# Barnette controller log

## 2026-09-10 — R1 pulse 1

Ran a full-text decision search for Kao--Chen 2005, Florek, and Schnieders
2025. Accessible full texts rule out containment by the cited Florek and
Schnieders results at the global ordered-edge-pair and same-order
nonisomorphic-count quantifiers. The Kao--Chen publisher record and metadata
were located, but the lawful full text requires authentication and no OA copy
was found. The precise theorem-level comparison boundary is recorded in
`advisor/REQUEST.md`; no novelty verdict is inferred from the abstract.

Repository-control caveat: this AIMath directory has no `AGENTS.md`, no git
metadata, no `ResearchLibrary`, and none of the four requested skill files was
present on the host. Consequently there was no lawful library-ingest target
and no repository in which to commit or push this pulse.

ROUTE=R1 PULSE=1 VERDICT=open

## 2026-09-11 — R1 pulse 2

Continued only at the Kao--Chen full-text comparison gate.  A fresh
title/DOI/Chinese-title/author-domain decision search found the publisher and
author records plus secondary citations, but no independently lawful complete
PDF or scan.  Therefore no theorem numbers, proof pages, figures, replacement
gadget, seed hypotheses, recursion quantifiers, joint ordered-edge-pair
property, or graph-enumeration statement can be verified.  In particular,
separate 1-edge fault Hamiltonicity and Hamiltonian laceability in the abstract
do not imply one joint containing/avoiding Hamilton cycle.

The exact external boundary is now frozen in `advisor/REQUEST.md`: obtain one
complete lawful scan of volume 33(1), pp. 11--19, with CiNii NCID `AN10510587`
and Iwate University's 33(1--3) holding as a concrete acquisition lead, then
audit all seven comparison quantities page by page.  The holding is not
mathematical evidence.  Containment remains UNDETERMINED, so neither GO nor
NOGO is issued.

Control caveat remains unchanged: this AIMath directory has no `AGENTS.md`, no
git metadata, no ResearchLibrary, and none of the four requested skill files
was present on the host.  Thus there was no lawful library-ingest target and no
repository in which to commit or push this pulse.

ROUTE=R1 PULSE=2 VERDICT=open

## 2026-09-12 — R2 pulse 1

Worked only on the cube CEN/UV word-to-unrooted-graph fibre.  Exact pynauty
canonicalization of every word through depth 12 gives class counts
`1,1,1,2,3,6,10,20,36,72,136,272,528`; at depth 12, 4096 words give 528
classes, with fibres of size 4 or 8.  Face-degree sequences are too coarse:
only 38 occur at depth 12 and one supports 85 canonical classes.  The finite
observation is stored under `scratch/` and is not used as a theorem.

Note 167 records the strict all-depth proof.  The rooted two-step delay
theorem makes each pointwise cube-rooted type receive exactly four words, and
an unrooted order-n graph supports at most `(n)_8` such types via injections of
the labelled old cube core.  Therefore every word fibre is at most `4(n)_8`,
and the image has at least `ceil(2^(k-2)/(n)_8) = 2^(n/4-O(log n))` pairwise
nonisomorphic global-H^{+-} Barnette graphs.  This proves R2 outcome (a); no
structural exponential collapse occurs.

Contribution verdict: at most B-level while R1 is unresolved and the theorem
remains confined to one fixed two-letter grammar.  The single missing A-level
increment is a uniform global-H^{+-} plus subexponential-fibre theorem for a
strictly larger intrinsic legal-successor subclass.  The cheapest upgrade
observation is a constant-size orbit/transfer classification of all legal
successor sites meeting the newest annulus, not an adjacent-order census.
This directory has no git metadata, so no commit was made.

ROUTE=R2 PULSE=1 VERDICT=proved

## 2026-09-12 — R2 pulse 2

Audited the exact upstream object used by Note 167.  Note 011 defines the
rooted type as the graph together with the old-core injection fixed pointwise,
and explicitly excludes both the raw history and the marked next successor
site.  Its ordered-boundary invariant and intrinsic peeling, now named
Theorem 011.1, prove the needed one-way implication
`rho_k(w)=rho_k(w') => w[1:k-2]=w'[1:k-2]`.  Extending the local isomorphism by
the identity on the eight old cube vertices, and restricting a cube-rooted
isomorphism to the four boundary vertices, identifies this with precisely the
cube-rooted object used in Note 167.  Thus every rooted word fibre is at most
four; the unused converse gives the stronger exact-four statement.

Note 167 now states the dependency by theorem number, equation range, object,
and direction, and writes the unrooting count exactly as `Aut(H)\I_H`, bounded
by `(n)_8`.  It also records the complete Note 011 text as a required
attachment in the next independent R2 verification package.  The counting
chain is therefore closed at the previously uncertified interface.

Added the scope limitation `pw(G_w) <= 7`: the initial cube is one bag, and
each later bag consists of the current four endpoints plus four new vertices.
All final edges occur in an introduction bag, while successor rules use only
the current endpoints and new vertices, so a vertex never returns after
leaving the active port.  Hence bag occurrences are intervals.  This bounded
pathwidth explains why the exponential family is not yet a broad structural
Barnette class.

No experiment was started.  A non-frozen, not-started structural-upgrade
candidate specification was drafted with an intrinsic nested four-port
annular class, at most three routes, mechanical go/no-go criteria, and the
required forbidden directions.  R1 remains untouched pending the external
library scan.  This directory has no git metadata, so no commit was made.

ROUTE=R2 PULSE=2 VERDICT=proved
UPGRADE_SPEC_DRAFT=SPEC-2026-09-12-upgrade-candidate.md

## 2026-09-12 — R2 pulse 3

Applied the GPT-6 Pro round-4 REVISE decision. The candidate class is now an
exhaustive finite spherical four-port certificate class with no outside face,
mirror transport, explicit port numbering, cube/zero-layer kernel, terminal
cap, virtual seals, UV shared ports, exact layer ownership, and checked legal
inverses. It includes a CEN/UV certificate construction and makes strictness a
separate unrooted-graph requirement.

The endpoint is global joint \(H^{+-}\); finite rooted congruence is only Route
1. Route quantifiers, the over-approximation rule, forbidden inferences,
bounded-pathwidth warning, and the remaining A/S increment were tightened.
Note 167 now says inclusion inherits the old exponential lower bound, so a new
word-fibre theorem is not required for this upgrade.

The freeze gate remains open: there is no concrete third successor operation
with representative, ordered ports and successor, allowed relabelling group,
non-CEN/UV orbit proof, and separate unrooted strictness proof. No experiment or
census was started, and R1 was untouched. No new advisor freeze request was
written. This directory has no git metadata, so no commit was made.

ROUTE=R2 PULSE=3 VERDICT=open
UPGRADE_SPEC_DRAFT=SPEC-2026-09-12-upgrade-candidate.md

## 2026-09-12 — R2 pulse 4

Closed only the explicit-new-orbit freeze gate.  Starting from the cube, the
first expanded graph has the adjacent mixed legal site `(0,3,11,8)`.  Expanding
that site with new vertices `12,13,14,15` and recording successor
`(0,12,7,4)` gives a fully specified third rooted operation: its successor
birth-status multiset is `{born,retained}`, invariant under the declared full
port/colour/reflection relabelling group, whereas both CEN and UV have
`{born,born}`.  Thus it is in neither old rooted orbit.

The separate graph-level gate is also closed.  Expanding `(0,12,7,4)` produces
an explicit 20-vertex Barnette graph whose incident-face-length-triple multiset
is `12(4,6,6)+6(4,4,6)+2(6,6,6)`.  The eight depth-three CEN/UV words have one
of two different displayed multisets, so uniqueness of the spherical embedding
for 3-connected planar graphs proves that this unrooted graph is in no old word
image.  The fixed constant-size checker verifies all edge tables, rotation
systems, legality, vertex connectivity, signatures, and the eight finite
same-depth comparisons; it is not promoted from `scratch/`.

Only lines belonging to the candidate SPEC's freeze-gate record were replaced.
The document remains DRAFT / NOT FROZEN / NOT STARTED, no route or (T) proof
was begun, and R1 remains waiting for the external library scan.  A final
ACCEPT/REVISE request with the complete revised SPEC and Note 167 v3 was
appended to `advisor/REQUEST.md`.  This directory has no git metadata, so no
commit was made.

ROUTE=R2 PULSE=4 VERDICT=record_complete
UPGRADE_SPEC_DRAFT=SPEC-2026-09-12-upgrade-candidate.md

## 2026-09-12 — R2 pulse 5

Applied the GPT-6 Pro round-5 REVISE decision by choosing interface option
(ii). The candidate class is now defined by general legal expansion sequences
with complete ledgers and embedded legal-site data; all asserted equivalence
with nested four-port separators was removed. The reason is explicit: the
fixed successor `S2={0,12,7,4}` revisits old-core vertices `4,7`, and no
alternative nested certificate has been supplied.

The SPEC now separates the proved unrooted statement
`H notin F_CEN/UV` from the unproved former nested-class membership claim. For
the revised general-sequence class, `H in C_4A` follows from the already
verified legal history only, and is not presented as a nested-decomposition
result. No legality, connectivity, count, or face-type computation was rerun.

The Route 1 input domain and fixed third-operation context now explicitly
include retained edge `74`, its endpoints, and its incident face/arcs. Route 1
is the unique first line; Route 2 retains only inverse-step support for the
target-property induction and no longer treats inverse existence as a
structural upgrade; Route 3 remains closed until a real Route 1 collision.
The proposed twelve-vertex bag argument and the claim of likely uniform
bounded pathwidth were withdrawn: vertices `4,7` violate bag-interval
continuity. Bounded pathwidth for the wider class is recorded as undetermined,
while the old CEN/UV bound `pw<=7` remains intact.

The upgrade SPEC remains DRAFT / NOT FROZEN / NOT STARTED. It is considered
freeze-ready for final advisor review, so a concise ACCEPT request listing
only these diff points was appended to `advisor/REQUEST.md`. No route, (T),
Hamilton search, census, or R1 work was started. This directory has no git
metadata, so no commit was made.

ROUTE=R2 PULSE=5 VERDICT=revised

## 2026-09-12 — R2 pulse 6

Applied the GPT-6 Pro round-6 sole remaining mechanical correction. Certificate
item 3 now partitions final-edge ownership explicitly as
`O_kernel=(E(Q) intersect E(G_k)) setminus F_k`,
`O_i=(B_i intersect E(G_k)) setminus F_k`, and `O_cap=F_k`, while original
cube vertices and layer-born vertices retain their prior assignments. The cap
therefore owns terminal-site edges exclusively even when one is a surviving
cube edge, so both depth zero and the allowed truncation at
`s_2=(0,12,7,4)` have unique ownership.

Route 1 now records the fixed third-operation template `o*`, its full real
context domain, joint semantic output, output-congruence and transition
equations, and the advisor's mechanical interface-only GO, certified-real-
collision NO-GO, and undecided cases. It explicitly states that interface GO
is not (T) GO. The contribution ceiling is now B-level structural
generalization/methodological progress; A/S still requires connecting the
joint-witness mechanism to complete coverage or sharp classification of a
broad class with independent structural meaning.

The round-5 nesting-equivalence and wider-class pathwidth issues remain CLOSED.
Historical copies of the former ownership sentence in earlier advisor request
attachments were left unchanged; the new final ACCEPT request lists the exact
before/after rule and Route 1 additions. The SPEC remains DRAFT / NOT FROZEN /
NOT STARTED. No route, (T), Hamilton search, R1 work, legality/count/face-type
calculation, or new lemma was started or repeated. This directory has no git
metadata, so no commit was made.

ROUTE=R2 PULSE=6 VERDICT=revised

## 2026-09-12 — Route 1 pulse 1: fixed third-operation interface GO

Read GPT-6 Pro round 7 in full and froze the pulse objects before computation.
`scratch/r3_pulse1/DEFS.md` defines the role operation
`(u,v,x,y;r0,r1) -> (u,a,r0,r1)`, the full real legal-history domain, the
fourteen slots and output rename/forget map, finite metadata eta, jointly
realized exterior rows, successor phase, semantic output J-star, and exact
Hamilton contain/avoid acceptance.  The frozen SPEC and old candidate were not
modified.

Proved the complete restriction--gluing bijection in
`scratch/r3_pulse1/PROOF.md`.  Every output generator uniquely restricts to a
real old-exterior generator plus a subset of the eight born edges and retained
edge, and every degree-compatible pair glues back.  Degree words, full
partitions, saturated closed-component counts, and joint target-use bits are
literal under this union.  The proof is independent of graph order, nesting,
face-arc length, and the age of the retained edge, so it covers every real
context in the declared domain and does not read information outside sigma0.
Connected spanning 2-regular acceptance with bits `(1,0)` is exactly one
Hamilton cycle containing e and avoiding f.

`generate_tables.py` mechanically generated the complete 512 local-selection
rows in `T0.tsv` and `j0.tsv` and ended with
`R3_PULSE1_ATOMIC_TABLES_VERIFIED rows=512`.  The independent
`validate_real_contexts.py` enumerated complete exterior/output supports in
the frozen 12-vertex context and a separately legality-checked cube context,
checking 19 and 10 deterministic target pairs respectively; it ended with
`R3_PULSE1_REAL_CONTEXT_CROSSCHECK_VERIFIED`.  These computations verify the
implementation, while the bijection bears the universal claim.

Recorded the result as Note 168 and added the README entry.  Appended an
advisor request for heterogeneous verification of DEFS, both tables, alias
handling, the bijection, coverage, and joint acceptance.  No adjacent-order
census, Route 2/3 work, Note 167 recount, R1 action, or general Barnette attack
was performed.  This is only `o*`'s interface GO and is not (T) GO.

ROUTE=R1 PULSE=1 VERDICT=GO

## 2026-09-12 — Route 1 pulse 2: corrected fourteen-slot interface GO (awaiting heterogeneous review)

Read GPT-6 Pro round 8 in full and withdrew pulse 1's certified status.  Note
168 now begins with the required REJECT notice and remains as historical
record; README points to that rejection and to Note 169.  The accepted
nine-edge atomic enumeration and actual-edge-set decomposition principle were
retained.  The frozen SPEC and Note 167 were not changed.

`scratch/r3_pulse2/DEFS.md` removes all absolute layer numbers from sigma:
complete certificates retain them, while eta has only enumerated finite
birth/deletion/location statuses and bounded marked-incidence words.  It
defines the full fourteen-slot equality quotient, a current-vertex-existence
bit for every class, input activity by actual membership in `V(G)`, output
activity after the four births, and deterministic quotient, preserve/forget,
target-location, status and face-word transport.  Forgotten structural roles
and target-only classes are retained exactly when they represent a current
target endpoint.

The rewritten `row_engine.py` consumes eta and rows on quotient classes.  T0
uses precisely the 128 canonical subsets of `L' minus {ua,r}`.  j0 separately
uses all 512 complete subsets of `L'`, checks full degree two, and computes
`kappa=(alpha(F union (P minus K+)),1_ua,1_r)` from that same legal complete
pair before testing its single component and joint `(1,0)` target bits.
`PROOF.md` states the bijections only for actual exterior subgraphs and local
edge sets; it proves that all actual realizations of a compressed row obey the
same quotient transition, rather than claiming a row uniquely recovers a
subgraph.

The regression gate first passed both round-8 real rows: the cube Hamilton
witness for `e=67,f=04` no longer raises `KeyError e0`, and the
`e=12,f=04` successor row correctly retains aliased roles `v,x`.  The full
validator then independently enumerated exterior generators, successor
generators and spanning 2-factors and compared eta+, every successor row,
every kappa and acceptance.  It covered the pulse-1 depth-zero and frozen
depth-one contexts and a legal complete CEN history at depth two, ending:

```
ROUND8_REAL_ROW_REGRESSIONS_OK cases=2
FULL_CONTEXT_OK depth-0 vertices=8 retained=(5, 4) pairs=6
FULL_CONTEXT_OK fixed-depth-1 vertices=12 retained=(7, 4) pairs=2
FULL_CONTEXT_OK legal-history-depth-2 vertices=16 retained=(11, 10) pairs=2
R3_PULSE2_FULL_SIGMA_KAPPA_ETA_ACCEPTANCE_VERIFIED
```

`generate_tables.py` regenerated 128 T0 rows and 512 j0 rows and ended
`R3_PULSE2_ATOMIC_TABLES_VERIFIED T0=128 j0=512`.  The universal result rests
on the quotient case coverage and restriction--gluing proof, not the three
bounded contexts.  Note 169 therefore registers only “o* interface GO
(awaiting heterogeneous review)”.  It is not (T) GO, supplies no later
retained-edge transition, covers no other operation, and does not establish
the full induction or acceptance of every reachable state.  No adjacent-order
census, Route 2/3, general Barnette attack, R1 change, or Note 167 recount was
performed.  A round-9 heterogeneous request listing the closure of every
round-8 REJECT item was appended to `advisor/REQUEST.md`.

ROUTE=R1 PULSE=2 VERDICT=GO

## 2026-09-13 — Route 1 pulse 3: retained-edge reattachment UNDETERMINED

Read GPT-6 Pro round 9 in full.  Updated Note 169 and README to the accepted
status “o* 一步接口 GO（异源核验 ACCEPT，round 9）”; its scope remains one
step only.  The frozen SPEC, Note 167 and the external-scan R1 item were not
changed.

Before computation, froze `scratch/r3_pulse3/DEFS.md`.  Its finite `nu` uses a
sixteen-slot equality quotient, colours up to reversal, q/target identity,
bounded marked-role face/arc order, and finite next-target location/status and
existence fields.  It excludes graph identifiers, unbounded arc lengths and
recomputed row support; no field was added after the freeze.

The proof audit closes no total reconstruction theorem.  If q endpoints were
not active, every old exterior generator had degree two there, while the next
input permits degrees 0/1.  Thus new rows need not be projections of old rows.
Even when q is a target and its use bit is present, that bit does not determine
how its component splits after deleting q.  No global real-domain identity
forcing the missing refinements was proved, and no two complete real histories
with equal `Sigma_plus,nu` but unequal full `Sigma_next` were completely
certified.  Hence neither GO nor NOGO is licensed.

The independent validator used the complete cube-to-depth-one certificate,
the displayed first o* operation, and a directly legality-checked second o*
with q=(15,8).  It computed full next supports directly from the graph in both
required load-bearing cases and ended:

```
DIRECT_NEXT_OK q-endpoints-outside-interface q=(15, 8) boundary=(0, 12, 7, 4, 15, 8, 1, 5, 2, 6) realizers=5632 rows=5121
DIRECT_NEXT_OK q-target-only-endpoints q=(15, 8) boundary=(0, 12, 7, 4, 15, 8, 2, 6) realizers=1144 rows=1016
NO_TOTAL_U_CLAIMED pulse-2 rows omit degree/connectivity refinements at newly exposed q endpoints; no proved total reconstruction rule is available
R3_PULSE3_DIRECT_REATTACH_REGRESSIONS_VERIFIED verdict=UNDETERMINED
R3_PULSE3_REATTACHMENT_UNDETERMINED
```

`reattach.py` returns an explicit Undetermined value rather than presenting an
unproved projection as U.  Per the stopping rule, no Note 170 was written and
Route 3 was not opened.  Added an advisor request to review this exact scope.
No census, Route 2/3 work, CEN/UV table duplication, Note 167 recount, or
general Barnette claim was made.

ROUTE=R1 PULSE=3 VERDICT=UNDETERMINED

## 2026-09-13 — Route 1 pulse 4: canonical-q bucket scan UNDETERMINED

Read the round-10 heterogeneous audit in full.  Before computation froze
`scratch/r3_pulse4/DEFS.md`, correcting the prior fourteen/sixteen mismatch by
naming the explicitly listed tuple as fourteen slots and giving the complete
old-to-new role map.  It also freezes the canonical colour/face encoding,
independent complete-summary calculators, and real-history/difference-row
certificate formats.  No fields were added after computation.

`canonical_nu.py`, `sigma_next.py`, and `bucket_scan.py` regenerate the fixed
cube -> G1 -> o* history, enumerate retained-edge legality, encode canonical
`nu`, and compute complete supports directly from graph edge subsets.  They do
not use pulse-2 row algebra as the authority for `Sigma_next`; hashes are only
reported after literal tuple/row comparison.  The real scan found one legal
q, `(15,8)`, one bucket of size one, and no conflict.  Both `Sigma_plus` and
that `Sigma_next` have 5,121 rows from 5,632 realizers.  Therefore the finite
package supplies no collision, while no all-domain `U` or semantic coverage
proof was obtained.

Direct legality also exposed that the frozen request's demand to include
`q=e={1,5}` and `q=f={2,6}` is incompatible with the same fixed real domain:
neither is a legal next retained edge.  They were not admitted as formal
collision states.  As a separate required regression, `q=e` used a freshly
regenerated old `Sigma_plus` and the canonical non-stub encoder; after
`beta_e=0`, renaming, and normalization, its 987 restricted rows exactly equal
the 987 direct deletion rows.  This regression is outside `D_next` and is not
GO.  `scan.json` contains full history/edge/property records and all statistics.

No Note 170 was written; Route 3 remains closed.  The frozen SPEC, R1, Note
167, and Note 169 were not changed.  An advisor request asks for review of the
domain discrepancy and a corrected cheapest package.

ROUTE=R1 PULSE=4 VERDICT=UNDETERMINED
