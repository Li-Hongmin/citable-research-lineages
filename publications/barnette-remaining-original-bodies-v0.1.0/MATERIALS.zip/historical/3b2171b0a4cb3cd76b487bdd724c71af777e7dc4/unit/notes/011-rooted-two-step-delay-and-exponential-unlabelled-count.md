# Rooted two-step delay and exponential unlabelled count

[Note 010](010-nonconjugate-cen-uv-expansion-tree.md) constructs, from a
fixed marked order-240 Barnette graph, an edge-Hamiltonian descendant for
every CEN/UV history.  This note determines the exact all-depth quotient
when the old core is fixed pointwise and then removes that rooting by a
counting argument.  No recognition theorem for the old core inside an
unlabelled descendant is required.

Encode CEN by \(0\) and UV by \(1\).  Throughout the rooted statement the
ordered boundary

\[
(U,V,X,Y)
\tag{1}
\]

is fixed pointwise.  For the explicit construction these are the four
vertices of the initial n240 expansion site, in the order used in Note 010.

## The ordered-boundary grammar

Let \(B\) be the basic four-pole with internal vertices \(a,b,c,d\), square

\[
a-b-c-d-a,
\]

and boundary attachments

\[
U-a,\qquad V-b,\qquad X-c,\qquad Y-d.
\tag{2}
\]

For an ordered-boundary four-pole \(N\), write \(n_T(N)\) for the internal
neighbour of terminal \(T\in\{U,V,X,Y\}\).  Define two outer-annulus
operators \(F_0,F_1\) as follows.

For \(F_0(N)\), the CEN annulus, introduce outer vertices \(a,b,c,d\), use
the boundary paths

\[
U-a-b-V,\qquad X-c-d-Y,
\]

and attach \(N\) by

\[
b n_U(N),\qquad c n_V(N),\qquad
d n_X(N),\qquad a n_Y(N).
\tag{3}
\]

Thus the only edges inside the outer four-vertex block are \(ab\) and
\(cd\).

For \(F_1(N)\), the UV annulus, let the outer vertices induce the square

\[
a-b-c-d-a.
\]

Use the attachments

\[
X-c,\qquad Y-d,\qquad a n_V(N),\qquad b n_X(N),
\tag{4}
\]

while the \(U\)- and \(Y\)-terminals of \(N\) become respectively the new
outer \(U\)- and \(V\)-terminals.  Equations (3)--(4) are precisely the
CEN and UV successor sites of Note 010 expressed from the old boundary
towards the newest gadget.

If \(b_1\cdots b_k\in\{0,1\}^k\) is a depth-\(k\) history, the first
expansion installs \(B\), and \(b_i\) determines the site expanded at the
next step.  Hence, for \(k\geq1\), its unmarked local patch is

\[
P(b_1\cdots b_k)
=F_{b_1}\circ F_{b_2}\circ\cdots\circ F_{b_{k-1}}(B).
\tag{5}
\]

The final letter \(b_k\) records only the next marked site and does not
alter the depth-\(k\) graph.

## A local letter invariant

Define

\[
r(N)=
\mathbf 1\bigl[n_V(N)n_X(N)\in E(N)\bigr].
\tag{6}
\]

For the basic pole, \(r(B)=1\), since \(n_V(B)=b\), \(n_X(B)=c\), and
\(bc\in E(B)\).  In \(F_0(N)\), the new boundary neighbours of \(V,X\)
are the outer vertices \(b,c\), but \(bc\) is absent from the CEN annulus.
In \(F_1(N)\), these neighbours are \(n_Y(N)\) and the outer vertex \(c\),
and (4) contains no edge between them.  Therefore

\[
r(F_0(N))=r(F_1(N))=0.
\tag{7}
\]

Since the grammar starts at \(B\) and is closed under \(F_0,F_1\),

\[
r(N)=1\quad\Longleftrightarrow\quad N=B
\tag{8}
\]

for every grammar pole \(N\).

Now let \(P\) be a nonbasic grammar pole.  Its boundary neighbours

\[
c=n_X(P),\qquad d=n_Y(P)
\]

are adjacent.  Let \(c^*,d^*\) be their unique remaining neighbours after
the boundary edges and the edge \(cd\) are omitted, and define

\[
\kappa(P)=\mathbf 1[c^*d^*\in E(P)].
\tag{9}
\]

If \(P=F_1(N)\), then \(c^*=b\), \(d^*=a\), and \(ab\) is an edge of the
UV square.  If \(P=F_0(N)\), equations (3) give

\[
c^*=n_V(N),\qquad d^*=n_X(N).
\]

Consequently,

\[
\kappa(F_1(N))=1,
\qquad
\kappa(F_0(N))=r(N).
\tag{10}
\]

Combining (8) and (10), whenever \(N\neq B\),

\[
\kappa(F_i(N))=i.
\tag{11}
\]

Thus the outer letter is intrinsic to the ordered-boundary rooted graph
until only the final annulus remains.

## Unique peeling and the invisible final letter

Once the value of \(i\) is known, its outer block is also intrinsic.  For
\(i=0\), it is the set of the four boundary neighbours.  For \(i=1\), it is

\[
\{c,d,c^*,d^*\}.
\]

Deleting this block exposes the four attachments of \(N\).  In the CEN
case their order is recovered from

\[
b,c,d,a\longleftrightarrow U,V,X,Y.
\]

In the UV case, the old outer \(U,V\) recover the inner terminals \(U,Y\),
while the attachments exposed at \(d^*=a\) and \(c^*=b\) recover the inner
terminals \(V,X\).  The peeled object is therefore \(N\) with its full
ordered boundary, not merely as an unlabelled four-pole.  Every
boundary-pointwise isomorphism preserves this block and induces a
boundary-pointwise isomorphism of the peeled poles.

The recursion stops exactly when the inner pole is \(B\).  At that point
the two caps are isomorphic.  Name the CEN outer block \(a,b,c,d\) and its
inner basic square \(e,f,g,h\).  The map

\[
\begin{aligned}
a&\mapsto e,& b&\mapsto h,& c&\mapsto c,& d&\mapsto d,\\
e&\mapsto g,& f&\mapsto b,& g&\mapsto a,& h&\mapsto f
\end{aligned}
\tag{12}
\]

fixes \(U,V,X,Y\) and sends the internal edge set of \(F_0(B)\),

\[
\{ab,cd,be,cf,dg,ah,ef,fg,gh,he\},
\]

onto the internal edge set of \(F_1(B)\).  Hence

\[
F_0(B)\cong F_1(B)
\tag{13}
\]

by a boundary-pointwise isomorphism.

### Rooted two-step delay theorem

For equal-length words \(s,t\), recursive application of (11) and the
intrinsic peeling forces equality of every letter except the last one.
Conversely, (13) identifies either choice of the last letter, and applying
the common outer operators extends that isomorphism through every common
prefix.  Therefore

\[
F_s(B)\cong F_t(B)
\quad\Longleftrightarrow\quad
s\text{ and }t\text{ agree after deleting their final letters}.
\tag{14}
\]

Together with (5), for \(k\geq2\), two depth-\(k\) histories give
pointwise-rooted isomorphic descendants if and only if their first \(k-2\)
letters agree.  At depths \(0\) and \(1\) there is one unmarked rooted type.
The exact number of pointwise-rooted types is consequently

\[
T_k=2^{\max(k-2,0)}.
\tag{15}
\]

This is an all-depth analytic theorem.  An independent reconstruction of
(3)--(13), including an edge-by-edge check of (12), is recorded in
[the independent validation](../scratch/worker-barnette/rooted-two-step-delay-independent-validation.md).
Its constant-size symbolic checker is
[verify_rooted_two_step_local_patch.py](../scratch/worker-barnette/verify_rooted_two_step_local_patch.py).

## Removing the root by counting marked embeddings

Let \(G_0\) be the fixed labelled order-240 root of Note 010, whose initial
site edges are \(uv\) and \(xy\), and set

\[
R=G_0-\{uv,xy\}.
\tag{16}
\]

Here \(R\) has the same 240 labelled vertices as \(G_0\).  The first
expansion deletes \(uv,xy\).  Every later operation deletes only a gadget
edge or an old--new edge, and no later operation adds an old--old edge.
Thus, in every positive-depth descendant, the subgraph induced by the 240
old vertices is exactly \(R\).  In particular, it would be incorrect to
describe this marked subgraph as an embedded copy of the complete \(G_0\);
the two missing site edges are part of the rooted data through the fixed
labels \(u,v,x,y\).

Fix an unlabelled \(n\)-vertex descendant \(H\).  A pointwise-rooted
realization of \(H\) determines an injection

\[
\iota:V(R)\hookrightarrow V(H)
\tag{17}
\]

that identifies the labelled old core and its ordered four boundary
vertices.

Here a rooted type consists only of the graph together with this labelled
old-core injection; the raw expansion history and the marked next site are
not additional rooted data.

The rooted types supported by \(H\) are orbits of the valid
injections (17) under \(\operatorname{Aut}(H)\).  They are therefore no
more numerous than all injections of a 240-element labelled set into an
\(n\)-element vertex set:

\[
(n)_{240}
=n(n-1)\cdots(n-239)
=\frac{n!}{(n-240)!}.
\tag{18}
\]

No uniqueness of the copy of \(R\) in \(H\) is assumed in this bound.

Let \(B_{\mathrm{EH}}(n)\) denote the number of isomorphism classes of
\(n\)-vertex edge-Hamiltonian Barnette graphs.  Note 010 proves that every
CEN/UV history used here is an edge-Hamiltonian Barnette graph.  At depth
\(k\), the order is

\[
n=240+4k.
\]

Partitioning the \(T_k\) rooted types by their underlying unlabelled graph
and applying (18) gives

\[
\boxed{
B_{\mathrm{EH}}(240+4k)
\ge
\left\lceil
\frac{2^{\max(k-2,0)}}{(240+4k)_{240}}
\right\rceil .
}
\tag{19}
\]

For \(k=0\), the same inequality follows separately from the certified
edge-Hamiltonian root \(G_0\).  For \(k\geq2\), writing \(n=240+4k\) and
using \((n)_{240}\leq n^{240}\) yields

\[
\begin{aligned}
B_{\mathrm{EH}}(n)
&\ge
\left\lceil
\frac{2^{n/4-62}}{(n)_{240}}
\right\rceil\\
&\ge
\left\lceil
2^{\,n/4-240\log_2 n-62}
\right\rceil .
\end{aligned}
\tag{20}
\]

Hence, along the orders \(n=240+4k\),

\[
\boxed{
B_{\mathrm{EH}}(n)\ge 2^{\,n/4-O(\log n)}.
}
\tag{21}
\]

## Scope

The local theorem fixes the ordered n240 boundary pointwise.  In the full
graph application we use the stronger rooted convention that all vertices
of the old labelled core are fixed pointwise.  The theorem does not assert
that this old core is uniquely recognizable inside an unlabelled descendant,
nor that arbitrary unrooted isomorphisms preserve it.  The
falling-factorial bound (18) bypasses both requirements by allowing every
possible injection of the old labelled vertices.  Equations (19)--(21) are
lower bounds, not an exact enumeration of the unlabelled descendants.
