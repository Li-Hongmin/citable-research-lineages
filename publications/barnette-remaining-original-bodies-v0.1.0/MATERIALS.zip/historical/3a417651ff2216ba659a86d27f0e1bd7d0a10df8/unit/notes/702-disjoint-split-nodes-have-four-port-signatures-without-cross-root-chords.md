# Disjoint split nodes have four-port signatures without cross-root chords

Retain the finite simple three-connected cubic bipartite plane parent, legal cofacial \(C_4\)-expansion site and selected chorded single-hexagon two-root opening of [Note 701](701-two-parent-squares-close-chorded-two-root-mixed-unary-openings.md). Every assigned special position lies in a complete two-special leaf except the two direct positions of each of two marked unary nodes
\[
 U_i=(H_i,s_i,A_i,t_i,J_i),\qquad A_i=[L_i,R_i]\quad(i=1,2),
\]
whose direct positions are split. Suppose each marked node has two consecutive incoming plain-unary ancestors. There is **no face chord between the two ordinary roots**.

**No-cross disjoint theorem.** If the two marked nodes lie in different roots, or lie in the same root with disjoint ordinary intervals, the parent has a Hamilton cycle through both site edges and its legal expanded child is Hamiltonian. Thus a hypothetical failure in this no-cross profile must put the two split nodes in one root, nested.

**Proof.** The even cut of each root consists of its two old boundary edges and some of the four external special attachments \(r_L,u,v,r_R\). Three-connectivity forces exactly two attachments in each root. A root with two attachments needs spanning two-path covers in two different pairings of its four ports: its two old boundary ends and its two special attachments. Given these signatures in both roots, the four exterior paths of [Note 641](641-two-port-split-root-signatures-close-disconnected-chorded-roots.md) join them to one Hamilton cycle through the two site edges. Its end-gap argument invokes precisely the two-edge-cut exclusion of [Note 469](469-the-end-root-chorded-splice-and-unified-12f-plus-2-kernel.md), which does not depend on the internal node shapes. Reflection covers the opposite side and end gaps.

If the split nodes lie in distinct roots, each root has the two-port split signature of Note 641: its two plain ancestors meet that lemma's proper-ancestor hypothesis. There are no other nonleaf marked nodes in either root. Hence the exterior pairing argument applies directly.

It remains to prove the signature for a root \(W\) containing two **disjoint** split nodes. Let \(P\) be its open old arc, with boundary ends \(\ell,r\), and let \(a,b\) be its two external special positions. Delete the old edge \(E\) in every complete two-special leaf and add the internal face matching \(M\) outside \(a,b\). Open both marked nodes inside:
\[
 F_{\rm ii}=
  \bigl(P-E-\{s_1L_1,R_1t_1,s_2L_2,R_2t_2\}\bigr)
      \cup M\cup\{L_1R_1,L_2R_2\}.                    \tag{1}
\]
All vertices except \(\ell,r,a,b\) have degree two. Restore \(E\) only for component bookkeeping. The coarse pieces are the two closed children \(A_1,A_2\) and the complementary old word \(B\), which contains \(\ell,r\). The immediate plain-parent square of each \(U_i\) joins the two flanks at that node, so the three old segments of \(B\) are connected in the switch quotient. Their supports are disjoint from one another and from leaf squares; their chords are unused because the root is open and the marked nodes have two plain ancestors. If an inserted child chord is a complete-leaf square chord, that leaf's old edge is a quotient loop and is not needed.

Let \(K\) be the three-vertex graph on \(A_1,A_2,B\) with edges for \(M\)-chords between pieces. If \(K\) is connected, the component quotient of (1) is connected and the four-terminal square-switch argument of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) gives two pairings.

Suppose \(K\) is disconnected. An isolated child \(A_i\) containing neither \(a\) nor \(b\) is impossible: no face edge leaves it, its ordinary third edges remain inside its closing chord, and its only outgoing edges in the cubic parent are \(s_iL_i,R_it_i\), a forbidden two-edge cut. Therefore either one isolated child \(A_i\) contains **both** \(a,b\), while the other child joins \(B\), or \(B\) is isolated and \(A_1,A_2\) join each other. The possibility of three isolated pieces is excluded by the same two-edge-cut argument.

In the first case \(s_i,t_i\) are both nonterminals. Their mates are outside \(A_i\), cannot be each other by [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md), and at least one mate is outside the whole node \(U_i\). Open \(U_i\) outside while keeping \(U_j\) inside:
\[
 F_{\rm oi}=
 \bigl(P-E-\{H_is_i,t_iJ_i,s_jL_j,R_jt_j\}\bigr)
      \cup M\cup\{H_iJ_i,L_jR_j\},\quad j\ne i.       \tag{2}
\]
The inserted \(H_iJ_i\) joins \(U_i\)'s outer flanks, and the parent square of \(U_j\) joins the two flanks of its inner opening. The identified face edge joins the central word \(s_i,A_i,t_i\) to the rest, in which \(A_j\) and \(B\) are already connected by \(K\). Thus the square quotient of (2) is connected.

In the second case, \(B\) contains the four direct positions \(s_1,t_1,s_2,t_2\) and at most the two special terminals \(a,b\). Choose \(i\) so that at least one of \(s_i,t_i\) is nonterminal. Since \(B\) is isolated in \(K\), this direct position has its \(M\)-mate in \(B\); Note 473 excludes its only other possible mate within \(U_i\), so the mate lies outside \(U_i\). Use (2). The face edge joins its central word to the outer complement \(B'\), while the \(A_1\)--\(A_2\) chord of \(K\) joins the other closed child to that central word. The parent square of \(U_j\) connects the flanks of \(B'\). Again the square quotient is connected.

In both disconnected cases the connected quotient gives two different four-port pairings, since its square supports are disjoint and unused chords are available. The other root has Note 458's all-leaf two-port signature. Note 641's exterior paths select pairings that form a single marked Hamilton cycle. The exact expansion criterion of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the legal child. \(\square\)

At the exact selected chorded row \(c=5f-10,(m,R)=(f,2)\), the charge has \(\delta=0\) and supplies both marked nodes with the required plain ancestors. Together with Notes 699–701, a hypothetical failure in the **two-root two-unary** row has two split direct pairs. If its root face graph is disconnected, those nodes must be nested in one root. A connected root face graph, the nested no-cross case, the one-root row, other selected openings, and Barnette's conjecture remain undecided by this theorem. The upstream proof chain and this new signature have not had independent external review.
