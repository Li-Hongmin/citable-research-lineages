# Barnette controller log

## 2026-09-10 — R1 pulse 1

Ran a full-text decision search for Kao--Chen 2005, Florek, and Schnieders
2025. Accessible full texts rule out containment by the cited Florek and
Schnieders results at the global ordered-edge-pair and same-order
nonisomorphic-count quantifiers. The Kao--Chen publisher record and metadata
were located, but the lawful full text requires authentication and no OA copy
was found. The precise theorem-level comparison boundary is recorded in
`advisor/REQUEST.md`; no novelty verdict is inferred from the abstract.

Repository-control caveat: this AIMath directory has no `AGENTS.md`, no git
metadata, no `ResearchLibrary`, and none of the four requested skill files was
present on the host. Consequently there was no lawful library-ingest target
and no repository in which to commit or push this pulse.

ROUTE=R1 PULSE=1 VERDICT=open

## 2026-09-11 — R1 pulse 2

Continued only at the Kao--Chen full-text comparison gate.  A fresh
title/DOI/Chinese-title/author-domain decision search found the publisher and
author records plus secondary citations, but no independently lawful complete
PDF or scan.  Therefore no theorem numbers, proof pages, figures, replacement
gadget, seed hypotheses, recursion quantifiers, joint ordered-edge-pair
property, or graph-enumeration statement can be verified.  In particular,
separate 1-edge fault Hamiltonicity and Hamiltonian laceability in the abstract
do not imply one joint containing/avoiding Hamilton cycle.

The exact external boundary is now frozen in `advisor/REQUEST.md`: obtain one
complete lawful scan of volume 33(1), pp. 11--19, with CiNii NCID `AN10510587`
and Iwate University's 33(1--3) holding as a concrete acquisition lead, then
audit all seven comparison quantities page by page.  The holding is not
mathematical evidence.  Containment remains UNDETERMINED, so neither GO nor
NOGO is issued.

Control caveat remains unchanged: this AIMath directory has no `AGENTS.md`, no
git metadata, no ResearchLibrary, and none of the four requested skill files
was present on the host.  Thus there was no lawful library-ingest target and no
repository in which to commit or push this pulse.

ROUTE=R1 PULSE=2 VERDICT=open

## 2026-09-12 — R2 pulse 1

Worked only on the cube CEN/UV word-to-unrooted-graph fibre.  Exact pynauty
canonicalization of every word through depth 12 gives class counts
`1,1,1,2,3,6,10,20,36,72,136,272,528`; at depth 12, 4096 words give 528
classes, with fibres of size 4 or 8.  Face-degree sequences are too coarse:
only 38 occur at depth 12 and one supports 85 canonical classes.  The finite
observation is stored under `scratch/` and is not used as a theorem.

Note 167 records the strict all-depth proof.  The rooted two-step delay
theorem makes each pointwise cube-rooted type receive exactly four words, and
an unrooted order-n graph supports at most `(n)_8` such types via injections of
the labelled old cube core.  Therefore every word fibre is at most `4(n)_8`,
and the image has at least `ceil(2^(k-2)/(n)_8) = 2^(n/4-O(log n))` pairwise
nonisomorphic global-H^{+-} Barnette graphs.  This proves R2 outcome (a); no
structural exponential collapse occurs.

Contribution verdict: at most B-level while R1 is unresolved and the theorem
remains confined to one fixed two-letter grammar.  The single missing A-level
increment is a uniform global-H^{+-} plus subexponential-fibre theorem for a
strictly larger intrinsic legal-successor subclass.  The cheapest upgrade
observation is a constant-size orbit/transfer classification of all legal
successor sites meeting the newest annulus, not an adjacent-order census.
This directory has no git metadata, so no commit was made.

ROUTE=R2 PULSE=1 VERDICT=proved

## 2026-09-12 — R2 pulse 2

Audited the exact upstream object used by Note 167.  Note 011 defines the
rooted type as the graph together with the old-core injection fixed pointwise,
and explicitly excludes both the raw history and the marked next successor
site.  Its ordered-boundary invariant and intrinsic peeling, now named
Theorem 011.1, prove the needed one-way implication
`rho_k(w)=rho_k(w') => w[1:k-2]=w'[1:k-2]`.  Extending the local isomorphism by
the identity on the eight old cube vertices, and restricting a cube-rooted
isomorphism to the four boundary vertices, identifies this with precisely the
cube-rooted object used in Note 167.  Thus every rooted word fibre is at most
four; the unused converse gives the stronger exact-four statement.

Note 167 now states the dependency by theorem number, equation range, object,
and direction, and writes the unrooting count exactly as `Aut(H)\I_H`, bounded
by `(n)_8`.  It also records the complete Note 011 text as a required
attachment in the next independent R2 verification package.  The counting
chain is therefore closed at the previously uncertified interface.

Added the scope limitation `pw(G_w) <= 7`: the initial cube is one bag, and
each later bag consists of the current four endpoints plus four new vertices.
All final edges occur in an introduction bag, while successor rules use only
the current endpoints and new vertices, so a vertex never returns after
leaving the active port.  Hence bag occurrences are intervals.  This bounded
pathwidth explains why the exponential family is not yet a broad structural
Barnette class.

No experiment was started.  A non-frozen, not-started structural-upgrade
candidate specification was drafted with an intrinsic nested four-port
annular class, at most three routes, mechanical go/no-go criteria, and the
required forbidden directions.  R1 remains untouched pending the external
library scan.  This directory has no git metadata, so no commit was made.

ROUTE=R2 PULSE=2 VERDICT=proved
UPGRADE_SPEC_DRAFT=SPEC-2026-09-12-upgrade-candidate.md

## 2026-09-12 — R2 pulse 3

Applied the GPT-6 Pro round-4 REVISE decision. The candidate class is now an
exhaustive finite spherical four-port certificate class with no outside face,
mirror transport, explicit port numbering, cube/zero-layer kernel, terminal
cap, virtual seals, UV shared ports, exact layer ownership, and checked legal
inverses. It includes a CEN/UV certificate construction and makes strictness a
separate unrooted-graph requirement.

The endpoint is global joint \(H^{+-}\); finite rooted congruence is only Route
1. Route quantifiers, the over-approximation rule, forbidden inferences,
bounded-pathwidth warning, and the remaining A/S increment were tightened.
Note 167 now says inclusion inherits the old exponential lower bound, so a new
word-fibre theorem is not required for this upgrade.

The freeze gate remains open: there is no concrete third successor operation
with representative, ordered ports and successor, allowed relabelling group,
non-CEN/UV orbit proof, and separate unrooted strictness proof. No experiment or
census was started, and R1 was untouched. No new advisor freeze request was
written. This directory has no git metadata, so no commit was made.

ROUTE=R2 PULSE=3 VERDICT=open
UPGRADE_SPEC_DRAFT=SPEC-2026-09-12-upgrade-candidate.md

## 2026-09-12 — R2 pulse 4

Closed only the explicit-new-orbit freeze gate.  Starting from the cube, the
first expanded graph has the adjacent mixed legal site `(0,3,11,8)`.  Expanding
that site with new vertices `12,13,14,15` and recording successor
`(0,12,7,4)` gives a fully specified third rooted operation: its successor
birth-status multiset is `{born,retained}`, invariant under the declared full
port/colour/reflection relabelling group, whereas both CEN and UV have
`{born,born}`.  Thus it is in neither old rooted orbit.

The separate graph-level gate is also closed.  Expanding `(0,12,7,4)` produces
an explicit 20-vertex Barnette graph whose incident-face-length-triple multiset
is `12(4,6,6)+6(4,4,6)+2(6,6,6)`.  The eight depth-three CEN/UV words have one
of two different displayed multisets, so uniqueness of the spherical embedding
for 3-connected planar graphs proves that this unrooted graph is in no old word
image.  The fixed constant-size checker verifies all edge tables, rotation
systems, legality, vertex connectivity, signatures, and the eight finite
same-depth comparisons; it is not promoted from `scratch/`.

Only lines belonging to the candidate SPEC's freeze-gate record were replaced.
The document remains DRAFT / NOT FROZEN / NOT STARTED, no route or (T) proof
was begun, and R1 remains waiting for the external library scan.  A final
ACCEPT/REVISE request with the complete revised SPEC and Note 167 v3 was
appended to `advisor/REQUEST.md`.  This directory has no git metadata, so no
commit was made.

ROUTE=R2 PULSE=4 VERDICT=record_complete
UPGRADE_SPEC_DRAFT=SPEC-2026-09-12-upgrade-candidate.md

## 2026-09-12 — R2 pulse 5

Applied the GPT-6 Pro round-5 REVISE decision by choosing interface option
(ii). The candidate class is now defined by general legal expansion sequences
with complete ledgers and embedded legal-site data; all asserted equivalence
with nested four-port separators was removed. The reason is explicit: the
fixed successor `S2={0,12,7,4}` revisits old-core vertices `4,7`, and no
alternative nested certificate has been supplied.

The SPEC now separates the proved unrooted statement
`H notin F_CEN/UV` from the unproved former nested-class membership claim. For
the revised general-sequence class, `H in C_4A` follows from the already
verified legal history only, and is not presented as a nested-decomposition
result. No legality, connectivity, count, or face-type computation was rerun.

The Route 1 input domain and fixed third-operation context now explicitly
include retained edge `74`, its endpoints, and its incident face/arcs. Route 1
is the unique first line; Route 2 retains only inverse-step support for the
target-property induction and no longer treats inverse existence as a
structural upgrade; Route 3 remains closed until a real Route 1 collision.
The proposed twelve-vertex bag argument and the claim of likely uniform
bounded pathwidth were withdrawn: vertices `4,7` violate bag-interval
continuity. Bounded pathwidth for the wider class is recorded as undetermined,
while the old CEN/UV bound `pw<=7` remains intact.

The upgrade SPEC remains DRAFT / NOT FROZEN / NOT STARTED. It is considered
freeze-ready for final advisor review, so a concise ACCEPT request listing
only these diff points was appended to `advisor/REQUEST.md`. No route, (T),
Hamilton search, census, or R1 work was started. This directory has no git
metadata, so no commit was made.

ROUTE=R2 PULSE=5 VERDICT=revised

## 2026-09-12 — R2 pulse 6

Applied the GPT-6 Pro round-6 sole remaining mechanical correction. Certificate
item 3 now partitions final-edge ownership explicitly as
`O_kernel=(E(Q) intersect E(G_k)) setminus F_k`,
`O_i=(B_i intersect E(G_k)) setminus F_k`, and `O_cap=F_k`, while original
cube vertices and layer-born vertices retain their prior assignments. The cap
therefore owns terminal-site edges exclusively even when one is a surviving
cube edge, so both depth zero and the allowed truncation at
`s_2=(0,12,7,4)` have unique ownership.

Route 1 now records the fixed third-operation template `o*`, its full real
context domain, joint semantic output, output-congruence and transition
equations, and the advisor's mechanical interface-only GO, certified-real-
collision NO-GO, and undecided cases. It explicitly states that interface GO
is not (T) GO. The contribution ceiling is now B-level structural
generalization/methodological progress; A/S still requires connecting the
joint-witness mechanism to complete coverage or sharp classification of a
broad class with independent structural meaning.

The round-5 nesting-equivalence and wider-class pathwidth issues remain CLOSED.
Historical copies of the former ownership sentence in earlier advisor request
attachments were left unchanged; the new final ACCEPT request lists the exact
before/after rule and Route 1 additions. The SPEC remains DRAFT / NOT FROZEN /
NOT STARTED. No route, (T), Hamilton search, R1 work, legality/count/face-type
calculation, or new lemma was started or repeated. This directory has no git
metadata, so no commit was made.

ROUTE=R2 PULSE=6 VERDICT=revised

## 2026-09-12 — Route 1 pulse 1: fixed third-operation interface GO

Read GPT-6 Pro round 7 in full and froze the pulse objects before computation.
`scratch/r3_pulse1/DEFS.md` defines the role operation
`(u,v,x,y;r0,r1) -> (u,a,r0,r1)`, the full real legal-history domain, the
fourteen slots and output rename/forget map, finite metadata eta, jointly
realized exterior rows, successor phase, semantic output J-star, and exact
Hamilton contain/avoid acceptance.  The frozen SPEC and old candidate were not
modified.

Proved the complete restriction--gluing bijection in
`scratch/r3_pulse1/PROOF.md`.  Every output generator uniquely restricts to a
real old-exterior generator plus a subset of the eight born edges and retained
edge, and every degree-compatible pair glues back.  Degree words, full
partitions, saturated closed-component counts, and joint target-use bits are
literal under this union.  The proof is independent of graph order, nesting,
face-arc length, and the age of the retained edge, so it covers every real
context in the declared domain and does not read information outside sigma0.
Connected spanning 2-regular acceptance with bits `(1,0)` is exactly one
Hamilton cycle containing e and avoiding f.

`generate_tables.py` mechanically generated the complete 512 local-selection
rows in `T0.tsv` and `j0.tsv` and ended with
`R3_PULSE1_ATOMIC_TABLES_VERIFIED rows=512`.  The independent
`validate_real_contexts.py` enumerated complete exterior/output supports in
the frozen 12-vertex context and a separately legality-checked cube context,
checking 19 and 10 deterministic target pairs respectively; it ended with
`R3_PULSE1_REAL_CONTEXT_CROSSCHECK_VERIFIED`.  These computations verify the
implementation, while the bijection bears the universal claim.

Recorded the result as Note 168 and added the README entry.  Appended an
advisor request for heterogeneous verification of DEFS, both tables, alias
handling, the bijection, coverage, and joint acceptance.  No adjacent-order
census, Route 2/3 work, Note 167 recount, R1 action, or general Barnette attack
was performed.  This is only `o*`'s interface GO and is not (T) GO.

ROUTE=R1 PULSE=1 VERDICT=GO
