# Corrected fourteen-slot interface GO for the fixed third operation

## Statement and exact objects

For the fixed role operation

\[
(u,v,x,y;r_0,r_1)\longmapsto(u,a,r_0,r_1),
\]

let \(D_{o^*}\) be the full real legal-history domain in the frozen SPEC.  Let
\(\sigma_0(X)=(\eta(X),R_X)\) be exactly the finite fourteen-slot quotient,
current-existence metadata and complete realized exterior-row support in
[`DEFS.md`](../scratch/r3_pulse2/DEFS.md).  The actually delivered maps are
[`row_engine.py`](../scratch/r3_pulse2/row_engine.py)'s `transition` and
`joint_output`.  Then, for every \(X\in D_{o^*}\),

\[
 \widetilde T_0(\sigma_0(X))=\sigma_0(\Phi_{o^*}X),\qquad
 \widetilde j_0(\sigma_0(X))=J^*(X).
\]

Both equalities include all finite metadata, every successor row, every
\(\kappa\) value and the joint acceptance bit.  This is registered as
**\(o^*\) interface GO (awaiting heterogeneous review)**.

## Load-bearing argument

The fourteen roles are first quotiented by their equality relation.  A finite
bit on each class distinguishes a syntactic role from a vertex currently in
the graph.  Consequently the input interface contains precisely existing old
structural and target-endpoint classes; the output contains precisely existing
successor structural and target-endpoint classes.  A forgotten structural role
therefore survives whenever it aliases a target endpoint, while a target-only
class passes through.  Absolute history levels are kept only in the complete
certificate; the summary uses enumerated target location/status tags and
bounded marked-incidence words, so its value set is finite.

There are two distinct literal edge-set bijections.  A successor exterior
generator restricts uniquely to an actual old exterior \(F\) and one of 128
sets \(P_0\subseteq L'\setminus K^+\).  A complete spanning 2-factor restricts
uniquely to \(F\) and one of 512 sets \(P\subseteq L'\).  From the same complete
pair the engine computes

\[
\kappa(F\cup P)=
(\alpha(F\cup(P\setminus K^+)),1_{ua\in P},1_{r\in P}),
\]

rather than attempting to recover the cut partition from a closed-cycle
count.  A compressed row need not identify (F); the proof in
[`PROOF.md`](../scratch/r3_pulse2/PROOF.md) shows instead that every realization
of a row has identical degree, quotient-partition, saturated-component and
target-bit transport under every local selection.  This proves restriction
and gluing in both directions on the whole real domain.

Finally, the acceptance bit is computed from one complete union: every vertex
has degree two, it has exactly one component, and its simultaneous target bits
are ((1,0)).  This is equivalent to one Hamilton cycle containing (e) and
avoiding (f), not a conjunction of marginal witnesses.

## Mechanical gate

[`generate_tables.py`](../scratch/r3_pulse2/generate_tables.py) regenerates the
[128 canonical transition atoms](../scratch/r3_pulse2/T0.tsv) and
[512 complete atoms](../scratch/r3_pulse2/j0.tsv).  The independent
[`validate_real_contexts.py`](../scratch/r3_pulse2/validate_real_contexts.py)
first passes both round-8 real regressions, including the Hamilton row with
target-only endpoint 6 and the \(e=12\) row retaining aliased \(v,x\).  It then
compares independently enumerated complete (\eta^+), successor support,
(\{\kappa(H)\}) and acceptance for the pulse-1 cube and fixed depth-one
contexts plus a legal CEN-history context at depth two.  Its terminal line is
`R3_PULSE2_FULL_SIGMA_KAPPA_ETA_ACCEPTANCE_VERIFIED`.  These checks certify the
implementation; the universal quantifier rests on the preceding finite
case-exhaustion and edge-set proof.

## Scope and replacement

This note replaces only Note 168's withdrawn claim that the pulse-1 program
implemented the declared summary and proved the (o^*) interface GO.  It
preserves Note 168's accepted atomic-table and edge-decomposition core.  It
does not prove (T), acceptance of every reachable state, closure under any
other operation, supply the retained-edge information needed by a later
operation, or establish the full induction/coverage chain for
\(\mathcal C_{4\mathrm A}\).  It is not Route 2 or Route 3, is not a census,
and says nothing new about the general Barnette conjecture.  Note 167 and the
external-scan status of R1 are unchanged.
