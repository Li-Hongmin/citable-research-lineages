# A marked binary node closes the chorded one-root opening

Use the chorded one-root normal form
\[
 C=(w_0,z_L,t_c,W,t_b,z_R,w_*,
                   \alpha,a,b,c,d,\beta,w_0),          \tag{1}
\]
where \(G\) is a finite simple three-connected cubic
bipartite plane parent with a legal cofacial \(C_4\)-site.
The hexagon has chord \(ad\), trap chord \(\alpha\beta\),
and escape edges \(t_cc,t_bb\). The site edges are
\(q=w_0u,p=vw_*\); the exposed face chords have root
mates \(r_L,r_R\), and their order in \(W\) is
\(r_L<u<v<r_R\). Every assigned special position in
\(W\) belongs to a complete two-special ordinary leaf
except the two positions \(s,t\) assigned directly to
one marked binary node \(N\). The node has exactly two
complete ordinary child words \(A_1,A_2\) and is not
the ordinary root. No condition is placed on the
number or type of its ancestors, the face matching,
or the other ordinary branching nodes.

**Marked-binary theorem.** The parent has a Hamilton
cycle through both site edges, and its legal expanded
child is Hamiltonian.

**Proof.** The two exterior two-path covers (2) of
[Note 460](460-two-exterior-pairings-close-the-chorded-single-unary-defect.md)
span every vertex outside \(W\), retain \(p,q\), and
realize different pairings of the four root terminals
\(T=\{r_L,u,v,r_R\}\). It therefore suffices to find
one spanning internal two-path cover of \(W\) with
these terminals.

Let \(C_W\) be the old root arc closed by its root
chord. Let \(E\) be the old edge at every complete
two-special leaf, and let \(M\) be the face matching
at all root special positions outside \(T\). If
\(s,t\) lie in the same gap among the two children,
they are consecutive old-cycle vertices. The
one-unsupported-edge theorem of
[Note 459](459-one-adjacent-nonleaf-pair-splices-and-102-vertex-failures-must-split.md)
gives an internal two-path cover. We henceforth take
\(s<t\) in different gaps.

We use a terminal barrier. If a complete ordinary
child word \(A\) contains a terminal in \(T\), no
face-matching chord can join a root position strictly
before \(A\) to one strictly after \(A\). Such a
chord would interlace the terminal's site or exposed
face chord: its other endpoint lies outside \(W\),
either before or after it. All these chords occupy
the same side of the old Hamilton cycle.

First suppose the positions flank just one child,
say the order inside \(N\) is
\(H,s,A_1,t,A_2,J\); reflection handles
\(H,A_1,s,A_2,t,J\). Write \(A_1=[L_1,R_1]\)
and open it inside:
\[
 F=(C_W-E-\{sL_1,R_1t\})\cup M\cup\{L_1R_1\}.    \tag{2}
\]
This graph has four degree-one terminals and degree
two elsewhere. Restoring \(E\) gives the closed
child \(A_1\) and its connected complement \(B\).
If an \(M\)-edge joins them, their leaf-square
quotient is connected and gives a spanning two-path
cover. Otherwise the cut of the even child \(A_1\)
has only its two old boundary edges and the exterior
terminal edges at its positions. Cut parity and
three-connectivity force exactly two or four terminals
in \(A_1\). With two, each of \(A_1,B\) has two
terminals, so leaf-square switches within each block
produce the desired two paths.

With all four terminals in \(A_1\), \(s\) is a
nonterminal face-matching endpoint. Its mate cannot
lie in \(A_1\) by the separation assumption, and
cannot lie after \(A_1\) by the terminal barrier.
The only directly assigned special positions of
\(N\) are \(s,t\), so the mate lies outside \(N\)
to its left. The core chord \(HJ\) is unused by
\(C_W\), since \(N\) is not the root. Open
\(N\) outside, deleting the two old edges from
\(H\) into its first interior position and from
its last interior position into \(J\), then inserting
\(HJ\), in addition to deleting \(E\) and inserting
\(M\). The resulting four-terminal graph has a
central old arc containing \(s,A_1,t,A_2\) and a
connected outer complement closed by \(HJ\).
The face edge at \(s\) joins these two pieces.
Its leaf-square quotient is connected and supplies
the internal cover.

Now suppose \(s,t\) flank both children:
\[
                  N=(H,s,A_1,A_2,t,J),
        \qquad A_i=[L_i,R_i].                           \tag{3}
\]
Open them both inside:
\[
 F_{\rm ii}=
 (C_W-E-\{sL_1,R_1L_2,R_2t\})
                \cup M\cup\{L_1R_1,L_2R_2\}.          \tag{4}
\]
Again its only degree-one vertices are \(T\).
After restoring \(E\), its coarse pieces are the
two closed children \(A_1,A_2\) and the complementary
outer arc \(B\) through the root chord. Each piece is
connected by its old edges, so contract the three
pieces and retain their \(M\)-edges to obtain \(K\).
The component quotient of \(F_{\rm ii}\) by the
deleted leaf edges \(E\) has exactly the same
connectivity as \(K\). Each nonloop quotient edge has
the disjoint leaf-square switch of Note 458; when an
inserted child chord is itself a leaf-square chord,
that leaf edge is a loop and needs no switch. If
\(K\) is connected, a spanning forest rooted at the
two terminal paths absorbs every cycle, giving a
spanning two-path cover. If \(K\) is disconnected
but every component has terminals, each component
has exactly two terminals by degree parity and the
same switches absorb its cycles into one path.

Suppose a component of \(K\) has no terminal. An
isolated \(A_i\) would have only its two old boundary
edges leaving it in the parent, contrary to
three-connectivity. The same is true of a terminal-free
\(A_1\cup A_2\), since \(R_1L_2\) is an old edge
internal to that union. A zero-terminal component
\(B\cup A_1\) would put all four terminals in
\(A_2\). The special positions before \(A_2\)
inside \(W\) comprise complete two-special leaves,
the even child \(A_1\), and the single direct position
\(s\), so they number oddly. They contain no terminal,
send no \(M\)-edge into \(A_2\) by the component
assumption, and cannot send a face edge after \(A_2\)
by the terminal barrier. They cannot be perfectly
matched, a contradiction. Reflection excludes a
zero-terminal \(B\cup A_2\).

The only remaining zero-terminal component is \(B\)
alone; all four terminals then lie in \(A_1\cup A_2\)
and no face edge joins \(B\) to either child. The
direct positions \(s,t\) are nonterminals. They
cannot match each other: the face chord \(st\)
would span a child containing a terminal and violate
the barrier. Their face mates therefore lie outside
\(N\) in the outer complement, since they cannot
lie in either child and \(N\) has no further direct
special position. Open \(N\) outside as above. Its
central arc \(s,A_1,A_2,t\) and its outer complement
are joined by a direct-position face edge. The
leaf-square quotient is connected and gives a
spanning two-path cover. These cases exhaust (3).

In every case, choose the exterior pairing of Note 460
different from the internal pairing. Their union is
one Hamilton cycle containing \(p,q\). The lifting
criterion of
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives a Hamilton cycle of the child. \(\square\)

At the exact charge \(f\ge8,c=5f-8,(m,R)=(f,1)\),
the marked-binary profile in
[Note 647](647-two-structural-profiles-remain-at-the-chorded-ninety-six-vertex-boundary.md)
has two consecutive plain ancestors, hence is nonroot and is
closed by the theorem. The other profile, with two
marked unary nodes and one missing plain wrapper, is
closed in [Note 649](649-one-plain-parent-closes-two-marked-unary-chorded-openings.md).
Smaller charges and Barnette's conjecture remain open.
