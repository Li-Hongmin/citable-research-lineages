# Cube CEN/UV word fibres are polynomial

This note isolates the R2 counting statement for the cube construction.  It
does not use the inaccessible Kao--Chen paper and makes no literature claim.

Let \(W_k=\{\mathrm{CEN},\mathrm{UV}\}^k\), and let
\(\Gamma_k:W_k\to\mathcal G_{8+4k}\) send a word to its graph after the
root, the current successor-site marking, and all vertex labels are forgotten.

> **Theorem.**  For \(k\geq2\), every fibre of \(\Gamma_k\) has size at most
> \[
> 4(8+4k)_8.
> \]
> Consequently the image of \(\Gamma_k\) contains at least
> \[
> \left\lceil\frac{2^{k-2}}{(8+4k)_8}\right\rceil
> =2^{n/4-O(\log n)},\qquad n=8+4k,
> \]
> pairwise nonisomorphic graphs.

## Proof

Retain the labelled eight-vertex graph
\(R=Q-\{01,23\}\) pointwise.  The rooted two-step delay theorem of
[Note 011](011-rooted-two-step-delay-and-exponential-unlabelled-count.md)
says that two length-\(k\) words give the same pointwise-rooted type if and
only if their first \(k-2\) letters agree.  Thus every rooted type has exactly
four word preimages.

Fix an unrooted output graph \(H\) of order \(n=8+4k\).  Every rooted type
over \(H\) determines an injection of the eight labelled old vertices of
\(R\) into \(V(H)\).  Quotienting valid injections by \(\operatorname{Aut}H\)
can only decrease their number, so \(H\) supports at most \((n)_8\) rooted
types.  Since each of those types has four word preimages,
\[
|\Gamma_k^{-1}(H)|\leq4(n)_8.
\]
Dividing \(|W_k|=2^k\) by this fibre bound proves the displayed count.  This
argument neither assumes nor needs an intrinsically recognizable or unique
cube core.

By [Note 014](014-cube-cen-uv-words-have-global-h-plus-minus.md), every graph
in this image is Barnette and has global \(H^{+-}\).  Hence R2 outcome (a) is
proved; there is no exponential word collapse.

## Exact finite observation through depth twelve

The exploratory verifier
[`scratch/r2_pulse1_cube_cen_uv_fibres.py`](../scratch/r2_pulse1_cube_cen_uv_fibres.py)
constructs every word, checks cubicity, bipartiteness and planarity, and uses
pynauty's exact canonical certificate after forgetting all markings.  Its
stored output is
[`scratch/r2_pulse1_cube_cen_uv_fibres.json`](../scratch/r2_pulse1_cube_cen_uv_fibres.json).

\[
\begin{array}{c|c|c|c|c}
k&n&2^k&\#\text{ unrooted classes}&\text{fibre sizes}\ (\#\text{ classes})\\\hline
0&8&1&1&1(1)\\
1&12&2&1&2(1)\\
2&16&4&1&4(1)\\
3&20&8&2&4(2)\\
4&24&16&3&4(2),8(1)\\
5&28&32&6&4(4),8(2)\\
6&32&64&10&4(4),8(6)\\
7&36&128&20&4(8),8(12)\\
8&40&256&36&4(8),8(28)\\
9&44&512&72&4(16),8(56)\\
10&48&1024&136&4(16),8(120)\\
11&52&2048&272&4(32),8(240)\\
12&56&4096&528&4(32),8(496)
\end{array}
\]

The observed fibres are much smaller than the proved worst-case polynomial
bound, but the finite pattern is not used as a theorem.  Face-degree
sequences are not a separating invariant: at \(k=12\) there are only 38 such
sequences for 528 isomorphism classes, and one sequence contains 85 classes.

## Contribution and upgrade boundary

With R1 still externally undecided, the present result is at most a
**B-level construction theorem**: it gives a rigorous same-order exponential
family with global \(H^{+-}\), but only inside one fixed two-letter annular
grammar, and its novelty relative to Kao--Chen cannot yet be certified.  It is
not A- or S-level because it supplies no mechanism for a structurally broad
class of Barnette graphs.

The single mathematical increment most directly missing for A-level is a
uniform closure-and-counting theorem for a sharp, intrinsically defined
subclass strictly larger than the CEN/UV chains (for example, all newest-face
legal successor sites satisfying an explicit seed-signature condition), with
both global \(H^{+-}\) and subexponential word fibres.  The cheapest upgrade
observation is constant-size rather than an adjacent-order census: classify
the local isomorphism orbits of all legal successor sites meeting the newest
annulus, compute their six-role signed/joint transfer maps, and test whether a
common finite closed domain retains a peeling invariant.  Failure would give
a structural boundary; success would identify the precise larger grammar to
prove.

