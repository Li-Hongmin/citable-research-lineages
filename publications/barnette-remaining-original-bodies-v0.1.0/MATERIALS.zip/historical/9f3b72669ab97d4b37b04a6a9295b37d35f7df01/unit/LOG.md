# Barnette controller log

## 2026-09-10 — R1 pulse 1

Ran a full-text decision search for Kao--Chen 2005, Florek, and Schnieders
2025. Accessible full texts rule out containment by the cited Florek and
Schnieders results at the global ordered-edge-pair and same-order
nonisomorphic-count quantifiers. The Kao--Chen publisher record and metadata
were located, but the lawful full text requires authentication and no OA copy
was found. The precise theorem-level comparison boundary is recorded in
`advisor/REQUEST.md`; no novelty verdict is inferred from the abstract.

Repository-control caveat: this AIMath directory has no `AGENTS.md`, no git
metadata, no `ResearchLibrary`, and none of the four requested skill files was
present on the host. Consequently there was no lawful library-ingest target
and no repository in which to commit or push this pulse.

ROUTE=R1 PULSE=1 VERDICT=open

## 2026-09-11 — R1 pulse 2

Continued only at the Kao--Chen full-text comparison gate.  A fresh
title/DOI/Chinese-title/author-domain decision search found the publisher and
author records plus secondary citations, but no independently lawful complete
PDF or scan.  Therefore no theorem numbers, proof pages, figures, replacement
gadget, seed hypotheses, recursion quantifiers, joint ordered-edge-pair
property, or graph-enumeration statement can be verified.  In particular,
separate 1-edge fault Hamiltonicity and Hamiltonian laceability in the abstract
do not imply one joint containing/avoiding Hamilton cycle.

The exact external boundary is now frozen in `advisor/REQUEST.md`: obtain one
complete lawful scan of volume 33(1), pp. 11--19, with CiNii NCID `AN10510587`
and Iwate University's 33(1--3) holding as a concrete acquisition lead, then
audit all seven comparison quantities page by page.  The holding is not
mathematical evidence.  Containment remains UNDETERMINED, so neither GO nor
NOGO is issued.

Control caveat remains unchanged: this AIMath directory has no `AGENTS.md`, no
git metadata, no ResearchLibrary, and none of the four requested skill files
was present on the host.  Thus there was no lawful library-ingest target and no
repository in which to commit or push this pulse.

ROUTE=R1 PULSE=2 VERDICT=open

## 2026-09-12 — R2 pulse 1

Worked only on the cube CEN/UV word-to-unrooted-graph fibre.  Exact pynauty
canonicalization of every word through depth 12 gives class counts
`1,1,1,2,3,6,10,20,36,72,136,272,528`; at depth 12, 4096 words give 528
classes, with fibres of size 4 or 8.  Face-degree sequences are too coarse:
only 38 occur at depth 12 and one supports 85 canonical classes.  The finite
observation is stored under `scratch/` and is not used as a theorem.

Note 167 records the strict all-depth proof.  The rooted two-step delay
theorem makes each pointwise cube-rooted type receive exactly four words, and
an unrooted order-n graph supports at most `(n)_8` such types via injections of
the labelled old cube core.  Therefore every word fibre is at most `4(n)_8`,
and the image has at least `ceil(2^(k-2)/(n)_8) = 2^(n/4-O(log n))` pairwise
nonisomorphic global-H^{+-} Barnette graphs.  This proves R2 outcome (a); no
structural exponential collapse occurs.

Contribution verdict: at most B-level while R1 is unresolved and the theorem
remains confined to one fixed two-letter grammar.  The single missing A-level
increment is a uniform global-H^{+-} plus subexponential-fibre theorem for a
strictly larger intrinsic legal-successor subclass.  The cheapest upgrade
observation is a constant-size orbit/transfer classification of all legal
successor sites meeting the newest annulus, not an adjacent-order census.
This directory has no git metadata, so no commit was made.

ROUTE=R2 PULSE=1 VERDICT=proved
