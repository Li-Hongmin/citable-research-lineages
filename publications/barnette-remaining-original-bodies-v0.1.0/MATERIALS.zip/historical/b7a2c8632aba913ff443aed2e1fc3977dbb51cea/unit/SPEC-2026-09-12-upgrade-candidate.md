# DRAFT — Barnette structural-upgrade candidate — 2026-09-12

**Status: NOT FROZEN. NOT STARTED.**

This candidate authorizes no experiment, census, or proof search. The target is
fixed below, but the draft is not freeze-ready until the explicit-new-orbit
gate is closed.

## The certificate class \(\mathcal C_{4\mathrm A}\)

All embeddings are on the sphere: no face is designated as outside, and a
simultaneous mirror image is allowed. A *site* is an ordered tuple
\(s=(u,v,x,y)\) for vertex-disjoint cofacial edges \(uv,xy\), in cyclic facial
order and with the colour convention for a legal Barnette \(C_4\)-expansion.
Port order is certificate data, not extra data of the unrooted graph.

A finite spherical four-port decomposition certificate of depth \(k\) contains:

1. Embedded intermediate graphs \((G_i,s_i)\), \(0\le i\le k\), with
   \(G_0=Q\), the cube, and every \(s_i\) legal. A depth-zero certificate has
   only \((Q,s_0)\), and its unrooted capped graph is \(Q\). Thus the old kernel
   and zero-layer case are explicit.
2. For each \(0\le i<k\), an operation code \(o_i\). It deletes the virtual
   sealing edges \(u_iv_i,x_iy_i\), introduces exactly four fresh vertices
   \(a_i,b_i,c_i,d_i\), and introduces exactly
   \[
   u_ia_i,a_ib_i,b_iv_i,x_ic_i,c_id_i,d_iy_i,a_id_i,b_ic_i.
   \]
   The code also gives the ordered legal successor \(s_{i+1}\). No other
   vertex or edge is created, deleted, or reassigned in the layer.
3. A complete edge ledger. The kernel owns the final edges of \(Q-s_0\); layer
   \(i\) owns its four new vertices and precisely those of its eight born edges
   that survive in the final graph, except for the two final-site edges; every
   born edge subsequently used as a site is instead marked deleted at that
   later layer; and the terminal cap owns the two actual edges of \(s_k\).
   Earlier site edges are virtual seals only:
   restoring them on the inner side reconstructs \(G_i\), while replacing them
   by the displayed layer reconstructs \(G_{i+1}\). Every final vertex and edge
   is owned exactly once, so kernel, layers, and cap exhaust the whole graph.
4. A spherical nesting record for the punctured four-poles
   \(G_i-\{u_iv_i,x_iy_i\}\). Successive separating boundaries may meet at
   named ports but nowhere else. Thus a UV successor \((u_i,a_i,b_i,v_i)\) may
   share \(u_i,v_i\) with \((u_i,v_i,x_i,y_i)\); strict disjointness is not
   required. Equivalently, the operation sequence, ledger, port incidences,
   and spherical rotation systems form the preferred purely combinatorial
   four-port decomposition; curves merely realize that record.
5. At every forward step, and every inverse step removing the four vertices of
   the outermost layer and restoring its two virtual seals, checks certify that
   the reconstructed intermediate graph is finite, simple, cubic, bipartite,
   planar, and 3-connected, and that the relevant ordered site is cofacial and
   legal. These are verification conditions, not content hidden in “trace.”

The terminal cap is the explicit restoration/retention of the two edges of the
final marked site, after which the mark is forgotten; there is no unspecified
region beyond the last separator. Mirroring all rotation systems and
transporting port orders preserves certificates.

An abstract graph belongs to \(\mathcal C_{4\mathrm A}\) **if and only if** it
is isomorphic to the unrooted final graph of at least one such certificate.
The certificate, embedding, history, and port numbering are not graph data.

### Inclusion of the old family

For a cube CEN/UV descendant, use its construction history. Start at \(Q\) and
\((0,1,2,3)\); record the four new vertices and eight displayed edges at every
step. For CEN record successor \((b_i,c_i,d_i,a_i)\), representing
\((b_ic_i,d_ia_i)\); for UV record \((u_i,a_i,b_i,v_i)\), representing
\((u_ia_i,b_iv_i)\). Note 010 verifies legality. The history gives the ledger,
and Note 011 (2)--(5) gives the ordered four-pole nesting, including UV shared
ports. Retain the final site edges as cap. Reversal recovers the preceding
simple cubic bipartite plane 3-connected graphs. Hence
\[
\{G_w:w\in\{\mathrm{CEN},\mathrm{UV}\}^*\}/\cong
\subseteq\mathcal C_{4\mathrm A}.
\]

### Strictly larger unrooted-class gate

Strictness requires an explicit certificate with final unrooted graph \(H\)
and a proof
\[
H\not\cong G_w\quad\text{for every CEN/UV word }w
\text{ of depth }(|V(H)|-8)/4.
\]
An invariant separating \(H\) from every old output, or an analytic complete
classification at that depth, suffices. A new marked site, orbit, or history
that produces an old unrooted graph does not.

## Mathematical endpoint

The statement to decide is
\[
\tag{T}
\forall G\in\mathcal C_{4\mathrm A}\ \forall e\ne f\in E(G)\
\exists C\in\mathcal H(G): e\in C,\ f\notin C.
\]
Finite-state congruence is a Route 1 tool, not a substitute for (T).

Fix a finite state set \(S\); “finite” forbids an integer or field carrying
arbitrarily long information. A rooted input \((G,s;\mu)\) records the ordered
port, ordered edge pair, and only frozen finite birth/deletion/interface flags.
For each operation code \(o\), require
\[
\Phi_o(G,s;\mu)=(G^+,s^+;\mu^+),\qquad
\sigma(\Phi_o(G,s;\mu))=T_o(\sigma(G,s;\mu)),
\]
with \(\sigma:(G,s;\mu)\to S\) and fixed \(T_o:S\to S\). Input and output both
remain rooted. Separately prove that the final accepting predicate is
equivalent—not merely necessary—to existence of one Hamilton cycle jointly
containing the required edge and avoiding the forbidden edge.

## Explicit first-new-orbit freeze gate

**VERDICT=record complete.**  The following is the fixed third operation
record.  It closes this definition gate only; the SPEC remains **DRAFT / NOT
FROZEN / NOT STARTED** pending the requested final advisor decision.

Start with the cube
\[
01,12,23,30,45,56,67,74,04,15,26,37
\]
and expand \((0,1,2,3)\), naming the new vertices \((8,9,10,11)\).  The
resulting embedded representative \((G_1,s_1)\) has
\[
\begin{split}
E(G_1)=\{&03,04,08,12,15,19,26,2\,10,37,3\,11,45,47,56,67,\\
         &89,8\,11,9\,10,10\,11\},\qquad s_1=(0,3,11,8),
\end{split}
\]
and clockwise rotation system
\[
\begin{array}{c|cccccccccccc}
z&0&1&2&3&4&5&6&7&8&9&10&11\\ \hline
\rho_z&3,8,4&5,9,2&1,10,6&0,7,11&7,0,5&4,1,6&2,7,5&3,4,6&
9,0,11&10,1,8&2,9,11&8,3,10.
\end{array}
\]
Thus the expanded pair is \(03,11\,8\), in the facial order
\(0,3,11,8\).  With fresh vertices \((a,b,c,d)=(12,13,14,15)\), the eight
born edges are
\[
0\,12,12\,13,13\,3,11\,14,14\,15,15\,8,12\,15,13\,14,
\]
and the ordered successor of the third operation is
\[
s_2=(0,12,7,4),\qquad\text{i.e. the pair }(0\,12,74).
\]
Here \(s_2\) occurs in the facial order
\(0,12,13,3,7,4\).  Hence its two residual facial paths have odd lengths
three and one, and its initial endpoints \(0,7\) have the same bipartition
colour.  The same checks for \(s_1\) have residual lengths one and one.
Note 006 therefore applies at both steps.  Direct checks give no loops or
parallel edges, degree three at every vertex, a bipartition, the displayed
spherical embeddings, and vertex connectivity three for the cube, \(G_1\),
and the 16-vertex child \(G_2\).  These facts also follow from Note 006's
legal-expansion preservation statement.

The allowed (possibly nonfaithful) relabelling group is exactly
\[
\Gamma=((C_2\times C_2)\rtimes C_2)\times C_2^{\rm col}
       \times C_2^{\rm mir}.
\]
The first two factors independently reverse the two ordered pairs and swap
the pairs; \(C_2^{\rm col}\) globally exchanges the bipartition colours; and
\(C_2^{\rm mir}\) reverses every cyclic rotation.  After an action one may
renormalize to the convention that the two initial endpoints have the same
colour.  This includes all pair swaps, within-pair reversals, colour swaps,
and global reflections, including their compositions.

The birth-status multiset of the two successor edges is invariant under
\(\Gamma\).  For CEN it is \(\{\mathrm{born},\mathrm{born}\}\), since the
successor is \((bc,da)\); for UV it is again
\(\{\mathrm{born},\mathrm{born}\}\), since the successor is \((ua,bv)\).
For the displayed operation it is
\(\{\mathrm{born},\mathrm{retained}\}\), since \(0\,12\) is born in the
second layer while \(74\) is a retained cube edge.  Thus, by the direct
definition (2) of Note 010, this rooted operation lies in neither the CEN nor
the UV orbit, even under the full allowed relabelling group.

Finally, strictness is certified at the unrooted graph level, not inferred
from that orbit statement.  Expand \(s_2\) with new vertices
\((16,17,18,19)\), and take the terminal CEN site
\(s_3=(17,18,19,16)\), whose two edges are retained by the cap.  The
resulting 20-vertex graph \(H\) has edge set
\[
\begin{split}
\{&04,08,0\,16,12,15,19,26,2\,10,37,3\,11,3\,13,45,4\,19,56,67,7\,18,\\
  &89,8\,15,9\,10,10\,11,11\,14,12\,13,12\,15,12\,17,13\,14,14\,15,
    16\,17,16\,19,17\,18,18\,19\}.
\end{split}
\]
Its multiset of incident-face-length triples is
\[
12(4,6,6)+6(4,4,6)+2(6,6,6).
\]
Direct construction of all eight depth-three CEN/UV words gives only
\[
8(4,6,6)+8(4,4,6)+4(6,6,6)
\]
when the first letter is CEN, and
\[
8(4,6,6)+4(4,4,6)+4(4,4,8)+4(4,6,8)
\]
when it is UV.  A 3-connected planar graph has its spherical faces fixed up
to reflection, so this multiset is an unrooted graph invariant.  Therefore
\(H\not\cong G_w\) for every depth-three CEN/UV word \(w\), proving strict
unrooted inclusion.  The constant-size recomputation is
`scratch/r2_pulse4_fixed_successor_certificate.py`; it also prints the full
edge tables and rotations and ends with
`R2_PULSE4_FIXED_SUCCESSOR_CERTIFICATE_VERIFIED`.  It is a scratch checker,
not a census and not part of this SPEC.

## Routes and mechanical go/no-go

1. **Finite boundary congruence (first line).** GO requires a complete finite
   table plus proofs of coverage of every allowed real context, transition
   semantics, and equivalence of final acceptance to the joint witness. A real
   collision—same summary and operation code but different required output—
   NO-GOs that summary only, not (T).
2. **Existential inverse annulus.** The quantifier is
   \[
   \forall G\in\mathcal C_{4\mathrm A}\setminus\{Q\}\ \exists r\in
   \operatorname{Red}(G)
   \]
   such that \(r\) is a verified legal inverse, strictly reduces order, returns
   to the class, and supports reconstruction of (T). It need not be canonical
   or unique. One bad inverse choice or failed old-witness lift neither refutes
   this existential statement nor directly makes (T) NO-GO.
3. **Collision-triggered obstruction refinement.** Start only after a real
   Route 1 collision. First freeze permitted atomic additions (specified port
   partitions, joint-witness bits, birth/deletion flags) and an absolute state
   bound, or supply a uniform termination proof. GO requires rechecking the
   whole domain. Nonexistence of any finite summary requires, for every \(m\),
   \(m\) realizable contexts distinguished by compatible future operations and
   target outputs; growing finite tables or repairing one pair is insufficient.

Route 1 is first. Route 2 tests whole-class coverage; Route 3 is not an
independent exploratory route.

Failure in unrealized formal states is not graph-level NO-GO. Success on a
finite over-approximation is GO only with real-state coverage and semantic
correctness proofs. Bounded-order failure to find an example is not an
all-order decision.

## Scope and contribution level

Even repaired, \(\mathcal C_{4\mathrm A}\) is likely uniformly bounded
pathwidth: normalized layer bags \(S_i\cup I_i\cup S_{i+1}\) have at most
\(4+4+4=12\) vertices. This SPEC tests finite-interface and structural-extension
feasibility. Passing it must not directly be recorded as an A/S upgrade.

### Key increment still separating this from A/S

What remains is a uniform joint-witness reduction/coverage theorem on a
structural domain with substantively independent coverage meaning, not merely
more analyzable linear four-port histories. Since the class contains the old
CEN/UV family, it inherits the existing exponential lower bound. A new
subexponential fibre theorem is needed only to count genuinely new outputs or
improve the rate.

## Forbidden directions

- no adjacent-order census, experiment before explicit freeze/start, or attack
  on the general Barnette conjecture;
- no pursuit here of the empirical claim that old fibres are always 4 or 8;
- no inference from marginal witnesses to a joint witness;
- no inference from state congruence to acceptance of every state;
- no inference from failure of one local lift to failure of the complete
  witness family;
- no treatment of a new operation orbit as automatically a new unrooted class;
- no inference from constantly many inverse choices per layer to a
  subexponential history fibre; and
- no unrealized formal failure or bounded-order non-observation as a verdict on
  real graphs of all orders.
