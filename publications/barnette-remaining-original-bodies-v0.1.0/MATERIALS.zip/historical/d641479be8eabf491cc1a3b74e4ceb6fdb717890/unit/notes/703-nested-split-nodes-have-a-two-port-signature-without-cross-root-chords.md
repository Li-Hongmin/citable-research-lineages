# Nested split nodes have a two-port signature without cross-root chords

Use the parent, selected chorded two-root opening, leaf profile, and saturated plain-ancestor hypothesis of [Note 702](702-disjoint-split-nodes-have-four-port-signatures-without-cross-root-chords.md). Suppose the two split marked unary nodes lie in the same root \(W\) and are nested:
\[
 U_o=(H_o,s_o,A_o,t_o,J_o),\qquad
 U_i=(H_i,s_i,A_i,t_i,J_i),\qquad U_i\subset A_o .
\]
There is no face chord between the two ordinary roots.

**Nested two-port theorem.** The open old arc of \(W\), using its internal face matching and unused ordinary chords, has spanning two-path covers in at least two different pairings of its two boundary ends and its two external special attachments. Hence the parent has a Hamilton cycle through both site edges, and its legal expanded child is Hamiltonian. Together with Note 702, **every no-cross-root two-split placement in this selected chorded two-root profile is Hamiltonian**.

**Proof.** Write \(\ell,r\) for the old arc ends of \(W\) and \(a,b\) for its two special positions with edges leaving \(W\). That it has exactly two such positions follows from the even root cut and three-connectivity, as in Note 702. Let \(P\) be the open old arc, \(E\) the old edge in each complete two-special leaf, and \(M\) the internal face matching outside \(a,b\). Open both nodes inside:
\[
 F_{\rm ii}=
  \bigl(P-E-\{s_oL_o,R_ot_o,s_iL_i,R_it_i\}\bigr)
       \cup M\cup\{L_oR_o,L_iR_i\}.                    \tag{1}
\]
This graph has degree one exactly at \(\ell,r,a,b\); all other degrees are two. Restore \(E\) only for the component quotient. The immediate plain-parent squares of \(U_o,U_i\) connect the two flanks of \(B=W\setminus A_o\) and \(D=A_o\setminus A_i\), respectively. The inserted child chords close the appropriate inner arcs. The three coarse pieces are therefore \(B,D,A_i\), with \(\ell,r\in B\); they meet each other only through face-matching chords. Every needed square has unused chords and a disjoint support: the root arc is open, both marked nodes have two plain ancestors, and any complete-leaf square whose closing chord is inserted is a quotient loop.

Let \(K\) be the three-vertex graph on these pieces with edges induced by \(M\). If \(K\) is connected, the four-terminal square-switch argument of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) supplies two pairings. We treat disconnected \(K\) by which coarse piece is isolated. Cut parity of each even piece, or equivalently parity of path endpoints in (1), makes the number of \(a,b\) in every component of \(K\) even. Thus an isolated piece has zero or both special attachments.

**Inner child \(A_i\) isolated.** With neither \(a\) nor \(b\), its parent cut would consist only of \(s_iL_i,R_it_i\), contrary to three-connectivity. With both, \(s_i,t_i\) are nonterminals; their \(M\)-mates lie outside \(A_i\), cannot be each other by [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md), and therefore lie outside \(U_i\). The other two pieces must be joined in \(K\): otherwise \(D\) is an isolated zero-attachment piece, excluded below. Open \(U_i\) outside while keeping \(U_o\) inside:
\[
 F_{\rm io}=
  \bigl(P-E-\{s_oL_o,R_ot_o,H_is_i,t_iJ_i\}\bigr)
       \cup M\cup\{L_oR_o,H_iJ_i\}.                    \tag{2}
\]
Its central piece \(C_i=s_i,A_i,t_i\) meets the connected remainder \(D\cup B\) through one of those face edges. The outer flanks of \(U_i\) are joined by \(H_iJ_i\), and the flanks of \(B\) by \(U_o\)'s parent square. Thus the quotient of (2) is connected.

**Outer complement \(B\) isolated.** If \(B\) has both \(a,b\), then the even child \(A_o\) has no special edge leaving it and no face chord to \(B\); its only outgoing edges are \(s_oL_o,R_ot_o\), a forbidden two-edge cut. Hence \(a,b\in A_o\) and \(s_o,t_o\) are nonterminals. Their mates lie in \(B\), because \(B\) is isolated, and cannot be each other by Note 473; hence a mate lies outside \(U_o\). The other two pieces \(D,A_i\) are joined in \(K\), since an isolated zero-attachment \(A_i\) is impossible. Open \(U_o\) outside while keeping \(U_i\) inside. Its central piece \(s_o,A_o,t_o\) is connected by the \(D\)--\(A_i\) matching edge and \(U_i\)'s parent square; its outer complement is joined by the inserted \(H_oJ_o\). The identified face edge joins these pieces, so this opening has a connected quotient.

**Middle piece \(D\) isolated.** Its left flank contains \(s_i\) and complete two-special leaves; its right flank contains \(t_i\) and complete two-special leaves. Each flank has an odd number of special positions. If \(D\) has no external attachment, its internal matching must contain a chord joining the two flanks, spanning \(A_i\). Such a chord crosses any same-face external edge incident with \(A_i\), so \(a,b\) both lie in \(B\). The zero-attachment child \(A_i\) cannot be isolated, hence an \(M\)-edge joins \(A_i\) to \(B\). In (2), that edge joins \(C_i\) to \(B\); at least one of the nonterminal \(s_i,t_i\) has its mate in \(D\setminus\{s_i,t_i\}\), because \(D\) is isolated and Note 473 forbids pairing them. This joins \(C_i\) to the remaining \(D\) piece. The quotient is connected.

If \(D\) has both \(a,b\), then \(A_i\) and \(B\) are joined by an \(M\)-edge; otherwise the zero-attachment child \(A_i\) is isolated. When at least one of \(s_i,t_i\) is nonterminal, its mate lies in \(D\setminus\{s_i,t_i\}\), while the \(A_i\)--\(B\) edge joins the central piece of (2) to \(B\). Thus (2) again has connected quotient. The only other possibility is \(a=s_i,b=t_i\). But any face chord from \(A_i\) to \(B\) then crosses one of these two terminal edges: its endpoint in \(B\) lies outside \(U_i\), so the chord spans \(s_i\) or \(t_i\), and that terminal's mate lies outside the entire root \(W\). The four endpoints alternate on the common face. This contradicts planarity, so this last possibility does not occur.

These cases exhaust disconnected \(K\); three isolated pieces would include an isolated zero-attachment \(A_i\), or the excluded isolated \(D\) with an \(A_i\)--\(B\) edge required. A connected quotient in one of (1), (2), or the outer-\(U_o\) opening supplies two four-port pairings by Note 458's spanning-forest switch. The other root is all-leaf and has the same two-port property. The exterior four-path pairing of [Note 641](641-two-port-split-root-signatures-close-disconnected-chorded-roots.md) forms a single Hamilton cycle containing the site edges, in every target-span, side, or end placement. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the legal expanded child. \(\square\)

At \(c=5f-10,(m,R)=(f,2)\), the two-marked-unary charge profile has \(\delta=0\), so the ancestor hypothesis holds. Combining Notes 699–703, a hypothetical failure in the **two-root two-unary** profile must have two split direct pairs **and at least one cross-root face chord**. The single-root row, other selected openings, and Barnette's conjecture remain unresolved by this result. This proof and its upstream chain have not had independent external review.
