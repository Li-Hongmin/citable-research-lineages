# Barnette controller log

## 2026-09-10 — R1 pulse 1

Ran a full-text decision search for Kao--Chen 2005, Florek, and Schnieders
2025. Accessible full texts rule out containment by the cited Florek and
Schnieders results at the global ordered-edge-pair and same-order
nonisomorphic-count quantifiers. The Kao--Chen publisher record and metadata
were located, but the lawful full text requires authentication and no OA copy
was found. The precise theorem-level comparison boundary is recorded in
`advisor/REQUEST.md`; no novelty verdict is inferred from the abstract.

Repository-control caveat: this AIMath directory has no `AGENTS.md`, no git
metadata, no `ResearchLibrary`, and none of the four requested skill files was
present on the host. Consequently there was no lawful library-ingest target
and no repository in which to commit or push this pulse.

ROUTE=R1 PULSE=1 VERDICT=open

## 2026-09-11 — R1 pulse 2

Continued only at the Kao--Chen full-text comparison gate.  A fresh
title/DOI/Chinese-title/author-domain decision search found the publisher and
author records plus secondary citations, but no independently lawful complete
PDF or scan.  Therefore no theorem numbers, proof pages, figures, replacement
gadget, seed hypotheses, recursion quantifiers, joint ordered-edge-pair
property, or graph-enumeration statement can be verified.  In particular,
separate 1-edge fault Hamiltonicity and Hamiltonian laceability in the abstract
do not imply one joint containing/avoiding Hamilton cycle.

The exact external boundary is now frozen in `advisor/REQUEST.md`: obtain one
complete lawful scan of volume 33(1), pp. 11--19, with CiNii NCID `AN10510587`
and Iwate University's 33(1--3) holding as a concrete acquisition lead, then
audit all seven comparison quantities page by page.  The holding is not
mathematical evidence.  Containment remains UNDETERMINED, so neither GO nor
NOGO is issued.

Control caveat remains unchanged: this AIMath directory has no `AGENTS.md`, no
git metadata, no ResearchLibrary, and none of the four requested skill files
was present on the host.  Thus there was no lawful library-ingest target and no
repository in which to commit or push this pulse.

ROUTE=R1 PULSE=2 VERDICT=open

## 2026-09-12 — R2 pulse 1

Worked only on the cube CEN/UV word-to-unrooted-graph fibre.  Exact pynauty
canonicalization of every word through depth 12 gives class counts
`1,1,1,2,3,6,10,20,36,72,136,272,528`; at depth 12, 4096 words give 528
classes, with fibres of size 4 or 8.  Face-degree sequences are too coarse:
only 38 occur at depth 12 and one supports 85 canonical classes.  The finite
observation is stored under `scratch/` and is not used as a theorem.

Note 167 records the strict all-depth proof.  The rooted two-step delay
theorem makes each pointwise cube-rooted type receive exactly four words, and
an unrooted order-n graph supports at most `(n)_8` such types via injections of
the labelled old cube core.  Therefore every word fibre is at most `4(n)_8`,
and the image has at least `ceil(2^(k-2)/(n)_8) = 2^(n/4-O(log n))` pairwise
nonisomorphic global-H^{+-} Barnette graphs.  This proves R2 outcome (a); no
structural exponential collapse occurs.

Contribution verdict: at most B-level while R1 is unresolved and the theorem
remains confined to one fixed two-letter grammar.  The single missing A-level
increment is a uniform global-H^{+-} plus subexponential-fibre theorem for a
strictly larger intrinsic legal-successor subclass.  The cheapest upgrade
observation is a constant-size orbit/transfer classification of all legal
successor sites meeting the newest annulus, not an adjacent-order census.
This directory has no git metadata, so no commit was made.

ROUTE=R2 PULSE=1 VERDICT=proved

## 2026-09-12 — R2 pulse 2

Audited the exact upstream object used by Note 167.  Note 011 defines the
rooted type as the graph together with the old-core injection fixed pointwise,
and explicitly excludes both the raw history and the marked next successor
site.  Its ordered-boundary invariant and intrinsic peeling, now named
Theorem 011.1, prove the needed one-way implication
`rho_k(w)=rho_k(w') => w[1:k-2]=w'[1:k-2]`.  Extending the local isomorphism by
the identity on the eight old cube vertices, and restricting a cube-rooted
isomorphism to the four boundary vertices, identifies this with precisely the
cube-rooted object used in Note 167.  Thus every rooted word fibre is at most
four; the unused converse gives the stronger exact-four statement.

Note 167 now states the dependency by theorem number, equation range, object,
and direction, and writes the unrooting count exactly as `Aut(H)\I_H`, bounded
by `(n)_8`.  It also records the complete Note 011 text as a required
attachment in the next independent R2 verification package.  The counting
chain is therefore closed at the previously uncertified interface.

Added the scope limitation `pw(G_w) <= 7`: the initial cube is one bag, and
each later bag consists of the current four endpoints plus four new vertices.
All final edges occur in an introduction bag, while successor rules use only
the current endpoints and new vertices, so a vertex never returns after
leaving the active port.  Hence bag occurrences are intervals.  This bounded
pathwidth explains why the exponential family is not yet a broad structural
Barnette class.

No experiment was started.  A non-frozen, not-started structural-upgrade
candidate specification was drafted with an intrinsic nested four-port
annular class, at most three routes, mechanical go/no-go criteria, and the
required forbidden directions.  R1 remains untouched pending the external
library scan.  This directory has no git metadata, so no commit was made.

ROUTE=R2 PULSE=2 VERDICT=proved
UPGRADE_SPEC_DRAFT=SPEC-2026-09-12-upgrade-candidate.md
