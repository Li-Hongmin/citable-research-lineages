# Cube CEN/UV word fibres are polynomial

This note isolates the R2 counting statement for the cube construction.  It
does not use the inaccessible Kao--Chen paper and makes no literature claim.

Let \(W_k=\{\mathrm{CEN},\mathrm{UV}\}^k\), and let
\(\Gamma_k:W_k\to\mathcal G_{8+4k}\) send a word to its graph after the
root, the current successor-site marking, and all vertex labels are forgotten.

> **Theorem.**  For \(k\geq2\), every fibre of \(\Gamma_k\) has size at most
> \[
> 4(8+4k)_8.
> \]
> Consequently the image of \(\Gamma_k\) contains at least
> \[
> \left\lceil\frac{2^{k-2}}{(8+4k)_8}\right\rceil
> =2^{n/4-O(\log n)},\qquad n=8+4k,
> \]
> pairwise nonisomorphic graphs.

## Proof

Retain the labelled eight-vertex graph
\(R=Q-\{01,23\}\) pointwise.  For \(w\in W_k\), define
\[
\rho_k(w)=[G_w,\iota_w],
\]
where \(\iota_w:V(R)\hookrightarrow V(G_w)\) labels the eight old cube
vertices pointwise.  This object retains neither the current successor-site
marking, labels on later vertices, nor the construction history.

Apply [Theorem 011.1, equations (5) and (11)--(15), and the rooted-object definition following (17)](011-rooted-two-step-delay-and-exponential-unlabelled-count.md).  Its local
statement fixes the ordered four-pole boundary pointwise.  After attachment to
the cube core, extend each local isomorphism by the identity on all eight old
vertices.  Conversely, an isomorphism fixing those eight vertices fixes the
four boundary vertices, so the intrinsic peeling of Theorem 011.1 applies.
Thus its rooted type is exactly \(\rho_k\), not a successor-marked refinement,
and the direction needed here is
\[
\rho_k(w)=\rho_k(w')\quad\Longrightarrow\quad
w_{1:k-2}=w'_{1:k-2}.                                      \tag{1}
\]
Consequently every \(\rho_k\)-fibre has size at most four.  The converse in
Theorem 011.1 gives equality, but that stronger fact is not used.

Fix an unrooted output graph \(H\) of order \(n=8+4k\).  Every rooted type
over \(H\) determines an injection of the eight labelled old vertices of
\(R\) into \(V(H)\).  Let \(I_H\) be the set of all such injections actually
realised by the construction.  Two realised injections determine the same
pointwise-rooted type precisely when an automorphism of \(H\) sends one to the
other.  Hence these rooted types are exactly
\(\operatorname{Aut}(H)\backslash I_H\), and
\[
|\operatorname{Aut}(H)\backslash I_H|\le |I_H|\le(n)_8.
\]
The action need not be free, and the cube core need not be intrinsically
recognisable or unique.  Combining this with the one-way implication (1),
\[
|\Gamma_k^{-1}(H)|\leq4(n)_8.
\]
Dividing \(|W_k|=2^k\) by this fibre bound proves the displayed count.  This
argument neither assumes nor needs an intrinsically recognizable or unique
cube core.

By [Note 014](014-cube-cen-uv-words-have-global-h-plus-minus.md), every graph
in this image is Barnette and has global \(H^{+-}\).  Hence R2 outcome (a) is
proved; there is no exponential word collapse.

## Scope limitation: uniformly bounded pathwidth

Every graph in this family has pathwidth at most seven.  Take the eight
vertices of the initial cube as the first bag.  At expansion step \(j\), take
as the next bag the four endpoints of the current site together with the four
vertices introduced at that step.  Each bag has at most eight vertices.

This is a path decomposition of the final graph.  Every retained cube edge is
in the initial bag.  Every other retained edge is either internal to a new
four-vertex gadget or joins a current endpoint to a new vertex, and hence lies
in the bag of the step at which it is introduced.  An edge later deleted by an
expansion is absent from the final graph and needs no covering bag.  Under both
CEN and UV successor rules, the next four endpoints are selected only from the
current endpoints and the four new vertices.  Thus a vertex occurs in a
consecutive run of bags while it remains an active endpoint; once it leaves
the active port it can never reappear.  The vertex-interval condition follows,
so \(\operatorname{pw}(G_w)\le8-1=7\).

Accordingly, exponentially many pairwise nonisomorphic outputs do not by
themselves constitute a structurally broad Barnette subclass: the entire
grammar remains inside one uniformly bounded-pathwidth stratum.

## R2 independent-verification package

The next advisor request must attach this note together with the complete text
of Note 011, rather than cite its conclusion alone.  The dependency to audit
is specifically Note 011's ordered-boundary grammar (equations (2)--(5)),
letter invariant and intrinsic peeling (equations (6)--(13)), Theorem 011.1
and equations (14)--(15), and the rooted-object definition following equation
(17), which explicitly excludes the raw history and marked next site.  No
claim about the observed exact fibre sizes 4 or 8 belongs to this package.

## Exact finite observation through depth twelve

The exploratory verifier
[`scratch/r2_pulse1_cube_cen_uv_fibres.py`](../scratch/r2_pulse1_cube_cen_uv_fibres.py)
constructs every word, checks cubicity, bipartiteness and planarity, and uses
pynauty's exact canonical certificate after forgetting all markings.  Its
stored output is
[`scratch/r2_pulse1_cube_cen_uv_fibres.json`](../scratch/r2_pulse1_cube_cen_uv_fibres.json).

\[
\begin{array}{c|c|c|c|c}
k&n&2^k&\#\text{ unrooted classes}&\text{fibre sizes}\ (\#\text{ classes})\\\hline
0&8&1&1&1(1)\\
1&12&2&1&2(1)\\
2&16&4&1&4(1)\\
3&20&8&2&4(2)\\
4&24&16&3&4(2),8(1)\\
5&28&32&6&4(4),8(2)\\
6&32&64&10&4(4),8(6)\\
7&36&128&20&4(8),8(12)\\
8&40&256&36&4(8),8(28)\\
9&44&512&72&4(16),8(56)\\
10&48&1024&136&4(16),8(120)\\
11&52&2048&272&4(32),8(240)\\
12&56&4096&528&4(32),8(496)
\end{array}
\]

The observed fibres are much smaller than the proved worst-case polynomial
bound, but the finite pattern is not used as a theorem.  Face-degree
sequences are not a separating invariant: at \(k=12\) there are only 38 such
sequences for 528 isomorphism classes, and one sequence contains 85 classes.

## Contribution and upgrade boundary

With R1 still externally undecided, the present result is at most a
**B-level construction theorem**: it gives a rigorous same-order exponential
family with global \(H^{+-}\), but only inside one fixed two-letter annular
grammar, and its novelty relative to Kao--Chen cannot yet be certified.  It is
not A- or S-level because it supplies no mechanism for a structurally broad
class of Barnette graphs.

The single mathematical increment most directly missing for A-level is a
uniform closure-and-counting theorem for a sharp, intrinsically defined
subclass strictly larger than the CEN/UV chains (for example, all newest-face
legal successor sites satisfying an explicit seed-signature condition), with
both global \(H^{+-}\) and subexponential word fibres.  The cheapest upgrade
observation is constant-size rather than an adjacent-order census: classify
the local isomorphism orbits of all legal successor sites meeting the newest
annulus, compute their six-role signed/joint transfer maps, and test whether a
common finite closed domain retains a peeling invariant.  Failure would give
a structural boundary; success would identify the precise larger grammar to
prove.
