# Round 7 independent review: protected carrier and leaf absorption

## Verdict and scope

**The supplied configurations admit a uniform marked Hamilton construction through a protected carrier cycle cover.** The valid operations are an inverse square on two distinct cycles and a fat-leaf hexagon exchange on three distinct cycles. The exceptional unanchored loop in the new configuration is classified exactly and can be absorbed before ordinary squares are used.

This is a fresh, same-model, bounded review based on the supplied graph/interface description and the parent's clarification of the remaining matching partners. I did not read prior packets, search files or literature, use Git, enumerate graphs, run a finite census, or recompute prior experiments. Same-model fresh context provides an independent derivation, not independence of model family. This result concerns the specified structural interface; it is neither a proof of the unrestricted Barnette conjecture nor a claim of novelty.

The graph is finite, simple, cubic, bipartite and plane. Its specified Hamilton cycle has the order

`w0, td, W1, tc, z1, z2, tb, W2, ta, w*, alpha, a, b, c, d, beta, w0`.

The distinguished actual-face matching edges are `w0-u`, `r1-z1`, `z2-r2`, `v-w*`, `alpha-beta`. Other actual-face matching edges are arbitrary fixed noncrossing partners of the remaining slots. The opposite-face trap edges are `td-d`, `tc-c`, `tb-b`, `ta-a`. The ordinary opposite-face matching is laminar inside the two roots. Each root has one whole fat leaf; all other leaves are complete `(h,s,t,j)` leaves with ordinary edge `h-j`. No nonleaf has direct special slots. All leaf supports are disjoint.

## The two absorption operations

For a complete leaf, the selected edges are initially `h-j` and `s-t`. Its inverse-square exchange is

`{h-j, s-t} -> {h-s, t-j}`.

If its two removed edges lie on distinct cycles of a spanning 2-factor, deleting them opens two paths and the new edges join those paths into one cycle. Every vertex still has degree two. The operation can therefore absorb a loop into the carrier whenever `h-j` is on the carrier and `s-t` is on that loop.

For a fat leaf `(h,p1,p2,p3,p4,j)`, the full split selects

`h-j, e1=p1-p2, e2=p3-p4`.

Its inverse-hexagon exchange is

`{h-j, e1, e2} -> {h-p1, p2-p3, p4-j}`.

When the three removed edges lie on **three distinct cycles**, the replacement links the three opened paths cyclically and produces one cycle. These are existing graph edges. The exchange preserves degree two and touches only that fat leaf's six vertices.

Neither lemma asserts anything about cutting two or three edges on the same cycle. Such an assertion is unnecessary here and would require an additional connectivity analysis.

## Independent degree and backbone construction

Inside a root, replace each complete leaf's interior C-path `h,s,t,j` by its ordinary chord `h-j`; replace a fully split fat leaf's interior by its ordinary chord as well. Retain the C-connectors between the leaf blocks and through nonleaf ordinary endpoints. Omit nonleaf ordinary chords. The result is a single skeleton path through all ordinary endpoints of that root. This construction uses the complete-leaf and no-direct-special assumptions, rather than an unproved root Hamilton interface.

For the first root, attach `td` and `tc` to this skeleton and close it through

`tc-c-d-td`.

This gives the ordinary cycle `B1`. It contains every first-root normal leaf chord and the first fat chord `h1-j1`.

For the second root, initially close the analogous skeleton through

`ta-a-b-tb`.

Call this cycle `Q2`. In the new configuration the second fat leaf is `(h2,r2,q2,q3,v,j2)`. Delete its chord `h2-j2` from `Q2` and add `h2-r2` and `j2-v`. This produces a single ordinary backbone path `B2` with endpoints `r2,v`. All second-root normal leaf chords remain on this path. The selected middle pair is `Iq=q2-q3`.

The remaining slot subgraph `T` selects all normal old pairs `s-t`, both first-fat pairs `e1,e2`, the second-fat middle pair `Iq`, and every nondistinguished actual-face matching edge. Its only degree-one vertices are `u,r1`, so it consists of one `u` to `r1` path `S` and cycles. This endpoint statement does not prescribe a direction along any path.

Close `S` and `B2` with the distinguished outside frame to form the protected carrier

`H0 = w0-u ... r1-z1-z2-r2 ... v-w*-alpha-beta-w0`.

At this point the selected graph is a spanning 2-factor consisting of `H0`, `B1`, and the cycles of `T`.

The degree accounting is exhaustive: every normal or fully split fat slot uses one old pair and its actual-face matching edge; `r2,v` use their outer rails and distinguished matching edges; a leaf endpoint uses its ordinary chord plus its exterior connector, except that the second fat endpoints use their exterior connectors plus outer rails; nonleaf ordinary endpoints use both C-neighbours; each trap endpoint uses its root connector plus its trap; `a,b` use `a-b` and their traps, and `c,d` use `c-d` and their traps; the remaining six frame vertices use the frame edges displayed above. The ordinary matching edges not selected at nonleaves cause no degree-three vertices.

## Exact unsupported-loop classification in the new configuration

A `T` loop has normal square support if it contains at least one normal old pair `s-t`. An unsupported loop consequently uses only the three old pairs `e1,e2,Iq`, alternating with actual-face matching edges.

One old pair cannot form a loop: its actual-face partner edge would duplicate the old C-edge, contradicting simplicity.

Two first-fat pairs alone cannot form a loop. On the ordered vertices `p1,p2,p3,p4`, noncrossing perfect matching allows only `(p1p2,p3p4)` or `(p1p4,p2p3)`. Each choice contains an actual-face edge duplicating a C-edge.

All three pairs cannot form a loop. On the ordered six vertices

`p1,p2,p3,p4,q2,q3`,

a noncrossing perfect matching pairs `p1` with either `p2`, `p4`, or `q3`. The first choice duplicates `p1-p2`. The second forces `p2-p3`. In the last choice the interior four vertices force either `p2-p3` or `p3-p4`. Every possibility duplicates a C-edge. This argument uses planarity and simplicity, and needs no extra bipartite parity inference.

Thus every unsupported loop is exactly a four-cycle using **one** of `e1,e2` and `Iq`. Its matching edges are the nested cross-root connections between those two pairs, provided they obey the graph's bipartite colours. There can be at most one such loop because the pair `Iq` is unique. This is a classification of any occurring unsupported loop, not an assertion that every such matching pattern extends to an admissible whole graph.

Let the unsupported loop be `Z`, using `e_i`. The other first-fat pair `e_other` necessarily lies in a different `T` component. Hence the first-fat edges `h1-j1,e_i,e_other` lie on three distinct global cycles: `B1`, `Z`, and either `H0` or another `T` loop. The inverse hexagon absorbs all three into one cycle. It must be performed before ordinary squares that could identify these components.

## Completion for the new minimal endpoint arrangement

Here `u` is the first slot of the complete leaf `(hL,u,s,jL)` before the whole first fat leaf, and `r1` is the last slot of `(hR,t,r1,jR)` after it. In particular the old edge `u-s` is on `S`, hence on `H0`; its ordinary leaf chord `hL-jL` is on `B1`.

First absorb the unsupported loop with the certified hexagon if it exists. If the resulting `B1` component already contains `H0`, continue directly. Otherwise `hL-jL` is still on that component and `u-s` is still on `H0`. Their inverse square joins the two distinct cycles.

Now every remaining loop of `T` has a normal old pair. Its corresponding normal chord lies on the carrier, whether the leaf belongs to the first or second root. Choose one such square per remaining loop and absorb that loop. Each exchange leaves all unused leaf connectors selected; disjoint supports ensure that a later square's local edges remain available. Finiteness gives a single spanning cycle. All five distinguished actual-face edges and all four traps remain selected throughout.

This establishes a marked Hamilton interface for the genuinely new placement with both physical first-root terminals outside the fat leaf.

## Adjacent-terminal fat interfaces

The same carrier-and-absorption lemma covers a whole fat leaf whose terminal pair is `(p1,p2)` or `(p3,p4)`. Full split gives a short terminal path equal to that old pair. The other old pair lies inside the actual-face interval bounded by `w0-u` or `r1-z1`, respectively. Noncrossing matching edges cannot leave that interval, and disjoint complete supports prevent an old normal pair from crossing its boundary. The nonterminal pair therefore lies on a root-local `T` loop. Simplicity excludes a loop consisting of that pair alone, so the loop has normal support.

If both roots have adjacent terminal pairs and are fully split, there are ordinary cycles `B1,B2` and short terminal paths `S1,S2`. Closing the two short paths by the same outside frame gives `H0`. The nonterminal-pair loops `C1,C2` are confined to disjoint protected intervals, so they are distinct. In the first root, the fat chord, terminal pair and nonterminal pair lie on `B1,H0,C1`; its hexagon merges these three. In the second root they still lie on `B2`, the enlarged carrier, and `C2`; its hexagon merges these three. Every remaining loop has normal support and is absorbed by an inverse square.

If only the first root has an adjacent terminal pair and the second has the outer-terminal partial split above, the same first-root hexagon uses `B1,H0,C1`, then the normal square absorption completes the construction. The root-local interval excludes an unsupported loop linking that first-root nonterminal pair to the second-root middle pair.

## Method boundary

The proof requires an explicit spanning cycle-cover certificate: the protected outside carrier, the ordinary root cycle(s), complete disjoint square supports, and a fat exchange whose removed edges are on three distinct cycles. The supplied arrangements provide those certificates.

Square absorption alone can stall at the classified unsupported four-cycle. Its recovery is the early first-fat hexagon; normal support cannot be silently inferred for that loop. Conversely, an arbitrary fat exchange after prior merges has no guarantee if two removed edges have entered the same cycle. The validated ordering is: assemble the carrier, absorb the exceptional unsupported loop if present, connect the first ordinary cycle through the marked normal leaf if still necessary (or through the adjacent-terminal hexagon), then absorb supported loops.

The bounded task is complete at this method boundary. No unsupported-cycle or anchor obstruction remains for the specified configurations. Broader arrangements lacking these component certificates are outside this review's conclusion.


## Final bounded strengthening: the new target has no unsupported loop

This strengthens the earlier worst-case classification and **supersedes its allowance of a four-cycle for the exact new target**. The conditional hexagon recovery remains valid as a general component-certificate statement, but its exceptional-loop branch is unnecessary for the supplied arrangement.

The distinguished actual-face chords separate the prefix before `u`, the suffix after `r1`, the second-root prefix before `r2`, and its suffix after `v`. Matching edges cannot cross these barriers. After excluding their endpoints and the slots inside those separated intervals, the remaining central actual-face endpoints have order

`s, (2k normal slots), p1,p2,p3,p4, (2l normal slots), t, q2,q3`.

Here the complete left terminal leaf contributes exactly `s`, the complete right terminal leaf exactly `t`, the whole first fat leaf contributes its four slots, and the second outer-terminal fat leaf contributes exactly `q2,q3`. Completeness and absence of nonleaf direct specials make every other contribution an even number of normal slots. Ordinary opposite-face endpoints are not endpoints of this actual-face matching and do not enter these ranks.

Number these remaining central endpoints from one. Then `p1,p3,q3` have even ranks and `p2,p4,q2` have odd ranks. In a noncrossing perfect matching of the remaining central set, each edge joins opposite rank parities: the endpoints strictly inside that edge must be paired internally, so their number is even. This is a matching-endpoint parity argument; it does not rely on parity of raw C vertex labels.

The only previously possible unsupported loop, using `e1` and `Iq`, would require the nested matching edges `p1-q3,p2-q2`. Both join equal rank parities. The alternative using `e2` requires `p3-q3,p4-q2`, with the same failure. Both are impossible. Consequently **every T loop in the new target contains a normal old pair**.

The final target-specific construction is therefore shorter: build the protected carrier and `B1`; use the marked-left inverse square on `hL-jL` and `u-s` to merge `B1` into the carrier; absorb every remaining T loop through a normal square. The adjacent-terminal fat arrangements still use the already certified three-cycle hexagon absorption. No new graph search or census is involved.

## Hand audit of the supplied 42-vertex nonempty certificate

This is one explicitly supplied certificate, checked symbolically by endpoint order. It is not an enumeration or minimality claim. Take `C=(0,1,...,41,0)` and the following complement perfect matching.

Actual-face edges:

`(0,5), (20,25), (26,29), (32,35), (36,41), (6,11), (12,31), (13,30), (14,19)`.

Opposite-face trap edges:

`(1,40), (24,39), (27,38), (34,37)`.

Ordinary opposite-face edges:

`(2,23), (3,8), (4,7), (9,16), (10,15), (17,22), (18,21), (28,33)`.

The 21 pairs use each of the 42 vertices once. Every pair has odd endpoint difference, and none duplicates a C-edge. Thus `C` plus the matching is simple, cubic and bipartite. Each page is noncrossing: the actual-face outer pairs are disjoint, with `(12,31)` containing `(13,30)`, and `(13,30)` containing the three disjoint intervals `(14,19),(20,25),(26,29)`; the ordinary first root is `(2,23)` with the three stated unary children, and the remaining opposite-face intervals nest inside `(1,40)` as supplied. The two-page embedding is plane.

All 20 proposed interlace-tree edges have alternating endpoints. Their hand checks are:

`1<36<40<41; 24<36<39<41; 27<36<38<41; 34<36<37<41;`

`0<1<5<40; 20<24<25<39; 26<27<29<38; 32<34<35<37;`

`0<2<5<23; 0<3<5<8; 0<4<5<7; 3<6<8<11;`

`6<9<11<16; 6<10<11<15; 9<14<16<19;`

`14<17<19<22; 14<18<19<21; 12<24<31<39; 13<24<30<39; 26<28<29<33`.

Starting at `(36,41)`, these edges successively attach the four traps, the four distinguished outer matching edges, the first-root ordinary nodes and their connecting actual-face edges, the two cross-root matching edges, and the second root. All 21 matching chords are connected by these 20 edges.

Connected chord interlace excludes a two-edge cut: such a cut in a graph containing C must consist of two C-edges, delimit a nonempty C-interval, and have no matching edge crossing the interval boundary. Matching chords entirely inside that interval cannot interlace matching chords entirely outside; both sides have matching chords, contradicting connected interlace. C excludes bridges. The graph is therefore three-edge-connected. In a cubic graph this implies three-vertex-connectivity: a two-vertex separator would have exactly two components, three attachments each, and no edge between the separator vertices; the attachment distributions `(1,2)` and `(2,1)` give a two-edge cut after adding the appropriate separator vertex to one component. A one-vertex separator is likewise incompatible with three-edge-connectivity and degree three. Thus this is an actual nonempty Barnette-class instance of the specified interface.

The actual-face boundary is exactly

`(0,5,6,11,12,31,32,35,36,41,0)`.

Its edges alternate the outermost page chords with the intervening C-connectors; no other actual-face chord enters that region. The selected boundary arc `(35,36,41,0)` and the trapped hexagon `36,...,41` are consistent with the specification.

For this instance,

`T stem = (5,6,11,12,31,30,13,14,19,20)`

and there are no T loops. The first ordinary cycle has 18 vertices:

`(1,2,3,4,7,8,9,10,15,16,17,18,21,22,23,24,39,40,1)`.

The second outer-terminal backbone path has eight vertices:

`(29,28,27,38,37,34,33,32)`.

The carrier has these ten stem vertices, eight backbone vertices, and the six outside vertices `0,25,26,35,36,41`, for 24 vertices. The disjoint 18- and 24-vertex cycles cover all 42 vertices. The marked-left square deletes `(4,7),(5,6)` and inserts `(4,5),(6,7)`, merging these two cycles into a Hamilton cycle. This supplies a hand-verified realizability certificate without a finite census.

## Sharp local guard for a same-cycle square

The distinct-cycle guard cannot be omitted. Take the selected eight-cycle

`F=(h,j,a,b,t,s,c,d,h)`

and ambient extra edges `h-s,t-j`. Use bipartite colour classes `{h,a,t,c}` and `{j,b,s,d}`. All selected and extra edges join opposite classes and are distinct. The inverse square deleting `h-j,s-t` and adding `h-s,t-j` produces two four-cycles:

`(h,s,c,d,h)` and `(j,a,b,t,j)`.

This is a purely local simple bipartite cycle-cover example, not a counterexample to the full supplied interface or to Barnette's conjecture. Eight vertices are the minimum for this particular failure mode: a simple bipartite 2-factor splitting into two cycles needs at least four vertices in each cycle. No ambient cubic completion or full-graph counterexample is needed for this guard.

The final verdict remains affirmative for the supplied arrangements, and is strengthened for the new minimal endpoint target: ordinary squares suffice after the protected carrier is formed.


## Final formal-text consistency audit and closure

I read only the newly supplied formal text `barnette-round7-protected-carrier-absorption.md` for this final consistency check. No graphs were generated, no searches or recomputations were run, and no formal-source edits were made.

The formal text agrees with the verified argument on all requested points:

- The four-slot and six-slot unsupported-cycle exclusions are valid. The central matching-endpoint ranks exclude both residual cross-root four-cycle patterns in the exact straddling allocation.
- In adjacent allocations, peripheral confinement gives distinct root-local nonterminal loops. Each successive fat exchange cuts one edge on each of three currently distinct cycles; the second certificate survives the first exchange.
- The initial factor contains every actual-face matching edge and all four traps. Square and fat exchanges remove only ordinary opposite-page chords and old-C pairs, preserving that whole protected set.
- The displayed 42-vertex Hamilton cycle visits every label exactly once before returning to its start and uses listed matching or C edges throughout. It contains all nine actual-face matching edges and all four traps.
- The hand interlace tree connects all 21 matching chords. Matching-closed C intervals would disconnect it, excluding two-edge cuts; the cubic attachment argument then excludes one- and two-vertex separators. The common-face and trapped-hexagon claims are consistent with the two-page embedding.
- The eight-vertex same-cycle guard has exactly the two asserted four-cycle outputs. Its minimality concerns that local bipartite splitting witness, and the text correctly avoids presenting it as a Barnette counterexample.

There is one optional wording clarification, with no effect on the verdict: the six-slot ear argument should explicitly say “a consecutive pair in the displayed linear order.” The usual noncrossing matching ear fact supplies such a linear consecutive pair. If “adjacent” were instead read cyclically, the additional wraparound pair `q3-p1` would not duplicate an old-C edge. The subsequent argument is correct under the displayed linear ordering.

No substantive gap, omitted component guard, or unverified broader claim was found in the supplied formal text. The claimed allocations are internally certified, and the stated stopping boundary is appropriate. This bounded review is closed; unresolved different-source validation, novelty and priority questions remain outside its conclusion.
