# Attachment barriers and two adjacent-terminal four-special leaves

2026-10-03. Fourth bounded round; separate private candidate. This changes no earlier packet or source-unit note. Same-model fresh-context review is not different-source external validation. No priority or general Barnette-conjecture claim.

**Result.** In the precise two-root single-hexagon model below, if each root's two terminals lie in its unique four-special leaf, only three placements per leaf survive the attachment barriers. Exactly one outer-terminal placement together with one adjacent-terminal placement is impossible. If both roots have adjacent terminal pairs, every realized model has a Hamilton cycle containing both sites. The remaining two outer-terminal placements are the explicitly conditional family treated in round three. None of this derives the leaf profile from two roots, B order or m=f.

## Exact model and position classification

Let G be a finite simple three-connected cubic bipartite plane graph with Hamilton circle C in the order

\[
(w_0,t_d,W_1,t_c,z_1,z_2,t_b,W_2,t_a,w_*,\alpha,a,b,c,d,\beta,w_0).
\]

All displayed vertices are distinct. Each W_i is a consecutive nonempty word from L_i to R_i. The two Jordan disks of C are the face and opposite pages. M=E(G)\E(C) is a perfect matching; its chords on either page have nonalternating endpoints. Require the **actual** face-page edges w_0u,vw_*,r_1z_1,z_2r_2,alpha-beta, and opposite-page trap edges t_dd,t_cc,t_bb,t_aa. The marked sites are w_0u and vw_*.

Every other opposite-page matching edge is an ordinary chord inside W_1 or W_2. These form laminar interval forests with exactly one root [L_i,R_i] per word, including the root chord L_iR_i. Every other face-page endpoint is an assigned special in those root intervals. Assignment is to the innermost containing ordinary interval. There are no other vertices or matching endpoints outside this decomposition.

Each root has exactly one exceptional leaf whose **entire** old-C word is (h_i,p_{i1},p_{i2},p_{i3},p_{i4},j_i), with ordinary chord h_ij_i. The terminals u,r_1 lie in the first exceptional leaf, and r_2,v lie in the second. All other assigned specials belong to complete two-special leaves with entire old word (h,s,t,j) and chord hj. All other ordinary nodes have no directly assigned specials, and leaf supports are vertex-disjoint. These are additional profile assumptions. The theorem is conditional on an actual realization; it does not promise realizability of arbitrary forests or depths.

First u precedes r_1 on W_1. Otherwise the two face chords w_0u and r_1z_1 would alternate. Likewise r_2 precedes v. If u=p_{1i} and r_1=p_{1k}, the barrier w_0u confines all unoccupied face matching endpoints before u to that peripheral interval. Their number is i-1 plus an even number from complete two-special leaves. It must be even. Similarly the r_1z_1 barrier confines the endpoints after r_1, whose number is 4-k plus an even number. Hence i is odd, k is even, and i<k. The same proof works in the second root. The only candidate positions, relative to the old leaf order, are

\[
P=(1,2),\qquad A=(1,4),\qquad S=(3,4).
\]

Here P and S are adjacent-terminal positions, and A is the outer-terminal position.

The four disjoint peripheral intervals (w_0,u),(r_1,z_1),(z_2,r_2),(v,w_*) are closed under all their unoccupied face matching endpoints. The only unoccupied endpoints in the complementary central region are the specials strictly between u,r_1 or between r_2,v. An A leaf contributes its two middle specials; a P or S leaf contributes none. If exactly one leaf is A, those two central endpoints are consecutive old neighbors in that one leaf. They must be matched to one another, but simplicity forbids a matching edge duplicating their C edge. Thus every A/P, A/S, P/A and S/A combination is impossible.

The complete necessary placement table is therefore:

|First root / second root|P|A|S|
|---|---|---|---|
|P|new adjacent-pair theorem|impossible|new adjacent-pair theorem|
|A|impossible|round-three outer-terminal theorem|impossible|
|S|new adjacent-pair theorem|impossible|new adjacent-pair theorem|

“Theorem” means Hamiltonicity of every realization under the full model, not that every combinatorial forest in that cell can be realized. The P/P cell has the explicit actual Barnette witness below.

## Adjacent-pair proof

Assume each leaf is P or S. The central region has no unoccupied face matching endpoints, so every nonterminal face matching edge is root-local, indeed confined to a peripheral interval. In each exceptional leaf denote its two nonterminals by x_i,y_i in their old order. They are old neighbors. Its two terminals are also old neighbors. The leaf word is either

\[
(h_1,u,r_1,x_1,y_1,j_1),\quad
(h_1,x_1,y_1,u,r_1,j_1)
\]

in the first root, and the analogous word with (r_2,v) in the second.

Use both trap closures:

\[
D_1=(L_1\xrightarrow{C}R_1,t_c,c,d,t_d,L_1),\quad
D_2=(L_2\xrightarrow{C}R_2,t_a,a,b,t_b,L_2).
\]

For each root let E_i consist only of the old edges st of its complete two-special leaves. Form F_i from D_i by deleting E_i, the exceptional leaf's terminal edge and its nonterminal edge x_iy_i; then add all root-local face matching edges at nonterminal specials. Each terminal has degree one, because its attachment matching edge is outside this root construction. Each remaining special loses one old edge and gains its matching edge, so has degree two; every other vertex retains degree two. Thus F_i consists of a terminal path and zero or more cycles.

The important connectivity statement is that **restoring only E_i suffices**; neither missing exceptional edge is restored. Removing those two exceptional edges from D_i leaves precisely two old paths. One is the two-vertex path containing a terminal and the neighboring nonterminal (r_1,x_1) for P in root1, or (y_1,u) for S. The other path contains every remaining vertex of D_i. The nonterminal on the short path has a face matching mate. That mate cannot be the terminal, whose third edge is already the prescribed attachment. It cannot be the other exceptional nonterminal, since x_iy_i is an old edge. Root locality and the full endpoint decomposition therefore place its mate at a peripheral complete-leaf special on the long path. This matching edge joins the two old paths. Consequently F_i+E_i is connected.

The following elementary square fact completes the root construction. A spanning degree-two/degree-one subgraph with exactly two terminals consists of one path and cycles. If restoring a set of missing ambient edges st makes it connected, and each such edge has a disjoint support (h,s,t,j) with surviving rails hs,tj and ambient chord hj, contract the components and take a spanning tree rooted at the path. Absorb cycles along tree edges by hs,tj -> hj,st. At the time of each switch the edge joins different components, so hj is absent, and the switch merges a path and a cycle into one path with the same endpoints. Disjoint supports preserve future rails and all edges outside them. This gives one spanning terminal path. This is the two-terminal specialization of the round-two general square lemma, with its proof included here.

Apply it to F_1,F_2. All supports are complete two-special leaves; none meets the exceptional leaf or trap vertices. Obtain disjoint paths P_1:u to r_1 and P_2:r_2 to v spanning all of D_1,D_2 and retaining both full trap paths. No special-leaf switch or residual-cycle absorption is needed in this profile.

Every vertex outside D_1 union D_2 is one of w_0,z_1,z_2,w_*,alpha,beta. The two exterior paths

\[
E_0=(u,w_0,\beta,\alpha,w_*,v),\quad
E_1=(r_1,z_1,z_2,r_2)
\]

use actual old, attachment and closing edges. Their interiors are disjoint and consist exactly of those six outside vertices. Thus

\[
u\xrightarrow{P_1}r_1\xrightarrow{E_1}r_2
\xrightarrow{P_2}v\xrightarrow{E_0^{-1}}u
\]

is one Hamilton cycle, containing w_0u and vw_*. This proves all four P/S combinations conditional on realization. It does not require Note 773 or a residual-cycle assertion as a black box.

## Actual witness, reproduction and boundary

The small witness in `verify_barnette_round4_adjacent_profile.py` has old C=(0,...,45). The exact data are

```text
face M: (0,5) (6,19) (20,25) (26,39) (40,45)
        (7,14) (8,13) (27,34) (28,33)
opposite M: (1,44) (18,43) (21,42) (38,41)
            (2,17) (3,10) (4,9) (11,16) (12,15)
            (22,37) (23,30) (24,29) (31,36) (32,35)
```

The first root is [2,17], with exceptional leaf [4,9] inside unary wrapper [3,10], and complete two-special leaf [12,15] inside unary wrapper [11,16]. The second root is the translated copy +20. Thus u=5,r_1=6,r_2=25,v=26: P/P. The outside labels are w_0=0,t_d=1,t_c=18,z_1=19,z_2=20,t_b=21,t_a=38,w_*=39,alpha=40,a=41,b=42,c=43,d=44,beta=45. Each exceptional leaf has depth2 rather than the unrealizable tempting singleton-root placement.

The common site face is (0,5,6,19,20,25,26,39,40,45,0), containing the actual three-edge arc (39,40,45,0) trapping the chord-free hexagon (40,41,42,43,44,45). The script checks the specified planar rotation, perfect matching, colouring, ordinary leaf profile, connected interlacement graph and connectivity after deletion of at most two vertices. For this exact graph it checks the one normal-leaf square per root, the two constructed paths, and the final marked Hamilton cycle. It performs no Hamilton-cycle search and no parameter census. A positive P/P witness is sufficient to show that the new adjacent family is nonempty; no witness for all forests or all four position cells is claimed.

The matching interlacement certificate also gives an analytic three-connectivity argument. A Hamilton circle rules out bridges. A two-edge cut would consist of two C edges and delimit a proper matching-closed C interval, separating the interlacement graph, a contradiction. A simple cubic three-edge-connected graph is three-vertex-connected: a cut vertex would need at least six incident edges; a two-vertex cut would force exactly two components, each with three attachments to nonadjacent cut vertices. The attachments split 1+2 to each component, and adjoining the cut vertex with two attachments to one component gives a forbidden two-edge cut. The finite deletion check independently verifies the specified example; it is not the arbitrary-depth theorem's proof.

For a bipartite realization additional colour constraints may forbid otherwise listed combinatorial forests. In this exact B order L_1,L_2 have the colour of w_0, u,r_2 have its opposite colour, and r_1,v its colour. Since every ordinary child interval has even length and nonleaf nodes have no direct specials, left-end colours alternate by tree depth. Each exceptional leaf's left end must therefore have the root's colour and its depth must be even. The barrier also forces the two exceptional nonterminals of P to find mates after the leaf (before the leaf for S), so an adjacent exceptional leaf cannot itself be the entire root. These are realization restrictions, not gaps in the conditional path proof.

The classification does not cover terminals outside their exceptional leaves, additional four-special leaves, nonleaf direct specials, overlapping supports or extra exposed hexagons. The next genuinely new distribution is a terminal moved to a different leaf/node, which changes the peripheral parity counts and the short-path connectivity argument. No claim about that distribution or the main conjecture is made. Authorship, license and different-source review remain unresolved; no publication action was taken.
