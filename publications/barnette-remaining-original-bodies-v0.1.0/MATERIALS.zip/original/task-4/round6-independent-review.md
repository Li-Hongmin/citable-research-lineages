# Round 6 independent interface review

## Verdict and scope

The direct split construction gives a uniform terminal-stem transport lemma for the stated finite simple cubic bipartite plane interface, with arbitrarily many complete two-special leaves between the marked leaf and the first fat leaf and arbitrary ordinary laminar wrappers. The construction does not require a fixed mate of `s`, a fixed cross matching, or a common color orientation of the inserted leaves.

This is a bounded, same-model analytic review. I first reasoned from the delegated interface without reading previous-round packets, then independently checked the parent's direct split construction and the exact fat exchange/exterior closure supplied in this round. No finite enumeration, SAT, search, heavy computation, Git operation, or older-file edit was used. The conclusion concerns this interface, not the main Barnette conjecture.

## Hypotheses used

The Hamilton cycle has the stated order

`(w0, td, W1, tc, z1, z2, tb, W2, ta, w*, alpha, a, b, c, d, beta, w0)`.

The actual matching edges include `w0-u`, `r1-z1`, `z2-r2`, `v-w*`, and `alpha-beta`. The opposite trap matching is `td-d`, `tc-c`, `tb-b`, `ta-a`.

Each ordinary root has exactly one entire four-special leaf; every other leaf is an entire two-special leaf `(h,s,t,j)` with ordinary matching chord `h-j`. Nonleaf ordinary supports contain no direct special endpoints. The marked leaf is `(h0,u,s,j0)`. The fat leaves are `(h1,p1,p2,p3,r1,j1)` and `(h2,r2,q2,q3,v,j2)`. Supports of distinct entire leaves are disjoint. All actual-face matching endpoints not on the prescribed exterior terminal edges are assigned to these leaf special vertices.

The pre-established exterior barriers leave precisely these ordinary roots and matching endpoints. They are part of the hypothesis; this review does not assert that arbitrary earlier barriers always produce this interface.

## Uniform split kernel

Put every complete two-special leaf in its split state: use `h-j` and the old Hamilton edge `s-t`, and omit the rails `h-s` and `t-j`. At the marked leaf these edges are `h0-j0` and `u-s`.

For the first fat leaf use `h1-p1`, `p2-p3`, and `j1-r1`; for the second use `h2-r2`, `q2-q3`, and `j2-v`.

Define a special-vertex graph `T` using all actual-face matching edges between nonexterior special vertices, all complete-leaf old edges `s-t` (including `u-s`), and the two fat old edges `p2-p3`, `q2-q3`. The vertices `r1,r2,v` are excluded from `T`; their matching partners are exterior. The vertex `u` has only its old edge `u-s` in `T`, and `p1` has only its actual-face matching edge. Every other vertex of `T` has exactly one actual matching edge and one selected old edge.

Consequently `T` is the disjoint union of one simple path `R` from `u` to `p1` and simple cycles. Finiteness and the degree conditions establish this decomposition; no assumption about the detailed matching is needed.

Replace each complete two-special leaf in the ordinary Hamilton arms by its ordinary chord `h-j`. Wrappers remain on their old Hamilton rails. Since a root has just one fat leaf, cutting out that fat interior leaves two ordinary arms. Joining the first root's arms through the first trap yields the ordinary path

`B1 = p1-h1 ... L1-td-d-c-tc-R1 ... j1-r1`,

with the evident traversal order of the arms; in particular its middle portion `H` from `h1` to `j1` contains the whole first-trap subpath `tc-c-d-td`.

For the second root, join its two arms either through its second trap or its root chord, as chosen below, obtaining `B2` from `r2` to `v`. Every complete-leaf ordinary chord lies on exactly one of `B1,B2`. Compression here only replaces the two ordinary end vertices of a leaf and skips its special interior; arbitrary wrappers cannot create an additional ordinary component.

The only intersection of `T` with `B1` is `p1`, and `T` is disjoint from `B2`. Thus `P1=R+B1` is a simple path from `u` to `r1`, and `P2=B2` is a disjoint simple path from `r2` to `v`.

## Cycle absorption and support check

Let a cycle of `T` contain the old edge `s-t` of a complete two-special leaf. Its ordinary chord `h-j` lies on one of the paths. Delete `h-j` and `s-t`, and add the actual old Hamilton rails `h-s` and `t-j`.

This is a path-cycle splice: deleting `h-j` splits the path into two arms, deleting `s-t` opens the disjoint cycle into a path, and the two rails join all three pieces into one path with the original endpoints. Every affected vertex keeps degree two except the unchanged terminal endpoints. All added edges are actual edges of `G`.

Choose one such leaf per cycle. Distinct cycles cannot share its special endpoints, and the entire-leaf supports are disjoint, so the selected squares cannot interfere. A previously absorbed cycle does not delete another selected ordinary chord. After one splice per cycle, each selected cycle is incorporated exactly once.

No selected old edge lies on the stem `R`. In particular `u-s` belongs to `R`, so the marked leaf is never used for cycle absorption. The entire stem remains protected. No splice deletes `p1-h1`, `j1-r1`, either fat central edge, or a trap edge. The order along the resulting first path remains

`u -> R -> p1 -> h1 -> H -> j1 -> r1`.

This establishes the requested transported stem, including a nontrivial stem that may pass through any number of inserted leaves.

## The sole unsupported cycle

A cycle of `T` with no complete-leaf old edge cannot use a complete-leaf special vertex, because that vertex's selected old edge is incident to it and must occur in its `T` component. It cannot use `u` or `p1`, which have degree one. Its vertices therefore belong to `{p2,p3,q2,q3}`.

Simplicity excludes a two-edge cycle in which an actual matching edge duplicates the old edge `p2-p3` or `q2-q3`. Hence at most one unsupported cycle exists, and it is

`Z = (p2,p3,q2,q3,p2)`,

with matching edges `p2-q3`, `p3-q2`. The alternative cross assignment `p2-q2`, `p3-q3` crosses in the actual-face side of the Hamilton cycle. There are no additional fat leaves, so there is no other unsupported component.

## Exterior closure when Z is absent

Choose the second-root trap base, through `ta-a-b-tb`. Absorb every `T` cycle as above. The two internal paths pair `(u,r1)` and `(r2,v)`.

The exterior paths are

`E0 = (u,w0,beta,alpha,w*,v)`,

`E1 = (r1,z1,z2,r2)`.

Their terminal pairing is `(u,v)` and `(r1,r2)`. Combining the two distinct pairings gives one cycle. The ordinary roots, both traps, all special vertices, and every remaining listed exterior vertex occur exactly once. In particular the cycle contains `w0-u`, `v-w*`, and `alpha-beta`.

## Exterior closure when Z is present

Choose the second-root root-chord base. Absorb all cycles of `T` except `Z`. The protected stem `R` avoids every vertex of `Z`.

On the first fat support delete

`h1-p1`, `p2-p3`, `j1-r1`,

and add

`h1-j1`, `p1-p2`, `p3-r1`.

The chord `h1-j1` is an actual ordinary matching edge and was absent from the two-path state. The other two added edges are old Hamilton edges. The result is a simple terminal path

`S1 = R + (p1,p2,q3,q2,p3,r1)`

and a disjoint terminal-free first-root cycle `Z1=H+(j1,h1)`. The stem remains intact; the exchange changes only the six-vertex fat support. All degree and disjointness conditions follow directly from the displayed edge replacement.

Delete `tc-c` and `d-td` from `Z1`. Its remaining components are a path `Q1` from `td` to `tc`, and the old edge `c-d`. The protected trap edges were untouched by every preceding absorption, so both cuts are available.

Use the exterior paths

`A0 = (u,w0,beta,alpha,a,ta,w*,v)`,

`A1 = (r1,z1,tc) + reverse(Q1) + (td,d,c,b,tb,z2,r2)`.

The portion `td-d-c-b-tb` uses the actual trap edges `td-d`, `b-tb` and the old edges `d-c`, `c-b`; it consumes the isolated old edge `c-d` exactly once. `A0` consumes `a-ta`. The internal paths `S1,P2` still pair `(u,r1)` and `(r2,v)`, while `A0,A1` pair `(u,v)` and `(r1,r2)`. Thus their union is one Hamilton cycle.

Coverage in this branch is explicit: `Q1` covers the first-root ordinary vertices and absorbed cycles assigned there; `S1` covers the stem and fat special cycle; `P2` covers the second-root ordinary vertices and cycles assigned there; `A0,A1` cover the remaining trap and exterior vertices. No vertex is reused. The required actual edges `w0-u`, `v-w*`, and `alpha-beta` occur on `A0`.

## Conclusion

The reusable interface is the special graph `T`, its unique terminal stem, and disjoint path-cycle absorption squares. The only unsupported cycle is the explicitly handled four-fat-special cycle. The second-root base is chosen after inspecting whether this cycle exists; this changes the ordinary connector, not `T`, the stem, or the absorption argument.

No structural obstruction remains within the stated interface. The proof depends on the complete-leaf support hypotheses and the supplied exterior barriers; relaxing those hypotheses would require a separate argument.

## Bounded audit of the self-contained manuscript

I made one read-only pass over `barnette-round6-uniform-terminal-stem.md` after it was supplied in this round. It precisely expresses the accepted uniform proof: the split state is selected directly rather than asserted to follow from an unchecked sequence of forward squares; `T` has just the two endpoints `u,p1`, with the `u=p1` case treated as an isolated length-zero stem; supported cycles are absorbed once each on disjoint leaf supports while protecting `R`; the sole unsupported component is `Z`; and the second-root base and exterior closure adapt to the presence of `Z` with complete vertex coverage.

The manuscript explicitly limits the compression to the stated round-three/round-five interface cases and excludes the different round-four fat openings. This is a check of those interface statements in the new manuscript, not an independent historical verification of older packets, which I did not read.

No mathematical correction was identified. One typographical correction was reported to the parent: the fat-exchange display has `}longmapsto` where the LaTeX command must be `}\longmapsto`. The manuscript itself was not edited by this reviewer. The bounded audit is complete; its same-model and conditional-profile limitations remain as stated above.
