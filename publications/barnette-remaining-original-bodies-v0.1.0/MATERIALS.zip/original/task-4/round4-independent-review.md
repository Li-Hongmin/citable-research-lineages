# Bounded independent review: terminal positions in four-special leaves

2026-10-03. This is a fresh-context, same-model mathematical review. It is not different-model, human, or external verification. The derivation below was formed without reading the round-three terminal-aligned proof or its review. No Git, remote computation, graph search, literature search, or publication operation was used. Only this new review file is written.

## Exact setting and verdict

Let G be the specified finite simple cubic bipartite plane Hamiltonian graph, with the actual matching edges on the two sides of its given Hamilton circle C. Its B order is

\[
C=(w_0,t_d,W_1,t_c,z_1,z_2,t_b,W_2,t_a,w_*,
\alpha,a,b,c,d,\beta,w_0).
\]

The face-side matching includes the actual edges w0-u, r1-z1, z2-r2, v-w*, and alpha-beta. The opposite-side matching includes td-d, tc-c, tb-b, ta-a. Its remaining ordinary chords form a laminar forest with exactly the roots [L1,R1] and [L2,R2]. All remaining face-matching endpoints are assigned specials. Each root has one entire four-special leaf (h,p1,p2,p3,p4,j); every other special lies in an entire two-special leaf (h,s,t,j). Nonleaf nodes have no direct specials. The four physical terminals are distinct, with u,r1 in the first four-special leaf and r2,v in the second.

**Verdict.** For every actual realization with both roots in adjacent-terminal profiles, there is a spanning Hamilton circle containing both prescribed site edges w0-u and v-w*. This includes the exact left-adjacent profile

\[
(h_1,u,r_1,x,y,j_1),\qquad
(h_2,r_2,v,z,t,j_2),
\]

and the other three left/right adjacency combinations. The proof is analytic, uniform in the ordinary-tree depth and the number of peripheral leaves. It does not assert that root count, B order, or m=f forces this profile. An adjacent four-special leaf that is its entire root is impossible; that is a realization obstruction, not a Hamilton obstruction. A profile with exactly one terminal-aligned root is also impossible, as shown below. The both-aligned Hamilton case is not re-reviewed here.

## Terminal-position classification

Within the first four-special leaf write u=p_i and r1=p_k. Their face chords w0-u and r1-z1 cannot cross, so i<k. The chord w0-u closes the face-matching demand strictly between w0 and u: every other face chord incident with an interior vertex has its other endpoint there. All ordinary endpoints and td have their matching on the opposite side. The face-side demand is therefore exactly the specials preceding u. Every complete two-special leaf preceding the fat leaf contributes two, and the fat prefix contributes i-1. No complete leaf is cut by this segment. A perfect matching inside the segment forces i-1 even, hence i odd.

Similarly, r1-z1 closes the suffix demand, which consists of complete two-special leaves and the 4-k fat suffix specials. Hence k is even. Consequently only

\[
(i,k)=(1,2),\ (1,4),\ (3,4)
\]

can occur. Denote them P, A, S respectively: left-adjacent, terminal-aligned, and right-adjacent. The same reasoning in W2, using z2-r2 and v-w*, gives precisely the same three possibilities for (r2,v). Reversed orders, equal positions, and the other increasing position pairs are impossible. This is initially a list of nine necessary profile pairs, not a sufficiency theorem asserting their realizability.

The four prefix/suffix sectors closed by the terminal attachments account for every peripheral special. Indeed, a peripheral leaf is disjoint from the fat leaf and cannot lie strictly between two fat positions. Any nonterminal specials outside these four closed sectors are therefore exactly those strictly between the terminal pair in a fat leaf. If exactly one root has profile A and the other has P or S, exactly two such specials remain, namely p2,p3 in the aligned leaf. Every other remaining face-matching endpoint is inside a closed sector. The two residual specials must consequently match each other, but p2p3 is already a C edge, prohibited by simplicity. Thus (A,P),(A,S),(P,A),(S,A) are impossible. The possible profile pairs reduce to (A,A) and the four adjacent-adjacent pairs; even these must satisfy all other realization constraints. In (A,A), the two middle pairs cannot match internally and noncrossing forces the cross pairing p2-q3, p3-q2. No Hamilton claim about that case is inferred from this matching observation.

There is a further depth-parity constraint. Colour w0 by 0. Since each ordinary root has even size, the displayed B order gives L1 and L2 colour 0, z1 colour 1, z2 colour 0, and w* colour 1. The terminal matching edges force

\[
\operatorname{col}(u)=\operatorname{col}(r_2)=1,
\qquad
\operatorname{col}(r_1)=\operatorname{col}(v)=0.
\]

The allowed indices therefore force both fat left ends h1,h2 to have colour 0. A nonleaf with no direct specials has its children as consecutive entire even-size blocks between its ends. Each child's left end has colour opposite its parent's left end. Thus each fat leaf has **even depth from its ordinary root**. Odd-depth fat leaves are impossible in this setting.

For either adjacent placement the open segment between the two terminals contains no special. Its complement in the root consists of prefix and suffix sectors, each individually closed by one of the two terminal attachments. Therefore all remaining face matching is root-local if both roots have adjacent terminals. In the selected left-adjacent profile, x,y must match within the suffix after r1, and z,t within the suffix after v. They cannot match each other: xy and zt already belong to C and G is simple. Their mates must consequently be specials of complete two-special leaves after the respective fat leaf. Each such suffix contains at least one peripheral leaf. In profile S the analogous demand is in the prefix, so at least one peripheral leaf precedes the fat leaf. In particular, any adjacent fat leaf is not its root; combined with the preceding colour constraint, its depth is at least two.

## Analytic Hamilton construction

Use the disjoint trap-closed base circles

\[
D_1=(L_1\xrightarrow{C}R_1,t_c,c,d,t_d,L_1),
\qquad
D_2=(L_2\xrightarrow{C}R_2,t_a,a,b,t_b,L_2).
\]

They cover both roots and all four trap targets and internal trap vertices a,b,c,d. They leave outside exactly w0,z1,z2,w*,alpha,beta. The trap matching edges in these circles are among the stated actual edges.

For each peripheral complete two-special leaf q=(h_q,s_q,t_q,j_q), let e_q=s_qt_q and let E_i be these edges in root i. Let N_i be all face-matching edges with nonterminal special endpoints in root i; root locality was just proved. Define

\[
F_1=(D_1-\{ur_1,xy\}-E_1)\cup N_1,
\qquad
F_2=(D_2-\{r_2v,zt\}-E_2)\cup N_2.
\]

Every terminal loses its unique selected old incidence and gets no restored matching edge, so its degree is one. Every nonterminal special loses exactly one old incidence and gets its unique matching incidence, so its degree is two. Ordinary endpoints and trap vertices keep degree two. Thus Fi is spanning on Di and consists of one terminal path and possibly cycles.

After restoring only E1, the old part D1-{ur1,xy} consists of precisely two paths:

* A1, from u backwards through h1 and the rest of the base circle to j1,y;
* B1=(r1,x).

Every peripheral special belongs to A1. The face mate of x is a peripheral special, because it is neither a terminal nor y and all nonterminal face edges are root-local. Hence its matching edge joins B1 to A1. Therefore F1+E1 is connected. The identical argument gives connectivity of F2+E2, whose short old path is (v,z).

Here is the needed square-switch interface, with its proof included. For each peripheral leaf, the rails hs,tj belong to Fi, its unused ordinary chord hj exists, and e=st is absent from Fi. These four-vertex supports are disjoint. Contract Fi's components and retain the restored e-edges. The resulting quotient is connected. Since Fi has just two terminals, it has exactly one path component; all other components are cycles. Root a spanning tree of the quotient at that path component. Successively use a tree edge e=st to merge the growing path with an adjacent cycle by replacing

\[
\{hs,tj\}\ \longmapsto\ \{hj,st\}.
\]

Cutting one rail in the path and one in the cycle, and joining their ends crosswise, creates one longer path with the same terminal endpoints. Disjoint supports ensure that earlier switches do not alter a later support. Induction absorbs every cycle. The resulting spanning path Pi has endpoints u,r1 for i=1 and r2,v for i=2. Only peripheral rails were removed, so both complete trap-closing paths remain intact. This is also the two-terminal case of the workspace's general square-splicing lemma, but no external theorem is needed for this argument.

Finally join the paths to the exterior paths

\[
E_0=(u,w_0,\beta,\alpha,w_*,v),
\qquad
E_1=(r_1,z_1,z_2,r_2).
\]

All their edges are actual: w0-u and v-w* are the site edges, beta-alpha is the specified face matching edge, r1-z1 and z2-r2 are the exposed attachments, and the rest are C edges. These exterior paths cover exactly the six vertices omitted by D1 and D2. Their interiors are disjoint from the two internal paths and each other. Their endpoint pairing (u,v)(r1,r2) differs from the internal pairing (u,r1)(r2,v), so their union is one spanning circle, rather than two. Explicitly, traverse u along P1 to r1, then z1,z2,r2, then P2 to v, then w*,alpha,beta,w0,u. Both site edges are retained.

The same construction treats all four adjacent-adjacent combinations, without assuming any new realization. In each fat leaf delete its terminal-pair C edge and its nonterminal-pair C edge. If its profile is P, the short remaining old path is (p2,p3), with p2 terminal and p3 nonterminal. If its profile is S, the same short path has p2 nonterminal and p3 terminal. The complementary old path contains all peripheral specials and the two fat end vertices. The nonterminal on the short path cannot match the other fat nonterminal because those two are C-adjacent; it cannot match a terminal already incident with its prescribed attachment. Its mate is a peripheral special on the complementary path. This again proves connectedness after restoring only peripheral special edges, and the same square-switch and exterior arguments apply. Thus the theorem is conditional on actual realization for each of (P,P),(P,S),(S,P),(S,S).

## Scope and weakest interface

The proof uses actual same-side noncrossing matching, the exact entire-leaf profile, absence of direct specials at nonleaves, and simplicity to exclude xy or zt as matching edges. Bipartiteness is used for the depth restriction. Three-connectivity is not needed after this exact profile and B opening are supplied. No residual anchored-cycle classification, finite graph enumeration, or previous terminal-aligned Hamilton proof is invoked.

The key interface is **root locality from the adjacent attachments**, not an automatic profile inference from two roots. Without adjacency, specials between the two terminals can support cross-root matching, and the present connectivity argument does not address that different case. The two cuts per fat leaf and the matching link from its short path to the complementary old path are completely explicit; peripheral nesting depth cannot change either fact.

This bounded review proves the four adjacent-profile conditional statements, excludes the four mixed aligned/adjacent profiles, and supplies necessary position/depth restrictions. The uniform adjacent extension and mixed exclusion were checked after the parent independently reported the same mechanism. The initial P,P derivation and position/depth constraints were communicated before that message. The both-aligned Hamilton proof, any wider upstream profile reduction, novelty, and external verification remain outside this review's scope.

## Final bounded check of the new synthesis

Read only `barnette-round4-adjacent-terminal-leaves.md` after completing the foregoing derivation. Its four mixed-profile impossibility cells, four adjacent conditional constructions, short-path mate interface, and exact six-vertex exterior coverage agree with the self-contained argument above. Its even-depth caveat correctly forbids odd depth in bipartite realizations and does not promise realization at arbitrary even depth. No finite witness computation was audited in this final check.

No missing hypothesis was found in the synthesis's new adjacent proof. Its weaker finite simple cubic plane setting suffices for that proof; its even-depth assertion is explicitly conditional on bipartiteness. I initially questioned whether the round-three reference required additional Barnette hypotheses, then checked that note's exact-hypotheses preamble after forming all the new reasoning above: it also explicitly uses the weaker finite simple cubic plane setting. That concern was withdrawn and is not an outstanding blocker. Acceptance of the A/A cell remains conditional on the cited round-three result; no fresh A/A proof review is made here.
