# Two terminal-aligned four-special leaves admit a marked Hamilton cycle

2026-10-03, third bounded round, separate version. Private contribution candidate; no priority or general Barnette-conjecture claim. The source unit and sealed earlier packets remain read-only. Fresh-context review used the same model and is not independent external validation.

**Result.** The precise profile below has a Hamilton cycle containing both marked site edges. It permits arbitrary ordinary forest depth, wrappers and branching. The profile is an additional hypothesis: two roots, B order and the equality m=f do not imply it. The second-round 26-vertex countermodel satisfies this profile and is covered by this construction.

## Exact hypotheses

Let G be a finite simple cubic plane graph with a specified Hamilton cycle C. Write its cyclic order as

\[
(w_0,t_d,W_1,t_c,z_1,z_2,t_b,W_2,t_a,w_*,\alpha,a,b,c,d,\beta,w_0).
\]

All displayed vertices are distinct. Each W_i is a nonempty consecutive old-C word from L_i to R_i. The two sides of the Jordan circle C are called face page and opposite page; edges on either page have nonalternating endpoints. The complement M=E(G)\E(C) is a perfect matching. It contains face-page edges

\[
w_0u,\quad vw_*,\quad r_1z_1,\quad z_2r_2,\quad \alpha\beta,
\]

and opposite-page trap edges t_dd,t_cc,t_bb,t_aa. The marked sites are w_0u and vw_*. In particular alpha-beta is an actual edge, not inferred merely from B cyclic order.

Every remaining opposite-page matching edge is an ordinary chord wholly inside W_1 or W_2. In each word these chords form a laminar interval forest with exactly one root [L_i,R_i]. Thus L_iR_i belongs to M. Every remaining face-page matching endpoint is an assigned special in one of these root intervals. Assignment means to the innermost ordinary interval containing the special. There are no further vertices or matching endpoints outside this specified decomposition.

Each forest has exactly one exceptional leaf, with its **entire old-C word** respectively

\[
(h_1,u,x_2,x_3,r_1,j_1),\qquad
(h_2,r_2,y_2,y_3,v,j_2).
\]

Here h_ij_i is the ordinary chord of that leaf. All other assigned specials occur in complete two-special leaves, whose entire old word is (h,s,t,j), with ordinary chord hj. Nodes other than these leaves have no directly assigned specials. Distinct leaves have disjoint vertex supports. A root may itself be its exceptional leaf. No restriction is imposed on the number or depth of the remaining ordinary nodes.

These hypotheses describe a conditional chord model. An application to a Barnette graph must supply them, including the plane embedding and actual closing edge alpha-beta. Simplicity, the page matching and the complete-leaf supports are the ingredients used below; the proof does not infer this profile from 3-connectivity or bipartiteness.

## Proof

**Forced central four-cycle.** A matching edge from a vertex strictly between the ends of a face-page chord must remain between those ends: otherwise the two chords would have alternating endpoints. Endpoints of the bounding chord are already matched. Apply this to the four occupied attachments w_0u, r_1z_1, z_2r_2, vw_*. All specials outside the exceptional interiors lie in one of the four peripheral intervals (w_0,u), (r_1,z_1), (z_2,r_2), (v,w_*), and remain matched in that interval. The only unoccupied face-page endpoints in the complementary region are x_2,x_3,y_2,y_3. Simplicity forbids matching the consecutive old neighbors x_2x_3 or y_2y_3; noncrossing forbids x_2y_2 together with x_3y_3. Hence M contains x_2y_3 and x_3y_2. These give the central cycle

\[
Z=(x_2,x_3,y_2,y_3,x_2).
\]

**Two outer spanning paths.** Choose the following disjoint base cycles, using the first trap and the second root chord:

\[
D_1=(L_1\xrightarrow{C}R_1,t_c,c,d,t_d,L_1),\qquad
D_2=(L_2\xrightarrow{C}R_2,L_2).
\]

Delete ux_2,x_3r_1 from D_1. This leaves the central edge x_2x_3 and an outer path O_1:u to r_1. Similarly deleting r_2y_2,y_3v from D_2 leaves y_2y_3 and O_2:r_2 to v. Each outer path contains all complete two-special leaves of its root, with their old rails hs,tj intact. Its other vertices are ordinary chord endpoints, its two unmatched terminals, and, for O_1, the consecutive trap t_c-c-d-t_d.

For i=1,2, let E_i be the set of old edges st in these complete leaves. Delete E_i from O_i and add all face-page matching edges incident with its nonterminal specials, calling the resulting spanning subgraph F_i. The barrier argument above places every such matching edge wholly inside O_i. Thus F_i has degree one exactly at the two endpoints of O_i and degree two elsewhere. Also F_i+E_i is connected because it contains O_i.

We use the following two-terminal square fact, included here so that the proof has no unpublished theorem dependency. If a spanning F has exactly two degree-one terminals and degree two elsewhere, then F consists of one path and cycles. Suppose pairwise disjoint supports (h,s,t,j) have hs,tj in F, an ambient graph edge st absent from F, and available ambient edge hj, and restoring all st makes F connected. Contract F-components and select a spanning tree rooted at its path component. Absorb the cycle components into the path along this tree, switching hs,tj to hj,st at each selected support. At each step the support joins different current components, so hj is not already present; cutting a path rail and a cycle rail and joining crosswise produces one path with the same terminals. Disjoint supports preserve all unused rails. At the end one spanning terminal path remains. Every edge outside the removable rails survives. This is the two-terminal specialization of the separately reviewed second-round general square-splicing lemma.

Apply this fact to each F_i, giving paths P_1:u to r_1 and P_2:r_2 to v. They cover D_1 minus {x_2,x_3} and D_2 minus {y_2,y_3}, respectively. P_1 retains u-h_1, j_1-r_1 and the entire trap t_c-c-d-t_d. The edge h_1j_1 is absent from P_1: it was absent from the trap base D_1, and no switch in another leaf can add it. This remains true if the exceptional leaf is the root.

**Six-edge exchange.** In P_1 union Z, remove u-h_1, x_2-x_3, j_1-r_1 and add h_1-j_1, u-x_2, x_3-r_1. Removing the two endpoint rails of P_1 leaves isolated u,r_1 and a single h_1 to j_1 path. Adding the unused ordinary chord h_1j_1 closes that path into a simple cycle Z_1, which retains t_c-c-d-t_d. Removing x_2x_3 from Z and adding the other two edges gives

\[
S=(u,x_2,y_3,y_2,x_3,r_1).
\]

The three objects S, P_2, Z_1 have disjoint vertex sets and together cover D_1 union D_2. This is the step missing from the naive attempt to apply only two-special-leaf squares: that attempt leaves an unanchored central cycle Z. The extra exchange gives the residual cycle a first-root trap anchor.

**Explicit exterior closure.** Delete t_cc and dt_d from Z_1. The remnants are edge cd and one path Q_1:t_d to t_c containing every other vertex of Z_1. Define

\[
A_0=(u,w_0,\beta,\alpha,a,t_a,w_*,v),
\]
\[
A_1=(r_1,z_1,t_c)\cdot Q_1^{-1}\cdot
(t_d,d,c,b,t_b,z_2,r_2).
\]

Concatenation identifies its repeated seam endpoint once. Each consecutive pair is an old edge or one of the actual attachment, closing or trap edges. A_0 and A_1 have disjoint interiors, avoid the interiors of S and P_2, and together cover Z_1 and every vertex outside D_1 union D_2. In particular c,d are absent from Q_1 and appear exactly once in A_1. Consequently

\[
u\xrightarrow{S}r_1\xrightarrow{A_1}r_2
\xrightarrow{P_2}v\xrightarrow{A_0^{-1}}u
\]

is a single Hamilton cycle. It contains both w_0u and vw_*. This completes the conditional profile theorem. A specified legal C4 expansion can be lifted by replacing each marked site with its length-three gadget side; legality of the child is a separate input, not a consequence claimed here. Square.

## Exact small witness and scope

For the 26-vertex graph of the second round, use old C=(0,...,25), face matching {(0,3),(16,19),(20,25),(6,9),(10,13),(4,15),(5,14)}, and opposite matching {(1,24),(8,23),(11,22),(18,21),(2,7),(12,17)}. The label correspondence is

\[
(w_0,t_d,h_1,u,x_2,x_3,r_1,j_1,t_c,z_1,z_2,t_b,
h_2,r_2,y_2,y_3,v,j_2,t_a,w_*,\alpha,a,b,c,d,\beta)
=(0,1,\ldots,25).
\]

The construction has P_1=(3,2,1,24,23,8,7,6), P_2=(13,12,17,16), Z=(4,5,14,15,4), S=(3,4,15,14,5,6), Z_1=(2,1,24,23,8,7,2), and Q_1=(1,2,7,8). Its final marked Hamilton cycle is

\[
(3,4,15,14,5,6,9,8,7,2,1,24,23,22,11,10,13,12,17,16,19,18,21,20,25,0,3).
\]

`verify_barnette_round3_marked_cycle.py` checks this exact construction, its edge exchanges, coverage and both marked sites, then lifts it to the previously specified 30-vertex C4 child. It performs no graph search. The arbitrary-depth result is proved analytically above; one witness is not its proof. The sealed second-round record separately establishes that the 26-vertex parent and specified child are actual Barnette graphs.

The exact terminal alignment is essential to this proof: cutting the two retained endpoint rails leaves one h_1 to j_1 path. Arbitrary four-special leaves, terminals at other assigned nodes, other distributions of four-special leaves, overlapping switch supports or additional exposed hexagon components are not covered. No counterexample to those wider cases is asserted. Source Note 503 covers a different single-four-special-leaf setting; Note 773 motivates the exterior formula but is not needed as a black box here. No literature-priority claim is made.

Review status: fresh same-model context independently derived the central ring, endpoint exchange and exterior closure, and flagged alpha-beta as an assumption that must be explicit. Different-source mathematical review, authorship, license and public contribution acceptance remain open. No local manuscript was uploaded or signed.
