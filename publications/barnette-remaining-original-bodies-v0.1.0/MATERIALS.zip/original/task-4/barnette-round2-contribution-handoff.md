# Barnette 第二轮最小贡献交接（给统一贡献任务）

2026-10-03。本任务仅准备本地材料，不 push、不发 PR、不生成 key、不做 Zenodo/DOI 归档。用户“每有发现就提交到 public-ai-research-commons”的新增授权由父指定的统一贡献任务实施；本任务不另开发布渠道。

建议以两个边界清楚的最小结果评估接收，不把条件性增强 Hamilton 结论作为已外审一般定理。

**A．任意终端位置的方块树拼接引理。** `barnette-general-square-splicing-lemma.md` 是完整自足陈述与证明。精确输入：有限简单图；F 在终端度1、其余度2；每个不交四点支撑有两轨在F、未用xy及可用hj；F+E连通；终端数0/2/4。输出：cycle/path/two distinct terminal pairings，并保护所有rails外的F边。没有终端必须属于E端点的限制，不需平面性、二部性或商图Eulerian。数学前身为项目458的树交换证明，不宣称首创。此引理修复458→914的正式终端接口遗漏，不单独证明Barnette。

**B．26点实际反模型。** `barnette-root2-B-profile-countermodel.md` 给出完整两页匹配、Hamilton圈、公共面、所选三边弧/六边形陷阱、三连通解析证书与合法指定扩张。它严格否定“root2+B（即使m=f且四终端在根内）自动推出914的双特殊叶轮廓”。它不满足914的全部假设，不是914或Barnette反例，也不声称任何child非Hamilton。

最小复现材料：`verify_barnette_profile_countermodel.py` 与原始 `barnette-profile-countermodel-check.json`，Python3.14.7标准库。只核一个明确26点例，含rotation/faces、352个parent与466个指定child至多删除两顶点的连通检查；没有参数格搜索、SAT或外部依赖。A 为解析证明，无计算承重。

准确依赖与异议：`barnette-upstream-model-audit.md` 给出actual G,C→两页→ordinary森林/叶支撑的自足证明、源逐项映射、依赖图及四个具体外审问题。`upstream-independent-review.md` 明确读过A正式证明并接受，也独立构造B；这是同模型新上下文，不能标作异源验证。原始源及拟交接材料的准确SHA256在 `barnette-round2-version-manifest.json`；该manifest包含私有来源路径，只供协调/provenance使用，不能自动原样公开。

失败与纠正必须保留：458正式定理不能直接套914任意直接终端；已由A修补。root2/B到特殊轮廓的自动推出严格失败；B给出反证。第一轮的选定内嵌外露相邻对排除仍成立，但完整增强Hamilton闭合链只应以准确profile呈现，外部seams与profile coverage尚须独立外审。该例不否定可能存在的更窄、附加条件明确的有效归约。

统一贡献任务尚需核实：自然人署名/贡献与同意；AI辅助及可核验模型版本披露；原项目材料及新代码/文字的所有权与拟公开许可证；相关文献/新颖性和目标仓库收录规则；是否接受“修正接口＋反模型”这种有范围贡献。未确定信息不能填作已授权或已验证。拟公开材料宜使用A/B自足正文和单例脚本，不携带原私稿、项目路径、会话管理记录或原仓库整体。

提交标题/摘要可用：**Square splicing with arbitrary terminal positions and a two-root profile countermodel**。摘要：给出一个不要求终端位于被删方块边端点的方块树交换引理，并构造具有B次序、两普通根、m=f的26点三连通三正则二部平面Hamilton图，其叶片各有四个直接特殊位点，排除相应自动profile推理。保留明确hypotheses、解析证明、单例复现与同模型审查限制；不声称解决Barnette。
