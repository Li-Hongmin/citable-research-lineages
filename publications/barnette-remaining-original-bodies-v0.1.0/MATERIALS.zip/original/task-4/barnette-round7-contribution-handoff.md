# Barnette 第七轮交接：carrier 吸收框架与新端点分布

2026-10-03。仅 task-4 新候选；不写 AIMath 原 unit、根 LOG/配置/索引，不作 Git 操作，不取源锁。前六轮封存保留。父协调是唯一公开工作接入口。

本轮不再枚举第六轮插叶族。正文 `barnette-round7-protected-carrier-absorption.md` 给出自足的两种 component-certified 交换及两个应用：

1. 先用实际外路 E0,E1 闭成 carrier 圈；普通叶逆平方在两个不同圈间合并，完整 fat 逆交换在三个不同圈间合并。所有交换保留**全部实际 face-page 匹配和四条 trap 匹配边**。
2. Round4 的四种 adjacent-terminal fat 配置均由同一框架吸收：两个 fat 各作一次三圈合并，余圈各选一普通叶平方吸收。分量区分由实际 attachment barriers 与 root locality 推出，无新增匹配方向假设。
3. 新配置为 W1 左普通叶 `(hL,u,s,jL)`、中间纯非终端 fat、右普通叶 `(hR,t,r1,jR)`，W2 仍 outer-terminal fat；允许普通完整叶穿插。中央 face 端点秩奇偶排除所有 unsupported 残圈。先通过左 marked 叶平方把 B1 并入 carrier，再吸收余圈。这里“两端均 nonfat”仅指 **W1 的 u/r1**，未推到全四终端均在两根 fat 之外。

证明依赖精确整个 leaf profile、实际 alpha-beta、实际四 attachment 与四 trap、平面非交叉匹配、简单性及指定旧 Hamilton 圈。两根/B-order/m=f 并不推出这些附加条件；第二轮已证反模型与原笔记审计不因本轮而消失。只称上述实际 realization 的条件性定理，不称解决主猜想，也不提升未审旧主张。

复现不依赖新脚本或运行：直接构造圈覆盖，核对 degree/vertex partition，按正文分量证明安排交换。新42点 matching、20边 interlacement spanning tree、实际双 site 共面边界、三连通手证及显式 Hamilton 圈均列入正文。它是一个正 realization，未称最小图或合法 child 扩张，不做删除枚举、Hamilton 搜索、SAT、旧 witness 重跑或新 checker。

最小方法阻碍是 **same-component switch**：正文8点 simple bipartite 局部圈的两个删除边同圈，逆平方把它拆成两个4圈；8为该局部分裂例最小阶。它不是 Barnette 反例。恢复条件必须是当前 support 的两/三 distinct components 与进入 carrier 的交换次序证书；没有证书时此吸收规则终止。不能凭叶名或观察到一条匹配边就声称可合并。

新上下文、同模型 review 为 `round7-independent-review.md`。其初稿容许 generic unsupported4 recovery；后续补核证明精确新配置其实没有该残圈，并保留初稿记录、不擦除推理历史。最终文本一致性审查单独追加。它是 fresh-context 独立推导和手证核对，仍不等于异模型或人类外审。

后续不建议再堆 slot/插叶配置。若父协调继续一般化，应先决定是否值得建立端点一般的 component-level carrier 证书；例如全四 physical terminals 均 nonfat 时，需要先证明 endpoint pairing、ordinary-component anchoring 与 unsupported-cycle 支持的统一条件。目前这些未证，不能套用本轮。非叶直接 specials、不同 marked 叶 slot、更多fat、support overlap、额外暴露分量也不在结论内。第3/6轮 outer-fat 构造没有被本轮完整 three-distinct-cycle 开法取代。

可公开的最小贡献候选：自足的 protected-carrier 2/3-cycle lemma，两个条件性应用，42点手证及sharp8局部 guard。仅作为待整理候选：署名/贡献归属、AI 使用说明、许可/源稿权属、现有文献/优先性比对、异源外审、可发布摘取版本仍缺。没有上传本地私稿、签名key、DOI或对 Commons 的提交；其唯一入口由父协调管理。

工程检查限于封存：源 unit 2676 文件对最初 metadata snapshot 无变化，11关键源文 SHA256 无变化，round6清单所承接33个既有封存对象无变化；详见新 `barnette-round7-version-manifest.json`。先前进程列表 `ps` 被系统拒绝，未重试或旁路；不能把 metadata/hash 稳定当作完整后台进程证明。原会话经受支持接口已 idle/Goal paused，历史writer归属不确定仍保留。任何明确新占用应停，不抢锁。

本轮已到有界检查点：数学结论与反例边界完整、私有候选封存后交回父协调；不得据此自动发布、写源定理簿或继续无界配置搜索。
