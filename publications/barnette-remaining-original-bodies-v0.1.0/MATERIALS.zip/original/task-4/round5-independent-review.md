# Independent bounded review: split terminals in consecutive leaves

2026-10-03. Fresh-context same-model review. This is not different-source validation. Only this new file was written; source notes and earlier packets were left unchanged.

**Verdict.** The stated profile admits a Hamilton cycle containing the marked edges `w0-u` and `v-w*`, and the construction below also retains the exact edge `alpha-beta`. The additional step is a marked two-special-leaf transport lemma: it absorbs the cycle between two consecutive special leaves into the terminal path and supplies the protected prefix needed for the four-special-leaf exchange. Arbitrary ordinary wrappers introduce a necessary depth parity condition, already forced by the stipulated bipartite graph; they do not introduce a further construction obstruction.

I first derived the central matching and the transport interface without reading preceding proofs. After those conclusions, I read `barnette-round3-terminal-aligned-four-special-leaves.md` to check the inherited exterior closure. The final closure below is explicitly credited to that note; the new transport assertion is checked here rather than assumed.

## Forced central matching and parity

Use the exact cyclic order and actual matching edges stated in the delegation. The occupied face-page chords `w0-u`, `r1-z1`, `z2-r2`, and `v-w*` enclose the four peripheral special intervals. Every unoccupied matching endpoint inside one such interval must mate inside it, since an edge leaving it would alternate with the bounding chord. Their endpoints are already occupied.

Because K0 and K1 are consecutive in leaf order, the only free central endpoints of root 1 are `s,p1,p2,p3`; those of root 2 are `q2,q3`. Thus the complete central matching is a noncrossing matching of the six vertices in cyclic order

`s,p1,p2,p3,q2,q3`.

There are five noncrossing perfect matchings in this order:

1. `(s,p1),(p2,p3),(q2,q3)`;
2. `(s,p1),(p2,q3),(p3,q2)`;
3. `(s,p3),(p1,p2),(q2,q3)`;
4. `(s,q3),(p1,p2),(p3,q2)`;
5. `(s,q3),(p1,q2),(p2,p3)`.

All except the second contain `p1-p2`, `p2-p3`, or `q2-q3`, which is already an old-C edge. Simplicity therefore forces

`Mcentral={(s,p1),(p2,q3),(p3,q2)}`.

Color alone does not exclude the other four; simplicity is essential. In particular, merely listing color-compatible pairings would leave the decisive issue unresolved.

There is also a forced depth restriction. The trap edges `td-d` and `tc-c`, together with the old edge `c-d`, make `td` and `tc` opposite colors. The old edges `w0-td`, `tc-z1` and matching edges `w0-u`, `r1-z1` then make `u` and `r1` opposite colors. The complete leaf words imply that `u,s` are opposite, and `p1,r1` are opposite. Hence `s,p1` are opposite colors, as required by the forced central matching.

Let the ordinary leaf depths of K0 and K1 be d0,d1, with root depth fixed arbitrarily. In the ordinary-only gap between consecutive leaves, the number of endpoint vertices is congruent to d0+d1 modulo 2: completed ordinary subtrees contribute pairs, and closing/opening the ancestral chains gives this parity. The odd old-C distance from `s` to `p1` consequently forces d0 and d1 to have the same parity. A proposed endpoint layout violating this condition is not a bipartite instance of the hypotheses. This is a consistency condition, not a counterexample to the conditional construction.

## Minimal transport lemma

Suppose F consists of a terminal path A from u to r and a disjoint cycle Y. A complete two-special leaf has word `(h,u,s,j)`, with ordinary chord `h-j`. Assume its retained rails satisfy `h-u` in A and `s-j` in Y. If Y also contains the old path from s through j and the ordinary-only gap to p, followed by the matching edge `p-s`, then switching

`h-u, s-j  ->  h-j, u-s`

merges A and Y into one u-to-r path. Its initial segment is

`u,s,p,...`,

and the terminal rail at r survives. If p is immediately preceded by the four-special leaf endpoint h1, the new path has protected prefix `u,s,p,h1`.

Proof: deleting `h-u` leaves isolated u and the remaining h-to-r path; deleting `s-j` opens Y into a j-to-s path. Adding `h-j` joins those two paths, and `u-s` attaches u to their remaining endpoint. Every vertex appears once. The two added edges were absent: `u-s` was a deleted opening edge, and `h-j` was not in the base path/cycle system and cannot be added by switches on disjoint leaf supports. This is a path-cycle merge, not a cycle-cycle merge.

The lemma records more than the availability of an ordinary square: its endpoint, orientation and protected-prefix conclusions are exactly the interface required below.

## Application and complete Hamilton construction

Let

`D1=(L1 --old C--> R1,tc,c,d,td,L1)`

and

`D2=(L2 --old C--> R2,L2)`,

where D2 closes with the actual ordinary root chord `L2-R2`. The second trap is deliberately reserved for the exterior closure.

In D1 delete `u-s`, `p1-p2`, and `p3-r1`, and add the forced matching edge `s-p1`. The result includes: an outside u-to-r1 path A; the cycle

`Y=(s --old C through j0 and h1--> p1,s)`;

and the edge `p2-p3`. The cycle Y has no other assigned special, by consecutiveness. In D2 delete `r2-q2` and `q3-v`; this leaves an outside r2-to-v path and the edge `q2-q3`. The forced central matching edges produce

`Z=(p2,p3,q2,q3,p2)`.

Complete all peripheral two-special leaves as follows. Delete their old `s'-t'` edges and add their face-page matching edges. Barriers place these matching edges on the corresponding outside path. Each resulting subgraph consists of its terminal path and possibly cycles. Its leaf rails remain present. Restoring all deleted `s'-t'` edges makes it connected, because it restores the original outside path. Contract components; a spanning tree of the resulting component graph can therefore be realized by the disjoint square switches `h'-s',t'-j' -> h'-j',s'-t'`. Each selected switch absorbs a cycle into the terminal path. This proves peripheral completion directly and does not require induction on ordinary depth.

The peripheral supports avoid K0 and K1, hence preserve `h0-u`, `s-j0`, `h1-p1`, and `j1-r1`. Apply the transport lemma at K0. It merges Y into the completed first outside path and produces P1 with endpoints u,r1, prefix `u,s,p1,h1`, and final rail `j1-r1`. Its four-special ordinary chord `h1-j1` is still absent. Let P2 be the completed r2-to-v path of D2.

In `P1 union Z` make the exchange

`h1-p1, p2-p3, j1-r1  ->  h1-j1, p1-p2, p3-r1`.

Cutting P1 isolates its prefix `u,s,p1`, its middle h1-to-j1 path, and r1. Cutting Z opens the path `p2,q3,q2,p3`. Thus the exchange gives the explicit central terminal path

`S=(u,s,p1,p2,q3,q2,p3,r1)`

and the cycle Z1 formed from the middle path and `h1-j1`. Z1 retains the first trap segment `tc-c-d-td`. The objects S, P2 and Z1 are vertex-disjoint and cover D1 union D2.

For the inherited exterior closure, delete `tc-c` and `d-td` from Z1. The remnants are the edge `c-d` and a td-to-tc path Q1 containing all other vertices of Z1. Define

`A0=(u,w0,beta,alpha,a,ta,w*,v)`

and

`A1=(r1,z1,tc) + reverse(Q1) + (td,d,c,b,tb,z2,r2)`,

identifying each repeated seam endpoint once. These are actual graph paths: their edges are old C edges or specified actual matching/trap edges. Their interiors are disjoint and cover exactly the remaining vertices. Consequently

`u --S--> r1 --A1--> r2 --P2--> v --reverse(A0)--> u`

is one Hamilton cycle. It contains `w0-u`, `v-w*`, and the stipulated exact edge `alpha-beta`.

## Scope and weakest interfaces

The construction depends on the complete consecutive K0/K1 words, not just on the two terminals occupying different leaves. Without consecutiveness, Y may contain assigned specials and the protected prefix is not established. Without complete leaf supports, the transport rails or subsequent six-edge exchange can be unavailable. Without simplicity, the central matching is not forced. Alpha-beta is an input actual edge, never inferred from endpoint order.

This is a genuine extension of the terminal-aligned four-special-leaf construction: u and r1 occupy different leaves, and the terminal u belongs to a complete two-special leaf. The transferable addition is the stated path-cycle transport lemma and its protected interface. The exterior closure and the basic peripheral square completion are inherited mechanisms, not new mathematical claims. No broader arbitrary split-terminal theorem, Barnette conjecture result, novelty claim, or external validation is established by this review. No obstruction remains within the stated exact profile.

## Final check of the new self-contained round-five note

I subsequently read `barnette-round5-terminal-leaf-transport.md`, without changing it or any previous packet. Its complete hypotheses, isolated Y, marked path-cycle square, protected stem, fat exchange, second-root chord closure and exterior coverage agree with the independently derived interfaces above. The final cycle retains alpha-beta, as follows directly from A0. The arbitrary-length terminal-stem lemma is valid: the three cuts separate the stem, the middle h-to-j path, the terminal r, and the opened four-cycle; the three added edges reconnect exactly the two claimed objects. Its zero-length-stem specialization is the older endpoint-aligned interface.

The new note's stronger depth constraint is also correct. Each ordinary interval has even vertex length because its opposite-page matching chord joins opposite colors. With no directly assigned specials at a nonleaf, the left endpoint of a child therefore has the opposite color to its parent's left endpoint: all completed siblings contribute even lengths. The trap/attachment color equations force h0 and h1 to have L1's color, and h2 to have L2's color. Thus the three marked leaves have even depth relative to their roots. The same-parity statement earlier in this review was a weaker necessary condition, not the full forced coloring relation.

One terminology qualification remains: the exact round-five hypothesis, requiring u in a two-special leaf, is not itself a set-theoretic superset of the older hypothesis requiring u in the four-special leaf. It enlarges the catalog of covered profiles. The terminal-stem lemma does strictly generalize the older interface and explains this additional profile. This distinction does not affect the theorem, but avoids construing “strict extension” as a false containment claim. The prescribed witness is used by the parent to establish nonemptiness; I did not rerun it or independently certify its three-connectivity. The analytic theorem does not depend on that computation.
