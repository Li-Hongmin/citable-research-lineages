# Two four-special leaves in the specified B profile

2026-10-03. Private, bounded, same-model independent-context review. This file alone is new; no project unit, first- or second-round packet, Git state, computation or publication was changed. The `math-research-system` skill was used only for its bounded mathematical-verdict discipline. This is not different-source external review.

## Verdict and exact interface

The stated **single-hexagon B profile**, with one exceptional leaf in each root in the specific orders

\[
(H_1,u,x_2,x_3,r_1,J_1),\qquad
(H_2,r_2,y_2,y_3,v,J_2),
\]

has a Hamilton parent cycle containing both site edges. The proof works with arbitrary ordinary branching, wrappers and depth. It is analytic and uses no finite search. This is an additional conditional profile; neither two roots nor B order nor \(m=f\) automatically supplies it. Note 503 has only one four-special leaf and is not the theorem being proved here.

The single-hexagon interface includes the closing edge \(\alpha\beta\), as in Note 773. To avoid silently enlarging a list of bare hypotheses, the exact graph interface used below is: all old edges of the displayed Hamilton circle; face-page edges \(w_0u,vw_*,z_1r_1,z_2r_2,\alpha\beta\); opposite-page trap edges \(t_dd,t_cc,t_bb,t_aa\); and the ordinary forest chords, including \(H_1J_1,H_2J_2\) and each root chord. Every remaining assigned special is in a complete two-special leaf. If “B order” is meant to specify only a cyclic vertex order without \(\alpha\beta\), the proof below is conditional on that missing interface edge and does not claim a verdict for that weaker problem.

## 1. The central matching is forced

All third edges of a cubic Hamilton graph constitute a perfect matching. On the face side, the four occupied chords

\[
w_0u,\quad r_1z_1,\quad z_2r_2,\quad vw_*
\]

bound four mutually disjoint peripheral boundary intervals

\[
(w_0,u),\quad(r_1,z_1),\quad(z_2,r_2),\quad(v,w_*).
\]

A face matching edge with one endpoint strictly in one such interval must have its other endpoint in that same interval: otherwise its endpoints alternate with the displayed bounding chord. The bounding endpoints already have their third edges and cannot be alternative mates.

The unoccupied face matching endpoints in the complementary region are exactly
\(x_2,x_3,y_2,y_3\). Indeed, the exposed endpoints and site endpoints are occupied, the four trap vertices have opposite-page third edges, \(\alpha,\beta\) are paired, and the exceptional leaf words contain no other positions between \(u,r_1\) or between \(r_2,v\). All other specials lie in the four peripheral intervals.

Simplicity forbids matching \(x_2\) to \(x_3\), or \(y_2\) to \(y_3\), because those are old edges. Noncrossing forbids the pairing \(x_2y_2,x_3y_3\). Consequently the matching contains exactly

\[
x_2y_3,\qquad x_3y_2. \tag{1}
\]

The four central vertices therefore support the cycle

\[
Z_0=(x_2,x_3,y_2,y_3,x_2). \tag{2}
\]

In particular, every other face matching edge stays in one peripheral interval, so no other edge joins the roots. This conclusion uses the specified terminal positions, not only the cardinality of exceptional leaves.

## 2. Construct the two complementary root paths

Use the first root's trap closure and the second root's root-chord closure:

\[
\begin{aligned}
D_1&=(L_1\xrightarrow{\rm old}R_1,t_c,c,d,t_d,L_1),\\
D_2&=(L_2\xrightarrow{\rm old}R_2,L_2).
\end{aligned} \tag{3}
\]

Delete \(ux_2,x_3r_1\) from \(D_1\). Apart from the central edge \(x_2x_3\), the result is a path \(O_1\) from \(u\) to \(r_1\). Likewise, deleting \(r_2y_2,y_3v\) from \(D_2\) leaves \(y_2y_3\) and a complementary path \(O_2:r_2\to v\).

Let \(E_i\) contain the central old edge of every complete two-special leaf in \(O_i\), and let \(M_i\) contain its internal face matching edges. By Section 1, \(M_i\) is a matching of every special in \(O_i\) except its two terminal endpoints. Thus

\[
F_i=(O_i-E_i)\cup M_i \tag{4}
\]

has degree one precisely at those two terminals and degree two elsewhere. Moreover
\(F_i\cup E_i=O_i\cup M_i\) is connected because it contains the full old complementary path \(O_i\).

The general square-splicing lemma in this workspace applies to (4). Each complete two-special leaf has consecutive support \((h,s,t,j)\), removable rails \(hs,tj\), available ordinary chord \(hj\), and missing edge \(st\). Supports are disjoint and avoid the exceptional leaves. It gives spanning paths

\[
P_1:u\to r_1,\qquad P_2:r_2\to v. \tag{5}
\]

Here \(P_1\) covers \(V(D_1)\setminus\{x_2,x_3\}\), retains the terminal rails \(uH_1,J_1r_1\), and retains the complete consecutive trap path \(t_c-c-d-t_d\). The path \(P_2\) covers \(V(D_2)\setminus\{y_2,y_3\}\). Only complete-leaf rails were removed in these splices.

The ordinary chord \(H_1J_1\) is absent from \(P_1\). It was absent from the first trap closure, even when the exceptional leaf itself is the root, and no complete-leaf switch can add it. This is why the first trap closure was chosen.

## 3. Transfer the central cycle through the four-special leaf

In \(P_1\cup Z_0\), perform the explicit three-edge exchange

\[
\{uH_1,x_2x_3,J_1r_1\}
\longmapsto
\{H_1J_1,ux_2,x_3r_1\}. \tag{6}
\]

Deleting the two terminal rails from \(P_1\) leaves one \(H_1\)--\(J_1\) path plus isolated \(u,r_1\). Adding the available chord \(H_1J_1\) closes that path into a simple terminal-free cycle \(Z_1\). It retains the entire trap subpath \(t_c-c-d-t_d\).

Deleting \(x_2x_3\) from \(Z_0\) gives the path \(x_2,y_3,y_2,x_3\). The other two added edges yield

\[
R=(u,x_2,y_3,y_2,x_3,r_1). \tag{7}
\]

Thus \(Z_1,R,P_2\) are vertex-disjoint except for no overlaps at all: their vertices partition \(D_1\cup D_2\). Their four terminal endpoints are exactly \(u,r_1,r_2,v\). This is the one-residual-cycle interface of Note 773, with the other root using its root chord. The isolated central cycle itself had no root anchor, so merely applying Note 773 before exchange (6) would have been invalid.

## 4. Explicit marked Hamilton closure

For completeness the final closure does not require accepting Note 773 as a black box. Delete \(t_cc\) and \(dt_d\) from \(Z_1\). Because its trap path is consecutive, the result is the edge \(cd\) and a path \(Q_1:t_d\to t_c\) on all its other vertices.

The following disjoint exterior paths have endpoint pairing \((u,v)(r_1,r_2)\):

\[
\begin{aligned}
A_0&=(u,w_0,\beta,\alpha,a,t_a,w_*,v),\\
A_1&=(r_1,z_1,t_c)\cdot Q_1^{-1}\cdot
       (t_d,d,c,b,t_b,z_2,r_2).
\end{aligned} \tag{8}
\]

All seams in (8) are present old edges or specified site, exposed, closing or trap edges. The two paths cover \(Z_1\) and all vertices outside \(D_1\cup D_2\), including the two vertices \(c,d\) separated when forming \(Q_1\). Their interiors avoid \(R\cup P_2\).

The internal pairing of \(R,P_2\) is \((u,r_1)(r_2,v)\), distinct from the exterior pairing. Therefore

\[
u\xrightarrow{R}r_1\xrightarrow{A_1}r_2
\xrightarrow{P_2}v\xrightarrow{A_0^{-1}}u \tag{9}
\]

is one Hamilton cycle. It contains \(w_0u\) and \(vw_*\). This is also Note 773's single-first-root-cycle formula (7), with its required cycle actually constructed rather than presumed.

## Scope and evidence

The weakest interface is the forced central matching in Section 1, which explicitly uses the four attachments, consecutive exceptional leaf words, all other specials in complete two-special leaves, and the occupied hexagon edge \(\alpha\beta\). No inference from root count or a charge equality was used. The square splicing step requires the disjoint complete-leaf supports and was checked in its two-terminal form. Exchange (6) handles the singleton exceptional-root case because the first closure is a trap closure.

The 26-vertex witness from the second round has precisely the forced matching (1), with no other complete leaves. It is therefore included as a special case of this analytic proof; it is neither a Hamiltonicity counterexample nor an additional computation here. No new script or search was run.

This establishes only the explicitly selected terminal-position profile, not all two-four-special-leaf arrangements or Barnette's conjecture. A legal C4 child can then be lifted by Note 001 from the marked parent cycle, but child legality remains the supplied hypothesis. No novelty or permanent promotion is claimed, and this same-model review does not satisfy different-source external review.

## Bounded check of the separate formal manuscript

I read `barnette-round3-terminal-aligned-four-special-leaves.md` after it was supplied by the controller. Its exact hypotheses explicitly include the actual face-page matching edge \(\alpha\beta\), the complete decomposition of all other vertices and matching endpoints, the ordinary root chords, and the entire six-vertex exceptional leaf words. Those hypotheses suffice for the statement that the central region has no other free face endpoints.

The two outer-path constructions and their degree patterns are valid. Restoring the complete-leaf old edges yields a connected graph in each root; disjoint square supports preserve the exceptional endpoint rails and complete first trap. The three-edge exchange is valid, including when the exceptional leaf is itself the first root, since the trap closure omits its ordinary chord. The displayed \(A_0,A_1\) use actual graph edges and cover the residual cycle and all outside vertices exactly once. I found no substantive mathematical gap in those four interfaces. The arbitrary-depth conclusion rests on this analytic construction; the small example is an illustration.

One local wording correction was reported to the controller: the two-terminal square fact says “missing st in the graph.” It must say that \(st\) is an edge of the ambient graph absent from \(F\), since it is restored by the switch. The preceding definition of \(E_i\) already supplies \(st\in E(G)\), so the error is in the abstract fact's wording, not the actual construction. Acceptance of the formal text is subject to that correction. No manuscript or earlier packet was edited by this reviewer.
