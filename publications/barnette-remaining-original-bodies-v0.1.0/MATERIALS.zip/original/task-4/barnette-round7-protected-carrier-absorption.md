# A protected carrier absorbs adjacent fat leaves and two external terminal leaves

2026-10-03. Seventh bounded round. Private conditional candidate; rounds 1–6 and the original unit remain read-only. No claim to solve Barnette's conjecture, to establish novelty, or to supply different-source validation. This round uses hand derivations and an explicit hand certificate, with no new search or finite-computation run.

**Result.** Close the exterior terminal paths first, obtaining a carrier cycle. Ordinary leaves then merge two distinct cycles, and a fully split four-special leaf merges three distinct cycles. This one framework absorbs the four adjacent-terminal profiles of round four and a different distribution: both physical terminals of the first root lie in distinct ordinary leaves straddling its nonterminal fat leaf. In the latter distribution, central matching parity excludes every unsupported special cycle. All actual face-page matching edges and all four trap edges survive, a stronger protection statement than retaining only the two marked sites.

## Exact ambient model

Let G be a finite simple three-connected cubic bipartite plane graph with specified Hamilton circle

\[
C=(w_0,t_d,W_1,t_c,z_1,z_2,t_b,W_2,t_a,w_*,\alpha,a,b,c,d,\beta,w_0).
\]

All displayed vertices are distinct. Each W_i is a consecutive word with endpoints L_i,R_i. Its matching M=E(G)\E(C) is divided between the two Jordan disks of C; endpoints of two matching edges on the same page never alternate. Require actual face-page matching edges w0-u, r1-z1, z2-r2, v-w*, alpha-beta and opposite-page trap edges td-d, tc-c, tb-b, ta-a. The marked sites are w0-u and v-w*.

All other opposite matching edges are ordinary chords within the two W_i, forming laminar interval forests with exactly one root [L_i,R_i] and actual root chord L_iR_i in each word. All remaining face matching endpoints are specials assigned to their innermost containing ordinary interval. There are no other vertices or matching endpoints. Nonleaf nodes have no directly assigned specials. Each root has one four-special leaf, with entire old-C word (h,p1,p2,p3,p4,j) and ordinary chord hj; every other leaf has entire word (h,s,t,j) and ordinary chord hj. Distinct leaf supports are vertex-disjoint. The profile is an additional hypothesis, not a consequence of two roots, B order or m=f. Only actual realizations are asserted.

We treat two allocations under this common model:

* **Adjacent allocation:** both terminals u,r1 in root1 occupy slots (1,2) or (3,4) of its fat leaf, and both r2,v in root2 occupy slots (1,2) or (3,4). These are the four already-established adjacent profiles of round four.
* **Straddling allocation:** W1 has a complete leaf (hL,u,s,jL), then its wholly nonterminal fat leaf (h1,p1,p2,p3,p4,j1), then a complete leaf (hR,t,r1,jR). W2 has fat leaf (h2,r2,q2,q3,v,j2). Any number of other complete leaves may occur between or outside these designated leaves, subject to the full ambient hypotheses.

“Both terminals outside the fat leaf” refers precisely to u,r1 in W1. This theorem does not place all four physical terminals outside both fat leaves.

## Two elementary component certificates

For a complete ordinary leaf, if selected edges hj and st lie on two distinct cycles of a spanning 2-factor and rails hs,tj are absent, the inverse square

\[
\{hj,st\}\longmapsto\{hs,tj\}
\]

merges the two cycles. Removing one edge from each makes two paths; the two rails join them into one cycle. Degrees and vertex coverage are preserved.

For a fully split fat leaf, if selected edges hj,p1p2,p3p4 lie on **three distinct cycles**, and hp1,p2p3,p4j are absent, the inverse fat exchange

\[
\{hj,p_1p_2,p_3p_4\}\longmapsto\{hp_1,p_2p_3,p_4j\}
\]

merges all three. The opened paths have endpoints h,j; p1,p2; p3,p4. The new edges connect them cyclically, in that order. This is an elementary three-component proof, not an assumption about a same-component exchange.

Let P consist of **all actual face-page matching edges plus the four trap matching edges**. Neither exchange removes a P edge: hj is an ordinary opposite-page chord and st,p1p2,p3p4 are old-C edges. Thus whenever the initial factor contains P, every resulting factor contains P. Disjoint supports also preserve the selected edges needed by later exchanges.

## Common ordinary and exterior construction

Use the two trap cycles

\[
D_1=(L_1\xrightarrow C R_1,t_c,c,d,t_d,L_1),\qquad
D_2=(L_2\xrightarrow C R_2,t_a,a,b,t_b,L_2).
\]

In each, directly replace every complete-leaf segment h-s-t-j by its ordinary chord hj. For a fully split fat leaf likewise replace h-p1-p2-p3-p4-j by hj. These replacements define the ordinary cycles B_i: each contains every ordinary endpoint in its root and its whole trap, and contains no special. This is direct subgraph selection; it does not assert sequential valid switches on C. The separately selected special edges are normal st and fully split fat p1p2,p3p4, together with all nonterminal face matching edges.

The exterior paths

\[
E_0=(u,w_0,\beta,\alpha,w_*,v),\qquad E_1=(r_1,z_1,z_2,r_2)
\]

are actual and cover exactly the six vertices outside D1 and D2. Once there are disjoint special/backbone terminal paths with pairings (u,r1),(r2,v), their union with E0,E1 is one carrier H0. The remaining ordinary and special cycles are disjoint from it. This factor includes all of P. The following applications prove the relevant component certificates from their allocations.

## Adjacent allocations: two three-cycle merges

In each fat leaf the adjacent terminal pair selects one of p1p2,p3p4; the other selected pair x_i y_i is nonterminal. The distinguished attachment chords close the four peripheral intervals (w0,u),(r1,z1),(z2,r2),(v,w*). No unoccupied face matching endpoint lies in the complementary central region, because neither adjacent terminal pair has a special between its terminals. Noncrossing therefore confines every nonterminal face edge to one peripheral region, hence to one root.

Select each root's terminal-pair edge as its short terminal path. In the remaining special graph every vertex has degree two, so it is a union of cycles. Let C_i contain x_i y_i. It cannot be a two-vertex cycle since G is simple; with only that nonterminal fat pair available in the root, it contains at least one ordinary-leaf st. Root confinement implies C1 and C2 are different cycles.

The two terminal-pair paths and E0,E1 make H0. The full split state is H0, the ordinary cycles B1,B2, and the special cycles. In root1 the fat chord lies on B1, its terminal pair on H0, and its nonterminal pair on C1: three distinct cycles. The inverse fat exchange merges them into the carrier. In root2 the analogous three cycles are B2, the enlarged carrier, and C2, which the root1 exchange did not touch. A second inverse fat exchange merges these.

Every remaining special cycle has an ordinary-leaf st. Its ordinary hj now lies on the carrier. Choose one such support per remaining cycle and apply the inverse square. Supports are disjoint, so every chosen st remains on its own cycle and every hj remains on the carrier until used. This absorbs all cycles into one Hamilton cycle containing P. All four choices of the two adjacent slot allocations obey this argument. No matching-direction assumption is added to the round-four hypotheses.

## Straddling allocation: central parity removes the fat obstruction

Fully split the first fat leaf and all complete leaves. Their ordinary endpoints form B1 as above. In root2 first fully collapse its fat leaf into h2j2, giving the ordinary trap cycle Q2; delete h2j2 and add its two actual outer rails h2-r2 and j2-v. This gives an ordinary path B2:r2 to v containing every root2 ordinary endpoint and its whole trap. Select q2q3 separately.

Let T select every normal st (including u-s and t-r1), the first fat pairs e1=p1p2,e2=p3p4, q2q3, and every nonterminal face matching edge. Its only degree-one vertices are u and r1. Thus it consists of one simple S:u to r1 and disjoint simple cycles. S,B2,E0,E1 make H0. Together with B1 and the T cycles they give a spanning 2-factor containing P.

We prove that **every T cycle contains a normal st**. An unsupported cycle would use only p1,p2,p3,p4,q2,q3, and alternates selected old pairs with matching edges. One pair alone cannot form a simple cycle. If it uses both first-fat pairs and no q pair, noncrossing on p1,p2,p3,p4 forces either matching p1p2,p3p4 or p1p4,p2p3, each containing a forbidden duplicate of an old edge. If it uses all three pairs, a noncrossing matching on the ordered six fat vertices must contain a consecutive pair in the displayed **linear** order (choose a chord with a shortest enclosed interval). All such pairs except p4-q2 duplicate old-C edges. With p4-q2 removed, the remaining four in order p1,p2,p3,q3 must match either p1p2,p3q3 or p1q3,p2p3, again a forbidden old edge. Thus only a four-cycle using e1 or e2 and q2q3 could remain.

The actual attachment barriers reduce the central unoccupied face endpoints, in order, to

\[
s,\ (2k\text{ normal specials}),\ p_1,p_2,p_3,p_4,\
(2\ell\text{ normal specials}),\ t,q_2,q_3.
\]

Every peripheral interval is closed under its unoccupied face matching, so these central endpoints carry a noncrossing perfect matching among themselves. Every chord in such a matching joins opposite ranks: the endpoints it encloses must be internally perfectly matched, hence their number is even. Here p1,p3,q3 have even ranks, and p2,p4,q2 have odd ranks. The only noncrossing matching of a putative four-cycle on p1,p2,q2,q3 is p1-q3,p2-q2; for p3,p4,q2,q3 it is p3-q3,p4-q2. Both require same-rank matching edges. They are impossible. This parity is a consequence of the exact first/last marked-leaf slots, not a freely imposed matching condition. Every T cycle is therefore normal-supported.

First use the marked-left square: hL-jL lies on B1 and u-s lies on the carrier's S. Its inverse merges B1 into H0. Every remaining T cycle now has a normal st whose ordinary hj is on the enlarged carrier, in either root. Choose one support per cycle and absorb it by an inverse square. The marked-left support cannot be chosen again: its old pair was on S, not on a cycle. Other supports are disjoint. The result is one Hamilton cycle containing all of P. No fat exchange or unsupported-cycle case is needed in this new allocation.

## Nonempty hand certificate, without a computation run

Take C=(0,1,...,41,0), and the following perfect matching; the graph is exactly C union these edges.

```text
face: (0,5) (20,25) (26,29) (32,35) (36,41)
      (6,11) (12,31) (13,30) (14,19)
opposite traps: (1,40) (24,39) (27,38) (34,37)
opposite ordinary: (2,23) (3,8) (4,7) (9,16)
                   (10,15) (17,22) (18,21) (28,33)
```

Each vertex occurs once in the matching; all endpoint differences are odd and none is a C neighbor pair. Both pages are nested or disjoint, giving a simple cubic bipartite plane graph. Root1 [2,23] has unary wrappers [3,8],[9,16],[17,22] respectively containing leaves [4,7],[10,15],[18,21]. These are the marked-left ordinary, wholly nonterminal fat, and marked-right ordinary leaves. Root2 [28,33] is the second fat leaf. Thus (u,s,p1,p2,p3,p4,t,r1,r2,q2,q3,v)=(5,6,11,12,13,14,19,20,29,30,31,32). The outside labels are w0=0,td=1,tc=24,z1=25,z2=26,tb=27,ta=34,w*=35,alpha=36,a=37,b=38,c=39,d=40,beta=41.

For three-connectivity there is a hand-checkable spanning tree of the matching interlacement graph (two nodes are adjacent exactly when their endpoint pairs alternate around C). Name chords

```text
Fa=(36,41); D=(1,40); Cc=(24,39); B=(27,38); A=(34,37);
Fq=(0,5); Fr=(20,25); Fz=(26,29); Fp=(32,35);
O=(2,23); UL=(3,8); KL=(4,7); X=(6,11); UF=(9,16);
KF=(10,15); Y=(14,19); UR=(17,22); KR=(18,21);
Z=(12,31); V=(13,30); O2=(28,33).
tree edges:
Fa-D Fa-Cc Fa-B Fa-A; D-Fq Cc-Fr B-Fz A-Fp;
Fq-O Fq-UL Fq-KL; UL-X X-UF X-KF; UF-Y Y-UR Y-KR;
Cc-Z Cc-V Fz-O2.
```

These 20 alternating pairs connect all 21 matching nodes. A Hamilton circle excludes bridges. A two-edge cut would have to delete two C edges and delimit a proper matching-closed interval; the matching interlacement graph would then be disconnected. Thus the graph is three-edge-connected. In a simple cubic graph this implies three-vertex-connectivity: a cut vertex would require at least three edges into each separated component, exceeding degree three. For a two-vertex cut, each component requires at least three attachments; cubicity forces two components with exactly three each and nonadjacent cut vertices. Each cut vertex meets both components, with distributions 1+2 and 2+1. Adjoining the vertex having two attachments to a component creates a two-edge cut, contradiction. This supplies actual Barnette membership without a deletion census.

The common site face is (0,5,6,11,12,31,32,35,36,41,0), and its arc (35,36,41,0) borders the chord-free hexagon (36,37,38,39,40,41). No separate C4 child legality claim is made.

Here T is the single path

\[
S=(5,6,11,12,31,30,13,14,19,20).
\]

B2=(29,28,27,38,37,34,33,32). A single inverse marked-left square produces the explicit Hamilton cycle

```text
(5,4,3,2,1,40,39,24,23,22,21,18,17,16,15,10,9,8,7,6,
 11,12,31,30,13,14,19,20,25,26,29,28,27,38,37,34,33,32,
 35,36,41,0,5).
```

This certificate is reproduced by checking the listed edges, endpoint alternation, degree partition and displayed cycle by hand. It is one positive realization, not a graph-size minimum, a census, a computational test result, or evidence that arbitrary forests are realizable.

## Sharp local obstruction and the stopping boundary

The distinct-component condition cannot be dropped. In the simple bipartite selected cycle

\[
F=(h,j,a,b,t,s,c,d,h),
\]

give h,a,t,c one color and j,b,s,d the other; include actual unused rails hs,tj. Both selected hj and st are on the same cycle. The inverse square replaces them by hs,tj and yields two cycles (h,s,c,d,h) and (j,a,b,t,j). Thus a blind inverse square can split the carrier instead of absorbing a residual circle. Eight vertices are the minimum for this local simple bipartite splitting witness, since both resulting cycles need length at least four. This is a local exchange counterexample, not a Barnette-conjecture counterexample.

The exact recovery condition for the elementary absorption rule is a current component certificate: two distinct cycles at an ordinary support, or three distinct cycles at a fully split fat support, including a route into the carrier. More abstractly, contract current factor cycles and certify an absorption order in which each chosen support meets the required distinct components; merely naming a leaf or observing a matching edge is insufficient. The two allocations proved here supply that certificate internally. We do not extend this route beyond its certified component conditions.

All four physical terminals outside both fat leaves, different slots in marked ordinary leaves, nonleaf terminals, extra exceptional leaves, overlapping supports and extra exposed components remain unproved. The wholly outer-terminal profile of rounds three/six also is not asserted to satisfy this fully split three-distinct-cycle construction; it used a different controlled interface. A general endpoint theorem would have to prove its component/attachment conditions, not append another placement table. No unreviewed broader assertion enters a formal source theorem register.

Fresh-context same-model review is recorded separately, including its initial weaker unsupported-cycle classification and the parity strengthening. Authorship, license, AI attribution, priority review and different-source validation remain unresolved. This private candidate was not uploaded, signed, published or assigned a DOI.
