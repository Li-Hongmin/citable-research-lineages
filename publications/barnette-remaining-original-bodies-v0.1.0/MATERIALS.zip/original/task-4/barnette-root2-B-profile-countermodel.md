# A 26-vertex B-order two-root opening with four-special leaves

2026-10-03. Self-contained countermodel to a profile implication, not to Barnette's conjecture or to the conditional theorem of Note 914. The example was independently constructed in a fresh same-model context and then checked by a separate standard-library implementation. No novelty claim is made.

## Exact statement refuted

The following implication is false: a selected chord-free single-hexagon B-order opening with exactly two ordinary roots, four distinct physical terminals in the roots and \(m=f\) must have its assigned special positions in complete two-special leaves apart from two marked nodes with two direct specials each.

The broader implication that B-order and two roots alone force every leaf to have two direct specials is therefore also false. This does not refute a theorem which expressly assumes that special-position profile, same-root adjacent exposed mates, or other additional restrictions.

## Complete graph and embedding

Let the Hamilton circle be \(C=(0,1,\ldots,25,0)\). Add the perfect matching with these two page assignments:

\[
M_f=\{03,16\,19,20\,25,69,10\,13,4\,15,5\,14\},
\]

\[
M_o=\{1\,24,8\,23,11\,22,18\,21,27,12\,17\}.
\]

Each concatenation denotes an unordered pair of the displayed integers; e.g. \(03=\{0,3\}\), \(27=\{2,7\}\). For an unambiguous machine-readable representation, the edge lists are

```text
face page:     (0,3) (16,19) (20,25) (6,9) (10,13) (4,15) (5,14)
opposite page:(1,24) (8,23) (11,22) (18,21) (2,7) (12,17)
```

Draw the two sets as chords of the two disks bounded by C. Each set is noncrossing: its chord intervals are nested or disjoint. The matching uses every vertex exactly once, each pair has odd index difference, and no pair duplicates a circle edge. Thus the graph is simple, cubic, bipartite and plane. Colour i by i modulo 2.

Choose site edges q=(0,3), p=(16,19). They share the face whose cyclic boundary is

\[
(0,3,4,15,16,19,20,25,0).
\]

One residual facial arc is \((19,20,25,0)\), alternating circle, matching, circle. It traps the old six-vertex segment \((20,21,22,23,24,25)\), closed by \((20,25)\). The other residual arc is \((3,4,15,16)\). No internal matching chord lies among 21,22,23,24: they match to 18,11,8,1 respectively. Thus the trap is chord-free.

Use the names

|Circle index|Name|
|---|---|
|0,1|w0, td|
|2,3,4,5,6,7|H1, u, s1, s2, r1, J1|
|8,9,10,11|tc, z1, z2, tb|
|12,13,14,15,16,17|H2, r2, t2, t1, v, J2|
|18,19|ta, w*|
|20,21,22,23,24,25|alpha, a, b, c, d, beta|

The exact old order is therefore

\[
w_0,t_d,W_1,t_c,z_1,z_2,t_b,W_2,t_a,w_*,\alpha,a,b,c,d,\beta,
\]

with \(W_1=[2,7]\), \(W_2=[12,17]\). The four terminals are \(u=3,v=16,r_1=6,r_2=13\), distinct and inside roots. The exposed attachments are \((9,6),(10,13)\).

After removing the four trap-escape chords from \(M_o\), the only remaining ordinary chords are \((2,7),(12,17)\). Both are maximal and are leaves of the ordinary forest. Their directly assigned specials are, respectively, \(3,4,5,6\) and \(13,14,15,16\): **four per leaf**. The four additional face-page main chords are \((6,9),(10,13),(4,15),(5,14)\), so \(f=4\). All eight assigned specials are in the roots, giving \(m=8/2=4=f\).

## Analytic three-connectivity certificate

Consider the interlacement graph on the 13 matching chords, joining two chords when their endpoints alternate on C; crossings here refer to abstract boundary interlacement, not two edges on the same page. This graph is connected. A concrete spanning tree is given by the following interlacements:

\[
\begin{array}{l}
(20,25)\text{ with }(1,24),(8,23),(11,22),(18,21);\\
(1,24)\text{ with }(0,3),\quad(18,21)\text{ with }(16,19);\\
(0,3)\text{ with }(2,7),\quad(16,19)\text{ with }(12,17);\\
(2,7)\text{ with }(6,9),(4,15),(5,14);\\
(12,17)\text{ with }(10,13).
\end{array}
\]

A bridge is impossible because C spans all vertices. If a two-edge cut existed, the Hamilton circle would cross it an even positive number of times, hence both cut edges would be circle edges. The isolated vertex set would be a proper consecutive circle interval closed under the matching. Every matching chord would then lie entirely in that interval or in its complement; a chord on one side cannot interlace one on the other. Both sides contain matching chords because the matching is perfect and the vertex sets are nonempty. This contradicts the connected interlacement graph. Thus the graph is three-edge-connected.

For completeness, a simple cubic three-edge-connected graph is three-vertex-connected here. A cut vertex would separate at least two components, each requiring at least three incident edges, exceeding its degree. If x,y formed a two-vertex cut, each component of G-x-y would require at least three edges to x,y. The combined degree bound forces x,y to be nonadjacent and exactly two components with three edges each. Since neither x nor y is a cut vertex, the attachments to either component split as 1+2. Adjoining the vertex with two attachments to that component leaves only two outgoing edges, contradicting three-edge-connectivity. This proves the required Barnette membership.

## Reproduction and site legality

Run `python3 verify_barnette_profile_countermodel.py > barnette-profile-countermodel-check.json`. Python 3.14.7, standard library only. The script constructs this one graph, checks its matching, degree and colouring, the absence of same-page interlacements, and an explicit rotation system with all face cycles and Euler characteristic 2. It checks connectivity after all 352 deletions of zero, one or two parent vertices, independently confirming three-vertex-connectivity. It also checks that the ordinary forest consists of the two leaves with direct counts (4,4).

To validate the selected site rather than presume its legality, it deletes (0,3),(16,19), adds vertices 26,27,28,29 and edges

\[
(0,26),(26,27),(27,3),(16,28),(28,29),(29,19),(26,29),(27,28).
\]

The new square has its four attachments in the cyclic port order 0,3,16,19 and embeds inside the displayed common face. With new colours 1,0,1,0, respectively, the child is simple, cubic and bipartite. All 466 deletions of at most two child vertices remain connected, verifying three-connectivity for this exact 30-vertex child. This is a finite check of a specified site, not a claim about every possible expansion or child Hamiltonicity.

The analytic parent proof does not depend on these finite connectivity tests. The finite child legality check is explicitly scoped to the given edge list, so it is an exact reproducible witness check, not an asymptotic inference.

## Boundary and objections

The exposed mates 6 and 13 lie in different roots. The graph lacks the same-root adjacent exposed pair and the two-direct-special marked-node profile required by Note 914. It therefore demonstrates failure of the proposed automatic profile inference and does not refute Note 914's conditional statement. It has the explicit Hamilton circle C, so it is plainly not a non-Hamiltonian Barnette counterexample. A more restricted reduction could still be valid, but must state the added conditions and account for this example.

Same-model independent-context construction and review are not different-model or human external verification. No priority, journal-level, public-license or author-identity assertion is made.
