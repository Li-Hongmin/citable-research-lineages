# A terminal in a preceding two-special leaf can be transported to a four-special leaf

2026-10-03. Fifth bounded round; separate private contribution candidate. The first four packets and original unit are unchanged. Same-model fresh-context review is not external validation. No priority or Barnette-conjecture claim.

**Result.** In the exact model below, the first site's terminal u is in a two-special leaf preceding the first four-special leaf, while r1 is that later leaf's last special. The second root has the outer-terminal four-special leaf. If the two marked leaves in the first root are consecutive in leaf order, every realization has a Hamilton cycle containing both sites. This adds a different solved profile to the rounds-three/four catalog: u is outside the exceptional leaf, so the earlier profile hypotheses do not hold here. The new interface is a protected terminal stem produced by a marked-leaf square, which then permits the fat-leaf anchor exchange.

## Model and forced matching

Let G be a finite simple three-connected cubic bipartite plane graph with a specified Hamilton circle

\[
C=(w_0,t_d,W_1,t_c,z_1,z_2,t_b,W_2,t_a,w_*,\alpha,a,b,c,d,\beta,w_0).
\]

All displayed vertices are distinct. W_i is a consecutive word from L_i to R_i. M=E(G)\E(C) is a perfect matching drawn on the two Jordan disks of C, with no alternating endpoints on either page. Require the actual face-page edges w_0u,vw_*,r_1z_1,z_2r_2,alpha-beta and opposite-page trap edges t_dd,t_cc,t_bb,t_aa. The marked sites are w_0u and vw_*. Alpha-beta is an actual matching edge, not inferred from cyclic order.

Every other opposite-page matching edge is an ordinary chord inside W_1 or W_2, forming laminar interval forests with exactly one root [L_i,R_i] per word and its chord L_iR_i. Every other face-page endpoint is an assigned special, assigned to its innermost containing ordinary interval. No other vertices or matching endpoints occur outside this decomposition. Nonleaf nodes have no directly assigned specials. Each root has exactly one four-special leaf; every other leaf has two specials, with entire old word (h,s,t,j) and ordinary chord hj. Leaf supports are vertex-disjoint.

The marked leaves have these **entire** words, in the indicated order:

\[
K_0=(h_0,u,s,j_0),\quad
K_1=(h_1,p_1,p_2,p_3,r_1,j_1)\quad\text{in }W_1;
\qquad K_2=(h_2,r_2,q_2,q_3,v,j_2)\quad\text{in }W_2.
\]

K0 and K1 are consecutive in leaf order: the old segment from j0 to h1 contains no assigned special. It may contain ordinary ends of enclosing intervals. Other complete two-special leaves may lie before K0 or after K1 in W1, and before or after K2 in W2. Ordinary wrappers/branching are allowed whenever the full input is realizable; no arbitrary-depth realizability is promised.

Each occupied face chord confines every unoccupied face matching endpoint in its interior boundary interval. Otherwise the two chords alternate; its own endpoints cannot be alternative mates. The four peripheral intervals (w0,u),(r1,z1),(z2,r2),(v,w*) are therefore closed under face matching. All their specials belong to complete two-special leaves. The remaining free central endpoints are precisely

\[
(s,p_1,p_2,p_3,q_2,q_3).
\]

Simplicity forbids matching old neighbors p1-p2, p2-p3 or q2-q3. For completeness, the five noncrossing perfect matchings on the six endpoints, numbered 1 through6 in the above order, are

\[
(12)(34)(56),\ (12)(36)(45),\ (14)(23)(56),\
(16)(23)(45),\ (16)(25)(34).
\]

All except the second contain one of the prohibited pairs 23,34,56. Hence the matching is uniquely forced:

\[
sp_1,\quad p_2q_3,\quad p_3q_2. \tag{1}
\]

The first edge does not duplicate an old edge: j0 and h1 intervene between s and p1. There is consequently no barrier/simplicity contradiction. The explicit graph below shows that the full Barnette hypotheses can actually be realized, not merely that these six pairs have consistent syntax.

## The new transport interface and Hamilton construction

Choose D1 as the first trap closure and D2 as the second root-chord closure:

\[
D_1=(L_1\xrightarrow{C}R_1,t_c,c,d,t_d,L_1),\quad
D_2=(L_2\xrightarrow{C}R_2,L_2).
\]

First cut D1 at us,p1p2,p3r1 and D2 at r2q2,q3v. The central old edges, together with the two cross edges in (1), form Z=(p2,p3,q2,q3,p2). In D1's remaining vertices, the edge sp1 closes the old path s-to-p1 into a cycle Y. This path contains no assigned special other than its two ends, because K0,K1 are consecutive leaves. Its vertices include j0 and h1. The other old D1 piece is a path A:u to r1 containing the entire trap tc-c-d-td, both h0 and j1, and every other complete two-special leaf of W1. The remaining D2 piece is an old path O2:r2 to v containing all other complete two-special leaves of W2.

Delete the central old edge st at each unmarked complete two-special leaf in A or O2, and insert all matching edges at their specials. The barrier argument puts each matching edge wholly in the corresponding path's vertex set. This gives degree-one endpoints and degree-two elsewhere; restoring the deleted st edges restores the whole old path, so gives connectivity. The disjoint complete-leaf square switches hs,tj -> hj,st therefore produce spanning paths A':u to r1 and P2:r2 to v, preserving the trap and exceptional/marked-leaf rails.

Here is the square argument without a black box: contract components of the initial degree-pattern graph, which consists of one path and cycles. Restored st edges make the quotient connected. Root a spanning tree at the path and absorb cycles along tree edges. Each switch cuts one rail in the path and one in a cycle and joins crosswise, producing one larger path with the same terminals. Disjoint supports preserve subsequent rails and all other edges.

**Marked-leaf transport.** In A' union Y, remove h0-u and s-j0 and add h0-j0 and u-s. The ordinary chord h0j0 is absent: it was not used in the trap base, and no unmarked leaf switch can add it. The two removed rails lie in different components. Cutting s-j0 in Y gives the path beginning s,p1,h1 and ending j0. Cutting h0-u leaves u isolated and the rest of A' starting h0 and ending r1. The two added edges join these into one path P1:u to r1 with the protected beginning

\[
(u,s,p_1,h_1)
\]

and ending (j1,r1). It still contains the entire trap. This is an ordinary path-cycle square; no new square identity is claimed. What it supplies here is the previously missing terminal stem u-s-p1 leading into the exceptional leaf.

Ordinary unmarked-leaf switches alone could not have joined Y: Y has no support or deleted st edge belonging to those leaves. The marked-leaf exchange therefore supplies a bridge absent from that unmarked-square quotient, rather than assuming that the old two-fat opening was already connected.

**Terminal-stem version of the fat exchange.** The following elementary interface does not require the physical terminal to be the fat leaf's first special. Suppose a path P:u to r has beginning S followed by p-h and ends j-r, where S is a simple u-to-p stem, and a disjoint cycle is (x,y,b,c,x). Suppose the ambient edges hj,px,yr exist, with hj absent from P. Remove hp,xy,jr and add hj,px,yr. The middle h-to-j path of P closes with hj into a simple cycle. The stem S joins the opened cycle path (x,c,b,y) and then r, giving one terminal path. The two resulting objects partition the original vertices. Any prescribed subpath inside the middle h-to-j path is retained. The original endpoint-aligned exchange is the special case where S has length0; the interface here has the nontrivial stem (u,s,p1).

Apply it to P1 union Z, with p=p1,h=h1,x=p2,y=p3,b=q2,c=q3,j=j1,r=r1. The chord h1j1 was absent from D1 and remains absent after both sorts of square switches. The result is the path

\[
S_1=(u,s,p_1,p_2,q_3,q_2,p_3,r_1)
\]

and a terminal-free cycle Z1 retaining tc-c-d-td. Together S1,P2,Z1 partition D1 union D2.

Delete tc-c and d-td from Z1. This leaves edge cd and a path Q1:td to tc on its remaining vertices. The explicit exterior paths

\[
A_0=(u,w_0,\beta,\alpha,a,t_a,w_*,v),
\]
\[
A_1=(r_1,z_1,t_c)\cdot Q_1^{-1}\cdot
(t_d,d,c,b,t_b,z_2,r_2)
\]

have disjoint interiors avoiding S1 and P2, and cover all other vertices. Concatenation identifies seam endpoints once. Every seam is an actual old, attachment, closing or trap edge. In particular c,d are absent from Q1 and appear once in A1. The traversal S1 from u to r1, then A1 to r2, then P2 to v, then A0 reversed to u is one Hamilton cycle and contains both marked sites. Neither a previously recorded closure theorem nor a virtual cubic graph contraction is needed.

## Actual witness and limitations

An exact 36-point realization has C=(0,...,35), with

```text
face M: (0,5) (26,29) (30,35) (14,19) (20,23)
        (6,11) (12,25) (13,24)
opposite M: (1,34) (18,33) (21,32) (28,31)
            (2,17) (3,8) (4,7) (9,16) (10,15) (22,27)
```

In W1=[2,17], K0=[4,7] sits in wrapper [3,8], and K1=[10,15] sits in wrapper [9,16]. In W2=[22,27], K2 is the root itself. Thus u=5,s=6,p1=11,p2=12,p3=13,r1=14,r2=23,q2=24,q3=25,v=26. The outside labels are w0=0,td=1,tc=18,z1=19,z2=20,tb=21,ta=28,w*=29,alpha=30,a=31,b=32,c=33,d=34,beta=35. The site common face is (0,5,6,11,12,25,26,29,30,35,0), with actual arc (29,30,35,0) trapping the chord-free hexagon (30,31,32,33,34,35).

Its initial A=(5,4,3,2,1,34,33,18,17,16,15,14), Y=(6,7,8,9,10,11,6). The marked square gives P1=(5,6,11,10,9,8,7,4,3,2,1,34,33,18,17,16,15,14); P2=(23,22,27,26). The final marked Hamilton circle is

\[
(5,6,11,12,25,24,13,14,19,18,17,16,15,10,9,8,7,4,3,2,1,
34,33,32,21,20,23,22,27,26,29,28,31,30,35,0,5).
\]

`verify_barnette_round5_transport.py` checks this one specified graph's pages/rotation/colouring, assigned leaf words and common face, interlacement spanning-tree certificate and all deletions of at most two vertices, then the exact marked square, fat exchange, exterior coverage and final circle. It performs no graph search or parameter census. Interlacement connectedness also analytically certifies three-connectivity: a Hamilton circle rules out bridges, a two-edge cut would isolate a matching-closed old interval and disconnect interlacement, and simple cubic three-edge-connectivity implies three-vertex-connectivity by the degree/attachment argument. The raw output is `barnette-round5-transport-check.json`. The fixed witness establishes nonemptiness; the general conditional result is the analytic proof above.

No assertion is made that any chosen ordinary forest can be realized. In particular bipartiteness forces K0,K1's left ends to have the root's colour and hence even depth when nonleaf direct-special counts are zero; the witness uses depth2 for both, and depth0 for K2. These constraints are retained rather than hidden in “arbitrary wrappers.”

The selected result does not cover intervening complete leaves between K0,K1, r1 in other fat slots, a terminal assigned to a nonleaf, more exceptional leaves, or additional exposed components. Without consecutiveness, the six-endpoint classification changes, sp1 need not be forced, and the protected transport stem is no longer supplied by this proof. Ordinary square splicing remains a reused tool. The newly covered profile in these bounded rounds distributes the terminal across two consecutive leaves; the terminal-stem exchange lemma itself extends the earlier endpoint-only interface to a nontrivial stem. Novelty against the literature or all legacy notes has not been established. Different-source review, authorship and license remain unresolved; no publication action occurred.
