# Barnette B opening: an exposed adjacent pair cannot straddle one direct-position exception

2026-10-03. Bounded research derivation; the exclusion proof has passed one independent-context review using the same model. This file remains a candidate in the delegated task workspace, not a new project theorem or a claim to solve Barnette's conjecture. The review is not independent external or different-model review.

## Exact input and claim

Read the actual body of project Note 914, `notes/914-an-exposed-adjacent-pair-closes-any-second-two-direct-node-in-middle-gap.md`, whose title and theorem still impose the outside-enclosed-children condition. Keep all its setup, but temporarily omit only that position condition. In particular use Note 773's old Hamilton-circle order

\[
(w_0,t_d,W_1,t_c,z_1,z_2,t_b,W_2,t_a,w_*,\alpha,a,b,c,d,\beta,w_0).
\]

The four physical attachments are \(w_0u,vw_*,z_1r_1,z_2r_2\), lying on the common-face side of this circle; all four root terminals are distinct. A special position in a root has exactly one third edge on this side, either an attachment or an internal/cross-root face matching edge. Ordinary chords lie on the other side; in particular \(t_c,t_b\) have their third trap edges on that ordinary side and cannot be face-matching endpoints. Every special position other than \(s,t,r_1,r_2\) belongs to a complete two-special leaf, whose two positions are consecutive in its leaf interval. The distinct marked nodes assign \(s,t\) and the adjacent old-edge pair \(r_1,r_2\), respectively. Complete ordinary child intervals and leaves are laminar.

**Finite claim:** the old order \(s<r_2<r_1<t\) in either marked root is impossible. Therefore the exposed pair cannot occur inside a child enclosed between \(s,t\). This is an exclusion of a selected configuration, not a Hamiltonicity theorem by itself.

## Proof

The two exposed attachments have disjoint endpoints and do not cross. In \(W_1\), which precedes \(z_1,z_2\), their root order must be \(r_2<r_1\): the alternative boundary order \(r_1,r_2,z_1,z_2\) interlaces their endpoints. In \(W_2\), which follows \(z_1,z_2\), the alternative order \(z_1,z_2,r_1,r_2\) likewise interlaces them. Thus \(r_2<r_1\) in both roots. The assumed adjacent old edge leaves no root vertex between them.

Suppose first that the marked root is \(W_1\). Let \(I\) be the root tail strictly after \(r_1\). The common-face disk arc from \(r_1\) to \(z_1\), in old-cycle order, contains exactly this tail and the nonspecial trap target \(t_c\). The chord \(r_1z_1\) separates this arc from the remaining disk boundary. An edge from a special position \(x\in I\) to a boundary point outside that arc would interlace \(r_1z_1\). It cannot end at \(r_1,z_1\), whose third incidences are occupied; nor at \(t_c\), whose third edge is its ordinary trap chord on the opposite side. Hence every special position of \(I\) must be face-matched to another special position of \(I\). This also excludes physical terminals and cross-root ports in \(I\).

But \(s<r_2<r_1<t\) puts exactly one exceptional special position, \(t\), in \(I\). All other specials of \(I\) occur in complete leaf pairs. A complete leaf pair cannot straddle this cut: its interval is laminar with the marked-node interval, its two specials are consecutive, and \(r_1\) is assigned to the distinct marked node. Thus \(|S\cap I|=1+2m\) for some \(m\ge0\). A perfect matching on an odd set is impossible.

If the marked root is \(W_2\), use instead the root head \(I\) strictly before \(r_2\). The boundary arc from \(z_2\) to \(r_2\) consists of the nonspecial trap target \(t_b\) and this head. The chord \(z_2r_2\) traps every face edge at a head special; its endpoints and \(t_b\) cannot be its mate. Now \(I\) contains \(s\), excludes \(t,r_1,r_2\), and again contains otherwise whole leaf pairs. The same odd-cardinality contradiction applies. \(\square\)

No root-crossing-edge count, ordinary-depth bound, bipartiteness or three-connectivity is used in this last parity step. Cubicity/side assignment ensures a matching incidence at every root special. These hypotheses are not a license to omit the selected circle, common-face embedding, prescribed exposed attachments or complete-leaf-pair condition.

## Consequence and boundary

Conditional on the outside theorem of Note 914 and its Hamilton construction being correct, this exclusion removes its only uncovered relative placement under the above exact setup. The resulting candidate corollary would cover any relative placement of the two marked nodes and any number of whole children between \(s,t\), with the original all-leaf other root and all other specials in complete leaves. Do not delete the hypothesis in the old note until the Hamilton chain is accepted and the wider statement receives the required verification. Nonadjacent exposed mates, additional exceptional single positions, other openings, and general Barnette remain outside this result.

The parity lemma is elementary. No priority or novelty claim is made. A finite matching check tests this geometry only and cannot certify graph realization, three-connectivity, Hamiltonicity, or the entire cited proof chain.

## Reproduction and review

Run `python3 check_barnette_exposed_pair.py > barnette-matching-check.json` in this workspace. Python 3.14.7, standard library only. A Catalan interval recurrence counts noncrossing perfect matchings with fixed exposed attachments and both site ends restricted to root positions. It checks the two root placements and three orders of the tokens \(D=(r_2,r_1),s,t\), with at most three complete leaf pairs distributed among four marked-root gaps and at most three leaf pairs in the other root: 840 boundary configurations, at most 20 matching slots. All 280 `s-D-t` configurations have zero admissible matchings. Every outside-order category has positive matching controls; allowing crossings gives an explicit perfect-matching control in an inner configuration. These are abstract boundary matchings, not realized Barnette graphs.

The general conclusion follows from the separating-chord and odd-set proof, not from those finite counts. The independently implemented recurrence is a diagnostic cross-check; it does not replace an independent unbounded proof. The same-model reviewer read only the formal proof and accepted the finite exclusion under the declared model, suggesting the explicit trap-side condition incorporated above. See `barnette-independent-context-review.md`. This review did not establish the upstream selected-opening classification or literature novelty. Project Note 914 and its existing hypotheses were left unchanged.
