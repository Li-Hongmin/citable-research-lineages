# Split-leaf absorption gives a uniform terminal stem

2026-10-03. Sixth bounded round. Separate private candidate; earlier packets and the original source unit remain read-only. This is a conditional interface theorem, not a proof of Barnette's conjecture. No novelty/priority claim or different-source validation is made.

**Result.** In the model below, any number of complete two-special leaves may occur between the leaf containing u and the four-special leaf containing r1. A terminal stem always exists. Its matching need not follow the fixed six-port pattern used in the consecutive-leaf case. A direct split-leaf construction absorbs all supported special cycles; at most one unsupported four-cycle remains, and a single fat exchange handles it. The construction thus replaces an unbounded matching case analysis by one path/cycle test.

## Exact model and statement

Let G be a finite simple three-connected cubic bipartite plane graph with specified Hamilton circle

\[
C=(w_0,t_d,W_1,t_c,z_1,z_2,t_b,W_2,t_a,w_*,\alpha,a,b,c,d,\beta,w_0).
\]

All displayed vertices are distinct. W_i is a consecutive word from L_i to R_i. The complement M=E(G)\E(C) is a perfect matching on the two Jordan disks of C, with nonalternating endpoints on each page. Require actual face-page edges w0-u,v-w*,r1-z1,z2-r2,alpha-beta and opposite-page trap edges td-d,tc-c,tb-b,ta-a. The marked sites are w0-u and v-w*. Alpha-beta is an actual matching edge, not inferred from order.

All other opposite matching edges are ordinary chords inside W1 or W2, forming laminar interval forests with exactly one root [Li,Ri] and its chord LiRi in each word. All other face matching endpoints are assigned specials in these roots, assigned to their innermost containing ordinary interval. There are no other vertices or matching endpoints outside this decomposition. Nonleaf ordinary nodes have no directly assigned specials. Each root has exactly one four-special leaf and every other leaf has entire word (h,s,t,j) with ordinary chord hj. Distinct leaf supports are vertex-disjoint.

In W1 the entire four-special word is (h1,p1,p2,p3,r1,j1). Either u=p1, or u is the first special of a two-special leaf (h0,u,s,j0) before that exceptional leaf. There may be **arbitrarily many** complete two-special leaves between these two designated leaves, as well as before and after them. In W2 the entire exceptional word is (h2,r2,q2,q3,v,j2). The four physical terminals u,r1,r2,v are distinct. All other leaf words and ordinary wrappers are unrestricted subject to actual realization of the full hypotheses.

**Uniform terminal-stem theorem.** Every graph satisfying this profile has a Hamilton cycle containing both marked sites. The proof supplies a stem from u to p1, possibly length0, and a rule deciding whether a fat exchange is needed. No fixed partner for s, p1, p2 or p3 is assumed. In particular it does not infer this profile from two roots, B order or m=f.

## Split-leaf interface and supported-cycle absorption

For every complete two-special leaf (h,s,t,j), select its ordinary chord hj and old special-pair edge st, and omit its rails hs,tj. This is a **direct choice of subgraph**, not a claim that all squares may be sequentially applied to the original Hamilton circle. The two unused rails are actual ambient edges, available for the inverse operation below.

Let T be the special subgraph consisting of every such st edge, the two old fat middle edges p2p3 and q2q3, and every matching edge between nonterminal root specials. Include u,p1, but exclude r1,r2,v; the four external terminal attachments are not part of T. If u differs from p1, the only degree-one vertices of T are u and p1: u has its complete-leaf pair edge but no internal matching, whereas p1 has its matching but no chosen fat pair edge. All other vertices have degree2. Thus

\[
T=R\ \dot\cup\ C_1\ \dot\cup\cdots\dot\cup C_m,
\]

where R is one simple u-to-p1 path and the Ci are vertex-disjoint simple cycles. If u=p1, include it as an isolated vertex, regard it as the length0 stem R, and all other components are cycles. Simplicity makes the selected graph simple: a matching edge cannot duplicate a chosen old neighbor edge.

Choose the first trap base D1=(old L1 to R1,tc,c,d,td,L1). After cutting its fat edges p1p2,p3r1, its complementary old arc is the simple p1-to-r1 path through h1 and j1 containing the entire first trap. In this arc replace every complete two-special segment h-s-t-j by its chord h-j. The result is an ordinary backbone B1:p1 to r1, starting p1-h1 and ending j1-r1. It contains all ordinary endpoints and first trap vertices, and no complete-leaf specials. Every ordinary complete-leaf chord of W1 appears exactly once in B1. Its interior excludes p2,p3.

For the second root choose either its root-chord base D2=(old L2 to R2,L2), or its trap base D2=(old L2 to R2,ta,a,b,tb,L2). Cut r2q2,q3v, and compress each complete two-special segment to its ordinary chord in the complementary old arc. This gives B2:r2 to v, starting r2-h2 and ending j2-v. All W2 complete-leaf chords appear exactly once in B2; its interior excludes q2,q3. Changing the second base does not change T or R.

The paths P1=R followed by B1, and P2=B2, are disjoint and have terminal pairs (u,r1) and (r2,v). Together with the Ci they cover D1 union D2. A chord hj for a complete leaf lies on exactly one backbone, and its pair edge st lies either on R or on exactly one Ci. This separation is the useful unified interface.

**Supported-cycle absorption lemma.** If a cycle Ci contains a complete-leaf edge st, choose that leaf and perform the inverse square

\[
\{hj,st\}\longmapsto\{hs,tj\}.
\]

The chord hj is on one terminal path, while st is on the disjoint cycle. The rails are absent, since their endpoints were in different components. Cutting the two selected edges and joining crosswise merges that cycle into the path, with unchanged endpoints. Choose one supporting leaf per cycle. The chosen supports are disjoint, so earlier operations affect none of the later selected chords or pair edges. Every cycle with a complete-leaf pair edge can therefore be absorbed.

No absorption removes an edge of R: the chosen st was on a cycle, and hj was on an ordinary backbone. The beginning R followed by p1-h1 and the end j1-r1 of P1 survive, with that order along the oriented path. Both trap subpaths survive whenever their bases were chosen. The first fat chord h1j1 remains absent, because no complete-leaf operation adds it. This proves protected stem transmission independently of the length, tree depths or matching pattern of the intervening leaves.

A cycle with **no** complete-leaf pair edge can use only the four remaining special vertices p2,p3,q2,q3. Each has its selected fat middle edge and matching edge. Matching cannot duplicate the two old middle edges, and a simple alternating cycle cannot have length2. Consequently the only possibility is one four-cycle Z. Noncrossing fixes its matching edges as p2q3,p3q2, hence

\[
Z=(p_2,p_3,q_2,q_3,p_2).
\]

There is at most one such unsupported cycle. Thus the construction leaves either two terminal paths alone, or two terminal paths and this one explicitly identified cycle. No enumeration or smoothing classification is required.

## Closing the two possible interfaces

If there is no unsupported Z, choose the second trap base before constructing B2. Supported-cycle absorption gives P1,P2 covering both trap bases. Their only missing vertices are w0,z1,z2,w*,alpha,beta. The exterior paths

\[
E_0=(u,w_0,\beta,\alpha,w_*,v),\qquad
E_1=(r_1,z_1,z_2,r_2)
\]

use actual edges and cover those six vertices once. P1, then E1, then P2, then E0 reversed is a Hamilton cycle through both sites. The supported cycles may contain central vertices from both roots; the proof needs the vertex partition, not root membership of each final path.

If unsupported Z exists, choose the second root-chord base. After absorption P1 is R followed by p1-h1, an h1-to-j1 middle path containing tc-c-d-td, and j1-r1. P2 covers the second base outside q2,q3. The stem R is disjoint from Z. Perform the fat exchange

\[
\{h_1p_1,p_2p_3,j_1r_1\}\longmapsto
\{h_1j_1,p_1p_2,p_3r_1\}.
\]

The middle h1-to-j1 path closes with the unused chord into a cycle Z1 retaining the entire first trap. The other new object is S1, the stem R followed by (p1,p2,q3,q2,p3,r1), identifying p1 once. S1,P2,Z1 partition both bases.

Deleting tc-c and d-td from Z1 leaves edge cd and a path Q1:td to tc on all other Z1 vertices. Use

\[
A_0=(u,w_0,\beta,\alpha,a,t_a,w_*,v),
\]
\[
A_1=(r_1,z_1,t_c)\cdot Q_1^{-1}\cdot
(t_d,d,c,b,t_b,z_2,r_2).
\]

The two exterior paths have disjoint interiors avoiding S1 and P2 and cover every remaining vertex. c,d occur once in A1 and not in Q1. All seams are actual old, attachment, closing or trap edges. S1, then A1, then P2, then A0 reversed gives one Hamilton cycle containing both marked sites. Choosing the second base adaptively is legitimate: T and the supported/unsupported cycle test are independent of that choice. This completes the theorem.

## What this compresses and what it does not

Round three is the length0-stem case u=p1; its outer-terminal leaf placement forces the unsupported Z branch. Round five with consecutive designated leaves has R=(u,s,p1) and the same branch. With intervening leaves, the stem may traverse their pair edges and even the fat middle vertices; the theorem uses the same split-leaf interface in all cases. The fifth-round consecutiveness assumption is therefore unnecessary for this specified terminal allocation.

For example, insert one complete leaf whose specials are x,y between s and p1. The central order is (s,x,y,p1,p2,p3,q2,q3). Both actual noncrossing matching patterns below avoid old within-leaf neighbors:

\[
M_A=\{sx,yp_1,p_2q_3,p_3q_2\},\qquad
M_B=\{sq_3,xp_2,yp_1,p_3q_2\}.
\]

With selected xy,p2p3,q2q3, the first gives R=(u,s,x,y,p1) and unsupported Z. The second gives R=(u,s,q3,q2,p3,p2,x,y,p1) and no unsupported cycle. This smallest insertion invalidates the old fixed equation sp1 in the second pattern, but it is not an obstruction to the uniform theorem. These are symbolic special-subgraph examples, not newly certified whole Barnette realizations or an exhaustive configuration search.

A supported loop is equally explicit: two inserted pair edges xy,zt and matching xt,yz form the cycle (x,y,z,t,x). A single inverse square on either supporting leaf absorbs it into an ordinary backbone, while preserving the stem. No loop census or separate loop-size induction is needed.

The cycle-absorption identity reuses ordinary square splicing. The substantive compression is the direct split state, the automatically existing protected stem, and the fact that unsupported cycles reduce to at most the one fat four-cycle. This replaces per-insertion matching analysis. The adjacent-terminal fat profiles of round four use different fat-pair openings and are not asserted to be instances of this theorem. Neither terminals on nonleaves, u in another slot, r1 in another fat slot, additional exceptional leaves, overlapping supports nor extra exposed hexagons are covered. Such changes may introduce more skeleton endpoints or unsupported cycles and would need a new interface.

The proof is analytic and uses no new finite computation, graph search or old-witness rerun. Previously sealed examples supply nonempty special cases; no realizability of arbitrary forests or prescribed matching patterns is promised. Same-model fresh-context review is recorded separately. Priority review, different-source verification, authorship and license remain unresolved. No publication or source theorem-register promotion occurred.
