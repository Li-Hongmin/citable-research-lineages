# Barnette bounded independent-context reviews

2026-10-03. Read-only review of project inputs; this report lives only in the delegated task workspace. Same-model independent context, not a different-model or independent external review. No project file, Git state, process, computation or publication was changed.

## Note 914 interface review

Verdict: conditionally accept the bounded proof chain under the selected B-order ordinary-word/common-face model. No substantive gap or counterexample was found. This review does not certify the upstream construction of that model or prove general Barnette.

The exact hypotheses are four distinct terminals; an adjacent real old edge joining the exposed pair at one marked node; a distinct node with exactly two direct specials s,t and only whole children between them; the exposed edge outside that subarc; all other specials in complete two-special leaves; the other root all-leaf. Child count, depth and root-crossing face matching are unrestricted.

The weakest step is the exclusion of a nonconsecutive terminal-free collection of enclosed children. Contract whole child intervals to ordered common-face boundary points, select a simple path in the component across two consecutive contacts, and push its interior into the disk. It separates the intervening block from the exterior. A face edge leaving the block either crosses the path or joins the component; a physical attachment also crosses. Ordinary chords remain internal to whole children. The intervening block has only two old boundary edges, contradicting three-edge connectivity. Note 901's local separation argument applies without its A/C-order exterior closure.

Complete-leaf square supports and old rails survive the marked cuts, so Note 458's component-tree switches apply. A terminal-free component must contain O and its complete trap path. Changing W to root-chord closure substitutes only its terminal-bearing closing path; the inserted child chords are proper even when N=W. Note 773's one-cycle covers therefore apply. With no terminal-free component, the exposed-pair component contains both A,B and hence W's trap path. Note 774's explicit exchange formulas apply irrespective of its overall theorem's zero-cross-root hypothesis. Note 001's marked-cycle lift then applies.

Minimal textual repair: deleting the single edge d from a cycle gives one path, not two arcs. State instead that deleting d and opening the s,t block leaves the closed children and complementary paths A,B, each with one exposed endpoint. Spell out the simple separating arc in the weakest step.

## Enclosed-pair candidate review

Input reviewed independently: `barnette-enclosed-pair-candidate.md`, including its formal setup and proof. Verdict: accept the finite exclusion under those exact hypotheses. No substantive gap or counterexample was found.

The noncrossing exposed attachments force r2 before r1 in either root. For W1, the boundary arc from r1 to z1 contains only the strict root tail and t_c. The attachment r1z1 blocks every common-face matching edge from a tail special to the complementary boundary. Its endpoints are occupied, and t_c's third edge is the opposite-side trap chord. Nonspecial root positions likewise have ordinary third edges on the opposite side. Thus tail specials form an internal perfect-matching set; no physical terminal or root-crossing port can occur there. For W2 the same argument uses the strict head and the separating attachment z2r2, with t_b excluded by its opposite-side trap chord.

The complete-leaf-pair condition is sufficient. A leaf pair cannot cross the cut at a direct special of the distinct marked node: whole leaf intervals are laminar ordinary leaves, cannot contain that node or its direct special, and their two positions are consecutive. Hence the W1 tail contains exactly t plus whole pairs, while the W2 head contains exactly s plus whole pairs. Each set is odd, contradicting the internal perfect matching. The parity step needs neither bipartiteness nor three-connectivity.

No mathematical repair is required. A useful clarification is to include explicitly in the formal setup that t_c and t_b have their third trap edges on the ordinary side, as used in the proof and inherited from the selected B model.

The merged Hamiltonicity consequence remains conditional on Note 914's Hamilton construction and the selected model. Adjacency and distinct assignment mean the exposed edge cannot partially cross an s,t boundary: its endpoints are both inside or both outside. The accepted finite exclusion rules out the inside case. It does not extend to nonadjacent exposed mates or extra exceptional specials. This same-model review is not the required different-source review for permanent theorem promotion.
