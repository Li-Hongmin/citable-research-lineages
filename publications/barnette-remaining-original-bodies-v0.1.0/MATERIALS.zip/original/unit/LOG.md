# Barnette controller log

## 2026-09-10 — R1 pulse 1

Ran a full-text decision search for Kao--Chen 2005, Florek, and Schnieders
2025. Accessible full texts rule out containment by the cited Florek and
Schnieders results at the global ordered-edge-pair and same-order
nonisomorphic-count quantifiers. The Kao--Chen publisher record and metadata
were located, but the lawful full text requires authentication and no OA copy
was found. The precise theorem-level comparison boundary is recorded in
`advisor/REQUEST.md`; no novelty verdict is inferred from the abstract.

Repository-control caveat: this AIMath directory has no `AGENTS.md`, no git
metadata, no `ResearchLibrary`, and none of the four requested skill files was
present on the host. Consequently there was no lawful library-ingest target
and no repository in which to commit or push this pulse.

ROUTE=R1 PULSE=1 VERDICT=open

## 2026-09-11 — R1 pulse 2

Continued only at the Kao--Chen full-text comparison gate.  A fresh
title/DOI/Chinese-title/author-domain decision search found the publisher and
author records plus secondary citations, but no independently lawful complete
PDF or scan.  Therefore no theorem numbers, proof pages, figures, replacement
gadget, seed hypotheses, recursion quantifiers, joint ordered-edge-pair
property, or graph-enumeration statement can be verified.  In particular,
separate 1-edge fault Hamiltonicity and Hamiltonian laceability in the abstract
do not imply one joint containing/avoiding Hamilton cycle.

The exact external boundary is now frozen in `advisor/REQUEST.md`: obtain one
complete lawful scan of volume 33(1), pp. 11--19, with CiNii NCID `AN10510587`
and Iwate University's 33(1--3) holding as a concrete acquisition lead, then
audit all seven comparison quantities page by page.  The holding is not
mathematical evidence.  Containment remains UNDETERMINED, so neither GO nor
NOGO is issued.

Control caveat remains unchanged: this AIMath directory has no `AGENTS.md`, no
git metadata, no ResearchLibrary, and none of the four requested skill files
was present on the host.  Thus there was no lawful library-ingest target and no
repository in which to commit or push this pulse.

ROUTE=R1 PULSE=2 VERDICT=open

## 2026-09-12 — R2 pulse 1

Worked only on the cube CEN/UV word-to-unrooted-graph fibre.  Exact pynauty
canonicalization of every word through depth 12 gives class counts
`1,1,1,2,3,6,10,20,36,72,136,272,528`; at depth 12, 4096 words give 528
classes, with fibres of size 4 or 8.  Face-degree sequences are too coarse:
only 38 occur at depth 12 and one supports 85 canonical classes.  The finite
observation is stored under `scratch/` and is not used as a theorem.

Note 167 records the strict all-depth proof.  The rooted two-step delay
theorem makes each pointwise cube-rooted type receive exactly four words, and
an unrooted order-n graph supports at most `(n)_8` such types via injections of
the labelled old cube core.  Therefore every word fibre is at most `4(n)_8`,
and the image has at least `ceil(2^(k-2)/(n)_8) = 2^(n/4-O(log n))` pairwise
nonisomorphic global-H^{+-} Barnette graphs.  This proves R2 outcome (a); no
structural exponential collapse occurs.

Contribution verdict: at most B-level while R1 is unresolved and the theorem
remains confined to one fixed two-letter grammar.  The single missing A-level
increment is a uniform global-H^{+-} plus subexponential-fibre theorem for a
strictly larger intrinsic legal-successor subclass.  The cheapest upgrade
observation is a constant-size orbit/transfer classification of all legal
successor sites meeting the newest annulus, not an adjacent-order census.
This directory has no git metadata, so no commit was made.

ROUTE=R2 PULSE=1 VERDICT=proved

## 2026-09-12 — R2 pulse 2

Audited the exact upstream object used by Note 167.  Note 011 defines the
rooted type as the graph together with the old-core injection fixed pointwise,
and explicitly excludes both the raw history and the marked next successor
site.  Its ordered-boundary invariant and intrinsic peeling, now named
Theorem 011.1, prove the needed one-way implication
`rho_k(w)=rho_k(w') => w[1:k-2]=w'[1:k-2]`.  Extending the local isomorphism by
the identity on the eight old cube vertices, and restricting a cube-rooted
isomorphism to the four boundary vertices, identifies this with precisely the
cube-rooted object used in Note 167.  Thus every rooted word fibre is at most
four; the unused converse gives the stronger exact-four statement.

Note 167 now states the dependency by theorem number, equation range, object,
and direction, and writes the unrooting count exactly as `Aut(H)\I_H`, bounded
by `(n)_8`.  It also records the complete Note 011 text as a required
attachment in the next independent R2 verification package.  The counting
chain is therefore closed at the previously uncertified interface.

Added the scope limitation `pw(G_w) <= 7`: the initial cube is one bag, and
each later bag consists of the current four endpoints plus four new vertices.
All final edges occur in an introduction bag, while successor rules use only
the current endpoints and new vertices, so a vertex never returns after
leaving the active port.  Hence bag occurrences are intervals.  This bounded
pathwidth explains why the exponential family is not yet a broad structural
Barnette class.

No experiment was started.  A non-frozen, not-started structural-upgrade
candidate specification was drafted with an intrinsic nested four-port
annular class, at most three routes, mechanical go/no-go criteria, and the
required forbidden directions.  R1 remains untouched pending the external
library scan.  This directory has no git metadata, so no commit was made.

ROUTE=R2 PULSE=2 VERDICT=proved
UPGRADE_SPEC_DRAFT=SPEC-2026-09-12-upgrade-candidate.md

## 2026-09-12 — R2 pulse 3

Applied the GPT-6 Pro round-4 REVISE decision. The candidate class is now an
exhaustive finite spherical four-port certificate class with no outside face,
mirror transport, explicit port numbering, cube/zero-layer kernel, terminal
cap, virtual seals, UV shared ports, exact layer ownership, and checked legal
inverses. It includes a CEN/UV certificate construction and makes strictness a
separate unrooted-graph requirement.

The endpoint is global joint \(H^{+-}\); finite rooted congruence is only Route
1. Route quantifiers, the over-approximation rule, forbidden inferences,
bounded-pathwidth warning, and the remaining A/S increment were tightened.
Note 167 now says inclusion inherits the old exponential lower bound, so a new
word-fibre theorem is not required for this upgrade.

The freeze gate remains open: there is no concrete third successor operation
with representative, ordered ports and successor, allowed relabelling group,
non-CEN/UV orbit proof, and separate unrooted strictness proof. No experiment or
census was started, and R1 was untouched. No new advisor freeze request was
written. This directory has no git metadata, so no commit was made.

ROUTE=R2 PULSE=3 VERDICT=open
UPGRADE_SPEC_DRAFT=SPEC-2026-09-12-upgrade-candidate.md

## 2026-09-12 — R2 pulse 4

Closed only the explicit-new-orbit freeze gate.  Starting from the cube, the
first expanded graph has the adjacent mixed legal site `(0,3,11,8)`.  Expanding
that site with new vertices `12,13,14,15` and recording successor
`(0,12,7,4)` gives a fully specified third rooted operation: its successor
birth-status multiset is `{born,retained}`, invariant under the declared full
port/colour/reflection relabelling group, whereas both CEN and UV have
`{born,born}`.  Thus it is in neither old rooted orbit.

The separate graph-level gate is also closed.  Expanding `(0,12,7,4)` produces
an explicit 20-vertex Barnette graph whose incident-face-length-triple multiset
is `12(4,6,6)+6(4,4,6)+2(6,6,6)`.  The eight depth-three CEN/UV words have one
of two different displayed multisets, so uniqueness of the spherical embedding
for 3-connected planar graphs proves that this unrooted graph is in no old word
image.  The fixed constant-size checker verifies all edge tables, rotation
systems, legality, vertex connectivity, signatures, and the eight finite
same-depth comparisons; it is not promoted from `scratch/`.

Only lines belonging to the candidate SPEC's freeze-gate record were replaced.
The document remains DRAFT / NOT FROZEN / NOT STARTED, no route or (T) proof
was begun, and R1 remains waiting for the external library scan.  A final
ACCEPT/REVISE request with the complete revised SPEC and Note 167 v3 was
appended to `advisor/REQUEST.md`.  This directory has no git metadata, so no
commit was made.

ROUTE=R2 PULSE=4 VERDICT=record_complete
UPGRADE_SPEC_DRAFT=SPEC-2026-09-12-upgrade-candidate.md

## 2026-09-12 — R2 pulse 5

Applied the GPT-6 Pro round-5 REVISE decision by choosing interface option
(ii). The candidate class is now defined by general legal expansion sequences
with complete ledgers and embedded legal-site data; all asserted equivalence
with nested four-port separators was removed. The reason is explicit: the
fixed successor `S2={0,12,7,4}` revisits old-core vertices `4,7`, and no
alternative nested certificate has been supplied.

The SPEC now separates the proved unrooted statement
`H notin F_CEN/UV` from the unproved former nested-class membership claim. For
the revised general-sequence class, `H in C_4A` follows from the already
verified legal history only, and is not presented as a nested-decomposition
result. No legality, connectivity, count, or face-type computation was rerun.

The Route 1 input domain and fixed third-operation context now explicitly
include retained edge `74`, its endpoints, and its incident face/arcs. Route 1
is the unique first line; Route 2 retains only inverse-step support for the
target-property induction and no longer treats inverse existence as a
structural upgrade; Route 3 remains closed until a real Route 1 collision.
The proposed twelve-vertex bag argument and the claim of likely uniform
bounded pathwidth were withdrawn: vertices `4,7` violate bag-interval
continuity. Bounded pathwidth for the wider class is recorded as undetermined,
while the old CEN/UV bound `pw<=7` remains intact.

The upgrade SPEC remains DRAFT / NOT FROZEN / NOT STARTED. It is considered
freeze-ready for final advisor review, so a concise ACCEPT request listing
only these diff points was appended to `advisor/REQUEST.md`. No route, (T),
Hamilton search, census, or R1 work was started. This directory has no git
metadata, so no commit was made.

ROUTE=R2 PULSE=5 VERDICT=revised

## 2026-09-12 — R2 pulse 6

Applied the GPT-6 Pro round-6 sole remaining mechanical correction. Certificate
item 3 now partitions final-edge ownership explicitly as
`O_kernel=(E(Q) intersect E(G_k)) setminus F_k`,
`O_i=(B_i intersect E(G_k)) setminus F_k`, and `O_cap=F_k`, while original
cube vertices and layer-born vertices retain their prior assignments. The cap
therefore owns terminal-site edges exclusively even when one is a surviving
cube edge, so both depth zero and the allowed truncation at
`s_2=(0,12,7,4)` have unique ownership.

Route 1 now records the fixed third-operation template `o*`, its full real
context domain, joint semantic output, output-congruence and transition
equations, and the advisor's mechanical interface-only GO, certified-real-
collision NO-GO, and undecided cases. It explicitly states that interface GO
is not (T) GO. The contribution ceiling is now B-level structural
generalization/methodological progress; A/S still requires connecting the
joint-witness mechanism to complete coverage or sharp classification of a
broad class with independent structural meaning.

The round-5 nesting-equivalence and wider-class pathwidth issues remain CLOSED.
Historical copies of the former ownership sentence in earlier advisor request
attachments were left unchanged; the new final ACCEPT request lists the exact
before/after rule and Route 1 additions. The SPEC remains DRAFT / NOT FROZEN /
NOT STARTED. No route, (T), Hamilton search, R1 work, legality/count/face-type
calculation, or new lemma was started or repeated. This directory has no git
metadata, so no commit was made.

ROUTE=R2 PULSE=6 VERDICT=revised

## 2026-09-12 — Route 1 pulse 1: fixed third-operation interface GO

Read GPT-6 Pro round 7 in full and froze the pulse objects before computation.
`scratch/r3_pulse1/DEFS.md` defines the role operation
`(u,v,x,y;r0,r1) -> (u,a,r0,r1)`, the full real legal-history domain, the
fourteen slots and output rename/forget map, finite metadata eta, jointly
realized exterior rows, successor phase, semantic output J-star, and exact
Hamilton contain/avoid acceptance.  The frozen SPEC and old candidate were not
modified.

Proved the complete restriction--gluing bijection in
`scratch/r3_pulse1/PROOF.md`.  Every output generator uniquely restricts to a
real old-exterior generator plus a subset of the eight born edges and retained
edge, and every degree-compatible pair glues back.  Degree words, full
partitions, saturated closed-component counts, and joint target-use bits are
literal under this union.  The proof is independent of graph order, nesting,
face-arc length, and the age of the retained edge, so it covers every real
context in the declared domain and does not read information outside sigma0.
Connected spanning 2-regular acceptance with bits `(1,0)` is exactly one
Hamilton cycle containing e and avoiding f.

`generate_tables.py` mechanically generated the complete 512 local-selection
rows in `T0.tsv` and `j0.tsv` and ended with
`R3_PULSE1_ATOMIC_TABLES_VERIFIED rows=512`.  The independent
`validate_real_contexts.py` enumerated complete exterior/output supports in
the frozen 12-vertex context and a separately legality-checked cube context,
checking 19 and 10 deterministic target pairs respectively; it ended with
`R3_PULSE1_REAL_CONTEXT_CROSSCHECK_VERIFIED`.  These computations verify the
implementation, while the bijection bears the universal claim.

Recorded the result as Note 168 and added the README entry.  Appended an
advisor request for heterogeneous verification of DEFS, both tables, alias
handling, the bijection, coverage, and joint acceptance.  No adjacent-order
census, Route 2/3 work, Note 167 recount, R1 action, or general Barnette attack
was performed.  This is only `o*`'s interface GO and is not (T) GO.

ROUTE=R1 PULSE=1 VERDICT=GO

## 2026-09-12 — Route 1 pulse 2: corrected fourteen-slot interface GO (awaiting heterogeneous review)

Read GPT-6 Pro round 8 in full and withdrew pulse 1's certified status.  Note
168 now begins with the required REJECT notice and remains as historical
record; README points to that rejection and to Note 169.  The accepted
nine-edge atomic enumeration and actual-edge-set decomposition principle were
retained.  The frozen SPEC and Note 167 were not changed.

`scratch/r3_pulse2/DEFS.md` removes all absolute layer numbers from sigma:
complete certificates retain them, while eta has only enumerated finite
birth/deletion/location statuses and bounded marked-incidence words.  It
defines the full fourteen-slot equality quotient, a current-vertex-existence
bit for every class, input activity by actual membership in `V(G)`, output
activity after the four births, and deterministic quotient, preserve/forget,
target-location, status and face-word transport.  Forgotten structural roles
and target-only classes are retained exactly when they represent a current
target endpoint.

The rewritten `row_engine.py` consumes eta and rows on quotient classes.  T0
uses precisely the 128 canonical subsets of `L' minus {ua,r}`.  j0 separately
uses all 512 complete subsets of `L'`, checks full degree two, and computes
`kappa=(alpha(F union (P minus K+)),1_ua,1_r)` from that same legal complete
pair before testing its single component and joint `(1,0)` target bits.
`PROOF.md` states the bijections only for actual exterior subgraphs and local
edge sets; it proves that all actual realizations of a compressed row obey the
same quotient transition, rather than claiming a row uniquely recovers a
subgraph.

The regression gate first passed both round-8 real rows: the cube Hamilton
witness for `e=67,f=04` no longer raises `KeyError e0`, and the
`e=12,f=04` successor row correctly retains aliased roles `v,x`.  The full
validator then independently enumerated exterior generators, successor
generators and spanning 2-factors and compared eta+, every successor row,
every kappa and acceptance.  It covered the pulse-1 depth-zero and frozen
depth-one contexts and a legal complete CEN history at depth two, ending:

```
ROUND8_REAL_ROW_REGRESSIONS_OK cases=2
FULL_CONTEXT_OK depth-0 vertices=8 retained=(5, 4) pairs=6
FULL_CONTEXT_OK fixed-depth-1 vertices=12 retained=(7, 4) pairs=2
FULL_CONTEXT_OK legal-history-depth-2 vertices=16 retained=(11, 10) pairs=2
R3_PULSE2_FULL_SIGMA_KAPPA_ETA_ACCEPTANCE_VERIFIED
```

`generate_tables.py` regenerated 128 T0 rows and 512 j0 rows and ended
`R3_PULSE2_ATOMIC_TABLES_VERIFIED T0=128 j0=512`.  The universal result rests
on the quotient case coverage and restriction--gluing proof, not the three
bounded contexts.  Note 169 therefore registers only “o* interface GO
(awaiting heterogeneous review)”.  It is not (T) GO, supplies no later
retained-edge transition, covers no other operation, and does not establish
the full induction or acceptance of every reachable state.  No adjacent-order
census, Route 2/3, general Barnette attack, R1 change, or Note 167 recount was
performed.  A round-9 heterogeneous request listing the closure of every
round-8 REJECT item was appended to `advisor/REQUEST.md`.

ROUTE=R1 PULSE=2 VERDICT=GO

## 2026-09-13 — Route 1 pulse 3: retained-edge reattachment UNDETERMINED

Read GPT-6 Pro round 9 in full.  Updated Note 169 and README to the accepted
status “o* 一步接口 GO（异源核验 ACCEPT，round 9）”; its scope remains one
step only.  The frozen SPEC, Note 167 and the external-scan R1 item were not
changed.

Before computation, froze `scratch/r3_pulse3/DEFS.md`.  Its finite `nu` uses a
sixteen-slot equality quotient, colours up to reversal, q/target identity,
bounded marked-role face/arc order, and finite next-target location/status and
existence fields.  It excludes graph identifiers, unbounded arc lengths and
recomputed row support; no field was added after the freeze.

The proof audit closes no total reconstruction theorem.  If q endpoints were
not active, every old exterior generator had degree two there, while the next
input permits degrees 0/1.  Thus new rows need not be projections of old rows.
Even when q is a target and its use bit is present, that bit does not determine
how its component splits after deleting q.  No global real-domain identity
forcing the missing refinements was proved, and no two complete real histories
with equal `Sigma_plus,nu` but unequal full `Sigma_next` were completely
certified.  Hence neither GO nor NOGO is licensed.

The independent validator used the complete cube-to-depth-one certificate,
the displayed first o* operation, and a directly legality-checked second o*
with q=(15,8).  It computed full next supports directly from the graph in both
required load-bearing cases and ended:

```
DIRECT_NEXT_OK q-endpoints-outside-interface q=(15, 8) boundary=(0, 12, 7, 4, 15, 8, 1, 5, 2, 6) realizers=5632 rows=5121
DIRECT_NEXT_OK q-target-only-endpoints q=(15, 8) boundary=(0, 12, 7, 4, 15, 8, 2, 6) realizers=1144 rows=1016
NO_TOTAL_U_CLAIMED pulse-2 rows omit degree/connectivity refinements at newly exposed q endpoints; no proved total reconstruction rule is available
R3_PULSE3_DIRECT_REATTACH_REGRESSIONS_VERIFIED verdict=UNDETERMINED
R3_PULSE3_REATTACHMENT_UNDETERMINED
```

`reattach.py` returns an explicit Undetermined value rather than presenting an
unproved projection as U.  Per the stopping rule, no Note 170 was written and
Route 3 was not opened.  Added an advisor request to review this exact scope.
No census, Route 2/3 work, CEN/UV table duplication, Note 167 recount, or
general Barnette claim was made.

ROUTE=R1 PULSE=3 VERDICT=UNDETERMINED

## 2026-09-13 — Route 1 pulse 4: canonical-q bucket scan UNDETERMINED

Read the round-10 heterogeneous audit in full.  Before computation froze
`scratch/r3_pulse4/DEFS.md`, correcting the prior fourteen/sixteen mismatch by
naming the explicitly listed tuple as fourteen slots and giving the complete
old-to-new role map.  It also freezes the canonical colour/face encoding,
independent complete-summary calculators, and real-history/difference-row
certificate formats.  No fields were added after computation.

`canonical_nu.py`, `sigma_next.py`, and `bucket_scan.py` regenerate the fixed
cube -> G1 -> o* history, enumerate retained-edge legality, encode canonical
`nu`, and compute complete supports directly from graph edge subsets.  They do
not use pulse-2 row algebra as the authority for `Sigma_next`; hashes are only
reported after literal tuple/row comparison.  The real scan found one legal
q, `(15,8)`, one bucket of size one, and no conflict.  Both `Sigma_plus` and
that `Sigma_next` have 5,121 rows from 5,632 realizers.  Therefore the finite
package supplies no collision, while no all-domain `U` or semantic coverage
proof was obtained.

Direct legality also exposed that the frozen request's demand to include
`q=e={1,5}` and `q=f={2,6}` is incompatible with the same fixed real domain:
neither is a legal next retained edge.  They were not admitted as formal
collision states.  As a separate required regression, `q=e` used a freshly
regenerated old `Sigma_plus` and the canonical non-stub encoder; after
`beta_e=0`, renaming, and normalization, its 987 restricted rows exactly equal
the 987 direct deletion rows.  This regression is outside `D_next` and is not
GO.  `scan.json` contains full history/edge/property records and all statistics.

No Note 170 was written; Route 3 remains closed.  The frozen SPEC, R1, Note
167, and Note 169 were not changed.  An advisor request asks for review of the
domain discrepancy and a corrected cheapest package.

ROUTE=R1 PULSE=4 VERDICT=UNDETERMINED

## 2026-09-24 — Route 1 pulse 5: real retained-edge reattachment collision

Selected the same-order two-candidate package from the round-11 review and
independently reconstructed its cube -> G1 -> Z -> H history. The first o*
site is (0,8,9,1), retaining (11,3); the second is (0,12,11,3). Both
q1=(15,1) and q2=(5,4) are legal retained-edge successors after the second
operation. With targets e=(2,6), f=(9,10), their old complete Sigma_plus is
identical and all fourteen-slot nu fields, including corrected future colours
and marked face word, are identical.

Note 170 proves a genuine difference in the next complete row support. For
q1 the two squares (4,5,6,7) and (8,9,14,13) realize the row with active
degree word (0,0,0,0,0,0,0,2,2,0), singleton partition, z=0 and target bits
(0,0). For q2 that row is impossible: its zero degrees at 3 and 4 leave
nonboundary vertex 7 only its edge to 6, below its required degree two.
This analytic absence proof and the explicit witness establish NO-GO for a
deterministic U on the frozen (Sigma_plus,nu), not for every finite summary
or for (T). The standard-library scratch checker independently reconstructs
the graphs, normalized colour and face words, degree row, and local
obstruction. Direct tiny graph checks found all intermediate graphs cubic,
bipartite, planar, and 3-connected. No higher-order census was run.

The earlier pulse-4 RESULT line claiming 5,121/5,632 old Sigma_plus
rows/realizers was a transcription error: direct recomputation gives
1,579/1,984; 5,121/5,632 belongs to its next support. The scratch RESULT
was corrected. Note 169's accepted one-step result and the Kao--Chen
novelty boundary remain unchanged. The collision satisfies the frozen
Route-3 trigger, but no refinement or full transition GO is claimed.

ROUTE=R1 PULSE=5 VERDICT=NO-GO-FOR-FROZEN-REATTACHMENT-SUMMARY

## 2026-09-29 — Analytic continuation: nonlocal transfer and four returns

Notes 172 and 173 record two all-order proofs. Note 172 independently
checks the September 26 infinite-prism candidate: a globally
\(H^{+-}\) parent has a unique marked Hamilton cycle avoiding both
expanded edges, the child has a marked Hamilton cycle, yet every child
Hamilton cycle changes at least \(2r-1\) old edges and changes an edge
at distance at least \(r-1\) from the ports. This rules out any uniform
bounded-edit or bounded-radius transfer rule, not global witness
preservation. Note 173 strengthens the marked opening lemma by an exact
four-unit directed min-cut: every isolated new square has four
arc-disjoint alternating returns, with at least
\(\max\{0,4-k-2\ell\}\) surviving after protecting \(k\)
nonmatching and \(\ell\) matching edges. The remaining open implication
is that an opening, possibly after further exchanges, has connected
complement. The connected-outside-square case admits an additional
Euler-tour/trail-switch proof selecting one opening through each of the
four square edges, so any one required parent-cycle edge leaves a cross
opening. Note 174 closes the separate forbidden-matching-edge condition
for 2-extendable parents: deleting its endpoints leaves a connected
matching-covered graph, whose contracted matching digraph is strong;
both cross openings avoid the forbidden edge. With a second required
cycle edge, a total failure of marked cross openings forces its arc to
be a strong bridge in that deletion digraph; the exact pair-specific
criterion is incomparability of the two site-edge vertices in the
strong-component DAG after deleting this arc. A further strict-Hall
argument now rules out that incomparability throughout the cubic
2-extendable class: two incomparable reachability shores would cross,
while their two differences demand more incoming arcs to the intersection
than its balanced cut permits. If the required edge meets the forbidden
edge, both paths avoiding the forbidden pair automatically avoid it too.
Thus one cross opening always preserves both marks. Its complement may
still have residual cycles; selecting a tree quotient, and transferring
through non-brace factors, remain open. This was an analytic argument;
no local enumeration, OMEN, or publication action was used.

The same prism construction now gives an exact analytic comparison of
quotient connectivity. Its explicit marked child Hamilton cycle is a
single alternating flip of length \(4r\) from the isolated-square
2-factor. A more direct jointly marked opening of length \(2r+4\)
leaves exactly \(r-2\) residual old cycles for \(r\ge3\). Their vertex
lists and the complementary spanning path are written in Note 172.
Hence the missing tree-quotient selection cannot be replaced by marked
reachability or by choosing this direct strip path. No enumeration was
used for this comparison. Note 172 now gives the full interpolation:
for \(0\le s\le r-2\), one marked path uses \(2r+1+2s\) old edges and
its opened 2-factor has exactly \(r-1-s\) components. Consecutive
paths differ by a single alternating side-face square that joins one
residual cycle to the main component. This proves a monotone repair
mechanism in the prism family, without asserting it for general braces.

## 2026-09-29 — A nonplanar brace separates marked openings from tree selection

Note 175 upgrades the 16-vertex nonplanar interface model of Note 013
to an analytic obstruction. Its adjacency table gives strict Hall
expansion on both colour classes, hence 2-extendability and
3-connectivity; four graph-theoretic squares versus the six facial
squares required by Euler's formula proves nonplanarity. An explicit
comparison identifies the graph as an octagonal prism with two
opposite rungs switched; switching them back restores a displayed
cross Hamilton path. Gorsky--Steiner--Wiederrecht's cubic Pfaffian
brace classification, together with the four-square count, also
shows that this 16-vertex brace is non-Pfaffian. An explicit Hamilton
cycle avoids the two site edges. After those edges are
deleted, the graph splits into two induced six-cycles joined only
through a four-vertex core. Degree counting leaves two core-edge
cases, and the four possible three-boundary pairings force a separate
cycle in each. An involution exchanges the two cross-path problems,
so neither cross Hamilton path exists. An explicit alternating path
nevertheless preserves both chosen marks and leaves one residual
six-cycle. Note 174's planarity-free matching argument supplies an
opening for every required old cycle edge and every forbidden
non-site matching edge, while the absent cross Hamilton paths rule
out a tree quotient for all of them. The example is nonplanar and does not
decide the planar site case or Barnette's conjecture.

The interpolation in Note 172 was checked term by term: its
step-\(s\) side square has one 2-factor edge on the main component
and the other on the residual square at \(j\ge4\), or on the
residual hexagon at \(j=3\). Each flip therefore merges exactly one
component, ending at the Hamilton path when \(s=r-2\).

The 2026-09-29 source check read Gorsky--Steiner--Wiederrecht
(arXiv:2202.11641v3, Theorems 2.3, 2.6, 5.1 and Corollary 4.9)
and Schnieders (arXiv:2508.03531v1, Lemma 3.3 and Theorem 5.2).
The former supplies the brace characterization, bipartite deletion
criterion, HMM generation statement and Pfaffian-brace classification
used above. The latter lifts Hamilton cycles through listed bounded-face
substitutions and closes by the identity \(f_4=f_8+6\); its lemma and
Euler contradiction both assume faces of length at most eight, so they
do not settle the unrestricted tree-selection step here.

Note 174 now records the direct one-edge-gap case: when the facial arc
between the two site edges is \(h=vx\), the original Hamilton cycle
contains \(h\), and flipping the square \(b,v,x,c\) replaces \(h\)
with a gadget path to give a cross Hamilton cycle. It preserves every
required old cycle edge other than \(h\) and avoids every forbidden
non-site old matching edge. If both arcs are single edges, one of the
two flips preserves any required old cycle edge. Thus a planar
cofacial site with no cross Hamilton path must have both facial gaps
of length at least three; marked tree selection when the required
edge is the only short gap edge remains a different question.
Note 176 extends the facial observation to every odd length:
an alternating facial residual arc of length \(2k+1\) has exactly
\(k\) matching edges, each of which closes a distinct old
\(C\)-segment into a residual cycle. The opened child 2-factor
therefore has exactly \(k+1\) components. The proof uses only
Jordan separation and noncrossing chords, with no computation or
brace assumption. Literal long facial returns cannot be the
missing tree connector; nonfacial paths remain possible, as
Note 172 demonstrates.
In the cubic bipartite 3-edge-connected case, every trapped segment
has even order and exactly two departing \(C\)-edges. Its cut must
therefore contain at least two departing matching edges. Planarity
puts all those edges on the side of \(C\) opposite the facial
matching chord that closed the segment. This proves escape supply
for each residual cycle, while their joint selection remains open.
Contracting the \(k+1\) cut segments and retaining all
intersegment matching edges yields a stronger all-order structure:
all these edges draw without crossings on the opposite side of the
parent Hamilton Jordan curve. If this network were disconnected,
noncrossingness would expose a connected component occupying a
consecutive block of segments; its union would have a forbidden
2-edge cut in the parent. Thus the network is connected. In a
bipartite parent every segment has even order, so every network
degree is even and, by 3-edge-connectivity, positive. The escape
network is therefore Eulerian, though this alone does not select
a spanning Hamilton opening.

## 2026-09-29 — The escape network has a second, facial cycle

Note 176 now distinguishes the abstract escape network from the
actual child edge overlay. Eulerianity makes every escape edge
non-bridging, so deleting a forbidden old matching edge leaves
the escape network connected. But after contracting the opened
2-factor components, the old \(C\)-edges cut by the facial return
remain available in the child and form a second cycle through all
components. These facial edges plus the opposite-side escape
edges are exactly the intercomponent edges. Any child 2-factor
projects to an even subgraph of this two-sided overlay; a
Hamilton cycle projects to a connected spanning even subgraph.
Thus an abstract spanning tree of escape edges cannot by itself
lift to a 2-factor, since every tree has odd-degree leaves.
Local attachment order and mixed use of both edge families
remain the decisive missing information. This is a parity
deduction, not a Hamiltonicity claim.

The even-prism family makes that parity boundary sharp at every
order. For its literal top-face return, the escape network is
exactly the \(r\)-cycle whose edges are
\(B_{2j}B_{2j+1}\), \(1\le j\le r\), with two parallel edges
when \(r=2\). Deleting any one such edge leaves a path. Hence
every Hamilton cycle of the expanded prism that avoids the
deleted edge must use at least one of the former facial
\(C\)-edges \(T_{2j}T_{2j+1}\). Such avoiding cycles exist:
Note 172 proves global \(H^{+-}\) for the parent prism, and
Note 013 gives \(H^-\) after the legal expansion. This is an
analytic all-order forcing statement for mixed use of the
two-sided overlay; it neither proves global \(H^{+-}\) in the
child nor Barnette's conjecture.

## 2026-09-29 — Square traps are even four-terminal ladders

Note 177 establishes a complete structure under the hypothesis that
every residual component of a literal facial opening is a square.
Each residual vertex has exactly two opposite-side matching exits.
The connected noncrossing escape network is therefore a bouquet
of cycles at the main component; each lobe consists of a consecutive
block of residual squares. For adjacent squares in a block, the
escape edge is forced between their facing interior vertices. It
and the intervening cut cycle edge form a facial alternating square.
These merger squares are vertex-disjoint, and flipping all of them
reduces the opened 2-factor to one residual cycle per lobe plus the
main cycle. The one-lobe case yields a Hamilton cycle if an end
escape endpoint is adjacent to the corresponding facial port in
the opened factor; the theorem does not force this adjacency.
In the bipartite one-lobe case with at most eight old vertices
in the main segment, site-port colour parity and simplicity
force that segment to have exactly eight vertices. The two
escape endpoints must be its first and last interior vertices:
the alternative noncrossing placements would leave two adjacent
vertices matched to one another. Both end merger squares are
therefore available. Flipping either one after the internal
mergers gives a distinct Hamilton cycle, for arbitrarily many
residual square traps.

Note 178 identifies a block of \(n\) square traps as the induced
four-terminal ladder \(P_{2n}\square K_2\), with exactly four
external attachment edges. For every even number of columns,
the four possible spanning Hamilton-path endpoint pairs and the
two possible spanning two-path pairings are exactly those of a
single square. Replacing a whole block by one square therefore
preserves the complete projection of Hamilton cycles onto all
exterior and labeled attachment edges, including any use/avoid
marks there. This is an analytic all-order reduction, with no
local enumeration or remote computation. A further connectivity
argument closes the class boundary: the four-edge cut and
3-edge-connectivity force the ladder exterior to be connected.
After replacing a long ladder by a square, every deletion of
at most two vertices still leaves the graph connected. In the
reverse direction, every component of a ladder after two
deletions contains a surviving terminal and attaches to the
connected exterior. Cubicity and simplicity are immediate,
bipartite terminal colours agree for even ladder length, and
the planar replacement uses the disk on the empty side of the
square. Thus Barnette membership is equivalent before and after
compression. A vertex-minimal non-Hamiltonian Barnette graph
cannot contain an induced even-column four-terminal ladder with
more than two columns. Iterating this compression gives a
ladder-reduced Barnette graph with the same Hamilton status;
the full conjecture is equivalent to that reduced class.
The final lobe-to-main connection and
nonsquare traps remain open.

The reduction also commutes with the current facial square
expansion. Compressing every square-trap lobe in both parent and
child leaves the site and all exterior edge marks unchanged;
the parent Hamilton cycle restricts on each ladder to a spanning
top-to-top path and becomes the corresponding square path.
The common-face arc loses each long alternating ladder strip
and retains one trapped square per former lobe. Thus the whole
all-square-trap case has a singleton-per-lobe normal form
within the Barnette class, with equivalent parent and child
Hamilton decisions. This removes lobe length from that branch;
the number of lobes and the main-segment connection remain.

## 2026-09-29 — First feasible square-trap main segment has a one-edge gap

Notes 179--180 sharpen the singleton-per-lobe normal form.
The escape endpoints on the old main segment occur in the
reverse order of their residual-square sources; each right
endpoint has odd main-path index and each left endpoint even.
If both endpoints of every lobe are adjacent, their escape
edges and the two corresponding factor edges form disjoint
alternating squares, so all residual squares merge into the
main cycle. This is an exact sufficient condition.

The counting lower bound \(|S_0|\ge2\ell+4\) is not attainable
in a Barnette parent. At equality, colour parity forces the
site ports \(y,u\) to be adjacent and all escape endpoints
to occupy adjacent pairs on either side. The first group of
residual squares and the corresponding main-segment suffix
then have only two crossing \(C\)-edges, a forbidden 2-edge
cut. Note 179 therefore proves \(|S_0|\ge2\ell+6\).
The initial idea of calling the saturated case Hamiltonian was
discarded because that class is empty under 3-edge-connectivity.

At the first feasible size \(|S_0|=2\ell+6\), exactly two
main-segment vertices remain after accounting for site ports
and escape targets; they are matched to one another. The cuts
immediately after \(y\) and before \(u\) must each be spanned
by an escape pair, or an even vertex-set cut would have only
two or three edges. Planarity forces those pairs to be the
same: if different, the extra matching chord crosses one
escape chord. Hence one residual square has the six-vertex
main pattern \(R,s,y,u,t,L\), with \(st\) matched, and every
other square has adjacent escape endpoints. Note 180 records
that this is the one-edge-gap case:
\(yu\) is an old \(C\)-edge on the other site face arc.
The already proved Note 174 square flip \(y,u,A,D\) directly
joins the original parent Hamilton cycle to the new patch.
The result holds for arbitrary lobe count and lengths. No
local recomputation, OMEN work, or publication action was used.

## 2026-09-29 — The one-lobe long-gap boundary is twelve vertices

Note 181 resolves the first genuinely long-gap main-segment
size in the all-square-trap, one-lobe branch. Notes 179--180
gave \(|S_0|\ge10\). At equality, the two site ports on the
opposite facial arc must occupy indices 3 and 6 along the
ten-vertex main path. The escape targets have odd/even indices
in that order, leaving exactly five placements. In each, the
four other main vertices have a unique simple bipartite
matching; its two edges interlace. Both edges also interlace
one of the site chords, so both must be drawn on the opposite
side of the parent Hamilton circle, where they cross. This
excludes order ten and proves \(|S_0|\ge12\).

The bound is sharp at every lobe length: Note 172's legal
eight-prism site has one four-vertex trap, main size twelve,
and two facial gaps of length three. Replacing that trap by
the even four-terminal ladder of Note 178 preserves Barnette
membership and the legal expansion, gives \(k\) square traps
in one lobe for any \(k\ge1\), and leaves main size twelve.
This is an analytic planar obstruction and an explicit
infinite sharpness family; no local recomputation was used.

## 2026-09-29 — Double-long-gap bound for every square-trap lobe count

Note 182 excludes the next candidate \(|S_0|=2\ell+8\) for every
\(\ell\ge1\), strengthening the double-long-gap bound to
\(|S_0|\ge2\ell+10\). At the excluded size, only four main-segment
vertices remain for two internal matching chords. Parity makes every
gap between successive escape targets hold an even number of these
vertices and the two site ports. The even-cut lemma and noncrossing
chords force \(y,u\) into distinct escape-pair gaps. A gap with only
one free vertex can match outward only toward the corresponding end
of the main segment; the available two extra free vertices cannot
supply both port gaps. The same-gap cases fail by the cut lemma or
by two forced crossing chords. The proof is analytic and applies
before and after arbitrary lobe-ladder compression. The single-lobe
equality family in Note 181 makes the bound sharp for \(\ell=1\).
Note 182 also gives a 22-vertex two-lobe parent and a six-vertex
insertion that preserves cubic bipartite planarity,
three-edge-connectivity and the legal site while adding one lobe
and two main vertices. Thus equality is attained for every
\(\ell\ge1\); even-ladder replacement makes each lobe length
arbitrary. Hamilton transfer at larger main size remains open.
No OMEN or local recomputation was run.

The sharpness family itself has a second, explicit Hamilton parent
cycle through both site edges. In the 22-vertex base, the whole
complementary matching together with every other edge of the
original Hamilton cycle is one cycle, displayed in Note 182.
The six-vertex insertion replaces one edge of this cycle by a
spanning seven-edge path, preserving both site edges. Note 001
then gives a Hamilton cycle in every expanded child; Note 178
transfers it through arbitrary lobe-ladder replacements. This
settles Hamiltonicity of the constructed equality family, while
leaving the unrestricted equality class open.

## 2026-09-29 — Sharp all-square equality transfers Hamiltonicity

Notes 183--184 close the unrestricted equality class left by
Note 182. The opposite site-face arc need not be assumed
alternating: it may initially contain consecutive old-cycle
edges. Note 183 first excludes two or more matching chords
using the even-cut lemma and the six available free vertices,
then excludes zero chords by target-gap parity and planar
chord placement. Both site ports must lie inside escape-pair
gaps. The weaker preliminary claim that long facial arcs
automatically alternate was discarded before recording a
theorem.

Note 184 classifies every equality configuration into a
one-pair or two-pair core. In both, the six free vertices
have the forced matching \(sb,ad,ct\), the opposite facial
arc is \(y,a,d,u\), and every other escape pair is adjacent.
The two core graphs have explicit Hamilton cycles containing
both site edges. Any further adjacent pair and its residual
square arise by a six-vertex insertion that replaces one
edge of the Hamilton cycle by a spanning path. Therefore
every legal Barnette expansion admitting this sharp
all-square opening has a Hamiltonian child, for arbitrary
lobe count and original lobe lengths. This is a statement
about the sharp boundary, not the full Barnette conjecture.
No OMEN or local recomputation was run.

## 2026-09-29 — Exact routing boundary of the six-vertex insertion

Note 185 treats the two-square patch used in Note 184 as a
four-terminal graph. Bipartite endpoint parity and planar
noncrossing prove its exact signature: four spanning-path
endpoint pairs and two spanning-two-path pairings, all with
explicit routes. For two vertex-disjoint selected host edges,
this gives an if-and-only-if Hamilton expansion criterion in
terms of old spanning paths or two-linkages. For selected
edges meeting at one endpoint, the exact criterion instead
uses two old spanning-path options or one spanning path
after deleting the common endpoint. The patch adds
cross-edge routes absent from merely restoring the two host
edges, so an inverse Hamilton projection requires more than
the sharp-family forward witness. The same patch-cut argument
proves forward preservation of three-edge-connectivity for
disjoint or incident selected edges; explicit face order and
colour conditions preserve planarity and bipartiteness.
For two distinct incident selected edges, the common cubic
endpoint absorbs the additional routes: Hamiltonicity and
Barnette membership are both equivalent before and after
insertion. The reflected incident orientation is covered too.
The seven vertices formed by the common endpoint and the
six-vertex patch are a cube minus one vertex, so this
incident operation is the known Holton--Manvel--McKay cube
expansion. Its Barnette/Hamilton preservation is not claimed
as a new operation.
No OMEN or local recomputation was run.

## 2026-09-29 — Boundary square traps peel or force Hamiltonicity

Note 186 applies this cube-expansion identification to an
all-square facial opening after the simultaneous lobe
compression of Note 178. If the main
segment starts \(x,R_\ell,L_\ell\) or ends \(R_1,L_1,v\),
the adjacent target pair and its residual square form the
six-vertex patch. Restoring the two interrupted cycle edges
gives an incident-edge inverse. The inverse is simple unless
its new main edge duplicates the site edge \(xy\) or \(uv\).
In the simple case, the parent and child both reduce to a
smaller Barnette parent and its legal site expansion; the
child Hamilton decision is equivalent and the number of
square traps falls by one. In the collision case, an explicit
rerouting through the six boundary vertices gives a parent
Hamilton cycle containing the site edge that would be
duplicated; its direct site lift gives a Hamilton cycle of
the child. Thus a vertex-minimal
non-Hamiltonian Barnette child with an all-square facial
opening has no such boundary triple. This does not treat
interior six-vertex patches or non-square residual cycles.
The proof is analytic; no OMEN or local recomputation was run.

## 2026-09-29 — Every opposite-face matching chord has a free-vertex cost

Note 187 extends the first obstruction of Note 183 to every
main-segment size in the all-square facial-opening class.
Write \(f=|S_0|-2\ell-4\) for the number of free main
vertices, and let \(r\ge1\) count matching edges on the
other site-face arc. Then \(f\ge2r+4\). If fewer free
vertices were available, at most one internal matching
chord would remain outside that arc, forcing both site
ports into escape-pair gaps by Note 179's even-cut lemma.
Parity then requires a free vertex before \(y\) and after
\(u\). At equality, these two would match each other:
distinct gaps force a crossing escape chord, while one
gap forces an adjacent matched pair among consecutive
interior free vertices. Thus eight free vertices allow
at most two opposite-face matching chords. This does not
settle the eight-free Hamilton decision. No OMEN or local
recomputation was run.

## 2026-09-29 — Two or more opposite-face chords need two additional free vertices

Note 188 sharpens Note 187 when the other site-face arc
contains \(r\ge2\) matching chords: the number of free
main vertices is at least \(2r+6\), so an eight-free
all-square opening has at most one such chord. At the
excluded equality \(f=2r+4\), Note 187 puts the site
ports in distinct escape-pair gaps. The two matching
chords outside the face arc are forced to stay inside
those two port gaps. Any free vertex in an intervening
nonpair gap would produce an odd-index main edge crossed
by at most one matching chord, contrary to Note 179's
even-cut lemma. Parity then makes each port gap contain
an odd positive number of face-chord endpoints. If the
first port gap contains three or more, its first two
face endpoints are adjacent on the original cycle or
have the same colour. Thus it contains exactly one; the
last port gap does too. The first intermediate pair gap
with endpoints starts with a vertex of the same colour
as the first port-gap endpoint, again preventing the
first face chord. The proof uses no alternation assumption
on the opposite arc. No OMEN or local recomputation was run.

## 2026-09-29 — The two-chord lower bound is attained

Note 189 gives a Barnette family for every lobe count
\(\ell\ge1\) with \(r=2\) opposite-face matching chords and
exactly \(f=10\) free main vertices, attaining Note 188's
bound. For \(\ell\ge2\), starting from Note 182's sharp
family, it expands the matching edge \(ad\) and the disjoint
cycle edge \(bL_2\) on their facial hexagon. For \(\ell=1\),
Note 184's same-gap core instead supplies the facial pair
\(ad,bc\). The original Hamilton cycle lifts
across the cycle edge and still avoids the two marked site
edges; the second Hamilton cycle lifts across \(ad\) and
still contains both site edges. The new opposite site-face
arc is \(y,a,\xi,\eta,d,u\), with matching edges
\(a\xi,\eta d\). The square-patch cut argument preserves
three-connectivity for both expansions; Note 178 then gives
arbitrary positive lobe lengths. This is sharpness within
the selected all-square opening, not a Hamilton decision for
every opening at \(f=10\). No OMEN or local recomputation was run.

## 2026-09-29 — Fixed-lobe opposite-face chord amplification

Note 190 proves a repeatable marked operation. When an
opposite-face matching edge closes a facial square whose
other three edges follow the original Hamilton cycle, and
a second Hamilton cycle uses the matching edge but avoids
the opposite cycle edge, expanding those two edges adds
four main vertices and one opposite-face matching edge.
Both Hamilton cycles lift by explicit spanning gadget
routes. The new adjacent facial square has the same marked
interface; Barnette membership and the original site
expansion's legality follow from the square-patch cut
argument. Note 189 supplies this interface for every
lobe count. Therefore every \(\ell,r\ge1\) occurs with
\(f=4r+2\), a Hamiltonian parent and child, and arbitrary
positive lobe lengths. For \(r\ge2\), the present lower
and upper bounds are \(2r+6\) and \(4r+2\), equal at
\(r=2\). The construction does not settle either the
minimum for \(r\ge3\) or the general Barnette conjecture.
No OMEN or local recomputation was run.

## 2026-09-29 — Exact one-lobe chord packing and Hamilton decision

Note 191 proves the universal facial spacing inequality
\(|S_0|\ge4r+8\): each opposite-face matching chord has
disjoint endpoints at least three old-cycle edges apart,
while each site matching edge needs two outer interior
vertices. Equality forces an alternating opposite face
arc and four-vertex blocks for its chords. In a one-lobe
all-square opening this gives \(f\ge4r+2\), attained
for every \(r\) by Note 190. At equality, all unmatched
main slots lie on the escape side. An internal chord
cannot straddle either escape target; putting the first
target after the first slot, or the last target before
the last slot, closes a proper old-cycle interval under
the matching and creates a forbidden two-edge cut.
With targets at the two extremes, the same cut argument
forces a single chain of matching chords across the
face blocks. This uniquely identifies the compressed
parent as Note 190's one-lobe family and supplies its
Hamilton cycle through both site edges. Thus every
one-lobe equality child is Hamiltonian, including
arbitrary positive lobe lengths. The general Barnette
conjecture remains open. No OMEN or local recomputation
was run.

## 2026-09-29 — Exact two-lobe minimum for every face-chord count

Note 192 excludes equality in Note 191's universal
\(|S_0|\ge4r+8\) spacing bound whenever the chosen
all-square opening has at least two lobes. In the
equality block pattern, the even-index target
\(L_\ell\) of the last residual square is the
last slot of an outer or face-chord block.
The main prefix through that block, together with
the last residual square, is closed under the
matching: slot chords cannot straddle \(L_\ell\)
without crossing its escape edge. Only two old-cycle
edges leave this vertex set, contradicting
three-edge-connectivity. Hence
\(|S_0|\ge4r+10\). For exactly two lobes this
gives \(f\ge4r+2\), met by Note 190 for every
\(r\ge1\), including arbitrary positive lobe
lengths. The minimum is exact, while Hamiltonicity
of every two-lobe equality graph remains open.
No OMEN or local recomputation was run.

## 2026-09-29 — Exact three-lobe minimum for every face-chord count

Note 193 excludes the next possible main size
\(|S_0|=4r+10\) whenever an all-square facial opening
has at least three lobes. A prefix-cut rule says that
each nonfinal even-index escape target \(L_j\) must
have another slot after it within the same site/face
block or interblock gap. If the two spacing extras
are in one block or one gap, this can serve at most
one of the at least two nonfinal targets. If they
occupy two distinct gaps, block-slot parity changes
from odd/even to even/odd and back. Noncrossing
matching plus bipartite balance force the first
target \(R_\ell\) to be the first slot, after which
every eligible \(L_\ell\) is a block's last slot;
the prefix-cut rule excludes it. Thus
\(|S_0|\ge4r+12\) for \(\ell\ge3\).
For exactly three lobes this yields
\(f_{\min}(3,r)=4r+2\) for every \(r\ge1\), attained
by Note 190 with Hamiltonian parents and children.
The general Barnette conjecture remains open.
No OMEN or local recomputation was run.

## 2026-09-29 — Short site and face chords force a Hamiltonian child

Note 194 proves a structural obstruction independent of
gap lengths. If both site matching edges and all \(r\)
matching edges on the other site-face arc span exactly
three old-cycle edges, every chosen all-square facial
opening has only one square-trap lobe and a Hamiltonian
site-expanded child. With all chord
blocks minimal, every other main matching chord lies
opposite the common face and cannot straddle an escape
target. The odd/even slot walk has height zero or one
at atom boundaries; its first odd escape target is
forced to the first slot of the first block. The next
even target is forced to a block's last slot, which
would create Note 193's two-edge prefix cut if another
lobe followed. In the remaining one-lobe case, the
even target must be next to \(v\); the explicit end
square flips the opened two-factor into one Hamilton
cycle. This excludes gap-only configurations
at any main-segment size, including one entire branch
of the four-lobe \(f=4r\) candidate. The other four-lobe
cases and the general Barnette conjecture remain open.
No OMEN or local recomputation was run.

## 2026-09-29 — Exact free-vertex bound for every square-trap lobe count

Note 195 proves \(f_{\min}(\ell,r)=4r+2\) for every
\(\ell,r\ge1\), using Note 190 for attainment. In any chosen
all-square facial opening, a free matching chord straddling an
escape target in a block gap would have to lie opposite the
common face and cross that escape edge. The resulting closed
prefix would require colour balance \(0\) before an odd target
or \(-1\) before an even target, whereas gap slots have balances
\(1\) and \(0\), respectively. Thus targets occur only inside
site or face-chord blocks. The first even slot of an even-first
block is likewise forbidden. Note 193's prefix-cut rule excludes
a nonfinal even target in a block's final slot. A block with
\(2+2k_i\) interior slots can therefore hold at most \(k_i\)
nonfinal even targets, so \(\sum k_i\ge\ell-1\) and
\(|S_0|\ge4r+2\ell+6\). Equality has no interblock gap
vertices and saturates every eligible even block slot.
The right endpoint \(L_1\) is pinned by a separate
suffix-chord argument: if it occurred before the final
block, the last free slot would match into the
target-free suffix, enclosing a matching-closed
consecutive block interval and exposing a two-edge cut.
In particular the four-lobe \(r=3,f=12\) candidate is
impossible. No OMEN, local graph recomputation, or agents
were used.

## 2026-09-29 — Every exact packing equality has a Hamiltonian child

Note 196 settles the Hamilton decision at Note 195's
all-parameter boundary \(f=4r+2\). Every consecutive
pair \(L_j,R_{j-1}\) of escape targets must lie in one
face/site block: if they occupy different blocks, the
main prefix through the preceding complete block
together with the already completed residual-square
suffix is closed under the complementary matching,
leaving a forbidden two-edge cut. Saturation at equality
then makes each such pair adjacent on the old cycle.
Every face block has precisely its first odd and final
even interior slots free. The free matching chords are
forced into the chain from each block's final even slot
to the next block's first odd slot; skipping a block
would give either a duplicate cycle edge or another
two-edge cut. The complementary matching together
with all even-starting edges of the old Hamilton cycle
forms two internally disjoint \(x\)-to-\(v\) paths
whose union spans: one goes through all residual squares and escape
targets and the other through all free slots and
face-chord endpoints. Their union is a Hamilton
parent cycle containing both site edges, so Note 001
lifts it to the site-expanded child; Note 178 restores
arbitrary lobe lengths. The general Barnette conjecture
and all-square openings above the exact boundary remain
open. No OMEN, local graph recomputation, or agents
were used.

## 2026-09-29 — Gapless defect budget above exact packing

Note 197 proves a stability bound for all-square openings with
empty interblock gaps. If \(s=\sum k_i-(\ell-1)\), then the
number of failed endpoint positions and nonadjacent consecutive
lobe transitions is at most \(s\). Each failure is assigned a
different eligible even slot not occupied by a nonfinal escape
target. The endpoint barrier also holds with arbitrary gaps:
placing the first target at the first slot of a later block,
or the last target at the final slot of an earlier block,
creates a matching-closed interval with a two-edge cut.
At \(f=4r+4\), the gapless branch therefore has at most one
target-order defect. The same note proves a complementary
saturation theorem: when all eligible block slots are occupied,
the first and last escape targets remain at the outermost block
slots even with gaps, and a nonadjacent lobe transition can end
only at the second slot of a parity-reversed block. Thus one
two-slot gap leaves every transition adjacent, whereas two
single-slot gaps localize any failed transition between them.
This does not prove Hamiltonicity at that boundary. No OMEN,
local graph recomputation, or agents were used.

## 2026-09-29 — A two-gap near-equality branch is impossible for one face chord

Note 198 excludes the capacity-saturated two-gap-slot branch
at \(r=1,f=8\), for every lobe count. Boundary peeling reduces
any such opening to three blocks with only the middle block
long. If both gap slots are together, its six free slots have
one of two colour orders, neither admitting the required
noncrossing complementary matching without duplicating a
cycle edge. If the gap slots are separate, the order is
\(E,E,E,O,O,O\); its unique noncrossing bipartite matching
pairs the two adjacent free slots inside the middle block.
Therefore every \(r=1,f=8\) opening is gapless and falls
under Note 197's one-defect budget. This is a structural
exclusion, not a Hamilton theorem. No OMEN, local graph
recomputation, or agents were used.

## 2026-09-29 — The single-lobe one-chord near-equality child is Hamiltonian

Note 199 settles the Hamilton decision at
\(\ell=r=1,f=8\). Note 198 first removes both two-gap
distributions. In the remaining gapless branch exactly
one of the three site/face-chord blocks has four interior
slots. Note 197 permits at most one endpoint deviation.
Planar noncrossing of the six free-slot matching endpoints
leaves, up to reflection, three possible complementary
matchings; two other target placements are impossible.
For each possible matching, Note 199 displays a spanning
cycle in \(M\cup A\), where \(A\) is the even-starting
old-cycle matching. Each cycle contains both site edges,
so Note 001 lifts it to the legal expanded child, and
Note 178 restores any original lobe length. The
multi-lobe near-equality case and the full Barnette
conjecture remain open. No OMEN, local graph recomputation,
or agents were used.

## 2026-09-29 — Three middle-block routes and a one-square repair

Note 200 treats the all-parameter \(r=1,f=8\) branch in
which the unique vacant eligible slot is in the middle
face-chord block and all escape-target endpoints and
consecutive transitions are tight. The six free slots
have exactly three compatible complementary matchings.
Two give a Hamilton cycle in \(M\cup A\). In the third,
\(M\cup A\) has two cycles, but if either internal chord
spans one target pair, a four-cycle flip joins them while
preserving both site edges. The third pattern cannot
avoid this repair when \(\ell\le4\). The case with at
least two target pairs on each side is left undecided;
the displayed two-factor is not a non-Hamiltonicity
certificate. No OMEN, local graph recomputation, or
agents were used.

## 2026-09-29 — Boundary-target delay is Hamiltonian at one-chord near equality

Note 201 proves the full-lobe-count Hamilton decision for
the endpoint-defect branch of \(r=1,f=8\). With no gaps,
the unique vacant eligible slot lies immediately before
the delayed first target. The target must occupy the third
slot of its block; all earlier blocks are short.
The left-block placement has no complementary-matching
mate for its second slot. In the middle and right blocks,
planar noncrossing forces the same respective six-slot
matchings as Note 199, and the tight lobe transitions form
one expandable \(M\cup A\) path. Explicit Hamilton cycles
contain both site edges for every lobe count. Reflection
settles an advanced final target. The transition-defect
and no-target-defect branches remain. No OMEN, local graph
recomputation, or agents were used.

## 2026-09-29 — One-chord near equality reduces to a two-parameter core

Note 202 settles the transition-defect branch at \(r=1,f=8\):
boundary square peels either turn the defect into an endpoint
delay already covered by Note 201, or leave both outer blocks
short. In the latter case, cross-block escape-edge crossings
force two free matching pairs, and the remaining pair is an
old cycle edge, an impossibility. With no target-order defect,
an outer-block vacancy peels to its first eligible position;
the only feasible six-slot matching then gives a displayed
Hamilton parent cycle. Together with Notes 198--201, any
non-Hamiltonian child in this opening class must use the
middle-block double inner route with at least two target
pairs on each side. Further simple peels reduce its Hamilton
decision to an explicit two-parameter core indexed by
\(a,b\ge2\), of child order \(6(a+b)+22\ge46\).
The core family and the full Barnette conjecture remain open.
No OMEN, local graph recomputation, or agents were used.

## 2026-09-29 — The one-chord eight-free boundary is Hamiltonian

Note 203 applies the opposite-side chord crossing rule of
Notes 177 and 193 to the three remaining middle-vacancy
matchings of Note 200. In the left route, the cross-block
edge \(ei\) straddles a target pair required by \(gh\);
in the right route, \(hz\) straddles one required by \(ij\);
in the double inner route, \(ez\) straddles both. None is
planar. Notes 198, 201 and 202 handle every other branch.
The simple boundary peels used in Note 202 preserve both
site edges in the lifted parent Hamilton cycle by Note 185.
Therefore every actual \(r=1,f=8\) all-square opening has
a Hamilton parent cycle through both site edges, and its
legal site-expanded child is Hamiltonian for all lobe counts
and lengths. With Note 196, a non-Hamiltonian child admitting
a one-chord all-square opening must have \(f\ge10\).
The general Barnette conjecture remains open. No OMEN,
local graph recomputation, or agents were used.

## 2026-09-29 — A real two-chord detour at first surplus

Note 204 constructs, for every lobe count \(\ell\ge2\), a
Barnette parent with \(r=2,f=12=4r+4\), no gaps,
tight escape-target order and a vacant eligible slot in the
second opposite-face chord block. Four free matching chords
form a nested detour through the preceding short block and
straddle no escape target. The given two-sided chord drawing
is planar; connected interlacement of all matching edges
excludes two-edge cuts and proves three-connectivity. An
explicit \(M\cup A\) Hamilton cycle uses both site edges.
Thus the no-straddling rule that eliminates the middle vacancy
at one chord cannot alone eliminate it for two chords. The
full \(r\ge2\) near-equality Hamilton decision remains open.
No OMEN, local graph recomputation, or agents were used.

## 2026-09-29 — The near-equality detour persists at every chord count

Note 204 now combines its explicit \(r=2\) parent with Note 190's
marked square amplifier. The square \(a_1,o,e_1,b_1\) meets the
amplifier's two Hamilton-edge requirements. Each step splits one
two-slot face-chord block into two such blocks, with no gap or
escape target inserted; the sole eligible vacancy remains at
position 2 of the final long face-chord block. Thus for every
\(\ell,r\ge2\) a Barnette parent realizes \(f=4r+4\) and has a
Hamilton cycle through both site edges, with a Hamiltonian
site-expanded child. This is a realization theorem, not a
Hamilton decision for all near-equality openings. No OMEN,
local graph recomputation, or agents were used.

## 2026-09-29 — A peripheral-vacancy restriction at first surplus

Note 205 proves a general necessary condition in the tight,
gapless \(f=4r+4\) branch. For an internal face-chord block,
the vacancy cannot have occupied eligible positions on both
sides: its matching mate would be forced to the block's first
free slot, leaving an odd set of earlier free slots closed
under the matching by planar no-straddling. If the vacancy
is first with targets only to its right, the preceding
face-chord block must be short; the reversed placement
requires a following short block. The \(r=2\) family of
Note 204 realizes the first placement, and reversal of its
amplified family realizes the second, for every \(\ell,r\ge2\).
The zero-target block and the full Hamilton decision were
not decided by this restriction. No OMEN, local graph
recomputation, or agents were used.

## 2026-09-29 — The zero-target vacancy is realizable at every chord count

Note 206 gives an explicit \(r=2,f=12\) Barnette parent for
every \(\ell\ge1\), with all nonfinal escape targets in the
left site block and the unique eligible vacancy in a
four-slot, target-free face-chord block. Its opposite-side
matching chords form a nested chain disjoint from the final
escape edge; a connected matching interlacement graph proves
three-connectivity, and two displayed \(M\cup A\) paths form
a marked Hamilton cycle. A short facial square after the
vacancy meets Note 190's amplifier hypotheses, so the same
shape exists for every \(r\ge2\) with \(f=4r+4\).
Consequently all three shapes allowed by Note 205 occur in
Hamiltonian Barnette parents. General Hamiltonicity at this
boundary and the full conjecture remain open. No OMEN, local
graph recomputation, or agents were used.

## 2026-09-29 — A universal Hamilton theorem for one long face-chord block

Note 207 proves more than the explicit Note 204 family. In
any tight gapless \(f=4r+4\) opening with \(\ell\ge2\) and
all block-extra slots concentrated in one face-chord block,
Note 205 makes the sole vacancy first or last in that block.
For the first case, the targets create a matching barrier.
All free matching chords to its left are noncrossing and
the three-edge connectivity condition forbids skipping a
closed run of short blocks. The complete matching is the
ordinary chain with one replacement
\(e_{s-1}o_s\mapsto\{e_{s-1}i,o_sh\}\), for some
\(1\le s<k\). The even old-cycle matching joins every
such pattern into a parent Hamilton cycle through both
site edges. Reversing the opening handles the last-slot
case. Thus every legal expanded child in this entire
single-long-block subclass is Hamiltonian. Multiple long
blocks, gaps and target-order defects remain undecided.
No OMEN, local graph recomputation, or agents were used.

## 2026-09-29 — One-sided internal vacancies are universally Hamiltonian

Note 208 removes Note 207's single-long-block restriction.
In a tight gapless first-surplus opening, every occupied
target run has an even number of free slots before it.
At most one same-block free matching edge could cross
that target; cross-block edges are forbidden by planar
no-straddling. Matching parity therefore forbids all
crossings. Between target runs, normal free-slot groups
form forced chains, and the one group containing a
one-sided internal vacancy has exactly one possible
chain detour, indexed by its short-block position.
The corresponding two \(M\cup A\) paths yield a parent
Hamilton cycle through both site edges for every
such opening, regardless of target distribution among
the other blocks. Note 205 eliminates the two-sided
case, leaving only target-free internal vacancy blocks
within this tight gapless branch. No OMEN, local graph
recomputation, or agents were used.

## 2026-09-29 — The tight gapless internal-vacancy branch is Hamiltonian

Note 209 closes the target-free four-slot case left by
Note 208. A hypothetical matching chord between the
first and last free slots of that block would force the
vacant slot to match outside; either direction encloses
an odd number of still-free endpoints in the same
noncrossing disk, so the chord is impossible. All
remaining free chords are cross-block. The three-edge
connectivity rule excludes a chord skipping a complete
short-block interval, leaving exactly two detour
directions: replace one chain edge \(e_{s-1}o_s\) by
\(e_{s-1}i,o_sh\), with \(s\le k-1\) or \(s\ge k+2\).
Both yield an explicit parent Hamilton cycle through
the site edges, and Note 001 lifts it. Together with
Note 208, every tight gapless first-surplus opening
whose sole eligible vacancy is internal has a
Hamiltonian site-expanded child. The full conjecture
remains open. No OMEN, local graph recomputation,
or agents were used.

## 2026-09-29 — Tight gapless first-surplus openings are Hamiltonian

Note 210 closes the outer-block vacancy left by Note 209. Peeling
occupied boundary targets moves the sole vacancy to the second
slot of the left site block. The reduced block has four interior
slots and the next face-chord block is short. Target-run parity
and planar noncrossing leave only one detour of the free matching
chain, which makes an explicit parent Hamilton cycle through both
site edges. The two possible six-vertex inverse routes preserve
those marks when the boundary lobes are restored. Hence every
tight, gapless opening at \(f=4r+4\) has a Hamiltonian child.
No OMEN, local graph recomputation, agents, or publication were used.

## 2026-09-29 — Endpoint defects have marked Hamilton cycles for all chord counts

Note 211 extends the one-chord endpoint theorem of Note 201 to
every \(r\ge1\). A delayed first target is forced into the third
slot of a noninitial block; all preceding blocks are short. Parity
at the first target and at each later target run prevents matching
edges from crossing them. Noncrossing and the absence of two-edge
cuts then force the entire free matching to be \(o_0w\) plus the
usual \(e_io_{i+1}\) chain. Two explicit \(M\cup A\) paths give a
parent Hamilton cycle through both sites. Reflection handles an
advanced final target. The sole unresolved gapless branch at
\(f=4r+4\) is one nonadjacent lobe transition; gap slots and
nonsquare residual cycles are separate. No OMEN, local graph
recomputation, agents, or publication were used.

## 2026-09-29 — The entire gapless first-surplus branch is Hamiltonian

Note 212 resolves the only case left by Notes 210 and 211: one
nonadjacent transition between consecutive lobe targets. A later
target at a new block's first slot would close a main-prefix plus
square-suffix two-edge cut, regardless of intermediate block length.
A defect within one block leaves two adjacent free slots isolated
by even-prefix matching parity and is impossible. Across blocks,
the unique vacancy forces the later target to the third slot and
all intermediate blocks to be short. Noncrossing and the prefix
cut force exactly one new matching edge \(c_iw\); all other free
edges form the ordinary chain. That edge replaces the missing
target transition by the alternating route
\(L_j,c_i,w,R_{j-1}\), giving a parent Hamilton cycle through both
sites. Thus every legal all-square, gapless opening at
\(f=4r+4\) has a Hamiltonian child for all \(\ell,r\ge1\).
Two gap slots, nonsquare residual cycles, and the full Barnette
conjecture remain open. No OMEN, local graph recomputation,
agents, or publication were used.

## 2026-09-29 — First-surplus gaps must split and disrupt a transition

Note 213 excludes two gap slots in one gap for every \(\ell,r\ge1\).
Saturated block capacity pins all target transitions; parity
forbids matching edges across target runs, so every free chord
lies in the same opposite-side disk. The first gap slot has
only its adjacent gap neighbour or block slots as colour
compatible mates; the former is an old-cycle edge, and every
other chord surrounds an odd number of free endpoints.
When the slots occupy distinct gaps, the same parity argument
shows that tight target transitions leave the first gap slot
unmatched. Its only extra candidate, the second gap slot,
would cross an escape target or enclose a target-free run
with a forbidden two-edge cut. Hence the remaining two-gap
shape requires a nonadjacent transition ending in a reversed
block between the gaps. No Hamilton decision for that shape
or for nonsquare residual cycles follows. No OMEN, local
graph recomputation, agents, or publication were used.

## 2026-09-29 — All two-slot gaps are excluded at first surplus

Note 214 closes the split-gap transition case left by Note 213.
For the first singleton gap slot \(g\), an odd mate to its left
would straddle a defective source target or enclose an odd
number of free endpoints. To its right, any mate past the
first escape target is forbidden by planar no-straddling.
Before that target, each candidate in the reversed blocks
again encloses an odd number of free endpoints; the only
possible same-block edge that could evacuate one endpoint
is excluded by even-prefix matching parity. If the first
target lies beyond the second gap, a chord to that gap
would enclose a target-free block interval and force a
two-edge cut. Thus no first-surplus opening has gap slots.
Notes 196 and 212 now give a marked parent Hamilton cycle
and Hamiltonian legal child for every all-square opening
with \(r,\ell\ge1\) and \(f\le4r+4\). This does not settle
larger \(f\), nonsquare residual cycles, or the conjecture.
No OMEN, local graph recomputation, agents, or publication
were used.

## 2026-09-29 — Separated vacancies compose marked Hamilton routes

Note 215 removes a fixed first-surplus bound from the single-vacancy
detour mechanism. In a tight, gapless all-square opening, each
eligible vacancy adds one adjacent free even/odd pair. With at
most one vacancy per block, every occupied target run has an
even free prefix and at most one same-block matching edge across
it; planar no-straddling and matching parity therefore make the
run a barrier. If different vacancies are separated by such
runs, each free group has at most one exceptional block.
Notes 208--209 then force one chain-edge detour per internal
exceptional group. Outer vacancies are peeled to their first
eligible positions, routed by Note 210, and restored with
Note 185's marked inverse paths. All group detours lie on
disjoint edges of the free Hamilton path. At \(f=4r+6\), two
target-separated vacancies are therefore Hamiltonian.
The statement is conditional on the opening shape and makes
no claim about the full conjecture. No OMEN, local graph
recomputation, agents, or publication were used.

## 2026-09-29 — An adjacent vacancy square has a marked Hamilton absorption

Note 216 identifies one same-group two-vacancy matching at
\(f=4r+6\). Two adjacent target-free four-slot face blocks
can retain the ordinary free chain while their four extra
slots pair across the blocks. The canonical \(M\cup A\)
then has an isolated alternating four-cycle, so connectivity
of that particular two-factor fails. A five-edge path
\(e_k,i_k,h_k,i_{k+1},h_{k+1},o_{k+1}\) replaces the single
chain edge \(e_ko_{k+1}\), visits all four extra vertices,
and joins the usual target and free routes into a marked
Hamilton cycle. This is a sufficient local routing rule,
not a classification of all same-group double vacancies.
No OMEN, local graph recomputation, agents, or publication
were used.

## 2026-09-29 — Double-vacancy squares absorb across unbounded short-block ladders

Notes 217--218 extend Note 216 in two directions. If two
target-free vacancy blocks retain the standard free chain
and their four new slots pair as one alternating square,
any number of short blocks between them form an even-column
four-terminal ladder. Its two-path routing joins the square
to the free Hamilton path while retaining both site edges.
An explicit \(4r+16\)-vertex family for every \(r\ge2\)
realizes the profile in the Barnette class: the two-page
chord drawing is planar and a connected matching-chord
interlacement chain rules out two-edge cuts. When adjacent
vacancies form an otherwise isolated ten-slot free group,
noncrossing, matching parity and three-connectivity force
exactly this absorbable profile. Other same-group matching
profiles and the full Barnette conjecture remain open.
No OMEN, local graph recomputation, agents, or publication
were used.

## 2026-09-29 — One separating short block gives three Hamilton profiles

Note 219 classifies the isolated twelve-slot free group formed by
two target-free vacancy blocks with one short face block between
them. The left boundary slot can match only its next block or the
second vacancy's later odd slot: all other mates enclose a
matching-closed block interval or strand an adjacent old-cycle
pair. Reflection leaves three profiles. One is the paired-square
profile of Note 217; two nested rainbow profiles make the
canonical \(M\cup A\) directly Hamiltonian. A real 28-vertex
Barnette parent realizes each profile: the paired one comes from
Note 217, and changing its free matching gives the two rainbow
examples, whose planar chord embeddings and connected
interlacement graphs are explicit in Note 219. Thus this entire
isolated twelve-slot branch has marked Hamilton parents and
Hamiltonian site-expanded children. Longer free groups remain
unclassified. No OMEN, local graph recomputation, agents, or
publication were used.

## 2026-09-29 — The double-vacancy boundary has three states at every length

Note 220 removes the corridor-length restriction from the
first step of Notes 218--219. In an isolated group with two
target-free vacancy blocks and any number of intermediate
short blocks, the left endpoint can match only the first
slot of the first vacant block or the later odd slot of the
second; every other choice strands adjacent slots or closes
a complete block interval into a two-edge cut. The
reflected statement holds at the right endpoint, and the
two long choices cross in the opposite-side disk. Only
ordinary--ordinary, long-left and long-right boundary
states remain. The same argument excludes either long
block's same-block free chord: after such a chord forces
an extreme boundary match, the other new free slot has
only mates that enclose an odd number of unmatched
free slots. Hence all free matching chords lie in one
noncrossing disk at every corridor length. This is a
structural reduction; longer corridors still lack a
Hamilton decision. No OMEN, local
graph recomputation, agents, or publication were used.

## 2026-09-29 — Every isolated double-vacancy corridor is Hamiltonian

Note 221 uses Note 220's canonical-edge theorem to settle every
corridor length between two target-free vacancy blocks, provided
their common free group has no extra short block outside them.
Only zero, one or two matching edges can join the four vacancy
slots, and exactly two, one or zero ordinary chain links are
respectively missing. With two vacancy-to-vacancy edges, the
remaining four-cycle is absorbed through the even ladder of
Note 217. With one such edge, noncrossing and old-cycle
adjacency exclude the inner pairing; the outer pairing
replaces one chain edge by a five-edge detour. With no such
edge, a crossed reconnection of the two missing links always
interlaces two matching chords or uses an adjacent old-cycle
edge. The two vacancy pairs therefore make independent
three-edge detours. Each case yields a parent Hamilton cycle
through both site edges and a Hamiltonian legal child. This
closes an unbounded same-group branch at \(f=4r+6\), while
same-block vacancies, groups with short-block flanks, target
defects, gaps and nonsquare residual cycles remain open.
No OMEN, local graph recomputation, agents, or publication
were used.

## 2026-09-29 — Flanked double vacancies still have only two chain defects

Note 222 extends Note 220 beyond isolated corridors. In a tight,
gapless, target-free two-vacancy group, arbitrary short-block
flanks do not permit a same-block free chord: an ordinary mate
of the remaining vacancy slot traps an odd number of free
endpoints, while the only cross-vacancy mate would close the
whole interval into a two-edge cut. Every ordinary-to-ordinary
edge is therefore a standard chain edge; at most two such
edges can be missing, regardless of flank or corridor length.
No OMEN, local graph recomputation, agents, or publication
were used.

## 2026-09-29 — Every distinct target-free double vacancy is Hamiltonian

Note 223 closes the remaining crossed-reconnection case of
Note 222. With two vacancy-to-vacancy matching edges, Note 217
absorbs their square; with one, a five-edge route replaces the
sole missing chain edge. With none, two chain links are missing.
Parallel reconnections give two disjoint three-edge detours.
For either crossed reconnection, noncrossing matching chords
force one cut port to be between the vacant blocks and the
other outside them; the intervening complete block interval
is then matching-closed, a forbidden two-edge cut. This gives
a marked parent Hamilton cycle for arbitrary short-block
flanks and separation whenever the two vacancies occupy
distinct target-free face blocks in one group. Note 215
handles target-separated groups. The full Barnette conjecture
remains open. No OMEN, local graph recomputation, agents, or
publication were used.

## 2026-09-29 — The isolated same-block double vacancy has one matching

Note 224 handles two vacancies in a single target-free
six-slot face block when its free group has no short-block
flank. The left boundary slot has four possible odd mates;
three force a two-edge cut, an odd unmatched interior,
or crossing chords. The remaining choice forces two nested
same-block chords and the opposite-side boundary chords.
The ordinary \(M\cup A\) has a separate four-cycle, but an
explicit ten-vertex path through the six slots and the
face-chord endpoints replaces its free-path segment and
gives a parent Hamilton cycle through both site edges.
A 20-vertex cycle-plus-matching construction realizes
the profile in the Barnette class, and its 24-vertex
site-expanded child is Barnette and Hamiltonian.
Same-block groups with flanks remain open. No OMEN,
local graph recomputation, agents, or publication were used.

## 2026-09-29 — Arbitrary one-sided flanks of a same-block double vacancy

Note 225 classifies a target-free double-vacancy block with any
number \(t\) of short blocks on one side and none on the other.
The matching either retains the isolated local pattern of
Note 224 or has two missing ordinary chain links indexed by
\(0\le d<a\le t-1\). Four nested cross-block chords reconnect
those links through the two vacancy pairs. Each profile gives
an explicit Hamilton parent cycle through both site edges;
the legal expanded child is Hamiltonian. A 28-vertex Barnette
parent realizes the first nonlocal rainbow, and its 32-vertex
expansion is Barnette and Hamiltonian. The proof uses planar
chord order, matching parity, and forbidden two-edge cuts.
Groups with short-block flanks on both sides remain outside
this theorem. No OMEN, local graph recomputation, agents,
publication, or push were used.

## 2026-09-29 — Two-sided double vacancies without an internal chord

Note 226 allows arbitrary short-block flanks on both sides
of a target-free same-block double vacancy, provided its
complementary matching has no free chord internal to that
block. All free chords then lie in one disk; an ordinary
edge is a standard chain link. Exactly two such links are
missing. Of the six left/right placements of a crossed
reconnection, every one has two interlacing matching
chords, so the two vacancy pairs reconnect the missing
links separately. Two disjoint three-edge replacements
yield a marked Hamilton parent cycle and a Hamiltonian
legal child. A 28-vertex two-sided Barnette graph realizes
the mixed left/right detours. The remaining target-free
two-sided interface requires an internal block chord.
No OMEN, local graph recomputation, agents, publication,
or push were used.

## 2026-09-29 — All target-free same-block double vacancies are Hamiltonian

Note 227 removes Note 226's no-internal-chord assumption.
The four possible internal chords are \(oe,oh_2,h_1i_2,i_1e\).
The ordinary-edge skipping rule leaves only standard chain
edges or \(oe\). If \(oe\) occurs, planarity forces \(h_1i_2\)
and the local Note 224 route. If \(h_1i_2\) occurs alone,
one missing chain link is replaced by a five-edge path.
Every profile involving \(oh_2\) or \(i_1e\) has interlacing
opposite-side chords, or three pairwise interlacing internal
chords. The chord-free case is Note 226. Therefore every
target-free same-block double vacancy has a marked Hamilton
parent cycle and a Hamiltonian legal child, regardless of
short-block flank lengths. With Notes 215 and 223 this
settles every tight, gapless two-vacancy opening whose
vacancies both lie in target-free face-chord blocks.
Target-bearing and outer-block vacancies, defective order,
gaps, and nonsquare residual cycles remain open.
No OMEN, local graph recomputation, agents, publication,
or push were used.

## 2026-09-29 — One occupied target pair between same-block vacancies

Note 228 handles the first target-bearing double-vacancy
block: its interior order is \(o,h_1,i_1,L,R,h_2,i_2,e\),
with one occupied consecutive \(L,R\) transition and
arbitrary short-block flanks. Matching parity and colour
balance allow zero or two internal chords across that
target run. Zero separates the two one-vacancy detours.
With two, the escape edges force both chords to the
site-face side, leaving only \(oe,h_1i_2\) or
\(h_1i_2,i_1h_2\). The first uses the existing local
route. For the second, replacing the target-path edge
\(LR\) by \(L,i_1,h_1,i_2,h_2,R\) absorbs all four
extra slots. Thus every such parent has a marked
Hamilton cycle and its legal child is Hamiltonian.
A 26-vertex Barnette parent and 30-vertex child
analytically realize the target detour. Longer target
runs and other target placements remain open.
No OMEN, local graph recomputation, agents,
publication, or push were used.

## 2026-09-29 — A concentrated target run has a second Hamilton route

Note 229 extends Note 228 to any number \(\ell-1\ge1\)
of occupied target pairs between same-block vacancies,
provided every other face block is short. The zero-crossing
and \(oe,h_1i_2\) profiles retain their earlier detours.
For the \(h_1i_2,i_1h_2\) profile, a new pair of spanning
\(x\)-to-\(v\) paths avoids the one-pair restriction:
the outer path follows all face chords and includes
\(xy,uv\); the inner path starts through residual square
\(S_\ell\), traverses the main free slots and concentrated
target run, inserts each intermediate residual square,
and finishes through \(S_1\). The two paths partition all
vertices except their common endpoints, giving a marked
Hamilton cycle. An explicit cycle-plus-matching family
of order \(6\ell+14\) realizes this profile for every
\(\ell\ge2\), with three-connectivity proved by a connected
matching-chord interlacement graph. The legal children
are Hamiltonian. Target runs outside the vacancy block
remain outside this two-path argument.
The same note now extends the marked conclusion to
occupied target pairs in either outer site block:
Notes 185--186 peel them by simple incident-edge
inverses and lift the reduced marked cycle while
retaining both site edges. Dispersed targets in
other face blocks remain the unresolved interface.
No OMEN, local graph recomputation, agents, publication,
or push were used.

## 2026-09-29 — Peripheral double vacancies before a target run

Note 230 proves a marked Hamilton cycle when two vacancies
are the first two or last two eligible positions in one
target-bearing face block, even if other blocks have occupied
target runs. Every free-slot prefix before a target run has
even size. Cross-block chords cannot cross escape targets,
and at most one same-block chord could cross a run, so the
free matching splits at all target barriers. In the group
containing the vacancies, planarity and the two-edge-cut
rule force two nested detours replacing distinct standard
links. The two vacancy pairs are absorbed by those detours;
the unchanged target-and-square path closes a Hamilton cycle
through both site edges. A 34-vertex parent and its 38-vertex
legal child have explicit planar, three-connectivity and
Hamilton certificates. The remaining dispersed-target case
has occupied targets in other internal face blocks between
the two vacancies. No OMEN, local graph recomputation, agents,
publication, or push were used.

## 2026-09-29 — Dispersed target runs have a same-square Hamilton sweep

Note 231 closes the internal-block dispersion left after
Note 229: the two vacancies are first and last eligible
positions of one target-bearing face block, while all other
blocks may have occupied target runs. The local free-chord
classification still gives zero crossing, the local pair,
or \(h_1i_2,i_1h_2\). The first two cases have the earlier
marked routes. In the last, every ordinary free slot follows
the standard chain. Each interval from \(R_j\) to \(L_j\)
contains no other target and has a path through precisely
its free slots. A new route visits these intervals in
descending \(j\), joining them through the exposed outer
halves of the residual squares. Together with the path
along all face chords, it is a Hamilton cycle through both
site edges. A 36-vertex three-connected plane bipartite
parent with an occupied target pair in another internal
block gives a concrete dispersed instance; its 40-vertex
site expansion is Hamiltonian. Target positions outside
the vacancies within their own block, defects, gaps,
and nonsquare residual cycles remain unaddressed.
No OMEN, local graph recomputation, agents, publication,
or push were used.

## 2026-09-29 — Facing vacancies in two occupied blocks

Note 232 treats two vacancies in different target-bearing
face blocks with no occupied target between them. The left
vacancy follows its block's target run, the right vacancy
precedes its block's run, and any intervening blocks are
short. The free group has only cross-block opposite-side
chords. Three-connectivity restricts ordinary-to-ordinary
edges to standard links; noncrossing and forbidden old-cycle
edges leave a nested pair, one five-edge detour, or two
three-edge detours. The detours give marked Hamilton cycles
directly. For the nested pair, all standard links remain;
Note 231's same-square sweep traverses both vacancy pairs
inside one \(R_j\)-to-\(L_j\) interval. An explicit
36-vertex Barnette parent and 40-vertex legal child realize
the nested profile. Vacancies at other positions inside
target-bearing blocks remain unclassified. No OMEN,
local graph recomputation, agents, publication, or push
were used.

## 2026-09-29 — All same-block double vacancies at the tight gapless boundary

Note 233 completes the same-face-block two-vacancy branch
under the compressed all-square, tight-target, empty-gap
hypotheses. Split the occupied target pairs of that block
into runs before, between, and after the vacancies. Notes
227, 230, 231 cover the empty and single-run placements.
When both outer runs exist and the middle is empty,
matching parity isolates four adjacent free slots that
cannot be perfectly matched. If the middle run and at
least one outer run exist, the outer runs are parity
barriers; the middle run must be crossed by exactly
\(h_1i_2,i_1h_2\). All other free slots follow the
standard chain, and Note 231's same-square sweep forms
a Hamilton cycle through both site edges. A 32-vertex
Barnette parent and 36-vertex legal child realize a
previously untreated internal placement. Distinct-block
mixed configurations, outer vacancies, target-order
defects, gaps, and nonsquare residual cycles remain.
No OMEN, local graph recomputation, agents, publication,
or push were used.

## 2026-09-29 — All two internal vacancies at the tight gapless boundary

Note 234 closes the mixed distinct-block case and combines
it with Notes 215, 223, 232, and 233. In the mixed case one
vacancy block is target-free, while the other has an occupied
run beyond its vacancy; no occupied target lies between them.
The only possible same-block free chord in their shared group
is \(oe\) in the target-free block. Ordinary-to-ordinary
cross-block chords must be standard, since a skipped complete
block interval would make a two-edge cut. If \(oe\) were used,
its two neighbouring standard ports would have to match the
far vacancy slots; the remaining even vacancy slot would
have no planar mate. Thus all free chords lie in one
noncrossing disk. By the number of vacancy-to-vacancy edges,
the remaining matchings admit a same-square sweep, one
five-edge detour, or two independent three-edge detours.
This proves marked Hamiltonicity for every tight, gapless,
all-square opening with exactly two internal face-block
vacancies, equivalently \(f=4r+6\). A 30-vertex Barnette
parent and 34-vertex child explicitly realize the mixed
nested profile. Outer-block vacancies, target-order defects,
gaps, and nonsquare residual cycles remain. No OMEN, local
graph recomputation, agents, publication, or push were used.

## 2026-09-29 — The full tight gapless second-surplus boundary

Note 235 extends Note 234 to either site block, closing all
two-vacancy placements at \(f=4r+6\) under tight target order,
empty gaps, and an all-square opening. Boundary peels preserve
the marked site edges; distinct-block free groups map to the
one-sided classifications of Notes 232 and 234. For two
vacancies in one site block, an intervening target run forces
the nested same-block pair and a same-square sweep. With no
intervening run, both potential same-block free chords are
excluded; noncrossing then forces two rainbow detours. An
explicit 24-vertex parent and 28-vertex legal child realize
the rainbow state. The result is opening-relative; target
defects, gap slots, and nonsquare residual cycles remain.

## 2026-09-29 — A separated target defect composes with a vacancy

Note 236 treats a non-tight part of \(f=4r+6\): one endpoint
or transition defect consuming one eligible vacancy, plus
one internal face-block vacancy outside the defect block
or blocks. Every occupied target run remains a matching
barrier because the second vacancy changes each free-prefix
count by two. The defect group retains Note 211's endpoint
matching or Note 212's transition matching. The other group
has one three-edge vacancy detour, so the two internally
disjoint spanning paths still make a marked Hamilton cycle.
A 28-vertex Barnette parent has an explicit complementary
matching, connected chord-interlacement certificate, and
vertex-by-vertex Hamilton cycle; its 32-vertex legal child
is Hamiltonian. This does not decide two defects, an extra
vacancy in a defect block or group, gap slots, nonsquare
residual cycles, or Barnette's conjecture. The source check
read Gorsky--Steiner--Wiederrecht (arXiv:2202.11641v3,
Theorem 5.1 and its discussion of the HMM cube expansion)
and Schnieders (arXiv:2508.03531v1, Theorem 1.12);
the HMM generation theorem does not make every
\(C_4\)-expansion Hamiltonian, while Schnieders
assumes all face sizes are at most eight. No OMEN, local graph
recomputation, agents, publication, or push were used.

## 2026-09-29 — Disjoint target defects compose at every saturated surplus

Note 237 extends the one-defect paths of Notes 211--212
to any number \(s\) of target-order defects in a gapless
all-square opening, provided the defect budget is
saturated and their closed block intervals are pairwise
disjoint. Each defect then receives exactly one eligible
vacancy. At every occupied target, other completed defects
change the free prefix by an even number; cross-block
chords cannot straddle the target and at most one
same-block chord could cross, so parity closes each
matching group. Endpoint and transition groups retain
the known forced matching, and their path substitutions
are disjoint. The unchanged ordinary path and the
simultaneously repaired target-and-square path form a
Hamilton cycle through both site edges. A 28-vertex
parent with both endpoint defects has a planar matching,
connected chord-interlacement certificate, and explicit
Hamilton route; its 32-vertex legal child is Barnette.
Overlapping defect intervals, spare vacancies, gaps, and
nonsquare residual cycles remain outside the theorem.
No OMEN, local graph recomputation, agents, publication,
or push were used.

## 2026-09-29 — Both endpoint target defects at second surplus

Note 238 settles \(s=2,d_L=d_R=1,b=0\) without
separation assumptions. If the first and last targets
occupy different blocks, Note 237 applies. If they share
one block, exactly two same-block free chords could cross
the target run. Taking both leaves a complete prefix
or suffix matching-closed, contradicting three-connectivity;
taking neither closes the left and right free groups
separately. The endpoint repairs of Note 211 and its
reflection then splice into one marked Hamilton cycle.
An explicit 24-vertex parent with both targets in one
face block has a planar matching, a connected
chord-interlacement certificate, and a vertex-by-vertex
Hamilton cycle; its 28-vertex legal child is Barnette.
Transition defects overlapping another defect, spare
vacancies, gaps, and nonsquare residual cycles remain.
No OMEN, local graph recomputation, agents, publication,
or push were used.

## 2026-09-29 — An endpoint and a cross-block transition defect

Note 239 treats one endpoint defect and one transition
defect at \(s=2\) when the transition targets lie in
different blocks. The only new overlap makes the delayed
first target and transition source share a block. Two
same-block chords across its occupied run would close a
complete prefix into a two-edge cut; without them the
endpoint and transition matching groups are separate.
Notes 211--212 then repair the two target-path edges
simultaneously. A 34-vertex Barnette parent and
38-vertex legal child realize the shared-block shape.
No OMEN, local graph recomputation, agents, publication,
or push were used.

## 2026-09-29 — Same-block transition with an endpoint defect

Note 240 handles the remaining endpoint-plus-transition
configuration at \(s=2\), where both targets of the
defective transition lie in one block. If the block is
not the endpoint site block, parity and a two-edge-cut
argument leave its adjacent free pair unmatched.
In the site block the free matching is uniquely
\(o_0d,wc\) plus the ordinary standard chain. A modified
same-square sweep starts \(x,o_0,d,c,w,R_\ell\), traverses
the first residual square in full, then uses each
same-lobe \(R_t\)-to-\(L_t\) interval. Together with the
exposed-face path it forms a Hamilton cycle through both
site edges. An explicit 26-vertex Barnette parent and
30-vertex legal child realize the matching. The two
defect branch at second surplus now remains only for
overlapping pairs of transition defects. No OMEN,
local graph recomputation, agents, publication, or push
were used.

## 2026-09-29 — Two transition defects at second surplus

Notes 241–242 settle the saturated gapless all-square case
\(s=2,d_L=d_R=0,b=2\). For two cross-block defects,
their intervals either separate or share one block. Two
matching chords across the shared target run would close
a proper prefix and residual-square suffix into a two-edge
cut; excluding them leaves the two Note 212 repairs
independent. The 36-vertex shared-block example has a
connected chord-interlacement certificate and a corrected
vertex-by-vertex marked Hamilton cycle; its legal child has
40 vertices. A mixed same-block/cross-block pair is
impossible: using both available crossing chords closes a
prefix or suffix into a two-edge cut, whereas using none
strands adjacent free slots. Two same-block defects in
different blocks are likewise impossible. When both stay
in one block, their four special free slots force the
matching \(cd',dc'\); the target path uses the old-cycle
detours \(L_j,c,d,R_{j-1}\) and \(L_k,c',d',R_{k-1}\),
and the ordinary path remains standard. A 32-vertex
parent and 36-vertex legal child realize this type.
The theorem concerns exactly two target-order defects;
spare vacancies, gaps, and nonsquare lobes remain open.
No OMEN, local graph recomputation, agents, publication,
or push were used.

## 2026-09-29 — Same-block transition clusters at arbitrary surplus

Note 243 proves a marked Hamilton theorem for every gapless
all-square opening with tight endpoints, \(b=s\), and all
nonadjacent consecutive-lobe transitions staying within
individual blocks. Each defective transition contributes
exactly two adjacent free slots. The first and last defective
targets in each block are even-prefix barriers, so that block's
special slots form a closed matching group. A singleton defect
block cannot be matched. All ordinary links remain the standard
chain; replacing every missing target edge by its three-edge
old-cycle subpath produces a Hamilton cycle through both site
edges. An explicit family with \(r=1,\ell=s+1\) realizes every
\(s\ge2\) on \(8s+16\) vertices; nested special chords, a
connected chord-interlacement graph, and the marked two-path
route are given analytically. Its legal expanded child has
\(8s+20\) vertices. Cross-block defects, spare vacancies,
gaps, and nonsquare lobes are outside the theorem. No OMEN,
local graph recomputation, agents, publication, or push were used.

## 2026-09-29 — A doubly delayed first target

Note 244 treats the second-surplus left endpoint defect when
both vacant eligible positions lie before the first target in
its own block, so that target is the fifth interior slot.
The free prefix is matching-closed by no-straddling and parity.
The first free slot cannot match an earlier block end without
creating a two-edge cut, nor the nearer of the two vacant
slots without stranding the next odd slot. It is forced to
match the fourth slot before the target. Noncrossing then
forces one indexed rainbow detour in the remaining prefix;
the first target cannot lie in blocks 0 or 1. The target
path starts through this outer chord and the free path absorbs
the inner two chords. Reflection handles a doubly advanced
last target. A 20-vertex Barnette parent and its 24-vertex
legal child realize the profile with explicit paths and
connected chord-interlacement. No OMEN, local graph
recomputation, agents, publication, or push were used.

## 2026-09-29 — A delayed endpoint with an earlier vacancy

Note 245 closes the remaining second-surplus configuration in
which both vacant eligible positions precede the first target:
that target is the third interior slot of B_h, and the other
vacancy lies in B_k with k<h. The even free prefix is closed
under the matching. A first-slot chord to the final free slot
of any earlier complete block creates a two-edge cut, leaving
only a chord to the earlier vacancy or to the slot immediately
before the target. The former forces a second direct chord and
a five-edge target detour; the latter encloses one target-free
vacancy group, whose detour follows Note 209 or its site-block
boundary case. The reflected last-target statement follows.
Two 20-vertex parents realize the direct and rainbow profiles,
with explicit matching, planarity, interlacement connectivity,
and marked Hamilton paths; their legal children have 24
vertices. Together with Note 244 this settles both placements
of two vacancies before a delayed first target. No OMEN, local
graph recomputation, agents, publication, or push were used.

## 2026-09-29 — Vacancy immediately after a delayed first target

Note 246 settles the second-surplus profile in which the
second vacant eligible slot immediately follows R_ell in its
block, and that block has no later target. In an internal
block, two same-block chords crossing R_ell would consume
both pretarget free slots and close the earlier complete
prefix into a two-edge cut. The pretarget group therefore
uses Note 211's repair, while the post-target vacancy group
has a forced one-vacancy detour; the next target must be at
least two blocks later. In the left site block, zero crossings
would strand an adjacent pair, and the two crossing chords
are forced to be nested by planarity. A later cross-block
chord then attaches the remaining vacancy to the next block.
Explicit marked cycles are given for 24- and 20-vertex
three-connected bipartite plane parents, with 28- and
24-vertex legal children. No OMEN, local graph
recomputation, agents, publication, or push were used.

## 2026-09-29 — Right-site vacancy before the final target

Note 247 treats the second-surplus opening with a delayed first
target and the other vacancy at any eligible position of the
right site block. When the first target shares that site block,
zero cross-target matching chords strand an adjacent free pair;
two cross-target chords close the earlier blocks into a two-edge
cut. Thus this overlap is impossible. Occupied target pairs
after that vacancy are removed by simple right boundary peels;
their marked Hamilton cycles lift through the inverse operation.
In the reduced opening, any occupied target before the vacancy
would leave the odd slot just before \(L_1\) without a matching
mate, so the site block has four interiors. The first-target
barrier forces Note 211's endpoint repair; the final free group
has one nested two-chord detour, replacing \(e_{t-1}o_t\) by
\(e_{t-1}I,Ho_t\), with \(m+1\le t\le r\) where \(R_1\in B_m\).
Two disjoint paths give a reduced parent Hamilton cycle through
both site edges. A 24-vertex core and 28-vertex legal child
are certified by explicit matching, plane two-page drawing,
chord interlacement connectivity, and Hamilton paths; repeated
right boundary insertions realize every vacancy distance. This is
conditional on the chosen all-square opening, empty gaps and
the stated vacancy locations; Barnette's conjecture remains open.
No OMEN, local graph recomputation, agents, publication or push
were used.

## 2026-09-29 — Single endpoint defects at second surplus

Note 248 completes the gapless all-square second-surplus branch
with exactly one endpoint target-order defect. Its new step is
the second vacancy in the delayed first target's own block,
after that target and possibly after several occupied target
pairs. In an internal block two matching chords across the first
target would close the earlier complete prefix into a two-edge
cut; in the left site block planarity forces the two nested
crossing chords. If occupied targets follow the vacancy, its
adjacent even--odd free pair is isolated by target barriers and
cannot be matched. Otherwise the matching and marked Hamilton
route are the two forms of Note 246, with any number of tight
target pairs before the vacancy. Explicit 30- and 26-vertex
Barnette parents with such a preceding pair have marked cycles,
plane two-page embeddings, and connected chord-interlacement
certificates. Notes 236 and 244--247 cover the other vacancy
locations; reflection covers the advanced last target.

Together with Notes 235 and 238--242 and the Note 197 defect
budget, a non-Hamiltonian legal child at this gapless all-square
second-surplus boundary would require exactly one nonadjacent
transition, \(d_L=d_R=0,b=1\), with a spare vacancy. Gaps,
nonsquare residual cycles, and the full Barnette conjecture
remain open. No OMEN, local graph recomputation, agents,
publication or push were used.

## 2026-09-29 — Same-block single transition defects at second surplus

Note 248's two explicit marked cycles and chord-interlacement
chains were checked edge by edge; its single-endpoint conclusion
survives that check. Note 249 closes the remaining same-block
one-transition, one-spare-vacancy branch. An extra vacancy in
another block strands the transition's adjacent free pair;
putting both vacancies between the targets strands a four-slot
group. Thus a realizable spare lies before or after the transition
in the same block. Parity and planarity force the three special
chords \(e_{h-1}I,o_hd,Hc\) and exclude earlier targets in that
block. The same-square sweep visits an arbitrary tight target run
between the spare and defect in reverse order, while traversing
its residual squares along the old cycle. This gives a marked
Hamilton parent cycle at any such run length; reflection covers
the other side. Explicit 26- and 32-vertex parents and their
30- and 36-vertex legal children have full matchings, plane
chord nests, connected interlacement and spanning paths.
The only gapless all-square second-surplus target-order branch
remaining is a cross-block transition with one spare vacancy.
No OMEN, local graph recomputation, agents, publication or push
were used.

## 2026-09-29 — Intermediate spare vacancy at a cross-block transition

Note 250 treats the gapless all-square second-surplus profile
with exactly one cross-block transition defect and a spare
vacancy in a strictly intermediate face block. The first-slot
destination would create a two-edge cut, so the destination
has a free pair before its target; the source has a free pair
after its target. The closed free group contains one target-free
four-slot spare block. Noncrossing and prefix cuts leave exactly
two matching types: a direct pair \(c_iH,Iw\), or a rainbow
pair around \(c_iw\) with one missing standard link. Each type
has an explicit marked Hamilton detour. A 26-vertex Barnette
parent and 30-vertex legal child realize the direct type, with
full matching, two-page nesting, connected chord interlacement
and two spanning paths. Cross-block placements at the source,
destination, or outside site blocks remain. No OMEN, local graph
recomputation, agents, publication or push were used.

## 2026-09-29 — Both vacancies at a cross-block destination

Note 251 settles a unique cross-block transition defect when
both second-surplus vacancies precede its destination target
in that target's block. The source has one free pair after
its target, and the destination has four free slots before its
target. Target barriers close this group. A prefix cut forbids
the first free source slot from matching any earlier complete
block; adjacency excludes its pairing with the first vacancy.
It must match the last vacancy. Noncrossing forces one indexed
rainbow detour \(e_ti_1,o_{t+1}h_1\), with
\(i\le t\le h-2\); hence adjacent source and destination
blocks cannot realize this profile. The target and free paths
each receive one three-edge replacement and form a marked
Hamilton cycle. Reflection covers one vacancy after the source
target and one before the destination target. An explicit
26-vertex Barnette parent and its
30-vertex legal child have full matchings, plane nesting,
connected interlacement and spanning paths. The initially
drafted Note 252 described the reflected case separately and
was removed as duplicate. No OMEN, local graph recomputation,
agents, publication or push were used.

## 2026-09-29 — Outside site vacancy with a cross-block transition

Note 252 extends the separated-defect composition to a spare
vacancy in the left site block before a cross-block source;
reflection handles the right site after the destination. An
occupied target after the left-site vacancy would isolate its
adjacent free pair. Otherwise the site group forces a rainbow
detour \(Ho_t,Ie_{t-1}\), while the transition group retains
Note 212's \(c_iw\) repair. The resulting two marked paths
span the parent. A 30-vertex Barnette parent and 34-vertex
legal child have explicit matching, plane chord nests,
connected interlacement and Hamilton paths. No OMEN, local
graph recomputation, agents, publication or push were used.

## 2026-09-29 — Spare vacancy before a cross-block source

Note 253 treats the spare vacancy in the source block before
its target. The two possible matching chords across that
target either interlace on the site-face side or close a
main-prefix plus square-suffix interval into a two-edge cut.
Thus the spare and defective transition occupy separate
matching groups. Any occupied target before the spare in its
block would strand an adjacent free pair. The remaining
pretarget group forces one rainbow detour
\(e_tI,o_{t+1}H\), and the defect group forces \(c_iw\).
Their marked path repairs compose. Reflection handles the
destination-posttarget placement. A 30-vertex parent and
34-vertex legal child have explicit spanning paths and
three-connectivity certificates. No OMEN, local graph
recomputation, agents, publication or push were used.

## 2026-09-29 — Complete gapless all-square second-surplus theorem

Note 254 combines the second-surplus defect budget with the
marked Hamilton theorems for zero, one and two target-order
defects. For the last one-transition case, a same-block
transition is Note 249. For a cross-block transition, the
destination is third or fifth in its block. A fifth-slot
destination uses both vacancies there (Note 251). With a
third-slot destination, the spare is outside the interval
(Notes 236, 252), in an intermediate face block (Note 250),
before or after the source in its own block (Notes 253 and
251 by reflection), or after the destination in its block
(Note 253 by reflection). This exhausts all block placements.
Every admissible opening has a parent Hamilton cycle through
both site edges, so the legal child is Hamiltonian. Together
with Notes 196 and 212, a non-Hamiltonian child in this selected
gapless all-square class would need at least third surplus,
\(f\ge4r+8\). Gaps, nonsquare residual cycles and the full
Barnette conjecture remain open. No OMEN, local graph
recomputation, agents, publication or push were used.

## 2026-09-29 — Saturated block capacity excludes every gap

Note 255 proves more generally that any positive gap requires
a block-internal free chord on the designated-face side.
Without one, a gap-to-block chord encloses an odd number of
free slots; a gap-to-gap matching forces either an old-cycle
edge or a matching-closed complete block interval with a
two-edge cut. At saturated block capacity, target barriers
exclude every such internal chord.
Thus a positive gap needs at least one unoccupied eligible block
position. At the second surplus, this removes the entire
four-gap-slot, zero-vacancy profile; the two-gap-slot,
one-vacancy profile remains. The Note 254 gapless theorem was
checked at the block-placement interface. No OMEN, local graph
recomputation, agents, publication or push were used.

## 2026-09-29 — One two-slot gap is impossible at second surplus

Note 256 treats the remaining second-surplus profile with both
gap slots in one gap. The general gap obstruction requires a
block-internal face-side free chord. With one eligible vacancy,
the only possible chord is \(o_ke_k\) in a target-free face
block. After reflection, parity and noncrossing force
\(gI,hH\) between the gap and that block. Any intervening
short blocks are matching-closed; if none intervene, the gap
and vacancy block together are matching-closed. Either case
gives a forbidden two-edge cut. Thus the only unsettled
all-square second-surplus gap profile has two distinct
singleton gaps and one eligible vacancy. No OMEN, local
graph recomputation, agents, publication or push were used.

## 2026-09-29 — Split gaps need a target-bearing vacancy block

Note 257 excludes a target-free unique-vacancy block when two
singleton gaps remain at second surplus. The general gap
obstruction forces its first-to-last free-slot chord on the
designated-face side. Each gap slot must then match a different
middle slot. For all three relative block orders, the resulting
noncrossing chords close a consecutive complete-block interval
under the complementary matching and create a forbidden two-edge
cut. The remaining all-square second-surplus interface puts an
occupied escape target and a free eligible vacancy in the same
block; an eligible position occupied by \(L_1\) cannot supply
the required face-side chord either. No OMEN,
local graph recomputation, agents, publication or push were used.

## 2026-09-29 — All-square second surplus and gap-edge localization

Note 258 completes the split-gap, target-bearing vacancy case.
An all-surplus localization lemma shows that no two gap slots
can be matching mates: without an intervening target their
chord encloses a matching-closed interval and a two-edge cut,
while an intervening target forbids the chord by planarity.
Odd free-slot parity makes every gap-to-block edge land in a
block with a face-side free chord. At one eligible vacancy,
all gap mates therefore enter the vacancy block. Its at most
five free slots leave capacity for only two gap mates; the
unique face-side chord forces both mates into its four-slot
run. The forward run sends a gap chord across the next
escape target, and the reversed run sends one across the
first target in its block. Hence positive gaps require at
least two eligible vacancies and \(f\ge4r+8\). Combining
with Note 254, every all-square second-surplus opening has
a parent Hamilton cycle through both site edges and a
Hamiltonian legal child. At the next boundary, any positive
gap has exactly two vacancies and two gap slots. This does
not settle nonsquare residual cycles or the general Barnette
conjecture.
The proof was checked against Notes 193, 195, 197, 203,
254--257; Schnieders's arXiv:2508.03531v1, Theorem 5.2,
was read for the distinct face-size-at-most-eight boundary.
No OMEN, local graph recomputation, publication or push
were used.

## 2026-09-29 — Two target-free vacancy blocks cannot carry a third-surplus gap

Note 259 gives a cross-block parity law: a free matching chord
between distinct blocks sees the same parity of face-side
chords across its two endpoints. At \(f=4r+8\), a positive gap
has exactly two eligible vacancies and two gap slots. If the
vacancies lie in distinct target-free four-slot blocks, each
gap slot must use an inner slot of one block's outer face-side
chord. When both use one block, their two chords close the
shortest old-cycle interval containing that block and the
gaps. When they use different blocks, the unused inner slots
must match each other by parity; three cross-atom chords then
connect the two blocks and gap slots, closing their interval.
Either interval gives a forbidden two-edge cut. The surviving
third-surplus positive-gap shapes have both vacancies in one
block or at least one vacancy in a target-bearing block.
No OMEN, local graph recomputation, publication or push
were used.

## 2026-09-29 — A sharp 22-vertex positive-gap opening

Note 260 constructs a 22-vertex Barnette parent from the
Hamilton cycle \(0,1,\ldots,21,0\) and an explicit two-page
perfect matching. The common face has site edges \((0,3)\)
and \((14,17)\); its arc \(17,18,21,0\) is alternating
and traps one four-vertex square. The main blocks have
capacities \((0,2,0)\), the last gap has slots \(12,13\),
and \((\ell,r,\sigma,T,f)=(1,1,2,2,12)\). Thus the
positive-gap lower bound \(f\ge4r+8\) is attained. Since
\(|V(G)|\ge4r+6\ell+12\ge22\), this is also the
minimum parent order in the selected positive-gap class. An
explicit parent Hamilton cycle uses both site edges and
lifts to the 26-vertex child. Connected matching-chord
interlacement graphs relative to the old and lifted
Hamilton cycles certify three-connectivity of parent and
child. The example is Hamiltonian, so it is not a Barnette
counterexample. No OMEN, local graph recomputation,
publication or push were used.

## 2026-09-29 — Exact local form of the sharp target-free gap

Note 261 classifies the third-surplus positive-gap branch
whose two vacancies share one target-free six-slot block.
The only possible local face-side chords are among four
non-cycle pairs. The central pair makes the forced gap
chords interlace; the outermost pair strands an inner pair
that has the same crossing. One short-end pair traps the
remaining adjacent slots into a two-edge cut. Up to
reflection, the surviving face-side chord joins slots 3
and 6, the two gap slots meet slots 5 and 4, and the block
immediately precedes one two-slot gap. Distinct singleton
gaps or intervening short blocks create two-edge cuts.
Note 260 realizes this exact form. Target-bearing vacancy
blocks and Hamiltonicity across the full third surplus
remain open. No OMEN, local graph recomputation,
publication or push were used.

## 2026-09-29 — Sharp target-free positive gaps are Hamiltonian

Note 262 identifies Note 261's forced six-vertex patch as
the incident-edge cube insertion of Note 185. Its simple
inverse restores the two edges at the common endpoint,
preserves the selected cofacial opening and both site edges,
and changes \((\sigma,T,f)=(2,2,4r+8)\) to
\((0,0,4r+2)\). Note 196 gives the inverse equality
parent a Hamilton cycle through both site edges. In that
specific cycle, replace \(bw_2\) by the edge-by-edge route
\(w_2,w_3,w_4,h,g,w_5,w_6,b\); this covers the six
inserted vertices and retains both marks. With Note 259,
every third-surplus positive-gap opening whose two vacancies
are in target-free blocks is either impossible or has a
marked Hamilton parent and Hamiltonian legal child. The
cube operation is known in Holton--Manvel--McKay (1985)
and Gorsky--Steiner--Wiederrecht (2023, Section 5);
the application to this opening class is the present result.
The target-bearing and gapless third-surplus branches remain
undecided. No OMEN, local graph recomputation, publication
or push were used.

## 2026-09-29 — Positive-gap sharpness for every lobe and chord count

Note 263 applies the incident-edge cube insertion to any
inner face-chord block of Note 190's equality opening for
arbitrary \(\ell,r\ge1\). The insertion adds four block
slots and one adjacent two-slot gap, preserves the selected
alternating face arc and its \(\ell\) residual squares,
and leaves the \(r\) other face chords unchanged. Thus
\((\sigma,T,f)=(2,2,4r+8)\) for every parameter pair.
The parent remains Barnette; insertion commutes with its
legal site expansion, so the child does too. Replacing
the equality Hamilton cycle's block-end edge by the
seven-edge route of Note 262 gives a parent cycle through
both site edges. Together with Note 258's lower bound,
the exact minimum orders for fixed \((\ell,r)\) are
\(4r+6\ell+12\) for the parent and \(4r+6\ell+16\)
for its expanded child. This sharpness construction does
not classify all third-surplus gaps. Using Note 182's
target-bearing inner block for \(\ell\ge2\), which persists
through Notes 189--190's chord amplification, gives such
sharp Hamiltonian positive-gap examples with both vacancies
in a target-bearing block for every \(r\ge1\). No OMEN, local graph
recomputation, publication or push were used.

## 2026-09-29 — Same-block third-surplus gaps outside the block are Hamiltonian

Note 264 settles every sharp positive-gap opening whose
two vacancies occupy one block lying before or after both
gap slots. Reflect to put the block first. Both gap slots
must match that block. If its final escape target is
\(L_j\), \(j\ge2\), the next \(R_{j-1}\) lies beyond the
gaps and is forced to the first slot of a saturated
forward block, giving the prefix two-edge cut. If it is
\(L_1\), the at-most-four free suffix slots of the
vacancy block are consumed by gap mates and face-side
chords; the whole main suffix beyond the gaps is
matching-closed, another two-edge cut. If the last target
is \(R_j\), the free block suffix must have five slots.
Parity excludes face-side chords crossing \(R_j\), and
the only noncrossing local matching is the cube tail
\(w_3w_6,w_5g,w_4h\). The gap slots are consecutive
and adjacent to that block by the same cut argument as
Note 261. Peeling gives Note 196's equality opening,
whose marked Hamilton cycle lifts by an explicit path.
Target-free blocks follow Note 262. Thus every same-block
opening with one two-slot gap is Hamiltonian; the
same-block split-gap case can remain only when its block
lies between the gaps. In that separating-block case the
two gap mates must lie before and after every escape
target of the block; target-prefix parity and the odd
gap-mate parity require at least two face-side free
chords. No OMEN, local graph recomputation,
publication or push were used.

## 2026-09-29 — Same-block sharp positive gaps close by ladder compression

Notes 265--267 close the separating-block case left by Note 264.
At \(f=4r+8,\sigma=T=2\), two vacancies in one block between
singleton gaps leave either six or seven free block slots.
The six-free matching is forced as in Note 265; its eight
corner vertices induce \(P_4\square K_2\). In the seven-free
case, target-prefix parity rules out a first target at \(z_3\);
the targets fill \(z_5,\ldots,z_{2K-1}\). The two face-side
chords must cross every target and hence are the nested pair
\(z_1z_{2K+2},z_3z_{2K}\). Gap localization gives
\(gz_2,z_{2K+1}h\), leaving \(z_4\) to match before \(g\).
Three-connectivity forces both gaps adjacent to the block.
The same eight-vertex ladder then compresses to a square.
The compressed opening has \((\sigma,T,f)=(1,0,4r+4)\),
so Note 212 gives a Hamilton parent cycle through both site
edges, lifted back through Note 178. Together with Note 264,
every sharp positive-gap opening with both vacancies in one
block has a marked Hamilton parent and Hamilton legal child.
The distinct-block target-bearing branch remains open.

The shared-middle-support corollary also removes a distinct-block
subcase. If both singleton gaps attach to the same intervening
block, a target-bearing one-vacancy block needs six free slots
but has at most five. A target-free support block traps the
interval between the gaps and gives a two-edge cut. Therefore
such shared support either uses both vacancies in that block
and is Hamiltonian by Note 267, or cannot occur.
No OMEN, local graph recomputation, publication or push was used.

## 2026-09-29 — One-vacancy gap support has one face chord

Note 268 proves that a block with exactly one eligible
position unoccupied by a nonfinal \(L\)-target, if it
receives a gap matching edge, has exactly one face-side
free chord. Note 258 supplies at least one. Two chords
would use four endpoints plus the gap mate, forcing all
five available free slots and a target run that begins
and ends with \(L\). The six possible first/internal/last
vacancy profiles across forward and reversed blocks,
combined with the two gap sides, each violate either
bipartite endpoint counts, odd gap-mate localization, or
even target-prefix parity. In the distinct-block sharp
positive-gap branch, saturated blocks cannot receive gap
edges, so each support block has exactly one face chord.
This does not decide its Hamiltonicity. No OMEN, local
graph recomputation, publication or push was used.

## 2026-09-29 — Two target-bearing support blocks cannot split the gaps

Note 269 uses Note 268's one-face-chord result. In each
one-vacancy support block the chord spans a consecutive
four-free-slot run; the unmatched inner slot cannot pair
inside its block or with a saturated block. If two distinct
target-bearing blocks separately receive the two gap slots,
their unmatched inner slots must join. This cross-block edge
cannot straddle a target, forcing the left block to have a
free suffix and the right block a free prefix, with both
gap slots between them. Global gap parity makes the
right block forward, contradicting its required
reversed free prefix. Thus the split support assignment
cannot occur. The mixed target-free/target-bearing assignment
and a single block receiving both gaps remain. No OMEN,
local graph recomputation, publication or push was used.

## 2026-09-29 — Mixed gap support has one orientation and four port rows

Note 270 treats distinct support blocks with one
target-bearing and one target-free. Their unmatched
face-chord inner ports must join by cross-block parity.
If the target-bearing block were on the right, that
port edge would force a reversed free prefix. Its own
gap must lie to its left; the other gap cannot lie to
its right without straddling a target, so two gaps
would precede the block and make it forward, a
contradiction. The target-bearing block is therefore
leftmost and precedes both gaps. Colour and
noncrossing reduce the three positions of the
target-free block to four explicit special-edge
pairings. This is a necessary boundary classification,
not a Hamilton theorem. No OMEN, local graph
recomputation, publication or push was used.

## 2026-09-29 — Distinct sharp vacancy blocks cannot separately support gaps

Note 271 excludes all four mixed-support rows of Note 270.
Each row's three special matching edges cover every possible
position for the next escape target after the target-bearing
block, up to the last gap or the target-free block. The next
target therefore lies farther right, in a saturated forward
block, where it must be the first interior slot. The complete
main prefix before that block plus the corresponding residual
square suffix is matching-closed and has only two departing
old-cycle edges, contradicting three-connectivity. Notes 259
and 269 exclude the other separate-support assignments. The
remaining distinct-vacancy case has both gaps supported by one
block. No OMEN, local graph recomputation, publication or push
was used.

## 2026-09-29 — The sharp positive-gap boundary is Hamiltonian

Note 272 closes the remaining distinct-vacancy assignment.
When both gap slots enter one one-vacancy block outside the
two gaps, Note 268 leaves a single face-side chord and a
four-free-slot run. The two gap edges use its inner ports.
For a target-free support block, the span from that block
through the last gap is matching-closed. For a target-bearing
support block, the four-run follows its last target L_j;
the main prefix through the last gap plus squares S_j through
S_l is matching-closed. Each set has a forbidden two-edge
cut. A support block between split gaps is already covered
by Note 267. Combining Notes 267 and 271 therefore proves
marked Hamiltonicity for every selected all-square opening
with ell,r at least one, f=4r+8, and positive gap total.
The broader Barnette conjecture remains open. No OMEN,
local graph recomputation, publication or push was used.

## 2026-09-29 — Target-free double-vacancy groups compose at all surpluses

Note 273 extends Note 215's separated one-vacancy composition.
In a tight gapless all-square opening, occupied target runs
are matching barriers when each target-bearing block has at
most one vacancy. Thus a free group with two vacancies in
target-free internal face blocks has exactly the local
boundary routing of Notes 223 or 227, independently of
other groups. Replacing disjoint standard free-path segments
simultaneously gives a marked Hamilton cycle at arbitrary
surplus. At s=3 this closes the qualifying two-group and
three-group profiles when every target-bearing block has
at most one vacancy and any double group is target-free
and internal.
No OMEN, local graph recomputation, publication or push
was used.

## 2026-09-29 — Rainbow vacancy cycles absorb at every surplus

Note 274 generalizes Note 217's square absorption to a
rainbow alternating 2q-cycle on q distinct target-free
vacancy blocks. Because all extra slots are paired among
themselves, a two-edge-cut skipping argument forces every
ordinary matching link. Removing one matching edge of
the vacancy cycle turns it into a path; the Note 217 ladder
route attaches its endpoints to the ordinary free path.
For q=3, noncrossing and old-cycle adjacency force the
rainbow matching whenever the six extra slots match only
one another. An explicit planar bipartite construction for
every q has a connected matching-chord interlacement graph,
so the condition is realized by three-connected parents.
No OMEN, local graph recomputation, publication or push
was used.

## 2026-09-29 — All vacancy-only noncrossing matchings absorb

Note 275 classifies every noncrossing matching among distinct
target-free vacancy pairs as a noncrossing partition without
singleton parts: each part is a rainbow alternating cycle.
The ordinary matching chain is forced independently of that
partition. Every closed block interval has a straight spanning
path, a cap of two spanning paths, and a separate always
available two-rail pairing. The cap routes an outer cycle
around arbitrarily nested inner cycles; the straight route
absorbs the outer cycle using the inner cap. Induction gives
a Hamilton parent cycle containing both site edges for every
vacancy-only matching, at arbitrary surplus. Replacing the
rainbow edges in Note 274's analytic construction realizes
every partition type by a Barnette parent; the four-vacancy
nested partition is the first case outside Note 274. The
remaining tight gapless third-surplus branch has at least
one vacancy-to-ordinary matching edge or a vacancy in a
target-bearing/site block. The general Barnette conjecture
remains open. No OMEN, local graph recomputation,
publication or push was used.

## 2026-09-29 — Distinct target-free vacancies have only chain defects

Note 276 extends the two-vacancy exclusion of Note 222 to
arbitrarily many distinct target-free vacancy blocks. If a
same-block ordinary chord were present, its even vacancy
slot could not match an ordinary slot by interval parity.
Matching another vacancy slot would force a second
same-block chord and make the intervening complete blocks
a forbidden two-edge cut. Thus all ordinary-to-ordinary
matching edges are standard links. If q vacancy pairs
have c internal vacancy matching edges, exactly q-c
standard links are missing. When q-c=1 and the vacancy
alternating graph is one spanning path, that path replaces
the missing link and gives a marked Hamilton parent cycle.
An analytic planar bipartite three-connected family of
order 6q+16 realizes this mixed case for every q. At
third surplus, the next unresolved target-free branch has
two or three missing ordinary links, or a separate vacancy
cycle beside the single-link path. No OMEN, local graph
recomputation, publication or push was used.

## 2026-09-29 — Every three-block single-defect group is Hamiltonian

Note 277 closes the third-surplus branch with three
distinct target-free vacancy blocks in one group and
exactly one missing ordinary chain link. Note 276
already handles a connected six-slot alternating path.
Otherwise two vacancy pairs form an alternating square
and the third pair attaches to the missing link. If
the third pair is outside that square, noncrossing
places its missing link outside too, so its detour and
the Note 217 square absorption are disjoint. If it is
inside, noncrossing places the missing link inside the
square, at least one short block away from the third
pair. A top-rail and reverse-bottom-rail route through
the intervening blocks gives the two disjoint paths
needed to absorb the outer square. A 34-vertex analytic
Barnette parent realizes the nested case and has an
explicit marked Hamilton path. The remaining
three-distinct-target-free-block cases have two or
three missing ordinary links. No OMEN, local graph
recomputation, publication or push was used.

## 2026-09-29 — Missing-chain ports separate

Note 278 turns each missing ordinary chain link into a
virtual boundary pair. Together with the actual adjacent
vacancy pairs, the remaining noncrossing matching forms
a noncrossing partition into alternating rainbow cycles.
If two virtual ports share one cycle, every matching
edge of the complete block interval between those ports
stays inside the interval. Its only two departing edges
are old-cycle edges, contradicting three-connectivity.
Thus each cycle contains at most one port at every surplus.
When a group's vacancy matching has at most one edge,
atom counting leaves no port-free cycle; deleting each
virtual port arc gives an independent spanning detour
for its missing chain link. This settles all such groups.
Together with Notes 275 and 277, it closes every tight,
gapless all-square opening with exactly three vacancies
in distinct target-free internal blocks, regardless of
their free-group distribution or matching. The broader
Barnette conjecture remains open. No OMEN, local graph
recomputation, publication or push was used.

## 2026-09-29 — A single mixed vacancy has three four-port routes

Note 279 gives an explicit three-state signature for a
target-free four-port interval with one vacant block
and one missing ordinary link wholly inside it. The
standard free path detours through the vacant pair.
A top-rail forward and bottom-rail reverse route gives
the two-path cap; a complementary split gives the
crossed two-path pairing. Short-block suffixes preserve
all three states by the serial composition already used
in Note 275, and reflection handles a defect on the
other side. This supplies a concrete interface for
absorbing port-free vacancy cycles around mixed
subintervals. It does not settle boundary-attached
ports or arbitrary nested mixed intervals. No OMEN,
local graph recomputation, publication or push was used.

## 2026-09-29 — Mixed port pairs and nested vacancy cycles

Notes 278 and 279 were checked at their load-bearing
interfaces: two ports on one alternating component close a
complete block interval under the matching, and each of the
three local routes covers its four-port patch once. Note 280
extends the mixed-pair routes through an arbitrary closed
vacancy-only interval between the port and its vacancy;
Note 275's prime induction then absorbs cycles around it.
Note 281 permits any number of two-atom mixed port parts.
Their block spans are nested or disjoint except when two
consecutive ports share a short block. Equations (4)--(7)
give explicit S, X, and K routes for that overlap, after
which the same noncrossing induction supplies all three
states for the full group. This is an all-surplus conditional
Hamilton theorem for distinct target-free internal vacancies.
An explicit \(14d+24\)-vertex Barnette family realizes \(d\)
mixed parts plus one separate vacancy square for every \(d\ge2\).
This does not solve Barnette's conjecture. Relevant published
boundaries were checked against the local full texts of
Gorsky--Steiner--Wiederrecht (2023) and Schnieders (2025):
the former gives the brace/C4-expansion setting, while the
latter proves the separate faces-at-most-eight case. No OMEN,
local graph recomputation, publication or push was used.

## 2026-09-29 — One end port can serve arbitrarily many vacancies

Note 282 extends the three-state routing beyond one vacancy
per port component. When the unique port of a component is
its first or last atom, its rainbow matching permits a
straight detour through all vacancy pairs. A cap route
uses one old-cycle arc from the first to the last vacant
block. For the crossed state, the old cycle covers every
block through the penultimate vacancy; a single matching
edge reaches the last vacancy, and its preceding gap is
traversed backwards on one rail and forwards on the other.
With nonconsecutive missing links and short port-source
blocks, the same nesting induction gives S/K/X for any
number of such components and port-free cycles. An explicit
\(6m+20\)-vertex Barnette family has one component with
\(m\ge2\) vacancies. Ports inside their component's atom
order and consecutive multi-vacancy port components remain
outside the theorem. No OMEN, local graph recomputation,
publication or push was used.

## 2026-09-29 — The first interior port component has full routing

Note 283 treats a three-atom component in the order
vacancy, missing-link port, vacancy. Its three matching
edges give a direct detour for S. The two closed block
gaps on either side of the port have Note 275's three
states, even when they contain nested vacancy-only
cycles. Traversing both X rails in opposite directions
gives the cap and crossed routes; the outer vacancy
matching edge is the crossed bottom connection. The
port-adjacent blocks themselves may be vacant, provided
their matching belongs to closed gap components. This
supplies a new all-surplus conditional Hamilton branch,
while larger interior-port components and multiple ports
in the same group remain open. No OMEN, local graph
recomputation, publication or push was used.

## 2026-09-29 — Arbitrary interior-port sides and a boundary-sharing end port

Note 284 extends the interior-port routes to one vacancy on
one side and any positive number on the other. Note 285
extends them to arbitrary positive numbers on both sides.
Its left path was checked block by block, including the
adjacent-first-vacancy substitution; the cap and crossed
routes each cover their two endpoint blocks and every
closed gap exactly once. The two-parameter realization
uses a noncrossing complementary matching, and its
interlacement bridge across the missing link gives
three-connectivity by Notes 217 and 182.

Note 286 proves a separate three-state attachment rule
for an end-port component whose source block lies in a
closed preceding vacancy interval. Its proof constructs a
right continuation that omits precisely the last vacancy
pair, then joins it to the left cap or crossed state.
An explicit Barnette family of order \(6m+28\) realizes
this boundary overlap for every \(m\ge1\).
These are conditional routing theorems, not a proof of
Barnette's conjecture or a verified literature novelty
claim. No OMEN, local graph recomputation, publication
or push was used.

## 2026-09-29 — Complete three-state routing for one missing link per group

Note 287 extends Note 277's nested three-vacancy route:
an arbitrarily long vacancy-only component may surround
an arbitrarily long end-port component starting at its
first vacant block. The proof supplies S by two covering
paths across the first gap, K by a right continuation
followed by the old-cycle arc, and X by top and bottom
rails. A two-parameter Barnette family realizes both
unbounded component lengths.

Note 288 closes the single-missing-link free-group case
under the tight, gapless, all-square, distinct target-free
vacancy hypotheses. If the port is internal, Note 285
applies. For an end port, a short source uses Note 282;
a source vacancy in a closed preceding component uses
Note 286; a source vacancy in a surrounding component
uses Note 287 when first, and otherwise a direct
S detour, unchanged K old-cycle arc, and X rail splice.
The same construction holds when every group has zero
or one missing ordinary link, giving a marked Hamilton
parent cycle and a legal Hamiltonian child. This does
not decide Barnette's conjecture or establish external
novelty. No OMEN, local graph recomputation, publication
or push was used.

## 2026-09-29 — Consecutive opposed end ports with unbounded sides

Note 286's attachment proof depends only on the left
interval's S/K/X signature. Note 289 uses its signature
version to join a reflected end-port component to a
second end-port component across one shared short block.
Both components may have arbitrarily many vacancies;
closed vacancy-only parts can nest in their gaps or
surround the combined span. A two-parameter analytic
Barnette family realizes every positive pair of counts.
This is a two-defect structural branch; other two-defect
arrangements remain open. No OMEN, local graph
recomputation, publication or push was used.

## 2026-09-29 — All consecutive two-port parts with a short shared block

A proposed explicit route for two nested two-atom parts
was removed after checking that Note 281 already covered
it. Note 290 instead proves the unbounded nested
end-port case: the inner part occupies the outer part's
final proper block gap, whose three states substitute
into Note 282's reflected prime construction. A
two-parameter analytic Barnette family realizes the
result.

Note 291 classifies the two port parts when their
atoms are consecutive: they are disjoint or one
nests in the other. Note 289 handles the disjoint
case; Note 290 handles nested end ports. Inspection
of Notes 275, 282, and 285--288 shows their explicit
routes use a proper gap only through S/K/X or an
unchanged old-cycle arc. This substitution covers
nested components with an interior outer port,
including a vacant outward block. Hence every
consecutive two-defect free group with a short shared
block has S/K/X, under the stated tight, gapless,
all-square, distinct target-free vacancy hypotheses.
A 46-vertex analytic Barnette parent realizes the
interior-outer case. The vacant shared-block branch
and other two-defect profiles remain open. No OMEN,
local graph recomputation, publication or push was used.

## 2026-09-29 — Vacant shared block: forced third part and sharp first case

Note 292 shows that when two consecutive missing links
share a vacant block, its vacancy atom cannot join either
port component: both possible adjacent matching edges
are already old-cycle edges. Note 278's port separation
then forces three distinct parts and at least four
vacancies. In the one-sided placement where the
middle vacancy ends a vacancy-only component and the
right port starts its component, Note 288's local
three-state interval and Note 286's signature attachment
give S/K/X for the full group. A 44-vertex analytic
Barnette parent realizes the four-vacancy bound and
has a legal 48-vertex Hamiltonian child. A vacancy-only
part spanning both sides of the shared block remains
the next joint-boundary case. No OMEN, local graph
recomputation, publication or push was used.

## 2026-09-29 — Sharp two-sided vacant shared-block example

Note 293 resolves the first two-sided placement of
the forced third vacancy-only component. If the
shared-block vacancy is internal in that component,
it needs at least three vacancy atoms; the two
separate port components bring the minimum to five.
An analytic 50-vertex Barnette parent attains it.
Its complementary matching is noncrossing and has
connected chord interlacement, and the note lists
spanning S, K, and X paths edge by edge. The
marked Hamilton parent route lifts to a legal
54-vertex Hamiltonian child. This is a sharp
base configuration, not a general two-sided
shared-block theorem. No OMEN, local graph
recomputation, publication or push was used.

## 2026-09-29 — Arbitrary closed gaps in the two-sided shared-vacancy pattern

Note 294 extends Note 293's five distinguished vacancy blocks
to arbitrary distances. Noncrossing confines every additional
vacancy-only component to one of four proper gaps. Each gap
supplies Note 275's straight route and crossed rails. Explicit
replacements in the three base routes cover each gap exactly
once; the cap route reads the two right gaps on the old cycle.
Thus this entire three-component pattern has S/K/X, including
arbitrarily nested vacancy-only parts. A four-parameter analytic
Barnette family realizes every short-gap length tuple, with
parent and legal child orders 50+4 sum(d) and 54+4 sum(d).
At exactly five vacancies, port separation, noncrossing and
old-cycle adjacency force this pattern, so the theorem closes
the entire sharp two-sided branch for consecutive missing links.
Other shared-vacancy atom patterns and the general conjecture
remain open. No OMEN, local graph recomputation, publication or
push was used.

A targeted literature check on 2026-09-29 also read the latest
five-page Zenodo claim "Proof of Barnette's Conjecture"
(10.5281/zenodo.19311816). Its Lemma 5 treats
\(|Q_{ab}|<|I_{ab}|\) as a decrease in the previously defined
disk-area minimum \(\mu(Q_{ab},I_{ab})\), although the pair and
its disk are unchanged. This does not follow, so the claimed
general proof is incomplete as written. The 2025 published
conditional theorem of Florek and the 2025 faces-at-most-eight
preprint of Schnieders do not themselves settle the full class.

## 2026-09-29 — Four-atom surrounding component across consecutive ports

Note 295 settles the first six-vacancy extension of Note 294.
When the extra vacancy joins the component containing the
shared-block vacancy, noncrossing forces a clean first gap
before the left port, or its reflection. Its K state takes
the old-cycle arc past both missing links. Its S state opens
the four-atom alternating cycle in the clean gap, and its X
state uses crossed rails on both sides of the new atom.
All five proper gaps may be arbitrarily long and contain
nested vacancy-only components. The resulting S/K/X theorem
covers every exactly-six-vacancy case with a four-atom
surrounding component, up to reflection. An analytic
five-parameter Barnette family has parent/child orders
56+4 sum(d) and 60+4 sum(d). The remaining sharp six-vacancy
cases put the extra vacancy in a port component. No OMEN,
local graph recomputation, publication or push was used.

## 2026-09-29 — Complete two-sided shared-block branch through six vacancies

Note 296 settles the other six-vacancy case, in which the
extra vacancy joins a port component. Its six vertices are
split across the two sides of that component's alternating
path: the a/o ordinary slots are absorbed in one folded rail,
the e/b slots in another, and H/I in the port detour. Explicit
S, K, X routes use only the straight or crossed signatures of
five closed gaps. Noncrossing and the two-port separation
theorem leave no other component-size profile at six vacancies.
Together with Notes 294--295, every two-sided vacant shared-
block free group with at most six vacancies has S/K/X under
the stated tight, gapless, all-square and distinct target-free
vacancy hypotheses. An analytic five-parameter 56+4 sum(d)
Barnette parent family realizes the sharp port-extended pattern;
its legal child has 60+4 sum(d) vertices. No OMEN, local graph
recomputation, publication or push was used.

## 2026-09-29 — Simultaneous unbounded growth of both end-port components

Note 297 was checked edge by edge: each left fold covers one closed
gap, the cap route splits only the first left-port block, and its old-
cycle arc covers the entire right side except the two cap vertices.
Note 298 then extends the same three-state signature to arbitrary
independent left and right port sizes \(p,q\ge1\). The straight route
traverses the right alternating component backwards; the crossed
route follows the old cycle through all right-port vacancies except
the last, then folds over the final gap. All right-side vertices are
accounted for by these routes and the cap remains unchanged. The
two-page matching, chord-interlacement connection, and exact vertex
count give a \(6(p+q)+38+4d\) vertex Barnette parent family and legal
Hamiltonian children with four more vertices. This remains a theorem
about a specified tight all-square opening, not a resolution of
Barnette's conjecture. A targeted 2026-09-29 literature check read
Gorsky--Steiner--Wiederrecht's brace reduction and Schnieders's
faces-at-most-eight proof; neither supplies the unrestricted conjecture
or the stated four-port routing theorem. No OMEN, local graph
recomputation, publication, or push was used.

## 2026-09-30 — Arbitrary surrounding component across two end ports

Note 299 extends the three-state construction to a vacancy-only
component with any positive number of atoms on both sides of the
shared vacant block, while both port components also have arbitrary
positive size. The outer alternating cycle gives one straight-route
detour. A cap uses an old-cycle arc; the crossed route absorbs each
additional outer block with a two-rail fold. When the block before
the first missing link is itself vacant, the terminal closed interval's
K state splits it into two paths and attaches it to the left-port
chain. The proof inventories all blocks and proper gaps in each state.
Noncrossing gives a complete corollary for exactly two consecutive
missing links when their common block is vacant and its component
crosses both sides, regardless of either neighbouring block's
vacancy status. A four-parameter analytic Barnette family has
parent/child orders 6(h+p+q)+20+4d and 6(h+p+q)+24+4d;
a second family with the first neighbour vacant has orders
6(h+p+q)+28 and 6(h+p+q)+32. Opening shapes outside the stated
tight all-square regime remain untreated. No OMEN, local graph
recomputation, publication, or push was used.

## 2026-09-30 — Complete consecutive two-port free-group branch

Note 300 closes the one-sided vacant-shared-block pattern left by
Note 292. If the right port has a vacancy to its left, that port
component surrounds the shared-block vacancy component. The interval
between its last left vacancy and the port contains exactly the other
internal missing link, so Note 288's boundary-local three-state theorem
applies. Notes 282 and 285--288 use this interval only through S/K/X
or an uninterrupted old-cycle arc; their outer port routes therefore
accept the decorated interval, even when the block after the right
port is vacant. Reflection handles the opposite side. Combined with
Note 291's short shared block and Note 299's two-sided shared vacancy,
every free group with exactly two consecutive missing ordinary links
has S/K/X under the tight, gapless, all-square, distinct target-free
vacancy and retained group-end-link hypotheses. A 44-vertex analytic
Barnette parent realizes the new nesting pattern, with a legal
48-vertex Hamiltonian child. The unrestricted Barnette conjecture
remains open; no OMEN, local graph recomputation, publication, or push
was used. Gorsky--Steiner--Wiederrecht (arXiv:2202.11641v3) and
Schnieders (arXiv:2508.03531v1) were read for the brace-reduction
and face-size boundaries, respectively.

## 2026-09-30 — Nonconsecutive two-port boundary chain

Note 301 gives explicit S/K/X routes when a first end-port component
ends at a vacant block whose following ordinary link is the second
missing link. The second end-port component starts at that link;
a port-free vacancy component surrounds both. The straight route
uses a new right covering path built from the second port's T
continuation and crossed rails. The cap joins the first and second
T continuations before following the old cycle, while the crossed
route joins them on its top path and uses both port matching edges
on its bottom path. All three distinguished components have
unbounded size, as do closed-gap lengths and nested vacancy-only
parts. An analytic Barnette family has parent/child orders
6(h+p+q)+20 and 6(h+p+q)+24; the first case is 44/48 vertices.
This handles one nonconsecutive two-defect boundary pattern under
the tight, gapless, all-square, distinct target-free vacancy and
retained group-end-link hypotheses. Other nonconsecutive patterns
and the unrestricted conjecture remain open. No OMEN, local graph
recomputation, publication, or push was used.

## 2026-09-30 — Unbounded nonconsecutive port chain

Note 302 extends Note 301 from two to arbitrarily many nonconsecutive
missing ordinary links in one free group. Each end-port component's
last vacancy is the source block of the next port; the whole chain
lies in the first gap of a surrounding vacancy-only component.
The key new route is a recursive cap R_i from e_{u_i} to b_{u_i}:
prepend the next port's outer matching edge, substitute R_{i-1}
for the source-block edge, and append that port's T continuation.
Its vertex inventory fills exactly the two vertices left by the
first-port path and all subsequent port regions. The cap and
crossed routes concatenate all T continuations and use the outer
port edges in reverse or forward order. Explicit S/K/X paths
cover all blocks and closed gaps. An analytic Barnette family
realizes every chain length k and every component-size vector,
with parent/child orders 6(h+sum p_i)+4k+12 and
6(h+sum p_i)+4k+16. The theorem is restricted to the stated
tight, gapless, all-square opening and serial port-chain order;
it does not settle arbitrary multiport groups or Barnette's
conjecture. No OMEN, local graph recomputation, publication, or
push was used.

## 2026-09-30 — Final-gap branches and cycle-traversed gaps

Checked Note 303's cap paths (7)--(11) against Notes 286, 287, and 302:
the cap adds precisely the parent's omitted e_v,b_v and all blocks of
the final gap; the parent prefix and cap meet only at e_{u-1}; the
first-port path crosses only its initial gap and otherwise uses old-cycle
edges. Its seven-edge 50-vertex example pairs every free slot, has
nested opposite-side matching chords, and has connected matching-chord
interlacement, giving a legal Hamiltonian 54-vertex child.

Note 304 proves a further cycle-traversed-gap theorem. Every proper
atom gap before an outer port component's penultimate vacancy is
invisible to the three-state construction, except the first gap of the
first port, whose crossed rails remain required. Such an inert gap may
contain arbitrarily many additional noncrossing port components without
an independent S/K/X signature, provided the stated Barnette parent and
outer interfaces exist. All three paths avoid every matching edge of
those components simultaneously. A final gap needs only an X state and its two
retained boundary links, so Note 300's two-port X motif can be composed
with these arbitrary inert gaps. An explicit nested-port family has parent and
legal-child orders 46+10d and 50+10d for every d>=1. This is an analytic
path proof and construction, not an unrestricted Barnette proof; neither
Note 303 nor 304 has had independent-source verification. Read the
proof-level boundaries in Gorsky--Steiner--Wiederrecht
(arXiv:2202.11641v3, Lemma 4.5) and Schnieders
(arXiv:2508.03531v1, Lemma 3.3 and Theorem 5.2); neither settles the
unrestricted class. No OMEN, local graph recomputation, publication, or
push was used.

## 2026-09-30 — Two-chord skeleton removes the first-gap restriction

Note 305 replaces Note 287's crossed first-port path by the old-cycle
arc a_{s+1} to I_{u_1}, followed by the fixed edge I_{u_1}e_s.
Its endpoints and vertex inventory are identical, with no matching
requirement inside the first gap. Every subsequent right continuation
needs only e_{a_i}I_{u_i}, I_{v_i}H_{u_i}, the retained link into
o_{u_i}, and a two-terminal cap covering e_{v_i},b_{v_i} plus the
final intervening blocks. Note 302's cap recurrence and S/K/X paths
therefore work without any rainbow classification or other matching
restriction on their cycle-traversed prefixes; all unlisted matching
edges within those prefixes are avoided simultaneously.

A planar cubic bipartite 3-connected realization puts d end-port
components in the first gap, with 40+10d parent and 44+10d legal-child
vertices for every d>=1. Matching-slot pairing, noncrossing chord order,
and interlacement connectivity are proved in Note 305. The result is
conditional on the displayed two chords, cap paths, outer vacancy
matching, and actual Barnette parent; it is not a general Hamiltonicity
proof. No independent-source review, OMEN, local graph recomputation,
publication, submission, or push was used.

## 2026-09-30 — Final-gap cap is a rooted crossed linkage

Note 306 turns Note 305's remaining cap interface into an exact
four-terminal condition. In a nonempty final gap, noncrossing with
I_vH_u forces the mate x of e_v into that gap. Degree two at e_v and
b_v forces every cap to use xe_v, e_vb_v, and b_va_{v+1}; deleting
these edges leaves exactly two disjoint spanning paths in the gap,
paired x--e_{u-1} and a_{v+1}--b_{u-1}. Conversely those paths
reconstruct the cap. If P_v is retained, this is the usual X state;
if missing, Note 276 forces x to be an interior vacancy slot I_t.
For a one-block gap, matching parity forbids a vacant block, and the
short-block cap is unique. For a two-block gap, matching-slot analysis
gives exactly three feasible patterns: short/short with both links,
short/vacant with the boundary port diverted to the last vacancy,
and vacant/vacant with a vacancy square and both links. The first and
third have ordinary X; an explicit twelve-vertex path caps the middle.
Thus a cap is automatic for every final gap of at most two blocks.
This closes alternative folds with the same
inventory that omit e_vb_v, but does not establish universal rooted
linkage from three-connectivity. No OMEN, local graph recomputation,
publication, submission, or push was used.

The same note now proves an unbounded one-defect cap theorem. If at
most one of P_v,...,P_{u-2} is missing, a retained P_v makes the
interior a zero- or one-defect group with X by Notes 275/288. If P_v
is the unique missing link, its end-port component has Note 286's
right continuation U; capping U with e_t,I_t,e_v,b_v and folding the
remaining all-retained suffix on crossed rails produces D. This
removes Note 305's cap hypothesis for every such final gap,
regardless of length or vacancy count. Cases with two or more
missing links remain the next mathematical boundary.

## 2026-09-30 — Backward ports and prefix shielding in rooted caps

Checked Note 307's original last-port formula edge by edge, including
the empty middle gap, its cap endpoints, matching-slot count, chord
nesting, and the face-chord interlacement bridges at every missing
link. The same argument extends the backward port from
\(P_{t-1}\) to any \(P_s\) with \(j<s<t\): after \(H_t,o_t\),
the path sweeps backward along the lower rail of
\(B_{s+1},\ldots,B_{t-1}\), crosses to \(H_j,I_j\), sweeps
back along the lower rail of \(B_{j+1},\ldots,B_s\), then
returns along the full upper rail. This spans the specified
rooted cap. The analytic Barnette realization has seven
vacant blocks and parent/child orders
\(58+4(\alpha+\beta+\gamma)\) and
\(62+4(\alpha+\beta+\gamma)\); cases with \(s<t-1\)
start at 70/74 vertices.

Note 308 proves a separate unbounded-defect theorem. With
\(I_vH_u,e_vI_t,I_hH_t,e_{u-1}o_u\) fixed and the ordinary
links from \(P_h\) through \(P_{u-2}\) retained, every matching
pattern before \(B_h\) is invisible to a rooted cap: its first
segment follows the old cycle to \(I_h\), and its remaining
segments use only the fixed chords and crossed rails. An explicit
family places \(d\) additional port components in that prefix
for every \(d\ge1\), yielding 3-connected cubic bipartite plane
parents of order \(56+14d\) and legal Hamiltonian children of
order \(60+14d\). The same cap proof only needs two spanning
\(X\) interfaces in the later intervals and their boundary links,
so internal later defects are allowed when those interfaces exist.
Noncrossing with the fixed \(I_hH_t,e_vI_t,I_vH_u\) chords
makes each later interval matching-closed after its boundary
links are retained; Note 288 then supplies \(X\) when each
interval has at most one internal missing link.
The proofs are analytic and conditional on the
stated opening and matching interfaces; neither establishes a
general two-defect cap or Barnette's conjecture. No OMEN, local
graph recomputation, publication, submission, or push was used.

## 2026-09-30 — All two-defect caps with a one-vacancy root port

Note 309 completes the next structural case. Assume the missing
boundary link \(P_v\) has exactly one vacancy \(V_t\) in its
component, with fixed edges \(e_vI_t,o_{v+1}H_t\), and at most
one further missing link \(P_s\) before the outer anchor
\(P_{u-1}\). If \(s<t-1\), the interval before \(V_t\) is
matching-closed behind \(o_{v+1}H_t\), so Note 288 supplies
its spanning \(X\) state. At \(s=t-1\), its internal links
are all retained and ordinary \(X\) works despite the
missing right boundary link. If \(s>t\), the suffix is
matching-closed between \(e_vI_t\) and \(I_vH_u\), and
Note 288 supplies its \(X\). These \(X\) states give a
single explicit cap formula. At \(s=t\), planarity puts
the second port's vacancy component entirely to the
right, where Note 303's two-component cap recurrence
applies. Thus the rooted cap exists for every second-link
position under the stated one-vacancy hypothesis. Note
307's 56/60-vertex Barnette family realizes the boundary
case with a backward port adjacent to \(B_v\). The
arbitrary multi-vacancy root-port case, other opening
shapes, and Barnette's conjecture remain open. No OMEN,
local graph recomputation, publication, submission, or
push was used.

## 2026-09-30 — A boundary port plus any one further missing link has a cap

Note 310 removes Note 309's one-vacancy restriction. For an end
port \(P_v<V_{r_1}<\cdots<V_h<V_t\) in the final gap,
Note 286's right continuation truncated at \(V_h\) spans the
prefix except \(I_h,e_h\) without using the component's
outer edge. When the further missing link is \(P_{t-1}\),
an upper-then-lower fold through \(B_{h+1},\ldots,B_{t-1}\)
returns to \(e_h,I_h,H_t\) and avoids \(P_{t-1}\)
altogether, regardless of its matching component. A defect
before \(h\) is shielded by Note 308; one strictly inside
\((h,t)\) gives an \(X\) state by Note 288; defects at
\(h\) or \(t\) become Note 303 side chains; one after
\(t\) gives the suffix \(X\) state by Note 288. Note
309 covers the one-vacancy root component. These cases prove
that every actual Barnette parent with the stated opening,
outer anchors, missing \(P_v\), and at most one other missing
ordinary link before \(P_{u-1}\) has the exact cap required
by Note 305. This remains a conditional theorem for the
tight, gapless, all-square opening and does not decide
Barnette's conjecture. No OMEN, local graph recomputation,
publication, submission, or push was used.

## 2026-09-30 — Serial composition of two-defect rooted caps

Note 311 applies Note 310 independently in each region of Note 305's serial
two-chord skeleton. A realized \(k\)-region family has one boundary port and
one backward port per region, plus the serial source port: its \(3k\) missing
ordinary links coexist with spanning \(S,K,X\) states. The explicit matching
has \(5k+2\) vacant blocks and \(8k+2\) special edges, producing Barnette
parents of order \(42k+24\) and legal Hamiltonian children of order
\(42k+28\). The first member agrees edge for edge with Note 307's 66/70
example. The proof now records the shared-block slot partition, nesting of
different regions, the precise matching chord behind every missing-link
interlacement bridge, and the unchanged end chain. This is a conditional
unbounded family in the compact all-square opening; it gives neither a
counterexample nor a general proof of Barnette's conjecture. No OMEN, local
graph recomputation, publication, submission, or push was used.

## 2026-09-30 — Short corridors reduce separated ports to consecutive ports

Note 312 identifies the induced ladder on \(d=t-s\) short blocks between two
missing ordinary links. Its four attachments are the two old-cycle edges at
the corridor ends and the two diverted matching edges at the port slots.
Note 178's exact four-terminal signature preserves each \(S,K,X\) route
under compression to one short block, and its Barnette reduction preserves
the site opening. The compressed ports are consecutive, so Note 291 supplies
all three states. More generally, \(m\) corridor vacancies leave at most
\(2m+1\) blocks after all short runs are compressed, without changing the
three-state signature. Reversing the reduction on Note 291's 46/50-vertex example
realizes every \(d\ge1\) with parent/child orders \(46+4(d-1)\) and
\(50+4(d-1)\). This settles separated ports only when every intervening
block is short; a vacancy inside the corridor is still outside the proof.
No OMEN, local graph recomputation, publication, submission, or push was used.

## 2026-09-30 — Six-port square buffers preserve routes and make a new one-vacancy family

Note 313 proves a one-way six-terminal linkage theorem. Attaching a short
square to the left or right of a vacant six-cycle preserves every spanning
path pairing: the four cases are both boundary terminals used, either one
used, or neither used; the last case replaces their forced edge by a
spanning square detour. The reverse fails: one left buffer has a three-path
pairing \((A,O),(I,e),(H,b)\) absent from the six-cycle. A two-edge-cut
projection proves that, when the two moved exterior edges share the local
face, buffering preserves the Barnette class. Conversely, when a buffer
can be removed to a simple plane bipartite Hamiltonian cubic graph, any
new two-edge cut must contain the old \(ao\) edge; equivalently one
old-cycle interval bounded there is matching-closed. The vacant block's
face chord and the inner slots' external matching edges exclude that
interval, so alias-free reversal also preserves the class. This transfers all of Note
300's consecutive two-port vacant-shared-block class to arbitrary left and
right short buffers. Applied to its 44/48-vertex example, it gives a
\(44+4(d_L+d_R)\)/\(48+4(d_L+d_R)\) family. Its two missing links
enclose \(d_L\) short blocks, one vacancy, and \(d_R\) short blocks;
the vacancy may occupy either end or any interior position.
The family has \(S,K,X\) and marked parent/child Hamilton cycles by route
lifting. This supplies an actual one-vacancy corridor class. No OMEN, local graph
recomputation, publication, submission, or push was used.

## 2026-09-30 — A port-free central vacancy settles a two-defect corridor class

Note 314 applies Note 312 to compress a corridor with exactly one vacancy
to at most three blocks. The reduced atom order is \(P_s<V<P_t\); Note 278's
rainbow rule identifies the only possible inverse-buffer alias: it occurs
on the left exactly when \(V\) belongs to the left port component, and on
the right exactly when \(V\) belongs to the right port component. The
components are distinct, so a port-free \(V\) has neither alias. The
strengthened reverse-cut argument in Note 313 shows each inverse then
remains Barnette. Removing at most two adjacent short blocks reaches Note
300's consecutive two-port class, which has \(S,K,X\). Six-port lifting
and the exact short-run replacement restore these states in the original
graph. Thus every actual group in this opening with two missing links,
one corridor vacancy, and that vacancy in a port-free component has all
three states. An absent state would force the central vacancy into one
of the two port components; no Hamilton conclusion is drawn for those
remaining ownership cases. No OMEN, local graph recomputation,
publication, submission, or push was used.

## 2026-09-30 — Port-owned corridor vacancies reduce by the known cube expansion

Note 315 closes the two ownership cases left by Note 314. After short-run
compression, ownership by the left port forces its matching edge to the
central vacancy through the left short block, while the block's other
ordinary link is retained. The resulting ten-vertex patch is a cube
expansion of one vertex of a short square: its seven-vertex core has the
explicit cube-minus-one-vertex labeling in Note 315. Four spanning
one-path terminal pairs and two spanning two-path pairings match those
of the square exactly. A terminal-preserving minor and a direct
two-vertex-deletion argument preserve planarity and three-connectivity
on contraction. The right short block, if present, first undergoes
the alias-free reverse buffering of Note 314. The folded graph has at
most two missing links; if two remain, they are consecutive around the
new short square. Notes 288/291 supply all three states, which lift back
through the cube patch, any right buffer, and the compressed short runs.
Reflection handles right ownership. Together with Note 314 this proves
the full one-vacancy, two-separated-port corridor theorem under the
specified compact all-square opening. Gorsky--Steiner--Wiederrecht
(2023, Section 5) identifies the cube expansion with the
Holton--Manvel--McKay (1985) operation; Schnieders (2025, Section 3)
provides a separate substitution framework. The local cube operation
is not claimed as new, and the corridor theorem has not had an
independent external proof review. Barnette's general conjecture
remains open. No OMEN, local graph recomputation, publication,
submission, or push was used.

## 2026-09-30 — Two-ended cube peels cover unbounded multi-vacancy corridors

Note 316 records a sufficient theorem for a two-port corridor with an
arbitrary number of distinct target-free vacant blocks. Label a corridor
vacancy L or R when it belongs to the corresponding port's rainbow
component, and F otherwise. If at most one corridor vacancy is F,
noncrossing forces the ownership word L^p F^epsilon R^q: an R before
an L interlaces the two port components, while a sole F before an L
or after an R interlaces a port component with its own second atom
outside the corridor. Compress the short run before the first L to
one square and use Note 315's cube reduction. The reduced left port is
either repaired, giving Note 288's one-defect theorem, or remains a
port in the same component with the first L atom removed. The other
components and ownership letters are unchanged. Induction peels the
L prefix; reflection peels the R suffix. The remaining zero or one
vacancy is covered by Notes 312/315. Exact four-pole signatures lift
S,K,X at each reversal. Repeated inverse cube expansions at the shared
short block of Note 291's 46/50-vertex example give actual Barnette
parents/children of orders 46+6p and 50+6p with corridor word L^p,
so the unbounded condition is nonvacuous. The proof remains conditional
on the compact all-square opening and the stated ownership word; it
does not address several port-free corridor vacancies. No OMEN,
local graph recomputation, publication,
submission, or push was used.

## 2026-09-30 — Closed vacancy intervals compress exactly to a square

Note 317 recognizes that the vacancy-only S,K,X construction of Note
275 already gives the entire four-terminal Hamilton linkage signature.
The old local spine supplies the a--b spanning path, S gives o--e,
and adding the two boundary spine edges to X makes an internal
Hamilton cycle; deleting either boundary edge gives the remaining
a--o and e--b spanning paths. K and X give both noncrossing two-path
pairings, and planarity excludes the interlacing third pairing.
Thus any induced disk chain of short/vacant face-chord blocks with
retained internal ordinary links, internally matched vacancies, and
exactly four exterior attachments has the square signature. The
replacement square is planar and bipartite in the same terminal order.
The four-attachment exterior is connected by three-edge-connectivity,
and the two-vertex-deletion argument used in Note 315 gives
three-connectivity after replacement. Hence Hamilton decisions and
all exterior attachment choices transfer both ways, even if the
original Barnette graph is not Hamiltonian. A vertex-minimal
non-Hamiltonian Barnette graph cannot contain a strictly larger such
patch. In the compact all-square opening, this compresses any
two-port corridor whose vacancy matching is closed internally,
regardless of vacancy count or nesting, to Note 291's shared short
square and yields S,K,X. Corridors with vacancy components crossing
their boundary remain outside this reduction. Together with Note 316,
failure of any three-state signature in a two-port corridor requires
at least two port-free corridor vacancies and a vacancy matching edge
across the corridor boundary. This necessary shape is not a
non-Hamiltonian example. No OMEN, local graph
recomputation, publication, submission, or push was used.

## 2026-09-30 — Exact reductions settle every target-free internal group

Note 318 first removes port-owned corridor vacancies in a two-defect group:
noncrossing closes every intervening port-free component, Note 317 compresses
that block interval to a square, and Note 315 folds the adjacent owned
vacancy. Note 319 then identifies the general induction, with no bound on
the number of missing links. Choose a port-containing rainbow component
of minimum first-to-last atom span. It has exactly one port by Note 278.
Between that port and a neighboring vacancy of the same component, any
other atom component is wholly contained in the gap; minimum span excludes
another port there. The intervening block interval is nonempty, since an
adjacent owned vacancy would force a matching edge already on the old cycle.
Its internal ordinary links are retained and all vacancy matching closes
inside it. Compress by Note 317 and fold by Note 315. The fold repairs the
port or deletes one of its owned vacancies without changing other port
components. Every step removes at least one vacancy, so eventually no port
remains. Note 275 gives S,K,X in the final vacancy-only group, and the exact
four-pole signatures lift all three states to the original group, including
when a patch touches a group end block. This covers arbitrarily many
missing links, vacancies, and nested matching components within the selected
target-free internal group. The same proof gives an intrinsic four-pole
reduction in any Barnette graph containing an induced short/vacant block
chain with four exterior edges and the stated local noncrossing matching:
port separation follows from a forbidden two-edge cut, so the patch has
the complete square Hamilton linkage signature without assuming a global
Hamilton cycle. A vertex-minimal non-Hamiltonian Barnette graph excludes
every strictly larger such patch. Its weakest dependencies are the exact
Barnette-preserving reductions of Notes 315 and 317; the new argument has
not had an independent external proof review. The selected opening still
excludes target-bearing or repeated vacancies, positive gaps, defective
target order, and nonsquare residual cycles, so the general Barnette
conjecture remains unresolved. No OMEN, local graph recomputation,
publication, submission, or push was used.

## 2026-09-30 — One-sided target-bearing vacancy has one terminal component

Note 320 tests the first block type outside Note 319. A single vacancy
immediately before an occupied target run leaves a terminal free-slot
fragment \(o_k,h_k,i_k\), so the complete-block square reduction cannot
fold that vacancy. Note 215's even-prefix barrier closes the preceding
group. The parity-and-two-edge-cut argument of Note 276 still excludes
same-block ordinary chords and nonstandard ordinary-to-ordinary chords:
the terminal block has no second free ordinary slot that could balance a
same-block chord. The free matching therefore yields a noncrossing atom
partition with at most one missing-link port per component.

The terminal vacancy is the rightmost atom \(T\). Choose a minimum-span
port component other than its component; a port-to-neighbor-vacancy gap
contains only closed port-free components, so Notes 317 and 315 compress
and fold it. Repetition eliminates all such ports. If the terminal
component has a port, fold its remaining target-free vacancy atoms in
the same way. The terminal core is either port-free or exactly
\(\{P_s,T\}\), with matching edges \(e_si_k,o_{s+1}h_k\). In the latter
case all other vacancy-only intervals compress to squares, leaving
Note 208's explicit detour \(e_s,i_k,h_k,o_{s+1}\). With compatible
routes in other groups, this gives the marked parent Hamilton cycle and
legal Hamilton child. The port-free terminal core is the next exact
interface; no Hamilton assertion is recorded for it. The argument is
analytic and awaits independent external proof review. No OMEN, local
graph recomputation, publication, submission, or push was used.

## 2026-09-30 — Standard-link sweep closes the one-sided target-vacancy branch

Note 321 removes Note 320's remaining port-free terminal core. The
same-square sweep of Note 231 only needs retained ordinary links: for each
consecutive target pair R_j,L_j, traverse every intervening free slot in
old-cycle order, crossing face-block boundaries through e_i o_{i+1}.
The disjoint face-chord path covers all block endpoints, and the residual
square transitions join the target intervals into the other spanning path.
Thus, in a tight gapless all-square opening, all standard links retained
imply a marked Hamilton parent cycle for arbitrary vacancy count and
placement, regardless of the matching among vacancy slots.

With a unique one-sided target-bearing vacancy T and all other vacancies
in distinct target-free internal blocks, Note 320 normalizes T's group.
The minimum-span fold also removes ports from every other target-free group,
even when its ordinary end slots lie in target-bearing boundary blocks,
because each actual replacement patch consists entirely of complete
target-free blocks. If T's component is port-free, all standard links are
then retained and the sweep applies. If the component is {P_s,T}, every
other vacancy component is closed in a complete target-free interval.
Compress these intervals by Note 317. The reduced tight opening has one
vacancy and matching e_s i_k, o_{s+1} h_k, exactly Note 208's first-surplus
one-sided case. Its marked Hamilton cycle lifts through all exact reductions.
This completes the specified unique one-sided target-bearing class at
arbitrary surplus and leaves multiple target-bearing or repeated same-block
vacancies, positive gaps, defective target order and nonsquare residual
cycles outside. The new proof has not had independent external review. No
OMEN, local graph recomputation, publication, submission, or push was used.

## 2026-09-30 — Facing target vacancies reduce to one mixed terminal core

Note 322 extends Note 232's facing two-target-vacancy group by allowing
arbitrarily many additional target-free vacancies in distinct complete
blocks. The target barriers close the group; Note 276's parity argument
still excludes same-block ordinary chords, including an endpoint at either
three-slot target-bearing fragment. Nonstandard ordinary chords would
close a complete target-free block interval into a two-edge cut. Thus the
vacancies and missing links form a noncrossing atom partition with at most
one port per component.

A minimum-span port component containing neither special terminal atom
has a port-to-owned-vacancy gap consisting only of closed target-free
components. Notes 317 and 315 compress and fold it. The two terminal
atoms are the global first and last atoms, so if their components differ,
those spans are disjoint; port components containing a terminal can then
lose all of their other target-free vacancy atoms by the same fold. The
reduced group has four alternatives: no port; one component {L,P,R};
two components {L,P_a} and {P_b,R}; or two components with a port at
exactly one end and a port-free component at the other. The first uses
Note 321's standard-link sweep. In the middle two, every other vacancy
interval compresses by Note 317, yielding Note 232's exact one- and
two-detour bases. Hence those three alternatives are marked Hamiltonian.
The last alternative necessarily contains at least one additional
vacancy in the port-free terminal component and is the next exact
interface, not a non-Hamilton example. The reduction and three sufficient
cases have a complete project proof but no independent external review.
No OMEN, local graph recomputation, publication, submission, or push was used.

## 2026-09-30 — Terminal-port U-turn closes facing target vacancies

Note 323 resolves Note 322's fourth terminal outcome. In the reduced
mixed group, reflect so the sole missing link is
\(P_s=e_so_{s+1}\) in the left terminal component. Its matching
edges are \(i_Le_s,h_Lo_{s+1}\), and every other ordinary link is
retained. The complete target-free block interval
\(D=B_{k+1},\ldots,B_s\) has an explicit spanning
\(e_s\)--\(b_s\) path: traverse every free interior backward using
retained links, then traverse the face chords forward. Insert this
path after \(b_L,e_L,i_L\) in the exposed-face route. The residual
square route instead goes from the preceding target through
\(h_L,o_{s+1}\) and follows the ordinary old-cycle sweep to the next
target. These disjoint routes cover all vertices, irrespective of
the matching inside the right port-free component.

Together with Note 322's other three outcomes, this proves marked
Hamiltonicity for two facing target-bearing vacancies with any
number of distinct-block target-free vacancies between them in the
specified all-square, gapless, tight opening, and Hamiltonicity of
the legal site-expanded child. The route is analytic and has not had
independent external review. Gorsky--Steiner--Wiederrecht 2023,
Section 5, was checked for the previously used cube reduction; that
operation remains credited to Holton--Manvel--McKay. The general
Barnette conjecture remains open. No OMEN, local graph recomputation,
publication, submission, or push was used.

## 2026-09-30 — All distinct internal vacancies compose across target barriers

Note 324 combines the local results of Notes 319, 321, and 323. The
occupied target runs partition the free matching into groups because
each earlier vacancy adds two free slots and at most one same-block
free chord could cross a run. A vacancy with occupied targets on both
sides would isolate its adjacent pair, impossible for the complementary
matching. Thus each group has zero, one, or two target-bearing terminal
vacancies, with all remaining vacancies in distinct complete
target-free blocks. The reductions and spanning routes of the three
notes are internal to their groups and retain their boundary
attachments. Apply them to all groups and splice the disjoint
modifications into Note 231's two spanning paths. This gives a marked
Hamilton parent cycle and a Hamilton legal site-expanded child for
an arbitrary number of vacancies in distinct internal face blocks,
under the selected all-square, gapless, tight-target opening.

The argument is analytic and awaits independent external review. It
does not resolve repeated same-block vacancies, site-block vacancies,
positive gaps, defective target order, nonsquare residual cycles, or
the general Barnette conjecture. No OMEN, local graph recomputation,
publication, submission, or push was used.

## 2026-09-30 — Even rainbow multivacancy blocks are exact square reductions

Note 325 identifies a target-free internal block with an even number
q=2m of vacancies and a full nested internal matching. Its old-cycle
perimeter, face chord, and q internal free matching chords form the
even-column ladder L_(q+2). Exactly four edges leave, at the two face
endpoints and the two central free slots i_m,h_(m+1). Note 178's exact
four-terminal ladder reduction replaces it by a short square, preserving
Barnette membership, the selected opening, and all exterior Hamilton
routes. The old Hamilton cycle maps to the square path through its four
vertices, and the face chord keeps its side. Compress any number of
these disjoint blocks; the remaining distinct-block vacancies fall
under Note 324. Reversing the reductions gives a marked Hamilton
parent cycle and a Hamilton legal site-expanded child. The family is
nonvacuous for every even q by expanding Note 224's L4 instance.

This result recognizes a known exact ladder operation inside a new
vacancy profile; it does not establish a new graph operation. Odd
multiplicity and other internal chord patterns remain unresolved. The
proof is analytic, has not had independent external review, and used
no OMEN, local graph recomputation, publication, submission, or push.

## 2026-09-30 — Odd ladders reduce to one vacant block

Note 326 proves the odd-column analogue of Note 178: for every odd
N>=3, L_N and L_3 have the same four spanning one-path corner pairs
and the same two spanning two-path pairings. The exact four-terminal
replacement preserves exterior Hamilton routes, planarity, bipartite
terminal colours, and three-connectivity. A target-free block with
q=2m+1>=3 vacancies and the specified complete rainbow matching is
precisely L_(q+2); compression leaves one vacant block with the
internal complementary chord oe.

If all other multiply vacant blocks are also rainbow ladders, first
compress every such block. The resulting Barnette opening has all
vacancies in distinct internal blocks yet retains oe in a target-free
singly vacant block. Notes 276, 320, and 322 exclude that chord in
every target-free group with zero, one, or two target-bearing
terminals. Thus an odd rainbow block under those global hypotheses
cannot occur. It remains possible for this argument that an odd
rainbow block coexists with a nonrainbow repeated block. This is an
analytic structural exclusion, not a Barnette proof. No OMEN, local
graph recomputation, publication, submission, or push was used.

The dependency check found a gap in Notes 276, 320, and 322: a block
interval between two oe-chord blocks linked by one vacancy matching
edge need not be matching-closed. The proofs now use the finite set of
all oe-chord blocks. Parity makes the h-to-i mate map a permutation of
that set; a noncrossing component's first-to-last span has an outer
chord that traps every matching edge, giving the required two-edge
cut. The notes' theorem statements and hypotheses are unchanged.
