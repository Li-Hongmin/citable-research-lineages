# The planar boundary-chord statement is false

The planar restriction in `TASK.md` is false.  A counterexample already
occurs in the frozen 16-vertex plane cubic bipartite brace with graph6 string

    O????B_sDOI_I_DO@W?M?

## The plane brace and fixed fibre

Let (F) have bipartition

\[
Y=\{0,1,2,3,4,5,6,7\},\qquad
X=\{8,9,10,11,12,13,14,15\}.
\]

It has the following plane embedding, given by its eight quadrilateral and
two octagonal facial boundaries:

\[
\begin{gathered}
(0,8,2,10),(0,9,1,8),(1,9,3,11),(2,12,4,10),\\
(3,13,5,11),(4,12,6,14),(5,13,7,15),(6,15,7,14),\\
(0,10,4,14,7,13,3,9),
(1,11,5,15,6,12,2,8).
\end{gathered}
\tag{1}
\]

Every directed edge occurs exactly once in (1).  The graph is simple,
connected, cubic and bipartite.  On both colour sides, exhaustive strict-Hall
minimization gives

\[
\min_{\varnothing\ne U,\ |U|\le6}(|N(U)|-|U|)=2,
\tag{2}
\]

so the bipartite 2-extendability criterion makes (F) a brace.

Take root (r=0), ports (N(r)=\{8,9,10\}), and fixed port split

\[
\{8\}\mid\{9,10\}.
\tag{3}
\]

In this fibre, consider the five spanning two-component forests

\[
\begin{aligned}
A=\{&(1,9),(1,11),(2,8),(3,11),(3,13),(4,10),(4,12),
      (4,14),(5,13),(5,15),(6,12),(6,15),(7,14)\},\\
B=\{&(1,8),(2,10),(2,12),(3,9),(3,11),(3,13),(4,14),
      (5,11),(5,15),(6,12),(6,15),(7,13),(7,14)\},\\
C=\{&(1,9),(1,11),(2,8),(3,13),(4,10),(4,12),(5,11),
      (5,13),(5,15),(6,12),(6,14),(7,14),(7,15)\},\\
D=\{&(1,9),(1,11),(2,8),(3,11),(3,13),(4,10),(4,12),
      (4,14),(5,15),(6,12),(7,13),(7,14),(7,15)\},\\
E=\{&(1,9),(1,11),(2,8),(3,11),(3,13),(4,10),(4,12),
      (5,15),(6,12),(6,14),(6,15),(7,13),(7,14)\}.
\end{aligned}
\tag{4}
\]

Direct component checks put every forest in the split (3).

## Minimal box feasibility and absence of a compatible pair

In coordinate order (Y\setminus\{r\}=(1,2,3,4,5,6,7)), their degree and
excess vectors are

\[
\begin{array}{c|c|c}
 &d&e=d-2\mathbf1\\ \hline
A&(2,1,2,3,2,2,1)&(0,-1,0,1,0,0,-1)\\
B&(1,2,3,1,2,2,2)&(-1,0,1,-1,0,0,0)\\
C&(2,1,1,2,3,2,2)&(0,-1,-1,0,1,0,0)\\
D&(2,1,2,3,1,1,3)&(0,-1,0,1,-1,-1,1)\\
E&(2,1,2,2,1,3,2)&(0,-1,0,0,-1,1,0).
\end{array}
\tag{5}
\]

The positive weights

\[
(w_A,w_B,w_C,w_D,w_E)=\frac17(1,2,2,1,1)
\tag{6}
\]

give

\[
\sum_J w_J e(J)=\frac17(-2,-5,0,0,0,0,0)\le0.
\tag{7}
\]

The support is inclusion-minimal.  For omission of (A,B,C,D,E),
respectively, use the nonnegative separating vectors

\[
\begin{array}{c|c}
\text{omitted state}&\lambda\\ \hline
A&(0,0,1,0,2,3,6)\\
B&(0,0,0,4,1,2,0)\\
C&(0,0,5,3,0,2,1)\\
D&(0,0,2,1,3,4,0)\\
E&(0,0,5,4,6,0,3).
\end{array}
\tag{8}
\]

For each row of (8), (lambda\cdot e(J)>0) for every remaining state
(J).  Hence the convex hull of any proper subfamily misses the nonpositive
box.

The support has no compatible pair, allowing repetition.  The following
symmetric matrix gives, for each pair, one coordinate at which the excess
sum is positive:

\[
\begin{array}{c|ccccc}
 &A&B&C&D&E\\ \hline
A&4&3&4&4&4\\
B&3&3&5&3&3\\
C&4&5&5&4&6\\
D&4&3&4&4&4\\
E&4&3&6&4&6
\end{array}
\tag{9}
\]

## Exact fundamental-cut obstruction

For a same-(X) pivot (J'=J-xz+xy),

\[
e(J')=e(J)-\mathbf1_z+\mathbf1_y.
\tag{10}
\]

Thus a pivot can repair an ordered pair ((J,K)) only if (e(J)+e(K))
has exactly one positive coordinate, equal to one, and the receiving
coordinate has negative slack.  Applying (10) to all 25 ordered pairs in
(5), then using the actual incidence of (F), leaves exactly the following
six edge transfers:

\[
\begin{array}{c|c|c}
\text{source, partner}&\text{only possible transfer}&\text{failure}\\ \hline
A,B&A-(3,13)+(7,13)&\text{not a two-component forest}\\
B,A&B-(3,9)+(1,9)&\{10\}\mid\{8,9\}\\
B,A&B-(3,11)+(1,11)&\{9\}\mid\{8,10\}\\
B,C&B-(5,11)+(1,11)&\{10\}\mid\{8,9\}\\
C,E&C-(6,12)+(2,12)&\{9\}\mid\{8,10\}\\
E,C&E-(6,12)+(2,12)&\{9\}\mid\{8,10\}.
\end{array}
\tag{11}
\]

The last five candidates remain two-component forests but cross the fixed
terminal partition (3).  Therefore no candidate belongs to the fixed fibre.
Equation (10) proves that (11) exhausts every pivot that could become
compatible with a support state.  This is a genuine planar realization of
the Heawood fundamental-cut port barrier.

For an independent finite check, the complete fixed fibre has 86 forests.
Its same-(X) pivot graph is connected with 217 edges; the five support
states have pivot degrees ((5,5,5,6,5)), and exhaustive inspection of all
26 incident pivots finds zero compatible boundary hits.

Exact reproduction:

    python3 units/barnette/scratch/barnette_planar_boundary_chord/verify_planar_boundary_chord_counterexample.py

Terminal marker:

    PLANAR_BOUNDARY_CHORD_COUNTEREXAMPLE_VERIFIED

## Boundary of the conclusion

The exact conclusion is existential and refutes the universal planar
statement: there exists a simple plane cubic bipartite brace, a fixed
singleton|paired fibre, and an inclusion-minimal box-feasible support with
no compatible pair and no compatible same-(X) boundary chord.

The weakest load-bearing argument is the six-candidate classification
(10)--(11); the 86-state enumeration is corroboration, not the conceptual
reason.  The evidence level is an explicit finite mathematical
counterexample with rational Farkas certificates, an explicit plane
embedding, and a standalone exact verifier.

This does **not** refute support two.  The same complete fibre contains
support-one forests, for example one with degree vector
((2,2,2,2,2,1,2)).  What remains open is whether every planar fixed fibre
has a support-one or support-two box certificate, or whether a different
global extremality rule or a multistep pivot route always finds one.
