# Single leaf task: planar boundary-chord

Work only in the Barnette unit:

    [local archival reference]

Read README.md and Notes 056, 059, and 061. Do not modify permanent notes or
papers. Put exploration only under this scratch directory.

Note 061 gives a nonplanar Heawood-brace counterexample to the general
boundary-chord lemma. Determine the following single planar restriction:

> In an actual fixed fibre of a simple plane cubic bipartite brace, does every
> inclusion-minimal box-feasible support with no compatible pair have a
> same-\(X\) pivot from one support state to a forest compatible with some
> support state?

Use the cheapest decisive observation: either adapt the two Heawood
fundamental-cut port barriers to a genuine plane brace, or prove that Jordan
separation/brace extendability forbids them. A small exact search is allowed
only to produce a real counterexample or a sharp structural reduction; do not
turn this into an unbounded census.

Stop at proof, genuine plane-brace counterexample, strict topological
reduction, or a bounded route closure. End with: exact conclusion and
quantifiers; weakest load-bearing argument; evidence level; unresolved
boundary.
