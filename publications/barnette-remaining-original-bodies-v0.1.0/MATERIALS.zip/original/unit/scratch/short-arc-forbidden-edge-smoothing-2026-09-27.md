# 短弧接口：Pro 核验、禁边平滑与尚缺的共同选择

2026-09-27。仅处理短弧必保边 (e=vx)。本稿是新的 scratch 推导，不修改冻结 SPEC、既有 scratch 或永久 notes。

**裁决。** Pro 的四圈对边 (f=zw) 证明及四端口状态归约成立。一般 S9 仍未解决，没有真实反例。本轮新增了一个结构归约：(Y=G-\{v,x\}-f) 的桥只能是挂着 (z,w) 的叶边；平滑禁边 (f) 的两端，得到一个简单平面三价图 (L)，且 (L-\{v,x\}) 连通无桥。指定弦定理在 (L) 上确实能产生根分离二因子；还原到原图的准确条件是同时使用两条平滑边。若 (f) 接触 (z) 或 (w)，这个条件自动成立，从而该子域的初始 (p,q) 分圈已经得到证明，但恰两圈仍未证明。远离 (z,w) 时，初始分圈也仍有共同选择缺口。

本轮改变的判断是：能否从已知四端口状态中严格排除结构性分离障碍，并保证一个含 (e,f) 的分圈匹配。最便宜的直接观测是桥割的端口计数及两条平滑边的原色度数恒等式；没有扩大图阶搜索。

## 1. 对象与 Pro 结论的独立核验

沿用冻结 [SPEC](../SPEC-2026-09-12-upgrade.md) 的真实 cube 合法历史域。父图 (G) 简单、三连通、三价、二分、平面，并具有全局 (H^{+-})。取同一面边界连续三边

\[
p=uv,\qquad e=vx,\qquad q=xy.
\]

记 (z,w) 分别为 (v,x) 的第三邻点，(\alpha=vz,\beta=xw)。可选二分颜色使 (u,z,x) 同色，(v,w,y) 同色。四点 (u,z,w,y) 互异。令

\[
X=G-\{v,x\},\qquad Y=X-f.
\tag{1}
\]

前件为

\[
\varnothing\ne J_G(e,f),\qquad
\forall C\in J_G(e,f):p,q\notin C.
\tag{2}
\]

任取 (C\in J_G(e,f))，其补匹配含 (p,q,f)，故 (f) 不接触四个 site 端口。若 (uy\in E(G))，则 (C-uy) 已给出目标，以下只处理 (uy\notin E(G))。这里与 [上一份 S1–S9](pro-E-independent-verdict.md) 的符号对应为 (r=z,s=w)。

### 1.1 双射与严格空状态

目标是 (G-p-q) 中含 (e)、避 (f) 的 spanning (u-y) path (P)。删去 (e) 后，四端口的同面次序排除交叉配对 (ux\mid vy)，故余下两条路径配成 (uv\mid xy)。于是

\[
F=(P-e)+p+q
\]

恰为两个圈，各含一个 seal。反向从两个分圈分别删去 (p,q)，再加 (e)，恢复同一条 (P)。因此有完整双射

\[
\{P\}\longleftrightarrow
\{N\in\operatorname{PM}(G):e,f\in N,\ c(G-N)=2,
\ p,q\text{ 分圈}\}.
\tag{3}
\]

含边 (vx) 的简单 (v-x) path 只能就是该单边；配成 (uv\mid xy) 的两条不交路径也不能含连接两个分量的 (vx)。所以原三见证析取的另外两类确实为空。

删除 (vx) 的小正则邻域，外接端口循环次序为 (u,z,w,y)，或其反向。非交叉论证发生在这个圆盘的外部，不要求 (X) 的外面边界简单。

令 (P_{ab}(W)) 表示 spanning (a-b) paths，(D_{ab\mid cd}(W)) 表示恰两条不交 spanning paths，配成 (ab\mid cd)，不允许其他闭分量。直接恢复经过 (v,x) 的路径，得到

\[
\begin{gathered}
P_{zw}(Y)\ne\varnothing,\qquad D_{uy\mid zw}(Y)\ne\varnothing,\\
P_{uy}(Y)=P_{uw}(Y)=P_{zy}(Y)=\varnothing.
\end{gathered}
\tag{4}
\]

第一项由 (J_G(e,f)) 删除段 (z-v-x-w) 得到。第二项由 (H_G^{+-}(p,f)) 得到：这个父圈避 (e)，在 (v,x) 处使用 (p,\alpha,q,\beta)；删除这两点后，(uz\mid wy) 会在恢复时形成两圈，(uw\mid zy) 交叉，故只能是 (uy\mid zw)。三个空状态分别补回 (u-v-x-y)、(u-v-x-w)、(z-v-x-y)，即违反 (2)。

另一方面，(H_G^{+-}(p,\beta),H_G^{+-}(p,q),H_G^{+-}(q,p)) 分别给出 (P_{uy}(X),P_{uw}(X),P_{zy}(X)) 的非空性；各族的每个成员都含 (f)。这三次调用没有合并成一个见证。

所有避 (f) 的父 Hamilton 圈都含 (\alpha,\beta)，且 (p,q) 同取、与 (e) 的取值相反。因此更有完整父圈族分解

\[
\{C\in\mathcal H(G):f\notin C\}
\longleftrightarrow
P_{zw}(Y)\ \dot\cup\ D_{uy\mid zw}(Y).
\tag{5}
\]

目标则精确等价于

\[
D_{uz\mid wy}(Y)\ne\varnothing.
\tag{6}
\]

目标路径必须经过 (z-v-x-w)，删除内部两点后只可能采用 (6) 的配对；反向补回这一段即可。令带新边标签的

\[
T=X+g+h,\qquad g=zw,\quad h=uy.
\]

则 (6) 等价于 (T) 中有含 (g,h)、避 (f) 的 Hamilton 圈。若含 (h)、避 (g,f) 的 Hamilton 圈存在，将 (h) 展开成 (u-v-x-y) 就违反 (2)。故仍有

\[
(6)\iff J_T(h,f)\ne\varnothing.
\tag{7}
\]

(T) 的阶数是 (n-2)，可能有平行边；新 (g) 即使与旧 (f) 端点相同也不合并。此处没有调用原历史类归纳。

### 1.2 四圈对边子情形的完整证明

设 (f=zw)。四圈 (v-x-w-z-v) 必为面边界：若两侧都有圈外顶点，三边连通性要求每侧至少三条外接边，但四个三价点一共只有四条；空侧也不可能有二分图对角线。

取 (C_D\in H_G^{+-}(p,\beta))。度数强制 (p,e,q\in C_D)，(\alpha,\beta\notin C_D)，继而在 (z,w) 处强制 (f\in C_D)。删除 (e,f) 后有两条覆盖全部顶点的路径。配对 (vx\mid wz) 与原圈连通性矛盾；配对 (vw\mid xz) 在该四边形面的外部交叉；所以实际配对是 (vz\mid xw)。

令 (M_D=E(G)\setminus C_D)。翻转得到

\[
N=(M_D-\{\alpha,\beta\})\cup\{e,f\}.
\tag{8}
\]

这是一个完美匹配；补图由上述两条路径分别加回 (\alpha,\beta) 组成，恰两圈，分别含 (p,q)。由 (3) 得到目标。这个证明甚至不需要困难前件 (2)，但需要所述全局有序边要求。Pro 的子情形证明接受。

## 2. 新结构引理：(X-f) 除端口叶边外无桥

这里实质使用真实历史提供的严格 Hall 余量，不能以一般平面四极替代 (X)。先重推这项输入。

若父图每侧有 (t) 点，则 cube 具有

\[
|N(A)|\ge |A|+2\quad
(\varnothing\ne A\subseteq V_0,\ |A|\le t-2).
\tag{9}
\]

在一次四点扩张中，设新 (V_0) 点为 (b,d)，新另一侧点为 (a,c)。对新图的集合 (S)，写 (A=S\cap V_0)、(j=|S\cap\{b,d\}|)，只需检查 (1\le|S|\le t)。

* (j=0)：删除 seals 造成的邻点损失分别由 (a,c) 补足。若 (|A|\le t-2)，用 (9)。若 (|A|=t-1,t)，三价性保证旧对侧全部 (t) 点仍有邻点，另至少增加一、二个新邻点。
* (j=1)：出现 (a,c) 并恢复一个旧 seal 端点，旧邻点至多损失一个。因此普通范围内邻域至少 (|A|+3)；(|A|=t-1) 时旧对侧全部仍在，再加两新点；(A=\varnothing) 时直接用新点度数三。
* (j=2)：两旧 seal 端点全部恢复，另加 (a,c)，非空 (A) 时至少 (|A|+4)；空集时有四个不同邻点。

于是 (9) 沿全部合法历史保持；交换两色后同样成立。固定任意两条独立边、删除各侧两个端点，Hall 所需的不等式由 (9) 恰好补足，故每个真实历史图都是 2-extendable。

特别地，(X=G-\{v,x\}) 连通、最小度至少二，每条边都能与 (e) 共同扩张为 (G) 的完美匹配，故每条边都属于 (X) 的某个完美匹配。(X) 无桥：若桥出现在一个完美匹配中，割岸奇偶性会迫使每个完美匹配都使用它，与桥端点的另一条边也可进入匹配矛盾。

**引理。** (Y=X-f) 的每条桥，都挂着一个单点 (z) 或 (w)，且该点必为 (f) 的端点。因此

\[
f\cap\{z,w\}=\varnothing\quad\Longrightarrow\quad Y\text{ 连通无桥}.
\tag{10}
\]

**证明。** (P_{zw}(Y)\ne\varnothing) 使 (Y) 连通，并使任一桥 (b) 分开 (z,w)。在 (D_{uy\mid zw}(Y)) 中，(z-w) 路径必须跨越 (b)，故不交的 (u-y) 路径不能跨越；(u,y) 在同一岸。令另一岸为 (U)，其中恰有一个端口 (z) 或 (w)。

(X) 无桥，所以 (f) 跨越此割。在 (G) 中只需再补回唯一关联该端口的边，得到

\[
\delta_G(U)=\{b,f,\alpha\}\quad\text{或}\quad\{b,f,\beta\}.
\tag{11}
\]

对三价二分图的三边割，逐色数度给出

\[
3(|U\cap V_0|-|U\cap V_1|)
=|\delta_{V_0}(U)|-|\delta_{V_1}(U)|.
\]

右侧只能为 (-3,-1,1,3)，故只能是 (\pm3)：三条割边全从同一色穿出，该岸的该色点数多一。少数色在 (U) 中的邻点全在 (U)，其邻域大小最多比自身多一。另一岸含 (u,y,v,x)，每色至少两点，所以非空少数色集合处于 (9) 的适用范围，矛盾。因此少数色集合为空，而多数色只有一个点，即 (U=\{z\}) 或 (U=\{w\})。该点因删去 (f) 才降到度一。证毕。

## 3. 新的一般归约：平滑禁边而不丢失其状态

写 (f=\xi\eta)，取原颜色 (\xi\in V_0,\eta\in V_1)。设

\[
N_G(\xi)\setminus\{\eta\}=\{\xi_1,\xi_2\},\qquad
N_G(\eta)\setminus\{\xi\}=\{\eta_1,\eta_2\}.
\]

删除 (f) 后平滑两个度二点，定义

\[
L=G-\{\xi,\eta\}+s+t,\qquad
s=\xi_1\xi_2,\quad t=\eta_1\eta_2.
\tag{12}
\]

这与平滑必保边得到的 (T) 是不同的图。

### 3.1 (L) 的适用性是已证事实

(L) 的阶数也是 (n-2)。它是**简单平面三价图**：(s) 的两端在原 (V_1)，(t) 的两端在原 (V_0)，均互异；旧边全部异色，故没有新旧平行，也没有 (s=t)。它通常不再二分，不能归纳到原历史类。

(G-f) 连通无桥，因为 (G) 三边连通；平滑度二点保持这个性质，所以 (L) 连通无桥。由于 (f) 不接触 site 端口，(e) 完整保留且无平行边。

更强地，

\[
Z=L-\{v,x\}\text{ 连通无桥}.
\tag{13}
\]

确实，从 (Y) 出发：若 (f) 的某个端点是 (z) 或 (w)，它在 (Y) 中是叶点，删除该叶点；其他 (f) 端点在 (Y) 中度二，将其平滑。所得恰是 (Z)。第 2 节证明了被删叶边就是全部可能的桥；剩余图仍连通无桥，平滑不改变这个性质。(Z) 至少有 (n-4\ge4) 个点，所以没有孤立点或度一点。这也排除 (v,x) 在 (L) 中有公共邻点。

### 3.2 指定弦定理真正给出的结论

Diwan 的指定弦定理为：每条二边连通平面三价图的边，若不属于二边割，就是某个二因子的一条圈的弦。其 Theorem 3 的构造对 (13) 给出

\[
\mathcal F_e(L):=\{F\subseteq L:F\text{ 为二因子},\ e\notin F,
\ v,x\text{ 分圈}\}\ne\varnothing.
\tag{14}
\]

为明确“分圈”而非仅“不连通”，现场展开其构造：删除 (v,x) 后，将 (e) 一侧的两个端口接到一个新点，另一侧的两个端口接到另一个新点，并在两新点间加边 (d)。因为 (Z) 连通无桥，所得简单平面三价图无桥，且 (d) 不属于二边割：删除 (d) 与任一旧边后 (Z) 仍连通；删除 (d) 与任一接口边后两个新点仍各有边接入 (Z)。指定弦定理给出一条圈同时经过两新点，而不使用弦 (d)。平面非交叉配对使这条圈在恢复 (v,x) 时拆成分别经过 (v,x) 的两圈，其他圈原样保留。故得到 (14)，没有无残圈保证。

原始来源为 A. A. Diwan, *Chords of 2-Factors in Planar Cubic Bridgeless Graphs*, Graphs and Combinatorics 38 (2022), DOI [10.1007/s00373-022-02583-y](https://doi.org/10.1007/s00373-022-02583-y)，arXiv:2110.12584，Theorems 1、3。本轮直接校读了保留的原文 [PDF 第 5 页图像](ordered_hamilton_diwan_20260826/pdf_render/theorems-1-2-05.png) 与 [第 10 页图像](ordered_hamilton_diwan_20260826/pdf_render/theorem-3-10.png)，不以旧 note 的摘要代替定理。校读日期 2026-09-27；本轮在线 arXiv 查询因 DNS 失败，未完成更新检索，不作新颖性判断。

### 3.3 两条平滑边只能同取或同不取，但还原必须同取

保留原来的颜色标签，(V'_i=V_i\setminus\{\xi,\eta\})，两侧仍等势。对 (L) 的任意二因子 (F)，逐色数度得到

\[
0=2|V'_0|-2|V'_1|
=2\bigl(\mathbf1_{t\in F}-\mathbf1_{s\in F}\bigr).
\]

所以

\[
s\in F\iff t\in F.
\tag{15}
\]

这仅使用原色标签，不宣称 (L) 二分。完整的原族对应为

\[
\begin{split}
\{N\in\operatorname{PM}(G):e,f\in N\}
\longleftrightarrow
\{F\subseteq L:F\text{ 为二因子},\ e\notin F,\ s,t\in F\}.
\end{split}
\tag{16}
\]

正向把 (G-N) 在 (\xi,\eta) 处的两条二边路径平滑为 (s,t)；反向分别展开 (s,t)，并令 (f) 属于补匹配。这是完整族的互逆映射，逐个保持圈数和 (v,x) 的圈分区。由于 (e\in N)，(p\) 在 (v) 所在圈，(q\) 在 (x) 所在圈，故也保持所需的 seal 分圈判定。

令

\[
\mathcal F_e^{11}(L)=\{F\in\mathcal F_e(L):s,t\in F\},\qquad
\mathcal F_e^{00}(L)=\{F\in\mathcal F_e(L):s,t\notin F\}.
\]

由 (15)，两者不交且并为完整 (\mathcal F_e(L))。结合 (3)、(7)、(16)，一般 S9 的新精确形式为

\[
\boxed{
J_T(h,f)\ne\varnothing
\iff \exists F\in\mathcal F_e^{11}(L):c(F)=2.
}
\tag{17}
\]

(14) 确实给出了根分离二因子，但未指定它落在 (11) 还是 (00)。(00) 成员没有保持 (f\in N) 的直接还原；不得把两条平滑边的支撑非空加到另一个根分离成员上。

### 3.4 一个已闭合的新子域：禁边接触第三邻点时，初始分圈存在

若 (f\cap\{z,w\}\ne\varnothing)，则 (s,t) 中至少一条接触 (v) 或 (x)。对任意 (F\in\mathcal F_e(L))，补匹配已经使用 (e=vx)，所以这条接触根端点的平滑边必在 (F) 中。由 (15)，另一条也在。因此

\[
f\cap\{z,w\}\ne\varnothing
\quad\Longrightarrow\quad
\mathcal F_e^{00}(L)=\varnothing,
\quad\mathcal F_e^{11}(L)\ne\varnothing.
\tag{18}
\]

由 (16)，得到原图中的实际存在性定理

\[
\boxed{
\exists N\in\operatorname{PM}(G):e,f\in N,
\quad p,q\text{ 在 }G-N\text{ 的不同圈}.
}
\tag{19}
\]

这里没有预设分圈。它是从真实历史的 Hall 余量、两类已知无残圈状态、桥引理和指定弦定理推导的结论。它仍不保证 (c(G-N)=2)。当 (f=zw) 时，第 1.2 节的直接四圈证明更强，已保证恰两圈。

## 4. 固定图小校验与停止边界

标准库程序 [check_short_arc_forbidden_edge_smoothing_20260927.py](check_short_arc_forbidden_edge_smoothing_20260927.py) 复用旧程序的纯图函数，不调用其旧验证入口或最短返回计算。只重建 Pro 给出的同一个 20 点父图，在其新回复接口与同图的一个四圈对边接口上检查本轮公式。匹配枚举完整递归，保存的是这一个小图的匹配族；未扩阶。

运行：

```sh
python3 scratch/check_short_arc_forbidden_edge_smoothing_20260927.py
```

结果保存在新的 [JSON](short-arc-forbidden-edge-smoothing-20260927-results.json)，结束标记为 `SHORT_ARC_FORBIDDEN_EDGE_SMOOTHING_VERIFIED`。两个接口共用的父图有 89 个 PM、24 个 Hamilton 圈，完整覆盖 870 个有序边要求；完整独立边对扩张也通过。

| 同一 20 点图上的接口 | (f) | (D_{uy\mid zw}(Y)) | 目标 (D_{uz\mid wy}(Y)) | (T) 有平行边 |
|---|---|---:|---:|---|
| Pro：((4,0,16,19)) | ((1,2)) | 1 | 3 | 否 |
| 四圈：((0,16,19,10)) | ((17,18)=zw) | 9 | 5 | 是，(g\parallel f) |

Pro 的非对边接口中，(P_{zw}(Y)) 恰有一条；另外三个 (P(Y)) 均空，而对应的 (P(X)) 数量为 (3,5,5)。其完整固定 (e,f) 匹配族有 10 项：1 项补图为 Hamilton 圈且根未分离，其余 9 项根分离，圈数分布为 (2^3,3^3,4^2,5^1)。这同样是 (L) 中 (11) 分圈族的分布，(00) 分圈族在这个固定实例中为空。这个有限事实不能外推为一般 (18)。Pro 所列目标路径已逐边核对，属于三个目标之一。

四圈接口中，(Y) 的桥恰为 (3\!-!17) 与 (5\!-!18)，分别挂着 (z,w)；两条叶边删除后得到所需无桥核。(T) 计算始终以边标签保留新 (g) 与旧 (f)；程序完整枚举并核对 (J_T(h,f)) 与目标路径族的双射，未将平行边合并。

**本轮停止于严格新归约 (10)–(19)。** 尚未闭合的第一箭头是

\[
\begin{gathered}
\text{真实历史、全局 }H^{+-}\text{、困难前件 (2)，以及上述全部结构}\
\Longrightarrow\quad \mathcal F_e^{11}(L)\ne\varnothing
\end{gathered}
\tag{20}
\]

在 (f\cap\{z,w\}=\varnothing) 的一般子域中的成立性。即使 (20) 成立，还需证明同一族命中 (c(F)=2)。在 (18) 的接触子域，(20) 已证，剩余缺口精确为

\[
\min_{F\in\mathcal F_e^{11}(L)}c(F)=2.
\tag{21}
\]

这些只定位本归约尚缺的存在性步骤，不声称排除了其他证明路线。没有把指定弦所在圈当成 spanning，也没有把某些边各自可用或支撑满秩当成一个目标匹配。一般 S9、冻结 (T) 均未晋级；本轮不写 notes，不提交或推送。
