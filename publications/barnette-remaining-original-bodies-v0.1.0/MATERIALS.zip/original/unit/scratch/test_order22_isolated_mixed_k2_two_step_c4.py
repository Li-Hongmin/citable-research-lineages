#!/usr/bin/env python3
"""Exhaust the prescribed two-step C4 descendants of the Note 154 brace.

The authoritative first-step calculation has 38 legal children, exactly
nine of which attain the minimum of three rooted crossing exchanges.  This
script reconstructs those nine children and applies one further standard
facial C4 expansion, again avoiding the three fixed interface edges.

Every distinct labelled grandchild is checked afresh for all hypotheses in
scope and, if it passes, for the complete perfect-matching fibre and complete
single-alternating-cycle exchange graph.  The search stops immediately if a
one-crossing grandchild is found.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations

import networkx as nx

from test_order22_isolated_mixed_k2_one_step_c4 import (
    FORCED,
    GRAPH6,
    ROOT,
    SURVIVING,
    edge,
    enumerate_perfect_matchings,
    exchange_data,
    expand_on_face,
    face_edges,
    is_target,
    legal_wide,
    opposite_on_square,
    plane_faces,
    two_extendable,
)


INTERFACE = {edge(*ROOT), edge(*FORCED), edge(*SURVIVING)}


def graph6(graph: nx.Graph) -> str:
    return nx.to_graph6_bytes(graph, header=False).decode().strip()


def structural_failures(graph: nx.Graph) -> tuple[str, ...]:
    """Return every cheap graph/decorated-hypothesis failure."""

    failures = []
    if nx.number_of_selfloops(graph):
        failures.append("simple")
    if not nx.is_connected(graph):
        failures.append("connected")
    if set(dict(graph.degree()).values()) != {3}:
        failures.append("cubic")
    if not nx.is_bipartite(graph):
        failures.append("bipartite")
    planar = nx.check_planarity(graph)[0]
    if not planar:
        failures.append("plane")
    if nx.is_connected(graph) and nx.node_connectivity(graph) != 3:
        failures.append("3-connected")
    if not opposite_on_square(graph):
        failures.append("root-square")
    if planar and not legal_wide(graph):
        failures.append("legal-wide")
    return tuple(failures)


def first_step_minimum_children(parent: nx.Graph):
    """Reconstruct the exact nine minimum children from the authority script."""

    children = []
    seen = set()
    legal_count = 0
    crossing_histogram: Counter[int] = Counter()
    for face_index, face in enumerate(plane_faces(parent)):
        boundary = face_edges(face)
        for first_index, second_index in combinations(range(len(face)), 2):
            selected = {boundary[first_index], boundary[second_index]}
            if selected & INTERFACE:
                continue
            if set(boundary[first_index]) & set(boundary[second_index]):
                continue
            child = expand_on_face(parent, face, first_index, second_index)
            encoding = graph6(child)
            if encoding in seen:
                continue
            seen.add(encoding)
            if structural_failures(child):
                continue
            perfect_matchings = enumerate_perfect_matchings(child)
            if not two_extendable(child, perfect_matchings):
                continue
            targets = tuple(
                matching
                for matching in perfect_matchings
                if is_target(child, matching)
            )
            exchange, crossings = exchange_data(child, targets)
            legal_count += 1
            crossing_histogram[len(crossings)] += 1
            if len(crossings) == 3:
                children.append(
                    {
                        "graph": child,
                        "graph6": encoding,
                        "first_face_index": face_index,
                        "first_selected_edges": tuple(sorted(selected)),
                        "perfect_matchings": len(perfect_matchings),
                        "targets": len(targets),
                        "exchange_edges": exchange.number_of_edges(),
                        "exchange_components": tuple(
                            sorted(map(len, nx.connected_components(exchange)))
                        ),
                    }
                )

    assert legal_count == 38
    assert crossing_histogram == Counter(
        {3: 9, 5: 11, 6: 1, 7: 5, 9: 4, 11: 2, 13: 2, 15: 2, 16: 1, 23: 1}
    )
    assert len(children) == 9
    return tuple(children)


def print_witness(record, graph, perfect_matchings, targets, exchange, crossings):
    """Freeze all literal data needed to reconstruct the first witness."""

    print("FIRST_ONE_CROSSING_GRANDCHILD", record)
    print("edges", sorted(edge(*item) for item in graph.edges()))
    print("perfect_matchings", [sorted(item) for item in perfect_matchings])
    print("targets", [sorted(item) for item in targets])
    print("exchange_edges", sorted(exchange.edges()))
    print("crossings", crossings)
    print("legal_wide_witnesses", legal_wide(graph))
    print("ORDER22_ISOLATED_K2_TWO_STEP_COUNTEREXAMPLE_FOUND")


def main() -> None:
    parent = nx.from_graph6_bytes(GRAPH6.encode())
    first_children = first_step_minimum_children(parent)
    print("first_step_minimum_children=9")
    for index, record in enumerate(first_children):
        print(
            "FIRST_CHILD",
            index,
            {
                key: value
                for key, value in record.items()
                if key != "graph"
            },
        )

    raw_attempts = 0
    distinct_attempts = 0
    duplicate_attempts = 0
    rejection_histogram: Counter[tuple[str, ...]] = Counter()
    legal_records = []
    crossing_histogram: Counter[int] = Counter()
    component_histogram: Counter[tuple[int, ...]] = Counter()
    seen_grandchildren = set()

    for first_child_index, first_record in enumerate(first_children):
        child = first_record["graph"]
        for face_index, face in enumerate(plane_faces(child)):
            boundary = face_edges(face)
            for first_index, second_index in combinations(range(len(face)), 2):
                selected = {boundary[first_index], boundary[second_index]}
                if selected & INTERFACE:
                    continue
                if set(boundary[first_index]) & set(boundary[second_index]):
                    continue
                raw_attempts += 1
                grandchild = expand_on_face(
                    child, face, first_index, second_index
                )
                encoding = graph6(grandchild)
                if encoding in seen_grandchildren:
                    duplicate_attempts += 1
                    continue
                seen_grandchildren.add(encoding)
                distinct_attempts += 1

                failures = structural_failures(grandchild)
                if failures:
                    rejection_histogram[failures] += 1
                    continue

                perfect_matchings = enumerate_perfect_matchings(grandchild)
                if not two_extendable(grandchild, perfect_matchings):
                    rejection_histogram[("2-extendable",)] += 1
                    continue

                targets = tuple(
                    matching
                    for matching in perfect_matchings
                    if is_target(grandchild, matching)
                )
                exchange, crossings = exchange_data(grandchild, targets)
                components = tuple(
                    sorted(map(len, nx.connected_components(exchange)))
                )
                record = {
                    "first_child_index": first_child_index,
                    "first_child_graph6": first_record["graph6"],
                    "second_face_index": face_index,
                    "second_selected_edges": tuple(sorted(selected)),
                    "graph6": encoding,
                    "perfect_matchings": len(perfect_matchings),
                    "targets": len(targets),
                    "exchange_edges": exchange.number_of_edges(),
                    "exchange_components": components,
                    "crossings": len(crossings),
                    "wide": legal_wide(grandchild),
                }
                legal_records.append(record)
                crossing_histogram[len(crossings)] += 1
                component_histogram[components] += 1

                if len(crossings) == 1:
                    print_witness(
                        record,
                        grandchild,
                        perfect_matchings,
                        targets,
                        exchange,
                        crossings,
                    )
                    return

    print(f"raw_second_step_attempts={raw_attempts}")
    print(f"distinct_labelled_grandchildren={distinct_attempts}")
    print(f"duplicate_labelled_histories={duplicate_attempts}")
    print("rejection_histogram", dict(sorted(rejection_histogram.items())))
    print(f"legal_two_step_grandchildren={len(legal_records)}")
    print("crossing_histogram", dict(sorted(crossing_histogram.items())))
    print("component_histogram", dict(sorted(component_histogram.items())))
    minimum = min(record["crossings"] for record in legal_records)
    minimum_records = [
        record for record in legal_records if record["crossings"] == minimum
    ]
    print(f"minimum_crossings={minimum}")
    print(f"minimum_grandchildren={len(minimum_records)}")
    minimum_by_first_child = Counter(
        record["first_child_index"] for record in minimum_records
    )
    print("minimum_by_first_child", dict(sorted(minimum_by_first_child.items())))
    for first_child_index in range(len(first_children)):
        representative = next(
            record
            for record in minimum_records
            if record["first_child_index"] == first_child_index
        )
        print("MINIMUM_REPRESENTATIVE", representative)
    print("one_crossing_grandchildren=0")
    print("ORDER22_ISOLATED_K2_TWO_STEP_COUNTEREXAMPLE_NOT_FOUND")


if __name__ == "__main__":
    main()
