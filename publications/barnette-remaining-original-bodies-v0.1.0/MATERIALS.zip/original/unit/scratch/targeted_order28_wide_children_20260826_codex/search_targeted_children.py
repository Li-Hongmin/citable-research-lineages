#!/usr/bin/env python3
"""Search one-step C4 children of the closest order-24 wide interfaces.

This is a deliberately bounded construction search.  It does not enumerate
all order-28 braces.  For each selected order-24 parent it generates every
legal dual-vertex split, converts the result back to the plane cubic brace,
and tests every wide two-gate interface in that child.  The run stops at the
first complete target family that forces both gates and records whether that
family still has a nonneutral lift.
"""

from __future__ import annotations

from collections import Counter
import argparse
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
ORDER24_DIR = UNIT / "scratch" / "existence_lifting_order24_20260826_codex"
ORDER24_SCRIPT = ORDER24_DIR / "census_complete_family_existence_order24.py"
ORDER28_ANALYSER = (
    UNIT
    / "scratch"
    / "wide_forced_family_order26_20260826_codex"
    / "search_wide_forced_family_order26.py"
)

# The first two are respectively closest by neutral count and neutral fraction
# among mixed order-24 wide families.  The third is the first real failed
# target-component witness.
PARENTS = (
    "W???????????w?s?P_BC?I_?L??d??`_?@g??R??Gg??B_?",
    "W???????????w?s?P_BC?Go?B_?R??W_?Og?CB??Gg??B_?",
    "W???????????w?s?P_BC?IO?L??H_?BO??w?CD??cG??P_?",
)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


order24 = load_module(ORDER24_SCRIPT, "targeted_children_order24")
analyse = load_module(ORDER28_ANALYSER, "targeted_children_order28")
lift = order24.lift_bundle
analyse.ORDER = 28


def legal_children(parent_graph6: str):
    primal = nx.from_graph6_bytes(parent_graph6.encode())
    planar, embedding = nx.check_planarity(primal)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    primal_faces = order24.source_bundle.plane_faces(primal, embedding)
    reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)

    for z in sorted(reduced):
        rotation = rotations[z]
        for first_index, second_index, first_gate, second_gate in lift.gate_pairs(
            rotation
        ):
            left_size = second_index - first_index + 1
            right_size = len(rotation) - (second_index - first_index) + 1
            if left_size % 2 == 0 or right_size % 2 == 0:
                continue
            expanded, _locals, _left_arc, _right_arc = lift.split_vertex(
                reduced, z, rotation, first_index, second_index
            )
            expanded_faces = lift.expanded_triangulation_faces(expanded)
            if expanded_faces is None:
                continue
            child = lift.dual_from_plane_graph(expanded, expanded_faces)
            check = lift.verify_brace(child)
            assert check["vertices"] == 28
            child_graph6 = order24.graph6(child)
            child_planar, child_embedding = nx.check_planarity(child)
            assert child_planar and isinstance(child_embedding, nx.PlanarEmbedding)
            child_faces = order24.source_bundle.plane_faces(child, child_embedding)
            yield {
                "parent_graph6": parent_graph6,
                "parent_operation": {
                    "split_vertex": z,
                    "rotation": rotation,
                    "gate_indices": (first_index, second_index),
                    "gate_vertices": (first_gate, second_gate),
                    "closed_arc_cardinalities": (left_size, right_size),
                },
                "child_graph6": child_graph6,
                "child": child,
                "child_faces": child_faces,
            }


def search() -> dict[str, object]:
    totals = Counter()
    by_parent = []
    first_witness = None

    for parent_graph6 in PARENTS:
        parent_counts = Counter()
        seen_labelled_graph6 = set()
        for child_record in legal_children(parent_graph6):
            totals["legal_parent_operations"] += 1
            parent_counts["legal_parent_operations"] += 1
            child_graph6 = child_record["child_graph6"]
            if child_graph6 in seen_labelled_graph6:
                totals["repeated_labelled_child_graph6"] += 1
                parent_counts["repeated_labelled_child_graph6"] += 1
                continue
            seen_labelled_graph6.add(child_graph6)
            totals["tested_labelled_children"] += 1
            parent_counts["tested_labelled_children"] += 1

            record, witness = analyse.analyse_brace(
                child_graph6,
                child_record["child"],
                child_record["child_faces"],
            )
            for key, value in record.items():
                if key in {"source_order", "source_graph6", "dual_vertices"}:
                    continue
                assert isinstance(value, int)
                totals[key] += value
                parent_counts[key] += value
            if parent_counts["tested_labelled_children"] % 25 == 0:
                print(
                    json.dumps(
                        {
                            "parent": PARENTS.index(parent_graph6),
                            "tested_children": parent_counts[
                                "tested_labelled_children"
                            ],
                            "wide_interfaces": parent_counts[
                                "wide_target_interfaces"
                            ],
                        },
                        sort_keys=True,
                    ),
                    flush=True,
                )
            if witness is not None:
                first_witness = {
                    "construction": {
                        "parent_graph6": parent_graph6,
                        "parent_operation": child_record["parent_operation"],
                        "child_graph6": child_graph6,
                    },
                    "wide_forced_family": witness,
                }
                break

        by_parent.append(
            {
                "parent_graph6": parent_graph6,
                "coverage_before_stop": dict(sorted(parent_counts.items())),
            }
        )
        if first_witness is not None:
            break

    if first_witness is None:
        status = "targeted_one_step_order28_route_closed"
    elif first_witness["wide_forced_family"][
        "complete_target_family_contains_liftable_target"
    ]:
        status = "wide_gate_escape_counterexample_but_ordinary_lifting_survives"
    else:
        status = "ordinary_wide_site_lifting_counterexample"
    return {
        "status": status,
        "scope": {
            "source_order": 24,
            "child_order": 28,
            "parents": PARENTS,
            "operation": "every legal one-step dual-vertex C4 split",
            "child_test": "every legal wide split and nonempty unchanged-root target family",
            "not_claimed": "complete order-28 census or unlabelled child deduplication",
        },
        "coverage_before_stop": dict(sorted(totals.items())),
        "by_parent_before_stop": by_parent,
        "first_witness": first_witness,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    payload = search()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if args.output is not None:
        args.output.write_text(rendered)
        print("certificate", args.output)
    print(json.dumps(payload["coverage_before_stop"], sort_keys=True))
    print(payload["status"].upper())


if __name__ == "__main__":
    main()
