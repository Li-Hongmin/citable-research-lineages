#!/usr/bin/env python3
"""Test simultaneous neutral-gate targets at two preserved parent sites."""

from __future__ import annotations

from collections import Counter
import argparse
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CHILD_SEARCH = HERE / "search_targeted_children.py"


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


children = load_module(CHILD_SEARCH, "two_site_parent_source")
order24 = children.order24
lift = children.lift
edge = order24.edge


def legal_sites(reduced, rotations, wide_only):
    sites = []
    for z in sorted(reduced):
        rotation = rotations[z]
        for i, j, first_gate, second_gate in lift.gate_pairs(rotation):
            left_size = j - i + 1
            right_size = len(rotation) - (j - i) + 1
            if left_size % 2 == 0 or right_size % 2 == 0:
                continue
            if wide_only and min(left_size, right_size) < 5:
                continue
            expanded, _locals, _left, _right = lift.split_vertex(
                reduced, z, rotation, i, j
            )
            if lift.expanded_triangulation_faces(expanded) is None:
                continue
            sites.append(
                {
                    "z": z,
                    "rotation": rotation,
                    "gate_indices": (i, j),
                    "gate_vertices": (first_gate, second_gate),
                    "closed_arc_cardinalities": (left_size, right_size),
                }
            )
    return tuple(sites)


def search(first_wide_only):
    totals = Counter()
    first_failure = None
    for parent_graph6 in children.PARENTS:
        primal = nx.from_graph6_bytes(parent_graph6.encode())
        planar, embedding = nx.check_planarity(primal)
        assert planar and isinstance(embedding, nx.PlanarEmbedding)
        faces = order24.source_bundle.plane_faces(primal, embedding)
        reduced, rotations = lift.dual_from_primal_faces(primal, faces)
        reduced_faces = lift.verify_reduced_triangulation(reduced)
        all_sites = legal_sites(reduced, rotations, wide_only=first_wide_only)
        wide_sites = legal_sites(reduced, rotations, wide_only=True)
        families = lift.target_families(reduced, reduced_faces)[0]
        vertices = tuple(sorted(reduced))
        dual_to_primal = order24.primal_edge_by_dual_edge(primal, faces)
        family_cache = {}
        for root, encoded in families.items():
            colours = tuple(
                lift.decode_colouring(vertices, item) for item in encoded
            )
            matchings = tuple(
                order24.matching_from_colour(
                    primal, reduced, dual_to_primal, colour
                )
                for colour in colours
            )
            family_cache[root] = matchings

        for operation in all_sites:
            u = operation["z"]
            operation_gates = tuple(
                dual_to_primal[edge(u, gate)]
                for gate in operation["gate_vertices"]
            )
            for query in wide_sites:
                z = query["z"]
                if u == z or u in reduced[z]:
                    continue
                query_gates = tuple(
                    dual_to_primal[edge(z, gate)]
                    for gate in query["gate_vertices"]
                )
                for root, matchings in family_cache.items():
                    if u in root or z in root:
                        continue
                    totals["preserved_two_site_interfaces"] += 1
                    operation_neutral = tuple(
                        index
                        for index, matching in enumerate(matchings)
                        if sum(gate in matching for gate in operation_gates) <= 1
                    )
                    query_neutral = tuple(
                        index
                        for index, matching in enumerate(matchings)
                        if sum(gate in matching for gate in query_gates) <= 1
                    )
                    assert query_neutral
                    if not operation_neutral:
                        totals["interfaces_with_forced_first_site"] += 1
                        continue
                    totals["interfaces_with_both_neutral_marginals"] += 1
                    simultaneous = sorted(
                        set(operation_neutral) & set(query_neutral)
                    )
                    if simultaneous:
                        totals["interfaces_with_simultaneous_neutral_target"] += 1
                        continue
                    first_failure = {
                        "parent_graph6": parent_graph6,
                        "operation_site": operation,
                        "operation_primal_gates": operation_gates,
                        "wide_query_site": query,
                        "query_primal_gates": query_gates,
                        "dual_root": root,
                        "primal_root": dual_to_primal[root],
                        "family_size": len(matchings),
                        "operation_neutral_indices": operation_neutral,
                        "query_neutral_indices": query_neutral,
                    }
                    break
                if first_failure is not None:
                    break
            if first_failure is not None:
                break
        if first_failure is not None:
            break
    return {
        "status": (
            "actual_two_site_gate_avoidance_counterexample"
            if first_failure is not None
            else "simultaneous_two_site_avoidance_holds_for_three_parents"
        ),
        "scope": {
            "parents": children.PARENTS,
            "first_site": (
                "every legal wide C4 operation site whose family has a neutral target"
                if first_wide_only
                else "every legal C4 operation site whose family has a neutral target"
            ),
            "second_site": "every remote preserved legal wide site",
            "roots": "every nonempty target family unchanged at both sites",
        },
        "counts_before_stop": dict(sorted(totals.items())),
        "first_failure": first_failure,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--first-wide-only", action="store_true")
    args = parser.parse_args()
    payload = search(args.first_wide_only)
    if args.output is not None:
        args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        print("certificate", args.output)
    print(json.dumps(payload["counts_before_stop"], sort_keys=True))
    print(payload["status"].upper())


if __name__ == "__main__":
    main()
