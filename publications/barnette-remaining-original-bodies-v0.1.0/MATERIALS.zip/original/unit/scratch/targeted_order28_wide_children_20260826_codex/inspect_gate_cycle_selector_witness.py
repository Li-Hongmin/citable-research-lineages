#!/usr/bin/env python3
"""List all gate-changing cycles in the frozen arbitrary-cycle counterexample."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
SOURCE = (
    HERE.parent
    / "family_forced_gate_leaf_20260826_codex"
    / "verify_unrepairable_gate_cycle_witness.py"
)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


verify = load_module(SOURCE, "selector_witness_source")
search = verify.search
edge = verify.edge


def main() -> None:
    primal = nx.from_graph6_bytes(verify.SOURCE_GRAPH6.encode())
    planar, embedding = nx.check_planarity(primal)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    faces = search.source.source_bundle.plane_faces(primal, embedding)
    reduced, _rotations = search.lift.dual_from_primal_faces(primal, faces)
    reduced_faces = search.lift.verify_reduced_triangulation(reduced)
    dual_to_primal = search.source.primal_edge_by_dual_edge(primal, faces)
    root = edge(*verify.ROOT)
    primal_root = dual_to_primal[root]
    gates = tuple(
        dual_to_primal[edge(verify.Z, verify.ROTATION[index])]
        for index in verify.GATE_INDICES
    )
    family = search.lift.target_families(reduced, reduced_faces)[0][root]
    vertices = tuple(sorted(reduced))
    colours = tuple(search.lift.decode_colouring(vertices, item) for item in family)
    matchings = tuple(
        search.source.matching_from_colour(
            primal, reduced, dual_to_primal, colour
        )
        for colour in colours
    )
    base = matchings[verify.TARGET_INDEX]
    alternating_cycles = set()
    for matching in search.perfect_matchings(primal):
        pieces = search.diff_cycles(base, matching)
        if len(pieces) == 1:
            alternating_cycles.add(pieces[0])
    alternating_cycles = tuple(
        sorted(alternating_cycles, key=lambda one: (len(one), sorted(one)))
    )

    records = []
    for cycle in alternating_cycles:
        gate_mask = tuple(gate in cycle for gate in gates)
        if primal_root in cycle or not any(gate_mask):
            continue
        one = base ^ cycle
        one_shape = search.shape(primal, one, primal_root)
        if one_shape == (2, True):
            records.append(
                {
                    "length": len(cycle),
                    "gate_mask": gate_mask,
                    "single_shape": one_shape,
                    "single_target": True,
                    "repair_count": 0,
                    "edges": sorted(cycle),
                }
            )
            continue
        partners = []
        for partner in alternating_cycles:
            if partner == cycle or primal_root in partner:
                continue
            if search.vertices(cycle) & search.vertices(partner):
                continue
            double = one ^ partner
            if sum(gate in double for gate in gates) > 1:
                continue
            if search.shape(primal, double, primal_root) == (2, True):
                partners.append(partner)
        records.append(
            {
                "length": len(cycle),
                "gate_mask": gate_mask,
                "single_shape": one_shape,
                "single_target": False,
                "repair_count": len(partners),
                "repair_lengths": sorted(len(partner) for partner in partners),
                "edges": sorted(cycle),
            }
        )
    print(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
