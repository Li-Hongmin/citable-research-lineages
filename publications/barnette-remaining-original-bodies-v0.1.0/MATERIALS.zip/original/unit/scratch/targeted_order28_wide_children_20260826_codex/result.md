# Three targeted order-28 one-step families retain wide gate escapes

## Exact bounded statement

Take the following three reduced order-24 plane cubic bipartite braces:

1. the mixed wide interface with the minimum neutral-target count;
2. the mixed wide interface with the minimum neutral fraction;
3. the first actual order-24 forced-component failure.

For each parent, perform every legal one-step dual-vertex split whose dual
is again a simple plane cubic bipartite brace of order 28.  In every resulting
labelled child, inspect every legal wide two-gate split and every nonempty
unchanged-root complete target family.  Then every such family contains a
target using at most one gate.

The exact totals are

\[
196\text{ parent operations},\quad
190\text{ distinct labelled children},\quad
2724\text{ legal wide child splits},
\]

\[
90896\text{ nonempty wide interfaces},\quad
1573984\text{ target instances},\quad
0\text{ wide forced families}.
\]

Thus none of the three tight order-24 examples produces a WGE counterexample
by one legal C4 expansion.  A fortiori, this bounded construction class
contains no ordinary wide-site lifting counterexample.

There is also a pointwise distance-two strengthening in the same operation
class.  Among all wide interfaces there are 162,492 double-gate targets.  For
each target, minimize over neutral targets in the same complete family the
number of alternating-cycle components of their symmetric difference.  The
exact distribution is

\[
153638\text{ at distance }1,qquad
8854\text{ at distance }2,qquad
0\text{ at distance }\ge3.
\]

Thus every tested double-gate target satisfies the synchronized one/two-cycle
selector, not merely the family-level WGE conclusion.

## A child escape need not descend from a parent target

Simple two-site inheritance already fails in the first parent.  For dual root
((11,13)), take the wide operation at (z=1), gate indices ((3,7)), and
the remote wide query at (z=8), gate indices ((1,5)).  The parent family
has five targets.  Operation-neutral indices are ({3,4}), while
query-neutral indices are ({0,1}); the two sets are disjoint.  More
strongly, indices 0 and 1 have no lift row at the operation site, while the
only lifted parent targets 3 and 4 remain query-double-gate.

The child family nevertheless has eleven targets, six of them query-neutral.
None of those six contracts to a parent target under either colour at the
removed vertex.  Their NAE contractions are non-target profiles with cycle
ranks (0,1,2,3); the rank-one contraction has the root off its unique
cycle.  The C4 gadget therefore creates genuinely new target states from a
neutral non-target defect spectrum.

Consequently WGE is not monotone at the level of the parent target family.
Any reduction induction through C4 faces must retain appropriate neutral NAE
defect states, not only target matchings or simultaneous-neutral marginals.
The focused data are reproduced by `analyze_new_child_escape.py`.

## Boundary

This is not a complete order-28 census and the 190 children were not
canonically deduplicated up to unlabelled isomorphism.  Duplicate testing does
not weaken the claimed operation-class coverage, but the result says nothing
about order-28 braces outside these three one-step descendant families.

The weakest computational dependency is the inherited complete NAE-colouring
and target-family enumerator; all children, wide splits, roots and gate counts
are evaluated directly.  The result is an exact finite route closure, not an
arbitrary-order theorem.

Reproduction:

```bash
uv run --with 'networkx==3.6.1' \
  units/barnette/scratch/targeted_order28_wide_children_20260826_codex/search_targeted_children.py \
  --output units/barnette/scratch/targeted_order28_wide_children_20260826_codex/targeted_children.json

uv run --with 'networkx==3.6.1' \
  units/barnette/scratch/targeted_order28_wide_children_20260826_codex/profile_neutral_cycle_distance.py \
  --output units/barnette/scratch/targeted_order28_wide_children_20260826_codex/neutral_cycle_distance.json
```
