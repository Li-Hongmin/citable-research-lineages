# Brace common-cycle closure does not force a rooted supplement

This note addresses one fixed split mechanism.  Its inputs are
[Notes 108](../../notes/108-kill-cover-supplementation-is-exactly-a-rooted-split-bond-lemma.md),
[114](../../notes/114-all-new-cell-rooted-bonds-have-four-attachment-obstruction-types.md),
[117](../../notes/117-mixed-sector-survival-is-a-gate-even-parent-child-exchange-alternative.md),
[132](../../notes/132-complete-boundary-rows-and-bond-deletion-atoms-are-one-step-closed.md),
[133](../../notes/133-complete-unary-and-pair-type-supports-form-a-finite-cen-uv-transducer.md),
and [134](../../notes/134-a-two-row-type-support-countermodel-isolates-the-actual-matching-incidence-gap.md).
It does not iterate a CEN/UV word and does not claim a counterexample to the
rooted split-bond lemma.

The conclusion is a route closure.  Brace closure forces an unlabelled
\(R_{00}\) perfect matching, but it does not force root admission or a
Note-114 attachment row.  The stronger proposed directed cycle through
\(p,q\) and the gate mark is not a consequence of being a plane cubic
brace, even when the site expansion is again a brace.

## 1. Fixed-perfect-matching digraph

Let \(G\) be bipartite with parts \(X,Y\), and fix a perfect matching
\(M\).  Contract every edge \(m\in M\) to a vertex \(\widehat m\).  Every
nonmatching edge \(xy\), \(x\in X,y\in Y\), becomes an arc from the
contracted \(M\)-edge at \(x\) to the contracted \(M\)-edge at \(y\).
Denote the resulting digraph by \(D_M\).

There is a bijection

\[
\{\text{\(M\)-alternating simple cycles in \(G\)}\}
\longleftrightarrow
\{\text{directed simple cycles in \(D_M\)}\}.
\tag{1}
\]

An edge of \(M\) is marked by a vertex of \(D_M\); an edge outside \(M\)
is marked by its corresponding arc.

For a bipartite graph, the elementary Hall characterization of
2-extendability is

\[
|N_G(S)|\ge |S|+2
\quad
(0<|S|\le |X|-2).
\tag{2}
\]

For a graph obtained from a digraph \(D\) by the inverse construction

\[
V(G_D)=\{x_v,y_v:v\in V(D)\},\qquad
E(G_D)=\{x_vy_v\}\cup\{x_uy_v:u\to v\in A(D)\},
\tag{3}
\]

the left side of (2) is

\[
|N_{G_D}(X_S)|=|S\cup N_D^+(S)|.
\tag{4}
\]

If \(D\) remains strongly connected after deletion of any one vertex,
then every \(S\) in (2) has at least two out-neighbours outside \(S\).
Otherwise deleting its unique outside out-neighbour, if any, leaves no
directed path from \(S\) to the remaining complement.  Thus (4) proves
that \(G_D\) is 2-extendable.  The converse is the same cut argument.
Consequently a brace gives a strongly 2-connected \(D_M\).

Strong 2-connectivity gives the standard two-object conclusion: any two
vertices of \(D_M\) lie on a common directed cycle.  Hence if a
state-\(11\) parent matching \(M\) contains the two site edges \(p,q\),
there is an \(M\)-alternating cycle containing both.  Flipping it gives a
perfect matching

\[
Q=M\mathbin\triangle C_{pq},
\qquad p,q\notin Q.
\tag{5}
\]

After the split, \(Q\) supplies an unlabelled \(R_{00}\) child perfect
matching.  This is the exact unary occupancy forced by the brace axiom.

## 2. The correct rooted directed-cycle target

The canonical child of a parent state-\(11\) row is \(C_{11}\).  By
Note 108, its central \(C\)-component is isolated, so it is never
root-admissible.  A \(C_{11}\)--\(R_{00}\) pair therefore cannot prove
supplementation.

Let

\[
\mathcal C=\{C_{00},C_{10},C_{01}\},
\qquad
\mathcal N=\{R_{00},X_{uy},X_{vx}\}.
\tag{6}
\]

The allowed cell-pair set is the fourteen rows of Note 114:

\[
\begin{aligned}
\mathscr P^*={}&
\{\mathcal C\!-\!X_{uy},\ \mathcal C\!-\!X_{vx},\
R_{00}\!-\!X_{uy},\ R_{00}\!-\!X_{vx},\\
&C_{10}\!-\!R_{00},\ C_{01}\!-\!R_{00},\
R_{00}\!-\!R_{00},\
X_{uy}\!-\!X_{uy},\
X_{vx}\!-\!X_{vx},\
X_{uy}\!-\!X_{vx}\}.
\end{aligned}
\tag{7}
\]

Here the first two symbols denote all three canonical choices, so (7)
contains \(3+3+2+2+3+1=14\) unordered pairs.  The pair
\(C_{00}\)--\(R_{00}\) is impossible.

Fix a root-admissible child perfect matching \(F\).  The exact
fixed-matching-digraph formulation of a supplement is:

\[
\boxed{
\begin{gathered}
\text{there is a directed simple cycle \(Z\subseteq D_F\) containing
the gate vertex or arc,}\\
H=F\mathbin\triangle Z\text{ is root-admissible, and}\\
\{\operatorname{cell}(F),\operatorname{cell}(H)\}\in\mathscr P^*.
\end{gathered}}
\tag{8}
\]

The directed-cycle condition is precisely that \(F\triangle H\) is one
alternating cycle carrying the gate change.  In the dual language, (8) is
equivalent to one of the attachment rows in Note 114.

Equation (8) cannot be expressed exactly using only a parent \(D_M\).
The \(X_{uy}\) and \(X_{vx}\) rows have two-hole exterior restrictions and
need not have a parent perfect-matching ancestor.  They appear either as
ordinary perfect matchings in the child digraph or as near-perfect rows in
the complete parent boundary language of Note 132.

Even a parent directed cycle through \(p,q\) and the gate mark would only
flip a state-\(11\) matching to an \(R_{00}\) matching.  Its evident local
pair is \(C_{11}\)--\(R_{00}\), whose \(C_{11}\) endpoint is inadmissible.
Thus three-object parent cyclability would still not imply (8).

## 3. What actual brace occupancy does and does not repair

The two-row countermodel of Note 134 omitted every source of a new cell.
Equation (5) shows why that omission cannot persist in the unlabelled
complete PM family of a brace: an \(R_{00}\) perfect matching exists.

Root-admissible occupancy is stronger.  The matching \(Q\) from (5) may
fail the labelled three-region condition, so

\[
\mathcal A_{R_{00}}=\varnothing
\tag{9}
\]

is still compatible with the brace conclusion (5).  Even if an admitted
\(R_{00}\) row exists, a partner with opposite gate bit may be absent
(obstruction \(\mathsf O\)), or every pair may fail one of
\(\mathsf F_0,\mathsf F_1,\mathsf F_2\) from Note 114.  Strong connectivity
of \(D_M\) contains none of these labelled shore-attachment assertions.

ParentKill has the same limitation.  It excludes rooted
canonical--canonical child bonds; it does not positively assert new-cell
rooted occupancy, an opposite-gate partner, or any attachment condition.

## 4. A plane cubic brace route counterexample

The failure of three-object cyclability already occurs in the exact
unlabelled graph class.

Let indices be in \(\mathbb Z_3\), and define a digraph \(D_0\) on

\[
\{a_i,b_i,c_i:i\in\mathbb Z_3\}
\tag{10}
\]

with arcs

\[
a_i\to a_{i+1},\qquad b_i\to b_{i+1},\qquad
a_i\leftrightarrow c_i,\qquad b_i\leftrightarrow c_i.
\tag{11}
\]

Every vertex has indegree and outdegree two.  The digraph remains strong
after deletion of any vertex.  If \(c_i\) is deleted, the two directed
triangles remain joined by the other two bidirected channels.  If \(a_i\)
is deleted, the \(b\)-triangle remains, and every other vertex reaches and
is reached from it through its surviving bidirected channel; the case
\(b_i\) is symmetric.

Form \(G=G_{D_0}\) by (3).  It is cubic and bipartite.  It is planar: one
embedding has the two hexagonal faces

\[
\begin{aligned}
&x_{a_0}y_{a_1}x_{a_1}y_{a_2}x_{a_2}y_{a_0},\\
&x_{b_0}y_{b_0}x_{b_2}y_{b_2}x_{b_1}y_{b_1},
\end{aligned}
\tag{12}
\]

the six square faces

\[
x_{a_i}y_{a_i}x_{c_i}y_{c_i},
\qquad
x_{b_i}y_{c_i}x_{c_i}y_{b_i},
\tag{13}
\]

and the three further hexagons

\[
x_{a_i}y_{c_i}x_{b_i}y_{b_{i+1}}x_{c_{i+1}}y_{a_{i+1}}.
\tag{14}
\]

These eleven faces use every edge twice and satisfy
\(18-27+11=2\).  Strong 2-connectivity of \(D_0\), together with
(2)--(4), proves that \(G\) is a plane cubic brace.

Use the perfect matching

\[
\begin{aligned}
M=\{&
x_{a_i}y_{a_i}\ (i=0,1,2),\
x_{b_0}y_{b_0},x_{b_1}y_{b_1},\\
&x_{c_0}y_{c_0},x_{c_1}y_{c_1},\
x_{b_2}y_{c_2},x_{c_2}y_{b_2}\}.
\end{aligned}
\tag{15}
\]

Take

\[
p=x_{a_1}y_{a_1},\qquad
q=x_{a_2}y_{a_2},\qquad
g=x_{c_2}y_{c_2}.
\tag{16}
\]

The site edges \(p,q\) are disjoint and cofacial in the first face of
(12), and the gate edge \(g\) is disjoint from the site.  The alternating
4-cycle

\[
x_{b_2}y_{c_2}x_{c_2}y_{b_2}x_{b_2}
\tag{17}
\]

contains \(g\) and avoids \(p,q\).  Flipping (17) gives a second matching
\(N\) which still contains \(p,q\).  Thus \(M,N\) are an actual
local-state-\(11\)--local-state-\(11\) single-cycle pair carrying the gate
change.

In \(D_M\), abbreviate the contracted matching edges by

\[
\begin{gathered}
A_i=x_{a_i}y_{a_i},\quad
B_i=x_{b_i}y_{b_i}\ (i=0,1),\quad
C_i=x_{c_i}y_{c_i}\ (i=0,1),\\
S=x_{b_2}y_{c_2},\qquad T=x_{c_2}y_{b_2}.
\end{gathered}
\tag{18}
\]

The site is marked by \(A_1,A_2\), and \(g\) is the arc \(T\to S\).
There is no directed simple cycle containing all three marks.

Indeed, a cycle using \(T\to S\) corresponds, after deleting that arc, to
a simple \(S\)-to-\(T\) path.  Apart from the direct arc \(S\to T\), such
a path must start

\[
S\to B_0
\tag{19}
\]

and end

\[
B_1\to T.
\tag{20}
\]

After \(S,T\) are removed, \(A_2\) has unique predecessor \(A_1\) and
unique successor \(A_0\).  Hence a path through both site vertices must
contain

\[
A_1\to A_2\to A_0.
\tag{21}
\]

But a simple \(B_0\)-to-\(A_1\) path which has not already ended at \(B_1\)
is forced to begin

\[
B_0\to C_0\to A_0\to A_1.
\tag{22}
\]

Equations (21)--(22) repeat \(A_0\), a contradiction.

The standard \(C_4\)-expansion at \(p,q\) is again a brace.  For
completeness, call the four patch vertices
\(\alpha,\beta,\gamma,\delta\), in the order

\[
u\alpha,\ \alpha\beta,\ \beta v,\quad
x\gamma,\ \gamma\delta,\ \delta y,\quad
\alpha\delta,\ \beta\gamma.
\]

Extend \(M\setminus\{p,q\}\) by the \(C_{11}\) patch matching
\[
u\alpha,\quad \beta v,\quad x\gamma,\quad\delta y.
\]
After contraction, put
\[
U=u\alpha,\qquad V=\beta v,\qquad
X=x\gamma,\qquad Y=\delta y.
\]
The resulting digraph has out-neighbour table

\[
\begin{array}{c|c@{\qquad}c|c}
A_0&C_0,V&U&C_1,Y\\
X&A_0,S&B_0&B_1,C_0\\
B_1&C_1,T&S&B_0,T\\
C_0&A_0,B_0&C_1&B_1,V\\
T&S,Y&V&U,X\\
Y&U,X&&
\end{array}
\tag{23}
\]

and indegree and outdegree two at every vertex.  The following closed
directed walks visit every vertex remaining after the vertex in the left
column is deleted:

\[
\begin{array}{c|l}
A_0&U,C_1,V,X,S,B_0,C_0,B_0,B_1,T,Y,U\\
U&A_0,C_0,B_0,B_1,C_1,V,X,S,T,Y,X,A_0\\
X&A_0,V,U,Y,U,C_1,B_1,T,S,B_0,C_0,A_0\\
B_0&A_0,C_0,A_0,V,U,C_1,B_1,T,S,T,Y,X,A_0\\
B_1&A_0,V,U,C_1,V,U,Y,X,S,T,S,B_0,C_0,A_0\\
S&A_0,C_0,B_0,B_1,T,Y,U,C_1,V,X,A_0\\
C_0&A_0,V,U,C_1,B_1,T,S,B_0,B_1,T,Y,X,A_0\\
C_1&A_0,V,U,Y,X,S,B_0,B_1,T,S,B_0,C_0,A_0\\
T&A_0,C_0,B_0,B_1,C_1,V,U,Y,X,S,B_0,C_0,A_0\\
V&A_0,C_0,B_0,B_1,C_1,B_1,T,S,T,Y,U,Y,X,A_0\\
Y&A_0,V,U,C_1,B_1,T,S,B_0,C_0,A_0,V,X,A_0
\end{array}
\tag{24}
\]

A closed walk spanning all remaining vertices proves strong connectivity.
Thus the digraph in (23) is strongly 2-connected, and (2)--(4) prove that
the child is 2-extendable.  The patch lies in the face (12), so the child is
also plane and cubic.  Hence (15)--(22) close the common-cycle route even
for an unlabelled cofacial parent/child plane-brace split.

The pure-standard-library verifier
[verify_brace_common_cycle_route_counterexample.py](verify_brace_common_cycle_route_counterexample.py)
checks the face certificate, parent and child 2-extendability, both perfect
matchings, the gate-changing \(C_4\), and every \(M\)-alternating cycle.  Its
terminal status is
\(\texttt{PLANE\_CUBIC\_BRACE\_COMMON\_CYCLE\_ROUTE\_COUNTEREXAMPLE\_VERIFIED}\).

## 5. Sharp remaining condition

The example above is not a rooted counterexample: no root labels have been
chosen, and global ParentKill has not been asserted.  It proves the narrower
but decisive fact

\[
\boxed{\text{brace alternating-cycle closure does not imply a common
cycle through \(p,q\) and the gate mark}.}
\tag{25}
\]

The exact stronger condition needed after ParentKill is **rooted,
cell-restricted gate cyclability**:

\[
\exists F\in\mathcal A_{\mathcal C\cup\mathcal N},\
\exists Z\subseteq D_F
\tag{26}
\]

such that \(Z\) is a directed simple cycle through the gate mark,
\(F\triangle Z\) is root-admissible, and the two cell labels form a pair
in \(\mathscr P^*\).  Equivalently, one opposite-gate pair in the complete
child family satisfies its Note-114 attachment row.

This condition simultaneously excludes the occupancy and attachment
obstructions

\[
\mathsf O,\mathsf F_0,\mathsf F_1,\mathsf F_2.
\tag{27}
\]

Ordinary brace closure proves only (5).  ParentKill removes
canonical--canonical edges but does not prove (26).  Notes 108, 114, 117
and 132--134 therefore neither prove nor refute Proposition P for actual
root-labelled braces.  They reduce it sharply to (26); the proposed
parent common-cycle mechanism is strictly insufficient.
