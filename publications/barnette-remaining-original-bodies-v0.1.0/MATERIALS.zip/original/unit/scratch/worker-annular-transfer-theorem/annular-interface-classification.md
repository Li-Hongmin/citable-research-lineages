# Exact four-port annular transfer classification

This is a disposable symbolic calculation.  It classifies one standard
plane four-port splice and does not assert that every formally allowed port
state is realized by a brace factor.

## 1. Matching connector states

Label the four connector edges by their port positions
\(0,1,2,3\) in cyclic order on the first boundary.  Their endpoint colours
on either factor alternate \(X,Y,X,Y\).  For a perfect matching \(N\), let

\[
 s(N)=N\cap\{e_0,e_1,e_2,e_3\}.
\]

The vertices of either factor not matched internally contain equally many
\(X\)- and \(Y\)-vertices.  Hence

\[
 |s(N)\cap\{0,2\}|=|s(N)\cap\{1,3\}|,
\]

so the only possible states are

\[
 \mathcal S=\{0,\Omega,A_0,A_1,A_2,A_3\},\qquad
 0=\varnothing,\quad \Omega=\{0,1,2,3\},\quad
 A_i=\{i,i+1\},
\tag{1}
\]

with indices modulo four.  These six states are necessary local states, not
a claim of six-state realizability in every brace.

For two perfect matchings \(M,Q\), put

\[
 D=s(M)\mathbin\triangle s(Q),\qquad d=|D|.
\]

The thirty-six ordered state pairs reduce exactly to

\[
\begin{array}{c|c|c}
d&\text{state pairs}&\text{ordered count}\\ \hline
0&s(M)=s(Q)&6\\
2&0\leftrightarrow A_i,\ \Omega\leftrightarrow A_i,
   \ A_i\leftrightarrow A_{i\pm1}&24\\
4&0\leftrightarrow\Omega,\ A_i\leftrightarrow A_{i+2}&6.
\end{array}
\tag{2}
\]

## 2. Alternating-component gluing

Restrict \(M\triangle Q\) to either factor.  Its nonclosed components are
paths whose endpoints are precisely the ports in \(D\).  Let \(z_j^\Delta\)
be the number of closed local components in factor \(j\).

At a terminal port, label the connector by the matching, \(M\) or \(Q\),
which uses it.  A local alternating path pairs terminals with the following
parity rule:

\[
\begin{array}{c|c}
\text{connector labels at the two terminals}&
\text{bipartite colours of the terminals}\\ \hline
\text{equal}&\text{opposite}\\
\text{different}&\text{equal}.
\end{array}
\tag{3}
\]

Indeed the first internal edge has the label opposite to the connector.
Equal connector labels therefore give an odd internal path, and different
labels give an even one.

Consequently the global alternating-component rule is exact.

1. If \(d=0\), no component is transferred across the annulus.  All
   components remain closed in their original factor.
2. If \(d=2\), each factor has one terminal path, and the two paths and two
   connector edges form exactly one cross-annular alternating cycle.  The
   other components are the \(z_1^\Delta+z_2^\Delta\) closed local cycles.
3. If \(d=4\) and \(\{s(M),s(Q)\}=\{0,\Omega\}\), all four terminal
   connector labels agree.  Each factor can have either noncrossing pairing

   \[
   \alpha=(01)(23),\qquad \beta=(03)(12).
   \]

   Equal pairings on the two factors give two cross-annular cycles; unequal
   pairings give one.
4. If \(d=4\) and \(\{s(M),s(Q)\}=\{A_i,A_{i+2}\}\), the connector labels
   occur as two consecutive \(M\)'s and two consecutive \(Q\)'s.  Rule
   (3) and planarity force the unique pairing

   \[
   (i,i+1)(i+2,i+3)
   \]

   on both factors.  Hence there are always two cross-annular alternating
   cycles, never one.

Equivalently, the overlay of the two local path pairings is a 2-regular
multigraph; its connected components are exactly the cross-annular
alternating cycles.

## 3. Closed demand cannot be absorbed

Let \(K\) be a closed component of \(M\triangle Q\).  If an
\(M\)-alternating cycle \(C\) contains every edge of
\((Q\setminus M)\cap E(K)\), then \(C=K\).  At each endpoint of a demanded
\(Q\)-edge, alternation forces the unique incident \(M\)-edge; repeating
around \(K\) forces all of \(K\), and the 2-regular cycle \(C\) cannot then
leave \(K\).

Therefore, if the two factors each contain a closed nontrivial component of
\(M\triangle Q\), no single \(M\)-alternating cycle contains all of
\(Q\setminus M\).  This conclusion is independent of \(s(M),s(Q)\), the
annular pairing, brace status, and legal-wide labels.  In the proposed
dichotomy, alternative (a) is then impossible.

## 4. Complement topology is separate data

The connector set used by the complement \(G-N\) is
\(\Omega\setminus s(N)\).  After deleting the connectors, the nonclosed
part in each factor has:

- four terminals and one of the pairings \(\alpha,\beta\) if \(s(N)=0\);
- two terminals and one path if \(s(N)=A_i\);
- no terminals if \(s(N)=\Omega\).

Thus for \(s(N)=0\), equal local complement pairings give two
cross-annular complement cycles and unequal pairings give one.  For
\(s(N)=A_i\), there is one cross-annular complement cycle.  For
\(s(N)=\Omega\), there is none.  Local closed complement cycles must be
added in every case.

Root separation is not determined by these unmarked component counts.  One
must also record the component containing each ordered root fragment.  In
particular, two completions can have the same connector state, the same
alternating path pairing, and the same unmarked complement quotient, but
put the two root fragments in the same or in different quotient components.

Here is the smallest explicit quotient witness to that independence.  Fix
\(s(M)=0\), give \(M\) the pairings \((\alpha,\alpha)\), and mark its two
cross-annular complement cycles by different roots.  Let \(Q\) have the
same connector state and one closed \(M\)-alternating demand component in
each factor.  Finally give a same-sector non-\(11\) row \(R\) state
\(s(R)=A_0\), no closed component of \(M\triangle R\), and a complement
quotient consisting of one cross-annular cycle \(X\) and one local cycle
\(Z\).  The following two root markings have identical \(M,Q\) data and
identical unmarked \(R\) data:

\[
\begin{array}{c|c|c}
&\text{first root}&\text{second root}\\ \hline
\Sigma^+&X&Z\\
\Sigma^-&X&X.
\end{array}
\tag{4}
\]

In \(\Sigma^+\), \(M\triangle R\) is the unique \(d=2\) annular cycle and
\(R\) is a root-separated escape.  In \(\Sigma^-\), the same single-cycle
row is not root-separated.  Taking the finite matching rows to be
\(\{M,Q,R\}\), the first record has alternative (b) and the second does
not, while alternative (a) fails in both by the closed-demand lemma.  This
is a strict finite **port-quotient** countermodel to determination by
unmarked matching transfer.  It is deliberately not claimed to be realized
by an actual brace or a legal-wide plane graph.

## 5. Necessary and sufficient annular escape signature

For a third perfect matching \(R\), record in each factor:

\[
\Sigma_j(M,R)=
\bigl(s(R),\ z_j^\Delta,\ \pi_j^\Delta;
z_j^c,\ \pi_j^c,\ \lambda_j;
\text{sector/cell labels}\bigr),
\tag{5}
\]

where \(\pi_j^\Delta\) is the terminal-path pairing for
\(M\triangle R\), \(\pi_j^c\) is the complement-path pairing, and
\(\lambda_j\) marks the root fragments on complement components.

A same-sector non-\(11\), root-separated, single-cycle escape exists if
and only if a compatible pair \((\Sigma_1,\Sigma_2)\) exists with the
required sector/cell labels, the complement quotient having exactly two
components with the ordered roots in different components, and one of the
following alternating conditions:

\[
\begin{array}{c|c}
|s(M)\triangle s(R)|&M\triangle R\text{ is one cycle iff}\\ \hline
0&z_1^\Delta+z_2^\Delta=1\\
2&z_1^\Delta=z_2^\Delta=0\\
4,\ \{s(M),s(R)\}=\{0,\Omega\}&
z_1^\Delta=z_2^\Delta=0\text{ and }
\pi_1^\Delta\ne\pi_2^\Delta\\
4,\ \{s(M),s(R)\}=\{A_i,A_{i+2}\}&\text{never}.
\end{array}
\tag{6}
\]

Condition (5)--(6) is the exact additional signature needed for alternative
(b).  The hypotheses concerning only \(M,Q\) do not contain it: they give
neither existence of a third matching \(R\) nor its root-marked complement
quotient.  Hence the four-port transfer data prove neither the proposed
general dichotomy nor an actual legal-wide brace counterexample.  They
strictly close the local-transfer route: under the stated closed-component
hypothesis, (a) fails identically, and the assertion is equivalent to the
independent existence of the escape signature (5)--(6).
