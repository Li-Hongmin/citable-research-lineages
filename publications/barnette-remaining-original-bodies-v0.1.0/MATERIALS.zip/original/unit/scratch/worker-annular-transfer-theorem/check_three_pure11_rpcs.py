#!/usr/bin/env python3
"""Check RPCS_11 on exactly three frozen through-26 pure-11--11 hits."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[1]
BASE_PATH = (
    BARNETTE
    / "computations"
    / "bundles"
    / "rooted-split-bond-through26"
    / "classify_through26_nonsquare_kill_cover.py"
)
PAYLOAD_PATH = BASE_PATH.with_name("through26_nonsquare_kill_cover.json")


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


base = load_module(BASE_PATH, "pure11_rpcs_base")
edge = base.edge

SOURCE24 = "W???????????w?s?P_BC?Go?B_?R??W_?SG?CB??@g??B_?"
SOURCE26 = "Y?????????????w?Y?CW??w??[?EC?T??_W?D@??AK?@_O?GK??SA???"

IDENTITIES = (
    {
        "name": "n24-site-0_13-3_20",
        "source_graph6": SOURCE24,
        "root": (10, 23),
        "forced_gate": (11, 21),
        "surviving_gate": (6, 17),
        "selected": frozenset((edge(0, 13), edge(3, 20))),
    },
    {
        "name": "n24-site-8_18-9_22",
        "source_graph6": SOURCE24,
        "root": (10, 23),
        "forced_gate": (11, 21),
        "surviving_gate": (1, 15),
        "selected": frozenset((edge(8, 18), edge(9, 22))),
    },
    {
        "name": "n26-site-3_25-11_21",
        "source_graph6": SOURCE26,
        "root": (1, 14),
        "forced_gate": (0, 13),
        "surviving_gate": (8, 19),
        "selected": frozenset((edge(3, 25), edge(11, 21))),
    },
)


def matching_key(matching):
    return tuple(sorted(matching))


def reconstruct_faces(graph: nx.Graph):
    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    faces = base.source.plane_faces(graph, embedding)
    base.validate_faces(graph, faces)
    return faces


def locate_hit(payload, identity):
    records = []
    for hit in payload["hits"]:
        if hit["source_graph6"] != identity["source_graph6"]:
            continue
        if tuple(hit["root"]) != identity["root"]:
            continue
        if tuple(hit["forced_gate"]) != identity["forced_gate"]:
            continue
        if tuple(hit["surviving_gate"]) != identity["surviving_gate"]:
            continue
        selected = frozenset(edge(*item) for item in hit["site"]["selected"])
        if selected != identity["selected"]:
            continue
        records.append(hit)
    assert len(records) == 1, (identity, len(records))
    return records[0]


def is_perfect_matching(graph: nx.Graph, matching) -> bool:
    degree = {vertex: 0 for vertex in graph}
    for left, right in matching:
        if not graph.has_edge(left, right):
            return False
        degree[left] += 1
        degree[right] += 1
    return set(degree.values()) == {1}


def check_hit(payload, identity):
    hit = locate_hit(payload, identity)
    graph = nx.from_graph6_bytes(identity["source_graph6"].encode())
    faces = reconstruct_faces(graph)
    root = edge(*identity["root"])
    forced = edge(*identity["forced_gate"])
    gate = edge(*identity["surviving_gate"])
    selected = tuple(edge(*item) for item in hit["site"]["selected"])
    assert frozenset(selected) == identity["selected"]
    site_candidates = tuple(
        site
        for site in base.facial_sites(graph, faces, frozenset())
        if frozenset(site["selected"]) == identity["selected"]
    )
    assert len(site_candidates) == 1
    site = site_candidates[0]
    selected = tuple(site["selected"])

    matchings = tuple(sorted(base.enumerate_perfect_matchings(graph), key=matching_key))
    fibre = tuple(
        matching
        for matching in matchings
        if base.is_root_target(graph, matching, root, forced)
    )
    sectors = (
        tuple(matching for matching in fibre if gate not in matching),
        tuple(matching for matching in fibre if gate in matching),
    )
    bonds = tuple(
        (first, second)
        for first in sectors[0]
        for second in sectors[1]
        if base.difference_component_count(first, second) == 1
    )
    l11 = frozenset(
        matching
        for matching in fibre
        if selected[0] in matching and selected[1] in matching
    )
    assert bonds
    assert all(first in l11 and second in l11 for first, second in bonds)
    endpoints = tuple(sorted({item for pair in bonds for item in pair}, key=matching_key))

    child, _, local = base.expand_on_face(graph, faces, site)
    _, ab, _, _, cd, _, _, _ = local
    r_patch = frozenset((ab, cd))

    endpoint_records = []
    for endpoint in endpoints:
        cycle_candidates = []
        root_retaining_candidates = []
        suppliers = []
        for supplier in matchings:
            if any(site_edge in supplier for site_edge in selected):
                continue
            difference = endpoint ^ supplier
            if base.difference_component_count(endpoint, supplier) != 1:
                continue
            cycle_candidates.append((supplier, len(difference)))
            if root not in supplier:
                continue
            root_retaining_candidates.append((supplier, len(difference)))
            child_r = supplier | r_patch
            assert is_perfect_matching(child, child_r)
            assert base.local_cell(child_r, local) == "R00"
            if base.is_root_target(child, child_r, root, forced):
                suppliers.append((supplier, len(difference)))

        fibre_index = fibre.index(endpoint)
        incident_bonds = sum(endpoint in pair for pair in bonds)
        endpoint_records.append(
            {
                "fibre_index": fibre_index,
                "sector": int(gate in endpoint),
                "incident_pure11_bonds": incident_bonds,
                "pq_one_cycle_candidates": len(cycle_candidates),
                "root_retaining_candidates": len(root_retaining_candidates),
                "rpcs_suppliers": len(suppliers),
                "minimum_supplier_cycle_length": (
                    min(length for _, length in suppliers) if suppliers else None
                ),
                "supplier_cycle_length_histogram": {
                    str(length): sum(item_length == length for _, item_length in suppliers)
                    for length in sorted({item_length for _, item_length in suppliers})
                },
                "supplier_matching_indices": [
                    matchings.index(supplier) for supplier, _ in suppliers
                ],
            }
        )

    record_by_matching = {
        endpoint: record for endpoint, record in zip(endpoints, endpoint_records)
    }
    bond_records = []
    for first, second in bonds:
        first_record = record_by_matching[first]
        second_record = record_by_matching[second]
        counts = (first_record["rpcs_suppliers"], second_record["rpcs_suppliers"])
        bond_records.append(
            {
                "endpoint_fibre_indices": [
                    first_record["fibre_index"],
                    second_record["fibre_index"],
                ],
                "endpoint_supplier_counts": list(counts),
                "bond_has_rpcs": any(counts),
            }
        )
    distinct_supplier_indices = sorted(
        {
            index
            for record in endpoint_records
            for index in record["supplier_matching_indices"]
        }
    )

    assert len(fibre) == hit["parent_fibre_size"]
    assert len(bonds) == hit["parent_crossings"]
    assert len(l11) == len(hit["parent_L11_indices"])
    return {
        "name": identity["name"],
        "parent_order": graph.number_of_nodes(),
        "source_graph6": identity["source_graph6"],
        "root": list(root),
        "forced_gate": list(forced),
        "surviving_gate": list(gate),
        "site": [list(item) for item in sorted(identity["selected"])],
        "parent_perfect_matchings": len(matchings),
        "parent_fibre_size": len(fibre),
        "parent_pure11_bonds": len(bonds),
        "parent_L11_size": len(l11),
        "bond_endpoint_fibre_indices": [record["fibre_index"] for record in endpoint_records],
        "bonds": bond_records,
        "endpoints": endpoint_records,
        "rpcs_endpoint_incidence_count": sum(
            record["rpcs_suppliers"] for record in endpoint_records
        ),
        "distinct_rpcs_supplier_matchings": len(distinct_supplier_indices),
        "distinct_rpcs_supplier_matching_indices": distinct_supplier_indices,
        "site_has_rpcs": any(record["rpcs_suppliers"] for record in endpoint_records),
        "every_bond_has_rpcs": all(record["bond_has_rpcs"] for record in bond_records),
        "all_endpoints_have_rpcs": all(record["rpcs_suppliers"] for record in endpoint_records),
        "site_minimum_supplier_cycle_length": min(
            record["minimum_supplier_cycle_length"]
            for record in endpoint_records
            if record["minimum_supplier_cycle_length"] is not None
        ),
    }


def main():
    payload = json.loads(PAYLOAD_PATH.read_text())
    results = [check_hit(payload, identity) for identity in IDENTITIES]
    all_sites_have_rpcs = all(record["site_has_rpcs"] for record in results)
    print(
        json.dumps(
            {
                "scope": "exactly three frozen through-26 pure-11--11 eligible hits",
                "sites": results,
                "all_three_sites_have_rpcs": all_sites_have_rpcs,
                "all_endpoints_have_rpcs": all(
                    record["all_endpoints_have_rpcs"] for record in results
                ),
            },
            indent=2,
            sort_keys=True,
        )
    )
    print(
        "THREE_FROZEN_PURE11_RPCS_VERIFIED"
        if all_sites_have_rpcs
        else "FROZEN_PURE11_RPCS_ROUTE_COUNTEREXAMPLE"
    )


if __name__ == "__main__":
    main()
