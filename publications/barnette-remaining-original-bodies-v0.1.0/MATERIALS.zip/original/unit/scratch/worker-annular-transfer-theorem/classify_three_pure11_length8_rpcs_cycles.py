#!/usr/bin/env python3
"""Classify length-8 RPCS cycles on exactly three frozen pure-11 sites."""

from __future__ import annotations

from collections import Counter, defaultdict
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
CHECK_PATH = HERE / "check_three_pure11_rpcs.py"


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


check = load_module(CHECK_PATH, "pure11_rpcs_check")
base = check.base
edge = base.edge


def face_incidence(graph: nx.Graph, faces):
    incidence = defaultdict(list)
    for face_index, face in enumerate(faces):
        for item in base.face_edges(face):
            incidence[item].append(face_index)
    assert set(incidence) == {edge(*item) for item in graph.edges()}
    assert all(len(indices) == 2 for indices in incidence.values())
    return {item: tuple(indices) for item, indices in incidence.items()}


def cycle_sides(graph: nx.Graph, faces, cycle_edges):
    incidence = face_incidence(graph, faces)
    dual = nx.Graph()
    dual.add_nodes_from(range(len(faces)))
    for primal_edge, (left, right) in incidence.items():
        if primal_edge not in cycle_edges:
            dual.add_edge(left, right)
    components = tuple(frozenset(component) for component in nx.connected_components(dual))
    assert len(components) == 2, components
    return components, incidence


def region_boundary(faces, region):
    parity = Counter()
    for face_index in region:
        for item in base.face_edges(faces[face_index]):
            parity[item] ^= 1
    return frozenset(item for item, value in parity.items() if value)


def mark_position(mark, cycle_edges, incidence, site_side):
    if mark in cycle_edges:
        return "cycle"
    mark_faces = frozenset(incidence[mark])
    assert mark_faces <= site_side or mark_faces.isdisjoint(site_side)
    return "site_side" if mark_faces <= site_side else "opposite_side"


def site_region_description(faces, site_face_index, site_side, incidence, marks):
    internal_dual = nx.Graph()
    internal_dual.add_nodes_from(site_side)
    for primal_edge, (left, right) in incidence.items():
        if left in site_side and right in site_side:
            internal_dual.add_edge(left, right, primal_edge=primal_edge)

    added = []
    site_boundary = frozenset(base.face_edges(faces[site_face_index]))
    for face_index in sorted(site_side - {site_face_index}):
        boundary = frozenset(base.face_edges(faces[face_index]))
        added.append(
            {
                "face_index": face_index,
                "face_length": len(faces[face_index]),
                "shared_site_edges": [list(item) for item in sorted(boundary & site_boundary)],
                "contained_marks": sorted(
                    name for name, item in marks.items() if item in boundary
                ),
            }
        )

    return {
        "face_count": len(site_side),
        "face_indices": sorted(site_side),
        "face_length_histogram": {
            str(length): count
            for length, count in sorted(Counter(len(faces[index]) for index in site_side).items())
        },
        "dual_edges": sorted([list(item) for item in internal_dual.edges()]),
        "dual_is_tree": nx.is_tree(internal_dual),
        "site_face_internal_degree": internal_dual.degree(site_face_index),
        "added_faces": added,
    }


def analyse_identity(payload, identity):
    hit = check.locate_hit(payload, identity)
    graph = nx.from_graph6_bytes(identity["source_graph6"].encode())
    faces = check.reconstruct_faces(graph)
    root = edge(*identity["root"])
    forced = edge(*identity["forced_gate"])
    gate = edge(*identity["surviving_gate"])
    site_candidates = tuple(
        site
        for site in base.facial_sites(graph, faces, frozenset())
        if frozenset(site["selected"]) == identity["selected"]
    )
    assert len(site_candidates) == 1
    site = site_candidates[0]
    selected = tuple(site["selected"])
    site_face_index = int(site["face_index"])

    matchings = tuple(sorted(base.enumerate_perfect_matchings(graph), key=check.matching_key))
    fibre = tuple(
        matching
        for matching in matchings
        if base.is_root_target(graph, matching, root, forced)
    )
    sectors = (
        tuple(matching for matching in fibre if gate not in matching),
        tuple(matching for matching in fibre if gate in matching),
    )
    bonds = tuple(
        (first, second)
        for first in sectors[0]
        for second in sectors[1]
        if base.difference_component_count(first, second) == 1
    )
    l11 = frozenset(
        matching
        for matching in fibre
        if selected[0] in matching and selected[1] in matching
    )
    assert bonds and all(first in l11 and second in l11 for first, second in bonds)
    endpoints = tuple(sorted({item for pair in bonds for item in pair}, key=check.matching_key))

    child, _, local = base.expand_on_face(graph, faces, site)
    _, ab, _, _, cd, _, _, _ = local
    r_patch = frozenset((ab, cd))
    marks = {
        "root": root,
        "forced_gate": forced,
        "surviving_gate": gate,
        "site_0": selected[0],
        "site_1": selected[1],
    }

    incidence = face_incidence(graph, faces)
    site_boundary_ordered = tuple(base.face_edges(faces[site_face_index]))
    selected_positions = tuple(
        index for index, item in enumerate(site_boundary_ordered) if item in selected
    )
    assert len(site_boundary_ordered) == 6
    assert len(selected_positions) == 2
    assert selected_positions[0] % 2 == selected_positions[1] % 2
    third_alternating_edges = tuple(
        item
        for index, item in enumerate(site_boundary_ordered)
        if index % 2 == selected_positions[0] % 2 and item not in selected
    )
    assert len(third_alternating_edges) == 1
    shared_edge = third_alternating_edges[0]
    square_face_index = next(
        index for index in incidence[shared_edge] if index != site_face_index
    )
    assert len(faces[square_face_index]) == 4
    template_cycle = (
        frozenset(site_boundary_ordered)
        ^ frozenset(base.face_edges(faces[square_face_index]))
    )
    assert len(template_cycle) == 8

    witnesses = []
    for endpoint in endpoints:
        for supplier in matchings:
            if any(item in supplier for item in selected):
                continue
            difference = endpoint ^ supplier
            if len(difference) != 8:
                continue
            if base.difference_component_count(endpoint, supplier) != 1:
                continue
            if root not in supplier:
                continue
            child_r = supplier | r_patch
            assert check.is_perfect_matching(child, child_r)
            assert base.local_cell(child_r, local) == "R00"
            if not base.is_root_target(child, child_r, root, forced):
                continue

            cycle_graph = nx.Graph()
            cycle_graph.add_edges_from(difference)
            assert nx.is_connected(cycle_graph)
            assert set(dict(cycle_graph.degree()).values()) == {2}
            sides, incidence = cycle_sides(graph, faces, difference)
            site_side = next(side for side in sides if site_face_index in side)
            opposite_side = next(side for side in sides if side != site_side)
            assert region_boundary(faces, site_side) == difference
            assert region_boundary(faces, opposite_side) == difference

            mark_positions = {
                name: mark_position(item, difference, incidence, site_side)
                for name, item in marks.items()
            }
            witnesses.append(
                {
                    "endpoint_fibre_index": fibre.index(endpoint),
                    "endpoint_sector": int(gate in endpoint),
                    "supplier_matching_index": matchings.index(supplier),
                    "supplier_sector": int(gate in supplier),
                    "cycle_edges": [list(item) for item in sorted(difference)],
                    "mark_positions": mark_positions,
                    "site_side": site_region_description(
                        faces, site_face_index, site_side, incidence, marks
                    ),
                    "opposite_side_face_count": len(opposite_side),
                    "site_side_is_smaller": len(site_side) <= len(opposite_side),
                }
            )

    assert witnesses
    assert all(frozenset(map(tuple, witness["cycle_edges"])) == template_cycle for witness in witnesses)
    endpoint_template_tests = []
    for endpoint in endpoints:
        candidate = endpoint ^ template_cycle
        alternating = check.is_perfect_matching(graph, candidate)
        root_retained = bool(alternating and root in candidate)
        child_root_admitted = False
        if alternating:
            child_r = candidate | r_patch
            assert check.is_perfect_matching(child, child_r)
            assert base.local_cell(child_r, local) == "R00"
            child_root_admitted = base.is_root_target(child, child_r, root, forced)
        endpoint_template_tests.append(
            {
                "endpoint_fibre_index": fibre.index(endpoint),
                "template_cycle_is_alternating": alternating,
                "root_retained": root_retained,
                "r00_child_root_admitted": child_root_admitted,
            }
        )
    return {
        "name": identity["name"],
        "site_face_index": site_face_index,
        "site_face": list(faces[site_face_index]),
        "root": list(root),
        "forced_gate": list(forced),
        "surviving_gate": list(gate),
        "site": [list(item) for item in selected],
        "fixed_local_template": {
            "third_alternating_shared_edge": list(shared_edge),
            "adjacent_square_face_index": square_face_index,
            "adjacent_square_face": list(faces[square_face_index]),
            "cycle_edges": [list(item) for item in sorted(template_cycle)],
            "endpoint_tests": endpoint_template_tests,
        },
        "length8_witnesses": witnesses,
    }


def coarse_template(witness):
    side = witness["site_side"]
    return (
        side["face_count"],
        tuple(sorted(side["face_length_histogram"].items())),
        side["dual_is_tree"],
        side["site_face_internal_degree"],
        tuple(sorted(witness["mark_positions"].items())),
    )


def main():
    payload = json.loads(check.PAYLOAD_PATH.read_text())
    sites = [analyse_identity(payload, identity) for identity in check.IDENTITIES]
    templates = defaultdict(list)
    for site in sites:
        for witness in site["length8_witnesses"]:
            templates[coarse_template(witness)].append(
                (site["name"], witness["endpoint_fibre_index"], witness["supplier_matching_index"])
            )
    output = {
        "scope": "all length-8 RPCS witnesses on exactly three frozen pure-11 sites",
        "sites": sites,
        "coarse_template_count": len(templates),
        "coarse_templates": [
            {
                "signature": {
                    "site_side_face_count": key[0],
                    "site_side_face_length_histogram": dict(key[1]),
                    "site_side_dual_is_tree": key[2],
                    "site_face_internal_degree": key[3],
                    "mark_positions": dict(key[4]),
                },
                "witnesses": values,
            }
            for key, values in templates.items()
        ],
    }
    print(json.dumps(output, indent=2, sort_keys=True))
    print("THREE_FROZEN_PURE11_LENGTH8_RPCS_CLASSIFIED")


if __name__ == "__main__":
    main()
