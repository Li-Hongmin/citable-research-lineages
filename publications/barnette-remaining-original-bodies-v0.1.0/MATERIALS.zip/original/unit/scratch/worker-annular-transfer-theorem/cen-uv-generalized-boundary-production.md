# The six defect classes are closed under CEN and UV boundary production

This is a local restriction--extension theorem for the standard patch

\[
E_J=\{ua,ab,bv,xc,cd,dy,ad,bc\}.
\tag{1}
\]

It concerns boundary rows and pair atoms only.  No exterior graph is
enumerated.

## 1. Generalized patch rows

Write

\[
\mathcal D=\{0,uv,xy,uvxy,uy,vx\}
\tag{2}
\]

for the six current exterior defect classes.  Let \(H'\) be one of the six
defect sets at a named next site \((p',q')\).  Boundary rows live in the
graph with the two next-site edges deleted.  A generalized patch row is
therefore a matching satisfying

\[
P\subseteq E_J\setminus\{p',q'\},\qquad
V(P)\cap\{a,b,c,d\}
=\{a,b,c,d\}\setminus H',
\qquad
V(P)\cap H'=\varnothing.
\tag{3}
\]

Thus every new patch vertex which is not a next-site hole is matched once,
every new hole is unmatched, and an old next-site hole is not used by the
patch.  The old exterior defect forced by \((H',P)\) is

\[
D(H',P)=
\bigl(V(P)\cap\{u,v,x,y\}\bigr)
\mathbin{\dot\cup}
\bigl(H'\cap\{u,v,x,y\}\bigr).
\tag{4}
\]

The union is disjoint by (3).  An exterior row of class \(D(H',P)\) and the
patch row \(P\) together match every child vertex outside \(H'\) exactly
once.

## 2. CEN production table

For

\[
\mathrm{CEN}=(bc,da),
\qquad
(U',V',X',Y')=(b,c,d,a),
\tag{5}
\]

the six next defect sets are

\[
0,\ bc,\ da,\ abcd,\ ab,\ cd.
\]

All generalized patch rows and their old defects are:

\[
\begin{array}{c|c|c}
\text{next class}&H'& (D(H',P),P)\\ \hline
0&0&
(0,ab\,cd),\ (uv,ua\,bv\,cd),\ (xy,ab\,xc\,dy),\\
&& (uvxy,ua\,bv\,xc\,dy)\\[1mm]
uv&bc&(uy,ua\,dy)\\
xy&da&(vx,bv\,xc)\\
uvxy&abcd&(0,\varnothing)\\
uy&ab&(0,cd),\ (xy,xc\,dy)\\
vx&cd&(0,ab),\ (uv,ua\,bv).
\end{array}
\tag{6}
\]

The four zero-defect rows are exactly the ordinary child patch matchings
which avoid both CEN edges.  A child matching using \(bc\), \(da\), or both
moves after deletion to the corresponding canonical defect row below.

## 3. UV production table

For

\[
\mathrm{UV}=(ua,bv),
\qquad
(U',V',X',Y')=(u,a,b,v),
\tag{7}
\]

the six next defect sets are

\[
0,\ ua,\ bv,\ uabv,\ uv,\ ab.
\]

The complete table is

\[
\begin{array}{c|c|c}
\text{next class}&H'& (D(H',P),P)\\ \hline
0&0&
(0,ab\,cd),\ (xy,ab\,xc\,dy),\ (0,ad\,bc)\\[1mm]
uv&ua&(uy,dy\,bc)\\
xy&bv&(vx,xc\,ad)\\
uvxy&uabv&(uv,cd),\ (uvxy,xc\,dy)\\
uy&uv&(uv,ab\,cd),\ (uvxy,ab\,xc\,dy),\ (uv,ad\,bc)\\
vx&ab&(0,cd),\ (xy,xc\,dy).
\end{array}
\tag{8}
\]

In particular, when a UV next defect uses one old endpoint and one new
endpoint, the old defect (4) includes both the old next-hole and every old
endpoint matched into the patch.  This is why the source class can be
\(uvxy\), not just the visibly corresponding two-defect class.

## 4. Restriction of the seven child perfect matchings

Deleting the selected next-site edges from the ordinary seven patch
matchings gives

\[
\begin{array}{c|cc|cc}
&\multicolumn{2}{c|}{\mathrm{CEN}:\{bc,da\}}&
 \multicolumn{2}{c}{\mathrm{UV}:\{ua,bv\}}\\
\text{cell}&\text{next class}&P&\text{next class}&P\\ \hline
R_{00}&0&ab\,cd&0&ab\,cd\\
C_{10}&0&ua\,bv\,cd&uvxy&cd\\
C_{01}&0&ab\,xc\,dy&0&ab\,xc\,dy\\
C_{11}&0&ua\,bv\,xc\,dy&uvxy&xc\,dy\\
X_{uy}&uv&ua\,dy&uv&dy\,bc\\
X_{vx}&xy&bv\,xc&xy&xc\,ad\\
C_{00}&uvxy&\varnothing&0&ad\,bc.
\end{array}
\tag{9}
\]

Thus a child perfect matching which uses one or both next-site edges enters
the corresponding two- or four-defect boundary class after deletion; it
does not remain in the zero-defect class.

## 5. Exhaustiveness

Fix \(H'\).  A patch edge set satisfying (3) is a matching which saturates
the prescribed subset of \(\{a,b,c,d\}\).  Inspect the mate of \(a\) when
\(a\notin H'\): it is one of \(u,b,d\), after which the mate choices at the
remaining required new vertices are forced or form the two explicitly
listed alternatives.  If \(a\in H'\), inspect \(b\), then \(c,d\).
Rejecting either selected next-site edge and every edge incident with an old
hole leaves exactly the rows in (6) and (8).  The row counts are

\[
\begin{array}{c|rrrrrr}
&0&uv&xy&uvxy&uy&vx\\ \hline
\mathrm{CEN}&4&1&1&1&2&2\\
\mathrm{UV}&3&1&1&2&3&2.
\end{array}
\tag{10}
\]

This proves directly, without an exterior graph, that every source defect
in (6) and (8) belongs to \(\mathcal D\).

## 6. Restriction--extension bijection

Let \(R'\) be any child boundary row in one of the six next defect classes.
Its restriction to \(E_J\) is a unique matching \(P\).  Degree one at every
non-hole patch vertex and degree zero at every next hole give (3).  The
restriction of \(R'\) to the old exterior leaves precisely the defect set
(4), so (6) or (8) places it in a unique listed source row.

Conversely, let \(r\) be any old exterior row in the listed source class
and let \(P\) be the corresponding generalized patch row.  Equation (4)
ensures that the old vertices used by \(P\) are exactly the non-next-hole
vertices left unmatched by \(r\); (3) handles the patch vertices.  Hence

\[
r\mathbin{\dot\cup}P
\tag{11}
\]

is a child matching with exactly the desired next defect.  Restriction and
extension are inverse.  Therefore (6) and (8) generate the complete six
next-boundary row classes, including cross-hole rows which have no child-PM
ancestor.

If the current patch straddles an annular interface, each source row in
(11) is assembled only from factor rows satisfying the colour-defect
balance

\[
|U_F\cap A|+|H_F\cap A|
=|U_F\cap B|+|H_F\cap B|.
\tag{12}
\]

Because every global source defect in the tables lies in \(\mathcal D\),
no seventh exterior defect class is needed.  Equation (12) merely selects
the legal connector subset, including one- and three-connector states when
a two-defect row is split between the factors.

## 7. Transport of row and pair atoms

For a table entry \((D,P)\), join the old row deletion atom with the fixed
local complement partition of the generalized patch row:

\[
\delta_{\rm next}(r,P)
=\delta_{p,q}(r)\vee J^c_{P,H'}.
\tag{13}
\]

The next-site stubs remain marked rather than being removed.  Component
counts, ordered roots and gate marks are inherited under the partition
join.  By the bijection above, (13) gives every next row atom exactly once.

For two next rows \((r,P)\), \((s,Q)\), their old restrictions belong to
two classes in \(\mathcal D\), so the current state contains their full pair
atom \(\varepsilon_{p,q}(r,s)\).  Their next pair atom is

\[
\varepsilon_{\rm next}((r,P),(s,Q))
=\varepsilon_{p,q}(r,s)
 \vee J^{\triangle}_{P,Q;H',H''},
\tag{14}
\]

where the fixed local partition on the right is the symmetric difference
of the two generalized patch rows, with both sets of next-hole stubs
retained.  Restricting an actual pair gives the two terms in (14);
extending them joins exactly the common site stubs.  Thus (14) is both
necessary and sufficient and reconstructs every pair atom, not only the
Boolean bond graph.

## 8. Conclusion

The six exterior defect classes (2), equipped with all row atoms
\(\delta_{p,q}\) and all pair atoms \(\varepsilon_{p,q}\), are strictly
closed under either deterministic next-site choice CEN or UV.  The ordinary
seven child perfect-matching rows are not enough for this conclusion; the
additional generalized patch partial matchings in (6) and (8) are essential.
No extra exterior defect class and no higher-arity incidence datum is
required for this one local transition.
