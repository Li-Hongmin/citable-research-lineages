#!/usr/bin/env python3
"""Generate the independently checkable finite local tables T0 and j0."""

import csv
from pathlib import Path
from row_engine import LOCAL, NEW, OUT_DELETED, local_masks

HERE = Path(__file__).resolve().parent


def signature(mask, removed=()):
    removed = frozenset(removed)
    deg = {q: 0 for q in ("u", "v", "x", "y", "r0", "r1", "a", "b", "c", "d")}
    joins = []
    for p, q, name in LOCAL:
        if name in mask and name not in removed:
            deg[p] += 1
            deg[q] += 1
            joins.append(f"{p}{q}")
    return deg, ",".join(joins) or "-"


def main():
    names = [e[2] for e in LOCAL]
    trows = []
    jrows = []
    for i, mask in enumerate(local_masks()):
        full_deg, full_join = signature(mask)
        out_deg, out_join = signature(mask, OUT_DELETED)
        base = {"id": i, "mask": ",".join(sorted(mask)) or "-"}
        jrows.append(base | {
            "new_degree": ",".join(f"{q}:{full_deg[q]}" for q in NEW),
            "old_increment": ",".join(f"{q}:{full_deg[q]}" for q in full_deg if q not in NEW),
            "joins": full_join,
        })
        trows.append(base | {
            "new_degree_after_cut": ",".join(f"{q}:{out_deg[q]}" for q in NEW),
            "old_increment_after_cut": ",".join(f"{q}:{out_deg[q]}" for q in out_deg if q not in NEW),
            "joins_after_cut": out_join,
            "cut_ua": int("ua" in mask), "cut_r": int("r" in mask),
        })
    for name, rows in (("j0.tsv", jrows), ("T0.tsv", trows)):
        with (HERE / name).open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=rows[0], delimiter="\t")
            w.writeheader(); w.writerows(rows)
    assert len(trows) == len(jrows) == 512
    assert len({r["mask"] for r in trows}) == 512
    print("R3_PULSE1_ATOMIC_TABLES_VERIFIED rows=512")


if __name__ == "__main__":
    main()
