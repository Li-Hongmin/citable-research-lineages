#!/usr/bin/env python3
"""Cross-check sigma0, T0 and j0 on certified small legal histories.

This is not an adjacent-order census.  It checks only depth 0 and the fixed
depth-1 record, and every tested operation has a directly verified legal
successor (u,a,r0,r1).
"""

from itertools import combinations
import networkx as nx
from row_engine import OLD, BORN, Row, accepting_full, canon_partition, glue, local_masks


def cube():
    return nx.Graph([(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7)])


def expand(G, site):
    u,v,x,y = site
    H=G.copy(); H.remove_edges_from(((u,v),(x,y)))
    a,b,c,d=range(max(H)+1,max(H)+5)
    H.add_edges_from(((u,a),(a,b),(b,v),(x,c),(c,d),(d,y),(a,d),(b,c)))
    return H,(a,b,c,d)


def faces(G):
    ok, emb=nx.check_planarity(G); assert ok
    seen=set(); out=[]
    for p,q in emb.edges():
        if (p,q) not in seen: out.append(tuple(emb.traverse_face(p,q,seen)))
    return out


def legal_sites(G):
    col=nx.bipartite.color(G); ans=set()
    for face in faces(G):
        for cyc in (face,tuple(reversed(face))):
            es=[(cyc[i],cyc[(i+1)%len(cyc)]) for i in range(len(cyc))]
            for p,q in combinations(range(len(es)),2):
                for i,j in ((p,q),(q,p)):
                    u,v=es[i]; x,y=es[j]
                    if len({u,v,x,y})==4 and col[u]==col[x]: ans.add((u,v,x,y))
    return ans


def edge(p,q): return tuple(sorted((p,q)))


def subgraphs_with_degrees(G, boundary):
    """All edge sets: degree 2 off boundary, degree <=2 on boundary."""
    es=[edge(*e) for e in G.edges()]; inc={v:[] for v in G}
    for i,(p,q) in enumerate(es): inc[p].append(i); inc[q].append(i)
    deg={v:0 for v in G}; picked=[]; out=[]
    def rec(i):
        if i==len(es):
            if all(deg[v]==2 or (v in boundary and deg[v]<=2) for v in G): out.append(frozenset(picked))
            return
        p,q=es[i]
        # Exclude, pruning vertices whose last incident edge has passed.
        if all(not (max(inc[v])==i and v not in boundary and deg[v]!=2) for v in (p,q)):
            rec(i+1)
        if deg[p]<2 and deg[q]<2:
            deg[p]+=1; deg[q]+=1; picked.append(es[i]); rec(i+1); picked.pop(); deg[p]-=1; deg[q]-=1
    rec(0); return out


def row_of(G, subset, roles, boundary, e, f):
    H=nx.Graph(); H.add_nodes_from(G); H.add_edges_from(subset)
    blocks=[]; touched=set()
    for comp in nx.connected_components(H):
        hit={q for q in boundary if roles[q] in comp}
        if hit: blocks.append(hit); touched |= hit
    # Isolated boundary roles are already components because all vertices retained.
    z=sum(not any(roles[q] in comp for q in boundary) for comp in nx.connected_components(H))
    return Row(tuple(H.degree(roles[q]) for q in boundary),canon_partition(blocks),min(2,z),int(e in subset),int(f in subset))


def check_context(G, site, retained, label):
    u,v,x,y=site; r0,r1=retained
    H,(a,b,c,d)=expand(G,site)
    assert (u,a,r0,r1) in legal_sites(H)
    assert all(q==3 for _,q in H.degree()) and nx.is_bipartite(H) and nx.node_connectivity(H)>=3
    roles=dict(zip(OLD,(u,v,x,y,r0,r1))) | dict(zip(("a","b","c","d"),(a,b,c,d)))
    controlled={edge(u,v),edge(x,y),edge(r0,r1)}
    X=G.copy(); X.remove_edges_from(controlled)
    ext_sets=subgraphs_with_degrees(X,set(roles[q] for q in OLD))
    born_name={edge(roles[p],roles[q]):name for p,q,name in BORN}
    local_name=born_name | {edge(r0,r1):"r"}
    targets=sorted(edge(*e0) for e0 in H.edges())
    # A deterministic broad sample, including external, born and retained targets.
    pairs=[(targets[i],targets[j]) for i in range(len(targets)) for j in range(len(targets)) if i!=j and (i*37+j*11)%29==0]
    out_graph=H.copy(); out_graph.remove_edges_from((edge(u,a),edge(r0,r1)))
    out_sets=subgraphs_with_degrees(out_graph,{u,a,r0,r1})
    for e,f in pairs:
        ext_rows={row_of(X,S,roles,OLD,e,f) for S in ext_sets}
        le,lf=local_name.get(e),local_name.get(f)
        predicted_out={q for row in ext_rows for mask in local_masks() if (q:=glue(row,mask,(le,lf),True)) is not None}
        direct_out={row_of(out_graph,S,roles,("u","a","r0","r1"),e,f) for S in out_sets}
        assert predicted_out==direct_out
        predicted_accept=any(accepting_full(q) for row in ext_rows for mask in local_masks() if (q:=glue(row,mask,(le,lf),False)) is not None)
        direct_accept=any(nx.is_connected(nx.Graph(list(S))) and e in S and f not in S for S in subgraphs_with_degrees(H,set()))
        assert predicted_accept==direct_accept
    print(f"REAL_CONTEXT_OK {label} vertices={len(G)} targets={len(targets)} pairs={len(pairs)} external_rows={len(ext_sets)}")


def main():
    Q=cube(); assert (0,1,2,3) in legal_sites(Q)
    Q1,born=expand(Q,(0,1,2,3)); assert born==(8,9,10,11)
    # Fixed certificate context.
    check_context(Q1,(0,3,11,8),(7,4),"fixed-depth-1")
    # A second genuine depth-zero context selected solely by legality.
    candidates=[]
    for r in Q.edges():
        if edge(*r) not in {edge(0,1),edge(2,3)} and (0,8,r[0],r[1]) in legal_sites(Q1): candidates.append(r)
        if edge(*r) not in {edge(0,1),edge(2,3)} and (0,8,r[1],r[0]) in legal_sites(Q1): candidates.append((r[1],r[0]))
    assert candidates
    check_context(Q,(0,1,2,3),candidates[0],"legal-depth-0")
    print("R3_PULSE1_REAL_CONTEXT_CROSSCHECK_VERIFIED")


if __name__=="__main__": main()
