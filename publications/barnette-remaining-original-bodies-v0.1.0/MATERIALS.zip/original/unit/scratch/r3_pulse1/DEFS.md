# Frozen definitions for Route 1, pulse 1

This file fixes the objects used in (P).  It follows §2.1--§2.2 of
`advisor/gpt6pro-2026-09-12-round7.md`; none of these definitions changes the
frozen SPEC.

## 1. The operation and its real domain

The structural roles are

\[
s=(u,v,x,y),\qquad r=(r_0,r_1).
\]

The fixed operation \(o^*\) deletes \(uv,xy\), creates fresh roles
\(a,b,c,d\), and creates, in this order,

\[
L=(ua,ab,bv,xc,cd,dy,ad,bc).
\]

It changes the marked site to

\[
s^+=(u,a,r_0,r_1),
\]

while retaining the old edge \(r_0r_1\).  The concrete frozen record is
\((u,v,x,y;r_0,r_1)=(0,3,11,8;7,4)\), but the definition is by roles, not by
these integers.

\(D_{o^*}\) is the set of all rooted inputs \(X=(G,s;r,e,f;\mu)\) occurring at
some stage of a complete legal-expansion certificate in \(\mathcal C_{4A}\)
for which: (i) \(s\) is the recorded legal ordered cofacial site; (ii) \(r\)
is an existing edge and the transported rotation/face/arcs certify that
\((u,a,r_0,r_1)\) is a legal site after the displayed expansion; (iii) the
ledger and target tokens \(e\ne f\) are complete.  No nesting condition is
imposed.  This is exactly the full real legal domain, including old-vertex
revisits.

## 2. Fourteen slots and frozen transport

The slots, in frozen order, are

\[
(u,v,x,y,r_0,r_1,e_0,e_1,f_0,f_1,a,b,c,d).
\]

The first ten are input slots and the last four are fresh output slots.  The
equality relation on slots is retained, so endpoint slots may alias structural
slots.  Arbitrary vertex numbers are never stored.

At output the successor-site renaming is

\[
(u^+,v^+,x^+,y^+)=(u,a,r_0,r_1).
\]

Roles \(v,x,y\) cease to be structural ports but remain only when aliased to a
target endpoint; \(b,c,d\) likewise remain only through such an alias.  The
target endpoint roles are transported unchanged.  There is no output
``next-retained'' edge: the output is tagged `successor-site phase`, whose
controlled edges are precisely \(ua,r_0r_1\).  A later operation requiring a
further retained edge must supply it in its own frozen input metadata.

## 3. Metadata eta

\(\eta(X)\) is the following finite record.

1. The equality relation on the fourteen slots and the incidence relation
   between role vertices and every named controlled/born/target edge.
2. For each target token \(e,f\), exactly one location tag:
   `external-existing`, one of `uv`, `xy`, `r`, one of the eight names in
   \(L\), `not-yet-born`, or `deleted`.  Its frozen birth layer and, if
   applicable, deletion layer/status are included.
3. The input/output phase, the bipartition colours of role classes up to the
   allowed global colour reversal, and the ordered site incidences.
4. The selected facial occurrence, its orientation up to simultaneous mirror,
   the positions of the role incidences on its two ordered arcs, and the
   association of \(r\) with the successor face/arcs.  Only the finite role
   order/incidence word is stored; unmarked vertices on an arbitrarily long
   arc are not stored.

This data is read only for legality, aliasing, target-location bits, and the
frozen rename/forget map.  Neither table reads an unmarked edge, an arc length,
a vertex number, or any other part of \(G\).

## 4. Controlled deletion and rows

In input phase let

\[
K_X=\{uv,xy,r_0r_1\},\qquad X_X=G-K_X,
\]

with every vertex retained.  The active role set \(B_X\) is the image of
\(u,v,x,y,r_0,r_1,e_0,e_1,f_0,f_1\) after equality quotient, omitting endpoint
slots whose target is not yet born.  In successor-site phase use
\(K^+=\{ua,r_0r_1\}\) and the image of
\(u,a,r_0,r_1,e_0,e_1,f_0,f_1\).

An exterior generator is a spanning subgraph \(F\subseteq X_X\) satisfying

\[
\deg_F(q)=2\ (q\notin B_X),\qquad 0\le\deg_F(q)\le2\ (q\in B_X).
\]

Its normalized row is

\[
\alpha(F)=(d,\pi,z,\beta_e,\beta_f),
\]

where: \(d\) is the degree (0,1,2) of every active role class in frozen order;
\(\pi\) is the complete connectivity partition of all active role classes,
including isolated classes; \(z=\min(2,c_0(F))\), where \(c_0\) counts
components disjoint from the active interface (necessarily closed cycles);
and \((\beta_e,\beta_f)\) records whether this same \(F\) uses the corresponding
external target edge.  A local, unborn, or deleted target is represented by
its location tag in \(\eta\), not by interpreting a zero bit as external
absence.

Finally

\[
R_X=\{\alpha(F):F\text{ is an exterior generator}\},\qquad
\sigma_0(X)=(\eta(X),R_X).
\]

Rows are sets, not multisets, and every row is jointly realized by one \(F\).
The value set is finite: there are at most ten input role classes, hence only
finitely many degree words, partitions, saturated counts, bits, and metadata
records.

## 5. The semantic output J-star and acceptance

For every spanning 2-factor \(H\subseteq G^+=\Phi_{o^*}(G)\), put

\[
\kappa(H)=(\alpha(H-K^+),\mathbf1_{ua\in H},
                 \mathbf1_{r_0r_1\in H}).
\]

The complete joint output is

\[
J^*(X)=\bigl(\{\kappa(H):H\subseteq G^+\text{ spanning 2-factor}\},A(X)\bigr),
\]

where \(A(X)=1\) iff one and the same such \(H\) is connected, contains \(e\),
and avoids \(f\).  Thus the finite interface type and the joint
required/forbidden/connection truth value are fixed before computation.
Because a finite spanning 2-regular subgraph is connected iff it is one cycle,
\(A(X)=1\) is exactly the required Hamilton-cycle contain/avoid predicate.
