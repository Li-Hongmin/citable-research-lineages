# Restriction--gluing proof and finite tables

## Atomic tables

Let \(L'=L\cup\{r_0r_1\}\).  `j0.tsv` and `T0.tsv` contain all \(2^9=512\)
subsets \(P\subseteq L'\), in a fixed order.  Each row gives its degree
increments and component joins.  `j0.tsv` uses all of \(P\); `T0.tsv` first
cuts \(ua,r_0r_1\), records their two selection bits, and uses
\(P\setminus K^+\).  Target-use bits are obtained by OR of the exterior bit
and the bit of the uniquely tagged local target.  Slot aliases are quotient
identifications prescribed by \(\eta\); target-only slots on which no local
edge is incident pass through unchanged.

For an input row \(\alpha=(d,\pi,z,\beta_e,\beta_f)\), a table row is legal
exactly when adding its displayed degree increments gives degree two at every
non-output role and a value in \(\{0,1,2\}\) at every output role.  Join the
blocks of \(\pi\) by the displayed local edges.  Blocks missing the output
interface become closed components and are added to \(z\), saturated at 2;
the remaining blocks give the normalized output partition.  This is the
complete finite atomic rule, not a graph query.

The set maps are

\[
T_0(\eta,R)=(\eta^+,\{t(\alpha,P):\alpha\in R, P\subseteq L',
t(\alpha,P)\text{ legal}\}),
\]

and \(j_0\) is the analogous union of the full-gluing atoms, grouped by the
two cut-edge bits to produce all \(\kappa\)'s, together with the acceptance
bit `degree two + exactly one component + (beta_e,beta_f)=(1,0)`.

## Bijection

Take any output generator or spanning 2-factor \(H\) in \(G^+\).  Its two
edge sets

\[
F=H\cap(E(G)\setminus\{uv,xy,r\}),\qquad P=H\cap L'
\]

are disjoint and have union \(H\), because the expansion changes no other
edge.  Degree two away from named roles makes \(F\) an exterior generator;
therefore its actual joint row belongs to \(R_X\).  Degrees, connectivity,
closed components and target use are exactly the arithmetic and partition
join printed in the corresponding atomic row.  This proves restriction.

Conversely, choose an actual generator \(F\) realizing an input row and a
legal table row \(P\).  The edge sets are disjoint, and the degree test says
that \(F\cup P\) has exactly the required degrees.  The partition join is the
connected-component relation of a union of graphs meeting only at their named
role vertices.  Hence the computed partition and closed-component count are
literal, and the OR rule is literal edge membership for the same witness.
Thus \(F\cup P\) is the claimed output generator/2-factor.  The two maps are
inverse because intersection with the fixed disjoint edge sets uniquely
recovers \(F,P\).

This proof covers every real context in \(D_{o^*}\), independently of graph
order, face-arc length, nesting, or the age of \(r\).  Face data is needed to
certify membership in the domain, but not to restrict or glue edge sets.
Consequently equal \(\sigma_0\) gives equal \(J^*\) and equal successor
summaries.  This proves (P).

## Mechanical checks

Run:

```
python scratch/r3_pulse1/generate_tables.py
python scratch/r3_pulse1/validate_real_contexts.py
```

The first command regenerates and checks all 512 atomic selections.  The
second independently enumerates exterior generators and child 2-factors in
two complete legal-history contexts: the frozen 12-vertex context with
retained edge 74, and a depth-zero cube context whose retained-edge
orientation is selected only after direct successor legality verification.
It compares the entire directly enumerated successor-row set with \(T_0\),
and direct Hamilton contain/avoid truth with \(j_0\), for deterministic broad
samples of ordered target pairs.  These tests detect implementation errors;
the preceding bijection, not bounded testing, bears the universal claim.
