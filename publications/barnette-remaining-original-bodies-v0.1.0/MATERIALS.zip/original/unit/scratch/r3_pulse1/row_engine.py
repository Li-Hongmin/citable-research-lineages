#!/usr/bin/env python3
"""Finite row algebra for frozen Route-1 operation o*.

The module deliberately accepts only a boundary row and a local edge set.
No graph object is an argument to ``glue``.
"""

from dataclasses import dataclass
from itertools import combinations

OLD = ("u", "v", "x", "y", "r0", "r1")
NEW = ("a", "b", "c", "d")
BORN = (
    ("u", "a", "ua"), ("a", "b", "ab"),
    ("b", "v", "bv"), ("x", "c", "xc"),
    ("c", "d", "cd"), ("d", "y", "dy"),
    ("a", "d", "ad"), ("b", "c", "bc"),
)
RETAINED = ("r0", "r1", "r")
LOCAL = BORN + (RETAINED,)
OUT_BOUNDARY = ("u", "a", "r0", "r1")
OUT_DELETED = frozenset(("ua", "r"))


class DSU:
    def __init__(self, xs):
        self.p = {x: x for x in xs}
    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x
    def union(self, x, y):
        x, y = self.find(x), self.find(y)
        if x != y:
            self.p[y] = x


def canon_partition(blocks):
    return tuple(sorted((tuple(sorted(b)) for b in blocks), key=lambda b: (b[0], len(b), b)))


@dataclass(frozen=True)
class Row:
    d: tuple
    pi: tuple
    z: int                 # 0, 1, or 2 meaning >=2
    be: int
    bf: int


def glue(row, chosen, target_local=(None, None), output=False):
    """Glue one input row to a local selection; return normalized row or None.

    ``row.pi`` is a partition of OLD. Closed exterior components are represented
    only by row.z, exactly as in the frozen summary.
    """
    chosen = frozenset(chosen)
    degree = dict(zip(OLD, row.d)) | {q: 0 for q in NEW}
    dsu = DSU(OLD + NEW)
    for block in row.pi:
        for q in block[1:]:
            dsu.union(block[0], q)
    active = chosen - OUT_DELETED if output else chosen
    for p, q, name in LOCAL:
        if name in active:
            degree[p] += 1
            degree[q] += 1
            dsu.union(p, q)

    boundary = OUT_BOUNDARY if output else ()
    for q in OLD + NEW:
        if q in boundary:
            if not 0 <= degree[q] <= 2:
                return None
        elif degree[q] != 2:
            return None

    # Components represented by the exterior partition plus selected local edges.
    comps = {}
    for q in OLD + NEW:
        comps.setdefault(dsu.find(q), set()).add(q)
    touching = []
    new_closed = 0
    for comp in comps.values():
        hit = set(boundary) & comp
        if hit:
            touching.append(hit)
        else:
            new_closed += 1
    z = min(2, row.z + new_closed)
    pi = canon_partition(touching)
    d = tuple(degree[q] for q in boundary)
    be = row.be | int(target_local[0] in active)
    bf = row.bf | int(target_local[1] in active)
    return Row(d, pi, z, be, bf)


def local_masks():
    names = tuple(e[2] for e in LOCAL)
    for k in range(len(names) + 1):
        for ss in combinations(names, k):
            yield frozenset(ss)


def accepting_full(row):
    """Connected spanning 2-factor with the joint contain/avoid bits."""
    return row.d == () and row.pi == () and row.z == 1 and (row.be, row.bf) == (1, 0)
