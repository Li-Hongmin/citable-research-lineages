#!/usr/bin/env python3
"""Find and verify a small-support degree-box mixture in the failed EH54 fibre.

Each forest copy is encoded as two rooted trees.  Every assigned non-root
vertex chooses one adjacent parent, and parent depths strictly decrease.
This avoids the component-flow formulation used in the original (A) search.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
from pathlib import Path
import platform

import networkx as nx
import ortools
from ortools.sat.python import cp_model


HERE = Path(__file__).resolve().parent
GRAPH_NAME = "EllinghamHorton54Graph"
ROOT = 52
SINGLETON_PORT = 53
PAIRED_PORTS = (32, 50)


def edge(a: int, b: int) -> tuple[int, int]:
    return (a, b) if a < b else (b, a)


def load_graph() -> tuple[nx.Graph, str]:
    records = json.loads((HERE / "named_graph_data.json").read_text())
    record = next(item for item in records if item["name"] == GRAPH_NAME)
    graph6 = record["graph6"]
    graph = nx.from_graph6_bytes(graph6.encode())
    assert graph.number_of_nodes() == 54
    assert graph.number_of_edges() == 81
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert tuple(sorted(graph[ROOT])) == (*PAIRED_PORTS, SINGLETON_PORT)
    return graph, graph6


def add_rooted_forest(
    model: cp_model.CpModel,
    graph: nx.Graph,
    copy: int,
) -> tuple[dict[tuple[int, int, int], cp_model.IntVar], dict[int, cp_model.LinearExpr]]:
    vertices = tuple(sorted(set(graph) - {ROOT}))
    edges = tuple(sorted(edge(a, b) for a, b in graph.edges() if ROOT not in (a, b)))
    colour = nx.bipartite.color(graph)
    x_side = tuple(sorted(vertex for vertex in graph if colour[vertex] != colour[ROOT]))
    ports = set(graph[ROOT])
    component_roots = (SINGLETON_PORT, PAIRED_PORTS[0])

    assigned = {
        (vertex, component): model.new_bool_var(
            f"copy_{copy}_assigned_{vertex}_{component}"
        )
        for vertex in vertices
        for component in (0, 1)
    }
    depth = {
        vertex: model.new_int_var(0, len(vertices) - 1, f"copy_{copy}_depth_{vertex}")
        for vertex in vertices
    }
    parent = {
        (a, b, component): model.new_bool_var(
            f"copy_{copy}_parent_{a}_{b}_{component}"
        )
        for u, v in edges
        for a, b in ((u, v), (v, u))
        for component in (0, 1)
    }

    for vertex in vertices:
        model.add(assigned[vertex, 0] + assigned[vertex, 1] == 1)
    model.add(assigned[SINGLETON_PORT, 0] == 1)
    for port in PAIRED_PORTS:
        model.add(assigned[port, 1] == 1)

    outgoing: dict[tuple[int, int], list[cp_model.IntVar]] = {
        (vertex, component): []
        for vertex in vertices
        for component in (0, 1)
    }
    incident_selected: dict[int, list[cp_model.IntVar]] = {
        vertex: [] for vertex in vertices
    }
    for u, v in edges:
        for component in (0, 1):
            forward = parent[u, v, component]
            reverse = parent[v, u, component]
            model.add(forward + reverse <= 1)
            for child, parent_vertex, variable in (
                (u, v, forward),
                (v, u, reverse),
            ):
                model.add(variable <= assigned[child, component])
                model.add(variable <= assigned[parent_vertex, component])
                model.add(depth[child] >= depth[parent_vertex] + 1).only_enforce_if(variable)
                outgoing[child, component].append(variable)
            incident_selected[u].extend((forward, reverse))
            incident_selected[v].extend((forward, reverse))

    for component, component_root in enumerate(component_roots):
        model.add(depth[component_root] == 0)
        for vertex in vertices:
            if vertex == component_root:
                model.add(sum(outgoing[vertex, component]) == 0)
            else:
                model.add(
                    sum(outgoing[vertex, component]) == assigned[vertex, component]
                )

    for x in x_side:
        required = 1 if x in ports else 2
        model.add(sum(incident_selected[x]) == required)

    degree = {
        vertex: sum(incident_selected[vertex])
        for vertex in vertices
    }
    return parent, degree


def verify_forest(
    graph: nx.Graph,
    forest: list[tuple[int, int]],
) -> dict[str, object]:
    colour = nx.bipartite.color(graph)
    y_order = tuple(
        sorted(vertex for vertex in graph if vertex != ROOT and colour[vertex] == colour[ROOT])
    )
    x_side = tuple(sorted(vertex for vertex in graph if colour[vertex] != colour[ROOT]))
    ports = set(graph[ROOT])
    support = nx.Graph()
    support.add_nodes_from(set(graph) - {ROOT})
    support.add_edges_from(forest)
    assert len(forest) == len(set(forest)) == 51
    assert nx.is_forest(support)
    assert nx.number_connected_components(support) == 2
    for x in x_side:
        assert support.degree(x) == (1 if x in ports else 2)
    components = tuple(frozenset(component) for component in nx.connected_components(support))
    blocks = sorted(sorted(component & ports) for component in components)
    assert blocks == [[*PAIRED_PORTS], [SINGLETON_PORT]]
    vector = tuple(support.degree(y) for y in y_order)
    assert min(vector) >= 1 and max(vector) <= 3 and sum(vector) == 51
    return {
        "forest_edges": sorted(forest),
        "degree_vector": vector,
        "component_sizes": sorted(map(len, components)),
        "degree_one_y": [y for y, value in zip(y_order, vector) if value == 1],
        "degree_three_y": [y for y, value in zip(y_order, vector) if value == 3],
    }


def solve(copies: int) -> dict[str, object]:
    assert copies >= 2
    graph, graph6 = load_graph()
    colour = nx.bipartite.color(graph)
    y_order = tuple(
        sorted(vertex for vertex in graph if vertex != ROOT and colour[vertex] == colour[ROOT])
    )
    edges = tuple(sorted(edge(a, b) for a, b in graph.edges() if ROOT not in (a, b)))

    model = cp_model.CpModel()
    forest_models = [add_rooted_forest(model, graph, copy) for copy in range(copies)]
    for y in y_order:
        model.add(sum(degrees[y] for _, degrees in forest_models) <= 2 * copies)

    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = 1
    solver.parameters.random_seed = 0
    solver.parameters.max_time_in_seconds = 1800.0
    status = solver.solve(model)
    status_name = solver.status_name(status)

    result: dict[str, object] = {
        "graph": GRAPH_NAME,
        "graph6": graph6,
        "order": graph.number_of_nodes(),
        "size": graph.number_of_edges(),
        "root": ROOT,
        "ports": sorted(graph[ROOT]),
        "singleton_port": SINGLETON_PORT,
        "paired_ports": list(PAIRED_PORTS),
        "y_order": y_order,
        "copies": copies,
        "weights": [f"1/{copies}"] * copies,
        "solver": {
            "name": "OR-Tools CP-SAT",
            "ortools_version": ortools.__version__,
            "python_version": platform.python_version(),
            "status": status_name,
            "wall_time_seconds": solver.wall_time,
            "num_conflicts": solver.num_conflicts,
            "num_branches": solver.num_branches,
            "response_stats": solver.response_stats(),
        },
        "certificates": None,
    }

    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        certificates = []
        for parent, _ in forest_models:
            forest = []
            for u, v in edges:
                if any(
                    solver.value(parent[u, v, component])
                    or solver.value(parent[v, u, component])
                    for component in (0, 1)
                ):
                    forest.append((u, v))
            certificates.append(verify_forest(graph, forest))

        expectations = tuple(
            sum(Fraction(cert["degree_vector"][index], copies) for cert in certificates)
            for index in range(len(y_order))
        )
        assert max(expectations) <= 2
        result["certificates"] = certificates
        result["expected_degree_vector"] = [
            f"{value.numerator}/{value.denominator}" for value in expectations
        ]
        result["coordinate_slacks"] = [
            f"{value.numerator}/{value.denominator}" for value in (2 - item for item in expectations)
        ]

    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--copies", type=int, default=2)
    args = parser.parse_args()
    result = solve(args.copies)
    output = HERE / f"eh54_failed_fibre_degree_box_support{args.copies}.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result["solver"], indent=2, sort_keys=True))
    print("output", output)
    if result["certificates"] is not None:
        print("EH54_FAILED_FIBRE_DEGREE_BOX_FEASIBLE")
    else:
        print("EH54_FAILED_FIBRE_EQUAL_SUPPORT_UNDECIDED_OR_INFEASIBLE")


if __name__ == "__main__":
    main()
