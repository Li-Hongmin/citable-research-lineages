# Named cubic bipartite fixed-fibre test

## Scope and stopping rule

The frozen Sage named graphs were tested first for the strict Hall brace
condition.  On each brace, root/port stabilizer orbits were to be tested for
the integral condition

\[
\tag{A}
\exists J\in\mathcal F_i\quad \deg_J(y)\le 2
\quad(y\in Y\setminus\{r\}).
\]

At the first failure of (A), the search stops and tests only that fibre for

\[
\tag{B}
\operatorname{conv}\{d_Y(J):J\in\mathcal F_i\}
\cap(-\infty,2]^{Y\setminus\{r\}}\ne\varnothing.
\]

No further graph family, root orbit, or adjacent parameter was tested after
this stopping condition was reached.

## Strict Hall classification

| graph | order | minimum \(|N(U)|-|U|\) | brace | root orbits | root/port orbit representatives |
|---|---:|---:|:---:|---:|---:|
| HortonGraph | 96 | 1 | no | 0 | 0 |
| EllinghamHorton54Graph | 54 | 2 | yes | 10 | 24 |
| EllinghamHorton78Graph | 78 | 1 | no | 0 | 0 |
| GrayGraph | 54 | 2 | yes | 2 | 2 |
| PappusGraph | 18 | 2 | yes | 1 | 1 |
| TutteCoxeterGraph | 30 | 2 | yes | 1 | 1 |

The two non-braces and exact minimizing Hall witnesses are stored in
`named_graph_data.json`.  The last column counts symmetry-reduced candidate
fibres; it does not assert that post-stop (A) tests were executed.

## First integral failure

The first 23 root/port stabilizer-orbit fibres of
`EllinghamHorton54Graph` have integral two-path certificates.  The final
orbit test does not:

\[
r=52,\qquad N(r)=(32,50,53),\qquad
\{53\}\mid\{32,50\}.
\]

The graph6 identity is

```text
uhCGGCP?GGo@?PG?_?KO@?????G?????C??@??AG??????P??@?????_???G???P??AA??OCC?C?CC???AAO???__???CC???????????@????????????_?????G?????P????????????AG?????G???????C??????@??????AG?????OOG?????__??G???__??????OQ??????CC???????__?????G??G?????O??W
```

The discovery model in `check_named_graph_two_path_scipy.py` uses binary
component assignments, selected edges, and two connectivity flows.  HiGHS
returns `Infeasible` for this fibre.

An independent model uses the fact that every forest satisfying (A) is a
two-path cover.  Orient the paired-port path from 32 to 50 and the other path
from 53 to its degree-one endpoint \(y\in Y\setminus\{52\}\).  Adding

\[
\mathrm{dummy}\to32,\qquad 50\to53,\qquad y\to\mathrm{dummy}
\]

gives a Hamilton circuit.  Conversely, deleting these three artificial arcs
from such a circuit gives exactly the required two paths.  The independent
CP-SAT model therefore consists of one `AddCircuit` constraint on 54
vertices, 156 orientations of the 78 edges of \(F-52\), one forced bridge,
one forced dummy-start arc, and 26 possible return arcs.  OR-Tools 9.15.6755
returns `INFEASIBLE` with 366 conflicts and 2511 branches.  This model uses
neither the original component variables nor its connectivity flows.

Thus this fibre is a genuine finite counterexample to (A) among the tested
named braces.  The stop rule leaves the (A) status of Gray, Pappus, and
Tutte--Coxeter outside the conclusion.

## The same fibre satisfies the fractional degree box

Property (B) has an exact support-two certificate.  Let \(J_1,J_2\) be the
two forests stored with their complete 51-edge sets in
`eh54_failed_fibre_degree_box_support2.json`.  Both are spanning forests of
\(F-52\) with two components, port partition
\(\{53\}\mid\{32,50\}\), port degrees one, and all other \(X\)-degrees two.
Their exceptional \(Y\)-degrees are

\[
\begin{array}{c|c|c}
&\deg=1&\deg=3\\ \hline
J_1&\{12,16,20,38,40\}&\{10,14,22,44\}\\
J_2&\{10,14,22,44\}&\{12,16,38\}.
\end{array}
\]

Every unlisted \(Y\)-vertex has degree two.  Hence the distribution

\[
\Pr[J_1]=\Pr[J_2]=\frac12
\]

has expected degree two at every coordinate except 20 and 40, where its
expected degree is \(3/2\).  It follows exactly that

\[
\frac12d_Y(J_1)+\frac12d_Y(J_2)\le2\mathbf1,
\]

so (B) holds.  Because (A) is precisely the support-one case, the support
size two is minimal.

The same distribution also settles every binary weak bound in this fibre:
for every \(H\subseteq Y\setminus\{52\}\),

\[
\frac12\ell_H(J_1)+\frac12\ell_H(J_2)\le2|H|,
\]

and therefore at least one of the two forests has
\(\ell_H(J_j)\le2|H|\).  There is no binary weak-bound failure and no
nonnegative Farkas separator for (B).  No claim is made here about the
one-unit strong binary bound.

## Evidence boundary and reproduction

The two stored edge sets are checked without a solver by
`verify_eh54_failed_fibre_certificates.py`: it reconstructs the frozen
graph6 graph, checks strict Hall metadata, all forest edges, acyclicity, the
two components, the labelled port partition, all prescribed \(X\)-degrees,
the complete \(Y\)-degree vectors, and the exact rational expectation.  It
also checks that both the discovery and independent (A) records identify the
same root and fibre and report infeasibility.  The infeasibility evidence is
two independent finite solver determinations; no standalone UNSAT proof log
is claimed.

Environment used: SageMath 10.9 for the named graph export and strict Hall
classification; Python 3.12.11, SciPy/HiGHS for discovery; Python 3.12.11 and
OR-Tools 9.15.6755 for the independent circuit test and support-two search.

From this directory:

```bash
uv run --python 3.12 --with networkx --with ortools \
  verify_eh54_failed_fibre_cpsat.py
uv run --python 3.12 --with networkx --with ortools \
  solve_eh54_failed_fibre_degree_box.py --copies 2
uv run --python 3.12 --with networkx \
  verify_eh54_failed_fibre_certificates.py
```

The final verifier marker is
`EH54_FAILED_FIBRE_CERTIFICATES_VERIFIED`.
