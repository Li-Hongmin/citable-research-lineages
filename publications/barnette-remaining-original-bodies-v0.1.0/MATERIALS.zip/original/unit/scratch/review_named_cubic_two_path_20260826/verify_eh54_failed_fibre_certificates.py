#!/usr/bin/env python3
"""Solver-free verification of the frozen EH54 fibre certificates."""

from __future__ import annotations

from fractions import Fraction
import json
from pathlib import Path

import networkx as nx


HERE = Path(__file__).resolve().parent
GRAPH_NAME = "EllinghamHorton54Graph"
ROOT = 52
PORTS = (32, 50, 53)
SINGLETON_PORT = 53
PAIRED_PORTS = frozenset((32, 50))


def edge(a: int, b: int) -> tuple[int, int]:
    return (a, b) if a < b else (b, a)


def parse_fraction(value: str) -> Fraction:
    return Fraction(value)


def verify_forest(
    graph: nx.Graph,
    forest_record: dict[str, object],
    y_order: tuple[int, ...],
) -> tuple[int, ...]:
    forest = tuple(edge(*item) for item in forest_record["forest_edges"])
    assert len(forest) == len(set(forest)) == 51
    assert all(graph.has_edge(*item) and ROOT not in item for item in forest)

    support = nx.Graph()
    support.add_nodes_from(set(graph) - {ROOT})
    support.add_edges_from(forest)
    assert nx.is_forest(support)
    components = tuple(frozenset(component) for component in nx.connected_components(support))
    assert len(components) == 2
    blocks = {frozenset(component & set(PORTS)) for component in components}
    assert blocks == {PAIRED_PORTS, frozenset((SINGLETON_PORT,))}

    colour = nx.bipartite.color(graph)
    x_side = tuple(sorted(vertex for vertex in graph if colour[vertex] != colour[ROOT]))
    for x in x_side:
        assert support.degree(x) == (1 if x in PORTS else 2)

    vector = tuple(support.degree(y) for y in y_order)
    assert vector == tuple(forest_record["degree_vector"])
    assert min(vector) >= 1 and max(vector) <= 3 and sum(vector) == 51
    assert [y for y, value in zip(y_order, vector) if value == 1] == forest_record["degree_one_y"]
    assert [y for y, value in zip(y_order, vector) if value == 3] == forest_record["degree_three_y"]
    assert sorted(map(len, components)) == forest_record["component_sizes"]
    return vector


def main() -> None:
    named = json.loads((HERE / "named_graph_data.json").read_text())
    named_record = next(item for item in named if item["name"] == GRAPH_NAME)
    graph6 = named_record["graph6"]
    graph = nx.from_graph6_bytes(graph6.encode())
    assert graph.number_of_nodes() == 54 and graph.number_of_edges() == 81
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert tuple(sorted(graph[ROOT])) == PORTS
    assert named_record["strict_hall"]["brace"] is True
    assert named_record["strict_hall"]["strict_hall_minimum"] == 2

    original = json.loads((HERE / "named_graph_two_path_scipy_results.json").read_text())
    original_record = next(item for item in original if item["name"] == GRAPH_NAME)
    original_failure = original_record["tests"][-1]
    assert len(original_record["tests"]) == 24
    assert original_failure["root"] == ROOT
    assert original_failure["singleton_port"] == SINGLETON_PORT
    assert original_failure["solver"]["status"] == "infeasible"
    assert original_failure["certificate"] is None

    independent = json.loads((HERE / "eh54_failed_fibre_cpsat_result.json").read_text())
    assert independent["graph"] == GRAPH_NAME and independent["graph6"] == graph6
    assert independent["root"] == ROOT
    assert tuple(independent["ports"]) == PORTS
    assert independent["singleton_port"] == SINGLETON_PORT
    assert frozenset(independent["paired_ports"]) == PAIRED_PORTS
    assert independent["solver"]["status"] == "INFEASIBLE"
    assert independent["certificate"] is None

    mixture = json.loads((HERE / "eh54_failed_fibre_degree_box_support2.json").read_text())
    assert mixture["graph"] == GRAPH_NAME and mixture["graph6"] == graph6
    assert mixture["root"] == ROOT
    assert tuple(mixture["ports"]) == PORTS
    assert mixture["singleton_port"] == SINGLETON_PORT
    assert frozenset(mixture["paired_ports"]) == PAIRED_PORTS
    y_order = tuple(mixture["y_order"])
    colour = nx.bipartite.color(graph)
    expected_y_order = tuple(
        sorted(vertex for vertex in graph if vertex != ROOT and colour[vertex] == colour[ROOT])
    )
    assert y_order == expected_y_order and len(y_order) == 26

    weights = tuple(parse_fraction(value) for value in mixture["weights"])
    assert weights == (Fraction(1, 2), Fraction(1, 2))
    assert sum(weights) == 1
    records = mixture["certificates"]
    assert len(records) == 2
    vectors = tuple(verify_forest(graph, record, y_order) for record in records)
    assert vectors[0] != vectors[1]

    expectation = tuple(
        sum(weight * vector[index] for weight, vector in zip(weights, vectors))
        for index in range(len(y_order))
    )
    assert expectation == tuple(parse_fraction(value) for value in mixture["expected_degree_vector"])
    assert max(expectation) <= 2
    assert tuple(2 - value for value in expectation) == tuple(
        parse_fraction(value) for value in mixture["coordinate_slacks"]
    )

    degree_one = tuple(
        {y for y, value in zip(y_order, vector) if value == 1}
        for vector in vectors
    )
    degree_three = tuple(
        {y for y, value in zip(y_order, vector) if value == 3}
        for vector in vectors
    )
    assert degree_three[0] <= degree_one[1]
    assert degree_three[1] <= degree_one[0]

    # Coordinatewise expectation <= 2 immediately implies every binary-H
    # weak bound after summing over H; no 2^26 subset scan is needed.
    assert all(value <= 2 for value in expectation)
    print("EH54_FAILED_FIBRE_CERTIFICATES_VERIFIED")


if __name__ == "__main__":
    main()
