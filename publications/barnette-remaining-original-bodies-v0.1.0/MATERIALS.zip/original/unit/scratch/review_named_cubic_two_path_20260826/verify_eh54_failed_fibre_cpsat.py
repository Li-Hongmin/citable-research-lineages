#!/usr/bin/env python3
"""Independently verify the reported EH54 two-path-fibre failure.

For root 52 and port split 53 | {32, 50}, a spanning two-path cover in
F-52 is equivalent to a Hamilton path obtained by inserting the artificial
directed bridge 50 -> 53.  Closing that path with a dummy vertex gives one
Hamilton circuit

    dummy -> 32 ... 50 -> 53 ... y -> dummy,

where y ranges over the Y-side vertices other than the root.  This CP-SAT
circuit model is independent of the component-assignment/flow MILP used to
discover the failure.
"""

from __future__ import annotations

import json
from pathlib import Path
import platform

import networkx as nx
import ortools
from ortools.sat.python import cp_model


HERE = Path(__file__).resolve().parent
GRAPH_NAME = "EllinghamHorton54Graph"
ROOT = 52
SINGLETON_PORT = 53
PAIRED_START = 32
PAIRED_END = 50


def edge(a: int, b: int) -> tuple[int, int]:
    return (a, b) if a < b else (b, a)


def load_graph() -> tuple[nx.Graph, str]:
    records = json.loads((HERE / "named_graph_data.json").read_text())
    record = next(item for item in records if item["name"] == GRAPH_NAME)
    graph6 = record["graph6"]
    graph = nx.from_graph6_bytes(graph6.encode())
    assert graph.number_of_nodes() == 54
    assert graph.number_of_edges() == 81
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert tuple(sorted(graph[ROOT])) == (PAIRED_START, PAIRED_END, SINGLETON_PORT)
    return graph, graph6


def verify_cycle_solution(
    graph: nx.Graph,
    successor: dict[int | str, int | str],
) -> dict[str, object]:
    dummy = "dummy"
    order: list[int | str] = [dummy]
    while True:
        nxt = successor[order[-1]]
        if nxt == dummy:
            break
        assert nxt not in order
        order.append(nxt)
    assert len(order) == graph.number_of_nodes()
    assert order[1] == PAIRED_START
    paired_end_index = order.index(PAIRED_END)
    assert order[paired_end_index + 1] == SINGLETON_PORT
    low_y = order[-1]

    colour = nx.bipartite.color(graph)
    y_side = {vertex for vertex in graph if colour[vertex] == colour[ROOT]}
    assert low_y in y_side - {ROOT}

    forest_edges = []
    for a, b in zip(order[1:], order[2:]):
        if (a, b) == (PAIRED_END, SINGLETON_PORT):
            continue
        assert isinstance(a, int) and isinstance(b, int)
        assert graph.has_edge(a, b)
        forest_edges.append(edge(a, b))

    support = nx.Graph()
    support.add_nodes_from(set(graph) - {ROOT})
    support.add_edges_from(forest_edges)
    assert nx.is_forest(support)
    assert nx.number_connected_components(support) == 2
    components = list(nx.connected_components(support))
    port_blocks = sorted(
        sorted(set(component) & {PAIRED_START, PAIRED_END, SINGLETON_PORT})
        for component in components
    )
    assert port_blocks == [[PAIRED_START, PAIRED_END], [SINGLETON_PORT]]
    return {
        "cycle_order_from_dummy": order,
        "low_y": low_y,
        "forest_edges": sorted(forest_edges),
    }


def solve() -> dict[str, object]:
    graph, graph6 = load_graph()
    vertices = sorted(set(graph) - {ROOT})
    dummy = max(graph) + 1
    node_order = vertices + [dummy]
    node_index = {vertex: index for index, vertex in enumerate(node_order)}

    model = cp_model.CpModel()
    arcs: list[tuple[int, int, cp_model.IntVar]] = []
    arc_vars: dict[tuple[int, int], cp_model.IntVar] = {}

    def add_arc(a: int, b: int, label: str) -> cp_model.IntVar:
        variable = model.new_bool_var(label)
        arcs.append((node_index[a], node_index[b], variable))
        arc_vars[a, b] = variable
        return variable

    for a, b in sorted(edge(a, b) for a, b in graph.edges() if ROOT not in (a, b)):
        add_arc(a, b, f"edge_{a}_{b}_forward")
        add_arc(b, a, f"edge_{a}_{b}_reverse")

    bridge = add_arc(PAIRED_END, SINGLETON_PORT, "forced_bridge_50_53")
    dummy_start = add_arc(dummy, PAIRED_START, "forced_dummy_32")

    colour = nx.bipartite.color(graph)
    y_side = sorted(
        vertex for vertex in graph
        if vertex != ROOT and colour[vertex] == colour[ROOT]
    )
    for y in y_side:
        add_arc(y, dummy, f"endpoint_{y}_dummy")

    model.add(bridge == 1)
    model.add(dummy_start == 1)
    model.add_circuit(arcs)

    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = 1
    solver.parameters.random_seed = 0
    solver.parameters.max_time_in_seconds = 1800.0
    status = solver.solve(model)
    status_name = solver.status_name(status)

    result: dict[str, object] = {
        "graph": GRAPH_NAME,
        "graph6": graph6,
        "order": graph.number_of_nodes(),
        "size": graph.number_of_edges(),
        "root": ROOT,
        "ports": sorted(graph[ROOT]),
        "singleton_port": SINGLETON_PORT,
        "paired_ports": [PAIRED_START, PAIRED_END],
        "reduction": (
            "Hamilton circuit on F-root plus dummy, with forced arcs "
            "dummy->32 and 50->53 and return arcs y->dummy"
        ),
        "solver": {
            "name": "OR-Tools CP-SAT",
            "ortools_version": ortools.__version__,
            "python_version": platform.python_version(),
            "status": status_name,
            "wall_time_seconds": solver.wall_time,
            "num_conflicts": solver.num_conflicts,
            "num_branches": solver.num_branches,
            "response_stats": solver.response_stats(),
        },
        "model": {
            "vertices_in_circuit": len(node_order),
            "directed_arc_variables": len(arcs),
            "original_edges_after_root_deletion": graph.number_of_edges() - 3,
            "candidate_low_y_vertices": y_side,
        },
    }

    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        successor: dict[int | str, int | str] = {}
        for (a, b), variable in arc_vars.items():
            if solver.value(variable):
                successor["dummy" if a == dummy else a] = "dummy" if b == dummy else b
        result["certificate"] = verify_cycle_solution(graph, successor)
    else:
        result["certificate"] = None

    return result


def main() -> None:
    result = solve()
    output = HERE / "eh54_failed_fibre_cpsat_result.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result["solver"], indent=2, sort_keys=True))
    print("output", output)
    if result["solver"]["status"] == "INFEASIBLE":
        print("EH54_FAILED_FIBRE_A_INFEASIBLE_CPSAT")
    else:
        print("EH54_FAILED_FIBRE_A_NOT_CONFIRMED")


if __name__ == "__main__":
    main()
