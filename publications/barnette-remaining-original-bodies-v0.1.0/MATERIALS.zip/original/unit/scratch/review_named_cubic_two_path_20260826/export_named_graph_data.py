#!/usr/bin/env python3
"""Export Sage named graphs, strict-Hall certificates, and symmetry orbits."""

from __future__ import annotations

import json
from pathlib import Path

from check_named_graph_two_path import (
    GRAPH_NAMES,
    root_and_port_orbit_representatives,
    serializable,
    strict_hall_certificate,
)
from sage.all import graphs


HERE = Path(__file__).resolve().parent


def main():
    payload = []
    for name in GRAPH_NAMES:
        graph = getattr(graphs, name)()
        hall = strict_hall_certificate(graph)
        payload.append(
            {
                "name": name,
                "order": graph.order(),
                "size": graph.size(),
                "graph6": graph.graph6_string(),
                "strict_hall": hall,
                "root_port_orbits": (
                    root_and_port_orbit_representatives(graph)
                    if hall["brace"]
                    else ()
                ),
            }
        )
        print(name, hall, flush=True)
    output = HERE / "named_graph_data.json"
    output.write_text(json.dumps(serializable(payload), indent=2, sort_keys=True) + "\n")
    print("output", output)


if __name__ == "__main__":
    main()
