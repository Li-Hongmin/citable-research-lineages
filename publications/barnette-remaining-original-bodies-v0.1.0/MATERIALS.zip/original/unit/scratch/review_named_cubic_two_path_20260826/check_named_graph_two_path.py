#!/usr/bin/env python3
"""Check strict Hall and fixed-fibre two-path feasibility in named Sage graphs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from sage.all import MixedIntegerLinearProgram, graphs


HERE = Path(__file__).resolve().parent
GRAPH_NAMES = (
    "HortonGraph",
    "EllinghamHorton54Graph",
    "EllinghamHorton78Graph",
    "GrayGraph",
    "PappusGraph",
    "TutteCoxeterGraph",
)


def edge(a, b):
    return (a, b) if a < b else (b, a)


def strict_hall_certificate(graph):
    """Minimize |N(U)|-|U| over 1 <= |U| <= n-2 exactly as a 0/1 MILP."""
    left, right = map(tuple, graph.bipartite_sets())
    if len(left) != len(right):
        return {"brace": False, "reason": "unbalanced"}
    program = MixedIntegerLinearProgram(maximization=False, solver="Coin")
    in_u = program.new_variable(binary=True)
    in_n = program.new_variable(binary=True)
    for x in left:
        for y in graph.neighbors(x):
            program.add_constraint(in_n[y] >= in_u[x])
    program.add_constraint(program.sum(in_u[x] for x in left) >= 1)
    program.add_constraint(program.sum(in_u[x] for x in left) <= len(left) - 2)
    program.set_objective(
        program.sum(in_n[y] for y in right)
        - program.sum(in_u[x] for x in left)
    )
    optimum = int(round(program.solve()))
    values_u = program.get_values(in_u)
    subset = tuple(sorted(x for x in left if values_u[x] > 0.5))
    neighbours = tuple(sorted(set().union(*(set(graph.neighbors(x)) for x in subset))))
    assert len(neighbours) - len(subset) == optimum
    return {
        "brace": optimum >= 2,
        "strict_hall_minimum": optimum,
        "minimizing_subset": subset,
        "neighbours": neighbours,
    }


def root_and_port_orbit_representatives(graph):
    group = graph.automorphism_group()
    records = []
    for vertex_orbit in group.orbits():
        root = min(vertex_orbit)
        stabilizer = group.stabilizer(root)
        port_orbits = []
        for port in graph.neighbors(root):
            orbit = tuple(sorted({permutation(port) for permutation in stabilizer}))
            if orbit not in port_orbits:
                port_orbits.append(orbit)
        records.append(
            {
                "root": root,
                "root_orbit": tuple(sorted(vertex_orbit)),
                "port_orbits": tuple(sorted(port_orbits)),
            }
        )
    return tuple(sorted(records, key=lambda item: item["root"]))


def two_path_forest(graph, root, singleton_port):
    """Return an exact fixed-fibre two-path forest, or None if infeasible."""
    side_a, side_b = map(set, graph.bipartite_sets())
    y_side, x_side = (side_a, side_b) if root in side_a else (side_b, side_a)
    y_vertices = tuple(sorted(y_side - {root}))
    x_vertices = tuple(sorted(x_side))
    ports = tuple(sorted(graph.neighbors(root)))
    assert singleton_port in ports
    paired_ports = tuple(port for port in ports if port != singleton_port)
    vertices = tuple(sorted(set(graph.vertices()) - {root}))
    edges = tuple(sorted(edge(a, b) for a, b in graph.edges(labels=False) if root not in (a, b)))
    incident = {vertex: [] for vertex in vertices}
    for a, b in edges:
        incident[a].append((a, b))
        incident[b].append((a, b))

    program = MixedIntegerLinearProgram(maximization=False, solver="Coin")
    assigned = program.new_variable(binary=True)
    selected = program.new_variable(binary=True)
    flow = program.new_variable(nonnegative=True)
    component_roots = (singleton_port, paired_ports[0])
    vertex_count = len(vertices)

    for vertex in vertices:
        program.add_constraint(assigned[vertex, 0] + assigned[vertex, 1] == 1)
    program.add_constraint(assigned[singleton_port, 0] == 1)
    for port in paired_ports:
        program.add_constraint(assigned[port, 1] == 1)

    for a, b in edges:
        for component in (0, 1):
            program.add_constraint(selected[a, b, component] <= assigned[a, component])
            program.add_constraint(selected[a, b, component] <= assigned[b, component])
            program.add_constraint(flow[a, b, component] <= vertex_count * selected[a, b, component])
            program.add_constraint(flow[b, a, component] <= vertex_count * selected[a, b, component])

    for x in x_vertices:
        required = 1 if x in ports else 2
        program.add_constraint(
            program.sum(
                selected[a, b, component]
                for a, b in incident[x]
                for component in (0, 1)
            )
            == required
        )
    for y in y_vertices:
        degree = program.sum(
            selected[a, b, component]
            for a, b in incident[y]
            for component in (0, 1)
        )
        program.add_constraint(degree >= 1)
        program.add_constraint(degree <= 2)

    for component, component_root in enumerate(component_roots):
        for vertex in vertices:
            incoming = program.sum(
                flow[other, vertex, component]
                for other in graph.neighbors(vertex)
                if other != root
            )
            outgoing = program.sum(
                flow[vertex, other, component]
                for other in graph.neighbors(vertex)
                if other != root
            )
            if vertex == component_root:
                program.add_constraint(
                    outgoing - incoming
                    == program.sum(
                        assigned[other, component]
                        for other in vertices
                        if other != component_root
                    )
                )
            else:
                program.add_constraint(incoming - outgoing == assigned[vertex, component])

    program.set_objective(0)
    try:
        program.solve()
    except Exception as error:
        if "no feasible solution" in str(error).lower():
            return None
        raise

    selected_values = program.get_values(selected)
    forest = tuple(
        (a, b)
        for a, b in edges
        if sum(selected_values[a, b, component] for component in (0, 1)) > 0.5
    )
    return verify_two_path_forest(
        graph, root, ports.index(singleton_port), forest
    )


def verify_two_path_forest(graph, root, fibre, forest):
    side_a, side_b = map(set, graph.bipartite_sets())
    y_side, x_side = (side_a, side_b) if root in side_a else (side_b, side_a)
    y_vertices = tuple(sorted(y_side - {root}))
    ports = tuple(sorted(graph.neighbors(root)))
    support = graph.subgraph(vertices=graph.vertices(), edges=[])
    support.delete_vertex(root)
    support.add_edges(forest)
    assert support.is_forest() and support.connected_components_number() == 2
    components = tuple(set(component) for component in support.connected_components())
    blocks = tuple(
        tuple(index for index, port in enumerate(ports) if port in component)
        for component in components
    )
    assert sorted(map(len, blocks)) == [1, 2] and (fibre,) in blocks
    for x in x_side:
        assert support.degree(x) == (1 if x in ports else 2)
    vector = tuple(support.degree(y) for y in y_vertices)
    assert vector.count(1) == 1 and vector.count(2) == len(vector) - 1
    singleton_component = next(
        component for component, block in zip(components, blocks) if block == (fibre,)
    )
    low_y = y_vertices[vector.index(1)]
    assert low_y in singleton_component
    return {
        "fibre": fibre,
        "ports": ports,
        "y_order": y_vertices,
        "degree_vector": vector,
        "forest": tuple(sorted(edge(a, b) for a, b in forest)),
        "component_sizes": tuple(sorted(map(len, components))),
        "low_y": low_y,
    }


def check_graph(name):
    graph = getattr(graphs, name)()
    assert graph.is_connected() and graph.is_bipartite()
    assert set(graph.degree()) == {3}
    hall = strict_hall_certificate(graph)
    result = {
        "name": name,
        "order": graph.order(),
        "size": graph.size(),
        "graph6": graph.graph6_string(),
        "strict_hall": hall,
        "tests": [],
    }
    print(name, "strict_hall", hall["strict_hall_minimum"], "brace", hall["brace"], flush=True)
    if not hall["brace"]:
        return result, None

    orbit_records = root_and_port_orbit_representatives(graph)
    result["root_port_orbits"] = orbit_records
    for root_index, orbit_record in enumerate(orbit_records, 1):
        root = orbit_record["root"]
        for port_orbit in orbit_record["port_orbits"]:
            singleton_port = port_orbit[0]
            certificate = two_path_forest(graph, root, singleton_port)
            test = {
                "root": root,
                "root_orbit": orbit_record["root_orbit"],
                "singleton_port": singleton_port,
                "singleton_port_orbit": port_orbit,
                "certificate": certificate,
            }
            result["tests"].append(test)
            print(
                name,
                f"root_orbit={root_index}/{len(orbit_records)}",
                "root",
                root,
                "port",
                singleton_port,
                "status",
                "A_feasible" if certificate else "A_FAILURE",
                flush=True,
            )
            if certificate is None:
                return result, test
    return result, None


def serializable(value):
    if isinstance(value, tuple):
        return [serializable(item) for item in value]
    if isinstance(value, list):
        return [serializable(item) for item in value]
    if isinstance(value, dict):
        return {key: serializable(item) for key, item in value.items()}
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--only", choices=GRAPH_NAMES)
    args = parser.parse_args()
    names = (args.only,) if args.only else GRAPH_NAMES
    payload = []
    failure = None
    for name in names:
        graph_result, failure = check_graph(name)
        payload.append(graph_result)
        if failure is not None:
            break
    suffix = args.only or "ordered_family"
    output = HERE / f"{suffix}_two_path_results.json"
    output.write_text(json.dumps(serializable(payload), indent=2, sort_keys=True) + "\n")
    print("output", output)
    if failure is None:
        print("NAMED_GRAPH_TWO_PATH_NO_FAILURE")
    else:
        print("NAMED_GRAPH_TWO_PATH_A_FAILURE")


if __name__ == "__main__":
    main()
