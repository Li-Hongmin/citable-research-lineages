#!/usr/bin/env python3
"""MILP search for fixed-fibre spanning two-path covers in exported graphs."""

from __future__ import annotations

from collections import defaultdict
import json
from pathlib import Path

import networkx as nx
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix


HERE = Path(__file__).resolve().parent


def edge(a, b):
    return (a, b) if a < b else (b, a)


class Model:
    def __init__(self):
        self.names = []
        self.lower = []
        self.upper = []
        self.integrality = []
        self.rows = []
        self.row_lower = []
        self.row_upper = []

    def variable(self, name, lower=0, upper=np.inf, integer=False):
        index = len(self.names)
        self.names.append(name)
        self.lower.append(lower)
        self.upper.append(upper)
        self.integrality.append(int(integer))
        return index

    def constraint(self, coefficients, lower=-np.inf, upper=np.inf):
        self.rows.append(dict(coefficients))
        self.row_lower.append(lower)
        self.row_upper.append(upper)

    def solve(self, time_limit=300):
        row_index = []
        column_index = []
        values = []
        for row, coefficients in enumerate(self.rows):
            for column, value in coefficients.items():
                if value:
                    row_index.append(row)
                    column_index.append(column)
                    values.append(value)
        matrix = coo_matrix(
            (values, (row_index, column_index)),
            shape=(len(self.rows), len(self.names)),
        ).tocsr()
        return milp(
            c=np.zeros(len(self.names)),
            integrality=np.asarray(self.integrality),
            bounds=Bounds(np.asarray(self.lower), np.asarray(self.upper)),
            constraints=LinearConstraint(
                matrix,
                np.asarray(self.row_lower),
                np.asarray(self.row_upper),
            ),
            options={"time_limit": time_limit, "mip_rel_gap": 0.0},
        )


def two_path_milp(graph, root, singleton_port):
    colour = nx.bipartite.color(graph)
    y_side = {v for v in graph if colour[v] == colour[root]}
    x_side = set(graph) - y_side
    vertices = tuple(sorted(set(graph) - {root}))
    y_vertices = tuple(sorted(y_side - {root}))
    ports = tuple(sorted(graph[root]))
    paired_ports = tuple(port for port in ports if port != singleton_port)
    edges = tuple(sorted(edge(a, b) for a, b in graph.edges() if root not in (a, b)))
    incident = defaultdict(list)
    for e in edges:
        for vertex in e:
            incident[vertex].append(e)

    model = Model()
    assigned = {
        (v, c): model.variable(("assigned", v, c), upper=1, integer=True)
        for v in vertices
        for c in (0, 1)
    }
    selected = {
        (e, c): model.variable(("selected", e, c), upper=1, integer=True)
        for e in edges
        for c in (0, 1)
    }
    flow = {
        (u, v, c): model.variable(("flow", u, v, c), upper=len(vertices))
        for a, b in edges
        for u, v in ((a, b), (b, a))
        for c in (0, 1)
    }

    for vertex in vertices:
        model.constraint(
            {assigned[vertex, 0]: 1, assigned[vertex, 1]: 1},
            lower=1,
            upper=1,
        )
    model.constraint({assigned[singleton_port, 0]: 1}, lower=1, upper=1)
    for port in paired_ports:
        model.constraint({assigned[port, 1]: 1}, lower=1, upper=1)

    for e in edges:
        a, b = e
        for component in (0, 1):
            model.constraint(
                {selected[e, component]: 1, assigned[a, component]: -1},
                upper=0,
            )
            model.constraint(
                {selected[e, component]: 1, assigned[b, component]: -1},
                upper=0,
            )
            model.constraint(
                {flow[a, b, component]: 1, selected[e, component]: -len(vertices)},
                upper=0,
            )
            model.constraint(
                {flow[b, a, component]: 1, selected[e, component]: -len(vertices)},
                upper=0,
            )

    for x in x_side:
        coefficients = {
            selected[e, component]: 1
            for e in incident[x]
            for component in (0, 1)
        }
        required = 1 if x in ports else 2
        model.constraint(coefficients, lower=required, upper=required)
    for y in y_vertices:
        coefficients = {
            selected[e, component]: 1
            for e in incident[y]
            for component in (0, 1)
        }
        model.constraint(coefficients, lower=1, upper=2)

    component_roots = (singleton_port, paired_ports[0])
    for component, component_root in enumerate(component_roots):
        for vertex in vertices:
            coefficients = defaultdict(float)
            for other in graph[vertex]:
                if other == root:
                    continue
                coefficients[flow[other, vertex, component]] += 1
                coefficients[flow[vertex, other, component]] -= 1
            if vertex == component_root:
                coefficients = {column: -value for column, value in coefficients.items()}
                for other in vertices:
                    if other != component_root:
                        coefficients[assigned[other, component]] = (
                            coefficients.get(assigned[other, component], 0) - 1
                        )
                model.constraint(coefficients, lower=0, upper=0)
            else:
                coefficients[assigned[vertex, component]] -= 1
                model.constraint(coefficients, lower=0, upper=0)

    result = model.solve()
    if result.status == 2:
        return None, {"status": "infeasible", "message": result.message}
    if not result.success:
        return None, {"status": "undecided", "message": result.message}
    forest = tuple(
        e
        for e in edges
        if sum(result.x[selected[e, component]] for component in (0, 1)) > 0.5
    )
    return forest, {"status": "feasible", "message": result.message}


def verify_forest(graph, root, singleton_port, forest):
    colour = nx.bipartite.color(graph)
    y_side = {v for v in graph if colour[v] == colour[root]}
    x_side = set(graph) - y_side
    ports = tuple(sorted(graph[root]))
    fibre = ports.index(singleton_port)
    selected = nx.Graph()
    selected.add_nodes_from(set(graph) - {root})
    selected.add_edges_from(forest)
    assert nx.is_forest(selected) and nx.number_connected_components(selected) == 2
    components = tuple(frozenset(c) for c in nx.connected_components(selected))
    blocks = tuple(
        frozenset(i for i, port in enumerate(ports) if port in component)
        for component in components
    )
    assert sorted(map(len, blocks)) == [1, 2] and frozenset((fibre,)) in blocks
    for x in x_side:
        assert selected.degree(x) == (1 if x in ports else 2)
    y_order = tuple(sorted(y_side - {root}))
    vector = tuple(selected.degree(y) for y in y_order)
    assert vector.count(1) == 1 and vector.count(2) == len(vector) - 1
    return {
        "fibre": fibre,
        "ports": ports,
        "y_order": y_order,
        "degree_vector": vector,
        "forest": tuple(sorted(forest)),
        "component_sizes": tuple(sorted(map(len, components))),
        "low_y": y_order[vector.index(1)],
    }


def main():
    graph_data = json.loads((HERE / "named_graph_data.json").read_text())
    output = []
    first_failure = None
    for graph_record in graph_data:
        result = {
            "name": graph_record["name"],
            "order": graph_record["order"],
            "graph6": graph_record["graph6"],
            "strict_hall": graph_record["strict_hall"],
            "tests": [],
        }
        output.append(result)
        if not graph_record["strict_hall"]["brace"]:
            print(graph_record["name"], "not_brace", flush=True)
            continue
        graph = nx.from_graph6_bytes(graph_record["graph6"].encode())
        orbit_records = graph_record["root_port_orbits"]
        for root_index, orbit_record in enumerate(orbit_records, 1):
            root = orbit_record["root"]
            for port_orbit in orbit_record["port_orbits"]:
                singleton_port = port_orbit[0]
                forest, solver = two_path_milp(graph, root, singleton_port)
                certificate = (
                    verify_forest(graph, root, singleton_port, forest)
                    if forest is not None
                    else None
                )
                test = {
                    "root": root,
                    "root_orbit": orbit_record["root_orbit"],
                    "singleton_port": singleton_port,
                    "singleton_port_orbit": port_orbit,
                    "solver": solver,
                    "certificate": certificate,
                }
                result["tests"].append(test)
                print(
                    graph_record["name"],
                    f"root_orbit={root_index}/{len(orbit_records)}",
                    "root",
                    root,
                    "port",
                    singleton_port,
                    solver["status"],
                    flush=True,
                )
                if solver["status"] == "infeasible":
                    first_failure = (graph_record, test)
                    break
                if solver["status"] == "undecided":
                    first_failure = (graph_record, test)
                    break
            if first_failure:
                break
        if first_failure:
            break
    path = HERE / "named_graph_two_path_scipy_results.json"
    path.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print("output", path)
    if first_failure is None:
        print("NAMED_GRAPH_TWO_PATH_NO_FAILURE")
    else:
        print("NAMED_GRAPH_TWO_PATH_STOP", first_failure[0]["name"], first_failure[1])


if __name__ == "__main__":
    main()
