# A cubic parity obstruction to the transparent two-row factor

This note translates the factor conditions (T0)--(TU) from
splice-signature-analysis.md into ordinary matching language and decides
their simultaneous realizability. No graph enumeration is used.

## 1. Boundary rows as ordinary perfect matchings

Let \(B\) be a finite simple cubic graph with a facial square

\[
        b_0b_1b_2b_3b_0.
\]

Write

\[
 q_i=b_i b_{i+1}\qquad(i\pmod 4),
\]

and form the four-port factor by deleting the opposite edges \(q_0,q_2\).
A boundary row \(N\) has state \(S\) when it leaves precisely the ports in
\(S\) unmatched. The six possible states have the following exact
completion to ordinary perfect matchings of \(B\):

\[
\begin{array}{c|c}
S(N)&\text{ordinary perfect matching }P\\ \hline
\varnothing&P=N,\quad q_0,q_2\notin P\\
A_0=\{0,1\}&P=N\cup\{q_0\}\\
A_1=\{1,2\}&P=N\cup\{q_1\}\\
A_2=\{2,3\}&P=N\cup\{q_2\}\\
A_3=\{3,0\}&P=N\cup\{q_3\}\\
\Omega&P=N\cup\{q_0,q_2\}.
\end{array}
\tag{1}
\]

Conversely, deleting the displayed square edge or edges from \(P\) gives
the indicated row. Thus (1) is a bijection for each state.

For a perfect matching \(P\), put

\[
        F(P)=B-P.
\tag{2}
\]

Because \(B\) is cubic, \(F(P)\) is a spanning 2-factor.

## 2. Exact translation of cleanliness

A row is *clean* when its local complement after deleting \(q_0,q_2\)
has no closed cycle component. Formula (1) gives the following translations.

### State \(\varnothing\)

Here \(P=N\) avoids \(q_0,q_2\), so both deleted edges lie in \(F(P)\), and

\[
       C(N)=F(P)-\{q_0,q_2\}.
\tag{3}
\]

The row is clean exactly when every cycle of \(F(P)\) contains at least one
of \(q_0,q_2\). In particular:

- its complement pairing is \(01\mid23\) exactly when \(F(P)\) consists
  of two cycles, one containing \(q_0\) and the other containing \(q_2\);
- if \(F(P)\) is one Hamilton cycle containing both deleted edges, the row
  is also clean, with the pairing determined by their cyclic order.

Thus (T0) is precisely:

> There is a perfect matching \(P_0\) avoiding \(q_0,q_2\) such that
> \(F(P_0)\) has exactly two cycles, with \(q_0,q_2\) on different cycles.

### States \(A_0\) and \(A_2\)

For \(A_0\), write \(P=N\cup\{q_0\}\). Then

\[
       C(N)=F(P)-\{q_2\}.
\tag{4}
\]

Consequently \(N\) is clean exactly when \(F(P)\) is a Hamilton cycle.
The clean local complement is then the spanning Hamilton path from \(b_2\)
to \(b_3\). Equivalently:

> (T1) says that \(P_1=N_1\cup\{q_0\}\) is a perfect matching containing
> \(q_0\), avoiding \(q_2\), and its complement \(F(P_1)\) is a Hamilton
> cycle (necessarily containing \(q_2\)).

The \(A_2\) statement is the same with \(q_0,q_2\) interchanged.

### Cross states \(A_1\) and \(A_3\)

For \(A_1\), put \(P=N\cup\{q_1\}\). The local complement is

\[
       C(N)=\bigl(F(P)-\{q_0,q_2\}\bigr)\cup\{q_1\}.
\tag{5}
\]

The row is clean exactly when (5) is one spanning Hamilton path from
\(b_0\) to \(b_3\). For \(A_3\), the analogous graph

\[
       \bigl(F(P)-\{q_0,q_2\}\bigr)\cup\{q_3\}
\tag{6}
\]

must be one spanning Hamilton path from \(b_1\) to \(b_2\).

### State \(\Omega\)

Here \(P=N\cup\{q_0,q_2\}\), and the local complement is the whole 2-factor
\(F(P)\). It has no boundary endpoints and at least one closed cycle, so an
\(\Omega\)-row is never clean.

### The bond condition

Since \(N_0=P_0\) and \(N_1=P_1-\{q_0\}\),

\[
 N_0\mathbin\triangle N_1
   =(P_0\mathbin\triangle P_1)-\{q_0\}.
\tag{7}
\]

Therefore (TB), which requires one \(b_0b_1\)-path and no closed component,
is equivalent to

> \(P_0\mathbin\triangle P_1\) is one alternating cycle.

Finally, (TU) says that among all rows represented in (1), the only clean
ones are \(N_0,N_1\).

## 3. Cubic Hamilton-cycle parity

The following standard parity lemma is enough; neither planarity,
bipartiteness, nor 2-extendability is needed.

> **Cubic edge-parity lemma (Smith).** Every edge of a finite cubic graph
> lies in an even number of Hamilton cycles.

For completeness, fix an oriented edge \(e=v_1v_2\), and form a finite
auxiliary graph whose vertices are the oriented Hamilton paths

\[
       v_1,v_2,\ldots,v_n
\]

starting with \(e\). At the terminal vertex \(v_n\), one incident edge is
the last path edge and the other two are unused. For every unused edge
\(v_nv_i\) with \(i>1\), reverse the terminal segment to obtain the
lollipop neighbour

\[
       v_1,\ldots,v_i,v_n,v_{n-1},\ldots,v_{i+1}.
\]

This operation is an involution. Hence an auxiliary vertex has degree two
unless one of the two unused terminal edges is \(v_nv_1\), in which case it
has degree one. Degree-one auxiliary vertices are in bijection with
Hamilton cycles containing \(e\): close the path with \(v_nv_1\), and in
the reverse direction delete from the cycle the other cycle edge at
\(v_1\). A finite graph has an even number of odd-degree vertices, proving
the lemma.

## 4. T0 and T1 already contradict TU

Assume (T0) and (T1). Then

\[
       H_1:=F(P_1)
\]

is a Hamilton cycle containing \(q_2\). By the cubic edge-parity lemma,
there is a distinct Hamilton cycle \(H_2\ne H_1\) containing \(q_2\).
Let

\[
       P_2=E(B)\setminus E(H_2).
\]

This is a perfect matching because \(B\) is cubic. There are two cases.

1. If \(q_0\in H_2\), then \(P_2\) avoids both \(q_0,q_2\). Its
   state-\(\varnothing\) row is clean, because deleting \(q_0,q_2\) from
   the Hamilton cycle \(H_2\) leaves paths and no closed cycle. It is not
   \(N_0\), since \(F(P_0)\) has two cycles by (T0), whereas \(H_2\) is
   Hamiltonian.
2. If \(q_0\notin H_2\), then \(q_0\in P_2\) and \(q_2\notin P_2\).
   The row \(P_2-\{q_0\}\) has state \(A_0\), and its local complement
   \(H_2-\{q_2\}\) is a spanning \(b_2b_3\)-Hamilton path. Hence it is
   clean. It is not \(N_1\), because \(H_2\ne H_1\).

In either case there is a third clean row. Therefore:

\[
\boxed{\text{No finite cubic graph can satisfy (T0)--(TU).}}
\tag{8}
\]

More precisely, the implication

\[
       \text{(T0) + (T1)}\Longrightarrow
       \text{at least one clean row besides }N_0,N_1
\tag{9}
\]

already disproves (TU), independently of (TB), brace structure,
2-extendability, planarity, or bipartiteness. Here (T0) is used only in
the first case above to ensure that the new Hamilton-complement row is not
the designated two-cycle-complement row \(N_0\).

## 5. Exact remaining interface

The transparent uniqueness condition (TU) must be discarded. This does not
rule out the exact carrier-relative criterion (7) in
splice-signature-analysis.md: the parity-forced extra clean row may still
fail rooted admissibility after joining to the Note 154 carrier, or it may
be rooted but have no one-cycle bond join with \(M_3\) or \(M_4\).

Thus the next decision-relevant factor condition is not uniqueness of clean
rows. It is the weaker pair-relational statement:

> For every parity-forced extra clean row \(N'\), every carrier row \(R\)
> that forms a rooted complement join with \(N'\) has a multi-component
> bond join with both preserved targets.

This condition cannot be read from Hamiltonicity or 2-extendability alone.
It requires the row's complement pairing together with the two bond atoms
\(d(N',N_0)\) and \(d(N',N_1)\), joined against the fixed carrier atoms.
That is the precise missing interface after the cubic parity obstruction.
