#!/usr/bin/env python3
"""Exhaust the first possible orders for a T0--TU annular factor.

The search is deliberately bounded at order 12.  It streams every connected
simple cubic bipartite graph from nauty geng, retains the plane braces, and
tests every oriented facial-square opposite-edge cut for the exact clean-row
signature derived in splice-signature-analysis.md.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations
from pathlib import Path
import importlib.util
import json
import shutil
import subprocess

import networkx as nx


HERE = Path(__file__).resolve().parent
SCAN_PATH = HERE / "scan_minimal_cube_annular_splices.py"
SPEC = importlib.util.spec_from_file_location("annular_scan", SCAN_PATH)
assert SPEC is not None and SPEC.loader is not None
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)

Edge = tuple[int, int]
Matching = frozenset[Edge]


def generated_graphs(order: int):
    geng = shutil.which("geng")
    assert geng is not None, "nauty geng is required"
    process = subprocess.Popen(
        (geng, "-cqb", "-d3", "-D3", str(order)),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    assert process.stdout is not None
    for line in process.stdout:
        value = line.strip()
        if value:
            yield value, nx.from_graph6_bytes(value.encode())
    stderr = process.stderr.read() if process.stderr is not None else ""
    return_code = process.wait()
    assert return_code == 0, stderr


def is_brace(graph: nx.Graph, matchings: tuple[Matching, ...]) -> bool:
    if not nx.is_connected(graph) or not nx.is_bipartite(graph):
        return False
    planar, _embedding = nx.check_planarity(graph)
    if not planar or nx.node_connectivity(graph) < 3:
        return False
    independent_pairs = (
        frozenset((first, second))
        for first, second in combinations(
            (BASE.BASE.edge(*item) for item in graph.edges()), 2
        )
        if set(first).isdisjoint(second)
    )
    return all(any(pair <= matching for matching in matchings) for pair in independent_pairs)


def oriented_squares(graph: nx.Graph):
    planar, embedding = nx.check_planarity(graph)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    faces = BASE.BASE.plane_faces(embedding)
    seen = set()
    for face in faces:
        if len(face) != 4:
            continue
        for reflected in (face, tuple(reversed(face))):
            for shift in range(4):
                ports = tuple(reflected[(shift + index) % 4] for index in range(4))
                key = ports
                if key not in seen:
                    seen.add(key)
                    yield ports


def clean_rows(
    graph: nx.Graph, ports: tuple[int, ...]
) -> dict[str, list[tuple[Matching, tuple[tuple[int, ...], ...]]]]:
    cut = (BASE.BASE.edge(ports[0], ports[1]), BASE.BASE.edge(ports[2], ports[3]))
    pole = graph.copy()
    pole.remove_edges_from(cut)
    states = {
        "empty": tuple(),
        "omega": (0, 1, 2, 3),
        "A0": (0, 1),
        "A1": (1, 2),
        "A2": (2, 3),
        "A3": (3, 0),
    }
    result = {}
    for name, state in states.items():
        removed = {ports[index] for index in state}
        rows = BASE.BASE.enumerate_perfect_matchings(
            pole.subgraph(set(pole) - removed).copy()
        )
        entries = []
        for row in rows:
            complement = pole.copy()
            complement.remove_edges_from(row)
            pairing = []
            closed = False
            for component in nx.connected_components(complement):
                piece = complement.subgraph(component)
                endpoints = tuple(
                    index
                    for index, port in enumerate(ports)
                    if port in component and piece.degree(port) == 1
                )
                if endpoints:
                    pairing.append(endpoints)
                elif all(degree == 2 for _, degree in piece.degree()):
                    closed = True
            if not closed:
                entries.append((row, tuple(sorted(pairing))))
        result[name] = entries
    return result


def target_signature(
    graph: nx.Graph,
    ports: tuple[int, ...],
    rows: dict[str, list[tuple[Matching, tuple[tuple[int, ...], ...]]]],
) -> tuple[bool, int, dict[str, Counter]]:
    desired_empty = tuple(
        row for row, pairing in rows["empty"]
        if pairing == ((0, 1), (2, 3))
    )
    desired_a0 = tuple(
        row for row, pairing in rows["A0"]
        if pairing == ((2, 3),)
    )
    positive = False
    if len(desired_empty) == len(desired_a0) == 1:
        cut = (BASE.BASE.edge(ports[0], ports[1]), BASE.BASE.edge(ports[2], ports[3]))
        pole = graph.copy()
        pole.remove_edges_from(cut)
        difference = nx.edge_subgraph(pole, desired_empty[0] ^ desired_a0[0])
        positive = (
            nx.is_connected(difference)
            and {degree for _, degree in difference.degree()} == {1, 2}
            and {vertex for vertex, degree in difference.degree() if degree == 1}
            == {ports[0], ports[1]}
        )
    clean_count = sum(len(entries) for entries in rows.values())
    profile = {
        state: Counter(pairing for _row, pairing in entries)
        for state, entries in rows.items()
    }
    return positive and clean_count == 2, clean_count, profile


def main() -> None:
    orders = (8, 10, 12)
    summary = {}
    hits = []
    closest = []
    for order in orders:
        generated = plane = braces = oriented_cuts = positive_sites = 0
        clean_histogram = Counter()
        for graph6, graph in generated_graphs(order):
            generated += 1
            planar, _embedding = nx.check_planarity(graph)
            if not planar:
                continue
            plane += 1
            matchings = BASE.BASE.enumerate_perfect_matchings(graph)
            if not is_brace(graph, matchings):
                continue
            braces += 1
            for ports in oriented_squares(graph):
                oriented_cuts += 1
                rows = clean_rows(graph, ports)
                exact, clean_count, profile = target_signature(graph, ports, rows)
                desired_empty = sum(
                    count
                    for pairing, count in profile["empty"].items()
                    if pairing == ((0, 1), (2, 3))
                )
                desired_a0 = sum(
                    count
                    for pairing, count in profile["A0"].items()
                    if pairing == ((2, 3),)
                )
                if desired_empty == desired_a0 == 1:
                    # Recompute the bond bit independently of TU.
                    candidate_exact, _count, _profile = target_signature(graph, ports, rows)
                    # exact may be false only because extra clean rows; check TB directly.
                    n0 = next(row for row, pairing in rows["empty"] if pairing == ((0, 1), (2, 3)))
                    n1 = next(row for row, pairing in rows["A0"] if pairing == ((2, 3),))
                    cut = (BASE.BASE.edge(ports[0], ports[1]), BASE.BASE.edge(ports[2], ports[3]))
                    pole = graph.copy()
                    pole.remove_edges_from(cut)
                    difference = nx.edge_subgraph(pole, n0 ^ n1)
                    tb = (
                        nx.is_connected(difference)
                        and {degree for _, degree in difference.degree()} == {1, 2}
                        and {vertex for vertex, degree in difference.degree() if degree == 1}
                        == {ports[0], ports[1]}
                    )
                    if tb:
                        positive_sites += 1
                        clean_histogram[clean_count] += 1
                        closest.append(
                            {
                                "order": order,
                                "graph6": graph6,
                                "ports": ports,
                                "clean_rows": clean_count,
                                "profile": {
                                    state: {str(key): value for key, value in counts.items()}
                                    for state, counts in profile.items()
                                },
                            }
                        )
                if exact:
                    hits.append(
                        {"order": order, "graph6": graph6, "ports": ports}
                    )
        summary[order] = {
            "generated": generated,
            "plane": plane,
            "braces": braces,
            "oriented_square_cuts": oriented_cuts,
            "T0_T1_TB_sites": positive_sites,
            "clean_count_histogram_on_positive_sites": dict(sorted(clean_histogram.items())),
        }

    output = {
        "generator": "geng -cqb -d3 -D3 n",
        "orders": summary,
        "hits": hits,
        "minimum_clean_rows_on_positive_site": min(
            (item["clean_rows"] for item in closest), default=None
        ),
        "closest": closest,
    }
    (HERE / "clean_row_factor_through12.json").write_text(
        json.dumps(output, indent=2) + "\n"
    )
    print("summary", summary)
    print("hits", len(hits))
    print("minimum_clean_rows_on_positive_site", output["minimum_clean_rows_on_positive_site"])
    if hits:
        print("first_hit", hits[0])
    else:
        print("NO_T0_TU_FACTOR_THROUGH_12")


if __name__ == "__main__":
    main()
