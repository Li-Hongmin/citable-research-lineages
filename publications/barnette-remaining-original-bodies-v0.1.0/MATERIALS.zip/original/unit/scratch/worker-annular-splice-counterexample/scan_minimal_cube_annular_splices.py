#!/usr/bin/env python3
"""Test the minimum cube annular splice family around Note 154.

The base graph and rooted decoration are the fixed order-22 object from
Note 154.  A candidate is obtained by deleting one opposite edge-pair from
an unmarked facial square of the base, deleting one opposite edge-pair from
a facial square of a fresh cube, and joining the four exposed ports in
reverse cyclic order.  We test every unmarked base cut on which the two
matchings of the isolated mixed K2 have identical incidence, and also the
single mixed-state carrier cut singled out by the exact two-row boundary
signature.

This is deliberately a one-factor, one-splice finite experiment.  It does
not enumerate larger factors, repeated splices, or arbitrary order-30
Barnette graphs.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations
from pathlib import Path
import importlib.util
import json

import networkx as nx


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
VERIFY_PATH = (
    ROOT
    / "computations/bundles/crossing-bridge-star-counterexample"
    / "verify_order22_crossing_bridge_star_counterexample.py"
)
SPEC = importlib.util.spec_from_file_location("note154_verify", VERIFY_PATH)
assert SPEC is not None and SPEC.loader is not None
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)

Edge = tuple[int, int]
Matching = frozenset[Edge]


def cube(offset: int = 22) -> nx.Graph:
    graph = nx.Graph()
    graph.add_nodes_from(range(offset, offset + 8))
    for vertex in range(8):
        for bit in (1, 2, 4):
            neighbour = vertex ^ bit
            if vertex < neighbour:
                graph.add_edge(offset + vertex, offset + neighbour)
    return graph


def generic_brace_check(
    graph: nx.Graph, matchings: tuple[Matching, ...]
) -> tuple[bool, int]:
    if nx.number_of_selfloops(graph):
        return False, 0
    if len(graph) < 6 or graph.number_of_edges() != 3 * len(graph) // 2:
        return False, 0
    if set(dict(graph.degree()).values()) != {3}:
        return False, 0
    if not nx.is_connected(graph) or not nx.is_bipartite(graph):
        return False, 0
    planar, _embedding = nx.check_planarity(graph)
    if not planar or nx.node_connectivity(graph) < 3:
        return False, 0
    independent_pairs = tuple(
        frozenset((first, second))
        for first, second in combinations(
            (BASE.edge(*item) for item in graph.edges()), 2
        )
        if set(first).isdisjoint(second)
    )
    for pair in independent_pairs:
        if not any(pair <= matching for matching in matchings):
            return False, len(independent_pairs)
    return True, len(independent_pairs)


def generic_legal_wide_check(graph: nx.Graph) -> tuple[int, int] | None:
    """Check the actual root-square legal-wide inverse split.

    Unlike the fixed Note-154 verifier, this permits the annular splice to
    lengthen the gate face, so long as the two odd wide arcs and the inverse
    dual split remain valid.
    """
    planar, embedding = nx.check_planarity(graph)
    if not planar or not isinstance(embedding, nx.PlanarEmbedding):
        return None
    faces = BASE.plane_faces(embedding)
    if BASE.edge_set(BASE.ROOT_SQUARE) not in {BASE.edge_set(face) for face in faces}:
        return None
    witnesses = []
    for face_index, face in enumerate(faces):
        boundary = tuple(
            BASE.edge(face[index], face[(index + 1) % len(face)])
            for index in range(len(face))
        )
        if BASE.FORCED_GATE not in boundary or BASE.SURVIVING_GATE not in boundary:
            continue
        if BASE.ROOT in boundary:
            continue
        delta = (
            boundary.index(BASE.SURVIVING_GATE)
            - boundary.index(BASE.FORCED_GATE)
        ) % len(boundary)
        arcs = (delta + 1, len(boundary) - delta + 1)
        if min(arcs) >= 5 and all(length % 2 for length in arcs):
            witnesses.append((face_index, face, boundary, tuple(sorted(arcs))))
    if len(witnesses) != 1:
        return None
    gate_face_index, _gate_face, boundary_edges, arcs = witnesses[0]

    primal_edge_faces: dict[Edge, list[int]] = {}
    for face_index, face in enumerate(faces):
        for item in BASE.edge_set(face):
            primal_edge_faces.setdefault(item, []).append(face_index)
    if not all(len(indices) == 2 for indices in primal_edge_faces.values()):
        return None
    dual = nx.Graph()
    dual.add_nodes_from(range(len(faces)))
    dual.add_edges_from(tuple(indices) for indices in primal_edge_faces.values())
    if (
        dual.number_of_edges() != 3 * dual.number_of_nodes() - 6
        or set(degree % 2 for _, degree in dual.degree()) != {0}
        or nx.node_connectivity(dual) < 4
    ):
        return None

    first_index = boundary_edges.index(BASE.FORCED_GATE)
    second_index = boundary_edges.index(BASE.SURVIVING_GATE)
    if first_index > second_index:
        first_index, second_index = second_index, first_index
    rotation = []
    for item in boundary_edges:
        indices = primal_edge_faces[item]
        rotation.append(indices[0] if indices[1] == gate_face_index else indices[1])
    if len(rotation) != len(set(rotation)):
        return None
    left_arc = rotation[first_index : second_index + 1]
    right_arc = rotation[second_index:] + rotation[: first_index + 1]
    expanded = dual.copy()
    expanded.remove_node(gate_face_index)
    next_vertex = max(dual) + 1
    left, right, centre = next_vertex, next_vertex + 1, next_vertex + 2
    expanded.add_nodes_from((left, right, centre))
    expanded.add_edges_from((left, neighbour) for neighbour in left_arc)
    expanded.add_edges_from((right, neighbour) for neighbour in right_arc)
    expanded.add_edges_from(
        (
            (centre, left),
            (centre, left_arc[0]),
            (centre, right),
            (centre, left_arc[-1]),
        )
    )
    if nx.number_of_selfloops(expanded):
        return None
    if expanded.number_of_edges() != 3 * expanded.number_of_nodes() - 6:
        return None
    if set(degree % 2 for _, degree in expanded.degree()) != {0}:
        return None
    expanded_planar, expanded_embedding = nx.check_planarity(expanded)
    if not expanded_planar or not isinstance(expanded_embedding, nx.PlanarEmbedding):
        return None
    if any(len(face) != 3 for face in BASE.plane_faces(expanded_embedding)):
        return None
    if nx.node_connectivity(expanded) < 4:
        return None
    return arcs


def opposite_pair(face: tuple[int, ...], parity: int) -> tuple[Edge, Edge]:
    assert len(face) == 4 and parity in {0, 1}
    return (
        BASE.edge(face[parity], face[(parity + 1) % 4]),
        BASE.edge(face[(parity + 2) % 4], face[(parity + 3) % 4]),
    )


def ports_for_pair(face: tuple[int, ...], parity: int) -> tuple[int, ...]:
    return tuple(face[(parity + index) % 4] for index in range(4))


def splice(
    base: nx.Graph,
    base_face: tuple[int, ...],
    base_parity: int,
    shift: int,
) -> tuple[nx.Graph, tuple[Edge, ...], tuple[Edge, Edge], tuple[Edge, Edge]]:
    factor = cube()
    factor_face = (22, 23, 25, 24)  # 0,1,3,2 in binary cube coordinates
    factor_parity = 0
    base_cut = opposite_pair(base_face, base_parity)
    factor_cut = opposite_pair(factor_face, factor_parity)
    base_ports = ports_for_pair(base_face, base_parity)
    factor_ports = ports_for_pair(factor_face, factor_parity)

    graph = nx.compose(base, factor)
    graph.remove_edges_from(base_cut)
    graph.remove_edges_from(factor_cut)
    connectors = tuple(
        BASE.edge(base_ports[index], factor_ports[(shift - index) % 4])
        for index in range(4)
    )
    graph.add_edges_from(connectors)
    return graph, connectors, base_cut, factor_cut


def exchange_data(
    graph: nx.Graph, family: tuple[Matching, ...]
) -> tuple[nx.Graph, frozenset[int], frozenset[tuple[int, int]]]:
    exchange = nx.Graph()
    exchange.add_nodes_from(range(len(family)))
    for first in range(len(family)):
        for second in range(first + 1, len(family)):
            difference = family[first] ^ family[second]
            if not difference:
                continue
            subgraph = nx.edge_subgraph(graph, difference)
            if (
                set(dict(subgraph.degree()).values()) == {2}
                and nx.is_connected(subgraph)
            ):
                exchange.add_edge(first, second, cycle_length=len(difference))
    sectors = frozenset(
        index
        for index, matching in enumerate(family)
        if BASE.SURVIVING_GATE in matching
    )
    crossings = frozenset(
        tuple(sorted((first, second)))
        for first, second in exchange.edges()
        if (first in sectors) != (second in sectors)
    )
    return exchange, sectors, crossings


def lifted_base_index(
    matching: Matching,
    base_matching: Matching,
    base_cut: tuple[Edge, Edge],
) -> bool:
    base_edges = frozenset(
        edge for edge in matching if edge[0] < 22 and edge[1] < 22
    )
    return base_edges == base_matching - frozenset(base_cut)


def marked_complement_signature(
    graph: nx.Graph,
    matching: Matching,
    face: tuple[int, ...],
    parity: int,
) -> tuple[tuple[tuple[int, ...], tuple[int, ...]], ...]:
    """Port partition and root marks after cutting two complement edges.

    Component lengths are deliberately forgotten: annular gluing sees the
    terminal partition, closed components, and the two ordered root marks.
    """
    ports = ports_for_pair(face, parity)
    cut = opposite_pair(face, parity)
    complement = graph.copy()
    complement.remove_edges_from(matching)
    complement.remove_edges_from(cut)
    root_order = {vertex: index for index, vertex in enumerate(BASE.ROOT)}
    signature = []
    for component in nx.connected_components(complement):
        port_indices = tuple(
            index for index, vertex in enumerate(ports) if vertex in component
        )
        root_marks = tuple(
            root_order[vertex] for vertex in BASE.ROOT if vertex in component
        )
        signature.append((port_indices, root_marks))
    return tuple(sorted(signature))


def cube_clean_boundary_profile() -> tuple[dict[str, Counter], bool]:
    factor = cube()
    face = (22, 23, 25, 24)
    cut = opposite_pair(face, 0)
    ports = ports_for_pair(face, 0)
    pole = factor.copy()
    pole.remove_edges_from(cut)
    states = {
        "empty": tuple(),
        "omega": (0, 1, 2, 3),
        "A0": (0, 1),
        "A1": (1, 2),
        "A2": (2, 3),
        "A3": (3, 0),
    }
    profile: dict[str, Counter] = {}
    clean_rows: dict[str, list[tuple[Matching, tuple[tuple[int, ...], ...]]]] = {}
    for name, state in states.items():
        removed = {ports[index] for index in state}
        rows = BASE.enumerate_perfect_matchings(pole.subgraph(set(pole) - removed).copy())
        entries = []
        for row in rows:
            complement = pole.copy()
            complement.remove_edges_from(row)
            pairing = []
            closed = False
            for component in nx.connected_components(complement):
                piece = complement.subgraph(component)
                endpoints = tuple(
                    index
                    for index, port in enumerate(ports)
                    if port in component and piece.degree(port) == 1
                )
                if endpoints:
                    pairing.append(endpoints)
                elif all(degree == 2 for _, degree in piece.degree()):
                    closed = True
            if not closed:
                entries.append((row, tuple(sorted(pairing))))
        clean_rows[name] = entries
        profile[name] = Counter(pairing for _row, pairing in entries)

    desired_empty = tuple(
        row for row, pairing in clean_rows["empty"]
        if pairing == ((0, 1), (2, 3))
    )
    desired_a0 = tuple(
        row for row, pairing in clean_rows["A0"]
        if pairing == ((2, 3),)
    )
    assert len(desired_empty) == len(desired_a0) == 1
    difference = nx.edge_subgraph(pole, desired_empty[0] ^ desired_a0[0])
    bond_ok = (
        nx.is_connected(difference)
        and {degree for _, degree in difference.degree()} == {1, 2}
        and {vertex for vertex, degree in difference.degree() if degree == 1}
        == {ports[0], ports[1]}
    )
    return profile, bond_ok


def main() -> None:
    base = nx.from_graph6_bytes(BASE.GRAPH6.encode())
    cube_profile, cube_target_bond = cube_clean_boundary_profile()
    assert cube_profile == {
        "empty": Counter({((0, 3), (1, 2)): 3, ((0, 1), (2, 3)): 1}),
        "omega": Counter(),
        "A0": Counter({((2, 3),): 1}),
        "A1": Counter({((0, 3),): 1}),
        "A2": Counter({((0, 1),): 1}),
        "A3": Counter({((1, 2),): 1}),
    }
    assert cube_target_bond
    base_matchings = BASE.enumerate_perfect_matchings(base)
    base_family = tuple(
        sorted(
            (matching for matching in base_matchings if BASE.is_rooted_target(base, matching)),
            key=BASE.matching_key,
        )
    )
    assert len(base_family) == 8
    isolated_first, isolated_second = base_family[3], base_family[4]

    planar, embedding = nx.check_planarity(base)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    faces = BASE.plane_faces(embedding)
    marked_face_edges = BASE.edge_set(BASE.ROOT_SQUARE) | BASE.edge_set(BASE.GATE_FACE)
    eligible: list[tuple[tuple[int, ...], int, tuple[Edge, Edge], tuple[bool, bool]]] = []
    for face in faces:
        if len(face) != 4:
            continue
        for parity in (0, 1):
            cut = opposite_pair(face, parity)
            if marked_face_edges & frozenset(cut):
                continue
            first_pattern = tuple(edge in isolated_first for edge in cut)
            second_pattern = tuple(edge in isolated_second for edge in cut)
            if first_pattern != second_pattern:
                continue
            eligible.append((face, parity, cut, first_pattern))

    # The four cuts are the exact canonical-lift preserving unmarked square cuts.
    assert len(eligible) == 4
    by_cut = {frozenset(cut): (face, parity, pattern) for face, parity, cut, pattern in eligible}
    cut_zero = frozenset((BASE.edge(1, 12), BASE.edge(0, 11)))
    cut_one = frozenset((BASE.edge(1, 14), BASE.edge(2, 11)))
    cut_two = frozenset((BASE.edge(2, 14), BASE.edge(1, 11)))
    cut_three = frozenset((BASE.edge(4, 15), BASE.edge(7, 16)))
    assert set(by_cut) == {cut_zero, cut_one, cut_two, cut_three}
    face_zero, parity_zero, _ = by_cut[cut_zero]
    face_one, parity_one, _ = by_cut[cut_one]
    face_three, parity_three, _ = by_cut[cut_three]
    signatures_zero = tuple(
        marked_complement_signature(base, matching, face_zero, parity_zero)
        for matching in base_family
    )
    signatures_one = tuple(
        marked_complement_signature(base, matching, face_one, parity_one)
        for matching in base_family
    )
    signatures_three = tuple(
        marked_complement_signature(base, matching, face_three, parity_three)
        for matching in base_family
    )
    assert signatures_zero[3] == signatures_zero[4]
    assert signatures_zero[5] == signatures_zero[7] != signatures_zero[3]
    assert signatures_one[3] == signatures_one[4]
    assert signatures_one[0] == signatures_one[2] != signatures_one[3]
    assert len(set(signatures_three)) == 1
    records = []
    carrier_face = next(face for face in faces if BASE.edge_set(face) == BASE.edge_set((9, 19, 10, 21)))
    carrier_parity = next(
        parity
        for parity in (0, 1)
        if frozenset(opposite_pair(carrier_face, parity))
        == frozenset((BASE.edge(10, 19), BASE.edge(9, 21)))
    )
    carrier_cut = opposite_pair(carrier_face, carrier_parity)
    carrier_patterns = tuple(
        tuple(item in matching for item in carrier_cut)
        for matching in (isolated_first, isolated_second)
    )
    assert carrier_patterns == ((False, False), (True, False))
    candidates = [
        ("common", face, parity, cut, (pattern, pattern))
        for face, parity, cut, pattern in eligible
    ] + [("carrier", carrier_face, carrier_parity, carrier_cut, carrier_patterns)]

    for cut_index, (kind, face, parity, cut, patterns) in enumerate(candidates):
        for shift in range(4):
            graph, connectors, base_cut, factor_cut = splice(base, face, parity, shift)
            matchings = BASE.enumerate_perfect_matchings(graph)
            brace, independent_pairs = generic_brace_check(graph, matchings)
            legal_wide_arcs = None
            if brace:
                legal_wide_arcs = generic_legal_wide_check(graph)
            family: tuple[Matching, ...] = tuple()
            crossings: frozenset[tuple[int, int]] = frozenset()
            exchange = nx.Graph()
            sectors: frozenset[int] = frozenset()
            lifted_first: tuple[int, ...] = tuple()
            lifted_second: tuple[int, ...] = tuple()
            isolated_lift_edges: tuple[tuple[int, int], ...] = tuple()
            if brace and legal_wide_arcs is not None:
                family = tuple(
                    sorted(
                        (matching for matching in matchings if BASE.is_rooted_target(graph, matching)),
                        key=BASE.matching_key,
                    )
                )
                exchange, sectors, crossings = exchange_data(graph, family)
                lifted_first = tuple(
                    index
                    for index, matching in enumerate(family)
                    if lifted_base_index(matching, isolated_first, base_cut)
                )
                lifted_second = tuple(
                    index
                    for index, matching in enumerate(family)
                    if lifted_base_index(matching, isolated_second, base_cut)
                )
                isolated_lift_edges = tuple(
                    sorted(
                        (first, second)
                        for first in lifted_first
                        for second in lifted_second
                        if exchange.has_edge(first, second)
                        and exchange.degree(first) == 1
                        and exchange.degree(second) == 1
                        and ((first in sectors) != (second in sectors))
                    )
                )
            records.append(
                {
                    "cut_index": cut_index,
                    "kind": kind,
                    "base_face": face,
                    "base_parity": parity,
                    "base_cut": base_cut,
                    "base_patterns": patterns,
                    "shift": shift,
                    "factor_cut": factor_cut,
                    "connectors": connectors,
                    "order": len(graph),
                    "perfect_matchings": len(matchings),
                    "brace": brace,
                    "independent_edge_pairs": independent_pairs,
                    "legal_wide_arcs": legal_wide_arcs,
                    "rooted_family": len(family),
                    "sector_sizes": (len(family) - len(sectors), len(sectors)),
                    "exchange_edges": exchange.number_of_edges(),
                    "crossings": len(crossings),
                    "crossing_edges": tuple(sorted(crossings)),
                    "components": tuple(sorted(len(item) for item in nx.connected_components(exchange))),
                    "lifted_first": lifted_first,
                    "lifted_second": lifted_second,
                    "isolated_lift_edges": isolated_lift_edges,
                }
            )

    assert len(records) == 20
    assert all(record["brace"] and record["legal_wide_arcs"] for record in records)
    common_records = tuple(record for record in records if record["kind"] == "common")
    carrier_records = tuple(record for record in records if record["kind"] == "carrier")
    assert len(common_records) == 16 and len(carrier_records) == 4
    assert Counter(record["rooted_family"] for record in common_records) == {
        8: 2, 16: 2, 18: 2, 20: 4, 24: 6
    }
    assert Counter(record["crossings"] for record in common_records) == {
        3: 2, 7: 8, 9: 6
    }
    assert Counter(record["rooted_family"] for record in carrier_records) == {16: 2, 22: 2}
    assert Counter(record["crossings"] for record in carrier_records) == {3: 2, 7: 2}
    one_crossing = tuple(record for record in records if record["crossings"] == 1)
    preserved_isolated = tuple(record for record in records if record["isolated_lift_edges"])

    output_path = HERE / "minimal_cube_annular_splice_records.json"
    output_path.write_text(json.dumps(records, indent=2) + "\n")

    print("eligible_base_cuts", len(eligible))
    print("cube_clean_boundary_profile", {
        state: {str(pairing): count for pairing, count in counts.items()}
        for state, counts in cube_profile.items()
    })
    print("cube_target_T0_T1_TB", cube_target_bond, "cube_TU", False)
    for index, (_face, _parity, cut, pattern) in enumerate(eligible):
        print(f"cut_{index}={cut} incidence={pattern}")
    print("decision_carrier_cut", carrier_cut, "patterns", carrier_patterns)
    print("labelled_splices", len(records))
    print("rooted_family_histogram", dict(sorted(Counter(record["rooted_family"] for record in records).items())))
    print("crossing_histogram", dict(sorted(Counter(record["crossings"] for record in records).items())))
    print("component_profile_histogram", {
        str(key): value
        for key, value in sorted(Counter(record["components"] for record in records).items())
    })
    print("preserved_isolated_k2", len(preserved_isolated))
    print("preserved_isolated_profiles", tuple(
        (record["cut_index"], record["shift"], record["crossings"], record["components"])
        for record in preserved_isolated
    ))
    print("one_crossing", len(one_crossing))
    assert not one_crossing
    print("MINIMAL_CUBE_ANNULAR_SPLICE_NO_ONE_CROSSING")


if __name__ == "__main__":
    main()
