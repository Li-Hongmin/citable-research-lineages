# The minimum annular factor does not isolate the Note 154 crossing

This scratch result tests one precise nonlocal replacement family and no
larger parameter range.  The base is the fixed order-22 legal-wide
root-square brace of Note 154.  The target component is its isolated mixed
component \(M_3M_4\).  We perform one facial four-port annular splice with
the cube, while preserving the root square and the full structural
legal-wide condition.  The splice may lengthen the gate face.

The cube is the unique minimum simple plane cubic bipartite brace that can
serve as a factor: order six would force \(K_{3,3}\), while at order eight a
3-regular bipartite graph with bipartition \(4+4\) is the cube.  Thus this is
the minimum genuine brace-factor splice family, not an arbitrary order-30
sample.

## 1. Exact base boundary filter

For a facial square with cyclic ports \((p_0,p_1,p_2,p_3)\), delete the
opposite pair

\[
 p_0p_1,\qquad p_2p_3.
\]

To carry the displayed Note 154 endpoints through the splice with the same
base restriction, the two endpoints must have identical incidence on these
two deleted edges.  The deleted edges must also avoid every edge of the
marked root square and gate face.  Directly from the two literal matchings
and the unique plane embedding, exactly four cuts remain:

\[
\begin{array}{c|c|c}
i&\text{deleted base edges}&
 (\mathbf 1_{M_3},\mathbf 1_{M_4})\\ \hline
0&(1\!-\!12,0\!-\!11)&(00,00)\\
1&(1\!-\!14,2\!-\!11)&(00,00)\\
2&(2\!-\!14,1\!-\!11)&(11,11)\\
3&(4\!-\!15,7\!-\!16)&(00,00).
\end{array}
\tag{1}
\]

This table is already a useful analytic obstruction.

For cut 2, preserving either base matching requires all four connector
edges.  The complement then contains the nonempty two-factor of the cube
factor as a union of closed components disconnected from both original root
cycles.  Hence no such canonical lift is a rooted two-cycle target.  The
only 2-bit cut that separates \(M_3M_4\) from both old compensating
crossings is therefore unusable.

For cut 3, every one of the eight base rooted targets has incidence 00 and
the same marked port partition: one deleted complement edge lies on each
root cycle.  Any fixed factor row that lifts \(M_3,M_4\) also lifts all
eight base rows, and using the same factor row leaves every base symmetric
difference unchanged.  It therefore preserves all three old crossings,
not only \(M_3M_4\).

Cuts 0 and 1 are the only *common-state* boundary signatures that can still
distinguish the isolated component from one old compensating component.

There is a sharper mixed-state carrier cut.  On the facial square

\[
(9,19,10,21)
\]

delete \(10\!-\!19\) and \(9\!-\!21\), with cyclic ports
\((19,10,21,9)\).  Then \(M_3\) has connector state \(\varnothing\), while
\(M_4\) has state \(A_0=\{0,1\}\).  The eight old target states are

\[
\Omega,\varnothing,\varnothing,\varnothing,
A_0,\Omega,\varnothing,\varnothing.
\tag{2}
\]

If a factor has exactly two clean boundary rows—one state-
\(\varnothing\) row with complement pairing \(01\mid23\), and one
state-\(A_0\) row whose complement is a single \(b_2b_3\)-path—and their
symmetric difference is one \(b_0b_1\)-path, then the splice retains
exactly old targets \(1,2,3,4,6,7\).  Its exchange graph is

\[
\{16,27,34\},
\tag{3}
\]

where the first two edges are monochromatic and \(34\) is the unique
crossing.  This is the decision-relevant factor signature.  The exact
necessary-and-sufficient version, allowing extra rows, is the row/pair atom
join criterion in `splice-signature-analysis.md`.

## 2. Complete minimum-factor splice family

Fix a facial square and opposite pair in the cube.  Cube automorphisms are
transitive on oriented facial squares, so there is no second factor choice.
Gluing two boundary circles noncrossingly maps the four cube ports to the
base ports in reverse cyclic order, with four possible cyclic shifts.
Together with the four common-state cuts in (1), this first gives

\[
4\cdot4=16
\tag{4}
\]

labelled minimum-factor splices.  We additionally test all four shifts at
the mixed-state carrier cut above, giving twenty candidates in total.

For every candidate the verifier independently enumerates all perfect
matchings and checks simplicity, planarity, cubicity, bipartiteness,
3-connectivity, extension of every independent edge pair, the facial root
square, the two odd wide gate arcs, and the exact inverse-dual legal-wide
split.  It then
reconstructs the complete rooted fixed-pairing family and its complete
single-cycle exchange graph.

All twenty candidates remain legal-wide braces.  Their combined
rooted-family and crossing distributions are

\[
\begin{aligned}
|\mathcal T_e| &: 8^2,16^4,18^2,20^4,22^2,24^6,\\
|E\Gamma_{g_1}(\mathcal T_e)| &: 3^4,7^{10},9^6.
\end{aligned}
\tag{5}
\]

In particular, no candidate has one crossing.  Eight candidates retain a
literal isolated mixed \(K_2\) lift of \(M_3M_4\).  Their profiles are

\[
\begin{array}{c|c|c|c}
\text{cut}&\text{shift}&\text{crossings}&
 \text{exchange-component orders}\\ \hline
0&1,3&7&(2,18)\\
1&1,3&7&(2,18)\\
3&1,3&3&(2,6)\\
\text{mixed carrier}&1,3&3&(2,14).
\end{array}
\tag{6}
\]

Thus even when the target \(K_2\) survives literally, the minimum factor
never eliminates all remote compensation.  At cut 3 the two odd shifts are
fully transparent: the complete rooted family and its \(2+6\) exchange
component decomposition are exactly the original Note 154 family.  More
importantly, the cube also fails the purpose-built mixed-state signature:
its odd shifts keep the target isolated \(K_2\), but a second component
still contributes two crossings.

The failure is exact at the boundary-row level.  The cube does satisfy the
three positive target conditions: it has a unique clean
state-\(\varnothing\) row with pairing \(01\mid23\), a unique clean
state-\(A_0\) row, and their difference is the required single
\(b_0b_1\)-path.  It fails only the exclusion condition.  Its full clean-row
profile is

\[
\begin{array}{c|c}
\text{state}&\text{clean complement pairings}\\ \hline
\varnothing&(03\mid12)^3,(01\mid23)^1\\
\Omega&\varnothing\\
A_0&(23)^1\\
A_1&(03)^1\\
A_2&(01)^1\\
A_3&(12)^1.
\end{array}
\tag{7}
\]

Thus the minimum factor reaches the desired two rows but necessarily brings
six additional clean rows.  Those rows, rather than a failure of the
target bond atom, are exactly where the extra rooted component enters.

## 3. Exact boundary and missing interface

The conclusion is deliberately limited:

> A single standard facial annular splice of the Note 154 brace with the
> unique minimum brace factor, tested both on every common-state square cut
> that canonically carries the isolated mixed \(K_2\) and on the exact
> mixed-state carrier cut that would produce one crossing under a two-clean-
> row factor signature, cannot produce a one-crossing rooted family.

This is not a general annular-splice impossibility theorem.  A successful
factor must be larger than the cube.  The most direct route is now the
mixed-state carrier cut: its root-marked four-port rows must do three things
simultaneously:

1. supply the clean \(\varnothing\) row with pairing \(01\mid23\);
2. supply the clean \(A_0\) row and their single-path bond atom; and
3. either have no other clean rows, or make every additional rooted join
   nonadjacent to both lifted target endpoints.

That coupled boundary-row/exchange requirement is the first missing
interface.  Cut 2 is ruled out by the closed-factor-complement obstruction,
cut 3 is ruled out by complete-signature transparency, and the cube fails
the purpose-built carrier signature.  Repeating cube splices or scanning
arbitrary order 30 would not test this missing interface; the next useful
object is a larger factor constructed or excluded directly from its clean
row and pairwise bond atoms.

## 4. Reproduction

From the AIMath root:

```bash
uv run --python 3.14 --with 'networkx==3.6.1' \
  units/barnette/scratch/worker-annular-splice-counterexample/scan_minimal_cube_annular_splices.py
```

The terminal marker is

```text
MINIMAL_CUBE_ANNULAR_SPLICE_NO_ONE_CROSSING
```

The complete twenty records are written to
`minimal_cube_annular_splice_records.json`.  This remains scratch evidence;
no permanent note or README is changed.
