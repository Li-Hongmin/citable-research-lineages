# Exact boundary signature for preserving the isolated mixed pair

This note only analyses one four-port annular splice of the fixed graph in
Note 154. It does not enumerate splices or assert that the required second
factor exists.

## 1. The useful carrier cut

Write the carrier graph of Note 154 as \(G\), with its eight rooted targets
\(M_0,\ldots,M_7\) in the verifier order. Besides the root and gate faces,
\(G\) has the facial square

\[
        (9,19,10,21).
\]

Delete its opposite edges

\[
 h_0=19\!-\!10,\qquad h_2=21\!-\!9,
\tag{1}
\]

and put the four carrier ports in cyclic order

\[
        (a_0,a_1,a_2,a_3)=(19,10,21,9).
\tag{2}
\]

This is the distinguished cut because

\[
 h_0,h_2\notin M_3,\qquad h_0\in M_4,\quad h_2\notin M_4.
\tag{3}
\]

Thus the two target states at the cut are respectively

\[
 S(M_3)=\varnothing,\qquad S(M_4)=A_0:=\{0,1\}.
\tag{4}
\]

The cut does not delete the root, forced gate, or surviving gate. It is
also the only one of the immediately useful common/mixed cuts whose simple
state filter can delete both old compensating crossings; see Section 5.

Let \(B\) be a second plane cubic bipartite factor with facial square
\((b_0,b_1,b_2,b_3)\). Delete \(b_0b_1,b_2b_3\), and, after absorbing any
allowed cyclic shift into the \(b_i\) labels, add the four noncrossing
connectors \(a_i b_i\).

## 2. The exact row and pair atoms

A boundary row \(N\) of \(B\) is a matching in
\(B-\{b_0b_1,b_2b_3\}\) which covers every vertex except the ports indexed
by a set \(S(N)\subseteq[4]\). Those and only those connectors are then
used by the spliced perfect matching. Bipartite balance restricts the
state to

\[
 \varnothing,\ \Omega,\ A_0,\ A_1,\ A_2,\ A_3,
 \qquad A_i=\{i,i+1\}\pmod 4.
\tag{5}
\]

Two pieces of boundary information are relevant.

1. The **complement atom** \(c(N)\) is the partition of the ports in
   \([4]\setminus S(N)\) induced by the path components of

   \[
      (B-\{b_0b_1,b_2b_3\})-N,
   \tag{6}
   \]

   together with the number of its closed cycle components. Call \(N\)
   *clean* when this number is zero.
2. For two rows \(N,N'\), the **bond atom** \(d(N,N')\) is the partition
   of \(S(N)\mathbin\triangle S(N')\) induced by the path components of
   \(N\mathbin\triangle N'\), together with the number of its closed
   alternating-cycle components.

The same atoms are defined on the carrier shore, with the four root-square
attachments and their prescribed pairing added as marks to the complement
atom. A carrier row and a \(B\)-row form a rooted target exactly when their
states agree and the two complement atoms, joined through the unused
connectors, have precisely the two prescribed root blocks and no unmarked
closed block. Two such targets are exchange-adjacent exactly when their two
bond atoms, joined through the connectors in the state symmetric difference,
form one alternating cycle. The surviving-gate bit says whether that edge
is a crossing.

Consequently the following is a necessary-and-sufficient boundary criterion
for an arbitrary second factor. Let \(\mathcal J\) be all joined row pairs
passing the complement test, and let \(X_3,X_4\in\mathcal J\) use the fixed
carrier rows \(M_3-\{h_0,h_2\}\) and
\(M_4-\{h_0,h_2\}\). Then the old pair survives as an isolated mixed
component if and only if

\[
\begin{split}
 &X_3,X_4\in\mathcal J,\\
 &d_G(X_3,X_4)\vee d_B(X_3,X_4)
       \text{ is one cycle},\\
 &\bigl[d_G(X_i,Y)\vee d_B(X_i,Y)
       \text{ is one cycle}\bigr]
       \iff Y=X_{7-i}
\end{split}
\tag{7}
\]

for \(i=3,4\) and every \(Y\in\mathcal J\). Here \(\vee\) is the literal
partition join along the relevant connector stubs. The two endpoints have
opposite surviving-gate bits already in the carrier.

Formula (7) uses no triple-row information. Conversely, row states and
complement atoms alone cannot decide its last two lines: pairings and closed
components of a symmetric difference can change while every one-row atom is
fixed. Thus, in the predicate-dependency sense, the minimum exact signature
is

\[
 \boxed{\text{row identities + state/gate bit + complement atoms
        + all pairwise bond atoms}.}
\tag{8}
\]

This is the one-splice specialization of the row/pair closure principle of
Note 132. It is an exact criterion, not yet a convenient realization
theorem.

## 3. The two target atoms specialize sharply

The carrier complement partitions can be read directly from the literal
matchings in Note 154. Let \(t_0,t_1,t_2,t_3\) denote the attachments at
the root-square vertices \(4,16,5,13\), so the required pairs are
\(t_0t_3\mid t_1t_2\).

After deleting the root square, (1), and \(M_3\), the nontrivial marked
components are

\[
 t_0t_3,\qquad a_1a_2,\qquad t_1a_0,\qquad t_2a_3.
\tag{9}
\]

Planarity permits only the two noncrossing pairings of four \(B\)-ports.
Exactly

\[
       b_0b_1\mid b_2b_3
\tag{10}
\]

joins (9) to the prescribed two root paths without creating a closed
component. The other noncrossing pairing \(b_0b_3\mid b_1b_2\) closes the
unmarked carrier path \(a_1a_2\) into a cycle.

For \(M_4\), the ports \(a_0,a_1\) use connectors. Its carrier complement
has marked components

\[
       t_0t_3,\qquad t_1a_2,\qquad t_2a_3;
\tag{11}
\]

\(a_1\) lies internally in the second component and \(a_0\) internally in
the third. Hence a clean \(A_0\)-row, necessarily one path from \(b_2\) to
\(b_3\), gives the required target.

Finally, deleting \(h_0\) cuts the old ten-cycle
\(M_3\mathbin\triangle M_4\) into one \(a_0a_1\)-path. Therefore the two
lifted targets remain adjacent if and only if the auxiliary bond atom is

\[
       d(N_0,N_1)=\text{one }b_0b_1\text{-path and no closed cycle},
\tag{12}
\]

where \(S(N_0)=\varnothing\) and \(S(N_1)=A_0\).

Equations (10)--(12) are the irreducible target-preservation part of (7):
dropping (10) loses \(M_3\), dropping the clean \(b_2b_3\)-path loses
\(M_4\), and dropping (12) loses their exchange edge.

## 4. A transparent two-row sufficient signature

There is a particularly useful carrier-independent sufficient condition on
the second factor:

\[
\begin{array}{ll}
\text{(T0)}&N_0\text{ is a clean state-}\varnothing\text{ row with pairing }
             01\mid23;\\
\text{(T1)}&N_1\text{ is a clean state-}A_0\text{ row, hence one spanning }
             b_2b_3\text{-path};\\
\text{(TB)}&N_0\mathbin\triangle N_1\text{ is one }b_0b_1\text{-path and
             has no closed component};\\
\text{(TU)}&N_0,N_1\text{ are the only clean boundary rows of }B.
\end{array}
\tag{13}
\]

Condition (TU) is stronger than logically necessary, but it is the smallest
simple factor-only exclusion condition: every nonclean row carries a local
cycle which remains a forbidden closed component after any splice, so no
other row can enter the rooted family.

Under (13), state-\(\varnothing\) joined targets are in bijection with the
old rooted targets avoiding \(h_0,h_2\), and state-\(A_0\) joined targets
are in bijection with the old rooted targets using \(h_0\) and avoiding
\(h_2\). The auxiliary paths merely replace the deleted complement edges
by spanning detours. Moreover, for any two retained targets the number of
alternating difference components is unchanged: equal auxiliary rows
cancel, while (TB) substitutes a path for \(h_0\).

Thus the new rooted exchange graph is exactly the subgraph of the old one
induced by the states \(\varnothing\) and \(A_0\).

## 5. Why this cut would produce the desired one-crossing family

For the cut (1), the verifier's eight old targets have the following exact
states:

\[
\begin{array}{c|cccccccc}
 i&0&1&2&3&4&5&6&7\\ \hline
 S(M_i)&\Omega&\varnothing&\varnothing&\varnothing&A_0&\Omega&
          \varnothing&\varnothing\\
 g_1\in M_i&0&0&1&0&1&0&0&1.
\end{array}
\tag{14}
\]

Therefore (13) retains exactly

\[
       M_1,M_2,M_3,M_4,M_6,M_7.
\tag{15}
\]

Intersecting the complete old exchange edge set

\[
 \{01,02,05,16,27,34,56,57\}
\tag{16}
\]

with (15) leaves

\[
       16,\qquad27,\qquad34.
\tag{17}
\]

The first edge is sector \(0\)-\(0\), the second is sector \(1\)-\(1\), and
only \(34\) is mixed. All three are isolated \(K_2\) components. Hence an
actual second brace satisfying (13), with a structurally legal splice,
would give a genuine one-crossing counterexample to the remaining
cardinality statement.

For comparison, the two common-state transparent cuts do not suffice. The
cut \(1\!-\!12\mid0\!-\!11\) retains the old crossing \(57\) in addition to
\(34\), and \(1\!-\!14\mid2\!-\!11\) retains \(02\) in addition to \(34\).
The cut \(4\!-\!15\mid7\!-\!16\) retains all eight targets. This is why
(1), rather than another facial cut on the same carrier, is the
decision-relevant splice.

## 6. Exact remaining interface

The unresolved step is now a factor-realizability question, not an exchange
topology question:

> Does a simple plane cubic bipartite brace have a facial opposite-edge cut
> whose complete boundary-row family satisfies (T0)--(TU), and can it be
> spliced to (1) while preserving the legal-wide brace hypotheses?

The matching part and the structural part must be checked separately.
The root, forced gate, and surviving gate are untouched by (1). Bipartite
parity of the gate-face arc is preserved by a facial bipartite detour, but
simplicity, brace connectivity, face simplicity, and the inverse-dual
legal-wide condition do not follow from (13).

If (TU) is too strong for actual braces, the exact fallback is (7): extra
clean rows are allowed precisely when every rooted join they create fails
the one-cycle bond join with both \(X_3\) and \(X_4\). Deciding that weaker
condition requires the complete pair-relational boundary signature (8);
connector-state counts or complement pairings alone cannot decide it.
