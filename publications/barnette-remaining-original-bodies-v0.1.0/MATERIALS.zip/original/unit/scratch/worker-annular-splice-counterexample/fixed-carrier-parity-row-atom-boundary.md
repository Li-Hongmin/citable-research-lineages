# Fixed-carrier atom boundary for the parity-forced clean row

This calculation fixes the Note 154 carrier, the ordered cut

\[
 (a_0,a_1,a_2,a_3)=(19,10,21,9),
 \qquad q_0=10\!-!19,\quad q_2=9\!-!21,
\]

and keeps the factor internal bond atom symbolic.  It does not generate a
new factor or scan any graph order.

## 1. Decision

The Smith--Thomason third clean row does **not** force a second mixed
one-cycle bond on this carrier.

More precisely:

- if the second Hamilton cycle \(H_2\) through \(q_2\) also contains
  \(q_0\), its clean row forms two new rooted joins, but neither can have
  any crossing at all;
- if \(H_2\) avoids \(q_0\), its clean row forms one new rooted join, and a
  second crossing occurs exactly when one still-uncontrolled factor bond
  atom has no closed alternating component.

Thus Hamilton parity and the one-row atoms do not prove compensation.  The
surviving graph-realizability interface is exactly the closed-component
count in \(d_B(N_0,N_2)\) in the second branch, together with control of any
other clean rows of a realizing factor.

## 2. Complete carrier census relevant to the forced rows

Enumerating every carrier boundary matching containing the root and forced
gate gives 54 rows.  Their counts by state are

\[
\begin{array}{c|rrrrrr}
S&\varnothing&\Omega&A_0&A_1&A_2&A_3\\ \hline
\#&22&6&3&12&0&11.
\end{array}
\]

Only the following rows pass one of the clean factor complement atoms used
below.  The gate column records membership of \(g_1=3\!-!21\).

\[
\begin{array}{c|c|c|c}
\text{factor complement atom}&\text{carrier rows}&\text{old identity}&g_1\\ \hline
\varnothing:01\mid23&K_1,K_2,K_{10},K_{19},K_{20}
 &M_1,M_2,M_3,M_6,M_7&0,1,0,0,1\\
A_0:23&K_{29}&M_4&1\\
\varnothing:03\mid12&K_0,K_{18}&\text{new carrier joins}&0,0\\
A_2:01&\varnothing&\text{none}&-
\end{array}
\]

Here \(K_{10}\) and \(K_{29}\) are the carrier rows of the retained pair
\(X_3,X_4\).  The verifier prints the literal edge set and complete marked
complement atom of every row in this table.

The carrier bond atoms needed for every possible mixed comparison are

\[
\begin{array}{c|ccc}
 &K_1&K_{10}&K_{19}\\ \hline
K_{29}&01+1\text{ closed}&01+0\text{ closed}&01+1\text{ closed}
\end{array}
\tag{1}
\]

and

\[
d_G(K_0,K_{29})=d_G(K_{18},K_{29})
   =01+1\text{ closed}.
\tag{2}
\]

All same-state bonds from \(K_0\) or \(K_{18}\) to a \(T0\)-compatible
carrier row already have at least one closed alternating component.

## 3. Branch \(q_0\in H_2\)

Removing \(q_0,q_2\) from the Hamilton cycle \(H_2\) gives the clean
empty-state complement pairing

\[
03\mid12.
\]

The crossing pairing \(02\mid13\) is impossible by planarity, and
\(01\mid23\) would close into two cycles after \(q_0,q_2\) were restored.
The corresponding row \(N_2\) therefore joins exactly through \(K_0,K_{18}\),
both in gate sector zero.

Against any empty-state \(N_0\)-target, the factor difference
\(N_0\triangle N_2\) contains at least one closed alternating cycle because
the two rows are distinct and have the same state.  The carrier difference
also has at least one closed component.  Hence their joined difference has
at least two components.

Against the sole \(A_0\)-target \((K_{29},N_1)\), equation (2) already
contributes one closed carrier component in addition to the cycle obtained
by joining the two \(01\)-paths.  Hence this joined difference is never one
cycle, independently of the factor bond atom.

Therefore the parity row in this branch forms rooted targets but has

\[
\boxed{\text{zero mixed one-cycle bonds}.}
\]

Parity at \(q_0\) forces a further Hamilton cycle.  The cut-edge parity
constraints admit the boundary incidence pattern

\[
(q_0,q_2)(H_1,H_2,H_3)=(01,11,10),
\]

so both cut edges occur twice.  The row of \(H_3\) has state \(A_2\), for
which the fixed carrier has no row at all.  Thus even completing parity on
both cut edges need not repair this failure.  If a further Hamilton cycle
contains both cut edges, its row again has the harmless
\(\varnothing:03\mid12\) atom above; parity on other internal edges remains
part of factor realizability rather than a carrier-atom consequence.

## 4. Branch \(q_0\notin H_2\)

Now \(P_2=E(B)-E(H_2)\) contains \(q_0\), so

\[
N_2=P_2-\{q_0\}
\]

has state \(A_0\), and its clean complement is the spanning \(23\)-path
\(H_2-q_2\).  It joins only through \(K_{29}\), producing a new gate-one
target \(Y=(K_{29},N_2)\).

The gate-zero \(N_0\)-targets use \(K_1,K_{10},K_{19}\).  Equation (1)
eliminates \(K_1,K_{19}\) unconditionally.  Consequently the complete
mixed-bond condition is

\[
\boxed{
X_3=(K_{10},N_0)\sim Y
\iff
d_B(N_0,N_2)=01+0\text{ closed}.
}
\tag{3}
\]

Smith--Thomason parity fixes the state and complement atom of \(N_2\), but
does not fix the right side of (3).  A consistent symbolic obstruction is
obtained from a \(01\)-path atom \(A\) and a disjoint closed-cycle atom
\(C\):

\[
N_0\triangle N_1=A,
\qquad
N_1\triangle N_2=C,
\qquad
N_0\triangle N_2=A\mathbin{\dot\cup}C.
\tag{4}
\]

Equation (4) respects the symmetric-difference identity, preserves (TB),
and allows both \(N_1,N_2\) to have clean spanning \(23\)-path complements.
It makes \((K_{29},N_1)\) and \((K_{29},N_2)\) same-sector exchange
neighbours, while the additional closed component blocks (3).  Hence the
row and pair-atom language itself admits a strict noncompensating model.

## 5. What remains to realize a graph counterexample

The symbolic model is not yet a finite cubic factor.  A realizing factor
must simultaneously provide perfect matchings \(P_0,P_1,P_2\) with the
stated two-factor/Hamilton complements, realize the path-plus-cycle bond in
(4), and make every additional clean row forced by the complete Hamilton
family harmless.  It must then also satisfy planarity, bipartiteness, the
brace condition, and the legal-wide splice conditions.

Thus the fixed-carrier calculation closes the proposed parity-compensation
argument, but does not construct the desired one-crossing brace.

## Reproduction

~~~bash
python3 units/barnette/scratch/worker-annular-splice-counterexample/audit_fixed_carrier_atoms.py
~~~

The terminal marker is

~~~text
FIXED_CARRIER_ATOMS_AUDITED
~~~
