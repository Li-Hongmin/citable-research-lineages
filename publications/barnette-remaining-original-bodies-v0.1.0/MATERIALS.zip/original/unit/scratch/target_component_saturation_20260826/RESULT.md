# Target-component saturation reduces to forced-gate components

## Statement

Fix a simple plane cubic bipartite brace \(F'\), a legal two-gate
\(C_4\)-expansion at a face \(C\) with gate edges \(g,h\), and a root edge
\(e\notin E(C)\). Let

\[
\mathcal T_e=\{M:e\in M,\ F'-M\text{ consists of two cycles separating
the ends of }e\}.
\]

For the fixed expansion, call \(M\in\mathcal T_e\) *liftable* when its dual
target colouring passes some local row and the rooted-connectivity test in
Note 065(5). Define the target-state graph \(G_e\) on \(\mathcal T_e\) by

\[
M\sim N
\quad\Longleftrightarrow\quad
M\triangle N\text{ is one alternating cycle}.
\tag{1}
\]

The cycle in (1) automatically avoids \(e\), since every member of
\(\mathcal T_e\) contains \(e\).

The proposed general statement is

\[
\forall(F',e,C,g,h),\ \forall\Gamma\in\operatorname{comp}(G_e),
\qquad
\Gamma\text{ contains a liftable target}.
\tag{CS}
\]

No arbitrary-order proof or counterexample to (CS) was found. The exact
outcome is a proof-level reduction of (CS), together with a complete finite
theorem through reduced order 20.

## A proof-level neutral-gate lemma

For \(M\in\mathcal T_e\), put

\[
\gamma(M)=|M\cap\{g,h\}|.
\]

**Lemma.** If \(\gamma(M)\le1\), then \(M\) is liftable.

**Proof.** Use the dual target colouring, normalize the contracted vertex
\(z\) to colour zero, and write \(p,q\) for the two gate-neighbour colours
as in Note 065. A gate belongs to \(M\) exactly when its dual neighbour has
colour zero.

If \(\gamma(M)=0\), then \((p,q)=(1,1)\). Choose the valid normalized row
\((\lambda,\rho;d)=(0,0;0)\). In the forest
\(H(c')-e^*\), replacing \(z\) by the path \(x_1-v-x_3\) and distributing
the old zero-coloured attachments between \(x_1,x_3\) is a tree
replacement. It preserves acyclicity, the number of components, and the
path between the two root marks.

If \(\gamma(M)=1\), suppose by symmetry that \((p,q)=(0,1)\). Choose the
valid row \((0,0;1)\). The old monochromatic edge \(zx_2\) is replaced by
the path \(x_1-x_2-x_3\), while \(v\) is added as a leaf at the
one-coloured gate \(x_4\). Again this is a forest-preserving tree
replacement and the root marks remain connected. The case \((1,0)\) is
symmetric. Thus Note 065(5) holds in every case. \(\square\)

It follows immediately that (CS) is equivalent to the strictly thinner
forced-component statement

\[
\forall(F',e,C,g,h),\ \forall\Gamma\in\operatorname{comp}(G_e),
\quad
\bigl[g,h\in M\text{ for every }M\in\Gamma\bigr]
\Longrightarrow
\Gamma\text{ contains a liftable target}.
\tag{FC}
\]

Indeed, every component not covered by the premise of (FC) already contains
a target with \(\gamma\le1\), which is liftable by the lemma. This is the
smallest exact correction obtained here: forcing both gates must be tested
componentwise, not merely over the complete family.

## Complete finite theorem through order 20

The streaming census in
`census_target_component_saturation_through20.py` checks every connected
simple cubic bipartite isomorphism representative of even order at most 20,
retains exactly the plane braces, constructs every legal split/root
interface with \(\mathcal T_e\ne\varnothing\), builds (1) from the actual
primal perfect matchings, and tests all eight local assignments for every
target.

The covered corpus consists of

\[
912\text{ generated graphs},\quad
10\text{ plane braces},\quad
8798\text{ interfaces},\quad
45364\text{ target/interface instances}.
\]

It contains 9296 target-state connected components. Exactly 8956 contain a
target using at most one gate; every such target lifts, as predicted by the
lemma. The remaining 340 components force both gates on all their 620
targets. Every one of these 620 targets also lifts. Hence

\[
\boxed{\text{(CS), and therefore (FC), holds for every reduced brace of
order at most 20.}}
\tag{2}
\]

The finite result is stronger pointwise. There are 184 nonliftable
target/interface instances. Every one has a liftable neighbour \(N\) in
\(G_e\), and every such recorded neighbour uses at most one gate. Thus

\[
M\text{ nonliftable}
\Longrightarrow
\exists N\in\mathcal T_e:
M\triangle N\text{ is one alternating cycle},\quad
\gamma(N)\le1,quad N\text{ liftable}
\tag{3}
\]

through order 20. For all 184 cases the minimum number of components of
\(M\triangle N\) among gate-avoiding targets is one. Therefore no
intermediate matching is needed in these shortest escapes. This does not
contradict the synchronized two-component pair in Note 066: that example
shows that a *particular* target-to-target difference may require
intermediate non-target states, while the same bad target has another
one-cycle good neighbour.

## Relation to the complete-family forced-gate dichotomy

There are 250 interfaces for which both gates belong to every member of the
complete family \(\mathcal T_e\), comprising 452 target/interface instances.
In every such interface, every target has two fully alternating gate arcs,
and each of the normalized rows \(011,101,110\) is a target lift.

This complete-family statement is stronger on its premise but too coarse to
replace (FC). Of the 340 forced-gate target-state components, 256 lie in
complete families that force both gates, whereas 84 lie inside mixed-gate
families. All 84 still consist entirely of liftable targets through order
20, but the family-level premise says nothing about them. Moreover, the
8798 target families split into 9296 target-state components, so ordinary
single-cycle target connectivity is itself false in the covered range.

At component level, 304 of the 340 forced-gate components have every target
fully alternating with all three rows \(011,101,110\) successful. The other
36 components are still entirely liftable, but not by that uniform
arc-\(11\)/three-row description. Thus arc alternation is not the general
component invariant; the Note 065(5) rooted component state remains
load-bearing.

## Stopping boundary

**Exact quantifiers.** Equation (2) covers every simple plane cubic
bipartite brace \(F'\) with \(|V(F')|\le20\), every legal two-gate
\(C_4\)-expansion, every unchanged root \(e\notin E(C)\) with
\(\mathcal T_e\ne\varnothing\), and every connected component of the exact
target-state graph (1).

**Weakest load-bearing step.** The proof-level step is the neutral-gate
tree replacement, which reduces (CS) exactly to (FC). The remaining
arbitrary-order burden is to show that a target-state component on which
both gate edges are forced cannot be entirely trapped in the bad rooted
component-partition states of Note 065(5). Complete-family gate forcing is
not weak enough because it misses forced components inside mixed families.

**Evidence level.** The neutral-gate lemma and the equivalence
\((\mathrm{CS})\Longleftrightarrow(\mathrm{FC})\) are proof-level. The
through-20 assertion and the stronger domination property (3) are exact
computer-assisted finite results, conditional only on nauty `geng`'s
isomorph-free coverage and NetworkX's planarity decisions; brace status,
embeddings, target families, matching differences, connected components,
and all lift rows are checked directly. Note 068 remains a genuine
order-20 counterexample to arbitrary-witness lifting, but its nine-vertex
target-state graph is connected and each of its three bad targets has a
one-step good neighbour.

**Unresolved boundary.** Neither (CS), (FC), nor the stronger one-step
domination statement (3) is proved or refuted for arbitrary order. The
first unsupported reduced order is 22. No further order was searched. A
general positive proof must control forced-gate *target-state components*
through their decorated component partitions and root marks; gate count,
complete-family forcing, lockedness, and arc alternation separately do not
supply that control.

## Reproduction

From the AIMath project root:

    uv run --with 'networkx==3.6.1' \
      units/barnette/scratch/target_component_saturation_20260826/census_target_component_saturation_through20.py \
      --output units/barnette/scratch/target_component_saturation_20260826/target_component_saturation_through20.json

The terminal marker is

    TARGET_COMPONENT_SATURATION_VERIFIED_THROUGH_REDUCED_ORDER_20
