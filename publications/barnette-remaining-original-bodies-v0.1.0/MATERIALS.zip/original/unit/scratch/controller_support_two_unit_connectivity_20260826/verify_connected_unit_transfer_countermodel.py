#!/usr/bin/env python3
"""Verify that unit-transfer connectivity does not force support two."""

from fractions import Fraction


STATES = (
    (-1, -1, -1, 1, 1),
    (-1, -1, 0, 0, 1),
    (-1, 0, -1, 1, 0),
    (-1, 0, 0, 1, -1),
    (-1, 0, 1, 0, -1),
    (-1, 1, -1, 0, 0),
    (-1, 1, -1, 1, -1),
    (0, 0, -1, 1, -1),
    (0, 1, -1, -1, 0),
    (1, -1, -1, 1, -1),
)


def compatible(first: tuple[int, ...], second: tuple[int, ...]) -> bool:
    return all(a + b <= 0 for a, b in zip(first, second, strict=True))


def is_unit_transfer(first: tuple[int, ...], second: tuple[int, ...]) -> bool:
    return sum(abs(a - b) for a, b in zip(first, second, strict=True)) == 2


def main() -> None:
    assert all(set(state) <= {-1, 0, 1} and sum(state) == -1 for state in STATES)
    assert all(
        not compatible(STATES[i], STATES[j])
        for i in range(len(STATES))
        for j in range(i, len(STATES))
    )

    adjacency = {
        i: {j for j in range(len(STATES)) if i != j and is_unit_transfer(STATES[i], STATES[j])}
        for i in range(len(STATES))
    }
    reached = {0}
    frontier = [0]
    while frontier:
        current = frontier.pop()
        for successor in adjacency[current] - reached:
            reached.add(successor)
            frontier.append(successor)
    assert reached == set(range(len(STATES)))

    weights = (Fraction(1, 4), Fraction(1, 2), Fraction(1, 4))
    support = (1, 8, 9)
    average = tuple(
        sum(weight * STATES[index][coordinate] for weight, index in zip(weights, support, strict=True))
        for coordinate in range(5)
    )
    assert average == (0, 0, Fraction(-3, 4), Fraction(-1, 4), 0)
    assert all(value <= 0 for value in average)

    print(
        {
            "states": len(STATES),
            "unit_transfer_graph_connected": True,
            "compatible_pairs": 0,
            "fractional_average": tuple(str(value) for value in average),
        }
    )
    print("CONNECTED_UNIT_TRANSFER_DOES_NOT_FORCE_SUPPORT_TWO_VERIFIED")


if __name__ == "__main__":
    main()
