#!/usr/bin/env python3
"""Standalone verifier for an order-22 forced-component failure record.

The verifier deliberately does not import the exploratory order-22 census.
It reconstructs the two plane objects from the frozen source graph, repeats
both brace checks, re-enumerates the complete rooted target family and its
one-cycle exchange graph, and recomputes all eight local profiles for every
target in the alleged failed component.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations, product
import argparse
import importlib.util
import json
from pathlib import Path
import sys
from typing import Iterable

import networkx as nx


Edge = tuple[int, int]
Matching = frozenset[Edge]

sys.dont_write_bytecode = True
UNIT_DIR = Path(__file__).resolve().parents[2]
LIFT_BUNDLE = (
    UNIT_DIR
    / "computations"
    / "bundles"
    / "locked-boundary-escape-through18"
    / "census_locked_escape_through18.py"
)


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


lift_bundle = load_module(LIFT_BUNDLE, "order22_failure_lift_bundle")


def edge(first: int, second: int) -> Edge:
    return (first, second) if first < second else (second, first)


def edge_set(items: Iterable[Iterable[int]]) -> set[Edge]:
    return {edge(*map(int, item)) for item in items}


def primal_edge_by_dual_edge(
    primal: nx.Graph, primal_faces: Iterable[Iterable[int]]
) -> dict[Edge, Edge]:
    incident: dict[Edge, list[int]] = defaultdict(list)
    for face_index, face_raw in enumerate(primal_faces):
        face = tuple(map(int, face_raw))
        for index, first in enumerate(face):
            second = face[(index + 1) % len(face)]
            incident[edge(first, second)].append(face_index)
    assert set(incident) == {edge(*item) for item in primal.edges()}
    assert all(len(pair) == 2 for pair in incident.values())
    return {edge(*pair): primal_edge for primal_edge, pair in incident.items()}


def matching_from_colour(
    primal: nx.Graph,
    reduced: nx.Graph,
    dual_to_primal: dict[Edge, Edge],
    colour: dict[int, int],
) -> Matching:
    matching = frozenset(
        dual_to_primal[edge(first, second)]
        for first, second in reduced.edges()
        if colour[first] == colour[second]
    )
    degrees = Counter(vertex for item in matching for vertex in item)
    assert len(matching) * 2 == primal.number_of_nodes()
    assert set(degrees) == set(primal) and set(degrees.values()) == {1}
    return matching


def matching_diff_component_count(first: Matching, second: Matching) -> int:
    difference = first ^ second
    if not difference:
        return 0
    graph = nx.Graph()
    graph.add_edges_from(difference)
    assert set(dict(graph.degree()).values()) == {2}
    return nx.number_connected_components(graph)


def target_graph(matchings: tuple[Matching, ...]) -> nx.Graph:
    graph = nx.Graph()
    graph.add_nodes_from(range(len(matchings)))
    for first, second in combinations(range(len(matchings)), 2):
        if matching_diff_component_count(matchings[first], matchings[second]) == 1:
            graph.add_edge(first, second)
    return graph


def reduce_expanded(
    expanded: nx.Graph, z: int, locals_: tuple[int, int, int]
) -> nx.Graph:
    left, right, centre = locals_
    result = expanded.copy()
    result.remove_node(centre)
    result = nx.contracted_nodes(result, left, right, self_loops=False)
    result = nx.relabel_nodes(result, {left: z})
    return nx.Graph(result)


def assignment_record(
    bits: tuple[int, int, int],
    normalized_bits: tuple[int, int, int],
    profile: tuple[bool, int | None, int | None, bool],
) -> dict[str, object]:
    return {
        "bits_left_right_centre": list(bits),
        "normalized_bits": list(normalized_bits),
        "nae": profile[0],
        "components": profile[1],
        "cycle_rank": profile[2],
        "root_on_cycle": profile[3],
        "target": lift_bundle.is_target_profile(profile),
    }


def verify(certificate: dict[str, object]) -> None:
    failure = certificate["first_failure"]
    assert isinstance(failure, dict)
    assert failure["failure_kind"] == (
        "forced_two_gate_target_component_without_liftable_target"
    )
    assert int(failure["source_order"]) == 22

    source_graph6 = str(failure["source_graph6"])
    primal = nx.from_graph6_bytes(source_graph6.encode())
    assert primal.number_of_nodes() == 22
    assert {edge(*item) for item in primal.edges()} == edge_set(
        failure["source_primal_edges"]
    )
    primal_faces = tuple(
        tuple(map(int, face)) for face in failure["source_primal_faces"]
    )
    reduced, rotations = lift_bundle.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift_bundle.verify_reduced_triangulation(reduced)
    assert {edge(*item) for item in reduced.edges()} == edge_set(
        failure["reduced_triangulation_edges"]
    )
    assert lift_bundle.verify_brace(primal) == failure["reduced_dual_brace_check"]

    site = failure["site"]
    assert isinstance(site, dict)
    z = int(site["split_vertex"])
    rotation = tuple(map(int, site["rotation"]))
    gate_indices = tuple(map(int, site["gate_indices"]))
    gate_vertices = tuple(map(int, site["gate_vertices"]))
    gate_edges = tuple(edge(*map(int, item)) for item in site["primal_gate_edges"])
    stored_arcs = (
        tuple(map(int, site["left_arc"])),
        tuple(map(int, site["right_arc"])),
    )
    stored_locals = tuple(map(int, site["left_right_centre"]))
    assert rotations[z] == rotation
    assert tuple(rotation[index] for index in gate_indices) == gate_vertices

    expanded, locals_, left_arc, right_arc = lift_bundle.split_vertex(
        reduced, z, rotation, gate_indices[0], gate_indices[1]
    )
    assert locals_ == stored_locals
    assert (left_arc, right_arc) == stored_arcs
    assert {edge(*item) for item in expanded.edges()} == edge_set(
        failure["expanded_triangulation_edges"]
    )
    assert {edge(*item) for item in reduce_expanded(expanded, z, locals_).edges()} == {
        edge(*item) for item in reduced.edges()
    }

    expanded_faces = lift_bundle.expanded_triangulation_faces(expanded)
    assert expanded_faces is not None
    expanded_dual = lift_bundle.dual_from_plane_graph(expanded, expanded_faces)
    stored_expanded_dual = nx.Graph()
    stored_expanded_dual.add_edges_from(
        tuple(map(int, item)) for item in failure["expanded_dual_edges"]
    )
    assert nx.is_isomorphic(expanded_dual, stored_expanded_dual)
    assert nx.is_isomorphic(
        expanded_dual,
        nx.from_graph6_bytes(str(failure["expanded_dual_graph6"]).encode()),
    )
    assert lift_bundle.verify_brace(expanded_dual) == failure[
        "expanded_dual_brace_check"
    ]

    dual_to_primal = primal_edge_by_dual_edge(primal, primal_faces)
    root = edge(*map(int, failure["dual_root"]))
    primal_root = edge(*map(int, failure["primal_root"]))
    assert dual_to_primal[root] == primal_root
    assert tuple(dual_to_primal[edge(z, gate)] for gate in gate_vertices) == gate_edges
    assert z not in root and expanded.has_edge(*root)

    families, _nae_count, _shape_count = lift_bundle.target_families(
        reduced, reduced_faces
    )
    encoded_family = families[root]
    assert len(encoded_family) == int(
        failure["complete_target_family_size_mod_complement"]
    )
    reduced_vertices = tuple(sorted(reduced))
    colours = tuple(
        lift_bundle.decode_colouring(reduced_vertices, encoded)
        for encoded in encoded_family
    )
    matchings = tuple(
        matching_from_colour(primal, reduced, dual_to_primal, colour)
        for colour in colours
    )
    adjacency = target_graph(matchings)

    component = set(map(int, failure["failed_component_family_indices"]))
    assert len(component) == int(failure["failed_component_size"])
    first = min(component)
    assert nx.node_connected_component(adjacency, first) == component
    assert all(set(gate_edges) <= set(matchings[index]) for index in component)

    stored_targets = failure["failed_component_targets"]
    assert isinstance(stored_targets, list)
    assert [int(record["family_index"]) for record in stored_targets] == sorted(component)
    for stored in stored_targets:
        assert isinstance(stored, dict)
        index = int(stored["family_index"])
        colour = colours[index]
        matching = matchings[index]
        assert stored["zero_vertices"] == sorted(
            vertex for vertex, value in colour.items() if value == 0
        )
        assert stored["one_vertices"] == sorted(
            vertex for vertex, value in colour.items() if value == 1
        )
        assert edge_set(stored["matching"]) == set(matching)
        assert int(stored["gate_count"]) == 2
        assert stored["target_graph_neighbours"] == sorted(adjacency[index])
        assert lift_bundle.is_target_profile(
            lift_bundle.rooted_profile(reduced, reduced_faces, colour, root)
        )

        fixed = {vertex: value for vertex, value in colour.items() if vertex != z}
        observed = []
        for bits in product((0, 1), repeat=3):
            lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
            profile = lift_bundle.rooted_profile(
                expanded, expanded_faces, lifted, root
            )
            normalized = tuple(bit ^ colour[z] for bit in bits)
            observed.append(assignment_record(bits, normalized, profile))
        assert observed == stored["all_eight_assignments"]
        assert not any(record["target"] for record in observed)

    assert certificate["status"] == "counterexample_at_reduced_order_22"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("certificate", type=Path)
    arguments = parser.parse_args()
    certificate = json.loads(arguments.certificate.read_text())
    verify(certificate)
    print("ORDER22_FORCED_TARGET_COMPONENT_FAILURE_INDEPENDENTLY_VERIFIED")


if __name__ == "__main__":
    main()
