#!/usr/bin/env python3
"""Scan every one-step C4 expansion remote from the order-24 FC witness.

This is disposable exploration.  It keeps the frozen order-24 split/root
interface unchanged, applies every legal dual vertex split outside its closed
neighbourhood and root endpoints, and tests the complete inherited target
family for an existence-level lifting failure.
"""

from __future__ import annotations

from collections import Counter
import argparse
import importlib.util
from itertools import product
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
CERTIFICATE = (
    UNIT
    / "scratch"
    / "target_component_saturation_order24_20260826"
    / "forced_target_components_order24.json"
)
VERIFIER = CERTIFICATE.with_name("verify_order24_component_failure.py")


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


verify = load_module(VERIFIER, "order24_remote_source")
lift = verify.lift_bundle


def colouring_record(colour: dict[int, int]) -> dict[str, object]:
    return {
        "zero_vertices": sorted(v for v, bit in colour.items() if bit == 0),
        "one_vertices": sorted(v for v, bit in colour.items() if bit == 1),
    }


def scan() -> dict[str, object]:
    certificate = json.loads(CERTIFICATE.read_text())
    frozen = certificate["first_failure"]
    primal = nx.from_graph6_bytes(frozen["source_graph6"].encode())
    primal_faces = tuple(tuple(face) for face in frozen["source_primal_faces"])
    reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift.verify_reduced_triangulation(reduced)

    site = frozen["site"]
    z = int(site["split_vertex"])
    rotation = tuple(site["rotation"])
    original_gate_indices = tuple(site["gate_indices"])
    original_gates = tuple(site["gate_vertices"])
    root = verify.edge(*frozen["dual_root"])
    assert rotations[z] == rotation
    assert tuple(rotation[i] for i in original_gate_indices) == original_gates

    original_families, _, _ = lift.target_families(reduced, reduced_faces)
    original_vertices = tuple(sorted(reduced))
    original_colours = tuple(
        lift.decode_colouring(original_vertices, encoded)
        for encoded in original_families[root]
    )
    original_neutral_indices = tuple(
        index
        for index, colour in enumerate(original_colours)
        if sum(colour[g] == colour[z] for g in original_gates) <= 1
    )
    assert original_neutral_indices == (2, 3, 7, 8)

    excluded = {z} | set(reduced[z]) | set(root)
    remote_vertices = tuple(sorted(set(reduced) - excluded))
    totals = Counter(
        remote_vertices=len(remote_vertices),
        nonconsecutive_gate_pairs=0,
        odd_arc_gate_pairs=0,
        legal_remote_expansions=0,
        legal_preserved_interfaces=0,
        empty_target_families=0,
        nonempty_target_families=0,
        target_instances=0,
        local_assignments=0,
        liftable_targets=0,
        nonliftable_targets=0,
        family_failures=0,
    )
    records: list[dict[str, object]] = []
    first_failure = None

    for operation_vertex in remote_vertices:
        operation_rotation = rotations[operation_vertex]
        for i, j, gate_i, gate_j in lift.gate_pairs(operation_rotation):
            totals["nonconsecutive_gate_pairs"] += 1
            left_size = j - i + 1
            right_size = len(operation_rotation) - (j - i) + 1
            if left_size % 2 == 0 or right_size % 2 == 0:
                continue
            totals["odd_arc_gate_pairs"] += 1
            new_reduced, operation_locals, op_left, op_right = lift.split_vertex(
                reduced, operation_vertex, operation_rotation, i, j
            )
            new_faces = lift.expanded_triangulation_faces(new_reduced)
            if new_faces is None:
                continue
            totals["legal_remote_expansions"] += 1

            assert set(new_reduced[z]) == set(rotation)
            assert new_reduced.has_edge(*root)
            final, final_locals, left_arc, right_arc = lift.split_vertex(
                new_reduced,
                z,
                rotation,
                original_gate_indices[0],
                original_gate_indices[1],
            )
            assert left_arc == tuple(site["left_arc"])
            assert right_arc == tuple(site["right_arc"])
            final_faces = lift.expanded_triangulation_faces(final)
            if final_faces is None:
                continue
            totals["legal_preserved_interfaces"] += 1

            families, nae_count, shape_count = lift.target_families(
                new_reduced, new_faces
            )
            family = families.get(root, [])
            vertices = tuple(sorted(new_reduced))
            row_counts: Counter[str] = Counter()
            gate_counts: Counter[int] = Counter()
            witnesses: list[dict[str, object]] = []
            liftable = 0
            for encoded in family:
                colour = lift.decode_colouring(vertices, encoded)
                gate_count = sum(colour[g] == colour[z] for g in original_gates)
                gate_counts[gate_count] += 1
                fixed = {v: bit for v, bit in colour.items() if v != z}
                good_rows = []
                for bits in product((0, 1), repeat=3):
                    totals["local_assignments"] += 1
                    lifted = {**fixed, **dict(zip(final_locals, bits, strict=True))}
                    profile = lift.rooted_profile(final, final_faces, lifted, root)
                    if lift.is_target_profile(profile):
                        row = "".join(str(bit ^ colour[z]) for bit in bits)
                        good_rows.append(row)
                        row_counts[row] += 1
                totals["target_instances"] += 1
                if good_rows:
                    liftable += 1
                    totals["liftable_targets"] += 1
                    if len(witnesses) < 3:
                        witnesses.append(
                            {
                                **colouring_record(colour),
                                "gate_count": gate_count,
                                "good_rows": good_rows,
                            }
                        )
                else:
                    totals["nonliftable_targets"] += 1

            if family:
                totals["nonempty_target_families"] += 1
            else:
                totals["empty_target_families"] += 1
            record = {
                "operation": {
                    "split_vertex": operation_vertex,
                    "rotation": operation_rotation,
                    "gate_indices": (i, j),
                    "gates": (gate_i, gate_j),
                    "left_arc": op_left,
                    "right_arc": op_right,
                    "left_right_centre": operation_locals,
                },
                "new_reduced_order": 2 * (new_reduced.number_of_nodes() - 2),
                "source_neutral_indices": original_neutral_indices,
                "source_neutral_gate_counts_at_remote_site": tuple(
                    sum(
                        original_colours[index][gate]
                        == original_colours[index][operation_vertex]
                        for gate in (gate_i, gate_j)
                    )
                    for index in original_neutral_indices
                ),
                "nae_colourings_mod_complement": nae_count,
                "target_shapes_mod_complement": shape_count,
                "root_target_family_size": len(family),
                "gate_count_histogram": dict(sorted(gate_counts.items())),
                "liftable_targets": liftable,
                "nonliftable_targets": len(family) - liftable,
                "successful_row_counts": dict(sorted(row_counts.items())),
                "first_liftable_witnesses": witnesses,
            }
            records.append(record)
            print(json.dumps(record, sort_keys=True), flush=True)

            if family and liftable == 0:
                totals["family_failures"] += 1
                new_primal = lift.dual_from_plane_graph(new_reduced, new_faces)
                final_primal = lift.dual_from_plane_graph(final, final_faces)
                first_failure = {
                    **record,
                    "new_reduced_graph6": nx.to_graph6_bytes(
                        new_primal, header=False
                    ).decode().strip(),
                    "final_expanded_graph6": nx.to_graph6_bytes(
                        final_primal, header=False
                    ).decode().strip(),
                    "new_reduced_brace_check": lift.verify_brace(new_primal),
                    "final_expanded_brace_check": lift.verify_brace(final_primal),
                }
                break
        if first_failure is not None:
            break

    return {
        "scope": {
            "source_graph6": frozen["source_graph6"],
            "fixed_split_vertex": z,
            "fixed_rotation": rotation,
            "fixed_gate_indices": original_gate_indices,
            "fixed_gate_vertices": original_gates,
            "fixed_root": root,
            "source_neutral_indices": original_neutral_indices,
            "remote_vertices": remote_vertices,
            "excluded_vertices": sorted(excluded),
        },
        "coverage": dict(totals),
        "operations": records,
        "first_failure": first_failure,
        "status": (
            "real_complete_family_failure"
            if first_failure is not None
            else "complete_remote_one_step_route_closed"
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    payload = scan()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(rendered)
    print(json.dumps(payload["coverage"], sort_keys=True))
    print(payload["status"])


if __name__ == "__main__":
    main()
