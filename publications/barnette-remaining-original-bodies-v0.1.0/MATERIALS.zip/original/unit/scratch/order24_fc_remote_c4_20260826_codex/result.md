# 首个全坏 component 的全部远程一步扩张仍保留中性逃逸

## 精确结论

固定 reduced order (24) 的首个真实 forced-component 反例：源 brace

```text
W???????????w?s?P_BC?IO?L??H_?BO??w?CD??cG??P_?
```

及其 (z=1)、rotation


\[
(2,8,9,11,13,6,3,0),
\]

gate indices ((1,5))、dual root (57) 的完整接口。原完整 target family
有三个四点 component；中间 component 的四个 targets 全用两道 gate 且全部
不可提升，但另外两个 components 各含两个 one-gate、row `001` 的提升。

称第二次 dual vertex split 为 remote，当其支撑顶点位于

\[
V(T')\setminus\bigl(N[z]\cup V(57)\bigr).
\]

这个集合精确为 ({4,10,12})。三个顶点均为四价，每点恰有两个
nonconsecutive gate pairs；六个 pairs 均满足 odd-arc 条件，且六次 split
全部产生合法四连通 Eulerian triangulation。原 (z)、rotation、两 gates、
两 arcs 与 root 因而保持不变。

对六个新的 reduced order (28) braces，在原接口完整枚举 root-target family，
每族恰有 (20) 个 targets。六族的 gate-count 与 liftable-target 数为

\[
\begin{array}{c|c|c}
\text{remote split}&(\#g=1,\#g=2)&\#\text{liftable}\\ \hline
4:(3,2)&(6,14)&6\\
4:(5,0)&(8,12)&8\\
10:(3,13)&(4,16)&4\\
10:(6,5)&(4,16)&4\\
12:(9,13)&(6,14)&6\\
12:(5,11)&(8,12)&8
\end{array}
\]

全部成功 targets 都只用一道原 gate，且唯一成功 normalized row 为 `001`。
因此六个 family 均成功；不存在一步 remote (C_4) expansion 把这个固定接口
变成 ordinary existence-level failure。

## 解析解释：remote neutral lifts 可复合

Note 071 的 neutral-gate tree replacement 可顺序复合。更精确地，设同一
target colouring (c) 在两个合法 split sites (z,u) 上都至多使用一道各自的
gate，且先做一个 split 后另一个 site 的 rotation、gates 与 root 仍保持。先在
(u) 使用 neutral row，所得 rooted forest 在旧图之外保持同一 component
partition 和 root path；同时 (z) 及其 gate-neighbour colours 不变。因此在新图
中仍可对 (z) 使用 neutral row。第二次 tree replacement 再次保持 component
partition 和 root path，故双扩张后的 colouring 仍为 target。两次操作的次序可
交换。

在本例原 family 中，四个 one-gate escapes 的 family indices 为
(2,3,7,8)。按上述六个 remote gate pairs 排列，它们在第二 site 上的 gate-use
向量分别为

\[
\begin{array}{c|c}
(u;\text{gates})&
(|M_2\cap G_u|,|M_3\cap G_u|,|M_7\cap G_u|,|M_8\cap G_u|)\\ \hline
(4;3,2)&(0,0,2,0)\\
(4;5,0)&(2,2,0,1)\\
(10;3,13)&(0,0,0,0)\\
(10;6,5)&(1,1,1,1)\\
(12;9,13)&(2,0,0,0)\\
(12;5,11)&(0,1,2,2).
\end{array}
\]

每行至少有一个值不超过 (1)。选择对应的原 escape，先在 remote site
neutral-lift，再在原 site neutral-lift，就解析地证明六个新 family 全部成功。
完整 colouring census 独立确认了同一结论，并给出上节更细的 target 计数。

## 量词与证明边界

这是固定 order-24 接口的**完整一步 remote operation class**，不是任意阶
定理。完整性来自：remote 支撑只有三个；每个 rotation 的全部
nonconsecutive pairs 均已枚举；合法性由 Eulerian triangulation、planarity 与
四连通性直接检查；每个新 family 由全部 (2^{15}) 个 normalized colourings
筛出，随后每个 target 的八个局部赋值全部测试。

六个 operations 总计 (120) 个 target instances、(960) 个局部赋值；其中
(36) 个 targets 提升、(84) 个失败。该结果关闭的仅是

\[
\text{首个真实全坏 component}
+\text{一次保持接口的 remote }C_4\text{ expansion}
\Longrightarrow\text{完整 family 反例}
\]

这一最短构造路线。触及 (N[z]) 或 root endpoints 的操作会改变继承接口；
多步 remote operations 也不在本结论中。

## 证据等级与未决边界

- **证据等级：** neutral-lift 可复合性是 proof-level；固定 operation class 的
  完整性和六行 gate-use 表是精确有限检查。完整 colouring census 是更强的
  同实现复核，尚不是独立实现，因此本轮不直接晋级永久 note。
- **最薄弱步骤：** 固定 operation class 的完整性依赖三个 remote rotations 的
  全部 nonconsecutive gate pairs 枚举；一般复合引理还要求第一次操作确实保持
  第二 site 的 rotation、gates 与 root。
- **未解决边界：** order-24 的全部 family-level census；触及接口的局部操作；
  两步或其他保 brace 构造；以及一般 complete-family lifting 命题。

复现：

```bash
uv run --with 'networkx==3.6.1' \
  units/barnette/scratch/order24_fc_remote_c4_20260826_codex/scan_remote.py \
  --output units/barnette/scratch/order24_fc_remote_c4_20260826_codex/remote_scan.json
```

终止标记：

```text
complete_remote_one_step_route_closed
```
