#!/usr/bin/env python3
"""Probe exact NAE-unicycle lifts across the standard dual degree-four split."""

from __future__ import annotations

from itertools import product

import networkx as nx


GRAPH6 = (
    ("cube", "G?zTb_"),
    ("brace12", "K??FEagT@WB_"),
    ("brace16", "O????B_sDOI_I_DO@W?M?"),
)


def plane_faces(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    planar, embedding = nx.check_planarity(graph)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    used: set[tuple[int, int]] = set()
    faces: list[tuple[int, ...]] = []
    for left, right in embedding.edges():
        if (left, right) not in used:
            faces.append(tuple(embedding.traverse_face(left, right, used)))
    assert len(faces) == graph.number_of_edges() - graph.number_of_nodes() + 2
    return tuple(faces)


def plane_dual(graph: nx.Graph) -> nx.Graph:
    faces = plane_faces(graph)
    incident: dict[tuple[int, int], list[int]] = {}
    for face_index, face in enumerate(faces):
        for index, left in enumerate(face):
            right = face[(index + 1) % len(face)]
            key = tuple(sorted((left, right)))
            incident.setdefault(key, []).append(face_index)
    assert all(len(pair) == 2 for pair in incident.values())
    dual = nx.Graph()
    dual.add_nodes_from(range(len(faces)))
    dual.add_edges_from(pair for pair in incident.values())
    assert dual.number_of_edges() == graph.number_of_edges()
    return dual


def cyclic_arcs(order: tuple[int, ...], first: int, second: int) -> tuple[tuple[int, ...], tuple[int, ...]]:
    start = order.index(first)
    stop = order.index(second)
    if start < stop:
        arc_one = order[start : stop + 1]
        arc_two = order[stop:] + order[: start + 1]
    else:
        arc_one = order[start:] + order[: stop + 1]
        arc_two = order[stop : start + 1]
    return arc_one, arc_two


def split_degree_four(
    reduced: nx.Graph, z: int, first: int, second: int
) -> tuple[nx.Graph, tuple[int, int, int]]:
    """Inverse of deleting a degree-four vertex and identifying opposite neighbours."""
    planar, embedding = nx.check_planarity(reduced)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    order = tuple(embedding.neighbors_cw_order(z))
    arc_one, arc_two = cyclic_arcs(order, first, second)
    assert len(arc_one) >= 3 and len(arc_two) >= 3

    next_vertex = max(reduced.nodes) + 1
    left, right, centre = next_vertex, next_vertex + 1, next_vertex + 2
    expanded = reduced.copy()
    expanded.remove_node(z)
    expanded.add_nodes_from((left, right, centre))

    for neighbour in arc_one:
        expanded.add_edge(left, neighbour)
    for neighbour in arc_two:
        expanded.add_edge(right, neighbour)
    expanded.add_edges_from(
        (
            (centre, left),
            (centre, first),
            (centre, right),
            (centre, second),
        )
    )
    return expanded, (left, right, centre)


def is_nae(graph: nx.Graph, colour: dict[int, int]) -> bool:
    faces = plane_faces(graph)
    return all(
        len({colour[vertex] for vertex in face}) == 2
        for face in faces
    )


def monochromatic_graph(graph: nx.Graph, colour: dict[int, int]) -> nx.Graph:
    mono = nx.Graph()
    mono.add_nodes_from(graph.nodes)
    mono.add_edges_from(
        (left, right)
        for left, right in graph.edges
        if colour[left] == colour[right]
    )
    return mono


def is_rooted_unicycle(graph: nx.Graph, colour: dict[int, int], root: tuple[int, int]) -> bool:
    if not is_nae(graph, colour):
        return False
    mono = monochromatic_graph(graph, colour)
    beta = mono.number_of_edges() - mono.number_of_nodes() + nx.number_connected_components(mono)
    if beta != 1 or not mono.has_edge(*root):
        return False
    test = mono.copy()
    test.remove_edge(*root)
    return nx.number_connected_components(test) == nx.number_connected_components(mono)


def colourings(graph: nx.Graph):
    vertices = tuple(graph.nodes)
    # Quotient by global complementation.
    anchor = vertices[0]
    others = tuple(vertex for vertex in vertices if vertex != anchor)
    for bits in product((0, 1), repeat=len(others)):
        yield {anchor: 0, **dict(zip(others, bits, strict=True))}


def main() -> None:
    totals = {
        "reduced_targets": 0,
        "tested_interfaces": 0,
        "no_lift": 0,
    }
    first_failure = None
    for name, graph6 in GRAPH6:
        primal = nx.from_graph6_bytes(graph6.encode())
        reduced = plane_dual(primal)
        planar, embedding = nx.check_planarity(reduced)
        assert planar and isinstance(embedding, nx.PlanarEmbedding)
        assert nx.node_connectivity(reduced) >= 4
        targets = []
        for colour in colourings(reduced):
            if not is_nae(reduced, colour):
                continue
            for root in reduced.edges:
                if is_rooted_unicycle(reduced, colour, root):
                    targets.append((colour, tuple(root)))
        totals["reduced_targets"] += len(targets)

        for z in reduced.nodes:
            order = tuple(embedding.neighbors_cw_order(z))
            sites = []
            for i, first in enumerate(order):
                for second in order[i + 1 :]:
                    distance = (order.index(second) - i) % len(order)
                    if distance not in (1, len(order) - 1):
                        sites.append((first, second))
            for first, second in sites:
                expanded, (left, right, centre) = split_degree_four(reduced, z, first, second)
                if any(degree % 2 for _, degree in expanded.degree):
                    continue
                if nx.node_connectivity(expanded) < 4:
                    continue
                assert all(len(face) == 3 for face in plane_faces(expanded))
                for reduced_colour, root in targets:
                    if z in root:
                        continue
                    totals["tested_interfaces"] += 1
                    fixed = {u: c for u, c in reduced_colour.items() if u != z}
                    lifts = []
                    for bits in product((0, 1), repeat=3):
                        lifted = {**fixed, left: bits[0], right: bits[1], centre: bits[2]}
                        if is_rooted_unicycle(expanded, lifted, root):
                            lifts.append(bits)
                    if not lifts:
                        totals["no_lift"] += 1
                        if first_failure is None:
                            first_failure = {
                                "name": name,
                                "graph6": graph6,
                                "reduced_nodes": reduced.number_of_nodes(),
                                "z": z,
                                "rotation": order,
                                "site": (first, second),
                                "root": root,
                                "colour": reduced_colour,
                                "reduced_edges": tuple(sorted(tuple(sorted(edge)) for edge in reduced.edges)),
                                "expanded_edges": tuple(sorted(tuple(sorted(edge)) for edge in expanded.edges)),
                            }
        print(name, "targets", len(targets))
    print(totals)
    print("FIRST_FAILURE", first_failure)


if __name__ == "__main__":
    main()
