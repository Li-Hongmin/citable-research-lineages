# Single leaf: degree-four reduction for the prescribed-edge NAE pseudoforest target

Long objective: decide Barnette-type Hamiltonicity through an exact structural theorem or a genuine counterexample. Work only in `units/barnette`; read the unit README, Notes 057, 058, 060, and the two scratch reductions `barnette_decorated_rca/result.md` and (when it appears) `barnette_dual_unicycle/result.md`. Do not modify permanent notes or papers. Put exploration only in this scratch directory.

Let `T=F*` be the 4-connected Eulerian plane triangulation dual to a simple plane cubic bipartite brace, and let `a` be a prescribed edge. The RCA-colouring target is a vertex 2-colouring such that every triangular face is nonmonochromatic and the graph of monochromatic edges has total cycle rank one, with its unique cycle containing `a`.

Determine this single proposition: can the standard degree-four / primal-C4 reduction be made into a universal induction step for this prescribed-edge target (for a reducible degree-four vertex away from `a`)? Derive the exact reduction and all boundary states rather than assuming a contraction. If it always lifts, prove the lift with all root cases. If it does not, give a real triangulation/colouring boundary obstruction or a complete finite local state obstruction that strictly closes this induction interface.

Possible route-changing outcomes: universal lift theorem; explicit genuine graph counterexample to the lift; or a strict boundary-state characterization showing exactly which missing state must be supplied globally. Cheapest observation: enumerate the finite colour/connectivity states on the four-neighbour ring, but do not infer a graph theorem from an unrealizable state without checking realizability.

Stop at proof, genuine counterexample, strict reduction, or scoped route closure. End with exact conclusion and quantifiers, weakest load-bearing argument, evidence level, and unresolved boundary. Do not select a new task.
