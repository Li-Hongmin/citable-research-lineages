#!/usr/bin/env python3
"""Targeted two-path search in the Ellingham--Horton 54-vertex brace.

This is not a graph census.  For a requested root and labelled singleton
port fibre it solves the exact degree-constrained spanning-linkage problem
by binary MILP with iteratively added cycle and terminal-connectivity cuts.
"""

from __future__ import annotations

import argparse

import networkx as nx
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp


GRAPH6 = (
    "uhCGGCP?GGo@?PG?_?KO@?????G?????C??@??AG??????P??@?????_???G???P??"
    "AA??OCC?C?CC???AAO???__???CC???????????@????????????_?????G?????P???"
    "?????????AG?????G???????C??????@??????AG?????OOG?????__??G???__??????"
    "OQ??????CC???????__?????G??G?????O??W"
)


def edge_key(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


def solve_fibre(
    graph: nx.Graph,
    root: int,
    singleton_index: int,
) -> tuple[int, tuple[tuple[int, int], ...]] | None:
    colour = nx.bipartite.color(graph)
    x_vertices = tuple(sorted(v for v in graph if colour[v] != colour[root]))
    y_vertices = tuple(sorted(v for v in graph if colour[v] == colour[root] and v != root))
    ports = tuple(sorted(graph[root]))
    singleton = ports[singleton_index]
    paired = tuple(port for port in ports if port != singleton)
    vertices = tuple(sorted(set(graph) - {root}))
    edges = tuple(sorted(edge_key(u, v) for u, v in graph.edges() if root not in (u, v)))
    edge_index = {edge: index for index, edge in enumerate(edges)}

    degree_rows = []
    degree_rhs = []
    for vertex in vertices:
        row = np.zeros(len(edges))
        for neighbour in graph[vertex]:
            edge = edge_key(vertex, neighbour)
            if edge in edge_index:
                row[edge_index[edge]] = 1
        degree_rows.append(row)
        if vertex in x_vertices:
            degree_rhs.append(1 if vertex in ports else 2)
        else:
            degree_rhs.append(None)

    for endpoint_y in y_vertices:
        rows = []
        lower = []
        upper = []
        for row, rhs, vertex in zip(degree_rows, degree_rhs, vertices):
            target = (1 if vertex == endpoint_y else 2) if rhs is None else rhs
            rows.append(row)
            lower.append(target)
            upper.append(target)

        seen_cuts: set[tuple[str, tuple[int, ...]]] = set()
        while True:
            constraints = LinearConstraint(np.asarray(rows), np.asarray(lower), np.asarray(upper))
            result = milp(
                c=np.zeros(len(edges)),
                integrality=np.ones(len(edges)),
                bounds=Bounds(np.zeros(len(edges)), np.ones(len(edges))),
                constraints=constraints,
                options={"presolve": True},
            )
            if not result.success:
                break

            chosen = tuple(edges[index] for index, value in enumerate(result.x) if value > 0.5)
            support = nx.Graph()
            support.add_nodes_from(vertices)
            support.add_edges_from(chosen)
            components = tuple(nx.connected_components(support))

            bad_cycles = [
                component
                for component in components
                if all(support.degree(vertex) == 2 for vertex in component)
            ]
            if bad_cycles:
                for component in bad_cycles:
                    indices = tuple(
                        index
                        for index, (u, v) in enumerate(edges)
                        if u in component and v in component
                    )
                    key = ("cycle", indices)
                    if key in seen_cuts:
                        raise RuntimeError("repeated cycle cut")
                    seen_cuts.add(key)
                    row = np.zeros(len(edges))
                    row[list(indices)] = 1
                    rows.append(row)
                    lower.append(-np.inf)
                    upper.append(len(component) - 1)
                continue

            paired_component = nx.node_connected_component(support, paired[0])
            if paired[1] not in paired_component:
                indices = tuple(
                    index
                    for index, (u, v) in enumerate(edges)
                    if (u in paired_component) != (v in paired_component)
                )
                key = ("terminal", indices)
                if key in seen_cuts:
                    raise RuntimeError("repeated terminal cut")
                seen_cuts.add(key)
                row = np.zeros(len(edges))
                row[list(indices)] = 1
                rows.append(row)
                lower.append(1)
                upper.append(np.inf)
                continue

            assert len(components) == 2
            assert nx.has_path(support, singleton, endpoint_y)
            return endpoint_y, chosen

    return None


def find_unrestricted_fibre_forest(
    graph: nx.Graph,
    root: int,
    singleton_index: int,
    edge_cost: np.ndarray | None = None,
) -> tuple[tuple[int, int], ...] | None:
    """Find any forest in the fixed port fibre, without Y-degree caps."""
    colour = nx.bipartite.color(graph)
    x_vertices = tuple(sorted(v for v in graph if colour[v] != colour[root]))
    ports = tuple(sorted(graph[root]))
    singleton = ports[singleton_index]
    paired = tuple(port for port in ports if port != singleton)
    vertices = tuple(sorted(set(graph) - {root}))
    edges = tuple(sorted(edge_key(u, v) for u, v in graph.edges() if root not in (u, v)))
    objective = np.zeros(len(edges)) if edge_cost is None else np.asarray(edge_cost, dtype=float)
    if objective.shape != (len(edges),):
        raise ValueError("edge_cost has the wrong length")

    rows = []
    lower = []
    upper = []
    for vertex in x_vertices:
        row = np.asarray([int(vertex in edge) for edge in edges], dtype=float)
        target = 1 if vertex in ports else 2
        rows.append(row)
        lower.append(target)
        upper.append(target)

    seen_cuts: set[tuple[str, tuple[int, ...]]] = set()
    while True:
        constraints = LinearConstraint(np.asarray(rows), np.asarray(lower), np.asarray(upper))
        result = milp(
            c=objective,
            integrality=np.ones(len(edges)),
            bounds=Bounds(np.zeros(len(edges)), np.ones(len(edges))),
            constraints=constraints,
            options={"presolve": True},
        )
        if not result.success:
            return None

        chosen = tuple(edges[index] for index, value in enumerate(result.x) if value > 0.5)
        support = nx.Graph()
        support.add_nodes_from(vertices)
        support.add_edges_from(chosen)
        components = tuple(nx.connected_components(support))
        bad_cycles = [
            component
            for component in components
            if support.subgraph(component).number_of_edges() >= len(component)
        ]
        if bad_cycles:
            for component in bad_cycles:
                indices = tuple(
                    index
                    for index, (u, v) in enumerate(edges)
                    if u in component and v in component
                )
                key = ("cycle", indices)
                if key in seen_cuts:
                    raise RuntimeError("repeated unrestricted cycle cut")
                seen_cuts.add(key)
                row = np.zeros(len(edges))
                row[list(indices)] = 1
                rows.append(row)
                lower.append(-np.inf)
                upper.append(len(component) - 1)
            continue

        assert len(components) == 2
        paired_component = nx.node_connected_component(support, paired[0])
        if paired[1] not in paired_component:
            component = paired_component
            cut_kind = "paired"
        elif singleton in paired_component:
            component = next(component for component in components if singleton not in component)
            cut_kind = "hidden"
        else:
            return chosen

        indices = tuple(
            index
            for index, (u, v) in enumerate(edges)
            if (u in component) != (v in component)
        )
        key = (cut_kind, indices)
        if key in seen_cuts:
            raise RuntimeError("repeated unrestricted connectivity cut")
        seen_cuts.add(key)
        row = np.zeros(len(edges))
        row[list(indices)] = 1
        rows.append(row)
        lower.append(1)
        upper.append(np.inf)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=int, required=True)
    parser.add_argument("--fibre", type=int, choices=range(3), required=True)
    args = parser.parse_args()

    graph = nx.from_graph6_bytes(GRAPH6.encode())
    unrestricted = find_unrestricted_fibre_forest(graph, args.root, args.fibre)
    result = solve_fibre(graph, args.root, args.fibre)
    print("root", args.root, "ports", tuple(sorted(graph[args.root])), "fibre", args.fibre)
    print("fixed_fibre_feasible", unrestricted is not None)
    print("fixed_fibre_witness", unrestricted)
    print("result", result)
    print("TWO_PATH_FOUND" if result else "NO_TWO_PATH")


if __name__ == "__main__":
    main()
