#!/usr/bin/env python3
"""Flow-extended MILP for one fixed Ellingham--Horton cap fibre.

The two simultaneous spanning-tree conditions encode the fixed terminal
partition exactly, avoiding iterative subtour cuts.  Only edge-selection
variables are integral; flow variables are continuous connectivity witnesses.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path

import networkx as nx
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("eh_base", HERE / "test_ellingham_horton_two_path.py")
assert SPEC is not None and SPEC.loader is not None
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)


def optimize_fixed_fibre(
    graph: nx.Graph,
    root: int,
    singleton_index: int,
    y_weights: dict[int, float] | None = None,
    y_capacity_two: bool = False,
):
    colour = nx.bipartite.color(graph)
    x_vertices = tuple(sorted(v for v in graph if colour[v] != colour[root]))
    y_vertices = tuple(sorted(v for v in graph if colour[v] == colour[root] and v != root))
    ports = tuple(sorted(graph[root]))
    singleton = ports[singleton_index]
    paired = tuple(port for port in ports if port != singleton)
    vertices = tuple(sorted(graph))
    p_edges = tuple(
        sorted(BASE.edge_key(u, v) for u, v in graph.edges() if root not in (u, v))
    )
    edge_index = {edge: index for index, edge in enumerate(p_edges)}
    q = len(p_edges)
    tree_fixed = (
        (BASE.edge_key(root, singleton), BASE.edge_key(root, paired[0])),
        (BASE.edge_key(root, singleton), BASE.edge_key(root, paired[1])),
    )
    augmented_edges = tuple(p_edges + fixed for fixed in tree_fixed)
    flow_offsets = (q, q + 2 * len(augmented_edges[0]))
    variable_count = q + sum(2 * len(edges) for edges in augmented_edges)
    big_m = len(vertices) - 1

    objective = np.zeros(variable_count)
    if y_weights is not None:
        for edge, index in edge_index.items():
            y = edge[0] if edge[0] in y_vertices else edge[1]
            objective[index] = y_weights[y]

    lower_bounds = np.zeros(variable_count)
    upper_bounds = np.full(variable_count, float(big_m))
    upper_bounds[:q] = 1
    integrality = np.zeros(variable_count)
    integrality[:q] = 1

    rows: list[np.ndarray] = []
    lower: list[float] = []
    upper: list[float] = []

    for x in x_vertices:
        row = np.zeros(variable_count)
        for edge, index in edge_index.items():
            if x in edge:
                row[index] = 1
        target = 1 if x in ports else 2
        rows.append(row)
        lower.append(target)
        upper.append(target)

    if y_capacity_two:
        for y in y_vertices:
            row = np.zeros(variable_count)
            for edge, index in edge_index.items():
                if y in edge:
                    row[index] = 1
            rows.append(row)
            lower.append(-np.inf)
            upper.append(2)

    for layer, edges in enumerate(augmented_edges):
        offset = flow_offsets[layer]
        for local_index, edge in enumerate(edges):
            if edge not in edge_index:
                continue
            selection = edge_index[edge]
            for direction in range(2):
                row = np.zeros(variable_count)
                row[offset + 2 * local_index + direction] = 1
                row[selection] = -big_m
                rows.append(row)
                lower.append(-np.inf)
                upper.append(0)

        for vertex in vertices:
            row = np.zeros(variable_count)
            for local_index, (u, v) in enumerate(edges):
                forward = offset + 2 * local_index
                reverse = forward + 1
                if vertex == u:
                    row[forward] -= 1
                    row[reverse] += 1
                elif vertex == v:
                    row[forward] += 1
                    row[reverse] -= 1
            target = -big_m if vertex == root else 1
            rows.append(row)
            lower.append(target)
            upper.append(target)

    result = milp(
        c=objective,
        integrality=integrality,
        bounds=Bounds(lower_bounds, upper_bounds),
        constraints=LinearConstraint(np.asarray(rows), np.asarray(lower), np.asarray(upper)),
        options={"presolve": True},
    )
    if not result.success:
        return result, None, None
    chosen = tuple(p_edges[index] for index, value in enumerate(result.x[:q]) if value > 0.5)
    degrees = tuple(sum(y in edge for edge in chosen) for y in y_vertices)
    return result, chosen, degrees


def main() -> None:
    graph = nx.from_graph6_bytes(BASE.GRAPH6.encode())
    result, chosen, degrees = optimize_fixed_fibre(graph, 52, 2, y_capacity_two=True)
    print("integral_capacity_two", result.success)
    print("message", result.message)
    print("chosen", chosen)
    print("degrees", degrees)
    print("EH54_FIXED_FIBRE_A_FAILURE" if not result.success else "EH54_FIXED_FIBRE_A_WITNESS")


if __name__ == "__main__":
    main()
