#!/usr/bin/env python3
"""Small random probe for the fixed-fibre multiple-hole surplus bounds.

This is deliberately a sample, not a census.  A graph is generated as the
union of three disjoint random perfect matchings between equally sized colour
classes.  Strict Hall expansion is checked exactly before any fibre is used.
"""

from __future__ import annotations

import argparse
from itertools import combinations, product
import random

import networkx as nx


def random_cubic_bipartite(n: int, rng: random.Random) -> nx.Graph:
    while True:
        perms: list[list[int]] = []
        edges: set[tuple[int, int]] = set()
        for _ in range(3):
            p = list(range(n))
            rng.shuffle(p)
            if any((x, p[x]) in edges for x in range(n)):
                break
            perms.append(p)
            edges.update((x, p[x]) for x in range(n))
        if len(perms) != 3:
            continue
        graph = nx.Graph()
        graph.add_nodes_from(range(n), bipartite=0)
        graph.add_nodes_from(range(n, 2 * n), bipartite=1)
        graph.add_edges_from((x, n + y) for x, y in edges)
        if nx.is_connected(graph):
            return graph


def is_brace(graph: nx.Graph, n: int) -> bool:
    # For a balanced bipartite graph, 2-extendability is equivalent to
    # |N(U)| >= |U|+2 for every 1 <= |U| <= n-2.
    x_vertices = tuple(range(n))
    for size in range(1, n - 1):
        for subset in combinations(x_vertices, size):
            neighbours = set().union(*(set(graph[x]) for x in subset))
            if len(neighbours) < size + 2:
                return False
    return True


class DSU:
    def __init__(self, vertices):
        self.parent = {v: v for v in vertices}

    def find(self, v):
        while self.parent[v] != v:
            self.parent[v] = self.parent[self.parent[v]]
            v = self.parent[v]
        return v

    def union(self, u, v) -> bool:
        ru, rv = self.find(u), self.find(v)
        if ru == rv:
            return False
        self.parent[rv] = ru
        return True


def rooted_fibre_vectors(graph: nx.Graph, n: int, root: int):
    x_vertices = tuple(range(n))
    y_vertices = tuple(y for y in range(n, 2 * n) if y != root)
    ports = tuple(sorted(graph[root]))
    choices = [tuple(y for y in graph[x] if y != root) for x in x_vertices]
    fibres: list[set[tuple[int, ...]]] = [set(), set(), set()]
    vertices = tuple(v for v in graph if v != root)

    for omitted in product(*choices):
        omitted_by_x = dict(zip(x_vertices, omitted))
        dsu = DSU(vertices)
        acyclic = True
        for x in x_vertices:
            for y in graph[x]:
                if y == root or y == omitted_by_x[x]:
                    continue
                if not dsu.union(x, y):
                    acyclic = False
                    break
            if not acyclic:
                break
        if not acyclic:
            continue
        port_roots = tuple(dsu.find(t) for t in ports)
        singleton = [i for i in range(3) if port_roots.count(port_roots[i]) == 1]
        if len(singleton) != 1:
            continue
        if len(set(port_roots)) != 2:
            continue
        multiplicity = {y: 0 for y in y_vertices}
        for y in omitted:
            multiplicity[y] += 1
        vector = tuple(3 - multiplicity[y] for y in y_vertices)
        fibres[singleton[0]].add(vector)
    return y_vertices, fibres


def first_failure(vectors, weak: bool):
    m = len(next(iter(vectors)))
    for mask in range(1, 1 << m):
        h = mask.bit_count()
        threshold = 2 * h if weak or h == 1 else 2 * h - 1
        value = min(
            sum(vector[j] for j in range(m) if mask >> j & 1)
            for vector in vectors
        )
        if value > threshold:
            return mask, value, threshold
    return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--side", type=int, default=10)
    parser.add_argument("--braces", type=int, default=20)
    parser.add_argument("--seed", type=int, default=20260826)
    args = parser.parse_args()
    rng = random.Random(args.seed)
    accepted = 0
    generated = 0
    while accepted < args.braces:
        graph = random_cubic_bipartite(args.side, rng)
        generated += 1
        if not is_brace(graph, args.side):
            continue
        accepted += 1
        for root in range(args.side, 2 * args.side):
            y_vertices, fibres = rooted_fibre_vectors(graph, args.side, root)
            for index, vectors in enumerate(fibres):
                if not vectors:
                    continue
                weak_failure = first_failure(vectors, weak=True)
                strong_failure = first_failure(vectors, weak=False)
                if weak_failure or strong_failure:
                    failure_kind = "weak" if weak_failure else "strong"
                    mask, value, threshold = weak_failure or strong_failure
                    holes = tuple(y_vertices[j] for j in range(len(y_vertices)) if mask >> j & 1)
                    print("COUNTEREXAMPLE", failure_kind)
                    print("graph6", nx.to_graph6_bytes(graph, header=False).decode().strip())
                    print("side", args.side, "root", root, "fibre", index)
                    print("holes", holes, "minimum", value, "threshold", threshold)
                    print("vectors", len(vectors))
                    return
        print("checked_brace", accepted, "generated", generated)
    print("NO_FAILURE_IN_SAMPLE", "accepted", accepted, "generated", generated)


if __name__ == "__main__":
    main()
