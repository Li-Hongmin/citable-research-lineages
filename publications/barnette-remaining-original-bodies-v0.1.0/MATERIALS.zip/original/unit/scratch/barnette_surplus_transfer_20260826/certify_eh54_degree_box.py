#!/usr/bin/env python3
"""Construct a small rational degree-box certificate in the EH54 fibre."""

from __future__ import annotations

import importlib.util
from fractions import Fraction
from pathlib import Path

import networkx as nx
import numpy as np
import sympy as sp
from scipy.optimize import linprog


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("eh_flow", HERE / "solve_eh54_common_bases.py")
assert SPEC is not None and SPEC.loader is not None
FLOW = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(FLOW)


def degree_vector(forest, y_vertices):
    return tuple(sum(y in edge for edge in forest) for y in y_vertices)


def main() -> None:
    graph = nx.from_graph6_bytes(FLOW.BASE.GRAPH6.encode())
    root = 52
    singleton_index = 2
    singleton = sorted(graph[root])[singleton_index]
    colour = nx.bipartite.color(graph)
    y_vertices = tuple(
        sorted(v for v in graph if v != root and colour[v] == colour[root])
    )
    stabilizer = [
        mapping
        for mapping in nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter()
        if mapping[root] == root and mapping[singleton] == singleton
    ]
    print("stabilizer_size", len(stabilizer), flush=True)

    _, seed, _ = FLOW.optimize_fixed_fibre(graph, root, singleton_index)
    assert seed is not None
    forests: dict[tuple[int, ...], tuple[tuple[int, int], ...]] = {}

    def add_orbit(forest) -> None:
        for mapping in stabilizer:
            image = tuple(
                sorted(FLOW.BASE.edge_key(mapping[u], mapping[v]) for u, v in forest)
            )
            forests.setdefault(degree_vector(image, y_vertices), image)

    add_orbit(seed)
    primal = None
    for iteration in range(20):
        degree_rows = np.asarray(list(forests), dtype=float)
        column_count = len(degree_rows)
        objective = np.r_[np.zeros(len(y_vertices)), -1.0]
        upper_matrix = np.hstack([-degree_rows, np.ones((column_count, 1))])
        dual = linprog(
            c=objective,
            A_ub=upper_matrix,
            b_ub=np.zeros(column_count),
            A_eq=np.asarray([np.r_[np.ones(len(y_vertices)), 0.0]]),
            b_eq=[1.0],
            bounds=[(0, None)] * len(y_vertices) + [(None, None)],
            method="highs",
        )
        assert dual.success
        weights = dual.x[:-1]
        restricted_value = dual.x[-1]
        oracle, forest, _ = FLOW.optimize_fixed_fibre(
            graph,
            root,
            singleton_index,
            dict(zip(y_vertices, weights)),
        )
        assert oracle.success and forest is not None
        print(
            "iteration",
            iteration,
            "columns",
            len(forests),
            "restricted_value",
            restricted_value,
            "oracle_value",
            oracle.fun,
            flush=True,
        )
        add_orbit(forest)

        matrix = np.asarray(list(forests), dtype=float).T
        primal = linprog(
            c=np.zeros(matrix.shape[1]),
            A_ub=matrix,
            b_ub=np.full(len(y_vertices), 2.0),
            A_eq=np.ones((1, matrix.shape[1])),
            b_eq=[1.0],
            bounds=(0, None),
            method="highs",
        )
        if primal.success:
            break

    assert primal is not None and primal.success
    matrix = np.asarray(list(forests), dtype=float).T
    support = tuple(index for index, value in enumerate(primal.x) if value > 1e-8)
    print("pool_columns", matrix.shape[1])
    print("basic_support", len(support))

    support_matrix = matrix[:, support]
    vertex_weights = primal.x[list(support)]
    assert min(vertex_weights) > 1e-8

    active = [
        row for row, value in enumerate(support_matrix @ vertex_weights) if abs(value - 2) < 1e-7
    ]
    exact_rows = [sp.ones(1, len(support))]
    exact_rhs = [sp.Integer(1)]
    current_rank = 1
    for row in active:
        candidate = exact_rows + [sp.Matrix([[int(x) for x in support_matrix[row]]])]
        rank = sp.Matrix.vstack(*candidate).rank()
        if rank > current_rank:
            exact_rows = candidate
            exact_rhs.append(sp.Integer(2))
            current_rank = rank
        if current_rank == len(support):
            break
    assert current_rank == len(support)
    exact_solution = sp.Matrix.vstack(*exact_rows).inv() * sp.Matrix(exact_rhs)
    rational = tuple(Fraction(int(value.p), int(value.q)) for value in exact_solution)
    assert all(value > 0 for value in rational)
    assert sum(rational) == 1

    selected_vectors = [list(forests)[index] for index in support]
    selected_forests = [forests[vector] for vector in selected_vectors]
    expectations = tuple(
        sum(weight * vector[coordinate] for weight, vector in zip(rational, selected_vectors))
        for coordinate in range(len(y_vertices))
    )
    assert max(expectations) <= 2

    print("y_order", y_vertices)
    print("weights", tuple(str(weight) for weight in rational))
    print("expectations", tuple(str(value) for value in expectations))
    for index, (weight, vector, forest) in enumerate(
        zip(rational, selected_vectors, selected_forests)
    ):
        print("certificate", index, "weight", weight)
        print("degree_vector", vector)
        print("forest", forest)
    print("EH54_FIXED_FIBRE_DEGREE_BOX_CERTIFIED")


if __name__ == "__main__":
    main()
