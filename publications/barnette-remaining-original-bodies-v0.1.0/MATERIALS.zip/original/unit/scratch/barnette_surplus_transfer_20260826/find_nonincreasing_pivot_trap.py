#!/usr/bin/env python3
"""Find an over-budget sink plateau of same-X pivots in fixed braces."""

from __future__ import annotations

import argparse
from collections import deque
from itertools import product

import networkx as nx


GRAPH6 = (
    ("cube", "G?zTb_"),
    ("brace12", "K??FEagT@WB_"),
    ("brace16a", "O????B_sDOI_I_DO@W?M?"),
    ("brace16b", "O????B_sCWKOI_BOAW?i?"),
    ("brace18", "Q??????wE_P_W_IO@g?h?Cg?B_?"),
)


def states(graph: nx.Graph, root: int):
    colour = nx.bipartite.color(graph)
    x_vertices = tuple(sorted(x for x in graph if colour[x] != colour[root]))
    y_vertices = tuple(sorted(y for y in graph if colour[y] == colour[root] and y != root))
    ports = tuple(sorted(graph[root]))
    choices = tuple(tuple(sorted(y for y in graph[x] if y != root)) for x in x_vertices)
    vertices = set(graph) - {root}
    fibres = [dict(), dict(), dict()]
    for omitted in product(*choices):
        omitted_by_x = dict(zip(x_vertices, omitted))
        selected = [
            (x, y)
            for x in x_vertices
            for y in graph[x]
            if y != root and y != omitted_by_x[x]
        ]
        forest = nx.Graph()
        forest.add_nodes_from(vertices)
        forest.add_edges_from(selected)
        if not nx.is_forest(forest) or nx.number_connected_components(forest) != 2:
            continue
        comp = {}
        for number, component in enumerate(nx.connected_components(forest)):
            for vertex in component:
                comp[vertex] = number
        roots = tuple(comp[t] for t in ports)
        singleton = [i for i in range(3) if roots.count(roots[i]) == 1]
        if len(singleton) != 1 or len(set(roots)) != 2:
            continue
        multiplicity = {y: 0 for y in y_vertices}
        for y in omitted:
            multiplicity[y] += 1
        vector = tuple(3 - multiplicity[y] for y in y_vertices)
        fibres[singleton[0]][omitted] = vector
    return x_vertices, y_vertices, choices, fibres


def neighbours(key, choices, valid):
    for coordinate, options in enumerate(choices):
        for value in options:
            if value == key[coordinate]:
                continue
            other = key[:coordinate] + (value,) + key[coordinate + 1 :]
            if other in valid:
                yield other


def first_trap(valid, choices, mask: int, strong: bool):
    load = {
        key: sum(value for j, value in enumerate(vector) if mask >> j & 1)
        for key, vector in valid.items()
    }
    unseen = set(valid)
    while unseen:
        start = min(unseen)
        level = load[start]
        stack = [start]
        plateau = set()
        lower_exit = False
        while stack:
            key = stack.pop()
            if key in plateau:
                continue
            plateau.add(key)
            unseen.discard(key)
            for other in neighbours(key, choices, valid):
                if load[other] < level:
                    lower_exit = True
                elif load[other] == level and other not in plateau:
                    stack.append(other)
        threshold = 2 * mask.bit_count() - int(strong and mask.bit_count() >= 2)
        if not lower_exit and level > threshold:
            return level, plateau, min(load.values())
    return None


def barrier_one_path(valid, choices, mask: int, plateau, level: int, target_level: int):
    """Return an actual path to a target minimum using load at most level+1."""
    load = {
        key: sum(value for j, value in enumerate(vector) if mask >> j & 1)
        for key, vector in valid.items()
    }
    start = min(plateau)
    queue = deque([start])
    previous = {start: None}
    target = None
    while queue:
        key = queue.popleft()
        if load[key] == target_level:
            target = key
            break
        for other in neighbours(key, choices, valid):
            if load[other] <= level + 1 and other not in previous:
                previous[other] = key
                queue.append(other)
    if target is None:
        return None
    path = []
    key = target
    while key is not None:
        path.append((key, load[key], valid[key]))
        key = previous[key]
    return tuple(reversed(path))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--strong", action="store_true")
    args = parser.parse_args()
    for name, graph6 in GRAPH6:
        graph = nx.from_graph6_bytes(graph6.encode())
        for root in sorted(graph):
            x_vertices, y_vertices, choices, fibres = states(graph, root)
            for fibre, valid in enumerate(fibres):
                for mask in range(1, 1 << len(y_vertices)):
                    trap = first_trap(valid, choices, mask, args.strong)
                    if trap:
                        level, plateau, global_min = trap
                        holes = tuple(y_vertices[j] for j in range(len(y_vertices)) if mask >> j & 1)
                        print("PIVOT_TRAP")
                        print("graph", name, "graph6", graph6)
                        print("root", root, "fibre", fibre, "ports", tuple(sorted(graph[root])))
                        budget = 2 * len(holes) - int(args.strong and len(holes) >= 2)
                        print("holes", holes, "level", level, "budget", budget)
                        print("global_min", global_min, "plateau_size", len(plateau))
                        print("representative", min(plateau))
                        print("x_order", x_vertices, "y_order", y_vertices)
                        path = barrier_one_path(
                            valid, choices, mask, plateau, level, global_min
                        )
                        print("barrier_one_path", path)
                        return
        print("checked", name)
    print("NO_PIVOT_TRAP")


if __name__ == "__main__":
    main()
