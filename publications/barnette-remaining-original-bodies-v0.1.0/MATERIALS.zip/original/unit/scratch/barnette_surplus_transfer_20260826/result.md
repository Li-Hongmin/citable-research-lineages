# Multiple-hole surplus transfer: Hall-tight shores or positive pivot gates

This leaf uses only Notes 052--054 and
scratch/worker-cap-flex-proof/multiple-hole-cap-flexibility-boundary.md as
mathematical inputs. Permanent notes and papers are unchanged.

## Statement under test

Let \(F\) be a simple cubic bipartite brace with bipartition
\(X\sqcup Y\), let \(r\in Y\), and put \(P=F-r\). All three ports
\(T=N_F(r)=\{t_1,t_2,t_3\}\subseteq X\) are selected. Fix one feasible
two-block fibre

\[
\pi_i=\{\{i\},[3]\setminus\{i\}\},
\qquad \mathcal F_i\ne\varnothing,
\]

and a nonempty \(H\subseteq Y\setminus\{r\}\). For
\(J\in\mathcal F_i\), write

\[
\ell_H(J)=\sum_{h\in H}\deg_J(h).
\]

The weak assertion is

\[
\min_{J\in\mathcal F_i}\ell_H(J)\le 2|H|. \tag{W}
\]

For \(K_J=E(P)\setminus J\), every \(x\in X\) is incident with exactly
one edge of \(K_J\), and

\[
q_J(y)=2-\deg_J(y)=\deg_{K_J}(y)-1,
\qquad
\sum_{y\in Y\setminus\{r\}}q_J(y)=1. \tag{1}
\]

Thus (W) is equivalently

\[
\max_{J\in\mathcal F_i}\sum_{h\in H}
   \bigl(\deg_{K_J}(h)-1\bigr)\ge0. \tag{2}
\]

The conclusion of this leaf is a strict reduction, not a proof of (W) and
not an actual brace counterexample to (W).

## A Hall-certified fractional bound before fixing the port partition

There is a clean relaxation in which the weak bound is automatic. Put

\[
d_x=\begin{cases}1,&x\in T,\\2,&x\notin T,\end{cases}
\qquad
z^0_e=\begin{cases}
1/2,&e\text{ is incident with a port},\\
2/3,&\text{otherwise}.
\end{cases} \tag{3}
\]

Then \(z^0(\delta_P(x))=d_x\) for every \(x\in X\), and every
\(y\in Y\setminus\{r\}\) has incident \(z^0\)-load at most two.
Moreover, \(z^0\) lies in the graphic forest polytope of \(P\).

To prove the last assertion, take \(W=A\sqcup B\subseteq V(P)\), where
\(A\subseteq X\), \(B\subseteq Y\setminus\{r\}\), and put
\(a=|A|\), \(b=|B|\), \(p=|A\cap T|\). The two colour-side degree bounds
give

\[
z^0(E_P[W])\le 2a-p,
\qquad
z^0(E_P[W])\le2b. \tag{4}
\]

If \(a\ne b\), or if \(a=b\) and \(p\ge1\), these inequalities already
give \(z^0(E_P[W])\le a+b-1\). The only remaining case is \(a=b\) and
\(p=0\). All internal edges then have weight \(2/3\). If there were at
least \(3a-1\) such edges, at most one of the \(3a\) edges out of \(A\)
would end outside \(B\), so

\[
|N_F(A)|\le a+1.
\]

Since \(A\cap T=\varnothing\), one has \(1\le a\le |X|-3\), and this
contradicts the brace strict Hall inequality
\(|N_F(A)|\ge |A|+2\). Hence

\[
z^0(E_P[W])\le \tfrac23(3a-2)<2a-1=|W|-1. \tag{5}
\]

The intersection of the graphic-forest polytope with the
partition-matroid polytope
\(z(\delta_P(x))\le d_x\) is integral. Its face of total size
\(2|X|-3\) therefore contains an integral forest \(J\) with all
prescribed \(X\)-degrees and

\[
\ell_H(J)\le z^0(\delta_P(H))\le2|H|. \tag{6}
\]

Such a forest has exactly two components. Its port distribution, however,
may be any of the three \(1\mid2\) partitions or the hidden-component type
\(0\mid3\). The hidden type is real even in the cube: for one root there
are 18 \(1\mid2\) forests and 6 \(0\mid3\) forests. Thus (6) proves that
Hall expansion already controls the degree/graphic relaxation; the entire
remaining issue is the integral terminal-partition face selecting the fixed
\(\pi_i\).

## Exact minimal-token exit lemma

Assume, for contradiction, that the weak bound fails, and put

\[
L=\min_{J\in\mathcal F_i}\ell_H(J)>2|H|. \tag{7}
\]

Choose an \(L\)-minimizer \(J\) with the minimum possible number of
degree-three holes. Some \(h\in H\) has \(\deg_J(h)=3\). Among all such
choices, choose a component \(C\) of \(J-h\) containing no port with
\(|V(C)|\) minimum. Such a branch exists because the component of \(J\)
containing \(h\) contains at most two of the three ports.

Put \(U=X\cap C\), \(V=Y\cap C\). The same degree count used in Note 054
gives

\[
|U|=|V|. \tag{8}
\]

The branch is port-free, so \(1\le |U|\le |X|-3\). Strict Hall expansion
therefore gives a neighbour of \(U\) outside \(V\cup\{h\}\). Let

\[
e=xy,\qquad x\in U,\quad y\notin V\cup\{h\}, \tag{9}
\]

be such an edge. It is not in \(J\). Let \(f=xy_f\) be the first edge on
the \(J\)-path from \(x\) towards \(h\). Then

\[
J'=J-f+e \tag{10}
\]

is a forest in the same fibre: the part cut from \(C\) contains no port and
is merely reattached either elsewhere in the same component or to the other
component. Its load change is

\[
\ell_H(J')-\ell_H(J)=\mathbf1_H(y)-\mathbf1_H(y_f). \tag{11}
\]

Minimality has the following exact consequences.

1. **No exit to \(Y\setminus H\).** If \(y\notin H\) and \(y_f\in H\),
   (11) lowers the load. If both are outside \(H\), (11) preserves the load
   and \(f\ne xh\); the remaining branch at \(h\) is a proper nonempty
   port-free subbranch of \(C\). Both alternatives contradict the choice.
   Hence every Hall exit in (9) ends in \(H\).

2. **A zero-cost exit is a whole-branch token transfer.** If
   \(y_f\in H\) but \(f\ne xh\), the pivot preserves load and leaves a
   smaller branch at the still degree-three hole \(h\), again impossible.
   Therefore a zero-cost exit has \(f=xh\). The old hole drops from degree
   three to two. Since \(e\notin J\), one has \(\deg_J(y)\le2\); the
   secondary minimization forces \(\deg_J(y)=2\), and hence
   \(\deg_{J'}(y)=3\). Thus (10) moves the overload token from \(h\) to
   \(y\), leaving the internal tree \(J[C]\) unchanged.

3. **Every other exit is a positive gate.** It has \(y\in H\),
   \(y_f\notin H\), and raises the load by exactly one.

This is the exact exchange obstruction. The nonincreasing same-\(X\)
graph can move the same minimal branch only by whole-branch token
transfers. Its attachment vertex in \(U\) has one internal
\(J[C]\)-edge and, by cubicity, only two possible external neighbours.
Consequently a zero-transfer class has at most two attachment holes.

Let \(R_0\subseteq H\) be those attachment holes and let
\(G\subseteq H\) be the endpoints of the positive gates from interior
vertices of \(C\). The exit lemma gives the exact neighbourhood identity

\[
N_F(U)=V\cup R_0\cup G,\qquad |V|=|U|, \tag{12}
\]

and brace Hall expansion says only

\[
|R_0\cup G|\ge2. \tag{13}
\]

Therefore every minimum nonincreasing token class falls into the following
dichotomy.

* If \(G=\varnothing\), then \(|R_0|=2\) and

  \[
  |N_F(U)|=|U|+2. \tag{14}
  \]

  The class is exactly a Hall-tight shore of a brace. This is allowed by
  \(2\)-extendability; it is not a Hall contradiction.
* If \(G\ne\varnothing\), every route seen by this branch but omitted from
  the nonincreasing class first pays one unit of load. Hall expansion does
  not constrain the removed endpoint \(y_f\), so it cannot turn such a gate
  into a nonpositive pivot.

Thus the proposed conversion of every closed nonincreasing class into a
contradictory Hall set stops sharply: the best no-gate conclusion is the
permitted equality (14), while the alternative is an explicit barrier-one
exchange gate. A proof of (W) must couple two or more pivots across that
gate, or use additional structure of Hall-tight shores. Ordinary strict
Hall expansion and one-pivot closure do not supply that coupling.

## A real brace barrier for the proposed strengthening

The stronger candidate

\[
\min_{J\in\mathcal F_i}\ell_H(J)\le2|H|-1
\qquad(|H|\ge2) \tag{S}
\]

also remains undecided. It cannot be obtained by simply extending the
nonincreasing overload-token descent to the equality layer. The planar
12-vertex brace with graph6 string

\[
\texttt{K??FEagT@WB\_}
\]

has, for root \(r=0\), ports \((6,7,8)\), fibre \(\pi_1\), and
\(H=\{3,4\}\), a two-state sink plateau under all same-\(X\) pivots. In
the \(X\)-order \((6,7,8,9,10,11)\), the omitted-edge endpoint tuples are

\[
(1,1,2,3,4,5),\qquad (2,1,2,3,4,5). \tag{15}
\]

Their \(Y\setminus\{r\}\)-degree vectors are respectively

\[
(1,2,2,2,2),\qquad(2,1,2,2,2), \tag{16}
\]

so both have \(H\)-load \(4\). Every pivot leaving this plateau has load
\(5\), whereas the exact fibre minimum is \(3\). One shortest load sequence
is

\[
4\longrightarrow5\longrightarrow4\longrightarrow3. \tag{17}
\]

Thus the stronger bound is true in this instance, but every route from this
plateau must first increase the load. At equality \(2|H|\), all holes in
(16) have degree two and there is no overload token from which the weak
argument could start.

The script find_nonincreasing_pivot_trap.py exhausts the complete fixed
fibre and verifies (15)--(17). The graph is simple, cubic, bipartite,
planar, and satisfies the strict Hall inequalities, hence is a real brace.

## Minimal finite probe (non-bearing)

The script probe_random_brace_surplus.py sampled exact fibres of 10 random
braces of order 20, 5 of order 22, and 1 of order 24. Every root, every
feasible fibre, and every nonempty hole set in those sampled graphs
satisfied (S). This is only counterexample-search evidence; it is neither a
census nor part of the analytic reduction.

## Exact conclusion and remaining boundary

* **Weak bound (W):** neither proved nor refuted. It is proved for the
  integral graphic--degree relaxation before selecting the fixed terminal
  partition. Any actual failure reduces to the Hall-tight/positive-gate
  dichotomy (12)--(14) at a globally minimum overload branch.
* **Strong bound (S):** neither proved nor refuted. The real brace plateau
  (15)--(17) strictly closes a purely nonincreasing same-\(X\) proof at the
  equality layer.
* **Missing implication:** show that a Hall-tight shore or a barrier-one
  positive gate admits a coupled exchange whose total load change is
  negative while the fixed port partition is restored. No statement in
  Notes 052--054 gives such a multi-pivot exchange.

The weakest load-bearing point is the use of the globally minimal branch in
the exit lemma: it classifies every single Hall exit, but it does not prove
that several positive gates can be composed inside the same fibre. That is
exactly the unresolved boundary, not a hidden claim of the reduction.
