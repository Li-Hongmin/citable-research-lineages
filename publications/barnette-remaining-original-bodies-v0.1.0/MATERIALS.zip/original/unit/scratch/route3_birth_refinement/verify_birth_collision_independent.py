"""Independent audit of advisor/gpt6pro-2026-09-25-note171-followup.md, IV.

Run from the unit directory:
    python3 -B scratch/route3_birth_refinement/verify_birth_collision_independent.py

Only the standard library is used; no project checker is imported. The
embedding is constructed by splitting oriented faces, not by the existing
checker's rotation surgery. The exhaustive check streams exact-degree edge
sets, without partition pruning or retaining a support table. At most 32
vertices / 48 edges are constructed; no graph census is performed.
"""

from collections import Counter
from itertools import combinations
from math import comb


def edge(u, v):
    return (min(u, v), max(u, v))


def darts(cycle):
    return tuple(zip(cycle, cycle[1:] + cycle[:1]))


def adjacency(n, edges):
    adj = [set() for _ in range(n)]
    for u, v in edges:
        assert 0 <= u < v < n
        adj[u].add(v)
        adj[v].add(u)
    return adj


def reach(adj, start, removed=frozenset()):
    seen, todo = {start}, [start]
    while todo:
        for v in adj[todo.pop()] - seen - removed:
            seen.add(v)
            todo.append(v)
    return seen


def rotation(faces, n):
    turns = [{} for _ in range(n)]
    for face in faces:
        assert len(face) >= 4 and len(set(face)) == len(face)
        for i, v in enumerate(face):
            before, after = face[i - 1], face[(i + 1) % len(face)]
            assert before not in turns[v]
            turns[v][before] = after
    orders = []
    for turn in turns:
        assert len(turn) == 3 and set(turn) == set(turn.values())
        start = min(turn)
        order = (start, turn[start], turn[turn[start]])
        assert len(set(order)) == 3 and turn[order[-1]] == start
        orders.append(order)
    return tuple(orders)


def validate(n, edges, faces):
    adj = adjacency(n, edges)
    assert all(len(neighbours) == 3 for neighbours in adj)
    actual_darts = Counter(d for face in faces for d in darts(face))
    expected_darts = {(u, v) for u, v in edges} | {(v, u) for u, v in edges}
    assert set(actual_darts) == expected_darts
    assert all(count == 1 for count in actual_darts.values())
    rho = rotation(faces, n)
    assert all(set(rho[v]) == adj[v] for v in range(n))
    # Paired oriented darts and one cyclic link per vertex give an orientable
    # closed surface. Connectivity and Euler characteristic 2 certify a sphere.
    assert n - len(edges) + len(faces) == 2
    for size in range(3):
        for cut in combinations(range(n), size):
            removed = frozenset(cut)
            start = next(v for v in range(n) if v not in removed)
            assert len(reach(adj, start, removed)) == n - size
    colour = {0: 0}
    todo = [0]
    while todo:
        u = todo.pop()
        for v in adj[u]:
            if v not in colour:
                colour[v] = colour[u] ^ 1
                todo.append(v)
            assert colour[v] != colour[u]
    assert len(colour) == n
    return colour, rho


def locate(faces, site, colour):
    u, v, x, y = site
    assert len(set(site)) == 4 and colour[u] == colour[x]
    matches = []
    for i, face in enumerate(faces):
        for sign in (1, -1):
            walk = face[::sign]
            if u not in walk:
                continue
            pos = walk.index(u)
            walk = walk[pos:] + walk[:pos]
            if walk[1] != v or x not in walk:
                continue
            j = walk.index(x)
            if 2 <= j < len(walk) - 1 and walk[j + 1] == y:
                arcs = (j - 1, len(walk) - j - 1)
                assert all(length > 0 and length % 2 == 1 for length in arcs)
                matches.append((i, sign, walk, arcs))
    assert len(matches) == 1, (site, matches)
    return matches[0]


def expand(n, edges, faces, site, colour):
    face_id, sign, walk, arcs = locate(faces, site, colour)
    u, v, x, y = site
    a, b, c, d = range(n, n + 4)
    seals = {edge(u, v), edge(x, y)}
    born = {edge(*p) for p in ((u, a), (a, b), (b, v), (x, c),
                              (c, d), (d, y), (a, d), (b, c))}
    assert seals <= edges and len(born) == 8 and not born & edges
    result_edges = (edges - seals) | born
    subdivisions = {(u, v): (a, b), (v, u): (b, a),
                    (x, y): (c, d), (y, x): (d, c)}
    result_faces = []
    for i, face in enumerate(faces):
        if i != face_id:
            result_faces.append(tuple(z for p, q in darts(face)
                                      for z in (p, *subdivisions.get((p, q), ()))))
    j = walk.index(x)
    pieces = ((a, b, c, d), (b, *walk[1:j + 1], c),
              (d, *walk[j + 1:], u, a))
    result_faces.extend(piece[::sign] for piece in pieces)
    return result_edges, tuple(result_faces), born, seals, walk, arcs


def canonical_cycle(values):
    i = values.index(min(values))
    return values[i:] + values[:i]


def inverse_check(old, new, site):
    n, edges, _, _, rho = old
    _, out_edges, _, _, out_rho = new
    u, v, x, y = site
    a, b, c, d = range(n, n + 4)
    restored = {p for p in out_edges if max(p) < n} | {edge(u, v), edge(x, y)}
    assert restored == edges
    substitutions = {(u, a): v, (v, b): u, (x, c): y, (y, d): x}
    recovered = tuple(canonical_cycle(tuple(substitutions.get((z, w), w)
                                            for w in out_rho[z])) for z in range(n))
    assert recovered == rho


def row(n, chosen, boundary, targets):
    adj = adjacency(n, chosen)
    assert len(set(boundary)) == len(boundary)
    assert all(len(adj[v]) <= 2 if v in boundary else len(adj[v]) == 2
               for v in range(n))
    unseen, blocks, closed = set(range(n)), [], 0
    while unseen:
        component = reach(adj, min(unseen))
        unseen -= component
        hit = tuple(i for i, v in enumerate(boundary) if v in component)
        if hit:
            blocks.append(hit)
        else:
            closed += 1
    return (tuple(len(adj[v]) for v in boundary), tuple(sorted(blocks)),
            min(closed, 2), tuple(int(t in chosen) for t in targets))


def exact_degree_sets(n, available, required):
    """Enumerate all exact-degree edge sets, with only degree-based pruning.

    At each branch, partition the unknown edges incident to a chosen vertex
    into exactly the required number selected and the remainder excluded.
    Every feasible completion belongs to exactly one branch. Store one branch
    at a time; depth <= n, and each pivot has at most three incident edges.
    """
    ordered = tuple(sorted(available))
    incident = [0] * n
    for i, (u, v) in enumerate(ordered):
        incident[u] |= 1 << i
        incident[v] |= 1 << i

    def search(selected, unknown):
        pivot = None
        for v in range(n):
            pending = incident[v] & unknown
            need = required[v] - (incident[v] & selected).bit_count()
            count = pending.bit_count()
            if need < 0 or need > count:
                return
            if pending:
                candidate = (comb(count, need), v, need, pending)
                if pivot is None or candidate < pivot:
                    pivot = candidate
        if pivot is None:
            yield {p for i, p in enumerate(ordered) if selected >> i & 1}
            return
        _, _, need, pending = pivot
        indices = tuple(i for i in range(len(ordered)) if pending >> i & 1)
        for take in combinations(indices, need):
            yield from search(selected | sum(1 << i for i in take), unknown ^ pending)

    yield from search(0, (1 << len(ordered)) - 1)


def audit():
    sites = ((0, 1, 2, 3), (4, 0, 3, 7), (0, 13, 14, 3),
             (0, 16, 19, 3), (0, 8, 9, 1), (0, 24, 11, 3))
    input_faces = ((0, 1, 2, 3), (4, 0, 3, 7), (0, 13, 14, 3),
                   (0, 16, 19, 3), (0, 8, 9, 1, 5, 4, 12, 13, 17, 16, 21, 20),
                   (0, 24, 25, 8, 11, 3))
    cube_edges = {edge(*p) for p in ((0, 1), (1, 2), (2, 3), (3, 0),
                                    (4, 5), (5, 6), (6, 7), (7, 4),
                                    (0, 4), (1, 5), (2, 6), (3, 7))}
    cube_faces = ((0, 1, 2, 3), (4, 7, 6, 5), (0, 4, 5, 1),
                  (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0))
    colour, rho = validate(8, cube_edges, cube_faces)
    history = [(8, cube_edges, cube_faces, colour, rho)]
    edge_birth = dict.fromkeys(cube_edges, 0)
    vertex_birth = dict.fromkeys(range(8), 0)
    deleted, pools = {}, [cube_edges]
    print("GRAPH", (8, 12, 6), "simple_cubic_bipartite_sphere_3connected=True")
    for layer, site in enumerate(sites, 1):
        n, edges, faces, colour, _ = history[-1]
        out_edges, out_faces, born, seals, face, arcs = expand(n, edges, faces, site, colour)
        assert face == input_faces[layer - 1]
        out_colour, out_rho = validate(n + 4, out_edges, out_faces)
        result = (n + 4, out_edges, out_faces, out_colour, out_rho)
        inverse_check(history[-1], result, site)
        assert not born & set(edge_birth) and not seals & set(deleted)
        edge_birth.update(dict.fromkeys(born, layer))
        vertex_birth.update(dict.fromkeys(range(n, n + 4), layer))
        deleted.update(dict.fromkeys(seals, layer))
        pools.append(born)
        history.append(result)
        print("LEGAL_STEP", layer, "site=", site, "face=", face, "arcs=", arcs,
              "VEF=", (n + 4, len(out_edges), len(out_faces)), "inverse_rotation=True")
    n, edges, faces, colour, _ = Z = history[-2]
    hn, he, hf, hc, _ = H = history[-1]
    assert (n, hn) == (28, 32)
    assert set(vertex_birth) == set(range(hn))
    assert set(edge_birth) - set(deleted) == he
    assert all(edge_birth[p] < layer for p, layer in deleted.items())

    targets, qs, current = (edge(2, 6), edge(9, 10)), ((12, 13), (17, 16)), sites[-1]
    fresh = tuple(range(n, hn))
    assert edge(11, 3) in history[-3][1] & edges
    assert current == (sites[-2][0], 24, 11, 3)
    # The previous operation is fixed, so its complete successor Sigma_plus
    # is a function of this identical history, root and targets. No new q is
    # an argument of that old operation. This proves equality of the entire
    # old support without enumerating it or comparing hashes.
    old_context = (tuple(history[:-1]), sites[-2], (11, 3), current, targets)
    contexts = [(old_context, q) for q in qs]
    assert contexts[0][0] is contexts[1][0]

    names = ("U", "V", "X", "Y", "Q0", "Q1", "E0", "E1", "F0", "F1",
             "A", "B", "C", "D")
    keys, boundaries = [], []
    for side, q in zip(("A", "B"), qs):
        assert edge(*q) in edges & he
        vals = (*current, *q, *targets[0], *targets[1], *fresh)
        classes = tuple(dict.fromkeys(vals))
        quotient = tuple(classes.index(v) for v in vals)
        assert quotient == tuple(range(14))
        cw = tuple(hc[v] for v in classes)
        cw = min(cw, tuple(c ^ 1 for c in cw))
        exists = tuple(v < n for v in classes)
        controlled = {edge(*current[:2]): "UV", edge(*current[2:]): "XY", edge(*q): "q"}
        target_data = tuple((t == edge(*q), controlled.get(t, "external-existing"),
                             "live", "kernel-live" if edge_birth[t] == 0 else "older-live",
                             tuple(classes.index(v) for v in t), tuple(v < n for v in t))
                            for t in targets)
        _, _, face, lengths = locate(hf, (0, fresh[0], *q), hc)
        assert face == (0, 28, 29, 24, 27, 1, 5, 4, 12, 13, 17, 16, 21, 20)
        role = dict(zip(vals, names))
        j = face.index(q[0])
        face_code = ("UA", tuple(role[v] for v in face[1:j + 1] if v in role), "SEP",
                     tuple(role[v] for v in face[j + 1:] if v in role), "SEP")
        birth_layers = (edge_birth[edge(*q)], vertex_birth[q[0]], vertex_birth[q[1]])
        tags = tuple("kernel" if k == 0 else "last" if k == 5 else "older" for k in birth_layers)
        nu = (quotient, cw, target_data, exists, face_code)
        keys.append((nu, tuple(min(length, 3) for length in lengths), tags))
        boundaries.append(vals[:10])
        assert cw == (0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0)
        assert exists == (True,) * 10 + (False,) * 4
        assert face_code == ("UA", ("A", "B", "V", "Q0"), "SEP", ("Q1",), "SEP")
        assert tags == ("older",) * 3
        assert lengths == ((7, 5) if side == "A" else (9, 3))
        cap = {edge(0, 28), edge(*q)}
        owners = [(pool & he) - cap for pool in pools] + [cap]
        assert set().union(*owners) == he and sum(map(len, owners)) == len(he)
        print("CONTEXT", side, "q=", q, "arcs=", lengths, "birth_layers=", birth_layers,
              "tau_Z=", tags, "owners=", tuple(map(len, owners)))
    assert keys[0] == keys[1]
    print("EQUAL_ENRICHED_KEY", keys[0], "Sigma_plus=identical_previous_context")

    paths = ((3, 23, 20, 21, 22, 19, 16), (2, 1, 27, 26, 25, 8, 9))
    cycles = ((4, 5, 6, 7, 15, 12), (13, 14, 18, 17))
    witness = {edge(u, v) for path in paths for u, v in zip(path, path[1:])}
    witness |= {edge(u, v) for cycle in cycles for u, v in darts(cycle)}
    cuts = {edge(*current[:2]), edge(*current[2:])}
    assert witness <= edges - cuts - {edge(*qs[1])}
    expected = ((0, 0, 0, 1, 2, 1, 1, 2, 1, 0),
                ((0,), (1,), (2,), (3, 5), (4,), (6, 8), (7,), (9,)), 0, (0, 0))
    assert row(n, witness, boundaries[1], targets) == expected
    assert len(witness) == 22 and n - len(boundaries[1]) == 18
    print("WITNESS_B", "edges=", sorted(witness), "row=", expected)

    # Check every graph/row premise of the universal argument. On side A,
    # deleting 12--13 forces 12--4,12--15. beta_e=0 and d(6)=2 force
    # 6--5,6--7. d(10)=0, beta_e=0 and d(2)=1 force 2--1.
    # Hence 1--5 would connect the distinct 2/6 blocks and is forbidden.
    # Vertex 5 is internal, so 5--4 is forced. Now 12--4--5--6 connects
    # the distinct 12/6 blocks: a contradiction for EVERY realization.
    adj = adjacency(n, edges)
    required_a = dict.fromkeys(range(n), 2)
    required_a.update(zip(boundaries[0], expected[0]))
    assert adj[12] == {4, 13, 15} and required_a[12] == 2
    assert adj[6] == {2, 5, 7} and required_a[6] == 2
    assert adj[2] == {1, 6, 10} and required_a[2] == 1 and required_a[10] == 0
    assert adj[5] == {1, 4, 6} and 5 not in boundaries[0] and required_a[5] == 2
    assert targets[0] == edge(2, 6) and expected[3][0] == 0
    assert edge(*qs[0]) == edge(12, 13)
    block_at = {boundaries[0][i]: b for b, block in enumerate(expected[1]) for i in block}
    assert block_at[2] != block_at[6] and block_at[12] != block_at[6]
    assert {edge(2, 1), edge(1, 5), edge(5, 6), edge(12, 4), edge(4, 5)} <= edges - cuts
    print("UNIVERSAL_ABSENCE_A", "2-1-5-6 forbidden; 12-4-5-6 forced; blocks contradict")

    # Independent exhaustive corroboration: enumerate all subgraphs with the
    # prescribed degrees and beta=(0,0), then compute their full rows. No use
    # of the preceding forced-path argument occurs in this search.
    for side, q, boundary in zip(("A", "B"), qs, boundaries):
        required = [2] * n
        for v, degree in zip(boundary, expected[0]):
            required[v] = degree
        available = edges - cuts - {edge(*q)} - set(targets)
        degree_solutions = row_solutions = 0
        witness_seen = False
        for chosen in exact_degree_sets(n, available, required):
            degree_solutions += 1
            row_solutions += row(n, chosen, boundary, targets) == expected
            witness_seen |= chosen == witness
        assert degree_solutions > 0  # Degree feasibility alone does not separate this pair.
        assert (row_solutions == 0) if side == "A" else (row_solutions > 0 and witness_seen)
        print("EXHAUSTIVE", side, "degree_and_target_solutions=", degree_solutions,
              "complete_row_solutions=", row_solutions, "explicit_witness_seen=", witness_seen)
    print("BIRTH_REFINEMENT_COLLISION_INDEPENDENTLY_VERIFIED")


if __name__ == "__main__":
    audit()
