"""Direct r=2 Hamilton-path enumeration, independent of matching classification.

Run from the Barnette unit with python3 -B scratch/parent-joint-uniqueness-2026-09-28/verify_parent_uniqueness.py
Only one 16-vertex cubic graph; depth-first streaming, no dependencies or files.
"""

def edge(u, v):
    return tuple(sorted((u, v)))


def cycle_edges(path):
    return {edge(u, v) for u, v in zip(path, path[1:] + path[:1])}


m = 8  # r=2; T_i=i, B_i=m+i.
edges = {edge(base+i, base+(i+1) % m) for base in (0, m) for i in range(m)}
edges |= {edge(i, m+i) for i in range(m)}
adj = {v: sorted(w for u, w in edges if u == v) + sorted(u for u, w in edges if w == v)
       for v in range(2*m)}
required, forbidden = edge(0, m), edge(3, 4)
expected = {edge(i, m+i) for i in range(m)}
expected |= {edge(i, (i+1) % m) for i in range(0, m, 2)}
expected |= {edge(m+i, m+(i+1) % m) for i in range(1, m, 2)}
assert len(edges) == 24 and all(len(adj[v]) == 3 for v in adj)


def cycles(path, used):
    # Fix the orientation of the required edge: every relevant edge-set occurs once.
    last = path[-1]
    if len(path) == 2*m:
        if 0 in adj[last] and edge(last, 0) != forbidden:
            yield tuple(path)
        return
    for nxt in adj[last]:
        if nxt not in used and edge(last, nxt) != forbidden:
            path.append(nxt)
            used.add(nxt)
            yield from cycles(path, used)
            used.remove(nxt)
            path.pop()


count = 0
for witness in cycles([0, m], {0, m}):
    support = cycle_edges(witness)
    assert len(set(witness)) == 2*m and len(support) == 2*m
    assert support <= edges and required in support and forbidden not in support
    assert support == expected, ("counterexample", witness)
    count += 1
    labels = [f"T{v}" if v < m else f"B{v-m}" for v in witness]
    print("cycle:", " - ".join(labels + labels[:1]))
assert count == 1, count
print(f"r=2: joint Hamilton cycle edge-sets = {count}")
print("PARENT_JOINT_UNIQUENESS_R2_VERIFIED")
