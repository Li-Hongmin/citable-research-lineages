#!/usr/bin/env python3
"""Exact, solver-free verification of one Ellingham--Horton 54 fibre.

The target is the rooted fixed fibre

    root 52, ports (32, 50, 53), singleton port 53.

The only nontrivial negative assertion is that this fibre has no forest
whose Y-degrees are all at most two.  Such a forest would be two spanning
paths, one from 32 to 50 and one from 53 to a Y-vertex y.  After adding the
artificial edge 50--53 it becomes a Hamilton path

    32 ... 50 -- 53 ... y.                         (*)

We prove that (*) is impossible without MILP, SAT, or floating point.  The
augmented graph has an exact four-block decomposition of orders 16, 18, 18,
and 1 with seven crossing edges.  For every candidate y and every crossing
edge subset, this program exhaustively enumerates all spanning linear-forest
signatures inside the three nontrivial blocks.  A signature records which
boundary tokens are paired by a local path.  The finite signature tables are
then glued exactly.  Every connected gluing crosses the artificial edge in
the reverse order 53--50; none has the order required in (*).

The local enumerator branches on every unresolved internal edge and only
uses consequences of exact target degrees and the prohibition on cycles.
Thus its empty target count is an exhaustive combinatorial certificate, not
a solver status.
"""

from __future__ import annotations

from collections import defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
import platform
from typing import Iterable

import networkx as nx


HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "eh54_exact_cut_signature_certificate.json"

GRAPH6 = (
    "uhCGGCP?GGo@?PG?_?KO@?????G?????C??@??AG??????P??@?????_???G???P??"
    "AA??OCC?C?CC???AAO???__???CC???????????@????????????_?????G?????P???"
    "?????????AG?????G???????C??????@??????AG?????OOG?????__??G???__??????"
    "OQ??????CC???????__?????G??G?????O??W"
)

ROOT = 52
PORTS = (32, 50, 53)
PAIRED_PORTS = frozenset((32, 50))
SINGLETON_PORT = 53
START = 32
BRIDGE = "cd_bridge"

BLOCKS: dict[str, frozenset[int]] = {
    "A": frozenset(range(0, 16)),
    "B": frozenset(range(16, 34)),
    "C": frozenset(range(34, 52)),
    "D": frozenset((53,)),
}

# These are all crossing edges after deleting 52 and adding 50--53.
CUT_EDGES: dict[str, tuple[int, int]] = {
    "ac_1_47": (1, 47),
    "ab_6_30": (6, 30),
    "ab_9_29": (9, 29),
    "ac_14_48": (14, 48),
    "bd_33_53": (33, 53),
    BRIDGE: (50, 53),
    "cd_51_53": (51, 53),
}

FOUR_FREE_CUT_EDGES = ("ac_1_47", "ab_6_30", "ab_9_29", "ac_14_48")
D_ALTERNATIVES = ("bd_33_53", "cd_51_53")


def edge(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


# Two explicit fixed-fibre forests.  Their half--half average is the exact
# fractional degree-box certificate checked below.
FOREST_1 = (
    (0, 1), (0, 11), (1, 2), (2, 13), (3, 4), (3, 8), (4, 15),
    (5, 6), (5, 10), (6, 30), (7, 8), (7, 12), (9, 10), (9, 29),
    (10, 11), (13, 14), (14, 15), (14, 48), (16, 21), (17, 24),
    (17, 29), (18, 23), (18, 30), (19, 20), (19, 31), (21, 33),
    (22, 23), (22, 27), (22, 28), (24, 25), (25, 26), (26, 32),
    (27, 33), (28, 31), (34, 39), (34, 46), (35, 42), (35, 47),
    (36, 41), (36, 48), (37, 38), (37, 49), (39, 51), (40, 45),
    (41, 47), (42, 43), (43, 44), (44, 45), (44, 50), (46, 49),
    (51, 53),
)

FOREST_2 = (
    (0, 11), (0, 15), (1, 2), (1, 47), (2, 13), (3, 4), (3, 8),
    (4, 15), (5, 6), (5, 10), (6, 7), (7, 12), (8, 9), (9, 29),
    (11, 12), (12, 13), (14, 48), (16, 17), (16, 21), (16, 28),
    (17, 24), (18, 23), (18, 30), (19, 20), (19, 31), (20, 32),
    (21, 33), (22, 28), (23, 29), (24, 30), (25, 26), (25, 31),
    (26, 27), (27, 33), (34, 35), (34, 39), (35, 42), (36, 37),
    (36, 41), (37, 38), (38, 39), (38, 50), (40, 45), (40, 46),
    (41, 47), (42, 48), (43, 44), (43, 49), (45, 51), (46, 49),
    (51, 53),
)


Signature = tuple[tuple[str, str], ...]


def graph_and_colours() -> tuple[nx.Graph, tuple[int, ...], tuple[int, ...]]:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert set(graph) == set(range(54))
    assert graph.number_of_edges() == 81
    assert not nx.number_of_selfloops(graph)
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert tuple(sorted(graph[ROOT])) == PORTS
    colour = nx.bipartite.color(graph)
    x_side = tuple(sorted(v for v in graph if colour[v] != colour[ROOT]))
    y_side = tuple(sorted(v for v in graph if colour[v] == colour[ROOT]))
    assert len(x_side) == len(y_side) == 27
    assert set(PORTS) <= set(x_side)
    return graph, x_side, y_side


def exact_bipartite_matching(
    graph: nx.Graph,
    x_vertices: Iterable[int],
    allowed_y: frozenset[int],
) -> tuple[tuple[int, int], ...] | None:
    """Deterministic augmenting-path matching; no external solver is used."""

    match_y: dict[int, int] = {}

    def augment(x: int, seen_y: set[int]) -> bool:
        for y in sorted(set(graph[x]) & allowed_y):
            if y in seen_y:
                continue
            seen_y.add(y)
            if y not in match_y or augment(match_y[y], seen_y):
                match_y[y] = x
                return True
        return False

    x_order = tuple(sorted(x_vertices))
    for x in x_order:
        if not augment(x, set()):
            return None
    assert len(match_y) == len(x_order)
    return tuple(sorted(edge(x, y) for y, x in match_y.items()))


def verify_brace(graph: nx.Graph, x_side: tuple[int, ...], y_side: tuple[int, ...]) -> dict[str, object]:
    """Verify every independent edge pair extends to a perfect matching.

    For balanced bipartite graphs this is 2-extendability, equivalently the
    strict Hall inequalities |N(A)| >= |A|+2 for
    nonempty A subset X with |A| <= |X|-2.  Cubicity makes equality occur
    on every singleton, so the strict-Hall minimum is exactly two.
    """

    x_set = frozenset(x_side)
    y_set = frozenset(y_side)
    graph_edges = tuple(sorted(edge(u, v) for u, v in graph.edges()))
    digest = sha256()
    pair_count = 0

    for first, second in combinations(graph_edges, 2):
        if set(first) & set(second):
            continue
        forced = (first, second)
        removed_x = frozenset(v for e in forced for v in e if v in x_set)
        removed_y = frozenset(v for e in forced for v in e if v in y_set)
        assert len(removed_x) == len(removed_y) == 2
        remaining_x = tuple(x for x in x_side if x not in removed_x)
        remaining_y = frozenset(y for y in y_side if y not in removed_y)
        completion = exact_bipartite_matching(graph, remaining_x, remaining_y)
        assert completion is not None and len(completion) == 25
        perfect = tuple(sorted(forced + completion))
        support = nx.Graph()
        support.add_nodes_from(graph)
        support.add_edges_from(perfect)
        assert all(support.degree(v) == 1 for v in graph)
        digest.update(
            (json.dumps([forced, completion], separators=(",", ":")) + "\n").encode()
        )
        pair_count += 1

    # C(81,2) minus the three incident edge-pairs at each of 54 vertices.
    assert pair_count == 3078
    return {
        "independent_edge_pairs_checked": pair_count,
        "canonical_completion_digest_sha256": digest.hexdigest(),
        "two_extendable": True,
        "strict_hall_minimum": 2,
        "brace": True,
    }


def verify_fixed_fibre_forest(
    graph: nx.Graph,
    x_side: tuple[int, ...],
    y_order: tuple[int, ...],
    forest_edges: tuple[tuple[int, int], ...],
) -> tuple[tuple[int, ...], tuple[int, ...]]:
    chosen = tuple(sorted(edge(*item) for item in forest_edges))
    assert len(chosen) == len(set(chosen)) == 51
    assert all(ROOT not in item and graph.has_edge(*item) for item in chosen)

    support = nx.Graph()
    support.add_nodes_from(set(graph) - {ROOT})
    support.add_edges_from(chosen)
    assert nx.is_forest(support)
    components = tuple(frozenset(c) for c in nx.connected_components(support))
    assert len(components) == 2
    blocks = {frozenset(c & set(PORTS)) for c in components}
    assert blocks == {PAIRED_PORTS, frozenset((SINGLETON_PORT,))}
    for x in x_side:
        assert support.degree(x) == (1 if x in PORTS else 2)

    degree_vector = tuple(support.degree(y) for y in y_order)
    assert sum(degree_vector) == 51
    return degree_vector, tuple(sorted(map(len, components)))


def verify_explicit_forests(
    graph: nx.Graph,
    x_side: tuple[int, ...],
    y_side: tuple[int, ...],
) -> dict[str, object]:
    y_order = tuple(y for y in y_side if y != ROOT)
    vector_1, sizes_1 = verify_fixed_fibre_forest(graph, x_side, y_order, FOREST_1)
    vector_2, sizes_2 = verify_fixed_fibre_forest(graph, x_side, y_order, FOREST_2)
    assert vector_1 != vector_2

    expected = tuple(
        (Fraction(a) + Fraction(b)) / 2 for a, b in zip(vector_1, vector_2)
    )
    assert all(value <= 2 for value in expected)
    slacks = tuple(Fraction(2) - value for value in expected)
    assert all(value >= 0 for value in slacks)
    return {
        "y_order": list(y_order),
        "fixed_fibre_nonempty": True,
        "forest_1_component_sizes": list(sizes_1),
        "forest_1_degree_vector": list(vector_1),
        "forest_2_component_sizes": list(sizes_2),
        "forest_2_degree_vector": list(vector_2),
        "fractional_weights": ["1/2", "1/2"],
        "expected_degree_vector": [str(value) for value in expected],
        "coordinate_slacks": [str(value) for value in slacks],
        "fractional_degree_box": True,
    }


def augmented_graph(graph: nx.Graph) -> nx.Graph:
    augmented = graph.copy()
    augmented.remove_node(ROOT)
    assert not augmented.has_edge(*CUT_EDGES[BRIDGE])
    augmented.add_edge(*CUT_EDGES[BRIDGE])
    assert set().union(*BLOCKS.values()) == set(augmented)

    actual_crossing = set()
    block_of = {v: name for name, vertices in BLOCKS.items() for v in vertices}
    for u, v in augmented.edges():
        if block_of[u] != block_of[v]:
            actual_crossing.add(edge(u, v))
    assert actual_crossing == {edge(*item) for item in CUT_EDGES.values()}
    return augmented


def selected_edges_at_block(block: str, selected: frozenset[str]) -> tuple[str, ...]:
    vertices = BLOCKS[block]
    return tuple(
        sorted(
            label
            for label in selected
            if (CUT_EDGES[label][0] in vertices) ^ (CUT_EDGES[label][1] in vertices)
        )
    )


def local_signatures(
    graph: nx.Graph,
    block: str,
    selected_labels: tuple[str, ...],
    endpoint: int | None,
) -> tuple[dict[Signature, tuple[tuple[int, int], ...]], dict[str, int]]:
    """Exhaust all local spanning linear forests with the exact degrees.

    An edge state is -1 (unresolved), 0 (absent), or 1 (present).  At every
    node, exact degree constraints force all remaining incident edges absent
    or present whenever possible.  Otherwise one unresolved edge is branched
    both ways.  Selected cycles are rejected by union-find.  Hence every
    internal edge subset occurs in exactly one covered branch before safe
    pruning.
    """

    vertices = tuple(sorted(BLOCKS[block]))
    vertex_set = frozenset(vertices)
    internal_edges = tuple(
        sorted(edge(u, v) for u, v in graph.edges() if u in vertex_set and v in vertex_set)
    )
    incident: dict[int, list[int]] = {v: [] for v in vertices}
    for index, (u, v) in enumerate(internal_edges):
        incident[u].append(index)
        incident[v].append(index)

    external_count = {v: 0 for v in vertices}
    tokens: dict[int, list[str]] = {v: [] for v in vertices}
    for label in selected_labels:
        u, v = CUT_EDGES[label]
        boundary_vertex = u if u in vertex_set else v
        assert boundary_vertex in vertex_set
        external_count[boundary_vertex] += 1
        tokens[boundary_vertex].append(label)
    if START in vertex_set:
        tokens[START].append("s")
    if endpoint is not None:
        assert endpoint in vertex_set
        tokens[endpoint].append("y")

    target = {
        v: (1 if v == START or v == endpoint else 2) - external_count[v]
        for v in vertices
    }
    if any(target[v] < 0 or target[v] > len(incident[v]) for v in vertices):
        return {}, {"search_nodes": 0, "normalized_states": 0, "complete_leaves": 0}

    results: dict[Signature, tuple[tuple[int, int], ...]] = {}
    seen: set[tuple[int, ...]] = set()
    stats = {"search_nodes": 0, "normalized_states": 0, "complete_leaves": 0}

    def has_cycle(state: list[int]) -> bool:
        parent = {v: v for v in vertices}

        def find(v: int) -> int:
            while parent[v] != v:
                parent[v] = parent[parent[v]]
                v = parent[v]
            return v

        for index, status in enumerate(state):
            if status != 1:
                continue
            u, v = internal_edges[index]
            root_u, root_v = find(u), find(v)
            if root_u == root_v:
                return True
            parent[root_u] = root_v
        return False

    def normalize(initial: tuple[int, ...]) -> tuple[int, ...] | None:
        state = list(initial)
        while True:
            changed = False
            for v in vertices:
                chosen_degree = sum(state[index] == 1 for index in incident[v])
                unresolved = [index for index in incident[v] if state[index] == -1]
                need = target[v] - chosen_degree
                if need < 0 or need > len(unresolved):
                    return None
                if need == 0:
                    for index in unresolved:
                        state[index] = 0
                        changed = True
                elif need == len(unresolved):
                    for index in unresolved:
                        state[index] = 1
                        changed = True
            if has_cycle(state):
                return None
            if not changed:
                return tuple(state)

    def visit(initial: tuple[int, ...]) -> None:
        stats["search_nodes"] += 1
        state = normalize(initial)
        if state is None or state in seen:
            return
        seen.add(state)
        stats["normalized_states"] += 1

        if -1 not in state:
            stats["complete_leaves"] += 1
            support = nx.Graph()
            support.add_nodes_from(vertices)
            support.add_edges_from(
                internal_edges[index] for index, status in enumerate(state) if status == 1
            )
            pairs: list[tuple[str, str]] = []
            for component in nx.connected_components(support):
                component_tokens = sorted(
                    token for v in component for token in tokens[v]
                )
                if len(component_tokens) != 2:
                    return
                pairs.append((component_tokens[0], component_tokens[1]))
            signature = tuple(sorted(pairs))
            witness = tuple(
                internal_edges[index] for index, status in enumerate(state) if status == 1
            )
            results.setdefault(signature, witness)
            return

        choices = []
        for v in vertices:
            unresolved = [index for index in incident[v] if state[index] == -1]
            if not unresolved:
                continue
            chosen_degree = sum(state[index] == 1 for index in incident[v])
            need = target[v] - chosen_degree
            if 0 < need < len(unresolved):
                choices.append((len(unresolved), v, unresolved[0]))
        assert choices
        branch_index = min(choices)[2]
        for status in (0, 1):
            child = list(state)
            child[branch_index] = status
            visit(tuple(child))

    visit(tuple(-1 for _ in internal_edges))
    return results, stats


def token_path(
    tagged_pairs: tuple[tuple[str, str, str], ...],
) -> tuple[tuple[str, ...], tuple[str, ...]] | None:
    """Return the s-to-y token path and intervening block tags if connected."""

    adjacency: dict[str, list[tuple[int, str, str]]] = defaultdict(list)
    for index, (left, right, tag) in enumerate(tagged_pairs):
        adjacency[left].append((index, right, tag))
        adjacency[right].append((index, left, tag))
    assert len(adjacency["s"]) == len(adjacency["y"]) == 1
    assert all(len(items) in (1, 2) for items in adjacency.values())

    nodes = ["s"]
    tags: list[str] = []
    previous_edge = -1
    current = "s"
    while current != "y":
        options = [item for item in adjacency[current] if item[0] != previous_edge]
        assert len(options) == 1
        next_edge, nxt, tag = options[0]
        previous_edge = next_edge
        current = nxt
        nodes.append(current)
        tags.append(tag)
        if len(nodes) > len(adjacency) + 1:
            return None
    if len(nodes) != len(adjacency):
        return None
    return tuple(nodes), tuple(tags)


def trace_vertex_path(support: nx.Graph, endpoint: int) -> tuple[int, ...]:
    assert nx.is_tree(support)
    assert support.number_of_edges() == support.number_of_nodes() - 1 == 52
    assert support.degree(START) == support.degree(endpoint) == 1
    assert all(
        support.degree(v) == (1 if v in (START, endpoint) else 2)
        for v in support
    )
    order = tuple(nx.shortest_path(support, START, endpoint))
    assert len(order) == 53
    return order


def verify_cut_signature_exhaustion(
    graph: nx.Graph,
    y_side: tuple[int, ...],
) -> dict[str, object]:
    augmented = augmented_graph(graph)
    endpoints = tuple(y for y in y_side if y != ROOT)
    assert len(endpoints) == 26 and SINGLETON_PORT not in endpoints

    cache: dict[
        tuple[str, tuple[str, ...], int | None],
        tuple[dict[Signature, tuple[tuple[int, int], ...]], dict[str, int]],
    ] = {}

    def get_local(
        block: str, selected: frozenset[str], endpoint: int
    ) -> dict[Signature, tuple[tuple[int, int], ...]]:
        local_selected = selected_edges_at_block(block, selected)
        local_endpoint = endpoint if endpoint in BLOCKS[block] else None
        key = (block, local_selected, local_endpoint)
        if key not in cache:
            cache[key] = local_signatures(augmented, block, local_selected, local_endpoint)
        return cache[key][0]

    endpoint_rows = []
    global_digest = sha256()
    first_reverse_path: tuple[int, ...] | None = None
    totals = {
        "cut_assignments": 0,
        "locally_compatible_signature_combinations": 0,
        "disconnected_signature_combinations": 0,
        "connected_reverse_53_to_50": 0,
        "connected_target_50_to_53": 0,
    }

    for endpoint in endpoints:
        row = {
            "endpoint": endpoint,
            "cut_assignments": 0,
            "locally_compatible_signature_combinations": 0,
            "disconnected_signature_combinations": 0,
            "connected_reverse_53_to_50": 0,
            "connected_target_50_to_53": 0,
        }
        for d_alternative in D_ALTERNATIVES:
            for mask in range(1 << len(FOUR_FREE_CUT_EDGES)):
                selected = frozenset(
                    {BRIDGE, d_alternative}
                    | {
                        label
                        for index, label in enumerate(FOUR_FREE_CUT_EDGES)
                        if mask & (1 << index)
                    }
                )
                row["cut_assignments"] += 1
                totals["cut_assignments"] += 1
                local = {
                    block: get_local(block, selected, endpoint)
                    for block in ("A", "B", "C")
                }
                if any(not table for table in local.values()):
                    continue
                d_signature: Signature = ((BRIDGE, d_alternative),)

                for signature_a, signature_b, signature_c in product(
                    sorted(local["A"]), sorted(local["B"]), sorted(local["C"])
                ):
                    row["locally_compatible_signature_combinations"] += 1
                    totals["locally_compatible_signature_combinations"] += 1
                    signatures = {
                        "A": signature_a,
                        "B": signature_b,
                        "C": signature_c,
                        "D": d_signature,
                    }
                    tagged_pairs = tuple(
                        (left, right, block)
                        for block in ("A", "B", "C", "D")
                        for left, right in signatures[block]
                    )
                    path = token_path(tagged_pairs)
                    record = {
                        "endpoint": endpoint,
                        "selected": sorted(selected),
                        "signatures": signatures,
                    }
                    if path is None:
                        classification = "disconnected"
                        row["disconnected_signature_combinations"] += 1
                        totals["disconnected_signature_combinations"] += 1
                    else:
                        token_nodes, block_tags = path
                        bridge_index = token_nodes.index(BRIDGE)
                        before = block_tags[bridge_index - 1]
                        after = block_tags[bridge_index]
                        assert {before, after} == {"C", "D"}
                        desired = before == "C" and after == "D"

                        chosen = set(CUT_EDGES[label] for label in selected)
                        for block, signature in (
                            ("A", signature_a), ("B", signature_b), ("C", signature_c)
                        ):
                            chosen.update(local[block][signature])
                        support = nx.Graph()
                        support.add_nodes_from(set(graph) - {ROOT})
                        support.add_edges_from(chosen)
                        vertex_order = trace_vertex_path(support, endpoint)
                        position_50 = vertex_order.index(50)
                        position_53 = vertex_order.index(53)
                        assert abs(position_50 - position_53) == 1
                        assert desired == (position_50 < position_53)

                        if desired:
                            classification = "target_50_to_53"
                            row["connected_target_50_to_53"] += 1
                            totals["connected_target_50_to_53"] += 1
                        else:
                            classification = "reverse_53_to_50"
                            row["connected_reverse_53_to_50"] += 1
                            totals["connected_reverse_53_to_50"] += 1
                            if first_reverse_path is None:
                                first_reverse_path = vertex_order
                    record["classification"] = classification
                    global_digest.update(
                        (json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n").encode()
                    )
        assert row["cut_assignments"] == 32
        endpoint_rows.append(row)

    assert totals == {
        "cut_assignments": 832,
        "locally_compatible_signature_combinations": 200,
        "disconnected_signature_combinations": 153,
        "connected_reverse_53_to_50": 47,
        "connected_target_50_to_53": 0,
    }
    assert first_reverse_path is not None

    local_digest = sha256()
    total_search_nodes = 0
    total_normalized_states = 0
    total_complete_leaves = 0
    total_distinct_signatures = 0
    for key in sorted(cache, key=lambda item: (item[0], item[1], -1 if item[2] is None else item[2])):
        table, stats = cache[key]
        block, selected_labels, endpoint = key
        serializable = {
            "block": block,
            "selected_labels": selected_labels,
            "endpoint": endpoint,
            "signatures": [
                {"pairing": signature, "witness_edges": table[signature]}
                for signature in sorted(table)
            ],
            "stats": stats,
        }
        local_digest.update(
            (json.dumps(serializable, sort_keys=True, separators=(",", ":")) + "\n").encode()
        )
        total_search_nodes += stats["search_nodes"]
        total_normalized_states += stats["normalized_states"]
        total_complete_leaves += stats["complete_leaves"]
        total_distinct_signatures += len(table)

    return {
        "reduction": (
            "capacity-two fixed-fibre forest iff a Hamilton path in F-52+50-53 "
            "has vertex order 32 ... 50,53 ... y for some y in Y-{52}"
        ),
        "blocks": {name: sorted(vertices) for name, vertices in BLOCKS.items()},
        "cut_edges": {label: list(item) for label, item in CUT_EDGES.items()},
        "candidate_endpoints": list(endpoints),
        "local_scenarios": len(cache),
        "local_search_nodes": total_search_nodes,
        "local_normalized_states": total_normalized_states,
        "local_complete_leaves": total_complete_leaves,
        "local_distinct_signatures": total_distinct_signatures,
        "local_signature_table_digest_sha256": local_digest.hexdigest(),
        "global_table_digest_sha256": global_digest.hexdigest(),
        "endpoint_table": endpoint_rows,
        "totals": totals,
        "first_reverse_vertex_path": list(first_reverse_path),
        "capacity_two_fixed_fibre": False,
    }


def main() -> None:
    graph, x_side, y_side = graph_and_colours()
    result = {
        "graph": {
            "name": "EllinghamHorton54Graph",
            "graph6": GRAPH6,
            "order": graph.number_of_nodes(),
            "size": graph.number_of_edges(),
            "simple": True,
            "cubic": True,
            "bipartite": True,
            "connected": True,
            "x_side": list(x_side),
            "y_side": list(y_side),
            "root": ROOT,
            "ports": list(PORTS),
            "singleton_port": SINGLETON_PORT,
            "paired_ports": sorted(PAIRED_PORTS),
        },
        "brace": verify_brace(graph, x_side, y_side),
        "explicit_forests": verify_explicit_forests(graph, x_side, y_side),
        "cut_signature_exhaustion": verify_cut_signature_exhaustion(graph, y_side),
        "runtime": {
            "python": platform.python_version(),
            "networkx": nx.__version__,
            "arithmetic": "integers, booleans, graph traversal, and Fraction only",
            "external_solver": None,
        },
    }
    OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print("brace", result["brace"])
    print("fixed_fibre_nonempty", result["explicit_forests"]["fixed_fibre_nonempty"])
    print("fractional_degree_box", result["explicit_forests"]["fractional_degree_box"])
    print("cut_signature_totals", result["cut_signature_exhaustion"]["totals"])
    print("output", OUTPUT)
    print("EH54_EXACT_CUT_SIGNATURE_CERTIFICATE_VERIFIED")


if __name__ == "__main__":
    main()
