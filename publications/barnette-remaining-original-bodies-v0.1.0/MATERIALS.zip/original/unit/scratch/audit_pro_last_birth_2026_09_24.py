#!/usr/bin/env python3
"""Independent, stdlib-only audit of the specified 20-vertex collision.

Run with Python (without -O); prints the full finite certificate as JSON.
Imports no project/proposer verifier and enumerates no row supports.
"""

from collections import Counter
from itertools import combinations
import json


def edge(u, v):
    return tuple(sorted((u, v)))


def darts(face):
    return tuple(zip(face, face[1:] + face[:1]))


def cyclic(word):
    return min(word[i:] + word[:i] for i in range(len(word)))


def components(adj):
    unseen = set(adj)
    result = []
    while unseen:
        comp = {unseen.pop()}
        todo = list(comp)
        while todo:
            for v in adj[todo.pop()] & unseen:
                unseen.remove(v)
                comp.add(v)
                todo.append(v)
        result.append(comp)
    return result


def adjacency(vertices, edges):
    adj = {v: set() for v in vertices}
    for u, v in edges:
        assert u != v
        adj[u].add(v)
        adj[v].add(u)
    return adj


def embedding(edges, faces):
    """Check directed face coverage, vertex links, Euler and rotation orbits."""
    adj = adjacency({v for e in edges for v in e}, edges)
    directed = {(u, v) for a, b in edges for u, v in ((a, b), (b, a))}
    assert Counter(d for f in faces for d in darts(f)) == Counter(directed)
    links = {v: {} for v in adj}
    for face in faces:
        assert len(face) >= 3 and len(face) == len(set(face))
        for i, v in enumerate(face):
            links[v][face[i - 1]] = face[(i + 1) % len(face)]
    rotations = {}
    for v in adj:
        rho = [min(adj[v])]
        while links[v][rho[-1]] != rho[0]:
            rho.append(links[v][rho[-1]])
            assert len(rho) <= len(adj[v])
        assert set(rho) == adj[v]
        rotations[v] = tuple(rho)
    unseen = set(directed)
    traversed = []
    while unseen:
        start = min(unseen)
        u, v = start
        walk = []
        while True:
            unseen.remove((u, v))
            walk.append(u)
            rho = rotations[v]
            u, v = v, rho[(rho.index(u) + 1) % len(rho)]
            if (u, v) == start:
                break
        traversed.append(cyclic(tuple(walk)))
    assert sorted(traversed) == sorted(cyclic(f) for f in faces)
    assert len(components(adj)) == 1
    assert len(adj) - len(edges) + len(faces) == 2
    return adj, rotations


def graph_check(edges, faces):
    adj, rotations = embedding(edges, faces)
    assert all(len(ns) == 3 for ns in adj.values())
    colors = {min(adj): 0}
    todo = list(colors)
    while todo:
        u = todo.pop()
        for v in adj[u]:
            if v not in colors:
                colors[v] = 1 - colors[u]
                todo.append(v)
            assert colors[v] != colors[u]
    cuts_checked = 0
    for size in range(3):
        for cut in combinations(sorted(adj), size):
            remaining = set(adj) - set(cut)
            assert len(components({v: adj[v] & remaining for v in remaining})) == 1
            cuts_checked += 1
    return {
        "order": len(adj), "edges": sorted(edges), "rotations": rotations,
        "faces": sorted(cyclic(f) for f in faces), "colors": colors,
        "vertex_cuts_checked": cuts_checked, "euler_characteristic": 2,
    }


def site_record(faces, site, colors):
    u, v, x, y = site
    assert len(set(site)) == 4 and colors[u] == colors[x]
    found = []
    for i, face in enumerate(faces):
        for mirror in (False, True):
            oriented = face[::-1] if mirror else face
            if u not in oriented:
                continue
            k = oriented.index(u)
            f = oriented[k:] + oriented[:k]
            if f[1] != v or x not in f:
                continue
            j = f.index(x)
            if j < 2 or j + 1 >= len(f) or f[j + 1] != y:
                continue
            arcs = (f[1:j + 1], f[j + 1:] + (u,))
            lengths = tuple(len(a) - 1 for a in arcs)
            assert all(n % 2 == 1 for n in lengths)
            found.append((i, mirror, {"site": site, "face": f,
                                      "arcs": arcs, "arc_lengths": lengths}))
    assert len(found) == 1, (site, found)
    return found[0]


def expand(edges, faces, site, fresh, colors):
    """Split the actual facial disk; preserve its exterior rotation orders."""
    index, mirror, record = site_record(faces, site, colors)
    work = [f[::-1] if mirror else f for f in faces]
    f = record["face"]
    u, v, x, y = site
    a, b, c, d = fresh
    assert len(set(fresh)) == 4 and not set(fresh) & set(colors)
    removed = {edge(u, v), edge(x, y)}
    born = {edge(*p) for p in ((u, a), (a, b), (b, v), (x, c),
                               (c, d), (d, y), (a, d), (b, c))}
    assert len(born) == 8 and not born & edges and removed <= edges
    child = (edges - removed) | born
    paths = {(u, v): (u, a, b), (v, u): (v, b, a),
             (x, y): (x, c, d), (y, x): (y, d, c)}
    next_faces = [tuple(z for p in darts(g) for z in paths.get(p, (p[0],)))
                  for i, g in enumerate(work) if i != index]
    j = f.index(x)
    next_faces += [(a, b, c, d), (b,) + f[1:j + 1] + (c,),
                   (d,) + f[j + 1:] + (u, a)]
    if mirror:
        next_faces = [g[::-1] for g in next_faces]
    # Verify the literal inverse on both graph edges and cyclic neighbor orders.
    assert {e for e in child if not set(e) & set(fresh)} | removed == edges
    _, old_rho = embedding(edges, faces)
    _, new_rho = embedding(child, next_faces)
    undo = {u: {a: v}, v: {b: u}, x: {c: y}, y: {d: x}}
    for z in old_rho:
        recovered = tuple(undo.get(z, {}).get(t, t) for t in new_rho[z])
        assert cyclic(recovered) == cyclic(old_rho[z])
    return child, next_faces, born, removed, dict(record, fresh=fresh, inverse_ok=True)


def ownership(edges, origins, site):
    cap = {edge(*site[:2]), edge(*site[2:])}
    owners = {name: sorted((group & edges) - cap) for name, group in origins.items()}
    owners["cap"] = sorted(cap)
    assert Counter(e for group in owners.values() for e in group) == Counter(edges)
    return {"edges_by_owner": owners, "counts": {k: len(v) for k, v in owners.items()}}


def audit():
    cube = {edge(*p) for p in ((0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6),
                              (6, 7), (7, 4), (0, 4), (1, 5), (2, 6), (3, 7))}
    faces = [(0, 1, 2, 3), (4, 7, 6, 5), (1, 0, 4, 5),
             (2, 1, 5, 6), (3, 2, 6, 7), (0, 3, 7, 4)]
    sites = [(0, 1, 2, 3), (0, 8, 9, 1), (0, 12, 13, 8), (0, 16, 11, 3)]
    claimed_faces = [(0, 1, 2, 3), (0, 8, 9, 1, 5, 4),
                     (0, 12, 13, 8, 11, 3), (0, 16, 19, 8, 11, 3)]
    graphs = [graph_check(cube, faces)]
    states = [(cube, faces)]
    origins = {"kernel": cube}
    operations = []
    deleted_at = {}
    edges = cube
    for layer, site in enumerate(sites):
        fresh = tuple(range(8 + 4 * layer, 12 + 4 * layer))
        edges, faces, born, removed, record = expand(
            edges, faces, site, fresh, graphs[-1]["colors"])
        assert record["face"] == claimed_faces[layer]
        origins[f"B{layer}"] = born
        record.update(layer=layer, born=sorted(born), deleted=sorted(removed),
                      successor=sites[layer + 1] if layer < 3 else "q-dependent")
        operations.append(record)
        for e in removed:
            assert e not in deleted_at
            deleted_at[e] = layer
        states.append((edges, faces))
        graphs.append(graph_check(edges, faces))
    assert [g["order"] for g in graphs] == [8, 12, 16, 20, 24]
    # First two successor choices are UV; final two operations have o* form.
    for i in (0, 1):
        u, v, _, _ = sites[i]
        a, b, _, _ = operations[i]["fresh"]
        assert sites[i + 1] == (u, a, b, v)
    assert sites[3] == (sites[2][0], operations[2]["fresh"][0], 11, 3)
    assert edge(11, 3) in states[2][0] - set(operations[2]["deleted"])
    Z, z_faces = states[3]
    H, h_faces = states[4]
    u, v, x, y = sites[3]
    q_edges = [(15, 1), (5, 4)]
    targets = [(2, 6), (9, 10)]
    slots = ("U", "V", "X", "Y", "Q0", "Q1", "E0", "E1", "F0", "F1",
             "A", "B", "C", "D")
    keys, cases = [], []
    for q in q_edges:
        assert edge(*q) in Z - {edge(u, v), edge(x, y)}
        _, _, terminal = site_record(h_faces, (u, 20, *q), graphs[4]["colors"])
        assert terminal["face"] == (0, 20, 21, 16, 17, 12, 15, 1, 5, 4)
        vals = (*sites[3], *q, *targets[0], *targets[1], 20, 21, 22, 23)
        ids = {}
        cls = tuple(ids.setdefault(z, len(ids)) for z in vals)
        assert cls == tuple(range(14))
        color = tuple(graphs[4]["colors"][z] for z in vals)
        color = min(color, tuple(1 - c for c in color))
        exists = tuple(z in graphs[3]["colors"] for z in vals)
        roles = dict(zip(vals, slots))
        arc0, arc1 = terminal["arcs"]
        word = ("UA", tuple(roles[z] for z in arc0 if z in roles), "SEP",
                tuple(roles[z] for z in arc1[:-1] if z in roles), "SEP")
        controlled = {edge(u, v): "UV", edge(x, y): "XY", edge(*q): "q"}
        target_meta = []
        for t in targets:
            te = edge(*t)
            assert te in Z
            status = "kernel-live" if te in cube else "older-live"
            target_meta.append((te == edge(*q), controlled.get(te, "external-existing"),
                                "live", tuple(z in graphs[3]["colors"] for z in t), status))
        current_word = tuple(roles[z] for z in claimed_faces[3] if z in roles)
        key = {"equality": cls, "colors": color, "exists": exists,
               "targets": tuple(target_meta), "successor_face_word": word,
               "phase": "input", "site_word": slots[:4],
               "current_face_word": current_word, "controlled_edges": ("UV", "XY", "Q0Q1"),
               "b_last": int(edge(*q) in origins["B2"])}
        keys.append(key)
        cases.append({"q": q, "slots": vals, "key": key, "terminal": terminal,
                      "terminal_ownership": ownership(H, origins, terminal["site"])})
    assert keys[0] == keys[1]
    assert keys[0]["b_last"] == 0
    assert keys[0]["exists"] == (True,) * 10 + (False,) * 4
    assert keys[0]["colors"] == (0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0)
    assert keys[0]["successor_face_word"] == ("UA", ("A", "B", "V", "Q0"),
                                                "SEP", ("Q1",), "SEP")
    assert [c["terminal"]["arc_lengths"] for c in cases] == [(5, 3), (7, 1)]
    # Sigma_plus is the same literal output object before q is supplied.
    old_input_slots = (0, 12, 13, 8, 11, 3, 2, 6, 9, 10, 16, 17, 18, 19)
    old_output_boundary = (0, 16, 11, 3, 2, 6, 9, 10)
    assert old_output_boundary == tuple(old_input_slots[i] for i in (0, 10, 4, 5, 6, 7, 8, 9))
    cycles = [(4, 5, 6, 7), (8, 9, 14, 13, 12, 17, 18, 19)]
    witness = {edge(*p) for c in cycles for p in darts(c)}
    boundary = cases[0]["slots"][:10]
    assert witness <= Z - {edge(u, v), edge(x, y), edge(*q_edges[0])}
    adj = adjacency(graphs[3]["colors"], witness)
    d = tuple(len(adj[z]) for z in boundary)
    assert d == (0, 0, 0, 0, 0, 0, 0, 2, 2, 0)
    assert all(len(adj[z]) == 2 for z in set(adj) - set(boundary))
    comps = components(adj)
    partition = sorted(tuple(i for i, z in enumerate(boundary) if z in c)
                       for c in comps if c & set(boundary))
    closed = min(2, sum(not c & set(boundary) for c in comps))
    bits = tuple(int(edge(*t) in witness) for t in targets)
    assert partition == [(i,) for i in range(10)] and closed == 0 and bits == (0, 0)
    # Universal absence certificate: even the maximum feasible degree at 7 is 1.
    boundary2 = cases[1]["slots"][:10]
    zero_vertices = {z for z, degree in zip(boundary2, d) if degree == 0}
    cut2 = {edge(u, v), edge(x, y), edge(*q_edges[1])}
    adj_z = adjacency(graphs[3]["colors"], Z)
    possible = {z for z in adj_z[7] if z not in zero_vertices and edge(7, z) not in cut2}
    assert 7 not in boundary2 and adj_z[7] == {3, 4, 6}
    assert {3, 4} <= zero_vertices and possible == {6}
    ledger = []
    for owner, group in origins.items():
        for e in sorted(group):
            deletion = deleted_at.get(e)
            assert (e in H) == (deletion is None)
            ledger.append({"edge": e, "birth_owner": owner, "deleted_layer": deletion})
    assert sum(len(group) for group in origins.values()) == len(ledger) == 44
    return {
        "verdict": "VERIFIED_COLLISION_FOR_(Sigma_plus,nu,b_last)",
        "graphs": graphs, "operations": operations, "edge_ledger": ledger,
        "vertex_owners": {"kernel": list(range(8)), **{
            f"B{i}": list(range(8 + 4 * i, 12 + 4 * i)) for i in range(4)}},
        "Z_ownership": ownership(Z, {k: origins[k] for k in ("kernel", "B0", "B1", "B2")}, sites[3]),
        "old_output_input_slots": old_input_slots, "old_output_boundary": old_output_boundary,
        "cases": cases, "witness_edges": sorted(witness),
        "witness_row": {"boundary": slots[:10], "degrees": d, "partition": partition,
                        "closed_components_capped": closed, "target_bits": bits},
        "absence": {"internal_vertex": 7, "neighbors": sorted(adj_z[7]),
                    "blocked_neighbors": [3, 4], "possible_neighbors": sorted(possible),
                    "required_degree": 2, "maximum_degree": len(possible)},
    }


if __name__ == "__main__":
    print(json.dumps(audit(), ensure_ascii=False, indent=2))
