#!/usr/bin/env python3
"""Exact finite observation of unrooted cube CEN/UV word fibres.

This is exploratory support for R2, not a proof.  Isomorphism classes are
identified by pynauty's exact canonical certificate; NetworkX is used only
for structural checks and planar face-degree observations.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import product
import json
from pathlib import Path

import networkx as nx
import pynauty


CUBE_EDGES = {
    (0, 1), (0, 3), (0, 4), (1, 2), (1, 7), (2, 3),
    (2, 6), (3, 5), (4, 5), (4, 7), (5, 6), (6, 7),
}
ROOT_SITE = (0, 1, 2, 3)


def expand(graph: nx.Graph, site: tuple[int, int, int, int]):
    u, v, x, y = site
    assert graph.has_edge(u, v) and graph.has_edge(x, y)
    child = graph.copy()
    child.remove_edges_from(((u, v), (x, y)))
    a, b, c, d = range(len(child), len(child) + 4)
    child.add_edges_from(((u, a), (a, b), (b, v), (x, c), (c, d),
                          (d, y), (a, d), (b, c)))
    return child, (b, c, d, a), (u, a, b, v)


def graph_for_word(word: str) -> nx.Graph:
    graph = nx.Graph(CUBE_EDGES)
    site = ROOT_SITE
    for bit in word:
        graph, cen, uv = expand(graph, site)
        site = cen if bit == "0" else uv
    return graph


def certificate(graph: nx.Graph) -> bytes:
    adjacency = {v: sorted(graph.neighbors(v)) for v in graph.nodes}
    return pynauty.certificate(
        pynauty.Graph(number_of_vertices=len(graph), adjacency_dict=adjacency)
    )


def face_signature(graph: nx.Graph) -> tuple[int, ...]:
    planar, embedding = nx.check_planarity(graph)
    assert planar
    used = set()
    lengths = []
    for u, v in embedding.edges():
        if (u, v) not in used:
            face = embedding.traverse_face(u, v, used)
            lengths.append(len(face))
    return tuple(sorted(lengths))


def main(max_depth: int = 12) -> None:
    records = []
    for k in range(max_depth + 1):
        classes = defaultdict(list)
        signatures = defaultdict(set)
        for bits in product("01", repeat=k):
            word = "".join(bits)
            graph = graph_for_word(word)
            assert len(graph) == 8 + 4 * k
            assert graph.number_of_edges() == 3 * len(graph) // 2
            assert set(dict(graph.degree()).values()) == {3}
            assert nx.is_bipartite(graph)
            key = certificate(graph)
            classes[key].append(word)
            signatures[face_signature(graph)].add(key)
        fibres = Counter(map(len, classes.values()))
        face_classes = len(signatures)
        record = {
            "k": k,
            "n": 8 + 4 * k,
            "words": 2 ** k,
            "isomorphism_classes": len(classes),
            "words_per_class_ratio": (2 ** k) / len(classes),
            "fibre_size_distribution": dict(sorted(fibres.items())),
            "distinct_face_degree_sequences": face_classes,
            "max_classes_sharing_face_sequence": max(map(len, signatures.values())),
        }
        records.append(record)
        print(json.dumps(record, sort_keys=True))
    output = Path(__file__).with_suffix(".json")
    output.write_text(json.dumps(records, indent=2, sort_keys=True) + "\n")
    print(f"wrote {output}")


if __name__ == "__main__":
    main()
