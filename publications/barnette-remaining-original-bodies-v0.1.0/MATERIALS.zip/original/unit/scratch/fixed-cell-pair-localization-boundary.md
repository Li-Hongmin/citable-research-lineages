# Parent kill cover does not localize the child rooted bond to a fixed cell-pair subset

This draft uses only Notes 108--113.  It asks a conditional localization
question: even if one grants the full three-new-cell rooted-bond conclusion,
can parent kill cover force its witness into a prescribed smaller family of
cell pairs?

Put

\[
 \mathcal C=\{C_{00},C_{10},C_{01}\},\qquad
 \mathcal N=\{R_{00},X_{uy},X_{vx}\}.
\]

Kill cover and the canonical induced-graph identity exclude every
\(\mathcal C\)--\(\mathcal C\) child bond.  The full conclusion is therefore

\[
 \exists uv\in E(\mathfrak B_{g_1}(T^+)):
 \{u,v\}\cap\mathcal A_{\mathcal N}\ne\varnothing .
\tag{1}
\]

## 1. The bare-incidence layer

If one retains only parent/child target states, gate bits, the canonical
bijection and induced graph, formal labelled region trees and balanced shore
ranks, then any unordered cell pair having an endpoint in \(\mathcal N\)
can be isolated as the only child bond.

Use the parent graph

\[
 \alpha\in L_{11}^{0},\qquad \beta\in L_{00}^{1},
 \qquad E=\{\alpha\beta\}.
\]

It is nonempty and kill-covered.  Its child has the canonical image
\(c\in C_{00}^{1}\).  For a canonical--new model add
\(n\in N^0\) and only the edge \(cn\).  For a new--new model add
\(n_1\in N_1^0,n_2\in N_2^1\), only the edge \(n_1n_2\), and leave
\(c\) isolated.  Other canonical cells are obtained by changing the
non-\(11\) parent state.  Assign every endpoint the formal tree
\(L_r-K-L_s\), and every bond the balanced rank profile
\((1,1,1,1)\) with separated root fragments.  Mark new endpoints
nondirect.  This is minimum at this incidence level.

This construction does **not** retain the attachment quotient.  In
particular it wrongly permits opposite-gate \(C_{00}\)--\(R_{00}\).
Thus it proves only that the weaker state/rank incidence does not localize
the bond; it is not a model of the full Note 112 component structure.

## 2. The attachment correction

For an opposite-gate \(C_{00}\)--\(R_{00}\) pair the local XOR is
\(ABPQ\).  The complementary local shore consists only of \(C\), while
both possible old attachments \(P,Q\) lie on the other shore.  The
external gate forces the complementary old shore to be nonempty.  Hence
that shore is disconnected, and this pair is impossible.

Let

\[
 \mathscr P^*=\bigl\{\{K,L\}:K,L\in\mathcal C\cup\mathcal N,
 \ \{K,L\}\cap\mathcal N\ne\varnothing\bigr\}
 \setminus\bigl\{\{C_{00},R_{00}\}\bigr\}.
\tag{2}
\]

Every member of \(\mathscr P^*\) has a strict two-shore attachment model.
Contract \(H[D]\) and \(H[\bar D]\) to one old component node each and
join their realizations by the external gate edge.  Put \(P,Q\) on the
shores prescribed by the local XOR row.  Add an auxiliary vertex from
\(J_A\) or \(J_B\) to a component exactly when its local core requires
that attachment.  For \(X_{uy}\)--\(X_{vx}\), put one auxiliary vertex
from each interval in the same \(D\)-component, joining the two local cores
\(A,B\), and put \(P,Q\) in the complementary component, attaching the
\(C\)-core.  For same-cell pairs both old shores are single components.
For \(C_{10}/C_{01}\)--\(R_{00}\), the \(D\)-component meets
\(J_A\cup J_B\) and the complementary shore is connected.  The
canonical--cross and \(R\)--cross rows use one named interval on each
shore.  Replacing each component node by a short path through its marked
vertices realizes these quotients as connected old graphs.

These constructions cover the zero-, one-, and two-local-core quotients.
The sole excluded local alphabet member is \(C_{00}\)--\(R_{00}\), whose
isolated \(C\)-core has no available attachment.

## 3. Exact boundary

Given any proper subset \(S\subsetneq\mathscr P^*\), choose
\(p\in\mathscr P^*\setminus S\), use its attachment model above, admit only
the two endpoint colourings of \(p\), and couple it to the minimum
kill-covered parent incidence.  Then (1) holds, but no child bond has a pair
in \(S\).  Therefore

\[
 \boxed{
 \text{parent kill cover + full supplementation}
 \not\Longrightarrow
 \text{a bond in any fixed proper subset of }\mathscr P^*.}
\tag{3}
\]

Thus canonical--\(X\), canonical--\(R\), new--new, one specified new
cell, and direct ancestry are all too narrow.  The only forced negative
localizations are: canonical--canonical is excluded by kill cover, and
opposite-gate \(C_{00}\)--\(R_{00}\) is excluded by attachment.  The
three-new-cell union in (1), with an otherwise unrestricted partner, is
irreducible at the attachment-quotient level.

The models do not form the complete NAE family of one actual
\(4\)-connected Eulerian plane-triangulation split.  A stronger actual
localization theorem would therefore need a new common-incidence lemma
coupling occupancy and rooted bonds across cells; local NAE rows, gate bits,
formal region trees, shore ranks, kill cover and the attachment quotient do
not supply that coupling.
