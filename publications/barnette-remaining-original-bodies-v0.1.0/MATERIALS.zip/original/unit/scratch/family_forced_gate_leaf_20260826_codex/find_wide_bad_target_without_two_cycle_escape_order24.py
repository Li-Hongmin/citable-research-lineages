#!/usr/bin/env python3
"""Find a wide-site bad target needing more than two cycles to reach neutral.

Only the 18 frozen order-24 braces from the accepted complete-family run are
used.  The scan stops at the first route closure.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations, product
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
SOURCE_DIR = UNIT / "scratch" / "existence_lifting_order24_20260826_codex"
SOURCE_JSON = SOURCE_DIR / "complete_family_existence_order24.json"
SOURCE_SCRIPT = SOURCE_DIR / "census_complete_family_existence_order24.py"


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


source = load_module(SOURCE_SCRIPT, "wide_two_cycle_escape_source")
lift = source.lift_bundle
edge = source.edge


def diff_count(first, second):
    graph = nx.Graph()
    graph.add_edges_from(first ^ second)
    return nx.number_connected_components(graph) if graph else 0


def first_failure():
    accepted = json.loads(SOURCE_JSON.read_text())
    totals = Counter()
    minimum_histogram = Counter()
    for source_graph6 in accepted["brace_graph6"]:
        primal = nx.from_graph6_bytes(source_graph6.encode())
        planar, embedding = nx.check_planarity(primal)
        assert planar and isinstance(embedding, nx.PlanarEmbedding)
        primal_faces = source.source_bundle.plane_faces(primal, embedding)
        reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
        reduced_faces = lift.verify_reduced_triangulation(reduced)
        families = lift.target_families(reduced, reduced_faces)[0]
        vertices = tuple(sorted(reduced))
        dual_to_primal = source.primal_edge_by_dual_edge(primal, primal_faces)
        cache = {}
        for root, encoded_family in families.items():
            colours = tuple(lift.decode_colouring(vertices, item) for item in encoded_family)
            matchings = tuple(
                source.matching_from_colour(primal, reduced, dual_to_primal, colour)
                for colour in colours
            )
            difference_counts = {}
            for first, second in combinations(range(len(matchings)), 2):
                difference_counts[first, second] = diff_count(matchings[first], matchings[second])
            cache[root] = colours, matchings, difference_counts

        for z in sorted(reduced):
            rotation = rotations[z]
            for i, j, first_gate, second_gate in lift.gate_pairs(rotation):
                left_size = j - i + 1
                right_size = len(rotation) - (j - i) + 1
                if (
                    min(left_size, right_size) < 5
                    or left_size % 2 == 0
                    or right_size % 2 == 0
                ):
                    continue
                expanded, locals_, _, _ = lift.split_vertex(reduced, z, rotation, i, j)
                expanded_faces = lift.expanded_triangulation_faces(expanded)
                if expanded_faces is None:
                    continue
                totals["wide_legal_splits"] += 1
                gate_edges = (
                    dual_to_primal[edge(z, first_gate)],
                    dual_to_primal[edge(z, second_gate)],
                )
                for root in sorted(families):
                    if z in root:
                        continue
                    totals["wide_interfaces"] += 1
                    colours, matchings, difference_counts = cache[root]
                    gate_counts = tuple(
                        sum(gate in matching for gate in gate_edges)
                        for matching in matchings
                    )
                    neutral = tuple(index for index, count in enumerate(gate_counts) if count <= 1)
                    assert neutral  # accepted order-24 family-level theorem
                    for index, (colour, count) in enumerate(zip(colours, gate_counts, strict=True)):
                        if count <= 1:
                            continue
                        totals["wide_double_gate_targets"] += 1
                        fixed = {vertex: value for vertex, value in colour.items() if vertex != z}
                        liftable = False
                        for bits in product((0, 1), repeat=3):
                            lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
                            if lift.is_target_profile(
                                lift.rooted_profile(expanded, expanded_faces, lifted, root)
                            ):
                                liftable = True
                                break
                        if liftable:
                            continue
                        totals["wide_bad_targets"] += 1
                        distances = {
                            other: difference_counts[tuple(sorted((index, other)))]
                            for other in neutral
                        }
                        minimum = min(distances.values())
                        minimum_histogram[minimum] += 1
                        if minimum <= 2:
                            continue
                        return {
                            "status": "wide_bad_target_without_two_cycle_neutral_escape",
                            "counts_before_stop": dict(sorted(totals.items())),
                            "minimum_histogram_before_stop": dict(sorted(minimum_histogram.items())),
                            "witness": {
                                "source_graph6": source_graph6,
                                "split_vertex": z,
                                "rotation": rotation,
                                "arc_lengths": [left_size, right_size],
                                "gate_indices": [i, j],
                                "gate_vertices": [first_gate, second_gate],
                                "primal_gate_edges": gate_edges,
                                "dual_root": root,
                                "primal_root": dual_to_primal[root],
                                "family_index": index,
                                "family_size": len(matchings),
                                "gate_counts": gate_counts,
                                "neutral_distances": distances,
                            },
                        }
    return {
        "status": "every_order24_wide_bad_target_has_two_cycle_neutral_escape",
        "counts": dict(sorted(totals.items())),
        "minimum_histogram": dict(sorted(minimum_histogram.items())),
        "witness": None,
    }


def main():
    print(json.dumps(first_failure(), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
