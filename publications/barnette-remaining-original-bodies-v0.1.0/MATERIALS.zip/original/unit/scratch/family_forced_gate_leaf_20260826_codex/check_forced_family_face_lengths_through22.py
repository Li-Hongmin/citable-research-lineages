#!/usr/bin/env python3
"""Test the face-length support of complete-family two-gate forcing through 22."""

from __future__ import annotations

from collections import Counter, defaultdict
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
BUNDLE = UNIT / "computations" / "bundles" / "target-component-saturation-through20"
SOURCE = BUNDLE / "verify_target_component_saturation_through20.py"
ORDER24 = UNIT / "scratch" / "existence_lifting_order24_20260826_codex" / "complete_family_existence_order24.json"


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


base = load_module(SOURCE, "forced_family_face_lengths_source")
lift = base.lift_bundle
edge = base.edge


def analyse(order, source_graph6, primal, primal_faces, totals, examples):
    reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift.verify_reduced_triangulation(reduced)
    families = lift.target_families(reduced, reduced_faces)[0]
    vertices = tuple(sorted(reduced))
    dual_to_primal = base.primal_edge_by_dual_edge(primal, primal_faces)
    cache = {}
    for root, encoded_family in families.items():
        colours = tuple(lift.decode_colouring(vertices, item) for item in encoded_family)
        matchings = tuple(
            base.matching_from_colour(primal, reduced, dual_to_primal, colour)
            for colour in colours
        )
        cache[root] = matchings

    for z in sorted(reduced):
        rotation = rotations[z]
        for first_index, second_index, first_gate, second_gate in lift.gate_pairs(rotation):
            left_size = second_index - first_index + 1
            right_size = len(rotation) - (second_index - first_index) + 1
            if left_size % 2 == 0 or right_size % 2 == 0:
                continue
            expanded, _, _, _ = lift.split_vertex(
                reduced, z, rotation, first_index, second_index
            )
            if lift.expanded_triangulation_faces(expanded) is None:
                continue
            gate_edges = (
                dual_to_primal[edge(z, first_gate)],
                dual_to_primal[edge(z, second_gate)],
            )
            for root, matchings in cache.items():
                if z in root:
                    continue
                if not all(set(gate_edges) <= set(matching) for matching in matchings):
                    continue
                face_length = len(rotation)
                totals[(order, face_length)] += 1
                if face_length > 4 and len(examples) < 20:
                    examples.append({
                        "order": order,
                        "source_graph6": source_graph6,
                        "split_vertex": z,
                        "rotation": rotation,
                        "gate_indices": [first_index, second_index],
                        "gate_vertices": [first_gate, second_gate],
                        "primal_gate_edges": gate_edges,
                        "dual_root": root,
                        "family_size": len(matchings),
                    })


def main():
    totals = Counter()
    graph_counts = Counter()
    examples = []
    for order in range(6, 23, 2):
        stream = base.generated_graphs(order)
        try:
            for source_graph6, primal in stream:
                graph_counts[(order, "generated")] += 1
                planar, embedding = nx.check_planarity(primal, counterexample=True)
                if not planar:
                    continue
                assert isinstance(embedding, nx.PlanarEmbedding)
                graph_counts[(order, "planar")] += 1
                primal_faces = base.source_bundle.plane_faces(primal, embedding)
                direct = base.source_bundle.is_two_extendable_direct(primal)
                assert direct == base.source_bundle.strict_hall_two_extendable(primal)
                if not direct:
                    continue
                graph_counts[(order, "braces")] += 1
                analyse(order, source_graph6, primal, primal_faces, totals, examples)
        finally:
            stream.close()
    accepted24 = json.loads(ORDER24.read_text())
    for source_graph6 in accepted24["brace_graph6"]:
        primal = nx.from_graph6_bytes(source_graph6.encode())
        planar, embedding = nx.check_planarity(primal, counterexample=True)
        assert planar and isinstance(embedding, nx.PlanarEmbedding)
        graph_counts[(24, "listed_braces")] += 1
        primal_faces = base.source_bundle.plane_faces(primal, embedding)
        assert base.source_bundle.is_two_extendable_direct(primal)
        analyse(24, source_graph6, primal, primal_faces, totals, examples)
    print(json.dumps({
        "graph_counts": {str(key): value for key, value in sorted(graph_counts.items())},
        "forced_family_interfaces_by_order_and_face_length": {
            str(key): value for key, value in sorted(totals.items())
        },
        "forced_family_interfaces_face_length_gt4": examples,
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
