# Exact synchronized two-cycle criterion at a wide gate site

## Rooted circuit-partition square

Let \(M\in\mathcal T_e\) and

\[
Q=F'-M=C_u\sqcup C_v,
\]

where the ends \(u,v\) of the matching root \(e=uv\) lie on different
cycles. Let \(A,B\) be vertex-disjoint \(M\)-alternating cycles, neither
containing \(e\). For \(i\in\{A,B\}\), write

\[
D_i=E(i)\cap E(Q),\qquad U_i=E(i)\cap M,
\]

and cut both cycles at once:

\[
P=Q-(D_A\cup D_B).
\]

For \(\epsilon=(\epsilon_A,\epsilon_B)\in\{0,1\}^2\), define

\[
Q_\epsilon=P\cup E_A^{\epsilon_A}\cup E_B^{\epsilon_B},
\qquad E_i^0=D_i,\quad E_i^1=U_i.
\tag{1}
\]

Thus \(Q_{00}=Q\), \(Q_{10}=Q\triangle A\),
\(Q_{01}=Q\triangle B\), and
\(Q_{11}=Q\triangle A\triangle B\). Alternation and vertex-disjointness
make every graph in (1) a spanning 2-factor.

Contract every connected component of \(P\) to one labelled vertex and add
the selected old/new pairing edges in (1). Retain an untouched cycle
component of \(P\) as an isolated quotient vertex. Call the resulting
multigraph \(J_\epsilon\), and mark by \(\mu,\nu\) the vertices containing
\(u,v\).

**Synchronized-pair criterion.** For every \(\epsilon\in\{0,1\}^2\),

\[
M_\epsilon=M\triangle \epsilon_A A\triangle\epsilon_B B\in\mathcal T_e
\iff
\begin{cases}
\kappa(J_\epsilon)=2,\\
\mu,\nu\text{ lie in different components of }J_\epsilon.
\end{cases}
\tag{2}
\]

Contraction preserves the component partition after the selected pairings
are restored, so \(\kappa(Q_\epsilon)=\kappa(J_\epsilon)\), including
untouched cycle components. It also preserves separation of \(u,v\).
Because \(Q_\epsilon\) is a spanning 2-factor and \(e\) is untouched, these
conditions are exactly membership in \(\mathcal T_e\).

An exact synchronized escape square satisfies

\[
\operatorname{Tar}(00)=\operatorname{Tar}(11)=1,\qquad
\operatorname{Tar}(10)=\operatorname{Tar}(01)=0.
\tag{3}
\]

It decreases gate load precisely when

\[
(A\cup B)\cap\{g,h\}\ne\varnothing.
\tag{4}
\]

For a double-gate base, the final load is
\(2-|(A\cup B)\cap\{g,h\}|\). Equation (2), rather than circuit counts
alone, is necessary: a two-cycle corner whose root ends lie on the same
cycle is still not a target.

## Equivalent dual-forest form

Let \(c\) be the dual target colouring, \(a=e^*\), and \(R=H(c)-a\).
By Note 074, \(A^*,B^*\) are edge-disjoint dual bonds
\(\delta(S_A),\delta(S_B)\). The four states satisfy

\[
E(R_\epsilon)=E(R)\triangle
\epsilon_A\delta(S_A)\triangle\epsilon_B\delta(S_B).
\tag{5}
\]

Criterion (2) is equivalently

\[
M_\epsilon\in\mathcal T_e
\iff
R_\epsilon\text{ is a three-component forest joining the ends of }a.
\tag{6}
\]

The common quotient \(J_\epsilon\) is the primal circuit version of
Note 074's labelled terminal-incidence transition. Scalar cycle changes do
not compose unless this common cut-path pairing is retained.

## The frozen order-24 (5,5) square

In the first forced-component failure, family target 4 and neutral target 2
differ on the alternating four-cycles

\[
\begin{aligned}
B_0&=\{1\!-\!12,1\!-\!15,2\!-\!12,2\!-\!15\},\\
A_g&=\{3\!-\!21,3\!-\!22,11\!-\!21,11\!-\!22\}.
\end{aligned}
\]

\(B_0\) avoids both gates and \(A_g\) contains the variable gate \(3-21\).
The four outcomes are

\[
\begin{array}{c|cccc}
\epsilon&00&10&01&11\\ \hline
\kappa(Q_\epsilon)&2&1&3&2\\
\text{root separated}&1&0&0&1.
\end{array}
\tag{7}
\]

The middle columns can be interchanged with the names of the cycles. Each
single flip leaves \(\mathcal T_e\); the synchronized flip reaches the
neutral target in another target-state component.

## Consequence for WGE

Brace structure supplies a root-avoiding gate-changing alternating cycle,
but not its repair pair. If \(g=xy\in M\), choose a nonmatching edge
\(xx'\) at \(x\). Because the unchanged root \(e\) is disjoint from the
gate. Of the two nonmatching edges at \(x\), at most one can meet an end of
\(e\), so choose \(xx'\) independent from \(e\). By 2-extendability they extend to
a perfect matching \(N\). Then \(N\) omits \(g\), while \(e\in M\cap N\).
Hence the component of \(M\triangle N\) containing \(g\) is an
\(M\)-alternating cycle that automatically avoids \(e\).

A distance-at-most-two proof of WGE still requires the selector

\[
\exists A\text{ gate-changing}:\quad
\operatorname{Tar}(A)=1
\quad\text{or}\quad
\exists B\perp A:\operatorname{Tar}(A\triangle B)=1,
\tag{8}
\]

with final gate load at most one. Criterion (2) decides a proposed pair; it
does not supply the existential quantifier in (8).

Across all 18 accepted order-24 braces, the frozen wide-site check finds

\[
170\text{ wide legal splits},\quad
4556\text{ wide interfaces},\quad
3282\text{ wide double-gate targets}.
\]

All 3,282 are nonliftable fixed targets, but every one reaches a neutral
target at alternating-cycle distance at most two:

\[
3175\text{ at distance }1,\qquad107\text{ at distance }2.
\tag{9}
\]

Thus distance-two escape holds through order 24, but (9) is finite evidence.
The independently checked neutral-count profile also closes a pure parity
route: among the 4,556 wide interfaces, 3,062 have odd neutral count, but
the 432 with count one are exactly singleton families; every mixed family
has at least two neutral targets. This is a family-size effect, not a parity
forcing law.

## Actual route closure: the gate cycle cannot be arbitrary

The implication

\[
\text{any gate-changing alternating cycle }A
\Longrightarrow
\exists B\perp A\text{ satisfying (2)}
\tag{10}
\]

is false in the actual plane brace with graph6

    W???????????w?s?T?Ag?I_?T??T??I_?Ag??T??@W??B_?

Use

\[
z=1,\quad
N(z)=(2,5,7,9,11,13,12,10,8,6,3,0),\quad
(\ell_1,\ell_3)=(5,9),
\]

gate indices \((0,4)\), primal gates \((0,14),(8,22)\), dual root
\((4,11)\), and primal root \((10,20)\). Family target 8 is nonliftable and
has matching

\[
\{0\!-\!14,1\!-\!13,2\!-\!12,3\!-\!15,4\!-\!16,5\!-\!17,
6\!-\!18,7\!-\!19,8\!-\!22,9\!-\!21,10\!-\!20,11\!-\!23\}.
\]

Choose the gate-changing alternating 8-cycle

\[
A=\{0\!-\!13,0\!-\!14,1\!-\!12,1\!-\!13,
2\!-\!12,2\!-\!16,4\!-\!14,4\!-\!16\}.
\tag{11}
\]

It removes gate \(0-14\). Its single flip has three complement cycles and
is not a target. Exhaustion of all 324 perfect matchings gives 16
\(M\)-alternating cycles. No alternating cycle vertex-disjoint from (11)
repairs it to a root-separated two-cycle factor of gate load at most one.

The same target has three non-target gate-changing cycles: one has a valid
one-cycle repair partner, while (11) and one other do not. Its complete
family has eight neutral targets. Thus this is a real selection counterexample
to (10), not a WGE counterexample. Planarity turns each cycle into a bond and
brace supplies at least one gate cycle; neither makes an arbitrary cycle's
terminal pairing compatible. Any proof of (8) must select \(A,B\) jointly
from the complete family.

## Boundary

- **Exact conclusion:** (1)--(6) are a necessary-and-sufficient proof-level
  synchronized two-cycle criterion. A distance-two WGE proof reduces to the
  existential selector (8), not to scalar cycle counts or parity.
- **Weakest load-bearing argument:** the quotient only recognizes a pair
  after both cycles are supplied. No brace/planar law forcing an accepting
  pair was proved; witness (11) shows that \(A\) cannot be arbitrary.
- **Evidence level:** criterion = proof-level; (11) = exact actual
  plane-brace route closure; (9) = exact order-24 finite evidence.
- **Unresolved boundary:** whether every wide double-gate target has some
  correctly selected \(A\), alone or with one disjoint \(B\), satisfying
  (2); whether higher order first needs distance at least three; WGE itself.

Reproduction:

    uv run --with 'networkx==3.6.1' \
      units/barnette/scratch/family_forced_gate_leaf_20260826_codex/verify_unrepairable_gate_cycle_witness.py

    uv run --with 'networkx==3.6.1' \
      units/barnette/scratch/family_forced_gate_leaf_20260826_codex/find_wide_bad_target_without_two_cycle_escape_order24.py
