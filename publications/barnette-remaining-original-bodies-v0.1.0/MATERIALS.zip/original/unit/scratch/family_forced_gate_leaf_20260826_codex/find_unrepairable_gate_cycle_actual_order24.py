#!/usr/bin/env python3
"""Find an actual wide bad target with an unrepairable chosen gate cycle.

This tests the overly strong mechanism "choose any gate-changing alternating
cycle, then add one disjoint alternating cycle to recover a neutral target".
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations, product
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
SOURCE_DIR = UNIT / "scratch" / "existence_lifting_order24_20260826_codex"
SOURCE_JSON = SOURCE_DIR / "complete_family_existence_order24.json"
SOURCE_SCRIPT = SOURCE_DIR / "census_complete_family_existence_order24.py"


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


source = load_module(SOURCE_SCRIPT, "unrepairable_gate_cycle_source")
lift = source.lift_bundle
edge = source.edge


def diff_cycles(first, second):
    graph = nx.Graph()
    graph.add_edges_from(first ^ second)
    if not graph:
        return []
    return [frozenset(edge(*item) for item in graph.subgraph(nodes).edges())
            for nodes in nx.connected_components(graph)]


def perfect_matchings(graph: nx.Graph):
    neighbours = {vertex: tuple(sorted(graph[vertex])) for vertex in graph}

    def visit(unmatched, chosen):
        if not unmatched:
            yield frozenset(chosen)
            return
        vertex = min(unmatched)
        for neighbour in neighbours[vertex]:
            if neighbour in unmatched:
                yield from visit(
                    unmatched - {vertex, neighbour},
                    chosen + (edge(vertex, neighbour),),
                )

    yield from visit(frozenset(graph), ())


def shape(primal, matching, root):
    complement = primal.copy()
    complement.remove_edges_from(matching)
    parts = list(nx.connected_components(complement))
    separated = len(parts) == 2 and not any(set(root) <= part for part in parts)
    return len(parts), separated


def vertices(cycle):
    return frozenset(vertex for item in cycle for vertex in item)


def main():
    accepted = json.loads(SOURCE_JSON.read_text())
    totals = Counter()
    for source_graph6 in accepted["brace_graph6"]:
        primal = nx.from_graph6_bytes(source_graph6.encode())
        planar, embedding = nx.check_planarity(primal)
        assert planar and isinstance(embedding, nx.PlanarEmbedding)
        primal_faces = source.source_bundle.plane_faces(primal, embedding)
        reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
        reduced_faces = lift.verify_reduced_triangulation(reduced)
        families = lift.target_families(reduced, reduced_faces)[0]
        reduced_vertices = tuple(sorted(reduced))
        dual_to_primal = source.primal_edge_by_dual_edge(primal, primal_faces)
        ambient_matchings = tuple(perfect_matchings(primal))
        cache = {}
        for root, encoded_family in families.items():
            colours = tuple(lift.decode_colouring(reduced_vertices, item) for item in encoded_family)
            matchings = tuple(
                source.matching_from_colour(primal, reduced, dual_to_primal, colour)
                for colour in colours
            )
            cache[root] = colours, matchings

        for z in sorted(reduced):
            rotation = rotations[z]
            for i, j, first_gate, second_gate in lift.gate_pairs(rotation):
                arc_lengths = (j - i + 1, len(rotation) - (j - i) + 1)
                if min(arc_lengths) < 5 or any(length % 2 == 0 for length in arc_lengths):
                    continue
                expanded, locals_, _, _ = lift.split_vertex(reduced, z, rotation, i, j)
                expanded_faces = lift.expanded_triangulation_faces(expanded)
                if expanded_faces is None:
                    continue
                gates = (
                    dual_to_primal[edge(z, first_gate)],
                    dual_to_primal[edge(z, second_gate)],
                )
                for root, (colours, targets) in cache.items():
                    if z in root:
                        continue
                    primal_root = dual_to_primal[root]
                    for target_index, (colour, base) in enumerate(zip(colours, targets, strict=True)):
                        if not set(gates) <= set(base):
                            continue
                        fixed = {vertex: value for vertex, value in colour.items() if vertex != z}
                        if any(
                            lift.is_target_profile(
                                lift.rooted_profile(
                                    expanded,
                                    expanded_faces,
                                    {**fixed, **dict(zip(locals_, bits, strict=True))},
                                    root,
                                )
                            )
                            for bits in product((0, 1), repeat=3)
                        ):
                            continue
                        totals["wide_bad_targets"] += 1
                        alternating_cycles = set()
                        for matching in ambient_matchings:
                            cycles = diff_cycles(base, matching)
                            if len(cycles) == 1:
                                alternating_cycles.add(cycles[0])
                        alternating_cycles = tuple(sorted(
                            alternating_cycles,
                            key=lambda one: (len(one), sorted(one)),
                        ))
                        for cycle_index, gate_cycle in enumerate(alternating_cycles):
                            if primal_root in gate_cycle:
                                continue
                            gate_mask = tuple(gate in gate_cycle for gate in gates)
                            if not any(gate_mask):
                                continue
                            single = base ^ gate_cycle
                            single_gate_count = sum(gate in single for gate in gates)
                            assert single_gate_count <= 1
                            if shape(primal, single, primal_root) == (2, True):
                                continue
                            totals["non_target_gate_cycles"] += 1
                            repair_partners = []
                            for partner_index, partner in enumerate(alternating_cycles):
                                if partner_index == cycle_index or primal_root in partner:
                                    continue
                                if vertices(gate_cycle) & vertices(partner):
                                    continue
                                double = single ^ partner
                                if sum(gate in double for gate in gates) > 1:
                                    continue
                                if shape(primal, double, primal_root) == (2, True):
                                    repair_partners.append(partner_index)
                            if repair_partners:
                                totals["repairable_chosen_gate_cycles"] += 1
                                continue
                            print(json.dumps({
                                "status": "actual_unrepairable_chosen_gate_cycle",
                                "counts_before_stop": dict(sorted(totals.items())),
                                "witness": {
                                    "source_graph6": source_graph6,
                                    "split_vertex": z,
                                    "rotation": rotation,
                                    "arc_lengths": arc_lengths,
                                    "gate_indices": [i, j],
                                    "primal_gates": gates,
                                    "dual_root": root,
                                    "primal_root": primal_root,
                                    "target_index": target_index,
                                    "matching": sorted(base),
                                    "gate_cycle": sorted(gate_cycle),
                                    "single_shape": shape(primal, single, primal_root),
                                    "alternating_cycle_count": len(alternating_cycles),
                                },
                            }, indent=2, sort_keys=True))
                            return
    print(json.dumps({
        "status": "every_tested_chosen_gate_cycle_has_one_cycle_repair",
        "counts": dict(sorted(totals.items())),
        "witness": None,
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
