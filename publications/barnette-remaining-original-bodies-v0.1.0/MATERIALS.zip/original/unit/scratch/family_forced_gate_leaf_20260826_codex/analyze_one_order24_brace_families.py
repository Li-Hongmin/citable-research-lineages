#!/usr/bin/env python3
"""Exhaust complete-family premises on only the frozen order-24 brace."""

from __future__ import annotations

from collections import Counter
from itertools import product
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
SOURCE = UNIT / "scratch" / "target_component_saturation_order24_20260826"
CERTIFICATE = SOURCE / "forced_target_components_order24.json"
CENSUS = SOURCE / "census_forced_target_components_order24.py"


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


census = load_module(CENSUS, "family_forced_gate_one_brace_source")
lift = census.lift_bundle
edge = census.edge


def main():
    failure = json.loads(CERTIFICATE.read_text())["first_failure"]
    source_graph6 = failure["source_graph6"]
    primal = nx.from_graph6_bytes(source_graph6.encode())
    primal_faces = tuple(tuple(face) for face in failure["source_primal_faces"])
    reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift.verify_reduced_triangulation(reduced)
    families = lift.target_families(reduced, reduced_faces)[0]
    vertices = tuple(sorted(reduced))
    dual_to_primal = census.primal_edge_by_dual_edge(primal, primal_faces)
    cache = {}
    for root, encoded_family in families.items():
        colours = tuple(lift.decode_colouring(vertices, item) for item in encoded_family)
        matchings = tuple(
            census.matching_from_colour(primal, reduced, dual_to_primal, colour)
            for colour in colours
        )
        cache[root] = colours, matchings

    counts = Counter()
    family_forced_profiles = Counter()
    failures = []
    non_arc11 = []
    forced_examples = []
    for z in sorted(reduced):
        rotation = rotations[z]
        for first_index, second_index, first_gate, second_gate in lift.gate_pairs(rotation):
            left_size = second_index - first_index + 1
            right_size = len(rotation) - (second_index - first_index) + 1
            if left_size % 2 == 0 or right_size % 2 == 0:
                continue
            expanded, locals_, left_arc, right_arc = lift.split_vertex(
                reduced, z, rotation, first_index, second_index
            )
            if nx.number_of_selfloops(expanded) or any(degree % 2 for _, degree in expanded.degree()):
                continue
            planar, _ = nx.check_planarity(expanded)
            if not planar or any(len(face) != 3 for face in lift.plane_faces(expanded)):
                continue
            expanded_faces = lift.expanded_triangulation_faces(expanded)
            if expanded_faces is None:
                continue
            counts["legal_splits"] += 1
            gate_edges = (
                dual_to_primal[edge(z, first_gate)],
                dual_to_primal[edge(z, second_gate)],
            )
            for root in sorted(families):
                if z in root:
                    continue
                counts["interfaces"] += 1
                colours, matchings = cache[root]
                gate_counts = tuple(sum(gate in matching for gate in gate_edges) for matching in matchings)
                counts[f"minimum_gate_count_{min(gate_counts)}"] += 1
                if not all(value == 2 for value in gate_counts):
                    continue
                counts["families_forcing_both_gates"] += 1
                all_rows = []
                all_arc11 = True
                for index, colour in enumerate(colours):
                    normalized = {vertex: value ^ colour[z] for vertex, value in colour.items()}
                    arc11 = all(
                        all(normalized[u] != normalized[v] for u, v in zip(arc, arc[1:]))
                        for arc in (left_arc, right_arc)
                    )
                    all_arc11 &= arc11
                    if not arc11:
                        non_arc11.append({
                            "z": z,
                            "gate_indices": [first_index, second_index],
                            "gate_vertices": [first_gate, second_gate],
                            "dual_root": list(root),
                            "target_index": index,
                            "boundary_word": "".join(str(normalized[v]) for v in rotation),
                        })
                    fixed = {vertex: value for vertex, value in colour.items() if vertex != z}
                    rows = []
                    for bits in product((0, 1), repeat=3):
                        lifted_colour = {**fixed, **dict(zip(locals_, bits, strict=True))}
                        profile = lift.rooted_profile(expanded, expanded_faces, lifted_colour, root)
                        if lift.is_target_profile(profile):
                            rows.append("".join(str(bit ^ colour[z]) for bit in bits))
                    all_rows.append(tuple(rows))
                liftable = any(all_rows)
                counts["family_forced_all_targets_arc11" if all_arc11 else "family_forced_has_non_arc11"] += 1
                counts["family_forced_with_lift" if liftable else "family_forced_without_lift"] += 1
                family_forced_profiles[str(tuple(all_rows))] += 1
                forced_examples.append({
                    "z": z,
                    "rotation": list(rotation),
                    "gate_indices": [first_index, second_index],
                    "gate_vertices": [first_gate, second_gate],
                    "primal_gate_edges": [list(item) for item in gate_edges],
                    "dual_root": list(root),
                    "primal_root": list(dual_to_primal[root]),
                    "family_size": len(matchings),
                    "all_rows": all_rows,
                })
                if not liftable:
                    failures.append({
                        "z": z,
                        "rotation": list(rotation),
                        "gate_indices": [first_index, second_index],
                        "gate_vertices": [first_gate, second_gate],
                        "primal_gate_edges": [list(item) for item in gate_edges],
                        "dual_root": list(root),
                        "primal_root": list(dual_to_primal[root]),
                        "family_size": len(matchings),
                        "rows": all_rows,
                    })
    print(json.dumps({
        "source_graph6": source_graph6,
        "counts": dict(sorted(counts.items())),
        "family_forced_row_profiles": dict(sorted(family_forced_profiles.items())),
        "family_forced_non_arc11_targets": non_arc11,
        "family_forced_examples": forced_examples,
        "family_level_failures": failures,
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
