#!/usr/bin/env python3
"""Find a three-switch circuit partition with no target at distance 1 or 2."""

from __future__ import annotations

from itertools import combinations
import json

import networkx as nx


PORTS = tuple(range(12))
SWITCHES = tuple(tuple(range(4 * index, 4 * index + 4)) for index in range(3))
OLD = tuple(((p[0], p[1]), (p[2], p[3])) for p in SWITCHES)
NEW = tuple(((p[0], p[2]), (p[1], p[3])) for p in SWITCHES)


def pairings(items):
    if not items:
        yield ()
        return
    first = items[0]
    for index in range(1, len(items)):
        second = items[index]
        remaining = items[1:index] + items[index + 1 :]
        for rest in pairings(remaining):
            yield ((first, second),) + rest


def components(alpha, state):
    adjacency = {port: [] for port in PORTS}
    for first, second in alpha:
        adjacency[first].append(second)
        adjacency[second].append(first)
    for index, bit in enumerate(state):
        for first, second in (NEW[index] if bit else OLD[index]):
            adjacency[first].append(second)
            adjacency[second].append(first)
    assert set(len(items) for items in adjacency.values()) == {2}
    result = []
    unseen = set(PORTS)
    while unseen:
        start = min(unseen)
        stack = [start]
        part = set()
        while stack:
            vertex = stack.pop()
            if vertex in part:
                continue
            part.add(vertex)
            stack.extend(adjacency[vertex])
        unseen -= part
        result.append(frozenset(part))
    return tuple(sorted(result, key=min))


def root_separated(parts, root_paths):
    first_path, second_path = root_paths
    first_port = first_path[0]
    second_port = second_path[0]
    return not any(first_port in part and second_port in part for part in parts)


def main():
    states = tuple(
        tuple((mask >> index) & 1 for index in range(3))
        for mask in range(8)
    )
    examined = 0
    for alpha in pairings(PORTS):
        examined += 1
        skeleton = nx.MultiGraph()
        skeleton.add_nodes_from(PORTS)
        skeleton.add_edges_from(alpha)
        for pairing in OLD + NEW:
            skeleton.add_edges_from(pairing)
        if not nx.is_connected(skeleton):
            continue
        planar, _ = nx.check_planarity(skeleton)
        if not planar:
            continue
        partitions = {state: components(alpha, state) for state in states}
        if len(partitions[(0, 0, 0)]) != 2 or len(partitions[(1, 1, 1)]) != 2:
            continue
        for root_paths in combinations(alpha, 2):
            targets = {
                state: (
                    len(partitions[state]) == 2
                    and root_separated(partitions[state], root_paths)
                )
                for state in states
            }
            if not targets[(0, 0, 0)] or not targets[(1, 1, 1)]:
                continue
            forbidden_d2_gate_states = (
                (1, 0, 0),
                (1, 1, 0),
                (1, 0, 1),
            )
            if any(targets[state] for state in forbidden_d2_gate_states):
                continue
            print(
                json.dumps(
                    {
                        "status": "three_switch_d2_pairing_obstruction",
                        "pairings_examined": examined,
                        "path_pairing_alpha": alpha,
                        "skeleton_graph6": nx.to_graph6_bytes(
                            nx.Graph(skeleton), header=False
                        ).decode().strip(),
                        "skeleton_planar": planar,
                        "skeleton_bipartite": nx.is_bipartite(skeleton),
                        "old_switch_pairings": OLD,
                        "new_switch_pairings": NEW,
                        "root_paths": root_paths,
                        "states": {
                            "".join(map(str, state)): {
                                "circuit_count": len(partitions[state]),
                                "root_separated": root_separated(
                                    partitions[state], root_paths
                                ),
                                "target": targets[state],
                                "components": [
                                    sorted(part) for part in partitions[state]
                                ],
                            }
                            for state in states
                        },
                    },
                    indent=2,
                    sort_keys=True,
                )
            )
            return
    print(json.dumps({"status": "no_obstruction", "pairings_examined": examined}))


if __name__ == "__main__":
    main()
