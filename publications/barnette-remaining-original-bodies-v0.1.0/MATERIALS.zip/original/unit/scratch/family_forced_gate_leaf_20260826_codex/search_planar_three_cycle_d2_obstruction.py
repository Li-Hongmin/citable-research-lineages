#!/usr/bin/env python3
"""Search planar rooted transition cubes for a distance-three gate escape."""

from __future__ import annotations

from itertools import combinations
import argparse
import json

import networkx as nx


def pairings(items):
    if not items:
        yield ()
        return
    first = items[0]
    for index in range(1, len(items)):
        second = items[index]
        remaining = items[1:index] + items[index + 1 :]
        for rest in pairings(remaining):
            yield ((first, second),) + rest


def switch_pairings(sizes):
    old = []
    new = []
    start = 0
    for size in sizes:
        ports = tuple(range(start, start + 2 * size))
        old.append(tuple((ports[2 * i], ports[2 * i + 1]) for i in range(size)))
        new.append(
            tuple(
                (ports[2 * i + 1], ports[(2 * i + 2) % (2 * size)])
                for i in range(size)
            )
        )
        start += 2 * size
    return tuple(old), tuple(new)


def components(port_count, alpha, old, new, state):
    adjacency = {port: [] for port in range(port_count)}
    for first, second in alpha:
        adjacency[first].append(second)
        adjacency[second].append(first)
    for index, bit in enumerate(state):
        for first, second in (new[index] if bit else old[index]):
            adjacency[first].append(second)
            adjacency[second].append(first)
    assert set(map(len, adjacency.values())) == {2}
    result = []
    unseen = set(adjacency)
    while unseen:
        stack = [min(unseen)]
        part = set()
        while stack:
            vertex = stack.pop()
            if vertex not in part:
                part.add(vertex)
                stack.extend(adjacency[vertex])
        unseen -= part
        result.append(frozenset(part))
    return tuple(sorted(result, key=min))


def separated(parts, root_paths):
    first = root_paths[0][0]
    second = root_paths[1][0]
    return not any(first in part and second in part for part in parts)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sizes", default="2,2,3")
    args = parser.parse_args()
    sizes = tuple(map(int, args.sizes.split(",")))
    assert len(sizes) == 3 and all(size >= 2 for size in sizes)
    old, new = switch_pairings(sizes)
    port_count = 2 * sum(sizes)
    ports = tuple(range(port_count))
    states = tuple(
        tuple((mask >> index) & 1 for index in range(3))
        for mask in range(8)
    )
    forbidden = ((1, 0, 0), (1, 1, 0), (1, 0, 1))
    counts = {
        "pairings": 0,
        "connected_skeletons": 0,
        "planar_skeletons": 0,
        "endpoint_target_squares": 0,
    }
    for alpha in pairings(ports):
        counts["pairings"] += 1
        skeleton = nx.MultiGraph()
        skeleton.add_nodes_from(ports)
        skeleton.add_edges_from(alpha)
        for local in old + new:
            skeleton.add_edges_from(local)
        if not nx.is_connected(skeleton):
            continue
        counts["connected_skeletons"] += 1
        planar, _ = nx.check_planarity(skeleton)
        if not planar:
            continue
        counts["planar_skeletons"] += 1
        partitions = {
            state: components(port_count, alpha, old, new, state)
            for state in states
        }
        if len(partitions[(0, 0, 0)]) != 2 or len(partitions[(1, 1, 1)]) != 2:
            continue
        for root_paths in combinations(alpha, 2):
            targets = {
                state: (
                    len(partitions[state]) == 2
                    and separated(partitions[state], root_paths)
                )
                for state in states
            }
            if not targets[(0, 0, 0)] or not targets[(1, 1, 1)]:
                continue
            counts["endpoint_target_squares"] += 1
            if any(targets[state] for state in forbidden):
                continue
            print(
                json.dumps(
                    {
                        "status": "planar_distance_three_pairing_obstruction",
                        "switch_half_lengths": sizes,
                        "counts_before_stop": counts,
                        "path_pairing_alpha": alpha,
                        "old_pairings": old,
                        "new_pairings": new,
                        "root_paths": root_paths,
                        "skeleton_bipartite_without_subdivision": nx.is_bipartite(
                            skeleton
                        ),
                        "states": {
                            "".join(map(str, state)): {
                                "circuits": len(partitions[state]),
                                "root_separated": separated(
                                    partitions[state], root_paths
                                ),
                                "target": targets[state],
                                "components": [
                                    sorted(part) for part in partitions[state]
                                ],
                            }
                            for state in states
                        },
                    },
                    indent=2,
                    sort_keys=True,
                )
            )
            return
    print(
        json.dumps(
            {
                "status": "no_planar_distance_three_pairing_obstruction",
                "switch_half_lengths": sizes,
                "counts": counts,
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
