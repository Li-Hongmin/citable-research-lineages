#!/usr/bin/env python3
"""Inspect only the frozen order-24 family and its exchange cubes."""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations, product
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
SOURCE = UNIT / "scratch" / "target_component_saturation_order24_20260826"
CERTIFICATE = SOURCE / "forced_target_components_order24.json"
VERIFIER = SOURCE / "verify_order24_component_failure.py"


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


order24 = load_module(VERIFIER, "family_forced_gate_order24_source")
lift = order24.lift_bundle
edge = order24.edge


def diff_cycles(first, second):
    graph = nx.Graph()
    graph.add_edges_from(first ^ second)
    if not graph:
        return []
    return [frozenset(edge(*item) for item in graph.subgraph(nodes).edges())
            for nodes in nx.connected_components(graph)]


def target_shape(primal: nx.Graph, matching, root):
    complement = primal.copy()
    complement.remove_edges_from(matching)
    assert set(dict(complement.degree()).values()) == {2}
    components = list(nx.connected_components(complement))
    separated = len(components) == 2 and not any(set(root) <= part for part in components)
    return len(components), separated


def affine_rank(vectors):
    base = vectors[0]
    rows = [value ^ base for value in vectors[1:]]
    rank = 0
    while rows:
        pivot = max(rows)
        if pivot == 0:
            break
        rank += 1
        bit = pivot.bit_length() - 1
        rows = [value ^ pivot if (value >> bit) & 1 else value for value in rows]
        rows.remove(0)
    return rank


def component_signature(reduced, colour, root, z, rotation):
    graph = nx.Graph()
    graph.add_nodes_from(reduced)
    graph.add_edges_from(
        (u, v) for u, v in reduced.edges()
        if edge(u, v) != root and colour[u] == colour[v]
    )
    graph.remove_node(z)
    parts = sorted((sorted(part) for part in nx.connected_components(graph)), key=lambda x: (min(x), x))
    block = {vertex: index for index, part in enumerate(parts) for vertex in part}
    return {
        "boundary_blocks": [block[vertex] for vertex in rotation],
        "root_blocks": [block[vertex] for vertex in root],
        "all_blocks": parts,
    }


def main():
    certificate = json.loads(CERTIFICATE.read_text())
    failure = certificate["first_failure"]
    primal = nx.from_graph6_bytes(failure["source_graph6"].encode())
    primal_faces = tuple(tuple(face) for face in failure["source_primal_faces"])
    reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift.verify_reduced_triangulation(reduced)
    site = failure["site"]
    z = site["split_vertex"]
    rotation = tuple(site["rotation"])
    gate_vertices = tuple(site["gate_vertices"])
    gate_edges = tuple(edge(*item) for item in site["primal_gate_edges"])
    left_arc = tuple(site["left_arc"])
    right_arc = tuple(site["right_arc"])
    root = edge(*failure["dual_root"])
    primal_root = edge(*failure["primal_root"])
    expanded, locals_, _, _ = lift.split_vertex(
        reduced, z, rotation, *site["gate_indices"]
    )
    expanded_faces = lift.expanded_triangulation_faces(expanded)
    assert expanded_faces is not None
    dual_to_primal = order24.primal_edge_by_dual_edge(primal, primal_faces)

    encoded_family = lift.target_families(reduced, reduced_faces)[0][root]
    vertices = tuple(sorted(reduced))
    colours = tuple(lift.decode_colouring(vertices, item) for item in encoded_family)
    matchings = tuple(order24.matching_from_colour(primal, reduced, dual_to_primal, colour)
                      for colour in colours)
    matching_index = {matching: index for index, matching in enumerate(matchings)}
    adjacency = order24.target_graph(matchings)
    components = sorted((sorted(part) for part in nx.connected_components(adjacency)), key=min)
    component_of = {index: component_index for component_index, part in enumerate(components)
                    for index in part}

    records = []
    for index, (colour, matching) in enumerate(zip(colours, matchings, strict=True)):
        fixed = {vertex: value for vertex, value in colour.items() if vertex != z}
        rows = []
        for bits in product((0, 1), repeat=3):
            lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
            profile = lift.rooted_profile(expanded, expanded_faces, lifted, root)
            if lift.is_target_profile(profile):
                rows.append("".join(str(bit ^ colour[z]) for bit in bits))
        normalized = {vertex: colour[vertex] ^ colour[z] for vertex in colour}
        vector = sum(value << vertex for vertex, value in normalized.items())
        records.append({
            "index": index,
            "component": component_of[index],
            "gate_count": sum(gate in matching for gate in gate_edges),
            "gate_bits": [int(normalized[vertex] == 0) for vertex in gate_vertices],
            "boundary_word": "".join(str(normalized[vertex]) for vertex in rotation),
            "arc_alternating": [
                all(normalized[u] != normalized[v] for u, v in zip(arc, arc[1:]))
                for arc in (left_arc, right_arc)
            ],
            "lift_rows": rows,
            "colour_vector": vector,
            "forest_signature": component_signature(reduced, colour, root, z, rotation),
        })

    pair_records = []
    cube_summary = Counter()
    cross_target_patterns = Counter()
    for first, second in combinations(range(len(matchings)), 2):
        cycles = diff_cycles(matchings[first], matchings[second])
        cycle_gate_masks = []
        for cycle in cycles:
            cycle_gate_masks.append("".join("1" if gate in cycle else "0" for gate in gate_edges))
        corners = []
        for mask in range(1 << len(cycles)):
            matching = matchings[first]
            for cycle_index, cycle in enumerate(cycles):
                if (mask >> cycle_index) & 1:
                    matching = matching ^ cycle
            count, separated = target_shape(primal, matching, primal_root)
            target_index = matching_index.get(matching)
            assert (target_index is not None) == (count == 2 and separated)
            corners.append({
                "mask": format(mask, f"0{len(cycles)}b"),
                "complement_cycles": count,
                "root_separated": separated,
                "target_index": target_index,
                "gate_count": sum(gate in matching for gate in gate_edges),
            })
        key = (
            component_of[first] == component_of[second],
            len(cycles),
            tuple(sorted(cycle_gate_masks)),
            tuple(sorted(corner["gate_count"] for corner in corners if corner["target_index"] is not None)),
            sum(corner["target_index"] is not None for corner in corners),
        )
        cube_summary[str(key)] += 1
        if component_of[first] != component_of[second]:
            target_pattern = tuple(
                (corner["mask"], corner["target_index"], corner["gate_count"])
                for corner in corners if corner["target_index"] is not None
            )
            cross_target_patterns[str((len(cycles), tuple(sorted(cycle_gate_masks)), target_pattern))] += 1
        pair_records.append({
            "pair": [first, second],
            "components": [component_of[first], component_of[second]],
            "difference_cycle_count": len(cycles),
            "difference_cycles": [sorted(cycle) for cycle in cycles],
            "cycle_gate_masks": cycle_gate_masks,
            "corners": corners,
        })

    output = {
        "components": components,
        "targets": records,
        "normalized_colour_affine_rank": affine_rank([record["colour_vector"] for record in records]),
        "cube_summary": dict(sorted(cube_summary.items())),
        "cross_component_target_patterns": dict(sorted(cross_target_patterns.items())),
        "pairs": pair_records,
    }
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
