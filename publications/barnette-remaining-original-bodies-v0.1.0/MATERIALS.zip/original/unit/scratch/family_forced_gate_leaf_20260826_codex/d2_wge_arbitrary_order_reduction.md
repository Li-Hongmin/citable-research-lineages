# D2-WGE reduces to a brace-realizable rooted transition-cube exclusion

## Exact quantifier

For every simple plane cubic bipartite brace \(F'\), every wide legal site,
every unchanged root \(e\), and every double-gate
\(M\in\mathcal T_e\), D2-WGE asks for either

\[
M\triangle A\in\mathcal T_e
\tag{D1}
\]

with gate load at most one, for one root-avoiding gate-changing
\(M\)-alternating cycle \(A\), or

\[
M\triangle A\triangle B\in\mathcal T_e
\tag{D2}
\]

with gate load at most one, where \(B\) is an \(M\)-alternating cycle
vertex-disjoint from \(A\). The common cut-path quotient \(J_\epsilon\)
from the preceding synchronous-two-cycle note is an exact test.

Brace structure guarantees a root-avoiding gate cycle, but not a successful
one. If \(g=xy\), choose one of the two nonmatching edges \(xx'\) at \(x\)
that is independent from \(e\); at most one can meet an end of \(e\).
The independent edges \(e,xx'\) extend to a perfect matching \(N\).
The component of \(M\triangle N\) containing \(g\) changes \(g\) and avoids
\(e\), since \(e\in M\cap N\). The missing step is selection of an accepting
\(A\) or pair \((A,B)\).

## Rooted transition cubes

Let \(C_0,\ldots,C_{k-1}\) be pairwise vertex-disjoint, root-avoiding
\(M\)-alternating cycles, with \(C_0\) gate-changing. Cutting all old
\(Q=F'-M\) edges on these cycles leaves \(Q\)-paths whose terminal pairing
is \(\alpha\). Coordinate \(i\) has old pairing \(D_i\) and new pairing
\(U_i\), with \(D_i\cup U_i=C_i\).

For \(S\subseteq\{0,\ldots,k-1\}\), restore \(U_i\) for \(i\in S\) and
\(D_i\) otherwise. Let \(\operatorname{Tar}(S)\) mean that the resulting
circuit partition has two circuits separating the root-marked
\(\alpha\)-paths. This is exactly \(J_\epsilon\)-acceptance.

Define:

> **Rooted gate-coordinate 2-accessibility (RG2A).** Every inclusion-minimal
> accepted set \(S\) containing a gate coordinate has \(|S|\le2\).

If WGE supplies any neutral target \(N\), apply RG2A to the components of
\(M\triangle N\); an inclusion-minimal accepted gate-containing subset gives
D1 or D2. Thus WGE plus brace-realizable RG2A is a sufficient two-part route
to D2. RG2A is stronger than necessary—D2 may use another transition cube—
but it is a concrete falsifiable condition, strictly thinner than an
unstructured joint-selector assertion.

## Complete three-C4 planar pairing theorem

Suppose \(k=3\) and all \(C_i\) are alternating four-cycles. Each coordinate
has four terminals and, after canonical relabelling,

\[
D_i=(01)(23),\qquad U_i=(12)(30).
\]

There are \((12-1)!!=10\,395\) labelled pairings \(\alpha\). Exhausting all
of them and all pairs of root-marked \(\alpha\)-paths gives

\[
9504\text{ connected skeletons},\quad
5728\text{ planar skeletons},\quad
2496\text{ rooted endpoint-target cases}.
\]

None has

\[
\operatorname{Tar}(000)=\operatorname{Tar}(111)=1
\]

while all gate-containing states \(100,101,110\) are rejected.

**Finite pairing theorem.** A plane rooted transition cube on three
alternating \(C_4\)'s cannot first reach a gate-changing target at distance
three.

Hence, if an actual D2 failure has some neutral target at minimum distance
three, at least one of the three difference cycles has length at least six.
Otherwise its minimum neutral distance is at least four.

## Sharp planar blocker at lengths (4,4,6)

The preceding boundary is sharp before brace realizability is imposed.
Take switch half-lengths \((2,2,3)\), old pairings

\[
\begin{aligned}
D_0&=(01)(23),&U_0&=(12)(30),\\
D_1&=(45)(67),&U_1&=(56)(74),\\
D_2&=(89)(10\,11)(12\,13),&
U_2&=(9\,10)(11\,12)(13\,8),
\end{aligned}
\]

and path pairing

\[
\alpha=(01)(24)(38)(5\,10)(6\,11)(7\,13)(9\,12).
\]

Mark paths \(01\) and \(9\,12\) as roots and coordinate 0 as gate-changing.
The transition multigraph is planar. Its rooted table is

\[
\begin{array}{c|rrrrrrrr}
S&000&001&010&011&100&101&110&111\\ \hline
\#\text{circuits}&2&2&3&3&1&1&2&2\\
\text{root separated}&1&1&1&1&0&0&0&1\\
\operatorname{Tar}(S)&1&1&0&0&0&0&0&1.
\end{array}
\]

Thus \(000\) has no neutral target at distance one or two, while \(111\) is
neutral at distance three; \(001\) is another double-gate target. This is a
strict planar terminal-pairing countermodel to RG2A.

Replacing \(\alpha\)-edges by internally disjoint plane paths allows their
parities to respect bipartite terminal colours. What is not supplied is a
cubic, 2-extendable completion whose full matching family adds no D1/D2
escape. Hence this is not an actual D2 counterexample. It proves exactly that
\(J_\epsilon\), root marking, and planarity alone do not prove D2. A positive
proof must use common brace incidence to exclude this \((4,4,6)\) blocker
and its higher-dimensional analogues.

## Actual selector route closure

Even in actual plane braces, minimum length cannot select the gate
coordinate. The verified graph6 is frozen exactly in
minimal_gate_cycle_selector_order24_20260826_codex/minimal_selector_order24.json.
It has wide \((5,5)\) arcs, primal gates \((0,14),(9,19)\), root
\((7,21)\), and target index 12. Among 56 \(M\)-alternating cycles, the
unique shortest root-avoiding gate-changing cycle has length eight. Its
single flip is not neutral and no disjoint cycle repairs it, although a
longer gate-cycle choice does give a D2 escape.

Therefore both arbitrary-cycle and shortest-cycle selectors fail in actual
braces. Any brace-level exclusion of the planar blocker must choose the gate
shore jointly with its mate; length and scalar defect do not select it.

## Boundary

- **Exact conclusion:** arbitrary-order D2-WGE is not proved or refuted.
  WGE plus brace-realizable RG2A would imply it, but pure rooted pairing and
  planarity cannot establish RG2A because the planar \((4,4,6)\) cube
  violates it. Independently, any actual minimum-distance-three failure must
  contain an alternating cycle of length at least six.
- **Weakest load-bearing argument:** the blocker has no verified cubic
  2-extendable completion. It closes the \(J_\epsilon\)+planarity route,
  not D2 itself.
- **Evidence level:** the three-\(C_4\) exclusion is an exact exhaustive
  finite pairing theorem; the \((4,4,6)\) blocker is an exact planar abstract
  countermodel; minimum-selector failure is an exact actual plane-brace
  witness.
- **Unresolved boundary:** whether brace realizability forbids every rooted
  gate-coordinate blocker; whether an actual failure first uses a \(C_6\)
  exchange or distance at least four; WGE and D2-WGE.

Reproduction:

    uv run --with 'networkx==3.6.1' \
      units/barnette/scratch/family_forced_gate_leaf_20260826_codex/search_planar_three_cycle_d2_obstruction.py \
      --sizes 2,2,2

    uv run --with 'networkx==3.6.1' \
      units/barnette/scratch/family_forced_gate_leaf_20260826_codex/search_planar_three_cycle_d2_obstruction.py \
      --sizes 2,2,3

    uv run --with 'networkx==3.6.1' \
      units/barnette/scratch/minimal_gate_cycle_selector_order24_20260826_codex/test_minimal_selector.py
