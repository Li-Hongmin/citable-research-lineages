#!/usr/bin/env python3
"""Focused verifier for an actual unrepairable chosen gate cycle."""

from __future__ import annotations

from itertools import product
import importlib.util
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
SEARCH = HERE / "find_unrepairable_gate_cycle_actual_order24.py"

SOURCE_GRAPH6 = "W???????????w?s?T?Ag?I_?T??T??I_?Ag??T??@W??B_?"
Z = 1
ROTATION = (2, 5, 7, 9, 11, 13, 12, 10, 8, 6, 3, 0)
GATE_INDICES = (0, 4)
ROOT = (4, 11)
TARGET_INDEX = 8
EXPECTED_MATCHING = frozenset(
    {
        (0, 14), (1, 13), (2, 12), (3, 15), (4, 16), (5, 17),
        (6, 18), (7, 19), (8, 22), (9, 21), (10, 20), (11, 23),
    }
)
CHOSEN_GATE_CYCLE = frozenset(
    {
        (0, 13), (0, 14), (1, 12), (1, 13),
        (2, 12), (2, 16), (4, 14), (4, 16),
    }
)


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


search = load_module(SEARCH, "unrepairable_gate_cycle_verifier_source")
source = search.source
lift = search.lift
edge = search.edge


def main():
    primal = nx.from_graph6_bytes(SOURCE_GRAPH6.encode())
    planar, embedding = nx.check_planarity(primal)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    primal_faces = source.source_bundle.plane_faces(primal, embedding)
    primal_brace = lift.verify_brace(primal)
    assert primal_brace["vertices"] == 24
    reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift.verify_reduced_triangulation(reduced)
    assert rotations[Z] == ROTATION
    expanded, locals_, left_arc, right_arc = lift.split_vertex(
        reduced, Z, ROTATION, *GATE_INDICES
    )
    assert (len(left_arc), len(right_arc)) == (5, 9)
    expanded_faces = lift.expanded_triangulation_faces(expanded)
    assert expanded_faces is not None
    expanded_dual = lift.dual_from_plane_graph(expanded, expanded_faces)
    expanded_brace = lift.verify_brace(expanded_dual)
    assert expanded_brace["vertices"] == 28

    dual_to_primal = source.primal_edge_by_dual_edge(primal, primal_faces)
    root = edge(*ROOT)
    primal_root = dual_to_primal[root]
    assert primal_root == (10, 20)
    gates = tuple(
        dual_to_primal[edge(Z, ROTATION[index])] for index in GATE_INDICES
    )
    assert gates == ((0, 14), (8, 22))

    family = lift.target_families(reduced, reduced_faces)[0][root]
    vertices = tuple(sorted(reduced))
    colours = tuple(lift.decode_colouring(vertices, item) for item in family)
    matchings = tuple(
        source.matching_from_colour(primal, reduced, dual_to_primal, colour)
        for colour in colours
    )
    base = matchings[TARGET_INDEX]
    assert base == EXPECTED_MATCHING
    assert set(gates) <= set(base)
    assert lift.is_target_profile(
        lift.rooted_profile(reduced, reduced_faces, colours[TARGET_INDEX], root)
    )

    fixed = {
        vertex: value for vertex, value in colours[TARGET_INDEX].items()
        if vertex != Z
    }
    lift_rows = []
    for bits in product((0, 1), repeat=3):
        lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
        if lift.is_target_profile(
            lift.rooted_profile(expanded, expanded_faces, lifted, root)
        ):
            lift_rows.append(bits)
    assert lift_rows == []

    ambient_matchings = tuple(search.perfect_matchings(primal))
    alternating_cycles = set()
    for matching in ambient_matchings:
        cycles = search.diff_cycles(base, matching)
        if len(cycles) == 1:
            alternating_cycles.add(cycles[0])
    assert CHOSEN_GATE_CYCLE in alternating_cycles
    chosen_vertices = search.vertices(CHOSEN_GATE_CYCLE)
    assert primal_root not in CHOSEN_GATE_CYCLE
    assert tuple(gate in CHOSEN_GATE_CYCLE for gate in gates) == (True, False)
    single = base ^ CHOSEN_GATE_CYCLE
    assert search.shape(primal, single, primal_root) == (3, False)

    chosen_partners = []
    repairable_other_gate_cycles = []
    gate_cycles = []
    for gate_cycle in alternating_cycles:
        if primal_root in gate_cycle or not any(gate in gate_cycle for gate in gates):
            continue
        one = base ^ gate_cycle
        if search.shape(primal, one, primal_root) == (2, True):
            continue
        partners = []
        for partner in alternating_cycles:
            if partner == gate_cycle or primal_root in partner:
                continue
            if search.vertices(gate_cycle) & search.vertices(partner):
                continue
            double = one ^ partner
            if sum(gate in double for gate in gates) <= 1 and search.shape(
                primal, double, primal_root
            ) == (2, True):
                partners.append(partner)
        gate_cycles.append((gate_cycle, partners))
        if gate_cycle == CHOSEN_GATE_CYCLE:
            chosen_partners = partners
        elif partners:
            repairable_other_gate_cycles.append((gate_cycle, partners))

    assert len(gate_cycles) >= 2
    assert chosen_partners == []
    assert len(repairable_other_gate_cycles) == 1
    assert len(repairable_other_gate_cycles[0][1]) >= 1

    neutral_targets = [
        index for index, matching in enumerate(matchings)
        if sum(gate in matching for gate in gates) <= 1
    ]
    assert neutral_targets
    print("ACTUAL_UNREPAIRABLE_CHOSEN_GATE_CYCLE_VERIFIED")
    print(f"PERFECT_MATCHINGS={len(ambient_matchings)}")
    print(f"ALTERNATING_CYCLES={len(alternating_cycles)}")
    print(f"NON_TARGET_GATE_CYCLES={len(gate_cycles)}")
    print(f"NEUTRAL_TARGETS={len(neutral_targets)}")


if __name__ == "__main__":
    main()
