# Complete-family forcing reduces to wide two-gate sites

## 1. 精确对象

固定 simple plane cubic bipartite brace (F')、dual Eulerian
triangulation (T'=F'^*)、dual vertex (z) 的 legal two-gate split、两个
gate neighbours (x_2,x_4)、对应 primal gates (g,h)，以及不经过 (z)
的 unchanged dual root (a=e^*)。两条 closed rotation arcs 记为

\[
A_1=(x_2,\ldots,x_4),\qquad A_3=(x_4,\ldots,x_2),
\]

其奇数 cardinalities 为 (ell_1,ell_3)。完整 rooted target family 是

\[
\mathcal T_e=\{M:e\in M,\ F'-M\text{ 是分离 }e\text{ 两端的两个圈}\}.
\]

本叶子的 family-level 前提是

\[
\mathcal T_e\ne\varnothing,
\qquad g,h\in M\quad(\forall M\in\mathcal T_e).
\tag{F}
\]

## 2. 短弧吸收引理

**引理。** 若 (min(\ell_1,\ell_3)=3)，则每个同时使用 (g,h) 的
(M\in\mathcal T_e) 都 liftable。这个结论不需要 complete-family forcing，
也不需要 exchange-component 假设。

**证明。** 不妨

\[
A_1=(x_2,y,x_4),\qquad \ell_1=3.
\]

令 (c) 是 (M) 的 normalized dual target colouring，(c(z)=0)。
由 (g,h\in M) 得 (c(x_2)=c(x_4)=0)。两个三角形
(zx_2y,z yx_4) 的 NAE 条件共同强制 (c(y)=1)，所以短弧颜色词必为
`010`，可以翻转短侧 split copy。

记左右 split copies 和新 centre 的 normalized colours 为
((\lambda,\rho,d))，其中 (lambda) 对应短弧。取 row

\[
(\lambda,\rho,d)=(1,0,1).
\tag{1}
\]

这是 Note 065 表中 \(p=q=0\) 的合法 row。令
\(R=H(c)-a\)。因为 \(c\) 是 target，\(R\) 是三分量森林，且 root 两端
在同一分量。所有与 \(z\) monochromatic 的边都通向 colour-0 neighbour；
短弧唯一内部点 \(y\) 是 colour 1，所以这些 colour-0 neighbours 全部属于
长弧 \(A_3\)。在 row (1) 中，保持 colour 0 的长侧 copy \(\rho\) 精确接管
\(z\) 的整个 monochromatic star。短侧 copy \(\lambda\) 只通过
\(y\lambda\) 接到旧图，而新 centre 只通过 \(\lambda d\) 接入。因此

\[
H(\widetilde c)-a
\]

就是把 \(R\) 中的 \(z\) 重命名为 \(\rho\)，再在 \(y\) 上挂一条新 pendant
path \(y-\lambda-d\)。它仍是三分量森林，旧 root path 完全不变。由
Note 065(5)，\(\widetilde c\) 是 target lift。另一短弧情形由对称 row
`011` 得证。\(\square\)

当 ((\ell_1,\ell_3)=(3,3)) 时还有更强的逐点结论：rows `011`、
`101`、`110` 全部 lift。前两行分别让一个 split copy 接管旧 (z)-star，
并在另一侧挂 pendant 2-path；`110` 让 centre 接管旧 star，并在两个异色
neighbours 上各挂一个新叶。三者都保持 rooted three-forest。

## 3. 对一般 family 命题的严格归约

合法 split 的 (ell_1,ell_3) 都是奇数，并且

\[
\ell_1+\ell_3=\deg_{T'}(z)+2.
\]

短弧吸收引理立即给出：任何满足 (F) 却没有 liftable target 的真实反例都必须
满足

\[
\boxed{\ell_1,\ell_3\ge5,\qquad \deg_{T'}(z)\ge8.}
\tag{W}
\]

因此四边形面和六边形面全部解析关闭；更一般地，即使面很长，只要 gates
在 rotation 上相隔一个 neighbour，也逐点关闭。首个真正非局部接口是八边形
面的 ((5,5)) gate pair。

由此得到一个只涉及 parent complete family、且足以关闭原命题的更薄不变量：

\[
\tag{WGE}
\ell_1,\ell_3\ge5, \mathcal T_e\ne\varnothing
\quad\Longrightarrow\quad
\exists M\in\mathcal T_e:\ |M\cap\{g,h\}|\le1.
\]

WGE 不再引用 expanded graph、八个 local rows、rooted quotient 或 target-state
components。若 WGE 成立，Note 071 的 neutral-gate lemma 立即给 lift；所以
它是下一轮应直接证明或寻找真实反例的 pure-parent gate-load invariant。
WGE 比原 family-level lifting 命题更强：一个 wide forced family 即使存在，
仍可能由 nonneutral row lift，因此不能把 WGE 的反例误报为 lifting 反例。

精确等价的剩余 lifting 命题则是把原量词限制到 (W) 的 wide sites；短弧 sites
已由上面的引理逐点证明。

## 4. order-24 坏分量怎样跨 component 逃逸

首个 order-24 component-saturation 反例正位于
((\ell_1,\ell_3)=(5,5))。其完整 family 有三个 (C_4) target-state
components，gate counts 为

\[
(2,2,1,1),\qquad(2,2,2,2),\qquad(2,1,1,2).
\]

中间 component 的四个 targets 全坏，但完整 family 的 indices
(2,3,7,8) 各使用一条 gate，并由 neutral row `001` lift。对每一个中间
坏 target，都存在一个 neutral target，使两 matching 的 symmetric difference
恰含两个 alternating cycles：一个 cycle 改变第二道 gate，另一个完全避开
两 gates。单独翻任一 cycle 得到的 perfect matching 都不是 target；两圈同步
翻转才回到 (mathcal T_e)。这说明所需耦合真实跨越 Note 074 的单圈 components，
但仍精确命中 WGE 的 gate-load escape。

## 5. 有限证据与路线裁决

对完整 through-order-22 corpus 的窄重算，以及 order-24 complete-family census
冻结的 18 个 braces，双 gate 完整-family forcing 的 face-length 支撑为

\[
\begin{array}{c|rrrrrrr}
|V(F')|&8&12&16&18&20&22&24\\ \hline
\#\text{ forced families}&24&24&60&6&136&30&408
\end{array}
\]

合计 688 个 forced families，全部发生在 face length 4，即
((\ell_1,\ell_3)=(3,3))；wide-site forced family 数为 0。order 24 的
408 families 含 1,864 targets，全部由 `011`,`101`,`110` 三行逐点提升。
这批三行成功并不是尚未解释的全局 monodromy：它完全由四边形的局部
tree-replacement 引理解释。当前数据对真正的 wide premise (W) 没有一个正例，
因此继续统计 forced components 不会检验 family-level 核心。

下一次最便宜、会改变证明方向的观测是：只在 order 26 的 actual braces 上搜索
首个满足 (W) 且 complete family 双 gate forced 的接口；一旦找到，先判它是否
仍由 nonneutral row lift。若仍找不到，应直接从 rooted spanning two-path-cover
family 证明 WGE，而不是继续 component saturation。

## 6. 证据边界

- **精确结论：** 短弧吸收引理及归约 (W) 为任意阶证明级；WGE 是尚未证明的
  更薄充分不变量。through 24 的 688-family face-length 支撑和 order-24
  1,864 个逐点 profiles 是精确 computer-assisted finite evidence。
- **最薄弱论证：** 任意阶部分只关闭 (min(\ell_1,\ell_3)=3)；从 brace
  incidence 推出 wide-site gate escape 仍无证明。有限范围依赖上游完整
  graph6 生成与 brace 筛选，本叶只重建冻结列表及既有 through-22 corpus。
- **证据等级：** short-arc lemma = proof-level；through-24 support = exact
  finite theorem；WGE = conjectural interface。
- **未解决边界：** 是否存在 order 26+ 的 actual wide forced family；若存在，
  它是否含 nonneutral lift；一般 WGE 或 weaker wide-site acceptance theorem。

复核脚本：

- `analyze_order24_family.py`：首个 order-24 坏 family 的完整 exchange cubes；
- `analyze_one_order24_brace_families.py`：该 brace 的全部 family premises；
- `check_forced_family_face_lengths_through22.py`：实际执行范围已扩至 through 24，
  统计 forced-family face-length 支撑。
