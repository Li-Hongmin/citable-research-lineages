#!/usr/bin/env python3
"""Enumerate gate-changing alternating cycles and disjoint repair partners.

The scope is one fixed bad target (family index 4) in the frozen order-24
(5,5) interface.  This is not an order census.
"""

from __future__ import annotations

from collections import defaultdict
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
ANALYZER = HERE / "analyze_order24_family.py"
CERTIFICATE = HERE.parent / "target_component_saturation_order24_20260826" / "forced_target_components_order24.json"


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


source = load_module(ANALYZER, "gate_cycle_repair_source")
lift = source.lift
edge = source.edge


def perfect_matchings(graph: nx.Graph):
    neighbours = {vertex: tuple(sorted(graph[vertex])) for vertex in graph}

    def visit(unmatched: frozenset[int], chosen: tuple[tuple[int, int], ...]):
        if not unmatched:
            yield frozenset(chosen)
            return
        vertex = min(unmatched)
        for neighbour in neighbours[vertex]:
            if neighbour not in unmatched:
                continue
            yield from visit(
                unmatched - {vertex, neighbour},
                chosen + (edge(vertex, neighbour),),
            )

    yield from visit(frozenset(graph), ())


def cycle_vertices(cycle):
    return frozenset(vertex for item in cycle for vertex in item)


def main():
    failure = json.loads(CERTIFICATE.read_text())["first_failure"]
    primal = nx.from_graph6_bytes(failure["source_graph6"].encode())
    primal_faces = tuple(tuple(face) for face in failure["source_primal_faces"])
    reduced, _ = lift.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift.verify_reduced_triangulation(reduced)
    dual_to_primal = source.order24.primal_edge_by_dual_edge(primal, primal_faces)
    root = edge(*failure["dual_root"])
    primal_root = edge(*failure["primal_root"])
    family = lift.target_families(reduced, reduced_faces)[0][root]
    vertices = tuple(sorted(reduced))
    colours = tuple(lift.decode_colouring(vertices, item) for item in family)
    matchings = tuple(
        source.order24.matching_from_colour(primal, reduced, dual_to_primal, colour)
        for colour in colours
    )
    base = matchings[4]
    gates = tuple(edge(*item) for item in failure["site"]["primal_gate_edges"])
    assert set(gates) <= set(base)

    all_matchings = tuple(perfect_matchings(primal))
    alternating_cycles = set()
    for matching in all_matchings:
        cycles = source.diff_cycles(base, matching)
        if len(cycles) == 1:
            alternating_cycles.add(cycles[0])
    alternating_cycles = tuple(sorted(alternating_cycles, key=lambda one: (len(one), sorted(one))))
    target_by_matching = {matching: index for index, matching in enumerate(matchings)}

    records = []
    for index, gate_cycle in enumerate(alternating_cycles):
        gate_mask = tuple(gate in gate_cycle for gate in gates)
        if gate_mask != (False, True) or primal_root in gate_cycle:
            continue
        single = base ^ gate_cycle
        single_shape = source.target_shape(primal, single, primal_root)
        partners = []
        for partner_index, partner in enumerate(alternating_cycles):
            if partner_index == index or primal_root in partner:
                continue
            if cycle_vertices(gate_cycle) & cycle_vertices(partner):
                continue
            double = single ^ partner
            shape = source.target_shape(primal, double, primal_root)
            if shape != (2, True):
                continue
            partners.append({
                "cycle_index": partner_index,
                "length": len(partner),
                "gate_mask": [gate in partner for gate in gates],
                "target_index": target_by_matching.get(double),
                "edges": sorted(partner),
            })
        records.append({
            "cycle_index": index,
            "length": len(gate_cycle),
            "edges": sorted(gate_cycle),
            "single_complement_cycles": single_shape[0],
            "single_root_separated": single_shape[1],
            "repair_partner_count": len(partners),
            "repair_partners": partners,
        })

    histogram = defaultdict(int)
    for record in records:
        key = (
            record["length"],
            record["single_complement_cycles"],
            record["single_root_separated"],
            record["repair_partner_count"],
        )
        histogram[str(key)] += 1
    print(json.dumps({
        "base_target_index": 4,
        "perfect_matching_count": len(all_matchings),
        "alternating_cycle_count": len(alternating_cycles),
        "gate_changing_cycle_count": len(records),
        "gate_cycle_histogram": dict(sorted(histogram.items())),
        "gate_cycles": records,
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
