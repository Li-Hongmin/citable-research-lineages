# RCA is an edgewise two-cycle minimum, not a guaranteed one-flip descent

Let \(F\) be a simple plane cubic bipartite brace, let \(e=rs\), and let

\[
\mathcal S_e=\{M:\ M\text{ is a perfect matching},\ e\in M,\ 
r,s\text{ lie on distinct cycles of }F-M\}.
\]

Note 058 proves \(\mathcal S_e\ne\varnothing\). For \(M\in\mathcal S_e\),
write \(D_M=F-M\) and let \(c(D_M)\) be its number of cycles.

## 1. Exact global reduction

Define

\[
\mu_F(e)=\min_{M\in\mathcal S_e}c(D_M).
\tag{1}
\]

Then RCA for the fixed pair \((F,e)\) is equivalent to

\[
\mu_F(e)=2.
\tag{2}
\]

Indeed, if (2) holds, choose a minimizer \(M_*\). For every separated
factor \(D\) with more than two cycles, \(D_*=F-M_*\) has the same two root
invariants and fewer cycles, so it is the required \(D'\). Conversely, if
RCA holds, start from any element of the nonempty finite set
\(\mathcal S_e\) and repeatedly reduce the positive integer \(c(D)\).
The process terminates at two cycles; it cannot terminate at one because
the root vertices remain separated.

Thus universal RCA is exactly the endpoint-separating two-cycle condition
(T) of Note 057 for every edge. The statement of RCA does not require
\(D'\) to be obtained from \(D\) by one alternating flip, so a local
descent theorem would be a sufficient strengthening, not an equivalent
formulation.

## 2. Exact effect of one alternating flip

Fix \(M\in\mathcal S_e\), put \(D=F-M\), and let \(A\) be an
\(M\)-alternating cycle such that \(e\notin A\). Then

\[
M'=M\triangle E(A),\qquad D'=D\triangle E(A).
\tag{3}
\]

Since \(e\) is the unique \(M\)-edge at each of \(r,s\), an alternating
cycle avoiding \(e\) also avoids the vertices \(r,s\).

Put

\[
S=E(A)\cap E(D)
\]

and let \(p\) be the number of cycles of \(D\) meeting \(S\). Cutting the
edges \(S\) turns the affected old cycles into \(|S|\) path segments. On
the \(2|S|\) segment endpoints there are two perfect pairings:

- \(\alpha\) joins the two ends of each path segment of \(D-S\);
- \(\beta\) joins endpoints by the new edges \(E(A)\cap M\).

Let

\[
q=\operatorname{comp}(\alpha\cup\beta),
\tag{4}
\]

the number of alternating polygon components formed by these two pairings.
These are exactly the affected cycles of \(D'\). Therefore

\[
c(D')=c(D)-p+q.
\tag{5}
\]

If an affected old cycle is a root cycle, mark the unique path segment of
\(D-S\) containing that root. The root-separation invariant survives
exactly when the \(r\)-marked and \(s\)-marked segments belong to different
components of \(\alpha\cup\beta\), with an untouched root cycle treated as
its own marked component.

Equation (5), plus this marked-component test, is a complete one-flip
criterion. In particular, the undecorated cycle quotient is insufficient.
Projecting \(A\) only records which old cycles it visits; it does not record
the cyclic order of the cut edges on those cycles. That order is the
pairing \(\alpha\), and different \(\alpha\)'s with the same projected
closed walk can make a flip merge, preserve, or split cycles.

## 3. A sharp sufficient local move

Call \(A\) transversal if it meets each affected cycle of \(D\) in exactly
one \(D\)-edge. Equivalently, its projection to the cycle quotient visits
each of its \(p\) vertices exactly once. Then

\[
q=1,
\]

so the \(p\) affected cycles merge into one and

\[
c(D')=c(D)-(p-1).
\tag{6}
\]

For a simple graph \(p\ge2\). If a transversal alternating cycle does not
meet both root cycles, (6) is a strict RCA move preserving \(e\) and root
separation.

Consequently, a minimum counterexample \((F,e,M)\), chosen with
\(c(F-M)=\mu_F(e)\ge3\), has no such transversal alternating cycle.
More generally it satisfies the exact obstruction

\[
q\ge p
\tag{7}
\]

for every \(M\)-alternating cycle avoiding \(e\) whose marked endpoint
pairing preserves root separation.

For a disjoint union of alternating cycles, the same construction applies
with \(S\) equal to all removed \(D\)-edges. A genuine counterexample must
satisfy (7) for every such alternating union that preserves the two root
marks. Restricting attention to single flips is therefore not enough to
prove or refute RCA.

## 4. Cycle quotient and the remaining structural condition

Contract every cycle of \(D\) to obtain the matching quotient \(Q_D\).
Each \(M\)-edge becomes an edge of \(Q_D\), possibly a loop. The root edge
\(e\) is a non-loop between the two marked root vertices. Since \(F\) is
connected, the non-loop part of \(Q_D\) is connected.

An alternating cycle projects to a closed walk in \(Q_D\), but it comes
with a transition at each visited quotient vertex: the two incident
matching half-edges must attach to endpoints of one common \(D\)-edge.
The complementary order of all such cuts around the old \(D\)-cycle is
precisely \(\alpha\). Hence RCA reduces to the following decorated
transition statement:

> For every separated factor with at least three quotient vertices, some
> union of compatible closed walks has \(q<p\) and leaves the two marked
> root segments in different \(\alpha\cup\beta\) components.

Brace connectivity and planarity constrain \(Q_D\), but the bare quotient
does not contain the transition data needed to prove this statement. A
proof must use the cyclic attachment order on every old factor cycle, or
an equivalent primal/dual incidence structure.

## 5. One fixed-graph diagnostic

The frozen order-26 plane brace from the preceding fixed-fibre work was
checked exactly, without an order census. All 253 perfect matchings were
enumerated. For each of its 39 edges \(e\), the exact value in (1) is

\[
\mu_F(e)=2.
\]

Thus it is not an RCA counterexample. This is finite positive evidence
only. The witnesses and solver-free graph/factor checks are stored in
**order26_rca_result.json**; the reproduction entry is
**check_order26_rca.py**.

## Boundary

RCA is not proved or refuted here. It is strictly reduced to the universal
two-cycle minimum (2), and a minimum counterexample is forced to satisfy
the decorated no-decrease condition (7) for every root-preserving
alternating union. The weakest interface is now the existence of a
compatible closed-walk union with favorable endpoint pairing \(q<p\);
neither brace expansion nor planarity alone has yet been shown to force it.
