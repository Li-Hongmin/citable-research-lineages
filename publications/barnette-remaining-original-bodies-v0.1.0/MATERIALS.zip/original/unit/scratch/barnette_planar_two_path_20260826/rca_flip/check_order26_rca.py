#!/usr/bin/env python3
"""Exact RCA diagnostic on the frozen order-26 plane brace.

For each edge e, compute the minimum number of cycles in F-M over perfect
matchings M containing e whose complementary 2-factor separates the
endpoints of e.  RCA on this fixed graph is equivalent to every minimum
being two.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
IS_DIR = HERE.parent / "is_matching_cut"
sys.path.insert(0, str(IS_DIR))
from check_order26_is import GRAPH6, complement_cycle_labels, edge, verify_graph  # noqa: E402


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    verify_graph(graph)
    all_edges = tuple(sorted(edge(u, v) for u, v in graph.edges()))
    minimum = {e: None for e in all_edges}
    witnesses: dict[tuple[int, int], tuple[tuple[int, int], ...]] = {}
    matching_count = 0

    neighbours = {v: tuple(sorted(graph[v])) for v in graph}
    current: list[tuple[int, int]] = []

    def visit(unmatched: int) -> None:
        nonlocal matching_count
        if not unmatched:
            matching_count += 1
            matching = frozenset(current)
            labels = complement_cycle_labels(graph, matching)
            cycle_count = len(set(labels.values()))
            for e in matching:
                if labels[e[0]] == labels[e[1]]:
                    continue
                if minimum[e] is None or cycle_count < minimum[e]:
                    minimum[e] = cycle_count
                    witnesses[e] = tuple(sorted(matching))
            return

        choices = []
        bits = unmatched
        while bits:
            low = bits & -bits
            u = low.bit_length() - 1
            available = tuple(v for v in neighbours[u] if unmatched & (1 << v))
            if not available:
                return
            choices.append((len(available), u, available))
            bits ^= low
        _, u, available = min(choices)
        for v in available:
            current.append(edge(u, v))
            visit(unmatched & ~(1 << u) & ~(1 << v))
            current.pop()

    visit((1 << len(graph)) - 1)
    assert all(value is not None for value in minimum.values())

    for e, witness in witnesses.items():
        labels = complement_cycle_labels(graph, frozenset(witness))
        assert e in witness
        assert labels[e[0]] != labels[e[1]]
        assert len(set(labels.values())) == minimum[e]

    result = {
        "graph6": GRAPH6,
        "vertices": len(graph),
        "edges": len(all_edges),
        "perfect_matchings": matching_count,
        "minimum_separated_cycle_count": {
            f"{e[0]}-{e[1]}": minimum[e] for e in all_edges
        },
        "minimum_histogram": {
            str(value): sum(1 for item in minimum.values() if item == value)
            for value in sorted(set(minimum.values()))
        },
        "rca_holds_on_graph": all(value == 2 for value in minimum.values()),
        "witnesses": {
            f"{e[0]}-{e[1]}": [list(pair) for pair in witnesses[e]]
            for e in all_edges
        },
    }
    (HERE / "order26_rca_result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    print(
        json.dumps(
            {key: value for key, value in result.items() if key != "witnesses"},
            indent=2,
            sort_keys=True,
        )
    )
    print("ORDER26_RCA_CHECK_COMPLETE")


if __name__ == "__main__":
    main()
