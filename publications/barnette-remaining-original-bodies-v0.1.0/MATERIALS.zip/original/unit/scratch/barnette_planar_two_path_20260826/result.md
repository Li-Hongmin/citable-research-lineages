# Planar fixed-fibre two-path covers: exact interfaces and the Diwan barrier

Let \(F\) be a simple plane cubic bipartite brace with bipartition
\(X\sqcup Y\), where \(|X|=|Y|=n\). Fix \(r\in Y\), write

\[
N_F(r)=\{a,b,s\},\qquad P=F-r,
\]

and consider the fixed fibre in which \(a,b\) are paired and \(s\) is the
singleton port. The unresolved assertion is

\[
\tag{A}
P\text{ has two vertex-disjoint paths }Q_{ab},Q_{sy}
\text{ whose union spans }P,
\]

where \(y\in Y\setminus\{r\}\) is free. This analysis does not prove or
refute (A). It gives exact linkage, planar-dual and 2-factor formulations,
and closes the proposed direct use of Diwan's Theorem 5.

## 1. Spanning-linkage and artificial-closure formulations

Condition (A) is exactly a one-free-end spanning 2-linkage:

\[
\tag{1}
\exists y\in Y\setminus\{r\}:\quad
\{Q_{ab},Q_{sy}\}\text{ is a spanning }(\{a,b\},\{s,y\})
\text{-linkage of }P.
\]

Choose an order on the paired ports and add a labelled artificial edge
\(bs\). Then (A) is equivalently the existence of \(y\) and a Hamilton
\(a\)-to-\(y\) path in \(P+bs\) which traverses the artificial edge in the
order

\[
\tag{2}
a\leadsto b-bs-s\leadsto y.
\]

Deleting \(bs\) proves the reverse implication. Merely requiring a Hamilton
path containing \(bs\), without the displayed order, is not equivalent:
the opposite order induces the wrong port partition.

For fixed \(y\), add labelled artificial edges \(ab\) and \(sy\), allowing
the latter to be a labelled parallel copy when \(sy\in E(P)\). Then (A),
with endpoint \(y\), is equivalent to a spanning 2-factor of

\[
\tag{3}
P+ab+sy
\]

having exactly two cycles, with the two artificial edges on different
cycles. Alternatively, adding \(bs\) and \(ya\) closes the paths into a
Hamilton cycle with a prescribed cyclic order. These closure graphs are
generally neither cubic nor bipartite, and the variable closing edge need
not be planar. Thus this exact 2-factor formulation lies outside Diwan's
hypotheses.

## 2. Exact planar-dual formulation

For a candidate \(J=Q_{ab}\cup Q_{sy}\), put

\[
K=E(P)\setminus E(J).
\]

Every \(x\in X\) has \(\deg_K(x)=1\). Every
\(z\in Y\setminus\{r,y\}\) has \(\deg_K(z)=1\), while
\(\deg_K(y)=2\).

Let \(P^*\) be the plane dual and \(K^*=\{e^*:e\in K\}\). Since

\[
|V(P)|=2n-1,\qquad |E(P)|=3n-3,\qquad |V(P^*)|=n,
\]

condition (A) is equivalent to all four of the following:

1. \(K^*\) is a connected spanning unicyclic subgraph of \(P^*\).
2. On the boundary of every dual face corresponding to an \(X\)-vertex,
   \(K^*\) uses exactly one edge.
3. On the boundary of every dual face corresponding to a
   \(Y\setminus\{r\}\)-vertex, it uses exactly one edge except at one face
   \(f_y\), where it uses exactly two.
4. The unique cycle of \(K^*\) is dual to a bond whose shores induce the
   port split \(\{s\}\mid\{a,b\}\).

Indeed, plane duality says that \(J\) is acyclic iff \(K^*\) is connected.
The face-incidence conditions give \(|K|=n\), hence

\[
|J|=(3n-3)-n=2n-3=|V(P)|-2.
\]

Thus \(J\) is a spanning forest with two components and \(K^*\), with \(n\)
vertices and \(n\) edges, is unicyclic. The cut between the two connected
components of \(J\) is a bond; all its edges lie in \(K\), so its dual is
the unique cycle of \(K^*\). Conversely, the same argument recovers the
two-component forest. The face incidences then give degree two at every
internal vertex of \(J\), with endpoints \(a,b,s,y\), so its two trees are
the paths in (A).

The dual target is therefore a near-perfect primal incidence object that
is simultaneously a face-constrained connected unicycle in the dual.

## 3. Exactly when a two-path cover closes inside \(F\)

The relation with ordinary 2-factors of \(F\) has one sharp extra condition.
For an (A)-witness \(J\), let \(y\) be its free endpoint and again put
\(K=E(P)\setminus J\). Then

\[
\tag{4}
J\text{ can be completed directly to a 2-factor of }F
\quad\Longleftrightarrow\quad
N_K(y)\cap\{a,b,s\}\ne\varnothing.
\]

Choose \(x\in N_K(y)\cap\{a,b,s\}\). Then

\[
\tag{5}
M_x=(K\setminus\{xy\})\cup\{rx\}
\]

is a perfect matching of \(F\), whose complementary 2-factor is

\[
\tag{6}
D_x=J\cup\{xy\}\cup\{rt:t\in\{a,b,s\}\setminus\{x\}\}.
\]

There are exactly two cases.

- If \(x=s\), then \(D_s\) has exactly two cycles. One contains \(r\) and
  uses \(ra,rb\); the other contains \(s\) and \(sy\). In particular,
  \(r,s\) lie on different cycles.
- If \(x=a\) or \(x=b\), then \(D_x\) is a Hamilton cycle. It contains
  \(rs\) and the root edge to the other paired port, while avoiding \(rx\).

The two paths show sufficiency immediately: the three added edges in (6)
either close them separately or join them cyclically. Conversely, deleting
the three closing edges from a factor of either stated form recovers (A).

Necessity in (4) follows from the degree deficits of \(J\), which occur only
at \(a,b,s,y,r\). A 2-factor completion containing all of \(J\) must choose
two root edges at \(r\); its third new edge must join the remaining port to
\(y\). Thus a general (A)-witness need not admit a direct 2-factor completion
inside \(F\).

Two sufficient conditions are now exact:

**(T) Endpoint-separating two-cycle factor.** There is a 2-factor with
exactly two cycles, its root cycle uses \(ra,rb\), and \(r,s\) lie on
different cycles. Deleting \(r\) from the first cycle and one cycle edge
incident with \(s\) from the second gives (A). The separation clause is
essential: \(ra,rb\) on the root cycle does not prevent \(s\) from lying on
that same cycle.

**(H) Prescribed-edge Hamilton factor.** There is a Hamilton cycle containing
\(rs\). It uses \(rs\) and one of \(ra,rb\), say \(ra\). After deleting
\(r\), the result is a Hamilton path from \(s\) to \(a\) containing \(b\)
internally. Delete from this path the edge incident with \(b\) on the
\(s\)-side. The resulting paths pair \(a,b\) and leave \(s\) in the other
component. A Hamilton cycle using \(ra,rb\) but not \(rs\) does not give this
conclusion by the same cut.

Consequently, using (H) for every fixed fibre would require every edge of a
Barnette graph to lie on a Hamilton cycle, a prescribed-edge strengthening
of Barnette's conjecture.

## 4. What Diwan's Theorem 5 supplies

The local PDF of A. A. Diwan, *Chords of 2-Factors in Planar Cubic
Bridgeless Graphs*, arXiv:2110.12584, states in Theorem 5:

> If \(G\) is a connected planar cubic bipartite graph and \(e_1,e_2\) are
> any two edges, some 2-factor contains both edges on the same cycle.

The proof on printed pages 13--14 proceeds by induction through 2-edge cuts
and then removes a facial 4-cycle. It does not retain earlier specified
edges beyond the current pair and does not control the total number of
cycles.

For the fixed-fibre problem, the direct invocation is vacuous. To force the
root state in (T), one must prescribe \(ra,rb\). These edges are adjacent,
so whenever a 2-factor contains both they automatically lie on the same
cycle. Their existence in one 2-factor already follows without planarity:
\(rs\) belongs to a perfect matching of the regular bipartite graph \(F\),
and its complement contains \(ra,rb\). The same applies to the adjacent
root-edge pair used in (H). Thus Theorem 5 gives no information here beyond
bipartite 1-factorization.

The exact missing absorption statement is:

**(RCA) Root-preserving cycle absorption.** If a 2-factor \(D\) has \(rs\)
in its complementary matching, has \(r,s\) on distinct cycles, and has more
than two cycles, then there is another 2-factor \(D'\) with the same two
invariants and fewer cycles.

Repeated (RCA) would yield (T). Diwan's two edge slots are already consumed
by \(ra,rb\) if the fixed root state is forced. If instead one chooses edges
from two cycles one hopes to merge, the new 2-factor need not keep \(ra,rb\),
need not keep \(r,s\) separated, and need not have fewer cycles. There is no
inductive potential.

This is a strict limitation of the theorem's conclusion. Let \(U\) be a
12-element set and let the admissible “cycle partitions” be all partitions
of \(U\) into three 4-element blocks. Every pair lies in a common block of
some admissible partition, but every admissible partition has exactly three
blocks. Hence the assertion schema

\[
\forall e_1,e_2\ \exists D:\quad
e_1,e_2\text{ are co-cyclic in }D
\]

does not imply a factor with at most two cycles, let alone (RCA). This is a
logical interface separator, not a graph-realizability counterexample.

Reducing the cycle count all the way to one while keeping a specified edge
in the complementary matching asks for a Hamilton cycle avoiding that edge;
its universal version is stronger than Barnette's existential Hamiltonicity.
The two-cycle statement (RCA) is a different, weaker-looking but still
global 2-factor minimization problem. No equivalence between (RCA) and
Barnette's conjecture is established here.

## 5. Route verdict and remaining boundary

Theorem 5 cannot, as a black-box pairwise co-cyclicity statement, be
cycle-merged into (A). The precise missing statement is (RCA), together
with existence of an initial 2-factor having the root state and separating
\(r\) from \(s\); alternatively one must prove the stronger Hamilton
condition (H). A distinct route is to construct directly the
face-constrained connected unicycle \(K^*\).

The weakest part of this conclusion is its scope: it closes only deductions
using the conclusion of Diwan's Theorem 5 as the cycle-merging engine. It
does not rule out a strengthening of Diwan's induction that preserves a
root state and a decreasing cycle potential.

**Evidence level.** The equivalences above are analytic and exact. The
literature claim was checked against the complete statement and proof of
Theorem 5 in the local PDF. The negative result is a strict black-box
interface closure, not a proof or counterexample to planar (A).

**Unresolved boundary.** It remains open here whether every simple planar
cubic bipartite brace satisfies (A), whether condition (T) always holds, or
whether every fixed fibre admits the dual unicycle of Section 2.
