#!/usr/bin/env python3
"""Exact fixed-graph check of the initial-separation property (IS).

This is only a route diagnostic on the frozen order-26 plane brace. It
streams perfect matchings and records, for each edge e=rs, whether some
matching containing e has its endpoints on different cycles of the
complementary 2-factor.
"""

from __future__ import annotations

import json
from itertools import combinations
from pathlib import Path

import networkx as nx


GRAPH6 = (
    "Y?????????S?s?b??[?CoI_?L??_o?"
    + "\x60"
    + "_@?G?@W????@C??@?@?@O??A_"
)
HERE = Path(__file__).resolve().parent


def edge(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


def verify_graph(graph: nx.Graph) -> None:
    assert len(graph) == 26
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    assert all(degree == 3 for _, degree in graph.degree())
    colour = nx.bipartite.color(graph)
    sides = (
        tuple(sorted(v for v in graph if colour[v] == 0)),
        tuple(sorted(v for v in graph if colour[v] == 1)),
    )
    assert len(sides[0]) == len(sides[1])
    for side in sides:
        for size in range(1, len(side) - 1):
            for shore in combinations(side, size):
                neighbours = set().union(*(set(graph[v]) for v in shore))
                assert len(neighbours) >= size + 2


def complement_cycle_labels(
    graph: nx.Graph, matching: frozenset[tuple[int, int]]
) -> dict[int, int]:
    complement = nx.Graph()
    complement.add_nodes_from(graph)
    complement.add_edges_from(
        e for e in map(lambda uv: edge(*uv), graph.edges()) if e not in matching
    )
    assert all(degree == 2 for _, degree in complement.degree())
    labels: dict[int, int] = {}
    for index, component in enumerate(nx.connected_components(complement)):
        for vertex in component:
            labels[vertex] = index
    return labels


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    verify_graph(graph)
    all_edges = tuple(sorted(edge(u, v) for u, v in graph.edges()))
    success: dict[tuple[int, int], tuple[tuple[int, int], ...]] = {}
    matching_count = 0

    neighbours = {v: tuple(sorted(graph[v])) for v in graph}
    full_mask = (1 << len(graph)) - 1
    current: list[tuple[int, int]] = []

    def visit(unmatched: int) -> bool:
        nonlocal matching_count
        if not unmatched:
            matching_count += 1
            matching = frozenset(current)
            labels = complement_cycle_labels(graph, matching)
            for e in matching:
                if e not in success and labels[e[0]] != labels[e[1]]:
                    success[e] = tuple(sorted(matching))
            return len(success) == len(all_edges)

        candidates_by_vertex = []
        bits = unmatched
        while bits:
            low = bits & -bits
            u = low.bit_length() - 1
            available = tuple(v for v in neighbours[u] if unmatched & (1 << v))
            if not available:
                return False
            candidates_by_vertex.append((len(available), u, available))
            bits ^= low
        _, u, available = min(candidates_by_vertex)
        for v in available:
            current.append(edge(u, v))
            if visit(unmatched & ~(1 << u) & ~(1 << v)):
                return True
            current.pop()
        return False

    stopped_early = visit(full_mask)
    missing = tuple(e for e in all_edges if e not in success)

    # Solver-free recheck of every retained witness.
    for e, witness in success.items():
        covered = [vertex for pair in witness for vertex in pair]
        assert len(witness) == len(graph) // 2
        assert len(set(covered)) == len(graph)
        assert e in witness
        labels = complement_cycle_labels(graph, frozenset(witness))
        assert labels[e[0]] != labels[e[1]]

    result = {
        "graph6": GRAPH6,
        "vertices": len(graph),
        "edges": len(all_edges),
        "perfect_matchings_visited": matching_count,
        "stopped_early": stopped_early,
        "successful_edges": len(success),
        "missing_edges": [list(e) for e in missing],
        "witnesses": {
            f"{e[0]}-{e[1]}": [list(pair) for pair in witness]
            for e, witness in sorted(success.items())
        },
    }
    (HERE / "order26_is_result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps({k: result[k] for k in result if k != "witnesses"}, indent=2))
    print("ORDER26_IS_CHECK_COMPLETE")


if __name__ == "__main__":
    main()
