#!/usr/bin/env python3
"""Classify the only one-presplit surgeries that can kill both Note 116 escapes.

This is deliberately not a site/label census.  The root, surviving gate,
final split, and the three displayed Note 116 targets are fixed.  We first
use canonical split persistence to retain only local sites at which either

    chi is in state 11, or both lambda and mu are in state 11.

Only such a site can possibly destroy both canonical single-cycle
neighbour relations chi--lambda and chi--mu.  We then test the two legal
survivors of that local CSP and the prescribed final split.
"""

from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations
from pathlib import Path


BASE_PATH = (
    Path(__file__).resolve().parents[1]
    / "worker-actual-occupancy-countermodel"
    / "audit_fixed_two_preprocessing_splits.py"
)
SPEC = spec_from_file_location("note116_base", BASE_PATH)
assert SPEC and SPEC.loader
base = module_from_spec(SPEC)
SPEC.loader.exec_module(base)


ETA = base.original_target("100010010111")
LABELLED_INTERFACES = (
    base.ROOT,
    base.GATE,
    base.edge("w", "r2"),
    base.edge("w", "r6"),
)


def link_cycle(centre, vertices, edges, tris):
    neighbours = {
        next(iter(set(e) - {centre}))
        for e in edges
        if centre in e
    }
    adjacency = {v: set() for v in neighbours}
    for tri in tris:
        if centre in tri:
            u, v = (x for x in tri if x != centre)
            adjacency[u].add(v)
            adjacency[v].add(u)
    assert all(len(adjacency[v]) == 2 for v in neighbours)
    start = min(neighbours)
    cycle = [start]
    previous = None
    current = start
    while True:
        choices = adjacency[current] - ({previous} if previous is not None else set())
        if len(cycle) == 1:
            nxt = min(choices)
        else:
            nxt = next(
                x for x in choices
                if x != start or len(cycle) == len(neighbours)
            )
        if nxt == start:
            break
        cycle.append(nxt)
        previous, current = current, nxt
    assert len(cycle) == len(neighbours)
    return tuple(cycle)


def closed_paths(cycle, p, q):
    i, j = sorted((cycle.index(p), cycle.index(q)))
    return cycle[i : j + 1], cycle[j:] + cycle[: i + 1]


def cobound_triangle(first, second, tris):
    return any(
        set(first) <= set(tri) and set(second) <= set(tri)
        for tri in tris
    )


def local_state11(colouring, centre, p, q):
    return colouring[centre] == colouring[p] == colouring[q]


def site_name(site):
    centre, p, q = site
    p, q = sorted((p, q))
    return f"{centre}:{p}|{q}"


def dangerous_local_candidates():
    """Return raw and interface-disjoint candidates from the exact local CSP."""
    tris = base.triangles(base.T_VERTICES, base.T_EDGES)
    raw = []
    legal = []
    for centre in base.T_VERTICES:
        cycle = link_cycle(centre, base.T_VERTICES, base.T_EDGES, tris)
        for p, q in combinations(cycle, 2):
            left, right = closed_paths(cycle, p, q)
            # A genuine Eulerian split has two nontrivial odd-cardinality
            # closed link intervals.  The new side vertices then have even
            # degrees |I|+1.
            if min(len(left), len(right)) <= 2:
                continue
            if len(left) % 2 == 0 or len(right) % 2 == 0:
                continue
            chi11 = local_state11(base.CHI, centre, p, q)
            lambda11 = local_state11(base.LAM, centre, p, q)
            mu11 = local_state11(base.MU, centre, p, q)
            # To destroy both canonical adjacencies, at least one endpoint
            # of each old edge must fail canonical lifting:
            # (chi11 or lambda11) and (chi11 or mu11).
            if not (chi11 or (lambda11 and mu11)):
                continue
            site = (centre, p, q)
            raw.append(site)
            selected = (base.edge(centre, p), base.edge(centre, q))
            if all(
                not cobound_triangle(e, labelled, tris)
                for e in selected
                for labelled in LABELLED_INTERFACES
            ):
                legal.append(site)
    return tuple(raw), tuple(legal)


PRESPLITS = {
    frozenset(("r4", "r3", "r5")): {
        "centre": "r4",
        "left": ("r5", "w", "r3"),
        "right": ("r3", "A", "C", "B", "r5"),
        "final_left": ("r2", "r3", "L", "r5", "r6"),
        "final_right": ("r6", "r7", "r0", "r1", "r2"),
    },
    frozenset(("r0", "r1", "r7")): {
        "centre": "r0",
        "left": ("r7", "w", "r1"),
        "right": ("r1", "A", "C", "B", "r7"),
        "final_left": ("r2", "r3", "r4", "r5", "r6"),
        "final_right": ("r6", "r7", "L", "r1", "r2"),
    },
}


def audit_legal_candidate(site):
    centre, p, q = site
    data = PRESPLITS[frozenset(site)]
    vertices, edges = base.split_graph(
        base.T_VERTICES,
        base.T_EDGES,
        centre,
        data["left"],
        data["right"],
        data["left"][0],
        data["left"][-1],
        ("L", "R", "M"),
    )
    tris = base.graph_checks(f"parent-after-{centre}", vertices, edges)
    base.assert_interfaces_disjoint(
        tris,
        (
            base.ROOT,
            base.GATE,
            base.edge("w", "r2"),
            base.edge("w", "r6"),
        ),
    )
    _, targets = base.target_family(vertices, edges, tris, base.ROOT)
    survivors = tuple(v for v in base.T_VERTICES if v != centre)

    def unique_lift(old):
        lifts = tuple(x for x in targets if base.same_on(x, old, survivors))
        assert len(lifts) == 1
        return lifts[0]

    chi, lam, mu, eta = map(unique_lift, (base.CHI, base.LAM, base.MU, ETA))
    assert base.gate_bit(chi, base.GATE) == 1
    assert base.state11(chi)
    assert all(base.gate_bit(x, base.GATE) == 1 for x in (lam, mu))
    assert not base.state11(lam) and not base.state11(mu)
    assert all(
        base.bond_pair(chi, x, vertices, edges)
        for x in (lam, mu)
    )
    assert base.gate_bit(eta, base.GATE) == 0
    assert not base.state11(eta)
    assert base.bond_pair(chi, eta, vertices, edges)

    child_vertices, child_edges = base.split_graph(
        vertices,
        edges,
        "w",
        data["final_left"],
        data["final_right"],
        "r2",
        "r6",
        ("D", "E", "F"),
    )
    child_tris = base.graph_checks(
        f"child-after-{centre}", child_vertices, child_edges
    )
    base.assert_interfaces_disjoint(child_tris, (base.ROOT, base.GATE))
    _, all_child_targets = base.target_family(
        child_vertices, child_edges, child_tris, base.ROOT
    )
    final_order = ("D", "E", "F", "r2", "r6")
    child_targets = tuple(
        x for x in all_child_targets
        if base.cell(x, final_order) != "C11"
    )
    sector_one_new = tuple(
        x for x in child_targets
        if base.gate_bit(x, base.GATE) == 1
        and base.cell(x, final_order) in {"R", "U", "V"}
    )
    assert not sector_one_new

    return {
        "site": site_name(site),
        "parent_targets": len(targets),
        "child_targets": len(child_targets),
        "chi_lambda_shore": tuple(v for v in vertices if chi[v] != lam[v]),
        "chi_mu_shore": tuple(v for v in vertices if chi[v] != mu[v]),
        "same_sector_cycle_escapes": 2,
        "mixed_bond_survives": True,
        "sector_one_new_cells": 0,
    }


def main():
    raw, legal = dangerous_local_candidates()
    raw_names = {site_name(x) for x in raw}
    legal_names = {site_name(x) for x in legal}
    assert raw_names == {
        "r0:r1|r7",
        "r2:A|w",
        "r4:r3|r5",
        "r6:B|w",
        "w:r2|r6",
        "C:A|B",
    }
    assert legal_names == {"r0:r1|r7", "r4:r3|r5"}
    print(f"dangerous_raw={sorted(raw_names)}")
    print(f"dangerous_interface_disjoint={sorted(legal_names)}")
    for site in legal:
        print(audit_legal_candidate(site))
    print("NOTE116_ONE_PRESPLIT_LOCAL_CSP_CLOSED")


if __name__ == "__main__":
    main()
