# The Note 116 example cannot lose both adjacent escapes by one legal preprocessing split

## Fixed question

Keep the crossed-double-split parent (T), ordered root (AC), surviving
gate (Ar_2), and eventual split of (w) across (r_2,r_6) from Note 116.
Let

\[
\begin{aligned}
 \chi&=100100010111,\\
 \lambda&=100100001111,\\
 \mu&=100100100111
\end{aligned}
\]

in the order ((w,r_0,\ldots,r_7,A,B,C)).  The state-(11) target
\(\chi\) has surviving-gate sector one, while \(\lambda,\mu\) are
non-(11) targets in the same sector.  Both differences are connected
bond shores and therefore single alternating-cycle exchanges:

\[
 \chi\triangle\lambda=\{r_6,r_7\},\qquad
 \chi\triangle\mu=\{r_5,r_6\}.
\]

The fixed final split has \({\cal N}^1=\varnothing\).  The question here is
only whether one prior interface-disjoint Eulerian vertex split can destroy
both displayed same-sector escapes while retaining the prescribed final
interface.  No other graph, root, gate, final site, or sequence of moves is
considered.

## Canonical-persistence reduction

For a preprocessing split, the canonical target correspondence preserves
every single-cycle adjacency whose two endpoints are outside local state
(11).  Hence the edge \(\chi\lambda\) can be destroyed only if \(\chi\)
or \(\lambda\) has local state (11), and similarly for
\(\chi\mu\).  A site capable of destroying both must therefore satisfy

\[
 (\chi_{11}\vee\lambda_{11})
 \wedge(\chi_{11}\vee\mu_{11})
 =\chi_{11}\vee(\lambda_{11}\wedge\mu_{11}).
\tag{1}
\]

This makes the required computation a local colour-word CSP, not a census
of all sites or target families.  Requiring two nontrivial odd closed link
intervals, so that the split remains Eulerian, leaves exactly six raw
solutions:

\[
 r_0:(r_1,r_7),\quad r_4:(r_3,r_5),\quad
 r_2:(A,w),\quad C:(A,B),\quad
 r_6:(B,w),\quad w:(r_2,r_6).
\tag{2}
\]

Four are not admissible preprocessing sites.  The (r_2) site uses the
labelled gate edge (Ar_2) and the future site edge (wr_2); the (C)
site uses the root edge (AC); the (r_6) site uses the other future site
edge (wr_6); and (w:(r_2,r_6)) is the future split itself.  Thus the
only interface-disjoint possibilities are the two reflected sites

\[
 r_4:(r_3,r_5),\qquad r_0:(r_1,r_7).
\tag{3}
\]

## Exact outcome of the two legal candidates

For each site in (3), complete NAE and labelled-root enumeration gives a
unique descendant of each of \(\chi,\lambda,\mu\).  The descendant of
\(\chi\) remains state (11), has a mixed rooted-bond neighbour in the
opposite gate sector, and has both descendants of \(\lambda,\mu\) as
same-sector non-(11) single-cycle neighbours.  After the prescribed final
split, sector one still satisfies

\[
 {\cal N}^1=\varnothing.
\tag{4}
\]

The exact lifted shores are

\[
\begin{array}{c|cc}
\text{pre-split}&\chi\triangle\lambda&\chi\triangle\mu\\ \hline
r_4&\{r_6,r_7\}&\{L,r_5,r_6\}\\
r_0&\{L,r_6,r_7\}&\{r_5,r_6\}.
\end{array}
\tag{5}
\]

Each shore and its complement are connected.  Thus both legal candidates
still satisfy the left side of the adjacent-escape dichotomy, even though
the child side remains empty.

Consequently this fixed construction family is not distinguishing:

\[
\boxed{
\text{no single legal preprocessing split of the fixed Note 116 interface
can destroy both adjacent escapes.}}
\tag{6}
\]

This is a strict one-surgery route closure, not a proof of the general
adjacent-escape dichotomy.  It does not exclude a different triangulation,
a different labelled interface, a multi-operation construction not reduced
to this local CSP, or a noncanonical global reconfiguration.

## Relation to the earlier actual objects

The actual forced-component witness of Note 74 lies on the opposite side of
the intended dichotomy: its two forced-gate targets both lift.  The facial
square objects of Notes 104--105 have explicit new-cell lifts for every
state-(11) target.  The Note 107 legal-wide witness populates all three new
cells.  Notes 101--102 kill inherited crossing edges only to retain or
supplement child crossings.  None of these frozen objects supplies the
simultaneous conditions “no gate-even non-(11) single-cycle neighbour” and
“same-sector new-cell family empty.”

Reproduce the fixed local classification with

```text
python3 units/barnette/scratch/worker-adjacent-escape-counterexample/verify_note116_one_presplit_local_csp.py
```

The final marker is

```text
NOTE116_ONE_PRESPLIT_LOCAL_CSP_CLOSED
```
