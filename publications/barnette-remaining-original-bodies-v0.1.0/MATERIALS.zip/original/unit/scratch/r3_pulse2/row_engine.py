#!/usr/bin/env python3
"""Fourteen-slot row algebra for Route 1 pulse 2.

The public maps are ``transition(eta, rows)`` and ``joint_output(eta, rows)``.
They use only finite metadata and normalized rows; no graph is an argument.
"""

from dataclasses import dataclass, replace
from itertools import combinations

SLOTS = ("u", "v", "x", "y", "r0", "r1",
         "e0", "e1", "f0", "f1", "a", "b", "c", "d")
OLD = ("u", "v", "x", "y", "r0", "r1")
NEW = ("a", "b", "c", "d")
TARGET = ("e0", "e1", "f0", "f1")
SUCCESSOR = ("u", "a", "r0", "r1")
BORN = (
    ("u", "a", "ua"), ("a", "b", "ab"),
    ("b", "v", "bv"), ("x", "c", "xc"),
    ("c", "d", "cd"), ("d", "y", "dy"),
    ("a", "d", "ad"), ("b", "c", "bc"),
)
RETAINED = ("r0", "r1", "r")
LOCAL = BORN + (RETAINED,)
CUT = frozenset(("ua", "r"))
EXTERIOR_LOCAL = tuple(e for e in LOCAL if e[2] not in CUT)
LOCATIONS = frozenset((
    "external-existing", "uv", "xy", "r", "ua", "ab", "bv", "xc",
    "cd", "dy", "ad", "bc", "not-yet-born", "deleted",
))
EDGE_STATUS = frozenset(("kernel-live", "older-live", "born-now", "future", "deleted"))
WORD_ALPHABET = frozenset(SLOTS + ("site-arc-0", "site-arc-1", "two-arcs"))
MAX_WORD = 32                 # bounded marked incidences; never an entire face


class DSU:
    def __init__(self, xs):
        self.p = {x: x for x in xs}

    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, x, y):
        x, y = self.find(x), self.find(y)
        if x != y:
            self.p[y] = x


def canon_partition(blocks, order):
    pos = {q: i for i, q in enumerate(order)}
    bs = [tuple(sorted(set(b), key=pos.__getitem__)) for b in blocks]
    return tuple(sorted(bs, key=lambda b: tuple(pos[q] for q in b)))


@dataclass(frozen=True)
class Eta:
    """The finite metadata. ``cls`` is a canonical equality quotient.

    ``exists[k]`` says whether the vertex represented by class k is in the
    current graph. Absolute birth/deletion layer numbers are deliberately absent.
    The remaining tuples are finite incidence/order words supplied by the legal
    certificate; transition merely transports the frozen successor word.
    """

    cls: tuple
    exists: tuple
    locations: tuple
    edge_status: tuple
    colors: tuple
    phase: str = "input"
    site_word: tuple = ("u", "v", "x", "y")
    face_word: tuple = ()
    successor_face_word: tuple = ()

    def __post_init__(self):
        if len(self.cls) != len(SLOTS):
            raise ValueError("cls must have fourteen entries")
        if set(self.cls) != set(range(max(self.cls, default=-1) + 1)):
            raise ValueError("class ids must be contiguous")
        first = {}
        for i, k in enumerate(self.cls):
            first.setdefault(k, i)
        if list(first.values()) != sorted(first.values()):
            raise ValueError("classes must be numbered by first slot occurrence")
        if len(self.exists) != len(first) or len(self.colors) != len(first):
            raise ValueError("exists/colors must be class indexed")
        if any(type(x) is not bool for x in self.exists) or any(x not in (0,1) for x in self.colors):
            raise ValueError("exists/colors are finite bits")
        if len(self.locations) != 2 or any(x not in LOCATIONS for x in self.locations):
            raise ValueError("bad target location")
        if len(self.edge_status) != 2 or any(x not in EDGE_STATUS for x in self.edge_status):
            raise ValueError("bad finite edge status")
        if self.phase not in ("input", "successor"):
            raise ValueError("bad phase")
        for word in (self.site_word, self.face_word, self.successor_face_word):
            if len(word) > MAX_WORD or any(x not in WORD_ALPHABET for x in word):
                raise ValueError("incidence word is outside the bounded finite alphabet")

    def cid(self, slot):
        return self.cls[SLOTS.index(slot)]

    def rep(self, cid):
        return SLOTS[self.cls.index(cid)]

    def reps(self, slots, require_exists=True):
        ans = []
        for slot in slots:
            k = self.cid(slot)
            if (not require_exists or self.exists[k]) and self.rep(k) not in ans:
                ans.append(self.rep(k))
        return tuple(ans)

    def active(self):
        structural = OLD if self.phase == "input" else SUCCESSOR
        return self.reps(structural + TARGET)


@dataclass(frozen=True)
class Row:
    boundary: tuple
    d: tuple
    pi: tuple
    z: int
    be: int
    bf: int


@dataclass(frozen=True)
class Kappa:
    row: Row
    cut_ua: int
    cut_r: int


def eta_plus(eta):
    """Deterministic role/existence/target/face transport."""
    if eta.phase != "input":
        raise ValueError("eta_plus requires input phase")
    exists = list(eta.exists)
    for slot in NEW:
        exists[eta.cid(slot)] = True
    loc_map = {"uv": "deleted", "xy": "deleted", "r": "r", "ua": "ua"}
    for name in ("ab", "bv", "xc", "cd", "dy", "ad", "bc"):
        loc_map[name] = "external-existing"
    locations = tuple(loc_map.get(x, x) for x in eta.locations)
    status = tuple(
        "deleted" if old in ("uv", "xy") else
        "older-live" if old in ("r", "ua", "ab", "bv", "xc", "cd", "dy", "ad", "bc") else st
        for old, st in zip(eta.locations, eta.edge_status)
    )
    return replace(eta, exists=tuple(exists), locations=locations,
                   edge_status=status, phase="successor",
                   site_word=SUCCESSOR, face_word=eta.successor_face_word,
                   successor_face_word=())


def masks(edges=LOCAL):
    names = tuple(e[2] for e in edges)
    for n in range(len(names) + 1):
        for ss in combinations(names, n):
            yield frozenset(ss)


def _target_local_bits(eta, chosen, cut=False):
    usable = chosen - CUT if cut else chosen
    return tuple(int(loc in usable) for loc in eta.locations)


def _glue(eta, row, chosen, mode):
    """Glue one realized row. mode is ``output`` or ``full``."""
    if row.boundary != eta.active():
        raise ValueError("row boundary does not match eta activity quotient")
    chosen = frozenset(chosen)
    ep = eta_plus(eta)
    universe = list(row.boundary)
    for slot in NEW:
        rep = eta.rep(eta.cid(slot))
        if rep not in universe:
            universe.append(rep)
    degree = dict(zip(row.boundary, row.d))
    degree.update({q: degree.get(q, 0) for q in universe})
    dsu = DSU(universe)
    for block in row.pi:
        for q in block[1:]:
            dsu.union(block[0], q)

    active_edges = chosen - CUT if mode == "output" else chosen
    for p, q, name in LOCAL:
        if name not in active_edges:
            continue
        rp, rq = eta.rep(eta.cid(p)), eta.rep(eta.cid(q))
        if rp == rq:
            degree[rp] += 2
        else:
            degree[rp] += 1
            degree[rq] += 1
            dsu.union(rp, rq)

    boundary = ep.active() if mode == "output" else ()
    for q in universe:
        if q in boundary:
            if not 0 <= degree[q] <= 2:
                return None
        elif degree[q] != 2:
            return None

    comps = {}
    for q in universe:
        comps.setdefault(dsu.find(q), set()).add(q)
    if mode == "full":
        be_local, bf_local = _target_local_bits(eta, chosen, cut=False)
        component_count = min(2, row.z + len(comps))
        return component_count, row.be | be_local, row.bf | bf_local

    touching, closed = [], 0
    for comp in comps.values():
        hit = set(boundary) & comp
        if hit:
            touching.append(hit)
        else:
            closed += 1
    be_local, bf_local = _target_local_bits(eta, chosen, cut=True)
    return Row(boundary, tuple(degree[q] for q in boundary),
               canon_partition(touching, boundary), min(2, row.z + closed),
               row.be | be_local, row.bf | bf_local)


def transition(eta, rows):
    """T0: enumerate exactly the 2^7 canonical P0 subsets of L' minus K+."""
    ep = eta_plus(eta)
    out = set()
    for row in rows:
        for p0 in masks(EXTERIOR_LOCAL):
            q = _glue(eta, row, p0, "output")
            if q is not None:
                out.add(q)
    return ep, frozenset(out)


def joint_output(eta, rows):
    """j0: enumerate all 2^9 complete local P and return kappa support + A."""
    support = set()
    accept = False
    for row in rows:
        for p in masks(LOCAL):
            full = _glue(eta, row, p, "full")
            if full is None:
                continue
            # Kappa's alpha is computed from this same (row,p), after cutting.
            cutrow = _glue(eta, row, p, "output")
            assert cutrow is not None
            support.add(Kappa(cutrow, int("ua" in p), int("r" in p)))
            components, be, bf = full
            accept |= components == 1 and (be, bf) == (1, 0)
    return frozenset(support), bool(accept)
