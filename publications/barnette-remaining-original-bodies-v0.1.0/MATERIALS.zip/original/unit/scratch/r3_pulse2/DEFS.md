# Corrected finite definitions for Route 1, pulse 2

This file fixes the objects in (P2).  It does not change
`SPEC-2026-09-12-upgrade.md`.  Relative to
[`r3_pulse1/DEFS.md`](../r3_pulse1/DEFS.md), it (i) removes absolute layer
numbers from the summary, (ii) makes vertex existence a class-indexed finite
flag, (iii) specifies the fourteen-slot quotient and target-only retention
algorithm, and (iv) separates the 128 canonical successor choices from the
512 complete choices.

## 1. Domain and operation

The real domain (D_{o^*}) and the operation are unchanged.  The structural
roles are (s=(u,v,x,y)), (r=(r_0,r_1)).  The operation deletes (uv,xy),
creates fresh (a,b,c,d), adds

\[
 L=(ua,ab,bv,xc,cd,dy,ad,bc),
\]

and changes the site to ((u,a,r_0,r_1)), retaining (r=r_0r_1).  Put
(K_X=\{uv,xy,r\}), (L'=L\cup\{r\}), and (K^+=\{ua,r\}).  Then

\[
 E(G^+)=(E(G)\setminus K_X)\mathbin{\dot\cup}L'.
\]

All graph legality, embedding, face and complete-history requirements remain
those of pulse 1 and the frozen SPEC.

## 2. Fourteen-slot quotient and current existence

The ordered slots are

\[
 Q=(u,v,x,y,r_0,r_1,e_0,e_1,f_0,f_1,a,b,c,d).
\]

Metadata stores the equivalence relation (\equiv) on these slots, canonically
numbered by first occurrence.  Each equivalence class has a bit
(\epsilon_X(C)), meaning that its represented vertex belongs to (V(G)).
Thus a role name always exists syntactically, while its represented vertex may
not yet exist.  In every real input the six old structural classes exist;
the four fresh classes do not, unless the same class is also represented by
an already existing target endpoint (real legality in fact keeps fresh
structural vertices distinct).  A target endpoint is active exactly when its
class existence bit is one.

The input active classes are, in quotient first-occurrence order,

\[
 B_X=\{[q]:q\in\{u,v,x,y,r_0,r_1,e_0,e_1,f_0,f_1\},
                 \epsilon_X([q])=1\}.
\]

At output set the classes of (a,b,c,d) to existing, preserve every old
existence bit, and take

\[
 B_+=\{[q]:q\in\{u,a,r_0,r_1,e_0,e_1,f_0,f_1\},
                 \epsilon_+([q])=1\}.
\]

This is the complete preserve/forget rule.  In particular, (v,x,y,b,c,d)
are absent as free output ports but their classes remain when aliased to a
current target endpoint.  Target-only classes never incident with a patch
edge pass through unchanged.  All degree additions and connectivity joins are
performed after quotienting edge endpoints; no program path addresses a raw
slot not in the quotient.

## 3. The finite metadata eta and its transport

(\eta) consists only of finite enumerated data:

1. the fourteen-slot equivalence relation, class existence bits, and class
   bipartition colours up to global reversal;
2. for each target, a location in
   `external-existing`, `uv`, `xy`, `r`, one of the eight names in (L),
   `not-yet-born`, or `deleted`, and a status in
   `kernel-live`, `older-live`, `born-now`, `future`, `deleted`;
3. `input`/`successor` phase, the ordered site-incidence word, and the finite
   marked-role word on the selected face and two arcs, up to simultaneous
   mirror, together with the already supplied successor-face word.

Absolute birth and deletion layer numbers occur only in the complete history
certificate and are not in (\eta).  No arc length, unmarked vertex, vertex
number, counter or other unbounded datum is stored.

The deterministic map (\eta\mapsto\eta^+) preserves the quotient, colours
and old existence, turns the four fresh-class existence bits on, changes the
phase and site word to ((u,a,r_0,r_1)), and moves the supplied successor-face
word into the current-face field.  Target locations map

\[
 uv,xy\mapsto\texttt{deleted},\quad r\mapsto r,\quad ua\mapsto ua,
\]

the other seven born-edge names map to `external-existing`, and
`external-existing`, `not-yet-born`, `deleted` remain unchanged.  Corresponding
finite statuses become `deleted` for (uv,xy), `older-live` for surviving
local edges, and otherwise remain unchanged.  This is exactly `eta_plus` in
`row_engine.py`.

## 4. Rows and successor transition

For (F\subseteq G-K_X), retain all vertices and require degree two outside
(B_X), degree at most two on (B_X).  Its row

\[
 \alpha_X(F)=(B_X,d,\pi,z,\beta_e,\beta_f)
\]

stores the ordered active quotient, its degrees, the full component partition
including isolated active classes, the number of components missing the
interface saturated at two, and use of each target precisely when its location
is `external-existing`.  Put (R_X=\{\alpha_X(F)\}) and
(\sigma_0(X)=(\eta(X),R_X)).

For the successor exterior, the local object is canonically

\[
 P_0\subseteq L'\setminus K^+
   =\{ab,bv,xc,cd,dy,ad,bc\}.
\]

There are (2^7=128), not 512, choices.  Quotient endpoint degrees and joins
are added to a row.  Every class outside (B_+) must finish at degree two and
every class in (B_+) at degree at most two.  Components no longer meeting
(B_+) are added to (z), and target bits are ORed only for targets located
on one of these seven exterior-local edges.  The result is

\[
 T_0(\eta,R)=(\eta^+,\{\alpha_+(F\cup P_0)\}).
\]

## 5. Complete joint output

Independently enumerate all (2^9=512) sets (P\subseteq L').  A pair
((F,P)) is full-legal exactly when every represented current/output vertex
has degree two.  From this same pair, without first compressing it to a closed
cycle count, form

\[
 \kappa(F\cup P)=
 (\alpha_+(F\cup(P\setminus K^+)),
  \mathbf1_{ua\in P},\mathbf1_{r\in P}).
\]

The two target-use bits for the full union use the exterior bits and the
uniquely tagged local edge in this same (P).  The acceptance bit is one iff
that same full union has one component and target bits ((1,0)).  Thus

\[
 j_0(\eta,R)=\bigl(\{\kappa(F\cup P)\},A\bigr)=J^*(X).
\]

All alphabets in these clauses are finite.  The only set-valued coordinate is
a subset of the finite row alphabet, so the complete state set is finite.

