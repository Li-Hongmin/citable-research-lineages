#!/usr/bin/env python3
"""Independent real-context gate for the full pulse-2 DEFS object."""

from itertools import combinations
import networkx as nx

from row_engine import (BORN, Kappa, LOCAL, OLD, SLOTS, Eta, Row,
                        _glue, canon_partition, joint_output,
                        transition)


def edge(p, q): return tuple(sorted((p, q)))


def cube():
    return nx.Graph([(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),
                     (0,4),(1,5),(2,6),(3,7)])


def expand(G, site):
    u,v,x,y = site
    H = G.copy(); H.remove_edges_from(((u,v),(x,y)))
    a,b,c,d = range(max(H)+1, max(H)+5)
    H.add_edges_from(((u,a),(a,b),(b,v),(x,c),(c,d),(d,y),(a,d),(b,c)))
    return H, (a,b,c,d)


def faces(G):
    ok, emb = nx.check_planarity(G); assert ok
    seen, out = set(), []
    for p,q in emb.edges():
        if (p,q) not in seen:
            out.append(tuple(emb.traverse_face(p,q,seen)))
    return out


def legal_sites(G):
    col = nx.bipartite.color(G); ans = set()
    for face in faces(G):
        for cyc in (face, tuple(reversed(face))):
            es = [(cyc[i],cyc[(i+1)%len(cyc)]) for i in range(len(cyc))]
            for p,q in combinations(range(len(es)),2):
                for i,j in ((p,q),(q,p)):
                    u,v=es[i]; x,y=es[j]
                    if len({u,v,x,y}) == 4 and col[u] == col[x]:
                        ans.add((u,v,x,y))
    return ans


def subgraphs_with_degrees(G, boundary):
    es = sorted(edge(*e) for e in G.edges())
    inc = {v: [] for v in G}
    for i,(p,q) in enumerate(es): inc[p].append(i); inc[q].append(i)
    deg = {v: 0 for v in G}; picked = []; out = []
    def rec(i):
        if i == len(es):
            if all(deg[v] == 2 or (v in boundary and deg[v] <= 2) for v in G):
                out.append(frozenset(picked))
            return
        p,q = es[i]
        if all(not (inc[v][-1] == i and v not in boundary and deg[v] != 2)
               for v in (p,q)):
            rec(i+1)
        if deg[p] < 2 and deg[q] < 2:
            deg[p]+=1; deg[q]+=1; picked.append(es[i]); rec(i+1)
            picked.pop(); deg[p]-=1; deg[q]-=1
    rec(0)
    return out


def make_eta(G, H, site, retained, born, e, f):
    u,v,x,y = site; r0,r1 = retained; a,b,c,d = born
    values = (u,v,x,y,r0,r1,e[0],e[1],f[0],f[1],a,b,c,d)
    ids, cls = {}, []
    for value in values:
        ids.setdefault(value, len(ids)); cls.append(ids[value])
    exists = tuple(value in G for value,_ in sorted(ids.items(), key=lambda x:x[1]))
    colors_map = nx.bipartite.color(H)
    colors = tuple(colors_map[value] for value,_ in sorted(ids.items(), key=lambda x:x[1]))
    local = {edge(*(values[SLOTS.index(p)], values[SLOTS.index(q)])): name
             for p,q,name in LOCAL}
    controlled = {edge(u,v): "uv", edge(x,y): "xy", edge(r0,r1): "r"}
    def loc(t):
        return controlled.get(t, local.get(t, "external-existing"))
    locations = (loc(e), loc(f))
    statuses = tuple("born-now" if z in {x[2] for x in BORN} else "older-live"
                     for z in locations)
    # These are finite role-incidence words, not full or length-bearing faces.
    return Eta(tuple(cls), exists, locations, statuses, colors,
               face_word=("site-arc-0", "site-arc-1"),
               successor_face_word=("u", "a", "r0", "r1", "two-arcs"))


def direct_row(G, subset, eta, slot_values, e, f):
    boundary = eta.active()
    rep_vertex = {eta.rep(eta.cid(slot)): slot_values[slot] for slot in SLOTS}
    W = nx.Graph(); W.add_nodes_from(G); W.add_edges_from(subset)
    blocks=[]; z=0
    for comp in nx.connected_components(W):
        hit={q for q in boundary if rep_vertex[q] in comp}
        if hit: blocks.append(hit)
        else: z += 1
    external = tuple(loc == "external-existing" for loc in eta.locations)
    return Row(boundary, tuple(W.degree(rep_vertex[q]) for q in boundary),
               canon_partition(blocks, boundary), min(2,z),
               int(external[0] and e in subset), int(external[1] and f in subset))


def context_data(G, site, retained, e, f):
    H,born = expand(G,site)
    u,v,x,y=site; r0,r1=retained; a,b,c,d=born
    assert (u,a,r0,r1) in legal_sites(H)
    assert all(q == 3 for _,q in H.degree()) and nx.is_bipartite(H)
    assert nx.node_connectivity(H) >= 3
    eta = make_eta(G,H,site,retained,born,e,f)
    vals = dict(zip(SLOTS,(u,v,x,y,r0,r1,e[0],e[1],f[0],f[1],a,b,c,d)))
    controlled=(edge(u,v),edge(x,y),edge(r0,r1))
    X=G.copy(); X.remove_edges_from(controlled)
    ext_sets=subgraphs_with_degrees(X,{vals[q] for q in eta.active()})
    rows=frozenset(direct_row(X,S,eta,vals,e,f) for S in ext_sets)
    return H,born,eta,vals,rows


def expected_eta_plus(eta):
    exists=list(eta.exists)
    for slot in ("a","b","c","d"): exists[eta.cid(slot)]=True
    locations=[]; status=[]
    for loc,st in zip(eta.locations,eta.edge_status):
        if loc in ("uv","xy"):
            locations.append("deleted"); status.append("deleted")
        elif loc in ("r","ua"):
            locations.append(loc); status.append("older-live")
        elif loc in ("ab","bv","xc","cd","dy","ad","bc"):
            locations.append("external-existing"); status.append("older-live")
        else:
            locations.append(loc); status.append(st)
    return Eta(eta.cls,tuple(exists),tuple(locations),tuple(status),eta.colors,
               phase="successor",site_word=("u","a","r0","r1"),
               face_word=eta.successor_face_word,successor_face_word=())


def check_pair(G, site, retained, e, f):
    H,born,eta,vals,rows=context_data(G,site,retained,e,f)
    ep,pred_rows=transition(eta,rows)
    u=site[0]; a=born[0]; r0,r1=retained
    out=H.copy(); out.remove_edges_from((edge(u,a),edge(r0,r1)))
    out_sets=subgraphs_with_degrees(out,{vals[q] for q in ep.active()})
    direct_rows=frozenset(direct_row(out,S,ep,vals,e,f) for S in out_sets)
    assert ep == expected_eta_plus(eta)
    assert pred_rows == direct_rows

    full_sets=subgraphs_with_degrees(H,set())
    direct_k=set(); direct_accept=False
    for S in full_sets:
        cut=S-{edge(u,a),edge(r0,r1)}
        rr=direct_row(out,cut,ep,vals,e,f)
        direct_k.add(Kappa(rr,int(edge(u,a) in S),int(edge(r0,r1) in S)))
        W=nx.Graph(); W.add_nodes_from(H); W.add_edges_from(S)
        direct_accept |= nx.is_connected(W) and e in S and f not in S
    pred_k,pred_accept=joint_output(eta,rows)
    assert pred_k == frozenset(direct_k)
    assert pred_accept == direct_accept
    return len(rows),len(pred_rows),len(pred_k),pred_accept


def regression_gate():
    Q=cube(); site=(0,1,2,3); retained=(5,4)
    # Round-8 real Hamilton witness: target-only class e0=6 must be accepted.
    e,f=edge(6,7),edge(0,4)
    H,born,eta,vals,rows=context_data(Q,site,retained,e,f)
    F=frozenset(map(lambda z: edge(*z),((0,3),(1,5),(2,6),(4,7),(6,7))))
    X=Q.copy(); X.remove_edges_from((edge(0,1),edge(2,3),edge(5,4)))
    row=direct_row(X,F,eta,vals,e,f)
    p=frozenset(("ua","ab","bv","xc","cd","dy","r"))
    assert _glue(eta,row,p,"full") == (1,1,0)
    assert joint_output(eta,{row})[1]

    # Round-8 target-alias row: v and x survive because they are e endpoints.
    e=edge(1,2)
    H,born,eta,vals,rows=context_data(Q,site,retained,e,f)
    F=frozenset(map(lambda z: edge(*z),((0,3),(5,6),(6,7),(7,4))))
    X=Q.copy(); X.remove_edges_from((edge(0,1),edge(2,3),edge(5,4)))
    row=direct_row(X,F,eta,vals,e,f)
    p0=frozenset(("ab","bc","xc","ad","dy"))
    got=_glue(eta,row,p0,"output")
    assert got is not None and "v" in got.boundary and "x" in got.boundary
    print("ROUND8_REAL_ROW_REGRESSIONS_OK cases=2")


def choose_retained(G,site):
    H,born=expand(G,site); u=site[0]; a=born[0]
    forbidden={edge(site[0],site[1]),edge(site[2],site[3])}
    candidates=[]
    for r0,r1 in G.edges():
        for r in ((r0,r1),(r1,r0)):
            if edge(*r) not in forbidden and (u,a,r[0],r[1]) in legal_sites(H):
                candidates.append(r)
    assert candidates
    return sorted(candidates)[0]


def main():
    regression_gate()
    Q=cube()
    contexts=[(Q,(0,1,2,3),(5,4),"depth-0")]
    Q1,b1=expand(Q,(0,1,2,3))
    contexts.append((Q1,(0,3,11,8),(7,4),"fixed-depth-1"))
    # Complete legal CEN history Q -> s1 -> s2, then apply o* at depth two.
    s1=(b1[1],b1[2],b1[3],b1[0]); assert s1 in legal_sites(Q1)
    Q2,b2=expand(Q1,s1)
    s2=(b2[1],b2[2],b2[3],b2[0]); assert s2 in legal_sites(Q2)
    contexts.append((Q2,s2,choose_retained(Q2,s2),"legal-history-depth-2"))
    for G,site,retained,label in contexts:
        H,born=expand(G,site); ts=sorted(edge(*z) for z in H.edges())
        pairs=[(ts[0],ts[-1]),(ts[len(ts)//3],ts[(2*len(ts))//3])]
        if label == "depth-0":
            pairs += [(edge(6,7),edge(0,4)),(edge(1,2),edge(0,4)),
                      (edge(site[0],born[0]),edge(*retained)),
                      (edge(born[0],born[1]),edge(6,7))]
        stats=[]
        for e,f in pairs:
            assert e != f
            stats.append(check_pair(G,site,retained,e,f))
        print(f"FULL_CONTEXT_OK {label} vertices={len(G)} retained={retained} "
              f"pairs={len(pairs)} stats={stats}")
    print("R3_PULSE2_FULL_SIGMA_KAPPA_ETA_ACCEPTANCE_VERIFIED")


if __name__ == "__main__": main()
