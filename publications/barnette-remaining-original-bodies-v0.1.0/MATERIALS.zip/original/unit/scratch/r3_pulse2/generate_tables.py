#!/usr/bin/env python3
"""Regenerate the canonical 128-row T0 and 512-row full-j0 atom tables."""

import csv
from pathlib import Path
from row_engine import EXTERIOR_LOCAL, LOCAL, masks

HERE=Path(__file__).resolve().parent


def signature(mask, edges):
    deg={q:0 for q in ("u","v","x","y","r0","r1","a","b","c","d")}
    joins=[]
    for p,q,name in edges:
        if name in mask:
            deg[p]+=1; deg[q]+=1; joins.append(name)
    return deg,",".join(joins) or "-"


def rows(edges, full):
    out=[]
    for i,mask in enumerate(masks(edges)):
        deg,joins=signature(mask,edges)
        row={"id":i,"mask":",".join(sorted(mask)) or "-",
             "increments":",".join(f"{q}:{deg[q]}" for q in deg),"joins":joins}
        if full:
            row |= {"cut_ua":int("ua" in mask),"cut_r":int("r" in mask)}
        out.append(row)
    return out


def main():
    tables=(("T0.tsv",rows(EXTERIOR_LOCAL,False)),("j0.tsv",rows(LOCAL,True)))
    for name,data in tables:
        with (HERE/name).open("w",newline="") as f:
            w=csv.DictWriter(f,fieldnames=data[0],delimiter="\t")
            w.writeheader(); w.writerows(data)
    assert len(tables[0][1])==128 and len(tables[1][1])==512
    print("R3_PULSE2_ATOMIC_TABLES_VERIFIED T0=128 j0=512")


if __name__=="__main__": main()
