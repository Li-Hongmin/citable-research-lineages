# Restriction--gluing proof for the corrected fourteen-slot engine

## 1. Edge-set decompositions

Fix any real (X\in D_{o^*}).  The disjoint ledger identity in DEFS gives two
different decompositions.

For a successor exterior generator (H_0\subseteq G^+-K^+),

\[
 F=H_0\cap(E(G)\setminus K_X),\qquad
 P_0=H_0\cap(L'\setminus K^+).
\]

Then (H_0=F\mathbin{\dot\cup}P_0), and intersection uniquely recovers the
pair.  This is the 128-choice bijection used by (T_0).

For a complete spanning 2-factor (H\subseteq G^+),

\[
 F=H\cap(E(G)\setminus K_X),\qquad P=H\cap L'.
\]

Then (H=F\mathbin{\dot\cup}P), again uniquely.  Here all 512 choices are
available.  Its (\kappa) is computed from this actual pair as

\[
 (\alpha_+(F\cup(P\setminus K^+)),1_{ua\in P},1_{r\in P}).
\]

There is no claimed bijection between a compressed row and an actual (F):
many exterior subgraphs may realize one row.

## 2. Why a row determines every gluing result

Take two actual exterior generators realizing the same row.  They have the
same degree on every active quotient class, the same complete component
partition there, the same saturated number of interface-free components, and
the same two external target-use bits.  A local edge can affect an exterior
component only at its named endpoint class.  Therefore, after any allowed
(P_0) or (P):

- degree legality is exactly addition of the same quotient-class increments;
- connectivity is exactly the same union of the stored partition with the
  local endpoint joins;
- a component becomes interface-free in exactly the same cases;
- saturation at two loses no information, since acceptance distinguishes only
  zero, one and at least two components;
- each target bit is the OR of its stored external bit and membership of its
  single finite location tag in the same local selection.

Thus every realization of a row obeys one transition rule.  Conversely, if
the quotient degree test accepts a row and a local choice, choosing any actual
realizer (F) gives a literal union with the asserted degrees, components and
target use.  This proves both directions without pretending that the row
recovers (F).

## 3. Exhaustion of aliases, existence and metadata

Equality is handled before every operation by replacing each endpoint slot by
the canonical representative of its equivalence class.  Hence the algorithm
does not branch on an alias pattern: every equivalence relation is covered by
the same quotient construction.  Looped quotient edges contribute degree two;
real legal contexts exclude structural collisions that would create such a
loop, but their treatment is nevertheless defined.

Existence is orthogonal to role naming.  Input activity is exactly the six
existing structural classes plus existing target endpoint classes.  Output
activity is exactly the four successor structural classes plus existing
target endpoint classes after the four births.  Consequently the exhaustive
cases are: a target endpoint aliases a surviving port; aliases a forgotten
old/new structural role and retains that class; is target-only and passes
through; or is not current and is omitted.  These are selected solely by the
class bit, so no target endpoint can be unconditionally forgotten.

For each target, the finite location cases partition all possibilities:
external existing; one of the three input-controlled edges; one of eight born
edges; future; deleted.  The explicit DEFS map covers every case.  Quotient,
existence, location/status and finite face-word transport are direct field
maps, so equal (\eta)'s have equal (\eta^+)'s.  Absolute history levels are
irrelevant and absent.

## 4. Exactness of T0, j0 and acceptance

Restriction of any real successor generator produces an input generator:
all vertices not represented at the interface are untouched and retain degree
two.  Its canonical (P_0) is one of the 128 enumerated choices, and the row
arithmetic is literal.  Conversely every accepted realized-row/(P_0) union
has exactly the successor-generator degree conditions.  Hence the complete
successor support, not merely a projection, equals (T_0(\sigma_0(X))).

The identical argument with full degree two and all 512 (P)'s exhausts the
spanning 2-factors.  Cutting (ua,r) only after choosing the full union gives
the exact complete (\kappa) support.  A finite spanning 2-regular graph is
connected iff it is one Hamilton cycle; combining this one-component test with
the same witness's target bits ((1,0)) is exactly “contains (e) and avoids
(f)”.  Therefore

\[
 T_0(\sigma_0(X))=\sigma_0(\Phi_{o^*}X),\qquad
 j_0(\sigma_0(X))=J^*(X)
\]

for every real (X\in D_{o^*}).  Graph order, arc length, nesting and the age
of (r) never enter the calculation.

## 5. Mechanical checks and their scope

`generate_tables.py` writes 128 canonical transition atoms and 512 full
atoms.  `validate_real_contexts.py` first executes both round-8 real-row
regressions.  It then independently enumerates actual exterior generators,
successor generators and full 2-factors, comparing (\eta^+), all successor
rows, all (\kappa)'s and the acceptance bit in the two pulse-1 contexts and
a complete legal-history context of depth two.  These checks certify the
implementation against independent graph enumeration; Sections 1--4, not the
finite sample, bear the universal quantifier.

