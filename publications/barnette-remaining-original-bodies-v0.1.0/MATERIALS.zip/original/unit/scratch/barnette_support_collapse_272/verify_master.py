#!/usr/bin/env python3
"""Independent verifier for the Barnette support-collapse experiment package.

This script verifies only finite, explicit certificates.  It does not invoke
MILP, does not trust solver 'infeasible' claims, and does not prove Barnette's
conjecture.  Dependency: networkx >= 3.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Iterable

import networkx as nx


def e(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


def read_json(path: Path):
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def graph6_from_record(data: dict) -> str:
    for key in ("graph6", "current_graph6", "grandchild_graph6", "child_graph6"):
        value = data.get(key)
        if value:
            return value
    raise KeyError("No graph6 field found")


def load_graph(path: Path) -> tuple[nx.Graph, dict]:
    data = read_json(path)
    g6 = graph6_from_record(data)
    G = nx.from_graph6_bytes(g6.encode("ascii"))
    claimed = data.get("graph6_sha256") or data.get("grandchild_graph6_sha256")
    if claimed:
        actual = hashlib.sha256(g6.encode("ascii")).hexdigest()
        assert actual == claimed, (path, actual, claimed)
    return G, data


def cycle_edge_set(cycle: list[int]) -> set[tuple[int, int]]:
    return {e(cycle[i], cycle[(i + 1) % len(cycle)]) for i in range(len(cycle))}


def path_edge_set(path: list[int]) -> set[tuple[int, int]]:
    return {e(path[i], path[i + 1]) for i in range(len(path) - 1)}


def verify_hamilton_cycle(G: nx.Graph, cycle: list[int], *, required_edge=None) -> set[tuple[int, int]]:
    n = G.number_of_nodes()
    assert len(cycle) == n, (len(cycle), n)
    assert len(set(cycle)) == n
    assert set(cycle) == set(G.nodes())
    E = cycle_edge_set(cycle)
    assert len(E) == n
    GE = {e(u, v) for u, v in G.edges()}
    assert E <= GE
    if required_edge is not None:
        assert e(*required_edge) in E
    F = nx.Graph()
    F.add_nodes_from(G.nodes())
    F.add_edges_from(E)
    assert nx.is_connected(F)
    assert all(d == 2 for _, d in F.degree())
    return E


def verify_hamilton_path(
    G: nx.Graph,
    path: list[int],
    endpoints: tuple[int, int],
    forbidden: Iterable[tuple[int, int]] = (),
) -> set[tuple[int, int]]:
    n = G.number_of_nodes()
    assert len(path) == n
    assert len(set(path)) == n
    assert set(path) == set(G.nodes())
    assert (path[0], path[-1]) == endpoints
    E = path_edge_set(path)
    assert len(E) == n - 1
    GE = {e(u, v) for u, v in G.edges()}
    assert E <= GE
    for z in forbidden:
        assert e(*z) not in E
    F = nx.Graph()
    F.add_nodes_from(G.nodes())
    F.add_edges_from(E)
    assert nx.is_connected(F)
    s, t = endpoints
    assert F.degree(s) == F.degree(t) == 1
    assert all(F.degree(z) == (1 if z in (s, t) else 2) for z in G.nodes())
    return E


def validate_barnette_graph(G: nx.Graph, expected_n: int | None = None) -> dict:
    if expected_n is not None:
        assert G.number_of_nodes() == expected_n
    assert not G.is_multigraph()
    assert nx.number_of_selfloops(G) == 0
    assert nx.is_connected(G)
    assert all(d == 3 for _, d in G.degree())
    assert nx.is_bipartite(G)
    planar, _ = nx.check_planarity(G, counterexample=False)
    assert planar
    kappa = nx.node_connectivity(G)
    assert kappa == 3
    return {
        "vertices": G.number_of_nodes(),
        "edges": G.number_of_edges(),
        "cubic": True,
        "bipartite": True,
        "planar": True,
        "vertex_connectivity": kappa,
    }


def planar_faces(G: nx.Graph) -> list[tuple[int, ...]]:
    ok, emb = nx.check_planarity(G, counterexample=False)
    assert ok
    visited: set[tuple[int, int]] = set()
    faces: list[tuple[int, ...]] = []
    for u, v in emb.edges():
        if (u, v) not in visited:
            faces.append(tuple(emb.traverse_face(u, v, visited)))
    return faces


def valid_c4_moves(G: nx.Graph):
    out = []
    for face in planar_faces(G):
        L = len(face)
        if L < 4 or L % 2:
            continue
        for i in range(L):
            for j in range(i + 1, L):
                if {face[i], face[(i + 1) % L]} & {face[j], face[(j + 1) % L]}:
                    continue
                if (j - i) % 2 == 0:
                    out.append((face, i, j))
    return out


def expand_c4(G: nx.Graph, face: tuple[int, ...], i: int, j: int):
    L = len(face)
    u, v = face[i], face[(i + 1) % L]
    x, y = face[j], face[(j + 1) % L]
    p, q = e(u, v), e(x, y)
    H = G.copy()
    a, b, c, d = range(max(H.nodes()) + 1, max(H.nodes()) + 5)
    H.remove_edge(*p)
    H.remove_edge(*q)
    H.add_edges_from(
        [(u, a), (a, b), (b, v), (x, c), (c, d), (d, y), (a, d), (b, c)]
    )
    return H, {
        "u": u,
        "v": v,
        "x": x,
        "y": y,
        "p": p,
        "q": q,
        "a": a,
        "b": b,
        "c": c,
        "d": d,
    }


def lift_cycle_edges(parent_edges: set[tuple[int, int]], r: dict):
    u, v, x, y = r["u"], r["v"], r["x"], r["y"]
    p, q = r["p"], r["q"]
    a, b, c, d = r["a"], r["b"], r["c"], r["d"]
    hp, hq = p in parent_edges, q in parent_edges
    if not (hp or hq):
        return None
    out = set(parent_edges) - {p, q}
    if hp and hq:
        local = [(u, a), (a, b), (b, v), (x, c), (c, d), (d, y)]
    elif hp:
        local = [(u, a), (a, d), (d, c), (c, b), (b, v)]
    else:
        local = [(x, c), (c, b), (b, a), (a, d), (d, y)]
    out.update(e(*z) for z in local)
    return out


def verify_hamilton_edge_set(G: nx.Graph, E: set[tuple[int, int]]):
    assert len(E) == G.number_of_nodes()
    F = nx.Graph()
    F.add_nodes_from(G.nodes())
    F.add_edges_from(E)
    assert nx.is_connected(F)
    assert all(d == 2 for _, d in F.degree())
    assert E <= {e(u, v) for u, v in G.edges()}


def load_cycles(path: Path) -> list[list[int]]:
    data = read_json(path)
    cycles = data["certificate_cycles"]
    if "certificate_cycle_count" in data:
        assert data["certificate_cycle_count"] == len(cycles)
    if "selected_cycle_count" in data:
        assert data["selected_cycle_count"] == len(cycles)
    return cycles


def verify_edge_cover(G: nx.Graph, cycles: list[list[int]]) -> dict:
    union: set[tuple[int, int]] = set()
    for c in cycles:
        union |= verify_hamilton_cycle(G, c)
    GE = {e(u, v) for u, v in G.edges()}
    assert union == GE
    return {"cycles": len(cycles), "covered_edges": len(union)}


def scan_direct_lift_coverage(G: nx.Graph, cycles: list[list[int]]) -> dict:
    parent_sets = [verify_hamilton_cycle(G, c) for c in cycles]
    moves = valid_c4_moves(G)
    fully_covered = 0
    max_missing = 0
    min_lifted = len(cycles)
    for face, i, j in moves:
        H, r = expand_c4(G, face, i, j)
        lifted = []
        union: set[tuple[int, int]] = set()
        HE = {e(u, v) for u, v in H.edges()}
        for C in parent_sets:
            L = lift_cycle_edges(C, r)
            if L is not None:
                # The generic local lift lemma proves Hamiltonicity from a
                # verified parent cycle.  Here we only check the finite edge
                # realization needed for the coverage certificate; rebuilding
                # a NetworkX graph for every one of ~100k lifted cycles would
                # dominate runtime without adding a distinct logical check.
                assert len(L) == H.number_of_nodes()
                assert L <= HE
                lifted.append(L)
                union |= L
        missing = len(HE - union)
        if missing == 0:
            fully_covered += 1
        max_missing = max(max_missing, missing)
        min_lifted = min(min_lifted, len(lifted))
    return {
        "legal_moves": len(moves),
        "fully_edge_covered_children": fully_covered,
        "children_with_missing_edges": len(moves) - fully_covered,
        "max_missing_edges": max_missing,
        "minimum_lifted_cycles": min_lifted,
    }


def verify_witness_rows(G: nx.Graph, path: Path, expected_count: int) -> dict:
    data = read_json(path)
    rows = data["rows"]
    assert len(rows) == expected_count
    seen = set()
    for row in rows:
        edge_req = tuple(row["edge"])
        result = row["result"]
        assert result["status"] == "hamiltonian"
        verify_hamilton_cycle(G, result["cycle"], required_edge=edge_req)
        seen.add(e(*edge_req))
    assert len(seen) == expected_count
    return {"witnesses": expected_count, "all_explicitly_verified": True}


def verify_single_witness(G: nx.Graph, path: Path, edge_req: tuple[int, int]):
    result = read_json(path)
    assert result["status"] == "hamiltonian"
    verify_hamilton_cycle(G, result["cycle"], required_edge=edge_req)


def state(cycle: list[int], p, q) -> str:
    E = cycle_edge_set(cycle)
    return f"{int(p in E)}{int(q in E)}"


def recover_cycle(G: nx.Graph, E: set[tuple[int, int]]) -> list[int]:
    verify_hamilton_edge_set(G, E)
    start = min(G.nodes())
    F = nx.Graph()
    F.add_nodes_from(G.nodes())
    F.add_edges_from(E)
    out = [start]
    prev = None
    cur = start
    for _ in range(G.number_of_nodes() - 1):
        ns = [z for z in F.neighbors(cur) if z != prev]
        nxt = min(ns) if prev is None else ns[0]
        out.append(nxt)
        prev, cur = cur, nxt
    assert F.has_edge(cur, start)
    return out


def recover_path(G: nx.Graph, E: set[tuple[int, int]], endpoints: tuple[int, int]) -> list[int]:
    s, t = endpoints
    F = nx.Graph()
    F.add_nodes_from(G.nodes())
    F.add_edges_from(E)
    assert len(E) == G.number_of_nodes() - 1
    assert nx.is_connected(F)
    assert F.degree(s) == F.degree(t) == 1
    assert all(F.degree(z) == (1 if z in (s, t) else 2) for z in G.nodes())
    out = [s]
    prev = None
    cur = s
    for _ in range(G.number_of_nodes() - 1):
        ns = [z for z in F.neighbors(cur) if z != prev]
        assert len(ns) == 1
        nxt = ns[0]
        out.append(nxt)
        prev, cur = cur, nxt
    assert cur == t
    return out


def verify_saturation_package(G, face, i, j, P):
    L = len(face)
    u, v = face[i], face[(i + 1) % L]
    x, y = face[j], face[(j + 1) % L]
    p, q = e(u, v), e(x, y)
    assert state(P["C11"], p, q) == "11"
    assert state(P["C10"], p, q) == "10"
    assert state(P["C01"], p, q) == "01"
    for key in ("C11", "C10", "C01"):
        verify_hamilton_cycle(G, P[key])
    verify_hamilton_path(G, P["X_vx"], (v, x), (p, q))
    verify_hamilton_path(G, P["X_uy"], (u, y), (p, q))
    return p, q


def transfer_saturation(G, face, i, j, P):
    verify_saturation_package(G, face, i, j, P)
    H, r = expand_c4(G, face, i, j)
    u, v, x, y = r["u"], r["v"], r["x"], r["y"]
    p, q = r["p"], r["q"]
    a, b, c, d = r["a"], r["b"], r["c"], r["d"]
    P10 = {e(*z) for z in [(u, a), (a, d), (d, c), (c, b), (b, v)]}
    E_C11 = (cycle_edge_set(P["C10"]) - {p, q}) | P10
    E_C10 = path_edge_set(P["X_uy"]) | {
        e(*z) for z in [(u, a), (a, b), (b, c), (c, d), (d, y)]
    }
    E_C01 = path_edge_set(P["X_vx"]) | {
        e(*z) for z in [(v, b), (b, a), (a, d), (d, c), (c, x)]
    }
    E0 = cycle_edge_set(P["C11"]) - {p, q}
    E_Xuy = E0 | {e(*z) for z in [(u, a), (v, b), (x, c), (c, d), (d, y)]}
    E_Xvx = E0 | {e(*z) for z in [(u, a), (a, b), (b, v), (x, c), (d, y)]}
    Pn = {
        "C11": recover_cycle(H, E_C11),
        "C10": recover_cycle(H, E_C10),
        "C01": recover_cycle(H, E_C01),
        "X_vx": recover_path(H, E_Xvx, (c, d)),
        "X_uy": recover_path(H, E_Xuy, (b, a)),
    }
    fn = (a, b, c, d)
    verify_saturation_package(H, fn, 1, 3, Pn)
    return H, fn, 1, 3, Pn


def verify_central_depth100(root: Path) -> dict:
    report = read_json(root / "data/central/central_saturation_depth100.json")
    G, _ = load_graph(root / "data/central/n240_graph.json")
    levels = report["levels"]
    assert report["depth"] == 100 and len(levels) == 101
    P = levels[0]["certificates"]
    # Move 739 is explicitly stored in level 0's expansion record.
    rec = levels[0]["expansion_record"]
    face, i, j = tuple(rec["face"]), rec["i"], rec["j"]
    for k, level in enumerate(levels):
        p, q = verify_saturation_package(G, face, i, j, P)
        g6 = nx.to_graph6_bytes(G, header=False).strip()
        assert hashlib.sha256(g6).hexdigest() == level["graph6_sha256"]
        assert [list(p), list(q)] == level["selected_edges"]
        for key, seq in P.items():
            digest = hashlib.sha256(json.dumps(seq).encode()).hexdigest()
            assert digest == level["certificate_hashes"][key]
        if "certificates" in level:
            assert level["certificates"] == P
        if k == 100:
            break
        G, face, i, j, P = transfer_saturation(G, face, i, j, P)
    assert G.number_of_nodes() == 640
    return {"levels": 101, "initial_vertices": 240, "final_vertices": 640, "verified": True}


def verify_local_state_enumeration() -> dict:
    names = ["ua", "ab", "bv", "xc", "cd", "dy", "ad", "bc"]
    edges = [("u", "a"), ("a", "b"), ("b", "v"), ("x", "c"), ("c", "d"), ("d", "y"), ("a", "d"), ("b", "c")]
    internal = {"a", "b", "c", "d"}
    rows = []
    for mask in range(1 << 8):
        chosen = [edges[k] for k in range(8) if (mask >> k) & 1]
        deg = Counter()
        for u, v in chosen:
            if u in internal:
                deg[u] += 1
            if v in internal:
                deg[v] += 1
        if all(deg[z] == 2 for z in internal):
            selected = [names[k] for k in range(8) if (mask >> k) & 1]
            ext = tuple(int(name in selected) for name in ("ua", "bv", "xc", "dy"))
            rows.append({"mask": mask, "selected": selected, "external_pattern": ext})
    assert len(rows) == 7
    isolated = [r for r in rows if r["external_pattern"] == (0, 0, 0, 0)]
    assert len(isolated) == 1 and set(isolated[0]["selected"]) == {"ab", "bc", "cd", "ad"}
    usable = [r for r in rows if r not in isolated]
    assert len(usable) == 6
    return {"degree_two_local_patterns": 7, "isolated_central_cycle_patterns": 1, "usable_patterns": 6}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    out = {"schema": "barnette-support-collapse-verification-v1", "root": str(root), "checks": {}}

    out["checks"]["local_state_calculus"] = verify_local_state_enumeration()

    graph_specs = [
        (240, "data/central/n240_graph.json", "data/central/n240_lift_complete_37.json"),
        (248, "data/ladder/n248_graph.json", "data/ladder/n248_edgecover_45.json"),
        (252, "data/ladder/n252_graph.json", "data/ladder/n252_edgecover_33.json"),
        (256, "data/ladder/n256_graph.json", "data/ladder/n256_edgecover_40.json"),
        (264, "data/ladder/n264_graph.json", "data/ladder/n264_edgecover_62.json"),
        (272, "data/ladder/n272_graph.json", "data/ladder/n272_edgecover_127.json"),
    ]
    graphs = {}
    for n, graph_rel, cert_rel in graph_specs:
        G, _ = load_graph(root / graph_rel)
        graphs[n] = G
        key = f"n{n}"
        out["checks"][key] = {
            "graph": validate_barnette_graph(G, n),
            "edge_cover": verify_edge_cover(G, load_cycles(root / cert_rel)),
        }

    # Direct-lift scans: independently rerun every legal immediate move.
    direct_specs = [
        (240, "data/central/n240_lift_complete_37.json"),
        (248, "data/ladder/n248_edgecover_45.json"),
        (256, "data/ladder/n256_edgecover_40.json"),
        (264, "data/ladder/n264_edgecover_62.json"),
        (272, "data/ladder/n272_lift_complete_16.json"),
    ]
    for n, cert_rel in direct_specs:
        scan = scan_direct_lift_coverage(graphs[n], load_cycles(root / cert_rel))
        out["checks"][f"n{n}"]["direct_lift_scan"] = scan

    # Assert the key move counts and exact coverage claims.
    assert out["checks"]["n240"]["direct_lift_scan"]["legal_moves"] == 1042
    assert out["checks"]["n240"]["direct_lift_scan"]["children_with_missing_edges"] == 0
    assert out["checks"]["n248"]["direct_lift_scan"]["legal_moves"] == 1050
    assert out["checks"]["n248"]["direct_lift_scan"]["children_with_missing_edges"] == 4
    assert out["checks"]["n248"]["direct_lift_scan"]["max_missing_edges"] == 2
    assert out["checks"]["n256"]["direct_lift_scan"]["legal_moves"] == 1082
    assert out["checks"]["n256"]["direct_lift_scan"]["children_with_missing_edges"] == 0
    assert out["checks"]["n264"]["direct_lift_scan"]["legal_moves"] == 1116
    assert out["checks"]["n264"]["direct_lift_scan"]["children_with_missing_edges"] == 0
    assert out["checks"]["n272"]["direct_lift_scan"]["legal_moves"] == 1174
    assert out["checks"]["n272"]["direct_lift_scan"]["children_with_missing_edges"] == 0
    assert len(load_cycles(root / "data/ladder/n272_lift_complete_16.json")) == 16

    # Explicit support-repair witnesses.  Only positive, checkable cycles are used.
    repairs = {}
    repairs["n248"] = verify_witness_rows(
        graphs[248], root / "data/ladder/n248_missing42_witnesses.json", 42
    )
    verify_single_witness(graphs[252], root / "data/ladder/n252_missing_edge_248_251.json", (248, 251))
    verify_single_witness(graphs[252], root / "data/ladder/n252_missing_edge_249_250.json", (249, 250))
    repairs["n252"] = {"witnesses": 2, "all_explicitly_verified": True}
    repairs["n256"] = verify_witness_rows(
        graphs[256], root / "data/ladder/n256_missing38_witnesses.json", 38
    )
    repairs["n264"] = verify_witness_rows(
        graphs[264], root / "data/ladder/n264_missing60_witnesses.json", 60
    )
    repairs["n272"] = verify_witness_rows(
        graphs[272], root / "data/ladder/n272_missing128_witnesses.json", 128
    )
    assert sum(z["witnesses"] for z in repairs.values()) == 270
    out["checks"]["explicit_support_repairs"] = {
        "by_graph": repairs,
        "total": 270,
        "all_explicitly_verified": True,
    }

    out["checks"]["central_saturation_depth100"] = verify_central_depth100(root)

    # Metadata-only cross-checks for the exhaustive second-level ranking runs.
    rank240 = read_json(root / "data/rankings/n240_second_level.json")
    rank256 = read_json(root / "data/rankings/n256_second_level.json")
    rank264 = read_json(root / "data/rankings/n264_second_level.json")
    assert rank240["summary"]["total_second_moves_scanned"] == 1_094_588
    assert rank256["total_second_moves"] == 1_182_348
    assert rank264["total_second_moves"] == 1_257_652
    out["checks"]["second_level_ranking_metadata"] = {
        "n240": 1_094_588,
        "n256": 1_182_348,
        "n264": 1_257_652,
        "total_labeled_second_moves_ranked": 3_534_588,
        "boundary": "Counts are checked against stored exhaustive ranking outputs; this verifier does not rerun the millions of ranking operations.",
    }

    out["status"] = "ALL_EXPLICIT_CERTIFICATES_VERIFIED"
    text = json.dumps(out, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(text + "\n", encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
