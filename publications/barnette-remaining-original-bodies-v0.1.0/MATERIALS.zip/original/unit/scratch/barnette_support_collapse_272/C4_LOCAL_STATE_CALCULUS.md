# Exact local state calculus for a Barnette \(C_4\)-expansion

## 1. Setup

Let \(G\) be a finite graph and let

\[
p=uv,\qquad q=xy
\]

be two distinct, vertex-disjoint edges on the boundary of one face.  The
\(C_4\)-expansion used in this project removes \(p,q\), introduces four new
vertices \(a,b,c,d\), and inserts

\[
ua,\ ab,\ bv,\ xc,\ cd,\ dy,\ ad,\ bc.
\]

Call the resulting graph \(H\).  No assertion below requires the full
Barnette hypotheses until they are explicitly invoked.

The central observation is elementary but exact: in a Hamilton cycle of
\(H\), each of \(a,b,c,d\) has local degree two.  Enumerating the \(2^8\)
subsets of the eight gadget edges subject to these four degree equations
leaves exactly seven patterns.

## 2. The seven local patterns

Here an entry lists the gadget edges selected by the global Hamilton cycle.

| Label | Selected gadget edges | Boundary terminals used | Parent-side witness |
|---|---|---|---|
| \(D_{11}\) | \(ua,ab,bv,xc,cd,dy\) | \(u,v,x,y\) | Hamilton cycle of \(G\) containing \(p,q\) |
| \(D_{10}\) | \(ua,ad,dc,cb,bv\) | \(u,v\) | Hamilton cycle of \(G\) containing \(p\), not \(q\) |
| \(D_{01}\) | \(xc,cb,ba,ad,dy\) | \(x,y\) | Hamilton cycle of \(G\) containing \(q\), not \(p\) |
| \(X_{vx}\) | \(vb,ba,ad,dc,cx\) | \(v,x\) | Hamilton path \(v\leadsto x\) in \(G-\{p,q\}\) |
| \(X_{uy}\) | \(ua,ab,bc,cd,dy\) | \(u,y\) | Hamilton path \(u\leadsto y\) in \(G-\{p,q\}\) |
| \(L\) | \(ua,ad,dy\) and \(vb,bc,cx\) | \(u,v,x,y\) | spanning two-path linkage in \(G-\{p,q\}\) |
| \(O\) | \(ab,bc,cd,da\) | none | isolated central four-cycle |

Pattern \(O\) cannot occur in a Hamilton cycle of \(H\) when \(H\) has any
old vertices: it is already a closed component disjoint from the rest of the
cycle.  Thus exactly six usable local patterns remain.

The linkage witness in row \(L\) is the following precise object.  In
\(G-\{p,q\}\), take two vertex-disjoint paths whose union contains every
vertex of \(G\), whose four endpoints are \(u,v,x,y\), and whose endpoint
pairing is different from

\[
\bigl\{\{u,y\},\{v,x\}\bigr\}.
\]

The excluded pairing is exactly the pairing already made inside the gadget;
using it outside would create two disjoint cycles.  Either of the other two
pairings combines with the gadget to make one spanning cycle.

## 3. Exact six-witness criterion

**Theorem 1 (exact local criterion).**  The expanded graph \(H\) is
Hamiltonian if and only if at least one of the following exists in \(G\):

1. a Hamilton cycle containing both \(p,q\);
2. a Hamilton cycle containing \(p\) but not \(q\);
3. a Hamilton cycle containing \(q\) but not \(p\);
4. a Hamilton path from \(v\) to \(x\) avoiding \(p,q\);
5. a Hamilton path from \(u\) to \(y\) avoiding \(p,q\);
6. the spanning two-path linkage described above.

**Proof.**  For necessity, intersect any Hamilton cycle of \(H\) with the
eight gadget edges.  The four new vertices all have degree two, hence the
intersection is one of the seven rows of the table.  Row \(O\) is impossible.
Deleting the gadget from each of the other six rows gives exactly the listed
parent-side witness.

For sufficiency, attach the corresponding gadget path or paths shown in the
table to the stated parent-side witness.  Every old and new vertex then has
degree two, and the pairing condition in row \(L\) guarantees connectedness.
The result is a Hamilton cycle of \(H\).  ∎

### Immediate corollary

If a Hamilton cycle of \(G\) contains at least one of \(p,q\), then \(H\) is
Hamiltonian.  This is the direct-lift lemma used throughout the finite search.

The theorem is stronger: failure of all direct lifts does **not** establish
non-Hamiltonicity, because either cross Hamilton path or the two-path linkage
may still create a cycle.

## 4. Direct-lift edge coverage

Let \(\mathcal F\) be a finite family of Hamilton cycles of \(G\), and define

\[
S_{\mathcal F}(e)=\{C\in\mathcal F:e\in C\}.
\]

Directly lift every \(C\in\mathcal F\) that contains \(p\) or \(q\).
These lifted cycles cover every edge of \(H\) if and only if both conditions
below hold.

### Old-edge condition

For every retained old edge \(g\in E(G)\setminus\{p,q\}\),

\[
S_{\mathcal F}(g)\cap
\bigl(S_{\mathcal F}(p)\cup S_{\mathcal F}(q)\bigr)\ne\varnothing.
\]

### Gadget-state condition

At least two of the three direct states

\[
11,\qquad 10,\qquad 01
\]

occur in \(\mathcal F\).  Each single state misses gadget edges, while the
union of any two distinct states contains all eight gadget edges.

This criterion is what the package calls **lift-completeness** for the chosen
family \(\mathcal F\).

If all Hamilton cycles of \(G\) are used, the old-edge condition says that
\(\{p,q\}\) is a dominating pair in the Hamilton-compatibility graph on
\(E(G)\).  Under edge-Hamiltonicity, the gadget-state condition fails exactly
when \(p,q\) have identical Hamilton-cycle support sets—what the exploratory
notes call *Hamilton twins*.

## 5. Central saturation transfer

For the oriented pair \(p=uv,q=xy\), define a **saturation package** to consist
of five explicit witnesses:

\[
\mathcal P=(C_{11},C_{10},C_{01},X_{vx},X_{uy}),
\]

where the first three are Hamilton cycles in the indicated direct states and
\(X_{vx},X_{uy}\) are the two cross Hamilton paths in Theorem 1.

After expanding \(p,q\), consider the two opposite central edges

\[
p'=bc,\qquad q'=da.
\]

**Theorem 2 (central saturation transfer).**  If \((G,p,q)\) has a saturation
package, then \((H,p',q')\) also has a saturation package.

### Explicit construction

- \(C'_{11}\): lift \(C_{10}\) through the local path
  \(u-a-d-c-b-v\).  It contains both \(bc\) and \(da\).
- \(C'_{10}\): close \(X_{uy}\) with
  \(u-a-b-c-d-y\).  It contains \(bc\), not \(da\).
- \(C'_{01}\): close \(X_{vx}\) with
  \(v-b-a-d-c-x\).  It contains \(da\), not \(bc\).
- \(X'_{c d}\): delete \(p,q\) from \(C_{11}\), then add
  \(u-a-b-v\), \(x-c\), and \(d-y\).  The result is a Hamilton path
  from \(c\) to \(d\).
- \(X'_{b a}\): delete \(p,q\) from \(C_{11}\), then add
  \(u-a\), \(v-b\), and \(x-c-d-y\).  The result is a Hamilton path
  from \(b\) to \(a\).

All five claims follow by checking degrees and connectivity after deleting the
two selected edges from the parent witness.  They are also reconstructed by
the independent verifier in this package.

### Infinite consequence

Theorem 2 can be iterated.  Therefore, once one expansion site possesses the
five-witness package, repeatedly expanding the newly created opposite central
pair can never produce a non-Hamiltonian graph.

The included finite certificate reconstructs 100 such iterations,

\[
240\longrightarrow244\longrightarrow\cdots\longrightarrow640,
\]

as a sanity check of the formulas.  The infinite statement follows from the
local transfer proof, not from extrapolating the finite computation.

## 6. Logical boundary

These results do **not** prove Barnette's conjecture and do not prove that
edge-Hamiltonicity or lift-completeness is preserved under every legal
\(C_4\)-expansion.  They establish:

1. an exact classification of how any Hamilton cycle can traverse one
   expansion gadget;
2. an exact parent-side criterion for Hamiltonicity of that one child;
3. a sufficient direct-lift coverage criterion;
4. an infinite safe route for recursively expanding a saturated central pair.

The literature novelty of this formulation has not been audited.  It should
be treated as a proved project lemma, not yet as a claim of a new published
theorem.
