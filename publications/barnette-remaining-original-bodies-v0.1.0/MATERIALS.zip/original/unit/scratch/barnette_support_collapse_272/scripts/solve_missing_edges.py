#!/usr/bin/env python3
from __future__ import annotations
import json,argparse,sys,os,time
from pathlib import Path
from dataclasses import asdict
from concurrent.futures import ProcessPoolExecutor,as_completed
import networkx as nx
sys.path.insert(0,'/mnt/data/barnette_work/cont240/barnette_continuation_240/code')
from forced_hamiltonian import solve
G=None

def init_worker(candidate):
 global G
 d=json.load(open(candidate));G=nx.from_graph6_bytes(d['grandchild_graph6'].encode())

def task(x):
 idx,e,tl=x;r=solve(G,forced_in=[e],time_limit=tl,max_rounds=50000,seed=1000003*idx+17)
 return {'missing_edge_index':idx,'edge':e,'result':asdict(r)}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('candidate');ap.add_argument('--time-limit',type=float,default=10);ap.add_argument('--workers',type=int,default=5);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();d=json.load(open(a.candidate));tasks=[(i,e,a.time_limit) for i,e in enumerate(d['missing_edges'])];rows=[];t0=time.time()
 with ProcessPoolExecutor(max_workers=a.workers,initializer=init_worker,initargs=(a.candidate,)) as ex:
  futs={ex.submit(task,t):t for t in tasks}
  for f in as_completed(futs):
   r=f.result();rows.append(r);z=r['result'];print(r['missing_edge_index'],r['edge'],z['status'],round(z['seconds'],3),z['rounds'],z['cuts'],flush=True)
 rows.sort(key=lambda z:z['missing_edge_index']);payload={'schema':'missing-edge-hamilton-support-v1','candidate':a.candidate,'time_limit':a.time_limit,'elapsed_seconds':time.time()-t0,'rows':rows,'summary':{}}
 from collections import Counter
 payload['summary']=dict(Counter(r['result']['status'] for r in rows));a.output.write_text(json.dumps(payload,indent=2));print(payload['summary'])
if __name__=='__main__':main()
