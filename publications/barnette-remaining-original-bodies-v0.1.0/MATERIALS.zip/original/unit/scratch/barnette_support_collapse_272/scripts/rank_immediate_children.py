#!/usr/bin/env python3
from __future__ import annotations
import json,argparse,time,heapq,sys,hashlib
from pathlib import Path
import networkx as nx
sys.path.insert(0,'/mnt/data/barnette_work')
from search_cross_paths import load_graph,valid_c4_moves,edge

def CE(c):return {edge(c[i],c[(i+1)%len(c)]) for i in range(len(c))}
def expand(G,face,i,j):
 L=len(face);u,v=face[i],face[(i+1)%L];x,y=face[j],face[(j+1)%L];p=edge(u,v);q=edge(x,y);H=G.copy();n=max(H)+1;a,b,c,d=range(n,n+4);H.remove_edge(*p);H.remove_edge(*q);H.add_edges_from([(u,a),(a,b),(b,v),(x,c),(c,d),(d,y),(a,d),(b,c)]);return H,{'u':u,'v':v,'x':x,'y':y,'p':p,'q':q,'a':a,'b':b,'c':c,'d':d,'new_vertices':[a,b,c,d]}
def lift(E,r):
 u,v,x,y,p,q,a,b,c,d=[r[k] for k in ('u','v','x','y','p','q','a','b','c','d')];h1=p in E;h2=q in E
 if not(h1 or h2):return None
 z=set(E)-{p,q}
 if h1 and h2:loc=[(u,a),(a,b),(b,v),(x,c),(c,d),(d,y)]
 elif h1:loc=[(u,a),(a,d),(d,c),(c,b),(b,v)]
 else:loc=[(x,c),(c,b),(b,a),(a,d),(d,y)]
 z.update(edge(*t) for t in loc);return z

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--graph',required=True);ap.add_argument('--certificate',required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--top',type=int,default=100);a=ap.parse_args();G=load_graph(a.graph);C=[CE(c) for c in json.load(open(a.certificate))['certificate_cycles']];rows=[];t0=time.time()
 for idx,(face,i,j) in enumerate(valid_c4_moves(G)):
  H,r=expand(G,face,i,j);lifted=[z for E in C if (z:=lift(E,r)) is not None];union=set().union(*lifted) if lifted else set();HE={edge(u,v) for u,v in H.edges()};missing=sorted(HE-union)
  p,q=r['p'],r['q'];states={'11':sum(p in E and q in E for E in C),'10':sum(p in E and q not in E for E in C),'01':sum(p not in E and q in E for E in C)}
  rows.append({'move_index':idx,'face':list(face),'i':i,'j':j,'face_length':len(face),'selected_edges':[list(p),list(q)],'new_vertices':r['new_vertices'],'lifted_cycles':len(lifted),'parent_state_counts':states,'child_vertices':len(H),'child_edges':H.number_of_edges(),'missing_edge_count':len(missing),'missing_edges':[list(e) for e in missing],'child_graph6':nx.to_graph6_bytes(H,header=False).decode().strip()})
 rows.sort(key=lambda z:(z['missing_edge_count'],-z['lifted_cycles'],z['face_length']),reverse=True);payload={'schema':'immediate-child-support-ranking-v1','source_graph':a.graph,'source_certificate':a.certificate,'parent_vertices':len(G),'parent_cycles':len(C),'legal_moves':len(rows),'elapsed_seconds':time.time()-t0,'summary':{'children_fully_edge_covered_by_direct_lifts':sum(r['missing_edge_count']==0 for r in rows),'children_with_missing_edges':sum(r['missing_edge_count']>0 for r in rows),'max_missing_edges':rows[0]['missing_edge_count']},'top':rows[:a.top]};a.output.write_text(json.dumps(payload,indent=2));print(json.dumps(payload['summary'],indent=2));
 for r in rows[:10]:print(r['move_index'],r['face_length'],r['selected_edges'],'lift',r['lifted_cycles'],'states',r['parent_state_counts'],'missing',r['missing_edge_count'])
if __name__=='__main__':main()
