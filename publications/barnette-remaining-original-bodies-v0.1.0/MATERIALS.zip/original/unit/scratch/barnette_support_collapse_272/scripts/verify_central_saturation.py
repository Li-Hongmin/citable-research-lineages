#!/usr/bin/env python3
from __future__ import annotations
import json,hashlib,sys,argparse
from pathlib import Path
from collections import Counter
import networkx as nx
sys.path.insert(0,'/mnt/data/barnette_work')
from search_cross_paths import load_graph,valid_c4_moves,edge

def edges_cycle(seq):return {edge(seq[i],seq[(i+1)%len(seq)]) for i in range(len(seq))}
def edges_path(seq):return {edge(seq[i],seq[i+1]) for i in range(len(seq)-1)}

def recover(G,E,endpoints=None):
 F=nx.Graph();F.add_nodes_from(G.nodes());F.add_edges_from(E)
 n=G.number_of_nodes()
 if endpoints is None:
  assert len(E)==n and nx.is_connected(F) and all(d==2 for _,d in F.degree())
  start=min(G.nodes());out=[start];prev=None;cur=start
  for _ in range(n-1):
   ns=[z for z in F.neighbors(cur) if z!=prev];assert len(ns)==1 if prev is not None else len(ns)==2
   nxt=min(ns) if prev is None else ns[0];out.append(nxt);prev,cur=cur,nxt
  assert F.has_edge(cur,start);return out
 s,t=endpoints
 assert len(E)==n-1 and nx.is_connected(F)
 assert F.degree(s)==F.degree(t)==1 and all(F.degree(z)==(1 if z in (s,t) else 2) for z in G.nodes())
 out=[s];prev=None;cur=s
 for _ in range(n-1):
  ns=[z for z in F.neighbors(cur) if z!=prev];assert len(ns)==1
  nxt=ns[0];out.append(nxt);prev,cur=cur,nxt
 assert cur==t;return out

def expand(G,face,i,j):
 L=len(face);u,v=face[i],face[(i+1)%L];x,y=face[j],face[(j+1)%L];p=edge(u,v);q=edge(x,y)
 H=G.copy();n=max(H.nodes())+1;a,b,c,d=range(n,n+4)
 H.remove_edge(*p);H.remove_edge(*q)
 H.add_edges_from([(u,a),(a,b),(b,v),(x,c),(c,d),(d,y),(a,d),(b,c)])
 return H,{'u':u,'v':v,'x':x,'y':y,'p':p,'q':q,'a':a,'b':b,'c':c,'d':d,'face':list(face),'i':i,'j':j}

def state(C,p,q):
 E=edges_cycle(C);return f'{int(p in E)}{int(q in E)}'

def verify_package(G,face,i,j,P):
 L=len(face);u,v=face[i],face[(i+1)%L];x,y=face[j],face[(j+1)%L];p=edge(u,v);q=edge(x,y)
 assert state(P['C11'],p,q)=='11';assert state(P['C10'],p,q)=='10';assert state(P['C01'],p,q)=='01'
 for key in ('C11','C10','C01'):
  assert len(P[key])==G.number_of_nodes();assert recover(G,edges_cycle(P[key]))
 assert P['X_vx'][0]==v and P['X_vx'][-1]==x
 assert P['X_uy'][0]==u and P['X_uy'][-1]==y
 for key,ends in [('X_vx',(v,x)),('X_uy',(u,y))]:
  E=edges_path(P[key]);assert p not in E and q not in E;assert recover(G,E,ends)
 return {'p':p,'q':q,'oriented':[u,v,x,y]}

def transfer(G,face,i,j,P):
 verify_package(G,face,i,j,P)
 H,r=expand(G,face,i,j);u,v,x,y=r['u'],r['v'],r['x'],r['y'];p,q=r['p'],r['q'];a,b,c,d=r['a'],r['b'],r['c'],r['d']
 P11={edge(*z) for z in [(u,a),(a,b),(b,v),(x,c),(c,d),(d,y)]}
 P10={edge(*z) for z in [(u,a),(a,d),(d,c),(c,b),(b,v)]}
 P01={edge(*z) for z in [(x,c),(c,b),(b,a),(a,d),(d,y)]}
 # child C11: lift parent C10; child central edges are p'=(b,c), q'=(d,a)
 E_C11=(edges_cycle(P['C10'])-{p,q})|P10
 # exact-one child cycles from the two cross Hamilton paths
 E_C10=edges_path(P['X_uy'])|{edge(*z) for z in [(u,a),(a,b),(b,c),(c,d),(d,y)]}
 E_C01=edges_path(P['X_vx'])|{edge(*z) for z in [(v,b),(b,a),(a,d),(d,c),(c,x)]}
 # child cross paths from parent C11 by deleting one selected edge
 E0=edges_cycle(P['C11'])-{p,q}
 E_Xuy=E0|{edge(*z) for z in [(u,a),(v,b),(x,c),(c,d),(d,y)]} # endpoints b,a; orientation reverse below
 E_Xvx=E0|{edge(*z) for z in [(u,a),(a,b),(b,v),(x,c),(d,y)]} # endpoints c,d
 C11=recover(H,E_C11);C10=recover(H,E_C10);C01=recover(H,E_C01)
 Xvx=recover(H,E_Xvx,(c,d));Xuy=recover(H,E_Xuy,(b,a))
 Pn={'C11':C11,'C10':C10,'C01':C01,'X_vx':Xvx,'X_uy':Xuy}
 fn=(a,b,c,d);ii,jj=1,3
 verify_package(H,fn,ii,jj,Pn)
 # also verify the omitted state 00 obtained from C11 parent
 C00=recover(H,(edges_cycle(P['C11'])-{p,q})|P11)
 assert state(C00,edge(b,c),edge(d,a))=='00'
 return H,fn,ii,jj,Pn,C00,r

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--graph',required=True);ap.add_argument('--certificate',required=True);ap.add_argument('--crosspaths',required=True);ap.add_argument('--move-index',type=int,required=True);ap.add_argument('--depth',type=int,default=50);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 G=load_graph(a.graph);moves=valid_c4_moves(G);face,i,j=moves[a.move_index];L=len(face);u,v=face[i],face[(i+1)%L];x,y=face[j],face[(j+1)%L];p=edge(u,v);q=edge(x,y)
 cert=json.load(open(a.certificate));cycles=cert['certificate_cycles']
 def pick(st):
  for c in cycles:
   if state(c,p,q)==st:return c
  raise ValueError(st)
 hp=json.load(open(a.crosspaths));rows={r['which']:r for r in hp['rows'] if r['move_index']==a.move_index}
 P={'C11':pick('11'),'C10':pick('10'),'C01':pick('01'),'X_vx':rows['vx']['result']['path'],'X_uy':rows['uy']['result']['path']}
 verify_package(G,face,i,j,P)
 report={'schema':'central-saturation-certificate-v1','source_graph':a.graph,'source_certificate':a.certificate,'source_crosspaths':a.crosspaths,'initial_move_index':a.move_index,'depth':a.depth,'theorem_boundary':'finite verification illustrates a separately proved local transfer lemma; it is not a proof of Barnette conjecture','levels':[]}
 for k in range(a.depth+1):
  meta=verify_package(G,face,i,j,P);g6=nx.to_graph6_bytes(G,header=False).strip();entry={'level':k,'vertices':G.number_of_nodes(),'edges':G.number_of_edges(),'graph6_sha256':hashlib.sha256(g6).hexdigest(),'selected_edges':[list(meta['p']),list(meta['q'])],'states':{z:state(P[z],meta['p'],meta['q']) for z in ('C11','C10','C01')},'certificate_hashes':{z:hashlib.sha256(json.dumps(P[z]).encode()).hexdigest() for z in P}}
  if k in (0,1,a.depth):entry['certificates']=P
  report['levels'].append(entry)
  if k==a.depth:break
  G,face,i,j,P,C00,r=transfer(G,face,i,j,P)
  report['levels'][-1]['expansion_record']={z:(list(vv) if isinstance(vv,tuple) else vv) for z,vv in r.items()}
 a.output.write_text(json.dumps(report,indent=2))
 print(json.dumps({'status':'verified','levels':len(report['levels']),'vertices_final':report['levels'][-1]['vertices'],'output':str(a.output)},indent=2))
if __name__=='__main__':main()
