#!/usr/bin/env python3
from __future__ import annotations
import json,time,argparse
from pathlib import Path
from dataclasses import dataclass,asdict
import networkx as nx
import numpy as np
from scipy.optimize import Bounds,LinearConstraint,milp
from scipy.sparse import lil_matrix,vstack

Edge=tuple[int,int]
def edge(u,v): return (u,v) if u<v else (v,u)

def planar_faces(G):
    ok,emb=nx.check_planarity(G,counterexample=False)
    if not ok: raise ValueError('nonplanar')
    visited=set(); faces=[]
    for u,v in emb.edges():
        if (u,v) not in visited:
            faces.append(tuple(emb.traverse_face(u,v,visited)))
    return faces

def valid_c4_moves(G):
    out=[]
    for face in planar_faces(G):
        L=len(face)
        if L<4 or L%2: continue
        for i in range(L):
            for j in range(i+1,L):
                if {face[i],face[(i+1)%L]} & {face[j],face[(j+1)%L]}: continue
                if (j-i)%2==0: out.append((face,i,j))
    return out

@dataclass
class Result:
    status:str; rounds:int; cuts:int; seconds:float; path:list[int]|None; solver_status:int; message:str

class HamiltonPathModel:
    def __init__(self,G:nx.Graph):
        self.G=G; self.nodes=sorted(G); self.ni={v:i for i,v in enumerate(self.nodes)}
        self.edges=[edge(u,v) for u,v in G.edges()]; self.ei={e:i for i,e in enumerate(self.edges)}
        self.n=len(self.nodes); self.m=len(self.edges)
        deg=lil_matrix((self.n,self.m),dtype=float)
        for k,(u,v) in enumerate(self.edges): deg[self.ni[u],k]=1;deg[self.ni[v],k]=1
        self.deg=deg.tocsr()
    def solve(self,s:int,t:int,forbidden=(),time_limit=2.0,max_rounds=2000,seed=0):
        if s==t: return Result('infeasible',0,0,0,None,2,'same endpoints')
        lb=np.zeros(self.m);ub=np.ones(self.m)
        for e in forbidden:
            e=edge(*e)
            if e in self.ei: ub[self.ei[e]]=0
        rhs=np.full(self.n,2.0);rhs[self.ni[s]]=1;rhs[self.ni[t]]=1
        mats=[self.deg];lbs=[rhs];ubs=[rhs];keys=set();start=time.monotonic()
        rng=np.random.default_rng(seed);obj=rng.normal(scale=1e-7,size=self.m)
        for r in range(max_rounds):
            rem=time_limit-(time.monotonic()-start)
            if rem<=0:return Result('unknown',r,len(keys),time.monotonic()-start,None,1,'time limit')
            res=milp(obj,integrality=np.ones(self.m),bounds=Bounds(lb,ub),
                     constraints=LinearConstraint(vstack(mats,format='csr'),np.concatenate(lbs),np.concatenate(ubs)),
                     options={'time_limit':max(.02,rem),'mip_rel_gap':0.,'presolve':True})
            elapsed=time.monotonic()-start
            if res.status==2:return Result('infeasible',r+1,len(keys),elapsed,None,int(res.status),str(res.message))
            if not res.success or res.x is None:return Result('unknown',r+1,len(keys),elapsed,None,int(res.status),str(res.message))
            chosen=[self.edges[k] for k,x in enumerate(res.x) if x>.5]
            F=nx.Graph();F.add_nodes_from(self.nodes);F.add_edges_from(chosen)
            comps=list(nx.connected_components(F))
            if len(comps)==1:
                path=[s];prev=None;cur=s
                for _ in range(self.n-1):
                    ns=[x for x in F.neighbors(cur) if x!=prev]
                    if len(ns)!=1: return Result('unknown',r+1,len(keys),elapsed,None,-1,f'bad path degree at {cur}: {ns}')
                    nxt=ns[0];path.append(nxt);prev,cur=cur,nxt
                if cur!=t:return Result('unknown',r+1,len(keys),elapsed,None,-1,'wrong endpoint')
                return Result('path',r+1,len(keys),elapsed,path,int(res.status),str(res.message))
            added=0;alln=set(self.nodes)
            for C in comps:
                if s in C or t in C: continue
                S=set(C);T=alln-S;a=tuple(sorted(S));b=tuple(sorted(T));key=a if (len(a),a)<=(len(b),b) else b
                if key in keys:continue
                keys.add(key);row=lil_matrix((1,self.m),dtype=float)
                for e,k in self.ei.items():
                    if (e[0] in S)!=(e[1] in S):row[0,k]=1
                mats.append(row.tocsr());lbs.append(np.array([2.]));ubs.append(np.array([np.inf]));added+=1
            if not added:return Result('unknown',r+1,len(keys),elapsed,None,-1,'no new cut')
        return Result('unknown',max_rounds,len(keys),time.monotonic()-start,None,1,'round limit')

def load_graph(path):
    d=json.load(open(path));g6=d.get('graph6') or d.get('current_graph6') or d['results'][-1]['graph6'];return nx.from_graph6_bytes(g6.encode())

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('graph');ap.add_argument('--start',type=int,default=0);ap.add_argument('--count',type=int,default=20);ap.add_argument('--time-limit',type=float,default=2.0);ap.add_argument('--output',type=Path);a=ap.parse_args()
    G=load_graph(a.graph);moves=valid_c4_moves(G);model=HamiltonPathModel(G);rows=[]
    for idx in range(a.start,min(len(moves),a.start+a.count)):
        face,i,j=moves[idx];L=len(face);u,v=face[i],face[(i+1)%L];x,y=face[j],face[(j+1)%L];p=edge(u,v);q=edge(x,y)
        r10=model.solve(v,x,[p,q],a.time_limit,seed=1000003*idx+1)
        r01=model.solve(u,y,[p,q],a.time_limit,seed=1000003*idx+2)
        row={'move_index':idx,'face':list(face),'i':i,'j':j,'edges':[list(p),list(q)],'cross_vx':asdict(r10),'cross_uy':asdict(r01)};rows.append(row)
        print(idx,len(face),p,q,r10.status,round(r10.seconds,3),r01.status,round(r01.seconds,3),flush=True)
    if a.output:a.output.write_text(json.dumps({'graph':a.graph,'moves_total':len(moves),'rows':rows},indent=2))
