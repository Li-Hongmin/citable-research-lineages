#!/usr/bin/env python3
import argparse,json,time,sys,importlib.util
from pathlib import Path
import networkx as nx
spec=importlib.util.spec_from_file_location('rs','/mnt/data/barnette_work/rank_second_level_failures.py');rs=importlib.util.module_from_spec(spec);spec.loader.exec_module(rs)
sys.path.insert(0,'/mnt/data/barnette_work')
from search_cross_paths import load_graph,valid_c4_moves
ap=argparse.ArgumentParser();ap.add_argument('--graph',required=True);ap.add_argument('--certificate',required=True);ap.add_argument('--start',type=int,required=True);ap.add_argument('--end',type=int,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--top-moves',type=int,default=20);a=ap.parse_args()
G=load_graph(a.graph);cert=json.load(open(a.certificate));parent=[rs.cycle_edges(c) for c in cert['certificate_cycles']];moves=valid_c4_moves(G);rows=[];t=time.time()
for idx in range(a.start,min(a.end,len(moves))):
 face,i,j=moves[idx];H,r=rs.expand(G,face,i,j);lifted=[]
 for E in parent:
  z=rs.lift_edges(E,r)
  if z is not None:lifted.append(z)
 met=rs.child_metrics(H,lifted,a.top_moves);met.update({'first_move_index':idx,'first_face':list(face),'first_i':i,'first_j':j,'first_face_length':len(face),'first_edges':[list(r['p']),list(r['q'])],'child_vertices':H.number_of_nodes(),'lifted_cycles':len(lifted)})
 rows.append(met)
 if (idx-a.start)%100==0:print(idx,met['failed_second_moves'],met['max_missing_old_edges'],flush=True)
a.output.write_text(json.dumps({'start':a.start,'end':min(a.end,len(moves)),'elapsed':time.time()-t,'rows':rows},indent=2));print('done',a.start,a.end,len(rows),round(time.time()-t,2))
