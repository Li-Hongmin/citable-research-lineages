#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,time,heapq,hashlib,sys
from pathlib import Path
import networkx as nx
sys.path.insert(0,'/mnt/data/barnette_work')
from search_cross_paths import load_graph,valid_c4_moves,edge

def cycle_edges(c):return {edge(c[i],c[(i+1)%len(c)]) for i in range(len(c))}

def expand(G,face,i,j):
 L=len(face);u,v=face[i],face[(i+1)%L];x,y=face[j],face[(j+1)%L];p=edge(u,v);q=edge(x,y)
 H=G.copy();n=max(H)+1;a,b,c,d=range(n,n+4)
 H.remove_edge(*p);H.remove_edge(*q);H.add_edges_from([(u,a),(a,b),(b,v),(x,c),(c,d),(d,y),(a,d),(b,c)])
 return H,{'u':u,'v':v,'x':x,'y':y,'p':p,'q':q,'a':a,'b':b,'c':c,'d':d}

def lift_edges(E,r):
 u,v,x,y,p,q,a,b,c,d=[r[k] for k in ('u','v','x','y','p','q','a','b','c','d')]
 h1=p in E;h2=q in E
 if not(h1 or h2):return None
 out=set(E);out.discard(p);out.discard(q)
 if h1 and h2: loc=[(u,a),(a,b),(b,v),(x,c),(c,d),(d,y)]
 elif h1: loc=[(u,a),(a,d),(d,c),(c,b),(b,v)]
 else: loc=[(x,c),(c,b),(b,a),(a,d),(d,y)]
 out.update(edge(*z) for z in loc);return out

def child_metrics(H,cycles,topk=10):
 hedges=sorted(edge(u,v) for u,v in H.edges());ei={e:k for k,e in enumerate(hedges)};m=len(hedges);allbits=(1<<m)-1
 c_edge_bits=[];support=[0]*m
 for ci,E in enumerate(cycles):
  bits=0
  for e in E:
   k=ei[e];bits|=1<<k;support[k]|=1<<ci
  c_edge_bits.append(bits)
 fullmask=(1<<len(cycles))-1
 cache={0:0}
 def union_for(mask):
  z=cache.get(mask)
  if z is not None:return z
  u=0;x=mask
  while x:
   l=x&-x;i=l.bit_length()-1;u|=c_edge_bits[i];x-=l
  cache[mask]=u;return u
 fail_count=0;total_missing_old=0;max_missing_old=0;state_fail=0;min_states=3;worst=[]
 moves=valid_c4_moves(H)
 for idx,(face,i,j) in enumerate(moves):
  L=len(face);r=edge(face[i],face[(i+1)%L]);s=edge(face[j],face[(j+1)%L]);ri=ei[r];si=ei[s]
  sr,ss=support[ri],support[si];elig=sr|ss;un=union_for(elig)
  retained=allbits & ~(1<<ri) & ~(1<<si);missing=(retained & ~un).bit_count()
  states=int(bool(sr&ss))+int(bool(sr&(~ss&fullmask)))+int(bool(ss&(~sr&fullmask)))
  min_states=min(min_states,states);bad=missing>0 or states<2
  if bad:
   fail_count+=1;total_missing_old+=missing;max_missing_old=max(max_missing_old,missing);state_fail+=states<2
   # high score = old gaps first, then state deficit, then low eligible cycle count
   score=(missing,2-states,-elig.bit_count(),len(face))
   rec={'second_move_index':idx,'face':list(face),'i':i,'j':j,'face_length':len(face),'edges':[list(r),list(s)],'eligible_cycles':elig.bit_count(),'state_count':states,'state_masks':{'11':(sr&ss).bit_count(),'10':(sr&(~ss&fullmask)).bit_count(),'01':(ss&(~sr&fullmask)).bit_count()},'missing_old_edges':missing,'score':list(score)}
   if len(worst)<topk:heapq.heappush(worst,(score,idx,rec))
   elif score>worst[0][0]:heapq.heapreplace(worst,(score,idx,rec))
 return {'second_moves':len(moves),'failed_second_moves':fail_count,'total_missing_old_edges':total_missing_old,'max_missing_old_edges':max_missing_old,'state_failure_moves':state_fail,'min_state_count':min_states,'distinct_eligible_masks':len(cache),'worst': [z[2] for z in sorted(worst,reverse=True)]}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--graph',required=True);ap.add_argument('--certificate',required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--top-children',type=int,default=30);ap.add_argument('--top-moves',type=int,default=10);a=ap.parse_args()
 G=load_graph(a.graph);cert=json.load(open(a.certificate));parent=[cycle_edges(c) for c in cert['certificate_cycles']];moves=valid_c4_moves(G);rows=[];t0=time.time()
 for idx,(face,i,j) in enumerate(moves):
  H,r=expand(G,face,i,j);lifted=[]
  for E in parent:
   z=lift_edges(E,r)
   if z is not None:lifted.append(z)
  met=child_metrics(H,lifted,a.top_moves);met.update({'first_move_index':idx,'first_face':list(face),'first_i':i,'first_j':j,'first_face_length':len(face),'first_edges':[list(r['p']),list(r['q'])],'child_vertices':H.number_of_nodes(),'lifted_cycles':len(lifted),'child_graph6':nx.to_graph6_bytes(H,header=False).decode().strip()})
  rows.append(met)
  if idx%50==0:print(idx,'/',len(moves),'fail2',met['failed_second_moves'],'maxmiss',met['max_missing_old_edges'],'states',met['state_failure_moves'],'elapsed',round(time.time()-t0,1),flush=True)
 # Ranking: many failures, then total old-edge gaps, then max gap, then state failures.
 rows.sort(key=lambda z:(z['failed_second_moves'],z['total_missing_old_edges'],z['max_missing_old_edges'],z['state_failure_moves']),reverse=True)
 payload={'schema':'barnette-second-level-support-ranking-v1','source_graph':a.graph,'source_certificate':a.certificate,'parent_vertices':G.number_of_nodes(),'parent_cycles':len(parent),'first_moves':len(moves),'elapsed_seconds':time.time()-t0,'ranking_rule':['failed_second_moves','total_missing_old_edges','max_missing_old_edges','state_failure_moves'],'top_children':rows[:a.top_children],
 'summary':{'children_with_any_failure':sum(r['failed_second_moves']>0 for r in rows),'max_failed_second_moves':rows[0]['failed_second_moves'],'max_missing_old_edges':max(r['max_missing_old_edges'] for r in rows),'total_second_moves_scanned':sum(r['second_moves'] for r in rows)}}
 a.output.write_text(json.dumps(payload,indent=2));print(json.dumps(payload['summary'],indent=2))
if __name__=='__main__':main()
