#!/usr/bin/env python3
from __future__ import annotations
import json,argparse,random,time,sys,hashlib
from pathlib import Path
import networkx as nx
sys.path.insert(0,'/mnt/data/barnette_work')
from search_cross_paths import load_graph,valid_c4_moves,edge

def CE(c):return {edge(c[i],c[(i+1)%len(c)]) for i in range(len(c))}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--graph',required=True);ap.add_argument('--certificate',required=True);ap.add_argument('--seed',type=int,default=0);ap.add_argument('--passes',type=int,default=3);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();G=load_graph(a.graph);data=json.load(open(a.certificate));cycles=data['certificate_cycles'];sets=[CE(c) for c in cycles];edges=sorted(edge(u,v) for u,v in G.edges());ei={e:i for i,e in enumerate(edges)};m=len(edges);allbits=(1<<m)-1;n=len(cycles);cb=[];support=[0]*m
 for ci,E in enumerate(sets):
  z=0
  for e in E:k=ei[e];z|=1<<k;support[k]|=1<<ci
  cb.append(z)
 moves=[]
 for face,i,j in valid_c4_moves(G):
  L=len(face);p=ei[edge(face[i],face[(i+1)%L])];q=ei[edge(face[j],face[(j+1)%L])];moves.append((p,q))
 def check(mask):
  cache={0:0}
  for p,q in moves:
   sp=support[p]&mask;sq=support[q]&mask;elig=sp|sq
   if not elig:return False
   union=cache.get(elig)
   if union is None:
    union=0;x=elig
    while x:
     l=x&-x;k=l.bit_length()-1;union|=cb[k];x-=l
    cache[elig]=union
   retained=allbits&~(1<<p)&~(1<<q)
   if retained&~union:return False
   full=mask;states=int(bool(sp&sq))+int(bool(sp&(~sq&full)))+int(bool(sq&(~sp&full)))
   if states<2:return False
  return True
 full=(1<<n)-1;assert check(full);mask=full;rng=random.Random(a.seed);t=time.time();history=[]
 for ps in range(a.passes):
  order=[i for i in range(n) if mask>>i&1];rng.shuffle(order);removed=0
  for z,i in enumerate(order):
   trial=mask&~(1<<i)
   if check(trial):mask=trial;removed+=1
  history.append({'pass':ps,'start':len(order),'removed':removed,'remaining':mask.bit_count(),'elapsed':time.time()-t});print(history[-1],flush=True)
  if not removed:break
 selected=[i for i in range(n) if mask>>i&1];out={'schema':'pruned-lift-complete-certificate-v1','source_graph':a.graph,'source_certificate':a.certificate,'seed':a.seed,'passes':history,'original_cycles':n,'selected_cycle_count':len(selected),'selected_source_indices':selected,'certificate_cycles':[cycles[i] for i in selected],'verification':{'all_moves':len(moves),'lift_complete':check(mask)}};a.output.write_text(json.dumps(out,indent=2));print(json.dumps({'original':n,'selected':len(selected),'moves':len(moves),'seconds':time.time()-t},indent=2))
if __name__=='__main__':main()
