# Barnette support-collapse certificate package

This package accompanies the report `REPORT.md`.

## Reproduce the explicit checks

```bash
python verify_master.py --output VERIFICATION.json
```

Dependency: Python 3.11+ and NetworkX 3.x.  On the creation environment the
complete explicit verification took about 19 seconds.

The verifier checks positive finite certificates only.  It does not prove
Barnette's conjecture, and it does not treat solver timeout as evidence of
nonexistence.

## Main files

- `REPORT.md`: Chinese research report and exact claim boundary.
- `C4_LOCAL_STATE_CALCULUS.md`: mathematical statement and proof of the
  six-witness local criterion and central saturation transfer.
- `data/ladder/n272_lift_complete_16.json`: compact 16-cycle certificate.
- `data/central/central_saturation_depth100.json`: 240→640 recursive transfer
  certificate.
- `VERIFICATION.json`: independent verification output.
- `CHECKSUMS.sha256`: SHA-256 manifest.
