# The four-external facial-square profile is not a fibre state

Let \(\mathcal L\) be the fixed-pairing spanning-two-path fibre obtained by
deleting the root--gate square, as in Notes 085 and 103.  Suppose the two
expanded edges

\[
p=uv,\qquad q=xy
\]

are opposite edges of a facial square

\[
F=u-v-x-y-u,
\]

disjoint from the deleted root square and the named gates.  Write
\(r=vx\) and \(s=yu\) for the other two sides of \(F\).

## The four-external state is impossible

**Lemma.**  No member of \(\mathcal L\) has the local form
\(00_{\rm ext}\) of Note 104.

**Proof.**  Let \(N\) be a perfect matching with local form
\(00_{\rm ext}\).  Thus \(N\) uses the third edge leaving \(F\) at each
of \(u,v,x,y\), and it uses none of \(p,q,r,s\).  Consequently all four
edges of \(F\) lie in the complement.  At each vertex of \(F\), the two
complement edges are precisely the two incident sides of \(F\).  Hence
\(F\) is a connected component of the complement.

If all four third edges survive root-square deletion, this gives a closed
\(C_4\) component of the residual complement.  It contradicts the
definition of \(\mathcal L\), according to which the residual complement
is the disjoint union of the two prescribed spanning terminal paths and
has no closed component.

If one of the third edges joins a vertex of \(F\) to the deleted root
square, then it is unavailable in a residual perfect matching.  Equivalently,
in the full rooted target the root-square vertex is already saturated by
one of the two forced opposite matching edges.  Thus the local form
\(00_{\rm ext}\) is impossible in this case as well.  \(\square\)

The argument is the parent analogue of the observation in Note 103 that
the child cell \(C_{11}\) is absent from the child target fibre: in both
cases the four unused boundary edges isolate a square in the complement.
It uses neither planarity outside the named face nor brace
\(2\)-extendability.

## Every parent crossing survives the facial-square expansion

**Theorem.**  Under the setup above, every edge of the parent crossing
graph gives an edge of the complete child crossing graph.  In particular,

\[
\Gamma(\mathcal L)\ne\varnothing
\quad\Longrightarrow\quad
\Gamma(\mathcal L^+)\ne\varnothing.
\]

**Proof.**  Let \(MN\) be an edge of \(\Gamma(\mathcal L)\).

If neither endpoint has state \(11\) at \(p,q\), their canonical child
lifts exist and preserve every symmetric-difference component by Note 103,
equation (8).  They therefore form a child crossing edge.

Suppose at least one endpoint, say \(M\), has state \(11\).  Note 104
constructs three child targets \(M^R,M^U,M^V\), one in each new cell.  The
other endpoint has one of the local forms listed in Note 104.  The form
\(00_{rs}\) cannot occur on a cross-sector single-cycle edge: then the
facial square itself is the whole symmetric-difference component and it
avoids the surviving gate.  The form \(00_{\rm ext}\) is excluded by the
lemma.  For each remaining possibility

\[
11,\quad 10,\quad 01,\quad 00_r,\quad 00_s,
\]

the connector table in Note 104 has an entry equal to one.  The
corresponding face-assisted lift of \(M\), together with the indicated
lift of \(N\), is therefore a cross-sector child pair whose symmetric
difference is one alternating cycle.  This is an edge of
\(\Gamma(\mathcal L^+)\).  \(\square\)

## Consequence for the proposed exceptional case

The hypothesis that every parent crossing has the planar four-external
\(11\)--\(00_{\rm ext}\) profile is inconsistent with
\(\Gamma(\mathcal L)\ne\varnothing\).  Thus the exceptional row retained
in Note 104 is a valid local connector calculation for arbitrary perfect
matchings, but it is not realizable by an endpoint in the fixed-pairing
target fibre.

Accordingly, opposite-edge expansion of a facial square preserves a
nonempty fixed-pairing crossing graph without using the assumption that the
child is a brace.  The brace and legal-wide hypotheses remain relevant to
the surrounding Barnette construction, but they carry no weight in this
local preservation statement.

