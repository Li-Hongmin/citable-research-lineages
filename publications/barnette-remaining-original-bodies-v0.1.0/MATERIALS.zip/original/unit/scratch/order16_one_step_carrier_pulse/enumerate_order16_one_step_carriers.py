#!/usr/bin/env python3
"""Exact one-step C4 neighbourhood of Note 160's order-16 carrier.

This is deliberately a scratch pulse, not an order-20 graph census.  It
starts from the single labelled graph6 carrier in Note 160, enumerates its
interface-preserving facial bipartite C4 moves, retains precisely the
children that are braces and still carry the inherited legal-wide
root/gate interface, and reconstructs the complete carrier boundary family
for all eight cyclic orientations of the inherited cut square.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import argparse
import importlib.util
from itertools import combinations, combinations_with_replacement, product
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BUNDLE = (
    HERE.parents[1]
    / "computations/bundles/carrier-mandatory-four-row-prefilter"
    / "verify_order16_carrier_m2_and_near_m1.py"
)


def load_note160_bundle():
    spec = importlib.util.spec_from_file_location("note160_carrier_bundle", BUNDLE)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


base = load_note160_bundle()
Edge = tuple[int, int]
Matching = frozenset[Edge]
State = frozenset[int]

GRAPH6 = base.GRAPH6
ROOT_SQUARE = base.ROOT_SQUARE
ROOT = base.ROOT
FORCED = base.FORCED
SURVIVING = base.SURVIVING
CUT_FACE = base.CUT_FACE
STATES = base.STATES
FACTOR_ROWS = base.FACTOR_ROWS
ONE_PATH_FACTOR_ATOMS = base.ONE_PATH_FACTOR_ATOMS
R1_R3_FACTOR_PAIRING = base.R1_R3_FACTOR_PAIRING
REQUIRED_ROOT_PAIRS = base.REQUIRED_ROOT_PAIRS

TERM_BY_LABEL_PAIR = {
    ("N0", "N0"): "s_Z",
    ("N1", "N1"): "s_0",
    ("R1", "R1"): "s_1",
    ("R3", "R3"): "s_3",
    ("N0", "N1"): "p_Z0",
    ("N0", "R1"): "p_Z1",
    ("N0", "R3"): "p_Z3",
    ("N1", "R1"): "p_01",
    ("N1", "R3"): "p_03",
    ("R1", "R3"): "t_13",
}
TERMS = tuple(TERM_BY_LABEL_PAIR.values())


def edge(left: int, right: int) -> Edge:
    return tuple(sorted((left, right)))


def face_edges(face: tuple[int, ...]) -> tuple[Edge, ...]:
    return tuple(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def plane_faces(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    visited: set[tuple[int, int]] = set()
    faces = []
    for left, right in embedding.edges():
        if (left, right) not in visited:
            faces.append(tuple(embedding.traverse_face(left, right, visited)))
    return tuple(faces)


def is_facial(faces: tuple[tuple[int, ...], ...], cycle: tuple[int, ...]) -> bool:
    target = frozenset(face_edges(cycle))
    return any(frozenset(face_edges(face)) == target for face in faces)


def all_cut_orientations() -> tuple[tuple[int, ...], ...]:
    forward = CUT_FACE
    backward = tuple(reversed(CUT_FACE))
    result = []
    for cycle in (forward, backward):
        for shift in range(4):
            result.append(cycle[shift:] + cycle[:shift])
    assert len(result) == len(set(result)) == 8
    return tuple(result)


def site_records(graph: nx.Graph, faces: tuple[tuple[int, ...], ...]):
    """All unordered cofacial, disjoint, bipartite facial move sites."""
    protected = frozenset(face_edges(ROOT_SQUARE)) | frozenset(face_edges(CUT_FACE))
    seen: set[frozenset[Edge]] = set()
    records = []
    for face_index, face in enumerate(faces):
        degree = len(face)
        assert degree % 2 == 0
        boundary = face_edges(face)
        for first_index, second_index in combinations(range(degree), 2):
            first, second = boundary[first_index], boundary[second_index]
            if set(first) & set(second):
                continue
            # Same boundary-edge parity is exactly the bipartite standard move.
            if (second_index - first_index) % 2:
                continue
            selected = frozenset((first, second))
            if selected & protected:
                continue
            # A 3-connected plane graph cannot present the same disjoint
            # edge pair on two distinct faces; keep this literal rather than
            # silently quotienting embeddings.
            assert selected not in seen
            seen.add(selected)
            records.append(
                {
                    "face_index": face_index,
                    "face": face,
                    "indices": (first_index, second_index),
                    "selected": tuple(sorted(selected)),
                }
            )
    return tuple(records)


def expand(graph: nx.Graph, site) -> nx.Graph:
    face = site["face"]
    first_index, second_index = site["indices"]
    child = base.c4_expand(
        graph,
        face[first_index],
        face[(first_index + 1) % len(face)],
        face[second_index],
        face[(second_index + 1) % len(face)],
    )
    return child


def exact_brace(graph: nx.Graph) -> tuple[Matching, ...] | None:
    if (
        nx.number_of_selfloops(graph)
        or graph.is_multigraph()
        or not nx.is_connected(graph)
        or set(dict(graph.degree()).values()) != {3}
        or not nx.is_bipartite(graph)
        or not nx.check_planarity(graph)[0]
        or nx.node_connectivity(graph) < 3
    ):
        return None
    matchings = base.enumerate_matchings(graph)
    for first, second in combinations(tuple(map(lambda item: edge(*item), graph.edges())), 2):
        if set(first) & set(second):
            continue
        if not any(first in matching and second in matching for matching in matchings):
            return None
    return matchings


def legal_wide_gate_face(faces: tuple[tuple[int, ...], ...]):
    candidates = []
    for face in faces:
        boundary = face_edges(face)
        if FORCED in boundary and SURVIVING in boundary:
            first = boundary.index(FORCED)
            second = boundary.index(SURVIVING)
            delta = (second - first) % len(boundary)
            arcs = (delta + 1, len(boundary) - delta + 1)
            if min(arcs) >= 5 and all(value % 2 for value in arcs):
                candidates.append((face, arcs, first, second))
    return candidates[0] if len(candidates) == 1 else None


def inherited_legal_wide(graph: nx.Graph, faces: tuple[tuple[int, ...], ...]):
    """The inherited gates stay wide and their own standard expansion is a brace."""
    gate = legal_wide_gate_face(faces)
    if gate is None:
        return None
    face, arcs, first, second = gate
    gate_site = {
        "face": face,
        "indices": tuple(sorted((first, second))),
    }
    gate_child = expand(graph, gate_site)
    gate_matchings = exact_brace(gate_child)
    if gate_matchings is None:
        return None
    return {"gate_face": face, "gate_arcs": arcs, "gate_child_pm_count": len(gate_matchings)}


def root_attachments(graph: nx.Graph) -> tuple[int, ...]:
    square = set(ROOT_SQUARE)
    attachments = []
    for vertex in ROOT_SQUARE:
        outside = [neighbour for neighbour in graph[vertex] if neighbour not in square]
        assert len(outside) == 1
        attachments.append(outside[0])
    assert len(set(attachments)) == 4
    return tuple(attachments)


def complement_profile(
    cut: nx.Graph,
    ports: tuple[int, ...],
    attachments: tuple[int, ...],
    row_matching: Matching,
):
    residual = cut.subgraph(set(cut) - set(ROOT_SQUARE)).copy()
    residual.remove_edges_from(row_matching)
    components = []
    for vertices in nx.connected_components(residual):
        component = residual.subgraph(vertices)
        degrees = tuple(dict(component.degree()).values())
        port_marks = frozenset(
            index for index, vertex in enumerate(ports) if vertex in vertices
        )
        root_marks = frozenset(
            index for index, vertex in enumerate(attachments) if vertex in vertices
        )
        if degrees and all(value == 2 for value in degrees):
            kind = "cycle"
        elif degrees and all(value in {1, 2} for value in degrees):
            kind = "path"
        else:
            return None
        components.append((kind, port_marks, root_marks))
    return tuple(
        sorted(components, key=lambda item: (item[0], tuple(item[1]), tuple(item[2])))
    )


@dataclass(frozen=True)
class Row:
    state: State
    matching: Matching
    profile: tuple


def carrier_rows(graph: nx.Graph, ports: tuple[int, ...]):
    cut = graph.copy()
    cut.remove_edges_from((edge(ports[0], ports[1]), edge(ports[2], ports[3])))
    attachments = root_attachments(graph)
    required = frozenset((ROOT, FORCED))
    rows = []
    for state in STATES:
        removed = frozenset(ports[index] for index in state)
        for item in base.enumerate_matchings(cut, removed, required):
            profile = complement_profile(cut, ports, attachments, item)
            if profile is not None:
                rows.append(Row(state, item, profile))
    rows.sort(key=lambda row: (tuple(sorted(row.state)), tuple(sorted(row.matching))))
    return cut, tuple(rows)


def bond_atom(cut: nx.Graph, ports: tuple[int, ...], first: Row, second: Row):
    difference = first.matching ^ second.matching
    if not difference:
        return (), 0
    difference_graph = nx.edge_subgraph(cut, difference).copy()
    paths = []
    cycles = 0
    for vertices in nx.connected_components(difference_graph):
        component = difference_graph.subgraph(vertices)
        ends = [vertex for vertex, degree in component.degree() if degree == 1]
        if not ends:
            if set(dict(component.degree()).values()) != {2}:
                return None
            cycles += 1
        else:
            if len(ends) != 2:
                return None
            marks = frozenset(index for index, vertex in enumerate(ports) if vertex in ends)
            if len(marks) != 2:
                return None
            paths.append(marks)
    expected = set(first.state ^ second.state)
    actual = set().union(*(set(path) for path in paths)) if paths else set()
    if actual != expected:
        return None
    return tuple(sorted(paths, key=tuple)), cycles


def joined_is_one_cycle(left: str, right: str, atom) -> bool:
    if atom is None:
        return False
    paths, closed = atom
    if left == right:
        return paths == () and closed == 1
    if closed:
        return False
    labels = frozenset((left, right))
    if labels in ONE_PATH_FACTOR_ATOMS:
        return len(paths) == 1 and paths[0] == ONE_PATH_FACTOR_ATOMS[labels]
    assert labels == frozenset(("R1", "R3"))
    pairing = frozenset(paths)
    return len(paths) == 2 and pairing != R1_R3_FACTOR_PAIRING


def serialize_profile(profile):
    return [
        {"kind": kind, "ports": sorted(ports), "roots": sorted(roots)}
        for kind, ports, roots in profile
    ]


def serialize_atom(atom):
    if atom is None:
        return None
    paths, closed = atom
    return {"paths": [sorted(path) for path in paths], "closed": closed}


def orientation_certificate(graph: nx.Graph, ports: tuple[int, ...]):
    cut, rows = carrier_rows(graph, ports)
    row_ids = {row: f"K{index}" for index, row in enumerate(rows)}
    compatible = {}
    for label, (state, factor_pairs) in FACTOR_ROWS.items():
        compatible[label] = tuple(
            row
            for row in rows
            if row.state == state
            and base.factor_join_passes(row.profile, state, factor_pairs)
        )
    sectors = {
        row: int(SURVIVING in row.matching)
        for values in compatible.values()
        for row in values
    }

    counts = Counter({term: 0 for term in TERMS})
    slots = []
    labels = tuple(FACTOR_ROWS)
    for left_label, right_label in combinations_with_replacement(labels, 2):
        candidates = (
            combinations(compatible[left_label], 2)
            if left_label == right_label
            else product(compatible[left_label], compatible[right_label])
        )
        for left, right in candidates:
            left_sector = sectors[left]
            right_sector = sectors[right]
            if left_sector == right_sector:
                continue
            atom = bond_atom(cut, ports, left, right)
            if not joined_is_one_cycle(left_label, right_label, atom):
                continue
            term = TERM_BY_LABEL_PAIR[(left_label, right_label)]
            counts[term] += 1
            slots.append(
                {
                    "term": term,
                    "left_factor": left_label,
                    "left_row": row_ids[left],
                    "left_sector": left_sector,
                    "right_factor": right_label,
                    "right_row": row_ids[right],
                    "right_sector": right_sector,
                    "atom": serialize_atom(atom),
                }
            )

    pz0_directions = Counter({"N0^0-N1^1": 0, "N0^1-N1^0": 0})
    for slot in slots:
        if slot["term"] == "p_Z0":
            pz0_directions[
                f"N0^{slot['left_sector']}-N1^{slot['right_sector']}"
            ] += 1

    row_records = []
    memberships = Counter()
    for label, values in compatible.items():
        for row in values:
            memberships[(row_ids[row], label)] += 1
    for row in rows:
        row_records.append(
            {
                "id": row_ids[row],
                "state": sorted(row.state),
                "matching": [list(item) for item in sorted(row.matching)],
                "profile": serialize_profile(row.profile),
                "compatible_factor_rows": [
                    label for label in FACTOR_ROWS if memberships[(row_ids[row], label)]
                ],
                "sector": int(SURVIVING in row.matching),
            }
        )

    return {
        "ports": ports,
        "deleted_cut_edges": (edge(ports[0], ports[1]), edge(ports[2], ports[3])),
        "surviving_gate_deleted": SURVIVING
        in {edge(ports[0], ports[1]), edge(ports[2], ports[3])},
        "row_count": len(rows),
        "row_state_counts": {
            str(tuple(sorted(state))): number
            for state, number in sorted(
                Counter(row.state for row in rows).items(), key=lambda item: tuple(sorted(item[0]))
            )
        },
        "compatible_row_ids": {
            label: [row_ids[row] for row in values]
            for label, values in compatible.items()
        },
        "compatible_sector_counts": {
            label: dict(sorted(Counter(sectors[row] for row in values).items()))
            for label, values in compatible.items()
        },
        "ten_terms": dict(counts),
        "M": sum(counts.values()),
        "p_Z0_by_direction": dict(pz0_directions),
        "mandatory_slots": slots,
        "rows": row_records,
    }


def graph6(graph: nx.Graph) -> str:
    ordered = nx.convert_node_labels_to_integers(graph, ordering="sorted")
    return nx.to_graph6_bytes(ordered, header=False).decode().strip()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=HERE / "result.json")
    args = parser.parse_args()

    parent = nx.from_graph6_bytes(GRAPH6.encode())
    parent_faces = plane_faces(parent)
    assert is_facial(parent_faces, ROOT_SQUARE)
    assert is_facial(parent_faces, CUT_FACE)
    orientations = all_cut_orientations()

    # Recover Note 160's literal parent count before testing descendants.
    parent_literal = orientation_certificate(parent, CUT_FACE)
    assert parent_literal["ten_terms"] == {
        "s_Z": 0,
        "s_0": 0,
        "s_1": 0,
        "s_3": 0,
        "p_Z0": 1,
        "p_Z1": 0,
        "p_Z3": 0,
        "p_01": 0,
        "p_03": 1,
        "t_13": 0,
    }

    sites = site_records(parent, parent_faces)
    counters = Counter(raw_sites=len(sites))
    children = []
    rejected_sites = []
    first_m1 = None
    for site_index, site in enumerate(sites):
        child = expand(parent, site)
        child_faces = plane_faces(child)
        if not is_facial(child_faces, ROOT_SQUARE) or not is_facial(child_faces, CUT_FACE):
            counters["lost_inherited_square"] += 1
            continue
        child_matchings = exact_brace(child)
        if child_matchings is None:
            counters["nonbrace_children"] += 1
            continue
        counters["brace_children"] += 1
        gate_candidate = legal_wide_gate_face(child_faces)
        legal = inherited_legal_wide(child, child_faces)
        if legal is None:
            counters["lost_legal_wide_interface"] += 1
            rejected_sites.append(
                {
                    "site_index": site_index,
                    "site_face": site["face"],
                    "site_indices": site["indices"],
                    "selected_edges": site["selected"],
                    "graph6": graph6(child),
                    "reason": (
                        "no_unique_wide_common_gate_face"
                        if gate_candidate is None
                        else "inherited_gate_expansion_is_not_a_brace"
                    ),
                }
            )
            continue
        counters["legal_wide_carrier_children"] += 1

        orientation_records = []
        for orientation_index, ports in enumerate(orientations):
            certificate = orientation_certificate(child, ports)
            certificate["orientation_index"] = orientation_index
            orientation_records.append(certificate)
            if certificate["ten_terms"]["p_Z0"] > 0:
                counters["antecedent_orientations"] += 1
                if certificate["M"] == 1:
                    counters["m1_orientations"] += 1
                    key = (graph6(child), tuple(site["selected"]), orientation_index)
                    candidate = (key, site_index, site, child, legal, certificate)
                    if first_m1 is None or key < first_m1[0]:
                        first_m1 = candidate

        children.append(
            {
                "site_index": site_index,
                "site_face": site["face"],
                "site_face_length": len(site["face"]),
                "site_indices": site["indices"],
                "selected_edges": site["selected"],
                "graph6": graph6(child),
                "perfect_matching_count": len(child_matchings),
                **legal,
                "orientations": orientation_records,
            }
        )

    antecedent_certificates = [
        orientation
        for child in children
        for orientation in child["orientations"]
        if orientation["ten_terms"]["p_Z0"] > 0
    ]
    nonantecedent_certificates = [
        orientation
        for child in children
        for orientation in child["orientations"]
        if orientation["ten_terms"]["p_Z0"] == 0
    ]
    assert counters == Counter(
        {
            "raw_sites": 22,
            "brace_children": 22,
            "lost_legal_wide_interface": 5,
            "legal_wide_carrier_children": 17,
            "antecedent_orientations": 68,
        }
    )
    assert len(children) == 17 and len(rejected_sites) == 5
    assert len(antecedent_certificates) == len(nonantecedent_certificates) == 68
    assert all(item["M"] == 0 for item in nonantecedent_certificates)
    assert all(item["surviving_gate_deleted"] for item in nonantecedent_certificates)
    assert all(item["M"] != 1 for item in antecedent_certificates)
    assert all(
        item["ten_terms"]["p_Z0"] in (1, 3)
        and item["ten_terms"]["p_01"] + item["ten_terms"]["p_03"] >= 1
        and all(
            item["ten_terms"][term] == 0
            for term in ("s_Z", "s_0", "s_1", "s_3", "p_Z1", "p_Z3", "t_13")
        )
        and item["p_Z0_by_direction"]["N0^0-N1^1"] == 0
        and item["p_Z0_by_direction"]["N0^1-N1^0"]
        == item["ten_terms"]["p_Z0"]
        for item in antecedent_certificates
    )

    result = {
        "scope": "Note160 fixed order-16 carrier, one interface-preserving standard facial C4 step only",
        "parent_graph6": GRAPH6,
        "root_square": ROOT_SQUARE,
        "root": ROOT,
        "forced_gate": FORCED,
        "surviving_gate": SURVIVING,
        "cut_face": CUT_FACE,
        "cut_orientations": orientations,
        "parent_literal_orientation": parent_literal,
        "counts": dict(counters),
        "rejected_sites": rejected_sites,
        "children": children,
        "smallest_actual_m1": None,
    }
    if first_m1 is not None:
        _key, site_index, site, child, legal, certificate = first_m1
        result["smallest_actual_m1"] = {
            "site_index": site_index,
            "site_face": site["face"],
            "site_indices": site["indices"],
            "selected_edges": site["selected"],
            "graph6": graph6(child),
            **legal,
            "orientation": certificate,
        }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result["counts"], sort_keys=True))
    if result["smallest_actual_m1"] is None:
        print("NO_ACTUAL_M1_IN_COMPLETE_ONE_STEP_NEIGHBOURHOOD")
        print("ORDER16_ONE_STEP_CARRIER_CLASSIFICATION_VERIFIED")
    else:
        witness = result["smallest_actual_m1"]
        print(
            "ACTUAL_M1",
            witness["graph6"],
            witness["selected_edges"],
            witness["orientation"]["ports"],
        )


if __name__ == "__main__":
    main()
