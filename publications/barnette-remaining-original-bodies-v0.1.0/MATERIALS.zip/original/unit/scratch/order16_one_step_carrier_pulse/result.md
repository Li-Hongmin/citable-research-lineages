# Order-16 carrier: exact one-step pulse

Starting graph: `O????B_sDOI_I_DO@W?M?` with the Note 160 labels unchanged.
The operation set consists only of standard bipartite C4 expansions on an
unordered pair of vertex-disjoint cofacial edges, with all four inherited
root-square edges and all four inherited cut-square edges protected.

## Finite scope

- There are exactly 22 such sites in the fixed plane embedding.
- Every one of the 22 expanded graphs is a simple plane cubic bipartite
  brace.
- Five sites split the forced and surviving gates onto different faces, so
  they leave the legal-wide carrier class:
  `3-13/4-10`, `0-9/4-10`, `3-9/4-14`, `3-13/7-14`, and
  `0-9/7-14` (site indices 2--6).
- The remaining 17 children preserve the inherited root square, cut
  face/ports, a unique wide common gate face, and a brace-preserving standard
  gate expansion.

For every child, all eight cyclic orientations of the cut square were
reconstructed.  The four orientations that retain the surviving gate are

~~~text
o0=(5,13,7,15)  o2=(7,15,5,13)
o4=(15,7,13,5)  o6=(13,5,15,7).
~~~

The other four delete the surviving gate as a cut edge; all their rows lie
in sector 0, so all ten mandatory terms and `M` are zero.  Thus the
antecedent is false in exactly those 68 orientations.

## Exact compensation table

In the table, each `oN:(a,b)` means `p_Z0=a` and the only additional
nonzero term has value `b`: it is `p_03` for `o0,o4` and `p_01` for
`o2,o6`.  Every one of

~~~text
s_Z,s_0,s_1,s_3,p_Z1,p_Z3,t_13
~~~

is zero in every antecedent orientation.

| site | selected old edges | o0 | o2 | o4 | o6 |
|---:|---|---:|---:|---:|---:|
| 0 | `0-9 / 1-8` | (1,1) | (1,1) | (1,1) | (1,1) |
| 1 | `4-10 / 7-14` | (3,1) | (3,3) | (3,3) | (3,1) |
| 7 | `0-9 / 3-13` | (3,3) | (3,1) | (3,1) | (3,3) |
| 8 | `1-9 / 3-11` | (3,3) | (3,1) | (3,1) | (3,3) |
| 9 | `1-11 / 3-9` | (1,1) | (1,1) | (1,1) | (1,1) |
| 10 | `1-11 / 6-12` | (1,1) | (1,1) | (1,1) | (1,1) |
| 11 | `5-11 / 6-15` | (3,1) | (3,1) | (3,1) | (3,1) |
| 12 | `2-12 / 5-11` | (3,2) | (3,1) | (3,1) | (3,2) |
| 13 | `1-8 / 5-11` | (3,3) | (3,1) | (3,1) | (3,3) |
| 14 | `2-12 / 6-15` | (3,1) | (3,3) | (3,3) | (3,1) |
| 15 | `1-8 / 6-15` | (3,1) | (3,2) | (3,2) | (3,1) |
| 16 | `1-8 / 2-12` | (1,1) | (1,1) | (1,1) | (1,1) |
| 17 | `2-12 / 4-10` | (1,1) | (1,1) | (1,1) | (1,1) |
| 18 | `3-13 / 5-11` | (1,1) | (1,1) | (1,1) | (1,1) |
| 19 | `4-12 / 6-14` | (3,1) | (3,3) | (3,3) | (3,1) |
| 20 | `4-14 / 6-12` | (1,1) | (1,1) | (1,1) | (1,1) |
| 21 | `6-15 / 7-14` | (1,1) | (1,1) | (1,1) | (1,1) |

Across the 68 antecedent orientations this gives the exact histogram

~~~text
(p_Z0, p_01+p_03, M) =
  (1,1,2)  x 32
  (3,1,4)  x 20
  (3,2,5)  x  4
  (3,3,6)  x 12.
~~~

All `p_Z0` atoms have direction `N0^1-N1^0`; the reverse direction
`N0^0-N1^1` occurs zero times.  Hence no actual one-step child has `M=1`.
The exact compensation is: when the designated atom remains unique, a
literal `p_03` or its cyclically relabelled `p_01` companion is always
present; otherwise the expansion already creates three `p_Z0` atoms, and
still retains one to three such companions.

## Complete certificates

`result.json` contains all 136 orientation certificates.  Each certificate
records every carrier row (matching, state, full complement component
profile, sector, and compatible factor-row memberships), all mandatory
slots with their carrier atoms, and the ten-term vector.  The verifier is
`enumerate_order16_one_step_carriers.py` and terminates with
`ORDER16_ONE_STEP_CARRIER_CLASSIFICATION_VERIFIED`.

Reproduce from the AIMath root with

~~~sh
uv run --python 3.14 --with 'networkx==3.6.1' \
  units/barnette/scratch/order16_one_step_carrier_pulse/enumerate_order16_one_step_carriers.py
~~~
