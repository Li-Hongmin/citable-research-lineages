#!/usr/bin/env python3
"""Solver-free check of the Q3 root-fixed Kempe counterexample in result.md."""

from itertools import combinations


VERTICES = tuple(range(8))
EDGES = frozenset(
    tuple(sorted((vertex, vertex ^ (1 << coordinate))))
    for vertex in VERTICES
    for coordinate in range(3)
    if vertex < (vertex ^ (1 << coordinate))
)


def edge(u: int, v: int) -> tuple[int, int]:
    return tuple(sorted((u, v)))


def is_perfect_matching(matching: frozenset[tuple[int, int]]) -> bool:
    ends = [vertex for item in matching for vertex in item]
    return len(matching) == 4 and len(set(ends)) == 8


def cycle_components(edge_set: frozenset[tuple[int, int]]) -> list[set[int]]:
    adjacency = {vertex: set() for vertex in VERTICES}
    for u, v in edge_set:
        adjacency[u].add(v)
        adjacency[v].add(u)
    assert all(len(neighbors) == 2 for neighbors in adjacency.values())
    unseen = set(VERTICES)
    components = []
    while unseen:
        start = unseen.pop()
        component = {start}
        stack = [start]
        while stack:
            vertex = stack.pop()
            for neighbor in adjacency[vertex]:
                if neighbor not in component:
                    component.add(neighbor)
                    unseen.remove(neighbor)
                    stack.append(neighbor)
        components.append(component)
    return components


perfect_matchings = frozenset(
    frozenset(candidate)
    for candidate in combinations(EDGES, 4)
    if is_perfect_matching(frozenset(candidate))
)
assert len(perfect_matchings) == 9
for first, second in combinations(EDGES, 2):
    if set(first).isdisjoint(second):
        assert any(first in matching and second in matching for matching in perfect_matchings)

r, s = 0b000, 0b001
root_edge = edge(r, s)
matching_m = frozenset(
    {
        root_edge,
        edge(0b010, 0b011),
        edge(0b100, 0b101),
        edge(0b110, 0b111),
    }
)
kempe_cycle = frozenset(
    {
        edge(0b010, 0b011),
        edge(0b011, 0b111),
        edge(0b111, 0b110),
        edge(0b110, 0b010),
    }
)
matching_n = matching_m ^ kempe_cycle

assert matching_m in perfect_matchings and matching_n in perfect_matchings
assert root_edge in matching_m and root_edge in matching_n
assert r not in set().union(*kempe_cycle) and s not in set().union(*kempe_cycle)

factor_m = EDGES - matching_m
factor_n = EDGES - matching_n
components_m = cycle_components(factor_m)
components_n = cycle_components(factor_n)
assert len(components_m) == 2
assert not any({r, s} <= component for component in components_m)
assert len(components_n) == 1 and len(components_n[0]) == 8

color_2 = frozenset(
    {
        edge(0b010, 0b110),
        edge(0b100, 0b000),
        edge(0b011, 0b111),
        edge(0b101, 0b001),
    }
)
color_3 = factor_m - color_2
assert matching_m | color_2 | color_3 == EDGES
assert not (matching_m & color_2 or matching_m & color_3 or color_2 & color_3)
for vertex in VERTICES:
    assert all(
        sum(vertex in item for item in color_class) == 1
        for color_class in (matching_m, color_2, color_3)
    )
assert kempe_cycle <= (matching_m | color_2)

print("Q3 perfect matchings: 9")
print("Q3 is 2-extendable: every independent edge pair extends")
print("before switch: 2 cycles, root endpoints separated")
print("after switch: 1 Hamilton cycle, root endpoints joined")
