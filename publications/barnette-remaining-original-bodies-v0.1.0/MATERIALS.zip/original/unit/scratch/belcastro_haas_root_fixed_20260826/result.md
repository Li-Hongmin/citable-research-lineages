# Belcastro--Haas gives ambient root-fixed Kempe connectivity, not separated descent

## Decision

Belcastro--Haas Theorem 3.1 and Corollary 4.3 do **not**, either separately
or together, imply

\[
\mu_F(e)=2
\]

for a root edge \(e=rs\), nor do they force a root-separation-preserving
alternating union with \(q<p\).  Their exact strongest direct consequence is
connectivity of the full proper-3-edge-coloring space with the three colors
on one root star fixed.  After projecting color 1 to a perfect matching, this
gives connectivity of the **ambient** space of all perfect matchings containing
\(e\), by color-compatible alternating-cycle flips that keep \(e\) and whose
matching-changing cycles avoid both \(r\) and \(s\).  It gives no connectivity,
invariance, or decreasing potential on the endpoint-separated subspace.

The route closes at a strict quantifier boundary: Kempe connectivity connects
two target states after both have been supplied; \(\mu_F(e)=2\) is the missing
existence of one such target state.

## 1. What the cited results actually state

Let \(H\) be a planar bipartite cubic graph.

- Corollary 4.3 says \(K'(H,3)=1\): all proper 3-edge-colorings of \(H\)
  are edge-Kempe equivalent.
- Theorem 3.1 says that if equivalent proper edge-colorings \(c,d\) agree
  on every edge incident with a vertex \(v\), then some Kempe sequence from
  \(c\) to \(d\) never changes the colors on the edges incident with \(v\).

The first statement is on printed page 11 of the supplied PDF.  The second
statement and proof occupy printed pages 6--8.  In the proof of Theorem 3.1,
a switch through \(v\) is replaced by switches on all the other components
of the same two-color subgraph, with a global color transposition tracked.
This construction fixes the root star but contains no assertion about the
number or marked incidence of cycles in the complement of one color class.

## 2. Exact root-fixed coloring-space consequence

Fix a vertex \(r\) and a bijection

\[
\phi:\delta_H(r)\longrightarrow\{1,2,3\}.
\]

Let \(\mathcal C_\phi(H)\) be the proper 3-edge-colorings restricting to
\(\phi\) on \(\delta_H(r)\).  Join two members when one is obtained from the
other by a single edge-Kempe switch that does not change \(\delta_H(r)\).
Then

\[
\boxed{\mathcal C_\phi(H)\text{ is connected}.}
\tag{BH-root}
\]

Indeed, Corollary 4.3 makes any two members \(c,d\) Kempe equivalent, and
Theorem 3.1 replaces an arbitrary equivalence by one fixing the star of
\(r\).  This is the strongest direct root-fixed statement of the two cited
results: it retains the full ordered 1-factorization, rather than only one
perfect matching.

## 3. Exact projection to perfect matchings

Fix \(e=rs\), and choose \(\phi(e)=1\).  Put

\[
\mathcal P_e=\{M:M\text{ is a perfect matching of }H,\ e\in M\}.
\]

Every \(M\in\mathcal P_e\) has a lift in \(\mathcal C_\phi(H)\): the
complement \(H-M\) is an even 2-factor, so its edges can be alternately
colored 2 and 3 on each cycle, with the alternation on the root cycle chosen
to realize \(\phi\) at \(r\).  The map

\[
\pi:\mathcal C_\phi(H)\to\mathcal P_e,\qquad
\pi(c)=c^{-1}(1)
\]

is therefore surjective.

Given \(M,N\in\mathcal P_e\), lift them to \(c,d\in\mathcal C_\phi(H)\)
and apply (BH-root).  Under the resulting sequence:

1. a 2--3 switch leaves the color-1 matching unchanged;
2. a 1--\(j\) switch on a bicolored component \(A\) changes the current
   matching by \(M_i\mapsto M_i\triangle E(A)\);
3. because the switch fixes \(\delta(r)\), such an \(A\) avoids \(r\);
   it also avoids \(s\), since the 1--\(j\) component through \(s\) contains
   the color-1 edge \(rs\), hence contains \(r\).

Consequently:

> Any two perfect matchings containing \(e\) are joined by a sequence of
> color-compatible alternating-cycle flips whose matching-changing cycles
> avoid \(\{r,s\}\), while \(e\) remains in the matching throughout.

This is a Kempe-lifted refinement of ordinary matching-space connectivity.
Ordinary connectivity itself needs no Belcastro--Haas theorem: for any two
perfect matchings containing \(e\), the components of \(M\triangle N\) are
alternating cycles avoiding \(e\), and they can be flipped successively.

## 4. Why this does not imply \(\mu_F(e)=2\)

For the notation of the RCA reduction, let

\[
\mathcal S_e=\{M\in\mathcal P_e:r,s\text{ lie on distinct cycles of }F-M\}.
\]

The cited conclusions have the quantifier form

\[
\forall M,N\in\mathcal P_e\quad
\exists\text{ a root-fixed Kempe path from a lift of }M\text{ to a lift of }N.
\tag{8}
\]

The desired two-cycle condition is

\[
\exists N\in\mathcal P_e:\quad
N\in\mathcal S_e\quad\text{and}\quad c(F-N)=2.
\tag{9}
\]

Statement (8) only connects an \(N\) after it has been supplied.  It places
no restriction on the predicate \(N\in\mathcal S_e\) or on the potential
\(c(F-N)\), so it cannot instantiate the existential target in (9).  Note
058 supplies nonemptiness of \(\mathcal S_e\), but not a member of cycle
count two.  Combining nonemptiness with ambient connectivity still gives no
information about the induced subspace \(\mathcal S_e\).

This is not merely a missing monotonicity observation.  Root-star-fixing does
not make endpoint separation invariant; Section 6 gives an actual plane
cubic bipartite brace where one allowed root-fixed Kempe switch destroys it.

## 5. The \(q<p\) move is equivalent to the missing target, not a consequence

Fix \(M\in\mathcal S_e\), and let \(U\) be a disjoint union of
\(M\)-alternating cycles avoiding \(e\).  Put \(N=M\triangle E(U)\).  If
\(U\) preserves the two marked root components, then \(N\in\mathcal S_e\).
Using the endpoint-pairing notation of the RCA result,

\[
c(F-N)=c(F-M)-p+q.
\]

Hence

\[
q<p\quad\Longleftrightarrow\quad c(F-N)<c(F-M).
\tag{10}
\]

Conversely, for any \(M,N\in\mathcal P_e\), the symmetric difference
\(M\triangle N\) is exactly such a disjoint alternating union; if both are
in \(\mathcal S_e\), it preserves root separation at the resulting endpoint.
It follows that the universal descent assertion

\[
\forall M\in\mathcal S_e, c(F-M)>2\quad
\exists U\text{ preserving separation with }q<p
\tag{11}
\]

is equivalent to \(\mu_F(e)=2\):

- if \(\mu_F(e)=2\), take a two-cycle minimizer \(N\) and
  \(U=M\triangle N\);
- if (11) holds, repeatedly apply (10) inside the finite set
  \(\mathcal S_e\); termination can only occur at two cycles because the
  two root marks remain separated.

Thus asking the Belcastro--Haas connectivity theorem to force a
separation-preserving \(q<p\) union asks it to prove exactly the missing RCA
condition.  The published connectivity statement supplies no additional
premise from which that descent follows.

## 6. Actual brace counterexample to preservation of separation

Let \(F=Q_3\), with vertices the binary strings of length three and edges
joining strings that differ in one coordinate.  This is a simple plane
cubic bipartite brace.  (It is 2-extendable: direct enumeration gives nine
perfect matchings and every pair of independent edges is contained in one;
this can also be checked immediately from the cube symmetry.)  Set

\[
r=000,\qquad s=001,\qquad e=000\,001,
\]

and take

\[
M=\{000\,001,\ 010\,011,\ 100\,101,\ 110\,111\}.
\]

Then \(F-M\) is the disjoint union of the two square layers with last
coordinate 0 and 1.  Thus \(r,s\) are on distinct cycles.  Color \(M\) with
color 1, and alternately color each square with colors 2 and 3 so that both
edges \(010\,110\) and \(011\,111\) have color 2.  The cycle

\[
A=010-011-111-110-010
\]

is then a 1--2 Kempe cycle, and it avoids both \(r\) and \(s\).  Switching
on \(A\) fixes every edge color at \(r\), keeps \(e\) in color 1, and changes
the color-1 matching to

\[
N=M\triangle E(A)
=\{000\,001,\ 100\,101,\ 010\,110,\ 011\,111\}.
\]

But \(F-N\) is the Hamilton cycle

\[
000-010-011-001-101-111-110-100-000.
\]

Therefore a single allowed root-fixed Kempe switch changes a separated
factor into one in which \(r,s\) are on the same cycle.  In the pairing
formula it has \(p=2,q=1\): it decreases the unmarked cycle count precisely
by merging the two marked root cycles.  Reversing the same switch increases
the cycle count.  This proves, inside the actual class of plane cubic
bipartite braces, both that separation is not invariant under root-fixed
Kempe moves and that such moves have no intrinsic potential orientation.

## 7. Route closure and remaining boundary

The Belcastro--Haas route is therefore closed as a black-box route to RCA:

- it proves connectedness of the ambient root-fixed coloring fibre;
- its matching-changing moves keep \(rs\) but need not keep the two endpoint
  marks in different complementary cycles;
- neither Theorem 3.1 nor Corollary 4.3 controls \(p,q\), marked endpoint
  pairings, or the number of complementary cycles;
- forcing a marked \(q<p\) union is equivalent to the still-open target
  \(\mu_F(e)=2\), not a weaker corollary of connectivity.

What remains open is whether additional planar-brace structure--especially
the cyclic attachment order discarded by ordinary Kempe connectivity--can
prove connectivity or descent inside \(\mathcal S_e\), or whether the proof
of the planar Kempe theorem can be substantially strengthened to control
the marked pairing.  Such a strengthening is not present in the cited
statement or proof.

## Evidence calibration

- **Direct primary-source fact:** the statements and proof scope of
  Theorem 3.1 and Corollary 4.3, checked in the supplied full PDF on
  2026-08-26.
- **Deductive proof:** (BH-root), its perfect-matching projection, the
  quantifier separation (8)--(9), and equivalence (10)--(11).
- **Exact finite counterexample:** the displayed \(Q_3\) edge sets and
  cycles, checked without a solver by `check_cube_root_fixed_switch.py`.
- **Weakest point:** “strongest direct consequence” is relative to the
  published theorem interface and proof as written.  A new refinement of
  the planar Kempe-equivalence proof using marked cyclic attachment data is
  not ruled out.
- **Unresolved boundary:** \(\mu_F(e)=2\), RCA, and existence of a
  separation-preserving compatible alternating union with \(q<p\) remain
  unproved and unrefuted.

## Source

sarah-marie belcastro and Ruth Haas, *Counting edge-Kempe-equivalence
classes for 3-edge-colored cubic graphs*, arXiv:1209.1730v1, Theorem 3.1
and Corollary 4.3, supplied PDF `unknownarxiv1209a.pdf`.
