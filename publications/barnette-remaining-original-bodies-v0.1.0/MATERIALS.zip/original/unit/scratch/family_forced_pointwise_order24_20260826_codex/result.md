# Complete-family gate forcing is pointwise arc11 through reduced order 24

## 精确有限定理

令 (F') 为 reduced order (24) 的任意 simple plane cubic bipartite
brace，固定任意 legal two-gate (C_4) expansion、split face 外任意
unchanged root (e)，并设非空完整 target family 为

\[
\mathcal T_e={M:e\in M, F'-M\text{ 是分离 }e\text{ 两端的两个圈}\}.
\]

若两道 gates (g,h) 在整个 family 中强制，即

\[
g,h\in M\qquad(\forall M\in\mathcal T_e),
\]

则不只是某个 target 可提升，而是每个 (M\in\mathcal T_e) 都满足：

1. 两条 gate arcs 的 normalized boundary colour words 均严格交替；
2. normalized local rows `011`, `101`, `110` 三条且仅这三条产生正确
   rooted target lift。

因而 family forcing 在 order (24) 上逐点推出 liftability。

## 完整范围

上游 complete-family census 的 (29,579) 个 connected simple cubic
bipartite 同构代表中有 (18) 个 plane braces。其全部合法 splits 与非空
unchanged-root families 中：

\[
408\text{ 个 complete families 强制双 gate},
\]

共含

\[
1,864\text{ 个 targets}.
\]

本检查重建这 (18) 个 braces、全部 target families 与 splits，并对上述
(1,864) 个 targets 的八个局部赋值逐一计算，共 (14,912) 个 profiles。
结果为

\[
\#\text{arc11}=1,864,\qquad
\#\text{pointwise liftable}=1,864,\qquad
\#\text{failures}=0.
\]

更关键地，全部 \(408\) 个强制 families、全部 \(1,864\) 个 targets 都发生在
split face length \(4\)；length \(6+\) 的合法 sites 没有一个 complete family
同时强制两道 gates。

成功 row histogram 在程序中因 absolute-bit 枚举方向写成
`011,101,110` 计 \(1,348\) 次、`110,101,011` 计 \(516\) 次；两者作为集合
完全相同，均为 \(\{011,101,110\}\)。

结合 Notes 071 与 073，这一逐点现象成立于完整 through-\(24\) corpus。
它不与 order-\(24\) 的 forced-component 反例冲突：该坏 component 位于一个
mixed-gate complete family，另外两个 components 含 one-gate neutral targets。

## 数学边界

该有限定理把一般 ordinary existence-level 命题的最自然加强候选确定为

\[
\boxed{
[\forall M\in\mathcal T_e, g,h\in M]
\Longrightarrow
[\forall M\in\mathcal T_e, M\text{ is arc11 and rows }011,101,110
\text{ all lift}].}
\]

这比 ordinary existence 所需的存在量词强，但与所有已覆盖 actual families
完全一致。component saturation 已被推翻，故任何一般证明都必须实质使用
**完整 family** 的 gate-forcing 前提，不能只在一个 exchange component 内
使用同样论证。

四边形局部本身解释三行现象：在 dual degree-four vertex \(z\) 处，两 gates
必为对径 neighbours；若 target 同时使用两 gate，则 NAE triangles 强制另外
两个 neighbours 取反色，故 boundary word 为 `0101`。rooted forest 中 \(z\)
的两个同色 neighbours 必位于 \(R-z\) 的不同 components，否则经过 \(z\)
成圈。三条 arc rows 正是把这两个 components 以三种 tree replacement 重新
连接，均保持三分量与 root path。更一般的短弧吸收引理证明：只要任一 closed
gate arc 的 cardinality 为 \(3\)，任一双-gate target 都逐点提升。因此一般
family-level 命题的真正非局部范围只剩**两弧均至少 \(5\)、face length 至少
\(8\)** 的 wide sites。through \(24\) 连一个 wide forced family 都没有。

- **证据等级：** 精确 computer-assisted finite theorem；不是任意阶证明。
- **最薄弱步骤：** 依赖上游 order-\(24\) `geng` 完整代表与 \(18\) 个 plane
  braces 的筛选；本脚本从冻结 graph6 列表重新枚举所有相关 families 和 rows。
- **未解决边界：** reduced order \(26+\) 是否首次出现 actual wide forced
  family；若出现，它是否仍由 nonneutral rows 提升。

复现：

```bash
uv run --with 'networkx==3.6.1' \
  units/barnette/scratch/family_forced_pointwise_order24_20260826_codex/check_pointwise.py \
  --output units/barnette/scratch/family_forced_pointwise_order24_20260826_codex/pointwise.json
```

终止标记：

```text
pointwise_forced_family_lifting_holds_at_order_24
```
