# Sector survival is a gate-even parent/child switch dichotomy

This draft uses only Notes 108, 109, 114, 115, and 116. It determines the
exact additional content of the sector hypothesis in \(P_{\rm sector}\).
The cited results do not decide the resulting actual-incidence dichotomy.

## 1. The sector hypothesis is genuinely stronger

Let

\[
 \chi^b-\eta^{1-b}
\tag{1}
\]

be a mixed parent rooted bond, where \(\chi\) has state \(11\) and
\(\eta\) does not. Assume

\[
 {\cal L}_{\neg11}^{\,b}=\varnothing .
\tag{2}
\]

Every parent rooted bond has endpoints with opposite surviving-gate bits.
Its endpoint in sector \(b\) therefore belongs to \({\cal L}_{11}^b\) by
(2). Hence (1)--(2) imply that the whole nonempty parent rooted bond graph
is covered by \({\cal L}_{11}\).

By the canonical bijection of Note 108,

\[
 {\cal C}^b=\varnothing
 \quad\Longleftrightarrow\quad
 {\cal L}_{\neg11}^{\,b}=\varnothing .
\tag{3}
\]

Since \(C_{11}\) is never root-admissible, the complete child target sector
\(b\) is therefore exactly \({\cal N}^b\). Consequently

\[
\boxed{
P_{\rm sector}
\quad\Longleftrightarrow\quad
\text{the child retains at least one root-admissible target in sector }b.}
\tag{4}
\]

If (4) fails, the child has no vertex at all in sector \(b\), hence no
opposite-gate rooted bond. Thus an actual counterexample to
\(P_{\rm sector}\) would also be an actual counterexample to the rooted
split-bond lemma.

The crossed-double-split example of Note 116 does not decide (4). In its
empty new-cell sector \(b=1\), the child still has two \(C_{10}^1\)
targets. Equation (3) gives
\({\cal L}_{\neg11}^{\,1}\ne\varnothing\), so (2) fails. This verifies
that the new hypothesis excludes the known actual \(P_{\rm mix}\)
counterexample.

## 2. Two gate-parity switch languages

Globally reverse \(\chi\) so that

\[
 \chi(z)=\chi(P)=\chi(Q)=0,
\qquad H=T-z=T^+-\{A,B,C\}.
\tag{5}
\]

Every other colouring orbit may be oriented relative to \(\chi\). For a
set \(K\subseteq V(H)\), write

\[
 \psi_K=\chi|_H\mathbin\triangle K.
\tag{6}
\]

Let \(g_1^*=xy\). A comparison colouring has the same gate bit as \(\chi\)
exactly when

\[
 {\bf1}_K(x)={\bf1}_K(y),
\quad\text{equivalently}\quad
g_1^*\notin\delta_H(K).
\tag{7}
\]

Call such a set **gate-even**.

Define two complete switch languages.

* \({\mathscr P}_{\neg11}^b(\chi)\) consists of the gate-even sets \(K\)
  for which \(\psi_K\), with a suitable colour at \(z\), is a
  root-admissible parent NAE colouring of non-\(11\) state.
* \({\mathscr X}_{N}^b(\chi)\), for \(N\in\{R,U,V\}\), consists of the
  gate-even sets \(K\) for which \(\psi_K\) extends by the \(N\)-row
  (in either global orientation) to a root-admissible child NAE colouring.

These are complete languages: no connectedness, ancestry, or
parent-compatibility requirement is imposed on \(K\). Every actual target
in the named sector gives such a difference set, and conversely every set
in a language gives the corresponding actual target. Therefore

\[
\boxed{
\begin{aligned}
{\cal L}_{\neg11}^{\,b}=\varnothing
 &\iff {\mathscr P}_{\neg11}^b(\chi)=\varnothing,\\
{\cal N}^b=\varnothing
 &\iff
 {\mathscr X}_{R}^b(\chi)\cup
 {\mathscr X}_{U}^b(\chi)\cup
 {\mathscr X}_{V}^b(\chi)=\varnothing .
\end{aligned}}
\tag{8}
\]

The parent mixed bond supplies a different kind of set. Align the
representatives of \(\chi,\eta\) at \(z\), and put

\[
 S=\{v:\chi(v)\ne\eta(v)\}\subseteq V(H).
\tag{9}
\]

Both shores are connected in \(T\), but the gate bits in (1) are opposite,
so

\[
 g_1^*\in\delta_H(S).
\tag{10}
\]

Thus \(S\) is **gate-odd**. Neither \(S\) nor its complement belongs to
either gate-even language in (8). The mixed bond supplies a connected
switch in the opposite parity class from both the excluded parent targets
and the desired child target.

## 3. Exact child membership test

For completeness, membership in
\({\mathscr X}_{N}^b(\chi)\) is intrinsic. Let
\(\gamma(K,N)\) be the candidate child colouring. It exists precisely
when:

1. \(\psi_K(P)=\psi_K(Q)\), so one orientation of the \(N\)-row agrees
   at \(P,Q\);
2. every triangle contained in \(H\), every interval triangle incident
   with \(A\) or \(B\), and the four central patch triangles are NAE;
3. (7) holds, and the root dual edge retains monochromatic status;
4. the two monochromatic component-gluing graphs obtained by attaching
   \(A,B,C\) through \(J_A,J_B,\{P,Q\}\) have total component count three,
   and the two labelled root fragments lie in distinct opposite-colour
   components.

The last condition is exactly the labelled region-tree test of Note 109.
It may be written

\[
\begin{aligned}
c({\cal G}_0(K,N))+c({\cal G}_1(K,N))&=3,\\
x_r\text{ and }x_s&\text{ lie in distinct components of the
opposite-colour gluing graph}.
\end{aligned}
\tag{11}
\]

This test uses the complete actual old exterior. Note 114 begins only
after two root-admissible child endpoints have been found and therefore
does not imply their existence.

## 4. The exact unresolved implication

Equations (8)--(10) turn \(P_{\rm sector}\) into the following statement:

\[
\boxed{
\begin{gathered}
\text{there is a gate-odd connected parent root-preserving switch }S
\text{ from }\chi_{11}^b
\text{ to }\eta_{\neg11}^{1-b},\\
{\mathscr P}_{\neg11}^b(\chi)=\varnothing
\\[2mm]\Longrightarrow\\[1mm]
{\mathscr X}_{R}^b(\chi)\cup
{\mathscr X}_{U}^b(\chi)\cup
{\mathscr X}_{V}^b(\chi)\ne\varnothing .
\end{gathered}}
\tag{12}
\]

This is a parity-class exchange dichotomy: once every gate-even parent
non-\(11\) repair is forbidden, some gate-even child new-cell repair must
exist.

None of the cited results proves a relation between the two gate-even
languages in (12):

* Note 109 gives an exact rank equality for a specified switch; it does
  not produce a switch in the other gate-parity class.
* Note 114 classifies shore connectivity for already occupied child
  cells; it does not force new-cell occupancy.
* Note 115 gives one positive different-exterior repair but retains
  non-\(11\) parent colourings in the same sector.
* Note 116 gives an actual same-sector new-cell vacuum, but precisely in a
  sector where the parent language
  \({\mathscr P}_{\neg11}^b(\chi)\) is nonempty.

At the state/bond/canonical-incidence level, (12) is false: take a parent
family consisting only of a state-\(11\) vertex \(\chi^b\), a non-\(11\)
vertex \(\eta^{1-b}\), and their rooted bond; retain only the canonical
child of \(\eta\). This has
\({\mathscr P}_{\neg11}^b(\chi)=\varnothing\) and
\({\cal N}^b=\varnothing\). It respects the canonical induced-graph
identity and the local cell table, but it is not the complete NAE family
of one actual triangulation split.

Thus the missing premise is not another local row or bond-connectivity
condition. It is an actual **sector-exchange alternative** coupling the
complete parent and child NAE families:

> a gate-odd mixed rooted bond cannot coexist with simultaneous emptiness
> of the same-sector parent non-\(11\) language and the same-sector child
> new-cell language.

Proving this alternative proves \(P_{\rm sector}\); realizing its
simultaneous emptiness in one legal split refutes the rooted split-bond
lemma.

## 5. Decision

The current inputs prove neither \(P_{\rm sector}\) nor its negation.
They reduce it sharply to the actual sector-exchange alternative (12).
The sector hypothesis is essential and excludes the only supplied actual
same-sector-vacuum example. No actual counterexample satisfying (2), and
no theorem coupling the two gate-even switch languages, is contained in
Notes 108, 109, 114, 115, or 116.

