# Per-stratum additive exterior projections do not force mixed-sector survival

This draft uses Notes 115--117 as fixed inputs and performs no new graph
enumeration. Its conclusion has one precise scope: it closes every
\(\mathbb Z\)-linear or \(\mathbb F _2\)-linear projection whose validity is
checked separately on each old-exterior stratum and is therefore preserved
when strata are deleted. It does not classify identities that may hold only
for the complete NAE family of an actual triangulation.

## 1. Exterior strata and closure coordinates

Fix a state-\(11\) colouring \(\chi^b\) and put

\[
 H=T-z=T^+-\{A,B,C\}.
\tag{1}
\]

An **exterior stratum** records:

1. one binary NAE colouring \(\psi\) on the old exterior \(H\);
2. its gate bit;
3. the two ordered root fragments;
4. the monochromatic-component partitions of \(H\);
5. which components meet \(J_A,J_B,\{P,Q\}\);
6. the two ordered interval colour words.

This data determines, by component gluing, whether each possible parent
apex colour and each of the seven child local rows is NAE and
root-admissible. For a stratum \(\sigma\), write

\[
 p_s^b(\sigma),\quad c_s^b(\sigma),\quad
 x_R^b(\sigma),x_U^b(\sigma),x_V^b(\sigma)\in\{0,1\}
\tag{2}
\]

for the parent state-\(s\), canonical child, and three new-cell target
indicators in sector \(b\).

The canonical extension keeps the old exterior and its ordered root
signature. Therefore Notes 108 and 117 give the exact stratumwise
identities

\[
\boxed{
 p_s^b(\sigma)=c_s^b(\sigma)
 \qquad(s\in\{00,10,01\}).}
\tag{3}
\]

Summing (3) gives

\[
 |{\cal L}_s^b|=|{\cal A}_{C_s}^b|
 \qquad(s\in\{00,10,01\}).
\tag{4}
\]

The \(C_{11}\)-closure is never root-admissible. Equations (3)--(4) are the
cross-level identities used below that are forced directly by
common-exterior canonicality.

There is no analogous local parent term for \(x_R,x_U,x_V\). Their apex
colours differ on one or both intervals, and their labelled-root status is
obtained from a different component gluing. In particular, neither NAE nor
the ordered three-component signature makes

\[
 x_R^b(\sigma)+x_U^b(\sigma)+x_V^b(\sigma)
\tag{5}
\]

a signed complement of one of the parent coordinates.

## 2. Two actual stratum witnesses

The octagonal bipyramid in Note 115 contains two decisive strata.

First, normalize the sterile state-\(11\) row \(\alpha\) by
\(\alpha(z)=\alpha(P)=\alpha(Q)=0\). Its two interval words are

\[
 01110,\qquad 01110.
\tag{6}
\]

The zero component is the centre of the ordered region tree, the two
one-components are the root leaves, and the internal vertices of each
interval lie in one distinct leaf. Nevertheless both intervals contain a
\(11\)-edge, so

\[
 p_{11}^1(\sigma_\alpha)=1,\qquad
 x_R^1(\sigma_\alpha)=x_U^1(\sigma_\alpha)
  =x_V^1(\sigma_\alpha)=0.
\tag{7}
\]

Second, the one-vertex exterior change at \(r_6\) is not a
root-admissible parent target, but its \(V\)-closure \(\gamma\) is a
root-admissible child target. Thus another actual stratum satisfies

\[
 p_{00}^1(\sigma_\gamma)=p_{10}^1(\sigma_\gamma)
 =p_{01}^1(\sigma_\gamma)=p_{11}^1(\sigma_\gamma)=0,
\qquad
x_V^1(\sigma_\gamma)=1.
\tag{8}
\]

Equations (7)--(8) show directly that new-cell occupancy can disappear in
a parent target stratum and appear in a stratum having no parent target.
In particular, neither direction is a pointwise implication between parent
target status and new-cell occupancy.

## 3. Fixed-instance comparison

The selected mixed sectors of Notes 115 and 116 have the following
certified data. No counts beyond those stated in the two notes are used.

\[
\begin{array}{c|c|c}
 &\text{Note 115 bipyramid}&\text{Note 116 crossed split}\\ \hline
\text{selected bit }b&1&1\\
|{\cal L}_{11}^b|&1&1\\
|{\cal L}_{\neg11}^b|&2&2\\
|{\cal C}^b|&2&2\\
\text{sterile \(11\)-interval words}&01110,01110&01110,01110\\
\text{ordered region-tree form}&L_r-K-L_s&L_r-K-L_s\\
{\cal N}^b&\text{nonempty: contains }\gamma\in V^1&
             \varnothing
\end{array}
\tag{9}
\]

For Note 115, the parent rows in bit \(1\) are
\(\alpha,\theta_3,\theta_4\), with only \(\alpha\) in state \(11\);
the \(V^1\)-target \(\gamma\) is displayed explicitly in that note.

For Note 116, the child table has two \(C_{10}^1\)-targets and no
\(R^1,U^1,V^1\)-target. By canonicality these correspond to exactly two
non-\(11\) parent targets in bit \(1\). The parent rooted family has nine
vertices and eight non-\(11\) canonical images, so the remaining selected
vertex is the displayed state-\(11\) row \(\chi\).

After global reversal in Note 116, its state-\(11\) interval words become
\(01110,01110\). Its unique centre-colour component contains the split
vertex, its two opposite-colour components are the ordered root leaves,
and the internal vertices of the two intervals lie in the two distinct
leaves. Thus the two examples have the same displayed interval words and
ordered region-tree form, up to exchanging the named intervals and their
ordered leaves. This is not an identification of their full exterior
signatures.

Thus the selected-sector cardinalities and the displayed sterile-endpoint
data agree in (9), while same-sector new-cell occupancy differs. The
difference lies in the other exterior strata:
Note 115 contains \(\sigma_\gamma\), whereas Note 116 contains no
successful new-cell stratum in bit \(1\).

The opposite-sector cardinalities do differ: Note 115 has two non-\(11\)
parent targets there, whereas Note 116 has six. Consequently this
fixed-instance comparison rules out a formula using only the displayed
selected-sector data; it says nothing by itself about an identity using the
entire complete family.

## 4. The per-stratum additive projection

For each exterior stratum \(\sigma\), let

\[
 v(\sigma)=
 (1,p_{00}^{b(\sigma)},p_{10}^{b(\sigma)},
   p_{01}^{b(\sigma)},p_{11}^{b(\sigma)},
   c_{00}^{b(\sigma)},c_{10}^{b(\sigma)},c_{01}^{b(\sigma)},
   x_R^{b(\sigma)},x_U^{b(\sigma)},x_V^{b(\sigma)})_\sigma
\tag{10}
\]

with its gate bit and full ordered signature retained as labels. Fix
\(R=\mathbb Z\) or \(\mathbb F _2\). A **per-stratum additive identity** is
an equality

\[
 \sum_\sigma n_\sigma\,\lambda_{\tau(\sigma)}(v(\sigma))=0
 \quad\text{in }R,
\tag{11}
\]

for formal multiplicities \(n_\sigma\), where the \(R\)-linear functional
\(\lambda_\tau\) may depend on the full ordered-signature label
\(\tau\), and where
\(\lambda_{\tau(\sigma)}(v(\sigma))=0\) is verified for every individual
stratum. Equivalently, (11) remains true after arbitrary deletion or
duplication of strata. This definition includes restriction to any fixed
ordered signature, the canonical identities (3), and all definitional
sums. It deliberately excludes a linear or parity identity whose proof
uses a constraint on which strata can coexist in the complete NAE family
of one actual triangulation.

For reference, the identities explicitly supplied here are

\[
\boxed{
\begin{aligned}
P_s^b-C_s^b&=0
  &&(s=00,10,01;\ b=0,1),\\
P_{\neg11}^b&=\sum_sP_s^b,\qquad
C^b=\sum_sC_s^b,\\
N^b&=X_R^b+X_U^b+X_V^b,
\end{aligned}}
\tag{12}
\]

together with their restrictions to fixed ordered signatures. The claim
below is stronger than observing that (12) has no desired equation: it
allows every identity of the precisely defined form (11).

## 5. Exact route-closure proposition

**Proposition (maximal quantifier closed here).** In the abstract language
consisting of the stratum vectors (10), all per-stratum additive identities
(11), and a distinguished mixed parent rooted bond, the projected premises
of \(P_{\rm sector}\) do not imply \({\cal N}^b\ne\varnothing\), over either
\(\mathbb Z\) or \(\mathbb F _2\).

**Proof.** Start with the actual signature table of the Note 116 split and
retain:

* its sterile state-\(11\) stratum \(\sigma_\chi\) in bit \(1\);
* the opposite-sector non-\(11\) stratum containing the displayed
  mixed-bond endpoint \(\eta\), together with its canonical child;
* the mixed rooted bond \(\chi^1-\eta^0\);
* every NAE/local-row/root-signature outcome attached to each retained
  exterior stratum.

Delete the two bit-\(1\) non-\(11\) exterior strata, hence also their two
canonical \(C_{10}^1\)-closures. The resulting formal table has

\[
 {\cal L}_{\neg11}^1=\varnothing,\qquad
 {\cal C}^1=\varnothing,\qquad
 {\cal N}^1=\varnothing,
\tag{13}
\]

while the mixed bond \(\chi^1-\eta^0\) remains. Every identity (11) remains
valid because its contribution vanishes on each retained stratum
separately; deletion cannot change that fact. Thus the formal table
satisfies the projected premises
\({\cal L}_{\neg11}^1=\varnothing\) and
\(\chi^1-\eta^0\), together with all per-stratum additive identities, but
has \({\cal N}^1=\varnothing\). \(\square\)

The table in the proof is not the complete NAE family of an actual
triangulation split. Therefore the proposition does **not** exclude a
\(\mathbb Z\)-linear or mod-two identity valid only on actual complete
families. Such an identity could constrain the multiplicities of different
strata through common incidence or realizability and need not survive the
deletion used above.

## 6. Decision

The per-stratum additive-projection route is closed, and no larger route is
closed by the present countermodel.

* Notes 115 and 116 agree on selected-sector cardinalities and the
  displayed sterile-endpoint interval/tree data, yet differ in new-cell
  occupancy; this rules out dependence on just those displayed marginals.
* The projected countermodel (13) satisfies every integer or mod-two
  identity valid independently on each exterior stratum while falsifying
  the desired implication.

What remains open includes any additive identity whose validity uses the
complete actual NAE family, as well as non-additive exchange or incidence
coupling between different exterior colourings. The present deletion
argument cannot distinguish or exclude those possibilities.
