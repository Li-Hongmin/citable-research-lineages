# State-\(11\) new-cell fertility is the unresolved occupancy boundary

This note uses only Notes 108, 109, 113, and 114. It separates the
occupancy part of the rooted split-bond lemma from the attachment part.
The conclusion is a strict actual-incidence reduction, not a proof or a
counterexample to the rooted split-bond lemma.

## 1. The exact occupancy proposition

For a gate bit \(b\in\{0,1\}\), let

\[
 {\cal C}^b={\cal A}_{C_{00}}^b\cup{\cal A}_{C_{10}}^b
              \cup{\cal A}_{C_{01}}^b,
 \qquad
 {\cal N}^b={\cal A}_{R}^b\cup{\cal A}_{U}^b
              \cup{\cal A}_{V}^b,
\]

where \(R=R_{00}\), \(U=X_{uy}\), and \(V=X_{vx}\). The occupancy
statement asked for in this pulse is

\[
 (\mathsf{OX}_{\rm full})\qquad
 \bigl({\cal N}^0\times({\cal C}^1\cup{\cal N}^1)\bigr)
 \cup
 \bigl({\cal N}^1\times({\cal C}^0\cup{\cal N}^0)\bigr)
 \ne\varnothing .
\tag{1}
\]

Thus its exact negation is

\[
\boxed{
 ({\cal N}^0=\varnothing\ \text{or}\
       {\cal C}^1\cup{\cal N}^1=\varnothing)
 \ \land\
 ({\cal N}^1=\varnothing\ \text{or}\
       {\cal C}^0\cup{\cal N}^0=\varnothing).}
\tag{2}
\]

There are two genuinely different mechanisms in (2).

1. **New-target vacuum:** \({\cal N}^0={\cal N}^1=\varnothing\).
2. **Single-sector stranding:** for one bit \(b\),
   \({\cal N}^b\ne\varnothing\), but the whole opposite sector
   \({\cal C}^{1-b}\cup{\cal N}^{1-b}\) is empty.

By the canonical bijection of Note 108,

\[
 {\cal C}^b\ne\varnothing
 \quad\Longleftrightarrow\quad
 {\cal L}_{\neg 11}^{\,b}\ne\varnothing .
\tag{3}
\]

The parent hypotheses constrain bond edges, but (1) is a vertex-occupancy
statement. The next sections determine exactly what one state-\(11\)
parent endpoint contributes to that occupancy.

## 2. Full NAE extension conditions along the two intervals

Let \(\chi\) be a root-admissible parent colouring in state \(11\).
Reverse it globally if necessary so that

\[
 \chi(z)=\chi(P)=\chi(Q)=0.
\tag{4}
\]

Let \(I_A\) and \(I_B\) be the two \(P\)--\(Q\) paths in the link cycle
of \(z\), with vertex sets \(J_A\) and \(J_B\). Put \(H=T-z\),
equivalently \(H=T^+-\{A,B,C\}\). Since every parent triangle
\(zv_iv_{i+1}\) is NAE, no edge of either link path has two
\(0\)-coloured ends.

Write \(\operatorname{alt}_A(\chi)\) when the colours strictly alternate
on \(I_A\), and define \(\operatorname{alt}_B(\chi)\) analogously.
Equivalently, in addition to the automatically absent \(00\)-edges, the
corresponding path has no \(11\)-edge.

The five-bit rows of Note 108 solve only the four triangles incident with
\(C,P,Q\). The remaining interval triangles give the following extra,
necessary and sufficient conditions:

\[
\begin{array}{c|c}
\text{extension of the fixed exterior colouring }\chi|_H
 &\text{full child NAE condition}\\ \hline
C_{11}&\text{always}\\
U&\operatorname{alt}_A(\chi)\\
V&\operatorname{alt}_B(\chi)\\
R&\operatorname{alt}_A(\chi)\land
   \operatorname{alt}_B(\chi).
\end{array}
\tag{5}
\]

Indeed, \(U\) changes the split-side colour from \(0\) to \(1\) precisely
on the \(A\)-interval, \(V\) does so on the \(B\)-interval, and \(R\)
does so on both. A triangle with new apex colour \(1\) is NAE exactly
when its link edge is not \(11\). This proves (5).

In particular, the existence of the seven local five-bit rows does not
mean that all four rows with \(P=Q=0\) extend a fixed state-\(11\)
parent colouring.

## 3. Exact labelled-root test for the three nondirect extensions

Let \(Z\) be the \(0\)-component of the parent monochromatic graph that
contains \(z\). Define

\[
\begin{aligned}
t&=\#\{K\in\pi_0(H_0):K\cap(J_A\cup J_B)\ne\varnothing\},\\
t_A&=\#\{K\in\pi_0(H_0):K\cap J_A\ne\varnothing\},\\
t_B&=\#\{K\in\pi_0(H_0):K\cap J_B\ne\varnothing\},\\
t_{PQ}&=\#\{K\in\pi_0(H_0):K\cap\{P,Q\}\ne\varnothing\},\\
a&=\#\{K\in\pi_0(H_1):K\cap J_A\ne\varnothing\},\\
b&=\#\{K\in\pi_0(H_1):K\cap J_B\ne\varnothing\}.
\end{aligned}
\tag{6}
\]

All \(t\) components counted in the first line are fragments of \(Z-z\).
The labelled region tree of \(\chi\) has three vertices. There are exactly
two cases.

### Case I: the \(z\)-colour is the centre colour

Here the parent has one \(0\)-component \(Z\) and two \(1\)-components,
which are exactly the labelled root leaves \(L_r,L_s\). Thus

\[
c(H_0)=t,\qquad c(H_1)=2,\qquad a,b\in\{1,2\}.
\tag{7}
\]

Then the fixed-exterior extensions are root-admissible exactly as follows:

\[
\boxed{
\begin{aligned}
U\text{ is root-admissible}
 &\iff \operatorname{alt}_A(\chi)\land t_B=t\land a=1,\\
V\text{ is root-admissible}
 &\iff \operatorname{alt}_B(\chi)\land t_A=t\land b=1,\\
R\text{ is root-admissible}
 &\iff \operatorname{alt}_A(\chi)\land\operatorname{alt}_B(\chi)
       \land t_{PQ}=t\land a=b=1.
\end{aligned}}
\tag{8}
\]

For example, in the \(U\)-row the \(0\)-vertex \(B\) reassembles precisely
the zero fragments meeting \(J_B\), while the \(1\)-core \(AC\) attaches
to the one-components meeting \(J_A\). The parent three-component count
is retained exactly when all \(t\) zero fragments are reassembled and
\(AC\) attaches to only one leaf. If \(a=2\), it fuses \(L_r,L_s\), so
the labelled root separation fails even if the scalar component count is
repaired by a simultaneous split elsewhere. This proves the first line;
the second is symmetric. In the \(R\)-row, \(C\) can reassemble only the
fragments containing \(P\) or \(Q\), while the separate vertices \(A,B\)
must each attach within a single root leaf. This gives the third line.

### Case II: the \(z\)-colour is a leaf colour

Here the parent has two \(0\)-components, the labelled root leaves, and one
\(1\)-component, the centre. The component \(Z\) is one root leaf; the
other zero leaf does not meet the link of \(z\). Hence

\[
c(H_0)=t+1,\qquad c(H_1)=1,\qquad a=b=1.
\tag{9}
\]

The exact criteria reduce to

\[
\boxed{
\begin{aligned}
U\text{ is root-admissible}
 &\iff \operatorname{alt}_A(\chi)\land t_B=t,\\
V\text{ is root-admissible}
 &\iff \operatorname{alt}_B(\chi)\land t_A=t,\\
R\text{ is root-admissible}
 &\iff \operatorname{alt}_A(\chi)\land\operatorname{alt}_B(\chi)
       \land t_{PQ}=t.
\end{aligned}}
\tag{10}
\]

The unique \(1\)-component cannot be incorrectly fused with another
centre component. Therefore the only labelled-root issue is whether all
fragments of the \(z\)-leaf are reassembled; the untouched zero component
remains the other labelled leaf. This proves (10).

Call \(\chi\) **new-cell fertile** when at least one line of (8),
respectively (10), holds. Equations (5), (8), and (10) are an intrinsic
test in the actual parent triangulation; they do not replace incidence by
a quotient model.

Two simple obstruction profiles show that neither the three-component rank
nor interval NAE alone decides fertility. In Case I, the profile

\[
t=t_A=t_B=t_{PQ}=1,\qquad a=b=2
\tag{11}
\]

is sterile even when both intervals alternate: every nondirect extension
fuses the two labelled root leaves. In Case II, the profile

\[
t=3,\qquad t_A=t_B=2,\qquad t_{PQ}=1
\tag{12}
\]

is sterile even when both intervals alternate: every nondirect extension
leaves a fragment of the \(z\)-leaf unattached. Equations (11)--(12) are
component profiles, not claims that a complete legal split pair realizing
all hypotheses exists.

## 4. What one parent bond does and does not force

Let \(\chi^b\eta^{1-b}\) be a parent rooted bond. Since
\({\cal L}_{11}\) is a vertex cover, at least one endpoint has state \(11\).

* If exactly one endpoint, say \(\chi^b\), has state \(11\), then the
  non-\(11\) endpoint \(\eta\) has a canonical root-admissible child
  extension in \({\cal C}^{1-b}\). The extensions inherited from this
  bond imply (1) exactly when \(\chi\) is new-cell fertile.
* If both endpoints have state \(11\), neither canonical extension is
  root-admissible. The extensions inherited from this bond imply (1)
  exactly when **both** endpoints are new-cell fertile. This is the
  dangerous case: fertility of only one endpoint produces child targets
  in only one gate sector.

The word “exactly” here is restricted to the extensions of the two fixed
parent exterior colourings. The complete child family may contain an
\(R,U,V\) target not obtained as such an extension, and that extra target
may establish (1).

Consequently, a proof of \(\mathsf{OX}_{\rm full}\) from one parent bond
must establish at least one of the following actual-incidence alternatives:

\[
\boxed{
\begin{array}{ll}
\text{(i)}&\text{a mixed \(11\)--non-\(11\) bond whose \(11\)-endpoint
is fertile;}\\
\text{(ii)}&\text{an \(11\)--\(11\) bond whose two endpoints are fertile;}\\
\text{(iii)}&\text{an additional child new-cell target supplying the
missing gate sector.}
\end{array}}
\tag{13}
\]

The parent bond condition and the shore-rank equality of Note 109 do not,
as stated, control the interval-alternation predicates or the six
attachment counts in (6). Notes 108, 109, 113, and 114 also contain no
existence theorem for the extra target in (iii). Thus they do not decide
whether (13) must hold in every actual legal split pair.

## 5. Decision

The current input proves neither \(\mathsf{OX}_{\rm full}\) nor its
negation. It reduces the missing actual theorem to the following sharp
occupancy-flexibility statement:

> In every actual interface-disjoint legal split pair with a nonempty
> parent rooted bond graph covered by \(L_{11}\), either some covered bond
> satisfies the endpoint-fertility alternative (i) or (ii) of (13), or the
> complete child NAE family supplies an extra new-cell target in the
> opposite missing gate sector.

An actual counterexample must simultaneously protect a new-target vacuum
or a single-sector stranded family, and every state-\(11\) endpoint that
could repair the missing sector must fail the corresponding exact test
(8) or (10). The scalar rank calculus, the labelled three-region tree,
and the attachment criteria of Note 114 do not exclude that configuration.

