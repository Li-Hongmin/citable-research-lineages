# Mixed bonds do not supply the required gate-even exterior switch

This draft uses only Notes 108, 109, 114, and 115. It determines the exact
meaning of a connected old-exterior repair and isolates what the mixed
parent bond does not provide. It neither proves nor refutes the existence
of such a repair in every legal split.

## 1. The natural switch convention

Let \(\chi\) be the state-\(11\) endpoint of a mixed parent rooted bond.
After global reversal, fix

\[
\chi(z)=\chi(P)=\chi(Q)=0.
\tag{1}
\]

Put \(H=T-z=T^+-\{A,B,C\}\). For
\(\varnothing\ne K\subsetneq V(H)\), define

\[
\psi_K(v)=\chi(v)\oplus {\bf 1}_K(v),\qquad v\in V(H).
\tag{2}
\]

The most natural version consistent with the one-vertex \(r_6\)-switch in
Note 115 is the following.

**Definition 1 (connected parent-compatible exterior switch).**
The set \(K\) is an admissible old-exterior switch for a new cell
\(N\in\{R,U,V\}\) if:

1. \(H[K]\) is connected;
2. keeping \(z\) coloured \(0\), the colouring \(\psi_K\) is NAE on the
   parent triangulation \(T\);
3. the surviving-gate bit and the root matching edge are unchanged;
4. after choosing the orientation of the \(N\)-row that agrees with
   \(\psi_K(P),\psi_K(Q)\), the resulting child colouring is NAE and
   root-admissible.

No connectivity assumption on \(H[\bar K]\) is required. Occupancy asks
for a target, not for a bond between \(\chi\) and that target. Requiring
both shores to be connected would add an unrelated cycle-exchange
hypothesis. The switch in Note 115 happens to have connected complement,
but its target property does not use that fact.

The empty switch is the sterile fixed exterior. If \(K=V(H)\), then using
the reversed local row gives the global reversal of the empty-switch child
colouring. Hence neither extreme can repair a sterile \(\chi\), and both
may be excluded without loss.

Definition 1 deliberately requires the switched exterior to remain a
parent NAE colouring, but not a parent root-admissible colouring. In the
Note 115 example, the \(r_6\)-switch has exactly this status: the \(V\)-row
repairs the labelled three-component condition only after the split.
If “old-exterior switch” is interpreted more weakly to require only the
child extension to be NAE, condition (4) below should simply be deleted.
All parity and gluing conditions remain necessary and sufficient, and the
parent-bond obstruction in Section 4 is unchanged.

## 2. Exact NAE and parity conditions

Let \({\cal F}_H\) be the triangular faces of \(T\) not incident with
\(z\). In each \(f\in{\cal F}_H\), let \(m_f\) be the unique vertex whose
\(\chi\)-colour is the minority colour on \(f\).

The switched colouring is NAE on all faces in \({\cal F}_H\) if and only if

\[
 K\cap V(f)\notin
 \bigl\{\{m_f\},\,V(f)\setminus\{m_f\}\bigr\}
 \qquad(f\in{\cal F}_H).
\tag{3}
\]

Indeed, these are exactly the two subsets whose flip makes the triangle
monochromatic. For the parent triangles incident with \(z\), parent NAE is
equivalent to

\[
 \{\psi_K(x),\psi_K(y)\}\ne\{0\}
 \qquad
 (xy\in E(I_A)\cup E(I_B)),
\tag{4}
\]

where \(I_A,I_B\) are the two \(P\)--\(Q\) paths in the link of \(z\).
Thus (3)--(4) are the exact parent-compatible NAE test.

Write \(g_1^*=xy\) and \(e^*=uv\) for the surviving-gate and root dual
edges. Their monochromatic statuses are preserved exactly when

\[
 {\bf 1}_K(x)={\bf 1}_K(y),
 \qquad
 {\bf 1}_K(u)={\bf 1}_K(v).
\tag{5}
\]

The first equality is precisely preservation of the gate bit. The second
retains the root matching edge. Once (3)--(4) hold, NAE on the two root
triangles forces the two opposite root vertices \(x_r,x_s\) to lie on the
same \(K\)-shore as \(u,v\).

Every \(R,U,V\) row has \(P,Q\) equally coloured. Consequently a local
row can agree with the switched exterior if and only if

\[
 {\bf 1}_K(P)={\bf 1}_K(Q)=:\sigma.
\tag{6}
\]

Let \(r_N(A),r_N(B),r_N(C),r_N(P),r_N(Q)\) be the standard row from
Note 108, so \(r_N(P)=r_N(Q)=0\). Use the oriented row
\(r_N\oplus\sigma\). The four central patch triangles are then
automatically NAE. The remaining child interval triangles are NAE exactly
when

\[
\begin{aligned}
&\text{no edge of }I_A\text{ has both ends coloured }
  r_N(A)\oplus\sigma\text{ under }\psi_K,\\
&\text{no edge of }I_B\text{ has both ends coloured }
  r_N(B)\oplus\sigma\text{ under }\psi_K.
\end{aligned}
\tag{7}
\]

Equations (3)--(7), together with connectedness of \(H[K]\), are necessary
and sufficient for a connected, parent-compatible, gate-preserving switch
to give a child NAE colouring in the chosen new cell.

## 3. Exact component-gluing test for the labelled root

Fix \(K,N\) satisfying (3)--(7), and let \(\gamma=\gamma(K,N)\) be the
resulting child colouring. For \(i\in\{0,1\}\), construct a gluing graph
\({\cal G}_i(K,N)\) as follows.

* Start with one vertex for every component of
  \(H[\psi_K^{-1}(i)]\).
* Add each of \(A,B,C\) whose oriented row colour is \(i\).
* Join \(A\) to every old component meeting \(J_A\), and \(B\) to every
  old component meeting \(J_B\), whenever the relevant new vertex has
  colour \(i\).
* Join \(C\) to the old components containing \(P,Q\) when \(C,P,Q\)
  have colour \(i\).
* Retain the local edges \(AC,BC\) when their ends both have colour \(i\).

Isolated old component vertices and isolated local vertices are retained.
Contracting the old monochromatic components shows

\[
 c\bigl(T^+[\gamma^{-1}(i)]\bigr)=c({\cal G}_i(K,N)).
\tag{8}
\]

Let \(i=\psi_K(u)=\psi_K(v)\). The root markers \(x_r,x_s\) have colour
\(1-i\). By Note 109 and (8), the exact labelled-root condition is

\[
\boxed{
\begin{aligned}
c({\cal G}_0(K,N))+c({\cal G}_1(K,N))=3,\\
&x_r,x_s\text{ belong to distinct components of }
  {\cal G}_{1-i}(K,N).
\end{aligned}}
\tag{9}
\]

Thus (3)--(7) and (9) are a necessary and sufficient test for every
quantifier in Definition 1. No scalar component count or interval
condition may be dropped: the second line of (9) is the labelled root
separation, while (7) tests triangles not present in the five-bit table.

## 4. Why the mixed parent bond does not force the switch

Let \(\eta\) be the non-\(11\) endpoint of the mixed rooted bond, and choose
its global representative so that \(\eta(z)=\chi(z)=0\). Put

\[
 D=\{v\in V(T):\chi(v)\ne\eta(v)\}.
\tag{10}
\]

Then \(z\notin D\). Since \(\delta_T(D)\) is a parent bond,
\(T[D]=H[D]\) is connected and \(T[\bar D]\) is connected. However,
the two parent endpoints have opposite gate bits, so

\[
 g_1^*\in\delta_H(D).
\tag{11}
\]

Therefore \(D\) violates the first equality in (5). Its complementary
shore violates the same equality. The only connected shore supplied by
the parent bond is in the wrong gate-parity class for the required
same-sector repair.

There is a second local incompatibility. According to the state of
\(\eta\),

\[
\begin{array}{c|c}
\text{state of }\eta&D\cap\{P,Q\}\\ \hline
00&\{P,Q\}\\
10&\{Q\}\\
01&\{P\}.
\end{array}
\tag{12}
\]

Thus for a \(10\)- or \(01\)-endpoint the parent shore also violates (6).
Even in the \(00\)-case, where (6) holds, gate parity (11) still excludes
the shore.

The four-rank equality of Note 109 applies to the gate-changing flip
\(\chi\mapsto\eta\). It gives no rank identity for a different
gate-preserving set \(K\). Similarly, connectivity of \(T[\bar D]\) does
not imply connectivity of \(H[\bar D]\), because removing \(z\) may split
that shore. Hence neither shore of the parent bond is an admissible \(K\),
and none of the cited results derives a different gate-even \(K\) from
that shore.

## 5. Sharp remaining proposition

For \(N\in\{R,U,V\}\), let \({\mathscr K}_N(\chi)\) be the family of
nonempty proper sets \(K\subset V(H)\) satisfying:

\[
\begin{gathered}
H[K]\text{ connected},\qquad
\text{(3)--(7)},\qquad
\text{(9)}.
\end{gathered}
\tag{13}
\]

With Definition 1, the mixed-switch proposition is exactly

\[
\boxed{
 P_{\rm mix}
 \quad\Longleftrightarrow\quad
 {\mathscr K}_R(\chi)\cup{\mathscr K}_U(\chi)
       \cup{\mathscr K}_V(\chi)\ne\varnothing
 \text{ for every sterile mixed-bond endpoint }\chi.}
\tag{14}
\]

The Note 115 bipyramid has \(\{r_6\}\in{\mathscr K}_V(\chi)\). The
parent hypotheses in Notes 108, 109, 114, and 115 assert no
gate-even switch existence, no connectivity statement for such a switch,
and no gluing condition (9) for it. They therefore do not decide (14).

The missing additional premise is precisely **same-sector connected
exterior-switch flexibility**:

> every sterile state-\(11\) endpoint of a mixed rooted bond admits a
> nontrivial connected gate-even parent-compatible NAE switch satisfying
> the new-cell interval conditions and the labelled gluing test (9).

This is strictly stronger than parent bondness. The latter supplies one
connected gate-odd shore, while the premise requires a different
gate-even shore. An actual counterexample to \(P_{\rm mix}\) must make all
three families in (14) empty; an abstract component profile is not enough.

Accordingly, the present axioms yield a sharp exact remainder but neither
a general proof nor an actual counterexample.
