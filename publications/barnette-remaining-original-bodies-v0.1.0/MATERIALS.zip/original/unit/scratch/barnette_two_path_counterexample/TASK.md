# Single leaf: genuine planar-brace failure of the Note 057 two-path target

Long objective: decide Barnette-type Hamiltonicity through an exact structural theorem or a genuine counterexample. Work only in `units/barnette`; read the unit README and Notes 056--062. Do not modify permanent notes or papers. Put all code and outputs only in this scratch directory, using bounded/streaming enumeration.

For every simple plane cubic bipartite brace `F`, root `r` with neighbours `{a,b,s}`, and split `{s}|{a,b}`, Note 057 asks whether `F-r` has two vertex-disjoint spanning paths with ends `a,b` and `s,y` for some free `y`. Determine the counterexample side of this exact universal statement.

First test all explicit planar braces already present in Notes 056--062 and their stored verifiers/data. If none fails and a complete low-order brace generator/corpus is already available locally, perform the cheapest complete census that fits low memory, recording the exact coverage theorem. Do not build a new large census infrastructure and do not report random nonfailure as evidence. A failure must include an explicit plane embedding/graph, root split, and independently checkable exhaustive no-witness certificate; verify simplicity, cubicity, bipartiteness, planarity, and brace/2-extendability.

Route-changing outcomes: genuine counterexample (closes the direct-unicycle route); rigorous finite lower bound from a complete corpus; or no decision because no complete cheap observation exists. Stop at the first of those outcomes. End with exact conclusion and quantifiers, weakest load-bearing argument, evidence level, and unresolved boundary. Do not select a new task or edit permanent files.
