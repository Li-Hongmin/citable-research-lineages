# Note 057 two-path target: complete finite lower bound through order 18

## Exact conclusion and quantifiers

There is no counterexample of order at most $18$.

More precisely, let $F$ be any simple plane cubic bipartite brace with
$|V(F)|\le 18$.  For every root $r$, every singleton neighbour
$s\in N_F(r)$, and the paired set

\[
\{a,b\}=N_F(r)\setminus\{s\},
\]

the graph $F-r$ has two vertex-disjoint paths whose union is all of
$V(F)\setminus\{r\}$, one with ends $a,b$ and the other with ends
$s,y$ for some free vertex $y$ in the colour class of $r$,
$y\ne r$.

Consequently, any genuine counterexample to the exact universal statement
of Note 057 has at least $20$ vertices.

## Complete coverage

For each even order $n=6,8,\ldots,18$, the command

```text
geng -cqb -d3 -D3 n
```

streams one representative of every connected simple cubic bipartite graph
of order $n$.  The exact generated and filtered counts were

| order | generated | planar | planar 3-connected | planar braces |
|---:|---:|---:|---:|---:|
| 6  | 1   | 0 | 0 | 0 |
| 8  | 1   | 1 | 1 | 1 |
| 10 | 2   | 0 | 0 | 0 |
| 12 | 5   | 1 | 1 | 1 |
| 14 | 13  | 1 | 1 | 0 |
| 16 | 38  | 3 | 2 | 2 |
| 18 | 149 | 3 | 2 | 1 |

Thus the census covers $209$ isomorphism classes and leaves exactly five
plane braces:

```text
8   G?zTb_
12  K??FEagT@WB_
16  O????B_sDOI_I_DO@W?M?
16  O????B_sCWKOI_BOAW?i?
18  Q??????wE_P_W_IO@g?h?Cg?B_?
```

Every vertex of every representative was used as root and all three choices
of singleton port were tested, for

\[
3(8+12+16+16+18)=210
\]

rooted fixed fibres.  All $210$ have witnesses.  The minimum number of
witnesses in any fibre is $4$; the per-graph minima and maxima are

| order/graph | minimum | maximum |
|---|---:|---:|
| cube, 8 | 4 | 4 |
| `K??FEagT@WB_`, 12 | 6 | 12 |
| `O????B_sDOI_I_DO@W?M?`, 16 | 8 | 24 |
| `O????B_sCWKOI_BOAW?i?`, 16 | 16 | 34 |
| order-18 brace | 24 | 46 |

In particular, all explicit planar braces in Notes 056--062 were tested.
For the Note 056/059 labelled fibre

```text
K??FEagT@WB_, root 0, singleton 6 | paired {7,8}
```

there are $6$ witnesses.  For the Note 062 labelled fibre

```text
O????B_sDOI_I_DO@W?M?, root 0, singleton 8 | paired {9,10}
```

there are $8$ witnesses.  The cube has $4$ witnesses in each of its
$24$ root/split fibres.  The stored verifiers for the 12- and 16-vertex
graphs were rerun successfully before the complete census.

Orders below six contain no simple cubic bipartite graph, and a cubic
bipartite graph has equal colour classes, hence even order.  The displayed
orders therefore cover every possible order below $20$, not merely a
selected parity subsequence.

## Weakest load-bearing argument

The only global coverage interface is the canonical completeness of
`geng -cqb -d3 -D3 n`, together with the exact planarity decisions used to
filter its output.  Everything after that is directly finite:

1. Each retained graph comes with a stored spherical face system.  The
   checker verifies that every directed edge occurs exactly once, every
   vertex has one cyclic rotation, and Euler's equation gives $2$.
2. Brace status is checked by extending every independent two-edge matching
   using a recursive exact matching search.  The strict-Hall inequalities on
   both colour sides are checked independently.
3. For each root, the census exhausts all local degree selections in
   $F-r$: each port has selected degree one and every other opposite-colour
   vertex has selected degree two.  Acyclic choices are streamed with a
   rollback disjoint-set structure.  The required fibre is recognized by
   the port component partition and by the remaining colour-side degrees.
4. The stored certificate does not require trusting the enumeration counts:
   it contains one explicit edge set and the two ordered paths for each of
   the $210$ fibres.  A separate checker verifies spanning, disjointness,
   graph-edge membership, and the exact endpoint sets.

No SAT, MILP, CP solver, randomized search, or unrecorded sample is used.

## Evidence level

This is an exact finite computer-assisted lower bound, not a general proof.
The generator was nauty 2.9.3 `geng` at `/opt/homebrew/bin/geng`; certificate
construction and checking used NetworkX 3.6.1.  The matching and path parts
are solver-free and independently recomputed from the stored graph data.
The external trusted interfaces are `geng`'s isomorph-free completeness and
the exact planarity algorithm used during corpus filtering.

Reproduction from this directory:

```bash
uv run --with 'networkx==3.6.1' \
  census_planar_brace_two_paths_through18.py \
  --output census_certificate.json

uv run --with 'networkx==3.6.1' \
  verify_census_certificate.py census_certificate.json
```

The terminal markers are

```text
PLANAR_BRACE_TWO_PATH_TARGET_VERIFIED_THROUGH_18
PLANAR_BRACE_TWO_PATH_CENSUS_CERTIFICATE_VERIFIED
```

## Unresolved boundary

The first unresolved order is $20$.  This finite result neither proves the
universal planar two-path statement nor refutes it at any larger order.  It
also does not prove root-preserving cycle absorption (RCA): the census checks
the two-path target directly, and Note 057's separated two-cycle condition is
only a sufficient route to that target.  The observed witness multiplicities
do not justify extrapolation beyond order $18$.
