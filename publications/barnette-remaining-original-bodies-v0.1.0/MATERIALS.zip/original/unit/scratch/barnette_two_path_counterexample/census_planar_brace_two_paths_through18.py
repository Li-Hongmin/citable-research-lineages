#!/usr/bin/env python3
"""Complete low-order census for the Note 057 planar two-path target.

For every even order 6 through 18, ``geng -cqb -d3 -D3`` streams all
connected simple cubic bipartite graphs, one representative per isomorphism
class.  We retain precisely the planar 2-extendable graphs.  On each retained
graph, every vertex is used as the root and all three singleton/paired port
splits are tested by an exhaustive degree-selection search in ``F-r``.

The search holds only one generated graph and one partial forest in memory.
The JSON output contains one directly checkable two-path witness for every
root/split, together with the exact number of witnesses in that fibre.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from itertools import combinations
import json
from pathlib import Path
import shutil
import subprocess
from typing import Iterator

import networkx as nx


ORDERS = tuple(range(6, 19, 2))
EXPECTED_RAW_COUNTS = {6: 1, 8: 1, 10: 2, 12: 5, 14: 13, 16: 38, 18: 149}
EXPECTED_BRACE_COUNTS = {6: 0, 8: 1, 10: 0, 12: 1, 14: 0, 16: 2, 18: 1}

Edge = tuple[int, int]


def edge(first: int, second: int) -> Edge:
    return (first, second) if first < second else (second, first)


def has_perfect_matching(graph: nx.Graph, vertices: frozenset[int]) -> bool:
    """Exact recursive perfect-matching decision on an induced vertex set."""

    if not vertices:
        return True
    if len(vertices) % 2:
        return False
    first = min(
        vertices,
        key=lambda vertex: sum(neighbour in vertices for neighbour in graph[vertex]),
    )
    return any(
        has_perfect_matching(graph, vertices - {first, neighbour})
        for neighbour in sorted(graph[first])
        if neighbour in vertices
    )


def is_two_extendable_direct(graph: nx.Graph) -> bool:
    """Check directly that every independent two-edge matching extends."""

    all_vertices = frozenset(graph)
    all_edges = tuple(sorted(edge(first, second) for first, second in graph.edges()))
    for first, second in combinations(all_edges, 2):
        endpoints = frozenset(first + second)
        if len(endpoints) != 4:
            continue
        if not has_perfect_matching(graph, all_vertices - endpoints):
            return False
    return True


def strict_hall_two_extendable(graph: nx.Graph) -> bool:
    """Independent bipartite strict-Hall characterization cross-check."""

    colour = nx.bipartite.color(graph)
    sides = tuple(
        tuple(sorted(vertex for vertex in graph if colour[vertex] == value))
        for value in (0, 1)
    )
    if len(sides[0]) != len(sides[1]):
        return False
    for side in sides:
        for size in range(1, len(side) - 1):
            for shore in combinations(side, size):
                neighbours = set().union(*(set(graph[vertex]) for vertex in shore))
                if len(neighbours) < size + 2:
                    return False
    return True


def plane_faces(graph: nx.Graph, embedding: nx.PlanarEmbedding) -> tuple[tuple[int, ...], ...]:
    """Extract and internally verify a spherical rotation-system certificate."""

    used: set[tuple[int, int]] = set()
    faces = []
    for first, second in embedding.edges():
        if (first, second) not in used:
            faces.append(tuple(embedding.traverse_face(first, second, used)))
    directed = tuple(
        (face[index], face[(index + 1) % len(face)])
        for face in faces
        for index in range(len(face))
    )
    expected = {
        dart
        for first, second in graph.edges()
        for dart in ((first, second), (second, first))
    }
    assert len(directed) == len(set(directed)) == 2 * graph.number_of_edges()
    assert set(directed) == expected
    assert len(graph) - graph.number_of_edges() + len(faces) == 2
    return tuple(faces)


class RollbackDSU:
    def __init__(self, vertices: tuple[int, ...]):
        self.parent = {vertex: vertex for vertex in vertices}
        self.rank = {vertex: 1 for vertex in vertices}
        self.history: list[tuple[int, int, int] | None] = []

    def find(self, vertex: int) -> int:
        while self.parent[vertex] != vertex:
            vertex = self.parent[vertex]
        return vertex

    def snapshot(self) -> int:
        return len(self.history)

    def union(self, first: int, second: int) -> bool:
        first = self.find(first)
        second = self.find(second)
        if first == second:
            self.history.append(None)
            return False
        if self.rank[first] < self.rank[second]:
            first, second = second, first
        self.history.append((second, first, self.rank[first]))
        self.parent[second] = first
        self.rank[first] += self.rank[second]
        return True

    def rollback(self, snapshot: int) -> None:
        while len(self.history) > snapshot:
            item = self.history.pop()
            if item is None:
                continue
            child, parent, old_rank = item
            self.parent[child] = child
            self.rank[parent] = old_rank


@dataclass
class RootSearchResult:
    root: int
    ports: tuple[int, int, int]
    local_selections: int
    acyclic_selections: int
    witness_counts: tuple[int, int, int]
    witnesses: tuple[dict[str, object] | None, ...]


def paths_from_forest(
    vertices: tuple[int, ...], selected: tuple[Edge, ...]
) -> tuple[tuple[int, ...], tuple[int, ...]]:
    support = nx.Graph()
    support.add_nodes_from(vertices)
    support.add_edges_from(selected)
    assert nx.is_forest(support) and nx.number_connected_components(support) == 2
    paths = []
    for component_vertices in nx.connected_components(support):
        component = support.subgraph(component_vertices)
        ends = sorted(vertex for vertex, degree in component.degree() if degree == 1)
        assert len(ends) == 2
        paths.append(tuple(nx.shortest_path(component, ends[0], ends[1])))
    return tuple(sorted(paths))  # type: ignore[return-value]


def search_root(graph: nx.Graph, root: int) -> RootSearchResult:
    """Exhaust all degree-feasible edge choices for one root."""

    colour = nx.bipartite.color(graph)
    x_vertices = tuple(sorted(vertex for vertex in graph if colour[vertex] != colour[root]))
    y_vertices = tuple(
        sorted(vertex for vertex in graph if colour[vertex] == colour[root] and vertex != root)
    )
    y_index = {vertex: index for index, vertex in enumerate(y_vertices)}
    ports = tuple(sorted(graph[root]))
    pole_vertices = tuple(sorted(set(graph) - {root}))

    options_by_x: dict[int, tuple[tuple[Edge, ...], ...]] = {}
    for x_vertex in x_vertices:
        available = tuple(
            sorted(
                edge(x_vertex, neighbour)
                for neighbour in graph[x_vertex]
                if neighbour != root
            )
        )
        required = 1 if x_vertex in ports else 2
        options_by_x[x_vertex] = tuple(combinations(available, required))

    # Put the three two-option ports last; the nonports create cycles earlier.
    ordered_x = tuple(sorted(x_vertices, key=lambda vertex: (vertex in ports, vertex)))
    local_selections = 1
    for x_vertex in ordered_x:
        local_selections *= len(options_by_x[x_vertex])

    dsu = RollbackDSU(pole_vertices)
    y_degrees = [0] * len(y_vertices)
    selected: list[Edge] = []
    acyclic_selections = 0
    counts = [0, 0, 0]
    witnesses: list[dict[str, object] | None] = [None, None, None]

    def visit(position: int) -> None:
        nonlocal acyclic_selections
        if position == len(ordered_x):
            acyclic_selections += 1
            if max(y_degrees) > 2:
                return
            # The total Y-degree is 2|Y|-1, so max <= 2 forces exactly one
            # free degree-one endpoint and all other Y-degrees equal to two.
            free = tuple(
                vertex for vertex, degree in zip(y_vertices, y_degrees, strict=True) if degree == 1
            )
            assert len(free) == 1 and all(degree in (1, 2) for degree in y_degrees)
            roots = tuple(dsu.find(port) for port in ports)
            singleton_indices = tuple(
                index for index, component in enumerate(roots) if roots.count(component) == 1
            )
            if len(singleton_indices) != 1:
                return
            singleton_index = singleton_indices[0]
            counts[singleton_index] += 1
            if witnesses[singleton_index] is None:
                forest = tuple(sorted(selected))
                paths = paths_from_forest(pole_vertices, forest)
                singleton = ports[singleton_index]
                paired = tuple(port for port in ports if port != singleton)
                path_endsets = {frozenset((path[0], path[-1])) for path in paths}
                assert frozenset(paired) in path_endsets
                assert frozenset((singleton, free[0])) in path_endsets
                witnesses[singleton_index] = {
                    "singleton": singleton,
                    "paired": paired,
                    "free_endpoint": free[0],
                    "forest_edges": forest,
                    "paths": paths,
                }
            return

        x_vertex = ordered_x[position]
        for option in options_by_x[x_vertex]:
            snapshot = dsu.snapshot()
            edge_snapshot = len(selected)
            touched_y: list[int] = []
            acyclic = True
            for chosen_edge in option:
                first, second = chosen_edge
                if not dsu.union(first, second):
                    acyclic = False
                    break
                selected.append(chosen_edge)
                y_vertex = first if first in y_index else second
                y_degrees[y_index[y_vertex]] += 1
                touched_y.append(y_vertex)
            if acyclic:
                visit(position + 1)
            for y_vertex in touched_y:
                y_degrees[y_index[y_vertex]] -= 1
            del selected[edge_snapshot:]
            dsu.rollback(snapshot)

    visit(0)
    return RootSearchResult(
        root=root,
        ports=ports,
        local_selections=local_selections,
        acyclic_selections=acyclic_selections,
        witness_counts=tuple(counts),
        witnesses=tuple(witnesses),
    )


def generated_graphs(order: int) -> Iterator[tuple[str, nx.Graph]]:
    process = subprocess.Popen(
        ("geng", "-cqb", "-d3", "-D3", str(order)),
        stdout=subprocess.PIPE,
        text=True,
    )
    assert process.stdout is not None
    for line in process.stdout:
        graph6 = line.strip()
        if graph6:
            yield graph6, nx.from_graph6_bytes(graph6.encode())
    assert process.wait() == 0


def serializable_root(result: RootSearchResult) -> dict[str, object]:
    return {
        "root": result.root,
        "ports": result.ports,
        "local_selections": result.local_selections,
        "acyclic_selections": result.acyclic_selections,
        "witness_counts_by_singleton_index": result.witness_counts,
        "witnesses": result.witnesses,
    }


def census() -> dict[str, object]:
    order_records = []
    brace_records = []
    total_fibres = 0
    minimum_witness_count: int | None = None

    for order in ORDERS:
        raw = 0
        planar = 0
        planar_three_connected = 0
        braces = 0
        for graph6, graph in generated_graphs(order):
            raw += 1
            assert len(graph) == order
            assert nx.number_of_selfloops(graph) == 0
            assert nx.is_connected(graph) and nx.is_bipartite(graph)
            assert set(dict(graph.degree()).values()) == {3}

            is_planar, embedding = nx.check_planarity(graph, counterexample=True)
            if not is_planar:
                continue
            planar += 1
            assert isinstance(embedding, nx.PlanarEmbedding)
            faces = plane_faces(graph, embedding)
            if nx.node_connectivity(graph) >= 3:
                planar_three_connected += 1

            direct = is_two_extendable_direct(graph)
            hall = strict_hall_two_extendable(graph)
            assert direct == hall
            if not direct:
                continue
            braces += 1
            roots = tuple(search_root(graph, root) for root in sorted(graph))
            assert all(min(result.witness_counts) > 0 for result in roots)
            total_fibres += 3 * len(graph)
            graph_minimum = min(count for result in roots for count in result.witness_counts)
            minimum_witness_count = (
                graph_minimum
                if minimum_witness_count is None
                else min(minimum_witness_count, graph_minimum)
            )
            brace_records.append(
                {
                    "order": order,
                    "graph6": graph6,
                    "edges": tuple(sorted(edge(first, second) for first, second in graph.edges())),
                    "faces": faces,
                    "two_extendable_direct": direct,
                    "strict_hall_both_sides": hall,
                    "roots": tuple(serializable_root(result) for result in roots),
                }
            )

        assert raw == EXPECTED_RAW_COUNTS[order]
        assert braces == EXPECTED_BRACE_COUNTS[order]
        order_records.append(
            {
                "order": order,
                "generated_connected_simple_cubic_bipartite": raw,
                "planar": planar,
                "planar_three_connected": planar_three_connected,
                "planar_braces": braces,
            }
        )
        print(
            f"order={order} raw={raw} planar={planar} "
            f"planar_3conn={planar_three_connected} braces={braces}",
            flush=True,
        )

    assert len(brace_records) == 5
    assert total_fibres == 210
    assert minimum_witness_count is not None and minimum_witness_count > 0
    return {
        "coverage": {
            "orders": ORDERS,
            "generator_command": "geng -cqb -d3 -D3 n",
            "generator_path": shutil.which("geng"),
            "networkx_version": nx.__version__,
            "isomorphism_representatives": sum(EXPECTED_RAW_COUNTS.values()),
            "planar_brace_isomorphism_classes": len(brace_records),
            "root_split_fibres": total_fibres,
        },
        "orders": tuple(order_records),
        "braces": tuple(brace_records),
        "conclusion": {
            "counterexamples_found": 0,
            "minimum_witness_count_in_any_root_split_fibre": minimum_witness_count,
            "finite_lower_bound": "Every simple plane cubic bipartite brace with at most 18 vertices satisfies the Note 057 two-path target for every root and every singleton/paired split.",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    payload = census()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
        print("certificate", arguments.output)
    print(json.dumps(payload["coverage"], sort_keys=True))
    print(json.dumps(payload["conclusion"], sort_keys=True))
    print("PLANAR_BRACE_TWO_PATH_TARGET_VERIFIED_THROUGH_18")


if __name__ == "__main__":
    main()
