# Exact crossing convolution at the Note 154 carrier

This scratch lemma completes the finite carrier side of the annular-factor
question.  It neither proves nor refutes the existence of a one-crossing
factor.

Let (P=B-\{q_0,q_2\}) be a plane four-port factor with cyclic ports
(0,1,2,3).  A boundary row is **clean** when (P-N) has no closed
component.  Write

* (Z) for clean state-empty rows with complement pairing
  (01\mid23);
* (U_i) for clean state-(A_i=\{i,i+1\}) rows.  Its complement is the
  unique path on the two ports outside (A_i);
* (O_{02}) for clean state-empty rows with pairing (03\mid12).

There is no clean state-(\Omega) row: every vertex of its complement has
degree two.  Planarity excludes the crossing state-empty pairing
(02\mid13).  Thus the six classes above exhaust all factor rows that can
join a rooted target.

For classes (X,Y), let (I_{XY}) be the number of unordered factor-row
pairs (N\in X,R\in Y) whose symmetric difference is one path on the
state-symmetric-difference ports and has no closed component.  In
particular, put

\[
 I_{01}=I_{Z,U_0},\qquad I_{12}=I_{Z,U_1}.
\]

Then the complete rooted family obtained by gluing (P) to the fixed
Note 154 carrier at ports ((19,10,21,9)) satisfies

\[
 \boxed{|E\Gamma_{g_1}|=I_{01}+2I_{12}.}
\tag{1}
\]

Indeed, the complete carrier compatibility sets are

\[
\begin{array}{c|c|c}
\text{factor class}&\text{carrier rows}&g_1\text{-sectors}\\ \hline
Z&K_1,K_2,K_{10},K_{19},K_{20}&0,1,0,0,1\\
O_{02}&K_0,K_{18}&0,0\\
U_0&K_{29}&1\\
U_1&K_{31},K_{41}&0,0\\
U_2&\varnothing&-\\
U_3&K_{43},K_{52}&0,0.
\end{array}
\tag{2}
\]

Among every opposite-sector carrier pair in (2), the only pairs whose
bond atom has no closed component are

\[
 d(K_{10},K_{29})=01,
 \qquad
 d(K_2,K_{31})=d(K_{20},K_{41})=12.
\tag{3}
\]

For a two-defect pair, the carrier path and factor path join into one
alternating cycle precisely when both have zero closed components.  The
first slot in (3) therefore contributes one joined crossing for every
productive (Z-U_0) pair, while the last two slots contribute two joined
crossings for every productive (Z-U_1) pair.  Every remaining class pair
either has no rooted join, lies in one gate sector, or already has a closed
carrier component.  Closed components on the two shores are disjoint after
gluing and cannot cancel.  This proves (1).

Consequently a one-crossing annular factor exists at this fixed carrier if
and only if

\[
 \boxed{I_{01}=1\quad\text{and}\quad I_{12}=0.}
\tag{4}
\]

The designated (N_0,N_1) from (T0)--(TB) already give (I_{01}\ge1).
Thus the entire common-incidence problem has the sharper form

\[
 I_{01}\ge1
 \quad\Longrightarrow?\quad
 I_{01}\ge2\ \text{ or }\ I_{12}\ge1
\tag{5}

for complete boundary-row families of finite simple plane cubic bipartite
factors.  The cube has ((I_{01},I_{12})=(1,1)), explaining its three
crossings without reference to the inert (U_2,O_{02},U_3) rows.

The disposable verifier
`units/barnette/scratch/controller_complete_factor_join_boundary.py`
reconstructs all 54 carrier rows and asserts that (3) is the complete list
of productive carrier slots.  Its terminal marker is
`COMPLETE_FACTOR_JOIN_BOUNDARY_PRINTED`.
