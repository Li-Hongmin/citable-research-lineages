"""Two fixed interfaces on Pro's existing 20-vertex graph; stdlib only.

Run: python3 scratch/check_short_arc_forbidden_edge_smoothing_20260927.py
Reuses the earlier pure graph helpers, not its verify()/shortest-return run.
Stores at most the small matching families of this one graph and its reductions.
"""

from collections import Counter
from pathlib import Path
import json
import runpy


helpers = runpy.run_path(str(Path(__file__).with_name("pro-E-independent-checker.py")))
edge = helpers["edge"]
components = helpers["components"]
perfect_matchings = helpers["perfect_matchings"]
expand = helpers["expand"]
check_graph = helpers["check_graph"]
walk_edges = helpers["walk_edges"]
cyclic_equal = helpers["cyclic_equal"]


def labelled_matchings(vertices, edges):
    """Keep parallel-edge identities in the T calculation."""
    adj = {v: [] for v in vertices}
    for label, (a, b) in edges.items():
        adj[a].append((b, label))
        adj[b].append((a, label))

    def visit(left, chosen):
        if not left:
            yield frozenset(chosen)
            return
        a = min(left)
        for b, label in adj[a]:
            if b in left:
                yield from visit(left - {a, b}, chosen + [label])

    yield from visit(set(vertices), [])


def verify():
    vertices = set(range(8))
    edges = {edge(*p) for p in [(0, 1), (0, 3), (0, 4), (1, 2), (1, 7),
                              (2, 3), (2, 6), (3, 5), (4, 5), (4, 7),
                              (5, 6), (6, 7)]}
    faces = [[0, 1, 2, 3], [4, 5, 6, 7], [1, 0, 4, 7],
             [2, 1, 7, 6], [3, 2, 6, 5], [0, 3, 5, 4]]
    check_graph(vertices, edges, faces)
    for site, carrier in [((7, 6, 5, 4), [7, 6, 5, 4]),
                          ((0, 1, 7, 4), [0, 1, 7, 4]),
                          ((0, 3, 5, 10), [0, 3, 5, 10, 11, 4])]:
        vertices, edges, faces = expand(vertices, edges, faces, site, carrier)
        check_graph(vertices, edges, faces)
    pm = list(perfect_matchings(vertices, edges))
    hamilton = [edges - n for n in pm if len(components(vertices, edges - n)) == 1]
    assert len(vertices) == 20
    assert all(any(a in c and b not in c for c in hamilton)
               for a in edges for b in edges if a != b)
    # Check the history-derived 2-extendability on this fixed fixture too.
    assert all(any({a, b} <= n for n in pm)
               for a in edges for b in edges if set(a).isdisjoint(b))

    answer = {"parent_order": len(vertices), "parent_PM": len(pm),
              "parent_Hamilton": len(hamilton), "interfaces": []}
    fixtures = [
        ("Pro_nonopposite", (4, 0, 16, 19), edge(1, 2),
         [4, 0, 16, 19, 10, 11]),
        ("same_graph_opposite_square", (0, 16, 19, 10), edge(17, 18),
         [0, 16, 19, 10, 11, 4]),
    ]
    for name, site, f, carrier in fixtures:
        u, v, x, y = site
        p, e, q = edge(u, v), edge(v, x), edge(x, y)
        z, = [a for a in vertices if edge(v, a) in edges and a not in (u, x)]
        w, = [a for a in vertices if edge(x, a) in edges and a not in (v, y)]
        alpha, beta = edge(v, z), edge(x, w)
        assert len({u, z, w, y}) == 4
        assert set(f).isdisjoint(site) and edge(u, y) not in edges
        assert any(cyclic_equal(face, carrier) or cyclic_equal(face[::-1], carrier)
                   for face in faces)
        joint = [c for c in hamilton if e in c and f not in c]
        assert joint and all(not ({p, q} & c) for c in joint)
        xv = vertices - {v, x}
        xe = {a for a in edges if set(a) <= xv}
        ye = xe - {f}
        ports = {u, z, w, y}

        def paths(a, b):
            # Complement of a spanning a-b path: all vertices matched except
            # the two degree-2 ports that are not path endpoints.
            active = xv - (ports - {a, b})
            return [frozenset(xe - n) for n in perfect_matchings(active, xe)
                    if len(components(xv, xe - n)) == 1]

        path_counts = {}
        for a, b in [(z, w), (u, y), (u, w), (z, y)]:
            family = paths(a, b)
            avoid = [c for c in family if f not in c]
            assert family
            assert bool(avoid) == ({a, b} == {z, w})
            path_counts[f"{a}-{b}"] = {"all": len(family), "avoid_f": len(avoid)}

        def pairing(a, b, c, d):
            return frozenset((frozenset((a, b)), frozenset((c, d))))

        da, db = [], []
        fixed_pm = [n for n in pm if {e, f} <= n]
        separated = []
        for n in fixed_pm:
            cover = xe - (n - {e})
            cc = components(xv, cover)
            if len(cc) == 2 and all(len(set(c) & ports) == 2 for c in cc):
                key = frozenset(frozenset(set(c) & ports) for c in cc)
                assert key in (pairing(u, y, z, w), pairing(u, z, w, y))
                (da if key == pairing(u, y, z, w) else db).append(frozenset(cover))
            gc = components(vertices, edges - n)
            sigma = not any({v, x} <= set(c) for c in gc)
            if sigma:
                separated.append(n)
        assert da and db  # Fixed positive fixtures only, not an all-order claim.
        assert len([c for c in hamilton if f not in c]) == len(da) + len(joint)
        targets = {c | {alpha, e, beta} for c in db}
        for path in targets:
            deg = Counter(a for g in path for a in g)
            assert all(deg[a] == (1 if a in (u, y) else 2) for a in vertices)
            assert len(components(vertices, path)) == 1
            assert not ({p, q, f} & path)
        if name == "Pro_nonopposite":
            stated = [4, 11, 10, 9, 8, 7, 1, 13, 14, 15, 12, 0, 16,
                      17, 3, 2, 6, 5, 18, 19]
            assert frozenset(walk_edges(stated)) in targets

        # T has separately labelled new edges, including a parallel copy of f.
        te = {a: a for a in sorted(xe)}
        te.update(g=edge(z, w), h=edge(u, y))
        tj = []
        for n in labelled_matchings(xv, te):
            c = set(te) - n
            if "h" in c and f not in c and len(components(xv, {te[a] for a in c})) == 1:
                assert "g" in c
                tj.append(frozenset(c))
        assert {frozenset((path - {alpha, e, beta}) | {"g", "h"})
                for path in targets} == set(tj)
        for n in fixed_pm:
            tc = set(te) - (n - {e})
            gc = components(vertices, edges - n)
            sigma = not any({v, x} <= set(c) for c in gc)
            assert len(components(xv, {te[a] for a in tc})) == len(gc) + 1 - 2 * sigma

        bridges = [a for a in ye if len(components(xv, ye - {a})) > 1]
        assert len(components(xv, ye)) == 1
        for a in bridges:
            cc = components(xv, ye - {a})
            assert any(len(c) == 1 and c[0] in {z, w} & set(f) for c in cc)

        # Smooth f, retaining s and t as names in the output (L itself is simple).
        xi, eta = f
        na = [a for a in vertices if edge(xi, a) in edges and a != eta]
        nb = [a for a in vertices if edge(eta, a) in edges and a != xi]
        s, t = edge(*na), edge(*nb)
        lv = vertices - set(f)
        old = {a for a in edges if set(a) <= lv}
        assert s not in old and t not in old and s != t
        le = old | {s, t}
        assert all(sum(a in g for g in le) == 3 for a in lv)
        assert len(components(lv, le)) == 1
        assert all(len(components(lv, le - {a})) == 1 for a in le)
        zv = lv - {v, x}
        ze = {a for a in le if set(a) <= zv}
        assert len(components(zv, ze)) == 1
        assert all(len(components(zv, ze - {a})) == 1 for a in ze)
        distribution, lifted = Counter(), set()
        all_separated = 0
        for n in perfect_matchings(lv, le):
            ff = frozenset(le - n)
            assert (s in ff) == (t in ff)
            if e not in n:
                continue
            cc = components(lv, ff)
            split = not any({v, x} <= set(c) for c in cc)
            distribution[(split, s in ff, len(cc))] += 1
            if split:
                all_separated += 1
                if set(f) & {z, w}:
                    assert s in ff and t in ff
                if s in ff:
                    lifted.add(ff)
        contracted = {frozenset(((edges - n) & old) | {s, t}) for n in separated}
        assert lifted == contracted and all_separated

        if f == edge(z, w):
            assert any(cyclic_equal(face, [v, x, w, z]) or
                       cyclic_equal(face[::-1], [v, x, w, z]) for face in faces)
            suppliers = [c for c in hamilton if p in c and beta not in c]
            assert suppliers
            for c in suppliers:
                assert {p, e, q, f} <= c and not ({alpha, beta} & c)
                n = ((edges - c) - {alpha, beta}) | {e, f}
                assert frozenset(n) in pm
                cc = components(vertices, edges - n)
                assert len(cc) == 2 and not any({v, x} <= set(a) for a in cc)
                assert frozenset((edges - n - {p, q}) | {e}) in targets

        answer["interfaces"].append({
            "name": name, "site": site, "f": f, "z_w": (z, w),
            "joint_parent_Hamilton": len(joint), "path_states": path_counts,
            "D_uy_zw_avoid_f": len(da), "D_uz_wy_avoid_f": len(db),
            "T_order": len(xv), "T_has_parallel_edges": len(set(te.values())) != len(te),
            "J_T_h_f": len(tj), "Y_bridges": sorted(bridges),
            "L_order": len(lv), "s_t": (s, t),
            "L_e_omitting_factor_distribution": [
                {"root_split": split, "s_t_used": used, "cycles": cycles, "count": count}
                for (split, used, cycles), count in sorted(distribution.items())],
            "fixed_e_f_PM": len(fixed_pm), "separated_fixed_e_f_PM": len(separated),
        })
    answer["result"] = "SHORT_ARC_FORBIDDEN_EDGE_SMOOTHING_VERIFIED"
    return answer


if __name__ == "__main__":
    print(json.dumps(verify(), ensure_ascii=False, indent=2))
