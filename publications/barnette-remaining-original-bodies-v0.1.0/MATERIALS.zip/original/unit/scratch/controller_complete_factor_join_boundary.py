#!/usr/bin/env python3
"""Print the complete clean-factor / fixed-carrier join boundary.

This is a disposable controller calculation.  It imports the promoted
Note 157 carrier verifier and extends its four parity-relevant atoms to
every planar clean four-port complement atom.
"""

from __future__ import annotations

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from itertools import combinations

import networkx as nx


ROOT = Path(__file__).resolve().parents[3]
AUDIT_PATH = (
    ROOT
    / "units/barnette/computations/bundles/fixed-carrier-parity-atom-boundary"
    / "audit_fixed_carrier_atoms.py"
)
SPEC = spec_from_file_location("carrier_audit", AUDIT_PATH)
assert SPEC is not None and SPEC.loader is not None
AUDIT = module_from_spec(SPEC)
SPEC.loader.exec_module(AUDIT)


ATOMS = {
    "Z_01|23": (frozenset(), (frozenset((0, 1)), frozenset((2, 3)))),
    "O02_03|12": (frozenset(), (frozenset((0, 3)), frozenset((1, 2)))),
    "U0_A0_23": (frozenset((0, 1)), (frozenset((2, 3)),)),
    "U1_A1_03": (frozenset((1, 2)), (frozenset((0, 3)),)),
    "U2_A2_01": (frozenset((2, 3)), (frozenset((0, 1)),)),
    "U3_A3_12": (frozenset((0, 3)), (frozenset((1, 2)),)),
}


def factor_bond_atom(
    pole: nx.Graph,
    ports: tuple[int, ...],
    first: frozenset[tuple[int, int]],
    second: frozenset[tuple[int, int]],
) -> tuple[tuple[frozenset[int], ...], int]:
    difference = first ^ second
    graph = nx.edge_subgraph(pole, difference).copy()
    paths: list[frozenset[int]] = []
    cycles = 0
    for vertices in nx.connected_components(graph):
        piece = graph.subgraph(vertices)
        ends = tuple(vertex for vertex, degree in piece.degree() if degree == 1)
        if ends:
            assert len(ends) == 2
            paths.append(
                frozenset(index for index, port in enumerate(ports) if port in ends)
            )
        else:
            cycles += 1
    return tuple(sorted(paths, key=lambda item: tuple(sorted(item)))), cycles


def cube_incidence() -> tuple[int, int]:
    cube = nx.Graph()
    cube.add_nodes_from(range(8))
    for vertex in range(8):
        for bit in (1, 2, 4):
            neighbour = vertex ^ bit
            if vertex < neighbour:
                cube.add_edge(vertex, neighbour)
    ports = (0, 1, 3, 2)
    pole = cube.copy()
    pole.remove_edges_from(((0, 1), (2, 3)))
    rows_by_label: dict[str, list[frozenset[tuple[int, int]]]] = {
        label: [] for label in ATOMS
    }
    for label, (state, factor_pairs) in ATOMS.items():
        removed = {ports[index] for index in state}
        for row in AUDIT.enumerate_perfect_matchings(
            pole.subgraph(set(pole) - removed).copy()
        ):
            complement = pole.copy()
            complement.remove_edges_from(row)
            pairs: list[frozenset[int]] = []
            closed = False
            for vertices in nx.connected_components(complement):
                piece = complement.subgraph(vertices)
                endpoints = frozenset(
                    index
                    for index, port in enumerate(ports)
                    if port in vertices and piece.degree(port) == 1
                )
                if endpoints:
                    pairs.append(endpoints)
                elif all(degree == 2 for _, degree in piece.degree()):
                    closed = True
            if not closed and tuple(sorted(pairs, key=lambda item: tuple(sorted(item)))) == tuple(
                sorted(factor_pairs, key=lambda item: tuple(sorted(item)))
            ):
                rows_by_label[label].append(row)

    def incidence(first_label: str, second_label: str) -> int:
        expected = ATOMS[first_label][0] ^ ATOMS[second_label][0]
        return sum(
            factor_bond_atom(pole, ports, first, second)
            == ((frozenset(expected),), 0)
            for first, second in combinations(
                rows_by_label[first_label] + rows_by_label[second_label], 2
            )
            if (first in rows_by_label[first_label])
            != (second in rows_by_label[first_label])
        )

    return incidence("Z_01|23", "U0_A0_23"), incidence(
        "Z_01|23", "U1_A1_03"
    )


def main() -> None:
    graph = nx.from_graph6_bytes(AUDIT.GRAPH6.encode())
    cut, rows = AUDIT.carrier_rows(graph)
    components = [
        AUDIT.complement_components(cut, state, matching)
        for state, matching in rows
    ]

    relevant: set[int] = set()
    compatible: dict[str, tuple[int, ...]] = {}
    for label, (state, pairs) in ATOMS.items():
        indices = tuple(
            index
            for index, ((row_state, _matching), atom) in enumerate(
                zip(rows, components)
            )
            if row_state == state
            and AUDIT.factor_join_passes(atom, state, pairs)
        )
        compatible[label] = indices
        relevant.update(indices)
        sectors = tuple(
            int(AUDIT.edge(*AUDIT.SURVIVING_GATE) in rows[index][1])
            for index in indices
        )
        print(f"{label}: rows={indices} sectors={sectors}")

    print("carrier_bonds")
    ordered = tuple(sorted(relevant))
    for left_position, left in enumerate(ordered):
        for right in ordered[left_position + 1 :]:
            left_sector = int(
                AUDIT.edge(*AUDIT.SURVIVING_GATE) in rows[left][1]
            )
            right_sector = int(
                AUDIT.edge(*AUDIT.SURVIVING_GATE) in rows[right][1]
            )
            if left_sector == right_sector:
                continue
            print(
                f"K{left}-K{right}: "
                f"{AUDIT.bond_atom(cut, rows[left], rows[right])}"
            )

    # With two boundary defects, a carrier path and a factor path close to
    # one alternating cycle exactly when neither shore has a closed cycle.
    # These are therefore all carrier-side slots in which a factor bond can
    # become a mixed exchange after gluing.
    productive: list[tuple[str, str, int, int, tuple[int, ...]]] = []
    labels = tuple(ATOMS)
    for first_position, first_label in enumerate(labels):
        first_state, _first_pairs = ATOMS[first_label]
        for second_label in labels[first_position + 1 :]:
            second_state, _second_pairs = ATOMS[second_label]
            defects = tuple(sorted(first_state ^ second_state))
            if len(defects) != 2:
                continue
            for first_row in compatible[first_label]:
                for second_row in compatible[second_label]:
                    first_sector = int(
                        AUDIT.edge(*AUDIT.SURVIVING_GATE)
                        in rows[first_row][1]
                    )
                    second_sector = int(
                        AUDIT.edge(*AUDIT.SURVIVING_GATE)
                        in rows[second_row][1]
                    )
                    if first_sector == second_sector:
                        continue
                    paths, closed = AUDIT.bond_atom(
                        cut, rows[first_row], rows[second_row]
                    )
                    if closed == 0 and paths == (frozenset(defects),):
                        productive.append(
                            (
                                first_label,
                                second_label,
                                first_row,
                                second_row,
                                defects,
                            )
                        )

    assert productive == [
        ("Z_01|23", "U0_A0_23", 10, 29, (0, 1)),
        ("Z_01|23", "U1_A1_03", 2, 31, (1, 2)),
        ("Z_01|23", "U1_A1_03", 20, 41, (1, 2)),
    ]
    print("productive_factor_bond_slots")
    for entry in productive:
        print(entry)
    print(
        "crossing_formula="
        "I(Z,U0;01-path)+2*I(Z,U1;12-path)"
    )
    assert cube_incidence() == (1, 1)
    print("cube_incidence=(1,1) cube_crossings=3")

    print("COMPLETE_FACTOR_JOIN_BOUNDARY_PRINTED")


if __name__ == "__main__":
    main()
