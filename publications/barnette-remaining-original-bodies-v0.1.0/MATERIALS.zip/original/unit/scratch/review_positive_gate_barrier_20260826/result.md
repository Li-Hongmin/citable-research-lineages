# Positive gates reduce to a global sublevel-augmentation lemma

## Exact quantifier

Let \(\Gamma_i(F,r,H)\) be the graph whose vertices are the forests in the
fixed fibre \(\mathcal F_i\), with an edge for each same-\(X\) pivot, and
let \(\Gamma_i^{\le a}\) be the subgraph induced by forests of
\(H\)-load at most \(a\).

Under Note 055(16),

\[
L=\min_{K\in\mathcal F_i}\ell_H(K).
\]

Therefore

\[
\{K\in\mathcal F_i:\ell_H(K)<L\}=\varnothing. \tag{1}
\]

If a positive gate gives \(J\to J_1\) with loads \(L\to L+1\), the
requested continuation is exactly

\[
\operatorname{comp}_{\Gamma_i^{\le L+1}}(J_1)
\cap\{K:\ell_H(K)\le L-1\}\ne\varnothing. \tag{2}
\]

Equation (1) shows that (2) cannot coexist with the assumed global
minimum.  Thus the proposed route is not an additional property of an
existing minimizer: proving it is precisely a contradiction proof that no
global overload minimizer with \(G\ne\varnothing\) exists.

The correct remaining lemma is consequently

> **Barrier-one fixed-partition augmentation.** If a forest satisfying the
> Note 055 primary and secondary minimizations has a positive gate, the
> complete fixed fibre contains a same-\(X\) path, of peak at most
> \(L+1\), to a forest of load at most \(L-1\).

Notes 052--055 do not prove this lemma.  Equations (18)--(22) give only the
first edge \(J J_1\) of \(\Gamma_i^{\le L+1}\); they impose no condition on
the remainder of the sublevel component of \(J_1\).

## Minimum local brace model

The positive-gate geometry itself is compatible with every ordinary brace
axiom.  The minimum-order realization is the following planar
12-vertex brace.  Put

\[
\begin{aligned}
X&=\{p_0,p_1,p_2,a,b,c\},\\
Y&=\{r,h_0,h_1,v_0,w_1,w_2\},
\end{aligned}
\]

with edges

\[
\begin{aligned}
\{&rp_0,rp_1,rp_2,
ah_0,av_0,aw_1,
bv_0,bw_1,bh_1,\\
&p_0h_1,p_0w_2,
p_1h_0,p_1w_1,
p_2h_0,p_2w_2,
ch_1,cv_0,cw_2\}.
\end{aligned} \tag{3}
\]

It is simple, cubic, bipartite, planar and 2-extendable.  Delete \(r\),
fix the fibre with \(p_0\) alone, take \(H=\{h_0,h_1\}\), and let

\[
J=\{ah_0,av_0,bv_0,bw_1,p_1h_0,p_2h_0,
p_0h_1,ch_1,cw_2\}. \tag{4}
\]

Its \(Y\setminus\{r\}\)-degree vector, in the order
\((h_0,h_1,v_0,w_1,w_2)\), is

\[
(3,2,2,1,1),
\]

so \(\ell_H(J)=5>2|H|=4\).  Deleting the degree-three hole \(h_0\)
leaves the unique port-free branch

\[
C=\{a,b,v_0,w_1\}.
\]

Its only exit of Note 055(18) is the positive gate

\[
J_1=J-bv_0+bh_1,\qquad 5\longrightarrow6, \tag{5}
\]

with removed endpoint \(v_0\notin H\) and added endpoint \(h_1\in H\).
Thus (17)--(21), including strict Hall expansion, have an exact realization
inside a true brace.

This is not a counterexample to the weak bound or to the fully quantified
gate-elimination statement: the complete fixed fibre has 46 forests and
minimum \(H\)-load two.  In particular, (4) fails the load-global-minimum
hypothesis.  Its role is to prove that no local Hall or cubic argument can
exclude the gate geometry; the proof must use the complete fibre beyond
\(J_1\).

The order is minimal for such local overload-gate data.  Put
\(N=|Y\setminus\{r\}|\) and \(h=|H|\).  A positive gate requires
\(h\ge2\).  Since the total \(Y\)-degree is \(2N-1\) and overload gives
\(\ell_H(J)\ge2h+1\), the nonholes have total degree at most
\(2N-2h-2\).  Every vertex of a legal two-component fixed fibre has
positive degree, and the removed nonhole endpoint of a valid gate has
degree at least two.  The \(N-h\) nonholes therefore have total degree at
least \(N-h+1\).  Hence

\[
N-h+1\le2N-2h-2,
\]

so \(N\ge h+3\ge5\), or \(|V(F)|=2(N+1)\ge12\).  Equations (3)--(5)
attain that boundary.

## Exact conclusion

The \(G\ne\varnothing\) branch is **not eliminated** by the supplied
results.  It is strictly reduced to the barrier-one fixed-partition
augmentation lemma (2).  Standard brace input supplies strict Hall
expansion but not the required global sublevel connectivity of the
same-\(X\) exchange graph.

The thinnest missing interface is therefore not another local neighbour
inequality.  It is a cap-conditioned augmenting-path theorem for the
complete fixed fibre after crossing the first \(+1\) gate.

Evidence level: rigorous logical equivalence/reduction, plus an exact
minimum-order true-brace realization of all local gate data.  There is no
actual weak-bound counterexample and no proof of barrier-one augmentation.
The \(G=\varnothing\) four-cut branch is untouched.

The verifier is `verify_positive_gate_local_brace_model.py` in this
directory, with terminal marker
`POSITIVE_GATE_LOCAL_BRACE_MODEL_VERIFIED`.
