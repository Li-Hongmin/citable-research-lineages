#!/usr/bin/env python3
"""Verify a minimum-order local positive-gate model inside a real brace.

The model realizes the overload degree identities and branch exits of
Note 055(17)--(21).  It is deliberately not a weak-bound counterexample:
the complete fixed fibre contains lower-load forests.  Its purpose is to
isolate the missing global-minimum/exchange-augmentation interface.
"""

from __future__ import annotations

from itertools import combinations, product

import networkx as nx


X = ("p0", "p1", "p2", "a", "b", "c")
Y = ("r", "h0", "h1", "v0", "w1", "w2")
ROOT = "r"
PORTS = ("p0", "p1", "p2")
HOLES = frozenset(("h0", "h1"))
Edge = tuple[str, str]


def edge(a: str, b: str) -> Edge:
    return tuple(sorted((a, b)))


J = frozenset(
    edge(a, b)
    for a, b in (
        ("a", "h0"),
        ("a", "v0"),
        ("b", "v0"),
        ("b", "w1"),
        ("p1", "h0"),
        ("p2", "h0"),
        ("p0", "h1"),
        ("c", "h1"),
        ("c", "w2"),
    )
)

FULL_EDGES = J | frozenset(
    edge(a, b)
    for a, b in (
        ("r", "p0"),
        ("r", "p1"),
        ("r", "p2"),
        ("a", "w1"),       # unused chord inside the branch shore
        ("b", "h1"),       # positive gate
        ("p0", "w2"),
        ("p1", "w1"),
        ("p2", "w2"),
        ("c", "v0"),
    )
)


def graph_on(vertices, edges) -> nx.Graph:
    graph = nx.Graph()
    graph.add_nodes_from(vertices)
    graph.add_edges_from(edges)
    return graph


def is_two_extendable(graph: nx.Graph) -> bool:
    edges = tuple(graph.edges())
    for index, first in enumerate(edges):
        for second in edges[index + 1 :]:
            if len(set(first + second)) != 4:
                continue
            remainder = graph.copy()
            remainder.remove_nodes_from(first + second)
            matching = nx.max_weight_matching(remainder, maxcardinality=True)
            if 2 * len(matching) != len(remainder):
                return False
    return True


def load(forest: frozenset[Edge]) -> int:
    return sum(sum(hole in e for e in forest) for hole in HOLES)


def port_fibre(forest: frozenset[Edge], pole: nx.Graph) -> int | None:
    selected = graph_on(pole.nodes(), forest)
    if not nx.is_forest(selected) or nx.number_connected_components(selected) != 2:
        return None
    blocks = []
    for component in nx.connected_components(selected):
        block = frozenset(i for i, port in enumerate(PORTS) if port in component)
        if not block:
            return None
        blocks.append(block)
    if sorted(map(len, blocks)) != [1, 2]:
        return None
    return next(iter(next(block for block in blocks if len(block) == 1)))


def enumerate_fibre_zero(pole: nx.Graph) -> tuple[frozenset[Edge], ...]:
    choices = []
    for x in X:
        required = 1 if x in PORTS else 2
        incident = tuple(edge(x, y) for y in pole[x])
        choices.append(tuple(combinations(incident, required)))
    answer = []
    for selection in product(*choices):
        forest = frozenset(e for local in selection for e in local)
        if port_fibre(forest, pole) == 0:
            answer.append(forest)
    return tuple(answer)


def main() -> None:
    graph = graph_on(X + Y, FULL_EDGES)
    assert len(graph) == 12 and graph.number_of_edges() == 18
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.is_bipartite(graph) and nx.node_connectivity(graph) == 3
    assert nx.check_planarity(graph)[0]
    assert is_two_extendable(graph)

    pole = graph.copy()
    pole.remove_node(ROOT)
    assert port_fibre(J, pole) == 0
    assert load(J) == 5 > 2 * len(HOLES)

    selected = graph_on(pole.nodes(), J)
    degree_vector = tuple(selected.degree(y) for y in Y if y != ROOT)
    assert degree_vector == (3, 2, 2, 1, 1)
    assert sum(degree_vector) == 2 * (len(Y) - 1) - 1
    assert sum(2 - degree for degree in degree_vector) == 1

    after_deletion = selected.copy()
    after_deletion.remove_node("h0")
    port_free = tuple(
        frozenset(component)
        for component in nx.connected_components(after_deletion)
        if not set(component) & set(PORTS)
    )
    assert port_free == (frozenset(("a", "b", "v0", "w1")),)

    branch = port_free[0]
    u_set = branch & set(X)
    v_set = branch & set(Y)
    exits = []
    for x in u_set:
        for y in graph[x]:
            e = edge(x, y)
            if y in v_set or y == "h0" or e in J:
                continue
            y_f = nx.shortest_path(selected, x, "h0")[1]
            delta = int(y in HOLES) - int(y_f in HOLES)
            exits.append((x, y, y_f, delta))
    assert exits == [("b", "h1", "v0", 1)]

    j1 = (J - {edge("b", "v0")}) | {edge("b", "h1")}
    assert port_fibre(j1, pole) == 0
    assert load(j1) == 6
    selected1 = graph_on(pole.nodes(), j1)
    assert tuple(selected1.degree(y) for y in Y if y != ROOT) == (3, 3, 1, 1, 1)

    # The complete fibre identifies the one missing hypothesis: J is not
    # its global minimum, although every local gate equation is realized.
    fibre = enumerate_fibre_zero(pole)
    assert len(fibre) == 46
    assert min(map(load, fibre)) == 2

    print("order", len(graph))
    print("planar_brace", is_two_extendable(graph))
    print("fixed_fibre", "pi_0")
    print("J_load", load(J))
    print("gate_load", load(j1))
    print("exits", exits)
    print("complete_fibre_size", len(fibre))
    print("complete_fibre_minimum", min(map(load, fibre)))
    print("POSITIVE_GATE_LOCAL_BRACE_MODEL_VERIFIED")


if __name__ == "__main__":
    main()
