#!/usr/bin/env python3
"""Test a minimum-length gate-cycle selector on every order-24 wide target."""

from __future__ import annotations

from collections import Counter
from itertools import product
import argparse
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
SOURCE_DIR = UNIT / "scratch" / "existence_lifting_order24_20260826_codex"
SOURCE_JSON = SOURCE_DIR / "complete_family_existence_order24_rerun.json"
SOURCE_SCRIPT = SOURCE_DIR / "census_complete_family_existence_order24.py"


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


source = load_module(SOURCE_SCRIPT, "minimal_gate_cycle_order24_source")
lift = source.lift_bundle
edge = source.edge


def perfect_matchings(graph: nx.Graph):
    neighbours = {vertex: tuple(sorted(graph[vertex])) for vertex in graph}

    def visit(unmatched, chosen):
        if not unmatched:
            yield frozenset(chosen)
            return
        vertex = min(unmatched)
        for neighbour in neighbours[vertex]:
            if neighbour in unmatched:
                yield from visit(
                    unmatched - {vertex, neighbour},
                    chosen + (edge(vertex, neighbour),),
                )

    yield from visit(frozenset(graph), ())


def diff_cycle(first, second):
    difference = first ^ second
    if not difference:
        return None
    graph = nx.Graph()
    graph.add_edges_from(difference)
    if nx.number_connected_components(graph) != 1:
        return None
    assert all(degree == 2 for _, degree in graph.degree())
    return frozenset(edge(*item) for item in graph.edges())


def vertices(cycle):
    return frozenset(vertex for item in cycle for vertex in item)


def target_shape(primal, matching, root):
    complement = primal.copy()
    complement.remove_edges_from(matching)
    parts = tuple(nx.connected_components(complement))
    separated = len(parts) == 2 and not any(set(root) <= part for part in parts)
    return len(parts), separated


def search() -> dict[str, object]:
    accepted = json.loads(SOURCE_JSON.read_text())
    totals = Counter()
    minimum_length_histogram = Counter()
    successful_minimum_count_histogram = Counter()
    first_failure = None

    for source_graph6 in accepted["brace_graph6"]:
        primal = nx.from_graph6_bytes(source_graph6.encode())
        planar, embedding = nx.check_planarity(primal)
        assert planar and isinstance(embedding, nx.PlanarEmbedding)
        primal_faces = source.source_bundle.plane_faces(primal, embedding)
        reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
        reduced_faces = lift.verify_reduced_triangulation(reduced)
        families = lift.target_families(reduced, reduced_faces)[0]
        reduced_vertices = tuple(sorted(reduced))
        dual_to_primal = source.primal_edge_by_dual_edge(primal, primal_faces)
        ambient_matchings = tuple(perfect_matchings(primal))
        totals["ambient_perfect_matchings"] += len(ambient_matchings)
        alternating_cache = {}

        family_cache = {}
        for root, encoded_family in families.items():
            colours = tuple(
                lift.decode_colouring(reduced_vertices, encoded)
                for encoded in encoded_family
            )
            matchings = tuple(
                source.matching_from_colour(
                    primal, reduced, dual_to_primal, colour
                )
                for colour in colours
            )
            family_cache[root] = colours, matchings

        for z in sorted(reduced):
            rotation = rotations[z]
            for i, j, first_gate, second_gate in lift.gate_pairs(rotation):
                left_size = j - i + 1
                right_size = len(rotation) - (j - i) + 1
                if (
                    min(left_size, right_size) < 5
                    or left_size % 2 == 0
                    or right_size % 2 == 0
                ):
                    continue
                expanded, _locals, _left_arc, _right_arc = lift.split_vertex(
                    reduced, z, rotation, i, j
                )
                if lift.expanded_triangulation_faces(expanded) is None:
                    continue
                totals["legal_wide_splits"] += 1
                gates = (
                    dual_to_primal[edge(z, first_gate)],
                    dual_to_primal[edge(z, second_gate)],
                )
                for root, (_colours, matchings) in family_cache.items():
                    if z in root:
                        continue
                    primal_root = dual_to_primal[root]
                    totals["wide_interfaces"] += 1
                    for target_index, base in enumerate(matchings):
                        if not set(gates) <= set(base):
                            continue
                        totals["wide_double_gate_targets"] += 1
                        if base not in alternating_cache:
                            cycles = {
                                cycle
                                for other in ambient_matchings
                                if (cycle := diff_cycle(base, other)) is not None
                            }
                            alternating_cache[base] = tuple(
                                sorted(
                                    cycles,
                                    key=lambda one: (len(one), sorted(one)),
                                )
                            )
                        cycles = alternating_cache[base]
                        gate_cycles = tuple(
                            cycle
                            for cycle in cycles
                            if primal_root not in cycle
                            and any(gate in cycle for gate in gates)
                        )
                        assert gate_cycles
                        minimum_length = min(map(len, gate_cycles))
                        minimum_cycles = tuple(
                            cycle
                            for cycle in gate_cycles
                            if len(cycle) == minimum_length
                        )
                        minimum_length_histogram[minimum_length] += 1
                        successful = []
                        success_records = []
                        for cycle in minimum_cycles:
                            one = base ^ cycle
                            if (
                                sum(gate in one for gate in gates) <= 1
                                and target_shape(primal, one, primal_root)
                                == (2, True)
                            ):
                                successful.append(cycle)
                                success_records.append(
                                    {
                                        "cycle": sorted(cycle),
                                        "mode": "one_cycle",
                                    }
                                )
                                continue
                            cycle_vertices = vertices(cycle)
                            partners = []
                            for partner in cycles:
                                if partner == cycle or primal_root in partner:
                                    continue
                                if cycle_vertices & vertices(partner):
                                    continue
                                double = one ^ partner
                                if sum(gate in double for gate in gates) > 1:
                                    continue
                                if target_shape(primal, double, primal_root) == (
                                    2,
                                    True,
                                ):
                                    partners.append(partner)
                            if partners:
                                successful.append(cycle)
                                success_records.append(
                                    {
                                        "cycle": sorted(cycle),
                                        "mode": "two_cycles",
                                        "partner_count": len(partners),
                                        "partner_lengths": sorted(
                                            len(partner) for partner in partners
                                        ),
                                    }
                                )
                        successful_minimum_count_histogram[len(successful)] += 1
                        if successful:
                            totals[
                                "targets_with_successful_minimum_gate_cycle"
                            ] += 1
                            if len(successful) == len(minimum_cycles):
                                totals[
                                    "targets_with_every_minimum_gate_cycle_successful"
                                ] += 1
                            else:
                                totals[
                                    "targets_with_mixed_minimum_gate_cycle_success"
                                ] += 1
                            continue
                        first_failure = {
                            "source_graph6": source_graph6,
                            "split_vertex": z,
                            "rotation": rotation,
                            "closed_arc_cardinalities": (
                                left_size, right_size
                            ),
                            "gate_indices": (i, j),
                            "gate_vertices": (first_gate, second_gate),
                            "primal_gates": gates,
                            "dual_root": root,
                            "primal_root": primal_root,
                            "target_index": target_index,
                            "target_matching": sorted(base),
                            "minimum_gate_cycle_length": minimum_length,
                            "minimum_gate_cycles": [
                                sorted(cycle) for cycle in minimum_cycles
                            ],
                            "all_alternating_cycle_count": len(cycles),
                            "successful_minimum_records": success_records,
                        }
                        break
                    if first_failure is not None:
                        break
                if first_failure is not None:
                    break
            if first_failure is not None:
                break
        if first_failure is not None:
            break

    return {
        "status": (
            "actual_minimum_gate_cycle_selector_counterexample"
            if first_failure is not None
            else "minimum_gate_cycle_selector_holds_at_order24"
        ),
        "scope": {
            "order": 24,
            "braces": len(accepted["brace_graph6"]),
            "interfaces": "all legal wide splits and unchanged nonempty target families",
            "selector": "some minimum-length root-avoiding gate-changing alternating cycle is target or has a disjoint one-cycle neutral repair",
        },
        "counts_before_stop": dict(sorted(totals.items())),
        "minimum_gate_cycle_length_histogram": {
            str(key): value for key, value in sorted(minimum_length_histogram.items())
        },
        "successful_minimum_count_histogram": {
            str(key): value
            for key, value in sorted(successful_minimum_count_histogram.items())
        },
        "first_failure": first_failure,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    payload = search()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if args.output is not None:
        args.output.write_text(rendered)
        print("certificate", args.output)
    print(json.dumps(payload["counts_before_stop"], sort_keys=True))
    print(json.dumps(payload["minimum_gate_cycle_length_histogram"], sort_keys=True))
    print(json.dumps(payload["successful_minimum_count_histogram"], sort_keys=True))
    print(payload["status"].upper())


if __name__ == "__main__":
    main()
