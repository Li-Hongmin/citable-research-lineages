# A shortest gate-changing alternating cycle need not admit a repair

The proposed selector

> choose a minimum-length root-avoiding gate-changing alternating cycle
> (A); then (M\triangle A) is neutral target, or some disjoint alternating
> cycle (B) makes (M\triangle A\triangle B) neutral target

is false in an actual order-24 plane cubic bipartite brace.

The first witness in the increasing frozen corpus has graph6

```text
W???????????w?s?P_BC?I_?L??d??`_?@g??R??Gg??B_?
```

with dual split vertex (z=1), rotation

\[
(2,7,9,12,11,6,3,0),
\]

closed arc sizes ((5,5)), primal gates ((0,14),(9,19)), dual root
((9,10)), primal root ((7,21)), and target index (12).  Exhaustion of
the brace's perfect matchings gives 56 (M)-alternating cycles.  There is a
unique shortest root-avoiding gate-changing cycle, of length eight:

\[
\{0\!-!13,0\!-!14,3\!-!13,3\!-!19,
  5\!-!14,5\!-!22,9\!-!19,9\!-!22\}.
\]

Its single flip is not a neutral target, and no vertex-disjoint
(M)-alternating cycle repairs it to a root-separated two-cycle factor of
gate load at most one.  The complete family nevertheless has neutral targets,
and the base target has minimum neutral distance at most two through a
different, nonminimum gate-cycle choice.  Thus this refutes only the shortest
cycle selector, not D2-WGE or WGE.

The scan stopped at the first failure after 76 wide double-gate target
instances.  Of the preceding 75, every minimum gate cycle was successful.
The exact witness and scope are in `minimal_selector_order24.json`.
