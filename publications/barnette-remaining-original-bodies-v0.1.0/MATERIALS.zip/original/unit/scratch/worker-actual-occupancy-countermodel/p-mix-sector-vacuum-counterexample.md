# A legal sector-vacuum counterexample to connected mixed repair

## 1. Statement refuted

Consider an interface-disjoint legal split (T\rightsquigarrow T^+) and a
mixed parent rooted bond

\[
 \chi^b-\eta^{1-b},
\]

where (chi) has state (11), is fixed-exterior sterile, and (eta) is
non-(11).  The proposed mixed-repair statement was that there is always a
connected old-exterior switch (K\subseteq H) such that a new-cell
extension of (chi\triangle K)

1. is NAE,
2. is labelled root-admissible,
3. retains gate bit (b), and
4. belongs to (R,U), or (V).

The statement is false.  The example below is stronger than a
two-island obstruction: the entire root-admissible new-cell sector of gate
bit (b) is empty.  Consequently no switch (K), connected or otherwise,
can work.

## 2. The fixed legal split

Begin with the bipyramid over the rim

\[
 r_0r_1\cdots r_7r_0
\]

and apices (z,w).  First split (z) across (r_0,r_4), introducing
(A,B,C).  The resulting triangulation (T) has

\[
 V(T)=\{w,r_0,\ldots,r_7,A,B,C\}
\]

and edge set consisting of

\[
\begin{aligned}
 &r_ir_{i+1}\quad(i\bmod 8),\qquad wr_i\quad(0\le i<8),\\
 &Ar_i\quad(0\le i\le4),\\
 &Br_i\quad(i\in\{4,5,6,7,0\}),\\
 &AC,BC,Cr_0,Cr_4.
\end{aligned}
\tag{1}
\]

Now split (w) across

\[
 P=r_2,\qquad Q=r_6.
\]

The two closed link intervals are

\[
 I_D=r_2r_3r_4r_5r_6,qquad
 I_E=r_6r_7r_0r_1r_2.
\tag{2}
\]

The child (T^+) is obtained from (H=T-w) by adding (D,E,F) and

\[
\begin{aligned}
 &Dr_i &&(i=2,3,4,5,6),\\
 &Er_i &&(i=6,7,0,1,2),\\
 &DF,EF,Fr_2,Fr_6.
\end{aligned}
\tag{3}
\]

The parent has (12) vertices, (30) edges and (20) triangular faces;
the child has (14) vertices, (36) edges and (24) triangular faces.
Their degree sequences in the displayed labels are even.  Direct deletion
of every vertex subset of size at most three leaves each graph connected.
Thus both are (4)-connected Eulerian plane triangulations and the split is
legal.

Take

\[
 e^*=AC,qquad g_1^*=Ar_2.
\tag{4}
\]

The root edge, gate edge, and the two split edges (wr_2,wr_6) are
pairwise disjoint as primal edges.  Equivalently, no corresponding pair of
dual edges co-bounds a triangular face of (T).  The root square is the
face dual to the degree-four vertex (C), whereas the split face is dual
to (w).

## 3. The mixed sterile parent bond

In vertex order

\[
 (w,r_0,r_1,r_2,r_3,r_4,r_5,r_6,r_7,A,B,C),
\]

define

\[
 \chi=100100010111,qquad
 \eta=100010010111.
\tag{5}
\]

For (chi), the monochromatic components are

\[
\begin{array}{c|c}
0&\{r_0,r_1,r_7\},\quad\{r_3,r_4,r_5\},\\
1&\{A,B,C,r_2,r_6,w\}.
\end{array}
\tag{6}
\]

For (eta), they are

\[
\begin{array}{c|c}
0&\{r_0,r_1,r_2,r_7\},\quad\{r_4,r_5\},\\
1&\{A,B,C,r_3,r_6,w\}.
\end{array}
\tag{7}
\]

The dual root edge (AC) is monochromatic, and its incident triangles
have third vertices (r_0,r_4).  These vertices lie in the two distinct
zero-components in both (6) and (7).  Hence both colourings are labelled
root-admissible.

Their local parent rows at (w,P,Q) are

\[
 (1,1,1)\quad\text{and}\quad(1,0,1),
\]

so (chi) has state (11) and (eta) is non-(11).  Their difference
shore is

\[
 D(\chi,\eta)=\{r_2,r_3\}.
\tag{8}
\]

The shore induces the edge (r_2r_3), and its complement is connected.
Thus (8) is a bond shore.  Moreover (Ar_2) is monochromatic under
(chi) and bichromatic under (eta).  Therefore

\[
 \chi^1-\eta^0
\tag{9}
\]

is a mixed parent rooted bond.

The state-(11) endpoint is fixed-exterior sterile already at the NAE
level.  Under (chi), the two link strings are

\[
 \chi(I_D)=10001,qquad \chi(I_E)=10001.
\tag{10}
\]

Since the old apex (w) has colour (1), a flipped interval apex has
colour (0); its incident triangles would require the corresponding link
path to have no (00)-edge.  Both paths in (10) contain such edges.
Hence the fixed exterior has no (U)-, (V)-, or (R)-extension.

## 4. Exhaustive exclusion of every switch

Fix (r_0=0) to quotient global reversal.  Direct triangular-face NAE
enumeration gives

\[
 89\text{ parent colour orbits},\qquad
 169\text{ child colour orbits}.
\tag{11}
\]

Applying the exact three-component and labelled-leaf root test at (AC)
leaves (14) root-admissible child targets outside (C_{11}).  Their
complete cell/gate-bit distribution is

\[
\begin{array}{c|rrrrrr}
 &C_{00}&C_{10}&C_{01}&R&U&V\\ \hline
g_1=0&4&0&2&4&1&1\\
g_1=1&0&2&0&0&0&0.
\end{array}
\tag{12}
\]

In particular,

\[
 \boxed{{\cal N}^{,1}=\varnothing.}
\tag{13}
\]

The canonical extension of (eta) is one of the (C_{01}^{,0})
targets, as required by the canonical bijection.  But the sector of the
state-(11) endpoint contains only two canonical (C_{10}^{,1})
targets and no new-cell target.

For any proposed switch (K\subseteq H), a successful extension of
(chi\triangle K) would occur among the enumerated root-admissible child
targets in (R^1\cup U^1\cup V^1).  Conversely, after representatives are
aligned at (r_0), every such target determines

\[
 K=\{v\in H:\gamma(v)\ne\chi(v)\};
\]

global reversal replaces (K) by (H\setminus K).  Equation (13) excludes
both representatives.  Thus no switch exists, regardless of its number of
components.  The minimum number of exterior islands is therefore not two
or any other finite number; it is undefined because the required gate
sector is vacant.

## 5. Scope

This actual counterexample proves

\[
 \boxed{P_{\rm mix}\text{ is false}.}
\tag{14}
\]

It does not refute full new-cell occupancy or the rooted split-bond lemma.
Indeed, (12) has new-cell targets in gate sector (0) and canonical targets
in sector (1), so the unrestricted opposite-gate occupancy condition is
nonempty.  What fails is the stronger demand that a prescribed mixed bond
be repaired in the gate sector of its sterile state-(11) endpoint.

The frozen verifier is

```text
python3 units/barnette/scratch/worker-actual-occupancy-countermodel/audit_crossed_double_split_mixed_connected_repair.py
```

and terminates with

```text
ACTUAL_P_MIX_SECTOR_VACUUM_COUNTEREXAMPLE_VERIFIED
CROSSED_DOUBLE_SPLIT_MIXED_REPAIR_AUDIT_OK
```
