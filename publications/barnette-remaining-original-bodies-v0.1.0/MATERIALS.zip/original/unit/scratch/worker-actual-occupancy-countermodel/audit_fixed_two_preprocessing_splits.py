#!/usr/bin/env python3
"""Audit one fixed two-preprocessing-split chain from Note 116.

The only chain considered is

    r4 across r5,r3; r0 across r7,r1; w across r2,r6.

The root is AC and the gate is Ar2 throughout.  The script enumerates
NAE orbits, labelled-root targets, and rooted bonds at every stage, and
checks the exact P_sector conditions at the final parent/child pair.
"""

from collections import Counter
from itertools import combinations, product


def edge(u, v):
    return tuple(sorted((u, v)))


def triangles(vertices, edges):
    return tuple(
        (u, v, x)
        for i, u in enumerate(vertices)
        for j, v in enumerate(vertices[i + 1:], i + 1)
        if edge(u, v) in edges
        for x in vertices[j + 1:]
        if edge(u, x) in edges and edge(v, x) in edges
    )


def components(vertices, edges, keep):
    adjacency = {v: set() for v in vertices}
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    unseen = set(keep)
    out = []
    while unseen:
        start = unseen.pop()
        comp = {start}
        stack = [start]
        while stack:
            u = stack.pop()
            for v in adjacency[u] & unseen:
                unseen.remove(v)
                comp.add(v)
                stack.append(v)
        out.append(frozenset(comp))
    return tuple(out)


def connected(vertices, edges, keep):
    return bool(keep) and len(components(vertices, edges, keep)) == 1


def vertex_connectivity_at_least_four(vertices, edges):
    for size in range(4):
        for deleted in combinations(vertices, size):
            keep = set(vertices) - set(deleted)
            if len(keep) > 1 and not connected(vertices, edges, keep):
                return False
    return True


def nae_colourings(vertices, tris):
    # A survives all three splits, so this is a valid global-reversal anchor
    # at every stage, including after r0 is deleted.
    anchor = "A"
    free = tuple(v for v in vertices if v != anchor)
    out = []
    for bits in product((0, 1), repeat=len(free)):
        chi = {anchor: 0, **dict(zip(free, bits))}
        if all(len({chi[v] for v in tri}) == 2 for tri in tris):
            out.append(chi)
    return tuple(out)


def incident_thirds(root_edge, tris):
    u, v = root_edge
    thirds = [
        next(x for x in tri if x not in root_edge)
        for tri in tris
        if u in tri and v in tri
    ]
    assert len(thirds) == 2, (root_edge, thirds)
    return tuple(thirds)


def root_admissible(chi, vertices, edges, tris, root_edge):
    u, v = root_edge
    if chi[u] != chi[v]:
        return False
    colour = chi[u]
    comps = {
        bit: components(vertices, edges, {x for x in vertices if chi[x] == bit})
        for bit in (0, 1)
    }
    if len(comps[0]) + len(comps[1]) != 3:
        return False
    x1, x2 = incident_thirds(root_edge, tris)
    if chi[x1] == colour or chi[x2] == colour:
        return False
    return not any(x1 in comp and x2 in comp for comp in comps[1 - colour])


def gate_bit(chi, gate_edge):
    u, v = gate_edge
    return int(chi[u] == chi[v])


def bond_pair(chi, eta, vertices, edges):
    diff = {v for v in vertices if chi[v] != eta[v]}
    return connected(vertices, edges, diff) and connected(
        vertices, edges, set(vertices) - diff
    )


LOCAL_ROWS = {
    "C00": (0, 0, 0, 1, 1),
    "C10": (0, 0, 1, 0, 1),
    "C01": (0, 0, 1, 1, 0),
    "C11": (0, 0, 1, 0, 0),
    "R": (1, 1, 0, 0, 0),
    "U": (1, 0, 1, 0, 0),
    "V": (0, 1, 1, 0, 0),
}


def cell(chi, local_order):
    row = tuple(chi[x] for x in local_order)
    for name, target in LOCAL_ROWS.items():
        if row == target or row == tuple(1 - x for x in target):
            return name
    raise AssertionError((local_order, row))


def split_graph(vertices, edges, centre, left, right, p, q, names):
    left_new, right_new, middle_new = names
    assert centre in vertices
    assert left[0] == p and left[-1] == q
    assert right[0] == q and right[-1] == p
    assert set(left) & set(right) == {p, q}
    neighbours = {
        next(iter(set(e) - {centre}))
        for e in edges
        if centre in e
    }
    assert set(left) | set(right) == neighbours
    for path in (left, right):
        assert all(edge(u, v) in edges for u, v in zip(path, path[1:]))
    new_vertices = tuple(v for v in vertices if v != centre) + names
    new_edges = {e for e in edges if centre not in e}
    new_edges.update(edge(left_new, x) for x in left)
    new_edges.update(edge(right_new, x) for x in right)
    new_edges.update({
        edge(left_new, middle_new),
        edge(right_new, middle_new),
        edge(middle_new, p),
        edge(middle_new, q),
    })
    return new_vertices, new_edges


def graph_checks(name, vertices, edges):
    tris = triangles(vertices, edges)
    assert len(edges) == 3 * len(vertices) - 6, name
    assert len(tris) == 2 * len(vertices) - 4, name
    degrees = {v: sum(v in e for e in edges) for v in vertices}
    assert all(degree % 2 == 0 for degree in degrees.values()), name
    assert min(degrees.values()) == 4, name
    assert vertex_connectivity_at_least_four(vertices, edges), name
    return tris


def cobound_triangle(first, second, tris):
    return any(
        set(first) <= set(tri) and set(second) <= set(tri)
        for tri in tris
    )


def assert_interfaces_disjoint(tris, labelled_edges):
    assert all(
        not cobound_triangle(first, second, tris)
        for first, second in combinations(labelled_edges, 2)
    )


def target_family(vertices, edges, tris, root_edge):
    nae = nae_colourings(vertices, tris)
    targets = tuple(
        chi for chi in nae
        if root_admissible(chi, vertices, edges, tris, root_edge)
    )
    return nae, targets


def bond_family(targets, gate_edge, vertices, edges):
    return tuple(
        (chi, eta)
        for i, chi in enumerate(targets)
        for eta in targets[i + 1:]
        if gate_bit(chi, gate_edge) != gate_bit(eta, gate_edge)
        and bond_pair(chi, eta, vertices, edges)
    )


def row(chi, vertices):
    return "".join(str(chi[v]) for v in vertices)


def state11(chi):
    return chi["w"] == chi["r2"] == chi["r6"]


def profile(chi, patch_orders):
    return (
        gate_bit(chi, GATE),
        state11(chi) if "w" in chi else None,
        tuple(cell(chi, order) for order in patch_orders),
    )


def print_stage(name, vertices, nae, targets, bonds, patch_orders):
    target_index = {id(chi): i for i, chi in enumerate(targets)}
    print(
        f"{name}: order={len(vertices)} NAE_orbits={len(nae)} "
        f"root_targets={len(targets)} rooted_bonds={len(bonds)}"
    )
    for i, chi in enumerate(targets):
        print(f"  target[{i}]={row(chi, vertices)} profile={profile(chi, patch_orders)}")
    for chi, eta in bonds:
        print(f"  bond=({target_index[id(chi)]},{target_index[id(eta)]})")


RIM = tuple(f"r{i}" for i in range(8))
W, A, B, C = "w", "A", "B", "C"
ROOT = edge(A, C)
GATE = edge(A, "r2")

T_VERTICES = (W,) + RIM + (A, B, C)
T_EDGES = {
    *(edge(RIM[i], RIM[(i + 1) % 8]) for i in range(8)),
    *(edge(W, x) for x in RIM),
    *(edge(A, f"r{i}") for i in range(5)),
    *(edge(B, f"r{i}") for i in (4, 5, 6, 7, 0)),
    edge(A, C), edge(B, C), edge(C, "r0"), edge(C, "r4"),
}

R4L, R4R, R4M = "R4L", "R4R", "R4M"
R4_LEFT = ("r5", W, "r3")
R4_RIGHT = ("r3", A, C, B, "r5")
T1_VERTICES, T1_EDGES = split_graph(
    T_VERTICES, T_EDGES, "r4", R4_LEFT, R4_RIGHT, "r5", "r3",
    (R4L, R4R, R4M),
)
R4_ORDER = (R4L, R4R, R4M, "r5", "r3")

R0L, R0R, R0M = "R0L", "R0R", "R0M"
R0_LEFT = ("r7", W, "r1")
R0_RIGHT = ("r1", A, C, B, "r7")
T2_VERTICES, T2_EDGES = split_graph(
    T1_VERTICES, T1_EDGES, "r0", R0_LEFT, R0_RIGHT, "r7", "r1",
    (R0L, R0R, R0M),
)
R0_ORDER = (R0L, R0R, R0M, "r7", "r1")

D, E, F = "D", "E", "F"
W_LEFT = ("r2", "r3", R4L, "r5", "r6")
W_RIGHT = ("r6", "r7", R0L, "r1", "r2")
T3_VERTICES, T3_EDGES = split_graph(
    T2_VERTICES, T2_EDGES, W, W_LEFT, W_RIGHT, "r2", "r6", (D, E, F)
)
W_ORDER = (D, E, F, "r2", "r6")


def original_target(bits):
    assert len(bits) == len(T_VERTICES)
    return dict(zip(T_VERTICES, map(int, bits)))


CHI = original_target("100100010111")
LAM = original_target("100100001111")
MU = original_target("100100100111")
ORIGINAL_SURVIVORS = tuple(v for v in T_VERTICES if v not in {"r4", "r0"})


def same_on_survivors(up_to_reversal_target, old):
    values = tuple(up_to_reversal_target[v] == old[v] for v in ORIGINAL_SURVIVORS)
    return all(values) or not any(values)


def same_on(up_to_reversal_target, old, survivors):
    values = tuple(up_to_reversal_target[v] == old[v] for v in survivors)
    return all(values) or not any(values)


def main():
    t_tris = graph_checks("T", T_VERTICES, T_EDGES)
    t1_tris = graph_checks("T1", T1_VERTICES, T1_EDGES)
    t2_tris = graph_checks("T2", T2_VERTICES, T2_EDGES)
    t3_tris = graph_checks("T3", T3_VERTICES, T3_EDGES)

    first_site = (edge("r4", "r5"), edge("r4", "r3"))
    second_site = (edge("r0", "r7"), edge("r0", "r1"))
    final_site = (edge(W, "r2"), edge(W, "r6"))
    assert_interfaces_disjoint(
        t_tris, (ROOT, GATE) + first_site + second_site + final_site
    )
    assert_interfaces_disjoint(
        t1_tris, (ROOT, GATE) + second_site + final_site
    )
    assert_interfaces_disjoint(t2_tris, (ROOT, GATE) + final_site)
    assert_interfaces_disjoint(t3_tris, (ROOT, GATE))
    for name, vertices, edges, tris in (
        ("T", T_VERTICES, T_EDGES, t_tris),
        ("T1", T1_VERTICES, T1_EDGES, t1_tris),
        ("T2", T2_VERTICES, T2_EDGES, t2_tris),
        ("T3", T3_VERTICES, T3_EDGES, t3_tris),
    ):
        print(
            f"{name}_structure=(V={len(vertices)},E={len(edges)},"
            f"F3={len(tris)},Eulerian=True,kappa=4)"
        )
    print("all_labelled_interfaces_legal=True")

    t_nae, t_targets = target_family(T_VERTICES, T_EDGES, t_tris, ROOT)
    t1_nae, t1_targets = target_family(T1_VERTICES, T1_EDGES, t1_tris, ROOT)
    t2_nae, t2_targets = target_family(T2_VERTICES, T2_EDGES, t2_tris, ROOT)
    t3_nae, t3_all_targets = target_family(T3_VERTICES, T3_EDGES, t3_tris, ROOT)
    t3_targets = tuple(chi for chi in t3_all_targets if cell(chi, W_ORDER) != "C11")

    t_bonds = bond_family(t_targets, GATE, T_VERTICES, T_EDGES)
    t1_bonds = bond_family(t1_targets, GATE, T1_VERTICES, T1_EDGES)
    t2_bonds = bond_family(t2_targets, GATE, T2_VERTICES, T2_EDGES)
    t3_bonds = bond_family(t3_targets, GATE, T3_VERTICES, T3_EDGES)

    assert (len(t_nae), len(t_targets), len(t_bonds)) == (89, 9, 6)
    assert (len(t1_nae), len(t1_targets), len(t1_bonds)) == (164, 11, 11)
    assert (len(t2_nae), len(t2_targets), len(t2_bonds)) == (320, 13, 16)
    assert (len(t3_nae), len(t3_targets), len(t3_bonds)) == (625, 22, 18)
    assert t3_all_targets == t3_targets
    assert Counter(
        (
            state11(x) if gate_bit(x, GATE) == 1 else state11(y),
            state11(y) if gate_bit(y, GATE) == 0 else state11(x),
        )
        for x, y in t2_bonds
    ) == Counter({
        (True, False): 4,
        (True, True): 2,
        (False, False): 4,
        (False, True): 6,
    })
    assert Counter(
        (gate_bit(x, GATE), cell(x, W_ORDER)) for x in t3_targets
    ) == Counter({
        (0, "C00"): 4,
        (0, "C01"): 2,
        (0, "R"): 4,
        (0, "U"): 5,
        (0, "V"): 5,
        (1, "C10"): 2,
    })
    assert Counter(
        cell(x if gate_bit(x, GATE) == 0 else y, W_ORDER)
        for x, y in t3_bonds
    ) == Counter({"C00": 4, "R": 4, "U": 5, "V": 5})

    print_stage("T", T_VERTICES, t_nae, t_targets, t_bonds, ())
    print_stage("T1", T1_VERTICES, t1_nae, t1_targets, t1_bonds, (R4_ORDER,))
    print_stage(
        "T2", T2_VERTICES, t2_nae, t2_targets, t2_bonds, (R4_ORDER, R0_ORDER)
    )
    print_stage(
        "T3", T3_VERTICES, t3_nae, t3_targets, t3_bonds,
        (R4_ORDER, R0_ORDER, W_ORDER),
    )
    print(f"T3_all_root_targets_including_C11={len(t3_all_targets)}")

    ancestry_t1 = {}
    t1_survivors = tuple(v for v in T_VERTICES if v != "r4")
    for name, old in (("chi", CHI), ("lambda", LAM), ("mu", MU)):
        lifts = tuple(x for x in t1_targets if same_on(x, old, t1_survivors))
        ancestry_t1[name] = lifts
        print(
            f"T1_{name}_ancestry",
            [
                (row(x, T1_VERTICES), cell(x, R4_ORDER),
                 gate_bit(x, GATE), state11(x))
                for x in lifts
            ],
        )

    ancestry = {}
    for name, old in (("chi", CHI), ("lambda", LAM), ("mu", MU)):
        lifts = tuple(x for x in t2_targets if same_on_survivors(x, old))
        ancestry[name] = lifts
        print(
            name,
            [
                (row(x, T2_VERTICES), cell(x, R4_ORDER), cell(x, R0_ORDER),
                 gate_bit(x, GATE), state11(x))
                for x in lifts
            ],
        )

    # The valid anchor A gives one representative per global-reversal orbit.
    assert len(t2_targets) == 13
    assert all(len(ancestry_t1[name]) == 1 for name in ancestry_t1)
    assert all(len(ancestry[name]) == 1 for name in ancestry)
    assert cell(ancestry_t1["chi"][0], R4_ORDER) == "U"
    assert cell(ancestry_t1["lambda"][0], R4_ORDER) == "U"
    assert cell(ancestry_t1["mu"][0], R4_ORDER) == "C01"
    assert (cell(ancestry["lambda"][0], R4_ORDER),
            cell(ancestry["lambda"][0], R0_ORDER)) == ("U", "C01")
    assert (cell(ancestry["mu"][0], R4_ORDER),
            cell(ancestry["mu"][0], R0_ORDER)) == ("C01", "U")

    sector_data = {}
    p_sector_hits = []
    for b in (0, 1):
        parent_b = tuple(x for x in t2_targets if gate_bit(x, GATE) == b)
        non11_b = tuple(x for x in parent_b if not state11(x))
        mixed_bonds = tuple(
            (x, y) for x, y in t2_bonds
            if (
                gate_bit(x, GATE) == b and state11(x) and not state11(y)
            ) or (
                gate_bit(y, GATE) == b and state11(y) and not state11(x)
            )
        )
        new_b = tuple(
            x for x in t3_targets
            if gate_bit(x, GATE) == b and cell(x, W_ORDER) in {"R", "U", "V"}
        )
        sector_data[b] = {
            "parent": len(parent_b),
            "non11": len(non11_b),
            "mixed_bonds": len(mixed_bonds),
            "new": len(new_b),
        }
        if not non11_b and mixed_bonds and not new_b:
            p_sector_hits.append(b)
    print(f"sector_data={sector_data}")
    print(f"P_sector_hits={p_sector_hits}")

    assert sector_data[1] == {
        "parent": 3,
        "non11": 2,
        "mixed_bonds": 4,
        "new": 0,
    }
    assert not p_sector_hits

    print("FIXED_TWO_PREPROCESSING_SPLITS_P_SECTOR_EXCLUDED")
    print("FIXED_TWO_PREPROCESSING_SPLITS_AUDIT_OK")


if __name__ == "__main__":
    main()
