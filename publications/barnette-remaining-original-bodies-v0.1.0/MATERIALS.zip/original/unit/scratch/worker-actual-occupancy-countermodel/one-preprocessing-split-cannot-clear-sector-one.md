# One disjoint preprocessing split cannot clear sector one

## Statement

Let \(T\) be the fixed crossed-double-split parent of Note 116, with
vertex order

\[
 (w,r_0,r_1,r_2,r_3,r_4,r_5,r_6,r_7,A,B,C).
\]

The three root-admissible sector-one targets relevant to the proposed
preprocessing construction are

\[
\begin{aligned}
 \chi&=100100010111,\\
 \lambda&=100100001111,\\
 \mu&=100100100111.
\end{aligned}
\tag{1}
\]

Here \(\chi\) is the prescribed state-\(11\) target for the future split
of \(w\) across \(r_2,r_6\), whereas \(\lambda,\mu\) are the two
sector-one non-\(11\) targets.  Consider one preprocessing vertex split
at a centre \(v\) across distinct neighbours \(p,q\).  Assume that this
split is interface-disjoint from the labelled root \(AC\), the gate
\(Ar_2\), and the future site edges \(wr_2,wr_6\).

Then at least one of \(\lambda,\mu\) is retained by canonical transport,
regardless of how \(\chi\) lifts.  Consequently this construction cannot
produce

\[
 {\cal L}_{\mathrm{non11}}^1=\varnothing.
\tag{2}
\]

## Canonical-transport necessity

For a vertex split at \(v\) across \(p,q\), an old colouring has local
state \(11\) exactly when

\[
 f(v)=f(p)=f(q).
\tag{3}
\]

The canonical bijection transports every non-\(11\) old target to a
canonical target of the split graph.  Since the preprocessing interface
is disjoint from \(AC\), \(Ar_2\), and the future \(w\)-site, this
transport preserves root admissibility, the gate bit, and the three
colours at \(w,r_2,r_6\).

It follows that eliminating both unwanted canonical lifts by this single
preprocessing split requires

\[
 \lambda(v)=\lambda(p)=\lambda(q),
 \qquad
 \mu(v)=\mu(p)=\mu(q).
\tag{4}
\]

## Pair-colour obstruction

Define the pair-colour

\[
 c(x)=(\lambda(x),\mu(x)).
\tag{5}
\]

Equation (4) is equivalent to

\[
 c(v)=c(p)=c(q).
\tag{6}
\]

The four pair-colour classes obtained directly from (1) are

\[
\begin{array}{c|l}
(1,1)&w,r_2,A,B,C,\\
(0,0)&r_0,r_1,r_3,r_4,r_6,\\
(0,1)&r_5,\\
(1,0)&r_7.
\end{array}
\tag{7}
\]

The last two classes are singletons, so neither can contain the three
distinct vertices \(v,p,q\).

The subgraph induced by the \((0,0)\)-class has exactly

\[
 E\bigl(T[c^{-1}(0,0)]\bigr)=\{r_0r_1,r_3r_4\},
\tag{8}
\]

with \(r_6\) isolated.  Its maximum degree is one, so no vertex in this
class has two same-class neighbours.  It therefore contains no split
triple satisfying (6).

The subgraph induced by the \((1,1)\)-class is the path

\[
 w-r_2-A-C-B.
\tag{9}
\]

Consequently its complete list of centre-with-two-neighbours triples is

\[
 (r_2;w,A),\qquad (A;r_2,C),\qquad (C;A,B).
\tag{10}
\]

Their pairs of split edges are respectively

\[
 \{wr_2,Ar_2\},\qquad
 \{Ar_2,AC\},\qquad
 \{AC,BC\}.
\tag{11}
\]

The first candidate uses a future-site edge and the gate, the second
uses the gate and the root, and the third uses the root.  None is
interface-disjoint from the fixed labelled interfaces.

Equations (8)--(11), together with the singleton classes, exhaust every
way in which (6) could hold.  Hence no legal interface-disjoint
preprocessing split can make \(\lambda,\mu\) both state \(11\).  Notice
that this conclusion makes no assumption about the local state or lift
of \(\chi\).

## Consequence and boundary

At least one of \(\lambda,\mu\) is non-\(11\) at the preprocessing site
and therefore has a canonical lift.  Interface-disjointness preserves
its root condition, gate bit, and local row at the future \(w\)-split,
so it remains a sector-one non-\(11\) target.  Thus one disjoint
preprocessing split cannot upgrade the Note 116 graph to a
\(P_{\rm sector}\) counterexample, even if \(\chi\) is retained by some
nondirect mechanism.

The obstruction is only a one-split canonical-transport theorem.  It
does not exclude two preprocessing splits or a different initial graph.

The minimal symbolic check is

    python3 units/barnette/scratch/worker-actual-occupancy-countermodel/verify_one_preprocessing_split_obstruction.py

and terminates with

    ONE_PREPROCESSING_SPLIT_OBSTRUCTION_VERIFIED
