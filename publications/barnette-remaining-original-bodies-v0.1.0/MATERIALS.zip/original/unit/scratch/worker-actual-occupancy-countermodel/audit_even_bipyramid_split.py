#!/usr/bin/env python3
"""Audit OX_full on one fixed legal split of a small even bipyramid.

This is deliberately not a graph census.  It enumerates the complete NAE
families of one parent Eulerian triangulation and one fixed split child, then
varies only the inherited root and surviving-gate edge labels in the common
old graph H.
"""

import argparse
from itertools import product


def edge(u, v):
    return tuple(sorted((u, v)))


PARSER = argparse.ArgumentParser()
PARSER.add_argument("--rim", type=int, choices=(6, 8, 10), default=6)
ARGS = PARSER.parse_args()
N = ARGS.rim

RIM = tuple(f"r{i}" for i in range(N))
Z, W = "z", "w"
A, B, C = "A", "B", "C"
P, Q = "r0", f"r{2 if N == 6 else 4}"

PARENT_VERTICES = (Z, W) + RIM
PARENT_EDGES = {
    *(edge(RIM[i], RIM[(i + 1) % N]) for i in range(N)),
    *(edge(Z, r) for r in RIM),
    *(edge(W, r) for r in RIM),
}

Q_INDEX = RIM.index(Q)
J_A = RIM[:Q_INDEX + 1]
J_B = RIM[Q_INDEX:] + (RIM[0],)
H_VERTICES = (W,) + RIM
H_EDGES = {
    *(edge(RIM[i], RIM[(i + 1) % N]) for i in range(N)),
    *(edge(W, r) for r in RIM),
}
CHILD_VERTICES = H_VERTICES + (A, B, C)
CHILD_EDGES = {
    *H_EDGES,
    *(edge(A, r) for r in J_A),
    *(edge(B, r) for r in J_B),
    edge(A, C),
    edge(B, C),
    edge(C, P),
    edge(C, Q),
}


def triangles(vertices, edges):
    out = []
    for i, u in enumerate(vertices):
        for j in range(i + 1, len(vertices)):
            v = vertices[j]
            if edge(u, v) not in edges:
                continue
            for k in range(j + 1, len(vertices)):
                x = vertices[k]
                if edge(u, x) in edges and edge(v, x) in edges:
                    out.append((u, v, x))
    return tuple(out)


PARENT_TRIANGLES = triangles(PARENT_VERTICES, PARENT_EDGES)
CHILD_TRIANGLES = triangles(CHILD_VERTICES, CHILD_EDGES)


def components(vertices, edges, keep):
    unseen = set(keep)
    answer = []
    adjacency = {v: set() for v in vertices}
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    while unseen:
        start = unseen.pop()
        comp = {start}
        stack = [start]
        while stack:
            u = stack.pop()
            for v in adjacency[u] & unseen:
                unseen.remove(v)
                comp.add(v)
                stack.append(v)
        answer.append(frozenset(comp))
    return tuple(answer)


def connected(vertices, edges, keep):
    return bool(keep) and len(components(vertices, edges, keep)) == 1


def nae_colourings(vertices, edges, tris):
    # Fix W=0 to quotient by global reversal.
    free = tuple(v for v in vertices if v != W)
    out = []
    for bits in product((0, 1), repeat=len(free)):
        chi = {W: 0, **dict(zip(free, bits))}
        if all(len({chi[v] for v in tri}) == 2 for tri in tris):
            out.append(chi)
    return tuple(out)


PARENT_NAE = nae_colourings(PARENT_VERTICES, PARENT_EDGES, PARENT_TRIANGLES)
CHILD_NAE = nae_colourings(CHILD_VERTICES, CHILD_EDGES, CHILD_TRIANGLES)


def incident_thirds(root_edge, tris):
    u, v = root_edge
    thirds = [next(x for x in tri if x not in root_edge)
              for tri in tris if u in tri and v in tri]
    assert len(thirds) == 2
    return tuple(thirds)


def root_admissible(chi, vertices, edges, tris, root_edge):
    u, v = root_edge
    if chi[u] != chi[v]:
        return False
    colour = chi[u]
    comps = {
        bit: components(vertices, edges, {x for x in vertices if chi[x] == bit})
        for bit in (0, 1)
    }
    if len(comps[0]) + len(comps[1]) != 3:
        return False
    x1, x2 = incident_thirds(root_edge, tris)
    if chi[x1] == colour or chi[x2] == colour:
        return False
    return not any(x1 in comp and x2 in comp for comp in comps[1 - colour])


LOCAL_ROWS = {
    "C00": (0, 0, 0, 1, 1),
    "C10": (0, 0, 1, 0, 1),
    "C01": (0, 0, 1, 1, 0),
    "C11": (0, 0, 1, 0, 0),
    "R": (1, 1, 0, 0, 0),
    "U": (1, 0, 1, 0, 0),
    "V": (0, 1, 1, 0, 0),
}


def child_cell(chi):
    row = tuple(chi[x] for x in (A, B, C, P, Q))
    for name, target in LOCAL_ROWS.items():
        if row == target or row == tuple(1 - x for x in target):
            return name
    raise AssertionError(row)


def parent_state11(chi):
    return chi[Z] == chi[P] == chi[Q]


def gate_bit(chi, gate_edge):
    u, v = gate_edge
    return int(chi[u] == chi[v])


def bond_pair(chi, eta, vertices, edges):
    diff = {v for v in vertices if chi[v] != eta[v]}
    comp = set(vertices) - diff
    return connected(vertices, edges, diff) and connected(vertices, edges, comp)


def vertex_connectivity_at_least_four(vertices, edges):
    from itertools import combinations

    for size in range(4):
        for deleted in combinations(vertices, size):
            keep = set(vertices) - set(deleted)
            if len(keep) > 1 and not connected(vertices, edges, keep):
                return False
    return True


def main():
    assert len(PARENT_TRIANGLES) == 2 * N
    assert len(CHILD_TRIANGLES) == 2 * N + 4
    assert all(sum(v in e for e in PARENT_EDGES) % 2 == 0 for v in PARENT_VERTICES)
    assert all(sum(v in e for e in CHILD_EDGES) % 2 == 0 for v in CHILD_VERTICES)
    assert vertex_connectivity_at_least_four(PARENT_VERTICES, PARENT_EDGES)
    assert vertex_connectivity_at_least_four(CHILD_VERTICES, CHILD_EDGES)

    labelled_edges = tuple(sorted(H_EDGES))
    hits = []
    antecedent_count = 0
    for root_edge in labelled_edges:
        parent_targets = tuple(
            chi for chi in PARENT_NAE
            if root_admissible(chi, PARENT_VERTICES, PARENT_EDGES,
                               PARENT_TRIANGLES, root_edge)
        )
        child_targets = tuple(
            chi for chi in CHILD_NAE
            if root_admissible(chi, CHILD_VERTICES, CHILD_EDGES,
                               CHILD_TRIANGLES, root_edge)
            and child_cell(chi) != "C11"
        )
        for gate_edge in labelled_edges:
            if gate_edge == root_edge:
                continue
            parent_bonds = tuple(
                (x, y) for i, x in enumerate(parent_targets)
                for y in parent_targets[i + 1:]
                if gate_bit(x, gate_edge) != gate_bit(y, gate_edge)
                and bond_pair(x, y, PARENT_VERTICES, PARENT_EDGES)
            )
            if not parent_bonds:
                continue
            if not all(parent_state11(x) or parent_state11(y)
                       for x, y in parent_bonds):
                continue
            antecedent_count += 1
            ox_full = any(
                gate_bit(x, gate_edge) != gate_bit(y, gate_edge)
                and (child_cell(x) in {"R", "U", "V"}
                     or child_cell(y) in {"R", "U", "V"})
                for i, x in enumerate(child_targets)
                for y in child_targets[i + 1:]
            )
            if not ox_full:
                hits.append((root_edge, gate_edge, parent_targets,
                             parent_bonds, child_targets))

    print(f"rim={N} parent_NAE={len(PARENT_NAE)} child_NAE={len(CHILD_NAE)}")
    print(f"antecedent_label_pairs={antecedent_count}")
    print(f"OX_full_failures={len(hits)}")
    for root_edge, gate_edge, parent_targets, parent_bonds, child_targets in hits[:5]:
        print("failure", root_edge, gate_edge,
              "parent_targets", len(parent_targets),
              "parent_bonds", len(parent_bonds),
              "child_cells", sorted(child_cell(x) for x in child_targets),
              "child_bits", [(child_cell(x), gate_bit(x, gate_edge))
                             for x in child_targets])
    if N == 8:
        root_edge = edge(W, "r0")
        gate_edge = edge("r2", "r3")
        parent_targets = tuple(
            x for x in PARENT_NAE
            if root_admissible(x, PARENT_VERTICES, PARENT_EDGES,
                               PARENT_TRIANGLES, root_edge)
        )
        parent_bonds = tuple(
            (x, y) for i, x in enumerate(parent_targets)
            for y in parent_targets[i + 1:]
            if gate_bit(x, gate_edge) != gate_bit(y, gate_edge)
            and bond_pair(x, y, PARENT_VERTICES, PARENT_EDGES)
        )
        assert len(parent_bonds) == 1
        alpha, beta = parent_bonds[0]
        if not parent_state11(alpha):
            alpha, beta = beta, alpha
        assert parent_state11(alpha) and not parent_state11(beta)
        assert [v for v in H_VERTICES if alpha[v] != beta[v]] == ["r3", "r4"]

        child_targets = tuple(
            x for x in CHILD_NAE
            if root_admissible(x, CHILD_VERTICES, CHILD_EDGES,
                               CHILD_TRIANGLES, root_edge)
            and child_cell(x) != "C11"
        )
        assert not any(
            child_cell(x) in {"R", "U", "V"}
            and all(x[v] == alpha[v] for v in H_VERTICES)
            for x in CHILD_NAE
        )
        gamma = next(
            x for x in child_targets
            if child_cell(x) == "V"
            and gate_bit(x, gate_edge) == gate_bit(alpha, gate_edge)
            and {v for v in H_VERTICES if x[v] != alpha[v]} == {"r6"}
        )
        beta_plus = next(
            x for x in child_targets
            if child_cell(x) == "C10"
            and all(x[v] == beta[v] for v in H_VERTICES)
        )
        assert gate_bit(gamma, gate_edge) != gate_bit(beta_plus, gate_edge)
        assert bond_pair(gamma, beta_plus, CHILD_VERTICES, CHILD_EDGES)
        assert {v for v in CHILD_VERTICES if gamma[v] != beta_plus[v]} == {
            "r3", "r4", "r6", B
        }
        print("OCTAGONAL_DIRECT_EXTENSION_BOUNDARY_VERIFIED")
    print("EVEN_BIPYRAMID_SPLIT_AUDIT_OK")


if __name__ == "__main__":
    main()
