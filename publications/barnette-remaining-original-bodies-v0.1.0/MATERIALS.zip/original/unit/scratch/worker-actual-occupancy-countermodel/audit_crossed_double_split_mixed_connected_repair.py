#!/usr/bin/env python3
"""Verify a sector-vacuum counterexample to bare P_mix.

Start with the octagonal bipyramid.  Split z across r0,r4, then use the
result as the parent and split the opposite apex w across r2,r6.  The
second split, root, and surviving gate are fixed.  The certificate also
checks the exact boundary: the selected parent bond graph is not kill-covered,
while the child still has new-cell rooted bonds in the opposite gate sector.
"""

from collections import Counter
from itertools import combinations, product


def edge(u, v):
    return tuple(sorted((u, v)))


RIM = tuple(f"r{i}" for i in range(8))
Z, W = "z", "w"
A, B, C = "A", "B", "C"
D, E, F = "D", "E", "F"


def split_edges(old_edges, split_vertex, left, right, p, q, a, b, c):
    old = {e for e in old_edges if split_vertex not in e}
    return {
        *old,
        *(edge(a, x) for x in left),
        *(edge(b, x) for x in right),
        edge(a, c), edge(b, c), edge(c, p), edge(c, q),
    }


T0_VERTICES = (Z, W) + RIM
T0_EDGES = {
    *(edge(RIM[i], RIM[(i + 1) % 8]) for i in range(8)),
    *(edge(Z, x) for x in RIM),
    *(edge(W, x) for x in RIM),
}

# First split: z across r0,r4.
FIRST_LEFT = ("r0", "r1", "r2", "r3", "r4")
FIRST_RIGHT = ("r4", "r5", "r6", "r7", "r0")
PARENT_VERTICES = (W,) + RIM + (A, B, C)
PARENT_EDGES = split_edges(
    T0_EDGES, Z, FIRST_LEFT, FIRST_RIGHT, "r0", "r4", A, B, C
)

# Second, crossed split: w across r2,r6.
P, Q = "r2", "r6"
SECOND_LEFT = ("r2", "r3", "r4", "r5", "r6")
SECOND_RIGHT = ("r6", "r7", "r0", "r1", "r2")
H_VERTICES = RIM + (A, B, C)
H_EDGES = {e for e in PARENT_EDGES if W not in e}
CHILD_VERTICES = H_VERTICES + (D, E, F)
CHILD_EDGES = split_edges(
    PARENT_EDGES, W, SECOND_LEFT, SECOND_RIGHT, P, Q, D, E, F
)


def triangles(vertices, edges):
    return tuple(
        (u, v, x)
        for i, u in enumerate(vertices)
        for j, v in enumerate(vertices[i + 1:], i + 1)
        if edge(u, v) in edges
        for x in vertices[j + 1:]
        if edge(u, x) in edges and edge(v, x) in edges
    )


PARENT_TRIANGLES = triangles(PARENT_VERTICES, PARENT_EDGES)
CHILD_TRIANGLES = triangles(CHILD_VERTICES, CHILD_EDGES)


def components(vertices, edges, keep):
    adjacency = {v: set() for v in vertices}
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    unseen = set(keep)
    out = []
    while unseen:
        start = unseen.pop()
        comp = {start}
        stack = [start]
        while stack:
            u = stack.pop()
            for v in adjacency[u] & unseen:
                unseen.remove(v)
                comp.add(v)
                stack.append(v)
        out.append(frozenset(comp))
    return tuple(out)


def connected(vertices, edges, keep):
    return bool(keep) and len(components(vertices, edges, keep)) == 1


def vertex_connectivity_at_least_four(vertices, edges):
    for size in range(4):
        for deleted in combinations(vertices, size):
            keep = set(vertices) - set(deleted)
            if len(keep) > 1 and not connected(vertices, edges, keep):
                return False
    return True


def nae_colourings(vertices, tris):
    anchor = "r0"
    free = tuple(v for v in vertices if v != anchor)
    out = []
    for bits in product((0, 1), repeat=len(free)):
        chi = {anchor: 0, **dict(zip(free, bits))}
        if all(len({chi[v] for v in tri}) == 2 for tri in tris):
            out.append(chi)
    return tuple(out)


PARENT_NAE = nae_colourings(PARENT_VERTICES, PARENT_TRIANGLES)
CHILD_NAE = nae_colourings(CHILD_VERTICES, CHILD_TRIANGLES)


def incident_thirds(root_edge, tris):
    u, v = root_edge
    thirds = [next(x for x in tri if x not in root_edge)
              for tri in tris if u in tri and v in tri]
    assert len(thirds) == 2, (root_edge, thirds)
    return tuple(thirds)


def root_admissible(chi, vertices, edges, tris, root_edge):
    u, v = root_edge
    if chi[u] != chi[v]:
        return False
    colour = chi[u]
    comps = {
        bit: components(vertices, edges, {x for x in vertices if chi[x] == bit})
        for bit in (0, 1)
    }
    if len(comps[0]) + len(comps[1]) != 3:
        return False
    x1, x2 = incident_thirds(root_edge, tris)
    if chi[x1] == colour or chi[x2] == colour:
        return False
    return not any(x1 in comp and x2 in comp for comp in comps[1 - colour])


LOCAL_ROWS = {
    "C00": (0, 0, 0, 1, 1),
    "C10": (0, 0, 1, 0, 1),
    "C01": (0, 0, 1, 1, 0),
    "C11": (0, 0, 1, 0, 0),
    "R": (1, 1, 0, 0, 0),
    "U": (1, 0, 1, 0, 0),
    "V": (0, 1, 1, 0, 0),
}


def child_cell(chi):
    row = tuple(chi[x] for x in (D, E, F, P, Q))
    for name, target in LOCAL_ROWS.items():
        if row == target or row == tuple(1 - x for x in target):
            return name
    raise AssertionError(row)


def state11(chi):
    return chi[W] == chi[P] == chi[Q]


def gate_bit(chi, gate_edge):
    u, v = gate_edge
    return int(chi[u] == chi[v])


def bond_pair(chi, eta, vertices, edges):
    diff = {v for v in vertices if chi[v] != eta[v]}
    return connected(vertices, edges, diff) and connected(
        vertices, edges, set(vertices) - diff
    )


def main():
    assert len(PARENT_EDGES) == 3 * len(PARENT_VERTICES) - 6
    assert len(CHILD_EDGES) == 3 * len(CHILD_VERTICES) - 6
    assert len(PARENT_TRIANGLES) == 2 * len(PARENT_VERTICES) - 4
    assert len(CHILD_TRIANGLES) == 2 * len(CHILD_VERTICES) - 4
    assert all(sum(v in e for e in PARENT_EDGES) % 2 == 0
               for v in PARENT_VERTICES)
    assert all(sum(v in e for e in CHILD_EDGES) % 2 == 0
               for v in CHILD_VERTICES)
    assert vertex_connectivity_at_least_four(PARENT_VERTICES, PARENT_EDGES)
    assert vertex_connectivity_at_least_four(CHILD_VERTICES, CHILD_EDGES)

    # Freeze one actual counterexample; no label or graph census follows.
    root_edge = edge(A, C)
    gate_edge = edge(A, "r2")
    chi = next(
        x for x in PARENT_NAE
        if ''.join(str(x[v]) for v in PARENT_VERTICES) == "100100010111"
    )
    eta = next(
        x for x in PARENT_NAE
        if ''.join(str(x[v]) for v in PARENT_VERTICES) == "100010010111"
    )
    assert root_admissible(chi, PARENT_VERTICES, PARENT_EDGES,
                           PARENT_TRIANGLES, root_edge)
    assert root_admissible(eta, PARENT_VERTICES, PARENT_EDGES,
                           PARENT_TRIANGLES, root_edge)
    assert state11(chi) and not state11(eta)
    assert gate_bit(chi, gate_edge) == 1
    assert gate_bit(eta, gate_edge) == 0
    assert bond_pair(chi, eta, PARENT_VERTICES, PARENT_EDGES)
    assert {v for v in PARENT_VERTICES if chi[v] != eta[v]} == {"r2", "r3"}
    assert incident_thirds(root_edge, PARENT_TRIANGLES) == ("r0", "r4")

    parent_targets = tuple(
        x for x in PARENT_NAE
        if root_admissible(x, PARENT_VERTICES, PARENT_EDGES,
                           PARENT_TRIANGLES, root_edge)
    )
    parent_bonds = tuple(
        (x, y) for i, x in enumerate(parent_targets)
        for y in parent_targets[i + 1:]
        if gate_bit(x, gate_edge) != gate_bit(y, gate_edge)
        and bond_pair(x, y, PARENT_VERTICES, PARENT_EDGES)
    )
    assert len(parent_targets) == 9 and len(parent_bonds) == 6
    assert sum(not state11(x) and not state11(y)
               for x, y in parent_bonds) == 4
    assert not all(state11(x) or state11(y) for x, y in parent_bonds)

    # The root edge, gate, and two split edges are pairwise disjoint as
    # primal edges: no pair of their duals co-bounds a triangular face.
    split_edges = (edge(W, P), edge(W, Q))
    for first, second in (
        (root_edge, gate_edge),
        *((root_edge, e) for e in split_edges),
        *((gate_edge, e) for e in split_edges),
    ):
        assert not any(set(first) <= set(tri) and set(second) <= set(tri)
                       for tri in PARENT_TRIANGLES)

    child_targets = tuple(
        x for x in CHILD_NAE
        if root_admissible(x, CHILD_VERTICES, CHILD_EDGES,
                           CHILD_TRIANGLES, root_edge)
        and child_cell(x) != "C11"
    )
    assert len(PARENT_NAE) == 89 and len(CHILD_NAE) == 169
    assert len(child_targets) == 14
    assert Counter((child_cell(x), gate_bit(x, gate_edge))
                   for x in child_targets) == Counter({
        ("C00", 0): 4,
        ("C01", 0): 2,
        ("R", 0): 4,
        ("U", 0): 1,
        ("V", 0): 1,
        ("C10", 1): 2,
    })
    # Sterility is already true at the NAE layer, before root labels.
    assert not any(
        child_cell(x) in {"R", "U", "V"}
        and (all(x[v] == chi[v] for v in H_VERTICES)
             or all(x[v] == 1 - chi[v] for v in H_VERTICES))
        for x in CHILD_NAE
    )
    # Stronger than failure of a connected repair: the entire new-cell
    # sector with chi's surviving-gate bit is empty.
    assert not any(
        child_cell(x) in {"R", "U", "V"}
        and gate_bit(x, gate_edge) == gate_bit(chi, gate_edge)
        for x in child_targets
    )
    eta_plus = next(
        x for x in child_targets
        if child_cell(x) == "C01"
        and all(x[v] == eta[v] for v in H_VERTICES)
    )
    assert gate_bit(eta_plus, gate_edge) == gate_bit(eta, gate_edge)

    child_bonds = tuple(
        (x, y) for i, x in enumerate(child_targets)
        for y in child_targets[i + 1:]
        if gate_bit(x, gate_edge) != gate_bit(y, gate_edge)
        and bond_pair(x, y, CHILD_VERTICES, CHILD_EDGES)
    )
    assert len(child_bonds) == 8
    assert Counter(tuple(sorted((child_cell(x), child_cell(y))))
                   for x, y in child_bonds) == Counter({
        ("C00", "C10"): 4,
        ("C10", "R"): 2,
        ("C10", "U"): 1,
        ("C10", "V"): 1,
    })
    print("ACTUAL_P_MIX_SECTOR_VACUUM_COUNTEREXAMPLE_VERIFIED")
    print("CROSSED_DOUBLE_SPLIT_MIXED_REPAIR_AUDIT_OK")


if __name__ == "__main__":
    main()
