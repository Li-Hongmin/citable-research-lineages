"""Minimal symbolic check for the one-preprocessing-split obstruction."""

VERTICES = ("w", "r0", "r1", "r2", "r3", "r4", "r5", "r6", "r7", "A", "B", "C")


def colouring(bits):
    assert len(bits) == len(VERTICES)
    return dict(zip(VERTICES, map(int, bits)))


chi = colouring("100100010111")
lam = colouring("100100001111")
mu = colouring("100100100111")

assert {x for x in VERTICES if lam[x] != chi[x]} == {"r6", "r7"}
assert {x for x in VERTICES if mu[x] != chi[x]} == {"r5", "r6"}

pair_classes = {
    pair: {x for x in VERTICES if (lam[x], mu[x]) == pair}
    for pair in ((0, 0), (0, 1), (1, 0), (1, 1))
}
assert pair_classes == {
    (0, 0): {"r0", "r1", "r3", "r4", "r6"},
    (0, 1): {"r5"},
    (1, 0): {"r7"},
    (1, 1): {"w", "r2", "A", "B", "C"},
}

edges = set()
for i in range(8):
    edges.add(frozenset((f"r{i}", f"r{(i + 1) % 8}")))
    edges.add(frozenset(("w", f"r{i}")))
for i in range(5):
    edges.add(frozenset(("A", f"r{i}")))
for i in (4, 5, 6, 7, 0):
    edges.add(frozenset(("B", f"r{i}")))
for edge in (("A", "C"), ("B", "C"), ("C", "r0"), ("C", "r4")):
    edges.add(frozenset(edge))

def induced_edges(vertices):
    return {edge for edge in edges if edge <= vertices}


edges_00 = induced_edges(pair_classes[(0, 0)])
assert edges_00 == {
    frozenset(("r0", "r1")),
    frozenset(("r3", "r4")),
}

edges_11 = induced_edges(pair_classes[(1, 1)])
assert edges_11 == {
    frozenset(("w", "r2")),
    frozenset(("r2", "A")),
    frozenset(("A", "C")),
    frozenset(("C", "B")),
}


def same_class_split_triples(vertices):
    triples = set()
    for centre in vertices:
        neighbours = sorted(
            next(iter(edge - {centre}))
            for edge in edges
            if centre in edge and edge <= vertices
        )
        for i, left in enumerate(neighbours):
            for right in neighbours[i + 1:]:
                triples.add((centre, frozenset((left, right))))
    return triples


assert same_class_split_triples(pair_classes[(0, 0)]) == set()
triples_11 = same_class_split_triples(pair_classes[(1, 1)])
assert triples_11 == {
    ("r2", frozenset(("w", "A"))),
    ("A", frozenset(("r2", "C"))),
    ("C", frozenset(("A", "B"))),
}

reserved_edges = {
    frozenset(("A", "C")),   # root
    frozenset(("A", "r2")),  # gate
    frozenset(("w", "r2")),  # future site
    frozenset(("w", "r6")),  # future site
}
for centre, endpoints in triples_11:
    site_edges = {frozenset((centre, endpoint)) for endpoint in endpoints}
    assert site_edges & reserved_edges

print("ONE_PREPROCESSING_SPLIT_OBSTRUCTION_VERIFIED")
