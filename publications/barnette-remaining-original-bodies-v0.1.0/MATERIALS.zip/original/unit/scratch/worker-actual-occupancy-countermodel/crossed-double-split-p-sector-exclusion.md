# The crossed double split has no globally kill-covered root/gate labelling

## 1. Fixed question

Use only the parent/child triangulations of Note 116.  For every
interface-disjoint root/gate labelling, ask whether there are a bit $b$
and a mixed parent rooted bond

\[
 \chi^b-\eta^{1-b}
\]

such that

1. the parent rooted bond graph is nonempty and globally covered by
   $L_{11}$;
2. every parent root-admissible target of gate bit $b$ has state $11$;
3. the child new-cell sector ${\cal N}^b$ is empty.

If these conditions held, the canonical bijection would also make the
entire child sector $b$ empty, and hence the child rooted bond graph would
be empty.  This is the fixed-graph $P_{\rm sector}$ counterexample sought
in the pulse.

No such labelling exists on the Note 116 graph.  The exclusion happens at
the first global condition: every interface-disjoint labelling has either
an empty parent rooted bond graph or an uncovered non-$11$--non-$11$
parent bond.

## 2. Complete label domain

The second split has site dual edges

\[
 wr_2,\qquad wr_6.
\]

A legal root edge must be incident with a degree-four dual vertex
representing a square face, that square must not be one of the site faces
$r_2,r_6$, and the root edge must be primal-disjoint from both expanded
edges.  Equivalently, its dual edge cannot co-bound a triangular face with
either site edge.  The complete root list is

\[
\begin{gathered}
 AC,Ar_1,Ar_3,BC,Br_5,Br_7,Cr_0,Cr_4,\\
 r_0r_1,r_0r_7,r_3r_4,r_4r_5.
\end{gathered}
\tag{1}
\]

Thus there are $12$ eligible roots.  A gate edge is eligible when it lies
in the old exterior and co-bounds no parent triangle with the root or either
site edge.  Applying this test gives exactly

\[
 168
\tag{2}
\]

unordered root/gate label pairs.  Gate orientation is irrelevant because
the gate bit is monochromaticity of the dual edge.

## 3. Exhaustive result

For each of the $168$ pairs, the computation uses the complete $89$
parent NAE colour orbits from the frozen Note 116 graph.  It applies the
exact three-component and labelled-leaf root test, then joins two targets
when their difference and complementary shores are both connected and their
gate bits are opposite.

The result is

\[
\begin{array}{c|r}
\text{parent rooted bond graph empty}&28\\
\text{parent graph nonempty but global }L_{11}\text{ cover fails}&140\\
\text{parent graph nonempty and globally kill-covered}&0.
\end{array}
\tag{3}

The counts in (3) exhaust (2).  In each of the $140$ nonempty cases, at
least one rooted bond has two non-$11$ endpoints.  Therefore no label pair
reaches the sector conditions, and

\[
 \boxed{P_{\rm sector}\text{ has no witness on the fixed Note 116 split}.}
\tag{4}

This is a complete finite exclusion for this one graph, not a theorem for
arbitrary legal splits.  In particular, it shows that the same-sector
vacuum of Note 116 cannot be upgraded to a globally kill-covered
counterexample merely by relabelling its root and gate.

## 4. Reproduction

Run

```text
python3 units/barnette/scratch/worker-actual-occupancy-countermodel/audit_crossed_double_split_sector_global.py
```

The frozen output is

```text
eligible_roots=12
eligible_root_gate_pairs=168
stage_counts={'kill_cover_fails': 140, 'parent_bond_empty': 28}
P_sector_hits=0
CROSSED_SPLIT_P_SECTOR_EXCLUDED
```
