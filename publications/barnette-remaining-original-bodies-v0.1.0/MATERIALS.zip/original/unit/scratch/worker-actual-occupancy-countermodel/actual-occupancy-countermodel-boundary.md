# Boundary of the full new-cell occupancy problem

## 1. Question and outcome

Let 

\[
 {cal N}={R_{00},X_{uy},X_{vx}},\qquad
 {cal X}={\cal C}\cup{cal N},
\]

and let superscripts record the surviving-gate bit.  The full occupancy
void is exactly

\[
 \mathsf O\iff
 \bigl({\cal N}^0=\varnothing\text{ or }{cal X}^1=\varnothing\bigr)
 \land
 \bigl({\cal N}^1=\varnothing\text{ or }{cal X}^0=\varnothing\bigr).
\tag{1}
\]

No actual counterexample to

\[
 \mathfrak B_{g_1}(T)\ne\varnothing,quad
 L_{11}\text{ covers }E(\mathfrak B_{g_1}(T))
 \quad\Longrightarrow\quad \neg\mathsf O
\tag{2}
\]

was obtained.  In particular, complete NAE enumeration gives no failure
on the fixed legal splits of the hexagonal and octagonal bipyramids.  A
separating-triangle Eulerian test obtained by gluing two octahedra also has
no failure, whether the split is at a nonseparator or separator vertex.
These are fixed-object tests, not a graph census and not evidence for all
orders.

There is, however, a strict actual-graph boundary.  Even in a legal
4-connected Eulerian split satisfying the antecedent of (2), the
state-\(11\) endpoint that covers the parent bond need not have any
same-exterior NAE extension in a new cell.  Thus (2) cannot be proved by
directly extending the covering endpoint.  The complete child family must
supply a different exterior colouring, and in the minimum example it does
so by a one-island repair.

## 2. Exact direct-extension criterion

Let \(\alpha\) be a parent NAE colouring with

\[
 \alpha(z)=\alpha(P)=\alpha(Q)=s.
\tag{3}
\]

Write \(I_A,I_B\) for the two closed neighbour intervals from \(P\) to
\(Q\) at \(z\).  Retain the colouring of the old graph
\(H=T-z\).  Then:

* the \(R_{00}\) row is NAE if and only if neither interval contains an
  edge whose two endpoints both have colour \(1-s\);
* the \(X_{uy}\) row is NAE if and only if \(I_A\) contains no such edge;
* the \(X_{vx}\) row is NAE if and only if \(I_B\) contains no such edge.

Indeed, in the parent row the split vertex has colour \(s\), so NAE says
that no interval edge has two endpoints of colour \(s\).  In a new row,
the interval governed by a flipped split vertex has colour \(1-s\), and
its triangular faces are NAE exactly when no interval edge is
\((1-s,1-s)\).  The unflipped interval retains the parent constraint.  The
four central patch triangles are already NAE by the corresponding local
row.

Consequently

\[
 \boxed{
 \text{no same-exterior new-cell NAE extension of }\alpha
 \iff
 I_A\text{ and }I_B\text{ each contain a }(1-s,1-s)\text{ edge}.}
\tag{4}
\]

This criterion concerns NAE existence before root-admissibility.  Thus a
colouring satisfying the right-hand side of (4) defeats every direct
extension argument a fortiori.

## 3. A legal actual split defeating direct extension

Let \(T\) be the suspension of the rim

\[
 r_0r_1\cdots r_7r_0
\]

with apices \(z,w\).  Split \(z\) across \(P=r_0,Q=r_4\), with

\[
 I_A=r_0r_1r_2r_3r_4,qquad
 I_B=r_4r_5r_6r_7r_0.
\]

Both \(T\) and its split child are 4-connected Eulerian plane
triangulations.  Take the root dual edge and surviving-gate dual edge to be

\[
 e^*=wr_0,qquad g_1^*=r_2r_3.
\tag{5}
\]

Consider the two parent colourings

\[
\begin{array}{c|cccccccccc}
 &z&w&r_0&r_1&r_2&r_3&r_4&r_5&r_6&r_7\\ \hline
\alpha&0&0&0&1&1&1&0&1&1&1\\
\beta &0&0&0&1&1&0&1&1&1&1.
\end{array}
\tag{6}
\]

For \(\alpha\), the colour-zero graph is connected and the colour-one
graph has the two components \(r_1r_2r_3\) and \(r_5r_6r_7\).  The two
triangles incident with \(wr_0\) have third vertices \(r_7,r_1\), which
lie in those distinct components.  Hence \(\alpha\) is root-admissible.
The same check for \(\beta\) gives colour-one components
\(r_1r_2\) and \(r_4r_5r_6r_7\), so \(\beta\) is root-admissible.

Their difference shore is

\[
 D(\alpha,\beta)=\{r_3,r_4\}.
\tag{7}
\]

Both this shore and its complement are connected.  Moreover \(r_2r_3\)
is monochromatic for \(\alpha\) and bichromatic for \(\beta\).  Thus they
form a parent rooted bond with opposite gate bits.  Complete enumeration of
the root-admissible parent family verifies that this is the unique edge of
\(\mathfrak B_{g_1}(T)\).  Since \(\alpha\) has state \(11\), the parent
bond graph is nonempty and is covered by \(L_{11}\).

Both intervals in (4) contain a \((1,1)\) edge for \(\alpha\).  Therefore
\(\alpha|_H\) has no NAE extension in \(R_{00},X_{uy}\), or \(X_{vx}\).
This is an actual legal-split counterexample to the direct-extension
sublemma.

It is not a counterexample to (2).  Flip only \(r_6\) in the old exterior
of \(\alpha\) and use the \(X_{vx}\) local row.  Explicitly, the resulting
child colouring \(\gamma\) has

\[
 (w,r_0,r_1,r_2,r_3,r_4,r_5,r_6,r_7)
 =(0,0,1,1,1,0,1,0,1)
\tag{8}
\]

and local row

\[
 (A,B,C,P,Q)=(0,1,1,0,0).
\tag{9}
\]

It is root-admissible and has the same gate bit as \(\alpha\).  The
canonical \(C_{10}\) extension of \(\beta\) is root-admissible with the
opposite gate bit.  Hence these two targets already give
\(\neg\mathsf O\).  In fact their child difference shore is

\[
 \{r_3,r_4,r_6,B\},
\]

and both shores are connected, so this particular repair gives a rooted
bond as well.

## 4. Exact remaining layer

The fixed example separates two statements:

\[
\begin{aligned}
&\text{a covering }L_{11}\text{ endpoint directly extends to }{cal N},
&&\text{false even for an actual legal split};\\
&\text{the complete child NAE family contains an opposite-gate pair}\
&\hspace{25mm}\text{touching }{cal N},
&&\text{unresolved in general}.
\end{aligned}
\tag{10}
\]

The first failed incidence condition in every attempted stranded model is
therefore precise: after the covering endpoint is locally blocked, the
complete NAE family admits a different old-exterior colouring obtained by
an island repair, and labelled root-admissibility survives.  To refute
(2), one must make every such repair root-rigid in the relevant gate
sector, while simultaneously retaining the parent rooted bond and its
\(L_{11}\) cover.  Formal region trees can impose this by declaration, but
the fixed actual triangulations tested here do not.

The computations are reproducible with

```text
python3 units/barnette/scratch/worker-actual-occupancy-countermodel/audit_even_bipyramid_split.py --rim 6
python3 units/barnette/scratch/worker-actual-occupancy-countermodel/audit_even_bipyramid_split.py --rim 8
python3 units/barnette/scratch/worker-actual-occupancy-countermodel/audit_two_octahedra_sum_split.py --site outer
python3 units/barnette/scratch/worker-actual-occupancy-countermodel/audit_two_octahedra_sum_split.py --site separator
```

The first two runs report respectively six antecedent label pairs and zero
occupancy failures.  The two separating-triangle runs report respectively
twenty-four and twenty antecedent label pairs and zero occupancy failures.
These bounded observations do not prove (2).
