#!/usr/bin/env python3
"""Audit OX_full on a fixed separating-triangle Eulerian triangulation.

The parent is the plane connected sum of two octahedra along one face.  It
is an actual Eulerian triangulation but is not 4-connected.  We split one
nonseparator degree-four vertex across its opposite neighbours.
"""

import argparse
from itertools import product


def edge(u, v):
    return tuple(sorted((u, v)))


SHARED = ("a", "b", "c")
LEFT_OPP = ("x", "y", "z")
RIGHT_OPP = ("u", "v", "w")
PARENT_VERTICES = SHARED + LEFT_OPP + RIGHT_OPP


def octahedron_edges(parts):
    return {
        edge(u, v)
        for i, part in enumerate(parts)
        for other in parts[i + 1:]
        for u in part for v in other
    }


LEFT_PARTS = (("a", "x"), ("b", "y"), ("c", "z"))
RIGHT_PARTS = (("a", "u"), ("b", "v"), ("c", "w"))
PARENT_EDGES = octahedron_edges(LEFT_PARTS) | octahedron_edges(RIGHT_PARTS)


def octahedron_faces(parts):
    return {
        tuple(sorted((i, j, k)))
        for i in parts[0] for j in parts[1] for k in parts[2]
    }


SEPARATOR = tuple(sorted(SHARED))
PARENT_FACES = tuple(sorted(
    (octahedron_faces(LEFT_PARTS) | octahedron_faces(RIGHT_PARTS))
    - {SEPARATOR}
))

PARSER = argparse.ArgumentParser()
PARSER.add_argument("--site", choices=("outer", "separator"), default="outer")
ARGS = PARSER.parse_args()

# The outer site has rotation b-c-y-z.  The separator site a has rotation
# b-z-y-c-v-w.  In either case P,Q have even cyclic distance, so the split
# vertices remain even.
if ARGS.site == "outer":
    SPLIT, P, Q = "x", "b", "y"
    J_A = ("b", "c", "y")
    J_B = ("y", "z", "b")
else:
    SPLIT, P, Q = "a", "b", "y"
    J_A = ("b", "z", "y")
    J_B = ("y", "c", "v", "w", "b")
A, B, C = "A", "B", "C"
H_VERTICES = tuple(v for v in PARENT_VERTICES if v != SPLIT)
H_EDGES = {e for e in PARENT_EDGES if SPLIT not in e}
CHILD_VERTICES = H_VERTICES + (A, B, C)
CHILD_EDGES = {
    *H_EDGES,
    *(edge(A, r) for r in J_A),
    *(edge(B, r) for r in J_B),
    edge(A, C), edge(B, C), edge(C, P), edge(C, Q),
}

REMOVED_FACES = {face for face in PARENT_FACES if SPLIT in face}
PATCH_FACES = {
    *(tuple(sorted((A, J_A[i], J_A[i + 1]))) for i in range(len(J_A) - 1)),
    *(tuple(sorted((B, J_B[i], J_B[i + 1]))) for i in range(len(J_B) - 1)),
    tuple(sorted((A, C, P))),
    tuple(sorted((B, C, P))),
    tuple(sorted((A, C, Q))),
    tuple(sorted((B, C, Q))),
}
CHILD_FACES = tuple(sorted((set(PARENT_FACES) - REMOVED_FACES) | PATCH_FACES))


def components(vertices, edges, keep):
    adjacency = {v: set() for v in vertices}
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    unseen = set(keep)
    answer = []
    while unseen:
        start = unseen.pop()
        comp = {start}
        stack = [start]
        while stack:
            u = stack.pop()
            for v in adjacency[u] & unseen:
                unseen.remove(v)
                comp.add(v)
                stack.append(v)
        answer.append(frozenset(comp))
    return tuple(answer)


def connected(vertices, edges, keep):
    return bool(keep) and len(components(vertices, edges, keep)) == 1


def nae_colourings(vertices, faces):
    anchor = vertices[0]
    free = tuple(v for v in vertices if v != anchor)
    out = []
    for bits in product((0, 1), repeat=len(free)):
        chi = {anchor: 0, **dict(zip(free, bits))}
        if all(len({chi[v] for v in face}) == 2 for face in faces):
            out.append(chi)
    return tuple(out)


PARENT_NAE = nae_colourings(PARENT_VERTICES, PARENT_FACES)
CHILD_NAE = nae_colourings(CHILD_VERTICES, CHILD_FACES)


def incident_thirds(root_edge, faces):
    u, v = root_edge
    thirds = [next(x for x in face if x not in root_edge)
              for face in faces if u in face and v in face]
    assert len(thirds) == 2, (root_edge, thirds)
    return tuple(thirds)


def root_admissible(chi, vertices, edges, faces, root_edge):
    u, v = root_edge
    if chi[u] != chi[v]:
        return False
    comps = {
        bit: components(vertices, edges, {x for x in vertices if chi[x] == bit})
        for bit in (0, 1)
    }
    if len(comps[0]) + len(comps[1]) != 3:
        return False
    x1, x2 = incident_thirds(root_edge, faces)
    if chi[x1] == chi[u] or chi[x2] == chi[u]:
        return False
    return not any(x1 in comp and x2 in comp for comp in comps[1 - chi[u]])


LOCAL_ROWS = {
    "C00": (0, 0, 0, 1, 1),
    "C10": (0, 0, 1, 0, 1),
    "C01": (0, 0, 1, 1, 0),
    "C11": (0, 0, 1, 0, 0),
    "R": (1, 1, 0, 0, 0),
    "U": (1, 0, 1, 0, 0),
    "V": (0, 1, 1, 0, 0),
}


def child_cell(chi):
    row = tuple(chi[x] for x in (A, B, C, P, Q))
    for name, target in LOCAL_ROWS.items():
        if row == target or row == tuple(1 - x for x in target):
            return name
    raise AssertionError(row)


def parent_state11(chi):
    return chi[SPLIT] == chi[P] == chi[Q]


def gate_bit(chi, gate_edge):
    u, v = gate_edge
    return int(chi[u] == chi[v])


def bond_pair(chi, eta, vertices, edges):
    diff = {v for v in vertices if chi[v] != eta[v]}
    return connected(vertices, edges, diff) and connected(
        vertices, edges, set(vertices) - diff
    )


def edge_face_check(edges, faces):
    return all(sum(u in face and v in face for face in faces) == 2
               for u, v in edges)


def main():
    assert len(PARENT_EDGES) == 3 * len(PARENT_VERTICES) - 6
    assert len(PARENT_FACES) == 2 * len(PARENT_VERTICES) - 4
    assert len(CHILD_EDGES) == 3 * len(CHILD_VERTICES) - 6
    assert len(CHILD_FACES) == 2 * len(CHILD_VERTICES) - 4
    assert edge_face_check(PARENT_EDGES, PARENT_FACES)
    assert edge_face_check(CHILD_EDGES, CHILD_FACES)
    assert all(sum(v in e for e in PARENT_EDGES) % 2 == 0
               for v in PARENT_VERTICES)
    assert all(sum(v in e for e in CHILD_EDGES) % 2 == 0
               for v in CHILD_VERTICES)

    labelled_edges = tuple(sorted(H_EDGES))
    antecedents = []
    failures = []
    for root_edge in labelled_edges:
        parent_targets = tuple(
            x for x in PARENT_NAE
            if root_admissible(x, PARENT_VERTICES, PARENT_EDGES,
                               PARENT_FACES, root_edge)
        )
        child_targets = tuple(
            x for x in CHILD_NAE
            if root_admissible(x, CHILD_VERTICES, CHILD_EDGES,
                               CHILD_FACES, root_edge)
            and child_cell(x) != "C11"
        )
        for gate_edge in labelled_edges:
            if gate_edge == root_edge:
                continue
            parent_bonds = tuple(
                (x, y) for i, x in enumerate(parent_targets)
                for y in parent_targets[i + 1:]
                if gate_bit(x, gate_edge) != gate_bit(y, gate_edge)
                and bond_pair(x, y, PARENT_VERTICES, PARENT_EDGES)
            )
            if not parent_bonds or not all(
                parent_state11(x) or parent_state11(y) for x, y in parent_bonds
            ):
                continue
            antecedents.append((root_edge, gate_edge))
            ox_full = any(
                gate_bit(x, gate_edge) != gate_bit(y, gate_edge)
                and ({child_cell(x), child_cell(y)} & {"R", "U", "V"})
                for i, x in enumerate(child_targets)
                for y in child_targets[i + 1:]
            )
            if not ox_full:
                failures.append((root_edge, gate_edge, parent_targets,
                                 parent_bonds, child_targets))

    print(f"site={ARGS.site} parent_NAE={len(PARENT_NAE)} child_NAE={len(CHILD_NAE)}")
    print(f"antecedent_label_pairs={len(antecedents)}")
    print(f"OX_full_failures={len(failures)}")
    for root, gate, parent_targets, bonds, child_targets in failures:
        print("failure", root, gate,
              "parent_targets", len(parent_targets),
              "parent_bonds", len(bonds),
              "child", [(child_cell(x), gate_bit(x, gate)) for x in child_targets])
    print("TWO_OCTAHEDRA_SUM_SPLIT_AUDIT_OK")


if __name__ == "__main__":
    main()
