#!/usr/bin/env python3
"""Test one octahedral root-filter attachment on the octagonal bipyramid.

The octahedron is glued into the fixed old face w-r6-r7, away from the
split site z-r0/z-r4.  This preserves a common complete plane-Eulerian NAE
family but introduces one separating triangle.
"""

import importlib.util
import sys

sys.argv = ["audit_even_bipyramid_split.py", "--rim", "8"]
BASE_PATH = (
    "units/barnette/scratch/worker-actual-occupancy-countermodel/"
    "audit_even_bipyramid_split.py"
)
SPEC = importlib.util.spec_from_file_location("base_bipyramid", BASE_PATH)
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)

edge = BASE.edge
components = BASE.components
connected = BASE.connected
nae_colourings = BASE.nae_colourings
bond_pair = BASE.bond_pair
gate_bit = BASE.gate_bit
child_cell = BASE.child_cell

ATTACH = ("w", "r6", "r7")
NEW = ("ow", "o6", "o7")
OCT_PARTS = tuple(zip(ATTACH, NEW))
OCT_EDGES = {
    edge(u, v)
    for i, part in enumerate(OCT_PARTS)
    for other in OCT_PARTS[i + 1:]
    for u in part for v in other
}
OCT_FACES = {
    tuple(sorted((u, v, x)))
    for u in OCT_PARTS[0] for v in OCT_PARTS[1] for x in OCT_PARTS[2]
}
SHARED_FACE = tuple(sorted(ATTACH))

PARENT_VERTICES = BASE.PARENT_VERTICES + NEW
PARENT_EDGES = BASE.PARENT_EDGES | OCT_EDGES
PARENT_FACES = tuple(sorted(
    ({tuple(sorted(face)) for face in BASE.PARENT_TRIANGLES} - {SHARED_FACE})
    | (OCT_FACES - {SHARED_FACE})
))
CHILD_VERTICES = BASE.CHILD_VERTICES + NEW
CHILD_EDGES = BASE.CHILD_EDGES | OCT_EDGES
CHILD_FACES = tuple(sorted(
    ({tuple(sorted(face)) for face in BASE.CHILD_TRIANGLES} - {SHARED_FACE})
    | (OCT_FACES - {SHARED_FACE})
))
H_EDGES = {e for e in PARENT_EDGES if BASE.Z not in e}


def incident_thirds(root_edge, faces):
    u, v = root_edge
    thirds = [next(x for x in face if x not in root_edge)
              for face in faces if u in face and v in face]
    assert len(thirds) == 2, (root_edge, thirds)
    return tuple(thirds)


def root_admissible(chi, vertices, edges, faces, root_edge):
    u, v = root_edge
    if chi[u] != chi[v]:
        return False
    comps = {
        bit: components(vertices, edges, {x for x in vertices if chi[x] == bit})
        for bit in (0, 1)
    }
    if len(comps[0]) + len(comps[1]) != 3:
        return False
    x1, x2 = incident_thirds(root_edge, faces)
    if chi[x1] == chi[u] or chi[x2] == chi[u]:
        return False
    return not any(x1 in comp and x2 in comp for comp in comps[1 - chi[u]])


def parent_state11(chi):
    return chi[BASE.Z] == chi[BASE.P] == chi[BASE.Q]


def edge_face_check(edges, faces):
    return all(sum(u in face and v in face for face in faces) == 2
               for u, v in edges)


def main():
    assert len(PARENT_EDGES) == 3 * len(PARENT_VERTICES) - 6
    assert len(PARENT_FACES) == 2 * len(PARENT_VERTICES) - 4
    assert len(CHILD_EDGES) == 3 * len(CHILD_VERTICES) - 6
    assert len(CHILD_FACES) == 2 * len(CHILD_VERTICES) - 4
    assert edge_face_check(PARENT_EDGES, PARENT_FACES)
    assert edge_face_check(CHILD_EDGES, CHILD_FACES)
    assert all(sum(v in e for e in PARENT_EDGES) % 2 == 0
               for v in PARENT_VERTICES)
    assert all(sum(v in e for e in CHILD_EDGES) % 2 == 0
               for v in CHILD_VERTICES)

    parent_nae = nae_colourings(PARENT_VERTICES, PARENT_EDGES, PARENT_FACES)
    child_nae = nae_colourings(CHILD_VERTICES, CHILD_EDGES, CHILD_FACES)
    labelled_edges = tuple(sorted(H_EDGES))
    antecedents = []
    failures = []
    for root in labelled_edges:
        parent_targets = tuple(
            x for x in parent_nae
            if root_admissible(x, PARENT_VERTICES, PARENT_EDGES,
                               PARENT_FACES, root)
        )
        child_targets = tuple(
            x for x in child_nae
            if root_admissible(x, CHILD_VERTICES, CHILD_EDGES,
                               CHILD_FACES, root)
            and child_cell(x) != "C11"
        )
        for gate in labelled_edges:
            if gate == root:
                continue
            parent_bonds = tuple(
                (x, y) for i, x in enumerate(parent_targets)
                for y in parent_targets[i + 1:]
                if gate_bit(x, gate) != gate_bit(y, gate)
                and bond_pair(x, y, PARENT_VERTICES, PARENT_EDGES)
            )
            if not parent_bonds or not all(
                parent_state11(x) or parent_state11(y) for x, y in parent_bonds
            ):
                continue
            antecedents.append((root, gate))
            ox_full = any(
                gate_bit(x, gate) != gate_bit(y, gate)
                and ({child_cell(x), child_cell(y)} & {"R", "U", "V"})
                for i, x in enumerate(child_targets)
                for y in child_targets[i + 1:]
            )
            if not ox_full:
                failures.append((root, gate, parent_targets,
                                 parent_bonds, child_targets))

    print(f"parent_NAE={len(parent_nae)} child_NAE={len(child_nae)}")
    print(f"antecedent_label_pairs={len(antecedents)}")
    print(f"OX_full_failures={len(failures)}")
    for root, gate, parent_targets, bonds, child_targets in failures:
        print("failure", root, gate,
              "parent_targets", len(parent_targets),
              "parent_bonds", len(bonds),
              "child", [(child_cell(x), gate_bit(x, gate)) for x in child_targets])
    print("ROOT_FILTER_OCTAHEDRON_ATTACHMENT_AUDIT_OK")


if __name__ == "__main__":
    main()
