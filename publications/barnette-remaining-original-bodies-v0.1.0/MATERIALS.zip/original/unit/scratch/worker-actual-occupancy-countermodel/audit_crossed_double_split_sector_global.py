#!/usr/bin/env python3
"""Exhaust P_sector labels on the fixed crossed-double-split graph.

The graph and complete NAE families are imported from the frozen Note 116
verifier.  This script varies only interface-disjoint root/gate labels on
that one graph.  No graph generation or order scan is performed.
"""

from collections import Counter
import importlib.util


BASE_PATH = (
    "units/barnette/scratch/worker-actual-occupancy-countermodel/"
    "audit_crossed_double_split_mixed_connected_repair.py"
)
SPEC = importlib.util.spec_from_file_location("note116_graph", BASE_PATH)
G = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(G)


def degree(vertex):
    return sum(vertex in e for e in G.PARENT_EDGES)


def cobound_triangle(first, second):
    return any(
        set(first) <= set(tri) and set(second) <= set(tri)
        for tri in G.PARENT_TRIANGLES
    )


SITE_EDGES = (G.edge(G.W, G.P), G.edge(G.W, G.Q))


def eligible_root(edge):
    # At least one endpoint represents a square face disjoint from the site.
    square_vertices = {v for v in edge if degree(v) == 4 and v not in {G.P, G.Q}}
    if not square_vertices:
        return False
    return not any(cobound_triangle(edge, site) for site in SITE_EDGES)


def eligible_gate(root, gate):
    if gate == root or cobound_triangle(root, gate):
        return False
    return not any(cobound_triangle(gate, site) for site in SITE_EDGES)


def targets(root):
    parent = tuple(
        x for x in G.PARENT_NAE
        if G.root_admissible(x, G.PARENT_VERTICES, G.PARENT_EDGES,
                             G.PARENT_TRIANGLES, root)
    )
    child = tuple(
        x for x in G.CHILD_NAE
        if G.root_admissible(x, G.CHILD_VERTICES, G.CHILD_EDGES,
                             G.CHILD_TRIANGLES, root)
        and G.child_cell(x) != "C11"
    )
    return parent, child


def bond_edges(family, gate, vertices, edges):
    return tuple(
        (x, y)
        for i, x in enumerate(family)
        for y in family[i + 1:]
        if G.gate_bit(x, gate) != G.gate_bit(y, gate)
        and G.bond_pair(x, y, vertices, edges)
    )


def row(chi, vertices):
    return ''.join(str(chi[v]) for v in vertices)


def main():
    roots = tuple(e for e in sorted(G.H_EDGES) if eligible_root(e))
    label_pairs = tuple(
        (root, gate)
        for root in roots
        for gate in sorted(G.H_EDGES)
        if eligible_gate(root, gate)
    )
    stage = Counter()
    hits = []
    for root, gate in label_pairs:
        parent, child = targets(root)
        parent_bonds = bond_edges(
            parent, gate, G.PARENT_VERTICES, G.PARENT_EDGES
        )
        if not parent_bonds:
            stage["parent_bond_empty"] += 1
            continue
        if not all(G.state11(x) or G.state11(y) for x, y in parent_bonds):
            stage["kill_cover_fails"] += 1
            continue
        stage["kill_covered_nonempty"] += 1

        found_sector = False
        for b in (0, 1):
            parent_b = tuple(x for x in parent if G.gate_bit(x, gate) == b)
            if not parent_b or not all(G.state11(x) for x in parent_b):
                continue
            mixed = tuple(
                (x, y) for x, y in parent_bonds
                if ((G.gate_bit(x, gate) == b and G.state11(x)
                     and not G.state11(y))
                    or (G.gate_bit(y, gate) == b and G.state11(y)
                        and not G.state11(x)))
            )
            if not mixed:
                continue
            found_sector = True
            new_b = tuple(
                x for x in child
                if G.gate_bit(x, gate) == b
                and G.child_cell(x) in {"R", "U", "V"}
            )
            if new_b:
                stage["sector_has_new_target"] += 1
                continue

            whole_b = tuple(x for x in child if G.gate_bit(x, gate) == b)
            child_bonds = bond_edges(
                child, gate, G.CHILD_VERTICES, G.CHILD_EDGES
            )
            assert not whole_b
            assert not child_bonds
            hits.append((root, gate, b, parent, parent_bonds, child, mixed))
        if not found_sector:
            stage["no_all_state11_mixed_sector"] += 1

    print(f"eligible_roots={len(roots)}")
    print(f"eligible_root_gate_pairs={len(label_pairs)}")
    print(f"stage_counts={dict(sorted(stage.items()))}")
    print(f"P_sector_hits={len(hits)}")
    for root, gate, b, parent, parent_bonds, child, mixed in hits:
        print("hit", root, gate, "b", b)
        print(" parent_targets", [(row(x, G.PARENT_VERTICES),
                                   G.state11(x), G.gate_bit(x, gate))
                                  for x in parent])
        print(" parent_bonds", [(row(x, G.PARENT_VERTICES),
                                 row(y, G.PARENT_VERTICES))
                                for x, y in parent_bonds])
        print(" child_targets", [(G.child_cell(x), G.gate_bit(x, gate),
                                  row(x, G.CHILD_VERTICES)) for x in child])
        print(" mixed", [(row(x, G.PARENT_VERTICES),
                           row(y, G.PARENT_VERTICES)) for x, y in mixed])

    if hits:
        print("CROSSED_SPLIT_P_SECTOR_COUNTEREXAMPLE_VERIFIED")
    else:
        assert len(roots) == 12
        assert len(label_pairs) == 168
        assert stage == Counter({
            "parent_bond_empty": 28,
            "kill_cover_fails": 140,
        })
        print("CROSSED_SPLIT_P_SECTOR_EXCLUDED")


if __name__ == "__main__":
    main()
