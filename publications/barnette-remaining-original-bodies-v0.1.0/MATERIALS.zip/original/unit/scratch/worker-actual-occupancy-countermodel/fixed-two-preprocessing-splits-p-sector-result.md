# Two prescribed preprocessing splits do not produce a sector counterexample

## The fixed split chain

Let \(T_0=T\) be the crossed-double-split parent of Note 116.  Keep the
labelled root \(AC\), the gate \(Ar_2\), and the eventual split of \(w\)
across \(r_2,r_6\).

First split \(r_4\) across \(r_5,r_3\).  Its two closed link intervals
are

\[
 (r_5,w,r_3),\qquad (r_3,A,C,B,r_5).
\tag{1}
\]

Call the new interval vertices \(\mathtt{R4L},\mathtt{R4R}\) and the
middle vertex \(\mathtt{R4M}\).  Thus \(\mathtt{R4L}\) is joined to the
first interval, \(\mathtt{R4R}\) to the second, and
\(\mathtt{R4M}\) to

\[
 \mathtt{R4L},\mathtt{R4R},r_5,r_3.
\tag{2}
\]

Next split \(r_0\) across \(r_7,r_1\), with intervals

\[
 (r_7,w,r_1),\qquad (r_1,A,C,B,r_7),
\tag{3}
\]

and new vertices
\(\mathtt{R0L},\mathtt{R0R},\mathtt{R0M}\), defined analogously.
Write \(T_1,T_2\) for the graphs after these two operations.

In \(T_2\), the two link intervals for the final split of \(w\) are

\[
\begin{aligned}
 &(r_2,r_3,\mathtt{R4L},r_5,r_6),\\
 &(r_6,r_7,\mathtt{R0L},r_1,r_2).
\end{aligned}
\tag{4}
\]

The final patch vertices are called \(D,E,F\), in the convention of
Note 116, and the resulting child is \(T_3\).

## Legality

Each graph is a simple Eulerian triangulation.  Direct vertex-cut
checking and the presence of a degree-four vertex give exact vertex
connectivity four:

\[
\begin{array}{c|rrrr}
 &|V|&|E|&\text{triangular faces}&\kappa\\ \hline
T_0&12&30&20&4\\
T_1&14&36&24&4\\
T_2&16&42&28&4\\
T_3&18&48&32&4.
\end{array}
\tag{5}
\]

Before the first split, the root, gate, and all three prescribed sites

\[
\begin{gathered}
 AC,\ Ar_2,\\
 r_4r_5,\ r_4r_3,\quad
 r_0r_7,\ r_0r_1,\quad
 wr_2,\ wr_6
\end{gathered}
\tag{6}
\]

are pairwise interface-disjoint: no two corresponding dual edges
co-bound a triangle.  The same test holds for the surviving labelled
interfaces after each split.  Hence all three operations are legal in
the required rooted setting.

## Complete target and bond enumeration

Global reversal is quotiented at every stage by the fixed surviving
anchor \(A=0\).  This is essential after the second preprocessing split,
because \(r_0\) no longer exists.  The complete orbit counts are

\[
\begin{array}{c|rrr}
 &\text{NAE orbits}&\text{root targets}&\text{rooted bonds}\\ \hline
T_0&89&9&6\\
T_1&164&11&11\\
T_2&320&13&16\\
T_3&625&22&18.
\end{array}
\tag{7}
\]

The \(T_3\) target count is taken outside the final \(C_{11}\) cell, as
in Note 116.  In fact none of its \(22\) root-admissible targets lies in
that cell, so the unrestricted root-target count is also \(22\).  The
verifier prints every target bit row and every bond, not merely the
counts in (7).

At the final parent \(T_2\), the complete target distribution is

\[
\begin{array}{c|rr}
 &\text{state }11&\text{non-}11\\ \hline
g_1=0&4&6\\
g_1=1&1&2.
\end{array}
\tag{8}
\]

Its \(16\) rooted bonds split into

\[
\begin{array}{c|r}
\text{endpoint types}&\text{number}\\ \hline
(g_1=1,11)-(g_1=0,\mathrm{non11})&4\\
(g_1=1,11)-(g_1=0,11)&2\\
(g_1=1,\mathrm{non11})-(g_1=0,\mathrm{non11})&4\\
(g_1=1,\mathrm{non11})-(g_1=0,11)&6.
\end{array}
\tag{9}
\]

Thus mixed bonds with a sector-one state-\(11\) endpoint do survive.
The four non-\(11\)--non-\(11\) bonds in (9) also show that the stronger
global kill-cover condition still fails.

For the final child, the cell distribution is

\[
\begin{array}{c|rrrrrr}
 &C_{00}&C_{10}&C_{01}&R&U&V\\ \hline
g_1=0&4&0&2&4&5&5\\
g_1=1&0&2&0&0&0&0.
\end{array}
\tag{10}
\]

The \(18\) final rooted bonds have cell-pair distribution

\[
4(C_{00},C_{10})+
4(R,C_{10})+
5(U,C_{10})+
5(V,C_{10}).
\tag{11}
\]

In particular, the original sector vacuum persists:

\[
 {\cal N}^1=\varnothing.
\tag{12}
\]

## The exact obstruction: alternating \(U\)-lifts

Use the original Note 116 vertex order and targets

\[
\begin{aligned}
\chi&=100100010111,\\
\lambda&=100100001111,\\
\mu&=100100100111.
\end{aligned}
\tag{13}
\]

Matching on all surviving old vertices, up to global reversal, gives a
unique descendant orbit for each row.  Their preprocessing-cell
ancestry is

\[
\begin{array}{c|cc|cc}
 &r_4\text{-cell in }T_1&r_4\text{-cell in }T_2
 &r_0\text{-cell in }T_2&\text{future state}\\ \hline
\chi&U&U&U&11\\
\lambda&U&U&C_{01}&\mathrm{non11}\\
\mu&C_{01}&C_{01}&U&\mathrm{non11}.
\end{array}
\tag{14}
\]

At the first preprocessing site, \(\lambda\) is locally state \(11\);
the split nevertheless creates its unique nondirect \(U\)-lift.
Meanwhile \(\mu\) passes canonically through \(C_{01}\).  At the second
site the roles reverse: \(\lambda\) passes canonically through
\(C_{01}\), while the unique nondirect \(U\)-lift restores \(\mu\).

Consequently sector one has exactly the three descendant orbits in
(14), including the same two non-\(11\) targets:

\[
 |{\cal L}_{\mathrm{non11}}^1|=2.
\tag{15}
\]

The fixed construction therefore satisfies the mixed-bond condition
and (12), but fails precisely at the proposed sector-clearing premise
(15).  It is not an actual \(P_{\rm sector}\) counterexample.  The
failure occurs already after each preprocessing step: a \(U\)-cell
nondirect lift replaces the target that the local canonical bijection
would have removed.

This conclusion concerns only the prescribed two-split order.  No other
site, order, graph, or further split is tested.

The frozen verifier is

    python3 units/barnette/scratch/worker-actual-occupancy-countermodel/audit_fixed_two_preprocessing_splits.py

and terminates with

    FIXED_TWO_PREPROCESSING_SPLITS_P_SECTOR_EXCLUDED
    FIXED_TWO_PREPROCESSING_SPLITS_AUDIT_OK
