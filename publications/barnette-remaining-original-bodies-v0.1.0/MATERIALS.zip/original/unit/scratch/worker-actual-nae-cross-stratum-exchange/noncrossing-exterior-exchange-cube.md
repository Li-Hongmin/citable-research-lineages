# Noncrossing exterior exchange cubes for an actual triangulation split

This scratch note isolates the common-realizability constraint shared by all
old-exterior NAE strata of one actual split.  It proves only the NAE exchange
structure.  It does not prove the root-labelled selection statement at the
end.

## 1. The exterior is a triangulated disk

Let \(T\) be a simple 4-connected plane triangulation, let \(z\in V(T)\)
be the vertex to be split, and list the neighbours of \(z\) in their cyclic
order as
\[
 L=v_0v_1\cdots v_{m-1}v_0.
\]
Consecutive neighbours are adjacent because every face incident with \(z\)
is a triangle.  The cyclic list has no repeated vertex.  Moreover, an edge
\(v_i v_j\) between nonconsecutive neighbours would make
\(zv_iv_jz\) a nonfacial triangle.  Such a triangle separates the sphere,
contrary to 4-connectivity.  Thus \(L\) is an induced cycle.

Regard \(T\) as a triangulation of the sphere and remove the open star of
\(z\).  What remains is a closed disk whose boundary is \(L\).  Its
1-skeleton is
\[
 H:=T-z,
\]
and all its faces other than the outer face bounded by \(L\) are triangles.
We use \(H\) below as this two-dimensional cell complex, with its triangular
2-cells included.  In particular,
\[
 H\simeq D^2,\qquad H^1(H;\mathbb F_2)=0.
\tag{1}
\]
The 4-connectivity assumption also ensures that the boundary is the induced
link cycle needed by an actual legal split.  The exchange proof below only
uses that \(H\) is a connected triangulated disk.

We must distinguish two kinds of edges throughout:

* an edge \(e\in E(H)\) is an edge of the original triangulation;
* \(e^\dagger\) denotes the edge labelled by \(e\) in the split weak dual
  defined next.

Let \(\mathcal F(H)\) be the set of triangular faces of the disk, excluding
the outer face.  The **split weak dual** \(W(H)\) has one vertex
\(f^\dagger\) for every \(f\in\mathcal F(H)\).  If an interior
triangulation edge \(e\) is incident with faces \(f,f'\), then \(W(H)\)
has the edge
\[
 e^\dagger=f^\dagger f'^\dagger.
\]
If a boundary triangulation edge \(e\in E(L)\) is incident with the unique
triangular face \(f\), introduce a separate degree-one terminal \(t_e\) and
put
\[
 e^\dagger=f^\dagger t_e.
\]
Thus different boundary edges never get identified at a single outer-face
dual vertex.

## 2. Integrating one-monochromatic-edge patterns

For a binary colouring \(\sigma:V(H)\to\mathbb F_2\), write
\[
 \mu_\sigma
 :=\{uv\in E(H):\sigma(u)=\sigma(v)\}.
\tag{2}
\]
The colouring is NAE on every triangular face if and only if every such face
contains exactly one edge of \(\mu_\sigma\).

The converse is intrinsic and will be used after exchanges.  Suppose that
\(\mu\subseteq E(H)\) contains exactly one edge of every triangular face.
Define a triangulation-edge 1-cochain
\[
 d_\mu(e)=
 \begin{cases}
 0,&e\in\mu,\\
 1,&e\notin\mu.
 \end{cases}
\tag{3}
\]
On the boundary of each triangular 2-cell, \(d_\mu\) takes the value one
on exactly two edges.  Its sum around that face is therefore zero in
\(\mathbb F_2\).  Hence \(d_\mu\) is a cellular 1-cocycle.  By (1), it is
exact: there is a vertex 0-cochain \(\sigma\) such that
\[
 d_\mu(uv)=\sigma(u)+\sigma(v).
\tag{4}
\]
Because \(H\) is connected, \(\sigma\) is unique up to addition of the
constant-one cochain, namely global colour reversal.  Equation (4) says
precisely that the edges in \(\mu\) are the monochromatic edges of
\(\sigma\).  Thus:

> **Integration lemma.** Every edge pattern having exactly one selected
> edge on each triangular face is the monochromatic-edge pattern of a unique
> NAE colouring of \(H\), modulo global reversal.

This is why the component toggles below produce vertex colourings rather
than merely formal face patterns.

## 3. The exact Boolean exchange cube

Let \(\sigma,\tau\) be two NAE colourings of \(H\), considered modulo
global reversal, and put
\[
 \Delta(\sigma,\tau)=\mu_\sigma\mathbin\triangle\mu_\tau
 \subseteq E(H).
\tag{5}
\]
Let \(\Delta^\dagger(\sigma,\tau)\) be the subgraph of \(W(H)\) consisting
of the split weak-dual edges \(e^\dagger\) labelled by
\(e\in\Delta(\sigma,\tau)\).

At a triangular face \(f\), either \(\sigma\) and \(\tau\) select the same
monochromatic edge, in which case \(f^\dagger\) has degree zero in
\(\Delta^\dagger\), or they select different monochromatic edges.  In the
latter case exactly those two edges lie in the symmetric difference, so
\(f^\dagger\) has degree two.  Every terminal has degree zero or one.
Consequently every nontrivial component of \(\Delta^\dagger\) is either

* a cycle containing no terminal, or
* a path joining two distinct boundary terminals.

Let \(\mathscr C(\sigma,\tau)\) be this set of nontrivial components.  For
\(C\in\mathscr C(\sigma,\tau)\), let \(E_H(C)\subseteq E(H)\) be the set
of triangulation-edge labels on the split weak-dual edges of \(C\).  For an
arbitrary subfamily \(\mathscr J\subseteq\mathscr C(\sigma,\tau)\), define
\[
 \mu_{\mathscr J}
 =\mu_\sigma\mathbin\triangle
   \bigcup_{C\in\mathscr J}E_H(C).
\tag{6}
\]
At every face met by a selected component, the two toggled edges consist of
the unique \(\mu_\sigma\)-edge and the unique \(\mu_\tau\)-edge.  The
toggle removes the former and inserts the latter.  At every other face the
selected edge is unchanged.  Therefore \(\mu_{\mathscr J}\) again contains
exactly one edge per triangular face.  The integration lemma supplies a
unique NAE colouring \(\sigma_{\mathscr J}\), modulo reversal, having this
monochromatic-edge pattern.

Distinct subfamilies give distinct patterns, and all components can be
toggled independently.  We have proved:

> **Exterior exchange-cube theorem.** For every pair
> \(\sigma,\tau\in\Omega(H)\), where \(\Omega(H)\) is the complete family
> of NAE colourings of \(H\) modulo reversal, the components of
> \(\Delta^\dagger(\sigma,\tau)\) generate a Boolean cube
> \[
> \{\sigma_{\mathscr J}:\mathscr J\subseteq
>          \mathscr C(\sigma,\tau)\}\subseteq\Omega(H).
> \tag{7}
> \]
> Moreover, these are exactly the intermediate patterns which, on each
> triangular face, choose either the monochromatic edge selected by
> \(\sigma\) or the one selected by \(\tau\).

Taking all pair-generated cubes gives the **exterior exchange cubical
complex** \(\mathcal Q(H)\).  This is a common-realizability constraint on
the complete family of old-exterior strata.  It is not stable under the
arbitrary deletion of individual strata used in a per-stratum projection.

## 4. Boundary traces: an even delta-matroid with noncrossing exchange

For \(\sigma\in\Omega(H)\), define its monochromatic boundary trace
\[
 B_\sigma=\mu_\sigma\cap E(L).
\tag{8}
\]
All traces have the same parity.  Indeed, counting incidences between
triangular faces and their selected monochromatic edges gives
\[
 |\mathcal F(H)|
 =2|\mu_\sigma\cap(E(H)\setminus E(L))|+|B_\sigma|,
\tag{9}
\]
so
\[
 |B_\sigma|\equiv |\mathcal F(H)|\pmod 2.
\tag{10}
\]

Let
\[
 \mathcal B(H)=\{B_\sigma:\sigma\in\Omega(H)\}.
\]
Take \(B_\sigma,B_\tau\in\mathcal B(H)\) and
\(e\in B_\sigma\triangle B_\tau\).  The split weak-dual edge
\(e^\dagger\) is incident with terminal \(t_e\) and belongs to a unique
path component \(C\) of \(\Delta^\dagger(\sigma,\tau)\).  Let \(t_f\) be
its other terminal.  Toggling \(C\) from either endpoint of the cube gives
NAE colourings \(\sigma_C,\tau_C\) with
\[
 B_{\sigma_C}=B_\sigma\triangle\{e,f\},\qquad
 B_{\tau_C}=B_\tau\triangle\{e,f\}.
\tag{11}
\]
Thus \(\mathcal B(H)\) obeys the strong symmetric exchange rule, and (10)
makes it an even delta-matroid support.

There is more information than the abstract delta-matroid axiom records.
The path components of \(\Delta^\dagger\) are disjoint embedded arcs in the
disk.  They pair the elements of \(B_\sigma\triangle B_\tau\) in a
noncrossing pairing in the cyclic boundary order.  All unions of the paired
paths occur simultaneously as the corners of (7).  This noncrossing
Boolean-cube structure is the minimal pairwise exchange information retained
from the common actual incidence.

## 5. A mixed rooted bond produces one distinguished gate path

Return to an actual parent triangulation \(T\) and its split at \(z\).  Let
\(G=T^*\) be the cubic plane graph.  A parent NAE colouring \(\xi\) encodes
the perfect matching
\[
 M_\xi=\{a^\vee:a\in\mu_\xi\}\subseteq E(G),
\tag{12}
\]
where \(a^\vee\) denotes the ordinary plane-dual edge in \(G\) corresponding
to the triangulation edge \(a\in E(T)\).  Thus \(a\), \(a^\dagger\), and
\(a^\vee\) are, respectively, a triangulation edge, its split weak-dual
edge, and its ordinary plane-dual edge.  The fixed labels \(g_1^*\) and
\(e^*\) used below follow the notation of the parent problem and are
themselves triangulation edges of \(T\).

Suppose
\[
 \chi^b-\eta^{1-b}
\tag{13}
\]
is a mixed parent rooted bond, with \(\chi\) in state \(11\) and \(\eta\)
in a non-\(11\) state.  Align global representatives at \(z\), and put
\[
 S=\{v\in V(T):\chi(v)\ne\eta(v)\}.
\]
The rooted-bond condition says that \(\delta_T(S)\) is a bond.  Since an
edge changes monochromatic status exactly when it crosses \(S\),
\[
 \mu_\chi\triangle\mu_\eta=\delta_T(S).
\tag{14}
\]
In a plane graph, the ordinary dual of a bond is a simple cycle.  Therefore
\[
 (\mu_\chi\triangle\mu_\eta)^\vee
 =M_\chi\triangle M_\eta
\tag{15}
\]
is one simple alternating cycle in \(G\), not a union of several cycles.

Because the local states of \(\chi\) and \(\eta\) differ, at least one edge
incident with \(z\) changes monochromatic status.  Hence the cycle (15)
meets the part dual to the deleted \(z\)-fan.  Cut that single cycle at the
fan and retain the triangulation-edge labels lying in \(E(H)\).  In the
split weak dual \(W(H)\), the retained pieces are exactly the components of
\[
 \Delta^\dagger(\chi|_H,\eta|_H).
\]
They are boundary-to-boundary paths.  There can be no closed component: a
closed component would be a cycle component of (15) disjoint from the fan,
whereas (15) is one cycle and does meet the fan.  The exterior paths and the
complementary fan-side path pieces concatenate to the single cycle (15).

Let \(g_1^*\in E(T)\) denote the triangulation edge dual to the surviving
primal gate.  Interface-disjointness puts it in \(E(H)\).  The two endpoints
in (13) have opposite gate bits, so
\[
 g_1^*\in\mu_\chi\triangle\mu_\eta.
\]
Consequently the split weak-dual edge \((g_1^*)^\dagger\) belongs to one
unique exterior path; call it \(P_g\).  In the cube (7), based at
\(\chi|_H\), toggling a component changes the gate bit exactly when that
component is \(P_g\).  Therefore
\[
 \boxed{\text{the sector-\(b\) corners are precisely the corners that do
 not toggle \(P_g\).}}
\tag{16}
\]

Let \(e^*\in E(T)\) be the triangulation edge dual to the fixed primal root
edge.  Both rooted targets contain that primal root edge in their matchings,
so \(e^*\in\mu_\chi\cap\mu_\eta\).  It is absent from the symmetric
difference, and every corner of the exterior cube keeps \(e^*\)
monochromatic.

This last statement preserves only root-edge membership.  It does not
preserve root-admissibility.  The latter also requires the monochromatic
component total to be three and the two ordered root fragments to remain in
distinct opposite-colour components.  In the shore-rank language, one needs
both the four-rank balance
\[
 \rho_{00}+\rho_{11}=\rho_{10}+\rho_{01}
\tag{17}
\]
and ordered root-fragment separation.  An exterior path toggle can merge or
split monochromatic components, so neither condition follows from the
Boolean exchange theorem, the even delta-matroid rule, noncrossing, or
(16).

## 6. The single remaining root-labelled selection lemma

For \(\sigma\in\Omega(H)\), use the following closure predicates.

* \(P_{\neg11}^b(\sigma)\) means that \(\sigma\), with a suitable parent
  colour at \(z\), has a root-admissible non-\(11\) parent closure in gate
  sector \(b\).
* \(X_N^b(\sigma)\), for \(N\in\{R,U,V\}\), means that \(\sigma\) has a
  root-admissible child closure in the indicated nondirect cell and gate
  sector \(b\).

These predicates include all interval NAE conditions, the root edge and
gate labels, the component-rank condition, and ordered root-fragment
separation.  They are decorations on vertices of the full exterior cubical
complex \(\mathcal Q(H)\), not consequences of its undecorated cube
structure.

> **Root-labelled cubical selection lemma (unproved).** Let
> \(T\rightsquigarrow T^+\) be an interface-disjoint legal split of actual
> 4-connected Eulerian plane triangulations.  Suppose a state-\(11\)
> root-admissible parent colouring \(\chi^b\) and a non-\(11\)
> root-admissible parent colouring \(\eta^{1-b}\) form a rooted bond.  Then
> the sector-\(b\) vertices of the complete exterior exchange complex contain
> a colouring \(\sigma\) such that
> \[
> P_{\neg11}^b(\sigma)
> \quad\text{or}\quad
> X_R^b(\sigma)\vee X_U^b(\sigma)\vee X_V^b(\sigma).
> \tag{18}
> \]
> The selected \(\sigma\) is not asserted to lie in the single pair-generated
> cube between \(\chi|_H\) and \(\eta|_H\); the complete actual exterior
> complex may be necessary.

If \({\cal L}_{\neg11}^{\,b}=\varnothing\), the first disjunct in (18) is
impossible, and (18) gives \({\cal N}^b\ne\varnothing\), exactly
\(P_{\rm sector}\).

The only unproved arrow is therefore the **root-labelled choice**: use the
actual noncrossing exchange cubes to select a gate-even exterior whose
parent or child gluing satisfies both (17) and ordered root separation.
NAE feasibility, componentwise toggling, gate parity, and root-edge
membership have already been supplied by the theorem above.

## Scope boundary

The proved statements are pairwise and exact for the complete NAE family of
one triangulated disk.  They do not use counting, enumeration, literature,
or the \(11\)--\(11\) branch.  Eulerianity is not needed for the exterior
cube theorem itself; it belongs to the actual parent/child setting of the
selection problem.  No convexity, parity identity, or delta-matroid axiom
for the ordered root-component decorations has been proved.  Accordingly,
this note proves neither \(P_{\rm sector}\) nor its negation and supplies no
actual counterexample.
