# 连通吸收的单圈边界、路径区间与有限容量缺口

2026-09-27。仅 Barnette；本轮裁决为 **VERIFIED-CONDITIONAL / FIRST-EXISTENCE-GAP**。

输入为冻结的 [SPEC-2026-09-12-upgrade.md](../SPEC-2026-09-12-upgrade.md)、
[共同子树独立核验](common-subtree-independent-20260927.md)、
[连通吸收独立推导](connected-absorption-independent-20260927.md) 和
[本轮指定 Pro 正文](pro-absorption-interval-20260927.txt)。
项目及 scratch 未发现额外 AGENTS.md；按会话给定指令执行。
以下从定义重推，不把旧核验结论当作承重证明；旧记录仅提供对象、符号和固定图数据。
未读取同步 Pro 的后续答案，不联网，不作新颖性判断。

本轮要改变的判断是两个必要结构定理是否成立，以及它们是否足以推进第一存在接口
\(\mathsf{Hard}\Rightarrow\Lambda<\infty\)。可能结果为条件定理失效、条件定理成立而
存在接口仍缺失、或第一存在接口闭合。最便宜的区分是三角形局部合法性、树连通性、
Jordan 分离，以及同一个固定图的少量指定赋值。

## 1. 裁决与准确范围

两个必要结构定理均成立：

1. 每个可用连通吸收的 **翻转岸** \(Q[U]\) 与 \(Q[V(Q)\setminus U]\) 都连通；
   因而交换边界恰是一条避开 \(e,f\) 的简单 \(M\)-交替圈。
2. 若该吸收使 \(e^*\) 在新匹配对偶图中非桥，则
   \(B\cap V(\Pi)\) 是非空连续内部顶点区间，允许区间只有一个顶点。

这里的两岸不是新二染色的两个色类。新根色为 \(K\cup B\)，另一色为 \(A\cup D\)；
当 \(r\ge1\) 时，后者是恰有 \(r\) 个分量的森林，通常不连通。

\(\Lambda\) 与原接边网络族的最小值相等，但只覆盖**根分离的连通吸收**。
Pro “每个原连通吸收都出现在这个定义里”若不保留根分离限定，字面上过宽。
区间条件只有必要性；§7 的既有赋值直接否定其逆命题。

偶割与所有父圈跨割的论证成立，前提是已经有有限容量见证。
它不能处理 \(\Lambda=\infty\)。本轮没有证明
\(\mathsf{Hard}\Rightarrow\Lambda<\infty\)，也没有完整 Hard 域的反例。
第一未闭合处精确见 §6；至此停止，不进入有限容量下降问题。

## 2. 对象、简单性与最小度

\(G\) 是实际合法历史中的简单、三连通、三价、二分球面图，同一 site 面依次含
\(p=uv,e=vx,q=xy\)。令
\[
\mathcal H=J_G(p,f),\qquad
\mathsf{Hard}=
\{\text{原图与 site 条件、全局 }H^{+-},
\ \forall D\in J_G(e,f):p,q\notin D,\ \mathsf L\}.
\]
其中 \(\mathsf L\) 是对**整个** \(\mathcal H\) 的条件：各父圈的路径 \(\Pi_C\)
均无边界避开 \(f\) 的内部四边形面。全局 \(H^{+-}\) 保证 \(\mathcal H\ne\varnothing\)；
kill 条件使每个 \(C\in\mathcal H\) 避开 \(e\)。固定这样的 \(C\)，则
\[
M=E(G)\setminus C\supseteq\{e,f\},\qquad p,q\in C.
\]
以下条件定理只使用这个父圈与图的结构，未使用全族 \(\mathsf L\) 或构造史来推出存在性。

令 \(Q=G^*\)。三连通性排除桥和二边割，所以 \(Q\) 无环、无平行边；
三价性使其面为三角形。原图各面是简单偶圈，长度至少四，故
\[
Q\text{ 是简单球面三角剖分},\qquad d_Q(z)\text{ 为偶数且 }d_Q(z)\ge4.
\]
特别地，顶点 link 中的邻点互异，连续邻点确实与中心点组成面三角形。
不能仅从原图三价性推出对偶最小度四。

Hamilton 圈 \(C\) 两侧是圆盘，匹配边是各盘中互不相交的弦。逐条加入弦时把一个
区域分成两个，故同侧面邻接图为树：
\[
(V(Q),M^*)=T_I\sqcup T_O,\qquad T_I=Q[I],\quad T_O=Q[O].
\]
令 \(e^*=ab\in T_I\)，\(I_0,I_1\) 是 \(T_I-e^*\) 中分别含 \(a,b\) 的分量。

取
\[
U=A\cup B,\quad A\subseteq I,\quad\varnothing\ne B\subseteq O,\qquad
K=I\setminus A,\quad D=O\setminus B.
\]
“可用连通吸收”精确要求：\(T_I[K]\) 连通且含 \(a,b\)，\(T_O[B]\) 连通，
翻色后无单色面三角形，且 \(f^*\) 两端同时翻或同时不翻。

旧、新二染色在每个三角形都有唯一同色边，对应每个原顶点唯一的匹配边。
所以
\[
\partial U=\{g:g^*\in\delta_Q(U)\},\qquad N=M\triangle\partial U
\]
确为同一个完美匹配，且 \(e,f\in N\)。每个原顶点处的 \(\partial U\) 度数为零，
或由一条 \(M\)-边和一条非 \(M\)-边组成。于是其非空分量都是顶点不交的交替圈。
所有对偶计数均保留孤立面顶点。

## 3. 两岸连通与单条边界：包括单点分量

取 \(T_I[A]\) 的任一分量 \(A_j\)。由于 \(T_I\) 是树而 \(K\) 非空连通，
\(A_j\) 与 \(K\) 恰有一条树边相接。若 \(A_j\) 没有跨旧色边接到 \(B\)，则：

- 若 \(A_j\) 含边，取其一侧面三角形。两端旧色均为 \(I\)，第三点旧色为 \(O\)，
  且第三点不在 \(B\)。翻色后这三点全部为新 \(O\) 色，矛盾。
- 若 \(A_j=\{i\}\)，则 \(i\) 恰有一个旧 \(I\)-邻点，其余至少三个不同的旧 \(O\)-邻点
  在 link 中连续排列。取其中相邻两个；它们都不翻色，而 \(i\) 翻成 \(O\)，
  又得到单色面三角形。

因此每个 \(A_j\) 均接到非空连通的 \(B\)，故 \(Q[A\cup B]\) 连通。
\(A=\varnothing\) 时结论直接成立。

再取 \(T_O[D]\) 的分量 \(D_j\)。它与非空连通的 \(B\) 恰由一条树边相接。
若它不接到 \(K\)，全部旧 \(I\)-邻点都在 \(A\) 中并翻成新 \(O\)。
若 \(D_j\) 含边，取该边旁的面三角形；若 \(D_j\) 为单点，取其至少三个旧
\(I\)-邻点中连续两个。两种情形都产生单色面三角形。因此每个 \(D_j\) 接到
连通的 \(K\)，故 \(Q[K\cup D]\) 连通。空 \(D\) 的连通结论亦直接成立；
实际根边合法性还会强迫 \(D\) 含下节两个第三顶点。

\(B\ne\varnothing\) 和 \(a,b\notin U\) 使割非空且真。两岸连通使
\(\delta_Q(U)\) 成为 bond；球面上的 bond 对偶为一个简单圈。结合上一节的
局部交替性，\(\partial U=M\triangle N\) 恰为一条简单交替圈，并避开 \(e,f\)。

这不证明任意大小的树枝都能实现，也不证明任意受保护匹配或多圈交换都能规范化为本类。
Pro 关于匹配多面体相邻顶点的附带解释亦成立：限制到 \(M\cup N\) 的面后，
公共边被固定，剩余一个偶圈只有两种交替匹配，恰给线段的两端。
该相邻关系仍不供给所需邻居的存在性。

## 4. 圈数、根分离与路径区间

### 4.1 圈数公式的前提

对任意完美匹配 \(N\)，令 \(H_N=(V(Q),N^*)\)，\(h=c(G-N)\)。
\(G-N\) 的 \(h\) 个不交 Jordan 圈把球面分成 \(h+1\) 个区域，恰对应 \(H_N\)
的分量。又有 \(|N|=|V(Q)|-2\)，所以
\[
c(H_N)=h+1,\qquad \beta(H_N)=h-1.                 \tag{1}
\]
等价的 Euler 公式是
\[
c((E(G)\setminus F)^*)=|F|-|V(G)|+c(V(G),F)+1.
\]
分别代入 \(F=E(G-N)\) 与 \(F=E(G-N)\cup\{e\}\)，得
\[
e^*\text{ 为 }H_N\text{ 的桥}\iff v,x\text{ 属于同一补圈}.     \tag{2}
\]
因 \(e\in N\)，三价性保证 \(p,q\in G-N\)，故这里也等价于 \(p,q\) 同圈。

记
\[
r=|E_{C^*}(K,B)|.
\]
若 \(r\ge1\)，新根色 \(Q[K\cup B]\) 是两棵树加 \(r\) 条接边，
连通且圈秩为 \(r-1\)。另一色 \(Q[A\cup D]\) 必为森林：否则取其简单圈，
两侧均须有根色顶点，否则一侧的三角剖分含单色面三角形；根色连通路径却无法
越过该圈。若这片森林有 \(t\) 个分量，则
\[
(|K|+|B|-2+r)+(|A|+|D|-t)=|V(Q)|-2,
\]
给出 \(t=r\)。由 (1) 得
\[
\boxed{r\ge1\Longrightarrow c(G-N)=r.}              \tag{3}
\]

删掉 \(e^*\) 后 \(K\) 分成 \(K\cap I_0,K\cap I_1\)，它们均非空。
因为 \(B\) 连通，\(e^*\) 非桥当且仅当接边的 \(K\)-端同时命中这两部分。
因此
\[
\boxed{c(G-N)=2\ \text{且 }p,q\text{ 分圈}
\iff r=2\ \text{且两个接点分居 }I_0,I_1.}            \tag{4}
\]
这是同一个 \(U,N\) 上的联合条件。仅 \(r=2\) 不充分。

若 \(r=0\)，根色是互不相接的两棵树，含 \(e^*\) 的分量仍是树，
故 \(e^*\) 为桥，根不分离。不能把 (3) 延伸为 \(c(G-N)=0\)，
也不能在这个情形使用“根色连通迫使另一色为森林”的论证。

### 4.2 非空内部区间

令 \(ab\) 两侧面三角形的第三顶点为 \(o_v,o_x\in O\)，
\(\Pi=T_O[o_v,o_x]\)。由于 \(a,b\) 都保留旧根色，NAE 合法性强迫
\[
o_v,o_x\notin B.                                   \tag{5}
\]
两个第三顶点在原域必不同：若相同，简单三角形 \(abo_v\) 的两侧均为面，
整个球面三角剖分只能是 \(K_3\)，与最小度四矛盾。

树中连通子树与路径的顶点交总为空或连续区间，因为两个公共顶点间的唯一路径
同时属于二者。若 \(B\cap\Pi=\varnothing\)，原路径 \(\Pi\) 翻色后仍完全属于
另一色，并连接 \(o_v,o_x\)。

现在设 \(e^*\) 非桥。存在根色简单圈 \(Z\) 经过 \(ab\)。
\(ab\) 两侧的面三角形内部不与 \(Z\) 相交；其第三顶点不在 \(Z\) 上，
且分别位于 \(Z\) 两侧。因此另一色中的路径 \(\Pi\) 不可能连接它们。
矛盾。结合 (5)，得到
\[
\boxed{e^*\text{ 非桥}\Longrightarrow
\varnothing\ne B\cap V(\Pi)\subseteq V(\Pi)\setminus\{o_v,o_x\},
\quad B\cap V(\Pi)\text{ 连续}.}                    \tag{6}
\]

“连续区间”是顶点区间，可以为单点。零长度 \(\Pi\) 已被原域排除；
若形式上处理只有一条边、因而无内部顶点的 \(\Pi\)，(6) 的正确含义是
不存在根分离连通吸收，不能把空交称为非空区间。本证明无需先假定
\(\Pi\) 有足够多内部顶点。

若 \(f^*\) 是 \(\Pi\) 的一条边，两端的翻色位须相等，所以区间不能恰切开其中一端。
这条附加约束同样没有提供区间的存在性。

## 5. \(\Lambda\) 等价及偶割论证

### 5.1 只对根分离类的无损改写

令 \(\mathscr U_C^{\rm sep}\) 为相对 \(C\) 的全部根分离可用连通吸收。
令 \(\mathcal A(C)\) 为 Pro 的单条受保护交替圈族：取圈的不含 \(a,b\) 的一侧
\(U\)，要求 \(K,B\) 满足连通吸收条件，且根侧接点同时命中 \(I_0,I_1\)。

因为交替圈避开 \(e\)，\(a,b\) 处于同侧，所选 \(U\) 唯一。
§3 给出 \(\mathscr U_C^{\rm sep}\to\mathcal A(C)\)；反向由定义与交替翻转得到，
故这是精确对应。它不包含仍使根同圈的吸收。

固定 \(\rho\in O\) 和旧圈边 \(h_j^*=i_jo_j\)，\(i_j\in I_j\)。
原网络的有限割精确对应 \(\rho,o_0,o_1\in B\)、\(a,b,i_0,i_1\in K\) 的
可用连通吸收，容量为 \(r\)。任一这样的割根分离；反之，任一
\(U\in\mathscr U_C^{\rm sep}\) 可选其两条跨根接边并取任意 \(\rho\in B\)。
因此，包括空集最小值为 \(+\infty\) 的情形，
\[
\boxed{\Lambda
=\min_{C\in\mathcal H}\min_{U\in\mathscr U_C^{\rm sep}}r(U)
=\min_{C,\rho,h_0,h_1}\lambda(C,\rho,h_0,h_1).}        \tag{7}
\]
有限值均至少二。\(\Lambda=2\) 精确刻画这个受限机制的成功，不等价于
任意受保护匹配的成功。

由 (6)，(7) 右侧可以把 \(\rho\) 限在相应的 \(\Pi^\circ\) 中而不改变全局最小值。
另一个独立简化是固定接边对时令 \(\rho=o_0\)，因为任何可行 \(B\) 已含 \(o_0\)。
不能无证明地把这两个简化合并成要求 \(o_0\in\Pi^\circ\)；
接边的 \(O\)-端可以在离开路径的树枝上。

### 5.2 偶割与父圈穿越均正确，但已有有限见证在先

假设已经有 \(3\le\Lambda<\infty\) 的最优见证 \(N\)。从其补图选一个既不含
\(v\) 也不含 \(x\) 的额外圈 \(L\)，令 \(S=V(L)\)。
每个 \(S\) 顶点的两条补匹配边都留在 \(S\)，故
\[
\delta_G(S)\subseteq N,\qquad e\notin\delta_G(S).
\]
设原二分为 \(V_0,V_1\)，则 \(|S\cap V_0|=|S\cap V_1|\)。
令 \(m=|E(G[S])|\)，令 \(d_j\) 是割边中在 \(S\) 内端点属于 \(V_j\) 的数量。
三正则计数给出
\[
3|S\cap V_j|=m+d_j,\quad j=0,1,
\]
故 \(d_0=d_1\)。非平凡割的大小为正偶数，三连通排除二边割，因此
\[
|\delta_G(S)|\ge4.
\]
此处 \(m\) 包括圈内可能存在的匹配弦，不能只数 \(L\) 的边。
割中至多有一条受保护边 \(f\)。

对每个 \(D_0\in\mathcal H\)，令 \(m_{D_0}=|D_0\cap E(G[S])|\)；
同样的二正则计数为
\[
2|S\cap V_j|=m_{D_0}+d_j(D_0).
\]
所以两个方向的穿越数相等。Hamilton 连通性保证穿越非空，故两方向至少各一条；
\(D_0\) 避 \(f\)，这些穿越边均不受保护。Pro 的全称量词在这里成立，
不只针对参考父圈。

但这个论证从选定 \(N,L\) 开始。\(\Lambda=\infty\) 时无此输入。
即使有这些跨割边，也没有由上述计数推出保匹配、保根分离、保吸收连通性和降低圈数
的联合交换。本轮不继续研究这一更晚接口。

## 6. 唯一进一步接口：能否排除全部硬约束不可行

这里只判定 \(\mathsf{Hard}\Rightarrow\Lambda<\infty\)，不优化容量。

对一个固定 \(C,h_0,h_1\)，取 \(\rho=o_0\)。设翻色变量为 \(x_i\)（旧 \(I\)）
和 \(y_o\)（旧 \(O\)）。把 \(T_I-e^*\) 的两树根植于 \(a,b\)，\(T_O\) 根植于
\(o_0\)。父子 \(P,D\) 的硬约束为
\[
\begin{array}{ll}
I\text{-树边}:&x_P\le x_D,\\
I,I,O\text{ 三角形}:&x_P\le y_o\le x_D,\\
O\text{-树边}:&y_D\le y_P,\\
I,O,O\text{ 三角形}:&y_D\le x_i\le y_P.
\end{array}                                                     \tag{8}
\]
根边两侧固定 \(y_{o_v}=y_{o_x}=0\)，并固定 \(x_a=x_b=0\)。
\(f^*\) 两端翻色位相等。之所以一般 NAE 约束在这里化为蕴含，是两棵树的
连通方向已经固定；没有这一步不能直接套有向闭包。

令 \(D_\infty(C,o_0)\) 仅含 (8) 及保护 \(f\) 的有向蕴含弧，不加入任何单位容量弧。
指定接边给出强制一、零集合
\[
S=\{o_0,o_1\},\qquad Z=\{a,b,o_v,o_x,i_0,i_1\}.
\]
若从 \(S\) 能到达 \(Z\)，蕴含把一推到强制零，故不可行。
若不能，直接取所有可达变量为一、其余为零；这个闭包满足全部硬约束与 pins，
解码得到根分离连通吸收。因此
\[
\boxed{\lambda(C,o_0,h_0,h_1)<\infty
\iff \operatorname{Reach}_{D_\infty(C,o_0)}(S)\cap Z=\varnothing.} \tag{9}
\]
这与容量二判据不同：容量二还要把其余单位弧加入闭包；本轮不需要那一步。

于是第一存在接口精确为
\[
\boxed{
\mathsf{Hard}\Longrightarrow
\exists C\in\mathcal H\
\exists h_0^*=i_0o_0,\ h_1^*=i_1o_1,\quad i_j\in I_j:
\operatorname{Reach}_{D_\infty(C,o_0)}(\{o_0,o_1\})
\cap\{a,b,o_v,o_x,i_0,i_1\}=\varnothing.}                         \tag{FIRST}
\]
否定后件意味着**每个父圈、每对跨根接边**都有一条硬阻断路径；
不是每个网络容量至少三，也不是仅有某一个框架失败。

对固定有限 \(G\)，这是有限族的精确可达性问题；每个框架只需线性空间。
这里的有限性没有把冻结 SPEC 的全图量词化为有限阶检查。

独立推进到此仍不能闭合 (FIRST)。已证明的输入用途分别是：
\(H^{+-}\) 供给父圈族非空；kill 条件使所有父圈的补匹配保 \(e,f\)；
\(\mathsf L\) 禁止直接的受保护内部四面。两个结构定理从可行吸收出发，
没有从这些全族前件构造一个闭包避开 \(Z\) 的框架。
树路径交为非空区间本身也不保证根分离，§7 有直接证书。

要完成 (FIRST)，仍须排除硬阻断路径在上述全称范围内同时存在。
本文既未从这些路径导出违反某条 Hard 前件，也未给出满足全部 Hard 前件且全部框架
阻断的真实图。故准确裁决是 **GAP / UNRESOLVED**，不宣称逻辑独立、不宣称 Hard 为假。
不预设有限候选，不转入容量下降、相邻图阶或新的充分机制。

## 7. 既有固定图的最小直接检查

只复用旧记录给出的 24 点、36 边、14 面图和参考父圈。
未重跑构造史、全部完美匹配、全部面赋值或全部网络枚举。
本次只检查四个已经指定的面集、三个明确接边对，并对两个已知父圈检查一个固定割。
代码只使用标准库，保存常数大小的图与结果，不生成新图或扫描参数。

固定面号下
\[
e^*=\{0,9\},\quad f^*=\{0,1\},\quad
I_0=\{0,1,7,8\},\ I_1=\{9,11,13\},\quad
\Pi=(6,12,4,3,10).
\]

| 指定 \(U\) | 边界长 | \(r\) | 补圈长度 | 根分离 | \(B\cap\Pi\) |
|---|---:|---:|---|---|---|
| \(\{12\}\) | 6 | 3 | \(4,6,14\) | 是 | \(\{12\}\) |
| \(\{7,12\}\) | 8 | 2 | \(10,14\) | 是 | \(\{12\}\) |
| \(\{3,8\}\) | 8 | 2 | \(8,16\) | 是 | \(\{3\}\) |
| \(\{7,12,13\}\) | 10 | 1 | \(24\) | 否 | \(\{12\}\) |

四个边界都是单条交替圈，并保留 \(e,f\)。检查同时覆盖 \(A\) 的单点分量
和 \(D\) 的单点分量。最后一行说明：
\[
B\cap\Pi\text{ 非空内部连续}\centernot\Longrightarrow e^*\text{ 非桥}.
\]
所以不能用区间条件代替 (FIRST) 中的跨根接边 pins。

三个固定网络的直接证书如下：

- \(h_0=(14,15),h_1=(20,23),\rho=12\)：硬闭包为 \(\{12\}\)，可行。
  两个 pins 保留指定接边；保护 \(f\) 又令 \(x_1=x_0=0\)，强迫第三接边
  \((7,8)^*\)。\(U=\{12\}\) 达到下界，故 \(\lambda=3\)。
- \(h_0=(7,8),h_1=(20,23),\rho=12\)：同一硬闭包可行，
  \(U=\{7,12\}\) 达到两条强制接边的下界，故 \(\lambda=2\)。
- \(h_0=(6,9),h_1=(20,23),\rho=3\)：\(i_0=1,o_0=3,i_1=13,o_1=12\)。
  旧 \(O\)-树边 \(4\!-\!12\) 在以 3 为根的定向中父为 4、子为 12；
  原顶点 8 的三角形 \((1,4,12)\) 给出硬弧 \(y_{12}\to x_1\)。
  \(y_{12}=1,x_1=0\) 已被 pins 固定，故 \(\lambda=\infty\)。

这分别展示可行而最优容量三、最优容量二、以及第一阶段就不可行，不能混为一类。

对 \(U=\{12\}\)，额外补圈顶点为 \(\{1,7,13,14\}\)，割为
\[
\{(1,2),(7,8),(12,13),(14,15)\}\subseteq N.
\]
割大小四且含 \(f=(1,2)\)、不含 \(e\)。参考父圈与最后一行产生的父圈
各在两个二分方向使用一条未保护割边，符合 §5 的计数。
这些有限检查不是“所有父圈”的证明；该全称结论由 §5 的解析计数承担。

本固定图不能作为 Hard 反例：最后一行的补圈是另一真实 Hamilton 父圈，
其对侧路径直接重建为
\[
\Pi'=(6,13,4,3,10).
\]
内部面 13 的边界为 \((20,21,22,23)\)，是避开 \(f\) 的四面，
故**全族 \(\mathsf L\) 失败**。这一失败见证本轮直接核对，无需重跑旧的族计数。

检查输出为 \(\texttt{FIXED\_ABSORPTION\_INTERVAL\_CERTIFICATES\_VERIFIED}\)。
结构化结果见 [absorption-interval-independent-20260927-results.json](absorption-interval-independent-20260927-results.json)。
本轮只新增这两个 scratch 文件；不修改既有文件，不永久晋级，不提交推送，不远程。

## 附录：固定证书检查代码

下面的完整检查只打印结果，不修改任何文件。数据来自上面指定的旧固定图；
没有赋值枚举、匹配枚举、最小割求解或参数扫描。

```python
from collections import Counter
import json

F = [(16,17,3,2,1,13,12,0), (6,9,8,7,1,2), (5,6,2,3),
     (6,5,18,19,10,9), (8,9,10,11,21,20), (1,7,14,13),
     (4,0,12,15,23,22), (12,13,14,15), (17,18,5,3),
     (19,16,0,4,11,10), (19,18,17,16), (11,4,22,21),
     (15,14,7,8,20,23), (20,21,22,23)]
def rim(face):
    return {tuple(sorted(g)) for g in zip(face, face[1:] + face[:1])}
def reach(starts, arcs):
    found, todo = set(starts), list(starts)
    while todo:
        v = todo.pop()
        for a,b in arcs:
            if a == v and b not in found:
                found.add(b)
                todo.append(b)
    return found
def components(vertices, edges):
    unseen, out = set(vertices), []
    arcs = [(a,b) for a,b in edges if a in unseen and b in unseen]
    arcs += [(b,a) for a,b in arcs]
    while unseen:
        part = reach({min(unseen)}, arcs)
        out.append(part)
        unseen -= part
    return out
def rooted(vertices, edges, root):
    parent, todo = {root: None}, [root]
    for v in todo:
        for a,b in edges:
            w = b if a == v else a if b == v else None
            if w in vertices and w not in parent:
                parent[w] = v
                todo.append(w)
    assert set(parent) == set(vertices)
    return parent
def tree_path(vertices, edges, s, t):
    parent = rooted(vertices, edges, s)
    out = [t]
    while out[-1] != s:
        out.append(parent[out[-1]])
    return out[::-1]

E = set().union(*(rim(face) for face in F))
V, Q = set(range(24)), set(range(14))
dual = {g: tuple(i for i,face in enumerate(F) if g in rim(face)) for g in E}
assert len(E) == 36 and all(len(z) == 2 for z in dual.values())
QE = list(dual.values())
assert len(set(QE)) == len(QE) and all(a != b for a,b in QE)
assert Counter(v for g in E for v in g) == Counter({v:3 for v in V})
qd = Counter(v for g in QE for v in g)
assert min(qd.values()) == 4 and all(d % 2 == 0 for d in qd.values())
assert len(V) - len(E) + len(F) == 2
assert Counter((a,b) for face in F for a,b in zip(face, face[1:]+face[:1])) == Counter((b,a) for a,b in E) + Counter(E)

C = rim((0,4,22,23,20,21,11,10,19,16,17,18,5,3,2,6,9,8,7,1,13,14,15,12))
M = E-C
e, f = (0,16), (1,2)
T = [dual[g] for g in M]
a,b = dual[e]
I = next(z for z in components(Q,T) if a in z)
O = Q-I
I0 = next(z for z in components(I,[dual[g] for g in M-{e}]) if a in z)
I1 = I-I0
tri = [tuple(i for i,face in enumerate(F) if v in face) for v in V]
assert all(len(t) == 3 and len(set(t)&I) in (1,2) for t in tri)
ov,ox = [next(w for w in t if w not in (a,b)) for t in tri if {a,b} <= set(t)]
Pi = tree_path(O,T,ov,ox)
assert Pi == [6,12,4,3,10]
ce = {g: (next(z for z in dual[g] if z in I),next(z for z in dual[g] if z in O)) for g in C}

checks, by_U = [], {}
for U in ({12}, {7,12}, {3,8}, {7,12,13}):
    A,B,K,D = I&U, O&U, I-U, O-U
    boundary = {g for g,(z,w) in dual.items() if (z in U) != (w in U)}
    N = M ^ boundary
    assert {a,b} <= K and B and len(components(K,T)) == len(components(B,T)) == 1
    assert Counter(v for g in N for v in g) == Counter(V) and {e,f} <= N
    assert len(components(U,QE)) == len(components(Q-U,QE)) == 1
    assert all(d == 2 for d in Counter(v for g in boundary for v in g).values())
    assert len(components({v for g in boundary for v in g},boundary)) == 1
    assert not boundary & {e,f}
    contacts = {g for g,(i,o) in ce.items() if i in K and o in B}
    r = len(contacts)
    cycles = components(V,E-N)
    root_separated = not any(set(e) <= z for z in cycles)
    H = [dual[g] for g in N]
    nonbridge = any({a,b} <= z for z in components(Q,[dual[g] for g in N-{e}]))
    assert root_separated == nonbridge
    assert len(H)-len(Q)+len(components(Q,H)) == len(cycles)-1
    assert r >= 1 and len(cycles) == r
    assert root_separated == (any(ce[g][0] in I0 for g in contacts) and any(ce[g][0] in I1 for g in contacts))
    interval = [v for v in Pi if v in B]
    if root_separated:
        ix = [Pi.index(v) for v in interval]
        assert ix and ix == list(range(ix[0],ix[-1]+1)) and not {ov,ox}&B
    record = dict(U=sorted(U), A=sorted(A), B=sorted(B), r=r,
                  boundary_length=len(boundary), complement_cycle_lengths=sorted(map(len,cycles)),
                  root_separated=root_separated, B_intersect_Pi=interval,
                  singleton_A_components=[min(z) for z in components(A,T) if len(z)==1],
                  singleton_D_components=[min(z) for z in components(D,T) if len(z)==1])
    checks.append(record)
    by_U[frozenset(U)] = (N,cycles)
assert checks[-1]["r"] == 1 and not checks[-1]["root_separated"] and checks[-1]["B_intersect_Pi"]

N2,_ = by_U[frozenset({7,12,13})]
T2 = [dual[g] for g in N2]
I2 = next(z for z in components(Q,T2) if a in z)
Pi2 = tree_path(Q-I2,T2,ov,ox)
assert Pi2 == [6,13,4,3,10] and len(F[13]) == 4 and f not in rim(F[13])

def hard_arcs(rho):
    out = set()
    for vs,root,is_I in ((I0,a,True),(I1,b,True),(O,rho,False)):
        for d,p in rooted(vs,T,root).items():
            if p is None:
                continue
            out.add((p,d) if is_I else (d,p))
            for triangle in tri:
                if {p,d} <= set(triangle):
                    w = next(z for z in triangle if z not in (p,d))
                    out.update(((p,w),(w,d)) if is_I else ((d,w),(w,p)))
    z,w = dual[f]
    return out | {(z,w),(w,z)}
frameworks = []
for h0,h1,expected in [((14,15),(20,23),True), ((7,8),(20,23),True), ((6,9),(20,23),False)]:
    i0,o0 = ce[h0]
    i1,o1 = ce[h1]
    assert i0 in I0 and i1 in I1
    arcs = hard_arcs(o0)
    S,Z = {o0,o1}, {a,b,ov,ox,i0,i1}
    closure = reach(S,arcs)
    feasible = not closure & Z
    assert feasible == expected
    frameworks.append(dict(h0=list(h0),h1=list(h1),rho=o0,finite_feasible=feasible,
                           closure=sorted(closure),zero_hits=sorted(closure&Z)))
    if not feasible:
        assert (12,1) in arcs and 12 in S and 1 in Z
        frameworks[-1]["hard_obstruction_path"] = [12,1]
frameworks[0]["lambda"] = 3
frameworks[0]["certificate"] = "U={12}; h0,h1 force two contacts, f forces x_1=0, so (7,8) is a third contact."
frameworks[1]["lambda"] = 2
frameworks[1]["certificate"] = "U={7,12} has two forced cross-root contacts."
frameworks[2]["lambda"] = "infinity"

colour = {0:0}
todo = [0]
for v in todo:
    for u,w in E:
        z = w if u == v else u if w == v else None
        if z is not None:
            if z not in colour:
                colour[z] = 1-colour[v]
                todo.append(z)
            assert colour[z] != colour[v]
N3,cycles3 = by_U[frozenset({12})]
L, = [z for z in cycles3 if not z & set(e)]
cut = {g for g in E if len(set(g)&L) == 1}
assert L == {1,7,13,14} and len(cut) == 4 and cut <= N3 and e not in cut
cross_counts = []
for father in (C,E-N2):
    crossing = father & cut
    counts = [sum(colour[next(v for v in g if v in L)] == k for g in crossing) for k in (0,1)]
    assert counts[0] == counts[1] and counts[0] >= 1 and f not in crossing
    cross_counts.append(counts)

result = dict(
    date="2026-09-27",
    verdict="VERIFIED_CONDITIONAL; HARD_FINITE_EXISTENCE_GAP",
    proof_verdicts=dict(two_dual_shores_connected="valid",single_protected_alternating_cycle="valid",
                       nonempty_internal_interval_if_root_nonbridge="valid",
                       Lambda_network_equivalence="valid_for_root_separated_connected_absorptions",
                       even_cut_and_all_parent_crossing="valid_conditional_on_finite_candidate",
                       Hard_implies_Lambda_finite="unresolved",Hard_implies_Lambda_two="not_established"),
    fixed_check=dict(vertices=24,edges=36,faces=14,dual_min_degree=min(qd.values()),Pi=Pi,
                     specified_face_assignments=checks,specified_frameworks=frameworks,
                     interval_converse=False,
                     failure_of_full_L=dict(parent_flip=[7,12,13],Pi=Pi2,protected_internal_square=13),
                     extra_cycle_cut=dict(vertices=sorted(L),edges=sorted(map(list,cut)),parent_direction_counts=cross_counts)),
    scope=dict(new_graphs=0,face_assignment_enumeration=False,perfect_matching_enumeration=False,
               parameter_scan=False,remote_access=False,Pro_followup_read=False,
               limitation="These fixed certificates fail full L and cannot refute Hard; general claims are proved in the companion note, not by these checks.")
)
print(json.dumps(result,ensure_ascii=False))
print("FIXED_ABSORPTION_INTERVAL_CERTIFICATES_VERIFIED")
```
