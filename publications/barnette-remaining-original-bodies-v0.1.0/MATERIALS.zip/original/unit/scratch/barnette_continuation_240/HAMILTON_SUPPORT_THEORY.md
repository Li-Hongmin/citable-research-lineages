# Hamilton 圈支持结构：本轮得到的两个严格命题

## 1. 直接提升的支持超图刻画

固定图 $G$、合法同面扩张边 $p,q$，以及 Hamilton 圈族 $\mathcal F$。记

$$S_{\mathcal F}(e)=\{C\in\mathcal F:e\in C\}.$$

对 $p,q$ 做 C4-expansion 后，$\mathcal F$ 的全部可直接提升圈覆盖子图的每一条边，当且仅当：

1. 对每条保留旧边 $g$，
   $$S_{\mathcal F}(g)\cap(S_{\mathcal F}(p)\cup S_{\mathcal F}(q))\neq\varnothing;$$
2. 三种可提升状态 $11,10,01$ 至少出现两种。

第一条恰好刻画旧边何时出现在某条可提升圈中。第二条来自 gadget 的有限局部检查：三个局部边模式中任意两个的并覆盖 gadget 全部八条边，任意一个单独模式都不能。

### 兼容图推论

若取 $G$ 的全部 Hamilton 圈，并定义 Hamilton 兼容图 $K_H(G)$：顶点为 $E(G)$，两条边相邻当且仅当它们同属某条 Hamilton 圈，那么第一条等价于：

> 每个合法同面边对 $\{p,q\}$ 都是 $K_H(G)$ 的支配对。

若 $G$ edge-Hamiltonian，则第二条失败当且仅当 $p,q$ 是 **Hamilton twins**：它们出现在完全相同的 Hamilton 圈中。因此，全圈族 lift-complete 等价于：

- 每个合法边对在 Hamilton 兼容图中支配所有边；
- 没有合法边对构成 Hamilton twins。

这把下一步反例搜索从“找非 Hamilton 图”压缩为两个更早出现的故障：**不支配的合法边对**或**同面 Hamilton twins**。

## 2. 偶棱柱的无限族定理

令 $L_m=C_m\square K_2$，其中 $m\ge4$ 为偶数。标记上、下环边为 $T_i,B_i$，梯边为 $R_i$，下标模 $m$。

构造 $m+2$ 条 Hamilton 圈：

- 对每个 $i$，$H_i$ 使用 $R_i,R_{i+1}$，并使用除 $T_i,B_i$ 外的全部环边；
- $Z_0,Z_1$ 使用全部梯边，并在上下两环交错选择相反奇偶性的环边。

这些圈具有支持：

$$
\begin{aligned}
S(R_i)&=\{H_{i-1},H_i,Z_0,Z_1\},\\
S(T_i)&=\{H_k:k\ne i\}\cup\{Z_{i\bmod2}\},\\
S(B_i)&=\{H_k:k\ne i\}\cup\{Z_{1-i\bmod2}\}.
\end{aligned}
$$

由此立即得到：

1. 任意两条边同属上述某条 Hamilton 圈；
2. 任意两条不同边的支持集合不同。

因此该显式 $m+2$ 圈族对每个合法 C4 边对都是 lift-complete。于是：

> **定理。** 对每个偶数 $m\ge4$，$L_m$ 的任意合法一次 C4-expansion 都是 edge-Hamiltonian；从 $L_m$ 出发任意连续做两次合法 C4-expansion，所得图都是 Hamiltonian。

这是一个严格无限族结果，但尚未做完备新颖性审计；它很可能被更一般的已知 Barnette 子类结果涵盖，因此当前不把它宣称为新定理。

## 3. 尚缺的一步

真正决定性的命题仍是：

$$G\text{ 有 lift-complete family}\Longrightarrow
\text{每个合法 C4 后继也有 lift-complete family}.$$

有限链只证明了具体节点与全部一步邻域；它没有证明这一封闭性。完整 Barnette 猜想还必须另外处理 cube-expansion。
