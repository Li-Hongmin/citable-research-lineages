#!/usr/bin/env python3
"""Independent verifier for the Barnette C4 lift-chain certificate package.

Default mode checks hashes, graph properties, every Hamiltonian cycle, exact
chain reconstruction, and the parent-side C4 lift-completeness criterion for
all manifest-listed legal first-step expansion operations.

Use --second-level to recompute every child's number of legal C4 moves from
the exact local face-length update. This independently recovers the reported
7,709,148 labeled second-step expansion operations without trusting the stored
per-child counts.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
from statistics import mean
from typing import Sequence

import networkx as nx

Edge = tuple[int, int]


def ue(u: int, v: int) -> Edge:
    return (u, v) if u < v else (v, u)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def planar_faces(graph: nx.Graph) -> list[list[int]]:
    planar, embedding = nx.check_planarity(graph, counterexample=False)
    if not planar:
        raise AssertionError("graph is not planar")
    visited: set[tuple[int, int]] = set()
    faces: list[list[int]] = []
    for u, v in embedding.edges():
        if (u, v) not in visited:
            faces.append(list(embedding.traverse_face(u, v, visited)))
    return faces


def valid_c4_moves(graph: nx.Graph) -> list[tuple[tuple[int, ...], int, int]]:
    moves: list[tuple[tuple[int, ...], int, int]] = []
    for face_list in planar_faces(graph):
        face = tuple(face_list)
        length = len(face)
        if length < 4 or length % 2:
            continue
        for i in range(length):
            for j in range(i + 1, length):
                e1 = {face[i], face[(i + 1) % length]}
                e2 = {face[j], face[(j + 1) % length]}
                if e1 & e2:
                    continue
                if (j - i) % 2 == 0:
                    moves.append((face, i, j))
    return moves


def face_data_and_moves(
    graph: nx.Graph,
) -> tuple[list[list[int]], dict[Edge, list[int]], list[tuple[int, tuple[int, ...], int, int]]]:
    """Return faces, edge-to-face incidences, and legal moves with face ids."""
    faces = planar_faces(graph)
    edge_faces: dict[Edge, list[int]] = {}
    for fid, face in enumerate(faces):
        for k in range(len(face)):
            edge_faces.setdefault(ue(face[k], face[(k + 1) % len(face)]), []).append(fid)
    moves: list[tuple[int, tuple[int, ...], int, int]] = []
    for fid, face_list in enumerate(faces):
        face = tuple(face_list)
        length = len(face)
        if length < 4 or length % 2:
            continue
        for i in range(length):
            for j in range(i + 1, length):
                e1 = {face[i], face[(i + 1) % length]}
                e2 = {face[j], face[(j + 1) % length]}
                if e1 & e2:
                    continue
                if (j - i) % 2 == 0:
                    moves.append((fid, face, i, j))
    return faces, edge_faces, moves


def moves_on_even_face(length: int) -> int:
    """Number of legal labeled C4 edge pairs on an even face of given length."""
    if length < 4 or length % 2:
        return 0
    half = length // 2
    return half * (half - 1)


def child_legal_move_count_from_faces(
    faces: list[list[int]],
    edge_faces: dict[Edge, list[int]],
    fid: int,
    face: tuple[int, ...],
    i: int,
    j: int,
) -> int:
    """Count child legal moves from the exact local face-length update.

    A C4 expansion replaces the selected L-face by faces of lengths
    4, d+2, and L-d+2. The face across each removed edge gains 2; if
    both removed edges have the same opposite face, that face gains 4.
    """
    length = len(face)
    distance = j - i
    lengths = [len(f) for f in faces]
    counts = Counter(lengths)

    counts[length] -= 1
    counts[4] += 1
    counts[distance + 2] += 1
    counts[length - distance + 2] += 1

    e1 = ue(face[i], face[(i + 1) % length])
    e2 = ue(face[j], face[(j + 1) % length])
    opposite: list[int] = []
    for edge in (e1, e2):
        other = [x for x in edge_faces[edge] if x != fid]
        if len(other) != 1:
            raise AssertionError(f"unexpected face incidence for {edge}: {edge_faces[edge]}")
        opposite.append(other[0])

    if opposite[0] == opposite[1]:
        old = lengths[opposite[0]]
        counts[old] -= 1
        counts[old + 4] += 1
    else:
        for other_fid in opposite:
            old = lengths[other_fid]
            counts[old] -= 1
            counts[old + 2] += 1

    return sum(number * moves_on_even_face(length) for length, number in counts.items())


def c4_expand(
    graph: nx.Graph, face: Sequence[int], i: int, j: int
) -> tuple[nx.Graph, dict[str, object]]:
    length = len(face)
    u, v = face[i], face[(i + 1) % length]
    x, y = face[j], face[(j + 1) % length]
    if len({u, v, x, y}) != 4:
        raise AssertionError("C4 expansion requires disjoint boundary edges")
    child = graph.copy()
    next_node = max(child.nodes, default=-1) + 1
    a, b, c, d = range(next_node, next_node + 4)
    child.remove_edge(u, v)
    child.remove_edge(x, y)
    child.add_edges_from(
        [
            (u, a), (a, b), (b, v),
            (x, c), (c, d), (d, y),
            (a, d), (b, c),
        ]
    )
    return child, {"new_vertices": [a, b, c, d]}


def cycle_edges(cycle: Sequence[int]) -> set[Edge]:
    return {ue(cycle[i], cycle[(i + 1) % len(cycle)]) for i in range(len(cycle))}


def verify_cycle(graph: nx.Graph, cycle: Sequence[int]) -> bool:
    return (
        len(cycle) == graph.number_of_nodes()
        and len(set(cycle)) == graph.number_of_nodes()
        and set(cycle) == set(graph.nodes())
        and all(
            graph.has_edge(cycle[i], cycle[(i + 1) % len(cycle)])
            for i in range(len(cycle))
        )
    )


def graph_validation(graph: nx.Graph) -> dict[str, object]:
    planar, _ = nx.check_planarity(graph, counterexample=False)
    return {
        "vertices": graph.number_of_nodes(),
        "edges": graph.number_of_edges(),
        "simple": nx.number_of_selfloops(graph) == 0 and not graph.is_multigraph(),
        "cubic": all(d == 3 for _, d in graph.degree()),
        "bipartite": nx.is_bipartite(graph),
        "planar": planar,
        "vertex_connectivity": nx.node_connectivity(graph),
        "face_lengths": {
            str(k): v for k, v in sorted(Counter(map(len, planar_faces(graph))).items())
        },
    }


def direct_lift_criterion(
    graph: nx.Graph,
    cycle_sets: list[set[Edge]],
    move: tuple[tuple[int, ...], int, int],
) -> tuple[bool, int, set[str], list[Edge]]:
    face, i, j = move
    length = len(face)
    e1 = ue(face[i], face[(i + 1) % length])
    e2 = ue(face[j], face[(j + 1) % length])
    liftable = [edges for edges in cycle_sets if e1 in edges or e2 in edges]
    states = {
        f"{int(e1 in edges)}{int(e2 in edges)}"
        for edges in liftable
    }
    covered_old = set().union(*liftable) if liftable else set()
    retained = {ue(u, v) for u, v in graph.edges()} - {e1, e2}
    missing_old = sorted(retained - covered_old)
    ok = not missing_old and len(states & {"11", "10", "01"}) >= 2
    return ok, len(liftable), states, missing_old


def main() -> None:
    parser = argparse.ArgumentParser()
    local_manifest = Path(__file__).with_name("barnette_liftchain_manifest.json")
    packaged_manifest = Path(__file__).parent / "barnette_continuation_200" / "barnette_liftchain_manifest.json"
    default_manifest = local_manifest
    if local_manifest.exists() and not (local_manifest.parent / "graphs").exists() and packaged_manifest.exists():
        default_manifest = packaged_manifest
    parser.add_argument(
        "--manifest",
        type=Path,
        default=default_manifest,
    )
    parser.add_argument(
        "--second-level",
        action="store_true",
        help="also recompute all labeled second-move counts",
    )
    args = parser.parse_args()

    manifest_path = args.manifest.resolve()
    root = manifest_path.parent
    manifest = json.loads(manifest_path.read_text())
    failures: list[str] = []
    totals = {"first_moves": 0, "second_moves": 0, "certificate_cycles": 0}
    previous_graph: nx.Graph | None = None

    for node in manifest["nodes"]:
        label = node["id"]
        paths = {k: root / v for k, v in node["files"].items() if v is not None}
        for role, path in paths.items():
            if sha256(path) != node["sha256"][role]:
                failures.append(f"{label}: SHA256 mismatch for {role}")

        graph_data = json.loads(paths["graph"].read_text())
        cert = json.loads(paths["certificate"].read_text())
        audit = json.loads(paths["audit"].read_text())
        graph6 = graph_data["graph6"]
        graph = nx.from_graph6_bytes(graph6.encode())

        if cert["graph6"] != graph6:
            failures.append(f"{label}: certificate graph6 mismatch")
        validation = graph_validation(graph)
        if validation != node["validation"]:
            failures.append(f"{label}: graph validation mismatch: {validation!r}")

        cycles = cert["certificate_cycles"]
        if len(cycles) != node["final_cycle_count"]:
            failures.append(f"{label}: cycle count mismatch")
        cycle_sets: list[set[Edge]] = []
        for cidx, cycle in enumerate(cycles):
            if not verify_cycle(graph, cycle):
                failures.append(f"{label}: invalid Hamiltonian cycle {cidx}")
                break
            cycle_sets.append(cycle_edges(cycle))
        all_edges = {ue(u, v) for u, v in graph.edges()}
        if cycle_sets and set().union(*cycle_sets) != all_edges:
            failures.append(f"{label}: cycle family does not cover every parent edge")

        if previous_graph is not None:
            parent_moves = valid_c4_moves(previous_graph)
            move_index = node["parent_move_index"]
            if not (0 <= move_index < len(parent_moves)):
                failures.append(f"{label}: parent move index out of range")
            else:
                reconstructed, _ = c4_expand(previous_graph, *parent_moves[move_index])
                reconstructed_g6 = nx.to_graph6_bytes(
                    reconstructed, header=False
                ).decode().strip()
                if reconstructed_g6 != graph6:
                    failures.append(f"{label}: chain reconstruction mismatch")

        faces, edge_faces, moves_with_ids = face_data_and_moves(graph)
        moves = [(face, i, j) for _, face, i, j in moves_with_ids]
        if len(moves) != node["legal_first_moves"]:
            failures.append(f"{label}: legal first-move count mismatch")

        lift_counts: list[int] = []
        second_count = 0
        for midx, (fid, face, i, j) in enumerate(moves_with_ids):
            move = (face, i, j)
            ok, liftable_count, states, missing_old = direct_lift_criterion(
                graph, cycle_sets, move
            )
            lift_counts.append(liftable_count)
            if not ok:
                failures.append(
                    f"{label}: lift criterion failed at move {midx}; "
                    f"states={sorted(states)}, missing_old={missing_old[:5]}"
                )
                break
            if args.second_level:
                child_count = child_legal_move_count_from_faces(
                    faces, edge_faces, fid, face, i, j
                )
                second_count += child_count
                stored_entry = audit["entries"][midx]
                stored_child_count = stored_entry.get(
                    "legal_second_moves_certified_hamiltonian",
                    stored_entry.get("legal_second_moves"),
                )
                if child_count != stored_child_count:
                    failures.append(
                        f"{label}: per-move second-count mismatch at {midx}: "
                        f"{child_count} != {stored_child_count}"
                    )

        if lift_counts:
            if min(lift_counts) != node["liftable_cycle_count_min"]:
                failures.append(f"{label}: minimum liftable-cycle count mismatch")
            if max(lift_counts) != node["liftable_cycle_count_max"]:
                failures.append(f"{label}: maximum liftable-cycle count mismatch")
            if not math.isclose(
                mean(lift_counts),
                node["liftable_cycle_count_mean"],
                rel_tol=0,
                abs_tol=1e-12,
            ):
                failures.append(f"{label}: mean liftable-cycle count mismatch")

        if not audit.get("all_first_children_directly_certified_edge_hamiltonian", False):
            failures.append(f"{label}: stored audit not complete")
        if int(audit["legal_first_moves"]) != node["legal_first_moves"]:
            failures.append(f"{label}: stored first-move count mismatch")
        if (
            int(audit["total_labeled_second_moves_certified_hamiltonian"])
            != node["labeled_second_moves"]
        ):
            failures.append(f"{label}: stored second-move count mismatch")
        if args.second_level and second_count != node["labeled_second_moves"]:
            failures.append(
                f"{label}: recomputed second-move count mismatch ({second_count})"
            )

        totals["first_moves"] += node["legal_first_moves"]
        totals["second_moves"] += node["labeled_second_moves"]
        totals["certificate_cycles"] += node["final_cycle_count"]
        previous_graph = graph
        print(
            f"[OK so far] {label}: n={graph.number_of_nodes()}, "
            f"cycles={len(cycles)}, moves={len(moves)}"
        )

    if totals != manifest["totals"]:
        failures.append(f"total mismatch: {totals!r} != {manifest['totals']!r}")

    if failures:
        print("\nVERIFICATION FAILED")
        for failure in failures:
            print(" -", failure)
        raise SystemExit(1)

    print("\nVERIFICATION PASSED")
    print(
        json.dumps(
            {
                "nodes": len(manifest["nodes"]),
                "first_moves_verified": totals["first_moves"],
                "stored_labeled_second_moves": totals["second_moves"],
                "second_level_recomputed": args.second_level,
                "certificate_cycles_counted_with_multiplicity": totals[
                    "certificate_cycles"
                ],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
