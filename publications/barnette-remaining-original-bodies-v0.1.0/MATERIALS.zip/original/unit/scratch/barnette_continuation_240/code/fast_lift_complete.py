#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys, time, hashlib
from pathlib import Path
from typing import Iterable
import networkx as nx
sys.path.insert(0,'/mnt/data/barnette_work/barnette_attempt_package')
from barnette_c4_attack import valid_c4_moves, c4_expand, undirected_edge
from audit_hplusminus import load_graph
from audit_all_c4_children import cycle_edges, verify_cycle
from forced_hamiltonian import solve

Edge=tuple[int,int]

def ckey(c): return tuple(sorted(cycle_edges(c)))

def patterns(face,i,j,rec):
    L=len(face);u,v=face[i],face[(i+1)%L];x,y=face[j],face[(j+1)%L]
    a,b,c,d=rec['new_vertices']; ue=undirected_edge
    return {
      '11': {ue(*z) for z in [(u,a),(a,b),(b,v),(x,c),(c,d),(d,y)]},
      '10': {ue(*z) for z in [(u,a),(a,d),(d,c),(c,b),(b,v)]},
      '01': {ue(*z) for z in [(x,c),(c,b),(b,a),(a,d),(d,y)]},
    }

def fast_audit(G:nx.Graph, cycles:list[list[int]]):
    sets=[cycle_edges(c) for c in cycles]
    GE={undirected_edge(u,v) for u,v in G.edges()}
    failures=[]
    for idx,(face,i,j) in enumerate(valid_c4_moves(G)):
        L=len(face); e1=undirected_edge(face[i],face[(i+1)%L]); e2=undirected_edge(face[j],face[(j+1)%L])
        H,rec=c4_expand(G,face,i,j); pats=patterns(face,i,j,rec)
        union=set(); states={'10':0,'01':0,'11':0}
        for E in sets:
            h1=e1 in E;h2=e2 in E
            if not(h1 or h2): continue
            st=f'{int(h1)}{int(h2)}'; states[st]+=1
            union |= (E-{e1,e2}) | pats[st]
        HE={undirected_edge(u,v) for u,v in H.edges()}
        missing=HE-union
        if missing:
            newv=set(rec['new_vertices'])
            old_missing=sorted(e for e in missing if not (set(e)&newv))
            gadget_missing=sorted(missing-set(old_missing))
            failures.append({'move_index':idx,'face':list(face),'i':i,'j':j,'e1':e1,'e2':e2,'states':states,
                             'missing':sorted(missing),'old_missing':old_missing,'gadget_missing':gadget_missing,
                             'patterns':{k:sorted(v) for k,v in pats.items()}})
    return failures

def persist(base, cycles, log, failures, status, outpath, elapsed):
    out=dict(base)
    out['certificate_cycles']=cycles; out['certificate_cycle_count']=len(cycles)
    out['fast_direct_lift_completion']={
      'source_certificate':base.get('_source_certificate'),
      'initial_cycles':base.get('_initial_cycles'),
      'final_cycles':len(cycles),
      'added_cycles':len(cycles)-base.get('_initial_cycles',len(cycles)),
      'status':status,
      'remaining_failed_moves':len(failures),
      'remaining_missing_edges':sum(len(f['missing']) for f in failures),
      'failure_sample':failures[:20],
      'solver_log':log,
      'elapsed_seconds':elapsed,
    }
    out.pop('_source_certificate',None);out.pop('_initial_cycles',None)
    outpath.write_text(json.dumps(out,indent=2))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('certificate',type=Path);ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--time-limit',type=float,default=60);ap.add_argument('--max-additions',type=int,default=100);a=ap.parse_args()
    data=json.loads(a.certificate.read_text()); G,g6=load_graph(Path(data['graph']))
    cycles=list(data['certificate_cycles']); seen={ckey(c) for c in cycles}; initial=len(cycles); log=[];t0=time.time()
    base=dict(data);base['_source_certificate']=str(a.certificate);base['_initial_cycles']=initial
    for it in range(a.max_additions+1):
        failures=fast_audit(G,cycles)
        print(json.dumps({'iteration':it,'cycles':len(cycles),'failed_moves':len(failures),'missing_edges':sum(len(f['missing']) for f in failures)}),flush=True)
        persist(base,cycles,log,failures,'complete' if not failures else 'running',a.output,time.time()-t0)
        if not failures: break
        # Score target: prioritize old-edge gaps, else absent gadget traversal state.
        f=next((x for x in failures if x['old_missing']), failures[0])
        attempts=[]; found=None; target={}
        if f['old_missing']:
            g=f['old_missing'][0]; target={'type':'old_edge','edge':list(g)}
            for branch,e in enumerate((f['e1'],f['e2'])):
                r=solve(G,forced_in=[g,e],time_limit=a.time_limit,max_rounds=10000,seed=1000003*it+1009*f['move_index']+branch)
                attempts.append({'forced_in':[list(g),list(e)],'forced_out':[],'status':r.status,'seconds':r.seconds,'rounds':r.rounds,'cuts':r.cuts,'message':r.message})
                if r.status=='hamiltonian' and r.cycle:
                    found=r.cycle; break
        else:
            # Choose an unrealized state that maximally covers currently missing gadget edges.
            miss=set(f['gadget_missing']); candidates=[]
            for st in ('10','01','11'):
                gain=len(miss & set(map(tuple,f['patterns'][st])))
                if f['states'][st]==0 and gain: candidates.append((gain,st))
            if not candidates:
                # A state may exist in the family but still not be selected due to a bug; try max-gain state.
                for st in ('10','01','11'):
                    gain=len(miss & set(map(tuple,f['patterns'][st])))
                    if gain:candidates.append((gain,st))
            candidates.sort(reverse=True); st=candidates[0][1];target={'type':'state','state':st,'gadget_missing':[list(e) for e in f['gadget_missing']]}
            forced=[];forbidden=[]
            if st=='10':forced=[f['e1']];forbidden=[f['e2']]
            elif st=='01':forced=[f['e2']];forbidden=[f['e1']]
            else:forced=[f['e1'],f['e2']]
            r=solve(G,forced_in=forced,forced_out=forbidden,time_limit=a.time_limit,max_rounds=10000,seed=1000003*it+1009*f['move_index'])
            attempts.append({'forced_in':[list(e) for e in forced],'forced_out':[list(e) for e in forbidden],'status':r.status,'seconds':r.seconds,'rounds':r.rounds,'cuts':r.cuts,'message':r.message})
            if r.status=='hamiltonian' and r.cycle:found=r.cycle
        rec={'iteration':it,'move_index':f['move_index'],'expanded_edges':[list(f['e1']),list(f['e2'])], 'target':target,'attempts':attempts,'resolved':found is not None}
        if found is None:
            log.append(rec);persist(base,cycles,log,failures,'unresolved',a.output,time.time()-t0);break
        if not verify_cycle(G,found):raise AssertionError('solver returned invalid cycle')
        k=ckey(found)
        if k in seen:
            rec['duplicate']=True;log.append(rec);persist(base,cycles,log,failures,'stalled_duplicate',a.output,time.time()-t0);break
        seen.add(k);cycles.append(found);rec['cycle_index']=len(cycles)-1;log.append(rec)
    else:
        failures=fast_audit(G,cycles);persist(base,cycles,log,failures,'max_additions',a.output,time.time()-t0)
    print(json.dumps({'initial_cycles':initial,'final_cycles':len(cycles),'added':len(cycles)-initial,
                      'status':json.loads(a.output.read_text())['fast_direct_lift_completion']['status'],
                      'elapsed_seconds':round(time.time()-t0,3)},indent=2))

if __name__=='__main__':main()
