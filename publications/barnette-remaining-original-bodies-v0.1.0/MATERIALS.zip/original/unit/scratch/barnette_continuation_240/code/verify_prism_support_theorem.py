#!/usr/bin/env python3
"""Finite sanity checker for the explicit prism support-family proof.

For each even m, index m perimeter Hamiltonian cycles H_0,...,H_{m-1}
and two zig-zag cycles Z_0,Z_1.  The edge support sets are:
  R_i: {H_{i-1}, H_i, Z_0, Z_1}
  T_i: {H_k:k!=i} plus Z_{i mod 2}
  B_i: {H_k:k!=i} plus Z_{1-i mod 2}.
The script checks that all supports are distinct and pairwise intersect.
Those two facts imply the family is C4 lift-complete for every distinct
edge pair, hence in particular every legal facial pair.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path

def supports(m:int):
    H=set(range(m)); z0=m;z1=m+1;out={}
    for i in range(m):
        out[f'R{i}']=(1<<((i-1)%m))|(1<<i)|(1<<z0)|(1<<z1)
        hmask=(1<<m)-1
        out[f'T{i}']=(hmask & ~(1<<i)) | (1<<(z0 if i%2==0 else z1))
        out[f'B{i}']=(hmask & ~(1<<i)) | (1<<(z1 if i%2==0 else z0))
    return out

def audit(m:int):
    S=supports(m);items=list(S.items());disjoint=[];twins=[]
    for i,(a,A) in enumerate(items):
        for b,B in items[i+1:]:
            if not (A&B):disjoint.append([a,b])
            if A==B:twins.append([a,b])
    return {'m':m,'vertices':2*m,'cycles':m+2,'edges':3*m,
            'disjoint_support_pairs':len(disjoint),'support_twins':len(twins),
            'passed':not disjoint and not twins}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--max-m',type=int,default=500);ap.add_argument('--output',type=Path,default=Path('/mnt/data/prism_support_theorem_verification.json'));a=ap.parse_args()
    rows=[audit(m) for m in range(4,a.max_m+1,2)]
    out={'tested_even_m_min':4,'tested_even_m_max':a.max_m,'tested_cases':len(rows),'all_passed':all(r['passed'] for r in rows),'rows':rows}
    a.output.write_text(json.dumps(out,indent=2));print(json.dumps({k:out[k] for k in ['tested_even_m_min','tested_even_m_max','tested_cases','all_passed']},indent=2))
if __name__=='__main__':main()
