#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,sys,time,hashlib
from pathlib import Path
from collections import Counter,defaultdict
sys.path.insert(0,'/mnt/data/barnette_work/barnette_attempt_package')
from audit_hplusminus import load_graph
from audit_all_c4_children import cycle_edges,verify_cycle
from forced_hamiltonian import solve
from fast_lift_complete import fast_audit,ckey

def persist(base,cycles,log,failures,status,outpath,initial,t0):
 out=dict(base);out['certificate_cycles']=cycles;out['certificate_cycle_count']=len(cycles)
 out['global_direct_lift_completion']={'source_certificate':base.get('_src'),'initial_cycles':initial,'final_cycles':len(cycles),'added_cycles':len(cycles)-initial,'status':status,'remaining_failed_moves':len(failures),'remaining_missing_edges':sum(len(f['missing']) for f in failures),'failure_sample':failures[:20],'solver_log':log,'elapsed_seconds':time.time()-t0}
 out.pop('_src',None);outpath.write_text(json.dumps(out,indent=2))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('certificate',type=Path);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--probe-time',type=float,default=8);ap.add_argument('--fallback-time',type=float,default=60);ap.add_argument('--max-additions',type=int,default=100);a=ap.parse_args()
 data=json.loads(a.certificate.read_text());G,g6=load_graph(Path(data['graph']));cycles=list(data['certificate_cycles']);seen={ckey(c) for c in cycles};initial=len(cycles);log=[];t0=time.time();base=dict(data);base['_src']=str(a.certificate)
 for it in range(a.max_additions+1):
  F=fast_audit(G,cycles);print(json.dumps({'iteration':it,'cycles':len(cycles),'failed_moves':len(F),'missing_edges':sum(len(f['missing']) for f in F)}),flush=True);persist(base,cycles,log,F,'complete' if not F else 'running',a.output,initial,t0)
  if not F:break
  found=None;rec={'iteration':it,'attempts':[]}
  # State-only gaps first.
  sf=next((f for f in F if not f['old_missing'] and f['gadget_missing']),None)
  if sf:
   miss=set(sf['gadget_missing']);cand=[]
   for st in ('10','01','11'):
    gain=len(miss & set(map(tuple,sf['patterns'][st])))
    if sf['states'][st]==0 and gain:cand.append((gain,st))
   cand.sort(reverse=True);st=cand[0][1];forced=[];out=[]
   if st=='10':forced=[sf['e1']];out=[sf['e2']]
   elif st=='01':forced=[sf['e2']];out=[sf['e1']]
   else:forced=[sf['e1'],sf['e2']]
   r=solve(G,forced_in=forced,forced_out=out,time_limit=a.fallback_time,max_rounds=10000,seed=1000003*it+sf['move_index'])
   rec.update({'target_type':'state','move_index':sf['move_index'],'state':st});rec['attempts'].append({'forced_in':[list(e) for e in forced],'forced_out':[list(e) for e in out],'status':r.status,'seconds':r.seconds,'rounds':r.rounds,'cuts':r.cuts})
   if r.status=='hamiltonian' and r.cycle:found=r.cycle
  else:
   # Rank missing old edges by how many failed moves they can potentially repair.
   edge_to_fail=defaultdict(list)
   for f in F:
    for g in f['old_missing']:edge_to_fail[g].append(f)
   ranked=sorted(edge_to_fail,key=lambda g:(-len(edge_to_fail[g]),g))
   rec['target_type']='global_old_edge'
   for gi,g in enumerate(ranked):
    # Try pairs containing this gap, low-state/low-index first, both branches.
    fs=sorted(edge_to_fail[g],key=lambda f:(sum(f['states'].values()),f['move_index']))
    for f in fs:
     for branch,e in enumerate((f['e1'],f['e2'])):
      r=solve(G,forced_in=[g,e],time_limit=a.probe_time,max_rounds=4000,seed=1000003*it+1009*f['move_index']+branch+gi*7919)
      rec['attempts'].append({'missing_edge':list(g),'move_index':f['move_index'],'with_edge':list(e),'status':r.status,'seconds':r.seconds,'rounds':r.rounds,'cuts':r.cuts})
      if r.status=='hamiltonian' and r.cycle:
       found=r.cycle;rec.update({'missing_edge':list(g),'move_index':f['move_index'],'with_edge':list(e),'frequency':len(edge_to_fail[g])});break
     if found:break
    if found:break
   if not found and ranked:
    # One longer fallback on the first high-frequency target.
    g=ranked[0];f=edge_to_fail[g][0]
    for branch,e in enumerate((f['e1'],f['e2'])):
     r=solve(G,forced_in=[g,e],time_limit=a.fallback_time,max_rounds=10000,seed=9000001+1000003*it+branch)
     rec['attempts'].append({'missing_edge':list(g),'move_index':f['move_index'],'with_edge':list(e),'status':r.status,'seconds':r.seconds,'rounds':r.rounds,'cuts':r.cuts,'fallback':True})
     if r.status=='hamiltonian' and r.cycle:found=r.cycle;break
  rec['resolved']=found is not None
  if not found:
   log.append(rec);persist(base,cycles,log,F,'unresolved',a.output,initial,t0);break
  if not verify_cycle(G,found):raise AssertionError('invalid')
  k=ckey(found)
  if k in seen:rec['duplicate']=True;log.append(rec);persist(base,cycles,log,F,'stalled_duplicate',a.output,initial,t0);break
  seen.add(k);cycles.append(found);rec['cycle_index']=len(cycles)-1;log.append(rec)
 print(json.dumps({'initial_cycles':initial,'final_cycles':len(cycles),'added':len(cycles)-initial,'status':json.loads(a.output.read_text())['global_direct_lift_completion']['status'],'elapsed':round(time.time()-t0,3)},indent=2))
if __name__=='__main__':main()
