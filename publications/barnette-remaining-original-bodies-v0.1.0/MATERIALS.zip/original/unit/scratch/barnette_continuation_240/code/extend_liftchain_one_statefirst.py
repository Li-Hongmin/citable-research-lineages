#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,subprocess,sys
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--graph',required=True);ap.add_argument('--certificate',required=True);ap.add_argument('--audit',required=True);ap.add_argument('--base',required=True);ap.add_argument('--move',type=int);a=ap.parse_args()
aud=json.load(open(a.audit));move=a.move if a.move is not None else min(aud['entries'],key=lambda e:(e['liftable_cycle_count'],e['move_index']))['move_index']
cmd=[sys.executable,'/mnt/data/build_selected_child.py','--graph',a.graph,'--certificate',a.certificate,'--move',str(move),'--base',a.base]
subprocess.run(cmd,check=True)
g=Path('/mnt/data/'+a.base+'.json');s=Path('/mnt/data/'+a.base+'_seeds.json');sd=json.loads(s.read_text())
seedcert=Path('/mnt/data/'+a.base+'_seed_certificate.json');seedcert.write_text(json.dumps({'graph':str(g),'graph6':sd['graph6'],'vertices':len(json.loads(g.read_text()).get('validation',{})) if False else json.loads(g.read_text())['validation']['vertices'],'scope':'direct_lift_seed_family','certificate_cycle_count':len(sd['cycles']),'certificate_cycles':sd['cycles'],'source_seed_file':str(s)},indent=2))
cert=Path('/mnt/data/'+a.base+'_lift_complete.json');log=Path('/mnt/data/'+a.base+'_augment.log')
with log.open('w') as f:subprocess.run([sys.executable,'/mnt/data/fast_lift_complete_statefirst.py',str(seedcert),'--output',str(cert),'--time-limit','60','--max-additions','120'],stdout=f,stderr=subprocess.STDOUT,check=True)
out=json.loads(cert.read_text());status=out['fast_direct_lift_completion']['status']
if status!='complete':
 print(json.dumps({'base':a.base,'move':move,'status':status,'seed_cycles':len(sd['cycles'])},indent=2));raise SystemExit(2)
fa=Path('/mnt/data/'+a.base+'_fast_audit.json');subprocess.run([sys.executable,'/mnt/data/fast_lift_audit_summary.py',str(cert),'--output',str(fa)],check=True)
A=json.loads(fa.read_text());C=out['fast_direct_lift_completion'];hard=min(A['entries'],key=lambda e:(e['liftable_cycle_count'],e['move_index']))
print(json.dumps({'base':a.base,'move':move,'vertices':A['parent_validation']['vertices'],'seed_cycles':C['initial_cycles'],'final_cycles':C['final_cycles'],'added_cycles':C['added_cycles'],'legal_first_moves':A['legal_first_moves'],'second_moves':A['total_labeled_second_moves_certified_hamiltonian'],'min_liftable':A['liftable_cycle_count_min'],'next_hardest_move':hard['move_index'],'next_hardest_face':hard['face_length'],'next_hardest_states':hard['state_counts'],'graph':str(g),'certificate':str(cert),'audit':str(fa)},indent=2))
