#!/usr/bin/env python3
"""Audit direct lifts of a finite Hamiltonian cycle family through every C4 move."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from statistics import mean

import networkx as nx

from audit_all_c4_children import cycle_edges, lift, verify_cycle
from audit_hplusminus import load_graph
from barnette_c4_attack import c4_expand, undirected_edge, valid_c4_moves


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('certificate', type=Path)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()

    cert = json.loads(args.certificate.read_text())
    G, g6 = load_graph(Path(cert['graph']))
    if g6 != cert['graph6']:
        raise SystemExit('graph mismatch')
    cycles = cert['certificate_cycles']
    parent_sets = [cycle_edges(c) for c in cycles]
    parent_edges = {undirected_edge(u, v) for u, v in G.edges()}
    if set().union(*parent_sets) != parent_edges:
        raise SystemExit('cycle family does not cover parent edges')

    entries = []
    all_direct_edge_hamiltonian = True
    total_second_moves = 0
    for move_index, (face, i, j) in enumerate(valid_c4_moves(G)):
        L = len(face)
        e1 = undirected_edge(face[i], face[(i + 1) % L])
        e2 = undirected_edge(face[j], face[(j + 1) % L])
        child, record = c4_expand(G, face, i, j)
        child_edges = {undirected_edge(u, v) for u, v in child.edges()}
        lifted_cycles = []
        lifted_parent_indices = []
        state_counts = {'10': 0, '01': 0, '11': 0}
        for k, (cycle, E) in enumerate(zip(cycles, parent_sets, strict=True)):
            h1, h2 = e1 in E, e2 in E
            if not (h1 or h2):
                continue
            state_counts[f'{int(h1)}{int(h2)}'] += 1
            lifted = lift(G, child, face, i, j, record, cycle)
            if not verify_cycle(child, lifted):
                raise AssertionError(f'invalid lift at move {move_index}, cycle {k}')
            lifted_cycles.append(lifted)
            lifted_parent_indices.append(k)
        union = set().union(*(cycle_edges(c) for c in lifted_cycles)) if lifted_cycles else set()
        missing = sorted(child_edges - union)
        direct_ok = not missing
        all_direct_edge_hamiltonian &= direct_ok
        second_moves = len(valid_c4_moves(child)) if direct_ok else 0
        total_second_moves += second_moves
        entries.append({
            'move_index': move_index,
            'face_length': L,
            'expanded_edges': [list(e1), list(e2)],
            'liftable_cycle_count': len(lifted_cycles),
            'liftable_parent_cycle_indices': lifted_parent_indices,
            'state_counts': state_counts,
            'child_edges_covered_by_direct_lifts': len(union),
            'child_edges': len(child_edges),
            'missing_child_edges': [list(e) for e in missing],
            'direct_lifts_certify_child_edge_hamiltonian': direct_ok,
            'legal_second_moves_certified_hamiltonian': second_moves,
            'child_graph6_sha256': hashlib.sha256(
                nx.to_graph6_bytes(child, header=False).decode().strip().encode()
            ).hexdigest(),
        })

    failures = [e for e in entries if not e['direct_lifts_certify_child_edge_hamiltonian']]
    payload = {
        'certificate': str(args.certificate),
        'certificate_sha256': hashlib.sha256(args.certificate.read_bytes()).hexdigest(),
        'parent_vertices': len(G),
        'parent_edges': G.number_of_edges(),
        'parent_cycle_count': len(cycles),
        'legal_first_moves': len(entries),
        'first_children_directly_certified_edge_hamiltonian': len(entries) - len(failures),
        'all_first_children_directly_certified_edge_hamiltonian': not failures,
        'failed_move_indices': [e['move_index'] for e in failures],
        'total_labeled_second_moves_certified_hamiltonian': total_second_moves,
        'liftable_cycle_count_min': min(e['liftable_cycle_count'] for e in entries),
        'liftable_cycle_count_max': max(e['liftable_cycle_count'] for e in entries),
        'liftable_cycle_count_mean': mean(e['liftable_cycle_count'] for e in entries),
        'entries': entries,
    }
    args.output.write_text(json.dumps(payload, indent=2))
    print(json.dumps({k: payload[k] for k in [
        'parent_vertices', 'parent_cycle_count', 'legal_first_moves',
        'first_children_directly_certified_edge_hamiltonian',
        'all_first_children_directly_certified_edge_hamiltonian',
        'total_labeled_second_moves_certified_hamiltonian',
        'liftable_cycle_count_min', 'liftable_cycle_count_max',
        'liftable_cycle_count_mean',
    ]}, indent=2))
    if failures:
        print('failure sample:', json.dumps(failures[:10], indent=2))


if __name__ == '__main__':
    main()
