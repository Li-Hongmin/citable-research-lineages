#!/usr/bin/env python3
from __future__ import annotations
import time,json,argparse
from pathlib import Path
from dataclasses import dataclass,asdict
import networkx as nx
import numpy as np
from scipy.optimize import Bounds,LinearConstraint,milp
from scipy.sparse import lil_matrix,vstack

def edge(u,v):return (u,v) if u<v else (v,u)
@dataclass
class Result:
 status:str;rounds:int;cuts:int;seconds:float;cycle:list[int]|None;selected_edges:list[list[int]]|None;solver_status:int;message:str

def solve(G, forced_in=(), forced_out=(), time_limit=120,max_rounds=3000,seed=0):
 nodes=sorted(G);ni={v:i for i,v in enumerate(nodes)};edges=[edge(u,v) for u,v in G.edges()];ei={e:i for i,e in enumerate(edges)};n=len(nodes);m=len(edges)
 forced_in={edge(*e) for e in forced_in};forced_out={edge(*e) for e in forced_out}
 if forced_in&forced_out:return Result('infeasible',0,0,0,None,None,2,'same edge forced both')
 lb=np.zeros(m);ub=np.ones(m)
 for e in forced_in:
  if e not in ei:return Result('infeasible',0,0,0,None,None,2,'forced-in edge absent')
  lb[ei[e]]=1
 for e in forced_out:
  if e not in ei:continue
  ub[ei[e]]=0
 deg=lil_matrix((n,m),dtype=float)
 for k,(u,v) in enumerate(edges):deg[ni[u],k]=1;deg[ni[v],k]=1
 mats=[deg.tocsr()];lbs=[np.full(n,2.)];ubs=[np.full(n,2.)];keys=set();start=time.monotonic();rng=np.random.default_rng(seed);obj=rng.normal(scale=1e-7,size=m)
 for r in range(max_rounds):
  rem=time_limit-(time.monotonic()-start)
  if rem<=0:return Result('unknown',r,len(keys),time.monotonic()-start,None,None,1,'time limit')
  res=milp(obj,integrality=np.ones(m),bounds=Bounds(lb,ub),constraints=LinearConstraint(vstack(mats,format='csr'),np.concatenate(lbs),np.concatenate(ubs)),options={'time_limit':max(.05,rem),'mip_rel_gap':0.,'presolve':True})
  elapsed=time.monotonic()-start
  if res.status==2:return Result('infeasible',r+1,len(keys),elapsed,None,None,int(res.status),str(res.message))
  if not res.success or res.x is None:return Result('unknown',r+1,len(keys),elapsed,None,None,int(res.status),str(res.message))
  chosen=[edges[k] for k,x in enumerate(res.x) if x>.5];F=nx.Graph();F.add_nodes_from(nodes);F.add_edges_from(chosen);comps=list(nx.connected_components(F))
  if len(comps)==1:
   s=nodes[0];cy=[s];prev=None;cur=s
   for _ in range(n-1):
    ns=list(F.neighbors(cur));nxt=ns[0] if ns[0]!=prev else ns[1];cy.append(nxt);prev,cur=cur,nxt
   assert F.has_edge(cur,s)
   return Result('hamiltonian',r+1,len(keys),elapsed,cy,[list(e) for e in chosen],int(res.status),str(res.message))
  added=0;alln=set(nodes)
  for C in comps:
   S=set(C);T=alln-S;a=tuple(sorted(S));b=tuple(sorted(T));key=a if (len(a),a)<=(len(b),b) else b
   if key in keys:continue
   keys.add(key);row=lil_matrix((1,m),dtype=float)
   for e,k in ei.items():
    if (e[0] in S)!=(e[1] in S):row[0,k]=1
   mats.append(row.tocsr());lbs.append(np.array([2.]));ubs.append(np.array([np.inf]));added+=1
  if not added:return Result('unknown',r+1,len(keys),elapsed,None,None,-1,'no new cut')
 return Result('unknown',max_rounds,len(keys),time.monotonic()-start,None,None,1,'round limit')

def load_graph(path):
 d=json.load(open(path));g6=d.get('graph6') or d.get('current_graph6') or d['results'][-1]['graph6'];return nx.from_graph6_bytes(g6.encode())
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('graph');ap.add_argument('--e1',nargs=2,type=int,required=True);ap.add_argument('--e2',nargs=2,type=int,required=True);ap.add_argument('--time-limit',type=float,default=120);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();G=load_graph(a.graph);e1=edge(*a.e1);e2=edge(*a.e2);out={}
 for s1,s2 in [(0,0),(0,1),(1,0),(1,1)]:
  fi=[e for e,s in [(e1,s1),(e2,s2)] if s];fo=[e for e,s in [(e1,s1),(e2,s2)] if not s];r=solve(G,fi,fo,a.time_limit,seed=100*s1+s2);out[f'{s1}{s2}']=asdict(r);print(f'{s1}{s2}',r.status,r.rounds,r.cuts,round(r.seconds,3),flush=True)
 a.output.write_text(json.dumps({'graph':a.graph,'e1':e1,'e2':e2,'states':out},indent=2))
