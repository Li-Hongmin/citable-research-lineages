#!/usr/bin/env python3
"""Exhaustively lift Hamiltonian cycles through every legal C4 expansion.

Input graph must come with a family of Hamiltonian cycles covering every edge.
For each legal C4 move, choose a covering cycle containing at least one removed
edge, apply the explicit local lift, and verify the resulting child cycle.
"""
from __future__ import annotations
import argparse,hashlib,json,sys
from pathlib import Path
from collections import Counter
import networkx as nx
sys.path.insert(0,'/mnt/data')
from barnette_c4_attack import c4_expand,valid_c4_moves,undirected_edge


def cycle_edges(cy):
 return {undirected_edge(cy[i],cy[(i+1)%len(cy)]) for i in range(len(cy))}

def ordered_cycle_from_edges(G,edges):
 H=nx.Graph();H.add_nodes_from(G);H.add_edges_from(edges)
 if any(d!=2 for _,d in H.degree()) or not nx.is_connected(H):raise ValueError('not one 2-regular connected spanning graph')
 s=min(H);cy=[s];prev=None;cur=s
 for _ in range(len(H)-1):
  ns=list(H.neighbors(cur));nxt=ns[0] if ns[0]!=prev else ns[1]
  cy.append(nxt);prev,cur=cur,nxt
 if not H.has_edge(cur,s):raise ValueError('not closed')
 return cy

def lift(parent,child,face,i,j,record,cy):
 L=len(face);u,v=face[i],face[(i+1)%L];x,y=face[j],face[(j+1)%L]
 a,b,c,d=record['new_vertices'];e1=undirected_edge(u,v);e2=undirected_edge(x,y)
 E=cycle_edges(cy);h1=e1 in E;h2=e2 in E
 if not (h1 or h2):raise ValueError('cycle misses both expanded edges')
 E.discard(e1);E.discard(e2)
 if h1 and h2:
  E.update(map(lambda q:undirected_edge(*q),[(u,a),(a,b),(b,v),(x,c),(c,d),(d,y)]))
 elif h1:
  E.update(map(lambda q:undirected_edge(*q),[(u,a),(a,d),(d,c),(c,b),(b,v)]))
 else:
  E.update(map(lambda q:undirected_edge(*q),[(x,c),(c,b),(b,a),(a,d),(d,y)]))
 return ordered_cycle_from_edges(child,E)

def verify_cycle(G,cy):
 return len(cy)==len(G) and len(set(cy))==len(G) and set(cy)==set(G) and all(G.has_edge(cy[k],cy[(k+1)%len(cy)]) for k in range(len(cy)))

def load(args):
 gdata=json.loads(args.graph_json.read_text());sdata=json.loads(args.support_json.read_text())
 g6=gdata.get('current_graph6') or gdata['results'][-1]['graph6'];G=nx.from_graph6_bytes(g6.encode())
 cycles=[r['cycle'] for r in sdata['runs'] if r.get('cycle') and (r.get('uncovered_used') or 0)>0]
 return G,g6,cycles

def main():
 ap=argparse.ArgumentParser();ap.add_argument('graph_json',type=Path);ap.add_argument('support_json',type=Path);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 G,g6,cycles=load(a);CE=[cycle_edges(c) for c in cycles]
 allE={undirected_edge(u,v) for u,v in G.edges()};covered=set().union(*CE)
 if covered!=allE:raise SystemExit(f'cycle family misses {len(allE-covered)} parent edges')
 entries=[];direct_cover_preserving=0;all_structural=True
 for idx,(face,i,j) in enumerate(valid_c4_moves(G)):
  L=len(face);e1=undirected_edge(face[i],face[(i+1)%L]);e2=undirected_edge(face[j],face[(j+1)%L])
  candidates=[k for k,E in enumerate(CE) if e1 in E or e2 in E]
  if not candidates:raise AssertionError('edge cover failed to supply a lift')
  child,rec=c4_expand(G,face,i,j);k=candidates[0];cc=lift(G,child,face,i,j,rec,cycles[k])
  if not verify_cycle(child,cc):raise AssertionError('invalid lifted cycle')
  planar,_=nx.check_planarity(child);struct=(all(d==3 for _,d in child.degree()) and nx.is_bipartite(child) and planar)
  all_structural &= struct
  # Can every member of the parent cover be lifted, and do those lifted cycles cover child edges?
  lifted=[];liftable_all=True
  for pc in cycles:
   try: lifted.append(lift(G,child,face,i,j,rec,pc))
   except ValueError: liftable_all=False;break
  cover_pres=False
  if liftable_all:
   union=set().union(*(cycle_edges(z) for z in lifted));cover_pres=(union=={undirected_edge(u,v) for u,v in child.edges()})
  if cover_pres:direct_cover_preserving+=1
  cg6=nx.to_graph6_bytes(child,header=False).decode().strip()
  entries.append({'move_index':idx,'removed_edges':[list(e1),list(e2)],'face_length':L,'parent_cycle_index':k,'lifted_cycle':cc,'child_graph6':cg6,'structural_ok':struct,'three_cycle_cover_lifts_directly':cover_pres})
 payload={'parent_vertices':len(G),'parent_edges':G.number_of_edges(),'parent_graph6_sha256':hashlib.sha256(g6.encode()).hexdigest(),'covering_cycles':cycles,'legal_moves':len(entries),'all_children_hamiltonian_certified':len(entries),'all_children_basic_structural_ok':all_structural,'moves_preserving_same_three_cycle_cover_by_direct_lifts':direct_cover_preserving,'children':entries}
 a.output.write_text(json.dumps(payload,indent=2))
 print(json.dumps({k:payload[k] for k in ['parent_vertices','legal_moves','all_children_hamiltonian_certified','all_children_basic_structural_ok','moves_preserving_same_three_cycle_cover_by_direct_lifts']},indent=2))
if __name__=='__main__':main()
