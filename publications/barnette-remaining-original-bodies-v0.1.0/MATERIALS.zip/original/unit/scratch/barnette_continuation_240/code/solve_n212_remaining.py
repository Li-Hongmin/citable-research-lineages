import json,sys
from concurrent.futures import ProcessPoolExecutor,as_completed
import networkx as nx
sys.path.insert(0,'/mnt/data/barnette_work/barnette_attempt_package')
from forced_hamiltonian import solve
D=json.load(open('/mnt/data/liftchain_212_hard_lift_complete.json'))
G6=D['graph6']
jobs=[
 ('m1_e1',(2,6),(0,23),101),('m1_e2',(2,6),(78,79),102),
 ('m522_e1',(40,41),(41,120),103),('m522_e2',(40,41),(19,162),104),
]
def one(j):
 name,g,e,seed=j;G=nx.from_graph6_bytes(G6.encode());r=solve(G,forced_in=[g,e],time_limit=180,max_rounds=20000,seed=seed)
 return {'name':name,'g':g,'e':e,'status':r.status,'seconds':r.seconds,'rounds':r.rounds,'cuts':r.cuts,'cycle':r.cycle,'message':r.message}
out=[]
with ProcessPoolExecutor(max_workers=4) as ex:
 fs=[ex.submit(one,j) for j in jobs]
 for f in as_completed(fs):
  r=f.result();out.append(r);print(r['name'],r['status'],r['seconds'],r['rounds'],r['cuts'],flush=True)
json.dump(out,open('/mnt/data/n212_remaining_solves.json','w'),indent=2)
