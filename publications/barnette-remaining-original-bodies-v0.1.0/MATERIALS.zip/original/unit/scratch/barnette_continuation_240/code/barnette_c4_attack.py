#!/usr/bin/env python3
"""Adversarial search against the C4-expansion subproblem of Barnette's conjecture.

Starting from the cube, repeatedly apply the Holton-Manvel-McKay C4-expansion.
At each generation step, sample candidate expansions and favor children whose
random perfect matchings rarely have a connected complementary 2-factor.
Every final candidate is then checked by an exact MILP cutting-plane model for
a Hamiltonian cycle.

This does not prove Barnette's conjecture.  A graph reported as non-Hamiltonian
must have exact_status == "infeasible"; timeouts are never treated as proofs.
"""
from __future__ import annotations

import argparse
import json
import math
import random
import time
from collections import Counter
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Sequence

import networkx as nx
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, linear_sum_assignment, milp
from scipy.sparse import lil_matrix, vstack

Edge = tuple[int, int]


def undirected_edge(u: int, v: int) -> Edge:
    return (u, v) if u < v else (v, u)


def planar_faces(graph: nx.Graph) -> list[list[int]]:
    planar, embedding = nx.check_planarity(graph, counterexample=False)
    if not planar:
        raise ValueError("graph is not planar")
    visited: set[tuple[int, int]] = set()
    faces: list[list[int]] = []
    for u, v in embedding.edges():
        if (u, v) not in visited:
            faces.append(list(embedding.traverse_face(u, v, visited)))
    return faces


def valid_c4_moves(graph: nx.Graph) -> list[tuple[tuple[int, ...], int, int]]:
    """Return face/index triples for all parity-valid C4 expansions.

    If boundary edges have starting indices i<j, their distance in the HMM
    convention is odd exactly when j-i is even.  Adjacent edges are excluded.
    """
    moves: list[tuple[tuple[int, ...], int, int]] = []
    for face_list in planar_faces(graph):
        face = tuple(face_list)
        length = len(face)
        if length < 4 or length % 2:
            continue
        for i in range(length):
            for j in range(i + 1, length):
                e1 = {face[i], face[(i + 1) % length]}
                e2 = {face[j], face[(j + 1) % length]}
                if e1 & e2:
                    continue
                if (j - i) % 2 == 0:
                    moves.append((face, i, j))
    return moves


def c4_expand(
    graph: nx.Graph, face: Sequence[int], i: int, j: int
) -> tuple[nx.Graph, dict[str, object]]:
    """Apply the noncrossing C4 expansion inside the specified face."""
    length = len(face)
    u, v = face[i], face[(i + 1) % length]
    x, y = face[j], face[(j + 1) % length]
    if len({u, v, x, y}) != 4:
        raise ValueError("C4 expansion requires two vertex-disjoint boundary edges")
    if not graph.has_edge(u, v) or not graph.has_edge(x, y):
        raise ValueError("selected boundary edge is absent")

    child = graph.copy()
    next_node = max(child.nodes, default=-1) + 1
    a, b, c, d = range(next_node, next_node + 4)
    child.remove_edge(u, v)
    child.remove_edge(x, y)
    child.add_edges_from(
        [
            (u, a), (a, b), (b, v),
            (x, c), (c, d), (d, y),
            (a, d), (b, c),
        ]
    )
    record = {
        "removed_edges": [list(undirected_edge(u, v)), list(undirected_edge(x, y))],
        "new_vertices": [a, b, c, d],
        "face_length": length,
        "boundary_separation": min((j - i) % length, (i - j) % length),
    }
    return child, record


def validate_barnette_graph(graph: nx.Graph) -> dict[str, object]:
    planar, _ = nx.check_planarity(graph, counterexample=False)
    return {
        "vertices": graph.number_of_nodes(),
        "edges": graph.number_of_edges(),
        "simple": not nx.number_of_selfloops(graph) and not graph.is_multigraph(),
        "cubic": all(deg == 3 for _, deg in graph.degree()),
        "bipartite": nx.is_bipartite(graph),
        "planar": planar,
        "vertex_connectivity": nx.node_connectivity(graph),
        "face_lengths": dict(sorted(Counter(map(len, planar_faces(graph))).items())),
    }


def bipartition(graph: nx.Graph) -> tuple[list[int], list[int]]:
    coloring = nx.bipartite.color(graph)
    left = sorted(v for v, color in coloring.items() if color == 0)
    right = sorted(v for v, color in coloring.items() if color == 1)
    if len(left) != len(right):
        raise ValueError("regular bipartite graph must have equal color classes")
    return left, right


def random_matching_score(
    graph: nx.Graph, samples: int, seed: int
) -> tuple[float, float, int]:
    """Cheap hardness proxy based on random min-cost perfect matchings.

    In a cubic graph, the complement of a perfect matching is a 2-factor.
    A connected complement is a Hamiltonian cycle.
    """
    left, right = bipartition(graph)
    n = len(left)
    right_index = {v: i for i, v in enumerate(right)}
    allowed = np.zeros((n, n), dtype=bool)
    edge_at: list[list[Edge | None]] = [[None] * n for _ in range(n)]
    for i, u in enumerate(left):
        for v in graph.neighbors(u):
            col = right_index[v]
            allowed[i, col] = True
            edge_at[i][col] = undirected_edge(u, v)

    all_edges = {undirected_edge(u, v) for u, v in graph.edges()}
    rng = np.random.default_rng(seed)
    hamiltonian_hits = 0
    component_total = 0
    distinct_cycles: set[tuple[Edge, ...]] = set()

    for _ in range(samples):
        costs = np.where(allowed, rng.random((n, n)), 1.0e9)
        rows, cols = linear_sum_assignment(costs)
        matching: set[Edge] = set()
        for row, col in zip(rows, cols, strict=True):
            edge = edge_at[row][col]
            if edge is None:
                raise RuntimeError("assignment used a forbidden edge")
            matching.add(edge)
        two_factor_edges = all_edges - matching
        two_factor = nx.Graph()
        two_factor.add_nodes_from(graph.nodes())
        two_factor.add_edges_from(two_factor_edges)
        components = nx.number_connected_components(two_factor)
        component_total += components
        if components == 1:
            hamiltonian_hits += 1
            distinct_cycles.add(tuple(sorted(two_factor_edges)))

    return (
        hamiltonian_hits / samples,
        component_total / samples,
        len(distinct_cycles),
    )


@dataclass
class ExactResult:
    exact_status: str
    rounds: int
    cuts: int
    seconds: float
    cycle: list[int] | None
    solver_status: int
    solver_message: str


def exact_hamiltonian_cycle(
    graph: nx.Graph,
    time_limit: float = 20.0,
    max_rounds: int = 500,
    objective_seed: int = 0,
) -> ExactResult:
    """Exact binary MILP with iterative subtour cuts.

    Returns `infeasible` only when HiGHS proves infeasibility.  A time limit or
    round limit is returned as `unknown`, never as a non-Hamiltonicity claim.
    """
    nodes = sorted(graph.nodes())
    node_index = {v: i for i, v in enumerate(nodes)}
    edges = [undirected_edge(u, v) for u, v in graph.edges()]
    edge_index = {edge: i for i, edge in enumerate(edges)}
    n, m = len(nodes), len(edges)

    degree_matrix = lil_matrix((n, m), dtype=float)
    for k, (u, v) in enumerate(edges):
        degree_matrix[node_index[u], k] = 1.0
        degree_matrix[node_index[v], k] = 1.0

    matrices = [degree_matrix.tocsr()]
    lower_bounds = [np.full(n, 2.0)]
    upper_bounds = [np.full(n, 2.0)]
    cut_keys: set[tuple[int, ...]] = set()
    rng = np.random.default_rng(objective_seed)
    objective = rng.normal(scale=1.0e-8, size=m)
    start = time.monotonic()

    for round_index in range(max_rounds):
        elapsed = time.monotonic() - start
        remaining = time_limit - elapsed
        if remaining <= 0:
            return ExactResult(
                "unknown", round_index, len(cut_keys), elapsed, None, 1,
                "time limit before next MILP round",
            )

        matrix = vstack(matrices, format="csr")
        lower = np.concatenate(lower_bounds)
        upper = np.concatenate(upper_bounds)
        result = milp(
            objective,
            integrality=np.ones(m),
            bounds=Bounds(np.zeros(m), np.ones(m)),
            constraints=LinearConstraint(matrix, lower, upper),
            options={
                "time_limit": max(0.05, remaining),
                "mip_rel_gap": 0.0,
                "presolve": True,
            },
        )
        elapsed = time.monotonic() - start

        if result.status == 2:
            return ExactResult(
                "infeasible", round_index + 1, len(cut_keys), elapsed, None,
                int(result.status), str(result.message),
            )
        if not result.success or result.x is None:
            return ExactResult(
                "unknown", round_index + 1, len(cut_keys), elapsed, None,
                int(result.status), str(result.message),
            )

        chosen = [edges[k] for k, value in enumerate(result.x) if value > 0.5]
        two_factor = nx.Graph()
        two_factor.add_nodes_from(nodes)
        two_factor.add_edges_from(chosen)
        components = list(nx.connected_components(two_factor))

        if len(components) == 1:
            start_vertex = nodes[0]
            cycle = [start_vertex]
            previous: int | None = None
            current = start_vertex
            for _ in range(n - 1):
                neighbors = list(two_factor.neighbors(current))
                nxt = neighbors[0] if neighbors[0] != previous else neighbors[1]
                cycle.append(nxt)
                previous, current = current, nxt
            if not two_factor.has_edge(current, start_vertex):
                raise AssertionError("solver output is not a cycle")
            return ExactResult(
                "hamiltonian", round_index + 1, len(cut_keys), elapsed,
                cycle, int(result.status), str(result.message),
            )

        new_cuts = 0
        all_nodes = set(nodes)
        for component in components:
            shore = set(component)
            complement = all_nodes - shore
            a = tuple(sorted(shore))
            b = tuple(sorted(complement))
            key = a if (len(a), a) <= (len(b), b) else b
            if key in cut_keys:
                continue
            cut_keys.add(key)
            row = lil_matrix((1, m), dtype=float)
            for edge, k in edge_index.items():
                u, v = edge
                if (u in shore) != (v in shore):
                    row[0, k] = 1.0
            matrices.append(row.tocsr())
            lower_bounds.append(np.array([2.0]))
            upper_bounds.append(np.array([np.inf]))
            new_cuts += 1

        if new_cuts == 0:
            return ExactResult(
                "unknown", round_index + 1, len(cut_keys), elapsed, None, -1,
                "subtour loop produced no new cut",
            )

    return ExactResult(
        "unknown", max_rounds, len(cut_keys), time.monotonic() - start,
        None, 1, "maximum cutting-plane rounds reached",
    )


@dataclass
class CandidateScore:
    move_index: int
    hit_rate: float
    mean_components: float
    distinct_cycles: int
    exact_rounds: int = -1
    exact_cuts: int = -1
    exact_seconds: float = -1.0


def adversarial_run(
    target_vertices: int,
    seed: int,
    candidate_cap: int,
    proxy_samples: int,
    shortlist_size: int,
    per_child_exact_limit: float,
) -> tuple[nx.Graph, list[dict[str, object]], list[dict[str, object]]]:
    if target_vertices < 8 or (target_vertices - 8) % 4:
        raise ValueError("target vertex count must be 8 mod 4")

    rng = random.Random(seed)
    graph = nx.cubical_graph()
    history: list[dict[str, object]] = []
    diagnostics: list[dict[str, object]] = []

    while graph.number_of_nodes() < target_vertices:
        moves = valid_c4_moves(graph)
        if len(moves) > candidate_cap:
            chosen_indices = sorted(rng.sample(range(len(moves)), candidate_cap))
        else:
            chosen_indices = list(range(len(moves)))

        scored: list[tuple[CandidateScore, nx.Graph, dict[str, object]]] = []
        for local_rank, move_index in enumerate(chosen_indices):
            face, i, j = moves[move_index]
            child, record = c4_expand(graph, face, i, j)
            hit_rate, mean_components, distinct = random_matching_score(
                child, proxy_samples, seed * 1_000_003 + graph.number_of_nodes() * 997 + local_rank
            )
            score = CandidateScore(
                move_index=move_index,
                hit_rate=hit_rate,
                mean_components=mean_components,
                distinct_cycles=distinct,
            )
            scored.append((score, child, record))

        scored.sort(
            key=lambda item: (
                item[0].hit_rate,
                -item[0].mean_components,
                item[0].distinct_cycles,
                -int(item[2]["face_length"]),
            )
        )
        shortlist = scored[: max(1, min(shortlist_size, len(scored)))]

        exact_scored: list[tuple[float, CandidateScore, nx.Graph, dict[str, object]]] = []
        for rank, (score, child, record) in enumerate(shortlist):
            exact = exact_hamiltonian_cycle(
                child,
                time_limit=per_child_exact_limit,
                max_rounds=200,
                objective_seed=seed + graph.number_of_nodes() + rank,
            )
            score.exact_rounds = exact.rounds
            score.exact_cuts = exact.cuts
            score.exact_seconds = exact.seconds
            # Unknown children are retained as maximally interesting, but are
            # never labelled non-Hamiltonian.  Among solved children, prefer
            # many rounds/cuts and low proxy hit rate.
            unknown_bonus = 1_000_000.0 if exact.exact_status == "unknown" else 0.0
            hardness = (
                unknown_bonus
                + 10.0 * exact.rounds
                + exact.cuts
                + 0.1 * score.mean_components
                - 100.0 * score.hit_rate
            )
            exact_scored.append((hardness, score, child, record))

        exact_scored.sort(key=lambda item: item[0], reverse=True)
        _, winning_score, graph, winning_record = exact_scored[0]
        history.append(winning_record)
        diagnostics.append(
            {
                "vertices": graph.number_of_nodes(),
                **asdict(winning_score),
                "available_moves": len(moves),
                "sampled_moves": len(chosen_indices),
            }
        )

    return graph, history, diagnostics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", type=int, default=92)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--runs", type=int, default=1)
    parser.add_argument("--candidate-cap", type=int, default=80)
    parser.add_argument("--proxy-samples", type=int, default=24)
    parser.add_argument("--shortlist", type=int, default=5)
    parser.add_argument("--child-time-limit", type=float, default=2.0)
    parser.add_argument("--final-time-limit", type=float, default=60.0)
    parser.add_argument("--output", type=Path, default=Path("barnette_c4_results.json"))
    args = parser.parse_args()

    results: list[dict[str, object]] = []
    for run in range(args.runs):
        run_seed = args.seed + run * 10_007
        started = time.monotonic()
        graph, history, diagnostics = adversarial_run(
            target_vertices=args.target,
            seed=run_seed,
            candidate_cap=args.candidate_cap,
            proxy_samples=args.proxy_samples,
            shortlist_size=args.shortlist,
            per_child_exact_limit=args.child_time_limit,
        )
        validation = validate_barnette_graph(graph)
        exact = exact_hamiltonian_cycle(
            graph,
            time_limit=args.final_time_limit,
            max_rounds=1000,
            objective_seed=run_seed + 999_983,
        )
        result = {
            "run": run,
            "seed": run_seed,
            "construction_seconds": time.monotonic() - started,
            "validation": validation,
            "graph6": nx.to_graph6_bytes(graph, header=False).decode().strip(),
            "expansions": history,
            "diagnostics": diagnostics,
            "exact": asdict(exact),
        }
        results.append(result)
        print(
            json.dumps(
                {
                    "run": run,
                    "seed": run_seed,
                    "vertices": validation["vertices"],
                    "faces": validation["face_lengths"],
                    "exact_status": exact.exact_status,
                    "rounds": exact.rounds,
                    "cuts": exact.cuts,
                    "seconds": round(exact.seconds, 3),
                },
                ensure_ascii=False,
            ),
            flush=True,
        )

    payload = {
        "problem": "Barnette conjecture: C4-expansion-only subproblem",
        "warning": (
            "Only exact_status='infeasible' is a proof of non-Hamiltonicity. "
            "Status 'unknown' is not a counterexample."
        ),
        "parameters": vars(args) | {"output": str(args.output)},
        "results": results,
    }
    args.output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
