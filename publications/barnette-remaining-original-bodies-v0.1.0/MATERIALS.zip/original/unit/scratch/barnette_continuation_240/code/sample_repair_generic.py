from __future__ import annotations
import argparse,json,sys
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import networkx as nx
sys.path.insert(0,'/mnt/data')
sys.path.insert(0,'/mnt/data/barnette_work/barnette_attempt_package')
from sample_hamiltonian_mcmc import sample,cycle_edges
from fast_lift_complete import fast_audit,patterns
from barnette_c4_attack import valid_c4_moves,c4_expand,undirected_edge
from audit_all_c4_children import verify_cycle
ap=argparse.ArgumentParser();ap.add_argument('certificate');ap.add_argument('--steps',type=int,default=3000);ap.add_argument('--workers',type=int,default=8);ap.add_argument('--output',required=True);ap.add_argument('--patched',required=True);a=ap.parse_args()
D=json.load(open(a.certificate));G6=D['graph6'];base=list(D['certificate_cycles']);G=nx.from_graph6_bytes(G6.encode());failures=fast_audit(G,base)
print('initial',len(base),'failures',len(failures),'missing',sum(len(f['missing']) for f in failures),flush=True)
def worker(arg):
 k,cy=arg;g=nx.from_graph6_bytes(G6.encode());Cs,st=sample(g,cy,steps=a.steps,seed=24000000+1000003*k,accept_nonham=True);return k,[sorted(C) for C in Cs],dict(st)
cand={};stats=[]
with ProcessPoolExecutor(max_workers=min(a.workers,len(base))) as ex:
 fs=[ex.submit(worker,(k,c)) for k,c in enumerate(base)]
 for f in as_completed(fs):
  k,Cs,st=f.result();stats.append({'start':k,'generated':len(Cs),'stats':st});print('sample',k,len(Cs),flush=True)
  for C in Cs:cand[frozenset(tuple(e) for e in C)]=None
basekeys={frozenset(cycle_edges(c)) for c in base}
for k in list(cand):
 if k in basekeys:del cand[k]
print('unique candidates',len(cand),flush=True)
moves=valid_c4_moves(G);fail_by={f['move_index']:f for f in failures};universe={(idx,tuple(e)) for idx,f in fail_by.items() for e in f['missing']};mi={}
for idx,f in fail_by.items():
 face,i,j=moves[idx];H,rec=c4_expand(G,face,i,j);L=len(face);e1=undirected_edge(face[i],face[(i+1)%L]);e2=undirected_edge(face[j],face[(j+1)%L]);mi[idx]=(e1,e2,patterns(face,i,j,rec))
def cov(E):
 out=set()
 for idx,f in fail_by.items():
  e1,e2,p=mi[idx];h1=e1 in E;h2=e2 in E
  if not(h1 or h2):continue
  st=f'{int(h1)}{int(h2)}';L=(set(E)-{e1,e2})|p[st]
  for e in f['missing']:
   e=tuple(e)
   if e in L:out.add((idx,e))
 return out
C={E:cov(set(E)) for E in cand};C={E:s for E,s in C.items() if s};uncovered=set(universe);chosen=[]
while uncovered:
 best=None;gain=0
 for E,s in C.items():
  q=len(s&uncovered)
  if q>gain:best=E;gain=q
 if best is None or gain==0:break
 chosen.append(best);uncovered-=C[best];del C[best];print('greedy',len(chosen),'gain',gain,'remaining',len(uncovered),flush=True)
def order(E):
 H=nx.Graph();H.add_nodes_from(G);H.add_edges_from(E);assert nx.is_connected(H) and all(d==2 for _,d in H.degree());s=min(H);o=[s];pr=None;cu=s
 for _ in range(len(H)-1):
  ns=list(H.neighbors(cu));nxv=ns[0] if ns[0]!=pr else ns[1];o.append(nxv);pr,cu=cu,nxv
 assert H.has_edge(cu,s);return o
added=[order(set(E)) for E in chosen];assert all(verify_cycle(G,c) for c in added);allc=base+added;final=fast_audit(G,allc)
payload={'steps_per_seed':a.steps,'seed_cycles':len(base),'sample_stats':stats,'unique_sampled_candidates':len(cand),'initial_failures':len(failures),'initial_missing':len(universe),'greedy_added':len(added),'universe_uncovered_by_greedy':[[i,list(e)] for i,e in sorted(uncovered)],'final_failures':len(final),'final_missing':sum(len(f['missing']) for f in final),'added_cycles':added,'failure_sample':final[:20]}
json.dump(payload,open(a.output,'w'),indent=2);print(json.dumps({k:v for k,v in payload.items() if k not in ('sample_stats','added_cycles','failure_sample','universe_uncovered_by_greedy')},indent=2),flush=True)
D['certificate_cycles']=allc;D['certificate_cycle_count']=len(allc);D['sample_repair_summary']={k:v for k,v in payload.items() if k not in ('sample_stats','added_cycles','failure_sample','universe_uncovered_by_greedy')};json.dump(D,open(a.patched,'w'),indent=2)
