#!/usr/bin/env python3
import argparse,json,sys,hashlib
from pathlib import Path
import networkx as nx
sys.path.insert(0,'/mnt/data/barnette_work/barnette_attempt_package')
from barnette_c4_attack import valid_c4_moves,c4_expand,validate_barnette_graph,undirected_edge
from audit_all_c4_children import lift,cycle_edges,verify_cycle
ap=argparse.ArgumentParser();ap.add_argument('--graph',required=True);ap.add_argument('--certificate',required=True);ap.add_argument('--move',type=int,required=True);ap.add_argument('--base',required=True);a=ap.parse_args()
gd=json.load(open(a.graph));g6=gd.get('graph6') or gd.get('child_graph6') or gd.get('current_graph6');G=nx.from_graph6_bytes(g6.encode())
cert=json.load(open(a.certificate));cycles=cert['certificate_cycles'];face,i,j=valid_c4_moves(G)[a.move];H,rec=c4_expand(G,face,i,j);L=len(face);e1=undirected_edge(face[i],face[(i+1)%L]);e2=undirected_edge(face[j],face[(j+1)%L]);lifted=[];src=[]
for k,c in enumerate(cycles):
 E=cycle_edges(c)
 if e1 in E or e2 in E:
  cc=lift(G,H,face,i,j,rec,c);assert verify_cycle(H,cc);lifted.append(cc);src.append(k)
hg6=nx.to_graph6_bytes(H,header=False).decode().strip();gp=Path('/mnt/data/'+a.base+'.json');sp=Path('/mnt/data/'+a.base+'_seeds.json')
gp.write_text(json.dumps({'source_graph':a.graph,'source_certificate':a.certificate,'parent_move_index':a.move,'move':{'face':list(face),'i':i,'j':j},'expanded_edges':[list(e1),list(e2)],'record':rec,'graph6':hg6,'graph6_sha256':hashlib.sha256(hg6.encode()).hexdigest(),'validation':validate_barnette_graph(H)},indent=2))
sp.write_text(json.dumps({'graph':str(gp),'graph6':hg6,'source_parent_certificate':a.certificate,'move_index':a.move,'expanded_edges':[list(e1),list(e2)],'lifted_parent_cycle_indices':src,'cycles':lifted,'cycle_count':len(lifted)},indent=2))
print(json.dumps({'graph':str(gp),'seeds':str(sp),'vertices':len(H),'expanded_edges':[list(e1),list(e2)],'seed_cycles':len(lifted),'validation':validate_barnette_graph(H)},indent=2))
