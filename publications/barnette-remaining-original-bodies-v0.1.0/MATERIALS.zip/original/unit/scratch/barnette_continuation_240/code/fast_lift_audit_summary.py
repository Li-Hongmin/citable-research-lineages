#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,hashlib,sys,time
from pathlib import Path
from statistics import mean
import networkx as nx
sys.path.insert(0,'/mnt/data/barnette_work/barnette_attempt_package')
from audit_hplusminus import load_graph
from audit_all_c4_children import cycle_edges,verify_cycle
from barnette_c4_attack import valid_c4_moves,c4_expand,undirected_edge,validate_barnette_graph

def pats(face,i,j,rec):
 L=len(face);u,v=face[i],face[(i+1)%L];x,y=face[j],face[(j+1)%L];a,b,c,d=rec['new_vertices'];ue=undirected_edge
 return {
 '11':{ue(*z) for z in [(u,a),(a,b),(b,v),(x,c),(c,d),(d,y)]},
 '10':{ue(*z) for z in [(u,a),(a,d),(d,c),(c,b),(b,v)]},
 '01':{ue(*z) for z in [(x,c),(c,b),(b,a),(a,d),(d,y)]},
 }

def main():
 ap=argparse.ArgumentParser();ap.add_argument('certificate',type=Path);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();t=time.time()
 d=json.loads(a.certificate.read_text());G,g6=load_graph(Path(d['graph']));C=d['certificate_cycles']
 if g6!=d['graph6']:raise SystemExit('graph mismatch')
 for k,c in enumerate(C):
  if not verify_cycle(G,c):raise SystemExit(f'invalid parent cycle {k}')
 CE=[cycle_edges(c) for c in C];GE={undirected_edge(u,v) for u,v in G.edges()}
 if set().union(*CE)!=GE:raise SystemExit('parent edges not covered')
 entries=[];total2=0
 for idx,(face,i,j) in enumerate(valid_c4_moves(G)):
  L=len(face);e1=undirected_edge(face[i],face[(i+1)%L]);e2=undirected_edge(face[j],face[(j+1)%L]);H,rec=c4_expand(G,face,i,j);P=pats(face,i,j,rec);U=set();states={'10':0,'01':0,'11':0};n=0
  for E in CE:
   h1=e1 in E;h2=e2 in E
   if not(h1 or h2):continue
   st=f'{int(h1)}{int(h2)}';states[st]+=1;n+=1;U|=(E-{e1,e2})|P[st]
  HE={undirected_edge(u,v) for u,v in H.edges()};missing=sorted(HE-U);ok=not missing;nm2=len(valid_c4_moves(H)) if ok else 0;total2+=nm2
  entries.append({'move_index':idx,'face_length':L,'expanded_edges':[list(e1),list(e2)],'liftable_cycle_count':n,'state_counts':states,'child_edges_covered':len(U),'child_edges':len(HE),'missing_child_edges':[list(e) for e in missing],'direct_ok':ok,'legal_second_moves':nm2})
 fails=[e for e in entries if not e['direct_ok']];vals=[e['liftable_cycle_count'] for e in entries]
 out={'certificate':str(a.certificate),'certificate_sha256':hashlib.sha256(a.certificate.read_bytes()).hexdigest(),'graph6_sha256':hashlib.sha256(g6.encode()).hexdigest(),'parent_validation':validate_barnette_graph(G),'parent_cycle_count':len(C),'legal_first_moves':len(entries),'first_children_directly_certified_edge_hamiltonian':len(entries)-len(fails),'all_first_children_directly_certified_edge_hamiltonian':not fails,'failed_move_indices':[e['move_index'] for e in fails],'total_labeled_second_moves_certified_hamiltonian':total2,'liftable_cycle_count_min':min(vals),'liftable_cycle_count_max':max(vals),'liftable_cycle_count_mean':mean(vals),'hardest_moves':sorted(entries,key=lambda e:(e['liftable_cycle_count'],e['move_index']))[:20],'entries':entries,'elapsed_seconds':time.time()-t}
 a.output.write_text(json.dumps(out,indent=2));print(json.dumps({k:out[k] for k in ['parent_validation','parent_cycle_count','legal_first_moves','first_children_directly_certified_edge_hamiltonian','all_first_children_directly_certified_edge_hamiltonian','total_labeled_second_moves_certified_hamiltonian','liftable_cycle_count_min','liftable_cycle_count_max','liftable_cycle_count_mean','elapsed_seconds']},indent=2))
if __name__=='__main__':main()
