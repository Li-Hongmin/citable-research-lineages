# Diwan specified-chord 不强制 ordered Hamilton root passage

## 精确结论

Diwan 的 Theorems 1、2、3、5，无论按原陈述作为黑箱，还是按 Theorem 3 的
specified-chord 辅助构造及其平面对偶使用，都**不能推出** Note 067 的 universal
ordered-Hamilton 命题

\[
\forall(F,r,s)\ \exists y\in Y\setminus\{r\}\ \exists
\text{ Hamilton }a\text{--}y\text{ path passing through }b-r-s.
\tag{OH}
\]

Theorem 3 的平面 chord-splitting 实际上已经强制了正确的**局部路径配对**；
缺失的不是根处左右次序，而是含指定 chord 的 2-factor 分量是否 spanning。
原证明明确保留 “the cycles other than \(C\) ... (if any)”。要由该构造推出
(OH)，必须把 Theorem 1 加强为：在 Theorem 3 的辅助图中，指定 chord 是一个
**Hamilton cycle** 的 chord。这个加强在原图中恰给出含 \(rs\) 的 matching，其
补 2-factor 恰有两个分离 \(r,s\) 的圈，即 RCA/\(\mu_F(rs)=2\)；它比 direct
target 更强，且仍未解决。

因此本轮结论是有范围的路线关闭，不是 (OH) 的真实反例。

## 原文量词核对

核对来源为 Diwan, *Chords of 2-factors in planar cubic bridgeless graphs*,
arXiv:2110.12584v1（arXiv 当前只有 v1；journal reference:
*Graphs and Combinatorics* 38, 177 (2022), DOI
10.1007/s00373-022-02583-y）。检索与全文核对日期为 2026-08-26。

### Theorem 1

输入是一个 2-edge-connected planar cubic graph \(G\) 和一条不在
2-edge-cut 中的指定边 \(g\)。输出量词只有

\[
\exists\text{ 2-factor }D\ \exists C\in\operatorname{comp}(D):
g\text{ is a chord of }C.
\tag{1}
\]

它没有断言 \(C\) 包含 \(D\) 的其他分量，更没有断言 \(C\) spanning。

### Theorem 2（Theorem 1 的精确平面对偶）

可以任取 triangulation 的外面并给其边界定向标号
\(v_1,v_2,v_3\)。定理给一个 special 3-colouring，边界颜色为 \(abc\)，
且唯一 \(ab\)-pair 是 \(v_1v_2\)。这精确编码“指定 dual edge 是某个
2-factor 圈的 chord”，但 special 的定义没有：

- monochromatic-edge graph 的 spanning-tree/cycle-rank 条件；
- 消除 chord cycle 之外其他 2-factor cycles 的条件；
- direct target 所需的一个 load-two free face \(\tau_y\)。

所以选择外面、顺逆时针或交换颜色只能选择指定 chord 及局部两侧，不能选择
Hamiltonicity。

### Theorem 3

对满足其假设的指定边 \(uv\)，定理构造含 \(uv\) 的 separating perfect
matching。令

\[
N(u)\setminus\{v\}=\{u_1,u_2\},\qquad
N(v)\setminus\{u\}=\{v_1,v_2\},
\]

其中 \(u_1,u,v,v_1\) 与 \(u_2,u,v,v_2\) 分别沿 \(uv\) 两侧共面。证明从
\(G-\{u,v\}\) 加入 \(u',v'\)，使

\[
N(u')=\{u_1,v_1,v'\},\qquad
N(v')=\{u_2,v_2,u'\},
\]

并对 chord \(u'v'\) 调用 Theorem 1。若 \(C\) 是含该 chord 两端的
2-factor cycle，planarity 确实强制

\[
C-\{u',v'\}=P_{u_1u_2}\sqcup P_{v_1v_2}.
\tag{2}
\]

这一步正是所需的局部 pairing；不存在未决的 cross pairing。把 \(u,v\) 放回后，
两条路径闭成分别含 \(u\) 与 \(v\) 的两个圈。但原证明随即把

> the cycles other than \(C\) in the 2-factor of \(G'\) (if any)

原样加入输出。故输出只保证根端分圈，不保证总圈数为二。

### Theorem 5

Theorem 5 的量词为：任意两条指定边 \(e_1,e_2\) 同属某个 2-factor cycle。
取 \(e_1=rb,e_2=rs\) 可以强制局部子路 \(b-r-s\)，但该 cycle 仍可不是
spanning，且其他 cycles 不受控制。若改用两个槽位处理其他圈，根边状态又不再
保留。原文最后也只提出进一步研究“含两指定边的 2-factors”，没有
Hamilton-cycle 结论。

## 精确缺失加强

把 Theorem 3 用于根边 \(rs\)，并按其两侧面序令

\[
\{u_1,u_2\}=\{a,b\},\qquad
\{v_1,v_2\}=N(s)\setminus\{r\}.
\]

若能把 (1) 加强为

\[
\tag{SC-H}
\text{辅助边 }u'v'\text{ 是一个 Hamilton cycle }C\text{ 的 chord},
\]

则 (2) 覆盖辅助图的全部旧顶点。放回 \(r,s\) 后恰得到两个 spanning
factor cycles：一个经 \(a-r-b\)，另一个经 \(s\)。删去 \(r\)，再删去
\(s\)-圈上一条 incident edge \(sy\)，便得到

\[
Q_{ab}\sqcup Q_{sy}.
\]

等价地，把两路接上 \(b-r-s\) 得到 Note 067 的
\(a\)-到-\(y\) Hamilton 路，按正确次序穿过 \(b-r-s\)。

但 (SC-H) 在原图中正等价于存在 perfect matching \(M\ni rs\)，使
\(F-M\) 恰有两个圈且分别含 \(r,s\)。这就是

\[
\mu_F(rs)=2,
\]

即 RCA/Note 063 的更强 matching-completable 分支。Note 058 只证明
\(\mathcal S_{rs}\ne\varnothing\)，没有证明其最小圈数为二。

一般 direct witness 甚至未必有 matching completion，因此不能反过来由
(OH) 推出 (SC-H)。所以 (SC-H) 是足够而非必要加强；把它作为 Diwan 构造的
“隐藏结论”会循环假设一个更强的开放命题。

## 真实 plane-brace 中 “if any” 确实发生

取 Note 064 的 12 点 simple plane cubic bipartite brace
（graph6 为 "K??FEagT@WB_"），并取根边

\[
rs=(0,7).
\]

下面是一个 perfect matching：

\[
\begin{split}
M=\{&(0,7),(1,6),(2,10),\\
     &(3,11),(4,8),(5,9)\}.
\end{split}
\tag{3}
\]

其补 2-factor 是三个 \(C_4\)：

\[
\begin{aligned}
&(0,6,2,8),\qquad (1,7,3,9),\\
&(4,10,5,11).
\end{aligned}
\tag{4}
\]

因此 \(M\ni 0\,7\)，且 \(0,7\) 分圈，但该 separated factor 有三圈。

按 Theorem 3 构造辅助图：沿 \(0\,7\) 两侧取

\[
u_1=6,\quad u_2=8,\quad v_1=1,\quad v_2=3,
\]

加入 \(u'=12,v'=13\) 与边

\[
12\,13,\ 12\,6,\ 12\,1,\ 13\,8,\ 13\,3.
\]

(4) 中前两个根圈去掉 \(0,7\) 后，与四条 connector 合成一个长度 8 的
cycle，且 \(12\,13\) 是它的 chord；另一个 \(C_4\) 原样保留。于是辅助
2-factor 的分量大小为

\[
(8,4).
\tag{5}
\]

这完全满足 Theorem 1 的 specified-chord 结论和 Theorem 2 的 special-colouring
对偶条件，却不产生 spanning chord cycle。它证明 brace 假设不会从定理的现有
输出公理中自动删除 “if any”。

该根边一共有 4 个 separated matchings，补因子圈数分布为

\[
c=2:3,\qquad c=3:1.
\tag{6}
\]

所以这个实例不是 RCA 或 (OH) 反例：good witnesses 也存在。它精确说明原定理
没有选择机制区分 (6) 中的 good 与 bad outputs；若要选择 \(c=2\)，必须新增
一个控制全局 cycle count 的归纳不变量。

## 结论边界

- **精确结论：** Diwan 构造强制正确局部 root pairing，但不强制 spanning；
  Theorems 1/2/3/5 均不能推出 (OH)。
- **最弱承重步骤：** 从“原构造不能推出”到“未来任何 Diwan 风格加强都不能”
  之间没有推论。本结果只关闭现有定理量词、special-colouring invariant 和
  任取其 witness 的路线；不排除加入新的全局 induction invariant。
- **证据等级：** 原定理陈述与证明为全文核对；量词缺口为解析证明级；(3)--(6)
  是真实 plane brace 上的逐项有限证书。不是 universal target 的反例。
- **未决边界：** 是否存在能在 Diwan induction 中同时保持 special boundary
  coloring 与 spanning/cycle-rank potential 的加强仍未知；这至少要解决
  (SC-H)/RCA，或改用允许一个 free-face load-two defect 的更弱 direct-dual
  invariant。
