"""Independent stdlib checks of the two specified prism instances only.

No project/generated checker is imported; perfect matchings are streamed.
Run from the unit directory: python3 -B scratch/pro-nonlocal-independent-check.py
"""

from collections import Counter, deque
from itertools import combinations, permutations
import json
import resource
import sys
import time


def edge(v, w):
    return tuple(sorted((v, w)))


def path_edges(vertices, closed=False):
    vertices = list(vertices)
    return {edge(v, w) for v, w in zip(
        vertices, vertices[1:] + (vertices[:1] if closed else []))}


def adjacency(n, edges):
    adj = [set() for _ in range(n)]
    for v, w in edges:
        assert 0 <= v < w < n
        adj[v].add(w)
        adj[w].add(v)
    return adj


def components(adj, vertices):
    unseen = set(vertices)
    result = []
    while unseen:
        start = unseen.pop()
        seen, stack = {start}, [start]
        while stack:
            v = stack.pop()
            for w in adj[v] & unseen:
                unseen.remove(w)
                seen.add(w)
                stack.append(w)
        result.append(seen)
    return result


def check_graph(n, edges, faces):
    adj = adjacency(n, edges)
    assert all(len(neighbours) == 3 for neighbours in adj)
    colour, queue = {0: 0}, deque([0])
    while queue:
        v = queue.popleft()
        for w in adj[v]:
            if w not in colour:
                colour[w] = 1 - colour[v]
                queue.append(w)
            assert colour[w] != colour[v]
    assert len(colour) == n
    for size in range(3):
        for cut in combinations(range(n), size):
            assert len(components(adj, set(range(n)) - set(cut))) == 1
    # Oriented faces, cyclic vertex links and Euler characteristic certify S^2.
    darts, rotations = Counter(), [dict() for _ in range(n)]
    for face in faces:
        assert len(face) == len(set(face)) >= 4
        for i, v in enumerate(face):
            previous, following = face[i - 1], face[(i + 1) % len(face)]
            darts[v, following] += 1
            assert previous not in rotations[v]
            rotations[v][previous] = following
    assert darts == Counter((v, w) for v in range(n) for w in adj[v])
    for v in range(n):
        start = current = min(adj[v])
        visited = set()
        while current not in visited:
            visited.add(current)
            current = rotations[v][current]
        assert current == start and visited == adj[v]
    assert n - len(edges) + len(faces) == 2
    return colour


def check_site(site, faces, colour):
    u, v, x, y = site
    assert len(set(site)) == 4 and colour[u] == colour[x]
    for face in faces:
        for direction in (face, list(reversed(face))):
            if u not in direction:
                continue
            i = direction.index(u)
            ordered = direction[i:] + direction[:i]
            if ordered[1] == v and x in ordered:
                j = ordered.index(x)
                if j + 1 < len(ordered) and ordered[j + 1] == y:
                    lengths = (j - 1, len(ordered) - j - 1)
                    assert all(length > 0 and length % 2 for length in lengths)
                    return lengths
    raise AssertionError(("nonfacial site", site))


def prism(top, bottom):
    edges = path_edges(top, True) | path_edges(bottom, True)
    edges |= {edge(v, w) for v, w in zip(top, bottom)}
    faces = [list(top), list(reversed(bottom))]
    for i in range(len(top)):
        j = (i + 1) % len(top)
        faces.append([top[j], top[i], bottom[i], bottom[j]])
    return edges, faces


def expand(edges, site, n):
    u, v, x, y = site
    a, b, c, d = range(n, n + 4)
    seals = {edge(u, v), edge(x, y)}
    born = path_edges([u, a, b, v]) | path_edges([x, c, d, y])
    born |= {edge(a, d), edge(b, c)}
    assert seals <= edges and not (born & edges) and len(born) == 8
    child = (edges - seals) | born
    assert (child - born) | seals == edges  # Recorded inverse.
    return child, born, seals


def check_ledger(edges, births, cap):
    assert cap <= edges
    owned = [birth & edges - cap for birth in births] + [cap]
    assert set().union(*owned) == edges
    assert sum(map(len, owned)) == len(edges)


def build_history(r):
    top, bottom = list(range(4)), list(range(4, 8))
    edges, faces = prism(top, bottom)
    assert edges == {edge(v, w) for v, w in [
        (0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6),
        (6, 7), (7, 4), (0, 4), (1, 5), (2, 6), (3, 7)]}
    births, sites = [set(edges)], []
    while len(top) < 4 * r:
        n = 2 * len(top)
        colour = check_graph(n, edges, faces)
        site = (top[-1], top[0], bottom[0], bottom[-1])
        assert check_site(site, faces, colour) == (1, 1)
        child, born, deleted = expand(edges, site, n)
        assert deleted <= set().union(*births)
        births.append(born)
        sites.append(site)
        top += [n, n + 1]
        bottom += [n + 3, n + 2]
        edges, faces = prism(top, bottom)
        assert edges == child
    n = 8 * r
    colour = check_graph(n, edges, faces)
    site = (top[1], top[2], top[2 * r + 1], top[2 * r + 2])
    assert check_site(site, faces, colour) == (2 * r - 1,) * 2
    child, born, seals = expand(edges, site, n)
    check_ledger(edges, births, seals)
    a, b, c, d = range(n, n + 4)
    u, v, x, y = site
    new_faces = [[a, b, c, d], [b] + top[2:2 * r + 2] + [c],
                 [d] + top[2 * r + 2:] + top[:2] + [a]]
    replacement = {(u, v): [a, b], (v, u): [b, a],
                   (x, y): [c, d], (y, x): [d, c]}
    for face in faces[1:]:
        revised = []
        for z, w in zip(face, face[1:] + face[:1]):
            revised.append(z)
            revised.extend(replacement.get((z, w), []))
        new_faces.append(revised)
    child_colour = check_graph(n + 4, child, new_faces)
    assert check_site((b, c, d, a), new_faces, child_colour) == (1, 1)
    check_ledger(child, births + [born], {edge(b, c), edge(d, a)})
    sites.append(site)
    return top, bottom, edges, child, site, seals, sites


def perfect_matchings(n, edges, removed=()):
    adj = adjacency(n, edges)
    available = ((1 << n) - 1) ^ sum(1 << v for v in removed)
    chosen = []

    def visit(left):
        if not left:
            yield frozenset(chosen)
            return
        v = (left & -left).bit_length() - 1
        for w in sorted(adj[v]):
            if left & (1 << w):
                chosen.append(edge(v, w))
                yield from visit(left ^ (1 << v) ^ (1 << w))
                chosen.pop()

    yield from visit(available)


def hamilton(n, edges):
    cycles, count = set(), 0
    for matching in perfect_matchings(n, edges):
        count += 1
        cycle = frozenset(edges - matching)
        adj = adjacency(n, cycle)
        assert all(len(neighbours) == 2 for neighbours in adj)
        if len(components(adj, range(n))) == 1:
            cycles.add(cycle)
    return cycles, count


def path_family(n, retained, removed, expected_pairs):
    result = set()
    for matching in perfect_matchings(n, retained, removed):
        witness = frozenset(retained - matching)
        adj = adjacency(n, witness)
        assert all(1 <= len(neighbours) <= 2 for neighbours in adj)
        parts = components(adj, range(n))
        pairs = {frozenset(v for v in part if len(adj[v]) == 1)
                 for part in parts}
        if len(parts) == len(expected_pairs) and pairs == expected_pairs:
            result.add(witness)
    return result


def check(r):
    top, bottom, parent, child, site, seals, sites = build_history(r)
    m, n = 4 * r, 8 * r
    u, v, x, y = site
    a, b, c, d = range(n, n + 4)
    p, q = edge(u, v), edge(x, y)
    e, f = edge(top[0], bottom[0]), edge(top[3], top[4])
    retained = parent - seals
    matching = {edge(top[i], top[(i + 1) % m]) for i in range(1, m, 2)}
    matching |= {edge(bottom[i], bottom[(i + 1) % m]) for i in range(0, m, 2)}
    old_cycle = frozenset(parent - matching)
    parent_cycles, parent_pm = hamilton(n, parent)
    child_cycles, child_pm = hamilton(n + 4, child)
    rims = path_edges(top, True) | path_edges(bottom, True)
    expected = {old_cycle, frozenset(parent - (rims - matching))}
    for i in range(m):
        j = (i + 1) % m
        expected.add(frozenset((rims - {edge(top[i], top[j]),
            edge(bottom[i], bottom[j])}) | {edge(top[i], bottom[i]),
            edge(top[j], bottom[j])}))
    assert parent_cycles == expected and len(expected) == m + 2
    for required, forbidden in permutations(parent, 2):
        assert any(required in cycle and forbidden not in cycle for cycle in parent_cycles)
    parent_joint = {cycle for cycle in parent_cycles if e in cycle and f not in cycle}
    child_joint = {cycle for cycle in child_cycles if e in cycle and f not in cycle}
    assert parent_joint == {old_cycle} and not (old_cycle & seals)

    explicit = [top[2], top[3], bottom[3], bottom[2], bottom[1], top[1], top[0], bottom[0]]
    for j in range(m - 1, 2 * r + 2, -2):
        explicit += [bottom[j], top[j], top[j - 1], bottom[j - 1]]
    explicit += [bottom[i] for i in range(2 * r + 1, 3, -1)]
    explicit += top[4:2 * r + 2] + [c, d, a, b]
    assert len(explicit) == len(set(explicit)) == n + 4
    explicit_edges = frozenset(path_edges(explicit, True))
    assert explicit_edges in child_joint
    if r == 2:
        assert sites == [(3, 0, 4, 7), (9, 0, 4, 10), (1, 2, 9, 12)]
        assert explicit == [2, 3, 7, 6, 5, 1, 0, 4, 14, 13, 12, 15, 10, 11, 8, 9, 18, 19, 16, 17]
        assert path_edges([0, 1, 5, 6, 2, 3, 7, 11, 8, 9, 10, 15, 12, 13, 14, 4], True) == old_cycle

    adj = adjacency(n, parent)
    distance, queue = {z: 0 for z in site}, deque(site)
    while queue:
        z = queue.popleft()
        for w in adj[z]:
            if w not in distance:
                distance[w] = distance[z] + 1
                queue.append(w)
    column = {z: i for row in (top, bottom) for i, z in enumerate(row)}
    colour_x = set(top[::2]) | set(bottom[1::2])
    counts, radii, path_counts = [], [], []
    for cycle in child_cycles:
        difference = old_cycle ^ (cycle & retained)
        assert difference == (matching - seals) ^ ((child - cycle) & retained)
        counts.append(len(difference))
        radii.append(max(min(distance[z], distance[w]) for z, w in difference))
        diff_adj = adjacency(n, difference)
        paths = 0
        for part in components(diff_adj, range(n)):
            ends = [z for z in part if len(diff_adj[z]) == 1]
            if not ends:
                continue
            assert len(ends) == 2 and set(ends) <= set(site)
            start, = set(ends) & colour_x
            finish, = set(ends) - colour_x
            order, previous, current = [start], None, start
            while current != finish:
                following, = diff_adj[current] - {previous}
                in_matching = edge(current, following) in matching
                assert (current not in colour_x) == in_matching
                order.append(following)
                previous, current = current, following
            horizontal = [(column[z], column[w]) for z, w in zip(order, order[1:])
                          if column[z] != column[w]]
            assert all(j == (i + 1) % m for i, j in horizontal)
            assert len(horizontal) >= 2 * r - 1
            middle = r + 1 if start == v else 3 * r + 1
            assert (middle % m, (middle + 1) % m) in horizontal
            paths += 1
        assert paths >= 1
        path_counts.append(paths)
    assert min(counts) >= 2 * r - 1 and min(radii) >= r - 1

    patches = {
        "A": path_edges([u, a, b, v]) | path_edges([x, c, d, y]),
        "B": path_edges([u, a, d, c, b, v]),
        "C": path_edges([x, c, b, a, d, y]),
        "D": path_edges([x, c, d, a, b, v]),
        "E": path_edges([u, a, b, c, d, y]),
        "L": {edge(u, a), edge(v, b), edge(x, c), edge(y, d), edge(a, d), edge(b, c)},
    }
    families = {
        "D": path_family(n, retained, (u, y), {frozenset((v, x))}),
        "E": path_family(n, retained, (v, x), {frozenset((u, y))}),
        "L": path_family(n, retained, (), {frozenset((u, v)), frozenset((x, y))}),
    }
    lifted = {frozenset(witness | patches[role]) for role, family in families.items()
              for witness in family}
    for cycle in parent_cycles:
        if cycle & seals:
            role = "A" if seals <= cycle else "B" if p in cycle else "C"
            lifted.add(frozenset((cycle - seals) | patches[role]))
    assert lifted == child_cycles  # Independent exterior enumeration, all six types.
    hard_pairs = 0
    for required, forbidden in permutations(retained, 2):
        old = {cycle for cycle in parent_cycles if required in cycle and forbidden not in cycle}
        if old and all(not (cycle & seals) for cycle in old):
            hard_pairs += 1
            actual = {cycle for cycle in child_cycles if required in cycle and forbidden not in cycle}
            reduced = {frozenset(witness | patches[role]) for role, family in families.items()
                       for witness in family if required in witness and forbidden not in witness}
            assert actual == reduced
    return {
        "r": r, "orders": [n, n + 4], "history_expansions": len(sites),
        "perfect_matchings": [parent_pm, child_pm],
        "hamilton_cycles": [len(parent_cycles), len(child_cycles)],
        "joint_cycles": [len(parent_joint), len(child_joint)],
        "min_changed_old_edges_all_child_cycles": min(counts),
        "min_max_edge_distance_all_child_cycles": min(radii),
        "alternating_path_counts": sorted(set(path_counts)),
        "DEL_families": {role: len(family) for role, family in families.items()},
        "DEL_joint_families": {role: sum(e in witness and f not in witness for witness in family)
                               for role, family in families.items()},
        "hard_ordered_pairs_checked": hard_pairs,
        "explicit_cycle_changed_old_edges": len(old_cycle ^ (explicit_edges & retained)),
    }


if __name__ == "__main__":
    started = time.perf_counter()
    for parameter in (2, 3):
        print(json.dumps(check(parameter), sort_keys=True), flush=True)
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    print(json.dumps({"python": sys.version.split()[0],
                      "elapsed_seconds": round(time.perf_counter() - started, 3),
                      "max_rss_mib": round(rss / (2 ** 20 if sys.platform == "darwin" else 1024), 2)}))
    print("INDEPENDENT_NONLOCAL_PRISM_CHECK_PASSED")
