# Fixed-fibre uniform point: minimal cube counterexample

Let $F$ be the frozen cube with graph6 string `G?zTb_`, use the stored
labelling

\[
\begin{aligned}
E(F)=\{&04,05,06,14,15,17,24,26,27,35,36,37\},\\
X&=\{4,5,6,7\},\qquad Y=\{0,1,2,3\}.
\end{aligned}
\]

Take $r=0$, so $T=(4,5,6)$, and fix

\[
\pi_0=\{\{0\},\{1,2\}\},
\]

meaning that the component containing port $4$ contains neither port
$5$ nor port $6$.  Exact enumeration gives six forests in this fibre.
For all six,

\[
\boxed{
  \mathbf 1_J(14)+\mathbf 1_J(15)+\mathbf 1_J(17)
 +\mathbf 1_J(24)+\mathbf 1_J(26)+\mathbf 1_J(27)\le3.}
\tag{1}
\]

The six left sides are $3,3,2,3,3,2$.  The proposed uniform point has
weights $1/2$ on $14,15,24,26$ and $2/3$ on $17,27$, so its left
side is

\[
4\left(\frac12\right)+2\left(\frac23\right)=\frac{10}{3}>3.
\tag{2}
\]

Thus

\[
x\notin\operatorname{conv}\{\mathbf1_J:J\in\mathcal F_0\}.
\]

This is minimum order among simple cubic bipartite braces.  The only
order-six candidate is $K_{3,3}$; after deleting any root, every fixed
fibre has two representatives obtained by swapping the two surviving
$Y$-vertices, and their half-half average is exactly the uniform
$1/2$ point.  The cube is the next possible order and is a brace.

## Graphic--partition distinction

The same $x$ does lie in the graphic-forest/partition-matroid relaxation.
This can be certified without relying only on rank inequalities:

* the degree-constrained two-component face has 18 legitimate
  $1\mid2$ forests (six in each fixed fibre) and six hidden
  $0\mid3$ forests having a component with no port;
* the uniform average of the six hidden forests equals $x$, so hidden
  components genuinely lie in the relaxation and can widen it;
* hidden components are not needed for this counterexample: $x$ is also
  the exact convex combination with coefficients
  $1/6,1/3,1/3,1/6$ of

  \[
  \begin{aligned}
  &\{14,15,17,27,36\},&&\pi_2,\\
  &\{14,17,26,35,37\},&&\pi_2,\\
  &\{15,24,27,36,37\},&&\pi_1,\\
  &\{17,24,26,27,35\},&&\pi_1.
  \end{aligned}
  \]

Hence the decisive loss here is already the omission of the **fixed**
terminal partition: mixing the other two legal fibres recovers $x$.
Allowing a no-port component is a separate additional widening.

## Boundary

The universal fixed-fibre membership claim is false.  Inequality (1) is an
exact rational separating certificate in the minimum brace.  No conclusion
is obtained about a modified point depending on $i$, or about a smaller
polyhedral relaxation that explicitly enforces one terminal partition.

The exact verifier is `verify_cube_fixed_pi_uniform_counterexample.py` in
this directory.  Its terminal marker is
`CUBE_FIXED_PI_UNIFORM_COUNTEREXAMPLE_VERIFIED`.
