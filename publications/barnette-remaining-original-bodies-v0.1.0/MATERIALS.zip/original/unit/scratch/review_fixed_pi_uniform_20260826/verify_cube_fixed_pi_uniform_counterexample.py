#!/usr/bin/env python3
"""Exact certificate for the fixed-port-partition uniform-point failure.

The graph is the frozen cube.  All arithmetic in the convex decompositions
and separating inequality is rational; NetworkX is used only for elementary
graph predicates and component classification.
"""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations, product

import networkx as nx


GRAPH6 = "G?zTb_"
ROOT = 0
Edge = tuple[int, int]


def edge(a: int, b: int) -> Edge:
    return (a, b) if a < b else (b, a)


def is_two_extendable(graph: nx.Graph) -> bool:
    edges = tuple(graph.edges())
    for index, (a, b) in enumerate(edges):
        for c, d in edges[index + 1 :]:
            if len({a, b, c, d}) != 4:
                continue
            remainder = graph.copy()
            remainder.remove_nodes_from((a, b, c, d))
            matching = nx.max_weight_matching(remainder, maxcardinality=True)
            if 2 * len(matching) != len(remainder):
                return False
    return True


def exact_average(
    forests: tuple[frozenset[Edge], ...], weights: tuple[Fraction, ...], edges: tuple[Edge, ...]
) -> dict[Edge, Fraction]:
    assert len(forests) == len(weights) and sum(weights) == 1
    return {
        e: sum((weight for forest, weight in zip(forests, weights) if e in forest), Fraction())
        for e in edges
    }


def verify_smaller_k33() -> None:
    """The unique order-six simple cubic bipartite graph is not a counterexample."""
    graph = nx.complete_bipartite_graph(3, 3)
    assert is_two_extendable(graph)
    root = 3
    x_side = (0, 1, 2)
    y_side = (4, 5)
    edges = tuple(sorted(edge(x, y) for x in x_side for y in y_side))
    target = {e: Fraction(1, 2) for e in edges}
    for singleton in x_side:
        pair = tuple(x for x in x_side if x != singleton)
        representatives = (
            frozenset({edge(singleton, y_side[0]), *(edge(x, y_side[1]) for x in pair)}),
            frozenset({edge(singleton, y_side[1]), *(edge(x, y_side[0]) for x in pair)}),
        )
        assert exact_average(
            representatives, (Fraction(1, 2), Fraction(1, 2)), edges
        ) == target


def main() -> None:
    verify_smaller_k33()
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert not graph.is_multigraph()
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.is_bipartite(graph)
    assert nx.node_connectivity(graph) == 3
    assert is_two_extendable(graph)

    colour = nx.bipartite.color(graph)
    y_side = {v for v in graph if colour[v] == colour[ROOT]}
    x_side = set(graph) - y_side
    ports = tuple(sorted(graph[ROOT]))
    vertices = tuple(sorted(set(graph) - {ROOT}))
    pole = graph.subgraph(vertices)
    edges = tuple(sorted(edge(a, b) for a, b in pole.edges()))

    local_choices = []
    for x in sorted(x_side):
        required_degree = 1 if x in ports else 2
        incident = tuple(sorted(edge(x, y) for y in pole[x]))
        local_choices.append(tuple(frozenset(choice) for choice in combinations(incident, required_degree)))

    fibres: list[list[frozenset[Edge]]] = [[], [], []]
    hidden: list[frozenset[Edge]] = []
    for selection in product(*local_choices):
        forest = frozenset().union(*selection)
        subgraph = nx.Graph()
        subgraph.add_nodes_from(vertices)
        subgraph.add_edges_from(forest)
        if not nx.is_forest(subgraph) or nx.number_connected_components(subgraph) != 2:
            continue
        components = tuple(frozenset(component) for component in nx.connected_components(subgraph))
        port_blocks = tuple(
            frozenset(i for i, port in enumerate(ports) if port in component)
            for component in components
        )
        if any(not block for block in port_blocks):
            hidden.append(forest)
            continue
        singleton = tuple(block for block in port_blocks if len(block) == 1)
        assert len(singleton) == 1
        fibres[next(iter(singleton[0]))].append(forest)

    assert tuple(len(fibre) for fibre in fibres) == (6, 6, 6)
    assert len(hidden) == 6

    target = {
        e: Fraction(1, 2)
        if next(v for v in e if v in x_side) in ports
        else Fraction(2, 3)
        for e in edges
    }

    # Exact separation of the fixed fibre pi_0={0}|{1,2}.
    separating_edges = frozenset(
        e for e in edges if 1 in e or 2 in e
    )
    fibre_loads = tuple(sum(e in forest for e in separating_edges) for forest in fibres[0])
    target_load = sum(target[e] for e in separating_edges)
    assert max(fibre_loads) == 3
    assert target_load == Fraction(10, 3) > 3

    # The hidden-component distinction is real: the average of the six
    # (0|3)-type forests is already the target point.
    hidden_average = exact_average(
        tuple(hidden), tuple(Fraction(1, 6) for _ in hidden), edges
    )
    assert hidden_average == target

    # Hidden components are not needed for this particular failure.  The
    # target is also an exact mixture of four legitimate forests from the
    # other two fixed terminal partitions.
    legal_forests = (
        frozenset({(1, 4), (1, 5), (1, 7), (2, 7), (3, 6)}),
        frozenset({(1, 4), (1, 7), (2, 6), (3, 5), (3, 7)}),
        frozenset({(1, 5), (2, 4), (2, 7), (3, 6), (3, 7)}),
        frozenset({(1, 7), (2, 4), (2, 6), (2, 7), (3, 5)}),
    )
    legal_weights = (Fraction(1, 6), Fraction(1, 3), Fraction(1, 3), Fraction(1, 6))
    assert legal_forests[0] in fibres[2] and legal_forests[1] in fibres[2]
    assert legal_forests[2] in fibres[1] and legal_forests[3] in fibres[1]
    assert exact_average(legal_forests, legal_weights, edges) == target

    # Hence target is in the graphic-forest/partition-matroid relaxation.
    # Direct equalities record the partition face used here.
    assert sum(target.values()) == 5
    for x in x_side:
        expected = Fraction(1 if x in ports else 2)
        assert sum(target[e] for e in edges if x in e) == expected

    print("graph6", GRAPH6)
    print("root", ROOT)
    print("X", tuple(sorted(x_side)))
    print("Y", tuple(sorted(y_side)))
    print("ports", ports)
    print("fibre_sizes", tuple(len(fibre) for fibre in fibres))
    print("hidden_size", len(hidden))
    print("separator_edges", tuple(sorted(separating_edges)))
    print("fibre_pi0_loads", fibre_loads)
    print("target_load", target_load)
    print("order6_K33_all_fixed_fibres", "MEMBER")
    print("CUBE_FIXED_PI_UNIFORM_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
