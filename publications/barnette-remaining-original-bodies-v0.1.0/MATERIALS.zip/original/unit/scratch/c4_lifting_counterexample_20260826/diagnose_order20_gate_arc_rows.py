#!/usr/bin/env python3
"""Exact gate/arc/local-row diagnostics on the accepted order-20 corpus."""

from __future__ import annotations

import argparse
from collections import Counter
import importlib.util
from itertools import product
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
RUN_DIR = Path(__file__).resolve().parent
ORDER20_DRIVER = RUN_DIR / "census_c4_lifting_order20.py"


def load_driver():
    specification = importlib.util.spec_from_file_location(
        "barnette_order20_c4_lifting_driver", ORDER20_DRIVER
    )
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


driver = load_driver()
lift = driver.lift_bundle
source = driver.source_bundle


def alternating(arc: tuple[int, ...], colour: dict[int, int]) -> bool:
    return all(
        colour[first] != colour[second]
        for first, second in zip(arc, arc[1:], strict=False)
    )


def colouring_record(colour: dict[int, int]) -> dict[str, list[int]]:
    return {
        "zero_vertices": sorted(vertex for vertex, value in colour.items() if value == 0),
        "one_vertices": sorted(vertex for vertex, value in colour.items() if value == 1),
    }


def increment(counter: dict[str, int], key: str, amount: int = 1) -> None:
    counter[key] = counter.get(key, 0) + amount


def census(certificate: dict[str, object]) -> dict[str, object]:
    accepted = certificate["coverage"]
    assert isinstance(accepted, dict)
    assert accepted["admissible_4connected_splits"] == 258
    assert accepted["surviving_root_interfaces"] == 6108
    assert accepted["reduced_target_interface_colourings"] == 35108
    assert accepted["local_assignments_tested"] == 280864
    assert accepted["target_extensions_found"] == 40760
    graph6_values = certificate["brace_graph6"]
    assert isinstance(graph6_values, list) and len(graph6_values) == 5

    totals: dict[str, int] = {
        "braces": 0,
        "admissible_splits": 0,
        "interfaces": 0,
        "interfaces_with_at_most_one_gate_target": 0,
        "interfaces_with_all_targets_using_both_gates": 0,
        "targets_at_interfaces": 0,
        "local_assignments_tested": 0,
        "successful_local_assignments": 0,
        "all_both_interface_targets": 0,
        "all_both_interfaces_all_targets_arc_type_11": 0,
        "all_both_interfaces_with_a_non11_target": 0,
    }
    arc_type_counts: Counter[str] = Counter()
    successful_row_counts: Counter[str] = Counter()
    all_both_successful_row_counts: Counter[str] = Counter()
    per_brace: list[dict[str, object]] = []
    first_all_both_interface = None
    first_non11_all_both_target = None
    first_new_all_both_successful_row = None
    through18_rows = {"011", "101", "110"}

    for graph6 in graph6_values:
        assert isinstance(graph6, str)
        primal = nx.from_graph6_bytes(graph6.encode())
        planar, embedding = nx.check_planarity(primal, counterexample=True)
        assert planar and isinstance(embedding, nx.PlanarEmbedding)
        primal_faces = source.plane_faces(primal, embedding)
        reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
        reduced_faces = lift.verify_reduced_triangulation(reduced)
        families, _nae_count, _shape_count = lift.target_families(reduced, reduced_faces)
        reduced_vertices = tuple(sorted(reduced))

        graph_counts: dict[str, object] = {
            "source_graph6": graph6,
            "admissible_splits": 0,
            "interfaces": 0,
            "interfaces_with_at_most_one_gate_target": 0,
            "interfaces_with_all_targets_using_both_gates": 0,
            "targets_at_interfaces": 0,
            "local_assignments_tested": 0,
            "successful_local_assignments": 0,
            "all_both_interface_targets": 0,
            "all_both_interfaces_all_targets_arc_type_11": 0,
            "all_both_interfaces_with_a_non11_target": 0,
        }
        graph_arc_types: Counter[str] = Counter()
        graph_rows: Counter[str] = Counter()
        graph_all_both_rows: Counter[str] = Counter()

        for z in sorted(reduced):
            rotation = rotations[z]
            for first_index, second_index, first_gate, second_gate in lift.gate_pairs(
                rotation
            ):
                left_size = second_index - first_index + 1
                right_size = len(rotation) - (second_index - first_index) + 1
                if left_size % 2 == 0 or right_size % 2 == 0:
                    continue
                expanded, locals_, left_arc, right_arc = lift.split_vertex(
                    reduced, z, rotation, first_index, second_index
                )
                expanded_faces = lift.expanded_triangulation_faces(expanded)
                if expanded_faces is None:
                    continue
                increment(totals, "admissible_splits")
                increment(graph_counts, "admissible_splits")

                surviving_roots = tuple(
                    sorted(
                        root
                        for root in (lift.edge(*item) for item in reduced.edges())
                        if z not in root
                    )
                )
                for root in surviving_roots:
                    family = families.get(root, [])
                    if not family:
                        continue
                    increment(totals, "interfaces")
                    increment(graph_counts, "interfaces")
                    increment(totals, "targets_at_interfaces", len(family))
                    increment(graph_counts, "targets_at_interfaces", len(family))

                    decoded_family = [
                        lift.decode_colouring(reduced_vertices, encoded)
                        for encoded in family
                    ]
                    uses_both = [
                        colour[first_gate] == colour[z]
                        and colour[second_gate] == colour[z]
                        for colour in decoded_family
                    ]
                    all_both = all(uses_both)
                    if all_both:
                        increment(totals, "interfaces_with_all_targets_using_both_gates")
                        increment(
                            graph_counts,
                            "interfaces_with_all_targets_using_both_gates",
                        )
                    else:
                        increment(totals, "interfaces_with_at_most_one_gate_target")
                        increment(
                            graph_counts,
                            "interfaces_with_at_most_one_gate_target",
                        )

                    capture_all_both = all_both and first_all_both_interface is None
                    captured_targets: list[dict[str, object]] = []
                    interface_all_arc_11 = True
                    interface_successes = 0
                    for target_index, reduced_colour in enumerate(decoded_family):
                        captured_target = None
                        if all_both:
                            arc_type = (
                                f"{int(alternating(left_arc, reduced_colour))}"
                                f"{int(alternating(right_arc, reduced_colour))}"
                            )
                            arc_type_counts[arc_type] += 1
                            graph_arc_types[arc_type] += 1
                            increment(totals, "all_both_interface_targets")
                            increment(graph_counts, "all_both_interface_targets")
                            if arc_type != "11":
                                interface_all_arc_11 = False
                                if first_non11_all_both_target is None:
                                    first_non11_all_both_target = {
                                        "source_graph6": graph6,
                                        "split_vertex": z,
                                        "rotation": rotation,
                                        "gate_indices": (first_index, second_index),
                                        "gates": (first_gate, second_gate),
                                        "left_arc": left_arc,
                                        "right_arc": right_arc,
                                        "root": root,
                                        "target_index": target_index,
                                        "target_family_size": len(decoded_family),
                                        "gate_usage": (True, True),
                                        "arc_type": arc_type,
                                        **colouring_record(reduced_colour),
                                    }
                            if capture_all_both:
                                captured_target = {
                                    "target_index": target_index,
                                    "gate_usage": (True, True),
                                    "arc_type": arc_type,
                                    "successful_relative_rows": [],
                                    **colouring_record(reduced_colour),
                                }

                        fixed = {
                            vertex: value
                            for vertex, value in reduced_colour.items()
                            if vertex != z
                        }
                        for bits in product((0, 1), repeat=3):
                            increment(totals, "local_assignments_tested")
                            increment(graph_counts, "local_assignments_tested")
                            lifted = {
                                **fixed,
                                **dict(zip(locals_, bits, strict=True)),
                            }
                            profile = lift.rooted_profile(
                                expanded, expanded_faces, lifted, root
                            )
                            if not lift.is_target_profile(profile):
                                continue
                            interface_successes += 1
                            increment(totals, "successful_local_assignments")
                            increment(graph_counts, "successful_local_assignments")
                            relative = tuple(bit ^ reduced_colour[z] for bit in bits)
                            row = "".join(map(str, relative))
                            successful_row_counts[row] += 1
                            graph_rows[row] += 1
                            if all_both:
                                all_both_successful_row_counts[row] += 1
                                graph_all_both_rows[row] += 1
                                if captured_target is not None:
                                    captured_target["successful_relative_rows"].append(row)
                            if (
                                all_both
                                and row not in through18_rows
                                and first_new_all_both_successful_row is None
                            ):
                                first_new_all_both_successful_row = {
                                    "source_graph6": graph6,
                                    "split_vertex": z,
                                    "rotation": rotation,
                                    "gate_indices": (first_index, second_index),
                                    "gates": (first_gate, second_gate),
                                    "left_arc": left_arc,
                                    "right_arc": right_arc,
                                    "root": root,
                                    "target_index": target_index,
                                    "target_family_size": len(decoded_family),
                                    "absolute_assignment_left_right_centre": bits,
                                    "relative_row_lambda_rho_d": row,
                                    "profile": {
                                        "nae": profile[0],
                                        "components": profile[1],
                                        "cycle_rank": profile[2],
                                        "root_on_cycle": profile[3],
                                    },
                                    **colouring_record(reduced_colour),
                                }
                        if captured_target is not None:
                            captured_targets.append(captured_target)
                    assert interface_successes > 0
                    if all_both:
                        key = (
                            "all_both_interfaces_all_targets_arc_type_11"
                            if interface_all_arc_11
                            else "all_both_interfaces_with_a_non11_target"
                        )
                        increment(totals, key)
                        increment(graph_counts, key)
                        if capture_all_both:
                            first_all_both_interface = {
                                "source_graph6": graph6,
                                "split_vertex": z,
                                "rotation": rotation,
                                "gate_indices": (first_index, second_index),
                                "gates": (first_gate, second_gate),
                                "left_arc": left_arc,
                                "right_arc": right_arc,
                                "root": root,
                                "complete_target_family_size": len(decoded_family),
                                "complete_target_family": captured_targets,
                                "total_successful_local_assignments": interface_successes,
                            }

        graph_counts["all_both_target_arc_type_counts"] = dict(
            sorted(graph_arc_types.items())
        )
        graph_counts["successful_relative_row_counts"] = dict(
            sorted(graph_rows.items())
        )
        graph_counts["all_both_successful_relative_row_counts"] = dict(
            sorted(graph_all_both_rows.items())
        )
        per_brace.append(graph_counts)
        totals["braces"] += 1
        print(json.dumps(graph_counts, sort_keys=True), flush=True)

    assert totals["admissible_splits"] == accepted["admissible_4connected_splits"]
    assert totals["interfaces"] == accepted["nonempty_antecedent_interfaces"]
    assert totals["targets_at_interfaces"] == accepted[
        "reduced_target_interface_colourings"
    ]
    assert totals["local_assignments_tested"] == accepted["local_assignments_tested"]
    assert totals["successful_local_assignments"] == accepted[
        "target_extensions_found"
    ]
    assert (
        totals["interfaces_with_at_most_one_gate_target"]
        + totals["interfaces_with_all_targets_using_both_gates"]
        == totals["interfaces"]
    )
    assert (
        totals["all_both_interfaces_all_targets_arc_type_11"]
        + totals["all_both_interfaces_with_a_non11_target"]
        == totals["interfaces_with_all_targets_using_both_gates"]
    )

    return {
        "scope": {
            "order": 20,
            "brace_graphs": len(graph6_values),
            "comparison_through18": {
                "all_both_interfaces": 114,
                "all_both_target_arc_type_set": ["11"],
                "successful_relative_row_set": ["011", "101", "110"],
            },
        },
        "coverage": totals,
        "all_both_target_arc_type_counts": dict(sorted(arc_type_counts.items())),
        "successful_relative_row_counts": dict(
            sorted(successful_row_counts.items())
        ),
        "all_both_successful_relative_row_counts": dict(
            sorted(all_both_successful_row_counts.items())
        ),
        "successful_relative_row_set": sorted(successful_row_counts),
        "all_both_successful_relative_row_set": sorted(
            all_both_successful_row_counts
        ),
        "per_brace": per_brace,
        "first_all_both_interface": first_all_both_interface,
        "first_non11_all_both_target": first_non11_all_both_target,
        "first_all_both_successful_row_outside_through18_set": (
            first_new_all_both_successful_row
        ),
        "conclusion": {
            "at_most_one_gate_selection": (
                "Counted exactly by interfaces_with_at_most_one_gate_target; its complement "
                "is the complete-family all-both class."
            ),
            "all_both_arc_statement": (
                "The first_non11 record is null exactly when every target in every all-both "
                "interface has both closed gate arcs alternating."
            ),
            "successful_rows_all_interfaces": sorted(successful_row_counts),
            "successful_rows_conditioned_on_all_both": sorted(
                all_both_successful_row_counts
            ),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "certificate",
        type=Path,
        nargs="?",
        default=RUN_DIR / "c4_lifting_order20_census.json",
    )
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    payload = census(json.loads(arguments.certificate.read_text()))
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
        print("certificate", arguments.output)
    print(json.dumps(payload["coverage"], sort_keys=True))
    print(
        json.dumps(
            {
                "all_both_target_arc_type_counts": payload[
                    "all_both_target_arc_type_counts"
                ],
                "successful_relative_row_counts": payload[
                    "successful_relative_row_counts"
                ],
                "successful_relative_row_set": payload[
                    "successful_relative_row_set"
                ],
                "first_non11_all_both_target": payload[
                    "first_non11_all_both_target"
                ],
                "first_all_both_interface": payload["first_all_both_interface"],
                "all_both_successful_relative_row_counts": payload[
                    "all_both_successful_relative_row_counts"
                ],
                "all_both_successful_relative_row_set": payload[
                    "all_both_successful_relative_row_set"
                ],
                "first_all_both_successful_row_outside_through18_set": payload[
                    "first_all_both_successful_row_outside_through18_set"
                ],
            },
            sort_keys=True,
        )
    )
    print("ORDER20_GATE_ARC_ROW_DIAGNOSTIC_COMPLETE")


if __name__ == "__main__":
    main()
