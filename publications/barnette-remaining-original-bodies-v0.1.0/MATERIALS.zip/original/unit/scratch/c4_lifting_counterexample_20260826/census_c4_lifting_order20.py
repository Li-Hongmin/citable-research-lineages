#!/usr/bin/env python3
"""Stream the complete order-20 brace corpus and test existence-level C4 lifts.

The finite-state and embedding routines are imported read-only from the
accepted Note 064 and Note 066 proof bundles.  This driver adds exactly one
new source order.  It holds one generated graph, one split, and one colouring
at a time, and stops immediately after freezing a genuine existence-level
failure.
"""

from __future__ import annotations

import argparse
import importlib.util
from itertools import product
import json
from pathlib import Path
import subprocess
import sys
from typing import Iterator

import networkx as nx


ORDER = 20
EXPECTED_RAW_COUNT = 703

sys.dont_write_bytecode = True
UNIT_DIR = Path(__file__).resolve().parents[2]
SOURCE_BUNDLE = (
    UNIT_DIR
    / "computations"
    / "bundles"
    / "planar-two-path-through18"
    / "census_planar_brace_two_paths_through18.py"
)
LIFT_BUNDLE = (
    UNIT_DIR
    / "computations"
    / "bundles"
    / "locked-boundary-escape-through18"
    / "census_locked_escape_through18.py"
)


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


source_bundle = load_module(SOURCE_BUNDLE, "barnette_planar_two_path_bundle")
lift_bundle = load_module(LIFT_BUNDLE, "barnette_locked_escape_bundle")


def generated_graphs() -> Iterator[tuple[str, nx.Graph]]:
    process = subprocess.Popen(
        ("geng", "-cqb", "-d3", "-D3", str(ORDER)),
        stdout=subprocess.PIPE,
        text=True,
    )
    assert process.stdout is not None
    completed = False
    try:
        for line in process.stdout:
            graph6 = line.strip()
            if graph6:
                yield graph6, nx.from_graph6_bytes(graph6.encode())
        assert process.wait() == 0
        completed = True
    finally:
        if not completed and process.poll() is None:
            process.terminate()
            process.wait()


def graph_census(
    source_graph6: str,
    primal: nx.Graph,
    primal_faces: tuple[tuple[int, ...], ...],
) -> tuple[dict[str, object], dict[str, object] | None]:
    reduced, rotations = lift_bundle.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift_bundle.verify_reduced_triangulation(reduced)
    families, nae_count, target_shape_count = lift_bundle.target_families(
        reduced, reduced_faces
    )
    reduced_vertices = tuple(sorted(reduced))

    record: dict[str, object] = {
        "source_order": ORDER,
        "source_graph6": source_graph6,
        "dual_vertices": reduced.number_of_nodes(),
        "colour_classes_mod_complement": 1 << (reduced.number_of_nodes() - 1),
        "nae_colourings_mod_complement": nae_count,
        "target_shape_colourings_mod_complement": target_shape_count,
        "root_target_pairs_mod_complement": sum(map(len, families.values())),
        "nonconsecutive_gate_pairs": 0,
        "odd_arc_gate_pairs": 0,
        "simple_eulerian_plane_triangulation_splits": 0,
        "admissible_4connected_splits": 0,
        "surviving_root_interfaces": 0,
        "nonempty_antecedent_interfaces": 0,
        "reduced_target_interface_colourings": 0,
        "local_assignments_tested": 0,
        "target_extensions_found": 0,
        "interfaces_with_an_extension": 0,
        "existence_failures": 0,
    }

    for z in sorted(reduced):
        rotation = rotations[z]
        for first_index, second_index, first_gate, second_gate in lift_bundle.gate_pairs(
            rotation
        ):
            record["nonconsecutive_gate_pairs"] += 1
            left_size = second_index - first_index + 1
            right_size = len(rotation) - (second_index - first_index) + 1
            if left_size % 2 == 0 or right_size % 2 == 0:
                continue
            record["odd_arc_gate_pairs"] += 1

            expanded, locals_, left_arc, right_arc = lift_bundle.split_vertex(
                reduced, z, rotation, first_index, second_index
            )
            if nx.number_of_selfloops(expanded):
                continue
            if any(degree % 2 for _, degree in expanded.degree()):
                continue
            planar, _ = nx.check_planarity(expanded)
            if not planar:
                continue
            pre_faces = lift_bundle.plane_faces(expanded)
            if any(len(face) != 3 for face in pre_faces):
                continue
            record["simple_eulerian_plane_triangulation_splits"] += 1

            expanded_faces = lift_bundle.expanded_triangulation_faces(expanded)
            if expanded_faces is None:
                continue
            record["admissible_4connected_splits"] += 1

            surviving_roots = tuple(
                sorted(
                    root
                    for root in (lift_bundle.edge(*item) for item in reduced.edges())
                    if z not in root
                )
            )
            assert all(expanded.has_edge(*root) for root in surviving_roots)
            record["surviving_root_interfaces"] += len(surviving_roots)

            for root in surviving_roots:
                family = families.get(root, [])
                if not family:
                    continue
                record["nonempty_antecedent_interfaces"] += 1
                record["reduced_target_interface_colourings"] += len(family)
                interface_extensions = 0

                for encoded in family:
                    reduced_colour = lift_bundle.decode_colouring(
                        reduced_vertices, encoded
                    )
                    fixed = {
                        vertex: value
                        for vertex, value in reduced_colour.items()
                        if vertex != z
                    }
                    for bits in product((0, 1), repeat=3):
                        record["local_assignments_tested"] += 1
                        lifted = {
                            **fixed,
                            **dict(zip(locals_, bits, strict=True)),
                        }
                        profile = lift_bundle.rooted_profile(
                            expanded, expanded_faces, lifted, root
                        )
                        if lift_bundle.is_target_profile(profile):
                            interface_extensions += 1
                            record["target_extensions_found"] += 1

                if interface_extensions:
                    record["interfaces_with_an_extension"] += 1
                    continue

                record["existence_failures"] += 1
                failure = lift_bundle.verify_failure(
                    source_graph6,
                    reduced,
                    expanded,
                    expanded_faces,
                    z,
                    rotation,
                    (first_index, second_index),
                    (first_gate, second_gate),
                    (left_arc, right_arc),
                    locals_,
                    root,
                    family,
                )
                return record, failure

    assert record["interfaces_with_an_extension"] == record[
        "nonempty_antecedent_interfaces"
    ]
    return record, None


def add_numeric(target: dict[str, int], record: dict[str, object]) -> None:
    excluded = {
        "source_order",
        "source_graph6",
        "dual_vertices",
    }
    for key, value in record.items():
        if key not in excluded:
            assert isinstance(value, int)
            target[key] = target.get(key, 0) + value


def census() -> dict[str, object]:
    source_counts = {
        "generated_connected_simple_cubic_bipartite": 0,
        "planar": 0,
        "planar_three_connected": 0,
        "plane_braces": 0,
    }
    totals: dict[str, int] = {}
    brace_records: list[dict[str, object]] = []
    first_failure = None

    graph_stream = generated_graphs()
    try:
        for graph6, graph in graph_stream:
            source_counts["generated_connected_simple_cubic_bipartite"] += 1
            assert len(graph) == ORDER
            assert nx.number_of_selfloops(graph) == 0
            assert nx.is_connected(graph) and nx.is_bipartite(graph)
            assert set(dict(graph.degree()).values()) == {3}

            is_planar, embedding = nx.check_planarity(graph, counterexample=True)
            if not is_planar:
                continue
            source_counts["planar"] += 1
            assert isinstance(embedding, nx.PlanarEmbedding)
            faces = source_bundle.plane_faces(graph, embedding)
            if nx.node_connectivity(graph) >= 3:
                source_counts["planar_three_connected"] += 1

            direct = source_bundle.is_two_extendable_direct(graph)
            strict_hall = source_bundle.strict_hall_two_extendable(graph)
            assert direct == strict_hall
            if not direct:
                continue
            source_counts["plane_braces"] += 1

            record, failure = graph_census(graph6, graph, faces)
            brace_records.append(record)
            add_numeric(totals, record)
            print(json.dumps(record, sort_keys=True), flush=True)
            if failure is not None:
                first_failure = failure
                break
    finally:
        graph_stream.close()

    if first_failure is None:
        assert source_counts[
            "generated_connected_simple_cubic_bipartite"
        ] == EXPECTED_RAW_COUNT
        assert totals["interfaces_with_an_extension"] == totals[
            "nonempty_antecedent_interfaces"
        ]
        conclusion = {
            "status": "exact_finite_theorem",
            "statement": (
                "Every order-20 simple plane cubic bipartite brace satisfies "
                "existence-level C4 lifting for every admissible two-gate expansion "
                "and every unchanged surviving root with nonempty reduced target family. "
                "Together with Note 066, the conclusion holds through reduced order 20."
            ),
            "unresolved_boundary": "Reduced brace order 22 and above.",
        }
    else:
        conclusion = {
            "status": "counterexample",
            "statement": (
                "Existence-level C4 lifting fails on the explicit order-20 reduced brace "
                "recorded in first_failure.  Note 066 makes reduced order 20 minimal."
            ),
            "unresolved_boundary": (
                "The universal lifting statement is false; this run does not classify all "
                "order-20 failures or decide whether the expanded brace has the RCA target "
                "for every root."
            ),
        }

    return {
        "trusted_generator_boundary": {
            "order": ORDER,
            "command": "geng -cqb -d3 -D3 20",
            "expected_isomorphism_representatives": EXPECTED_RAW_COUNT,
            "geng_path": source_bundle.shutil.which("geng"),
            "networkx_version": nx.__version__,
            "external_interfaces": [
                "nauty geng isomorph-free completeness",
                "NetworkX exact planarity decisions",
            ],
        },
        "source_counts": source_counts,
        "coverage": totals,
        "brace_graph6": [record["source_graph6"] for record in brace_records],
        "by_brace": brace_records,
        "first_failure": first_failure,
        "conclusion": conclusion,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    payload = census()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
        print("certificate", arguments.output)
    print(json.dumps(payload["source_counts"], sort_keys=True))
    print(json.dumps(payload["coverage"], sort_keys=True))
    print(json.dumps(payload["conclusion"], sort_keys=True))
    if payload["first_failure"] is None:
        print("C4_LIFTING_EXISTENCE_VERIFIED_THROUGH_REDUCED_ORDER_20")
    else:
        print("C4_LIFTING_EXISTENCE_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
