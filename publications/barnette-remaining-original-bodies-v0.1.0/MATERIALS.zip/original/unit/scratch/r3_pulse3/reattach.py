#!/usr/bin/env python3
"""Frozen pulse-3 reattachment interface.

No total U is claimed.  ``reattach`` deliberately returns an explicit
undetermined result: a pulse-2 row does not record the degrees/connectivity at
new q endpoints (and a target-use bit does not record connectivity after q is
cut).  This module prevents the validator from silently treating a projection
as the demanded full reconstruction.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Undetermined:
    reason: str


def reattach(sigma_plus, nu):
    """Attempt the frozen (P3) map, without querying a graph.

    Returning ``Undetermined`` is part of the pulse verdict, not a candidate
    state and not evidence of NOGO.  A total implementation may replace this
    only after a semantic proof or a certified real collision changes the
    verdict in a later pulse.
    """
    del sigma_plus, nu
    return Undetermined(
        "pulse-2 rows omit degree/connectivity refinements at newly exposed "
        "q endpoints; no proved total reconstruction rule is available"
    )


if __name__ == "__main__":
    print("R3_PULSE3_REATTACHMENT_UNDETERMINED")
