# Pulse-3 proof audit: no verdict-strength reconstruction obtained

## Exact attempted proposition

The attempted statement is the frozen (P3) in `DEFS.md`, with literal equality
of the complete pulse-2 successor summary and the complete next-input summary.
No projection of the row support is substituted for that object.

## Why the pulse-2 gluing proof does not iterate

For a pulse-2 successor row, every vertex outside its active quotient is
required to have degree two.  If a later retained edge `q=Q0Q1` has endpoints
outside that quotient, the next input instead exposes those endpoints and
allows degrees zero, one, or two.  Restricting an old generator therefore
sees only the degree-two slice at `Q0,Q1`; it is not a restriction--gluing
bijection onto the next generators.

Adding a bit for membership of `q` does not repair this.  When `q` is deleted,
the component containing it can split, and the pulse-2 partition records only
connectivity among its old active classes.  It does not record the two sides
of that split at newly active `Q0,Q1`.  The frozen `nu` contains incidence,
colour, equality, target and finite face-order data, but by design contains no
generator support from which those missing refinements could be read.

This proves that the existing pulse-2 *proof method* supplies no total `U`.
It is not an impossibility proof: on the real domain there might be additional
global identities forcing a unique refinement.  No such identity was proved
in this pulse.

## Direct real checks and their limit

`validate_reattach.py` uses the frozen certificate prefix

`cube -> (0,3,11,8) with retained 74 -> (0,12,7,4)`,

then directly verifies a legal second `o*` successor using retained edge
`q=(15,8)`.  It computes `Sigma_next` from graph edge sets independently of
`reattach.py`.  With unrelated targets, both q endpoints are absent from the
old interface; with `e=q`, they are target-only endpoints.  The complete
direct supports have respectively 5,121 and 1,016 distinct rows.  These checks
exercise the load-bearing cases but compare no claimed `U`, because
`reattach.py` truthfully returns `Undetermined`.

No pair of real histories with equal `Sigma_plus` and equal frozen `nu` but
different `Sigma_next` was found and completely certified.  Accordingly the
checks are neither GO nor NOGO evidence.  Under the frozen three-way stopping
rule the only valid verdict is **UNDETERMINED**.
