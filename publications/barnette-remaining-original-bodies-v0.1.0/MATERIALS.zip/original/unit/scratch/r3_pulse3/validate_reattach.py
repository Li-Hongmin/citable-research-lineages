#!/usr/bin/env python3
"""Independent direct-graph checks for frozen Route 1 pulse 3.

The checks construct a certified depth-one history, apply o* once, select
second retained edges only by direct successor legality, and compute the full
next exterior row support directly.  They include q endpoints outside the old
interface and q endpoints present only because q is a target.  Since no total
U was proved, these are regressions and obstruction witnesses, not a GO gate.
"""

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
P2 = HERE.parent / "r3_pulse2"
sys.path.insert(0, str(P2))

from row_engine import transition  # noqa: E402
from validate_real_contexts import (  # noqa: E402
    SLOTS, context_data, direct_row, edge, expand, legal_sites,
    subgraphs_with_degrees,
)
from reattach import Undetermined, reattach  # noqa: E402


def candidate_qs(Z, site):
    Z2, born = expand(Z, site)
    import networkx as nx
    assert all(d == 3 for _, d in Z2.degree())
    assert nx.is_bipartite(Z2) and nx.node_connectivity(Z2) >= 3
    u = site[0]
    a = born[0]
    cut = {edge(site[0], site[1]), edge(site[2], site[3])}
    ans = []
    for p, q in Z.edges():
        if edge(p, q) in cut:
            continue
        for oriented in ((p, q), (q, p)):
            if (u, a, oriented[0], oriented[1]) in legal_sites(Z2):
                ans.append(oriented)
    return sorted(set(ans))


def canonical_direct_support(Z, site, q, e, f):
    """Literal Sigma_next row support, with no pulse-2 row algebra."""
    structural = tuple(site) + tuple(q)
    target_vertices = tuple(e) + tuple(f)
    boundary_vertices = []
    for v in structural + target_vertices:
        if v not in boundary_vertices:
            boundary_vertices.append(v)
    X = Z.copy()
    X.remove_edges_from((edge(site[0], site[1]),
                         edge(site[2], site[3]), edge(*q)))
    sets = subgraphs_with_degrees(X, set(boundary_vertices))

    # A self-contained canonical row representation on actual ordered vertex
    # roles; it is used only for exact support equality/counting here.
    out = set()
    for subset in sets:
        import networkx as nx
        W = nx.Graph(); W.add_nodes_from(X); W.add_edges_from(subset)
        blocks, z = [], 0
        for comp in nx.connected_components(W):
            hit = tuple(i for i, v in enumerate(boundary_vertices) if v in comp)
            if hit:
                blocks.append(hit)
            else:
                z += 1
        out.add((tuple(W.degree(v) for v in boundary_vertices),
                 tuple(sorted(blocks)), min(2, z),
                 int(edge(*e) in subset), int(edge(*f) in subset)))
    return frozenset(out), len(sets), tuple(boundary_vertices)


def main():
    # Frozen certificate prefix: cube -> G1, then the displayed o* at s1.
    import networkx as nx
    Q = nx.Graph([(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),
                  (0,4),(1,5),(2,6),(3,7)])
    G1, _ = expand(Q, (0,1,2,3))
    s1, retained = (0,3,11,8), (7,4)
    # Targets deliberately external and disjoint from the first successor site.
    e0, f0 = edge(1,5), edge(2,6)
    Z, born, eta, vals, old_rows = context_data(G1, s1, retained, e0, f0)
    eta_plus, sigma_plus_rows = transition(eta, old_rows)
    site2 = (s1[0], born[0], retained[0], retained[1])
    assert site2 in legal_sites(Z)
    qs = candidate_qs(Z, site2)
    assert qs

    structural = set(site2)
    q_outside = next(q for q in qs if not (set(q) & structural))
    support1, realizers1, boundary1 = canonical_direct_support(
        Z, site2, q_outside, e0, f0)
    assert set(q_outside).isdisjoint(structural | set(e0) | set(f0))
    print("DIRECT_NEXT_OK q-endpoints-outside-interface",
          f"q={q_outside} boundary={boundary1} realizers={realizers1}",
          f"rows={len(support1)}")

    # q itself is target e: its nonstructural endpoints are target-only active.
    e1 = edge(*q_outside)
    support2, realizers2, boundary2 = canonical_direct_support(
        Z, site2, q_outside, e1, f0)
    assert set(q_outside).isdisjoint(structural)
    print("DIRECT_NEXT_OK q-target-only-endpoints",
          f"q={q_outside} boundary={boundary2} realizers={realizers2}",
          f"rows={len(support2)}")

    nu_stub = ("frozen-sixteen-slot-encoding", q_outside)
    result = reattach((eta_plus, sigma_plus_rows), nu_stub)
    assert isinstance(result, Undetermined)
    print("NO_TOTAL_U_CLAIMED", result.reason)
    print("R3_PULSE3_DIRECT_REATTACH_REGRESSIONS_VERIFIED verdict=UNDETERMINED")


if __name__ == "__main__":
    main()
