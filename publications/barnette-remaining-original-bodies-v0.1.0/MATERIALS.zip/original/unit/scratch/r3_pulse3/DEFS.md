# Frozen definitions for Route 1, pulse 3

**FROZEN before computation: 2026-09-13.**  No field may be added to
`nu` during this pulse.  This file does not alter
`SPEC-2026-09-12-upgrade.md`.

## 1. Domain and role normalization

`D_next` consists of the real objects with complete legal histories for which
two consecutive operations are instances of the fixed template `o*`.  After
the first operation, rename its successor site as

\[
  (U,V,X,Y)=(u,a,r_0,r_1),
\]

and let the genuinely present old edge selected as the second retained edge be
`q=(Q0,Q1)`.  The next operation cuts

\[
 K_{next}=\{UV,XY,Q0Q1\}.
\]

The ordered slots for the next input summary are

\[
 (U,V,X,Y,Q0,Q1,E0,E1,F0,F1,A,B,C,D).
\]

They have exactly the quotient, existence-bit and colour conventions of pulse
2 `DEFS.md`; `A,B,C,D` are the four not-yet-born vertices of the second
operation.  `Sigma_next(Z,q)` is the pulse-2 input summary computed literally
from `G(Z)-K_next`: it contains the resulting finite metadata and **all**
realized exterior-generator rows, with degree two off the active quotient and
degree at most two on it.

## 2. Frozen finite datum nu(Z,q)

`nu` is the following canonical tuple and nothing else.

1. `q_partition`: the equivalence relation on the sixteen ordered slots above,
   canonically numbered by first occurrence.  Its restriction to the old
   successor/target slots must agree with `Sigma_plus`; it records all
   equalities and inequalities of `Q0,Q1` with existing roles and targets.
2. `q_colours`: one bipartition bit per quotient class, modulo simultaneous
   reversal.  It includes the colours of `Q0,Q1`.
3. `q_target_identity`: for each of the two ordered target edges `e,f`, one of
   `equal-q`, `distinct-from-q`; endpoint equalities and orientation are read
   from `q_partition`.  Existing pulse-2 target location/status tags are
   retained unchanged where applicable.
4. `face_code`: an identifier from the fixed finite alphabet of second-site
   incidences allowed by `o*`, together with the cyclic word obtained by
   deleting every unmarked vertex from the selected face boundary and writing
   only the marked quotient roles `U,V,X,Y,Q0,Q1,E0,E1,F0,F1`, plus separators
   for the two site arcs.  The word is canonical up to simultaneous mirror.
   Repetition records marked-role occurrences only; no unmarked arc length is
   stored.
5. `next_target_code`: for each target, its pulse-2 finite location and status
   alphabet (`external-existing`, either site edge, `q`, one of the eight next
   patch edges, `not-yet-born`, or `deleted`; and the corresponding bounded
   live/future/deleted status), plus its current endpoint-existence bits.

No graph identifier, vertex number, history depth, birth/deletion layer,
unbounded arc length, unmarked facial word, exterior edge, generator, row, or
recomputed support is part of `nu`.

## 3. Compared objects and verdict gate

`Sigma_plus(Z)` is exactly the complete pulse-2 successor metadata and row
support already certified in Note 169.  Equality of summaries and of `nu` is
literal equality of their canonical encodings.  Equality of `Sigma_next` is
literal equality of all metadata and the full row-support set, not a
projection.

GO requires an explicit fixed finite `U` and a semantic proof over every
member of `D_next`.  NOGO requires two real, fully certified members with the
same `Sigma_plus` and `nu` but unequal full `Sigma_next`, including a complete
existence/nonexistence check for a differing row.  Otherwise the verdict is
UNDETERMINED.  Passing regressions is never itself GO.
