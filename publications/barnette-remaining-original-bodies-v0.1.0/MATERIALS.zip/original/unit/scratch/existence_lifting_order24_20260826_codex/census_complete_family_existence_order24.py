#!/usr/bin/env python3
"""Decide ordinary complete-family C4 lifting at reduced order 24.

This is the family-level continuation of the component census in the sibling
scratch directory.  It deliberately does not construct the alternating-cycle
target graph: by Note 071, any complete target family containing a target that
uses at most one gate already has a lift.  Only complete families in which
both gates occur in every target are sent to the exact eight-row lift test.

The input is streamed from geng.  The run stops only at the first complete
target family with no liftable target.  A component-level failure is therefore
not a stopping event.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import product
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Iterable, Iterator

import networkx as nx


ORDER = 24
EXPECTED_RAW_COUNT = 29579
Edge = tuple[int, int]
Matching = frozenset[Edge]

sys.dont_write_bytecode = True
BASE_SCRIPT = (
    Path(__file__).resolve().parents[1]
    / "target_component_saturation_order24_20260826"
    / "census_forced_target_components_order24.py"
)


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


base = load_module(BASE_SCRIPT, "order24_complete_family_base")
source_bundle = base.source_bundle
lift_bundle = base.lift_bundle
edge = base.edge
graph6 = base.graph6
matching_from_colour = base.matching_from_colour
primal_edge_by_dual_edge = base.primal_edge_by_dual_edge


def generated_graphs() -> Iterator[tuple[str, nx.Graph]]:
    process = subprocess.Popen(
        ("geng", "-cqb", "-d3", "-D3", str(ORDER)),
        stdout=subprocess.PIPE,
        text=True,
    )
    assert process.stdout is not None
    completed = False
    try:
        for line in process.stdout:
            source_graph6 = line.strip()
            if source_graph6:
                yield source_graph6, nx.from_graph6_bytes(source_graph6.encode())
        assert process.wait() == 0
        completed = True
    finally:
        if not completed and process.poll() is None:
            process.terminate()
            process.wait()


def profile_record(
    bits: tuple[int, int, int],
    normalized_bits: tuple[int, int, int],
    profile: tuple[bool, int | None, int | None, bool],
) -> dict[str, object]:
    return {
        "bits_left_right_centre": bits,
        "normalized_bits": normalized_bits,
        "nae": profile[0],
        "components": profile[1],
        "cycle_rank": profile[2],
        "root_on_cycle": profile[3],
        "target": lift_bundle.is_target_profile(profile),
    }


def freeze_family_failure(
    source_graph6: str,
    primal: nx.Graph,
    primal_faces: tuple[tuple[int, ...], ...],
    reduced: nx.Graph,
    reduced_faces: tuple[tuple[int, ...], ...],
    expanded: nx.Graph,
    expanded_faces: tuple[tuple[int, ...], ...],
    z: int,
    rotation: tuple[int, ...],
    gate_indices: tuple[int, int],
    gate_vertices: tuple[int, int],
    gate_edges: tuple[Edge, Edge],
    arcs: tuple[tuple[int, ...], tuple[int, ...]],
    locals_: tuple[int, int, int],
    root: Edge,
    primal_root: Edge,
    colours: tuple[dict[int, int], ...],
    matchings: tuple[Matching, ...],
) -> dict[str, object]:
    """Freeze the complete family and independently re-evaluate all rows."""

    expanded_dual = lift_bundle.dual_from_plane_graph(expanded, expanded_faces)
    targets = []
    for index, (colour, matching) in enumerate(
        zip(colours, matchings, strict=True)
    ):
        assert set(gate_edges) <= set(matching)
        fixed = {vertex: value for vertex, value in colour.items() if vertex != z}
        assignments = []
        for bits in product((0, 1), repeat=3):
            lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
            profile = lift_bundle.rooted_profile(
                expanded, expanded_faces, lifted, root
            )
            normalized = tuple(bit ^ colour[z] for bit in bits)
            assignments.append(profile_record(bits, normalized, profile))
        assert not any(record["target"] for record in assignments)
        reduced_profile = lift_bundle.rooted_profile(
            reduced, reduced_faces, colour, root
        )
        assert lift_bundle.is_target_profile(reduced_profile)
        targets.append(
            {
                "family_index": index,
                "zero_vertices": sorted(
                    vertex for vertex, value in colour.items() if value == 0
                ),
                "one_vertices": sorted(
                    vertex for vertex, value in colour.items() if value == 1
                ),
                "matching": sorted(matching),
                "gate_count": sum(gate in matching for gate in gate_edges),
                "reduced_rooted_profile": {
                    "nae": reduced_profile[0],
                    "components": reduced_profile[1],
                    "cycle_rank": reduced_profile[2],
                    "root_on_cycle": reduced_profile[3],
                },
                "all_eight_assignments": assignments,
            }
        )

    return {
        "failure_kind": "complete_target_family_without_liftable_target",
        "source_order": ORDER,
        "source_graph6": source_graph6,
        "source_primal_edges": sorted(edge(*item) for item in primal.edges()),
        "source_primal_faces": primal_faces,
        "reduced_triangulation_graph6": graph6(reduced),
        "reduced_triangulation_edges": sorted(
            edge(*item) for item in reduced.edges()
        ),
        "expanded_triangulation_graph6": graph6(expanded),
        "expanded_triangulation_edges": sorted(
            edge(*item) for item in expanded.edges()
        ),
        "expanded_triangulation_faces": expanded_faces,
        "expanded_dual_graph6": graph6(expanded_dual),
        "expanded_dual_edges": sorted(
            edge(*item) for item in expanded_dual.edges()
        ),
        "reduced_dual_brace_check": lift_bundle.verify_brace(primal),
        "expanded_dual_brace_check": lift_bundle.verify_brace(expanded_dual),
        "site": {
            "split_vertex": z,
            "rotation": rotation,
            "gate_indices": gate_indices,
            "gate_vertices": gate_vertices,
            "primal_gate_edges": gate_edges,
            "left_arc": arcs[0],
            "right_arc": arcs[1],
            "left_right_centre": locals_,
        },
        "dual_root": root,
        "primal_root": primal_root,
        "complete_target_family_size_mod_complement": len(matchings),
        "complete_target_family": targets,
    }


def analyse_brace(
    source_graph6: str,
    primal: nx.Graph,
    primal_faces: tuple[tuple[int, ...], ...],
) -> tuple[dict[str, object], dict[str, object] | None]:
    reduced, rotations = lift_bundle.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift_bundle.verify_reduced_triangulation(reduced)
    families, nae_count, target_shape_count = lift_bundle.target_families(
        reduced, reduced_faces
    )
    reduced_vertices = tuple(sorted(reduced))
    dual_to_primal = primal_edge_by_dual_edge(primal, primal_faces)

    family_cache: dict[
        Edge, tuple[tuple[dict[int, int], ...], tuple[Matching, ...]]
    ] = {}
    for root, encoded_family in families.items():
        colours = tuple(
            lift_bundle.decode_colouring(reduced_vertices, encoded)
            for encoded in encoded_family
        )
        matchings = tuple(
            matching_from_colour(primal, reduced, dual_to_primal, colour)
            for colour in colours
        )
        assert len(matchings) == len(set(matchings))
        assert all(dual_to_primal[root] in matching for matching in matchings)
        family_cache[root] = colours, matchings

    counts: Counter = Counter(
        {
            "colour_classes_mod_complement": 1 << (len(reduced_vertices) - 1),
            "nae_colourings_mod_complement": nae_count,
            "target_shape_colourings_mod_complement": target_shape_count,
            "root_target_pairs_mod_complement": sum(map(len, families.values())),
            "complete_family_failures": 0,
        }
    )

    for z in sorted(reduced):
        rotation = rotations[z]
        for first_index, second_index, first_gate, second_gate in lift_bundle.gate_pairs(
            rotation
        ):
            counts["nonconsecutive_gate_pairs"] += 1
            left_size = second_index - first_index + 1
            right_size = len(rotation) - (second_index - first_index) + 1
            if left_size % 2 == 0 or right_size % 2 == 0:
                continue
            counts["odd_arc_gate_pairs"] += 1

            expanded, locals_, left_arc, right_arc = lift_bundle.split_vertex(
                reduced, z, rotation, first_index, second_index
            )
            if nx.number_of_selfloops(expanded):
                continue
            if any(degree % 2 for _, degree in expanded.degree()):
                continue
            planar, _embedding = nx.check_planarity(expanded)
            if not planar:
                continue
            pre_faces = lift_bundle.plane_faces(expanded)
            if any(len(face) != 3 for face in pre_faces):
                continue
            counts["simple_eulerian_plane_triangulation_splits"] += 1

            expanded_faces = lift_bundle.expanded_triangulation_faces(expanded)
            if expanded_faces is None:
                continue
            counts["admissible_4connected_splits"] += 1

            gate_edges = (
                dual_to_primal[edge(z, first_gate)],
                dual_to_primal[edge(z, second_gate)],
            )
            assert gate_edges[0] != gate_edges[1]
            surviving_roots = tuple(root for root in sorted(families) if z not in root)
            counts["target_interfaces"] += len(surviving_roots)

            for root in surviving_roots:
                colours, matchings = family_cache[root]
                primal_root = dual_to_primal[root]
                gate_counts = tuple(
                    sum(gate in matching for gate in gate_edges)
                    for matching in matchings
                )
                counts["target_instances"] += len(matchings)
                counts["target_instances_using_at_most_one_gate"] += sum(
                    gate_count <= 1 for gate_count in gate_counts
                )
                counts["target_instances_using_both_gates"] += sum(
                    gate_count == 2 for gate_count in gate_counts
                )

                if any(gate_count <= 1 for gate_count in gate_counts):
                    counts["complete_families_closed_by_neutral_gate_lemma"] += 1
                    continue

                assert all(gate_count == 2 for gate_count in gate_counts)
                counts["complete_families_forcing_both_gates"] += 1
                counts["targets_in_forced_two_gate_complete_families"] += len(
                    matchings
                )
                found_lift = False
                for colour in colours:
                    counts["targets_examined_for_forced_family_witness"] += 1
                    fixed = {
                        vertex: value
                        for vertex, value in colour.items()
                        if vertex != z
                    }
                    for bits in product((0, 1), repeat=3):
                        counts["assignments_evaluated_for_forced_families"] += 1
                        lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
                        profile = lift_bundle.rooted_profile(
                            expanded, expanded_faces, lifted, root
                        )
                        if lift_bundle.is_target_profile(profile):
                            found_lift = True
                            break
                    if found_lift:
                        break

                if found_lift:
                    counts["forced_two_gate_complete_families_with_lift"] += 1
                    continue

                counts["complete_family_failures"] += 1
                failure = freeze_family_failure(
                    source_graph6,
                    primal,
                    primal_faces,
                    reduced,
                    reduced_faces,
                    expanded,
                    expanded_faces,
                    z,
                    rotation,
                    (first_index, second_index),
                    (first_gate, second_gate),
                    gate_edges,
                    (left_arc, right_arc),
                    locals_,
                    root,
                    primal_root,
                    colours,
                    matchings,
                )
                return {
                    "source_order": ORDER,
                    "source_graph6": source_graph6,
                    "dual_vertices": reduced.number_of_nodes(),
                    **dict(sorted(counts.items())),
                }, failure

    assert counts["complete_families_forcing_both_gates"] == counts[
        "forced_two_gate_complete_families_with_lift"
    ]
    assert counts["target_interfaces"] == (
        counts["complete_families_closed_by_neutral_gate_lemma"]
        + counts["complete_families_forcing_both_gates"]
    )
    return {
        "source_order": ORDER,
        "source_graph6": source_graph6,
        "dual_vertices": reduced.number_of_nodes(),
        **dict(sorted(counts.items())),
    }, None


def add_counts(totals: Counter, record: dict[str, object]) -> None:
    excluded = {"source_order", "source_graph6", "dual_vertices"}
    for key, value in record.items():
        if key in excluded:
            continue
        assert isinstance(value, int)
        totals[key] += value


def census() -> dict[str, object]:
    source_counts: Counter = Counter()
    totals: Counter = Counter()
    brace_records: list[dict[str, object]] = []
    first_failure = None

    stream = generated_graphs()
    try:
        for source_graph6, primal in stream:
            source_counts["generated_connected_simple_cubic_bipartite"] += 1
            assert primal.number_of_nodes() == ORDER
            assert nx.number_of_selfloops(primal) == 0
            assert nx.is_connected(primal) and nx.is_bipartite(primal)
            assert set(dict(primal.degree()).values()) == {3}

            planar, embedding = nx.check_planarity(primal, counterexample=True)
            if not planar:
                continue
            source_counts["planar"] += 1
            assert isinstance(embedding, nx.PlanarEmbedding)
            primal_faces = source_bundle.plane_faces(primal, embedding)
            if nx.node_connectivity(primal) >= 3:
                source_counts["planar_three_connected"] += 1

            direct = source_bundle.is_two_extendable_direct(primal)
            strict_hall = source_bundle.strict_hall_two_extendable(primal)
            assert direct == strict_hall
            if not direct:
                continue
            source_counts["plane_braces"] += 1

            record, failure = analyse_brace(source_graph6, primal, primal_faces)
            brace_records.append(record)
            add_counts(totals, record)
            print(json.dumps(record, sort_keys=True), flush=True)
            if failure is not None:
                first_failure = failure
                break
    finally:
        stream.close()

    complete_source_coverage = first_failure is None
    if complete_source_coverage:
        assert source_counts[
            "generated_connected_simple_cubic_bipartite"
        ] == EXPECTED_RAW_COUNT
        assert totals["complete_family_failures"] == 0
        assert totals["complete_families_forcing_both_gates"] == totals[
            "forced_two_gate_complete_families_with_lift"
        ]
        assert totals["target_interfaces"] == (
            totals["complete_families_closed_by_neutral_gate_lemma"]
            + totals["complete_families_forcing_both_gates"]
        )
        status = "ordinary_existence_lifting_verified_at_reduced_order_24"
        statement = (
            "For every order-24 simple plane cubic bipartite brace F', every "
            "legal two-gate C4 expansion, and every unchanged root e outside "
            "the split face with nonempty complete target family T_e, at "
            "least one member of T_e lifts through the fixed expansion."
        )
        unresolved = "Reduced brace order 26 and above; no arbitrary-order proof."
    else:
        status = "ordinary_existence_lifting_counterexample_at_reduced_order_24"
        statement = (
            "The explicit first_failure is an order-24 complete target family "
            "with no liftable member."
        )
        unresolved = (
            "Later order-24 inputs and all larger orders were not searched "
            "after the mandated first complete-family failure."
        )

    return {
        "status": status,
        "statement": statement,
        "trusted_coverage_boundary": {
            "order": ORDER,
            "generator_command": "geng -cqb -d3 -D3 24",
            "expected_isomorphism_representatives": EXPECTED_RAW_COUNT,
            "geng_path": shutil.which("geng"),
            "networkx_version": nx.__version__,
            "external_interfaces": [
                "nauty geng isomorph-free completeness",
                "NetworkX exact planarity decisions",
            ],
            "direct_checks_after_planarity": [
                "independent-two-edge extension",
                "strict-Hall brace criterion",
                "complete reduced target-family enumeration modulo global colour complement",
                "local lift rows through the first witness in each forced-two-gate complete family, or all rows on failure",
            ],
            "proof_level_reduction": (
                "Note 071 neutral-gate lemma closes every complete family "
                "containing a target that uses at most one gate"
            ),
            "complete_source_coverage": complete_source_coverage,
        },
        "source_counts": dict(sorted(source_counts.items())),
        "coverage": dict(sorted(totals.items())),
        "brace_graph6": [record["source_graph6"] for record in brace_records],
        "by_brace": brace_records,
        "first_failure": first_failure,
        "unresolved_boundary": unresolved,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    payload = census()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
        print("certificate", arguments.output)
    print(json.dumps(payload["source_counts"], sort_keys=True))
    print(json.dumps(payload["coverage"], sort_keys=True))
    if payload["first_failure"] is None:
        print("ORDINARY_EXISTENCE_LIFTING_VERIFIED_AT_REDUCED_ORDER_24")
    else:
        print("ORDINARY_EXISTENCE_LIFTING_COUNTEREXAMPLE_AT_REDUCED_ORDER_24")


if __name__ == "__main__":
    main()
