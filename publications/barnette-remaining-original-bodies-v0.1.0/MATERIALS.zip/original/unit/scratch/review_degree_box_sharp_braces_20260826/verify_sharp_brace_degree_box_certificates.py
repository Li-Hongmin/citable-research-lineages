#!/usr/bin/env python3
"""Independently verify the stored order-26/30 support-one certificates."""

from __future__ import annotations

from itertools import combinations
import json
from pathlib import Path

import networkx as nx


HERE = Path(__file__).resolve().parent


def edge(a: int, b: int) -> tuple[int, int]:
    return (a, b) if a < b else (b, a)


def strict_hall(graph: nx.Graph) -> bool:
    colour = nx.bipartite.color(graph)
    x_side = tuple(v for v in graph if colour[v] == 0)
    for size in range(1, len(x_side) - 1):
        for subset in combinations(x_side, size):
            neighbours = set().union(*(set(graph[x]) for x in subset))
            if len(neighbours) < size + 2:
                return False
    return True


def verify_payload(path: Path):
    payload = json.loads(path.read_text())
    assert len(payload) == 1
    record = payload[0]
    graph = nx.from_graph6_bytes(record["graph6"].encode())
    assert len(graph) == record["order"]
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.is_bipartite(graph) and nx.check_planarity(graph)[0]
    assert nx.node_connectivity(graph) == 3 and strict_hall(graph)

    automorphisms = tuple(
        nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter()
    )
    covered: set[tuple[int, int]] = set()
    certificates = 0
    component_size_pairs = set()

    root_records = {item["root"]: item for item in record["records"]}
    for root_record in record["records"]:
        root = root_record["root"]
        ports = tuple(root_record["ports"])
        y_order = tuple(root_record["y_order"])
        colour = nx.bipartite.color(graph)
        x_side = {v for v in graph if colour[v] != colour[root]}
        expected_y = tuple(sorted(v for v in graph if v != root and colour[v] == colour[root]))
        assert y_order == expected_y

        for fibre_record in root_record["fibre_records"]:
            assert fibre_record["status"] == "integral"
            assert fibre_record["support"] == 1
            fibre = fibre_record["fibre"]
            vector = tuple(fibre_record["vector"])
            forest = frozenset(tuple(e) for e in fibre_record["forest"])
            assert all(graph.has_edge(*e) and root not in e for e in forest)

            selected = nx.Graph()
            selected.add_nodes_from(v for v in graph if v != root)
            selected.add_edges_from(forest)
            assert nx.is_forest(selected)
            components = tuple(frozenset(c) for c in nx.connected_components(selected))
            assert len(components) == 2
            blocks = tuple(
                frozenset(index for index, port in enumerate(ports) if port in component)
                for component in components
            )
            assert sorted(map(len, blocks)) == [1, 2]
            assert frozenset((fibre,)) in blocks

            for x in x_side:
                assert selected.degree(x) == (1 if x in ports else 2)
            actual_vector = tuple(selected.degree(y) for y in y_order)
            assert actual_vector == vector
            assert vector.count(1) == 1 and vector.count(2) == len(vector) - 1

            low_y = y_order[vector.index(1)]
            singleton_component = next(
                component
                for component, block in zip(components, blocks)
                if block == frozenset((fibre,))
            )
            pair_component = next(
                component
                for component, block in zip(components, blocks)
                if len(block) == 2
            )
            assert low_y in singleton_component
            assert sorted(dict(selected.subgraph(singleton_component).degree()).values()).count(1) == 2
            assert sorted(dict(selected.subgraph(pair_component).degree()).values()).count(1) == 2
            assert max(dict(selected.degree()).values()) <= 2
            component_size_pairs.add((len(singleton_component), len(pair_component)))
            certificates += 1

            # Map this representative certificate through every
            # automorphism; its singleton port determines the target label.
            singleton_port = ports[fibre]
            for mapping in automorphisms:
                target_root = mapping[root]
                target_ports = tuple(sorted(graph[target_root]))
                target_fibre = target_ports.index(mapping[singleton_port])
                covered.add((target_root, target_fibre))

    assert covered == {(root, fibre) for root in graph for fibre in range(3)}
    return {
        "name": record["name"],
        "order": len(graph),
        "representative_certificates": certificates,
        "covered_root_fibres": len(covered),
        "component_size_pairs": tuple(sorted(component_size_pairs)),
    }


def main() -> None:
    summaries = tuple(
        verify_payload(HERE / f"{name}_degree_box_certificates.json")
        for name in ("order26", "order30")
    )
    for summary in summaries:
        print(summary)
    assert tuple(item["representative_certificates"] for item in summaries) == (39, 90)
    assert tuple(item["covered_root_fibres"] for item in summaries) == (78, 90)
    print("SHARP_BRACE_DEGREE_BOX_CERTIFICATES_VERIFIED")


if __name__ == "__main__":
    main()
