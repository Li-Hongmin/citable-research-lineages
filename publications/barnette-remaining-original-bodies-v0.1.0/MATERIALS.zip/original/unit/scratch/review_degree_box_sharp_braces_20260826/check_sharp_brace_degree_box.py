#!/usr/bin/env python3
"""Stream fixed-fibre degree-box certificates on the order-26/30 braces.

For each root, a rollback-DSU search generates only acyclic choices.  It
stops as soon as every fixed fibre has an integral forest whose complete
Y-degree vector is coordinatewise at most two.  If a fibre has no such
forest, its distinct degree vectors are retained for an LP test instead.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
from pathlib import Path

import networkx as nx
import numpy as np
from scipy.optimize import linprog


ORDER26_GRAPH6 = (
    "Y?????????S?s?b??[?CoI_?L??_o?`_@?G?@W????@C??@?@?@O??A_"
)
ORDER30_GRAPH6 = (
    "]?????????S?s?b??[?CoA_?L??_o?`_@???@W????@C??@?@?@O??A_"
    "?@?@???@???GC?G??g"
)
HERE = Path(__file__).resolve().parent


def edge(a: int, b: int) -> tuple[int, int]:
    return (a, b) if a < b else (b, a)


class RollbackDSU:
    def __init__(self, vertices: tuple[int, ...]):
        size = max(vertices) + 1
        self.parent = list(range(size))
        self.rank = [1] * size
        self.history: list[tuple[int, int, int] | None] = []

    def find(self, vertex: int) -> int:
        while self.parent[vertex] != vertex:
            vertex = self.parent[vertex]
        return vertex

    def snapshot(self) -> int:
        return len(self.history)

    def union(self, first: int, second: int) -> bool:
        first = self.find(first)
        second = self.find(second)
        if first == second:
            self.history.append(None)
            return False
        if self.rank[first] < self.rank[second]:
            first, second = second, first
        self.history.append((second, first, self.rank[first]))
        self.parent[second] = first
        self.rank[first] += self.rank[second]
        return True

    def rollback(self, snapshot: int) -> None:
        while len(self.history) > snapshot:
            record = self.history.pop()
            if record is None:
                continue
            child, parent, old_rank = record
            self.parent[child] = child
            self.rank[parent] = old_rank


def automorphism_orbit_representatives(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    orbits = {vertex: {vertex} for vertex in graph}
    matcher = nx.algorithms.isomorphism.GraphMatcher(graph, graph)
    for automorphism in matcher.isomorphisms_iter():
        for vertex, image in automorphism.items():
            orbits[vertex].add(image)
    return tuple(sorted({tuple(sorted(orbit)) for orbit in orbits.values()}))


def exact_lp(vectors: tuple[tuple[int, ...], ...]):
    """Return a float LP result; exact certificates are reconstructed below."""
    matrix = np.asarray(vectors, dtype=float).T
    return linprog(
        c=np.zeros(len(vectors)),
        A_ub=matrix,
        b_ub=np.full(matrix.shape[0], 2.0),
        A_eq=np.ones((1, len(vectors))),
        b_eq=np.ones(1),
        bounds=(0.0, None),
        method="highs",
    )


def rationalize_feasible(vectors, solution):
    support = tuple(index for index, value in enumerate(solution) if value > 1e-9)
    weights = tuple(Fraction(float(solution[index])).limit_denominator(10**7) for index in support)
    if sum(weights) != 1:
        return None
    expectations = tuple(
        sum(weight * vectors[index][coordinate] for index, weight in zip(support, weights))
        for coordinate in range(len(vectors[0]))
    )
    if max(expectations) > 2 or min(weights) <= 0:
        return None
    return support, weights, expectations


def farkas_separator(vectors: tuple[tuple[int, ...], ...]):
    """Find w>=0, sum w=1, with min_v w.(v-2)>0."""
    count = len(vectors[0])
    # Variables are w_0,...,w_{m-1},delta; maximize delta.
    a_ub = []
    for vector in vectors:
        a_ub.append([-(value - 2) for value in vector] + [1])
    result = linprog(
        c=[0] * count + [-1],
        A_ub=np.asarray(a_ub, dtype=float),
        b_ub=np.zeros(len(vectors)),
        A_eq=np.asarray([[1] * count + [0]], dtype=float),
        b_eq=np.ones(1),
        bounds=[(0, None)] * count + [(None, None)],
        method="highs",
    )
    assert result.success and result.x[-1] > 1e-9
    weights = tuple(Fraction(float(value)).limit_denominator(10**7) for value in result.x[:-1])
    total = sum(weights)
    weights = tuple(weight / total for weight in weights)
    margins = tuple(
        sum(weight * (value - 2) for weight, value in zip(weights, vector))
        for vector in vectors
    )
    assert min(margins) > 0
    return weights, min(margins)


def rooted_search(graph: nx.Graph, root: int):
    colour = nx.bipartite.color(graph)
    y_vertices = tuple(sorted(v for v in graph if v != root and colour[v] == colour[root]))
    x_vertices = tuple(sorted(v for v in graph if colour[v] != colour[root]))
    y_index = {vertex: index for index, vertex in enumerate(y_vertices)}
    ports = tuple(sorted(graph[root]))
    port_index = {vertex: index for index, vertex in enumerate(ports)}
    vertices = tuple(sorted(v for v in graph if v != root))

    # Each option records its omitted Y endpoint and selected P-edges.
    option_by_x = {}
    for x in x_vertices:
        neighbours = tuple(sorted(y for y in graph[x] if y != root))
        options = []
        for omitted in neighbours:
            selected = tuple((x, y) for y in neighbours if y != omitted)
            options.append((omitted, selected))
        option_by_x[x] = tuple(options)

    # Nonports contribute two selected edges and are placed first to prune
    # cycles early; ports contribute one selected edge.
    ordered_x = tuple(sorted(x_vertices, key=lambda x: (x in port_index, x)))
    dsu = RollbackDSU(tuple(graph))
    omitted_count = [0] * len(y_vertices)
    selected_edges: list[tuple[int, int]] = []
    integral = [None, None, None]
    vector_maps: list[dict[tuple[int, ...], tuple[tuple[int, int], ...]]] = [
        {}, {}, {}
    ]
    leaves = 0

    def visit(position: int) -> bool:
        nonlocal leaves
        if all(item is not None for item in integral):
            return True
        if position == len(ordered_x):
            leaves += 1
            roots = tuple(dsu.find(port) for port in ports)
            if len(set(roots)) != 2:
                return False
            singleton = tuple(i for i in range(3) if roots.count(roots[i]) == 1)
            if len(singleton) != 1:
                return False
            fibre = singleton[0]
            vector = tuple(3 - count for count in omitted_count)
            certificate = tuple(sorted(edge(a, b) for a, b in selected_edges))
            vector_maps[fibre].setdefault(vector, certificate)
            if max(vector) <= 2:
                integral[fibre] = {"vector": vector, "forest": certificate}
            return False

        x = ordered_x[position]
        for omitted, selected in option_by_x[x]:
            snapshot = dsu.snapshot()
            edge_snapshot = len(selected_edges)
            acyclic = True
            for first, second in selected:
                if not dsu.union(first, second):
                    acyclic = False
                    break
                selected_edges.append((first, second))
            if acyclic:
                omitted_count[y_index[omitted]] += 1
                if visit(position + 1):
                    omitted_count[y_index[omitted]] -= 1
                    del selected_edges[edge_snapshot:]
                    dsu.rollback(snapshot)
                    return True
                omitted_count[y_index[omitted]] -= 1
            del selected_edges[edge_snapshot:]
            dsu.rollback(snapshot)
        return False

    visit(0)
    records = []
    for fibre in range(3):
        if integral[fibre] is not None:
            records.append(
                {
                    "fibre": fibre,
                    "status": "integral",
                    "support": 1,
                    **integral[fibre],
                }
            )
            continue
        vectors = tuple(vector_maps[fibre])
        if not vectors:
            records.append({"fibre": fibre, "status": "infeasible_fibre"})
            continue
        result = exact_lp(vectors)
        if not result.success:
            weights, margin = farkas_separator(vectors)
            records.append(
                {
                    "fibre": fibre,
                    "status": "degree_box_failure",
                    "vectors": len(vectors),
                    "farkas_weights": weights,
                    "farkas_margin": margin,
                }
            )
            continue
        exact = rationalize_feasible(vectors, result.x)
        records.append(
            {
                "fibre": fibre,
                "status": "fractional_float" if exact is None else "fractional_exact",
                "vectors": len(vectors),
                "float_support": int(sum(value > 1e-9 for value in result.x)),
                "exact": exact,
            }
        )
    return {
        "root": root,
        "ports": ports,
        "y_order": y_vertices,
        "acyclic_leaves_seen": leaves,
        "fibre_records": records,
    }


def serializable(value):
    if isinstance(value, Fraction):
        return f"{value.numerator}/{value.denominator}"
    if isinstance(value, tuple):
        return [serializable(item) for item in value]
    if isinstance(value, list):
        return [serializable(item) for item in value]
    if isinstance(value, dict):
        return {key: serializable(item) for key, item in value.items()}
    return value


def check_graph(name: str, graph6: str):
    graph = nx.from_graph6_bytes(graph6.encode())
    orbits = automorphism_orbit_representatives(graph)
    records = []
    for index, orbit in enumerate(orbits, 1):
        root = orbit[0]
        record = rooted_search(graph, root)
        record["orbit"] = orbit
        records.append(record)
        statuses = tuple(item["status"] for item in record["fibre_records"])
        print(name, f"orbit={index}/{len(orbits)}", "root", root, "statuses", statuses, flush=True)
        if "degree_box_failure" in statuses:
            break
    return {
        "name": name,
        "graph6": graph6,
        "order": len(graph),
        "root_orbits": orbits,
        "records": records,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--graph", choices=("order26", "order30", "both"), default="both")
    args = parser.parse_args()
    targets = []
    if args.graph in ("order26", "both"):
        targets.append(("order26", ORDER26_GRAPH6))
    if args.graph in ("order30", "both"):
        targets.append(("order30", ORDER30_GRAPH6))

    payload = [check_graph(name, graph6) for name, graph6 in targets]
    output = HERE / f"{args.graph}_degree_box_certificates.json"
    output.write_text(json.dumps(serializable(payload), indent=2, sort_keys=True) + "\n")

    statuses = [
        fibre["status"]
        for graph_record in payload
        for root_record in graph_record["records"]
        for fibre in root_record["fibre_records"]
    ]
    print("output", output)
    print("status_counts", {status: statuses.count(status) for status in sorted(set(statuses))})
    if "degree_box_failure" in statuses:
        print("SHARP_BRACE_DEGREE_BOX_COUNTEREXAMPLE")
    elif all(status == "integral" for status in statuses):
        print("SHARP_BRACE_DEGREE_BOX_INTEGRAL_CERTIFICATES")
    else:
        print("SHARP_BRACE_DEGREE_BOX_REQUIRES_EXACT_FOLLOWUP")


if __name__ == "__main__":
    main()
