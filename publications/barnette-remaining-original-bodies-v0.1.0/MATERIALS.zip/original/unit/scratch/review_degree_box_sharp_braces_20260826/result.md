# The sharp order-26/30 braces have integral two-path certificates

## Statement tested

For a root \(r\), fixed port partition
\(\pi_i=\{i\}\mid([3]\setminus\{i\})\), and its exact forest fibre
\(\mathcal F_i\), test first the strengthening

\[
\tag{A}
\exists J\in\mathcal F_i\quad
\deg_J(y)\le2\quad(y\in Y\setminus\{r\}),
\]

and only if (A) fails test

\[
\tag{B}
\operatorname{conv}\{d_Y(J):J\in\mathcal F_i\}
\cap(-\infty,2]^{Y\setminus\{r\}}\ne\varnothing.
\]

The graphs are exactly the order-26 brace and its order-30 child frozen in
Note 027.

## Exact finite conclusion

Neither graph refutes (A), and hence neither refutes (B).

* The order-26 graph has an automorphism group of order two and 13 vertex
  orbits. Exact certificates for the three fibres at every orbit
  representative give 39 stored forests. Mapping them through the graph
  automorphisms covers all \(26\cdot3=78\) rooted fixed fibres.
* The order-30 child is asymmetric. All 30 roots and all three fibres were
  checked directly, giving 90 stored forests.

Every certificate is integral and has

\[
d_Y(J)=(2,\ldots,2,1,2,\ldots,2):
\]

there is exactly one degree-one \(Y\)-vertex and every other
\(Y\setminus\{r\}\) vertex has degree two. Thus the required rational
distribution is the point mass

\[
\Pr[J]=1,
\]

whose support size one is necessarily minimal.

In particular, every binary hole set is simultaneously safe for this same
forest:

\[
\ell_H(J)\le2|H|\qquad
(H\subseteq Y\setminus\{r\}).
\]

Hence there is neither a degree-box failure nor a binary-\(H\) failure in
the target graphs, and no Farkas separator is applicable.

## Reusable structural pattern

The integral degree-box certificate is exactly a spanning two-path cover.
Indeed, let a component contain \(k\in\{1,2\}\) ports. The prescribed
\(X\)-degrees and the tree identity give

\[
|E|=2|X_C|-k=|X_C|+|Y_C|-1
\]

and therefore

\[
\sum_{y\in Y_C}(2-\deg_J(y))=2-k. \tag{1}
\]

For the singleton-port component, (1) gives one \(Y\)-leaf; all other
vertices have degree two except the singleton port. It is a path from
that port to the unique degree-one \(Y\)-vertex. For the two-port
component, (1) is zero, so it is a path between the paired ports.

Thus (A) can be restated as:

> For each labelled port split, \(P=F-r\) has a spanning two-path cover in
> which one path joins the paired ports and the other joins the singleton
> port to a \(Y\)-vertex.

Across the stored certificates, every possible component-size split of
the correct parity occurs:

* order 26: \((2,23),(4,21),\ldots,(22,3)\);
* order 30: \((2,27),(4,25),\ldots,(26,3)\).

This size flexibility is an observed aggregate pattern, not a theorem for
each individual root/fibre.

## Computation and evidence boundary

The search used rollback union--find and streamed one root/fibre at a time.
It stopped as soon as all three fibres at a root had constructive integral
certificates; it did not materialize their full forest families. This is
sufficient because each retained forest is itself a checkable witness.
The search visited 85,695 acyclic leaves over the 13 order-26 orbit
representatives and 932,970 over the 30 order-30 roots; the certificate
files are below 0.3 MB.

An independent verifier checks the graph properties, strict Hall
inequalities, every stored edge set, prescribed \(X\)-degrees, acyclicity,
two components, labelled port partition, \(Y\)-degree vector, two-path
form, and automorphism coverage.

Evidence level: strict finite constructive certificate on the two requested
actual braces. It is only positive structural evidence for arbitrary
plane cubic bipartite braces. It does not prove (A), (B), or the Note 055
weak bound generally; in particular, a future graph may refute (A) while
still satisfying the genuinely fractional condition (B). The saved random
order-20/22/24 braces were not needed because the sharper target graphs
already supplied support-one witnesses. No adjacent-order census was run.

Reproduction:

    uv run --python 3.12 --with networkx --with numpy --with scipy \
      check_sharp_brace_degree_box.py --graph order26
    uv run --python 3.12 --with networkx --with numpy --with scipy \
      check_sharp_brace_degree_box.py --graph order30
    uv run --python 3.12 --with networkx \
      verify_sharp_brace_degree_box_certificates.py

The final verifier marker is
SHARP_BRACE_DEGREE_BOX_CERTIFICATES_VERIFIED.
