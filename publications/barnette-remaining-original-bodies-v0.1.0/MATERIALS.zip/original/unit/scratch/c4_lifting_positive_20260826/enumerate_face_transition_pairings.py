#!/usr/bin/env python3
"""Enumerate the minimal planar pairing obstructions to one-sector absorption."""

from __future__ import annotations

from functools import lru_cache


Pair = tuple[int, int]
Pairing = frozenset[Pair]


@lru_cache(maxsize=None)
def noncrossing(start: int, stop: int) -> tuple[Pairing, ...]:
    """Noncrossing perfect matchings of the ordered interval [start, stop)."""

    if start == stop:
        return (frozenset(),)
    answer = []
    for partner in range(start + 1, stop, 2):
        for inside in noncrossing(start + 1, partner):
            for outside in noncrossing(partner + 1, stop):
                answer.append(inside | outside | {(start, partner)})
    return tuple(answer)


def components(first: Pairing, second: Pairing) -> tuple[frozenset[int], ...]:
    adjacency: dict[int, set[int]] = {}
    for left, right in first | second:
        adjacency.setdefault(left, set()).add(right)
        adjacency.setdefault(right, set()).add(left)
    unseen = set(adjacency)
    answer = []
    while unseen:
        stack = [unseen.pop()]
        reached = set(stack)
        while stack:
            vertex = stack.pop()
            for neighbour in adjacency[vertex]:
                if neighbour not in reached:
                    reached.add(neighbour)
                    unseen.remove(neighbour)
                    stack.append(neighbour)
        answer.append(frozenset(reached))
    return tuple(sorted(answer, key=min))


def main() -> None:
    for half_length in range(2, 8):
        order = 2 * half_length
        old = frozenset((index, index + 1) for index in range(0, order, 2))
        new = frozenset(
            {(index, index + 1) for index in range(1, order - 1, 2)}
            | {(0, order - 1)}
        )
        patterns = []
        for rest in noncrossing(2, order):
            outside = rest | {(0, 1)}
            old_components = components(outside, old)
            new_components = components(outside, new)
            assert old_components[0] == frozenset({0, 1})
            old_count = len(old_components)
            new_count = len(new_components)
            if old_count <= 3 and new_count != old_count - 1:
                patterns.append(
                    (
                        tuple(sorted(outside)),
                        tuple(map(tuple, old_components)),
                        tuple(map(tuple, new_components)),
                    )
                )
        print(
            "face_length",
            order,
            "pairings",
            len(noncrossing(2, order)),
            "bad_with_at_most_three_old_cycles",
            len(patterns),
        )
        for pattern in patterns[:4]:
            print(" ", pattern)


if __name__ == "__main__":
    main()
