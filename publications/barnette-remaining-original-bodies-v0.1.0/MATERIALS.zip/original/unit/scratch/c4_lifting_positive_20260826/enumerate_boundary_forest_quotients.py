#!/usr/bin/env python3
"""Test the local quotient lemma over abstract noncrossing boundary partitions."""

from __future__ import annotations

from itertools import combinations


def partitions(order: int):
    labels = [0] * order

    def visit(index: int, maximum: int):
        if index == order:
            blocks = []
            for label in range(maximum + 1):
                blocks.append(frozenset(i for i, value in enumerate(labels) if value == label))
            yield tuple(blocks)
            return
        for label in range(maximum + 2):
            labels[index] = label
            yield from visit(index + 1, max(maximum, label))

    labels[0] = 0
    yield from visit(1, 0)


def is_noncrossing(blocks: tuple[frozenset[int], ...]) -> bool:
    for first, second in combinations(blocks, 2):
        for a, c in combinations(sorted(first), 2):
            for b, d in combinations(sorted(second), 2):
                if a < b < c < d or b < a < d < c:
                    return False
    return True


def quotient(
    blocks: tuple[frozenset[int], ...],
    attachments: tuple[tuple[str, tuple[int, ...]], ...],
    local_edges: tuple[tuple[str, str], ...],
) -> tuple[bool, callable]:
    block_of = {item: index for index, block in enumerate(blocks) for item in block}
    names = list(range(len(blocks))) + ["x1", "x3", "v"]
    parent = {name: name for name in names}

    def find(item):
        while parent[item] != item:
            parent[item] = parent[parent[item]]
            item = parent[item]
        return item

    def add(first, second) -> bool:
        left, right = find(first), find(second)
        if left == right:
            return False
        parent[left] = right
        return True

    forest = True
    for centre, positions in attachments:
        for position in positions:
            forest &= add(centre, block_of[position])
    for first, second in local_edges:
        forest &= add(first, second)
    return forest, lambda first, second: find(first) == find(second)


def both_alternating(order: int, gate: int, blocks: tuple[frozenset[int], ...]):
    first_arc = tuple(range(0, gate + 1))
    second_arc = tuple(range(gate, order)) + (0,)
    zero_first = tuple(item for item in first_arc if item % 2 == 0)
    one_first = tuple(item for item in first_arc if item % 2 == 1)
    zero_second = tuple(item for item in second_arc if item % 2 == 0)
    one_second = tuple(item for item in second_arc if item % 2 == 1)
    return (
        quotient(blocks, (("x1", zero_first), ("x3", one_second)), (("x3", "v"),)),
        quotient(blocks, (("x1", one_first), ("x3", zero_second)), (("x1", "v"),)),
        quotient(
            blocks,
            (("x1", one_first), ("x3", one_second), ("v", (0, gate))),
            (),
        ),
        quotient(
            blocks,
            (("x1", one_first), ("x3", one_second)),
            (("x1", "v"), ("v", "x3")),
        ),
    )


def main() -> None:
    for order in (4, 6, 8):
        for gate in range(2, order - 1, 2):
            admitted = 0
            no_forest = []
            bad_root = []
            zeros = set(range(0, order, 2))
            for blocks in partitions(order):
                if not is_noncrossing(blocks):
                    continue
                if any((block & zeros) and (block - zeros) for block in blocks):
                    continue
                if any(len(block & zeros) > 1 for block in blocks):
                    continue
                admitted += 1
                rows = both_alternating(order, gate, blocks)
                forest_rows = [item for item in rows if item[0]]
                if not forest_rows:
                    no_forest.append(blocks)
                    continue
                zero_blocks = [index for index, block in enumerate(blocks) if block & zeros]
                for left, right in combinations(zero_blocks, 2):
                    if not any(connected(left, right) for _, connected in forest_rows):
                        bad_root.append((blocks, left, right))
                        break
            print(
                "order_gate",
                (order, gate),
                "admitted",
                admitted,
                "no_forest",
                len(no_forest),
                "bad_root_pairs",
                len(bad_root),
            )
            if no_forest:
                print(" first_no_forest", no_forest[0])
            if bad_root:
                print(" first_bad_root", bad_root[0])


if __name__ == "__main__":
    main()
