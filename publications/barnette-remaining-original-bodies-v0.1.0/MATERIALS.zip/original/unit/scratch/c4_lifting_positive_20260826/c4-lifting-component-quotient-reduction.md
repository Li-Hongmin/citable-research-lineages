# C4 lifting is a component-quotient selection problem

## 1. Two proposed simplifications do not decide family selection

Let \(T'=F'^*\), let \(z\in V(T')\) be split along two nonconsecutive
gates, and let \(a\) be an unchanged root edge. For a target colouring
\(c\), normalize \(c(z)=0\), and write \(H=H(c)\) for its monochromatic
graph.

Two possible simplifications must be separated from the actual family
selection statement:

1. **Per-witness escape (A):** every target not in the locked state (L)
   has some target lift.
2. **Family escape (B):** a complete target family can never consist
   entirely of locked targets.

Statement (A) is false, even for an actual order-20 plane brace whose
two gate arcs are both fully alternating; Section 6 records the
counterexample from Note 068. Statement (B) remains open, but after the
failure of (A) it is only a necessary condition for the general
existence-level assertion, not a sufficient replacement for it. The result
below is instead an exact component-quotient criterion for each row and an
exact reformulation of selection over the complete target family.

## 2. Gate avoidance is false even for the cube

The stronger claim that every nonempty target family contains a target
using at most one gate is false. In the cube interface

\[
F'=Q_3,\quad \text{graph6 }G?zTb_,\quad
z=0,\quad N_{T'}(z)=(1,3,4,2),
\]

take gate positions \(0,2\), hence gate neighbours \(1,4\), and root
\(a=15\) in the dual. The complete target family modulo complement has
size one. Its normalized colouring is

\[
(c(0),c(1),c(2),c(3),c(4),c(5))=(0,0,1,1,0,0),
\]

so both gates are used. Both arcs \((1,3,4)\) and \((4,2,1)\) alternate.
The unique target has three target lifts, in rows

\[
011,\qquad 101,\qquad 110.
\]

Relative to the neutral three-cycle lift, rows \(011\) and \(101\) each
flip one alternating facial cycle with \((p,q)=(2,1)\); row \(110\) uses
an alternating union with \((p,q)=(3,2)\). All retain root separation.

Thus a proof cannot be based only on replacing a target by a different
reduced target: here no different reduced target exists. Nonneutral local
absorption at the same target is indispensable.

## 3. Exact component quotient

Put

\[
R=H-a.
\]

By Note 065, \(R\) is a spanning forest with exactly three components, and
the ends of \(a\) lie in the same component. Since \(a\) is not incident
with \(z\), let

\[
d=\deg_R(z),\qquad P=R-z,\qquad
\Pi=\operatorname{comp}(P).
\]

Removing a degree-\(d\) vertex from a three-component forest gives

\[
|\Pi|=d+2.                                                \tag{1}
\]

Every component of \(P\) is monochromatic. Moreover, the \(0\)-coloured
neighbours of \(z\) lie in pairwise different members of \(\Pi\), since
two such neighbours joined in \(P\) would form a cycle with their two
edges to \(z\).

Fix any locally NAE assignment

\[
s=(\lambda,\rho;\delta)
\]

from Note 065(2)--(3), where \(\lambda,\rho\) colour the two split copies
\(x_1,x_3\), and \(\delta\) colours the new centre \(v\). Define a
multigraph \(K_s\) as follows.

- Its vertices are the components \(\Pi\), together with \(x_1,x_3,v\).
- For every \(y\in A_1\) with \(c(y)=\lambda\), add
  \(x_1[C_P(y)]\).
- For every \(y\in A_3\) with \(c(y)=\rho\), add
  \(x_3[C_P(y)]\).
- Add \(vx_1\) if \(\delta=\lambda\), and \(vx_3\) if
  \(\delta=\rho\).
- For each gate \(y\in\{x_2,x_4\}\), add \(v[C_P(y)]\) if
  \(\delta=c(y)\).

Parallel edges are retained. The two ends of \(a\) mark their two
components of \(P\), which may coincide.

**Component-quotient theorem.** The assignment \(s\) is a target lift if
and only if

\[
K_s\text{ is a forest}                                   \tag{2}
\]

and its two root-marked vertices are connected in \(K_s\). \(\tag{3}\)

**Proof.** The expanded graph \(H(c_s)-a\) is obtained from the forest
\(P\) by adding exactly the local vertices and edges used to define
\(K_s\). Contracting every tree component of \(P\) preserves cycles,
component incidence, and root connectivity, and gives \(K_s\).

It remains only to check the component count. If \(n=|V(T')|\), then
\(R\) has \(n-3\) edges and \(P\) has \(n-3-d\) edges. Every facewise-NAE
colouring of the expanded triangulation, which has \(n+2\) vertices, has
\(n\) monochromatic edges; after deleting \(a\), it has \(n-1\). Hence
\(K_s\) has

\[
|V(K_s)|=(d+2)+3=d+5,\qquad |E(K_s)|=d+2.                \tag{4}
\]

If \(K_s\) is a forest, (4) forces exactly three components. Condition
(3) is precisely Note 065(5). Conversely, a target lift makes
\(H(c_s)-a\), and hence \(K_s\), a three-component forest with connected
root marks. \(\square\)

This removes the expanded triangulation from the connectivity test:
liftability depends only on the boundary-to-component incidence in the old
rooted three-forest.

## 4. Double-gate rows as collision tests

Assume both gates have colour \(0\). For \(i=1,3\), put

\[
Z_i=\{y\in A_i:c(y)=0\},\qquad
O_i=\{y\in A_i:c(y)=1\},
\]

and let \(\pi(y)=C_P(y)\). Components meeting \(Z_1\cup Z_3\) are
pairwise distinct and are disjoint from components meeting \(O_1\cup O_3\)
because components are monochromatic.

Suppose \(A_3\) alternates. For row \(011\), the quotient consists of the
\(x_1\)-star on \(\pi(Z_1)\), the \(x_3\)-star on \(\pi(O_3)\), and the
leaf edge \(x_3v\). Therefore row \(011\) is a target lift exactly when

\[
\pi|_{O_3}\text{ is injective},                           \tag{5}
\]

and either the root marks already lie in the same component of \(P\), or
both root marks belong to \(\pi(Z_1)\).                    \(\tag{6}\)

The latter alternative has a direct meaning. If deleting \(z\) separates
the root path in \(R\), its two branches must re-enter \(z\) through
zero-coloured neighbours. Row \(011\) reconnects exactly the branches on
the unflipped side \(A_1\). The symmetric criterion holds for row \(101\).

If both arcs alternate, row \(110\) has three stars: \(x_1\) on
\(\pi(O_1)\), \(x_3\) on \(\pi(O_3)\), and \(v\) on the two gate
components. It is a target lift exactly when

\[
\begin{aligned}
&\pi|_{O_1}\text{ and }\pi|_{O_3}\text{ are injective},\\
&|\pi(O_1)\cap\pi(O_3)|\le1,                              \tag{7}
\end{aligned}
\]

and the root marks already coincide in \(P\), or are precisely the two
gate components. Row \(111\) has the path \(x_1-v-x_3\); it is acyclic
exactly when both restrictions in (7) are injective and

\[
\pi(O_1)\cap\pi(O_3)=\varnothing.                         \tag{8}
\]

Since row \(111\) attaches no zero component, it preserves the rooted path
only when the root marks already coincide in \(P\).

The neutral row \(001\) is always cyclic: the two gate components, together
with \(x_1,x_3\), form a four-cycle in \(K_{001}\). Thus for a double-gate
target, the entire nonlocked per-witness question is the finite collision
problem (5)--(8) plus the stated root-mark conditions.

One immediate positive case is worth isolating. If an alternating sector
has length three, its set \(O_i\) has one vertex and it has no internal
zero vertex. Hence the corresponding single-side row automatically
satisfies (5), while every root branch through that sector enters at a
gate also belonging to the unflipped side. Therefore:

> A double-gate target with an alternating three-vertex sector always
> lifts.

This proves the cube absorption structurally rather than by enumeration.

## 5. The minimal composable state under reduced exchanges

Fix \(M_0\in\mathcal T_e\). For any other perfect matching
\(M=M_0\triangle(A_1\dot\cup\cdots\dot\cup A_k)\), gate incidence is
additive modulo two:

\[
\mathbf1_{\{g,h\}\cap M}
=\mathbf1_{\{g,h\}\cap M_0}
\oplus\bigoplus_j\mathbf1_{\{g,h\}\cap A_j}.             \tag{9}
\]

Cycle count and root separation are not additive. The alternating union
instead composes the old path pairing with the new matching pairing, as in
Note 060; the resulting circuit partition is exactly the component
partition \(\Pi_M\) needed to build \(K_{M,s}\). Consequently

\[
( \text{gate bits},\ \Pi_M,\ \text{two root marks})
\]

is a sufficient composable state for liftability. A scalar sum of the
individual values \(q-p\) is not sufficient: the Note 065 fixed site has
two disjoint components with effects \(+1\) and \(-1\), neither giving a
target alone, while their union restores the target and changes the gate
state.

This is also why ordinary exchange-graph connectivity cannot replace the
quotient state. The state remembers which boundary attachments collide in
the same old forest component, not just how many cycles an individual
exchange creates.

## 6. Witness-level escape is false, and the family state is indispensable

The quotient theorem does not make nonlockedness or arc alternation
sufficient. Note 068 gives a genuine order-20 plane-brace counterexample.
Its reduced brace has graph6 string

    S???????F?Y?b?W_DO?Y?DG?Oo?E_?B_?

and, in the dual, the interface is

\[
z=3,\qquad
N_{T'}(z)=(0,1,6,11,10,7,5,4),\qquad
\text{gates }0,10,\qquad a=02.
\]

For the target specified in Note 068, both gate arcs have word
\(01010\). Thus both gates are used and both arcs are fully alternating.
Nevertheless all eight local assignments fail to be target lifts. In the
five NAE rows, \(001,101,111\) have quotient cycles, while \(011\) and
\(110\) fail the rooted target condition. This is a real brace-realizable
counterexample to

\[
\forall c\in\mathcal T_e,\qquad
c\text{ nonlocked}\Longrightarrow c\text{ has a target lift}.
\tag{A}
\]

It does not refute family selection. The same complete target family has
nine members modulo complement: three are nonliftable and six have target
lifts. The example therefore proves that gate count, lockedness, and even
simultaneous full alternation do not determine the needed quotient state.

There is also a useful weaker-axiom route closure. Even planarity,
monochromatic components, and distinct zero-neighbour components do not by
themselves force one of the rows to be acyclic. Consider a cyclic boundary
of length eight with gates at positions \(0,4\) and alternating colours

Take a cyclic boundary of length eight with gates at positions \(0,4\) and
alternating colours

\[
0,1,0,1,0,1,0,1.
\]

Let the boundary partition induced by \(P\) be

\[
\{0\},\quad \{2\},\quad \{4\},\quad \{6\},\quad
\{1,3,5,7\},                                              \tag{10}
\]

and add one component of \(P\) not meeting the boundary. This partition is
noncrossing and every block is monochromatic. The four zero neighbours are
in different components. Adding \(z\) and its four zero edges turns the six
components of \(P\) into a three-component forest, exactly as required by
(1). A root path may be placed wholly in the off-boundary component, so
root connectivity introduces no obstruction.

Nevertheless every valid row fails:

- row \(011\) joins both \(5,7\) to \(x_3\), producing parallel quotient
  edges to the block \(\{1,3,5,7\}\);
- row \(101\) similarly collides at \(1,3\);
- rows \(110\) and \(111\) contain both collisions;
- row \(001\) contains the forced gate four-cycle.

Thus (10) is a nonlocked, root-compatible abstract boundary obstruction.
It is not claimed to come from a simple \(4\)-connected Eulerian
triangulation or a brace. It independently closes any proof using only:

1. that \(H-a\) is a planar three-forest;
2. that its components are monochromatic;
3. that the zero neighbours of \(z\) lie in distinct components; and
4. noncrossing boundary incidence.

The actual Note 068 witness is stronger: it already refutes (A) inside the
intended class. Pattern (10) is retained only to identify why the bare
three-forest and noncrossing-partition axioms cannot prove even row-level
escape.

## 7. Stopping conclusion

### Exact conclusion and quantifiers

The general existence-level lifting proposition remains undecided.
For every admissible interface and every reduced target \(c\), let
\(\mathcal S(c)\) be the locally NAE rows of Note 065(2)--(3), and construct
\(K_{c,s}\) as in Section 3. Then the proposition is exactly

\[
\forall(F',\text{site},e)\quad
\mathcal T_e\ne\varnothing
\Longrightarrow
\exists c\in\mathcal T_e\ \exists s\in\mathcal S(c):
\begin{cases}
K_{c,s}\text{ is a forest},\\
\text{the root marks are connected in }K_{c,s}.
\end{cases}                                               \tag{11}
\]

This is a strict equivalent reduction to the complete family's
boundary-component quotients. It includes simultaneous alternating
components and does not require intermediate matchings to be targets.

The stronger gate-avoidance selection principle is false by the cube
interface of Section 2. Statement (A), “every nonlocked target lifts”, is
equivalent to the assertion that the collision conditions of Section 4
always admit a row in an actual brace; it remains open. Statement (B),
“a complete target family is not all locked”, also remains open.

### Weakest load-bearing step

The contraction of the old forest \(P=H(c)-a-z\) is load-bearing. It turns
Note 065's global connectivity test into the finite multigraph \(K_{c,s}\).
The fixed edge count

\[
|V(K_{c,s})|-|E(K_{c,s})|=3
\]

makes acyclicity alone force the required three components; only root
connectivity remains.

### Evidence level

The component-quotient theorem and row criteria (5)--(8) are proof-level.
The cube is an exact finite interface check: its complete target family has
one member and rows \(011,101,110\) are target lifts. Pattern (10) is an
analytic countermodel to a stated set of weakened boundary axioms, not an
actual brace counterexample. The helper scripts merely reproduce the cube
and enumerate the small abstract quotient patterns; no graph-order census
is used here.

### Unresolved boundary

The next mathematical distinction, without selecting a new task, is exact:
does brace/face-load structure forbid the component collisions in
(5)--(8), especially the degree-eight pattern (10), or can such a quotient
be realized at a legal fixed site/root? Independently, if locked targets
exist, must the full target family contain a nonlocked quotient state?
Neither ordinary Kempe connectivity nor target-to-target single-component
exchange decides these questions.
