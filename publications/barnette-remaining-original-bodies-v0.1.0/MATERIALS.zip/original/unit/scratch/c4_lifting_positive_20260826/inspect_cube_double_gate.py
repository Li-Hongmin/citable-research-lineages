#!/usr/bin/env python3
"""Resolve the smallest all-both-gate target interface from Note 066."""

from __future__ import annotations

from collections import defaultdict
import importlib.util
from itertools import product
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
DRIVER_PATH = (
    UNIT
    / "computations/bundles/locked-boundary-escape-through18"
    / "census_locked_escape_through18.py"
)
SOURCE_PATH = UNIT / "scratch/barnette_locked_escape_census/through18_source_certificate.json"
sys.dont_write_bytecode = True


def load_driver():
    spec = importlib.util.spec_from_file_location("locked_escape_driver", DRIVER_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def dual_edge_map(
    graph: nx.Graph, faces: tuple[tuple[int, ...], ...]
) -> tuple[nx.Graph, dict[tuple[int, int], tuple[int, int]]]:
    incident: dict[tuple[int, int], list[int]] = defaultdict(list)
    for face_index, face in enumerate(faces):
        for index, first in enumerate(face):
            second = face[(index + 1) % len(face)]
            incident[tuple(sorted((first, second)))].append(face_index)
    dual = nx.Graph()
    edge_map = {}
    for source_edge, ends in incident.items():
        assert len(ends) == 2
        dual_edge = tuple(sorted(ends))
        dual.add_edge(*dual_edge)
        edge_map[source_edge] = dual_edge
    assert dual.number_of_edges() == graph.number_of_edges()
    return dual, edge_map


def primal_matching(
    triangulation: nx.Graph,
    edge_map: dict[tuple[int, int], tuple[int, int]],
    colour: dict[int, int],
) -> set[tuple[int, int]]:
    return {
        edge_map[tuple(sorted((first, second)))]
        for first, second in triangulation.edges()
        if colour[first] == colour[second]
    }


def factor(graph: nx.Graph, matching: set[tuple[int, int]]) -> nx.Graph:
    answer = nx.Graph()
    answer.add_nodes_from(graph.nodes())
    answer.add_edges_from(
        tuple(sorted(edge))
        for edge in graph.edges()
        if tuple(sorted(edge)) not in matching
    )
    return answer


def component_effect(
    graph: nx.Graph,
    old_matching: set[tuple[int, int]],
    exchange: set[tuple[int, int]],
    root: tuple[int, int],
) -> tuple[int, int, int, bool]:
    old_factor = factor(graph, old_matching)
    new_factor = factor(graph, old_matching ^ exchange)
    old_components = tuple(nx.connected_components(old_factor))
    new_components = tuple(nx.connected_components(new_factor))
    old_edges = exchange - old_matching
    new_edges = exchange & old_matching
    p = sum(
        any(set(edge) <= vertices for edge in old_edges)
        for vertices in old_components
    )
    q = sum(
        any(set(edge) <= vertices for edge in new_edges)
        for vertices in new_components
    )
    root_separated = not any(set(root) <= vertices for vertices in new_components)
    return p, q, len(new_components), root_separated


def main() -> None:
    driver = load_driver()
    source = json.loads(SOURCE_PATH.read_text())
    record = next(item for item in source["braces"] if item["graph6"] == "G?zTb_")
    reduced_primal = nx.from_graph6_bytes(record["graph6"].encode())
    reduced, rotations = driver.dual_from_primal_faces(reduced_primal, record["faces"])
    reduced_faces = driver.verify_reduced_triangulation(reduced)
    families, _, _ = driver.target_families(reduced, reduced_faces)

    z = 0
    first_index, second_index = 0, 2
    root = (1, 5)
    rotation = rotations[z]
    assert (rotation[first_index], rotation[second_index]) == (1, 4)
    assert len(families[root]) == 1
    expanded, locals_, left_arc, right_arc = driver.split_vertex(
        reduced, z, rotation, first_index, second_index
    )
    expanded_faces = driver.expanded_triangulation_faces(expanded)
    assert expanded_faces is not None

    vertices = tuple(sorted(reduced))
    colour = driver.decode_colouring(vertices, families[root][0])
    normalized = {vertex: value ^ colour[z] for vertex, value in colour.items()}
    assert normalized[rotation[first_index]] == normalized[rotation[second_index]] == 0
    assert all(
        normalized[left_arc[index]] != normalized[left_arc[index + 1]]
        for index in range(len(left_arc) - 1)
    )
    assert all(
        normalized[right_arc[index]] != normalized[right_arc[index + 1]]
        for index in range(len(right_arc) - 1)
    )

    fixed = {vertex: value for vertex, value in colour.items() if vertex != z}
    target_rows = []
    nae_rows = []
    for bits in product((0, 1), repeat=3):
        lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
        profile = driver.rooted_profile(expanded, expanded_faces, lifted, root)
        if profile[0]:
            relative = tuple(bit ^ colour[z] for bit in bits)
            nae_rows.append((relative, profile))
            if driver.is_target_profile(profile):
                target_rows.append((relative, lifted))
    assert target_rows

    expanded_primal, expanded_edge_map = dual_edge_map(expanded, expanded_faces)
    root_primal = expanded_edge_map[root]
    neutral = {
        **fixed,
        locals_[0]: colour[z],
        locals_[1]: colour[z],
        locals_[2]: colour[z] ^ 1,
    }
    neutral_matching = primal_matching(expanded, expanded_edge_map, neutral)
    neutral_factor = factor(expanded_primal, neutral_matching)
    assert nx.number_connected_components(neutral_factor) == 3

    inverse_labels = {value: key for key, value in expanded_edge_map.items()}
    row_effects = []
    for relative, lifted in target_rows:
        target_matching = primal_matching(expanded, expanded_edge_map, lifted)
        difference = nx.Graph()
        difference.add_edges_from(neutral_matching ^ target_matching)
        effects = []
        for component_vertices in nx.connected_components(difference):
            exchange = {
                tuple(sorted(edge))
                for edge in difference.subgraph(component_vertices).edges()
            }
            effects.append(
                {
                    "dual_labels": sorted(inverse_labels[edge] for edge in exchange),
                    "p_q_cycles_root": component_effect(
                        expanded_primal, neutral_matching, exchange, root_primal
                    ),
                }
            )
        row_effects.append((relative, effects))

    print("graph6", record["graph6"])
    print("reduced_rotation_at_z", rotation)
    print("gate_neighbours", (rotation[first_index], rotation[second_index]))
    print("root_dual", root)
    print("root_primal", root_primal)
    print("target_family_size", len(families[root]))
    print("normalized_target", normalized)
    print("arcs", left_arc, right_arc)
    print("nae_rows", nae_rows)
    print("target_rows", [row for row, _ in target_rows])
    print("neutral_factor_components", sorted(map(sorted, nx.connected_components(neutral_factor))))
    print("target_row_component_effects", row_effects)
    print("CUBE_DOUBLE_GATE_INTERFACE_VERIFIED")


if __name__ == "__main__":
    main()
