# Single leaf: existence-level escape from the locked C4 boundary

Long objective: decide Barnette-type Hamiltonicity through a genuine structural theorem or counterexample. Work only in units/barnette. Read the unit README and Notes 060, 063, and 065. Do not modify permanent notes or papers; keep all exploration in this scratch directory.

Let T' be a simple 4-connected Eulerian plane triangulation, let a be a prescribed edge, and let a reducible split of a vertex z along two nonconsecutive gates produce another simple 4-connected Eulerian plane triangulation T, with a surviving unchanged. A target colouring is facewise NAE and has monochromatic-edge graph of total cycle rank one with its unique cycle containing a.

Determine this single proposition:

> If T' has a target colouring for a, then T' has some target colouring for a that extends across the fixed split to a target colouring of T.

This is the exact existence-level form left open by Note 065. Translate the locked boundary into the primal perfect-matching/two-factor language and determine whether a root-preserving alternating exchange must escape it. Do not invoke generic Kempe connectivity: Note 060 already proves that connectivity alone neither preserves separation nor orients cycle rank.

Route-changing outcomes are a proof of the selection lemma, a genuine fixed-site/root counterexample in which every reduced target is nonextendable, or a strict reduction to a thinner matching/cut condition. The cheapest direct observation is the exact effect of one symmetric-difference component on the two gate arcs and the rooted cycle; do not build a broad census here.

Stop at proof, genuine counterexample, strict reduction, or scoped route closure. End with exact conclusion and quantifiers, weakest load-bearing argument, evidence level, and unresolved boundary. Do not select a new task.
