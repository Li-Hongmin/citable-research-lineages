#!/usr/bin/env python3
"""Inspect only the fixed Note 065 site in primal matching language."""

from __future__ import annotations

from itertools import product
import importlib.util
from pathlib import Path
import sys

import networkx as nx


ROOT = Path(__file__).resolve().parents[4]
VERIFY = ROOT / "units/barnette/computations/verify_locked_degree_four_boundary_obstruction.py"
sys.dont_write_bytecode = True
SPEC = importlib.util.spec_from_file_location("locked_verifier", VERIFY)
assert SPEC is not None and SPEC.loader is not None
LOCKED = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(LOCKED)


def dual_with_labels(
    graph: nx.Graph,
) -> tuple[nx.Graph, dict[tuple[int, int], tuple[int, int]]]:
    faces = LOCKED.plane_faces(graph)
    edge_faces: dict[tuple[int, int], list[int]] = {}
    for face_index, face in enumerate(faces):
        for index, first in enumerate(face):
            second = face[(index + 1) % len(face)]
            edge_faces.setdefault(tuple(sorted((first, second))), []).append(face_index)

    primal = nx.Graph()
    dual_to_primal: dict[tuple[int, int], tuple[int, int]] = {}
    for edge, ends in edge_faces.items():
        assert len(ends) == 2
        primal_edge = tuple(sorted(ends))
        primal.add_edge(*primal_edge, dual_edge=edge)
        dual_to_primal[edge] = primal_edge
    return primal, dual_to_primal


def target_colours(graph: nx.Graph) -> list[dict[int, int]]:
    vertices = tuple(graph.nodes)
    anchor = vertices[0]
    others = tuple(vertex for vertex in vertices if vertex != anchor)
    answer = []
    for bits in product((0, 1), repeat=len(others)):
        colour = {anchor: 0, **dict(zip(others, bits, strict=True))}
        if LOCKED.is_nae(graph, colour) and LOCKED.rooted_profile(graph, colour) == (3, 1, True):
            answer.append(colour)
    return answer


def matching(
    graph: nx.Graph,
    edge_map: dict[tuple[int, int], tuple[int, int]],
    colour: dict[int, int],
) -> set[tuple[int, int]]:
    return {
        edge_map[tuple(sorted((first, second)))]
        for first, second in graph.edges
        if colour[first] == colour[second]
    }


def edge_label(
    edge_map: dict[tuple[int, int], tuple[int, int]], primal_edge: tuple[int, int]
) -> tuple[int, int]:
    inverse = {value: key for key, value in edge_map.items()}
    return inverse[tuple(sorted(primal_edge))]


def rooted_profile_for(
    graph: nx.Graph, colour: dict[int, int], root: tuple[int, int]
) -> tuple[int, int, bool]:
    mono = LOCKED.mono_graph(graph, colour)
    components = nx.number_connected_components(mono)
    beta = mono.number_of_edges() - mono.number_of_nodes() + components
    without_root = mono.copy()
    if not without_root.has_edge(*root):
        return components, beta, False
    without_root.remove_edge(*root)
    root_on_cycle = nx.number_connected_components(without_root) == components
    return components, beta, root_on_cycle


def main() -> None:
    reduced = nx.Graph(LOCKED.REDUCED_EDGES)
    primal, edge_map = dual_with_labels(reduced)
    targets = target_colours(reduced)
    records = []
    for colour in targets:
        match = matching(reduced, edge_map, colour)
        records.append((colour, match))

    locked_index = next(
        index
        for index, (colour, _) in enumerate(records)
        if colour == LOCKED.REDUCED_COLOUR
    )
    locked_matching = records[locked_index][1]
    all_edges = {tuple(sorted(edge)) for edge in primal.edges}
    root_primal = edge_map[tuple(sorted(LOCKED.ROOT))]
    gate_edges = {
        edge_map[(0, LOCKED.CONTRACTED)],
        edge_map[(LOCKED.CONTRACTED, 9)],
    }
    print("primal_edges", sorted(primal.edges(data="dual_edge")))
    print("root_primal", root_primal)
    print("gate_0_primal", edge_map[(0, LOCKED.CONTRACTED)])
    print("gate_9_primal", edge_map[(LOCKED.CONTRACTED, 9)])
    print("locked_index", locked_index)

    extendable_count = 0
    synchronized_two_component_escape = False
    successful_single_component_escapes = 0

    for index, (colour, match) in enumerate(records):
        fixed = {
            vertex: value
            for vertex, value in colour.items()
            if vertex != LOCKED.CONTRACTED
        }
        extensions = []
        for local in product((0, 1), repeat=3):
            expanded_colour = {
                **fixed,
                LOCKED.LEFT: local[0],
                LOCKED.RIGHT: local[1],
                LOCKED.CENTRE: local[2],
            }
            if (
                LOCKED.is_nae(nx.Graph(LOCKED.EXPANDED_EDGES), expanded_colour)
                and rooted_profile_for(
                    nx.Graph(LOCKED.EXPANDED_EDGES), expanded_colour, LOCKED.ROOT
                )
                == (3, 1, True)
            ):
                extensions.append(local)
        if extensions:
            extendable_count += 1
        complement = nx.Graph()
        complement.add_nodes_from(primal.nodes)
        complement.add_edges_from(all_edges - match)
        cycles = [sorted(component) for component in nx.connected_components(complement)]
        difference = nx.Graph()
        difference.add_edges_from(locked_matching ^ match)
        components = [
            sorted(edge_label(edge_map, edge) for edge in difference.subgraph(vertices).edges)
            for vertices in nx.connected_components(difference)
        ]
        print(
            "target",
            index,
            "ones",
            sorted(vertex for vertex, value in colour.items() if value),
            "gate_bits",
            colour[0] == colour[1],
            colour[9] == colour[1],
            "factor_cycles",
            cycles,
            "target_extensions",
            extensions,
            "symdiff_dual_labels",
            components,
        )
        component_profiles = []
        for component_index, vertices in enumerate(nx.connected_components(difference)):
            exchange = {tuple(sorted(edge)) for edge in difference.subgraph(vertices).edges}
            new_matching = locked_matching ^ exchange
            old_factor = nx.Graph()
            old_factor.add_nodes_from(primal.nodes)
            old_factor.add_edges_from(all_edges - locked_matching)
            new_factor = nx.Graph()
            new_factor.add_nodes_from(primal.nodes)
            new_factor.add_edges_from(all_edges - new_matching)
            old_touched = {
                next(
                    cycle_index
                    for cycle_index, cycle_vertices in enumerate(nx.connected_components(old_factor))
                    if set(old_edge) <= cycle_vertices
                )
                for old_edge in exchange - locked_matching
            }
            new_touched = {
                next(
                    cycle_index
                    for cycle_index, cycle_vertices in enumerate(nx.connected_components(new_factor))
                    if set(new_edge) <= cycle_vertices
                )
                for new_edge in exchange & locked_matching
            }
            root_separated = not any(
                set(root_primal) <= cycle_vertices
                for cycle_vertices in nx.connected_components(new_factor)
            )
            gate_membership = tuple(gate in new_matching for gate in sorted(gate_edges))
            component_profiles.append(
                (
                    len(old_touched),
                    len(new_touched),
                    root_separated,
                    gate_membership,
                )
            )
            print(
                "  component",
                component_index,
                "dual_labels",
                sorted(edge_label(edge_map, edge) for edge in exchange),
                "p_q",
                (len(old_touched), len(new_touched)),
                "factor_count",
                nx.number_connected_components(new_factor),
                "root_separated",
                root_separated,
                "gate_membership",
                gate_membership,
            )
        if len(component_profiles) == 1 and extensions:
            profile = component_profiles[0]
            if profile[:3] == (2, 2, True) and profile[3] != (True, True):
                successful_single_component_escapes += 1
        if len(component_profiles) == 2 and extensions:
            effects = {(p, q, separated) for p, q, separated, _ in component_profiles}
            if effects == {(1, 2, True), (2, 1, False)}:
                synchronized_two_component_escape = True

    assert len(records) == 5
    assert extendable_count == 4
    assert synchronized_two_component_escape
    assert successful_single_component_escapes == 2
    print("verified_reduced_targets", len(records))
    print("verified_extendable_targets", extendable_count)
    print("verified_synchronized_two_component_escape", synchronized_two_component_escape)
    print("verified_successful_single_component_escapes", successful_single_component_escapes)


if __name__ == "__main__":
    main()
