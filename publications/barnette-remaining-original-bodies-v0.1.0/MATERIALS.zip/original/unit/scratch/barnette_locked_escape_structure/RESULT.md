# Locked split: a decorated two-gate matching reduction

## Primal translation

Let
\[
G=T'^{*},\qquad \widehat G=T^{*},\qquad e=a^{*}.
\]
The vertex \(z\) is dual to a facial cycle \(C\) of the plane cubic
bipartite brace \(G\). For a neighbour \(x\) of \(z\), put
\(b_x=(zx)^*\in E(C)\), and let \(g=b_{x_2},h=b_{x_4}\) be the
nonadjacent gate edges.

A facewise-NAE colouring \(c'\) gives the perfect matching \(M\) formed by
the duals of its monochromatic edges, and
\[
c'(x)=c'(z)\iff b_x\in M.                               \tag{1}
\]
It is a target exactly when
\[
e\in M,\qquad G-M=R\mathbin{\dot\cup}S,                 \tag{2}
\]
where the ends of \(e\) lie on different cycles \(R,S\).

Let \(J_1,J_3\) be the two closed edge arcs of \(C\) from \(g\) to \(h\).
The locked state is precisely
\[
g,h\in M,\qquad
\text{each \(J_i\) has two consecutive edges outside \(M\)}. \tag{3}
\]
Indeed, with both gate edges used, an arc alternates exactly when its
matching word is \(101\cdots01\). Since adjacent matching edges are
impossible, nonalternation is exactly a \(00\): a boundary vertex matched
by its third, external edge.

## Neutral lift

**Lemma 1.** If a target \(M\) has
\[
|M\cap\{g,h\}|\le1,                                     \tag{4}
\]
then its colouring extends to a target of \(T\).

**Proof.** The split replaces \(g,h\) by length-three paths whose middle
edges are opposite on a new facial quadrilateral \(Q\) of \(\widehat G\).
If neither gate is used, match the four new vertices by the two non-gate
edges of \(Q\). Each old gate in the complementary two-factor is only
subdivided to a length-three path.

If, say, \(g\in M,h\notin M\), replace \(g\) by the two outer edges of its
new path and put the middle edge of the \(h\)-path in the matching. In the
complementary two-factor, \(h\) is replaced by the length-five detour
through the other three edges of \(Q\). Thus \(R,S\), and the positions of
the ends of \(e\), are preserved. These are exactly the local assignments
\((00;0)\) and \((00;1)\) of Note 065. \(\square\)

Hence a counterexample must have both gates in every target matching.

## Exact remaining absorption condition

Fix a target \(M\) using both gates. The neutral lifted matching
\(\widehat M_0\) replaces them by the four outer half-gate edges, so
\[
\widehat G-\widehat M_0
=R\mathbin{\dot\cup}S\mathbin{\dot\cup}Q.                \tag{5}
\]
Let \(B_i\) be the facial boundary dual to the split copy of \(z\) on side
\(J_i\). It is \(\widehat M_0\)-alternating exactly when \(J_i\) alternates.
The complete nonneutral candidate family from Note 065's table is
\[
\mathcal A(M)=
\begin{cases}
\varnothing, & J_1,J_3\text{ both nonalternating},\\
\{B_i\}, & J_i\text{ is the only alternating side},\\
\{B_1,B_3,B_1\triangle B_3,
B_1\triangle B_3\triangle\partial Q\},
& J_1,J_3\text{ both alternating}.
\end{cases}                                               \tag{6}
\]
The last two terms are the two-copy and two-copy-plus-centre flips.

For \(A\in\mathcal A(M)\), let \(p(A)\) count the cycles in (5) meeting
the old two-factor edges of \(A\). After cutting them, let \(\alpha_A\)
pair ends along old path segments and \(\beta_A\) pair ends joined by the
new two-factor edges. Set
\[
q(A)=\operatorname{comp}(\alpha_A\cup\beta_A).           \tag{7}
\]
Then
\[
c\bigl(\widehat G-(\widehat M_0\triangle A)\bigr)
=3-p(A)+q(A).                                             \tag{8}
\]

**Lemma 2.** A target using both gates extends if and only if some
\(A\in\mathcal A(M)\) satisfies
\[
q(A)=p(A)-1,                                              \tag{9}
\]
and the two root-marked path segments lie in different
\(\alpha_A\cup\beta_A\)-components.

The component identity proves the cycle count, and marked separation is
exactly the condition that the new matching contain the bond between its
two complementary cycles, including \(e\). The candidates in (6) exhaust
the local NAE table. Thus Lemma 2 is a matching/cut condition, not a Kempe
connectivity statement.

## One reduced symmetric-difference component

Return to a target \(M\) in \(G\). For one \(M\)-alternating cycle \(A\)
avoiding \(e\), with \(N=M\triangle A\),
\[
c(G-N)=2-p(A)+q(A).                                      \tag{10}
\]
Thus \(N\) is another target exactly when \(q(A)=p(A)\) and its two root
marks remain separated. Starting from a locked \(M\),
\[
\mathbf1_{b\in N}
=\mathbf1_{b\in M}\oplus\mathbf1_{b\in A}
\quad(b\in E(C)).                                        \tag{11}
\]
A gate escape must meet \(g\) or \(h\), but retaining \(e\) says nothing
about the cycle or root tests.

The fixed Note 065 site exhibits the missing synchronization without a
graph census. Up to colour complementation it has five reduced targets for
root \(04\): the locked one is nonextendable, while the other four use one
gate and extend by Lemma 1. From the locked target,
\[
A_9=\{19,49,79,89\}^{*}
\]
meets a gate but has \((p,q)=(2,1)\), merging the root cycles. A disjoint
component
\[
A_5=\{15,25,45,57\}^{*}
\]
has \((p,q)=(1,2)\), splitting one old cycle. Neither works alone, but
\(A_5\cup A_9\) has \(p=q=2\), preserves root separation, and reaches an
extendable target. The same site also has two successful one-component
escapes with \(p=q=2\).

Thus this site does not decide universal selection, but it refutes the rule
that the gate-containing component of an arbitrary target symmetric
difference must work alone. The exact fixed-site check is:

    uv run --with 'networkx==3.6.1' \
      units/barnette/scratch/barnette_locked_escape_structure/inspect_fixed_site.py

## Stopping conclusion

**Exact conclusion and quantifiers.** The universal proposition is not
proved or refuted. It is exactly reduced to the following thinner statement.
For every admissible \((G,e,C,g,h)\) with nonempty target family
\[
\mathcal T_e(G)=
\{M:e\in M,\ G-M\text{ is two cycles separating the ends of }e\},
\]
there is \(M\in\mathcal T_e(G)\) satisfying (4), or using both gates and
having a candidate in (6) satisfying (9) and root separation. Lemmas 1--2
prove equivalence with the original extension proposition.

The stronger selection lemma
\[
\mathcal T_e(G)\ne\varnothing
\Longrightarrow
\exists M\in\mathcal T_e(G):|M\cap\{g,h\}|\le1           \tag{12}
\]
would settle it, but is not established. In reduced exchange language, a
sufficient escape from a locked target is an \(e\)-avoiding alternating
union meeting a gate, with \(q=p\) and separated root marks; these
properties are not forced componentwise by the present hypotheses.

**Weakest load-bearing argument.** Lemma 1's explicit two-factor surgery:
zero or one gate turns the expansion into subdivisions or one length-five
detour and preserves the two rooted cycles. In the remaining case,
\(3-p+q\) plus marked pairing is necessary and sufficient.

**Evidence level.** The primal translation and Lemmas 1--2 are proof-level.
The five-target and two-component facts are an exact finite check of one
fixed site in the scratch verifier, not evidence for the universal
quantifier.

**Unresolved boundary.** It remains to prove the selection statement or
find a fixed site/root where every target uses both gates and every legal
local union fails (9) or merges the roots. Generic Kempe connectivity does
not decide this; synchronized components may be essential. No adjacent
split, root, order, or new task is selected.
