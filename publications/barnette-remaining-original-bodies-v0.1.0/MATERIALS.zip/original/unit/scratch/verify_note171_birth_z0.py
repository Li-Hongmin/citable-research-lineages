#!/usr/bin/env python3
"""Independently check the advisor's 28/32-vertex collision (stdlib only).

Sources: SPEC-2026-09-12-upgrade.md; Notes 169--171;
scratch/r3_pulse{2,4}/DEFS.md; advisor/gpt6pro-2026-09-25-note171-followup.md.
No existing checker is imported or used. Run with python3 -B this_file.py.
Graphs come from the eight-edge SPEC rule, embeddings from local rotations.
All searches stream solutions; there is no full-support or 2^39 subset table.
Sigma_+ equality follows from identical complete source contexts, not a hash
or an enumeration of its rows. Only the declared finite nu/tau fields vary.
"""

from itertools import combinations
from time import perf_counter


def edge(u, v):
    assert u != v, ("loop", u)
    return tuple(sorted((u, v)))


def path(vertices):
    return {edge(u, v) for u, v in zip(vertices, vertices[1:])}


def cycle(vertices):
    return path((*vertices, vertices[0]))


def rotated(word):
    i = word.index(min(word))
    return tuple(word[i:] + word[:i])


def faces(rotation):
    darts = {(u, v) for u, ns in rotation.items() for v in ns}
    unseen = set(darts)
    result = []
    while unseen:
        start = min(unseen)
        dart, face = start, []
        while True:
            assert dart in unseen, ("invalid face permutation", dart)
            unseen.remove(dart)
            u, v = dart
            face.append(u)
            ns = rotation[v]
            dart = (v, ns[(ns.index(u) + 1) % len(ns)])
            if dart == start:
                break
        assert len(face) == len(set(face)), ("nonsimple face", face)
        result.append(rotated(face))
    return tuple(sorted(result))


def components(vertices, edges):
    adjacent = {v: set() for v in vertices}
    for u, v in edges:
        adjacent[u].add(v)
        adjacent[v].add(u)
    unseen = set(vertices)
    result = []
    while unseen:
        todo = [min(unseen)]
        part = set(todo)
        unseen.difference_update(part)
        while todo:
            new = adjacent[todo.pop()] & unseen
            unseen.difference_update(new)
            part.update(new)
            todo.extend(new)
        result.append(part)
    return result


def check_graph(rotation, edges):
    vertices = set(rotation)
    assert all(len(ns) == len(set(ns)) == 3 for ns in rotation.values())
    assert all(v in rotation[u] for v, ns in rotation.items() for u in ns)
    actual = {edge(v, u) for v, ns in rotation.items() for u in ns}
    assert actual == edges
    face_list = faces(rotation)
    assert len(vertices) - len(edges) + len(face_list) == 2, "not spherical"
    colours = {min(vertices): 0}
    todo = list(colours)
    while todo:
        v = todo.pop()
        for u in rotation[v]:
            if u not in colours:
                colours[u] = 1 - colours[v]
                todo.append(u)
            assert colours[u] != colours[v], ("not bipartite", v, u)
    assert set(colours) == vertices
    for size in range(3):
        for removed in combinations(sorted(vertices), size):
            allowed = vertices - set(removed)
            reached = {min(allowed)}
            todo = list(reached)
            while todo:
                new = set(rotation[todo.pop()]) & (allowed - reached)
                reached.update(new)
                todo.extend(new)
            assert reached == allowed, ("vertex cut", removed)
    return colours, face_list


def site_geometry(rotation, colours, site):
    u, v, x, y = site
    assert len(set(site)) == 4
    assert v in rotation[u] and y in rotation[x]
    assert colours[u] == colours[x]
    matches = []
    for f in faces(rotation):
        for sign, oriented in ((1, f), (-1, tuple(reversed(f)))):
            if u not in oriented:
                continue
            i = oriented.index(u)
            oriented = oriented[i:] + oriented[:i]
            if oriented[1] != v or x not in oriented:
                continue
            j = oriented.index(x)
            if j + 1 < len(oriented) and oriented[j + 1] == y:
                arcs = j - 1, len(oriented) - j - 1
                assert all(a > 0 and a % 2 == 1 for a in arcs)
                matches.append((oriented, arcs, sign))
    assert len(matches) == 1, ("site lacks a unique legal face", site, matches)
    return matches[0]


def expand(rotation, edges, colours, site, fresh):
    _, _, sign = site_geometry(rotation, colours, site)
    u, v, x, y = site
    a, b, c, d = fresh
    assert len(set(fresh)) == 4 and not (set(fresh) & set(rotation))
    seals = {edge(u, v), edge(x, y)}
    born = {edge(*p) for p in
            ((u, a), (a, b), (b, v), (x, c), (c, d), (d, y), (a, d), (b, c))}
    assert len(born) == 8 and not (born & edges)
    out = {v: list(ns) for v, ns in rotation.items()}
    for port, old, new in ((u, v, a), (v, u, b), (x, y, c), (y, x, d)):
        out[port][out[port].index(old)] = new
    local = {a: [u, d, b], b: [v, a, c], c: [x, b, d], d: [y, c, a]}
    out.update({v: ns if sign == 1 else ns[::-1] for v, ns in local.items()})
    return out, (edges - seals) | born, born, seals


ROLES = tuple("U V X Y Q0 Q1 E0 E1 F0 F1 A B C D".split())
TARGETS = (edge(2, 6), edge(9, 10))
SITES = ((0, 1, 2, 3), (4, 0, 3, 7), (0, 13, 14, 3),
         (0, 16, 19, 3), (0, 8, 9, 1), (0, 24, 11, 3))
EXPECTED_FACES = ((0, 1, 2, 3), (4, 0, 3, 7), (0, 13, 14, 3),
                  (0, 16, 19, 3),
                  (0, 8, 9, 1, 5, 4, 12, 13, 17, 16, 21, 20),
                  (0, 24, 25, 8, 11, 3))
QA, QB = (12, 13), (17, 16)
DEGREES = (0, 0, 0, 1, 2, 1, 1, 2, 1, 0)
PARTITION = ((0,), (1,), (2,), (3, 5), (4,), (6, 8), (7,), (9,))
EXPECTED_ROW = (DEGREES, PARTITION, 0, (0, 0))


def boundary(q):
    return (*SITES[-1], *q, 2, 6, 9, 10)


def birth_tag(layer, current):
    return "kernel" if layer == 0 else "last" if layer == current else "older"


def finite_key(q, z, h, colours, edge_birth, vertex_birth):
    slots = (*boundary(q), 28, 29, 30, 31)
    classes = tuple(dict.fromkeys(slots))
    quotient = tuple(classes.index(v) for v in slots)
    colour_word = tuple(colours[v] for v in classes)
    colour_word = min(colour_word, tuple(1 - c for c in colour_word))
    exists = tuple(v in z for v in classes)
    face, arcs, _ = site_geometry(h, colours, (0, 28, *q))
    labels = {v: ROLES[quotient[i]] for i, v in enumerate(slots)}
    j = face.index(q[0])
    # Same oriented role description implies equality after simultaneous mirror
    # canonicalization as well. Unmarked vertices and exact lengths are dropped.
    marked = ("UA", tuple(labels[v] for v in face[1:j + 1] if v in labels),
              "SEP", tuple(labels[v] for v in face[j + 1:] if v in labels), "SEP")
    target_data = []
    controlled = ((edge(0, 24), "UV"), (edge(11, 3), "XY"), (edge(*q), "q"))
    for i, target in enumerate(TARGETS):
        location = dict(controlled).get(target, "external-existing")
        status = "kernel-live" if edge_birth[target] == 0 else "older-live"
        endpoints = quotient[6 + 2 * i:8 + 2 * i]
        target_data.append((target == edge(*q), location, status, endpoints,
                            tuple(v in z for v in target)))
    nu = (quotient, colour_word, tuple(target_data), marked, exists)
    tau = (birth_tag(edge_birth[edge(*q)], 5),
           *(birth_tag(vertex_birth[v], 5) for v in q))
    return (nu, tuple(min(a, 3) for a in arcs), tau), arcs


def row(vertices, selected, active):
    degrees = {v: 0 for v in vertices}
    for u, v in selected:
        degrees[u] += 1
        degrees[v] += 1
    assert all(degrees[v] == 2 for v in set(vertices) - set(active))
    assert all(degrees[v] <= 2 for v in active)
    parts = components(vertices, selected)
    partition = tuple(sorted(tuple(i for i, v in enumerate(active) if v in part)
                             for part in parts if set(active) & part))
    closed = min(2, sum(not (set(active) & part) for part in parts))
    return (tuple(degrees[v] for v in active), partition, closed,
            tuple(int(t in selected) for t in TARGETS))


def degree_solutions(vertices, available, required):
    """Enumerate all degree-constrained subsets, by disjoint edge decisions.

    Propagation only forces all undecided incident edges or none when the
    degree equation requires it. Otherwise both values of one edge are tried.
    Hence every completion is visited exactly once, without partition pruning.
    """
    incident = {v: {e for e in available if v in e} for v in vertices}

    def visit(selected, pending):
        while True:
            changed = False
            for v in vertices:
                need = required[v] - len(incident[v] & selected)
                choices = incident[v] & pending
                if need < 0 or need > len(choices):
                    return
                if choices and need in (0, len(choices)):
                    if need:
                        selected = selected | choices
                    pending = pending - choices
                    changed = True
            if not changed:
                break
        if not pending:
            yield selected
            return
        e = min(pending)
        yield from visit(selected | {e}, pending - {e})
        yield from visit(selected, pending - {e})

    yield from visit(set(), set(available))


def check_absence_argument(vertices, exterior):
    """Validate each implication in the advisor's universal qA proof."""
    active = boundary(QA)
    required = dict.fromkeys(vertices, 2)
    required.update(zip(active, DEGREES))
    block = {active[i]: k for k, part in enumerate(PARTITION) for i in part}
    allowed = {e for e in exterior - set(TARGETS) if all(required[v] for v in e)}
    forced = set()

    def force_at(v, expected):
        incident = {e for e in allowed if v in e}
        assert len(incident) == required[v]
        assert incident == {edge(*e) for e in expected}
        forced.update(incident)

    assert edge(12, 13) not in exterior
    force_at(12, ((12, 4), (12, 15)))
    force_at(2, ((2, 1),))
    force_at(6, ((6, 5), (6, 7)))
    assert block[2] != block[6]
    assert path((2, 1, 5, 6)) - {edge(1, 5)} <= forced
    assert edge(1, 5) in allowed
    allowed.remove(edge(1, 5))  # Would connect two required distinct blocks.
    assert 5 not in active
    force_at(5, ((5, 4), (5, 6)))
    assert path((12, 4, 5, 6)) <= forced
    assert block[12] != block[6]  # Forced contradiction, for every realization.
    print("Universal proof: 1-5 forbidden by E0/E1 separation; forced 12-4-5-6")
    print("                contradicts Q0/E1 separation (independent of z).")


def verify():
    started = perf_counter()
    rotation = {0: [3, 1, 4], 1: [5, 0, 2], 2: [1, 3, 6], 3: [0, 7, 2],
                4: [7, 0, 5], 5: [4, 1, 6], 6: [2, 7, 5], 7: [3, 4, 6]}
    edges = cycle((0, 1, 2, 3)) | cycle((4, 5, 6, 7)) | {
        edge(0, 4), edge(1, 5), edge(2, 6), edge(3, 7)}
    vertex_birth = dict.fromkeys(rotation, 0)
    edge_birth = dict.fromkeys(edges, 0)
    deleted_at = {}
    history = [(rotation, edges)]
    births, seals = [], []
    colours, fs = check_graph(rotation, edges)
    print(f"Q: V={len(rotation)} E={len(edges)} faces={len(fs)}")
    for layer, site in enumerate(SITES, 1):
        face, arcs, _ = site_geometry(rotation, colours, site)
        assert face == EXPECTED_FACES[layer - 1], (layer, face)
        fresh = tuple(range(4 + 4 * layer, 8 + 4 * layer))
        rotation, edges, born, removed = expand(rotation, edges, colours, site, fresh)
        for e in removed:
            assert e in edge_birth and e not in deleted_at
            deleted_at[e] = layer
        assert not (born & edge_birth.keys())
        edge_birth.update(dict.fromkeys(born, layer))
        vertex_birth.update(dict.fromkeys(fresh, layer))
        births.append(born)
        seals.append(removed)
        history.append((rotation, edges))
        colours, fs = check_graph(rotation, edges)
        assert (len(rotation), len(edges), len(fs)) == (8 + 4 * layer, 12 + 6 * layer, 6 + 2 * layer)
        assert edges == {e for e, b in edge_birth.items() if b <= layer and e not in deleted_at}
        print(f"Layer {layer}: site={site} input_arcs={arcs} "
              f"V={len(rotation)} E={len(edges)} faces={len(fs)}; legal")

    # Actually remove each last gadget and restore seals/old port incidences.
    inverse, inverse_edges = rotation, edges
    for layer in range(6, 0, -1):
        site = SITES[layer - 1]
        u, v, x, y = site
        fresh = tuple(range(4 + 4 * layer, 8 + 4 * layer))
        a, b, c, d = fresh
        assert {e for e in inverse_edges if set(e) & set(fresh)} == births[layer - 1]
        inverse = {v: list(ns) for v, ns in inverse.items() if v not in fresh}
        for port, new, old in ((u, a, v), (v, b, u), (x, c, y), (y, d, x)):
            inverse[port][inverse[port].index(new)] = old
        inverse_edges = {e for e in inverse_edges if not (set(e) & set(fresh))} | seals[layer - 1]
        parent_rotation, parent_edges = history[layer - 1]
        assert inverse_edges == parent_edges
        assert {v: rotated(ns) for v, ns in inverse.items()} == {
            v: rotated(ns) for v, ns in parent_rotation.items()}
        inverse_colours, _ = check_graph(inverse, inverse_edges)
        site_geometry(inverse, inverse_colours, site)
    print("All six inverse edge/rotation reconstructions and graph checks passed.")

    z, z_edges = history[5]
    h, h_edges = history[6]
    assert set(TARGETS) <= z_edges - seals[5]
    assert edge(11, 3) in history[4][1] - seals[4]
    assert SITES[5] == (SITES[4][0], 24, 11, 3)
    site_geometry(z, colours, SITES[5])
    common_source = (history[:6], SITES[:5], SITES[5], (11, 3), TARGETS)
    contexts = [(common_source, q) for q in (QA, QB)]
    assert contexts[0][0] is contexts[1][0]
    print("Sigma_plus sources are literally identical: history, previous o*, site, targets.")
    keys = []
    for name, (_, q) in zip(("qA", "qB"), contexts):
        assert edge(*q) in z_edges - seals[5]
        terminal = (SITES[5][0], 28, *q)
        face, _, _ = site_geometry(h, colours, terminal)
        assert face == (0, 28, 29, 24, 27, 1, 5, 4, 12, 13, 17, 16, 21, 20)
        cap = {edge(0, 28), edge(*q)}
        owners = [{e for e in h_edges - cap if edge_birth[e] == b} for b in range(7)] + [cap]
        assert set.union(*owners) == h_edges
        assert sum(map(len, owners)) == len(h_edges)
        assert all(sum(e in owner for owner in owners) == 1 for e in h_edges)
        assert set(vertex_birth) == set(h)
        assert [sum(b == layer for b in vertex_birth.values()) for layer in range(7)] == [8] + [4] * 6
        key, arcs = finite_key(q, z, h, colours, edge_birth, vertex_birth)
        keys.append(key)
        assert key[0][0] == tuple(range(14))
        assert key[0][1] == (0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0)
        assert key[0][3] == ("UA", ("A", "B", "V", "Q0"), "SEP", ("Q1",), "SEP")
        assert key[0][4] == (True,) * 10 + (False,) * 4
        assert key[1:] == ((3, 3), ("older",) * 3)
        assert arcs == ((7, 5) if q == QA else (9, 3))
        print(f"{name}={q}: arcs={arcs}, c3={key[1]}, tau={key[2]}, "
              f"birth_layers={(edge_birth[edge(*q)], *(vertex_birth[v] for v in q))}")
        print(f"  ledger owner counts (kernel, layers 1..6, cap)={tuple(map(len, owners))}")
    assert keys[0] == keys[1]
    print(f"Equal complete nu={keys[0][0]}")
    print("K_tau equality verified, including candidate-edge and endpoint birth labels.")

    witness = (path((3, 23, 20, 21, 22, 19, 16)) |
               path((2, 1, 27, 26, 25, 8, 9)) |
               cycle((4, 5, 6, 7, 15, 12)) | cycle((13, 14, 18, 17)))
    exterior_b = z_edges - seals[5] - {edge(*QB)}
    assert witness <= exterior_b and not (witness & set(TARGETS))
    assert len(set(z) - set(boundary(QB))) == 18
    assert row(z, witness, boundary(QB)) == EXPECTED_ROW
    print(f"qB witness: {len(witness)} edges; full row={EXPECTED_ROW}")
    print(f"Witness components (isolated boundary vertices included): "
          f"{[tuple(sorted(c)) for c in components(z, witness)]}")
    exterior_a = z_edges - seals[5] - {edge(*QA)}
    check_absence_argument(z, exterior_a)
    for name, q in (("qA", QA), ("qB", QB)):
        exterior = z_edges - seals[5] - {edge(*q)}
        required = dict.fromkeys(z, 2)
        required.update(zip(boundary(q), DEGREES))
        total = matching = witness_hits = 0
        for selected in degree_solutions(sorted(z), exterior - set(TARGETS), required):
            total += 1
            matching += row(z, selected, boundary(q)) == EXPECTED_ROW
            witness_hits += selected == witness
        assert total > 0, ("unexpected degree-only obstruction", name)
        assert matching == 0 if q == QA else matching > 0
        if q == QB:
            assert witness_hits == 1
        print(f"Exhaustive {name}: degree/target-feasible subsets={total}; "
              f"matching full rows={matching}")
    print("Scope: exact z=0 row-support reattachment fails for K_tau; "
          "no Hamilton-acceptance or all-finite-summary no-go is inferred.")
    print(f"Elapsed: {perf_counter() - started:.3f}s")
    print("NOTE171_BIRTH_Z0_COLLISION_INDEPENDENTLY_VERIFIED")


if __name__ == "__main__":
    verify()
