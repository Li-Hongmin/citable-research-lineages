# One-step C4 patches do not turn the order-22 isolated component into a one-crossing fibre

Fix the order-\(22\) brace

~~~text
U?????????[?s?b?KO@Q?BO?Co?F??@o?QG?CE??
~~~

with

\[
e=1-11,\qquad g_0=0-12,\qquad g_1=9-17.
\]

Its complete rooted exchange graph has components of orders \(2\) and \(6\)
and exactly three crossings; the order-two component is an isolated mixed
edge.

For every face of the fixed embedding and every pair of disjoint boundary
edges avoiding \(e,g_0,g_1\), install the standard planar \(C_4\) expansion.
After deduplication, exactly \(38\) children remain simple plane cubic
bipartite braces with the same root square and a legal-wide gate face.
Their crossing-count distribution is

\[
3^9,\quad5^{11},\quad6^1,\quad7^5,\quad9^4,\quad
11^2,\quad13^2,\quad15^2,\quad16^1,\quad23^1.
\]

Thus no one-step child has exactly one crossing; the minimum remains three.
This is a complete result only for the named parent and one standard
face-local expansion. It is not an arbitrary-patch theorem and gives no
general lower bound.

Reproduce with

    uv run --python 3.14 --with 'networkx==3.6.1' \
      units/barnette/scratch/test_order22_isolated_mixed_k2_one_step_c4.py

The terminal marker is

    ORDER22_ISOLATED_K2_ONE_STEP_COUNTEREXAMPLE_NOT_FOUND
