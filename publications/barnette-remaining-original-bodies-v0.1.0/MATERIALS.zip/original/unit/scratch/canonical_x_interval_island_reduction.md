# Canonical--cross bonds reduce exactly to an interval-island obstruction

This draft uses only the split dictionary and the root-admissibility calculus
of Notes 108, 109, and 111.  It does not assume the finite classifications
reported elsewhere.

## 1. Setup

Let \(T^+\) be the child Eulerian triangulation.  Around the split patch use
the notation of Note 108, so its local edges are

\[
 AP,BP,CP,AQ,BQ,CQ,AC,BC .
\]

Delete the three new vertices and put

\[
 H=T^+-\{A,B,C\},\qquad
 J_A=N_{T^+}(A)\cap V(H),\qquad
 J_B=N_{T^+}(B)\cap V(H).
\tag{1}
\]

Thus \(J_A,J_B\) are the two closed rotation intervals inherited from the
split vertex; both contain \(P,Q\).  Let \({\cal A}_K^b\) denote the
root-admissible NAE colourings in local cell \(K\), modulo global reversal,
whose surviving-gate bit is \(b\in\{0,1\}\).  Write

\[
 {\cal C}=\{C_{00},C_{10},C_{01}\},\qquad U=X_{uy},\quad V=X_{vx}.
\]

For a pair \((\kappa,\xi)\in{\cal A}_{\cal C}\times{\cal A}_{\{U,V\}}\),
choose representatives according to the five-bit rows of Note 108 and put

\[
 D=D(\kappa,\xi)=\{v\in V(H):\kappa(v)\ne\xi(v)\}.
\tag{2}
\]

The normalization of \(D\) is fixed by the local XOR support below; replacing
both representatives by their global reversals does not change it.

## 2. Exact interval-hitting criterion

Define

\[
 \begin{aligned}
 h_A(D)&:\Longleftrightarrow
   \text{every component of }H[D]\text{ meets }J_A,\\
 h_B(D)&:\Longleftrightarrow
   \text{every component of }H[D]\text{ meets }J_B.
 \end{aligned}
\tag{3}
\]

**Lemma 1 (component criterion).**  Let \(\kappa,\xi\) be root-admissible.

1. If \(\xi\in U\), their XOR shore is a bond precisely when
   
   \[
   h_A(D)\quad\text{and}\quad h_B(\bar D).
   \tag{4}
   \]

2. If \(\xi\in V\), their XOR shore is a bond precisely when

   \[
   h_B(D)\quad\text{and}\quad h_A(\bar D).
   \tag{5}
   \]

Here complements are taken in \(V(H)\).

*Proof.*  Direct XOR of the five-bit representatives gives

\[
\begin{array}{c|cc}
 &U&V\\ \hline
C_{00}&ACPQ&BCPQ\\
C_{10}&AQ&BQ\\
C_{01}&AP&BP.
\end{array}
\tag{6}
\]

Consider first a \(U\)-pair.  In all three rows the \(D\)-shore has one
connected local core containing \(A\), and \(A\) attaches to \(H[D]\)
exactly at \(J_A\cap D\).  Hence that shore is connected exactly when every
component of \(H[D]\) meets \(J_A\).  The complementary shore has one
connected local core containing \(B\), and it attaches to \(H[\bar D]\)
exactly at \(J_B\cap\bar D\).  Its connectivity is therefore equivalent to
\(h_B(\bar D)\).  A cut is a bond exactly when both shores are connected,
which proves (4).  The \(V\)-rows exchange \(A\) and \(B\), proving (5).
\(\square\)

The gate is outside the split interface.  Therefore two such colourings
have different gate bits exactly when the gate dual edge lies in their XOR
cut.  Since both endpoints are already root-admissible, Lemma 1 gives the
following complete characterization without any further rank test.

**Theorem 2 (complete-family criterion).**

\[
\begin{split}
 \Gamma({\cal C},{\cal X})\ne\varnothing
 \quad\Longleftrightarrow\quad
 &\exists b,\ \kappa\in{\cal A}_{\cal C}^{b},\
      \xi\in{\cal A}_{U}^{1-b}:
      h_A(D)\wedge h_B(\bar D),\\
 &\text{or }\exists b,\ \kappa\in{\cal A}_{\cal C}^{b},\
      \xi\in{\cal A}_{V}^{1-b}:
      h_B(D)\wedge h_A(\bar D).
\end{split}
\tag{7}
\]

Thus the negation of canonical--cross supplementation has an exact single
form: every opposite-gate canonical--cross pair contains a
**wrong-interval island**.  For a \(U\)-pair this is either a component of
\(H[D]\) missing \(J_A\), or a component of \(H[\bar D]\) missing \(J_B\);
for a \(V\)-pair the interval labels are reversed.  Empty opposite-gate
occupancy is included vacuously.

## 3. Minimal-island reduction

The component criterion can be sharpened without selecting a parent
ancestor.  Fix an opposite-gate canonical--cross pair and let
\(W^+\subset V(T^+)\) be its XOR shore.  The primal dual of
\(\delta(W^+)\) is the symmetric difference of two perfect matchings, hence
is a disjoint union of simple alternating cycles.  The components of
\(T^+[W^+]\) and \(T^+[\overline{W^+}]\), joined once for each boundary
cycle, form a tree: disjoint Jordan curves on the sphere increase the
number of regions by one at each insertion.

The local cut edges in (6) form one path through the four split triangles.
Consequently they all lie on one distinguished alternating cycle, denoted
\(Z_0\).  Every other cycle \(Z\) cuts off a shore \(S_Z\) containing none
of \(A,B,C,P,Q\).  Flipping \(S_Z\) in either endpoint

* is again NAE, because \(Z\) is one component of the matching symmetric
  difference;
* leaves its local cell unchanged;
* removes exactly \(Z\) from the symmetric difference.

There is a unique symmetric-difference cycle \(Z_g\) containing the
surviving gate, since the two gate bits are different.

Choose an opposite-gate canonical--cross pair with the minimum number of
symmetric-difference cycles.  If it is not a bond, it has at least two
cycles.  For every exterior cycle

\[
 Z\notin\{Z_0,Z_g\},
\tag{8}
\]

flipping its patch-free shore at either endpoint must destroy
root-admissibility.  Otherwise the resulting endpoint has the same local
cell and gate bit and gives an opposite-gate canonical--cross pair with one
fewer cycle, contrary to minimality.  By Note 109, each such failure is
exactly one of

\[
 \rho_{00}+\rho_{11}\ne\rho_{10}+\rho_{01}
 \quad\text{or}\quad
 \text{fusion of the two labelled opposite-colour root fragments}.
\tag{9}
\]

If \(Z_g\ne Z_0\), the patch-free \(Z_g\)-flip at the canonical endpoint
cannot be root-admissible either: it would be a canonical--canonical rooted
bond, forbidden by the parent kill-cover hypothesis through Note 108's
canonical induced-graph identity.  A root-admissible flip at the cross
endpoint would only produce a cross--cross rooted bond.

This is the full reach of the parent kill-cover assumption on exterior
colourings.  It excludes a patch-free flip only when (i) the starting
endpoint is canonical, (ii) the flipped endpoint is still
root-admissible, and (iii) the exterior cycle is \(Z_g\).  It says nothing
about gate-free exterior flips, flips based at a cross cell, or NAE
colourings which fail root-admissibility.

This can be stated as one obstruction with exact quantifiers.  Say that the
complete child family has the **wrong-interval-island obstruction**
\(\mathsf{WII}\) when

\[
\begin{aligned}
&\forall b,\ \forall\kappa\in{\cal A}_{\cal C}^{b},\
 \forall\xi\in{\cal A}_{U}^{1-b},\\[-2mm]
&\qquad
 \bigl[\exists K\in\pi_0(H[D]):K\cap J_A=\varnothing\bigr]
 \ \vee\
 \bigl[\exists L\in\pi_0(H[\bar D]):L\cap J_B=\varnothing\bigr],
\\[1mm]
&\forall b,\ \forall\kappa\in{\cal A}_{\cal C}^{b},\
 \forall\xi\in{\cal A}_{V}^{1-b},\\[-2mm]
&\qquad
 \bigl[\exists K\in\pi_0(H[D]):K\cap J_B=\varnothing\bigr]
 \ \vee\
 \bigl[\exists L\in\pi_0(H[\bar D]):L\cap J_A=\varnothing\bigr].
\end{aligned}
\tag{10}
\]

Universal quantification makes missing opposite-gate occupancy a vacuous
instance of the same obstruction; it is not a second case.

**Proposition 3 (unique exact obstruction).**  Under the hypotheses in the
question,

\[
\boxed{\Gamma({\cal C},{\cal X})=\varnothing
\quad\Longleftrightarrow\quad \mathsf{WII}.}
\tag{11}
\]

For a minimum-cycle pair witnessing a nonvacuous instance of
\(\mathsf{WII}\), every exterior nongate boundary cycle is doubly
root-blocked by (9).  The only exterior cycle not subject to that
minimality statement is \(Z_g\).  If \(Z_g\ne Z_0\), its flip at the
canonical endpoint is root-blocked by the kill-cover condition itself.
After all root-admissible neutral reductions, the two possible
manifestations of the *same* obstruction are therefore:

* a local/gate two-cycle diagonal \(Z_0\ne Z_g\); or
* an exterior nongate cycle whose flip is rank- or label-blocked at both
  endpoints.

These are not separate hypotheses: they are the two irreducible region-tree
shapes realizing the quantified condition (10).

## 4. Why the current notes do not decide the general statement

The parent assumptions imply that the parent rooted bond graph is nonempty
and that the child has no canonical--canonical rooted bond.  They do not,
in Notes 108, 109, or 111, imply any of the following:

* opposite-gate occupancy of both a canonical and a cross child cell;
* alignment \(Z_0=Z_g\) for some such pair;
* root-admissibility of one endpoint after a patch-free exterior-cycle
  flip.

Note 109 tests the last property exactly once a shore is given, but does not
force the rank equality or root-label separation.  Note 111's prescribed
parent-lift calculus cannot fill this gap, because its actual nondirect
example proves that every successful canonical--cross bond may lack a
parent-bond ancestor.  Its finite theorem supplies (7) only in its stated
finite stratum.

The rank identity alone also does not give the missing convexity.  Two
disjoint transition switches between the same two cycles of a two-factor
can have circuit-count table

\[
 \begin{array}{c|cc}
 &0&1\\ \hline
 0&2&1\\
 1&1&2
 \end{array}.
\tag{12}
\]

Each single switch merges the two cycles, whereas performing both splits
the resulting circuit again.  Thus diagonally opposite target states can
coexist while both one-switch intermediate states fail the scalar part of
root-admissibility.  This is only a transition-system obstruction, not an
actual plane-brace counterexample, but it shows why component minimality
cannot silently assume endpoint convexity.

Accordingly the three authoritative notes do not distinguish truth from
falsehood of the arbitrary-order canonical--cross statement.  They reduce
it exactly to exclusion of the single wrong-interval-island obstruction
(10), with Proposition 3 identifying its irreducible region-tree
manifestations.
An actual counterexample must realize one of those mechanisms in a
4-connected Eulerian triangulation split; a proof must rule all of them out
using incidence beyond the present rank calculus.
