#!/usr/bin/env python3
"""Test a simultaneous expected-degree certificate in the five frozen braces.

For every root and fixed two-block port fibre, test whether a probability
distribution on its exact Y-degree vectors has coordinatewise expectation
at most two.  This is only a finite diagnostic for the proposed convex
interface; it is not a proof for arbitrary braces.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path
import sys

import networkx as nx
import numpy as np
from scipy.optimize import linprog


HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "worker-cap-profile-measure"
sys.path.insert(0, str(SOURCE))


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


base = load("degree_box_base", SOURCE / "measure_fixed_brace_cap_profiles.py")
measure = load(
    "degree_box_measure",
    SOURCE / "measure_fixed_brace_multi_hole_three_port_profiles.py",
)


def main() -> None:
    checked = 0
    minimum_margin = float("inf")
    first_failure = None
    for name, graph6 in base.GRAPH6:
        graph = nx.from_graph6_bytes(graph6.encode())
        for root in sorted(graph):
            y_order, fibres, _ = measure.rooted_forest_vectors(graph, root)
            for fibre_index, vectors in enumerate(fibres):
                if not vectors:
                    continue
                matrix = np.asarray(vectors, dtype=float).T
                count = len(vectors)
                result = linprog(
                    c=np.zeros(count),
                    A_ub=matrix,
                    b_ub=np.full(len(y_order), 2.0),
                    A_eq=np.ones((1, count)),
                    b_eq=np.ones(1),
                    bounds=(0.0, None),
                    method="highs",
                )
                checked += 1
                if not result.success:
                    first_failure = {
                        "graph": name,
                        "graph6": graph6,
                        "root": root,
                        "fibre": fibre_index,
                        "y_order": y_order,
                        "vectors": len(vectors),
                        "message": result.message,
                    }
                    break
                expectation = matrix @ result.x
                margin = float(np.min(2.0 - expectation))
                minimum_margin = min(minimum_margin, margin)
            if first_failure:
                break
        if first_failure:
            break

    print("fixed_fibres_checked", checked)
    print("minimum_coordinate_margin", minimum_margin)
    print("first_failure", first_failure)
    if first_failure is None:
        print("FROZEN_BRACE_DEGREE_BOX_FEASIBLE")
    else:
        print("FROZEN_BRACE_DEGREE_BOX_FAILURE")


if __name__ == "__main__":
    main()
