#!/usr/bin/env python3
"""Constant-size checker for the R2 pulse-4 fixed cube certificate.

This is deliberately not a census: it enumerates only the faces/sites of
one fixed cube expansion and compares one/two further fixed expansions with
the finite CEN/UV words of the same depth.
"""

from itertools import permutations, product
from collections import Counter, defaultdict
import networkx as nx


def cube():
    G = nx.Graph()
    G.add_edges_from([
        (0, 1), (1, 2), (2, 3), (3, 0),
        (4, 5), (5, 6), (6, 7), (7, 4),
        (0, 4), (1, 5), (2, 6), (3, 7),
    ])
    return G


def expand(G, site):
    u, v, x, y = site
    H = G.copy()
    H.remove_edges_from([(u, v), (x, y)])
    a, b, c, d = range(max(H.nodes) + 1, max(H.nodes) + 5)
    H.add_edges_from([
        (u, a), (a, b), (b, v), (x, c),
        (c, d), (d, y), (a, d), (b, c),
    ])
    return H, (a, b, c, d)


def faces(G):
    ok, emb = nx.check_planarity(G)
    assert ok
    seen = set()
    out = []
    for u, v in emb.edges():
        if (u, v) not in seen:
            f = emb.traverse_face(u, v, seen)
            out.append(tuple(f))
    return emb, out


def rotation(emb):
    return {v: tuple(emb.neighbors_cw_order(v)) for v in sorted(emb)}


def legal_oriented_sites(G):
    """Canonical orientations (u,v,...,x,y,...) with u,x same colour."""
    colour = nx.bipartite.color(G)
    ans = set()
    _, fs = faces(G)
    for f in fs:
        for oriented_f in (f, tuple(reversed(f))):
            m = len(oriented_f)
            boundary_edges = [
                (oriented_f[i], oriented_f[(i + 1) % m]) for i in range(m)
            ]
            for i, j in permutations(range(m), 2):
                u, v = boundary_edges[i]
                x, y = boundary_edges[j]
                if len({u, v, x, y}) < 4 or colour[u] != colour[x]:
                    continue
                ans.add((u, v, x, y))
    return sorted(ans)


def validate(G, site):
    u, v, x, y = site
    assert len({u, v, x, y}) == 4
    assert G.has_edge(u, v) and G.has_edge(x, y)
    assert all(d == 3 for _, d in G.degree())
    assert nx.is_bipartite(G)
    assert nx.check_planarity(G)[0]
    assert nx.node_connectivity(G) >= 3
    assert site in legal_oriented_sites(G)


def old_words(depth):
    result = []
    for word in product(("CEN", "UV"), repeat=depth):
        G = cube()
        site = (0, 1, 2, 3)
        for letter in word:
            G, (a, b, c, d) = expand(G, site)
            site = (b, c, d, a) if letter == "CEN" else (site[0], a, b, site[1])
        result.append((word, G, site))
    return result


def face_incidence_signature(G):
    incident = defaultdict(list)
    for face in faces(G)[1]:
        for v in face:
            incident[v].append(len(face))
    return Counter(tuple(sorted(incident[v])) for v in G)


def main():
    Q = cube()
    root = (0, 1, 2, 3)
    validate(Q, root)
    G1, born1 = expand(Q, root)
    assert born1 == (8, 9, 10, 11)
    new_operation_successor = (0, 3, 11, 8)
    validate(G1, new_operation_successor)
    G2, born2 = expand(G1, new_operation_successor)
    assert born2 == (12, 13, 14, 15)
    strictness_site = (0, 12, 7, 4)
    validate(G2, strictness_site)
    G3, born3 = expand(G2, strictness_site)
    assert born3 == (16, 17, 18, 19)
    validate(G3, (17, 18, 19, 16))

    expected_new = Counter({(4, 6, 6): 12, (4, 4, 6): 6, (6, 6, 6): 2})
    assert face_incidence_signature(G3) == expected_new
    old_signatures = {}
    for word, H, _ in old_words(3):
        sig = face_incidence_signature(H)
        old_signatures["-".join(word)] = sig
        assert sig != expected_new
        assert not nx.is_isomorphic(G3, H)

    for name, G, site in (
        ("G1", G1, new_operation_successor),
        ("G2", G2, strictness_site),
        ("G3", G3, (17, 18, 19, 16)),
    ):
        emb, _ = faces(G)
        print(name + "_SITE", site)
        print(name + "_EDGES", sorted(tuple(sorted(e)) for e in G.edges()))
        print(name + "_ROTATION", rotation(emb))
    print("NEW_FACE_INCIDENCE_SIGNATURE", expected_new)
    print("OLD_FACE_INCIDENCE_SIGNATURES", old_signatures)
    print("R2_PULSE4_FIXED_SUCCESSOR_CERTIFICATE_VERIFIED")


if __name__ == "__main__":
    main()
