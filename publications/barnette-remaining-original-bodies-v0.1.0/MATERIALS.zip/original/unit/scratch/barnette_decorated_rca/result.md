# Decorated RCA is a rooted exact-one three-forest problem in the dual

Let \(F\) be a simple plane cubic bipartite brace, let \(e=rs\), and put
\(T=F^*\).  Write \(a=e^*=xy\), where \(x,y\) are the two dual vertices
(the two faces of \(F\)) on the sides of \(e\).  The two triangular faces
of \(T\) corresponding to the primal vertices \(r,s\) are denoted by
\(\tau_r,\tau_s\); they share the edge \(a\).

This note gives an exact topological reduction of the proposition in the
task.  It does not prove or refute RCA.

## 1. Dual states

For a perfect matching \(M\ni e\), let

\[
K=M^*\subseteq E(T),\qquad L=K-\{a\}=(M-\{e\})^*.
\]

Because \(F\) is cubic, every face \(\tau_v\) of \(T\) corresponding to a
primal vertex \(v\) is a triangle.  The perfect-matching condition is
exactly

\[
|K\cap \partial\tau_v|=1\quad\text{for every }v\in V(F).
\tag{1}
\]

Since the unique selected edge on each of \(\tau_r,\tau_s\) is \(a\), the
subgraph \(L\) satisfies

\[
|L\cap\partial\tau_r|=|L\cap\partial\tau_s|=0,
\qquad
|L\cap\partial\tau_v|=1\quad(v\ne r,s).
\tag{2}
\]

Conversely, every edge set \(L\) satisfying (2) gives a perfect matching
\(M\ni e\) by taking the primal edges dual to \(L\cup\{a\}\).  Thus (2)
is an exact parametrization, not a relaxation.

Call such an \(L\) a *rooted exact-one state*.  Every rooted exact-one
state has \(|V(T)|=n+2\) and \(|L|=n-1\), where \(|V(F)|=2n\).

## 2. Root separation is one dual connectivity bit

Let \(D=F-M\).  Then

\[
r,s\text{ lie on distinct cycles of }D
\quad\Longleftrightarrow\quad
x,y\text{ lie in the same component of }L.
\tag{3}
\]

Indeed, the right side says that \(a\) lies on a cycle of
\(K=L+a\).  By planar cycle--cut duality this is equivalent to a primal
cut contained in \(M\) and containing \(e\).  Since \(D\) uses no edge of
that cut and \(e\) crosses its shores, the two endpoints of \(e\) are in
distinct components, hence distinct cycles, of \(D\).  Conversely, if
the \(D\)-cycles containing \(r\) and \(s\) are distinct, the cut of the
vertex set of the \(r\)-cycle is contained in \(M\) and contains \(e\).
Its dual is Eulerian, so the edge \(a\) belongs to a dual cycle in \(K\),
which is the right side of (3).

Equivalently, (3) follows from the graphic-dual rank identity: adding
\(e\) to \(D\) raises rank exactly when \(r,s\) are in different
components, and this is exactly when adding \(a\) to \(L\) does not raise
dual rank.

## 3. The cycle count is the dual cycle rank plus two

Let \(k=c(D)\), and let

\[
\beta(H)=|E(H)|-|V(H)|+\operatorname{comp}(H)
\]

denote the cycle rank of a spanning graph.  Plane graphic-matroid duality
gives

\[
\beta(K)=k-1.
\tag{4}
\]

For completeness, \(r_F(D)=2n-k\), \(r_F(E(F))=2n-1\), and

\[
r_T(K)=|M|+r_F(D)-r_F(E(F))=n-k+1,
\]

so \(\beta(K)=n-r_T(K)=k-1\).  Under the separated-root condition (3),
\(a\) is not a bridge of \(K\).  Deleting it therefore lowers cycle rank
by one without changing the number of components.  Hence

\[
\boxed{\quad c(D)=\beta(L)+2\quad}
\tag{5}
\]

for every separated rooted state.

In particular, \(D\) has exactly two cycles if and only if \(L\) is a
forest and \(x,y\) belong to the same tree.  Because \(L\) has \(n-1\)
edges on \(n+2\) vertices, such a forest automatically has exactly three
components.  Thus the exact dual target is:

> **Rooted exact-one three-forest.** Find a spanning forest \(L\subseteq
> T-a\) such that (2) holds and the two ends \(x,y\) of \(a\) lie in the
> same tree of \(L\).

Equivalently, \(K=L+a\) has three components and total cycle rank one;
its unique cyclic component contains \(a\).

## 4. Exact translation of the decorated move

Let \(M,N\ni e\) be perfect matchings, with separated complementary
factors \(D=F-M\) and \(D'=F-N\), and let \(L_M,L_N\) be their rooted
exact-one states.  The symmetric difference

\[
U=M\triangle N
\]

is a disjoint union of \(M\)-alternating cycles avoiding \(e\).  Conversely,
every such alternating union produces a unique \(N=M\triangle U\).
Therefore there is no additional reachability condition between dual
states.

For the endpoint pairings \(\alpha,\beta\) of Note 060, if \(p\) old
factor cycles are affected and \(q\) new factor cycles result, then

\[
q-p=c(D')-c(D)
=\beta(L_N)-\beta(L_M).
\tag{6}
\]

The marked-component test in Note 060 is, by (3), exactly the assertion
that the two ends of \(a\) are connected in \(L_N\).  Hence the full
decorated requirement

\[
\text{root marks preserved and }q<p
\]

is equivalent to

\[
x\leftrightarrow y\text{ in }L_N
\quad\text{and}\quad
\beta(L_N)<\beta(L_M).
\tag{7}
\]

This is the promised removal of the cyclic attachment pairings: planarity
packages all of their globally relevant information into rooted dual
connectivity and cycle rank.

## 5. Exact conclusion and unresolved boundary

For a fixed pair \((F,e)\), define \(\mathcal L_e\) to be the rooted
exact-one states satisfying (2) and \(x\leftrightarrow y\).  Note 058
implies \(\mathcal L_e\ne\varnothing\).  The proposition in the task is
equivalent to each of the following:

\[
\min_{L\in\mathcal L_e}\beta(L)=0;
\tag{8}
\]

\[
\mathcal L_e\text{ contains a rooted exact-one three-forest};
\tag{9}
\]

and, in the original notation, \(\mu_F(e)=2\).

The equivalence is pointwise in every simple plane cubic bipartite brace
\(F\) and every edge \(e\).  If (9) holds, symmetric difference with its
matching gives from every state with \(c(D)>2\) one alternating union with
preserved roots and \(q<p\).  If (9) fails, a minimum-cycle-rank member of
the finite nonempty set \(\mathcal L_e\) is a counterexample to the move
proposition.

The weakest load-bearing step is (3), the bridge/cycle form of planar
duality.  After that, (5) is a rank identity and (6) is the exact
cycle-count formula already present in Note 060.

**Evidence level:** proof-level strict topological reduction.  No finite
census or solver assertion is used.

**Unresolved boundary:** it remains unknown whether every dual of a simple
plane cubic bipartite brace admits the rooted exact-one three-forest (9)
for every distinguished edge.  Brace/2-extendability has not yet been used
to force acyclicity under the facial loads (2) while retaining the single
connectivity demand \(x\leftrightarrow y\).  Proving or refuting precisely
that forest-existence statement proves or refutes RCA.
