# Single leaf task: decorated planar RCA

Work only in the Barnette unit:

    [local archival reference]

Read README.md and Notes 057, 058, and 060. Do not modify permanent notes or
papers. Put any exploration only under this scratch directory.

Let \(F\) be a simple plane cubic bipartite brace, \(e=rs\), and let
\(M\ni e\) be a perfect matching such that \(r,s\) lie on distinct cycles of
\(D=F-M\). For an \(M\)-alternating union avoiding \(e\), use the endpoint
pairings \(\alpha,\beta\) and \(p,q\) from Note 060.

Determine this single proposition:

> If \(c(D)>2\), must there exist an alternating union whose endpoint pairing
> preserves the two root marks and has \(q<p\)?

This proposition is equivalent to RCA globally, so do not relabel ordinary
Kempe connectivity as progress. Attack the cyclic attachment/ribbon or
primal-dual structure that the bare cycle quotient omits. Stop at one of:

1. a proof;
2. a genuine simple plane cubic bipartite brace counterexample with exact
   verification;
3. a strict topological reduction identifying a thinner necessary and
   sufficient decorated condition;
4. a route closure showing a proposed invariant cannot decide it.

End with: exact conclusion and quantifiers; weakest load-bearing argument;
evidence level; unresolved boundary.
