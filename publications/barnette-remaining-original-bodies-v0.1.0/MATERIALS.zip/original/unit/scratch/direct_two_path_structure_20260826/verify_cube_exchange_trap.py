#!/usr/bin/env python3
"""Verify a cube obstruction to one-element three-base repair.

The calculation is deliberately confined to one explicit plane brace.  Dual
edges retain their primal-edge labels, so facial partition loads are checked
as degrees of the corresponding primal labels.
"""

from itertools import combinations


def edge(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


VERTICES = tuple(range(8))
EDGES = frozenset(
    edge(u, u ^ (1 << bit))
    for u in VERTICES
    for bit in range(3)
    if u < (u ^ (1 << bit))
)

# Six square faces of the standard cube embedding.
FACES = (
    (0, 2, 3, 1),
    (4, 5, 7, 6),
    (0, 1, 5, 4),
    (2, 6, 7, 3),
    (0, 4, 6, 2),
    (1, 3, 7, 5),
)

ROOT = 0
A, B, S = 4, 2, 1
DA, DB = edge(ROOT, A), edge(ROOT, B)
X = frozenset((1, 2, 4, 7))
Y = frozenset((0, 3, 5, 6))
E0 = tuple(sorted(EDGES - {edge(ROOT, x) for x in (A, B, S)}))

BAD_PATH = (4, 6, 7, 5, 1, 0, 2, 3)
GOOD_PATH = (4, 6, 2, 0, 1, 5, 7, 3)
H_BAD = frozenset((edge(1, 3), edge(2, 6), edge(3, 7), edge(4, 5)))
H_GOOD = frozenset((edge(1, 3), edge(2, 3), edge(4, 5), edge(6, 7)))


def path_edges(path: tuple[int, ...]) -> frozenset[tuple[int, int]]:
    return frozenset(edge(u, v) for u, v in zip(path, path[1:]))


def dual_endpoints() -> dict[tuple[int, int], tuple[int, int]]:
    incident: dict[tuple[int, int], list[int]] = {e: [] for e in EDGES}
    for face_index, face in enumerate(FACES):
        for u, v in zip(face, face[1:] + face[:1]):
            incident[edge(u, v)].append(face_index)
    assert all(len(indices) == 2 for indices in incident.values())
    return {label: tuple(indices) for label, indices in incident.items()}


DUAL_ENDS = dual_endpoints()


def dual_tree(labels: frozenset[tuple[int, int]]) -> bool:
    if len(labels) != len(FACES) - 1:
        return False
    adjacency = {face: set() for face in range(len(FACES))}
    for label in labels:
        u, v = DUAL_ENDS[label]
        adjacency[u].add(v)
        adjacency[v].add(u)
    reached = {0}
    stack = [0]
    while stack:
        u = stack.pop()
        for v in adjacency[u] - reached:
            reached.add(v)
            stack.append(v)
    return len(reached) == len(FACES)


def free_face(labels: frozenset[tuple[int, int]]) -> int | None:
    degree = {v: 0 for v in VERTICES}
    for u, v in labels:
        degree[u] += 1
        degree[v] += 1
    if any(degree[x] != 1 for x in X):
        return None
    if degree[ROOT] != 0:
        return None
    candidates = [y for y in Y - {ROOT} if degree[y] == 2]
    if len(candidates) != 1:
        return None
    free = candidates[0]
    if any(degree[y] != 1 for y in Y - {ROOT, free}):
        return None
    return free


def three_base(labels: frozenset[tuple[int, int]]) -> bool:
    return free_face(labels) is not None and dual_tree(labels | {DA})


def four_base(labels: frozenset[tuple[int, int]]) -> bool:
    return three_base(labels) and dual_tree(labels | {DB})


def main() -> None:
    assert len(EDGES) == 12 and len(E0) == 9
    assert path_edges(BAD_PATH) == EDGES - H_BAD - {DA}
    assert path_edges(GOOD_PATH) == EDGES - H_GOOD - {DA}
    assert free_face(H_BAD) == free_face(H_GOOD) == 3
    assert three_base(H_BAD) and not four_base(H_BAD)
    assert four_base(H_GOOD)

    all_states = tuple(frozenset(choice) for choice in combinations(E0, 4))
    three = tuple(state for state in all_states if three_base(state))
    four = tuple(state for state in three if four_base(state))

    degree_feasible_neighbours = []
    fixed_free_neighbours = []
    three_base_neighbours = []
    for removed in H_BAD:
        for added in set(E0) - H_BAD:
            candidate = (H_BAD - {removed}) | {added}
            if free_face(candidate) is not None:
                degree_feasible_neighbours.append(candidate)
                if free_face(candidate) == free_face(H_BAD):
                    fixed_free_neighbours.append(candidate)
                if three_base(candidate):
                    three_base_neighbours.append(candidate)

    nearest_four_distance = min(len(H_BAD ^ state) // 2 for state in four)
    nearest_four = tuple(state for state in four if len(H_BAD ^ state) // 2 == nearest_four_distance)

    assert len(degree_feasible_neighbours) == 3
    assert not fixed_free_neighbours
    assert len(three_base_neighbours) == 1
    assert all(four_base(state) for state in three_base_neighbours)
    assert nearest_four_distance == 1

    print(
        {
            "graph": "cube_Q3",
            "three_common_bases": len(three),
            "four_common_bases": len(four),
            "bad_free_face": free_face(H_BAD),
            "degree_feasible_one_exchanges_from_bad": len(degree_feasible_neighbours),
            "fixed_free_face_one_exchanges_from_bad": len(fixed_free_neighbours),
            "three_base_one_exchanges_from_bad": len(three_base_neighbours),
            "minimum_swaps_from_bad_to_four_base": nearest_four_distance,
            "repair_symmetric_difference": sorted(H_BAD ^ H_GOOD),
        }
    )


if __name__ == "__main__":
    main()
