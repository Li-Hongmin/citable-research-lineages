# Direct two-path 四公共基：有序 Hamilton 路归约与 fundamental-exchange 边界

## 精确结论

Note 063(12)--(14) 的一般存在命题本轮没有被证明或反驳。它可进一步严格等价
为一个**有序 Hamilton 路**命题；同时，所建议的“先任取前三公共基，再用一次
fundamental-bond exchange 强制第四基”路线是假的，即使 \(F\) 是真实 simple
plane cubic bipartite brace。

更精确地：

1. 固定自由面 \(y\) 后，保持两个 partition bases 的非平凡单元素交换根本不
   存在。
2. 即使允许一次交换同时把自由面从 \(y\) 移到 \(y'\)，Note 062 的 16 点 plane
   brace 也有一个前三公共基 \(H_0\)，其唯一合法前三基邻居仍不满足第四基；
   \(H_0\) 在完整单元素前三基交换图中距任意四公共基恰为 \(3\)。

因此，平面性、\(2\)-extendability、面分块和 ordinary fundamental exchange
本身不强制 \(d_b\)。任何一般正证明至少必须全局选择初始三公共基，或允许受控的
多步 free-face transport / 多边 alternating exchange。

## 三公共基恰是一个根有序未定的 Hamilton 路

沿用 Note 063 的记号。把
\(H\subseteq E(T)\setminus E(\tau_r)\) 中的 dual edge 继续用其 primal edge
标号表示，并设

\[
K_H=\{e\in E(F):e^*\in H\}.
\]

若

\[
H\in\mathcal B(\mathcal P_X)\cap
\mathcal B(\mathcal P_{Y,y})\cap\mathcal B(M(T/d_a)),
\tag{1}
\]

则 \(H+d_a\) 是 \(T\) 的 spanning tree。由 plane graphic duality，

\[
R_a=E(F)\setminus(K_H\cup\{ra\})
\tag{2}
\]

是 \(F\) 的 spanning tree。两个 partition loads 又给出：

- \(a,y\) 在 \(R_a\) 中度数为 \(1\)；
- 其余所有顶点度数为 \(2\)，特别地 \(r\) 的两条边是 \(rb,rs\)。

因此 \(R_a\) 是从 \(a\) 到 \(y\) 的 Hamilton 路，且在根处只能以两个次序之一
通过：

\[
a\leadsto b-r-s\leadsto y,
\qquad\text{或}\qquad
a\leadsto s-r-b\leadsto y.
\tag{3}
\]

反向取 (2) 的 dual complement 也立即恢复 (1)，所以这是等价而非仅必要条件。

第四基恰好选出 (3) 的第一个次序。事实上

\[
H\in\mathcal B(M(T/d_b))
\Longleftrightarrow
E(F)\setminus(K_H\cup\{rb\})\text{ 是 spanning tree}.
\tag{4}
\]

若次序是 \(a\leadsto b-r-s\leadsto y\)，删去 \(r\) 后得到端点对
\(\{a,b\}\) 与 \(\{s,y\}\)，(4) 成立；若次序相反，则 (4) 的边集在
\(a\leadsto s\) 一侧闭成圈，同时留下 \(b\leadsto y\) 分量，故不成立。

所以 Note 063(12)--(14) 还等价于：对每个 \((F,r,s)\)，固定任意命名
\(\{a,b\}=N(r)\setminus\{s\}\)，存在某个 \(y\in Y\setminus\{r\}\) 和一条
从 \(a\) 到 \(y\) 的 Hamilton 路，以指定次序经过 \(b-r-s\)。这只是严格归约；
plane brace 并无已知 Hamilton-laceability 定理直接给出该有序结论。

## Fundamental-cycle 的精确翻转式

令

\[
B=H+d_a
\]

为前三基给出的 dual spanning tree，并定义最后一位

\[
\varepsilon_B=\mathbf 1\{d_a\in C_B(d_b)\},
\tag{5}
\]

其中 \(C_B(g)\) 是非树边 \(g\) 的 fundamental cycle。把 \(d_a\) 换成
\(d_b\) 后仍为树，当且仅当 \(\varepsilon_B=1\)；这正是第四基条件。

设一个 tree pivot 为

\[
B'=B-e+f,\qquad e\in H,\quad f\notin B,\quad e\in C_B(f).
\tag{6}
\]

fundamental-cycle 的标准对称差更新给出

\[
\boxed{
\varepsilon_{B'}=\varepsilon_B\oplus
\mathbf 1\{e\in C_B(d_b)\}
\cdot
\mathbf 1\{d_a\in C_B(f)\}.}
\tag{7}
\]

因此一次 pivot 只有在被删边同时落在 \(d_b\) 的 fundamental cycle，且新边的
fundamental cycle 同时经过 \(d_a\) 时，才会翻转第四基位。普通 graphic basis
exchange 只保证 (6)，不保证 (7) 中另外两个交叉条件。

两个 partition matroids 使这个缺口更尖锐。若自由面 \(y\) 固定，
\(H-e+f\) 同时保持两个 partition bases，就要求 \(e,f\) 同属一个 \(X\)-face
block 且同属一个 \(Y\)-face block。每条 ground edge 正由这两个 primal 端点
确定；由于 \(F\) simple，只能 \(e=f\)。故固定 \(y\) 的单元素交换图完全没有
非平凡边。

若允许自由面改变，唯一可能的 pivot 形式是

\[
e=xy,\qquad f=xy',
\tag{8}
\]

其中 \(y\) 是旧 free face、\(y'\) 是新 free face；它沿 primal 二步
\(y-x-y'\) 搬运唯一的 load-two 缺陷。brace 的 \(2\)-extendability 并不自动
提供同时满足 (6)--(7) 的这种搬运。

## Pairwise common bases 不具有 fixed-\(y\) Helly 性

同一个 Note 062 的真实 plane brace 还给出更直接的四-matroid 路线反模型。
仍取

\[
r=0,\qquad s=8,\qquad a=9,\qquad b=10,
\]

但固定 free face \(y=3\)。依次记四个 matroid 为

\[
\mathcal P_X,\quad \mathcal P_{Y,3},\quad M(T/d_a),\quad M(T/d_b).
\]

在共同 ground set \(E(T)\setminus E(\tau_r)\) 上，六个两两公共基集合的基数
（按 pair \(01,02,03,12,13,23\)）分别为

\[
(15,\ 356,\ 356,\ 192,\ 468,\ 5436),
\tag{9}
\]

全部非空；但四重公共基集合为空。故即使共同对象来自 actual plane cubic
bipartite brace，下面的 fixed-\(y\) Helly 推理仍为假：

\[
\bigl[\text{六个 pairwise common-base sets 全部非空}\bigr]
\not\Longrightarrow
\bigl[\text{存在 four-common base}\bigr].
\tag{10}
\]

这不是 universal target 反例，因为同一 root split 在
\(y=1,2,5,6\) 时各有两个四公共基；\(y=3,4,7\) 时则为零。它精确说明：
一般证明必须使用外层 \(\exists y\) 的全局选择，不能固定任意 free face 后只调用
pairwise matroid intersection。

## 真实 plane-brace 的三步 exchange trap

取 Note 062 的 16 点 plane brace，使用其 equation (1) 的十个 facial
boundaries，令

\[
r=0,\qquad s=8,\qquad a=9,\qquad b=10.
\]

以下 dual edge set（仍写 primal labels）以 \(y=2\) 为 free face：

\[
\begin{split}
H_0=\{&(1,9),(2,8),(2,10),(3,11),\\
       &(4,12),(5,13),(6,15),(7,14)\}.
\end{split}
\tag{11}
\]

它是 \(\mathcal P_X,\mathcal P_{Y,2},M(T/d_a)\) 的公共基，但不是
\(M(T/d_b)\) 的基。其 (2) 中的 primal Hamilton 路为

\[
9-3-13-7-15-5-11-1-8-0-10-4-14-6-12-2.
\tag{12}
\]

从端点 \(a=9\) 看，(12) 以错误次序 \(s-r-b=8-0-10\) 通过根。

在允许 \(y\) 改变的完整单元素 exchange graph 中，\(H_0\) 只有一个前三基邻居：

\[
H_1=H_0-(2,10)+(4,10),
\tag{13}
\]

其新 free face 是 \(4\)，但第四基仍失败。到四公共基的最短路线恰需三步：

\[
\begin{aligned}
H_1&=H_0-(2,10)+(4,10),\\
H_2&=H_1-(4,12)+(6,12),\\
H_3&=H_2-(6,15)+(5,15).
\end{aligned}
\tag{14}
\]

\(H_0,H_1,H_2\) 均只满足前三基，\(H_3\) 才同时满足四基。这给出 actual
plane-brace 反模型，严格否定“任取前三基后一次（甚至两次）fundamental
exchange 必命中 \(d_b\)”的选择规则。它不反驳目标本身：同一 fibre 有八个四
公共基，且 (14) 展示了一个成功三步修复。

同目录 verifier 独立检查 plane rotation、cubic bipartition、完整 strict Hall
brace 条件、dual tree 条件和 exchange graph。该固定 fibre 恰有 106 个
face-load states、32 个前三公共基和 8 个四公共基；24 个前三基是坏的，其中
15 个没有一步 good neighbour。\(H_0\) 到 good set 的图距离为 3。

## 结论边界

- **精确结论：** 四公共基的一般存在性仍未知；它严格等价于上述有序根穿越
  Hamilton 路。固定-\(y\) ordinary exchange 完全退化，variable-\(y\) 的一次或
  两次 fundamental exchange 也不由 plane-brace 结构强制；fixed-\(y\) 的
  pairwise common-base Helly 原理亦被真实 plane brace 否定。
- **最薄弱论证：** “距离恰为 3”的下界依赖对一个显式 16 点 fibre 的有限完整
  枚举；fixed-\(y\) Helly 反例同样是显式有限枚举。它们证明选择规则失败，但
  不给出任意阶 exchange distance 的界。
- **证据等级：** 有序-Hamilton 路等价和翻转式 (7) 为解析证明级；三步 trap
  是真实 plane brace 上可逐项核验的有限证明级反模型。没有进行相邻扩阶 census。
- **未决边界：** 尚未知是否总能从一开始选择 \(\varepsilon_B=1\) 的前三基，或
  是否每个 actual plane-brace 三基交换分量总会命中 good set。Note 062 的该
  fibre 四个交换分量全都含 good state，但这只是单实例事实，不能外推一般命题。
