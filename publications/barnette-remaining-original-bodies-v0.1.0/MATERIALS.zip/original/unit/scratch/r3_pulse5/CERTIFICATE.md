# Complete real-history certificate for Note 170

The cube starts with the edge list in Note 170. Each displayed row is the
cyclic neighbor order at that vertex; all four rotation systems use the same
orientation. The graph at depth three is `H` for both contexts. The two
contexts differ only in their final ordered marked sites.

| vertex | cube Q | G1 | Z | H |
|---:|:---|:---|:---|:---|
| 0 | 1,4,3 | 3,8,4 | 3,12,4 | 3,16,4 |
| 1 | 0,2,5 | 5,9,2 | 5,15,2 | 5,15,2 |
| 2 | 1,3,6 | 1,10,6 | 1,10,6 | 1,10,6 |
| 3 | 2,0,7 | 0,7,11 | 0,7,11 | 0,7,19 |
| 4 | 7,0,5 | 7,0,5 | 7,0,5 | 7,0,5 |
| 5 | 4,1,6 | 4,1,6 | 4,1,6 | 4,1,6 |
| 6 | 5,2,7 | 2,7,5 | 2,7,5 | 2,7,5 |
| 7 | 3,4,6 | 3,4,6 | 3,4,6 | 3,4,6 |
| 8 | — | 9,0,11 | 9,13,11 | 9,13,11 |
| 9 | — | 10,1,8 | 10,14,8 | 10,14,8 |
| 10 | — | 2,9,11 | 2,9,11 | 2,9,11 |
| 11 | — | 8,3,10 | 8,3,10 | 8,18,10 |
| 12 | — | — | 13,15,0 | 17,13,15 |
| 13 | — | — | 8,14,12 | 12,8,14 |
| 14 | — | — | 15,13,9 | 13,9,15 |
| 15 | — | — | 12,14,1 | 14,1,12 |
| 16 | — | — | — | 17,0,19 |
| 17 | — | — | — | 18,12,16 |
| 18 | — | — | — | 11,17,19 |
| 19 | — | — | — | 16,3,18 |

The selected sites and their facial arcs are:

| graph | ordered site | witnessing face | residual arc lengths |
|:---|:---|:---|:---|
| Q | (0,1,2,3) | (0,1,2,3) | (1,1) |
| G1 | (0,8,9,1) | (0,8,9,1,5,4) | (1,3) |
| Z | (0,12,11,3) | (0,12,13,8,11,3) | (3,1) |
| H, first context | (0,16,15,1) | (0,16,17,12,15,1,5,4) | (3,3) |
| H, second context | (0,16,5,4) | (0,16,17,12,15,1,5,4) | (5,1) |

At the three operations, the deleted site edges are respectively
`{01,23}`, `{0-8,9-1}`, and `{0-12,11-3}`. The eight edges born at each
operation are

```
B0 = {0-8,8-9,9-1,2-10,10-11,11-3,8-11,9-10}
B1 = {0-12,12-13,13-8,9-14,14-15,15-1,12-15,13-14}
B2 = {0-16,16-17,17-12,11-18,18-19,19-3,16-19,17-18}
```

The kernel vertices are `0..7`; the birth layers own `8..11`, `12..15`,
and `16..19`. The surviving kernel edges are the ten cube edges except
`01,23`. The surviving born edges are `B0\{0-8,9-1,11-3}` (five),
`B1\{0-12}` (seven), and all eight of `B2`. The final cap owns exactly the
two edges of its marked site:

```
cap(q1) = {0-16,15-1};  owner counts (kernel,B0,B1,B2,cap) = (10,5,6,7,2)
cap(q2) = {0-16,5-4};   owner counts (kernel,B0,B1,B2,cap) = (9,5,7,7,2)
```

Both owner sums are 30, the number of edges of H. Earlier site edges are
virtual seals in inverse steps. Restoring them after removing the appropriate
four birth vertices recovers `Z`, `G1`, and `Q` in order. All four graphs have
orders `8,12,16,20`, degree three, a bipartition, spherical embeddings from
the displayed rotations, and vertex connectivity three. The two ordered
targets are the same in both contexts: `e=2-6`, `f=9-10`.
