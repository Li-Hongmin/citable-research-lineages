"""Small independent certificate for the retained-edge reattachment collision."""

from itertools import combinations


def edge(a, b):
    return tuple(sorted((a, b)))


def expand(edges, site, fresh):
    u, v, x, y = site
    a, b, c, d = fresh
    return (edges - {edge(u, v), edge(x, y)}) | {
        edge(*pair) for pair in ((u, a), (a, b), (b, v), (x, c),
                                  (c, d), (d, y), (a, d), (b, c))
    }


def vertices(edges):
    return {v for e in edges for v in e}


def adjacency(edges, verts):
    adj = {v: set() for v in verts}
    for a, b in edges:
        adj[a].add(b)
        adj[b].add(a)
    return adj


def components(adj):
    unseen = set(adj)
    out = []
    while unseen:
        seen = {unseen.pop()}
        stack = list(seen)
        while stack:
            for v in adj[stack.pop()]:
                if v in unseen:
                    unseen.remove(v)
                    seen.add(v)
                    stack.append(v)
        out.append(seen)
    return out


def check_barnette(edges):
    verts = vertices(edges)
    adj = adjacency(edges, verts)
    assert all(len(adj[v]) == 3 for v in verts)
    colour = {}
    for start in verts:
        if start in colour:
            continue
        colour[start] = 0
        stack = [start]
        while stack:
            u = stack.pop()
            for v in adj[u]:
                if v not in colour:
                    colour[v] = 1 - colour[u]
                    stack.append(v)
                else:
                    assert colour[v] != colour[u]
    for size in range(3):
        for cut in combinations(verts, size):
            remaining = verts - set(cut)
            restricted = {v: adj[v] & remaining for v in remaining}
            assert len(components(restricted)) == 1
    return colour


def check_face_cycle(edges, face):
    assert len(face) == len(set(face))
    assert all(edge(face[i], face[(i + 1) % len(face)]) in edges
               for i in range(len(face)))


Q = {edge(*pair) for pair in ((0, 1), (1, 2), (2, 3), (3, 0),
                              (4, 5), (5, 6), (6, 7), (7, 4),
                              (0, 4), (1, 5), (2, 6), (3, 7))}
G1 = expand(Q, (0, 1, 2, 3), (8, 9, 10, 11))
Z = expand(G1, (0, 8, 9, 1), (12, 13, 14, 15))
H = expand(Z, (0, 12, 11, 3), (16, 17, 18, 19))
check_barnette(Q)
colours_g1 = check_barnette(G1)
colours_z = check_barnette(Z)
colours = check_barnette(H)
assert colours_g1[0] == colours_g1[9]
assert colours_z[0] == colours_z[11]

# These faces follow by replacing the selected edge by its new three-edge path.
check_face_cycle(G1, (0, 8, 9, 1, 5, 4))
check_face_cycle(Z, (0, 12, 13, 8, 11, 3))
outer_face = (0, 16, 17, 12, 15, 1, 5, 4)
check_face_cycle(H, outer_face)

slots = ("U", "V", "X", "Y", "Q0", "Q1", "E0", "E1", "F0", "F1",
         "A", "B", "C", "D")
qs = ((15, 1), (5, 4))
keys = []
for q in qs:
    assert edge(*q) in Z and colours[0] == colours[q[0]]
    vals = (0, 12, 11, 3, *q, 2, 6, 9, 10, 16, 17, 18, 19)
    assert len(set(vals)) == 14
    colour_word = tuple(colours[v] for v in vals)
    colour_word = min(colour_word, tuple(1 - x for x in colour_word))
    j = next(i for i in range(2, len(outer_face) - 1)
             if outer_face[i:i + 2] == q)
    assert (j - 1, len(outer_face) - j - 1) in ((3, 3), (5, 1))
    roles = dict(zip(vals, slots))
    face_word = ("UA", tuple(roles[v] for v in outer_face[1:j + 1]
                             if v in roles), "SEP",
                 tuple(roles[v] for v in outer_face[j + 1:] if v in roles),
                 "SEP")
    keys.append((colour_word, face_word))
assert keys[0] == keys[1]
assert keys[0][1] == ("UA", ("A", "B", "V", "Q0"), "SEP", ("Q1",), "SEP")

# A generator for q=(15,1): two disjoint four-cycles, with all other vertices
# isolated. Every nonboundary vertex has degree two.
F = {edge(*pair) for pair in ((4, 5), (5, 6), (6, 7), (7, 4),
                              (8, 9), (9, 14), (14, 13), (13, 8))}
cut1 = {edge(0, 12), edge(11, 3), edge(15, 1)}
assert F <= Z - cut1
boundary1 = (0, 12, 11, 3, 15, 1, 2, 6, 9, 10)
deg = adjacency(F, vertices(Z))
assert tuple(len(deg[v]) for v in boundary1) == (0, 0, 0, 0, 0, 0, 0, 2, 2, 0)
assert all(len(deg[v]) == 2 for v in vertices(Z) - set(boundary1))
assert all(len(comp & set(boundary1)) == 1 for comp in components(deg))
assert edge(2, 6) not in F and edge(9, 10) not in F

# For q=(5,4), the same row sets degrees at 3 and 4 to zero. Vertex 7 is
# outside the boundary and has only neighbour 6 left, so degree two is impossible.
boundary2 = (0, 12, 11, 3, 5, 4, 2, 6, 9, 10)
assert 7 not in boundary2
assert adjacency(Z, vertices(Z))[7] == {3, 4, 6}
print("REAL_REATTACHMENT_COLLISION_VERIFIED")
