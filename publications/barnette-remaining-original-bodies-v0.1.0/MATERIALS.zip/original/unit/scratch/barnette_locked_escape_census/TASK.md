# Single leaf: complete low-order test of existence-level locked-boundary escape

Long objective: decide Barnette-type Hamiltonicity through a genuine structural theorem or counterexample. Work only in units/barnette. Read Notes 063--065 and reuse the permanent through-18 proof bundle in computations/bundles/planar-two-path-through18. Do not modify permanent notes or papers; keep code and outputs in this scratch directory and use streaming/low-memory enumeration.

For every simple plane cubic bipartite brace F' of order at most 18, put T'=F'^*. Enumerate every vertex split of T' along two nonconsecutive gates that yields a simple 4-connected Eulerian plane triangulation T, and every prescribed edge a surviving the split. Determine the exact existence-level statement:

> whenever T' has at least one prescribed-edge target colouring, at least one such target colouring extends, with all old vertex colours fixed, to a target colouring of T.

Enumerate colourings modulo global complement and all eight local assignments exactly. If the statement fails, give the smallest explicit reduced/expanded triangulations, site, root, the complete reduced target family, and verify that none lifts; check that the expanded dual is a genuine simple plane cubic bipartite brace and distinguish whether it itself has another target colouring. If no failure occurs, report only the exact complete finite coverage and its trusted generator boundary. Do not automatically extend the reduced corpus beyond order 18.

Stop at genuine counterexample or exact finite theorem. End with exact conclusion and quantifiers, weakest load-bearing argument, evidence level, and unresolved boundary. Do not select a new task or edit permanent files.
