#!/usr/bin/env python3
"""Exact low-order census of existence-level degree-four NAE lifts.

The source corpus is the certificate produced by the permanent
``planar-two-path-through18`` bundle.  For each of its five plane braces we
construct the embedded dual, enumerate every unordered nonconsecutive gate
pair at every dual vertex, retain exactly the splits that are simple
4-connected Eulerian plane triangulations, and test every unchanged root
edge.

Colourings are quotiented only by global complementation.  For each reduced
target colouring all eight assignments to the two split copies and the new
degree-four vertex are tested, even after a successful lift is found.  Only
aggregate counters are retained unless the existence statement fails, so the
enumeration holds one graph, one split, and one colouring at a time.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from functools import lru_cache
from itertools import combinations, product
import json
from pathlib import Path
from typing import Iterable, Iterator

import networkx as nx


Edge = tuple[int, int]
Colouring = tuple[int, ...]


def edge(first: int, second: int) -> Edge:
    return (first, second) if first < second else (second, first)


def plane_faces(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    planar, embedding = nx.check_planarity(graph)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    used: set[tuple[int, int]] = set()
    faces: list[tuple[int, ...]] = []
    for first, second in embedding.edges():
        if (first, second) not in used:
            faces.append(tuple(embedding.traverse_face(first, second, used)))
    directed = [
        (face[index], face[(index + 1) % len(face)])
        for face in faces
        for index in range(len(face))
    ]
    expected = {
        dart
        for first, second in graph.edges()
        for dart in ((first, second), (second, first))
    }
    assert len(directed) == len(set(directed)) == 2 * graph.number_of_edges()
    assert set(directed) == expected
    assert graph.number_of_nodes() - graph.number_of_edges() + len(faces) == 2
    return tuple(faces)


def dual_from_primal_faces(
    primal: nx.Graph, primal_faces: Iterable[Iterable[int]]
) -> tuple[nx.Graph, dict[int, tuple[int, ...]]]:
    """Build the dual and its rotations directly from a stored face system."""

    faces = tuple(tuple(map(int, face)) for face in primal_faces)
    edge_faces: dict[Edge, list[int]] = defaultdict(list)
    face_edges: list[tuple[Edge, ...]] = []
    for face_index, face in enumerate(faces):
        boundary = tuple(
            edge(face[index], face[(index + 1) % len(face)])
            for index in range(len(face))
        )
        assert len(boundary) == len(set(boundary))
        face_edges.append(boundary)
        for boundary_edge in boundary:
            assert primal.has_edge(*boundary_edge)
            edge_faces[boundary_edge].append(face_index)

    assert set(edge_faces) == {edge(*item) for item in primal.edges()}
    assert all(len(incident) == 2 for incident in edge_faces.values())

    dual = nx.Graph()
    dual.add_nodes_from(range(len(faces)))
    for incident in edge_faces.values():
        dual.add_edge(*incident)
    assert nx.number_of_selfloops(dual) == 0
    assert dual.number_of_edges() == primal.number_of_edges()

    rotations: dict[int, tuple[int, ...]] = {}
    for face_index, boundary in enumerate(face_edges):
        rotation = tuple(
            incident[0] if incident[1] == face_index else incident[1]
            for boundary_edge in boundary
            for incident in (edge_faces[boundary_edge],)
        )
        assert len(rotation) == len(set(rotation)) == dual.degree[face_index]
        assert set(rotation) == set(dual[face_index])
        rotations[face_index] = rotation

    return dual, rotations


def verify_reduced_triangulation(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    assert nx.number_of_selfloops(graph) == 0
    assert graph.number_of_edges() == 3 * graph.number_of_nodes() - 6
    assert all(degree % 2 == 0 for _, degree in graph.degree())
    assert nx.node_connectivity(graph) >= 4
    faces = plane_faces(graph)
    assert all(len(face) == 3 for face in faces)
    return faces


def gate_pairs(rotation: tuple[int, ...]) -> Iterator[tuple[int, int, int, int]]:
    """Yield all unordered nonconsecutive gates by their positions and labels."""

    degree = len(rotation)
    for first_index in range(degree):
        for second_index in range(first_index + 1, degree):
            distance = second_index - first_index
            if distance in (1, degree - 1):
                continue
            yield first_index, second_index, rotation[first_index], rotation[second_index]


def split_vertex(
    reduced: nx.Graph,
    z: int,
    rotation: tuple[int, ...],
    first_index: int,
    second_index: int,
) -> tuple[nx.Graph, tuple[int, int, int], tuple[int, ...], tuple[int, ...]]:
    """Apply the exact inverse degree-four reduction of Note 065."""

    assert 0 <= first_index < second_index < len(rotation)
    left_arc = rotation[first_index : second_index + 1]
    right_arc = rotation[second_index:] + rotation[: first_index + 1]
    assert len(left_arc) >= 3 and len(right_arc) >= 3

    next_vertex = max(reduced) + 1
    left, right, centre = next_vertex, next_vertex + 1, next_vertex + 2
    expanded = reduced.copy()
    expanded.remove_node(z)
    expanded.add_nodes_from((left, right, centre))
    expanded.add_edges_from((left, neighbour) for neighbour in left_arc)
    expanded.add_edges_from((right, neighbour) for neighbour in right_arc)
    expanded.add_edges_from(
        (
            (centre, left),
            (centre, left_arc[0]),
            (centre, right),
            (centre, left_arc[-1]),
        )
    )
    assert expanded.number_of_nodes() == reduced.number_of_nodes() + 2
    assert expanded.number_of_edges() == reduced.number_of_edges() + 6
    return expanded, (left, right, centre), left_arc, right_arc


def expanded_triangulation_faces(
    graph: nx.Graph,
) -> tuple[tuple[int, ...], ...] | None:
    """Return faces exactly when this is an admissible expanded triangulation."""

    if nx.number_of_selfloops(graph):
        return None
    if graph.number_of_edges() != 3 * graph.number_of_nodes() - 6:
        return None
    if any(degree % 2 for _, degree in graph.degree()):
        return None
    planar, _ = nx.check_planarity(graph)
    if not planar:
        return None
    faces = plane_faces(graph)
    if any(len(face) != 3 for face in faces):
        return None
    if nx.node_connectivity(graph) < 4:
        return None
    return faces


def complement_classes(vertices: tuple[int, ...]) -> Iterator[dict[int, int]]:
    """Enumerate vertex 2-colourings modulo the global complement."""

    anchor = min(vertices)
    others = tuple(vertex for vertex in vertices if vertex != anchor)
    for bits in product((0, 1), repeat=len(others)):
        yield {anchor: 0, **dict(zip(others, bits, strict=True))}


def is_nae(faces: Iterable[Iterable[int]], colour: dict[int, int]) -> bool:
    return all(len({colour[vertex] for vertex in face}) == 2 for face in faces)


def monochromatic_graph(graph: nx.Graph, colour: dict[int, int]) -> nx.Graph:
    mono = nx.Graph()
    mono.add_nodes_from(graph.nodes())
    mono.add_edges_from(
        (first, second)
        for first, second in graph.edges()
        if colour[first] == colour[second]
    )
    return mono


def cycle_edges_if_target_shape(
    graph: nx.Graph, faces: tuple[tuple[int, ...], ...], colour: dict[int, int]
) -> frozenset[Edge]:
    """Return the unique mono-cycle edges, or empty if this is not a target shape."""

    if not is_nae(faces, colour):
        return frozenset()
    mono = monochromatic_graph(graph, colour)
    components = nx.number_connected_components(mono)
    beta = mono.number_of_edges() - mono.number_of_nodes() + components
    if beta != 1:
        return frozenset()
    cycles = nx.cycle_basis(mono)
    assert len(cycles) == 1
    cycle = cycles[0]
    return frozenset(
        edge(cycle[index], cycle[(index + 1) % len(cycle)])
        for index in range(len(cycle))
    )


def target_families(
    graph: nx.Graph, faces: tuple[tuple[int, ...], ...]
) -> tuple[dict[Edge, list[Colouring]], int, int]:
    """Enumerate the complete prescribed-edge target families."""

    vertices = tuple(sorted(graph))
    families: dict[Edge, list[Colouring]] = defaultdict(list)
    nae_count = 0
    target_shape_count = 0
    for colour in complement_classes(vertices):
        if not is_nae(faces, colour):
            continue
        nae_count += 1
        cycle_edges = cycle_edges_if_target_shape(graph, faces, colour)
        if not cycle_edges:
            continue
        target_shape_count += 1
        encoded = tuple(colour[vertex] for vertex in vertices)
        for root in cycle_edges:
            families[root].append(encoded)
    return families, nae_count, target_shape_count


def decode_colouring(vertices: tuple[int, ...], encoded: Colouring) -> dict[int, int]:
    return dict(zip(vertices, encoded, strict=True))


def rooted_profile(
    graph: nx.Graph,
    faces: tuple[tuple[int, ...], ...],
    colour: dict[int, int],
    root: Edge,
) -> tuple[bool, int | None, int | None, bool]:
    """Return NAE, component count, cycle rank, and root-on-cycle."""

    if not is_nae(faces, colour):
        return False, None, None, False
    mono = monochromatic_graph(graph, colour)
    components = nx.number_connected_components(mono)
    beta = mono.number_of_edges() - mono.number_of_nodes() + components
    root_on_cycle = False
    if mono.has_edge(*root):
        test = mono.copy()
        test.remove_edge(*root)
        root_on_cycle = nx.number_connected_components(test) == components
    return True, components, beta, root_on_cycle


def is_target_profile(profile: tuple[bool, int | None, int | None, bool]) -> bool:
    nae, _components, beta, root_on_cycle = profile
    return nae and beta == 1 and root_on_cycle


def perfect_matching_decider(graph: nx.Graph):
    vertices = tuple(sorted(graph))
    index = {vertex: position for position, vertex in enumerate(vertices)}
    neighbour_masks = {
        index[vertex]: sum(1 << index[neighbour] for neighbour in graph[vertex])
        for vertex in vertices
    }

    @lru_cache(maxsize=None)
    def exists(mask: int) -> bool:
        if mask == 0:
            return True
        if mask.bit_count() % 2:
            return False
        candidates = [position for position in range(len(vertices)) if mask & (1 << position)]
        first = min(candidates, key=lambda item: (neighbour_masks[item] & mask).bit_count())
        choices = neighbour_masks[first] & mask
        without_first = mask ^ (1 << first)
        while choices:
            bit = choices & -choices
            choices ^= bit
            if exists(without_first ^ bit):
                return True
        return False

    return vertices, index, exists


def verify_brace(graph: nx.Graph) -> dict[str, object]:
    """Directly verify simple plane cubic bipartite 2-extendability."""

    assert nx.number_of_selfloops(graph) == 0
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    planar, _ = nx.check_planarity(graph)
    assert planar
    assert nx.node_connectivity(graph) >= 3

    vertices, index, matching_exists = perfect_matching_decider(graph)
    full_mask = (1 << len(vertices)) - 1
    graph_edges = tuple(sorted(edge(*item) for item in graph.edges()))
    independent_pairs = 0
    for first, second in combinations(graph_edges, 2):
        endpoints = set(first + second)
        if len(endpoints) != 4:
            continue
        independent_pairs += 1
        remaining = full_mask
        for vertex in endpoints:
            remaining ^= 1 << index[vertex]
        assert matching_exists(remaining)
    assert independent_pairs > 0

    colour = nx.bipartite.color(graph)
    hall_subsets = 0
    for value in (0, 1):
        side = tuple(sorted(vertex for vertex in graph if colour[vertex] == value))
        for size in range(1, len(side) - 1):
            for shore in combinations(side, size):
                hall_subsets += 1
                neighbours = set().union(*(set(graph[vertex]) for vertex in shore))
                assert len(neighbours) >= size + 2

    return {
        "vertices": graph.number_of_nodes(),
        "edges": graph.number_of_edges(),
        "independent_two_edge_matchings_checked": independent_pairs,
        "strict_hall_subsets_checked": hall_subsets,
    }


def dual_from_plane_graph(graph: nx.Graph, faces: tuple[tuple[int, ...], ...]) -> nx.Graph:
    incident: dict[Edge, list[int]] = defaultdict(list)
    for face_index, face in enumerate(faces):
        for index, first in enumerate(face):
            second = face[(index + 1) % len(face)]
            incident[edge(first, second)].append(face_index)
    assert set(incident) == {edge(*item) for item in graph.edges()}
    assert all(len(pair) == 2 for pair in incident.values())
    dual = nx.Graph()
    dual.add_nodes_from(range(len(faces)))
    dual.add_edges_from(pair for pair in incident.values())
    assert dual.number_of_edges() == graph.number_of_edges()
    return dual


def explicit_colouring(colour: dict[int, int]) -> dict[str, list[int]]:
    return {
        "zero_vertices": sorted(vertex for vertex, value in colour.items() if value == 0),
        "one_vertices": sorted(vertex for vertex, value in colour.items() if value == 1),
    }


def enumerate_expanded_root_targets(
    graph: nx.Graph, faces: tuple[tuple[int, ...], ...], root: Edge
) -> tuple[int, dict[str, list[int]] | None]:
    count = 0
    first = None
    for colour in complement_classes(tuple(sorted(graph))):
        profile = rooted_profile(graph, faces, colour, root)
        if is_target_profile(profile):
            count += 1
            if first is None:
                first = explicit_colouring(colour)
    return count, first


def verify_failure(
    source_graph6: str,
    reduced: nx.Graph,
    expanded: nx.Graph,
    expanded_faces: tuple[tuple[int, ...], ...],
    z: int,
    rotation: tuple[int, ...],
    gate_indices: tuple[int, int],
    gates: tuple[int, int],
    arcs: tuple[tuple[int, ...], tuple[int, ...]],
    locals_: tuple[int, int, int],
    root: Edge,
    family: list[Colouring],
) -> dict[str, object]:
    """Freeze and independently recheck the first, hence smallest, failure."""

    reduced_vertices = tuple(sorted(reduced))
    family_records = []
    target_extensions = 0
    for encoded in family:
        reduced_colour = decode_colouring(reduced_vertices, encoded)
        fixed = {vertex: value for vertex, value in reduced_colour.items() if vertex != z}
        assignments = []
        for bits in product((0, 1), repeat=3):
            lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
            profile = rooted_profile(expanded, expanded_faces, lifted, root)
            target = is_target_profile(profile)
            target_extensions += int(target)
            assignments.append(
                {
                    "bits_left_right_centre": bits,
                    "nae": profile[0],
                    "components": profile[1],
                    "cycle_rank": profile[2],
                    "root_on_cycle": profile[3],
                    "target": target,
                }
            )
        family_records.append(
            {
                **explicit_colouring(reduced_colour),
                "assignments": assignments,
            }
        )
    assert target_extensions == 0

    expanded_dual = dual_from_plane_graph(expanded, expanded_faces)
    brace_check = verify_brace(expanded_dual)
    expanded_target_count, expanded_first_target = enumerate_expanded_root_targets(
        expanded, expanded_faces, root
    )

    return {
        "source_graph6": source_graph6,
        "reduced_order_primal": 2 * (reduced.number_of_nodes() - 2),
        "expanded_order_primal": expanded_dual.number_of_nodes(),
        "reduced_triangulation_edges": sorted(edge(*item) for item in reduced.edges()),
        "expanded_triangulation_edges": sorted(edge(*item) for item in expanded.edges()),
        "site": {
            "split_vertex": z,
            "rotation": rotation,
            "gate_indices": gate_indices,
            "gates": gates,
            "left_arc": arcs[0],
            "right_arc": arcs[1],
            "left_right_centre": locals_,
        },
        "root": root,
        "complete_reduced_target_family_size_up_to_complement": len(family),
        "complete_reduced_target_family": family_records,
        "expanded_dual_edges": sorted(edge(*item) for item in expanded_dual.edges()),
        "expanded_dual_graph6": nx.to_graph6_bytes(expanded_dual, header=False).decode().strip(),
        "expanded_dual_brace_check": brace_check,
        "expanded_other_rooted_targets_up_to_complement": expanded_target_count,
        "expanded_first_rooted_target": expanded_first_target,
    }


def census(source: dict[str, object]) -> dict[str, object]:
    coverage = source["coverage"]
    assert isinstance(coverage, dict)
    assert coverage["orders"] == [6, 8, 10, 12, 14, 16, 18]
    assert coverage["isomorphism_representatives"] == 209
    assert coverage["planar_brace_isomorphism_classes"] == 5

    totals = {
        "source_braces": 0,
        "reduced_colour_classes": 0,
        "reduced_nae_colourings": 0,
        "reduced_target_shape_colourings": 0,
        "reduced_root_target_pairs": 0,
        "nonconsecutive_gate_pairs": 0,
        "odd_arc_gate_pairs": 0,
        "simple_eulerian_plane_triangulation_splits": 0,
        "admissible_4connected_splits": 0,
        "surviving_root_interfaces": 0,
        "nonempty_antecedent_interfaces": 0,
        "reduced_target_interface_colourings": 0,
        "local_assignments_tested": 0,
        "target_extensions_found": 0,
        "interfaces_with_an_extension": 0,
        "existence_failures": 0,
    }
    graph_records: list[dict[str, object]] = []
    first_failure = None

    braces = source["braces"]
    assert isinstance(braces, list)
    for source_record in braces:
        assert isinstance(source_record, dict)
        source_order = int(source_record["order"])
        source_graph6 = str(source_record["graph6"])
        primal = nx.from_graph6_bytes(source_graph6.encode())
        stored_edges = {edge(*map(int, item)) for item in source_record["edges"]}
        assert stored_edges == {edge(*item) for item in primal.edges()}
        reduced, rotations = dual_from_primal_faces(primal, source_record["faces"])
        reduced_faces = verify_reduced_triangulation(reduced)
        families, nae_count, target_shape_count = target_families(reduced, reduced_faces)
        reduced_vertices = tuple(sorted(reduced))

        graph_totals = {
            "source_order": source_order,
            "source_graph6": source_graph6,
            "dual_vertices": reduced.number_of_nodes(),
            "colour_classes_mod_complement": 1 << (reduced.number_of_nodes() - 1),
            "nae_colourings_mod_complement": nae_count,
            "target_shape_colourings_mod_complement": target_shape_count,
            "root_target_pairs_mod_complement": sum(map(len, families.values())),
            "nonconsecutive_gate_pairs": 0,
            "odd_arc_gate_pairs": 0,
            "simple_eulerian_plane_triangulation_splits": 0,
            "admissible_4connected_splits": 0,
            "surviving_root_interfaces": 0,
            "nonempty_antecedent_interfaces": 0,
            "reduced_target_interface_colourings": 0,
            "local_assignments_tested": 0,
            "target_extensions_found": 0,
            "interfaces_with_an_extension": 0,
            "existence_failures": 0,
        }
        totals["source_braces"] += 1
        totals["reduced_colour_classes"] += graph_totals["colour_classes_mod_complement"]
        totals["reduced_nae_colourings"] += nae_count
        totals["reduced_target_shape_colourings"] += target_shape_count
        totals["reduced_root_target_pairs"] += graph_totals["root_target_pairs_mod_complement"]

        for z in sorted(reduced):
            rotation = rotations[z]
            for first_index, second_index, first_gate, second_gate in gate_pairs(rotation):
                graph_totals["nonconsecutive_gate_pairs"] += 1
                totals["nonconsecutive_gate_pairs"] += 1
                left_size = second_index - first_index + 1
                right_size = len(rotation) - (second_index - first_index) + 1
                if left_size % 2 == 0 or right_size % 2 == 0:
                    continue
                graph_totals["odd_arc_gate_pairs"] += 1
                totals["odd_arc_gate_pairs"] += 1

                expanded, locals_, left_arc, right_arc = split_vertex(
                    reduced, z, rotation, first_index, second_index
                )
                # Before the 4-connectivity filter, certify the exact local
                # topological and parity conditions named in the counter.
                if nx.number_of_selfloops(expanded):
                    continue
                if any(degree % 2 for _, degree in expanded.degree()):
                    continue
                planar, _ = nx.check_planarity(expanded)
                if not planar:
                    continue
                pre_faces = plane_faces(expanded)
                if any(len(face) != 3 for face in pre_faces):
                    continue
                graph_totals["simple_eulerian_plane_triangulation_splits"] += 1
                totals["simple_eulerian_plane_triangulation_splits"] += 1

                expanded_faces = expanded_triangulation_faces(expanded)
                if expanded_faces is None:
                    continue
                graph_totals["admissible_4connected_splits"] += 1
                totals["admissible_4connected_splits"] += 1

                surviving_roots = tuple(
                    sorted(root for root in (edge(*item) for item in reduced.edges()) if z not in root)
                )
                assert all(expanded.has_edge(*root) for root in surviving_roots)
                graph_totals["surviving_root_interfaces"] += len(surviving_roots)
                totals["surviving_root_interfaces"] += len(surviving_roots)

                for root in surviving_roots:
                    family = families.get(root, [])
                    if not family:
                        continue
                    graph_totals["nonempty_antecedent_interfaces"] += 1
                    totals["nonempty_antecedent_interfaces"] += 1
                    graph_totals["reduced_target_interface_colourings"] += len(family)
                    totals["reduced_target_interface_colourings"] += len(family)

                    interface_extensions = 0
                    for encoded in family:
                        reduced_colour = decode_colouring(reduced_vertices, encoded)
                        fixed = {
                            vertex: value
                            for vertex, value in reduced_colour.items()
                            if vertex != z
                        }
                        for bits in product((0, 1), repeat=3):
                            graph_totals["local_assignments_tested"] += 1
                            totals["local_assignments_tested"] += 1
                            lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
                            if is_target_profile(rooted_profile(expanded, expanded_faces, lifted, root)):
                                interface_extensions += 1
                                graph_totals["target_extensions_found"] += 1
                                totals["target_extensions_found"] += 1

                    if interface_extensions:
                        graph_totals["interfaces_with_an_extension"] += 1
                        totals["interfaces_with_an_extension"] += 1
                        continue

                    graph_totals["existence_failures"] += 1
                    totals["existence_failures"] += 1
                    first_failure = verify_failure(
                        source_graph6,
                        reduced,
                        expanded,
                        expanded_faces,
                        z,
                        rotation,
                        (first_index, second_index),
                        (first_gate, second_gate),
                        (left_arc, right_arc),
                        locals_,
                        root,
                        family,
                    )
                    break
                if first_failure is not None:
                    break
            if first_failure is not None:
                break

        graph_records.append(graph_totals)
        print(json.dumps(graph_totals, sort_keys=True), flush=True)
        if first_failure is not None:
            break

    if first_failure is None:
        assert totals["interfaces_with_an_extension"] == totals["nonempty_antecedent_interfaces"]
        conclusion = {
            "status": "exact_finite_theorem",
            "statement": (
                "For every simple plane cubic bipartite brace F' with at most 18 vertices, "
                "every admissible vertex split of T'=F'^* along two nonconsecutive gates, "
                "and every prescribed edge a of T' not incident with the split vertex: if "
                "T' has a target colouring for a, then some such colouring extends, with all "
                "surviving old vertex colours fixed, to a target colouring of the expanded T."
            ),
            "unresolved_boundary": (
                "Reduced braces of order 20 and above; the census is finite and does not "
                "supply a general existence-level lifting argument."
            ),
        }
    else:
        conclusion = {
            "status": "counterexample",
            "statement": (
                "The existence-level locked-boundary escape statement fails; the attached "
                "record is the first failure in complete increasing reduced-order coverage."
            ),
            "unresolved_boundary": (
                "The census settles only the universal statement by counterexample; it does "
                "not classify all failing sites or decide the underlying RCA target."
            ),
        }

    return {
        "trusted_source_boundary": {
            "generator_command": coverage["generator_command"],
            "generator_path": coverage["generator_path"],
            "networkx_version": nx.__version__,
            "orders": coverage["orders"],
            "isomorphism_representatives": coverage["isomorphism_representatives"],
            "planar_brace_isomorphism_classes": coverage["planar_brace_isomorphism_classes"],
            "source_graph6": [record["source_graph6"] for record in graph_records],
            "external_interfaces": [
                "nauty geng isomorph-free completeness for geng -cqb -d3 -D3 n",
                "NetworkX exact planarity decisions used by the permanent source bundle and split filter",
            ],
        },
        "coverage": totals,
        "by_source_graph": graph_records,
        "conclusion": conclusion,
        "first_failure": first_failure,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_certificate", type=Path)
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    source = json.loads(arguments.source_certificate.read_text())
    payload = census(source)
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
        print("certificate", arguments.output)
    print(json.dumps(payload["coverage"], sort_keys=True))
    print(json.dumps(payload["conclusion"], sort_keys=True))
    if payload["first_failure"] is None:
        print("LOCKED_ESCAPE_EXISTENCE_VERIFIED_THROUGH_REDUCED_ORDER_18")
    else:
        print("LOCKED_ESCAPE_EXISTENCE_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
