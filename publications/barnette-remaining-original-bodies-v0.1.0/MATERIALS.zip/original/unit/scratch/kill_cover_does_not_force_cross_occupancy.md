# Parent kill cover does not force canonical--cross occupancy at the current axiomatic layer

This note uses only Notes 108--112.  It concerns occupancy, not bondness.

## 1. The exact occupancy statement

Let \({\cal L}_{\neg 11}^b\) be the parent root-admissible colourings of
gate bit \(b\) whose split state is not \(11\).  By the canonical bijection
of Note 108, these are in gate-bit-preserving bijection with the canonical
child colourings:

\[
 {\cal L}_{\neg 11}^b\longleftrightarrow {\cal A}_{\cal C}^b.
\tag{1}
\]

Put

\[
 {\cal A}_{X}^b={\cal A}_{X_{uy}}^b\cup{\cal A}_{X_{vx}}^b.
\tag{2}
\]

The occupancy assertion in the question is therefore exactly

\[
\boxed{
(\mathsf{OX})\qquad
\exists b\in\{0,1\}:
{\cal L}_{\neg11}^{\,b}\ne\varnothing
\quad\text{and}\quad
{\cal A}_{X}^{\,1-b}\ne\varnothing.}
\tag{3}
\]

No shore connectivity or bond condition occurs in (3).

## 2. What kill cover actually says

Let \(\mathfrak B_{g_1}(T)\) be the parent rooted bond graph.  The
kill-cover assumption is

\[
E(\mathfrak B_{g_1}(T))\ne\varnothing,\qquad
L_{11}\text{ is a vertex cover of }\mathfrak B_{g_1}(T).
\tag{4}
\]

Condition (4) constrains edges only.  It permits:

* every parent bond to have both endpoints in \(L_{11}\), so that
  \({\cal L}_{\neg11}\) is empty; and
* a parent \(11\)--non-\(11\) bond, hence a canonical child colouring,
  while both cross cells are empty.

The split NAE table specifies which local rows are possible, but Notes
108--112 contain no theorem asserting that a root-admissible colouring
occupies either cross row.  The direct-lift calculus of Note 111 cannot
supply this assertion: its hypotheses classify a prescribed lift, while
its nondirect example explicitly separates complete-family occupancy from
parent ancestry.

## 3. A strict abstract countermodel

The following two-level incidence structure satisfies every established
graph-level conclusion used in Notes 108--112 while violating
\(\mathsf{OX}\).

The parent rooted bond graph has two vertices

\[
 \alpha\in L_{11}^{\,0},\qquad
 \beta\in{\cal L}_{00}^{\,1},
\]

and its only edge is \(\alpha\beta\).  It is nonempty and \(L_{11}\)
covers its edge.

The child root-admissible family has

\[
 c\in{\cal A}_{C_{00}}^{\,1},\qquad
 r\in{\cal A}_{R_{00}}^{\,0},
\qquad
{\cal A}_{X_{uy}}={\cal A}_{X_{vx}}=\varnothing.
\tag{5}
\]

The canonical bijection sends \(\beta\) to \(c\).  Give the child the
single rooted bond \(cr\).  Declare \(r\) nondirect, so the prohibition on a
direct \(C_{00}\)--\(R_{00}\) lift in Note 111 is respected.  The
canonical induced child graph is the isolated vertex \(c\), exactly as is
the parent graph after deleting \(L_{11}\).  If the rank language is
retained, assign the bond \(cr\) any balanced profile, for example

\[
(\rho_{00},\rho_{11},\rho_{10},\rho_{01})=(1,1,1,1),
\]

with separated root labels.  Thus the exact test of Note 109 is also
satisfied.

This model even grants the weaker rooted split-bond conclusion through the
nondirect \(R_{00}\) bond.  Nevertheless the only canonical child has gate
bit \(1\), and there is no cross child of gate bit \(0\); hence
\(\mathsf{OX}\) fails.

The model is abstract: it is not asserted to be the NAE family of an actual
4-connected Eulerian triangulation.  It proves that the current
kill-cover, canonical-bijection, local-row, rank, and nondirect-lift
statements do not logically force occupancy.

## 4. Exact boundary

At the level of Notes 108--112, the unique missing assertion is precisely
\(\mathsf{OX}\) in (3).  Parent kill cover supplies neither factor:
edge-covering by \(L_{11}\) does not force a non-\(11\) parent target, and
no current complete-family theorem forces an opposite-bit cross target.

Therefore the actual triangulation statement is undecided by the present
notes.  A proof must use one new actual-incidence lemma implying (3).  An
actual counterexample must realize the abstract occupancy pattern (5), or
the still weaker all-\(11\) parent pattern, in a legal split pair.
