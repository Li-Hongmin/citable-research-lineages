# 连通吸收的独立推导：精确割编码、单圈边界与完整父圈族的缺口

2026-09-27。仅 Barnette，本地轻量。

输入为 [最新 Pro 正文](pro-connected-absorption-mincut-20260927.txt) 和
[双侧交换独立推导](two-sided-independent-derivation-20260927.md)。适用的全局 AGENTS、
[README](../README.md)、[原 SPEC](../SPEC-2026-09-09.md) 及
[冻结 upgrade SPEC](../SPEC-2026-09-12-upgrade.md) 已读取；本地单元及 scratch 未发现额外
`AGENTS.md`。旧记录仅提供定义和固定图数据，以下重新证明承重箭头。按本次用户边界不联网，
不作新文献或新颖性判断；不枚举新图阶，不访问其他数学单元或远端，不修改永久层及既有 dirty。

本轮要改变的判断是：最新连通吸收归约是否正确、是否扩大了覆盖范围，以及完整父圈族尚须强迫
哪个最小条件。互斥结果是正式归约失效、归约成立而存在性仍缺失、或得到完整存在性。
最便宜的直接观测是三角形翻色真值表、球面 Euler 计数和已有 24 点证书上的有限赋值核对。

## 1. 裁决

**Pro 的正式连通吸收定理和最小割定理，在其写出的连通、可用、保护及跨根接边前提下成立。
完整父圈族强迫容量 2 仍为精确 GAP。** 本轮没有原始全部前件下的反例，也没有存在性证明。

必须收紧三个表述。

1. 自动无圈的是新根色的**另一色诱导图**。对上一份推导中的完整收缩图 \(J_U\)，有跨根接边时
   \(\beta(J_U)=r(U)-2\)。只有再满足 \(r(U)=2\)，整个 \(J_U\) 才自动为森林。
   §9 给出真实、可用、受保护、跨根但 \(r=3,\beta(J_U)=1\) 的固定证书。
2. 两侧连通条件加合法性事实上强迫 \(M\triangle N\) 为**单个交替圈**，即使翻转多个
   \(O\)-面、吸收含边的 \(I\)-树枝也是如此。§6 是本轮新增的解析限制。
   因而不能把该机制解释成覆盖多回路交换。
3. 含两条强制跨根接边的网络覆盖该连通类中全部**根分离**区域，包括全部成功区域；它不覆盖
   根仍同圈的连通吸收，也不覆盖任意受保护匹配。固定父圈上的多项式规模更不意味着完整父圈族
   只有多项式多个元素。

本轮集中攻击的决定性步骤是容量 2 的存在。结果为：可以去掉对 \(\rho\) 的枚举，并将容量 2
精确化为删去两条指定单位弧后的一次有向可达性判断（§8）。仍缺的是排除这些阻断路径在
**所有父圈、所有跨根接边对**上同时存在（§10），不是再检查森林或匹配合法性。

## 2. 原域、量词与目标

令 \(G\) 是由实际 cube 合法历史得到的简单、三连通、三价、二分球面图，属于冻结 SPEC 的
\(\mathcal C_{4\mathrm A}\)。当前合法 site 的一个面上按次序出现

\[
p=uv,\qquad e=vx,\qquad q=xy,
\tag{1}
\]

四个端点互异，\(f\) 是不同于 \(p,e,q\) 的 retained edge。定义

\[
J_G(g,f)=\{C:C\text{ 是 Hamilton 圈},\ g\in C,\ f\notin C\}.
\]

原困难前件包含全局 \(H^{+-}\)，以及

\[
\forall D\in J_G(e,f),\qquad p,q\notin D.
\tag{2}
\]

\(J_G(e,f)\) 非空。取其中一个圈，它避 \(p,q\)，所以在 \(u,v,x,y\) 上必须使用剩下的
两条 incident edges；由 \(f\notin D\) 得 \(f\) 不接触这四点。

记完整父圈族为

\[
\mathcal C=J_G(p,f)\ne\varnothing.
\]

对任意 \(C\in\mathcal C\)，(2) 排除 \(e\in C\)。令 \(M=E(G)\setminus E(C)\)，则

\[
e,f\in M,\qquad p,q\in C.
\tag{3}
\]

本轮目标是同一个完美匹配

\[
N\supseteq\{e,f\},\qquad c(G-N)=2,
\qquad v,x\text{ 位于不同补圈}.
\tag{4}
\]

由于 \(e\in N\)，两补圈分别含 \(p,q\)。删去 \(p,q\) 并加入 \(e\)，正好得到原短弧目标的
spanning \(u-y\) path；没有额外闭分量。

还有原剩余前件 \(\mathsf L\)：对每个 \(C\in\mathcal C\)，以下定义的对侧树路径
\(\Pi_C=T_O[o_v,o_x]\) 都没有边界避开 \(f\) 的内部四边形面。这里 \(o_v,o_x\) 是根边
\(e^*\) 两侧三角形的第三顶点。以下用 \(\mathsf{Hard}\) 表示实际合法历史、上述图与 site 条件、
全局 \(H^{+-}\)、(2) 和这个**对整个父圈族的** \(\mathsf L\)。

§3–8 的条件定理不使用实际历史、全局 \(H^{+-}\) 或 \(\mathsf L\)；它们只需要一个满足 (3)
的父圈及图的结构条件。这些尚未使用的全族假设，不能在结尾被自动视为已经证明存在性的输入。

## 3. 先重推匹配、面二染色与圈数

写 \(Q=G^*\)，保留全部对偶顶点，包括孤立点。三连通简单平面性使 \(Q\) 是简单球面三角剖分；
原图二分性使每个对偶顶点度数为偶数且至少四。

Hamilton 圈 \(C\) 将球面分成两个圆盘。每侧的 \(M\)-边都是互不相交的弦，每添一条弦使一个
区域分成两个，因此同侧面的弱对偶是一棵树。把含 \(e^*\) 的侧命名为 \(I\)，另一侧命名为 \(O\)：

\[
T_I=Q[I],\quad T_O=Q[O],\quad
(V(Q),M^*)=T_I\sqcup T_O.
\tag{5}
\]

所有 \(C^*\)-边跨越 \(I,O\)。写 \(e^*=ab\in T_I\)，以 \(I_0,I_1\) 表示 \(T_I-e^*\) 的两个
分量，分别含 \(a,b\)。

在任一原顶点，对应的对偶面三角形具有二同一异的颜色，唯一同色边就是其匹配边。
反过来，任何无单色面三角形的二染色，恰在每个原顶点选中一条匹配边，故给出完美匹配。

对面集 \(U\subseteq V(Q)\) 翻色，记

\[
D_U=\{g\in E(G):g^*\in\delta_Q(U)\},\qquad N_U=M\triangle D_U.
\tag{6}
\]

在每个原顶点，保持非单色恰等价于 \(D_U\) 的局部度为零，或由一条旧匹配边和一条旧圈边组成。
所以“可用”与“翻色后无单色面三角形”完全等价。保护旧匹配边 \(g\) 恰为其两侧面同时翻或同时不翻。

所有含 \(e,f\) 的完美匹配均有 (6) 的表示：\(M\triangle N\) 是顶点不交的交替圈并，在球面上
将这些圈的一侧面集作模二和即可得到 \(U\)。两个表示只差全局补集。因保护 \(e\) 使
\(a,b\) 的翻色变量相等，要求它们都为零恰选定一个表示，不会损失一般受保护匹配。
后续真正缩小范围的是 \(K,B\) 的连通要求。

对任意原边集 \(A_0\subseteq E(G)\)，删除其余边会合并跨这些边相邻的原面。平面 Euler 公式给出

\[
c\bigl(V(Q),(E(G)\setminus A_0)^*\bigr)
=|A_0|-|V(G)|+c(V(G),A_0)+1.
\tag{7}
\]

令 \(n=|V(G)|\)、\(h=c(G-N)\)、\(H_N=(V(Q),N^*)\)。由于
\(|E(G-N)|=n\)、\(|V(Q)|=n/2+2\)、\(|N|=n/2\)，有

\[
c(H_N)=h+1,\qquad
\beta(H_N)=|N|-|V(Q)|+c(H_N)=h-1.
\tag{8}
\]

再把 \(e\in N\) 加入 \(G-N\)。若 \(v,x\) 同圈，原图分量数不变，(7) 表明删除 \(e^*\)
增加一个对偶分量；若分圈，原图分量数减少一，对偶分量数不变。因此

\[
e^*\text{ 是 }H_N\text{ 的桥}
\iff v,x\text{ 同补圈}.
\tag{9}
\]

特别地，(4) 等价于 \(H_N-e^*\) 是森林且仍连接 \(a,b\)。对旧匹配保留森林作收缩，正好得到
上一份推导中的 \(J_U\)；收缩森林不改变圈秩，故

\[
\beta(J_U)=\beta(H_N-e^*).
\tag{10}
\]

## 4. 一色连通确实迫使另一色为森林

**引理 1。** 简单球面三角剖分的二染色若没有单色面三角形，且第一色诱导图连通，则第二色
诱导图没有圈。

证明。若第二色有简单圈 \(Z\)，Jordan 分离给出其两侧。每侧都必须含第一色顶点：否则这一侧
连同边界的三角剖分全部为第二色，至少有一张单色面三角形。连接两侧第一色顶点的第一色路径
既不能经过第二色圈上的顶点，也不能横穿嵌入边，矛盾。证毕。

若第一色连通且圈秩为 \(s\)，另一色是有 \(c_2\) 个分量的森林。所有同色边的总数是
\(|N|=|V(Q)|-2\)。因此

\[
(|V_1|-1+s)+(|V_2|-c_2)=|V(Q)|-2,
\qquad c_2=s+1.
\tag{11}
\]

于是 \(c(H_N)=1+c_2=s+2\)，再由 (8) 得

\[
c(G-N)=s+1.
\tag{12}
\]

这里没有从“另一色无圈”直接跳到补圈数；(11)、(8) 是必须保留的计数步骤。合法二染色也不可删。

## 5. 连通吸收的圈数与根分离

取

\[
A\subseteq I,\qquad \varnothing\ne B\subseteq O,
\quad K=I\setminus A,\quad R=O\setminus B,
\quad U=A\cup B.
\]

要求 \(T_I[K]\) 连通且含 \(a,b\)，\(T_O[B]\) 连通，翻色可用并保 \(e,f\)。定义

\[
r(U)=|E_{C^*}(K,B)|.
\tag{13}
\]

新根色诱导图精确为

\[
Q[K\cup B]=T_I[K]\cup T_O[B]\cup E_{C^*}(K,B).
\tag{14}
\]

其前两项是不交的两棵树。若 \(r\ge1\)，(14) 连通，且

\[
\beta(Q[K\cup B])
=(|K|-1)+(|B|-1)+r-(|K|+|B|)+1=r-1.
\]

引理 1 及 (12) 遂给出

\[
\boxed{Q[A\cup R]\text{ 是恰有 }r\text{ 个分量的森林},
\qquad c(G-N_U)=r.}
\tag{15}
\]

删去 \(e^*\) 后，\(K\) 分为非空的 \(K\cap I_0,K\cap I_1\)。因 \(B\) 是一棵树，
\(e^*\) 非桥当且仅当接边的 \(K\)-端同时命中这两部分：一边一条接边，加上两棵树中的唯一路径，
就构成经过 \(e^*\) 的圈；若只命中一部分，另一部分与外界仍只能通过 \(e^*\) 相连。

所以在这个类中有严格充要式

\[
\boxed{N_U\text{ 满足 (4)}
\iff r(U)=2\ \text{且两个接点分别属于 }I_0,I_1.}
\tag{16}
\]

当 \(r=0\) 时，含 \(e^*\) 的分量就是树 \(T_I[K]\)，根仍为桥，不能成功；(15) 没有覆盖此情形。

特别要区别两种“森林”。在有跨根接边的情形，\(e^*\) 非桥，删它使圈秩下降一，(8)、(10)、(15) 给出

\[
\boxed{\beta(J_U)=r(U)-2.}
\tag{17}
\]

\(r\ge3\) 时，对色森林仍自动成立，但完整 \(J_U\) 有圈。Pro 开头的“\(J_U\) 自动无圈”若指
任意有限割，按旧文的 \(J_U\) 定义就是错误；在“容量 2 且跨根”的最终判据下则正确。
这不推翻其后正式定理。

### 单个 \(O\)-面的限制也成立

若 \(B=\{F\}\)，假设 \(T_I[A]\) 有一条边。其两侧对偶面三角形的第三顶点是两个不同的
\(O\)-顶点；原域的简单球面三角剖分保证它们不同。两端翻为 \(O\) 色后，为避免单色三角形，
两个第三顶点都必须翻色，不可能都等于唯一的 \(F\)。故 \(A\) 在 \(T_I\) 中独立。

删除独立集而保留非空连通的 \(K\)，迫使每个 \(i\in A\) 是 \(T_I\) 的叶。它在 \(Q\) 中仅有
一个 \(I\)-邻点，其余 \(d_Q(i)-1\) 个 \(O\)-邻点依次排成路径。翻转 \(i\) 后，这条路径上的
\(d_Q(i)-2\) 条边都须接触唯一翻转的 \(F\)。单个路径顶点最多覆盖两条路径边，故

\[
d_Q(i)-2\le2,\qquad d_Q(i)\ge4,
\]

从而 \(d_Q(i)=4\)，且 \(F\) 是三个 \(O\)-邻点的中点。对应原面是叶四面，和 \(F\) 的公共边
正对它唯一的旧匹配边。这完整重得 Pro 引理 2；它没有保证这种叶面一定可选择。

## 6. 新的范围定理：多面连通吸收仍然只有一个交换圈

**定理 2。** 在 §5 的全部连通与可用条件下，\(Q[U]\) 与 \(Q[V(Q)\setminus U]\) 都连通，
因而 \(D_U=M\triangle N_U\) 是单个交替简单圈。这个结论不要求 \(r=2\)。

证明。先考察 \(T_I[A]\) 的一个分量 \(A_j\)。因为 \(T_I\) 是树且 \(K\) 非空连通，
\(A_j\) 恰由一条树边接到 \(K\)。声称 \(A_j\) 必有一条 \(C^*\)-边接到 \(B\)。

若没有这样的边，\(A_j\) 的所有 \(O\)-邻点都属于 \(R\)。若 \(A_j\) 含边，取这条边的一侧
面三角形：两个 \(A\)-端翻为 \(O\)，第三顶点属于未翻的 \(R\)，于是三点全为新 \(O\) 色，矛盾。
若 \(A_j=\{i\}\)，它只有一个 \(I\)-邻点，至少三个 \(O\)-邻点都在 \(R\)，其中存在连续两个。
它们与 \(i\) 构成同样的新单色三角形，仍矛盾。因此每个 \(A_j\) 都接到连通的 \(B\)，证明
\(Q[A\cup B]=Q[U]\) 连通。\(A=\varnothing\) 时直接成立。

再考察 \(T_O[R]\) 的一个分量 \(R_j\)。因 \(B\) 非空连通，\(R_j\) 恰有一条树边接到 \(B\)。
若它没有 \(C^*\)-边接到 \(K\)，则所有 \(I\)-邻点属于 \(A\)。\(R_j\) 含边时，该边的一侧
三角形由两个未翻的 \(O\)-点及一个翻成 \(O\) 的 \(A\)-点组成，非法。\(R_j\) 为单点时，
它只有一个 \(O\)-邻点，至少三个 \(I\)-邻点都在 \(A\)，连续两个与它再次形成新单色三角形。
故每个 \(R_j\) 都接到 \(K\)，证明 \(Q[K\cup R]=Q[V(Q)\setminus U]\) 连通。
\(R=\varnothing\) 时也直接成立。

\(B\ne\varnothing\)、\(K\ne\varnothing\) 保证割非空。两岸均连通使 \(\delta_Q(U)\) 成为 bond。
可用性又使其原图对应边集为顶点不交的交替圈并。如果有至少两个圈，球面被分成至少三个区域，
按跨边界变换 \(U\)/补集标记，必使至少一岸有两个不能在该岸内连通的区域，矛盾。故恰一个圈。
证毕。

这比单 \(O\)-面限制更强：允许多个 \(O\)-面确实去除了“\(A\) 必为独立叶四面集”的上述证明，
但没有去除单回路限制。本文不据此声称任意大小的被吸收树枝都有真实实现。
即使某个一般成功匹配需要多回路差集，§7 的网络也不能相对该父圈表示它。
“更换父圈后总能进入本类”仍须另证。

## 7. 网络编码：逐约束、双向覆盖与容量

固定 \(\rho\in O\) 及两条旧圈对偶边

\[
h_0^*=i_0o_0,\quad h_1^*=i_1o_1,
\quad i_j\in I_j,\quad o_j\in O.
\tag{18}
\]

两条边必不同，但允许 \(o_0=o_1\)。定义翻色变量

\[
x_i=\mathbf1[i\in A]\quad(i\in I),\qquad
y_o=\mathbf1[o\in B]\quad(o\in O).
\tag{19}
\]

这些都是“是否翻色”，不是“新颜色是否为根色”。混淆二者会反转单位弧。

### 7.1 连通与逐三角形合法性

将 \(T_I-e^*\) 的两棵树分别根植于 \(a,b\)。父子边 \(PD\) 上的条件是

\[
x_P\le x_D,\qquad x_a=x_b=0.
\tag{20}
\]

若一个点保留，则其所有祖先都保留；反向，含根且连通的保留子树必有此性质。因此 (20) 与
\(K\) 连通含根边精确等价。

将 \(T_O\) 根植于 \(\rho\)，相应要求

\[
y_D\le y_P,\qquad y_\rho=1.
\tag{21}
\]

它精确表示非空连通的 \(B\) 包含 \(\rho\)。

旧色为 \(I,I,O\) 的面三角形，其两个 \(I\) 翻色位与允许的 \(O\) 翻色位为

| 两个 \(I\) 位 | 允许的 \(O\) 位 |
|---|---|
| 00 | 0 |
| 01 | 0 或 1 |
| 10 | 0 或 1 |
| 11 | 1 |

故恰为 \(\min(x_P,x_D)\le y_o\le\max(x_P,x_D)\)。结合 (20)，变成

\[
x_P\le y_o\le x_D.
\tag{22}
\]

对旧色为 \(I,O,O\) 的三角形同理；因 \(y_D\le y_P\)，其条件是

\[
y_D\le x_i\le y_P.
\tag{23}
\]

根边 \(ab\) 没有父子方向，必须单独处理。其两侧第三顶点 \(o_v,o_x\) 都满足

\[
y_{o_v}=y_{o_x}=0.
\tag{24}
\]

所有面三角形恰落在 (22)、(23)、(24) 之一，没有漏项，也没有把一般 NAE 约束错误地直接当成蕴含。
恰是预先固定的两棵树的连通方向，使本类 NAE 约束退化为一元有向蕴含。

### 7.2 保护与指定接边

对 \(f^*\) 的两个端点要求翻色位相等，即两个方向的蕴含。因为 \(f\in M\)，两端原本同色，
这恰保证新匹配仍含 \(f\)。允许两端一起翻色；把它们一律固定为零会错误缩小覆盖。

再要求

\[
y_{o_0}=y_{o_1}=1,\qquad x_{i_0}=x_{i_1}=0.
\tag{25}
\]

这样两条指定接边在同一个结果中保留。\(e\) 则由 (20) 保留。

### 7.3 有向割与语义的双射

每个面变量对应一个节点。源侧变量值为一，汇侧变量值为零。
每个 \(z\le w\) 加无限弧 \(z\to w\)；固定一加 \(s\to z\)，固定零加 \(z\to t\)，均为无限容量。
对每条 \(io\in C^*\)，加入单位容量弧

\[
o\longrightarrow i.
\tag{26}
\]

有限割不会割断任何硬弧。于是有限割的源侧面集，恰对应满足 (20)–(25)、保护 \(f\) 的赋值；
由上述逐项等价，它又恰对应含 \(\rho\)、保留指定两接边的可用连通吸收区域。反向把任一区域的
翻色位放在源侧，所有硬弧均不被割断，得到有限割。这是双向覆盖，不只是充分编码。

只有 \(y_o=1,x_i=0\) 时单位弧被割断。因此

\[
\operatorname{cap}(U)=\sum_{io\in C^*}y_o(1-x_i)
=|E_{C^*}(B,K)|=r(U)=c(G-N_U).
\tag{27}
\]

(25) 保证容量至少二，并由 (9)、(14) 保证根分圈，即使容量大于二也成立。记最小割值为
\(\lambda(C,\rho,h_0,h_1)\)，无有限割时为 \(+\infty\)。由 (16)、(27)，

\[
\boxed{\lambda=2\iff
\text{存在具有指定根和接边的成功连通吸收区域}.}
\tag{28}
\]

有限 \(\lambda\ge3\) 只证明这个受限选择的最佳结果仍有至少 \(\lambda\) 个圈；
\(+\infty\) 只证明这个选择不可行。二者都不是原目标的反例。

实现时可用 \(L=n+1\) 替代无穷，因为共有 \(|C|=n\) 条单位弧，任一无硬违规的割容量至多 \(n\)。
最小割小于 \(L\) 当且仅当真正存在有限割。平行容量应相加，不能用后一条弧覆盖前一条；特别是
同一方向可能既有硬蕴含又有单位弧。Pro 提及的实现包未随本次可读正文提供，本文核验的是完整
数学编码，并用附录独立检查固定输入；不声称检查过未取得的实现源码。

### 7.4 覆盖的准确范围及一个可删除的枚举

任一成功连通吸收的两条接边必跨根；选择它们和任意 \(\rho\in B\)，就落入一个网络。更一般地，
该网络族覆盖本类中一切有根分离的区域。根仍同圈的 \(r=1\) 或同侧接点区域不在此族中。
§9 的固定图确有这种区域，故“全部连通吸收”不宜无条件照搬。

固定 \(C\) 时，\(|O||C|^2=O(n^3)\) 个线性规模网络是正确的上界。不过若目的是寻找某个成功区域，
可以直接选择

\[
\rho=o_0.
\tag{29}
\]

任何保留 \(h_0\) 的区域已经包含 \(o_0\)。以 \(o_0\) 为根的树蕴含恰覆盖所有这些连通 \(B\)，
故并未增加限制；并且

\[
\min_{\rho\in O}\lambda(C,\rho,h_0,h_1)
=\lambda(C,o_0,h_0,h_1).
\tag{30}
\]

因此固定父圈只需 \(O(n^2)\) 个网络。此简化没有减少需要考虑的完整父圈族。

## 8. 集中攻击容量 2：精确降到两个接边删除后的可达性

现在固定 \(C,h_0,h_1\)，采用 (29)。把只由硬蕴含组成的面变量有向图记为 \(D_\infty\)，
包括 (20)–(23) 及保护 \(f\) 的双向弧。用集合表示 pins：

\[
S=\{o_0,o_1\},\qquad
Z=\{a,b,i_0,i_1,o_v,o_x\}.
\tag{31}
\]

\(S\) 强制一，\(Z\) 强制零，重复顶点只计一次；若相交，当然不可行。

在 \(D_\infty\) 上加入所有 (26) 的有向弧，**仅去掉 \(h_0,h_1\) 对应的两条单位弧**，
得到 \(D^-_{C,h_0,h_1}\)。如果相同端点间还存在硬弧，它必须保留，不能连硬约束一起删掉。

**定理 3。** 记 \(\operatorname{Reach}_D(S)\) 为从 \(S\) 出发的有向可达闭包，则

\[
\boxed{
\lambda(C,o_0,h_0,h_1)=2
\iff
\operatorname{Reach}_{D^-_{C,h_0,h_1}}(S)\cap Z=\varnothing.
}
\tag{32}
\]

证明。任何可行赋值都因 (25) 割断指定的两条单位弧，已付出容量二。总容量为二当且仅当
其余所有单位弧也都满足源侧闭包条件，恰与全部硬弧一起成为 \(D^-\) 的闭包条件。
若存在从 \(S\) 到 \(Z\) 的路径，沿蕴含传播一必碰到强制零，故不可能。
若不存在，取

\[
U_*=\operatorname{Reach}_{D^-}(S).
\tag{33}
\]

它包含 \(S\)、避开 \(Z\)、对全部所保留弧闭合，因而给出有限割且只割断指定的两条单位弧。
由 §7 解码得到同一个成功匹配。证毕。

这还给出失败证书的精确分层。

* 若 \(D_\infty\) 已有 \(S\to Z\) 路径，则硬条件矛盾，\(\lambda=+\infty\)。
* 若硬条件可行，但 \(D^-\) 有这样的路径，则每个有限割除了指定两弧，还必须割断路径上的某条
  其他单位弧，故 \(\lambda\ge3\)。该单路径不声称证明更大的精确下界。
* 若没有路径，(33) 直接给出容量二，不必再运行最大流或另找吸收集合。

每个图有 \(O(n)\) 个点、弧，因此固定父圈上的存在性，可由 \(O(n^2)\) 次线性可达性判定，
总计 \(O(n^3)\) 时间、单次 \(O(n)\) 空间完成。不必保存面集族，也不必执行任何图阶枚举。
这是**条件判定的进一步化简**，仍没有证明某一对 \(h_0,h_1\) 的可达性必失败。

## 9. 固定 24 点证书：最小失效接口可以直接手查

使用前份推导 §7 的同一图、同一面号及同一父圈。附录明确列出全部 14 张面和父圈，因此数据
不依赖旧结论。这里

\[
\begin{aligned}
I&=\{0,1,7,8,9,11,13\},&O&=\{2,3,4,5,6,10,12\},\\
e^*&=\{0,9\},& f^*&=\{0,1\},\\
I_0&=\{0,1,7,8\},&I_1&=\{9,11,13\}.
\end{aligned}
\tag{34}
\]

原边 \(e=(0,16),f=(1,2)\)。旧匹配为

\[
\begin{split}
M=\{&(0,16),(1,2),(3,17),(4,11),(5,6),(7,14),\\
     &(8,20),(9,10),(12,13),(15,23),(18,19),(21,22)\}.
\end{split}
\]

### 9.1 真实容量三及 \(J_U\) 非森林

令 \(A=\varnothing\)、\(B=\{12\}\)。面 12 的边界为
\((15,14,7,8,20,23)\)，是避 \(e,f\) 的交替六圈，故联合条件全部成立。它的三个接边为

| 原边 | \(I\)-端 | \(O\)-端 |
|---|---:|---:|
| \((7,8)\) | 1 | 12 |
| \((14,15)\) | 7 | 12 |
| \((20,23)\) | 13 | 12 |

它们跨越 \(I_0,I_1\)，所以 \(r=3\)、根分圈、\(\beta(J_U)=1\)。匹配的变化为

\[
N=M\setminus\{(7,14),(8,20),(15,23)\}
\ \cup\ \{(7,8),(14,15),(20,23)\}.
\tag{35}
\]

直接取补得到三个圈，长度为 \(4,6,14\)。这是真实反例，但只反驳
“任意可用连通吸收的整个 \(J_U\) 都自动无圈”的无条件读法；不反驳 (16)、(28) 或原存在命题。

更精确地，选 \(\rho=12\)、\(h_0=(14,15)\)、\(h_1=(20,23)\)。这强制
\(y_{12}=1,x_7=x_{13}=0\)。保护 \(f\) 又给出 \(x_1=x_0=0\)，因此第三条
\((7,8)^*\) 也必被割断。于是每个有限割容量至少三，而 (35) 达到三：

\[
\lambda(C,12,(14,15),(20,23))=3.
\tag{36}
\]

在 (32) 中，其最短类型的阻断证书就是

\[
y_{12}\ \xrightarrow{\text{额外单位弧 }(7,8)^*}\ x_1
\ \xrightarrow{\text{保护 }f}\ x_0\in Z.
\tag{37}
\]

这条路径没有违反任何局部 NAE、平面性或连通性条件。保留两个接边可能同时迫出第三个接边，
确实是容量二选择中真实存在的失效接口。

### 9.2 换接边即可成功，不能由 (36) 推全族失败

改选 \(h_0=(7,8),h_1=(20,23)\)，允许翻转叶面 7。取 \(U=\{7,12\}\)，
面 7 的边界是 \((12,13,14,15)\)。它消去第三个接点，得到容量二；补图两个圈长度为 \(10,14\)，
根分离。这也说明固定某对接边失败与存在另一对成功是不同量词。

### 9.3 本轮实际运行及其证据边界

附录程序只用标准库，对这个固定图流式检查 \(2^{14}=16384\) 个面赋值。它将原图逐顶点匹配检验、
直接的 \(K,B\) 连通性检验，与全部七种 \(\rho\) 的硬蕴含编码逐赋值比较，再独立比较带接边 pins
的几何最小容量与 (32) 的路径判据。没有运行 Pro 未提供的最大流实现。

| 量 | 本轮结果 |
|---|---:|
| 面赋值 | 16384 |
| 跨根接边对 | 135 |
| 带 \(\rho\) 的网络实例 | 945 |
| 可用且保 \(e,f\) 的连通吸收区域 | 6 |
| 按 \(r=1,2,3\) 的区域数 | 1、3、2 |
| 成功的根分离二圈区域 | \(\{3,8\},\{7,12\}\) |
| 最小割为 \(+\infty,3,2\) 的网络数 | 941、2、2 |

其中一个 \(r=2\) 区域根仍同圈，另有一个 \(r=1\) 区域。这两个区域不在强制跨根接边网络的
覆盖范围内，直接支持 §7.4 的量词收缩。全部六个区域的翻转边界都只有一个圈，与定理 2 一致。

为核验这里使用的“真实合法历史、全局 \(H^{+-}\)、困难前件”而非沿用旧数字，已完整阅读并执行
[原固定证书 checker](check_two_sided_independent_20260927.py)：

```sh
python3 -B scratch/check_two_sided_independent_20260927.py
```

它仅重建已有历史及流式遍历此固定 24 点图的 170 个完美匹配，输出
`FIXED_24_CERTIFICATE_VERIFIED`，核得 34 个 Hamilton 圈、全部 \(36\cdot35=1260\) 个有序边对
含避见证、\(|J_G(e,f)|=1\)、\(|\mathcal C|=3\)，三个父圈的好内部四面数为 \(0,1,1\)。
所以本例**不满足全族 \(\mathsf L\)**，不得把 (36) 或其他固定选择失败升级为 \(\mathsf{Hard}\)
下的反例。本轮没有尝试搜索一个满足 \(\mathsf L\) 的新图。

## 10. 完整父圈族的精确 GAP 与停止点

结合 (28)、(30)、(32)，Pro 的全族受限存在性现在精确等价于

\[
\boxed{
\mathsf{Hard}(G,p,e,q,f)
\Longrightarrow
\exists C\in\mathcal C\ \exists h_0^*=i_0o_0,h_1^*=i_1o_1,
\ i_j\in I_j:\quad
\operatorname{Reach}_{D^-_{C,h_0,h_1}}(\{o_0,o_1\})
\cap\{a,b,i_0,i_1,o_v,o_x\}=\varnothing.
}
\tag{GAP}
\]

本轮尝试的关键步骤是：能否由完整父圈族的前件排除 \(D^-\) 中的强制一到强制零路径。
已把“路径一旦不存在，如何产出同一个成功匹配”完全解决；(33) 就是构造。
但一条阻断路径完全可以只有一个额外单位弧加保护 \(f\) 的等式，(37) 已在满足全局 \(H^{+-}\)
和 (2)、且指定父圈没有好四面的真实输入上实现。因此，仅凭这些前件就对每个接边对排除
阻断路径的加强为假。该例不满足全族 \(\mathsf L\)，并未反驳再加入它之后的逐对加强，更未反驳
(GAP)。即使本例另有成功对，也不能把这个事实推广到所有满足 \(\mathsf{Hard}\) 的图。

尚缺的最小全称排除式是

\[
\mathsf{Hard}\ \wedge\
\bigl[\forall C\in\mathcal C\ \forall(h_0,h_1)\text{ 跨根},\
\operatorname{Reach}_{D^-_{C,h_0,h_1}}(S)\cap Z\ne\varnothing\bigr]
\quad\Longrightarrow\quad\bot.
\tag{38}
\]

§3–8 只分别描述每个父圈的网络，没有给出跨父圈的阻断路径相容性定理。全局 \(H^{+-}\) 提供
\(\mathcal C\ne\varnothing\)；(2) 使其全部父圈满足 (3)；\(\mathsf L\) 排除内部四面的直接修复。
这些已证明的用途都没有推出 (38)。若要通过阻断路径更换父圈，必须证明由它构造出的新匹配
补图仍为 Hamilton、仍避 \(f\)，并使某个阻断消失；合法匹配或一般 alternating exchange 本身
不给这三个结论。本文没有把这一步作为隐含引理。

还存在另一条不可混淆的边界：原目标 (4) 可由任意可用 \(U\) 实现，而本网络要求 \(K,B\) 连通，
且定理 2 已证明其差集只能是一条交替圈。未证明任何原目标见证都可在更换父圈后规范化为此类。
因此即使将来真实反例使 (GAP) 的后件对全部父圈失败，也只反驳这一受限机制；仍须另证原目标
无解，才能反驳原存在命题或冻结 (T)。

**停止于 (GAP)/(38)。** 正式条件归约已独立核验，范围上的两处误读已有解析修正，其中
“整个 \(J_U\) 无条件无圈”还有真实固定反例。没有把条件归约、路径判定或固定证书通过当作
完整父圈族存在性。只新增本 scratch 文件；不晋级、不提交、不推送。

## 附录：固定面赋值与网络编码的独立小检查

下列代码是本轮新增检查的完整内容，输入固定为上述 14 张面。内存只保存这个固定图、945 个
最小值及少量计数；逐个处理赋值，不存储面集族或匹配族。它无需安装依赖、访问网络或输出其他文件。
在 Barnette 目录可执行本文件中唯一的 Python 代码块：

```sh
python3 -B - <<'PY'
from pathlib import Path
p = Path('scratch/connected-absorption-independent-20260927.md')
src = p.read_text().split('```python\n', 1)[1].split('\n```', 1)[0]
exec(compile(src, str(p) + ':appendix', 'exec'))
PY
```

```python
from collections import Counter

F = [(16,17,3,2,1,13,12,0), (6,9,8,7,1,2), (5,6,2,3),
     (6,5,18,19,10,9), (8,9,10,11,21,20), (1,7,14,13),
     (4,0,12,15,23,22), (12,13,14,15), (17,18,5,3),
     (19,16,0,4,11,10), (19,18,17,16), (11,4,22,21),
     (15,14,7,8,20,23), (20,21,22,23)]

def rim(face):
    return {tuple(sorted(e)) for e in zip(face, face[1:] + face[:1])}

def comps(vs, es):
    adj = {v: set() for v in vs}
    for a, b in es:
        if a in adj and b in adj:
            adj[a].add(b)
            adj[b].add(a)
    unseen, ans = set(vs), []
    while unseen:
        todo, found = [min(unseen)], set()
        while todo:
            v = todo.pop()
            if v not in found:
                found.add(v)
                todo.extend(adj[v] - found)
        unseen -= found
        ans.append(found)
    return ans

E = set().union(*(rim(face) for face in F))
dual = {g: tuple(i for i, face in enumerate(F) if g in rim(face)) for g in E}
assert all(len(ends) == 2 for ends in dual.values())
C = rim((0,4,22,23,20,21,11,10,19,16,17,18,
         5,3,2,6,9,8,7,1,13,14,15,12))
M, V, Q = E - C, set(range(24)), set(range(14))
e, f = (0,16), (1,2)
T = [dual[g] for g in M]
a, b = dual[e]
I = next(part for part in comps(Q, T) if a in part)
O = Q - I
assert {a,b} <= I
I0, I1 = comps(I, [dual[g] for g in M - {e}])
if a not in I0:
    I0, I1 = I1, I0
tri = [tuple(i for i, face in enumerate(F) if v in face) for v in V]
assert all(len(t) == 3 for t in tri)
ce = [(g, next(v for v in dual[g] if v in I),
          next(v for v in dual[g] if v in O)) for g in sorted(C)]
pairs = [(h,k) for h in ce for k in ce if h[1] in I0 and k[1] in I1]

def oriented(vs, root):
    out, seen, todo = [], {root}, [root]
    while todo:
        p = todo.pop()
        for u, v in T:
            d = v if u == p else u if v == p else None
            if d in vs and d not in seen:
                seen.add(d)
                todo.append(d)
                out.append((p,d))
    assert seen == vs
    return out

base = []
for p, d in oriented(I0,a) + oriented(I1,b):
    base.append((p,d))
    for t in tri:
        if p in t and d in t:
            o = next(v for v in t if v not in (p,d))
            base.extend([(p,o), (o,d)])
zero = {a,b} | {next(v for v in t if v not in (a,b))
                 for t in tri if a in t and b in t}
z, w = dual[f]
base.extend([(z,w), (w,z)])
hard = {}
for rho in O:
    arcs = list(base)
    for p, d in oriented(O,rho):
        arcs.append((d,p))
        for t in tri:
            if p in t and d in t:
                i = next(v for v in t if v not in (p,d))
                arcs.extend([(d,i), (i,p)])
    hard[rho] = set(arcs)

best, hist, success, all_valid = {}, Counter(), [], 0
for mask in range(1 << 14):
    U = {i for i in Q if mask >> i & 1}
    K, B = I - U, O & U
    boundary = {g for g, (z,w) in dual.items() if (z in U) != (w in U)}
    N = M ^ boundary
    pm = Counter(v for g in N for v in g) == Counter(V)
    geom = (bool(B) and {a,b} <= K and len(comps(K,T)) == 1
            and len(comps(B,T)) == 1 and pm and {e,f} <= N)
    for rho in O:
        enc = (rho in U and not zero & U
               and all(z not in U or w in U for z,w in hard[rho]))
        assert enc == (geom and rho in B), (mask,rho)
    if not geom:
        continue
    all_valid += 1
    assert len(comps(U,dual.values())) == len(comps(Q-U,dual.values())) == 1
    assert len(comps({v for g in boundary for v in g},boundary)) == 1
    contacts = [h for h in ce if h[1] in K and h[2] in B]
    r = len(contacts)
    hist[r] += 1
    if r:
        assert len(comps(V,E-N)) == r
        newO = (I & U) | (O - U)
        ne = [dual[g] for g in N if set(dual[g]) <= newO]
        assert len(ne) - len(newO) + len(comps(newO,ne)) == 0
    for h, k in pairs:
        if h in contacts and k in contacts:
            assert not any(set(e) <= part for part in comps(V,E-N))
            for rho in B:
                key = (rho,h[0],k[0])
                best[key] = min(best.get(key,99),r)
    if r == 2 and any(h in contacts and k in contacts for h,k in pairs):
        success.append(sorted(U))
    if U == {12}:
        hn = [dual[g] for g in N - {e}]
        assert (r, sorted(map(len,comps(V,E-N))),
                len(hn)-14+len(comps(Q,hn))) == (3,[4,6,14],1)

def reachable(src, arcs):
    reach, todo = set(src), list(src)
    adj = {v: set() for v in Q}
    for z, w in arcs:
        adj[z].add(w)
    while todo:
        z = todo.pop()
        for w in adj[z] - reach:
            reach.add(w)
            todo.append(w)
    return reach

counts = Counter()
for rho in O:
    for h, k in pairs:
        src, dst = {rho,h[2],k[2]}, zero | {h[1],k[1]}
        val = best.get((rho,h[0],k[0]),99)
        assert (not reachable(src,hard[rho]) & dst) == (val < 99)
        arcs = hard[rho] | {(o,i) for g,i,o in ce if g not in (h[0],k[0])}
        assert (not reachable(src,arcs) & dst) == (val == 2)
        counts['infinite' if val == 99 else str(val)] += 1
assert all_valid == 6 and hist == {3:2, 2:3, 1:1}
assert success == [[3,8], [7,12]]
assert counts == {'infinite':941, '3':2, '2':2}
print({'face_masks':1 << 14, 'rooted_networks':len(O)*len(pairs),
       'contact_pairs':len(pairs), 'geometric_absorptions':all_valid,
       'r_histogram':dict(hist), 'min_values':dict(counts),
       'successful_regions':success})
print('FIXED_FACE_ENCODING_AND_TWO_CONTACT_REACHABILITY_VERIFIED')
```
