# Complete attachment calculus for all new-cell rooted bonds

This draft uses only Notes 108--113.  It classifies bondness for every
opposite-gate pair in the complete rooted child NAE family having at least
one endpoint in

\[
{\cal N}=\{R_{00},X_{uy},X_{vx}\}.
\]

No parent ancestry is assumed.

## 1. Normalization and component predicates

Write

\[
R=R_{00},\qquad U=X_{uy},\qquad V=X_{vx},
\qquad {\cal C}=\{C_{00},C_{10},C_{01}\}.
\]

The local \(C_{11}\) row never belongs to the rooted target family: its
isolated \(C\)-component gives the isolated central complement cycle.
Thus the complete rooted family uses exactly the six cells
\({\cal C}\cup{\cal N}\).

Let

\[
H=T^+-\{A,B,C\},\qquad
J_A=N(A)\cap V(H),\qquad J_B=N(B)\cap V(H).
\]

For two cell orbits choose the unique representatives equal to the
five-bit rows of Note 108 and put

\[
D=\{v\in V(H):\chi(v)\ne\eta(v)\}.
\tag{1}
\]

Simultaneous global reversal does not change \(D\).  Reversing only one
representative would replace the prescribed local XOR row by its
complement and is excluded by this normalization.  Bondness itself is of
course unchanged by replacing the entire shore with its complement.

For \(S\subseteq V(H)\), define

\[
\begin{aligned}
h_A(S)&:\Longleftrightarrow
  \forall K\in\pi_0(H[S]),\quad K\cap J_A\ne\varnothing,\\
h_B(S)&:\Longleftrightarrow
  \forall K\in\pi_0(H[S]),\quad K\cap J_B\ne\varnothing,\\
h_{AB}(S)&:\Longleftrightarrow
  \forall K\in\pi_0(H[S]),\quad
  K\cap(J_A\cup J_B)\ne\varnothing,\\
j_{AB}(S)&:\Longleftrightarrow
  \exists K\in\pi_0(H[S]):\
  K\cap J_A\ne\varnothing\ne K\cap J_B,\\
e_{PQ}(S)&:\Longleftrightarrow
  \forall K\in\pi_0(H[S]),\quad K\cap\{P,Q\}\ne\varnothing.
\end{aligned}
\tag{2}
\]

Write \(\operatorname{conn}(S)\) when \(H[S]\) is nonempty and connected.
For every pair considered below, opposite gate bits imply that the external
gate dual edge crosses \(D\), so both \(D\) and \(\bar D\) are nonempty.
There is therefore no empty-shore convention hidden in the table.

## 2. The complete table

**Theorem 1.**  Let \(\chi,\eta\) be root-admissible NAE colourings with
opposite surviving-gate bits.  If at least one local cell belongs to
\({\cal N}\), their XOR cut is a bond exactly under the condition in the
last column.

\[
\begin{array}{c|c|c}
\text{cell pair}&
W\cap\{A,B,C,P,Q\}&
\text{bond criterion}\\ \hline
C_{00}\!-\!U,\ C_{10}\!-\!U,\ C_{01}\!-\!U&
ACPQ,\ AQ,\ AP&
h_A(D)\wedge h_B(\bar D)\\
C_{00}\!-\!V,\ C_{10}\!-\!V,\ C_{01}\!-\!V&
BCPQ,\ BQ,\ BP&
h_B(D)\wedge h_A(\bar D)\\
R\!-\!V&AC&
h_A(D)\wedge h_B(\bar D)\\
R\!-\!U&BC&
h_B(D)\wedge h_A(\bar D)\\
C_{10}\!-\!R,\ C_{01}\!-\!R&
ABCQ,\ ABCP&
h_{AB}(D)\wedge\operatorname{conn}(\bar D)\\
C_{00}\!-\!R&ABPQ&
\text{never for opposite gate bits}\\
R\!-\!R,\ U\!-\!U,\ V\!-\!V&
\varnothing&
\operatorname{conn}(D)\wedge h_{AB}(\bar D)\\
U\!-\!V&AB&
h_{AB}(D)\wedge j_{AB}(D)\wedge e_{PQ}(\bar D).
\end{array}
\tag{3}
\]

The three same-cell rows mean two distinct colourings in that cell; opposite
gate bits already ensure distinctness.

*Proof.*  Contract every component of \(H[D]\) and \(H[\bar D]\).  Retain
only the new vertices \(A,B,C\).  A retained \(A\) joins precisely those
component nodes meeting \(J_A\), a retained \(B\) those meeting \(J_B\),
and a retained \(C\) the component nodes containing \(P\) or \(Q\).
Retain also the local edges \(AC,BC\).  Each XOR shore is connected if and
only if its resulting attachment quotient is connected.

For every \(C\)--\(U\) row, and also \(R\)--\(V\), the \(D\)-shore has one
local core attached through \(J_A\), while the complementary shore has one
local core attached through \(J_B\).  This gives the first and third rows.
Exchanging \(A,B\) gives the second and fourth rows.

For \(C_{10}\)--\(R\) and \(C_{01}\)--\(R\), the \(D\)-shore has the
connected local core \(ABC\), attached through \(J_A\cup J_B\); the other
shore has no new local vertex.  Hence its two requirements are
\(h_{AB}(D)\) and \(\operatorname{conn}(\bar D)\).

For \(C_{00}\)--\(R\), the complementary local core is the singleton
\(C\), but both of its old neighbours \(P,Q\) lie in \(D\).  General
bondness would force \(\bar D=\varnothing\).  Opposite gate bits force the
external gate edge to cross \(D\), hence \(\bar D\ne\varnothing\).
This pair can therefore never give a rooted bond.

For a same-cell pair, the \(D\)-shore has no new local vertex, so it must be
connected inside \(H\).  The other shore contains the connected patch
\(ABC\) and attaches to old components through \(J_A\cup J_B\), giving the
seventh row.

Finally, for \(U\)--\(V\), the \(D\)-shore has two local cores \(A,B\).
Every old component must attach to at least one of them, and some one
component must attach to both in order to join the two cores.  These are
\(h_{AB}(D)\) and \(j_{AB}(D)\).  The complementary local core is \(C\);
it joins old components only through \(P,Q\), giving
\(e_{PQ}(\bar D)\).  These cases exhaust the unordered pairs among the six
rooted cells having an endpoint in \({\cal N}\). \(\square\)

The theorem is conditional on both endpoints already being NAE and fully
root-admissible.  Its predicates test only shore connectivity, hence
bondness.  Opposite gate bits supply the surviving-gate condition.

## 3. The minimum obstruction alphabet

Under parent kill cover, Note 108 excludes every canonical--canonical
rooted bond.  Since \(C_{11}\) is absent, the rooted split-bond conclusion
fails exactly when no pair in Theorem 1 realizes its row.

All failures in (3) have one of four irreducible forms.

1. **\(\mathsf O\), occupancy void.**  There is no opposite-gate pair with
   an endpoint in \({\cal N}\).  The parent kill-cover edge condition does
   not exclude this form by Note 113.
2. **\(\mathsf F_0\), bare-shore fragmentation.**  A shore has no new local
   core and its induced old graph has at least two components.  This is the
   failure of \(\operatorname{conn}(D)\) or
   \(\operatorname{conn}(\bar D)\).
3. **\(\mathsf F_1\), unattached island.**  A shore has one connected local
   core, but some old component misses its full attachment set.  This is
   the failure of one of \(h_A,h_B,h_{AB},e_{PQ}\).  The
   \(C_{00}\)--\(R\) row is a forced instance: its \(C\)-core has no
   available attachment because \(P,Q\in D\), while opposite gate bits
   force \(\bar D\ne\varnothing\).
4. **\(\mathsf F_2\), unbridged double core.**  The \(U\)--\(V\)
   \(D\)-shore has local cores \(A,B\); every old component may attach to
   one core, but none attaches to both.  This is
   \(h_{AB}(D)\wedge\neg j_{AB}(D)\).

These types are complete because an XOR shore in (3) has zero, one, or two
local core components after \(H\) is deleted.  For zero cores connectivity
is \(\mathsf F_0\); for one core its only failure is \(\mathsf F_1\); for
two cores the additional irreducible failure is \(\mathsf F_2\).
Occupancy failure occurs before any attachment quotient exists and cannot
be merged with those three.

Equivalently, a nonempty candidate family fails the rooted split-bond
conclusion precisely when every opposite-gate candidate pair is blocked by
at least one symbol in

\[
\boxed{\{\mathsf F_0,\mathsf F_1,\mathsf F_2\},}
\tag{4}
\]

while the full failure alphabet including empty candidate occupancy is

\[
\boxed{\{\mathsf O,\mathsf F_0,\mathsf F_1,\mathsf F_2\}.}
\tag{5}
\]

Notes 108--113 do not exclude any member of (5) for actual arbitrary-order
split pairs.  The table is a complete analytic reduction, not a proof of
the rooted split-bond lemma and not an actual counterexample.
