裁决：两条必要结构定理有效。\(\Lambda\) 等价须限定于根分离的连通吸收；偶割论证有效，但不能排除 \(\Lambda=\infty\)。

`Hard ⇒ Λ<∞` 仍有明确缺口，未证明存在性。已完成固定图轻量检查并止步。

已写入：[独立核验全文](scratch/absorption-interval-independent-20260927.md) 与 [结果文件](scratch/absorption-interval-independent-20260927-results.json)。未修改既有文件、晋级、提交或访问远程。