#!/usr/bin/env python3
"""Verify a real fixed fibre whose degree projection is not polymatroidal.

The order-12 graph is a simple cubic bipartite planar brace.  We enumerate
the complete fixed fibre at root 0 with port 6 alone, compute its exact
Y-degree vectors and their complementary degree support function, and check
both a submodularity violation and an M-convex symmetric-exchange failure.
"""

from __future__ import annotations

from itertools import combinations, product

import networkx as nx


GRAPH6 = "K??FEagT@WB_"
ROOT = 0
SINGLETON_PORT = 6
Edge = tuple[int, int]
Vector = tuple[int, ...]


def edge(a: int, b: int) -> Edge:
    return (a, b) if a < b else (b, a)


def strict_hall_brace(graph: nx.Graph, x_side: tuple[int, ...]) -> bool:
    n = len(x_side)
    for size in range(1, n - 1):
        for shore in combinations(x_side, size):
            neighbours = set().union(*(set(graph[x]) for x in shore))
            if len(neighbours) < size + 2:
                return False
    return True


def fixed_fibre_vectors(
    graph: nx.Graph,
) -> tuple[tuple[int, ...], tuple[int, ...], tuple[Vector, ...], int]:
    colour = nx.bipartite.color(graph)
    y_side = tuple(sorted(v for v in graph if colour[v] == colour[ROOT]))
    x_side = tuple(sorted(set(graph) - set(y_side)))
    y_order = tuple(y for y in y_side if y != ROOT)
    ports = tuple(sorted(graph[ROOT]))
    assert ports == (6, 7, 8)

    pole_vertices = tuple(sorted(set(graph) - {ROOT}))
    pole = graph.subgraph(pole_vertices)
    choices: list[tuple[frozenset[Edge], ...]] = []
    for x in x_side:
        required = 1 if x in ports else 2
        incident = tuple(sorted(edge(x, y) for y in pole[x]))
        choices.append(
            tuple(frozenset(selected) for selected in combinations(incident, required))
        )

    vectors: set[Vector] = set()
    raw_count = 0
    for local_selection in product(*choices):
        selected = frozenset().union(*local_selection)
        forest = nx.Graph()
        forest.add_nodes_from(pole_vertices)
        forest.add_edges_from(selected)
        if not nx.is_forest(forest) or nx.number_connected_components(forest) != 2:
            continue
        components = tuple(
            frozenset(component) for component in nx.connected_components(forest)
        )
        port_blocks = sorted(
            (tuple(sorted(set(component) & set(ports))) for component in components),
            key=lambda block: (len(block), block),
        )
        if port_blocks != [(SINGLETON_PORT,), (7, 8)]:
            continue
        raw_count += 1
        vector = tuple(forest.degree(y) for y in y_order)
        assert min(vector) >= 1 and max(vector) <= 3
        assert sum(vector) == 2 * len(x_side) - 3
        vectors.add(vector)

    return x_side, y_order, tuple(sorted(vectors)), raw_count


def support(
    complement_vectors: tuple[Vector, ...], selected: frozenset[int]
) -> int:
    return max(sum(vector[index] for index in selected) for vector in complement_vectors)


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert not graph.is_multigraph()
    assert graph.number_of_nodes() == 12 and graph.number_of_edges() == 18
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    planar, _ = nx.check_planarity(graph)
    assert planar

    colour = nx.bipartite.color(graph)
    x_side_from_colour = tuple(
        sorted(v for v in graph if colour[v] != colour[ROOT])
    )
    assert strict_hall_brace(graph, x_side_from_colour)

    x_side, y_order, degree_vectors, raw_count = fixed_fibre_vectors(graph)
    assert x_side == x_side_from_colour == (6, 7, 8, 9, 10, 11)
    assert y_order == (1, 2, 3, 4, 5)
    assert raw_count == 22
    assert len(degree_vectors) == 13

    expected_vectors = (
        (1, 1, 2, 2, 3),
        (1, 1, 2, 3, 2),
        (1, 1, 3, 2, 2),
        (1, 1, 3, 3, 1),
        (1, 2, 2, 1, 3),
        (1, 2, 2, 2, 2),
        (1, 2, 3, 1, 2),
        (1, 2, 3, 2, 1),
        (2, 1, 1, 2, 3),
        (2, 1, 1, 3, 2),
        (2, 1, 2, 2, 2),
        (2, 1, 2, 3, 1),
        (2, 2, 2, 2, 1),
    )
    assert degree_vectors == expected_vectors

    # For K=E(F-r)\J, cubicity gives deg_K(y)=3-deg_J(y).
    complement_vectors = tuple(
        tuple(3 - coordinate for coordinate in vector)
        for vector in degree_vectors
    )
    a_set = frozenset((0, 2))      # Y-set {1,3}
    b_set = frozenset((2, 3))      # Y-set {3,4}
    union = a_set | b_set
    intersection = a_set & b_set
    support_values = (
        support(complement_vectors, a_set),
        support(complement_vectors, b_set),
        support(complement_vectors, union),
        support(complement_vectors, intersection),
    )
    assert support_values == (3, 3, 5, 2)
    assert support_values[0] + support_values[1] < (
        support_values[2] + support_values[3]
    )

    # Symmetric M-convex exchange fails for a,b at coordinate i=Y-vertex 2.
    first = (1, 2, 3, 2, 1)
    second = (2, 1, 1, 2, 3)
    assert first in degree_vectors and second in degree_vectors
    i = 1
    candidate_indices = tuple(
        j for j in range(len(first)) if first[j] < second[j]
    )
    assert candidate_indices == (0, 4)
    exchange_outcomes = []
    degree_set = set(degree_vectors)
    for j in candidate_indices:
        first_exchange = list(first)
        second_exchange = list(second)
        first_exchange[i] -= 1
        first_exchange[j] += 1
        second_exchange[i] += 1
        second_exchange[j] -= 1
        outcome = (
            tuple(first_exchange),
            tuple(first_exchange) in degree_set,
            tuple(second_exchange),
            tuple(second_exchange) in degree_set,
        )
        exchange_outcomes.append(outcome)
        assert not (outcome[1] and outcome[3])

    # This route obstruction is not a counterexample to the degree box.
    integral_box_witness = (1, 2, 2, 2, 2)
    assert integral_box_witness in degree_vectors
    assert max(integral_box_witness) <= 2

    print("graph6", GRAPH6)
    print("root", ROOT)
    print("ports", tuple(sorted(graph[ROOT])))
    print("singleton_port", SINGLETON_PORT)
    print("x_side", x_side)
    print("y_order", y_order)
    print("raw_fixed_fibre_forests", raw_count)
    print("distinct_degree_vectors", len(degree_vectors))
    print("support_sets", (tuple(y_order[i] for i in a_set), tuple(y_order[i] for i in b_set)))
    print("support_values_A_B_union_intersection", support_values)
    print("mconvex_pair", first, second, "exchange_coordinate", y_order[i])
    print("mconvex_exchange_outcomes", tuple(exchange_outcomes))
    print("integral_degree_box_witness", integral_box_witness)
    print("ACTUAL_FIXED_FIBRE_NONPOLYMATROID_VERIFIED")


if __name__ == "__main__":
    main()
