# The fixed-fibre degree projection is not polymatroidal

Let \(F\) be the planar order-twelve brace with graph6 string

```text
K??FEagT@WB_
```

take root \(r=0\), ports \((6,7,8)\), and the nonempty fibre in which port
\(6\) is alone.  In the coordinate order

\[
Y\setminus\{r\}=(1,2,3,4,5),
\]

complete enumeration gives 22 forests and the following 13 distinct
\(Y\)-degree vectors:

\[
\begin{split}
&(1,1,2,2,3),(1,1,2,3,2),(1,1,3,2,2),(1,1,3,3,1),\\
&(1,2,2,1,3),(1,2,2,2,2),(1,2,3,1,2),(1,2,3,2,1),\\
&(2,1,1,2,3),(2,1,1,3,2),(2,1,2,2,2),(2,1,2,3,1),\\
&(2,2,2,2,1).
\end{split}
\tag{1}
\]

For \(K_J=E(F-r)\setminus J\), put

\[
u(J)_y=\deg_{K_J}(y)=3-d(J)_y
\]

and define the upper support set function

\[
g(S)=\max_{J\in\mathcal F_0}\sum_{y\in S}u(J)_y.
\tag{2}
\]

For

\[
A=\{1,3\},\qquad B=\{3,4\},
\]

the exact values are

\[
g(A)=3,\quad g(B)=3,\quad g(A\cup B)=5,\quad g(A\cap B)=2.
\tag{3}
\]

Consequently

\[
g(A)+g(B)=6<7=g(A\cup B)+g(A\cap B),
\tag{4}
\]

so \(g\) is not submodular.  In particular, the complement-degree
polytope is not a polymatroid base polytope.  It also cannot be the
block-count projection of the bases of one matroid: for such a projection,
\(g(S)\) would be the matroid rank of the union of the blocks indexed by
\(S\), hence submodular.

The stronger discrete exchange formulation fails in the same fibre.  Take

\[
a=(1,2,3,2,1),\qquad b=(2,1,1,2,3).
\tag{5}
\]

Use the coordinate labelled by the \(Y\)-vertex \(2\), where
\(a_2>b_2\). The coordinates with \(a_j<b_j\) are \(j=1,5\). At \(j=1\),
neither exchanged vector belongs to (1). At \(j=5\), the exchanged vector
from \(a\) does belong to (1), but the exchanged vector \((2,2,1,2,2)\)
from \(b\) does not. Thus no \(j\) satisfies the symmetric
\(M\)-convex exchange axiom.

This closes the direct route that would prove the weighted dual by treating
the fixed-fibre degree vectors as a matroid/polymatroid base family and then
applying greedy integration over the nested level sets of \(\lambda\).  The
failure occurs with full genuine incidence, planarity, cubicity, and the
brace strict Hall inequalities; it is not an abstract vector model.

It is not a counterexample to the degree-box statement.  Vector
\((1,2,2,2,2)\) in (1) is already an integral capacity-two witness.  Hence
the universal weighted assertion remains open and must use a weaker
convex/exchange principle than submodularity or \(M\)-convexity, or use the
joint structure of the three common-base constraints directly.

The self-contained verifier is
`verify_actual_fixed_fibre_nonpolymatroid.py`.  Run

```bash
uv run --python 3.12 --with networkx \
  verify_actual_fixed_fibre_nonpolymatroid.py
```

and check the marker
`ACTUAL_FIXED_FIBRE_NONPOLYMATROID_VERIFIED`.
