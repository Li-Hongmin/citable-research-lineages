"""Check one explicit Route-3 collision; standard library, no graph census.

Run: python3 scratch/route3_short_arc_refinement/verify_short_arc_collision.py
"""

from itertools import combinations


def edge(u, v):
    return tuple(sorted((u, v)))


def edges(rotation):
    return {edge(u, v) for u, ns in rotation.items() for v in ns}


def components(adj):
    unseen = set(adj)
    out = []
    while unseen:
        seen = {unseen.pop()}
        stack = list(seen)
        while stack:
            for v in adj[stack.pop()] & unseen:
                unseen.remove(v)
                seen.add(v)
                stack.append(v)
        out.append(seen)
    return out


def faces(rotation):
    unused = {(u, v) for u, ns in rotation.items() for v in ns}
    out = []
    while unused:
        start = min(unused)
        u, v = start
        face = []
        while True:
            assert (u, v) in unused
            unused.remove((u, v))
            face.append(u)
            ns = rotation[v]
            u, v = v, ns[(ns.index(u) + 1) % len(ns)]
            if (u, v) == start:
                break
        assert len(set(face)) == len(face)
        out.append(tuple(face))
    return out


def check_graph(rotation):
    adj = {u: set(ns) for u, ns in rotation.items()}
    assert all(len(ns) == 3 and u not in ns for u, ns in adj.items())
    assert all(u in adj[v] for u, ns in adj.items() for v in ns)
    assert len(rotation) - len(edges(rotation)) + len(faces(rotation)) == 2
    for size in range(3):
        for cut in combinations(rotation, size):
            remaining = set(rotation) - set(cut)
            assert len(components({u: adj[u] & remaining for u in remaining})) == 1
    colour = {min(rotation): 0}
    stack = list(colour)
    while stack:
        u = stack.pop()
        for v in adj[u]:
            if v not in colour:
                colour[v] = 1 - colour[u]
                stack.append(v)
            assert colour[v] != colour[u]
    assert set(colour) == set(rotation)
    return colour


def site_face(rotation, site):
    u, v, x, y = site
    assert len(set(site)) == 4
    colour = check_graph(rotation)
    assert colour[u] == colour[x]
    for face in faces(rotation):
        for direction in (1, -1):
            cyc = face[::direction]
            if u not in cyc:
                continue
            i = cyc.index(u)
            cyc = cyc[i:] + cyc[:i]
            if cyc[1] != v or x not in cyc:
                continue
            j = cyc.index(x)
            if 2 <= j < len(cyc) - 1 and cyc[j + 1] == y:
                lengths = (j - 1, len(cyc) - j - 1)
                assert all(n > 0 and n % 2 for n in lengths)
                return cyc, lengths, direction
    raise AssertionError(("nonfacial site", site))


def expand(rotation, site, fresh):
    _, _, direction = site_face(rotation, site)
    u, v, x, y = site
    a, b, c, d = fresh
    assert len(set(fresh)) == 4 and not set(fresh) & set(rotation)
    out = {z: list(ns) for z, ns in rotation.items()}
    for z, old, new in ((u, v, a), (v, u, b), (x, y, c), (y, x, d)):
        out[z][out[z].index(old)] = new
    new_orders = {a: (b, u, d), b: (c, v, a), c: (x, b, d), d: (a, y, c)}
    out.update({z: list(ns[::direction]) for z, ns in new_orders.items()})
    out = {z: tuple(ns) for z, ns in out.items()}
    born = {edge(*p) for p in ((u, a), (a, b), (b, v), (x, c),
                               (c, d), (d, y), (a, d), (b, c))}
    cut = {edge(u, v), edge(x, y)}
    assert edges(out) == (edges(rotation) - cut) | born
    assert len(born) == 8 and not born & edges(rotation)
    check_graph(out)
    # Inverse on edges and rotations, including the two restored virtual seals.
    restored = {z: list(ns) for z, ns in out.items() if z not in fresh}
    for z, old, new in ((u, a, v), (v, b, u), (x, c, y), (y, d, x)):
        restored[z][restored[z].index(old)] = new
    assert {z: tuple(ns) for z, ns in restored.items()} == rotation
    return out, born


def cycle(*vs):
    return {edge(vs[i], vs[(i + 1) % len(vs)]) for i in range(len(vs))}


def row(verts, chosen, boundary, targets):
    adj = {v: set() for v in verts}
    for u, v in chosen:
        adj[u].add(v)
        adj[v].add(u)
    assert all(len(ns) <= 2 if v in boundary else len(ns) == 2
               for v, ns in adj.items())
    blocks, closed = [], 0
    for comp in components(adj):
        hit = tuple(i for i, v in enumerate(boundary) if v in comp)
        if hit:
            blocks.append(hit)
        else:
            closed += 1
    return (tuple(len(adj[v]) for v in boundary), tuple(sorted(blocks)),
            min(2, closed), *(int(t in chosen) for t in targets))


def nu_and_lengths(Z, H, site, q, targets, fresh):
    names = ("U", "V", "X", "Y", "Q0", "Q1", "E0", "E1", "F0", "F1",
             "A", "B", "C", "D")
    vals = (*site, *q, *targets[0], *targets[1], *fresh)
    ids = {}
    quotient = tuple(ids.setdefault(v, len(ids)) for v in vals)
    colours = check_graph(H)
    word = tuple(colours[v] for v in ids)
    word = min(word, tuple(1 - c for c in word))
    controlled = {edge(*site[:2]): "UV", edge(*site[2:]): "XY", edge(*q): "q"}
    loc = tuple((t == edge(*q), controlled.get(t, "external-existing"), "live",
                 tuple(v in Z for v in t)) for t in targets)
    face, lengths, _ = site_face(H, (site[0], fresh[0], *q))
    j = face.index(q[0])
    roles = {}
    for name, v in zip(names, vals):
        roles.setdefault(v, name)
    code = ("UA", tuple(roles[v] for v in face[1:j + 1] if v in roles), "SEP",
            tuple(roles[v] for v in face[j + 1:] if v in roles), "SEP")
    return (quotient, word, loc, code, tuple(v in Z for v in ids)), lengths


Q = {0: (1, 4, 3), 1: (0, 2, 5), 2: (1, 3, 6), 3: (2, 0, 7),
     4: (7, 0, 5), 5: (4, 1, 6), 6: (2, 7, 5), 7: (3, 4, 6)}
sites = ((0, 1, 2, 3), (4, 0, 3, 7), (0, 8, 9, 1), (0, 16, 11, 3))
graphs, births = [Q], []
for i, site in enumerate(sites):
    face, lengths, _ = site_face(graphs[-1], site)
    G, born = expand(graphs[-1], site, tuple(range(8 + 4 * i, 12 + 4 * i)))
    graphs.append(G)
    births.append(born)
    print("LEGAL_STEP", i, "site=", site, "face=", face, "arcs=", lengths)
Z, H = graphs[-2:]
targets = (edge(2, 6), edge(9, 10))
qs = ((19, 1), (5, 4))
fresh = (20, 21, 22, 23)
keys, boundaries = [], []
for q in qs:
    nu, lengths = nu_and_lengths(Z, H, sites[-1], q, targets, fresh)
    keys.append((nu, tuple(min(n, 3) for n in lengths)))
    boundaries.append((*sites[-1], *q, *targets[0], *targets[1]))
    cap = {edge(0, 20), edge(*q)}
    owners = [pool & edges(H) - cap for pool in [edges(Q), *births]] + [cap]
    assert set.union(*owners) == edges(H)
    assert sum(map(len, owners)) == len(edges(H))
    assert edge(*q) in edges(Z)
    # e and f have identical finite birth/status tags in the two histories.
    assert targets[0] in edges(Q) and targets[1] in births[0]
    print("SUCCESSOR", q, "arcs=", lengths, "capped=", keys[-1][1],
          "owner_counts=", tuple(map(len, owners)))
assert keys[0] == keys[1]
assert keys[0][0][0] == tuple(range(14))
assert keys[0][0][1] == (0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0)
assert keys[0][0][3] == ("UA", ("A", "B", "V", "Q0"), "SEP", ("Q1",), "SEP")
assert keys[0][1] == (3, 3)

# Sigma_plus is literally the same: the entire history through Z, old
# operation, target pair, and old successor roles are identical. No support
# enumeration or hash is needed to infer equality of a function on this input.
F = cycle(4, 5, 6, 7) | cycle(8, 9, 18, 17) | cycle(12, 13, 14, 15)
cuts = {edge(0, 16), edge(11, 3)}
assert F <= edges(Z) - cuts - {edge(*qs[0])}
expected = ((0, 0, 0, 0, 0, 0, 0, 2, 2, 0), tuple((i,) for i in range(10)), 1, 0, 0)
assert row(Z, F, boundaries[0], targets) == expected
print("ROW_WITNESS", sorted(F), "row=", expected)

# Structural absence: the four inserted vertices have even total F-degree.
# The row forbids three of their four outgoing edges; parity forbids the last.
gadget = {12, 13, 14, 15}
zero = {v for v, d in zip(boundaries[1], expected[0]) if d == 0}
assert {0, 3, 4} <= zero and not gadget & set(boundaries[1])
crossing = {e for e in edges(Z) if len(set(e) & gadget) == 1}
assert crossing == {edge(4, 12), edge(0, 13), edge(3, 14), edge(7, 15)}
assert {e for e in crossing if not set(e) & zero} == {edge(7, 15)}
assert set(Z[7]) == {4, 6, 15} and 7 not in boundaries[1]

# Independent exhaustive absence check using only required vertex degrees.
# Remove zero-degree incident edges, then check every remaining subset. This
# intentionally does not use the cut-parity argument or compressed row algebra.
required = {v: 2 for v in Z}
required.update(zip(boundaries[1], expected[0]))
available = sorted(e for e in edges(Z) - cuts - {edge(*qs[1])}
                   if all(required[v] for v in e))
assert len(available) <= 18  # memory is linear; at most 2^18 tiny subsets
degree_solutions = 0
for mask in range(1 << len(available)):
    degrees = dict.fromkeys(Z, 0)
    for i, (u, v) in enumerate(available):
        if mask >> i & 1:
            degrees[u] += 1
            degrees[v] += 1
    degree_solutions += degrees == required
assert degree_solutions == 0
print("DIRECT_ABSENCE", "candidate_edges=", len(available),
      "subsets=", 1 << len(available), "degree_solutions=", degree_solutions)
print("SHORT_ARC_REFINEMENT_COLLISION_VERIFIED")
