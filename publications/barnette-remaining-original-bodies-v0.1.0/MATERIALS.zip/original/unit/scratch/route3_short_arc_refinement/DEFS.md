# Route 3: short-arc refinement (frozen before computation, 2026-09-24)

The sole decision is whether the frozen fourteen-slot reattachment key becomes
complete after recording, for each ordered residual arc of the future
successor face, whether its length is one. Define

`nu_short = (nu, min(ell_0, 3), min(ell_1, 3))`.

Legal arc lengths are positive odd integers. The only permitted new atomic
fields are these two short-arc flags, with exactly four possible added states.
No field will be added in response to a failed example. This is a fixed finite
refinement of the finite alphabets of Notes 169/170; one flag alone already
distinguishes Note 170's (3,3) and (5,1). The two-flag refinement is tested
because a collision for it also defeats either single flag and any function
of the pair. The absolute bound on the added alphabet is four. A loose
absolute bound on the entire input key is 2^(2^1024): the fixed fourteen-role
metadata and individual rows each admit fewer than 2^512 encodings, and only
the row-support coordinate takes a powerset.

Try only the following directed modification, without a graph census:
after the original cube expansion, insert the legal expansion at (4,0,3,7),
then perform the two consecutive o* operations with the same old roles as
Note 170. The inserted square should lengthen the formerly unit arc and
preserve the zero-degree obstruction by the even-cut identity.

NO-GO requires the same literal old Sigma_plus, equal full nu_short, an
explicit next-row witness on one side, and a complete nonexistence argument
on the other, with executable checks of both real histories. GO would require
an all-domain reconstruction proof; merely separating the original pair is
insufficient. Do not infer anything about all finite enrichments or (T).

All exploration and executable checks stay here. A numbered note is permitted
only after the structural argument and independent direct check succeed.
