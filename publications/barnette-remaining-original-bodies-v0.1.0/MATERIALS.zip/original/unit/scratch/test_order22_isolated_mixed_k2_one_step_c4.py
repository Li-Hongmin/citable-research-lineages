#!/usr/bin/env python3
"""Test every one-face C4 expansion of the closest order-22 fibre.

The parent has one isolated mixed K2 exchange component and one further
mixed component.  The test asks whether one standard facial C4 expansion,
away from the three named interface edges, can preserve the legal-wide
root-square brace hypotheses while killing every crossing except the
isolated one.
"""

from __future__ import annotations

from collections import Counter
from functools import lru_cache
from itertools import combinations

import networkx as nx


GRAPH6 = "U?????????[?s?b?KO@Q?BO?Co?F??@o?QG?CE??"
ROOT = (1, 11)
FORCED = (0, 12)
SURVIVING = (9, 17)


def edge(first: int, second: int) -> tuple[int, int]:
    return (first, second) if first < second else (second, first)


def face_edges(face: tuple[int, ...]) -> tuple[tuple[int, int], ...]:
    return tuple(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def plane_faces(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    planar, embedding = nx.check_planarity(graph)
    assert planar
    visited: set[tuple[int, int]] = set()
    result = []
    for first, second in embedding.edges():
        if (first, second) in visited:
            continue
        result.append(tuple(embedding.traverse_face(first, second, visited)))
    return tuple(result)


def expand_on_face(
    graph: nx.Graph,
    face: tuple[int, ...],
    first_index: int,
    second_index: int,
) -> nx.Graph:
    result = graph.copy()
    u, v = face[first_index], face[(first_index + 1) % len(face)]
    x, y = face[second_index], face[(second_index + 1) % len(face)]
    result.remove_edges_from(((u, v), (x, y)))
    a, b, c, d = range(max(graph) + 1, max(graph) + 5)
    result.add_edges_from(
        ((u, a), (a, b), (b, v), (x, c), (c, d), (d, y), (a, d), (b, c))
    )
    return result


def enumerate_perfect_matchings(
    graph: nx.Graph,
) -> tuple[frozenset[tuple[int, int]], ...]:
    vertices = tuple(sorted(graph))
    position = {vertex: index for index, vertex in enumerate(vertices)}
    neighbours = tuple(
        sum(1 << position[other] for other in graph[vertex])
        for vertex in vertices
    )

    @lru_cache(maxsize=None)
    def recurse(mask: int):
        if not mask:
            return ((),)
        candidates = [
            index for index in range(len(vertices)) if mask & (1 << index)
        ]
        first = min(
            candidates,
            key=lambda index: (neighbours[index] & mask).bit_count(),
        )
        choices = neighbours[first] & mask
        result = []
        while choices:
            bit = choices & -choices
            choices ^= bit
            second = bit.bit_length() - 1
            for suffix in recurse(mask ^ (1 << first) ^ bit):
                result.append(((first, second),) + suffix)
        return tuple(result)

    return tuple(
        frozenset(edge(vertices[first], vertices[second]) for first, second in item)
        for item in recurse((1 << len(vertices)) - 1)
    )


def is_target(
    graph: nx.Graph,
    matching: frozenset[tuple[int, int]],
) -> bool:
    if edge(*ROOT) not in matching or edge(*FORCED) not in matching:
        return False
    complement = graph.copy()
    complement.remove_edges_from(matching)
    assert set(dict(complement.degree()).values()) == {2}
    components = tuple(nx.connected_components(complement))
    return (
        len(components) == 2
        and all(len(set(ROOT) & vertices) == 1 for vertices in components)
    )


def is_single_cycle(
    graph: nx.Graph,
    first: frozenset[tuple[int, int]],
    second: frozenset[tuple[int, int]],
) -> bool:
    difference = first ^ second
    if not difference:
        return False
    subgraph = nx.edge_subgraph(graph, difference)
    return nx.is_connected(subgraph) and set(dict(subgraph.degree()).values()) == {2}


def exchange_data(graph: nx.Graph, targets):
    exchange = nx.Graph()
    exchange.add_nodes_from(range(len(targets)))
    surviving = edge(*SURVIVING)
    crossings = []
    for first, second in combinations(range(len(targets)), 2):
        if not is_single_cycle(graph, targets[first], targets[second]):
            continue
        exchange.add_edge(first, second)
        if (surviving in targets[first]) != (surviving in targets[second]):
            crossings.append((first, second))
    return exchange, tuple(crossings)


def opposite_on_square(graph: nx.Graph) -> bool:
    root = edge(*ROOT)
    forced = edge(*FORCED)
    if set(root) & set(forced):
        return False
    u, v = root
    x, y = forced
    return any(
        all(graph.has_edge(cycle[index], cycle[(index + 1) % 4]) for index in range(4))
        for cycle in ((u, v, x, y), (u, v, y, x))
    )


def legal_wide(graph: nx.Graph):
    witnesses = []
    root = edge(*ROOT)
    forced = edge(*FORCED)
    surviving = edge(*SURVIVING)
    for face in plane_faces(graph):
        boundary = face_edges(face)
        if forced not in boundary or surviving not in boundary or root in boundary:
            continue
        delta = (boundary.index(surviving) - boundary.index(forced)) % len(boundary)
        arcs = (delta + 1, len(boundary) - delta + 1)
        if min(arcs) >= 5 and all(value % 2 for value in arcs):
            witnesses.append((face, arcs))
    return tuple(witnesses)


def two_extendable(graph: nx.Graph, perfect_matchings) -> bool:
    graph_edges = tuple(sorted(edge(*item) for item in graph.edges()))
    covered = {
        frozenset((first, second))
        for matching in perfect_matchings
        for first, second in combinations(sorted(matching), 2)
    }
    return all(
        frozenset((first, second)) in covered
        for first, second in combinations(graph_edges, 2)
        if set(first).isdisjoint(second)
    )


def main() -> None:
    parent = nx.from_graph6_bytes(GRAPH6.encode())
    parent_matchings = enumerate_perfect_matchings(parent)
    parent_targets = tuple(
        matching for matching in parent_matchings if is_target(parent, matching)
    )
    parent_exchange, parent_crossings = exchange_data(parent, parent_targets)
    parent_components = tuple(
        sorted(component) for component in nx.connected_components(parent_exchange)
    )
    assert len(parent_targets) == 8
    assert len(parent_crossings) == 3
    assert sorted(map(len, parent_components)) == [2, 6]
    assert any(
        len(component) == 2
        and parent_exchange.subgraph(component).number_of_edges() == 1
        for component in parent_components
    )

    interface = {edge(*ROOT), edge(*FORCED), edge(*SURVIVING)}
    records = []
    witnesses = []
    seen = set()
    for face_index, face in enumerate(plane_faces(parent)):
        boundary = face_edges(face)
        for first_index, second_index in combinations(range(len(face)), 2):
            selected = {boundary[first_index], boundary[second_index]}
            if selected & interface:
                continue
            if set(boundary[first_index]) & set(boundary[second_index]):
                continue
            child = expand_on_face(parent, face, first_index, second_index)
            labelled_graph6 = nx.to_graph6_bytes(
                child, header=False
            ).decode().strip()
            if labelled_graph6 in seen:
                continue
            seen.add(labelled_graph6)
            if not opposite_on_square(child):
                continue
            wide = legal_wide(child)
            if not wide:
                continue
            if not (
                nx.number_of_selfloops(child) == 0
                and nx.is_connected(child)
                and nx.is_bipartite(child)
                and set(dict(child.degree()).values()) == {3}
                and nx.check_planarity(child)[0]
                and nx.node_connectivity(child) == 3
            ):
                continue
            perfect_matchings = enumerate_perfect_matchings(child)
            if not two_extendable(child, perfect_matchings):
                continue
            targets = tuple(
                matching
                for matching in perfect_matchings
                if is_target(child, matching)
            )
            exchange, crossings = exchange_data(child, targets)
            record = {
                "face_index": face_index,
                "selected_edges": tuple(sorted(selected)),
                "perfect_matchings": len(perfect_matchings),
                "targets": len(targets),
                "exchange_edges": exchange.number_of_edges(),
                "exchange_components": tuple(
                    sorted(map(len, nx.connected_components(exchange)))
                ),
                "crossings": len(crossings),
                "wide": wide,
                "graph6": labelled_graph6,
            }
            records.append(record)
            if len(crossings) == 1:
                witnesses.append((record, child, targets, exchange, crossings))

    print(f"parent_perfect_matchings={len(parent_matchings)}")
    print(
        "parent_targets=8 parent_exchange_components="
        f"{sorted(map(len, parent_components))} parent_crossings=3"
    )
    print(f"legal_one_step_children={len(records)}")
    print(
        "crossing_histogram",
        dict(sorted(Counter(record["crossings"] for record in records).items())),
    )
    print(
        "component_histogram",
        dict(
            sorted(
                Counter(record["exchange_components"] for record in records).items()
            )
        ),
    )
    print(f"one_crossing_children={len(witnesses)}")
    if witnesses:
        record, child, targets, exchange, crossings = witnesses[0]
        print("FIRST_ONE_CROSSING_RECORD", record)
        print("edges", sorted(edge(*item) for item in child.edges()))
        print("targets", [sorted(item) for item in targets])
        print("exchange_edges", sorted(exchange.edges()))
        print("crossings", crossings)
        print("ORDER22_ISOLATED_K2_ONE_STEP_COUNTEREXAMPLE_FOUND")
    else:
        print("ORDER22_ISOLATED_K2_ONE_STEP_COUNTEREXAMPLE_NOT_FOUND")


if __name__ == "__main__":
    main()
