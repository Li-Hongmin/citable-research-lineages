# Frozen definitions for Route 1, pulse 4

**FROZEN BEFORE COMPUTATION: 2026-09-13.**  This finite work package is
exactly the certified history cube -> `G1` -> `o*` at
`s1=(0,3,11,8)` with retained edge `(7,4)`, followed by the site
`s2=(0,12,7,4)`, targets `e={1,5}`, `f={2,6}`, and every retained edge `q`
for which the next `o*` successor is legal.  No field below may be changed in
this pulse.  The frozen SPEC, R1, Notes 167 and 169 are untouched.

## Exact slots and role transport

There are **fourteen**, not sixteen, ordered slots:

```
(U,V,X,Y,Q0,Q1,E0,E1,F0,F1,A,B,C,D).
```

Their values for `(Z,q)` are `(0,12,7,4,q0,q1,1,5,2,6,16,17,18,19)`.
`A,B,C,D` are the four vertices not yet born in the expansion at `s2`.
Class ids are assigned by first occurrence in this displayed tuple.

The old pulse-2 successor roles for the operation at `s1` transport as

```
old u -> U, old a -> V, old r0 -> X, old r1 -> Y,
old e0,e1 -> E0,E1, old f0,f1 -> F0,F1.
```

The old roles `v,x,y,b,c,d` have no structural role in the next input (they
remain ordinary graph vertices unless also a target/q endpoint).  New `Q0,Q1`
name the ordered retained edge; new `A,B,C,D` are fresh roles.  No role is
silently added.

## Canonical nu

`canonical_nu.py` encodes exactly:

1. the first-occurrence equality partition of the fourteen slots;
2. one bipartition bit per quotient class, normalized by taking the
   lexicographically smaller of the colour word and its global complement;
3. for each target, whether its unoriented edge equals `q`, plus its frozen
   finite location (`UV`, `XY`, `q`, or `external-existing`) and live status;
4. the marked-role word on the unique post-expansion face witnessing the
   successor `(U,A,Q0,Q1)`, with all unmarked vertices deleted.  The word is
   rotated to begin with `(U,A)` and the lexicographically smaller of the two
   simultaneous mirror/orientation descriptions is used.  Two separators
   mark the residual arc from `A` to `Q0` and from `Q1` to `U`.  This is a
   finite role word, not an arc length;
5. endpoint-existence bits and the finite live/future status for `e,f`.

It contains no graph number, absolute history depth, unbounded arc length,
unmarked face data, exterior generator/row, recomputed support, or hash.

## Independent complete summaries

`sigma_next.py` directly enumerates subgraphs of the relevant graph after
deleting the three controlled edges.  Every non-boundary vertex has degree
exactly two and every boundary vertex degree at most two.  A canonical row is

```
(ordered boundary quotient roles, degree word, component partition,
 capped number of closed components, e-use bit, f-use bit).
```

The component partition and rows are sorted literally.  `Sigma_plus(Z)` is
independently regenerated from `Z-{0,12}-{7,4}` using the transported old
successor roles and its complete metadata.  `Sigma_next(Z,q)` is independently
regenerated from `Z-{0,12}-{7,4}-q` using all fourteen next roles and its
complete metadata.  Neither computation uses pulse-2 row algebra as an
authority.  Hashes may index objects, but equality is always metadata-field
and sorted-row equality.

## Certificates and stopping rule

A real-history certificate lists every graph edge at each step, each ordered
site/retained edge, fresh vertices, direct cubic/bipartite/planar/3-connected
checks, and direct cofacial legality.  A difference-row certificate records
the complete canonical row, the side on which it occurs, an explicit realizing
edge subset there, and exhaustive nonexistence on the other side.

NOGO requires two legal `q` values with equal canonical `nu` (and the common
literal `Sigma_plus`) but unequal `Sigma_next`, plus such an existence/
nonexistence certificate.  GO requires a concrete `U` and proofs covering all
real inputs in `D_next`; finite-package agreement is not GO.  Otherwise the
verdict is UNDETERMINED.  For `q=e`, the separately regenerated old
`Sigma_plus` is also checked against the normalized restricted-support
identity; that regression is not GO.
