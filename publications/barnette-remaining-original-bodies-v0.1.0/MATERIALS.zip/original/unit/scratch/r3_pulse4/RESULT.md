# Route 1 pulse 4 result

## Verdict: UNDETERMINED

The frozen real-domain scan has one legal retained-edge choice, `q=(15,8)`.
Consequently it has one canonical `nu` bucket of size one.  Its independently
computed complete `Sigma_next` has 5,121 rows from 5,632 realizing subgraphs.
There is no pair to compare inside a bucket and no collision certificate.
This finite result supplies neither a global reconstruction function `U` nor
a proof covering all real `D_next`, so it is not GO.

Literal figures (full objects, not hashes, were compared):

```
Sigma_plus: 1,579 rows / 1,984 realizers
legal q: 1
nu buckets: 1
bucket sizes: [1]
conflict buckets: 0
```

The complete machine-readable history, edge tables, graph-property checks,
per-q counts, hashes used only as display summaries, and empty collision list
are in `scan.json`.  The scan compared tuple metadata field-by-field and the
sorted complete row sequences; it did not decide equality by hash.

## Frozen-package domain discrepancy

Direct cofacial legality in the stated fixed graph gives only `(15,8)` as an
oriented old edge for which `(0,16,q0,q1)` is a legal successor after expanding
`s2`.  Neither target edge `{1,5}` nor `{2,6}` is such a choice.  Thus the
request that the same real legal-q package include `q=e` and `q=f` is
incompatible with the fixed history/site/targets.  They were not inserted as
formal bad states and were not used as collision evidence.

The mandated `q=e={1,5}` regression was nevertheless computed separately,
outside `D_next`, with the frozen canonical encoder (which reports the finite
`NOT-LEGAL-SUCCESSOR` face tag).  `Sigma_plus` was genuinely regenerated,
not inherited and not paired with `nu_stub`.  After filtering its rows by
`beta_e=0`, renaming actual boundary classes to the next fourteen-slot order,
and canonicalizing, all 987 rows equal the 987 rows of the direct
`Z-{0,12}-{7,4}-e` calculation.  This is the requested restricted-support
identity, only as a regression and not as P3 GO.

No Note 170 was created and Route 3 remains closed.  Notes 167/169, R1, and
the frozen SPEC were not modified.
