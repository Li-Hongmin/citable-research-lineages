#!/usr/bin/env python3
"""Exhaust the frozen q package and compare canonical nu buckets literally."""

from collections import defaultdict
from pathlib import Path
import hashlib, json
import networkx as nx

from canonical_nu import canonical_nu
from sigma_next import (SLOTS, certified_context, edge, expand, legal_sites,
                        quotient, sigma_next, sigma_plus)

HERE=Path(__file__).resolve().parent
E=edge(1,5); F=edge(2,6); S2=(0,12,7,4)

def digest(x): return hashlib.sha256(repr(x).encode()).hexdigest()

def legal_qs(Z):
    H,born=expand(Z,S2); assert born==(16,17,18,19)
    cut={edge(0,12),edge(7,4)}; ans=[]
    legal=legal_sites(H)
    for a,b in Z.edges():
        if edge(a,b) in cut: continue
        for q in ((a,b),(b,a)):
            if (0,16,q[0],q[1]) in legal: ans.append(q)
    return sorted(set(ans))

def graph_checks(G):
    return {"vertices":len(G),"edges":len(G.edges()),"simple":not nx.number_of_selfloops(G),
            "cubic":all(d==3 for _,d in G.degree()),"bipartite":nx.is_bipartite(G),
            "planar":nx.check_planarity(G)[0],"connectivity":nx.node_connectivity(G)}

def normalized_old_restriction(old_summary, q):
    """Rename old R+ rows with beta_e=0 into next fourteen-slot roles."""
    _,rows=old_summary
    old_names=("u","v","x","y","r0","r1","e0","e1","f0","f1","a","b","c","d")
    old_vals=(0,3,11,8,7,4,1,5,2,6,12,13,14,15)
    new_vals=(0,12,7,4,q[0],q[1],1,5,2,6,16,17,18,19)
    new_cls=quotient(new_vals); first={}
    for n,k,v in zip(SLOTS,new_cls,new_vals): first.setdefault(k,(n,v))
    vertex_to_rep={v:n for n,v in first.values()}
    old_value=dict(zip(old_names,old_vals))
    out=[]
    for row in rows:
        boundary,d,pi,z,be,bf=row
        if be: continue
        degree={vertex_to_rep[old_value[n]]:x for n,x in zip(boundary,d)}
        nb=tuple(n for n,v in first.values() if n in degree)
        blocks=[]
        for block in pi:
            mapped=tuple(sorted({vertex_to_rep[old_value[n]] for n in block},key=nb.index))
            if mapped: blocks.append(mapped)
        out.append((nb,tuple(degree[n] for n in nb),tuple(sorted(blocks)),z,0,bf))
    return tuple(sorted(set(out)))

def main():
    Q,G1,Z=certified_context()
    assert S2 in legal_sites(Z)
    qs=legal_qs(Z); assert qs
    old,old_realizers,old_count=sigma_plus(Z,E,F)
    # Regenerate it a second time, rather than accepting an inherited/stub key.
    old2,_,_=sigma_plus(Z,E,F); assert old==old2
    records=[]
    for q in qs:
        nu=canonical_nu(Z,q,E,F)
        sig,realizers,count=sigma_next(Z,q,E,F)
        records.append({"q":q,"nu":nu,"sigma":sig,"realizers":realizers,"count":count})
    buckets=defaultdict(list)
    for r in records: buckets[r["nu"]].append(r)
    conflicts=[]
    for nu,rs in buckets.items():
        for i in range(len(rs)):
            for j in range(i+1,len(rs)):
                if rs[i]["sigma"] != rs[j]["sigma"]:
                    rows1=set(rs[i]["sigma"][1]); rows2=set(rs[j]["sigma"][1])
                    row=next(iter(rows1^rows2)); present=rs[i] if row in rows1 else rs[j]; absent=rs[j] if row in rows1 else rs[i]
                    assert row in present["realizers"] and row not in absent["realizers"]
                    conflicts.append({"q_present":present["q"],"q_absent":absent["q"],"row":row,
                                      "realizer":present["realizers"][row],"absent_exhaustive_realizers":absent["count"]})
    qe_q=E
    qe_nu=canonical_nu(Z,qe_q,E,F)
    qe_sig,_,qe_count=sigma_next(Z,qe_q,E,F)
    restricted=normalized_old_restriction(old,qe_q)
    assert restricted==qe_sig[1]
    history={"Q":graph_checks(Q),"G1":graph_checks(G1),"Z":graph_checks(Z),
             "edges":{"Q":sorted(map(lambda x:edge(*x),Q.edges())),"G1":sorted(map(lambda x:edge(*x),G1.edges())),"Z":sorted(map(lambda x:edge(*x),Z.edges()))},
             "steps":[{"site":(0,1,2,3),"fresh":(8,9,10,11)},
                      {"site":(0,3,11,8),"retained":(7,4),"fresh":(12,13,14,15),"successor":S2}],
             "all_q_successors":[(q,(0,16,q[0],q[1])) for q in qs]}
    report={"history":history,"sigma_plus_rows":len(old[1]),"sigma_plus_realizers":old_count,
            "sigma_plus_sha256":digest(old),"legal_q_count":len(qs),
            "bucket_count":len(buckets),"bucket_sizes":sorted(len(v) for v in buckets.values()),
            "q_rows":[{"q":r["q"],"nu_sha256":digest(r["nu"]),"rows":len(r["sigma"][1]),"realizers":r["count"],"sigma_sha256":digest(r["sigma"])} for r in records],
            "domain_warning":{"e_is_legal_retained":any(edge(*q)==E for q in qs),
                              "f_is_legal_retained":any(edge(*q)==F for q in qs),
                              "meaning":"q=e and q=f are not real D_next members in this fixed context"},
            "conflicts":conflicts,"q_equals_e_restricted_identity":{"q":qe_q,
              "canonical_nu":repr(qe_nu),"in_D_next":False,"direct_realizers":qe_count,
              "old_beta_e_zero_rows":len(restricted),"next_rows":len(qe_sig[1]),"verified":True}}
    (HERE/"scan.json").write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
    print(f"LEGAL_Q={len(qs)} BUCKETS={len(buckets)} SIZES={report['bucket_sizes']}")
    for x in report["q_rows"]: print("Q",x)
    print("CONFLICTS",len(conflicts))
    print("Q_EQUALS_E_RESTRICTED_IDENTITY rows",len(restricted),"VERIFIED")
    print("R3_PULSE4_SCAN_COMPLETE")

if __name__=="__main__": main()
