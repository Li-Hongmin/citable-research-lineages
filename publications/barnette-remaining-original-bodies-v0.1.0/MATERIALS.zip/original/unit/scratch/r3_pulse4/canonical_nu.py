#!/usr/bin/env python3
"""Frozen canonical nu encoder; it never computes a row support."""

import networkx as nx
from sigma_next import SLOTS, edge, expand, faces, quotient

def _rot_to_edge(face,a,b):
    n=len(face)
    for i in range(n):
        if face[i]==a and face[(i+1)%n]==b: return face[i:]+face[:i]
    return None

def canonical_nu(Z,q,e,f):
    vals=(0,12,7,4,q[0],q[1],e[0],e[1],f[0],f[1],16,17,18,19)
    cls=quotient(vals); col=nx.bipartite.color(Z)
    class_vals=[]
    for k in range(max(cls)+1): class_vals.append(vals[cls.index(k)])
    cw=tuple(col.get(v,0) for v in class_vals)
    cw=min(cw,tuple(1-x for x in cw))
    loc=[]
    controlled={edge(0,12):"UV",edge(7,4):"XY",edge(*q):"q"}
    for t in (e,f): loc.append((edge(*t)==edge(*q),controlled.get(edge(*t),"external-existing"),"live",(t[0] in Z,t[1] in Z)))
    H,born=expand(Z,(0,12,7,4)); assert born==(16,17,18,19)
    candidates=[]
    role_by_vertex={}
    for n,v in zip(SLOTS,vals): role_by_vertex.setdefault(v,n)
    for face in faces(H):
        for oriented in (face,tuple(reversed(face))):
            r=_rot_to_edge(oriented,0,16)
            if r is None: continue
            n=len(r)
            for j in range(2,n):
                if r[j]==q[0] and r[(j+1)%n]==q[1]:
                    arc0=tuple(role_by_vertex[v] for v in r[1:j+1] if v in role_by_vertex)
                    arc1=tuple(role_by_vertex[v] for v in r[j+1:] if v in role_by_vertex)
                    candidates.append(("UA",arc0,"SEP",arc1,"SEP"))
    # The tagged value is useful for the mandatory q=e regression, but such a
    # value is never admitted to the real D_next bucket scan.
    face_code=min(candidates) if candidates else ("NOT-LEGAL-SUCCESSOR",)
    return (cls,cw,tuple(loc),face_code,tuple(x[3] for x in loc))
