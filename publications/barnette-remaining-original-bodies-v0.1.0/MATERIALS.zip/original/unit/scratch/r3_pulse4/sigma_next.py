#!/usr/bin/env python3
"""Independent direct graph calculators for pulse 4 complete summaries."""

from itertools import combinations
import networkx as nx

SLOTS = ("U","V","X","Y","Q0","Q1","E0","E1","F0","F1","A","B","C","D")

def edge(a,b): return tuple(sorted((a,b)))

def cube():
    return nx.Graph([(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7)])

def expand(G, site):
    u,v,x,y=site; H=G.copy(); H.remove_edges_from((edge(u,v),edge(x,y)))
    a,b,c,d=range(max(H)+1,max(H)+5)
    H.add_edges_from(((u,a),(a,b),(b,v),(x,c),(c,d),(d,y),(a,d),(b,c)))
    return H,(a,b,c,d)

def faces(G):
    ok,emb=nx.check_planarity(G); assert ok
    seen=set(); out=[]
    for a,b in emb.edges():
        if (a,b) not in seen: out.append(tuple(emb.traverse_face(a,b,seen)))
    return out

def legal_sites(G):
    col=nx.bipartite.color(G); ans=set()
    for face in faces(G):
        for cyc in (face,tuple(reversed(face))):
            es=[(cyc[i],cyc[(i+1)%len(cyc)]) for i in range(len(cyc))]
            for i,j in combinations(range(len(es)),2):
                for p,q in ((i,j),(j,i)):
                    u,v=es[p]; x,y=es[q]
                    if len({u,v,x,y})==4 and col[u]==col[x]: ans.add((u,v,x,y))
    return ans

def certified_context():
    Q=cube(); G1,b1=expand(Q,(0,1,2,3)); assert b1==(8,9,10,11)
    Z,b2=expand(G1,(0,3,11,8)); assert b2==(12,13,14,15)
    return Q,G1,Z

def quotient(values):
    ids={}; cls=[]
    for v in values: cls.append(ids.setdefault(v,len(ids)))
    return tuple(cls)

def boundary_reps(slot_names, values, active):
    cls=quotient(values); first={}
    for n,k,v in zip(slot_names,cls,values): first.setdefault(k,(n,v))
    out=[]
    for n in active:
        i=slot_names.index(n); rep=first[cls[i]]
        if rep not in out: out.append(rep)
    return tuple(out),cls

def enumerate_support(G, cut_edges, slot_names, values, active, e, f):
    X=G.copy(); X.remove_edges_from([edge(*z) for z in cut_edges])
    boundary,cls=boundary_reps(slot_names,values,active)
    bverts={v for _,v in boundary}; es=sorted(edge(*z) for z in X.edges())
    inc={v:[] for v in X}
    for i,(a,b) in enumerate(es): inc[a].append(i); inc[b].append(i)
    deg={v:0 for v in X}; picked=[]; rows={}; realizers=0
    def emit():
        nonlocal realizers
        realizers += 1
        W=nx.Graph(); W.add_nodes_from(X); W.add_edges_from(picked)
        blocks=[]; closed=0
        for comp in nx.connected_components(W):
            hit=tuple(n for n,v in boundary if v in comp)
            if hit: blocks.append(hit)
            else: closed+=1
        row=(tuple(n for n,_ in boundary),tuple(deg[v] for _,v in boundary),
             tuple(sorted(blocks)),min(2,closed),int(edge(*e) in picked),int(edge(*f) in picked))
        rows.setdefault(row,tuple(picked))
    def rec(i):
        if i==len(es):
            if all(deg[v]==2 or (v in bverts and deg[v]<=2) for v in X): emit()
            return
        a,b=es[i]
        if all(not (inc[v][-1]==i and v not in bverts and deg[v]!=2) for v in (a,b)): rec(i+1)
        if deg[a]<2 and deg[b]<2:
            deg[a]+=1; deg[b]+=1; picked.append(es[i]); rec(i+1)
            picked.pop(); deg[a]-=1; deg[b]-=1
    rec(0)
    meta=(slot_names,cls,tuple(v in G for v in dict.fromkeys(values)),tuple(active),tuple(sorted(edge(*z) for z in cut_edges)),edge(*e),edge(*f))
    return (meta,tuple(sorted(rows))),rows,realizers

def sigma_plus(Z,e,f):
    # Literal old successor roles after s1/o*: u,a,r0,r1,e,f plus all old slots.
    names=("u","v","x","y","r0","r1","e0","e1","f0","f1","a","b","c","d")
    vals=(0,3,11,8,7,4,e[0],e[1],f[0],f[1],12,13,14,15)
    active=("u","a","r0","r1","e0","e1","f0","f1")
    return enumerate_support(Z,((0,12),(7,4)),names,vals,active,e,f)

def sigma_next(Z,q,e,f):
    vals=(0,12,7,4,q[0],q[1],e[0],e[1],f[0],f[1],16,17,18,19)
    active=SLOTS[:10]
    return enumerate_support(Z,((0,12),(7,4),q),SLOTS,vals,active,e,f)
