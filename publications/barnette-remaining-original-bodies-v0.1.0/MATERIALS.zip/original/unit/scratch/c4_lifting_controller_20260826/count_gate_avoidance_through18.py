#!/usr/bin/env python3
"""Count whether each Note 066 interface has a target using at most one gate."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import sys
from collections import Counter
from itertools import product

import networkx as nx


HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
DRIVER_PATH = (
    UNIT
    / "computations/bundles/locked-boundary-escape-through18"
    / "census_locked_escape_through18.py"
)


def load_driver():
    spec = importlib.util.spec_from_file_location("locked_escape_driver", DRIVER_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main(source_path: str) -> None:
    driver = load_driver()
    source = json.loads(Path(source_path).read_text())
    totals = {
        "interfaces": 0,
        "interfaces_with_at_most_one_gate_target": 0,
        "interfaces_all_targets_use_both_gates": 0,
        "target_instances_gate_count_0": 0,
        "target_instances_gate_count_1": 0,
        "target_instances_gate_count_2": 0,
    }
    failures = []
    all_both_family_sizes: Counter[int] = Counter()
    all_both_interface_success_types: Counter[str] = Counter()
    all_both_target_arc_types: Counter[str] = Counter()
    target_signature_liftability: Counter[str] = Counter()
    target_signature_success_rows: Counter[str] = Counter()

    for record in source["braces"]:
        primal = nx.from_graph6_bytes(record["graph6"].encode())
        reduced, rotations = driver.dual_from_primal_faces(primal, record["faces"])
        faces = driver.verify_reduced_triangulation(reduced)
        families, _, _ = driver.target_families(reduced, faces)
        vertices = tuple(sorted(reduced))

        for z in sorted(reduced):
            rotation = rotations[z]
            for i, j, gate_left, gate_right in driver.gate_pairs(rotation):
                left_size = j - i + 1
                right_size = len(rotation) - (j - i) + 1
                if left_size % 2 == 0 or right_size % 2 == 0:
                    continue
                expanded, locals_, left_arc, right_arc = driver.split_vertex(
                    reduced, z, rotation, i, j
                )
                expanded_faces = driver.expanded_triangulation_faces(expanded)
                if expanded_faces is None:
                    continue

                roots = sorted(
                    root
                    for root in (driver.edge(*item) for item in reduced.edges())
                    if z not in root and root in families
                )
                for root in roots:
                    totals["interfaces"] += 1
                    best = 3
                    for encoded in families[root]:
                        colour = driver.decode_colouring(vertices, encoded)
                        gate_count = int(colour[gate_left] == colour[z]) + int(
                            colour[gate_right] == colour[z]
                        )
                        totals[f"target_instances_gate_count_{gate_count}"] += 1
                        best = min(best, gate_count)
                        normalized = {
                            vertex: value ^ colour[z] for vertex, value in colour.items()
                        }
                        left_alt = all(
                            normalized[left_arc[k]] != normalized[left_arc[k + 1]]
                            for k in range(len(left_arc) - 1)
                        )
                        right_alt = all(
                            normalized[right_arc[k]] != normalized[right_arc[k + 1]]
                            for k in range(len(right_arc) - 1)
                        )
                        fixed = {
                            vertex: value for vertex, value in colour.items() if vertex != z
                        }
                        rows = set()
                        for bits in product((0, 1), repeat=3):
                            lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
                            if driver.is_target_profile(
                                driver.rooted_profile(expanded, expanded_faces, lifted, root)
                            ):
                                relative = tuple(bit ^ colour[z] for bit in bits)
                                rows.add("".join(map(str, relative)))
                        signature = f"gates={gate_count};arcs={int(left_alt)}{int(right_alt)}"
                        target_signature_liftability[
                            f"{signature};liftable={int(bool(rows))}"
                        ] += 1
                        for row in rows:
                            target_signature_success_rows[f"{signature};row={row}"] += 1
                    if best <= 1:
                        totals["interfaces_with_at_most_one_gate_target"] += 1
                    else:
                        totals["interfaces_all_targets_use_both_gates"] += 1
                        all_both_family_sizes[len(families[root])] += 1
                        success_types = set()
                        for encoded in families[root]:
                            colour = driver.decode_colouring(vertices, encoded)
                            normalized = {
                                vertex: value ^ colour[z] for vertex, value in colour.items()
                            }
                            left_alt = all(
                                normalized[left_arc[k]] != normalized[left_arc[k + 1]]
                                for k in range(len(left_arc) - 1)
                            )
                            right_alt = all(
                                normalized[right_arc[k]] != normalized[right_arc[k + 1]]
                                for k in range(len(right_arc) - 1)
                            )
                            all_both_target_arc_types[f"{int(left_alt)}{int(right_alt)}"] += 1
                            fixed = {
                                vertex: value for vertex, value in colour.items() if vertex != z
                            }
                            for bits in product((0, 1), repeat=3):
                                lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
                                if driver.is_target_profile(
                                    driver.rooted_profile(
                                        expanded, expanded_faces, lifted, root
                                    )
                                ):
                                    relative = tuple(bit ^ colour[z] for bit in bits)
                                    success_types.add(
                                        f"arcs={int(left_alt)}{int(right_alt)};row={''.join(map(str, relative))}"
                                    )
                        assert success_types
                        all_both_interface_success_types["|".join(sorted(success_types))] += 1
                        failures.append(
                            {
                                "graph6": record["graph6"],
                                "z": z,
                                "gate_indices": [i, j],
                                "gates": [gate_left, gate_right],
                                "root": root,
                                "family_size": len(families[root]),
                            }
                        )

    assert totals["interfaces"] == 2690
    print(json.dumps(totals, sort_keys=True))
    print(json.dumps({"all_both_family_sizes": all_both_family_sizes}, sort_keys=True))
    print(json.dumps({"all_both_target_arc_types": all_both_target_arc_types}, sort_keys=True))
    print(
        json.dumps(
            {"target_signature_liftability": target_signature_liftability},
            sort_keys=True,
        )
    )
    print(
        json.dumps(
            {"target_signature_success_rows": target_signature_success_rows},
            sort_keys=True,
        )
    )
    print(
        json.dumps(
            {"all_both_interface_success_types": all_both_interface_success_types},
            sort_keys=True,
        )
    )
    print(json.dumps({"first_all_both_gate_interface": failures[:1]}, sort_keys=True))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: count_gate_avoidance_through18.py SOURCE_JSON")
    main(sys.argv[1])
