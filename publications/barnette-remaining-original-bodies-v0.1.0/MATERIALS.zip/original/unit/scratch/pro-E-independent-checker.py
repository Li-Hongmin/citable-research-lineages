"""Independent, standard-library verification of the single Pro E instance.

Run: python3 scratch/pro-E-independent-checker.py
Only stdout is written; redirect it to a new scratch JSON path if desired.
All enumeration is on the specified 20-vertex parent, with streaming recursion.
"""

from collections import Counter, deque
from itertools import combinations
import json


def edge(a, b):
    return tuple(sorted((a, b)))


def walk_edges(walk, closed=False):
    pairs = zip(walk, walk[1:] + (walk[:1] if closed else []))
    return {edge(a, b) for a, b in pairs}


def adjacency(vertices, edges):
    adj = {v: set() for v in vertices}
    for a, b in edges:
        adj[a].add(b)
        adj[b].add(a)
    return adj


def components(vertices, edges):
    adj = adjacency(vertices, edges)
    left = set(vertices)
    result = []
    while left:
        start = min(left)
        found, todo = {start}, [start]
        while todo:
            for nxt in adj[todo.pop()] - found:
                found.add(nxt)
                todo.append(nxt)
        left -= found
        result.append(sorted(found))
    return result


def ordered_component(comp, edges):
    adj = adjacency(comp, {g for g in edges if set(g) <= set(comp)})
    ends = sorted(v for v in comp if len(adj[v]) == 1)
    assert all(len(adj[v]) in (1, 2) for v in comp)
    assert len(ends) in (0, 2)
    result = [ends[0] if ends else min(comp)]
    prev = None
    while True:
        opts = sorted(adj[result[-1]] - ({prev} if prev is not None else set()))
        if not opts or opts[0] == result[0]:
            break
        prev, nxt = result[-1], opts[0]
        assert nxt not in result
        result.append(nxt)
    assert set(result) == set(comp)
    return {"kind": "path" if ends else "cycle", "vertices": result}


def factor(vertices, edges):
    return [ordered_component(c, edges) for c in components(vertices, edges)]


def check_graph(vertices, edges, faces):
    adj = adjacency(vertices, edges)
    assert all(a != b for a, b in edges)
    assert all(len(adj[v]) == 3 for v in vertices)
    colour = {min(vertices): 0}
    todo = deque(colour)
    while todo:
        v = todo.popleft()
        for w in sorted(adj[v]):
            if w not in colour:
                colour[w] = 1 - colour[v]
                todo.append(w)
            assert colour[w] != colour[v]
    assert set(colour) == set(vertices)
    darts = Counter()
    rotation = {v: {} for v in vertices}
    for face in faces:
        assert len(face) == len(set(face)) and len(face) >= 4
        assert len(face) % 2 == 0
        for i, v in enumerate(face):
            prev, nxt = face[i - 1], face[(i + 1) % len(face)]
            assert edge(v, nxt) in edges
            darts[v, nxt] += 1
            assert prev not in rotation[v]
            rotation[v][prev] = nxt
    assert darts == Counter({(a, b): 1 for g in edges for a, b in (g, g[::-1])})
    for v in vertices:
        assert set(rotation[v]) == adj[v] == set(rotation[v].values())
        start = min(adj[v])
        cyclic = [start]
        while rotation[v][cyclic[-1]] != start:
            cyclic.append(rotation[v][cyclic[-1]])
            assert len(cyclic) <= 3
        assert set(cyclic) == adj[v]
    assert len(vertices) - len(edges) + len(faces) == 2
    deletion_checks = 0
    for k in range(3):
        for removed in combinations(sorted(vertices), k):
            surviving = vertices - set(removed)
            kept = {g for g in edges if set(g) <= surviving}
            assert len(components(surviving, kept)) == 1
            deletion_checks += 1
    return {"n": len(vertices), "m": len(edges), "faces": faces,
            "bipartition": [[v for v in sorted(vertices) if colour[v] == i]
                            for i in range(2)],
            "vertex_deletion_checks": deletion_checks}


def cyclic_equal(first, second):
    return len(first) == len(second) and any(
        first[i:] + first[:i] == second for i in range(len(first)))


def expand(vertices, edges, faces, site, carrier):
    u, v, x, y = site
    assert len(set(site)) == 4
    p, q = edge(u, v), edge(x, y)
    assert {p, q} <= edges
    hits = [i for i, face in enumerate(faces)
            if cyclic_equal(face, carrier) or cyclic_equal(face[::-1], carrier)]
    assert len(hits) == 1
    fi = hits[0]
    if not cyclic_equal(faces[fi], carrier):
        faces = [face[::-1] for face in faces]
    start = carrier.index(u)
    ordered = carrier[start:] + carrier[:start]
    assert ordered[1] == v
    xi = ordered.index(x)
    assert ordered[xi + 1] == y and xi % 2 == 0
    a, b, c, d = range(max(vertices) + 1, max(vertices) + 5)
    new_edges = {edge(*g) for g in [(u, a), (a, b), (b, v), (x, c),
                                  (c, d), (d, y), (a, d), (b, c)]}
    out_edges = (edges - {p, q}) | new_edges
    assert len(out_edges) == len(edges) + 6
    out_faces = []
    for i, face in enumerate(faces):
        subdivided = []
        for j, z in enumerate(face):
            w = face[(j + 1) % len(face)]
            subdivided.append(z)
            if edge(z, w) == p:
                subdivided += [a, b] if z == u else [b, a]
            if edge(z, w) == q:
                subdivided += [c, d] if z == x else [d, c]
        if i != fi:
            out_faces.append(subdivided)
            continue
        for first, last in [(b, c), (d, a)]:
            j = subdivided.index(first)
            rotated = subdivided[j:] + subdivided[:j]
            out_faces.append(rotated[:rotated.index(last) + 1])
        out_faces.append([a, b, c, d])
    return vertices | {a, b, c, d}, out_edges, out_faces


def perfect_matchings(vertices, edges):
    adj = adjacency(vertices, {g for g in edges if set(g) <= vertices})

    def visit(left, chosen):
        if not left:
            yield frozenset(chosen)
            return
        v = min(left)
        for w in sorted(adj[v] & left):
            yield from visit(left - {v, w}, chosen + [edge(v, w)])

    yield from visit(set(vertices), [])


def matching_contraction(vertices, edges, matching, first_side):
    mate = {}
    for a, b in matching:
        assert a not in mate and b not in mate
        mate[a], mate[b] = b, a
    assert set(mate) == vertices
    owner = {v: v if v in first_side else mate[v] for v in vertices}
    arcs = []
    for g in sorted(edges - matching):
        a, b = g if g[0] in first_side else g[::-1]
        arcs.append((a, owner[b], g))
    assert all(sum(a == v for a, _, _ in arcs) == 2 ==
               sum(b == v for _, b, _ in arcs) for v in first_side)
    return owner, arcs


def all_shortest_returns(arcs, starts, ends):
    adj = {v: [] for a, b, _ in arcs for v in (a, b)}
    for a, b, g in arcs:
        adj[a].append((b, g))
    dist = {v: 0 for v in starts}
    preds = {v: [] for v in starts}
    todo = deque(sorted(starts))
    while todo:
        a = todo.popleft()
        for b, g in adj.get(a, []):
            if b not in dist:
                dist[b] = dist[a] + 1
                preds[b] = []
                todo.append(b)
            if dist[b] == dist[a] + 1:
                preds[b].append((a, g))
    length = min(dist[t] for t in ends if t in dist)

    def paths(v):
        if v in starts:
            yield [v]
        else:
            for prev, _ in preds[v]:
                for prefix in paths(prev):
                    yield prefix + [v]

    return length, [path for t in sorted(ends) if dist.get(t) == length
                    for path in paths(t)]


def verify():
    cube = [(0, 1), (0, 3), (0, 4), (1, 2), (1, 7), (2, 3),
            (2, 6), (3, 5), (4, 5), (4, 7), (5, 6), (6, 7)]
    vertices, edges = set(range(8)), {edge(*g) for g in cube}
    faces = [[0, 1, 2, 3], [4, 5, 6, 7], [1, 0, 4, 7],
             [2, 1, 7, 6], [3, 2, 6, 5], [0, 3, 5, 4]]
    history = [check_graph(vertices, edges, faces)]
    operations = [((7, 6, 5, 4), [7, 6, 5, 4]),
                  ((0, 1, 7, 4), [0, 1, 7, 4]),
                  ((0, 3, 5, 10), [0, 3, 5, 10, 11, 4])]
    for site, carrier in operations:
        vertices, edges, faces = expand(vertices, edges, faces, site, carrier)
        history.append(check_graph(vertices, edges, faces))
    assert len(vertices) == 20
    site, carrier = (1, 2, 16, 0), [1, 2, 3, 17, 16, 0, 12, 13]
    u, v, x, y = site
    p, q, e, f = edge(u, v), edge(x, y), edge(0, 4), edge(12, 13)
    assert {p, q, e, f} <= edges and len({p, q, e, f}) == 4
    child_v, child_e, child_faces = expand(vertices, edges, faces, site, carrier)
    child_legal = check_graph(child_v, child_e, child_faces)

    all_pm, hamilton = [], []
    for matching in perfect_matchings(vertices, edges):
        cycles = factor(vertices, edges - matching)
        assert all(c["kind"] == "cycle" for c in cycles)
        all_pm.append({"matching": sorted(matching), "complement": cycles})
        if len(cycles) == 1:
            hamilton.append(matching)
    assert len({tuple(row["matching"]) for row in all_pm}) == len(all_pm)
    # Every Hamilton cycle of a cubic graph has exactly one complementary PM.
    requirements = [(a, b) for a in sorted(edges) for b in sorted(edges) if a != b]
    cover = []
    missing = []
    for required, forbidden in requirements:
        witness = next((i for i, m in enumerate(hamilton)
                        if required not in m and forbidden in m), None)
        if witness is None:
            missing.append((required, forbidden))
        else:
            cover.append([required, forbidden, witness])
    assert not missing
    uncovered, selected = set(requirements), []
    while uncovered:
        i = max((i for i in range(len(hamilton)) if i not in selected),
                key=lambda i: sum(a not in hamilton[i] and b in hamilton[i]
                                  for a, b in uncovered))
        selected.append(i)
        uncovered = {(a, b) for a, b in uncovered
                     if not (a not in hamilton[i] and b in hamilton[i])}
    assert len(selected) <= 12  # Verify the separate 12-cycle cover claim.
    joint = [m for m in hamilton if e not in m and f in m]
    claimed_cycle = [0, 4, 11, 10, 19, 16, 17, 18, 5, 3, 2, 6,
                     9, 8, 7, 1, 13, 14, 15, 12]
    assert len(joint) == 1
    assert edges - joint[0] == walk_edges(claimed_cycle, closed=True)
    assert all({p, q} <= m for m in joint)
    C = edges - joint[0]
    Q = walk_edges([20, 21, 22, 23], closed=True)
    F0 = C | Q
    M0 = child_e - F0
    side = next(set(s) for s in child_legal["bipartition"] if u in s)
    owner, arcs = matching_contraction(child_v, child_e, M0, side)
    blocked = owner[f[0]]
    assert blocked not in {u, x, 21, 23}
    allowed = [(a, b, g) for a, b, g in arcs
               if blocked not in (a, b) and g != e]
    length, shortest = all_shortest_returns(allowed, {u, x}, {21, 23})
    assert length == 2 and shortest == [[16, 3, 21]]

    def flip_return(path):
        assert len(set(path)) == len(path)
        assert path[0] in {u, x} and path[-1] in {21, 23}
        assert not (set(path[1:-1]) & {u, x, 21, 23})
        pairs = list(zip(path, path[1:])) + [(path[-1], path[0])]
        circuit_edges = set()
        for a, b in pairs:
            opts = [g for aa, bb, g in allowed if (aa, bb) == (a, b)]
            assert len(opts) == 1
            circuit_edges.add(opts[0])
        circuit_edges |= {g for g in M0 if owner[g[0]] in path}
        assert len(circuit_edges) == 2 * len(path)
        assert not ({e, f} & circuit_edges)
        assert len(components({z for g in circuit_edges for z in g}, circuit_edges)) == 1
        flipped = F0 ^ circuit_edges
        result = factor(child_v, flipped)
        assert all(c["kind"] == "cycle" for c in result)
        assert e in flipped and f not in flipped and len(flipped & Q) == 3
        assert sum(g in flipped for g in [edge(u, 20), edge(v, 21),
                                          edge(x, 22), edge(y, 23)]) == 2
        return {"return": path, "alternating_cycle": sorted(circuit_edges),
                "removed": sorted(F0 - flipped), "added": sorted(flipped - F0),
                "two_factor": result}, flipped

    failed, F1 = flip_return(shortest[0])
    assert sorted(len(c["vertices"]) for c in failed["two_factor"]) == [4, 20]
    assert walk_edges([3, 17, 18, 5], True) <= F1
    longer, F2 = flip_return([16, 3, 6, 21])
    assert len(longer["two_factor"]) == 1
    claimed_path = [2, 3, 17, 18, 5, 6, 9, 8, 7, 1, 13, 14,
                    15, 12, 0, 4, 11, 10, 19, 16]
    path_edges = walk_edges(claimed_path)
    R = edges - {p, q}
    assert len(claimed_path) == len(set(claimed_path)) == len(vertices)
    assert set(claimed_path) == vertices and path_edges <= R
    assert e in path_edges and f not in path_edges
    assert {g for g in F2 if set(g) <= vertices} == path_edges

    # Full family A from (7): choose its exact unmatched port set first.
    ports = set(site)
    feasible, histogram = [], Counter()
    union = set()
    for k in range(5):
        for holes_tuple in combinations(sorted(ports), k):
            holes = set(holes_tuple)
            residual_vertices = vertices - holes - set(f)
            if len(residual_vertices) % 2:
                continue
            for rest in perfect_matchings(residual_vertices, R - {e}):
                N = set(rest) | {f}
                assert N <= R and e not in N
                used = [z for g in N for z in g]
                assert len(used) == len(set(used)) and set(used) == vertices - holes
                W = factor(vertices, R - N)
                z = sum(row["kind"] == "cycle" for row in W)
                s = 4 - len(holes)
                rank = len(N) - len(W) + 1
                b = len(R) - len(vertices) + 1
                assert s in (0, 2, 4) and b - rank == z
                histogram[s, z, rank] += 1
                union |= N
                feasible.append({"matching": sorted(N), "matched_ports": s,
                                 "cycles": z, "cographic_rank": rank,
                                 "complement": W})
    assert len({tuple(map(tuple, row["matching"])) for row in feasible}) == len(feasible)
    union_rank = len(union) - len(components(vertices, R - union)) + 1
    assert union_rank == b and max(row["cographic_rank"] for row in feasible) == b
    successful_N = R - path_edges
    assert any(set(map(tuple, row["matching"])) == successful_N for row in feasible)
    return {"cube_edges": sorted(map(tuple, cube)), "operations": operations,
            "history": history, "parent_edges": sorted(edges),
            "final_site": site, "final_carrier": carrier,
            "targets": {"p": p, "q": q, "e": e, "f": f},
            "child_legality": child_legal,
            "perfect_matching_count": len(all_pm),
            "all_parent_perfect_matchings": all_pm,
            "hamilton_matching_count": len(hamilton),
            "hamilton_matchings": [sorted(m) for m in hamilton],
            "global_H_plus_minus": {"requirements": len(requirements),
                                    "missing": missing, "witness_indices": cover,
                                    "cover_indices": selected,
                                    "cover_cycles": [factor(vertices, edges - hamilton[i])[0]
                                                     for i in selected]},
            "unique_joint_matching": sorted(joint[0]), "unique_joint_cycle": claimed_cycle,
            "initial_child_matching": sorted(M0),
            "contraction": {"first_side": sorted(side), "owner": owner,
                            "all_arcs": arcs, "deleted_vertex": blocked,
                            "deleted_edge": e, "allowed_arcs": allowed},
            "shortest_return_length": length, "all_shortest_returns": shortest,
            "shortest_flip": failed, "longer_flip": longer,
            "successful_old_path": claimed_path,
            "family_A": {"count": len(feasible), "rank": b,
                         "support_rank": union_rank, "full_family": feasible,
                         "histogram_s_z_rank": [[*key, count] for key, count
                                                in sorted(histogram.items())]}}


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2, ensure_ascii=False))
