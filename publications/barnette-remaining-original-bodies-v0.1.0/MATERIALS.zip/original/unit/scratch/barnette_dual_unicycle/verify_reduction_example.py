"""Verify the lifted two-forest reduction on the 16-vertex brace of Note 062."""

from collections import defaultdict, deque
from itertools import combinations


FACES = (
    (0, 8, 2, 10),
    (0, 9, 1, 8),
    (1, 9, 3, 11),
    (2, 12, 4, 10),
    (3, 13, 5, 11),
    (4, 12, 6, 14),
    (5, 13, 7, 15),
    (6, 15, 7, 14),
    (0, 10, 4, 14, 7, 13, 3, 9),
    (1, 11, 5, 15, 6, 12, 2, 8),
)

# Note 062, equation (12).
J = {
    (1, 8), (1, 11), (2, 10), (2, 12), (3, 9), (3, 13),
    (4, 12), (4, 14), (5, 11), (5, 15), (6, 15),
    (7, 13), (7, 14),
}

Y = set(range(8))
X = set(range(8, 16))
ROOT = 0
PORTS = {8, 9, 10}
SINGLETON_PORT = 8
FREE_Y = 6


def edge(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


def components(vertices, edges):
    adjacency = {v: set() for v in vertices}
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    unseen = set(vertices)
    result = []
    while unseen:
        start = next(iter(unseen))
        queue = deque([start])
        unseen.remove(start)
        component = {start}
        while queue:
            u = queue.popleft()
            for v in adjacency[u]:
                if v in unseen:
                    unseen.remove(v)
                    component.add(v)
                    queue.append(v)
        result.append(component)
    return result


edge_faces = defaultdict(list)
for face_id, face in enumerate(FACES):
    for i, u in enumerate(face):
        edge_faces[edge(u, face[(i + 1) % len(face)])].append(face_id)

edges = set(edge_faces)
assert len(edges) == 24
assert all(len(edge_faces[e]) == 2 for e in edges)
assert all(sum(v in e for e in edges) == 3 for v in X | Y)
assert all((u in X) != (v in X) for u, v in edges)

# The strict Hall certificate used in Note 062, checked directly.
for side, other in ((X, Y), (Y, X)):
    minimum = min(
        len({v for u in subset for e in edges if u in e for v in e if v in other})
        - len(subset)
        for size in range(1, 7)
        for subset in combinations(side, size)
    )
    assert minimum == 2

assert J <= edges
assert not any(ROOT in e for e in J)
P_edges = {e for e in edges if ROOT not in e}
K = P_edges - J

deg_J = {v: sum(v in e for e in J) for v in (X | Y) - {ROOT}}
assert all(deg_J[x] == (1 if x in PORTS else 2) for x in X)
assert all(deg_J[y] == (1 if y == FREE_Y else 2) for y in Y - {ROOT})

J_components = components((X | Y) - {ROOT}, J)
assert len(J_components) == 2
assert len(J) == 13 == 15 - 2
assert any({9, 10} <= component and 8 not in component for component in J_components)
assert any({8, FREE_Y} <= component and not ({9, 10} & component) for component in J_components)

deg_K = {v: sum(v in e for e in K) for v in (X | Y) - {ROOT}}
assert all(deg_K[x] == 1 for x in X)
assert all(deg_K[y] == (2 if y == FREE_Y else 1) for y in Y - {ROOT})
assert {e for e in K if FREE_Y in e} == {(6, 12), (6, 14)}
assert not any(FREE_Y in e and bool(PORTS & set(e)) for e in K)

# Lift K* from P* to T=F*: it is a forest with two components.  The
# endpoints of (r,s)^* are together and the third root-triangle vertex is
# in the other component.
H = {tuple(edge_faces[e]) for e in K}
dual_vertices = set(range(len(FACES)))
H_components = components(dual_vertices, H)
assert len(H) == 8
assert len(H_components) == 2
assert len(H) == len(dual_vertices) - len(H_components)

root_dual_edges = {neighbor: tuple(edge_faces[edge(ROOT, neighbor)]) for neighbor in PORTS}
p, q = root_dual_edges[SINGLETON_PORT]
root_corners = set().union(*map(set, root_dual_edges.values()))
assert len(root_corners) == 3
z, = root_corners - {p, q}
assert any({p, q} <= component and z not in component for component in H_components)
assert any(z in component and not ({p, q} & component) for component in H_components)

# Contracting the three root corners gives the direct connected unicycle.
contracted = -1
quotient_vertices = (dual_vertices - root_corners) | {contracted}
quotient_edges = {
    edge(contracted if u in root_corners else u, contracted if v in root_corners else v)
    for u, v in H
}
assert all(u != v for u, v in quotient_edges)
assert len(components(quotient_vertices, quotient_edges)) == 1
assert len(quotient_edges) == len(quotient_vertices)

print("DIRECT_DUAL_TWO_FOREST_REDUCTION_VERIFIED")
print("free-face K edges:", sorted(e for e in K if FREE_Y in e))
print("root dual corners (p,q|z):", (p, q, z))
