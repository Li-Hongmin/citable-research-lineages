# Direct dual-unicycle target = a rooted two-forest = four common bases

Let \(|X|=|Y|=n\), put (T=F^*), and let the three vertices of the root
triangle \(\tau_r\) be \(p,q,z\), labelled so that

\[
(rs)^*=pq,qquad (ra)^*,(rb)^*\in\{qz,zp\}.
\]

Write (d_a=(ra)^*), (d_b=(rb)^*), and
(E_0=E(T)\setminus E(\tau_r)).  Deleting (r) in the primal identifies
(p,q,z) in the dual, so (P^*) is the quotient of (T) obtained by
collapsing \(\tau_r\) to one vertex.

For a fixed free vertex (y\in Y\setminus\{r\}), the proposition in the
task is equivalent to the existence of (H\subseteq E_0) with the facial
loads

\[
|H\cap\partial\tau_x|=1\quad(x\in X),
\]
\[
|H\cap\partial\tau_v|=1\quad
(v\in Y\setminus\{r,y\}),
\qquad |H\cap\partial\tau_y|=2,
\tag{1}
\]

such that (H) is a spanning forest of (T) with exactly two components
and root partition

\[
p\leftrightarrow_H q,qquad z\not\leftrightarrow_H p.
\tag{2}
\]

Thus the universal direct target is exactly

\[
\forall(F,r,s) \exists y\in Y\setminus\{r\}\ \exists H
\text{ satisfying (1)--(2)}.
\tag{3}
\]

## Why the lift is exact

The loads give \(|H|=n\), while \(|V(T)|=n+2\).  Let \(\bar H\) be the
image of (H) after identifying (p,q,z).  If \(\bar H\) is connected,
every component of (H) meets \(\{p,q,z\}\).  With (c=c(H)),

\[
\beta(\bar H)=\beta(H)+3-c.
\tag{4}
\]

The unique cycle dual to a bond inducing the port split
\(\{s\}\mid\{a,b\}\) traverses the collapsed root face through the two
corners (p,q), the ends of \((rs)^*\).  Hence (p,q) lie in one component
of (H).  Equation (4), connectedness, and \(\beta(\bar H)=1\) then force
(c=2) and \(\beta(H)=0\); the other component contains (z).  Conversely,
(2) makes the quotient connected, and identifying (p,q) creates its only
cycle while identifying (z) joins the other tree.  The local Jordan-curve
order at the collapsed root face gives exactly the stated port split.

This removes both dual connectedness and the unicycle/bond condition: they
become one forest condition and the three-root partition (2).

## Exact four-common-base form

On (E_0), let

- \(\mathcal P_X\) be the partition matroid whose (X)-face blocks all
  have capacity one;
- \(\mathcal P_{Y,y}\) be the partition matroid whose
  (Y\setminus\{r,y\})-face blocks have capacity one and whose (y)-block
  has capacity two;
- \(\mathcal G_a=M(T/d_a)\) and
  \(\mathcal G_b=M(T/d_b)\), with the unused root-triangle edges forbidden.

All four relevant ranks are (n).  Conditions (1)--(2) are equivalent to

\[
H\in
\mathcal B(\mathcal P_X)\cap
\mathcal B(\mathcal P_{Y,y})\cap
\mathcal B(\mathcal G_a)\cap
\mathcal B(\mathcal G_b).
\tag{5}
\]

Indeed, the two partition bases are exactly (1).  Moreover,

\[
H\in\mathcal B(\mathcal G_a)
\Longleftrightarrow H+d_a\text{ is a spanning tree of }T,
\]

and similarly for (d_b).  Both are trees precisely when (H) is a
two-forest with (z) separated from each of (p,q), which is (2).
Equivalently, after requiring (B=H+d_a) to be a spanning tree, the last
graphic-base condition is the single exact cut test that (d_b) crosses
the fundamental bond of (d_a) in (B).

## Check of the proposed decorated-RCA/coloring hint

The reduction in `../barnette_decorated_rca/result.md` is correct, but it
describes the stronger two-cycle completion/RCA branch, not every direct
target.  For a perfect matching (M\ni rs), its dual edge set (M^*) has

\[
\beta(M^*)=c(F-M)-1,
\]

and \((rs)^*\) lies on a cycle of (M^*) exactly when (r,s) lie on
different complementary cycles.  Hence the RCA target is exactly
\(\beta(M^*)=1\) with \((rs)^*\) on the unique cycle; deleting \((rs)^*\)
gives the rooted exact-one three-forest stated in that result.

The binary-coloring reformulation is also exact only when
"non-monochromatic" means **on every triangular face**.  Such a coloring
selects one monochromatic edge per triangle and hence a perfect matching.
Conversely every perfect matching gives two complementary colorings: set
matching-dual edges monochromatic and complementary-factor dual edges
bichromatic.  Consistency follows because the complementary 2-factor meets
every primal cut evenly.

This coloring does not parametrize a general direct witness: its
monochromatic count on a non-monochromatic triangle is one, whereas (1)
has loads zero at \(\tau_r\) and two at \(\tau_y\).  It applies only after
a completion edge from the free vertex to a root port is available.  The
Note 062 witness (12) is a concrete direct two-path witness with free
vertex (6) whose two omitted edges are (6\!-!12,6\!-!14), neither
incident with a root port \(\{8,9,10\}\).  Thus the direct route is genuinely
broader than the matching-coloring/RCA branch.

The scratch verifier `verify_reduction_example.py` independently checks
on that simple plane 16-vertex brace the facial loads, two path components,
lifted two-forest, root partition, and contracted connected-unicycle count;
it ends with `DIRECT_DUAL_TWO_FOREST_REDUCTION_VERIFIED`.

## Acceptance items

**Exact conclusion and quantifiers.**  The universal proposition is not
proved or refuted here.  Pointwise for every simple plane cubic bipartite
brace (F), every root (r\in Y), and every choice of singleton port
(s\in N(r)), it is exactly (3), equivalently the existence for some free
(y) of the four-common-base object (5).

**Weakest load-bearing argument.**  The only topological step is that a
dual bond separating \(\{s\}\) from \(\{a,b\}\) traverses the collapsed
root face through the ends (p,q) of \((rs)^*\).  The rest is the cycle-rank
identity (4) and the elementary contraction criterion
(H\in\mathcal B(M(T/d))\iff H+d) is a spanning tree.

**Evidence level.**  Proof-level exact integral reduction, plus an
independent finite sanity check on the genuine plane 16-vertex brace of
Note 062.  No LP relaxation and no assumed RCA lemma are used.

**Unresolved boundary.**  It remains unknown whether the four matroids in
(5) always have a common base for at least one free face (y).  In the
equivalent thinnest cut form: one must find a common
\(\mathcal P_X\)-, \(\mathcal P_{Y,y}\)-, and \(M(T/d_a)\)-base for which
(d_b) crosses the fundamental bond of (d_a).  Planarity and the brace
condition have not yet been shown to force that final cut hit.
