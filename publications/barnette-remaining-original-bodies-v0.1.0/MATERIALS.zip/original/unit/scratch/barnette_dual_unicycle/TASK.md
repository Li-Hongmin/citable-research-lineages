# Single leaf task: direct dual-unicycle route

Work only in the Barnette unit:

    [local archival reference]

Read README.md and Notes 057, 058, 060, and 062. Do not modify permanent
notes or papers. Put exploration only under this scratch directory.

Let \(F\) be a simple plane cubic bipartite brace with bipartition
\(X\sqcup Y\), root \(r\in Y\), neighbours \(\{a,b,s\}\), and
\(P=F-r\). Determine this single proposition, in the exact dual form of
Note 057:

> Does \(P^*\) always contain a connected spanning unicyclic subgraph \(K^*\)
> using exactly one edge on every \(X\)-face, exactly one edge on every
> \(Y\setminus\{r,y\}\)-face and two on one free face \(f_y\), such that its
> unique cycle is dual to a bond separating the port split
> \(\{s\}\mid\{a,b\}\)?

This is equivalent to the planar spanning two-path target. Attack it directly
through planar duality, matroid intersection, arborescences, or a genuine
counterexample. Do not use RCA as an assumed lemma and do not report a
generic LP relaxation unless it changes the integral decision.

Stop at proof, genuine simple plane-brace counterexample, strict reduction to
a thinner exact common-base/cut condition, or a route closure. End with:
exact conclusion and quantifiers; weakest load-bearing argument; evidence
level; unresolved boundary.
