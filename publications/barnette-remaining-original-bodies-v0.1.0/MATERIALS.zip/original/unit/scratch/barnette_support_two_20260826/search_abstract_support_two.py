#!/usr/bin/env python3
"""Find a degree-vector family satisfying (B) but with no compatible pair.

Vectors have entries in {-1,0,1}, total -1, and no all-nonpositive
vector.  Compatibility means a+b <= 0 coordinatewise, exactly the
equal-weight support-two condition for e=d-2.
"""

from __future__ import annotations

from itertools import product

import networkx as nx
import numpy as np
from scipy.optimize import linprog


def vectors(m: int) -> list[tuple[int, ...]]:
    return [
        v
        for v in product((-1, 0, 1), repeat=m)
        if sum(v) == -1 and 1 in v
    ]


def compatible(a: tuple[int, ...], b: tuple[int, ...]) -> bool:
    return all(x + y <= 0 for x, y in zip(a, b))


def find_countermodel(m: int):
    states = vectors(m)
    graph = nx.Graph()
    graph.add_nodes_from(range(len(states)))
    graph.add_edges_from(
        (i, j)
        for i in range(len(states))
        for j in range(i + 1, len(states))
        if not compatible(states[i], states[j])
    )
    for clique in nx.find_cliques(graph):
        if len(clique) < 3:
            continue
        matrix = np.asarray([states[i] for i in clique], dtype=float).T
        result = linprog(
            np.zeros(len(clique)),
            A_ub=matrix,
            b_ub=np.zeros(m),
            A_eq=np.ones((1, len(clique))),
            b_eq=np.ones(1),
            bounds=(0, None),
            method="highs",
        )
        if result.success:
            support = [
                (states[clique[j]], weight)
                for j, weight in enumerate(result.x)
                if weight > 1e-8
            ]
            return len(states), support
    return len(states), None


def main() -> None:
    for m in range(3, 7):
        count, answer = find_countermodel(m)
        print({"m": m, "state_count": count, "countermodel": answer})
        if answer is not None:
            break


if __name__ == "__main__":
    main()
