# Equal support two is not a consequence of the fractional degree box

For a fixed fibre put

\[
e(J)=d(J)-2\mathbf 1\in\{-1,0,1\}^m,
\qquad \sum_y e(J)_y=-1.
\]

The proposed pair condition is exactly

\[
e(J_1)+e(J_2)\le0.
\tag{1}
\]

Equivalently, if

\[
P(J)=\{y:d(J)_y=3\},\qquad N(J)=\{y:d(J)_y=1\},
\]

then (1) says

\[
P(J_1)\subseteq N(J_2),\qquad
P(J_2)\subseteq N(J_1).
\tag{2}
\]

In complement notation \(K_J=E(P)\setminus J\), it says that two
\(X\)-degree-one complements have combined degree at least two at every
\(Y\setminus\{r\}\) vertex.

## Minimum abstract obstruction

Consider the three excess vectors

\[
\begin{aligned}
e_1&=(-1,-1,0,1),\\
e_2&=(-1,1,-1,0),\\
e_3&=(-1,0,1,-1).
\end{aligned}
\tag{3}
\]

They obey all universal degree-vector constraints: every entry lies in
\(\{-1,0,1\}\) and every total is \(-1\).  The corresponding degree
vectors are

\[
(1,1,2,3),\qquad (1,3,1,2),\qquad (1,2,3,1),
\tag{4}
\]

each with total \(7=2\cdot4-1\).

Their equal three-way average is

\[
\frac13(e_1+e_2+e_3)=(-1,0,0,0),
\]

so their convex hull meets the degree box, at degree vector
\((1,2,2,2)\).  In fact the coordinate inequalities on a convex
combination with weights \((w_1,w_2,w_3)\) give

\[
w_2\le w_1,\qquad w_3\le w_2,\qquad w_1\le w_3,
\]

so the unique box-feasible distribution is
\(w_1=w_2=w_3=1/3\).

No two vectors, including a repeated vector, satisfy (1).  For the three
distinct pairs the uncancelled positive coordinates are respectively the
fourth, third and second coordinates.  Thus this model satisfies (B), and
hence all binary weak hole bounds, but every box-feasible distribution has
support exactly three.  It rules out extracting equal support at most two
from (B) by convexity, Caratheodory reduction, or the universal discrete
constraints on \(d(J)\).

The obstruction is coordinate-minimal.  With at most two coordinates, a
vector in \(\{-1,0,1\}^m\) of total \(-1\) has no positive entry and is
itself a support-one certificate.  With three coordinates, every vector
having a positive entry is a permutation of \((1,-1,-1)\); every two
distinct such vectors satisfy (1), while a singleton family cannot have a
nonpositive convex average.

## Exact boundary

This is an abstract degree-vector model, not a fixed forest fibre and not an
actual cubic bipartite brace.  It therefore does **not** refute the proposed
universal support-two statement.  It proves the strict route boundary:

> Any proof of universal equal support two must use additional incidence or
> exchange structure of actual brace fibres; the fractional degree-box
> property (B), even together with all universal coordinate and total-sum
> constraints, is insufficient.

The remaining interface is to identify an actual-fibre condition excluding
the directed three-cycle in (3), or to realize an analogous cycle in a real
brace.  The EH54 certificate of Note 056 shows that support two can be
necessary, but does not decide whether it is always sufficient.

Run

```bash
python3 units/barnette/scratch/barnette_support_two_20260826/verify_fractional_box_does_not_force_support_two.py
```

to obtain

```text
FRACTIONAL_BOX_DOES_NOT_FORCE_SUPPORT_TWO_VERIFIED
```
