#!/usr/bin/env python3
"""Exact abstract countermodel to degree-unit-exchange connectivity."""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations_with_replacement

import networkx as nx


STATES = (
    (-1, -1, -1, 1, 1),
    (-1, -1, 0, 0, 1),
    (-1, 0, -1, 1, 0),
    (-1, 0, 0, 1, -1),
    (-1, 0, 1, 0, -1),
    (-1, 1, -1, 0, 0),
    (-1, 1, -1, 1, -1),
    (0, 0, -1, 1, -1),
    (0, 1, -1, -1, 0),
    (1, -1, -1, 1, -1),
)


def unit_transfer(a: tuple[int, ...], b: tuple[int, ...]) -> bool:
    difference = tuple(x - y for x, y in zip(a, b))
    return sum(abs(value) for value in difference) == 2


def compatible(a: tuple[int, ...], b: tuple[int, ...]) -> bool:
    return all(x + y <= 0 for x, y in zip(a, b))


def main() -> None:
    assert len(STATES) == len(set(STATES)) == 10
    assert all(set(state) <= {-1, 0, 1} and sum(state) == -1 for state in STATES)
    assert all(
        not compatible(STATES[i], STATES[j])
        for i, j in combinations_with_replacement(range(len(STATES)), 2)
    )

    exchange = nx.Graph()
    exchange.add_nodes_from(range(len(STATES)))
    exchange.add_edges_from(
        (i, j)
        for i in range(len(STATES))
        for j in range(i + 1, len(STATES))
        if unit_transfer(STATES[i], STATES[j])
    )
    assert nx.is_connected(exchange)

    weights = (Fraction(1, 4), Fraction(1, 2), Fraction(1, 4))
    support = (1, 8, 9)
    average = tuple(
        sum(weight * STATES[index][coordinate] for weight, index in zip(weights, support))
        for coordinate in range(5)
    )
    assert average == (
        Fraction(0),
        Fraction(0),
        Fraction(-3, 4),
        Fraction(-1, 4),
        Fraction(0),
    )
    assert max(average) <= 0

    print(
        {
            "states": len(STATES),
            "unit_transfer_edges": exchange.number_of_edges(),
            "unit_transfer_connected": nx.is_connected(exchange),
            "diameter": nx.diameter(exchange),
            "box_feasible_support_1_based": tuple(index + 1 for index in support),
            "weights": tuple(str(weight) for weight in weights),
            "average": tuple(str(value) for value in average),
            "compatible_pairs_allowing_repetition": 0,
        }
    )
    print("CONNECTED_UNIT_EXCHANGE_DOES_NOT_FORCE_SUPPORT_TWO_VERIFIED")


if __name__ == "__main__":
    main()
