# Actual fibre incidence does not exclude the support-three circuit

## Question and compatibility language

For a fixed fibre \(\mathcal J\), write

\[
e(J)=d(J)-2\mathbf 1,\qquad
P(J)=\{y:e(J)_y=1\},\qquad
N(J)=\{y:e(J)_y=-1\}.
\]

Two forests are compatible precisely when

\[
e(J_1)+e(J_2)\le0,
\]

equivalently

\[
P(J_1)\subseteq N(J_2),\qquad
P(J_2)\subseteq N(J_1).
\tag{1}
\]

The abstract three-state circuit in Note 056 shows that fractional
feasibility alone does not imply (1). The first remaining possibility was
that actual brace incidence, or the legal exchange graph of a full fibre,
forbids that circuit. It does not.

## A directed circuit inside an actual full fibre

Take the planar cubic bipartite brace

    K??FEagT@WB_

with root \(r=0\), ports \((6,7,8)\), and split
\(\{6\}\mid\{7,8\}\). Exhausting all local \(X\)-degree choices gives the
complete fibre: 22 forests and 13 distinct \(Y\)-degree vectors, in the
order \(Y\setminus\{r\}=(1,2,3,4,5)\).

The full fibre contains forests \(A,B,C\) with

\[
\begin{aligned}
d(A)&=(1,2,3,1,2),&
e(A)&=(-1,0,1,-1,0),\\
d(B)&=(2,1,1,2,3),&
e(B)&=(0,-1,-1,0,1),\\
d(C)&=(2,1,2,3,1),&
e(C)&=(0,-1,0,1,-1).
\end{aligned}
\tag{2}
\]

On the last three coordinates these are

\[
(1,-1,0),\qquad(-1,0,1),\qquad(0,1,-1),
\]

the directed three-cycle. Moreover,

\[
\frac13(e(A)+e(B)+e(C))
=\left(-\frac13,-\frac23,0,0,0\right)\le0,
\tag{3}
\]

but none of \(A,B,C\), allowing repetition, forms a compatible pair.
Explicit forest edge sets are

\[
\begin{aligned}
A=\{&
16,28,2\,10,37,39,3\,11,4\,11,59,5\,10\},\\
B=\{&
17,19,26,3\,11,48,4\,10,59,5\,10,5\,11\},\\
C=\{&
16,19,2\,10,37,3\,11,48,4\,10,4\,11,59\}.
\end{aligned}
\tag{4}
\]

Here, for example, \(2\,10\) denotes the edge \(\{2,10\}\).
The verifier independently checks that the graph is simple, cubic,
bipartite, planar and satisfies strict Hall; it then enumerates the whole
specified fibre rather than merely checking the three displayed forests.

Define the same-\(X\) pivot graph on the 22 forests by joining \(J,J'\)
when \(J'=J-f+g\), where \(f,g\) meet the same \(X\)-vertex and \(J'\)
remains in the fixed fibre. This graph has 35 edges and is connected.
Thus actual planar-brace incidence and full-fibre pivot connectivity do not
exclude the support-three circuit.

The full fibre repairs the circuit by **additional compatibility chords**,
not by preventing it. For example,

\[
\begin{array}{c|c|c}
\text{pivot}&\text{new degree vector}&\text{compatible target}\\ \hline
A-5\,10+4\,10&(1,2,3,2,1)&B\\
A-3\,11+5\,11&(1,2,2,1,3)&C\\
B-5\,11+4\,11&(2,1,1,3,2)&A.
\end{array}
\tag{5}
\]

There are also three integral box vectors in the full fibre. Consequently
this graph is not a counterexample to S2; its role is to identify the
load-bearing mechanism as full-family chord saturation rather than circuit
exclusion.

## Ordinary degree-unit connectivity is still insufficient

Even connectivity under the projected unit-transfer relation cannot supply
the missing chord abstractly. The ten states

\[
\begin{aligned}
&(-1,-1,-1,1,1),\ (-1,-1,0,0,1),\
(-1,0,-1,1,0),\\
&(-1,0,0,1,-1),\ (-1,0,1,0,-1),\
(-1,1,-1,0,0),\\
&(-1,1,-1,1,-1),\ (0,0,-1,1,-1),\
(0,1,-1,-1,0),\\
&(1,-1,-1,1,-1)
\end{aligned}
\tag{6}
\]

all lie in \(\{-1,0,1\}^5\) and have total \(-1\). Join two states when
their difference has \(\ell_1\)-norm two, that is, when one unit is moved
between two coordinates. The resulting graph is connected, with 13 edges
and diameter four. Nevertheless every pair, allowing repetition, has a
positive sum coordinate. States 2, 9 and 10 with weights
\((1/4,1/2,1/4)\) average to

\[
(0,0,-3/4,-1/4,0)\le0.
\tag{7}
\]

Hence (B), all universal degree constraints, and connectedness of the
ordinary degree-unit exchange graph still do not imply S2. Model (6) is
abstract and is not claimed to be a forest fibre.

## Route boundary and remaining exchange interface

The following natural routes are now closed:

1. excluding the Note 056 circuit by actual cubic, bipartite, planar or
   brace incidence;
2. excluding it by connectedness of the full same-\(X\) pivot graph;
3. extracting a compatible pair from (B) plus connected projected
   unit-transfer dynamics.

Along the local-exchange route, a sufficient remaining statement is the
following **actual boundary-chord lemma**.

> Let \(\mathcal S\) be an inclusion-minimal support of a box-feasible
> distribution in an actual fixed fibre. If \(\mathcal S\) has no
> compatible pair, then some same-\(X\) pivot \(J\to J'\), with
> \(J\in\mathcal S\), produces \(J'\) compatible with some
> \(K\in\mathcal S\).

This lemma immediately implies S2. The planar fibre above satisfies it via
(5), while the connected abstract system (6) proves that its proof must use
the full graphic/partition incidence of the forest exchange, not merely
degree-vector adjacency. The lemma, and therefore S2 itself, remains
unproved for arbitrary simple cubic bipartite braces.

Exact reproduction:

    python3 units/barnette/scratch/barnette_support_two_20260826/s2_actual_exchange_cycle/analyze_actual_exchange_cycle.py
    python3 units/barnette/scratch/barnette_support_two_20260826/s2_actual_exchange_cycle/verify_connected_unit_exchange_countermodel.py

with terminal markers

    ACTUAL_FULL_FIBRE_CONTAINS_SUPPORT_THREE_CYCLE_VERIFIED
    CONNECTED_UNIT_EXCHANGE_DOES_NOT_FORCE_SUPPORT_TWO_VERIFIED
