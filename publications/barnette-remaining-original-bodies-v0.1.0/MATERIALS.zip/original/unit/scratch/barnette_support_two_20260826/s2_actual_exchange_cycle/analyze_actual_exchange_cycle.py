#!/usr/bin/env python3
"""Inspect the full fixed fibre containing an abstract support-three cycle."""

from __future__ import annotations

from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations, product

import networkx as nx


GRAPH6 = "K??FEagT@WB_"
ROOT = 0
SINGLETON_PORT = 6
TARGET_VECTORS = (
    (1, 2, 3, 1, 2),
    (2, 1, 1, 2, 3),
    (2, 1, 2, 3, 1),
)
Edge = tuple[int, int]
Forest = frozenset[Edge]


def edge(a: int, b: int) -> Edge:
    return (a, b) if a < b else (b, a)


def strict_hall_brace(graph: nx.Graph, side: tuple[int, ...]) -> bool:
    for size in range(1, len(side) - 1):
        for shore in combinations(side, size):
            neighbours = set().union(*(set(graph[x]) for x in shore))
            if len(neighbours) < size + 2:
                return False
    return True


def enumerate_fibre(
    graph: nx.Graph,
) -> tuple[tuple[int, ...], tuple[int, ...], tuple[int, ...], tuple[Forest, ...]]:
    colour = nx.bipartite.color(graph)
    y_side = tuple(sorted(v for v in graph if colour[v] == colour[ROOT]))
    x_side = tuple(sorted(set(graph) - set(y_side)))
    y_order = tuple(v for v in y_side if v != ROOT)
    ports = tuple(sorted(graph[ROOT]))
    pole_vertices = tuple(sorted(set(graph) - {ROOT}))
    pole = graph.subgraph(pole_vertices)

    choices = []
    for x in x_side:
        required = 1 if x in ports else 2
        incident = tuple(sorted(edge(x, y) for y in pole[x]))
        choices.append(
            tuple(frozenset(selected) for selected in combinations(incident, required))
        )

    fibre = []
    for local_selection in product(*choices):
        selected = frozenset().union(*local_selection)
        support = nx.Graph()
        support.add_nodes_from(pole_vertices)
        support.add_edges_from(selected)
        if not nx.is_forest(support) or nx.number_connected_components(support) != 2:
            continue
        blocks = sorted(
            (
                tuple(sorted(set(component) & set(ports)))
                for component in nx.connected_components(support)
            ),
            key=lambda block: (len(block), block),
        )
        if blocks == [(SINGLETON_PORT,), (7, 8)]:
            fibre.append(selected)
    return x_side, y_order, ports, tuple(sorted(fibre, key=lambda f: tuple(sorted(f))))


def degree_vector(forest: Forest, y_order: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(sum(y in selected_edge for selected_edge in forest) for y in y_order)


def same_x_pivot(a: Forest, b: Forest, x_side: set[int]) -> bool:
    if len(a ^ b) != 2:
        return False
    removed = next(iter(a - b))
    added = next(iter(b - a))
    removed_x = next(v for v in removed if v in x_side)
    added_x = next(v for v in added if v in x_side)
    return removed_x == added_x


def compatible(a: tuple[int, ...], b: tuple[int, ...]) -> bool:
    return all(x + y <= 4 for x, y in zip(a, b))


def convex_pair_hits_box(a: tuple[int, ...], b: tuple[int, ...]) -> bool:
    """Test exactly whether t*a+(1-t)*b <= 2 for some 0 <= t <= 1."""

    lower = Fraction(0)
    upper = Fraction(1)
    for a_value, b_value in zip(a, b):
        a_excess = a_value - 2
        b_excess = b_value - 2
        difference = a_excess - b_excess
        if difference == 0:
            if b_excess > 0:
                return False
        elif difference > 0:
            upper = min(upper, Fraction(-b_excess, difference))
        else:
            lower = max(lower, Fraction(-b_excess, difference))
    return lower <= upper


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert graph.number_of_nodes() == 12 and graph.number_of_edges() == 18
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.check_planarity(graph)[0]

    x_side, y_order, ports, fibre = enumerate_fibre(graph)
    assert x_side == (6, 7, 8, 9, 10, 11)
    assert y_order == (1, 2, 3, 4, 5)
    assert ports == (6, 7, 8)
    assert strict_hall_brace(graph, x_side)
    assert strict_hall_brace(graph, (ROOT,) + y_order)
    assert len(fibre) == 22

    vectors = tuple(degree_vector(forest, y_order) for forest in fibre)
    vector_counts = Counter(vectors)
    assert len(vector_counts) == 13
    assert all(target in vector_counts for target in TARGET_VECTORS)

    # The last three coordinates are the directed three-cycle from Note 056.
    excess = tuple(tuple(value - 2 for value in vector) for vector in TARGET_VECTORS)
    assert tuple(vector[2:] for vector in excess) == (
        (1, -1, 0),
        (-1, 0, 1),
        (0, 1, -1),
    )
    assert tuple(sum(vector[j] for vector in excess) for j in range(5)) == (
        -1,
        -2,
        0,
        0,
        0,
    )
    assert all(
        not compatible(TARGET_VECTORS[i], TARGET_VECTORS[j])
        for i in range(3)
        for j in range(i, 3)
    )
    assert all(
        not convex_pair_hits_box(TARGET_VECTORS[i], TARGET_VECTORS[j])
        for i in range(3)
        for j in range(i, 3)
    )

    pivot_graph = nx.Graph()
    pivot_graph.add_nodes_from(range(len(fibre)))
    for i, j in combinations(range(len(fibre)), 2):
        if same_x_pivot(fibre[i], fibre[j], set(x_side)):
            pivot_graph.add_edge(i, j)
    assert nx.is_connected(pivot_graph)

    indices_by_vector: dict[tuple[int, ...], list[int]] = defaultdict(list)
    for index, vector in enumerate(vectors):
        indices_by_vector[vector].append(index)
    target_indices = tuple(indices_by_vector[vector][0] for vector in TARGET_VECTORS)
    target_forests = tuple(tuple(sorted(fibre[index])) for index in target_indices)

    # The full fibre does repair this particular circuit, but by adding
    # states rather than by forbidding the circuit.  Freeze three explicit
    # one-pivot compatibility chords, one from each of the first two target
    # representatives and two choices from the third.
    chord_indices = ((4, 3, 15), (4, 6, 1), (15, 14, 4), (1, 0, 15))
    chords = []
    for source, neighbour, partner in chord_indices:
        assert vectors[source] in TARGET_VECTORS
        assert pivot_graph.has_edge(source, neighbour)
        assert vectors[partner] in TARGET_VECTORS
        assert compatible(vectors[neighbour], vectors[partner])
        chords.append(
            {
                "source_vector": vectors[source],
                "neighbour_vector": vectors[neighbour],
                "partner_vector": vectors[partner],
                "removed": tuple(sorted(fibre[source] - fibre[neighbour])),
                "added": tuple(sorted(fibre[neighbour] - fibre[source])),
            }
        )

    pair_distances = {
        (i, j): min(
            nx.shortest_path_length(pivot_graph, source, target)
            for source in indices_by_vector[TARGET_VECTORS[i]]
            for target in indices_by_vector[TARGET_VECTORS[j]]
        )
        for i, j in combinations(range(3), 2)
    }

    box_vectors = tuple(vector for vector in vector_counts if max(vector) <= 2)
    assert set(box_vectors) == {
        (1, 2, 2, 2, 2),
        (2, 1, 2, 2, 2),
        (2, 2, 2, 2, 1),
    }

    print(
        {
            "graph6": GRAPH6,
            "root": ROOT,
            "port_split": ((SINGLETON_PORT,), (7, 8)),
            "full_fibre_forests": len(fibre),
            "distinct_degree_vectors": len(vector_counts),
            "same_x_pivot_edges": pivot_graph.number_of_edges(),
            "same_x_pivot_connected": nx.is_connected(pivot_graph),
            "target_vectors": TARGET_VECTORS,
            "target_vector_multiplicities": tuple(
                vector_counts[vector] for vector in TARGET_VECTORS
            ),
            "target_pair_pivot_distances": pair_distances,
            "target_forests": target_forests,
            "one_pivot_compatibility_chords": tuple(chords),
            "integral_box_vectors": box_vectors,
        }
    )
    print("ACTUAL_FULL_FIBRE_CONTAINS_SUPPORT_THREE_CYCLE_VERIFIED")


if __name__ == "__main__":
    main()
