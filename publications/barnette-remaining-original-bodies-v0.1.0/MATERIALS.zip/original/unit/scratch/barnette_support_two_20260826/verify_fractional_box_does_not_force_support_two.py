#!/usr/bin/env python3
"""Exact verifier for the minimum abstract support-two obstruction."""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations, product


def compatible(a: tuple[int, ...], b: tuple[int, ...]) -> bool:
    """Return whether the equal-weight pair has coordinatewise mean <= 0."""

    return all(x + y <= 0 for x, y in zip(a, b))


def valid_states(m: int) -> tuple[tuple[int, ...], ...]:
    return tuple(
        vector
        for vector in product((-1, 0, 1), repeat=m)
        if sum(vector) == -1
    )


def verify_minimality_through_three_coordinates() -> None:
    for m in range(1, 4):
        states = valid_states(m)
        positive_states = tuple(v for v in states if max(v) == 1)

        # A state without a positive coordinate is itself a support-one
        # certificate.  For m <= 2 there are no positive states at all.
        if m <= 2:
            assert not positive_states
            continue

        # At m=3 the only positive states are permutations of (1,-1,-1),
        # and every two distinct states form a compatible pair.  A family
        # containing only one of them cannot have a nonpositive average.
        assert set(positive_states) == {
            (1, -1, -1),
            (-1, 1, -1),
            (-1, -1, 1),
        }
        assert all(compatible(a, b) for a, b in combinations(positive_states, 2))
        for state in positive_states:
            assert any(value > 0 for value in state)


def verify_four_coordinate_obstruction() -> None:
    excess = (
        (-1, -1, 0, 1),
        (-1, 1, -1, 0),
        (-1, 0, 1, -1),
    )
    degrees = tuple(tuple(2 + value for value in vector) for vector in excess)

    assert all(vector in valid_states(4) for vector in excess)
    assert all(set(vector) <= {-1, 0, 1} and sum(vector) == -1 for vector in excess)
    assert degrees == (
        (1, 1, 2, 3),
        (1, 3, 1, 2),
        (1, 2, 3, 1),
    )
    assert all(sum(vector) == 7 for vector in degrees)

    # The unique box-feasible distribution has all three weights 1/3.
    weights = (Fraction(1, 3),) * 3
    average_excess = tuple(
        sum(weight * vector[index] for weight, vector in zip(weights, excess))
        for index in range(4)
    )
    average_degree = tuple(2 + value for value in average_excess)
    assert average_excess == (Fraction(-1), Fraction(0), Fraction(0), Fraction(0))
    assert average_degree == (Fraction(1), Fraction(2), Fraction(2), Fraction(2))

    # No repeated or distinct equal-weight pair is compatible.
    assert all(
        not compatible(excess[i], excess[j])
        for i in range(3)
        for j in range(i, 3)
    )

    # More strongly, any box-feasible convex distribution on these three
    # vectors has w2 <= w1 <=?  The cyclic inequalities force equality:
    # coordinate 2 gives w1 >= w2, coordinate 3 gives w2 >= w3,
    # and coordinate 4 gives w3 >= w1.
    # Check the resulting unique rational solution directly.
    w1, w2, w3 = weights
    assert w2 <= w1 and w3 <= w2 and w1 <= w3
    assert w1 == w2 == w3 == Fraction(1, 3)


def main() -> None:
    verify_minimality_through_three_coordinates()
    verify_four_coordinate_obstruction()
    print("FRACTIONAL_BOX_DOES_NOT_FORCE_SUPPORT_TWO_VERIFIED")


if __name__ == "__main__":
    main()
