#!/usr/bin/env python3
"""Targeted search for the boundary-chord lemma in the Heawood brace."""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations, permutations, product

import networkx as nx
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp


ROOT = 0
SINGLETON = 1
PAIRED = (5, 13)
ABSTRACT_TEMPLATE = (
    (-1, -1, -1, 0, 1, 1),
    (1, -1, -1, 1, 0, -1),
    (1, -1, 0, -1, -1, 1),
    (0, -1, 1, -1, 1, -1),
    (-1, -1, 1, 1, -1, 0),
)


def edge(a: int, b: int) -> tuple[int, int]:
    return (a, b) if a < b else (b, a)


def enumerate_fibre(graph: nx.Graph):
    colour = nx.bipartite.color(graph)
    y_full = tuple(sorted(v for v in graph if colour[v] == colour[ROOT]))
    x_side = tuple(sorted(set(graph) - set(y_full)))
    y_order = tuple(v for v in y_full if v != ROOT)
    ports = tuple(sorted(graph[ROOT]))
    pole_vertices = tuple(sorted(set(graph) - {ROOT}))
    pole = graph.subgraph(pole_vertices)

    choices = []
    for x in x_side:
        required = 1 if x in ports else 2
        incident = tuple(sorted(edge(x, y) for y in pole[x]))
        choices.append(
            tuple(frozenset(selected) for selected in combinations(incident, required))
        )

    fibre = []
    for local in product(*choices):
        selected = frozenset().union(*local)
        support = nx.Graph()
        support.add_nodes_from(pole_vertices)
        support.add_edges_from(selected)
        if not nx.is_forest(support) or nx.number_connected_components(support) != 2:
            continue
        blocks = sorted(
            (
                tuple(sorted(set(component) & set(ports)))
                for component in nx.connected_components(support)
            ),
            key=lambda block: (len(block), block),
        )
        if blocks == [(SINGLETON,), PAIRED]:
            fibre.append(selected)
    return x_side, y_order, tuple(fibre)


def degree_vector(forest, y_order):
    return tuple(sum(y in e for e in forest) for y in y_order)


def same_x_pivot(a, b, x_side):
    if len(a ^ b) != 2:
        return False
    removed = next(iter(a - b))
    added = next(iter(b - a))
    return next(v for v in removed if v in x_side) == next(
        v for v in added if v in x_side
    )


def compatible_degrees(a, b):
    return all(x + y <= 4 for x, y in zip(a, b))


def main() -> None:
    graph = nx.heawood_graph()
    x_side, y_order, fibre = enumerate_fibre(graph)
    vectors_by_forest = tuple(degree_vector(forest, y_order) for forest in fibre)
    vector_set = set(vectors_by_forest)
    excess_set = {tuple(value - 2 for value in vector) for vector in vector_set}
    print(
        {
            "graph6": nx.to_graph6_bytes(graph, header=False).decode().strip(),
            "root": ROOT,
            "ports": tuple(sorted(graph[ROOT])),
            "split": ((SINGLETON,), PAIRED),
            "y_order": y_order,
            "forests": len(fibre),
            "vectors": len(vector_set),
            "vector_multiplicities": Counter(vectors_by_forest),
        }
    )

    pivot = nx.Graph()
    pivot.add_nodes_from(range(len(fibre)))
    pivot.add_edges_from(
        (i, j)
        for i, j in combinations(range(len(fibre)), 2)
        if same_x_pivot(fibre[i], fibre[j], set(x_side))
    )
    print(
        {
            "pivot_edges": pivot.number_of_edges(),
            "pivot_components": tuple(
                sorted((len(component) for component in nx.connected_components(pivot)))
            ),
        }
    )

    template_hits = []
    for permutation in permutations(range(6)):
        permuted = tuple(
            tuple(vector[index] for index in permutation)
            for vector in ABSTRACT_TEMPLATE
        )
        if set(permuted) <= excess_set:
            template_hits.append((permutation, permuted))
    print({"template_hits": template_hits})

    indices_by_excess = defaultdict(list)
    for index, vector in enumerate(vectors_by_forest):
        indices_by_excess[tuple(value - 2 for value in vector)].append(index)

    actual_counterexamples = []
    for permutation, support in template_hits:
        bad_representatives = {}
        for vector in support:
            bad = []
            for forest_index in indices_by_excess[vector]:
                if not any(
                    compatible_degrees(vectors_by_forest[neighbour], tuple(2 + x for x in partner))
                    for neighbour in pivot.neighbors(forest_index)
                    for partner in support
                ):
                    bad.append(forest_index)
            bad_representatives[vector] = tuple(bad)
        if all(bad_representatives[vector] for vector in support):
            actual_counterexamples.append((permutation, support, bad_representatives))
    print({"actual_counterexamples": actual_counterexamples})

    # Search directly for any box-feasible forest support having neither a
    # compatible pair nor a one-pivot compatibility chord.  Such a support
    # contains an inclusion-minimal one with the same two negative properties.
    forest_count = len(fibre)
    variable_count = 2 * forest_count
    objective = np.zeros(variable_count)
    objective[forest_count:] = 1
    integrality = np.zeros(variable_count)
    integrality[forest_count:] = 1
    lower_bounds = np.zeros(variable_count)
    upper_bounds = np.ones(variable_count)
    rows = []
    lowers = []
    uppers = []

    # Convex weights sum to one and have nonpositive expected excess.
    row = np.zeros(variable_count)
    row[:forest_count] = 1
    rows.append(row)
    lowers.append(1)
    uppers.append(1)
    for coordinate in range(len(y_order)):
        row = np.zeros(variable_count)
        row[:forest_count] = [
            vector[coordinate] - 2 for vector in vectors_by_forest
        ]
        rows.append(row)
        lowers.append(-np.inf)
        uppers.append(0)

    # Positive weight requires selecting that forest.
    for index in range(forest_count):
        row = np.zeros(variable_count)
        row[index] = 1
        row[forest_count + index] = -1
        rows.append(row)
        lowers.append(-np.inf)
        uppers.append(0)

    forbidden_singletons = set()
    conflict_pairs = set()
    for source in range(forest_count):
        for partner in range(source, forest_count):
            direct = compatible_degrees(
                vectors_by_forest[source], vectors_by_forest[partner]
            )
            source_chord = any(
                compatible_degrees(vectors_by_forest[neighbour], vectors_by_forest[partner])
                for neighbour in pivot.neighbors(source)
            )
            partner_chord = any(
                compatible_degrees(vectors_by_forest[neighbour], vectors_by_forest[source])
                for neighbour in pivot.neighbors(partner)
            )
            if direct or source_chord or partner_chord:
                if source == partner:
                    forbidden_singletons.add(source)
                else:
                    conflict_pairs.add((source, partner))

    for index in forbidden_singletons:
        row = np.zeros(variable_count)
        row[forest_count + index] = 1
        rows.append(row)
        lowers.append(0)
        uppers.append(0)
    for first, second in conflict_pairs:
        row = np.zeros(variable_count)
        row[forest_count + first] = 1
        row[forest_count + second] = 1
        rows.append(row)
        lowers.append(-np.inf)
        uppers.append(1)

    result = milp(
        c=objective,
        integrality=integrality,
        bounds=Bounds(lower_bounds, upper_bounds),
        constraints=LinearConstraint(
            np.asarray(rows), np.asarray(lowers), np.asarray(uppers)
        ),
        options={"presolve": True},
    )
    if result.success:
        selected = tuple(
            index
            for index, value in enumerate(result.x[forest_count:])
            if value > 0.5
        )
        weights = tuple(result.x[index] for index in selected)
        print(
            {
                "direct_boundary_chord_counterexample": {
                    "forest_indices": selected,
                    "weights": weights,
                    "degree_vectors": tuple(vectors_by_forest[i] for i in selected),
                    "forests": tuple(tuple(sorted(fibre[i])) for i in selected),
                }
            }
        )
    else:
        print(
            {
                "direct_boundary_chord_counterexample": None,
                "milp_status": result.message,
            }
        )


if __name__ == "__main__":
    main()
