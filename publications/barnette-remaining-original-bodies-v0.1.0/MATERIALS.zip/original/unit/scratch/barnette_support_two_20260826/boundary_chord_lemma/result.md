# The actual boundary-chord lemma fails in the Heawood brace

## Counterexample

Let \(F\) be the Heawood graph

    MhEGHC@AI?_PC@_G_

with bipartition

\[
X=\{1,3,5,7,9,11,13\},\qquad
Y=\{0,2,4,6,8,10,12\}.
\]

Take root \(r=0\), ports \(N(r)=(1,5,13)\), and fixed port split

\[
\{1\}\mid\{5,13\}.
\]

The graph is simple, connected, cubic and bipartite. Exhaustive strict-Hall
checks on both colour sides give

\[
|N(U)|\ge |U|+2
\qquad
(1\le |U|\le5),
\]

so \(F\) is a brace.

In the coordinate order

\[
Y\setminus\{r\}=(2,4,6,8,10,12),
\]

the complete fixed fibre contains the following three forests:

\[
\begin{aligned}
A=\{&
12,23,27,34,49,56,6\,11,78,9\,10,11\,12,12\,13\},\\
B=\{&
12,23,34,56,67,6\,11,78,89,8\,13,9\,10,11\,12\},\\
C=\{&
1\,10,27,34,3\,12,45,49,6\,11,78,89,11\,12,12\,13\}.
\end{aligned}
\tag{1}
\]

Unspaced two-digit strings such as \(12\) denote the edge \(\{1,2\}\);
thin spaces separate endpoints when one endpoint has two digits.

Their degree and excess vectors are

\[
\begin{array}{c|c|c}
&d&e=d-2\mathbf1\\ \hline
A&(3,2,2,1,1,2)&(1,0,0,-1,-1,0)\\
B&(2,1,3,3,1,1)&(0,-1,1,1,-1,-1)\\
C&(1,3,1,2,1,3)&(-1,1,-1,0,-1,1).
\end{array}
\tag{2}
\]

Thus

\[
\frac13(e(A)+e(B)+e(C))=(0,0,0,0,-1,0)\le0.
\tag{3}
\]

The support \(\mathcal S=\{A,B,C\}\) is inclusion-minimal
box-feasible. Each singleton has a positive coordinate. For \(A,B\), the
first coordinate forces the weight of \(A\) to zero; for \(A,C\), the
second forces the weight of \(C\) to zero; for \(B,C\), the fourth forces
the weight of \(B\) to zero. The remaining singleton is still infeasible.

The six sums allowing repetition are

\[
\begin{array}{c|c}
AA&(2,0,0,-2,-2,0)\\
AB&(1,-1,1,0,-2,-1)\\
AC&(0,1,-1,-1,-2,1)\\
BB&(0,-2,2,2,-2,-2)\\
BC&(-1,0,0,1,-2,0)\\
CC&(-2,2,-2,0,-2,2).
\end{array}
\tag{4}
\]

Every row has a positive coordinate, so \(\mathcal S\) contains no
compatible pair.

## Exact pivot obstruction

For a same-\(X\) pivot

\[
J'=J-xz+xy
\]

the excess changes by

\[
e(J')=e(J)-\mathbf1_z+\mathbf1_y.
\tag{5}
\]

Consequently \(J'\) can become compatible with \(K\) only if
\(e(J)+e(K)\) has exactly one positive coordinate \(z\), that positive
value is one, and \(e(J)_y+e(K)_y\le-1\).

Equation (4) eliminates every ordered pair except \(B,C\). For that pair,

\[
e(B)+e(C)=(-1,0,0,1,-2,0),
\]

so a repairing pivot must transfer one degree unit from \(Y\)-vertex \(8\)
to \(2\) or \(10\). The graph incidence leaves exactly two directed
candidates:

\[
B-78+27,\qquad C-89+9\,10.
\tag{6}
\]

Both candidates remain two-component forests and retain every prescribed
\(X\)-degree. They fail precisely at the terminal partition:

\[
\begin{aligned}
B-78+27 &: \quad \{13\}\mid\{1,5\},\\
C-89+9\,10 &: \quad \varnothing\mid\{1,5,13\}.
\end{aligned}
\tag{7}
\]

This is the exact fundamental-cut barrier. In \(B-78\), the component
containing \(x=7\) already contains port \(5\), so attaching it through
\(27\) to the singleton component mixes port blocks. In \(C-89\), the
component containing \(x=9\) contains both paired ports, so attaching it
through \(9\,10\) to the singleton component leaves a port-free component.

The standalone verifier enumerates the entire fixed fibre: 112 forests.
Its same-\(X\) pivot graph has 256 edges and is connected. The support
forests have respectively \(4,4,6\) legal pivot neighbours; exhaustive
checking confirms that none is compatible with any member of
\(\mathcal S\).

Hence the boundary-chord lemma of Note 059 is false for an actual simple
cubic bipartite brace.

## Exact boundary

This counterexample does not refute support two. The full Heawood fibre
contains integral degree-box forests, even though the particular
inclusion-minimal support (2) has no boundary chord. It proves that
**arbitrary inclusion-minimality of a box-feasible support is not a
sufficient selection rule**.

Any surviving local-exchange proof must either:

1. choose a box-feasible distribution using an additional global
   extremality criterion that rules out the port barriers in (7);
2. permit a sequence of pivots through states not immediately compatible
   with the original support; or
3. use a partner outside the chosen minimal support.

Exact reproduction:

    python3 units/barnette/scratch/barnette_support_two_20260826/boundary_chord_lemma/verify_heawood_boundary_chord_counterexample.py

Terminal marker:

    HEAWOOD_BOUNDARY_CHORD_COUNTEREXAMPLE_VERIFIED
