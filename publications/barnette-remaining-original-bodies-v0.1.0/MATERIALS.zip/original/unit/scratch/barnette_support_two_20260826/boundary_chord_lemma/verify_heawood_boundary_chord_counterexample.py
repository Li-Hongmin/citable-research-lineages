#!/usr/bin/env python3
"""Exact actual-brace counterexample to the boundary-chord lemma."""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations, product

import networkx as nx


GRAPH6 = "MhEGHC@AI?_PC@_G_"
ROOT = 0
PORTS = (1, 5, 13)
SINGLETON = 1
PAIRED = (5, 13)
Y_ORDER = (2, 4, 6, 8, 10, 12)
Edge = tuple[int, int]
Forest = frozenset[Edge]
Vector = tuple[int, ...]

SUPPORT_FORESTS: tuple[Forest, ...] = (
    frozenset(
        (
            (1, 2), (2, 3), (2, 7), (3, 4), (4, 9), (5, 6),
            (6, 11), (7, 8), (9, 10), (11, 12), (12, 13),
        )
    ),
    frozenset(
        (
            (1, 2), (2, 3), (3, 4), (5, 6), (6, 7), (6, 11),
            (7, 8), (8, 9), (8, 13), (9, 10), (11, 12),
        )
    ),
    frozenset(
        (
            (1, 10), (2, 7), (3, 4), (3, 12), (4, 5), (4, 9),
            (6, 11), (7, 8), (8, 9), (11, 12), (12, 13),
        )
    ),
)

EXPECTED_DEGREES = (
    (3, 2, 2, 1, 1, 2),
    (2, 1, 3, 3, 1, 1),
    (1, 3, 1, 2, 1, 3),
)


def edge(a: int, b: int) -> Edge:
    return (a, b) if a < b else (b, a)


def strict_hall(graph: nx.Graph, side: tuple[int, ...]) -> bool:
    for size in range(1, len(side) - 1):
        for shore in combinations(side, size):
            neighbours = set().union(*(set(graph[x]) for x in shore))
            if len(neighbours) < size + 2:
                return False
    return True


def port_blocks(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    return tuple(
        sorted(
            (
                tuple(sorted(set(component) & set(PORTS)))
                for component in nx.connected_components(graph)
            ),
            key=lambda block: (len(block), block),
        )
    )


def enumerate_full_fibre(
    graph: nx.Graph,
    x_side: tuple[int, ...],
) -> tuple[Forest, ...]:
    pole_vertices = tuple(sorted(set(graph) - {ROOT}))
    pole = graph.subgraph(pole_vertices)
    choices = []
    for x in x_side:
        required = 1 if x in PORTS else 2
        incident = tuple(sorted(edge(x, y) for y in pole[x]))
        choices.append(
            tuple(frozenset(selected) for selected in combinations(incident, required))
        )

    fibre = []
    for local_selection in product(*choices):
        selected = frozenset().union(*local_selection)
        forest = nx.Graph()
        forest.add_nodes_from(pole_vertices)
        forest.add_edges_from(selected)
        if not nx.is_forest(forest):
            continue
        if nx.number_connected_components(forest) != 2:
            continue
        if port_blocks(forest) != ((SINGLETON,), PAIRED):
            continue
        fibre.append(selected)
    return tuple(fibre)


def degree_vector(forest: Forest) -> Vector:
    return tuple(sum(y in selected_edge for selected_edge in forest) for y in Y_ORDER)


def excess(vector: Vector) -> Vector:
    return tuple(value - 2 for value in vector)


def compatible(a: Vector, b: Vector) -> bool:
    return all(x + y <= 4 for x, y in zip(a, b))


def convex_pair_hits_box(a: Vector, b: Vector) -> bool:
    lower = Fraction(0)
    upper = Fraction(1)
    for a_value, b_value in zip(excess(a), excess(b)):
        difference = a_value - b_value
        if difference == 0:
            if b_value > 0:
                return False
        elif difference > 0:
            upper = min(upper, Fraction(-b_value, difference))
        else:
            lower = max(lower, Fraction(-b_value, difference))
    return lower <= upper


def same_x_pivot(a: Forest, b: Forest, x_side: set[int]) -> bool:
    if len(a ^ b) != 2:
        return False
    removed = next(iter(a - b))
    added = next(iter(b - a))
    removed_x = next(v for v in removed if v in x_side)
    added_x = next(v for v in added if v in x_side)
    return removed_x == added_x


def candidate_repair_transfers(
    source: Forest,
    partner: Forest,
    x_side: set[int],
) -> tuple[tuple[Edge, Edge], ...]:
    """List edgewise transfers capable of repairing source against partner."""

    source_excess = excess(degree_vector(source))
    partner_excess = excess(degree_vector(partner))
    pair_sum = tuple(a + b for a, b in zip(source_excess, partner_excess))
    positive = tuple(i for i, value in enumerate(pair_sum) if value > 0)
    if len(positive) != 1 or pair_sum[positive[0]] != 1:
        return ()
    removed_y = Y_ORDER[positive[0]]
    slack_y = {
        Y_ORDER[i] for i, value in enumerate(pair_sum) if value <= -1
    }

    graph = nx.from_graph6_bytes(GRAPH6.encode())
    pole_edges = {
        edge(a, b) for a, b in graph.edges() if ROOT not in (a, b)
    }
    candidates = []
    for removed in source:
        if removed_y not in removed:
            continue
        x = next(v for v in removed if v in x_side)
        for added in pole_edges - source:
            if x not in added:
                continue
            added_y = next(v for v in added if v not in x_side)
            if added_y in slack_y:
                candidates.append((removed, added))
    return tuple(sorted(candidates))


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert graph.number_of_nodes() == 14 and graph.number_of_edges() == 21
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert not nx.check_planarity(graph)[0]
    assert tuple(sorted(graph[ROOT])) == PORTS

    colour = nx.bipartite.color(graph)
    y_full = tuple(sorted(v for v in graph if colour[v] == colour[ROOT]))
    x_side = tuple(sorted(set(graph) - set(y_full)))
    assert y_full == (0, 2, 4, 6, 8, 10, 12)
    assert x_side == (1, 3, 5, 7, 9, 11, 13)
    assert strict_hall(graph, x_side) and strict_hall(graph, y_full)

    fibre = enumerate_full_fibre(graph, x_side)
    assert len(fibre) == len(set(fibre)) == 112
    assert all(forest in fibre for forest in SUPPORT_FORESTS)
    integral_box_vectors = {
        degree_vector(forest)
        for forest in fibre
        if max(degree_vector(forest)) <= 2
    }
    assert integral_box_vectors == {
        (2, 2, 2, 2, 2, 1),
        (2, 1, 2, 2, 2, 2),
        (2, 2, 2, 1, 2, 2),
        (2, 2, 1, 2, 2, 2),
    }

    support_degrees = tuple(degree_vector(forest) for forest in SUPPORT_FORESTS)
    assert support_degrees == EXPECTED_DEGREES
    support_excess = tuple(excess(vector) for vector in support_degrees)
    assert support_excess == (
        (1, 0, 0, -1, -1, 0),
        (0, -1, 1, 1, -1, -1),
        (-1, 1, -1, 0, -1, 1),
    )
    average = tuple(
        sum(Fraction(vector[i], 3) for vector in support_excess)
        for i in range(len(Y_ORDER))
    )
    assert average == (
        Fraction(0), Fraction(0), Fraction(0),
        Fraction(0), Fraction(-1), Fraction(0),
    )

    # No singleton or two-state subfamily reaches the box, so the displayed
    # three-state support is inclusion-minimal.
    assert all(max(vector) > 2 for vector in support_degrees)
    assert all(
        not convex_pair_hits_box(support_degrees[i], support_degrees[j])
        for i in range(3)
        for j in range(i, 3)
    )
    assert all(
        not compatible(support_degrees[i], support_degrees[j])
        for i in range(3)
        for j in range(i, 3)
    )

    pivot_graph = nx.Graph()
    pivot_graph.add_nodes_from(range(len(fibre)))
    pivot_graph.add_edges_from(
        (i, j)
        for i, j in combinations(range(len(fibre)), 2)
        if same_x_pivot(fibre[i], fibre[j], set(x_side))
    )
    assert nx.is_connected(pivot_graph)
    support_indices = tuple(fibre.index(forest) for forest in SUPPORT_FORESTS)
    assert support_indices == (0, 5, 103)
    assert tuple(pivot_graph.degree(index) for index in support_indices) == (4, 4, 6)

    # Exhaust every legal same-X pivot out of the three support forests.
    for source in support_indices:
        for neighbour in pivot_graph.neighbors(source):
            neighbour_degree = degree_vector(fibre[neighbour])
            assert all(
                not compatible(neighbour_degree, partner)
                for partner in support_degrees
            )

    # Algebraically, only the second/third pair is one unit from
    # compatibility.  The unique positive coordinate is Y=8; the two
    # possible same-X edge transfers to slack coordinates are frozen below.
    pair_sums = {
        (i, j): tuple(
            support_excess[i][coordinate] + support_excess[j][coordinate]
            for coordinate in range(len(Y_ORDER))
        )
        for i in range(3)
        for j in range(i, 3)
    }
    assert pair_sums[(1, 2)] == (-1, 0, 0, 1, -2, 0)
    assert all(
        (
            len([value for value in vector if value > 0]) != 1
            or max(vector) != 1
        )
        for pair, vector in pair_sums.items()
        if pair != (1, 2)
    )

    transfers_b_to_c = candidate_repair_transfers(
        SUPPORT_FORESTS[1], SUPPORT_FORESTS[2], set(x_side)
    )
    transfers_c_to_b = candidate_repair_transfers(
        SUPPORT_FORESTS[2], SUPPORT_FORESTS[1], set(x_side)
    )
    assert transfers_b_to_c == (((7, 8), (2, 7)),)
    assert transfers_c_to_b == (((8, 9), (9, 10)),)

    failed_port_blocks = []
    for source, transfer in (
        (SUPPORT_FORESTS[1], transfers_b_to_c[0]),
        (SUPPORT_FORESTS[2], transfers_c_to_b[0]),
    ):
        removed, added = transfer
        candidate = frozenset((source - {removed}) | {added})
        candidate_graph = nx.Graph()
        candidate_graph.add_nodes_from(set(graph) - {ROOT})
        candidate_graph.add_edges_from(candidate)
        assert nx.is_forest(candidate_graph)
        assert nx.number_connected_components(candidate_graph) == 2
        blocks = port_blocks(candidate_graph)
        assert blocks != ((SINGLETON,), PAIRED)
        failed_port_blocks.append(blocks)
    assert tuple(failed_port_blocks) == (
        ((13,), (1, 5)),
        ((), (1, 5, 13)),
    )

    print(
        {
            "graph": "HeawoodGraph",
            "graph6": GRAPH6,
            "root": ROOT,
            "port_split": ((SINGLETON,), PAIRED),
            "full_fibre_forests": len(fibre),
            "full_pivot_edges": pivot_graph.number_of_edges(),
            "support_indices": support_indices,
            "weights": ("1/3", "1/3", "1/3"),
            "degree_vectors": support_degrees,
            "expected_excess": tuple(str(value) for value in average),
            "support_pivot_degrees": tuple(
                pivot_graph.degree(index) for index in support_indices
            ),
            "candidate_repair_transfers": (
                transfers_b_to_c,
                transfers_c_to_b,
            ),
            "failed_port_blocks": tuple(failed_port_blocks),
            "integral_box_vectors": tuple(sorted(integral_box_vectors)),
            "boundary_chord": False,
        }
    )
    print("HEAWOOD_BOUNDARY_CHORD_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
