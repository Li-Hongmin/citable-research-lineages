#!/usr/bin/env python3
"""Enumerate minimal box-feasible supports and test the boundary chord."""

from __future__ import annotations

import importlib.util
from itertools import combinations
from pathlib import Path

import networkx as nx
import numpy as np
from scipy.optimize import linprog


HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "s2_actual_exchange_cycle" / "analyze_actual_exchange_cycle.py"
SPEC = importlib.util.spec_from_file_location("actual_cycle", SOURCE)
assert SPEC is not None and SPEC.loader is not None
CYCLE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CYCLE)


def feasible(vectors: tuple[tuple[int, ...], ...]) -> bool:
    if not vectors:
        return False
    matrix = np.asarray(
        [[coordinate - 2 for coordinate in vector] for vector in vectors],
        dtype=float,
    ).T
    result = linprog(
        np.zeros(len(vectors)),
        A_ub=matrix,
        b_ub=np.zeros(matrix.shape[0]),
        A_eq=np.ones((1, len(vectors))),
        b_eq=np.ones(1),
        bounds=(0, None),
        method="highs",
    )
    return result.success


def main() -> None:
    graph = nx.from_graph6_bytes(CYCLE.GRAPH6.encode())
    x_side, y_order, _, fibre = CYCLE.enumerate_fibre(graph)
    vectors_by_forest = tuple(CYCLE.degree_vector(forest, y_order) for forest in fibre)
    vectors = tuple(sorted(set(vectors_by_forest)))

    pivot = nx.Graph()
    pivot.add_nodes_from(range(len(fibre)))
    pivot.add_edges_from(
        (i, j)
        for i, j in combinations(range(len(fibre)), 2)
        if CYCLE.same_x_pivot(fibre[i], fibre[j], set(x_side))
    )

    forests_by_vector = {
        vector: tuple(i for i, candidate in enumerate(vectors_by_forest) if candidate == vector)
        for vector in vectors
    }
    minimal_supports = []
    no_pair_supports = []
    counterexamples = []
    for size in range(1, len(y_order) + 2):
        for support in combinations(vectors, size):
            if not feasible(support):
                continue
            if any(feasible(support[:i] + support[i + 1 :]) for i in range(size)):
                continue
            minimal_supports.append(support)
            if any(
                CYCLE.compatible(support[i], support[j])
                for i in range(size)
                for j in range(i, size)
            ):
                continue
            no_pair_supports.append(support)

            bad_representatives = {}
            for vector in support:
                bad = []
                for forest_index in forests_by_vector[vector]:
                    has_chord = any(
                        CYCLE.compatible(vectors_by_forest[neighbour], partner)
                        for neighbour in pivot.neighbors(forest_index)
                        for partner in support
                    )
                    if not has_chord:
                        bad.append(forest_index)
                bad_representatives[vector] = tuple(bad)

            if all(bad_representatives[vector] for vector in support):
                counterexamples.append((support, bad_representatives))

    print(
        {
            "full_fibre_forests": len(fibre),
            "distinct_vectors": len(vectors),
            "minimal_box_feasible_supports": len(minimal_supports),
            "minimal_no_pair_supports": len(no_pair_supports),
            "boundary_chord_counterexamples": counterexamples,
            "minimal_no_pair_support_vectors": no_pair_supports,
        }
    )


if __name__ == "__main__":
    main()
