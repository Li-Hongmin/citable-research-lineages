#!/usr/bin/env python3
"""Profile neutral-gate multiplicities at every order-24 wide site."""

from __future__ import annotations

from collections import Counter
import argparse
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
SOURCE_DIR = UNIT / "scratch" / "existence_lifting_order24_20260826_codex"
SOURCE_JSON = SOURCE_DIR / "complete_family_existence_order24_rerun.json"
SOURCE_SCRIPT = SOURCE_DIR / "census_complete_family_existence_order24.py"


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


source = load_module(SOURCE_SCRIPT, "order24_wide_escape_source")
lift = source.lift_bundle
edge = source.edge


def profile() -> dict[str, object]:
    accepted = json.loads(SOURCE_JSON.read_text())
    totals = Counter()
    neutral_histogram = Counter()
    gate_histogram = Counter()
    family_neutral_histogram = Counter()
    closest_by_count = None
    closest_by_fraction = None

    for source_graph6 in accepted["brace_graph6"]:
        primal = nx.from_graph6_bytes(source_graph6.encode())
        planar, embedding = nx.check_planarity(primal)
        assert planar and isinstance(embedding, nx.PlanarEmbedding)
        primal_faces = source.source_bundle.plane_faces(primal, embedding)
        reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
        reduced_faces = lift.verify_reduced_triangulation(reduced)
        families, _, _ = lift.target_families(reduced, reduced_faces)
        vertices = tuple(sorted(reduced))
        dual_to_primal = source.primal_edge_by_dual_edge(primal, primal_faces)
        cache = {}
        for root, encoded_family in families.items():
            colours = tuple(
                lift.decode_colouring(vertices, encoded) for encoded in encoded_family
            )
            matchings = tuple(
                source.matching_from_colour(
                    primal, reduced, dual_to_primal, colour
                )
                for colour in colours
            )
            cache[root] = matchings

        for z in sorted(reduced):
            rotation = rotations[z]
            for i, j, first_gate, second_gate in lift.gate_pairs(rotation):
                left_size = j - i + 1
                right_size = len(rotation) - (j - i) + 1
                if left_size % 2 == 0 or right_size % 2 == 0:
                    continue
                if left_size < 5 or right_size < 5:
                    continue
                expanded, _, _, _ = lift.split_vertex(reduced, z, rotation, i, j)
                if lift.expanded_triangulation_faces(expanded) is None:
                    continue
                totals["legal_wide_splits"] += 1
                gates = (
                    dual_to_primal[edge(z, first_gate)],
                    dual_to_primal[edge(z, second_gate)],
                )
                for root, matchings in cache.items():
                    if z in root:
                        continue
                    counts = tuple(
                        sum(gate in matching for gate in gates)
                        for matching in matchings
                    )
                    by_gate = Counter(counts)
                    neutral = by_gate[0] + by_gate[1]
                    totals["wide_interfaces"] += 1
                    totals["wide_target_instances"] += len(matchings)
                    totals["wide_neutral_target_instances"] += neutral
                    totals["wide_double_gate_target_instances"] += by_gate[2]
                    totals[
                        "wide_interfaces_with_odd_neutral_count"
                        if neutral % 2
                        else "wide_interfaces_with_even_neutral_count"
                    ] += 1
                    if neutral == 1:
                        totals["wide_interfaces_with_one_neutral_target"] += 1
                    neutral_histogram[neutral] += 1
                    gate_histogram[str((by_gate[0], by_gate[1], by_gate[2]))] += 1
                    family_neutral_histogram[str((len(matchings), neutral))] += 1
                    record = {
                            "source_graph6": source_graph6,
                            "split_vertex": z,
                            "rotation": rotation,
                            "gate_indices": (i, j),
                            "gate_vertices": (first_gate, second_gate),
                            "closed_arc_cardinalities": (left_size, right_size),
                            "dual_root": root,
                            "family_size": len(matchings),
                            "gate_count_histogram": {
                                str(key): value for key, value in sorted(by_gate.items())
                            },
                            "neutral_target_count": neutral,
                    }
                    count_score = (neutral, neutral / len(matchings), len(matchings))
                    fraction_score = (neutral / len(matchings), neutral, len(matchings))
                    if by_gate[2] and (
                        closest_by_count is None
                        or count_score < tuple(closest_by_count["score"])
                    ):
                        closest_by_count = {"score": count_score, **record}
                    if by_gate[2] and (
                        closest_by_fraction is None
                        or fraction_score < tuple(closest_by_fraction["score"])
                    ):
                        closest_by_fraction = {"score": fraction_score, **record}

    assert totals["wide_interfaces"] == sum(neutral_histogram.values())
    assert 0 not in neutral_histogram
    return {
        "scope": {
            "order": 24,
            "plane_braces": len(accepted["brace_graph6"]),
            "wide": "both closed gate arcs have cardinality at least five",
        },
        "counts": dict(sorted(totals.items())),
        "neutral_target_count_histogram": {
            str(key): value for key, value in sorted(neutral_histogram.items())
        },
        "family_size_neutral_count_histogram": dict(
            sorted(family_neutral_histogram.items())
        ),
        "gate_count_histogram_by_family": dict(sorted(gate_histogram.items())),
        "closest_by_neutral_count_among_mixed_families": closest_by_count,
        "closest_by_neutral_fraction_among_mixed_families": closest_by_fraction,
        "all_neutral_counts_even": all(key % 2 == 0 for key in neutral_histogram),
        "status": "all_order24_wide_families_have_neutral_targets",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    payload = profile()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(rendered)
    print(json.dumps(payload["counts"], sort_keys=True))
    print(json.dumps(payload["neutral_target_count_histogram"], sort_keys=True))
    print(json.dumps(payload["closest_by_neutral_count_among_mixed_families"], sort_keys=True))
    print(json.dumps(payload["closest_by_neutral_fraction_among_mixed_families"], sort_keys=True))
    print("all_neutral_counts_even", payload["all_neutral_counts_even"])


if __name__ == "__main__":
    main()
