#!/usr/bin/env python3
"""Find the smallest real nonlocked target colouring with no local target lift."""

from __future__ import annotations

import argparse
from collections import Counter
import importlib.util
from itertools import product
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
UNIT_DIR = Path(__file__).resolve().parents[2]
LIFT_DRIVER = (
    UNIT_DIR
    / "computations"
    / "bundles"
    / "locked-boundary-escape-through18"
    / "census_locked_escape_through18.py"
)
THROUGH18_CERTIFICATE = (
    UNIT_DIR
    / "computations"
    / "bundles"
    / "locked-boundary-escape-through18"
    / "locked_escape_census.json"
)
ORDER20_CERTIFICATE = (
    UNIT_DIR
    / "scratch"
    / "c4_lifting_counterexample_20260826"
    / "c4_lifting_order20_census.json"
)


def load_lift_driver():
    specification = importlib.util.spec_from_file_location(
        "barnette_locked_escape_driver", LIFT_DRIVER
    )
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


lift = load_lift_driver()


def alternating(arc: tuple[int, ...], colour: dict[int, int]) -> bool:
    return all(colour[first] != colour[second] for first, second in zip(arc, arc[1:]))


def colouring_record(colour: dict[int, int]) -> dict[str, list[int]]:
    return {
        "zero_vertices": sorted(vertex for vertex, value in colour.items() if value == 0),
        "one_vertices": sorted(vertex for vertex, value in colour.items() if value == 1),
    }


def source_corpus() -> list[tuple[int, str]]:
    through18 = json.loads(THROUGH18_CERTIFICATE.read_text())
    records = [
        (int(record["source_order"]), str(record["source_graph6"]))
        for record in through18["by_source_graph"]
    ]
    order20 = json.loads(ORDER20_CERTIFICATE.read_text())
    assert order20["source_counts"]["plane_braces"] == 5
    records.extend((20, str(graph6)) for graph6 in order20["brace_graph6"])
    assert [order for order, _graph6 in records] == [8, 12, 16, 16, 18, 20, 20, 20, 20, 20]
    return records


def target_extension_record(
    reduced_colour: dict[int, int],
    z: int,
    gates: tuple[int, int],
    arcs: tuple[tuple[int, ...], tuple[int, ...]],
    expanded: nx.Graph,
    expanded_faces: tuple[tuple[int, ...], ...],
    locals_: tuple[int, int, int],
    root: tuple[int, int],
) -> dict[str, object]:
    gate_usage = tuple(reduced_colour[gate] == reduced_colour[z] for gate in gates)
    arc_type = tuple(int(alternating(arc, reduced_colour)) for arc in arcs)
    locked = all(gate_usage) and arc_type == (0, 0)
    fixed = {
        vertex: value for vertex, value in reduced_colour.items() if vertex != z
    }
    assignments = []
    successful_rows = []
    for bits in product((0, 1), repeat=3):
        colour = {**fixed, **dict(zip(locals_, bits, strict=True))}
        profile = lift.rooted_profile(expanded, expanded_faces, colour, root)
        target = lift.is_target_profile(profile)
        relative = tuple(bit ^ reduced_colour[z] for bit in bits)
        row = "".join(map(str, relative))
        if target:
            successful_rows.append(row)
        assignments.append(
            {
                "absolute_left_right_centre": bits,
                "relative_lambda_rho_d": row,
                "nae": profile[0],
                "components": profile[1],
                "cycle_rank": profile[2],
                "root_on_cycle": profile[3],
                "target": target,
            }
        )
    return {
        **colouring_record(reduced_colour),
        "gate_usage": gate_usage,
        "arc_type": arc_type,
        "locked": locked,
        "successful_relative_rows": successful_rows,
        "target_lift_count": len(successful_rows),
        "assignments": assignments,
    }


def search() -> dict[str, object]:
    counters = Counter(
        braces_started=0,
        admissible_splits=0,
        root_interfaces=0,
        reduced_target_instances=0,
        locked_target_instances=0,
        nonlocked_target_instances=0,
        nonlocked_target_instances_with_lift=0,
        nonlocked_target_instances_without_lift=0,
        local_assignments_tested=0,
    )
    first_failure = None

    for order, graph6 in source_corpus():
        counters["braces_started"] += 1
        primal = nx.from_graph6_bytes(graph6.encode())
        planar, embedding = nx.check_planarity(primal, counterexample=True)
        assert planar and isinstance(embedding, nx.PlanarEmbedding)
        primal_faces = lift.plane_faces(primal)
        reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
        reduced_faces = lift.verify_reduced_triangulation(reduced)
        families, _nae_count, _target_shape_count = lift.target_families(
            reduced, reduced_faces
        )
        reduced_vertices = tuple(sorted(reduced))

        for z in sorted(reduced):
            rotation = rotations[z]
            for first_index, second_index, first_gate, second_gate in lift.gate_pairs(
                rotation
            ):
                left_size = second_index - first_index + 1
                right_size = len(rotation) - (second_index - first_index) + 1
                if left_size % 2 == 0 or right_size % 2 == 0:
                    continue
                expanded, locals_, left_arc, right_arc = lift.split_vertex(
                    reduced, z, rotation, first_index, second_index
                )
                expanded_faces = lift.expanded_triangulation_faces(expanded)
                if expanded_faces is None:
                    continue
                counters["admissible_splits"] += 1

                surviving_roots = tuple(
                    sorted(
                        root
                        for root in (lift.edge(*item) for item in reduced.edges())
                        if z not in root
                    )
                )
                for root in surviving_roots:
                    family = families.get(root, [])
                    if not family:
                        continue
                    counters["root_interfaces"] += 1
                    family_records = []
                    failed_indices = []
                    for target_index, encoded in enumerate(family):
                        reduced_colour = lift.decode_colouring(reduced_vertices, encoded)
                        record = target_extension_record(
                            reduced_colour,
                            z,
                            (first_gate, second_gate),
                            (left_arc, right_arc),
                            expanded,
                            expanded_faces,
                            locals_,
                            root,
                        )
                        family_records.append(record)
                        counters["reduced_target_instances"] += 1
                        counters["local_assignments_tested"] += 8
                        if record["locked"]:
                            counters["locked_target_instances"] += 1
                        else:
                            counters["nonlocked_target_instances"] += 1
                            if record["target_lift_count"]:
                                counters["nonlocked_target_instances_with_lift"] += 1
                            else:
                                counters["nonlocked_target_instances_without_lift"] += 1
                                failed_indices.append(target_index)

                    if not failed_indices:
                        continue

                    expanded_dual = lift.dual_from_plane_graph(expanded, expanded_faces)
                    reduced_brace_check = lift.verify_brace(primal)
                    expanded_brace_check = lift.verify_brace(expanded_dual)
                    expanded_target_count, expanded_first_target = (
                        lift.enumerate_expanded_root_targets(
                            expanded, expanded_faces, root
                        )
                    )
                    first_failure = {
                        "minimality": {
                            "reduced_primal_order": order,
                            "smaller_orders_excluded_by_complete_corpus": sorted(
                                {item_order for item_order, _ in source_corpus() if item_order < order}
                            ),
                        },
                        "source_graph6": graph6,
                        "reduced_brace_check": reduced_brace_check,
                        "expanded_dual_graph6": nx.to_graph6_bytes(
                            expanded_dual, header=False
                        ).decode().strip(),
                        "expanded_brace_check": expanded_brace_check,
                        "reduced_triangulation_edges": sorted(
                            lift.edge(*item) for item in reduced.edges()
                        ),
                        "expanded_triangulation_edges": sorted(
                            lift.edge(*item) for item in expanded.edges()
                        ),
                        "site": {
                            "split_vertex": z,
                            "rotation": rotation,
                            "gate_indices": (first_index, second_index),
                            "gates": (first_gate, second_gate),
                            "left_arc": left_arc,
                            "right_arc": right_arc,
                            "left_right_centre": locals_,
                        },
                        "root": root,
                        "complete_reduced_target_family_size": len(family_records),
                        "failed_nonlocked_target_indices": failed_indices,
                        "complete_reduced_target_family": family_records,
                        "expanded_rooted_target_count_mod_complement": expanded_target_count,
                        "expanded_first_rooted_target": expanded_first_target,
                    }
                    break
                if first_failure is not None:
                    break
            if first_failure is not None:
                break
        print(
            json.dumps(
                {
                    "completed_reduced_order": order,
                    "source_graph6": graph6,
                    "counters": dict(counters),
                    "failure_found": first_failure is not None,
                },
                sort_keys=True,
            ),
            flush=True,
        )
        if first_failure is not None:
            break

    if first_failure is None:
        conclusion = {
            "status": "no_counterexample_through_20",
            "statement": (
                "Every nonlocked reduced target in the complete through-order-20 corpus "
                "has a local target lift."
            ),
            "boundary": "This finite result neither proves nor strictly reduces the general proposition.",
        }
    else:
        conclusion = {
            "status": "real_brace_counterexample",
            "statement": (
                "The general proposition is false: the explicit nonlocked reduced target "
                "has no target lift under any of the eight local assignments."
            ),
            "boundary": (
                "This is a witness-by-witness counterexample only; the same interface may "
                "contain another liftable target, so existence-level family selection is not refuted."
            ),
        }

    return {
        "trusted_corpus": {
            "orders": [8, 12, 16, 16, 18, 20, 20, 20, 20, 20],
            "brace_graphs": 10,
            "sources": [str(THROUGH18_CERTIFICATE), str(ORDER20_CERTIFICATE)],
        },
        "coverage_until_stop": dict(counters),
        "first_failure": first_failure,
        "conclusion": conclusion,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    payload = search()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
        print("certificate", arguments.output)
    print(json.dumps(payload["coverage_until_stop"], sort_keys=True))
    print(json.dumps(payload["conclusion"], sort_keys=True))
    if payload["first_failure"] is None:
        print("NONLOCKED_WITNESS_LIFT_NO_FAILURE_THROUGH_20")
    else:
        print("NONLOCKED_WITNESS_LIFT_REAL_BRACE_COUNTEREXAMPLE")


if __name__ == "__main__":
    main()
