#!/usr/bin/env python3
"""Test laminarity and pointwise liftability in forced-gate components.

The input is exactly the existing through-order-22 corpus: connected simple
cubic bipartite graph representatives from ``geng``.  Graphs are streamed;
only aggregate counts and the first (least-order) non-laminar witness are
retained.
"""

from __future__ import annotations

from collections import Counter
from itertools import product
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from typing import Iterator

import networkx as nx


Edge = tuple[int, int]
Matching = frozenset[Edge]

EXPECTED_GENERATED = {
    6: 1,
    8: 1,
    10: 2,
    12: 5,
    14: 13,
    16: 38,
    18: 149,
    20: 703,
    22: 4132,
}
EXPECTED_FORCED_THROUGH20 = (340, 620)
EXPECTED_FORCED_ORDER22 = (266, 668)

sys.dont_write_bytecode = True
BARNETTE_DIR = Path(__file__).resolve().parents[2]
ORDER22_DRIVER = (
    BARNETTE_DIR
    / "computations"
    / "bundles"
    / "target-component-saturation-order22"
    / "census_forced_target_components_order22.py"
)


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


bundle = load_module(ORDER22_DRIVER, "forced_gate_shore_source")
source_bundle = bundle.source_bundle
lift_bundle = bundle.lift_bundle


def edge(first: int, second: int) -> Edge:
    return (first, second) if first < second else (second, first)


def generated_graphs(order: int) -> Iterator[tuple[str, nx.Graph]]:
    process = subprocess.Popen(
        ("geng", "-cqb", "-d3", "-D3", str(order)),
        stdout=subprocess.PIPE,
        text=True,
    )
    assert process.stdout is not None
    completed = False
    try:
        for line in process.stdout:
            source_graph6 = line.strip()
            if source_graph6:
                yield source_graph6, nx.from_graph6_bytes(source_graph6.encode())
        assert process.wait() == 0
        completed = True
    finally:
        if not completed and process.poll() is None:
            process.terminate()
            process.wait()


def graph6(graph: nx.Graph) -> str:
    return nx.to_graph6_bytes(graph, header=False).decode().strip()


def normalized_row(bits: tuple[int, int, int], base: int) -> str:
    return "".join(str(bit ^ base) for bit in bits)


def lift_rows(
    colour: dict[int, int],
    z: int,
    locals_: tuple[int, int, int],
    expanded: nx.Graph,
    expanded_faces: tuple[tuple[int, ...], ...],
    root: Edge,
) -> tuple[str, ...]:
    fixed = {vertex: value for vertex, value in colour.items() if vertex != z}
    rows: list[str] = []
    for bits in product((0, 1), repeat=3):
        lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
        profile = lift_bundle.rooted_profile(expanded, expanded_faces, lifted, root)
        if lift_bundle.is_target_profile(profile):
            rows.append(normalized_row(bits, colour[z]))
    return tuple(sorted(rows))


def shore_for_edge(
    first: int,
    second: int,
    z: int,
    gate_vertices: tuple[int, int],
    root: Edge,
    reduced: nx.Graph,
    colours: tuple[dict[int, int], ...],
    matchings: tuple[Matching, ...],
    dual_to_primal: dict[Edge, Edge],
) -> frozenset[int]:
    difference = {
        vertex
        for vertex in reduced
        if colours[first][vertex] != colours[second][vertex]
    }
    shore = frozenset(set(reduced) - difference if z in difference else difference)
    assert shore and z not in shore and set(shore) != set(reduced)
    assert not (set(gate_vertices) & shore)
    assert not (set(root) & shore)

    cut = frozenset(
        edge(u, v)
        for u, v in reduced.edges()
        if (u in shore) != (v in shore)
    )
    assert cut
    assert frozenset(dual_to_primal[item] for item in cut) == (
        matchings[first] ^ matchings[second]
    )
    complement = set(reduced) - set(shore)
    assert nx.is_connected(reduced.subgraph(shore))
    assert nx.is_connected(reduced.subgraph(complement))
    return shore


def shores_cross(first: frozenset[int], second: frozenset[int]) -> bool:
    return bool(first & second and first - second and second - first)


def target_record(
    index: int,
    colours: tuple[dict[int, int], ...],
    matchings: tuple[Matching, ...],
    gate_edges: tuple[Edge, Edge],
    rows_by_target: dict[int, tuple[str, ...]],
    adjacency: nx.Graph,
) -> dict[str, object]:
    colour = colours[index]
    return {
        "family_index": index,
        "zero_vertices": sorted(v for v, value in colour.items() if value == 0),
        "one_vertices": sorted(v for v, value in colour.items() if value == 1),
        "matching": sorted(matchings[index]),
        "gate_count": sum(gate in matchings[index] for gate in gate_edges),
        "lift_rows_normalized": rows_by_target[index],
        "liftable": bool(rows_by_target[index]),
        "target_graph_neighbours": sorted(adjacency[index]),
    }


def freeze_crossing(
    *,
    order: int,
    source_graph6: str,
    primal: nx.Graph,
    primal_faces: tuple[tuple[int, ...], ...],
    reduced: nx.Graph,
    reduced_faces: tuple[tuple[int, ...], ...],
    expanded: nx.Graph,
    expanded_faces: tuple[tuple[int, ...], ...],
    z: int,
    rotation: tuple[int, ...],
    gate_indices: tuple[int, int],
    gate_vertices: tuple[int, int],
    gate_edges: tuple[Edge, Edge],
    arcs: tuple[tuple[int, ...], tuple[int, ...]],
    locals_: tuple[int, int, int],
    root: Edge,
    primal_root: Edge,
    component: set[int],
    colours: tuple[dict[int, int], ...],
    matchings: tuple[Matching, ...],
    rows_by_target: dict[int, tuple[str, ...]],
    adjacency: nx.Graph,
    first_edge: tuple[int, int],
    first_shore: frozenset[int],
    second_edge: tuple[int, int],
    second_shore: frozenset[int],
) -> dict[str, object]:
    intersection = first_shore & second_shore
    first_only = first_shore - second_shore
    second_only = second_shore - first_shore
    outside = set(reduced) - (first_shore | second_shore)
    assert intersection and first_only and second_only and z in outside

    expanded_dual = lift_bundle.dual_from_plane_graph(expanded, expanded_faces)
    source_brace_check = lift_bundle.verify_brace(primal)
    expanded_brace_check = lift_bundle.verify_brace(expanded_dual)
    dual_to_primal = bundle.primal_edge_by_dual_edge(primal, primal_faces)

    def bond_record(
        target_edge: tuple[int, int], shore: frozenset[int]
    ) -> dict[str, object]:
        cut = frozenset(
            edge(u, v)
            for u, v in reduced.edges()
            if (u in shore) != (v in shore)
        )
        primal_cycle = matchings[target_edge[0]] ^ matchings[target_edge[1]]
        assert frozenset(dual_to_primal[item] for item in cut) == primal_cycle
        return {
            "target_edge": target_edge,
            "z_free_shore": sorted(shore),
            "dual_bond_edges": sorted(cut),
            "primal_alternating_cycle_edges": sorted(primal_cycle),
            "shore_connected": nx.is_connected(reduced.subgraph(shore)),
            "complement_connected": nx.is_connected(
                reduced.subgraph(set(reduced) - set(shore))
            ),
        }

    return {
        "witness_kind": "shared_plane_brace_forced_component_with_crossing_bond_shores",
        "shared_brace_realizability": True,
        "meaning": (
            "Both target-state edges, both shores, and all endpoint states occur "
            "in one forced-gate component of one legal split of one plane brace."
        ),
        "source_order": order,
        "source_graph6": source_graph6,
        "source_primal_edges": sorted(edge(*item) for item in primal.edges()),
        "source_primal_faces": primal_faces,
        "source_primal_brace_check": source_brace_check,
        "reduced_triangulation_graph6": graph6(reduced),
        "reduced_triangulation_edges": sorted(edge(*item) for item in reduced.edges()),
        "reduced_triangulation_faces": reduced_faces,
        "expanded_triangulation_graph6": graph6(expanded),
        "expanded_triangulation_edges": sorted(edge(*item) for item in expanded.edges()),
        "expanded_triangulation_faces": expanded_faces,
        "expanded_dual_graph6": graph6(expanded_dual),
        "expanded_dual_brace_check": expanded_brace_check,
        "site": {
            "split_vertex": z,
            "rotation": rotation,
            "gate_indices": gate_indices,
            "gate_vertices": gate_vertices,
            "primal_gate_edges": gate_edges,
            "left_arc": arcs[0],
            "right_arc": arcs[1],
            "left_right_centre": locals_,
        },
        "dual_root": root,
        "primal_root": primal_root,
        "complete_target_family_size_mod_complement": len(matchings),
        "forced_component_family_indices": sorted(component),
        "forced_component_targets": [
            target_record(
                index,
                colours,
                matchings,
                gate_edges,
                rows_by_target,
                adjacency,
            )
            for index in sorted(component)
        ],
        "forced_component_target_graph_edges": sorted(
            (min(u, v), max(u, v))
            for u, v in adjacency.subgraph(component).edges()
        ),
        "crossing_target_edges": (first_edge, second_edge),
        "crossing_shores": (sorted(first_shore), sorted(second_shore)),
        "crossing_bond_records": (
            bond_record(first_edge, first_shore),
            bond_record(second_edge, second_shore),
        ),
        "four_nonempty_regions": {
            "intersection": sorted(intersection),
            "first_only": sorted(first_only),
            "second_only": sorted(second_only),
            "outside_union": sorted(outside),
        },
    }


def analyse_brace(
    *,
    order: int,
    source_graph6: str,
    primal: nx.Graph,
    primal_faces: tuple[tuple[int, ...], ...],
    counts: Counter,
    first_crossing: dict[str, object] | None,
) -> dict[str, object] | None:
    reduced, rotations = lift_bundle.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift_bundle.verify_reduced_triangulation(reduced)
    families, _nae_count, _target_shape_count = lift_bundle.target_families(
        reduced, reduced_faces
    )
    reduced_vertices = tuple(sorted(reduced))
    dual_to_primal = bundle.primal_edge_by_dual_edge(primal, primal_faces)

    family_cache: dict[
        Edge,
        tuple[tuple[dict[int, int], ...], tuple[Matching, ...], nx.Graph],
    ] = {}
    for root, encoded_family in families.items():
        colours = tuple(
            lift_bundle.decode_colouring(reduced_vertices, encoded)
            for encoded in encoded_family
        )
        matchings = tuple(
            bundle.matching_from_colour(primal, reduced, dual_to_primal, colour)
            for colour in colours
        )
        adjacency = bundle.target_graph(matchings)
        family_cache[root] = colours, matchings, adjacency

    for z in sorted(reduced):
        rotation = rotations[z]
        for first_index, second_index, first_gate, second_gate in lift_bundle.gate_pairs(
            rotation
        ):
            left_size = second_index - first_index + 1
            right_size = len(rotation) - (second_index - first_index) + 1
            if left_size % 2 == 0 or right_size % 2 == 0:
                continue
            expanded, locals_, left_arc, right_arc = lift_bundle.split_vertex(
                reduced, z, rotation, first_index, second_index
            )
            expanded_faces = lift_bundle.expanded_triangulation_faces(expanded)
            if expanded_faces is None:
                continue

            gate_vertices = (first_gate, second_gate)
            gate_edges = (
                dual_to_primal[edge(z, first_gate)],
                dual_to_primal[edge(z, second_gate)],
            )
            for root in sorted(families):
                if z in root:
                    continue
                colours, matchings, adjacency = family_cache[root]
                primal_root = dual_to_primal[root]
                gate_counts = tuple(
                    sum(gate in matching for gate in gate_edges)
                    for matching in matchings
                )
                for component_raw in nx.connected_components(adjacency):
                    component = set(component_raw)
                    if not all(gate_counts[index] == 2 for index in component):
                        continue

                    counts["forced_components"] += 1
                    counts["forced_targets"] += len(component)
                    component_edges = tuple(
                        sorted(
                            (min(u, v), max(u, v))
                            for u, v in adjacency.subgraph(component).edges()
                        )
                    )
                    counts["forced_target_state_edges"] += len(component_edges)

                    rows_by_target = {
                        index: lift_rows(
                            colours[index],
                            z,
                            locals_,
                            expanded,
                            expanded_faces,
                            root,
                        )
                        for index in sorted(component)
                    }
                    good = {index for index, rows in rows_by_target.items() if rows}
                    bad = component - good
                    counts["liftable_forced_targets"] += len(good)
                    counts["nonliftable_forced_targets"] += len(bad)
                    if bad:
                        counts["forced_components_with_nonliftable_target"] += 1
                    else:
                        counts["forced_components_all_targets_liftable"] += 1

                    shore_records: list[tuple[tuple[int, int], frozenset[int]]] = []
                    component_crossing = False
                    for target_edge in component_edges:
                        shore = shore_for_edge(
                            *target_edge,
                            z,
                            gate_vertices,
                            root,
                            reduced,
                            colours,
                            matchings,
                            dual_to_primal,
                        )
                        for previous_edge, previous_shore in shore_records:
                            if not shores_cross(previous_shore, shore):
                                continue
                            component_crossing = True
                            if first_crossing is None:
                                first_crossing = freeze_crossing(
                                    order=order,
                                    source_graph6=source_graph6,
                                    primal=primal,
                                    primal_faces=primal_faces,
                                    reduced=reduced,
                                    reduced_faces=reduced_faces,
                                    expanded=expanded,
                                    expanded_faces=expanded_faces,
                                    z=z,
                                    rotation=rotation,
                                    gate_indices=(first_index, second_index),
                                    gate_vertices=gate_vertices,
                                    gate_edges=gate_edges,
                                    arcs=(left_arc, right_arc),
                                    locals_=locals_,
                                    root=root,
                                    primal_root=primal_root,
                                    component=component,
                                    colours=colours,
                                    matchings=matchings,
                                    rows_by_target=rows_by_target,
                                    adjacency=adjacency,
                                    first_edge=previous_edge,
                                    first_shore=previous_shore,
                                    second_edge=target_edge,
                                    second_shore=shore,
                                )
                        shore_records.append((target_edge, shore))

                    if component_crossing:
                        counts["forced_components_nonlaminar_shores"] += 1
                    else:
                        counts["forced_components_laminar_shores"] += 1

                    if bad:
                        for index in sorted(bad):
                            incident = [
                                (neighbour, shore)
                                for (u, v), shore in shore_records
                                for neighbour in (
                                    (v,) if u == index else (u,) if v == index else ()
                                )
                            ]
                            minimal = [
                                (neighbour, shore)
                                for neighbour, shore in incident
                                if not any(
                                    other < shore
                                    for _other_neighbour, other in incident
                                )
                            ]
                            if all(neighbour in good for neighbour, _shore in minimal):
                                counts[
                                    "nonliftable_targets_all_inclusion_minimal_incident_shores_reach_liftable"
                                ] += 1
                            else:
                                counts[
                                    "nonliftable_targets_with_bad_inclusion_minimal_incident_transition"
                                ] += 1

    return first_crossing


def census() -> dict[str, object]:
    counts_by_order: dict[str, dict[str, int]] = {}
    source_counts_by_order: dict[str, dict[str, int]] = {}
    first_crossing: dict[str, object] | None = None

    for order in EXPECTED_GENERATED:
        counts: Counter = Counter()
        sources: Counter = Counter()
        stream = generated_graphs(order)
        try:
            for source_graph6, primal in stream:
                sources["generated_connected_simple_cubic_bipartite"] += 1
                planar, embedding = nx.check_planarity(primal, counterexample=True)
                if not planar:
                    continue
                sources["planar"] += 1
                assert isinstance(embedding, nx.PlanarEmbedding)
                primal_faces = source_bundle.plane_faces(primal, embedding)
                direct = source_bundle.is_two_extendable_direct(primal)
                strict_hall = source_bundle.strict_hall_two_extendable(primal)
                assert direct == strict_hall
                if not direct:
                    continue
                sources["plane_braces"] += 1
                first_crossing = analyse_brace(
                    order=order,
                    source_graph6=source_graph6,
                    primal=primal,
                    primal_faces=primal_faces,
                    counts=counts,
                    first_crossing=first_crossing,
                )
        finally:
            stream.close()

        assert sources["generated_connected_simple_cubic_bipartite"] == (
            EXPECTED_GENERATED[order]
        )
        counts_by_order[str(order)] = dict(sorted(counts.items()))
        source_counts_by_order[str(order)] = dict(sorted(sources.items()))
        print(
            json.dumps(
                {
                    "order": order,
                    "sources": source_counts_by_order[str(order)],
                    "counts": counts_by_order[str(order)],
                    "first_crossing_order": (
                        None
                        if first_crossing is None
                        else first_crossing["source_order"]
                    ),
                },
                sort_keys=True,
            ),
            flush=True,
        )

    totals: Counter = Counter()
    through20: Counter = Counter()
    for order_text, record in counts_by_order.items():
        totals.update(record)
        if int(order_text) <= 20:
            through20.update(record)

    assert (
        through20["forced_components"],
        through20["forced_targets"],
    ) == EXPECTED_FORCED_THROUGH20
    assert (
        counts_by_order["22"].get("forced_components", 0),
        counts_by_order["22"].get("forced_targets", 0),
    ) == EXPECTED_FORCED_ORDER22
    assert totals["forced_components"] == (
        totals["forced_components_laminar_shores"]
        + totals["forced_components_nonlaminar_shores"]
    )
    assert totals["forced_targets"] == (
        totals["liftable_forced_targets"]
        + totals["nonliftable_forced_targets"]
    )

    return {
        "status": (
            "nonlaminar_forced_component_found"
            if first_crossing is not None
            else "all_forced_component_shore_families_laminar_through22"
        ),
        "scope": (
            "Every simple plane cubic bipartite brace of even order 6 through "
            "22 in the existing geng corpus; every legal two-gate split, "
            "unchanged root, and forced-gate target-state component."
        ),
        "generator": "geng -cqb -d3 -D3 n for even 6 <= n <= 22",
        "networkx_version": nx.__version__,
        "expected_generated_by_order": EXPECTED_GENERATED,
        "source_counts_by_order": source_counts_by_order,
        "counts_by_order": counts_by_order,
        "totals": dict(sorted(totals.items())),
        "all_forced_targets_liftable_through22": (
            totals["nonliftable_forced_targets"] == 0
        ),
        "first_crossing": first_crossing,
        "logical_force": {
            "proved_by_first_crossing_if_present": (
                "Forced-gate plane-dual bond shores need not form a laminar "
                "family, even with shared plane-brace realizability."
            ),
            "not_proved": (
                "The arbitrary-order forced-component saturation statement; "
                "the witness contains liftable rather than all-bad states."
            ),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    payload = census()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
        print("certificate", arguments.output)
    print(json.dumps(payload["totals"], sort_keys=True))
    if payload["first_crossing"] is None:
        print("FORCED_GATE_SHORES_LAMINAR_THROUGH_REDUCED_ORDER_22")
    else:
        print("FORCED_GATE_SHORES_NONLAMINAR_SHARED_BRACE_WITNESS_VERIFIED")
    if payload["all_forced_targets_liftable_through22"]:
        print("ALL_FORCED_COMPONENT_TARGETS_LIFTABLE_THROUGH_REDUCED_ORDER_22")
    else:
        print("NONLIFTABLE_FORCED_COMPONENT_TARGET_FOUND_THROUGH_REDUCED_ORDER_22")


if __name__ == "__main__":
    main()
