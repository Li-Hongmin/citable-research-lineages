# Forced-gate bond shores：真实非-laminar 路线关闭与 through-22 逐点接受性

## 结论

一般 forced-component saturation 命题仍未决；本轮没有得到全坏的真实
plane-brace orbit，也没有得到任意阶证明。

但是，“plane-dual bond shores 在 forced-gate component 中形成 laminar family，
因而可按嵌套 shore 归纳”的路线被一个真实的 shared-brace witness 严格关闭。
更强地，在该 witness 的中心 target 处，两条仅有的 incident toggle shores 都是
inclusion-minimal，却互相交叉。

完整 through-22 census 还得到比 Note 073 更强的有限陈述：在 reduced order
\(6,8,\ldots,22\) 的既有完整 corpus 中，所有 606 个 forced-gate components 的
全部 1288 个 targets 都满足 \(\operatorname{Acc}(\Sigma)\)。因此当前有限范围内
没有 bad target，更没有 bad-to-bad minimal transition。

## 最小阶真实 witness

源图是 order-16 simple plane cubic bipartite brace

```text
O????B_sCWKOI_BOAW?i?
```

其 reduced dual triangulation 的 graph6 是 `I}kyb?vOw`。取

\[
z=0,\qquad N(z)=(1,3,4,2),\qquad (x_2,x_4)=(1,4),
\]

primal gate edges 为 \((0,9),(1,8)\)，dual root 为 \((4,5)\)，primal
root 为 \((2,11)\)。完整 target family（modulo complement）恰有三个成员，
它们构成同一 forced-gate component

\[
V(\Gamma)=\{0,1,2\},\qquad
E(\Gamma)=\{02,12\}.
\]

按 \(z\notin S\) 规范化，两条 target-state edges 的唯一 bond shores 是

\[
S_{02}=\{6,9\},\qquad S_{12}=\{7,9\}.
\]

四个 Venn 区域分别包含

\[
S_{02}\cap S_{12}=\{9\},\quad
S_{02}\setminus S_{12}=\{6\},\quad
S_{12}\setminus S_{02}=\{7\},
\]

以及

\[
V(T')\setminus(S_{02}\cup S_{12})
=\{0,1,2,3,4,5,8\}.
\]

故两 shore 严格交叉。证书同时直接检查每个 shore 及其补集在 \(T'\) 中连通，
所以每个 \(\delta(S)\) 确为 bond；并检查其 primal dual 恰等于相应两 perfect
matchings 的 symmetric difference，即一条 alternating cycle。两个 toggles、三个
targets、split、root 和 gate edges 全部来自同一 plane brace interface，故

```text
shared_brace_realizability = true
```

而不是把分别可实现的因子做抽象乘积。三个 endpoint states 都接受，且各自的
normalized lift rows 都是 `011`, `101`, `110`；所以此 witness 只反驳 laminar
机制，不反驳 forced-component saturation。

逐阶穷尽还表明 order \(6,8,10,12,14\) 没有交叉 witness，因此 order 16 是该
through-22 corpus 中的最小 reduced order。总计 606 个 forced components 中，
488 个 shore family laminar，118 个非-laminar。

## 精确量词与逻辑力

仍未决的一般命题量化于每个 simple plane cubic bipartite brace \(F'\)、每个 legal
two-gate \(C_4\)-expansion、每个 split face 外且 target family 非空的 unchanged
root，以及每个同时 forcing 两 gate edges 的 target-state connected component
\(\Gamma\)：

\[
\Gamma\text{ 是否必含某个 }M
\text{ 使 }\operatorname{Acc}(\Sigma(M))?
\]

由 Note 074 的 proof-level equivalence，这等价于不存在一个真实
brace-realizable orbit，同时满足：对所有 target-preserving single-cycle bond
toggles 闭合、gate bits 恒为 \(11\)、且所有状态都在 \(\operatorname{Bad}\)。

本轮严格证明的路线关闭只有：上述真实量词下，forced-gate bond shores 不必
laminar；即使只取某状态的 inclusion-minimal incident shores，也不必 nested。
它不声称 labelled incidence \(J_{M,S}\) 无用，也不声称某个局部
\((S,J_{M,S})\) 条件已足以推出接受。

## 最弱承重步骤、证据等级与未决边界

**最弱承重步骤。** 仍需证明：实际来自同一 plane brace 的全部
\(J_{M,S}\) 受某个全局 plane-incidence 约束，使任何 closed gate-11 orbit 不能
完全停留在 \(\operatorname{Bad}\)。Note 074 的
\((\Sigma(M),J_{M,S})\mapsto\Sigma(N)\) 只给出精确单步演化；单步可计算性本身
不是强迫 orbit 退出 \(\operatorname{Bad}\) 的势函数或禁形定理。

**证据等级。** bond-toggle 公式、acceptance criterion 和 orbit equivalence 沿用
Note 074 的 proof-level 结果。order-16 非-laminar witness 与 through-22 逐点
接受性是精确有限穷尽：输入为 `geng -cqb -d3 -D3 n` 的全部 even orders
\(6\le n\le22\)，并直接复核 planarity、brace 条件、全部 legal splits、roots、
target components、bond cuts 和每个 forced target 的八个 local rows。其外部
依赖边界是 nauty `geng` 的同构代表完整性与 NetworkX 的精确图算法；有限成功
不是任意阶证明。

**未决边界。** reduced order \(24\) 及以上未搜索；依照本轮停止条件不扩阶。
尚无真实全坏 shared-brace orbit，也尚无把 actual \(J_{M,S}\) 的 plane incidence
转化为强迫接受的任意阶定理。

## 复现

```bash
uv run --with 'networkx==3.6.1' \
  units/barnette/scratch/forced_gate_laminar_shores_20260826/census_forced_gate_shores_through22.py \
  --output units/barnette/scratch/forced_gate_laminar_shores_20260826/forced_gate_shores_through22.json
```

预期末尾标记：

```text
FORCED_GATE_SHORES_NONLAMINAR_SHARED_BRACE_WITNESS_VERIFIED
ALL_FORCED_COMPONENT_TARGETS_LIFTABLE_THROUGH_REDUCED_ORDER_22
```
