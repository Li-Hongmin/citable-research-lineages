# Route 1 bounded pulse 6 — Note 171 check

**Verdict.** Note 171's stated NO-GO is mathematically sound for the exact input key \((\Sigma_+(Z),\nu_{\rm short}(Z,q))\) and complete next exterior-row support. The same real pair also separates the **zero-closed-component** part of that support, by a different explicit row below. This is an additional output collision on the same two histories, not a new pair of histories and not a Hamilton-acceptance collision. No finite refinement is proved sufficient on the full real domain.

## Scope and direct checks

Read the frozen SPEC, Notes 169–171, and the latest LOG entry (2026-09-24, Route 1 pulse 5). I made no census or tracked-file changes. I ran the existing standard-library checker:

```text
python3 -B scratch/route3_short_arc_refinement/verify_short_arc_collision.py
SHORT_ARC_REFINEMENT_COLLISION_VERIFIED
```

The checker reconstructs the four embedded expansions, tests the legal sites and graph conditions, and independently finds zero degree-feasible edge subsets among 4,096 subsets on the \(q_2\) side of Note 171's row. The decisive facts can also be checked without trusting that enumeration:

* The common successor face is \((0,20,21,16,19,1,5,4,12,13)\). For \(q_1=(19,1)\), its ordered residual lengths are \((3,5)\); for \(q_2=(5,4)\), they are \((5,3)\). Thus both capped pairs are \((3,3)\). The common prefix through \(Z\) makes \(\Sigma_+(Z)\) literally identical, while the fourteen-slot equality, colours, target statuses and marked word agree as Note 171 states.
* In \(Z\), \(D=\{12,13,14,15\}\) has cut \(\delta(D)=\{4\!-\!12,0\!-\!13,3\!-\!14,7\!-\!15\}\). In the claimed \(q_2\) row, vertices \(0,3,4\) have degree zero, and all of \(D\) have degree two. The cut-use count must be even, so \(7\!-\!15\) is also unused. Vertex \(7\), outside the boundary, then has at most its edge \(7\!-\!6\), contradicting degree two. This excludes the entire degree word, hence every row with that degree word, regardless of partition or closed-component count.
* The three squares in Note 171 are actual edges of \(Z\), avoid its three cut edges on the \(q_1\) side, and produce the claimed row with \(z=1\). Its complete-row distinction is therefore real.

## Additional separating row with \(z=0\)

Keep the same histories, targets \(e=2\!-\!6, f=9\!-\!10\), and ordered active boundary
\((U,V,X,Y,Q_0,Q_1,E_0,E_1,F_0,F_1)\). On the \(q_1\) side select

\[
 F'=C_8(4,5,6,7,15,14,13,12)\;\dot\cup\;C_4(8,9,18,17).
\]

The first cycle uses \(4\!-\!12\) and \(7\!-\!15\), joining Note 171's previously closed gadget square to the square through \(6\). Every displayed edge is in \(Z-\{0\!-\!16,11\!-\!3,19\!-\!1\}\). All nonboundary vertices have degree two. The two components meet the boundary only at \(E_1=6\) and \(F_0=9\), respectively. Direct evaluation of the row gives

```text
degree    = (0,0,0,0,0,0,0,2,2,0)
partition = ((0,),(1,),(2,),(3,),(4,),(5,),(6,),(7,),(8,),(9,))
z         = 0
(e-use,f-use) = (0,0)
```

I checked this edge set and complete row directly with the existing `row` function; it returned exactly the tuple above. On the \(q_2\) side the same degree word is impossible by the cut-parity argument, independently of \(z\). Thus the identical enriched input key has different next supports even after restricting to rows with no component disjoint from the active boundary. These two boundary-touching cycles are saturated at \(6\) and \(9\); this observation alone gives no Hamilton acceptance difference.

## Finite-refinement limit

For **only the two exhibited pairs** in Notes 170 and 171, one added bit \(b=\mathbf1_{\ell_0=3}\) separates the alternatives: their ordered first lengths are \(3\) versus \(5\) in both pairs. One bit is the smallest alphabet extension that can separate any formerly equal key with unequal outputs. A bit recording whether \(q\) is from the newest previous layer also separates the Note 171 pair. Neither bit has a whole-domain reattachment proof, so neither is a viable full-domain refinement on present evidence. In particular, this pulse does not establish closure for \(c_5\), a refined transition, statement (T), or nonexistence of every finite summary.
