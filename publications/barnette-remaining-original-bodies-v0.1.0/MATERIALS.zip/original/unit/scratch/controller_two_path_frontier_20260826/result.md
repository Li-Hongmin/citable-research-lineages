# Fixed-fibre degree-box frontier

Let \(m=|Y\setminus\{r\}|\), and for \(J\in\mathcal F_i\) write
\[
d(J)=(\deg_J(y))_{y\in Y\setminus\{r\}}.
\]
Because every component contains a port, \(d(J)\in\{1,2,3\}^m\), and
\[
\sum_y d(J)_y=2m-1.
\]

## Exact convex dual

The degree-box property
\[
\operatorname{conv}\{d(J):J\in\mathcal F_i\}
\cap(-\infty,2]^m\ne\varnothing
\tag{B}
\]
holds if and only if, for every nonnegative weight vector
\(\lambda\in\mathbb R^m_+\), some \(J\in\mathcal F_i\) satisfies
\[
\lambda\cdot d(J)\le2\lambda\cdot\mathbf1.
\tag{1}
\]
This is the separating-hyperplane theorem, since a separator of the
downward box must have nonnegative normal.

For \(K_J=E(F-r)\setminus J\), Note 055(4) gives
\[
d(J)_y=3-\deg_{K_J}(y).
\]
Thus (1) is equivalently
\[
\lambda\cdot\deg_{K_J}\ge\lambda\cdot\mathbf1.
\tag{2}
\]

Property (B) implies every binary-hole weak bound by taking
\(\lambda=\mathbf1_H\). It is strictly stronger even than all proposed
strong binary-hole bounds at the abstract degree-vector level.

## Exact abstract separation

Put \(e=d-2\mathbf1\), and take the following eight vectors in
\(\{-1,0,1\}^6\), each of total sum \(-1\):
\[
\begin{split}
&(-1,-1,0,0,0,1),\quad
(-1,1,-1,-1,0,1),\\
&(-1,-1,1,1,-1,0),\quad
(0,-1,-1,-1,1,1),\\
&(-1,-1,-1,1,1,0),\quad
(-1,-1,1,-1,1,0),\\
&(-1,0,-1,1,-1,1),\quad
(-1,0,1,-1,-1,1).
\end{split}
\tag{3}
\]
For every singleton \(H\), some vector has \(e(H)\le0\); for every
\(|H|\ge2\), some vector has
\[
e(H)\le-1.
\tag{4}
\]
Hence the corresponding \(d=e+2\mathbf1\) satisfy every binary-hole
strong bound.

Nevertheless, for
\[
\lambda=(1,1,3,3,3,7)
\]
the eight values \(\lambda\cdot e\) are
\[
(5,1,1,3,1,1,3,3).
\tag{5}
\]
Every convex combination therefore has positive weighted excess and
misses the degree box.

This is not an actual forest family or brace. It proves only that binary
hole inequalities, even with the conjectured one-unit slack for every
set of size at least two, cannot be converted to (B) without using
additional exchange structure of fixed fibres.

## Stronger integral frontier

In all 210 rooted fixed fibres of the five frozen braces, and in all
fibres of the sharp order-26 and order-30 braces from Note 027, there is
already a single forest with
\[
d(J)=(2,\ldots,2,1,2,\ldots,2).
\tag{6}
\]
Such a forest is exactly a spanning two-path cover: one path joins the
paired ports, and the other joins the singleton port to the unique
degree-one \(Y\)-vertex. This finite observation motivates first
determining the integral two-path statement. If it fails, (B) remains a
genuinely weaker fallback.

The exact abstract verifier is
\`verify_binary_bounds_do_not_force_degree_box.py\`. The sharp-brace
certificates are independently stored under
\`scratch/review_degree_box_sharp_braces_20260826/\`.
