"""Only the fixed 24-vertex certificate; stdlib, streaming, no file output.

Run: python3 -B scratch/check_two_sided_independent_20260927.py
No imports from earlier checkers, graph census, or exchange search.
"""

from collections import Counter
from itertools import combinations
import json


def edge(a, b):
    return tuple(sorted((a, b)))


def rim(walk):
    return {edge(a, b) for a, b in zip(walk, walk[1:] + walk[:1])}


def parts(vertices, edges):
    adj = {v: set() for v in vertices}
    for a, b in edges:
        adj[a].add(b)
        adj[b].add(a)
    left, out = set(vertices), []
    while left:
        found, todo = set(), [min(left)]
        while todo:
            v = todo.pop()
            if v not in found:
                found.add(v)
                todo.extend(adj[v] - found)
        left -= found
        out.append(found)
    return out


def rank(vertices, edges):
    # Multiplicity is retained in len(edges); isolated vertices are retained.
    return len(edges) - len(vertices) + len(parts(vertices, edges))


def check_plane_graph(n, edges, faces):
    vertices = set(range(n))
    assert len(edges) == 3 * n // 2
    assert Counter(v for g in edges for v in g) == Counter({v: 3 for v in vertices})
    darts, turns = Counter(), {v: {} for v in vertices}
    for face in faces:
        assert len(face) == len(set(face)) >= 4 and len(face) % 2 == 0
        for i, v in enumerate(face):
            prev, nxt = face[i - 1], face[(i + 1) % len(face)]
            assert edge(v, nxt) in edges and prev not in turns[v]
            turns[v][prev] = nxt
            darts[v, nxt] += 1
    assert darts == Counter({dart: 1 for g in edges for dart in (g, g[::-1])})
    for turn in turns.values():
        first = min(turn)
        assert {first, turn[first], turn[turn[first]]} == set(turn)
        assert turn[turn[turn[first]]] == first
    assert n - len(edges) + len(faces) == 2
    colour = {0: 0}
    while len(colour) < n:
        old_size = len(colour)
        for a, b in edges:
            if a in colour:
                colour.setdefault(b, 1 - colour[a])
            if b in colour:
                colour.setdefault(a, 1 - colour[b])
            if a in colour and b in colour:
                assert colour[a] != colour[b]
        assert len(colour) > old_size
    assert all(colour[a] != colour[b] for a, b in edges)
    for size in range(3):
        for deleted in combinations(range(n), size):
            kept = vertices - set(deleted)
            assert len(parts(kept, [g for g in edges if set(g) <= kept])) == 1


def expand(n, edges, faces, site):
    u, v, x, y = site
    assert len(set(site)) == 4
    hits = []
    for i, face in enumerate(faces):
        for reverse in (False, True):
            walk = face[::-1] if reverse else face
            if u not in walk:
                continue
            j = walk.index(u)
            walk = walk[j:] + walk[:j]
            if walk[1] == v and x in walk:
                j = walk.index(x)
                if j + 1 < len(walk) and walk[j + 1] == y:
                    hits.append((i, reverse, walk, j))
    assert len(hits) == 1
    fi, reverse, carrier, j = hits[0]
    assert j % 2 == 0  # both residual arcs odd, u and x same bipartition colour
    if reverse:
        faces = [face[::-1] for face in faces]
    a, b, c, d = range(n, n + 4)
    p, q = edge(u, v), edge(x, y)
    replacements = {(u, v): [a, b], (v, u): [b, a],
                    (x, y): [c, d], (y, x): [d, c]}
    out = []
    for i, face in enumerate(faces):
        if i != fi:
            out.append([z for h, w in zip(face, face[1:] + face[:1])
                        for z in [h] + replacements.get((h, w), [])])
    out += [carrier[1:j + 1] + [c, b],
            carrier[j + 1:] + [u, a, d], [a, b, c, d]]
    born = {edge(*g) for g in [(u, a), (a, b), (b, v), (x, c),
                              (c, d), (d, y), (a, d), (b, c)]}
    return n + 4, (edges - {p, q}) | born, out


def verify():
    n = 8
    edges = {(0, 1), (0, 3), (0, 4), (1, 2), (1, 7), (2, 3),
             (2, 6), (3, 5), (4, 5), (4, 7), (5, 6), (6, 7)}
    faces = [[0, 1, 2, 3], [4, 5, 6, 7], [1, 0, 4, 7],
             [2, 1, 7, 6], [3, 2, 6, 5], [0, 3, 5, 4]]
    check_plane_graph(n, edges, faces)
    for site in [(7, 6, 5, 4), (0, 1, 7, 4), (0, 3, 5, 10), (8, 11, 4, 15)]:
        n, edges, faces = expand(n, edges, faces, site)
        check_plane_graph(n, edges, faces)
    assert (n, len(edges), len(faces)) == (24, 36, 14)
    vertices, face_ids = set(range(n)), set(range(len(faces)))
    dual = {g: tuple(i for i, face in enumerate(faces) if g in rim(face)) for g in edges}
    assert all(len(ends) == 2 for ends in dual.values())
    e, f, p, q = (0, 16), (1, 2), (0, 4), (16, 19)
    assert rim([0, 4, 11, 10, 19, 16]) in [rim(face) for face in faces]

    def de(gs):
        return [dual[g] for g in sorted(gs)]

    def matching(gs):
        assert gs <= edges
        assert Counter(v for g in gs for v in g) == Counter(vertices)

    def setup(pm):
        trees = parts(face_ids, de(pm))
        assert len(trees) == 2 and rank(face_ids, de(pm)) == 0
        inside = next(t for t in trees if set(dual[e]) <= t)
        outside = face_ids - inside
        ov, ox = [next(i for i in outside if v in faces[i]) for v in (0, 16)]
        paths, todo = {ov: [ov]}, [ov]
        while todo:
            at = todo.pop()
            for a, b in de(pm):
                if at in (a, b):
                    other = b if at == a else a
                    if other not in paths:
                        paths[other] = paths[at] + [other]
                        todo.append(other)
        return inside, outside, paths[ox]

    c = [0, 4, 22, 23, 20, 21, 11, 10, 19, 16, 17, 18,
         5, 3, 2, 6, 9, 8, 7, 1, 13, 14, 15, 12]
    assert set(c) == vertices and len(c) == n and rim(c) <= edges
    m = edges - rim(c)
    matching(m)
    assert {e, f} <= m and {p, q} <= rim(c)
    inside, outside, pi = setup(m)
    assert [len(faces[i]) for i in pi[1:-1]] == [6, 6, 6]
    face_f = next(i for i, face in enumerate(faces) if rim(face) == rim([7, 8, 20, 23, 15, 14]))
    face_s = next(i for i, face in enumerate(faces) if rim(face) == rim([12, 13, 14, 15]))
    assert face_f in outside and face_s in inside
    u = {face_f, face_s}
    boundary = {g for g, (a, b) in dual.items() if (a in u) != (b in u)}
    exchange = rim([7, 8, 20, 23, 15, 12, 13, 14])
    assert boundary == exchange and exchange not in [rim(face) for face in faces]
    assert not {e, f} & boundary
    new = m ^ boundary
    matching(new)
    assert {e, f} <= new and len(m - new) == 4
    cycles = [[0, 4, 22, 23, 15, 14, 7, 1, 13, 12],
              [2, 3, 5, 18, 17, 16, 19, 10, 11, 21, 20, 8, 9, 6]]
    assert not set(cycles[0]) & set(cycles[1])
    assert set(cycles[0] + cycles[1]) == vertices
    assert edges - new == rim(cycles[0]) | rim(cycles[1])
    assert p in rim(cycles[0]) and q in rim(cycles[1])
    assert rank(face_ids, de(new)) == 1
    assert len(parts(face_ids, de(new - {e}))) == len(parts(face_ids, de(new))) == 3

    base = parts(face_ids, de((m & new) - {e}))
    label = {v: i for i, comp in enumerate(base) for v in comp}
    ju = [(label[a], label[b]) for a, b in de(new - m)]
    ae, be = [label[v] for v in dual[e]]
    assert len(base) == 7 and len(ju) == 4 and ae != be
    assert rank(set(range(7)), ju) == 0
    assert any({ae, be} <= comp for comp in parts(set(range(7)), ju))
    assert all((base[a] <= inside) != (base[b] <= inside) for a, b in ju)

    retained = inside - {face_s}
    ti = {g for g in m if set(dual[g]) <= retained}
    assert set(dual[e]) <= retained and len(parts(retained, de(ti))) == 1
    o_branches = parts(outside - {face_f}, de({g for g in m if set(dual[g]) <= outside - {face_f}}))
    blocks = [{face_s}] + o_branches
    block_id = {v: i for i, comp in enumerate(blocks) for v in comp}
    j_edges = [g for g in new - m if set(dual[g]) <= set(block_id)]
    j = [(block_id[a], block_id[b]) for a, b in de(j_edges)]
    r, k, b = len(rim(faces[face_f]) & m), len(rim(faces[face_f]) & rim(faces[face_s])), 1
    assert (r, k, b) == (3, 1, 1) and len(o_branches) == r
    assert len(m - new) == r + b and len(j) == k + b == 2
    assert rank(set(range(r + b)), j) == 0 and len(parts(set(range(r + b)), j)) == 2
    attachment_edges = sorted((rim(faces[face_f]) - m) - rim(faces[face_s]))
    attachments = [next(v for v in dual[g] if v != face_f) for g in attachment_edges]
    root_sides = parts(retained, de(ti - {e}))
    assert len(attachments) == 2 and all(sum(v in comp for v in attachments) == 1 for comp in root_sides)
    solo = m ^ rim(faces[face_f])
    matching(solo)
    assert len(parts(vertices, edges - solo)) == 3
    assert (2 - 1 - (4 - 1)) % 2 == 0

    # One tiny, streamed PM traversal of this fixed graph checks the numerical
    # claims; it generates no other graph and stores no matching family.
    adj = {v: sorted(w for g in edges if v in g for w in g if w != v) for v in vertices}

    def perfect_matchings(left, chosen):
        if not left:
            yield chosen
            return
        v = min(left)
        for w in adj[v]:
            if w in left:
                yield from perfect_matchings(left - {v, w}, chosen | {edge(v, w)})

    counts = Counter()
    covered, good_faces = set(), []
    for pm in perfect_matchings(vertices, set()):
        counts['perfect_matchings'] += 1
        if len(parts(vertices, edges - pm)) != 1:
            continue
        counts['hamilton_cycles'] += 1
        covered.update((a, z) for a in edges - pm for z in pm)
        if f in pm and e not in pm:
            counts['e_plus_f_minus'] += 1
            assert {p, q} <= pm
        if f in pm and p not in pm:
            counts['p_plus_f_minus'] += 1
            assert e in pm
            _, _, path = setup(pm)
            good = [faces[i] for i in path[1:-1] if len(faces[i]) == 4 and f not in rim(faces[i])]
            good_faces.append(good)
    assert counts['hamilton_cycles'] == 34 and len(covered) == 36 * 35
    assert counts['e_plus_f_minus'] == 1 and counts['p_plus_f_minus'] == 3
    assert sorted(map(len, good_faces)) == [0, 1, 1]
    print(json.dumps({'status': 'FIXED_24_CERTIFICATE_VERIFIED', 'counts': dict(counts),
                      'ordered_pairs_covered': len(covered), 'M': sorted(m), 'N': sorted(new),
                      'Pi_faces': [faces[i] for i in pi], 'r_k_b': [r, k, b],
                      'J_edges': sorted(j_edges), 'F_retained_attachment_edges': attachment_edges,
                      'J_U_vertices_edges_components': [len(base), len(ju), len(parts(set(range(7)), ju))],
                      'faces': faces, 'I': sorted(inside), 'O': sorted(outside),
                      'F_S_face_ids': [face_f, face_s],
                      'J_U_blocks': [sorted(comp) for comp in base],
                      'J_U_labelled_edges': [[list(g), label[dual[g][0]], label[dual[g][1]]]
                                             for g in sorted(new - m)],
                      'J_U_root_ends': [ae, be],
                      'absorption_O_branches': [sorted(comp) for comp in o_branches],
                      'absorption_root_sides': [sorted(comp) for comp in root_sides],
                      'other_parent_good_faces': good_faces, 'complement_cycle_lengths': [10, 14]},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    verify()
