# Two standard facial C4 expansions do not produce a one-crossing descendant

Fix the labelled order-(22) brace and decoration used by
`test_order22_isolated_mixed_k2_one_step_c4.py`:

\[
e=1-11,\qquad g_0=0-12,\qquad g_1=9-17.
\]

The complete rooted exchange graph of the parent has three crossings.  Its
first standard facial (C_4)-expansions, with both expanded edges disjoint
and avoiding (e,g_0,g_1), contain exactly (38) legal-wide root-square
braces.  Exactly nine attain the minimum crossing count three.  In the fixed
labelling, their first expanded edge pairs are

\[
\begin{gathered}
\{3\!-!12,6\!-!20\},\quad
\{1\!-!14,2\!-!11\},\quad
\{2\!-!15,6\!-!14\},\\
\{6\!-!18,7\!-!15\},\quad
\{3\!-!21,10\!-!20\},\quad
\{7\!-!16,8\!-!18\},\\
\{8\!-!19,10\!-!20\},\quad
\{9\!-!19,10\!-!21\},\quad
\{9\!-!21,10\!-!19\}.
\end{gathered}
\]

Only these nine children are continued.  On every face of each child, every
pair of disjoint boundary edges avoiding (e,g_0,g_1) is replaced by the
same standard planar (C_4) patch.  This gives (809) distinct labelled
order-(30) candidates and no duplicated labelled histories.  Every
candidate is checked afresh for simplicity, planarity, cubicity,
bipartiteness, (3)-connectivity, the opposite root square and a legal-wide
gate face.  The (350) rejected candidates fail only as follows:

\[
\begin{array}{c|r}
\text{failure set}&\text{number}\\ \hline
\{\text{bipartite}\}&174\\
\{\text{bipartite},\text{legal-wide}\}&51\\
\{\text{bipartite},\text{root-square}\}&22\\
\{\text{legal-wide}\}&54\\
\{\text{root-square}\}&49.
\end{array}
\]

For each of the remaining (459) grandchildren, all perfect matchings are
enumerated.  Every one is (2)-extendable: every pair of independent edges
occurs in an enumerated perfect matching.  The full rooted fibre is then
selected from the complete matching family, and every pair of rooted
matchings is tested for whether its symmetric difference is one cycle.
Consequently the following histogram uses the complete rooted exchange
graph, not a sampled or inherited subgraph:

\[
\begin{array}{c|rrrrrrrrrrrrrr}
\#\text{ crossings}&3&5&6&7&8&9&10&11&12&13&14&15&16&17\\
\#\text{ graphs}&110&107&6&52&3&43&4&8&4&10&10&25&10&9\\[2pt]
\#\text{ crossings}&18&19&20&21&23&24&25&29&31&32&33&41&42\\
\#\text{ graphs}&5&12&4&4&12&4&2&2&5&2&2&2&2
\end{array}
\]

Thus the minimum is again three, attained by (110) grandchildren.  Their
distribution over the nine first-step children is

\[
(12,11,11,14,12,14,12,12,12).
\]

In particular, this prescribed two-step descendant family contains no
complete rooted exchange graph with exactly one crossing.  This is a strict
finite closure for the named brace, the nine minimum first-step children and
two standard facial (C_4) expansions only.  It is not a theorem about
arbitrary patches, a third expansion, or all order-(30) braces.

Reproduce with

~~~text
uv run --python 3.14 --with 'networkx==3.6.1' \
  units/barnette/scratch/test_order22_isolated_mixed_k2_two_step_c4.py
~~~

The terminal marker is

~~~text
ORDER22_ISOLATED_K2_TWO_STEP_COUNTEREXAMPLE_NOT_FOUND
~~~
