# No-positive-gate branches collapse to an edge, but edge smoothing need not preserve a brace

This leaf starts from Note 055 and treats only its \(G=\varnothing\)
branch. Permanent notes and papers are unchanged.

## Setting

Assume the hypothetical fixed-\(\pi_i\) weak-bound failure of Note 055.
Thus \(J\in\mathcal F_i\) is a global \(H\)-load minimizer,
\(h_0\in H\) has \(\deg_J(h_0)=3\), and \(C\) is a minimum-order
port-free component of \(J-h_0\). Put

\[
U=X\cap C,\qquad V=Y\cap C.
\]

Note 055 proves

\[
|U|=|V|, \tag{1}
\]

and classifies every edge from \(U\) to \(Y\setminus V\) as either the
current attachment, a zero-cost whole-branch token transfer, or a
positive gate. Let \(x_0h_0\) be the current attachment and assume
\(G=\varnothing\), so no positive gate exists.

## The Hall-tight shore is necessarily one edge

> **No-gate collapse lemma.** Under the assumptions above,
> \[
> U=\{x_0\},\qquad V=\{v\},
> \]
> and \(C\) is the edge \(x_0v\). Moreover
> \[
> \delta_F(U\cup V)
> =\{x_0h_0,x_0h_1,av,bv\}, \tag{2}
> \]
> where \(h_0,h_1\in H\) are distinct, \(a,b\in X\setminus U\) are
> distinct, and
> \[
> \begin{aligned}
> \delta^+(U\cup V)&=E(U,Y\setminus V)
>   =\{x_0h_0,x_0h_1\},\\
> \delta^-(U\cup V)&=E(X\setminus U,V)
>   =\{av,bv\}.
> \end{aligned} \tag{3}
> \]
> In particular, the cut has exactly four edges, two in each orientation,
> and the two \(U\)-outgoing edges share the same \(X\)-endpoint \(x_0\).

To prove the lemma, consider \(U'=U\setminus\{x_0\}\). If
\(x\in U'\) had a neighbour outside \(V\), the corresponding edge would be
absent from \(J\): the tree branch \(C\) has only the attachment
\(x_0h_0\). The exit classification of Note 055 would then make it either
a positive gate, excluded by \(G=\varnothing\), or a zero-cost exit. The
latter is also impossible because every zero-cost exit has
\(f=x_0h_0\), and hence is incident with \(x_0\). Therefore

\[
N_F(U')\subseteq V. \tag{4}
\]

If \(|U|\ge2\), then \(U'\) is a nonempty proper subset of \(X\), and
brace strict Hall expansion gives

\[
|N_F(U')|\ge |U'|+2=|U|+1>|V|,
\]

contradicting (4) and (1). Hence \(|U|=|V|=1\). Since \(C\) is connected,
it is the edge \(x_0v\).

The vertex \(x_0\) has one edge in \(J[C]\). The current attachment uses
one of its remaining two cubic edges. Hall expansion supplies a second
external neighbour, and, because \(G=\varnothing\), it is exactly the
alternative zero-cost attachment hole \(h_1\). Thus the first equality in
(3) holds and its two edges share \(x_0\). Cubic degree balance gives

\[
3|U|=|E_F(U,V)|+|\delta^+(U\cup V)|,
\qquad
3|V|=|E_F(U,V)|+|\delta^-(U\cup V)|.
\]

Equation (1) makes the two directed cut sizes equal, proving the second
equality in (3). Simplicity makes \(h_0\ne h_1\) and \(a\ne b\).

This completely answers the first part of the pulse: a nontrivial balanced
four-cut cannot occur in the no-gate branch.

## The only strict local reductions

Delete \(x_0,v\). Each of the four external vertices
\(a,b,h_0,h_1\) loses one incident edge. A strictly smaller local
replacement preserving simplicity, cubicity, and the bipartition cannot
insert one new vertex: the four boundary stubs have both orientations and
one cubic vertex cannot absorb them. With no new vertices, every external
degree is restored precisely by one of the two pairings

\[
\sigma_0=\{ah_0,bh_1\},
\qquad
\sigma_1=\{ah_1,bh_0\}. \tag{5}
\]

Thus the two bipartite smoothings (5) exhaust all strict-order local
contractions of the two-point shore.

## A real brace/fibre obstruction to universal smoothing

The assertion that one of (5) must again be a simple brace is false, even
with the complete local no-gate fibre state.

Take the order-20 graph

\[
\texttt{S???????DAICi?\_g@o?I\_F?@@O?d?B?\_?}. \tag{6}
\]

It is a simple cubic bipartite brace. Use colour classes

\[
X=\{0,\ldots,9\},\qquad Y=\{10,\ldots,19\},
\]

root \(r=10\), ports \((0,2,7)\), and the fibre in which port \(7\)
is alone. In the \(X\)-order \((0,\ldots,9)\), take the representative
whose omitted-edge endpoint tuple is

\[
(13,11,19,11,16,14,14,15,13,17). \tag{7}
\]

Let

\[
x_0=4,\quad v=14,\quad h_0=12,\quad h_1=16,\quad
a=5,\quad b=6,\quad H=\{12,16\}. \tag{8}
\]

The forest in (7) has the prescribed \(X\)-degrees and port partition,
and

\[
\deg_J(h_0)=3,\qquad \deg_J(h_1)=2,\qquad \deg_J(v)=1. \tag{9}
\]

The component of \(J-h_0\) containing \(x_0\) is exactly
\(\{4,14\}\), and

\[
\delta_F(\{4,14\})
=\{4\,12,4\,16,5\,14,6\,14\}. \tag{10}
\]

Replacing \(4\,12\) by \(4\,16\) stays in the same fibre and transfers
the token, changing the two hole degrees from \((3,2)\) to \((2,3)\).
There is no positive gate because the branch has no \(X\)-vertex other
than its attachment.

Now smooth the shore.

* The pairing
  \[
  \{5\,12,6\,16\}
  \]
  produces a simple connected cubic bipartite graph, but it is not a
  brace:
  \[
  N(\{3,6,8\})=\{11,13,16,18\},
  \]
  so a three-set has only four neighbours, violating strict Hall by one.
* The other pairing
  \[
  \{5\,16,6\,12\}
  \]
  is not a simple cubic replacement because \(5\,16\) is already an edge
  of \(F\).

Hence neither strict local reduction is a simple brace.

This is a real brace/fibre counterexample to **universal local no-gate
smoothing**. It is deliberately not claimed to be a counterexample to the
weak cap-load bound: in this fibre and for \(H=\{12,16\}\), the displayed
state has load five but the exact fibre minimum is two. The graph is also
nonplanar. Consequently the example proves that the local no-gate boundary
state alone cannot support a minimal-counterexample contraction. It does
not exclude an additional theorem derived from the full global
counterexample hypothesis, nor does it decide a plane-brace-only version.

The complete certificate is checked by
verify_no_gate_smoothing_counterexample.py in this scratch directory.

## The fixed-\(\pi\) lifting state still missing after a brace smoothing

Even when one smoothing \(F_\sigma\) happens to be a brace, brace
preservation is not enough to reduce a counterexample.

Deleting \(x_0,v\) and the two incident \(J\)-edges
\(x_0v,x_0h_0\) leaves a two-component forest with the same port
partition and all remaining \(X\)-degrees. It is therefore a feasible
representative in the reduced fibre and uses neither smoothing edge.
However, an arbitrary low-load representative of the reduced fibre may
use the new edges. Put

\[
S(J')=J'\cap\sigma\subseteq\sigma. \tag{11}
\]

The exact reverse-lifting cases are:

1. **\(|S|=1\).** The selected smoothing edge \(ah_j\) can always be
   replaced by the path
   \[
   a-v-x_0-h_j.
   \]
   This preserves acyclicity, the fixed port partition, and all prescribed
   \(X\)-degrees.
2. **\(|S|=0\).** One must attach the new leaf path
   \(h_j-x_0-v\) at one token hole. If
   \(\epsilon=\mathbf1_{\{v\in H\}}\) and
   \(H'=H\setminus\{v\}\), the load changes by
   \[
   \ell_H(\operatorname{lift}J')
   =\ell_{H'}(J')+1+\epsilon. \tag{12}
   \]
   Thus a weak-bound representative at equality does not lift safely when
   \(v\notin H\); one additional unit of reduced slack is required.
3. **\(|S|=2\).** After removing the two smoothing edges, the edges
   \(av,bv\) are forced, and \(x_0\) must use two of
   \[
   x_0h_0,\quad x_0h_1,\quad x_0v. \tag{13}
   \]
   Whether one of these three choices is a forest with the original
   \(\pi_i\) depends on the port-decorated component partition of
   \(\{a,b,h_0,h_1\}\) induced by \(J'-S\); equivalently, one must
   retain the component partition induced on the four boundary terminals
   together with the three named ports.

Therefore the exact missing local datum is a four-terminal cap profile

\[
(S,\rho,\lambda), \tag{14}
\]

where \(S\subseteq\sigma\) records smoothing-edge occupancy,
\(\rho\) is the port-decorated component partition after those edges are
deleted, and \(\lambda\) is the minimum \(H'\)-load in that state. In
addition one needs the graph-side bit saying which smoothing \(\sigma\),
if any, is brace-admissible. Notes 052--055 contain neither of these
boundary controls.

## Exact conclusion

For every hypothetical fixed-\(\pi_i\) weak-bound counterexample, its
no-positive-gate minimum branch is necessarily the two-vertex shore
\(\{x_0,v\}\), with a balanced four-edge cut whose two \(U\)-outgoing
edges share \(x_0\).

The stronger claim that this shore always admits a strict
brace-preserving, fixed-\(\pi_i\)-preserving counterexample reduction is
not implied by the no-gate state. The real brace/fibre certificate
(6)--(10) blocks both possible strict local smoothings. Even when a brace
smoothing exists, the exact unresolved interface is the state profile
(14), especially the \(|S|=2\) terminal partition and the
\(|S|=0,\ v\notin H\) one-unit load loss.

The weakest load-bearing step in the positive structural result is the use
of Note 055's exit classification for every edge from
\(U\setminus\{x_0\}\) to \(Y\setminus V\). Once that classification is
accepted, the singleton-shore conclusion is a direct strict-Hall
contradiction. The contraction failure is an exact finite certificate;
the remaining plane/full-counterexample boundary is not decided.
