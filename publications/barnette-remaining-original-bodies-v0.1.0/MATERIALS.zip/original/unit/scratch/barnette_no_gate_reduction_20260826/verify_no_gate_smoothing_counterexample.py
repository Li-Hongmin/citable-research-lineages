#!/usr/bin/env python3
"""Verify a real-brace/fibre obstruction to local no-gate smoothing."""

from __future__ import annotations

from itertools import combinations, product

import networkx as nx


GRAPH6 = "S???????DAICi?_g@o?I_F?@@O?d?B?_?"
ROOT = 10
X_ORDER = tuple(range(10))
OMITTED = (13, 11, 19, 11, 16, 14, 14, 15, 13, 17)
X0 = 4
V0 = 14
H0 = 12
H1 = 16
INCOMING_X = (5, 6)
HOLES = frozenset((H0, H1))


def strict_hall_defects(graph: nx.Graph):
    colour = nx.bipartite.color(graph)
    sides = [
        tuple(vertex for vertex in graph if colour[vertex] == side)
        for side in (0, 1)
    ]
    defects = []
    for side in sides:
        n = len(side)
        for size in range(1, n - 1):
            for selected in combinations(side, size):
                neighbours = set().union(*(set(graph[v]) for v in selected))
                if len(neighbours) < size + 2:
                    defects.append((selected, tuple(sorted(neighbours))))
    return defects


def is_brace(graph: nx.Graph) -> bool:
    return (
        nx.is_connected(graph)
        and nx.is_bipartite(graph)
        and all(degree == 3 for _, degree in graph.degree())
        and not strict_hall_defects(graph)
    )


def forest_from_omissions(graph: nx.Graph, omissions=OMITTED):
    forest = nx.Graph()
    forest.add_nodes_from(set(graph) - {ROOT})
    omitted_by_x = dict(zip(X_ORDER, omissions))
    for x in X_ORDER:
        for y in graph[x]:
            if y != ROOT and y != omitted_by_x[x]:
                forest.add_edge(x, y)
    return forest


def port_partition(forest: nx.Graph, ports):
    component_of = {}
    for index, component in enumerate(nx.connected_components(forest)):
        for vertex in component:
            component_of[vertex] = index
    return tuple(sorted(tuple(sorted(p for p in ports if component_of[p] == index))
                        for index in set(component_of[p] for p in ports)))


def hole_load(forest: nx.Graph) -> int:
    return sum(forest.degree(h) for h in HOLES)


def exact_fibre_minimum(graph: nx.Graph):
    choices = tuple(
        tuple(y for y in graph[x] if y != ROOT)
        for x in X_ORDER
    )
    target_partition = ((0, 2), (7,))
    minimum = 99
    count = 0
    for omissions in product(*choices):
        forest = forest_from_omissions(graph, omissions)
        if not nx.is_forest(forest):
            continue
        if nx.number_connected_components(forest) != 2:
            continue
        if port_partition(forest, (0, 2, 7)) != target_partition:
            continue
        count += 1
        minimum = min(minimum, hole_load(forest))
    return count, minimum


def reduced_graph(graph: nx.Graph, pairs):
    reduced = graph.copy()
    reduced.remove_nodes_from((X0, V0))
    if any(reduced.has_edge(x, y) for x, y in pairs):
        return None
    reduced.add_edges_from(pairs)
    return reduced


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert is_brace(graph)
    assert not nx.check_planarity(graph)[0]
    assert tuple(sorted(graph[ROOT])) == (0, 2, 7)

    forest = forest_from_omissions(graph)
    assert nx.is_forest(forest)
    assert nx.number_connected_components(forest) == 2
    assert port_partition(forest, (0, 2, 7)) == ((0, 2), (7,))
    assert all(
        forest.degree(x) == (1 if x in graph[ROOT] else 2)
        for x in X_ORDER
    )
    assert forest.degree(H0) == 3
    assert forest.degree(H1) == 2
    assert forest.degree(V0) == 1
    assert hole_load(forest) == 5

    deleted_hole = forest.copy()
    deleted_hole.remove_node(H0)
    branch = nx.node_connected_component(deleted_hole, X0)
    assert branch == {X0, V0}
    assert not branch.intersection(graph[ROOT])

    shore = {X0, V0}
    cut = {
        tuple(sorted((u, v)))
        for u in shore
        for v in graph[u]
        if v not in shore
    }
    assert cut == {(4, 12), (4, 16), (5, 14), (6, 14)}

    transferred = forest.copy()
    transferred.remove_edge(X0, H0)
    transferred.add_edge(X0, H1)
    assert nx.is_forest(transferred)
    assert nx.number_connected_components(transferred) == 2
    assert port_partition(transferred, (0, 2, 7)) == ((0, 2), (7,))
    assert transferred.degree(H0) == 2
    assert transferred.degree(H1) == 3
    assert hole_load(transferred) == 5
    fibre_count, fibre_minimum = exact_fibre_minimum(graph)
    assert fibre_count == 2076
    assert fibre_minimum == 2

    simple_pairing = ((5, 12), (6, 16))
    simple_reduction = reduced_graph(graph, simple_pairing)
    assert simple_reduction is not None
    assert nx.is_connected(simple_reduction)
    assert nx.is_bipartite(simple_reduction)
    assert all(degree == 3 for _, degree in simple_reduction.degree())
    defects = strict_hall_defects(simple_reduction)
    assert ((3, 6, 8), (11, 13, 16, 18)) in defects
    assert not is_brace(simple_reduction)

    duplicate_pairing = ((5, 16), (6, 12))
    assert graph.has_edge(5, 16)
    assert reduced_graph(graph, duplicate_pairing) is None

    print("graph6", GRAPH6)
    print("root_ports_fibre", ROOT, (0, 2, 7), ((0, 2), (7,)))
    print("omitted", OMITTED)
    print("branch", tuple(sorted(branch)), "cut", tuple(sorted(cut)))
    print("token_degrees", forest.degree(H0), forest.degree(H1))
    print("fibre_count_minimum", fibre_count, fibre_minimum)
    print("simple_pairing_hall_defect", ((3, 6, 8), (11, 13, 16, 18)))
    print("duplicate_pairing_existing_edge", (5, 16))
    print("NO_GATE_SMOOTHING_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
