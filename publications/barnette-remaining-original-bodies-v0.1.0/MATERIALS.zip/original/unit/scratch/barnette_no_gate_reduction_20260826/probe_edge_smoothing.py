#!/usr/bin/env python3
"""Probe whether both bipartite smoothings of an edge can fail to be braces."""

from __future__ import annotations

import argparse
from itertools import combinations, permutations
import random

import networkx as nx


GRAPH6 = (
    ("cube", "G?zTb_"),
    ("brace12", "K??FEagT@WB_"),
    ("brace16a", "O????B_sDOI_I_DO@W?M?"),
    ("brace16b", "O????B_sCWKOI_BOAW?i?"),
    ("brace18", "Q??????wE_P_W_IO@g?h?Cg?B_?"),
)


def is_brace(graph: nx.Graph) -> bool:
    if (
        nx.number_of_selfloops(graph)
        or not nx.is_connected(graph)
        or not nx.is_bipartite(graph)
        or any(degree != 3 for _, degree in graph.degree())
    ):
        return False
    colour = nx.bipartite.color(graph)
    sides = [
        tuple(vertex for vertex in graph if colour[vertex] == side)
        for side in (0, 1)
    ]
    if len(sides[0]) != len(sides[1]):
        return False
    n = len(sides[0])
    for side in sides:
        for size in range(1, n - 1):
            for selected in combinations(side, size):
                neighbours = set().union(*(set(graph[v]) for v in selected))
                if len(neighbours) < size + 2:
                    return False
    return True


def smoothings(graph: nx.Graph, edge: tuple[int, int]):
    colour = nx.bipartite.color(graph)
    x, y = edge
    if colour[x] == colour[y]:
        raise AssertionError
    if colour[x] == 1:
        x, y = y, x
    # x and the neighbours of y have one colour; y and the neighbours of x
    # have the other.  Pair these two two-element boundary sets.
    y_side = tuple(sorted(set(graph[x]) - {y}))
    x_side = tuple(sorted(set(graph[y]) - {x}))
    for ordered_y_side in permutations(y_side):
        pairs = tuple(zip(x_side, ordered_y_side))
        reduced = graph.copy()
        reduced.remove_nodes_from((x, y))
        if any(reduced.has_edge(a, b) for a, b in pairs):
            yield pairs, None
            continue
        reduced.add_edges_from(pairs)
        yield pairs, reduced


def random_cubic_bipartite(n: int, rng: random.Random) -> nx.Graph:
    while True:
        edges: set[tuple[int, int]] = set()
        successful = True
        for _ in range(3):
            matching = list(range(n))
            rng.shuffle(matching)
            if any((x, matching[x]) in edges for x in range(n)):
                successful = False
                break
            edges.update((x, matching[x]) for x in range(n))
        if not successful:
            continue
        graph = nx.Graph()
        graph.add_nodes_from(range(2 * n))
        graph.add_edges_from((x, n + y) for x, y in edges)
        if nx.is_connected(graph):
            return graph


def bad_edges(graph: nx.Graph):
    output = []
    for edge in sorted(graph.edges()):
        results = [
            reduced is not None and is_brace(reduced)
            for _, reduced in smoothings(graph, edge)
        ]
        if not any(results):
            output.append((tuple(sorted(edge)), tuple(results)))
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--random-side", type=int)
    parser.add_argument("--random-braces", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260826)
    args = parser.parse_args()
    for name, graph6 in GRAPH6:
        graph = nx.from_graph6_bytes(graph6.encode())
        assert is_brace(graph)
        print(
            name,
            "order",
            len(graph),
            "edges_with_no_brace_smoothing",
            bad_edges(graph),
        )
    if args.random_side and args.random_braces:
        rng = random.Random(args.seed)
        accepted = 0
        generated = 0
        while accepted < args.random_braces:
            graph = random_cubic_bipartite(args.random_side, rng)
            generated += 1
            if not is_brace(graph):
                continue
            accepted += 1
            failures = bad_edges(graph)
            print(
                "random",
                accepted,
                "generated",
                generated,
                "order",
                len(graph),
                "edges_with_no_brace_smoothing",
                failures,
            )
            if failures:
                print(
                    "graph6",
                    nx.to_graph6_bytes(graph, header=False).decode().strip(),
                )
                return


if __name__ == "__main__":
    main()
