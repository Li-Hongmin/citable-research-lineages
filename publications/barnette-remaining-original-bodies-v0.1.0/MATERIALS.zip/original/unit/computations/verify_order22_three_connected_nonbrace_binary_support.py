#!/usr/bin/env python3
"""Verify binary common-base support for every order-22 non-brace.

Every simple plane cubic bipartite 3-connected non-brace of order 22 is
a tight 3-splice of either the cube with one of the two order-16 braces,
or the order-12 brace with itself.  This program generates all 2,400
rooted port gluings, reduces them to five unlabelled graphs, and checks all
binary layers at one representative of every ordered-site automorphism
orbit.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from itertools import permutations, product
from pathlib import Path
import subprocess

import networkx as nx


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "verify_no_strict_binary_defect_through_order_sixteen.py"
SPEC = spec_from_file_location("order22_binary_base", BASE_PATH)
assert SPEC is not None and SPEC.loader is not None
BASE = module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)

Edge = tuple[int, int]
Site = tuple[int, int, int, int]

CUBE = "G?zTb_"
BRACE12 = "K??FEagT@WB_"
BRACE16_A = "O????B_sDOI_I_DO@W?M?"
BRACE16_B = "O????B_sCWKOI_BOAW?i?"
FACTOR_PAIRS = (
    (CUBE, BRACE16_A),
    (CUBE, BRACE16_B),
    (BRACE12, BRACE12),
)

EXPECTED_GRAPH6 = {
    "UEhf????????????AK?Q_@I?@S?@S??i??J??@o?",
    "UEhf????????????AK?Q_@B?@a?@S??Y??R??DO?",
    "UEhf????????????AK?Q_?R?Ca?@S??Y??R??DO?",
    "U?BDAagU@o???????????@@_AD?AD??I_?Ao??[?",
    "U?BDAagU@o????????????`_CD?AD??I_?Ao??[?",
}


def edge(left: int, right: int) -> Edge:
    return (left, right) if left < right else (right, left)


def splice(
    first: nx.Graph,
    first_root: int,
    second: nx.Graph,
    second_root: int,
    neighbour_order: tuple[int, int, int],
) -> tuple[nx.Graph, frozenset[Edge]]:
    """Delete the two roots and join their three neighbours in order."""
    first_remaining = tuple(sorted(set(first) - {first_root}))
    second_remaining = tuple(sorted(set(second) - {second_root}))
    first_map = {vertex: index for index, vertex in enumerate(first_remaining)}
    second_map = {
        vertex: len(first_remaining) + index
        for index, vertex in enumerate(second_remaining)
    }

    graph = nx.Graph()
    graph.add_nodes_from(range(len(first_remaining) + len(second_remaining)))
    graph.add_edges_from(
        (first_map[left], first_map[right])
        for left, right in first.edges()
        if first_root not in (left, right)
    )
    graph.add_edges_from(
        (second_map[left], second_map[right])
        for left, right in second.edges()
        if second_root not in (left, right)
    )
    first_neighbours = tuple(sorted(first[first_root]))
    cut = frozenset(
        edge(first_map[left], second_map[right])
        for left, right in zip(first_neighbours, neighbour_order, strict=True)
    )
    graph.add_edges_from(cut)
    return graph, cut


def five_splices() -> tuple[tuple[nx.Graph, frozenset[Edge]], ...]:
    decoded = {
        graph6: nx.from_graph6_bytes(graph6.encode())
        for pair in FACTOR_PAIRS
        for graph6 in pair
    }
    output: list[tuple[nx.Graph, frozenset[Edge]]] = []
    for first_graph6, second_graph6 in FACTOR_PAIRS:
        first = decoded[first_graph6]
        second = decoded[second_graph6]
        for first_root in sorted(first):
            for second_root in sorted(second):
                for order in permutations(tuple(sorted(second[second_root]))):
                    graph, cut = splice(
                        first, first_root, second, second_root, order
                    )
                    assert len(graph) == 22
                    assert set(dict(graph.degree()).values()) == {3}
                    assert nx.is_bipartite(graph)
                    assert nx.check_planarity(graph)[0]
                    assert nx.node_connectivity(graph) == 3
                    assert not BASE.UTILITY.is_two_extendable(graph)
                    if not any(nx.is_isomorphic(graph, known) for known, _ in output):
                        output.append((graph, cut))
    assert len(output) == 5
    assert {
        nx.to_graph6_bytes(graph, header=False).decode().strip()
        for graph, _ in output
    } == EXPECTED_GRAPH6
    return tuple(output)


def verify_complete_geng_census(
    splices: tuple[tuple[nx.Graph, frozenset[Edge]], ...]
) -> None:
    """Independently recover exactly these five graphs from all order 22."""
    raw = 0
    planar_three_connected = 0
    braces = 0
    nonbraces: list[nx.Graph] = []
    process = subprocess.Popen(
        ("geng", "-cqb", "-d3", "-D3", "22"),
        stdout=subprocess.PIPE,
        text=True,
    )
    assert process.stdout is not None
    for line in process.stdout:
        raw += 1
        graph = nx.from_graph6_bytes(line.strip().encode())
        if not nx.check_planarity(graph)[0] or nx.node_connectivity(graph) < 3:
            continue
        planar_three_connected += 1
        if BASE.UTILITY.is_two_extendable(graph):
            braces += 1
        else:
            nonbraces.append(graph)
    assert process.wait() == 0
    assert (raw, planar_three_connected, braces, len(nonbraces)) == (4132, 8, 3, 5)

    splice_graphs = tuple(graph for graph, _cut in splices)
    assert all(
        sum(nx.is_isomorphic(graph, splice) for splice in splice_graphs) == 1
        for graph in nonbraces
    )
    assert all(
        sum(nx.is_isomorphic(splice, graph) for graph in nonbraces) == 1
        for splice in splice_graphs
    )


def site_orbits(graph: nx.Graph) -> dict[Site, tuple[Site, ...]]:
    sites = BASE.ordered_legal_sites(graph)
    automorphisms = tuple(
        nx.algorithms.isomorphism.GraphMatcher(
            graph, graph
        ).isomorphisms_iter()
    )
    grouped: dict[Site, list[Site]] = defaultdict(list)
    for site in sites:
        representative = min(
            tuple(mapping[vertex] for vertex in site)
            for mapping in automorphisms
        )
        grouped[representative].append(site)
    return {
        representative: tuple(sorted(members))
        for representative, members in grouped.items()
    }


def strict_masks(loads: tuple[tuple[int, ...], ...]) -> tuple[int, ...]:
    """Return exact over-budget masks by subset DP over all base loads."""
    width = len(loads[0])
    minima = [width + 1] * (1 << width)
    for load in loads:
        values = [0] * (1 << width)
        for mask in range(1, 1 << width):
            bit = mask & -mask
            index = bit.bit_length() - 1
            values[mask] = values[mask ^ bit] + load[index]
        for mask, value in enumerate(values):
            minima[mask] = min(minima[mask], value)
    return tuple(
        mask for mask, value in enumerate(minima)
        if value > mask.bit_count()
    )


def fast_base_loads(
    graph: nx.Graph, site: Site
) -> tuple[tuple[int, ...], tuple[tuple[int, ...], ...], int]:
    """Enumerate common-base loads with a union--find tree test."""
    u, _v, _z, a = site
    colour = nx.bipartite.color(graph)
    reduced = graph.copy()
    reduced.remove_nodes_from({u, a})
    ground = frozenset(edge(left, right) for left, right in reduced.edges())
    x_vertices = tuple(
        sorted(vertex for vertex in reduced if colour[vertex] == colour[u])
    )
    x_side = set(x_vertices)
    blocks = {
        x: tuple(sorted(label for label in ground if x in label))
        for x in x_vertices
    }
    q_ends, _root = BASE.UTILITY.contracted_dual(graph, site)
    q_vertices = tuple(
        sorted({vertex for ends in q_ends.values() for vertex in ends})
    )
    q_index = {vertex: index for index, vertex in enumerate(q_vertices)}
    y_vertices = tuple(
        sorted(
            vertex for vertex in graph
            if colour[vertex] != colour[u] and vertex != a
        )
    )
    y_index = {vertex: index for index, vertex in enumerate(y_vertices)}

    loads: list[tuple[int, ...]] = []
    transversal_count = 0
    for choice in product(*(blocks[x] for x in x_vertices)):
        transversal_count += 1
        parent = list(range(len(q_vertices)))

        def find(vertex: int) -> int:
            while parent[vertex] != vertex:
                parent[vertex] = parent[parent[vertex]]
                vertex = parent[vertex]
            return vertex

        acyclic = True
        for label in choice:
            left, right = (q_index[value] for value in q_ends[label])
            left_root, right_root = find(left), find(right)
            if left_root == right_root:
                acyclic = False
                break
            parent[right_root] = left_root
        if not acyclic:
            continue
        assert len(choice) == len(q_vertices) - 1
        load = [0] * len(y_vertices)
        for label in choice:
            y = next(vertex for vertex in label if vertex not in x_side)
            load[y_index[y]] += 1
        loads.append(tuple(load))
    assert loads
    return y_vertices, tuple(loads), transversal_count


def verify_cotree_formula(
    graph: nx.Graph,
    site: Site,
    bases: tuple[frozenset[Edge], ...],
    x_vertices: tuple[int, ...],
) -> None:
    """Cross-check the analytic cotree fragmentation identity."""
    u, v, z, a = site
    p, q = edge(u, v), edge(z, a)
    colour = nx.bipartite.color(graph)
    y_vertices = tuple(
        sorted(
            vertex for vertex in graph
            if colour[vertex] != colour[u] and vertex != a
        )
    )
    x_side = set(x_vertices)
    all_edges = {edge(left, right) for left, right in graph.edges()}

    for base in bases:
        tree_edges = all_edges - set(base) - {p, q}
        tree = nx.Graph()
        tree.add_nodes_from(graph)
        tree.add_edges_from(tree_edges)
        assert nx.is_tree(tree)
        assert all(tree.degree[x] == 2 for x in x_side - {z})
        assert tree.degree[z] == 1
        assert tree.degree[u] == 2
        assert set(graph[u]) - {v} <= set(tree[u])
        assert set(graph[a]) - {z} <= set(tree[a])
        for mask in range(1 << len(y_vertices)):
            active = {
                y_vertices[index]
                for index in range(len(y_vertices))
                if mask >> index & 1
            }
            holes = set(y_vertices) - active
            cost = sum(
                next(vertex for vertex in label if vertex not in x_side)
                in active
                for label in base
            )
            # H is independent, so deletion from a tree creates exactly
            # 1 + sum_{y in H}(deg_T(y)-1) components.
            components = 1 + sum(tree.degree[y] - 1 for y in holes)
            epsilon = int(v in holes)
            assert (cost <= len(active)) == (
                components <= len(holes) + 1 - epsilon
            )


def main() -> None:
    graphs = five_splices()
    verify_complete_geng_census(graphs)
    totals: Counter[str] = Counter()
    for graph_index, (graph, _cut) in enumerate(graphs):
        sites = BASE.ordered_legal_sites(graph)
        orbits = site_orbits(graph)
        graph_totals: Counter[str] = Counter(
            ordered_sites=len(sites), site_orbits=len(orbits)
        )
        first_site = min(orbits)
        for site, orbit_members in sorted(orbits.items()):
            y_vertices, loads, transversals = fast_base_loads(graph, site)
            assert len(y_vertices) == 10
            graph_totals["transversals"] += transversals
            graph_totals["bases"] += len(loads)
            bad = strict_masks(loads)
            graph_totals["strict_layers"] += len(bad) * len(orbit_members)
            assert not bad

            if site == first_site:
                stable = BASE.UTILITY.partition_data(graph, site)
                stable_loads = BASE.base_loads(graph, site, stable)
                assert transversals == len(stable["transversals"])
                assert Counter(loads) == Counter(stable_loads)
                verify_cotree_formula(
                    graph,
                    site,
                    stable["bases"],
                    stable["x_vertices"],
                )
                graph_totals["stable_cross_checks"] += 1
        totals.update(graph_totals)
        print(
            f"graph {graph_index + 1}/5: sites={len(sites)} "
            f"orbits={len(orbits)} strict={graph_totals['strict_layers']}",
            flush=True,
        )

    assert totals == Counter(
        ordered_sites=1176,
        site_orbits=756,
        transversals=16_979_868,
        bases=1_529_304,
        strict_layers=0,
        stable_cross_checks=5,
    )
    print("ORDER22_THREE_CONNECTED_NONBRACE_BINARY_SUPPORT_VERIFIED")


if __name__ == "__main__":
    main()
