#!/usr/bin/env python3
"""Verify a genuine short-bridge common-complement fibre failure.

The graph is an order-18 plane cubic bipartite brace with global H^{+-}.
At the legal P-regime site (u,v,z,a)=(0,9,5,11), the displayed
01--00--10 Hamilton bridge uses two alternating six-cycles.  Its complete
common-complement near-matching fibre has three members, but none has a
connected complement after deleting p=uv and h=za.
"""

from __future__ import annotations

from itertools import combinations

import networkx as nx


GRAPH6 = b"Q??????wE_P_?wGo@cAc?EG?d??"
U, V, Z, A = 0, 9, 5, 11
P, H = (0, 9), (5, 11)

LEFT = frozenset({
    (6, 12), (4, 16), (8, 14), (2, 17), (0, 10), (5, 11),
    (7, 13), (3, 15), (1, 9),
})
MIDDLE = frozenset({
    (6, 12), (2, 17), (0, 10), (5, 14), (8, 16), (7, 13),
    (4, 11), (3, 15), (1, 9),
})
RIGHT = frozenset({
    (6, 12), (2, 17), (1, 15), (5, 14), (0, 9), (3, 10),
    (8, 16), (7, 13), (4, 11),
})

FIBRE = frozenset({
    frozenset({
        (6, 12), (5, 17), (8, 16), (7, 13), (2, 9), (1, 10),
        (4, 14), (3, 15),
    }),
    frozenset({
        (5, 17), (8, 16), (2, 9), (6, 13), (7, 12), (1, 10),
        (4, 14), (3, 15),
    }),
    frozenset({
        (6, 15), (5, 17), (7, 13), (3, 16), (8, 12), (2, 9),
        (1, 10), (4, 14),
    }),
})


Edge = tuple[int, int]
Matching = frozenset[Edge]


def edge(left: int, right: int) -> Edge:
    return (left, right) if left < right else (right, left)


def perfect_matchings(graph: nx.Graph):
    def visit(remaining: frozenset[int], chosen: tuple[Edge, ...]):
        if not remaining:
            yield frozenset(chosen)
            return
        first = min(remaining)
        for neighbour in graph[first]:
            if neighbour in remaining:
                yield from visit(
                    remaining - {first, neighbour},
                    chosen + (edge(first, neighbour),),
                )

    yield from visit(frozenset(graph), ())


def one_cycle(edges: Matching) -> bool:
    support = nx.Graph()
    support.add_edges_from(edges)
    return (
        bool(edges)
        and nx.is_connected(support)
        and set(dict(support.degree()).values()) == {2}
    )


def complement(
    graph: nx.Graph, all_edges: Matching, matching: Matching
) -> nx.Graph:
    result = nx.Graph()
    result.add_nodes_from(graph)
    result.add_edges_from(all_edges - matching)
    return result


def is_two_extendable(graph: nx.Graph) -> bool:
    graph_edges = tuple(edge(left, right) for left, right in graph.edges())
    for first, second in combinations(graph_edges, 2):
        endpoints = set(first + second)
        if len(endpoints) != 4:
            continue
        reduced = graph.copy()
        reduced.remove_nodes_from(endpoints)
        if next(perfect_matchings(reduced), None) is None:
            return False
    return True


def face_boundaries(embedding: nx.PlanarEmbedding) -> tuple[tuple[int, ...], ...]:
    seen: set[tuple[int, int]] = set()
    answer = []
    for left, right in embedding.edges():
        if (left, right) not in seen:
            answer.append(tuple(embedding.traverse_face(left, right, seen)))
    return tuple(answer)


def global_h_plus_minus(
    all_edges: Matching, hamilton_matchings: tuple[Matching, ...]
) -> bool:
    return all(
        any(
            first not in matching and second in matching
            for matching in hamilton_matchings
        )
        for first in all_edges
        for second in all_edges
        if first != second
    )


def state(matching: Matching) -> str:
    return f"{int(P in matching)}{int(H in matching)}"


def target_complement(
    graph: nx.Graph, all_edges: Matching, matching: Matching
) -> nx.Graph:
    result = nx.Graph()
    result.add_nodes_from(graph)
    result.add_edges_from(all_edges - {P, H} - matching)
    return result


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6)
    all_edges = frozenset(edge(left, right) for left, right in graph.edges())
    planar, embedding = nx.check_planarity(graph)

    assert len(graph) == 18 and len(all_edges) == 27
    assert planar
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.node_connectivity(graph) == 3
    assert set(dict(graph.degree()).values()) == {3}
    assert is_two_extendable(graph)
    assert (0, 9, 2, 17, 5, 11) in face_boundaries(embedding) or (
        0, 11, 5, 17, 2, 9
    ) in face_boundaries(embedding)
    colour = nx.bipartite.color(graph)
    assert colour[U] == colour[Z]

    all_matchings = tuple(perfect_matchings(graph))
    hamilton_matchings = tuple(
        matching
        for matching in all_matchings
        if nx.is_connected(complement(graph, all_edges, matching))
    )
    assert len(all_matchings) == 56
    assert len(hamilton_matchings) == 20
    assert global_h_plus_minus(all_edges, hamilton_matchings)
    assert {LEFT, MIDDLE, RIGHT} <= set(hamilton_matchings)
    assert tuple(map(state, (LEFT, MIDDLE, RIGHT))) == ("01", "00", "10")
    assert one_cycle(LEFT ^ MIDDLE) and len(LEFT ^ MIDDLE) == 6
    assert one_cycle(MIDDLE ^ RIGHT) and len(MIDDLE ^ RIGHT) == 6

    reduced = graph.copy()
    reduced.remove_nodes_from((U, A))
    near_matchings = tuple(perfect_matchings(reduced))
    common_complement = all_edges - (LEFT | MIDDLE | RIGHT)
    fibre = frozenset(
        matching
        for matching in near_matchings
        if matching - MIDDLE <= common_complement
    )
    assert len(near_matchings) == 15
    assert fibre == FIBRE

    profiles = []
    for matching in fibre:
        residual = target_complement(graph, all_edges, matching)
        assert not nx.is_connected(residual)
        profiles.append(tuple(sorted(
            len(part) for part in nx.connected_components(residual)
        )))
        degrees = dict(residual.degree())
        assert degrees[V] == degrees[Z] == 1
        assert all(
            degree == (1 if vertex in {V, Z} else 2)
            for vertex, degree in degrees.items()
        )
    assert sorted(profiles) == [(4, 6, 8), (6, 12), (6, 12)]

    # The site itself is not an FEC counterexample: four of all fifteen
    # near matchings have connected complements.  The obstruction belongs
    # to this compatible bridge and its common-complement fibre.
    all_targets = tuple(
        matching
        for matching in near_matchings
        if nx.is_connected(target_complement(graph, all_edges, matching))
    )
    assert len(all_targets) == 4

    adjacency = {
        matching: frozenset(
            other
            for other in hamilton_matchings
            if matching != other and one_cycle(matching ^ other)
        )
        for matching in hamilton_matchings
    }
    layers = {
        label: tuple(m for m in hamilton_matchings if state(m) == label)
        for label in ("00", "01", "10", "11")
    }
    bridges = tuple(
        (left, middle, right)
        for middle in layers["00"]
        for left in layers["01"]
        if left in adjacency[middle]
        for right in layers["10"]
        if right in adjacency[middle]
    )
    successful = 0
    for left, middle, right in bridges:
        allowed_new = all_edges - (left | middle | right)
        bridge_fibre = tuple(
            matching
            for matching in near_matchings
            if matching - middle <= allowed_new
        )
        if any(
            nx.is_connected(target_complement(graph, all_edges, matching))
            for matching in bridge_fibre
        ):
            successful += 1
    assert {label: len(layer) for label, layer in layers.items()} == {
        "00": 6, "01": 4, "10": 4, "11": 6,
    }
    assert len(bridges) == 34 and successful == 19
    assert sum(
        len(left ^ middle) == len(middle ^ right) == 6
        for left, middle, right in bridges
    ) == 1

    print("perfect_matchings", 56, "hamilton_matchings", 20)
    print("site_layers", {label: len(layer) for label, layer in layers.items()})
    print("bridges", 34, "successful", 19)
    print("selected_exchange_orders", (6, 6))
    print("selected_fibre_profiles", sorted(profiles))
    print("ORDER18_SHORT_BRIDGE_FIBRE_FAILURE_VERIFIED")


if __name__ == "__main__":
    main()
