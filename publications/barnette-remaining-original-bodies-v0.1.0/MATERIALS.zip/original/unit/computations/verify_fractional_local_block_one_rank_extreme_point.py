"""Verify a fractional local-block vertex after one omitted rank row.

The certificate is exact and uses only the Python standard library.
It does not claim realizability by one plane cubic bipartite brace.
"""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations


VERTICES = tuple(range(5))
EDGES = tuple(e for e in combinations(VERTICES, 2) if e != (0, 3))
EDGE_INDEX = {e: i for i, e in enumerate(EDGES)}
BLOCKS = (
    ((0, 1), (0, 2), (1, 2)),
    ((0, 4), (1, 4)),
    ((1, 3), (2, 3)),
    ((2, 4), (3, 4)),
)
W = frozenset((1, 2, 3, 4))
VALUES = {
    (0, 4): Fraction(1, 2),
    (1, 2): Fraction(1),
    (1, 3): Fraction(1),
    (1, 4): Fraction(1, 2),
    (2, 4): Fraction(1, 2),
    (3, 4): Fraction(1, 2),
}
X = tuple(VALUES.get(e, Fraction(0)) for e in EDGES)


def subsets():
    for mask in range(1, (1 << len(VERTICES)) - 1):
        yield frozenset(v for v in VERTICES if mask >> v & 1)


def internal_row(shore):
    return [int(u in shore and v in shore) for u, v in EDGES]


def dot(row, vector):
    return sum(Fraction(a) * b for a, b in zip(row, vector))


def rational_rank(rows):
    matrix = [[Fraction(value) for value in row] for row in rows]
    ncolumns = len(matrix[0]) if matrix else 0
    rank = 0
    for column in range(ncolumns):
        pivot = next(
            (i for i in range(rank, len(matrix)) if matrix[i][column]),
            None,
        )
        if pivot is None:
            continue
        matrix[rank], matrix[pivot] = matrix[pivot], matrix[rank]
        scale = matrix[rank][column]
        matrix[rank] = [value / scale for value in matrix[rank]]
        for i, row in enumerate(matrix):
            if i != rank and row[column]:
                scale = row[column]
                matrix[i] = [
                    value - scale * pivot_value
                    for value, pivot_value in zip(row, matrix[rank])
                ]
        rank += 1
    return rank


def generic_internal_row(edges, shore):
    return [int(u in shore and v in shore) for u, v in edges]


def connected_after_deleting(deleted):
    remaining = set(VERTICES) - set(deleted)
    if len(remaining) <= 1:
        return True
    seen = {next(iter(remaining))}
    while True:
        expanded = seen | {
            v
            for u, v in EDGES
            if u in seen and v in remaining
        } | {
            u
            for u, v in EDGES
            if v in seen and u in remaining
        }
        if expanded == seen:
            return seen == remaining
        seen = expanded


def verify_graph_and_blocks():
    # Q is the triangular bipyramid with apices 0 and 3 and base 1,2,4.
    expected = {
        (1, 2), (1, 4), (2, 4),
        (0, 1), (0, 2), (0, 4),
        (1, 3), (2, 3), (3, 4),
    }
    assert set(EDGES) == expected
    assert len(EDGES) == 3 * len(VERTICES) - 6
    assert all(connected_after_deleting(deleted)
               for k in (0, 1, 2)
               for deleted in combinations(VERTICES, k))

    flat = [edge for block in BLOCKS for edge in block]
    assert len(flat) == len(set(flat)) == len(EDGES)
    assert set(flat) == set(EDGES)
    assert set(BLOCKS[0]) == set(combinations((0, 1, 2), 2))
    for block in BLOCKS[1:]:
        assert len(block) == 2
        assert set(block[0]) & set(block[1])


def verify_feasibility_and_unique_violation():
    assert all(value >= 0 for value in X)
    assert sum(X) == len(VERTICES) - 1
    for block in BLOCKS:
        assert sum(X[EDGE_INDEX[e]] for e in block) == 1

    violations = []
    for shore in subsets():
        value = dot(internal_row(shore), X)
        if value > len(shore) - 1:
            violations.append((shore, value))
    assert violations == [(W, Fraction(7, 2))]


def verify_extremality():
    rows = []
    for block in BLOCKS:
        rows.append([int(edge in block) for edge in EDGES])
    for zero_edge in ((0, 1), (0, 2), (2, 3)):
        i = EDGE_INDEX[zero_edge]
        rows.append([int(i == j) for j in range(len(EDGES))])
    rows.append(internal_row(frozenset((1, 2, 4))))
    rows.append(internal_row(frozenset((1, 3, 4))))
    assert all(dot(row, X) in (Fraction(0), Fraction(1), Fraction(2))
               for row in rows)
    assert rational_rank(rows) == len(EDGES)


def verify_pure_five_point_counterexample():
    vertices = tuple(range(6))
    edges = tuple(combinations(vertices, 2))
    values = {
        (0, 2): Fraction(1, 2),
        (0, 3): Fraction(1, 2),
        (0, 4): Fraction(1, 2),
        (0, 5): Fraction(1, 2),
        (1, 2): Fraction(1),
        (1, 3): Fraction(1),
        (1, 4): Fraction(1),
    }
    vector = tuple(values.get(edge, Fraction(0)) for edge in edges)
    shore_w = frozenset(range(5))
    assert sum(vector) == len(vertices) - 1

    violations = []
    for mask in range(1, (1 << len(vertices)) - 1):
        shore = frozenset(v for v in vertices if mask >> v & 1)
        value = dot(generic_internal_row(edges, shore), vector)
        if value > len(shore) - 1:
            violations.append((shore, value))
    assert violations == [(shore_w, Fraction(9, 2))]

    active = []
    for i, value in enumerate(vector):
        if value == 0:
            active.append([int(i == j) for j in range(len(edges))])
    for i in (2, 3, 4):
        active.append(generic_internal_row(edges, frozenset((1, i))))
    for i, j in combinations((2, 3, 4), 2):
        active.append(
            generic_internal_row(edges, frozenset((0, 1, i, j)))
        )
    active.append([1] * len(edges))
    assert rational_rank(active) == len(edges)


if __name__ == "__main__":
    verify_graph_and_blocks()
    verify_feasibility_and_unique_violation()
    verify_extremality()
    verify_pure_five_point_counterexample()
    print("FRACTIONAL_LOCAL_BLOCK_ONE_RANK_EXTREME_POINT_VERIFIED")
