#!/usr/bin/env python3
"""Verify the sharp boundaries for small laminar-leaf elimination.

The first check uses one already-fixed genuine global-H+- brace and only
records that its fixed site has no strict single-layer defect.  The second
check uses the already-fixed order-16 plane cubic bipartite two-cut graph.
It verifies an actual-incidence strict certificate supported on a two-vertex
leaf and proves, by two explicit cost-six partition transversals, that no
strict *laminar* certificate can avoid that leaf.  The final check verifies
a separate-primal/dual degree-pattern model in which a size-three leaf is
indispensable even for unrestricted replacement.

This is a fixed-object discriminator.  It generates no graphs and performs
no order census.
"""

from __future__ import annotations

from itertools import combinations, permutations, product

import networkx as nx


Edge = tuple[int, int]
Site = tuple[int, int, int, int]


def edge(left: int, right: int) -> Edge:
    return (left, right) if left < right else (right, left)


def fixed_two_cut_graph() -> nx.Graph:
    graph = nx.Graph()
    graph.add_edges_from((i, (i + 1) % 16) for i in range(16))
    graph.add_edges_from(
        (
            (0, 3),
            (1, 6),
            (2, 5),
            (4, 7),
            (8, 11),
            (9, 14),
            (10, 13),
            (12, 15),
        )
    )
    return graph


def has_oriented_common_face(graph: nx.Graph, site: Site) -> bool:
    planar, embedding = nx.check_planarity(graph)
    assert planar
    u, v, z, a = site
    seen: set[tuple[int, int]] = set()
    for first, second in embedding.edges():
        if (first, second) in seen:
            continue
        face = tuple(embedding.traverse_face(first, second, seen))
        for orientation in (face, tuple(reversed(face))):
            doubled = orientation + orientation
            for start in range(len(face)):
                rotated = doubled[start : start + len(face)]
                if rotated[:2] != (u, v):
                    continue
                if any(
                    rotated[index : index + 2] == (z, a)
                    for index in range(2, len(face) - 1)
                ):
                    return True
    return False


def contracted_dual(
    graph: nx.Graph, site: Site
) -> tuple[dict[Edge, tuple[int, int]], int]:
    planar, embedding = nx.check_planarity(graph)
    assert planar
    halfedge_face: dict[tuple[int, int], int] = {}
    seen: set[tuple[int, int]] = set()
    face_count = 0
    for first, second in embedding.edges():
        if (first, second) in seen:
            continue
        face = tuple(embedding.traverse_face(first, second, seen))
        for left, right in zip(face, face[1:] + face[:1]):
            halfedge_face[(left, right)] = face_count
        face_count += 1

    dual_ends = {
        edge(left, right): (halfedge_face[(left, right)], halfedge_face[(right, left)])
        for left, right in graph.edges()
    }
    parent = list(range(face_count))

    def find(vertex: int) -> int:
        while parent[vertex] != vertex:
            parent[vertex] = parent[parent[vertex]]
            vertex = parent[vertex]
        return vertex

    def union(left: int, right: int) -> None:
        left, right = find(left), find(right)
        if left != right:
            parent[right] = left

    u, v, z, a = site
    special_faces: set[int] = set()
    for special in (edge(u, v), edge(z, a)):
        special_faces.update(dual_ends[special])
        union(*dual_ends[special])

    roots = sorted({find(face) for face in range(face_count)})
    root_index = {representative: index for index, representative in enumerate(roots)}
    face_to_q = {face: root_index[find(face)] for face in range(face_count)}
    root = face_to_q[next(iter(special_faces))]
    assert {face_to_q[face] for face in special_faces} == {root}

    reduced = graph.copy()
    reduced.remove_nodes_from({u, a})
    ground = {edge(left, right) for left, right in reduced.edges()}
    q_ends = {
        label: (face_to_q[left], face_to_q[right])
        for label, (left, right) in dual_ends.items()
        if label in ground
    }
    assert not any(left == right for left, right in q_ends.values())
    return q_ends, root


def partition_data(graph: nx.Graph, site: Site) -> dict[str, object]:
    u, v, z, a = site
    colour = nx.bipartite.color(graph)
    assert colour[u] == colour[z]
    reduced = graph.copy()
    reduced.remove_nodes_from({u, a})
    ground = frozenset(edge(left, right) for left, right in reduced.edges())
    x_vertices = tuple(sorted(vertex for vertex in reduced if colour[vertex] == colour[u]))
    blocks = {
        x: tuple(sorted(label for label in ground if x in label)) for x in x_vertices
    }
    q_ends, root = contracted_dual(graph, site)
    q_vertices = tuple(sorted({vertex for ends in q_ends.values() for vertex in ends}))

    def is_q_tree(support: frozenset[Edge]) -> bool:
        tree = nx.MultiGraph()
        tree.add_nodes_from(q_vertices)
        tree.add_edges_from(q_ends[label] for label in support)
        return nx.is_tree(tree)

    transversals = {
        frozenset(choice)
        for choice in product(*(blocks[x] for x in x_vertices))
        if len(frozenset(choice)) == len(x_vertices)
    }
    bases = tuple(sorted((support for support in transversals if is_q_tree(support)), key=sorted))
    return {
        "ground": ground,
        "x_vertices": x_vertices,
        "blocks": blocks,
        "q_ends": q_ends,
        "q_vertices": q_vertices,
        "root": root,
        "transversals": transversals,
        "bases": bases,
    }


def cost(support: frozenset[Edge], x_vertices: tuple[int, ...], active_y: set[int]) -> int:
    x_side = set(x_vertices)
    return sum(next(vertex for vertex in label if vertex not in x_side) in active_y for label in support)


def internal_count(
    support: frozenset[Edge], region: frozenset[int], q_ends: dict[Edge, tuple[int, int]]
) -> int:
    return sum(left in region and right in region for left, right in map(q_ends.__getitem__, support))


def crosses(left: frozenset[int], right: frozenset[int]) -> bool:
    return bool(left & right and left - right and right - left)


def is_two_extendable(graph: nx.Graph) -> bool:
    for first, second in combinations(tuple(graph.edges()), 2):
        if set(first) & set(second):
            continue
        remainder = graph.copy()
        remainder.remove_nodes_from(set(first + second))
        matching = nx.algorithms.matching.max_weight_matching(
            remainder, maxcardinality=True
        )
        if len(matching) < len(remainder) // 2:
            return False
    return True


def verify_fixed_brace_has_no_strict_defect() -> None:
    graph = nx.from_graph6_bytes(b"OlCGHD@?g?_@@@A?_?k?P")
    site = (15, 14, 13, 4)
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.node_connectivity(graph) == 3
    for first, second in combinations(graph.edges(), 2):
        if set(first) & set(second):
            continue
        remainder = graph.copy()
        remainder.remove_nodes_from((*first, *second))
        matching = nx.max_weight_matching(remainder, maxcardinality=True)
        assert len(matching) == len(remainder) // 2
    assert is_two_extendable(graph)
    assert has_oriented_common_face(graph, site)

    data = partition_data(graph, site)
    bases: tuple[frozenset[Edge], ...] = data["bases"]  # type: ignore[assignment]
    x_vertices: tuple[int, ...] = data["x_vertices"]  # type: ignore[assignment]
    u, _v, _z, a = site
    colour = nx.bipartite.color(graph)
    y_vertices = tuple(
        sorted(vertex for vertex in graph if colour[vertex] != colour[u] and vertex != a)
    )
    assert len(bases) == 112

    tested = 0
    for size in range(len(y_vertices) + 1):
        for selected in combinations(y_vertices, size):
            active_y = set(selected)
            mu = min(cost(base, x_vertices, active_y) for base in bases)
            assert mu <= size
            tested += 1
    assert tested == 128


def verify_two_cut_leaf_is_laminar_indispensable() -> None:
    graph = fixed_two_cut_graph()
    site = (14, 15, 8, 9)
    assert not graph.is_multigraph()
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.node_connectivity(graph) == 2
    assert nx.minimum_edge_cut(graph) == {edge(0, 15), edge(7, 8)}
    assert has_oriented_common_face(graph, site)
    colour = nx.bipartite.color(graph)
    assert colour[site[0]] == colour[site[2]]

    # An explicit independent matching pair that cannot be extended proves
    # directly that the graph is not a brace.
    remainder = graph.copy()
    remainder.remove_nodes_from({0, 1, 7, 8})
    assert nx.algorithms.matching.max_weight_matching(remainder, maxcardinality=True)
    assert len(nx.algorithms.matching.max_weight_matching(remainder, maxcardinality=True)) < len(remainder) // 2

    data = partition_data(graph, site)
    ground: frozenset[Edge] = data["ground"]  # type: ignore[assignment]
    x_vertices: tuple[int, ...] = data["x_vertices"]  # type: ignore[assignment]
    blocks: dict[int, tuple[Edge, ...]] = data["blocks"]  # type: ignore[assignment]
    q_ends: dict[Edge, tuple[int, int]] = data["q_ends"]  # type: ignore[assignment]
    q_vertices: tuple[int, ...] = data["q_vertices"]  # type: ignore[assignment]
    root: int = data["root"]  # type: ignore[assignment]
    bases: tuple[frozenset[Edge], ...] = data["bases"]  # type: ignore[assignment]

    active_y = {1, 3, 5, 7, 11, 13}
    assert x_vertices == (0, 2, 4, 6, 8, 10, 12)
    assert len(q_vertices) == 8
    assert len(bases) == 112
    assert {cost(base, x_vertices, active_y) for base in bases} == {7}

    # W is the root together with the other shore of the four parallel
    # retained dual labels.  It contains the two primal two-cut edges.
    cut = {edge(0, 15), edge(7, 8)}
    candidates = []
    for other in q_vertices:
        if other == root:
            continue
        region = frozenset({root, other})
        labels = {
            label
            for label, (left, right) in q_ends.items()
            if left in region and right in region
        }
        if cut <= labels:
            candidates.append((region, labels))
    assert len(candidates) == 1
    W, internal_labels = candidates[0]
    assert W == frozenset({1, 5})
    assert internal_labels == {
        edge(0, 15),
        edge(7, 8),
        edge(8, 11),
        edge(12, 15),
    }

    # The literal strict one-leaf dual: z_W=1, alpha_8=2, all other
    # block potentials one.  Every edge inequality is checked directly.
    alpha = {x: 2 if x == 8 else 1 for x in x_vertices}
    x_side = set(x_vertices)
    for label in ground:
        x = next(vertex for vertex in label if vertex in x_side)
        y = next(vertex for vertex in label if vertex not in x_side)
        depth = int(label in internal_labels)
        assert alpha[x] - depth <= int(y in active_y)
    dual_value = sum(alpha.values()) - (len(W) - 1)
    assert dual_value == 7 > len(active_y) == 6

    # Two cost-six X-block transversals.  If a laminar certificate avoiding
    # W had value >6, weak duality against each transversal would force its
    # positive support to contain a region violated by that transversal.
    first = frozenset(
        {
            edge(0, 15),
            edge(1, 2),
            edge(4, 5),
            edge(5, 6),
            edge(7, 8),
            edge(10, 13),
            edge(11, 12),
        }
    )
    second = frozenset(
        {
            edge(0, 1),
            edge(1, 2),
            edge(4, 5),
            edge(5, 6),
            edge(7, 8),
            edge(10, 13),
            edge(12, 15),
        }
    )
    for support in (first, second):
        assert support <= ground
        assert all(len(support & set(blocks[x])) == 1 for x in x_vertices)
        assert cost(support, x_vertices, active_y) == 6

    proper_regions = tuple(
        frozenset(region)
        for size in range(1, len(q_vertices))
        for region in combinations(q_vertices, size)
        if frozenset(region) != W
    )

    def violated_by(support: frozenset[Edge]) -> set[frozenset[int]]:
        return {
            region
            for region in proper_regions
            if internal_count(support, region, q_ends) > len(region) - 1
        }

    first_violations = {
        frozenset({1, 5, 7}),
        frozenset({1, 5, 6, 7}),
    }
    second_violations = {
        frozenset({0, 1, 5}),
        frozenset({0, 1, 2, 5}),
        frozenset({0, 1, 2, 4, 5}),
        frozenset({0, 1, 2, 3, 4, 5}),
    }
    assert violated_by(first) == first_violations
    assert violated_by(second) == second_violations
    assert all(crosses(left, right) for left in first_violations for right in second_violations)

    # The quantifier "some other certificate" is strictly weaker if the
    # replacement need not remain laminar.  In fact this model has the
    # following W-free value-seven replacement.  Its two regions cross, so
    # uncrossing necessarily leaves the W-free class.
    crossing_regions = (frozenset({0, 1, 5}), frozenset({1, 5, 7}))
    crossing_alpha = dict(zip(x_vertices, (2, 1, 1, 1, 3, 1, 2), strict=True))
    for label in ground:
        x = next(vertex for vertex in label if vertex in x_side)
        y = next(vertex for vertex in label if vertex not in x_side)
        depth = sum(
            left in region and right in region
            for region in crossing_regions
            for left, right in (q_ends[label],)
        )
        assert crossing_alpha[x] - depth <= int(y in active_y)
    crossing_value = sum(crossing_alpha.values()) - sum(
        len(region) - 1 for region in crossing_regions
    )
    assert crossing_value == 7
    assert all(region != W for region in crossing_regions)
    assert crosses(*crossing_regions)


def verify_degree_pattern_strict_countermodel() -> None:
    """Verify a strict abstract countermodel with literal FEC block costs.

    The partition incidence is K=F-{u,a} for an explicit simple plane cubic
    bipartite graph F and the 0/1 cost is one literal Y-block.  The separate
    planar multigraph Q has the correct rank and block cardinalities, but its
    labelled endpoints are deliberately not the contracted dual of that
    embedding.  This isolates the missing joint primal-dual rotation datum.
    """

    # A 14-vertex simple plane cubic bipartite completion of the block
    # incidence.  X={0,...,6}, Y={7,...,13}; u=6 and a=13.
    neighbours = {
        7: (0, 1, 3),
        8: (0, 2, 4),
        9: (0, 2, 5),
        10: (1, 3, 6),
        11: (1, 4, 6),
        12: (3, 5, 6),
        13: (2, 4, 5),
    }
    graph = nx.Graph()
    graph.add_nodes_from(range(14))
    for y, x_neighbours in neighbours.items():
        graph.add_edges_from((x, y) for x in x_neighbours)
    site = (6, 11, 4, 13)
    assert not graph.is_multigraph()
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.node_connectivity(graph) == 3
    assert has_oriented_common_face(graph, site)

    # It is not a brace: the independent edges 0--7 and 4--11 do not extend
    # to a perfect matching.
    remainder = graph.copy()
    remainder.remove_nodes_from({0, 7, 4, 11})
    maximum = nx.algorithms.matching.max_weight_matching(remainder, maxcardinality=True)
    assert len(maximum) < len(remainder) // 2

    reduced = graph.copy()
    reduced.remove_nodes_from({6, 13})
    ground = frozenset(edge(left, right) for left, right in reduced.edges())
    x_vertices = tuple(range(6))
    y_vertices = tuple(range(7, 13))
    blocks = {
        x: tuple(sorted(label for label in ground if x in label)) for x in x_vertices
    }
    y_blocks = {
        y: tuple(sorted(label for label in ground if y in label)) for y in y_vertices
    }
    assert tuple(sorted(map(len, blocks.values()))) == (2, 2, 2, 3, 3, 3)
    assert tuple(sorted(map(len, y_blocks.values()))) == (2, 2, 2, 3, 3, 3)
    assert set(y_blocks[7]) == {edge(0, 7), edge(1, 7), edge(3, 7)}

    # A separate planar rank graph Q.  Parallel copies only fill the literal
    # degree-two/degree-three block cardinalities and do not alter the core.
    q_ends: dict[Edge, tuple[int, int]] = {
        edge(0, 7): (0, 6),
        edge(0, 8): (0, 1),
        edge(0, 9): (0, 1),
        edge(1, 7): (2, 4),
        edge(1, 10): (1, 2),
        edge(1, 11): (1, 2),
        edge(2, 8): (0, 2),
        edge(2, 9): (0, 2),
        edge(3, 7): (3, 6),
        edge(3, 10): (3, 4),
        edge(3, 12): (3, 4),
        edge(4, 8): (4, 5),
        edge(4, 11): (4, 5),
        edge(5, 9): (3, 5),
        edge(5, 12): (3, 5),
    }
    assert set(q_ends) == set(ground)
    q_graph = nx.MultiGraph()
    q_graph.add_nodes_from(range(7))
    q_graph.add_edges_from(q_ends.values())
    assert nx.is_connected(q_graph)
    assert nx.check_planarity(nx.Graph(q_graph))[0]

    # The chosen q_ends are not the actual contracted-dual endpoints of the
    # displayed embedding.  Thus the model retains the two marginal
    # structures but not their joint rotation compatibility.
    actual_q_ends, _actual_root = contracted_dual(graph, site)
    actual_vertices = tuple(
        sorted({vertex for ends in actual_q_ends.values() for vertex in ends})
    )
    desired_vertices = tuple(range(7))
    assert len(actual_vertices) == len(desired_vertices)
    labelled_isomorphism_exists = any(
        all(
            {mapping[left], mapping[right]} == set(q_ends[label])
            for label, (left, right) in actual_q_ends.items()
        )
        for image in permutations(desired_vertices)
        for mapping in (
            dict(zip(actual_vertices, image, strict=True)),
        )
    )
    assert not labelled_isomorphism_exists

    transversals = {
        frozenset(choice)
        for choice in product(*(blocks[x] for x in x_vertices))
        if len(frozenset(choice)) == len(x_vertices)
    }

    def is_tree(support: frozenset[Edge]) -> bool:
        candidate = nx.MultiGraph()
        candidate.add_nodes_from(range(7))
        candidate.add_edges_from(q_ends[label] for label in support)
        return nx.is_tree(candidate)

    bases = tuple(support for support in transversals if is_tree(support))
    active_y = {7}
    assert len(bases) == 32
    assert {cost(base, x_vertices, active_y) for base in bases} == {2}

    left_triangle = frozenset({0, 1, 2})
    right_triangle = frozenset({3, 4, 5})
    assert left_triangle.isdisjoint(right_triangle)

    # z_left=z_right=1 and alpha_x=1 is a strict laminar certificate:
    # 6 - (3-1) - (3-1) = 2 > |A|=1.
    for label in ground:
        x = next(vertex for vertex in label if vertex in x_vertices)
        y = next(vertex for vertex in label if vertex in y_vertices)
        depth = sum(
            left in region and right in region
            for region in (left_triangle, right_triangle)
            for left, right in (q_ends[label],)
        )
        assert 1 - depth <= int(y in active_y)
    assert len(x_vertices) - 2 * (3 - 1) == 2 > len(active_y) == 1

    # This cost-one X-transversal has exactly one violated proper graphic
    # rank inequality, namely the left triangle.  Therefore every dual with
    # z_left=0 has value at most one, whether or not its support is laminar.
    witness = frozenset(
        {
            edge(0, 8),
            edge(1, 10),
            edge(2, 8),
            edge(3, 7),
            edge(4, 8),
            edge(5, 9),
        }
    )
    assert all(len(witness & set(blocks[x])) == 1 for x in x_vertices)
    assert cost(witness, x_vertices, active_y) == 1
    regions = tuple(
        frozenset(region)
        for size in range(1, 7)
        for region in combinations(range(7), size)
    )
    violations = {
        region
        for region in regions
        if internal_count(witness, region, q_ends) > len(region) - 1
    }
    assert violations == {left_triangle}


def main() -> None:
    verify_fixed_brace_has_no_strict_defect()
    verify_two_cut_leaf_is_laminar_indispensable()
    verify_degree_pattern_strict_countermodel()
    print("fixed genuine brace: 128/128 layers have no strict defect")
    print("two-cut model: unrestricted crossing escape exists, laminar escape does not")
    print("degree-pattern model: a size-three leaf is indispensable even unrestricted")
    print("SMALL_LAMINAR_LEAF_BOUNDARIES_VERIFIED")


if __name__ == "__main__":
    main()
