#!/usr/bin/env python3
"""Verify exact reductions for unrestricted three-Hamilton witnesses.

This is a bounded diagnostic on the fixed order-26 graph of Note 027.  It
does not scan graphs, sites, or orders.  Besides reproducing the unrestricted
three-witness incidences, it verifies:

* the arbitrary-cut dual formula for multi-component disagreements;
* the factorisation of the two rooted choices after (W,T) is fixed;
* the restricted graph K Hall/tree split; and
* a literal (1,2)-component witness in which two disjoint C4 matching flips
  have to be made simultaneously to obtain the Hamilton target.
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path
import sys

import networkx as nx

PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from units.barnette.computations.verify_full_family_good_bridge_counterexample import (
    CHILD_GRAPH6,
    TARGET_SITE,
    all_edges,
    alternating_component_count,
    connected_complement,
    edge,
    faces,
    perfect_matchings,
)


Edge = tuple[int, int]
Matching = frozenset[Edge]


SELECTED_L = frozenset(
    {
        (0, 13), (1, 12), (2, 11), (3, 19), (4, 16), (5, 17),
        (6, 15), (7, 21), (8, 14), (9, 18), (10, 20),
        (22, 25), (23, 24),
    }
)
SELECTED_W = frozenset(
    {
        (0, 12), (1, 20), (2, 11), (3, 19), (4, 13), (5, 17),
        (6, 16), (7, 21), (8, 14), (9, 18), (10, 15),
        (22, 25), (23, 24),
    }
)
SELECTED_R = frozenset(
    {
        (0, 11), (1, 20), (2, 16), (3, 12), (4, 13), (5, 17),
        (6, 15), (7, 14), (8, 21), (9, 19), (10, 18),
        (22, 25), (23, 24),
    }
)
SELECTED_T0 = frozenset(
    {
        (0, 12), (1, 20), (2, 11), (3, 18), (4, 13), (5, 21),
        (6, 14), (7, 17), (8, 19), (9, 15), (22, 25), (23, 24),
    }
)
SELECTED_TARGET = frozenset(
    {
        (0, 12), (1, 20), (2, 11), (3, 18), (4, 13), (5, 17),
        (6, 14), (7, 21), (8, 19), (9, 15), (22, 23), (24, 25),
    }
)


def residual_graph(
    graph: nx.Graph,
    edges: frozenset[Edge],
    p: Edge,
    h: Edge,
    near: Matching,
) -> nx.Graph:
    residual = nx.Graph()
    residual.add_nodes_from(graph)
    residual.add_edges_from(edges - {p, h} - near)
    return residual


def residual_cycle_count(
    graph: nx.Graph,
    edges: frozenset[Edge],
    p: Edge,
    h: Edge,
    near: Matching,
) -> int:
    # The residual has n vertices and n-1 edges and is one terminal path
    # plus cycles.  Hence the number of cycles is components-1.
    return nx.number_connected_components(
        residual_graph(graph, edges, p, h, near)
    ) - 1


def planar_dual_data(
    embedding: nx.PlanarEmbedding,
) -> tuple[tuple[tuple[int, ...], ...], dict[tuple[int, int], int]]:
    facial_walks = faces(embedding)
    directed_face: dict[tuple[int, int], int] = {}
    for face_id, face in enumerate(facial_walks):
        for index, first in enumerate(face):
            second = face[(index + 1) % len(face)]
            directed_face[first, second] = face_id
    return facial_walks, directed_face


def dual_ends(
    item: Edge, directed_face: dict[tuple[int, int], int]
) -> tuple[int, int]:
    first, second = item
    return directed_face[first, second], directed_face[second, first]


def matching_colouring(
    dual_order: int,
    edges: frozenset[Edge],
    matching: Matching,
    directed_face: dict[tuple[int, int], int],
    root: int,
) -> tuple[int, ...]:
    """Recover the normalized admissible dual 2-colouring of a matching."""
    adjacency: list[list[tuple[int, int]]] = [[] for _ in range(dual_order)]
    for item in edges:
        first, second = dual_ends(item, directed_face)
        # A primal matching edge is dual-monochromatic; every other dual edge
        # is bichromatic.
        difference = 0 if item in matching else 1
        adjacency[first].append((second, difference))
        adjacency[second].append((first, difference))

    colours: list[int | None] = [None] * dual_order
    colours[root] = 0
    pending = [root]
    while pending:
        first = pending.pop()
        assert colours[first] is not None
        for second, difference in adjacency[first]:
            candidate = colours[first] ^ difference
            if colours[second] is None:
                colours[second] = candidate
                pending.append(second)
            else:
                assert colours[second] == candidate
    assert all(value is not None for value in colours)
    return tuple(int(value) for value in colours)


def induced_component_count(graph: nx.Graph, shore: set[int]) -> int:
    if not shore:
        return 0
    return nx.number_connected_components(graph.subgraph(shore))


def quotient_identity(
    graph: nx.Graph,
    edges: frozenset[Edge],
    p: Edge,
    h: Edge,
    initial: Matching,
    flipped_edges: frozenset[Edge],
) -> tuple[int, int, int]:
    """Return (mu of pieces, mu of quotient, components of final residual)."""
    initial_residual = residual_graph(graph, edges, p, h, initial)
    removed = flipped_edges - initial
    inserted = flipped_edges & initial

    pieces = initial_residual.copy()
    pieces.remove_edges_from(removed)
    components = tuple(nx.connected_components(pieces))
    owner = {
        vertex: component_id
        for component_id, component in enumerate(components)
        for vertex in component
    }
    piece_mu = sum(
        pieces.subgraph(component).number_of_edges() - len(component) + 1
        for component in components
    )

    quotient = nx.MultiGraph()
    quotient.add_nodes_from(range(len(components)))
    for first, second in inserted:
        quotient.add_edge(owner[first], owner[second])
    quotient_components = nx.number_connected_components(quotient)
    quotient_mu = (
        quotient.number_of_edges()
        - quotient.number_of_nodes()
        + quotient_components
    )

    final = initial ^ flipped_edges
    final_residual = residual_graph(graph, edges, p, h, final)
    final_mu = (
        final_residual.number_of_edges()
        - final_residual.number_of_nodes()
        + nx.number_connected_components(final_residual)
    )
    assert final_mu == piece_mu + quotient_mu
    assert nx.number_connected_components(final_residual) == quotient_components
    return piece_mu, quotient_mu, quotient_components


def main() -> None:
    graph = nx.from_graph6_bytes(CHILD_GRAPH6)
    planar, embedding = nx.check_planarity(graph)
    assert planar
    edges = all_edges(graph)
    u, v, z, a = TARGET_SITE
    p, h = edge(u, v), edge(z, a)

    perfect = tuple(perfect_matchings(graph))
    hamilton = tuple(
        matching
        for matching in perfect
        if connected_complement(graph, edges, matching)
    )
    layers = {
        bits: tuple(
            matching
            for matching in hamilton
            if f"{int(p in matching)}{int(h in matching)}" == bits
        )
        for bits in ("00", "01", "10", "11")
    }
    assert {bits: len(family) for bits, family in layers.items()} == {
        "00": 34,
        "01": 2,
        "10": 4,
        "11": 4,
    }

    reduced = graph.copy()
    reduced.remove_nodes_from((u, a))
    targets = tuple(
        near
        for near in perfect_matchings(reduced)
        if nx.is_connected(residual_graph(graph, edges, p, h, near))
    )
    assert len(targets) == 12

    # Once (W,T) is fixed, unrestricted L and R choices factor completely.
    side_profiles: Counter[tuple[bool, bool]] = Counter()
    successful_pairs = 0
    for middle in layers["00"]:
        for target in targets:
            outside = target - middle
            left_ok = any(not (outside & (first ^ middle)) for first in layers["01"])
            right_ok = any(not (outside & (last ^ middle)) for last in layers["10"])
            side_profiles[left_ok, right_ok] += 1
            successful_pairs += int(left_ok and right_ok)
    assert side_profiles == {
        (False, False): 321,
        (False, True): 42,
        (True, False): 33,
        (True, True): 12,
    }
    assert successful_pairs == 12

    # Dual arbitrary-cut formula.  For D={dual vertices on which the two
    # normalized colourings differ}, the number of primal alternating cycles
    # is c(Delta[D])+c(Delta-D)-1.  The root patterns are exactly the four
    # (p,h)-membership layers.
    facial_walks, directed_face = planar_dual_data(embedding)
    dual = nx.Graph()
    dual.add_nodes_from(range(len(facial_walks)))
    for item in edges:
        dual.add_edge(*dual_ends(item, directed_face))
    p_ends, h_ends = dual_ends(p, directed_face), dual_ends(h, directed_face)
    common = set(p_ends) & set(h_ends)
    assert len(common) == 1
    q = common.pop()
    alpha = next(item for item in p_ends if item != q)
    beta = next(item for item in h_ends if item != q)
    colourings = {
        matching: matching_colouring(
            len(facial_walks), edges, matching, directed_face, q
        )
        for matching in hamilton
    }
    expected_roots = {
        "00": (1, 0, 1),
        "01": (1, 0, 0),
        "10": (0, 0, 1),
        "11": (0, 0, 0),
    }
    for bits, family in layers.items():
        assert {
            (colourings[item][alpha], colourings[item][q], colourings[item][beta])
            for item in family
        } == {expected_roots[bits]}

    all_dual_vertices = set(dual)
    for middle in layers["00"]:
        middle_colouring = colourings[middle]
        for other in layers["01"] + layers["10"]:
            shore = {
                vertex
                for vertex in dual
                if middle_colouring[vertex] != colourings[other][vertex]
            }
            predicted = (
                induced_component_count(dual, shore)
                + induced_component_count(dual, all_dual_vertices - shore)
                - 1
            )
            assert predicted == alternating_component_count(middle, other)

        for target in targets:
            outside = target - middle
            # S* is a forest because it is a subset of the target dual tree.
            s_dual = nx.Graph()
            s_dual.add_nodes_from(dual)
            s_dual.add_edges_from(dual_ends(item, directed_face) for item in outside)
            assert nx.is_forest(s_dual)
            s_components = {
                vertex: component_id
                for component_id, component in enumerate(nx.connected_components(s_dual))
                for vertex in component
            }
            for other in layers["01"] + layers["10"]:
                shore = {
                    vertex
                    for vertex in dual
                    if middle_colouring[vertex] != colourings[other][vertex]
                }
                descends_to_quotient = all(
                    (first in shore) == (second in shore)
                    for first, second in s_dual.edges()
                )
                assert descends_to_quotient == (not bool(outside & other))
                # Explicitly keep the component map live: every admissible
                # flip avoiding S is a 0/1 choice on these quotient vertices.
                if descends_to_quotient:
                    for first, second in s_dual.edges():
                        assert s_components[first] == s_components[second]

    # Restricted K = W union (E-(L union R)).  A triple succeeds precisely
    # when K-{u,a} has a perfect matching whose residual is connected.
    restricted_split: Counter[tuple[bool, bool]] = Counter()
    bridge_split: Counter[tuple[bool, bool]] = Counter()
    minimum_residual: Counter[tuple[int, int]] = Counter()
    general_successes: list[tuple[Matching, Matching, Matching, tuple[Matching, ...]]] = []
    component_profiles: Counter[tuple[int, int]] = Counter()
    target_degrees: Counter[Matching] = Counter()
    for first in layers["01"]:
        for middle in layers["00"]:
            for last in layers["10"]:
                restricted_edges = middle | (edges - (first | last))
                restricted_graph = nx.Graph()
                restricted_graph.add_nodes_from(graph)
                restricted_graph.add_edges_from(restricted_edges)
                restricted_graph.remove_nodes_from((u, a))
                restricted_matchings = tuple(perfect_matchings(restricted_graph))
                compatible_targets = tuple(
                    target for target in targets if target <= restricted_edges
                )
                assert set(compatible_targets) == {
                    near
                    for near in restricted_matchings
                    if residual_cycle_count(graph, edges, p, h, near) == 0
                }
                split_key = (bool(restricted_matchings), bool(compatible_targets))
                restricted_split[split_key] += 1
                if (
                    alternating_component_count(first, middle) == 1
                    and alternating_component_count(middle, last) == 1
                ):
                    bridge_split[split_key] += 1
                if restricted_matchings:
                    minimum_residual[
                        min(
                            residual_cycle_count(graph, edges, p, h, near)
                            for near in restricted_matchings
                        ),
                        len(restricted_matchings),
                    ] += 1
                if compatible_targets:
                    general_successes.append(
                        (first, middle, last, compatible_targets)
                    )
                    component_profiles[
                        alternating_component_count(first, middle),
                        alternating_component_count(middle, last),
                    ] += len(compatible_targets)
                    target_degrees.update(compatible_targets)

    assert restricted_split == {
        (False, False): 176,
        (True, False): 72,
        (True, True): 24,
    }
    assert bridge_split == {(False, False): 20, (True, False): 8}
    assert len(general_successes) == 24
    assert sum(len(item[3]) for item in general_successes) == 30
    assert component_profiles == {
        (1, 2): 10,
        (1, 3): 3,
        (2, 1): 1,
        (2, 2): 4,
        (2, 3): 6,
        (3, 2): 3,
        (3, 3): 3,
    }
    assert sorted(target_degrees[target] for target in targets) == [0] * 9 + [10] * 3
    assert sum(
        count for (minimum, _), count in minimum_residual.items() if minimum == 0
    ) == 24
    assert sum(
        count for (minimum, _), count in minimum_residual.items() if minimum == 1
    ) == 48
    assert sum(
        count for (minimum, _), count in minimum_residual.items() if minimum == 2
    ) == 24

    # Freeze one sharp (1,2) witness.  Its restricted fibre has 15 matchings
    # and three targets.  From T0 the displayed target requires two disjoint
    # C4 flips: either flip alone leaves a 4-cycle, while both give the
    # Hamilton v-z path.
    assert SELECTED_L in layers["01"]
    assert SELECTED_W in layers["00"]
    assert SELECTED_R in layers["10"]
    assert alternating_component_count(SELECTED_L, SELECTED_W) == 1
    assert alternating_component_count(SELECTED_W, SELECTED_R) == 2
    selected_k = SELECTED_W | (edges - (SELECTED_L | SELECTED_R))
    selected_graph = nx.Graph()
    selected_graph.add_nodes_from(graph)
    selected_graph.add_edges_from(selected_k)
    selected_graph.remove_nodes_from((u, a))
    selected_matchings = tuple(perfect_matchings(selected_graph))
    assert len(selected_matchings) == 15
    assert SELECTED_T0 in selected_matchings
    assert SELECTED_TARGET in selected_matchings
    assert sum(
        residual_cycle_count(graph, edges, p, h, near) == 0
        for near in selected_matchings
    ) == 3
    assert sorted(
        len(component)
        for component in nx.connected_components(
            residual_graph(graph, edges, p, h, SELECTED_T0)
        )
    ) == [4, 4, 18]
    assert nx.is_connected(
        residual_graph(graph, edges, p, h, SELECTED_TARGET)
    )

    difference = nx.Graph()
    difference.add_edges_from(SELECTED_T0 ^ SELECTED_TARGET)
    flip_cycles = tuple(
        frozenset(
            edge(*item)
            for item in difference.subgraph(component).edges()
        )
        for component in nx.connected_components(difference)
    )
    assert sorted(len(cycle) for cycle in flip_cycles) == [4, 4]
    for cycle in flip_cycles:
        intermediate = SELECTED_T0 ^ cycle
        assert sorted(
            len(component)
            for component in nx.connected_components(
                residual_graph(graph, edges, p, h, intermediate)
            )
        ) == [4, 22]
        quotient_identity(graph, edges, p, h, SELECTED_T0, cycle)
    both = flip_cycles[0] | flip_cycles[1]
    assert SELECTED_T0 ^ both == SELECTED_TARGET
    assert quotient_identity(graph, edges, p, h, SELECTED_T0, both) == (0, 0, 1)

    print("restricted_split", dict(restricted_split))
    print("bridge_split", dict(bridge_split))
    print("successful_triples_incidences", len(general_successes), sum(component_profiles.values()))
    print("component_profiles", dict(component_profiles))
    print("sharp_profile", (1, 2), "restricted_matchings", len(selected_matchings))
    print("sharp_simultaneous_flips", sorted(len(cycle) for cycle in flip_cycles))
    print("MULTICOMPONENT_THREE_WITNESS_REDUCTION_VERIFIED")


if __name__ == "__main__":
    main()
