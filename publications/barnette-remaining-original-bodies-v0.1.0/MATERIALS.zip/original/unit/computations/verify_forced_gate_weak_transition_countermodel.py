#!/usr/bin/env python3
"""Verify the Note 068 bad quotient and a weakened transition countermodel.

The two-state trace at the end is deliberately abstract: each vertex carries
the genuine Note 068 rooted boundary quotient, while the edge is a remote
gate-avoiding p=q=1 target transition that leaves that quotient unchanged.
It is not asserted to be jointly realizable by one plane brace.  Its purpose
is only to show that local quotient admissibility, forced gate bits, ordinary
connectedness, and the scalar p/q transition test do not imply a lift.
"""

from __future__ import annotations

import json

import networkx as nx


REDUCED_EDGES = (
    (0, 1), (0, 2), (0, 3), (0, 4),
    (1, 2), (1, 3), (1, 6), (1, 8), (1, 9),
    (2, 4), (2, 5), (2, 7), (2, 8),
    (3, 4), (3, 5), (3, 6), (3, 7), (3, 10), (3, 11),
    (4, 5), (5, 7),
    (6, 9), (6, 11),
    (7, 8), (7, 9), (7, 10),
    (8, 9),
    (9, 10), (9, 11),
    (10, 11),
)
COLOUR = {
    0: 0, 1: 1, 2: 0, 3: 0, 4: 1, 5: 0,
    6: 0, 7: 1, 8: 0, 9: 1, 10: 0, 11: 1,
}
Z = 3
ROTATION = (0, 1, 6, 11, 10, 7, 5, 4)
LEFT_ARC = (0, 1, 6, 11, 10)
RIGHT_ARC = (10, 7, 5, 4, 0)
GATES = (0, 10)
ROOT = (0, 2)
VALID_ROWS = ("001", "011", "101", "110", "111")


class DisjointSet:
    def __init__(self, vertices):
        self.parent = {vertex: vertex for vertex in vertices}

    def find(self, vertex):
        while self.parent[vertex] != vertex:
            self.parent[vertex] = self.parent[self.parent[vertex]]
            vertex = self.parent[vertex]
        return vertex

    def add_edge(self, first, second) -> bool:
        left, right = self.find(first), self.find(second)
        if left == right:
            return False
        self.parent[left] = right
        return True


def rooted_partition():
    reduced = nx.Graph(REDUCED_EDGES)
    mono = nx.Graph()
    mono.add_nodes_from(reduced)
    mono.add_edges_from(
        (first, second)
        for first, second in reduced.edges()
        if COLOUR[first] == COLOUR[second]
    )
    assert nx.number_connected_components(mono) == 3
    assert len(nx.cycle_basis(mono)) == 1
    mono.remove_edge(*ROOT)
    assert nx.is_forest(mono) and nx.number_connected_components(mono) == 3
    mono.remove_node(Z)
    components = tuple(
        frozenset(component)
        for component in nx.connected_components(mono)
    )
    assert len(components) == 6
    component_of = {
        vertex: index
        for index, component in enumerate(components)
        for vertex in component
    }
    return components, component_of


def quotient_profile(row: str, component_of: dict[int, int]):
    left, right, centre = map(int, row)
    component_vertices = set(component_of.values())
    local_vertices = {"x1", "x3", "v"}
    dsu = DisjointSet(component_vertices | local_vertices)
    edges = []

    def add(first, second):
        edges.append((first, second))

    for vertex in LEFT_ARC:
        if COLOUR[vertex] == left:
            add("x1", component_of[vertex])
    for vertex in RIGHT_ARC:
        if COLOUR[vertex] == right:
            add("x3", component_of[vertex])
    if centre == left:
        add("v", "x1")
    if centre == right:
        add("v", "x3")
    for gate in GATES:
        if centre == COLOUR[gate]:
            add("v", component_of[gate])

    forest = True
    for first, second in edges:
        forest &= dsu.add_edge(first, second)
    root_connected = dsu.find(component_of[ROOT[0]]) == dsu.find(
        component_of[ROOT[1]]
    )
    return {
        "row": row,
        "edges": edges,
        "forest": forest,
        "root_connected": root_connected,
        "target_lift": forest and root_connected,
    }


def main() -> None:
    components, component_of = rooted_partition()
    profiles = [quotient_profile(row, component_of) for row in VALID_ROWS]
    assert not any(profile["target_lift"] for profile in profiles)

    boundary_signature = {
        "rotation": ROTATION,
        "colours": tuple(COLOUR[vertex] for vertex in ROTATION),
        "component_ids": tuple(component_of[vertex] for vertex in ROTATION),
        "root_component_ids": tuple(component_of[vertex] for vertex in ROOT),
        "both_gates_used": all(COLOUR[gate] == COLOUR[Z] for gate in GATES),
        "rows": profiles,
    }
    assert boundary_signature["colours"] == (0, 1, 0, 1, 0, 1, 0, 1)
    assert boundary_signature["both_gates_used"]

    # This is an axiomatic product trace, not a graph-realization claim.
    abstract_trace = {
        "vertices": (
            {"name": "u0", "state": boundary_signature},
            {"name": "u1", "state": boundary_signature},
        ),
        "edges": (
            {
                "ends": ("u0", "u1"),
                "single_alternating_cycle": True,
                "avoids_root_and_gates": True,
                "p": 1,
                "q": 1,
                "root_separation_preserved": True,
                "boundary_partition_unchanged": True,
            },
        ),
        "connected": True,
        "gates_forced_at_every_vertex": True,
        "contains_liftable_state": False,
        "joint_plane_brace_realizability": "not claimed",
    }
    assert abstract_trace["connected"]
    assert abstract_trace["gates_forced_at_every_vertex"]
    assert not abstract_trace["contains_liftable_state"]
    assert all(item["p"] == item["q"] for item in abstract_trace["edges"])

    print(json.dumps({
        "P_components": [sorted(component) for component in components],
        "boundary_signature": boundary_signature,
        "abstract_trace": abstract_trace,
    }, indent=2, sort_keys=True))
    print("FORCED_GATE_WEAK_TRANSITION_AXIOMS_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()
