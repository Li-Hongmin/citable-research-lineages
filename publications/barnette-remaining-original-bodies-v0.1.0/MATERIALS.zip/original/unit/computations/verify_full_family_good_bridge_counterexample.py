#!/usr/bin/env python3
"""Certificate for a full-family good-bridge counterexample and its child.

Starting from the frozen order-22 brace, perform exactly one legal C4
expansion on the facial edges 20-2 and 11-1.  At the inherited legal site
(u,v,z,a)=(16,2,20,10), the order-26 child has global H^{+-}, genuine
targets, and compatible single-cycle bridges, but its *complete* family of
Hamilton-complement perfect matchings contains no good bridge.

Expanding that inherited site once more gives an order-30 brace which still
has global H^{+-}. Its complete Hamilton family uses all six traversal
types, and deleting any one complete type family destroys H^{+-}.

This verifier is self-contained apart from NetworkX graph primitives. It
does not import the exploratory scan or any previous matching enumerator.
"""

from __future__ import annotations

from itertools import combinations

import networkx as nx


PARENT_GRAPH6 = b"U?????????[?s?b??[?CoI_?L??_o?`_@_G?@W??"
CHILD_GRAPH6 = b"Y?????????S?s?b??[?CoI_?L??_o?`_@?G?@W????@C??@?@?@O??A_"
EXPANSION_SITE = (20, 2, 11, 1)
TARGET_SITE = (16, 2, 20, 10)
GRANDCHILD_GRAPH6 = (
    b"]?????????S?s?b??[?CoA_?L??_o?`_@???@W????@C??@?@?@O??A_"
    b"?@?@???@???GC?G??g"
)

Edge = tuple[int, int]
Matching = frozenset[Edge]


def edge(x: int, y: int) -> Edge:
    return (x, y) if x < y else (y, x)


def perfect_matchings(graph: nx.Graph):
    """Enumerate every perfect matching by exact branching."""
    def visit(remaining: frozenset[int], chosen: tuple[Edge, ...]):
        if not remaining:
            yield frozenset(chosen)
            return
        first = min(
            remaining,
            key=lambda x: sum(y in remaining for y in graph[x]),
        )
        for second in sorted(graph[first]):
            if second in remaining:
                yield from visit(
                    remaining - {first, second},
                    chosen + (edge(first, second),),
                )

    yield from visit(frozenset(graph), ())


def all_edges(graph: nx.Graph) -> frozenset[Edge]:
    return frozenset(edge(x, y) for x, y in graph.edges())


def connected_complement(
    graph: nx.Graph, edges: frozenset[Edge], matching: Matching
) -> bool:
    complement = nx.Graph()
    complement.add_nodes_from(graph)
    complement.add_edges_from(edges - matching)
    return nx.is_connected(complement)


def one_cycle(first: Matching, second: Matching) -> bool:
    difference = first ^ second
    if not difference:
        return False
    support = nx.Graph()
    support.add_edges_from(difference)
    return nx.is_connected(support) and set(dict(support.degree()).values()) == {2}


def alternating_component_count(first: Matching, second: Matching) -> int:
    difference = nx.Graph()
    difference.add_edges_from(first ^ second)
    return nx.number_connected_components(difference)


def expand(graph: nx.Graph, site: tuple[int, int, int, int]) -> nx.Graph:
    u, v, x, y = site
    child = graph.copy()
    child.remove_edge(u, v)
    child.remove_edge(x, y)
    a = max(child) + 1
    b, c, d = a + 1, a + 2, a + 3
    child.add_edges_from(
        ((u, a), (a, b), (b, v), (x, c), (c, d), (d, y), (a, d), (b, c))
    )
    return child


def faces(embedding: nx.PlanarEmbedding) -> tuple[tuple[int, ...], ...]:
    used: set[tuple[int, int]] = set()
    answer = []
    for x, y in embedding.edges():
        if (x, y) not in used:
            answer.append(tuple(embedding.traverse_face(x, y, used)))
    return tuple(answer)


def has_oriented_site(
    embedding: nx.PlanarEmbedding, site: tuple[int, int, int, int]
) -> bool:
    u, v, z, a = site
    for face in faces(embedding):
        for oriented in (face, tuple(reversed(face))):
            size = len(oriented)
            for i in range(size):
                if (oriented[i], oriented[(i + 1) % size]) != (u, v):
                    continue
                for step in range(2, size - 1):
                    j = (i + step) % size
                    if (oriented[j], oriented[(j + 1) % size]) == (z, a):
                        # The two residual face paths have odd length, or
                        # equivalently the two directed edge positions have
                        # the same parity.
                        if step % 2 == 0:
                            return True
    return False


def is_two_extendable(perfect: tuple[Matching, ...], edges: frozenset[Edge]) -> bool:
    for first, second in combinations(edges, 2):
        if set(first).isdisjoint(second):
            if not any(first in matching and second in matching for matching in perfect):
                return False
    return True


def global_h_plus_minus(
    edges: frozenset[Edge], hamilton: tuple[Matching, ...]
) -> bool:
    return all(
        any(first not in matching and second in matching for matching in hamilton)
        for first in edges
        for second in edges
        if first != second
    )


def main() -> None:
    parent = nx.from_graph6_bytes(PARENT_GRAPH6)
    parent_planar, parent_embedding = nx.check_planarity(parent)
    assert parent_planar
    assert has_oriented_site(parent_embedding, EXPANSION_SITE)

    child = expand(parent, EXPANSION_SITE)
    assert nx.to_graph6_bytes(child, header=False).strip() == CHILD_GRAPH6
    assert len(child) == 26 and child.number_of_edges() == 39
    assert not child.is_multigraph()
    assert nx.is_connected(child)
    assert set(dict(child.degree()).values()) == {3}
    assert nx.is_bipartite(child)
    child_planar, child_embedding = nx.check_planarity(child)
    assert child_planar
    assert nx.node_connectivity(child) == 3
    assert has_oriented_site(child_embedding, TARGET_SITE)

    edges = all_edges(child)
    perfect = tuple(perfect_matchings(child))
    assert len(perfect) == 253
    assert is_two_extendable(perfect, edges)

    hamilton = tuple(
        matching
        for matching in perfect
        if connected_complement(child, edges, matching)
    )
    assert len(hamilton) == 44

    # Global H^{+-}: the complementary Hamilton cycle contains e and avoids
    # f exactly when its matching omits e and contains f.
    assert global_h_plus_minus(edges, hamilton)

    u, v, z, a = TARGET_SITE
    p, h = edge(u, v), edge(z, a)
    layers = {
        bits: tuple(
            matching
            for matching in hamilton
            if f"{int(p in matching)}{int(h in matching)}" == bits
        )
        for bits in ("00", "01", "10", "11")
    }
    assert {bits: len(family) for bits, family in layers.items()} == {
        "00": 34,
        "01": 2,
        "10": 4,
        "11": 4,
    }

    reduced = child.copy()
    reduced.remove_nodes_from((u, a))
    targets = []
    for near in perfect_matchings(reduced):
        residual = nx.Graph()
        residual.add_nodes_from(child)
        residual.add_edges_from(edges - {p, h} - near)
        if nx.is_connected(residual):
            targets.append(near)
    targets = tuple(targets)
    assert len(targets) == 12

    left = {
        middle: tuple(first for first in layers["01"] if one_cycle(first, middle))
        for middle in layers["00"]
    }
    right = {
        middle: tuple(last for last in layers["10"] if one_cycle(middle, last))
        for middle in layers["00"]
    }
    bridges = tuple(
        (first, middle, last)
        for middle in layers["00"]
        for first in left[middle]
        for last in right[middle]
    )
    assert len(bridges) == 28

    good_pairs = []
    direct_successes = []
    for middle in layers["00"]:
        for target in targets:
            outside = target - middle
            left_ok = tuple(
                first for first in left[middle] if not (outside & (first ^ middle))
            )
            right_ok = tuple(
                last for last in right[middle] if not (outside & (last ^ middle))
            )
            if left_ok and right_ok:
                good_pairs.append((middle, target))
    for first, middle, last in bridges:
        allowed = edges - (first | middle | last)
        if any(target - middle <= allowed for target in targets):
            direct_successes.append((first, middle, last))

    assert not good_pairs
    assert not direct_successes
    assert targets and bridges

    # Dropping only the single-cycle adjacency requirement restores the
    # three-witness common-complement mechanism.
    general_successes = []
    component_profiles: dict[tuple[int, int], int] = {}
    for first in layers["01"]:
        for middle in layers["00"]:
            for last in layers["10"]:
                allowed = edges - (first | middle | last)
                compatible = tuple(
                    target
                    for target in targets
                    if target - middle <= allowed
                )
                if compatible:
                    left_components = alternating_component_count(first, middle)
                    right_components = alternating_component_count(middle, last)
                    general_successes.append(
                        (first, middle, last, compatible)
                    )
                    key = (left_components, right_components)
                    component_profiles[key] = (
                        component_profiles.get(key, 0) + len(compatible)
                    )
    assert len(general_successes) == 24
    assert sum(len(item[3]) for item in general_successes) == 30
    assert component_profiles == {
        (1, 2): 10,
        (1, 3): 3,
        (2, 1): 1,
        (2, 2): 4,
        (2, 3): 6,
        (3, 2): 3,
        (3, 3): 3,
    }

    grandchild = expand(child, TARGET_SITE)
    assert nx.to_graph6_bytes(grandchild, header=False).strip() == GRANDCHILD_GRAPH6
    assert len(grandchild) == 30 and grandchild.number_of_edges() == 45
    assert nx.is_connected(grandchild)
    assert set(dict(grandchild.degree()).values()) == {3}
    assert nx.is_bipartite(grandchild)
    assert nx.check_planarity(grandchild)[0]
    assert nx.node_connectivity(grandchild) == 3

    grand_edges = all_edges(grandchild)
    grand_perfect = tuple(perfect_matchings(grandchild))
    assert len(grand_perfect) == 552
    assert is_two_extendable(grand_perfect, grand_edges)
    grand_hamilton = tuple(
        matching
        for matching in grand_perfect
        if connected_complement(grandchild, grand_edges, matching)
    )
    assert len(grand_hamilton) == 84
    assert global_h_plus_minus(grand_edges, grand_hamilton)

    # New vertices are a,b,c,d in the standard C4-expansion notation.
    a_new, b_new, c_new, d_new = 26, 27, 28, 29
    gadget_edges = tuple(
        edge(*item)
        for item in (
            (u, a_new),
            (a_new, b_new),
            (b_new, v),
            (z, c_new),
            (c_new, d_new),
            (d_new, a),
            (a_new, d_new),
            (b_new, c_new),
        )
    )
    traversal_rows = {
        "A": "11111100",
        "B": "10101011",
        "C": "01010111",
        "D": "01111010",
        "E": "11001101",
        "L": "10110111",
    }
    row_to_type = {row: kind for kind, row in traversal_rows.items()}
    by_type: dict[str, list[Matching]] = {
        kind: [] for kind in traversal_rows
    }
    for matching in grand_hamilton:
        complement = grand_edges - matching
        row = "".join("1" if item in complement else "0" for item in gadget_edges)
        assert row in row_to_type
        by_type[row_to_type[row]].append(matching)

    assert {kind: len(family) for kind, family in by_type.items()} == {
        "A": 34,
        "B": 2,
        "C": 4,
        "D": 12,
        "E": 8,
        "L": 24,
    }
    # Every complete traversal family is genuinely used: removing all
    # members of any one type leaves at least one ordered edge pair uncovered.
    for omitted in traversal_rows:
        retained = tuple(
            matching
            for kind, family in by_type.items()
            if kind != omitted
            for matching in family
        )
        assert not global_h_plus_minus(grand_edges, retained)

    print("parent_order", len(parent))
    print("expansion_site", EXPANSION_SITE)
    print("child_graph6", CHILD_GRAPH6.decode())
    print("child_order_edges", len(child), child.number_of_edges())
    print("perfect_hamilton", len(perfect), len(hamilton))
    print("layers", {bits: len(family) for bits, family in layers.items()})
    print("targets_bridges_good", len(targets), len(bridges), len(direct_successes))
    print("general_three_witness_successes", len(general_successes), component_profiles)
    print("grandchild_perfect_hamilton", len(grand_perfect), len(grand_hamilton))
    print("grandchild_traversal_types", {kind: len(family) for kind, family in by_type.items()})
    print("FULL_FAMILY_GOOD_BRIDGE_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
