#!/usr/bin/env python3
"""Verify integral two-point paid-exit discharge through order eighteen.

The scan uses one representative of every ordered-site automorphism orbit
in the five actual braces through order eighteen.  It checks all integral
X-block transversals with a unique two-point rank violation, all eligible
binary layers, all boundary completions, and the full one-block common-base
exchange graph.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

import networkx as nx


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "verify_no_strict_binary_defect_through_order_sixteen.py"
SPEC = spec_from_file_location("paid_exit_base", BASE_PATH)
assert SPEC is not None and SPEC.loader is not None
BASE = module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)

Edge = tuple[int, int]
Site = tuple[int, int, int, int]

GRAPHS = (
    (8, "G?zTb_"),
    (12, "K??FEagT@WB_"),
    (16, "O????B_sDOI_I_DO@W?M?"),
    (16, "O????B_sCWKOI_BOAW?i?"),
    (18, "Q??????wE_P_W_IO@g?h?Cg?B_?"),
)


def site_orbits(graph: nx.Graph) -> tuple[set[Site], dict[Site, tuple[Site, ...]]]:
    sites = BASE.ordered_legal_sites(graph)
    automorphisms = tuple(
        nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter()
    )
    grouped: dict[Site, list[Site]] = defaultdict(list)
    for site in sites:
        representative = min(
            tuple(mapping[vertex] for vertex in site) for mapping in automorphisms
        )
        grouped[representative].append(site)
    return sites, {
        representative: tuple(sorted(members))
        for representative, members in grouped.items()
    }


def common_base_graph(data: dict[str, object]):
    x_vertices = data["x_vertices"]
    blocks = data["blocks"]
    bases = data["bases"]
    assert isinstance(x_vertices, tuple)
    assert isinstance(blocks, dict)
    assert isinstance(bases, tuple)

    signatures = tuple(
        tuple(next(label for label in blocks[x] if label in base) for x in x_vertices)
        for base in bases
    )
    signature_index = {signature: index for index, signature in enumerate(signatures)}
    base_index = {base: index for index, base in enumerate(bases)}
    adjacency = [set() for _ in bases]
    for index, signature in enumerate(signatures):
        for position, x in enumerate(x_vertices):
            for label in blocks[x]:
                if label == signature[position]:
                    continue
                candidate = (
                    signature[:position] + (label,) + signature[position + 1 :]
                )
                other = signature_index.get(candidate)
                if other is not None:
                    adjacency[index].add(other)
    return signatures, base_index, tuple(tuple(sorted(row)) for row in adjacency)


def exact_violations(
    transversal: frozenset[Edge],
    q_vertices: tuple[int, ...],
    q_ends: dict[Edge, tuple[int, int]],
) -> tuple[frozenset[int], ...]:
    violations = []
    order = len(q_vertices)
    for mask in range(1, (1 << order) - 1):
        shore = frozenset(
            q_vertices[index] for index in range(order) if mask >> index & 1
        )
        internal = sum(
            left in shore and right in shore
            for left, right in (q_ends[label] for label in transversal)
        )
        if internal > len(shore) - 1:
            violations.append(shore)
    return tuple(violations)


def unique_two_point_violation(
    transversal: frozenset[Edge],
    q_vertices: tuple[int, ...],
    q_ends: dict[Edge, tuple[int, int]],
) -> frozenset[int] | None:
    """Recognize the isolated-double-edge plus exterior-tree normal form."""
    endpoint_counts = Counter(tuple(sorted(q_ends[label])) for label in transversal)
    repeated = [pair for pair, count in endpoint_counts.items() if count >= 2]
    if len(repeated) != 1 or endpoint_counts[repeated[0]] != 2:
        return None
    shore = frozenset(repeated[0])

    selected = nx.MultiGraph()
    selected.add_nodes_from(q_vertices)
    selected.add_edges_from(q_ends[label] for label in transversal)
    components = [set(component) for component in nx.connected_components(selected)]
    if len(components) != 2 or set(shore) not in components:
        return None
    exterior = next(component for component in components if component != set(shore))
    if not nx.is_tree(selected.subgraph(exterior)):
        return None
    assert exact_violations(transversal, q_vertices, q_ends) == (shore,)
    return shore


def distances_to_low_cost(
    loads: tuple[tuple[int, ...], ...],
    active_mask: int,
    threshold: int,
    adjacency: tuple[tuple[int, ...], ...],
):
    layer_order = len(loads[0])
    low = {
        index
        for index, load in enumerate(loads)
        if sum(
            load[position]
            for position in range(layer_order)
            if active_mask >> position & 1
        )
        <= threshold
    }
    assert low
    distance: list[int | None] = [None] * len(loads)
    toward_low: list[int | None] = [None] * len(loads)
    queue = deque(sorted(low))
    for index in low:
        distance[index] = 0
    while queue:
        current = queue.popleft()
        assert distance[current] is not None
        for neighbour in adjacency[current]:
            if distance[neighbour] is None:
                distance[neighbour] = distance[current] + 1
                toward_low[neighbour] = current
                queue.append(neighbour)
    return distance, toward_low, low


def main() -> None:
    statistics: Counter[str] = Counter()
    distance_distribution: Counter[int] = Counter()
    deficits_by_order: Counter[int] = Counter()
    first_distance_one = None
    first_distance_two = None

    for order, graph6 in GRAPHS:
        graph = nx.from_graph6_bytes(graph6.encode())
        assert nx.is_bipartite(graph)
        assert nx.check_planarity(graph)[0]
        assert nx.node_connectivity(graph) == 3
        assert BASE.UTILITY.is_two_extendable(graph)
        sites, orbits = site_orbits(graph)
        statistics["ordered_sites"] += len(sites)
        statistics["site_orbits"] += len(orbits)

        for site, orbit_members in sorted(orbits.items()):
            orbit_size = len(orbit_members)
            data = BASE.UTILITY.partition_data(graph, site)
            x_vertices = data["x_vertices"]
            blocks = data["blocks"]
            q_ends = data["q_ends"]
            q_vertices = data["q_vertices"]
            bases = data["bases"]
            transversals = data["transversals"]
            assert isinstance(x_vertices, tuple)
            assert isinstance(blocks, dict)
            assert isinstance(q_ends, dict)
            assert isinstance(q_vertices, tuple)
            assert isinstance(bases, tuple)
            assert isinstance(transversals, set)
            x_side = set(x_vertices)

            colour = nx.bipartite.color(graph)
            u, _v, _z, a = site
            y_vertices = tuple(
                sorted(
                    vertex
                    for vertex in graph
                    if colour[vertex] != colour[u] and vertex != a
                )
            )
            y_index = {vertex: index for index, vertex in enumerate(y_vertices)}

            signatures, base_index, adjacency = common_base_graph(data)
            base_loads = []
            for base in bases:
                load = [0] * len(y_vertices)
                for label in base:
                    y = next(vertex for vertex in label if vertex not in x_side)
                    load[y_index[y]] += 1
                base_loads.append(tuple(load))
            base_loads = tuple(base_loads)
            distance_cache = {}

            for transversal in sorted(transversals, key=lambda support: tuple(sorted(support))):
                statistics["transversals_representative"] += 1
                statistics["transversals_unquotiented"] += orbit_size
                shore = unique_two_point_violation(
                    transversal, q_vertices, q_ends
                )
                if shore is None:
                    continue
                statistics["unique_pairs_representative"] += 1
                statistics["unique_pairs_unquotiented"] += orbit_size

                removable = []
                for internal_label in transversal:
                    if not set(q_ends[internal_label]) <= shore:
                        continue
                    x = next(
                        vertex
                        for vertex in x_vertices
                        if internal_label in blocks[vertex]
                    )
                    exits = tuple(
                        label
                        for label in blocks[x]
                        if len(set(q_ends[label]) & shore) == 1
                    )
                    if exits:
                        removable.append((internal_label, exits))
                assert removable

                completions = set()
                for internal_label, exits in removable:
                    for exit_label in exits:
                        completion = frozenset(
                            (set(transversal) - {internal_label}) | {exit_label}
                        )
                        assert completion in base_index
                        completions.add(base_index[completion])
                assert completions

                transversal_load = [0] * len(y_vertices)
                for label in transversal:
                    y = next(vertex for vertex in label if vertex not in x_side)
                    transversal_load[y_index[y]] += 1

                for active_mask in range(1 << len(y_vertices)):
                    active_size = active_mask.bit_count()
                    initial_cost = sum(
                        transversal_load[position]
                        for position in range(len(y_vertices))
                        if active_mask >> position & 1
                    )
                    if initial_cost > active_size:
                        continue
                    statistics["eligible_layers_representative"] += 1
                    statistics["eligible_layers_unquotiented"] += orbit_size

                    kappas = []
                    for internal_label, exits in removable:
                        internal_y = next(
                            vertex
                            for vertex in internal_label if vertex not in x_side
                        )
                        internal_cost = int(active_mask >> y_index[internal_y] & 1)
                        exit_cost = min(
                            int(
                                active_mask
                                >> y_index[
                                    next(
                                        vertex
                                        for vertex in exit_label
                                        if vertex not in x_side
                                    )
                                ]
                                & 1
                            )
                            for exit_label in exits
                        )
                        kappas.append(exit_cost - internal_cost)
                    rho = min(kappas)
                    slack = active_size - initial_cost
                    if rho <= slack:
                        continue

                    assert (rho, slack) == (1, 0)
                    statistics["deficits_representative"] += 1
                    statistics["deficits_unquotiented"] += orbit_size
                    deficits_by_order[order] += orbit_size

                    if active_mask not in distance_cache:
                        distance_cache[active_mask] = distances_to_low_cost(
                            base_loads, active_mask, active_size, adjacency
                        )
                    distance, toward_low, low = distance_cache[active_mask]
                    attainable = sorted(
                        (distance[index], index)
                        for index in completions
                        if distance[index] is not None
                    )
                    assert attainable
                    shortest, start = attainable[0]
                    assert shortest is not None
                    distance_distribution[shortest] += orbit_size

                    path = [start]
                    while path[-1] not in low:
                        next_index = toward_low[path[-1]]
                        assert next_index is not None
                        path.append(next_index)
                    record = {
                        "order": order,
                        "graph6": graph6,
                        "site": site,
                        "W": tuple(sorted(shore)),
                        "R": tuple(sorted(transversal)),
                        "A": tuple(
                            y_vertices[position]
                            for position in range(len(y_vertices))
                            if active_mask >> position & 1
                        ),
                        "distance": shortest,
                        "path": tuple(signatures[index] for index in path),
                    }
                    if shortest == 1 and first_distance_one is None:
                        first_distance_one = record
                    if shortest == 2 and first_distance_two is None:
                        first_distance_two = record

    assert statistics == {
        "ordered_sites": 616,
        "site_orbits": 42,
        "transversals_representative": 56136,
        "transversals_unquotiented": 700848,
        "unique_pairs_representative": 338,
        "unique_pairs_unquotiented": 4064,
        "eligible_layers_representative": 44160,
        "eligible_layers_unquotiented": 517752,
        "deficits_representative": 2470,
        "deficits_unquotiented": 29104,
    }
    assert deficits_by_order == {8: 48, 12: 360, 16: 8560, 18: 20136}
    assert distance_distribution == {1: 28760, 2: 344}
    assert first_distance_one is not None
    assert first_distance_one["order"] == 8
    assert first_distance_two is not None
    assert first_distance_two["order"] == 16
    print("INTEGRAL_PAID_EXIT_DISCHARGE_VERIFIED_THROUGH_18")


if __name__ == "__main__":
    main()
