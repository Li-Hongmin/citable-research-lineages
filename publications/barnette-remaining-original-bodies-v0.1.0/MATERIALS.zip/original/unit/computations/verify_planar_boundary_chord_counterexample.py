#!/usr/bin/env python3
"""Exact verifier for a planar boundary-chord counterexample."""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations, combinations_with_replacement, product

import networkx as nx


GRAPH6 = "O????B_sDOI_I_DO@W?M?"
ROOT = 0
PORTS = (8, 9, 10)
SINGLETON = 8
PAIRED = (9, 10)
X_SIDE = tuple(range(8, 16))
Y_FULL = tuple(range(8))
Y_ORDER = tuple(range(1, 8))

# One fixed plane embedding: eight quadrilateral faces and two octagons.
FACES = (
    (0, 8, 2, 10),
    (0, 9, 1, 8),
    (1, 9, 3, 11),
    (2, 12, 4, 10),
    (3, 13, 5, 11),
    (4, 12, 6, 14),
    (5, 13, 7, 15),
    (6, 15, 7, 14),
    (0, 10, 4, 14, 7, 13, 3, 9),
    (1, 11, 5, 15, 6, 12, 2, 8),
)

Edge = tuple[int, int]
Forest = frozenset[Edge]
Vector = tuple[int, ...]


SUPPORT: tuple[Forest, ...] = (
    frozenset(
        ((1, 9), (1, 11), (2, 8), (3, 11), (3, 13), (4, 10),
         (4, 12), (4, 14), (5, 13), (5, 15), (6, 12), (6, 15),
         (7, 14))
    ),
    frozenset(
        ((1, 8), (2, 10), (2, 12), (3, 9), (3, 11), (3, 13),
         (4, 14), (5, 11), (5, 15), (6, 12), (6, 15), (7, 13),
         (7, 14))
    ),
    frozenset(
        ((1, 9), (1, 11), (2, 8), (3, 13), (4, 10), (4, 12),
         (5, 11), (5, 13), (5, 15), (6, 12), (6, 14), (7, 14),
         (7, 15))
    ),
    frozenset(
        ((1, 9), (1, 11), (2, 8), (3, 11), (3, 13), (4, 10),
         (4, 12), (4, 14), (5, 15), (6, 12), (7, 13), (7, 14),
         (7, 15))
    ),
    frozenset(
        ((1, 9), (1, 11), (2, 8), (3, 11), (3, 13), (4, 10),
         (4, 12), (5, 15), (6, 12), (6, 14), (6, 15), (7, 13),
         (7, 14))
    ),
)

EXPECTED_DEGREES = (
    (2, 1, 2, 3, 2, 2, 1),
    (1, 2, 3, 1, 2, 2, 2),
    (2, 1, 1, 2, 3, 2, 2),
    (2, 1, 2, 3, 1, 1, 3),
    (2, 1, 2, 2, 1, 3, 2),
)
WEIGHTS = tuple(Fraction(value, 7) for value in (1, 2, 2, 1, 1))

# If state i is omitted, the corresponding nonnegative lambda has
# strictly positive dot product with every remaining excess vector.
OMISSION_SEPARATORS = (
    (0, 0, 1, 0, 2, 3, 6),
    (0, 0, 0, 4, 1, 2, 0),
    (0, 0, 5, 3, 0, 2, 1),
    (0, 0, 2, 1, 3, 4, 0),
    (0, 0, 5, 4, 6, 0, 3),
)


def edge(a: int, b: int) -> Edge:
    return (a, b) if a < b else (b, a)


def strict_hall(graph: nx.Graph, side: tuple[int, ...]) -> bool:
    for size in range(1, len(side) - 1):
        for shore in combinations(side, size):
            neighbours = set().union(*(set(graph[x]) for x in shore))
            if len(neighbours) < size + 2:
                return False
    return True


def port_blocks(forest: nx.Graph) -> tuple[tuple[int, ...], ...]:
    return tuple(
        sorted(
            (
                tuple(sorted(set(component) & set(PORTS)))
                for component in nx.connected_components(forest)
            ),
            key=lambda block: (len(block), block),
        )
    )


def enumerate_fibre(graph: nx.Graph) -> tuple[Forest, ...]:
    pole_vertices = tuple(sorted(set(graph) - {ROOT}))
    pole = graph.subgraph(pole_vertices)
    choices = []
    for x in X_SIDE:
        required = 1 if x in PORTS else 2
        incident = tuple(sorted(edge(x, y) for y in pole[x]))
        choices.append(
            tuple(frozenset(selected) for selected in combinations(incident, required))
        )

    fibre = []
    for local_selection in product(*choices):
        selected = frozenset().union(*local_selection)
        forest = nx.Graph()
        forest.add_nodes_from(pole_vertices)
        forest.add_edges_from(selected)
        if not nx.is_forest(forest) or nx.number_connected_components(forest) != 2:
            continue
        if port_blocks(forest) == ((SINGLETON,), PAIRED):
            fibre.append(selected)
    return tuple(sorted(fibre, key=lambda item: tuple(sorted(item))))


def degree_vector(forest: Forest) -> Vector:
    return tuple(sum(y in selected for selected in forest) for y in Y_ORDER)


def excess(vector: Vector) -> Vector:
    return tuple(value - 2 for value in vector)


def compatible(first: Vector, second: Vector) -> bool:
    return all(a + b <= 4 for a, b in zip(first, second, strict=True))


def same_x_pivot(first: Forest, second: Forest) -> bool:
    if len(first ^ second) != 2:
        return False
    removed = next(iter(first - second))
    added = next(iter(second - first))
    removed_x = next(v for v in removed if v in X_SIDE)
    added_x = next(v for v in added if v in X_SIDE)
    return removed_x == added_x


def degree_repair_candidates(
    graph: nx.Graph, source: Forest, partner: Forest
) -> tuple[tuple[Edge, Edge], ...]:
    """All graph-edge same-X transfers that could repair this ordered pair."""

    pair_sum = tuple(
        a + b for a, b in zip(excess(degree_vector(source)), excess(degree_vector(partner)), strict=True)
    )
    positive = tuple(index for index, value in enumerate(pair_sum) if value > 0)
    if len(positive) != 1 or pair_sum[positive[0]] != 1:
        return ()
    removed_y = Y_ORDER[positive[0]]
    slack_y = {Y_ORDER[index] for index, value in enumerate(pair_sum) if value <= -1}
    pole_edges = {edge(a, b) for a, b in graph.edges() if ROOT not in (a, b)}
    candidates = []
    for removed in source:
        if removed_y not in removed:
            continue
        x = next(vertex for vertex in removed if vertex in X_SIDE)
        for added in pole_edges - source:
            if x not in added:
                continue
            added_y = next(vertex for vertex in added if vertex not in X_SIDE)
            if added_y in slack_y:
                candidates.append((removed, added))
    return tuple(sorted(candidates))


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert len(graph) == 16 and graph.number_of_edges() == 24
    assert nx.number_of_selfloops(graph) == 0
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    directed_face_edges = tuple(
        (face[index], face[(index + 1) % len(face)])
        for face in FACES
        for index in range(len(face))
    )
    assert len(FACES) == 2 + graph.number_of_edges() - len(graph)
    assert len(directed_face_edges) == len(set(directed_face_edges)) == 2 * graph.number_of_edges()
    assert set(directed_face_edges) == {
        directed for a, b in graph.edges() for directed in ((a, b), (b, a))
    }
    assert tuple(sorted(graph[ROOT])) == PORTS

    colour = nx.bipartite.color(graph)
    assert tuple(sorted(v for v in graph if colour[v] == colour[ROOT])) == Y_FULL
    assert tuple(sorted(set(graph) - set(Y_FULL))) == X_SIDE
    assert strict_hall(graph, X_SIDE) and strict_hall(graph, Y_FULL)

    fibre = enumerate_fibre(graph)
    assert len(fibre) == len(set(fibre)) == 86
    assert all(forest in fibre for forest in SUPPORT)
    degrees = tuple(degree_vector(forest) for forest in SUPPORT)
    assert degrees == EXPECTED_DEGREES
    excesses = tuple(excess(vector) for vector in degrees)

    expected_excess = tuple(
        sum(weight * vector[coordinate] for weight, vector in zip(WEIGHTS, excesses, strict=True))
        for coordinate in range(len(Y_ORDER))
    )
    assert expected_excess == (
        Fraction(-2, 7), Fraction(-5, 7), Fraction(0), Fraction(0),
        Fraction(0), Fraction(0), Fraction(0),
    )

    # Exact Farkas certificates establish inclusion-minimality.  Every
    # proper subfamily omits at least one state and is separated from the
    # nonpositive box by that state's omission separator.
    for omitted, separator in enumerate(OMISSION_SEPARATORS):
        assert all(value >= 0 for value in separator)
        for index, vector in enumerate(excesses):
            if index == omitted:
                continue
            assert sum(a * b for a, b in zip(separator, vector, strict=True)) > 0

    assert all(
        not compatible(degrees[i], degrees[j])
        for i, j in combinations_with_replacement(range(len(SUPPORT)), 2)
    )

    # There are only six degree-capable directed repair transfers.  One is
    # not a two-component forest; the other five cross the prescribed port
    # partition.  This is the compact fundamental-cut obstruction behind
    # the exhaustive pivot check below.
    expected_candidates = {
        (0, 1): (((3, 13), (7, 13)),),
        (1, 0): (((3, 9), (1, 9)), ((3, 11), (1, 11))),
        (1, 2): (((5, 11), (1, 11)),),
        (2, 4): (((6, 12), (2, 12)),),
        (4, 2): (((6, 12), (2, 12)),),
    }
    actual_candidates = {
        (i, j): degree_repair_candidates(graph, SUPPORT[i], SUPPORT[j])
        for i in range(len(SUPPORT))
        for j in range(len(SUPPORT))
        if degree_repair_candidates(graph, SUPPORT[i], SUPPORT[j])
    }
    assert actual_candidates == expected_candidates
    failed_repair_status = {}
    for pair, transfers in actual_candidates.items():
        for transfer in transfers:
            source = SUPPORT[pair[0]]
            removed, added = transfer
            candidate = frozenset((source - {removed}) | {added})
            candidate_graph = nx.Graph()
            candidate_graph.add_nodes_from(set(graph) - {ROOT})
            candidate_graph.add_edges_from(candidate)
            if not nx.is_forest(candidate_graph) or nx.number_connected_components(candidate_graph) != 2:
                failed_repair_status[(pair, transfer)] = "not_two_component_forest"
            else:
                blocks = port_blocks(candidate_graph)
                assert blocks != ((SINGLETON,), PAIRED)
                failed_repair_status[(pair, transfer)] = blocks
    assert tuple(failed_repair_status.values()).count("not_two_component_forest") == 1
    assert len(failed_repair_status) == 6

    pivot = nx.Graph()
    pivot.add_nodes_from(range(len(fibre)))
    pivot.add_edges_from(
        (i, j)
        for i, j in combinations(range(len(fibre)), 2)
        if same_x_pivot(fibre[i], fibre[j])
    )
    assert pivot.number_of_edges() == 217 and nx.is_connected(pivot)
    support_indices = tuple(fibre.index(forest) for forest in SUPPORT)
    assert support_indices == (48, 16, 61, 51, 54)
    assert tuple(pivot.degree(index) for index in support_indices) == (5, 5, 5, 6, 5)

    compatible_boundary_hits = []
    for source in support_indices:
        for neighbour in pivot[source]:
            for partner in support_indices:
                if compatible(degree_vector(fibre[neighbour]), degree_vector(fibre[partner])):
                    compatible_boundary_hits.append((source, neighbour, partner))
    assert compatible_boundary_hits == []

    print(
        {
            "graph6": GRAPH6,
            "root": ROOT,
            "port_split": ((SINGLETON,), PAIRED),
            "full_fibre_forests": len(fibre),
            "full_pivot_edges": pivot.number_of_edges(),
            "support_indices": support_indices,
            "support_pivot_degrees": tuple(pivot.degree(index) for index in support_indices),
            "weights": tuple(str(weight) for weight in WEIGHTS),
            "degrees": degrees,
            "expected_excess": tuple(str(value) for value in expected_excess),
            "compatible_boundary_hits": tuple(compatible_boundary_hits),
            "degree_capable_repair_transfers": len(failed_repair_status),
            "boundary_chord": False,
        }
    )
    print("PLANAR_BOUNDARY_CHORD_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
