#!/usr/bin/env python3
"""Verify the finite incidence core of the six-label cycle--cut obstruction."""

from collections import defaultdict
from itertools import product


LABELS = tuple(f"e{index}" for index in range(6))

X_BLOCKS = {
    "D0": ("e0", "e1"),
    "D1": ("e2", "e3"),
    "D2": ("e4", "e5"),
}
Y_BLOCKS = {
    "C0": ("e3", "e4"),
    "C1": ("e0", "e2"),
    "C2": ("e1", "e5"),
}
Q_ENDS = {
    "e0": (1, 2),
    "e1": (1, 2),
    "e2": (1, 2),
    "e3": (2, 3),
    "e4": (3, 4),
    "e5": (1, 3),
}


def endpoint_map(blocks: dict[str, tuple[str, ...]]) -> dict[str, str]:
    endpoints: dict[str, str] = {}
    for vertex, labels in blocks.items():
        for label in labels:
            assert label not in endpoints
            endpoints[label] = vertex
    assert set(endpoints) == set(LABELS)
    return endpoints


def main() -> None:
    left = endpoint_map(X_BLOCKS)
    right = endpoint_map(Y_BLOCKS)

    primal_adjacency: dict[str, set[str]] = defaultdict(set)
    for label in LABELS:
        primal_adjacency[left[label]].add(right[label])
        primal_adjacency[right[label]].add(left[label])

    assert len(primal_adjacency) == 6
    assert {len(neighbours) for neighbours in primal_adjacency.values()} == {2}
    seen: set[str] = set()
    stack = [next(iter(primal_adjacency))]
    while stack:
        vertex = stack.pop()
        if vertex in seen:
            continue
        seen.add(vertex)
        stack.extend(primal_adjacency[vertex] - seen)
    assert len(seen) == 6

    triangle_labels = ("e0", "e3", "e5")
    assert {
        tuple(sorted(Q_ENDS[label])) for label in triangle_labels
    } == {(1, 2), (2, 3), (1, 3)}

    q_vertices = tuple(sorted({vertex for ends in Q_ENDS.values() for vertex in ends}))
    valid_cut_colours = []
    for bits in product((0, 1), repeat=len(q_vertices)):
        side = dict(zip(q_vertices, bits, strict=True))
        if all(side[left_end] != side[right_end] for left_end, right_end in Q_ENDS.values()):
            valid_cut_colours.append(side)
    assert valid_cut_colours == []

    print("primal_core=C6")
    print("contracted_dual_odd_core=12,23,13")
    print("valid_cut_colours=0")
    print("SIX_LABEL_CYCLE_CUT_OBSTRUCTION_VERIFIED")


if __name__ == "__main__":
    main()
