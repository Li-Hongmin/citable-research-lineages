#!/usr/bin/env python3
"""Probe the three-base exchange graph of the Note 062 plane brace."""

from collections import deque
from itertools import combinations, product


def edge(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


FACES = (
    (0, 8, 2, 10),
    (0, 9, 1, 8),
    (1, 9, 3, 11),
    (2, 12, 4, 10),
    (3, 13, 5, 11),
    (4, 12, 6, 14),
    (5, 13, 7, 15),
    (6, 15, 7, 14),
    (0, 10, 4, 14, 7, 13, 3, 9),
    (1, 11, 5, 15, 6, 12, 2, 8),
)
EDGES = frozenset(
    edge(u, v)
    for face in FACES
    for u, v in zip(face, face[1:] + face[:1])
)
X = tuple(range(8, 16))
Y = frozenset(range(8))
ROOT = 0
S, A, B = 8, 9, 10
DA, DB = edge(ROOT, A), edge(ROOT, B)
ROOT_EDGES = frozenset(edge(ROOT, x) for x in (S, A, B))
E0 = frozenset(EDGES - ROOT_EDGES)

H_TRAP = frozenset(
    (
        edge(1, 9),
        edge(2, 8),
        edge(2, 10),
        edge(3, 11),
        edge(4, 12),
        edge(5, 13),
        edge(6, 15),
        edge(7, 14),
    )
)
H_NEAREST_GOOD = frozenset(
    (
        edge(1, 9),
        edge(2, 8),
        edge(3, 11),
        edge(4, 10),
        edge(5, 13),
        edge(5, 15),
        edge(6, 12),
        edge(7, 14),
    )
)
H_CHAIN_1 = (H_TRAP - {edge(2, 10)}) | {edge(4, 10)}
H_CHAIN_2 = (H_CHAIN_1 - {edge(4, 12)}) | {edge(6, 12)}


def verify_plane_brace() -> None:
    adjacency = {vertex: set() for vertex in range(16)}
    for u, v in EDGES:
        adjacency[u].add(v)
        adjacency[v].add(u)
    assert len(EDGES) == 24
    assert all(len(adjacency[vertex]) == 3 for vertex in adjacency)
    assert all((u < 8) != (v < 8) for u, v in EDGES)
    assert 16 - len(EDGES) + len(FACES) == 2
    darts = [
        (u, v)
        for face in FACES
        for u, v in zip(face, face[1:] + face[:1])
    ]
    expected_darts = {(u, v) for u, v in EDGES} | {(v, u) for u, v in EDGES}
    assert len(darts) == len(set(darts)) and set(darts) == expected_darts

    successor = {vertex: {} for vertex in range(16)}
    for face in FACES:
        for previous, vertex, following in zip(face[-1:] + face[:-1], face, face[1:] + face[:1]):
            successor[vertex][previous] = following
    for vertex, rotation in successor.items():
        start = next(iter(rotation))
        orbit = [start]
        while rotation[orbit[-1]] != start:
            orbit.append(rotation[orbit[-1]])
        assert len(orbit) == 3 and set(orbit) == adjacency[vertex]

    # Strict Hall on both colour classes is the bipartite 2-extendability
    # criterion.  Only subsets of size at most |side|-2 need checking.
    for side in (tuple(range(8)), tuple(range(8, 16))):
        for size in range(1, len(side) - 1):
            for subset in combinations(side, size):
                neighbours = set().union(*(adjacency[v] for v in subset))
                assert len(neighbours) >= size + 2


def dual_endpoints() -> dict[tuple[int, int], tuple[int, int]]:
    incident: dict[tuple[int, int], list[int]] = {label: [] for label in EDGES}
    for index, face in enumerate(FACES):
        for u, v in zip(face, face[1:] + face[:1]):
            incident[edge(u, v)].append(index)
    assert all(len(indices) == 2 for indices in incident.values())
    return {label: tuple(indices) for label, indices in incident.items()}


DUAL_ENDS = dual_endpoints()


def dual_tree(labels: frozenset[tuple[int, int]]) -> bool:
    if len(labels) != len(FACES) - 1:
        return False
    adjacency = {index: set() for index in range(len(FACES))}
    for label in labels:
        u, v = DUAL_ENDS[label]
        adjacency[u].add(v)
        adjacency[v].add(u)
    reached = {0}
    queue = [0]
    while queue:
        u = queue.pop()
        for v in adjacency[u] - reached:
            reached.add(v)
            queue.append(v)
    return len(reached) == len(FACES)


def free_face(labels: frozenset[tuple[int, int]]) -> int | None:
    load = {y: 0 for y in Y}
    for u, v in labels:
        y = u if u in Y else v
        load[y] += 1
    candidates = [y for y in Y - {ROOT} if load[y] == 2]
    if load[ROOT] != 0 or len(candidates) != 1:
        return None
    free = candidates[0]
    return free if all(load[y] == 1 for y in Y - {ROOT, free}) else None


def x_partition_base(labels: frozenset[tuple[int, int]]) -> bool:
    load = {x: 0 for x in X}
    for u, v in labels:
        x = u if u in load else v
        load[x] += 1
    return all(value == 1 for value in load.values())


def y_partition_base(labels: frozenset[tuple[int, int]], free: int) -> bool:
    load = {y: 0 for y in Y}
    for u, v in labels:
        y = u if u in load else v
        load[y] += 1
    return (
        load[ROOT] == 0
        and load[free] == 2
        and all(load[y] == 1 for y in Y - {ROOT, free})
    )


def all_load_states() -> tuple[frozenset[tuple[int, int]], ...]:
    choices = tuple(tuple(sorted(e for e in E0 if x in e)) for x in X)
    result = []
    for selected in product(*choices):
        labels = frozenset(selected)
        if len(labels) == len(X) and free_face(labels) is not None:
            result.append(labels)
    return tuple(result)


def main() -> None:
    verify_plane_brace()
    assert len(E0) == 21
    load_states = all_load_states()
    three = frozenset(state for state in load_states if dual_tree(state | {DA}))
    four = frozenset(state for state in three if dual_tree(state | {DB}))
    bad = three - four

    adjacency = {state: set() for state in three}
    for state in three:
        for removed in state:
            x = removed[0] if removed[0] in X else removed[1]
            for added in E0 - state:
                if x not in added:
                    continue
                candidate = (state - {removed}) | {added}
                if candidate in three:
                    adjacency[state].add(candidate)

    isolated_bad = tuple(state for state in bad if not adjacency[state])
    bad_without_good_neighbour = tuple(
        state for state in bad if adjacency[state].isdisjoint(four)
    )

    components = []
    unseen = set(three)
    while unseen:
        start = next(iter(unseen))
        component = {start}
        queue = deque((start,))
        unseen.remove(start)
        while queue:
            state = queue.popleft()
            for other in adjacency[state]:
                if other not in component:
                    component.add(other)
                    unseen.discard(other)
                    queue.append(other)
        components.append(frozenset(component))

    bad_components = tuple(component for component in components if component.isdisjoint(four))

    assert len(load_states) == 106
    assert len(three) == 32 and len(four) == 8
    assert H_TRAP in bad
    assert H_NEAREST_GOOD in four
    assert len(adjacency[H_TRAP]) == 1
    assert H_CHAIN_1 in bad and H_CHAIN_2 in bad
    assert H_CHAIN_1 in adjacency[H_TRAP]
    assert H_CHAIN_2 in adjacency[H_CHAIN_1]
    assert H_NEAREST_GOOD in adjacency[H_CHAIN_2]

    distance = {H_TRAP: 0}
    queue = deque((H_TRAP,))
    nearest = None
    while queue:
        state = queue.popleft()
        if state in four:
            nearest = state
            break
        for other in adjacency[state]:
            if other not in distance:
                distance[other] = distance[state] + 1
                queue.append(other)
    assert nearest is not None
    assert distance[nearest] == 3
    assert min(distance[state] for state in four if state in distance) == 3

    # Pairwise Helly check for the same actual plane brace and fixed root
    # split.  Matroid order: P_X, P_{Y,y}, M(T/d_a), M(T/d_b).
    pairs = tuple(combinations(range(4), 2))
    pairwise = {y: {pair: 0 for pair in pairs} for y in Y - {ROOT}}
    four_by_free = {y: 0 for y in Y - {ROOT}}
    for choice in combinations(E0, len(X)):
        state = frozenset(choice)
        px = x_partition_base(state)
        ga = dual_tree(state | {DA})
        gb = dual_tree(state | {DB})
        for y in Y - {ROOT}:
            flags = (px, y_partition_base(state, y), ga, gb)
            for pair in pairs:
                if flags[pair[0]] and flags[pair[1]]:
                    pairwise[y][pair] += 1
            if all(flags):
                four_by_free[y] += 1

    expected_y3_pairs = (15, 356, 356, 192, 468, 5436)
    assert tuple(pairwise[3][pair] for pair in pairs) == expected_y3_pairs
    assert four_by_free[3] == 0
    assert all(pairwise[3][pair] > 0 for pair in pairs)
    assert tuple(four_by_free[y] for y in range(1, 8)) == (2, 2, 0, 0, 2, 2, 0)
    print(
        {
            "load_states": len(load_states),
            "three_common_bases": len(three),
            "four_common_bases": len(four),
            "bad_three_bases": len(bad),
            "isolated_bad": len(isolated_bad),
            "bad_without_one_step_good": len(bad_without_good_neighbour),
            "exchange_components": sorted(len(component) for component in components),
            "all_bad_components": sorted(len(component) for component in bad_components),
            "trap_free_face": free_face(H_TRAP),
            "trap_three_base_neighbours": len(adjacency[H_TRAP]),
            "trap_distance_to_four_base": distance[nearest],
            "trap": sorted(H_TRAP),
            "nearest_good": sorted(nearest),
            "fixed_y3_pairwise_intersection_sizes": {
                str(pair): pairwise[3][pair] for pair in pairs
            },
            "fixed_y3_four_common_bases": four_by_free[3],
            "four_common_bases_by_free_face": four_by_free,
        }
    )


if __name__ == "__main__":
    main()
