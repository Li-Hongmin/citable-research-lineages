#!/usr/bin/env python3
"""Independently verify an actual non-brace paid-exit counterexample."""

from __future__ import annotations

from itertools import combinations, product

import networkx as nx


Edge = tuple[int, int]


def edge(left: int, right: int) -> Edge:
    return (left, right) if left < right else (right, left)


def fixed_graph() -> nx.Graph:
    graph = nx.Graph()
    graph.add_edges_from((i, (i + 1) % 16) for i in range(16))
    graph.add_edges_from(
        (
            (0, 3),
            (1, 6),
            (2, 5),
            (4, 7),
            (8, 11),
            (9, 14),
            (10, 13),
            (12, 15),
        )
    )
    return graph


ROTATION = {
    0: (1, 3, 15),
    1: (0, 6, 2),
    2: (1, 5, 3),
    3: (0, 2, 4),
    4: (3, 5, 7),
    5: (2, 6, 4),
    6: (1, 7, 5),
    7: (4, 6, 8),
    8: (7, 9, 11),
    9: (8, 14, 10),
    10: (9, 13, 11),
    11: (8, 10, 12),
    12: (11, 13, 15),
    13: (10, 14, 12),
    14: (9, 15, 13),
    15: (0, 12, 14),
}


def faces_from_rotation(graph: nx.Graph):
    assert all(set(ROTATION[vertex]) == set(graph[vertex]) for vertex in graph)
    seen: set[tuple[int, int]] = set()
    faces: list[tuple[int, ...]] = []
    dart_face: dict[tuple[int, int], int] = {}
    for left in sorted(graph):
        for right in graph[left]:
            if (left, right) in seen:
                continue
            first = (left, right)
            dart = first
            face: list[int] = []
            face_index = len(faces)
            while dart not in seen:
                seen.add(dart)
                dart_face[dart] = face_index
                previous, current = dart
                face.append(previous)
                cyclic = ROTATION[current]
                following = cyclic[(cyclic.index(previous) - 1) % 3]
                dart = (current, following)
            assert dart == first
            faces.append(tuple(face))
    assert len(seen) == 2 * graph.number_of_edges()
    assert len(graph) - graph.number_of_edges() + len(faces) == 2
    return tuple(faces), dart_face


def contracted_dual(
    graph: nx.Graph,
    faces: tuple[tuple[int, ...], ...],
    dart_face: dict[tuple[int, int], int],
    site: tuple[int, int, int, int],
):
    dual_ends = {
        edge(left, right): (dart_face[(left, right)], dart_face[(right, left)])
        for left, right in graph.edges()
    }
    parent = list(range(len(faces)))

    def find(vertex: int) -> int:
        while parent[vertex] != vertex:
            parent[vertex] = parent[parent[vertex]]
            vertex = parent[vertex]
        return vertex

    def union(left: int, right: int) -> None:
        left, right = find(left), find(right)
        if left != right:
            parent[right] = left

    u, v, z, a = site
    special_faces: set[int] = set()
    for special in (edge(u, v), edge(z, a)):
        special_faces.update(dual_ends[special])
        union(*dual_ends[special])
    representatives = sorted({find(face) for face in range(len(faces))})
    renumber = {representative: index for index, representative in enumerate(representatives)}
    face_to_q = {face: renumber[find(face)] for face in range(len(faces))}
    root = face_to_q[next(iter(special_faces))]
    assert {face_to_q[face] for face in special_faces} == {root}

    reduced = graph.copy()
    reduced.remove_nodes_from((u, a))
    ground = frozenset(edge(left, right) for left, right in reduced.edges())
    q_ends = {
        label: tuple(face_to_q[face] for face in dual_ends[label]) for label in ground
    }
    q_vertices = tuple(sorted({vertex for ends in q_ends.values() for vertex in ends}))
    return reduced, ground, q_ends, q_vertices, root


def is_tree(
    support: frozenset[Edge],
    q_ends: dict[Edge, tuple[int, int]],
    q_vertices: tuple[int, ...],
) -> bool:
    graph = nx.MultiGraph()
    graph.add_nodes_from(q_vertices)
    graph.add_edges_from(q_ends[label] for label in support)
    return nx.is_tree(graph)


def all_violations(
    support: frozenset[Edge],
    q_ends: dict[Edge, tuple[int, int]],
    q_vertices: tuple[int, ...],
):
    output = []
    for mask in range(1, (1 << len(q_vertices)) - 1):
        shore = frozenset(
            q_vertices[index]
            for index in range(len(q_vertices))
            if mask >> index & 1
        )
        internal = sum(
            left in shore and right in shore
            for left, right in (q_ends[label] for label in support)
        )
        if internal > len(shore) - 1:
            output.append((shore, internal))
    return tuple(output)


def main() -> None:
    graph = fixed_graph()
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.node_connectivity(graph) == 2

    # The graph is not a brace: this independent edge pair has no extension.
    first, second = edge(0, 1), edge(7, 8)
    assert not (set(first) & set(second))
    remainder = graph.copy()
    remainder.remove_nodes_from((*first, *second))
    matching = nx.max_weight_matching(remainder, maxcardinality=True)
    assert len(matching) == 5 < len(remainder) // 2 == 6

    faces, dart_face = faces_from_rotation(graph)
    assert sorted(map(len, faces)) == [4] * 8 + [8] * 2
    site = (2, 1, 6, 5)
    assert (1, 6, 5, 2) in faces
    assert nx.bipartite.color(graph)[site[0]] == nx.bipartite.color(graph)[site[2]]

    reduced, ground, q_ends, q_vertices, root = contracted_dual(
        graph, faces, dart_face, site
    )
    assert root == 3
    assert q_vertices == tuple(range(8))
    colour = nx.bipartite.color(graph)
    x_vertices = tuple(
        sorted(vertex for vertex in reduced if colour[vertex] == colour[site[0]])
    )
    y_vertices = tuple(
        sorted(vertex for vertex in reduced if colour[vertex] != colour[site[0]])
    )
    assert x_vertices == (0, 4, 6, 8, 10, 12, 14)
    assert y_vertices == (1, 3, 7, 9, 11, 13, 15)
    blocks = {
        x: tuple(sorted(label for label in ground if x in label)) for x in x_vertices
    }
    assert blocks == {
        0: ((0, 1), (0, 3), (0, 15)),
        4: ((3, 4), (4, 7)),
        6: ((1, 6), (6, 7)),
        8: ((7, 8), (8, 9), (8, 11)),
        10: ((9, 10), (10, 11), (10, 13)),
        12: ((11, 12), (12, 13), (12, 15)),
        14: ((9, 14), (13, 14), (14, 15)),
    }

    transversals = tuple(
        frozenset(choice) for choice in product(*(blocks[x] for x in x_vertices))
    )
    assert len(transversals) == 972
    bases = tuple(
        support for support in transversals if is_tree(support, q_ends, q_vertices)
    )
    assert len(bases) == 112

    active = {3, 9, 11, 13, 15}
    x_side = set(x_vertices)

    def cost(support: frozenset[Edge]) -> int:
        return sum(
            next(vertex for vertex in label if vertex not in x_side) in active
            for label in support
        )

    # This is the strict full problem: every one of the 112 bases is over budget.
    assert {cost(base) for base in bases} == {6}
    assert min(map(cost, bases)) == 6 > len(active) == 5

    support = frozenset(
        {
            edge(0, 1),
            edge(1, 6),
            edge(3, 4),
            edge(8, 11),
            edge(9, 10),
            edge(11, 12),
            edge(13, 14),
        }
    )
    assert support in transversals and support not in bases
    assert cost(support) == 5 == len(active)
    W = frozenset((0, 3))
    assert all_violations(support, q_ends, q_vertices) == ((W, 2),)
    assert {
        label
        for label in support
        if q_ends[label][0] in W and q_ends[label][1] in W
    } == {edge(0, 1), edge(1, 6)}

    # The root-parallel block at x=6 is wholly internal.  The other internal
    # choice has exactly two boundary exits, and both Note-047 completions are
    # full bases of cost six.
    assert {
        label
        for label in blocks[6]
        if set(q_ends[label]) <= W
    } == set(blocks[6])
    exits = {
        label
        for label in blocks[0]
        if sum(vertex in W for vertex in q_ends[label]) == 1
    }
    assert exits == {edge(0, 3), edge(0, 15)}
    completions = {
        frozenset((set(support) - {edge(0, 1)}) | {exit}) for exit in exits
    }
    assert completions <= set(bases)
    assert {cost(completion) for completion in completions} == {6}

    # Exhaust the binary layer too: the displayed A is one of the strict
    # layers and there is no hidden lower-cost base.
    strict_layers = []
    for mask in range(1 << len(y_vertices)):
        selected = {
            y_vertices[index]
            for index in range(len(y_vertices))
            if mask >> index & 1
        }

        def selected_cost(base: frozenset[Edge]) -> int:
            return sum(
                next(vertex for vertex in label if vertex not in x_side) in selected
                for label in base
            )

        minimum = min(selected_cost(base) for base in bases)
        if minimum > len(selected):
            strict_layers.append((frozenset(selected), minimum))
    assert (frozenset(active), 6) in strict_layers
    assert strict_layers == [(frozenset(active), 6)]

    print("FIXED_TWO_CUT_PAID_EXIT_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
