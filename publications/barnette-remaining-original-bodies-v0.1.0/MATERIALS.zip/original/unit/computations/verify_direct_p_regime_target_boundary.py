#!/usr/bin/env python3
"""Verify ordinary and endpoint-closing Posa rotations at two fixed FEC sites.

This is a fixed-instance diagnostic, not an order census.  It distinguishes
ordinary rotations from the augmented fixed-endpoint rotation graph at the
unique-target and all-even orientations of the order-16 brace in Notes
023--024.
"""

from __future__ import annotations

from collections import defaultdict, deque

import networkx as nx


GRAPH6 = b"OlCGHD@?g?_@@@A?_?k?P"

Edge = frozenset[int]
Path = frozenset[Edge]


def edge(x: int, y: int) -> Edge:
    return frozenset((x, y))


def full_paths(graph: nx.Graph, left: int, right: int) -> tuple[Path, ...]:
    found: set[Path] = set()
    order = graph.number_of_nodes()

    def visit(path: list[int], seen: set[int]) -> None:
        here = path[-1]
        if len(path) == order:
            if here == right:
                found.add(frozenset(edge(x, y) for x, y in zip(path, path[1:])))
            return
        for nxt in graph[here]:
            if nxt in seen:
                continue
            if nxt == right and len(path) + 1 != order:
                continue
            seen.add(nxt)
            path.append(nxt)
            visit(path, seen)
            path.pop()
            seen.remove(nxt)

    visit([left], {left})
    return tuple(found)


def endpoints(path: Path, vertices: set[int]) -> frozenset[int]:
    degree = defaultdict(int)
    for e in path:
        x, y = tuple(e)
        degree[x] += 1
        degree[y] += 1
    return frozenset(v for v in vertices if degree[v] == 1)


def is_spanning_path(graph: nx.Graph, support: Path) -> bool:
    path_graph = nx.Graph()
    path_graph.add_nodes_from(graph)
    path_graph.add_edges_from(tuple(e) for e in support)
    degrees = sorted(dict(path_graph.degree()).values())
    return nx.is_connected(path_graph) and degrees == [1, 1] + [2] * (len(graph) - 2)


def fixed_endpoint_rotations(graph: nx.Graph, path: Path, fixed: int) -> tuple[Path, ...]:
    ends = endpoints(path, set(graph))
    assert fixed in ends and len(ends) == 2
    moving = next(iter(ends - {fixed}))
    answers: set[Path] = set()
    for neighbour in graph[moving]:
        chord = edge(moving, neighbour)
        if chord in path or neighbour == fixed:
            continue
        incident = tuple(e for e in path if neighbour in e)
        assert len(incident) == 2
        for removed in incident:
            candidate = frozenset((path | {chord}) - {removed})
            if is_spanning_path(graph, candidate) and fixed in endpoints(candidate, set(graph)):
                answers.add(candidate)
    return tuple(answers)


def closure(graph: nx.Graph, seeds: tuple[Path, ...], fixed: int) -> frozenset[Path]:
    reached = set(seeds)
    queue = deque(seeds)
    while queue:
        current = queue.popleft()
        for nxt in fixed_endpoint_rotations(graph, current, fixed):
            if nxt not in reached:
                reached.add(nxt)
                queue.append(nxt)
    return frozenset(reached)


def unrestricted_rotations(graph: nx.Graph, path: Path) -> tuple[Path, ...]:
    answers: set[Path] = set()
    for endpoint in endpoints(path, set(graph)):
        answers.update(fixed_endpoint_rotations(graph, path, endpoint))
    return tuple(answers)


def rotations_and_cycle_openings(graph: nx.Graph, path: Path) -> tuple[Path, ...]:
    answers = set(unrestricted_rotations(graph, path))
    left, right = tuple(endpoints(path, set(graph)))
    closing = edge(left, right)
    if graph.has_edge(left, right) and closing not in path:
        cycle = path | {closing}
        for removed in cycle:
            if removed == closing:
                continue
            candidate = frozenset(cycle - {removed})
            assert is_spanning_path(graph, candidate)
            answers.add(candidate)
    return tuple(answers)


def fixed_endpoint_augmented_rotations(
    graph: nx.Graph, path: Path, fixed: int
) -> tuple[Path, ...]:
    answers = set(fixed_endpoint_rotations(graph, path, fixed))
    ends = endpoints(path, set(graph))
    moving = next(iter(ends - {fixed}))
    closing = edge(fixed, moving)
    if graph.has_edge(fixed, moving) and closing not in path:
        cycle = path | {closing}
        fixed_path_edge = next(e for e in path if fixed in e)
        candidate = frozenset(cycle - {fixed_path_edge})
        assert is_spanning_path(graph, candidate)
        assert fixed in endpoints(candidate, set(graph))
        answers.add(candidate)
    return tuple(answers)


def fixed_endpoint_augmented_closure(
    graph: nx.Graph, seeds: tuple[Path, ...], fixed: int
) -> frozenset[Path]:
    reached = set(seeds)
    queue = deque(seeds)
    while queue:
        current = queue.popleft()
        for nxt in fixed_endpoint_augmented_rotations(graph, current, fixed):
            if nxt not in reached:
                reached.add(nxt)
                queue.append(nxt)
    return frozenset(reached)


def unrestricted_closure(graph: nx.Graph, seeds: tuple[Path, ...]) -> frozenset[Path]:
    reached = set(seeds)
    queue = deque(seeds)
    while queue:
        current = queue.popleft()
        for nxt in unrestricted_rotations(graph, current):
            if nxt not in reached:
                reached.add(nxt)
                queue.append(nxt)
    return frozenset(reached)


def augmented_closure(graph: nx.Graph, seeds: tuple[Path, ...]) -> frozenset[Path]:
    reached = set(seeds)
    queue = deque(seeds)
    while queue:
        current = queue.popleft()
        for nxt in rotations_and_cycle_openings(graph, current):
            if nxt not in reached:
                reached.add(nxt)
                queue.append(nxt)
    return frozenset(reached)


def audit_site(u: int, v: int, z: int, a: int) -> dict[str, object]:
    graph = nx.from_graph6_bytes(GRAPH6)
    reduced = graph.copy()
    reduced.remove_edges_from(((u, v), (z, a)))

    uv = full_paths(reduced, u, v)
    za = full_paths(reduced, z, a)
    vz = full_paths(reduced, v, z)
    ua = full_paths(reduced, u, a)

    from_uv_fixed_v = closure(reduced, uv, v)
    from_za_fixed_z = closure(reduced, za, z)
    from_uv_fixed_u = closure(reduced, uv, u)
    from_za_fixed_a = closure(reduced, za, a)
    from_uv_any = unrestricted_closure(reduced, uv)
    from_za_any = unrestricted_closure(reduced, za)
    from_vz_any = unrestricted_closure(reduced, vz)
    from_uv_augmented = augmented_closure(reduced, uv)
    fixed_v_components: list[tuple[int, int, int]] = []
    unseen_uv = set(uv)
    while unseen_uv:
        seed = next(iter(unseen_uv))
        component = fixed_endpoint_augmented_closure(reduced, (seed,), v)
        source_count = sum(path in component for path in uv)
        target_count = sum(path in component for path in vz)
        fixed_v_components.append((len(component), source_count, target_count))
        unseen_uv.difference_update(component)

    print("site", (u, v, z, a), "source_target_counts", len(uv), len(za), len(vz), len(ua))
    for label, family, targets in (
        ("uv_fixed_v", from_uv_fixed_v, vz),
        ("za_fixed_z", from_za_fixed_z, vz),
        ("uv_fixed_u", from_uv_fixed_u, ua),
        ("za_fixed_a", from_za_fixed_a, ua),
    ):
        endpoint_counts = defaultdict(int)
        for path in family:
            for endpoint in endpoints(path, set(reduced)):
                endpoint_counts[endpoint] += 1
        hits = sum(target in family for target in targets)
        print(label, "closure", len(family), "target_hits", hits,
              "endpoint_support", sorted(endpoint_counts))

    print("uv_unrestricted", len(from_uv_any), "vz_hits",
          sum(target in from_uv_any for target in vz), "ua_hits",
          sum(target in from_uv_any for target in ua))
    print("za_unrestricted", len(from_za_any), "vz_hits",
          sum(target in from_za_any for target in vz), "ua_hits",
          sum(target in from_za_any for target in ua))
    print("vz_unrestricted", len(from_vz_any), "uv_hits",
          sum(source in from_vz_any for source in uv), "za_hits",
          sum(source in from_vz_any for source in za))
    print("uv_augmented", len(from_uv_augmented), "vz_hits",
          sum(target in from_uv_augmented for target in vz), "ua_hits",
          sum(target in from_uv_augmented for target in ua))
    print("fixed_v_component_profiles", sorted(fixed_v_components))
    return {
        "counts": (len(uv), len(za), len(vz), len(ua)),
        "fixed_v_hits": sum(target in from_uv_fixed_v for target in vz),
        "fixed_z_hits": sum(target in from_za_fixed_z for target in vz),
        "unrestricted_hits": sum(target in from_uv_any for target in vz),
        "augmented_hits": sum(target in from_uv_augmented for target in vz),
        "uv_any": from_uv_any,
        "za_any": from_za_any,
        "vz_any": from_vz_any,
        "fixed_v_components": tuple(sorted(fixed_v_components)),
    }


def main() -> None:
    unique = audit_site(15, 14, 13, 4)
    assert unique["counts"] == (3, 3, 1, 3)
    assert unique["fixed_v_hits"] == unique["fixed_z_hits"] == 0
    assert unique["unrestricted_hits"] == 0
    assert unique["augmented_hits"] == 1
    assert unique["uv_any"] == unique["za_any"]
    assert unique["uv_any"].isdisjoint(unique["vz_any"])
    assert unique["fixed_v_components"] == ((6, 1, 1), (8, 2, 0))

    even = audit_site(0, 15, 4, 13)
    assert even["counts"] == (4, 2, 2, 4)
    assert even["fixed_v_hits"] == even["fixed_z_hits"] == 2
    assert even["unrestricted_hits"] == 2
    assert even["augmented_hits"] == 2
    print("DIRECT_P_REGIME_FIXED_ENDPOINT_ROTATION_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
