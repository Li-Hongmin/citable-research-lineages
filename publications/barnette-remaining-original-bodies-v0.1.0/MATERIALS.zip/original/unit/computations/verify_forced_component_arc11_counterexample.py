#!/usr/bin/env python3
"""Freeze the first through-20 forced-gate component that is not all arc11."""

from __future__ import annotations

import argparse
import importlib.util
from itertools import product
import json
from pathlib import Path
import subprocess
import sys

import networkx as nx


UNIT_DIR = Path(__file__).resolve().parents[1]
SOURCE = (
    UNIT_DIR
    / "computations"
    / "bundles"
    / "target-component-saturation-order22"
    / "census_forced_target_components_order22.py"
)


def load(path: Path):
    specification = importlib.util.spec_from_file_location("forced_component_source", path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


sat = load(SOURCE)


def generated_graphs(order: int):
    process = subprocess.Popen(
        ("geng", "-cqb", "-d3", "-D3", str(order)),
        stdout=subprocess.PIPE,
        text=True,
    )
    assert process.stdout is not None
    completed = False
    try:
        for line in process.stdout:
            graph6 = line.strip()
            if graph6:
                yield graph6, nx.from_graph6_bytes(graph6.encode())
        assert process.wait() == 0
        completed = True
    finally:
        if not completed and process.poll() is None:
            process.terminate()
            process.wait()


def alternating(word: tuple[int, ...]) -> bool:
    return all(word[index] != word[index + 1] for index in range(len(word) - 1))


def find_witness():
    scanned = {"generated": 0, "braces": 0, "interfaces": 0}
    for order in range(6, 21, 2):
        stream = generated_graphs(order)
        try:
            for graph6, primal in stream:
                scanned["generated"] += 1
                planar, embedding = nx.check_planarity(primal, counterexample=True)
                if not planar:
                    continue
                assert isinstance(embedding, nx.PlanarEmbedding)
                primal_faces = sat.source_bundle.plane_faces(primal, embedding)
                direct = sat.source_bundle.is_two_extendable_direct(primal)
                strict_hall = sat.source_bundle.strict_hall_two_extendable(primal)
                assert direct == strict_hall
                if not direct:
                    continue
                scanned["braces"] += 1

                reduced, rotations = sat.lift_bundle.dual_from_primal_faces(
                    primal, primal_faces
                )
                reduced_faces = sat.lift_bundle.verify_reduced_triangulation(reduced)
                families, _, _ = sat.lift_bundle.target_families(
                    reduced, reduced_faces
                )
                reduced_vertices = tuple(sorted(reduced))
                dual_to_primal = sat.primal_edge_by_dual_edge(primal, primal_faces)
                family_cache = {}
                for root, encoded_family in families.items():
                    colours = tuple(
                        sat.lift_bundle.decode_colouring(reduced_vertices, encoded)
                        for encoded in encoded_family
                    )
                    matchings = tuple(
                        sat.matching_from_colour(
                            primal, reduced, dual_to_primal, colour
                        )
                        for colour in colours
                    )
                    adjacency = sat.target_graph(matchings)
                    family_cache[root] = colours, matchings, adjacency

                for z in sorted(reduced):
                    rotation = rotations[z]
                    for first_index, second_index, first_gate, second_gate in sat.lift_bundle.gate_pairs(
                        rotation
                    ):
                        left_size = second_index - first_index + 1
                        right_size = len(rotation) - (second_index - first_index) + 1
                        if left_size % 2 == 0 or right_size % 2 == 0:
                            continue
                        expanded, locals_, left_arc, right_arc = sat.lift_bundle.split_vertex(
                            reduced, z, rotation, first_index, second_index
                        )
                        expanded_faces = sat.lift_bundle.expanded_triangulation_faces(expanded)
                        if expanded_faces is None:
                            continue
                        gate_edges = (
                            dual_to_primal[sat.edge(z, first_gate)],
                            dual_to_primal[sat.edge(z, second_gate)],
                        )

                        for root in sorted(families):
                            if z in root:
                                continue
                            scanned["interfaces"] += 1
                            colours, matchings, adjacency = family_cache[root]
                            gate_counts = tuple(
                                sum(gate in matching for gate in gate_edges)
                                for matching in matchings
                            )
                            arc11 = tuple(
                                gate_counts[index] == 2
                                and alternating(
                                    tuple(colour[item] ^ colour[z] for item in left_arc)
                                )
                                and alternating(
                                    tuple(colour[item] ^ colour[z] for item in right_arc)
                                )
                                for index, colour in enumerate(colours)
                            )
                            for component in nx.connected_components(adjacency):
                                if not all(gate_counts[index] == 2 for index in component):
                                    continue
                                if all(arc11[index] for index in component):
                                    continue

                                lift_rows = []
                                for colour in colours:
                                    fixed = {
                                        vertex: value
                                        for vertex, value in colour.items()
                                        if vertex != z
                                    }
                                    rows = set()
                                    for bits in product((0, 1), repeat=3):
                                        lifted = {
                                            **fixed,
                                            **dict(zip(locals_, bits, strict=True)),
                                        }
                                        profile = sat.lift_bundle.rooted_profile(
                                            expanded,
                                            expanded_faces,
                                            lifted,
                                            root,
                                        )
                                        if sat.lift_bundle.is_target_profile(profile):
                                            rows.add(
                                                "".join(
                                                    str(bit ^ colour[z]) for bit in bits
                                                )
                                            )
                                    lift_rows.append(rows)
                                record = {
                                    "source_order": order,
                                    "source_graph6": graph6,
                                    "split_vertex": z,
                                    "rotation": rotation,
                                    "gate_indices": (first_index, second_index),
                                    "gate_vertices": (first_gate, second_gate),
                                    "primal_gate_edges": gate_edges,
                                    "left_arc": left_arc,
                                    "right_arc": right_arc,
                                    "dual_root": root,
                                    "primal_root": dual_to_primal[root],
                                    "complete_family_size": len(matchings),
                                    "component_family_indices": sorted(component),
                                    "component_targets": [
                                        {
                                            "family_index": index,
                                            "zero_vertices": sorted(
                                                vertex
                                                for vertex, value in colours[index].items()
                                                if value == 0
                                            ),
                                            "one_vertices": sorted(
                                                vertex
                                                for vertex, value in colours[index].items()
                                                if value == 1
                                            ),
                                            "matching": sorted(matchings[index]),
                                            "lift_rows_normalized": sorted(lift_rows[index]),
                                            "target_graph_neighbours": sorted(adjacency[index]),
                                        }
                                        for index in sorted(component)
                                    ],
                                }
                                record["arc11_by_selected_target"] = {
                                    str(index): arc11[index]
                                    for index in sorted(component)
                                }
                                record["complete_family_forces_both_gates"] = all(
                                    count == 2 for count in gate_counts
                                )
                                record["scanned_before_witness"] = scanned
                                return record
        finally:
            stream.close()
    raise AssertionError("No forced-component non-arc11 witness through order 20")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    witness = find_witness()
    rendered = json.dumps(witness, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
    print(rendered, end="")
    print("FORCED_COMPONENT_ARC11_IMPLICATION_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
