#!/usr/bin/env python3
"""Verify the finite local lemma for rooted four-vertex triangle profiles.

The three nonroot dual vertices form a facial triangle.  This constant-size
calculation uses only the legal root-class states, the second facial triangle
on a shared-root edge, local common-neighbour uniqueness, and extendability
of each retained triangle label.
"""

from __future__ import annotations

from itertools import product


ROOTS = ("c", "p", "h")
VERTICES = ("s", "t", "q")
TRIANGLE = (("s", "t"), ("t", "q"), ("q", "s"))

CLASSES = {
    "0": frozenset(),
    "1c": frozenset({"c"}),
    "1p": frozenset({"p"}),
    "1h": frozenset({"h"}),
    "V": frozenset({"c", "p"}),
    "Z": frozenset({"c", "h"}),
    "R": frozenset({"p", "h"}),
    "T": frozenset(ROOTS),
}


def class_state_is_legal(
    name: str,
    vertex: str,
    roots: frozenset[str],
    values: dict[tuple[str, str], int],
    remote_mode: str,
) -> bool:
    state = [values[(vertex, root)] for root in roots]
    if len(roots) <= 1:
        return True
    if name in {"V", "Z"}:
        return sum(state) == 1
    if name == "R":
        if remote_mode == "E":
            return sum(state) == 1
        return state[0] == state[1]
    if name == "T":
        return (
            values[(vertex, "c")] + values[(vertex, "p")] == 1
            and values[(vertex, "p")] == values[(vertex, "h")]
        )
    raise AssertionError(name)


def local_states(
    names: tuple[str, str, str],
    remote_modes: tuple[str, str, str],
) -> list[tuple[int, dict[tuple[str, str], int]]]:
    root_sets = [CLASSES[name] for name in names]
    labels = [
        (vertex, root)
        for vertex, roots in zip(VERTICES, root_sets, strict=True)
        for root in roots
    ]
    states: list[tuple[int, dict[tuple[str, str], int]]] = []

    for bits in product((0, 1), repeat=len(labels) + len(TRIANGLE)):
        root_values = dict(zip(labels, bits[: len(labels)], strict=True))
        triangle_values = dict(
            zip(TRIANGLE, bits[len(labels) :], strict=True)
        )
        if sum(triangle_values.values()) != 1:
            continue

        if any(
            not class_state_is_legal(name, vertex, roots, root_values, mode)
            for name, vertex, roots, mode in zip(
                names, VERTICES, root_sets, remote_modes, strict=True
            )
        ):
            continue

        valid = True
        for edge, triangle_value in triangle_values.items():
            left, right = edge
            left_index = VERTICES.index(left)
            right_index = VERTICES.index(right)
            for root in root_sets[left_index] & root_sets[right_index]:
                # The two facial triangles on the dual edge give the
                # complete three-edge incidence at the primal endpoint.
                if (
                    triangle_value
                    + root_values[(left, root)]
                    + root_values[(right, root)]
                    != 1
                ):
                    valid = False
        if valid:
            states.append((sum(root_values.values()), triangle_values))
    return states


def verify() -> None:
    admitted_modes = 0
    large_modes = 0
    safe_edge_histogram = {edge: 0 for edge in TRIANGLE}

    for names in product(CLASSES, repeat=3):
        root_sets = [CLASSES[name] for name in names]

        # A root edge has one retained third face.  The nonroot facial
        # triangle already occupies one side of each of its own edges.
        if sum({"c", "p"} <= roots for roots in root_sets) > 1:
            continue
        if sum({"c", "h"} <= roots for roots in root_sets) > 1:
            continue
        if any(
            len(root_sets[left] & root_sets[right]) > 1
            for left, right in ((0, 1), (1, 2), (2, 0))
        ):
            continue

        mode_choices = [
            ("E", "B") if name == "R" else ("-",) for name in names
        ]
        for remote_modes in product(*mode_choices):
            states = local_states(names, remote_modes)

            # Every retained triangle label is extendable in the actual K.
            if any(
                not any(triangle_values[edge] for _, triangle_values in states)
                for edge in TRIANGLE
            ):
                continue

            admitted_modes += 1
            root_label_count = sum(map(len, root_sets))
            if root_label_count <= 3:
                continue

            large_modes += 1
            safe_edges = [
                edge
                for edge in TRIANGLE
                if max(
                    root_cost
                    for root_cost, triangle_values in states
                    if triangle_values[edge]
                )
                <= 2
            ]
            assert safe_edges, (names, remote_modes, states)
            safe_edge_histogram[safe_edges[0]] += 1

    print(f"admitted profile modes: {admitted_modes}")
    print(f"modes with at least four root labels: {large_modes}")
    print(f"first-safe-edge histogram: {safe_edge_histogram}")
    assert admitted_modes == 430
    assert large_modes == 279
    assert sum(safe_edge_histogram.values()) == large_modes
    print("ROOTED_FOUR_TRIANGLE_PROFILES_VERIFIED")


if __name__ == "__main__":
    verify()
