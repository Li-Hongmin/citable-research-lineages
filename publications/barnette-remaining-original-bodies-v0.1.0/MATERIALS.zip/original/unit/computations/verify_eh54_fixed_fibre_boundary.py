#!/usr/bin/env python3
"""Verify the Ellingham--Horton fixed-fibre A/B separation.

For the frozen 54-vertex graph, root 52, and port split
53 | {32, 50}, this program checks:

* the graph is a nonplanar simple cubic bipartite brace;
* the fixed fibre has two explicit forests whose half--half mixture has
  expected Y-degree at most two;
* no forest in the fibre has all Y-degrees at most two, by an exact
  Hamilton-circuit reduction solved by integer CP-SAT.

The strict-Hall check uses only integer minimum cuts.  The two positive
forest certificates and their rational average are checked without a solver.
"""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations

import networkx as nx
from ortools.sat.python import cp_model


GRAPH6 = (
    "uhCGGCP?GGo@?PG?_?KO@?????G?????C??@??AG??????P??@?????_???G???P??"
    "AA??OCC?C?CC???AAO???__???CC???????????@????????????_?????G?????P???"
    "?????????AG?????G???????C??????@??????AG?????OOG?????__??G???__??????"
    "OQ??????CC???????__?????G??G?????O??W"
)
ROOT = 52
PORTS = (32, 50, 53)
PAIRED_START = 32
PAIRED_END = 50
SINGLETON = 53

FORESTS = (
    (
        (0, 1), (0, 11), (1, 2), (2, 13), (3, 4), (3, 8), (4, 15),
        (5, 6), (5, 10), (6, 30), (7, 8), (7, 12), (9, 10), (9, 29),
        (10, 11), (13, 14), (14, 15), (14, 48), (16, 21), (17, 24),
        (17, 29), (18, 23), (18, 30), (19, 20), (19, 31), (21, 33),
        (22, 23), (22, 27), (22, 28), (24, 25), (25, 26), (26, 32),
        (27, 33), (28, 31), (34, 39), (34, 46), (35, 42), (35, 47),
        (36, 41), (36, 48), (37, 38), (37, 49), (39, 51), (40, 45),
        (41, 47), (42, 43), (43, 44), (44, 45), (44, 50), (46, 49),
        (51, 53),
    ),
    (
        (0, 11), (0, 15), (1, 2), (1, 47), (2, 13), (3, 4), (3, 8),
        (4, 15), (5, 6), (5, 10), (6, 7), (7, 12), (8, 9), (9, 29),
        (11, 12), (12, 13), (14, 48), (16, 17), (16, 21), (16, 28),
        (17, 24), (18, 23), (18, 30), (19, 20), (19, 31), (20, 32),
        (21, 33), (22, 28), (23, 29), (24, 30), (25, 26), (25, 31),
        (26, 27), (27, 33), (34, 35), (34, 39), (35, 42), (36, 37),
        (36, 41), (37, 38), (38, 39), (38, 50), (40, 45), (40, 46),
        (41, 47), (42, 48), (43, 44), (43, 49), (45, 51), (46, 49),
        (51, 53),
    ),
)


def strict_hall_minimum(
    graph: nx.Graph,
    left: tuple[int, ...],
    right: tuple[int, ...],
) -> int:
    """Return min |N(A)|-|A| over nonempty A with |A|<=|left|-2.

    For each forced member x and pair of forced nonmembers u,v, a maximum
    closure/minimum-cut instance optimizes |A|-|N(A)|.  Every admissible A
    occurs in at least one such instance, so the minimum over all triples is
    the required global minimum.
    """

    large = 10 * graph.number_of_nodes()
    best = len(right)
    for member in left:
        for omitted_a, omitted_b in combinations(
            (vertex for vertex in left if vertex != member), 2
        ):
            source = ("source",)
            sink = ("sink",)
            network = nx.DiGraph()
            for x in left:
                network.add_edge(source, ("x", x), capacity=1)
            for y in right:
                network.add_edge(("y", y), sink, capacity=1)
            for x in left:
                for y in graph[x]:
                    network.add_edge(("x", x), ("y", y), capacity=large)

            # Replacing the unit source arc by a large one forces membership;
            # the added large sink arcs force two nonmembers.  These changes
            # are constants on the constrained family and do not alter its
            # optimizer for |A|-|N(A)|.
            network[source][("x", member)]["capacity"] = large
            network.add_edge(("x", omitted_a), sink, capacity=large)
            network.add_edge(("x", omitted_b), sink, capacity=large)
            _, (source_shore, _) = nx.minimum_cut(network, source, sink)
            subset = tuple(x for x in left if ("x", x) in source_shore)
            assert member in subset
            assert omitted_a not in subset and omitted_b not in subset
            neighbours = set().union(*(set(graph[x]) for x in subset))
            best = min(best, len(neighbours) - len(subset))
    return best


def verify_positive_certificates(
    graph: nx.Graph,
    x_side: tuple[int, ...],
    y_side: tuple[int, ...],
) -> tuple[tuple[Fraction, ...], tuple[tuple[int, ...], ...]]:
    vectors = []
    for forest in FORESTS:
        assert len(forest) == len(set(forest)) == 51
        assert all(ROOT not in edge and graph.has_edge(*edge) for edge in forest)
        support = nx.Graph()
        support.add_nodes_from(set(graph) - {ROOT})
        support.add_edges_from(forest)
        assert nx.is_forest(support)
        components = tuple(frozenset(part) for part in nx.connected_components(support))
        assert len(components) == 2
        port_blocks = {frozenset(part & set(PORTS)) for part in components}
        assert port_blocks == {
            frozenset((SINGLETON,)),
            frozenset((PAIRED_START, PAIRED_END)),
        }
        for x in x_side:
            assert support.degree(x) == (1 if x in PORTS else 2)
        vector = tuple(support.degree(y) for y in y_side)
        assert min(vector) >= 1 and max(vector) <= 3 and sum(vector) == 51
        vectors.append(vector)

    expectation = tuple(
        Fraction(vectors[0][index] + vectors[1][index], 2)
        for index in range(len(y_side))
    )
    assert max(expectation) <= 2
    assert tuple(y for y, value in zip(y_side, expectation) if value < 2) == (20, 40)
    assert all(value == Fraction(3, 2) for value in expectation if value < 2)
    return expectation, tuple(vectors)


def verify_integral_failure(graph: nx.Graph, y_side: tuple[int, ...]) -> dict[str, int | str]:
    """Solve the exact Hamilton-circuit formulation of the two-path cover."""

    vertices = tuple(sorted(set(graph) - {ROOT}))
    dummy = max(graph) + 1
    nodes = vertices + (dummy,)
    node_index = {vertex: index for index, vertex in enumerate(nodes)}
    model = cp_model.CpModel()
    arcs = []

    def add_arc(start: int, end: int, name: str):
        variable = model.new_bool_var(name)
        arcs.append((node_index[start], node_index[end], variable))
        return variable

    for a, b in sorted(
        (min(a, b), max(a, b))
        for a, b in graph.edges()
        if ROOT not in (a, b)
    ):
        add_arc(a, b, f"edge_{a}_{b}_forward")
        add_arc(b, a, f"edge_{a}_{b}_reverse")

    bridge = add_arc(PAIRED_END, SINGLETON, "forced_bridge")
    dummy_start = add_arc(dummy, PAIRED_START, "forced_dummy_start")
    for y in y_side:
        add_arc(y, dummy, f"return_{y}")
    model.add(bridge == 1)
    model.add(dummy_start == 1)
    model.add_circuit(arcs)

    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = 1
    solver.parameters.random_seed = 0
    solver.parameters.max_time_in_seconds = 1800
    status = solver.solve(model)
    status_name = solver.status_name(status)
    assert status == cp_model.INFEASIBLE
    return {
        "status": status_name,
        "arc_variables": len(arcs),
        "branches": solver.num_branches,
        "conflicts": solver.num_conflicts,
    }


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert graph.number_of_nodes() == 54 and graph.number_of_edges() == 81
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert tuple(sorted(graph[ROOT])) == PORTS
    assert nx.check_planarity(graph)[0] is False

    colour = nx.bipartite.color(graph)
    root_colour = colour[ROOT]
    x_side = tuple(sorted(v for v in graph if colour[v] != root_colour))
    full_y_side = tuple(sorted(v for v in graph if colour[v] == root_colour))
    y_side = tuple(v for v in full_y_side if v != ROOT)
    assert len(x_side) == len(full_y_side) == 27 and len(y_side) == 26

    hall_x = strict_hall_minimum(graph, x_side, full_y_side)
    hall_y = strict_hall_minimum(graph, full_y_side, x_side)
    assert hall_x == hall_y == 2
    expectation, vectors = verify_positive_certificates(graph, x_side, y_side)
    failure = verify_integral_failure(graph, y_side)

    print(
        {
            "graph": "EllinghamHorton54Graph",
            "strict_hall_minima": (hall_x, hall_y),
            "root": ROOT,
            "port_split": ((SINGLETON,), (PAIRED_START, PAIRED_END)),
            "integral_A": False,
            "cp_sat": failure,
            "fractional_B": True,
            "support": 2,
            "degree_vectors": vectors,
            "expected_degrees": tuple(str(value) for value in expectation),
        }
    )
    print("EH54_FIXED_FIBRE_A_FAILS_B_HOLDS_VERIFIED")


if __name__ == "__main__":
    main()
