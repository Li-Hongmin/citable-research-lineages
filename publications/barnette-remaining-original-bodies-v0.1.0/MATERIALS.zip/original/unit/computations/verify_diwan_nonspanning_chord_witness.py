#!/usr/bin/env python3
"""Verify a 12-vertex plane-brace realization of Diwan's nonspanning output.

The root edge is 0--7 in the order-12 brace from Note 064.  A separated
perfect matching with three complementary cycles maps under Diwan's
Theorem 3 auxiliary construction to a 2-factor with two cycles, one of
which has the specified auxiliary edge as a chord.
"""

from collections import Counter
from itertools import combinations


def edge(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


FACES = (
    (0, 7, 1, 6),
    (0, 8, 4, 11, 3, 7),
    (0, 6, 2, 8),
    (1, 7, 3, 9),
    (1, 9, 5, 10, 2, 6),
    (2, 10, 4, 8),
    (3, 11, 5, 9),
    (4, 10, 5, 11),
)
VERTICES = frozenset(range(12))
EDGES = frozenset(
    edge(u, v)
    for face in FACES
    for u, v in zip(face, face[1:] + face[:1])
)
ROOT_EDGE = edge(0, 7)
MATCHING = frozenset(
    (
        edge(0, 7),
        edge(1, 6),
        edge(2, 10),
        edge(3, 11),
        edge(4, 8),
        edge(5, 9),
    )
)


def adjacency(vertices, edges):
    result = {vertex: set() for vertex in vertices}
    for u, v in edges:
        result[u].add(v)
        result[v].add(u)
    return result


def components(vertices, edges):
    graph = adjacency(vertices, edges)
    unseen = set(vertices)
    result = []
    while unseen:
        start = unseen.pop()
        component = {start}
        stack = [start]
        while stack:
            u = stack.pop()
            for v in graph[u] - component:
                component.add(v)
                unseen.discard(v)
                stack.append(v)
        result.append(frozenset(component))
    return tuple(result)


def connected(vertices, edges):
    return len(components(vertices, edges)) == 1


def verify_plane_brace():
    graph = adjacency(VERTICES, EDGES)
    assert len(EDGES) == 18
    assert all(len(graph[v]) == 3 for v in VERTICES)
    assert all((u < 6) != (v < 6) for u, v in EDGES)
    assert len(VERTICES) - len(EDGES) + len(FACES) == 2

    darts = [
        (u, v)
        for face in FACES
        for u, v in zip(face, face[1:] + face[:1])
    ]
    expected = {(u, v) for u, v in EDGES} | {(v, u) for u, v in EDGES}
    assert len(darts) == len(set(darts)) and set(darts) == expected

    for side in (tuple(range(6)), tuple(range(6, 12))):
        for size in range(1, len(side) - 1):
            for subset in combinations(side, size):
                neighbours = set().union(*(graph[v] for v in subset))
                assert len(neighbours) >= size + 2


def enumerate_perfect_matchings():
    graph = adjacency(VERTICES, EDGES)
    result = []

    def visit(unmatched, selected):
        if not unmatched:
            result.append(frozenset(selected))
            return
        u = min(unmatched)
        for v in graph[u]:
            if v in unmatched:
                visit(unmatched - {u, v}, selected + [edge(u, v)])

    visit(set(VERTICES), [])
    return tuple(result)


def main():
    verify_plane_brace()
    assert MATCHING <= EDGES
    assert all(
        sum(vertex in selected for selected in MATCHING) == 1
        for vertex in VERTICES
    )

    factor = EDGES - MATCHING
    factor_components = components(VERTICES, factor)
    assert sorted(len(one) for one in factor_components) == [4, 4, 4]
    component_index = {
        vertex: index
        for index, one in enumerate(factor_components)
        for vertex in one
    }
    assert component_index[0] != component_index[7]

    # Theorem 3 notation for root edge u-v = 0-7:
    # u1=6, u2=8 and v1=1, v2=3 in the two incident faces.
    up, vp = 12, 13
    aux_vertices = (VERTICES - {0, 7}) | {up, vp}
    aux_edges = {
        selected
        for selected in EDGES
        if 0 not in selected and 7 not in selected
    } | {
        edge(up, vp),
        edge(up, 6),
        edge(up, 1),
        edge(vp, 8),
        edge(vp, 3),
    }
    aux_graph = adjacency(aux_vertices, aux_edges)
    assert all(len(aux_graph[v]) == 3 for v in aux_vertices)
    assert connected(aux_vertices, aux_edges)
    assert all(
        connected(aux_vertices, aux_edges - {selected})
        for selected in aux_edges
    )

    aux_factor = {
        selected
        for selected in factor
        if 0 not in selected and 7 not in selected
    } | {
        edge(up, 6),
        edge(up, 1),
        edge(vp, 8),
        edge(vp, 3),
    }
    assert all(
        sum(vertex in selected for selected in aux_factor) == 2
        for vertex in aux_vertices
    )
    aux_components = components(aux_vertices, aux_factor)
    assert sorted(len(one) for one in aux_components) == [4, 8]
    chord = edge(up, vp)
    assert chord in aux_edges and chord not in aux_factor
    chord_component = next(one for one in aux_components if up in one)
    assert vp in chord_component
    assert vp not in adjacency(aux_vertices, aux_factor)[up]

    all_matchings = enumerate_perfect_matchings()
    separated_histogram = Counter()
    for matching in all_matchings:
        if ROOT_EDGE not in matching:
            continue
        complement_components = components(VERTICES, EDGES - matching)
        index = {
            vertex: i
            for i, one in enumerate(complement_components)
            for vertex in one
        }
        if index[0] != index[7]:
            separated_histogram[len(complement_components)] += 1
    assert separated_histogram == Counter({2: 3, 3: 1})

    print(
        {
            "graph": "Note_064_order_12_plane_brace",
            "root_edge": ROOT_EDGE,
            "perfect_matchings": len(all_matchings),
            "root_separated_cycle_histogram": dict(sorted(separated_histogram.items())),
            "witness_primal_factor_cycles": 3,
            "auxiliary_factor_cycle_sizes": sorted(len(one) for one in aux_components),
            "specified_chord_cycle_is_spanning": len(chord_component) == len(aux_vertices),
            "auxiliary_other_cycles": len(aux_components) - 1,
        }
    )


if __name__ == "__main__":
    main()
