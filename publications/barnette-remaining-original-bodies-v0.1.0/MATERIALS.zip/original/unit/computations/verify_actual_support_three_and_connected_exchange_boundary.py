#!/usr/bin/env python3
"""Verify the actual support-three circuit and connected abstract boundary."""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations, combinations_with_replacement, product

import networkx as nx

import verify_fixed_fibre_degree_projection_nonpolymatroid as base


Edge = tuple[int, int]
Forest = frozenset[Edge]
Vector = tuple[int, ...]


TARGET_VECTORS = (
    (1, 2, 3, 1, 2),
    (2, 1, 1, 2, 3),
    (2, 1, 2, 3, 1),
)

ABSTRACT_STATES = (
    (-1, -1, -1, 1, 1),
    (-1, -1, 0, 0, 1),
    (-1, 0, -1, 1, 0),
    (-1, 0, 0, 1, -1),
    (-1, 0, 1, 0, -1),
    (-1, 1, -1, 0, 0),
    (-1, 1, -1, 1, -1),
    (0, 0, -1, 1, -1),
    (0, 1, -1, -1, 0),
    (1, -1, -1, 1, -1),
)


def enumerate_fixed_fibre(graph: nx.Graph) -> tuple[tuple[int, ...], tuple[int, ...], tuple[Forest, ...]]:
    colour = nx.bipartite.color(graph)
    y_side = tuple(sorted(v for v in graph if colour[v] == colour[base.ROOT]))
    x_side = tuple(sorted(set(graph) - set(y_side)))
    y_order = tuple(v for v in y_side if v != base.ROOT)
    ports = tuple(sorted(graph[base.ROOT]))
    pole_vertices = tuple(sorted(set(graph) - {base.ROOT}))
    pole = graph.subgraph(pole_vertices)

    choices = []
    for x in x_side:
        required = 1 if x in ports else 2
        incident = tuple(sorted(base.edge(x, y) for y in pole[x]))
        choices.append(
            tuple(frozenset(selected) for selected in combinations(incident, required))
        )

    fibre = []
    for local_selection in product(*choices):
        selected = frozenset().union(*local_selection)
        support = nx.Graph()
        support.add_nodes_from(pole_vertices)
        support.add_edges_from(selected)
        if not nx.is_forest(support) or nx.number_connected_components(support) != 2:
            continue
        blocks = sorted(
            (
                tuple(sorted(set(component) & set(ports)))
                for component in nx.connected_components(support)
            ),
            key=lambda block: (len(block), block),
        )
        if blocks == [(base.SINGLETON_PORT,), (7, 8)]:
            fibre.append(selected)
    return x_side, y_order, tuple(sorted(fibre, key=lambda forest: tuple(sorted(forest))))


def degree_vector(forest: Forest, y_order: tuple[int, ...]) -> Vector:
    return tuple(sum(y in selected for selected in forest) for y in y_order)


def compatible_degrees(first: Vector, second: Vector) -> bool:
    return all(a + b <= 4 for a, b in zip(first, second, strict=True))


def same_x_pivot(first: Forest, second: Forest, x_side: set[int]) -> bool:
    if len(first ^ second) != 2:
        return False
    removed = next(iter(first - second))
    added = next(iter(second - first))
    removed_x = next(v for v in removed if v in x_side)
    added_x = next(v for v in added if v in x_side)
    return removed_x == added_x


def compatible_excess(first: Vector, second: Vector) -> bool:
    return all(a + b <= 0 for a, b in zip(first, second, strict=True))


def unit_transfer(first: Vector, second: Vector) -> bool:
    return sum(abs(a - b) for a, b in zip(first, second, strict=True)) == 2


def verify_actual_fibre() -> dict[str, object]:
    graph = nx.from_graph6_bytes(base.GRAPH6.encode())
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    assert set(dict(graph.degree()).values()) == {3}

    x_side, y_order, fibre = enumerate_fixed_fibre(graph)
    assert x_side == (6, 7, 8, 9, 10, 11)
    assert y_order == (1, 2, 3, 4, 5)
    assert base.strict_hall_brace(graph, x_side)
    assert base.strict_hall_brace(graph, (base.ROOT,) + y_order)
    assert len(fibre) == 22

    vectors = tuple(degree_vector(forest, y_order) for forest in fibre)
    _, _, distinct_vectors, raw_count = base.fixed_fibre_vectors(graph)
    assert raw_count == len(fibre) == 22
    assert set(vectors) == set(distinct_vectors) and len(distinct_vectors) == 13
    assert all(target in distinct_vectors for target in TARGET_VECTORS)

    excess = tuple(tuple(value - 2 for value in vector) for vector in TARGET_VECTORS)
    average = tuple(
        sum(Fraction(vector[index], 3) for vector in excess)
        for index in range(5)
    )
    assert average == (Fraction(-1, 3), Fraction(-2, 3), 0, 0, 0)
    assert all(
        not compatible_degrees(TARGET_VECTORS[i], TARGET_VECTORS[j])
        for i, j in combinations_with_replacement(range(3), 2)
    )

    pivot_graph = nx.Graph()
    pivot_graph.add_nodes_from(range(len(fibre)))
    pivot_graph.add_edges_from(
        (i, j)
        for i, j in combinations(range(len(fibre)), 2)
        if same_x_pivot(fibre[i], fibre[j], set(x_side))
    )
    assert pivot_graph.number_of_edges() == 35 and nx.is_connected(pivot_graph)

    forest_a = frozenset(
        base.edge(*selected)
        for selected in ((1, 6), (2, 8), (2, 10), (3, 7), (3, 9), (3, 11), (4, 11), (5, 9), (5, 10))
    )
    forest_b = frozenset(
        base.edge(*selected)
        for selected in ((1, 7), (1, 9), (2, 6), (3, 11), (4, 8), (4, 10), (5, 9), (5, 10), (5, 11))
    )
    forest_c = frozenset(
        base.edge(*selected)
        for selected in ((1, 6), (1, 9), (2, 10), (3, 7), (3, 11), (4, 8), (4, 10), (4, 11), (5, 9))
    )
    assert tuple(degree_vector(forest, y_order) for forest in (forest_a, forest_b, forest_c)) == TARGET_VECTORS
    assert all(forest in fibre for forest in (forest_a, forest_b, forest_c))

    chord_data = (
        (forest_a, base.edge(5, 10), base.edge(4, 10), TARGET_VECTORS[1]),
        (forest_a, base.edge(3, 11), base.edge(5, 11), TARGET_VECTORS[2]),
        (forest_b, base.edge(5, 11), base.edge(4, 11), TARGET_VECTORS[0]),
    )
    for source, removed, added, partner in chord_data:
        neighbour = (source - {removed}) | {added}
        assert neighbour in fibre
        assert same_x_pivot(source, neighbour, set(x_side))
        assert compatible_degrees(degree_vector(neighbour, y_order), partner)

    box_vectors = tuple(sorted(vector for vector in distinct_vectors if max(vector) <= 2))
    assert box_vectors == (
        (1, 2, 2, 2, 2),
        (2, 1, 2, 2, 2),
        (2, 2, 2, 2, 1),
    )
    return {
        "forests": len(fibre),
        "degree_vectors": len(distinct_vectors),
        "pivot_edges": pivot_graph.number_of_edges(),
        "target_average": tuple(str(value) for value in average),
        "compatibility_chords_checked": len(chord_data),
    }


def verify_connected_abstract_model() -> dict[str, object]:
    assert all(set(state) <= {-1, 0, 1} and sum(state) == -1 for state in ABSTRACT_STATES)
    assert all(
        not compatible_excess(ABSTRACT_STATES[i], ABSTRACT_STATES[j])
        for i, j in combinations_with_replacement(range(len(ABSTRACT_STATES)), 2)
    )
    exchange = nx.Graph()
    exchange.add_nodes_from(range(len(ABSTRACT_STATES)))
    exchange.add_edges_from(
        (i, j)
        for i, j in combinations(range(len(ABSTRACT_STATES)), 2)
        if unit_transfer(ABSTRACT_STATES[i], ABSTRACT_STATES[j])
    )
    assert exchange.number_of_edges() == 13 and nx.is_connected(exchange)
    assert nx.diameter(exchange) == 4

    support = (1, 8, 9)
    weights = (Fraction(1, 4), Fraction(1, 2), Fraction(1, 4))
    average = tuple(
        sum(weight * ABSTRACT_STATES[index][coordinate] for weight, index in zip(weights, support, strict=True))
        for coordinate in range(5)
    )
    assert average == (0, 0, Fraction(-3, 4), Fraction(-1, 4), 0)
    return {
        "states": len(ABSTRACT_STATES),
        "unit_transfer_edges": exchange.number_of_edges(),
        "diameter": nx.diameter(exchange),
        "average": tuple(str(value) for value in average),
    }


def main() -> None:
    print({"actual_fibre": verify_actual_fibre(), "abstract_model": verify_connected_abstract_model()})
    print("ACTUAL_SUPPORT_THREE_AND_CONNECTED_EXCHANGE_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
