#!/usr/bin/env python3
"""Verify a realizable locked boundary for the degree-four NAE lift."""

from __future__ import annotations

from itertools import combinations, product

import networkx as nx


REDUCED_EDGES = (
    (0, 1), (0, 2), (0, 3), (0, 4),
    (1, 2), (1, 3), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9),
    (2, 4), (2, 5),
    (3, 4), (3, 6),
    (4, 5), (4, 6), (4, 7), (4, 8), (4, 9),
    (5, 7), (6, 8), (7, 9), (8, 9),
)

EXPANDED_EDGES = (
    (0, 2), (0, 3), (0, 4), (0, 10), (0, 11), (0, 12),
    (2, 4), (2, 5), (2, 10),
    (3, 4), (3, 6), (3, 11),
    (4, 5), (4, 6), (4, 7), (4, 8), (4, 9),
    (5, 7), (5, 10),
    (6, 8), (6, 11),
    (7, 9), (7, 10),
    (8, 9), (8, 11),
    (9, 10), (9, 11), (9, 12),
    (10, 12), (11, 12),
)

REDUCED_COLOUR = {
    0: 0, 1: 0, 2: 1, 3: 1, 4: 0,
    5: 1, 6: 1, 7: 1, 8: 1, 9: 0,
}

ROOT = (0, 4)
CONTRACTED = 1
LEFT = 10
RIGHT = 11
CENTRE = 12
SITE_NEIGHBOURS = (0, 9)
LEFT_ARC = (0, 2, 5, 7, 9)
RIGHT_ARC = (9, 8, 6, 3, 0)


def plane_faces(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    planar, embedding = nx.check_planarity(graph)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    used: set[tuple[int, int]] = set()
    faces: list[tuple[int, ...]] = []
    for first, second in embedding.edges():
        if (first, second) not in used:
            faces.append(tuple(embedding.traverse_face(first, second, used)))
    assert len(faces) == graph.number_of_edges() - graph.number_of_nodes() + 2
    return tuple(faces)


def plane_dual(graph: nx.Graph) -> nx.Graph:
    faces = plane_faces(graph)
    edge_faces: dict[tuple[int, int], list[int]] = {}
    for face_index, face in enumerate(faces):
        for index, first in enumerate(face):
            second = face[(index + 1) % len(face)]
            edge_faces.setdefault(tuple(sorted((first, second))), []).append(face_index)
    assert all(len(pair) == 2 for pair in edge_faces.values())
    dual = nx.Graph()
    dual.add_nodes_from(range(len(faces)))
    dual.add_edges_from(pair for pair in edge_faces.values())
    return dual


def is_two_extendable(graph: nx.Graph) -> bool:
    target_size = graph.number_of_nodes() // 2
    edges = tuple(graph.edges)
    for first, second in combinations(edges, 2):
        if set(first).isdisjoint(second):
            remaining = graph.copy()
            remaining.remove_nodes_from((*first, *second))
            matching = nx.algorithms.matching.max_weight_matching(
                remaining, maxcardinality=True
            )
            if len(matching) != target_size - 2:
                return False
    return True


def verify_triangulation(graph: nx.Graph, order: int) -> None:
    assert graph.number_of_nodes() == order
    assert not nx.number_of_selfloops(graph)
    assert all(degree % 2 == 0 for _, degree in graph.degree)
    assert nx.node_connectivity(graph) >= 4
    assert all(len(face) == 3 for face in plane_faces(graph))

    primal = plane_dual(graph)
    assert nx.is_connected(primal)
    assert all(degree == 3 for _, degree in primal.degree)
    assert nx.is_bipartite(primal)
    assert is_two_extendable(primal)


def is_nae(graph: nx.Graph, colour: dict[int, int]) -> bool:
    return all(
        len({colour[vertex] for vertex in face}) == 2
        for face in plane_faces(graph)
    )


def mono_graph(graph: nx.Graph, colour: dict[int, int]) -> nx.Graph:
    answer = nx.Graph()
    answer.add_nodes_from(graph.nodes)
    answer.add_edges_from(
        (first, second)
        for first, second in graph.edges
        if colour[first] == colour[second]
    )
    return answer


def rooted_profile(
    graph: nx.Graph, colour: dict[int, int]
) -> tuple[int, int, bool]:
    mono = mono_graph(graph, colour)
    components = nx.number_connected_components(mono)
    beta = mono.number_of_edges() - mono.number_of_nodes() + components
    root_on_cycle = False
    if mono.has_edge(*ROOT):
        without_root = mono.copy()
        without_root.remove_edge(*ROOT)
        root_on_cycle = nx.number_connected_components(without_root) == components
    return components, beta, root_on_cycle


def reduce_expanded(expanded: nx.Graph) -> nx.Graph:
    reduced = expanded.copy()
    reduced.remove_node(CENTRE)
    quotient = nx.contracted_nodes(reduced, LEFT, RIGHT, self_loops=False)
    quotient = nx.relabel_nodes(quotient, {LEFT: CONTRACTED})
    return nx.Graph(quotient)


def edge_set(graph: nx.Graph) -> set[tuple[int, int]]:
    return {tuple(sorted(edge)) for edge in graph.edges}


def main() -> None:
    reduced = nx.Graph(REDUCED_EDGES)
    expanded = nx.Graph(EXPANDED_EDGES)
    verify_triangulation(reduced, 10)
    verify_triangulation(expanded, 12)
    assert edge_set(reduce_expanded(expanded)) == edge_set(reduced)
    assert expanded.degree[CENTRE] == 4
    assert CENTRE not in ROOT

    assert is_nae(reduced, REDUCED_COLOUR)
    assert rooted_profile(reduced, REDUCED_COLOUR) == (3, 1, True)
    assert REDUCED_COLOUR[CONTRACTED] == REDUCED_COLOUR[SITE_NEIGHBOURS[0]]
    assert REDUCED_COLOUR[CONTRACTED] == REDUCED_COLOUR[SITE_NEIGHBOURS[1]]

    # A split copy can take the opposite colour exactly when its complete
    # neighbour arc is alternating.  Both arcs here contain 1--1 adjacencies.
    for arc in (LEFT_ARC, RIGHT_ARC):
        arc_colours = tuple(REDUCED_COLOUR[vertex] for vertex in arc)
        assert any(left == right == 1 for left, right in zip(arc_colours, arc_colours[1:]))

    fixed = {
        vertex: colour
        for vertex, colour in REDUCED_COLOUR.items()
        if vertex != CONTRACTED
    }
    nae_extensions: list[tuple[tuple[int, int, int], tuple[int, int, bool]]] = []
    target_extensions = []
    for bits in product((0, 1), repeat=3):
        colour = {
            **fixed,
            LEFT: bits[0],
            RIGHT: bits[1],
            CENTRE: bits[2],
        }
        if is_nae(expanded, colour):
            profile = rooted_profile(expanded, colour)
            nae_extensions.append((bits, profile))
            if profile == (3, 1, True):
                target_extensions.append(bits)

    assert nae_extensions == [((0, 0, 1), (4, 2, True))]
    assert not target_extensions

    # This is a witness-lift obstruction, not an RCA counterexample: the
    # expanded graph has other rooted target colourings.
    target_count = 0
    vertices = tuple(expanded.nodes)
    anchor = vertices[0]
    others = tuple(vertex for vertex in vertices if vertex != anchor)
    for bits in product((0, 1), repeat=len(others)):
        colour = {anchor: 0, **dict(zip(others, bits, strict=True))}
        if is_nae(expanded, colour) and rooted_profile(expanded, colour) == (3, 1, True):
            target_count += 1
    assert target_count > 0

    print("LOCKED_DEGREE_FOUR_BOUNDARY_VERIFIED")
    print("unique_NAE_extension", nae_extensions[0])
    print("expanded_other_rooted_targets_up_to_complement", target_count)


if __name__ == "__main__":
    main()
