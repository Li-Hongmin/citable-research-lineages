#!/usr/bin/env python3
"""Exhaust actual brace binary FEC layers at order eighteen.

All binary layers are evaluated on one representative of each ordered-site
automorphism orbit.  Automorphisms biject the X-blocks, contracted-dual
spanning trees, and opposite-colour subsets, so the representative scan
recovers the full unquotiented distribution exactly.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import subprocess

import networkx as nx


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "verify_no_strict_binary_defect_through_order_sixteen.py"
SPEC = spec_from_file_location("through_sixteen", BASE_PATH)
assert SPEC is not None and SPEC.loader is not None
BASE = module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)

Site = tuple[int, int, int, int]


def site_orbits(graph: nx.Graph, sites: set[Site]) -> dict[Site, tuple[Site, ...]]:
    automorphisms = tuple(
        nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter()
    )
    grouped: dict[Site, list[Site]] = defaultdict(list)
    for site in sites:
        representative = min(
            tuple(mapping[vertex] for vertex in site) for mapping in automorphisms
        )
        grouped[representative].append(site)
    return {
        representative: tuple(sorted(members))
        for representative, members in grouped.items()
    }


def main() -> None:
    raw = 0
    planar_three_connected = 0
    braces = []
    process = subprocess.Popen(
        ("geng", "-cqb", "-d3", "-D3", "18"),
        stdout=subprocess.PIPE,
        text=True,
    )
    assert process.stdout is not None
    for line in process.stdout:
        raw += 1
        graph6 = line.strip()
        graph = nx.from_graph6_bytes(graph6.encode())
        assert nx.is_bipartite(graph)
        if not nx.check_planarity(graph)[0] or nx.node_connectivity(graph) < 3:
            continue
        planar_three_connected += 1
        if BASE.UTILITY.is_two_extendable(graph):
            braces.append((graph6, graph))
    assert process.wait() == 0
    assert raw == 149
    assert planar_three_connected == 2
    assert len(braces) == 1

    graph6, graph = braces[0]
    assert graph6 == "Q??????wE_P_W_IO@g?h?Cg?B_?"
    sites = BASE.ordered_legal_sites(graph)
    orbits = site_orbits(graph, sites)
    automorphism_count = sum(
        1
        for _ in nx.algorithms.isomorphism.GraphMatcher(
            graph, graph
        ).isomorphisms_iter()
    )
    assert automorphism_count == 12
    assert len(sites) == 168
    assert len(orbits) == 14
    assert {len(members) for members in orbits.values()} == {12}

    gap_distribution: Counter[int] = Counter()
    equality_by_size: Counter[int] = Counter()
    common_base_counts: Counter[int] = Counter()
    representative_layers = 0
    for representative, members in sorted(orbits.items()):
        data = BASE.UTILITY.partition_data(graph, representative)
        loads = BASE.base_loads(graph, representative, data)
        layer_order = len(loads[0])
        assert layer_order == 8
        common_base_counts[len(loads)] += len(members)
        representative_layers += 1 << layer_order
        for mask in range(1 << layer_order):
            size = mask.bit_count()
            mu = min(
                sum(
                    load[index]
                    for index in range(layer_order)
                    if mask >> index & 1
                )
                for load in loads
            )
            gap = mu - size
            assert gap <= 0
            gap_distribution[gap] += len(members)
            if gap == 0:
                equality_by_size[size] += len(members)

    assert representative_layers == 14 * 256 == 3584
    assert sum(gap_distribution.values()) == 168 * 256 == 43008
    assert dict(sorted(gap_distribution.items())) == {
        -4: 336,
        -3: 9420,
        -2: 22248,
        -1: 10020,
        0: 984,
    }
    assert dict(sorted(equality_by_size.items())) == {
        0: 168,
        1: 96,
        2: 48,
        3: 48,
        4: 72,
        5: 108,
        6: 108,
        7: 168,
        8: 168,
    }
    assert dict(sorted(common_base_counts.items())) == {
        192: 12,
        224: 12,
        272: 24,
        312: 24,
        392: 24,
        400: 12,
        432: 12,
        472: 12,
        548: 12,
        560: 12,
        628: 12,
    }

    # Freeze a smallest nonempty tight layer.
    representative = (0, 9, 2, 13)
    data = BASE.UTILITY.partition_data(graph, representative)
    loads = BASE.base_loads(graph, representative, data)
    colour = nx.bipartite.color(graph)
    u, _v, _z, a = representative
    y_vertices = tuple(
        sorted(
            vertex
            for vertex in graph
            if colour[vertex] != colour[u] and vertex != a
        )
    )
    active_index = y_vertices.index(14)
    assert Counter(load[active_index] for load in loads) == {1: 112, 2: 160}

    print("ACTUAL_BRACE_COST_QUALIFIED_ONE_HOLE_EXCLUDED_AT_ORDER_18")


if __name__ == "__main__":
    main()
