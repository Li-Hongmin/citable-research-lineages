#!/usr/bin/env python3
"""Complete one-step remote C4-expansion neighbourhood of the Note 068 interface."""

from __future__ import annotations

import argparse
from collections import Counter
import importlib.util
from itertools import product
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
UNIT_DIR = Path(__file__).resolve().parents[1]
LIFT_DRIVER = (
    UNIT_DIR
    / "computations"
    / "bundles"
    / "locked-boundary-escape-through18"
    / "census_locked_escape_through18.py"
)
NOTE068_VERIFIER = (
    UNIT_DIR / "computations" / "verify_nonlocked_arc11_witness_lift_counterexample.py"
)


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


lift = load_module(LIFT_DRIVER, "barnette_locked_escape_driver")
base = load_module(NOTE068_VERIFIER, "barnette_note068_verifier")


def alternating(arc: tuple[int, ...], colour: dict[int, int]) -> bool:
    return all(colour[first] != colour[second] for first, second in zip(arc, arc[1:]))


def explicit_colouring(colour: dict[int, int]) -> dict[str, list[int]]:
    return {
        "zero_vertices": sorted(vertex for vertex, value in colour.items() if value == 0),
        "one_vertices": sorted(vertex for vertex, value in colour.items() if value == 1),
    }


def target_lifts(
    reduced: nx.Graph,
    reduced_vertices: tuple[int, ...],
    encoded: tuple[int, ...],
    expanded: nx.Graph,
    expanded_faces: tuple[tuple[int, ...], ...],
    locals_: tuple[int, int, int],
) -> tuple[dict[str, object], list[dict[str, object]]]:
    colour = lift.decode_colouring(reduced_vertices, encoded)
    gate_usage = tuple(colour[gate] == colour[base.SPLIT_VERTEX] for gate in base.GATES)
    arc_type = tuple(
        int(alternating(arc, colour)) for arc in (base.LEFT_ARC, base.RIGHT_ARC)
    )
    fixed = {
        vertex: value
        for vertex, value in colour.items()
        if vertex != base.SPLIT_VERTEX
    }
    successes = []
    assignments = []
    for bits in product((0, 1), repeat=3):
        lifted_colour = {**fixed, **dict(zip(locals_, bits, strict=True))}
        profile = lift.rooted_profile(
            expanded, expanded_faces, lifted_colour, base.ROOT
        )
        relative = tuple(bit ^ colour[base.SPLIT_VERTEX] for bit in bits)
        row = "".join(map(str, relative))
        is_target = lift.is_target_profile(profile)
        assignment = {
            "absolute_left_right_centre": bits,
            "relative_lambda_rho_d": row,
            "nae": profile[0],
            "components": profile[1],
            "cycle_rank": profile[2],
            "root_on_cycle": profile[3],
            "target": is_target,
        }
        assignments.append(assignment)
        if is_target:
            successes.append(assignment)
    summary = {
        **explicit_colouring(colour),
        "gate_usage": gate_usage,
        "arc_type": arc_type,
        "locked": all(gate_usage) and arc_type == (0, 0),
        "target_lift_count": len(successes),
        "successful_relative_rows": [item["relative_lambda_rho_d"] for item in successes],
    }
    return summary, assignments


def scan() -> dict[str, object]:
    original = nx.Graph(base.REDUCED_EDGES)
    lift.verify_reduced_triangulation(original)
    assert original.has_edge(*base.ROOT)

    planar, embedding = nx.check_planarity(original)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    remote_vertices = tuple(
        sorted(
            set(original)
            - {base.SPLIT_VERTEX}
            - set(original[base.SPLIT_VERTEX])
            - set(base.ROOT)
        )
    )
    assert remote_vertices == (8, 9)

    totals = Counter(
        remote_vertices=len(remote_vertices),
        nonconsecutive_gate_pairs=0,
        odd_arc_gate_pairs=0,
        legal_remote_expansions=0,
        legal_preserved_original_interfaces=0,
        empty_target_families=0,
        nonempty_target_families=0,
        target_instances=0,
        local_assignments_tested=0,
        target_lifts=0,
        liftable_target_instances=0,
        nonliftable_target_instances=0,
        family_failures=0,
    )
    operation_records = []
    first_failure = None
    common_escape_signatures: set[str] | None = None

    for operation_vertex in remote_vertices:
        operation_rotation = tuple(embedding.neighbors_cw_order(operation_vertex))
        for first_index, second_index, first_gate, second_gate in lift.gate_pairs(
            operation_rotation
        ):
            totals["nonconsecutive_gate_pairs"] += 1
            left_size = second_index - first_index + 1
            right_size = len(operation_rotation) - (second_index - first_index) + 1
            if left_size % 2 == 0 or right_size % 2 == 0:
                continue
            totals["odd_arc_gate_pairs"] += 1

            new_reduced, operation_locals, operation_left_arc, operation_right_arc = (
                lift.split_vertex(
                    original,
                    operation_vertex,
                    operation_rotation,
                    first_index,
                    second_index,
                )
            )
            new_reduced_faces = lift.expanded_triangulation_faces(new_reduced)
            if new_reduced_faces is None:
                continue
            totals["legal_remote_expansions"] += 1
            assert set(new_reduced[base.SPLIT_VERTEX]) == set(base.ROTATION)
            assert all(
                new_reduced.has_edge(
                    base.ROTATION[index],
                    base.ROTATION[(index + 1) % len(base.ROTATION)],
                )
                for index in range(len(base.ROTATION))
            )
            assert new_reduced.has_edge(*base.ROOT)

            final_expanded, final_locals, final_left_arc, final_right_arc = (
                lift.split_vertex(
                    new_reduced,
                    base.SPLIT_VERTEX,
                    base.ROTATION,
                    0,
                    4,
                )
            )
            assert final_left_arc == base.LEFT_ARC
            assert final_right_arc == base.RIGHT_ARC
            final_faces = lift.expanded_triangulation_faces(final_expanded)
            if final_faces is None:
                continue
            totals["legal_preserved_original_interfaces"] += 1

            families, nae_count, shape_count = lift.target_families(
                new_reduced, new_reduced_faces
            )
            new_reduced_primal = lift.dual_from_plane_graph(
                new_reduced, new_reduced_faces
            )
            family = families.get(base.ROOT, [])
            new_vertices = tuple(sorted(new_reduced))
            record: dict[str, object] = {
                "operation": {
                    "split_vertex": operation_vertex,
                    "rotation": operation_rotation,
                    "gate_indices": (first_index, second_index),
                    "gates": (first_gate, second_gate),
                    "left_arc": operation_left_arc,
                    "right_arc": operation_right_arc,
                    "left_right_centre": operation_locals,
                },
                "new_reduced_dual_vertices": new_reduced.number_of_nodes(),
                "new_reduced_nae_colourings_mod_complement": nae_count,
                "new_reduced_target_shapes_mod_complement": shape_count,
                "new_reduced_primal_graph6": nx.to_graph6_bytes(
                    new_reduced_primal, header=False
                ).decode().strip(),
                "new_reduced_brace_check": lift.verify_brace(new_reduced_primal),
                "root_target_family_size": len(family),
                "liftable_targets": 0,
                "nonliftable_targets": 0,
                "successful_relative_row_counts": {},
                "escape_signature_set": [],
                "escape_witnesses_by_signature": {},
            }
            if not family:
                totals["empty_target_families"] += 1
                operation_records.append(record)
                print(json.dumps(record, sort_keys=True), flush=True)
                continue
            totals["nonempty_target_families"] += 1

            family_summaries = []
            family_assignments = []
            row_counts: Counter[str] = Counter()
            escape_signatures: set[str] = set()
            escape_witnesses: dict[str, dict[str, object]] = {}
            for encoded in family:
                summary, assignments = target_lifts(
                    new_reduced,
                    new_vertices,
                    encoded,
                    final_expanded,
                    final_faces,
                    final_locals,
                )
                family_summaries.append(summary)
                family_assignments.append(assignments)
                totals["target_instances"] += 1
                totals["local_assignments_tested"] += 8
                totals["target_lifts"] += summary["target_lift_count"]
                if summary["target_lift_count"]:
                    totals["liftable_target_instances"] += 1
                    record["liftable_targets"] += 1
                else:
                    totals["nonliftable_target_instances"] += 1
                    record["nonliftable_targets"] += 1
                for assignment in assignments:
                    if not assignment["target"]:
                        continue
                    row = assignment["relative_lambda_rho_d"]
                    row_counts[row] += 1
                    gate_word = "".join(map(lambda value: str(int(value)), summary["gate_usage"]))
                    arc_word = "".join(map(str, summary["arc_type"]))
                    signature = f"g{gate_word}:a{arc_word}:r{row}"
                    escape_signatures.add(signature)
                    if signature not in escape_witnesses:
                        escape_witnesses[signature] = {
                            **explicit_colouring(
                                lift.decode_colouring(new_vertices, encoded)
                            ),
                            "gate_usage": summary["gate_usage"],
                            "arc_type": summary["arc_type"],
                            "assignment": assignment,
                        }

            record["successful_relative_row_counts"] = dict(sorted(row_counts.items()))
            record["escape_signature_set"] = sorted(escape_signatures)
            record["escape_witnesses_by_signature"] = dict(
                sorted(escape_witnesses.items())
            )
            operation_records.append(record)
            common_escape_signatures = (
                set(escape_signatures)
                if common_escape_signatures is None
                else common_escape_signatures & escape_signatures
            )

            if record["liftable_targets"] == 0:
                totals["family_failures"] += 1
                new_primal = lift.dual_from_plane_graph(new_reduced, new_reduced_faces)
                final_primal = lift.dual_from_plane_graph(final_expanded, final_faces)
                first_failure = {
                    **record,
                    "new_reduced_triangulation_edges": sorted(
                        lift.edge(*item) for item in new_reduced.edges()
                    ),
                    "final_expanded_triangulation_edges": sorted(
                        lift.edge(*item) for item in final_expanded.edges()
                    ),
                    "new_reduced_primal_graph6": nx.to_graph6_bytes(
                        new_primal, header=False
                    ).decode().strip(),
                    "final_expanded_primal_graph6": nx.to_graph6_bytes(
                        final_primal, header=False
                    ).decode().strip(),
                    "new_reduced_brace_check": lift.verify_brace(new_primal),
                    "final_expanded_brace_check": lift.verify_brace(final_primal),
                    "original_interface": {
                        "split_vertex": base.SPLIT_VERTEX,
                        "rotation": base.ROTATION,
                        "gates": base.GATES,
                        "left_arc": base.LEFT_ARC,
                        "right_arc": base.RIGHT_ARC,
                        "root": base.ROOT,
                        "left_right_centre": final_locals,
                    },
                    "complete_target_family": [
                        {
                            **summary,
                            "assignments": assignments,
                        }
                        for summary, assignments in zip(
                            family_summaries, family_assignments, strict=True
                        )
                    ],
                }
                print(json.dumps(record, sort_keys=True), flush=True)
                break

            print(json.dumps(record, sort_keys=True), flush=True)
        if first_failure is not None:
            break

    if first_failure is None:
        conclusion = {
            "status": "complete_one_step_remote_c4_route_closure",
            "statement": (
                "No legal C4 expansion supported away from the original split closed "
                "neighbourhood and root turns the Note 068 interface into a complete-family "
                "existence-level lifting failure."
            ),
            "common_escape_signatures": sorted(common_escape_signatures or set()),
        }
    else:
        conclusion = {
            "status": "real_complete_family_counterexample",
            "statement": (
                "One remote brace-preserving C4 expansion of the Note 068 reduced brace "
                "produces a nonempty complete target family with no target lift."
            ),
        }

    return {
        "scope": {
            "base_reduced_graph6": base.REDUCED_GRAPH6,
            "base_original_interface": {
                "split_vertex": base.SPLIT_VERTEX,
                "closed_neighbourhood": sorted(
                    {base.SPLIT_VERTEX} | set(original[base.SPLIT_VERTEX])
                ),
                "root": base.ROOT,
            },
            "remote_operation_vertices": remote_vertices,
            "operation_class": (
                "all legal dual vertex splits/C4 primal expansions whose removed dual "
                "vertex is outside the original split closed neighbourhood and root"
            ),
        },
        "coverage": dict(totals),
        "operations": operation_records,
        "first_failure": first_failure,
        "conclusion": conclusion,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    payload = scan()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
        print("certificate", arguments.output)
    print(json.dumps(payload["coverage"], sort_keys=True))
    print(json.dumps(payload["conclusion"], sort_keys=True))
    if payload["first_failure"] is None:
        print("NOTE068_REMOTE_C4_ONE_STEP_ROUTE_CLOSED")
    else:
        print("NOTE068_REMOTE_C4_COMPLETE_FAMILY_COUNTEREXAMPLE_FOUND")


if __name__ == "__main__":
    main()
