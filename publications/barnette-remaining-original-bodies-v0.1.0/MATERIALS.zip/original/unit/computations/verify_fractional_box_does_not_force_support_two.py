#!/usr/bin/env python3
"""Verify the coordinate-minimal abstract obstruction to support at most two."""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations, product


def compatible(a: tuple[int, ...], b: tuple[int, ...]) -> bool:
    return all(x + y <= 0 for x, y in zip(a, b, strict=True))


def valid_states(m: int) -> tuple[tuple[int, ...], ...]:
    return tuple(
        vector
        for vector in product((-1, 0, 1), repeat=m)
        if sum(vector) == -1
    )


def verify_coordinate_minimality() -> None:
    for m in range(1, 4):
        positive_states = tuple(
            vector for vector in valid_states(m) if max(vector) == 1
        )
        if m <= 2:
            assert not positive_states
            continue
        assert set(positive_states) == {
            (1, -1, -1),
            (-1, 1, -1),
            (-1, -1, 1),
        }
        assert all(
            compatible(a, b)
            for a, b in combinations(positive_states, 2)
        )


def verify_four_coordinate_obstruction() -> None:
    excess = (
        (-1, -1, 0, 1),
        (-1, 1, -1, 0),
        (-1, 0, 1, -1),
    )
    degrees = tuple(
        tuple(2 + value for value in vector)
        for vector in excess
    )
    assert all(vector in valid_states(4) for vector in excess)
    assert degrees == (
        (1, 1, 2, 3),
        (1, 3, 1, 2),
        (1, 2, 3, 1),
    )
    assert all(sum(vector) == 7 for vector in degrees)

    weights = (Fraction(1, 3),) * 3
    average_excess = tuple(
        sum(weight * vector[index] for weight, vector in zip(weights, excess))
        for index in range(4)
    )
    assert average_excess == (
        Fraction(-1), Fraction(0), Fraction(0), Fraction(0)
    )
    assert all(
        not compatible(excess[i], excess[j])
        for i in range(3)
        for j in range(i, 3)
    )

    # Coordinatewise nonpositivity for weights w1,w2,w3 gives the cyclic
    # inequalities w2<=w1, w3<=w2, w1<=w3, hence the unique distribution.
    w1, w2, w3 = weights
    assert w2 <= w1 and w3 <= w2 and w1 <= w3
    assert w1 == w2 == w3 == Fraction(1, 3)


def main() -> None:
    verify_coordinate_minimality()
    verify_four_coordinate_obstruction()
    print("FRACTIONAL_BOX_DOES_NOT_FORCE_SUPPORT_TWO_VERIFIED")


if __name__ == "__main__":
    main()
