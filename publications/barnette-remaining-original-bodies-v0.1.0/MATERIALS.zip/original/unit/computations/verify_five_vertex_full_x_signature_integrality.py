"""Exhaust the five-vertex full X-side one-hole block systems.

Requires the lrslib lrs executable. Arithmetic and output parsing are
exact rational. The scope is planar 3-connected rank multigraphs with one
triangle block, one parallel-pair block, and two length-two path blocks.
"""

from __future__ import annotations

from fractions import Fraction
from itertools import combinations, permutations
import shutil
import subprocess


VERTICES = tuple(range(5))
PAIRS = tuple(combinations(VERTICES, 2))
TRIANGLES = tuple(
    tuple(combinations(vertices, 2))
    for vertices in combinations(VERTICES, 3)
)
PATHS = tuple(sorted({
    tuple(sorted(((a, centre), (b, centre))))
    for centre in VERTICES
    for a, b in combinations(
        tuple(v for v in VERTICES if v != centre),
        2,
    )
}))


def three_connected(simple_edges):
    edge_set = set(simple_edges)
    for deleted in combinations(VERTICES, 2):
        remaining = set(VERTICES) - set(deleted)
        seen = {next(iter(remaining))}
        while True:
            expanded = seen | {
                v
                for u, v in edge_set
                if u in seen and v in remaining
            } | {
                u
                for u, v in edge_set
                if v in seen and u in remaining
            }
            if expanded == seen:
                break
            seen = expanded
        if seen != remaining:
            return False
    return True


def canonical(pattern):
    parallel, triangle, path_one, path_two = pattern
    encodings = []
    for permutation in permutations(VERTICES):
        def image(edge):
            return tuple(sorted((permutation[edge[0]], permutation[edge[1]])))

        encoded_paths = tuple(sorted((
            tuple(sorted(image(edge) for edge in path_one)),
            tuple(sorted(image(edge) for edge in path_two)),
        )))
        encodings.append((
            image(parallel),
            tuple(sorted(image(edge) for edge in triangle)),
            encoded_paths,
        ))
    return min(encodings)


def pattern_orbits():
    representatives = {}
    labelled_count = 0
    for parallel in PAIRS:
        for triangle in TRIANGLES:
            for i, path_one in enumerate(PATHS):
                for path_two in PATHS[i:]:
                    simple_edges = {
                        parallel,
                        *triangle,
                        *path_one,
                        *path_two,
                    }
                    if not three_connected(simple_edges):
                        continue
                    # Three-connectivity gives minimum degree three, hence
                    # at least eight simple edges. There are only nine
                    # labels and the parallel block already repeats one
                    # pair, so equality holds and no other pair repeats.
                    assert len(simple_edges) == 8
                    labelled_count += 1
                    pattern = (parallel, triangle, path_one, path_two)
                    representatives.setdefault(canonical(pattern), pattern)
    assert labelled_count == 420
    assert len(representatives) == 4
    return tuple(representatives.values())


def lrs_input(pattern, omitted):
    parallel, triangle, path_one, path_two = pattern
    edges = triangle + (parallel, parallel) + path_one + path_two
    blocks = (
        tuple(range(3)),
        (3, 4),
        (5, 6),
        (7, 8),
    )
    rows = []
    for block in blocks:
        coefficients = [0] * 9
        for i in block:
            coefficients[i] = 1
        rows.append([-1, *coefficients])

    for mask in range(1, (1 << len(VERTICES)) - 1):
        shore = frozenset(
            v for v in VERTICES if mask >> v & 1
        )
        if shore == omitted:
            continue
        rows.append([
            len(shore) - 1,
            *[
                -int(u in shore and v in shore)
                for u, v in edges
            ],
        ])

    for i in range(9):
        coefficients = [0] * 9
        coefficients[i] = 1
        rows.append([0, *coefficients])

    text = [
        "five_vertex_full_x_signature",
        "H-representation",
        "linearity 4 1 2 3 4",
        "begin",
        f"{len(rows)} 10 rational",
    ]
    text.extend(" ".join(map(str, row)) for row in rows)
    text.append("end")
    return edges, blocks, "\n".join(text) + "\n"


def enumerate_vertices(pattern, omitted):
    edges, blocks, input_text = lrs_input(pattern, omitted)
    result = subprocess.run(
        ["lrs"],
        input=input_text,
        text=True,
        capture_output=True,
        check=True,
    )
    vertices = []
    in_matrix = False
    for line in result.stdout.splitlines():
        if line.strip() == "begin":
            in_matrix = True
            continue
        if line.strip() == "end":
            break
        if not in_matrix:
            continue
        fields = line.split()
        if not fields or fields[0] == "*****":
            continue
        assert fields[0] == "1", "the bounded block slice has no rays"
        vector = tuple(Fraction(field) for field in fields[1:])
        assert len(vector) == 9
        vertices.append(vector)

    assert vertices
    for vector in vertices:
        assert all(value >= 0 for value in vector)
        assert all(sum(vector[i] for i in block) == 1 for block in blocks)
        for mask in range(1, (1 << len(VERTICES)) - 1):
            shore = frozenset(
                v for v in VERTICES if mask >> v & 1
            )
            if shore == omitted:
                continue
            value = sum(
                vector[i]
                for i, (u, v) in enumerate(edges)
                if u in shore and v in shore
            )
            assert value <= len(shore) - 1
    return vertices


def main():
    assert shutil.which("lrs"), "install lrslib and put lrs on PATH"
    representatives = pattern_orbits()
    system_count = 0
    vertex_count = 0
    for pattern in representatives:
        for size in (2, 3, 4):
            for shore in combinations(VERTICES, size):
                system_count += 1
                vertices = enumerate_vertices(pattern, frozenset(shore))
                vertex_count += len(vertices)
                assert all(
                    value.denominator == 1
                    for vector in vertices
                    for value in vector
                )
    assert system_count == 100
    assert vertex_count == 1426
    print("five-vertex systems=100 vertices=1426 all integral")
    print("FIVE_VERTEX_FULL_X_SIGNATURE_INTEGRALITY_VERIFIED")


if __name__ == "__main__":
    main()
