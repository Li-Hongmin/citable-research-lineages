# Demand-cycle containment boundary

This bundle supports [Note 129](../../../notes/129-productivity-is-demand-cycle-containment-and-braces-do-not-force-it.md).
It verifies one fixed graph, the hexagonal prism (C_6\square K_2).  It
does not generate graphs, sites, or higher orders.

From the AIMath root, run

```bash
python3 units/barnette/computations/bundles/demand-cycle-containment-boundary/verify_hexagonal_prism_demand_boundary.py
```

The terminal marker is

```text
HEXAGONAL_PRISM_DEMAND_CYCLE_BOUNDARY_VERIFIED
```

Tested with Python 3.14.6 and NetworkX 3.6.1.  SHA-256:

```text
bb04f1a6879348543628d4811a10df035f3178697b15e94c4658e3733fb80161  verify_hexagonal_prism_demand_boundary.py
```

The script verifies planarity, cubic bipartiteness, (3)-connectivity,
(2)-extendability, all (20) perfect matchings, the (C_6\dot\cup C_6)
root complement, the (C_4\dot\cup C_4) matching difference, failure of
single-cycle demand containment, and the face-length histogram.

The example is a strict boundary for generic brace/Menger arguments.  It is
not a counterexample to the legal-wide (G\lor P) statement.
