#!/usr/bin/env python3
"""Verify the fixed brace boundary in Note 129; no graph is generated."""

from collections import Counter
from itertools import combinations

import networkx as nx


EDGES = (
    (0, 1), (0, 3), (0, 5),
    (1, 2), (1, 4),
    (2, 3), (2, 9),
    (3, 10),
    (4, 5), (4, 7),
    (5, 6),
    (6, 7), (6, 11),
    (7, 8),
    (8, 9), (8, 11),
    (9, 10),
    (10, 11),
)

ROOT_MATCHING = (
    (0, 1), (2, 3), (4, 5), (6, 7), (8, 11), (9, 10),
)

ALTERNATIVE_MATCHING = (
    (0, 1), (2, 3), (4, 7), (5, 6), (8, 9), (10, 11),
)


def edge(first: int, second: int) -> frozenset[int]:
    return frozenset((first, second))


def perfect_matchings(graph: nx.Graph) -> list[frozenset[frozenset[int]]]:
    result: list[frozenset[frozenset[int]]] = []

    def extend(unused: frozenset[int], chosen: tuple[frozenset[int], ...]) -> None:
        if not unused:
            result.append(frozenset(chosen))
            return
        first = min(unused)
        for second in graph[first]:
            if second in unused:
                extend(
                    unused - {first, second},
                    chosen + (edge(first, second),),
                )

    extend(frozenset(graph), ())
    return result


def complement_components(
    graph: nx.Graph,
    matching: frozenset[frozenset[int]],
) -> list[set[int]]:
    complement = graph.copy()
    complement.remove_edges_from(map(tuple, matching))
    return [set(component) for component in nx.connected_components(complement)]


def alternating_cycle_supports(
    matching: frozenset[frozenset[int]],
    matchings: list[frozenset[frozenset[int]]],
) -> list[frozenset[frozenset[int]]]:
    supports = []
    for other in matchings:
        difference = matching ^ other
        if not difference:
            continue
        exchange = nx.Graph()
        exchange.add_edges_from(map(tuple, difference))
        if nx.is_connected(exchange) and set(dict(exchange.degree()).values()) == {2}:
            supports.append(difference)
    return supports


def plane_faces(graph: nx.Graph) -> list[tuple[int, ...]]:
    planar, embedding = nx.check_planarity(graph)
    assert planar
    seen: set[tuple[int, int]] = set()
    faces = []
    for first, second in embedding.edges():
        if (first, second) not in seen:
            faces.append(tuple(embedding.traverse_face(first, second, seen)))
    return faces


def main() -> None:
    graph = nx.Graph(EDGES)
    root_matching = frozenset(edge(*item) for item in ROOT_MATCHING)
    alternative = frozenset(edge(*item) for item in ALTERNATIVE_MATCHING)

    assert nx.is_isomorphic(graph, nx.circular_ladder_graph(6))
    assert nx.is_isomorphic(graph, nx.from_graph6_bytes(b"KlQGGS@GG__T"))
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    assert nx.node_connectivity(graph) == 3
    assert set(dict(graph.degree()).values()) == {3}

    matchings = perfect_matchings(graph)
    assert len(matchings) == 20
    assert root_matching in matchings
    assert alternative in matchings

    for first, second in combinations(graph.edges(), 2):
        if set(first).isdisjoint(second):
            required = {edge(*first), edge(*second)}
            assert any(required <= matching for matching in matchings)

    root_components = complement_components(graph, root_matching)
    assert sorted(map(len, root_components)) == [6, 6]
    assert all(
        sum(bool(set(item) & component) for component in root_components) == 2
        for item in ROOT_MATCHING
    )

    difference = root_matching ^ alternative
    exchange = nx.Graph()
    exchange.add_edges_from(map(tuple, difference))
    assert sorted(map(len, nx.connected_components(exchange))) == [4, 4]

    demand = alternative - root_matching
    single_cycle_supports = alternating_cycle_supports(root_matching, matchings)
    assert single_cycle_supports
    assert not any(demand <= support for support in single_cycle_supports)

    faces = plane_faces(graph)
    assert Counter(map(len, faces)) == Counter({4: 6, 6: 2})

    print("graph=hexagonal_prism_C6_square_K2")
    print("graph6_explicit_labelling=KsXOPCCCGA_T")
    print("perfect_matchings=20")
    print("plane_cubic_bipartite_3connected_2extendable=true")
    print("root_complement_cycles=6,6")
    print("matching_difference_cycles=4,4")
    print(f"single_alternating_cycle_supports={len(single_cycle_supports)}")
    print("demand_contained_in_single_cycle=false")
    print("face_histogram=4:6,6:2")
    print("HEXAGONAL_PRISM_DEMAND_CYCLE_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
