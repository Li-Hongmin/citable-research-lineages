#!/usr/bin/env python3
"""Classify nonsquare kill-cover sites in the frozen through-26 corpus.

The only parent objects are the graph6 representatives already frozen in
the permanent through-26 Barnette bundles.  For every direct root-opposite
square occurrence of Note 085, this script reconstructs its complete fixed
rooted target fibre and cross-sector single-cycle graph.  It then checks all
interface-disjoint facial bipartite C4 sites whose selected edges do not lie
on one facial square.

Child perfect matchings are enumerated only after the parent L11 slice is a
vertex cover.  No graph generator, random search, new parent, or neighbouring
order is used.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from functools import lru_cache
from itertools import combinations
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys

import networkx as nx


Edge = tuple[int, int]
Matching = frozenset[Edge]

HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
BASE_PATH = (
    BARNETTE
    / "computations"
    / "bundles"
    / "local-square-two-linkage-fibre"
    / "profile_direct_square_other_gate_escape.py"
)

sys.dont_write_bytecode = True


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    with contextlib.redirect_stdout(io.StringIO()):
        specification.loader.exec_module(module)
    return module


profile = load_module(BASE_PATH, "through26_kill_cover_base")
base = profile.base
corpus = profile.corpus
wide = profile.wide
lift = profile.lift
source = profile.source
edge = profile.edge


def serial_matching(matching: Matching) -> list[list[int]]:
    return [list(item) for item in sorted(matching)]


def face_edges(face: tuple[int, ...]) -> tuple[Edge, ...]:
    return tuple(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def validate_faces(
    graph: nx.Graph, faces: tuple[tuple[int, ...], ...]
) -> None:
    darts = [
        (face[index], face[(index + 1) % len(face)])
        for face in faces
        for index in range(len(face))
    ]
    expected = {
        dart
        for left, right in graph.edges()
        for dart in ((left, right), (right, left))
    }
    assert len(darts) == len(set(darts)) == 2 * graph.number_of_edges()
    assert set(darts) == expected
    assert graph.number_of_nodes() - graph.number_of_edges() + len(faces) == 2
    assert all(len(face) == len(set(face)) for face in faces)


def replace_dart(
    face: tuple[int, ...],
    left: int,
    right: int,
    inserted: tuple[int, ...],
) -> tuple[int, ...]:
    positions = [
        index
        for index in range(len(face))
        if face[index] == left and face[(index + 1) % len(face)] == right
    ]
    if not positions:
        return face
    assert len(positions) == 1
    index = positions[0]
    rotated = face[index:] + face[:index]
    return (left,) + inserted + (right,) + rotated[2:]


def facial_sites(
    graph: nx.Graph,
    faces: tuple[tuple[int, ...], ...],
    interface_vertices: frozenset[int],
) -> tuple[dict[str, object], ...]:
    """Return every interface-disjoint nonsquare legal facial site."""

    square_boundaries = {
        frozenset(face_edges(face)) for face in faces if len(face) == 4
    }
    seen: set[frozenset[Edge]] = set()
    records = []
    for face_index, face in enumerate(faces):
        degree = len(face)
        assert degree % 2 == 0
        for first_index, second_index in combinations(range(degree), 2):
            distance = second_index - first_index
            if distance in (1, degree - 1) or distance % 2:
                continue
            selected = (
                edge(face[first_index], face[(first_index + 1) % degree]),
                edge(face[second_index], face[(second_index + 1) % degree]),
            )
            assert set(selected[0]).isdisjoint(selected[1])
            key = frozenset(selected)
            if key in seen:
                continue
            seen.add(key)
            selected_vertices = frozenset(
                vertex for item in selected for vertex in item
            )
            if selected_vertices & interface_vertices:
                continue
            if any(key <= square for square in square_boundaries):
                continue
            records.append(
                {
                    "face_index": face_index,
                    "face_length": degree,
                    "indices": (first_index, second_index),
                    "selected": selected,
                }
            )
    return tuple(records)


def expand_on_face(
    graph: nx.Graph,
    faces: tuple[tuple[int, ...], ...],
    record: dict[str, object],
) -> tuple[
    nx.Graph,
    tuple[tuple[int, ...], ...],
    tuple[Edge, ...],
]:
    face_index = int(record["face_index"])
    first_index, second_index = record["indices"]
    assert isinstance(first_index, int) and isinstance(second_index, int)
    face = faces[face_index]
    first_left = face[first_index]
    first_right = face[(first_index + 1) % len(face)]
    second_left = face[second_index]
    second_right = face[(second_index + 1) % len(face)]
    first, second = record["selected"]
    assert first == edge(first_left, first_right)
    assert second == edge(second_left, second_right)

    next_vertex = max(graph) + 1
    a, b, c, d = range(next_vertex, next_vertex + 4)
    child = graph.copy()
    child.remove_edges_from((first, second))
    child.add_edges_from(
        (
            (first_left, a),
            (a, b),
            (b, first_right),
            (second_left, c),
            (c, d),
            (d, second_right),
            (a, d),
            (b, c),
        )
    )

    updated = []
    for index, old_face in enumerate(faces):
        if index == face_index:
            continue
        new_face = replace_dart(old_face, first_right, first_left, (b, a))
        new_face = replace_dart(new_face, second_right, second_left, (d, c))
        updated.append(new_face)
    first_channel = face[first_index + 1 : second_index + 1] + (c, b)
    second_channel = (
        face[second_index + 1 :] + face[: first_index + 1] + (a, d)
    )
    updated.extend((first_channel, second_channel, (a, b, c, d)))
    child_faces = tuple(updated)
    validate_faces(child, child_faces)
    assert nx.is_connected(child)
    assert nx.is_bipartite(child)
    assert set(dict(child.degree()).values()) == {3}
    assert nx.check_planarity(child)[0]
    local = (
        edge(first_left, a),
        edge(a, b),
        edge(b, first_right),
        edge(second_left, c),
        edge(c, d),
        edge(d, second_right),
        edge(a, d),
        edge(b, c),
    )
    return child, child_faces, local


def enumerate_perfect_matchings(graph: nx.Graph) -> tuple[Matching, ...]:
    vertices = tuple(sorted(graph))
    position = {vertex: index for index, vertex in enumerate(vertices)}
    neighbours = {
        position[vertex]: sum(
            1 << position[other] for other in graph[vertex]
        )
        for vertex in vertices
    }

    @lru_cache(maxsize=None)
    def enumerate_mask(mask: int) -> tuple[tuple[tuple[int, int], ...], ...]:
        if mask == 0:
            return ((),)
        candidates = [
            index for index in range(len(vertices)) if mask & (1 << index)
        ]
        first = min(
            candidates,
            key=lambda index: (neighbours[index] & mask).bit_count(),
        )
        choices = neighbours[first] & mask
        without_first = mask ^ (1 << first)
        result = []
        while choices:
            bit = choices & -choices
            choices ^= bit
            second = bit.bit_length() - 1
            for suffix in enumerate_mask(without_first ^ bit):
                result.append(((first, second),) + suffix)
        return tuple(result)

    encoded = enumerate_mask((1 << len(vertices)) - 1)
    matchings = tuple(
        frozenset(edge(vertices[left], vertices[right]) for left, right in item)
        for item in encoded
    )
    assert len(matchings) == len(set(matchings))
    return matchings


def difference_component_count(first: Matching, second: Matching) -> int:
    difference = first ^ second
    if not difference:
        return 0
    graph = nx.Graph()
    graph.add_edges_from(difference)
    assert set(dict(graph.degree()).values()) == {2}
    return nx.number_connected_components(graph)


def is_root_target(
    graph: nx.Graph,
    matching: Matching,
    root: Edge,
    forced_gate: Edge,
) -> bool:
    if root not in matching or forced_gate not in matching:
        return False
    complement = graph.copy()
    complement.remove_edges_from(matching)
    assert set(dict(complement.degree()).values()) == {2}
    components = tuple(nx.connected_components(complement))
    if len(components) != 2:
        return False
    return all(len(set(root) & component) == 1 for component in components)


def legal_wide_arcs(
    faces: tuple[tuple[int, ...], ...],
    root: Edge,
    forced_gate: Edge,
    surviving_gate: Edge,
) -> tuple[int, int] | None:
    witnesses = []
    for face in faces:
        boundary = face_edges(face)
        if forced_gate not in boundary or surviving_gate not in boundary:
            continue
        if root in boundary:
            continue
        delta = (
            boundary.index(surviving_gate) - boundary.index(forced_gate)
        ) % len(boundary)
        arcs = (delta + 1, len(boundary) - delta + 1)
        if min(arcs) >= 5 and all(size % 2 for size in arcs):
            witnesses.append(tuple(sorted(arcs)))
    assert len(witnesses) <= 1
    return witnesses[0] if witnesses else None


def local_cell(matching: Matching, local: tuple[Edge, ...]) -> str:
    ua, ab, bv, xc, cd, dy, ad, bc = local
    patterns = {
        frozenset((ad, bc)): "C00",
        frozenset((ua, bv, cd)): "C10",
        frozenset((xc, dy, ab)): "C01",
        frozenset((ua, bv, xc, dy)): "C11",
        frozenset((ab, cd)): "R00",
        frozenset((ua, bc, dy)): "Xuy",
        frozenset((ad, bv, xc)): "Xvx",
    }
    patch = matching & frozenset(local)
    assert patch in patterns, (patch, local)
    return patterns[patch]


def classify_child(
    graph: nx.Graph,
    faces: tuple[tuple[int, ...], ...],
    site: dict[str, object],
    root: Edge,
    forced_gate: Edge,
    surviving_gate: Edge,
) -> dict[str, object]:
    child, child_faces, local = expand_on_face(graph, faces, site)
    matchings = enumerate_perfect_matchings(child)
    fibre = tuple(
        matching
        for matching in matchings
        if is_root_target(child, matching, root, forced_gate)
    )
    sectors = (
        tuple(matching for matching in fibre if surviving_gate not in matching),
        tuple(matching for matching in fibre if surviving_gate in matching),
    )
    cells = {matching: local_cell(matching, local) for matching in fibre}
    assert all(cell != "C11" for cell in cells.values())
    crossings = tuple(
        (first, second)
        for first in sectors[0]
        for second in sectors[1]
        if difference_component_count(first, second) == 1
    )
    new_cells = {"R00", "Xuy", "Xvx"}
    new_cell_crossings = tuple(
        pair
        for pair in crossings
        if cells[pair[0]] in new_cells or cells[pair[1]] in new_cells
    )
    canonical_crossings = len(crossings) - len(new_cell_crossings)
    assert canonical_crossings == 0

    arcs = legal_wide_arcs(
        child_faces, root, forced_gate, surviving_gate
    )
    three_connected = nx.node_connectivity(child) >= 3
    brace = bool(three_connected and source.is_two_extendable_direct(child))
    if brace:
        assert source.strict_hall_two_extendable(child)
    return {
        "child_order": child.number_of_nodes(),
        "child_perfect_matchings": len(matchings),
        "child_three_connected": three_connected,
        "child_brace": brace,
        "child_legal_wide_arcs": arcs,
        "child_legal_wide_brace": bool(brace and arcs is not None),
        "child_fibre_size": len(fibre),
        "child_sector_sizes": tuple(map(len, sectors)),
        "child_cell_histogram": dict(
            sorted(Counter(cells.values()).items())
        ),
        "child_crossings": len(crossings),
        "child_crossing_nonempty": bool(crossings),
        "new_cell_crossings": len(new_cell_crossings),
        "canonical_crossings": canonical_crossings,
    }


def analyse_graph(order: int, source_graph6: str) -> tuple[Counter, list]:
    primal = nx.from_graph6_bytes(source_graph6.encode())
    assert primal.number_of_nodes() == order
    planar, embedding = nx.check_planarity(primal, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    primal_faces = source.plane_faces(primal, embedding)
    validate_faces(primal, primal_faces)
    assert lift.verify_brace(primal)

    reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift.verify_reduced_triangulation(reduced)
    splits = wide.legal_wide_splits(reduced, rotations, Counter())
    if not splits:
        return Counter({"parent_braces": 1}), []

    families, _, _ = lift.target_families(reduced, reduced_faces)
    reduced_vertices = tuple(sorted(reduced))
    dual_to_primal = wide.primal_edge_by_dual_edge(primal, primal_faces)
    family_matchings: dict[Edge, tuple[Matching, ...]] = {}
    for root, encoded_family in families.items():
        colours = tuple(
            lift.decode_colouring(reduced_vertices, encoded)
            for encoded in encoded_family
        )
        matchings = tuple(
            wide.matching_from_colour(
                primal, reduced, dual_to_primal, colour
            )
            for colour in colours
        )
        assert len(matchings) == len(set(matchings))
        family_matchings[root] = matchings

    counts: Counter[str] = Counter({"parent_braces": 1})
    hits = []
    site_cache: dict[
        tuple[frozenset[int], Edge, Edge], tuple[dict[str, object], ...]
    ] = {}
    for split in splits:
        z = int(split["z"])
        gates = (
            dual_to_primal[edge(z, int(split["first_gate"]))],
            dual_to_primal[edge(z, int(split["second_gate"]))],
        )
        for dual_root in sorted(families):
            if z in dual_root:
                continue
            matchings = family_matchings[dual_root]
            primal_root = dual_to_primal[dual_root]
            local_data = tuple(
                base.opposite_on_square(primal, primal_root, gate)
                for gate in gates
            )
            local_indices = tuple(
                index
                for index, (local, _square) in enumerate(local_data)
                if local
            )
            if not local_indices:
                continue
            assert len(local_indices) == 1
            local_index = local_indices[0]
            forced_gate = gates[local_index]
            surviving_gate = gates[1 - local_index]
            assert all(forced_gate in matching for matching in matchings)
            if all(surviving_gate in matching for matching in matchings):
                counts["discarded_two_forced_gates"] += 1
                continue
            _local, square = local_data[local_index]
            assert square is not None
            counts["fixed_fibre_occurrences"] += 1
            assert all(
                is_root_target(primal, matching, primal_root, forced_gate)
                for matching in matchings
            )

            sector0 = tuple(
                index
                for index, matching in enumerate(matchings)
                if surviving_gate not in matching
            )
            sector1 = tuple(
                index
                for index, matching in enumerate(matchings)
                if surviving_gate in matching
            )
            crossings = tuple(
                (first, second)
                for first in sector0
                for second in sector1
                if difference_component_count(
                    matchings[first], matchings[second]
                )
                == 1
            )
            if not crossings:
                counts["fixed_fibres_with_empty_crossing_graph"] += 1
                continue
            counts["fixed_fibres_with_nonempty_crossing_graph"] += 1

            interface_vertices = frozenset(square) | frozenset(
                vertex for gate in gates for vertex in gate
            )
            site_key = (
                frozenset(interface_vertices),
                forced_gate,
                surviving_gate,
            )
            if site_key not in site_cache:
                site_cache[site_key] = facial_sites(
                    primal, primal_faces, interface_vertices
                )
            sites = site_cache[site_key]
            counts["nonsquare_interface_disjoint_sites_tested"] += len(sites)
            for site in sites:
                selected = site["selected"]
                assert isinstance(selected, tuple)
                l11 = {
                    index
                    for index, matching in enumerate(matchings)
                    if selected[0] in matching and selected[1] in matching
                }
                counts["sites_with_nonempty_L11"] += bool(l11)
                cover = bool(l11) and all(
                    first in l11 or second in l11
                    for first, second in crossings
                )
                if not cover:
                    continue
                counts["nonsquare_kill_cover_hits"] += 1
                child = classify_child(
                    primal,
                    primal_faces,
                    site,
                    primal_root,
                    forced_gate,
                    surviving_gate,
                )
                counts["hits_with_legal_wide_brace_child"] += int(
                    child["child_legal_wide_brace"]
                )
                counts["legal_wide_brace_hits_with_crossing"] += int(
                    child["child_legal_wide_brace"]
                    and child["child_crossing_nonempty"]
                )
                counts["legal_wide_brace_hits_without_crossing"] += int(
                    child["child_legal_wide_brace"]
                    and not child["child_crossing_nonempty"]
                )
                hits.append(
                    {
                        "parent_order": order,
                        "source_graph6": source_graph6,
                        "root": primal_root,
                        "forced_gate": forced_gate,
                        "surviving_gate": surviving_gate,
                        "root_gate_square": square,
                        "parent_fibre_size": len(matchings),
                        "parent_sector_sizes": (len(sector0), len(sector1)),
                        "parent_crossings": len(crossings),
                        "parent_L11_indices": sorted(l11),
                        "site": {
                            "face_index": site["face_index"],
                            "face_length": site["face_length"],
                            "indices": site["indices"],
                            "selected": site["selected"],
                        },
                        **child,
                    }
                )
    return counts, hits


def classify() -> dict[str, object]:
    totals: Counter[str] = Counter()
    by_order = {}
    hits = []
    corpora = corpus.frozen_graphs()
    for order, graph6_values in corpora.items():
        order_counts: Counter[str] = Counter()
        for source_graph6 in graph6_values:
            counts, graph_hits = analyse_graph(order, source_graph6)
            order_counts.update(counts)
            totals.update(counts)
            hits.extend(graph_hits)
        by_order[str(order)] = dict(sorted(order_counts.items()))
        print(
            f"order {order}: fibres="
            f"{order_counts['fixed_fibre_occurrences']} sites="
            f"{order_counts['nonsquare_interface_disjoint_sites_tested']} "
            f"hits={order_counts['nonsquare_kill_cover_hits']}",
            flush=True,
        )

    assert totals["fixed_fibre_occurrences"] == 541
    assert totals["fixed_fibres_with_empty_crossing_graph"] == 0
    counterexamples = tuple(
        record
        for record in hits
        if record["child_legal_wide_brace"]
        and not record["child_crossing_nonempty"]
    )
    eligible_positive = tuple(
        record
        for record in hits
        if record["child_legal_wide_brace"]
        and record["child_crossing_nonempty"]
    )
    if counterexamples:
        status = "REAL_NONSQUARE_KILL_COVER_COUNTEREXAMPLE"
    elif not hits:
        status = "NONSQUARE_KILL_COVER_HIT_SET_EMPTY"
    elif totals["hits_with_legal_wide_brace_child"] == 0:
        status = "KILL_COVER_HITS_EXIST_BUT_NO_ELIGIBLE_CHILD"
    else:
        assert len(eligible_positive) == totals[
            "hits_with_legal_wide_brace_child"
        ]
        status = "ALL_ELIGIBLE_NONSQUARE_KILL_COVER_HITS_POSITIVE"

    return {
        "status": status,
        "scope": {
            "parent_inputs": (
                "only the 50 graph6 representatives frozen in permanent "
                "through-26 bundles"
            ),
            "orders": list(corpora),
            "fixed_fibres": (
                "all 541 direct root-opposite-square legal-wide occurrences"
            ),
            "sites": (
                "all facial bipartite C4 sites vertex-disjoint from the "
                "root square and both named gates, excluding pairs lying "
                "on one facial square"
            ),
            "parent_antecedent": (
                "nonempty cross-sector single-cycle graph and L11 vertex cover"
            ),
            "no_graph_generation": True,
            "children_enumerated_only_after_kill_cover": True,
            "not_claimed": (
                "new parent graphs, parents above order 26, or an "
                "arbitrary-order rooted split-bond theorem"
            ),
        },
        "by_order": by_order,
        "counts": dict(sorted(totals.items())),
        "counterexamples": counterexamples,
        "hits": hits,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=HERE / "through26_nonsquare_kill_cover.json",
    )
    arguments = parser.parse_args()
    payload = classify()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    arguments.output.write_text(rendered)
    print(json.dumps(payload["counts"], sort_keys=True))
    print("status", payload["status"])
    print("json_sha256", hashlib.sha256(rendered.encode()).hexdigest())
    print("THROUGH26_NONSQUARE_KILL_COVER_CLASSIFIED")


if __name__ == "__main__":
    main()
