# Rooted split-bond supplementation through order 26

This bundle supports
[Note 110](../../../notes/110-nonsquare-kill-cover-supplementation-holds-through-order-twenty-six-in-the-frozen-root-square-stratum.md).

Run from the AIMath root:

```bash
PYTHONHASHSEED=0 uv run --python 3.12 --with 'networkx==3.6.1' \
  units/barnette/computations/bundles/rooted-split-bond-through26/classify_through26_nonsquare_kill_cover.py
```

The classifier reads the 50 graph6 representatives already frozen in the
permanent through-order-26 bundles. It generates no new parent graph. For
every direct root-opposite-square legal-wide fixed fibre it reconstructs all
interface-disjoint nonsquare cofacial sites, tests the parent kill-cover
antecedent, and enumerates a child complete perfect-matching family only for
the 323 hits.

The bundled JSON stores the aggregate counts and all 323 hit records. Its
SHA-256 is

```text
76dd3664ea7f85c1cbbad0edd09c5ce7925c7b8ceee901da6cb5a59fd8c75bf8
```

Expected final lines:

```text
status ALL_ELIGIBLE_NONSQUARE_KILL_COVER_HITS_POSITIVE
json_sha256 76dd3664ea7f85c1cbbad0edd09c5ce7925c7b8ceee901da6cb5a59fd8c75bf8
THROUGH26_NONSQUARE_KILL_COVER_CLASSIFIED
```

The promotion environment was Python 3.12 with NetworkX 3.6.1 on
2026-08-28.
