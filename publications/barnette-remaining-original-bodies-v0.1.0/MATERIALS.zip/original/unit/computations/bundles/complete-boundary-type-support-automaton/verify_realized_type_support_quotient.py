#!/usr/bin/env python3
"""Verify the realized unary/pair-type support quotient for one local step.

Three maps are kept separate:

1. current boundary rows -> four parent-PM cells (kill-cover);
2. current boundary rows -> seven child-PM cells (supplementation);
3. current boundary rows -> generalized CEN/UV next-boundary rows.

Only finite marked-partition atoms on the four old stubs are used.  No graph,
decoration, random sample, or second expansion step is enumerated.
"""

from __future__ import annotations

from collections import defaultdict
import importlib.util
from itertools import product
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
LOCAL_VERIFIER = (
    HERE.parent
    / "cen-uv-complete-boundary-row-closure"
    / "verify_cen_uv_next_boundary_closure.py"
)
OUTPUT = HERE / "realized_type_support_quotient.json"


def load_local_verifier():
    spec = importlib.util.spec_from_file_location("cen_uv_local", LOCAL_VERIFIER)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


local = load_local_verifier()


def edge(left: str, right: str) -> tuple[str, str]:
    return local.normalized_edge(left, right)


PARENT_PRODUCTIONS = (
    {"name": "P00", "source": "empty", "target": "C00", "edges": frozenset()},
    {"name": "P10", "source": "uv", "target": "C10", "edges": frozenset((edge("u", "v"),))},
    {"name": "P01", "source": "xy", "target": "C01", "edges": frozenset((edge("x", "y"),))},
    {"name": "P11", "source": "uvxy", "target": "C11", "edges": frozenset((edge("u", "v"), edge("x", "y")))},
)

CHILD_PRODUCTIONS = (
    {"name": "C00", "source": "empty", "target": "C00", "edges": frozenset((edge("a", "d"), edge("b", "c")))},
    {"name": "C10", "source": "uv", "target": "C10", "edges": frozenset((edge("u", "a"), edge("b", "v"), edge("c", "d")))},
    {"name": "C01", "source": "xy", "target": "C01", "edges": frozenset((edge("x", "c"), edge("d", "y"), edge("a", "b")))},
    {"name": "C11", "source": "uvxy", "target": "C11", "edges": frozenset((edge("u", "a"), edge("b", "v"), edge("x", "c"), edge("d", "y")))},
    {"name": "R00", "source": "empty", "target": "R00", "edges": frozenset((edge("a", "b"), edge("c", "d")))},
    {"name": "Xuy", "source": "uy", "target": "Xuy", "edges": frozenset((edge("u", "a"), edge("d", "y"), edge("b", "c")))},
    {"name": "Xvx", "source": "vx", "target": "Xvx", "edges": frozenset((edge("a", "d"), edge("b", "v"), edge("x", "c")))},
)

SUPPLEMENTING_CELLS = frozenset(("R00", "Xuy", "Xvx"))
KILL_CELL = "C11"
DIAGONAL_EPSILON = local.canonical_profile(
    [], [{f"old:{vertex}"} for vertex in local.OLD_BOUNDARY], 0
)


def labels_for_site(site_name: str) -> dict[str, tuple[str, ...]]:
    labels: dict[str, list[str]] = defaultdict(list)
    for vertex in local.OLD_BOUNDARY:
        labels[vertex].append(f"old:{vertex}")
    for role, vertex in zip(
        ("u", "v", "x", "y"), local.SITES[site_name]["boundary"], strict=True
    ):
        labels[vertex].append(f"next:{role}")
    return {vertex: tuple(items) for vertex, items in labels.items()}


def next_row_datum(site_name: str, pattern: dict) -> tuple:
    available = frozenset(local.PATCH_EDGES) - local.SITES[site_name]["edges"]
    complement = available - pattern["edge_set"]
    profile = local.graph_profile(complement, labels_for_site(site_name))
    return (pattern["next_class"], pattern["next_class"], profile)


def next_unary_type(site_name: str, old_unary_type: tuple, pattern: dict) -> tuple:
    old_class, old_delta = old_unary_type
    assert old_class == pattern["old_class"]
    return (
        pattern["next_class"],
        local.join_profiles(old_delta, next_row_datum(site_name, pattern)),
    )


def completed_component_count(old_profile: tuple, local_edges: frozenset) -> int:
    """Join an old cut atom to local difference edges and remove all stubs."""
    union = local.UnionFind()
    token_vertex = {f"old:{vertex}": vertex for vertex in local.OLD_BOUNDARY}
    for block_index, block in enumerate(old_profile[0]):
        hub = ("old-block", block_index)
        union.add(hub, active=True)
        for token in block:
            vertex = token_vertex[token]
            union.add(vertex, active=True)
            union.union(hub, vertex)
    for left, right in local_edges:
        union.add(left, active=True)
        union.add(right, active=True)
        union.union(left, right)
    roots = {union.find(node) for node in union.parent}
    return min(3, old_profile[2] + len(roots))


def full_pair_output(
    old_epsilon: tuple,
    equality: bool,
    first: dict,
    second: dict,
) -> tuple:
    component_count = completed_component_count(
        old_epsilon, first["edges"] ^ second["edges"]
    )
    return (
        first["target"],
        second["target"],
        equality and first["name"] == second["name"],
        component_count,
    )


def next_pair_output(
    site_name: str,
    old_epsilon: tuple,
    equality: bool,
    first: dict,
    second: dict,
) -> tuple:
    datum = local.local_join_datum(site_name, first, second)
    return (
        first["next_class"],
        second["next_class"],
        equality and first["name"] == second["name"],
        local.join_profiles(old_epsilon, datum),
    )


def is_bond_component_count(component_count: int) -> bool:
    return component_count == 1


def is_cut_bond(old_epsilon: tuple) -> bool:
    return len(old_epsilon[0]) + old_epsilon[2] == 1


def group_by_source(productions: tuple[dict, ...]) -> dict[str, list[dict]]:
    grouped = {name: [] for name in local.CLASS_POSITIONS}
    for production in productions:
        grouped[production["source"]].append(production)
    return grouped


def verify_unary_functionality(old_atoms: tuple, next_patterns: dict) -> dict:
    counts = {}
    for map_name, productions, local_universe in (
        (
            "parent_pm",
            PARENT_PRODUCTIONS,
            frozenset((edge("u", "v"), edge("x", "y"))),
        ),
        ("seven_cell_child_pm", CHILD_PRODUCTIONS, frozenset(local.PATCH_EDGES)),
    ):
        outcomes: dict[tuple, set[tuple]] = defaultdict(set)
        for production, old_delta in product(productions, old_atoms):
            input_unary = (production["source"], old_delta)
            key = (input_unary, production["name"])
            # This is the unmarked component-count core of the exact marked
            # complement join.  Every omitted root/gate mark rides its unique
            # old block under the same deterministic union operation.
            complement = local_universe - production["edges"]
            outcomes[key].add(
                (
                    production["target"],
                    completed_component_count(old_delta, complement),
                )
            )
        assert all(len(values) == 1 for values in outcomes.values())
        counts[map_name] = {
            "typed_local_transitions": len(productions) * len(old_atoms),
            "functional_codes": len(outcomes),
            "collisions": 0,
        }

    for site_name, patterns in next_patterns.items():
        outcomes = defaultdict(set)
        for pattern, old_delta in product(patterns, old_atoms):
            input_unary = (pattern["old_class"], old_delta)
            datum = next_row_datum(site_name, pattern)
            outcomes[(input_unary, datum)].add(
                next_unary_type(site_name, input_unary, pattern)
            )
        assert all(len(values) == 1 for values in outcomes.values())
        counts[f"generalized_next_{site_name}"] = {
            "typed_local_transitions": len(patterns) * len(old_atoms),
            "functional_codes": len(outcomes),
            "collisions": 0,
        }
    return counts


def verify_full_pair_map(
    map_name: str,
    productions: tuple[dict, ...],
    old_atoms: tuple,
) -> dict:
    outcomes: dict[tuple, set[tuple]] = defaultdict(set)
    off_diagonal_checks = 0
    diagonal_checks = 0
    for first, second in product(productions, repeat=2):
        local_datum = (
            first["target"],
            second["target"],
            tuple(sorted(first["edges"] ^ second["edges"])),
        )
        for old_epsilon in old_atoms:
            input_pair_type = (
                first["source"], second["source"], False, old_epsilon
            )
            output = full_pair_output(old_epsilon, False, first, second)
            outcomes[(input_pair_type, local_datum)].add(output)
            off_diagonal_checks += 1
        if first["source"] == second["source"]:
            input_pair_type = (
                first["source"], second["source"], True, DIAGONAL_EPSILON
            )
            output = full_pair_output(DIAGONAL_EPSILON, True, first, second)
            outcomes[(input_pair_type, local_datum)].add(output)
            diagonal_checks += 1
    assert all(len(values) == 1 for values in outcomes.values())
    return {
        "map": map_name,
        "off_diagonal_typed_transition_checks": off_diagonal_checks,
        "diagonal_typed_transition_checks": diagonal_checks,
        "functional_codes": len(outcomes),
        "collisions": 0,
    }


def verify_next_pair_map(site_name: str, patterns: list[dict], old_atoms: tuple) -> dict:
    outcomes: dict[tuple, set[tuple]] = defaultdict(set)
    off_diagonal_checks = 0
    diagonal_checks = 0
    for first, second in product(patterns, repeat=2):
        datum = local.local_join_datum(site_name, first, second)
        for old_epsilon in old_atoms:
            input_pair_type = (
                first["old_class"], second["old_class"], False, old_epsilon
            )
            output = next_pair_output(
                site_name, old_epsilon, False, first, second
            )
            outcomes[(input_pair_type, datum)].add(output)
            off_diagonal_checks += 1
        if first["old_class"] == second["old_class"]:
            input_pair_type = (
                first["old_class"],
                second["old_class"],
                True,
                DIAGONAL_EPSILON,
            )
            output = next_pair_output(
                site_name, DIAGONAL_EPSILON, True, first, second
            )
            outcomes[(input_pair_type, datum)].add(output)
            diagonal_checks += 1
    assert all(len(values) == 1 for values in outcomes.values())
    return {
        "map": f"generalized_next_{site_name}",
        "off_diagonal_typed_transition_checks": off_diagonal_checks,
        "diagonal_typed_transition_checks": diagonal_checks,
        "functional_codes": len(outcomes),
        "collisions": 0,
    }


def partition_profile(*blocks: tuple[str, ...]) -> tuple:
    active = [{f"old:{vertex}" for vertex in block} for block in blocks]
    return local.canonical_profile(active, [], 0)


def find_production(productions: tuple[dict, ...], name: str) -> dict:
    return next(item for item in productions if item["name"] == name)


def weakening_collisions() -> dict:
    # Equality-bit deletion: a formal one-row/two-row typed-support pair.
    # The off-diagonal use of the diagonal core is deliberately an abstract
    # relational realization, not a claim about two distinct graph matchings.
    unique_source_pattern = next(
        pattern
        for pattern in local.enumerate_patterns("CEN")
        if pattern["old_class"] == "uy"
    )
    equality_collision = {
        "status": "STRICT_ABSTRACT_TYPED_SUPPORT_COLLISION",
        "map": "generalized_next_CEN",
        "source_unary_type": "A=(uy,delta_0)",
        "unique_local_pattern": unique_source_pattern["name"],
        "input_without_equality_bit": {
            "unary_type_support": ["A"],
            "ordered_pair_core_support": ["(A,A,epsilon_0)"],
        },
        "realization_1": "one row r; only (r,r)",
        "realization_2": "two rows r,s; all four ordered pairs share epsilon_0",
        "different_full_outputs": {
            "realization_1": "diagonal output pair type only",
            "realization_2": "both diagonal and off-diagonal output pair types",
        },
        "scope_warning": "formal finite relational support; not asserted graph-realizable",
    }

    # Removing off-diagonal same-unary-type support hides a real closed-cycle
    # pair atom.  Keep one visible C11--A bond in both realizations so that
    # the crossing graph and C11 slice remain nonempty; the hidden A--A bond
    # then changes the full kill-cover antecedent.
    closed_cycle = local.canonical_profile(
        [], [{f"old:{vertex}"} for vertex in local.OLD_BOUNDARY], 1
    )
    visible_linked = partition_profile(("u", "v", "x", "y"))
    p10 = find_production(PARENT_PRODUCTIONS, "P10")
    p11 = find_production(PARENT_PRODUCTIONS, "P11")
    assert is_bond_component_count(
        full_pair_output(closed_cycle, False, p10, p10)[3]
    )
    assert is_bond_component_count(
        full_pair_output(visible_linked, False, p11, p10)[3]
    )
    off_diagonal_collision = {
        "status": "STRICT_PORT_REALIZABLE_COLLISION",
        "map": "current_boundary_to_parent_pm_kill_cover",
        "source_unary_types": {
            "C": "C11 unary atom",
            "A": "(uv, non-C11 unary atom)",
        },
        "input_after_dropping_off_diagonal_same_type_pairs": {
            "unary_type_support": ["C", "A"],
            "retained_pair_support": [
                "diagonal endpoint types",
                "visible bond(C,A,linked)",
            ],
        },
        "realization_1": "one C-row and one A-row",
        "realization_2": (
            "one C-row and two A-rows; every C--A bond is visible, "
            "and the hidden A--A difference is one unmarked closed cycle"
        ),
        "nonvacuity_in_both": {
            "parent_crossing_graph_nonempty": True,
            "C11_slice_nonempty": True,
        },
        "truth_values": {
            "realization_1_kill_cover": True,
            "realization_2_kill_cover": False,
        },
        "visible_pair_profile": profile_json(visible_linked),
        "hidden_pair_profile": profile_json(closed_cycle),
    }

    # Boolean-only deletion collision.  The uy endpoint has no parent-PM
    # ancestor, so the ordinary current Boolean bond bit is false in both
    # realizations.  Its complete epsilon atom still controls child and next
    # bonds.  The profiles differ by one unmarked closed component.
    linked = visible_linked
    linked_plus_cycle = local.canonical_profile(
        [{f"old:{vertex}" for vertex in local.OLD_BOUNDARY}], [], 1
    )
    c00 = find_production(CHILD_PRODUCTIONS, "C00")
    xuy = find_production(CHILD_PRODUCTIONS, "Xuy")
    child_linked = full_pair_output(linked, False, c00, xuy)
    child_plus_cycle = full_pair_output(linked_plus_cycle, False, c00, xuy)
    assert child_linked[3] == 1 and child_plus_cycle[3] == 2

    cen_patterns = local.enumerate_patterns("CEN")
    next_left = next(row for row in cen_patterns if row["name"] == "empty:ab_cd")
    next_right = next(
        row for row in cen_patterns if row["name"] == "uv:ua_yd"
    )
    next_linked = next_pair_output(
        "CEN", linked, False, next_left, next_right
    )
    next_plus_cycle = next_pair_output(
        "CEN", linked_plus_cycle, False, next_left, next_right
    )
    assert is_cut_bond(next_linked[3]) and not is_cut_bond(next_plus_cycle[3])

    boolean_collision = {
        "status": "STRICT_PORT_PARTITION_COLLISION",
        "weakened_input_pair_type": {
            "endpoint_unary_types": ("empty boundary row", "uy cross boundary row"),
            "endpoint_unary_types_retained": True,
            "equality_bit": False,
            "ordinary_parent_bond": False,
            "reason": "the uy cross row has no parent-PM ancestor",
        },
        "full_profiles": {
            "linked": profile_json(linked),
            "linked_plus_one_closed_cycle": profile_json(linked_plus_cycle),
        },
        "parent_pm_kill_cover": {
            "linked": True,
            "linked_plus_one_closed_cycle": True,
            "note": "no collision here; current kill-cover factors through Boolean parent pair support",
        },
        "seven_cell_supplementation_collision": {
            "endpoint_cells": ("C00", "Xuy"),
            "linked_completed_components": child_linked[3],
            "linked_plus_cycle_completed_components": child_plus_cycle[3],
            "linked_supplementation": True,
            "linked_plus_cycle_supplementation": False,
            "qualification": "fix identical rooted/gate-change marks to true",
        },
        "generalized_next_CEN_collision": {
            "patterns": (next_left["name"], next_right["name"]),
            "linked_next_profile": profile_json(next_linked[3]),
            "linked_plus_cycle_next_profile": profile_json(next_plus_cycle[3]),
            "linked_next_cut_bond": True,
            "linked_plus_cycle_next_cut_bond": False,
        },
    }
    return {
        "delete_equality_bit": equality_collision,
        "delete_off_diagonal_same_unary_type_support": off_diagonal_collision,
        "replace_full_pair_atom_by_boolean_bond": boolean_collision,
    }


def profile_json(profile: tuple) -> dict:
    return {
        "active_blocks": profile[0],
        "inactive_blocks": profile[1],
        "closed_components_saturated": profile[2],
    }


def main() -> None:
    old_atoms = local.old_boundary_atoms()
    next_patterns = {
        site_name: local.enumerate_patterns(site_name)
        for site_name in local.SITES
    }
    unary_checks = verify_unary_functionality(old_atoms, next_patterns)
    pair_checks = [
        verify_full_pair_map(
            "current_boundary_to_parent_pm", PARENT_PRODUCTIONS, old_atoms
        ),
        verify_full_pair_map(
            "current_boundary_to_seven_cell_child_pm", CHILD_PRODUCTIONS, old_atoms
        ),
        verify_next_pair_map("CEN", next_patterns["CEN"], old_atoms),
        verify_next_pair_map("UV", next_patterns["UV"], old_atoms),
    ]
    collisions = weakening_collisions()

    payload = {
        "status": "EXACT_REALIZED_TYPE_SUPPORT_QUOTIENT_FOR_ONE_LOCAL_STEP",
        "proposition_F": True,
        "scope": {
            "abstract_old_boundary_partition_atoms": len(old_atoms),
            "actual_graphs_touched": 0,
            "decoration_orbits_touched": 0,
            "random_cases": 0,
            "expansion_depth": 1,
            "permanent_notes_written": 0,
        },
        "quotient_fields": {
            "unary_support": "set of realized complete unary row-atom types",
            "ordered_pair_support": "set of realized complete pair-atom types",
            "pair_endpoints": "ordered endpoint unary types",
            "pair_equality": "explicit diagonal/equality bit",
            "multiplicity": "not retained",
        },
        "three_separate_maps": {
            "parent_pm": {
                "local_rows": len(PARENT_PRODUCTIONS),
                "predicate": "kill-cover is universal over realized parent bond pair types",
            },
            "seven_cell_child_pm": {
                "local_rows": len(CHILD_PRODUCTIONS),
                "supplementing_cells": tuple(sorted(SUPPLEMENTING_CELLS)),
                "predicate": "supplementation is existential over realized child bond pair types",
            },
            "generalized_next_boundary": {
                site: len(patterns) for site, patterns in next_patterns.items()
            },
        },
        "functional_checks": {
            "unary": unary_checks,
            "ordered_pairs": pair_checks,
            "all_collisions": 0,
        },
        "exact_support_image_law": {
            "unary": "U+ = { f(a,P) : a in U and P compatible with a }",
            "ordered_pairs": "R+ = { g(b,P,Q) : b in R and P,Q compatible with its ordered endpoint types }",
            "output_equality": "eq+ = eq(b) and (P = Q)",
            "reason": "every output row/pair restricts uniquely, and every listed compatible production extends",
        },
        "predicate_factorization": {
            "kill_cover": "for every realized parent pair type: bond implies an endpoint cell is C11",
            "supplementation": "there exists a realized rooted gate-changing child bond pair type incident with R00, Xuy, or Xvx",
        },
        "weakening_collisions": collisions,
        "conclusion": {
            "multiplicity_and_row_identities_needed": False,
            "off_diagonal_same_type_pair_support_needed": True,
            "complete_pair_partition_needed": True,
            "endpoint_unary_types_needed": True,
            "explicit_equality_bit_needed_for_abstract_relational_supports": True,
            "claim_beyond_one_local_step": False,
        },
    }
    OUTPUT.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print("status", payload["status"])
    print("proposition_F", payload["proposition_F"])
    print("unary_checks", json.dumps(unary_checks, sort_keys=True))
    print("pair_checks", json.dumps(pair_checks, sort_keys=True))
    print(
        "weakening_collisions",
        json.dumps({key: value["status"] for key, value in collisions.items()}, sort_keys=True),
    )
    print("output", OUTPUT)


if __name__ == "__main__":
    main()
