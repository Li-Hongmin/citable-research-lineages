# Complete boundary type-support automaton

This bundle checks the finite quotient of Note 133.  A quotient retains:

1. the support of all realized complete unary boundary-row types;
2. the support of all realized complete ordered pair types;
3. both endpoint unary types and the row-equality bit in every pair type;
4. the full marked pair-deletion partition, not only its Boolean bond value.

The verifier keeps three local maps separate:

- current boundary rows to the four parent-PM cells;
- current boundary rows to the seven child-PM cells;
- current boundary rows to the \(11\)-row CEN or \(12\)-row UV generalized
  next boundary.

For each map it verifies that unary output type and ordered-pair output type
are functions of the retained input types and the fixed local production
patterns.  The diagonal rule is

\[
\operatorname{eq}^{+}
=\operatorname{eq}\wedge[\text{the two local patterns are equal}].
\]

The bundle also freezes three strict weakening collisions:

- deleting the equality bit confuses one row with two equal-type rows;
- deleting off-diagonal same-type support hides a non-\(C_{11}\) bond and
  changes parent kill-cover even though a visible \(C_{11}\) bond keeps
  both the crossing graph and the \(C_{11}\) slice nonempty;
- replacing the full pair atom by a Boolean bond preserves the current
  Boolean value but changes both child supplementation and the next pair
  type.

Run from the AIMath root:

~~~bash
uv run --python 3.12 \
  python units/barnette/computations/bundles/complete-boundary-type-support-automaton/verify_realized_type_support_quotient.py
~~~

The terminal status is:

~~~text
EXACT_REALIZED_TYPE_SUPPORT_QUOTIENT_FOR_ONE_LOCAL_STEP
~~~

Frozen SHA256 values:

~~~text
verifier  3c68c944b7e1b4d71f5cb8d3544378bce3f696f2cd768776924b60970841c019
output    c5a986458221f0df694e0ab9562448c717a9dde5cc28dd65bf408e2402afce95
~~~

The finite verification covers local marked-partition functionality and the
three weakening collisions.  The all-depth statement of Note 133 follows
analytically by iterating the exact one-step quotient map.  This bundle does
not enumerate graphs, decide graph realizability, or prove rooted
split-bond supplementation.
