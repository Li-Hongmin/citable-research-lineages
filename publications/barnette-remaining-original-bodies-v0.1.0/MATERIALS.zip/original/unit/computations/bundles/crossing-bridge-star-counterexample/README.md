# Crossing-bridge star counterexample

This bundle verifies the fixed order-\(22\) counterexample in
[Note 154](../../../notes/154-a-crossing-bridge-can-be-an-isolated-mixed-component.md).
It decodes one graph6 string, enumerates every perfect matching, reconstructs
the complete rooted fixed-pairing fibre, and builds its complete
single-alternating-cycle exchange graph.

From the AIMath root, run

    uv run --python 3.14 --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/crossing-bridge-star-counterexample/verify_order22_crossing_bridge_star_counterexample.py

The verified environment on 2026-08-29 was Python 3.14.6 with NetworkX
3.6.1. The terminal marker is

    ORDER22_CROSSING_BRIDGE_STAR_COUNTEREXAMPLE_VERIFIED

The verifier checks the plane cubic bipartite brace conditions, all 119
perfect matchings, extension of all 462 independent edge pairs, the facial
root square, the legal-wide gate face, the complete eight-member rooted
family, and every edge of its exchange graph.
