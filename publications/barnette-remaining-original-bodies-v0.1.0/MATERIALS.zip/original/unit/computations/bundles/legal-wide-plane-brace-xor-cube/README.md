# Legal-wide plane-brace XOR cube

This bundle verifies Note 099 on the fixed 28-vertex residual of Note 098.
It checks, in one deterministic run:

1. the explicit target-preserving square attachment and legal-wide face;
2. planarity, bipartiteness, cubicity and the facial root square;
3. all 811 perfect matchings of the 32-vertex extension and extension of all
   1,032 independent edge pairs;
4. all 212 residual perfect matchings and the complete \(41=16+25\)
   fixed-\(I\) fibre;
5. all 400 cross-sector pairs, including the 69 one-cycle exchanges and the
   nonminimum atomic double-\(E\) XOR pair.

Run from the AIMath root:

```bash
uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/legal-wide-plane-brace-xor-cube/verify_legal_wide_plane_brace_xor_cube.py
```

The final line must be

```text
LEGAL_WIDE_PLANE_BRACE_XOR_CUBE_VERIFIED
```

The bundle uses Python 3.12 and NetworkX.  It performs no graph generation,
random search, solver call, brace repair or order extension.
