# Fixed common-\(B\) crossing without a rooted triangle

This bundle verifies the counterexample in
[Note 153](../../../notes/153-a-fixed-common-b-unique-crossing-can-have-no-rooted-triangle.md).
It uses only the fixed graph6 string and independently reconstructs the
entire perfect-matching and rooted fixed-pairing families; it does not read
the exploratory through-order-\(26\) corpus.

From the AIMath root, run

    uv run --python 3.14 --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/fixed-common-b-no-rooted-triangle/verify_fixed_common_b_no_rooted_triangle.py

The verified environment on 2026-08-29 was Python 3.14.6 with NetworkX
3.6.1. The terminal marker is

    FIXED_COMMON_B_NO_ROOTED_TRIANGLE_VERIFIED

The verifier checks simplicity, planarity, cubicity, bipartiteness,
3-connectivity, all 244 perfect matchings, extension of all 558 independent
edge pairs, both named facial cycles, legal-wide arc sizes, the complete
15-member rooted fibre, all 22 single-cycle exchange edges, the fixed-edge
three-member subfibre, its unique crossing, and the absence of any rooted
common exchange neighbour of the distinguished endpoints.
