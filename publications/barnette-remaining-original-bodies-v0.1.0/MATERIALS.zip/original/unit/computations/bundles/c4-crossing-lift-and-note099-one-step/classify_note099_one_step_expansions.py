#!/usr/bin/env python3
"""Classify every one-step facial C4 move on the fixed Note 099 graph.

The parent graph, embedding-independent plane faces, complete perfect-
matching family and fixed root-square fibre are imported from the permanent
Note 099 verifier.  No graph generation, random search or order census is
performed.

For a chosen pair of cofacial edges, every child perfect matching is obtained
from a parent perfect matching by one of the five exhaustive local C4
patterns.  This gives both a direct brace test and an exact ancestor map for
every child member of the inherited fixed-pairing fibre.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations
from pathlib import Path
import contextlib
import csv
import io
import json
import runpy

import networkx as nx


HERE = Path(__file__).resolve().parent
BASE_PATH = (
    HERE.parent
    / "legal-wide-plane-brace-xor-cube"
    / "verify_legal_wide_plane_brace_xor_cube.py"
)

with contextlib.redirect_stdout(io.StringIO()):
    BASE = runpy.run_path(BASE_PATH)

edge = BASE["edge"]
face_edges = BASE["face_edges"]
plane_faces = BASE["plane_faces"]
cyclic_equal = BASE["cyclic_equal"]
delta_component_count = BASE["delta_component_count"]
enumerate_perfect_matchings = BASE["enumerate_perfect_matchings"]

PARENT_EDGES = BASE["EXTENSION_EDGES"]
PARENT_GRAPH = nx.Graph()
PARENT_GRAPH.add_nodes_from(sorted(BASE["EXTENSION_VERTICES"]))
PARENT_GRAPH.add_edges_from(sorted(tuple(sorted(item)) for item in PARENT_EDGES))
PARENT_MATCHINGS = tuple(BASE["extension_matchings"])
_planar, _embedding = nx.check_planarity(PARENT_GRAPH)
assert _planar
PARENT_FACES = tuple(plane_faces(_embedding))
ROOT = BASE["ROOT"]
FORCED_GATE = BASE["FORCED_GATE"]
SURVIVING_GATE = BASE["SURVIVING_GATE"]
ROOT_SQUARE = frozenset(BASE["SQUARE"])
ROOT_SQUARE_EDGES = frozenset(BASE["SQUARE_EDGES"])
OLD_FIBRE = tuple(
    matching | frozenset((ROOT, FORCED_GATE)) for matching in BASE["fibre"]
)
OLD_FIBRE_SET = frozenset(OLD_FIBRE)


def validate_faces(graph: nx.Graph, faces: tuple[tuple[str, ...], ...]) -> None:
    darts = [
        (face[index], face[(index + 1) % len(face)])
        for face in faces
        for index in range(len(face))
    ]
    expected = {
        dart
        for left, right in graph.edges()
        for dart in ((left, right), (right, left))
    }
    assert len(darts) == len(set(darts)) == 2 * graph.number_of_edges()
    assert set(darts) == expected
    assert graph.number_of_nodes() - graph.number_of_edges() + len(faces) == 2


def replace_dart(
    face: tuple[str, ...], left: str, right: str, inserted: tuple[str, ...]
) -> tuple[str, ...]:
    positions = [
        index
        for index in range(len(face))
        if face[index] == left and face[(index + 1) % len(face)] == right
    ]
    if not positions:
        return face
    assert len(positions) == 1
    index = positions[0]
    rotated = face[index:] + face[:index]
    return (left,) + inserted + (right,) + rotated[2:]


def expand_on_face(
    face_index: int, first_index: int, second_index: int
) -> tuple[nx.Graph, tuple[tuple[str, ...], ...], tuple[frozenset[str], ...]]:
    face = PARENT_FACES[face_index]
    first_left = face[first_index]
    first_right = face[(first_index + 1) % len(face)]
    second_left = face[second_index]
    second_right = face[(second_index + 1) % len(face)]
    prefix = f"m{face_index}_{first_index}_{second_index}_"
    a, b, c, d = tuple(prefix + letter for letter in "abcd")

    child = PARENT_GRAPH.copy()
    child.remove_edge(first_left, first_right)
    child.remove_edge(second_left, second_right)
    child.add_edges_from(
        (
            (first_left, a),
            (a, b),
            (b, first_right),
            (second_left, c),
            (c, d),
            (d, second_right),
            (a, d),
            (b, c),
        )
    )

    updated = []
    for index, old_face in enumerate(PARENT_FACES):
        if index == face_index:
            continue
        new_face = replace_dart(old_face, first_right, first_left, (b, a))
        new_face = replace_dart(new_face, second_right, second_left, (d, c))
        updated.append(new_face)
    first_channel = face[first_index + 1 : second_index + 1] + (c, b)
    second_channel = face[second_index + 1 :] + face[: first_index + 1] + (a, d)
    updated.extend((first_channel, second_channel, (a, b, c, d)))
    child_faces = tuple(updated)
    validate_faces(child, child_faces)
    assert nx.is_bipartite(child) and nx.check_planarity(child)[0]
    assert set(dict(child.degree()).values()) == {3}
    local = (
        edge(first_left, a),
        edge(a, b),
        edge(b, first_right),
        edge(second_left, c),
        edge(c, d),
        edge(d, second_right),
        edge(a, d),
        edge(b, c),
    )
    return child, child_faces, local


def legal_moves() -> tuple[dict[str, object], ...]:
    records = []
    seen = set()
    for face_index, face in enumerate(PARENT_FACES):
        degree = len(face)
        for first_index, second_index in combinations(range(degree), 2):
            distance = second_index - first_index
            if distance in (1, degree - 1) or distance % 2:
                continue
            selected = (
                edge(face[first_index], face[(first_index + 1) % degree]),
                edge(face[second_index], face[(second_index + 1) % degree]),
            )
            assert not (set(selected[0]) & set(selected[1]))
            key = frozenset(selected)
            if key in seen:
                continue
            seen.add(key)
            records.append(
                {
                    "face_index": face_index,
                    "indices": (first_index, second_index),
                    "selected": selected,
                    "root_edge_unchanged": ROOT not in selected,
                    "root_square_unchanged": not (set(selected) & set(ROOT_SQUARE_EDGES)),
                    "surviving_gate_unchanged": SURVIVING_GATE not in selected,
                }
            )
    return tuple(records)


def lift_matching(
    parent: frozenset[frozenset[str]],
    selected: tuple[frozenset[str], frozenset[str]],
    local: tuple[frozenset[str], ...],
) -> tuple[frozenset[frozenset[str]], ...]:
    first, second = selected
    ua, ab, bv, xc, cd, dy, ad, bc = local
    bits = (first in parent, second in parent)
    common = parent - frozenset(selected)
    if bits == (True, True):
        patterns = ((ua, bv, xc, dy),)
    elif bits == (True, False):
        patterns = ((ua, bv, cd),)
    elif bits == (False, True):
        patterns = ((ab, xc, dy),)
    else:
        patterns = ((ab, cd), (ad, bc))
    return tuple(common | frozenset(pattern) for pattern in patterns)


def child_matchings(
    graph: nx.Graph,
    selected: tuple[frozenset[str], frozenset[str]],
    local: tuple[frozenset[str], ...],
) -> tuple[
    tuple[frozenset[frozenset[str]], ...],
    dict[frozenset[frozenset[str]], frozenset[frozenset[str]]],
]:
    ancestor = {}
    for parent in PARENT_MATCHINGS:
        for child in lift_matching(parent, selected, local):
            assert child not in ancestor
            ancestor[child] = parent
    vertices = frozenset(graph)
    edges = frozenset(edge(left, right) for left, right in graph.edges())
    children = enumerate_perfect_matchings(vertices, edges)
    # The two additional valid local patterns use the external edges at
    # opposite corners a,d or b,c.  They do not contract to a parent perfect
    # matching, so direct enumeration is required for completeness.
    assert set(ancestor) <= set(children)
    return tuple(children), ancestor


def target(graph: nx.Graph, matching: frozenset[frozenset[str]]) -> bool:
    if ROOT not in matching or FORCED_GATE not in matching:
        return False
    complement = nx.Graph()
    complement.add_nodes_from(graph)
    complement.add_edges_from(tuple(item) for item in set(map(frozenset, graph.edges())) - matching)
    assert set(dict(complement.degree()).values()) == {2}
    components = tuple(nx.connected_components(complement))
    if len(components) != 2:
        return False
    root_vertices = set(ROOT)
    return all(len(root_vertices & component) == 1 for component in components)


def one_cycle(first, second) -> bool:
    return delta_component_count(first, second) == 1


def legal_wide(faces: tuple[tuple[str, ...], ...]) -> tuple[int, int] | None:
    witnesses = []
    for face in faces:
        boundary = face_edges(face)
        if FORCED_GATE not in boundary or SURVIVING_GATE not in boundary:
            continue
        if ROOT in boundary:
            continue
        delta = (boundary.index(SURVIVING_GATE) - boundary.index(FORCED_GATE)) % len(boundary)
        arcs = (delta + 1, len(boundary) - delta + 1)
        if min(arcs) >= 5 and all(size % 2 for size in arcs):
            witnesses.append(tuple(sorted(arcs)))
    assert len(witnesses) <= 1
    return witnesses[0] if witnesses else None


def brace_certificate(
    graph: nx.Graph, matchings: tuple[frozenset[frozenset[str]], ...]
) -> tuple[bool, int, int]:
    edges = frozenset(edge(left, right) for left, right in graph.edges())
    independent = {
        frozenset((first, second))
        for first, second in combinations(edges, 2)
        if first.isdisjoint(second)
    }
    covered = {
        frozenset((first, second))
        for matching in matchings
        for first, second in combinations(matching, 2)
    }
    return independent <= covered, len(independent), len(covered & independent)


OLD_SECTOR0 = tuple(matching for matching in OLD_FIBRE if SURVIVING_GATE not in matching)
OLD_SECTOR1 = tuple(matching for matching in OLD_FIBRE if SURVIVING_GATE in matching)
OLD_CROSSINGS = frozenset(
    frozenset((first, second))
    for first in OLD_SECTOR0
    for second in OLD_SECTOR1
    if one_cycle(first, second)
)
assert len(OLD_CROSSINGS) == 69


def classify_move(record: dict[str, object]) -> dict[str, object]:
    face_index = int(record["face_index"])
    first_index, second_index = record["indices"]
    assert isinstance(first_index, int) and isinstance(second_index, int)
    selected = record["selected"]
    assert isinstance(selected, tuple)
    child, child_faces, local = expand_on_face(face_index, first_index, second_index)
    matchings, ancestor = child_matchings(child, selected, local)
    brace, independent_pairs, covered_pairs = brace_certificate(child, matchings)
    fibre = tuple(matching for matching in matchings if target(child, matching))
    sector0 = tuple(matching for matching in fibre if SURVIVING_GATE not in matching)
    sector1 = tuple(matching for matching in fibre if SURVIVING_GATE in matching)

    old_lifts: dict[frozenset[frozenset[str]], tuple[frozenset[frozenset[str]], ...]] = {}
    for old in OLD_FIBRE:
        old_lifts[old] = tuple(
            matching for matching in fibre if ancestor.get(matching) == old
        )
    assert all(len(value) <= 1 for value in old_lifts.values())
    # Independent local criterion supplied by the C4 lift calculus: the
    # canonical fixed-pairing lift exists exactly outside local state 11.
    # In state 11 the four attachment edges enter the child matching and the
    # four gadget edges form an isolated complement C4.
    assert all(
        bool(old_lifts[old]) == (not all(item in old for item in selected))
        for old in OLD_FIBRE
    )
    lift_multiplicity = Counter(len(value) for value in old_lifts.values())

    child_crossings = tuple(
        (first, second)
        for first in sector0
        for second in sector1
        if one_cycle(first, second)
    )
    retained_old = set()
    child_ancestry_histogram = Counter()
    for first, second in child_crossings:
        first_ancestor = ancestor.get(first)
        second_ancestor = ancestor.get(second)
        if first_ancestor is None or second_ancestor is None:
            child_ancestry_histogram["new_noncontractible"] += 1
            continue
        ancestral_pair = frozenset((first_ancestor, second_ancestor))
        if ancestral_pair in OLD_CROSSINGS:
            retained_old.add(ancestral_pair)
            child_ancestry_histogram["old_crossing"] += 1
        elif first_ancestor in OLD_FIBRE_SET and second_ancestor in OLD_FIBRE_SET:
            child_ancestry_histogram["old_fibre_nonedge"] += 1
        else:
            child_ancestry_histogram["new_fibre_ancestor"] += 1

    cross_histogram = Counter(
        delta_component_count(first, second)
        for first in sector0
        for second in sector1
    )
    minimum = min(cross_histogram, default=None)
    dead = OLD_CROSSINGS - retained_old
    predicted_retained = {
        pair
        for pair in OLD_CROSSINGS
        if all(not all(item in endpoint for item in selected) for endpoint in pair)
    }
    assert retained_old == predicted_retained
    death_reasons = Counter()
    for ancestral_pair in OLD_CROSSINGS:
        first, second = tuple(ancestral_pair)
        first_lifts = old_lifts[first]
        second_lifts = old_lifts[second]
        if not first_lifts or not second_lifts:
            missing = (not first_lifts) + (not second_lifts)
            death_reasons[f"missing_{missing}_canonical_endpoint"] += 1
            continue
        components = delta_component_count(first_lifts[0], second_lifts[0])
        if components == 1:
            death_reasons["retained_one_cycle"] += 1
        else:
            death_reasons[f"canonical_lift_has_{components}_components"] += 1
    assert death_reasons["retained_one_cycle"] == len(retained_old)
    assert sum(
        value for key, value in death_reasons.items() if key != "retained_one_cycle"
    ) == len(dead)
    selected_names = tuple(sorted(tuple(sorted(item)) for item in selected))

    return {
        "face_index": face_index,
        "face_length": len(PARENT_FACES[face_index]),
        "indices": (first_index, second_index),
        "selected": selected_names,
        "root_edge_unchanged": record["root_edge_unchanged"],
        "root_square_unchanged": record["root_square_unchanged"],
        "surviving_gate_unchanged": record["surviving_gate_unchanged"],
        "child_perfect_matchings": len(matchings),
        "brace": brace,
        "independent_pairs": independent_pairs,
        "covered_independent_pairs": covered_pairs,
        "node_connectivity": nx.node_connectivity(child),
        "legal_wide_arcs": legal_wide(child_faces),
        "fibre_size": len(fibre),
        "sector_sizes": (len(sector0), len(sector1)),
        "old_fibre_lift_multiplicity": dict(sorted(lift_multiplicity.items())),
        "old_crossings_retained": len(retained_old),
        "old_crossings_dead": len(dead),
        "old_crossing_death_reasons": dict(sorted(death_reasons.items())),
        "child_crossings": len(child_crossings),
        "new_child_crossings": len(child_crossings) - len(retained_old),
        "child_crossing_ancestry": dict(sorted(child_ancestry_histogram.items())),
        "cross_component_histogram": dict(sorted(cross_histogram.items())),
        "global_cross_sector_minimum": minimum,
    }


def serial_counter(counter: Counter) -> dict[str, int]:
    return {str(key): value for key, value in sorted(counter.items(), key=lambda item: str(item[0]))}


def main() -> None:
    validate_faces(PARENT_GRAPH, PARENT_FACES)
    moves = legal_moves()
    unchanged_root = tuple(record for record in moves if record["root_edge_unchanged"])
    inherited_interface = tuple(
        record
        for record in unchanged_root
        if record["root_square_unchanged"] and record["surviving_gate_unchanged"]
    )
    records = []
    for number, record in enumerate(inherited_interface, 1):
        records.append(classify_move(record))
        if number % 25 == 0:
            print(f"classified {number}/{len(inherited_interface)}", flush=True)

    totals = {
        "all_facial_bipartite_c4_moves": len(moves),
        "root_edge_unchanged_moves": len(unchanged_root),
        "root_edge_unchanged_but_root_square_destroyed": sum(
            not record["root_square_unchanged"] for record in unchanged_root
        ),
        "root_square_unchanged_but_surviving_gate_destroyed": sum(
            record["root_square_unchanged"] and not record["surviving_gate_unchanged"]
            for record in unchanged_root
        ),
        "inherited_fixed_interface_moves": len(records),
        "inherited_legal_wide_moves": sum(record["legal_wide_arcs"] is not None for record in records),
        "inherited_brace_moves": sum(record["brace"] for record in records),
        "inherited_legal_wide_brace_moves": sum(
            record["brace"] and record["legal_wide_arcs"] is not None for record in records
        ),
        "moves_killing_at_least_one_old_crossing": sum(record["old_crossings_dead"] > 0 for record in records),
        "moves_killing_all_old_crossings": sum(record["old_crossings_retained"] == 0 for record in records),
        "legal_wide_brace_moves_with_minimum_above_one": sum(
            record["brace"]
            and record["legal_wide_arcs"] is not None
            and record["global_cross_sector_minimum"] is not None
            and record["global_cross_sector_minimum"] > 1
            for record in records
        ),
    }
    histograms = {
        "old_crossings_retained": serial_counter(Counter(record["old_crossings_retained"] for record in records)),
        "old_crossings_dead": serial_counter(Counter(record["old_crossings_dead"] for record in records)),
        "child_crossings": serial_counter(Counter(record["child_crossings"] for record in records)),
        "new_child_crossings": serial_counter(Counter(record["new_child_crossings"] for record in records)),
        "global_cross_sector_minimum": serial_counter(Counter(record["global_cross_sector_minimum"] for record in records)),
        "fibre_size": serial_counter(Counter(record["fibre_size"] for record in records)),
        "sector_sizes": serial_counter(Counter(tuple(record["sector_sizes"]) for record in records)),
        "brace": serial_counter(Counter(record["brace"] for record in records)),
        "legal_wide_arcs": serial_counter(Counter(tuple(record["legal_wide_arcs"]) if record["legal_wide_arcs"] else None for record in records)),
    }
    legal_wide_braces = tuple(
        record
        for record in records
        if record["brace"] and record["legal_wide_arcs"] is not None
    )
    legal_wide_summary = {
        "moves": len(legal_wide_braces),
        "minimum_old_crossings_retained": min(
            record["old_crossings_retained"] for record in legal_wide_braces
        ),
        "maximum_old_crossings_dead": max(
            record["old_crossings_dead"] for record in legal_wide_braces
        ),
        "minimum_child_crossings": min(
            record["child_crossings"] for record in legal_wide_braces
        ),
        "maximum_child_crossings": max(
            record["child_crossings"] for record in legal_wide_braces
        ),
        "minimum_new_child_crossings": min(
            record["new_child_crossings"] for record in legal_wide_braces
        ),
        "maximum_new_child_crossings": max(
            record["new_child_crossings"] for record in legal_wide_braces
        ),
        "global_minimum_histogram": serial_counter(
            Counter(record["global_cross_sector_minimum"] for record in legal_wide_braces)
        ),
    }
    excluded_unchanged_root = []
    for record in unchanged_root:
        if record in inherited_interface:
            continue
        selected = record["selected"]
        assert isinstance(selected, tuple)
        excluded_unchanged_root.append(
            {
                "selected": tuple(sorted(tuple(sorted(item)) for item in selected)),
                "reason": (
                    "root_square_destroyed"
                    if not record["root_square_unchanged"]
                    else "surviving_gate_destroyed"
                ),
            }
        )
    payload = {
        "scope": {
            "parent": "fixed labelled order-32 Note 099 plane brace",
            "operation": "every facial bipartite C4 expansion in the frozen embedding",
            "classified_fibre_scope": "moves preserving all four root-square edges and the surviving gate",
            "not_claimed": "two steps, another graph, an order-36 census, or arbitrary-order preservation",
        },
        "totals": totals,
        "histograms": histograms,
        "legal_wide_brace_summary": legal_wide_summary,
        "excluded_unchanged_root_moves": sorted(
            excluded_unchanged_root, key=lambda item: item["selected"]
        ),
        "records": records,
    }
    output_path = HERE / "note099_one_step_expansions.json"
    output_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    table_path = HERE / "note099_one_step_effects.tsv"
    with table_path.open("w", newline="") as stream:
        writer = csv.writer(stream, delimiter="\t")
        writer.writerow(
            (
                "selected_edge_1",
                "selected_edge_2",
                "legal_wide_arcs",
                "brace",
                "old69_retained",
                "old69_dead",
                "new_child_crossings",
                "all_child_crossings",
                "global_minimum",
                "fibre_size",
                "sector_sizes",
            )
        )
        for record in sorted(records, key=lambda item: item["selected"]):
            writer.writerow(
                (
                    "-".join(record["selected"][0]),
                    "-".join(record["selected"][1]),
                    "-".join(map(str, record["legal_wide_arcs"]))
                    if record["legal_wide_arcs"]
                    else "lost",
                    int(record["brace"]),
                    record["old_crossings_retained"],
                    record["old_crossings_dead"],
                    record["new_child_crossings"],
                    record["child_crossings"],
                    record["global_cross_sector_minimum"],
                    record["fibre_size"],
                    "-".join(map(str, record["sector_sizes"])),
                )
            )
    print(json.dumps(totals, sort_keys=True))
    print(json.dumps(histograms, sort_keys=True))
    print(json.dumps(legal_wide_summary, sort_keys=True))
    print("certificate", output_path)
    print("per-move table", table_path)
    print("NOTE099_ONE_STEP_EXPANSIONS_CLASSIFIED")


if __name__ == "__main__":
    main()

