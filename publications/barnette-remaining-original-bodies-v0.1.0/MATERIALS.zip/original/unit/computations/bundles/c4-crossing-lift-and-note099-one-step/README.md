# C4 crossing lift and Note 099 one-step classification

This bundle supports
[Note 101](../../../notes/101-a-c4-expansion-kills-an-inherited-fibre-crossing-exactly-at-an-11-site.md).

Run from the AIMath root:

```bash
PYTHONHASHSEED=0 uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/c4-crossing-lift-and-note099-one-step/classify_note099_one_step_expansions.py
```

The program imports the literal graph and fixed fibre from the permanent
Note 099 bundle.  It reconstructs all facial moves, child embeddings,
perfect matchings, brace certificates, inherited lift ancestry and complete
child fibres.  It writes:

- `note099_one_step_expansions.json`, the full 79-move records;
- `note099_one_step_effects.tsv`, a compact per-move table.

The final marker is

```text
NOTE099_ONE_STEP_EXPANSIONS_CLASSIFIED
```

The expected SHA256 of the JSON is

```text
e67a8680ea1ab7009a521e37bc7f5c0fe251f5ddef8c0453766c140332770b90
```

The environment used for promotion was Python 3.12 with NetworkX supplied
by `uv` on 2026-08-28.

