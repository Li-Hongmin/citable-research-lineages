# Rooted-compatible two-cycle interpolation counterexample

This bundle verifies the fixed order-\(20\) counterexample in
[Note 161](../../../notes/161-rooted-compatible-carrier-rows-need-not-admit-single-cycle-interpolation.md).

From the AIMath root, run

    uv run --python 3.14 --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/rooted-compatible-two-cycle-interpolation-counterexample/verify_rooted_compatible_two_cycle_interpolation.py

The verified environment on 2026-08-29 was Python 3.14.6 with NetworkX
3.6.1. The terminal marker is

    ROOTED_COMPATIBLE_TWO_CYCLE_INTERPOLATION_VERIFIED

The verifier reconstructs the graph from its graph6 string and imports no
AIMath module. It enumerates all 89 parent perfect matchings and checks
extension of all 375 independent parent edge pairs. It also performs the
legal common-face \(C_4\)-expansion in the correct orientation, enumerates
all 157 child perfect matchings, and checks extension of every independent
child edge pair. Thus both graphs are verified simple plane cubic bipartite
braces.

For the displayed root and cut squares, the verifier checks the two
rooted-compatible endpoint joins, their common opposite-sector anchor, and
the zero-closed \(01\) carrier atom. Their symmetric difference is exactly
two disjoint alternating \(C_4\)'s. Each one-cycle intermediate is an actual
matching row and preserves the \(01+0\) atom, but both fail the rooted
\(N_0\)-join predicate; only the double flip reaches the second
rooted-compatible endpoint.
