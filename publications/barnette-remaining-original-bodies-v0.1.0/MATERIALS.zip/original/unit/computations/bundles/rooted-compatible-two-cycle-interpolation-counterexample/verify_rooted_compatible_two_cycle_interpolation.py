#!/usr/bin/env python3
"""Verify the order-20 rooted-compatible two-cycle interpolation boundary."""

from __future__ import annotations

from functools import lru_cache
from itertools import combinations

import networkx as nx


Edge = tuple[int, int]
Matching = frozenset[Edge]
State = frozenset[int]

GRAPH6 = "S???????F?Y?b?W_DO?Y?DG?Oo?E_?B_?"
ROOT_SQUARE = (10, 0, 11, 1)
ROOT = (0, 10)
FORCED = (1, 11)
SURVIVING = (9, 18)
GATE_FACE = (1, 11, 3, 17, 9, 18, 6, 13)
CUT_FACE = (8, 19, 9, 17)
PORTS = CUT_FACE

EMPTY = frozenset()
A0 = frozenset((0, 1))
REQUIRED_ROOT_PAIRS = frozenset(
    (frozenset((0, 3)), frozenset((1, 2)))
)
N0_FACTOR_PAIRS = (
    frozenset((0, 1)),
    frozenset((2, 3)),
)
N1_FACTOR_PAIRS = (frozenset((2, 3)),)


def edge(left: int, right: int) -> Edge:
    return (left, right) if left < right else (right, left)


ROOT = edge(*ROOT)
FORCED = edge(*FORCED)
SURVIVING = edge(*SURVIVING)


def matching(items) -> Matching:
    return frozenset(edge(*item) for item in items)


ANCHOR = matching(
    (
        (0, 10),
        (1, 11),
        (4, 12),
        (6, 13),
        (2, 14),
        (7, 15),
        (5, 16),
        (3, 17),
        (9, 18),
    )
)
LEFT = matching(
    (
        (0, 10),
        (1, 11),
        (4, 12),
        (6, 13),
        (2, 14),
        (5, 15),
        (3, 16),
        (8, 17),
        (7, 18),
        (9, 19),
    )
)
RIGHT = matching(
    (
        (0, 10),
        (1, 11),
        (5, 12),
        (6, 13),
        (2, 14),
        (4, 15),
        (8, 16),
        (3, 17),
        (7, 18),
        (9, 19),
    )
)
CYCLE_ONE = matching(((4, 12), (5, 12), (5, 15), (4, 15)))
CYCLE_TWO = matching(((3, 16), (8, 16), (8, 17), (3, 17)))
INTERMEDIATE_ONE = LEFT ^ CYCLE_ONE
INTERMEDIATE_TWO = LEFT ^ CYCLE_TWO


def face_edges(face) -> frozenset[Edge]:
    return frozenset(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def plane_faces(graph: nx.Graph):
    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    visited = set()
    result = []
    for left, right in embedding.edges():
        if (left, right) not in visited:
            result.append(tuple(embedding.traverse_face(left, right, visited)))
    return tuple(result)


def enumerate_matchings(
    graph: nx.Graph,
    removed: frozenset[int] = frozenset(),
    required: Matching = frozenset(),
) -> tuple[Matching, ...]:
    assert all(graph.has_edge(*item) for item in required)
    assert not any(set(item) & set(removed) for item in required)
    used = {vertex for item in required for vertex in item}
    assert len(used) == 2 * len(required)
    vertices = tuple(sorted(set(graph) - set(removed) - used))
    position = {vertex: index for index, vertex in enumerate(vertices)}
    neighbours = [0] * len(vertices)
    for left, right in graph.edges():
        if left in position and right in position:
            neighbours[position[left]] |= 1 << position[right]
            neighbours[position[right]] |= 1 << position[left]

    @lru_cache(maxsize=None)
    def solve(mask: int):
        if not mask:
            return ((),)
        candidates = [index for index in range(len(vertices)) if mask >> index & 1]
        first = min(
            candidates,
            key=lambda index: ((neighbours[index] & mask).bit_count(), index),
        )
        choices = neighbours[first] & mask
        remainder = mask ^ (1 << first)
        rows = []
        while choices:
            bit = choices & -choices
            choices ^= bit
            second = bit.bit_length() - 1
            for suffix in solve(remainder ^ bit):
                rows.append(((first, second),) + suffix)
        return tuple(rows)

    return tuple(
        required
        | frozenset(edge(vertices[left], vertices[right]) for left, right in row)
        for row in solve((1 << len(vertices)) - 1)
    )


def verify_brace(graph: nx.Graph, expected_matchings: int) -> None:
    assert nx.number_of_selfloops(graph) == 0 and nx.is_connected(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.is_bipartite(graph) and nx.check_planarity(graph)[0]
    assert nx.node_connectivity(graph) >= 3
    perfect_matchings = enumerate_matchings(graph)
    assert len(perfect_matchings) == expected_matchings
    independent_pairs = tuple(
        (edge(*first), edge(*second))
        for first, second in combinations(graph.edges(), 2)
        if set(first).isdisjoint(second)
    )
    assert all(
        any(first in item and second in item for item in perfect_matchings)
        for first, second in independent_pairs
    )


def c4_expand(graph: nx.Graph) -> nx.Graph:
    result = graph.copy()
    result.remove_edges_from((FORCED, SURVIVING))
    a, b, c, d = range(max(result) + 1, max(result) + 5)
    # The common facial order is 1,11,...,9,18,... .
    result.add_edges_from(
        (
            (1, a),
            (a, b),
            (b, 11),
            (9, c),
            (c, d),
            (d, 18),
            (a, d),
            (b, c),
        )
    )
    return result


def root_attachments(graph: nx.Graph):
    square = set(ROOT_SQUARE)
    result = []
    for vertex in ROOT_SQUARE:
        outside = [neighbour for neighbour in graph[vertex] if neighbour not in square]
        assert len(outside) == 1
        result.append(outside[0])
    assert len(set(result)) == 4
    return tuple(result)


def verify_near_matching(
    cut: nx.Graph, state: State, row_matching: Matching
) -> None:
    removed = {PORTS[index] for index in state}
    assert all(cut.has_edge(*item) for item in row_matching)
    assert not any(set(item) & removed for item in row_matching)
    degrees = {vertex: 0 for vertex in cut}
    for left, right in row_matching:
        degrees[left] += 1
        degrees[right] += 1
    assert all(
        degrees[vertex] == (0 if vertex in removed else 1)
        for vertex in cut
    )


def complement_profile(
    cut: nx.Graph,
    attachments,
    row_matching: Matching,
):
    residual = cut.subgraph(set(cut) - set(ROOT_SQUARE)).copy()
    residual.remove_edges_from(row_matching)
    components = []
    for vertices in nx.connected_components(residual):
        component = residual.subgraph(vertices)
        degrees = tuple(dict(component.degree()).values())
        ports = frozenset(
            index for index, vertex in enumerate(PORTS) if vertex in vertices
        )
        roots = frozenset(
            index for index, vertex in enumerate(attachments) if vertex in vertices
        )
        if degrees and all(value == 2 for value in degrees):
            kind = "cycle"
        else:
            assert degrees and all(value in {1, 2} for value in degrees)
            kind = "path"
        components.append((kind, ports, roots))
    return tuple(
        sorted(components, key=lambda item: (item[0], tuple(item[1]), tuple(item[2])))
    )


def factor_join_passes(profile, state: State, factor_pairs) -> bool:
    if any(kind == "cycle" for kind, _ports, _roots in profile):
        return False
    auxiliary = nx.Graph()
    marks = {}
    for index, (_kind, _ports, roots) in enumerate(profile):
        name = ("carrier", index)
        auxiliary.add_node(name)
        marks[name] = set(roots)
    for index, pair in enumerate(factor_pairs):
        name = ("factor", index)
        auxiliary.add_node(name)
        marks[name] = set()
        for port in pair:
            owners = [
                ("carrier", ordinal)
                for ordinal, (_kind, ports, _roots) in enumerate(profile)
                if port in ports
            ]
            if len(owners) != 1:
                return False
            auxiliary.add_edge(name, owners[0])
    covered = set().union(*(set(pair) for pair in factor_pairs))
    if covered != set(range(4)) - set(state):
        return False
    root_pairs = frozenset(
        frozenset().union(*(marks[vertex] for vertex in vertices))
        for vertices in nx.connected_components(auxiliary)
    )
    return root_pairs == REQUIRED_ROOT_PAIRS


def bond_atom(cut: nx.Graph, left_state, left, right_state, right):
    difference = left ^ right
    support = nx.edge_subgraph(cut, difference).copy()
    paths = []
    cycles = 0
    for vertices in nx.connected_components(support):
        component = support.subgraph(vertices)
        ends = [vertex for vertex, degree in component.degree() if degree == 1]
        if not ends:
            assert set(dict(component.degree()).values()) == {2}
            cycles += 1
        else:
            assert len(ends) == 2
            marks = frozenset(
                index for index, vertex in enumerate(PORTS) if vertex in ends
            )
            assert len(marks) == 2
            paths.append(marks)
    actual = set().union(*(set(path) for path in paths)) if paths else set()
    assert actual == set(left_state ^ right_state)
    return tuple(sorted(paths, key=tuple)), cycles


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert len(graph) == 20 and graph.number_of_edges() == 30
    verify_brace(graph, expected_matchings=89)
    faces = plane_faces(graph)
    facial_sets = {face_edges(face) for face in faces}
    assert face_edges(ROOT_SQUARE) in facial_sets
    assert face_edges(CUT_FACE) in facial_sets
    assert face_edges(GATE_FACE) in facial_sets
    assert set(ROOT_SQUARE).isdisjoint(CUT_FACE)
    assert ROOT in face_edges(ROOT_SQUARE) and FORCED in face_edges(ROOT_SQUARE)
    assert set(ROOT).isdisjoint(FORCED)

    gate_boundary = tuple(
        edge(GATE_FACE[index], GATE_FACE[(index + 1) % len(GATE_FACE)])
        for index in range(len(GATE_FACE))
    )
    first = gate_boundary.index(FORCED)
    second = gate_boundary.index(SURVIVING)
    delta = (second - first) % len(gate_boundary)
    assert sorted((delta + 1, len(gate_boundary) - delta + 1)) == [5, 5]
    verify_brace(c4_expand(graph), expected_matchings=157)

    cut = graph.copy()
    cut.remove_edges_from(
        (edge(PORTS[0], PORTS[1]), edge(PORTS[2], PORTS[3]))
    )
    attachments = root_attachments(graph)
    verify_near_matching(cut, A0, ANCHOR)
    for item in (LEFT, INTERMEDIATE_ONE, INTERMEDIATE_TWO, RIGHT):
        verify_near_matching(cut, EMPTY, item)
    assert all(ROOT in item and FORCED in item for item in (
        ANCHOR,
        LEFT,
        INTERMEDIATE_ONE,
        INTERMEDIATE_TWO,
        RIGHT,
    ))
    assert SURVIVING in ANCHOR
    assert all(
        SURVIVING not in item
        for item in (LEFT, INTERMEDIATE_ONE, INTERMEDIATE_TWO, RIGHT)
    )

    anchor_profile = complement_profile(cut, attachments, ANCHOR)
    left_profile = complement_profile(cut, attachments, LEFT)
    intermediate_one_profile = complement_profile(
        cut, attachments, INTERMEDIATE_ONE
    )
    intermediate_two_profile = complement_profile(
        cut, attachments, INTERMEDIATE_TWO
    )
    right_profile = complement_profile(cut, attachments, RIGHT)
    assert factor_join_passes(anchor_profile, A0, N1_FACTOR_PAIRS)
    assert factor_join_passes(left_profile, EMPTY, N0_FACTOR_PAIRS)
    assert factor_join_passes(right_profile, EMPTY, N0_FACTOR_PAIRS)
    assert not factor_join_passes(
        intermediate_one_profile, EMPTY, N0_FACTOR_PAIRS
    )
    assert not factor_join_passes(
        intermediate_two_profile, EMPTY, N0_FACTOR_PAIRS
    )

    required_atom = ((frozenset((0, 1)),), 0)
    assert all(
        bond_atom(cut, A0, ANCHOR, EMPTY, item) == required_atom
        for item in (LEFT, INTERMEDIATE_ONE, INTERMEDIATE_TWO, RIGHT)
    )
    assert LEFT ^ RIGHT == CYCLE_ONE | CYCLE_TWO
    assert CYCLE_ONE.isdisjoint(CYCLE_TWO)
    for cycle in (CYCLE_ONE, CYCLE_TWO):
        support = nx.edge_subgraph(cut, cycle)
        assert len(cycle) == 4
        assert nx.is_connected(support)
        assert set(dict(support.degree()).values()) == {2}
    assert INTERMEDIATE_ONE == LEFT ^ CYCLE_ONE
    assert INTERMEDIATE_TWO == LEFT ^ CYCLE_TWO

    print("ROOTED_COMPATIBLE_TWO_CYCLE_INTERPOLATION_VERIFIED")


if __name__ == "__main__":
    main()
