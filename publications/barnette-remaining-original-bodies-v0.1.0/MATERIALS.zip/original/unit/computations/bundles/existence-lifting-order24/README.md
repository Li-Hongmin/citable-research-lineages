# Complete-family existence lifting at reduced order 24

This bundle decides the ordinary complete-family C4-lifting statement for
every simple plane cubic bipartite brace of order 24.  It uses the proof-level
neutral-gate lemma of Note 071 to close every family containing a target that
uses at most one gate, then checks the exact local lift rows only for families
forcing both gates.

The accepted census covers 29,579 connected simple cubic bipartite
isomorphism representatives, 18 plane braces, 1,174 legal splits, 34,580
nonempty target interfaces, and 408 complete families forcing both gates.
All 408 forced families contain a liftable target; no complete-family failure
occurs.

The companion pointwise check reconstructs those 408 families.  Their 1,864
targets all occur at face length 4, all have two alternating gate arcs, and
all lift in normalized rows 011, 101, and 110.  Thus no wide forced family
(face length at least 8) occurs at order 24.

## Contents

- `census_complete_family_existence_order24.py` is the streaming complete
  census.  It stops and freezes an explicit family if ordinary existence
  lifting fails.
- `complete_family_existence_order24.json` is the accepted complete-success
  certificate.
- `check_forced_family_pointwise_order24.py` checks every target in every
  forced-two-gate complete family.
- `forced_family_pointwise_order24.json` is its accepted output.

## Reproduction

From the AIMath project root:

    task_run_dir=$(mktemp -d)

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/existence-lifting-order24/census_complete_family_existence_order24.py \
      --output "$task_run_dir/existence-order24.json"

    cmp "$task_run_dir/existence-order24.json" \
      units/barnette/computations/bundles/existence-lifting-order24/complete_family_existence_order24.json

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/existence-lifting-order24/check_forced_family_pointwise_order24.py \
      --output "$task_run_dir/pointwise-order24.json"

    cmp "$task_run_dir/pointwise-order24.json" \
      units/barnette/computations/bundles/existence-lifting-order24/forced_family_pointwise_order24.json

Required markers:

    ORDINARY_EXISTENCE_LIFTING_VERIFIED_AT_REDUCED_ORDER_24
    pointwise_forced_family_lifting_holds_at_order_24

Accepted environment:

- nauty 2.9.3, using `geng -cqb -d3 -D3 24`;
- NetworkX 3.6.1;
- Python 3 via `uv`.

The external coverage interfaces are `geng`'s isomorph-free generation and
NetworkX's planarity decisions.  Cubicity, bipartition, two-edge extension,
strict Hall, embedded duals, complete rooted target families, gate forcing,
and every required local row are checked directly.
