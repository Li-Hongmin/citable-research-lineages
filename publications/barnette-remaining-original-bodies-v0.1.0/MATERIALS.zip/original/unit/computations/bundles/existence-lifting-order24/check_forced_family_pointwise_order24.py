#!/usr/bin/env python3
"""Check every target in every order-24 complete family forcing both gates."""

from __future__ import annotations

from collections import Counter
import argparse
import importlib.util
from itertools import product
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[2]
SOURCE_JSON = HERE / "complete_family_existence_order24.json"
SOURCE_SCRIPT = HERE / "census_complete_family_existence_order24.py"


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


source = load_module(SOURCE_SCRIPT, "order24_pointwise_source")
lift = source.lift_bundle
edge = source.edge


def is_alternating(arc: tuple[int, ...], colour: dict[int, int]) -> bool:
    return all(colour[u] != colour[v] for u, v in zip(arc, arc[1:]))


def check() -> dict[str, object]:
    accepted = json.loads(SOURCE_JSON.read_text())
    assert accepted["status"] == "ordinary_existence_lifting_verified_at_reduced_order_24"
    totals = Counter()
    row_histogram: Counter[str] = Counter()
    family_row_set_histogram: Counter[str] = Counter()
    first_pointwise_failure = None

    for source_graph6 in accepted["brace_graph6"]:
        primal = nx.from_graph6_bytes(source_graph6.encode())
        planar, embedding = nx.check_planarity(primal)
        assert planar and isinstance(embedding, nx.PlanarEmbedding)
        primal_faces = source.source_bundle.plane_faces(primal, embedding)
        reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
        reduced_faces = lift.verify_reduced_triangulation(reduced)
        families, _, _ = lift.target_families(reduced, reduced_faces)
        vertices = tuple(sorted(reduced))
        dual_to_primal = source.primal_edge_by_dual_edge(primal, primal_faces)
        cache = {}
        for root, encoded_family in families.items():
            colours = tuple(
                lift.decode_colouring(vertices, encoded) for encoded in encoded_family
            )
            matchings = tuple(
                source.matching_from_colour(
                    primal, reduced, dual_to_primal, colour
                )
                for colour in colours
            )
            cache[root] = colours, matchings

        for z in sorted(reduced):
            rotation = rotations[z]
            for i, j, first_gate, second_gate in lift.gate_pairs(rotation):
                left_size = j - i + 1
                right_size = len(rotation) - (j - i) + 1
                if left_size % 2 == 0 or right_size % 2 == 0:
                    continue
                expanded, locals_, left_arc, right_arc = lift.split_vertex(
                    reduced, z, rotation, i, j
                )
                expanded_faces = lift.expanded_triangulation_faces(expanded)
                if expanded_faces is None:
                    continue
                gate_edges = (
                    dual_to_primal[edge(z, first_gate)],
                    dual_to_primal[edge(z, second_gate)],
                )
                for root in sorted(families):
                    if z in root:
                        continue
                    colours, matchings = cache[root]
                    if not all(
                        all(gate in matching for gate in gate_edges)
                        for matching in matchings
                    ):
                        continue
                    totals["complete_families_forcing_both_gates"] += 1
                    totals[
                        f"forced_families_at_face_length_{len(rotation)}"
                    ] += 1
                    family_rows = set()
                    for index, colour in enumerate(colours):
                        totals["targets_in_forced_families"] += 1
                        totals[
                            f"forced_family_targets_at_face_length_{len(rotation)}"
                        ] += 1
                        normalized = {
                            vertex: value ^ colour[z]
                            for vertex, value in colour.items()
                        }
                        arc_word = "".join(
                            str(
                                int(
                                    is_alternating(arc, normalized)
                                )
                            )
                            for arc in (left_arc, right_arc)
                        )
                        totals[f"target_arc_{arc_word}"] += 1
                        fixed = {
                            vertex: value
                            for vertex, value in colour.items()
                            if vertex != z
                        }
                        rows = []
                        for bits in product((0, 1), repeat=3):
                            totals["local_assignments"] += 1
                            lifted = {
                                **fixed,
                                **dict(zip(locals_, bits, strict=True)),
                            }
                            profile = lift.rooted_profile(
                                expanded, expanded_faces, lifted, root
                            )
                            if lift.is_target_profile(profile):
                                rows.append(
                                    "".join(str(bit ^ colour[z]) for bit in bits)
                                )
                        key = ",".join(rows) if rows else "NONE"
                        row_histogram[key] += 1
                        family_rows.add(key)
                        if rows:
                            totals["pointwise_liftable_targets"] += 1
                        else:
                            totals["pointwise_failures"] += 1
                            if first_pointwise_failure is None:
                                first_pointwise_failure = {
                                    "source_graph6": source_graph6,
                                    "split_vertex": z,
                                    "rotation": rotation,
                                    "gate_indices": (i, j),
                                    "gate_vertices": (first_gate, second_gate),
                                    "dual_root": root,
                                    "family_index": index,
                                    "zero_vertices": sorted(
                                        vertex
                                        for vertex, value in colour.items()
                                        if value == 0
                                    ),
                                    "one_vertices": sorted(
                                        vertex
                                        for vertex, value in colour.items()
                                        if value == 1
                                    ),
                                    "arc_word": arc_word,
                                }
                    family_row_set_histogram[
                        ";".join(sorted(family_rows))
                    ] += 1

    assert totals["complete_families_forcing_both_gates"] == accepted["coverage"][
        "complete_families_forcing_both_gates"
    ]
    assert totals["targets_in_forced_families"] == accepted["coverage"][
        "targets_in_forced_two_gate_complete_families"
    ]
    assert (
        totals["pointwise_liftable_targets"] + totals["pointwise_failures"]
        == totals["targets_in_forced_families"]
    )
    return {
        "scope": {
            "order": 24,
            "plane_braces": len(accepted["brace_graph6"]),
            "source": str(SOURCE_JSON.relative_to(UNIT)),
            "quantifier": (
                "every target in every nonempty unchanged-root complete "
                "family forcing both split gates"
            ),
        },
        "counts": dict(sorted(totals.items())),
        "successful_row_histogram": dict(sorted(row_histogram.items())),
        "family_row_set_histogram": dict(sorted(family_row_set_histogram.items())),
        "first_pointwise_failure": first_pointwise_failure,
        "status": (
            "pointwise_forced_family_lifting_holds_at_order_24"
            if first_pointwise_failure is None
            else "pointwise_forced_family_lifting_fails_at_order_24"
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    payload = check()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(rendered)
    print(json.dumps(payload["counts"], sort_keys=True))
    print(json.dumps(payload["successful_row_histogram"], sort_keys=True))
    print(payload["status"])


if __name__ == "__main__":
    main()
