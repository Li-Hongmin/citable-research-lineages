# Through-order-26 child shore-rank profiles

This bundle supports
[Note 111](../../../notes/111-parent-bond-split-lift-calculus-and-nondirect-canonical-x-supplementation.md).
It reads only the frozen parents and deterministic children already used by
the Note 110 bundle. It generates no new parent graph and tests no adjacent
order.

Run from the AIMath root:

    PYTHONHASHSEED=0 uv run --python 3.12 --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/through26-child-rank-profiles/classify_child_rank_profiles.py

The classification covers the \(322\) eligible children of Note 110,
reconstructs every rooted crossing, computes the four Note 109 ranks,
classifies the two canonical--cross templates, tests direct ancestry from
every parent state-\(11\) target, and solves the exact finite profile-cover
problem.

Expected terminal marker:

    THROUGH26_CHILD_RANK_PROFILES_CLASSIFIED

Expected SHA-256 of the generated full JSON:

    0cf5c3b10233e87103de2be5b55f8209685e6b758a60d33abb601e2317123e55

The compact promoted record is
[result-summary.json](result-summary.json). The full generated JSON is
through26_child_rank_profiles.json; it contains all \(322\) site records
and all \(487\) profile types.

The promotion environment was Python 3.12 with NetworkX 3.6.1 on
2026-08-28.
