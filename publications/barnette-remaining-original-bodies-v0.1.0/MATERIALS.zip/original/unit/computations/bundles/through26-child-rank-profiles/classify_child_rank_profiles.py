#!/usr/bin/env python3
"""Classify Note 109 shore-rank profiles on the 322 Note 110 children.

No graph is generated beyond the deterministic children already quantified
over by the permanent ``rooted-split-bond-through26`` classifier.  We load
that classifier, replace only its child summariser by an enriched version,
and then retain a compact per-site set of witness profiles.
"""

from __future__ import annotations

from collections import Counter, defaultdict
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
BASE_PATH = (
    BARNETTE
    / "computations"
    / "bundles"
    / "rooted-split-bond-through26"
    / "classify_through26_nonsquare_kill_cover.py"
)

LOCAL_NAMES = ("A", "B", "C", "P", "Q")
REPRESENTATIVES = {
    "C00": (0, 0, 0, 1, 1),
    "C10": (0, 0, 1, 0, 1),
    "C01": (0, 0, 1, 1, 0),
    "C11": (0, 0, 1, 0, 0),
    "R00": (1, 1, 0, 0, 0),
    "Xuy": (1, 0, 1, 0, 0),
    "Xvx": (0, 1, 1, 0, 0),
}
NEW_CELLS = frozenset(("R00", "Xuy", "Xvx"))


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


base = load_module(BASE_PATH, "through26_rank_profile_base")
edge = base.edge


def dual_from_faces(
    graph: nx.Graph, faces: tuple[tuple[int, ...], ...]
) -> tuple[nx.Graph, dict[tuple[int, int], tuple[int, int]]]:
    incidences: dict[tuple[int, int], list[int]] = defaultdict(list)
    for face_index, face in enumerate(faces):
        for index in range(len(face)):
            incidences[edge(face[index], face[(index + 1) % len(face)])].append(
                face_index
            )
    assert set(incidences) == {edge(*item) for item in graph.edges()}
    assert all(len(indices) == 2 for indices in incidences.values())
    edge_faces = {item: tuple(indices) for item, indices in incidences.items()}
    dual = nx.Graph()
    dual.add_nodes_from(range(len(faces)))
    for primal_edge, (left, right) in edge_faces.items():
        assert left != right and not dual.has_edge(left, right)
        dual.add_edge(left, right, primal_edge=primal_edge)
    assert nx.is_connected(dual)
    assert all(dual.degree(index) == len(face) for index, face in enumerate(faces))
    return dual, edge_faces


def colouring_from_matching(
    dual: nx.Graph,
    matching: frozenset[tuple[int, int]],
) -> dict[int, int]:
    colour: dict[int, int] = {}
    for seed in dual:
        if seed in colour:
            continue
        colour[seed] = 0
        stack = [seed]
        while stack:
            current = stack.pop()
            for neighbour, data in dual[current].items():
                parity = int(data["primal_edge"] not in matching)
                value = colour[current] ^ parity
                if neighbour in colour:
                    assert colour[neighbour] == value
                else:
                    colour[neighbour] = value
                    stack.append(neighbour)
    assert len(colour) == dual.number_of_nodes()
    for triangle in nx.enumerate_all_cliques(dual):
        if len(triangle) < 3:
            continue
        if len(triangle) > 3:
            break
        assert len({colour[vertex] for vertex in triangle}) == 2
    return colour


def local_vertices(
    faces: tuple[tuple[int, ...], ...],
    local: tuple[tuple[int, int], ...],
    edge_faces: dict[tuple[int, int], tuple[int, int]],
) -> dict[str, int]:
    ua, ab, bv, xc, cd, dy, ad, bc = local
    # expand_on_face appends first_channel=A, second_channel=B, square=C.
    result = {"A": len(faces) - 3, "B": len(faces) - 2, "C": len(faces) - 1}

    def other(item: tuple[int, int], known: int) -> int:
        pair = edge_faces[item]
        assert known in pair
        return pair[0] if pair[1] == known else pair[1]

    result["P"] = other(bv, result["A"])
    assert other(ua, result["B"]) == result["P"]
    result["Q"] = other(xc, result["A"])
    assert other(dy, result["B"]) == result["Q"]
    expected = {
        ua: frozenset((result["B"], result["P"])),
        bv: frozenset((result["A"], result["P"])),
        ab: frozenset((result["C"], result["P"])),
        xc: frozenset((result["A"], result["Q"])),
        dy: frozenset((result["B"], result["Q"])),
        cd: frozenset((result["C"], result["Q"])),
        ad: frozenset((result["B"], result["C"])),
        bc: frozenset((result["A"], result["C"])),
    }
    assert all(frozenset(edge_faces[item]) == pair for item, pair in expected.items())
    assert len(set(result.values())) == 5
    return result


def normalise_colouring(
    colour: dict[int, int], local_map: dict[str, int], cell: str
) -> dict[int, int]:
    bits = tuple(colour[local_map[name]] for name in LOCAL_NAMES)
    representative = REPRESENTATIVES[cell]
    if bits == representative:
        return colour
    assert tuple(1 - bit for bit in bits) == representative, (
        cell,
        bits,
        representative,
        local_map,
    )
    return {vertex: 1 - bit for vertex, bit in colour.items()}


def restricted_components(
    dual: nx.Graph, vertices: set[int]
) -> tuple[tuple[frozenset[int], ...], dict[int, int]]:
    if not vertices:
        return (), {}
    components = tuple(
        frozenset(component)
        for component in nx.connected_components(dual.subgraph(vertices))
    )
    index = {
        vertex: component_index
        for component_index, component in enumerate(components)
        for vertex in component
    }
    return components, index


def four_ranks(
    dual: nx.Graph, colour: dict[int, int], shore: set[int]
) -> tuple[int, int, int, int]:
    outside = set(dual) - shore
    fragments = {}
    for side_name, side in (("W", shore), ("O", outside)):
        for bit in (0, 1):
            fragments[(side_name, bit)] = restricted_components(
                dual, {vertex for vertex in side if colour[vertex] == bit}
            )

    def rank(a: int, b: int) -> int:
        left_components, left_index = fragments[("W", a)]
        right_components, right_index = fragments[("O", b)]
        count = len(left_components) + len(right_components)
        parent = list(range(count))

        def find(item: int) -> int:
            while parent[item] != item:
                parent[item] = parent[parent[item]]
                item = parent[item]
            return item

        def union(first: int, second: int) -> None:
            first_root, second_root = find(first), find(second)
            if first_root != second_root:
                parent[second_root] = first_root

        for first, second in dual.edges():
            if (first in shore) == (second in shore):
                continue
            inside, out = (first, second) if first in shore else (second, first)
            if colour[inside] == a and colour[out] == b:
                union(left_index[inside], len(left_components) + right_index[out])
        components = len({find(item) for item in range(count)})
        return count - components

    return rank(0, 0), rank(1, 1), rank(1, 0), rank(0, 1)


def root_label_data(
    graph: nx.Graph,
    faces: tuple[tuple[int, ...], ...],
    dual: nx.Graph,
    edge_faces: dict[tuple[int, int], tuple[int, int]],
    root: tuple[int, int],
    after: dict[int, int],
) -> tuple[bool, tuple[int, int]]:
    root_faces = frozenset(edge_faces[root])
    assert len(root_faces) == 2
    left, right = root

    def third_face(vertex: int) -> int:
        incident = {index for index, face in enumerate(faces) if vertex in face}
        assert len(incident) == 3 and root_faces <= incident
        return next(iter(incident - root_faces))

    x_left, x_right = third_face(left), third_face(right)
    root_colour = {after[vertex] for vertex in root_faces}
    assert len(root_colour) == 1
    opposite = 1 - next(iter(root_colour))
    assert after[x_left] == after[x_right] == opposite
    components = tuple(
        nx.connected_components(
            dual.subgraph({vertex for vertex in dual if after[vertex] == opposite})
        )
    )
    component_index = {
        vertex: index
        for index, component in enumerate(components)
        for vertex in component
    }
    separated = component_index[x_left] != component_index[x_right]
    return separated, (x_left, x_right)


def witness_profile(
    graph: nx.Graph,
    faces: tuple[tuple[int, ...], ...],
    dual: nx.Graph,
    edge_faces: dict[tuple[int, int], tuple[int, int]],
    local_map: dict[str, int],
    root: tuple[int, int],
    first: frozenset[tuple[int, int]],
    second: frozenset[tuple[int, int]],
    first_cell: str,
    second_cell: str,
) -> dict[str, object]:
    first_colour = normalise_colouring(
        colouring_from_matching(dual, first), local_map, first_cell
    )
    second_colour = normalise_colouring(
        colouring_from_matching(dual, second), local_map, second_cell
    )
    shore = {
        vertex for vertex in dual if first_colour[vertex] != second_colour[vertex]
    }
    assert shore and shore != set(dual)
    outside = set(dual) - shore
    assert nx.is_connected(dual.subgraph(shore))
    assert nx.is_connected(dual.subgraph(outside))
    cut = {
        edge(first_vertex, second_vertex)
        for first_vertex, second_vertex in dual.edges()
        if (first_vertex in shore) != (second_vertex in shore)
    }
    difference = first ^ second
    assert {
        dual.edges[item]["primal_edge"] for item in cut
    } == set(difference)
    ranks = four_ranks(dual, first_colour, shore)
    assert ranks[0] + ranks[1] == ranks[2] + ranks[3]
    separated_before, _ = root_label_data(
        graph, faces, dual, edge_faces, root, first_colour
    )
    separated, root_fragments = root_label_data(
        graph, faces, dual, edge_faces, root, second_colour
    )
    assert separated_before and separated
    signature = tuple(
        name for name in LOCAL_NAMES if local_map[name] in shore
    )
    return {
        "local_signature": "".join(signature) if signature else "empty",
        "ranks_00_11_10_01": ranks,
        "root_labels_separated": separated,
        "cell_pair": f"{first_cell}->{second_cell}",
        "bond_length": len(difference),
        "shore_size": len(shore),
        "shore_complement_size": len(outside),
        "root_fragments": root_fragments,
    }


SITE_PROFILES: list[tuple[dict[str, object], ...]] = []
SITE_DIRECT_STATS: list[dict[str, object]] = []
PARENT_FIBRE_CACHE: dict[
    tuple[bytes, tuple[int, int], tuple[int, int]],
    tuple[frozenset[tuple[int, int]], ...],
] = {}


def parent_fibre(
    graph: nx.Graph,
    root: tuple[int, int],
    forced_gate: tuple[int, int],
) -> tuple[frozenset[tuple[int, int]], ...]:
    graph6 = nx.to_graph6_bytes(graph, header=False).strip()
    key = (graph6, root, forced_gate)
    if key not in PARENT_FIBRE_CACHE:
        PARENT_FIBRE_CACHE[key] = tuple(
            matching
            for matching in base.enumerate_perfect_matchings(graph)
            if base.is_root_target(graph, matching, root, forced_gate)
        )
    return PARENT_FIBRE_CACHE[key]


def face_arc_edges(
    face: tuple[int, ...], first_index: int, second_index: int
) -> tuple[
    frozenset[tuple[int, int]], frozenset[tuple[int, int]]
]:
    assert 0 <= first_index < second_index < len(face)
    first_arc = frozenset(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(first_index + 1, second_index)
    )
    second_indices = tuple(range(second_index + 1, len(face))) + tuple(
        range(first_index)
    )
    second_arc = frozenset(
        edge(face[index], face[(index + 1) % len(face)])
        for index in second_indices
    )
    return first_arc, second_arc


def classify_child_enriched(
    graph: nx.Graph,
    faces: tuple[tuple[int, ...], ...],
    site: dict[str, object],
    root: tuple[int, int],
    forced_gate: tuple[int, int],
    surviving_gate: tuple[int, int],
) -> dict[str, object]:
    child, child_faces, local = base.expand_on_face(graph, faces, site)
    matchings = base.enumerate_perfect_matchings(child)
    fibre = tuple(
        matching
        for matching in matchings
        if base.is_root_target(child, matching, root, forced_gate)
    )
    sectors = (
        tuple(matching for matching in fibre if surviving_gate not in matching),
        tuple(matching for matching in fibre if surviving_gate in matching),
    )
    cells = {matching: base.local_cell(matching, local) for matching in fibre}
    assert all(cell != "C11" for cell in cells.values())
    crossings = tuple(
        (first, second)
        for first in sectors[0]
        for second in sectors[1]
        if base.difference_component_count(first, second) == 1
    )
    new_cell_crossings = tuple(
        pair
        for pair in crossings
        if cells[pair[0]] in NEW_CELLS or cells[pair[1]] in NEW_CELLS
    )
    assert len(new_cell_crossings) == len(crossings)

    dual, edge_faces = dual_from_faces(child, child_faces)
    local_map = local_vertices(child_faces, local, edge_faces)
    profiles = tuple(
        witness_profile(
            child,
            child_faces,
            dual,
            edge_faces,
            local_map,
            root,
            first,
            second,
            cells[first],
            cells[second],
        )
        for first, second in new_cell_crossings
    )
    SITE_PROFILES.append(profiles)

    face_index = int(site["face_index"])
    first_index, second_index = map(int, site["indices"])
    parent_face = faces[face_index]
    selected = tuple(site["selected"])
    first_arc, second_arc = face_arc_edges(
        parent_face, first_index, second_index
    )
    ua, ab, bv, xc, cd, dy, ad, bc = local
    l11 = tuple(
        matching
        for matching in parent_fibre(graph, root, forced_gate)
        if selected[0] in matching and selected[1] in matching
    )
    assert l11
    direct_x_targets = {"Xuy": set(), "Xvx": set()}
    fibre_set = frozenset(fibre)
    matching_set = frozenset(matchings)
    crossing_incidence = Counter(
        matching for pair in new_cell_crossings for matching in pair
    )
    direct_formula_records = []
    for parent_index, parent in enumerate(sorted(l11, key=lambda item: sorted(item))):
        common = parent - frozenset(selected)
        candidates = {
            "R00": (common ^ first_arc ^ second_arc) | frozenset((ab, cd)),
            "Xuy": (common ^ first_arc) | frozenset((ua, bc, dy)),
            "Xvx": (common ^ second_arc) | frozenset((ad, bv, xc)),
        }
        for cell, candidate in candidates.items():
            perfect = candidate in matching_set
            target = candidate in fibre_set
            if candidate in fibre_set:
                assert cells[candidate] == cell
                if cell in direct_x_targets:
                    direct_x_targets[cell].add(candidate)
            if len(new_cell_crossings) == 2:
                direct_formula_records.append(
                    {
                        "parent_L11_index": parent_index,
                        "parent_sector": int(surviving_gate in parent),
                        "cell": cell,
                        "perfect_matching": perfect,
                        "target": target,
                        "child_sector": (
                            int(surviving_gate in candidate) if perfect else None
                        ),
                        "crossing_incidence": crossing_incidence[candidate],
                    }
                )

    canonical_cells = {"C00", "C10", "C01"}
    cross_cells = {"Xuy", "Xvx"}
    canonical_x = []
    for first, second in new_cell_crossings:
        first_cell, second_cell = cells[first], cells[second]
        if first_cell in canonical_cells and second_cell in cross_cells:
            cross_matching, cross_cell = second, second_cell
        elif second_cell in canonical_cells and first_cell in cross_cells:
            cross_matching, cross_cell = first, first_cell
        else:
            continue
        canonical_x.append(
            (cross_matching, cross_cell, cross_matching in direct_x_targets[cross_cell])
        )
    SITE_DIRECT_STATS.append(
        {
            "parent_L11": len(l11),
            "direct_Xuy_targets": len(direct_x_targets["Xuy"]),
            "direct_Xvx_targets": len(direct_x_targets["Xvx"]),
            "canonical_X_witnesses": len(canonical_x),
            "canonical_X_direct_witnesses": sum(item[2] for item in canonical_x),
            "canonical_X_has_direct_witness": any(item[2] for item in canonical_x),
            "direct_formula_records_if_two_witness_site": direct_formula_records,
        }
    )

    arcs = base.legal_wide_arcs(child_faces, root, forced_gate, surviving_gate)
    three_connected = nx.node_connectivity(child) >= 3
    brace = bool(three_connected and base.source.is_two_extendable_direct(child))
    if brace:
        assert base.source.strict_hall_two_extendable(child)
    return {
        "child_order": child.number_of_nodes(),
        "child_perfect_matchings": len(matchings),
        "child_three_connected": three_connected,
        "child_brace": brace,
        "child_legal_wide_arcs": arcs,
        "child_legal_wide_brace": bool(brace and arcs is not None),
        "child_fibre_size": len(fibre),
        "child_sector_sizes": tuple(map(len, sectors)),
        "child_cell_histogram": dict(sorted(Counter(cells.values()).items())),
        "child_crossings": len(crossings),
        "child_crossing_nonempty": bool(crossings),
        "new_cell_crossings": len(new_cell_crossings),
        "canonical_crossings": 0,
    }


def profile_key(record: dict[str, object]) -> tuple[object, ...]:
    return (
        record["local_signature"],
        tuple(record["ranks_00_11_10_01"]),
        record["root_labels_separated"],
        record["cell_pair"],
        record["bond_length"],
    )


def serial_profile(key: tuple[object, ...]) -> dict[str, object]:
    signature, ranks, separated, cell_pair, bond_length = key
    return {
        "local_signature": signature,
        "ranks_00_11_10_01": list(ranks),
        "root_labels_separated": separated,
        "cell_pair": cell_pair,
        "bond_length": bond_length,
    }


def template_class(record: dict[str, object]) -> str | None:
    """Return the canonical--cross coarse template of a witness, if any."""

    first, second = str(record["cell_pair"]).split("->")
    pair = frozenset((first, second))
    signature = record["local_signature"]
    if (
        len(pair & {"C10", "C01"}) == 1
        and len(pair & {"Xuy", "Xvx"}) == 1
        and signature in {"AP", "AQ", "BP", "BQ"}
    ):
        return "I"
    if (
        "C00" in pair
        and len(pair & {"Xuy", "Xvx"}) == 1
        and signature in {"ACPQ", "BCPQ"}
    ):
        return "II"
    return None


def exact_minimum_profile_cover(
    site_sets: tuple[frozenset[tuple[object, ...]], ...]
) -> tuple[tuple[object, ...], ...]:
    universe = (1 << len(site_sets)) - 1
    coverage: dict[tuple[object, ...], int] = defaultdict(int)
    for site_index, keys in enumerate(site_sets):
        for key in keys:
            coverage[key] |= 1 << site_index

    # Discard profiles weakly dominated by another profile.  This preserves
    # the minimum cardinality and chooses the lexicographically first survivor
    # only after the cardinality has been proved.
    ordered = sorted(coverage, key=str)
    useful = []
    for key in ordered:
        mask = coverage[key]
        if any(mask != coverage[other] and mask | coverage[other] == coverage[other] for other in ordered):
            continue
        useful.append(key)
    coverage = {key: coverage[key] for key in useful}

    greedy = []
    covered = 0
    while covered != universe:
        key = max(coverage, key=lambda item: ((coverage[item] & ~covered).bit_count(), str(item)))
        assert coverage[key] & ~covered
        greedy.append(key)
        covered |= coverage[key]
    best = tuple(greedy)

    site_options = []
    for site_index in range(len(site_sets)):
        options = tuple(key for key, mask in coverage.items() if mask & (1 << site_index))
        assert options
        site_options.append(options)

    def search(covered_mask: int, chosen: tuple[tuple[object, ...], ...]) -> None:
        nonlocal best
        if covered_mask == universe:
            if len(chosen) < len(best) or (
                len(chosen) == len(best) and tuple(map(str, chosen)) < tuple(map(str, best))
            ):
                best = chosen
            return
        if len(chosen) >= len(best):
            return
        uncovered_indices = [
            index for index in range(len(site_sets)) if not covered_mask & (1 << index)
        ]
        pivot = min(
            uncovered_indices,
            key=lambda index: sum(
                1 for key in site_options[index] if coverage[key] & ~covered_mask
            ),
        )
        candidates = sorted(
            site_options[pivot],
            key=lambda key: (-(coverage[key] & ~covered_mask).bit_count(), str(key)),
        )
        for key in candidates:
            if key in chosen:
                continue
            search(covered_mask | coverage[key], chosen + (key,))

    search(0, ())
    assert sum((coverage[key] for key in best), 0) or best
    union = 0
    for key in best:
        union |= coverage[key]
    assert union == universe
    return best


def classify_profiles() -> dict[str, object]:
    SITE_PROFILES.clear()
    SITE_DIRECT_STATS.clear()
    PARENT_FIBRE_CACHE.clear()
    original = base.classify_child
    base.classify_child = classify_child_enriched
    try:
        payload = base.classify()
    finally:
        base.classify_child = original
    assert payload["status"] == "ALL_ELIGIBLE_NONSQUARE_KILL_COVER_HITS_POSITIVE"
    assert len(payload["hits"]) == len(SITE_PROFILES) == len(SITE_DIRECT_STATS) == 323

    eligible_indices = tuple(
        index
        for index, hit in enumerate(payload["hits"])
        if hit["child_legal_wide_brace"] and hit["child_crossing_nonempty"]
    )
    assert len(eligible_indices) == 322
    site_sets = tuple(
        frozenset(profile_key(record) for record in SITE_PROFILES[index])
        for index in eligible_indices
    )
    assert all(site_sets)
    common = set.intersection(*(set(keys) for keys in site_sets))
    minimum_cover = exact_minimum_profile_cover(site_sets)

    profile_occurrences: Counter[tuple[object, ...]] = Counter()
    profile_sites: Counter[tuple[object, ...]] = Counter()
    marginal_counts = {
        "local_signature": Counter(),
        "ranks_00_11_10_01": Counter(),
        "cell_pair": Counter(),
        "bond_length": Counter(),
    }
    site_summaries = []
    for eligible_position, hit_index in enumerate(eligible_indices):
        profiles = SITE_PROFILES[hit_index]
        keys = site_sets[eligible_position]
        profile_occurrences.update(profile_key(record) for record in profiles)
        profile_sites.update(keys)
        for field in marginal_counts:
            values = {
                tuple(record[field]) if isinstance(record[field], tuple) else record[field]
                for record in profiles
            }
            marginal_counts[field].update(values)
        site_summaries.append(
            {
                "hit_index": hit_index,
                "parent_order": payload["hits"][hit_index]["parent_order"],
                "child_order": payload["hits"][hit_index]["child_order"],
                "source_graph6": payload["hits"][hit_index]["source_graph6"],
                "root": payload["hits"][hit_index]["root"],
                "forced_gate": payload["hits"][hit_index]["forced_gate"],
                "surviving_gate": payload["hits"][hit_index]["surviving_gate"],
                "site": payload["hits"][hit_index]["site"],
                "witnesses": len(profiles),
                "direct_ancestry": SITE_DIRECT_STATS[hit_index],
                "distinct_profiles": [serial_profile(key) for key in sorted(keys, key=str)],
            }
        )

    all_keys = sorted(profile_sites, key=str)
    template_i_sites = []
    template_ii_sites = []
    for eligible_position, hit_index in enumerate(eligible_indices):
        classes = {
            template_class(record) for record in SITE_PROFILES[hit_index]
        }
        if "I" in classes:
            template_i_sites.append(eligible_position)
        if "II" in classes:
            template_ii_sites.append(eligible_position)
    assert len(template_i_sites) == 319
    assert len(template_ii_sites) == 139
    assert set(template_i_sites) | set(template_ii_sites) == set(range(322))
    i_failures = sorted(set(range(322)) - set(template_i_sites))
    assert i_failures == [278, 279, 280]
    rigid_sites = [
        index for index, summary in enumerate(site_summaries)
        if summary["witnesses"] == 2
    ]
    assert rigid_sites == [277, 279]
    assert len(site_summaries[279]["distinct_profiles"]) == 1
    eligible_direct = tuple(SITE_DIRECT_STATS[index] for index in eligible_indices)
    assert all(record["canonical_X_witnesses"] for record in eligible_direct)
    all_nondirect_sites = [
        index
        for index, record in enumerate(eligible_direct)
        if not record["canonical_X_has_direct_witness"]
    ]
    direct_sites = len(eligible_direct) - len(all_nondirect_sites)
    return {
        "status": (
            "UNIVERSAL_CHILD_RANK_PROFILE"
            if common
            else "NO_UNIVERSAL_PROFILE_EXACT_MINIMUM_COVER"
        ),
        "scope": {
            "input": "the 322 eligible positive children of permanent Note 110",
            "no_new_parent": True,
            "profile_fields": (
                "canonical local shore signature, ordered four ranks, root-label "
                "separation, ordered sector cell pair, bond length"
            ),
        },
        "counts": {
            "eligible_sites": len(site_sets),
            "crossing_witnesses": sum(len(SITE_PROFILES[index]) for index in eligible_indices),
            "distinct_profiles": len(all_keys),
            "universal_profiles": len(common),
            "minimum_profile_cover_size": len(minimum_cover),
        },
        "universal_profiles": [serial_profile(key) for key in sorted(common, key=str)],
        "minimum_profile_cover": [serial_profile(key) for key in minimum_cover],
        "coarse_two_template_cover": {
            "template_I": {
                "description": (
                    "C10/C01 versus Xuy/Xvx, with local shore signature "
                    "AP/AQ/BP/BQ"
                ),
                "sites": len(template_i_sites),
            },
            "template_II": {
                "description": (
                    "C00 versus Xuy/Xvx, with local shore signature ACPQ/BCPQ"
                ),
                "sites": len(template_ii_sites),
            },
            "union_sites": len(set(template_i_sites) | set(template_ii_sites)),
            "template_I_failure_site_indices": i_failures,
            "two_witness_site_indices": rigid_sites,
            "most_rigid_site_index": 279,
        },
        "direct_parent_L11_ancestry": {
            "sites_with_direct_canonical_X_witness": direct_sites,
            "sites_with_only_nondirect_canonical_X_witnesses": len(all_nondirect_sites),
            "first_all_nondirect_site_index": (
                all_nondirect_sites[0] if all_nondirect_sites else None
            ),
            "all_nondirect_site_indices": all_nondirect_sites,
            "canonical_X_witnesses": sum(
                int(record["canonical_X_witnesses"])
                for record in eligible_direct
            ),
            "canonical_X_direct_witnesses": sum(
                int(record["canonical_X_direct_witnesses"])
                for record in eligible_direct
            ),
            "direct_Xuy_targets": sum(
                int(record["direct_Xuy_targets"])
                for record in eligible_direct
            ),
            "direct_Xvx_targets": sum(
                int(record["direct_Xvx_targets"])
                for record in eligible_direct
            ),
        },
        "profile_table": [
            {
                **serial_profile(key),
                "sites": profile_sites[key],
                "occurrences": profile_occurrences[key],
            }
            for key in all_keys
        ],
        "marginal_site_counts": {
            field: {str(key): value for key, value in sorted(counter.items(), key=lambda item: str(item[0]))}
            for field, counter in marginal_counts.items()
        },
        "sites": site_summaries,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=HERE / "through26_child_rank_profiles.json")
    arguments = parser.parse_args()
    payload = classify_profiles()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    arguments.output.write_text(rendered)
    print(json.dumps(payload["counts"], sort_keys=True))
    print("status", payload["status"])
    print("json_sha256", hashlib.sha256(rendered.encode()).hexdigest())
    print("THROUGH26_CHILD_RANK_PROFILES_CLASSIFIED")


if __name__ == "__main__":
    main()
