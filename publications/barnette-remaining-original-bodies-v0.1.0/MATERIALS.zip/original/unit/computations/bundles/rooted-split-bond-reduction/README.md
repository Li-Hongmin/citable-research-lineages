# Rooted split-bond reduction

This bundle supports
[Note 108](../../../notes/108-kill-cover-supplementation-is-exactly-a-rooted-split-bond-lemma.md).

Run from the AIMath root:

```bash
python3 \
  units/barnette/computations/bundles/rooted-split-bond-reduction/verify_local_split_nae_table.py
```

The script enumerates all binary colourings of the five local dual vertices,
imposes the four nonmonochromatic triangle constraints, quotients by global
colour reversal, and recovers exactly the seven patch cells of Note 103.
The bond-flip equivalence and the rooted-family restriction are proved
analytically in Note 108 and are not inferred from this local enumeration.

Expected final marker:

```text
ROOTED_SPLIT_BOND_LOCAL_TABLE_VERIFIED
```

The promotion environment was Python 3.12 on 2026-08-28.
