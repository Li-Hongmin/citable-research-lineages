#!/usr/bin/env python3
"""Verify the seven local NAE classes in the dual C4 split."""

from __future__ import annotations

from itertools import product


VERTICES = ("A", "B", "C", "P", "Q")
TRIANGLES = (("A", "C", "P"), ("B", "C", "P"), ("A", "C", "Q"), ("B", "C", "Q"))
EDGES = (("A", "P"), ("B", "P"), ("C", "P"), ("A", "Q"), ("B", "Q"), ("C", "Q"), ("A", "C"), ("B", "C"))

EXPECTED = {
    "C00": frozenset(("AC", "BC")),
    "C10": frozenset(("AP", "BP", "CQ")),
    "C01": frozenset(("AQ", "BQ", "CP")),
    "C11": frozenset(("AP", "BP", "AQ", "BQ")),
    "R00": frozenset(("CP", "CQ")),
    "Xuy": frozenset(("BP", "AC", "BQ")),
    "Xvx": frozenset(("BC", "AP", "AQ")),
}

DISPLAYED_REPRESENTATIVES = {
    "C00": (0, 0, 0, 1, 1),
    "C10": (0, 0, 1, 0, 1),
    "C01": (0, 0, 1, 1, 0),
    "C11": (0, 0, 1, 0, 0),
    "R00": (1, 1, 0, 0, 0),
    "Xuy": (1, 0, 1, 0, 0),
    "Xvx": (0, 1, 1, 0, 0),
}


def nae(bits, triangle):
    values = {bits[VERTICES.index(vertex)] for vertex in triangle}
    return len(values) == 2


def monochromatic_edges(bits):
    values = dict(zip(VERTICES, bits))
    return frozenset(
        "".join((left, right))
        for left, right in EDGES
        if values[left] == values[right]
    )


def complement(bits):
    return tuple(1 - bit for bit in bits)


def main():
    admissible = tuple(
        bits
        for bits in product((0, 1), repeat=len(VERTICES))
        if all(nae(bits, triangle) for triangle in TRIANGLES)
    )
    assert len(admissible) == 14
    orbits = {
        min(bits, complement(bits)): monochromatic_edges(bits) for bits in admissible
    }
    assert len(orbits) == 7
    assert frozenset(orbits.values()) == frozenset(EXPECTED.values())

    for cell, bits in DISPLAYED_REPRESENTATIVES.items():
        assert bits in admissible
        assert monochromatic_edges(bits) == EXPECTED[cell]

    # Parent state 11 means both selected dual edges are monochromatic:
    # z=P=Q.  Its canonical local class is C11.
    c11 = DISPLAYED_REPRESENTATIVES["C11"]
    values = dict(zip(VERTICES, c11))
    assert values["A"] == values["B"] == values["P"] == values["Q"]
    assert values["C"] != values["A"]

    print("NAE assignments/orbits 14 7")
    print("cells C00 C10 C01 C11 R00 Xuy Xvx")
    print("ROOTED_SPLIT_BOND_LOCAL_TABLE_VERIFIED")


if __name__ == "__main__":
    main()
