#!/usr/bin/env python3
"""Test gate-component multi-cycle toggles in the 32 Note 080 braces.

The graph class is reconstructed exactly as in the permanent Note 080
bundle.  For every double-gate rooted target M, gate g, and perfect matching
N containing the fixed root but excluding g, the script tests every union of
components of M symmetric-difference N which contains the component through
g.  It also tests the lexicographic restriction requested in the pulse:
first minimise the number of alternating components, then the number of
components of G-N.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[4]
REPAIR_PATH = (
    PROJECT
    / "units/barnette/computations/bundles/minimum-two-c4-brace-repairs"
    / "verify_minimum_two_c4_brace_repairs.py"
)


def load_repair_bundle():
    specification = importlib.util.spec_from_file_location(
        "gate_component_repair_bundle", REPAIR_PATH
    )
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


repair = load_repair_bundle()
base = repair.base
Edge = tuple[int, int]
Matching = frozenset[Edge]


def matching_key(matching: Matching) -> list[list[int]]:
    return [list(item) for item in sorted(matching)]


def operation_key(operation: dict[str, object]) -> dict[str, object]:
    return {
        "ends": list(operation["ends"]),
        "removed": [list(item) for item in operation["removed"]],
        "new": list(operation["new"]),
    }


def graph_edges(graph: nx.Graph) -> frozenset[Edge]:
    return frozenset(base.edge(*item) for item in graph.edges())


def complement_partition(
    graph: nx.Graph, matching: Matching
) -> tuple[frozenset[int], ...]:
    return tuple(
        sorted(
            (
                frozenset(component)
                for component in nx.connected_components(
                    graph.edge_subgraph(graph_edges(graph) - matching)
                )
            ),
            key=lambda component: tuple(sorted(component)),
        )
    )


def target_status(
    graph: nx.Graph, matching: Matching
) -> tuple[bool, tuple[frozenset[int], ...], bool]:
    components = complement_partition(graph, matching)
    root_separated = not any(
        base.ROOT[0] in component and base.ROOT[1] in component
        for component in components
    )
    return (
        base.ROOT in matching and len(components) == 2 and root_separated,
        components,
        root_separated,
    )


def alternating_components(first: Matching, second: Matching) -> tuple[Matching, ...]:
    difference = first ^ second
    assert difference
    auxiliary = nx.Graph()
    auxiliary.add_edges_from(difference)
    assert set(dict(auxiliary.degree()).values()) == {2}
    components = []
    for vertices in nx.connected_components(auxiliary):
        component = frozenset(
            edge for edge in difference if set(edge) <= set(vertices)
        )
        components.append(component)
    return tuple(sorted(components, key=lambda item: tuple(sorted(item))))


def subset_outcomes(
    graph: nx.Graph,
    source: Matching,
    components: tuple[Matching, ...],
    gate: Edge,
) -> tuple[dict[str, object], ...]:
    gate_index = next(
        index for index, component in enumerate(components) if gate in component
    )
    optional = tuple(
        index for index in range(len(components)) if index != gate_index
    )
    outcomes = []
    for size in range(len(optional) + 1):
        for chosen_optional in combinations(optional, size):
            chosen = tuple(sorted((gate_index, *chosen_optional)))
            toggle = frozenset(
                edge for index in chosen for edge in components[index]
            )
            result = source ^ toggle
            is_target, complement, root_separated = target_status(graph, result)
            outcomes.append(
                {
                    "chosen_component_indices": list(chosen),
                    "result": result,
                    "target": is_target,
                    "complement": complement,
                    "root_separated": root_separated,
                }
            )
    return tuple(outcomes)


def outcome_key(outcome: dict[str, object]) -> dict[str, object]:
    complement = outcome["complement"]
    assert isinstance(complement, tuple)
    result = outcome["result"]
    assert isinstance(result, frozenset)
    return {
        "chosen_component_indices": outcome["chosen_component_indices"],
        "result": matching_key(result),
        "target": outcome["target"],
        "complement_component_count": len(complement),
        "complement_components": [sorted(component) for component in complement],
        "root_separated": outcome["root_separated"],
    }


def main() -> None:
    original = nx.from_graph6_bytes(base.GRAPH6.encode())
    first_records = []
    for first_move_index, (face, first_index, second_index) in enumerate(
        repair.admissible_moves(original)
    ):
        first_child, first_operation = repair.c4_expand(
            original, face, first_index, second_index
        )
        first_matchings = base.enumerate_perfect_matchings(first_child)
        first_records.append(
            (
                first_move_index,
                first_child,
                first_operation,
                len(repair.nonextendible_pairs(first_child, first_matchings)),
            )
        )

    totals = Counter()
    candidate_profiles = Counter()
    failure_profiles = Counter()
    lex_failure_profiles = Counter()
    family_profiles = Counter()
    counterexamples: list[dict[str, object]] = []
    lex_counterexamples: list[dict[str, object]] = []
    sequence_index = 0
    brace_index = 0

    for (
        first_move_index,
        first_child,
        first_operation,
        first_bad_count,
    ) in first_records:
        for second_move_index, (face, first_index, second_index) in enumerate(
            repair.admissible_moves(first_child)
        ):
            sequence_index += 1
            repaired, second_operation = repair.c4_expand(
                first_child, face, first_index, second_index
            )
            matchings = tuple(
                sorted(
                    base.enumerate_perfect_matchings(repaired),
                    key=lambda matching: tuple(sorted(matching)),
                )
            )
            if repair.nonextendible_pairs(repaired, matchings):
                continue
            brace_index += 1
            assert first_bad_count == 3
            family = tuple(
                sorted(
                    base.target_family(repaired, matchings),
                    key=lambda matching: tuple(sorted(matching)),
                )
            )
            double_targets = tuple(
                matching
                for matching in family
                if all(gate in matching for gate in base.GATES)
            )
            root_matchings = tuple(
                matching for matching in matchings if base.ROOT in matching
            )
            zero_targets = tuple(
                matching
                for matching in family
                if all(gate not in matching for gate in base.GATES)
            )
            assert zero_targets
            totals["brace_sequences"] += 1
            totals["perfect_matchings"] += len(matchings)
            totals["root_matchings"] += len(root_matchings)
            totals["targets"] += len(family)
            totals["double_targets"] += len(double_targets)

            local_candidates = 0
            local_failures = 0
            local_lex_failures = 0
            for source_index, source in enumerate(double_targets):
                for gate_index, gate in enumerate(base.GATES):
                    totals["source_gate_pairs"] += 1
                    candidates = tuple(
                        candidate
                        for candidate in root_matchings
                        if gate not in candidate
                    )
                    assert candidates
                    records = []
                    for candidate_index, candidate in enumerate(candidates):
                        components = alternating_components(source, candidate)
                        outcomes = subset_outcomes(
                            repaired, source, components, gate
                        )
                        succeeds = any(
                            bool(outcome["target"]) for outcome in outcomes
                        )
                        complement_count = len(
                            complement_partition(repaired, candidate)
                        )
                        record = {
                            "candidate_index": candidate_index,
                            "candidate": candidate,
                            "components": components,
                            "outcomes": outcomes,
                            "succeeds": succeeds,
                            "lex_key": (len(components), complement_count),
                        }
                        records.append(record)
                        local_candidates += 1
                        totals["candidate_triples"] += 1
                        totals[
                            "successful_candidate_triples"
                            if succeeds
                            else "failed_candidate_triples"
                        ] += 1
                        candidate_profiles[
                            (len(components), complement_count, succeeds)
                        ] += 1
                        if not succeeds:
                            local_failures += 1
                            failure_profiles[
                                (
                                    len(family),
                                    len(matchings),
                                    len(components),
                                    complement_count,
                                    len(outcomes),
                                )
                            ] += 1
                            certificate = {
                                "sequence_index": sequence_index,
                                "brace_index": brace_index,
                                "family_size": len(family),
                                "perfect_matching_count": len(matchings),
                                "first_move_index": first_move_index,
                                "second_move_index": second_move_index,
                                "first_operation": operation_key(first_operation),
                                "second_operation": operation_key(second_operation),
                                "graph6": nx.to_graph6_bytes(
                                    repaired, header=False
                                ).decode().strip(),
                                "source_index_within_double_targets": source_index,
                                "gate_index": gate_index,
                                "gate": list(gate),
                                "source": matching_key(source),
                                "candidate": matching_key(candidate),
                                "alternating_components": [
                                    matching_key(component)
                                    for component in components
                                ],
                                "outcomes": [
                                    outcome_key(outcome) for outcome in outcomes
                                ],
                            }
                            counterexamples.append(certificate)

                    minimum_key = min(record["lex_key"] for record in records)
                    lex_records = tuple(
                        record
                        for record in records
                        if record["lex_key"] == minimum_key
                    )
                    totals["lex_minimizer_triples"] += len(lex_records)
                    for record in lex_records:
                        succeeds = bool(record["succeeds"])
                        totals[
                            "successful_lex_minimizers"
                            if succeeds
                            else "failed_lex_minimizers"
                        ] += 1
                        if succeeds:
                            continue
                        local_lex_failures += 1
                        components = record["components"]
                        outcomes = record["outcomes"]
                        candidate = record["candidate"]
                        assert isinstance(components, tuple)
                        assert isinstance(outcomes, tuple)
                        assert isinstance(candidate, frozenset)
                        lex_failure_profiles[
                            (len(family), len(matchings), *minimum_key)
                        ] += 1
                        lex_counterexamples.append(
                            {
                                "sequence_index": sequence_index,
                                "brace_index": brace_index,
                                "family_size": len(family),
                                "perfect_matching_count": len(matchings),
                                "first_move_index": first_move_index,
                                "second_move_index": second_move_index,
                                "first_operation": operation_key(first_operation),
                                "second_operation": operation_key(second_operation),
                                "graph6": nx.to_graph6_bytes(
                                    repaired, header=False
                                ).decode().strip(),
                                "source_index_within_double_targets": source_index,
                                "gate_index": gate_index,
                                "gate": list(gate),
                                "lex_key": list(minimum_key),
                                "number_of_tied_lex_minimizers": len(lex_records),
                                "source": matching_key(source),
                                "candidate": matching_key(candidate),
                                "alternating_components": [
                                    matching_key(component)
                                    for component in components
                                ],
                                "outcomes": [
                                    outcome_key(outcome) for outcome in outcomes
                                ],
                            }
                        )

                    # The existential weakening is equivalent to the existence
                    # of a target excluding g.  Check both directions directly.
                    existential_by_toggle = any(
                        bool(record["succeeds"]) for record in records
                    )
                    existential_by_family = any(
                        gate not in target for target in family
                    )
                    assert existential_by_toggle == existential_by_family
                    assert existential_by_toggle

            family_profiles[
                (
                    len(family),
                    len(matchings),
                    len(double_targets),
                    local_candidates,
                    local_failures,
                    local_lex_failures,
                )
            ] += 1

    assert sequence_index == 868
    assert totals["brace_sequences"] == 32
    assert totals["targets"] == 612
    assert totals["double_targets"] == 180
    assert totals["source_gate_pairs"] == 360
    assert totals["candidate_triples"] == (
        totals["successful_candidate_triples"]
        + totals["failed_candidate_triples"]
    )
    assert totals["lex_minimizer_triples"] == (
        totals["successful_lex_minimizers"]
        + totals["failed_lex_minimizers"]
    )
    assert counterexamples and lex_counterexamples

    counterexamples.sort(
        key=lambda item: (
            item["family_size"], item["sequence_index"],
            item["source_index_within_double_targets"], item["gate_index"],
        )
    )
    lex_counterexamples.sort(
        key=lambda item: (
            item["family_size"], item["sequence_index"],
            item["source_index_within_double_targets"], item["gate_index"],
        )
    )
    report = {
        "scope": dict(totals),
        "candidate_profile_fields": [
            "alternating_component_count",
            "complement_component_count_of_N",
            "has_target_toggle_containing_gate_component",
        ],
        "candidate_profiles": [
            {"profile": list(profile), "count": count}
            for profile, count in sorted(candidate_profiles.items())
        ],
        "failure_profile_fields": [
            "family_size", "perfect_matching_count",
            "alternating_component_count", "complement_component_count_of_N",
            "number_of_tested_subsets",
        ],
        "failure_profiles": [
            {"profile": list(profile), "count": count}
            for profile, count in sorted(failure_profiles.items())
        ],
        "lex_failure_profile_fields": [
            "family_size", "perfect_matching_count",
            "alternating_component_count", "complement_component_count_of_N",
        ],
        "lex_failure_profiles": [
            {"profile": list(profile), "count": count}
            for profile, count in sorted(lex_failure_profiles.items())
        ],
        "family_profile_fields": [
            "family_size", "perfect_matching_count", "double_target_count",
            "candidate_triple_count", "failed_candidate_triple_count",
            "failed_lex_minimizer_count",
        ],
        "family_profiles": [
            {"profile": list(profile), "count": count}
            for profile, count in sorted(family_profiles.items())
        ],
        "minimum_counterexample": counterexamples[0],
        "minimum_lex_counterexample": lex_counterexamples[0],
    }
    output_path = HERE / "gate_component_target_toggle_classification.json"
    output_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")

    print("GATE_COMPONENT_TARGET_TOGGLES_CLASSIFIED")
    print(
        f"sequences={sequence_index} braces={totals['brace_sequences']} "
        f"targets={totals['targets']} double_targets={totals['double_targets']}"
    )
    print(
        f"candidate_triples={totals['candidate_triples']} "
        f"success={totals['successful_candidate_triples']} "
        f"failure={totals['failed_candidate_triples']}"
    )
    print(
        f"lex_minimizers={totals['lex_minimizer_triples']} "
        f"lex_success={totals['successful_lex_minimizers']} "
        f"lex_failure={totals['failed_lex_minimizers']}"
    )
    print(
        "minimum_counterexample="
        f"family{counterexamples[0]['family_size']}/"
        f"sequence{counterexamples[0]['sequence_index']}"
    )
    print(
        "minimum_lex_counterexample="
        f"family{lex_counterexamples[0]['family_size']}/"
        f"sequence{lex_counterexamples[0]['sequence_index']}"
    )
    print(f"report={output_path}")


if __name__ == "__main__":
    main()
