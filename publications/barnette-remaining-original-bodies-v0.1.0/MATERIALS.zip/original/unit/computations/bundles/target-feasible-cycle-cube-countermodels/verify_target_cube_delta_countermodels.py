#!/usr/bin/env python3
"""Frozen checks for the Note 082 endpoint and lexicographic countermodels."""

from itertools import combinations


def edge(a, b):
    return frozenset((a, b))


def components(vertices, edges):
    adj = {v: [] for v in vertices}
    for e in edges:
        a, b = tuple(e)
        adj[a].append(b)
        adj[b].append(a)
    out, seen = [], set()
    for start in vertices:
        if start in seen:
            continue
        stack, block = [start], set()
        seen.add(start)
        while stack:
            v = stack.pop()
            block.add(v)
            for w in adj[v]:
                if w not in seen:
                    seen.add(w)
                    stack.append(w)
        out.append(block)
    return out


def is_perfect_matching(vertices, matching):
    return len(matching) * 2 == len(vertices) and set().union(*matching) == set(vertices)


def endpoint_countermodel():
    vertices = set(range(18))
    c0 = (0, 1, 6, 7, 2, 3, 4, 5)
    c1 = (8, 9, 16, 17, 10, 11, 12, 13, 14, 15)
    factor = {
        edge(c[i], c[(i + 1) % len(c)])
        for c in (c0, c1)
        for i in range(len(c))
    }
    matching = {
        edge(6, 16), edge(7, 17),
        edge(0, 3), edge(1, 2),
        edge(9, 12), edge(8, 13),
        edge(4, 10), edge(11, 14), edge(5, 15),
    }
    cycles = (
        {edge(0, 1), edge(1, 2), edge(2, 3), edge(3, 0)},
        {edge(8, 9), edge(9, 12), edge(12, 13), edge(13, 8)},
        {edge(4, 5), edge(5, 15), edge(15, 14),
         edge(14, 11), edge(11, 10), edge(10, 4)},
    )
    graph = factor | matching
    assert len(graph) == 27
    assert is_perfect_matching(vertices, matching)
    assert all(sum(v in e for e in graph) == 3 for v in vertices)
    x = {0, 2, 4, 6, 9, 11, 13, 15, 17}
    assert all(len(e & x) == 1 for e in graph)
    cycle_vertices = [set().union(*cycle) for cycle in cycles]
    assert all(cycle_vertices[i].isdisjoint(cycle_vertices[j])
               for i, j in combinations(range(3), 2))
    assert all(len(c & matching) * 2 == len(c) for c in cycles)

    root_ends = {6, 16}
    feasible = []
    profile = []
    for mask in range(8):
        new_matching = set(matching)
        for i, cycle in enumerate(cycles):
            if mask >> i & 1:
                new_matching ^= cycle
        assert is_perfect_matching(vertices, new_matching)
        blocks = components(vertices, graph - new_matching)
        separated = not any(root_ends <= b for b in blocks)
        profile.append((len(blocks), separated))
        if len(blocks) == 2 and separated:
            feasible.append(mask)
    assert feasible == [0, 7]
    assert profile == [
        (2, True), (3, True), (3, True), (4, True),
        (2, False), (3, True), (1, False), (2, True),
    ]
    # Symmetric exchange fails for X=0,Y=7,e=coordinate 0.
    assert all((1 if f == 0 else 1 | (1 << f)) not in feasible for f in range(3))


def cube_lexicographic_countermodel():
    # Q_3, with dimension-2 edges viewed as the four prism rungs.
    vertices = set(range(8))
    graph = {edge(v, v ^ (1 << bit)) for v in vertices for bit in range(3)}
    assert len(graph) == 12
    matching = {edge(i, i ^ 4) for i in range(4)}
    root = edge(0, 4)
    gate = edge(2, 6)
    alternating_face = {edge(2, 3), edge(3, 7), edge(7, 6), edge(6, 2)}
    new_matching = matching ^ alternating_face
    assert root in matching & new_matching
    assert gate in matching and gate not in new_matching
    assert is_perfect_matching(vertices, matching)
    assert is_perfect_matching(vertices, new_matching)
    assert len(components(vertices, graph - matching)) == 2
    assert len(components(vertices, graph - new_matching)) == 1

    # Direct 2-extendability check of this one fixed graph.
    perfect_matchings = []
    for candidate in combinations(graph, 4):
        candidate = set(candidate)
        if is_perfect_matching(vertices, candidate):
            perfect_matchings.append(candidate)
    assert len(perfect_matchings) == 9
    for a, b in combinations(graph, 2):
        if a.isdisjoint(b):
            assert any(a in p and b in p for p in perfect_matchings)


def main():
    endpoint_countermodel()
    cube_lexicographic_countermodel()
    print("TARGET_CUBE_DELTA_COUNTERMODELS_VERIFIED")


if __name__ == "__main__":
    main()
