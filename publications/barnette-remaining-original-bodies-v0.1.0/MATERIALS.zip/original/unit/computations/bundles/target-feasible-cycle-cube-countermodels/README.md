# Target-feasible cycle-cube countermodels

This bundle verifies the finite assertions used in
[Note 082](../../../notes/082-target-feasible-cycle-cubes-are-not-delta-matroids.md).
The lexicographic equivalence in that note is analytic.

The pure-standard-library verifier checks two countermodels:

1. an \(18\)-vertex simple cubic bipartite common-incidence model whose
   three-coordinate target-feasible family is exactly
   \(\{\varnothing,\{1,2,3\}\}\), violating symmetric exchange; and
2. the plane brace \(Q_3\), where the absolute lexicographic minimum
   \((1,1)\) for a root-sharing gate-deleting matching has Hamiltonian
   complement, so the gate coordinate remains a target-feasible loop.

Run from the AIMath project root:

    python3 \
      units/barnette/computations/bundles/target-feasible-cycle-cube-countermodels/verify_target_cube_delta_countermodels.py

The required final line is

    TARGET_CUBE_DELTA_COUNTERMODELS_VERIFIED

The second verifier reconstructs exactly the \(868\) labelled two-step
repair sequences frozen by Note 080 and tests every relevant component
subset in its \(32\) braces.  It does not generate another graph class.

Run

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/target-feasible-cycle-cube-countermodels/classify_gate_component_target_toggles.py

The required summary is

    GATE_COMPONENT_TARGET_TOGGLES_CLASSIFIED
    sequences=868 braces=32 targets=612 double_targets=180
    candidate_triples=23104 success=6813 failure=16291
    lex_minimizers=1693 lex_success=0 lex_failure=1693
    minimum_counterexample=family11/sequence350
    minimum_lex_counterexample=family11/sequence350

The classifier writes
gate_component_target_toggle_classification.json in this directory.
These counts classify the fixed minimum-repair class; they are not an
order-\(28\) census and do not refute ordinary \(C_4\)-lifting.
