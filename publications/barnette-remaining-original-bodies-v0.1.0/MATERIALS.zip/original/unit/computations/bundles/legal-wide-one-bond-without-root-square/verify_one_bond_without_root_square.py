#!/usr/bin/env python3
"""Verify the twelve-vertex one-bond counterexample of Note 150.

The script uses only the Python standard library.  It checks the stated
combinatorial plane triangulation, exhausts all normalized NAE colourings,
applies the rooted-admission test, and reconstructs the complete rooted
bond graph for the fixed root and two gates.
"""

from itertools import combinations, product


def edge(u, v):
    return tuple(sorted((u, v)))


RIM = tuple(f"r{i}" for i in range(8))
VERTICES = ("z",) + RIM + ("A", "B", "C")

EDGES = {
    *(edge(RIM[i], RIM[(i + 1) % 8]) for i in range(8)),
    *(edge("z", r) for r in RIM),
    edge("A", "r0"), edge("A", "r1"), edge("A", "r2"), edge("A", "C"),
    edge("B", "r0"),
    *(edge("B", f"r{i}") for i in range(2, 8)),
    edge("B", "C"), edge("C", "r0"), edge("C", "r2"),
}

FACES = {
    *(frozenset(("z", RIM[i], RIM[(i + 1) % 8])) for i in range(8)),
    frozenset(("A", "r0", "r1")),
    frozenset(("A", "r1", "r2")),
    *(frozenset(("B", RIM[i], RIM[(i + 1) % 8])) for i in range(2, 7)),
    frozenset(("B", "r7", "r0")),
    frozenset(("A", "C", "r0")),
    frozenset(("B", "C", "r0")),
    frozenset(("A", "C", "r2")),
    frozenset(("B", "C", "r2")),
}

ROOT = edge("B", "r3")
FORCED_GATE = edge("z", "r5")
SURVIVING_GATE = edge("z", "r1")
SITE_P = edge("A", "r2")
SITE_Q = edge("A", "r0")
SHORT_EDGE = edge("A", "r1")

EXPECTED_ROWS = {
    "010101011001",
    "010101011100",
    "011101011000",
}


def adjacency():
    out = {v: set() for v in VERTICES}
    for u, v in EDGES:
        out[u].add(v)
        out[v].add(u)
    return out


ADJ = adjacency()


def connected(keep):
    keep = set(keep)
    if not keep:
        return False
    seen = {next(iter(keep))}
    stack = list(seen)
    while stack:
        u = stack.pop()
        for v in ADJ[u] & keep - seen:
            seen.add(v)
            stack.append(v)
    return seen == keep


def components(keep):
    unseen = set(keep)
    out = []
    while unseen:
        start = next(iter(unseen))
        comp = {start}
        stack = [start]
        unseen.remove(start)
        while stack:
            u = stack.pop()
            for v in ADJ[u] & unseen:
                unseen.remove(v)
                comp.add(v)
                stack.append(v)
        out.append(frozenset(comp))
    return tuple(out)


def all_triangles():
    return {
        frozenset(triple)
        for triple in combinations(VERTICES, 3)
        if all(edge(u, v) in EDGES for u, v in combinations(triple, 2))
    }


def check_plane_triangulation():
    assert len(VERTICES) == 12
    assert len(EDGES) == 3 * len(VERTICES) - 6 == 30
    assert len(FACES) == 2 * len(VERTICES) - 4 == 20
    assert all_triangles() == FACES
    for e in EDGES:
        assert sum(set(e) <= face for face in FACES) == 2
    for v in VERTICES:
        link_edges = {
            edge(*tuple(face - {v})) for face in FACES if v in face
        }
        link_vertices = ADJ[v]
        link_degree = {x: 0 for x in link_vertices}
        for x, y in link_edges:
            link_degree[x] += 1
            link_degree[y] += 1
        assert len(link_edges) == len(link_vertices)
        assert set(link_degree.values()) == {2}
    assert connected(VERTICES)
    for size in range(1, 4):
        for deleted in combinations(VERTICES, size):
            assert connected(set(VERTICES) - set(deleted))
    assert all(len(ADJ[v]) % 2 == 0 for v in VERTICES)


def dual_cubic_graph():
    face_list = tuple(sorted(FACES, key=lambda face: tuple(sorted(face))))
    dual_edges = set()
    for named_edge in EDGES:
        incident = [
            i for i, face in enumerate(face_list)
            if set(named_edge) <= face
        ]
        assert len(incident) == 2
        dual_edges.add(edge(*incident))
    assert len(face_list) == 20 and len(dual_edges) == 30
    dual_adjacency = {i: set() for i in range(len(face_list))}
    for u, v in dual_edges:
        dual_adjacency[u].add(v)
        dual_adjacency[v].add(u)
    assert {len(neighbours) for neighbours in dual_adjacency.values()} == {3}

    colours = {0: 0}
    stack = [0]
    while stack:
        u = stack.pop()
        for v in dual_adjacency[u]:
            if v in colours:
                assert colours[v] != colours[u]
            else:
                colours[v] = 1 - colours[u]
                stack.append(v)
    assert len(colours) == len(face_list)
    return dual_adjacency, dual_edges


def enumerate_perfect_matchings(graph):
    vertices = frozenset(graph)
    output = []

    def visit(unmatched, chosen):
        if not unmatched:
            output.append(frozenset(chosen))
            return
        u = min(unmatched, key=lambda x: len(graph[x] & unmatched))
        for v in sorted(graph[u] & unmatched):
            visit(unmatched - {u, v}, chosen + (edge(u, v),))

    visit(vertices, ())
    return tuple(output)


def check_dual_is_brace():
    graph, dual_edges = dual_cubic_graph()
    matchings = enumerate_perfect_matchings(graph)
    independent_pairs = tuple(
        frozenset((first, second))
        for first, second in combinations(dual_edges, 2)
        if set(first).isdisjoint(second)
    )
    assert len(independent_pairs) == 375
    assert all(
        any(pair <= matching for matching in matchings)
        for pair in independent_pairs
    )
    return len(matchings), len(independent_pairs)


def incident_thirds(named_edge):
    u, v = named_edge
    thirds = [next(iter(face - {u, v})) for face in FACES if {u, v} <= face]
    assert len(thirds) == 2
    return tuple(thirds)


def normalized_nae_colourings():
    free = tuple(v for v in VERTICES if v != "z")
    for bits in product((0, 1), repeat=len(free)):
        row = {"z": 0, **dict(zip(free, bits))}
        if all(len({row[v] for v in face}) == 2 for face in FACES):
            yield row


def gate_bit(row, named_edge):
    u, v = named_edge
    return int(row[u] == row[v])


def rooted(row):
    u, v = ROOT
    if row[u] != row[v]:
        return False
    root_colour = row[u]
    colour_components = {
        bit: components(v for v in VERTICES if row[v] == bit)
        for bit in (0, 1)
    }
    if sum(map(len, colour_components.values())) != 3:
        return False
    x, y = incident_thirds(ROOT)
    if row[x] == root_colour or row[y] == root_colour:
        return False
    return not any(
        x in comp and y in comp for comp in colour_components[1 - root_colour]
    )


def row_string(row):
    return "".join(str(row[v]) for v in VERTICES)


def bond_shore(first, second):
    shore = {v for v in VERTICES if first[v] != second[v]}
    if connected(shore) and connected(set(VERTICES) - shore):
        return frozenset(shore)
    return None


def main():
    check_plane_triangulation()
    matching_count, independent_pair_count = check_dual_is_brace()

    family = tuple(
        row for row in normalized_nae_colourings()
        if rooted(row) and gate_bit(row, FORCED_GATE) == 1
    )
    assert {row_string(row) for row in family} == EXPECTED_ROWS
    assert sorted(gate_bit(row, SURVIVING_GATE) for row in family) == [0, 1, 1]

    crossing_bonds = []
    same_sector_bonds = []
    disconnected_crossings = []
    for first, second in combinations(family, 2):
        shore = bond_shore(first, second)
        crossing = (
            gate_bit(first, SURVIVING_GATE)
            != gate_bit(second, SURVIVING_GATE)
        )
        if shore is not None and crossing:
            crossing_bonds.append((row_string(first), row_string(second), shore))
        elif shore is not None:
            same_sector_bonds.append((row_string(first), row_string(second), shore))
        elif crossing:
            disconnected_crossings.append((row_string(first), row_string(second)))

    assert len(crossing_bonds) == 1
    assert crossing_bonds[0][2] == frozenset(("A", "r1"))
    assert len(same_sector_bonds) == 1
    assert same_sector_bonds[0][2] == frozenset(("A", "C"))
    assert len(disconnected_crossings) == 1

    chi = next(row for row in family if row_string(row) == "010101011100")
    eta = next(row for row in family if row_string(row) == "011101011000")
    assert gate_bit(chi, SITE_P) == gate_bit(chi, SITE_Q) == 1
    assert gate_bit(eta, SITE_P) == gate_bit(eta, SITE_Q) == 0
    assert gate_bit(eta, SHORT_EDGE) == 0

    # In the dual, opposite edges of a primal root square must share its
    # degree-four face vertex.  Here the named root and forced gate are
    # vertex-disjoint, so this essential hypothesis is absent.
    assert set(ROOT).isdisjoint(FORCED_GATE)

    # The two gate positions r5 and r1 split the cyclic link of z into
    # two arcs of four steps, the minimum legal-wide geometry.
    assert (5 - 1) % 8 == 4 and (1 - 5) % 8 == 4

    print("triangulation: vertices=12 edges=30 faces=20 connectivity=4 Eulerian=yes")
    print(
        "dual brace: vertices=20 edges=30 "
        f"perfect_matchings={matching_count} "
        f"independent_edge_pairs={independent_pair_count}"
    )
    print("complete_rooted_family=3 sectors=2+1 crossing_bonds=1")
    print("unique_shore={A,r1} profile=h-avoiding-11-00 root_square=no")
    print("LEGAL_WIDE_ONE_BOND_WITHOUT_ROOT_SQUARE_VERIFIED")


if __name__ == "__main__":
    main()
