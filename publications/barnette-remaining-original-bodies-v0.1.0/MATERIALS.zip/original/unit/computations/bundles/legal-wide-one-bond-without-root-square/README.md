# Legal-wide one-bond counterexample without a root square

This bundle verifies the finite certificate used in
[Note 150](../../../notes/150-root-square-incidence-is-essential-and-polyhedral-connectivity-stops-at-root-admission.md).
The graph, embedding faces, root, gates, and split-site labels are
hard-coded in `verify_one_bond_without_root_square.py`.

Run from the AIMath project root:

```bash
python3 units/barnette/computations/bundles/legal-wide-one-bond-without-root-square/verify_one_bond_without_root_square.py
```

The verifier uses only the Python standard library and exhausts
(2^{11}=2048) normalized binary rows.  It was frozen under Python
3.14.6.  Expected output:

```text
triangulation: vertices=12 edges=30 faces=20 connectivity=4 Eulerian=yes
dual brace: vertices=20 edges=30 perfect_matchings=97 independent_edge_pairs=375
complete_rooted_family=3 sectors=2+1 crossing_bonds=1
unique_shore={A,r1} profile=h-avoiding-11-00 root_square=no
LEGAL_WIDE_ONE_BOND_WITHOUT_ROOT_SQUARE_VERIFIED
```

The certificate proves the stated fixed example.  It does not enumerate
all twelve-vertex triangulations and does not address the one-bond problem
when the root-opposite-square incidence is present.
