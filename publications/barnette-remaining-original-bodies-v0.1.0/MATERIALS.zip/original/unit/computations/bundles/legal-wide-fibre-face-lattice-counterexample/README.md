# Legal-wide fibre face-lattice counterexample

This bundle verifies the octagonal-prism counterexample in
[Note 100](../../../notes/100-a-legal-wide-fixed-pairing-fibre-need-not-be-convex-in-the-face-flip-lattice.md).

Run from the repository root:

```bash
python3 units/barnette/computations/bundles/legal-wide-fibre-face-lattice-counterexample/verify_legal_wide_fibre_face_lattice_counterexample.py
```

The verifier uses only the Python standard library.  It independently:

1. enumerates all 49 perfect matchings of \(C_8\square K_2\);
2. checks that all 228 independent edge pairs extend to a perfect matching;
3. reconstructs the complete five-state fixed-pairing fibre and its
   \(4+1\) gate sectors;
4. builds the directed facial-flip lattice for each of the ten outer-face
   choices and checks nonconvexity and absence of fibre-internal covers;
5. verifies the displayed two-cover interval and a nonfacial crossing
   alternating six-cycle.

The final line is

```text
LEGAL_WIDE_FIBRE_FACE_LATTICE_COUNTEREXAMPLE_VERIFIED
```

