#!/usr/bin/env python3
"""Verify the octagonal-prism face-lattice counterexample of Note 100."""

from __future__ import annotations

from collections import deque
from itertools import combinations


Vertex = str
Edge = frozenset[Vertex]
Matching = frozenset[Edge]


def edge(left: Vertex, right: Vertex) -> Edge:
    return frozenset((left, right))


def cycle_edges(vertices: tuple[Vertex, ...]) -> frozenset[Edge]:
    return frozenset(
        edge(vertices[index], vertices[(index + 1) % len(vertices)])
        for index in range(len(vertices))
    )


def enumerate_perfect_matchings(
    vertices: frozenset[Vertex], edges: frozenset[Edge]
) -> tuple[Matching, ...]:
    adjacency = {vertex: set() for vertex in vertices}
    for item in edges:
        left, right = tuple(item)
        adjacency[left].add(right)
        adjacency[right].add(left)
    matchings: list[Matching] = []

    def recurse(unmatched: frozenset[Vertex], chosen: tuple[Edge, ...]) -> None:
        if not unmatched:
            matchings.append(frozenset(chosen))
            return
        vertex = min(
            unmatched,
            key=lambda value: (
                sum(neighbour in unmatched for neighbour in adjacency[value]),
                value,
            ),
        )
        for neighbour in sorted(adjacency[vertex] & unmatched):
            recurse(unmatched - {vertex, neighbour}, chosen + (edge(vertex, neighbour),))

    recurse(vertices, ())
    return tuple(matchings)


def complement_profile(
    vertices: frozenset[Vertex],
    edges: frozenset[Edge],
    matching: Matching,
    terminals: frozenset[Vertex],
) -> tuple[frozenset[frozenset[Vertex]], int] | None:
    adjacency = {vertex: set() for vertex in vertices}
    for item in edges - matching:
        left, right = tuple(item)
        adjacency[left].add(right)
        adjacency[right].add(left)
    if any(len(adjacency[vertex]) not in (1, 2) for vertex in vertices):
        return None
    unseen = set(vertices)
    pairs: set[frozenset[Vertex]] = set()
    closed = 0
    while unseen:
        start = min(unseen)
        component = {start}
        queue = deque((start,))
        while queue:
            vertex = queue.popleft()
            for neighbour in adjacency[vertex] - component:
                component.add(neighbour)
                queue.append(neighbour)
        unseen -= component
        endpoints = {vertex for vertex in component if len(adjacency[vertex]) == 1}
        if not endpoints:
            closed += 1
        elif len(endpoints) == 2 and endpoints <= terminals:
            pairs.add(frozenset(endpoints))
        else:
            return None
    return frozenset(pairs), closed


def alternating_sign(
    face: tuple[Vertex, ...], matching: Matching, colours: dict[Vertex, int]
) -> int | None:
    boundary = tuple(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )
    pattern = tuple(item in matching for item in boundary)
    even = tuple(index % 2 == 0 for index in range(len(face)))
    odd = tuple(not value for value in even)
    if pattern not in (even, odd):
        return None
    first = pattern.index(True)
    left = face[first]
    right = face[(first + 1) % len(face)]
    return 1 if colours[left] == 0 and colours[right] == 1 else -1


def directed_flip_graph(
    matchings: tuple[Matching, ...],
    faces: tuple[tuple[Vertex, ...], ...],
    outer: int,
    colours: dict[Vertex, int],
) -> dict[Matching, set[Matching]]:
    matching_set = set(matchings)
    graph = {matching: set() for matching in matchings}
    for matching in matchings:
        for index, face in enumerate(faces):
            if index == outer or alternating_sign(face, matching, colours) != 1:
                continue
            target = matching ^ cycle_edges(face)
            assert target in matching_set
            graph[matching].add(target)
    return graph


def topological_order(graph: dict[Matching, set[Matching]]) -> tuple[Matching, ...]:
    indegree = {vertex: 0 for vertex in graph}
    for targets in graph.values():
        for target in targets:
            indegree[target] += 1
    queue = deque(sorted((vertex for vertex, degree in indegree.items() if degree == 0), key=str))
    order: list[Matching] = []
    while queue:
        vertex = queue.popleft()
        order.append(vertex)
        for target in graph[vertex]:
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
    assert len(order) == len(graph)
    return tuple(order)


def convexity_witness(
    graph: dict[Matching, set[Matching]], subset: frozenset[Matching]
) -> tuple[Matching, Matching, Matching] | None:
    order = topological_order(graph)
    predecessors = {vertex: set() for vertex in graph}
    for source, targets in graph.items():
        for target in targets:
            predecessors[target].add(source)
    below: dict[Matching, Matching | None] = {}
    for vertex in order:
        below[vertex] = vertex if vertex in subset else next(
            (below[parent] for parent in predecessors[vertex] if below[parent] is not None),
            None,
        )
    above: dict[Matching, Matching | None] = {}
    for vertex in reversed(order):
        above[vertex] = vertex if vertex in subset else next(
            (above[target] for target in graph[vertex] if above[target] is not None),
            None,
        )
    for middle in order:
        if middle not in subset and below[middle] is not None and above[middle] is not None:
            return below[middle], middle, above[middle]
    return None


def connected_after_deletion(
    vertices: frozenset[Vertex], edges: frozenset[Edge], deleted: frozenset[Vertex]
) -> bool:
    remaining = vertices - deleted
    if not remaining:
        return True
    adjacency = {vertex: set() for vertex in remaining}
    for item in edges:
        if item & deleted:
            continue
        left, right = tuple(item)
        adjacency[left].add(right)
        adjacency[right].add(left)
    reached = {min(remaining)}
    queue = deque(reached)
    while queue:
        vertex = queue.popleft()
        for neighbour in adjacency[vertex] - reached:
            reached.add(neighbour)
            queue.append(neighbour)
    return reached == remaining


def main() -> None:
    n = 8
    top = tuple(f"t{index}" for index in range(n))
    bottom = tuple(f"b{index}" for index in range(n))
    vertices = frozenset(top + bottom)
    top_edges = cycle_edges(top)
    bottom_edges = cycle_edges(bottom)
    rungs = frozenset(edge(top[index], bottom[index]) for index in range(n))
    edges = top_edges | bottom_edges | rungs
    matchings = enumerate_perfect_matchings(vertices, edges)
    assert len(matchings) == 49

    independent_pairs = tuple(
        (left, right)
        for left, right in combinations(edges, 2)
        if not (left & right)
    )
    assert len(independent_pairs) == 228
    assert all(any({left, right} <= matching for matching in matchings) for left, right in independent_pairs)
    assert all(
        connected_after_deletion(vertices, edges, frozenset(deleted))
        for size in (0, 1, 2)
        for deleted in combinations(vertices, size)
    )

    side_edges = tuple(
        frozenset(
            (
                edge(top[index], top[(index + 1) % n]),
                edge(bottom[index], bottom[(index + 1) % n]),
                edge(top[index], bottom[index]),
                edge(top[(index + 1) % n], bottom[(index + 1) % n]),
            )
        )
        for index in range(n)
    )
    root = edge(bottom[0], bottom[1])
    forced_gate = edge(top[0], top[1])
    surviving_gate = edge(top[4], top[5])
    common = frozenset((root, forced_gate)) | frozenset(
        edge(top[index], bottom[index]) for index in range(n) if index not in (0, 1)
    )
    expected_fibre = frozenset(common ^ side_edges[index] for index in range(2, 7))
    assert expected_fibre <= set(matchings)

    square_vertices = frozenset((bottom[0], bottom[1], top[1], top[0]))
    residual_vertices = vertices - square_vertices
    residual_edges = frozenset(item for item in edges if not (item & square_vertices))
    residual_matchings = enumerate_perfect_matchings(residual_vertices, residual_edges)
    terminals = frozenset((bottom[7], bottom[2], top[2], top[7]))
    pairing = frozenset(
        (frozenset((bottom[7], top[7])), frozenset((bottom[2], top[2])))
    )
    residual_fibre = frozenset(
        matching
        for matching in residual_matchings
        if complement_profile(residual_vertices, residual_edges, matching, terminals)
        == (pairing, 0)
    )
    lifted_fibre = frozenset(matching | {root, forced_gate} for matching in residual_fibre)
    assert lifted_fibre == expected_fibre
    assert sum(surviving_gate in matching for matching in lifted_fibre) == 1

    faces = tuple(
        (bottom[index], bottom[(index + 1) % n], top[(index + 1) % n], top[index])
        for index in range(n)
    ) + (top, (bottom[0],) + tuple(reversed(bottom[1:])))
    assert len(faces) == 10
    colours = {
        **{top[index]: index % 2 for index in range(n)},
        **{bottom[index]: 1 - index % 2 for index in range(n)},
    }
    for outer in range(len(faces)):
        graph = directed_flip_graph(matchings, faces, outer, colours)
        assert convexity_witness(graph, lifted_fibre) is not None
        assert not any(
            target in lifted_fibre
            for source in lifted_fibre
            for target in graph[source]
        )

    middle = common ^ side_edges[2] ^ side_edges[5]
    lower = common ^ side_edges[5]
    upper = common ^ side_edges[2]
    graph = directed_flip_graph(matchings, faces, 0, colours)
    assert middle in graph[lower] and upper in graph[middle]
    residual_middle = middle - {root, forced_gate}
    assert complement_profile(residual_vertices, residual_edges, residual_middle, terminals) == (pairing, 1)
    crossing = (common ^ side_edges[4]) ^ (common ^ side_edges[3])
    assert len(crossing) == 6
    assert crossing not in {cycle_edges(face) for face in faces}
    assert surviving_gate in crossing

    print("perfect_matchings", len(matchings))
    print("independent_edge_pairs", len(independent_pairs))
    print("fibre_size", len(lifted_fibre), "sectors", (4, 1))
    print("outer_faces_nonconvex", len(faces))
    print("LEGAL_WIDE_FIBRE_FACE_LATTICE_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
