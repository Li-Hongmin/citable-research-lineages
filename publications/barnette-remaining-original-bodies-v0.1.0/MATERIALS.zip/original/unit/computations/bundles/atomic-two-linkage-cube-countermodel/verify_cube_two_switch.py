#!/usr/bin/env python3
"""Exact small verifier for the labelled cube two-switch countermodel."""

from itertools import combinations


def perfect_matchings(vertices, edges):
    result = []
    for candidate in combinations(edges, len(vertices) // 2):
        endpoints = [vertex for edge in candidate for vertex in edge]
        if len(set(endpoints)) == len(vertices):
            result.append(frozenset(candidate))
    return result


def components(vertices, edges, include_isolates=True):
    adjacency = {vertex: [] for vertex in vertices}
    for left, right in edges:
        adjacency[left].append(right)
        adjacency[right].append(left)
    seen = set()
    result = []
    for start in vertices:
        if start in seen or (not include_isolates and not adjacency[start]):
            continue
        stack = [start]
        seen.add(start)
        component = set()
        while stack:
            vertex = stack.pop()
            component.add(vertex)
            for neighbour in adjacency[vertex]:
                if neighbour not in seen:
                    seen.add(neighbour)
                    stack.append(neighbour)
        result.append(component)
    return result


def normalized(left, right):
    return tuple(sorted((left, right), key=str))


cube_vertices = tuple(range(8))
cube_edges = tuple(
    normalized(vertex, vertex ^ (1 << coordinate))
    for vertex in cube_vertices
    for coordinate in range(3)
    if vertex < (vertex ^ (1 << coordinate))
)
p = normalized(0, 1)
q = normalized(6, 7)
g1 = normalized(0, 2)

cube_matchings = perfect_matchings(cube_vertices, cube_edges)
assert len(cube_matchings) == 9
for first, second in combinations(cube_edges, 2):
    if set(first).isdisjoint(second):
        assert any(
            first in matching and second in matching
            for matching in cube_matchings
        )

fibre = []
for matching in cube_matchings:
    if p in matching or q in matching:
        continue
    complement_components = components(
        cube_vertices, set(cube_edges) - set(matching)
    )
    if len(complement_components) != 2:
        continue
    p_component = next(i for i, part in enumerate(complement_components) if 0 in part)
    q_component = next(i for i, part in enumerate(complement_components) if 6 in part)
    if p_component != q_component:
        fibre.append(matching)

n0 = frozenset(map(lambda edge: normalized(*edge), [(0, 2), (1, 3), (4, 6), (5, 7)]))
n1 = frozenset(map(lambda edge: normalized(*edge), [(0, 4), (1, 5), (2, 6), (3, 7)]))
assert set(fibre) == {n0, n1}
assert g1 in n0 and g1 not in n1
assert len(components(cube_vertices, n0 ^ n1, include_isolates=False)) == 2

# The inverse square extension.
square_vertices = ("u", "v", "x", "y")
extension_vertices = cube_vertices + square_vertices
extension_edges = tuple(
    edge for edge in cube_edges if edge not in {p, q}
) + tuple(
    map(
        lambda edge: normalized(*edge),
        [
            (1, "u"),
            (6, "v"),
            (7, "x"),
            (0, "y"),
            ("u", "v"),
            ("v", "x"),
            ("x", "y"),
            ("y", "u"),
        ],
    )
)

assert len(set(extension_edges)) == 18
degrees = {vertex: 0 for vertex in extension_vertices}
for left, right in extension_edges:
    degrees[left] += 1
    degrees[right] += 1
assert set(degrees.values()) == {3}
assert len(components(extension_vertices, extension_edges)) == 1
part = {
    vertex: (
        vertex.bit_count() % 2
        if isinstance(vertex, int)
        else {"u": 0, "v": 1, "x": 0, "y": 1}[vertex]
    )
    for vertex in extension_vertices
}
assert all(part[left] != part[right] for left, right in extension_edges)

extension_matchings = perfect_matchings(extension_vertices, extension_edges)
assert len(extension_matchings) == 17
for first, second in combinations(extension_edges, 2):
    if set(first).isdisjoint(second):
        assert any(first in matching and second in matching for matching in extension_matchings)

# Explicit K_3,3 subdivision certificate.  Internal vertices of the nine
# paths are pairwise disjoint, and every path joins the displayed branch
# bipartition.
left_branches = {3, 5, "x"}
right_branches = {6, 1, 7}
kuratowski_paths = (
    (3, 2, 6),
    (3, 1),
    (3, 7),
    (5, 4, 6),
    (5, 1),
    (5, 7),
    ("x", "v", 6),
    ("x", "y", "u", 1),
    ("x", 7),
)
used_internal = set()
branch_pairs = set()
for path in kuratowski_paths:
    assert path[0] in left_branches and path[-1] in right_branches
    branch_pairs.add((path[0], path[-1]))
    for edge in zip(path, path[1:]):
        assert normalized(*edge) in extension_edges
    internal = set(path[1:-1])
    assert not (internal & used_internal)
    assert not (internal & (left_branches | right_branches))
    used_internal |= internal
assert branch_pairs == {
    (left, right) for left in left_branches for right in right_branches
}

print("cube perfect matchings: 9")
print("separated fibre: {N0, N1}")
print("cross-sector symmetric difference components: 2")
print("extension perfect matchings: 17")
print("nonextendible independent edge pairs: 0")
print("extension contains the certified K3,3 subdivision")
print("ATOMIC_TWO_LINKAGE_CUBE_COUNTERMODEL_VERIFIED")
