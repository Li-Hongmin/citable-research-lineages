# Atomic two-linkage cube countermodel

This bundle verifies the finite countermodel used in
[Note 086](../../../notes/086-minimum-cross-sector-pairs-are-atomic-and-the-cube-is-the-minimum-fibre-countermodel.md).

The pure-standard-library verifier:

1. enumerates all nine perfect matchings of \(Q_3\) and verifies its
   \(2\)-extendability;
2. reconstructs the separated fibre
   \(\mathcal S_{01\mid67}=\{N_0,N_1\}\);
3. checks that \(N_0\triangle N_1\) has two alternating components;
4. enumerates all \(17\) perfect matchings of the inverse square extension
   and verifies every independent edge pair extends; and
5. checks the nine internally disjoint paths of the displayed
   \(K_{3,3}\)-subdivision.

Run from the AIMath root:

    python3 \
      units/barnette/computations/bundles/atomic-two-linkage-cube-countermodel/verify_cube_two_switch.py

The required final line is

    ATOMIC_TWO_LINKAGE_CUBE_COUNTERMODEL_VERIFIED

The example is not a counterexample to the plane-brace crossing-cycle
candidate: its specified inverse square extension is nonplanar.
