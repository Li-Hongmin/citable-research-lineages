# Legal-wide defect counterexample

This bundle verifies the construction in
[Note 092](../../../notes/092-a-legal-wide-plane-interface-has-nonnormalized-minimum-two-switches.md).

Run from the AIMath root:

```text
uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/legal-wide-defect-counterexample/verify_legal_wide_defect_counterexample.py
```

The frozen run used Python 3.12.11 and NetworkX 3.6.1.  The verifier
constructs the residual graph and all eight labelled square attachments,
checks the explicit cellular embedding and legal-wide gate arcs, recursively
enumerates all 450 residual perfect matchings, and classifies all 768
cross-sector pairs in the complete fixed-pairing fibre.  It also freezes one
literal \(C_8\dot\cup C_4\) minimum pair whose two proper toggles both have
profile \((\pi_0,1)\).

Expected final line:

```text
LEGAL_WIDE_DOUBLE_PI0_DEFECT_COUNTEREXAMPLE_VERIFIED
```

The extension is simple, connected, plane, cubic and bipartite, but has
vertex-connectivity two.  The bundle does not claim a brace counterexample
or order-minimality.

The same bundle also freezes the minimum directed repair classification used
in [Note 093](../../../notes/093-minimum-directed-repairs-of-the-legal-wide-defect-example-do-not-reach-a-brace.md):

```text
uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/legal-wide-defect-counterexample/classify_minimum_directed_brace_repairs.py
```

That command exhausts the fixed embedding's one- and two-step facial
\(C_4\) repairs.  Its expected final line is

```text
brace counterexamples with no normalized minimum: 0
```

