#!/usr/bin/env python3
"""Verify an actual legal-wide plane-interface defect counterexample."""

from collections import Counter

import networkx as nx


def edge(left, right):
    return tuple(sorted((left, right)))


def graph_from_edges(edges):
    graph = nx.Graph()
    graph.add_edges_from(sorted(edges))
    return graph


def enumerate_matchings(graph):
    adjacency = {vertex: tuple(sorted(graph[vertex])) for vertex in graph}

    def recurse(remaining):
        if not remaining:
            yield frozenset()
            return
        vertex = min(
            remaining,
            key=lambda item: (sum(neighbour in remaining for neighbour in adjacency[item]), item),
        )
        for neighbour in adjacency[vertex]:
            if neighbour not in remaining:
                continue
            for matching in recurse(remaining - {vertex, neighbour}):
                yield matching | {edge(vertex, neighbour)}

    return tuple(recurse(frozenset(graph)))


def complement_profile(graph, matching, terminals, pairing_names):
    complement = graph_from_edges(set(map(lambda item: edge(*item), graph.edges())) - set(matching))
    complement.add_nodes_from(graph)
    pairing = set()
    cycle_count = 0
    for vertices in nx.connected_components(complement):
        component = complement.subgraph(vertices)
        ends = frozenset(set(vertices) & terminals)
        if ends:
            pairing.add(ends)
        cycle_count += component.number_of_edges() - component.number_of_nodes() + 1
    frozen_pairing = frozenset(pairing)
    return pairing_names.get(frozen_pairing, tuple(sorted(map(tuple, frozen_pairing)))), cycle_count


def difference_cycles(first, second):
    difference = first ^ second
    graph = graph_from_edges(difference)
    return tuple(
        frozenset(item for item in difference if set(item) <= vertices)
        for vertices in nx.connected_components(graph)
    )


def plane_faces(embedding):
    seen = set()
    faces = []
    for left, right in embedding.edges():
        if (left, right) not in seen:
            faces.append(tuple(embedding.traverse_face(left, right, seen)))
    return tuple(faces)


def cyclic_equal(first, second):
    if len(first) != len(second):
        return False
    doubled = first + first
    reversed_doubled = tuple(reversed(first)) + tuple(reversed(first))
    return any(
        tuple(second) == doubled[index:index + len(first)]
        or tuple(second) == reversed_doubled[index:index + len(first)]
        for index in range(len(first))
    )


def assert_cellular_embedding(graph, faces):
    darts = [
        (face[index], face[(index + 1) % len(face)])
        for face in faces
        for index in range(len(face))
    ]
    assert len(darts) == 2 * graph.number_of_edges()
    assert len(set(darts)) == len(darts)
    assert {edge(*item) for item in darts} == {edge(*item) for item in graph.edges()}
    assert len(graph) - graph.number_of_edges() + len(faces) == 2


# Note 091 residual: a 12-vertex overlay with q3q4 replaced by Q3-A0B0.
OVERLAY_EDGES = {
    edge(*item)
    for item in (
        ("p0", "p1"), ("p0", "p3"), ("p1", "p2"), ("p1", "q0"),
        ("p2", "p3"), ("p2", "q5"), ("q0", "q1"), ("q1", "q2"),
        ("q1", "q4"), ("q2", "q3"), ("q2", "q7"), ("q3", "q4"),
        ("q3", "q6"), ("q4", "q5"), ("q5", "q6"), ("q6", "q7"),
    )
}
CUBE_POLE_EDGES = (
    ("A0", "B1"), ("A0", "B2"), ("A1", "B0"), ("A1", "B1"),
    ("A1", "B3"), ("A2", "B0"), ("A2", "B2"), ("A2", "B3"),
    ("A3", "B1"), ("A3", "B2"), ("A3", "B3"),
)


def prefixed_pole(prefix):
    return {edge(prefix + left, prefix + right) for left, right in CUBE_POLE_EDGES}


NOTE091_EDGES = set(OVERLAY_EDGES)
NOTE091_EDGES.remove(edge("q3", "q4"))
NOTE091_EDGES.update(prefixed_pole("L"))
NOTE091_EDGES.update((edge("q3", "LA0"), edge("q4", "LB0")))

# Two directed terminal repairs.  The q-ear moves q0,q7 to q0z,q7z.
# The W pole moves p0 to WB0 while preserving cubic bipartite incidence.
RESIDUAL_EDGES = set(NOTE091_EDGES)
RESIDUAL_EDGES.update(
    (edge("q0", "q0z"), edge("q0z", "q7z"), edge("q7z", "q7"))
)
RESIDUAL_EDGES.update(prefixed_pole("W"))
RESIDUAL_EDGES.add(edge("p0", "WA0"))
R = graph_from_edges(RESIDUAL_EDGES)

TERMINALS = frozenset(("WB0", "p3", "q0z", "q7z"))
PI0 = frozenset((frozenset(("WB0", "p3")), frozenset(("q0z", "q7z"))))
GATE1 = edge("p0", "p1")

assert len(R) == 30 and R.number_of_edges() == 43
assert R.number_of_edges() == len(RESIDUAL_EDGES) and not any(
    left == right for left, right in RESIDUAL_EDGES
)
assert nx.number_of_selfloops(R) == 0
assert nx.is_connected(R) and nx.is_bipartite(R)
assert nx.check_planarity(R)[0]
assert {vertex for vertex, degree in R.degree() if degree == 2} == TERMINALS
assert all(degree in (2, 3) for _, degree in R.degree())
assert GATE1 in set(map(lambda item: edge(*item), R.edges()))


def labelled_extensions():
    target_pairs = (("WB0", "p3"), ("q0z", "q7z"))
    for channel_swap in (False, True):
        first_pair = target_pairs[int(channel_swap)]
        second_pair = target_pairs[1 - int(channel_swap)]
        for first_channel in (first_pair, first_pair[::-1]):
            for second_channel in (second_pair, second_pair[::-1]):
                u_terminal, y_terminal = first_channel
                v_terminal, x_terminal = second_channel
                extension_edges = set(RESIDUAL_EDGES)
                extension_edges.update(
                    (
                        edge(u_terminal, "u"), edge(v_terminal, "v"),
                        edge(x_terminal, "x"), edge(y_terminal, "y"),
                        edge("u", "v"), edge("v", "x"),
                        edge("x", "y"), edge("y", "u"),
                    )
                )
                yield (u_terminal, v_terminal, x_terminal, y_terminal), graph_from_edges(extension_edges)


attachment_results = Counter()
legal_extensions = []
for attachment, extension in labelled_extensions():
    planar, embedding = nx.check_planarity(extension)
    bipartite = nx.is_bipartite(extension)
    attachment_results[(planar, bipartite)] += 1
    if not (planar and bipartite):
        continue
    faces = plane_faces(embedding)
    square_faces = tuple(
        face for face in faces if len(face) == 4 and set(face) == {"u", "v", "x", "y"}
    )
    if len(square_faces) != 1:
        continue
    square_edges = (edge("u", "v"), edge("v", "x"), edge("x", "y"), edge("y", "u"))
    for root, gate0 in ((square_edges[0], square_edges[2]), (square_edges[2], square_edges[0])):
        for face in faces:
            boundary = tuple(
                edge(face[index], face[(index + 1) % len(face)])
                for index in range(len(face))
            )
            if gate0 not in boundary or GATE1 not in boundary or root in boundary:
                continue
            delta = (boundary.index(GATE1) - boundary.index(gate0)) % len(boundary)
            arc_sizes = (delta + 1, len(boundary) - delta + 1)
            if min(arc_sizes) >= 5 and all(size % 2 == 1 for size in arc_sizes):
                legal_extensions.append(
                    (attachment, extension, faces, root, gate0, face, arc_sizes)
                )

print(f"attachment results: {attachment_results}")
print(f"legal extension witnesses: {len(legal_extensions)}")
for record in legal_extensions:
    attachment, _, _, root, gate0, face, arc_sizes = record
    print(f"  attachment={attachment} root={root} gate0={gate0} arcs={arc_sizes}")
    print(f"  common_face={face}")

assert attachment_results == Counter({(True, True): 4, (False, False): 4})
assert len(legal_extensions) == 4
CHOSEN_ATTACHMENT = ("WB0", "q0z", "q7z", "p3")
attachment, G, G_FACES, ROOT, GATE0, COMMON_FACE, WIDE_ARCS = next(
    record for record in legal_extensions if record[0] == CHOSEN_ATTACHMENT
)
assert len(G) == 34 and G.number_of_edges() == 51
assert nx.is_connected(G) and nx.is_bipartite(G) and nx.check_planarity(G)[0]
assert nx.number_of_selfloops(G) == 0
assert all(degree == 3 for _, degree in G.degree())
assert nx.node_connectivity(G) == 2
assert_cellular_embedding(G, G_FACES)
assert attachment == CHOSEN_ATTACHMENT
assert ROOT == edge("x", "y") and GATE0 == edge("u", "v")
assert set(ROOT).isdisjoint(GATE0)
colour = nx.bipartite.color(G)
assert colour["u"] == colour["x"] != colour["v"] == colour["y"]
assert all(colour[square] != colour[terminal] for square, terminal in zip(
    ("u", "v", "x", "y"), attachment
))
assert sorted(WIDE_ARCS) == [5, 7]
assert cyclic_equal(
    COMMON_FACE,
    ("WA0", "WB2", "WA2", "WB0", "u", "v", "q0z", "q0", "p1", "p0"),
)
assert sum(
    GATE0 in {
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    }
    and GATE1 in {
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    }
    for face in G_FACES
) == 1

# Name all three endpoint pairings from their square positions.
terminal_at = dict(zip(("u", "v", "x", "y"), attachment))
pairing_names = {
    frozenset((
        frozenset((terminal_at["u"], terminal_at["y"])),
        frozenset((terminal_at["v"], terminal_at["x"])),
    )): "pi0",
    frozenset((
        frozenset((terminal_at["u"], terminal_at["v"])),
        frozenset((terminal_at["x"], terminal_at["y"])),
    )): "pi1",
    frozenset((
        frozenset((terminal_at["u"], terminal_at["x"])),
        frozenset((terminal_at["v"], terminal_at["y"])),
    )): "pi2",
}
assert pairing_names[PI0] == "pi0"

# Complete residual PM/fibre classification.
matchings = enumerate_matchings(R)
fibre = tuple(
    matching for matching in matchings
    if complement_profile(R, matching, TERMINALS, pairing_names) == ("pi0", 0)
)
sector1 = tuple(matching for matching in fibre if GATE1 in matching)
sector0 = tuple(matching for matching in fibre if GATE1 not in matching)
assert (len(matchings), len(fibre), len(sector1), len(sector0)) == (450, 64, 16, 48)

cross_pairs = []
for first in sector1:
    for second in sector0:
        cycles = difference_cycles(first, second)
        cross_pairs.append((len(cycles), first, second, cycles))
cross_histogram = Counter(item[0] for item in cross_pairs)
assert cross_histogram == Counter({2: 48, 3: 240, 4: 348, 5: 120, 6: 12})
minimum_pairs = tuple(item for item in cross_pairs if item[0] == 2)
assert len(minimum_pairs) == 48

defect_pairs = []
profile_histogram = Counter()
for _, first, second, cycles in minimum_pairs:
    profiles = tuple(
        complement_profile(R, first ^ cycle, TERMINALS, pairing_names)
        for cycle in cycles
    )
    profile_histogram[tuple(sorted(profiles, key=str))] += 1
    if Counter(profiles) != Counter({("pi1", 0): 1, ("pi0", 1): 1}):
        defect_pairs.append((first, second, cycles, profiles))

print(f"minimum profile histogram: {profile_histogram}")
print(f"defective minimum pairs: {len(defect_pairs)}")
assert len(defect_pairs) == 16
assert {
    tuple(sorted(profiles, key=str)) for _, _, _, profiles in defect_pairs
} == {(('pi0', 1), ('pi0', 1))}

# A literal minimum witness, independent of enumeration order.
COMMON_POLE_MATCHING = {
    edge(*item)
    for item in (
        ("LA0", "LB1"), ("LA1", "LB0"), ("LA2", "LB2"), ("LA3", "LB3"),
        ("WA0", "WB1"), ("WA1", "WB0"), ("WA2", "WB2"), ("WA3", "WB3"),
        ("q0z", "q7z"),
    )
}
M = frozenset(COMMON_POLE_MATCHING | {
    edge("p0", "p1"), edge("p2", "p3"), edge("q0", "q1"),
    edge("q2", "q3"), edge("q4", "q5"), edge("q6", "q7"),
})
N = frozenset(COMMON_POLE_MATCHING | {
    edge("p0", "p3"), edge("p1", "q0"), edge("p2", "q5"),
    edge("q1", "q4"), edge("q2", "q7"), edge("q3", "q6"),
})
C8 = frozenset(
    edge(*item)
    for item in (
        ("p0", "p1"), ("p1", "q0"), ("q0", "q1"), ("q1", "q4"),
        ("q4", "q5"), ("q5", "p2"), ("p2", "p3"), ("p3", "p0"),
    )
)
C4 = frozenset(
    edge(*item)
    for item in (("q2", "q3"), ("q3", "q6"), ("q6", "q7"), ("q7", "q2"))
)
CYCLES = difference_cycles(M, N)
PROFILES = tuple(
    complement_profile(R, M ^ cycle, TERMINALS, pairing_names)
    for cycle in CYCLES
)
assert M in sector1 and N in sector0
assert set(CYCLES) == {C4, C8}
assert Counter(PROFILES) == Counter({("pi0", 1): 2})
assert N == M ^ CYCLES[0] ^ CYCLES[1]
assert all(M ^ cycle not in fibre for cycle in CYCLES)
assert any(first == M and second == N for _, first, second, _ in minimum_pairs)

# Every residual fibre state extends across the labelled root square by the
# two opposite matching edges ROOT and GATE0.
for matching in fibre:
    extended_matching = matching | {ROOT, GATE0}
    assert len(extended_matching) == len(G) // 2
    assert len({vertex for item in extended_matching for vertex in item}) == len(G)

print(f"chosen attachment order (u,v,x,y): {attachment}")
print(f"root={ROOT}; gate0={GATE0}; gate1={GATE1}; wide_arcs={WIDE_ARCS}")
print(f"M={tuple(sorted(M))}")
print(f"N={tuple(sorted(N))}")
print(f"cycles={tuple(tuple(sorted(cycle)) for cycle in CYCLES)}")
print("LEGAL_WIDE_DOUBLE_PI0_DEFECT_COUNTEREXAMPLE_VERIFIED")
