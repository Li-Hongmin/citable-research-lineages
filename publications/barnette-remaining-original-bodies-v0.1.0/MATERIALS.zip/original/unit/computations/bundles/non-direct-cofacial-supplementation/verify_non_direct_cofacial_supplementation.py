#!/usr/bin/env python3
"""Verify the fixed Note 107 non-direct supplementation witness.

The parent is the labelled order-32 plane brace frozen in the Note 099
bundle.  We reconstruct one order-36 cofacial child, enumerate its complete
perfect-matching family, and compare the three literal Note 106 lifts of
every parent state-11 target with the complete child target fibre.
"""

from __future__ import annotations

from collections import Counter
import contextlib
import io
from pathlib import Path
import runpy

import networkx as nx


HERE = Path(__file__).resolve().parent
AIMATH = HERE.parents[4]
BASE_PATH = (
    AIMATH
    / "units/barnette/computations/bundles/c4-crossing-lift-and-note099-one-step"
    / "classify_note099_one_step_expansions.py"
)

with contextlib.redirect_stdout(io.StringIO()):
    BASE = runpy.run_path(BASE_PATH)

edge = BASE["edge"]
expand_on_face = BASE["expand_on_face"]
child_matchings = BASE["child_matchings"]
target = BASE["target"]
one_cycle = BASE["one_cycle"]
brace_certificate = BASE["brace_certificate"]
legal_wide = BASE["legal_wide"]
PARENT_GRAPH = BASE["PARENT_GRAPH"]
PARENT_FACES = BASE["PARENT_FACES"]
PARENT_MATCHINGS = BASE["PARENT_MATCHINGS"]
OLD_FIBRE = BASE["OLD_FIBRE"]
SURVIVING_GATE = BASE["SURVIVING_GATE"]
ROOT = BASE["ROOT"]
FORCED_GATE = BASE["FORCED_GATE"]

FACE_INDEX = 1
INDICES = (3, 7)
EXPECTED_FACE = ("a0", "x2", "b11", "b10", "b9", "x8", "x7", "a3")


def serial_matching(matching):
    return tuple(sorted(tuple(sorted(item)) for item in matching))


def parent_names():
    ordered = sorted(OLD_FIBRE, key=serial_matching)
    return {matching: f"L{index:02d}" for index, matching in enumerate(ordered)}


def face_arc_edges(face, first_index, second_index):
    degree = len(face)
    arc_a = frozenset(
        edge(face[index], face[(index + 1) % degree])
        for index in range(first_index + 1, second_index)
    )
    indices_b = tuple(range(second_index + 1, degree)) + tuple(range(0, first_index))
    arc_b = frozenset(
        edge(face[index], face[(index + 1) % degree]) for index in indices_b
    )
    return arc_a, arc_b


def direct_lifts(parent, selected, local, arc_a, arc_b):
    ua, ab, bv, xc, cd, dy, ad, bc = local
    common = parent - frozenset(selected)
    return {
        "R00": (common ^ arc_a ^ arc_b) | frozenset((ab, cd)),
        "Xuy": (common ^ arc_a) | frozenset((ua, bc, dy)),
        "Xvx": (common ^ arc_b) | frozenset((ad, bv, xc)),
    }


def cell_type(matching, local):
    ua, ab, bv, xc, cd, dy, ad, bc = local
    patterns = {
        frozenset((ad, bc)): "canonical",
        frozenset((ua, bv, cd)): "canonical",
        frozenset((xc, dy, ab)): "canonical",
        frozenset((ua, bv, xc, dy)): "C11",
        frozenset((ab, cd)): "R00",
        frozenset((ua, dy, bc)): "Xuy",
        frozenset((bv, xc, ad)): "Xvx",
    }
    return patterns[matching & frozenset(local)]


def complement_component_count(graph, matching):
    complement = nx.Graph()
    complement.add_nodes_from(graph)
    complement.add_edges_from(
        tuple(item)
        for item in frozenset(map(frozenset, graph.edges())) - matching
    )
    return nx.number_connected_components(complement)


def assert_plane_brace(graph, faces, matchings):
    assert nx.check_planarity(graph)[0]
    assert nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    brace, independent, covered = brace_certificate(graph, matchings)
    assert brace and independent == covered
    assert legal_wide(faces) is not None


def main():
    assert len(PARENT_GRAPH) == 32
    assert PARENT_FACES[FACE_INDEX] == EXPECTED_FACE
    assert_plane_brace(PARENT_GRAPH, PARENT_FACES, PARENT_MATCHINGS)

    face = PARENT_FACES[FACE_INDEX]
    first_index, second_index = INDICES
    selected = (
        edge(face[first_index], face[(first_index + 1) % len(face)]),
        edge(face[second_index], face[(second_index + 1) % len(face)]),
    )
    assert frozenset(selected) == frozenset((edge("b10", "b9"), edge("a3", "a0")))

    child, child_faces, local = expand_on_face(FACE_INDEX, *INDICES)
    matchings, _ancestor = child_matchings(child, selected, local)
    assert len(child) == 36
    assert_plane_brace(child, child_faces, matchings)

    fibre = tuple(matching for matching in matchings if target(child, matching))
    labels = {matching: cell_type(matching, local) for matching in fibre}
    sector_zero = tuple(matching for matching in fibre if SURVIVING_GATE not in matching)
    sector_one = tuple(matching for matching in fibre if SURVIVING_GATE in matching)
    crossings = tuple(
        (first, second)
        for first in sector_zero
        for second in sector_one
        if one_cycle(first, second)
    )
    incidence = Counter(endpoint for pair in crossings for endpoint in pair)

    names = parent_names()
    state_11 = tuple(
        matching for matching in OLD_FIBRE if all(item in matching for item in selected)
    )
    assert tuple(sorted(names[matching] for matching in state_11)) == ("L20", "L26", "L27")

    arc_a, arc_b = face_arc_edges(face, *INDICES)
    assert (len(arc_a), len(arc_b)) == (3, 3)
    matching_set = frozenset(matchings)
    fibre_set = frozenset(fibre)
    direct_candidates = []
    direct_perfect = []
    direct_targets = []
    diagnoses = []
    for parent in sorted(state_11, key=serial_matching):
        for cell, candidate in direct_lifts(parent, selected, local, arc_a, arc_b).items():
            direct_candidates.append((names[parent], cell, candidate))
            if candidate in matching_set:
                direct_perfect.append((names[parent], cell, candidate))
                diagnoses.append((names[parent], cell, complement_component_count(child, candidate)))
            if candidate in fibre_set:
                direct_targets.append((names[parent], cell, candidate))

    assert len(direct_candidates) == 9
    assert tuple((name, cell) for name, cell, _ in direct_perfect) == (
        ("L20", "Xuy"),
        ("L26", "R00"),
        ("L26", "Xuy"),
        ("L26", "Xvx"),
        ("L27", "Xvx"),
    )
    assert tuple(count for _name, _cell, count in diagnoses) == (3, 4, 3, 3, 3)
    assert not direct_targets

    cells = ("R00", "Xuy", "Xvx")
    full_counts = {
        cell: sum(labels[matching] == cell for matching in fibre) for cell in cells
    }
    touching_counts = {
        cell: sum(labels[matching] == cell and incidence[matching] > 0 for matching in fibre)
        for cell in cells
    }
    incidence_counts = {
        cell: sum(incidence[matching] for matching in fibre if labels[matching] == cell)
        for cell in cells
    }
    assert len(fibre) == 67
    assert len(crossings) == 139
    assert full_counts == {"R00": 15, "Xuy": 5, "Xvx": 9}
    assert touching_counts == {"R00": 13, "Xuy": 5, "Xvx": 9}
    assert incidence_counts == {"R00": 41, "Xuy": 27, "Xvx": 38}

    new_cells = frozenset(cells)
    new_crossings = tuple(
        pair for pair in crossings if any(labels[endpoint] in new_cells for endpoint in pair)
    )
    assert len(new_crossings) == 88
    direct_matching_set = frozenset(candidate for _name, _cell, candidate in direct_candidates)
    assert all(
        endpoint not in direct_matching_set
        for pair in new_crossings
        for endpoint in pair
        if labels[endpoint] in new_cells
    )

    old_sector_zero = tuple(matching for matching in OLD_FIBRE if SURVIVING_GATE not in matching)
    old_sector_one = tuple(matching for matching in OLD_FIBRE if SURVIVING_GATE in matching)
    old_crossings = tuple(
        (first, second)
        for first in old_sector_zero
        for second in old_sector_one
        if one_cycle(first, second)
    )
    state_11_set = frozenset(state_11)
    uncovered = tuple(
        pair for pair in old_crossings if all(endpoint not in state_11_set for endpoint in pair)
    )
    assert len(old_crossings) == 69
    assert len(uncovered) == 51

    # Required edges are part of the fibre definition, not inferred from
    # the counts above.
    assert all(ROOT in matching and FORCED_GATE in matching for matching in fibre)

    print("parent_order 32 child_order 36")
    print("state_11 L20 L26 L27")
    print("direct candidates/perfect/targets 9 5 0")
    print("child fibre/crossings/new-cell-crossings 67 139 88")
    print("cells R00=15/13 Xuy=5/5 Xvx=9/9")
    print("parent crossings/uncovered-by-L11 69 51")
    print("NON_DIRECT_COFACIAL_SUPPLEMENTATION_VERIFIED")


if __name__ == "__main__":
    main()
