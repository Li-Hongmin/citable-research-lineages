#!/usr/bin/env python3
"""Verify the two-state exchange-closed Omega blocker of Note 107."""

from __future__ import annotations

def edge(left, right):
    return frozenset((left, right))


def components(edges):
    adjacency = {}
    for item in edges:
        left, right = tuple(item)
        adjacency.setdefault(left, set()).add(right)
        adjacency.setdefault(right, set()).add(left)
    result = []
    unseen = set(adjacency)
    while unseen:
        start = min(unseen)
        stack = [start]
        component = set()
        while stack:
            vertex = stack.pop()
            if vertex in component:
                continue
            component.add(vertex)
            stack.extend(adjacency[vertex] - component)
        unseen -= component
        result.append(component)
    return tuple(result)


def terminal_pairing(edges):
    terminals = {"alpha", "beta", "gamma", "delta"}
    degrees = {}
    for item in edges:
        for vertex in item:
            degrees[vertex] = degrees.get(vertex, 0) + 1
    assert all(degrees[terminal] == 1 for terminal in terminals)
    assert all(
        degree == 2 for vertex, degree in degrees.items() if vertex not in terminals
    )
    comps = components(edges)
    closed = tuple(component for component in comps if not (component & terminals))
    pairs = tuple(sorted(tuple(sorted(component & terminals)) for component in comps if component & terminals))
    return closed, pairs


def perfect_matchings(vertices, edges):
    edges = frozenset(edges)

    def visit(unmatched, chosen):
        if not unmatched:
            yield frozenset(chosen)
            return
        left = min(unmatched)
        for item in sorted((item for item in edges if left in item), key=lambda x: tuple(sorted(x))):
            right = next(iter(item - {left}))
            if right not in unmatched:
                continue
            yield from visit(unmatched - {left, right}, chosen + (item,))

    return tuple(visit(frozenset(vertices), ()))


def main():
    p = frozenset((edge("a0", "a1"), edge("a2", "a3"), edge("b0", "b1")))
    q = frozenset((edge("a0", "a3"), edge("a1", "a2"), edge("b0", "b1")))
    omega_zero = frozenset(
        (
            edge("alpha", "a0"),
            edge("a1", "beta"),
            edge("gamma", "a2"),
            edge("a3", "b0"),
            edge("b1", "delta"),
        )
    )
    omega_one = frozenset(
        (
            edge("alpha", "beta"),
            edge("a0", "b1"),
            edge("a1", "delta"),
            edge("gamma", "a2"),
            edge("a3", "b0"),
        )
    )
    desired = (("alpha", "beta"), ("delta", "gamma"))
    for omega in (omega_zero, omega_one):
        assert terminal_pairing(omega | p) == ((), desired)

    assert terminal_pairing(omega_zero | q) == (
        (),
        (("alpha", "delta"), ("beta", "gamma")),
    )
    closed, pairing = terminal_pairing(omega_one | q)
    assert pairing == desired
    assert closed == ({"a0", "a3", "b0", "b1"},)

    support = omega_zero | omega_one
    vertices = frozenset(vertex for item in support for vertex in item)
    family = perfect_matchings(vertices, support)
    assert frozenset(family) == frozenset((omega_zero, omega_one))
    symmetric_difference = omega_zero ^ omega_one
    assert len(symmetric_difference) == 6
    assert len(components(symmetric_difference)) == 1

    print("complete support family 2")
    print("exchange cycle length 6")
    print("OMEGA_EXCHANGE_CLOSED_HEXAGON_BLOCKER_VERIFIED")


if __name__ == "__main__":
    main()
