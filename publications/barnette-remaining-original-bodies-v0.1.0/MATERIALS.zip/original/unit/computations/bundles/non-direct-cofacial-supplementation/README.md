# Non-direct cofacial supplementation

This bundle supports
[Note 107](../../../notes/107-cofacial-complete-family-supplementation-can-be-entirely-nondirect.md).

Run from the AIMath root:

```bash
PYTHONHASHSEED=0 uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/non-direct-cofacial-supplementation/verify_non_direct_cofacial_supplementation.py

python3 \
  units/barnette/computations/bundles/non-direct-cofacial-supplementation/verify_abstract_exchange_closed_omega_blocker.py
```

The first command reconstructs the frozen order-32 Note 099 plane brace and
one specified order-36 legal-wide brace child.  It enumerates the complete
child perfect-matching family and verifies that all 88 crossings incident
with the three new cells use non-direct targets.  It also records that the
chosen site is not a one-step kill cover.

The second command verifies the sharp two-state hexagonal connection-support
blocker: the complete feasible family is one nontrivial alternating-cycle
exchange component and both states are direct-\(\Omega\)-bad.

Expected final markers:

```text
NON_DIRECT_COFACIAL_SUPPLEMENTATION_VERIFIED
OMEGA_EXCHANGE_CLOSED_HEXAGON_BLOCKER_VERIFIED
```

The promotion environment was Python 3.12 with NetworkX supplied by `uv` on
2026-08-28.
