#!/usr/bin/env python3
"""Classify rooted split-bond kill-cover sites in the four fixed parents."""

from __future__ import annotations

from collections import Counter, defaultdict
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
FAMILY = HERE / "three_cube_annular_family_support.py"
NOTE130_VERIFY = (
    HERE.parent
    / "legal-wide-single-cycle-productivity-counterexample"
    / "verify_legal_wide_single_cycle_productivity_counterexample.py"
)


def load_module(path, name):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    with contextlib.redirect_stdout(io.StringIO()):
        specification.loader.exec_module(module)
    return module


family = load_module(FAMILY, "fixed_four_parent_family")
note130 = load_module(NOTE130_VERIFY, "fixed_note130_instance")
note110 = family.note110
nx = family.nx
edge = family.edge


def crossing_edges(fibre, surviving):
    sectors = (
        tuple(matching for matching in fibre if surviving not in matching),
        tuple(matching for matching in fibre if surviving in matching),
    )
    crossings = tuple(
        (first, second)
        for first in sectors[0]
        for second in sectors[1]
        if note110.difference_component_count(first, second) == 1
    )
    return sectors, crossings


def analyse_fixed_decoration(
    graph,
    faces,
    parent_matchings,
    child,
    child_faces,
    local,
    child_matchings,
    site,
    root,
    forced,
    surviving,
):
    selected = frozenset(site["selected"])
    parent_fibre = tuple(
        matching
        for matching in parent_matchings
        if note110.is_root_target(graph, matching, root, forced)
    )
    parent_sectors, parent_crossings = crossing_edges(parent_fibre, surviving)
    l11 = frozenset(
        matching for matching in parent_fibre if selected <= matching
    )
    kill_cover = bool(parent_crossings) and bool(l11) and all(
        first in l11 or second in l11
        for first, second in parent_crossings
    )
    record = {
        "parent_fibre_size": len(parent_fibre),
        "parent_sector_sizes": tuple(map(len, parent_sectors)),
        "parent_crossings": len(parent_crossings),
        "L11_size": len(l11),
        "L11_vertex_cover": kill_cover,
    }
    if not kill_cover:
        return record

    child_fibre = tuple(
        matching
        for matching in child_matchings
        if note110.is_root_target(child, matching, root, forced)
    )
    child_sectors, child_crossings = crossing_edges(child_fibre, surviving)
    cells = {
        matching: note110.local_cell(matching, local)
        for matching in child_fibre
    }
    new_cells = {"R00", "Xuy", "Xvx"}
    canonical_cells = {"C00", "C10", "C01"}
    cell_pairs = Counter()
    new_cell_crossings = 0
    canonical_crossings = 0
    for first, second in child_crossings:
        first_cell, second_cell = cells[first], cells[second]
        cell_pairs[f"{first_cell}--{second_cell}"] += 1
        incident_new = first_cell in new_cells or second_cell in new_cells
        new_cell_crossings += int(incident_new)
        canonical_crossings += int(
            first_cell in canonical_cells and second_cell in canonical_cells
        )
    # Note 103(8): under the kill-cover antecedent every child crossing must
    # be incident with a nondirect new cell.
    assert canonical_crossings == 0
    assert new_cell_crossings == len(child_crossings)
    record.update(
        {
            "child_fibre_size": len(child_fibre),
            "child_sector_sizes": tuple(map(len, child_sectors)),
            "child_crossings": len(child_crossings),
            "child_new_cell_crossings": new_cell_crossings,
            "child_crossing_cell_pairs": dict(sorted(cell_pairs.items())),
            "child_cell_histogram": dict(
                sorted(Counter(cells.values()).items())
            ),
        }
    )
    return record


def note130_precheck():
    graph = nx.Graph()
    graph.add_edges_from(note130.PARENT_EDGES)
    faces = note130.embedded_faces(graph)
    site = note130.site_record(faces)
    child, child_faces, local = note110.expand_on_face(graph, faces, site)
    parent_matchings = note110.enumerate_perfect_matchings(graph)
    child_matchings = note110.enumerate_perfect_matchings(child)
    record = analyse_fixed_decoration(
        graph,
        faces,
        parent_matchings,
        child,
        child_faces,
        local,
        child_matchings,
        site,
        note130.ROOT,
        note130.FORCED,
        note130.SURVIVING,
    )
    record.update(
        {
            "root": note130.ROOT,
            "forced_gate": note130.FORCED,
            "surviving_gate": note130.SURVIVING,
            "site_selected": tuple(sorted(note130.SELECTED)),
            "legal_wide_arcs": note110.legal_wide_arcs(
                child_faces,
                note130.ROOT,
                note130.FORCED,
                note130.SURVIVING,
            ),
            "parent_perfect_matchings": len(parent_matchings),
            "child_perfect_matchings": len(child_matchings),
        }
    )
    explicit_child_fibre = tuple(
        matching
        for matching in child_matchings
        if note110.is_root_target(
            child, matching, note130.ROOT, note130.FORCED
        )
    )
    explicit_child_sectors, explicit_child_crossings = crossing_edges(
        explicit_child_fibre, note130.SURVIVING
    )
    explicit_cells = {
        matching: note110.local_cell(matching, local)
        for matching in explicit_child_fibre
    }
    record.update(
        {
            "child_fibre_size_without_antecedent": len(explicit_child_fibre),
            "child_sector_sizes_without_antecedent": tuple(
                map(len, explicit_child_sectors)
            ),
            "child_crossings_without_antecedent": len(explicit_child_crossings),
            "child_crossing_cell_pairs_without_antecedent": dict(
                sorted(
                    Counter(
                        f"{explicit_cells[first]}--{explicit_cells[second]}"
                        for first, second in explicit_child_crossings
                    ).items()
                )
            ),
        }
    )
    # The explicit Note-130 site is a G/P counterexample but not a kill-cover
    # antecedent.  Keep this assertion as a regression check before the full
    # fixed-family classification.
    assert record["parent_crossings"] == 6
    assert record["L11_size"] == 2
    assert not record["L11_vertex_cover"]
    assert record["child_fibre_size_without_antecedent"] == 25
    assert record["child_crossings_without_antecedent"] == 19
    return record


def serial_counterexample(
    parent_type,
    graph,
    faces,
    site,
    decoration,
    orbit_size,
    result,
):
    root, forced, surviving, selected = decoration
    assert result["L11_vertex_cover"]
    assert result["child_crossings"] == 0
    return {
        "parent_type": parent_type,
        "parent_edges": tuple(sorted(edge(*item) for item in graph.edges)),
        "parent_faces": faces,
        "root": root,
        "forced_gate": forced,
        "surviving_gate": surviving,
        "site": {
            "face_index": site["face_index"],
            "face_length": site["face_length"],
            "indices": site["indices"],
            "selected": tuple(sorted(selected)),
        },
        "decoration_orbit_size": orbit_size,
        **result,
    }


def classify_parent_type(type_index, parent_record, stop_on_hit=True):
    graph = parent_record["graph"]
    faces = family.embedded_faces(graph)
    assert note110.lift.verify_brace(graph)
    automorphisms = tuple(
        nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter()
    )
    sites = family.all_sites(graph, faces)
    decorations, geometry_counts, site_children, site_by_selected = (
        family.enumerate_decorations(
            graph, faces, sites, automorphisms
        )
    )
    parent_matchings = note110.enumerate_perfect_matchings(graph)
    decorations_by_site = defaultdict(list)
    for decoration in decorations:
        selected = frozenset(decoration["key"][3])
        decorations_by_site[selected].append(decoration)

    counts = Counter(
        {
            "parent_types": 1,
            "parent_perfect_matchings": len(parent_matchings),
            "legal_wide_decoration_orbits": len(decorations),
            "legal_wide_decorations_raw_labelled": geometry_counts[
                "legal_wide_decorations"
            ],
        }
    )
    crossing_histogram_orbits = Counter()
    crossing_histogram_raw = Counter()
    cell_pair_totals_orbits = Counter()
    cell_pair_totals_raw = Counter()
    first_counterexample = None

    for site_ordinal, selected in enumerate(
        sorted(decorations_by_site, key=lambda value: tuple(sorted(value)))
    ):
        site = site_by_selected[selected]
        child, child_faces, local = site_children[selected]
        child_matchings = note110.enumerate_perfect_matchings(child)
        counts["decorated_sites_examined"] += 1
        for decoration_record in decorations_by_site[selected]:
            decoration = decoration_record["key"]
            root, forced, surviving, _selected = decoration
            orbit_size = decoration_record["orbit_size"]
            result = analyse_fixed_decoration(
                graph,
                faces,
                parent_matchings,
                child,
                child_faces,
                local,
                child_matchings,
                site,
                root,
                forced,
                surviving,
            )
            counts["decorations_examined_orbits"] += 1
            counts["decorations_examined_raw_labelled"] += orbit_size
            if result["parent_crossings"] == 0:
                counts["parent_Gamma_empty_orbits"] += 1
                counts["parent_Gamma_empty_raw_labelled"] += orbit_size
                continue
            counts["parent_Gamma_nonempty_orbits"] += 1
            counts["parent_Gamma_nonempty_raw_labelled"] += orbit_size
            if not result["L11_vertex_cover"]:
                counts["not_kill_cover_orbits"] += 1
                counts["not_kill_cover_raw_labelled"] += orbit_size
                continue

            counts["kill_cover_hits_orbits"] += 1
            counts["kill_cover_hits_raw_labelled"] += orbit_size
            child_crossings = result["child_crossings"]
            crossing_histogram_orbits[child_crossings] += 1
            crossing_histogram_raw[child_crossings] += orbit_size
            for pair, multiplicity in result[
                "child_crossing_cell_pairs"
            ].items():
                cell_pair_totals_orbits[pair] += multiplicity
                cell_pair_totals_raw[pair] += multiplicity * orbit_size
            if child_crossings == 0:
                counts["rooted_split_bond_counterexamples_orbits"] += 1
                counts["rooted_split_bond_counterexamples_raw_labelled"] += orbit_size
                first_counterexample = serial_counterexample(
                    type_index,
                    graph,
                    faces,
                    site,
                    decoration,
                    orbit_size,
                    result,
                )
                if stop_on_hit:
                    break
        if first_counterexample is not None and stop_on_hit:
            break
        print(
            f"parent_type={type_index} decorated_site="
            f"{site_ordinal + 1}/{len(decorations_by_site)}",
            flush=True,
        )

    return {
        "parent_type": type_index,
        "parent_face_histogram": family.face_histogram(faces),
        "parent_perfect_matchings": len(parent_matchings),
        "parent_automorphism_group_order": len(automorphisms),
        "counts": dict(sorted(counts.items())),
        "child_crossing_count_histogram_orbits": dict(
            sorted(crossing_histogram_orbits.items())
        ),
        "child_crossing_count_histogram_raw_labelled": dict(
            sorted(crossing_histogram_raw.items())
        ),
        "child_new_cell_pair_totals_orbits": dict(
            sorted(cell_pair_totals_orbits.items())
        ),
        "child_new_cell_pair_totals_raw_labelled": dict(
            sorted(cell_pair_totals_raw.items())
        ),
        "counterexample": first_counterexample,
    }


def classify(stop_on_hit=True):
    explicit = note130_precheck()
    if explicit["L11_vertex_cover"] and explicit["child_crossings"] == 0:
        raise AssertionError("Note-130 precheck unexpectedly became a counterexample")

    family.cube_oriented_face_transitivity()
    parents = family.enumerate_parent_types()
    records = []
    first_counterexample = None
    for type_index, parent in enumerate(parents):
        record = classify_parent_type(
            type_index, parent, stop_on_hit=stop_on_hit
        )
        records.append(record)
        if record["counterexample"] is not None:
            first_counterexample = record["counterexample"]
            if stop_on_hit:
                break

    complete = len(records) == 4 and first_counterexample is None
    totals = Counter()
    crossing_histogram_orbits = Counter()
    crossing_histogram_raw = Counter()
    cell_pair_totals_orbits = Counter()
    cell_pair_totals_raw = Counter()
    for record in records:
        totals.update(record["counts"])
        crossing_histogram_orbits.update(
            {int(key): value for key, value in record[
                "child_crossing_count_histogram_orbits"
            ].items()}
        )
        crossing_histogram_raw.update(
            {int(key): value for key, value in record[
                "child_crossing_count_histogram_raw_labelled"
            ].items()}
        )
        cell_pair_totals_orbits.update(
            record["child_new_cell_pair_totals_orbits"]
        )
        cell_pair_totals_raw.update(
            record["child_new_cell_pair_totals_raw_labelled"]
        )

    if first_counterexample is not None:
        status = "A_EXPLICIT_ROOTED_SPLIT_BOND_COUNTEREXAMPLE"
    elif complete:
        status = "B_COMPLETE_FIXED_THREE_CUBE_FAMILY_EXCLUDED"
    else:
        status = "C_RESOURCE_LIMIT_UNRESOLVED"
    if complete:
        assert totals["legal_wide_decoration_orbits"] == 437
        assert totals["legal_wide_decorations_raw_labelled"] == 4094
        assert totals["parent_Gamma_nonempty_orbits"] == 437
        assert totals["kill_cover_hits_orbits"] == 62
        assert totals["kill_cover_hits_raw_labelled"] == 690
        assert sum(crossing_histogram_orbits.values()) == 62
        assert sum(crossing_histogram_raw.values()) == 690
        assert 0 not in crossing_histogram_orbits
    return {
        "status": status,
        "scope": {
            "parent_order": 24,
            "parent_isomorphism_types": 4,
            "only_fixed_three_cube_annular_family": True,
            "interface_disjoint_legal_wide_decorations": True,
            "automorphism_reduced": True,
            "complete": complete,
            "no_other_graph_order_or_random_search": True,
        },
        "note130_explicit_site_precheck": explicit,
        "totals": dict(sorted(totals.items())),
        "child_crossing_count_histogram_orbits": dict(
            sorted(crossing_histogram_orbits.items())
        ),
        "child_crossing_count_histogram_raw_labelled": dict(
            sorted(crossing_histogram_raw.items())
        ),
        "child_new_cell_pair_totals_orbits": dict(
            sorted(cell_pair_totals_orbits.items())
        ),
        "child_new_cell_pair_totals_raw_labelled": dict(
            sorted(cell_pair_totals_raw.items())
        ),
        "parent_types": records,
        "counterexample": first_counterexample,
    }


def main():
    payload = classify(stop_on_hit=True)
    output = HERE / "three_cube_rooted_split_bond.json"
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print("status", payload["status"])
    print("totals", json.dumps(payload["totals"], sort_keys=True))
    print(
        "child_crossing_histogram_orbits",
        json.dumps(payload["child_crossing_count_histogram_orbits"], sort_keys=True),
    )
    print("output", output)


if __name__ == "__main__":
    main()
