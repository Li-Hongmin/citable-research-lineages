#!/usr/bin/env python3
"""Stop at the first parent-PM-only delta-state support failure.

This verifier consumes the frozen four-parent support module of Note 131.
It does not add two-defect near-perfect rows to the state.
"""

from __future__ import annotations

from collections import Counter
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
SUPPORT = HERE / "three_cube_annular_family_support.py"


def load_support():
    spec = importlib.util.spec_from_file_location(
        "note131_frozen_family_support", SUPPORT
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules["note131_frozen_family_support"] = module
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(module)
    return module


support = load_support()
note110 = support.note110
nx = support.nx
edge = support.edge


def cell_patterns(local):
    ua, ab, bv, xc, cd, dy, ad, bc = local
    return {
        "C00": frozenset((ad, bc)),
        "C10": frozenset((ua, bv, cd)),
        "C01": frozenset((xc, dy, ab)),
        "C11": frozenset((ua, bv, xc, dy)),
        "R00": frozenset((ab, cd)),
        "Xuy": frozenset((ua, bc, dy)),
        "Xvx": frozenset((ad, bv, xc)),
    }


def restriction_defects(parent_vertices, exterior_matching):
    covered = {vertex for item in exterior_matching for vertex in item}
    return tuple(sorted(set(parent_vertices) - covered))


def main():
    # Consume the frozen family in its canonical order and stop at its first
    # decoration orbit.  No fifth parent or neighbouring graph is generated.
    parents = support.enumerate_parent_types()
    assert len(parents) == 4
    graph = parents[0]["graph"]
    faces = support.embedded_faces(graph)
    assert support.face_histogram(faces) == {4: 10, 8: 4}
    automorphisms = tuple(
        nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter()
    )
    decorations, _geometry, site_children, site_by_selected = (
        support.enumerate_decorations(
            graph, faces, support.all_sites(graph, faces), automorphisms
        )
    )
    first = min(decorations, key=lambda record: record["key"])
    root, forced, surviving, selected_tuple = first["key"]
    selected = frozenset(selected_tuple)
    site = site_by_selected[selected]
    child, child_faces, local = site_children[selected]
    patterns = cell_patterns(local)

    parent_matchings = note110.enumerate_perfect_matchings(graph)
    child_matchings = note110.enumerate_perfect_matchings(child)
    child_cells = {
        matching: note110.local_cell(matching, local)
        for matching in child_matchings
    }
    direct_cell_histogram = Counter(child_cells.values())

    # A parent PM row restricts outside p,q to exactly one of four defect
    # sets: empty, the endpoints of p, the endpoints of q, or all four.
    # Canonical cells use all four cases; R00 reuses state 00.  No X row is
    # inserted here.
    reconstructed = set()
    parent_defect_histogram = Counter()
    parent_exteriors = set()
    first_selected, second_selected = site["selected"]
    for matching in parent_matchings:
        exterior = matching - selected
        parent_exteriors.add(exterior)
        defects = restriction_defects(graph, exterior)
        parent_defect_histogram[defects] += 1
        state = (
            int(first_selected in matching),
            int(second_selected in matching),
        )
        canonical_cell = {
            (0, 0): "C00",
            (1, 0): "C10",
            (0, 1): "C01",
            (1, 1): "C11",
        }[state]
        reconstructed.add(frozenset(exterior | patterns[canonical_cell]))
        if state == (0, 0):
            reconstructed.add(frozenset(exterior | patterns["R00"]))

    assert reconstructed <= set(child_matchings)
    reconstructed_cells = {
        matching: child_cells[matching] for matching in reconstructed
    }
    reconstructed_cell_histogram = Counter(reconstructed_cells.values())
    missing = tuple(
        sorted(
            set(child_matchings) - reconstructed,
            key=lambda matching: tuple(sorted(matching)),
        )
    )
    missing_cell_histogram = Counter(child_cells[matching] for matching in missing)

    expected_parent_defects = {
        (),
        tuple(sorted(first_selected)),
        tuple(sorted(second_selected)),
        tuple(sorted(set(first_selected) | set(second_selected))),
    }
    assert set(parent_defect_histogram) == expected_parent_defects
    assert direct_cell_histogram == {
        "C00": 97,
        "C10": 20,
        "C01": 41,
        "C11": 68,
        "R00": 97,
        "Xuy": 76,
        "Xvx": 76,
    }
    assert reconstructed_cell_histogram == {
        "C00": 97,
        "C10": 20,
        "C01": 41,
        "C11": 68,
        "R00": 97,
    }
    assert missing_cell_histogram == {"Xuy": 76, "Xvx": 76}

    child_fibre = tuple(
        matching
        for matching in child_matchings
        if note110.is_root_target(child, matching, root, forced)
    )
    reconstructed_fibre = frozenset(child_fibre) & reconstructed
    missing_rooted = tuple(
        sorted(
            set(child_fibre) - reconstructed_fibre,
            key=lambda matching: tuple(sorted(matching)),
        )
    )
    assert Counter(child_cells[matching] for matching in child_fibre) == {
        "C00": 5,
        "C10": 1,
        "R00": 7,
        "Xuy": 7,
        "Xvx": 7,
    }
    assert Counter(child_cells[matching] for matching in missing_rooted) == {
        "Xuy": 7,
        "Xvx": 7,
    }

    first_missing = {}
    local_set = frozenset(local)
    for cell in ("Xuy", "Xvx"):
        matching = next(
            matching
            for matching in missing_rooted
            if child_cells[matching] == cell
        )
        exterior = matching - local_set
        defects = restriction_defects(graph, exterior)
        assert exterior not in parent_exteriors
        first_missing[cell] = {
            "child_matching": tuple(sorted(matching)),
            "exterior_near_perfect_row": tuple(sorted(exterior)),
            "defect_vertices": defects,
            "has_parent_PM_ancestor": False,
        }

    ua, _ab, bv, xc, _cd, dy, _ad, _bc = local
    old_vertices = set(graph)
    u = next(vertex for vertex in ua if vertex in old_vertices)
    v = next(vertex for vertex in bv if vertex in old_vertices)
    x = next(vertex for vertex in xc if vertex in old_vertices)
    y = next(vertex for vertex in dy if vertex in old_vertices)
    cross_defects = {
        tuple(sorted((u, y))),
        tuple(sorted((v, x))),
    }
    assert {
        tuple(record["defect_vertices"])
        for record in first_missing.values()
    } == cross_defects
    assert not (cross_defects & set(parent_defect_histogram))

    payload = {
        "status": "STRICT_INFORMATION_INSUFFICIENCY_AT_FIRST_DECORATION",
        "scope": {
            "frozen_parent_types_available": 4,
            "decoration_orbits_available": 437,
            "parent_types_examined": 1,
            "decoration_orbits_examined": 1,
            "stopped_at_first_collision": True,
            "no_two_defect_rows_added": True,
        },
        "first_decoration": {
            "parent_face_histogram": support.face_histogram(faces),
            "parent_perfect_matchings": len(parent_matchings),
            "root": root,
            "forced_gate": forced,
            "surviving_gate": surviving,
            "site": site,
            "orbit_size": first["orbit_size"],
            "local_edges": local,
        },
        "parent_PM_restriction_defect_histogram": {
            str(key): value for key, value in sorted(parent_defect_histogram.items())
        },
        "direct_child": {
            "perfect_matchings": len(child_matchings),
            "cell_histogram": dict(sorted(direct_cell_histogram.items())),
            "rooted_fibre": len(child_fibre),
            "rooted_cell_histogram": dict(
                sorted(Counter(child_cells[m] for m in child_fibre).items())
            ),
        },
        "parent_PM_only_reconstruction": {
            "perfect_matchings": len(reconstructed),
            "cell_histogram": dict(
                sorted(reconstructed_cell_histogram.items())
            ),
            "rooted_fibre": len(reconstructed_fibre),
            "missing_cell_histogram": dict(sorted(missing_cell_histogram.items())),
            "missing_rooted_cell_histogram": dict(
                sorted(Counter(child_cells[m] for m in missing_rooted).items())
            ),
        },
        "first_missing_rows": first_missing,
        "missing_datum": (
            "joint support of two-defect exterior near-perfect rows with "
            "cross defect sets {u,y} and {v,x}; no parent perfect-matching "
            "row has either restriction"
        ),
        "not_tested_after_stop": (
            "full 437-orbit agreement and 62-hit supplementation reconstruction"
        ),
    }
    output = HERE / "parent_pm_only_state_collision.json"
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print("status", payload["status"])
    print("decoration", payload["first_decoration"])
    print("parent_defects", payload["parent_PM_restriction_defect_histogram"])
    print("direct_child", payload["direct_child"])
    print("parent_PM_only", payload["parent_PM_only_reconstruction"])
    print("first_missing_rows", payload["first_missing_rows"])
    print("output", output)


if __name__ == "__main__":
    main()
