#!/usr/bin/env python3
"""Exhaust the fixed order-24 three-cube annular-splice family.

The first splice is normalized by the cube automorphism group.  The second
splice is then enumerated over every surviving middle-cube facial square,
both opposite-edge pairs, every third-cube face and opposite-edge pair, and
all four cyclic noncrossing port identifications.  Isomorphic parent graphs
and decorated endpoints are reduced by exact NetworkX isomorphisms.

Only after plane-brace and legal-wide filtering are complete are perfect
matchings enumerated.  Matchings are streamed one expanded site at a time.
"""

from __future__ import annotations

from collections import Counter, defaultdict
import argparse
import contextlib
import importlib.util
import io
from itertools import combinations
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
NOTE128 = (
    BARNETTE
    / "computations/bundles/good-sibling-portal-dichotomy"
    / "verify_frozen_good_sibling_portal_dichotomy.py"
)


def load_note128():
    spec = importlib.util.spec_from_file_location(
        "three_cube_family_note128", NOTE128
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules["three_cube_family_note128"] = module
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(module)
    return module


bundle = load_note128()
note110 = bundle.note110
nx = bundle.nx
edge = note110.edge


def cube_edges(offset: int):
    return {
        edge(offset + vertex, offset + (vertex ^ bit))
        for vertex in range(8)
        for bit in (1, 2, 4)
        if vertex < (vertex ^ bit)
    }


def embedded_faces(graph):
    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    faces = note110.source.plane_faces(graph, embedding)
    note110.validate_faces(graph, faces)
    return faces


def map_edge(item, automorphism):
    return edge(automorphism[item[0]], automorphism[item[1]])


def face_histogram(faces):
    return dict(sorted(Counter(map(len, faces)).items()))


def cube_oriented_face_transitivity():
    """Verify the normalization used for the first splice.

    A face, an opposite-edge pair, and a choice of cyclic port origin/direction
    are equivalently encoded by an oriented facial 4-cycle.  The 48 cube
    automorphisms send one fixed oriented facial cycle to all 6*8=48 such
    cycles.
    """
    graph = nx.Graph()
    graph.add_edges_from(cube_edges(0))
    faces = embedded_faces(graph)
    target = faces[0]
    automorphisms = tuple(
        nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter()
    )
    images = {
        tuple(automorphism[vertex] for vertex in target)
        for automorphism in automorphisms
    }
    oriented_faces = set()
    for face in faces:
        for shift in range(4):
            rotated = face[shift:] + face[:shift]
            oriented_faces.add(rotated)
            oriented_faces.add(tuple(reversed(rotated)))
    assert len(automorphisms) == len(images) == len(oriented_faces) == 48
    assert images == oriented_faces
    return len(automorphisms)


def fixed_first_splice():
    graph = nx.Graph()
    graph.add_nodes_from(range(16))
    edges = cube_edges(0) | cube_edges(8)
    edges -= {(0, 1), (2, 3), (8, 9), (10, 11)}
    edges |= {(0, 9), (1, 8), (3, 10), (2, 11)}
    graph.add_edges_from(edges)
    assert nx.is_bipartite(graph) and nx.check_planarity(graph)[0]
    return graph


def opposite_pair(face, parity):
    assert len(face) == 4 and parity in (0, 1)
    return frozenset(
        {
            edge(face[parity], face[(parity + 1) % 4]),
            edge(face[(parity + 2) % 4], face[(parity + 3) % 4]),
        }
    )


def graph_isomorphism_index(graph, representatives):
    for index, record in enumerate(representatives):
        representative = record["graph"]
        if nx.is_isomorphic(graph, representative):
            return index
    return None


def enumerate_parent_types():
    first = fixed_first_splice()
    first_faces = embedded_faces(first)
    middle_squares = tuple(
        face
        for face in first_faces
        if len(face) == 4 and set(face) <= set(range(8, 16))
    )
    assert len(middle_squares) == 3

    third = nx.Graph()
    third.add_edges_from(cube_edges(16))
    third_faces = embedded_faces(third)
    representatives = []
    raw = 0
    for middle_face in middle_squares:
        for middle_parity in (0, 1):
            middle_deleted = opposite_pair(middle_face, middle_parity)
            for third_face in third_faces:
                for third_parity in (0, 1):
                    third_deleted = opposite_pair(third_face, third_parity)
                    for shift in range(4):
                        raw += 1
                        graph = nx.Graph()
                        graph.add_nodes_from(range(24))
                        graph.add_edges_from(first.edges)
                        graph.add_edges_from(cube_edges(16))
                        graph.remove_edges_from(middle_deleted | third_deleted)
                        graph.add_edges_from(
                            (middle_face[index], third_face[(index + shift) % 4])
                            for index in range(4)
                        )
                        assert nx.is_bipartite(graph)
                        assert nx.check_planarity(graph)[0]
                        parameters = {
                            "middle_face": middle_face,
                            "middle_opposite_pair": middle_parity,
                            "third_face": third_face,
                            "third_opposite_pair": third_parity,
                            "port_shift": shift,
                        }
                        type_index = graph_isomorphism_index(graph, representatives)
                        if type_index is None:
                            representatives.append(
                                {
                                    "graph": graph,
                                    "parameters": [parameters],
                                }
                            )
                        else:
                            representatives[type_index]["parameters"].append(parameters)
    assert raw == 288
    assert len(representatives) == 4
    assert sorted(len(record["parameters"]) for record in representatives) == [72] * 4
    return representatives


def all_sites(graph, faces):
    """All bipartite C4 expansions on two disjoint cofacial old edges."""
    seen = set()
    records = []
    for face_index, face in enumerate(faces):
        boundary = note110.face_edges(face)
        degree = len(face)
        for first_index, second_index in combinations(range(degree), 2):
            distance = second_index - first_index
            if distance in (1, degree - 1) or distance % 2:
                continue
            selected = (boundary[first_index], boundary[second_index])
            key = frozenset(selected)
            if key in seen:
                continue
            seen.add(key)
            records.append(
                {
                    "face_index": face_index,
                    "face_length": degree,
                    "indices": (first_index, second_index),
                    "selected": selected,
                }
            )
    return tuple(records)


def site_vertices(site):
    return frozenset(vertex for item in site["selected"] for vertex in item)


def decoration_key(root, forced, surviving, selected):
    return root, forced, surviving, tuple(sorted(selected))


def map_decoration(key, automorphism):
    root, forced, surviving, selected = key
    return decoration_key(
        map_edge(root, automorphism),
        map_edge(forced, automorphism),
        map_edge(surviving, automorphism),
        (map_edge(item, automorphism) for item in selected),
    )


def enumerate_decorations(graph, faces, sites, automorphisms):
    """Return every raw legal-wide decoration and its automorphism orbits."""
    graph_edges = frozenset(edge(*item) for item in graph.edges)
    squares = tuple(face for face in faces if len(face) == 4)
    raw_counts = Counter()
    raw_keys = set()
    site_children = {}
    site_by_selected = {
        frozenset(site["selected"]): site for site in sites
    }

    for site in sites:
        selected = frozenset(site["selected"])
        selected_vertices = site_vertices(site)
        child, child_faces, local = note110.expand_on_face(graph, faces, site)
        child_brace = bool(note110.lift.verify_brace(child))
        raw_counts["sites"] += 1
        raw_counts["brace_sites"] += int(child_brace)
        assert child_brace
        site_children[selected] = (child, child_faces, local)

        for square in squares:
            if selected_vertices & set(square):
                continue
            boundary = note110.face_edges(square)
            for index in range(4):
                root = boundary[index]
                forced = boundary[(index + 2) % 4]
                raw_counts["interface_disjoint_root_forced_site"] += 1
                for surviving in graph_edges - {root, forced} - selected:
                    raw_counts["surviving_edge_trials"] += 1
                    if selected_vertices & set(surviving):
                        raw_counts["surviving_touches_site"] += 1
                        continue
                    arcs = note110.legal_wide_arcs(
                        child_faces, root, forced, surviving
                    )
                    if arcs is None:
                        raw_counts["not_legal_wide"] += 1
                        continue
                    raw_counts["legal_wide_decorations"] += 1
                    raw_keys.add(
                        decoration_key(root, forced, surviving, selected)
                    )
    assert len(raw_keys) == raw_counts["legal_wide_decorations"]

    orbit_records = {}
    for key in raw_keys:
        canonical = min(map_decoration(key, item) for item in automorphisms)
        if canonical not in orbit_records:
            orbit = {
                map_decoration(canonical, item) for item in automorphisms
            }
            assert orbit <= raw_keys
            orbit_records[canonical] = {
                "key": canonical,
                "orbit_size": len(orbit),
            }
    assert sum(record["orbit_size"] for record in orbit_records.values()) == len(raw_keys)
    return (
        tuple(orbit_records[key] for key in sorted(orbit_records)),
        raw_counts,
        site_children,
        site_by_selected,
    )


def matching_key(matching):
    return tuple(sorted(matching))


def map_matching(matching, automorphism):
    return frozenset(map_edge(item, automorphism) for item in matching)


def endpoint_orbit_representatives(matchings, stabilizer):
    remaining = set(matchings)
    representatives = []
    while remaining:
        representative = min(remaining, key=matching_key)
        orbit = {
            map_matching(representative, automorphism)
            for automorphism in stabilizer
        }
        assert orbit <= set(matchings)
        remaining -= orbit
        representatives.append((representative, len(orbit)))
    return tuple(representatives)


def classify_endpoint(
    graph,
    faces,
    parent_matchings,
    parent_fibre,
    child,
    child_faces,
    local,
    child_matchings,
    root,
    forced,
    surviving,
    selected,
    chi,
    site,
):
    parent_fibre_set = frozenset(parent_fibre)
    child_fibre = tuple(
        matching
        for matching in child_matchings
        if note110.is_root_target(child, matching, root, forced)
    )
    child_fibre_set = frozenset(child_fibre)
    cells = {
        matching: note110.local_cell(matching, local)
        for matching in child_fibre
    }
    direct = bundle.direct_lifts(
        chi, faces[site["face_index"]], site, local
    )
    canonical_admissible = tuple(
        cell for cell, matching in direct.items() if matching in child_fibre_set
    )
    if canonical_admissible:
        return {
            "failure": "direct_lift_not_sterile",
            "canonical_admissible": canonical_admissible,
        }

    sector = surviving in chi
    mixed = tuple(
        matching
        for matching in parent_fibre
        if (surviving in matching) != sector
        and not selected <= matching
        and note110.difference_component_count(chi, matching) == 1
    )
    if not mixed:
        return {"failure": "M_empty", "M": 0}

    escapes = tuple(
        matching
        for matching in parent_fibre
        if (surviving in matching) == sector
        and not selected <= matching
        and note110.difference_component_count(chi, matching) == 1
    )
    if escapes:
        return {"failure": "E_nonempty", "M": len(mixed), "E": len(escapes)}

    targets = tuple(
        matching
        for matching in child_fibre
        if (surviving in matching) == sector
        and cells[matching] in {"R00", "Xuy", "Xvx"}
    )
    if not targets:
        return {"failure": "X_empty", "M": len(mixed), "E": 0, "X": 0}

    retained = frozenset(edge(*item) for item in graph.edges) - selected
    old_supports = tuple(target & retained for target in targets)
    good = tuple(
        (mixed_index, target_index)
        for mixed_index, matching in enumerate(mixed)
        for target_index, old in enumerate(old_supports)
        if old <= ((chi | matching) & retained)
    )

    labelled = frozenset({root, forced, surviving})
    same_label_nonrooted = tuple(
        matching
        for matching in parent_matchings
        if root in matching
        and forced in matching
        and (surviving in matching) == sector
        and matching not in parent_fibre_set
    )
    phase_portals = tuple(
        matching
        for matching in same_label_nonrooted
        if selected <= (matching ^ chi)
        and not ((matching ^ chi) & labelled)
        and not (selected & matching)
        and note110.difference_component_count(chi, matching) == 1
    )
    productive_portals = tuple(
        (portal_index, target_index)
        for portal_index, matching in enumerate(phase_portals)
        for target_index, old in enumerate(old_supports)
        if old <= ((chi | matching) & retained)
    )
    return {
        "failure": (
            "REAL_COUNTEREXAMPLE" if not good and not productive_portals
            else "G_or_P_positive"
        ),
        "sector": int(sector),
        "M": len(mixed),
        "E": 0,
        "X": len(targets),
        "X_cells": dict(sorted(Counter(cells[item] for item in targets).items())),
        "G_incidences": len(good),
        "phase_portals": len(phase_portals),
        "P_incidences": len(productive_portals),
    }


def serial_decoration(key):
    root, forced, surviving, selected = key
    return {
        "root": root,
        "forced_gate": forced,
        "surviving_gate": surviving,
        "site_selected": selected,
    }


def classify_type(type_index, parent_record, stop_on_hit=True):
    graph = parent_record["graph"]
    faces = embedded_faces(graph)
    assert note110.lift.verify_brace(graph)
    automorphisms = tuple(
        nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter()
    )
    sites = all_sites(graph, faces)
    decorations, geometry_counts, site_children, site_by_selected = (
        enumerate_decorations(graph, faces, sites, automorphisms)
    )
    parent_matchings = note110.enumerate_perfect_matchings(graph)
    parent_fibre_cache = {}
    endpoint_counts = Counter()
    endpoint_raw_within_decoration_orbits = Counter()
    counterexample = None

    decorations_by_site = defaultdict(list)
    for decoration in decorations:
        selected = frozenset(decoration["key"][3])
        decorations_by_site[selected].append(decoration)

    for site_ordinal, selected in enumerate(sorted(decorations_by_site, key=lambda x: tuple(sorted(x)))):
        site = site_by_selected[selected]
        child, child_faces, local = site_children[selected]
        child_matchings = note110.enumerate_perfect_matchings(child)
        for decoration in decorations_by_site[selected]:
            key = decoration["key"]
            root, forced, surviving, _selected_tuple = key
            fibre_key = (root, forced)
            if fibre_key not in parent_fibre_cache:
                parent_fibre_cache[fibre_key] = tuple(
                    matching
                    for matching in parent_matchings
                    if note110.is_root_target(graph, matching, root, forced)
                )
            parent_fibre = parent_fibre_cache[fibre_key]
            l11 = tuple(matching for matching in parent_fibre if selected <= matching)
            if not l11:
                endpoint_counts["decorations_with_L11_empty"] += 1
                continue
            endpoint_counts["decorations_with_L11_nonempty"] += 1
            stabilizer = tuple(
                automorphism
                for automorphism in automorphisms
                if map_decoration(key, automorphism) == key
            )
            endpoint_orbits = endpoint_orbit_representatives(l11, stabilizer)
            endpoint_counts["L11_endpoint_orbits"] += len(endpoint_orbits)
            endpoint_raw_within_decoration_orbits["L11_endpoints"] += len(l11)

            for chi, chi_orbit_size in endpoint_orbits:
                result = classify_endpoint(
                    graph,
                    faces,
                    parent_matchings,
                    parent_fibre,
                    child,
                    child_faces,
                    local,
                    child_matchings,
                    root,
                    forced,
                    surviving,
                    selected,
                    chi,
                    site,
                )
                endpoint_counts[result["failure"]] += 1
                endpoint_raw_within_decoration_orbits[result["failure"]] += chi_orbit_size
                if result["failure"] == "REAL_COUNTEREXAMPLE":
                    counterexample = {
                        "parent_type": type_index,
                        "parent_edges": tuple(sorted(edge(*item) for item in graph.edges)),
                        "parent_faces": faces,
                        "parent_perfect_matchings": len(parent_matchings),
                        "child_perfect_matchings": len(child_matchings),
                        "decoration": serial_decoration(key),
                        "decoration_orbit_size": decoration["orbit_size"],
                        "chi_matching": tuple(sorted(chi)),
                        "chi_orbit_size_in_stabilizer": chi_orbit_size,
                        "legal_wide_arcs": note110.legal_wide_arcs(
                            child_faces, root, forced, surviving
                        ),
                        "child_brace": bool(note110.lift.verify_brace(child)),
                        **result,
                    }
                    if stop_on_hit:
                        break
            if counterexample is not None and stop_on_hit:
                break
        if counterexample is not None and stop_on_hit:
            break
        print(
            f"type={type_index} decorated_site={site_ordinal + 1}/"
            f"{len(decorations_by_site)}",
            flush=True,
        )

    return {
        "parent_type": type_index,
        "operation_multiplicity_after_first_normalization": len(parent_record["parameters"]),
        "representative_operation": parent_record["parameters"][0],
        "parent_edges": tuple(sorted(edge(*item) for item in graph.edges)),
        "parent_face_histogram": face_histogram(faces),
        "parent_node_connectivity": nx.node_connectivity(graph),
        "parent_brace": bool(note110.lift.verify_brace(graph)),
        "parent_perfect_matchings": len(parent_matchings),
        "automorphism_group_order": len(automorphisms),
        "geometry_counts_raw_labelled": dict(sorted(geometry_counts.items())),
        "legal_wide_decoration_orbits": len(decorations),
        "endpoint_orbit_earliest_failure": dict(sorted(endpoint_counts.items())),
        "endpoint_raw_within_decoration_orbits": dict(
            sorted(endpoint_raw_within_decoration_orbits.items())
        ),
        "counterexample": counterexample,
    }


def classify(stop_on_hit=True):
    cube_automorphisms = cube_oriented_face_transitivity()
    parents = enumerate_parent_types()
    records = []
    counterexample = None
    for type_index, parent in enumerate(parents):
        record = classify_type(type_index, parent, stop_on_hit=stop_on_hit)
        records.append(record)
        if record["counterexample"] is not None:
            counterexample = record["counterexample"]
            if stop_on_hit:
                break
    complete = len(records) == len(parents) and counterexample is None
    return {
        "status": (
            "REAL_LEGAL_WIDE_THREE_CUBE_COUNTEREXAMPLE"
            if counterexample is not None
            else "COMPLETE_FIXED_THREE_CUBE_FAMILY_EXCLUDED"
        ),
        "scope": {
            "factors": "exactly three cubes",
            "parent_order": 24,
            "first_splice_normalized_by_cube_automorphisms": True,
            "cube_automorphism_group_order": cube_automorphisms,
            "second_splice_raw_parameters": 288,
            "parent_isomorphism_types": 4,
            "sites": "all interface-disjoint cofacial bipartite C4 expansions, square and nonsquare",
            "decorations": "all facial root/opposite-forced squares and every surviving gate giving a legal-wide child",
            "complete": complete,
            "not_claimed": "other factors, other orders, random samples, or adjacent operation families",
        },
        "parent_types": records,
        "counterexample": counterexample,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=HERE / "three_cube_annular_family.json",
    )
    parser.add_argument(
        "--continue-after-hit",
        action="store_true",
        help="finish all four types even if a genuine counterexample is found",
    )
    arguments = parser.parse_args()
    result = classify(stop_on_hit=not arguments.continue_after_hit)
    arguments.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print("status", result["status"])
    print("output", arguments.output)


if __name__ == "__main__":
    main()
