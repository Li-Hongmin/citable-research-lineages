#!/usr/bin/env python3
"""Verify the corrected exterior-row delta/epsilon state on one decoration.

Scope is the first collision decoration only.  The parent graph and labels
are frozen literally, so this script does not enumerate another decoration
or parent type.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from functools import lru_cache
import contextlib
import importlib.util
import io
import json
from itertools import combinations
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
SUPPORT = HERE / "three_cube_annular_family_support.py"


def load_support():
    spec = importlib.util.spec_from_file_location(
        "corrected_state_note131_support", SUPPORT
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules["corrected_state_note131_support"] = module
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(module)
    return module


support = load_support()
note110 = support.note110
nx = support.nx
edge = support.edge


PARENT_EDGES = frozenset(
    {
        (0, 2), (0, 4), (0, 9), (1, 3), (1, 5), (1, 8),
        (2, 6), (2, 11), (3, 7), (3, 10), (4, 5), (4, 6),
        (5, 7), (6, 7), (8, 12), (8, 16), (9, 11), (9, 13),
        (10, 14), (10, 18), (11, 15), (12, 13), (12, 20),
        (13, 15), (14, 15), (14, 22), (16, 17), (16, 20),
        (17, 19), (17, 21), (18, 19), (18, 22), (19, 23),
        (20, 21), (21, 23), (22, 23),
    }
)
ROOT = (0, 4)
FORCED = (2, 6)
SURVIVING = (10, 14)
SELECTED = frozenset({(5, 7), (1, 3)})


def enumerate_exterior_rows(graph, removed_edges, defects):
    """Perfect match the old vertices outside a prescribed defect set."""
    vertices = tuple(sorted(set(graph) - set(defects)))
    position = {vertex: index for index, vertex in enumerate(vertices)}
    neighbours = [0] * len(vertices)
    for left, right in graph.edges:
        item = edge(left, right)
        if item in removed_edges or left not in position or right not in position:
            continue
        neighbours[position[left]] |= 1 << position[right]
        neighbours[position[right]] |= 1 << position[left]

    @lru_cache(maxsize=None)
    def solve(mask):
        if mask == 0:
            return ((),)
        candidates = [index for index in range(len(vertices)) if mask >> index & 1]
        first = min(
            candidates,
            key=lambda index: (neighbours[index] & mask).bit_count(),
        )
        choices = neighbours[first] & mask
        remainder = mask ^ (1 << first)
        rows = []
        while choices:
            bit = choices & -choices
            choices ^= bit
            second = bit.bit_length() - 1
            for suffix in solve(remainder ^ bit):
                rows.append(((first, second),) + suffix)
        return tuple(rows)

    encoded = solve((1 << len(vertices)) - 1)
    return tuple(
        frozenset(edge(vertices[left], vertices[right]) for left, right in row)
        for row in encoded
    )


def patch_patterns(local):
    ua, ab, bv, xc, cd, dy, ad, bc = local
    return {
        "C00": frozenset((ad, bc)),
        "C10": frozenset((ua, bv, cd)),
        "C01": frozenset((xc, dy, ab)),
        "C11": frozenset((ua, bv, xc, dy)),
        "R00": frozenset((ab, cd)),
        "Xuy": frozenset((ua, bc, dy)),
        "Xvx": frozenset((ad, bv, xc)),
    }


def token_vertices(boundary):
    u, v, x, y = boundary
    return {
        "B_u": u,
        "B_v": v,
        "B_x": x,
        "B_y": y,
        "R_0": ROOT[0],
        "R_1": ROOT[1],
        "G_0": SURVIVING[0],
        "G_1": SURVIVING[1],
    }


def component_profile(vertices, edges, boundary, include_isolates):
    """Encode marked boundary components and residual closed components."""
    graph = nx.Graph()
    if include_isolates:
        graph.add_nodes_from(vertices)
    graph.add_edges_from(edges)
    components = tuple(nx.connected_components(graph))
    component_of = {
        vertex: index
        for index, component in enumerate(components)
        for vertex in component
    }
    tokens_by_vertex = defaultdict(list)
    for token, vertex in token_vertices(boundary).items():
        tokens_by_vertex[vertex].append(token)

    blocks = defaultdict(list)
    inactive = []
    for vertex, tokens in tokens_by_vertex.items():
        if vertex in component_of:
            blocks[component_of[vertex]].extend(tokens)
        else:
            inactive.append(tuple(sorted(tokens)))
    residual_closed = sum(
        not blocks[index] for index in range(len(components))
    )
    active_blocks = tuple(
        sorted(
            tuple(sorted(tokens))
            for tokens in blocks.values()
            if tokens
        )
    )
    inactive_blocks = tuple(sorted(inactive))
    return active_blocks, inactive_blocks, residual_closed


class UnionFind:
    def __init__(self):
        self.parent = {}
        self.active = {}

    def add(self, item, active=False):
        if item not in self.parent:
            self.parent[item] = item
            self.active[item] = active

    def find(self, item):
        root = item
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[item] != item:
            parent = self.parent[item]
            self.parent[item] = root
            item = parent
        return root

    def union(self, first, second, activate=False):
        self.add(first)
        self.add(second)
        left, right = self.find(first), self.find(second)
        if left != right:
            self.parent[right] = left
            self.active[left] = self.active[left] or self.active[right]
        if activate:
            self.active[self.find(left)] = True


def glue_profile(profile, patch_edges, boundary, include_all_active):
    active_blocks, inactive_blocks, residual_closed = profile
    union = UnionFind()
    token_node = {}
    for ordinal, tokens in enumerate(active_blocks):
        node = ("A", ordinal)
        union.add(node, active=True)
        for token in tokens:
            token_node[token] = node
    for ordinal, tokens in enumerate(inactive_blocks):
        node = ("I", ordinal)
        union.add(node, active=False)
        for token in tokens:
            token_node[token] = node

    boundary_tokens = dict(zip(boundary, ("B_u", "B_v", "B_x", "B_y"), strict=True))

    def node_for_vertex(vertex):
        if vertex in boundary_tokens:
            return token_node[boundary_tokens[vertex]]
        node = ("N", vertex)
        union.add(node, active=include_all_active)
        return node

    for left, right in patch_edges:
        union.union(
            node_for_vertex(left), node_for_vertex(right), activate=True
        )
    roots = {
        union.find(node)
        for node in union.parent
        if union.active[union.find(node)]
    }
    component_count = residual_closed + len(roots)
    root_nodes = (
        union.find(token_node["R_0"]),
        union.find(token_node["R_1"]),
    )
    return component_count, root_nodes[0] != root_nodes[1]


def matching_key(matching):
    return tuple(sorted(matching))


def main():
    parent = nx.Graph()
    parent.add_edges_from(PARENT_EDGES)
    faces = support.embedded_faces(parent)
    site = next(
        record
        for record in support.all_sites(parent, faces)
        if frozenset(record["selected"]) == SELECTED
    )
    child, child_faces, local = note110.expand_on_face(parent, faces, site)
    patterns = patch_patterns(local)
    ua, _ab, bv, xc, _cd, dy, _ad, _bc = local
    old_vertices = set(parent)
    u = next(vertex for vertex in ua if vertex in old_vertices)
    v = next(vertex for vertex in bv if vertex in old_vertices)
    x = next(vertex for vertex in xc if vertex in old_vertices)
    y = next(vertex for vertex in dy if vertex in old_vertices)
    boundary = (u, v, x, y)
    assert set(boundary) == {1, 3, 5, 7}

    defect_by_cell = {
        "C00": (),
        "C10": tuple(sorted((u, v))),
        "C01": tuple(sorted((x, y))),
        "C11": tuple(sorted(boundary)),
        "R00": (),
        "Xuy": tuple(sorted((u, y))),
        "Xvx": tuple(sorted((v, x))),
    }
    exterior_cache = {
        defects: enumerate_exterior_rows(parent, SELECTED, defects)
        for defects in set(defect_by_cell.values())
    }
    assert {key: len(value) for key, value in exterior_cache.items()} == {
        (): 97,
        (5, 7): 20,
        (1, 3): 41,
        (1, 3, 5, 7): 68,
        (1, 5): 76,
        (3, 7): 76,
    }

    rows = []
    reconstructed = set()
    old_edges = frozenset(edge(*item) for item in parent.edges) - SELECTED
    local_set = frozenset(local)
    for cell, pattern in patterns.items():
        for exterior in exterior_cache[defect_by_cell[cell]]:
            matching = frozenset(exterior | pattern)
            assert matching not in reconstructed
            reconstructed.add(matching)
            complement_components = component_profile(
                tuple(parent), old_edges - exterior, boundary, True
            )
            label_bits = (
                int(ROOT in exterior),
                int(FORCED in exterior),
                int(SURVIVING in exterior),
            )
            delta_state = (
                defect_by_cell[cell], label_bits, complement_components
            )
            complement_patch = local_set - pattern
            component_count, root_separated = glue_profile(
                complement_components,
                complement_patch,
                boundary,
                include_all_active=True,
            )
            root_admissible = bool(
                label_bits[0]
                and label_bits[1]
                and component_count == 2
                and root_separated
            )
            rows.append(
                {
                    "matching": matching,
                    "exterior": exterior,
                    "cell": cell,
                    "delta": delta_state,
                    "rooted": root_admissible,
                    "sector": label_bits[2],
                }
            )

    direct_matchings = frozenset(note110.enumerate_perfect_matchings(child))
    assert reconstructed == direct_matchings
    direct_cells = {
        matching: note110.local_cell(matching, local)
        for matching in direct_matchings
    }
    assert all(direct_cells[row["matching"]] == row["cell"] for row in rows)
    direct_rooted = frozenset(
        matching
        for matching in direct_matchings
        if note110.is_root_target(child, matching, ROOT, FORCED)
    )
    state_rooted = frozenset(
        row["matching"] for row in rows if row["rooted"]
    )
    assert state_rooted == direct_rooted

    row_by_matching = {row["matching"]: row for row in rows}
    epsilon_cache = {}
    state_crossings = set()
    direct_crossings = set()
    pair_state_outcomes = defaultdict(set)
    distinct_pair_states = set()
    all_pairs = 0
    for first_index, second_index in combinations(range(len(rows)), 2):
        all_pairs += 1
        first, second = rows[first_index], rows[second_index]
        exterior_pair = tuple(
            sorted((matching_key(first["exterior"]), matching_key(second["exterior"])))
        )
        if exterior_pair not in epsilon_cache:
            exterior_difference = first["exterior"] ^ second["exterior"]
            epsilon_cache[exterior_pair] = component_profile(
                tuple(parent), exterior_difference, boundary, False
            )
        epsilon = epsilon_cache[exterior_pair]
        patch_difference = patterns[first["cell"]] ^ patterns[second["cell"]]
        component_count, _root_separated = glue_profile(
            epsilon,
            patch_difference,
            boundary,
            include_all_active=False,
        )
        sector_change = first["sector"] != second["sector"]
        pair_state = (
            tuple(sorted((first["cell"], second["cell"]))),
            epsilon,
            sector_change,
        )
        distinct_pair_states.add(pair_state)
        state_bond = component_count == 1
        pair_state_outcomes[pair_state].add(state_bond)
        direct_bond = (
            note110.difference_component_count(
                first["matching"], second["matching"]
            ) == 1
        )
        assert state_bond == direct_bond
        if (
            first["rooted"]
            and second["rooted"]
            and sector_change
            and state_bond
        ):
            state_crossings.add(
                frozenset((first["matching"], second["matching"]))
            )
        if (
            first["matching"] in direct_rooted
            and second["matching"] in direct_rooted
            and (SURVIVING in first["matching"])
            != (SURVIVING in second["matching"])
            and direct_bond
        ):
            direct_crossings.add(
                frozenset((first["matching"], second["matching"]))
            )
    assert state_crossings == direct_crossings
    assert all(len(outcomes) == 1 for outcomes in pair_state_outcomes.values())

    cell_histogram = Counter(row["cell"] for row in rows)
    rooted_cell_histogram = Counter(
        row["cell"] for row in rows if row["rooted"]
    )
    crossing_cell_histogram = Counter()
    for pair in state_crossings:
        first, second = sorted(pair, key=matching_key)
        crossing_cell_histogram[
            "--".join(sorted((row_by_matching[first]["cell"], row_by_matching[second]["cell"])))
        ] += 1

    row_state_keys = {
        (row["cell"], row["delta"])
        for row in rows
    }
    payload = {
        "status": "EXACT_AGREEMENT_ON_FIRST_COLLISION_DECORATION",
        "scope": {
            "parent_types": 1,
            "decoration_orbits": 1,
            "other_decoration_orbits_touched": 0,
            "parent_order": 24,
            "child_order": 28,
        },
        "decoration": {
            "root": ROOT,
            "forced_gate": FORCED,
            "surviving_gate": SURVIVING,
            "site_selected": tuple(sorted(SELECTED)),
            "oriented_boundary": boundary,
            "legal_wide_arcs": note110.legal_wide_arcs(
                child_faces, ROOT, FORCED, SURVIVING
            ),
        },
        "state_sizes": {
            "exterior_boundary_rows": sum(map(len, exterior_cache.values())),
            "exterior_rows_by_defect_class": {
                str(key): len(value)
                for key, value in sorted(exterior_cache.items())
            },
            "decorated_child_rows": len(rows),
            "distinct_delta_decorated_row_states": len(row_state_keys),
            "unordered_row_pairs_with_epsilon": all_pairs,
            "distinct_epsilon_exterior_profiles": len(set(epsilon_cache.values())),
            "distinct_decorated_pair_states": len(distinct_pair_states),
        },
        "reconstructed": {
            "perfect_matchings": len(rows),
            "cell_histogram": dict(sorted(cell_histogram.items())),
            "rooted_rows": len(state_rooted),
            "rooted_cell_histogram": dict(sorted(rooted_cell_histogram.items())),
            "cross_sector_single_cycle_edges": len(state_crossings),
            "crossing_cell_histogram": dict(
                sorted(crossing_cell_histogram.items())
            ),
        },
        "direct": {
            "perfect_matchings": len(direct_matchings),
            "cell_histogram": dict(sorted(Counter(direct_cells.values()).items())),
            "rooted_rows": len(direct_rooted),
            "cross_sector_single_cycle_edges": len(direct_crossings),
        },
        "equalities": {
            "perfect_matching_set": True,
            "seven_cell_partition": True,
            "rooted_row_set": True,
            "complete_cross_sector_single_cycle_graph": True,
            "pair_state_collision_absent": True,
        },
    }
    assert len(rows) == 475
    assert len(state_rooted) == 27
    assert len(state_crossings) == 26
    output = HERE / "corrected_boundary_joint_state.json"
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print("status", payload["status"])
    print("state_sizes", json.dumps(payload["state_sizes"], sort_keys=True))
    print("reconstructed", json.dumps(payload["reconstructed"], sort_keys=True))
    print("equalities", json.dumps(payload["equalities"], sort_keys=True))
    print("output", output)


if __name__ == "__main__":
    main()
