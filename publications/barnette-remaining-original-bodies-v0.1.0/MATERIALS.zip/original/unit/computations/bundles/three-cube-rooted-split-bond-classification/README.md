# Rooted split-bond classification for the three-cube annular family

This bundle exhausts the fixed order-\(24\) family obtained from three
cubes by two standard plane four-port annular splices.  The first splice is
normalized by the \(48\)-element cube automorphism group; all \(288\)
embedded choices for the second splice reduce to four parent isomorphism
types.

For each parent the classifier enumerates every cofacial bipartite
\(C_4\)-expansion site, every interface-disjoint legal-wide root/gate
decoration, the complete parent and child perfect-matching fibres, and the
cross-sector single-cycle graphs.  Exact graph automorphisms reduce \(4094\)
labelled decorations to \(437\) orbits.

The result is:

- all \(437\) parent crossing graphs are nonempty;
- \(62\) decoration orbits, or \(690\) labelled decorations, satisfy the
  kill-cover antecedent;
- all \(62\) child crossing graphs are nonempty, with at least four edges;
- every surviving child crossing is incident with
  \(R_{00},X_{uy}\), or \(X_{vx}\).

A second verifier stops at the first decoration and tests whether parent
perfect-matching rows, even when decorated by arbitrary deletion data, can
reconstruct the seven child cells.  It reconstructs \(323\) of the \(475\)
child perfect matchings and misses exactly all \(76\) \(X_{uy}\) rows and
all \(76\) \(X_{vx}\) rows.  In the rooted fibre it misses exactly seven
rows of each cross type.  Their exterior restrictions are near-perfect
rows with cross defects \(\{u,y\}\) and \(\{v,x\}\), which have no parent
perfect-matching ancestor.

A third verifier adds all six exterior defect classes, the marked
row-deletion signatures, and the pairwise bond-deletion atoms of Note 132.
On the same first decoration it reconstructs the literal set of all \(475\)
child perfect matchings, the literal \(27\)-row rooted fibre, and the literal
\(26\)-edge cross-sector single-cycle graph.  It checks all \(112{,}575\)
unordered exterior-row pairs and finds no conflicting outcome among the
\(1{,}647\) decorated pair states.  Its scope is this one decoration; the
general one-step closure is proved by the restriction-and-gluing argument
of Note 132.

Run from the AIMath root:

~~~bash
uv run --python 3.12 --with networkx==3.6.1 \
  python units/barnette/computations/bundles/three-cube-rooted-split-bond-classification/classify_three_cube_rooted_split_bond.py
~~~

The terminal status is:

~~~text
B_COMPLETE_FIXED_THREE_CUBE_FAMILY_EXCLUDED
~~~

Run the PM-only state collision verifier with:

~~~bash
uv run --python 3.12 --with networkx==3.6.1 \
  python units/barnette/computations/bundles/three-cube-rooted-split-bond-classification/verify_parent_pm_only_state_collision.py
~~~

Its terminal status is:

~~~text
STRICT_INFORMATION_INSUFFICIENCY_AT_FIRST_DECORATION
~~~

Run the corrected-state verifier with:

~~~bash
uv run --python 3.12 --with networkx==3.6.1 \
  python units/barnette/computations/bundles/three-cube-rooted-split-bond-classification/verify_corrected_boundary_joint_state.py
~~~

Its terminal status is:

~~~text
EXACT_AGREEMENT_ON_FIRST_COLLISION_DECORATION
~~~

Frozen SHA256 values:

~~~text
classifier  08fe90cf323df521213c99a18ea62f88030e3c53cf1ddffa820058c0ea81c5cc
support     60e5c981036d3d1d835c3d0e377c808189864271ee87e42201102cf16c8da69f
output      378e7a5f87b2401c86062cd7064d179d9c572c5c44362c55873f3b313860e2bc
collision   0c0e60def54766604139950b3e5c6ca78796a51f26e3601bb83c747d074358b1
collision-json  7a5262cc7e8255c0114cc4b03612a46f3feef460bb01eccbfd8549cd4582d444
corrected-state  7f6726e51805617298cda58cea20bc50bca96d69637202560722177c824396a2
corrected-json   0d5f7fcc314db35bdc1cdee717360ebd29b814d71fd39ad0cb7259c342d2c1dd
~~~

The support module imports the permanent matching/root predicates of
Notes 110 and 128; it has no dependency on the exploratory scratch tree.
This bundle proves only the fixed three-cube annular-family exclusion.  It
does not classify other factors or orders and is not a proof of the general
rooted split-bond lemma.
