# Forced-gate target-component saturation at reduced order 22

This bundle extends the component-saturation theorem of Note 071 to every
simple plane cubic bipartite brace of order 22.  It streams the complete
`geng` corpus, builds every legal split/root target-state graph, and uses the
neutral-gate lemma to restrict local lift tests to components on which both
gate edges are forced.

The accepted certificate covers 4,132 connected simple cubic bipartite
isomorphism representatives, 3 plane braces, 4,548 nonempty interfaces,
36,696 target instances, and 6,362 target-state components.  Of these
components, 6,096 contain a target using at most one gate.  Each of the
remaining 266 forced-two-gate components contains a liftable target.

## Contents

- `census_forced_target_components_order22.py` is the streaming driver.  It
  stops and freezes a complete explicit record if a forced-gate component
  without a lift is found.
- `forced_target_components_order22.json` is the accepted complete-success
  certificate; its `first_failure` field is null.

## Reproduction

From the AIMath project root:

    task_run_dir=$(mktemp -d)

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/target-component-saturation-order22/census_forced_target_components_order22.py \
      --output "$task_run_dir/order22.json"

    cmp "$task_run_dir/order22.json" \
      units/barnette/computations/bundles/target-component-saturation-order22/forced_target_components_order22.json

The required terminal marker is

    FORCED_TARGET_COMPONENT_SATURATION_VERIFIED_AT_REDUCED_ORDER_22

Accepted environment:

- nauty 2.9.3, using `geng -cqb -d3 -D3 22`;
- NetworkX 3.6.1;
- Python 3 via `uv`.

The accepted run used approximately 30 seconds wall time and 47 MB maximum
resident memory.  A second local run reproduced the JSON byte for byte.

The external coverage interfaces are `geng`'s isomorph-free generation and
NetworkX's planarity decisions.  Cubicity, bipartition, independent-two-edge
extension, strict Hall, embedded duals, complete reduced target families,
single-cycle target adjacency, forced-gate components, and all rows needed to
find a component witness are checked directly.
