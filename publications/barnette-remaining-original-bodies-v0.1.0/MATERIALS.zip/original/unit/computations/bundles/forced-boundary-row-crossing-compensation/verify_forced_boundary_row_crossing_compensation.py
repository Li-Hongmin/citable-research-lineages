#!/usr/bin/env python3
"""Verify the fixed-carrier facts carrying Note 158."""

from __future__ import annotations

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

import networkx as nx


HERE = Path(__file__).resolve().parent
AUDIT_PATH = (
    HERE.parent
    / "fixed-carrier-parity-atom-boundary"
    / "audit_fixed_carrier_atoms.py"
)
SPEC = spec_from_file_location("carrier_audit", AUDIT_PATH)
assert SPEC is not None and SPEC.loader is not None
AUDIT = module_from_spec(SPEC)
SPEC.loader.exec_module(AUDIT)


def compatible_rows(rows, atoms, state, pairs):
    return tuple(
        index
        for index, ((row_state, _matching), atom) in enumerate(
            zip(rows, atoms)
        )
        if row_state == state
        and AUDIT.factor_join_passes(atom, state, pairs)
    )


def main() -> None:
    graph = nx.from_graph6_bytes(AUDIT.GRAPH6.encode())
    cut, rows = AUDIT.carrier_rows(graph)
    atoms = tuple(
        AUDIT.complement_components(cut, state, matching)
        for state, matching in rows
    )
    assert len(rows) == 54

    empty = frozenset()
    state_a1 = frozenset((1, 2))
    pairing_z = (frozenset((0, 1)), frozenset((2, 3)))
    pairing_a1 = (frozenset((0, 3)),)

    z_carriers = compatible_rows(rows, atoms, empty, pairing_z)
    a1_carriers = compatible_rows(rows, atoms, state_a1, pairing_a1)
    assert z_carriers == (1, 2, 10, 19, 20)
    assert a1_carriers == (31, 41)

    sectors = {
        index: int(
            AUDIT.edge(*AUDIT.SURVIVING_GATE) in rows[index][1]
        )
        for index in z_carriers + a1_carriers
    }
    assert sectors[2] == sectors[20] == 1
    assert sectors[31] == sectors[41] == 0

    path12 = (frozenset((1, 2)),)
    assert AUDIT.bond_atom(cut, rows[2], rows[31]) == (path12, 0)
    assert AUDIT.bond_atom(cut, rows[20], rows[41]) == (path12, 0)

    # A carrier 12-path and a factor 12-path, with the two splice
    # connectors, form exactly one cycle.
    joined = nx.Graph()
    joined.add_edges_from(
        (
            ("carrier-1", "carrier-2"),
            ("factor-1", "factor-2"),
            ("carrier-1", "factor-1"),
            ("carrier-2", "factor-2"),
        )
    )
    assert nx.is_connected(joined)
    assert set(dict(joined.degree()).values()) == {2}

    print(f"carrier_rows={len(rows)}")
    print(f"Z_carrier_rows={z_carriers}")
    print(f"A1_carrier_rows={a1_carriers}")
    print("forced_crossing_pairs=K2-K31,K20-K41")
    print("FORCED_BOUNDARY_ROW_CROSSING_COMPENSATION_VERIFIED")


if __name__ == "__main__":
    main()
