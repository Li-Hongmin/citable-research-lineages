# Forced boundary-row crossing compensation

This bundle verifies the finite carrier facts in
[Note 158](../../../notes/158-complete-boundary-row-deletion-forces-fixed-carrier-crossing-compensation.md).
The forced deletion row itself is proved analytically in the note.

From the AIMath root, run

    uv run --python 3.14 --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/forced-boundary-row-crossing-compensation/verify_forced_boundary_row_crossing_compensation.py

The verified environment on 2026-08-29 was Python 3.14.6 with NetworkX
3.6.1.  The terminal marker is

    FORCED_BOUNDARY_ROW_CROSSING_COMPENSATION_VERIFIED

The verifier imports the promoted Note 157 carrier enumerator, reconstructs
all (54) carrier rows from the fixed graph6 string, and checks that
(K_2,K_{20}) join the clean empty-state (01\mid23) atom in gate sector
one, (K_{31},K_{41}) join the clean state-(A_1) (03) atom in gate
sector zero, and the two corresponding carrier differences are single
(12)-paths with no closed component.
