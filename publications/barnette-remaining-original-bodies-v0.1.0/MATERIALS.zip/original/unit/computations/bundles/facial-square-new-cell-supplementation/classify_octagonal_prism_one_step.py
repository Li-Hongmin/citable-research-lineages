#!/usr/bin/env python3
"""Classify every allowed one-step facial C4 expansion of Note 100.

Scope: the fixed labelled octagonal prism and its fixed root-square/gates.
No graph generation, order census, random search, or multi-step search occurs.
"""

from __future__ import annotations

from collections import Counter, deque
from itertools import combinations
import csv
import hashlib
import json
from pathlib import Path

import networkx as nx


Vertex = str
Edge = frozenset[Vertex]
Matching = frozenset[Edge]

HERE = Path(__file__).resolve().parent


def edge(left: Vertex, right: Vertex) -> Edge:
    assert left != right
    return frozenset((left, right))


def cycle_edges(vertices: tuple[Vertex, ...]) -> frozenset[Edge]:
    return frozenset(
        edge(vertices[index], vertices[(index + 1) % len(vertices)])
        for index in range(len(vertices))
    )


def face_edges(face: tuple[Vertex, ...]) -> tuple[Edge, ...]:
    return tuple(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def enumerate_perfect_matchings(
    vertices: frozenset[Vertex], edges: frozenset[Edge]
) -> tuple[Matching, ...]:
    adjacency = {vertex: set() for vertex in vertices}
    for item in edges:
        left, right = tuple(item)
        adjacency[left].add(right)
        adjacency[right].add(left)
    matchings: list[Matching] = []

    def recurse(unmatched: frozenset[Vertex], chosen: tuple[Edge, ...]) -> None:
        if not unmatched:
            matchings.append(frozenset(chosen))
            return
        vertex = min(
            unmatched,
            key=lambda value: (
                sum(neighbour in unmatched for neighbour in adjacency[value]),
                value,
            ),
        )
        for neighbour in sorted(adjacency[vertex] & unmatched):
            recurse(unmatched - {vertex, neighbour}, chosen + (edge(vertex, neighbour),))

    recurse(vertices, ())
    assert len(matchings) == len(set(matchings))
    return tuple(matchings)


def validate_faces(graph: nx.Graph, faces: tuple[tuple[Vertex, ...], ...]) -> None:
    darts = [
        (face[index], face[(index + 1) % len(face)])
        for face in faces
        for index in range(len(face))
    ]
    expected = {
        dart
        for left, right in graph.edges()
        for dart in ((left, right), (right, left))
    }
    assert len(darts) == len(set(darts)) == 2 * graph.number_of_edges()
    assert set(darts) == expected
    assert graph.number_of_nodes() - graph.number_of_edges() + len(faces) == 2
    assert all(len(face) == len(set(face)) for face in faces)


def replace_dart(
    face: tuple[Vertex, ...],
    left: Vertex,
    right: Vertex,
    inserted: tuple[Vertex, ...],
) -> tuple[Vertex, ...]:
    positions = [
        index
        for index in range(len(face))
        if face[index] == left and face[(index + 1) % len(face)] == right
    ]
    if not positions:
        return face
    assert len(positions) == 1
    index = positions[0]
    rotated = face[index:] + face[:index]
    return (left,) + inserted + (right,) + rotated[2:]


N = 8
TOP = tuple(f"t{index}" for index in range(N))
BOTTOM = tuple(f"b{index}" for index in range(N))
PARENT_VERTICES = frozenset(TOP + BOTTOM)
PARENT_EDGES = (
    cycle_edges(TOP)
    | cycle_edges(BOTTOM)
    | frozenset(edge(TOP[index], BOTTOM[index]) for index in range(N))
)
PARENT_GRAPH = nx.Graph()
PARENT_GRAPH.add_nodes_from(sorted(PARENT_VERTICES))
PARENT_GRAPH.add_edges_from(tuple(item) for item in PARENT_EDGES)
PARENT_FACES = tuple(
    (BOTTOM[index], BOTTOM[(index + 1) % N], TOP[(index + 1) % N], TOP[index])
    for index in range(N)
) + (TOP, (BOTTOM[0],) + tuple(reversed(BOTTOM[1:])))

ROOT = edge("b0", "b1")
FORCED_GATE = edge("t0", "t1")
SURVIVING_GATE = edge("t4", "t5")
ROOT_SQUARE = ("b0", "b1", "t1", "t0")
ROOT_SQUARE_EDGES = cycle_edges(ROOT_SQUARE)
PROTECTED_EDGES = ROOT_SQUARE_EDGES | frozenset((SURVIVING_GATE,))


def expand_on_face(
    face_index: int, first_index: int, second_index: int
) -> tuple[nx.Graph, tuple[tuple[Vertex, ...], ...], tuple[Edge, Edge]]:
    face = PARENT_FACES[face_index]
    first_left = face[first_index]
    first_right = face[(first_index + 1) % len(face)]
    second_left = face[second_index]
    second_right = face[(second_index + 1) % len(face)]
    selected = (edge(first_left, first_right), edge(second_left, second_right))
    prefix = f"m{face_index}_{first_index}_{second_index}_"
    a, b, c, d = tuple(prefix + letter for letter in "abcd")

    child = PARENT_GRAPH.copy()
    child.remove_edge(first_left, first_right)
    child.remove_edge(second_left, second_right)
    child.add_edges_from(
        (
            (first_left, a),
            (a, b),
            (b, first_right),
            (second_left, c),
            (c, d),
            (d, second_right),
            (a, d),
            (b, c),
        )
    )

    updated: list[tuple[Vertex, ...]] = []
    for index, old_face in enumerate(PARENT_FACES):
        if index == face_index:
            continue
        new_face = replace_dart(old_face, first_right, first_left, (b, a))
        new_face = replace_dart(new_face, second_right, second_left, (d, c))
        updated.append(new_face)
    first_channel = face[first_index + 1 : second_index + 1] + (c, b)
    second_channel = face[second_index + 1 :] + face[: first_index + 1] + (a, d)
    updated.extend((first_channel, second_channel, (a, b, c, d)))
    child_faces = tuple(updated)
    validate_faces(child, child_faces)
    return child, child_faces, selected


def legal_moves() -> tuple[dict[str, object], ...]:
    records: list[dict[str, object]] = []
    seen: set[frozenset[Edge]] = set()
    for face_index, face in enumerate(PARENT_FACES):
        degree = len(face)
        assert degree % 2 == 0
        for first_index, second_index in combinations(range(degree), 2):
            distance = second_index - first_index
            # Exactly the vertex-disjoint, same-parity boundary edges.  This
            # is the facial bipartite C4 move condition used in Note 101.
            if distance in (1, degree - 1) or distance % 2:
                continue
            selected = (
                edge(face[first_index], face[(first_index + 1) % degree]),
                edge(face[second_index], face[(second_index + 1) % degree]),
            )
            key = frozenset(selected)
            assert len(key) == 2 and selected[0].isdisjoint(selected[1])
            if key in seen:
                continue
            seen.add(key)
            records.append(
                {
                    "face_index": face_index,
                    "indices": (first_index, second_index),
                    "face": face,
                    "selected": selected,
                    "protected_edges_untouched": not bool(key & PROTECTED_EDGES),
                }
            )
    return tuple(records)


def delta_component_count(first: Matching, second: Matching) -> int:
    delta = first ^ second
    if not delta:
        return 0
    adjacency: dict[Vertex, set[Vertex]] = {}
    for item in delta:
        left, right = tuple(item)
        adjacency.setdefault(left, set()).add(right)
        adjacency.setdefault(right, set()).add(left)
    assert set(map(len, adjacency.values())) == {2}
    unseen = set(adjacency)
    components = 0
    while unseen:
        components += 1
        start = next(iter(unseen))
        reached = {start}
        queue = deque((start,))
        while queue:
            vertex = queue.popleft()
            for neighbour in adjacency[vertex] - reached:
                reached.add(neighbour)
                queue.append(neighbour)
        unseen -= reached
    return components


def target(graph: nx.Graph, matching: Matching) -> bool:
    # This is the full-graph formulation of the Note 100 fixed-pairing
    # fibre, identical to Note 101: root and forced gate are in the matching,
    # and the complementary 2-factor has exactly two components separating
    # the two endpoints of the root edge.
    if ROOT not in matching or FORCED_GATE not in matching:
        return False
    graph_edges = frozenset(edge(left, right) for left, right in graph.edges())
    complement = nx.Graph()
    complement.add_nodes_from(graph)
    complement.add_edges_from(tuple(item) for item in graph_edges - matching)
    assert set(dict(complement.degree()).values()) == {2}
    components = tuple(nx.connected_components(complement))
    if len(components) != 2:
        return False
    root_vertices = set(ROOT)
    return all(len(root_vertices & component) == 1 for component in components)


def legal_wide(faces: tuple[tuple[Vertex, ...], ...]) -> tuple[int, int] | None:
    witnesses: list[tuple[int, int]] = []
    for face in faces:
        boundary = face_edges(face)
        if FORCED_GATE not in boundary or SURVIVING_GATE not in boundary:
            continue
        if ROOT in boundary:
            continue
        delta = (boundary.index(SURVIVING_GATE) - boundary.index(FORCED_GATE)) % len(boundary)
        arcs = (delta + 1, len(boundary) - delta + 1)
        if min(arcs) >= 5 and all(size % 2 for size in arcs):
            witnesses.append(tuple(sorted(arcs)))
    assert len(witnesses) <= 1
    return witnesses[0] if witnesses else None


def brace_certificate(
    graph: nx.Graph, matchings: tuple[Matching, ...]
) -> tuple[bool, int, int]:
    edges = frozenset(edge(left, right) for left, right in graph.edges())
    independent = {
        frozenset((first, second))
        for first, second in combinations(edges, 2)
        if first.isdisjoint(second)
    }
    covered = {
        frozenset((first, second))
        for matching in matchings
        for first, second in combinations(matching, 2)
    }
    return independent <= covered, len(independent), len(covered & independent)


def graph_hash(graph: nx.Graph) -> str:
    canonical_edges = tuple(sorted(tuple(sorted((left, right))) for left, right in graph.edges()))
    return hashlib.sha256(
        json.dumps(canonical_edges, separators=(",", ":")).encode()
    ).hexdigest()


def selected_names(selected: tuple[Edge, Edge]) -> tuple[tuple[Vertex, Vertex], ...]:
    return tuple(sorted(tuple(sorted(item)) for item in selected))


def classify(record: dict[str, object]) -> dict[str, object]:
    face_index = int(record["face_index"])
    first_index, second_index = record["indices"]
    assert isinstance(first_index, int) and isinstance(second_index, int)
    child, child_faces, selected = expand_on_face(face_index, first_index, second_index)
    vertices = frozenset(child)
    edges = frozenset(edge(left, right) for left, right in child.edges())
    matchings = enumerate_perfect_matchings(vertices, edges)

    simple = (
        child.number_of_edges() == len(edges)
        and all(len(item) == 2 for item in edges)
        and nx.number_of_selfloops(child) == 0
    )
    connected = nx.is_connected(child)
    cubic = set(dict(child.degree()).values()) == {3}
    bipartite = nx.is_bipartite(child)
    planar_algorithmic, _ = nx.check_planarity(child)
    planar_combinatorial = (
        sum(map(len, child_faces)) == 2 * child.number_of_edges()
        and child.number_of_nodes() - child.number_of_edges() + len(child_faces) == 2
    )
    node_connectivity = nx.node_connectivity(child)
    brace, independent_pairs, covered_pairs = brace_certificate(child, matchings)
    fibre = tuple(matching for matching in matchings if target(child, matching))
    sector0 = tuple(matching for matching in fibre if SURVIVING_GATE not in matching)
    sector1 = tuple(matching for matching in fibre if SURVIVING_GATE in matching)
    histogram = Counter(
        delta_component_count(first, second)
        for first in sector0
        for second in sector1
    )
    minimum = min(histogram, default=None)

    return {
        "face_index": face_index,
        "parent_face": tuple(record["face"]),
        "parent_face_length": len(record["face"]),
        "indices": (first_index, second_index),
        "selected": selected_names(selected),
        "child_hash": graph_hash(child),
        "vertices": child.number_of_nodes(),
        "edges": child.number_of_edges(),
        "simple": simple,
        "connected": connected,
        "cubic": cubic,
        "bipartite": bipartite,
        "planar_algorithmic": planar_algorithmic,
        "planar_combinatorial": planar_combinatorial,
        "node_connectivity": node_connectivity,
        "perfect_matchings": len(matchings),
        "brace": brace,
        "independent_edge_pairs": independent_pairs,
        "covered_independent_edge_pairs": covered_pairs,
        "legal_wide_arcs": legal_wide(child_faces),
        "fibre_size": len(fibre),
        "sector_sizes": (len(sector0), len(sector1)),
        "cross_sector_pairs": len(sector0) * len(sector1),
        "cross_component_histogram": dict(sorted(histogram.items())),
        "global_cross_sector_minimum": minimum,
    }


def serial_counter(counter: Counter) -> dict[str, int]:
    return {
        str(key): value
        for key, value in sorted(counter.items(), key=lambda item: str(item[0]))
    }


def parent_certificate() -> dict[str, object]:
    validate_faces(PARENT_GRAPH, PARENT_FACES)
    matchings = enumerate_perfect_matchings(PARENT_VERTICES, PARENT_EDGES)
    brace, independent_pairs, covered_pairs = brace_certificate(PARENT_GRAPH, matchings)
    fibre = tuple(matching for matching in matchings if target(PARENT_GRAPH, matching))
    sector0 = tuple(matching for matching in fibre if SURVIVING_GATE not in matching)
    sector1 = tuple(matching for matching in fibre if SURVIVING_GATE in matching)
    histogram = Counter(
        delta_component_count(first, second)
        for first in sector0
        for second in sector1
    )
    assert len(matchings) == 49
    assert brace and independent_pairs == covered_pairs == 228
    assert len(fibre) == 5 and (len(sector0), len(sector1)) == (4, 1)
    assert histogram == Counter({2: 2, 1: 2})
    assert legal_wide(PARENT_FACES) == (5, 5)
    return {
        "vertices": PARENT_GRAPH.number_of_nodes(),
        "edges": PARENT_GRAPH.number_of_edges(),
        "perfect_matchings": len(matchings),
        "brace": brace,
        "independent_edge_pairs": independent_pairs,
        "covered_independent_edge_pairs": covered_pairs,
        "node_connectivity": nx.node_connectivity(PARENT_GRAPH),
        "legal_wide_arcs": legal_wide(PARENT_FACES),
        "fibre_size": len(fibre),
        "sector_sizes": (len(sector0), len(sector1)),
        "cross_component_histogram": dict(sorted(histogram.items())),
        "global_cross_sector_minimum": min(histogram),
    }


def main() -> None:
    parent = parent_certificate()
    moves = legal_moves()
    allowed = tuple(record for record in moves if record["protected_edges_untouched"])
    records = tuple(classify(record) for record in allowed)
    eligible = tuple(
        record
        for record in records
        if record["simple"]
        and record["connected"]
        and record["cubic"]
        and record["bipartite"]
        and record["planar_algorithmic"]
        and record["planar_combinatorial"]
        and record["node_connectivity"] == 3
        and record["brace"]
        and record["legal_wide_arcs"] is not None
    )
    counterexamples = tuple(
        record
        for record in eligible
        if record["global_cross_sector_minimum"] is None
        or record["global_cross_sector_minimum"] > 1
    )
    totals = {
        "all_facial_bipartite_c4_moves": len(moves),
        "moves_touching_root_square_or_gate": len(moves) - len(allowed),
        "allowed_moves": len(allowed),
        "simple_plane_cubic_bipartite_children": sum(
            record["simple"]
            and record["connected"]
            and record["cubic"]
            and record["bipartite"]
            and record["planar_algorithmic"]
            and record["planar_combinatorial"]
            for record in records
        ),
        "three_connected_children": sum(record["node_connectivity"] == 3 for record in records),
        "brace_children": sum(record["brace"] for record in records),
        "legal_wide_children": sum(record["legal_wide_arcs"] is not None for record in records),
        "eligible_legal_wide_plane_brace_children": len(eligible),
        "eligible_children_with_minimum_one": sum(
            record["global_cross_sector_minimum"] == 1 for record in eligible
        ),
        "eligible_counterexamples": len(counterexamples),
    }
    histograms = {
        "legal_wide_arcs_all_allowed": serial_counter(
            Counter(tuple(record["legal_wide_arcs"]) if record["legal_wide_arcs"] else None for record in records)
        ),
        "perfect_matchings_eligible": serial_counter(Counter(record["perfect_matchings"] for record in eligible)),
        "fibre_size_eligible": serial_counter(Counter(record["fibre_size"] for record in eligible)),
        "sector_sizes_eligible": serial_counter(Counter(tuple(record["sector_sizes"]) for record in eligible)),
        "global_cross_sector_minimum_eligible": serial_counter(
            Counter(record["global_cross_sector_minimum"] for record in eligible)
        ),
        "crossings_eligible": serial_counter(
            Counter(record["cross_component_histogram"].get(1, 0) for record in eligible)
        ),
    }
    payload = {
        "scope": {
            "parent": "fixed labelled Note 100 octagonal prism C8 square K2",
            "operation": "every facial bipartite one-step C4 expansion in the fixed embedding",
            "allowed": "selected edges avoid all four root-square edges and surviving gate T4; forced gate T0 is already a root-square edge",
            "eligible_child": "simple connected plane cubic bipartite, node connectivity 3, brace, and inherited legal-wide interface",
            "counterexample_test": "complete fixed-pairing fibre has an empty sector or cross-sector minimum alternating-component count greater than one",
            "not_claimed": "another parent, two steps, any order census, random search, or arbitrary-order preservation",
        },
        "parent_certificate": parent,
        "totals": totals,
        "histograms": histograms,
        "counterexamples": counterexamples,
        "records": records,
    }
    json_path = HERE / "octagonal_prism_one_step_classification.json"
    json_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    tsv_path = HERE / "octagonal_prism_one_step_classification.tsv"
    with tsv_path.open("w", newline="") as stream:
        writer = csv.writer(stream, delimiter="\t")
        writer.writerow(
            (
                "selected_edge_1",
                "selected_edge_2",
                "face_index",
                "face_length",
                "legal_wide_arcs",
                "node_connectivity",
                "brace",
                "perfect_matchings",
                "fibre_size",
                "sector_sizes",
                "cross_component_histogram",
                "global_minimum",
                "child_hash",
            )
        )
        for record in sorted(records, key=lambda item: item["selected"]):
            writer.writerow(
                (
                    "-".join(record["selected"][0]),
                    "-".join(record["selected"][1]),
                    record["face_index"],
                    record["parent_face_length"],
                    "-".join(map(str, record["legal_wide_arcs"])) if record["legal_wide_arcs"] else "lost",
                    record["node_connectivity"],
                    int(record["brace"]),
                    record["perfect_matchings"],
                    record["fibre_size"],
                    "-".join(map(str, record["sector_sizes"])),
                    json.dumps(record["cross_component_histogram"], sort_keys=True),
                    record["global_cross_sector_minimum"],
                    record["child_hash"],
                )
            )
    print(json.dumps(parent, sort_keys=True))
    print(json.dumps(totals, sort_keys=True))
    print(json.dumps(histograms, sort_keys=True))
    print("json_sha256", hashlib.sha256(json_path.read_bytes()).hexdigest())
    print("certificate", json_path)
    print("per_move_table", tsv_path)
    print("OCTAGONAL_PRISM_ONE_STEP_CLASSIFIED")


if __name__ == "__main__":
    main()
