#!/usr/bin/env python3
"""Verify the local connector table for a facial-square C4 expansion.

Paths outside the facial square are suppressed to single labelled edges.
Suppression preserves the number of symmetric-difference components.
"""

from __future__ import annotations


def edge(left: str, right: str) -> frozenset[str]:
    return frozenset((left, right))


def component_count(edges: set[frozenset[str]]) -> int:
    adjacency: dict[str, set[str]] = {}
    for item in edges:
        left, right = tuple(item)
        adjacency.setdefault(left, set()).add(right)
        adjacency.setdefault(right, set()).add(left)
    assert adjacency and all(len(neighbours) == 2 for neighbours in adjacency.values())
    unseen = set(adjacency)
    count = 0
    while unseen:
        count += 1
        stack = [unseen.pop()]
        while stack:
            current = stack.pop()
            for neighbour in adjacency[current]:
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    stack.append(neighbour)
    return count


p = edge("u", "v")
q = edge("x", "y")
r = edge("v", "x")
s = edge("y", "u")

ua = edge("u", "a")
ab = edge("a", "b")
bv = edge("b", "v")
xc = edge("x", "c")
cd = edge("c", "d")
dy = edge("d", "y")
ad = edge("a", "d")
bc = edge("b", "c")

stub = {
    "u": edge("u", "U"),
    "v": edge("v", "V"),
    "x": edge("x", "X"),
    "y": edge("y", "Y"),
}

canonical = {
    "11": {ua, bv, xc, dy},
    "10": {ua, bv, cd},
    "01": {xc, dy, ab},
    "00": {ad, bc},
}

# For a parent 11 matching on the opposite facial edges p,q, these are
# three child targets.  Their complements replace r and/or s by paths.
face_assisted = {
    "R00": {r, s, ab, cd},
    "Xuy": {r, ua, bc, dy},
    "Xvx": {s, ad, bv, xc},
}

child_local_graph = {r, s, ua, ab, bv, xc, cd, dy, ad, bc}
expected_complement_components = {
    "R00": [
        {ua, ad, dy},
        {bv, bc, xc},
    ],
    "Xuy": [
        {s},
        {bv, ab, ad, cd, xc},
    ],
    "Xvx": [
        {r},
        {ua, ab, bc, cd, dy},
    ],
}
for name, matching in face_assisted.items():
    complement = child_local_graph - matching
    expected = set().union(*expected_complement_components[name])
    assert complement == expected


def delta_count(
    face_lift: str,
    child_state: str,
    child_extra: set[frozenset[str]],
    outside_paths: set[frozenset[str]],
) -> int:
    delta = face_assisted[face_lift] ^ (canonical[child_state] | child_extra)
    delta |= outside_paths
    return component_count(delta)


# Two parent state-11 targets use the same face-assisted patch matching.
# Their local edges therefore cancel.  Model their (single) parent
# symmetric-difference cycle explicitly instead of hard-coding its count.
parent_11_outside_m = {
    edge("m0", "m1"),
    edge("m2", "m3"),
}
parent_11_outside_n = {
    edge("m1", "m2"),
    edge("m3", "m0"),
}


# The external endpoints U,V,X,Y stand for the first vertices of suppressed
# alternating paths outside the face.
tables = {
    "11": {
        name: component_count(
            face_assisted[name]
            ^ face_assisted[name]
            ^ parent_11_outside_m
            ^ parent_11_outside_n
        )
        for name in face_assisted
    },
    "10": {
        name: delta_count(
            name,
            "10",
            {stub["x"], stub["y"]},
            {edge("X", "Y")},
        )
        for name in face_assisted
    },
    "01": {
        name: delta_count(
            name,
            "01",
            {stub["u"], stub["v"]},
            {edge("U", "V")},
        )
        for name in face_assisted
    },
    "00_r": {
        name: delta_count(
            name,
            "00",
            {r, stub["u"], stub["y"]},
            {edge("U", "Y")},
        )
        for name in face_assisted
    },
    "00_s": {
        name: delta_count(
            name,
            "00",
            {s, stub["v"], stub["x"]},
            {edge("V", "X")},
        )
        for name in face_assisted
    },
    "00_ext_planar": {
        name: delta_count(
            name,
            "00",
            set(stub.values()),
            {edge("U", "Y"), edge("V", "X")},
        )
        for name in face_assisted
    },
}

assert tables == {
    "11": {"R00": 1, "Xuy": 1, "Xvx": 1},
    "10": {"R00": 1, "Xuy": 1, "Xvx": 1},
    "01": {"R00": 1, "Xuy": 1, "Xvx": 1},
    "00_r": {"R00": 2, "Xuy": 1, "Xvx": 2},
    "00_s": {"R00": 2, "Xuy": 2, "Xvx": 1},
    "00_ext_planar": {"R00": 3, "Xuy": 2, "Xvx": 2},
}

for state, row in tables.items():
    print(state, row)
print("FACIAL_SQUARE_CONNECTOR_TABLE_VERIFIED")
