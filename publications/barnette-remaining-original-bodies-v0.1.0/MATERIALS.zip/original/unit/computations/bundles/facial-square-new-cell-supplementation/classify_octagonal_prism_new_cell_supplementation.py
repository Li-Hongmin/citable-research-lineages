#!/usr/bin/env python3
"""Classify old-crossing kills and new local-cell supplementation.

This script uses only the 22 eligible one-step children already classified
for the fixed Note 100 octagonal prism.  It does not generate another parent
or inspect another order.
"""

from __future__ import annotations

from collections import Counter
import contextlib
import csv
import hashlib
import io
import json
from pathlib import Path
import runpy


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "classify_octagonal_prism_one_step.py"
BASE_JSON = HERE / "octagonal_prism_one_step_classification.json"

with contextlib.redirect_stdout(io.StringIO()):
    BASE = runpy.run_path(BASE_PATH)

edge = BASE["edge"]
cycle_edges = BASE["cycle_edges"]
enumerate_perfect_matchings = BASE["enumerate_perfect_matchings"]
expand_on_face = BASE["expand_on_face"]
target = BASE["target"]
delta_component_count = BASE["delta_component_count"]
selected_names = BASE["selected_names"]

TOP = BASE["TOP"]
BOTTOM = BASE["BOTTOM"]
PARENT_GRAPH = BASE["PARENT_GRAPH"]
PARENT_EDGES = BASE["PARENT_EDGES"]
ROOT = BASE["ROOT"]
FORCED_GATE = BASE["FORCED_GATE"]
SURVIVING_GATE = BASE["SURVIVING_GATE"]


def serial_matching(matching):
    return tuple(sorted(tuple(sorted(item)) for item in matching))


def serial_counter(counter: Counter) -> dict[str, int]:
    return {str(key): value for key, value in sorted(counter.items(), key=lambda item: str(item[0]))}


SIDE_EDGES = tuple(
    frozenset(
        (
            edge(TOP[index], TOP[(index + 1) % 8]),
            edge(BOTTOM[index], BOTTOM[(index + 1) % 8]),
            edge(TOP[index], BOTTOM[index]),
            edge(TOP[(index + 1) % 8], BOTTOM[(index + 1) % 8]),
        )
    )
    for index in range(8)
)
COMMON = frozenset((ROOT, FORCED_GATE)) | frozenset(
    edge(TOP[index], BOTTOM[index]) for index in range(8) if index not in (0, 1)
)
PARENT_FIBRE = {f"M{index}": COMMON ^ SIDE_EDGES[index] for index in range(2, 7)}
PARENT_SECTOR0 = {
    name: matching for name, matching in PARENT_FIBRE.items() if SURVIVING_GATE not in matching
}
PARENT_SECTOR1 = {
    name: matching for name, matching in PARENT_FIBRE.items() if SURVIVING_GATE in matching
}
PARENT_CROSSINGS = tuple(
    (left_name, right_name)
    for left_name, left in PARENT_SECTOR0.items()
    for right_name, right in PARENT_SECTOR1.items()
    if delta_component_count(left, right) == 1
)
assert set(PARENT_CROSSINGS) == {("M3", "M4"), ("M5", "M4")}


def local_edges(face_index: int, first_index: int, second_index: int):
    face = BASE["PARENT_FACES"][face_index]
    first_left = face[first_index]
    first_right = face[(first_index + 1) % len(face)]
    second_left = face[second_index]
    second_right = face[(second_index + 1) % len(face)]
    prefix = f"m{face_index}_{first_index}_{second_index}_"
    a, b, c, d = tuple(prefix + letter for letter in "abcd")
    return (
        edge(first_left, a),
        edge(a, b),
        edge(b, first_right),
        edge(second_left, c),
        edge(c, d),
        edge(d, second_right),
        edge(a, d),
        edge(b, c),
    )


def cell_type(matching, local) -> str:
    ua, ab, bv, xc, cd, dy, ad, bc = local
    patch = matching & frozenset(local)
    patterns = {
        frozenset((ad, bc)): "canonical:C00",
        frozenset((ua, bv, cd)): "canonical:C10",
        frozenset((xc, dy, ab)): "canonical:C01",
        frozenset((ua, bv, xc, dy)): "C11",
        frozenset((ab, cd)): "R00",
        frozenset((ua, dy, bc)): "Xuy",
        frozenset((bv, xc, ad)): "Xvx",
    }
    assert patch in patterns, serial_matching(patch)
    return patterns[patch]


def coarse_cell(label: str) -> str:
    return "canonical" if label.startswith("canonical:") else label


def canonical_cycle(delta) -> tuple[str, ...]:
    adjacency: dict[str, set[str]] = {}
    for item in delta:
        left, right = tuple(item)
        adjacency.setdefault(left, set()).add(right)
        adjacency.setdefault(right, set()).add(left)
    assert set(map(len, adjacency.values())) == {2}
    start = min(adjacency)

    def traverse(first_neighbour: str) -> tuple[str, ...]:
        path = [start, first_neighbour]
        previous, current = start, first_neighbour
        while True:
            candidates = adjacency[current] - {previous}
            assert len(candidates) == 1
            following = next(iter(candidates))
            if following == start:
                return tuple(path + [start])
            path.append(following)
            previous, current = current, following

    alternatives = tuple(traverse(neighbour) for neighbour in sorted(adjacency[start]))
    return min(alternatives)


def classify_record(base_record: dict[str, object]) -> tuple[dict[str, object], list[dict[str, object]]]:
    face_index = int(base_record["face_index"])
    first_index, second_index = base_record["indices"]
    child, _child_faces, selected = expand_on_face(face_index, first_index, second_index)
    local = local_edges(face_index, first_index, second_index)
    vertices = frozenset(child)
    edges = frozenset(edge(left, right) for left, right in child.edges())
    matchings = enumerate_perfect_matchings(vertices, edges)
    fibre = tuple(matching for matching in matchings if target(child, matching))
    sector0 = tuple(matching for matching in fibre if SURVIVING_GATE not in matching)
    sector1 = tuple(matching for matching in fibre if SURVIVING_GATE in matching)
    assert len(matchings) == base_record["perfect_matchings"]
    assert len(fibre) == base_record["fibre_size"]
    assert (len(sector0), len(sector1)) == tuple(base_record["sector_sizes"])

    labels = {matching: cell_type(matching, local) for matching in matchings}
    coarse = {matching: coarse_cell(labels[matching]) for matching in matchings}
    assert all(labels[matching] != "C11" for matching in fibre)

    l11 = tuple(
        name for name, matching in sorted(PARENT_FIBRE.items()) if all(item in matching for item in selected)
    )
    killed_crossings = tuple(
        crossing for crossing in PARENT_CROSSINGS if set(crossing) & set(l11)
    )
    l11_vertex_cover = len(killed_crossings) == len(PARENT_CROSSINGS)

    crossings = tuple(
        (first, second)
        for first in sector0
        for second in sector1
        if delta_component_count(first, second) == 1
    )
    assert len(crossings) == int(base_record["cross_component_histogram"]["1"])
    pair_histogram = Counter(
        "--".join(sorted((coarse[first], coarse[second]))) for first, second in crossings
    )
    incident_edges = Counter()
    endpoint_incidences = Counter()
    distinct_endpoints: dict[str, set[object]] = {
        cell: set() for cell in ("canonical", "R00", "Xuy", "Xvx")
    }
    detailed_crossings: list[dict[str, object]] = []
    for first, second in crossings:
        cell_pair = (coarse[first], coarse[second])
        for cell in set(cell_pair):
            incident_edges[cell] += 1
        for matching, cell in ((first, coarse[first]), (second, coarse[second])):
            endpoint_incidences[cell] += 1
            distinct_endpoints[cell].add(matching)
        delta = first ^ second
        detailed_crossings.append(
            {
                "cells": cell_pair,
                "fine_cells": (labels[first], labels[second]),
                "sector0_matching": serial_matching(first),
                "sector1_matching": serial_matching(second),
                "symmetric_difference_cycle": canonical_cycle(delta),
                "cycle_length": len(delta),
            }
        )

    cell_counts = Counter(coarse[matching] for matching in fibre)
    fine_cell_counts = Counter(labels[matching] for matching in fibre)
    sector_cell_counts = {
        "sector0": serial_counter(Counter(coarse[matching] for matching in sector0)),
        "sector1": serial_counter(Counter(coarse[matching] for matching in sector1)),
    }
    for cell in ("canonical", "R00", "Xuy", "Xvx"):
        incident_edges.setdefault(cell, 0)
        endpoint_incidences.setdefault(cell, 0)
    canonical_canonical = pair_histogram["canonical--canonical"]
    new_cell_crossings = len(crossings) - canonical_canonical
    # Canonical lifts preserve the parent component count.  Hence a full
    # parent kill together with canonical_canonical == 0 and a nonempty
    # child crossing family is genuine supplementation by a new patch cell.
    supplementation = l11_vertex_cover and canonical_canonical == 0 and bool(crossings)

    record = {
        "selected": selected_names(selected),
        "face_index": face_index,
        "indices": (first_index, second_index),
        "legal_wide_arcs": base_record["legal_wide_arcs"],
        "parent_L11": l11,
        "parent_crossings": PARENT_CROSSINGS,
        "killed_parent_crossings": killed_crossings,
        "parent_L11_is_vertex_cover": l11_vertex_cover,
        "child_fibre_size": len(fibre),
        "child_sector_sizes": (len(sector0), len(sector1)),
        "child_fibre_cell_counts": serial_counter(cell_counts),
        "child_fibre_fine_cell_counts": serial_counter(fine_cell_counts),
        "child_sector_cell_counts": sector_cell_counts,
        "child_crossings": len(crossings),
        "crossing_cell_pair_histogram": serial_counter(pair_histogram),
        "canonical_canonical_crossings": canonical_canonical,
        "new_cell_crossings": new_cell_crossings,
        "crossing_edges_incident_by_cell": serial_counter(incident_edges),
        "crossing_endpoint_incidences_by_cell": serial_counter(endpoint_incidences),
        "distinct_crossing_endpoints_by_cell": {
            cell: len(states) for cell, states in sorted(distinct_endpoints.items())
        },
        "genuine_new_cell_supplementation_after_full_parent_kill": supplementation,
    }
    return record, detailed_crossings


def main() -> None:
    payload = json.loads(BASE_JSON.read_text())
    eligible_base = tuple(
        record
        for record in payload["records"]
        if record["legal_wide_arcs"] is not None and record["brace"] and record["node_connectivity"] == 3
    )
    assert len(eligible_base) == 22
    classified = []
    detailed_by_move = {}
    for base_record in eligible_base:
        record, detailed = classify_record(base_record)
        classified.append(record)
        detailed_by_move[tuple(map(tuple, record["selected"]))] = detailed
    classified.sort(key=lambda record: record["selected"])

    kill_cover_moves = tuple(record for record in classified if record["parent_L11_is_vertex_cover"])
    supplementing_moves = tuple(
        record
        for record in classified
        if record["genuine_new_cell_supplementation_after_full_parent_kill"]
    )

    witness = None
    if kill_cover_moves:
        witness_move = kill_cover_moves[0]
        key = tuple(map(tuple, witness_move["selected"]))
        candidate_crossings = detailed_by_move[key]
        chosen = min(
            candidate_crossings,
            key=lambda item: (
                item["cycle_length"],
                tuple(sorted(item["cells"])),
                item["symmetric_difference_cycle"],
                item["sector0_matching"],
                item["sector1_matching"],
            ),
        )
        witness = {
            "minimality_rule": "lexicographically first kill-cover move; then shortest child crossing, with lexicographic tie-break",
            "selected": witness_move["selected"],
            "parent_L11": witness_move["parent_L11"],
            "parent_crossings": witness_move["parent_crossings"],
            "killed_parent_crossings": witness_move["killed_parent_crossings"],
            "child_crossing": chosen,
        }
        witness_path = HERE / "minimal_kill_cover_new_cell_supplementation_witness.json"
        witness_path.write_text(json.dumps(witness, indent=2, sort_keys=True) + "\n")

    totals = {
        "eligible_moves": len(classified),
        "parent_crossings": len(PARENT_CROSSINGS),
        "moves_with_nonempty_L11": sum(bool(record["parent_L11"]) for record in classified),
        "moves_whose_L11_is_vertex_cover": len(kill_cover_moves),
        "moves_killing_no_parent_crossing": sum(not record["killed_parent_crossings"] for record in classified),
        "moves_killing_one_parent_crossing": sum(len(record["killed_parent_crossings"]) == 1 for record in classified),
        "moves_killing_all_parent_crossings": len(kill_cover_moves),
        "moves_with_genuine_new_cell_supplementation_after_full_parent_kill": len(supplementing_moves),
    }
    aggregate_participation = {
        "crossing_edges_incident_by_cell": serial_counter(
            sum((Counter(record["crossing_edges_incident_by_cell"]) for record in classified), Counter())
        ),
        "crossing_endpoint_incidences_by_cell": serial_counter(
            sum((Counter(record["crossing_endpoint_incidences_by_cell"]) for record in classified), Counter())
        ),
        "crossing_cell_pair_histogram": serial_counter(
            sum((Counter(record["crossing_cell_pair_histogram"]) for record in classified), Counter())
        ),
    }
    output = {
        "scope": {
            "parent": "fixed labelled Note 100 octagonal prism",
            "children": "the 22 previously classified eligible one-step legal-wide plane braces",
            "not_claimed": "another parent, another order, two steps, or an arbitrary-order theorem",
        },
        "local_cells": {
            "canonical": "C00={ad,bc}, C10={ua,bv,cd}, or C01={xc,dy,ab}",
            "R00": "{ab,cd}",
            "Xuy": "{ua,dy,bc}",
            "Xvx": "{bv,xc,ad}",
            "C11": "{ua,bv,xc,dy}; absent from the child fixed-pairing fibre",
        },
        "parent_fibre": {name: serial_matching(matching) for name, matching in sorted(PARENT_FIBRE.items())},
        "parent_crossings": PARENT_CROSSINGS,
        "totals": totals,
        "aggregate_participation": aggregate_participation,
        "kill_cover_moves": kill_cover_moves,
        "witness": witness,
        "records": classified,
    }
    json_path = HERE / "octagonal_prism_new_cell_supplementation_classification.json"
    json_path.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    tsv_path = HERE / "octagonal_prism_new_cell_supplementation_classification.tsv"
    with tsv_path.open("w", newline="") as stream:
        writer = csv.writer(stream, delimiter="\t")
        writer.writerow(
            (
                "selected_edge_1",
                "selected_edge_2",
                "L11",
                "L11_vertex_cover",
                "killed_old_crossings",
                "child_crossings",
                "canonical_canonical",
                "R00_incident_edges",
                "Xuy_incident_edges",
                "Xvx_incident_edges",
                "cell_pair_histogram",
                "genuine_supplementation",
            )
        )
        for record in classified:
            writer.writerow(
                (
                    "-".join(record["selected"][0]),
                    "-".join(record["selected"][1]),
                    ",".join(record["parent_L11"]) or "empty",
                    int(record["parent_L11_is_vertex_cover"]),
                    len(record["killed_parent_crossings"]),
                    record["child_crossings"],
                    record["canonical_canonical_crossings"],
                    record["crossing_edges_incident_by_cell"]["R00"],
                    record["crossing_edges_incident_by_cell"]["Xuy"],
                    record["crossing_edges_incident_by_cell"]["Xvx"],
                    json.dumps(record["crossing_cell_pair_histogram"], sort_keys=True),
                    int(record["genuine_new_cell_supplementation_after_full_parent_kill"]),
                )
            )
    print(json.dumps(totals, sort_keys=True))
    print(json.dumps(aggregate_participation, sort_keys=True))
    print("kill_cover_selected", json.dumps([record["selected"] for record in kill_cover_moves]))
    print("json_sha256", hashlib.sha256(json_path.read_bytes()).hexdigest())
    if witness is not None:
        print("witness", HERE / "minimal_kill_cover_new_cell_supplementation_witness.json")
    print("certificate", json_path)
    print("per_move_table", tsv_path)
    print("OCTAGONAL_PRISM_NEW_CELL_SUPPLEMENTATION_CLASSIFIED")


if __name__ == "__main__":
    main()
