# Facial-square new-cell supplementation

This bundle supports Note 104.  It contains two independent checks.

1. `verify_facial_square_connector_table.py` suppresses the external
   alternating paths and verifies the six-row component table for the three
   face-assisted lifts of a parent state-\(11\) target.
2. `classify_octagonal_prism_one_step.py` reconstructs every allowed
   one-step child of the fixed Note 100 octagonal prism.  The second
   classifier restricts to its twenty-two legal-wide plane-brace children,
   identifies the two \(\mathcal L_{11}\) vertex-cover sites and classifies
   every child crossing by local cell.

## Reproduction

From the project root:

```bash
python3 units/barnette/computations/bundles/facial-square-new-cell-supplementation/verify_facial_square_connector_table.py

PYTHONHASHSEED=0 uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/facial-square-new-cell-supplementation/classify_octagonal_prism_one_step.py

PYTHONHASHSEED=0 uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/facial-square-new-cell-supplementation/classify_octagonal_prism_new_cell_supplementation.py
```

The terminal markers are

```text
FACIAL_SQUARE_CONNECTOR_TABLE_VERIFIED
OCTAGONAL_PRISM_ONE_STEP_CLASSIFIED
OCTAGONAL_PRISM_NEW_CELL_SUPPLEMENTATION_CLASSIFIED
```

The final classification JSON has SHA256

```text
37ebd049634db1425bc7feb68c40637bd679d310f76ee6235790b1b67fe2f0df
```

The frozen scope is one labelled parent and its existing twenty-two
eligible children.  It is not an order-20 census, a multi-step search or an
arbitrary-order computation.  The arbitrary-order content of Note 104 is
the analytic three-lift construction and connector table.

