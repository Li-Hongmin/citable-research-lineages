# Existence-level C4 lifting at reduced order 20

This bundle extends the complete through-order-18 theorem of Note 066 by
testing every simple plane cubic bipartite brace of order 20. It imports the
accepted embedding, brace, colouring, split, and rooted-profile routines from
the adjacent through-18 bundles, while streaming the new graph order directly
from nauty `geng`.

For every retained brace it enumerates every admissible two-gate split, every
unchanged surviving root with a nonempty reduced target family, every target
colouring in that family, and all eight assignments to the three new dual
vertices. No interface stops after its first successful assignment.

## Contents

- `census_c4_lifting_order20.py` is the exhaustive driver.
- `c4_lifting_order20_census.json` is the accepted aggregate certificate.
- `raw-output.txt` is the accepted terminal output and resource record.

## Reproduction

From the AIMath project root:

    task_run_dir=$(mktemp -d)

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/locked-boundary-escape-order20/census_c4_lifting_order20.py \
      --output "$task_run_dir/order20.json"

    cmp "$task_run_dir/order20.json" \
      units/barnette/computations/bundles/locked-boundary-escape-order20/c4_lifting_order20_census.json

The required terminal marker is

    C4_LIFTING_EXISTENCE_VERIFIED_THROUGH_REDUCED_ORDER_20

Accepted environment:

- nauty 2.9.3, using `geng -cqb -d3 -D3 20`;
- NetworkX 3.6.1;
- Python 3 via `uv`.

The trusted external interfaces are geng's isomorph-free completeness and
NetworkX's exact planarity decisions. Cubicity, bipartition, brace status,
rotations, split parity, 4-connectivity, target families, rooted cycle rank,
and all local assignments are checked directly.
