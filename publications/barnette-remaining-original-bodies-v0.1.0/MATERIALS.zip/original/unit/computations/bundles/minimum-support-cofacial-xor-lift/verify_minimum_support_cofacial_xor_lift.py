#!/usr/bin/env python3
"""Verify the explicit minimum-support cofacial XOR matching cube."""

from collections import defaultdict, deque
from itertools import product

import networkx as nx


def edge(left: str, right: str) -> frozenset[str]:
    assert left != right
    return frozenset((left, right))


def cycle_edges(vertices: tuple[str, ...]) -> frozenset[frozenset[str]]:
    return frozenset(
        edge(vertices[index], vertices[(index + 1) % len(vertices)])
        for index in range(len(vertices))
    )


def path_edges(vertices: tuple[str, ...]) -> frozenset[frozenset[str]]:
    return frozenset(
        edge(vertices[index], vertices[index + 1])
        for index in range(len(vertices) - 1)
    )


def smoothing(vertices: tuple[str, ...], state: int) -> frozenset[frozenset[str]]:
    return frozenset(
        edge(
            vertices[(2 * index + state) % len(vertices)],
            vertices[(2 * index + 1 + state) % len(vertices)],
        )
        for index in range(len(vertices) // 2)
    )


A = tuple(f"a{index}" for index in range(4))
B = tuple(f"b{index}" for index in range(12))
T = tuple(f"t{index}" for index in range(4))
X = ("x0", "x1", "x2", "x3", "x5", "x7", "x8", "x9")

COMMON_PATHS = (
    ("t0", "x0", "b1"),
    ("b0", "x1", "b10"),
    ("b11", "x2", "a0"),
    ("a1", "x3", "b2"),
    ("b3", "t1"),
    ("t2", "x5", "b5"),
    ("b4", "a2"),
    ("a3", "x7", "b6"),
    ("b7", "x8", "b9"),
    ("b8", "x9", "t3"),
)

K = frozenset(
    edge(*item)
    for item in (
        ("x0", "x1"),
        ("x2", "x3"),
        ("x7", "x8"),
        ("x5", "x9"),
        ("t0", "t1"),
        ("t2", "t3"),
    )
)

EDGES = set(cycle_edges(A) | cycle_edges(B) | K)
for path in COMMON_PATHS:
    EDGES.update(path_edges(path))
EDGES = frozenset(EDGES)
VERTICES = frozenset(A + B + T + X)

assert len(VERTICES) == 28
assert len(EDGES) == 40
assert all(len(item) == 2 for item in EDGES)


def adjacency(
    vertices: frozenset[str],
    edges: frozenset[frozenset[str]],
) -> dict[str, set[str]]:
    result = {vertex: set() for vertex in vertices}
    for item in edges:
        left, right = tuple(item)
        result[left].add(right)
        result[right].add(left)
    return result


ADJ = adjacency(VERTICES, EDGES)
assert all(len(ADJ[terminal]) == 2 for terminal in T)
assert all(len(ADJ[vertex]) == 3 for vertex in VERTICES - set(T))

# Connectedness.
seen = {"a0"}
queue = deque(("a0",))
while queue:
    vertex = queue.popleft()
    for neighbour in ADJ[vertex] - seen:
        seen.add(neighbour)
        queue.append(neighbour)
assert seen == VERTICES

# A literal bipartition.
COLOUR = {f"a{index}": index % 2 for index in range(4)}
COLOUR.update({f"b{index}": 1 ^ (index % 2) for index in range(12)})
COLOUR.update({"t0": 0, "t1": 1, "t2": 0, "t3": 1})
COLOUR.update(
    {"x0": 1, "x1": 0, "x2": 1, "x3": 0,
     "x5": 1, "x7": 0, "x8": 1, "x9": 0}
)
assert set(COLOUR) == VERTICES
assert all(COLOUR[left] != COLOUR[right] for left, right in map(tuple, EDGES))


def perfect(matching: frozenset[frozenset[str]]) -> bool:
    multiplicity = defaultdict(int)
    for item in matching:
        if item not in EDGES:
            return False
        for vertex in item:
            multiplicity[vertex] += 1
    return set(multiplicity) == VERTICES and all(value == 1 for value in multiplicity.values())


MATCHINGS = {
    (i, j): K | smoothing(A, 1 - i) | smoothing(B, 1 - j)
    for i, j in product((0, 1), repeat=2)
}
assert all(perfect(matching) for matching in MATCHINGS.values())

I = frozenset((edge("t0", "t1"), edge("t2", "t3")))
E = frozenset((edge("t0", "t3"), edge("t1", "t2")))
EXPECTED = {(0, 0): I, (1, 0): E, (0, 1): E, (1, 1): I}
EXPECTED_SIZES = {(0, 0): (14, 14), (1, 0): (10, 18),
                  (0, 1): (10, 18), (1, 1): (10, 18)}

for state, matching in MATCHINGS.items():
    complement = EDGES - matching
    graph = adjacency(VERTICES, complement)
    unseen = set(VERTICES)
    endpoint_pairs = set()
    component_sizes = []
    while unseen:
        root = min(unseen)
        component = {root}
        queue = deque((root,))
        while queue:
            vertex = queue.popleft()
            for neighbour in graph[vertex] - component:
                component.add(neighbour)
                queue.append(neighbour)
        unseen -= component
        endpoints = frozenset(vertex for vertex in component if len(graph[vertex]) == 1)
        assert endpoints <= set(T) and len(endpoints) == 2
        assert all(len(graph[vertex]) in (1, 2) for vertex in component)
        induced_edge_count = sum(len(graph[vertex]) for vertex in component) // 2
        assert induced_edge_count == len(component) - 1
        endpoint_pairs.add(endpoints)
        component_sizes.append(len(component))
    assert frozenset(endpoint_pairs) == EXPECTED[state]
    assert tuple(sorted(component_sizes)) == EXPECTED_SIZES[state]

P00 = MATCHINGS[(0, 0)]
P11 = MATCHINGS[(1, 1)]
assert P00 ^ P11 == cycle_edges(A) | cycle_edges(B)
assert len(A) + len(B) == 16

# The two required same-cycle returns on B.
assert ("b0", "x1", "b10") in COMMON_PATHS
assert ("b7", "x8", "b9") in COMMON_PATHS

# An explicit sphere rotation for the graph augmented by one common apex z.
APEX = "z"
AUGMENTED_VERTICES = VERTICES | {APEX}
AUGMENTED_EDGES = EDGES | frozenset(edge(APEX, terminal) for terminal in T)
ROTATION = {
    "a0": ("a3", "a1", "x2"), "a1": ("x3", "a0", "a2"),
    "a2": ("a1", "a3", "b4"), "a3": ("a2", "a0", "x7"),
    "b0": ("b1", "x1", "b11"), "b1": ("b2", "x0", "b0"),
    "b2": ("x3", "b3", "b1"), "b3": ("b4", "t1", "b2"),
    "b4": ("b3", "a2", "b5"), "b5": ("b4", "b6", "x5"),
    "b6": ("b7", "b5", "x7"), "b7": ("b8", "b6", "x8"),
    "b8": ("b9", "x9", "b7"), "b9": ("x8", "b10", "b8"),
    "b10": ("x1", "b9", "b11"), "b11": ("b10", "x2", "b0"),
    "t0": ("t1", "z", "x0"), "t1": ("z", "t0", "b3"),
    "t2": ("t3", "z", "x5"), "t3": ("x9", "z", "t2"),
    "x0": ("t0", "x1", "b1"), "x1": ("x0", "b10", "b0"),
    "x2": ("b11", "a0", "x3"), "x3": ("x2", "a1", "b2"),
    "x5": ("b5", "x9", "t2"), "x7": ("a3", "x8", "b6"),
    "x8": ("x7", "b9", "b7"), "x9": ("x5", "b8", "t3"),
    "z": ("t2", "t3", "t0", "t1"),
}
assert set(ROTATION) == AUGMENTED_VERTICES
AUGMENTED_ADJ = adjacency(AUGMENTED_VERTICES, AUGMENTED_EDGES)
assert all(set(ROTATION[vertex]) == AUGMENTED_ADJ[vertex] for vertex in AUGMENTED_VERTICES)

directed_seen = set()
faces = []
for left in sorted(AUGMENTED_VERTICES):
    for right in ROTATION[left]:
        if (left, right) in directed_seen:
            continue
        face = []
        current = (left, right)
        while current not in directed_seen:
            directed_seen.add(current)
            previous, vertex = current
            face.append(previous)
            neighbours = ROTATION[vertex]
            index = neighbours.index(previous)
            current = vertex, neighbours[(index - 1) % len(neighbours)]
        assert current == (left, right)
        faces.append(tuple(face))
assert len(directed_seen) == 2 * len(AUGMENTED_EDGES)
assert len(AUGMENTED_VERTICES) == 29 and len(AUGMENTED_EDGES) == 44
assert len(faces) == 17
assert len(AUGMENTED_VERTICES) - len(AUGMENTED_EDGES) + len(faces) == 2

apex_order = ROTATION[APEX]
start = apex_order.index("t0")
normalised = apex_order[start:] + apex_order[:start]
assert normalised in (("t0", "t1", "t2", "t3"), ("t0", "t3", "t2", "t1"))

# Cut the frozen embedding only along A and B.  The three Jordan regions
# have port/terminal profiles (0,0), (10,0), and (6,4), and each satisfies
# the exact signed balance law of Note 096.
class UnionFind:
    def __init__(self, size: int) -> None:
        self.parent = list(range(size))

    def find(self, item: int) -> int:
        if self.parent[item] != item:
            self.parent[item] = self.find(self.parent[item])
        return self.parent[item]

    def union(self, left: int, right: int) -> None:
        left, right = self.find(left), self.find(right)
        if left != right:
            self.parent[right] = left


dart_face = {}
for face_index, face in enumerate(faces):
    for index in range(len(face)):
        dart_face[(face[index], face[(index + 1) % len(face)])] = face_index
barriers = cycle_edges(A) | cycle_edges(B)
regions = UnionFind(len(faces))
for item in AUGMENTED_EDGES - barriers:
    left, right = tuple(item)
    regions.union(dart_face[(left, right)], dart_face[(right, left)])


def edge_region(left: str, right: str) -> int:
    return regions.find(dart_face[(left, right)])


region_ports = defaultdict(list)
for vertex in A + B:
    own_cycle = set(A if vertex in A else B)
    third = [neighbour for neighbour in ADJ[vertex] if neighbour not in own_cycle]
    assert len(third) == 1
    region_ports[edge_region(vertex, third[0])].append(vertex)
region_terminals = defaultdict(list)
for terminal in T:
    path_neighbours = [
        neighbour for neighbour in ADJ[terminal]
        if edge(terminal, neighbour) not in K
    ]
    assert len(path_neighbours) == 1
    region_terminals[edge_region(terminal, path_neighbours[0])].append(terminal)

region_ids = {regions.find(index) for index in range(len(faces))}
assert len(region_ids) == 3
for region in region_ids:
    port_sum = sum(1 if COLOUR[vertex] == 0 else -1 for vertex in region_ports[region])
    terminal_sum = sum(
        1 if COLOUR[vertex] == 0 else -1 for vertex in region_terminals[region]
    )
    assert port_sum == terminal_sum == 0
profiles = sorted(
    (len(region_ports[region]), len(region_terminals[region]))
    for region in region_ids
)
assert profiles == [(0, 0), (6, 4), (10, 0)]

# Cross-check the frozen rotation with an independent planarity test.
augmented_graph = nx.Graph()
augmented_graph.add_nodes_from(AUGMENTED_VERTICES)
augmented_graph.add_edges_from(map(tuple, AUGMENTED_EDGES))
assert nx.check_planarity(augmented_graph)[0]

print("graph: 28 vertices, 40 edges; four terminals degree 2, others degree 3")
print("complement table: 00=I, 10=E, 01=E, 11=I; closed=0")
print("diagonal: C4 dot-union C12; two same-cycle returns")
print("apex augmentation: planar with ordered terminals t0,t1,t2,t3")
print("Jordan regions: profiles (0,0), (6,4), (10,0); signed balance zero")
print("MINIMUM_SUPPORT_COFACIAL_XOR_LIFT_VERIFIED")
