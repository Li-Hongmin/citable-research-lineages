# Minimum-support cofacial XOR lift

This bundle verifies the explicit graph in Note 098.

## Environment and reproduction

- Python 3.12
- NetworkX 3.5 or a compatible 3.x release

From the AIMath project root run

```bash
uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/minimum-support-cofacial-xor-lift/verify_minimum_support_cofacial_xor_lift.py
```

The final line must be

```text
MINIMUM_SUPPORT_COFACIAL_XOR_LIFT_VERIFIED
```

The verifier hard-codes the graph rather than searching for it.  It checks
the vertex and edge counts, simplicity, connectedness, degrees,
bipartition, the six-edge common matching, all four perfect matchings, all
four two-path complement signatures, absence of closed components, the
\(C_4\dot\cup C_{12}\) diagonal, and an explicit planar rotation after
adding a common terminal apex.

## Scope

The bundle certifies the positive sixteen-port example.  Minimality of the
toggle-port count is the separate complete classification in the Note 097
bundle.  No vertex-order minimality, legal-wide attachment, brace property
or complete-fibre assertion is tested here.
