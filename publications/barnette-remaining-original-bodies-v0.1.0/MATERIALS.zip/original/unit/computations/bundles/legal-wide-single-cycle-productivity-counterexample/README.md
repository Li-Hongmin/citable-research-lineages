# Legal-wide single-cycle productivity counterexample

This bundle verifies the explicit order-(24\to28) plane-brace endpoint in
Note 130.  It imports the permanent predicate implementation frozen for
[Note 128](../good-sibling-portal-dichotomy/README.md), but it does not import
the exploratory three-cube search.

The verifier checks the following claims directly from the displayed edge
set and decoration:

- the parent and child are cubic bipartite planar braces of vertex
  connectivity three;
- the expansion is interface-disjoint and legal-wide, with gate arcs
  ((5,7));
- the displayed matching is a sterile state-(11) rooted endpoint;
- ((|\mathcal M_\chi|,|\mathcal E_\chi|,|\mathcal X^b|)=(2,0,2));
- every mixed-neighbour/child-target incidence misses retained demand, and
  the phase-portal family is empty.
- each target has exact rooted-fibre witness-cover number three; the entire
  same-label family misses the demand edge (9\!-!13).

Run from the AIMath root:

```bash
uv run --python 3.12 --with networkx==3.6.1 \
  python units/barnette/computations/bundles/legal-wide-single-cycle-productivity-counterexample/verify_legal_wide_single_cycle_productivity_counterexample.py
```

The terminal marker is

```text
LEGAL_WIDE_SINGLE_CYCLE_PRODUCTIVITY_COUNTEREXAMPLE_VERIFIED
```

This is an existence certificate.  It does not claim that order 24 is
minimum, classify all three-cube decorations, or refute (H^{+-})
preservation itself.
