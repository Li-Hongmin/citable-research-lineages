#!/usr/bin/env python3
"""Verify a legal-wide plane-brace counterexample to the Note-128 G-or-P claim."""

from __future__ import annotations

from collections import Counter
import contextlib
import importlib.util
import io
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
NOTE128 = (
    BARNETTE
    / "computations/bundles/good-sibling-portal-dichotomy"
    / "verify_frozen_good_sibling_portal_dichotomy.py"
)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(module)
    return module


note128 = load_module(NOTE128, "single_cycle_counterexample_note128")
note110 = note128.note110
nx = note128.nx
edge = note110.edge


PARENT_EDGES = {
    (0, 2), (0, 4), (0, 9), (1, 3), (1, 5), (1, 8),
    (2, 6), (2, 11), (3, 7), (3, 10), (4, 5), (4, 6),
    (5, 7), (6, 7), (8, 10), (8, 16), (9, 11), (9, 13),
    (10, 18), (11, 15), (12, 13), (12, 14), (12, 20),
    (13, 15), (14, 15), (14, 22), (16, 17), (16, 20),
    (17, 19), (17, 21), (18, 19), (18, 22), (19, 23),
    (20, 21), (21, 23), (22, 23),
}
ROOT = (1, 8)
FORCED = (3, 10)
SURVIVING = (2, 11)
SELECTED = frozenset({(0, 9), (16, 20)})
CHI = frozenset(
    {
        (0, 9), (1, 8), (2, 11), (3, 10), (4, 6), (5, 7),
        (12, 14), (13, 15), (16, 20), (17, 21), (18, 19),
        (22, 23),
    }
)


def minimum_cover_size(demand, candidates):
    demand_edges = tuple(sorted(demand))
    full = (1 << len(demand_edges)) - 1
    masks = {
        sum(
            1 << index
            for index, item in enumerate(demand_edges)
            if item in matching
        )
        for matching in candidates
    }
    distance = {0: 0}
    for mask in masks:
        for covered, size in tuple(distance.items()):
            updated = covered | mask
            distance[updated] = min(distance.get(updated, len(candidates) + 1), size + 1)
    return distance.get(full)


def embedded_faces(graph):
    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    faces = note110.source.plane_faces(graph, embedding)
    note110.validate_faces(graph, faces)
    return faces


def site_record(faces):
    witnesses = []
    for face_index, face in enumerate(faces):
        boundary = note110.face_edges(face)
        if SELECTED <= set(boundary):
            indices = tuple(sorted(boundary.index(item) for item in SELECTED))
            witnesses.append(
                {
                    "face_index": face_index,
                    "face_length": len(face),
                    "indices": indices,
                    "selected": tuple(boundary[index] for index in indices),
                }
            )
    assert len(witnesses) == 1
    return witnesses[0]


def main():
    parent = nx.Graph()
    parent.add_nodes_from(range(24))
    parent.add_edges_from(PARENT_EDGES)
    assert parent.number_of_edges() == 36
    assert set(dict(parent.degree()).values()) == {3}
    assert nx.is_bipartite(parent)

    faces = embedded_faces(parent)
    assert Counter(map(len, faces)) == {4: 10, 6: 2, 10: 2}
    assert nx.node_connectivity(parent) == 3
    parent_brace = note110.lift.verify_brace(parent)
    assert parent_brace["independent_two_edge_matchings_checked"] == 558

    site = site_record(faces)
    assert site["face_length"] == 10
    child, child_faces, local = note110.expand_on_face(parent, faces, site)
    assert child.number_of_nodes() == 28
    assert set(dict(child.degree()).values()) == {3}
    assert nx.is_bipartite(child)
    assert nx.node_connectivity(child) == 3
    child_brace = note110.lift.verify_brace(child)
    assert child_brace["independent_two_edge_matchings_checked"] == 777

    root_square = next(
        face
        for face in faces
        if len(face) == 4
        and ROOT in note110.face_edges(face)
        and FORCED in note110.face_edges(face)
    )
    root_boundary = note110.face_edges(root_square)
    assert root_boundary.index(ROOT) % 2 == root_boundary.index(FORCED) % 2
    interface_vertices = frozenset(root_square) | frozenset(SURVIVING)
    site_vertices = frozenset(vertex for item in SELECTED for vertex in item)
    assert not (interface_vertices & site_vertices)
    assert note110.legal_wide_arcs(child_faces, ROOT, FORCED, SURVIVING) == (5, 7)

    parent_matchings = note110.enumerate_perfect_matchings(parent)
    parent_fibre = tuple(
        matching
        for matching in parent_matchings
        if note110.is_root_target(parent, matching, ROOT, FORCED)
    )
    assert len(parent_matchings) == 244
    assert len(parent_fibre) == 17
    assert CHI in parent_fibre and SELECTED <= CHI

    child_matchings = note110.enumerate_perfect_matchings(child)
    child_fibre = tuple(
        matching
        for matching in child_matchings
        if note110.is_root_target(child, matching, ROOT, FORCED)
    )
    child_fibre_set = frozenset(child_fibre)
    cells = {matching: note110.local_cell(matching, local) for matching in child_fibre}
    assert len(child_matchings) == 392
    assert len(child_fibre) == 25

    direct = note128.direct_lifts(CHI, faces[site["face_index"]], site, local)
    assert not any(matching in child_fibre_set for matching in direct.values())

    sector = SURVIVING in CHI
    mixed = tuple(
        matching
        for matching in parent_fibre
        if (SURVIVING in matching) != sector
        and not SELECTED <= matching
        and note110.difference_component_count(CHI, matching) == 1
    )
    escapes = tuple(
        matching
        for matching in parent_fibre
        if (SURVIVING in matching) == sector
        and not SELECTED <= matching
        and note110.difference_component_count(CHI, matching) == 1
    )
    targets = tuple(
        matching
        for matching in child_fibre
        if (SURVIVING in matching) == sector
        and cells[matching] in {"R00", "Xuy", "Xvx"}
    )
    assert (len(mixed), len(escapes), len(targets)) == (2, 0, 2)
    assert {cells[matching] for matching in targets} == {"Xuy"}

    retained = frozenset(edge(*item) for item in parent.edges) - SELECTED
    missing_by_good_pair = tuple(
        tuple(sorted((target & retained) - (CHI | matching)))
        for matching in mixed
        for target in targets
    )
    assert missing_by_good_pair == (
        ((12, 20), (14, 15), (17, 19), (18, 22), (21, 23)),
        ((12, 20), (14, 15)),
        ((9, 13), (12, 20), (14, 15), (17, 19), (18, 22), (21, 23)),
        ((9, 13), (12, 20), (14, 15)),
    )

    fibre_set = frozenset(parent_fibre)
    labels = frozenset({ROOT, FORCED, SURVIVING})
    same_label_nonrooted = tuple(
        matching
        for matching in parent_matchings
        if ROOT in matching
        and FORCED in matching
        and (SURVIVING in matching) == sector
        and matching not in fibre_set
    )
    phase_portals = tuple(
        matching
        for matching in same_label_nonrooted
        if SELECTED <= (matching ^ CHI)
        and not ((matching ^ CHI) & labels)
        and not (SELECTED & matching)
        and note110.difference_component_count(CHI, matching) == 1
    )
    assert len(same_label_nonrooted) == 19
    assert not phase_portals

    demands = frozenset((target & retained) - CHI for target in targets)
    assert demands == frozenset(
        {
            frozenset({(9, 13), (12, 20), (14, 15)}),
            frozenset(
                {
                    (9, 13), (12, 20), (14, 15),
                    (17, 19), (18, 22), (21, 23),
                }
            ),
        }
    )
    same_labels = tuple(
        matching
        for matching in parent_matchings
        if ROOT in matching and FORCED in matching and SURVIVING in matching
    )
    any_single_component = tuple(
        matching
        for matching in parent_matchings
        if note110.difference_component_count(CHI, matching) == 1
    )
    phase_any_components = tuple(
        matching
        for matching in same_label_nonrooted
        if SELECTED <= (matching ^ CHI)
        and not ((matching ^ CHI) & labels)
        and not (SELECTED & matching)
    )
    assert len(same_labels) == 22
    assert len(any_single_component) == 21
    assert not phase_any_components
    assert {
        minimum_cover_size(demand, parent_fibre) for demand in demands
    } == {3}
    assert {
        minimum_cover_size(demand, any_single_component) for demand in demands
    } == {1, 2}
    assert {
        item for demand in demands for item in demand
        if all(item not in matching for matching in same_labels)
    } == {(9, 13)}

    print("parent_child_pm", (len(parent_matchings), len(child_matchings)))
    print("parent_child_rooted_fibre", (len(parent_fibre), len(child_fibre)))
    print("M_E_X", (len(mixed), len(escapes), len(targets)))
    print("G_missing_retained_edges", missing_by_good_pair)
    print("same_label_nonrooted_phase_portals", (len(same_label_nonrooted), len(phase_portals)))
    print("rooted_minimum_cover_sizes", tuple(sorted(minimum_cover_size(demand, parent_fibre) for demand in demands)))
    print("same_label_uncovered_demand_edge", (9, 13))
    print("legal_wide_arcs", (5, 7))
    print("LEGAL_WIDE_SINGLE_CYCLE_PRODUCTIVITY_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
