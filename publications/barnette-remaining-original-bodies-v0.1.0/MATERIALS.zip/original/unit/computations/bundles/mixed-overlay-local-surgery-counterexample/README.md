# Mixed-overlay local-surgery counterexample

This bundle supports [Note 125](../../../notes/125-a-prescribed-mixed-hamilton-overlay-need-not-contain-its-escape.md).
It freezes one actual order-(24) legal-wide plane-brace split for which the
Boolean same-sector escape exists, but the lexicographically first mixed
Hamilton overlay contains no such escape under any proper-arc surgery.

For a fixed mixed pair ((M_\chi,M_\eta)), the verified surgery class is

\[
 N^+\cap E_0\subseteq(M_\chi\cup M_\eta)\cap E_0,
 \qquad E_0=E(G)\setminus\{p,q\},
\]

with all seven local (C_4)-patch matching patterns allowed.  This is
exactly the class obtained by switching proper arcs of the single
alternating cycle (M_\chi\triangle M_\eta) and repairing all possible
(0/2/4) exposed ports inside the patch.

For mixed ordinal (0), the five resulting child rows are

| cell | root-separated | sector | accepted |
|---|:---:|:---:|:---:|
| (R_{00}) | no | 0 | no |
| (C_{00}) | yes | 0 | no |
| (X_{vx}) | yes | 0 | no |
| (X_{uy}) | no | 1 | no |
| (C_{11}) | no | 1 | no |

Thus the Hamiltonian hybrid lies in the wrong gate sector, while the
same-sector hybrid is not root-separated.  The complete child family still
contains two same-sector (X_{uy}) targets.  They are overlay-local for
mixed siblings (3) and (4), respectively, not for ordinal (0).

## Reproduction

From the AIMath project root, run

```bash
python3 units/barnette/computations/bundles/mixed-overlay-local-surgery-counterexample/verify_hit29_overlay_local_surgery_counterexample.py
```

The terminal marker is

```text
HIT29_OVERLAY_LOCAL_SURGERY_COUNTEREXAMPLE_VERIFIED
```

The program uses only the Python standard library.  It reconstructs the
parent and child from literal graph6 and face data, verifies the legal-wide
plane cubic bipartite brace conditions, enumerates every perfect matching,
and recomputes the root, sector, cell, single-cycle, overlay, and surgery
predicates.  It does not read a frozen JSON table or import a project
classifier.

The frozen run used CPython 3.14.6 and took 0.03 s.  The source hash is

```text
3d4772e0e02d446f55e59604b041da626bb5224ce6bcb1fef6b1653c51ad3f14  verify_hit29_overlay_local_surgery_counterexample.py
```

The bundle refutes only prescribed two-target overlay surgery.  It does not
refute the Boolean adjacent-escape statement: the fixed complete family
escapes by selecting a different mixed sibling.
