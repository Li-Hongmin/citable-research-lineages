#!/usr/bin/env python3
"""Independent certificate for the hit-29 overlay-local surgery boundary.

The script reads no project classifier, frozen endpoint table, or JSON file.
It reconstructs the parent from one graph6 literal, verifies the displayed
sphere embedding and the legal wide C4 expansion, enumerates every parent and
child perfect matching, performs root smoothing with distinguished parallel
edges, and exhausts the precisely defined overlay-local surgery class.
"""

from __future__ import annotations

from collections import Counter, deque


GRAPH6 = "W???????????w?s?P_BC?I_?L??J??B_?AW??F??_W?AC_?"
FACES = (
    (0, 13, 1, 12),
    (0, 14, 5, 18, 8, 23, 3, 13),
    (0, 12, 2, 16, 4, 14),
    (1, 13, 3, 22, 10, 20, 6, 15),
    (1, 15, 2, 12),
    (2, 15, 6, 16),
    (3, 23, 11, 22),
    (4, 17, 5, 14),
    (4, 16, 6, 20, 9, 19, 7, 17),
    (5, 17, 7, 18),
    (7, 19, 8, 18),
    (8, 19, 9, 21, 11, 23),
    (9, 20, 10, 21),
    (10, 22, 11, 21),
)
ROOT = (7, 17)
FORCED_GATE = (5, 18)
SURVIVING_GATE = (3, 13)
ROOT_GATE_SQUARE = (7, 17, 5, 18)
FACE_INDEX = 3
SITE_INDICES = (3, 7)
SITE = frozenset({(1, 15), (10, 22)})
CHI = frozenset(
    {
        (0, 12), (1, 15), (2, 16), (3, 13), (4, 14), (5, 18),
        (6, 20), (7, 17), (8, 19), (9, 21), (10, 22), (11, 23),
    }
)
NEW_TYPES = frozenset({"R00", "Xuy", "Xvx"})


def edge(left: int, right: int) -> tuple[int, int]:
    return (left, right) if left < right else (right, left)


def decode_graph6(value: str):
    data = [ord(character) - 63 for character in value]
    assert data and data[0] < 63 and all(0 <= item < 64 for item in data)
    order = data[0]
    bits = [
        (item >> shift) & 1
        for item in data[1:]
        for shift in range(5, -1, -1)
    ]
    needed = order * (order - 1) // 2
    assert len(bits) >= needed and not any(bits[needed:])
    edges = set()
    position = 0
    for right in range(1, order):
        for left in range(right):
            if bits[position]:
                edges.add((left, right))
            position += 1
    return tuple(range(order)), frozenset(edges)


def adjacency(vertices, edges):
    graph = {vertex: set() for vertex in vertices}
    for left, right in edges:
        assert left in graph and right in graph and left != right
        graph[left].add(right)
        graph[right].add(left)
    return graph


def components(vertices, edges):
    graph = adjacency(vertices, edges)
    remaining = set(vertices)
    result = []
    while remaining:
        start = remaining.pop()
        component = {start}
        stack = [start]
        while stack:
            current = stack.pop()
            for other in graph[current] & remaining:
                remaining.remove(other)
                component.add(other)
                stack.append(other)
        result.append(frozenset(component))
    return tuple(result)


def validate_bipartite(vertices, edges):
    graph = adjacency(vertices, edges)
    colour = {}
    for start in vertices:
        if start in colour:
            continue
        colour[start] = 0
        queue = deque([start])
        while queue:
            current = queue.popleft()
            for other in graph[current]:
                if other not in colour:
                    colour[other] = 1 - colour[current]
                    queue.append(other)
                else:
                    assert colour[other] != colour[current]
    return colour


def validate_sphere_embedding(vertices, edges, faces):
    graph = adjacency(vertices, edges)
    darts = []
    successor = {vertex: {} for vertex in vertices}
    for face in faces:
        assert len(face) == len(set(face)) >= 3
        for index, current in enumerate(face):
            previous = face[index - 1]
            following = face[(index + 1) % len(face)]
            assert edge(current, following) in edges
            darts.append((current, following))
            assert previous not in successor[current]
            successor[current][previous] = following
    expected = {
        dart for left, right in edges for dart in ((left, right), (right, left))
    }
    assert len(darts) == len(set(darts)) and set(darts) == expected
    for vertex in vertices:
        assert set(successor[vertex]) == graph[vertex]
        assert set(successor[vertex].values()) == graph[vertex]
    assert len(vertices) - len(edges) + len(faces) == 2


def validate_plane_cubic_bipartite(vertices, edges, faces):
    assert len(components(vertices, edges)) == 1
    assert {len(items) for items in adjacency(vertices, edges).values()} == {3}
    validate_bipartite(vertices, edges)
    validate_sphere_embedding(vertices, edges, faces)


def matching_key(matching):
    return tuple(sorted(matching))


def enumerate_perfect_matchings(vertices, edges):
    graph = adjacency(vertices, edges)
    result = []

    def recurse(unmatched, chosen):
        if not unmatched:
            result.append(frozenset(chosen))
            return
        first = min(unmatched, key=lambda v: (len(graph[v] & unmatched), v))
        for second in sorted(graph[first] & unmatched):
            recurse(unmatched - {first, second}, chosen + [edge(first, second)])

    recurse(set(vertices), [])
    assert len(result) == len(set(result))
    return tuple(sorted(result, key=matching_key))


def complement_components(vertices, edges, matching):
    complement = edges - matching
    assert {len(items) for items in adjacency(vertices, complement).values()} == {2}
    return components(vertices, complement)


def root_target(vertices, edges, matching):
    if ROOT not in matching or FORCED_GATE not in matching:
        return False
    cycles = complement_components(vertices, edges, matching)
    return len(cycles) == 2 and all(
        len(set(ROOT) & component) == 1 for component in cycles
    )


def difference_component_count(first, second):
    difference = first ^ second
    if not difference:
        return 0
    vertices = tuple(sorted({vertex for item in difference for vertex in item}))
    graph = adjacency(vertices, difference)
    assert {len(graph[vertex]) for vertex in vertices} == {2}
    return len(components(vertices, difference))


def replace_dart(face, left, right, inserted):
    positions = [
        index
        for index in range(len(face))
        if face[index] == left and face[(index + 1) % len(face)] == right
    ]
    if not positions:
        return face
    assert len(positions) == 1
    index = positions[0]
    rotated = face[index:] + face[:index]
    return (left,) + inserted + (right,) + rotated[2:]


def expand(vertices, edges, faces):
    first_index, second_index = SITE_INDICES
    face = faces[FACE_INDEX]
    u, v = face[first_index], face[(first_index + 1) % len(face)]
    x, y = face[second_index], face[(second_index + 1) % len(face)]
    first, second = edge(u, v), edge(x, y)
    assert frozenset({first, second}) == SITE
    assert not (set(first) & set(second))
    a, b, c, d = range(max(vertices) + 1, max(vertices) + 5)
    child_vertices = vertices + (a, b, c, d)
    child_edges = set(edges - {first, second})
    child_edges.update(
        {
            edge(u, a), edge(a, b), edge(b, v),
            edge(x, c), edge(c, d), edge(d, y),
            edge(a, d), edge(b, c),
        }
    )
    child_faces = []
    for index, old_face in enumerate(faces):
        if index == FACE_INDEX:
            continue
        new_face = replace_dart(old_face, v, u, (b, a))
        new_face = replace_dart(new_face, y, x, (d, c))
        child_faces.append(new_face)
    child_faces.extend(
        (
            face[first_index + 1 : second_index + 1] + (c, b),
            face[second_index + 1 :] + face[: first_index + 1] + (a, d),
            (a, b, c, d),
        )
    )
    local = (
        edge(u, a), edge(a, b), edge(b, v),
        edge(x, c), edge(c, d), edge(d, y),
        edge(a, d), edge(b, c),
    )
    port_stubs = {
        edge(u, a): u, edge(b, v): v, edge(x, c): x, edge(d, y): y
    }
    return (
        child_vertices,
        frozenset(child_edges),
        tuple(child_faces),
        local,
        port_stubs,
        face,
        (first, second),
    )


def face_edges(face):
    return tuple(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def verify_legal_wide(child_faces):
    square_rotations = {
        tuple(ROOT_GATE_SQUARE[index:] + ROOT_GATE_SQUARE[:index])
        for index in range(4)
    }
    assert any(
        face in square_rotations
        or tuple(reversed(face)) in square_rotations
        for face in child_faces
    )
    witnesses = []
    for face in child_faces:
        boundary = face_edges(face)
        if FORCED_GATE not in boundary or SURVIVING_GATE not in boundary:
            continue
        assert ROOT not in boundary
        delta = (
            boundary.index(SURVIVING_GATE) - boundary.index(FORCED_GATE)
        ) % len(boundary)
        arcs = tuple(sorted((delta + 1, len(boundary) - delta + 1)))
        if min(arcs) >= 5 and all(length % 2 for length in arcs):
            witnesses.append(arcs)
    assert witnesses == [(5, 5)]


def local_cell(matching, local):
    ua, ab, bv, xc, cd, dy, ad, bc = local
    patterns = {
        frozenset((ad, bc)): "C00",
        frozenset((ua, bv, cd)): "C10",
        frozenset((xc, dy, ab)): "C01",
        frozenset((ua, bv, xc, dy)): "C11",
        frozenset((ab, cd)): "R00",
        frozenset((ua, bc, dy)): "Xuy",
        frozenset((ad, bv, xc)): "Xvx",
    }
    patch = matching & frozenset(local)
    assert patch in patterns
    return patterns[patch]


def path_edges(vertices):
    return frozenset(edge(left, right) for left, right in zip(vertices, vertices[1:]))


def direct_lifts(parent, site_face, selected, local):
    first_index, second_index = SITE_INDICES
    first, second = selected
    assert first in parent and second in parent
    arc_a = path_edges(site_face[first_index + 1 : second_index + 1])
    arc_b = path_edges(
        site_face[second_index + 1 :] + site_face[: first_index + 1]
    )
    ua, ab, bv, xc, cd, dy, ad, bc = local
    common = parent - {first, second}
    return {
        "Xuy": frozenset((common ^ arc_a) | {ua, bc, dy}),
        "Xvx": frozenset((common ^ arc_b) | {ad, bv, xc}),
        "R00": frozenset((common ^ arc_a ^ arc_b) | {ab, cd}),
    }


def normal_cycle(edges):
    vertices = tuple(sorted({vertex for item in edges for vertex in item}))
    graph = adjacency(vertices, edges)
    assert {len(graph[vertex]) for vertex in vertices} == {2}
    start = min(vertices)
    sequences = []
    for following in sorted(graph[start]):
        sequence = [start, following]
        previous, current = start, following
        while True:
            successor = next(iter(graph[current] - {previous}))
            if successor == start:
                break
            sequence.append(successor)
            previous, current = current, successor
        sequences.append(tuple(sequence))
    return min(sequences)


def smoothed_cycle(vertices, edges, matching):
    """Return edge-labelled Hamilton cycle in the root-smoothed multigraph."""
    r, s = ROOT
    graph = adjacency(vertices, edges)
    assert graph[r] - {s} == {18, 19}
    assert graph[s] - {r} == {4, 5}
    old = {
        ("e", left, right)
        for left, right in edges - matching
        if r not in (left, right) and s not in (left, right)
    }
    cycle = old | {("a", 5, 18), ("d", 4, 19)}
    smooth_vertices = tuple(vertex for vertex in vertices if vertex not in ROOT)
    incidence = {vertex: [] for vertex in smooth_vertices}
    for item in cycle:
        _, left, right = item
        incidence[left].append(item)
        incidence[right].append(item)
    assert {len(items) for items in incidence.values()} == {2}
    simple_edges = frozenset(edge(item[1], item[2]) for item in cycle)
    # The only possible parallel pair is a versus the old forced gate, which
    # is absent from every rooted Hamilton cycle because it lies in matching.
    assert len(simple_edges) == len(cycle)
    assert len(components(smooth_vertices, simple_edges)) == 1
    return frozenset(cycle)


def common_path_data(first_cycle, second_cycle, difference_cycle):
    common = first_cycle & second_cycle
    graph = {}
    for item in common:
        label, left, right = item
        graph.setdefault(left, []).append((right, label, item))
        graph.setdefault(right, []).append((left, label, item))
    assert {len(items) for items in graph.values()} <= {1, 2}
    unseen = set(common)
    paths = []
    for start in sorted(vertex for vertex, items in graph.items() if len(items) == 1):
        if not any(item in unseen for _, _, item in graph[start]):
            continue
        vertices = [start]
        labels = []
        previous = None
        current = start
        while True:
            choices = [entry for entry in graph[current] if entry[0] != previous]
            if not choices:
                break
            following, label, item = choices[0]
            assert item in unseen
            unseen.remove(item)
            vertices.append(following)
            labels.append(label)
            previous, current = current, following
        if vertices[0] > vertices[-1]:
            vertices.reverse()
            labels.reverse()
        paths.append((tuple(vertices), tuple(labels)))
    assert not unseen
    paths.sort()
    difference_vertices = set(difference_cycle)
    endpoints = [vertex for vertices, _ in paths for vertex in (vertices[0], vertices[-1])]
    assert len(endpoints) == len(set(endpoints)) == len(difference_vertices)
    assert set(endpoints) == difference_vertices
    return tuple(paths)


def contracted_overlay_is_hamiltonian(paths, difference, matching):
    pairing = frozenset(edge(vertices[0], vertices[-1]) for vertices, _ in paths)
    selected = frozenset(item for item in difference if item not in matching)
    graph_edges = pairing | selected
    vertices = tuple(sorted({vertex for item in difference for vertex in item}))
    assert {len(items) for items in adjacency(vertices, graph_edges).values()} == {2}
    return len(components(vertices, graph_edges)) == 1


def surgery_rows(
    parent_matchings,
    child_matchings,
    parent_fibre,
    child_fibre,
    child_local,
    port_stubs,
    eta,
):
    difference = CHI ^ eta
    retained = parent_edges - SITE
    overlay_edges = (CHI | eta) & retained

    # In the parent there is no repair patch.  A matching whose change from
    # CHI is confined to K is precisely an endpoint-free K-arc surgery.
    parent_candidates = tuple(
        matching for matching in parent_matchings if (matching ^ CHI) <= difference
    )
    parent_accepted = tuple(
        matching
        for matching in parent_candidates
        if matching in parent_fibre
        and (SURVIVING_GATE in matching) == (SURVIVING_GATE in CHI)
        and not SITE <= matching
    )

    # In the child, every retained matching edge must come from CHI or eta.
    # Perfect-matching degree then forces constant alternating choices on each
    # proper K-arc between site ports.  The seven possible local patterns are
    # already exhaustive because every child perfect matching has one of them.
    child_candidates = tuple(
        matching
        for matching in child_matchings
        if (matching & retained) <= overlay_edges
    )
    rows = []
    for matching in child_candidates:
        cell = local_cell(matching, child_local)
        endpoints = tuple(
            sorted(port for stub, port in port_stubs.items() if stub not in matching)
        )
        assert len(endpoints) in {0, 2, 4}
        rooted = matching in child_fibre
        sector = int(SURVIVING_GATE in matching)
        accepted = rooted and sector == int(SURVIVING_GATE in CHI) and cell in NEW_TYPES
        rows.append((matching_key(matching), cell, endpoints, rooted, sector, accepted))
    rows.sort()
    return parent_candidates, parent_accepted, tuple(rows)


def main():
    global parent_edges
    parent_vertices, parent_edges = decode_graph6(GRAPH6)
    validate_plane_cubic_bipartite(parent_vertices, parent_edges, FACES)
    assert ROOT in parent_edges and FORCED_GATE in parent_edges
    assert not (set(ROOT) & {vertex for item in SITE for vertex in item})
    assert FORCED_GATE not in SITE
    assert SURVIVING_GATE not in SITE

    parent_matchings = enumerate_perfect_matchings(parent_vertices, parent_edges)
    assert len(parent_matchings) == 200 and CHI in parent_matchings
    parent_fibre = frozenset(
        matching
        for matching in parent_matchings
        if root_target(parent_vertices, parent_edges, matching)
    )
    assert len(parent_fibre) == 13 and CHI in parent_fibre
    assert SITE <= CHI and SURVIVING_GATE in CHI

    (
        child_vertices,
        child_edges,
        child_faces,
        child_local,
        port_stubs,
        site_face,
        selected,
    ) = expand(parent_vertices, parent_edges, FACES)
    validate_plane_cubic_bipartite(child_vertices, child_edges, child_faces)
    verify_legal_wide(child_faces)
    child_matchings = enumerate_perfect_matchings(child_vertices, child_edges)
    assert len(child_matchings) == 388
    child_fibre = frozenset(
        matching
        for matching in child_matchings
        if root_target(child_vertices, child_edges, matching)
    )
    assert len(child_fibre) == 22
    cell_of = {matching: local_cell(matching, child_local) for matching in child_fibre}
    assert Counter(cell_of.values()) == Counter(
        {"C00": 8, "C01": 2, "C10": 2, "R00": 6, "Xuy": 2, "Xvx": 2}
    )

    # Recompute sterility: all three direct new-cell lifts of CHI are perfect
    # matchings, but none is a rooted target.
    child_matching_set = frozenset(child_matchings)
    direct = direct_lifts(CHI, site_face, selected, child_local)
    assert set(direct) == NEW_TYPES
    assert all(matching in child_matching_set for matching in direct.values())
    assert not any(matching in child_fibre for matching in direct.values())

    bit = int(SURVIVING_GATE in CHI)
    mixed = tuple(
        matching
        for matching in sorted(parent_fibre, key=matching_key)
        if (SURVIVING_GATE in matching) != bool(bit)
        and not SITE <= matching
        and difference_component_count(CHI, matching) == 1
    )
    escape = tuple(
        matching
        for matching in parent_fibre
        if (SURVIVING_GATE in matching) == bool(bit)
        and not SITE <= matching
        and difference_component_count(CHI, matching) == 1
    )
    targets = tuple(
        matching
        for matching in sorted(child_fibre, key=matching_key)
        if (SURVIVING_GATE in matching) == bool(bit)
        and cell_of[matching] in NEW_TYPES
    )
    assert (len(mixed), len(escape), len(targets)) == (6, 0, 2)
    assert tuple(cell_of[matching] for matching in targets) == ("Xuy", "Xuy")

    overlay_records = []
    surgery_records = []
    for ordinal, eta in enumerate(mixed):
        difference = CHI ^ eta
        cycle = normal_cycle(difference)
        assert len(cycle) == len(difference) == 14
        chi_cycle = smoothed_cycle(parent_vertices, parent_edges, CHI)
        eta_cycle = smoothed_cycle(parent_vertices, parent_edges, eta)
        assert frozenset(
            edge(item[1], item[2]) for item in chi_cycle ^ eta_cycle
        ) == difference
        paths = common_path_data(chi_cycle, eta_cycle, cycle)
        assert len(paths) == 7
        assert contracted_overlay_is_hamiltonian(paths, difference, CHI)
        assert contracted_overlay_is_hamiltonian(paths, difference, eta)
        overlay_records.append(
            {
                "ordinal": ordinal,
                "eta": matching_key(eta),
                "K": cycle,
                "common_path_pairing": tuple(
                    (vertices[0], vertices[-1]) for vertices, _ in paths
                ),
                "common_paths": paths,
            }
        )

        parent_candidates, parent_accepted, rows = surgery_rows(
            parent_matchings,
            child_matchings,
            parent_fibre,
            child_fibre,
            child_local,
            port_stubs,
            eta,
        )
        assert len(parent_candidates) == 2
        assert frozenset(parent_candidates) == frozenset({CHI, eta})
        assert not parent_accepted
        surgery_records.append(
            {
                "ordinal": ordinal,
                "child_candidate_count": len(rows),
                "accepted_count": sum(row[-1] for row in rows),
                "rows": tuple(
                    {
                        "cell": row[1],
                        "repaired_endpoints": row[2],
                        "rooted": row[3],
                        "sector": row[4],
                        "accepted": row[5],
                    }
                    for row in rows
                ),
            }
        )

    assert tuple(record["child_candidate_count"] for record in surgery_records) == (
        5, 5, 2, 5, 5, 2
    )
    assert tuple(record["accepted_count"] for record in surgery_records) == (
        0, 0, 0, 1, 1, 0
    )

    # The four state-00 mixed neighbours have exactly the two natural hybrid
    # two-arc rows Xuy and Xvx.  Exactly one hybrid is rooted in every case,
    # agreeing with the unlabelled Hamilton-path observation.  For ordinals
    # 0 and 1, however, the rooted hybrid is in sector 0 while the sector-1
    # hybrid is not rooted; the required same-sector strengthening is false.
    state00_ordinals = tuple(
        ordinal for ordinal, eta in enumerate(mixed) if not (SITE & eta)
    )
    assert state00_ordinals == (0, 1, 3, 4)
    hybrid_profiles = []
    for ordinal in state00_ordinals:
        hybrid_rows = {
            row["cell"]: (row["rooted"], row["sector"], row["accepted"])
            for row in surgery_records[ordinal]["rows"]
            if row["cell"] in {"Xuy", "Xvx"}
        }
        assert set(hybrid_rows) == {"Xuy", "Xvx"}
        assert sum(value[0] for value in hybrid_rows.values()) == 1
        hybrid_profiles.append((ordinal, hybrid_rows))
    assert tuple(ordinal for ordinal, rows in hybrid_profiles if not any(
        value[2] for value in rows.values()
    )) == (0, 1)
    failed_ordinals = tuple(
        record["ordinal"]
        for record in surgery_records
        if record["accepted_count"] == 0
    )
    assert failed_ordinals == (0, 1, 2, 5)

    # Ordinal 0 is the lexicographically first mixed neighbour and the minimum
    # fixed counterexample.  Both genuine Boolean X targets use a retained old
    # matching edge absent from CHI union eta, hence neither may be smuggled
    # into the overlay-local construction.
    eta0 = mixed[0]
    retained = parent_edges - SITE
    overlay0 = (CHI | eta0) & retained
    target_extra_edges = tuple(
        tuple(sorted((target & retained) - overlay0)) for target in targets
    )
    assert target_extra_edges == (((10, 20),), ((6, 15),))

    # Each one-edge escape is supplied by a unique *other* mixed neighbour of
    # CHI.  There are five parent rooted targets containing either extra edge,
    # but exactly one of them is a single-cycle mixed neighbour of CHI.  Those
    # unique siblings are ordinals 3 and 4, respectively, and CHI union that
    # sibling already covers the target's retained-old matching support.  The
    # repair is therefore not a genuine three-target overlay.
    sibling_records = []
    for target, extra, sibling_ordinal in zip(
        targets, target_extra_edges, (3, 4), strict=True
    ):
        extra_set = frozenset(extra)
        suppliers = tuple(
            matching
            for matching in sorted(parent_fibre, key=matching_key)
            if matching not in {CHI, eta0} and extra_set <= matching
        )
        mixed_suppliers = tuple(matching for matching in mixed if extra_set <= matching)
        assert len(suppliers) == 5
        assert mixed_suppliers == (mixed[sibling_ordinal],)
        sibling = mixed_suppliers[0]
        assert not SITE & sibling
        assert not (SURVIVING_GATE in sibling)
        assert (target & retained) <= ((CHI | sibling) & retained)
        sibling_records.append(
            {
                "target_extra": extra,
                "all_parent_suppliers": len(suppliers),
                "unique_mixed_supplier_ordinal": sibling_ordinal,
                "unique_mixed_supplier": matching_key(sibling),
                "supplier_state": "00",
            }
        )

    print({"overlay_records": tuple(overlay_records)})
    print({"surgery_records": tuple(surgery_records)})
    print(
        {
            "profile": (len(mixed), len(escape), len(targets)),
            "failed_ordinals": failed_ordinals,
            "minimum_counterexample_ordinal": 0,
            "minimum_eta": matching_key(eta0),
            "global_X_target_extra_edges": target_extra_edges,
            "sibling_suppliers": tuple(sibling_records),
            "state00_hybrid_profiles": tuple(hybrid_profiles),
        }
    )
    print("HIT29_OVERLAY_LOCAL_SURGERY_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
