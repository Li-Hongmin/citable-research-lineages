#!/usr/bin/env python3
"""Verify the minimum reduced planar multi-port XOR tangle of Note 094."""

from collections.abc import Iterator

import networkx as nx


Pair = tuple[int, int]


def smoothing(offset: int, length: int, state: int) -> list[Pair]:
    assert length >= 4 and length % 2 == 0
    return [
        (offset + (2 * i + state) % length,
         offset + (2 * i + 1 + state) % length)
        for i in range(length // 2)
    ]


def perfect_matchings(vertices: tuple[int, ...]) -> Iterator[list[Pair]]:
    if not vertices:
        yield []
        return
    first = vertices[0]
    for index in range(1, len(vertices)):
        second = vertices[index]
        remaining = vertices[1:index] + vertices[index + 1:]
        for rest in perfect_matchings(remaining):
            yield [(first, second), *rest]


def signature(
    external: list[Pair],
    first: list[Pair],
    second: list[Pair],
    terminals: tuple[int, int, int, int],
) -> tuple[frozenset[frozenset[int]], int] | None:
    graph = nx.MultiGraph()
    graph.add_nodes_from(range(max(terminals) + 1))
    graph.add_edges_from(external + first + second)
    terminal_set = frozenset(terminals)
    pairs: set[frozenset[int]] = set()
    closed = 0
    for component in nx.connected_components(graph):
        boundary = terminal_set.intersection(component)
        if not boundary:
            closed += 1
        elif len(boundary) == 2:
            pairs.add(frozenset(boundary))
        else:
            return None
    return frozenset(pairs), closed


def xor_table(
    first_length: int,
    second_length: int,
    external: list[Pair],
) -> tuple[bool, tuple[tuple[frozenset[frozenset[int]], int], ...] | None]:
    port_count = first_length + second_length
    terminals = tuple(range(port_count, port_count + 4))
    identity = frozenset((
        frozenset((terminals[0], terminals[1])),
        frozenset((terminals[2], terminals[3])),
    ))
    elbow = frozenset((
        frozenset((terminals[0], terminals[3])),
        frozenset((terminals[1], terminals[2])),
    ))
    first = [smoothing(0, first_length, state) for state in (0, 1)]
    second = [
        smoothing(first_length, second_length, state) for state in (0, 1)
    ]
    raw = tuple(
        signature(external, first[i], second[j], terminals)
        for i, j in ((0, 0), (1, 0), (0, 1), (1, 1))
    )
    if any(item is None for item in raw):
        return False, None
    states = tuple(item for item in raw if item is not None)
    desired = (
        (identity, 0),
        (elbow, states[1][1]),
        (elbow, states[2][1]),
        (identity, 0),
    )
    return states == desired, states


def ordered_boundary_graph(
    first_length: int,
    second_length: int,
    external: list[Pair],
) -> nx.Graph:
    """Subdivide external pairs and add a rim forcing terminal order."""
    port_count = first_length + second_length
    terminals = tuple(range(port_count, port_count + 4))
    graph = nx.Graph()
    graph.add_nodes_from(range(port_count + 4))
    graph.add_edges_from(
        smoothing(0, first_length, 0)
        + smoothing(0, first_length, 1)
        + smoothing(first_length, second_length, 0)
        + smoothing(first_length, second_length, 1)
    )
    for index, (left, right) in enumerate(external):
        subdivision = ("external", index)
        graph.add_edge(left, subdivision)
        graph.add_edge(subdivision, right)
    for index in range(4):
        rim = ("rim", index)
        graph.add_edge(terminals[index], rim)
        graph.add_edge(rim, terminals[(index + 1) % 4])
    return graph


def verify_explicit_tangle() -> None:
    # C4 ports 0..3, C8 ports 4..11, terminals 12..15.
    external = [
        (0, 4), (1, 6), (2, 8), (3, 10),
        (5, 12), (7, 13), (9, 14), (11, 15),
    ]
    works, states = xor_table(4, 8, external)
    assert works and states is not None
    assert tuple(closed for _, closed in states) == (0, 0, 0, 0)

    tangle = nx.Graph()
    tangle.add_nodes_from(range(16))
    tangle.add_edges_from(
        smoothing(0, 4, 0) + smoothing(0, 4, 1)
        + smoothing(4, 8, 0) + smoothing(4, 8, 1)
        + external
    )
    assert nx.is_connected(tangle)
    assert tangle.number_of_edges() == 20
    assert all(tangle.degree(vertex) == 3 for vertex in range(12))
    assert all(tangle.degree(vertex) == 1 for vertex in range(12, 16))
    assert nx.check_planarity(ordered_boundary_graph(4, 8, external))[0]


def classify_smaller_cases() -> dict[tuple[int, int], tuple[int, int]]:
    result: dict[tuple[int, int], tuple[int, int]] = {}
    for first_length, second_length in ((4, 4), (4, 6), (6, 4)):
        vertices = tuple(range(first_length + second_length + 4))
        xor_count = 0
        planar_count = 0
        for external in perfect_matchings(vertices):
            works, _ = xor_table(first_length, second_length, external)
            if not works:
                continue
            xor_count += 1
            if nx.check_planarity(
                ordered_boundary_graph(first_length, second_length, external)
            )[0]:
                planar_count += 1
        result[first_length, second_length] = xor_count, planar_count
    assert result == {
        (4, 4): (32, 0),
        (4, 6): (192, 0),
        (6, 4): (192, 0),
    }
    return result


def main() -> None:
    verify_explicit_tangle()
    result = classify_smaller_cases()
    print("smaller reduced tangles (XOR, rim-planar XOR superfamily):", result)
    print("minimum total toggle ports: 12, attained by C4 + C8")
    print("MULTIPORT_XOR_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()
