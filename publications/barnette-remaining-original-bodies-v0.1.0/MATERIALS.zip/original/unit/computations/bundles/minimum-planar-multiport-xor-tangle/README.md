# Minimum planar multi-port XOR tangle

This bundle verifies Note 094.

Run from the AIMath root:

```text
uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/minimum-planar-multiport-xor-tangle/verify_multiport_xor_countermodel.py
```

The expected final line is

```text
MULTIPORT_XOR_COUNTERMODEL_VERIFIED
```

The program checks the explicit planar \(C_4+C_8\) construction, all four
pairing states and their zero closed-component counts.  It then exhausts
the only smaller even cycle-length pairs \((4,4),(4,6),(6,4)\) at the
reduced port-perfect-matching level, including a necessary rim-planarity
test after subdividing external matching edges.  Genuine ordered-cofacial
objects form a subset of this rim-planar family, so the zero smaller-case
count proves the stated lower bound even though the converse test is not
used.

Scope: this is a port-tangle classification, not a graph-order census and
not a legal-wide or brace realization test.
