# Target-component saturation through reduced order 20

For every simple plane cubic bipartite brace of even order at most 20, this
bundle enumerates every legal two-gate inverse reduction and every unchanged
root with a nonempty reduced target family.  For each fixed interface it
builds the graph whose vertices are rooted two-cycle target matchings and whose
edges are single alternating-cycle exchanges, then tests every local lift row.

The accepted certificate covers 912 generated cubic bipartite graphs, 10
plane braces, 8,798 interfaces, 45,364 target/interface instances, and 9,296
target-state components.  Every component contains a liftable target.  More
strongly, each of the 184 nonliftable target instances has a liftable
single-cycle neighbour using at most one gate.

## Contents

- `verify_target_component_saturation_through20.py` is the streaming driver.
- `target_component_saturation_through20.json` is the accepted aggregate
  certificate.

## Reproduction

From the AIMath project root:

    task_run_dir=$(mktemp -d)

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/target-component-saturation-through20/verify_target_component_saturation_through20.py \
      --output "$task_run_dir/target-components.json"

    cmp "$task_run_dir/target-components.json" \
      units/barnette/computations/bundles/target-component-saturation-through20/target_component_saturation_through20.json

The required terminal marker is

    TARGET_COMPONENT_SATURATION_VERIFIED_THROUGH_REDUCED_ORDER_20

Accepted environment:

- nauty 2.9.3, using `geng -cqb -d3 -D3 n` for even `6 <= n <= 20`;
- NetworkX 3.6.1;
- Python 3 via `uv`.

The external coverage interfaces are `geng`'s isomorph-free generation and
NetworkX's planarity decisions.  Cubicity, bipartition, both brace criteria,
embedded duals, legal split sites, complete target families, perfect-matching
symmetric-difference components, target-state components, and all eight local
rows are checked directly.
