#!/usr/bin/env python3
"""Test target-component saturation on the complete through-20 brace corpus.

For a fixed reduced brace, split site, and surviving root, vertices are the
complete reduced target family.  Two targets are adjacent exactly when their
perfect matchings differ on one alternating cycle (the root edge is retained
by both and hence avoided).  A vertex is good when some Note 065 local row is
a target lift at the fixed split site.

The driver also records two stronger candidate mechanisms:

* every bad target has a good one-cycle neighbour;
* every bad target has a target using at most one of the two gate edges.

It streams graphs and interfaces and freezes the first component-saturation
failure, while retaining the first failures of the stronger mechanisms.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from itertools import combinations, product
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from typing import Iterable, Iterator

import networkx as nx


Edge = tuple[int, int]
Matching = frozenset[Edge]

sys.dont_write_bytecode = True
UNIT_DIR = Path(__file__).resolve().parents[3]
SOURCE_BUNDLE = (
    UNIT_DIR
    / "computations"
    / "bundles"
    / "planar-two-path-through18"
    / "census_planar_brace_two_paths_through18.py"
)
LIFT_BUNDLE = (
    UNIT_DIR
    / "computations"
    / "bundles"
    / "locked-boundary-escape-through18"
    / "census_locked_escape_through18.py"
)
EXPECTED_THROUGH18_RAW = 209
EXPECTED_ORDER20_RAW = 703


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


source_bundle = load_module(SOURCE_BUNDLE, "target_saturation_source_bundle")
lift_bundle = load_module(LIFT_BUNDLE, "target_saturation_lift_bundle")


def edge(first: int, second: int) -> Edge:
    return (first, second) if first < second else (second, first)


def generated_graphs(order: int) -> Iterator[tuple[str, nx.Graph]]:
    process = subprocess.Popen(
        ("geng", "-cqb", "-d3", "-D3", str(order)),
        stdout=subprocess.PIPE,
        text=True,
    )
    assert process.stdout is not None
    completed = False
    try:
        for line in process.stdout:
            graph6 = line.strip()
            if graph6:
                yield graph6, nx.from_graph6_bytes(graph6.encode())
        assert process.wait() == 0
        completed = True
    finally:
        if not completed and process.poll() is None:
            process.terminate()
            process.wait()


def primal_edge_by_dual_edge(
    primal: nx.Graph, primal_faces: Iterable[Iterable[int]]
) -> dict[Edge, Edge]:
    incident: dict[Edge, list[int]] = defaultdict(list)
    for face_index, face_raw in enumerate(primal_faces):
        face = tuple(face_raw)
        for index, first in enumerate(face):
            second = face[(index + 1) % len(face)]
            incident[edge(first, second)].append(face_index)
    assert set(incident) == {edge(*item) for item in primal.edges()}
    assert all(len(pair) == 2 for pair in incident.values())
    result = {edge(*pair): primal_edge for primal_edge, pair in incident.items()}
    assert len(result) == primal.number_of_edges()
    return result


def matching_from_colour(
    primal: nx.Graph,
    reduced: nx.Graph,
    dual_to_primal: dict[Edge, Edge],
    colour: dict[int, int],
) -> Matching:
    matching = frozenset(
        dual_to_primal[edge(first, second)]
        for first, second in reduced.edges()
        if colour[first] == colour[second]
    )
    assert len(matching) * 2 == primal.number_of_nodes()
    degrees = Counter(vertex for item in matching for vertex in item)
    assert set(degrees) == set(primal) and set(degrees.values()) == {1}
    return matching


def matching_diff_components(first: Matching, second: Matching) -> tuple[frozenset[Edge], ...]:
    difference = first ^ second
    if not difference:
        return ()
    graph = nx.Graph()
    graph.add_edges_from(difference)
    assert nx.is_connected(graph) or nx.number_connected_components(graph) >= 2
    assert set(dict(graph.degree()).values()) == {2}
    return tuple(
        frozenset(edge(*item) for item in graph.subgraph(vertices).edges())
        for vertices in nx.connected_components(graph)
    )


def target_graph(matchings: tuple[Matching, ...]) -> tuple[nx.Graph, dict[tuple[int, int], int]]:
    graph = nx.Graph()
    graph.add_nodes_from(range(len(matchings)))
    diff_counts: dict[tuple[int, int], int] = {}
    for first, second in combinations(range(len(matchings)), 2):
        count = len(matching_diff_components(matchings[first], matchings[second]))
        diff_counts[(first, second)] = count
        if count == 1:
            graph.add_edge(first, second)
    return graph, diff_counts


def alternating(word: tuple[int, ...]) -> bool:
    return all(word[index] != word[index + 1] for index in range(len(word) - 1))


def internal_target_cube_path(
    start: Matching,
    finish: Matching,
    family_matchings: tuple[Matching, ...],
) -> bool:
    components = matching_diff_components(start, finish)
    if not components:
        return True
    component_index = {
        item: index for index, component in enumerate(components) for item in component
    }
    full_union = frozenset().union(*components)
    allowed_masks: set[int] = set()
    for matching in family_matchings:
        difference = start ^ matching
        if not difference <= full_union:
            continue
        mask = 0
        valid = True
        for index, component in enumerate(components):
            overlap = difference & component
            if overlap == component:
                mask |= 1 << index
            elif overlap:
                valid = False
                break
        if valid:
            assert all(item in component_index for item in difference)
            allowed_masks.add(mask)
    target = (1 << len(components)) - 1
    assert 0 in allowed_masks and target in allowed_masks
    queue = deque([0])
    seen = {0}
    while queue:
        state = queue.popleft()
        if state == target:
            return True
        for index in range(len(components)):
            neighbour = state ^ (1 << index)
            if neighbour in allowed_masks and neighbour not in seen:
                seen.add(neighbour)
                queue.append(neighbour)
    return False


def target_record(
    index: int,
    colour: dict[int, int],
    matching: Matching,
    gates: tuple[Edge, Edge],
    lift_rows: set[str],
    adjacency: nx.Graph,
) -> dict[str, object]:
    return {
        "index": index,
        "zero_vertices": sorted(vertex for vertex, value in colour.items() if value == 0),
        "one_vertices": sorted(vertex for vertex, value in colour.items() if value == 1),
        "matching": sorted(matching),
        "gate_count": sum(gate in matching for gate in gates),
        "lift_rows_normalized": sorted(lift_rows),
        "liftable": bool(lift_rows),
        "target_graph_neighbours": sorted(adjacency[index]),
    }


def interface_record(
    source_order: int,
    source_graph6: str,
    z: int,
    rotation: tuple[int, ...],
    gate_indices: tuple[int, int],
    gate_vertices: tuple[int, int],
    gate_edges: tuple[Edge, Edge],
    arcs: tuple[tuple[int, ...], tuple[int, ...]],
    root: Edge,
    primal_root: Edge,
    colours: tuple[dict[int, int], ...],
    matchings: tuple[Matching, ...],
    lift_rows: tuple[set[str], ...],
    adjacency: nx.Graph,
    selected: Iterable[int] | None = None,
) -> dict[str, object]:
    indices = tuple(range(len(matchings))) if selected is None else tuple(sorted(selected))
    return {
        "source_order": source_order,
        "source_graph6": source_graph6,
        "split_vertex": z,
        "rotation": rotation,
        "gate_indices": gate_indices,
        "gate_vertices": gate_vertices,
        "primal_gate_edges": gate_edges,
        "arcs": arcs,
        "dual_root": root,
        "primal_root": primal_root,
        "family_size": len(matchings),
        "selected_targets": [
            target_record(
                index,
                colours[index],
                matchings[index],
                gate_edges,
                lift_rows[index],
                adjacency,
            )
            for index in indices
        ],
    }


def analyse_brace(
    order: int,
    source_graph6: str,
    primal: nx.Graph,
    primal_faces: tuple[tuple[int, ...], ...],
    totals: Counter,
    first_records: dict[str, object | None],
) -> dict[str, object] | None:
    reduced, rotations = lift_bundle.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift_bundle.verify_reduced_triangulation(reduced)
    families, _nae_count, _target_shape_count = lift_bundle.target_families(
        reduced, reduced_faces
    )
    reduced_vertices = tuple(sorted(reduced))
    dual_to_primal = primal_edge_by_dual_edge(primal, primal_faces)

    family_cache: dict[Edge, tuple[tuple[dict[int, int], ...], tuple[Matching, ...], nx.Graph]] = {}
    for root, encoded_family in families.items():
        colours = tuple(
            lift_bundle.decode_colouring(reduced_vertices, encoded)
            for encoded in encoded_family
        )
        matchings = tuple(
            matching_from_colour(primal, reduced, dual_to_primal, colour)
            for colour in colours
        )
        assert len(matchings) == len(set(matchings))
        primal_root = dual_to_primal[root]
        assert all(primal_root in matching for matching in matchings)
        adjacency, _diff_counts = target_graph(matchings)
        family_cache[root] = colours, matchings, adjacency

    for z in sorted(reduced):
        rotation = rotations[z]
        for first_index, second_index, first_gate, second_gate in lift_bundle.gate_pairs(
            rotation
        ):
            left_size = second_index - first_index + 1
            right_size = len(rotation) - (second_index - first_index) + 1
            if left_size % 2 == 0 or right_size % 2 == 0:
                continue
            expanded, locals_, left_arc, right_arc = lift_bundle.split_vertex(
                reduced, z, rotation, first_index, second_index
            )
            expanded_faces = lift_bundle.expanded_triangulation_faces(expanded)
            if expanded_faces is None:
                continue

            gate_edges = (
                dual_to_primal[edge(z, first_gate)],
                dual_to_primal[edge(z, second_gate)],
            )
            assert gate_edges[0] != gate_edges[1]
            for root in sorted(families):
                if z in root:
                    continue
                totals["interfaces"] += 1
                colours, matchings, adjacency = family_cache[root]
                primal_root = dual_to_primal[root]
                lift_rows_list: list[set[str]] = []
                arc11: list[bool] = []
                gate_counts: list[int] = []

                for colour, matching in zip(colours, matchings, strict=True):
                    fixed = {vertex: value for vertex, value in colour.items() if vertex != z}
                    normalized_rows: set[str] = set()
                    for bits in product((0, 1), repeat=3):
                        lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
                        profile = lift_bundle.rooted_profile(
                            expanded, expanded_faces, lifted, root
                        )
                        if lift_bundle.is_target_profile(profile):
                            normalized_rows.add(
                                "".join(str(bit ^ colour[z]) for bit in bits)
                            )
                    lift_rows_list.append(normalized_rows)
                    gate_count = sum(gate in matching for gate in gate_edges)
                    gate_counts.append(gate_count)
                    normal_left = tuple(colour[item] ^ colour[z] for item in left_arc)
                    normal_right = tuple(colour[item] ^ colour[z] for item in right_arc)
                    arc11.append(
                        gate_count == 2
                        and alternating(normal_left)
                        and alternating(normal_right)
                    )

                lift_rows = tuple(lift_rows_list)
                good = {index for index, rows in enumerate(lift_rows) if rows}
                bad = set(range(len(matchings))) - good
                totals["target_instances"] += len(matchings)
                totals["liftable_target_instances"] += len(good)
                totals["nonliftable_target_instances"] += len(bad)

                all_both = all(count == 2 for count in gate_counts)
                components = tuple(nx.connected_components(adjacency))
                totals["target_graph_components"] += len(components)
                bad_components = [component for component in components if not (component & good)]
                totals["components_without_liftable_target"] += len(bad_components)
                required_rows = {"011", "101", "110"}
                for component in components:
                    component_all_both = all(gate_counts[index] == 2 for index in component)
                    if component_all_both:
                        totals["all_both_gate_components"] += 1
                        totals["all_both_gate_component_targets"] += len(component)
                        if all_both:
                            totals["all_both_components_in_all_both_families"] += 1
                        else:
                            totals["all_both_components_in_mixed_gate_families"] += 1
                        if all(arc11[index] for index in component):
                            totals["all_both_components_all_targets_arc11"] += 1
                        if all(required_rows <= lift_rows[index] for index in component):
                            totals["all_both_components_all_targets_have_011_101_110"] += 1
                        if all(index in good for index in component):
                            totals["all_both_components_all_targets_liftable"] += 1
                    else:
                        gate_avoiding_members = {
                            index for index in component if gate_counts[index] <= 1
                        }
                        assert gate_avoiding_members
                        totals["components_with_gate_avoiding_target"] += 1
                        if gate_avoiding_members <= good:
                            totals["components_all_gate_avoiding_targets_liftable"] += 1

                if all_both:
                    totals["all_both_gate_interfaces"] += 1
                    totals["all_both_gate_target_instances"] += len(matchings)
                    if all(arc11):
                        totals["all_both_interfaces_all_targets_arc11"] += 1
                    elif first_records["all_both_arc11_failure"] is None:
                        first_records["all_both_arc11_failure"] = interface_record(
                            order, source_graph6, z, rotation,
                            (first_index, second_index), (first_gate, second_gate),
                            gate_edges, (left_arc, right_arc), root, primal_root,
                            colours, matchings, lift_rows, adjacency,
                        )
                    if all(required_rows <= rows for rows in lift_rows):
                        totals["all_both_interfaces_all_targets_have_011_101_110"] += 1
                    elif first_records["all_both_three_rows_failure"] is None:
                        first_records["all_both_three_rows_failure"] = interface_record(
                            order, source_graph6, z, rotation,
                            (first_index, second_index), (first_gate, second_gate),
                            gate_edges, (left_arc, right_arc), root, primal_root,
                            colours, matchings, lift_rows, adjacency,
                        )

                for bad_index in sorted(bad):
                    good_neighbours = set(adjacency[bad_index]) & good
                    if good_neighbours:
                        totals["bad_targets_with_good_one_cycle_neighbour"] += 1
                    else:
                        totals["bad_targets_without_good_one_cycle_neighbour"] += 1
                        if first_records["one_cycle_domination_failure"] is None:
                            component = nx.node_connected_component(adjacency, bad_index)
                            first_records["one_cycle_domination_failure"] = interface_record(
                                order, source_graph6, z, rotation,
                                (first_index, second_index), (first_gate, second_gate),
                                gate_edges, (left_arc, right_arc), root, primal_root,
                                colours, matchings, lift_rows, adjacency,
                                component,
                            )

                    gate_avoiding = [
                        index for index, count in enumerate(gate_counts) if count <= 1
                    ]
                    if gate_avoiding:
                        totals["bad_targets_with_gate_avoiding_target"] += 1
                        counts = {
                            index: len(
                                matching_diff_components(
                                    matchings[bad_index], matchings[index]
                                )
                            )
                            for index in gate_avoiding
                        }
                        minimum = min(counts.values())
                        totals[f"minimum_gate_avoiding_diff_components_{minimum}"] += 1
                        closest = [index for index, count in counts.items() if count == minimum]
                        if any(
                            nx.has_path(adjacency, bad_index, index)
                            for index in gate_avoiding
                        ):
                            totals["bad_targets_gate_avoiding_same_target_component"] += 1
                        if any(
                            internal_target_cube_path(
                                matchings[bad_index], matchings[index], matchings
                            )
                            for index in closest
                        ):
                            totals["bad_targets_closest_gate_avoiding_internal_target_path"] += 1
                    else:
                        totals["bad_targets_without_gate_avoiding_target"] += 1
                        if first_records["gate_avoiding_failure"] is None:
                            first_records["gate_avoiding_failure"] = interface_record(
                                order, source_graph6, z, rotation,
                                (first_index, second_index), (first_gate, second_gate),
                                gate_edges, (left_arc, right_arc), root, primal_root,
                                colours, matchings, lift_rows, adjacency,
                            )

                if bad_components:
                    failure_vertices = set().union(*bad_components)
                    return interface_record(
                        order, source_graph6, z, rotation,
                        (first_index, second_index), (first_gate, second_gate),
                        gate_edges, (left_arc, right_arc), root, primal_root,
                        colours, matchings, lift_rows, adjacency,
                        failure_vertices,
                    )
    return None


def census() -> dict[str, object]:
    totals: Counter = Counter()
    generated_by_order: dict[str, int] = {}
    braces_by_order: dict[str, int] = {}
    first_records: dict[str, object | None] = {
        "one_cycle_domination_failure": None,
        "gate_avoiding_failure": None,
        "all_both_arc11_failure": None,
        "all_both_three_rows_failure": None,
    }
    component_failure = None

    for order in range(6, 21, 2):
        generated = 0
        braces = 0
        stream = generated_graphs(order)
        try:
            for graph6, primal in stream:
                generated += 1
                totals["generated_graphs"] += 1
                planar, embedding = nx.check_planarity(primal, counterexample=True)
                if not planar:
                    continue
                totals["planar_graphs"] += 1
                assert isinstance(embedding, nx.PlanarEmbedding)
                primal_faces = source_bundle.plane_faces(primal, embedding)
                direct = source_bundle.is_two_extendable_direct(primal)
                strict_hall = source_bundle.strict_hall_two_extendable(primal)
                assert direct == strict_hall
                if not direct:
                    continue
                braces += 1
                totals["plane_braces"] += 1
                component_failure = analyse_brace(
                    order,
                    graph6,
                    primal,
                    primal_faces,
                    totals,
                    first_records,
                )
                if component_failure is not None:
                    break
        finally:
            stream.close()
        generated_by_order[str(order)] = generated
        braces_by_order[str(order)] = braces
        print(
            json.dumps(
                {
                    "order": order,
                    "generated": generated,
                    "braces": braces,
                    "interfaces": totals["interfaces"],
                    "component_failures": totals["components_without_liftable_target"],
                },
                sort_keys=True,
            ),
            flush=True,
        )
        if component_failure is not None:
            break

    if component_failure is None:
        assert sum(generated_by_order[str(order)] for order in range(6, 19, 2)) == EXPECTED_THROUGH18_RAW
        assert generated_by_order["20"] == EXPECTED_ORDER20_RAW
        status = "verified_through_reduced_order_20"
    else:
        status = "counterexample"

    return {
        "status": status,
        "generator": "geng -cqb -d3 -D3 n for even 6 <= n <= 20",
        "networkx_version": nx.__version__,
        "generated_by_order": generated_by_order,
        "braces_by_order": braces_by_order,
        "coverage": dict(sorted(totals.items())),
        "first_stronger_candidate_failures": first_records,
        "component_saturation_failure": component_failure,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    payload = census()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
        print("certificate", arguments.output)
    print(json.dumps(payload["coverage"], sort_keys=True))
    if payload["component_saturation_failure"] is None:
        print("TARGET_COMPONENT_SATURATION_VERIFIED_THROUGH_REDUCED_ORDER_20")
    else:
        print("TARGET_COMPONENT_SATURATION_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
