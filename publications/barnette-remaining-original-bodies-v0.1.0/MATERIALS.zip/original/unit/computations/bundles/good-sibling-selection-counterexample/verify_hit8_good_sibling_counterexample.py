#!/usr/bin/env python3
"""Independent fixed certificate for the minimum frozen good-sibling failure.

The only imported code is the pure-standard-library graph/matching checker
already frozen for the independent hit-29 certificate.  No endpoint table,
project classifier, NetworkX routine, or generated object is read.
"""

from __future__ import annotations

from collections import Counter
import importlib.util
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
LIBRARY = (
    BARNETTE
    / "computations"
    / "bundles"
    / "endpoint-star-parity-and-pairing-counterexamples"
    / "verify_hit29_bondwise_hall_counterexample.py"
)


def load_library():
    specification = importlib.util.spec_from_file_location(
        "hit8_fixed_graph_library", LIBRARY
    )
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


h = load_library()

GRAPH6 = "S???????F?Y?b?W_CW?F?AW?KO?`_?g_?"
FACES = (
    (0, 11, 1, 10),
    (0, 12, 5, 19, 3, 11),
    (0, 10, 2, 14, 7, 16, 4, 12),
    (1, 11, 3, 18, 8, 15, 6, 13),
    (1, 13, 2, 10),
    (2, 13, 6, 14),
    (3, 19, 9, 18),
    (4, 17, 5, 12),
    (4, 16, 8, 18, 9, 17),
    (5, 17, 9, 19),
    (6, 15, 7, 14),
    (7, 15, 8, 16),
)
ROOT = (5, 17)
FORCED_GATE = (4, 12)
SURVIVING_GATE = (2, 14)
ROOT_GATE_SQUARE = (5, 17, 4, 12)
FACE_INDEX = 3
SITE_INDICES = (2, 6)
SITE = frozenset({(3, 18), (6, 13)})
CHI = frozenset(
    {
        (0, 11), (1, 10), (2, 14), (3, 18), (4, 12),
        (5, 17), (6, 13), (7, 15), (8, 16), (9, 19),
    }
)


def main():
    vertices, edges = h.decode_graph6(GRAPH6)
    h.validate_plane_cubic_bipartite(vertices, edges, FACES)
    h.verify_root_gate_square(FACES, ROOT, FORCED_GATE, ROOT_GATE_SQUARE)
    labelled = (ROOT, FORCED_GATE, SURVIVING_GATE, *tuple(sorted(SITE)))
    assert all(
        not (set(first) & set(second))
        for index, first in enumerate(labelled)
        for second in labelled[index + 1 :]
    )
    parent_matchings = h.enumerate_perfect_matchings(vertices, edges)
    assert len(parent_matchings) == 97
    assert h.verify_brace(edges, parent_matchings) == 375
    parent_fibre = tuple(
        matching
        for matching in parent_matchings
        if h.root_target(vertices, edges, matching, ROOT, FORCED_GATE)
    )
    assert len(parent_fibre) == 5
    assert tuple(
        sum((SURVIVING_GATE in matching) == bool(bit) for matching in parent_fibre)
        for bit in (0, 1)
    ) == (4, 1)
    l11 = tuple(matching for matching in parent_fibre if SITE <= matching)
    assert l11 == (CHI,)
    assert SURVIVING_GATE in CHI

    (
        child_vertices,
        child_edges,
        child_faces,
        local,
        selected,
        site_face,
    ) = h.expand(vertices, edges, FACES, FACE_INDEX, SITE_INDICES)
    assert frozenset(selected) == SITE
    h.validate_plane_cubic_bipartite(child_vertices, child_edges, child_faces)
    h.verify_root_gate_square(child_faces, ROOT, FORCED_GATE, ROOT_GATE_SQUARE)
    assert h.legal_wide_arcs(
        child_faces, ROOT, FORCED_GATE, SURVIVING_GATE
    ) == (5, 5)
    child_matchings = h.enumerate_perfect_matchings(child_vertices, child_edges)
    assert len(child_matchings) == 164
    assert h.verify_brace(child_edges, child_matchings) == 558
    child_fibre = tuple(
        matching
        for matching in child_matchings
        if h.root_target(
            child_vertices, child_edges, matching, ROOT, FORCED_GATE
        )
    )
    assert len(child_fibre) == 7
    cells = {matching: h.local_cell(matching, local) for matching in child_fibre}
    assert Counter(cells.values()) == Counter(
        {"C10": 4, "R00": 1, "Xuy": 1, "Xvx": 1}
    )
    assert tuple(
        sum((SURVIVING_GATE in matching) == bool(bit) for matching in child_fibre)
        for bit in (0, 1)
    ) == (4, 3)

    direct = h.direct_lifts(CHI, site_face, SITE_INDICES, selected, local)
    assert set(direct) == {"R00", "Xuy", "Xvx"}
    assert all(matching not in child_fibre for matching in direct.values())

    sector = int(SURVIVING_GATE in CHI)
    mixed = tuple(
        matching
        for matching in parent_fibre
        if (SURVIVING_GATE in matching) != bool(sector)
        and not SITE <= matching
        and h.difference_component_count(CHI, matching) == 1
    )
    escape = tuple(
        matching
        for matching in parent_fibre
        if (SURVIVING_GATE in matching) == bool(sector)
        and not SITE <= matching
        and h.difference_component_count(CHI, matching) == 1
    )
    targets = tuple(
        matching
        for matching in child_fibre
        if (SURVIVING_GATE in matching) == bool(sector)
        and cells[matching] in {"R00", "Xuy", "Xvx"}
    )
    assert (len(mixed), len(escape), len(targets)) == (2, 0, 3)
    assert tuple(cells[target] for target in targets) == ("R00", "Xvx", "Xuy")

    retained = edges - SITE
    deficits = tuple(
        tuple(
            (target & retained) - ((CHI | eta) & retained)
            for target in targets
        )
        for eta in mixed
    )
    assert tuple(tuple(map(len, row)) for row in deficits) == (
        (5, 3, 2),
        (5, 2, 3),
    )
    assert all(deficit for row in deficits for deficit in row)
    assert tuple(min(map(len, row)) for row in deficits) == (2, 2)

    # Even the union of the complete parent rooted fibre misses retained
    # support required by every same-sector child target.  Hence adding more
    # rooted overlays cannot repair this example; a non-rooted parent
    # matching or intrinsically child-side incidence is unavoidable.
    rooted_union = frozenset().union(*parent_fibre) & retained
    full_fibre_deficits = tuple(
        (target & retained) - rooted_union for target in targets
    )
    assert tuple(map(len, full_fibre_deficits)) == (2, 1, 1)
    assert tuple(map(h.matching_key, full_fibre_deficits)) == (
        ((3, 11), (8, 18)),
        ((3, 11),),
        ((8, 18),),
    )

    print(
        {
            "parent": (len(vertices), len(edges), len(parent_matchings), 375),
            "child": (
                len(child_vertices), len(child_edges), len(child_matchings), 558
            ),
            "rooted_fibres": (len(parent_fibre), len(child_fibre)),
            "profile": (len(mixed), len(escape), len(targets)),
            "target_cells": tuple(cells[target] for target in targets),
            "retained_support_deficit_sizes": tuple(
                tuple(map(len, row)) for row in deficits
            ),
            "minimum_deficit_by_mixed_sibling": tuple(
                min(map(len, row)) for row in deficits
            ),
            "complete_parent_rooted_union_deficits": tuple(
                h.matching_key(deficit) for deficit in full_fibre_deficits
            ),
            "good_siblings": (),
        }
    )
    print("HIT8_GOOD_SIBLING_COUNTEREXAMPLE_INDEPENDENTLY_VERIFIED")


if __name__ == "__main__":
    main()
