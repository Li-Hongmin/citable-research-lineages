# Complete rooted support can miss every child escape

This bundle verifies the fixed order-(20\to24) legal-wide split used in
[Note 126](../../../notes/126-even-the-complete-parent-rooted-support-need-not-contain-a-child-escape.md).

The certificate reads only its literal graph6 record, facial embedding and
labels.  It imports the already frozen pure-standard-library graph and
matching routines from the endpoint-star bundle; it does not read the
frozen endpoint census, a classifier output, NetworkX, or a generated
certificate.

## Reproduction

From the AIMath root, run

```bash
python3 units/barnette/computations/bundles/good-sibling-selection-counterexample/verify_hit8_good_sibling_counterexample.py
```

Tested with Python 3.14.6 on 2026-08-28.  Wall time was (0.03) seconds on
the freezing machine.  The terminal marker is

```text
HIT8_GOOD_SIBLING_COUNTEREXAMPLE_INDEPENDENTLY_VERIFIED
```

The complete expected output is stored in [expected-output.txt](expected-output.txt).

SHA-256 of the verifier:

```text
63312d5c8f99fbd65bbc494ed918db79f3c61f28ab4c5692752e3328ced442e0
```

## Scope

The computation proves a fixed actual counterexample to overlay-local
good-sibling selection and to the stronger complete-parent-rooted-support
selection.  It does not disprove Boolean mixed-sector survival and does not
claim global order minimality.

