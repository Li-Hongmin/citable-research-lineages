#!/usr/bin/env python3
"""Verify a wide plane nonbrace with minimum cross-sector distance two.

Start from the octagonal prism.  Replace each of the two rim edges T3 and
T5 by a plane cubic two-pole obtained from the cube by deleting one edge.
These two local blockers remove the two single-cycle neighbours of the
unique T4-sector target while leaving its two-C4 opposite-sector witnesses.
"""

from collections import Counter
from itertools import combinations

import networkx as nx


def edge(left, right):
    return tuple(sorted((left, right)))


def prism_edges(order):
    result = set()
    for index in range(order):
        result.add(edge(f"t{index}", f"t{(index + 1) % order}"))
        result.add(edge(f"b{index}", f"b{(index + 1) % order}"))
        result.add(edge(f"t{index}", f"b{index}"))
    return result


CUBE_POLE_EDGES = (
    ("A0", "B1"),
    ("A0", "B2"),
    ("A1", "B0"),
    ("A1", "B1"),
    ("A1", "B3"),
    ("A2", "B0"),
    ("A2", "B2"),
    ("A2", "B3"),
    ("A3", "B1"),
    ("A3", "B2"),
    ("A3", "B3"),
)


def splice_cube_pole(edges, removed_edge, prefix):
    result = set(edges)
    result.remove(edge(*removed_edge))
    left, right = removed_edge
    result.update(edge(prefix + a, prefix + b) for a, b in CUBE_POLE_EDGES)
    result.add(edge(left, prefix + "A0"))
    result.add(edge(right, prefix + "B0"))
    return result


def enumerate_matchings(graph):
    vertices = frozenset(graph)
    adjacency = {vertex: frozenset(graph[vertex]) for vertex in graph}

    def recurse(remaining):
        if not remaining:
            yield frozenset()
            return
        vertex = min(remaining, key=lambda item: len(adjacency[item] & remaining))
        for neighbour in adjacency[vertex] & remaining:
            for matching in recurse(remaining - {vertex, neighbour}):
                yield matching | {edge(vertex, neighbour)}

    return tuple(recurse(vertices))


def complement_signature(graph, matching):
    complement = nx.Graph()
    complement.add_nodes_from(graph)
    complement.add_edges_from(set(map(lambda item: edge(*item), graph.edges())) - matching)
    result = []
    for vertices in nx.connected_components(complement):
        component = complement.subgraph(vertices)
        endpoints = frozenset(
            vertex for vertex, degree in component.degree() if degree == 1
        )
        cycle_rank = component.number_of_edges() - component.number_of_nodes() + 1
        result.append((frozenset(vertices), endpoints, cycle_rank))
    return tuple(result)


def difference_components(first, second):
    graph = nx.Graph()
    graph.add_edges_from(first ^ second)
    return tuple(frozenset(vertices) for vertices in nx.connected_components(graph))


def plane_faces(graph):
    planar, embedding = nx.check_planarity(graph)
    assert planar
    seen = set()
    result = []
    for left, right in embedding.edges():
        if (left, right) not in seen:
            result.append(tuple(embedding.traverse_face(left, right, seen)))
    return tuple(result)


# The two-pole really is Q3 minus one edge.  Three vertices on each shore
# have degree three and the two attachment terminals have degree two.
pole = nx.Graph(CUBE_POLE_EDGES)
completed_pole = pole.copy()
completed_pole.add_edge("A0", "B0")
assert nx.is_isomorphic(completed_pole, nx.cubical_graph())
assert nx.check_planarity(pole)[0]

# Two independent blockers in the octagonal prism.
G_EDGES = prism_edges(8)
G_EDGES = splice_cube_pole(G_EDGES, ("t3", "t4"), "L")
G_EDGES = splice_cube_pole(G_EDGES, ("t5", "t6"), "R")
G = nx.Graph(G_EDGES)
assert len(G) == 32 and G.number_of_edges() == 48
assert nx.number_of_selfloops(G) == 0
assert all(degree == 3 for _, degree in G.degree())
assert nx.is_connected(G) and nx.is_bipartite(G)
assert nx.check_planarity(G)[0]

# The graph is not a brace.  The displayed independent pair cannot extend;
# equivalently the two cube poles are attached across nontrivial 2-edge cuts.
G_MATCHINGS = enumerate_matchings(G)
assert len(G_MATCHINGS) == 1314
NONEXTENDIBLE_PAIR = frozenset((edge("LA0", "LB1"), edge("LB0", "t4")))
first_bad_edge, second_bad_edge = tuple(NONEXTENDIBLE_PAIR)
assert set(first_bad_edge).isdisjoint(second_bad_edge)
assert not any(NONEXTENDIBLE_PAIR <= matching for matching in G_MATCHINGS)
assert nx.node_connectivity(G) == 2

# Labelled inverse square data inherited from the octagonal prism.
Q = frozenset(("b0", "b1", "t0", "t1"))
ROOT = edge("b0", "b1")
GATE0 = edge("t0", "t1")
GATE1 = edge("t4", "t5")
assert {ROOT, GATE0, edge("b0", "t0"), edge("b1", "t1")} <= G_EDGES

# The two gates are genuinely wide: in the unique common face the two closed
# arcs both have nine vertices (the cube poles lengthen the old C8 face).
faces = plane_faces(G)
site_data = []
for face in faces:
    boundary = tuple(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )
    if GATE0 in boundary and GATE1 in boundary:
        first, second = sorted((boundary.index(GATE0), boundary.index(GATE1)))
        site_data.append((face, second - first + 1, len(face) - (second - first) + 1))
assert len(site_data) == 1
assert sorted(site_data[0][1:]) == [9, 9]
assert ROOT not in {
    edge(site_data[0][0][index], site_data[0][0][(index + 1) % len(site_data[0][0])])
    for index in range(len(site_data[0][0]))
}

# Delete the root--gate square and enumerate the complete fixed-pairing fibre.
R = G.subgraph(set(G) - Q).copy()
assert len(R) == 28
TERMINAL_PAIRING = {
    frozenset(("b7", "t7")),
    frozenset(("b2", "t2")),
}


def in_fibre(matching):
    signature = complement_signature(R, matching)
    return (
        len(signature) == 2
        and all(cycle_rank == 0 for _, _, cycle_rank in signature)
        and {endpoints for _, endpoints, _ in signature} == TERMINAL_PAIRING
    )


R_MATCHINGS = enumerate_matchings(R)
FIBRE = tuple(matching for matching in R_MATCHINGS if in_fibre(matching))
SECTOR1 = tuple(matching for matching in FIBRE if GATE1 in matching)
SECTOR0 = tuple(matching for matching in FIBRE if GATE1 not in matching)
assert (len(R_MATCHINGS), len(FIBRE), len(SECTOR1), len(SECTOR0)) == (369, 48, 16, 32)
rim_profile = Counter(
    tuple(
        index
        for index in range(8)
        if edge(f"t{index}", f"t{(index + 1) % 8}") in matching
    )
    for matching in FIBRE
)
assert rim_profile == Counter({(2,): 16, (4,): 16, (6,): 16})

# Hard quantifier: minimize over the complete L^1 x L^0, not a selected
# subcube.  Every cross-sector pair has at least two alternating components.
cross_histogram = Counter(
    len(difference_components(first, second))
    for first in SECTOR1
    for second in SECTOR0
)
assert cross_histogram == Counter({2: 32, 3: 160, 4: 232, 5: 80, 6: 8})
assert min(cross_histogram) == 2

# One explicit minimum pair.  Both cube poles use the same internal matching,
# so the symmetric difference is exactly two disjoint prism side squares.
COMMON_POLE = frozenset(
    edge(*item)
    for item in (
        ("LA0", "LB1"),
        ("LA1", "LB3"),
        ("LA2", "LB0"),
        ("LA3", "LB2"),
        ("RA0", "RB2"),
        ("RA1", "RB0"),
        ("RA2", "RB3"),
        ("RA3", "RB1"),
    )
)
M = COMMON_POLE | frozenset(
    edge(*item)
    for item in (
        ("b2", "t2"),
        ("b3", "t3"),
        ("b4", "b5"),
        ("b6", "t6"),
        ("b7", "t7"),
        ("t4", "t5"),
    )
)
N = COMMON_POLE | frozenset(
    edge(*item)
    for item in (
        ("b2", "b3"),
        ("b4", "t4"),
        ("b5", "t5"),
        ("b6", "t6"),
        ("b7", "t7"),
        ("t2", "t3"),
    )
)
C2 = frozenset(
    edge(*item)
    for item in (("b2", "b3"), ("b2", "t2"), ("b3", "t3"), ("t2", "t3"))
)
C4 = frozenset(
    edge(*item)
    for item in (("b4", "b5"), ("b4", "t4"), ("b5", "t5"), ("t4", "t5"))
)
assert M in SECTOR1 and N in SECTOR0
assert M ^ N == C2 | C4 and C2.isdisjoint(C4)
assert M ^ C2 not in FIBRE and M ^ C4 not in FIBRE
assert N == M ^ C2 ^ C4

print("graph: octagonal prism with cube-minus-edge poles at T3 and T5")
print("extension: simple plane cubic bipartite, but not a brace")
print("wide gate arcs: 9 and 9")
print("fixed-pairing fibre sectors: 16 and 32")
print("complete cross-sector component histogram: 2^32 3^160 4^232 5^80 6^8")
print("minimum cross-sector component count: 2")
print("explicit atom: M triangle N = C2 dot-union C4")
print("WIDE_PLANE_NONBRACE_MINIMUM_ATOMIC_TWO_SWITCH_VERIFIED")
