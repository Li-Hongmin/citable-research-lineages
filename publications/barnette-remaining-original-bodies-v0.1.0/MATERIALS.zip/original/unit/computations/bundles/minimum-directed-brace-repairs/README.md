# Minimum directed brace-repair classification

This bundle classifies all one- and two-step facial \(C_4\) repairs of the
two attachment cuts in the fixed labelled plane embedding of Note 088.
The root square and both gate edges are held fixed.  It does not generate
cubic graphs of an order.

Run from the AIMath root:

    uv run --python 3.12 --with networkx units/barnette/computations/bundles/minimum-directed-brace-repairs/classify_minimum_directed_brace_repairs.py

The frozen environment used Python 3.12.11 and NetworkX 3.6.1.  A
hash-randomized run completed in about 28 seconds on the project machine.
The labelled face system is hard-coded and updated combinatorially after
each expansion; intermediate graphs with 2-cuts are never implicitly
re-embedded.

The driver imports the bundled
verify_wide_plane_nonbrace_atomic_minimum.py as its base construction.
The source hashes are:

- classifier:
  \(64bc0bc22dd8d72fc536e38617a13a2ca92b83ca63cd5fcbfb549e98621200a7\);
- base verifier:
  \(1106c070da9d23311ebb33dc8731d791bb84a9f4a558339a18d4126eff76bf82\).

The frozen stdout is [output.txt](output.txt).  Expected marker:

    MINIMUM_DIRECTED_BRACE_REPAIRS_SUPPLEMENT_CROSSING_VERIFIED

The classification is exhaustive only for the named fixed-embedding
one/two-facial-\(C_4\) repair route.
