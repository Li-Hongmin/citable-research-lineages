#!/usr/bin/env python3
"""Classify one- and two-C4 repairs of the two Q3-e attachment cuts.

The scope is deliberately local: facial C4 expansions that preserve the
labelled root square and the two gate edges of Note 088.  No cubic graphs of
an order are generated.
"""

from collections import Counter
import contextlib
import io
from itertools import combinations
from pathlib import Path
import runpy

import networkx as nx


HERE = Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):
    base = runpy.run_path(HERE / "verify_wide_plane_nonbrace_atomic_minimum.py")

edge = base["edge"]
ROOT = base["ROOT"]
GATE0 = base["GATE0"]
GATE1 = base["GATE1"]
FIXED_EDGES = {ROOT, GATE0, GATE1, edge("b0", "t0"), edge("b1", "t1")}
ROOT_SQUARE = frozenset(("b0", "b1", "t0", "t1"))
TERMINAL_PAIRING = {
    frozenset(("b7", "t7")),
    frozenset(("b2", "t2")),
}

# Note 088's labelled plane embedding.  This is frozen explicitly because
# the base graph has 2-cuts and therefore does not have a unique embedding.
BASE_FACES = (
    ("LA0", "t3", "b3", "b4", "t4", "LB0", "LA1", "LB1"),
    ("LA0", "LB2", "LA2", "LB0", "t4", "t5", "RA0", "RB1", "RA1", "RB0", "t6", "t7", "t0", "t1", "t2", "t3"),
    ("LA0", "LB1", "LA3", "LB2"),
    ("LB1", "LA1", "LB3", "LA3"),
    ("LB2", "LA3", "LB3", "LA2"),
    ("t3", "t2", "b2", "b3"),
    ("LA1", "LB0", "LA2", "LB3"),
    ("t4", "b4", "b5", "t5"),
    ("RA0", "RB2", "RA3", "RB1"),
    ("RA0", "t5", "b5", "b6", "t6", "RB0", "RA2", "RB2"),
    ("RB1", "RA3", "RB3", "RA1"),
    ("RB2", "RA2", "RB3", "RA3"),
    ("RA1", "RB3", "RA2", "RB0"),
    ("t6", "b6", "b7", "t7"),
    ("b0", "b7", "b6", "b5", "b4", "b3", "b2", "b1"),
    ("b0", "t0", "t7", "b7"),
    ("b0", "b1", "t1", "t0"),
    ("b1", "b2", "t2", "t1"),
)

G = nx.Graph()
G.add_edges_from(sorted(base["G_EDGES"]))
LEFT_POLE = frozenset(vertex for vertex in G if vertex.startswith("L"))
RIGHT_POLE = frozenset(vertex for vertex in G if vertex.startswith("R"))


def boundary_size(graph, shore):
    return sum(
        1 for left, right in graph.edges() if (left in shore) != (right in shore)
    )


def validate_faces(graph, faces):
    directed = [
        (face[index], face[(index + 1) % len(face)])
        for face in faces
        for index in range(len(face))
    ]
    expected = {
        dart
        for left, right in graph.edges()
        for dart in ((left, right), (right, left))
    }
    assert len(directed) == len(set(directed)) == 2 * graph.number_of_edges()
    assert set(directed) == expected
    assert graph.number_of_nodes() - graph.number_of_edges() + len(faces) == 2


def replace_dart(face, left, right, inserted):
    degree = len(face)
    positions = [
        index
        for index in range(degree)
        if face[index] == left and face[(index + 1) % degree] == right
    ]
    if not positions:
        return face
    assert len(positions) == 1
    index = positions[0]
    rotated = face[index:] + face[:index]
    return (left,) + tuple(inserted) + (right,) + rotated[2:]


def expand_on_face(graph, faces, face_index, first_index, second_index, prefix):
    face = faces[face_index]
    first_left = face[first_index]
    first_right = face[(first_index + 1) % len(face)]
    second_left = face[second_index]
    second_right = face[(second_index + 1) % len(face)]
    expanded = graph.copy()
    expanded.remove_edge(first_left, first_right)
    expanded.remove_edge(second_left, second_right)
    u, v, x, y = tuple(prefix + letter for letter in "uvxy")
    expanded.add_edges_from(
        (
            (first_left, u),
            (first_right, v),
            (second_left, x),
            (second_right, y),
            (u, v),
            (v, x),
            (x, y),
            (y, u),
        )
    )
    chosen = (
        edge(first_left, first_right),
        edge(second_left, second_right),
    )
    assert nx.is_bipartite(expanded) and nx.check_planarity(expanded)[0]
    assert all(degree == 3 for _, degree in expanded.degree())

    # Update the frozen face system combinatorially.  The chosen face splits
    # into two channel faces plus the new square; the reverse darts in the
    # adjacent face(s) are lengthened through the other square sides.
    updated_faces = []
    for index, old_face in enumerate(faces):
        if index == face_index:
            continue
        new_face = replace_dart(old_face, first_right, first_left, (v, u))
        new_face = replace_dart(new_face, second_right, second_left, (y, x))
        updated_faces.append(new_face)
    first_channel = face[first_index + 1 : second_index + 1] + (x, v)
    second_channel = face[second_index + 1 :] + face[: first_index + 1] + (u, y)
    updated_faces.extend((first_channel, second_channel, (u, v, x, y)))
    updated_faces = tuple(updated_faces)
    validate_faces(expanded, updated_faces)
    return expanded, updated_faces, chosen


def expansion_sites(graph, faces, prefix):
    """All facial bipartite C4 expansions avoiding the fixed interface."""

    for face_index, face in enumerate(faces):
        degree = len(face)
        for first_index in range(degree):
            for second_index in range(first_index + 1, degree):
                distance = second_index - first_index
                if distance in (1, degree - 1) or distance % 2:
                    continue
                chosen = {
                    edge(face[first_index], face[(first_index + 1) % degree]),
                    edge(face[second_index], face[(second_index + 1) % degree]),
                }
                if chosen & FIXED_EDGES:
                    continue
                yield expand_on_face(
                    graph,
                    faces,
                    face_index,
                    first_index,
                    second_index,
                    f"{prefix}_{face_index}_{first_index}_{second_index}_",
                )


def wide_arcs(faces):
    result = []
    for face in faces:
        boundary = tuple(
            edge(face[index], face[(index + 1) % len(face)])
            for index in range(len(face))
        )
        if GATE0 not in boundary or GATE1 not in boundary:
            continue
        first, second = sorted((boundary.index(GATE0), boundary.index(GATE1)))
        arcs = (second - first + 1, len(face) - (second - first) + 1)
        if min(arcs) >= 5 and all(size % 2 for size in arcs):
            result.append(arcs)
    assert len(result) <= 1
    return result[0] if result else None


def is_brace(graph):
    """Exact 2-extendability test over all independent edge pairs."""

    edges = tuple(edge(*item) for item in graph.edges())
    for first, second in combinations(edges, 2):
        if set(first) & set(second):
            continue
        remaining = graph.subgraph(set(graph) - set(first) - set(second))
        matching = nx.max_weight_matching(remaining, maxcardinality=True)
        if 2 * len(matching) != len(remaining):
            return False
    return True


def legal_gate_expansion(graph, faces, prefix):
    """Check that expanding the fixed gates again yields a plane brace."""

    sites = []
    for face_index, face in enumerate(faces):
        boundary = tuple(
            edge(face[index], face[(index + 1) % len(face)])
            for index in range(len(face))
        )
        if GATE0 in boundary and GATE1 in boundary:
            first, second = sorted((boundary.index(GATE0), boundary.index(GATE1)))
            sites.append((face_index, first, second))
    if len(sites) != 1:
        return False
    face_index, first, second = sites[0]
    child, _child_faces, _chosen = expand_on_face(
        graph, faces, face_index, first, second, prefix
    )
    return is_brace(child)


def repair_key(first, second):
    return frozenset((frozenset(first), frozenset(second)))


# Any operation wholly inside one pole while retaining the two original
# attachments leaves a nontrivial 2-edge cut.  Therefore a brace repair must
# make the boundary of each original pole larger than two.
assert boundary_size(G, LEFT_POLE) == boundary_size(G, RIGHT_POLE) == 2
validate_faces(G, BASE_FACES)

# One C4 is the absolute minimum.  Exactly one one-step graph is a brace, but
# its square chord separates the two gates into different faces.
one_step = tuple(expansion_sites(G, BASE_FACES, "one"))
assert len(one_step) == 99
one_connectivity = Counter(
    nx.node_connectivity(graph) for graph, _faces, _choice in one_step
)
assert one_connectivity == Counter({2: 94, 3: 5})
one_step_braces = tuple(
    (graph, faces, chosen)
    for graph, faces, chosen in one_step
    if nx.node_connectivity(graph) >= 3 and is_brace(graph)
)
assert len(one_step_braces) == 1
assert wide_arcs(one_step_braces[0][1]) is None

# Two steps are the next possible size.  Enumerate both orders and every
# intermediate facial site; only then apply the necessary pole-boundary,
# wide, connectivity and brace filters.
counts = Counter()
brace_sequences = []
for first_number, (intermediate, intermediate_faces, first_choice) in enumerate(one_step):
    for repaired, repaired_faces, second_choice in expansion_sites(
        intermediate, intermediate_faces, f"two{first_number}"
    ):
        counts["two_step_sequences"] += 1
        if boundary_size(repaired, LEFT_POLE) <= 2:
            continue
        if boundary_size(repaired, RIGHT_POLE) <= 2:
            continue
        counts["both_original_boundaries_broken"] += 1
        arcs = wide_arcs(repaired_faces)
        if arcs is None:
            continue
        counts["wide_preserved"] += 1
        connectivity = nx.node_connectivity(repaired)
        counts[f"connectivity_{connectivity}"] += 1
        if connectivity < 3:
            continue
        brace = is_brace(repaired)
        counts["brace" if brace else "nonbrace"] += 1
        if brace:
            legal = legal_gate_expansion(
                repaired,
                repaired_faces,
                f"legal{first_number}_{len(brace_sequences)}_",
            )
            counts["legal_gate" if legal else "illegal_gate"] += 1
            if legal:
                brace_sequences.append(
                    (repaired, repaired_faces, first_choice, second_choice, arcs)
                )

print(f"raw two-step counts: {counts}", flush=True)
assert counts == Counter(
    {
        "two_step_sequences": 11083,
        "both_original_boundaries_broken": 2376,
        "wide_preserved": 968,
        "connectivity_2": 840,
        "connectivity_3": 128,
        "nonbrace": 120,
        "brace": 8,
        "legal_gate": 8,
    }
)
assert len(brace_sequences) == 8

# The eight labelled sequences are four disjoint repair pairs in the two
# commuting orders.  Profile one representative of each repaired graph.
representatives = {}
for record in brace_sequences:
    key = repair_key(record[2], record[3])
    representatives.setdefault(key, record)
assert len(representatives) == 4


def fibre_profile(graph):
    residual = graph.subgraph(set(graph) - ROOT_SQUARE).copy()
    matchings = base["enumerate_matchings"](residual)

    def in_fibre(matching):
        signature = base["complement_signature"](residual, matching)
        return (
            len(signature) == 2
            and all(rank == 0 for _, _, rank in signature)
            and {ends for _, ends, _ in signature} == TERMINAL_PAIRING
        )

    fibre = tuple(matching for matching in matchings if in_fibre(matching))
    sector1 = tuple(matching for matching in fibre if GATE1 in matching)
    sector0 = tuple(matching for matching in fibre if GATE1 not in matching)
    histogram = Counter(
        len(base["difference_components"](first, second))
        for first in sector1
        for second in sector0
    )
    crossing_cycles = tuple(
            tuple(sorted(first ^ second))
            for first in sector1
            for second in sector0
            if len(base["difference_components"](first, second)) == 1
    )
    crossing_cycle = min(crossing_cycles, key=lambda cycle: (len(cycle), cycle), default=None)
    return (
        len(matchings),
        len(fibre),
        len(sector1),
        len(sector0),
        histogram,
        crossing_cycle,
    )


profiles = []
for key, (graph, faces, first, second, arcs) in representatives.items():
    profiles.append((key, first, second, arcs, fibre_profile(graph)))

nonempty = tuple(record for record in profiles if record[-1][1] > 0)
empty = tuple(record for record in profiles if record[-1][1] == 0)
assert len(nonempty) == 1 and len(empty) == 3

_, first_live, second_live, live_arcs, live_profile = nonempty[0]
(
    matching_count,
    fibre_size,
    sector1_size,
    sector0_size,
    cross_histogram,
    crossing_cycle,
) = live_profile
assert (fibre_size, sector1_size, sector0_size) == (125, 25, 100)
assert cross_histogram == Counter(
    {1: 30, 2: 262, 3: 684, 4: 836, 5: 528, 6: 160}
)
assert crossing_cycle is not None and GATE1 in crossing_cycle
assert len(crossing_cycle) == 10

print("one-step facial C4 repairs: 99")
print("one-step connectivity distribution: kappa2^94 kappa3^5")
print("one-step braces: 1; legal-wide survivors among them: 0")
print("two-step labelled sequences: 11083")
print("wide kappa3 sequences: 128; braces: 8 = 4 commuting repair pairs")
print("fixed-gate legal expansions among the eight braces: 8")
print("brace repair fibre outcomes: empty^3, nonempty^1")
print(f"live repair choices: {first_live} and {second_live}")
print(f"live repaired wide arcs: {live_arcs}")
print(f"live residual perfect matchings: {matching_count}")
print("live fibre sectors: 25 and 100")
print("live cross-sector histogram: 1^30 2^262 3^684 4^836 5^528 6^160")
print(f"one explicit supplemented crossing cycle: {crossing_cycle}")
print("MINIMUM_DIRECTED_BRACE_REPAIRS_SUPPLEMENT_CROSSING_VERIFIED")
