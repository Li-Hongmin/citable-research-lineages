#!/usr/bin/env python3
"""Verify the minimum octagonal-prism restricted-gate coloop."""

from __future__ import annotations

from collections import Counter
from itertools import combinations

import networkx as nx


Edge = tuple[int, int]
Matching = frozenset[Edge]


def edge(u: int, v: int) -> Edge:
    return (u, v) if u < v else (v, u)


def enumerate_perfect_matchings(
    graph: nx.Graph, remaining: frozenset[int]
):
    if not remaining:
        yield frozenset()
        return
    u = min(remaining)
    for v in sorted(graph[u]):
        if v not in remaining:
            continue
        for tail in enumerate_perfect_matchings(
            graph, remaining - {u, v}
        ):
            yield tail | {edge(u, v)}


def is_rooted_target(
    graph: nx.Graph, matching: Matching, root: Edge
) -> bool:
    if root not in matching:
        return False
    complement = graph.edge_subgraph(
        {edge(*item) for item in graph.edges()} - matching
    ).copy()
    components = list(nx.connected_components(complement))
    return (
        len(components) == 2
        and all(complement.degree(vertex) == 2 for vertex in complement)
        and not any(set(root) <= component for component in components)
    )


def expected_target(n: int, j: int) -> Matching:
    top = {edge(0, 1), edge(j, (j + 1) % n)}
    bottom = {edge(n, n + 1), edge(n + j, n + ((j + 1) % n))}
    excluded = {0, 1, j, (j + 1) % n}
    rungs = {edge(i, n + i) for i in range(n) if i not in excluded}
    return frozenset(top | bottom | rungs)


def verify_brace(graph: nx.Graph, matchings: tuple[Matching, ...]) -> None:
    assert not nx.number_of_selfloops(graph)
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    assert set(dict(graph.degree()).values()) == {3}
    edges = tuple(edge(*item) for item in graph.edges())
    for first, second in combinations(edges, 2):
        if set(first).isdisjoint(second):
            assert any(first in matching and second in matching for matching in matchings)


def main() -> None:
    n = 8
    graph = nx.circular_ladder_graph(n)
    matchings = tuple(
        enumerate_perfect_matchings(graph, frozenset(graph.nodes()))
    )
    verify_brace(graph, matchings)

    root = edge(n, n + 1)
    gates = (edge(0, 1), edge(4, 5))
    targets = tuple(
        matching
        for matching in matchings
        if is_rooted_target(graph, matching, root)
    )
    expected = {
        expected_target(n, j)
        for j in range(n)
        if j not in {n - 1, 0, 1}
    }
    assert set(targets) == expected
    assert len(targets) == 5
    patterns = Counter(
        "".join("1" if gate in matching else "0" for gate in gates)
        for matching in targets
    )
    assert patterns == Counter({"10": 4, "11": 1})
    assert all(gates[0] in matching for matching in targets)
    assert sum(gates[1] not in matching for matching in targets) == 4

    frozen = nx.from_graph6_bytes(b"O????B_sDOI_I_DO@W?M?")
    assert nx.is_isomorphic(graph, frozen)
    print("EVEN_PRISM_RESTRICTED_COLOOP_VERIFIED")


if __name__ == "__main__":
    main()
