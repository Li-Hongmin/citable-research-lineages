# Wide restricted-gate coloop

This bundle verifies the finite minimum-width example used in
[Note 083](../../../notes/083-a-wide-gate-can-be-a-restricted-coloop.md).
The arbitrary even-prism classification is proved analytically in the note.

The verifier constructs the octagonal prism directly, enumerates its entire
perfect-matching family, verifies planarity, cubicity, bipartiteness and
brace (2)-extendability, and then reconstructs all rooted targets for root
(B_0).  It checks that their gate profile at (T_0,T_4) is
(10^4,11^1), and that the graph is isomorphic to the frozen order-(16)
certificate from the existing lower-order census.

Run from the AIMath project root:

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/wide-restricted-gate-coloop/verify_even_prism_restricted_coloop.py

The required final line is

    EVEN_PRISM_RESTRICTED_COLOOP_VERIFIED

This computation certifies the finite instance.  It is not the proof of the
arbitrary-(n) statement and does not test the unresolved two-gate
restricted-coloop question.
