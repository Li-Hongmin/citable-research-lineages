# Legal-wide atomic two-switch certificate

This bundle verifies the minimum member used in Note 087.  The graph is the
octagonal prism (C_8\square K_2), with root (B_0), square-forced gate
(T_0), and surviving legal-wide gate (T_4).

Run from the AIMath root:

```text
python3 units/barnette/computations/bundles/legal-wide-atomic-two-switch/verify_octagonal_prism_atomic_pair.py
```

The frozen run used Python 3.14.6 and completed in 0.04 seconds on the
project machine.  The verifier uses only the Python standard library.  It
checks an explicit
cellular plane embedding, cubic bipartite incidence, the brace extension
condition for every independent edge pair, all 49 perfect matchings, the
complete five-member rooted-target/fixed-pairing fibre, the local
two-(C_4) mask set \(\{00,11\}\), and the external one-(C_6) crossing
witness showing that the selected pair is not globally minimum.

Expected marker:

```text
LEGAL_WIDE_ATOMIC_TWO_SWITCH_VERIFIED
```

The infinite even-prism statement in Note 087 is analytic; this fixed
certificate independently checks its smallest displayed instance.  The
frozen stdout is [output.txt](output.txt).  The verifier SHA-256 is
\(845686c66918a5c10ac531969b1519fff1653baf8983095b6681db6c694fe777\).
