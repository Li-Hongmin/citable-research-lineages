"""Fixed-instance certificate for the octagonal-prism quantifier boundary."""

from itertools import combinations


N = 8


def canon(a, b):
    return tuple(sorted((a, b)))


def T(i):
    return canon(f"t{i % N}", f"t{(i + 1) % N}")


def B(i):
    return canon(f"b{i % N}", f"b{(i + 1) % N}")


def rung(i):
    return canon(f"t{i % N}", f"b{i % N}")


vertices = {f"t{i}" for i in range(N)} | {f"b{i}" for i in range(N)}
edges = {T(i) for i in range(N)} | {B(i) for i in range(N)} | {
    rung(i) for i in range(N)
}


def enumerate_perfect_matchings(vset, eset):
    incident = {v: set() for v in vset}
    for item in eset:
        for vertex in item:
            incident[vertex].add(item)

    def rec(uncovered, chosen):
        if not uncovered:
            yield frozenset(chosen)
            return
        vertex = min(
            uncovered,
            key=lambda value: len(
                [item for item in incident[value] if set(item) <= uncovered]
            ),
        )
        for item in sorted(incident[vertex]):
            if set(item) <= uncovered:
                yield from rec(uncovered - set(item), chosen + [item])

    return list(rec(set(vset), []))


def components(vset, eset):
    adjacency = {v: set() for v in vset}
    for left, right in eset:
        adjacency[left].add(right)
        adjacency[right].add(left)
    result = []
    unseen = set(vset)
    while unseen:
        start = min(unseen)
        stack = [start]
        component = set()
        while stack:
            vertex = stack.pop()
            if vertex in component:
                continue
            component.add(vertex)
            stack.extend(adjacency[vertex] - component)
        unseen -= component
        result.append(component)
    return result


def is_rooted_target(matching):
    if B(0) not in matching:
        return False
    complement_components = components(vertices, edges - set(matching))
    return len(complement_components) == 2 and not any(
        {"b0", "b1"} <= component for component in complement_components
    )


# Simple, cubic and bipartite.
assert len(edges) == 24 and all(left != right for left, right in edges)
assert all(sum(vertex in item for item in edges) == 3 for vertex in vertices)
colour = {f"t{i}": i % 2 for i in range(N)} | {
    f"b{i}": 1 - (i % 2) for i in range(N)
}
assert all(colour[left] != colour[right] for left, right in edges)

# A spherical cellular embedding: two rim faces and eight side squares.
faces = [
    [f"t{i}" for i in range(N)],
    [f"b{i}" for i in reversed(range(N))],
] + [
    [f"t{i}", f"b{i}", f"b{(i + 1) % N}", f"t{(i + 1) % N}"]
    for i in range(N)
]
directed_face_edges = []
for face in faces:
    directed_face_edges.extend(zip(face, face[1:] + face[:1]))
assert len(directed_face_edges) == 2 * len(edges)
assert {canon(left, right) for left, right in directed_face_edges} == edges
assert len(set(directed_face_edges)) == 2 * len(edges)
assert len(vertices) - len(edges) + len(faces) == 2

# Brace certificate: every independent edge pair extends to a perfect matching.
perfect_matchings = enumerate_perfect_matchings(vertices, edges)
assert len(perfect_matchings) == 49
for first, second in combinations(edges, 2):
    if set(first).isdisjoint(second):
        assert any({first, second} <= matching for matching in perfect_matchings)

# The legal-wide interface and root--gate square.
root, gate0, gate1 = B(0), T(0), T(4)
square_q = {B(0), rung(1), T(0), rung(0)}
assert root in square_q and gate0 in square_q and set(root).isdisjoint(gate0)
assert 4 - 1 == 3 and N - 4 - 1 == 3

# Complete rooted-target classification.
H = frozenset({T(0), B(0)} | {rung(i) for i in range(N) if i not in {0, 1}})
side_square = {
    i: frozenset({T(i), B(i), rung(i), rung(i + 1)}) for i in range(N)
}
expected_targets = {
    H ^ side_square[j] for j in range(N) if j not in {N - 1, 0, 1}
}
targets = {matching for matching in perfect_matchings if is_rooted_target(matching)}
assert targets == expected_targets and len(targets) == 5

# Exact fixed-pairing fibre after deleting Q.
q_vertices = {"b0", "b1", "t1", "t0"}
r_vertices = vertices - q_vertices
r_edges = {item for item in edges if set(item) <= r_vertices}
terminals = ("b7", "b2", "t2", "t7")
required_pairing = {frozenset(("b7", "t7")), frozenset(("b2", "t2"))}


def in_fibre(matching):
    complement = r_edges - set(matching)
    degrees = {
        vertex: sum(vertex in item for item in complement) for vertex in r_vertices
    }
    if any(
        degrees[vertex] != (1 if vertex in terminals else 2)
        for vertex in r_vertices
    ):
        return False
    complement_components = components(r_vertices, complement)
    endpoint_pairs = {
        frozenset(component & set(terminals))
        for component in complement_components
        if component & set(terminals)
    }
    return len(complement_components) == 2 and endpoint_pairs == required_pairing


r_matchings = set(enumerate_perfect_matchings(r_vertices, r_edges))
fibre = {matching for matching in r_matchings if in_fibre(matching)}
expected_fibre = {frozenset(matching - {root, gate0}) for matching in targets}
assert fibre == expected_fibre and len(fibre) == 5

# Local atomic two-C4 pair: only masks 00 and 11 are in the fibre.
M4 = H ^ side_square[4]
M2 = H ^ side_square[2]
L4 = frozenset(M4 - {root, gate0})
L2 = frozenset(M2 - {root, gate0})
C4, C2 = side_square[4], side_square[2]
assert gate1 in M4 and gate1 not in M2
assert C4.isdisjoint(C2)
assert M4 ^ M2 == C4 | C2
assert {
    frozenset(L4 ^ frozenset(C4)),
    frozenset(L4 ^ frozenset(C2)),
}.isdisjoint(fibre)
assert frozenset(L4 ^ frozenset(C4) ^ frozenset(C2)) == L2

# The two proper-toggle defects: wrong pairing, then an extra closed C4.
wrong_pairing_state = frozenset(H - {root, gate0})
wrong_components = components(r_vertices, r_edges - set(wrong_pairing_state))
wrong_pairs = {
    frozenset(component & set(terminals)) for component in wrong_components
}
assert wrong_pairs == {
    frozenset(("b7", "b2")),
    frozenset(("t7", "t2")),
}
double_state = frozenset((H ^ C4 ^ C2) - {root, gate0})
double_components = components(r_vertices, r_edges - set(double_state))
assert len(double_components) == 3
assert {"t3", "t4", "b4", "b3"} in double_components

# Global crossing witness: the local atomic pair is not minimum cross-sector.
M3 = H ^ side_square[3]
crossing = M4 ^ M3
assert gate1 in M4 and gate1 not in M3
assert len(crossing) == 6
crossing_vertices = set().union(*map(set, crossing))
assert len(crossing_vertices) == 6
assert all(
    sum(vertex in item for item in crossing) == 2 for vertex in crossing_vertices
)

print("LEGAL_WIDE_ATOMIC_TWO_SWITCH_VERIFIED")
print("perfect_matchings=49 rooted_targets=5 fibre=5")
print("local_masks={00,11}; global_crossing=M4^M3 is one C6")
