#!/usr/bin/env python3
"""Complete fixed-fibre audit of the unique serializable Note 099 2-cover.

Only the labelled order-40 child obtained by applying the two disjoint sites

    A = {b2-b3, t0-t1},   C = {t2-t3, x5-x9}

is constructed.  The two expansion orders are rebuilt independently with
site-based new-vertex labels and are required to give the same labelled graph
and the same plane face system.  Perfect matchings of that one final graph are
then enumerated directly; no neighbouring sites or graphs are searched.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations
from pathlib import Path
import contextlib
import hashlib
import io
import runpy

import networkx as nx


HERE = Path(__file__).resolve().parent
CLASSIFIER = (
    HERE.parent
    / "c4-crossing-lift-and-note099-one-step"
    / "classify_note099_one_step_expansions.py"
)

with contextlib.redirect_stdout(io.StringIO()):
    BASE = runpy.run_path(CLASSIFIER)

edge = BASE["edge"]
cyclic_equal = BASE["cyclic_equal"]
delta_component_count = BASE["delta_component_count"]
enumerate_perfect_matchings = BASE["enumerate_perfect_matchings"]
face_edges = BASE["face_edges"]
legal_wide = BASE["legal_wide"]
replace_dart = BASE["replace_dart"]
validate_faces = BASE["validate_faces"]

ROOT = BASE["ROOT"]
FORCED_GATE = BASE["FORCED_GATE"]
SURVIVING_GATE = BASE["SURVIVING_GATE"]
ROOT_SQUARE = ("u", "v", "x", "y")
ROOT_SQUARE_EDGES = BASE["ROOT_SQUARE_EDGES"]

Site = tuple[frozenset[str], frozenset[str]]
Matching = frozenset[frozenset[str]]

A: Site = (edge("b2", "b3"), edge("t0", "t1"))
C: Site = (edge("t2", "t3"), edge("x5", "x9"))


def edge_key(item: frozenset[str]) -> tuple[str, str]:
    return tuple(sorted(item))  # type: ignore[return-value]


def matching_key(matching: Matching) -> tuple[tuple[str, str], ...]:
    return tuple(sorted(edge_key(item) for item in matching))


def legal_locations(
    faces: tuple[tuple[str, ...], ...], selected: Site
) -> tuple[tuple[int, int, int], ...]:
    if not selected[0].isdisjoint(selected[1]):
        return ()
    locations = []
    selected_set = frozenset(selected)
    for face_index, face in enumerate(faces):
        positions = tuple(
            index
            for index in range(len(face))
            if edge(face[index], face[(index + 1) % len(face)]) in selected_set
        )
        if len(positions) != 2:
            continue
        first_index, second_index = sorted(positions)
        distance = second_index - first_index
        if distance not in (1, len(face) - 1) and distance % 2 == 0:
            locations.append((face_index, first_index, second_index))
    return tuple(locations)


def expand(
    graph: nx.Graph,
    faces: tuple[tuple[str, ...], ...],
    selected: Site,
    prefix: str,
) -> tuple[nx.Graph, tuple[tuple[str, ...], ...], dict[str, object]]:
    """Apply one uniquely located facial C4 expansion."""

    locations = legal_locations(faces, selected)
    assert len(locations) == 1
    face_index, first_index, second_index = locations[0]
    face = faces[face_index]
    u, v = face[first_index], face[(first_index + 1) % len(face)]
    x, y = face[second_index], face[(second_index + 1) % len(face)]
    p, q = edge(u, v), edge(x, y)
    assert frozenset((p, q)) == frozenset(selected)
    a, b, c, d = tuple(prefix + letter for letter in "abcd")

    child = graph.copy()
    child.remove_edge(u, v)
    child.remove_edge(x, y)
    local_edges = (
        edge(u, a),
        edge(a, b),
        edge(b, v),
        edge(x, c),
        edge(c, d),
        edge(d, y),
        edge(a, d),
        edge(b, c),
    )
    child.add_edges_from(tuple(item) for item in local_edges)

    updated = []
    for index, old_face in enumerate(faces):
        if index == face_index:
            continue
        new_face = replace_dart(old_face, v, u, (b, a))
        new_face = replace_dart(new_face, y, x, (d, c))
        updated.append(new_face)
    updated.extend(
        (
            face[first_index + 1 : second_index + 1] + (c, b),
            face[second_index + 1 :] + face[: first_index + 1] + (a, d),
            (a, b, c, d),
        )
    )
    child_faces = tuple(updated)
    validate_faces(child, child_faces)
    descriptor: dict[str, object] = {
        "prefix": prefix,
        "p": p,
        "q": q,
        "local": local_edges,
    }
    return child, child_faces, descriptor


def canonical_cycle(face: tuple[str, ...]) -> tuple[str, ...]:
    variants = []
    for oriented in (face, tuple(reversed(face))):
        variants.extend(
            oriented[index:] + oriented[:index] for index in range(len(oriented))
        )
    return min(variants)


def face_system(faces: tuple[tuple[str, ...], ...]) -> frozenset[tuple[str, ...]]:
    return frozenset(canonical_cycle(face) for face in faces)


def build(order: tuple[str, str]):
    graph = BASE["PARENT_GRAPH"].copy()
    faces = BASE["PARENT_FACES"]
    descriptors = {}
    sites = {"A": A, "C": C}
    for name in order:
        graph, faces, descriptor = expand(graph, faces, sites[name], name + "_")
        descriptors[name] = descriptor
    return graph, faces, descriptors


def target(graph: nx.Graph, matching: Matching) -> bool:
    """The inherited fixed-pairing two-path fibre, in square-closed form."""

    if ROOT not in matching or FORCED_GATE not in matching:
        return False
    complement = nx.Graph()
    complement.add_nodes_from(graph)
    complement.add_edges_from(
        tuple(item)
        for item in frozenset(edge(left, right) for left, right in graph.edges())
        - matching
    )
    assert set(dict(complement.degree()).values()) == {2}
    components = tuple(nx.connected_components(complement))
    if len(components) != 2:
        return False
    root_vertices = set(ROOT)
    return all(len(root_vertices & component) == 1 for component in components)


def brace_certificate(
    graph: nx.Graph, matchings: tuple[Matching, ...]
) -> tuple[int, int]:
    edges = frozenset(edge(left, right) for left, right in graph.edges())
    independent = {
        frozenset((first, second))
        for first, second in combinations(edges, 2)
        if first.isdisjoint(second)
    }
    covered = {
        frozenset((first, second))
        for matching in matchings
        for first, second in combinations(matching, 2)
    }
    assert independent <= covered
    return len(independent), len(covered & independent)


def contract_matching(
    matching: Matching, descriptor: dict[str, object]
) -> Matching | None:
    """Contract a gadget matching when it is one of the five parent lifts."""

    p = descriptor["p"]
    q = descriptor["q"]
    local = descriptor["local"]
    assert isinstance(p, frozenset) and isinstance(q, frozenset)
    assert isinstance(local, tuple)
    ua, ab, bv, xc, cd, dy, ad, bc = local
    patch = matching & frozenset(local)
    patterns: dict[frozenset[frozenset[str]], frozenset[frozenset[str]]] = {
        frozenset((ua, bv, xc, dy)): frozenset((p, q)),
        frozenset((ua, bv, cd)): frozenset((p,)),
        frozenset((ab, xc, dy)): frozenset((q,)),
        frozenset((ab, cd)): frozenset(),
        frozenset((ad, bc)): frozenset(),
    }
    if patch not in patterns:
        # The only remaining local matching patterns are
        # {ua,bc,dy} and {ad,bv,xc}; neither contracts to a parent matching.
        assert patch in (frozenset((ua, bc, dy)), frozenset((ad, bv, xc)))
        return None
    return (matching - frozenset(local)) | patterns[patch]


def patch_pattern(matching: Matching, descriptor: dict[str, object]) -> str:
    local = descriptor["local"]
    assert isinstance(local, tuple)
    ua, ab, bv, xc, cd, dy, ad, bc = local
    patch = matching & frozenset(local)
    names = {
        frozenset((ua, bv, xc, dy)): "11",
        frozenset((ua, bv, cd)): "10",
        frozenset((ab, xc, dy)): "01",
        frozenset((ad, bc)): "00_subdivide",
        frozenset((ab, cd)): "00_reconnect",
        frozenset((ua, bc, dy)): "noncontractible_uy",
        frozenset((ad, bv, xc)): "noncontractible_vx",
    }
    assert patch in names
    return names[patch]


def perfect(graph: nx.Graph, matching: Matching) -> bool:
    return (
        len(matching) * 2 == graph.number_of_nodes()
        and matching <= frozenset(edge(left, right) for left, right in graph.edges())
        and Counter(vertex for item in matching for vertex in item)
        == Counter({vertex: 1 for vertex in graph})
    )


def ancestry(
    matching: Matching,
    descriptors: dict[str, dict[str, object]],
    one_step_graphs: dict[str, nx.Graph],
) -> dict[str, object]:
    contracted_a = contract_matching(matching, descriptors["A"])
    contracted_c = contract_matching(matching, descriptors["C"])
    assert contracted_a is None or perfect(one_step_graphs["C"], contracted_a)
    assert contracted_c is None or perfect(one_step_graphs["A"], contracted_c)

    parent_from_a = (
        None
        if contracted_a is None
        else contract_matching(contracted_a, descriptors["C"])
    )
    parent_from_c = (
        None
        if contracted_c is None
        else contract_matching(contracted_c, descriptors["A"])
    )
    if parent_from_a is not None and parent_from_c is not None:
        assert parent_from_a == parent_from_c
    parent = parent_from_a if parent_from_a is not None else parent_from_c
    if parent is not None:
        assert perfect(BASE["PARENT_GRAPH"], parent)
    return {
        "A_pattern": patch_pattern(matching, descriptors["A"]),
        "C_pattern": patch_pattern(matching, descriptors["C"]),
        "contracts_A": contracted_a is not None,
        "contracts_C": contracted_c is not None,
        "target_after_contracting_A": (
            target(one_step_graphs["C"], contracted_a)
            if contracted_a is not None
            else None
        ),
        "target_after_contracting_C": (
            target(one_step_graphs["A"], contracted_c)
            if contracted_c is not None
            else None
        ),
        "parent": parent,
        "parent_in_fibre": parent in BASE["OLD_FIBRE_SET"] if parent else False,
        "parent_sector": (
            int(SURVIVING_GATE in parent)
            if parent is not None and parent in BASE["OLD_FIBRE_SET"]
            else None
        ),
    }


def difference_cycle(first: Matching, second: Matching) -> tuple[str, ...]:
    difference = first ^ second
    graph = nx.Graph()
    graph.add_edges_from(tuple(item) for item in difference)
    assert nx.number_connected_components(graph) == 1
    start = min(graph)
    candidates = []
    for neighbour in sorted(graph[start]):
        sequence = [start]
        previous, current = start, neighbour
        while current != start:
            sequence.append(current)
            following = sorted(set(graph[current]) - {previous})
            assert len(following) == 1
            previous, current = current, following[0]
        candidates.append(tuple(sequence))
    return min(candidates)


def format_matching(matching: Matching) -> str:
    return " ".join("-".join(item) for item in matching_key(matching))


def main() -> None:
    old_crossings = BASE["OLD_CROSSINGS"]
    assert len(old_crossings) == 69
    assert all(
        any(
            any(all(site_edge in endpoint for site_edge in site) for endpoint in pair)
            for site in (A, C)
        )
        for pair in old_crossings
    )

    graph_ac, faces_ac, descriptors_ac = build(("A", "C"))
    graph_ca, faces_ca, descriptors_ca = build(("C", "A"))
    edges_ac = frozenset(edge(left, right) for left, right in graph_ac.edges())
    edges_ca = frozenset(edge(left, right) for left, right in graph_ca.edges())
    assert frozenset(graph_ac) == frozenset(graph_ca)
    assert edges_ac == edges_ca
    assert face_system(faces_ac) == face_system(faces_ca)
    assert descriptors_ac == descriptors_ca
    graph, faces, descriptors = graph_ac, faces_ac, descriptors_ac
    graph_digest = hashlib.sha256(
        ("\n".join("-".join(item) for item in sorted(map(edge_key, edges_ac))) + "\n").encode()
    ).hexdigest()
    assert graph_digest == "d25416910397fe43ab2f52d17103a9039fc35454df83f49ca1010d3d14c6b998"

    assert graph.number_of_nodes() == 40
    assert graph.number_of_edges() == 60
    assert nx.number_of_selfloops(graph) == 0
    assert len(edges_ac) == graph.number_of_edges()
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.check_planarity(graph)[0]
    validate_faces(graph, faces)
    assert nx.node_connectivity(graph) == 3
    assert all(item in edges_ac for item in ROOT_SQUARE_EDGES)
    assert sum(cyclic_equal(face, ROOT_SQUARE) for face in faces) == 1
    assert legal_wide(faces) == (5, 5)

    vertices = frozenset(graph)
    matchings = enumerate_perfect_matchings(vertices, edges_ac)
    assert all(perfect(graph, matching) for matching in matchings)
    independent_pairs, covered_pairs = brace_certificate(graph, matchings)
    assert (len(matchings), independent_pairs, covered_pairs) == (3389, 1650, 1650)

    fibre = tuple(matching for matching in matchings if target(graph, matching))
    sector0 = tuple(matching for matching in fibre if SURVIVING_GATE not in matching)
    sector1 = tuple(matching for matching in fibre if SURVIVING_GATE in matching)
    distribution = Counter(
        delta_component_count(first, second)
        for first in sector0
        for second in sector1
    )
    assert (len(fibre), len(sector0), len(sector1)) == (129, 32, 97)
    assert distribution == Counter({1: 315, 2: 1004, 3: 1083, 4: 528, 5: 150, 6: 24})
    assert sector0 and sector1
    minimum = min(distribution)
    crossing_pairs = sorted(
        (
            (first, second)
            for first in sector0
            for second in sector1
            if delta_component_count(first, second) == 1
        ),
        key=lambda pair: (matching_key(pair[0]), matching_key(pair[1])),
    )
    assert len(crossing_pairs) == distribution.get(1, 0)

    # Rebuild both one-step graphs for literal ancestry checks.
    graph_a, _faces_a, _descriptor_a = (
        lambda built: (built[0], built[1], built[2]["A"])
    )(build(("A",)))
    graph_c, _faces_c, _descriptor_c = (
        lambda built: (built[0], built[1], built[2]["C"])
    )(build(("C",)))
    one_step_graphs = {"A": graph_a, "C": graph_c}

    ancestry_histogram = Counter()
    explicit = None
    explicit_ancestry = None
    if crossing_pairs:
        explicit = crossing_pairs[0]
        explicit_ancestry = tuple(
            ancestry(endpoint, descriptors, one_step_graphs) for endpoint in explicit
        )
    for first, second in crossing_pairs:
        first_a = ancestry(first, descriptors, one_step_graphs)
        second_a = ancestry(second, descriptors, one_step_graphs)
        parents = (first_a["parent"], second_a["parent"])
        if None in parents:
            ancestry_histogram["noncontractible_endpoint"] += 1
        elif all(parent in BASE["OLD_FIBRE_SET"] for parent in parents):
            assert isinstance(parents[0], frozenset) and isinstance(parents[1], frozenset)
            components = delta_component_count(parents[0], parents[1])
            ancestry_histogram[f"old_fibre_{components}_components"] += 1
            # A parent old crossing cannot survive the exact A,C kill cover.
            assert components != 1
        else:
            ancestry_histogram["contractible_but_parent_outside_fibre"] += 1
    assert ancestry_histogram == Counter(
        {"noncontractible_endpoint": 264, "contractible_but_parent_outside_fibre": 51}
    )

    print("orders AC and CA give the same labelled graph and face system")
    print(
        f"final graph: vertices={graph.number_of_nodes()} edges={graph.number_of_edges()} "
        f"connectivity={nx.node_connectivity(graph)} legal-wide={legal_wide(faces)} "
        f"edge-sha256={graph_digest}"
    )
    print(
        f"perfect matchings={len(matchings)}; brace independent pairs="
        f"{independent_pairs}/{covered_pairs}"
    )
    print(
        f"fixed fibre={len(fibre)}={len(sector0)}+{len(sector1)}; "
        + "cross distribution="
        + ",".join(f"{key}^{distribution[key]}" for key in sorted(distribution))
    )
    print(f"global cross-sector minimum={minimum}")
    print("crossing ancestry=" + repr(dict(sorted(ancestry_histogram.items()))))
    if explicit is not None and explicit_ancestry is not None:
        first, second = explicit
        print("explicit sector0 matching:", format_matching(first))
        print("explicit sector1 matching:", format_matching(second))
        print("explicit difference cycle:", "-".join(difference_cycle(first, second)))
        for index, record in enumerate(explicit_ancestry):
            printable = {key: value for key, value in record.items() if key != "parent"}
            parent = record["parent"]
            printable["parent_matching"] = (
                format_matching(parent) if isinstance(parent, frozenset) else None
            )
            print(f"explicit endpoint {index} ancestry:", repr(printable))
    assert minimum == 1
    assert crossing_pairs
    assert ancestry_histogram["old_fibre_1_components"] == 0
    print("NOTE099_TWO_STEP_FINAL_FIBRE_MINIMUM_ONE_VERIFIED")


if __name__ == "__main__":
    main()

