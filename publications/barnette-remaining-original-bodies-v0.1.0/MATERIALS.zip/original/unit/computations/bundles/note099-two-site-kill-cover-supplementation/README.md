# Note 099 two-site kill-cover supplementation

This bundle supports
[Note 102](../../../notes/102-the-unique-two-site-kill-cover-supplements-new-fibre-crossings.md).

Run from the AIMath root:

```bash
PYTHONHASHSEED=0 uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/note099-two-site-kill-cover-supplementation/verify_note099_old_crossing_kill_cover.py

PYTHONHASHSEED=0 uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/note099-two-site-kill-cover-supplementation/verify_note099_two_step_final_fibre.py
```

The first program reconstructs the 74 legal sites from the permanent
Note 101 records, solves the exact singleton/pair set-cover problem and
updates the rotation system to test both orders of all three minimum covers.

The second program constructs only the unique final graph from sites
\(A,C\), checks both construction orders, enumerates all perfect matchings,
certifies 2-extendability, classifies the complete fixed-pairing fibre and
freezes an explicit new alternating 14-cycle crossing with its ancestry.

Expected final markers:

```text
NOTE099_OLD_CROSSING_KILL_COVER_VERIFIED
NOTE099_TWO_STEP_FINAL_FIBRE_MINIMUM_ONE_VERIFIED
```

The second command prints the canonical edge SHA256

```text
d25416910397fe43ab2f52d17103a9039fc35454df83f49ca1010d3d14c6b998
```

The promotion environment was Python 3.12 with NetworkX supplied by `uv`
on 2026-08-28.

