#!/usr/bin/env python3
"""Exact set cover of the 69 inherited crossings in Note 099.

This verifier uses only the parent fibre and the 74 legal-wide sites frozen
in the permanent Note 101 bundle.  It never enumerates a perfect matching
of a multi-step child.  Sequential feasibility is checked directly in the
frozen plane embedding by updating its facial walks after each C4 move.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path
import contextlib
import hashlib
import io
import json
import runpy

import networkx as nx


HERE = Path(__file__).resolve().parent
BUNDLE = HERE.parent / "c4-crossing-lift-and-note099-one-step"
CLASSIFIER = BUNDLE / "classify_note099_one_step_expansions.py"
RECORDS = BUNDLE / "note099_one_step_expansions.json"

with contextlib.redirect_stdout(io.StringIO()):
    BASE = runpy.run_path(CLASSIFIER)

edge = BASE["edge"]
replace_dart = BASE["replace_dart"]
validate_faces = BASE["validate_faces"]
legal_wide = BASE["legal_wide"]


def edge_name(item: frozenset[str]) -> tuple[str, str]:
    left, right = sorted(item)
    return left, right


def site_name(
    selected: tuple[frozenset[str], frozenset[str]],
) -> tuple[tuple[str, str], tuple[str, str]]:
    return tuple(sorted(edge_name(item) for item in selected))  # type: ignore[return-value]


def named_site(
    first: tuple[str, str], second: tuple[str, str]
) -> tuple[tuple[str, str], tuple[str, str]]:
    return tuple(sorted((tuple(sorted(first)), tuple(sorted(second)))))  # type: ignore[return-value]


A = named_site(("b2", "b3"), ("t0", "t1"))
B = named_site(("b3", "t1"), ("t0", "x0"))
C = named_site(("t2", "t3"), ("x5", "x9"))
D = named_site(("t2", "x5"), ("t3", "x9"))

EXPECTED_COVERS = frozenset(
    (
        frozenset((A, B)),
        frozenset((A, C)),
        frozenset((C, D)),
    )
)


def selected_edges(
    name: tuple[tuple[str, str], tuple[str, str]],
) -> tuple[frozenset[str], frozenset[str]]:
    return tuple(frozenset(item) for item in name)  # type: ignore[return-value]


def legal_locations(
    faces: tuple[tuple[str, ...], ...],
    selected: tuple[frozenset[str], frozenset[str]],
) -> tuple[tuple[int, int, int], ...]:
    """Return face/index triples on which ``selected`` is a legal move."""

    if not selected[0].isdisjoint(selected[1]):
        return ()
    locations = []
    for face_index, face in enumerate(faces):
        positions = tuple(
            index
            for index in range(len(face))
            if edge(face[index], face[(index + 1) % len(face)]) in selected
        )
        if len(positions) != 2:
            continue
        first_index, second_index = sorted(positions)
        distance = second_index - first_index
        if distance not in (1, len(face) - 1) and distance % 2 == 0:
            locations.append((face_index, first_index, second_index))
    return tuple(locations)


def expand_in_current_face(
    graph: nx.Graph,
    faces: tuple[tuple[str, ...], ...],
    selected: tuple[frozenset[str], frozenset[str]],
    prefix: str,
) -> tuple[nx.Graph, tuple[tuple[str, ...], ...], tuple[int, int, int]]:
    """Perform one legal C4 move in the current combinatorial embedding."""

    locations = legal_locations(faces, selected)
    assert len(locations) == 1
    face_index, first_index, second_index = locations[0]
    face = faces[face_index]
    first_left = face[first_index]
    first_right = face[(first_index + 1) % len(face)]
    second_left = face[second_index]
    second_right = face[(second_index + 1) % len(face)]
    a, b, c, d = tuple(prefix + letter for letter in "abcd")

    child = graph.copy()
    child.remove_edge(first_left, first_right)
    child.remove_edge(second_left, second_right)
    child.add_edges_from(
        (
            (first_left, a),
            (a, b),
            (b, first_right),
            (second_left, c),
            (c, d),
            (d, second_right),
            (a, d),
            (b, c),
        )
    )

    updated = []
    for index, old_face in enumerate(faces):
        if index == face_index:
            continue
        new_face = replace_dart(old_face, first_right, first_left, (b, a))
        new_face = replace_dart(new_face, second_right, second_left, (d, c))
        updated.append(new_face)
    updated.extend(
        (
            face[first_index + 1 : second_index + 1] + (c, b),
            face[second_index + 1 :] + face[: first_index + 1] + (a, d),
            (a, b, c, d),
        )
    )
    child_faces = tuple(updated)
    validate_faces(child, child_faces)
    assert nx.is_bipartite(child)
    assert set(dict(child.degree()).values()) == {3}
    assert nx.node_connectivity(child) == 3
    assert nx.check_planarity(child)[0]
    return child, child_faces, locations[0]


def sequentially_executable(
    ordered_sites: tuple[
        tuple[tuple[str, str], tuple[str, str]],
        tuple[tuple[str, str], tuple[str, str]],
    ],
) -> bool:
    graph = BASE["PARENT_GRAPH"].copy()
    faces = BASE["PARENT_FACES"]
    for step, name in enumerate(ordered_sites):
        selected = selected_edges(name)
        if any(not graph.has_edge(*item) for item in name):
            return False
        if len(legal_locations(faces, selected)) != 1:
            return False
        graph, faces, _location = expand_in_current_face(
            graph, faces, selected, f"step{step}_"
        )
        assert graph.number_of_nodes() == 32 + 4 * (step + 1)
        assert graph.number_of_edges() == 48 + 6 * (step + 1)
        # The named rooted interface remains present and legal-wide.
        assert all(graph.has_edge(*tuple(item)) for item in BASE["ROOT_SQUARE_EDGES"])
        assert graph.has_edge(*tuple(BASE["SURVIVING_GATE"]))
        assert legal_wide(faces) is not None
    assert graph.number_of_nodes() == 40
    assert graph.number_of_edges() == 60
    if frozenset(ordered_sites) == frozenset((A, C)):
        assert legal_wide(faces) == (5, 5)
    return True


def main() -> None:
    assert hashlib.sha256(RECORDS.read_bytes()).hexdigest() == (
        "e67a8680ea1ab7009a521e37bc7f5c0fe251f5ddef8c0453766c140332770b90"
    )
    payload = json.loads(RECORDS.read_text())
    valid_names = frozenset(
        tuple(tuple(item) for item in record["selected"])
        for record in payload["records"]
        if record["brace"] and record["legal_wide_arcs"] is not None
    )
    assert len(valid_names) == 74

    crossings = tuple(BASE["OLD_CROSSINGS"])
    assert len(crossings) == 69
    sites = []
    for record in BASE["legal_moves"]():
        name = site_name(record["selected"])
        if name not in valid_names:
            continue
        killed = frozenset(
            index
            for index, pair in enumerate(crossings)
            if any(
                all(item in endpoint for item in record["selected"])
                for endpoint in pair
            )
        )
        sites.append((name, killed))
    sites.sort(key=lambda item: item[0])
    assert len(sites) == 74
    assert frozenset(name for name, _killed in sites) == valid_names

    universe = frozenset(range(69))
    singleton_covers = tuple(name for name, killed in sites if killed == universe)
    assert singleton_covers == ()

    two_covers = frozenset(
        frozenset((sites[first][0], sites[second][0]))
        for first, second in combinations(range(len(sites)), 2)
        if sites[first][1] | sites[second][1] == universe
    )
    assert two_covers == EXPECTED_COVERS

    killed_by_name = dict(sites)
    cover_profiles = {}
    for cover in sorted(two_covers, key=lambda item: sorted(item)):
        first, second = sorted(cover)
        first_kill = killed_by_name[first]
        second_kill = killed_by_name[second]
        cover_profiles[(first, second)] = (
            len(first_kill),
            len(second_kill),
            len(first_kill & second_kill),
        )
    assert cover_profiles == {
        tuple(sorted((A, B))): (50, 20, 1),
        tuple(sorted((A, C))): (50, 48, 29),
        tuple(sorted((C, D))): (48, 21, 0),
    }

    # Compress the full 74-site family by identical kill masks.  This is
    # diagnostic only; exact cover above is performed on all labelled sites.
    mask_classes: dict[frozenset[int], list[object]] = defaultdict(list)
    for name, killed in sites:
        mask_classes[killed].append(name)
    assert len(mask_classes) == 55
    assert Counter(map(len, mask_classes.values())) == Counter({1: 47, 2: 6, 3: 1, 12: 1})
    assert len(mask_classes[frozenset()]) == 12

    ordered_feasibility = {}
    for cover in two_covers:
        first, second = sorted(cover)
        ordered_feasibility[(first, second)] = sequentially_executable((first, second))
        ordered_feasibility[(second, first)] = sequentially_executable((second, first))

    # A and C lie on the disjoint original faces
    # (b1,b2,b3,t1,t0,x0) and (t2,x5,x9,t3), so either order works.
    # The other two covers use two crossing choices in the same original
    # face; the first move separates the edges of the second site.
    assert ordered_feasibility == {
        (A, B): False,
        (B, A): False,
        (A, C): True,
        (C, A): True,
        (C, D): False,
        (D, C): False,
    }

    # Since the feasible sites use four mutually disjoint old edges, a
    # surviving inherited matching keeps its membership bits at the second
    # site.  Thus the sequential death set is exactly the union already
    # certified above, without enumerating any child perfect matchings.
    assert killed_by_name[A] | killed_by_name[C] == universe

    print("sites 74; distinct kill masks 55; zero kill sites 12")
    print("minimum cover size 2; labelled minimum covers 3")
    print("A", A, "kill 50")
    print("B", B, "kill 20")
    print("C", C, "kill 48")
    print("D", D, "kill 21")
    print("minimum covers AB, AC, CD")
    print("sequentially executable minimum cover AC (both orders)")
    print("NOTE099_OLD_CROSSING_KILL_COVER_VERIFIED")


if __name__ == "__main__":
    main()

