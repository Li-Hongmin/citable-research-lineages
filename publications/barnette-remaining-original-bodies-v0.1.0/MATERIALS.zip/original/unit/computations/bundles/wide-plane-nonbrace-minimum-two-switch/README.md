# Wide plane nonbrace minimum two-switch certificate

This bundle verifies the 32-vertex countermodel of Note 088.  It starts
from the octagonal prism and replaces each of the top-rim edges \(T_3,T_5\)
by a plane two-pole \(Q_3-e\).

Run from the AIMath root:

    uv run --python 3.12 --with networkx units/barnette/computations/bundles/wide-plane-nonbrace-minimum-two-switch/verify_wide_plane_nonbrace_atomic_minimum.py

The frozen environment used Python 3.12.11 and NetworkX 3.6.1; the run
completed in 0.22 seconds on the project machine.  The script checks:

1. the explicit graph is simple, connected, plane, cubic and bipartite;
2. the gates are cofacial with closed arc sizes \(9,9\);
3. all 369 residual perfect matchings and the complete 48-member
   fixed-pairing fibre;
4. all \(16\cdot32=512\) cross-sector pairs, whose minimum
   symmetric-difference component count is exactly two;
5. an explicit two-\(C_4\) minimum pair and an explicit independent edge
   pair proving that the graph is not a brace.

Expected marker:

    WIDE_PLANE_NONBRACE_MINIMUM_ATOMIC_TWO_SWITCH_VERIFIED

This is a strict class-boundary countermodel.  It is not a counterexample
in the plane-brace class and makes no global order-minimality claim.  The
frozen stdout is [output.txt](output.txt).  The verifier SHA-256 is
\(1106c070da9d23311ebb33dc8731d791bb84a9f4a558339a18d4126eff76bf82\).
