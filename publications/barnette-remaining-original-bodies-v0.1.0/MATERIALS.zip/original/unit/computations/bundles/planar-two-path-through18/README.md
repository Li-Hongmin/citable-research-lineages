# Planar two-path target through order 18

This bundle proves the finite theorem in
[Note 064](../../../notes/064-the-planar-two-path-target-holds-through-order-eighteen.md).
It generates every connected simple cubic bipartite graph on
\(6,8,\ldots,18\) vertices, retains the plane braces, and checks every root
and every singleton/paired port split.

## Contents

- census_planar_brace_two_paths_through18.py is the isomorph-free
  generator/filter and exhaustive two-path search. It stores one explicit
  witness and the exact witness count for every fibre.
- verify_census_certificate.py independently checks the stored embeddings,
  brace property, strict Hall inequalities, and all explicit path witnesses.
- raw-output.txt records the terminal output of the accepted run.

The generated JSON certificate is deliberately not duplicated in the
repository: it is 365 KB, is reproduced byte-for-byte in under two seconds
on the recorded environment, and is checked immediately by the second
program.

## Reproduction

From this bundle directory:

    uv run --with 'networkx==3.6.1' \
      census_planar_brace_two_paths_through18.py \
      --output census_certificate.json

    uv run --with 'networkx==3.6.1' \
      verify_census_certificate.py census_certificate.json

Accepted environment:

    nauty 2.9.3: /opt/homebrew/bin/geng
    NetworkX 3.6.1
    Python 3 via uv

The two required terminal markers are

    PLANAR_BRACE_TWO_PATH_TARGET_VERIFIED_THROUGH_18
    PLANAR_BRACE_TWO_PATH_CENSUS_CERTIFICATE_VERIFIED

The trusted external coverage interfaces are the isomorph-free completeness
of geng and the exact planarity decision in NetworkX. Matching extension,
strict Hall, spherical rotations, and the path witnesses are checked
directly by bounded recursive or combinatorial code.
