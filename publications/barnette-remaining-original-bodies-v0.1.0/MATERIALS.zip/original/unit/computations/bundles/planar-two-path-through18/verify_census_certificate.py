#!/usr/bin/env python3
"""Direct checker for ``census_certificate.json``.

This checker does not trust NetworkX's planarity or matching routines.  It
checks each stored spherical face system combinatorially, tests every
independent two-edge matching by a small recursive matching search, and
checks every stored pair of paths directly against the graph edge set.
Generator completeness is the separate interface exercised by the census
driver itself.
"""

from __future__ import annotations

import argparse
from itertools import combinations
import json
from pathlib import Path

import networkx as nx


Edge = tuple[int, int]


def edge(first: int, second: int) -> Edge:
    return (first, second) if first < second else (second, first)


def perfect_matching_exists(graph: nx.Graph, vertices: frozenset[int]) -> bool:
    if not vertices:
        return True
    if len(vertices) % 2:
        return False
    first = min(
        vertices,
        key=lambda vertex: sum(neighbour in vertices for neighbour in graph[vertex]),
    )
    for neighbour in sorted(graph[first]):
        if neighbour in vertices and perfect_matching_exists(
            graph, vertices - {first, neighbour}
        ):
            return True
    return False


def verify_two_extendable(graph: nx.Graph) -> None:
    vertices = frozenset(graph)
    graph_edges = tuple(sorted(edge(first, second) for first, second in graph.edges()))
    checked = 0
    for first, second in combinations(graph_edges, 2):
        endpoints = frozenset(first + second)
        if len(endpoints) != 4:
            continue
        checked += 1
        assert perfect_matching_exists(graph, vertices - endpoints)
    assert checked > 0


def verify_strict_hall(graph: nx.Graph) -> None:
    colour = nx.bipartite.color(graph)
    for value in (0, 1):
        side = tuple(sorted(vertex for vertex in graph if colour[vertex] == value))
        for size in range(1, len(side) - 1):
            for shore in combinations(side, size):
                neighbours = set().union(*(set(graph[vertex]) for vertex in shore))
                assert len(neighbours) >= size + 2


def verify_spherical_faces(graph: nx.Graph, faces: list[list[int]]) -> None:
    directed = [
        (face[index], face[(index + 1) % len(face)])
        for face in faces
        for index in range(len(face))
    ]
    expected = {
        dart
        for first, second in graph.edges()
        for dart in ((first, second), (second, first))
    }
    assert len(directed) == len(set(directed)) == 2 * graph.number_of_edges()
    assert set(directed) == expected
    assert len(graph) - graph.number_of_edges() + len(faces) == 2

    # Around each vertex, the face-successor map must be one cyclic rotation,
    # rather than several pinched rotations sharing only the vertex label.
    successor: dict[int, dict[int, int]] = {vertex: {} for vertex in graph}
    for face in faces:
        for index, vertex in enumerate(face):
            predecessor = face[index - 1]
            following = face[(index + 1) % len(face)]
            assert predecessor not in successor[vertex]
            successor[vertex][predecessor] = following
    for vertex in graph:
        mapping = successor[vertex]
        assert set(mapping) == set(graph[vertex]) == set(mapping.values())
        start = min(mapping)
        orbit = []
        current = start
        while current not in orbit:
            orbit.append(current)
            current = mapping[current]
        assert current == start and set(orbit) == set(graph[vertex])


def verify_witness(graph: nx.Graph, root: int, witness: dict[str, object]) -> None:
    singleton = int(witness["singleton"])
    paired = tuple(int(vertex) for vertex in witness["paired"])
    free = int(witness["free_endpoint"])
    forest_edges = tuple(edge(*map(int, item)) for item in witness["forest_edges"])
    paths = tuple(tuple(map(int, path)) for path in witness["paths"])

    graph_edges = {edge(first, second) for first, second in graph.edges()}
    assert len(forest_edges) == len(set(forest_edges)) == len(graph) - 3
    assert set(forest_edges) <= graph_edges
    assert all(root not in selected for selected in forest_edges)

    support = nx.Graph()
    support.add_nodes_from(set(graph) - {root})
    support.add_edges_from(forest_edges)
    assert nx.is_forest(support) and nx.number_connected_components(support) == 2

    ports = tuple(sorted(graph[root]))
    assert singleton in ports and set(paired) == set(ports) - {singleton}
    colour = nx.bipartite.color(graph)
    root_side = {vertex for vertex in graph if colour[vertex] == colour[root]}
    opposite_side = set(graph) - root_side
    for vertex in set(graph) - {root}:
        expected_degree = 2
        if vertex in ports or vertex == free:
            expected_degree = 1
        assert support.degree(vertex) == expected_degree
    assert free in root_side - {root}
    assert set(ports) <= opposite_side

    assert len(paths) == 2
    assert set(paths[0]).isdisjoint(paths[1])
    assert set(paths[0]) | set(paths[1]) == set(graph) - {root}
    path_edges = {
        edge(path[index], path[index + 1])
        for path in paths
        for index in range(len(path) - 1)
    }
    assert path_edges == set(forest_edges)
    endpoint_sets = {frozenset((path[0], path[-1])) for path in paths}
    assert endpoint_sets == {frozenset(paired), frozenset((singleton, free))}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("certificate", type=Path, nargs="?", default=Path("census_certificate.json"))
    arguments = parser.parse_args()
    payload = json.loads(arguments.certificate.read_text())

    assert payload["coverage"]["isomorphism_representatives"] == 209
    assert payload["coverage"]["planar_brace_isomorphism_classes"] == 5
    assert payload["coverage"]["root_split_fibres"] == 210
    assert payload["conclusion"]["counterexamples_found"] == 0

    seen_graph6 = set()
    fibres = 0
    witnesses_checked = 0
    for record in payload["braces"]:
        graph6 = record["graph6"]
        assert graph6 not in seen_graph6
        seen_graph6.add(graph6)
        graph = nx.from_graph6_bytes(graph6.encode())
        stored_edges = {edge(*map(int, item)) for item in record["edges"]}
        assert stored_edges == {edge(first, second) for first, second in graph.edges()}
        assert len(graph) == record["order"]
        assert nx.number_of_selfloops(graph) == 0
        assert nx.is_connected(graph) and nx.is_bipartite(graph)
        assert set(dict(graph.degree()).values()) == {3}
        verify_spherical_faces(graph, record["faces"])
        verify_two_extendable(graph)
        verify_strict_hall(graph)

        roots = record["roots"]
        assert {item["root"] for item in roots} == set(graph)
        for root_record in roots:
            root = root_record["root"]
            ports = tuple(sorted(graph[root]))
            assert tuple(root_record["ports"]) == ports
            assert len(root_record["witnesses"]) == 3
            assert len(root_record["witness_counts_by_singleton_index"]) == 3
            assert min(root_record["witness_counts_by_singleton_index"]) > 0
            for index, witness in enumerate(root_record["witnesses"]):
                assert witness is not None and witness["singleton"] == ports[index]
                verify_witness(graph, root, witness)
                witnesses_checked += 1
            fibres += 3

    assert fibres == 210 and witnesses_checked == 210
    print(
        {
            "brace_graphs": len(seen_graph6),
            "root_split_fibres": fibres,
            "explicit_two_path_witnesses": witnesses_checked,
            "minimum_recorded_fibre_count": payload["conclusion"][
                "minimum_witness_count_in_any_root_split_fibre"
            ],
        }
    )
    print("PLANAR_BRACE_TWO_PATH_CENSUS_CERTIFICATE_VERIFIED")


if __name__ == "__main__":
    main()
