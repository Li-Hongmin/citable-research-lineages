#!/usr/bin/env python3
"""Verify the fixed order-26 all-P example and its one-edge-gap transfer."""

from __future__ import annotations

from collections import Counter
from itertools import combinations
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BASE_PATH = (
    HERE.parent
    / "rooted-split-bond-through26"
    / "classify_through26_nonsquare_kill_cover.py"
)


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


base = load_module(BASE_PATH, "one_edge_gap_base")
edge = base.edge

GRAPH6 = "Y?????????????w?Y?CW??w??[?EC?T??_W?D@??AK?@_O?GK??SA???"
SITE = frozenset((edge(3, 25), edge(11, 21)))
SHARED = edge(10, 17)
OPPOSITE = edge(9, 20)
CANDIDATES = (
    (edge(0, 13), edge(9, 24), edge(7, 22), 5, (3, 2), 4, 5),
    (edge(1, 14), edge(9, 24), edge(7, 22), 5, (3, 2), 4, 5),
    (edge(4, 15), edge(9, 24), edge(7, 22), 6, (5, 1), 1, 2),
    (edge(5, 23), edge(9, 24), edge(7, 22), 6, (5, 1), 1, 2),
)


def matching_key(matching):
    return tuple(sorted(matching))


def reconstruct_faces(graph: nx.Graph):
    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    faces = base.source.plane_faces(graph, embedding)
    base.validate_faces(graph, faces)
    return faces


def is_perfect_matching(graph: nx.Graph, matching) -> bool:
    if not matching <= {edge(*item) for item in graph.edges()}:
        return False
    degree = Counter(vertex for item in matching for vertex in item)
    return len(degree) == graph.number_of_nodes() and set(degree.values()) == {1}


def bond_graph(fibre, gate):
    sector0 = tuple(matching for matching in fibre if gate not in matching)
    sector1 = tuple(matching for matching in fibre if gate in matching)
    bonds = tuple(
        (first, second)
        for first in sector0
        for second in sector1
        if base.difference_component_count(first, second) == 1
    )
    return sector0, sector1, bonds


def local_type(matching):
    if SHARED not in matching:
        return "X"
    return "T" if OPPOSITE in matching else "P"


def verify_brace_by_two_extendability(graph, matchings):
    edges = tuple(sorted(edge(*item) for item in graph.edges()))
    independent = {
        frozenset((first, second))
        for first, second in combinations(edges, 2)
        if set(first).isdisjoint(second)
    }
    covered = {
        frozenset((first, second))
        for matching in matchings
        for first, second in combinations(sorted(matching), 2)
    }
    assert covered == independent
    return len(independent)


def oriented_short_gap(faces, site):
    face = faces[int(site["face_index"])]
    first_index, second_index = site["indices"]
    assert isinstance(first_index, int) and isinstance(second_index, int)
    u = face[first_index]
    v = face[(first_index + 1) % len(face)]
    x = face[second_index]
    y = face[(second_index + 1) % len(face)]
    second_arc = face[second_index + 1 :] + face[: first_index + 1]
    assert second_arc == (y, u)
    return face, (u, v, x, y), edge(y, u)


def direct_xvx_lift(matching, child, local, short_edge):
    _ua, _ab, bv, xc, _cd, _dy, ad, _bc = local
    image = frozenset(
        (matching - SITE) | frozenset((short_edge, ad, bv, xc))
    )
    assert is_perfect_matching(child, image)
    assert base.local_cell(image, local) == "Xvx"
    return image


def main():
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert graph.number_of_nodes() == 26
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    faces = reconstruct_faces(graph)
    matchings = tuple(sorted(base.enumerate_perfect_matchings(graph), key=matching_key))
    assert len(matchings) == 254

    sites = tuple(
        record
        for record in base.facial_sites(graph, faces, frozenset())
        if frozenset(record["selected"]) == SITE
    )
    assert len(sites) == 1
    site = sites[0]
    site_face, orientation, short_edge = oriented_short_gap(faces, site)
    assert short_edge == edge(3, 21)
    assert SHARED in base.face_edges(site_face)
    shared_faces = [face for face in faces if SHARED in base.face_edges(face)]
    assert sorted(map(len, shared_faces)) == [4, 6]
    adjacent_square = next(face for face in shared_faces if len(face) == 4)
    assert OPPOSITE in base.face_edges(adjacent_square)

    child, child_faces, local = base.expand_on_face(graph, faces, site)
    child_matchings = tuple(
        sorted(base.enumerate_perfect_matchings(child), key=matching_key)
    )
    assert child.number_of_nodes() == 30
    assert len(child_matchings) == 528
    assert nx.is_connected(child) and nx.is_bipartite(child)
    assert set(dict(child.degree()).values()) == {3}
    independent_pairs = verify_brace_by_two_extendability(child, child_matchings)

    records = []
    for root, forced, gate, size, sector_sizes, bond_count, endpoint_count in CANDIDATES:
        site_vertices = frozenset(vertex for item in SITE for vertex in item)
        assert not (frozenset(root) | frozenset(forced) | frozenset(gate)) & site_vertices
        assert base.legal_wide_arcs(faces, root, forced, gate) == (5, 5)
        assert base.legal_wide_arcs(child_faces, root, forced, gate) == (5, 5)

        fibre = tuple(
            matching
            for matching in matchings
            if base.is_root_target(graph, matching, root, forced)
        )
        sector0, sector1, bonds = bond_graph(fibre, gate)
        endpoints = frozenset(item for pair in bonds for item in pair)
        assert len(fibre) == size
        assert (len(sector0), len(sector1)) == sector_sizes
        assert len(bonds) == bond_count and len(endpoints) == endpoint_count
        assert all(SITE <= matching for matching in endpoints)
        assert all(local_type(matching) == "P" for matching in endpoints)

        images = {
            matching: direct_xvx_lift(matching, child, local, short_edge)
            for matching in endpoints
        }
        assert all(
            base.is_root_target(child, image, root, forced)
            for image in images.values()
        )
        assert all((gate in image) == (gate in matching) for matching, image in images.items())
        for first, second in bonds:
            first_image, second_image = images[first], images[second]
            assert first_image ^ second_image == first ^ second
            assert base.difference_component_count(first_image, second_image) == 1
            assert (gate in first_image) != (gate in second_image)

        records.append(
            {
                "root": list(root),
                "forced_gate": list(forced),
                "surviving_gate": list(gate),
                "fibre_size": len(fibre),
                "sector_sizes": [len(sector0), len(sector1)],
                "bond_count": len(bonds),
                "endpoint_count": len(endpoints),
                "endpoint_types": {"P": len(endpoints)},
                "transferred_cell": "Xvx",
                "transferred_bond_count": len(bonds),
            }
        )

    print(
        json.dumps(
            {
                "scope": "one fixed n=26 parent/site and four decorations",
                "graph6": GRAPH6,
                "site_face": list(site_face),
                "site": [list(item) for item in sorted(SITE)],
                "orientation_u_v_x_y": list(orientation),
                "one_edge_gap": list(short_edge),
                "parent_perfect_matchings": len(matchings),
                "child_perfect_matchings": len(child_matchings),
                "child_independent_edge_pairs": independent_pairs,
                "child_is_brace_by_two_extendability": True,
                "records": records,
            },
            indent=2,
            sort_keys=True,
        )
    )
    print("ONE_EDGE_GAP_PURE11_TRANSFER_VERIFIED")


if __name__ == "__main__":
    main()
