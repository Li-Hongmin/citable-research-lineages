# One-edge-gap pure-\(11\) transfer certificate

This bundle verifies the fixed order-\(26\) example used in Note 138.  It
does not search for graphs or vary the expansion site.  It reconstructs one
explicit graph from its graph6 string, enumerates its complete perfect-
matching family and that of the one fixed child, and checks four explicit
legal-wide decorations.

For every decoration the verifier checks that:

1. the complete parent rooted bond graph is nonempty and every bond has two
   state-\(11\) endpoints;
2. every nonisolated endpoint is local type \(P\), so the octagon-\(X\)
   endpoint-selection claim fails on an actual plane brace;
3. the expansion site has a one-edge residual facial gap;
4. the explicit \(X_{vx}\) lift is a root-admissible child target in the
   same gate sector; and
5. each transferred pair has symmetric difference literally equal to its
   parent bond cycle.

The child is independently checked to be a brace by complete
two-extendability over all \(900\) independent edge pairs.

Run from the AIMath project root:

~~~bash
uv run --python 3.12 --with 'networkx==3.6.1' python \
  units/barnette/computations/bundles/one-edge-gap-pure11-transfer/verify_fixed_n26_one_edge_gap.py
~~~

The final marker is

~~~text
ONE_EDGE_GAP_PURE11_TRANSFER_VERIFIED
~~~

The script imports only the already permanent general graph routines from
the rooted-split-bond-through26 bundle.  Its fixed graph, site, four
decorations, expected counts, and transfer identities are stated literally
in the verifier.
