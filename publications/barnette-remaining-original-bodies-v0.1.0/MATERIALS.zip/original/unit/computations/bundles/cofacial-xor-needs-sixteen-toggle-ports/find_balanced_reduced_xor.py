#!/usr/bin/env python3
"""Classify a rim-planar XOR superfamily and test regional balance."""

from argparse import ArgumentParser
from itertools import permutations, product

import networkx as nx

from search_reduced_xor_by_base_paths import (
    external_from_blocks,
    signature,
    smoothing,
)


class UnionFind:
    def __init__(self, size: int):
        self.parent = list(range(size))

    def find(self, item: int) -> int:
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, first: int, second: int) -> None:
        first, second = self.find(first), self.find(second)
        if first != second:
            self.parent[second] = first


def embedded_regions(first_length: int, second_length: int, external):
    port_count = first_length + second_length
    terminals = tuple(range(port_count, port_count + 4))
    graph = nx.Graph()
    graph.add_nodes_from(range(port_count + 4))
    first_cycle = smoothing(0, first_length, 0) + smoothing(0, first_length, 1)
    second_cycle = (
        smoothing(first_length, second_length, 0)
        + smoothing(first_length, second_length, 1)
    )
    graph.add_edges_from(first_cycle + second_cycle)
    external_paths = []
    for index, (left, right) in enumerate(external):
        subdivision = ("external", index)
        path = ((left, subdivision), (subdivision, right))
        graph.add_edges_from(path)
        external_paths.append(path)
    rim_paths = []
    for index in range(4):
        subdivision = ("rim", index)
        path = (
            (terminals[index], subdivision),
            (subdivision, terminals[(index + 1) % 4]),
        )
        graph.add_edges_from(path)
        rim_paths.append(path)
    planar, embedding = nx.check_planarity(graph)
    if not planar:
        return None

    dart_face = {}
    visited = set()
    faces = []
    for left, right in embedding.edges():
        if (left, right) in visited:
            continue
        face = embedding.traverse_face(left, right, visited)
        face_index = len(faces)
        faces.append(face)
        for index in range(len(face)):
            dart_face[(face[index], face[(index + 1) % len(face)])] = face_index
    union = UnionFind(len(faces))
    barriers = {
        frozenset(item)
        for item in first_cycle + second_cycle + sum(rim_paths, ())
    }
    for left, right in graph.edges():
        if frozenset((left, right)) in barriers:
            continue
        union.union(dart_face[(left, right)], dart_face[(right, left)])
    regions = []
    for path in external_paths:
        left, right = path[0]
        regions.append(union.find(dart_face[(left, right)]))
    core = nx.Graph()
    core.add_nodes_from(range(port_count + 4))
    core.add_edges_from(first_cycle + second_cycle + external)
    core.add_edges_from(
        (terminals[index], terminals[(index + 1) % 4]) for index in range(4)
    )
    rigid = (
        core.number_of_edges() == 3 * core.number_of_nodes() // 2
        and all(degree == 3 for _, degree in core.degree())
        and nx.node_connectivity(core) == 3
    )
    return tuple(regions), rigid


def balanced_colouring(first_length: int, second_length: int, external, regions):
    port_count = first_length + second_length
    terminals = tuple(range(port_count, port_count + 4))
    for second_offset in (0, 1):
        for terminal_colours in product((0, 1), repeat=4):
            colours = {index: index % 2 for index in range(first_length)}
            colours.update(
                {
                    first_length + index: second_offset ^ (index % 2)
                    for index in range(second_length)
                }
            )
            colours.update(dict(zip(terminals, terminal_colours)))
            residue = {}
            for edge_index, (left, right) in enumerate(external):
                region = regions[edge_index]
                counts = residue.setdefault(region, [0, 0])
                if left in terminals:
                    counts[colours[left]] += 1
                if right in terminals:
                    counts[colours[right]] += 1
                if colours[left] == colours[right]:
                    counts[1 - colours[left]] += 1
            if all(black == white for black, white in residue.values()):
                return second_offset, terminal_colours, residue
    return None


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("first", type=int)
    parser.add_argument("second", type=int)
    args = parser.parse_args()
    first_length, second_length = args.first, args.second
    port_count = first_length + second_length
    terminals = tuple(range(port_count, port_count + 4))
    identity = ((terminals[0], terminals[1]), (terminals[2], terminals[3]))
    elbow = ((terminals[0], terminals[3]), (terminals[1], terminals[2]))
    first = tuple(smoothing(0, first_length, state) for state in (0, 1))
    second = tuple(smoothing(first_length, second_length, state) for state in (0, 1))
    blocks = first[0] + second[0]
    block_count = len(blocks)
    xor_count = 0
    rim_planar_count = 0
    nonrigid_count = 0

    for permutation in permutations(range(block_count)):
        for mask in range(1 << block_count):
            oriented = tuple(
                blocks[index][::-1] if mask >> index & 1 else blocks[index]
                for index in permutation
            )
            for cut in range(block_count + 1):
                external = external_from_blocks(oriented, cut, terminals)
                if signature(
                    external, first[1], second[0], terminals, port_count + 4
                ) != (elbow, 0):
                    continue
                if signature(
                    external, first[0], second[1], terminals, port_count + 4
                ) != (elbow, 0):
                    continue
                if signature(
                    external, first[1], second[1], terminals, port_count + 4
                ) != (identity, 0):
                    continue
                xor_count += 1
                embedded = embedded_regions(first_length, second_length, external)
                if embedded is None:
                    continue
                rim_planar_count += 1
                regions, rigid = embedded
                if not rigid:
                    nonrigid_count += 1
                balance = balanced_colouring(
                    first_length, second_length, external, regions
                )
                if balance is None:
                    continue
                print("BALANCED_ORDERED_PLANE_XOR_FOUND")
                print("cycle lengths:", first_length, second_length)
                print("external:", external)
                print("regions:", regions)
                print("colouring:", balance)
                print("xor candidates seen:", xor_count)
                print("rim-planar candidates seen:", rim_planar_count)
                print("non-Whitney-rigid candidates seen:", nonrigid_count)
                return
    print(
        "NO_BALANCED_RIM_PLANAR_XOR",
        (first_length, second_length),
        "xor", xor_count,
        "rim_planar", rim_planar_count,
        "nonrigid", nonrigid_count,
    )


if __name__ == "__main__":
    main()
