#!/usr/bin/env python3
"""Generate one fixed port-size pair through its 00 path blocks.

This is a reduced-tangle search, not a graph-order census.  Every generated
external involution has 00 equal to the two prescribed terminal paths; only
the other three XOR states and ordered-boundary planarity are tested.
"""

from argparse import ArgumentParser
from itertools import permutations
from time import monotonic

import networkx as nx


def smoothing(offset: int, length: int, state: int) -> tuple[tuple[int, int], ...]:
    return tuple(
        (
            offset + (2 * index + state) % length,
            offset + (2 * index + 1 + state) % length,
        )
        for index in range(length // 2)
    )


def signature(
    external: tuple[tuple[int, int], ...],
    first: tuple[tuple[int, int], ...],
    second: tuple[tuple[int, int], ...],
    terminals: tuple[int, int, int, int],
    order: int,
) -> tuple[tuple[tuple[int, int], ...], int] | None:
    adjacency = [[] for _ in range(order)]
    for left, right in external + first + second:
        adjacency[left].append(right)
        adjacency[right].append(left)
    terminal_set = frozenset(terminals)
    visited = 0
    pairs = []
    closed = 0
    for root in range(order):
        if visited >> root & 1:
            continue
        visited |= 1 << root
        stack = [root]
        boundary = []
        while stack:
            vertex = stack.pop()
            if vertex in terminal_set:
                boundary.append(vertex)
            for neighbour in adjacency[vertex]:
                if not visited >> neighbour & 1:
                    visited |= 1 << neighbour
                    stack.append(neighbour)
        if len(boundary) == 2:
            pairs.append(tuple(sorted(boundary)))
        elif not boundary:
            closed += 1
        else:
            return None
    return tuple(sorted(pairs)), closed


def rim_planar(
    first_length: int,
    second_length: int,
    external: tuple[tuple[int, int], ...],
) -> bool:
    port_count = first_length + second_length
    terminals = tuple(range(port_count, port_count + 4))
    graph = nx.Graph()
    graph.add_nodes_from(range(port_count + 4))
    graph.add_edges_from(
        smoothing(0, first_length, 0)
        + smoothing(0, first_length, 1)
        + smoothing(first_length, second_length, 0)
        + smoothing(first_length, second_length, 1)
    )
    for index, (left, right) in enumerate(external):
        subdivision = ("external", index)
        graph.add_edge(left, subdivision)
        graph.add_edge(subdivision, right)
    for index in range(4):
        rim = ("rim", index)
        graph.add_edge(terminals[index], rim)
        graph.add_edge(rim, terminals[(index + 1) % 4])
    return nx.check_planarity(graph)[0]


# Compatibility for the exploratory constructor that used the older name.
# This test is only a necessary rim-planarity test, not a cofaciality test.
ordered_plane = rim_planar


def external_from_blocks(
    oriented: tuple[tuple[int, int], ...],
    cut: int,
    terminals: tuple[int, int, int, int],
) -> tuple[tuple[int, int], ...]:
    answer = []

    def append_path(left: int, right: int, blocks: tuple[tuple[int, int], ...]) -> None:
        if not blocks:
            answer.append((left, right))
            return
        answer.append((left, blocks[0][0]))
        answer.extend((before[1], after[0]) for before, after in zip(blocks, blocks[1:]))
        answer.append((blocks[-1][1], right))

    append_path(terminals[0], terminals[1], oriented[:cut])
    append_path(terminals[2], terminals[3], oriented[cut:])
    return tuple(answer)


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("first", type=int)
    parser.add_argument("second", type=int)
    parser.add_argument("--stop-first-plane", action="store_true")
    args = parser.parse_args()
    first_length, second_length = args.first, args.second
    assert first_length >= 4 and first_length % 2 == 0
    assert second_length >= 4 and second_length % 2 == 0

    port_count = first_length + second_length
    terminals = tuple(range(port_count, port_count + 4))
    identity = ((terminals[0], terminals[1]), (terminals[2], terminals[3]))
    elbow = ((terminals[0], terminals[3]), (terminals[1], terminals[2]))
    first = tuple(smoothing(0, first_length, state) for state in (0, 1))
    second = tuple(smoothing(first_length, second_length, state) for state in (0, 1))
    blocks = first[0] + second[0]
    block_count = len(blocks)
    xor_count = 0
    rim_planar_count = 0
    started = monotonic()

    for permutation in permutations(range(block_count)):
        for mask in range(1 << block_count):
            oriented = tuple(
                blocks[index][::-1] if mask >> index & 1 else blocks[index]
                for index in permutation
            )
            for cut in range(block_count + 1):
                external = external_from_blocks(oriented, cut, terminals)
                if signature(
                    external, first[1], second[0], terminals, port_count + 4
                ) != (elbow, 0):
                    continue
                if signature(
                    external, first[0], second[1], terminals, port_count + 4
                ) != (elbow, 0):
                    continue
                if signature(
                    external, first[1], second[1], terminals, port_count + 4
                ) != (identity, 0):
                    continue
                xor_count += 1
                if rim_planar(first_length, second_length, external):
                    rim_planar_count += 1
                    print("RIM_PLANAR_XOR", external, flush=True)
                    if args.stop_first_plane:
                        print("REDUCED_XOR_SEARCH_STOPPED_AT_FIRST_PLANE", flush=True)
                        return

    print(
        "REDUCED_XOR_SEARCH_COMPLETE",
        (first_length, second_length),
        "xor", xor_count,
        "rim_planar", rim_planar_count,
        "seconds", round(monotonic() - started, 3),
        flush=True,
    )


if __name__ == "__main__":
    main()
