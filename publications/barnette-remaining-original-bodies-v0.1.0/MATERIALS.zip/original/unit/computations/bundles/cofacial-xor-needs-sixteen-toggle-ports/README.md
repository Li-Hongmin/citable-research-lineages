# Cofacial XOR needs sixteen toggle ports

This bundle verifies Note 097.  It exhausts the complete block
representation of every reduced two-cycle XOR incidence with total toggle
ports twelve or fourteen, filters a rim-planar superfamily containing every
ordered-cofacial candidate, checks Whitney rigidity of the rim augmentation,
and tests the regional signed-colour balance for every relative cycle phase
and terminal colouring.

## Environment

- Python 3.12
- NetworkX 3.5 or a compatible 3.x release

The verifier is deterministic.  Its largest case has seven smoothing
blocks and enumerates \(7!2^7\cdot8\) descriptions without retaining them
in memory.

## Reproduction

From the AIMath project root run the following four commands.  They are
written explicitly so they work in both zsh and bash.

```bash
uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/cofacial-xor-needs-sixteen-toggle-ports/find_balanced_reduced_xor.py 4 8
uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/cofacial-xor-needs-sixteen-toggle-ports/find_balanced_reduced_xor.py 6 6
uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/cofacial-xor-needs-sixteen-toggle-ports/find_balanced_reduced_xor.py 4 10
uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/cofacial-xor-needs-sixteen-toggle-ports/find_balanced_reduced_xor.py 6 8
```

The final lines must be

```text
NO_BALANCED_RIM_PLANAR_XOR (4, 8) xor 3264 rim_planar 64 nonrigid 0
NO_BALANCED_RIM_PLANAR_XOR (6, 6) xor 1584 rim_planar 0 nonrigid 0
NO_BALANCED_RIM_PLANAR_XOR (4, 10) xor 40960 rim_planar 640 nonrigid 0
NO_BALANCED_RIM_PLANAR_XOR (6, 8) xor 28608 rim_planar 384 nonrigid 0
```

`search_reduced_xor_by_base_paths.py` supplies the complete block generator
and the direct four-state signature calculation.  The primary verifier
imports it from this directory.

## Scope

The enumeration is over reduced path incidences, not graphs of bounded
order.  Rim planarity is used only as a necessary test: adding the rim to a
genuinely ordered-cofacial embedding is always planar, but a rim-planar
graph may straddle the rim and fail true cofaciality.  Keeping that larger
family makes the exclusion stronger.  The regional residue is invariant
under adding two vertices to any external path, so the result covers
arbitrary compatible path lengths.  Zero regional residue is only a
necessary condition for a common matching; because no candidate passes it,
no matching-construction sufficiency is assumed.  The bundle does not test
sixteen-port incidences.
