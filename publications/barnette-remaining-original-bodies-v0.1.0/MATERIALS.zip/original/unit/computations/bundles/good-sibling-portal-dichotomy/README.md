# Good-sibling/portal dichotomy

This bundle supports
[Note 128](../../../notes/128-good-sibling-or-nonrooted-portal-covers-the-frozen-mixed-sector-family.md).
It reads only the permanent Note-110 through-order-(26) bundle, reconstructs
the (323) actual kill-cover splits, and independently enumerates all parent
and child perfect matchings.  No scratch JSON, endpoint table, new graph,
new site, or higher order is used.

## Reproduction

From the AIMath root, run in order:

```bash
python3 units/barnette/computations/bundles/good-sibling-portal-dichotomy/verify_frozen_good_sibling_portal_dichotomy.py
python3 units/barnette/computations/bundles/good-sibling-portal-dichotomy/verify_productive_incidence_identities.py
python3 units/barnette/computations/bundles/good-sibling-portal-dichotomy/verify_dichotomy_local_abstract_boundary.py
```

Tested with Python 3.14.6 on 2026-08-28.  The full actual-family
reconstruction took (4.07) seconds on the freezing machine; the other two
checks each took less than (0.1) seconds.  Terminal markers are

```text
FROZEN_GOOD_SIBLING_PORTAL_DICHOTOMY_COVERS_112
FROZEN_TWO_HUB_SHORT_COUPLING_COUNTEREXAMPLE_FOUND
FROZEN_TWO_HUB_LENGTH12_RELAXATION_STILL_FAILS
FROZEN_TWO_HUB_SHORT_COUPLING_AUDIT_OK
ONLY_TAUTOLOGICAL_PRODUCTIVE_INCIDENCE_PARITY_IDENTITY
FROZEN_PRODUCTIVE_INCIDENCE_IDENTITIES_CLASSIFIED
FROZEN_GP_COUNTS_AND_LOCAL_ABSTRACT_BOUNDARY_VERIFIED
```

The first command writes the complete (112)-endpoint raw table to
`frozen_good_sibling_portal_dichotomy.json`; the second writes the exact
incidence classification to `frozen_productive_incidence_identities.json`.

SHA-256 values:

```text
6caa7e26fb34bcbbfdcb48be463f89a12dc6a1fa6dbd54b7a5cb7ef8e024ae85  verify_frozen_good_sibling_portal_dichotomy.py
7e0d6153990e951990f8658d8431dcae4cf19930681e6d2758615e875cc3cded  frozen_good_sibling_portal_dichotomy.json
5ad41a8aa1ea11518d15f744d57bae2c45b5751cd01d679f08574fe2f688eb81  verify_productive_incidence_identities.py
81c7c7bd4602e511c2cc1961105b35453140a9d34c8424c23efc5ad7229fb1c6  frozen_productive_incidence_identities.json
7924f0ab50036dc25600f54890ac498755ba9c1b71117cbecbed97d73ed0e38d  verify_dichotomy_local_abstract_boundary.py
```

## Scope

The (112/112) dichotomy is a complete finite theorem on the frozen actual
family.  The cube construction is a strict abstract local countermodel, not
an actual connected brace.  The bundle does not prove the candidate for
arbitrary legal-wide splits.

