#!/usr/bin/env python3
"""Audit two-hub short coupling on the 112 frozen eligible endpoints."""

from __future__ import annotations

from collections import Counter
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
NOTE110_DIR = BARNETTE / "computations/bundles/rooted-split-bond-through26"
NOTE110_SCRIPT = NOTE110_DIR / "classify_through26_nonsquare_kill_cover.py"
NOTE110_JSON = NOTE110_DIR / "through26_nonsquare_kill_cover.json"
OUTPUT = HERE / "frozen_good_sibling_portal_dichotomy.json"


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(module)
    return module


note110 = load_module(NOTE110_SCRIPT, "good_sibling_portal_note110")
nx = note110.nx


def as_edge(value):
    return note110.edge(*value)


def path_edges(vertices):
    return frozenset(
        note110.edge(left, right)
        for left, right in zip(vertices, vertices[1:])
    )


def direct_lifts(parent_matching, face, site, local):
    """The three face-supported matching formulas of Note 106(6)."""
    first_index, second_index = map(int, site["indices"])
    first, second = map(as_edge, site["selected"])
    assert first in parent_matching and second in parent_matching
    first_arc = tuple(face[first_index + 1 : second_index + 1])
    second_arc = tuple(face[second_index + 1 :] + face[: first_index + 1])
    arc_a = path_edges(first_arc)
    arc_b = path_edges(second_arc)
    ua, ab, bv, xc, cd, dy, ad, bc = local
    common = parent_matching - {first, second}
    return {
        "Xuy": frozenset((common ^ arc_a) | {ua, bc, dy}),
        "Xvx": frozenset((common ^ arc_b) | {ad, bv, xc}),
        "R00": frozenset((common ^ arc_a ^ arc_b) | {ab, cd}),
    }


def reconstruct_primal(source_graph6, cache):
    if source_graph6 not in cache:
        graph = nx.from_graph6_bytes(source_graph6.encode())
        planar, embedding = nx.check_planarity(graph, counterexample=True)
        assert planar and isinstance(embedding, nx.PlanarEmbedding)
        faces = note110.source.plane_faces(graph, embedding)
        note110.validate_faces(graph, faces)
        assert note110.lift.verify_brace(graph)
        matchings = note110.enumerate_perfect_matchings(graph)
        cache[source_graph6] = (graph, faces, matchings)
    return cache[source_graph6]


def is_hamilton_complement(graph, matching):
    complement = graph.copy()
    complement.remove_edges_from(matching)
    assert set(dict(complement.degree()).values()) == {2}
    return nx.is_connected(complement)


def difference_component_lengths(first, second):
    difference = first ^ second
    if not difference:
        return ()
    graph = nx.Graph()
    graph.add_edges_from(difference)
    assert set(dict(graph.degree()).values()) == {2}
    return tuple(sorted(len(c) for c in nx.connected_components(graph)))


def serial_pair(pair, cells, selected):
    qp, qh, covered = pair
    difference = qp ^ qh
    return {
        "Qp": note110.serial_matching(qp),
        "Qh": note110.serial_matching(qh),
        "coupling_component_lengths": list(difference_component_lengths(qp, qh)),
        "coupling_site_edges": [list(e) for e in sorted(difference & selected)],
        "covered_target_ordinals": [i for i, _target in covered],
        "covered_target_cells": [cells[target] for _i, target in covered],
    }


def audit():
    frozen = json.loads(NOTE110_JSON.read_text())
    assert len(frozen["hits"]) == 323
    graph_cache, fibre_cache = {}, {}
    records, sterile_count = [], 0
    for hit_index, hit in enumerate(frozen["hits"]):
        graph, faces, parent_matchings = reconstruct_primal(
            hit["source_graph6"], graph_cache
        )
        root = as_edge(hit["root"])
        forced = as_edge(hit["forced_gate"])
        surviving = as_edge(hit["surviving_gate"])
        fibre_key = (hit["source_graph6"], root, forced)
        if fibre_key not in fibre_cache:
            fibre_cache[fibre_key] = tuple(
                m for m in parent_matchings
                if note110.is_root_target(graph, m, root, forced)
            )
        fibre = fibre_cache[fibre_key]
        fibre_set = frozenset(fibre)
        site = {
            "face_index": int(hit["site"]["face_index"]),
            "face_length": int(hit["site"]["face_length"]),
            "indices": tuple(map(int, hit["site"]["indices"])),
            "selected": tuple(map(as_edge, hit["site"]["selected"])),
        }
        selected = frozenset(site["selected"])
        child, _child_faces, local = note110.expand_on_face(graph, faces, site)
        child_matchings = note110.enumerate_perfect_matchings(child)
        child_fibre = tuple(
            m for m in child_matchings
            if note110.is_root_target(child, m, root, forced)
        )
        child_fibre_set = frozenset(child_fibre)
        cells = {m: note110.local_cell(m, local) for m in child_fibre}
        retained = frozenset(note110.edge(*e) for e in graph.edges) - selected
        face = faces[site["face_index"]]
        for chi_ordinal, chi in enumerate(m for m in fibre if selected <= m):
            direct = direct_lifts(chi, face, site, local)
            if any(m in child_fibre_set for m in direct.values()):
                continue
            sterile_count += 1
            sector = int(surviving in chi)
            mixed = tuple(
                m for m in fibre
                if (surviving in m) != bool(sector)
                and not selected <= m
                and note110.difference_component_count(chi, m) == 1
            )
            escape = tuple(
                m for m in fibre
                if (surviving in m) == bool(sector)
                and not selected <= m
                and note110.difference_component_count(chi, m) == 1
            )
            if not mixed or escape:
                continue
            targets = tuple(
                m for m in child_fibre
                if (surviving in m) == bool(sector)
                and cells[m] in {"R00", "Xuy", "Xvx"}
            )
            old_supports = tuple(m & retained for m in targets)
            labelled = frozenset({root, forced, surviving})
            same_label = tuple(
                m for m in parent_matchings
                if root in m and forced in m
                and (surviving in m) == bool(sector)
                and m not in fibre_set
            )
            phase_hubs = tuple(
                m for m in same_label
                if selected <= (m ^ chi)
                and not ((m ^ chi) & labelled)
                and not (selected & m)
                and note110.difference_component_count(chi, m) == 1
            )
            hamilton_hubs = tuple(m for m in same_label if is_hamilton_complement(graph, m))

            # Zero-extra-cost cross-check requested by the controller.
            good_incidences = tuple(
                (eta_index, target_index)
                for eta_index, eta in enumerate(mixed)
                for target_index, old in enumerate(old_supports)
                if old <= ((chi | eta) & retained)
            )
            portal_incidences = tuple(
                (portal_index, target_index)
                for portal_index, qp in enumerate(phase_hubs)
                for target_index, old in enumerate(old_supports)
                if old <= ((chi | qp) & retained)
            )
            good_sibling = bool(good_incidences)
            portal = bool(portal_incidences)
            endpoint_star_degree = sum(
                other != chi
                and note110.difference_component_count(chi, other) == 1
                for other in fibre
            )

            strict_pairs, relaxed_pairs = [], []
            strict_site, relaxed_site = Counter(), Counter()
            for qp in phase_hubs:
                for qh in hamilton_hubs:
                    difference = qp ^ qh
                    if difference & labelled:
                        continue
                    lengths = difference_component_lengths(qp, qh)
                    covered = tuple(
                        (i, target)
                        for i, (target, old) in enumerate(zip(targets, old_supports))
                        if old <= ((chi | qp | qh) & retained)
                    )
                    if not lengths or (len(lengths) == 1 and lengths[0] in {4, 6}):
                        strict_pairs.append((qp, qh, covered))
                        strict_site[tuple(sorted(difference & selected))] += 1
                    if sum(lengths) <= 12:
                        relaxed_pairs.append((qp, qh, covered))
                        relaxed_site[tuple(sorted(difference & selected))] += 1
            strict_accepting = tuple(pair for pair in strict_pairs if pair[2])
            relaxed_accepting = tuple(pair for pair in relaxed_pairs if pair[2])
            if not phase_hubs:
                first_failure = "A"
            elif not hamilton_hubs:
                first_failure = "B"
            elif not strict_pairs:
                first_failure = "C"
            elif not strict_accepting:
                first_failure = "D"
            else:
                first_failure = None
            records.append({
                "hit_index": hit_index,
                "parent_order": int(hit["parent_order"]),
                "source_graph6": hit["source_graph6"],
                "root": list(root), "forced_gate": list(forced),
                "surviving_gate": list(surviving),
                "site_selected": [list(e) for e in sorted(selected)],
                "sector": sector, "chi_ordinal_in_L11": chi_ordinal,
                "chi_matching": note110.serial_matching(chi),
                "target_count": len(targets),
                "target_cell_histogram": dict(Counter(cells[m] for m in targets)),
                "good_sibling_pass": good_sibling,
                "single_cycle_portal_pass": portal,
                "M": len(mixed),
                "endpoint_star_degree": endpoint_star_degree,
                "good_productive_incidences": len(good_incidences),
                "portal_productive_incidences": len(portal_incidences),
                "total_productive_incidences": (
                    len(good_incidences) + len(portal_incidences)
                ),
                "good_incidence_pairs": [list(pair) for pair in good_incidences],
                "portal_incidence_pairs": [list(pair) for pair in portal_incidences],
                "candidate_counts": {
                    "same_label_nonrooted": len(same_label),
                    "A_phase_hubs": len(phase_hubs),
                    "B_hamilton_hubs": len(hamilton_hubs),
                    "C_strict_pairs": len(strict_pairs),
                    "C_relaxed_pairs": len(relaxed_pairs),
                    "strict_accepting": len(strict_accepting),
                    "relaxed_accepting": len(relaxed_accepting),
                },
                "first_failure": first_failure,
                "strict_site_histogram": {
                    str(tuple(map(tuple, key))): value for key, value in sorted(strict_site.items())
                },
                "relaxed_site_histogram": {
                    str(tuple(map(tuple, key))): value for key, value in sorted(relaxed_site.items())
                },
                "first_strict_witness": (
                    serial_pair(strict_accepting[0], cells, selected) if strict_accepting else None
                ),
                "first_relaxed_witness": (
                    serial_pair(relaxed_accepting[0], cells, selected) if relaxed_accepting else None
                ),
            })
        if (hit_index + 1) % 50 == 0:
            print(f"note110_hits_processed={hit_index + 1}", flush=True)
    assert sterile_count == 172 and len(records) == 112
    return records


def summarize(records):
    strict = [r for r in records if r["candidate_counts"]["strict_accepting"]]
    relaxed = [r for r in records if r["candidate_counts"]["relaxed_accepting"]]
    sfail = [r for r in records if r not in strict]
    rfail = [r for r in records if r not in relaxed]
    good = {i for i, r in enumerate(records) if r["good_sibling_pass"]}
    portal = {i for i, r in enumerate(records) if r["single_cycle_portal_pass"]}
    return {
        "eligible_endpoints": 112,
        "strict_pass": len(strict), "strict_fail": len(sfail),
        "relaxed_pass": len(relaxed), "relaxed_fail": len(rfail),
        "first_strict_failure": sfail[0] if sfail else None,
        "first_relaxed_failure": rfail[0] if rfail else None,
        "first_failure_histogram": dict(Counter(r["first_failure"] or "pass" for r in records)),
        "good_sibling_pass": len(good),
        "single_cycle_portal_pass": len(portal),
        "good_sibling_intersection_portal": len(good & portal),
        "good_sibling_union_portal": len(good | portal),
        "portal_fail_all_good_sibling": (set(range(112)) - portal) <= good,
        "by_order": {
            str(order): {
                "eligible": sum(r["parent_order"] == order for r in records),
                "strict": sum(r["parent_order"] == order and r["candidate_counts"]["strict_accepting"] > 0 for r in records),
                "relaxed": sum(r["parent_order"] == order and r["candidate_counts"]["relaxed_accepting"] > 0 for r in records),
            }
            for order in sorted({r["parent_order"] for r in records})
        },
        "strict_first_witness_uses_site": sum(bool(r["first_strict_witness"]["coupling_site_edges"]) for r in strict),
        "relaxed_first_witness_uses_site": sum(bool(r["first_relaxed_witness"]["coupling_site_edges"]) for r in relaxed),
    }


def main():
    records = audit()
    summary = summarize(records)
    assert summary["good_sibling_pass"] == 18
    assert summary["single_cycle_portal_pass"] == 102
    assert summary["good_sibling_intersection_portal"] == 8
    assert summary["good_sibling_union_portal"] == 112
    assert summary["portal_fail_all_good_sibling"]
    OUTPUT.write_text(json.dumps({
        "scope": "112 frozen Note-110 eligible endpoints only",
        "strict_C": "empty or one C4/C6 component, label-disjoint",
        "relaxed_C": "components of total length at most 12, label-disjoint",
        "summary": summary, "records": records,
    }, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, indent=2, sort_keys=True))
    print("FROZEN_GOOD_SIBLING_PORTAL_DICHOTOMY_COVERS_112")
    print("FROZEN_TWO_HUB_SHORT_COUPLING_COUNTEREXAMPLE_FOUND" if summary["strict_fail"] else "FROZEN_TWO_HUB_SHORT_COUPLING_SURVIVES")
    print("FROZEN_TWO_HUB_LENGTH12_RELAXATION_STILL_FAILS" if summary["relaxed_fail"] else "FROZEN_TWO_HUB_LENGTH12_RELAXATION_REPAIRS_ALL")
    print("FROZEN_TWO_HUB_SHORT_COUPLING_AUDIT_OK")


if __name__ == "__main__":
    main()
