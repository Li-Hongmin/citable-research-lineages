#!/usr/bin/env python3
"""Verify the frozen G/P dichotomy and a strict local PM countermodel.

Part I reads only the two already-frozen JSON tables and joins their 112
endpoint records by a literal mathematical key.  Part II is independent of
the project data: it builds a small abstract parent/child pair from three
disjoint cubes, enumerates the complete perfect-matching families, and shows
that C4-patch matching equations plus one-alternating-cycle adjacency do not
formally imply G or P from a nonempty child X-family.

The abstract rooted/nonrooted predicate is declared explicitly rather than
derived from a Hamilton-complement topology.  This is intentional: it
pinpoints exactly the global information absent from the local axioms.
"""

from __future__ import annotations

from collections import deque
import json
from pathlib import Path


Edge = tuple[int, int]
Matching = frozenset[Edge]

HERE = Path(__file__).resolve().parent
INPUT = HERE / "frozen_good_sibling_portal_dichotomy.json"


def edge(left: int, right: int) -> Edge:
    return (left, right) if left < right else (right, left)


def nested_tuple(value):
    if isinstance(value, list):
        return tuple(nested_tuple(item) for item in value)
    return value


def endpoint_key(record: dict) -> tuple:
    """All literal fields determining one frozen decorated endpoint."""

    return (
        record["hit_index"],
        record["parent_order"],
        record["source_graph6"],
        nested_tuple(record["root"]),
        nested_tuple(record["forced_gate"]),
        nested_tuple(record["surviving_gate"]),
        nested_tuple(record["site_selected"]),
        record["sector"],
        record["chi_ordinal_in_L11"],
        nested_tuple(record["chi_matching"]),
    )


def verify_frozen_sets() -> dict[str, object]:
    payload = json.loads(INPUT.read_text())
    records = payload["records"]
    assert len(records) == 112
    by_key = {endpoint_key(record): record for record in records}
    assert len(by_key) == 112
    keys = frozenset(by_key)
    good = frozenset(
        key for key in keys if by_key[key]["good_sibling_pass"]
    )
    portal = frozenset(
        key for key in keys if by_key[key]["single_cycle_portal_pass"]
    )
    assert (len(good), len(portal), len(good & portal), len(good | portal)) == (
        18,
        102,
        8,
        112,
    )
    assert keys - portal <= good
    return {
        "endpoint_keys": len(keys),
        "G": len(good),
        "P": len(portal),
        "G_intersection_P": len(good & portal),
        "G_union_P": len(good | portal),
        "duplicate_keys": 0,
    }


def cube_edges(offset: int) -> frozenset[Edge]:
    return frozenset(
        edge(offset + vertex, offset + (vertex ^ bit))
        for vertex in range(8)
        for bit in (1, 2, 4)
        if vertex < (vertex ^ bit)
    )


def cube_faces(offset: int) -> tuple[tuple[int, ...], ...]:
    return tuple(
        tuple(offset + vertex for vertex in face)
        for face in (
            (0, 1, 3, 2),
            (4, 6, 7, 5),
            (0, 4, 5, 1),
            (2, 3, 7, 6),
            (0, 2, 6, 4),
            (1, 5, 7, 3),
        )
    )


def adjacency(vertices: tuple[int, ...], edges: frozenset[Edge]):
    graph = {vertex: set() for vertex in vertices}
    for left, right in edges:
        graph[left].add(right)
        graph[right].add(left)
    return graph


def components(vertices: tuple[int, ...], edges: frozenset[Edge]):
    graph = adjacency(vertices, edges)
    remaining = set(vertices)
    result = []
    while remaining:
        start = min(remaining)
        remaining.remove(start)
        component = {start}
        stack = [start]
        while stack:
            current = stack.pop()
            for other in sorted(graph[current] & remaining):
                remaining.remove(other)
                component.add(other)
                stack.append(other)
        result.append(frozenset(component))
    return tuple(result)


def validate_cubic_bipartite(vertices: tuple[int, ...], edges: frozenset[Edge]):
    graph = adjacency(vertices, edges)
    assert {len(graph[vertex]) for vertex in vertices} == {3}
    colour: dict[int, int] = {}
    for start in vertices:
        if start in colour:
            continue
        colour[start] = 0
        queue = deque([start])
        while queue:
            current = queue.popleft()
            for other in graph[current]:
                if other not in colour:
                    colour[other] = 1 - colour[current]
                    queue.append(other)
                else:
                    assert colour[other] != colour[current]
    return colour


def validate_cube_embedding(offset: int) -> None:
    vertices = tuple(range(offset, offset + 8))
    edges = cube_edges(offset)
    faces = cube_faces(offset)
    darts = [
        (face[index], face[(index + 1) % len(face)])
        for face in faces
        for index in range(len(face))
    ]
    expected = {
        dart
        for left, right in edges
        for dart in ((left, right), (right, left))
    }
    assert len(darts) == len(set(darts)) == 2 * len(edges)
    assert set(darts) == expected
    assert len(vertices) - len(edges) + len(faces) == 2


def enumerate_perfect_matchings(
    vertices: tuple[int, ...], edges: frozenset[Edge]
) -> tuple[Matching, ...]:
    graph = adjacency(vertices, edges)
    result: list[Matching] = []

    def recurse(unmatched: set[int], chosen: list[Edge]) -> None:
        if not unmatched:
            result.append(frozenset(chosen))
            return
        first = min(unmatched, key=lambda v: (len(graph[v] & unmatched), v))
        for second in sorted(graph[first] & unmatched):
            recurse(unmatched - {first, second}, chosen + [edge(first, second)])

    recurse(set(vertices), [])
    assert len(result) == len(set(result))
    return tuple(sorted(result, key=lambda matching: tuple(sorted(matching))))


def difference_component_count(first: Matching, second: Matching) -> int:
    difference = first ^ second
    if not difference:
        return 0
    vertices = tuple(sorted({vertex for item in difference for vertex in item}))
    graph = adjacency(vertices, difference)
    assert {len(graph[vertex]) for vertex in vertices} == {2}
    return len(components(vertices, difference))


def replace_dart(
    face: tuple[int, ...], left: int, right: int, inserted: tuple[int, ...]
) -> tuple[int, ...]:
    positions = [
        index
        for index in range(len(face))
        if face[index] == left and face[(index + 1) % len(face)] == right
    ]
    if not positions:
        return face
    assert len(positions) == 1
    index = positions[0]
    rotated = face[index:] + face[:index]
    return (left,) + inserted + (right,) + rotated[2:]


def expand_cube_site():
    """Expand opposite edges of the facial square (8,9,11,10)."""

    vertices = tuple(range(8, 16))
    edges = cube_edges(8)
    faces = cube_faces(8)
    face_index, first_index, second_index = 0, 0, 2
    face = faces[face_index]
    u, v = face[first_index], face[first_index + 1]
    x, y = face[second_index], face[(second_index + 1) % len(face)]
    selected = (edge(u, v), edge(x, y))
    assert selected == ((8, 9), (10, 11))
    a, b, c, d = 24, 25, 26, 27
    child_vertices = vertices + (a, b, c, d)
    child_edges = set(edges - set(selected))
    child_edges.update(
        {
            edge(u, a), edge(a, b), edge(b, v),
            edge(x, c), edge(c, d), edge(d, y),
            edge(a, d), edge(b, c),
        }
    )
    child_faces = []
    for index, old_face in enumerate(faces):
        if index == face_index:
            continue
        new_face = replace_dart(old_face, v, u, (b, a))
        new_face = replace_dart(new_face, y, x, (d, c))
        child_faces.append(new_face)
    child_faces.extend(
        (
            face[first_index + 1 : second_index + 1] + (c, b),
            face[second_index + 1 :] + face[: first_index + 1] + (a, d),
            (a, b, c, d),
        )
    )
    local = (
        edge(u, a), edge(a, b), edge(b, v),
        edge(x, c), edge(c, d), edge(d, y),
        edge(a, d), edge(b, c),
    )
    return child_vertices, frozenset(child_edges), tuple(child_faces), local


def local_cell(matching: Matching, local: tuple[Edge, ...]) -> str:
    ua, ab, bv, xc, cd, dy, ad, bc = local
    patterns = {
        frozenset((ad, bc)): "C00",
        frozenset((ua, bv, cd)): "C10",
        frozenset((xc, dy, ab)): "C01",
        frozenset((ua, bv, xc, dy)): "C11",
        frozenset((ab, cd)): "R00",
        frozenset((ua, bc, dy)): "Xuy",
        frozenset((ad, bv, xc)): "Xvx",
    }
    patch = matching & frozenset(local)
    assert patch in patterns
    return patterns[patch]


def verify_abstract_local_countermodel() -> dict[str, object]:
    """A full common-PM incidence model with X nonempty but G=P=false."""

    for offset in (0, 8, 16):
        validate_cube_embedding(offset)

    parent_vertices = tuple(range(24))
    parent_edges = cube_edges(0) | cube_edges(8) | cube_edges(16)
    validate_cubic_bipartite(parent_vertices, parent_edges)
    assert len(components(parent_vertices, parent_edges)) == 3

    root = (0, 1)
    forced = (2, 3)
    p, q = (8, 9), (10, 11)
    surviving = (12, 13)
    selected = frozenset({p, q})
    labels = frozenset({root, forced, surviving})
    chi = frozenset(
        {
            (0, 1), (2, 3), (4, 5), (6, 7),
            (8, 9), (10, 11), (12, 13), (14, 15),
            (16, 17), (18, 19), (20, 21), (22, 23),
        }
    )

    parent_matchings = enumerate_perfect_matchings(parent_vertices, parent_edges)
    assert len(parent_matchings) == 9 ** 3 == 729
    assert chi in parent_matchings

    site_child_vertices, site_child_edges, site_child_faces, local = expand_cube_site()
    validate_cubic_bipartite(site_child_vertices, site_child_edges)
    # The expanded site component is still a plane cubic bipartite graph.
    darts = [
        (face[index], face[(index + 1) % len(face)])
        for face in site_child_faces
        for index in range(len(face))
    ]
    expected_darts = {
        dart
        for left, right in site_child_edges
        for dart in ((left, right), (right, left))
    }
    assert len(darts) == len(set(darts)) == 2 * len(site_child_edges)
    assert set(darts) == expected_darts
    assert len(site_child_vertices) - len(site_child_edges) + len(site_child_faces) == 2

    child_vertices = tuple(range(24)) + (24, 25, 26, 27)
    child_edges = cube_edges(0) | cube_edges(16) | site_child_edges
    validate_cubic_bipartite(child_vertices, child_edges)
    assert len(components(child_vertices, child_edges)) == 3
    child_matchings = enumerate_perfect_matchings(child_vertices, child_edges)

    # Same-sector R00 target: site square flipped and one independent remote
    # square flipped.  The remote flip supplies a two-edge support defect that
    # no one-cycle site/sector neighbour can see.
    target = frozenset(
        {
            (0, 1), (2, 3), (4, 5), (6, 7),
            (8, 10), (9, 11), (12, 13), (14, 15),
            (16, 18), (17, 19), (20, 21), (22, 23),
            (24, 25), (26, 27),
        }
    )
    assert target in child_matchings
    assert local_cell(target, local) == "R00"
    assert surviving in target

    # The abstract rooted predicate preserves every local PM fact but carries
    # no Hamilton-complement axiom.  Chi and every opposite-sector, one-cycle,
    # non-11 neighbour are declared rooted; same-sector non-11 neighbours are
    # nonrooted.  The child rooted X-family is {target}.
    def same_fixed_labels(matching: Matching) -> bool:
        return root in matching and forced in matching

    def sector(matching: Matching) -> int:
        return int(surviving in matching)

    def state11(matching: Matching) -> bool:
        return selected <= matching

    def parent_rooted(matching: Matching) -> bool:
        return matching == chi or (
            same_fixed_labels(matching)
            and sector(matching) != sector(chi)
            and not state11(matching)
            and difference_component_count(chi, matching) == 1
        )

    mixed = tuple(
        matching
        for matching in parent_matchings
        if parent_rooted(matching)
        and sector(matching) != sector(chi)
        and not state11(matching)
        and difference_component_count(chi, matching) == 1
    )
    same_sector_rooted_escapes = tuple(
        matching
        for matching in parent_matchings
        if parent_rooted(matching)
        and sector(matching) == sector(chi)
        and not state11(matching)
        and difference_component_count(chi, matching) == 1
    )
    assert mixed and not same_sector_rooted_escapes

    retained = parent_edges - selected
    target_old = target & retained
    good = tuple(
        matching
        for matching in mixed
        if target_old <= ((chi | matching) & retained)
    )

    phase = tuple(
        matching
        for matching in parent_matchings
        if same_fixed_labels(matching)
        and sector(matching) == sector(chi)
        and not parent_rooted(matching)
        and difference_component_count(chi, matching) == 1
        and not ((chi ^ matching) & labels)
        and selected <= (chi ^ matching)
        and not (selected & matching)
    )
    portal = tuple(
        matching
        for matching in phase
        if target_old <= ((chi | matching) & retained)
    )
    assert phase
    assert not good and not portal

    remote_defect = frozenset({(16, 18), (17, 19)})
    assert remote_defect <= target_old
    assert all(remote_defect.isdisjoint(chi | matching) for matching in mixed)
    assert all(remote_defect.isdisjoint(chi | matching) for matching in phase)

    return {
        "parent": {
            "order": len(parent_vertices),
            "edges": len(parent_edges),
            "components": 3,
            "perfect_matchings": len(parent_matchings),
            "cubic_bipartite": True,
            "componentwise_plane": True,
        },
        "child": {
            "order": len(child_vertices),
            "edges": len(child_edges),
            "components": 3,
            "perfect_matchings": len(child_matchings),
            "cubic_bipartite": True,
            "componentwise_plane": True,
        },
        "patch": "cofacial opposite-edge C4 expansion",
        "profile_M_E_X": (len(mixed), len(same_sector_rooted_escapes), 1),
        "phase_candidates": len(phase),
        "G": len(good),
        "P": len(portal),
        "remote_defect": tuple(sorted(remote_defect)),
        "formal_local_implication": False,
    }


def main() -> None:
    frozen = verify_frozen_sets()
    abstract = verify_abstract_local_countermodel()
    print("frozen_sets", frozen)
    print("abstract_local_countermodel", abstract)
    print("FROZEN_GP_COUNTS_AND_LOCAL_ABSTRACT_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
