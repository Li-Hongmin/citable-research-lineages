#!/usr/bin/env python3
"""Freeze a direct bipartite cubic lift of the C4+C8 XOR tangle.

The verifier is pure standard library.  Besides the literal graph and four
perfect matchings, it checks a planar rotation system and the sharp
four-subdivision lower bound inside the direct path-subdivision/common-
matching lift model.
"""

from collections import defaultdict, deque
from itertools import product


def edge(left: str, right: str) -> frozenset[str]:
    assert left != right
    return frozenset((left, right))


def cycle_edges(vertices: tuple[str, ...]) -> frozenset[frozenset[str]]:
    return frozenset(
        edge(vertices[index], vertices[(index + 1) % len(vertices)])
        for index in range(len(vertices))
    )


A = tuple(f"a{i}" for i in range(4))
B = tuple(f"b{i}" for i in range(8))
T = tuple(f"t{i}" for i in range(4))
SUBDIVISIONS = ("r1", "r3", "s1", "s3")
VERTICES = frozenset(A + B + T + SUBDIVISIONS)

# The radial paths a_i--b_{2i} have subdivision pattern (0,1,0,1).
# The terminal paths b_{2i+1}--t_i have the same pattern.
EXTERNAL_PATHS = (
    ("a0", "b0"),
    ("a1", "r1", "b2"),
    ("a2", "b4"),
    ("a3", "r3", "b6"),
    ("b1", "t0"),
    ("b3", "s1", "t1"),
    ("b5", "t2"),
    ("b7", "s3", "t3"),
)

# This matching cubicizes every internal path vertex and raises each terminal
# from degree one in the reduced tangle to degree two in the actual graph.
K = frozenset(
    edge(*item)
    for item in (
        ("t0", "r1"),
        ("t1", "s3"),
        ("t2", "r3"),
        ("t3", "s1"),
    )
)

EDGES = set(cycle_edges(A) | cycle_edges(B) | K)
for path in EXTERNAL_PATHS:
    EDGES.update(edge(path[index], path[index + 1]) for index in range(len(path) - 1))
EDGES = frozenset(EDGES)


def adjacency(edges: frozenset[frozenset[str]]) -> dict[str, set[str]]:
    result = {vertex: set() for vertex in VERTICES}
    for item in edges:
        left, right = tuple(item)
        result[left].add(right)
        result[right].add(left)
    return result


ADJ = adjacency(EDGES)
assert len(VERTICES) == 20 and len(EDGES) == 28
assert all(len(item) == 2 for item in EDGES)
assert all(len(ADJ[terminal]) == 2 for terminal in T)
assert all(len(ADJ[vertex]) == 3 for vertex in VERTICES - set(T))

# Connectedness.
seen = {"a0"}
queue = deque(("a0",))
while queue:
    vertex = queue.popleft()
    for neighbour in ADJ[vertex] - seen:
        seen.add(neighbour)
        queue.append(neighbour)
assert seen == VERTICES

# A literal bipartition.
BLACK = frozenset(("a1", "a3", "b0", "b2", "b4", "b6", "t0", "t2", "s1", "s3"))
WHITE = VERTICES - BLACK
assert len(BLACK) == len(WHITE) == 10
assert all(len(item & BLACK) == len(item & WHITE) == 1 for item in EDGES)

# A planar rotation system.  Traversing every directed edge on its left gives
# ten faces, so V-E+F=2 and this is a sphere embedding.
ROTATION = {
    "a0": ("a1", "b0", "a3"),
    "a1": ("a0", "a2", "r1"),
    "a2": ("a1", "a3", "b4"),
    "a3": ("a2", "a0", "r3"),
    "b0": ("b1", "b7", "a0"),
    "b1": ("b2", "b0", "t0"),
    "b2": ("b3", "b1", "r1"),
    "b3": ("b4", "s1", "b2"),
    "b4": ("b5", "b3", "a2"),
    "b5": ("b6", "b4", "t2"),
    "b6": ("r3", "b7", "b5"),
    "b7": ("b0", "s3", "b6"),
    "t0": ("b1", "r1"),
    "t1": ("s3", "s1"),
    "t2": ("b5", "r3"),
    "t3": ("s1", "s3"),
    "r1": ("t0", "a1", "b2"),
    "r3": ("a3", "b6", "t2"),
    "s1": ("t1", "b3", "t3"),
    "s3": ("b7", "t1", "t3"),
}
assert set(ROTATION) == VERTICES
assert all(set(ROTATION[vertex]) == ADJ[vertex] for vertex in VERTICES)

directed_seen: set[tuple[str, str]] = set()
faces: list[tuple[str, ...]] = []
for left in sorted(VERTICES):
    for right in ROTATION[left]:
        if (left, right) in directed_seen:
            continue
        face: list[str] = []
        current = (left, right)
        while current not in directed_seen:
            directed_seen.add(current)
            previous, vertex = current
            face.append(previous)
            neighbours = ROTATION[vertex]
            index = neighbours.index(previous)
            current = vertex, neighbours[(index - 1) % len(neighbours)]
        assert current == (left, right)
        faces.append(tuple(face))
assert len(directed_seen) == 2 * len(EDGES)
assert len(faces) == 10
assert len(VERTICES) - len(EDGES) + len(faces) == 2
assert max(len(set(face) & set(T)) for face in faces) == 2

# The terminals are not cofacial in any plane embedding.  If they were,
# adding one apex z adjacent to all four could be done inside their common
# face.  The augmented graph instead contains the following explicit
# K_{3,3} subdivision, with branch classes
# {s3,z,s1} and {a3,t1,t3}.
APEX = "z"
K33_PATHS = (
    ("s3", "b7", "b0", "a0", "a3"),
    ("s3", "t1"),
    ("s3", "t3"),
    ("z", "t2", "r3", "a3"),
    ("z", "t1"),
    ("z", "t3"),
    ("s1", "b3", "b2", "r1", "a1", "a2", "a3"),
    ("s1", "t1"),
    ("s1", "t3"),
)
AUGMENTED_EDGES = EDGES | frozenset(edge(APEX, terminal) for terminal in T)
assert all(
    edge(path[index], path[index + 1]) in AUGMENTED_EDGES
    for path in K33_PATHS
    for index in range(len(path) - 1)
)
assert {
    frozenset((path[0], path[-1])) for path in K33_PATHS
} == {
    frozenset((left, right))
    for left in ("s3", "z", "s1")
    for right in ("a3", "t1", "t3")
}
internal_sets = [set(path[1:-1]) for path in K33_PATHS]
assert all(
    internal_sets[i].isdisjoint(internal_sets[j])
    for i in range(len(internal_sets))
    for j in range(i)
)
assert all(
    internal.isdisjoint({"s3", "z", "s1", "a3", "t1", "t3"})
    for internal in internal_sets
)


def smoothing(vertices: tuple[str, ...], state: int) -> frozenset[frozenset[str]]:
    return frozenset(
        edge(
            vertices[(2 * index + state) % len(vertices)],
            vertices[(2 * index + 1 + state) % len(vertices)],
        )
        for index in range(len(vertices) // 2)
    )


def matching(first_state: int, second_state: int) -> frozenset[frozenset[str]]:
    # The complement uses the requested smoothing, so the matching uses the
    # opposite one on each toggle cycle.
    return K | smoothing(A, 1 - first_state) | smoothing(B, 1 - second_state)


MATCHINGS = {(i, j): matching(i, j) for i, j in product((0, 1), repeat=2)}
for item in MATCHINGS.values():
    covered = defaultdict(int)
    for matching_edge in item:
        assert matching_edge in EDGES
        for vertex in matching_edge:
            covered[vertex] += 1
    assert set(covered) == VERTICES
    assert all(multiplicity == 1 for multiplicity in covered.values())


def components(edges: frozenset[frozenset[str]]) -> tuple[frozenset[str], ...]:
    graph = adjacency(edges)
    unseen = set(VERTICES)
    answer = []
    while unseen:
        root = min(unseen)
        component = {root}
        queue = deque((root,))
        while queue:
            vertex = queue.popleft()
            for neighbour in graph[vertex] - component:
                component.add(neighbour)
                queue.append(neighbour)
        unseen -= component
        answer.append(frozenset(component))
    return tuple(answer)


I = frozenset((frozenset(("t0", "t1")), frozenset(("t2", "t3"))))
E = frozenset((frozenset(("t0", "t3")), frozenset(("t1", "t2"))))
EXPECTED = {(0, 0): I, (1, 0): E, (0, 1): E, (1, 1): I}

for state, item in MATCHINGS.items():
    complement = EDGES - item
    comp = components(complement)
    assert len(comp) == 2
    assert frozenset().union(*comp) == VERTICES
    endpoint_pairs = set()
    for vertex_set in comp:
        induced_edges = frozenset(edge_item for edge_item in complement if edge_item <= vertex_set)
        degrees = {
            vertex: sum(vertex in edge_item for edge_item in induced_edges)
            for vertex in vertex_set
        }
        endpoints = frozenset(vertex for vertex, degree in degrees.items() if degree == 1)
        assert endpoints <= set(T) and len(endpoints) == 2
        assert all(degree in (1, 2) for degree in degrees.values())
        assert len(induced_edges) == len(vertex_set) - 1
        endpoint_pairs.add(endpoints)
    assert frozenset(endpoint_pairs) == EXPECTED[state]

# The four matchings form the intended two-coordinate cube, and the diagonal
# consists of exactly the two alternating components C4 and C8.
C4 = cycle_edges(A)
C8 = cycle_edges(B)
P00 = MATCHINGS[(0, 0)]
P10 = MATCHINGS[(1, 0)]
P01 = MATCHINGS[(0, 1)]
P11 = MATCHINGS[(1, 1)]
assert P00 ^ P10 == C4
assert P00 ^ P01 == C8
assert P00 ^ P11 == C4 | C8
assert P11 == P00 ^ C4 ^ C8
assert C4.isdisjoint(C8)

# Sharp size in the direct lift model.  Fix a0 colour 0 and let beta be the
# colour of every even b-vertex.  A path has odd length exactly when its
# endpoints have opposite colours.  For a chosen parity, the shortest path
# has zero internal vertices if odd and one if even; adding two more internal
# vertices changes neither colour balance nor the lower bound.  The vertices
# needing the common matching K are all path interiors plus the four
# terminals.  K requires equal black/white counts.
direct_lift_sizes = []
for beta in (0, 1):
    radial_counts = [0, 0]
    radial_subdivisions = 0
    for index in range(4):
        colour_a = index % 2
        colour_b = beta
        length_parity = colour_a ^ colour_b
        if length_parity == 0:
            radial_counts[1 - colour_a] += 1
            radial_subdivisions += 1
    for spoke_parities in product((0, 1), repeat=4):
        counts = radial_counts.copy()
        subdivisions = radial_subdivisions
        colour_b_odd = beta ^ 1
        for length_parity in spoke_parities:
            terminal_colour = colour_b_odd ^ length_parity
            counts[terminal_colour] += 1
            if length_parity == 0:
                counts[1 - colour_b_odd] += 1
                subdivisions += 1
        if counts[0] == counts[1]:
            direct_lift_sizes.append(subdivisions)
assert min(direct_lift_sizes) == 4
assert len(VERTICES) == 12 + 4 + min(direct_lift_sizes)

print("graph: 20 vertices, 28 edges, simple connected plane bipartite")
print("degrees: four terminals of degree 2; all other vertices degree 3")
print("complement pairings: 00=I, 10=E, 01=E, 11=I; closed=0")
print("P00 xor P11: C4 dot-union C8")
print("direct path/common-matching lift minimum: four subdivisions, order 20")
print("scope: the four terminals are not cofacial in any plane embedding")
print("XOR_BIPARTITE_LIFT_VERIFIED")
