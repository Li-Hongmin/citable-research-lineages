# Cofacial boundary of the \(C_4+C_8\) XOR lift

This bundle verifies Note 095 with pure standard-library scripts.

Run from the AIMath root:

```text
python3 units/barnette/computations/bundles/cofacial-boundary-of-the-c4-c8-xor-lift/verify_xor_bipartite_lift.py
python3 units/barnette/computations/bundles/cofacial-boundary-of-the-c4-c8-xor-lift/verify_annular_colour_imbalance.py
```

The expected final markers are

```text
XOR_BIPARTITE_LIFT_VERIFIED
ANNULAR_BIPARTITE_IMBALANCE_VERIFIED
```

The first script checks the explicit 20-vertex graph, its bipartition and
plane rotation, all four perfect matchings and complement path pairings,
the diagonal \(C_4\dot\cup C_8\), the four-subdivision lower bound in the
direct lift model, and an explicit \(K_{3,3}\)-subdivision after adding an
apex adjacent to the four terminals.  The latter certifies that the
terminals are not cofacial in any plane embedding.

The second script checks the signed colour contribution of all four radial
paths for both relative cycle-colour phases.  It is a symbolic endpoint
calculation, not a graph-order search.
