#!/usr/bin/env python3
"""Verify the endpoint-colour imbalance in the Note 094 annulus.

This enumerates only the two relative colour phases of the nested cycles.
It does not enumerate graphs or path lengths: a path contributes zero
imbalance when its endpoints differ and one unit toward the opposite colour
when its endpoints agree.
"""


def internal_imbalance(left: int, right: int, beta: int) -> int:
    """Return #internal(1-beta) - #internal(beta) for any such path."""
    if left != right:
        return 0
    assert left == beta
    return 1


for alpha in (0, 1):
    for beta in (0, 1):
        a_colours = [(alpha + i) % 2 for i in range(4)]
        b_even_colours = [beta] * 4
        contributions = [
            internal_imbalance(a_colours[i], b_even_colours[i], beta)
            for i in range(4)
        ]
        assert sorted(contributions) == [0, 0, 1, 1]
        assert sum(contributions) == 2

print("ANNULAR_BIPARTITE_IMBALANCE_VERIFIED")
