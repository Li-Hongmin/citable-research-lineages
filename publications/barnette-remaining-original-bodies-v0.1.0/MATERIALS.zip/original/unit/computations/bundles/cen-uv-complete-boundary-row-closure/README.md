# CEN/UV complete boundary-row closure

This bundle verifies the purely local finite table used in Note 132.  Start
with the standard \(C_4\)-expansion patch

\[
\{ua,ab,bv,xc,cd,dy,ad,bc\}.
\]

For each of the two deterministically named successor sites

\[
\mathrm{CEN}=(bc,da),\qquad \mathrm{UV}=(ua,bv),
\]

the verifier first deletes the two successor-site edges.  It then enumerates
every local partial matching for each of the six next defect classes

\[
\varnothing,\ uv,\ xy,\ uvxy,\ uy,\ vx
\]

and records the old exterior defect forced by that pattern.

There are exactly \(11\) CEN patterns and \(12\) UV patterns.  Every old
defect remains in the same six-class alphabet.  To test pair transport
independently of any graph realization, the verifier enumerates all \(208\)
marked partitions of the four old boundary stubs, including saturated
closed-component counts.  Across both sites it compares \(55{,}120\)
partition joins with direct symmetric-difference gluing and recutting.
Every comparison agrees and no pair-state collision occurs.

Run from the AIMath root:

~~~bash
uv run --python 3.12 \
  python units/barnette/computations/bundles/cen-uv-complete-boundary-row-closure/verify_cen_uv_next_boundary_closure.py
~~~

The terminal status is:

~~~text
PURE_LOCAL_CEN_UV_NEXT_BOUNDARY_PAIR_CLOSURE
~~~

Frozen SHA256 values:

~~~text
verifier  8217f94911eb5200137e72c2d7fee0bc188d12e9a779de5595ad34cc79b7747d
output    e011d0f7bf45dd1882e9df79076a08ad1d2a2419714d934bee56ae40923d32f3
~~~

This is a local finite verification of the production table and pairwise
partition composition.  It does not enumerate a parent graph, prove
realizability of an abstract support, or prove rooted split-bond
supplementation.
