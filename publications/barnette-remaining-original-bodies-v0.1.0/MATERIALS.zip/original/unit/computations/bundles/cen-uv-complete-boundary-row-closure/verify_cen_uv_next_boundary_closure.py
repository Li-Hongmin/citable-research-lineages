#!/usr/bin/env python3
"""Exhaust the purely local CEN/UV next-boundary transition.

The selected next-site edges are deleted before generalized patch rows are
enumerated.  No parent graph, decoration, random sample, or higher expansion
depth is touched.
"""

from __future__ import annotations

from collections import defaultdict
from itertools import combinations, product
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "cen_uv_next_boundary_closure.json"

VERTICES = ("u", "v", "x", "y", "a", "b", "c", "d")
OLD_BOUNDARY = ("u", "v", "x", "y")
NEW_VERTICES = frozenset(("a", "b", "c", "d"))
PATCH_EDGES = (
    ("u", "a"),
    ("a", "b"),
    ("b", "v"),
    ("x", "c"),
    ("c", "d"),
    ("d", "y"),
    ("a", "d"),
    ("b", "c"),
)

SITES = {
    "CEN": {
        "edges": frozenset((("b", "c"), ("a", "d"))),
        "boundary": ("b", "c", "d", "a"),
    },
    "UV": {
        "edges": frozenset((("u", "a"), ("b", "v"))),
        "boundary": ("u", "a", "b", "v"),
    },
}

CLASS_POSITIONS = {
    "empty": (),
    "uv": (0, 1),
    "xy": (2, 3),
    "uvxy": (0, 1, 2, 3),
    "uy": (0, 3),
    "vx": (1, 2),
}
OLD_CLASS_BY_SET = {
    frozenset(OLD_BOUNDARY[index] for index in positions): name
    for name, positions in CLASS_POSITIONS.items()
}

EXPECTED_ROWS = {
    "CEN": {
        ("empty", "empty", ("ab", "cd")),
        ("empty", "uv", ("cd", "ua", "vb")),
        ("empty", "xy", ("ab", "xc", "yd")),
        ("empty", "uvxy", ("ua", "vb", "xc", "yd")),
        ("uv", "uy", ("ua", "yd")),
        ("xy", "vx", ("vb", "xc")),
        ("uvxy", "empty", ()),
        ("uy", "empty", ("cd",)),
        ("uy", "xy", ("xc", "yd")),
        ("vx", "empty", ("ab",)),
        ("vx", "uv", ("ua", "vb")),
    },
    "UV": {
        ("empty", "empty", ("ab", "cd")),
        ("empty", "empty", ("ad", "bc")),
        ("empty", "xy", ("ab", "xc", "yd")),
        ("uv", "uy", ("bc", "yd")),
        ("xy", "vx", ("ad", "xc")),
        ("uvxy", "uv", ("cd",)),
        ("uvxy", "uvxy", ("xc", "yd")),
        ("uy", "uv", ("ab", "cd")),
        ("uy", "uv", ("ad", "bc")),
        ("uy", "uvxy", ("ab", "xc", "yd")),
        ("vx", "empty", ("cd",)),
        ("vx", "xy", ("xc", "yd")),
    },
}


def normalized_edge(left: str, right: str) -> tuple[str, str]:
    return tuple(sorted((left, right)))


PATCH_EDGES = tuple(normalized_edge(*item) for item in PATCH_EDGES)
for site in SITES.values():
    site["edges"] = frozenset(normalized_edge(*item) for item in site["edges"])


def edge_name(item: tuple[str, str]) -> str:
    order = {vertex: index for index, vertex in enumerate(VERTICES)}
    return "".join(sorted(item, key=order.__getitem__))


def pattern_name(next_class: str, edges: frozenset[tuple[str, str]]) -> str:
    suffix = "0" if not edges else "_".join(sorted(map(edge_name, edges)))
    return f"{next_class}:{suffix}"


def defect_set(boundary: tuple[str, ...], class_name: str) -> frozenset[str]:
    return frozenset(boundary[index] for index in CLASS_POSITIONS[class_name])


def enumerate_patterns(site_name: str) -> list[dict]:
    site = SITES[site_name]
    boundary = site["boundary"]
    available = tuple(edge for edge in PATCH_EDGES if edge not in site["edges"])
    rows = []
    for next_class in CLASS_POSITIONS:
        next_defect = defect_set(boundary, next_class)
        for edge_bits in product((0, 1), repeat=len(available)):
            edges = frozenset(
                edge for edge, present in zip(available, edge_bits, strict=True)
                if present
            )
            degree = {vertex: 0 for vertex in VERTICES}
            for left, right in edges:
                degree[left] += 1
                degree[right] += 1
            if any(value > 1 for value in degree.values()):
                continue
            if any(
                degree[vertex] != int(vertex not in next_defect)
                for vertex in NEW_VERTICES
            ):
                continue
            if any(degree[vertex] for vertex in next_defect & set(OLD_BOUNDARY)):
                continue

            old_defect = frozenset(
                vertex
                for vertex in OLD_BOUNDARY
                if degree[vertex] == 1 or vertex in next_defect
            )
            if old_defect not in OLD_CLASS_BY_SET:
                raise AssertionError(
                    f"{site_name} escaped six old classes: {sorted(old_defect)}"
                )
            rows.append(
                {
                    "name": pattern_name(next_class, edges),
                    "next_class": next_class,
                    "next_defect": tuple(sorted(next_defect)),
                    "old_class": OLD_CLASS_BY_SET[old_defect],
                    "old_defect": tuple(sorted(old_defect)),
                    "edges": tuple(sorted(map(edge_name, edges))),
                    "edge_set": edges,
                }
            )
    rows.sort(key=lambda row: (tuple(CLASS_POSITIONS).index(row["next_class"]), row["name"]))
    return rows


class UnionFind:
    def __init__(self):
        self.parent: dict[object, object] = {}
        self.active: dict[object, bool] = {}

    def add(self, item: object, active: bool = False) -> None:
        if item not in self.parent:
            self.parent[item] = item
            self.active[item] = active

    def find(self, item: object) -> object:
        root = item
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[item] != item:
            parent = self.parent[item]
            self.parent[item] = root
            item = parent
        return root

    def union(self, first: object, second: object) -> None:
        self.add(first)
        self.add(second)
        left, right = self.find(first), self.find(second)
        if left == right:
            return
        self.parent[right] = left
        self.active[left] = self.active[left] or self.active[right]


def canonical_profile(
    active_blocks: list[set[str]] | tuple[tuple[str, ...], ...],
    inactive_blocks: list[set[str]] | tuple[tuple[str, ...], ...],
    closed: int,
) -> tuple[tuple[tuple[str, ...], ...], tuple[tuple[str, ...], ...], int]:
    return (
        tuple(sorted(tuple(sorted(block)) for block in active_blocks if block)),
        tuple(sorted(tuple(sorted(block)) for block in inactive_blocks if block)),
        min(3, closed),
    )


def graph_profile(
    edges: frozenset[tuple[str, str]],
    labels_by_vertex: dict[str, tuple[str, ...]],
) -> tuple[tuple[tuple[str, ...], ...], tuple[tuple[str, ...], ...], int]:
    union = UnionFind()
    incident = set()
    for left, right in edges:
        union.add(left, active=True)
        union.add(right, active=True)
        union.union(left, right)
        incident.update((left, right))

    blocks: dict[object, set[str]] = defaultdict(set)
    inactive = []
    for vertex, labels in labels_by_vertex.items():
        if vertex in incident:
            blocks[union.find(vertex)].update(labels)
        else:
            inactive.append(set(labels))
    roots = {union.find(item) for item in union.parent}
    closed = sum(not blocks[root] for root in roots)
    return canonical_profile(list(blocks.values()), inactive, closed)


def local_join_datum(site_name: str, first: dict, second: dict) -> tuple:
    labels: dict[str, list[str]] = defaultdict(list)
    for vertex in OLD_BOUNDARY:
        labels[vertex].append(f"old:{vertex}")
    for role, vertex in zip(("u", "v", "x", "y"), SITES[site_name]["boundary"], strict=True):
        labels[vertex].append(f"next:{role}")
    partition = graph_profile(
        first["edge_set"] ^ second["edge_set"],
        {vertex: tuple(items) for vertex, items in labels.items()},
    )
    # H', H'' are part of the already-prescribed fixed local join datum.
    return (
        first["next_class"],
        second["next_class"],
        partition,
    )


def set_partitions(items: tuple[str, ...]):
    if not items:
        yield ()
        return
    first, rest = items[0], items[1:]
    for partition in set_partitions(rest):
        yield ((first,),) + partition
        for index in range(len(partition)):
            block = tuple(sorted(partition[index] + (first,)))
            yield partition[:index] + (block,) + partition[index + 1:]


def old_boundary_atoms() -> tuple[tuple, ...]:
    tokens = tuple(f"old:{vertex}" for vertex in OLD_BOUNDARY)
    atoms = set()
    for active_bits in product((0, 1), repeat=len(tokens)):
        active = tuple(token for token, bit in zip(tokens, active_bits, strict=True) if bit)
        inactive = tuple((token,) for token, bit in zip(tokens, active_bits, strict=True) if not bit)
        for blocks in set_partitions(active):
            for closed in range(4):
                atoms.add(canonical_profile(list(blocks), list(inactive), closed))
    return tuple(sorted(atoms))


def join_profiles(old_profile: tuple, local_datum: tuple) -> tuple:
    local_profile = local_datum[2]
    union = UnionFind()
    token_nodes: dict[str, list[object]] = defaultdict(list)
    residual = old_profile[2] + local_profile[2]

    for side, profile in (("exterior", old_profile), ("patch", local_profile)):
        for kind, blocks in (("active", profile[0]), ("inactive", profile[1])):
            for index, block in enumerate(blocks):
                node = (side, kind, index)
                union.add(node, active=kind == "active")
                for token in block:
                    token_nodes[token].append(node)
    for nodes in token_nodes.values():
        for other in nodes[1:]:
            union.union(nodes[0], other)

    next_tokens = tuple(f"next:{role}" for role in ("u", "v", "x", "y"))
    blocks: dict[object, set[str]] = defaultdict(set)
    for token in next_tokens:
        nodes = token_nodes[token]
        assert nodes
        blocks[union.find(nodes[0])].add(token)

    roots = {union.find(node) for node in union.parent}
    active_blocks = []
    inactive_blocks = []
    for root in roots:
        labels = blocks[root]
        if labels:
            target = active_blocks if union.active[root] else inactive_blocks
            target.append(labels)
        elif union.active[root]:
            residual += 1
    return canonical_profile(active_blocks, inactive_blocks, residual)


def direct_join_profile(site_name: str, old_profile: tuple, first: dict, second: dict) -> tuple:
    """Realize an abstract old atom, adjoin P triangle Q, and recut directly."""
    union = UnionFind()
    old_token_vertex = {f"old:{vertex}": vertex for vertex in OLD_BOUNDARY}

    for block_index, block in enumerate(old_profile[0]):
        hub = ("old-hub", block_index)
        union.add(hub, active=True)
        for token in block:
            vertex = old_token_vertex[token]
            union.add(vertex, active=True)
            union.union(hub, vertex)
    residual = old_profile[2]
    for left, right in first["edge_set"] ^ second["edge_set"]:
        union.add(left, active=True)
        union.add(right, active=True)
        union.union(left, right)

    labels_by_vertex: dict[str, list[str]] = defaultdict(list)
    for role, vertex in zip(("u", "v", "x", "y"), SITES[site_name]["boundary"], strict=True):
        labels_by_vertex[vertex].append(f"next:{role}")

    blocks: dict[object, set[str]] = defaultdict(set)
    inactive = []
    for vertex, labels in labels_by_vertex.items():
        if vertex in union.parent and union.active[union.find(vertex)]:
            blocks[union.find(vertex)].update(labels)
        else:
            inactive.append(set(labels))
    roots = {union.find(node) for node in union.parent}
    residual += sum(not blocks[root] for root in roots)
    return canonical_profile(list(blocks.values()), inactive, residual)


def json_profile(profile: tuple) -> dict:
    return {
        "active_blocks": profile[0],
        "inactive_blocks": profile[1],
        "closed_components_saturated": profile[2],
    }


def json_local_datum(datum: tuple) -> dict:
    return {
        "endpoint_next_classes": datum[:2],
        "stub_partition": json_profile(datum[2]),
    }


def analyze_site(site_name: str, patterns: list[dict], old_atoms: tuple[tuple, ...]) -> dict:
    outcomes: dict[tuple, set[tuple]] = defaultdict(set)
    pair_records = []
    direct_checks = 0
    for first, second in product(patterns, repeat=2):
        datum = local_join_datum(site_name, first, second)
        for old_atom in old_atoms:
            joined = join_profiles(old_atom, datum)
            direct = direct_join_profile(site_name, old_atom, first, second)
            assert joined == direct
            direct_checks += 1
            old_pair_atom = (
                first["old_class"],
                second["old_class"],
                old_atom,
            )
            outcomes[(old_pair_atom, datum)].add(joined)
        pair_records.append(
            {
                "first": first["name"],
                "second": second["name"],
                "source_old_classes": (first["old_class"], second["old_class"]),
                "target_next_classes": (first["next_class"], second["next_class"]),
                "local_join_datum": json_local_datum(datum),
            }
        )

    collisions = [
        (key, values) for key, values in outcomes.items() if len(values) != 1
    ]
    if collisions:
        key, values = sorted(collisions, key=repr)[0]
        raise AssertionError(f"first local pair collision: {key!r} -> {values!r}")

    row_histogram: dict[str, dict[str, int]] = {}
    for next_class in CLASS_POSITIONS:
        selected = [row for row in patterns if row["next_class"] == next_class]
        old_histogram: dict[str, int] = defaultdict(int)
        for row in selected:
            old_histogram[row["old_class"]] += 1
        row_histogram[next_class] = dict(sorted(old_histogram.items()))

    unordered_with_repetition = len(patterns) * (len(patterns) + 1) // 2
    distinct_data = {local_join_datum(site_name, a, b) for a, b in product(patterns, repeat=2)}
    return {
        "next_boundary": SITES[site_name]["boundary"],
        "deleted_next_site_edges": tuple(sorted(map(edge_name, SITES[site_name]["edges"]))),
        "pattern_count": len(patterns),
        "row_histogram_by_next_and_old_class": row_histogram,
        "patterns": [
            {key: value for key, value in row.items() if key != "edge_set"}
            for row in patterns
        ],
        "pair_counts": {
            "ordered_including_diagonal": len(patterns) ** 2,
            "unordered_including_diagonal": unordered_with_repetition,
            "distinct_fixed_local_join_data": len(distinct_data),
            "abstract_old_boundary_atoms": len(old_atoms),
            "direct_join_checks": direct_checks,
            "distinct_old_atom_plus_local_join_codes": len(outcomes),
            "collisions": 0,
        },
        "ordered_pattern_pairs": pair_records,
    }


def main() -> None:
    old_atoms = old_boundary_atoms()
    assert len(old_atoms) == 208
    patterns = {site: enumerate_patterns(site) for site in SITES}
    assert {site: len(rows) for site, rows in patterns.items()} == {"CEN": 11, "UV": 12}
    for site, rows in patterns.items():
        actual = {
            (row["next_class"], row["old_class"], tuple(row["edges"]))
            for row in rows
        }
        assert actual == EXPECTED_ROWS[site]

    payload = {
        "status": "PURE_LOCAL_CEN_UV_NEXT_BOUNDARY_PAIR_CLOSURE",
        "scope": {
            "patch_edges": tuple(map(edge_name, PATCH_EDGES)),
            "decoration_orbits_touched": 0,
            "expansion_depth": 1,
            "random_cases": 0,
            "permanent_notes_written": 0,
        },
        "old_defect_classes": tuple(CLASS_POSITIONS),
        "abstract_old_pair_atom_model": {
            "marked_old_stubs": OLD_BOUNDARY,
            "boundary_partition_atoms_with_saturated_closed_count": len(old_atoms),
            "closed_count_values": (0, 1, 2, ">=3"),
        },
        "sites": {
            site: analyze_site(site, patterns[site], old_atoms)
            for site in SITES
        },
        "equalities": {
            "all_old_defects_remain_in_six_classes": True,
            "partition_join_equals_direct_symmetric_difference_recut": True,
            "next_epsilon_is_function_of_old_pair_atom_and_fixed_local_join": True,
            "pair_collision_absent": True,
        },
    }
    OUTPUT.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print("status", payload["status"])
    for site, result in payload["sites"].items():
        print(site, json.dumps({
            "pattern_count": result["pattern_count"],
            "row_histogram": result["row_histogram_by_next_and_old_class"],
            "pair_counts": result["pair_counts"],
        }, sort_keys=True))
    print("equalities", json.dumps(payload["equalities"], sort_keys=True))
    print("output", OUTPUT)


if __name__ == "__main__":
    main()
