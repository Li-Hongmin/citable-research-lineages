# Order-20 terminal-fixed sector countermodel

This bundle verifies the finite countermodel in
[Note 079](../../../notes/079-sector-collision-calculus-exposes-the-essential-brace-boundary.md).
The graph is one actual simple planar cubic bipartite graph, not an abstract
incidence system.  Its complete rooted target family has four members and is
the full closure under two disjoint alternating \(6\)-cycles.  Every eligible
sector quotient and every exact local lift row fails.

The verifier also enumerates all \(81\) perfect matchings and every
independent edge pair.  The only nonextendible pairs are the six pairs drawn
from two nontrivial tight \(3\)-edge cuts.  Thus the example satisfies the
ambient common-incidence hypotheses but fails exactly the brace condition of
\(2\)-extendability.

## Reproduction

From the AIMath project root:

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/order20-terminal-fixed-sector-countermodel/verify_order20_terminal_fixed_sector_countermodel.py

The required final lines are

    ORDER20_TERMINAL_FIXED_SECTOR_COUNTERMODEL_VERIFIED
    COMPLETE_FAMILY_SIZE=4 PM_COUNT=81 ALL_ELIGIBLE_SECTORS_CYCLIC
    ONLY_MISSING_BRACE_AXIOM=TWO_EXTENDABILITY_DUAL_FOUR_CONNECTIVITY

The verifier imports only the permanent local-colouring primitives from the
earlier
[locked-boundary-escape-through18](../locked-boundary-escape-through18/README.md)
bundle.  Discovery search code and search-order claims are not part of this
certificate.

