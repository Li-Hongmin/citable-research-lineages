#!/usr/bin/env python3
"""Verify the order-20 common-incidence countermodel to Note 076(14)."""

from __future__ import annotations

from collections import deque
from itertools import combinations, product
import importlib.util
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
LIFT_PATH = (
    HERE.parent
    / "locked-boundary-escape-through18"
    / "census_locked_escape_through18.py"
)


def load_lift_bundle():
    specification = importlib.util.spec_from_file_location(
        "order20_sector_countermodel_lift", LIFT_PATH
    )
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


lift = load_lift_bundle()
Edge = tuple[int, int]
GRAPH6 = "S???????F?Y?i?X?BO?k?AW?DO?B_?D_?"
BOUNDARY = (13, 5, 17, 7, 16, 4, 12, 2)


def edge(first: int, second: int) -> Edge:
    return (first, second) if first < second else (second, first)


GATES = (edge(5, 13), edge(4, 16))
ROOT = edge(3, 15)
F = frozenset(
    map(lambda item: edge(*item), ((3, 15), (4, 16), (5, 13), (6, 14)))
)
LEFT = (
    frozenset(map(lambda item: edge(*item), ((0, 11), (1, 10), (2, 12)))),
    frozenset(map(lambda item: edge(*item), ((0, 12), (1, 11), (2, 10)))),
)
RIGHT = (
    frozenset(map(lambda item: edge(*item), ((7, 17), (8, 18), (9, 19)))),
    frozenset(map(lambda item: edge(*item), ((7, 18), (8, 19), (9, 17)))),
)
EXPECTED_FAMILY = frozenset(
    F | LEFT[i] | RIGHT[j] for i in range(2) for j in range(2)
)
EXPECTED_WORD = {
    F | LEFT[0] | RIGHT[0]: "01010101",
    F | LEFT[0] | RIGHT[1]: "01110101",
    F | LEFT[1] | RIGHT[0]: "01010111",
    F | LEFT[1] | RIGHT[1]: "01110111",
}
EXPECTED_ELIGIBILITY = {
    "01010101": (True, True, True),
    "01110101": (False, True, False),
    "01010111": (True, False, False),
    "01110111": (False, False, False),
}
TIGHT_CUTS = (
    frozenset((edge(3, 11), edge(4, 12), edge(5, 13))),
    frozenset((edge(4, 16), edge(5, 17), edge(6, 19))),
)
COLLISION_HOLE_PAIRS = (
    frozenset((edge(5, 17), edge(7, 16))),
    frozenset((edge(4, 12), edge(2, 13))),
)


def enumerate_perfect_matchings(graph: nx.Graph) -> tuple[frozenset[Edge], ...]:
    vertices = tuple(sorted(graph))
    used: set[int] = set()
    chosen: list[Edge] = []
    result: list[frozenset[Edge]] = []

    def visit() -> None:
        try:
            first = next(vertex for vertex in vertices if vertex not in used)
        except StopIteration:
            result.append(frozenset(chosen))
            return
        used.add(first)
        for second in graph.neighbors(first):
            if second in used:
                continue
            used.add(second)
            chosen.append(edge(first, second))
            visit()
            chosen.pop()
            used.remove(second)
        used.remove(first)

    visit()
    return tuple(result)


def target_family(
    graph: nx.Graph, matchings: tuple[frozenset[Edge], ...]
) -> frozenset[frozenset[Edge]]:
    graph_edges = frozenset(edge(*item) for item in graph.edges())
    family = []
    for matching in matchings:
        if ROOT not in matching:
            continue
        complement = graph.edge_subgraph(graph_edges - matching)
        components = tuple(nx.connected_components(complement))
        if len(components) != 2:
            continue
        if any(
            ROOT[0] in component and ROOT[1] in component
            for component in components
        ):
            continue
        family.append(matching)
    return frozenset(family)


def face_incidence(
    graph: nx.Graph, faces: tuple[tuple[int, ...], ...]
) -> dict[Edge, tuple[int, int]]:
    result: dict[Edge, list[int]] = {edge(*item): [] for item in graph.edges()}
    for face_index, face in enumerate(faces):
        for index, first in enumerate(face):
            result[edge(first, face[(index + 1) % len(face)])].append(face_index)
    assert all(len(pair) == 2 for pair in result.values())
    return {item: (pair[0], pair[1]) for item, pair in result.items()}


def locate_site(
    faces: tuple[tuple[int, ...], ...],
    incidence: dict[Edge, tuple[int, int]],
) -> tuple[int, tuple[int, ...]]:
    boundary_edges = frozenset(
        edge(BOUNDARY[index], BOUNDARY[(index + 1) % len(BOUNDARY)])
        for index in range(len(BOUNDARY))
    )
    split_face = next(
        index
        for index, face in enumerate(faces)
        if len(face) == len(BOUNDARY)
        and frozenset(
            edge(face[j], face[(j + 1) % len(face)])
            for j in range(len(face))
        )
        == boundary_edges
    )
    neighbours = []
    for index in range(len(BOUNDARY)):
        pair = incidence[
            edge(BOUNDARY[index], BOUNDARY[(index + 1) % len(BOUNDARY)])
        ]
        neighbours.append(pair[1] if pair[0] == split_face else pair[0])
    return split_face, tuple(neighbours)


def dual_colouring(
    face_count: int,
    incidence: dict[Edge, tuple[int, int]],
    matching: frozenset[Edge],
    anchor: int,
) -> dict[int, int]:
    adjacency: dict[int, list[tuple[int, int]]] = {
        index: [] for index in range(face_count)
    }
    for primal_edge, (first, second) in incidence.items():
        difference = 0 if primal_edge in matching else 1
        adjacency[first].append((second, difference))
        adjacency[second].append((first, difference))
    colour = {anchor: 0}
    queue = deque((anchor,))
    while queue:
        first = queue.popleft()
        for second, difference in adjacency[first]:
            value = colour[first] ^ difference
            if second in colour:
                assert colour[second] == value
            else:
                colour[second] = value
                queue.append(second)
    assert len(colour) == face_count
    return colour


def punctured_components(
    dual: nx.Graph,
    colour: dict[int, int],
    dual_root: Edge,
    split_face: int,
) -> tuple[dict[int, int], Edge]:
    forest = lift.monochromatic_graph(dual, colour)
    assert forest.has_edge(*dual_root)
    forest.remove_edge(*dual_root)
    assert nx.is_forest(forest)
    assert nx.number_connected_components(forest) == 3
    assert nx.has_path(forest, *dual_root)
    forest.remove_node(split_face)
    components = tuple(nx.connected_components(forest))
    component_of = {
        vertex: index
        for index, component in enumerate(components)
        for vertex in component
    }
    return component_of, dual_root


def alternating(word: tuple[int, ...]) -> bool:
    return all(
        word[index] != word[index + 1] for index in range(len(word) - 1)
    )


def sector_profile(
    kind: str,
    colour: dict[int, int],
    neighbours: tuple[int, ...],
    component_of: dict[int, int],
    root_ends: Edge,
) -> tuple[bool, bool, bool, bool]:
    left_arc = neighbours[:5]
    right_arc = neighbours[4:] + neighbours[:1]
    graph = nx.MultiGraph()
    graph.add_nodes_from(set(component_of.values()))
    graph.add_nodes_from(("ell", "r", "v"))
    if kind == "L":
        eligible = alternating(tuple(colour[item] for item in left_arc))
        graph.add_edges_from(
            ("ell", component_of[item])
            for item in left_arc
            if colour[item] == 1
        )
        graph.add_edges_from(
            ("r", component_of[item])
            for item in right_arc
            if colour[item] == 0
        )
        graph.add_edge("ell", "v")
    elif kind == "R":
        eligible = alternating(tuple(colour[item] for item in right_arc))
        graph.add_edges_from(
            ("ell", component_of[item])
            for item in left_arc
            if colour[item] == 0
        )
        graph.add_edges_from(
            ("r", component_of[item])
            for item in right_arc
            if colour[item] == 1
        )
        graph.add_edge("r", "v")
    else:
        eligible = alternating(
            tuple(colour[item] for item in left_arc)
        ) and alternating(tuple(colour[item] for item in right_arc))
        graph.add_edges_from(
            ("ell", component_of[item])
            for item in left_arc
            if colour[item] == 1
        )
        graph.add_edges_from(
            ("r", component_of[item])
            for item in right_arc
            if colour[item] == 1
        )
        graph.add_edge("v", component_of[neighbours[0]])
        graph.add_edge("v", component_of[neighbours[4]])
    forest = nx.is_forest(graph)
    root_blocks = tuple(component_of[item] for item in root_ends)
    joined = nx.has_path(graph, *root_blocks)
    parallel = any(
        graph.number_of_edges(first, second) > 1
        for first, second in graph.edges()
    )
    return eligible, forest, joined, parallel


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert nx.number_of_selfloops(graph) == 0
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.check_planarity(graph)[0]
    assert nx.node_connectivity(graph) == 3

    faces = lift.plane_faces(graph)
    incidence = face_incidence(graph, faces)
    split_face, neighbours = locate_site(faces, incidence)
    dual, _rotations = lift.dual_from_primal_faces(graph, faces)
    dual_faces = lift.plane_faces(dual)
    dual_root = edge(*incidence[ROOT])
    assert edge(split_face, neighbours[0]) == edge(*incidence[GATES[0]])
    assert edge(split_face, neighbours[4]) == edge(*incidence[GATES[1]])

    matchings = enumerate_perfect_matchings(graph)
    assert len(matchings) == 81
    assert target_family(graph, matchings) == EXPECTED_FAMILY
    assert {
        sum(edge(*item) in matching for matching in matchings)
        for item in graph.edges()
    } == {27}

    expanded, locals_, _left_arc, _right_arc = lift.split_vertex(
        dual, split_face, neighbours, 0, 4
    )
    expanded_faces = lift.plane_faces(expanded)
    assert all(len(face) == 3 for face in dual_faces + expanded_faces)

    observed_collision_paths: set[tuple[int, ...]] = set()
    for matching in EXPECTED_FAMILY:
        colour = dual_colouring(len(faces), incidence, matching, split_face)
        assert lift.is_target_profile(
            lift.rooted_profile(dual, dual_faces, colour, dual_root)
        )
        word = "".join(str(colour[item]) for item in neighbours)
        assert word == EXPECTED_WORD[matching]
        component_of, root_ends = punctured_components(
            dual, colour, dual_root, split_face
        )
        profiles = tuple(
            sector_profile(kind, colour, neighbours, component_of, root_ends)
            for kind in ("L", "R", "LR")
        )
        assert tuple(profile[0] for profile in profiles) == EXPECTED_ELIGIBILITY[
            word
        ]
        assert all(
            not forest and joined and parallel
            for eligible, forest, joined, parallel in profiles
            if eligible
        )

        punctured = lift.monochromatic_graph(dual, colour)
        punctured.remove_edge(*dual_root)
        punctured.remove_node(split_face)
        for arc, eligible in (
            (neighbours[:5], profiles[0][0]),
            (neighbours[4:] + neighbours[:1], profiles[1][0]),
        ):
            if not eligible:
                continue
            one_vertices = tuple(item for item in arc if colour[item] == 1)
            for first, second in combinations(one_vertices, 2):
                if not nx.has_path(punctured, first, second):
                    continue
                path = tuple(nx.shortest_path(punctured, first, second))
                observed_collision_paths.add(min(path, tuple(reversed(path))))

        fixed = {
            vertex: value
            for vertex, value in colour.items()
            if vertex != split_face
        }
        local_targets = 0
        for bits in product((0, 1), repeat=3):
            lifted_colour = {
                **fixed,
                **dict(zip(locals_, bits, strict=True)),
            }
            local_targets += int(
                lift.is_target_profile(
                    lift.rooted_profile(
                        expanded,
                        expanded_faces,
                        lifted_colour,
                        dual_root,
                    )
                )
            )
        assert local_targets == 0

    left_exchange = LEFT[0] ^ LEFT[1]
    right_exchange = RIGHT[0] ^ RIGHT[1]
    assert left_exchange.isdisjoint(right_exchange)
    assert len(left_exchange) == len(right_exchange) == 6
    assert (left_exchange | right_exchange).isdisjoint(set(GATES) | {ROOT})
    assert observed_collision_paths == {(8, 11, 10), (1, 0, 4)}
    assert all(
        any(pair <= matching for matching in matchings)
        for pair in COLLISION_HOLE_PAIRS
    )

    graph_edges = tuple(sorted(edge(*item) for item in graph.edges()))
    nonextendible = {
        frozenset((first, second))
        for first, second in combinations(graph_edges, 2)
        if set(first).isdisjoint(second)
        and not any(
            first in matching and second in matching for matching in matchings
        )
    }
    expected_nonextendible = {
        frozenset(pair)
        for cut in TIGHT_CUTS
        for pair in combinations(sorted(cut), 2)
    }
    assert nonextendible == expected_nonextendible
    assert all(
        all(len(cut & matching) == 1 for matching in matchings)
        for cut in TIGHT_CUTS
    )

    assert all(degree % 2 == 0 for _, degree in dual.degree())
    assert nx.node_connectivity(dual) == 3
    assert nx.check_planarity(expanded)[0]
    assert all(degree % 2 == 0 for _, degree in expanded.degree())
    assert nx.node_connectivity(expanded) == 3

    print("ORDER20_TERMINAL_FIXED_SECTOR_COUNTERMODEL_VERIFIED")
    print("COMPLETE_FAMILY_SIZE=4 PM_COUNT=81 ALL_ELIGIBLE_SECTORS_CYCLIC")
    print("ONLY_MISSING_BRACE_AXIOM=TWO_EXTENDABILITY_DUAL_FOUR_CONNECTIVITY")


if __name__ == "__main__":
    main()
