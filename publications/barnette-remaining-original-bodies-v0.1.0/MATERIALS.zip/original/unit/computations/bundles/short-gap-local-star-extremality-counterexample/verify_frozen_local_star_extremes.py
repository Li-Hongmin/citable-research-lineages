#!/usr/bin/env python3
"""Audit the fixed-state-11 local-star sibling claim in frozen data.

The universe is exactly the 262 one-edge-gap ParentKill records already
frozen in the through-order-26 rooted-split-bond bundle.  Inside each
record, a local star is centred at an incident state-11 rooted target M;
its leaves are all parent bonds incident with M.  A nonempty star is
called extreme when every leaf is an h-avoiding 11--00 bond.

For every leaf of every extreme star, this script reconstructs the
Note-140 gate-path sibling in the child already specified by that frozen
record and tests rooted admission.  It generates no graph, site, order,
random instance, or neighbouring parameter beyond the frozen records.
"""

from __future__ import annotations

from collections import Counter, defaultdict
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
EXTREME_BUNDLE = HERE.parent / "short-gap-extreme-family-boundary"
BASE_PATH = EXTREME_BUNDLE / "verify_frozen_short_gap_extreme_families.py"
SIBLING_PATH = EXTREME_BUNDLE / "verify_frozen_gate_path_siblings.py"

sys.dont_write_bytecode = True


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


base = load_module(BASE_PATH, "frozen_local_star_base")
sibling_base = load_module(SIBLING_PATH, "frozen_local_star_sibling_base")
classifier = base.classifier


def matching_key(matching):
    return tuple(sorted(matching))


def serial_matching(matching):
    return [list(item) for item in matching_key(matching)]


def complement_components(graph: nx.Graph, matching):
    complement = graph.copy()
    complement.remove_edges_from(matching)
    return tuple(
        sorted(
            (
                tuple(sorted(component))
                for component in nx.connected_components(complement)
            ),
            key=lambda component: (len(component), component),
        )
    )


def gate_path_sibling(
    graph,
    child,
    local,
    selected,
    surviving_gate,
    state11,
    state00,
):
    """Return the canonical C00 lift and its gate-path sibling."""

    ua, _ab, bv, xc, _cd, dy, ad, bc = local
    old_vertices = set(graph)
    first_left = next(vertex for vertex in ua if vertex in old_vertices)
    first_right = next(vertex for vertex in bv if vertex in old_vertices)
    second_left = next(vertex for vertex in xc if vertex in old_vertices)
    second_right = next(vertex for vertex in dy if vertex in old_vertices)
    endpoint_pairs = {
        frozenset((first_left, second_right)): (
            "Xuy",
            frozenset((ua, ad, dy)),
        ),
        frozenset((first_right, second_left)): (
            "Xvx",
            frozenset((bv, bc, xc)),
        ),
    }

    difference = state11 ^ state00
    paths = sibling_base.component_edge_sets(difference, selected)
    gate_paths = tuple(path for path in paths if surviving_gate in path)
    assert len(gate_paths) == 1
    gate_path = gate_paths[0]
    path_endpoints = frozenset(
        vertex
        for vertex in (
            first_left,
            first_right,
            second_left,
            second_right,
        )
        if sum(vertex in item for item in gate_path) == 1
    )
    assert path_endpoints in endpoint_pairs
    target_cell, gadget_path = endpoint_pairs[path_endpoints]

    canonical = frozenset(state00 | frozenset((ad, bc)))
    assert sibling_base.is_perfect_matching(child, canonical)
    flip_cycle = frozenset(gate_path | gadget_path)
    cycle_graph = nx.Graph()
    cycle_graph.add_edges_from(flip_cycle)
    assert nx.is_connected(cycle_graph)
    assert set(dict(cycle_graph.degree()).values()) == {2}
    sibling = frozenset(canonical ^ flip_cycle)
    assert sibling_base.is_perfect_matching(child, sibling)
    assert classifier.local_cell(sibling, local) == target_cell
    assert (surviving_gate in sibling) != (surviving_gate in canonical)
    assert classifier.difference_component_count(canonical, sibling) == 1
    return canonical, sibling, target_cell, gate_path, flip_cycle


def record_key(record):
    site = record["site"]
    return (
        str(record["source_graph6"]),
        tuple(record["root"]),
        tuple(record["forced_gate"]),
        tuple(record["surviving_gate"]),
        int(site["face_index"]),
        tuple(site["indices"]),
    )


def main() -> None:
    frozen = json.loads(base.FROZEN_PATH.read_text())
    assert len(frozen["hits"]) == 323
    records = sorted(
        frozen["hits"],
        key=lambda record: (
            int(record["parent_order"]),
            str(record["source_graph6"]),
            record["root"],
            record["forced_gate"],
            record["surviving_gate"],
            record["site"]["face_index"],
            record["site"]["indices"],
        ),
    )

    short_gap_records = 0
    incident_state11_stars = 0
    local_extreme_stars = []
    full_family_extreme_records = set()
    local_extreme_records = set()
    star_degree_histogram: Counter[int] = Counter()
    outcome_histogram: Counter[str] = Counter()
    by_order_local_extreme: Counter[int] = Counter()
    by_order_counterexamples: Counter[int] = Counter()

    for record in records:
        graph6 = str(record["source_graph6"])
        graph, faces, all_matchings = base.graph_data(graph6)
        short_edge = base.one_edge_gap(record, faces)
        if short_edge is None:
            continue
        short_gap_records += 1

        root = base.as_edge(record["root"])
        forced_gate = base.as_edge(record["forced_gate"])
        surviving_gate = base.as_edge(record["surviving_gate"])
        site = record["site"]
        selected = tuple(base.as_edge(item) for item in site["selected"])
        fibre = tuple(
            sorted(
                (
                    matching
                    for matching in all_matchings
                    if classifier.is_root_target(
                        graph, matching, root, forced_gate
                    )
                ),
                key=matching_key,
            )
        )
        assert len(fibre) == int(record["parent_fibre_size"])
        sectors = (
            tuple(item for item in fibre if surviving_gate not in item),
            tuple(item for item in fibre if surviving_gate in item),
        )
        bonds = tuple(
            (first, second)
            for first in sectors[0]
            for second in sectors[1]
            if classifier.difference_component_count(first, second) == 1
        )
        assert len(bonds) == int(record["parent_crossings"])

        incident = defaultdict(list)
        all_bonds_bad = True
        for first, second in bonds:
            first_state = base.matching_state(first, selected)
            second_state = base.matching_state(second, selected)
            assert "11" in (first_state, second_state)
            if first_state == "11" and second_state != "11":
                state11, other, other_state = first, second, second_state
            elif second_state == "11" and first_state != "11":
                state11, other, other_state = second, first, first_state
            else:
                # A 11--11 bond is automatic and is incident with both
                # state-11 endpoints.  Store the same bond in both stars.
                assert first_state == second_state == "11"
                incident[first].append((first, second, False, second))
                incident[second].append((first, second, False, first))
                all_bonds_bad = False
                continue

            bad = other_state == "00" and short_edge not in other
            incident[state11].append((first, second, bad, other))
            all_bonds_bad &= bad

        if all_bonds_bad:
            full_family_extreme_records.add(record_key(record))

        expanded_site = {
            "face_index": int(site["face_index"]),
            "face_length": int(site["face_length"]),
            "indices": tuple(map(int, site["indices"])),
            "selected": selected,
        }
        child, _child_faces, local = classifier.expand_on_face(
            graph, faces, expanded_site
        )

        for state11, star_bonds in sorted(
            incident.items(), key=lambda item: matching_key(item[0])
        ):
            assert star_bonds
            incident_state11_stars += 1
            if not all(item[2] for item in star_bonds):
                continue

            order = int(record["parent_order"])
            local_extreme_records.add(record_key(record))
            by_order_local_extreme[order] += 1
            star_degree_histogram[len(star_bonds)] += 1
            leaf_results = []
            for _first, _second, _bad, state00 in star_bonds:
                assert base.matching_state(state00, selected) == "00"
                assert short_edge not in state00
                canonical, candidate, target_cell, gate_path, flip_cycle = (
                    gate_path_sibling(
                        graph,
                        child,
                        local,
                        selected,
                        surviving_gate,
                        state11,
                        state00,
                    )
                )
                rooted = classifier.is_root_target(
                    child, candidate, root, forced_gate
                )
                components = complement_components(child, candidate)
                if rooted:
                    assert len(components) == 2
                else:
                    assert len(components) != 2 or not all(
                        len(set(root) & component) == 1
                        for component in components
                    )
                leaf_results.append(
                    {
                        "state00": state00,
                        "canonical": canonical,
                        "sibling": candidate,
                        "target_cell": target_cell,
                        "gate_path": gate_path,
                        "flip_cycle": flip_cycle,
                        "rooted": rooted,
                        "complement_components": components,
                    }
                )

            rooted_count = sum(item["rooted"] for item in leaf_results)
            if rooted_count:
                outcome = "at-least-one-rooted-sibling"
            else:
                outcome = "no-rooted-sibling"
                by_order_counterexamples[order] += 1
            outcome_histogram[outcome] += 1
            local_extreme_stars.append(
                {
                    "record": record,
                    "root": root,
                    "forced_gate": forced_gate,
                    "surviving_gate": surviving_gate,
                    "selected": selected,
                    "short_edge": short_edge,
                    "state11": state11,
                    "state11_fibre_index": fibre.index(state11),
                    "leaf_results": leaf_results,
                    "rooted_count": rooted_count,
                }
            )

    assert short_gap_records == 262
    assert len(full_family_extreme_records) == 1
    counterexamples = tuple(
        star for star in local_extreme_stars if star["rooted_count"] == 0
    )
    witnesses = tuple(
        star for star in local_extreme_stars if star["rooted_count"] > 0
    )
    assert counterexamples
    witness_records = {record_key(star["record"]) for star in witnesses}
    counterexample_records = {
        record_key(star["record"]) for star in counterexamples
    }
    assert witness_records == full_family_extreme_records
    assert counterexample_records.isdisjoint(full_family_extreme_records)
    assert len(local_extreme_stars) == 6
    assert len(local_extreme_records) == 5
    assert star_degree_histogram == {1: 6}
    assert len(counterexamples) == 4
    assert len(witnesses) == 2

    first = counterexamples[0]
    first_record = first["record"]
    first_profile, first_bond_count = base.bond_profile(
        tuple(
            matching
            for matching in base.graph_data(
                str(first_record["source_graph6"])
            )[2]
            if classifier.is_root_target(
                base.graph_data(str(first_record["source_graph6"]))[0],
                matching,
                first["root"],
                first["forced_gate"],
            )
        ),
        first["surviving_gate"],
        first["selected"],
        first["short_edge"],
    )
    assert first_bond_count == int(first_record["parent_crossings"])

    first_counterexample = {
        "parent_order": first_record["parent_order"],
        "source_graph6": first_record["source_graph6"],
        "root": list(first["root"]),
        "forced_gate": list(first["forced_gate"]),
        "surviving_gate": list(first["surviving_gate"]),
        "site": first_record["site"],
        "short_edge_h": list(first["short_edge"]),
        "family_bond_profile": dict(sorted(first_profile.items())),
        "family_is_extreme": (
            record_key(first_record) in full_family_extreme_records
        ),
        "state11_centre": serial_matching(first["state11"]),
        "state11_fibre_index": first["state11_fibre_index"],
        "star_degree": len(first["leaf_results"]),
        "leaves": [
            {
                "state00": serial_matching(leaf["state00"]),
                "target_cell": leaf["target_cell"],
                "gate_path": serial_matching(leaf["gate_path"]),
                "flip_cycle": serial_matching(leaf["flip_cycle"]),
                "sibling": serial_matching(leaf["sibling"]),
                "sibling_rooted": leaf["rooted"],
                "sibling_complement_components": [
                    list(component)
                    for component in leaf["complement_components"]
                ],
            }
            for leaf in first["leaf_results"]
        ],
        "recorded_child_supplement_bonds": first_record[
            "new_cell_crossings"
        ],
    }

    payload = {
        "scope": {
            "frozen_parentkill_hits": len(frozen["hits"]),
            "one_edge_gap_parentkill_records": short_gap_records,
            "generated_new_graphs_sites_orders_or_random_instances": False,
            "zero_degree_state11_targets_excluded": True,
        },
        "incident_state11_stars": incident_state11_stars,
        "local_star_extremes": len(local_extreme_stars),
        "records_containing_local_star_extremes": len(
            local_extreme_records
        ),
        "local_star_extremes_by_parent_order": dict(
            sorted(by_order_local_extreme.items())
        ),
        "local_star_degree_histogram": dict(
            sorted(star_degree_histogram.items())
        ),
        "local_star_outcomes": dict(sorted(outcome_histogram.items())),
        "counterexamples_by_parent_order": dict(
            sorted(by_order_counterexamples.items())
        ),
        "full_family_extreme_records": len(full_family_extreme_records),
        "local_star_extreme_records": len(local_extreme_records),
        "local_star_is_strictly_more_common_than_full_family_extreme": (
            len(local_extreme_records) > len(full_family_extreme_records)
        ),
        "counterexample_identities": [
            {
                "parent_order": star["record"]["parent_order"],
                "source_graph6": star["record"]["source_graph6"],
                "root": star["record"]["root"],
                "forced_gate": star["record"]["forced_gate"],
                "surviving_gate": star["record"]["surviving_gate"],
                "site_face_index": star["record"]["site"]["face_index"],
                "site_indices": star["record"]["site"]["indices"],
                "state11_fibre_index": star["state11_fibre_index"],
                "star_degree": len(star["leaf_results"]),
            }
            for star in counterexamples
        ],
        "first_counterexample": first_counterexample,
        "rooted_local_star_witnesses": len(witnesses),
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("FROZEN_LOCAL_STAR_EXTREME_HAS_REAL_COUNTEREXAMPLE")


if __name__ == "__main__":
    main()
