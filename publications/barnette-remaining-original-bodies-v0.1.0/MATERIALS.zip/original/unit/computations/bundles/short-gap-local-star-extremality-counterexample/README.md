# Short-gap local-star extremality counterexample certificate

This bundle supports the real counterexample and finite scope statement in
Note 143.  It reads only the 323 frozen ParentKill records from the permanent
through-order-26 bundle, retains the 262 one-edge-gap records, reconstructs
every nonempty state-\(11\) incident bond star, and tests the Note-140
gate-path sibling on every locally extreme star.

Run from the AIMath project root:

~~~bash
uv run --python 3.12 --with 'networkx==3.6.1' python \
  units/barnette/computations/bundles/short-gap-local-star-extremality-counterexample/verify_frozen_local_star_extremes.py
~~~

The final marker is

~~~text
FROZEN_LOCAL_STAR_EXTREME_HAS_REAL_COUNTEREXAMPLE
~~~

The verifier confirms 674 nonempty state-\(11\) stars, six locally extreme
stars in five order-26 records, four failures and two successes.  It freezes
one explicit real failure and checks that all four failures lie in
non-extreme complete families, whereas the two successes are the two stars
of the unique complete-family-extreme record.

The minimum and counts are only for the named frozen root-opposite-square
legal-wide stratum.  The script generates no graph, site, order, random
instance, or neighbouring parameter.
