#!/usr/bin/env python3
"""Finite boundary-state certificate for the Note 141 six-port core.

The certificate deliberately over-approximates a plane cubic completion.
An exterior matching state is represented by

* a pairing of the six open ports by complement paths;
* zero, one, or two exterior complement cycles; and
* the two root endpoints marked on exterior path/cycle components.

Every actual completion whose matching avoids the six spokes induces one
of these states.  The parent rooted antecedent forces at most one exterior
closed cycle, so the finite range is complete for the question.

The decisive UNSAT core is smaller: the canonical C00 matching and its
gate-changing Xuy sibling have exactly the same local complement boundary
signature.  Consequently every common exterior matching state gives them
the same global complement count and the same root-separation bit.
"""

from __future__ import annotations

from collections import deque
from itertools import combinations, product


Vertex = str
Edge = tuple[Vertex, Vertex]
Matching = frozenset[Edge]
Pairing = tuple[Edge, ...]


def edge(first: Vertex, second: Vertex) -> Edge:
    assert first != second
    return tuple(sorted((first, second)))


def edges(*items: tuple[Vertex, Vertex]) -> frozenset[Edge]:
    return frozenset(edge(*item) for item in items)


PORTS = ("v", "r", "s", "x", "w", "t")
OUTER_FACE = PORTS
HEXAGON_FACE = ("v", "r", "s", "x")
SQUARE_FACE = ("w", "t")
FACES = {
    "outer": OUTER_FACE,
    "hexagon": HEXAGON_FACE,
    "square": SQUARE_FACE,
}

P = edge("u", "v")
Q = edge("x", "y")
H = edge("u", "y")
GATE = edge("t", "u")
P_UY = edges(("u", "t"), ("t", "w"), ("w", "y"))
P_VX = edges(("v", "r"), ("r", "s"), ("s", "x"))
PARENT = frozenset({P, Q, H}) | P_UY | P_VX

UA = edge("u", "a")
AB = edge("a", "b")
BV = edge("b", "v")
XC = edge("x", "c")
CD = edge("c", "d")
DY = edge("d", "y")
AD = edge("a", "d")
BC = edge("b", "c")
CHILD = (PARENT - {P, Q}) | frozenset((UA, AB, BV, XC, CD, DY, AD, BC))


def vertices(graph: frozenset[Edge]) -> frozenset[Vertex]:
    return frozenset(vertex for item in graph for vertex in item)


def adjacency(graph: frozenset[Edge]) -> dict[Vertex, set[Vertex]]:
    result = {vertex: set() for vertex in vertices(graph)}
    for first, second in graph:
        result[first].add(second)
        result[second].add(first)
    return result


def enumerate_perfect_matchings(graph: frozenset[Edge]) -> tuple[Matching, ...]:
    graph_adjacency = adjacency(graph)
    output: list[Matching] = []

    def visit(remaining: frozenset[Vertex], chosen: tuple[Edge, ...]) -> None:
        if not remaining:
            output.append(frozenset(chosen))
            return
        first = min(remaining)
        for second in sorted(graph_adjacency[first] & set(remaining)):
            visit(remaining - {first, second}, chosen + (edge(first, second),))

    visit(vertices(graph), ())
    return tuple(sorted(set(output), key=lambda item: tuple(sorted(item))))


def all_pairings(items: tuple[Vertex, ...]) -> tuple[Pairing, ...]:
    if not items:
        return ((),)
    first = items[0]
    output: list[Pairing] = []
    for index in range(1, len(items)):
        second = items[index]
        remainder = items[1:index] + items[index + 1 :]
        for rest in all_pairings(remainder):
            output.append(tuple(sorted((edge(first, second),) + rest)))
    return tuple(sorted(set(output)))


def chords_cross(first: Edge, second: Edge, boundary: tuple[Vertex, ...]) -> bool:
    positions = {vertex: index for index, vertex in enumerate(boundary)}
    a, b = sorted((positions[first[0]], positions[first[1]]))
    c, d = sorted((positions[second[0]], positions[second[1]]))
    return (a < c < b < d) or (c < a < d < b)


def facewise_planar_assignments(pairing: Pairing) -> tuple[tuple[str, ...], ...]:
    choices = [
        tuple(name for name, boundary in FACES.items() if set(item) <= set(boundary))
        for item in pairing
    ]
    output = []
    for assignment in product(*choices):
        valid = True
        for face_name, boundary in FACES.items():
            face_edges = [
                item for item, assigned in zip(pairing, assignment, strict=True)
                if assigned == face_name
            ]
            if any(
                chords_cross(first, second, boundary)
                for first, second in combinations(face_edges, 2)
            ):
                valid = False
                break
        if valid:
            output.append(assignment)
    return tuple(output)


def local_complement_signature(
    graph: frozenset[Edge], matching: Matching
) -> tuple[Pairing, int]:
    complement = graph - matching
    graph_adjacency = adjacency(complement)
    unseen = set(graph_adjacency)
    port_pairs: list[Edge] = []
    closed_cycles = 0
    while unseen:
        start = next(iter(unseen))
        component = {start}
        unseen.remove(start)
        queue = deque((start,))
        while queue:
            current = queue.popleft()
            for neighbour in graph_adjacency[current]:
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    component.add(neighbour)
                    queue.append(neighbour)
        component_ports = sorted(component & set(PORTS))
        if component_ports:
            assert len(component_ports) == 2
            port_pairs.append(edge(*component_ports))
        else:
            closed_cycles += 1
    assert len(port_pairs) == 3
    return tuple(sorted(port_pairs)), closed_cycles


def union_partition(local: Pairing, exterior: Pairing) -> tuple[frozenset[int], ...]:
    port_to_exterior_path = {
        vertex: index for index, item in enumerate(exterior) for vertex in item
    }
    graph = {index: set() for index in range(3)}
    for first, second in local:
        left = port_to_exterior_path[first]
        right = port_to_exterior_path[second]
        graph[left].add(right)
        graph[right].add(left)
    unseen = set(graph)
    output = []
    while unseen:
        start = next(iter(unseen))
        component = {start}
        unseen.remove(start)
        queue = [start]
        while queue:
            current = queue.pop()
            for neighbour in graph[current]:
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    component.add(neighbour)
                    queue.append(neighbour)
        output.append(frozenset(component))
    return tuple(sorted(output, key=lambda item: (min(item), len(item))))


def global_signature(
    local_signature: tuple[Pairing, int],
    exterior: Pairing,
    exterior_cycles: int,
    root_marks: tuple[int, int],
) -> tuple[int, bool]:
    local_pairing, local_cycles = local_signature
    path_partition = union_partition(local_pairing, exterior)
    component_of_path = {
        path: index
        for index, component in enumerate(path_partition)
        for path in component
    }
    # Labels 0,1,2 denote exterior port paths.  Larger labels denote
    # port-free exterior cycles, each of which remains its own component.
    root_components = []
    for mark in root_marks:
        if mark < 3:
            root_components.append(("joined", component_of_path[mark]))
        else:
            root_components.append(("external-cycle", mark - 3))
    component_count = len(path_partition) + local_cycles + exterior_cycles
    root_separated = root_components[0] != root_components[1]
    return component_count, root_separated


def difference_component_count(first: Matching, second: Matching) -> int:
    difference = first ^ second
    graph = adjacency(difference)
    assert graph and set(map(len, graph.values())) == {2}
    unseen = set(graph)
    count = 0
    while unseen:
        count += 1
        start = unseen.pop()
        queue = [start]
        while queue:
            current = queue.pop()
            for neighbour in graph[current]:
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    queue.append(neighbour)
    return count


def rooted(signature: tuple[int, bool]) -> bool:
    return signature == (2, True)


def main() -> None:
    parent_matchings = frozenset(enumerate_perfect_matchings(PARENT))
    child_matchings = frozenset(enumerate_perfect_matchings(CHILD))
    assert len(parent_matchings) == 3
    assert len(child_matchings) == 8

    matching_11 = frozenset((P, Q, edge("r", "s"), edge("t", "w")))
    matching_00 = frozenset(
        (edge("v", "r"), edge("s", "x"), edge("u", "t"), edge("w", "y"))
    )
    toggle_h = frozenset((edge("v", "r"), edge("s", "x"), edge("t", "w"), H))
    assert parent_matchings == {matching_11, matching_00, toggle_h}

    canonical_00 = matching_00 | {AD, BC}
    phi_11 = (matching_11 - {P, Q}) | {H, AD, BV, XC}
    sibling_uy = canonical_00 ^ (P_UY | {UA, AD, DY})
    sibling_vx = canonical_00 ^ (P_VX | {BV, BC, XC})
    assert {canonical_00, phi_11, sibling_uy, sibling_vx} <= child_matchings

    parent_signatures = {
        matching: local_complement_signature(PARENT, matching)
        for matching in parent_matchings
    }
    child_signatures = {
        matching: local_complement_signature(CHILD, matching)
        for matching in child_matchings
    }

    decisive_signature = ((edge("r", "s"), edge("t", "w"), edge("v", "x")), 0)
    assert child_signatures[canonical_00] == decisive_signature
    assert child_signatures[sibling_uy] == decisive_signature
    assert GATE in canonical_00 and GATE not in sibling_uy
    assert difference_component_count(canonical_00, sibling_uy) == 1

    pairings = all_pairings(PORTS)
    outer_noncrossing = tuple(
        pairing
        for pairing in pairings
        if not any(
            chords_cross(first, second, OUTER_FACE)
            for first, second in combinations(pairing, 2)
        )
    )
    facewise_planar = tuple(
        pairing for pairing in pairings if facewise_planar_assignments(pairing)
    )
    assert len(pairings) == 15
    assert len(outer_noncrossing) == 5

    checked_states = 0
    parent_antecedent_states = []
    exact_note141_states = []
    no_supplement_states = []
    for exterior in pairings:  # all 15 is a planar over-approximation
        for exterior_cycles in range(3):
            labels = tuple(range(3 + exterior_cycles))
            for root_marks in product(labels, repeat=2):
                checked_states += 1
                signatures_parent = {
                    matching: global_signature(
                        parent_signatures[matching], exterior, exterior_cycles, root_marks
                    )
                    for matching in parent_matchings
                }
                signatures_child = {
                    matching: global_signature(
                        child_signatures[matching], exterior, exterior_cycles, root_marks
                    )
                    for matching in child_matchings
                }

                parent_antecedent = (
                    rooted(signatures_parent[matching_11])
                    and rooted(signatures_parent[matching_00])
                    and not rooted(signatures_parent[toggle_h])
                )
                if parent_antecedent:
                    parent_antecedent_states.append(
                        (exterior, exterior_cycles, root_marks, signatures_parent)
                    )

                if (
                    signatures_parent[matching_11] == (2, True)
                    and signatures_parent[matching_00] == (2, True)
                    and signatures_parent[toggle_h][0] == 3
                ):
                    exact_note141_states.append(
                        (exterior, exterior_cycles, root_marks)
                    )

                # Matching extension is common: an exterior matching which
                # extends canonical_00 also extends sibling_uy because both
                # match every core vertex internally.  Their equal boundary
                # signatures must therefore give equal rootedness.
                assert rooted(signatures_child[canonical_00]) == rooted(
                    signatures_child[sibling_uy]
                )
                if parent_antecedent and rooted(signatures_child[canonical_00]) and not rooted(
                    signatures_child[sibling_uy]
                ):
                    no_supplement_states.append(
                        (exterior, exterior_cycles, root_marks)
                    )

    assert parent_antecedent_states
    assert exact_note141_states
    assert not no_supplement_states

    # The parent antecedent is not killed by an accidental outer-face-only
    # assumption.  Its unique exterior pairing can be drawn facewise without
    # crossings: rx in the hexagon, vs outside, wt in the square.
    zero_cycle_parent_pairings = {
        state[0] for state in parent_antecedent_states if state[1] == 0
    }
    witness_exterior = tuple(sorted((edge("r", "x"), edge("v", "s"), edge("w", "t"))))
    assert zero_cycle_parent_pairings == {witness_exterior}
    witness_assignments = facewise_planar_assignments(witness_exterior)
    assert ("hexagon", "outer", "square") in witness_assignments
    assert witness_exterior in facewise_planar
    assert witness_exterior not in outer_noncrossing

    print(f"parent_pm_count={len(parent_matchings)}")
    print(f"child_pm_count={len(child_matchings)}")
    print(f"all_port_pairings={len(pairings)}")
    print(f"outer_face_noncrossing_pairings={len(outer_noncrossing)}")
    print(f"facewise_planar_pairings={len(facewise_planar)}")
    print(f"abstract_boundary_states_checked={checked_states}")
    print(f"parent_extreme_boundary_states={len(parent_antecedent_states)}")
    print("zero-exterior-cycle_parent_extreme_unique_pairing=(rx)(vs)(wt)")
    print(f"exact_note141_parent_2_2_3_states={len(exact_note141_states)}")
    print("canonical_C00_signature=(rs)(tw)(vx)+0cycles")
    print("gate_sibling_Xuy_signature=(rs)(tw)(vx)+0cycles")
    print(f"parent_extreme_plus_gate_sibling_nonrooted_states={len(no_supplement_states)}")
    print("SIX_PORT_BOUNDARY_SIGNATURE_UNSAT_VERIFIED")


if __name__ == "__main__":
    main()

