# C8+h six-port common-completion obstruction certificate

This bundle supports the fixed-core theorem in Note 142.  It enumerates all
three internally perfect matchings of the parent \(C_8+h\) core, all eight
of its expanded child core, and their complete complementary boundary
signatures.

The boundary CSP deliberately over-approximates plane completions.  It uses
all 15 pairings of the six ports, zero through two port-free exterior
complement cycles, and every placement of the two root endpoints on the
resulting exterior components, for 750 states.  It confirms that parent
extreme signatures are feasible in this abstraction, but the joint
requirement “canonical \(C_{00}\) rooted and gate sibling \(X_{uy}\)
nonrooted” is impossible because the two local complements have the same
port pairing and no internal closed cycle.

Run from the AIMath project root:

~~~bash
python3 \
  units/barnette/computations/bundles/c8h-six-port-completion-obstruction/verify_six_port_boundary_signature_unsat.py
~~~

The final marker is

~~~text
SIX_PORT_BOUNDARY_SIGNATURE_UNSAT_VERIFIED
~~~

The script performs no completion construction, graph generation, order
scan, random search, or neighbouring-parameter computation.  Its theorem is
only for the explicit core of Note 141.
