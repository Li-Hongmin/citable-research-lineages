# One-edge-gap mixed-bond classification certificate

This bundle verifies the fixed order-(26) sharpness example used in
Note 139.  The arbitrary-order classification in that note is analytic;
this script only proves that all four local rows, including the unique bad
row, occur in actual interface-disjoint legal-wide rooted decorations.

The verifier reconstructs the fixed Note 138 graph and expansion site,
enumerates the complete parent and child perfect-matching families, and
checks every state-(11)--non-(11) pair having one-cycle symmetric
difference.  It verifies the exact counts

\[
248,\quad392,\quad652,\quad406
\]

for (11)--(10), (11)--(01), (11)--(00) with (h) present,
and (11)--(00) with (h) absent.  The first three rows always transfer
to one child cycle; every pair in the last row transfers to exactly two.

For one legal-wide rooted witness in each row, the script checks rooted
admission, opposite gate sectors, and inherited child admission.  For the
bad witness it also enumerates the complete parent and child rooted fibres,
showing that ParentKill is false and that (16) unrelated new-cell child
bonds still supplement the direct failure.

Run from the AIMath project root:

~~~bash
uv run --python 3.12 --with 'networkx==3.6.1' python \
  units/barnette/computations/bundles/one-edge-gap-mixed-bond-classification/verify_fixed_n26_short_gap_mixed_bonds.py
~~~

The final marker is

~~~text
ONE_EDGE_GAP_MIXED_BOND_CLASSIFICATION_VERIFIED
~~~

The script imports the fixed graph and general matching routines from the
already permanent Note 138 bundle.  It performs no graph generation, order
scan, random search, or site scan.
