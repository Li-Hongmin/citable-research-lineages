#!/usr/bin/env python3
"""Verify the fixed Note 139 one-edge-gap mixed-bond classification."""

from __future__ import annotations

from collections import Counter
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
VERIFY_PATH = (
    HERE.parent
    / "one-edge-gap-pure11-transfer"
    / "verify_fixed_n26_one_edge_gap.py"
)


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


verify = load_module(VERIFY_PATH, "short_gap_mixed_verify_base")
base = verify.base
edge = base.edge

P = edge(11, 21)
Q = edge(3, 25)


def state(matching):
    return (int(P in matching), int(Q in matching))


def canonical_lift(matching, child, local):
    ua, ab, bv, xc, cd, dy, ad, bc = local
    patterns = {
        (0, 0): frozenset((ad, bc)),
        (1, 0): frozenset((ua, bv, cd)),
        (0, 1): frozenset((xc, dy, ab)),
    }
    image = frozenset((matching - verify.SITE) | patterns[state(matching)])
    assert verify.is_perfect_matching(child, image)
    return image


def deleted_pairing(first, second, orientation):
    """Return the endpoint pairing after deleting p and q from one cycle."""
    u, v, x, y = orientation
    difference = set(first ^ second) - set(verify.SITE)
    graph = nx.Graph()
    graph.add_edges_from(difference)
    endpoint_set = {u, v, x, y}
    distinct = []
    for vertex in (u, v, x, y):
        component = nx.node_connected_component(graph, vertex)
        pair = frozenset(component & endpoint_set)
        if pair not in distinct:
            distinct.append(pair)
    assert len(distinct) == 2 and all(len(item) == 2 for item in distinct)
    return frozenset(distinct)


def target_roots(graph, matching):
    complement = graph.copy()
    complement.remove_edges_from(matching)
    components = tuple(
        frozenset(item) for item in nx.connected_components(complement)
    )
    if len(components) != 2:
        return frozenset()
    return frozenset(
        item
        for item in matching
        if all(len(set(item) & component) == 1 for component in components)
    )


def first_legal_decoration(graph, faces, first, second, site_vertices):
    roots = target_roots(graph, first) & target_roots(graph, second)
    roots = tuple(
        sorted(item for item in roots if not set(item) & site_vertices)
    )
    forced = tuple(
        sorted(
            item
            for item in first & second
            if not set(item) & site_vertices
        )
    )
    gates = tuple(
        sorted(
            item
            for item in first ^ second
            if not set(item) & site_vertices
        )
    )
    for root in roots:
        for forced_gate in forced:
            if forced_gate == root:
                continue
            for surviving_gate in gates:
                if base.legal_wide_arcs(
                    faces, root, forced_gate, surviving_gate
                ):
                    return root, forced_gate, surviving_gate
    return None


def bond_state_profile(bonds):
    return dict(
        sorted(
            Counter(
                "-".join(
                    sorted(
                        (
                            "".join(map(str, state(first))),
                            "".join(map(str, state(second))),
                        )
                    )
                )
                for first, second in bonds
            ).items()
        )
    )


def main():
    graph = nx.from_graph6_bytes(verify.GRAPH6.encode())
    faces = verify.reconstruct_faces(graph)
    matchings = tuple(
        sorted(
            base.enumerate_perfect_matchings(graph), key=verify.matching_key
        )
    )
    assert len(matchings) == 254

    sites = tuple(
        record
        for record in base.facial_sites(graph, faces, frozenset())
        if frozenset(record["selected"]) == verify.SITE
    )
    assert len(sites) == 1
    site = sites[0]
    _face, orientation, short_edge = verify.oriented_short_gap(faces, site)
    assert orientation == (21, 11, 25, 3)
    assert short_edge == edge(3, 21)

    child, child_faces, local = base.expand_on_face(graph, faces, site)
    child_matchings = tuple(base.enumerate_perfect_matchings(child))
    assert len(child_matchings) == 528

    site_vertices = {
        vertex for item in verify.SITE for vertex in item
    }
    u, v, x, y = orientation
    crossed = frozenset(
        (frozenset((u, x)), frozenset((v, y)))
    )
    uncrossed = frozenset(
        (frozenset((u, y)), frozenset((v, x)))
    )

    counts = Counter()
    examples = {}
    state11 = tuple(item for item in matchings if state(item) == (1, 1))
    others = tuple(item for item in matchings if state(item) != (1, 1))
    for matching11 in state11:
        image11 = verify.direct_xvx_lift(
            matching11, child, local, short_edge
        )
        for other in others:
            if base.difference_component_count(matching11, other) != 1:
                continue
            other_state = state(other)
            image_other = canonical_lift(other, child, local)
            child_components = base.difference_component_count(
                image11, image_other
            )
            key = f"11-{other_state[0]}{other_state[1]}"
            if other_state == (0, 0):
                pairing = deleted_pairing(
                    matching11, other, orientation
                )
                assert pairing in (crossed, uncrossed)
                short_in_other = short_edge in other
                expected = 1 if short_in_other or pairing == crossed else 2
                assert child_components == expected
                subtype = (
                    "h-in-00"
                    if short_in_other
                    else "crossed"
                    if pairing == crossed
                    else "uncrossed-h-absent"
                )
                key += f"/{subtype}"
            else:
                assert child_components == 1
            counts[key] += 1

            decoration = first_legal_decoration(
                graph, faces, matching11, other, site_vertices
            )
            if decoration is None or key in examples:
                continue
            root, forced, gate = decoration
            assert base.is_root_target(
                graph, matching11, root, forced
            )
            assert base.is_root_target(graph, other, root, forced)
            assert (gate in matching11) != (gate in other)
            assert base.is_root_target(child, image11, root, forced)
            assert base.is_root_target(child, image_other, root, forced)
            assert base.legal_wide_arcs(
                child_faces, root, forced, gate
            )
            examples[key] = {
                "matching11_index": matchings.index(matching11),
                "other_index": matchings.index(other),
                "root": root,
                "forced_gate": forced,
                "surviving_gate": gate,
                "child_components": child_components,
            }

    expected_counts = Counter(
        {
            "11-10": 248,
            "11-01": 392,
            "11-00/h-in-00": 652,
            "11-00/uncrossed-h-absent": 406,
        }
    )
    assert counts == expected_counts
    assert set(examples) == set(expected_counts)
    bad_key = "11-00/uncrossed-h-absent"
    assert examples[bad_key] == {
        "matching11_index": 58,
        "other_index": 210,
        "root": edge(6, 16),
        "forced_gate": edge(8, 19),
        "surviving_gate": edge(0, 13),
        "child_components": 2,
    }

    root = examples[bad_key]["root"]
    forced = examples[bad_key]["forced_gate"]
    gate = examples[bad_key]["surviving_gate"]
    parent_fibre = tuple(
        item
        for item in matchings
        if base.is_root_target(graph, item, root, forced)
    )
    _p0, _p1, parent_bonds = verify.bond_graph(parent_fibre, gate)
    child_fibre = tuple(
        item
        for item in child_matchings
        if base.is_root_target(child, item, root, forced)
    )
    _c0, _c1, child_bonds = verify.bond_graph(child_fibre, gate)
    new_cells = {"R00", "Xuy", "Xvx"}
    supplement = tuple(
        pair
        for pair in child_bonds
        if any(
            base.local_cell(item, local) in new_cells for item in pair
        )
    )
    parent_kill = bool(parent_bonds) and all(
        state(first) == (1, 1) or state(second) == (1, 1)
        for first, second in parent_bonds
    )
    assert len(parent_fibre) == 12
    assert len(parent_bonds) == 13
    assert bond_state_profile(parent_bonds) == {
        "00-00": 2,
        "00-01": 1,
        "00-10": 4,
        "00-11": 1,
        "01-11": 2,
        "10-11": 3,
    }
    assert not parent_kill
    assert len(child_fibre) == 18
    assert len(child_bonds) == 23
    assert len(supplement) == 16

    payload = {
        "scope": "one fixed n=26 graph and one fixed facial site",
        "graph6": verify.GRAPH6,
        "orientation_u_v_x_y": orientation,
        "one_edge_gap": short_edge,
        "parent_perfect_matchings": len(matchings),
        "child_perfect_matchings": len(child_matchings),
        "mixed_pair_counts": dict(sorted(counts.items())),
        "legal_wide_examples": dict(sorted(examples.items())),
        "bad_example_complete_family": {
            "parent_targets": len(parent_fibre),
            "parent_bonds": len(parent_bonds),
            "parent_bond_state_pairs": bond_state_profile(parent_bonds),
            "parent_kill": parent_kill,
            "child_targets": len(child_fibre),
            "child_bonds": len(child_bonds),
            "child_supplement_bonds": len(supplement),
        },
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("ONE_EDGE_GAP_MIXED_BOND_CLASSIFICATION_VERIFIED")


if __name__ == "__main__":
    main()
