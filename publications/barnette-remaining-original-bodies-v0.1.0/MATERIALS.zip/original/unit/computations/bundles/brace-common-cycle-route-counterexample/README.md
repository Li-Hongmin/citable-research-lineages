# Plane-brace common-cycle route counterexample

This bundle verifies the explicit graph in
[Note 135](../../../notes/135-a-plane-brace-common-cycle-counterexample-leaves-rooted-cell-restricted-cyclability.md).

The program independently checks that the 18-vertex parent is simple,
cubic, bipartite, planar and 2-extendable; that the selected perfect
matchings differ on one gate-changing alternating square while both contain
the two cofacial site edges; that none of the 16 simple alternating cycles
for the fixed matching contains both site edges and the gate; and that the
22-vertex standard expansion is cubic, bipartite and 2-extendable.

Run from the project root:

```bash
python3 units/barnette/computations/bundles/brace-common-cycle-route-counterexample/verify_brace_common_cycle_route_counterexample.py
```

The final status is

```text
PLANE_CUBIC_BRACE_COMMON_CYCLE_ROUTE_COUNTEREXAMPLE_VERIFIED
```

The verifier uses only the Python standard library.  Its scope is the
explicit route counterexample; it does not test root labels or refute the
rooted split-bond lemma.

Frozen environment and source identity:

```text
Python 3.14.6
SHA256 4b6eb70649e492318d07a3b0c5cf92a332031dfad83c6a82888e3d7cc118ca11
```
