#!/usr/bin/env python3
"""Verify the Note 135 route counterexample using only the standard library."""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations
import json


def edge(u: str, v: str) -> tuple[str, str]:
    assert u != v
    return tuple(sorted((u, v)))


def is_perfect_matching(
    vertices: set[str], edges: set[tuple[str, str]], matching: set[tuple[str, str]]
) -> bool:
    if not matching <= edges or 2 * len(matching) != len(vertices):
        return False
    degree = Counter(v for e in matching for v in e)
    return all(degree[v] == 1 for v in vertices)


def residual_has_perfect_matching(
    vertices: set[str],
    edges: set[tuple[str, str]],
    x_part: set[str],
    forced: tuple[tuple[str, str], tuple[str, str]],
) -> bool:
    used = set(forced[0]) | set(forced[1])
    if len(used) != 4:
        return False
    remaining = vertices - used
    xs = sorted(x_part & remaining)
    ys = remaining - set(xs)
    if len(xs) != len(ys):
        return False

    adjacency: dict[str, list[str]] = {x: [] for x in xs}
    for u, v in edges:
        if u not in remaining or v not in remaining:
            continue
        if u in adjacency:
            adjacency[u].append(v)
        elif v in adjacency:
            adjacency[v].append(u)

    mate: dict[str, str] = {}

    def augment(x: str, seen: set[str]) -> bool:
        for y in adjacency[x]:
            if y in seen:
                continue
            seen.add(y)
            if y not in mate or augment(mate[y], seen):
                mate[y] = x
                return True
        return False

    return all(augment(x, set()) for x in xs)


def is_two_extendable(
    vertices: set[str], edges: set[tuple[str, str]], x_part: set[str]
) -> bool:
    for e, f in combinations(sorted(edges), 2):
        if set(e).isdisjoint(f) and not residual_has_perfect_matching(
            vertices, edges, x_part, (e, f)
        ):
            return False
    return True


def verify_plane_faces(
    vertices: set[str],
    edges: set[tuple[str, str]],
    faces: list[tuple[str, ...]],
) -> None:
    undirected = Counter()
    directed = Counter()
    for face in faces:
        assert len(face) >= 4 and len(set(face)) == len(face)
        for i, u in enumerate(face):
            v = face[(i + 1) % len(face)]
            assert edge(u, v) in edges
            undirected[edge(u, v)] += 1
            directed[(u, v)] += 1
    assert set(undirected) == edges
    assert all(count == 2 for count in undirected.values())
    for u, v in edges:
        assert directed[(u, v)] == 1
        assert directed[(v, u)] == 1
    assert len(vertices) - len(edges) + len(faces) == 2


def matching_digraph_cycles(
    vertices: set[str],
    edges: set[tuple[str, str]],
    x_part: set[str],
    matching: set[tuple[str, str]],
) -> list[frozenset[tuple[str, str]]]:
    matching_at: dict[str, tuple[str, str]] = {}
    for m in matching:
        for v in m:
            matching_at[v] = m

    arcs: dict[tuple[str, str], list[tuple[tuple[str, str], tuple[str, str]]]] = defaultdict(list)
    for e in edges - matching:
        u, v = e
        x, y = (u, v) if u in x_part else (v, u)
        arcs[matching_at[x]].append((matching_at[y], e))

    cycles: set[frozenset[tuple[str, str]]] = set()
    for start in sorted(matching):
        path_vertices = [start]
        path_arcs: list[tuple[str, str]] = []

        def dfs(current: tuple[str, str]) -> None:
            for nxt, actual_edge in arcs[current]:
                if nxt == start and len(path_vertices) >= 2:
                    cycles.add(frozenset(path_vertices + path_arcs + [actual_edge]))
                elif nxt not in path_vertices:
                    path_vertices.append(nxt)
                    path_arcs.append(actual_edge)
                    dfs(nxt)
                    path_arcs.pop()
                    path_vertices.pop()

        dfs(start)
    return sorted(cycles, key=lambda c: (len(c), sorted(c)))


def is_single_cycle(edge_set: set[tuple[str, str]]) -> bool:
    adjacency: dict[str, set[str]] = defaultdict(set)
    for u, v in edge_set:
        adjacency[u].add(v)
        adjacency[v].add(u)
    if not adjacency or any(len(ns) != 2 for ns in adjacency.values()):
        return False
    start = next(iter(adjacency))
    seen = {start}
    stack = [start]
    while stack:
        u = stack.pop()
        for v in adjacency[u]:
            if v not in seen:
                seen.add(v)
                stack.append(v)
    return len(seen) == len(adjacency)


def build_parent() -> tuple[
    set[str], set[tuple[str, str]], set[str], set[str], list[tuple[str, ...]]
]:
    labels = [f"{s}{i}" for s in "abc" for i in range(3)]
    vertices = {f"X{v}" for v in labels} | {f"Y{v}" for v in labels}
    x_part = {v for v in vertices if v.startswith("X")}
    y_part = vertices - x_part

    arcs: list[tuple[str, str]] = []
    for s in "ab":
        arcs.extend((f"{s}{i}", f"{s}{(i + 1) % 3}") for i in range(3))
    for i in range(3):
        arcs.extend(
            [
                (f"a{i}", f"c{i}"),
                (f"c{i}", f"a{i}"),
                (f"b{i}", f"c{i}"),
                (f"c{i}", f"b{i}"),
            ]
        )

    edges = {edge(f"X{v}", f"Y{v}") for v in labels}
    edges |= {edge(f"X{u}", f"Y{v}") for u, v in arcs}

    faces: list[tuple[str, ...]] = [
        ("Xa0", "Ya1", "Xa1", "Ya2", "Xa2", "Ya0"),
        ("Xb0", "Yb0", "Xb2", "Yb2", "Xb1", "Yb1"),
    ]
    for i in range(3):
        j = (i + 1) % 3
        faces.extend(
            [
                (f"Xa{i}", f"Ya{i}", f"Xc{i}", f"Yc{i}"),
                (f"Xb{i}", f"Yc{i}", f"Xc{i}", f"Yb{i}"),
                (f"Xa{i}", f"Yc{i}", f"Xb{i}", f"Yb{j}", f"Xc{j}", f"Ya{j}"),
            ]
        )
    return vertices, edges, x_part, y_part, faces


def main() -> None:
    vertices, edges, x_part, y_part, faces = build_parent()
    assert len(vertices) == 18 and len(edges) == 27
    assert all(u != v for u, v in edges) and len(edges) == len(set(edges))
    assert all((u in x_part) != (v in x_part) for u, v in edges)
    degrees = Counter(v for e in edges for v in e)
    assert all(degrees[v] == 3 for v in vertices)
    verify_plane_faces(vertices, edges, faces)
    assert is_two_extendable(vertices, edges, x_part)

    matching = {
        edge("Xa0", "Ya0"),
        edge("Xa1", "Ya1"),
        edge("Xa2", "Ya2"),
        edge("Xb0", "Yb0"),
        edge("Xb1", "Yb1"),
        edge("Xc0", "Yc0"),
        edge("Xc1", "Yc1"),
        edge("Xb2", "Yc2"),
        edge("Xc2", "Yb2"),
    }
    site_p = edge("Xa1", "Ya1")
    site_q = edge("Xa2", "Ya2")
    gate = edge("Xc2", "Yc2")
    gate_cycle = {
        edge("Xb2", "Yc2"),
        edge("Xc2", "Yb2"),
        edge("Xb2", "Yb2"),
        gate,
    }
    second_matching = matching ^ gate_cycle
    assert is_perfect_matching(vertices, edges, matching)
    assert is_perfect_matching(vertices, edges, second_matching)
    assert matching ^ second_matching == gate_cycle
    assert is_single_cycle(gate_cycle) and len(gate_cycle) == 4
    assert gate in gate_cycle and site_p not in gate_cycle and site_q not in gate_cycle
    assert site_p in second_matching and site_q in second_matching

    alternating_cycles = matching_digraph_cycles(vertices, edges, x_part, matching)
    assert any(gate in c and site_p not in c and site_q not in c for c in alternating_cycles)
    assert any(site_p in c and site_q in c for c in alternating_cycles)
    assert not any(gate in c and site_p in c and site_q in c for c in alternating_cycles)

    child_vertices = set(vertices) | {"PA", "PB", "PC", "PD"}
    child_x = set(x_part) | {"PB", "PD"}
    child_y = set(y_part) | {"PA", "PC"}
    child_edges = set(edges) - {site_p, site_q}
    child_edges |= {
        edge("Xa1", "PA"),
        edge("PA", "PB"),
        edge("PB", "Ya1"),
        edge("Xa2", "PC"),
        edge("PC", "PD"),
        edge("PD", "Ya2"),
        edge("PA", "PD"),
        edge("PB", "PC"),
    }
    assert len(child_vertices) == 22 and len(child_edges) == 33
    assert all((u in child_x) != (v in child_x) for u, v in child_edges)
    child_degrees = Counter(v for e in child_edges for v in e)
    assert all(child_degrees[v] == 3 for v in child_vertices)
    assert is_two_extendable(child_vertices, child_edges, child_x)

    result = {
        "status": "PLANE_CUBIC_BRACE_COMMON_CYCLE_ROUTE_COUNTEREXAMPLE_VERIFIED",
        "parent": {
            "vertices": len(vertices),
            "edges": len(edges),
            "faces": len(faces),
            "simple": True,
            "cubic": True,
            "bipartite": True,
            "plane_face_certificate": True,
            "two_extendable": True,
        },
        "matching_pair": {
            "both_perfect": True,
            "symmetric_difference_is_single_C4": True,
            "gate_in_difference": True,
            "site_avoided_by_difference": True,
        },
        "fixed_matching_cycles": {
            "count": len(alternating_cycles),
            "gate_cycle_avoiding_site_exists": True,
            "site_common_cycle_exists": True,
            "site_and_gate_common_cycle_exists": False,
        },
        "child": {
            "vertices": len(child_vertices),
            "edges": len(child_edges),
            "cubic": True,
            "bipartite": True,
            "two_extendable": True,
        },
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
