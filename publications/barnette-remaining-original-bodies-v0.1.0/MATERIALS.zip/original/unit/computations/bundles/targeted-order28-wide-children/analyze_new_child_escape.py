#!/usr/bin/env python3
"""Diagnose the first wide-wide two-site inheritance failure."""

from __future__ import annotations

from itertools import product
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CHILD_SEARCH = HERE / "search_targeted_children.py"

PARENT_GRAPH6 = "W???????????w?s?P_BC?I_?L??d??`_?@g??R??Gg??B_?"
OP_Z = 1
OP_ROTATION = (2, 7, 9, 12, 11, 6, 3, 0)
OP_GATE_INDICES = (3, 7)
QUERY_Z = 8
QUERY_GATE_VERTICES = (5, 10)
ROOT = (11, 13)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


children = load_module(CHILD_SEARCH, "new_child_escape_source")
order24 = children.order24
lift = children.lift
edge = order24.edge


def profile_record(profile):
    return {
        "nae": profile[0],
        "components": profile[1],
        "cycle_rank": profile[2],
        "root_on_cycle": profile[3],
        "target": lift.is_target_profile(profile),
    }


def main():
    primal = nx.from_graph6_bytes(PARENT_GRAPH6.encode())
    planar, embedding = nx.check_planarity(primal)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    faces = order24.source_bundle.plane_faces(primal, embedding)
    reduced, rotations = lift.dual_from_primal_faces(primal, faces)
    reduced_faces = lift.verify_reduced_triangulation(reduced)
    assert rotations[OP_Z] == OP_ROTATION
    child, locals_, left_arc, right_arc = lift.split_vertex(
        reduced, OP_Z, OP_ROTATION, *OP_GATE_INDICES
    )
    child_faces = lift.expanded_triangulation_faces(child)
    assert child_faces is not None
    root = edge(*ROOT)

    parent_family = lift.target_families(reduced, reduced_faces)[0][root]
    parent_vertices = tuple(sorted(reduced))
    parent_colours = tuple(
        lift.decode_colouring(parent_vertices, item) for item in parent_family
    )
    parent_records = []
    for index, colour in enumerate(parent_colours):
        op_gate_count = sum(
            colour[OP_ROTATION[position]] == colour[OP_Z]
            for position in OP_GATE_INDICES
        )
        query_gate_count = sum(
            colour[gate] == colour[QUERY_Z]
            for gate in QUERY_GATE_VERTICES
        )
        fixed = {vertex: value for vertex, value in colour.items() if vertex != OP_Z}
        rows = []
        for bits in product((0, 1), repeat=3):
            candidate = {**fixed, **dict(zip(locals_, bits, strict=True))}
            if lift.is_target_profile(
                lift.rooted_profile(child, child_faces, candidate, root)
            ):
                rows.append("".join(str(bit ^ colour[OP_Z]) for bit in bits))
        parent_records.append(
            {
                "parent_index": index,
                "operation_gate_count": op_gate_count,
                "query_gate_count": query_gate_count,
                "lift_rows_at_operation": rows,
            }
        )

    child_family = lift.target_families(child, child_faces)[0][root]
    child_vertices = tuple(sorted(child))
    child_colours = tuple(
        lift.decode_colouring(child_vertices, item) for item in child_family
    )
    child_records = []
    for index, colour in enumerate(child_colours):
        query_gate_count = sum(
            colour[gate] == colour[QUERY_Z] for gate in QUERY_GATE_VERTICES
        )
        contractions = []
        for contracted_bit in (0, 1):
            contracted = {
                vertex: value
                for vertex, value in colour.items()
                if vertex not in locals_
            }
            contracted[OP_Z] = contracted_bit
            profile = lift.rooted_profile(
                reduced, reduced_faces, contracted, root
            )
            matching_parent_indices = []
            for parent_index, parent_colour in enumerate(parent_colours):
                if all(
                    contracted[vertex] ^ parent_colour[vertex]
                    == contracted[OP_Z] ^ parent_colour[OP_Z]
                    for vertex in parent_vertices
                ):
                    matching_parent_indices.append(parent_index)
            contractions.append(
                {
                    "contracted_bit": contracted_bit,
                    "profile": profile_record(profile),
                    "matching_parent_indices_up_to_complement": matching_parent_indices,
                }
            )
        child_records.append(
            {
                "child_index": index,
                "query_gate_count": query_gate_count,
                "local_bits_left_right_centre": tuple(
                    colour[vertex] for vertex in locals_
                ),
                "contractions": contractions,
            }
        )

    print(
        json.dumps(
            {
                "parent_graph6": PARENT_GRAPH6,
                "operation": {
                    "split_vertex": OP_Z,
                    "rotation": OP_ROTATION,
                    "gate_indices": OP_GATE_INDICES,
                    "left_arc": left_arc,
                    "right_arc": right_arc,
                    "locals": locals_,
                },
                "query": {
                    "split_vertex": QUERY_Z,
                    "gate_vertices": QUERY_GATE_VERTICES,
                    "root": root,
                },
                "parent_family_size": len(parent_records),
                "parent_family": parent_records,
                "child_family_size": len(child_records),
                "child_query_neutral_count": sum(
                    record["query_gate_count"] <= 1
                    for record in child_records
                ),
                "child_query_neutral_records": [
                    record
                    for record in child_records
                    if record["query_gate_count"] <= 1
                ],
                "child_all_records": child_records,
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
