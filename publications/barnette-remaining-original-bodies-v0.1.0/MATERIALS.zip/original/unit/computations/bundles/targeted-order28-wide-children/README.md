# Targeted order-28 wide children and non-descending neutral escapes

This bundle follows three extremal order-24 parents through every legal
one-step C4 expansion.  It is a bounded construction-family theorem, not a
complete order-28 census.

The 196 legal parent operations produce 190 distinct labelled order-28
children.  Across all 2,724 legal wide child splits, 90,896 nonempty target
families and 1,573,984 target instances, every family contains a neutral
target using at most one gate.  Among 162,492 double-gate targets, the
minimum number of alternating-cycle components to a neutral target in the
same family is one for 153,638 targets and two for 8,854 targets.

The focused non-descent witness is structurally sharper.  Its parent family
has five targets; the operation-neutral and query-neutral subsets are
disjoint.  The child family has eleven targets, six query-neutral, and none
of those six contracts under either colour of the removed vertex to a
parent target.  The NAE contractions instead have cycle ranks 0, 1, 2 or 3;
the rank-one contraction has the root off its unique cycle.

## Contents

- `search_targeted_children.py` covers the three specified one-step
  construction families.
- `targeted_children.json` is its accepted output.
- `profile_neutral_cycle_distance.py` computes the exact one/two-cycle
  selector distances.
- `neutral_cycle_distance.json` is its accepted output.
- `analyze_new_child_escape.py` reconstructs the non-descending child
  escape.
- `new_child_escape.json` is the frozen focused witness.

## Reproduction

From the AIMath project root:

    task_run_dir=$(mktemp -d)

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/targeted-order28-wide-children/search_targeted_children.py \
      --output "$task_run_dir/children.json"

    cmp "$task_run_dir/children.json" \
      units/barnette/computations/bundles/targeted-order28-wide-children/targeted_children.json

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/targeted-order28-wide-children/profile_neutral_cycle_distance.py \
      --output "$task_run_dir/distance.json"

    cmp "$task_run_dir/distance.json" \
      units/barnette/computations/bundles/targeted-order28-wide-children/neutral_cycle_distance.json

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/targeted-order28-wide-children/analyze_new_child_escape.py \
      > "$task_run_dir/escape.json"

    cmp "$task_run_dir/escape.json" \
      units/barnette/computations/bundles/targeted-order28-wide-children/new_child_escape.json

Required success statuses are
`targeted_one_step_order28_route_closed` and
`distance_two_escape_holds_in_targeted_order28_children`.

All graph, brace, split, target-family, gate-load, symmetric-difference and
contraction-profile checks are exact.  The three parents are selected
extremal examples, not an isomorph-free order-28 source.
