#!/usr/bin/env python3
"""Test distance-two gate escape in the targeted order-28 children."""

from __future__ import annotations

from collections import Counter
from itertools import combinations
import argparse
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CHILD_SEARCH = HERE / "search_targeted_children.py"


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


children = load_module(CHILD_SEARCH, "targeted_distance_children")
order24 = children.order24
analyse = children.analyse
lift = children.lift
edge = order24.edge


def cycle_count(first, second) -> int:
    difference = first ^ second
    if not difference:
        return 0
    graph = nx.Graph()
    graph.add_edges_from(difference)
    assert all(degree == 2 for _, degree in graph.degree())
    return nx.number_connected_components(graph)


def search() -> dict[str, object]:
    totals = Counter()
    distance_histogram = Counter()
    first_failure = None

    for parent_graph6 in children.PARENTS:
        seen_labelled_graph6 = set()
        for child_record in children.legal_children(parent_graph6):
            child_graph6 = child_record["child_graph6"]
            if child_graph6 in seen_labelled_graph6:
                continue
            seen_labelled_graph6.add(child_graph6)
            totals["tested_labelled_children"] += 1

            primal = child_record["child"]
            primal_faces = child_record["child_faces"]
            reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
            reduced_faces = lift.verify_reduced_triangulation(reduced)
            split_counts = Counter()
            splits = analyse.legal_wide_splits(reduced, rotations, split_counts)
            totals["legal_wide_splits"] += len(splits)
            families = lift.target_families(reduced, reduced_faces)[0]
            vertices = tuple(sorted(reduced))
            dual_to_primal = order24.primal_edge_by_dual_edge(
                primal, primal_faces
            )

            cache = {}
            for root, encoded_family in families.items():
                colours = tuple(
                    lift.decode_colouring(vertices, encoded)
                    for encoded in encoded_family
                )
                matchings = tuple(
                    order24.matching_from_colour(
                        primal, reduced, dual_to_primal, colour
                    )
                    for colour in colours
                )
                distances = {}
                for first, second in combinations(range(len(matchings)), 2):
                    distances[first, second] = cycle_count(
                        matchings[first], matchings[second]
                    )
                cache[root] = colours, matchings, distances

            for split in splits:
                z = int(split["z"])
                gates = (
                    dual_to_primal[edge(z, int(split["first_gate"]))],
                    dual_to_primal[edge(z, int(split["second_gate"]))],
                )
                for root, (_colours, matchings, distances) in cache.items():
                    if z in root:
                        continue
                    totals["wide_interfaces"] += 1
                    gate_counts = tuple(
                        sum(gate in matching for gate in gates)
                        for matching in matchings
                    )
                    neutral = tuple(
                        index for index, count in enumerate(gate_counts)
                        if count <= 1
                    )
                    assert neutral
                    for index, count in enumerate(gate_counts):
                        if count <= 1:
                            continue
                        totals["wide_double_gate_targets"] += 1
                        minimum = min(
                            distances[tuple(sorted((index, other)))]
                            for other in neutral
                        )
                        distance_histogram[minimum] += 1
                        if minimum <= 2:
                            continue
                        first_failure = {
                            "parent_graph6": parent_graph6,
                            "parent_operation": child_record["parent_operation"],
                            "child_graph6": child_graph6,
                            "split_vertex": z,
                            "rotation": split["rotation"],
                            "gate_indices": (
                                split["first_index"], split["second_index"]
                            ),
                            "gate_vertices": (
                                split["first_gate"], split["second_gate"]
                            ),
                            "primal_gates": gates,
                            "closed_arc_cardinalities": (
                                split["left_size"], split["right_size"]
                            ),
                            "dual_root": root,
                            "primal_root": dual_to_primal[root],
                            "target_index": index,
                            "target_matching": sorted(matchings[index]),
                            "family_size": len(matchings),
                            "gate_counts": gate_counts,
                            "neutral_indices": neutral,
                            "neutral_distances": {
                                str(other): distances[
                                    tuple(sorted((index, other)))
                                ]
                                for other in neutral
                            },
                        }
                        break
                    if first_failure is not None:
                        break
                if first_failure is not None:
                    break
            if totals["tested_labelled_children"] % 25 == 0:
                print(
                    json.dumps(
                        {
                            "tested_children": totals[
                                "tested_labelled_children"
                            ],
                            "double_gate_targets": totals[
                                "wide_double_gate_targets"
                            ],
                            "distance_histogram": dict(
                                sorted(distance_histogram.items())
                            ),
                        },
                        sort_keys=True,
                    ),
                    flush=True,
                )
            if first_failure is not None:
                break
        if first_failure is not None:
            break

    return {
        "status": (
            "actual_targeted_order28_distance_two_counterexample"
            if first_failure is not None
            else "distance_two_escape_holds_in_targeted_order28_children"
        ),
        "scope": {
            "parents": children.PARENTS,
            "children": "every legal one-step C4 child, with exact labelled duplicate removal",
            "interfaces": "every legal wide split and nonempty unchanged-root family",
            "not_claimed": "complete order-28 census or arbitrary-order theorem",
        },
        "counts_before_stop": dict(sorted(totals.items())),
        "minimum_cycle_distance_histogram": {
            str(key): value for key, value in sorted(distance_histogram.items())
        },
        "first_failure": first_failure,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    payload = search()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if args.output is not None:
        args.output.write_text(rendered)
        print("certificate", args.output)
    print(json.dumps(payload["counts_before_stop"], sort_keys=True))
    print(json.dumps(payload["minimum_cycle_distance_histogram"], sort_keys=True))
    print(payload["status"].upper())


if __name__ == "__main__":
    main()
