#!/usr/bin/env python3
"""Verify the fixed order-20 double failure for one bad short-gap bond.

The graph, decoration, site, and two parent matchings are literal data from
the already frozen through-order-26 result.  No graph or parameter search is
performed.
"""

from __future__ import annotations

from itertools import combinations

import networkx as nx


GRAPH6 = "S???????F?Y?b?W_CW?F?AW?KO?`_?g_?"


def edge(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


def edge_set(items) -> frozenset[tuple[int, int]]:
    return frozenset(edge(u, v) for u, v in items)


def enumerate_perfect_matchings(graph: nx.Graph):
    def visit(remaining: frozenset[int]):
        if not remaining:
            yield frozenset()
            return
        u = min(remaining)
        for v in graph[u]:
            if v not in remaining:
                continue
            for rest in visit(remaining - {u, v}):
                yield rest | {edge(u, v)}

    return tuple(visit(frozenset(graph.nodes())))


def is_perfect_matching(graph: nx.Graph, matching) -> bool:
    return (
        2 * len(matching) == graph.number_of_nodes()
        and {vertex for item in matching for vertex in item} == set(graph)
        and all(graph.has_edge(*item) for item in matching)
    )


def complement_components(graph: nx.Graph, matching):
    complement = graph.copy()
    complement.remove_edges_from(matching)
    return tuple(
        sorted(
            (frozenset(item) for item in nx.connected_components(complement)),
            key=lambda item: (len(item), tuple(sorted(item))),
        )
    )


def root_target(graph: nx.Graph, matching, root, forced) -> bool:
    if not is_perfect_matching(graph, matching):
        return False
    if root not in matching or forced not in matching:
        return False
    components = complement_components(graph, matching)
    return len(components) == 2 and all(
        len(set(root) & component) == 1 for component in components
    )


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert graph.number_of_nodes() == 20
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    assert nx.node_connectivity(graph) == 3

    matchings = enumerate_perfect_matchings(graph)
    assert len(matchings) == 97
    graph_edges = frozenset(edge(*item) for item in graph.edges())
    for first, second in combinations(graph_edges, 2):
        if set(first) & set(second):
            continue
        assert any(
            first in matching and second in matching for matching in matchings
        )

    root = edge(1, 13)
    forced = edge(2, 10)
    gate = edge(4, 16)
    p = edge(5, 12)
    q = edge(3, 19)
    h = edge(5, 19)

    state00 = edge_set(
        [
            (0, 11),
            (1, 13),
            (2, 10),
            (3, 18),
            (4, 12),
            (5, 17),
            (6, 14),
            (7, 15),
            (8, 16),
            (9, 19),
        ]
    )
    state11 = edge_set(
        [
            (0, 11),
            (1, 13),
            (2, 10),
            (3, 19),
            (4, 16),
            (5, 12),
            (6, 14),
            (7, 15),
            (8, 18),
            (9, 17),
        ]
    )
    assert root_target(graph, state00, root, forced)
    assert root_target(graph, state11, root, forced)
    assert p not in state00 and q not in state00 and h not in state00
    assert p in state11 and q in state11
    assert gate not in state00 and gate in state11

    difference = state00 ^ state11
    difference_graph = nx.Graph()
    difference_graph.add_edges_from(difference)
    assert nx.is_connected(difference_graph)
    assert set(dict(difference_graph.degree()).values()) == {2}

    residual = difference - {p, q}
    residual_graph = nx.Graph()
    residual_graph.add_edges_from(residual)
    residual_components = tuple(nx.connected_components(residual_graph))
    assert len(residual_components) == 2
    paths = tuple(
        frozenset(item for item in residual if set(item) <= set(component))
        for component in residual_components
    )
    path_uy = next(
        path
        for path in paths
        if {5, 19} <= {vertex for item in path for vertex in item}
    )
    path_vx = next(path for path in paths if path != path_uy)
    assert path_uy == edge_set([(5, 17), (9, 17), (9, 19)])
    assert path_vx == edge_set(
        [(12, 4), (4, 16), (16, 8), (8, 18), (18, 3)]
    )
    assert gate not in path_uy and gate in path_vx

    # Parent h-toggle.  It is a genuine state-00 matching containing h, but
    # its complement is one Hamilton circuit rather than two rooted circuits.
    h_toggle = state00 ^ path_uy ^ {h}
    assert is_perfect_matching(graph, h_toggle)
    assert root in h_toggle and forced in h_toggle and h in h_toggle
    assert p not in h_toggle and q not in h_toggle
    assert len(complement_components(graph, h_toggle)) == 1
    assert not root_target(graph, h_toggle, root, forced)

    # Standard C4 expansion with (u,v,x,y)=(5,12,3,19).
    a, b, c, d = 20, 21, 22, 23
    ua, ab, bv = edge(5, a), edge(a, b), edge(b, 12)
    xc, cd, dy = edge(3, c), edge(c, d), edge(d, 19)
    ad, bc = edge(a, d), edge(b, c)
    child = graph.copy()
    child.remove_edges_from((p, q))
    child.add_edges_from((ua, ab, bv, xc, cd, dy, ad, bc))
    assert child.number_of_nodes() == 24
    assert set(dict(child.degree()).values()) == {3}
    assert nx.is_connected(child)
    assert nx.is_bipartite(child)
    assert nx.check_planarity(child)[0]
    assert nx.node_connectivity(child) == 3
    child_matchings = enumerate_perfect_matchings(child)
    assert len(child_matchings) == 202
    child_edges = frozenset(edge(*item) for item in child.edges())
    for first, second in combinations(child_edges, 2):
        if set(first) & set(second):
            continue
        assert any(
            first in matching and second in matching
            for matching in child_matchings
        )

    canonical = state00 | {ad, bc}
    assert root_target(child, canonical, root, forced)
    gate_cycle = path_vx | {bv, bc, xc}
    cycle_graph = nx.Graph()
    cycle_graph.add_edges_from(gate_cycle)
    assert nx.is_connected(cycle_graph)
    assert set(dict(cycle_graph.degree()).values()) == {2}
    assert gate in gate_cycle
    gate_sibling = canonical ^ gate_cycle
    assert is_perfect_matching(child, gate_sibling)
    assert root in gate_sibling and forced in gate_sibling
    assert (gate in gate_sibling) != (gate in canonical)
    assert len(complement_components(child, gate_sibling)) == 3
    assert not root_target(child, gate_sibling, root, forced)

    print(f"parent_perfect_matchings={len(matchings)}")
    print(f"child_perfect_matchings={len(child_matchings)}")
    print("h_toggle_complement_components=1")
    print("gate_sibling_complement_components=3")
    print("ORDER20_H_TOGGLE_GATE_SIBLING_DOUBLE_FAILURE_VERIFIED")


if __name__ == "__main__":
    main()

