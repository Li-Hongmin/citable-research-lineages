#!/usr/bin/env python3
"""Verify a minimal abstract countermodel to short-gap extremality sufficiency.

The two graphs below are the complete parent and child *local* plane
subcubic cores.  Every perfect matching of each core is enumerated.  The
rooted-component signature is deliberately abstract: it records the
number of complement components that a hypothetical common exterior would
produce, but it is not asserted to come from one cubic plane completion.

Thus the certificate separates the local matching/exchange axioms of
Notes 138--139 from the still-missing common-completion constraint.
"""

from __future__ import annotations

from collections import deque
from itertools import combinations


Vertex = str
Edge = tuple[Vertex, Vertex]
Matching = frozenset[Edge]


def edge(first: Vertex, second: Vertex) -> Edge:
    assert first != second
    return tuple(sorted((first, second)))


def graph_edges(raw: tuple[tuple[Vertex, Vertex], ...]) -> frozenset[Edge]:
    return frozenset(edge(*item) for item in raw)


P = edge("u", "v")
Q = edge("x", "y")
H = edge("u", "y")
GATE = edge("t", "u")

P_UY = graph_edges((("u", "t"), ("t", "w"), ("w", "y")))
P_VX = graph_edges((("v", "r"), ("r", "s"), ("s", "x")))

PARENT_EDGES = frozenset({P, Q, H}) | P_UY | P_VX

UA = edge("u", "a")
AB = edge("a", "b")
BV = edge("b", "v")
XC = edge("x", "c")
CD = edge("c", "d")
DY = edge("d", "y")
AD = edge("a", "d")
BC = edge("b", "c")

CHILD_EDGES = (
    PARENT_EDGES - {P, Q}
) | frozenset((UA, AB, BV, XC, CD, DY, AD, BC))


def vertices(edges: frozenset[Edge]) -> frozenset[Vertex]:
    return frozenset(vertex for item in edges for vertex in item)


def adjacency(edges: frozenset[Edge]) -> dict[Vertex, set[Vertex]]:
    result = {vertex: set() for vertex in vertices(edges)}
    for first, second in edges:
        result[first].add(second)
        result[second].add(first)
    return result


def connected(edges: frozenset[Edge]) -> bool:
    graph = adjacency(edges)
    start = next(iter(graph))
    seen = {start}
    queue = deque((start,))
    while queue:
        current = queue.popleft()
        for neighbour in graph[current]:
            if neighbour not in seen:
                seen.add(neighbour)
                queue.append(neighbour)
    return seen == set(graph)


def bipartite(edges: frozenset[Edge]) -> bool:
    graph = adjacency(edges)
    colour: dict[Vertex, int] = {}
    for start in graph:
        if start in colour:
            continue
        colour[start] = 0
        queue = deque((start,))
        while queue:
            current = queue.popleft()
            for neighbour in graph[current]:
                if neighbour not in colour:
                    colour[neighbour] = 1 - colour[current]
                    queue.append(neighbour)
                elif colour[neighbour] == colour[current]:
                    return False
    return True


def is_perfect_matching(edges: frozenset[Edge], matching: Matching) -> bool:
    return (
        matching <= edges
        and len(matching) * 2 == len(vertices(edges))
        and {vertex for item in matching for vertex in item} == set(vertices(edges))
    )


def enumerate_perfect_matchings(edges: frozenset[Edge]) -> tuple[Matching, ...]:
    graph = adjacency(edges)
    output: list[Matching] = []

    def visit(remaining: frozenset[Vertex], chosen: tuple[Edge, ...]) -> None:
        if not remaining:
            output.append(frozenset(chosen))
            return
        first = min(remaining)
        for second in sorted(graph[first] & set(remaining)):
            visit(remaining - {first, second}, chosen + (edge(first, second),))

    visit(vertices(edges), ())
    return tuple(sorted(set(output), key=lambda item: tuple(sorted(item))))


def difference_component_count(first: Matching, second: Matching) -> int:
    difference = first ^ second
    if not difference:
        return 0
    graph = adjacency(difference)
    assert set(dict((vertex, len(neighbours)) for vertex, neighbours in graph.items()).values()) == {2}
    unseen = set(graph)
    count = 0
    while unseen:
        count += 1
        start = next(iter(unseen))
        queue = [start]
        unseen.remove(start)
        while queue:
            current = queue.pop()
            for neighbour in graph[current]:
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    queue.append(neighbour)
    return count


def site_state(matching: Matching) -> str:
    return f"{int(P in matching)}{int(Q in matching)}"


def sector(matching: Matching) -> int:
    return int(GATE in matching)


def bonds(fibre: frozenset[Matching]) -> frozenset[frozenset[Matching]]:
    return frozenset(
        frozenset((first, second))
        for first, second in combinations(fibre, 2)
        if sector(first) != sector(second)
        and difference_component_count(first, second) == 1
    )


def main() -> None:
    # The parent is an 8-cycle plus the short facial chord h=uy.  It is a
    # connected plane bipartite subcubic graph.  The named common face is
    # u-v-r-s-x-y-u; its two selected edges are p=uv and q=xy.
    for graph in (PARENT_EDGES, CHILD_EDGES):
        assert connected(graph)
        assert bipartite(graph)
        assert max(map(len, adjacency(graph).values())) <= 3

    parent_matchings = frozenset(enumerate_perfect_matchings(PARENT_EDGES))
    child_matchings = frozenset(enumerate_perfect_matchings(CHILD_EDGES))
    assert len(parent_matchings) == 3
    assert len(child_matchings) == 8

    matching_11 = frozenset((P, Q, edge("r", "s"), edge("t", "w")))
    matching_00 = frozenset(
        (edge("v", "r"), edge("s", "x"), edge("u", "t"), edge("w", "y"))
    )
    toggle_h = frozenset(
        (edge("v", "r"), edge("s", "x"), edge("t", "w"), H)
    )
    assert parent_matchings == {matching_11, matching_00, toggle_h}
    assert site_state(matching_11) == "11"
    assert site_state(matching_00) == site_state(toggle_h) == "00"
    assert H not in matching_00 and H in toggle_h
    assert sector(matching_11) == 0 and sector(matching_00) == 1
    assert difference_component_count(matching_11, matching_00) == 1
    assert matching_00 ^ toggle_h == P_UY | {H}
    assert difference_component_count(matching_00, toggle_h) == 1
    assert difference_component_count(matching_11, toggle_h) == 1

    canonical_00 = matching_00 | {AD, BC}
    phi_11 = (matching_11 - {P, Q}) | {H, AD, BV, XC}
    sibling_uy = canonical_00 ^ (P_UY | {UA, AD, DY})
    sibling_vx = canonical_00 ^ (P_VX | {BV, BC, XC})
    for matching in (canonical_00, phi_11, sibling_uy, sibling_vx):
        assert matching in child_matchings
        assert is_perfect_matching(CHILD_EDGES, matching)

    assert sector(canonical_00) == 1
    assert sector(phi_11) == sector(sibling_uy) == 0
    assert sector(sibling_vx) == 1
    assert difference_component_count(canonical_00, phi_11) == 2
    assert difference_component_count(canonical_00, sibling_uy) == 1
    assert difference_component_count(canonical_00, sibling_vx) == 1

    # Abstract global complement signatures.  "2+sep" means exactly two
    # labelled complement components with the root endpoints separated.
    # Every object has the inherited root and forced edge in the omitted
    # common exterior incidence block.
    parent_signature = {
        matching_11: "2+sep",
        matching_00: "2+sep",
        toggle_h: "3",
    }
    child_signature = {matching: "3" for matching in child_matchings}
    child_signature[canonical_00] = "2+sep"
    child_signature[phi_11] = "2+sep"

    parent_fibre = frozenset(
        matching for matching in parent_matchings
        if parent_signature[matching] == "2+sep"
    )
    child_fibre = frozenset(
        matching for matching in child_matchings
        if child_signature[matching] == "2+sep"
    )
    assert parent_fibre == {matching_11, matching_00}
    assert child_fibre == {canonical_00, phi_11}

    parent_bonds = bonds(parent_fibre)
    assert parent_bonds == {frozenset((matching_11, matching_00))}
    assert all(
        {site_state(item) for item in bond} == {"11", "00"}
        and all(H not in item for item in bond if site_state(item) == "00")
        for bond in parent_bonds
    )

    # The complete abstract child fibre has no bond at all.  In particular
    # it has no bond incident with Xuy, Xvx, or R00.
    assert not bonds(child_fibre)
    assert child_signature[sibling_uy] == child_signature[sibling_vx] == "3"

    print("parent_complete_pm_family=3")
    print("child_complete_pm_family=8")
    print("parent_rooted_fibre=2; all_bonds=h-avoiding-11-00")
    print("child_rooted_fibre=2; child_supplement=false")
    print("first_unrealized_layer=common_cubic_plane_rooted-complement_completion")
    print("MINIMAL_EXTREMALITY_ABSTRACT_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()

