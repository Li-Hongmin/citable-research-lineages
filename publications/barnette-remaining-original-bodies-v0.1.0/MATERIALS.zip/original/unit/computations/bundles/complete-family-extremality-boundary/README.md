# Complete-family extremality boundary certificate

This bundle supports the two sharp boundaries in Note 141.

The first verifier reconstructs one fixed order-20 legal-wide plane-brace
fibre and its designated bad short-gap bond.  On that same bond the parent
\(h\)-toggle has a one-component Hamilton complement, while the child
gate-path sibling has three complement components.  Thus neither matching
is rooted.

~~~bash
uv run --python 3.12 --with 'networkx==3.6.1' python \
  units/barnette/computations/bundles/complete-family-extremality-boundary/verify_order20_h_toggle_gate_sibling_double_failure.py
~~~

The final marker is

~~~text
ORDER20_H_TOGGLE_GATE_SIBLING_DOUBLE_FAILURE_VERIFIED
~~~

The second verifier enumerates all three parent and all eight child perfect
matchings of a fixed plane bipartite subcubic six-port core.  It checks the
literal \(h\)-toggle and sibling exchanges and a complete abstract rooted
signature assignment in which the parent has exactly one extreme bond and
the child has no rooted bond.

~~~bash
python3 \
  units/barnette/computations/bundles/complete-family-extremality-boundary/verify_minimal_extremality_countermodel.py
~~~

The final marker is

~~~text
MINIMAL_EXTREMALITY_ABSTRACT_COUNTERMODEL_VERIFIED
~~~

The second object is deliberately not claimed to be a Barnette graph: its
rooted complement signatures have not been realized by one connected cubic
plane completion of the six open ports.  Its purpose is to prove that the
local matching algebra and formal component signatures do not imply the
complete-family statement.  Neither verifier performs graph generation,
order scanning, random search, or a neighbouring-parameter computation.
