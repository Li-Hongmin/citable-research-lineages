#!/usr/bin/env python3
"""Audit the Note 139 extreme short-gap family in frozen data.

The parent universe is exactly the 323 ParentKill hit records already
frozen in the through-order-26 rooted-split-bond bundle.  This script keeps
only one-edge facial-gap sites and reconstructs their complete parent
rooted fibres from the recorded graph/root/gates.  It generates no new
parent, site, fibre decoration, or neighbouring order; for the unique hit
it deterministically reconstructs the child already stored in that record.
"""

from __future__ import annotations

from collections import Counter
from functools import lru_cache
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


Edge = tuple[int, int]
Matching = frozenset[Edge]

HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
CLASSIFIER_PATH = (
    BARNETTE
    / "computations"
    / "bundles"
    / "rooted-split-bond-through26"
    / "classify_through26_nonsquare_kill_cover.py"
)
FROZEN_PATH = CLASSIFIER_PATH.parent / "through26_nonsquare_kill_cover.json"

sys.dont_write_bytecode = True


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


classifier = load_module(CLASSIFIER_PATH, "short_gap_extreme_base")
edge = classifier.edge


def as_edge(value: list[int] | tuple[int, int]) -> Edge:
    return edge(int(value[0]), int(value[1]))


@lru_cache(maxsize=None)
def graph_data(graph6: str):
    graph = nx.from_graph6_bytes(graph6.encode())
    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    faces = classifier.source.plane_faces(graph, embedding)
    classifier.validate_faces(graph, faces)
    matchings = classifier.enumerate_perfect_matchings(graph)
    return graph, faces, matchings


def one_edge_gap(record: dict[str, object], faces) -> Edge | None:
    site = record["site"]
    assert isinstance(site, dict)
    degree = int(site["face_length"])
    first, second = map(int, site["indices"])
    delta = second - first
    if delta == 2:
        gap_index = first + 1
    elif degree - delta == 2:
        gap_index = (second + 1) % degree
    else:
        return None

    face_index = int(site["face_index"])
    face = faces[face_index]
    assert len(face) == degree
    gap = edge(face[gap_index], face[(gap_index + 1) % degree])

    selected = tuple(as_edge(item) for item in site["selected"])
    boundary = classifier.face_edges(face)
    assert selected[0] == boundary[first]
    assert selected[1] == boundary[second]
    assert gap not in selected
    assert len(set(gap) & set(selected[0])) == 1
    assert len(set(gap) & set(selected[1])) == 1
    return gap


def matching_state(matching: Matching, selected: tuple[Edge, Edge]) -> str:
    return "".join("1" if item in matching else "0" for item in selected)


def bond_profile(
    fibre: tuple[Matching, ...],
    surviving_gate: Edge,
    selected: tuple[Edge, Edge],
    short_edge: Edge,
) -> tuple[Counter[str], int]:
    sectors = (
        tuple(item for item in fibre if surviving_gate not in item),
        tuple(item for item in fibre if surviving_gate in item),
    )
    bonds = tuple(
        (first, second)
        for first in sectors[0]
        for second in sectors[1]
        if classifier.difference_component_count(first, second) == 1
    )
    profile: Counter[str] = Counter()
    for first, second in bonds:
        first_state = matching_state(first, selected)
        second_state = matching_state(second, selected)
        assert "11" in (first_state, second_state)
        if first_state == second_state == "11":
            profile["11-11"] += 1
            continue
        other = second if first_state == "11" else first
        other_state = matching_state(other, selected)
        assert other_state in {"10", "01", "00"}
        if other_state == "00":
            suffix = "h-in" if short_edge in other else "h-avoiding"
            profile[f"11-00/{suffix}"] += 1
        else:
            profile[f"11-{other_state}"] += 1
    return profile, len(bonds)


def serial_record(record: dict[str, object], profile: Counter[str]) -> dict:
    site = record["site"]
    assert isinstance(site, dict)
    return {
        "parent_order": record["parent_order"],
        "source_graph6": record["source_graph6"],
        "root": record["root"],
        "forced_gate": record["forced_gate"],
        "surviving_gate": record["surviving_gate"],
        "site": site,
        "parent_fibre_size": record["parent_fibre_size"],
        "parent_bonds": record["parent_crossings"],
        "bond_profile": dict(sorted(profile.items())),
        "child_new_cell_bonds": record["new_cell_crossings"],
        "child_legal_wide_brace": record["child_legal_wide_brace"],
    }


def matching_key(matching: Matching):
    return tuple(sorted(matching))


def serial_matching(matching: Matching) -> list[list[int]]:
    return [list(item) for item in matching_key(matching)]


def explicit_extreme_witness(row: dict[str, object]) -> dict[str, object]:
    """Reconstruct the already recorded child and freeze its two bonds."""

    record = row["record"]
    assert isinstance(record, dict)
    graph6 = str(record["source_graph6"])
    graph, faces, all_matchings = graph_data(graph6)
    root = as_edge(record["root"])
    forced_gate = as_edge(record["forced_gate"])
    surviving_gate = as_edge(record["surviving_gate"])
    short_edge = row["short_edge"]
    assert isinstance(short_edge, tuple)
    site = record["site"]
    assert isinstance(site, dict)
    selected = tuple(as_edge(item) for item in site["selected"])

    parent_fibre = tuple(
        sorted(
            (
                matching
                for matching in all_matchings
                if classifier.is_root_target(
                    graph, matching, root, forced_gate
                )
            ),
            key=matching_key,
        )
    )
    parent_sectors = (
        tuple(
            matching
            for matching in parent_fibre
            if surviving_gate not in matching
        ),
        tuple(
            matching
            for matching in parent_fibre
            if surviving_gate in matching
        ),
    )
    parent_bonds = tuple(
        (first, second)
        for first in parent_sectors[0]
        for second in parent_sectors[1]
        if classifier.difference_component_count(first, second) == 1
    )
    assert len(parent_fibre) == 4
    assert len(parent_bonds) == 2
    assert all(
        {
            matching_state(first, selected),
            matching_state(second, selected),
        }
        == {"00", "11"}
        for first, second in parent_bonds
    )
    assert all(
        short_edge not in (
            first
            if matching_state(first, selected) == "00"
            else second
        )
        for first, second in parent_bonds
    )

    expanded_site = {
        "face_index": int(site["face_index"]),
        "face_length": int(site["face_length"]),
        "indices": tuple(map(int, site["indices"])),
        "selected": selected,
    }
    child, _child_faces, local = classifier.expand_on_face(
        graph, faces, expanded_site
    )
    child_matchings = tuple(
        sorted(classifier.enumerate_perfect_matchings(child), key=matching_key)
    )
    child_fibre = tuple(
        matching
        for matching in child_matchings
        if classifier.is_root_target(child, matching, root, forced_gate)
    )
    child_sectors = (
        tuple(
            matching
            for matching in child_fibre
            if surviving_gate not in matching
        ),
        tuple(
            matching
            for matching in child_fibre
            if surviving_gate in matching
        ),
    )
    child_bonds = tuple(
        (first, second)
        for first in child_sectors[0]
        for second in child_sectors[1]
        if classifier.difference_component_count(first, second) == 1
    )
    new_cells = {"R00", "Xuy", "Xvx"}
    supplements = tuple(
        (first, second)
        for first, second in child_bonds
        if any(
            classifier.local_cell(item, local) in new_cells
            for item in (first, second)
        )
    )
    assert len(child_matchings) == int(record["child_perfect_matchings"])
    assert len(child_fibre) == int(record["child_fibre_size"])
    assert len(child_bonds) == int(record["child_crossings"])
    assert len(supplements) == int(record["new_cell_crossings"]) == 2
    assert all(
        {
            classifier.local_cell(first, local),
            classifier.local_cell(second, local),
        }
        == {"C00", "Xuy"}
        for first, second in supplements
    )

    return {
        "parent_order": graph.number_of_nodes(),
        "child_order": child.number_of_nodes(),
        "source_graph6": graph6,
        "root": list(root),
        "forced_gate": list(forced_gate),
        "surviving_gate": list(surviving_gate),
        "facial_cycle": list(faces[int(site["face_index"])]),
        "selected_edges": [list(item) for item in selected],
        "short_edge_h": list(short_edge),
        "parent_fibre": [
            {
                "index": index,
                "state": matching_state(matching, selected),
                "sector": int(surviving_gate in matching),
                "contains_h": short_edge in matching,
                "matching": serial_matching(matching),
            }
            for index, matching in enumerate(parent_fibre)
        ],
        "parent_bonds": [
            {
                "indices": [
                    parent_fibre.index(first),
                    parent_fibre.index(second),
                ],
                "difference_cycle": serial_matching(first ^ second),
            }
            for first, second in parent_bonds
        ],
        "parent_bond_profile": dict(sorted(row["profile"].items())),
        "child_perfect_matchings": len(child_matchings),
        "child_fibre_size": len(child_fibre),
        "child_supplement_bonds": [
            {
                "cells": [
                    classifier.local_cell(first, local),
                    classifier.local_cell(second, local),
                ],
                "first": serial_matching(first),
                "second": serial_matching(second),
                "difference_cycle": serial_matching(first ^ second),
            }
            for first, second in supplements
        ],
    }


def main() -> None:
    frozen = json.loads(FROZEN_PATH.read_text())
    assert frozen["status"] == "ALL_ELIGIBLE_NONSQUARE_KILL_COVER_HITS_POSITIVE"
    assert len(frozen["hits"]) == 323

    automatic_labels = {
        "11-11",
        "11-10",
        "11-01",
        "11-00/h-in",
    }
    audited = []
    automatic_count_histogram: Counter[int] = Counter()
    by_order: Counter[int] = Counter()

    for record in frozen["hits"]:
        graph6 = str(record["source_graph6"])
        graph, faces, all_matchings = graph_data(graph6)
        short_edge = one_edge_gap(record, faces)
        if short_edge is None:
            continue

        root = as_edge(record["root"])
        forced_gate = as_edge(record["forced_gate"])
        surviving_gate = as_edge(record["surviving_gate"])
        fibre = tuple(
            matching
            for matching in all_matchings
            if classifier.is_root_target(graph, matching, root, forced_gate)
        )
        assert len(fibre) == int(record["parent_fibre_size"])

        site = record["site"]
        assert isinstance(site, dict)
        selected = tuple(as_edge(item) for item in site["selected"])
        assert len(selected) == 2
        profile, bond_count = bond_profile(
            fibre, surviving_gate, selected, short_edge
        )
        assert bond_count == int(record["parent_crossings"])
        assert bond_count > 0
        assert sum(profile.values()) == bond_count
        assert sum(
            profile[label] for label in automatic_labels
        ) > 0 or profile["11-00/h-avoiding"] == bond_count

        automatic_count = sum(profile[label] for label in automatic_labels)
        bad_count = profile["11-00/h-avoiding"]
        row = {
            "record": record,
            "profile": profile,
            "automatic_count": automatic_count,
            "bad_count": bad_count,
            "short_edge": short_edge,
        }
        audited.append(row)
        by_order[int(record["parent_order"])] += 1
        automatic_count_histogram[automatic_count] += 1

    assert len(audited) == 262
    extreme = tuple(row for row in audited if row["automatic_count"] == 0)
    minimum_automatic = min(row["automatic_count"] for row in audited)
    first_extreme_order = min(
        (int(row["record"]["parent_order"]) for row in extreme),
        default=None,
    )

    # Every automatic row is a direct new-cell supplement by Notes 138--139.
    # The frozen child census independently records the complete-family count.
    assert all(int(row["record"]["new_cell_crossings"]) > 0 for row in audited)

    payload = {
        "scope": {
            "input": str(FROZEN_PATH.relative_to(BARNETTE.parents[1])),
            "parentkill_hits": len(frozen["hits"]),
            "one_edge_gap_parentkill_families": len(audited),
            "orders": dict(sorted(by_order.items())),
            "generated_new_parent_graphs_or_sites": False,
            "recorded_child_reconstructed_only_for_extreme_witness": True,
        },
        "extreme_families": len(extreme),
        "first_extreme_order_in_frozen_scope": first_extreme_order,
        "minimum_automatic_bonds": minimum_automatic,
        "automatic_bond_count_histogram": dict(
            sorted(automatic_count_histogram.items())
        ),
        "extreme_witnesses": [
            explicit_extreme_witness(row) for row in extreme
        ],
        "all_have_child_supplement": all(
            int(row["record"]["new_cell_crossings"]) > 0 for row in audited
        ),
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    assert len(extreme) == 1
    assert first_extreme_order == 26
    assert all(
        int(row["record"]["parent_order"]) == 26 for row in extreme
    )
    print("FROZEN_THROUGH26_SHORT_GAP_EXTREME_FAMILY_REALIZED")


if __name__ == "__main__":
    main()

