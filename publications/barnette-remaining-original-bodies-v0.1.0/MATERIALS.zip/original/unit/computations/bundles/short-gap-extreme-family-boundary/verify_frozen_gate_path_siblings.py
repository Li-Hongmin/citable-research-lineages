#!/usr/bin/env python3
"""Test the gate-path sibling for every frozen bad short-gap bond.

Only the 262 one-edge-gap ParentKill records in the already frozen
through-order-26 bundle are used.  For every h-avoiding 11--00 parent bond,
the script flips the canonical C00 child lift along the component of
(M11 triangle N00)-{p,q} containing the surviving gate, closed by the
corresponding three-edge gadget path.  No new parent, site, or order is
generated.
"""

from __future__ import annotations

from collections import Counter
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "verify_frozen_short_gap_extreme_families.py"

sys.dont_write_bytecode = True


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


base = load_module(BASE_PATH, "frozen_short_gap_extreme_base")
classifier = base.classifier
edge = base.edge


def matching_key(matching):
    return tuple(sorted(matching))


def is_perfect_matching(graph: nx.Graph, matching) -> bool:
    return (
        len(matching) * 2 == graph.number_of_nodes()
        and {vertex for item in matching for vertex in item} == set(graph)
        and all(graph.has_edge(*item) for item in matching)
    )


def component_edge_sets(difference, selected):
    residual = frozenset(difference - frozenset(selected))
    graph = nx.Graph()
    graph.add_edges_from(residual)
    components = tuple(nx.connected_components(graph))
    assert len(components) == 2
    return tuple(
        frozenset(
            item
            for item in residual
            if set(item) <= set(component)
        )
        for component in components
    )


def failure_reason(child, matching, root, forced_gate) -> str:
    assert is_perfect_matching(child, matching)
    assert root in matching and forced_gate in matching
    complement = child.copy()
    complement.remove_edges_from(matching)
    components = tuple(nx.connected_components(complement))
    if len(components) != 2:
        return f"complement-components-{len(components)}"
    if not all(
        len(set(root) & component) == 1 for component in components
    ):
        return "root-not-separated"
    raise AssertionError("matching is rooted but was classified as failure")


def child_bond_profile(
    child, child_fibre, surviving_gate, local
) -> tuple[Counter[str], tuple]:
    sectors = (
        tuple(item for item in child_fibre if surviving_gate not in item),
        tuple(item for item in child_fibre if surviving_gate in item),
    )
    bonds = tuple(
        (first, second)
        for first in sectors[0]
        for second in sectors[1]
        if classifier.difference_component_count(first, second) == 1
    )
    profile: Counter[str] = Counter()
    for first, second in bonds:
        cells = sorted(
            (
                classifier.local_cell(first, local),
                classifier.local_cell(second, local),
            )
        )
        profile["-".join(cells)] += 1
    return profile, bonds


def serial_matching(matching):
    return [list(item) for item in matching_key(matching)]


def main() -> None:
    frozen = json.loads(base.FROZEN_PATH.read_text())
    assert len(frozen["hits"]) == 323
    records = sorted(
        frozen["hits"],
        key=lambda record: (
            int(record["parent_order"]),
            str(record["source_graph6"]),
            record["root"],
            record["forced_gate"],
            record["surviving_gate"],
            record["site"]["face_index"],
            record["site"]["indices"],
        ),
    )

    short_gap_records = 0
    bad_bonds = 0
    successes = 0
    failures = []
    success_cells: Counter[str] = Counter()
    failure_reasons: Counter[str] = Counter()
    by_order_bonds: Counter[int] = Counter()
    by_order_failures: Counter[int] = Counter()
    by_order_successes: Counter[int] = Counter()
    records_with_bad_bonds: set[tuple] = set()
    records_with_failures: set[tuple] = set()
    records_with_successes: set[tuple] = set()
    record_profiles: dict[tuple, Counter[str]] = {}

    for record in records:
        graph6 = str(record["source_graph6"])
        graph, faces, all_matchings = base.graph_data(graph6)
        short_edge = base.one_edge_gap(record, faces)
        if short_edge is None:
            continue
        short_gap_records += 1

        root = base.as_edge(record["root"])
        forced_gate = base.as_edge(record["forced_gate"])
        surviving_gate = base.as_edge(record["surviving_gate"])
        site = record["site"]
        assert isinstance(site, dict)
        selected = tuple(base.as_edge(item) for item in site["selected"])
        fibre = tuple(
            sorted(
                (
                    matching
                    for matching in all_matchings
                    if classifier.is_root_target(
                        graph, matching, root, forced_gate
                    )
                ),
                key=matching_key,
            )
        )
        sectors = (
            tuple(
                item for item in fibre if surviving_gate not in item
            ),
            tuple(item for item in fibre if surviving_gate in item),
        )
        bonds = tuple(
            (first, second)
            for first in sectors[0]
            for second in sectors[1]
            if classifier.difference_component_count(first, second) == 1
        )
        assert len(bonds) == int(record["parent_crossings"])
        record_key = (
            record["source_graph6"],
            tuple(record["root"]),
            tuple(record["forced_gate"]),
            tuple(record["surviving_gate"]),
            int(site["face_index"]),
            tuple(site["indices"]),
        )
        profile, profile_bonds = base.bond_profile(
            fibre, surviving_gate, selected, short_edge
        )
        assert profile_bonds == len(bonds)
        record_profiles[record_key] = profile

        expanded_site = {
            "face_index": int(site["face_index"]),
            "face_length": int(site["face_length"]),
            "indices": tuple(map(int, site["indices"])),
            "selected": selected,
        }
        child, child_faces, local = classifier.expand_on_face(
            graph, faces, expanded_site
        )
        ua, ab, bv, xc, cd, dy, ad, bc = local
        first_left = ua[0] if ua[1] not in graph else ua[1]
        # The expansion routine always numbers new vertices above max(graph).
        old_vertices = set(graph)
        first_left = next(vertex for vertex in ua if vertex in old_vertices)
        first_right = next(vertex for vertex in bv if vertex in old_vertices)
        second_left = next(vertex for vertex in xc if vertex in old_vertices)
        second_right = next(vertex for vertex in dy if vertex in old_vertices)
        endpoint_pairs = {
            frozenset((first_left, second_right)): (
                "Xuy",
                frozenset((ua, ad, dy)),
            ),
            frozenset((first_right, second_left)): (
                "Xvx",
                frozenset((bv, bc, xc)),
            ),
        }

        for first, second in bonds:
            first_state = base.matching_state(first, selected)
            second_state = base.matching_state(second, selected)
            if {first_state, second_state} != {"11", "00"}:
                continue
            state00 = first if first_state == "00" else second
            state11 = second if first_state == "00" else first
            if short_edge in state00:
                continue

            bad_bonds += 1
            order = int(record["parent_order"])
            by_order_bonds[order] += 1
            records_with_bad_bonds.add(record_key)
            difference = state11 ^ state00
            paths = component_edge_sets(difference, selected)
            assert surviving_gate in difference
            gate_paths = tuple(
                path for path in paths if surviving_gate in path
            )
            assert len(gate_paths) == 1
            gate_path = gate_paths[0]
            path_vertices = {vertex for item in gate_path for vertex in item}
            path_endpoints = frozenset(
                vertex
                for vertex in (
                    first_left,
                    first_right,
                    second_left,
                    second_right,
                )
                if sum(vertex in item for item in gate_path) == 1
            )
            assert path_endpoints in endpoint_pairs
            target_cell, gadget_path = endpoint_pairs[path_endpoints]

            canonical = frozenset(state00 | frozenset((ad, bc)))
            assert is_perfect_matching(child, canonical)
            assert classifier.is_root_target(
                child, canonical, root, forced_gate
            )
            flip_cycle = frozenset(gate_path | gadget_path)
            cycle_graph = nx.Graph()
            cycle_graph.add_edges_from(flip_cycle)
            assert nx.is_connected(cycle_graph)
            assert set(dict(cycle_graph.degree()).values()) == {2}
            assert surviving_gate in flip_cycle
            sibling = frozenset(canonical ^ flip_cycle)
            assert is_perfect_matching(child, sibling)
            assert classifier.local_cell(sibling, local) == target_cell
            assert (surviving_gate in sibling) != (
                surviving_gate in canonical
            )
            assert classifier.difference_component_count(
                canonical, sibling
            ) == 1

            rooted = classifier.is_root_target(
                child, sibling, root, forced_gate
            )
            if rooted:
                successes += 1
                success_cells[target_cell] += 1
                by_order_successes[order] += 1
                records_with_successes.add(record_key)
                continue

            reason = failure_reason(
                child, sibling, root, forced_gate
            )
            failure_reasons[reason] += 1
            by_order_failures[order] += 1
            records_with_failures.add(record_key)
            failures.append(
                {
                    "record": record,
                    "graph": graph,
                    "faces": faces,
                    "child": child,
                    "child_faces": child_faces,
                    "local": local,
                    "root": root,
                    "forced_gate": forced_gate,
                    "surviving_gate": surviving_gate,
                    "selected": selected,
                    "short_edge": short_edge,
                    "state11": state11,
                    "state00": state00,
                    "canonical": canonical,
                    "sibling": sibling,
                    "target_cell": target_cell,
                    "gate_path": gate_path,
                    "flip_cycle": flip_cycle,
                    "reason": reason,
                }
            )

    assert short_gap_records == 262
    automatic_labels = {
        "11-11",
        "11-10",
        "11-01",
        "11-00/h-in",
    }
    successful_extreme_records = tuple(
        key
        for key in records_with_successes
        if sum(record_profiles[key][label] for label in automatic_labels)
        == 0
        and record_profiles[key]["11-00/h-avoiding"]
        == sum(record_profiles[key].values())
    )
    assert len(records_with_successes) == len(successful_extreme_records) == 1
    assert records_with_successes.isdisjoint(records_with_failures)
    first_failure = None
    if failures:
        failure = failures[0]
        record = failure["record"]
        child = failure["child"]
        root = failure["root"]
        forced_gate = failure["forced_gate"]
        surviving_gate = failure["surviving_gate"]
        local = failure["local"]
        child_matchings = tuple(
            sorted(
                classifier.enumerate_perfect_matchings(child),
                key=matching_key,
            )
        )
        child_fibre = tuple(
            matching
            for matching in child_matchings
            if classifier.is_root_target(
                child, matching, root, forced_gate
            )
        )
        profile, child_bonds = child_bond_profile(
            child, child_fibre, surviving_gate, local
        )
        new_cells = {"R00", "Xuy", "Xvx"}
        supplements = tuple(
            (first, second)
            for first, second in child_bonds
            if any(
                classifier.local_cell(item, local) in new_cells
                for item in (first, second)
            )
        )
        assert len(child_bonds) == int(record["child_crossings"])
        assert len(supplements) == int(record["new_cell_crossings"])
        complement = child.copy()
        complement.remove_edges_from(failure["sibling"])
        failed_components = tuple(
            sorted(
                (tuple(sorted(item)) for item in nx.connected_components(complement)),
                key=lambda item: (len(item), item),
            )
        )
        canonical_index = child_fibre.index(failure["canonical"])
        parent_profile, parent_bond_count = base.bond_profile(
            tuple(
                matching
                for matching in base.graph_data(
                    str(record["source_graph6"])
                )[2]
                if classifier.is_root_target(
                    failure["graph"], matching, root, forced_gate
                )
            ),
            surviving_gate,
            failure["selected"],
            failure["short_edge"],
        )
        assert parent_bond_count == int(record["parent_crossings"])
        first_failure = {
            "parent_order": record["parent_order"],
            "source_graph6": record["source_graph6"],
            "root": list(root),
            "forced_gate": list(forced_gate),
            "surviving_gate": list(surviving_gate),
            "site": record["site"],
            "short_edge": list(failure["short_edge"]),
            "target_cell": failure["target_cell"],
            "failure_reason": failure["reason"],
            "failed_complement_components": [
                list(item) for item in failed_components
            ],
            "parent_fibre_size": record["parent_fibre_size"],
            "parent_bond_profile": dict(sorted(parent_profile.items())),
            "state11": serial_matching(failure["state11"]),
            "state00": serial_matching(failure["state00"]),
            "gate_path": serial_matching(failure["gate_path"]),
            "flip_cycle": serial_matching(failure["flip_cycle"]),
            "failed_sibling": serial_matching(failure["sibling"]),
            "child_fibre_size": len(child_fibre),
            "child_bond_profile": dict(sorted(profile.items())),
            "child_supplement_count": len(supplements),
            "canonical_child_fibre_index": canonical_index,
            "child_supplements": [
                {
                    "fibre_indices": [
                        child_fibre.index(first),
                        child_fibre.index(second),
                    ],
                    "cells": [
                        classifier.local_cell(first, local),
                        classifier.local_cell(second, local),
                    ],
                    "contains_failed_bond_canonical_C00": (
                        failure["canonical"] in (first, second)
                    ),
                    "first": serial_matching(first),
                    "second": serial_matching(second),
                    "difference_cycle": serial_matching(first ^ second),
                }
                for first, second in supplements
            ],
        }

    payload = {
        "scope": {
            "short_gap_parentkill_records": short_gap_records,
            "new_parent_graphs_sites_or_orders": False,
        },
        "h_avoiding_11_00_bonds": bad_bonds,
        "records_with_h_avoiding_11_00_bonds": len(records_with_bad_bonds),
        "by_parent_order": dict(sorted(by_order_bonds.items())),
        "rooted_gate_path_siblings": successes,
        "successful_siblings_by_parent_order": dict(
            sorted(by_order_successes.items())
        ),
        "records_with_successful_siblings": len(records_with_successes),
        "successful_records_are_exact_note139_extreme": (
            len(successful_extreme_records) == len(records_with_successes)
        ),
        "rooted_sibling_cells": dict(sorted(success_cells.items())),
        "failed_gate_path_siblings": len(failures),
        "records_with_failed_siblings": len(records_with_failures),
        "failure_reasons": dict(sorted(failure_reasons.items())),
        "failures_by_parent_order": dict(sorted(by_order_failures.items())),
        "first_failure": first_failure,
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    if failures:
        print("FROZEN_GATE_PATH_SIBLING_HAS_REAL_FAILURE")
    else:
        print("FROZEN_GATE_PATH_SIBLING_SUPPORTED_FOR_ALL_BAD_BONDS")


if __name__ == "__main__":
    main()

