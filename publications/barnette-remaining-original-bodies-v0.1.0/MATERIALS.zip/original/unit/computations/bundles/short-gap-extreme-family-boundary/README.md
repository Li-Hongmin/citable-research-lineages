# Short-gap extreme-family boundary certificate

This bundle supports the fixed finite statements in Note 140.  The
arbitrary-order \(h\)-toggle and gate-path sibling lemmas in that note are
analytic; the scripts here only verify the two sharp realizability boundaries
inside the already frozen rooted-split-bond through-order-26 stratum.

The first verifier reads the 323 frozen ParentKill records, keeps the 262
one-edge-gap records, and proves that exactly one complete parent fibre has
only \(h\)-avoiding \(11\)--\(00\) bonds.  It reconstructs that order-26
fibre and its two nondirect \(C_{00}\)--\(X_{uy}\) child bonds.

~~~bash
uv run --python 3.12 --with 'networkx==3.6.1' python \
  units/barnette/computations/bundles/short-gap-extreme-family-boundary/verify_frozen_short_gap_extreme_families.py
~~~

The final marker is

~~~text
FROZEN_THROUGH26_SHORT_GAP_EXTREME_FAMILY_REALIZED
~~~

The second verifier tests the canonical gate-path sibling for every bad bond
in those same 262 records.  Of 278 bad bonds, only the two bonds in the unique
extreme order-26 fibre retain rooted admission; the other 276 fail because the
child complement has three components.  It freezes an explicit order-20
pointwise counterexample.

~~~bash
uv run --python 3.12 --with 'networkx==3.6.1' python \
  units/barnette/computations/bundles/short-gap-extreme-family-boundary/verify_frozen_gate_path_siblings.py
~~~

The final marker is

~~~text
FROZEN_GATE_PATH_SIBLING_HAS_REAL_FAILURE
~~~

Both scripts depend on the permanent
`rooted-split-bond-through26` bundle.  They generate no graph, site, order,
decoration, or random instance.  The claim that order 26 is first is only for
the frozen root-opposite-square legal-wide stratum, not for all Barnette
graphs or all rooted decorations.
