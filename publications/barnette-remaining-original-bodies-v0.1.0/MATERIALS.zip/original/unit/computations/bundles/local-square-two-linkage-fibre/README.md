# Local-square two-linkage fibre

This bundle verifies the finite classifications used in
[Note 085](../../../notes/085-a-square-forced-gate-reduces-the-other-gate-to-a-two-linkage-fibre.md).
The square-deletion and separated-two-factor bijections are analytic.

The profiler reads only graph representatives and rooted-target interfaces
already frozen in the permanent through-\(26\) bundles.  It invokes no graph
generator.  Run from the AIMath root:

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/local-square-two-linkage-fibre/profile_direct_square_other_gate_escape.py \
      --output units/barnette/computations/bundles/local-square-two-linkage-fibre/direct_square_other_gate_escape_through26.json

The required terminal marker is

    DIRECT_SQUARE_OTHER_GATE_ESCAPE_PROFILED_THROUGH26

The profiler verifies:

1. all \(7\,160\) targets in the \(541\) direct-square occurrences satisfy
   the fixed-pairing spanning-two-path bijection;
2. every family has a single alternating-cycle edge crossing the other gate
   coordinate;
3. the minimum crossing lengths are \(6^{396},10^{132},14^{13}\);
4. arbitrary-source distances are
   \(1^{1881},2^{15},3^1,\infty^{32}\); and
5. no crossing cycle is facial.

The output JSON freezes the aggregate counts.  This is a classification of
the named through-\(26\) corpus, not an order-\(28\) census or a proof of
the arbitrary-order crossing-cycle candidate.
