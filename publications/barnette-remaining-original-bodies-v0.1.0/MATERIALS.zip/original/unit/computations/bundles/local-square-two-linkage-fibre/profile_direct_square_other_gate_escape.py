#!/usr/bin/env python3
"""Profile canonical other-gate escapes for all direct-square coloops through 26.

The script reads only graph6 representatives frozen in the permanent paired
coloop bundle.  It reconstructs every complete rooted-target family at every
legal wide split and restricts to occurrences where exactly one gate is a
restricted coloop and that gate is opposite the root on a 4-cycle.
"""

from __future__ import annotations

from collections import Counter, deque
import argparse
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
BUNDLE = (
    BARNETTE
    / "computations"
    / "bundles"
    / "paired-restricted-gate-coloop-boundary"
)
BASE_SCRIPT = BUNDLE / "classify_existing_single_gate_coloops.py"
sys.dont_write_bytecode = True


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


base = load_module(BASE_SCRIPT, "local_global_direct_square_base")
corpus = base.base
wide = base.wide
lift = base.lift
source = base.source
edge = base.edge


def difference_components(
    graph: nx.Graph,
    first: frozenset[tuple[int, int]],
    second: frozenset[tuple[int, int]],
) -> tuple[tuple[frozenset[tuple[int, int]], int], ...]:
    difference = set(first ^ second)
    assert difference
    subgraph = nx.edge_subgraph(graph, difference)
    result = []
    for vertices in nx.connected_components(subgraph):
        component = subgraph.subgraph(vertices)
        assert set(dict(component.degree()).values()) == {2}
        edges = frozenset(edge(*item) for item in component.edges())
        result.append((edges, len(edges)))
    return tuple(sorted(result, key=lambda item: (item[1], sorted(item[0]))))


def target_exchange_graph(
    graph: nx.Graph,
    matchings: tuple[frozenset[tuple[int, int]], ...],
) -> tuple[nx.Graph, dict[tuple[int, int], tuple[tuple[frozenset[tuple[int, int]], int], ...]]]:
    exchange = nx.Graph()
    exchange.add_nodes_from(range(len(matchings)))
    components = {}
    for first in range(len(matchings)):
        for second in range(first + 1, len(matchings)):
            parts = difference_components(graph, matchings[first], matchings[second])
            components[(first, second)] = parts
            if len(parts) == 1:
                exchange.add_edge(first, second, cycle_length=parts[0][1])
    return exchange, components


def distances_to_set(graph: nx.Graph, targets: set[int]) -> dict[int, int]:
    distances = {target: 0 for target in targets}
    queue = deque(sorted(targets))
    while queue:
        current = queue.popleft()
        for neighbour in graph[current]:
            if neighbour in distances:
                continue
            distances[neighbour] = distances[current] + 1
            queue.append(neighbour)
    return distances


def verify_square_deleted_linkage_image(
    graph: nx.Graph,
    square: tuple[int, int, int, int],
    root: tuple[int, int],
    local_gate: tuple[int, int],
    matching: frozenset[tuple[int, int]],
) -> None:
    """Check the two fixed spanning paths obtained after deleting the square."""

    square_vertices = set(square)
    assert {edge(square[0], square[1]), edge(square[2], square[3])} == {
        root,
        local_gate,
    }
    attachments = {}
    for vertex in square:
        outside = [neighbour for neighbour in graph[vertex] if neighbour not in square_vertices]
        assert len(outside) == 1
        attachments[vertex] = outside[0]
    assert len(set(attachments.values())) == 4

    residual = graph.subgraph(set(graph) - square_vertices).copy()
    residual_matching = set(matching) - {root, local_gate}
    assert all(
        sum(vertex in item for item in residual_matching) == 1 for vertex in residual
    )
    residual.remove_edges_from(residual_matching)
    components = tuple(nx.connected_components(residual))
    assert len(components) == 2
    endpoint_pairs = set()
    for component_vertices in components:
        component = residual.subgraph(component_vertices)
        endpoints = frozenset(
            vertex for vertex, degree in component.degree() if degree == 1
        )
        assert len(endpoints) == 2
        assert all(degree in {1, 2} for _, degree in component.degree())
        endpoint_pairs.add(endpoints)
    assert endpoint_pairs == {
        frozenset((attachments[square[0]], attachments[square[3]])),
        frozenset((attachments[square[1]], attachments[square[2]])),
    }


def freeze_occurrence(
    order: int,
    source_graph6: str,
    primal: nx.Graph,
    primal_faces: tuple[tuple[int, ...], ...],
    split: dict[str, object],
    root: tuple[int, int],
    primal_root: tuple[int, int],
    gates: tuple[tuple[int, int], tuple[int, int]],
    local_index: int,
    square: tuple[int, int, int, int],
    matchings: tuple[frozenset[tuple[int, int]], ...],
    exchange: nx.Graph,
    sources: set[int],
    escapes: set[int],
    distances: dict[int, int],
) -> dict[str, object]:
    return {
        "source_order": order,
        "source_graph6": source_graph6,
        "source_edges": sorted(edge(*item) for item in primal.edges()),
        "source_faces": primal_faces,
        "site": {
            "split_vertex": split["z"],
            "rotation": split["rotation"],
            "gate_indices": (split["first_index"], split["second_index"]),
            "gate_vertices": (split["first_gate"], split["second_gate"]),
            "primal_gates": gates,
            "closed_arc_cardinalities": (
                split["left_size"], split["right_size"]
            ),
        },
        "dual_root": root,
        "primal_root": primal_root,
        "local_forced_gate_index": local_index,
        "local_forced_gate": gates[local_index],
        "other_gate": gates[1 - local_index],
        "root_gate_square": square,
        "complete_family_size": len(matchings),
        "double_gate_indices": sorted(sources),
        "other_gate_omitting_indices": sorted(escapes),
        "source_distance_to_escape": {
            str(index): distances.get(index) for index in sorted(sources)
        },
        "single_cycle_exchange_edges": [
            {
                "indices": (first, second),
                "cycle_length": int(data["cycle_length"]),
            }
            for first, second, data in sorted(exchange.edges(data=True))
        ],
        "complete_family": [sorted(matching) for matching in matchings],
    }


def analyse_graph(order: int, source_graph6: str):
    primal = nx.from_graph6_bytes(source_graph6.encode())
    planar, embedding = nx.check_planarity(primal, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    primal_faces = source.plane_faces(primal, embedding)
    assert lift.verify_brace(primal)
    reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift.verify_reduced_triangulation(reduced)
    splits = wide.legal_wide_splits(reduced, rotations, Counter())
    if not splits:
        return Counter(), {}

    families, _, _ = lift.target_families(reduced, reduced_faces)
    reduced_vertices = tuple(sorted(reduced))
    dual_to_primal = wide.primal_edge_by_dual_edge(primal, primal_faces)
    family_matchings = {}
    for root, encoded_family in families.items():
        colours = tuple(
            lift.decode_colouring(reduced_vertices, encoded)
            for encoded in encoded_family
        )
        family_matchings[root] = tuple(
            wide.matching_from_colour(primal, reduced, dual_to_primal, colour)
            for colour in colours
        )

    counts: Counter[str] = Counter()
    witnesses = {}
    for split in splits:
        z = int(split["z"])
        gates = (
            dual_to_primal[edge(z, int(split["first_gate"]))],
            dual_to_primal[edge(z, int(split["second_gate"]))],
        )
        for root in sorted(families):
            if z in root:
                continue
            matchings = family_matchings[root]
            forced = tuple(all(gate in matching for matching in matchings) for gate in gates)
            primal_root = dual_to_primal[root]
            local_data = tuple(
                base.opposite_on_square(primal, primal_root, gate)
                for gate in gates
            )
            local_indices = tuple(
                index for index, (local, _square) in enumerate(local_data) if local
            )
            if not local_indices:
                continue
            assert len(local_indices) == 1
            local_index = local_indices[0]
            assert forced[local_index]
            _local, square = local_data[local_index]
            assert square is not None
            counts["direct_square_hypothesis_occurrences"] += 1
            if forced[1 - local_index]:
                counts["p_lg_counterexamples"] += 1
                continue
            counts["direct_square_coloop_occurrences"] += 1
            counts[f"family_size_{len(matchings)}"] += 1
            for matching in matchings:
                verify_square_deleted_linkage_image(
                    primal,
                    square,
                    primal_root,
                    gates[local_index],
                    matching,
                )
                counts["square_deleted_two_path_linkage_images"] += 1

            other_gate = gates[1 - local_index]
            sources = {
                index for index, matching in enumerate(matchings) if other_gate in matching
            }
            escapes = set(range(len(matchings))) - sources
            assert escapes
            counts[f"double_target_count_{len(sources)}"] += 1
            counts[f"escape_target_count_{len(escapes)}"] += 1
            if not sources:
                counts["other_gate_absent_from_entire_family"] += 1
                continue

            exchange, parts = target_exchange_graph(primal, matchings)
            distances = distances_to_set(exchange, escapes)
            source_distances = [distances.get(index) for index in sorted(sources)]
            unreachable = sum(distance is None for distance in source_distances)
            counts["double_gate_target_occurrences"] += len(sources)
            counts["double_gate_targets_unreachable_from_escape"] += unreachable
            for distance in source_distances:
                counts[f"source_to_escape_distance_{distance}"] += 1
            if unreachable:
                counts["families_with_unreachable_double_target"] += 1
                witnesses.setdefault(
                    "first_unreachable_double_target",
                    freeze_occurrence(
                        order,
                        source_graph6,
                        primal,
                        primal_faces,
                        split,
                        root,
                        primal_root,
                        gates,
                        local_index,
                        square,
                        matchings,
                        exchange,
                        sources,
                        escapes,
                        distances,
                    ),
                )
            if any(distance == 3 for distance in source_distances):
                witnesses.setdefault(
                    "first_distance_three_double_target",
                    freeze_occurrence(
                        order,
                        source_graph6,
                        primal,
                        primal_faces,
                        split,
                        root,
                        primal_root,
                        gates,
                        local_index,
                        square,
                        matchings,
                        exchange,
                        sources,
                        escapes,
                        distances,
                    ),
                )

            minimum_pair_components = min(
                len(parts[tuple(sorted((source_index, escape_index)))])
                for source_index in sources
                for escape_index in escapes
            )
            counts[
                f"family_minimum_source_escape_difference_components_{minimum_pair_components}"
            ] += 1
            if all(distance == 1 for distance in source_distances):
                counts["every_double_target_has_single_cycle_escape"] += 1
            else:
                witnesses.setdefault(
                    "first_not_every_source_one_step",
                    freeze_occurrence(
                        order,
                        source_graph6,
                        primal,
                        primal_faces,
                        split,
                        root,
                        primal_root,
                        gates,
                        local_index,
                        square,
                        matchings,
                        exchange,
                        sources,
                        escapes,
                        distances,
                    ),
                )
            if any(distance == 1 for distance in source_distances):
                counts["some_double_target_has_single_cycle_escape"] += 1
            else:
                witnesses.setdefault(
                    "first_no_one_step_source",
                    freeze_occurrence(
                        order,
                        source_graph6,
                        primal,
                        primal_faces,
                        split,
                        root,
                        primal_root,
                        gates,
                        local_index,
                        square,
                        matchings,
                        exchange,
                        sources,
                        escapes,
                        distances,
                    ),
                )

            crossing_cycle_lengths = []
            facial_crossing = False
            induced_crossing = False
            face_edge_sets = {
                frozenset(
                    edge(face[index], face[(index + 1) % len(face)])
                    for index in range(len(face))
                )
                for face in primal_faces
            }
            square_vertices = set(square)
            for source_index in sources:
                for escape_index in exchange[source_index]:
                    if escape_index not in escapes:
                        continue
                    data = exchange[source_index][escape_index]
                    counts[
                        f"one_step_escape_cycle_length_{int(data['cycle_length'])}"
                    ] += 1
                    crossing_cycle_lengths.append(int(data["cycle_length"]))
                    difference = matchings[source_index] ^ matchings[escape_index]
                    assert other_gate in difference
                    assert not (square_vertices & set().union(*map(set, difference)))
                    counts["one_step_escapes_vertex_disjoint_from_root_square"] += 1
                    facial_crossing |= frozenset(difference) in face_edge_sets
                    cycle_vertices = set().union(*map(set, difference))
                    induced_crossing |= (
                        primal.subgraph(cycle_vertices).number_of_edges()
                        == len(difference)
                    )
            assert crossing_cycle_lengths
            counts[
                f"family_minimum_crossing_cycle_length_{min(crossing_cycle_lengths)}"
            ] += 1
            counts[
                "families_with_facial_crossing_cycle"
                if facial_crossing
                else "families_without_facial_crossing_cycle"
            ] += 1
            counts[
                "families_with_induced_crossing_cycle"
                if induced_crossing
                else "families_without_induced_crossing_cycle"
            ] += 1
            if not facial_crossing:
                witnesses.setdefault(
                    "first_no_facial_crossing_cycle",
                    freeze_occurrence(
                        order,
                        source_graph6,
                        primal,
                        primal_faces,
                        split,
                        root,
                        primal_root,
                        gates,
                        local_index,
                        square,
                        matchings,
                        exchange,
                        sources,
                        escapes,
                        distances,
                    ),
                )

            if len(tuple(nx.connected_components(exchange))) == 1:
                counts["complete_family_single_cycle_exchange_connected"] += 1
            else:
                counts["complete_family_single_cycle_exchange_disconnected"] += 1
                witnesses.setdefault(
                    "first_disconnected_family",
                    freeze_occurrence(
                        order,
                        source_graph6,
                        primal,
                        primal_faces,
                        split,
                        root,
                        primal_root,
                        gates,
                        local_index,
                        square,
                        matchings,
                        exchange,
                        sources,
                        escapes,
                        distances,
                    ),
                )
    return counts, witnesses


def profile():
    totals: Counter[str] = Counter()
    by_order = {}
    witnesses = {}
    for order, graph6_values in corpus.frozen_graphs().items():
        order_counts: Counter[str] = Counter()
        for source_graph6 in graph6_values:
            counts, local_witnesses = analyse_graph(order, source_graph6)
            order_counts.update(counts)
            totals.update(counts)
            for key, value in local_witnesses.items():
                witnesses.setdefault(key, value)
        by_order[str(order)] = dict(sorted(order_counts.items()))

    assert totals["direct_square_hypothesis_occurrences"] == 541
    assert totals["p_lg_counterexamples"] == 0
    assert totals["direct_square_coloop_occurrences"] == 541
    assert totals["one_step_escapes_vertex_disjoint_from_root_square"] == sum(
        value
        for key, value in totals.items()
        if key.startswith("one_step_escape_cycle_length_")
    )
    return {
        "status": "direct_square_other_gate_escape_profiled_through26",
        "scope": {
            "inputs": "permanent paired-coloop frozen graph6 corpus",
            "orders": list(corpus.frozen_graphs()),
            "quantifier": "all 541 direct root-opposite-square coloop occurrences",
            "no_graph_generation": True,
        },
        "by_order": by_order,
        "counts": dict(sorted(totals.items())),
        "first_boundary_witnesses": witnesses,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    payload = profile()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
    print(json.dumps(payload["counts"], sort_keys=True))
    print("DIRECT_SQUARE_OTHER_GATE_ESCAPE_PROFILED_THROUGH26")


if __name__ == "__main__":
    main()
