#!/usr/bin/env python3
"""Measure cycle mechanisms in the fixed 41-state Note 151 fibre."""

from __future__ import annotations

from collections import Counter
from pathlib import Path
import runpy

import networkx as nx


ROOT_DIR = Path(__file__).resolve().parents[5]
BASE = ROOT_DIR / (
    "units/barnette/computations/bundles/"
    "legal-wide-plane-brace-xor-cube/"
    "verify_legal_wide_plane_brace_xor_cube.py"
)
data = runpy.run_path(str(BASE))

fibre = data["fibre"]
index = {matching: position for position, matching in enumerate(fibre)}
g1 = data["SURVIVING_GATE"]
f = data["edge"]("b3", "t1")
component_count = data["delta_component_count"]

graph = nx.Graph()
graph.add_nodes_from(range(len(fibre)))
for left in range(len(fibre)):
    for right in range(left + 1, len(fibre)):
        if component_count(fibre[left], fibre[right]) == 1:
            graph.add_edge(left, right)

crossings = tuple(
    (left, right)
    for left, right in graph.edges()
    if (g1 in fibre[left]) != (g1 in fibre[right])
)
bridges = set(map(tuple, map(sorted, nx.bridges(graph))))
assert (graph.number_of_nodes(), graph.number_of_edges()) == (41, 136)
assert nx.is_connected(graph)
assert len(crossings) == 69
assert not bridges

alternate_lengths = Counter()
commuting_squares = 0
for left, right in crossings:
    graph.remove_edge(left, right)
    alternate_lengths[nx.shortest_path_length(graph, left, right)] += 1
    graph.add_edge(left, right)

    crossing_cycle = fibre[left] ^ fibre[right]
    has_commuting_square = False
    for neighbour in graph[left]:
        if neighbour == right:
            continue
        cycle = fibre[left] ^ fibre[neighbour]
        if not crossing_cycle.isdisjoint(cycle):
            continue
        opposite = index.get(fibre[right] ^ cycle)
        if (
            opposite is not None
            and graph.has_edge(neighbour, opposite)
            and graph.has_edge(opposite, right)
        ):
            has_commuting_square = True
            break
    commuting_squares += has_commuting_square

assert alternate_lengths == Counter({2: 67, 3: 2})
assert commuting_squares == 26

fixed_f_crossings = tuple(
    (left, right)
    for left, right in crossings
    if f in fibre[left] and f in fibre[right]
)
assert fixed_f_crossings == ((36, 37),)
third_vertices = set(graph[36]) & set(graph[37])
assert {25, 26} <= third_vertices
assert all(f not in fibre[position] for position in (25, 26))
assert all(g1 not in fibre[position] for position in (25, 26))

print("Note151 exchange graph: vertices=41 edges=136 connected=yes bridges=0")
print("crossings=69; triangle witnesses=67; shortest four-cycles=2")
print("edge-disjoint commuting squares=26")
print("fixed-f crossing=36-37; triangle vertices omitting f=25,26")
print("NOTE151_CYCLE_MECHANISMS_VERIFIED")
