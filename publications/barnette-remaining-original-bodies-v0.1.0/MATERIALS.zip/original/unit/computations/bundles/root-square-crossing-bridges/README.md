# Root-square crossing bridges

This bundle verifies
[Note 152](../../../notes/152-root-square-crossing-edges-can-be-bridges.md).

The first script uses only the Python standard library and reuses the fixed
triangulation of Note 150 with a different decoration:

~~~bash
python3 units/barnette/computations/bundles/root-square-crossing-bridges/verify_root_square_crossing_bridges.py
~~~

Its terminal marker is ROOT_SQUARE_CROSSING_BRIDGES_VERIFIED.

The second script measures the cycle witnesses in the fixed Note 151
41-state fibre:

~~~bash
uv run --python 3.12 --with networkx==3.6.1 \
  python units/barnette/computations/bundles/root-square-crossing-bridges/verify_note151_cycle_mechanisms.py
~~~

Its terminal marker is NOTE151_CYCLE_MECHANISMS_VERIFIED.

Neither script generates graphs or scans neighbouring orders.  The first
proves a fixed real counterexample to the edgewise nonbridge strengthening;
the second only identifies how the already-fixed Note 151 example escapes
its unique fixed-\(f\) crossing.
