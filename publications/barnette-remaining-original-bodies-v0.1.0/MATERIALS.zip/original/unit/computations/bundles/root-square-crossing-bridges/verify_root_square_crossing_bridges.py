#!/usr/bin/env python3
"""Verify crossing bridges in a root-square legal-wide complete family."""

from __future__ import annotations

from itertools import combinations
from pathlib import Path
import runpy


ROOT_DIR = Path(__file__).resolve().parents[5]
BASE = ROOT_DIR / (
    "units/barnette/computations/bundles/"
    "legal-wide-one-bond-without-root-square/"
    "verify_one_bond_without_root_square.py"
)
data = runpy.run_path(str(BASE))

edge = data["edge"]
vertices = data["VERTICES"]
faces = data["FACES"]
adjacency = data["ADJ"]

root_square_vertex = "r1"
root = edge("A", "r1")
g0 = edge("z", "r1")
g1 = edge("z", "r5")


def link_cycle(vertex):
    neighbours = set(adjacency[vertex])
    link = {item: [] for item in neighbours}
    for face in faces:
        if vertex not in face:
            continue
        left, right = tuple(face - {vertex})
        link[left].append(right)
        link[right].append(left)
    assert all(len(link[item]) == 2 for item in neighbours)
    start = min(neighbours)
    order = [start]
    previous = None
    current = start
    while True:
        following = (
            link[current][0]
            if link[current][0] != previous
            else link[current][1]
        )
        if following == start:
            break
        order.append(following)
        previous, current = current, following
    return tuple(order)


def cyclic_distance(order, first, second):
    return (order.index(second) - order.index(first)) % len(order)


square_link = link_cycle(root_square_vertex)
assert len(square_link) == 4
assert cyclic_distance(square_link, "A", "z") == 2

gate_link = link_cycle("z")
gate_distance = cyclic_distance(gate_link, "r1", "r5")
assert len(gate_link) == 8
assert gate_distance == len(gate_link) - gate_distance == 4


def rooted(row):
    left, right = root
    if row[left] != row[right]:
        return False
    root_colour = row[left]
    colour_components = {
        bit: data["components"](
            vertex for vertex in vertices if row[vertex] == bit
        )
        for bit in (0, 1)
    }
    if sum(map(len, colour_components.values())) != 3:
        return False
    first, second = data["incident_thirds"](root)
    if row[first] == root_colour or row[second] == root_colour:
        return False
    return not any(
        first in component and second in component
        for component in colour_components[1 - root_colour]
    )


def gate_bit(row, named_edge):
    left, right = named_edge
    return int(row[left] == row[right])


def bond_shore(first, second):
    shore = {vertex for vertex in vertices if first[vertex] != second[vertex]}
    if data["connected"](shore) and data["connected"](set(vertices) - shore):
        return frozenset(shore)
    return None


data["check_plane_triangulation"]()
matching_count, independent_pair_count = data["check_dual_is_brace"]()
assert (matching_count, independent_pair_count) == (97, 375)

family = tuple(
    row
    for row in data["normalized_nae_colourings"]()
    if rooted(row) and gate_bit(row, g0) == 1
)
row_string = data["row_string"]
expected_rows = (
    "010101111000",
    "010110111000",
    "010111011000",
    "010111101000",
    "010111110000",
)
assert tuple(row_string(row) for row in family) == expected_rows
assert tuple(gate_bit(row, g1) for row in family) == (0, 0, 1, 0, 0)

exchange_edges = {}
for left, right in combinations(range(len(family)), 2):
    shore = bond_shore(family[left], family[right])
    if shore is not None:
        exchange_edges[left, right] = shore

assert exchange_edges == {
    (0, 1): frozenset(("r3", "r4")),
    (1, 2): frozenset(("r4", "r5")),
    (2, 3): frozenset(("r5", "r6")),
    (3, 4): frozenset(("r6", "r7")),
}


def connected_without(removed_edge):
    graph = {index: set() for index in range(len(family))}
    for left, right in exchange_edges:
        if (left, right) == removed_edge:
            continue
        graph[left].add(right)
        graph[right].add(left)
    seen = {0}
    stack = [0]
    while stack:
        vertex = stack.pop()
        for neighbour in graph[vertex] - seen:
            seen.add(neighbour)
            stack.append(neighbour)
    return len(seen) == len(family)


bridges = tuple(item for item in exchange_edges if not connected_without(item))
crossings = tuple(
    (left, right)
    for left, right in exchange_edges
    if gate_bit(family[left], g1) != gate_bit(family[right], g1)
)
assert bridges == tuple(exchange_edges)
assert crossings == ((1, 2), (2, 3))


def face_word(first, second):
    symbols = {
        (0, 0): "0",
        (1, 0): "M",
        (0, 1): "N",
        (1, 1): "B",
    }
    order = tuple(f"r{index}" for index in range(1, 8)) + ("r0",)
    return "".join(
        symbols[1 - first[vertex], 1 - second[vertex]]
        for vertex in order
    )


assert face_word(family[1], family[2]) == "B00MN000"
assert face_word(family[2], family[3]) == "B000MN00"

print("dual brace: 20 vertices; perfect matchings=97; independent pairs=375")
print("root square: dual vertex r1; opposite edges A-r1 and z-r1")
print("legal-wide gates: z-r1 and z-r5; arc lengths=(5,5)")
print("complete rooted exchange graph: path 0-1-2-3-4")
print("sectors=(0,0,1,0,0); crossing bridges=(1,2),(2,3)")
print("crossing face words: B00MN000, B000MN00")
print("ROOT_SQUARE_CROSSING_BRIDGES_VERIFIED")
