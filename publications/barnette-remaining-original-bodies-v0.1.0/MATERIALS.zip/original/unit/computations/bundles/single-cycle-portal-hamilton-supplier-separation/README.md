# Single-cycle portal and Hamilton supplier separation

This bundle verifies the fixed legal-wide split in
[Note 127](../../../notes/127-single-cycle-portals-and-hamilton-suppliers-need-not-coincide.md).
The graph, embedding, root, gates, site and endpoint are literal inputs.
The verifier enumerates the complete parent and child perfect-matching
families and does not read a census or generated classification record.

## Reproduction

From the AIMath root:

```bash
python3 units/barnette/computations/bundles/single-cycle-portal-hamilton-supplier-separation/verify_hit24_nonrooted_hamilton_hub_counterexample.py
```

Tested with Python 3.14.6 on 2026-08-28.  Wall time was (0.04) seconds on
the freezing machine.  The terminal marker is

```text
HIT24_NONROOTED_HAMILTON_HUB_COUNTEREXAMPLE_VERIFIED
```

The complete expected output is in [expected-output.txt](expected-output.txt).

SHA-256 of the verifier:

```text
82f794e1df1cad76f7d6b6b1585a4c9234ab556e8a632504e196970387bb610e
```

## Scope

The certificate proves that the single-cycle portal and Hamilton-complement
requirements can be separately realized but not realized by one matching.
It does not disprove mixed-sector survival and makes no global order-minimality
claim.

