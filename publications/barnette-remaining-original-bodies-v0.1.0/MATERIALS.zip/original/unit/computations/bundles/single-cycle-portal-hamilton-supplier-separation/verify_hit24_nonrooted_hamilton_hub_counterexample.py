#!/usr/bin/env python3
"""Independent fixed certificate for the minimum frozen Hamilton-hub failure."""

from __future__ import annotations

from collections import Counter
import importlib.util
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
LIBRARY = (
    BARNETTE
    / "computations"
    / "bundles"
    / "endpoint-star-parity-and-pairing-counterexamples"
    / "verify_hit29_bondwise_hall_counterexample.py"
)


def load_library():
    specification = importlib.util.spec_from_file_location(
        "hit24_hamilton_hub_fixed_library", LIBRARY
    )
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


h = load_library()

GRAPH6 = h.GRAPH6
FACES = h.FACES
ROOT = (11, 22)
FORCED_GATE = (3, 23)
SURVIVING_GATE = (5, 14)
ROOT_GATE_SQUARE = (11, 22, 3, 23)
FACE_INDEX = 8
SITE_INDICES = (3, 7)
SITE = frozenset({(9, 20), (4, 17)})
CHI = frozenset(
    {
        (0, 12), (1, 13), (2, 15), (3, 23),
        (4, 17), (5, 14), (6, 16), (7, 18),
        (8, 19), (9, 20), (10, 21), (11, 22),
    }
)
Q_DROP_IV = frozenset(
    {
        (0, 12), (1, 13), (2, 15), (3, 23),
        (4, 16), (5, 14), (6, 20), (7, 17),
        (8, 18), (9, 19), (10, 21), (11, 22),
    }
)
Q_DROP_III = frozenset(
    {
        (0, 13), (1, 12), (2, 15), (3, 23),
        (4, 16), (5, 14), (6, 20), (7, 17),
        (8, 18), (9, 19), (10, 21), (11, 22),
    }
)


def difference_component_orders(first, second):
    difference = first ^ second
    vertices = tuple(sorted({vertex for edge in difference for vertex in edge}))
    return tuple(sorted(map(len, h.components(vertices, difference))))


def complement_component_orders(vertices, edges, matching):
    return tuple(sorted(map(len, h.components(vertices, edges - matching))))


def main():
    vertices, edges = h.decode_graph6(GRAPH6)
    h.validate_plane_cubic_bipartite(vertices, edges, FACES)
    h.verify_root_gate_square(FACES, ROOT, FORCED_GATE, ROOT_GATE_SQUARE)
    labelled = (ROOT, FORCED_GATE, SURVIVING_GATE, *tuple(sorted(SITE)))
    assert all(
        not (set(first) & set(second))
        for index, first in enumerate(labelled)
        for second in labelled[index + 1 :]
    )
    parent_matchings = h.enumerate_perfect_matchings(vertices, edges)
    assert len(parent_matchings) == 200
    assert h.verify_brace(edges, parent_matchings) == 558
    rooted = tuple(
        matching
        for matching in parent_matchings
        if h.root_target(vertices, edges, matching, ROOT, FORCED_GATE)
    )
    assert len(rooted) == 11
    l11 = tuple(matching for matching in rooted if SITE <= matching)
    assert len(l11) == 3 and l11[0] == CHI
    assert SURVIVING_GATE in CHI

    (
        child_vertices,
        child_edges,
        child_faces,
        local,
        selected,
        site_face,
    ) = h.expand(vertices, edges, FACES, FACE_INDEX, SITE_INDICES)
    assert frozenset(selected) == SITE
    h.validate_plane_cubic_bipartite(child_vertices, child_edges, child_faces)
    h.verify_root_gate_square(child_faces, ROOT, FORCED_GATE, ROOT_GATE_SQUARE)
    assert h.legal_wide_arcs(
        child_faces, ROOT, FORCED_GATE, SURVIVING_GATE
    ) == (5, 5)
    child_matchings = h.enumerate_perfect_matchings(child_vertices, child_edges)
    assert len(child_matchings) == 344
    assert h.verify_brace(child_edges, child_matchings) == 777
    child_fibre = tuple(
        matching
        for matching in child_matchings
        if h.root_target(
            child_vertices, child_edges, matching, ROOT, FORCED_GATE
        )
    )
    assert len(child_fibre) == 13
    cells = {matching: h.local_cell(matching, local) for matching in child_fibre}
    assert Counter(cells.values()) == Counter(
        {"C10": 8, "Xuy": 3, "R00": 1, "Xvx": 1}
    )
    targets = tuple(
        matching
        for matching in child_fibre
        if SURVIVING_GATE in matching
        and cells[matching] in {"R00", "Xuy", "Xvx"}
    )
    assert tuple(cells[target] for target in targets) == (
        "Xuy", "R00", "Xvx", "Xuy", "Xuy"
    )

    direct = h.direct_lifts(CHI, site_face, SITE_INDICES, selected, local)
    assert all(matching not in child_fibre for matching in direct.values())
    mixed = tuple(
        matching
        for matching in rooted
        if SURVIVING_GATE not in matching
        and not SITE <= matching
        and h.difference_component_count(CHI, matching) == 1
    )
    escape = tuple(
        matching
        for matching in rooted
        if SURVIVING_GATE in matching
        and not SITE <= matching
        and h.difference_component_count(CHI, matching) == 1
    )
    assert (len(mixed), len(escape), len(targets)) == (2, 0, 5)

    retained = edges - SITE
    rooted_set = frozenset(rooted)
    base_candidates = []
    iii_candidates = []
    iv_candidates = []
    full_candidates = []
    for index, matching in enumerate(parent_matchings):
        if ROOT not in matching or FORCED_GATE not in matching:
            continue
        if SURVIVING_GATE not in matching or matching in rooted_set:
            continue
        covered = tuple(
            target_index
            for target_index, target in enumerate(targets)
            if (target & retained) <= ((CHI | matching) & retained)
        )
        difference = matching ^ CHI
        condition_iii = (
            SITE <= difference
            and not (difference & {ROOT, FORCED_GATE, SURVIVING_GATE})
            and not (SITE & matching)
            and h.difference_component_count(CHI, matching) == 1
        )
        condition_iv = complement_component_orders(
            vertices, edges, matching
        ) == (24,)
        row = (index, matching, covered)
        base_candidates.append(row)
        if condition_iii:
            iii_candidates.append(row)
        if condition_iv:
            iv_candidates.append(row)
        if condition_iii and condition_iv:
            full_candidates.append(row)

    assert len(base_candidates) == 20
    assert tuple(index for index, _matching, _covered in iii_candidates) == (23,)
    assert tuple(index for index, _matching, _covered in iv_candidates) == (
        27, 93, 125, 156
    )
    assert full_candidates == []
    assert iii_candidates[0][1] == Q_DROP_IV
    assert iii_candidates[0][2] == (0,)
    assert difference_component_orders(CHI, Q_DROP_IV) == (10,)
    assert complement_component_orders(vertices, edges, Q_DROP_IV) == (6, 18)
    assert iv_candidates[1][1] == Q_DROP_III
    assert iv_candidates[1][2] == (0, 1, 2)
    assert difference_component_orders(CHI, Q_DROP_III) == (4, 10)
    assert complement_component_orders(vertices, edges, Q_DROP_III) == (24,)
    assert tuple(
        index for index, _matching, covered in base_candidates if covered
    ) == (23, 93, 152)

    print(
        {
            "parent": (24, 36, 200, 558),
            "child": (28, 42, 344, 777),
            "rooted_fibres": (len(rooted), len(child_fibre)),
            "endpoint_profile": (len(mixed), len(escape), len(targets)),
            "candidate_counts": (20, 1, 4, 0),
            "drop_iv": {
                "matching_index": 23,
                "difference_components": (10,),
                "complement_components": (6, 18),
                "covered": ((0, "Xuy"),),
            },
            "drop_iii": {
                "matching_index": 93,
                "difference_components": (4, 10),
                "complement_components": (24,),
                "covered": ((0, "Xuy"), (1, "R00"), (2, "Xvx")),
            },
            "full_hubs": (),
        }
    )
    print("HIT24_NONROOTED_HAMILTON_HUB_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
