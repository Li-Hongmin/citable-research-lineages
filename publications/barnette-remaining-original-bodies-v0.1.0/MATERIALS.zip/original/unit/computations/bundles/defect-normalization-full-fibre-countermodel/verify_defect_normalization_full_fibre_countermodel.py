#!/usr/bin/env python3
"""Strict abstract P4 countermodel with two (pi0,1) proper toggles.

The residual graph is plane, simple and bipartite, with four degree-two
terminals and all other vertices cubic.  Its eight labelled inverse-square
attachments split exactly into plane/nonbipartite and bipartite/nonplanar
cases, so this is not an actual legal plane interface.
"""

from collections import Counter
from itertools import combinations

import networkx as nx


def edge(left, right):
    return tuple(sorted((left, right)))


def enumerate_matchings(graph):
    adjacency = {vertex: frozenset(graph[vertex]) for vertex in graph}

    def recurse(remaining):
        if not remaining:
            yield frozenset()
            return
        vertex = min(remaining, key=lambda item: len(adjacency[item] & remaining))
        for neighbour in adjacency[vertex] & remaining:
            for matching in recurse(remaining - {vertex, neighbour}):
                yield matching | {edge(vertex, neighbour)}

    return tuple(recurse(frozenset(graph)))


def complement_profile(graph, matching, terminals, target_pairing):
    complement = nx.Graph()
    complement.add_nodes_from(graph)
    complement.add_edges_from(
        set(edge(*item) for item in graph.edges()) - set(matching)
    )
    pairing = set()
    cycle_count = 0
    for vertices in nx.connected_components(complement):
        component = complement.subgraph(vertices)
        ends = frozenset(set(vertices) & terminals)
        if ends:
            pairing.add(ends)
        cycle_count += (
            component.number_of_edges() - component.number_of_nodes() + 1
        )
    pairing_name = "pi0" if pairing == target_pairing else tuple(
        sorted(tuple(sorted(part)) for part in pairing)
    )
    return pairing_name, cycle_count


def difference_cycles(first, second):
    graph = nx.Graph()
    graph.add_edges_from(first ^ second)
    difference = first ^ second
    return tuple(
        frozenset(item for item in difference if set(item) <= vertices)
        for vertices in nx.connected_components(graph)
    )


TERMINALS = frozenset(("p0", "p3", "q0", "q7"))
PI0 = {
    frozenset(("p0", "p3")),
    frozenset(("q0", "q7")),
}
GATE = edge("p0", "p1")

# Twelve-vertex symbolic overlay before blocking.  Its fixed-pairing fibre
# has four states.  The two unwanted crossing states have the unique common
# edge q3q4, while the intended endpoint states both omit q3q4.
OVERLAY_EDGES = frozenset(
    edge(*item)
    for item in (
        ("p0", "p1"),
        ("p0", "p3"),
        ("p1", "p2"),
        ("p1", "q0"),
        ("p2", "p3"),
        ("p2", "q5"),
        ("q0", "q1"),
        ("q1", "q2"),
        ("q1", "q4"),
        ("q2", "q3"),
        ("q2", "q7"),
        ("q3", "q4"),
        ("q3", "q6"),
        ("q4", "q5"),
        ("q5", "q6"),
        ("q6", "q7"),
    )
)
overlay = nx.Graph(OVERLAY_EDGES)
overlay_matchings = enumerate_matchings(overlay)
overlay_fibre = tuple(
    matching
    for matching in overlay_matchings
    if complement_profile(overlay, matching, TERMINALS, PI0) == ("pi0", 0)
)
assert len(overlay_fibre) == 4

OVERLAY_M = frozenset(
    edge(*item)
    for item in (
        ("p0", "p1"),
        ("p2", "p3"),
        ("q0", "q1"),
        ("q2", "q3"),
        ("q4", "q5"),
        ("q6", "q7"),
    )
)
OVERLAY_N = frozenset(
    edge(*item)
    for item in (
        ("p0", "p3"),
        ("p1", "q0"),
        ("p2", "q5"),
        ("q1", "q4"),
        ("q2", "q7"),
        ("q3", "q6"),
    )
)
assert OVERLAY_M in overlay_fibre and OVERLAY_N in overlay_fibre
unwanted = tuple(
    matching for matching in overlay_fibre if matching not in (OVERLAY_M, OVERLAY_N)
)
assert len(unwanted) == 2
assert (
    (set(unwanted[0]) & set(unwanted[1])) - set(OVERLAY_M) - set(OVERLAY_N)
) == {
    edge("q3", "q4")
}

# Replace q3q4 by the plane two-pole Q3-A0B0.  This removes both unwanted
# projected states while giving four internal lifts of each intended state.
CUBE_POLE_EDGES = (
    ("A0", "B1"),
    ("A0", "B2"),
    ("A1", "B0"),
    ("A1", "B1"),
    ("A1", "B3"),
    ("A2", "B0"),
    ("A2", "B2"),
    ("A2", "B3"),
    ("A3", "B1"),
    ("A3", "B2"),
    ("A3", "B3"),
)
RESIDUAL_EDGES = set(OVERLAY_EDGES)
RESIDUAL_EDGES.remove(edge("q3", "q4"))
RESIDUAL_EDGES.update(edge("L" + a, "L" + b) for a, b in CUBE_POLE_EDGES)
RESIDUAL_EDGES.update((edge("q3", "LA0"), edge("q4", "LB0")))
R = nx.Graph(RESIDUAL_EDGES)

assert len(R) == 20 and R.number_of_edges() == 28
assert nx.is_connected(R) and nx.is_bipartite(R) and nx.check_planarity(R)[0]
assert sorted(degree for _, degree in R.degree()).count(2) == 4
assert {vertex for vertex, degree in R.degree() if degree == 2} == TERMINALS
assert all(degree in (2, 3) for _, degree in R.degree())

POLE_MATCHING = frozenset(
    edge(*item)
    for item in (
        ("LA0", "LB1"),
        ("LA1", "LB3"),
        ("LA2", "LB0"),
        ("LA3", "LB2"),
    )
)
M = OVERLAY_M | POLE_MATCHING
N = OVERLAY_N | POLE_MATCHING

matchings = enumerate_matchings(R)
fibre = tuple(
    matching
    for matching in matchings
    if complement_profile(R, matching, TERMINALS, PI0) == ("pi0", 0)
)
sector1 = tuple(matching for matching in fibre if GATE in matching)
sector0 = tuple(matching for matching in fibre if GATE not in matching)
assert (len(matchings), len(fibre), len(sector1), len(sector0)) == (45, 8, 4, 4)
assert M in sector1 and N in sector0

cross_histogram = Counter(
    len(difference_cycles(first, second))
    for first in sector1
    for second in sector0
)
assert cross_histogram == Counter({2: 4, 3: 10, 4: 2})

cycles = difference_cycles(M, N)
assert sorted(len(cycle) for cycle in cycles) == [4, 8]
proper_profiles = tuple(
    complement_profile(R, M ^ cycle, TERMINALS, PI0) for cycle in cycles
)
assert proper_profiles == (("pi0", 1), ("pi0", 1))
assert all(M ^ cycle not in fibre for cycle in cycles)
assert N == M ^ cycles[0] ^ cycles[1]

# There is no plane-bipartite labelled inverse square extension for this
# terminal pairing.  Assign either target pair to the (u,y) channel and
# orient both pairs independently.  The resulting eight labelled
# attachments split 4+4 exactly.
orientation_results = Counter()
extensions = []
target_pairs = (("p0", "p3"), ("q0", "q7"))
for channel_swap in (False, True):
    first_pair = target_pairs[int(channel_swap)]
    second_pair = target_pairs[1 - int(channel_swap)]
    for first_channel in (first_pair, first_pair[::-1]):
        for second_channel in (second_pair, second_pair[::-1]):
            p_first, p_last = first_channel
            q_first, q_last = second_channel
            extension = R.copy()
            extension.add_edges_from(
                (
                    (p_first, "u"),
                    (q_first, "v"),
                    (q_last, "x"),
                    (p_last, "y"),
                    ("u", "v"),
                    ("v", "x"),
                    ("x", "y"),
                    ("y", "u"),
                )
            )
            planar = nx.check_planarity(extension)[0]
            bipartite = nx.is_bipartite(extension)
            orientation_results[(planar, bipartite)] += 1
            extensions.append(((p_first, q_first, q_last, p_last), extension))
assert orientation_results == Counter({(True, False): 4, (False, True): 4})

# Explicit certificates for both sides of the dichotomy.
plane_nonbip = next(graph for _, graph in extensions if nx.check_planarity(graph)[0])
assert all(plane_nonbip.has_edge(*item) for item in zip(
    ("q0", "v", "u", "p0", "p1"),
    ("v", "u", "p0", "p1", "q0"),
))

bip_nonplane = next(graph for _, graph in extensions if nx.is_bipartite(graph))
planar, kuratowski = nx.check_planarity(bip_nonplane, counterexample=True)
assert not planar
branches = {vertex for vertex, degree in kuratowski.degree() if degree == 3}
assert len(branches) == 6
assert nx.is_connected(kuratowski)
assert all(degree in (2, 3) for _, degree in kuratowski.degree())

# NetworkX may return different subdivisions as its edge iteration order
# changes.  Suppress every degree-two path and verify the invariant core.
core = nx.Graph()
core.add_nodes_from(branches)
for branch in branches:
    for neighbour in kuratowski[branch]:
        previous, current = branch, neighbour
        while current not in branches:
            following = next(
                vertex for vertex in kuratowski[current] if vertex != previous
            )
            previous, current = current, following
        core.add_edge(branch, current)
assert nx.is_isomorphic(core, nx.complete_bipartite_graph(3, 3))

print("residual: plane simple bipartite four-terminal cubic interface")
print("residual perfect matchings: 45")
print("fixed-pairing fibre sectors: 4 and 4")
print("complete cross-sector histogram: 2^4 3^10 4^2")
print("explicit minimum atom: C4 dot-union C8")
print("proper toggle profiles: {(pi0,1), (pi0,1)}")
print("inverse-square attachments: plane/nonbipartite^4, bipartite/nonplanar^4")
print("ABSTRACT_DOUBLE_CORRECT_CYCLE_DEFECT_VERIFIED")
