# Defect-normalization full-fibre countermodel

This bundle verifies the countermodel used in
[Note 091](../../../notes/091-defect-normalization-fails-before-the-labelled-inverse-square-interface.md).

Run from the AIMath root:

```text
uv run --python 3.12 --with networkx \
  units/barnette/computations/bundles/defect-normalization-full-fibre-countermodel/verify_defect_normalization_full_fibre_countermodel.py
```

The frozen run used Python 3.12.11 and NetworkX 3.6.1.  The verifier
constructs the 20-vertex residual graph directly, recursively enumerates all
45 perfect matchings, extracts the complete fixed-pairing fibre, checks every
cross-sector pair and verifies the explicit two-toggle defect.  It then tests
all eight labelled inverse-square attachments.  Every attachment is either
plane and nonbipartite or bipartite and nonplanar; the nonplanar case is
certified by suppressing the returned subdivision to a graph isomorphic to
\(K_{3,3}\).

Expected final line:

```text
ABSTRACT_DOUBLE_CORRECT_CYCLE_DEFECT_VERIFIED
```

The certificate proves a complete-fibre countermodel before the labelled
inverse-square interface.  It does not construct a legal plane cubic
bipartite square extension or a Barnette graph.

