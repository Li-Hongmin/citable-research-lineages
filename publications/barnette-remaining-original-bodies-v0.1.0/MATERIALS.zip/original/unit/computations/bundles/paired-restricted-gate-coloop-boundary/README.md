# Paired restricted-gate coloop boundary

This bundle verifies the finite assertions used in
[Note 084](../../../notes/084-two-local-gate-coloops-are-nonplanar-but-single-gate-forcing-can-be-nonlocal.md).
The \(K_{3,3}\)-subdivision theorem and the arbitrary even-prism
classification are analytic.

The first verifier enumerates the complete perfect-matching and rooted-target
families of the octagonal prism for every root and minimum-wide gate pair:

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/paired-restricted-gate-coloop-boundary/verify_even_prism_paired_gate_boundary.py

Its required final line is

    OCTAGONAL_PRISM_HAS_NO_PAIRED_GATE_RESTRICTED_COLOOPS

The classifier reads only graph6 representatives already frozen in the
permanent through-\(26\) bundles.  It invokes no graph generator:

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/paired-restricted-gate-coloop-boundary/classify_existing_single_gate_coloops.py \
      --output units/barnette/computations/bundles/paired-restricted-gate-coloop-boundary/existing_single_gate_coloops_through26.json

The required final marker is

    NONLOCAL_RESTRICTED_GATE_COLOOP_FOUND

The frozen JSON records all aggregate counts and explicit first witnesses.
The third verifier reconstructs the order-\(24\) witness, its complete
\(15\)-target family, the profile \(01^{12}+11^3\), the exact family
intersection, and the failure of every common-square-ladder explanation:

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/paired-restricted-gate-coloop-boundary/verify_order24_nonlocal_single_gate_coloop.py

Its required final line is

    ORDER24_NONLOCAL_RESTRICTED_GATE_COLOOP_VERIFIED

The through-\(26\) classification is a finite statement about the named
frozen corpus.  It is not an order-\(28\) census and does not settle the
arbitrary-order paired-coloop question.
