#!/usr/bin/env python3
"""Exact one-graph check of the paired-gate boundary in the octagonal prism."""

from __future__ import annotations

from collections import Counter
from itertools import combinations

import networkx as nx


Edge = tuple[int, int]
Matching = frozenset[Edge]
N = 8


def edge(u: int, v: int) -> Edge:
    return (u, v) if u < v else (v, u)


def top(i: int) -> int:
    return i % N


def bottom(i: int) -> int:
    return N + i % N


def prism() -> nx.Graph:
    graph = nx.Graph()
    for i in range(N):
        graph.add_edge(top(i), top(i + 1))
        graph.add_edge(bottom(i), bottom(i + 1))
        graph.add_edge(top(i), bottom(i))
    return graph


def perfect_matchings(graph: nx.Graph) -> tuple[Matching, ...]:
    def recurse(remaining: frozenset[int], chosen: tuple[Edge, ...]):
        if not remaining:
            yield frozenset(chosen)
            return
        u = min(remaining)
        for v in sorted(graph[u]):
            if v in remaining:
                yield from recurse(
                    remaining - {u, v}, chosen + (edge(u, v),)
                )

    return tuple(recurse(frozenset(graph), ()))


def rooted_family(
    graph: nx.Graph,
    matchings: tuple[Matching, ...],
    root: Edge,
) -> tuple[Matching, ...]:
    family = []
    for matching in matchings:
        if root not in matching:
            continue
        complement = graph.copy()
        complement.remove_edges_from(matching)
        components = tuple(nx.connected_components(complement))
        if len(components) != 2:
            continue
        if (root[0] in components[0]) == (root[1] in components[0]):
            continue
        assert all(
            complement.subgraph(component).number_of_edges() == len(component)
            for component in components
        )
        family.append(matching)
    return tuple(family)


def verify_brace(graph: nx.Graph, matchings: tuple[Matching, ...]) -> None:
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    assert set(dict(graph.degree()).values()) == {3}
    edges = tuple(edge(*item) for item in graph.edges())
    for first, second in combinations(edges, 2):
        if set(first) & set(second):
            continue
        assert any({first, second} <= matching for matching in matchings)


def formula_matching(j: int) -> Matching:
    result = {
        edge(top(0), top(1)),
        edge(top(j), top(j + 1)),
        edge(bottom(0), bottom(1)),
        edge(bottom(j), bottom(j + 1)),
    }
    result.update(
        edge(top(i), bottom(i))
        for i in range(N)
        if i not in {0, 1, j, (j + 1) % N}
    )
    return frozenset(result)


def verify_all_octagonal_wide_interfaces(
    graph: nx.Graph, matchings: tuple[Matching, ...]
) -> None:
    rim_faces = (
        tuple(edge(top(i), top(i + 1)) for i in range(N)),
        tuple(edge(bottom(i), bottom(i + 1)) for i in range(N)),
    )
    for rim in rim_faces:
        rim_vertices = set().union(*map(set, rim))
        outside_roots = tuple(
            edge(*item)
            for item in graph.edges()
            if edge(*item) not in rim
        )
        assert all(not (set(root) <= rim_vertices) for root in outside_roots)
        for i in range(4):
            gates = (rim[i], rim[i + 4])
            for root in outside_roots:
                family = rooted_family(graph, matchings, root)
                assert family
                assert not all(
                    gates[0] in matching and gates[1] in matching
                    for matching in family
                )


def main() -> None:
    graph = prism()
    matchings = perfect_matchings(graph)
    assert len(matchings) == 49
    verify_brace(graph, matchings)

    root = edge(bottom(0), bottom(1))
    gates = (edge(top(0), top(1)), edge(top(4), top(5)))
    family = rooted_family(graph, matchings, root)
    expected = tuple(formula_matching(j) for j in range(2, 7))
    assert family == expected
    assert Counter(
        "".join("1" if gate in matching else "0" for gate in gates)
        for matching in family
    ) == Counter({"10": 4, "11": 1})

    verify_all_octagonal_wide_interfaces(graph, matchings)
    print("OCTAGONAL_PRISM_HAS_NO_PAIRED_GATE_RESTRICTED_COLOOPS")


if __name__ == "__main__":
    main()
