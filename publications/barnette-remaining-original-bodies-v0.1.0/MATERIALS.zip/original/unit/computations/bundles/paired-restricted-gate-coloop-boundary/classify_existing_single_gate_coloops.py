#!/usr/bin/env python3
"""Classify local versus nonlocal restricted gate coloops through order 26.

Only graph6 representatives already frozen in permanent bundles are read.
No graph generator or new construction is invoked.
"""

from __future__ import annotations

from collections import Counter
import argparse
import importlib.util
from itertools import combinations
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
BUNDLES = BARNETTE / "computations" / "bundles"
SINGLE_GATE_SCRIPT = HERE / "existing_wide_corpus.py"

sys.dont_write_bytecode = True


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


base = load_module(SINGLE_GATE_SCRIPT, "paired_gate_existing_base")
wide = base.wide
lift = base.lift
source = base.source
edge = base.edge


def opposite_on_square(graph: nx.Graph, first: tuple[int, int], second: tuple[int, int]):
    if set(first) & set(second):
        return False, None
    u, v = first
    x, y = second
    for square in ((u, v, x, y), (u, v, y, x)):
        if all(graph.has_edge(square[i], square[(i + 1) % 4]) for i in range(4)):
            return True, square
    return False, None


def square_opposition_graph(graph: nx.Graph) -> nx.Graph:
    """Return the graph on primal edges joined when opposite on a 4-cycle."""

    result = nx.Graph()
    result.add_nodes_from(edge(*item) for item in graph.edges())
    for vertices in combinations(sorted(graph), 4):
        subgraph = graph.subgraph(vertices)
        if subgraph.number_of_edges() != 4:
            continue
        if not nx.is_connected(subgraph) or set(dict(subgraph.degree()).values()) != {2}:
            continue
        cycle = tuple(nx.find_cycle(subgraph, source=min(vertices)))
        cycle_edges = tuple(edge(*item) for item in cycle)
        assert len(cycle_edges) == 4
        result.add_edge(cycle_edges[0], cycle_edges[2])
        result.add_edge(cycle_edges[1], cycle_edges[3])
    return result


def analyse_graph(order: int, source_graph6: str):
    primal = nx.from_graph6_bytes(source_graph6.encode())
    planar, embedding = nx.check_planarity(primal, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    primal_faces = source.plane_faces(primal, embedding)
    assert lift.verify_brace(primal)
    reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift.verify_reduced_triangulation(reduced)
    split_counts: Counter[str] = Counter()
    splits = wide.legal_wide_splits(reduced, rotations, split_counts)
    counts: Counter[str] = Counter(split_counts)
    counts["plane_braces"] = 1
    counts["legal_wide_splits"] = len(splits)
    if not splits:
        return counts, None, None

    families, _, _ = lift.target_families(reduced, reduced_faces)
    opposition = square_opposition_graph(primal)
    reduced_vertices = tuple(sorted(reduced))
    dual_to_primal = wide.primal_edge_by_dual_edge(primal, primal_faces)
    family_matchings = {}
    for root, encoded_family in families.items():
        colours = tuple(
            lift.decode_colouring(reduced_vertices, encoded)
            for encoded in encoded_family
        )
        matchings = tuple(
            wide.matching_from_colour(primal, reduced, dual_to_primal, colour)
            for colour in colours
        )
        family_matchings[root] = matchings

    first_nonlocal = None
    first_outside_ladder = None
    for split in splits:
        z = int(split["z"])
        gates = (
            dual_to_primal[edge(z, int(split["first_gate"]))],
            dual_to_primal[edge(z, int(split["second_gate"]))],
        )
        for root in sorted(families):
            if z in root:
                continue
            matchings = family_matchings[root]
            primal_root = dual_to_primal[root]
            common_edges = set.intersection(*(set(item) for item in matchings))
            common_opposition = opposition.subgraph(common_edges)
            counts["nonempty_wide_rooted_target_families"] += 1
            forced = tuple(all(gate in item for item in matchings) for gate in gates)
            counts[f"family_forced_gate_count_{sum(forced)}"] += 1
            for gate_index, is_forced in enumerate(forced):
                if not is_forced:
                    continue
                counts["restricted_gate_coloop_occurrences"] += 1
                local, square = opposite_on_square(
                    primal, primal_root, gates[gate_index]
                )
                counts[
                    "opposite_square_coloops" if local else "nonlocal_coloops"
                ] += 1
                if nx.has_path(common_opposition, primal_root, gates[gate_index]):
                    distance = nx.shortest_path_length(
                        common_opposition, primal_root, gates[gate_index]
                    )
                    counts[f"common_square_ladder_distance_{distance}"] += 1
                else:
                    distance = None
                    counts["coloops_outside_common_square_ladder"] += 1
                need_nonlocal_record = not local and first_nonlocal is None
                need_outside_record = (
                    distance is None and first_outside_ladder is None
                )
                if not need_nonlocal_record and not need_outside_record:
                    continue
                patterns = Counter(
                    "".join("1" if gate in item else "0" for gate in gates)
                    for item in matchings
                )
                record = {
                    "source_order": order,
                    "source_graph6": source_graph6,
                    "source_edges": sorted(edge(*item) for item in primal.edges()),
                    "source_faces": primal_faces,
                    "site": {
                        "split_vertex": z,
                        "rotation": split["rotation"],
                        "gate_indices": (
                            split["first_index"],
                            split["second_index"],
                        ),
                        "gate_vertices": (
                            split["first_gate"],
                            split["second_gate"],
                        ),
                        "primal_gates": gates,
                        "closed_arc_cardinalities": (
                            split["left_size"], split["right_size"]
                        ),
                    },
                    "dual_root": root,
                    "primal_root": primal_root,
                    "forced_gate_index": gate_index,
                    "forced_gate": gates[gate_index],
                    "opposite_square": square,
                    "common_square_ladder_distance": distance,
                    "common_square_ladder_path": (
                        nx.shortest_path(
                            common_opposition, primal_root, gates[gate_index]
                        )
                        if distance is not None
                        else None
                    ),
                    "common_edges": sorted(common_edges),
                    "complete_family_size": len(matchings),
                    "gate_pattern_histogram": dict(sorted(patterns.items())),
                    "complete_family": [sorted(item) for item in matchings],
                }
                if need_nonlocal_record:
                    first_nonlocal = record
                if need_outside_record:
                    first_outside_ladder = record
    return counts, first_nonlocal, first_outside_ladder


def classify():
    totals: Counter[str] = Counter()
    by_order = {}
    first_nonlocal = None
    first_outside_ladder = None
    corpora = base.frozen_graphs()
    for order, graph6_values in corpora.items():
        order_counts: Counter[str] = Counter()
        for source_graph6 in graph6_values:
            counts, witness, outside_witness = analyse_graph(order, source_graph6)
            order_counts.update(counts)
            totals.update(counts)
            if first_nonlocal is None and witness is not None:
                first_nonlocal = witness
            if first_outside_ladder is None and outside_witness is not None:
                first_outside_ladder = outside_witness
        by_order[str(order)] = dict(sorted(order_counts.items()))
    assert totals["family_forced_gate_count_2"] == 0
    assert totals["restricted_gate_coloop_occurrences"] == (
        totals["opposite_square_coloops"] + totals["nonlocal_coloops"]
    )
    assert totals["restricted_gate_coloop_occurrences"] == (
        sum(
            value
            for key, value in totals.items()
            if key.startswith("common_square_ladder_distance_")
        )
        + totals["coloops_outside_common_square_ladder"]
    )
    return {
        "status": (
            "nonlocal_restricted_gate_coloop_found"
            if first_nonlocal is not None
            else "all_existing_through26_restricted_gate_coloops_are_opposite_square"
        ),
        "scope": {
            "orders": list(corpora),
            "inputs": "frozen complete plane-brace representatives only",
            "quantifier": "every legal wide split and nonempty complete rooted-target family",
            "no_graph_generation": True,
        },
        "by_order": by_order,
        "counts": dict(sorted(totals.items())),
        "first_nonlocal_coloop": first_nonlocal,
        "first_coloop_outside_common_square_ladder": first_outside_ladder,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    payload = classify()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
    print(json.dumps(payload["counts"], sort_keys=True))
    print(payload["status"].upper())


if __name__ == "__main__":
    main()
