#!/usr/bin/env python3
"""Verify the first restricted gate coloop outside common square ladders."""

from __future__ import annotations

from collections import Counter
import importlib.util
from itertools import combinations
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "existing_single_gate_coloops_through26.json"
CLASSIFIER = HERE / "classify_existing_single_gate_coloops.py"
sys.dont_write_bytecode = True


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


base = load_module(CLASSIFIER, "verify_nonlocal_coloop_base")
wide = base.wide
lift = base.lift
edge = base.edge


def main() -> None:
    with SOURCE.open() as handle:
        payload = json.load(handle)
    witness = payload["first_coloop_outside_common_square_ladder"]
    assert witness["source_order"] == 24
    assert witness["source_graph6"] == (
        "W???????????w?s?P_BC?I_?H_?e??B_?SG?@B??@g??B_?"
    )

    primal = nx.from_graph6_bytes(witness["source_graph6"].encode())
    assert lift.verify_brace(primal)
    assert sorted(edge(*item) for item in primal.edges()) == [
        tuple(item) for item in witness["source_edges"]
    ]
    faces = tuple(tuple(face) for face in witness["source_faces"])
    reduced, rotations = lift.dual_from_primal_faces(primal, faces)
    reduced_faces = lift.verify_reduced_triangulation(reduced)
    dual_to_primal = wide.primal_edge_by_dual_edge(primal, faces)

    site = witness["site"]
    z = int(site["split_vertex"])
    rotation = tuple(site["rotation"])
    assert rotations[z] == rotation
    first_index, second_index = map(int, site["gate_indices"])
    assert (second_index - first_index + 1, len(rotation) - second_index + first_index + 1) == (5, 5)
    expanded, _, _, _ = lift.split_vertex(
        reduced, z, rotation, first_index, second_index
    )
    expanded_faces = lift.expanded_triangulation_faces(expanded)
    assert expanded_faces is not None
    assert lift.verify_brace(lift.dual_from_plane_graph(expanded, expanded_faces))

    gates = tuple(tuple(item) for item in site["primal_gates"])
    first_gate, second_gate = map(int, site["gate_vertices"])
    assert gates == (
        dual_to_primal[edge(z, first_gate)],
        dual_to_primal[edge(z, second_gate)],
    )
    root = tuple(witness["dual_root"])
    primal_root = tuple(witness["primal_root"])
    assert z not in root and dual_to_primal[root] == primal_root

    families, _, _ = lift.target_families(reduced, reduced_faces)
    vertices = tuple(sorted(reduced))
    matchings = tuple(
        wide.matching_from_colour(
            primal,
            reduced,
            dual_to_primal,
            lift.decode_colouring(vertices, encoded),
        )
        for encoded in families[root]
    )
    frozen = tuple(
        frozenset(tuple(item) for item in matching)
        for matching in witness["complete_family"]
    )
    assert matchings == frozen
    assert len(matchings) == len(set(matchings)) == 15
    common = set.intersection(*(set(matching) for matching in matchings))
    assert common == {primal_root, gates[1]}
    assert Counter(
        "".join("1" if gate in matching else "0" for gate in gates)
        for matching in matchings
    ) == Counter({"01": 12, "11": 3})

    opposition = base.square_opposition_graph(primal)
    assert not nx.has_path(opposition.subgraph(common), primal_root, gates[1])
    assert not base.opposite_on_square(primal, primal_root, gates[1])[0]
    for vertices4 in combinations(sorted(primal), 4):
        subgraph = primal.subgraph(vertices4)
        if subgraph.number_of_edges() != 4:
            continue
        if not nx.is_connected(subgraph):
            continue
        if set(dict(subgraph.degree()).values()) != {2}:
            continue
        cycle_edges = {edge(*item) for item in subgraph.edges()}
        if {primal_root, gates[1]} <= cycle_edges:
            assert set(primal_root) & set(gates[1]) or not base.opposite_on_square(
                primal, primal_root, gates[1]
            )[0]

    print("ORDER24_NONLOCAL_RESTRICTED_GATE_COLOOP_VERIFIED")


if __name__ == "__main__":
    main()
