# Short-gap complete-family nonlocality certificate

This bundle supports Note 144.  It reads only the permanent 323-record
ParentKill certificate, keeps the same 262 one-edge-gap records as Notes
140--143, and reconstructs their already specified parent and child fibres.
It generates no graph, site, root, order, or random instance.

Run from the AIMath project root:

~~~bash
uv run --python 3.12 --with 'networkx==3.6.1' python \
  units/barnette/computations/bundles/short-gap-complete-family-nonlocality/verify_cross_star_pairs.py \
  --counts-only

uv run --python 3.12 --with 'networkx==3.6.1' python \
  units/barnette/computations/bundles/short-gap-complete-family-nonlocality/verify_pair_local_recombination_closures.py

uv run --python 3.12 --with 'networkx==3.6.1' python \
  units/barnette/computations/bundles/short-gap-complete-family-nonlocality/verify_bad_bond_components.py

uv run --python 3.12 --with 'networkx==3.6.1' python \
  units/barnette/computations/bundles/short-gap-complete-family-nonlocality/verify_unique_extreme_complete_closure.py
~~~

The terminal markers are

~~~text
FROZEN_CROSS_STAR_COUNTS_VERIFIED
FROZEN_CROSS_STAR_PATTERNS_AUDITED
FROZEN_ALL_BAD_COMPONENT_HAS_REAL_COUNTEREXAMPLE
EXTREME_FAMILY_COMPLETE_CLOSURE_ANALYZED
~~~

The verifiers establish:

- 25 distinct-star bad-bond pairs share their exact gate path; 24 pairs
  have two nonrooted siblings and the unique extreme pair has two rooted
  siblings;
- the 24 failing pair-local recombination closures have size four or eight,
  contain exactly the original four rooted targets, and contain no internal
  automatic bond;
- among 352 nonempty rooted bond components, six are all bad, all are
  \(K_2\)'s, and four have a nonrooted sibling;
- the unique extreme family has the stated four-target difference matrix
  and fifty complete fixed-edge perfect matchings.

The finite minima and counts apply only to the frozen direct-root-square
legal-wide stratum through parent order 26.  The explicit negative examples
are independently checked to be connected, 3-connected, cubic, bipartite,
and planar.  None is a counterexample to ChildSupplement: every negative
family has automatic bonds elsewhere and recorded child supplements.
