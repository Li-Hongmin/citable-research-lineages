#!/usr/bin/env python3
"""Audit cross-star fingerprints in the already frozen short-gap records.

This is a bounded comparison, not a new graph search.  It asks whether the
four-target alternating-cycle pattern of the unique complete-family-extreme
record already occurs in non-extreme families whose gate siblings fail.
"""

from __future__ import annotations

from collections import Counter, defaultdict
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
SIBLING_PATH = (
    BARNETTE
    / "computations"
    / "bundles"
    / "short-gap-extreme-family-boundary"
    / "verify_frozen_gate_path_siblings.py"
)

sys.dont_write_bytecode = True


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


sibling_base = load_module(SIBLING_PATH, "cross_star_sibling_base")
base = sibling_base.base
classifier = base.classifier


def matching_key(matching):
    return tuple(sorted(matching))


def component_lengths(first, second):
    difference = first ^ second
    graph = nx.Graph()
    graph.add_edges_from(difference)
    return tuple(sorted(len(component) for component in nx.connected_components(graph)))


def bad_bond_data(graph, faces, all_matchings, record, short_edge):
    root = base.as_edge(record["root"])
    forced = base.as_edge(record["forced_gate"])
    surviving = base.as_edge(record["surviving_gate"])
    site = record["site"]
    selected = tuple(base.as_edge(item) for item in site["selected"])
    fibre = tuple(
        sorted(
            (
                matching
                for matching in all_matchings
                if classifier.is_root_target(graph, matching, root, forced)
            ),
            key=matching_key,
        )
    )
    sectors = (
        tuple(item for item in fibre if surviving not in item),
        tuple(item for item in fibre if surviving in item),
    )
    bonds = tuple(
        (first, second)
        for first in sectors[0]
        for second in sectors[1]
        if classifier.difference_component_count(first, second) == 1
    )
    expanded_site = {
        "face_index": int(site["face_index"]),
        "face_length": int(site["face_length"]),
        "indices": tuple(map(int, site["indices"])),
        "selected": selected,
    }
    child, _child_faces, local = classifier.expand_on_face(graph, faces, expanded_site)
    ua, ab, bv, xc, cd, dy, ad, bc = local
    old_vertices = set(graph)
    u = next(vertex for vertex in ua if vertex in old_vertices)
    v = next(vertex for vertex in bv if vertex in old_vertices)
    x = next(vertex for vertex in xc if vertex in old_vertices)
    y = next(vertex for vertex in dy if vertex in old_vertices)
    endpoint_paths = {
        frozenset((u, y)): frozenset((ua, ad, dy)),
        frozenset((v, x)): frozenset((bv, bc, xc)),
    }
    result = []
    for first, second in bonds:
        first_state = base.matching_state(first, selected)
        second_state = base.matching_state(second, selected)
        if {first_state, second_state} != {"11", "00"}:
            continue
        state00 = first if first_state == "00" else second
        state11 = second if state00 is first else first
        if short_edge in state00:
            continue
        paths = sibling_base.component_edge_sets(state11 ^ state00, selected)
        gate_path = next(path for path in paths if surviving in path)
        endpoints = frozenset(
            vertex
            for vertex in (u, v, x, y)
            if sum(vertex in item for item in gate_path) == 1
        )
        canonical = frozenset(state00 | frozenset((ad, bc)))
        flip_cycle = gate_path | endpoint_paths[endpoints]
        sibling = frozenset(canonical ^ flip_cycle)
        rooted_sibling = classifier.is_root_target(child, sibling, root, forced)
        result.append(
            {
                "state11": state11,
                "state00": state00,
                "gate_path": gate_path,
                "rooted_sibling": rooted_sibling,
                "bond_length": len(state11 ^ state00),
            }
        )
    profile, _ = base.bond_profile(fibre, surviving, selected, short_edge)
    automatic = sum(
        profile[label]
        for label in ("11-11", "11-10", "11-01", "11-00/h-in")
    )
    return fibre, result, automatic


def pair_fingerprint(first, second):
    m0, n0 = first["state11"], first["state00"]
    m1, n1 = second["state11"], second["state00"]
    return (
        first["bond_length"],
        second["bond_length"],
        component_lengths(m0, m1),
        component_lengths(n0, n1),
        component_lengths(m0, n1),
        component_lengths(m1, n0),
        first["gate_path"] == second["gate_path"],
    )


def component_sets(first, second):
    difference = first ^ second
    graph = nx.Graph()
    graph.add_edges_from(difference)
    return tuple(
        frozenset(item for item in difference if set(item) <= component)
        for component in nx.connected_components(graph)
    )


def recombination_closure(matchings):
    closure = set(matchings)
    changed = True
    while changed:
        changed = False
        current = tuple(closure)
        for first_index in range(len(current)):
            for second_index in range(first_index + 1, len(current)):
                first, second = current[first_index], current[second_index]
                components = component_sets(first, second)
                # Each component flip preserves perfect matching status.
                for mask in range(1 << len(components)):
                    choice = frozenset().union(
                        *(
                            components[index]
                            for index in range(len(components))
                            if mask >> index & 1
                        )
                    )
                    candidate = frozenset(first ^ choice)
                    if candidate not in closure:
                        closure.add(candidate)
                        changed = True
    return frozenset(closure)


def main():
    frozen = json.loads(base.FROZEN_PATH.read_text())
    fingerprint_histogram = Counter()
    outcome_histogram = Counter()
    exact_rows = []
    failure_closure_automatic = Counter()
    failure_external_distance = Counter()
    failure_automatic_bond_incidence = Counter()
    failure_record_keys = set()
    distinct_cross_star_pairs = 0
    common_gate_pairs = 0
    for record in frozen["hits"]:
        graph, faces, all_matchings = base.graph_data(str(record["source_graph6"]))
        short_edge = base.one_edge_gap(record, faces)
        if short_edge is None:
            continue
        _fibre, bonds, automatic = bad_bond_data(
            graph, faces, all_matchings, record, short_edge
        )
        for first_index in range(len(bonds)):
            for second_index in range(first_index + 1, len(bonds)):
                first, second = bonds[first_index], bonds[second_index]
                if (
                    first["state11"] == second["state11"]
                    or first["state00"] == second["state00"]
                ):
                    continue
                distinct_cross_star_pairs += 1
                fingerprint = pair_fingerprint(first, second)
                fingerprint_histogram[fingerprint] += 1
                outcomes = (first["rooted_sibling"], second["rooted_sibling"])
                outcome_histogram[(fingerprint[-1], automatic == 0, sum(outcomes))] += 1
                if fingerprint[-1]:
                    common_gate_pairs += 1
                if fingerprint[-1] and sum(outcomes) == 0:
                    failure_record_keys.add(
                        (
                            str(record["source_graph6"]),
                            tuple(record["root"]),
                            tuple(record["forced_gate"]),
                            tuple(record["surviving_gate"]),
                            int(record["site"]["face_index"]),
                            tuple(record["site"]["indices"]),
                        )
                    )
                    four = (
                        first["state11"],
                        first["state00"],
                        second["state11"],
                        second["state00"],
                    )
                    closure = recombination_closure(four)
                    root = base.as_edge(record["root"])
                    forced = base.as_edge(record["forced_gate"])
                    surviving = base.as_edge(record["surviving_gate"])
                    selected = tuple(
                        base.as_edge(item) for item in record["site"]["selected"]
                    )
                    rooted_closure = tuple(
                        item
                        for item in closure
                        if classifier.is_root_target(graph, item, root, forced)
                    )
                    sectors = (
                        tuple(item for item in rooted_closure if surviving not in item),
                        tuple(item for item in rooted_closure if surviving in item),
                    )
                    automatic_inside = 0
                    automatic_endpoints = set()
                    automatic_bonds_full = []
                    for low in sectors[0]:
                        for high in sectors[1]:
                            if classifier.difference_component_count(low, high) != 1:
                                continue
                            states = {
                                base.matching_state(low, selected),
                                base.matching_state(high, selected),
                            }
                            state00 = low if base.matching_state(low, selected) == "00" else high
                            if not (states == {"11", "00"} and short_edge not in state00):
                                automatic_inside += 1
                                automatic_endpoints.update((low, high))
                    failure_closure_automatic[
                        (len(closure), len(rooted_closure), automatic_inside > 0)
                    ] += 1
                    full_fixed = tuple(
                        matching
                        for matching in all_matchings
                        if root in matching and forced in matching
                    )
                    full_rooted = tuple(
                        matching
                        for matching in full_fixed
                        if classifier.is_root_target(graph, matching, root, forced)
                    )
                    full_sectors = (
                        tuple(item for item in full_rooted if surviving not in item),
                        tuple(item for item in full_rooted if surviving in item),
                    )
                    for low in full_sectors[0]:
                        for high in full_sectors[1]:
                            if classifier.difference_component_count(low, high) != 1:
                                continue
                            states = {
                                base.matching_state(low, selected),
                                base.matching_state(high, selected),
                            }
                            state00 = low if base.matching_state(low, selected) == "00" else high
                            if not (states == {"11", "00"} and short_edge not in state00):
                                automatic_endpoints.update((low, high))
                                automatic_bonds_full.append((low, high))
                    assert automatic_endpoints
                    touches_closure = sum(
                        bool({low, high} & set(closure))
                        for low, high in automatic_bonds_full
                    )
                    failure_automatic_bond_incidence[
                        (touches_closure > 0, touches_closure)
                    ] += 1
                    # Exchange distance in the complete fixed-edge PM graph.
                    distance = {item: 0 for item in closure}
                    frontier = list(closure)
                    while frontier and not any(item in automatic_endpoints for item in distance):
                        current = frontier.pop(0)
                        for candidate in full_fixed:
                            if candidate in distance:
                                continue
                            if classifier.difference_component_count(current, candidate) == 1:
                                distance[candidate] = distance[current] + 1
                                frontier.append(candidate)
                    minimum = min(
                        distance[item]
                        for item in automatic_endpoints
                        if item in distance
                    )
                    failure_external_distance[minimum] += 1
                target = (
                    14,
                    14,
                    (4, 4),
                    (6, 6),
                    (4, 12),
                    (4, 12),
                    True,
                )
                if fingerprint == target:
                    exact_rows.append(
                        {
                            "order": int(record["parent_order"]),
                            "graph6": str(record["source_graph6"]),
                            "root": tuple(record["root"]),
                            "forced": tuple(record["forced_gate"]),
                            "surviving": tuple(record["surviving_gate"]),
                            "selected": tuple(tuple(item) for item in record["site"]["selected"]),
                            "automatic_bonds": automatic,
                            "sibling_successes": sum(outcomes),
                        }
                    )

    print("distinct-cross-star-pairs", distinct_cross_star_pairs)
    print("common-gate-pairs", common_gate_pairs)
    print("outcomes-by-common/extreme/success-count")
    for key, count in sorted(outcome_histogram.items()):
        print(key, count)
    print("exact-extreme-four-target-fingerprint-rows", len(exact_rows))
    for row in exact_rows:
        print(row)
    print("fingerprint-types", len(fingerprint_histogram))
    print("common-gate-double-failure-recombination-closure")
    for key, count in sorted(failure_closure_automatic.items()):
        print(key, count)
    print("common-gate-double-failure-records", len(failure_record_keys))
    print("minimum-exchange-distance-to-automatic-endpoint", dict(sorted(failure_external_distance.items())))
    print("automatic-bonds-touching-recombination-closure", dict(sorted(failure_automatic_bond_incidence.items())))
    assert distinct_cross_star_pairs == 103
    assert common_gate_pairs == 25
    assert outcome_histogram[(True, False, 0)] == 24
    assert outcome_histogram[(True, True, 2)] == 1
    assert failure_closure_automatic == Counter(
        {(4, 4, False): 16, (8, 4, False): 8}
    )
    assert len(failure_record_keys) == 8
    assert failure_external_distance == Counter({0: 24})
    assert failure_automatic_bond_incidence == Counter(
        {(True, 4): 12, (True, 6): 12}
    )
    assert any(row["automatic_bonds"] == 0 for row in exact_rows)
    print("FROZEN_CROSS_STAR_PATTERNS_AUDITED")


if __name__ == "__main__":
    main()
