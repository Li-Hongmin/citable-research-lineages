#!/usr/bin/env python3
"""Test cross-star gate-path sibling statements in the frozen 262 records.

This script does not generate parent graphs, sites, roots, or orders.  It
reads the permanent through-order-26 ParentKill records, keeps the 262
one-edge-gap records, reconstructs only their recorded parent/child fibres,
and tests two nested antecedents for pairs of h-avoiding 11--00 bonds with
distinct state-11 endpoints:

* the two bonds have exactly the same surviving-gate exterior path P_g;
* more weakly, their P_g paths induce the same ordered-site boundary
  transition (equivalently the same Xuy/Xvx sibling cell).

The conclusion tested is that at least one of the two canonical gate-path
siblings is rooted-admitted.  The unique complete-family-extreme record is
also given a full 4x4 symmetric-difference component audit.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations
import argparse
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
LOCAL_STAR_PATH = (
    BARNETTE
    / "computations"
    / "bundles"
    / "short-gap-local-star-extremality-counterexample"
    / "verify_frozen_local_star_extremes.py"
)

sys.dont_write_bytecode = True


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


local_star = load_module(LOCAL_STAR_PATH, "frozen_cross_star_local_base")
base = local_star.base
sibling_base = local_star.sibling_base
classifier = local_star.classifier


def matching_key(matching):
    return tuple(sorted(matching))


def serial_matching(matching):
    return [list(item) for item in matching_key(matching)]


def serial_edges(edges):
    return [list(item) for item in sorted(edges)]


def record_key(record):
    site = record["site"]
    return (
        str(record["source_graph6"]),
        tuple(record["root"]),
        tuple(record["forced_gate"]),
        tuple(record["surviving_gate"]),
        int(site["face_index"]),
        tuple(site["indices"]),
    )


def path_vertices(path_edges):
    path = nx.Graph()
    path.add_edges_from(path_edges)
    assert nx.is_connected(path)
    endpoints = sorted(vertex for vertex, degree in path.degree() if degree == 1)
    assert len(endpoints) == 2
    order = [endpoints[0]]
    previous = None
    current = endpoints[0]
    while current != endpoints[1]:
        choices = sorted(vertex for vertex in path[current] if vertex != previous)
        assert len(choices) == 1
        previous, current = current, choices[0]
        order.append(current)
    assert len(order) == path.number_of_edges() + 1
    return tuple(order)


def difference_parts(first, second):
    difference = first ^ second
    if not difference:
        return ()
    graph = nx.Graph()
    graph.add_edges_from(difference)
    parts = []
    for vertices in nx.connected_components(graph):
        edges = frozenset(
            item for item in difference if set(item) <= set(vertices)
        )
        cycle = nx.Graph()
        cycle.add_edges_from(edges)
        assert set(dict(cycle.degree()).values()) == {2}
        parts.append(edges)
    return tuple(sorted(parts, key=lambda item: (len(item), sorted(item))))


def complement_signature(graph, matching, root):
    components = local_star.complement_components(graph, matching)
    separated = (
        len(components) == 2
        and all(
            len(set(root) & set(component)) == 1 for component in components
        )
    )
    return len(components), separated, components


def classify_record(record):
    graph6 = str(record["source_graph6"])
    graph, faces, all_matchings = base.graph_data(graph6)
    short_edge = base.one_edge_gap(record, faces)
    if short_edge is None:
        return None

    root = base.as_edge(record["root"])
    forced_gate = base.as_edge(record["forced_gate"])
    surviving_gate = base.as_edge(record["surviving_gate"])
    site = record["site"]
    selected = tuple(base.as_edge(item) for item in site["selected"])
    fibre = tuple(
        sorted(
            (
                matching
                for matching in all_matchings
                if classifier.is_root_target(graph, matching, root, forced_gate)
            ),
            key=matching_key,
        )
    )
    assert len(fibre) == int(record["parent_fibre_size"])
    sectors = (
        tuple(item for item in fibre if surviving_gate not in item),
        tuple(item for item in fibre if surviving_gate in item),
    )
    bonds = tuple(
        (first, second)
        for first in sectors[0]
        for second in sectors[1]
        if classifier.difference_component_count(first, second) == 1
    )
    assert len(bonds) == int(record["parent_crossings"])
    profile, profile_count = base.bond_profile(
        fibre, surviving_gate, selected, short_edge
    )
    assert profile_count == len(bonds)
    automatic_labels = {"11-11", "11-10", "11-01", "11-00/h-in"}
    automatic_count = sum(profile[label] for label in automatic_labels)

    expanded_site = {
        "face_index": int(site["face_index"]),
        "face_length": int(site["face_length"]),
        "indices": tuple(map(int, site["indices"])),
        "selected": selected,
    }
    child, _child_faces, local = classifier.expand_on_face(
        graph, faces, expanded_site
    )

    bad_rows = []
    for first, second in bonds:
        first_state = base.matching_state(first, selected)
        second_state = base.matching_state(second, selected)
        if {first_state, second_state} != {"11", "00"}:
            continue
        state11 = first if first_state == "11" else second
        state00 = first if first_state == "00" else second
        if short_edge in state00:
            continue

        canonical, sibling, target_cell, gate_path, flip_cycle = (
            local_star.gate_path_sibling(
                graph,
                child,
                local,
                selected,
                surviving_gate,
                state11,
                state00,
            )
        )
        rooted = classifier.is_root_target(child, sibling, root, forced_gate)
        component_count, root_separated, components = complement_signature(
            child, sibling, root
        )
        ordered_path = path_vertices(gate_path)
        transition = tuple(sorted((ordered_path[0], ordered_path[-1])))
        bad_rows.append(
            {
                "state11": state11,
                "state00": state00,
                "state11_index": fibre.index(state11),
                "state00_index": fibre.index(state00),
                "gate_path": gate_path,
                "gate_path_vertices": ordered_path,
                "boundary_transition": transition,
                "target_cell": target_cell,
                "flip_cycle": flip_cycle,
                "canonical": canonical,
                "sibling": sibling,
                "sibling_rooted": rooted,
                "sibling_component_count": component_count,
                "sibling_root_separated": root_separated,
                "sibling_components": components,
            }
        )

    return {
        "record": record,
        "graph": graph,
        "faces": faces,
        "child": child,
        "local": local,
        "root": root,
        "forced_gate": forced_gate,
        "surviving_gate": surviving_gate,
        "selected": selected,
        "short_edge": short_edge,
        "fibre": fibre,
        "bonds": bonds,
        "profile": profile,
        "automatic_count": automatic_count,
        "bad_rows": tuple(bad_rows),
    }


def pair_key(first, second):
    return tuple(sorted((
        (first["state11_index"], first["state00_index"]),
        (second["state11_index"], second["state00_index"]),
    )))


def qualifying_pairs(rows, key):
    pairs = []
    for first, second in combinations(rows, 2):
        if first["state11"] == second["state11"]:
            continue
        if first[key] != second[key]:
            continue
        pairs.append((first, second))
    return tuple(pairs)


def serial_bad_row(row):
    return {
        "parent_fibre_indices_11_00": [
            row["state11_index"], row["state00_index"]
        ],
        "gate_path_vertices": list(row["gate_path_vertices"]),
        "gate_path_edges": serial_edges(row["gate_path"]),
        "boundary_transition": list(row["boundary_transition"]),
        "target_cell": row["target_cell"],
        "sibling_rooted": row["sibling_rooted"],
        "sibling_complement_component_count": row[
            "sibling_component_count"
        ],
        "sibling_root_separated": row["sibling_root_separated"],
    }


def serial_pair(first, second):
    return {
        "bond_indices": [list(item) for item in pair_key(first, second)],
        "at_least_one_sibling_rooted": (
            first["sibling_rooted"] or second["sibling_rooted"]
        ),
        "first": serial_bad_row(first),
        "second": serial_bad_row(second),
    }


def serial_record_summary(row, exact_pairs, transition_pairs):
    record = row["record"]
    distinct_stars = sorted(
        {item["state11_index"] for item in row["bad_rows"]}
    )
    return {
        "parent_order": record["parent_order"],
        "source_graph6": record["source_graph6"],
        "root": record["root"],
        "forced_gate": record["forced_gate"],
        "surviving_gate": record["surviving_gate"],
        "site": record["site"],
        "short_edge_h": list(row["short_edge"]),
        "parent_fibre_size": len(row["fibre"]),
        "parent_bond_profile": dict(sorted(row["profile"].items())),
        "complete_family_extreme": row["automatic_count"] == 0,
        "recorded_child_supplement_bonds": record["new_cell_crossings"],
        "bad_bond_count": len(row["bad_rows"]),
        "distinct_bad_state11_stars": distinct_stars,
        "bad_bonds": [serial_bad_row(item) for item in row["bad_rows"]],
        "same_exact_gate_path_distinct_star_pairs": [
            serial_pair(*pair) for pair in exact_pairs
        ],
        "same_boundary_transition_distinct_star_pairs": [
            serial_pair(*pair) for pair in transition_pairs
        ],
    }


def extreme_matrix(row):
    fibre = row["fibre"]
    assert len(fibre) == 4
    selected = row["selected"]
    surviving_gate = row["surviving_gate"]
    entries = []
    matrix = []
    for first_index, first in enumerate(fibre):
        matrix_row = []
        for second_index, second in enumerate(fibre):
            parts = difference_parts(first, second)
            matrix_row.append(len(parts))
            if first_index < second_index:
                entries.append(
                    {
                        "indices": [first_index, second_index],
                        "component_edge_lengths": [len(part) for part in parts],
                        "difference_edges": serial_edges(first ^ second),
                    }
                )
        matrix.append(matrix_row)

    bad_rows = row["bad_rows"]
    assert len(bad_rows) == 2
    first, second = bad_rows
    m0, n0 = first["state11"], first["state00"]
    m1, n1 = second["state11"], second["state00"]
    cross_pairs = ((m0, n1), (m1, n0))
    bad_differences = (m0 ^ n0, m1 ^ n1)
    star_difference = m0 ^ m1
    leaf_difference = n0 ^ n1

    # The h-toggle uses the residual path whose endpoints are h's endpoints.
    toggles = []
    for item in bad_rows:
        paths = sibling_base.component_edge_sets(
            item["state11"] ^ item["state00"], selected
        )
        h_paths = []
        for path in paths:
            vertices = path_vertices(path)
            if {vertices[0], vertices[-1]} == set(row["short_edge"]):
                h_paths.append(path)
        h_paths = tuple(h_paths)
        assert len(h_paths) == 1
        toggle_cycle = frozenset(h_paths[0] | {row["short_edge"]})
        toggled = frozenset(item["state00"] ^ toggle_cycle)
        assert sibling_base.is_perfect_matching(row["graph"], toggled)
        toggles.append(
            {
                "bond_indices_11_00": [
                    item["state11_index"], item["state00_index"]
                ],
                "toggle_path_vertices": list(path_vertices(h_paths[0])),
                "toggle_cycle": serial_edges(toggle_cycle),
                "toggle_matching": serial_matching(toggled),
                "toggle_complement_component_count": complement_signature(
                    row["graph"], toggled, row["root"]
                )[0],
                "gate_sibling_target_cell": item["target_cell"],
                "gate_sibling_path_vertices": list(
                    item["gate_path_vertices"]
                ),
                "gate_sibling_rooted": item["sibling_rooted"],
                "gate_sibling_component_count": item[
                    "sibling_component_count"
                ],
            }
        )

    return {
        "targets": [
            {
                "index": index,
                "state": base.matching_state(matching, selected),
                "sector": int(surviving_gate in matching),
                "contains_h": row["short_edge"] in matching,
                "matching": serial_matching(matching),
            }
            for index, matching in enumerate(fibre)
        ],
        "difference_component_count_matrix": matrix,
        "pairwise_differences": entries,
        "bad_bond_indices_11_00": [
            [item["state11_index"], item["state00_index"]]
            for item in bad_rows
        ],
        "bad_difference_cycles_equal": bad_differences[0] == bad_differences[1],
        "bad_difference_cycle_intersection_size": len(
            bad_differences[0] & bad_differences[1]
        ),
        "bad_difference_cycle_union_size": len(
            bad_differences[0] | bad_differences[1]
        ),
        "opposite_side_differences_equal": star_difference == leaf_difference,
        "four_corner_xor_empty": not (m0 ^ n0 ^ m1 ^ n1),
        "cross_pair_component_counts": [
            classifier.difference_component_count(*pair)
            for pair in cross_pairs
        ],
        "cross_pair_component_lengths": [
            [len(part) for part in difference_parts(*pair)]
            for pair in cross_pairs
        ],
        "h_toggles_and_gate_siblings": toggles,
        "same_exact_gate_path": first["gate_path"] == second["gate_path"],
        "same_boundary_transition": (
            first["boundary_transition"] == second["boundary_transition"]
        ),
        "same_target_cell": first["target_cell"] == second["target_cell"],
    }


def compact_record_index(row):
    record = row["record"]
    exact_pairs = qualifying_pairs(row["bad_rows"], "gate_path")
    transition_pairs = qualifying_pairs(
        row["bad_rows"], "boundary_transition"
    )
    return {
        "parent_order": record["parent_order"],
        "source_graph6": record["source_graph6"],
        "root": record["root"],
        "forced_gate": record["forced_gate"],
        "surviving_gate": record["surviving_gate"],
        "site_face_index": record["site"]["face_index"],
        "site_indices": record["site"]["indices"],
        "parent_bond_profile": dict(sorted(row["profile"].items())),
        "complete_family_extreme": row["automatic_count"] == 0,
        "bad_bond_count": len(row["bad_rows"]),
        "distinct_bad_state11_stars": sorted(
            {item["state11_index"] for item in row["bad_rows"]}
        ),
        "same_exact_gate_path_pairs": len(exact_pairs),
        "same_exact_gate_path_counterexample_pairs": sum(
            not (first["sibling_rooted"] or second["sibling_rooted"])
            for first, second in exact_pairs
        ),
        "same_boundary_transition_pairs": len(transition_pairs),
        "same_boundary_transition_counterexample_pairs": sum(
            not (first["sibling_rooted"] or second["sibling_rooted"])
            for first, second in transition_pairs
        ),
        "recorded_child_supplement_bonds": record["new_cell_crossings"],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--full",
        action="store_true",
        help="print every bad bond and every qualifying pair",
    )
    parser.add_argument(
        "--counts-only",
        action="store_true",
        help="print only census counts and first-pair identities",
    )
    parser.add_argument(
        "--index-only",
        action="store_true",
        help="print the complete compact index of multi-star records",
    )
    arguments = parser.parse_args()
    frozen = json.loads(base.FROZEN_PATH.read_text())
    assert len(frozen["hits"]) == 323
    records = sorted(
        frozen["hits"],
        key=lambda record: (
            int(record["parent_order"]),
            str(record["source_graph6"]),
            record["root"],
            record["forced_gate"],
            record["surviving_gate"],
            record["site"]["face_index"],
            record["site"]["indices"],
        ),
    )

    short_gap_rows = []
    multi_star_rows = []
    exact_pair_records = []
    transition_pair_records = []
    exact_counterexamples = []
    transition_counterexamples = []
    exact_pairs_total = 0
    transition_pairs_total = 0

    for record in records:
        row = classify_record(record)
        if row is None:
            continue
        short_gap_rows.append(row)
        bad_rows = row["bad_rows"]
        distinct_stars = {item["state11"] for item in bad_rows}
        if len(bad_rows) < 2 or len(distinct_stars) < 2:
            continue
        multi_star_rows.append(row)
        exact_pairs = qualifying_pairs(bad_rows, "gate_path")
        transition_pairs = qualifying_pairs(
            bad_rows, "boundary_transition"
        )
        if exact_pairs:
            exact_pair_records.append(row)
        if transition_pairs:
            transition_pair_records.append(row)
        exact_pairs_total += len(exact_pairs)
        transition_pairs_total += len(transition_pairs)
        exact_counterexamples.extend(
            (row, first, second)
            for first, second in exact_pairs
            if not (first["sibling_rooted"] or second["sibling_rooted"])
        )
        transition_counterexamples.extend(
            (row, first, second)
            for first, second in transition_pairs
            if not (first["sibling_rooted"] or second["sibling_rooted"])
        )

    assert len(short_gap_rows) == 262
    extreme_rows = tuple(
        row
        for row in short_gap_rows
        if row["automatic_count"] == 0 and row["bad_rows"]
    )
    assert len(extreme_rows) == 1
    extreme = extreme_rows[0]

    def first_counterexample(items, full=False):
        if not items:
            return None
        row, first, second = items[0]
        if full:
            summary = serial_record_summary(
                row,
                qualifying_pairs(row["bad_rows"], "gate_path"),
                qualifying_pairs(row["bad_rows"], "boundary_transition"),
            )
        else:
            summary = compact_record_index(row)
            summary.update(
                {
                    "site": row["record"]["site"],
                    "short_edge_h": list(row["short_edge"]),
                }
            )
        summary["counterexample_pair"] = serial_pair(first, second)
        summary["sibling_complement_components"] = [
            [list(component) for component in item["sibling_components"]]
            for item in (first, second)
        ]
        summary["state11_matchings"] = [
            serial_matching(item["state11"]) for item in (first, second)
        ]
        summary["state00_matchings"] = [
            serial_matching(item["state00"]) for item in (first, second)
        ]
        summary["sibling_matchings"] = [
            serial_matching(item["sibling"]) for item in (first, second)
        ]
        return summary

    if arguments.counts_only:
        compact_extreme = extreme_matrix(extreme)
        def first_identity(items):
            if not items:
                return None
            row, first, second = items[0]
            record = row["record"]
            return {
                "parent_order": record["parent_order"],
                "source_graph6": record["source_graph6"],
                "root": record["root"],
                "forced_gate": record["forced_gate"],
                "surviving_gate": record["surviving_gate"],
                "site": record["site"],
                "short_edge_h": list(row["short_edge"]),
                "parent_bond_profile": dict(sorted(row["profile"].items())),
                "complete_family_extreme": row["automatic_count"] == 0,
                "bond_indices": [
                    [first["state11_index"], first["state00_index"]],
                    [second["state11_index"], second["state00_index"]],
                ],
                "gate_paths": [
                    list(first["gate_path_vertices"]),
                    list(second["gate_path_vertices"]),
                ],
                "target_cells": [first["target_cell"], second["target_cell"]],
                "sibling_component_counts": [
                    first["sibling_component_count"],
                    second["sibling_component_count"],
                ],
            }

        counts_payload = {
            "scope": {
                "frozen_parentkill_hits": len(frozen["hits"]),
                "one_edge_gap_parentkill_records": len(short_gap_rows),
                "generated_new_graphs_sites_orders_or_random_instances": False,
            },
            "multi_bad_bond_multi_state11_star_records": len(multi_star_rows),
            "multi_star_records_by_parent_order": dict(sorted(Counter(
                int(row["record"]["parent_order"])
                for row in multi_star_rows
            ).items())),
            "records_with_same_exact_gate_path": len(exact_pair_records),
            "same_exact_gate_path_pairs": exact_pairs_total,
            "same_exact_gate_path_counterexamples": len(exact_counterexamples),
            "exact_counterexamples_by_order": dict(sorted(Counter(
                int(row["record"]["parent_order"])
                for row, _first, _second in exact_counterexamples
            ).items())),
            "first_exact_counterexample": first_identity(exact_counterexamples),
            "records_with_same_boundary_transition": len(
                transition_pair_records
            ),
            "same_boundary_transition_pairs": transition_pairs_total,
            "same_boundary_transition_counterexamples": len(
                transition_counterexamples
            ),
            "transition_counterexamples_by_order": dict(sorted(Counter(
                int(row["record"]["parent_order"])
                for row, _first, _second in transition_counterexamples
            ).items())),
            "first_transition_counterexample": first_identity(
                transition_counterexamples
            ),
            "complete_family_extreme_records": len(extreme_rows),
            "extreme_same_exact_gate_path": (
                extreme["bad_rows"][0]["gate_path"]
                == extreme["bad_rows"][1]["gate_path"]
            ),
            "extreme_both_siblings_rooted": all(
                item["sibling_rooted"] for item in extreme["bad_rows"]
            ),
            "extreme_four_by_four": {
                "target_state_sector": [
                    [item["state"], item["sector"]]
                    for item in compact_extreme["targets"]
                ],
                "difference_component_count_matrix": compact_extreme[
                    "difference_component_count_matrix"
                ],
                "pair_component_lengths": {
                    "-".join(map(str, item["indices"])): item[
                        "component_edge_lengths"
                    ]
                    for item in compact_extreme["pairwise_differences"]
                },
                "bad_bond_indices_11_00": compact_extreme[
                    "bad_bond_indices_11_00"
                ],
                "bad_difference_cycles_equal": compact_extreme[
                    "bad_difference_cycles_equal"
                ],
                "bad_difference_cycle_intersection_size": compact_extreme[
                    "bad_difference_cycle_intersection_size"
                ],
                "bad_difference_cycle_union_size": compact_extreme[
                    "bad_difference_cycle_union_size"
                ],
                "opposite_side_differences_equal": compact_extreme[
                    "opposite_side_differences_equal"
                ],
                "four_corner_xor_empty": compact_extreme[
                    "four_corner_xor_empty"
                ],
                "cross_pair_component_counts": compact_extreme[
                    "cross_pair_component_counts"
                ],
                "cross_pair_component_lengths": compact_extreme[
                    "cross_pair_component_lengths"
                ],
                "same_exact_gate_path": compact_extreme[
                    "same_exact_gate_path"
                ],
                "same_boundary_transition": compact_extreme[
                    "same_boundary_transition"
                ],
                "toggle_and_sibling_signatures": [
                    {
                        "bond_indices_11_00": item[
                            "bond_indices_11_00"
                        ],
                        "toggle_path_vertices": item[
                            "toggle_path_vertices"
                        ],
                        "toggle_complement_component_count": item[
                            "toggle_complement_component_count"
                        ],
                        "gate_sibling_path_vertices": item[
                            "gate_sibling_path_vertices"
                        ],
                        "gate_sibling_target_cell": item[
                            "gate_sibling_target_cell"
                        ],
                        "gate_sibling_component_count": item[
                            "gate_sibling_component_count"
                        ],
                        "gate_sibling_rooted": item[
                            "gate_sibling_rooted"
                        ],
                    }
                    for item in compact_extreme[
                        "h_toggles_and_gate_siblings"
                    ]
                ],
            },
        }
        print(json.dumps(counts_payload, indent=2, sort_keys=True))
        print("FROZEN_CROSS_STAR_COUNTS_VERIFIED")
        return

    if arguments.index_only:
        print(json.dumps(
            {
                "multi_star_records": [
                    compact_record_index(row) for row in multi_star_rows
                ]
            },
            indent=2,
            sort_keys=True,
        ))
        print("FROZEN_CROSS_STAR_RECORD_INDEX_VERIFIED")
        return

    multi_star_summaries = []
    for row in multi_star_rows:
        multi_star_summaries.append(
            serial_record_summary(
                row,
                qualifying_pairs(row["bad_rows"], "gate_path"),
                qualifying_pairs(row["bad_rows"], "boundary_transition"),
            )
        )

    payload = {
        "scope": {
            "frozen_parentkill_hits": len(frozen["hits"]),
            "one_edge_gap_parentkill_records": len(short_gap_rows),
            "generated_new_graphs_sites_orders_or_random_instances": False,
        },
        "multi_bad_bond_multi_state11_star_records": len(multi_star_rows),
        "records_with_same_exact_gate_path_across_distinct_stars": len(
            exact_pair_records
        ),
        "same_exact_gate_path_distinct_star_pairs": exact_pairs_total,
        "same_exact_gate_path_counterexample_pairs": len(exact_counterexamples),
        "records_with_same_boundary_transition_across_distinct_stars": len(
            transition_pair_records
        ),
        "same_boundary_transition_distinct_star_pairs": transition_pairs_total,
        "same_boundary_transition_counterexample_pairs": len(
            transition_counterexamples
        ),
        "multi_star_records_by_parent_order": dict(
            sorted(Counter(
                int(row["record"]["parent_order"])
                for row in multi_star_rows
            ).items())
        ),
        "exact_gate_path_counterexamples_by_parent_order": dict(
            sorted(Counter(
                int(row["record"]["parent_order"])
                for row, _first, _second in exact_counterexamples
            ).items())
        ),
        "boundary_transition_counterexamples_by_parent_order": dict(
            sorted(Counter(
                int(row["record"]["parent_order"])
                for row, _first, _second in transition_counterexamples
            ).items())
        ),
        "first_exact_gate_path_counterexample": first_counterexample(
            exact_counterexamples, full=arguments.full
        ),
        "first_boundary_transition_counterexample": first_counterexample(
            transition_counterexamples, full=arguments.full
        ),
        "multi_star_records": (
            multi_star_summaries
            if arguments.full
            else [compact_record_index(row) for row in multi_star_rows]
        ),
        "unique_complete_family_extreme": {
            "record": serial_record_summary(
                extreme,
                qualifying_pairs(extreme["bad_rows"], "gate_path"),
                qualifying_pairs(
                    extreme["bad_rows"], "boundary_transition"
                ),
            ),
            "four_by_four_audit": extreme_matrix(extreme),
        },
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    if exact_counterexamples:
        print("FROZEN_EXACT_GATE_PATH_CROSS_STAR_CLAIM_REFUTED")
    else:
        print("FROZEN_EXACT_GATE_PATH_CROSS_STAR_CLAIM_SUPPORTED")
    if transition_counterexamples:
        print("FROZEN_BOUNDARY_TRANSITION_CROSS_STAR_CLAIM_REFUTED")
    else:
        print("FROZEN_BOUNDARY_TRANSITION_CROSS_STAR_CLAIM_SUPPORTED")


if __name__ == "__main__":
    main()
