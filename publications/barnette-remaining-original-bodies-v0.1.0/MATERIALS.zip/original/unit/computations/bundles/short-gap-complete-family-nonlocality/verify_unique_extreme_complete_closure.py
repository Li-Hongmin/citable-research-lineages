#!/usr/bin/env python3
"""Reconstruct the complete PM closure around the unique frozen extreme family.

This reads only the already frozen through-order-26 certificate.  It creates no
graphs, sites, or neighbouring orders.  The purpose is to expose which
cross-star relations are literal consequences of componentwise alternating
cycle recombination and which are only features of the four rooted targets.
"""

from __future__ import annotations

from collections import defaultdict
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
BASE_PATH = (
    BARNETTE
    / "computations"
    / "bundles"
    / "short-gap-extreme-family-boundary"
    / "verify_frozen_short_gap_extreme_families.py"
)

sys.dont_write_bytecode = True


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


base = load_module(BASE_PATH, "cross_star_extreme_base")
classifier = base.classifier
edge = base.edge


def matching_key(matching):
    return tuple(sorted(matching))


def difference_components(first, second):
    difference = first ^ second
    graph = nx.Graph()
    graph.add_edges_from(difference)
    return tuple(
        frozenset(
            item
            for item in difference
            if set(item) <= component
        )
        for component in sorted(
            nx.connected_components(graph),
            key=lambda vertices: (len(vertices), sorted(vertices)),
        )
    )


def complement_signature(graph, matching, root):
    complement = graph.copy()
    complement.remove_edges_from(matching)
    components = tuple(
        sorted(
            (frozenset(item) for item in nx.connected_components(complement)),
            key=lambda item: (len(item), tuple(sorted(item))),
        )
    )
    root_parts = tuple(
        next(index for index, component in enumerate(components) if vertex in component)
        for vertex in root
    )
    return tuple(len(item) for item in components), root_parts


def serial_component(component):
    return tuple(sorted(component))


def find_extreme_record():
    frozen = json.loads(base.FROZEN_PATH.read_text())
    hits = []
    automatic = {"11-11", "11-10", "11-01", "11-00/h-in"}
    for record in frozen["hits"]:
        graph, faces, all_matchings = base.graph_data(str(record["source_graph6"]))
        short_edge = base.one_edge_gap(record, faces)
        if short_edge is None:
            continue
        root = base.as_edge(record["root"])
        forced = base.as_edge(record["forced_gate"])
        surviving = base.as_edge(record["surviving_gate"])
        selected = tuple(base.as_edge(item) for item in record["site"]["selected"])
        fibre = tuple(
            matching
            for matching in all_matchings
            if classifier.is_root_target(graph, matching, root, forced)
        )
        profile, count = base.bond_profile(fibre, surviving, selected, short_edge)
        if count and sum(profile[label] for label in automatic) == 0:
            hits.append((record, graph, faces, all_matchings, short_edge))
    assert len(hits) == 1
    return hits[0]


def main():
    record, graph, faces, all_matchings, short_edge = find_extreme_record()
    root = base.as_edge(record["root"])
    forced = base.as_edge(record["forced_gate"])
    surviving = base.as_edge(record["surviving_gate"])
    selected = tuple(base.as_edge(item) for item in record["site"]["selected"])
    rooted = tuple(
        sorted(
            (
                matching
                for matching in all_matchings
                if classifier.is_root_target(graph, matching, root, forced)
            ),
            key=matching_key,
        )
    )
    fixed = tuple(
        sorted(
            (
                matching
                for matching in all_matchings
                if root in matching and forced in matching
            ),
            key=matching_key,
        )
    )
    fixed_index = {matching: index for index, matching in enumerate(fixed)}
    rooted_index = {matching: index for index, matching in enumerate(rooted)}
    assert len(rooted) == 4 and len(fixed) == 50

    print("ROOTED TARGETS")
    for index, matching in enumerate(rooted):
        print(
            index,
            "fixed", fixed_index[matching],
            "state", base.matching_state(matching, selected),
            "sector", int(surviving in matching),
            "h", int(short_edge in matching),
            "complement", complement_signature(graph, matching, root),
        )

    print("PAIRWISE ROOTED DIFFERENCES")
    for first in range(len(rooted)):
        for second in range(first + 1, len(rooted)):
            components = difference_components(rooted[first], rooted[second])
            print(
                first, second,
                "lengths", tuple(len(item) for item in components),
                "components", tuple(serial_component(item) for item in components),
            )

    sectors = (
        tuple(item for item in rooted if surviving not in item),
        tuple(item for item in rooted if surviving in item),
    )
    bonds = tuple(
        (first, second)
        for first in sectors[0]
        for second in sectors[1]
        if len(difference_components(first, second)) == 1
    )
    assert len(bonds) == 2

    bond_data = []
    print("BOND PATHS AND RECOMBINATIONS")
    for bond_number, (low, high) in enumerate(bonds):
        state00 = low if base.matching_state(low, selected) == "00" else high
        state11 = high if state00 is low else low
        difference = state00 ^ state11
        residual = difference - frozenset(selected)
        residual_graph = nx.Graph()
        residual_graph.add_edges_from(residual)
        paths = tuple(
            frozenset(
                item for item in residual if set(item) <= component
            )
            for component in nx.connected_components(residual_graph)
        )
        assert len(paths) == 2
        gate_path = next(path for path in paths if surviving in path)
        other_path = next(path for path in paths if path != gate_path)
        h_endpoints = frozenset(short_edge)
        h_path = next(
            path
            for path in paths
            if frozenset(
                vertex
                for vertex in h_endpoints
                if sum(vertex in item for item in path) == 1
            )
            == h_endpoints
        )
        h_toggle = frozenset(state00 ^ (h_path | frozenset((short_edge,))))
        assert h_toggle in fixed_index
        print(
            "bond", bond_number,
            "rooted", (rooted_index[state11], rooted_index[state00]),
            "gate", serial_component(gate_path),
            "other", serial_component(other_path),
            "h-path-is-gate", h_path == gate_path,
            "h-toggle-fixed", fixed_index[h_toggle],
            "h-toggle-state", base.matching_state(h_toggle, selected),
            "h-toggle-sector", int(surviving in h_toggle),
            "h-toggle-complement", complement_signature(graph, h_toggle, root),
        )
        bond_data.append((state11, state00, gate_path, other_path, h_toggle))

    # Every component of a symmetric difference may be flipped independently.
    # Locate all such rectangle/cube vertices in the common fixed-edge PM family.
    print("COMPONENTWISE RECTANGLES")
    named_pairs = {
        "M-M": (rooted[0], rooted[1]),
        "N-N": (rooted[2], rooted[3]),
        "cross-0-3": (rooted[0], rooted[3]),
        "cross-1-2": (rooted[1], rooted[2]),
    }
    for label, (first, second) in named_pairs.items():
        components = difference_components(first, second)
        print(label, "components", tuple(serial_component(item) for item in components))
        for mask in range(1 << len(components)):
            choice = frozenset().union(
                *(components[index] for index in range(len(components)) if mask >> index & 1)
            )
            matching = frozenset(first ^ choice)
            assert matching in fixed_index
            print(
                " ", mask,
                "fixed", fixed_index[matching],
                "rooted", rooted_index.get(matching),
                "state", base.matching_state(matching, selected),
                "sector", int(surviving in matching),
                "h", int(short_edge in matching),
                "complement", complement_signature(graph, matching, root),
            )

    # Summarize the entire fixed-edge closure by state, sector and actual
    # complement partition.  This is the information invisible in the four-node
    # rooted bond graph.
    print("COMPLETE 50-PM SIGNATURE CENSUS")
    census = defaultdict(list)
    for index, matching in enumerate(fixed):
        signature = (
            base.matching_state(matching, selected),
            int(surviving in matching),
            int(short_edge in matching),
            complement_signature(graph, matching, root),
        )
        census[signature].append(index)
    for signature, indices in sorted(census.items(), key=lambda item: repr(item[0])):
        print(signature, tuple(indices))

    assert bond_data[0][2] == bond_data[1][2]
    print("EXTREME_FAMILY_COMPLETE_CLOSURE_ANALYZED")


if __name__ == "__main__":
    main()
