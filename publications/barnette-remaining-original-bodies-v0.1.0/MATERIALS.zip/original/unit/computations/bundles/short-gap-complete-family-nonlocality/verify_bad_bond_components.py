#!/usr/bin/env python3
"""Decide bad-component gate-sibling selection in the frozen short-gap data.

The universe is exactly the 323 already frozen ParentKill hits, restricted
to the same 262 one-edge-gap records used by Notes 139--143.  For each
record the script reconstructs the complete rooted parent bond graph,
labels every edge either bad (h-avoiding 11--00) or automatic (all other
Notes 138--139 types), and tests every nonempty connected component all of
whose edges are bad.  No graph, site, order, random instance, or
neighbouring parameter is generated.
"""

from __future__ import annotations

from collections import Counter
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
LOCAL_STAR_PATH = (
    BARNETTE
    / "computations"
    / "bundles"
    / "short-gap-local-star-extremality-counterexample"
    / "verify_frozen_local_star_extremes.py"
)

sys.dont_write_bytecode = True


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


local_star = load_module(LOCAL_STAR_PATH, "frozen_bad_component_local_star")
base = local_star.base
classifier = base.classifier


def matching_key(matching):
    return tuple(sorted(matching))


def serial_matching(matching):
    return [list(item) for item in matching_key(matching)]


def serial_component(component):
    return sorted(component, key=matching_key)


def record_key(record):
    site = record["site"]
    return (
        str(record["source_graph6"]),
        tuple(record["root"]),
        tuple(record["forced_gate"]),
        tuple(record["surviving_gate"]),
        int(site["face_index"]),
        tuple(site["indices"]),
    )


def classify_bond(first, second, selected, short_edge):
    first_state = base.matching_state(first, selected)
    second_state = base.matching_state(second, selected)
    assert "11" in (first_state, second_state)

    if first_state == second_state == "11":
        return "11-11", False, None, None

    if first_state == "11":
        state11, other, other_state = first, second, second_state
    else:
        assert second_state == "11"
        state11, other, other_state = second, first, first_state

    if other_state == "00":
        if short_edge in other:
            return "11-00/h-in", False, None, None
        return "11-00/h-avoiding", True, state11, other
    assert other_state in {"10", "01"}
    return f"11-{other_state}", False, None, None


def main() -> None:
    frozen = json.loads(base.FROZEN_PATH.read_text())
    assert len(frozen["hits"]) == 323
    records = sorted(
        frozen["hits"],
        key=lambda record: (
            int(record["parent_order"]),
            str(record["source_graph6"]),
            record["root"],
            record["forced_gate"],
            record["surviving_gate"],
            record["site"]["face_index"],
            record["site"]["indices"],
        ),
    )

    short_gap_records = 0
    total_components = 0
    all_bad_components = []
    records_with_all_bad_components = set()
    component_size_histogram: Counter[tuple[int, int]] = Counter()
    outcome_histogram: Counter[str] = Counter()
    components_by_order: Counter[int] = Counter()
    failures_by_order: Counter[int] = Counter()
    full_family_extreme_records = set()

    for record in records:
        graph6 = str(record["source_graph6"])
        graph, faces, all_matchings = base.graph_data(graph6)
        short_edge = base.one_edge_gap(record, faces)
        if short_edge is None:
            continue
        short_gap_records += 1

        root = base.as_edge(record["root"])
        forced_gate = base.as_edge(record["forced_gate"])
        surviving_gate = base.as_edge(record["surviving_gate"])
        site = record["site"]
        selected = tuple(base.as_edge(item) for item in site["selected"])
        fibre = tuple(
            sorted(
                (
                    matching
                    for matching in all_matchings
                    if classifier.is_root_target(
                        graph, matching, root, forced_gate
                    )
                ),
                key=matching_key,
            )
        )
        assert len(fibre) == int(record["parent_fibre_size"])
        sectors = (
            tuple(item for item in fibre if surviving_gate not in item),
            tuple(item for item in fibre if surviving_gate in item),
        )
        bonds = tuple(
            (first, second)
            for first in sectors[0]
            for second in sectors[1]
            if classifier.difference_component_count(first, second) == 1
        )
        assert len(bonds) == int(record["parent_crossings"])

        bond_graph = nx.Graph()
        bond_rows = {}
        profile: Counter[str] = Counter()
        for first, second in bonds:
            label, bad, state11, state00 = classify_bond(
                first, second, selected, short_edge
            )
            profile[label] += 1
            bond_graph.add_edge(first, second)
            bond_rows[frozenset((first, second))] = {
                "first": first,
                "second": second,
                "label": label,
                "bad": bad,
                "state11": state11,
                "state00": state00,
            }
        assert bond_graph.number_of_edges() == len(bonds)
        assert sum(profile.values()) == len(bonds)

        components = tuple(
            sorted(
                nx.connected_components(bond_graph),
                key=lambda component: (
                    min(matching_key(item) for item in component),
                    len(component),
                ),
            )
        )
        total_components += len(components)
        component_rows = []
        for component_index, component in enumerate(components):
            edges = tuple(
                bond_rows[frozenset((first, second))]
                for first, second in bond_graph.subgraph(component).edges()
            )
            assert edges
            if not all(row["bad"] for row in edges):
                continue
            component_rows.append((component_index, component, edges))

        if not component_rows:
            continue

        key = record_key(record)
        records_with_all_bad_components.add(key)
        if len(component_rows) == len(components):
            assert all(row["bad"] for row in bond_rows.values())
            full_family_extreme_records.add(key)

        expanded_site = {
            "face_index": int(site["face_index"]),
            "face_length": int(site["face_length"]),
            "indices": tuple(map(int, site["indices"])),
            "selected": selected,
        }
        child, _child_faces, local = classifier.expand_on_face(
            graph, faces, expanded_site
        )

        for component_index, component, edges in component_rows:
            edge_results = []
            for row in sorted(
                edges,
                key=lambda item: (
                    matching_key(item["state11"]),
                    matching_key(item["state00"]),
                ),
            ):
                canonical, sibling, target_cell, gate_path, flip_cycle = (
                    local_star.gate_path_sibling(
                        graph,
                        child,
                        local,
                        selected,
                        surviving_gate,
                        row["state11"],
                        row["state00"],
                    )
                )
                rooted = classifier.is_root_target(
                    child, sibling, root, forced_gate
                )
                edge_results.append(
                    {
                        "state11": row["state11"],
                        "state00": row["state00"],
                        "canonical": canonical,
                        "sibling": sibling,
                        "target_cell": target_cell,
                        "gate_path": gate_path,
                        "flip_cycle": flip_cycle,
                        "rooted": rooted,
                        "complement_components": local_star.complement_components(
                            child, sibling
                        ),
                    }
                )

            rooted_count = sum(item["rooted"] for item in edge_results)
            outcome = (
                "at-least-one-rooted-sibling"
                if rooted_count
                else "no-rooted-sibling"
            )
            order = int(record["parent_order"])
            outcome_histogram[outcome] += 1
            components_by_order[order] += 1
            if not rooted_count:
                failures_by_order[order] += 1
            component_size_histogram[(len(component), len(edges))] += 1
            all_bad_components.append(
                {
                    "record": record,
                    "record_key": key,
                    "root": root,
                    "forced_gate": forced_gate,
                    "surviving_gate": surviving_gate,
                    "selected": selected,
                    "short_edge": short_edge,
                    "fibre": fibre,
                    "profile": profile,
                    "component_index": component_index,
                    "component": frozenset(component),
                    "component_edge_count": len(edges),
                    "component_total_count": len(components),
                    "edge_results": edge_results,
                    "rooted_count": rooted_count,
                }
            )

    assert short_gap_records == 262
    failures = tuple(
        item for item in all_bad_components if item["rooted_count"] == 0
    )
    successes = tuple(
        item for item in all_bad_components if item["rooted_count"] > 0
    )

    assert total_components == 352
    assert len(all_bad_components) == 6
    assert len(records_with_all_bad_components) == 5
    assert component_size_histogram == {(2, 1): 6}
    assert components_by_order == {26: 6}
    assert outcome_histogram == {
        "at-least-one-rooted-sibling": 2,
        "no-rooted-sibling": 4,
    }
    assert failures_by_order == {26: 4}
    assert len(full_family_extreme_records) == 1
    assert {
        item["record_key"] for item in successes
    } == full_family_extreme_records
    assert {
        item["record_key"] for item in failures
    }.isdisjoint(full_family_extreme_records)

    first_counterexample = None
    if failures:
        first = failures[0]
        record = first["record"]
        component_vertices = serial_component(first["component"])
        first_counterexample = {
            "parent_order": record["parent_order"],
            "source_graph6": record["source_graph6"],
            "root": list(first["root"]),
            "forced_gate": list(first["forced_gate"]),
            "surviving_gate": list(first["surviving_gate"]),
            "site": record["site"],
            "short_edge_h": list(first["short_edge"]),
            "parent_fibre_size": len(first["fibre"]),
            "parent_bond_profile": dict(sorted(first["profile"].items())),
            "parent_bond_components": first["component_total_count"],
            "all_bad_component_index": first["component_index"],
            "all_bad_component_vertex_count": len(first["component"]),
            "all_bad_component_edge_count": first["component_edge_count"],
            "all_bad_component_fibre_indices": [
                first["fibre"].index(item) for item in component_vertices
            ],
            "all_bad_component_vertices": [
                serial_matching(item) for item in component_vertices
            ],
            "bad_bonds": [
                {
                    "state11_fibre_index": first["fibre"].index(
                        row["state11"]
                    ),
                    "state00_fibre_index": first["fibre"].index(
                        row["state00"]
                    ),
                    "state11": serial_matching(row["state11"]),
                    "state00": serial_matching(row["state00"]),
                    "target_cell": row["target_cell"],
                    "gate_path": serial_matching(row["gate_path"]),
                    "flip_cycle": serial_matching(row["flip_cycle"]),
                    "sibling": serial_matching(row["sibling"]),
                    "sibling_rooted": row["rooted"],
                    "sibling_complement_components": [
                        list(component)
                        for component in row["complement_components"]
                    ],
                }
                for row in first["edge_results"]
            ],
            "recorded_child_supplement_bonds": record["new_cell_crossings"],
            "family_is_complete_extreme": (
                first["record_key"] in full_family_extreme_records
            ),
        }

    payload = {
        "scope": {
            "frozen_parentkill_hits": len(frozen["hits"]),
            "one_edge_gap_parentkill_records": short_gap_records,
            "generated_new_graphs_sites_orders_or_random_instances": False,
            "isolated_rooted_targets_excluded": True,
        },
        "nonempty_parent_bond_components": total_components,
        "all_bad_components": len(all_bad_components),
        "records_with_all_bad_components": len(
            records_with_all_bad_components
        ),
        "all_bad_components_by_parent_order": dict(
            sorted(components_by_order.items())
        ),
        "all_bad_component_vertex_edge_histogram": {
            f"{vertices}v-{edges}e": count
            for (vertices, edges), count in sorted(
                component_size_histogram.items()
            )
        },
        "all_bad_component_outcomes": dict(sorted(outcome_histogram.items())),
        "counterexamples_by_parent_order": dict(
            sorted(failures_by_order.items())
        ),
        "full_family_extreme_records_among_them": len(
            full_family_extreme_records
        ),
        "counterexample_identities": [
            {
                "parent_order": item["record"]["parent_order"],
                "source_graph6": item["record"]["source_graph6"],
                "root": item["record"]["root"],
                "forced_gate": item["record"]["forced_gate"],
                "surviving_gate": item["record"]["surviving_gate"],
                "site_face_index": item["record"]["site"]["face_index"],
                "site_indices": item["record"]["site"]["indices"],
                "component_fibre_indices": [
                    item["fibre"].index(matching)
                    for matching in serial_component(item["component"])
                ],
            }
            for item in failures
        ],
        "first_counterexample": first_counterexample,
    }
    print(json.dumps(payload, indent=2, sort_keys=True))

    if failures:
        print("FROZEN_ALL_BAD_COMPONENT_HAS_REAL_COUNTEREXAMPLE")
    else:
        assert successes
        print("FROZEN_ALL_BAD_COMPONENT_SELECTION_SUPPORTED")


if __name__ == "__main__":
    main()
