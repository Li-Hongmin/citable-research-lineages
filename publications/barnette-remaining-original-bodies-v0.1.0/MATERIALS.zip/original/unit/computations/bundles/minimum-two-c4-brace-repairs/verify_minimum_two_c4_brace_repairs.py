#!/usr/bin/env python3
"""Exhaust the minimum two-C4 brace repairs of the order-20 countermodel."""

from __future__ import annotations

from collections import Counter
from itertools import combinations, product
import importlib.util
from pathlib import Path
from typing import Sequence
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE_PATH = (
    HERE.parent
    / "order20-terminal-fixed-sector-countermodel"
    / "verify_order20_terminal_fixed_sector_countermodel.py"
)


def load_base():
    specification = importlib.util.spec_from_file_location(
        "minimum_two_c4_repair_base", BASE_PATH
    )
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


base = load_base()
Edge = tuple[int, int]
BOUNDARY_EDGES = frozenset(
    base.edge(base.BOUNDARY[index], base.BOUNDARY[(index + 1) % 8])
    for index in range(8)
)


def planar_faces(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    planar, embedding = nx.check_planarity(graph)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    visited: set[tuple[int, int]] = set()
    faces = []
    for first, second in embedding.edges():
        if (first, second) not in visited:
            faces.append(tuple(embedding.traverse_face(first, second, visited)))
    return tuple(faces)


def valid_c4_moves(
    graph: nx.Graph,
) -> tuple[tuple[tuple[int, ...], int, int], ...]:
    moves = []
    for face in planar_faces(graph):
        length = len(face)
        if length < 4 or length % 2:
            continue
        for first_index in range(length):
            for second_index in range(first_index + 1, length):
                first_edge = {
                    face[first_index],
                    face[(first_index + 1) % length],
                }
                second_edge = {
                    face[second_index],
                    face[(second_index + 1) % length],
                }
                if first_edge & second_edge:
                    continue
                if (second_index - first_index) % 2 == 0:
                    moves.append((face, first_index, second_index))
    return tuple(moves)


def c4_expand(
    graph: nx.Graph,
    face: Sequence[int],
    first_index: int,
    second_index: int,
) -> tuple[nx.Graph, dict[str, object]]:
    length = len(face)
    u, v = face[first_index], face[(first_index + 1) % length]
    x, y = face[second_index], face[(second_index + 1) % length]
    assert len({u, v, x, y}) == 4
    assert graph.has_edge(u, v) and graph.has_edge(x, y)
    child = graph.copy()
    next_vertex = max(child) + 1
    a, b, c, d = range(next_vertex, next_vertex + 4)
    child.remove_edge(u, v)
    child.remove_edge(x, y)
    child.add_edges_from(
        (
            (u, a),
            (a, b),
            (b, v),
            (x, c),
            (c, d),
            (d, y),
            (a, d),
            (b, c),
        )
    )
    return child, {
        "new": (a, b, c, d),
        "ends": (u, v, x, y),
        "removed": (base.edge(u, v), base.edge(x, y)),
    }


def projected_matching(
    matching: frozenset[Edge], operation: dict[str, object]
) -> frozenset[Edge] | None:
    new = tuple(operation["new"])
    u, v, x, y = tuple(operation["ends"])
    a, b, c, d = new
    flags = (
        base.edge(u, a) in matching,
        base.edge(b, v) in matching,
        base.edge(x, c) in matching,
        base.edge(d, y) in matching,
    )
    if flags not in {
        (False, False, False, False),
        (True, True, False, False),
        (False, False, True, True),
        (True, True, True, True),
    }:
        return None
    old = {item for item in matching if set(item).isdisjoint(new)}
    removed = tuple(operation["removed"])
    if flags[0]:
        old.add(removed[0])
    if flags[2]:
        old.add(removed[1])
    return frozenset(old)


def admissible_moves(
    graph: nx.Graph,
) -> tuple[tuple[tuple[int, ...], int, int], ...]:
    accepted = []
    for face, first_index, second_index in valid_c4_moves(graph):
        first = base.edge(
            face[first_index], face[(first_index + 1) % len(face)]
        )
        second = base.edge(
            face[second_index], face[(second_index + 1) % len(face)]
        )
        if first in BOUNDARY_EDGES or second in BOUNDARY_EDGES:
            continue
        if base.ROOT in (first, second):
            continue
        accepted.append((face, first_index, second_index))
    return tuple(accepted)


def nonextendible_pairs(
    graph: nx.Graph, matchings: tuple[frozenset[Edge], ...]
) -> frozenset[frozenset[Edge]]:
    graph_edges = tuple(sorted(base.edge(*item) for item in graph.edges()))
    return frozenset(
        frozenset((first, second))
        for first, second in combinations(graph_edges, 2)
        if set(first).isdisjoint(second)
        and not any(
            first in matching and second in matching for matching in matchings
        )
    )


def fixed_site(
    graph: nx.Graph,
) -> tuple[
    tuple[tuple[int, ...], ...],
    dict[Edge, tuple[int, int]],
    int,
    tuple[int, ...],
]:
    faces = base.lift.plane_faces(graph)
    incidence = base.face_incidence(graph, faces)
    split_face, neighbours = base.locate_site(faces, incidence)
    return faces, incidence, split_face, neighbours


def local_lift_rows(
    graph: nx.Graph,
    faces: tuple[tuple[int, ...], ...],
    incidence: dict[Edge, tuple[int, int]],
    split_face: int,
    neighbours: tuple[int, ...],
    matching: frozenset[Edge],
) -> tuple[tuple[int, int, int], ...]:
    reduced, _rotations = base.lift.dual_from_primal_faces(graph, faces)
    reduced_faces = base.lift.plane_faces(reduced)
    dual_root = base.edge(*incidence[base.ROOT])
    colour = base.dual_colouring(
        len(faces), incidence, matching, split_face
    )
    assert base.lift.is_target_profile(
        base.lift.rooted_profile(
            reduced, reduced_faces, colour, dual_root
        )
    )
    expanded, locals_, _left_arc, _right_arc = base.lift.split_vertex(
        reduced, split_face, neighbours, 0, 4
    )
    expanded_faces = base.lift.plane_faces(expanded)
    fixed = {
        vertex: value
        for vertex, value in colour.items()
        if vertex != split_face
    }
    rows = []
    for bits in product((0, 1), repeat=3):
        lifted_colour = {
            **fixed,
            **dict(zip(locals_, bits, strict=True)),
        }
        if base.lift.is_target_profile(
            base.lift.rooted_profile(
                expanded, expanded_faces, lifted_colour, dual_root
            )
        ):
            rows.append(bits)
    return tuple(rows)


def main() -> None:
    original = nx.from_graph6_bytes(base.GRAPH6.encode())
    original_matchings = base.enumerate_perfect_matchings(original)
    original_family = base.target_family(original, original_matchings)
    assert len(original_family) == 4
    assert len(nonextendible_pairs(original, original_matchings)) == 6

    totals = Counter()
    family_patterns = Counter()
    first_records = []
    for face, first_index, second_index in admissible_moves(original):
        first_child, first_operation = c4_expand(
            original, face, first_index, second_index
        )
        first_matchings = base.enumerate_perfect_matchings(first_child)
        bad_pairs = nonextendible_pairs(first_child, first_matchings)
        totals["first_moves"] += 1
        totals[f"first_nonextendible_pairs_{len(bad_pairs)}"] += 1
        first_records.append(
            (first_child, first_operation, len(bad_pairs))
        )

    assert totals["first_moves"] == 24
    assert totals["first_nonextendible_pairs_3"] == 7
    assert totals["first_nonextendible_pairs_6"] == 17

    for first_child, first_operation, first_bad_count in first_records:
        for face, first_index, second_index in admissible_moves(first_child):
            totals["two_step_sequences"] += 1
            repaired, second_operation = c4_expand(
                first_child, face, first_index, second_index
            )
            repaired_matchings = base.enumerate_perfect_matchings(repaired)
            if nonextendible_pairs(repaired, repaired_matchings):
                continue

            totals["brace_sequences"] += 1
            totals[
                f"brace_after_first_bad_count_{first_bad_count}"
            ] += 1
            assert nx.number_of_selfloops(repaired) == 0
            assert nx.is_connected(repaired) and nx.is_bipartite(repaired)
            assert set(dict(repaired.degree()).values()) == {3}
            assert nx.check_planarity(repaired)[0]
            assert nx.node_connectivity(repaired) >= 3

            faces, incidence, split_face, neighbours = fixed_site(repaired)
            family = tuple(
                base.target_family(repaired, repaired_matchings)
            )
            assert family
            profiles = tuple(
                local_lift_rows(
                    repaired,
                    faces,
                    incidence,
                    split_face,
                    neighbours,
                    matching,
                )
                for matching in family
            )
            loads = tuple(
                sum(gate in matching for gate in base.GATES)
                for matching in family
            )

            descendants = []
            for matching in family:
                first_projection = projected_matching(
                    matching, second_operation
                )
                original_projection = (
                    None
                    if first_projection is None
                    else projected_matching(
                        first_projection, first_operation
                    )
                )
                descendants.append(original_projection in original_family)

            assert min(loads) == 0
            assert all(
                bool(profile) == (load <= 1)
                for profile, load in zip(profiles, loads, strict=True)
            )
            assert all(
                not descendant or (load == 2 and not profile)
                for descendant, load, profile in zip(
                    descendants, loads, profiles, strict=True
                )
            )

            zero_count = loads.count(0)
            one_count = loads.count(1)
            two_count = loads.count(2)
            liftable_count = sum(bool(profile) for profile in profiles)
            descendant_count = sum(descendants)
            family_patterns[
                (
                    len(family),
                    zero_count,
                    one_count,
                    two_count,
                    liftable_count,
                    descendant_count,
                )
            ] += 1
            totals["targets"] += len(family)
            totals["zero_gate_targets"] += zero_count
            totals["one_gate_targets"] += one_count
            totals["two_gate_targets"] += two_count
            totals["liftable_targets"] += liftable_count
            totals["old_cube_descendants"] += descendant_count
            totals["old_cube_descendant_lifts"] += sum(
                descendant and bool(profile)
                for descendant, profile in zip(
                    descendants, profiles, strict=True
                )
            )

    assert totals["two_step_sequences"] == 868
    assert totals["brace_sequences"] == 32
    assert totals["brace_after_first_bad_count_3"] == 32
    assert totals["brace_after_first_bad_count_6"] == 0
    assert totals["targets"] == 612
    assert totals["zero_gate_targets"] == 222
    assert totals["one_gate_targets"] == 210
    assert totals["two_gate_targets"] == 180
    assert totals["liftable_targets"] == 432
    assert totals["old_cube_descendants"] == 126
    assert totals["old_cube_descendant_lifts"] == 0

    print("MINIMUM_TWO_C4_BRACE_REPAIR_CLASS_VERIFIED")
    print(
        "first_moves=24 two_step_sequences=868 brace_sequences=32 "
        "all_braces_have_zero_gate_target"
    )
    print(
        "targets=612 neutral=432 liftable=432 "
        "old_cube_descendants=126 descendant_lifts=0"
    )
    print(f"family_profile_types={len(family_patterns)}")


if __name__ == "__main__":
    main()

