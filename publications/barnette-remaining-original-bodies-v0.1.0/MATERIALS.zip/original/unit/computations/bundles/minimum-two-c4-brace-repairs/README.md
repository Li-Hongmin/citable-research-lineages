# Minimum two-C4 brace repairs

This bundle verifies the bounded repair theorem in
[Note 080](../../../notes/080-minimum-brace-repairs-supplement-rather-than-repair-the-bad-target-cube.md).
It keeps the facial octagon, root and two gates of the order-\(20\)
countermodel pointwise fixed.

Every admissible first \(C_4\)-expansion and every admissible second
expansion supported away from those frozen edges is enumerated.  The
resulting \(868\) labelled two-step sequences contain exactly \(32\) plane
brace sequences.  Every repaired complete rooted target family contains a
zero-gate target.

The verifier separately projects child matching patterns through both
gadgets.  All \(126\) target occurrences descending from the original bad
four-target cube remain double-gate and nonliftable.  The repaired braces
instead acquire \(432\) neutral target occurrences, all liftable.

## Reproduction

From the AIMath project root:

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/minimum-two-c4-brace-repairs/verify_minimum_two_c4_brace_repairs.py

The required final lines are

    MINIMUM_TWO_C4_BRACE_REPAIR_CLASS_VERIFIED
    first_moves=24 two_step_sequences=868 brace_sequences=32 all_braces_have_zero_gate_target
    targets=612 neutral=432 liftable=432 old_cube_descendants=126 descendant_lifts=0
    family_profile_types=14

This is a complete theorem for the stated two-step repair class, not an
order-\(28\) census and not a theorem about arbitrary brace completions.
The script depends only on the permanent
[order-20 countermodel bundle](../order20-terminal-fixed-sector-countermodel/README.md).

