#!/usr/bin/env python3
"""Verify the twelve-vertex two-hole surgery counterexample from Note 081.

Pure standard library.  The rotation system is checked as a spherical
cellular embedding, and 2-extendability is checked against the complete
perfect-matching family.
"""

from itertools import combinations


C = [(i, (i + 1) % 8) for i in range(8)]
D = [(8, 9), (9, 10), (10, 11), (11, 8)]
M = [(0, 5), (1, 4), (2, 9), (3, 8), (6, 11), (7, 10)]
EDGES = C + D + M

def edge(u, v):
    return frozenset((u, v))


E = {edge(u, v) for u, v in EDGES}
MATCHING = {edge(u, v) for u, v in M}
ROOT = edge(6, 11)
GATES = {edge(2, 9), edge(3, 8)}
HOLES = {edge(0, 1), edge(4, 5)}
ALT = {edge(0, 1), edge(1, 4), edge(4, 5), edge(0, 5)}
SHORE = {1, 2, 3, 4}

ROTATION = {
    0: [1, 5, 7],
    1: [0, 2, 4],
    2: [1, 9, 3],
    3: [2, 8, 4],
    4: [3, 5, 1],
    5: [4, 6, 0],
    6: [5, 11, 7],
    7: [6, 10, 0],
    8: [9, 11, 3],
    9: [10, 8, 2],
    10: [7, 11, 9],
    11: [8, 10, 6],
}


def neighbours(edges, vertices=None):
    if vertices is None:
        vertices = set(range(12))
    out = {v: set() for v in vertices}
    for e in edges:
        u, v = tuple(e)
        out[u].add(v)
        out[v].add(u)
    return out


def components(edges, vertices=None):
    adj = neighbours(edges, vertices)
    unseen = set(adj)
    answer = []
    while unseen:
        start = next(iter(unseen))
        stack = [start]
        block = set()
        while stack:
            v = stack.pop()
            if v in block:
                continue
            block.add(v)
            stack.extend(adj[v] - block)
        unseen -= block
        answer.append(block)
    return answer


def perfect_matchings():
    answer = []
    for choice in combinations(E, 6):
        if len(set().union(*choice)) == 12:
            answer.append(set(choice))
    return answer


def trace_faces():
    directed = {(u, v) for e in E for u, v in (tuple(e), tuple(e)[::-1])}
    faces = []
    while directed:
        start = next(iter(directed))
        u, v = start
        face = []
        while True:
            directed.remove((u, v))
            face.append(u)
            order = ROTATION[v]
            w = order[(order.index(u) - 1) % len(order)]
            u, v = v, w
            if (u, v) == start:
                break
        faces.append(face)
    return faces


def main():
    adj = neighbours(E)
    assert all(len(adj[v]) == 3 for v in adj)
    assert len(components(E)) == 1
    assert all((u % 2) != (v % 2) for u, v in map(tuple, E))

    # The rotation system is a sphere embedding: every dart occurs once and
    # V-E+F=2.  Its face lengths are 4,4,4,4,4,4,6,6.
    faces = trace_faces()
    assert len(faces) == 8
    assert sorted(map(len, faces)) == [4, 4, 4, 4, 4, 4, 6, 6]
    assert 12 - len(E) + len(faces) == 2

    pms = perfect_matchings()
    assert len(pms) == 20
    assert MATCHING in pms

    # Every independent edge pair extends: G is a brace.
    independent_pairs = [
        {a, b}
        for a, b in combinations(E, 2)
        if a.isdisjoint(b)
    ]
    assert all(any(pair <= pm for pm in pms) for pair in independent_pairs)

    complement = E - MATCHING
    old_components = components(complement)
    assert sorted(map(len, old_components)) == [4, 8]
    assert any(6 in block and 11 not in block for block in old_components)
    assert any(11 in block and 6 not in block for block in old_components)

    # The displayed cut is a bond, saturated by M except for the two holes.
    cut = {e for e in E if len(e & SHORE) == 1}
    assert cut == HOLES | GATES
    assert components({e for e in E if e <= SHORE}, SHORE) == [SHORE]
    outside = set(range(12)) - SHORE
    assert components({e for e in E if e <= outside}, outside) == [outside]
    assert cut - MATCHING == HOLES
    assert MATCHING & cut == GATES

    # ALT is M-alternating, contains both holes, and fixes root and gates.
    assert ALT & MATCHING == {edge(0, 5), edge(1, 4)}
    assert ALT - MATCHING == HOLES
    assert ROOT not in ALT and ALT.isdisjoint(GATES)

    # Any alternating cycle containing both holes is forced at their four
    # endpoints and is therefore exactly ALT.
    forced = set(HOLES)
    for h in HOLES:
        for v in h:
            forced |= {m for m in MATCHING if v in m}
    assert forced == ALT

    toggled = MATCHING ^ ALT
    assert toggled in pms
    new_components = components(E - toggled)
    assert sorted(map(len, new_components)) == [4, 4, 4]

    print("MINIMAL_TWO_HOLE_SURGERY_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
