#!/usr/bin/env python3
"""Classify target-exchange distance in the 32 minimum repaired braces.

This is deliberately restricted to the labelled two-C4 sequences of the
permanent Note 080 verifier.  A target exchange is one alternating cycle:
the symmetric difference of the two perfect matchings is nonempty and
connected (hence one even cycle).
"""

from __future__ import annotations

from collections import Counter, deque
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[4]
REPAIR_PATH = (
    PROJECT
    / "units/barnette/computations/bundles/minimum-two-c4-brace-repairs"
    / "verify_minimum_two_c4_brace_repairs.py"
)


def load_repair_bundle():
    specification = importlib.util.spec_from_file_location(
        "neutral_exchange_repair_bundle", REPAIR_PATH
    )
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


repair = load_repair_bundle()
base = repair.base
Edge = tuple[int, int]
Matching = frozenset[Edge]


def cut_small_shore(graph: nx.Graph, cut: frozenset[Edge]) -> frozenset[int]:
    remainder = graph.copy()
    remainder.remove_edges_from(cut)
    components = tuple(nx.connected_components(remainder))
    assert len(components) == 2 and len(components[0]) != len(components[1])
    return frozenset(min(components, key=len))


def one_cycle(first: Matching, second: Matching) -> bool:
    difference = first ^ second
    if not difference:
        return False
    graph = nx.Graph()
    graph.add_edges_from(difference)
    assert set(dict(graph.degree()).values()) == {2}
    return nx.is_connected(graph)


def complement_components(
    graph: nx.Graph, matching: Matching
) -> tuple[frozenset[int], frozenset[int]]:
    graph_edges = frozenset(base.edge(*item) for item in graph.edges())
    components = tuple(
        frozenset(component)
        for component in nx.connected_components(
            graph.edge_subgraph(graph_edges - matching)
        )
    )
    assert len(components) == 2
    return components  # type: ignore[return-value]


def operation_key(operation: dict[str, object]) -> dict[str, object]:
    return {
        "ends": list(operation["ends"]),
        "removed": [list(item) for item in operation["removed"]],
        "new": list(operation["new"]),
    }


def matching_key(matching: Matching) -> list[list[int]]:
    return [list(item) for item in sorted(matching)]


def main() -> None:
    original = nx.from_graph6_bytes(base.GRAPH6.encode())
    original_matchings = base.enumerate_perfect_matchings(original)
    original_family = base.target_family(original, original_matchings)
    assert len(original_family) == 4
    left_shore, right_shore = tuple(
        cut_small_shore(original, cut) for cut in base.TIGHT_CUTS
    )
    assert left_shore.isdisjoint(right_shore)

    totals = Counter()
    distance_distribution = Counter()
    family_distance_profiles = Counter()
    geodesic_cycle_profiles = Counter()
    all_exchange_cycle_profiles = Counter()
    per_descendant_geodesic_length_profiles = Counter()
    counterexamples = []

    first_records = []
    for first_move_index, (face, first_index, second_index) in enumerate(
        repair.admissible_moves(original)
    ):
        first_child, first_operation = repair.c4_expand(
            original, face, first_index, second_index
        )
        first_matchings = base.enumerate_perfect_matchings(first_child)
        first_records.append(
            (
                first_move_index,
                first_child,
                first_operation,
                len(repair.nonextendible_pairs(first_child, first_matchings)),
            )
        )

    assert len(first_records) == 24
    sequence_index = 0
    brace_index = 0
    for (
        first_move_index,
        first_child,
        first_operation,
        first_bad_count,
    ) in first_records:
        for second_move_index, (face, first_index, second_index) in enumerate(
            repair.admissible_moves(first_child)
        ):
            sequence_index += 1
            repaired, second_operation = repair.c4_expand(
                first_child, face, first_index, second_index
            )
            repaired_matchings = base.enumerate_perfect_matchings(repaired)
            if repair.nonextendible_pairs(repaired, repaired_matchings):
                continue
            brace_index += 1
            totals["brace_sequences"] += 1
            assert first_bad_count == 3

            family = tuple(sorted(
                base.target_family(repaired, repaired_matchings),
                key=lambda matching: tuple(sorted(matching)),
            ))
            loads = tuple(
                sum(gate in matching for gate in base.GATES)
                for matching in family
            )
            neutral = frozenset(
                index for index, load in enumerate(loads) if load <= 1
            )
            descendants = []
            projections = []
            for index, matching in enumerate(family):
                first_projection = repair.projected_matching(
                    matching, second_operation
                )
                original_projection = (
                    None
                    if first_projection is None
                    else repair.projected_matching(
                        first_projection, first_operation
                    )
                )
                if original_projection in original_family:
                    descendants.append(index)
                    projections.append(original_projection)
            assert descendants and all(loads[index] == 2 for index in descendants)

            adjacency = [set() for _ in family]
            for first in range(len(family)):
                for second in range(first + 1, len(family)):
                    if not one_cycle(family[first], family[second]):
                        continue
                    adjacency[first].add(second)
                    adjacency[second].add(first)
                    difference = family[first] ^ family[second]
                    vertices = frozenset(vertex for edge in difference for vertex in edge)
                    first_components = complement_components(repaired, family[first])
                    second_components = complement_components(repaired, family[second])
                    all_exchange_cycle_profiles[
                        (
                            len(difference),
                            all(vertices & component for component in first_components),
                            all(vertices & component for component in second_components),
                            bool(vertices & left_shore) and bool(vertices & right_shore),
                            sum(gate in difference for gate in base.GATES),
                        )
                    ] += 1

            # Exact distance from the neutral set in the target-exchange graph.
            distance: list[int | None] = [None] * len(family)
            queue = deque()
            for index in neutral:
                distance[index] = 0
                queue.append(index)
            while queue:
                current = queue.popleft()
                assert distance[current] is not None
                for neighbour in adjacency[current]:
                    if distance[neighbour] is None:
                        distance[neighbour] = distance[current] + 1
                        queue.append(neighbour)

            descendant_distances = tuple(distance[index] for index in descendants)
            family_distance_profiles[
                tuple(sorted(Counter(descendant_distances).items(), key=str))
            ] += 1
            for value in descendant_distances:
                distance_distribution[value] += 1
            totals["descendants"] += len(descendants)
            totals["targets"] += len(family)

            bad = [
                (index, distance[index])
                for index in descendants
                if distance[index] is None or distance[index] > 2
            ]
            if bad:
                bad_components = []
                covered_bad_nodes: set[int] = set()
                for bad_index, _value in bad:
                    if bad_index in covered_bad_nodes:
                        continue
                    component = {bad_index}
                    component_queue = [bad_index]
                    covered_bad_nodes.add(bad_index)
                    while component_queue:
                        current = component_queue.pop()
                        for neighbour in adjacency[current]:
                            if neighbour in covered_bad_nodes:
                                continue
                            covered_bad_nodes.add(neighbour)
                            component.add(neighbour)
                            component_queue.append(neighbour)
                    bad_components.append(
                        {
                            "family_indices": sorted(component),
                            "gate_loads": [loads[index] for index in sorted(component)],
                            "inherited_indices": sorted(
                                component & set(descendants)
                            ),
                            "exchange_edges": [
                                {
                                    "ends": [first, second],
                                    "cycle_length": len(family[first] ^ family[second]),
                                    "cycle": [
                                        list(item)
                                        for item in sorted(family[first] ^ family[second])
                                    ],
                                }
                                for first in sorted(component)
                                for second in sorted(adjacency[first])
                                if first < second and second in component
                            ],
                        }
                    )
                counterexamples.append(
                    {
                        "sequence_index": sequence_index,
                        "brace_index": brace_index,
                        "first_move_index": first_move_index,
                        "second_move_index": second_move_index,
                        "first_operation": operation_key(first_operation),
                        "second_operation": operation_key(second_operation),
                        "graph6": nx.to_graph6_bytes(repaired, header=False).decode().strip(),
                        "family_size": len(family),
                        "family_gate_loads": dict(sorted(Counter(loads).items())),
                        "neutral_indices": sorted(neutral),
                        "bad": [
                            {
                                "family_index": index,
                                "distance": value,
                                "matching": matching_key(family[index]),
                                "original_word": base.EXPECTED_WORD[
                                    projections[descendants.index(index)]
                                ],
                            }
                            for index, value in bad
                        ],
                        "bad_components": bad_components,
                    }
                )

            # Exhaustively classify every directed target exchange that occurs
            # on at least one shortest descendant-to-neutral path.
            active = set(descendants)
            frontier = list(descendants)
            while frontier:
                source = frontier.pop()
                source_distance = distance[source]
                if source_distance is None or source_distance == 0:
                    continue
                for target in adjacency[source]:
                    if distance[target] != source_distance - 1:
                        continue
                    if target not in active:
                        active.add(target)
                        frontier.append(target)

            local_geodesic_edges = []
            for source in sorted(active):
                source_distance = distance[source]
                if source_distance is None or source_distance == 0:
                    continue
                for target in sorted(adjacency[source]):
                    if distance[target] != source_distance - 1:
                        continue
                    difference = family[source] ^ family[target]
                    vertices = frozenset(
                        vertex for edge in difference for vertex in edge
                    )
                    source_components = complement_components(
                        repaired, family[source]
                    )
                    target_components = complement_components(
                        repaired, family[target]
                    )
                    profile = (
                        source_distance,
                        loads[source],
                        loads[target],
                        len(difference),
                        all(vertices & component for component in source_components),
                        all(vertices & component for component in target_components),
                        bool(vertices & left_shore) and bool(vertices & right_shore),
                        sum(gate in difference for gate in base.GATES),
                    )
                    geodesic_cycle_profiles[profile] += 1
                    local_geodesic_edges.append((source, target, len(difference)))

            # For each inherited target, record all cycle-length words realised
            # by its shortest paths.  This separates existence from multiplicity.
            for descendant in descendants:
                words = set()

                if distance[descendant] is None:
                    per_descendant_geodesic_length_profiles[(None,)] += 1
                    continue

                def visit(current: int, word: tuple[int, ...]) -> None:
                    current_distance = distance[current]
                    assert current_distance is not None
                    if current_distance == 0:
                        words.add(word)
                        return
                    for target in adjacency[current]:
                        if distance[target] == current_distance - 1:
                            visit(
                                target,
                                word + (len(family[current] ^ family[target]),),
                            )

                visit(descendant, ())
                per_descendant_geodesic_length_profiles[
                    tuple(sorted(words))
                ] += 1

    assert sequence_index == 868
    assert totals["brace_sequences"] == 32
    assert totals["targets"] == 612
    assert totals["descendants"] == 126
    assert distance_distribution == Counter({1: 102, None: 24})
    assert len(counterexamples) == 6
    assert Counter(
        (
            item["family_size"],
            tuple(
                sorted(
                    edge["cycle_length"]
                    for component in item["bad_components"]
                    for edge in component["exchange_edges"]
                )
            ),
        )
        for item in counterexamples
    ) == Counter(
        {
            (11, (6, 6, 10, 10)): 2,
            (16, (6, 6, 10, 10)): 2,
            (16, (6, 6, 6, 6)): 2,
        }
    )
    assert geodesic_cycle_profiles == Counter(
        {
            (1, 2, 0, 14, False, False, True, 2): 4,
            (1, 2, 0, 14, True, True, True, 2): 134,
            (1, 2, 0, 18, True, True, True, 2): 178,
            (1, 2, 1, 6, False, False, False, 1): 12,
            (1, 2, 1, 10, False, False, False, 1): 4,
            (1, 2, 1, 10, True, True, False, 1): 78,
            (1, 2, 1, 14, True, True, False, 1): 20,
            (1, 2, 1, 14, True, True, True, 1): 46,
            (1, 2, 1, 18, True, True, True, 1): 34,
        }
    )

    report = {
        "scope": {
            "two_step_sequences": sequence_index,
            "brace_sequences": totals["brace_sequences"],
            "targets": totals["targets"],
            "inherited_targets": totals["descendants"],
            "left_small_shore": sorted(left_shore),
            "right_small_shore": sorted(right_shore),
        },
        "distance_distribution": {
            str(key): value
            for key, value in sorted(distance_distribution.items(), key=lambda item: str(item[0]))
        },
        "family_distance_profiles": [
            {"profile": [[str(key), value] for key, value in profile], "count": count}
            for profile, count in sorted(family_distance_profiles.items(), key=str)
        ],
        "geodesic_cycle_profile_fields": [
            "source_distance",
            "source_gate_load",
            "target_gate_load",
            "cycle_length",
            "touches_both_source_complement_cycles",
            "touches_both_target_complement_cycles",
            "touches_both_original_small_tight_cut_shores",
            "number_of_gates_on_cycle",
        ],
        "geodesic_cycle_profiles": [
            {"profile": list(profile), "count": count}
            for profile, count in sorted(geodesic_cycle_profiles.items())
        ],
        "all_exchange_cycle_profile_fields": [
            "cycle_length",
            "touches_both_first_complement_cycles",
            "touches_both_second_complement_cycles",
            "touches_both_original_small_tight_cut_shores",
            "number_of_gates_on_cycle",
        ],
        "all_exchange_cycle_profiles": [
            {"profile": list(profile), "count": count}
            for profile, count in sorted(all_exchange_cycle_profiles.items())
        ],
        "per_descendant_shortest_cycle_length_words": [
            {
                "words": (
                    None
                    if words == (None,)
                    else [list(word) for word in words]
                ),
                "count": count,
            }
            for words, count in sorted(
                per_descendant_geodesic_length_profiles.items(), key=str
            )
        ],
        "counterexamples": counterexamples,
    }
    output_path = HERE / "inherited_target_exchange_distance.json"
    output_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")

    print("INHERITED_TARGET_EXCHANGE_DISTANCE_CLASSIFIED")
    print(
        f"sequences={sequence_index} braces={totals['brace_sequences']} "
        f"targets={totals['targets']} inherited={totals['descendants']}"
    )
    print(
        "distance_distribution="
        + repr(dict(sorted(distance_distribution.items(), key=lambda item: str(item[0]))))
    )
    print(f"counterexamples={len(counterexamples)}")
    print(f"report={output_path}")


if __name__ == "__main__":
    main()
