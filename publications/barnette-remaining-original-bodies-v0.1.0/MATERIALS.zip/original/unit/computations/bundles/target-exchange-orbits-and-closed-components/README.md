# Target-exchange orbits and closed single-cycle components

This bundle verifies the two finite assertions used in
[Note 081](../../../notes/081-target-preserving-exchange-is-a-two-rooted-orbit-and-single-cycle-components-can-be-closed.md).
The endpoint-involution theorem in that note is analytic and does not depend
on either computation.

The first verifier checks a minimum order-\(12\) plane brace in which the
unique root- and gate-clean alternating cycle through two same-orientation
holes changes a two-cycle complement into three cycles.  It independently
checks the spherical rotation system, all \(20\) perfect matchings,
\(2\)-extendability, the two-hole bond, uniqueness of the exchange cycle and
the three-cycle complement after the toggle.

From the AIMath project root, run

    python3 \
      units/barnette/computations/bundles/target-exchange-orbits-and-closed-components/verify_minimal_two_hole_surgery_counterexample.py

The required final line is

    MINIMAL_TWO_HOLE_SURGERY_COUNTEREXAMPLE_VERIFIED

The second verifier uses exactly the \(868\) labelled two-step repair
sequences already frozen in the
[minimum two-\(C_4\) brace-repair bundle](../minimum-two-c4-brace-repairs/README.md).
For each of its \(32\) brace sequences it constructs the complete rooted
target family and the graph whose edges are single alternating-cycle target
exchanges.  Among the \(126\) inherited bad-target occurrences, \(102\) are
one exchange from a neutral target and \(24\) lie in closed all-double-gate
components.  The latter occur in exactly six labelled sequences.

Run

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/target-exchange-orbits-and-closed-components/classify_inherited_target_exchange_distance.py

The required final lines are

    INHERITED_TARGET_EXCHANGE_DISTANCE_CLASSIFIED
    sequences=868 braces=32 targets=612 inherited=126
    distance_distribution={1: 102, None: 24}
    counterexamples=6

The classifier writes the complete machine-readable table to
`inherited_target_exchange_distance.json` in this directory.  This is a
classification of the fixed two-step repair class, not a census of all
order-\(28\) braces and not a counterexample to ordinary \(C_4\)-lifting.
