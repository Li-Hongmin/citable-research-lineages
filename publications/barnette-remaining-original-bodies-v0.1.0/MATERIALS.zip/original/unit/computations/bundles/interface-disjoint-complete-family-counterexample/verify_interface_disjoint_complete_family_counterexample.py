#!/usr/bin/env python3
"""Verify the complete-family counterexample outside legal-wide.

This certificate is self-contained apart from NetworkX. It independently
enumerates every parent and child perfect matching and reads no census.
"""

from __future__ import annotations

from collections import Counter
from functools import lru_cache

import networkx as nx


GRAPH6 = "Y?????????????w?Y?CW??w??[?EC?T??_W?D@??AK?@_O?GK??SA???"
ROOT = (6, 16)
FORCED_GATE = (1, 13)
SURVIVING_GATE = (5, 15)
P = (11, 21)
Q = (3, 25)
H = (3, 21)
ORIENTATION = (21, 11, 25, 3)


def edge(left: int, right: int) -> tuple[int, int]:
    return tuple(sorted((left, right)))


def face_edges(face: tuple[int, ...]) -> tuple[tuple[int, int], ...]:
    return tuple(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def plane_faces(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    planar, embedding = nx.check_planarity(graph)
    assert planar
    visited: set[tuple[int, int]] = set()
    faces = []
    for left, right in embedding.edges():
        if (left, right) in visited:
            continue
        faces.append(tuple(embedding.traverse_face(left, right, visited)))
    assert sum(map(len, faces)) == 2 * graph.number_of_edges()
    return tuple(faces)


def cyclically_equal(first: tuple[int, ...], second: tuple[int, ...]) -> bool:
    if len(first) != len(second):
        return False
    size = len(first)
    for oriented in (first, tuple(reversed(first))):
        doubled = oriented + oriented
        if any(tuple(doubled[start : start + size]) == second for start in range(size)):
            return True
    return False


def enumerate_perfect_matchings(
    graph: nx.Graph,
) -> tuple[frozenset[tuple[int, int]], ...]:
    vertices = tuple(sorted(graph))
    position = {vertex: index for index, vertex in enumerate(vertices)}
    neighbours = tuple(
        sum(1 << position[other] for other in graph[vertex])
        for vertex in vertices
    )

    @lru_cache(maxsize=None)
    def recurse(mask: int) -> tuple[tuple[tuple[int, int], ...], ...]:
        if mask == 0:
            return ((),)
        candidates = [
            index for index in range(len(vertices)) if mask & (1 << index)
        ]
        first = min(
            candidates,
            key=lambda index: (neighbours[index] & mask).bit_count(),
        )
        choices = neighbours[first] & mask
        without_first = mask ^ (1 << first)
        result = []
        while choices:
            bit = choices & -choices
            choices ^= bit
            second = bit.bit_length() - 1
            for suffix in recurse(without_first ^ bit):
                result.append(((first, second),) + suffix)
        return tuple(result)

    encoded = recurse((1 << len(vertices)) - 1)
    matchings = tuple(
        frozenset(edge(vertices[left], vertices[right]) for left, right in item)
        for item in encoded
    )
    assert len(matchings) == len(set(matchings))
    return matchings


def is_two_extendable(
    graph: nx.Graph,
    matchings: tuple[frozenset[tuple[int, int]], ...],
) -> bool:
    graph_edges = tuple(sorted(edge(*item) for item in graph.edges()))
    covered_pairs = {
        frozenset((first, second))
        for matching in matchings
        for first in matching
        for second in matching
        if first < second
    }
    return all(
        frozenset((first, second)) in covered_pairs
        for first_index, first in enumerate(graph_edges)
        for second in graph_edges[first_index + 1 :]
        if set(first).isdisjoint(second)
    )


def complement_components(
    graph: nx.Graph, matching: frozenset[tuple[int, int]]
) -> tuple[frozenset[int], ...]:
    complement = graph.copy()
    complement.remove_edges_from(matching)
    assert set(dict(complement.degree()).values()) == {2}
    return tuple(frozenset(item) for item in nx.connected_components(complement))


def is_root_target(
    graph: nx.Graph, matching: frozenset[tuple[int, int]]
) -> bool:
    root = edge(*ROOT)
    if root not in matching or edge(*FORCED_GATE) not in matching:
        return False
    components = complement_components(graph, matching)
    return len(components) == 2 and all(
        len(set(root) & component) == 1 for component in components
    )


def difference_component_count(
    first: frozenset[tuple[int, int]],
    second: frozenset[tuple[int, int]],
) -> int:
    difference = first ^ second
    if not difference:
        return 0
    graph = nx.Graph()
    graph.add_edges_from(difference)
    assert set(dict(graph.degree()).values()) == {2}
    return nx.number_connected_components(graph)


def bond_graph(
    fibre: tuple[frozenset[tuple[int, int]], ...],
) -> tuple[
    tuple[tuple[frozenset[tuple[int, int]], ...], ...],
    tuple[tuple[frozenset[tuple[int, int]], frozenset[tuple[int, int]]], ...],
]:
    gate = edge(*SURVIVING_GATE)
    sectors = (
        tuple(matching for matching in fibre if gate not in matching),
        tuple(matching for matching in fibre if gate in matching),
    )
    bonds = tuple(
        (first, second)
        for first in sectors[0]
        for second in sectors[1]
        if difference_component_count(first, second) == 1
    )
    return sectors, bonds


def expand(graph: nx.Graph) -> tuple[nx.Graph, tuple[tuple[int, int], ...]]:
    child = graph.copy()
    child.remove_edges_from((P, Q))
    a, b, c, d = range(graph.number_of_nodes(), graph.number_of_nodes() + 4)
    u, v, x, y = ORIENTATION
    local = tuple(
        edge(*item)
        for item in (
            (u, a), (a, b), (b, v), (x, c),
            (c, d), (d, y), (a, d), (b, c),
        )
    )
    child.add_edges_from(local)
    return child, local


def local_cell(
    matching: frozenset[tuple[int, int]],
    local: tuple[tuple[int, int], ...],
) -> str:
    ua, ab, bv, xc, cd, dy, ad, bc = local
    patterns = {
        frozenset((ad, bc)): "C00",
        frozenset((ua, bv, cd)): "C10",
        frozenset((xc, dy, ab)): "C01",
        frozenset((ua, bv, xc, dy)): "C11",
        frozenset((ab, cd)): "R00",
        frozenset((ua, bc, dy)): "Xuy",
        frozenset((ad, bv, xc)): "Xvx",
    }
    return patterns[frozenset(matching & frozenset(local))]


def legal_wide_arcs(
    faces: tuple[tuple[int, ...], ...],
) -> tuple[int, int] | None:
    root = edge(*ROOT)
    forced = edge(*FORCED_GATE)
    gate = edge(*SURVIVING_GATE)
    witnesses = []
    for face in faces:
        boundary = face_edges(face)
        if forced not in boundary or gate not in boundary or root in boundary:
            continue
        delta = (boundary.index(gate) - boundary.index(forced)) % len(boundary)
        arcs = (delta + 1, len(boundary) - delta + 1)
        if min(arcs) >= 5 and all(size % 2 for size in arcs):
            witnesses.append(tuple(sorted(arcs)))
    assert len(witnesses) <= 1
    return witnesses[0] if witnesses else None


def component_edge_sets(
    difference: frozenset[tuple[int, int]],
) -> tuple[frozenset[tuple[int, int]], ...]:
    residual = difference - frozenset((edge(*P), edge(*Q)))
    graph = nx.Graph()
    graph.add_edges_from(residual)
    components = tuple(nx.connected_components(graph))
    assert len(components) == 2
    return tuple(
        frozenset(item for item in residual if set(item) <= set(component))
        for component in components
    )


def verify_graph_class(
    graph: nx.Graph,
    matchings: tuple[frozenset[tuple[int, int]], ...],
) -> None:
    assert nx.number_of_selfloops(graph) == 0
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.check_planarity(graph)[0]
    assert nx.node_connectivity(graph) == 3
    assert is_two_extendable(graph, matchings)


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert graph.number_of_nodes() == 26
    faces = plane_faces(graph)
    assert any(
        cyclically_equal(face, (3, 21, 11, 17, 10, 25)) for face in faces
    )
    interface = set(ROOT) | set(FORCED_GATE) | set(SURVIVING_GATE)
    assert len(interface) == 6
    assert interface.isdisjoint(set(P) | set(Q))

    parent_matchings = enumerate_perfect_matchings(graph)
    assert len(parent_matchings) == 254
    verify_graph_class(graph, parent_matchings)
    parent_fibre = tuple(
        matching for matching in parent_matchings if is_root_target(graph, matching)
    )
    parent_sectors, parent_bonds = bond_graph(parent_fibre)
    assert len(parent_fibre) == 4
    assert tuple(map(len, parent_sectors)) == (3, 1)
    assert len(parent_bonds) == 1
    assert Counter(
        (edge(*P) in matching, edge(*Q) in matching)
        for matching in parent_fibre
    ) == {(True, True): 3, (False, False): 1}
    first, second = parent_bonds[0]
    state11 = first if edge(*P) in first else second
    state00 = first if edge(*P) not in first else second
    assert edge(*P) in state11 and edge(*Q) in state11
    assert edge(*P) not in state00 and edge(*Q) not in state00
    assert edge(*H) not in state00

    child, local = expand(graph)
    child_matchings = enumerate_perfect_matchings(child)
    assert len(child_matchings) == 528
    verify_graph_class(child, child_matchings)
    child_fibre = tuple(
        matching for matching in child_matchings if is_root_target(child, matching)
    )
    child_sectors, child_bonds = bond_graph(child_fibre)
    assert len(child_fibre) == 6
    assert tuple(map(len, child_sectors)) == (5, 1)
    assert not child_bonds
    assert Counter(local_cell(matching, local) for matching in child_fibre) == {
        "C00": 1, "R00": 1, "Xuy": 1, "Xvx": 3,
    }

    ua, _ab, bv, xc, _cd, dy, ad, bc = local
    phi = frozenset(
        (state11 - frozenset((edge(*P), edge(*Q))))
        | frozenset((edge(*H), ad, bv, xc))
    )
    assert phi in child_matchings
    assert is_root_target(child, phi)
    assert local_cell(phi, local) == "Xvx"
    assert edge(*SURVIVING_GATE) in phi

    paths = component_edge_sets(state11 ^ state00)
    gate_path = next(path for path in paths if edge(*SURVIVING_GATE) in path)
    canonical = frozenset(state00 | frozenset((ad, bc)))
    path_graph = nx.Graph()
    path_graph.add_edges_from(gate_path)
    endpoints = frozenset(
        vertex for vertex, degree in path_graph.degree() if degree == 1
    )
    u, v, x, y = ORIENTATION
    endpoint_gadgets = {
        frozenset((u, y)): frozenset((ua, ad, dy)),
        frozenset((v, x)): frozenset((bv, bc, xc)),
    }
    gate_sibling = frozenset(
        canonical ^ (gate_path | endpoint_gadgets[endpoints])
    )
    assert gate_sibling in child_matchings
    assert local_cell(gate_sibling, local) == "Xuy"
    assert difference_component_count(canonical, gate_sibling) == 1
    assert len(complement_components(child, gate_sibling)) == 1
    assert not is_root_target(child, gate_sibling)

    assert legal_wide_arcs(plane_faces(child)) is None

    print(f"parent_perfect_matchings={len(parent_matchings)}")
    print(f"parent_rooted_targets={len(parent_fibre)}")
    print(f"parent_bonds={len(parent_bonds)}")
    print("parent_profile=h-avoiding-11-00")
    print(f"child_perfect_matchings={len(child_matchings)}")
    print(f"child_rooted_targets={len(child_fibre)}")
    print(f"child_bonds={len(child_bonds)}")
    print("gate_sibling_complement_components=1")
    print("legal_wide_arcs=None")
    print("INTERFACE_DISJOINT_COMPLETE_FAMILY_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
