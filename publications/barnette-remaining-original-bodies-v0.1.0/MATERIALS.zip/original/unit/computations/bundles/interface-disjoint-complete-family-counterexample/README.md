# Interface-disjoint complete-family counterexample certificate

This bundle supports Note 145. It verifies one fixed order-\(26\) parent
and its order-\(30\) \(C_4\)-expanded child. The verifier is self-contained
apart from NetworkX: it decodes the graph6 string, reconstructs the planar
faces, constructs the child, and recursively enumerates every parent and
child perfect matching. It reads no frozen census and generates no graph,
site, root, gate, or random instance.

Run from the AIMath project root:

~~~bash
uv run --python 3.12 --with 'networkx==3.6.1' python \
  units/barnette/computations/bundles/interface-disjoint-complete-family-counterexample/verify_interface_disjoint_complete_family_counterexample.py
~~~

The terminal marker is

~~~text
INTERFACE_DISJOINT_COMPLETE_FAMILY_COUNTEREXAMPLE_VERIFIED
~~~

The verifier proves that the parent and child have respectively \(254\) and
\(528\) perfect matchings; their complete rooted fibres have sizes \(4\) and
\(6\); the parent cross-sector bond graph consists of one \(h\)-avoiding
\(11\)--\(00\) bond; and the child cross-sector bond graph is empty. It also
checks that both graphs are simple, connected, cubic, bipartite, planar,
3-connected, and 2-extendable. Finally it reconstructs the child faces and
checks that the decoration has no legal-wide gate-face witness.

The certificate proves a counterexample to the implication quantified over
arbitrary interface-disjoint decorations. It is outside the historical
legal-wide stratum and therefore does not decide the legal-wide implication.
No claim of order-minimality is made.
