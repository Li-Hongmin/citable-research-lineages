#!/usr/bin/env python3
"""Verify a common-B face with exactly one rooted crossing edge.

The fixed graph is the explicit 32-vertex plane brace frozen in the
legal-wide plane-brace XOR-cube bundle.  The base verifier reconstructs the
graph, its embedding, all perfect matchings, the brace certificate, and the
complete fixed-pairing rooted fibre.  This script fixes f=b3-t1 and exhausts
the resulting polytope face and rooted subfibre.
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path
import runpy


ROOT_DIR = Path(__file__).resolve().parents[5]
BASE = ROOT_DIR / (
    "units/barnette/computations/bundles/"
    "legal-wide-plane-brace-xor-cube/"
    "verify_legal_wide_plane_brace_xor_cube.py"
)
data = runpy.run_path(str(BASE))

edge = data["edge"]
delta_component_count = data["delta_component_count"]

root = data["ROOT"]
g0 = data["FORCED_GATE"]
g1 = data["SURVIVING_GATE"]
f = edge("b3", "t1")

assert f in data["boundary"]
assert f not in {root, g0, g1}

# Full vertices of P(G) with x_e=x_g0=x_f=1.
full_face = tuple(
    matching
    for matching in data["extension_matchings"]
    if {root, g0, f} <= matching
)
full_sector0 = tuple(matching for matching in full_face if g1 not in matching)
full_sector1 = tuple(matching for matching in full_face if g1 in matching)
full_crossings = tuple(
    (left, right)
    for left in full_sector0
    for right in full_sector1
    if delta_component_count(left, right) == 1
)

assert (len(full_face), len(full_sector0), len(full_sector1)) == (77, 29, 48)
assert len(full_crossings) == 280

# Square deletion identifies rooted targets with the fixed-I residual
# fibre.  Filtering by f gives the rooted vertices of the same face.
rooted_face = tuple(matching for matching in data["fibre"] if f in matching)
rooted_sector0 = tuple(matching for matching in rooted_face if g1 not in matching)
rooted_sector1 = tuple(matching for matching in rooted_face if g1 in matching)
rooted_crossings = tuple(
    (left, right)
    for left in rooted_sector0
    for right in rooted_sector1
    if delta_component_count(left, right) == 1
)

assert (len(rooted_face), len(rooted_sector0), len(rooted_sector1)) == (7, 1, 6)
assert len(rooted_crossings) == 1

minus, plus = rooted_crossings[0]
assert f in minus and f in plus
assert g1 not in minus and g1 in plus
minus_lifted = minus | frozenset((root, g0))
plus_lifted = plus | frozenset((root, g0))

expected_cycle = data["cycle_edges"](
    ("a0", "a1", "a2", "b4", "b5", "b6", "b7", "x8", "x7", "a3")
)
assert minus ^ plus == expected_cycle

gate_face = (
    g0,
    edge("x", "t2"),
    edge("t2", "x5"),
    edge("x5", "b5"),
    g1,
    edge("b4", "b3"),
    f,
    edge("t1", "y"),
)
assert frozenset(gate_face) == frozenset(data["boundary"])


def symbol(item):
    in_plus = item in plus_lifted
    in_minus = item in minus_lifted
    return {
        (False, False): "0",
        (True, False): "M",
        (False, True): "N",
        (True, True): "B",
    }[in_plus, in_minus]


assert "".join(symbol(item) for item in gate_face) == "B000M0B0"

lifted_rooted = {
    matching | frozenset((root, g0))
    for matching in data["fibre"]
}
root_profile = Counter(
    (left in lifted_rooted, right in lifted_rooted)
    for left, right in full_crossings
)
assert root_profile == Counter(
    {
        (False, False): 242,
        (False, True): 34,
        (True, False): 3,
        (True, True): 1,
    }
)

print("full face: 77=29+48; crossing polytope edges=280")
print("rooted fixed-pairing face: 7=1+6; crossing polytope edges=1")
print("common gate-face word: B000M0B0")
print("unique rooted crossing cycle: a0-a1-a2-b4-b5-b6-b7-x8-x7-a3-a0")
print("COMMON_B_UNIQUE_ROOTED_CROSSING_VERIFIED")
