# Common-\(B\) face with one rooted crossing

This bundle verifies the counterexample in
[Note 151](../../../notes/151-a-common-b-face-can-have-exactly-one-rooted-crossing.md).
It reuses the fixed 32-vertex plane brace and complete perfect-matching
enumeration from the
[Note 099 bundle](../legal-wide-plane-brace-xor-cube/README.md), then fixes
the common gate-face edge \(f=b_3t_1\).

Run from the AIMath root:

~~~bash
uv run --python 3.12 --with networkx==3.6.1 \
  python units/barnette/computations/bundles/common-b-face-unique-rooted-crossing/verify_common_b_unique_rooted_crossing.py
~~~

Expected final lines:

~~~text
full face: 77=29+48; crossing polytope edges=280
rooted fixed-pairing face: 7=1+6; crossing polytope edges=1
common gate-face word: B000M0B0
unique rooted crossing cycle: a0-a1-a2-b4-b5-b6-b7-x8-x7-a3-a0
COMMON_B_UNIQUE_ROOTED_CROSSING_VERIFIED
~~~

The computation exhausts one fixed graph.  It proves that fixing a common
\(B\)-edge and invoking the perfect-matching face lattice cannot force a
second rooted crossing.  It does not refute the unconditioned one-bond
statement, because the full 41-state rooted fibre of the same graph has 69
cross-sector single-cycle edges.
