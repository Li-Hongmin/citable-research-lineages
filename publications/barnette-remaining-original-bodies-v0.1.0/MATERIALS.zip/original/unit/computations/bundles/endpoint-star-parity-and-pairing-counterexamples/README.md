# Endpoint-star parity and pairing counterexamples

This bundle supports [Note 124](../../../notes/124-root-smoothing-does-not-turn-mixed-sector-survival-into-parity.md).
It reconstructs three fixed legal-wide splits directly from literal graph6
strings and plane face systems.  The two positive counterexamples are:

\[
\begin{array}{c|c|c}
\text{endpoint}&(|{\cal M}|,|{\cal E}|,|{\cal X}|)&\text{consequence}\\ \hline
114&(1,0,8)&|{\cal M}|\not\equiv|{\cal E}|\pmod 2,
                 \ {\cal M}\not\hookrightarrow{\cal E},\\
29 &(6,0,2)&|{\cal M}|>|{\cal E}|+|{\cal X}|,
                 \ \nu({\cal M},{\cal X})=2.
\end{array}
\]

For endpoint 29, the six canonical mixed-child lifts have neighbourhoods

\[
 \varnothing,\ \varnothing,\ \{X_0\},\ \{X_0\},\ \{X_1\},\ \{X_1\}.
\]

Thus no injection can assign each mixed bond a distinct compatible child
target.  Endpoint 315 is retained only as a regression guard for the
corrected sector predicate: its profile is \((0,2,4)\), not the obsolete
\((2,0,4)\), and it is not used as a counterexample in Note 124.

Both programs use only the Python standard library.  They independently
enumerate perfect matchings, reconstruct the rooted parent and child target
families, verify the plane cubic bipartite brace conditions, and compute the
single-alternating-cycle compatibility graph.  They do not import any
project classifier, frozen JSON table, NetworkX, or scratch module.

## Reproduction

From the AIMath project root, run

```bash
python3 units/barnette/computations/bundles/endpoint-star-parity-and-pairing-counterexamples/verify_hit114_hit315_endpoint_stars.py
python3 units/barnette/computations/bundles/endpoint-star-parity-and-pairing-counterexamples/verify_hit29_bondwise_hall_counterexample.py
```

The terminal markers are

```text
HIT114_HIT315_ENDPOINT_STARS_INDEPENDENTLY_VERIFIED
HIT29_BONDWISE_HALL_COUNTEREXAMPLE_INDEPENDENTLY_VERIFIED
```

The frozen run used CPython 3.14.6.  Wall times were 0.05 s and 0.03 s,
respectively.  The source hashes are

```text
fe6e3b6a9e709879480399ef8fdf20dc6c2741e2a1270d924a9224f3babe96b1  verify_hit114_hit315_endpoint_stars.py
1c27aa81cdd52701106abaa61c32b49c88dc040bc76e8b4aae6c3c610e4722dd  verify_hit29_bondwise_hall_counterexample.py
```

The bundle proves only the displayed fixed counterexamples.  It does not
prove or refute the surviving Boolean alternative

\[
 {\cal M}_\chi\ne\varnothing
 \Longrightarrow
 {\cal E}_\chi\ne\varnothing\ \text{or}\ {\cal X}^b\ne\varnothing.
\]
