#!/usr/bin/env python3
"""Freeze the corrected endpoint-star record for Note 110 hit 29.

Only the Python standard library is used.  The parent is reconstructed from
one literal graph6 string; its displayed face system is checked as a sphere
embedding.  Parent and child perfect matchings, rooted fibres, alternating-
cycle adjacencies, and the mixed-child compatibility graph are then computed
from scratch.  No project classifier or frozen endpoint-star table is read.
"""

from __future__ import annotations

from collections import Counter, deque
from itertools import combinations


GRAPH6 = "W???????????w?s?P_BC?I_?L??J??B_?AW??F??_W?AC_?"
FACES = (
    (0, 13, 1, 12),
    (0, 14, 5, 18, 8, 23, 3, 13),
    (0, 12, 2, 16, 4, 14),
    (1, 13, 3, 22, 10, 20, 6, 15),
    (1, 15, 2, 12),
    (2, 15, 6, 16),
    (3, 23, 11, 22),
    (4, 17, 5, 14),
    (4, 16, 6, 20, 9, 19, 7, 17),
    (5, 17, 7, 18),
    (7, 19, 8, 18),
    (8, 19, 9, 21, 11, 23),
    (9, 20, 10, 21),
    (10, 22, 11, 21),
)
ROOT = (7, 17)
FORCED_GATE = (5, 18)
SURVIVING_GATE = (3, 13)
ROOT_GATE_SQUARE = (7, 17, 5, 18)
FACE_INDEX = 3
SITE_INDICES = (3, 7)
SITE = frozenset({(1, 15), (10, 22)})
CHI = frozenset(
    {
        (0, 12),
        (1, 15),
        (2, 16),
        (3, 13),
        (4, 14),
        (5, 18),
        (6, 20),
        (7, 17),
        (8, 19),
        (9, 21),
        (10, 22),
        (11, 23),
    }
)


def edge(left: int, right: int) -> tuple[int, int]:
    return (left, right) if left < right else (right, left)


def decode_graph6(value: str) -> tuple[tuple[int, ...], frozenset[tuple[int, int]]]:
    data = [ord(character) - 63 for character in value]
    assert data and data[0] < 63
    assert all(0 <= item < 64 for item in data)
    order = data[0]
    bits = [
        (item >> shift) & 1
        for item in data[1:]
        for shift in range(5, -1, -1)
    ]
    needed = order * (order - 1) // 2
    assert len(bits) >= needed and not any(bits[needed:])
    edges: set[tuple[int, int]] = set()
    position = 0
    for right in range(1, order):
        for left in range(right):
            if bits[position]:
                edges.add((left, right))
            position += 1
    return tuple(range(order)), frozenset(edges)


def adjacency(vertices, edges):
    graph = {vertex: set() for vertex in vertices}
    for left, right in edges:
        assert left in graph and right in graph and left != right
        graph[left].add(right)
        graph[right].add(left)
    return graph


def components(vertices, edges, keep=None):
    remaining = set(vertices if keep is None else keep)
    graph = adjacency(vertices, edges)
    result = []
    while remaining:
        start = remaining.pop()
        component = {start}
        stack = [start]
        while stack:
            current = stack.pop()
            for other in graph[current] & remaining:
                remaining.remove(other)
                component.add(other)
                stack.append(other)
        result.append(frozenset(component))
    return tuple(result)


def validate_bipartite(vertices, edges):
    graph = adjacency(vertices, edges)
    colour = {}
    for start in vertices:
        if start in colour:
            continue
        colour[start] = 0
        queue = deque([start])
        while queue:
            current = queue.popleft()
            for other in graph[current]:
                if other not in colour:
                    colour[other] = 1 - colour[current]
                    queue.append(other)
                else:
                    assert colour[other] != colour[current]
    return colour


def validate_sphere_embedding(vertices, edges, faces):
    graph = adjacency(vertices, edges)
    directed = []
    link_successor = {vertex: {} for vertex in vertices}
    for face in faces:
        assert len(face) == len(set(face)) >= 3
        for index, current in enumerate(face):
            previous = face[index - 1]
            following = face[(index + 1) % len(face)]
            assert edge(current, following) in edges
            directed.append((current, following))
            assert previous not in link_successor[current]
            link_successor[current][previous] = following
    expected = {
        dart
        for left, right in edges
        for dart in ((left, right), (right, left))
    }
    assert len(directed) == len(set(directed))
    assert set(directed) == expected
    for vertex in vertices:
        successor = link_successor[vertex]
        assert set(successor) == graph[vertex] == set(successor.values())
        start = min(graph[vertex])
        orbit = []
        current = start
        while current not in orbit:
            orbit.append(current)
            current = successor[current]
        assert current == start and set(orbit) == graph[vertex]
    assert len(vertices) - len(edges) + len(faces) == 2


def validate_plane_cubic_bipartite(vertices, edges, faces):
    assert len(vertices) == len(set(vertices))
    assert len(edges) == len(set(edges))
    assert len(components(vertices, edges)) == 1
    graph = adjacency(vertices, edges)
    assert {len(graph[vertex]) for vertex in vertices} == {3}
    validate_bipartite(vertices, edges)
    validate_sphere_embedding(vertices, edges, faces)


def matching_key(matching):
    return tuple(sorted(matching))


def enumerate_perfect_matchings(vertices, edges):
    graph = adjacency(vertices, edges)
    result = []

    def recurse(unmatched, chosen):
        if not unmatched:
            result.append(frozenset(chosen))
            return
        first = min(unmatched, key=lambda v: (len(graph[v] & unmatched), v))
        for second in sorted(graph[first] & unmatched):
            recurse(unmatched - {first, second}, chosen + [edge(first, second)])

    recurse(set(vertices), [])
    assert len(result) == len(set(result))
    return tuple(sorted(result, key=matching_key))


def verify_brace(edges, matchings):
    independent_pairs = 0
    for first, second in combinations(sorted(edges), 2):
        if set(first) & set(second):
            continue
        independent_pairs += 1
        assert any(first in matching and second in matching for matching in matchings)
    assert independent_pairs > 0
    return independent_pairs


def complement_components(vertices, edges, matching):
    assert matching <= edges
    complement = edges - matching
    graph = adjacency(vertices, complement)
    assert {len(graph[vertex]) for vertex in vertices} == {2}
    return components(vertices, complement)


def root_target(vertices, edges, matching, root, forced_gate):
    if root not in matching or forced_gate not in matching:
        return False
    cycles = complement_components(vertices, edges, matching)
    return len(cycles) == 2 and all(
        len(set(root) & component) == 1 for component in cycles
    )


def difference_component_count(first, second):
    difference = first ^ second
    if not difference:
        return 0
    vertices = tuple(sorted({vertex for item in difference for vertex in item}))
    graph = adjacency(vertices, difference)
    assert {len(graph[vertex]) for vertex in vertices} == {2}
    return len(components(vertices, difference))


def replace_dart(face, left, right, inserted):
    positions = [
        index
        for index in range(len(face))
        if face[index] == left and face[(index + 1) % len(face)] == right
    ]
    if not positions:
        return face
    assert len(positions) == 1
    index = positions[0]
    rotated = face[index:] + face[:index]
    return (left,) + inserted + (right,) + rotated[2:]


def expand(vertices, edges, faces, face_index, indices):
    first_index, second_index = indices
    assert 0 <= first_index < second_index < len(faces[face_index])
    face = faces[face_index]
    u, v = face[first_index], face[(first_index + 1) % len(face)]
    x, y = face[second_index], face[(second_index + 1) % len(face)]
    first, second = edge(u, v), edge(x, y)
    assert not (set(first) & set(second))
    a, b, c, d = range(max(vertices) + 1, max(vertices) + 5)
    child_vertices = vertices + (a, b, c, d)
    child_edges = set(edges - {first, second})
    child_edges.update(
        {
            edge(u, a), edge(a, b), edge(b, v),
            edge(x, c), edge(c, d), edge(d, y),
            edge(a, d), edge(b, c),
        }
    )
    child_faces = []
    for index, old_face in enumerate(faces):
        if index == face_index:
            continue
        new_face = replace_dart(old_face, v, u, (b, a))
        new_face = replace_dart(new_face, y, x, (d, c))
        child_faces.append(new_face)
    child_faces.extend(
        (
            face[first_index + 1 : second_index + 1] + (c, b),
            face[second_index + 1 :] + face[: first_index + 1] + (a, d),
            (a, b, c, d),
        )
    )
    local = (
        edge(u, a), edge(a, b), edge(b, v),
        edge(x, c), edge(c, d), edge(d, y),
        edge(a, d), edge(b, c),
    )
    return (
        child_vertices,
        frozenset(child_edges),
        tuple(child_faces),
        local,
        (first, second),
        face,
    )


def face_edges(face):
    return tuple(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def verify_root_gate_square(faces, root, forced_gate, square):
    assert root == edge(square[0], square[1])
    assert forced_gate == edge(square[2], square[3])
    rotations = {tuple(square[index:] + square[:index]) for index in range(4)}
    reversals = {tuple(reversed(item)) for item in rotations}
    assert any(face in rotations | reversals for face in faces)


def legal_wide_arcs(faces, root, forced_gate, surviving_gate):
    witnesses = []
    for face in faces:
        boundary = face_edges(face)
        if forced_gate not in boundary or surviving_gate not in boundary:
            continue
        if root in boundary:
            continue
        delta = (boundary.index(surviving_gate) - boundary.index(forced_gate)) % len(boundary)
        arcs = (delta + 1, len(boundary) - delta + 1)
        if min(arcs) >= 5 and all(length % 2 for length in arcs):
            witnesses.append(tuple(sorted(arcs)))
    assert len(witnesses) <= 1
    return witnesses[0] if witnesses else None


def local_cell(matching, local):
    ua, ab, bv, xc, cd, dy, ad, bc = local
    patterns = {
        frozenset((ad, bc)): "C00",
        frozenset((ua, bv, cd)): "C10",
        frozenset((xc, dy, ab)): "C01",
        frozenset((ua, bv, xc, dy)): "C11",
        frozenset((ab, cd)): "R00",
        frozenset((ua, bc, dy)): "Xuy",
        frozenset((ad, bv, xc)): "Xvx",
    }
    patch = matching & frozenset(local)
    assert patch in patterns
    return patterns[patch]


def path_edges(vertices):
    return frozenset(edge(left, right) for left, right in zip(vertices, vertices[1:]))


def direct_lifts(parent, face, indices, selected, local):
    first_index, second_index = indices
    first, second = selected
    assert first in parent and second in parent
    arc_a = path_edges(face[first_index + 1 : second_index + 1])
    arc_b = path_edges(face[second_index + 1 :] + face[: first_index + 1])
    ua, ab, bv, xc, cd, dy, ad, bc = local
    common = parent - {first, second}
    return {
        "Xuy": frozenset((common ^ arc_a) | {ua, bc, dy}),
        "Xvx": frozenset((common ^ arc_b) | {ad, bv, xc}),
        "R00": frozenset((common ^ arc_a ^ arc_b) | {ab, cd}),
    }


def canonical_lift(parent, selected, local):
    first, second = selected
    uses_first, uses_second = first in parent, second in parent
    assert not (uses_first and uses_second)
    ua, ab, bv, xc, cd, dy, ad, bc = local
    common = parent - {first, second}
    if not uses_first and not uses_second:
        return frozenset(common | {ad, bc})
    if uses_first:
        return frozenset(common | {ua, bv, cd})
    return frozenset(common | {xc, dy, ab})


def maximum_matching_size(neighbours, right_size):
    assigned = [-1] * right_size

    def augment(left, seen):
        for right in neighbours[left]:
            if right in seen:
                continue
            seen.add(right)
            if assigned[right] == -1 or augment(assigned[right], seen):
                assigned[right] = left
                return True
        return False

    return sum(augment(left, set()) for left in range(len(neighbours)))


def main():
    vertices, edges = decode_graph6(GRAPH6)
    validate_plane_cubic_bipartite(vertices, edges, FACES)
    verify_root_gate_square(FACES, ROOT, FORCED_GATE, ROOT_GATE_SQUARE)

    parent_matchings = enumerate_perfect_matchings(vertices, edges)
    assert len(parent_matchings) == 200
    parent_independent_pairs = verify_brace(edges, parent_matchings)
    assert parent_independent_pairs == 558
    parent_fibre = tuple(
        matching
        for matching in parent_matchings
        if root_target(vertices, edges, matching, ROOT, FORCED_GATE)
    )
    assert len(parent_fibre) == 13
    parent_sectors = tuple(
        tuple(
            matching
            for matching in parent_fibre
            if (SURVIVING_GATE in matching) == bool(bit)
        )
        for bit in (0, 1)
    )
    assert tuple(map(len, parent_sectors)) == (12, 1)
    parent_crossings = tuple(
        (first, second)
        for first in parent_sectors[0]
        for second in parent_sectors[1]
        if difference_component_count(first, second) == 1
    )
    assert len(parent_crossings) == 6
    l11 = tuple(matching for matching in parent_fibre if SITE <= matching)
    assert len(l11) == 1 and l11[0] == CHI
    assert SURVIVING_GATE in CHI

    (
        child_vertices,
        child_edges,
        child_faces,
        local,
        selected,
        site_face,
    ) = expand(vertices, edges, FACES, FACE_INDEX, SITE_INDICES)
    assert frozenset(selected) == SITE
    validate_plane_cubic_bipartite(child_vertices, child_edges, child_faces)
    verify_root_gate_square(child_faces, ROOT, FORCED_GATE, ROOT_GATE_SQUARE)
    assert legal_wide_arcs(child_faces, ROOT, FORCED_GATE, SURVIVING_GATE) == (5, 5)

    child_matchings = enumerate_perfect_matchings(child_vertices, child_edges)
    assert len(child_matchings) == 388
    child_matching_set = frozenset(child_matchings)
    child_independent_pairs = verify_brace(child_edges, child_matchings)
    assert child_independent_pairs == 777
    child_fibre = tuple(
        matching
        for matching in child_matchings
        if root_target(child_vertices, child_edges, matching, ROOT, FORCED_GATE)
    )
    assert len(child_fibre) == 22
    child_fibre_set = frozenset(child_fibre)
    cells = {matching: local_cell(matching, local) for matching in child_fibre}
    assert Counter(cells.values()) == Counter(
        {"C00": 8, "C01": 2, "C10": 2, "R00": 6, "Xuy": 2, "Xvx": 2}
    )
    child_sectors = tuple(
        tuple(
            matching
            for matching in child_fibre
            if (SURVIVING_GATE in matching) == bool(bit)
        )
        for bit in (0, 1)
    )
    assert tuple(map(len, child_sectors)) == (20, 2)

    direct = direct_lifts(CHI, site_face, SITE_INDICES, selected, local)
    assert set(direct) == {"R00", "Xuy", "Xvx"}
    assert all(matching in child_matching_set for matching in direct.values())
    assert all(local_cell(matching, local) == cell for cell, matching in direct.items())
    assert all(matching not in child_fibre_set for matching in direct.values())

    bit = int(SURVIVING_GATE in CHI)
    mixed = tuple(
        matching
        for matching in parent_fibre
        if (SURVIVING_GATE in matching) != bool(bit)
        and not SITE <= matching
        and difference_component_count(CHI, matching) == 1
    )
    escape = tuple(
        matching
        for matching in parent_fibre
        if (SURVIVING_GATE in matching) == bool(bit)
        and not SITE <= matching
        and difference_component_count(CHI, matching) == 1
    )
    targets = tuple(
        matching
        for matching in child_fibre
        if (SURVIVING_GATE in matching) == bool(bit)
        and cells[matching] in {"R00", "Xuy", "Xvx"}
    )
    assert (len(mixed), len(escape), len(targets)) == (6, 0, 2)
    assert tuple(cells[matching] for matching in targets) == ("Xuy", "Xuy")

    canonical = tuple(canonical_lift(matching, selected, local) for matching in mixed)
    assert len(canonical) == len(set(canonical)) == 6
    assert all(matching in child_fibre_set for matching in canonical)
    neighbours = tuple(
        tuple(
            index
            for index, target in enumerate(targets)
            if difference_component_count(matching, target) == 1
        )
        for matching in canonical
    )
    assert neighbours == ((), (), (0,), (0,), (1,), (1,))
    degrees = tuple(map(len, neighbours))
    assert degrees == (0, 0, 1, 1, 1, 1)
    matching_size = maximum_matching_size(neighbours, len(targets))
    assert matching_size == 2

    print(
        {
            "parent": (len(vertices), len(edges), len(parent_matchings), parent_independent_pairs),
            "child": (len(child_vertices), len(child_edges), len(child_matchings), child_independent_pairs),
            "rooted_fibres": (len(parent_fibre), len(child_fibre)),
            "sector_sizes": (tuple(map(len, parent_sectors)), tuple(map(len, child_sectors))),
            "L11_ordinal_0": matching_key(CHI),
            "legal_wide_arcs": (5, 5),
            "sterile_direct_closures": (),
            "profile": (len(mixed), len(escape), len(targets)),
            "compatibility_neighbours": neighbours,
            "compatibility_degrees": degrees,
            "compatibility_matching": matching_size,
        }
    )
    print("HIT29_BONDWISE_HALL_COUNTEREXAMPLE_INDEPENDENTLY_VERIFIED")


if __name__ == "__main__":
    main()
