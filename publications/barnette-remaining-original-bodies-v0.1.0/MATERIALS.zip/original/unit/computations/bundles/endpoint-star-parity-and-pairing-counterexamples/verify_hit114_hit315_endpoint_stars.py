#!/usr/bin/env python3
"""Independent fixed certificates for Note 110 hits 114 and 315.

The verifier uses only the Python standard library.  It does not import the
Note 110 classifier, NetworkX, or any project module.  Each fixed graph6
string, sphere face system, site, labels, and distinguished matching is
literal data.  Perfect matchings and rooted target families are recomputed
recursively from the graph itself.
"""

from __future__ import annotations

from collections import Counter, deque
from itertools import combinations


def edge(left, right):
    return (left, right) if left < right else (right, left)


def decode_graph6(value):
    data = [ord(character) - 63 for character in value]
    assert all(0 <= item < 64 for item in data)
    assert data[0] < 63
    order = data[0]
    bits = []
    for item in data[1:]:
        bits.extend((item >> shift) & 1 for shift in range(5, -1, -1))
    needed = order * (order - 1) // 2
    assert len(bits) >= needed
    edges = set()
    position = 0
    for right in range(1, order):
        for left in range(right):
            if bits[position]:
                edges.add((left, right))
            position += 1
    assert all(bit == 0 for bit in bits[needed:])
    return tuple(range(order)), frozenset(edges)


def adjacency(vertices, edges):
    result = {vertex: set() for vertex in vertices}
    for left, right in edges:
        result[left].add(right)
        result[right].add(left)
    return result


def components(vertices, edges, keep=None):
    keep = set(vertices if keep is None else keep)
    graph = adjacency(vertices, edges)
    result = []
    while keep:
        start = keep.pop()
        component = {start}
        queue = [start]
        while queue:
            current = queue.pop()
            for other in graph[current] & keep:
                keep.remove(other)
                component.add(other)
                queue.append(other)
        result.append(frozenset(component))
    return tuple(result)


def connected(vertices, edges):
    return len(components(vertices, edges)) == 1


def bipartition(vertices, edges):
    graph = adjacency(vertices, edges)
    colour = {}
    for start in vertices:
        if start in colour:
            continue
        colour[start] = 0
        queue = deque([start])
        while queue:
            current = queue.popleft()
            for other in graph[current]:
                if other not in colour:
                    colour[other] = 1 - colour[current]
                    queue.append(other)
                else:
                    assert colour[other] != colour[current]
    return colour


def validate_sphere_embedding(vertices, edges, faces):
    directed = []
    for face in faces:
        assert len(face) == len(set(face)) >= 3
        for index, left in enumerate(face):
            right = face[(index + 1) % len(face)]
            assert edge(left, right) in edges
            directed.append((left, right))
    expected = {
        dart
        for left, right in edges
        for dart in ((left, right), (right, left))
    }
    assert len(directed) == len(set(directed))
    assert set(directed) == expected
    assert len(vertices) - len(edges) + len(faces) == 2


def validate_plane_cubic_bipartite(vertices, edges, faces):
    assert len(vertices) == len(set(vertices))
    assert all(left != right for left, right in edges)
    assert connected(vertices, edges)
    graph = adjacency(vertices, edges)
    assert {len(graph[vertex]) for vertex in vertices} == {3}
    bipartition(vertices, edges)
    validate_sphere_embedding(vertices, edges, faces)


def enumerate_perfect_matchings(vertices, edges):
    graph = adjacency(vertices, edges)
    result = []

    def recurse(unmatched, chosen):
        if not unmatched:
            result.append(frozenset(chosen))
            return
        first = min(
            unmatched,
            key=lambda vertex: len(graph[vertex] & unmatched),
        )
        for second in sorted(graph[first] & unmatched):
            recurse(
                unmatched - {first, second},
                chosen + [edge(first, second)],
            )

    recurse(set(vertices), [])
    assert len(result) == len(set(result))
    return tuple(result)


def verify_two_extendable(edges, matchings):
    independent_pairs = 0
    for first, second in combinations(sorted(edges), 2):
        if set(first) & set(second):
            continue
        independent_pairs += 1
        assert any(first in matching and second in matching for matching in matchings)
    assert independent_pairs > 0
    return independent_pairs


def complement_components(vertices, edges, matching):
    complement = edges - matching
    graph = adjacency(vertices, complement)
    assert {len(graph[vertex]) for vertex in vertices} == {2}
    return components(vertices, complement)


def root_target(vertices, edges, matching, root, forced_gate):
    if root not in matching or forced_gate not in matching:
        return False
    comps = complement_components(vertices, edges, matching)
    return len(comps) == 2 and all(
        len(set(root) & component) == 1 for component in comps
    )


def difference_component_count(first, second):
    difference = first ^ second
    if not difference:
        return 0
    vertices = tuple(sorted({vertex for item in difference for vertex in item}))
    graph = adjacency(vertices, difference)
    assert {len(graph[vertex]) for vertex in vertices} == {2}
    return len(components(vertices, difference))


def replace_dart(face, left, right, inserted):
    positions = [
        index
        for index in range(len(face))
        if face[index] == left and face[(index + 1) % len(face)] == right
    ]
    if not positions:
        return face
    assert len(positions) == 1
    index = positions[0]
    rotated = face[index:] + face[:index]
    return (left,) + inserted + (right,) + rotated[2:]


def expand(vertices, edges, faces, face_index, indices):
    first_index, second_index = indices
    face = faces[face_index]
    u = face[first_index]
    v = face[(first_index + 1) % len(face)]
    x = face[second_index]
    y = face[(second_index + 1) % len(face)]
    first, second = edge(u, v), edge(x, y)
    assert not (set(first) & set(second))
    next_vertex = max(vertices) + 1
    a, b, c, d = range(next_vertex, next_vertex + 4)
    child_vertices = vertices + (a, b, c, d)
    child_edges = set(edges - {first, second})
    child_edges.update(
        {
            edge(u, a), edge(a, b), edge(b, v),
            edge(x, c), edge(c, d), edge(d, y),
            edge(a, d), edge(b, c),
        }
    )
    updated = []
    for index, old_face in enumerate(faces):
        if index == face_index:
            continue
        new_face = replace_dart(old_face, v, u, (b, a))
        new_face = replace_dart(new_face, y, x, (d, c))
        updated.append(new_face)
    first_channel = face[first_index + 1 : second_index + 1] + (c, b)
    second_channel = face[second_index + 1 :] + face[: first_index + 1] + (a, d)
    updated.extend((first_channel, second_channel, (a, b, c, d)))
    local = (
        edge(u, a), edge(a, b), edge(b, v),
        edge(x, c), edge(c, d), edge(d, y),
        edge(a, d), edge(b, c),
    )
    return (
        child_vertices,
        frozenset(child_edges),
        tuple(updated),
        local,
        (first, second),
        face,
    )


def face_edges(face):
    return tuple(edge(face[index], face[(index + 1) % len(face)]) for index in range(len(face)))


def legal_wide_arcs(faces, root, forced_gate, surviving_gate):
    witnesses = []
    for face in faces:
        boundary = face_edges(face)
        if forced_gate not in boundary or surviving_gate not in boundary:
            continue
        if root in boundary:
            continue
        delta = (boundary.index(surviving_gate) - boundary.index(forced_gate)) % len(boundary)
        arcs = (delta + 1, len(boundary) - delta + 1)
        if min(arcs) >= 5 and all(length % 2 for length in arcs):
            witnesses.append(tuple(sorted(arcs)))
    assert len(witnesses) <= 1
    return witnesses[0] if witnesses else None


def verify_root_gate_square(faces, root, forced_gate, square):
    assert len(square) == 4
    assert root == edge(square[0], square[1])
    assert forced_gate == edge(square[2], square[3])
    rotations = {
        tuple(square[index:] + square[:index]) for index in range(4)
    }
    reversals = {tuple(reversed(item)) for item in rotations}
    assert any(face in rotations | reversals for face in faces)


def local_cell(matching, local):
    ua, ab, bv, xc, cd, dy, ad, bc = local
    patterns = {
        frozenset((ad, bc)): "C00",
        frozenset((ua, bv, cd)): "C10",
        frozenset((xc, dy, ab)): "C01",
        frozenset((ua, bv, xc, dy)): "C11",
        frozenset((ab, cd)): "R00",
        frozenset((ua, bc, dy)): "Xuy",
        frozenset((ad, bv, xc)): "Xvx",
    }
    patch = matching & frozenset(local)
    assert patch in patterns
    return patterns[patch]


def path_edges(vertices):
    return frozenset(edge(left, right) for left, right in zip(vertices, vertices[1:]))


def direct_lifts(parent, face, indices, selected, local):
    first_index, second_index = indices
    first, second = selected
    assert first in parent and second in parent
    arc_a = path_edges(face[first_index + 1 : second_index + 1])
    arc_b = path_edges(face[second_index + 1 :] + face[: first_index + 1])
    ua, ab, bv, xc, cd, dy, ad, bc = local
    common = parent - {first, second}
    return {
        "Xuy": frozenset((common ^ arc_a) | {ua, bc, dy}),
        "Xvx": frozenset((common ^ arc_b) | {ad, bv, xc}),
        "R00": frozenset((common ^ arc_a ^ arc_b) | {ab, cd}),
    }


def canonical_lift(parent, selected, local):
    first, second = selected
    ua, ab, bv, xc, cd, dy, ad, bc = local
    uses_first, uses_second = first in parent, second in parent
    assert not (uses_first and uses_second)
    common = parent - {first, second}
    if not uses_first and not uses_second:
        return frozenset(common | {ad, bc})
    if uses_first:
        return frozenset(common | {ua, bv, cd})
    return frozenset(common | {xc, dy, ab})


def maximum_matching_size(neighbours, right_size):
    assigned = [-1] * right_size

    def augment(left, seen):
        for right in neighbours[left]:
            if right in seen:
                continue
            seen.add(right)
            if assigned[right] == -1 or augment(assigned[right], seen):
                assigned[right] = left
                return True
        return False

    return sum(augment(left, set()) for left in range(len(neighbours)))


HIT114 = {
    "name": "hit114",
    "graph6": "W???????????w?s?P_BC?IO?L??H_?BO??w?CD??cG??P_?",
    "faces": (
        (0, 13, 1, 12),
        (0, 14, 5, 18, 9, 21, 3, 13),
        (0, 12, 2, 16, 4, 14),
        (1, 13, 3, 22, 6, 15),
        (1, 15, 2, 12),
        (2, 15, 6, 23, 10, 19, 7, 16),
        (3, 21, 11, 22),
        (4, 16, 7, 17),
        (4, 17, 5, 14),
        (5, 17, 7, 19, 8, 18),
        (6, 22, 11, 23),
        (8, 20, 9, 18),
        (8, 19, 10, 20),
        (9, 20, 10, 23, 11, 21),
    ),
    "face_index": 5,
    "indices": (2, 6),
    "root": (11, 22),
    "forced_gate": (3, 21),
    "surviving_gate": (5, 14),
    "root_gate_square": (11, 22, 3, 21),
    "chi": frozenset(
        {
            (0, 12), (1, 13), (2, 15), (3, 21),
            (4, 14), (5, 17), (6, 23), (7, 16),
            (8, 20), (9, 18), (10, 19), (11, 22),
        }
    ),
    "expected": {
        "parent_pm": 164,
        "parent_fibre": 12,
        "parent_sectors": (4, 8),
        "parent_crossings": 4,
        "child_pm": 320,
        "child_fibre": 17,
        "child_sectors": (8, 9),
        "child_cells": {"C10": 4, "R00": 3, "Xuy": 5, "Xvx": 5},
        "child_crossings": 22,
        "star": (1, 0, 8),
        "compatibility_degrees": (2,),
        "compatibility_matching": 1,
    },
}


HIT315 = {
    "name": "hit315",
    "graph6": "Y?????????????w?B_?F??FAOACCC?Oo?D_?W@??I_?H@??CG_?G`???",
    "faces": (
        (0, 17, 3, 14, 4, 23, 1, 13),
        (0, 18, 12, 17),
        (0, 13, 2, 25, 6, 18),
        (1, 21, 2, 13),
        (1, 23, 10, 16, 11, 21),
        (2, 21, 11, 25),
        (3, 17, 12, 24),
        (3, 24, 8, 20, 5, 14),
        (4, 19, 10, 23),
        (4, 14, 5, 22, 9, 19),
        (5, 20, 7, 22),
        (6, 15, 8, 24, 12, 18),
        (6, 25, 11, 16, 9, 22, 7, 15),
        (7, 20, 8, 15),
        (9, 16, 10, 19),
    ),
    "face_index": 12,
    "indices": (3, 7),
    "root": (10, 19),
    "forced_gate": (4, 23),
    "surviving_gate": (0, 17),
    "root_gate_square": (10, 19, 4, 23),
    "chi": frozenset(
        {
            (0, 17), (1, 21), (2, 13), (3, 24), (4, 23),
            (5, 14), (6, 15), (7, 22), (8, 20), (9, 16),
            (10, 19), (11, 25), (12, 18),
        }
    ),
    "expected": {
        "parent_pm": 231,
        "parent_fibre": 12,
        "parent_sectors": (5, 7),
        "parent_crossings": 9,
        "child_pm": 476,
        "child_fibre": 20,
        "child_sectors": (11, 9),
        "child_cells": {"C10": 5, "R00": 4, "Xuy": 7, "Xvx": 4},
        "child_crossings": 33,
        # This is the corrected endpoint star.  The earlier extractor
        # omitted parentheses around the membership comparison and
        # misclassified the two same-sector neighbours as mixed.
        "star": (0, 2, 4),
        "compatibility_degrees": (),
        "compatibility_matching": 0,
    },
}


def verify_instance(data):
    vertices, edges = decode_graph6(data["graph6"])
    faces = data["faces"]
    validate_plane_cubic_bipartite(vertices, edges, faces)
    verify_root_gate_square(
        faces, data["root"], data["forced_gate"], data["root_gate_square"]
    )
    parent_matchings = enumerate_perfect_matchings(vertices, edges)
    assert len(parent_matchings) == data["expected"]["parent_pm"]
    parent_independent_pairs = verify_two_extendable(edges, parent_matchings)
    parent_fibre = tuple(
        matching
        for matching in parent_matchings
        if root_target(
            vertices, edges, matching, data["root"], data["forced_gate"]
        )
    )
    assert len(parent_fibre) == data["expected"]["parent_fibre"]
    parent_sectors = tuple(
        tuple(
            matching
            for matching in parent_fibre
            if (data["surviving_gate"] in matching) == bool(bit)
        )
        for bit in (0, 1)
    )
    assert tuple(map(len, parent_sectors)) == data["expected"]["parent_sectors"]
    parent_crossings = tuple(
        (first, second)
        for first in parent_sectors[0]
        for second in parent_sectors[1]
        if difference_component_count(first, second) == 1
    )
    assert len(parent_crossings) == data["expected"]["parent_crossings"]

    (
        child_vertices,
        child_edges,
        child_faces,
        local,
        selected,
        site_face,
    ) = expand(
        vertices,
        edges,
        faces,
        data["face_index"],
        data["indices"],
    )
    validate_plane_cubic_bipartite(child_vertices, child_edges, child_faces)
    verify_root_gate_square(
        child_faces,
        data["root"],
        data["forced_gate"],
        data["root_gate_square"],
    )
    assert legal_wide_arcs(
        child_faces,
        data["root"],
        data["forced_gate"],
        data["surviving_gate"],
    ) == (5, 5)
    child_matchings = enumerate_perfect_matchings(child_vertices, child_edges)
    assert len(child_matchings) == data["expected"]["child_pm"]
    child_independent_pairs = verify_two_extendable(child_edges, child_matchings)
    child_fibre = tuple(
        matching
        for matching in child_matchings
        if root_target(
            child_vertices,
            child_edges,
            matching,
            data["root"],
            data["forced_gate"],
        )
    )
    assert len(child_fibre) == data["expected"]["child_fibre"]
    cells = {matching: local_cell(matching, local) for matching in child_fibre}
    assert Counter(cells.values()) == Counter(data["expected"]["child_cells"])
    assert "C11" not in cells.values()
    child_sectors = tuple(
        tuple(
            matching
            for matching in child_fibre
            if (data["surviving_gate"] in matching) == bool(bit)
        )
        for bit in (0, 1)
    )
    assert tuple(map(len, child_sectors)) == data["expected"]["child_sectors"]
    child_crossings = tuple(
        (first, second)
        for first in child_sectors[0]
        for second in child_sectors[1]
        if difference_component_count(first, second) == 1
    )
    assert len(child_crossings) == data["expected"]["child_crossings"]

    chi = data["chi"]
    assert chi in parent_fibre
    assert set(selected) <= chi
    direct = direct_lifts(chi, site_face, data["indices"], selected, local)
    assert all(matching not in child_fibre for matching in direct.values())

    bit = int(data["surviving_gate"] in chi)
    mixed = tuple(
        matching
        for matching in parent_fibre
        if (data["surviving_gate"] in matching) != bool(bit)
        and not set(selected) <= matching
        and difference_component_count(chi, matching) == 1
    )
    escape = tuple(
        matching
        for matching in parent_fibre
        if (data["surviving_gate"] in matching) == bool(bit)
        and not set(selected) <= matching
        and difference_component_count(chi, matching) == 1
    )
    new_cells = tuple(
        matching
        for matching in child_fibre
        if (data["surviving_gate"] in matching) == bool(bit)
        and cells[matching] in {"R00", "Xuy", "Xvx"}
    )
    assert (len(mixed), len(escape), len(new_cells)) == data["expected"]["star"], (
        data["name"], len(mixed), len(escape), len(new_cells)
    )

    canonical_mixed = tuple(canonical_lift(matching, selected, local) for matching in mixed)
    assert all(matching in child_fibre for matching in canonical_mixed)
    neighbours = tuple(
        tuple(
            index
            for index, target in enumerate(new_cells)
            if difference_component_count(canonical, target) == 1
        )
        for canonical in canonical_mixed
    )
    assert tuple(map(len, neighbours)) == data["expected"]["compatibility_degrees"]
    assert maximum_matching_size(neighbours, len(new_cells)) == data["expected"]["compatibility_matching"]

    print(
        data["name"],
        {
            "parent": (len(vertices), len(edges), len(parent_matchings), parent_independent_pairs),
            "child": (len(child_vertices), len(child_edges), len(child_matchings), child_independent_pairs),
            "fibre": (len(parent_fibre), len(child_fibre)),
            "star": (len(mixed), len(escape), len(new_cells)),
            "compatibility_degrees": tuple(map(len, neighbours)),
            "compatibility_matching": maximum_matching_size(neighbours, len(new_cells)),
        },
    )


def main():
    verify_instance(HIT114)
    verify_instance(HIT315)
    print("HIT114_HIT315_ENDPOINT_STARS_INDEPENDENTLY_VERIFIED")


if __name__ == "__main__":
    main()
