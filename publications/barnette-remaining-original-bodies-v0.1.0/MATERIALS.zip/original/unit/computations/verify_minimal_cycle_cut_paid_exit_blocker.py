#!/usr/bin/env python3
"""Find and minimally certify a cycle--cut compatible paid-exit blocker.

The search is deliberately restricted to the smallest possible simple
bipartite label-incidence systems.  Every block has size two or three.  A
size-three block must be a rank triangle; a size-two block must be a
two-edge rank path or a parallel pair.  There is at most one parallel block
on each side, and the parallel endpoint pairs have a common possible root.

Endpoint assignments are streamed and quotiented by permutations of the
rank vertices.  The four incidence shapes exhaust all systems on at most
six labels after exchanging labels and blocks within the two fixed sides.
"""

from __future__ import annotations

from itertools import combinations, permutations, product


Edge = tuple[int, int]
Block = tuple[int, ...]


SHAPES: dict[str, tuple[tuple[Block, ...], tuple[Block, ...], int]] = {
    # Four labels: the only simple bipartite minimum-degree-two graph is C4.
    "C4": (((0, 1), (2, 3)), ((0, 2), (1, 3)), 3),
    # Six labels: these are the three connected simple bipartite shapes with
    # all degrees in {2,3}.
    "K2,3": (((0, 1, 2), (3, 4, 5)), ((0, 3), (1, 4), (2, 5)), 3),
    "C6": (((0, 1), (2, 3), (4, 5)), ((3, 4), (0, 2), (1, 5)), 4),
    "K3,2": (((0, 1), (2, 3), (4, 5)), ((0, 2, 4), (1, 3, 5)), 4),
}


def endpoint_map(blocks: tuple[Block, ...], label_count: int) -> tuple[int, ...]:
    result = [-1] * label_count
    for block_index, block in enumerate(blocks):
        for label in block:
            assert result[label] == -1
            result[label] = block_index
    assert -1 not in result
    return tuple(result)


def verify_simple_incidence(x_blocks: tuple[Block, ...], y_blocks: tuple[Block, ...]) -> None:
    label_count = sum(map(len, x_blocks))
    assert label_count == sum(map(len, y_blocks))
    x_end = endpoint_map(x_blocks, label_count)
    y_end = endpoint_map(y_blocks, label_count)
    assert len(set(zip(x_end, y_end, strict=True))) == label_count
    assert all(len(block) in (2, 3) for block in x_blocks + y_blocks)


def connected_rank_graph(vertex_count: int, ends: tuple[Edge, ...]) -> bool:
    adjacency = [set() for _ in range(vertex_count)]
    for left, right in ends:
        adjacency[left].add(right)
        adjacency[right].add(left)
    seen = {0}
    frontier = [0]
    while frontier:
        vertex = frontier.pop()
        for neighbour in adjacency[vertex] - seen:
            seen.add(neighbour)
            frontier.append(neighbour)
    return len(seen) == vertex_count


def block_type(block: Block, ends: tuple[Edge, ...]) -> str | None:
    block_ends = tuple(ends[label] for label in block)
    if len(block) == 2:
        first, second = block_ends
        if first == second:
            return "parallel"
        if len(set(first) & set(second)) == 1:
            return "path"
        return None
    assert len(block) == 3
    if len(set(block_ends)) != 3:
        return None
    vertices = set().union(*map(set, block_ends))
    return "triangle" if len(vertices) == 3 else None


def local_types(
    blocks: tuple[Block, ...], ends: tuple[Edge, ...]
) -> tuple[str, ...] | None:
    types = tuple(block_type(block, ends) for block in blocks)
    if any(kind is None for kind in types):
        return None
    return tuple(kind for kind in types if kind is not None)


def parallel_endpoint(
    blocks: tuple[Block, ...], types: tuple[str, ...], ends: tuple[Edge, ...]
) -> Edge | None:
    parallel = [ends[blocks[index][0]] for index, kind in enumerate(types) if kind == "parallel"]
    assert len(parallel) <= 1
    return parallel[0] if parallel else None


def simple_cycle_label_sets(
    x_blocks: tuple[Block, ...], y_blocks: tuple[Block, ...]
) -> tuple[frozenset[int], ...]:
    label_count = sum(map(len, x_blocks))
    x_end = endpoint_map(x_blocks, label_count)
    y_end = endpoint_map(y_blocks, label_count)
    cycles = []
    for size in range(4, label_count + 1, 2):
        for labels in combinations(range(label_count), size):
            degree: dict[tuple[str, int], int] = {}
            adjacency: dict[tuple[str, int], set[tuple[str, int]]] = {}
            for label in labels:
                left = ("x", x_end[label])
                right = ("y", y_end[label])
                degree[left] = degree.get(left, 0) + 1
                degree[right] = degree.get(right, 0) + 1
                adjacency.setdefault(left, set()).add(right)
                adjacency.setdefault(right, set()).add(left)
            if set(degree.values()) != {2}:
                continue
            start = next(iter(adjacency))
            seen = {start}
            frontier = [start]
            while frontier:
                vertex = frontier.pop()
                for neighbour in adjacency[vertex] - seen:
                    seen.add(neighbour)
                    frontier.append(neighbour)
            if len(seen) == len(adjacency):
                cycles.append(frozenset(labels))
    return tuple(cycles)


def is_exact_cut(
    labels: frozenset[int], vertex_count: int, ends: tuple[Edge, ...]
) -> bool:
    # Fix the final vertex outside the shore to quotient complementary shores.
    for mask in range(1, 1 << (vertex_count - 1)):
        shore = {vertex for vertex in range(vertex_count - 1) if mask >> vertex & 1}
        crossing = {
            label
            for label, (left, right) in enumerate(ends)
            if (left in shore) != (right in shore)
        }
        if crossing == labels:
            return True
    return False


def is_tree(selected: frozenset[int], vertex_count: int, ends: tuple[Edge, ...]) -> bool:
    if len(selected) != vertex_count - 1:
        return False
    parent = list(range(vertex_count))

    def find(vertex: int) -> int:
        while parent[vertex] != vertex:
            parent[vertex] = parent[parent[vertex]]
            vertex = parent[vertex]
        return vertex

    for label in selected:
        left, right = map(find, ends[label])
        if left == right:
            return False
        parent[right] = left
    return len({find(vertex) for vertex in range(vertex_count)}) == 1


def rank_violations(
    selected: frozenset[int], vertex_count: int, ends: tuple[Edge, ...]
) -> tuple[frozenset[int], ...]:
    violations = []
    vertices = range(vertex_count)
    for size in range(2, vertex_count):
        for shore_tuple in combinations(vertices, size):
            shore = frozenset(shore_tuple)
            internal = sum(set(ends[label]) <= shore for label in selected)
            if internal > size - 1:
                violations.append(shore)
    return tuple(violations)


def canonical_under_rank_relabelling(
    ends: tuple[Edge, ...], vertex_count: int
) -> tuple[Edge, ...]:
    images = []
    for image in permutations(range(vertex_count)):
        images.append(
            tuple(tuple(sorted((image[left], image[right]))) for left, right in ends)
        )
    return min(images)


def blocker_certificates(
    x_blocks: tuple[Block, ...],
    y_blocks: tuple[Block, ...],
    vertex_count: int,
    ends: tuple[Edge, ...],
) -> tuple[dict[str, object], ...]:
    bases = tuple(
        frozenset(choice)
        for choice in product(*x_blocks)
        if is_tree(frozenset(choice), vertex_count, ends)
    )
    if not bases:
        return ()
    certificates = []
    for active_mask in range(1, 1 << len(y_blocks)):
        active = frozenset(
            index for index in range(len(y_blocks)) if active_mask >> index & 1
        )
        cost_labels = frozenset(label for index in active for label in y_blocks[index])
        if any(len(base & cost_labels) <= len(active) for base in bases):
            continue
        for choice in product(*x_blocks):
            selected = frozenset(choice)
            if len(selected & cost_labels) > len(active):
                continue
            violations = rank_violations(selected, vertex_count, ends)
            if len(violations) != 1 or len(violations[0]) != 2:
                continue
            shore = violations[0]
            completions = set()
            paid_internal = []
            for block in x_blocks:
                internal_selected = [
                    label for label in block if label in selected and set(ends[label]) <= shore
                ]
                for internal in internal_selected:
                    exits = [
                        label
                        for label in block
                        if len(set(ends[label]) & shore) == 1
                    ]
                    if exits and internal not in cost_labels and all(
                        exit_label in cost_labels for exit_label in exits
                    ):
                        paid_internal.append(internal)
                    for exit_label in exits:
                        completion = (selected - {internal}) | {exit_label}
                        if is_tree(completion, vertex_count, ends):
                            completions.add(completion)
            if not completions or not paid_internal:
                continue
            certificates.append(
                {
                    "active": active,
                    "cost_labels": cost_labels,
                    "R": selected,
                    "W": shore,
                    "completions": tuple(sorted(completions, key=sorted)),
                    "bases": tuple(sorted(set(bases), key=sorted)),
                    "paid_internal": tuple(sorted(paid_internal)),
                }
            )
    return tuple(certificates)


def scan_shape(
    name: str, x_blocks: tuple[Block, ...], y_blocks: tuple[Block, ...], vertex_count: int
) -> tuple[int, int, tuple[Edge, ...] | None, dict[str, object] | None]:
    verify_simple_incidence(x_blocks, y_blocks)
    label_count = sum(map(len, x_blocks))
    edge_types = tuple(combinations(range(vertex_count), 2))
    cycles = simple_cycle_label_sets(x_blocks, y_blocks)
    locally_legal = 0
    blocker_count = 0
    first_ends = None
    first_certificate = None
    for ends in product(edge_types, repeat=label_count):
        if ends != canonical_under_rank_relabelling(ends, vertex_count):
            continue
        if not connected_rank_graph(vertex_count, ends):
            continue
        x_types = local_types(x_blocks, ends)
        y_types = local_types(y_blocks, ends)
        if x_types is None or y_types is None:
            continue
        if x_types.count("parallel") > 1 or y_types.count("parallel") > 1:
            continue
        x_parallel = parallel_endpoint(x_blocks, x_types, ends)
        y_parallel = parallel_endpoint(y_blocks, y_types, ends)
        if x_parallel is not None and y_parallel is not None:
            if not (set(x_parallel) & set(y_parallel)):
                continue
        if not all(is_exact_cut(cycle, vertex_count, ends) for cycle in cycles):
            continue
        locally_legal += 1
        certificates = blocker_certificates(x_blocks, y_blocks, vertex_count, ends)
        if certificates:
            blocker_count += 1
            if first_ends is None:
                first_ends = ends
                first_certificate = certificates[0]
    print(
        f"{name}: canonical_cycle_cut_local_systems={locally_legal} "
        f"blocker_endpoint_systems={blocker_count}"
    )
    return locally_legal, blocker_count, first_ends, first_certificate


def verify_explicit_witness() -> None:
    x_blocks, y_blocks, vertex_count = SHAPES["C6"]
    ends = ((0, 1), (0, 1), (0, 1), (0, 2), (2, 3), (0, 2))
    x_types = local_types(x_blocks, ends)
    y_types = local_types(y_blocks, ends)
    assert x_types == ("parallel", "path", "path")
    assert y_types == ("path", "parallel", "path")
    cycles = simple_cycle_label_sets(x_blocks, y_blocks)
    assert cycles == (frozenset(range(6)),)
    assert is_exact_cut(cycles[0], vertex_count, ends)
    certificates = blocker_certificates(x_blocks, y_blocks, vertex_count, ends)
    target = next(
        certificate
        for certificate in certificates
        if certificate["active"] == frozenset({0})
        and certificate["R"] == frozenset({0, 2, 4})
    )
    assert target["cost_labels"] == frozenset({3, 4})
    assert target["W"] == frozenset({0, 1})
    assert target["paid_internal"] == (2,)
    assert target["completions"] == (frozenset({0, 3, 4}),)
    assert target["bases"] == (
        frozenset({0, 3, 4}),
        frozenset({1, 3, 4}),
    )
    assert len(target["R"] & target["cost_labels"]) == 1
    assert all(len(base & target["cost_labels"]) == 2 for base in target["bases"])
    # The sole primal cycle is literally the rank cut delta({0,3}).
    shore = {0, 3}
    assert {
        label
        for label, (left, right) in enumerate(ends)
        if (left in shore) != (right in shore)
    } == set(range(6))


def verify_forced_primal_completion_is_antipodal_cube() -> None:
    """Check the exact legal-site datum omitted by the countermodel."""
    x_blocks, y_blocks, _vertex_count = SHAPES["C6"]
    label_count = 6
    x_end = endpoint_map(x_blocks, label_count)
    y_end = endpoint_map(y_blocks, label_count)
    # Vertices 0,1,2 are X0,X1,X2; 3,4,5 are Y0,Y1,Y2; 6=u, 7=a.
    adjacency = [set() for _ in range(8)]
    for label in range(label_count):
        left = x_end[label]
        right = 3 + y_end[label]
        adjacency[left].add(right)
        adjacency[right].add(left)
    for y_vertex in range(3, 6):
        adjacency[6].add(y_vertex)
        adjacency[y_vertex].add(6)
    for x_vertex in range(3):
        adjacency[7].add(x_vertex)
        adjacency[x_vertex].add(7)
    assert {len(neighbours) for neighbours in adjacency} == {3}
    # An explicit isomorphism to Q_3; u and a are complementary bitstrings.
    cube_image = {
        0: (0, 0, 0),
        7: (0, 0, 1),
        5: (0, 1, 0),
        2: (0, 1, 1),
        4: (1, 0, 0),
        1: (1, 0, 1),
        6: (1, 1, 0),
        3: (1, 1, 1),
    }
    for vertex in range(8):
        expected = {
            neighbour
            for neighbour in range(8)
            if sum(
                left != right
                for left, right in zip(cube_image[vertex], cube_image[neighbour], strict=True)
            )
            == 1
        }
        assert adjacency[vertex] == expected
    assert sum(
        left != right for left, right in zip(cube_image[6], cube_image[7], strict=True)
    ) == 3


def main() -> None:
    verify_explicit_witness()
    verify_forced_primal_completion_is_antipodal_cube()
    results = {
        name: scan_shape(name, *shape)
        for name, shape in SHAPES.items()
    }
    assert results["C4"][1] == 0
    assert results["K2,3"][1] == 0
    assert results["K3,2"][1] == 0
    assert results["C6"][1] > 0
    print("explicit_C6_blocker=verified")
    print("no_blocker_with_fewer_than_six_labels=verified")
    print("MINIMAL_CYCLE_CUT_PAID_EXIT_BLOCKER_VERIFIED")


if __name__ == "__main__":
    main()
