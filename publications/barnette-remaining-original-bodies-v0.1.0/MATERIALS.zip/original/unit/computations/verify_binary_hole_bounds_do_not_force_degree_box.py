#!/usr/bin/env python3
"""Verify the six-coordinate abstract separation used in Note 056."""

from itertools import combinations


EXCESS_VECTORS = (
    (-1, -1, 0, 0, 0, 1),
    (-1, 1, -1, -1, 0, 1),
    (-1, -1, 1, 1, -1, 0),
    (0, -1, -1, -1, 1, 1),
    (-1, -1, -1, 1, 1, 0),
    (-1, -1, 1, -1, 1, 0),
    (-1, 0, -1, 1, -1, 1),
    (-1, 0, 1, -1, -1, 1),
)
SEPARATOR = (1, 1, 3, 3, 3, 7)


def dot(left, right):
    return sum(a * b for a, b in zip(left, right, strict=True))


def main() -> None:
    assert all(set(vector) <= {-1, 0, 1} for vector in EXCESS_VECTORS)
    assert all(sum(vector) == -1 for vector in EXCESS_VECTORS)

    checked = 0
    for size in range(1, 7):
        threshold = 0 if size == 1 else -1
        for subset in combinations(range(6), size):
            checked += 1
            assert min(
                sum(vector[index] for index in subset)
                for vector in EXCESS_VECTORS
            ) <= threshold

    values = tuple(dot(SEPARATOR, vector) for vector in EXCESS_VECTORS)
    assert min(values) > 0
    print(
        {
            "vectors": len(EXCESS_VECTORS),
            "subsets_checked": checked,
            "strong_binary_hole_bounds": True,
            "degree_box": False,
            "separator": SEPARATOR,
            "separator_values": values,
        }
    )
    print("BINARY_HOLE_BOUNDS_DO_NOT_FORCE_DEGREE_BOX_VERIFIED")


if __name__ == "__main__":
    main()
