#!/usr/bin/env python3
"""Verify the finite three-port cotree states and a scalar-minimum blocker.

The first part checks the 14 cap states and all 17 tree-compatible pairs.
The second part checks an integral abstract profile whose two ordinary
marginal minima are safe but whose every compatible splice sum is unsafe.
It is a profile countermodel, not a graph-realizability certificate.
"""

from __future__ import annotations

from itertools import combinations


Ports = frozenset[int]
Partition = tuple[frozenset[int], ...]
State = tuple[Ports, Partition]

ALL_PORTS: Ports = frozenset({1, 2, 3})


def canonical(blocks: tuple[frozenset[int], ...]) -> Partition:
    return tuple(sorted(blocks, key=lambda block: (min(block), len(block))))


def partitions(ports: Ports) -> tuple[Partition, ...]:
    ordered = tuple(sorted(ports))
    if len(ordered) == 1:
        return ((ports,),)
    if len(ordered) == 2:
        left, right = ordered
        return (
            (ports,),
            canonical((frozenset({left}), frozenset({right}))),
        )
    assert ports == ALL_PORTS
    return (
        (ALL_PORTS,),
        canonical((frozenset({1}), frozenset({2, 3}))),
        canonical((frozenset({2}), frozenset({1, 3}))),
        canonical((frozenset({3}), frozenset({1, 2}))),
        canonical(
            (
                frozenset({1}),
                frozenset({2}),
                frozenset({3}),
            )
        ),
    )


def all_states() -> tuple[State, ...]:
    output = []
    for size in (1, 2, 3):
        for used in combinations(sorted(ALL_PORTS), size):
            ports = frozenset(used)
            output.extend((ports, partition) for partition in partitions(ports))
    return tuple(output)


def block_index(partition: Partition, port: int) -> int:
    return next(index for index, block in enumerate(partition) if port in block)


def quotient_is_tree(
    used: Ports, left: Partition, right: Partition
) -> bool:
    vertices = [
        *(("L", index) for index in range(len(left))),
        *(("R", index) for index in range(len(right))),
    ]
    edges = [
        (
            ("L", block_index(left, port)),
            ("R", block_index(right, port)),
        )
        for port in used
    ]
    if len(edges) != len(vertices) - 1:
        return False
    adjacency = {vertex: [] for vertex in vertices}
    for first, second in edges:
        adjacency[first].append(second)
        adjacency[second].append(first)
    seen = set()
    stack = [vertices[0]]
    while stack:
        vertex = stack.pop()
        if vertex in seen:
            continue
        seen.add(vertex)
        stack.extend(adjacency[vertex])
    return len(seen) == len(vertices)


def compatible_pairs(states: tuple[State, ...]):
    output = []
    for left in states:
        for right in states:
            if left[0] != right[0]:
                continue
            if quotient_is_tree(left[0], left[1], right[1]):
                output.append((left, right))
    return tuple(output)


def indiscrete(used: Ports) -> Partition:
    return (used,)


def discrete(used: Ports) -> Partition:
    return canonical(tuple(frozenset({port}) for port in used))


def two_block(singleton: int) -> Partition:
    return canonical(
        (
            frozenset({singleton}),
            ALL_PORTS - {singleton},
        )
    )


def specialized_profiles() -> tuple[dict[State, int], dict[State, int]]:
    """Return a minimal-orientation abstract defect profile.

    For two used edges the left shore must be discrete and the right shore
    connected.  For three used edges both shores have two components.
    """
    left: dict[State, int] = {}
    right: dict[State, int] = {}
    for used_tuple in combinations(sorted(ALL_PORTS), 2):
        used = frozenset(used_tuple)
        left[(used, discrete(used))] = 0
        right[(used, indiscrete(used))] = 1
    for singleton in (1, 2, 3):
        state = (ALL_PORTS, two_block(singleton))
        value = 0 if singleton == 1 else 1
        left[state] = value
        right[state] = value
    return left, right


def compatible_profile_sums(
    compatible: tuple[tuple[State, State], ...],
    left: dict[State, int],
    right: dict[State, int],
) -> dict[tuple[State, State], int]:
    return {
        pair: left[pair[0]] + right[pair[1]]
        for pair in compatible
        if pair[0] in left and pair[1] in right
    }


def main() -> None:
    states = all_states()
    assert len(states) == 14
    assert {size: sum(len(state[0]) == size for state in states) for size in (1, 2, 3)} == {
        1: 3,
        2: 6,
        3: 5,
    }

    compatible = compatible_pairs(states)
    distribution = {
        size: sum(len(left[0]) == size for left, _right in compatible)
        for size in (1, 2, 3)
    }
    assert len(compatible) == 17
    assert distribution == {1: 3, 2: 6, 3: 8}

    left, right = specialized_profiles()
    assert min(left.values()) == 0
    assert min(right.values()) == 0
    sums = compatible_profile_sums(compatible, left, right)
    assert len(sums) == 9
    assert {
        size: sum(len(pair[0][0]) == size for pair in sums)
        for size in (2, 3)
    } == {2: 3, 3: 6}
    assert min(sums.values()) == 1

    # Every positive finite entry is load-bearing: lowering it by one opens
    # a zero-defect compatible splice.
    positive = [
        ("L", state) for state, value in left.items() if value > 0
    ] + [
        ("R", state) for state, value in right.items() if value > 0
    ]
    for side, state in positive:
        trial_left = dict(left)
        trial_right = dict(right)
        if side == "L":
            trial_left[state] -= 1
        else:
            trial_right[state] -= 1
        trial = compatible_profile_sums(
            compatible, trial_left, trial_right
        )
        assert min(trial.values()) == 0

    # A single abstract all-one ordinary load witnesses every binary layer
    # at equality.  This records that even universal scalar marginals do
    # not restore the missing cap-state correlation at profile level.
    coordinates = tuple(range(4))
    for mask in range(1 << len(coordinates)):
        active = {
            coordinate for coordinate in coordinates
            if mask >> coordinate & 1
        }
        assert sum(1 for coordinate in coordinates if coordinate in active) == len(active)

    # With two holes and epsilon=1, the allowed component count is two;
    # the abstract splice has 2 + defect >= 3.
    assert 2 + min(sums.values()) == 3

    print("cap_states", len(states))
    print("compatible_pairs", len(compatible))
    print("minimum_splice_defect", min(sums.values()))
    print("THREE_PORT_COTREE_CONVOLUTION_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
