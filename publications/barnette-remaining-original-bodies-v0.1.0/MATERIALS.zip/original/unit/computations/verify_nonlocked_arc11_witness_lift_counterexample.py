#!/usr/bin/env python3
"""Standalone verification of a real nonlocked, arc-11 witness-lift failure."""

from __future__ import annotations

from functools import lru_cache
from itertools import combinations, product

import networkx as nx


REDUCED_GRAPH6 = "S???????F?Y?b?W_DO?Y?DG?Oo?E_?B_?"
EXPANDED_DUAL_GRAPH6 = "WhEK?G@?i??O?BGA??WA??GC????@G?gG??K??CGO??a??P"
REDUCED_EDGES = (
    (0, 1), (0, 2), (0, 3), (0, 4),
    (1, 2), (1, 3), (1, 6), (1, 8), (1, 9),
    (2, 4), (2, 5), (2, 7), (2, 8),
    (3, 4), (3, 5), (3, 6), (3, 7), (3, 10), (3, 11),
    (4, 5), (5, 7),
    (6, 9), (6, 11),
    (7, 8), (7, 9), (7, 10),
    (8, 9),
    (9, 10), (9, 11),
    (10, 11),
)
EXPANDED_EDGES = (
    (0, 1), (0, 2), (0, 4), (0, 12), (0, 13), (0, 14),
    (1, 2), (1, 6), (1, 8), (1, 9), (1, 12),
    (2, 4), (2, 5), (2, 7), (2, 8),
    (4, 5), (4, 13),
    (5, 7), (5, 13),
    (6, 9), (6, 11), (6, 12),
    (7, 8), (7, 9), (7, 10), (7, 13),
    (8, 9),
    (9, 10), (9, 11),
    (10, 11), (10, 12), (10, 13), (10, 14),
    (11, 12),
    (12, 14), (13, 14),
)

SPLIT_VERTEX = 3
ROTATION = (0, 1, 6, 11, 10, 7, 5, 4)
GATES = (0, 10)
LEFT_ARC = (0, 1, 6, 11, 10)
RIGHT_ARC = (10, 7, 5, 4, 0)
LEFT, RIGHT, CENTRE = 12, 13, 14
ROOT = (0, 2)
PRIMAL_ROOT = (0, 10)
PRIMAL_GATES = ((1, 11), (9, 18))
PRIMAL_MATCHING = (
    (0, 10), (1, 11), (2, 14), (3, 17), (4, 12),
    (5, 16), (6, 13), (7, 15), (8, 19), (9, 18),
)
REDUCED_COLOUR = {
    0: 0, 1: 1, 2: 0, 3: 0, 4: 1, 5: 0,
    6: 0, 7: 1, 8: 0, 9: 1, 10: 0, 11: 1,
}


def edge(first: int, second: int) -> tuple[int, int]:
    return (first, second) if first < second else (second, first)


def edge_set(graph: nx.Graph) -> set[tuple[int, int]]:
    return {edge(*item) for item in graph.edges()}


def plane_faces(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    planar, embedding = nx.check_planarity(graph)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    used: set[tuple[int, int]] = set()
    faces = []
    for first, second in embedding.edges():
        if (first, second) not in used:
            faces.append(tuple(embedding.traverse_face(first, second, used)))
    directed = [
        (face[index], face[(index + 1) % len(face)])
        for face in faces
        for index in range(len(face))
    ]
    expected = {
        dart
        for first, second in graph.edges()
        for dart in ((first, second), (second, first))
    }
    assert len(directed) == len(set(directed)) == 2 * graph.number_of_edges()
    assert set(directed) == expected
    assert graph.number_of_nodes() - graph.number_of_edges() + len(faces) == 2
    return tuple(faces)


def verify_triangulation(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    assert nx.number_of_selfloops(graph) == 0
    assert graph.number_of_edges() == 3 * graph.number_of_nodes() - 6
    assert all(degree % 2 == 0 for _, degree in graph.degree())
    assert nx.node_connectivity(graph) >= 4
    faces = plane_faces(graph)
    assert all(len(face) == 3 for face in faces)
    return faces


def dual(graph: nx.Graph, faces: tuple[tuple[int, ...], ...]) -> nx.Graph:
    incidence: dict[tuple[int, int], list[int]] = {}
    for face_index, face in enumerate(faces):
        for index, first in enumerate(face):
            second = face[(index + 1) % len(face)]
            incidence.setdefault(edge(first, second), []).append(face_index)
    assert set(incidence) == edge_set(graph)
    assert all(len(pair) == 2 for pair in incidence.values())
    answer = nx.Graph()
    answer.add_nodes_from(range(len(faces)))
    answer.add_edges_from(pair for pair in incidence.values())
    return answer


def edge_face_incidence(
    graph: nx.Graph, faces: tuple[tuple[int, ...], ...]
) -> dict[tuple[int, int], tuple[int, int]]:
    incidence: dict[tuple[int, int], list[int]] = {}
    for face_index, face in enumerate(faces):
        for index, first in enumerate(face):
            second = face[(index + 1) % len(face)]
            incidence.setdefault(edge(first, second), []).append(face_index)
    assert set(incidence) == edge_set(graph)
    assert all(len(pair) == 2 for pair in incidence.values())
    return {item: tuple(pair) for item, pair in incidence.items()}  # type: ignore[return-value]


def perfect_matching_decider(graph: nx.Graph):
    vertices = tuple(sorted(graph))
    index = {vertex: position for position, vertex in enumerate(vertices)}
    neighbour_masks = {
        index[vertex]: sum(1 << index[neighbour] for neighbour in graph[vertex])
        for vertex in vertices
    }

    @lru_cache(maxsize=None)
    def exists(mask: int) -> bool:
        if not mask:
            return True
        if mask.bit_count() % 2:
            return False
        positions = [item for item in range(len(vertices)) if mask & (1 << item)]
        first = min(positions, key=lambda item: (neighbour_masks[item] & mask).bit_count())
        choices = neighbour_masks[first] & mask
        without_first = mask ^ (1 << first)
        while choices:
            bit = choices & -choices
            choices ^= bit
            if exists(without_first ^ bit):
                return True
        return False

    return vertices, index, exists


def verify_brace(graph: nx.Graph) -> tuple[int, int]:
    assert nx.number_of_selfloops(graph) == 0
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.check_planarity(graph)[0]
    assert nx.node_connectivity(graph) >= 3
    vertices, index, matching_exists = perfect_matching_decider(graph)
    full_mask = (1 << len(vertices)) - 1
    independent_pairs = 0
    for first, second in combinations(tuple(graph.edges()), 2):
        endpoints = set(first + second)
        if len(endpoints) != 4:
            continue
        independent_pairs += 1
        remaining = full_mask
        for vertex in endpoints:
            remaining ^= 1 << index[vertex]
        assert matching_exists(remaining)

    hall_subsets = 0
    colour = nx.bipartite.color(graph)
    for value in (0, 1):
        side = tuple(sorted(vertex for vertex in graph if colour[vertex] == value))
        for size in range(1, len(side) - 1):
            for shore in combinations(side, size):
                hall_subsets += 1
                neighbours = set().union(*(set(graph[vertex]) for vertex in shore))
                assert len(neighbours) >= size + 2
    return independent_pairs, hall_subsets


def is_nae(faces: tuple[tuple[int, ...], ...], colour: dict[int, int]) -> bool:
    return all(len({colour[vertex] for vertex in face}) == 2 for face in faces)


def profile(
    graph: nx.Graph,
    faces: tuple[tuple[int, ...], ...],
    colour: dict[int, int],
) -> tuple[bool, int | None, int | None, bool]:
    if not is_nae(faces, colour):
        return False, None, None, False
    mono = nx.Graph()
    mono.add_nodes_from(graph)
    mono.add_edges_from(
        (first, second)
        for first, second in graph.edges()
        if colour[first] == colour[second]
    )
    components = nx.number_connected_components(mono)
    beta = mono.number_of_edges() - mono.number_of_nodes() + components
    root_on_cycle = False
    if mono.has_edge(*ROOT):
        test = mono.copy()
        test.remove_edge(*ROOT)
        root_on_cycle = nx.number_connected_components(test) == components
    return True, components, beta, root_on_cycle


def target(profile_value: tuple[bool, int | None, int | None, bool]) -> bool:
    return profile_value[0] and profile_value[2] == 1 and profile_value[3]


def complement_classes(vertices: tuple[int, ...]):
    anchor = min(vertices)
    others = tuple(vertex for vertex in vertices if vertex != anchor)
    for bits in product((0, 1), repeat=len(others)):
        yield {anchor: 0, **dict(zip(others, bits, strict=True))}


def reduce_expanded(expanded: nx.Graph) -> nx.Graph:
    reduced = expanded.copy()
    reduced.remove_node(CENTRE)
    quotient = nx.contracted_nodes(reduced, LEFT, RIGHT, self_loops=False)
    quotient = nx.relabel_nodes(quotient, {LEFT: SPLIT_VERTEX})
    return nx.Graph(quotient)


def main() -> None:
    reduced = nx.Graph(REDUCED_EDGES)
    expanded = nx.Graph(EXPANDED_EDGES)
    original_primal = nx.from_graph6_bytes(REDUCED_GRAPH6.encode())
    original_faces = plane_faces(original_primal)
    assert edge_set(dual(original_primal, original_faces)) == edge_set(reduced)
    reduced_faces = verify_triangulation(reduced)
    expanded_faces = verify_triangulation(expanded)
    assert set(ROTATION) == set(reduced[SPLIT_VERTEX])
    assert all(
        reduced.has_edge(ROTATION[index], ROTATION[(index + 1) % len(ROTATION)])
        for index in range(len(ROTATION))
    )
    rebuilt = reduced.copy()
    rebuilt.remove_node(SPLIT_VERTEX)
    rebuilt.add_nodes_from((LEFT, RIGHT, CENTRE))
    rebuilt.add_edges_from((LEFT, neighbour) for neighbour in LEFT_ARC)
    rebuilt.add_edges_from((RIGHT, neighbour) for neighbour in RIGHT_ARC)
    rebuilt.add_edges_from(
        (
            (CENTRE, LEFT),
            (CENTRE, LEFT_ARC[0]),
            (CENTRE, RIGHT),
            (CENTRE, LEFT_ARC[-1]),
        )
    )
    assert edge_set(rebuilt) == edge_set(expanded)
    assert edge_set(reduce_expanded(expanded)) == edge_set(reduced)
    assert tuple(ROTATION[0:5]) == LEFT_ARC
    assert tuple(ROTATION[4:] + ROTATION[:1]) == RIGHT_ARC
    assert ROOT in edge_set(reduced) and ROOT in edge_set(expanded)

    expanded_primal = dual(expanded, expanded_faces)
    assert nx.is_isomorphic(
        expanded_primal, nx.from_graph6_bytes(EXPANDED_DUAL_GRAPH6.encode())
    )
    reduced_checks = verify_brace(original_primal)
    expanded_checks = verify_brace(expanded_primal)
    assert original_primal.number_of_nodes() == 20
    assert expanded_primal.number_of_nodes() == 24

    assert profile(reduced, reduced_faces, REDUCED_COLOUR) == (True, 3, 1, True)
    assert REDUCED_COLOUR[GATES[0]] == REDUCED_COLOUR[SPLIT_VERTEX]
    assert REDUCED_COLOUR[GATES[1]] == REDUCED_COLOUR[SPLIT_VERTEX]
    assert all(
        REDUCED_COLOUR[first] != REDUCED_COLOUR[second]
        for arc in (LEFT_ARC, RIGHT_ARC)
        for first, second in zip(arc, arc[1:])
    )

    primal_incidence = edge_face_incidence(original_primal, original_faces)
    assert edge(*primal_incidence[PRIMAL_ROOT]) == ROOT
    assert {
        edge(*primal_incidence[primal_gate]) for primal_gate in PRIMAL_GATES
    } == {edge(SPLIT_VERTEX, gate) for gate in GATES}
    induced_matching = tuple(
        sorted(
            primal_edge
            for primal_edge, incident_faces in primal_incidence.items()
            if REDUCED_COLOUR[incident_faces[0]]
            == REDUCED_COLOUR[incident_faces[1]]
        )
    )
    assert induced_matching == PRIMAL_MATCHING
    assert PRIMAL_ROOT in induced_matching and set(PRIMAL_GATES) <= set(induced_matching)
    assert len({vertex for matching_edge in induced_matching for vertex in matching_edge}) == 20
    complement = original_primal.copy()
    complement.remove_edges_from(induced_matching)
    complement_components = list(nx.connected_components(complement))
    assert len(complement_components) == 2
    assert all(
        all(degree == 2 for _, degree in complement.subgraph(component).degree())
        for component in complement_components
    )
    assert not any(set(PRIMAL_ROOT) <= component for component in complement_components)

    expected = {
        (0, 0, 0): (False, None, None, False),
        (0, 0, 1): (True, 4, 2, True),
        (0, 1, 0): (False, None, None, False),
        (0, 1, 1): (True, 2, 0, False),
        (1, 0, 0): (False, None, None, False),
        (1, 0, 1): (True, 4, 2, True),
        (1, 1, 0): (True, 3, 1, False),
        (1, 1, 1): (True, 4, 2, False),
    }
    fixed = {
        vertex: value
        for vertex, value in REDUCED_COLOUR.items()
        if vertex != SPLIT_VERTEX
    }
    observed = {}
    for bits in product((0, 1), repeat=3):
        colour = {**fixed, LEFT: bits[0], RIGHT: bits[1], CENTRE: bits[2]}
        observed[bits] = profile(expanded, expanded_faces, colour)
    assert observed == expected
    assert not any(target(item) for item in observed.values())

    reduced_family = []
    for colour in complement_classes(tuple(sorted(reduced))):
        if not target(profile(reduced, reduced_faces, colour)):
            continue
        fixed_colour = {
            vertex: value for vertex, value in colour.items() if vertex != SPLIT_VERTEX
        }
        lift_count = 0
        for bits in product((0, 1), repeat=3):
            lifted = {
                **fixed_colour,
                LEFT: bits[0],
                RIGHT: bits[1],
                CENTRE: bits[2],
            }
            lift_count += int(target(profile(expanded, expanded_faces, lifted)))
        gate_usage = tuple(colour[gate] == colour[SPLIT_VERTEX] for gate in GATES)
        arc_type = tuple(
            all(colour[first] != colour[second] for first, second in zip(arc, arc[1:]))
            for arc in (LEFT_ARC, RIGHT_ARC)
        )
        locked = all(gate_usage) and not any(arc_type)
        reduced_family.append((lift_count, locked))

    reduced_root_targets = len(reduced_family)
    assert sum(lift_count > 0 for lift_count, _locked in reduced_family) == 6
    assert sum(lift_count == 0 for lift_count, _locked in reduced_family) == 3
    assert sum(lift_count == 0 and locked for lift_count, locked in reduced_family) == 1
    assert sum(lift_count == 0 and not locked for lift_count, locked in reduced_family) == 2
    expanded_root_targets = sum(
        target(profile(expanded, expanded_faces, colour))
        for colour in complement_classes(tuple(sorted(expanded)))
    )
    assert reduced_root_targets == 9
    assert expanded_root_targets == 11

    print("NONLOCKED_ARC11_WITNESS_LIFT_COUNTEREXAMPLE_VERIFIED")
    print("reduced_brace_independent_pairs_hall_subsets", reduced_checks)
    print("expanded_brace_independent_pairs_hall_subsets", expanded_checks)
    print("eight_assignments", observed)
    print("reduced_expanded_rooted_targets_mod_complement", (9, 11))
    print("reduced_family_liftable_nonliftable", (6, 3))


if __name__ == "__main__":
    main()
