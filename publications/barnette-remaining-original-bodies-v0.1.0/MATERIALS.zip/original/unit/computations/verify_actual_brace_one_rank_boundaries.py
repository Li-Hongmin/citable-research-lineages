#!/usr/bin/env python3
"""Verify three sharp boundaries for one-rank-relaxed FEC slices.

The checks are fixed and exact:

1. an integral one-hole transversal at a legal cube site whose offending
   dual parallel labels lift to two adjacent primal edges;
2. a rank-six full-X half-integral extreme point, together with the fact
   that this fixed rooted block system is not realized by an order-twelve
   plane cubic bipartite brace site;
3. a half-integral extreme point at a genuine order-sixteen brace site.

The two genuine sites have no strict binary layer: their full common-base
minimum is at most |A| for every binary cost set A.  Thus the checks refute
uncosted integrality/extraction claims but do not decide the cost-qualified
leaf-deletion statement of Note 044.
"""

from __future__ import annotations

from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, permutations
from pathlib import Path
import subprocess

import networkx as nx
import sympy as sp


HERE = Path(__file__).resolve().parent
UTILITY_PATH = HERE / "verify_small_laminar_leaf_boundaries.py"
SPEC = spec_from_file_location("small_leaf_boundaries", UTILITY_PATH)
assert SPEC is not None and SPEC.loader is not None
UTILITY = module_from_spec(SPEC)
SPEC.loader.exec_module(UTILITY)

Edge = tuple[int, int]
Site = tuple[int, int, int, int]


def edge(left: int, right: int) -> Edge:
    return (left, right) if left < right else (right, left)


def all_proper_shores(vertices: tuple[int, ...]):
    for size in range(1, len(vertices)):
        for shore in combinations(vertices, size):
            yield frozenset(shore)


def internal_row(
    ground: tuple[Edge, ...],
    q_ends: dict[Edge, tuple[int, int]],
    shore: frozenset[int],
) -> tuple[int, ...]:
    return tuple(
        int(q_ends[label][0] in shore and q_ends[label][1] in shore)
        for label in ground
    )


def dot(row: tuple[int, ...], vector: tuple[Fraction, ...]) -> Fraction:
    return sum((Fraction(a) * b for a, b in zip(row, vector)), Fraction(0))


def verify_cube_star_absorption() -> None:
    graph = nx.Graph()
    graph.add_edges_from(
        (
            (0, 1),
            (0, 3),
            (0, 4),
            (1, 2),
            (1, 7),
            (2, 3),
            (2, 6),
            (3, 5),
            (4, 5),
            (4, 7),
            (5, 6),
            (6, 7),
        )
    )
    site = (0, 3, 2, 1)
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.node_connectivity(graph) == 3
    assert UTILITY.has_oriented_common_face(graph, site)
    assert UTILITY.is_two_extendable(graph)

    data = UTILITY.partition_data(graph, site)
    blocks: dict[int, tuple[Edge, ...]] = data["blocks"]
    q_ends: dict[Edge, tuple[int, int]] = data["q_ends"]
    q_vertices: tuple[int, ...] = data["q_vertices"]
    bases: tuple[frozenset[Edge], ...] = data["bases"]
    x_vertices: tuple[int, ...] = data["x_vertices"]
    assert blocks == {
        2: ((2, 3), (2, 6)),
        5: ((3, 5), (4, 5), (5, 6)),
        7: ((4, 7), (6, 7)),
    }

    support = frozenset((edge(2, 3), edge(3, 5), edge(4, 7)))
    assert all(len(support & set(block)) == 1 for block in blocks.values())
    violations = []
    for shore in all_proper_shores(q_vertices):
        value = sum(
            q_ends[label][0] in shore and q_ends[label][1] in shore
            for label in support
        )
        if value > len(shore) - 1:
            violations.append((shore, value))
    assert violations == [(frozenset((1, 2)), 2)]

    # The two dual-parallel labels are adjacent in the primal graph and are
    # absorbed by the restored facial cubic star at vertex 3.
    assert frozenset(q_ends[edge(2, 3)]) == frozenset((1, 2))
    assert frozenset(q_ends[edge(3, 5)]) == frozenset((1, 2))
    assert set(edge(2, 3)) & set(edge(3, 5)) == {3}
    assert {edge(0, 3), edge(2, 3), edge(3, 5)} == {
        edge(3, neighbour) for neighbour in graph[3]
    }

    colour = nx.bipartite.color(graph)
    y_vertices = tuple(
        sorted(
            vertex
            for vertex in graph
            if colour[vertex] != colour[site[0]] and vertex != site[3]
        )
    )
    assert x_vertices == (2, 5, 7)
    assert y_vertices == (3, 4, 6)

    # Note 047's paid-exit bound is tight for A={4,6}.  Each of the two
    # selected internal labels has zero cost and only unit-cost boundary
    # exits; removing the one unit of excess therefore costs exactly one,
    # equal to the available binary slack.
    active_paid_exit = {4, 6}
    assert UTILITY.cost(support, x_vertices, active_paid_exit) == 1
    region = frozenset((1, 2))
    selected_internal = {
        label
        for label in support
        if q_ends[label][0] in region and q_ends[label][1] in region
    }
    assert selected_internal == {edge(2, 3), edge(3, 5)}
    removable = {}
    for label in selected_internal:
        block = next(block for block in blocks.values() if label in block)
        exits = {
            candidate
            for candidate in block
            if sum(vertex in region for vertex in q_ends[candidate]) == 1
        }
        if exits:
            removable[label] = exits
    assert set(removable) == {edge(3, 5)}
    label = edge(3, 5)
    assert min(
        UTILITY.cost(frozenset((candidate,)), x_vertices, active_paid_exit)
        for candidate in removable[label]
    ) - UTILITY.cost(frozenset((label,)), x_vertices, active_paid_exit) == 1
    assert len(active_paid_exit) - UTILITY.cost(
        support, x_vertices, active_paid_exit
    ) == 1

    tested = 0
    for size in range(len(y_vertices) + 1):
        for selected in combinations(y_vertices, size):
            active = set(selected)
            mu = min(UTILITY.cost(base, x_vertices, active) for base in bases)
            assert mu <= size
            tested += 1
    assert tested == 8


# The abstract rank-six obstruction uses labelled parallel edges.  Indices,
# rather than endpoint pairs, distinguish labels inside and across blocks.
RANK6_EDGES = (
    (0, 1),
    (0, 2),
    (1, 2),
    (0, 4),
    (1, 4),
    (1, 3),
    (1, 3),
    (2, 4),
    (3, 4),
    (0, 1),
    (0, 5),
    (1, 5),
)
RANK6_BLOCKS = ((0, 1, 2), (3, 4), (5, 6), (7, 8), (9, 10, 11))
RANK6_TYPES = ("T", "P", "R", "P", "T")
RANK6_X = (
    Fraction(0),
    Fraction(0),
    Fraction(1),
    Fraction(1, 2),
    Fraction(1, 2),
    Fraction(0),
    Fraction(1),
    Fraction(1, 2),
    Fraction(1, 2),
    Fraction(0),
    Fraction(1),
    Fraction(0),
)


def verify_rank_six_extreme_point() -> None:
    graph = nx.MultiGraph()
    graph.add_nodes_from(range(6))
    graph.add_edges_from(RANK6_EDGES)
    assert nx.is_connected(graph)
    assert nx.number_of_selfloops(graph) == 0
    assert nx.check_planarity(graph)[0]
    assert [sum((RANK6_X[i] for i in block), Fraction(0)) for block in RANK6_BLOCKS] == [
        Fraction(1)
    ] * 5

    ground = tuple(range(12))
    q_ends = dict(enumerate(RANK6_EDGES))
    violations = []
    for shore in all_proper_shores(tuple(range(6))):
        row = tuple(
            int(q_ends[i][0] in shore and q_ends[i][1] in shore) for i in ground
        )
        value = dot(row, RANK6_X)
        if value > len(shore) - 1:
            violations.append((shore, value))
    assert violations == [(frozenset((1, 2, 3, 4)), Fraction(7, 2))]

    rows: list[list[int]] = []
    rows.extend([[int(i in block) for i in ground] for block in RANK6_BLOCKS])
    rows.extend([[int(i == zero) for i in ground] for zero in (0, 1, 5, 9, 11)])
    for shore in (frozenset((1, 2, 4)), frozenset((1, 3, 4))):
        rows.append(
            [int(RANK6_EDGES[i][0] in shore and RANK6_EDGES[i][1] in shore) for i in ground]
        )
    active = sp.Matrix(rows)
    assert active.rank() == 12
    assert active.det() == -2


def rank6_block_type(endpoints: tuple[tuple[int, int], ...]) -> str:
    pairs = tuple(sorted(tuple(sorted(pair)) for pair in endpoints))
    if len(pairs) == 2 and pairs[0] == pairs[1]:
        return "R"
    if len(pairs) == 2 and len(set(pairs[0]) & set(pairs[1])) == 1:
        return "P"
    if (
        len(pairs) == 3
        and len(set(pairs)) == 3
        and len(set().union(*(set(pair) for pair in pairs))) == 3
    ):
        return "T"
    return "?"


def oriented_sites(graph: nx.Graph) -> set[Site]:
    planar, embedding = nx.check_planarity(graph)
    assert planar
    colour = nx.bipartite.color(graph)
    seen: set[tuple[int, int]] = set()
    faces = []
    for first, second in embedding.edges():
        if (first, second) not in seen:
            faces.append(tuple(embedding.traverse_face(first, second, seen)))

    sites = set()
    for face in faces:
        order = len(face)
        for orientation in (face, tuple(reversed(face))):
            for start in range(order):
                u = orientation[start]
                v = orientation[(start + 1) % order]
                for gap in range(2, order - 1):
                    z = orientation[(start + gap) % order]
                    a = orientation[(start + gap + 1) % order]
                    if len({u, v, z, a}) == 4 and colour[u] == colour[z]:
                        sites.add((u, v, z, a))
    return sites


def same_rank6_rooted_block_system(
    actual: tuple[tuple[str, tuple[tuple[int, int], ...]], ...], root: int
) -> bool:
    if sorted(kind for kind, _ in actual) != sorted(RANK6_TYPES):
        return False
    actual_by_type = {
        kind: [i for i, (candidate, _) in enumerate(actual) if candidate == kind]
        for kind in ("T", "P", "R")
    }
    fixed_by_type = {"T": (0, 4), "P": (1, 3), "R": (2,)}
    for rank_permutation in permutations(range(6)):
        rank_map = dict(enumerate(rank_permutation))
        if rank_map[root] not in {1, 3}:
            continue
        for triangle_order in permutations(fixed_by_type["T"]):
            for path_order in permutations(fixed_by_type["P"]):
                block_map = {
                    actual_by_type["T"][i]: triangle_order[i] for i in range(2)
                }
                block_map.update(
                    {actual_by_type["P"][i]: path_order[i] for i in range(2)}
                )
                block_map[actual_by_type["R"][0]] = fixed_by_type["R"][0]
                if all(
                    sorted(
                        tuple(sorted((rank_map[a], rank_map[b])))
                        for a, b in actual[actual_index][1]
                    )
                    == sorted(
                        tuple(sorted(RANK6_EDGES[label]))
                        for label in RANK6_BLOCKS[fixed_index]
                    )
                    for actual_index, fixed_index in block_map.items()
                ):
                    return True
    return False


def verify_no_rank_six_order_twelve_realization() -> None:
    graph6_lines = subprocess.check_output(
        ("geng", "-cq", "-d3", "-D3", "12"), text=True
    ).splitlines()
    assert len(graph6_lines) == 85
    retained = 0
    braces = 0
    sites = 0
    occurrences = []
    for graph6 in graph6_lines:
        graph = nx.from_graph6_bytes(graph6.encode())
        if not nx.is_bipartite(graph):
            continue
        if not nx.check_planarity(graph)[0] or nx.node_connectivity(graph) < 3:
            continue
        retained += 1
        if not UTILITY.is_two_extendable(graph):
            continue
        braces += 1
        colour = nx.bipartite.color(graph)
        for site in oriented_sites(graph):
            sites += 1
            u, _v, _z, a = site
            q_ends, root = UTILITY.contracted_dual(graph, site)
            reduced = graph.copy()
            reduced.remove_nodes_from((u, a))
            actual_blocks = []
            for x_vertex in reduced:
                if colour[x_vertex] != colour[u]:
                    continue
                labels = tuple(edge(x_vertex, y) for y in reduced[x_vertex])
                endpoints = tuple(tuple(sorted(q_ends[label])) for label in labels)
                actual_blocks.append((rank6_block_type(endpoints), endpoints))
            actual = tuple(actual_blocks)
            if same_rank6_rooted_block_system(actual, root):
                occurrences.append((graph6, site))
    assert retained == 1
    assert braces == 1
    assert sites == 96
    assert occurrences == []


def verify_order_sixteen_actual_fractional_vertex() -> None:
    graph = nx.from_graph6_bytes(b"OlCGHD@?g?_@@@A?_?k?P")
    site = (15, 14, 13, 4)
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.node_connectivity(graph) == 3
    assert UTILITY.has_oriented_common_face(graph, site)
    assert UTILITY.is_two_extendable(graph)

    data = UTILITY.partition_data(graph, site)
    ground: tuple[Edge, ...] = tuple(sorted(data["ground"]))
    blocks: dict[int, tuple[Edge, ...]] = data["blocks"]
    q_ends: dict[Edge, tuple[int, int]] = data["q_ends"]
    q_vertices: tuple[int, ...] = data["q_vertices"]
    x_vertices: tuple[int, ...] = data["x_vertices"]
    bases: tuple[frozenset[Edge], ...] = data["bases"]
    assert len(ground) == 18
    assert x_vertices == (1, 3, 5, 7, 9, 11, 13)
    assert q_vertices == tuple(range(8))
    assert len(bases) == 112

    values = {
        edge(1, 8): Fraction(1),
        edge(2, 3): Fraction(1),
        edge(5, 6): Fraction(1, 2),
        edge(5, 12): Fraction(1, 2),
        edge(6, 7): Fraction(1, 2),
        edge(6, 9): Fraction(1, 2),
        edge(7, 8): Fraction(1, 2),
        edge(9, 10): Fraction(1, 2),
        edge(11, 12): Fraction(1),
        edge(13, 14): Fraction(1),
    }
    vector = tuple(values.get(label, Fraction(0)) for label in ground)
    index = {label: i for i, label in enumerate(ground)}
    for block in blocks.values():
        assert sum((vector[index[label]] for label in block), Fraction(0)) == 1

    omitted = frozenset((4, 5, 7))
    violations = []
    tight = []
    for shore in all_proper_shores(q_vertices):
        value = dot(internal_row(ground, q_ends, shore), vector)
        bound = Fraction(len(shore) - 1)
        if value > bound:
            violations.append((shore, value, bound))
        elif value == bound:
            tight.append(shore)
    assert violations == [(omitted, Fraction(5, 2), Fraction(2))]

    # Seven block rows, eight zero-coordinate rows, and three tight graphic
    # rows form a square full-rank active system.
    rows: list[list[int]] = []
    rows.extend([[int(label in block) for label in ground] for block in blocks.values()])
    zero_labels = (
        edge(0, 1),
        edge(0, 3),
        edge(1, 2),
        edge(2, 7),
        edge(8, 9),
        edge(10, 11),
        edge(11, 14),
        edge(12, 13),
    )
    rows.extend([[int(label == zero) for label in ground] for zero in zero_labels])
    active_shores = (
        frozenset((1, 4, 5, 7)),
        frozenset((4, 5, 6, 7)),
        frozenset((3, 4, 5, 6, 7)),
    )
    assert all(shore in tight for shore in active_shores)
    rows.extend([list(internal_row(ground, q_ends, shore)) for shore in active_shores])
    active = sp.Matrix(rows)
    assert active.shape == (18, 18)
    assert active.rank() == 18

    # The exact fractional Y-load profile is useful for locating the missing
    # cost information.  It is not itself an integrality certificate.
    colour = nx.bipartite.color(graph)
    y_vertices = tuple(
        sorted(
            vertex
            for vertex in graph
            if colour[vertex] != colour[site[0]] and vertex != site[3]
        )
    )
    assert y_vertices == (0, 2, 6, 8, 10, 12, 14)
    x_side = set(x_vertices)
    loads = []
    for y in y_vertices:
        loads.append(
            sum(
                (
                    vector[index[label]]
                    for label in ground
                    if y in label and any(vertex in x_side for vertex in label)
                ),
                Fraction(0),
            )
        )
    assert tuple(loads) == (
        Fraction(0),
        Fraction(1),
        Fraction(3, 2),
        Fraction(3, 2),
        Fraction(1, 2),
        Fraction(3, 2),
        Fraction(1),
    )

    tested = 0
    for size in range(len(y_vertices) + 1):
        for selected in combinations(y_vertices, size):
            active_y = set(selected)
            mu = min(UTILITY.cost(base, x_vertices, active_y) for base in bases)
            assert mu <= size
            tested += 1
    assert tested == 128


def main() -> None:
    verify_cube_star_absorption()
    verify_rank_six_extreme_point()
    verify_no_rank_six_order_twelve_realization()
    verify_order_sixteen_actual_fractional_vertex()
    print("ACTUAL_BRACE_ONE_RANK_BOUNDARIES_VERIFIED")


if __name__ == "__main__":
    main()
