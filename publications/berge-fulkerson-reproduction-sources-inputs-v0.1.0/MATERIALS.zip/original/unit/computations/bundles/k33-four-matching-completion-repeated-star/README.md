# \(K_{3,3}\) repeated-star completion classification

This bundle verifies the six-permutation classification in
[Note 077](../../../notes/077-one-k33-factor-cannot-block-all-three-repeated-star-targets.md).
It normalizes one singleton permutation, exhausts the remaining \(6^5\)
assignments, and records which of the three target quadruples cannot be
completed to a six-matching double cover of \(K_{3,3}\).

Run on Omen with one process:

```bash
python3 verify.py
```

The final line is

```text
K33_REPEATED_STAR_COMPLETION_CLASSIFIED
```

The script uses only the Python standard library.  The promoted Omen run on
2026-09-04 took 0.08 seconds with peak RSS 9,216 KB; its output is frozen in
[`omen-run.log`](omen-run.log).
