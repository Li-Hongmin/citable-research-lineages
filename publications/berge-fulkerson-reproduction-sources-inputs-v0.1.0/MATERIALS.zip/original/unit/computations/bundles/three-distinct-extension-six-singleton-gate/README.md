# Three-distinct-extension six-singleton gate

This bundle verifies the finite classification in
[Note 074](../../../notes/074-three-distinct-extensions-require-four-witness-reuse-rows.md).
Starting from the four actual pivot rows of Note 070, it considers every
six-subset of the four anchor identities and three distinct class-3
extensions.  It enumerates every Case-XII-compatible singleton quadruple and
every inclusion-minimal family whose missing-pair graph has independence
number at most two.

Run on Omen with one process:

```bash
python3 verify.py
```

The final line is

```text
THREE_DISTINCT_EXTENSION_SIX_SET_GATE_CLASSIFIED
```

The promoted run on 2026-09-04 used the Python standard library, took below
one second, and had peak RSS below 12 MB.  Its output is frozen in
[`omen-run.json`](omen-run.json).
