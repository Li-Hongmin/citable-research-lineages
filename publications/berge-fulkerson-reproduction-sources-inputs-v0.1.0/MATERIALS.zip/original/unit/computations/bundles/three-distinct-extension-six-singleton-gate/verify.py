#!/usr/bin/env python3
"""Classify six-singleton gates for the three-distinct-extension pivot star.

The seven identities and four initial rows are those of Note 070.  For each
six-subset, this script adds only singleton quadruples whose boundary-class
multiset is a Case-XII S--S or S--T cell.  It enumerates all inclusion-minimal
sets of additional rows that make the missing-pair graph have alpha at most
two.  This is a finite combinatorial check and uses no SAT/ILP solver.
"""

from __future__ import annotations

import json
from itertools import combinations, combinations_with_replacement


IDENTITIES = ("a1", "a2", "a4", "a5", "x", "y", "z")
POSITION = {
    "a1": 1,
    "a2": 2,
    "a4": 4,
    "a5": 5,
    "x": 3,
    "y": 3,
    "z": 3,
}
POSITIONS = tuple(range(1, 6))
PAIR_STATES = tuple(combinations(POSITIONS, 2))
S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
T = frozenset(set(PAIR_STATES) - set(S))

# Row order and cells are read from the Note-070 frozen certificate.
INITIAL_ROWS = (
    ("C", frozenset(("a1", "a2", "a4", "a5")), ((1, 5), (2, 4))),
    ("A", frozenset(("a1", "a4", "a5", "x")), ((1, 3), (4, 5))),
    ("D", frozenset(("a2", "a4", "a5", "y")), ((2, 5), (3, 4))),
    ("E", frozenset(("a1", "a2", "a5", "z")), ((1, 2), (3, 5))),
)


def ordered(items):
    return tuple(sorted(items, key=IDENTITIES.index))


def cell_name(cell):
    return "(" + ",".join("".join(map(str, pair)) for pair in cell) + ")"


def case_xii_cells():
    cells = set()
    for first, second in combinations_with_replacement(PAIR_STATES, 2):
        if first in S and second in S or (first in S) != (second in S):
            cells.add(tuple(sorted((first, second))))
    assert len(cells) == 40
    return frozenset(cells)


CASE_XII_CELLS = case_xii_cells()


def allowed_cells(singleton_quadruple):
    """All Case-XII cells with this exact singleton boundary multiset."""
    quadruple = tuple(singleton_quadruple)
    cells = set()
    # The three unordered partitions of four labelled identities into pairs.
    for first_indices in combinations(range(4), 2):
        if 0 not in first_indices:
            continue
        second_indices = tuple(i for i in range(4) if i not in first_indices)
        first = tuple(sorted(POSITION[quadruple[i]] for i in first_indices))
        second = tuple(sorted(POSITION[quadruple[i]] for i in second_indices))
        if first[0] == first[1] or second[0] == second[1]:
            continue
        cell = tuple(sorted((first, second)))
        if cell in CASE_XII_CELLS:
            cells.add(cell)
    return tuple(sorted(cells))


def alpha_at_most_two(vertices, edges):
    edge_set = {frozenset(edge) for edge in edges}
    return not any(
        all(frozenset(pair) not in edge_set for pair in combinations(triple, 2))
        for triple in combinations(vertices, 3)
    )


def row_record(edge, quadruple, cells):
    return {
        "missing_pair": ordered(edge),
        "singleton_quadruple": ordered(quadruple),
        "allowed_cells": tuple(cell_name(cell) for cell in cells),
    }


def classify_six_set(omitted):
    vertices = tuple(identity for identity in IDENTITIES if identity != omitted)
    vertex_set = frozenset(vertices)
    initial = tuple(
        (name, quadruple, cell) for name, quadruple, cell in INITIAL_ROWS
        if quadruple <= vertex_set
    )
    initial_edges = frozenset(vertex_set - quadruple for _, quadruple, _ in initial)

    candidates = []
    invalid = []
    for quadruple_tuple in combinations(vertices, 4):
        quadruple = frozenset(quadruple_tuple)
        cells = allowed_cells(quadruple_tuple)
        if not cells:
            invalid.append(ordered(quadruple))
            continue
        missing_pair = vertex_set - quadruple
        if missing_pair in initial_edges:
            continue
        candidates.append((missing_pair, quadruple, cells))

    minimal = []
    for mask in range(1 << len(candidates)):
        chosen = tuple(
            candidates[index] for index in range(len(candidates))
            if mask & (1 << index)
        )
        edges = set(initial_edges) | {row[0] for row in chosen}
        if not alpha_at_most_two(vertices, edges):
            continue
        # Monotonicity makes one-edge deletion sufficient for inclusion
        # minimality.
        if all(
            not alpha_at_most_two(
                vertices,
                set(initial_edges) | {
                    row[0] for index, row in enumerate(chosen) if index != deleted
                },
            )
            for deleted in range(len(chosen))
        ):
            minimal.append(chosen)

    minimum = min(map(len, minimal), default=None)
    optimum = tuple(solution for solution in minimal if len(solution) == minimum)
    size_distribution = {
        size: sum(len(solution) == size for solution in minimal)
        for size in sorted(set(map(len, minimal)))
    }
    return {
        "omitted": omitted,
        "six_set": vertices,
        "initial_rows": tuple({
            "name": name,
            "singleton_quadruple": ordered(quadruple),
            "cell": cell_name(tuple(sorted(cell))),
            "missing_pair": ordered(vertex_set - quadruple),
        } for name, quadruple, cell in initial),
        "initial_missing_edges": tuple(sorted(
            (ordered(edge) for edge in initial_edges), key=str
        )),
        "valid_additional_quadruples": len(candidates),
        "boundary_forbidden_quadruples": tuple(invalid),
        "inclusion_minimal_size_distribution": size_distribution,
        "minimum_additional_rows": minimum,
        "minimum_solutions": tuple(
            tuple(row_record(*row) for row in solution) for solution in optimum
        ),
    }


def main():
    records = tuple(classify_six_set(omitted) for omitted in IDENTITIES)
    feasible = tuple(
        record for record in records if record["minimum_additional_rows"] is not None
    )
    global_minimum = min(record["minimum_additional_rows"] for record in feasible)
    optimal_records = tuple(
        record for record in feasible
        if record["minimum_additional_rows"] == global_minimum
    )

    # The four anchor omissions retain x,y,z.  No allowed singleton row can
    # contain all three class-3 identities, so their triple can never be
    # covered.  Omitting an extension leaves exactly two class-3 identities
    # and is feasible, with the asserted complete optimum counts.
    assert tuple(record["omitted"] for record in feasible) == ("x", "y", "z")
    assert global_minimum == 4
    assert tuple(len(record["minimum_solutions"]) for record in optimal_records) == (3, 2, 3)

    output = {
        "identities": IDENTITIES,
        "initial_row_count": len(INITIAL_ROWS),
        "case_xii_cells": len(CASE_XII_CELLS),
        "six_subsets": records,
        "global_minimum_additional_rows": global_minimum,
        "globally_optimal_omissions": tuple(record["omitted"] for record in optimal_records),
        "globally_optimal_six_sets": tuple(record["six_set"] for record in optimal_records),
        "global_minimum_solution_count": sum(
            len(record["minimum_solutions"]) for record in optimal_records
        ),
    }
    print(json.dumps(output, indent=2, sort_keys=False))
    print("THREE_DISTINCT_EXTENSION_SIX_SET_GATE_CLASSIFIED")


if __name__ == "__main__":
    main()

