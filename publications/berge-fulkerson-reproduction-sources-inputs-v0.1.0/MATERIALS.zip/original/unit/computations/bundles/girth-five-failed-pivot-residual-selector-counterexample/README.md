# Girth-five failed-pivot residual-selector counterexample

Run from the AIMath root:

```text
python3 units/berge-fulkerson/computations/bundles/girth-five-failed-pivot-residual-selector-counterexample/verify_girth5_voltage_lift_counterexample.py
```

The verifier uses only the Python standard library.  It imports the frozen
order-thirteen data from the Note-070 bundle, constructs the explicit
three-layer \(\mathbb Z_3\)-voltage lift, and checks simplicity, connectedness,
cubic degrees, absence of proper bridges, girth exactly five, all fifteen
designated actual perfect matchings, the four exact \(D_5\) double covers,
the distinct pivot extensions \(2,12,10\), and all \(79\) blocked
forbidden-boundary selectors.  Its final marker is

```text
GIRTH5_VOLTAGE_LIFT_COUNTEREXAMPLE_VERIFIED
```

Transitive source dependency:

```text
units/berge-fulkerson/computations/bundles/failed-pivot-residual-selector-counterexample/verify_failed_pivot_residual_avoiding_pole.py
```

Reference run: Python 3.10.12 on Omen, 2026-09-04; wall time 0.30 seconds,
maximum RSS 10,752 KB, one process with a 1 GiB virtual-memory limit.  The
captured output is in `omen-output.txt`.
