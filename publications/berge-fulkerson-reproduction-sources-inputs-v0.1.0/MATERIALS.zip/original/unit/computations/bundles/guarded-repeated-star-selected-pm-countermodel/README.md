# Guarded repeated-star selected-PM countermodel

This bundle verifies the order-19 construction in
[Note 081](../../../notes/081-selected-perfect-matching-negative-support-does-not-force-nonoverload.md).
It checks the common cubic 5-pole, fourteen designated actual perfect
matchings, four literal BF rows, three overloaded targets, all seven required
shared-edge pairs, the full six-multiset support inside the designated family,
and the support profile after enumerating the complete perfect-matching family.

Run on Omen with one process:

```bash
python3 verify.py
```

The final marker is
`GUARDED_REPEATED_STAR_INCIDENCE_MODEL_VERIFIED`.
The verifier uses only the Python standard library.  The promoted Omen run on
2026-09-05 used Python 3.10.12, took 0.77 seconds, and had peak RSS 10,496 KB.
Its source SHA-256 was
`ef8d7958112ea6807f32046327ffe57519e0bb8e586e4e99b874a5df68f5aba1`.
