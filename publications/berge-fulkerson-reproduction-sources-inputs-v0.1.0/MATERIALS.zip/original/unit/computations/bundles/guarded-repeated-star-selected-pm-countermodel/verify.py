#!/usr/bin/env python3
"""Verify the twice-guarded selected-PM countermodel of Note 081.

The universe consists of fourteen designated perfect-matching vectors of one
simple connected cubic 5-pole.  BF rows are quantified over this designated
universe, with repetitions allowed.  The script deliberately does not claim
that the universe is the complete perfect-matching family of the pole.
"""

from collections import Counter
from itertools import combinations, combinations_with_replacement, product


N = 19
TERMINALS = frozenset(range(5))

BASE_PROPER = (
    (0, 8), (0, 10), (1, 5), (1, 8), (2, 7), (2, 9), (3, 8),
    (3, 9), (4, 6), (4, 7), (5, 6), (5, 10), (6, 9), (7, 10),
)

BASE_BOUNDARY = {
    "A": (0,), "B": (1,), "C": (3,), "D": (4,), "X": (2,), "Y": (2,),
    "q13": (1, 3, 4), "r45": (0, 1, 2),
    "q14": (1, 2, 4), "r23": (0, 3, 4),
    "q24": (0, 2, 4), "r15": (1, 2, 3),
    "q25": (0, 2, 3), "r34": (0, 1, 4),
}

BASE_MATCHINGS = {
    "A": ((1, 8), (2, 7), (3, 9), (4, 6), (5, 10)),
    "B": ((0, 10), (2, 9), (3, 8), (4, 7), (5, 6)),
    "C": ((0, 8), (1, 5), (2, 9), (4, 6), (7, 10)),
    "D": ((0, 10), (1, 8), (2, 7), (3, 9), (5, 6)),
    "X": ((0, 10), (1, 5), (3, 8), (4, 7), (6, 9)),
    "Y": ((0, 8), (1, 5), (3, 9), (4, 6), (7, 10)),
    "q13": ((0, 8), (2, 9), (5, 6), (7, 10)),
    "r45": ((3, 8), (4, 7), (5, 10), (6, 9)),
    "q14": ((0, 8), (3, 9), (5, 6), (7, 10)),
    "r23": ((1, 8), (2, 7), (5, 10), (6, 9)),
    "q24": ((1, 5), (3, 8), (6, 9), (7, 10)),
    "r15": ((0, 8), (4, 7), (5, 10), (6, 9)),
    "q25": ((1, 8), (4, 7), (5, 10), (6, 9)),
    "r34": ((2, 7), (3, 8), (5, 10), (6, 9)),
}

ROWS = (
    ("q13", "r45", "A", "X", "C", "D"),
    ("q14", "r23", "A", "B", "X", "C"),
    ("q24", "r15", "A", "B", "C", "D"),
    ("q25", "r34", "B", "Y", "C", "D"),
)

TARGETS = (
    (("B", "D", "X", "Y"), (0, 10), frozenset(("B", "D", "X"))),
    (("A", "C", "X", "Y"), (1, 5), frozenset(("C", "X", "Y"))),
    (("A", "B", "D", "Y"), (3, 9), frozenset(("A", "D", "Y"))),
)

# Three perfect matchings of K4.  Its colour-0 edge (11,12) is 2-summed
# with the base edge (4,6), whose designated-identity signature is {A,C,Y}.
G0_COLOUR = {
    "A": 0, "C": 0, "Y": 0,
    "B": 1, "D": 1, "r23": 1, "r45": 1,
    "X": 2, "q13": 2, "q14": 2, "q24": 2,
    "q25": 2, "r15": 2, "r34": 2,
}

# A second legal K4 partition.  Together with the old pole and G0 it makes
# every singleton-identity pair whose boundary pair lies in T share an edge.
# Its colour-2 edge is 2-summed with the current edge (6,9), which has exactly
# this colour-2 signature.
G1_COLOUR = {
    "A": 0, "B": 0, "Y": 0, "q13": 0,
    "C": 1, "D": 1, "q14": 1,
    "X": 2, "r45": 2, "r23": 2, "q24": 2,
    "r15": 2, "q25": 2, "r34": 2,
}

REMOVED_BASE_EDGE = (4, 6)
REMOVED_G0_EDGE = (6, 9)
PROPER = tuple(
    edge for edge in BASE_PROPER
    if edge not in (REMOVED_BASE_EDGE, REMOVED_G0_EDGE)
) + (
    (4, 11), (6, 12), (13, 14),
    (11, 13), (12, 14),
    (11, 14), (12, 13),
    (6, 15), (9, 16), (17, 18),
    (15, 17), (16, 18),
    (15, 18), (16, 17),
)

S_STATES = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))


def base_objects(name):
    return set(BASE_MATCHINGS[name]) | {f"s{v}" for v in BASE_BOUNDARY[name]}


def g0_objects(name):
    objects = base_objects(name) - {REMOVED_BASE_EDGE}
    colour = G0_COLOUR[name]
    if colour == 0:
        objects |= {(4, 11), (6, 12), (13, 14)}
    elif colour == 1:
        objects |= {(11, 13), (12, 14)}
    else:
        objects |= {(11, 14), (12, 13)}
    return frozenset(objects)


def guarded_objects(name):
    objects = set(g0_objects(name)) - {REMOVED_G0_EDGE}
    colour = G1_COLOUR[name]
    if colour == 2:
        objects |= {(6, 15), (9, 16), (17, 18)}
    elif colour == 0:
        objects |= {(15, 17), (16, 18)}
    else:
        objects |= {(15, 18), (16, 17)}
    return frozenset(objects)


def is_double_cover(row, vectors, objects):
    loads = Counter(edge for name in row for edge in vectors[name])
    return all(loads[edge] == 2 for edge in objects)


def state_of_triple(name):
    boundary = {v + 1 for v in BASE_BOUNDARY[name]}
    return tuple(sorted(set(range(1, 6)) - boundary))


def classified_rows(vectors, objects):
    output = []
    for row in combinations_with_replacement(vectors, 6):
        if not is_double_cover(row, vectors, objects):
            continue
        triples = tuple(name for name in row if len(BASE_BOUNDARY[name]) == 3)
        singles = tuple(name for name in row if len(BASE_BOUNDARY[name]) == 1)
        # Semiedge load two forces exactly two triple and four singleton rows.
        assert len(triples) == 2 and len(singles) == 4
        states = tuple(sorted(state_of_triple(name) for name in triples))
        if states[0] in S_STATES and states[1] in S_STATES:
            kind = "SS"
        elif states[0] not in S_STATES and states[1] not in S_STATES:
            kind = "TT"
        else:
            kind = "ST"
        output.append((kind, states, row))
    return tuple(output)


def connected():
    adjacency = {v: [] for v in range(N)}
    for u, v in PROPER:
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    stack = [0]
    while stack:
        for neighbour in adjacency[stack.pop()]:
            if neighbour not in seen:
                seen.add(neighbour)
                stack.append(neighbour)
    return len(seen) == N


def enumerate_all_perfect_matchings():
    adjacency = {v: [] for v in range(N)}
    for edge in PROPER:
        u, v = edge
        adjacency[u].append((v, edge))
        adjacency[v].append((u, edge))
    used = [False] * N
    chosen = []
    output = set()

    def rec():
        try:
            vertex = next(v for v in range(N) if not used[v])
        except StopIteration:
            output.add(frozenset(chosen))
            return
        used[vertex] = True
        if vertex in TERMINALS:
            chosen.append(f"s{vertex}")
            rec()
            chosen.pop()
        for neighbour, edge in adjacency[vertex]:
            if used[neighbour]:
                continue
            used[neighbour] = True
            chosen.append(edge)
            rec()
            chosen.pop()
            used[neighbour] = False
        used[vertex] = False

    rec()
    return tuple(output)


def complete_family_support_profile(all_objects):
    family = enumerate_all_perfect_matchings()
    classes = {}
    for matching in family:
        boundary = tuple(
            index + 1 for index in range(5) if f"s{index}" in matching
        )
        classes.setdefault(boundary, []).append(matching)

    states = tuple(combinations(range(1, 6), 2))
    complement = lambda pair: tuple(sorted(set(range(1, 6)) - set(pair)))
    profile = Counter()
    for first, second in combinations_with_replacement(states, 2):
        rows = product(
            classes.get(complement(first), ()),
            classes.get(complement(second), ()),
            *(classes.get((terminal,), ()) for terminal in first + second),
        )
        if any(
            all(sum(edge in matching for matching in row) == 2 for edge in all_objects)
            for row in rows
        ):
            if first in S_STATES and second in S_STATES:
                profile["SS"] += 1
            elif first not in S_STATES and second not in S_STATES:
                profile["TT"] += 1
            else:
                profile["ST"] += 1
    return family, profile


def main():
    identities = tuple(BASE_BOUNDARY)
    assert set(G0_COLOUR) == set(G1_COLOUR) == set(identities)
    assert len(PROPER) == len(set(PROPER)) == (3 * N - 5) // 2
    degrees = Counter(v for edge in PROPER for v in edge)
    assert all(degrees[v] == (2 if v in TERMINALS else 3) for v in range(N))
    assert connected()

    all_objects = frozenset(PROPER) | {f"s{v}" for v in TERMINALS}
    vectors = {name: guarded_objects(name) for name in identities}
    assert len(set(vectors.values())) == len(vectors)

    # Every designated identity is an actual perfect matching of the common
    # simple connected cubic 5-pole.
    for vector in vectors.values():
        assert vector <= all_objects
        for vertex in range(N):
            count = sum(
                vertex in edge for edge in vector if isinstance(edge, tuple)
            ) + int(f"s{vertex}" in vector)
            assert count == 1

    # Every pivot row remains a literal double cover after the 2-sum.
    assert all(is_double_cover(row, vectors, all_objects) for row in ROWS)

    # The three prescribed target quadruples retain their three-hit witnesses.
    for target, edge, expected_signature in TARGETS:
        signature = frozenset(name for name in "ABCDXY" if edge in vectors[name])
        assert signature == expected_signature
        assert sum(edge in vectors[name] for name in target) == 3

    # Before G0 there are exactly three forbidden TT rows in the designated
    # universe.  G0 is balanced 2+2+2 on every pivot row and unbalanced on
    # all three forbidden rows.
    base_all_objects = frozenset(BASE_PROPER) | {f"s{v}" for v in TERMINALS}
    base_vectors = {name: frozenset(base_objects(name)) for name in identities}
    base_rows = classified_rows(base_vectors, base_all_objects)
    base_tt = tuple(row for row in base_rows if row[0] == "TT")
    assert len(base_rows) == 9 and len(base_tt) == 3
    assert all(
        sorted(Counter(G0_COLOUR[name] for name in row).values()) != [2, 2, 2]
        for _, _, row in base_tt
    )
    assert all(
        sorted(Counter(G0_COLOUR[name] for name in row).values()) == [2, 2, 2]
        for row in ROWS
    )

    # G1 is also balanced on all pivot rows.  Its colour-2 class is exactly
    # the designated signature of the G0 edge (6,9), so the second 2-sum
    # preserves every designated perfect matching.
    g0_proper = (frozenset(BASE_PROPER) - {REMOVED_BASE_EDGE}) | {
        (4, 11), (6, 12), (13, 14),
        (11, 13), (12, 14), (11, 14), (12, 13),
    }
    g0_all_objects = g0_proper | {f"s{v}" for v in TERMINALS}
    g0_vectors = {name: g0_objects(name) for name in identities}
    assert frozenset(
        name for name in identities if REMOVED_G0_EDGE in g0_vectors[name]
    ) == frozenset(name for name in identities if G1_COLOUR[name] == 2)
    assert all(
        sorted(Counter(G1_COLOUR[name] for name in row).values()) == [2, 2, 2]
        for row in ROWS
    )
    g0_rows = classified_rows(g0_vectors, g0_all_objects)
    assert len(g0_rows) == 5
    assert {kind for kind, _, _ in g0_rows} == {"ST"}

    # The strengthened no-T-loop necessary condition: every pair of selected
    # singleton identities whose boundary labels form a T-state shares at
    # least one actual edge in the common incidence graph.
    required_shared_pairs = {
        frozenset(pair) for pair in (
            ("A", "B"), ("A", "D"), ("B", "X"), ("B", "Y"),
            ("C", "X"), ("C", "Y"), ("C", "D"),
        )
    }
    shared_edge_witnesses = {
        pair: min(set.intersection(*(set(vectors[name]) for name in pair)), key=str)
        for pair in required_shared_pairs
    }
    assert set(shared_edge_witnesses) == required_shared_pairs

    # Exhaust all six-multisets over the designated identity universe.
    # Exactly the four pivot ST rows survive; no T-loop or off-diagonal TT
    # cover does.
    surviving = classified_rows(vectors, all_objects)
    assert len(surviving) == 4
    assert {kind for kind, _, _ in surviving} == {"ST"}
    assert {frozenset(row) for row in ROWS} <= {
        frozenset(row) for _, _, row in surviving
    }

    # The designated universe is not PM-closed.  Quantifying over every
    # perfect matching of the same pole restores forbidden TT support.
    complete_family, complete_profile = complete_family_support_profile(all_objects)
    assert len(complete_family) == 66
    assert complete_profile == Counter({"ST": 17, "TT": 15, "SS": 7})

    print({
        "order": N,
        "designated_actual_perfect_matchings": len(vectors),
        "pivot_rows": len(ROWS),
        "overloaded_targets": len(TARGETS),
        "base_designated_support": Counter(kind for kind, _, _ in base_rows),
        "guarded_designated_support": Counter(kind for kind, _, _ in surviving),
        "complete_pm_family_size": len(complete_family),
        "complete_pm_support": complete_profile,
        "shared_T_pair_witnesses": {
            "".join(sorted(pair)): edge
            for pair, edge in sorted(shared_edge_witnesses.items(), key=lambda item: sorted(item[0]))
        },
        "guard_partitions": {
            guard: {
                colour: tuple(name for name in identities if colouring[name] == colour)
                for colour in range(3)
            }
            for guard, colouring in (("G0", G0_COLOUR), ("G1", G1_COLOUR))
        },
    })
    print("GUARDED_REPEATED_STAR_INCIDENCE_MODEL_VERIFIED")


if __name__ == "__main__":
    main()
