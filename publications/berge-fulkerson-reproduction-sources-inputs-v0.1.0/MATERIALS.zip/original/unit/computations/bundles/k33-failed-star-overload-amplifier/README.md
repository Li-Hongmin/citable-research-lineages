# \(K_{3,3}\) failed-star overload amplifier

This bundle verifies the finite \(S_3\) classifications used in
[Note 079](../../../notes/079-k33-two-sums-destroy-failed-star-nonoverload-gates.md).
It reuses the permanent enumerators underlying Notes 074 and 077.

For the repeated-extension star it checks all eight possible triple-hit
sets and supplies two gadget assignments whose target-badness vectors have
Boolean OR \(111\).  For the three-distinct-extension star it checks all 29
possible overload hit sets and supplies one assignment that blocks every
one of the eight optimal four-row gates.

Run on Omen with one process:

```bash
python3 verify.py
```

The final line is

```text
K33_FAILED_STAR_OVERLOAD_AMPLIFIERS_VERIFIED
```

The script uses only the Python standard library.  The promoted Omen run on
2026-09-05 used Python 3.10.12, took 0.83 seconds, and had peak RSS 12,544
KB; its output is frozen in [`omen-run.log`](omen-run.log).
