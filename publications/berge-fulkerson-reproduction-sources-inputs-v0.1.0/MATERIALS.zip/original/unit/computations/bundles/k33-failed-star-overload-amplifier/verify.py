#!/usr/bin/env python3
"""Verify support-preserving K3,3 overload amplifiers for failed stars."""

from itertools import combinations, product
from pathlib import Path
from runpy import run_path


ROOT = Path(__file__).resolve().parents[3]
REPEATED_BASE = run_path(
    ROOT / "computations/bundles/k33-four-matching-completion-repeated-star/verify.py"
)
DISTINCT_BASE = run_path(
    ROOT / "computations/bundles/three-distinct-extension-six-singleton-gate/verify.py"
)
PERMS = REPEATED_BASE["PERMS"]
PIVOTS = REPEATED_BASE["PIVOTS"]
TARGETS = REPEATED_BASE["TARGETS"]
completable = REPEATED_BASE["completable"]

NAMES = "ABCDXY"
ALLOWED_TRIPLE_HITS = (
    "ABY", "ACY", "ADY", "BDX", "AXY", "BXY", "CXY", "DXY",
)


def hit_signature(values, names=NAMES):
    return "".join(
        names[index]
        for index, value in enumerate(values)
        if PERMS[value][0] == 0
    )


def badness(values):
    return tuple(not completable(values, target) for target in TARGETS)


def format_values(values):
    return tuple("".join(map(str, PERMS[value])) for value in values)


def repeated_extension_witnesses():
    by_hit = {hit: {} for hit in ALLOWED_TRIPLE_HITS}
    for values in product(range(len(PERMS)), repeat=len(NAMES)):
        hit = hit_signature(values)
        if hit not in by_hit:
            continue
        if not all(completable(values, pivot) for pivot in PIVOTS):
            continue
        by_hit[hit].setdefault(badness(values), values)

    witnesses = {}
    for hit, representatives in by_hit.items():
        assert (True, True, True) not in representatives
        first, second = next(
            (first, second)
            for first in representatives
            for second in representatives
            if all(a or b for a, b in zip(first, second, strict=True))
        )
        witnesses[hit] = tuple(
            {
                "badness": "".join(str(int(bit)) for bit in pattern),
                "permutations": format_values(representatives[pattern]),
            }
            for pattern in (first, second)
        )
    assert set(witnesses) == set(ALLOWED_TRIPLE_HITS)
    return witnesses


def distinct_extension_witnesses():
    names = "ABCDXYZ"
    identity_to_letter = dict(
        zip(DISTINCT_BASE["IDENTITIES"], names, strict=True)
    )
    name_to_index = {name: index for index, name in enumerate(names)}
    pivots = tuple(
        tuple(name_to_index[identity_to_letter[identity]] for identity in row[1])
        for row in DISTINCT_BASE["INITIAL_ROWS"]
    )

    gates = []
    for omitted in ("x", "y", "z"):
        record = DISTINCT_BASE["classify_six_set"](omitted)
        assert record["minimum_additional_rows"] == 4
        for solution in record["minimum_solutions"]:
            gates.append(
                tuple(
                    tuple(
                        name_to_index[identity_to_letter[identity]]
                        for identity in row["singleton_quadruple"]
                    )
                    for row in solution
                )
            )
    assert len(gates) == 8

    possible_hits = {
        "".join(names[index] for index in hit)
        for size in range(3, len(names) + 1)
        for hit in combinations(range(len(names)), size)
        if all(len(set(hit) & set(pivot)) <= 2 for pivot in pivots)
    }
    witnesses = {}
    for values in product(range(len(PERMS)), repeat=len(names)):
        hit = hit_signature(values, names)
        if hit not in possible_hits or hit in witnesses:
            continue
        if not all(completable(values, pivot) for pivot in pivots):
            continue
        blocked = tuple(
            any(not completable(values, quadruple) for quadruple in gate)
            for gate in gates
        )
        if all(blocked):
            witnesses[hit] = format_values(values)

    assert len(possible_hits) == 29
    assert set(witnesses) == possible_hits
    return witnesses


def main():
    repeated = repeated_extension_witnesses()
    distinct = distinct_extension_witnesses()
    print({
        "repeated_allowed_hits": len(repeated),
        "repeated_factors_required": 2,
        "repeated_witnesses": repeated,
        "distinct_possible_overload_hits": len(distinct),
        "distinct_factors_required": 1,
        "distinct_all_eight_gates_blocked": True,
    })
    print("K33_FAILED_STAR_OVERLOAD_AMPLIFIERS_VERIFIED")


if __name__ == "__main__":
    main()
