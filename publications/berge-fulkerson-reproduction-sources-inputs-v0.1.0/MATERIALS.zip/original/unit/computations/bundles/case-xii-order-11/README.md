# Case XII at eleven internal vertices

This bundle verifies the following finite statement: every simple connected cubic 5-pole with eleven internal vertices, five distinct boundary vertices, and Tait lonely-pair state set exactly

\[
S=\{13,14,24,25,35\}
\]

has a compatible pentagon of singleton-boundary perfect matchings and hence a Berge–Fulkerson colouring of boundary type `(12345)`.

## Reproduction

Requirements used for the retained run:

- Python 3.13.15;
- NetworkX 3.6.1;
- nauty `geng` 2.9.3.

From this directory run:

```sh
uv run --with networkx python case_xii_n11_geng_audit.py \
  --json case_xii_n11_geng_results.json

uv run --with networkx python case_xii_n11_geng_audit.py \
  --all-labelings \
  --json case_xii_n11_geng_all120_results.json
```

The first command tests twelve representatives modulo `Aut(S)=D_5`; the second tests all 120 boundary labelings. The program imports `case_xii_pentagon_audit.py` from the same directory.

## Coverage

Adding an apex adjacent to the five boundary vertices is a bijection between the stated unlabelled 5-pole skeletons and simple twelve-vertex graphs with degree sequence `(5,3^11)`, unique degree-five vertex `z`, and connected deletion `G-z`. The command

```sh
geng -q -c -d3 -D5 12 19
```

generates all connected simple twelve-vertex, nineteen-edge graphs with degrees between three and five. Filtering gives 581 exact degree-sequence graphs and 536 with connected apex deletion.

The quotient run checks 6,432 boundary-label orbits and retains 41 Case-XII branches; all 41 pass. The unquotiented run checks 64,320 labelings and retains 410 branches; all 410 pass. The tenfold ratio independently checks the `D_5` quotient used by the smaller run.

This bundle does not cover repeated boundary vertices, multigraphs, loops, or disconnected proper graphs.

