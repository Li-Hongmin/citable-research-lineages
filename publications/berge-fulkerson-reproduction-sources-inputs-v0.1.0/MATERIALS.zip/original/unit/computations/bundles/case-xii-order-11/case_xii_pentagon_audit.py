#!/usr/bin/env python3
"""Exact small-order audit for the 3-edge-colourable Case XII 5-pole.

We fix five labelled semiedges e_1,...,e_5 at five distinct boundary
vertices 0,...,4.  Up to a permutation of the three Tait colours, a Case-XII
Tait colouring may be normalised so that

    colour 0 is on e_1,
    colour 1 is on e_4,
    colour 2 is on e_2,e_3,e_5.

For n=5,7,9 internal vertices, the program exhaustively enumerates all triples
of colour-class matchings with this boundary pattern, rejects non-simple or
disconnected proper graphs, and deduplicates equal labelled proper-edge sets.
For every resulting pole it enumerates all 3-edge-colourings.  A necessary
Case-XII condition is that the set of lonely boundary pairs be exactly

    S = {13,14,24,25,35}.

For every pole satisfying this condition, the program enumerates all perfect
matchings with singleton boundary and searches for a compatible pentagon

    P_1 -- P_4 -- P_2 -- P_5 -- P_3 -- P_1,

where adjacent matchings are edge-disjoint.  From such a pentagon it constructs
P_0 as the edges occurring exactly once among P_1,...,P_5, and verifies that
P_0,P_1,...,P_5 form a Berge--Fulkerson cover of boundary type (12345).

No external packages are required.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import sys
import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, FrozenSet, Iterable, Iterator, List, Optional, Sequence, Set, Tuple

Vertex = int
Position = int
ProperEdge = Tuple[Vertex, Vertex]
EdgeId = str
Matching = FrozenSet[EdgeId]

BOUNDARY_VERTEX: Dict[Position, Vertex] = {1: 0, 2: 1, 3: 2, 4: 3, 5: 4}
VERTEX_POSITION: Dict[Vertex, Position] = {v: p for p, v in BOUNDARY_VERTEX.items()}

# A fixed Tait boundary state [14].
BOUNDARY_COLOUR: Dict[Position, int] = {1: 0, 4: 1, 2: 2, 3: 2, 5: 2}
COLOUR_BOUNDARY_VERTICES: Dict[int, FrozenSet[Vertex]] = {
    c: frozenset(BOUNDARY_VERTEX[p] for p, cc in BOUNDARY_COLOUR.items() if cc == c)
    for c in range(3)
}

# The five diagonal pairs, in cyclic order 1-4-2-5-3-1.
S_DIAGONALS: FrozenSet[Tuple[int, int]] = frozenset(
    tuple(sorted(x)) for x in ((1, 3), (1, 4), (2, 4), (2, 5), (3, 5))
)
PENTAGON_ORDER: Tuple[int, ...] = (1, 4, 2, 5, 3)


@dataclass(frozen=True)
class Pole:
    n: int
    proper_edges: Tuple[ProperEdge, ...]

    def edge_data(self) -> Tuple[Tuple[EdgeId, Tuple[Vertex, ...], Optional[Position]], ...]:
        data: List[Tuple[EdgeId, Tuple[Vertex, ...], Optional[Position]]] = []
        for i, (u, v) in enumerate(self.proper_edges):
            data.append((f"e{i}", (u, v), None))
        for p in range(1, 6):
            data.append((f"s{p}", (BOUNDARY_VERTEX[p],), p))
        return tuple(data)


def canonical_edge(u: Vertex, v: Vertex) -> ProperEdge:
    return (u, v) if u < v else (v, u)


def perfect_pairings(vertices: Sequence[Vertex]) -> Tuple[Tuple[ProperEdge, ...], ...]:
    """All perfect matchings of the complete graph on the supplied vertices."""
    vertices = tuple(sorted(vertices))
    if not vertices:
        return (tuple(),)
    first = vertices[0]
    out: List[Tuple[ProperEdge, ...]] = []
    for i in range(1, len(vertices)):
        second = vertices[i]
        rest = vertices[1:i] + vertices[i + 1 :]
        for tail in perfect_pairings(rest):
            out.append(tuple(sorted((canonical_edge(first, second),) + tail)))
    return tuple(out)


def connected(n: int, edges: Sequence[ProperEdge]) -> bool:
    adj: List[List[int]] = [[] for _ in range(n)]
    for u, v in edges:
        adj[u].append(v)
        adj[v].append(u)
    seen = {0}
    stack = [0]
    while stack:
        u = stack.pop()
        for v in adj[u]:
            if v not in seen:
                seen.add(v)
                stack.append(v)
    return len(seen) == n


def generate_poles(n: int) -> Tuple[int, int, Tuple[Pole, ...]]:
    """Generate all labelled simple connected poles carrying the fixed Tait state."""
    vertices = tuple(range(n))
    colour_matchings: List[Tuple[Tuple[ProperEdge, ...], ...]] = []
    for colour in range(3):
        remaining = tuple(v for v in vertices if v not in COLOUR_BOUNDARY_VERTICES[colour])
        colour_matchings.append(perfect_pairings(remaining))

    raw = 1
    for family in colour_matchings:
        raw *= len(family)

    valid_coloured = 0
    edge_sets: Set[Tuple[ProperEdge, ...]] = set()
    expected_edge_count = (3 * n - 5) // 2

    for m0 in colour_matchings[0]:
        s0 = set(m0)
        for m1 in colour_matchings[1]:
            s01 = s0 | set(m1)
            if len(s01) != len(m0) + len(m1):
                continue  # repeated proper edge in two colour classes
            for m2 in colour_matchings[2]:
                all_edges = s01 | set(m2)
                if len(all_edges) != expected_edge_count:
                    continue
                edge_tuple = tuple(sorted(all_edges))
                if not connected(n, edge_tuple):
                    continue
                valid_coloured += 1
                edge_sets.add(edge_tuple)

    poles = tuple(Pole(n=n, proper_edges=e) for e in sorted(edge_sets))
    return raw, valid_coloured, poles


def incidence(pole: Pole):
    edge_data = pole.edge_data()
    info = {eid: (vertices, pos) for eid, vertices, pos in edge_data}
    inc: Dict[int, List[str]] = defaultdict(list)
    for eid, vertices, _ in edge_data:
        for v in vertices:
            inc[v].append(eid)
    for v in inc:
        inc[v].sort()
    return edge_data, info, inc


def enumerate_tait_states(pole: Pole) -> FrozenSet[Tuple[int, int]]:
    """Enumerate boundary lonely-pair states, modulo global colour permutation."""
    edge_data, info, inc = incidence(pole)
    eids = tuple(eid for eid, _, _ in edge_data)

    root = 0
    root_edges = tuple(inc[root])
    if len(root_edges) != 3:
        raise AssertionError("the pole is not cubic at the root")

    assignment: Dict[str, int] = {}
    used: Dict[int, Set[int]] = {v: set() for v in range(pole.n)}
    for colour, eid in enumerate(root_edges):
        assignment[eid] = colour
        for v in info[eid][0]:
            used[v].add(colour)

    states: Set[Tuple[int, int]] = set()

    def choose_edge() -> Tuple[Optional[str], Tuple[int, ...]]:
        best: Optional[str] = None
        best_domain: Tuple[int, ...] = tuple()
        for eid in eids:
            if eid in assignment:
                continue
            domain = set((0, 1, 2))
            for v in info[eid][0]:
                domain.difference_update(used[v])
            domain_tuple = tuple(sorted(domain))
            if best is None or len(domain_tuple) < len(best_domain):
                best = eid
                best_domain = domain_tuple
                if not domain_tuple:
                    break
        return best, best_domain

    def record_state() -> None:
        positions_by_colour: Dict[int, List[int]] = {0: [], 1: [], 2: []}
        for eid, _, pos in edge_data:
            if pos is not None:
                positions_by_colour[assignment[eid]].append(pos)
        lengths = sorted(len(x) for x in positions_by_colour.values())
        if lengths != [1, 1, 3]:
            raise AssertionError(f"invalid Tait boundary counts: {lengths}")
        lonely = sorted(x[0] for x in positions_by_colour.values() if len(x) == 1)
        states.add((lonely[0], lonely[1]))

    def dfs() -> None:
        eid, domain = choose_edge()
        if eid is None:
            record_state()
            return
        if not domain:
            return
        vertices = info[eid][0]
        for colour in domain:
            assignment[eid] = colour
            for v in vertices:
                used[v].add(colour)
            dfs()
            for v in vertices:
                used[v].remove(colour)
            del assignment[eid]

    dfs()
    return frozenset(states)


def enumerate_perfect_matchings(pole: Pole) -> Tuple[Tuple[Matching, ...], Dict[EdgeId, Tuple[Vertex, ...]], Dict[EdgeId, Optional[Position]], Dict[int, Tuple[EdgeId, ...]]]:
    edge_data, info, inc_lists = incidence(pole)
    vertices = frozenset(range(pole.n))
    matchings: Set[Matching] = set()

    def dfs(uncovered: FrozenSet[int], chosen: Tuple[str, ...]) -> None:
        if not uncovered:
            matchings.add(frozenset(chosen))
            return
        v = min(uncovered)
        for eid in inc_lists[v]:
            endpoints = frozenset(info[eid][0])
            if endpoints.issubset(uncovered):
                dfs(uncovered - endpoints, chosen + (eid,))

    dfs(vertices, tuple())
    edge_vertices = {eid: vertices for eid, vertices, _ in edge_data}
    edge_position = {eid: pos for eid, _, pos in edge_data}
    inc = {v: tuple(eids) for v, eids in inc_lists.items()}
    return tuple(sorted(matchings, key=lambda m: tuple(sorted(m)))), edge_vertices, edge_position, inc


def boundary_set(matching: Matching, edge_position: Dict[EdgeId, Optional[Position]]) -> FrozenSet[int]:
    return frozenset(edge_position[e] for e in matching if edge_position[e] is not None)


def find_pentagon_and_verify(pole: Pole):
    matchings, edge_vertices, edge_position, inc = enumerate_perfect_matchings(pole)
    singleton: Dict[int, List[Matching]] = {i: [] for i in range(1, 6)}
    for m in matchings:
        b = boundary_set(m, edge_position)
        if len(b) == 1:
            singleton[next(iter(b))].append(m)

    if any(not singleton[i] for i in range(1, 6)):
        return None

    order = PENTAGON_ORDER
    selected: Dict[int, Matching] = {}

    def disjoint(a: Matching, b: Matching) -> bool:
        return a.isdisjoint(b)

    def search(k: int) -> bool:
        if k == len(order):
            return disjoint(selected[order[-1]], selected[order[0]])
        pos = order[k]
        for m in singleton[pos]:
            if k > 0 and not disjoint(selected[order[k - 1]], m):
                continue
            selected[pos] = m
            if search(k + 1):
                return True
            del selected[pos]
        return False

    if not search(0):
        return None

    five = [selected[i] for i in range(1, 6)]
    multiplicity: Dict[str, int] = {eid: 0 for eid in edge_vertices}
    for m in five:
        for eid in m:
            multiplicity[eid] += 1

    if max(multiplicity.values()) > 2:
        raise AssertionError("pentagon disjointness failed to bound multiplicities")

    p0 = frozenset(eid for eid, value in multiplicity.items() if value == 1)

    # P0 is a perfect matching and contains all five semiedges.
    for v in range(pole.n):
        count = sum(eid in p0 for eid in inc[v])
        if count != 1:
            raise AssertionError(f"constructed P0 is not perfect at vertex {v}: {count}")
    if boundary_set(p0, edge_position) != frozenset(range(1, 6)):
        raise AssertionError("constructed P0 does not contain all semiedges")

    cover = {eid: int(eid in p0) + multiplicity[eid] for eid in edge_vertices}
    if set(cover.values()) != {2}:
        raise AssertionError("the six matchings do not cover each edge exactly twice")

    witness = {
        "proper_edges": [list(e) for e in pole.proper_edges],
        "P0": sorted(p0),
        **{f"P{i}": sorted(selected[i]) for i in range(1, 6)},
    }
    return witness


def run(max_n: int) -> dict:
    rows = []
    witnesses = {}
    total_start = time.perf_counter()
    for n in (5, 7, 9):
        if n > max_n:
            continue
        t0 = time.perf_counter()
        raw, valid_coloured, poles = generate_poles(n)
        candidates = 0
        pentagon_success = 0
        first_witness = None
        for pole in poles:
            states = enumerate_tait_states(pole)
            if states != S_DIAGONALS:
                continue
            candidates += 1
            witness = find_pentagon_and_verify(pole)
            if witness is not None:
                pentagon_success += 1
                if first_witness is None:
                    first_witness = witness
        elapsed = time.perf_counter() - t0
        row = {
            "n": n,
            "raw_colour_matching_triples": raw,
            "valid_connected_simple_coloured_triples": valid_coloured,
            "distinct_labelled_proper_edge_sets": len(poles),
            "case_xii_tait_state_candidates": candidates,
            "pentagon_and_A_cover_verified": pentagon_success,
            "elapsed_seconds": round(elapsed, 6),
        }
        rows.append(row)
        if first_witness is not None:
            witnesses[str(n)] = first_witness

    return {
        "normalised_boundary_colours": BOUNDARY_COLOUR,
        "case_xii_diagonal_states": [list(x) for x in sorted(S_DIAGONALS)],
        "pentagon_order": list(PENTAGON_ORDER),
        "rows": rows,
        "all_candidates_pass": all(
            row["case_xii_tait_state_candidates"] == row["pentagon_and_A_cover_verified"]
            for row in rows
        ),
        "total_elapsed_seconds": round(time.perf_counter() - total_start, 6),
        "first_witness_by_order": witnesses,
    }


def render(result: dict) -> str:
    lines = []
    lines.append("Case XII pentagonal perfect-matching audit")
    lines.append("normalised Tait boundary: e1=0, e4=1, e2=e3=e5=2")
    lines.append("required state set S={13,14,24,25,35}")
    lines.append("pentagon order: 1-4-2-5-3-1")
    lines.append("")
    header = (
        " n | raw triples | valid coloured | labelled edge sets | "
        "Case-XII candidates | pentagon/A verified"
    )
    lines.append(header)
    lines.append("-" * len(header))
    for row in result["rows"]:
        lines.append(
            f"{row['n']:2d} | {row['raw_colour_matching_triples']:11d} | "
            f"{row['valid_connected_simple_coloured_triples']:14d} | "
            f"{row['distinct_labelled_proper_edge_sets']:18d} | "
            f"{row['case_xii_tait_state_candidates']:19d} | "
            f"{row['pentagon_and_A_cover_verified']:20d}"
        )
    lines.append("")
    lines.append(f"ALL CANDIDATES PASS: {result['all_candidates_pass']}")
    lines.append(f"total elapsed seconds: {result['total_elapsed_seconds']}")
    lines.append("")
    lines.append("For each passing candidate, P0,P1,...,P5 were checked to be perfect")
    lines.append("matchings, every edge/semiedge was checked to occur exactly twice, and")
    lines.append("the boundary multiplicities were 5,1,1,1,1,1 (type (12345)).")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-n", type=int, default=9, choices=(5, 7, 9))
    parser.add_argument("--json", type=Path, default=None)
    args = parser.parse_args()

    result = run(args.max_n)
    text = render(result)
    sys.stdout.write(text)
    if args.json is not None:
        args.json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0 if result["all_candidates_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
