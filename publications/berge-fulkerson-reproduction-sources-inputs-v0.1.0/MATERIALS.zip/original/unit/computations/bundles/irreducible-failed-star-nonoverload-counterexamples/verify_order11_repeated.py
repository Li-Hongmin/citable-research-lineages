#!/usr/bin/env python3
"""Verify the order-11 repeated-star irreducible counterexample."""

from collections import Counter, deque


N = 11
TERMINALS = set(range(5))
PROPER = (
    (0, 8), (0, 10), (1, 5), (1, 8), (2, 7), (2, 9), (3, 8),
    (3, 9), (4, 6), (4, 7), (5, 6), (5, 10), (6, 9), (7, 10),
)
BOUNDARY = {
    "A": (0,), "B": (1,), "C": (3,), "D": (4,), "X": (2,), "Y": (2,),
    "q13": (1, 3, 4), "r45": (0, 1, 2),
    "q14": (1, 2, 4), "r23": (0, 3, 4),
    "q24": (0, 2, 4), "r15": (1, 2, 3),
    "q25": (0, 2, 3), "r34": (0, 1, 4),
}
MATCHINGS = {
    "A": ((1, 8), (2, 7), (3, 9), (4, 6), (5, 10)),
    "B": ((0, 10), (2, 9), (3, 8), (4, 7), (5, 6)),
    "C": ((0, 8), (1, 5), (2, 9), (4, 6), (7, 10)),
    "D": ((0, 10), (1, 8), (2, 7), (3, 9), (5, 6)),
    "X": ((0, 10), (1, 5), (3, 8), (4, 7), (6, 9)),
    "Y": ((0, 8), (1, 5), (3, 9), (4, 6), (7, 10)),
    "q13": ((0, 8), (2, 9), (5, 6), (7, 10)),
    "r45": ((3, 8), (4, 7), (5, 10), (6, 9)),
    "q14": ((0, 8), (3, 9), (5, 6), (7, 10)),
    "r23": ((1, 8), (2, 7), (5, 10), (6, 9)),
    "q24": ((1, 5), (3, 8), (6, 9), (7, 10)),
    "r15": ((0, 8), (4, 7), (5, 10), (6, 9)),
    "q25": ((1, 8), (4, 7), (5, 10), (6, 9)),
    "r34": ((2, 7), (3, 8), (5, 10), (6, 9)),
}
ROWS = (
    ("q13", "r45", "A", "X", "C", "D"),
    ("q14", "r23", "A", "B", "X", "C"),
    ("q24", "r15", "A", "B", "C", "D"),
    ("q25", "r34", "B", "Y", "C", "D"),
)
TARGETS = (
    ("B", "D", "X", "Y"),
    ("A", "C", "X", "Y"),
    ("A", "B", "D", "Y"),
)
EXPECTED_OVERLOADS = (
    ((0, 10), ("B", "D", "X")),
    ((1, 5), ("C", "X", "Y")),
    ((3, 9), ("A", "D", "Y")),
)


def objects(name):
    return set(MATCHINGS[name]) | {f"s{v}" for v in BOUNDARY[name]}


def connected_without(skip=None):
    adjacency = {v: [] for v in range(N)}
    for edge in PROPER:
        if edge == skip:
            continue
        u, v = edge
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    stack = [0]
    while stack:
        for neighbour in adjacency[stack.pop()]:
            if neighbour not in seen:
                seen.add(neighbour)
                stack.append(neighbour)
    return len(seen) == N


def graph_girth():
    adjacency = {v: [] for v in range(N)}
    for u, v in PROPER:
        adjacency[u].append(v)
        adjacency[v].append(u)
    best = N + 1
    for removed in PROPER:
        start, finish = removed
        queue = deque([(start, 0)])
        seen = {start}
        while queue:
            vertex, distance = queue.popleft()
            if vertex == finish:
                best = min(best, distance + 1)
                break
            for neighbour in adjacency[vertex]:
                if tuple(sorted((vertex, neighbour))) == removed or neighbour in seen:
                    continue
                seen.add(neighbour)
                queue.append((neighbour, distance + 1))
    return best


def two_cut_shores():
    shores = []
    for mask in range(1 << (N - 1)):
        if mask == (1 << (N - 1)) - 1:
            continue
        side = {0} | {i + 1 for i in range(N - 1) if mask & (1 << i)}
        cut = tuple(
            edge for edge in PROPER
            if (edge[0] in side) != (edge[1] in side)
        )
        if len(cut) == 2:
            other = set(range(N)) - side
            smaller = min((side, other), key=lambda value: (len(value), sorted(value)))
            shores.append(tuple(sorted(smaller)))
    return tuple(sorted(set(shores)))


def main():
    assert len(PROPER) == (3 * N - 5) // 2
    assert len(set(PROPER)) == len(PROPER)
    assert all(0 <= u < v < N for u, v in PROPER)
    degrees = Counter(v for edge in PROPER for v in edge)
    assert all(degrees[v] == (2 if v in TERMINALS else 3) for v in range(N))
    assert connected_without()
    assert not any(not connected_without(edge) for edge in PROPER)
    assert graph_girth() == 5
    assert two_cut_shores() == ((0,), (1,), (2,), (3,), (4,))

    all_objects = set(PROPER) | {f"s{v}" for v in TERMINALS}
    vectors = {name: objects(name) for name in BOUNDARY}
    assert len(set(map(frozenset, vectors.values()))) == len(vectors)
    for vector in vectors.values():
        assert vector <= all_objects
        for vertex in range(N):
            incidences = sum(
                vertex in edge for edge in vector if isinstance(edge, tuple)
            )
            incidences += int(f"s{vertex}" in vector)
            assert incidences == 1

    for row in ROWS:
        loads = Counter(edge for name in row for edge in vectors[name])
        assert set(loads) == all_objects
        assert set(loads.values()) == {2}

    singleton_vectors = {name: vectors[name] for name in "ABCDXY"}
    for target, expected in zip(TARGETS, EXPECTED_OVERLOADS, strict=True):
        edge, signature = expected
        assert tuple(
            name for name in "ABCDXY" if edge in singleton_vectors[name]
        ) == signature
        assert sum(edge in singleton_vectors[name] for name in target) == 3

    print({
        "order": N,
        "proper_edges": len(PROPER),
        "girth": graph_girth(),
        "bridges": (),
        "proper_two_cut_small_shores": two_cut_shores(),
        "distinct_actual_perfect_matchings": len(vectors),
        "literal_bf_rows": len(ROWS),
        "target_overloads": EXPECTED_OVERLOADS,
    })
    print("ORDER11_REPEATED_STAR_IRREDUCIBLE_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
