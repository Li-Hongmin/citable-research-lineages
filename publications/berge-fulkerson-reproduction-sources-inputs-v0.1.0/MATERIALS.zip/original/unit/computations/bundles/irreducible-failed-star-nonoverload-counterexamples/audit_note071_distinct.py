#!/usr/bin/env python3
"""Audit the Note-071 pole against the Note-019 cuts and Note-074 gates."""

import importlib.util
import json
from collections import Counter
from itertools import combinations, product
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
NOTE071 = (
    ROOT
    / "computations/bundles/girth-five-failed-pivot-residual-selector-counterexample"
    / "verify_girth5_voltage_lift_counterexample.py"
)
NOTE074 = (
    ROOT
    / "computations/bundles/three-distinct-extension-six-singleton-gate"
    / "omen-run.json"
)
IDENTITY_TO_PM = {
    "a1": 33, "a2": 16, "a4": 24, "a5": 0, "x": 2, "y": 12, "z": 10,
}
EXPECTED_CUTS = {
    frozenset(((0, 30), (0, 33))),
    frozenset(((3, 24), (3, 27))),
    frozenset(((6, 27), (6, 30))),
    frozenset(((9, 21), (9, 36))),
    frozenset(((12, 18), (12, 21))),
}


def load_module(path):
    spec = importlib.util.spec_from_file_location("note071_frozen", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_first_json(path):
    value, _ = json.JSONDecoder().raw_decode(path.read_text(encoding="utf-8"))
    return value


def components(vertices, edges, removed=frozenset()):
    adjacency = {vertex: [] for vertex in vertices}
    for edge in edges:
        if edge in removed:
            continue
        u, v = edge
        adjacency[u].append(v)
        adjacency[v].append(u)
    unseen = set(vertices)
    result = []
    while unseen:
        seed = unseen.pop()
        part = {seed}
        stack = [seed]
        while stack:
            for neighbour in adjacency[stack.pop()]:
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    part.add(neighbour)
                    stack.append(neighbour)
        result.append(frozenset(part))
    return tuple(result)


def concrete_gates(note074):
    gates = []
    for six_set in note074["six_subsets"]:
        if six_set["minimum_additional_rows"] != 4:
            continue
        for solution in six_set["minimum_solutions"]:
            for cells in product(*(row["allowed_cells"] for row in solution)):
                gates.append((
                    tuple(tuple(row["singleton_quadruple"]) for row in solution),
                    tuple(cells),
                ))
    assert len(gates) == 28
    return tuple(gates)


def main():
    note071 = load_module(NOTE071)
    note074 = read_first_json(NOTE074)
    vertices = frozenset(range(39))
    proper = tuple(note071.PROPER)
    terminals = frozenset(edge[0] for edge in note071.SEMIEDGES)

    bridges = tuple(
        edge for edge in proper
        if len(components(vertices, proper, frozenset((edge,)))) > 1
    )
    assert not bridges

    cut_parts = {}
    for cut in combinations(proper, 2):
        parts = components(vertices, proper, frozenset(cut))
        if len(parts) > 1:
            cut_parts[frozenset(cut)] = parts
    assert set(cut_parts) == EXPECTED_CUTS
    for parts in cut_parts.values():
        assert len(parts) == 2
        small = min(parts, key=len)
        assert len(small) == 1
        assert next(iter(small)) in terminals

    vectors = {
        label: note071.lift_matching(label)
        for label in IDENTITY_TO_PM.values()
    }
    target_cache = {}
    blocked_counts = []
    for targets, cells in concrete_gates(note074):
        assert len(targets) == len(cells) == 4
        blocked = 0
        for quadruple in targets:
            if quadruple not in target_cache:
                labels = tuple(IDENTITY_TO_PM[name] for name in quadruple)
                target_cache[quadruple] = tuple(
                    edge for edge in proper
                    if sum(edge in vectors[label] for label in labels) >= 3
                )
            blocked += bool(target_cache[quadruple])
        assert blocked
        blocked_counts.append(blocked)

    assert len(target_cache) == 20
    assert sum(bool(edges) for edges in target_cache.values()) == 15
    assert Counter(blocked_counts) == {2: 4, 3: 16, 4: 8}

    print({
        "order": len(vertices),
        "proper_edges": len(proper),
        "bridges": bridges,
        "proper_two_edge_cuts": tuple(
            sorted(tuple(sorted(cut)) for cut in EXPECTED_CUTS)
        ),
        "note019_cut_boundary_passes": True,
        "distinct_targets": len(target_cache),
        "overloaded_targets": 15,
        "concrete_gates": len(blocked_counts),
        "blocked_target_distribution": dict(sorted(Counter(blocked_counts).items())),
        "unblocked_gates": 0,
    })
    print("NOTE071_CASE_XII_CUT_AND_NONOVERLOAD_GATE_AUDITED")


if __name__ == "__main__":
    main()
