# Irreducible failed-star nonoverload counterexamples

This bundle verifies the two real-pole counterexamples in
[Note 080](../../../notes/080-girth-five-and-terminal-tree-two-cuts-do-not-force-nonoverload.md).

- `verify_order11_repeated.py` independently checks the explicit order-11
  pole, all fourteen perfect matchings, four BF rows, the complete proper
  bridge/2-cut boundary, girth five, and all three target overloads.
- `audit_note071_distinct.py` reads the permanent Note-071 certificate and
  Note-074 classification, checks the complete proper bridge/2-cut boundary,
  and verifies all 28 concrete three-distinct gates.

Run both on Omen with one process each:

```bash
python3 verify_order11_repeated.py
python3 audit_note071_distinct.py
```

Their final markers are

```text
ORDER11_REPEATED_STAR_IRREDUCIBLE_COUNTEREXAMPLE_VERIFIED
NOTE071_CASE_XII_CUT_AND_NONOVERLOAD_GATE_AUDITED
```

Both scripts use only the Python standard library.  The promoted Omen runs
on 2026-09-05 took 0.03 seconds with peak RSS 9,984 KB and 0.09 seconds with
peak RSS 12,032 KB, respectively.  Their outputs are frozen in
[`order11-omen-run.log`](order11-omen-run.log) and
[`note071-omen-run.log`](note071-omen-run.log).
