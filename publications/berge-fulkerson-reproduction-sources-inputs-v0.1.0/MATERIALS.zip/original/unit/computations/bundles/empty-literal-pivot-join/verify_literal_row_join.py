#!/usr/bin/env python3
"""Independent, vertex-recursive verification of the four literal-row join."""
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import sys


PROPER = ((0, 2), (0, 11), (1, 11), (1, 12), (2, 12), (3, 9),
          (3, 10), (4, 8), (4, 9), (5, 7), (5, 8), (5, 11),
          (6, 7), (6, 10), (6, 12), (7, 9), (8, 10))
INCIDENCES = tuple(frozenset(e) for e in PROPER) + tuple(frozenset((v,)) for v in range(5))
ROW_SLOTS = (("q13", "A", "X", "r45", "C", "D"),
             ("q14", "A", "C", "r23", "B", "X"),
             ("q24", "B", "C", "r15", "A", "D"),
             ("q25", "B", "D", "r34", "Y", "C"))
# Explicit boundary masks from the four displayed row equations, not a cell decoder.
ROW_BOUNDARIES = ((26, 1, 4, 7, 8, 16), (22, 1, 8, 25, 2, 4),
                  (21, 2, 8, 14, 1, 16), (13, 2, 16, 19, 4, 8))


def verify():
    matchings = []

    def extend(uncovered, chosen):
        if not uncovered:
            matchings.append(frozenset(chosen))
            return
        v = min(uncovered)
        for edge, ends in enumerate(INCIDENCES):
            if v in ends and ends <= uncovered:
                extend(uncovered - ends, (*chosen, edge))

    # Every PM has exactly one incidence at the first uncovered vertex, so this
    # recursion exhausts the graph-induced family without scanning proper subsets.
    extend(frozenset(range(13)), ())
    matchings.sort(key=lambda m: sum(1 << e for e in m))
    assert len(matchings) == len(set(matchings)) == 31
    assert all(sum(v in ends for ends in INCIDENCES) == 3 for v in range(13))
    for matching in matchings:
        assert all(sum(v in INCIDENCES[e] for e in matching) == 1 for v in range(13))
        assert 2 * sum(e < 17 for e in matching) + sum(e >= 17 for e in matching) == 13
    boundaries = [sum(1 << (e - 17) for e in m if e >= 17) for m in matchings]

    relations = []
    for slots, boundary_row in zip(ROW_SLOTS, ROW_BOUNDARIES):
        candidates = [[i for i, b in enumerate(boundaries) if b == required] for required in boundary_row]
        rows = []
        for identities in product(*candidates):
            # Complete class products and direct edge counts; no BF-cover input.
            if all(sum(e in matchings[i] for i in identities) == 2 for e in range(22)):
                rows.append(dict(zip(slots, identities)))
        relations.append(rows)

    partial = [{}]
    join_counts = []
    for rows in relations:
        next_partial = []
        for a in partial:
            for b in rows:
                shared = a.keys() & b.keys()
                if all(a[k] == b[k] for k in shared):
                    next_partial.append(dict(a, **b))
        partial = next_partial
        join_counts.append(len(partial))

    # Two of the four rows already force disjoint actual anchor identities.
    common_slots = ("B", "C")
    projection_14_23 = sorted({tuple(r[k] for k in common_slots) for r in relations[1]})
    projection_24_15 = sorted({tuple(r[k] for k in common_slots) for r in relations[2]})
    anchor_intersection = sorted(set(projection_14_23) & set(projection_24_15))

    # These exact assertions are the small regression check for the mathematical claim.
    assert list(map(len, relations)) == [4, 2, 4, 4]
    assert projection_14_23 == [(4, 9)]
    assert projection_24_15 == [(2, 8), (3, 8)]
    assert not anchor_intersection
    assert not partial
    return {"schema_version": 1,
        "spec_sha256": sha256(Path(__file__).with_name("SPEC.md").read_bytes()).hexdigest(),
        "independent_method": "vertex-recursive PM enumeration plus complete class products and integer edge loads",
        "verdict": "UNKNOWN", "unknown_reason": "empty_literal_configuration_domain",
        "scope": "Fixed Note-007 boundary labels; all four literal-row equations; no negative-support filter",
        "domain_enumeration_complete": True, "configurations_checked": 0,
        "unclassified_configuration_count": 0,
        "input": {"n": 13, "proper_edges": PROPER, "terminal_vertices": list(range(5))},
        "PM_count": len(matchings), "PM_masks": [sum(1 << e for e in m) for m in matchings],
        "PMs_used_by_rows": [{"id": i, "edge_ids": sorted(matchings[i]), "boundary_mask": boundaries[i]}
                            for i in sorted({i for rows in relations for r in rows for i in r.values()})],
        "pivot_slot_names": ROW_SLOTS, "pivot_relations": relations, "successive_join_sizes": join_counts,
        "common_anchor_slots": common_slots,
        "BC_projection_14_23": projection_14_23, "BC_projection_24_15": projection_24_15,
        "common_anchor_intersection": anchor_intersection,
        "all_literal_configuration_count": len(partial),
        "six_distinct_configuration_count": sum(c["X"] != c["Y"] for c in partial),
        "degenerate_configuration_count": sum(c["X"] == c["Y"] for c in partial),
        "dependent_splice_observation": "NOT_APPLICABLE_EMPTY_DOMAIN",
        "four_first_splice_projections": None,
        "configuration_components": [], "configuration_cross_cell_residual_mappings": []}


if __name__ == "__main__":
    result = verify()
    if len(sys.argv) > 1:
        Path(sys.argv[1]).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k not in ("PM_masks", "PMs_used_by_rows")}, indent=2))
