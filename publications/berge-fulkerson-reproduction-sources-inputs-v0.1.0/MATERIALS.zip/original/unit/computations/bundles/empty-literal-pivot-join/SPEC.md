# Note-007 literal identities and the Note-093/082 dependent section

Frozen before computation, 2026-09-05. This specification concerns only the
labelled thirteen-vertex pole of Notes 005 and 007. It makes no exact-Case-XII
assumption and does not launch another order census.

## Object, units, and identity conventions

Vertices are 0,...,12. Proper edges e0,...,e16, in order, are
`02,0-11,1-11,1-12,2-12,39,3-10,48,49,57,58,5-11,67,6-10,6-12,79,8-10`.
Edges e17,...,e21 are semiedges s1,...,s5 incident with vertices 0,...,4.
The displayed input in Note 005 fixes these boundary labels: no permutation,
orbit quotient, or anonymous-token identification is used.

For every actual perfect matching M, chi_M(e) is 0 or 1. It satisfies
sum_{e incident v} chi_M(e)=1 at all thirteen vertices and
2|M_proper|+|boundary(M)|=13. Coordinates and all loads are dimensionless
integer incidence counts; a semiedge has one vertex incidence. Thus
2|E_proper|+5=39. All equations below include all 22 edge objects.

Reuse Note 007's full PM and BF enumeration, with no selected-PM restriction.
The stable identity M_i is index i (zero based) in its numerically sorted
22-bit matching masks. BF covers are six-multisets, not six distinct identities.
At each row the six occurrence positions remain distinguished even when two
positions carry the same M_i. P_i is the complete boundary-{i} class; Q_ij
is the complete boundary-[5]\\{i,j} class. S={13,14,24,25,35} and
T={12,15,23,34,45}, as in Notes 005 and 055.

## Complete literal configuration domain

A configuration is a tuple

 (A,B,C,D,X,Y,q13,r45,q14,r23,q24,r15,q25,r34)

with A in P1, B in P2, C in P4, D in P5, X,Y in P3 and each triple
matching in the class specified by its subscript, satisfying all four exact
equations from Note 085(4):

 R1=(q13,A,X;r45,C,D),
 R2=(q14,A,C;r23,B,X),
 R3=(q24,B,C;r15,A,D),
 R4=(q25,B,D;r34,Y,C),
 sum_{M in Rj} chi_M = 2*1 for j=1,2,3,4.

Enumerate every tuple satisfying these equations. Do not add target overload,
failed-pivot, no-A, negative-support, column saturation, or exact-40 filters.
Record X!=Y (the six-distinct-identity stratum used in Notes 072/091) and
X=Y (the degenerate literal-equation stratum) separately. A verdict must say
which domain it covers; an empty six-identity stratum cannot establish its go.
Triple witnesses are part of the quantified configuration, rather than chosen
after seeing a successful splice. Equalities across rows use the same PM IDs.

## Independently constructed sources and reference targets

For each configuration form H23=r23+B+X and H34=r34+Y+C, and
K23(e)=2-H23(e), K34(e)=2-H34(e). Exhaust the complete PM products

 D35(K23)={(q,P3,P5) in Q35 x P3 x P5: q+P3+P5=K23},
 D13(K34)={(q',P1,P3') in Q13 x P1 x P3: q'+P1+P3'=K34}.

The occurrence rows (q,r23,B,X,P3,P5) and (q',r34,Y,C,P1,P3') are
the only initial rows. Construct these complete source families from the
fixed halves and PMs before testing any target, never from a final witness.
Construct the reference final families independently by scanning all complete
BF covers for the displayed boundary slots with literal singleton quartets
BDXY in (35,23) and ACXY in (13,34). Do not infer their members backwards
from a proposed chain. In either final family, the two fixed singleton
occurrences must return to their original actual identities at their slots;
the two triple occurrences may change identities within their original classes.

## Exact first and dependent second step

Sep(N;P,H) iff H\\P is a subset of N and N intersect (P\\H) is empty.
For each first replacement P3->Y, P5->D, P1->A, or P3'->X, first compute
the Note-093 projection F and fixed-half set
G={H} union {P in P_i: Sep(L;P,H) for at least one fixed-half occurrence L}.
Export F, G, and F intersect G. These sets quantify over all source rows.
Internal companions are represented in this projection by a source row that
already contains H, precisely as in the proof of Note 093(7).

For every actual source row and both endpoint orders, enumerate every one
of its other five occurrence positions as a first companion. For Sep success,
force N1=N+P-H coordinatewise and replace the two slots. Then use this
exact updated row, including N1 if selected again, for the other endpoint's
replacement. If the first companion was the other endpoint, its updated PM
is the second source. Enumerate all five second companion positions and force
the second update by the same equation. Check both updated PMs in the full
family, every intermediate row sum, and the final literal singleton slots.
The source quartet and all desired literals are those of this one configuration.
At most two splices includes an empty difference or an already final source.
No independent existential choice is permitted for the second row or anchors.

Only first steps installing one of the four literals count here. The arbitrary
preparatory forced-intermediate branch of Note 082 is outside this first-step
restriction. The third target ABDY, which needs an extra literal r12+A+B
anchor, is not a substitute for one of the four required projections.

The finite proposition is: for every literal configuration c, at least one
of its two source families has such a successful sequential chain. A failed
configuration must exhaust both source families, both endpoint orders and all
companions; failure of just one displayed row is insufficient.

## Component and cross-cell export

For each same-boundary pair P,H used in the four endpoint families, export
every connected component of P xor H as a sorted list of proper-edge IDs.
This edge-set list is its canonical component ID. Export P-phase, H-phase,
and the occurrence-pair labels on each H-phase edge; check each label has
size two and compare their intersection to Sep on all five companions.

For each endpoint source occurrence h=(R,P,H), enumerate every subset I
of its alternating components, let P^I=P xor union(I), and, for each current
companion N, test the forced vector N+P-P^I. Export every actual PM residual
and its slot. Cross-cell mappings join these residual IDs to identical PM
IDs in all operative occurrence slots of the opposite source family. Never
join only on boundary class. Export both directions, and the common literal
anchor/extension IDs A,B,C,D,X,Y linking all four pivot rows and both sources.
Empty crossings do not constitute an additional unproved obstruction class.

## Coverage, resource bound, and independent acceptance

One local process; 31 PMs, 177 BF covers, 22 coordinates. The input verifier
uses an array of 2^17 proper subsets (a few MB); no graph generator or solver
is needed. Index the 177 rows by boundary slots; stream Cartesian joins of
the four literal relations. Keep diagnostic expansion only for a decisive
counterexample or a compact representative certificate. Do not multiply by
six-colour permutations. A resource interruption is UNKNOWN, never no-go or go.

Before accepting a counterexample, independently verify its PM vertex
incidences and four literal equations, and build the target BF families
without using splice residuals. Verify the decisive absence by a different
direct check (e.g. target quartet overload, or exhaustive ordered pair-sum
reachability on the complete PM family). Before accepting finite go, check
one valid chain certificate for every configuration with direct integer-vector
equalities and fixed slot identities, and confirm full nonempty domain coverage.
Proxy/agent prose, a successful exit code, or a reported count is not evidence.

## Output schema and one-sentence acceptance

The JSON contains schema_version, spec_sha256, input/PM/BF/slot tables,
domain_counts (including X!=Y and X=Y), domain_enumeration_complete,
configurations_checked, verdict in {NO_GO, FINITE_GO, UNKNOWN},
unknown_reason (null or explicit text), unclassified_configuration_count
(integer or null), scope, and a counterexample or per-configuration witnesses.
Diagnostic tables include component IDs, four projections, all relevant
dependent first/second updates, reference target families, and cross-cell
residual mappings. There is no EXCEPTIONAL branch and no inferred clearing
of unresolved cases. Stopping on a checked counterexample does not imply
that unvisited configurations passed.

Acceptance: a legally instantiated and independently verified failure closes
this literal-only route; a completely checked nonempty domain yields only
finite go; an empty required domain, incomplete identity mapping, interruption,
or any undecided configuration yields UNKNOWN, with no claim about genuine
exact-Case-XII poles or order seventeen.
