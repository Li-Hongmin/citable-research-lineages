# Failed-pivot residual-selector counterexample

Run from the AIMath root:

```text
python3 units/berge-fulkerson/computations/bundles/failed-pivot-residual-selector-counterexample/verify_failed_pivot_residual_avoiding_pole.py
```

The verifier uses only the Python standard library.  It independently
enumerates all perfect matchings of the explicit order-thirteen pole and
checks simplicity, connectedness, cubic degrees, absence of bridges, the
four exact double-cover rows, the three distinct pivot extensions, all 79
forbidden-boundary five-occurrence selectors, girth, Tait states, and the
complete BF pair-type support.  Its final marker is

```text
FAILED_PIVOT_RESIDUAL_AVOIDING_POLE_VERIFIED
```

Reference run: Python 3.12 on Omen, 2026-09-04; wall time 0.31 seconds,
maximum RSS 10,240 KB.
