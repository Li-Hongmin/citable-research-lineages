import itertools as it,json
from pathlib import Path
P=range(1,8)
L=tuple(tuple(sorted((a,b,a^b))) for a in P for b in P if a<b<a^b)
perms=[]
for a,b,c in it.permutations(P,3):
 t=tuple(0 if x==0 else (a if x&1 else 0)^(b if x&2 else 0)^(c if x&4 else 0) for x in range(8))
 if len(set(t))==8: perms.append(t)
def act(t,l):return tuple(sorted(t[x] for x in l))
S=frozenset(L[2:]); H=[t for t in perms if frozenset(act(t,l) for l in S)==S]
point_orbits=sorted(set(tuple(sorted(t[x] for t in H)) for x in []))
def orbits(items,action):
 todo=set(items);out=[]
 while todo:
  x=min(todo);o={action(t,x) for t in H};todo-=o;out.append(sorted(o))
 return out
points=orbits(P,lambda t,x:t[x]);flags=orbits([q for l in S for q in it.permutations(l)],lambda t,q:tuple(t[x] for x in q))
print('lines',L,'palette',sorted(S),'group',len(perms),'stabilizer',len(H),'point orbits',points,'ordered star orbit sizes',[len(o) for o in flags])
# Exact palettes retained after cutting an edge; equal five palettes needed.
edge_matrix=[[any(t[y]==x for t in H) for y in P] for x in P]
# Actual retained palette after deleting star can have <=5; general compatible profile check later.
res={'lines':L,'palette':sorted(S),'group_order':len(perms),'stabilizer_order':len(H),'point_orbits':points,'star_orbits':flags,'edge_matrix':edge_matrix}
Path(__file__).with_name('classification.json').write_text(json.dumps(res,indent=2)+'\n')
