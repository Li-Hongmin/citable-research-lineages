import random,json,itertools
from pathlib import Path
import networkx as nx
D=Path(__file__).parent;r=json.loads((D/'classification.json').read_text());stars=r['palette']*2
rng=random.Random(20260913)
for trial in range(100000):
 edges=[]
 for c in range(1,8):
  vs=[v for v,s in enumerate(stars) if c in s];rng.shuffle(vs)
  edges.extend((min(a,b),max(a,b),c) for a,b in zip(vs[::2],vs[1::2]))
 G=nx.Graph();G.add_nodes_from(range(10));G.add_edges_from((a,b) for a,b,c in edges)
 if G.number_of_edges()!=15 or nx.number_of_selfloops(G) or not nx.is_connected(G) or list(nx.bridges(G)):continue
 # An explicit Tait witness, independent of the Fano labels.
 edges.sort();labels=[0]*15;used=[set() for _ in G]
 def dfs(i):
  if i==15:return True
  a,b,_=edges[i]
  for c in (1,2,3):
   if c not in used[a] and c not in used[b]:
    used[a].add(c);used[b].add(c);labels[i]=c
    if dfs(i+1):return True
    used[a].remove(c);used[b].remove(c)
  return False
 if dfs(0):break
else:raise RuntimeError('no witness')
out={'edges':edges,'tait':labels,'stars':stars,'trial':trial}
(D/'graph.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
