# A separate constructive check, using basis extension rather than search in a group.
import itertools,json
from pathlib import Path
P=set(range(1,8));lines=[set(x) for x in [(1,2,3),(1,4,5),(1,6,7),(2,4,6),(2,5,7),(3,4,7),(3,5,6)]]
# Addition table defined by incidence, independently of the generator's XOR.
def add(a,b):
 if a==0:return b
 if b==0:return a
 if a==b:return 0
 return next(next(iter(l-{a,b})) for l in lines if {a,b}<=l)
def extension(a,b):
 c=min(P-{a,b,add(a,b)});p={1:a,2:b,3:add(a,b),4:c,5:add(a,c),6:add(b,c),7:add(add(a,b),c)}
 assert set(p.values())==P
 assert all({p[x] for x in l} in lines for l in lines)
 return p
edges=stars=0
for mask in range(1,128):
 S=[lines[i] for i in range(7) if mask>>i&1]
 if len(S)>5:continue
 for x in set().union(*S):
  l=next(l for l in S if x in l); y=min(l-{x});p=extension(x,y)
  assert p[1]==x and {p[1],p[2],p[3]} in S;edges+=1
 for l in S:
  for a,b in itertools.permutations(sorted(l),2):
   q=(a,b,next(iter(l-{a,b})));p=extension(a,b)
   assert tuple(p[x] for x in (1,2,3))==q;stars+=1
r=json.loads(Path(__file__).with_name('interface.json').read_text())
assert r=={'one_line_edge_cases':edges,'one_line_star_cases':stars}
print('VERIFIED constructive one-line interface:',edges,'edge cases;',stars,'ordered-star cases')
