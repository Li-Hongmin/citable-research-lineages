import itertools as it,json
from pathlib import Path
P=range(1,8);L=[frozenset((a,b,a^b)) for a in P for b in P if a<b<a^b]
G=[]
for a,b,c in it.permutations(P,3):
 p={x:(a if x&1 else 0)^(b if x&2 else 0)^(c if x&4 else 0) for x in P}
 if len(set(p.values()))==7:G.append(p)
root=frozenset((1,2,3));edge=star=0
for k in range(1,6):
 for comb in it.combinations(L,k):
  S=set(comb)
  for x in set.union(*(set(l) for l in S)):
   assert any(p[1]==x and frozenset(p[c] for c in root) in S for p in G);edge+=1
  for l in S:
   for q in it.permutations(sorted(l)):
    assert any(tuple(p[c] for c in (1,2,3))==q for p in G);star+=1
out={'one_line_edge_cases':edge,'one_line_star_cases':star}
Path(__file__).with_name('interface.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
