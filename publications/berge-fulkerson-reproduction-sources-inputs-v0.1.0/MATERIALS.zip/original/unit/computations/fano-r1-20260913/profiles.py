import itertools as it,json
from pathlib import Path
D=Path(__file__).parent;P=range(1,8)
L=[frozenset((a,b,a^b)) for a in P for b in P if a<b<a^b];S=set(L[2:]);G=[]
for a,b,c in it.permutations(P,3):
 p={x:(a if x&1 else 0)^(b if x&2 else 0)^(c if x&4 else 0) for x in P}
 if len(set(p.values()))==7:G.append(p)
H=[p for p in G if {frozenset(p[x] for x in l) for l in S}==S]
result={}
for k,states in ((2,[(x,x) for x in P]),(3,sorted(q for l in L for q in it.permutations(sorted(l))))):
 todo=set(states);orbits=[]
 while todo:
  q=min(todo);o={tuple(p[x] for x in q) for p in H};todo-=o;orbits.append(sorted(o))
 result[str(k)]=orbits
 print(k,'pole:',len(orbits),'orbits, sizes',[len(o) for o in orbits])
(D/'profiles.json').write_text(json.dumps(result,indent=2)+'\n')
