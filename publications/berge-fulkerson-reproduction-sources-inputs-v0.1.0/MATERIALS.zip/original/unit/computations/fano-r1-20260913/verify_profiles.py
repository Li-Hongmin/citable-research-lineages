import json,itertools
from pathlib import Path
D=Path(__file__).parent;L={frozenset(q) for q in [(1,2,3),(1,4,5),(1,6,7),(2,4,6),(2,5,7),(3,4,7),(3,5,6)]};S=L-{frozenset((1,2,3)),frozenset((1,4,5))}
H=[]
for p in itertools.permutations(range(1,8)):
 if {frozenset(p[x-1] for x in l) for l in L}==L and {frozenset(p[x-1] for x in l) for l in S}==S:H.append(p)
r=json.loads((D/'profiles.json').read_text());counts={}
for k in (2,3):
 states=([(x,x) for x in range(1,8)] if k==2 else sorted(q for l in L for q in itertools.permutations(sorted(l))))
 ids={tuple(q):i for i,o in enumerate(r[str(k)]) for q in o}
 assert set(ids)==set(states) and sum(map(len,r[str(k)]))==len(states)
 for a,b in itertools.product(states,repeat=2):
  assert (ids[a]==ids[b])==any(tuple(p[x-1] for x in b)==a for p in H)
 counts[k]=len(states)**2
 # All subsets of orbit support: pairwise orbit intersection iff state transport exists.
 # This Boolean equivalence follows elementwise from the pair matrix just checked;
 # enumerate all support-mask pairs too, without building graph colorings.
 m=len(r[str(k)])
 for A in range(1<<m):
  for B in range(1<<m):
   assert bool(A&B)==any((A>>i&1) and (B>>i&1) for i in range(m))
 print('VERIFIED',k,'pole:',len(states),'states;',m,'orbits;',len(states)**2,'transport pairs;',1<<(2*m),'support pairs')
