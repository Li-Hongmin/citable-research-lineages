# Independent implementation: all 7! incidence permutations, no XOR or imports from explorer.
import itertools,json
from pathlib import Path
D=Path(__file__).parent
lines={frozenset(x) for x in [(1,2,3),(1,4,5),(1,6,7),(2,4,6),(2,5,7),(3,4,7),(3,5,6)]}
r=json.loads((D/'classification.json').read_text()); S={frozenset(x) for x in r['palette']}
g=[]
for p in itertools.permutations(range(1,8)):
 if {frozenset(p[x-1] for x in l) for l in lines}==lines:g.append(p)
h=[p for p in g if {frozenset(p[x-1] for x in l) for l in S}==S]
assert len(g)==r['group_order']==168 and len(h)==r['stabilizer_order']==8
assert len({frozenset(frozenset(p[x-1] for x in l) for l in S) for p in g})==21
for o in r['point_orbits']:
 assert {p[o[0]-1] for p in h}==set(o)
for o in r['star_orbits']:
 assert {tuple(p[x-1] for x in o[0]) for p in h}==set(map(tuple,o))
assert sorted(x for o in r['point_orbits'] for x in o)==list(range(1,8))
assert set(tuple(x) for o in r['star_orbits'] for x in o)=={x for l in S for x in itertools.permutations(l)}
for x in range(1,8):
 for y in range(1,8):assert r['edge_matrix'][x-1][y-1]==any(p[y-1]==x for p in h)
print('VERIFIED: 21 palettes, 168 incidence automorphisms, stabilizer 8, point orbits 1/4/2, six ordered-star orbits.')
