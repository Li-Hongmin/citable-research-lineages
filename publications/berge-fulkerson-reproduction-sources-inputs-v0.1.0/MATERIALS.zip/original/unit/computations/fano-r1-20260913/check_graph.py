# Independent incidence-permutation checker of the explicit graph witness.
import json,itertools
from pathlib import Path
D=Path(__file__).parent
r=json.loads((D/'graph.json').read_text()); E=r['edges'];T=r['tait'];n=10
L={frozenset(x) for x in [(1,2,3),(1,4,5),(1,6,7),(2,4,6),(2,5,7),(3,4,7),(3,5,6)]}
assert len(E)==15 and len({(a,b) for a,b,c in E})==15 and all(0<=a<b<n for a,b,c in E)
def connected(edges,n):
 seen={0}
 while True:
  nxt=seen|{b for a,b in edges if a in seen}|{a for a,b in edges if b in seen}
  if nxt==seen:return len(seen)==n
  seen=nxt
assert all(connected([(a,b) for j,(a,b,c) in enumerate(E) if j!=i],n) for i in range(15))
stars=[]
for v in range(n):
 inds=[i for i,(a,b,c) in enumerate(E) if v in (a,b)]
 assert len(inds)==3 and {T[i] for i in inds}=={1,2,3}
 star=frozenset(E[i][2] for i in inds);assert star in L;stars.append(star)
assert [sorted(s) for s in stars]==r['stars'];S=set(stars);assert len(S)==5
A=[]
for p in itertools.permutations(range(1,8)):
 if {frozenset(p[x-1] for x in l) for l in L}==L:A.append(p)
def image(p,S):return {frozenset(p[x-1] for x in l) for l in S}
edge_min=min(len(S|image(p,S)) for p in A if p[2-1]==1)
# Delete vertex 0 on side A, vertex 1 on side B, ordered colors (1,6,7) vs (2,4,6).
SA=set(stars[1:]);SB={s for i,s in enumerate(stars) if i!=1}
assert SA==SB==S
star_min=min(len(SA|image(p,SB)) for p in A if tuple(p[x-1] for x in (2,4,6))==(1,6,7))
assert edge_min==6 and star_min==6
print('VERIFIED graph: simple connected cubic bridgeless; exact 5-line coloring and Tait witness.')
print('VERIFIED fixed-coloring minimum union: edge (0,5) / (1,2):',edge_min,'; ordered vertex 0 / 1:',star_min)
# Check constructed sums and transformed Tait witnesses explicitly.
for mode in ('edge','star'):
 if mode=='edge':
  i=next(i for i,e in enumerate(E) if e[:2]==[0,5]);j=next(i for i,e in enumerate(E) if e[:2]==[1,2])
  perm=next(q for q in itertools.permutations((1,2,3)) if q[T[j]-1]==T[i])
  out=[(a,b,T[k]) for k,(a,b,c) in enumerate(E) if k!=i]+[(a+10,b+10,perm[T[k]-1]) for k,(a,b,c) in enumerate(E) if k!=j]
  out.extend([(0,11,T[i]),(5,12,T[i])])
 else:
  # Pair ports by increasing original Fano color at removed vertices.
  ports=[]
  for v in (0,1):
   ports.append(sorted((c,b if a==v else a,T[k]) for k,(a,b,c) in enumerate(E) if v in (a,b)))
  perm=next(q for q in itertools.permutations((1,2,3)) if all(q[y[2]-1]==x[2] for x,y in zip(*ports)))
  out=[(a,b,T[k]) for k,(a,b,c) in enumerate(E) if 0 not in (a,b)]+[(a+10,b+10,perm[T[k]-1]) for k,(a,b,c) in enumerate(E) if 1 not in (a,b)]
  out.extend((x[1],y[1]+10,x[2]) for x,y in zip(*ports))
 vertices=sorted({v for a,b,c in out for v in (a,b)}); ren={v:i for i,v in enumerate(vertices)}
 assert len(vertices)==(20 if mode=='edge' else 18)
 for v in vertices:assert sorted(c for a,b,c in out if v in (a,b))==[1,2,3]
 pairs=[(ren[a],ren[b]) for a,b,c in out]
 assert len(set(tuple(sorted(e)) for e in pairs))==len(pairs)
 assert all(connected(pairs[:i]+pairs[i+1:],len(vertices)) for i in range(len(pairs)))
 print('VERIFIED',mode,'sum: cubic simple bridgeless, explicit one-line recoloring, order',len(vertices))
