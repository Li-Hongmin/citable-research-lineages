> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK padded history 的 signal/off-signal parent-binding gate（2026-08-18）

> **Correction.** The lift formula in this note is dimensionally misstated. It must be
> read using the left/right half-lifts (L_{G,0}(z)=G(\operatorname{left}_k z)) and
> (L_{G,1}(z)=G(\operatorname{right}_k z)), as proved in [C382](382-jk-signal-lift-dimension-correction-2026-08-18.md). The concatenation (G(u)\Vert G(v)) has length (4k) and is not a single JK block.

## 本轮判定

对 RW Theorem 4.3 实际使用的

\[
  f_i=B_i\,0^{T_i-2n_i}
\]

型目标，JK 的 success 输出不能再只被抽象地称为一个“child outsider”。在固定的
truth-table generator \(G_k:\{0,1\}^k\to\{0,1\}^{2k}\) 和 lexicographically
first range preimage 规则下，每一层只有第一块携带父表前缀；其余块是与 \(B_i\)
无关的固定 tail。于是 success 分支有一个精确的 source-specific 三分：

1. 输出 signal block 时，给出阶段编号即可沿 \(G_k\) 的正向计算逆着恢复原始首块；
2. 输出 off-signal block 时，输出本身不携带父表，任何同一输出 fiber 上的精确
   parent decoder 都必须把 fiber 大小写进 descriptor；
3. 若父表比一个 \(2k\)-bit block 更长，则单个 success 输出加 \(d\)-bit descriptor
   至少支付 \(b-2k\) bits，不能在 \(k=\operatorname{poly}(\log b)\) 的地址尺度下
   免费恢复 \(b\)-bit 父表。

这不是 \(P\ne NP\) 证明，也不是对 JK 任意 tie-break 的无条件结论。它把 RW-specific
Gate-I 的剩余问题压成一个可核验的选择条件：采用允许的 first-failure tie-break
并证明 signal block 落在 non-range，或证明 off-signal fiber 本身很小；否则必须支付
object-scale parent information。

## JK 分层记号

固定 \(G\)，令

\[
  F_B=B0^{T-b},\qquad B\in\{0,1\}^b,
\]

其中 \(T>k\)，并令 \(h=\lceil\log_2(T/k)\rceil\)、\(T'=k2^h\)。JK 把
\(F_B\) 右侧补零得到 \(Y_h=F_B0^{T'-T}\)。在阶段 \(j\) 中，\(Y_j\) 长度为
\(k2^j\)，分成 \(2^{j-1}\) 个连续的 \(2k\)-bit blocks

\[
  Z_{j,1},\ldots,Z_{j,2^{j-1}}.
\]

若所有块都在 \(R=\operatorname{Range}(G)\)，令

\[
  P_G(z)=\min\{u:G(u)=z\}
\]

为 lexicographically first preimage，并把下一层设为

\[
  Y_{j-1}=P_G(Z_{j,1})\,P_G(Z_{j,2})\cdots
          P_G(Z_{j,2^{j-1}}).
\]

若某块不在 \(R\)，Theorem 3.1 允许输出该块作为 hard/AVOID witness。令

\[
  \mathsf{Lift}_G(u\Vert v):=G(u)\Vert G(v),
  \qquad u,v\in\{0,1\}^k.
\]

这里的 \(\mathsf{Lift}_G\) 只是对已输出的 \(2k\)-bit block 做正向计算，不需要求
\(G\) 的逆。

## Signal-path lemma

假设 \(b\le 2k\)，并令 \(Z_{j,1}\) 为每一层第一块。只要 JK 在阶段 \(j+1\)
之前没有停止，就有

\[
  \mathsf{Lift}_G(Z_{j,1})=Z_{j+1,1}.
\tag{377.1}
\]

因此，如果 hard 分支在阶段 \(j\) 输出 signal block

\[
  y=Z_{j,1},
\]

则

\[
  \operatorname{pref}_{b}
  \left(\mathsf{Lift}_G^{\,h-j}(y)\right)=B.
\tag{377.2}
\]

### 证明

在阶段 \(j+1\) 没有停止时，第一块 \(Z_{j+1,1}\) 的两个 canonical preimages
\(P_G(Z_{j+1,1})\) 和 \(P_G(Z_{j+1,2})\) 组成阶段 \(j\) 的前 \(2k\) bits，故

\[
  Z_{j,1}=P_G(Z_{j+1,1})\Vert P_G(Z_{j+1,2}).
\]

对两半分别应用 \(G\) 即得 (377.1)。迭代到 \(Z_{h,1}\)；由于顶层 \(Y_h\) 的前
\(b\) bits 正是 \(B\)，得到 (377.2)。证毕。

阶段编号 \(j\in\{1,\ldots,h\}\) 只需 \(\lceil\log_2(h+1)\rceil\) bits。故在
signal 分支，\((G,y,j)\mapsto B\) 是一个显式的 parent-binding evaluator，其
计算只需 \(h-j\) 次 \(G\) 的正向计算。它不调用 SAT，也不需要 descriptor 去编码
整条父表。

## Off-signal fiber lemma

本节与 signal-path lemma 一样，先处在 \(b\le2k\) 的 single-block regime；若
\(b>2k\)，直接使用下一节的 block-width information gate。

在顶层 \(Y_h=F_B0^{T'-T}\) 中，除了第一块之外的 blocks 都是全零。只要某个阶段
以前没有停止，所有非第一块都由同一个固定的 canonical tail 递推得到；因此对每个
阶段 \(j\) 和位置 \(u\ge2\)，其 block \(Z_{j,u}\) 与 \(B\) 无关。

设 \(\mathcal F_{j,u}\) 是一组目标前缀，使得 JK 在阶段 \(j\) 选择同一个 off-signal
block \(Z_{j,u}=y\)（选择规则和阶段一并固定）。若存在 exact decoder

\[
  D(G,y,\sigma_B)=B
  \qquad(B\in\mathcal F_{j,u}),
\]

则

\[
  |\sigma_B|\ge \log_2|\mathcal F_{j,u}|.
\tag{377.3}
\]

### 证明

在该 fiber 上 \(G\) 和 \(y\) 相同。若两个不同目标使用相同 descriptor，decoder 的
输入完全相同，却必须输出两个不同的 \(B\)，矛盾。因此 \(B\mapsto\sigma_B\) 在
fiber 上 injective，得到 (377.3)。证毕。

注意：该结论按实际 fiber 计数，不假设所有 \(2^b\) 个目标都落在同一个 off-signal
fiber；这避免把 JK 未规定的并列 non-range tie-break 偷换成强结论。

## Block-width information gate

即使不区分 signal/off-signal，单个 JK success output 只有 \(2k\) bits。若 \(B\)
在一个 \(2^b\)-大小的均匀 family 中，且 decoder 的 target-dependent descriptor
只有 \(d\) bits，则 exact recovery

\[
  D(G,y,\sigma_B)=B
\]

要求

\[
  2k+d\ge b,
  \qquad\text{即}\qquad d\ge b-2k.
\tag{377.4}
\]

这是简单的状态计数：\((y,\sigma_B)\) 最多有 \(2^{2k+d}\) 种取值，而目标有
\(2^b\) 个。因而当 \(k=\operatorname{poly}(\log b)\) 时，一个 success outsider
不可能独立恢复整个 \(b\)-bit parent；至少要付近 \(b\) bits 的 descriptor，除非
改用多个 success outputs 或别的 global binding。

## 对 truth-table generator 的 signal corollary

对 RW 的 truth-table generator \(G_k\)，若

\[
  B0^{2k-b}\in\operatorname{Range}(G_k),
\]

则一个 \(k\)-bit circuit description 产生了一个包含 \(B\) 的 truth table。固定该
description 后，只在相应地址上加零 padding，就得到一个计算 \(B\) 的通用电路，故

\[
  \operatorname{CC}(B)\le O(k\,\operatorname{polylog}k).
\tag{377.5}
\]

（具体常数取决于 gate-list/universal-evaluation 编码。）所以在允许的 first-failure
tie-break 下，如果 \(b\le2k\) 且

\[
  \operatorname{CC}(B)>O(k\,\operatorname{polylog}k),
\tag{377.6}
\]

顶层 signal block 必为 non-range，JK 会在第一层输出它；此时 \(y\) 的前 \(b\) bits
就是 \(B\)，parent binding 是免费的。

这个 corollary 的重要边界是尺度：实际 RW 稳定段中

\[
  b=2n_i,\qquad k=n_{i+1}=n_i^C,
\]

所以 \(b\le2k\) 成立，但已发表的硬度
\(\operatorname{CC}(B)=\Omega(n_i/\log n_i)\) 并不超过
\(O(k\,\operatorname{polylog}k)\)。因此 (377.6) 在 published 参数上不触发，不能把
该 signal corollary 冒称为现有 RW 的最终矛盾。

反过来，若试图把 \(k\) 压到 \(\operatorname{poly}(\log b)\)，则通常 \(b>2k\)，
直接进入 (377.4) 的 message-scale descriptor gate；这正是“success outsider 只是
child object，不能自动成为 parent accessor”的一个更具体的 RW source-level 证明。

## 对 Closure 的决定

这条结果把 RW Gate-I 的 success 分支压成三个可检验任务：

1. **first-failure + signal：** 明确采用 Theorem 3.1 允许的最小 non-range tie-break，
   并证明实际 hard parent 使顶层 signal non-range；随后 (377.2) 给出 parent binding。
2. **off-signal：** 对每个可能的 off-signal fiber 给出足够大的
   \(|\mathcal F_{j,u}|\)，然后用 (377.3) 付 descriptor；或证明该分支不可能。
3. **短 block：** 若 \(b>2k\)，必须用多个输出或另一个 relation-PCP 绑定；单个
   outsider 加地址尺度 descriptor 被 (377.4) 排除。

因此，JK success 并非自动闭合，也不是完全无信息的 child outsider：它在 signal 路径上
有一个明确的正向 lift，但这个正向机制在已发表 RW 稳定尺度上仍是 object-scale，且受
off-signal/tie-break 与短 block 两个 Gate-I 条件约束。

## 证据边界

* Ren--Williams Theorem 3.1 的分层过程和 lexicographically smallest range
  preimage：本地原文抽取 units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md，第 8--10 页。
* Ren--Williams Theorem 4.3 的实际目标 \(f_i(x)=B_i0^{T_i-2n_i}\) 与
  \(k=n_{i+1}\)：同一抽取第 16--18 页。
* 该 note 是 padded-target 的 source-specific parent-binding/scale theorem；它不声称
  RW 当前 tie-break 已经选择 signal、不声称 off-signal fiber 必然大，也不声称
  \(P\ne NP\) 或一般 dPCP/RLDC 不可能性。
