> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fano--entropy closure for policy-generated global words

## Setup

Let \(\mathcal M\) be a finite message set of size \(L\), let \(M\) be uniform on
\(\mathcal M\), and let
\[
 Y:\mathcal M\to\Gamma^N
\]
be a code with minimum distance \(d>2t\). Let \(S\) be an arbitrary
standard-Borel policy object. Let \(R\) be fresh randomness independent of \(M,S\),
and let \(Z=G(S,R)\) be a full-word output. Thus
\[
 M\longrightarrow S\longrightarrow Z
\tag{1}
\]
is a Markov chain.

Assume
\[
 p:=\Pr[d_H(Z,Y(M))\le t].
\]

## Theorem 1 (policy information lower bound)

Under the setup above,
\[
 I_2(M;S)
 \ge
 \log_2 L-h_2(1-p)-(1-p)\log_2(L-1).
 \tag{2}
\]
In particular,
\[
 I_2(M;S)\ge p\log_2L-1.
 \tag{3}
\]

### Proof

Because \(d>2t\), the nearest-codeword decoder is unique on every word within
distance \(t\) of a codeword. Applying this decoder to \(Z\) gives an estimate
\(\widehat M\) with error at most \(1-p\). Fano's inequality yields
\[
 H_2(M\mid Z)\le H_2(M\mid\widehat M)
 \le h_2(1-p)+(1-p)\log_2(L-1).
\]
Therefore \(I_2(M;Z)\) is at least the right-hand side of (2). The Markov chain
and data processing give \(I_2(M;S)\ge I_2(M;Z)\). Since
\(h_2(1-p)\le1\) and \((1-p)\log_2(L-1)\le(1-p)\log_2L\), (3) follows. \(\square\)

## Corollary 2 (three-way closure gate)

Suppose in addition that, conditioned on \(S=s\), the coordinates of \(Z\) are
independent, and that the conditional min-entropy sum is at least \(H\) outside
a policy set of mass \(\delta\). Then the conditional-independence bound gives
\[
 p\le \delta+(1-\delta)|\mathcal Y|V_Q(N,t)2^{-H},
 \tag{4}
\]
where \(\mathcal Y=Y(\mathcal M)\). Consequently, any construction aiming for
global success \(p\ge p_0\) must pay at least one of:

1. target information
   \(I_2(M;S)\ge p_0\log_2L-1\);
2. a policy mass \(\delta\) of conditional-entropy collapse large enough to evade (4);
3. residual joint correlation after conditioning on \(S\), so the conditional-product
   hypothesis itself fails.

If \(\mathcal Y\) has full projections and relative distance
\(\Delta=d/N>H_Q(\varepsilon)\) at \(t=\varepsilon N\), then item 2 requires a
linear conditional min-entropy deficit by C286.

## Scope

The Markov assumption says that the policy object contains all target-dependent
information used to generate the full word; it is not automatic for a verifier that
still receives the target as a separate input. The theorem is therefore a precise
closure interface, not an unconditional statement about arbitrary PCP protocols.
It is useful exactly when a proposed same-proof construction claims to compress the
target dependence into a policy/strategy object.
