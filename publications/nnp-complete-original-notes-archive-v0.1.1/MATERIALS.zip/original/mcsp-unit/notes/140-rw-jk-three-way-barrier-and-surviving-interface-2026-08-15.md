> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW/JK 解压架构的三路障碍与唯一剩余接口（2026-08-15）

## 适用范围

本 note 只讨论如下架构：固定 \(G_q:\{0,1\}^{q}\to\{0,1\}^{2q}\)，把一个
显式或隐式 PCP truth table 分成 \(2q\)-bit leaf blocks，并通过 Jeřábek--Korten
的相邻 preimage concatenation 递归重建。它不是对所有可能的 compressed search
算法的完备不可能性定理。

## 三路障碍

### A. Universal coverage + full closure

若 \(G_q\) 覆盖所有 size-\(\le s\) 的 \(m\)-变量 truth tables，且所有 covered
\(2^h\)-leaf tuples 都能在同一 range 中递归闭合，则 note 138 给出

\[
2^h s\log s=O(q).
\]

对完整长度 \(T\) 的 JK recursion，\(2^h=\Theta(T/q)\)，所以

\[
s\log s=O(q^2/T).
\tag{1}
\]

当 \(T\gg q^2\) 时，near-linear coverage 与 full universal closure 不能同时成立。

### B. Shared global key + 高熵 history family

若所有 history proofs 由一个统一 random-access global key 生成，且 witness family
\(\mathcal W\) 的 systematic prefix 两两不同，则 note 139 的单射计数给出

\[
|K|\ge\log_2|\mathcal W|.
\tag{2}
\]

所以高熵 witness family 不能用 \(\operatorname{poly}(\log T)\)-bit key 覆盖；只有
单一 history 可能有短 key，而这要求一个真正 P-uniform 的 history-specific
construction，不能把 witness 当作 hidden advice。

### C. 放弃 universal closure 后的 outsider 硬度不足

若只知道每个 leaf block 属于一个 size-\(s\) family \(A\)，对任意 tuple 直接拼接
得到的整张 expansion truth table \(Y\) 有平凡上界

\[
\operatorname{CC}(Y)
\le O\!\left(2^h(s+m+h)\right).
\tag{3}
\]

因此 tree-capacity 找到一个 expansion outsider，并不自动给出
\(N^{1+\varepsilon}\) 或 \(n^{\omega(1)}\) 的全局电路下界；note 119 已把这个
“sparse range \(\not\Rightarrow\) hard outsider”边界写成正式估计。

## 只剩的可行接口

在这三个障碍下，当前架构若要改变 \(P\) vs \(NP\) 决策，只能证明一个更窄的
RW-specific 命题：

\[
\boxed{
\begin{array}{c}
\text{单一 actual history}\\
\text{有 uniform、短且不含隐式 witness advice 的 global key}\\
\text{该 key 产生的 whole-tree labeler 仍对应一个全局 hard slice}
\end{array}}
\tag{4}
\]

或者彻底放弃 full-tree closure，直接给出一个对 implicit history 的
compressed-JK search theorem。Universal coverage、generic PCP systematicity 或
单纯的 tree-capacity counting 都不能替代式 (4)。

## 路线裁决

式 (4) 目前仍是未证明的充分接口，而不是存在性结论。它比“构造一个
near-linear universal decoder”窄得多，也比“从一个 non-range block 自动得到
hard language”强得多。后续实验/证明若不能产生式 (4) 中的 uniform key 或全局硬度，
就不应继续扩大 universal decoder 的覆盖范围。

来源：notes 119、137--139；Ren--Williams Theorems 3.1、3.4--3.5、4.1
（ECCC TR26-118 revision 1）。本文是路线合并记录，不声称 \(P\ne NP\)。
