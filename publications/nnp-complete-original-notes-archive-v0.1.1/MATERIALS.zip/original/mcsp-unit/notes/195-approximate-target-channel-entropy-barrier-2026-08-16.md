> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 近似 singleton target-channel 的熵下界（2026-08-16）

## 结论地位

这是对 note 175 的 `SB-ENT` 的定量升级：允许一个**共同的有限摘要**驱动随机
evaluator，并允许目标词有平均 Hamming 误差 `eta<1/2`，仍然得到目标族熵下界。
它是一个编码/通信定理，不是一般 dPCP proof-length lower bound；摘要可以支付
`Theta(k)` 比特，定理本身不排除近线性 proof。

## 定理（approximate target-channel entropy）

令 `F subseteq {0,1}^k` 为目标词族，`0 <= eta < 1/2`。设一个总长度为 `L`
比特的共同摘要 `omega`（例如 static key 与有限 Merlin-strategy summary 的拼接）
和一个统一 randomized word evaluator

```text
E(omega; R) in {0,1}^k
```

满足：对每个 `f in F`，存在某个摘要 `omega_f`，使

```text
E_R[ dist_H(E(omega_f; R), f) ] <= eta * k.
```

则

```text
L >= log_2 |F| - k H_2(eta).
```

这里 `H_2` 是二元熵函数；右端为负时按平凡的 `L>=0` 理解。特别地，对全目标族
`F={0,1}^k`，有

```text
L >= (1-H_2(eta)) k.
```

`eta=0` 时恢复 exact target-channel 界 `L>=log_2|F|`。

更精细地，若对每个目标词和每个坐标都有坐标误差上界 `eta_i<1/2`，即

```text
Pr_R[E(omega_f;R)_i != f_i] <= eta_i,
```

则同一证明给出

```text
L >= log_2 |F| - sum_i H_2(eta_i).
```

主定理是 `eta_i` 的平均值不超过 `eta` 时由熵函数凹性得到的对称化版本。这个坐标
加权形式更适合审查 distributional soundness：少数坏坐标不能被误写成全词平均界，
必须把它们的熵预算显式计入。

## 证明

对每个摘要 `omega`，令 `F_omega` 是被该摘要以平均误差至多 `eta` 产生的目标词
集合。显然 `F` 是至多 `2^L` 个这样的集合的并。

固定非空的 `F_omega`，令 `F` 在其上均匀取值，并令 `Y=E(omega;R)`。因为 `R` 与
均匀选择的 `F` 独立，

```text
E[dist_H(F,Y)] <= eta * k.
```

写 `p_i=Pr[F_i=1]`、`q_i=Pr[Y_i=1]`、
`e_i=Pr[F_i != Y_i]`。对固定 `p_i`，`e_i` 随 `q_i` 在区间
`[min(p_i,1-p_i), max(p_i,1-p_i)]` 内变化。因此

```text
min(p_i,1-p_i) <= min(e_i,1-e_i) =: d_i <= 1/2.
```

均匀 `F` 的熵满足

```text
log_2 |F_omega| = H(F)
    <= sum_i H_2(p_i)
    = sum_i H_2(min(p_i,1-p_i))
    <= sum_i H_2(d_i)
    <= k H_2( (sum_i d_i)/k )
    <= k H_2(eta).
```

最后一步用 `sum_i d_i <= sum_i e_i <= eta k`；倒数第二步是二元熵在
`[0,1/2]` 上的凹性与单调性。于是

```text
|F| <= 2^L * 2^{k H_2(eta)},
```

取对数即得结论。

## 对 distributional soundness / ACRR 的含义

若一个 singleton-output bridge 把所有坐标共用的 static key 和有限的共同策略摘要
压成 `L=s+r` 比特，并且其 randomized evaluator 对每个目标词达到平均错误率
`eta<1/2`，那么目标族大小为 `2^k` 时必须支付

```text
s+r >= (1-H_2(eta)) k.
```

这把 note 175 的三分进一步量化：

1. 支付至少线性的 target-channel 熵；
2. 保留没有有限摘要的交互策略，此时不能直接得到 deterministic JK seed；或
3. 允许不同坐标使用不同策略，退化为 `forall i exists tau_i`，重新产生 phantom word。

因此，distributional soundness 若声称在 `poly(n,log T)` 的共同摘要下覆盖一个
近乎全熵的 `k`-bit target family，且 `k` 大于该预算，则该接口直接不可能；无需先
假设 proof assignment 唯一。相反，若目标族本身只有 `M` 个词，精确界是
`L >= log_2 M-k H_2(eta)`，不能把它误读成所有 dPCP 的长度下界。

## 通信解释：这是 INDEX 的共同承诺版本

把目标词 `f` 看作 Alice 的输入，把 `omega_f` 看作在坐标 `i` 揭示前已经提交的
message，把 `i` 看作 Bob 的 INDEX 查询，则 `E(omega_f;R)_i` 是 Bob 的输出。上述
证明正是一个允许平均坐标错误的 one-way random-access-code 下界。它也说明了模型边界：

* 若 Merlin 在看到 `i` 之后才发送响应，INDEX 只需发送一个 bit；但这对应
  `forall i exists tau_i`，不是一个可供 JK 拼接的共同 word/seed。
* 若 Merlin 必须在所有坐标前提交同一摘要，便回到本定理的线性通信下界。
* 允许交互并不自动逃逸：必须明确交互发生在坐标揭示前还是之后，以及后续响应是否
  仍能定义一个 deterministic、word-consistent 的 parent seed。

因此，任何声称“用短 Merlin interaction 同时恢复所有坐标”的 ACRR 构造，都必须报告
其 INDEX 通信顺序；仅给出逐坐标的短响应不能替代共同承诺。

## 对顶级路线的精确筛选

对全 `k`-bit target family，`L=Theta(k)` 已经达到这个信息论界的量级。因此 C54
可以关闭“用 `o(k)` 的共同 key 同时承载所有输出坐标”的乐观路线，但不能单独推出
`Omega(k^2)` 的 proof-length lower bound；后者还需要证明每个坐标的额外 proof/robust
consistency 不能共享。近线性 dPCP 若已经支付 `Theta(k)` 的 message channel，C54
在该尺度上是紧的，真正的顶级障碍仍是：额外坐标鲁棒性是否必然触发 RLDC/LDC 型
超线性代价，或是否存在一种新的共享 target-binding 机制。

## 边界与非蕴含

* 该定理只限制**有限、共同、可编码的摘要**。若 Merlin response 是任意地址相关
  函数，或每个坐标可重新选择 response，`L` 没有定义，定理不适用；这正是需要另证
  word consistency 的交互逃逸。
* evaluator 可以是任意随机函数；没有使用其计算复杂度、局部查询数或 dPCP 图结构。
  因而这是 target-channel 的信息下界，不是 proof-length 或 alphabet 的一般下界。
* `eta` 是平均 Hamming 误差。若接口只保证某些坐标的错误率，必须先给出坐标集合的
  质量/覆盖条件，不能直接代入全词结论。
* 对单一固定 target (`|F|=1`) 该界为空；这与 RW 单实例量词的边界一致。要把它升级
  为 RLDC/LDC barrier，仍需 note 193 的 target-relative near-oracle code-family
  语义以及相应的 robust radius。

## 可证伪的下一步

要把此结果晋级为一般性编码障碍，必须证明一个候选 near-linear dPCP/PCPP 的共同
strategy summary 确实是 `o(k)`，同时其 target family 的有效熵为 `Omega(k)`；两者一旦
同时成立，定理给出直接矛盾。若 summary 为 `Theta(k)`，该路线只证明它支付了线性
target channel，不能再宣称超线性不可能性。若 summary 无法有限化，则应转向
interactive/JK-parent-closure 的独立分析，而不是把它暗中当作短 key。

## 来源与关系

* [singleton-output distributional-soundness bridge](175-singleton-output-distributional-soundness-bridge-2026-08-16.md)：`eta=0` 的 exact 界与量词边界。
* [radius-to-relaxed-LDC barrier](../../rw-jk-succinct-reconstruction/statements/radius-to-relaxed-ldc-barrier.md)：把 target-relative robust ACRR 另行编译为 relaxed LDC；本 note 不替代该 family-level 条件。
* [ACRR 顶级定理攻坚计划](189-top-tier-acrr-theorem-program-2026-08-16.md)：将本定理作为 distributional 路线的 target-channel 检验，而非局部 decoder 记数。
