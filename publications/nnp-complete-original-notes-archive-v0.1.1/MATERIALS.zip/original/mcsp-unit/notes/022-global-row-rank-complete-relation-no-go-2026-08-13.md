> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 全局行秩势在完整关系上的常数坍缩（2026-08-13）

本节给出 note 021 候选的最便宜判定：在完整关系
\(C=X\times Y\) 上，任意叶变量 \(\phi\)（允许有符号）都满足常数级目标上界。
因此 anti-thinning 只说明一个局部平均不能关闭，不产生 QA 下界。

## 势与对称性

令 \(m=|X|=3k-1\)、\(c=m/2\)，并令

\[
g(a)=a-c\left\lfloor a/k\right\rfloor,
\qquad 0\le a\le m.
\]

因为 (m=3k-1)，直接分段得到

\[
g(m-a)=-g(a).
\tag{1}
\]

对 (R=A\times B) 取

\[
K(R)=\lambda g(|A|)|B|.
\tag{2}
\]

它满足 QA 递归（见 note 021）。

## 取向配对与 K 消去

固定 affine parity \(\ell\)，写

\[
A_t=X\cap\ell^{-1}(t),
\qquad
B_t=Y\cap\ell^{-1}(t),
\qquad
a_t=|A_t|, b_t=|B_t|, n=|Y|.
\]

两个合法取向叶为

\[
R_0=A_0\times B_1,
\qquad R_1=A_1\times B_0.
\]

叶约束分别是

\[
\Phi(R_0)+\lambda g(a_0)b_1\le1,
\qquad
\Phi(R_1)+\lambda g(a_1)b_0\le1,
\tag{3}
\]

其中 \(\Phi(A\times B)=\sum_{(x,y)\in A\times B}\phi_{x,y}\)。由
\(a_1=m-a_0\) 与 (1)，

\[
g(a_1)=-g(a_0).
\]

将 (3) 的第一式乘 (b_0/n)，第二式乘 (b_1/n)，并相加；两项 (K) 完全抵消：

\[
\frac{b_0}{n}\Phi(R_0)+\frac{b_1}{n}\Phi(R_1)\le1.
\tag{4}
\]

若 \(b_t=0\)，对应权重为零，(4) 仍成立。

## 均匀 affine parity 平均

令 \((r,b)\) 在 \(\mathbb F_2^{N+1}\) 均匀，\(\ell(z)=r\cdot z+b\)。
固定 cell \(c=(x,y)\)。其在 (4) 左端的系数为

\[
q_{x,y}=\mathbb E_\ell\left[
\frac{b_0}{n}\mathbf1_{\ell(x)=0,\ell(y)=1}
 +\frac{b_1}{n}\mathbf1_{\ell(x)=1,\ell(y)=0}
\right].
\tag{5}
\]

第一项中 \(b_0\) 不含 \(y\)，故展开 \(y'\in Y\setminus\{y\}\)：

\[
\mathbb E\left[b_0\mathbf1_{\ell(x)=0,\ell(y)=1}\right]
 =\sum_{y'\ne y}\Pr[\ell(x)=0,\ell(y)=1,\ell(y')=0].
\]

当 \(N\ge2\) 时，\(x,y,y'\) 两两不同；三条 affine 方程独立，因为三个 affine
lifts \((x,1),(y,1),(y',1)\) 在 \(\mathbb F_2^{N+1}\) 中无非平凡线性关系
（奇数个 lift 不可能相加为零，成对相等也被排除）。因此每项概率
\(2^{-3}=1/8\)。第二项完全相同，得到

\[
q_{x,y}=\frac1n\left(\frac{n-1}{8}+\frac{n-1}{8}\right)
=\frac{n-1}{4n}.
\tag{6}
\]

该系数与 \((x,y)\) 无关，故即使 \(\phi\) 有正有负，平均 (4) 仍给出

\[
\frac{n-1}{4n}\sum_{(x,y)\in X\times Y}\phi_{x,y}\le1.
\]

最终

\[
\boxed{
\sum_{c\in X\times Y}\phi_c
\le \frac{4n}{n-1}
\le 8\qquad(n\ge2).
}
\tag{7}
\]

这与 \(\lambda\) 无关；任何 \(\lambda\ge0\) 都不能使该全局行秩势在完整关系上产生超常数 QA 目标。

## 边界

若 \(n=1\)，上述配对平均退化；但此时只有一列，单点叶约束直接给

\[
\phi_{x,y}+\lambda g(1)\le1,
\]

故不能作为 MCSP 的大双侧关系。\(N=1\) 时不存在三点 \((x,y,y')\)，也是有限退化情形。

## 研究决定

候选 (2) 关闭：

\[
\text{anti-thinning}
\not\Rightarrow
\text{QA 下界};
\qquad
\text{取向配对+均匀 affine 平均}
\Rightarrow O(1).
\]

下一候选必须打破至少一个等式：

\[
K(A,B)=u(|A|)\,|B|,
\qquad g(m-a)=-g(a),
\qquad
\text{或两个取向叶可同时用于同一个消去。}
\]
