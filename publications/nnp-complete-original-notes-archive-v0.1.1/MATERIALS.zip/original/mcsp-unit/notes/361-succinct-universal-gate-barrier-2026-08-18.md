> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Succinct universal-gate barrier for generic Local-JK (2026-08-18)

## Proposition

Let \(q=2^m\), and let \(G_q:\{0,1\}^{q}\to\{0,1\}^{2q}\) be the
truth-table generator used by the RW/JK interface: a seed \(u\) encodes a
fan-in-two circuit \(C_u\) on \(m+1\) input bits, and
\[
G_q(u)[r]=C_u(r)
\]
for every output address \(r\). Assume the encoding supports all circuits with at
most \(q/(c m)\) gates for a fixed constant \(c\), as the standard gate-list
encoding does.

Call \(U:\{0,1\}^{m}\to\{0,1\}\) a succinct seed generator when \(U(\ell)=u[\ell]\)
and \(U\) has a size-\(\operatorname{poly}(m)\) circuit. Consider the problem
\[
\operatorname{SuccEval}_{G}(U,r):=G_q(u)[r].
\]
If \(\operatorname{SuccEval}_{G}\) has a uniform deterministic
\(\operatorname{poly}(m)\)-time algorithm on all succinct \(U\) and addresses \(r\),
then
\[
\mathrm{EXP}=\mathrm P.
\]
Consequently, unless \(\mathrm{EXP}=\mathrm P\), no generic address-scale
range-checker may evaluate \(G_q\) on an arbitrary succinctly generated preimage.

### Proof

Use the succinct circuit value problem. Its input is a polynomial-size circuit \(U_C\)
that, on a gate-list index, outputs the corresponding bit of a circuit \(C\) with
\(q/(c m)\) gates, together with an input \(r\); deciding \(C(r)\) is EXP-complete
under polynomial-time reductions. The standard padding version with
\(q/(c m)=2^{m}/(c m)\) gates is still EXP-complete.

From \(U_C\), use the fixed gate-list encoding to obtain a succinct seed generator
\(U\) for the \(q\)-bit description \(u_C\), padding unused description bits by zero.
By construction,
\[
\operatorname{SuccEval}_{G}(U,r)=G_q(u_C)[r]=C(r).
\]
A uniform \(\operatorname{poly}(m)\)-time algorithm for
\(\operatorname{SuccEval}_{G}\) would therefore solve succinct circuit value in
polynomial time, giving \(\mathrm{EXP}\subseteq\mathrm P\). The reverse inclusion is
trivial, while \(\mathrm P\ne\mathrm{EXP}\) follows from deterministic time hierarchy.
\(\square\)

## Consequence for the RW attachment

The proposition identifies a distinct Gate-I boundary. A recursive JK selector may not
be treated as an arbitrary address-scale word and then ask a generic small verifier to
evaluate the truth-table generator on that word: that operation is an EXP-scale
succinct computation, and \(P=NP\) does not collapse EXP to P.

The positive escape is narrower and testable:

1. the selector must restrict seeds to a syntactic subclass whose gate values are
   locally evaluable without invoking generic succinct circuit value; or
2. the construction must replace exact \(G_q\)-evaluation by a new relation/PCP
   predicate whose soundness survives at address scale.

This barrier is stronger than the streaming observation in C359 but still does not
rule out the actual RW-specific possibility: the canonical history may use a highly
structured seed subclass, and a selector may prove its \(G_q\)-identity
syntactically. It rules out only a black-box generic Local-JK physicalization for all
succinct preimages. In particular, \(P=NP\) alone is insufficient to justify that
physicalization.

## Source boundary

The RW source fixes \(G_q\) as a universal truth-table generator and gives explicit
\(q\)-scale range queries. The EXP-completeness input above is the standard succinct
circuit-value reduction applied to that universal encoding. The result is not a lower
bound on a restricted actual selector and is not a \(P\ne NP\) theorem; it isolates the
new structure any successful address-scale selector must provide.
