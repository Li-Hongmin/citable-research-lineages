> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Choice-robust JK removes the lex-first easy-branch obstacle (2026-08-18)

## Theorem

Let
\[
G:\{0,1\}^{q}\to\{0,1\}^{2q},
\qquad
G(x)=G_0(x)G_1(x),
\]
and let \(f'\in\{0,1\}^{q2^h}\). Run the Jeřábek--Korten recursion on
\(y_h=f'\): at level \(i\), split \(y_i\) into \(2^{i-1}\) blocks
\(z_{i,j}\in\{0,1\}^{2q}\). If \(z_{i,j}\in\operatorname{Range}(G)\), choose
*any* word
\[
x_{i,j}\in G^{-1}(z_{i,j})
\]
and concatenate these choices to form \(y_{i-1}\).

Then exactly the following alternatives hold:

1. some encountered \(z_{i,j}\notin\operatorname{Range}(G)\), which is already a valid
   Range-Avoidance output; or
2. all encountered blocks are in the range, and the resulting root \(y_0\) satisfies
   \[
     f'=G^{\otimes 2^{h-1}}\!\circ\cdots\circ
        G^{\otimes 2}\!\circ G(y_0).
   \]

In the second case, hardwiring \(y_0\) gives a circuit for every bit of \(f'\) of size
\[
O\!\left(h(|G|+q)\right).
\tag{360.1}
\]
No lexicographic minimality, repeated-block consistency, or common preimage across
different occurrences is used.

### Proof

At level \(i\), the definition of \(y_{i-1}\) gives, block by block,
\[
  G(x_{i,j})=z_{i,j}.
\]
Therefore \(y_i=G^{\otimes 2^{i-1}}(y_{i-1})\). Induction from \(i=1\) through \(h\)
gives the displayed composition. To compute a requested output bit, hardwire \(y_0\),
follow the \(h\) address bits through the corresponding \(G_0\) or \(G_1\) branch, and
apply the final fixed coordinate selector. Duplicating the circuit for \(G\) at each level
gives (360.1). If a block is outside the range, the first such block is an explicit
AVOID witness. \(\square\)

## Selector consequence

A replacement for the published lex-first selector therefore needs only a single
word-level condition. A fixed selector
\[
S(i,j,z,\ell)\in\{0,1\},\qquad \ell\in[q],
\]
is sufficient if, on every actual range occurrence, the word
\[
u_{i,j,z}:=S(i,j,z,1)\cdots S(i,j,z,q)
\]
satisfies \(G(u_{i,j,z})=z\). Bitwise statements of the form
\(\forall\ell\,\exists u_\ell\) are not sufficient: they may splice bits from different
preimages and fail the displayed identity.

The selector may depend on the occurrence; it need not be canonical or equal on two
occurrences carrying the same \(z\). If it uses smart promise queries, the actual
execution still needs the usual promise guarantee, and the same answers must define the
single word \(u_{i,j,z}\) for all \(\ell\).

## RW consequence and boundary

The locally uniform tableau selector from note 082 can therefore replace lex-first
choices on the systematic output blocks for which its time-dominating hypothesis holds.
This removes lex-first canonicalization as a separate Gate-I obstruction. It does **not**
provide selectors for the remaining
\[
\text{non-systematic Reed--Muller coordinates}
\;\longrightarrow\;
\text{auxiliary PCP oracles}
\;\longrightarrow\;
\text{recursive JK blocks}.
\]
Those blocks may have generation time polynomial in the full output scale, and the
time-to-circuit condition used by note 082 need not hold at the available \(q\)-scale.
Replacing their selectors can also change the first level at which a non-range block
appears; the modified history remains a valid easy/hard dichotomy, but a proposed
RW smart reconstruction must separately prove that its selected branch is executable
and smart.

Thus the precise remaining Gate-I target is:
\[
\boxed{\text{one word-consistent, address-scale selector for every actual
auxiliary/recursive block, or a JK variant that verifies such selectors locally}.}
\]
This theorem is a positive simplification of the attachment problem, not a \(P\ne NP\)
proof and not a general dPCP impossibility theorem.

## Source boundary

The recursion identity is the easy-branch argument in Jeřábek--Korten and in
Ren--Williams Theorem 3.1; the selector formulation and the systematic-block
time-dominating construction are recorded in notes 082--083. The present statement
only removes lexicographic minimality from the circuit-size argument; it does not claim
that the published RW completeness proof supplies the auxiliary selectors.
