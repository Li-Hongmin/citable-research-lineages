> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW/JK reconstruction-width and round-conservation barrier (2026-08-18)

## Proposition

Fix an instance \(x\) and a multi-output function

\[
  f(x)\in\{0,1\}^{T}.
\]

Let \(G_k:\{0,1\}^{k}\to\{0,1\}^{2k}\) be an AVOID instance. Assume that the
RW Theorem 4.1 interface has the following source-level guarantee: if

\[
  \mathsf{Solve}_f(x,G_k)
\]

fails to output a string outside \(\operatorname{Range}(G_k)\), then for every
address \(j\in[T]\), \(\mathsf{Reconf}_f(x,j)\) outputs \(f(x)_j\), makes only
smart \(\mathsf{prMA}\) queries, and has deterministic work and query-description
length at most

\[
  L(k,r,\ell)^{c_R},\qquad
  L(k,r,\ell):=k+r+\ell+2,
  \qquad \ell=\lceil\log_2(T+1)\rceil,
\tag{363.1}
\]

for a fixed constant \(c_R\). Here \(r\) is the round/query-length parameter
of the source computation; the precise polynomial can be absorbed into \(c_R\).

Assume \(P=NP\). For the perfect-completeness prMA query format used by published
RW, [C387](387-rw-perfect-completeness-prma-collapse-2026-08-18.md) supplies a
promise-preserving deterministic simulator in time \(L^{c_C}\) on queries of
description length \(L\), via the \(\Sigma_2^P\) predicate
\(\exists w\,\forall r\,V(q,w;r)=1\). This source-specific statement does not
assert that arbitrary non-perfect-completeness promise problems collapse.

Then, on every length where \(\mathsf{Solve}_f(x,G_k)\) fails,

\[
  \operatorname{CC}(f(x))
  \le O\!\left(L(k,r,\ell)^{c_Rc_C}\right).
\tag{363.2}
\]

Consequently, if

\[
  \operatorname{CC}(f(x))>S,
\]

then every failed Solve call must pay

\[
  k+r+\log T
  =\Omega\!\left(S^{1/(c_Rc_C)}\right).
\tag{363.3}
\]

Equivalently, an address-scale attempt with
\(k+r+\log T=(\log T)^{O(1)}\) cannot enter the Reconf branch on a target
whose circuit complexity dominates every fixed polynomial in \(\log T\). On
such a target, the same interface must return an AVOID outsider instead.

## Proof

On a failed call, the source theorem gives a correct bit procedure
\(\mathsf{Reconf}_f(x,j)\) for every \(j\). Under \(P=NP\), the fixed-format smart
\(\mathsf{prMA}\) queries can be answered by the assumed deterministic simulator.
Substituting this simulator into the deterministic control of Reconf gives a
uniform address procedure for \(f(x)\) running in time

\[
  O\!\left(L(k,r,\ell)^{c_Rc_C}\right).
\]

The address has \(\ell\) bits; \(x\), \(k\), \(r\), and the failed-call parameters
are fixed at this length and can be hardwired. The standard time-to-circuit
simulation therefore gives (363.2). Rearranging yields (363.3). If the
left-hand side of (363.3) is violated, the failed branch contradicts the assumed
lower bound, so Solve must output an outsider. \(\square\)

## RW stable-stage corollary

In the published RW recurrence,

\[
  k=n_{i+1}=n_i^C,
  \qquad r_i=O(n_i),
  \qquad T_i=n_{i+1}=n_i^C
\]

on the stable tail. The natural Reconf evaluator consequently has

\[
  L_i=n_i^{\Theta(C)}
\]

up to the fixed polynomial exponents in the theorem, while the hard output
\(B_i\) has only the near-maximum lower bound

\[
  \operatorname{CC}(B_i)=\Omega\!\left(\frac{n_i}{\log n_i}\right).
\]

Thus (363.3) is satisfied by the published object-scale \(k_i\) and \(r_i\);
it does not produce a \(P/\mathrm{poly}\) contradiction. More sharply, if one
replaces \(k_i\) by \((\log T_i)^{O(1)}\) but leaves \(r_i=\Theta(n_i)\), the
round parameter alone prevents address-scale closure. If both \(k_i\) and
\(r_i\) are compressed to \((\log T_i)^{O(1)}\), then a failed Solve branch is
ruled out by (363.3) on the same hard table; the only remaining outcome is the
successful AVOID branch, which supplies no reconstruction of \(B_i\).

For the padded RW function \(f_i\) whose first \(2n_i\) bits are \(B_i\), the
same lower bound transfers up to \(O(\log T_i)\) address-gadget overhead: a circuit
for \(f_i\) restricts to a circuit for \(B_i\) after zero-padding the address. Hence
the corollary applies to the actual \(f_i\), not merely to an abstract target.

## Consequence for the Closure program

C363 closes a tempting but invalid positive move:

> choose a very small child width \(k\), invoke Reconf, and claim an
> address-scale evaluator for the previous hard table.

On a hard target, the small-\(k\) call cannot fail; if it does fail, it already
forces the target into a small circuit by (363.2). A successful call instead
returns a new Range-Avoidance outsider and does not expose the old table. Thus
an actual RW Closure proof must do one of the following:

1. prove a stronger-than-near-maximum lower bound that exceeds the published
   object-scale simulator;
2. prove a new address-scale selector that is not obtained from a failed
   Reconf call; or
3. derive a new semantic consequence from the successful AVOID branch.

The theorem is a source-specific scale barrier. It is not an unconditional
\(P\ne NP\) proof, does not say that all AVOID calls succeed, and does not rule
out a future RW-specific selector or a stronger forcing theorem.

## Sources

* Ren--Williams, ECCC TR26-118, Theorem 4.1 and its proof, especially the
  Reconf guarantee and the poly(k,r,log t) budget:
  <https://eccc.weizmann.ac.il/report/2026/118/>.
* The project extraction of the source theorem:
  units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md,
  pages 14--18.
* The object-scale correction and five-way audit: notes 357--358.
