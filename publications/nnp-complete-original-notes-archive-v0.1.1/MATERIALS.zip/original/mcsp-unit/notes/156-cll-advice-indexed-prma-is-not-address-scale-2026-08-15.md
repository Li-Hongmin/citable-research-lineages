> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# CLL 的 advice-indexed prMA bit-query 仍不是地址尺度接口（2026-08-15）

## 精确正向编译

设 CLL Theorem 1.3 在长度 \(N\) 的正确 advice \(\alpha_N\) 下输出 canonical
字符串 \(x_N\)。其 conformity/resiliency 语义可写成

\[
\exists\tau_N:\Pr[A^{\tau_N}(1^N,\alpha_N)=x_N]=1,
\tag{1}
\]

以及

\[
\forall\tau,
\Pr[A^{\tau}(1^N,\alpha_N)\in\{x_N,\bot\}]\ge 2/3.
\tag{2}
\]

对地址 \(a\in[N]\) 和 bit \(b\in\{0,1\}\)，定义 verifier

\[
V_{N,a,b}(\tau,r)=1
\iff
A^{\tau}(1^N,\alpha_N;r)=z\ne\bot
\ \land\ z_a=b .
\tag{3}
\]

若 \(b=x_N[a]\)，策略 \(\tau_N\) 使 (3) 的接受概率为 1。若
\(b\ne x_N[a]\)，由 (2)，任意策略输出具有第 \(a\) 位为 \(b\) 的非 \(\bot\) 字符串的
概率至多 \(1/3\)。因此，在同一正确 advice 下，\(V_{N,a,b}\) 给出一个合法的
promise-MA bit query：

\[
b=x_N[a]\Rightarrow\mathrm{YES},
\qquad
b\ne x_N[a]\Rightarrow\mathrm{NO}.
\tag{4}
\]

关键是 (1) 中的**同一个** \(\tau_N\) 对所有地址同时有效，所以逐位查询拼出的
\(N\)-bit 字符串没有 phantom word。若只有

\[
\forall a\ \exists\tau_a
\]

而没有 \(\exists\tau\ \forall a\)，则结论不成立：两种策略分别只输出
\((0,1)\) 与 \((1,0)\) 时，每个地址都可找到局部策略，却不存在输出目标
\((0,0)\) 的统一策略。

## 为什么这仍不是 RW 的 smart-prMA 接口

式 (3) 把 \(\alpha_N\) 当作协议的固定外部参数。因此它给出的是
**advice-indexed** 的 prMA 查询，而不是自动给出 \(E^{\mathrm{prMA}}/1\)：

1. 若把 \(\alpha_N\) 显式写入 query，query 描述长度至少为
   \(|\alpha_N|+O(\log N)\)。CLL 的长度为
   \[
   |\alpha_N|=2^{(\log N)^{1/k}},
   \tag{5}
   \]
   因而在基尺度 \(n=\log N\) 时为 \(2^{n^{1/k}}\)，不是 \(\operatorname{poly}(n)\)。
2. 若把 \(\alpha_N\) 作为外部 advice，则得到的是带
   \(2^{(\log N)^{1/k}}\)-bit advice 的协议，而不是 `/1`。不能让 Merlin 任意提供
   \(\alpha_N\)：对错误 advice \(\beta\)，resiliency 只保证存在某个
   \(y_{N,\beta}\) 使输出落在 \(\{y_{N,\beta},\bot\}\)。若
   \(y_{N,\beta}[a]=0\)，则 bit-1 查询被拒绝；若为 1，则 bit-0 查询被拒绝，二者
   甚至可能都拒绝。这种 partial single-valuedness 不给出一对总的 promise-bit queries，
也不保证错误 advice 有同一完备策略。

更一般地，若存在统一确定性 decoder \(D_N(a,\sigma)\mapsto W\)，且一个 generic tailored-property compressor 用长度至多 \(A\) 的 advice 和
长度至多 \(S\) 的**静态、有限编码**公共 strategy summary，要求对每个
\(W\in\Pi_G[N]\) 逐词恢复所有叶及自由位，则

\[
(a,\sigma)\longmapsto W
\quad\text{必须是单射},
\qquad
A+S+O(1)\ge \log_2|\Pi_G[N]|.
\tag{6}
\]

所以把信息从 advice 移到 Merlin strategy 只改变存放位置，不消除 entropy floor。这个
计数不适用于 CLL 只挑选一个 canonical \(W_N\) 的情形；在那里真正需要证明的是该
canonical strategy 是否有短、可统一生成的 summary。

还要区分 promise 极性：\(B_j\notin R_q\) 只是
\(\forall u\,G_q(u)\ne B_j\) 的 coNP/NO 事实，并不提供一个 Merlin 的 YES witness。
CLL 的 Merlin strategy 是生成 \(W_N\) 内容的对象，与证明 leaf 为 outsider 的
range-witness 对象不是同一个量词；不能把二者直接合并。

3. verifier 还需模拟 CLL 算法；Theorem 1.3 只给出运行时间/电路大小的准多项式上界
   \[
   T(N)=2^{(\log N)^{O(k)}}
   \tag{7}
   \]
   而不是一个地址尺度的多项式上界。若 \(N=\operatorname{poly}(n)\)，该保证仍只是
   准多项式；若要叶宽
   \(q\asymp 2^n\)，则 \(N\ge 2q\)，整叶输出本身已有 \(\Omega(2^n)\) 成本。

因此 CLL 确实提供了一个语义上的按位 prMA 编译，但没有提供地址尺度的统一 compiler、
短 advice 或 `/1` promise family。该缺口不是“逐位策略不一致”这一单一问题，而是

\[
\boxed{
\text{single-strategy word consistency 已有；}
\quad
\text{advice compression + address-scale verifier 仍未知。}
}
\tag{8}
\]

## 一个不依赖 \(P=NP\) 的三分障碍

在命中长度取一个 leaf \(B_j\notin R_q\)，并假设 coverage 给出
\(\operatorname{CC}(B_j)>s(q)\)。以下三项不能同时成立：

1. 地址编码和 verifier 大小均为 \(\operatorname{poly}(n+\log q)\)；
2. 所有地址共用一个 word-consistent strategy，其 response function
   \(\tau_N(j,\ell,r)\) 有统一的 \(\operatorname{poly}(n+\log q)\)-时间/电路 decoder
   从 summary 生成；
3. 存在直接输出 bit 的 verifier（或可判定 0/1 的双边 perfect-complete 协议），
   对所有随机串 \(r\) 都输出 \(B_j[\ell]\)。仅有单个 one-sided \(b=1\) 查询时，NO 位
   没有完备 witness，不能直接复合成 bit evaluator。

事实上固定 \(r=0\)，把 verifier 与 strategy circuit 复合，就得到一个
\(\operatorname{poly}(n+\log q)\)-size evaluator for \(B_j\)，与
\(\operatorname{CC}(B_j)>s(q)\) 矛盾（当 \(s(q)\) 超过该多项式时）。因此任何成功路线
必须让 strategy response 没有低尺度可计算描述、放弃 word consistency，或保留
\(q\)/准多项式查询尺度。CLL Theorem 1.3 只保证存在 strategy，不给第 2 项；
这正是当前剩余接口的结构性断点。

## 对 \(P\) vs. \(NP\) 路线的含义

若另行证明一个统一 compiler，能在 \(\operatorname{poly}(n)\) 时间产生 (3)，其 advice
长度为允许的 `/1` 或 \(\operatorname{poly}(n)\) 规模，且 \(q(N)\le\operatorname{poly}(n)\)，
则 note 121 的 smart-prMA 充分条件可直接应用；在 coverage 排除相同尺度的 leaf
truth tables 时，\(P=NP\) 会导致矛盾。

当前 CLL Theorem 1.3 只证明 (1)--(2) 的 advice-indexed 版本，不能直接推出
\(P\ne NP\)。

来源：Chen--Li--Liang, *Maximum Circuit Lower Bounds for Exponential-Time Arthur
Merlin*, ECCC TR24-182 revision 2, Theorem 1.3；原文核验日期 2026-08-15：
<https://eccc.weizmann.ac.il/report/2024/182/>。
