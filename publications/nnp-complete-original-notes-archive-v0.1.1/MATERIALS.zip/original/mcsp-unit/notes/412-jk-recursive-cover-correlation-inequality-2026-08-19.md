> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK recursive range-cover 的 tree-correlation 不等式（2026-08-19）

## 本轮改变的判断

C402 的乘法容量界只处理 product-rich family：若所有叶 tuple 都能同时递归
保持 in-range，则叶 family 的总 entropy 不得超过 \(k\)。这里把它提升为一个
分布版本，允许叶 blocks 之间已有任意相关性，并精确量化这种相关性必须达到的
规模：

\[
  \text{leaf entropy}
  \;-\;
  \text{conditional total correlation}
  \;\le\; k.
\]

因此，若每个 non-output leaf 保留高熵，任何共同 \(G_k\) 的 exact recursive
range-cover 都必须携带 tree-scale correlation。条件独立只是该定理的零相关特例；
它不是一个可以免费绕过 C402 的 global relation。

## 设置

固定

\[
  G:\{0,1\}^{k}\to\{0,1\}^{2k},
  \qquad R=\operatorname{Range}(G),
\]

并固定 JK 使用的 canonical right inverse

\[
  p:R\to\{0,1\}^{k},
  \qquad G(p(z))=z.
\tag{412.1}
\]

令 \(\mathcal T_d\) 是深度 \(d\) 的完整二叉树，叶集合为
\(\mathcal L\)，\(|\mathcal L|=m=2^d\)。随机叶 tuple

\[
  L=(L_v)_{v\in\mathcal L}
\]

的每个 \(L_v\) 都是 \(2k\)-bit block。对内部节点递归定义

\[
  W_v:=p(W_{v0})\Vert p(W_{v1}),
\tag{412.2}
\]

其中 \(W_v=L_v\)（叶节点），并要求所有内部节点的 \(W_v\) 都属于 \(R\)。
这个要求就是 exact recursive range-cover。允许同时存在一个任意 policy 变量
\(S\)；假设对几乎所有 \((L,S)\)，该递归定义在整棵树上成立。

## 定理 412.1（recursive-cover tree-correlation inequality）

在上述设置下，对二进制熵和条件 total correlation，有

\[
  \boxed{
  \mathbb E\!\left[\operatorname{TC}_2(L\mid S)\right]
  \ \ge\
  \sum_{v\in\mathcal L} H_2(L_v\mid S)
  \;-\; k .
  }
\tag{412.3}
\]

更强地，对每个 policy 值 \(s\)，只要该 \(s\)-fiber 上的递归 range-cover
几乎处处成立，就有

\[
  \operatorname{TC}_2(L\mid S=s)
  \ge
  \sum_{v\in\mathcal L}H_2(L_v\mid S=s)-k.
\tag{412.4}
\]

因此，若每个叶在每个 good policy fiber 上满足

\[
  H_2(L_v\mid S=s)\ge h_v,
\]

则

\[
  \operatorname{TC}_2(L\mid S=s)
  \ge
  \sum_{v\in\mathcal L}h_v-k.
\tag{412.5}
\]

### 证明

由 \(G(p(z))=z\)，\(p\) 在 \(R\) 上是 injective：若
\(p(z)=p(z')\)，则 \(z=G(p(z))=G(p(z'))=z'\)。

定义从叶 tuple 到 root block 的映射 \(\Phi_d\)。深度 \(1\) 时，

\[
  \Phi_1(a,b)=p(a)\Vert p(b)
\]

在 \(\mathcal L\)-tuple 上是 injective，因为左右两个 \(k\)-bit half 分别确定
\(p(a)\) 与 \(p(b)\)，再由 \(p\) 的 injectivity 确定 \(a,b\)。假设
\(\Phi_{d-1}\) 在两个子树上 injective；根的两个 \(k\)-bit half 分别是左右子树
root 的 canonical preimage，因此根 block 确定两个子树 root，再由归纳假设确定
全部叶 tuple。于是 \(\Phi_d\) injective。

在每个 \(S=s\) 的 fiber 上，root \(W_{\varnothing}\) 落在
\(R\)，故其取值数至多 \(2^k\)，从而

\[
  H_2(L\mid S=s)
  =H_2(W_{\varnothing}\mid S=s)
  \le \log_2|R|
  \le k.
\tag{412.6}
\]

由 total-correlation 定义

\[
  \operatorname{TC}_2(L\mid S=s)
  =\sum_{v\in\mathcal L}H_2(L_v\mid S=s)
   -H_2(L\mid S=s),
\]

代入 (412.6) 即得 (412.4)。对 \(S\) 平均得到 (412.3)，再用
\(H_2(L_v\mid S=s)\ge h_v\) 得 (412.5)。证毕。

## 近似 recursive cover

若 exact closure 只在一个事件 \(E\) 上成立，且

\[
  \Pr[E^c\mid S=s]\le\delta_s,
\]

则同一证明给出保守的近似版本

\[
\operatorname{TC}_2(L\mid S=s)
\ge
\sum_{v\in\mathcal L}H_2(L_v\mid S=s)
-h_2(\delta_s)
-(1-\delta_s)k
-2km\,\delta_s.
\tag{412.7}
\]

事实上，令 \(E\) 为所有内部 nodes 都在 \(R\) 的事件。条件于 \(E\)，root
injectively determines all leaves，故 \(H(L\mid S=s,E)\le k\)；条件于 \(E^c\)，
粗略地 \(H(L\mid S=s,E^c)\le2km\)。于是

\[
H(L\mid S=s)
\le h_2(\delta_s)+(1-\delta_s)k+2km\delta_s,
\]

代回 total correlation 即得 (412.7)。该版本在
\(\delta_s=o(1/m)\) 时退化为 exact bound 的同阶形式；若失败概率大于此尺度，
不能把 approximate cover 自动当成 closure。

## 三个直接推论

### 1. 条件独立 leaves 的容量界

若在每个 good policy fiber 上 leaves 条件独立，则
\(\operatorname{TC}_2(L\mid S=s)=0\)，所以

\[
  \sum_{v\in\mathcal L}H_2(L_v\mid S=s)\le k.
\tag{412.8}
\]

当所有 \(m\) 个 leaves 都有熵至少 \(h\) 时，\(mh\le k\)。这严格恢复 C402 的
product-capacity 结论；C402 的 support-counting 是 (412.8) 的均匀分布特例。

### 2. 高熵 leaves 必须有 tree-scale joint coupling

若 \(m\) 个 leaves 每个保留至少 \(h\) bits 条件熵，且
\(mh>k\)，则任何 exact recursive cover 都满足

\[
  \operatorname{TC}_2(L\mid S=s)\ge mh-k.
\tag{412.9}
\]

特别地，若 \(m=\Theta(k)\) 且每个 leaf 有 \(\Omega(k)\) bits entropy，则
required correlation 是 \(\Omega(k^2)\)；若只保留一个固定数量的高熵 leaves，
则至少支付超出 root capacity 的总熵。

### 3. RW/Harsha Gate-I 的解释

把 \(L_v\) 取为 canonical proof 的 non-output recursive blocks。若一个 proposed
\(H_{\rm wit}\) 同时声称：

* 每个 leaf block 在同一个 \(G_k\) range 内；
* 每个 lower-level preimage 拼接仍在该 range 内；
* policy/descriptor 只带地址尺度信息；

那么 (412.5) 要求这些 blocks 的 conditional joint law 本身携带
\(\sum h_v-k\) 的相关性。因而“每个区段都有短描述”并不足够；短描述还必须在
整个 JK tree 上提供足够的 cross-leaf coupling。

如果 leaves 在给定 target 与 policy 后是独立生成的，(412.8) 直接排除高熵
recursive cover。如果它们不是独立的，则该相关性正是一个新的 global relation
resource，必须另外说明它如何在同一个 proof/address space 中被生成、验证并保持
same-parent binding；不能把它算作免费的 canonical preimage。

### 4. Systematic-witness entropy test

还可以把 leaf entropy 直接连接到 RW 的 canonical witness。设 \(X\) 是一个
source family，\(\alpha_X\) 是 Theorem 3.5 所选的 canonical satisfying assignment。
若在每个 policy fiber 上，non-output leaf tuple \(L\) 能确定 \(\alpha_X\)，即存在
一个确定函数

\[
  \alpha_X=\psi(L),
\tag{412.10a}
\]

并且

\[
  H_2(\alpha_X\mid S=s)\ge h_{\mathrm{wit}},
\]

则

\[
  \operatorname{TC}_2(L\mid S=s)
  \ge h_{\mathrm{wit}}-k.
\tag{412.11}
\]

证明是
\(H_2(\alpha_X\mid S=s)\le H_2(L\mid S=s)\le k\) 与
\(\sum_vH_2(L_v\mid S=s)\ge H_2(L\mid S=s)\) 的合并，再代入
(412.4)。因此，只要 non-output systematic witness 保留超过 \(k\) bits 的
条件 entropy，recursive cover 就不能同时是条件独立的。

这个测试不把公开输入自动当作 hidden entropy：若 \(X\) 本身被 decoder 作为
metadata 读取，必须把 \(H(X)\) 计入 policy channel。它真正约束的是
target-oblivious common-proof family，或一个已经证明了 witness entropy 不由公开
context 免费提供的 source interface。

## 与现有闭合门的关系

* C402 是 Theorem 412.1 的 product/support 特例；
* C400/C401 只给出原始 ECC/代数区段的直接 block cover，不提供
  (412.2) 所需的 tree-wide correlation；
* C410 对 singleton 的 JK half-lift 电路成本负责；C412 说明即使不做
  singleton circuit compilation，recursive cover 本身也必须支付 entropy/correlation；
* C411 处理 global word 成功所需的 target-channel / residual-correlation 三分。
  C412 更窄：它把 residual correlation 定位到 JK recursive leaf tuple，而不是
  只对整个输出词做统计 accounting。

因此，当前 Gate-I 的真正三分可以写成：

\[
\text{low-correlation cover}
\;\Longrightarrow\;
\text{capacity failure},
\qquad
\text{high-correlation cover}
\;\Longrightarrow\;
\text{new global relation resource},
\qquad
\text{JK half-lift}
\;\Longrightarrow\;
\text{C410 circuit payment}.
\tag{412.10}
\]

本定理不证明 published RW singleton 的 leaf entropy 已超过 \(k\)，也不声称
所有 actual Harsha blocks 都满足独立性；它把这一未知量变成了一个有明确单位、
可从 source family 或 proof distribution 直接测量的参数。

## 证据边界

* JK 的 canonical preimage 递归与 injectivity：C402；
* actual Harsha proof 的区段/serialization 边界：C389、C397--C400；
* singleton parent-binding circuit cost：C410；
* global-relation residual-correlation accounting：C411。

这是一个 source-compatible recursive-cover entropy theorem，不是 \(P\ne NP\)
证明，也不是一般 dPCP/RLDC 不可能性。其价值在于把
\(H_{\rm wit}\) 的“递归 range closure”从一个布尔覆盖条件升级为一个必须支付的
correlation budget。
