> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 单边 Bernoulli thinning：静态势的一个局部 no-go 与真实缺口

## 1. 数值势的 Bernoulli 引理

设 (q\ge2)，(g(0)=g(q)=0)，并满足

\[
g(a+b)\le g(a)+g(b)\qquad(a,b\ge1, a+b\le q).
\tag{1}
\]

令 (gamma=g(1))。由把 (q) 写成 (q) 个 1 可知 (gamma\ge0)，并由归纳得

\[
g(k)\le k\gamma.
\tag{2}
\]

若 (2\le k\le q/2)，写 (q=ak+b)，(a=\lfloor q/k\rfloor\ge2)，(0\le b<k)。由 (1)--(2)，

\[
g(k)\ge-\frac ba\gamma\ge-\frac{2k^2}{q}\gamma.
\tag{3}
\]

若 (k>q/2)，由 (g(k)+g(q-k)\ge0) 得

\[
g(k)\ge-(q-k)\gamma\ge-q\gamma.
\tag{4}
\]

令 (S\sim\operatorname{Bin}(s,p))，(s<q)，(p\le1/(4q))。置 (mu=sp\le1/4)。则

\[
\Pr[S=1]=\mu(1-p)^{s-1}\ge\frac34\mu,
\qquad
\mathbb E S^2\le\mu+mu^2\le\frac54\mu.
\tag{5}
\]

并且令 (k_0=\lfloor q/2\rfloor+1)，阶乘矩给出

\[
q\Pr[S>q/2]
\le q\frac{\mu^{k_0}}{k_0!}
\le\frac1{16}\mu
\qquad(q\ge4).
\tag{6}
\]

由 (3)--(6)，

\[
\mathbb E g(S)
\ge\gamma\mu
\left(\frac34-\frac5{2q}-\frac1{16}\right)\ge0
\qquad(q\ge4).
\tag{7}
\]

(q=2,3) 直接由 (1) 检查。故

\[
\boxed{\mathbb E g(\operatorname{Bin}(s,p))\ge0\quad(p\le1/(4q), s<q).}
\]

若某 collision 超边 (h) 在一个 parity rectangle (A\times B_0) 中每个 (y) 至多出现一次，则随机取 (B\subseteq B_0)，独立保留概率 (p\le1/(4q_h))，其交点数正是上述二项分布；该超边的 (g)-势平均非负。

## 2. 端点重复是不能跳过的状态

一般 (h\subseteq X\times Y) 不是 column-simple 或 row-simple。即使 (h) inclusion-minimal，也可能两侧同时重复。例：在 (mathbb F_2^4) 中取

\[
h=\{(1,8),(1,4),(2,12),(3,12)\}.
\tag{8}
\]

其两端 affine hull 为

\[
\operatorname{aff}\{1,2,3\},
\qquad
\operatorname{aff}\{8,4,12\},
\]

交点为 (0)。删除任意一个 cell 后，两个 affine hull 分离；所以这是一个 inclusion-minimal 四元 collision，但 row/column 最大度均为 2。

因此在 (A\times B_0) 中同时独立抽取行、列时，边指示变量有正相关：共享行的两条边以 (p_Xp_Y^2) 同时保留，独立边仅以 (p_X^2p_Y^2) 保留。若只用最大端点度 (\Delta) 控制二阶矩，保守参数为

\[
p_X,p_Y\asymp\frac1{q\Delta},
\qquad
\Pr[(x,y)\text{保留}]asymp\frac1{q^2\Delta^2},
\]

只能得到 (O(q^2\Delta^2)) 型容量，而不是线性 (O(q))。

这种重复并非固定小例的偶然现象。令 (r) 为偶数，在
(mathbb F_2^{2r}=U\oplus V) 中取独立基
(e_1,\ldots,e_r) 与 (f_1,\ldots,f_r)，置

\[
a=\bigoplus_{j=1}^r e_j,
\qquad
c=\bigoplus_{j=1}^r f_j.
\]

构造 (2r) 个 cell

\[
h_r=\{(a,f_i):i\in[r]\}
\cup
\{(e_i,c):i\in[r]\}.
\tag{9}
\]

两端 affine hull 都经过 0，且由于 (U\cap V=\{0\}) 其交集仅为 0。删去第一组任一 cell 会删去 (f_i) 这一端的必需点；删去第二组任一 cell 会删去 (e_i) 这一端的必需点。因此 (h_r) 是 inclusion-minimal collision，而

\[
\Delta_X(h_r)=\Delta_Y(h_r)=r=|h_r|/2.
\]

这给出随维数增长的两端重复状态；任何只按“collision 最小”而不记录端点度谱的 thinning 论证都会在 (h_r) 上失效。

## 3. 一个可递归的 degree-profile 势

对任意固定 cell 图 (h\subseteq X\times Y)，令

\[
E_R=h\cap R,\qquad
u_R=|\pi_X(E_R)|,\qquad
v_R=|\pi_Y(E_R)|,
\]

空图时下式取 0，并设

\[
\Psi_h(R)=\frac{|E_R|^2}{u_Rv_R},
\qquad
\omega_h(R)=u_Rv_R.
\]

Cauchy--Schwarz 给出 Chukhin 型递归不等式：若 (R=V\mathbin{\dot\cup}W) 是横向或纵向二分，则

\[
\Psi_h(V)+\Psi_h(W)\ge\Psi_h(R).
\tag{10}
\]

同时 (\omega_h(V)+\omega_h(W)\le\omega_h(R))：横向二分时两个子图的列投影都包含于母列投影，纵向情形对称。因此令

\[
K_h(R)=\Psi_h(R)-
\frac{\Psi_h(C)}{\omega_h(C)}\,\omega_h(R)
\tag{11}
\]

就有

\[
K_h(V)+K_h(W)\ge K_h(R),
\qquad K_h(C)=0.
\tag{12}
\]

这是一个严格记录端点度谱的 quasi-additive 状态；它不再把 (h\cap R) 仅压成一个 cardinality。若 (h) 为 (q) 条边、两侧投影大小为 (u,v)，则

\[
K_h(R)=\frac{e_R^2}{u_Rv_R}-\frac{q^2}{(uv)^2}u_Rv_R.
\tag{13}
\]

尚待证明的单叶命题是：对 affine-parity monochromatic (R)，能否用 collision 条件给 (13) 一个统一的上界，或将正的高密度叶交给 Chukhin 式 projected-KW 第二势。式 (11) 是可直接接入 QA LP 的递归状态，且能承载 (h_r) 这样的两侧重复家族；它是绕开单纯 Bernoulli thinning 的最小候选。

## 4. 一个可关闭的 degree-density 子类

上面的线性版本实际上不能产生负单叶势。令 (G_h) 为 (h) 的 incidence graph，并假设 (h) inclusion-minimal。每条边至少有一个端点度为 1：若某边两端度均大于 1，删除该边不改变左右投影，故 affine hull 交点仍在，和极小性矛盾。因此 (G_h) 是 star forest。

把左中心星的边数总和记为 (A)，右中心星的边数总和记为 (B)，星的个数记为 (ell,r)。任意非空边诱导子图仍为 star forest；若其对应参数为 (A',B',ell',r')，则密度为

\[
D(A',B',\ell',r')
=\frac{A'+B'}{(\ell'+B')(A'+r')}.
\tag{14}
\]

因每个活动星至少保留一条边，(A'\ge\ell')、(B'\ge r')。在固定 ((\ell',r')) 下，

\[
\frac{\partial D}{\partial A'}
=\frac{r'-B'}{(\ell'+B')(A'+r')^2}\le0,
\qquad
\frac{\partial D}{\partial B'}
=\frac{\ell'-A'}{(\ell'+B')^2(A'+r')}\le0.
\]

加入一个未活动的左星先增大 (A') 再增大 (ell')，只会降低 (D)；右星同理。因此完整 (G_h) 的密度最小：

\[
\frac{|h\cap R|}{|\pi_X(h\cap R)|\,|\pi_Y(h\cap R)|}
\ge
\frac{|h|}{|\pi_X(h)|\,|\pi_Y(h)|}
\tag{15}
\]

对任意矩形 (R)，甚至不必使用 parity 条件。于是线性 degree-profile 势

\[
K_h(R)=|h\cap R|
-\frac{|h|}{|\pi_X(h)|\,|\pi_Y(h)|}
 |\pi_X(h\cap R)|\,|\pi_Y(h\cap R)|
\tag{16}
\]

满足 QA recursion（边计数可加，投影积次可加），且由 (15)

\[
\boxed{K_h(R)\ge0\quad\text{for every rectangle }R.}
\]

因此 Chukhin/Khrápchenko 风格的单图 density 状态在极小 collision 上只能给正势，不能提供负的 leaf compensation；若要逃逸，必须使用比 incidence graph density 更细的 affine-label 或 projected-KW 语义。

## 5. 第一个真正的 affine-label 状态

对固定超边 (h)，写每条 cell (e=(x,y)) 的 difference vector

\[
d_e=x\oplus y,
\qquad
\rho_h(R)=\operatorname{rank}_{\mathbb F_2}\{d_e:e\in h\cap R\}.
\]

若 (D_h=\{d_e:e\in h\})，令 (r_h=\operatorname{rank}D_h)，(m=|X||Y|)，定义

\[
K_h^{\mathrm{rank}}(R)=
\rho_h(R)-\frac{r_h}{m}|R|.
\tag{17}
\]

这是一个严格的 QA 状态：行/列二分时，向量秩满足

\[
\rho_h(V)+\rho_h(W)\ge\rho_h(R),
\]

而 (|V|+|W|=|R|)，故

\[
K_h^{\mathrm{rank}}(V)+K_h^{\mathrm{rank}}(W)\ge K_h^{\mathrm{rank}}(R),
\qquad
K_h^{\mathrm{rank}}(C)=0.
\tag{18}
\]

它记录 affine leaf 的真正标签约束：若 (R) 是由 (r\cdot x+b=t)、(r\cdot y+b=1-t) 定义的叶，则每条命中 cell 满足 (r\cdot d_e=1)，但这些 (d_e) 的秩可远低于命中数。因而 (17) 有机会在“多条命中、低 difference-rank”的叶上产生负势；此前所有 hit-count/density 势都看不到这一状态。

尚未证明的是如何选择 (h) 和权重使单叶正的低秩项不泄漏。若能构造 (h) 族满足

\[
\rho_h(R)\ll (r_h/m)|R|
\]

对大 affine-parity 叶同时成立，则 (17) 是一个可直接接入 QA LP 的随 (N) 增长候选；反之，对其取随机 affine 平均可给出 rank-capacity 上界。

## 3. 结论

单边 Bernoulli thinning 已关闭 column-simple/row-simple collision 的静态 (g)-势超线性路线；但两端重复的 collision 需要把端点度谱写入状态。这个缺口不能用“任意最小 collision 至少一侧简单”填补，式 (8) 是最小反例。
