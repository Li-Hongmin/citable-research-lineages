> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha binary address-scale evaluator forcing transfer (2026-08-19)

## 改变的判断

C485 的 binary-to-\(P\)-to-\(q\) 局部逆可以与 C459 的 published-output forcing
直接合并。因而在同一个 \(P=NP\) source-alignment 分支、同一 canonical proof 和同一
good-length 集合上，raw ZoS binary bit evaluator、\(\widehat C\)-evaluator 与 output
address map 的**总复杂度**必须支付 forcing scale；不能把二值化的 component access
当作一个免费的 address-scale Closure 接口。

## 设置

取 C455/C456 的无限 good-length 集合 \(\mathcal I\)。对 \(n\in\mathcal I\)，令
\[
 B_n=A'(1^n,a_n),\qquad N_n=|B_n|,\qquad
 \operatorname{CC}(B_n)\ge c\frac{N_n}{\log N_n}.
\tag{486.1}
\]

在 \(P=NP\) 的反证分支中，C456 的 source-compatible hist-first serialization
给出同一个 honest assignment polynomial \(q_n:F_n^{m_n}\to F_n\)，并在 aligned
systematic coordinates \(u_{n,j}\) 上满足
\[
 q_n(u_{n,j})=B_n[j].
\tag{486.2}
\]

令 \(Q_n=|F_n|\)、\(\lambda_n=\lceil\log_2Q_n\rceil\)、\(D_n=3m_n+3\)。假设：

1. C398 的 raw ZoS segment 使用公开 component-major flattening；
2. 同一个由 \(q_n\) 的 honest completion 生成的 canonical Harsha proof
   \(\Gamma(q_n)\) 有 exact arbitrary-bit evaluator，大小为 \(s_{{\rm bit},n}\)；
3. C439/C457 的 nondegenerate incidence、exact \(\widehat C\)-evaluator 和 field-size
   条件成立，记 \(s_{\widehat C,n}\) 为该 evaluator 大小，记
   \(s_{{\rm Inc},n}\) 为 incidence map 的完整电路大小；
4. output-address map \(j\mapsto u_{n,j}\) 的大小 \(s_{{\rm out},n}\) 被完整计价。

所有 evaluator 描述和非一致参数都计入相应电路大小，不另附 q-dependent ROM。

## 定理 486.1（raw-binary address-scale forcing transfer）

记
\[
 A_n^{\rm dec}:=\operatorname{poly}(D_n,\lambda_n)+O(|H_n|\mu_{F_n}),
 \qquad
 R_n:=s_{\widehat C,n}+s_{{\rm Inc},n}+s_{{\rm out},n}+1,
\tag{486.3}
\]
并令 \(K_n=K(m_n,Q_n)\) 为 C439/C446/C459 的有限域枚举、field arithmetic、
incidence 与 output-address 编译所需的显式多项式因子（可取
\(K_n=O(Q_n^3\operatorname{poly}(m_n,\log Q_n))\)）。在上述条件下，有
\[
\operatorname{CC}(B_n)
 \le
 K_n\bigl(2\lambda_n s_{{\rm bit},n}+A_n^{\rm dec}+R_n\bigr).
\tag{486.4}
\]

等价地，
\[
 s_{{\rm bit},n}\ge
 \frac{1}{2\lambda_n}
 \left[
   \frac{\operatorname{CC}(B_n)}{K_n}
   -A_n^{\rm dec}-R_n
 \right]_+.
\tag{486.5}
\]
若 \(K_n,A_n^{\rm dec},R_n,\lambda_n\) 都是
\(\operatorname{polylog}N_n\)，并且 \(A_n^{\rm dec}+R_n\) 小于
\(\tfrac12\operatorname{CC}(B_n)/K_n\)，则
\[
 s_{{\rm bit},n}=\Omega\!\left(\frac{N_n}{\operatorname{polylog}N_n}\right).
\tag{486.6}
\]
特别地，不存在 \(\operatorname{polylog}N_n\)-size 的 exact arbitrary-bit evaluator
来完成该 source-aligned raw ZoS segment。更一般地，即使不满足这些 polylog 假设，(486.4)
仍给出 bit evaluator、constraint evaluator、incidence map 与 output map 四者的
forcing-scale 总下界。

### 证明

C485 的推论 485.2 在同一 \(\Gamma(q_n)\) 上把 \(O(Q_n^3\lambda_n)\) 次 raw proof-bit
reads 和 bit evaluator 编译为 exact \(q_n\)-evaluator；C446 将其与
constraint/incidence/output 电路统一计价，得到
\[
 \operatorname{CC}(B_n)
 \le K_n\bigl(2\lambda_n s_{{\rm bit},n}+A_n^{\rm dec}+R_n\bigr).
\tag{486.7}
\]
这就是 (486.4)；代入 (486.1) 得到 (486.6)。证毕。

## 对 Closure 的精确含义

* **raw-binary branch：** 若 bit evaluator、\(\widehat C\)、incidence 和 output map
  都是 address-scale，则 C486 直接把该分支推入 forcing contradiction；它不能提供
  \(P/\mathrm{poly}\) closure。
* **object-scale/global-relation branch：** 若 (486.4) 由 \(\widehat C\)、incidence、
  descriptor、q-dependent ROM 或 non-product global relation 支付，则必须把该成本显式保留；不能
  继续称为纯 binary component extraction。
* **ECC-only/near-proof branch：** C486 不覆盖删除 raw \(\Gamma\) 的 partial view、
  arbitrary near proof、bounded-error/approximate recovery，或改变 same-proof 量词的接口。

这把 C485 的局部逆提升为一个 source-aligned 的复杂度闭合定理，但仍不是无条件的
\(P\ne NP\) 证明：它依赖 \(P=NP\) 反证分支、C453--C456 的 replacement serialization、
C439/C457 的 factorized interface 以及 C459 的 infinitely-often forcing lengths。

## 来源

* [C485：Harsha binary raw-segment local inverse](485-harsha-binary-raw-segment-local-inverse-2026-08-19.md)。
* [C459：published RW generic \(q\)-access forcing](459-published-rw-generic-q-access-forcing-scale-2026-08-19.md)。
* [C456：published RW output/source alignment](456-published-rw-output-source-alignment-and-direct-scale-boundary-2026-08-19.md)。
* C439、C446、C453、C454、C455、C457。
