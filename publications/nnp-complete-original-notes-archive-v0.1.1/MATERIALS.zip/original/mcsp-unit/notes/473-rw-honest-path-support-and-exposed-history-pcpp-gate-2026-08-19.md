> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW honest-path support forcing and the exposed-history PCPP gate (2026-08-19)

## 结论

C471 对同一个 physical proof 上的 adaptive evaluator 使用了所有可能
proof-answer branches 的 union support。对 singleton forcing，这个集合可以严格缩小：
只需保留真实 proof 上、遍历所有输出地址时实际经过的 query positions。按真实执行路径归纳，
ROM 展开仍然逐步一致。

因此，对 C455 的 hard output \(B_n\in\{0,1\}^{N_n}\)，任何 address-scale
single-valued decoder 的 honest-path support 已经满足

\[
  L_n^{\rm act}
  =\Omega\!\left(
    \frac{N_n/\log N_n-g_n}
         {q_n(\ell_n+a_n)}
  \right).
  \tag{473.1}
\]

把这一点用于 C183 的 exposed-history PCPP+RLDC：其 \(R_n\) 个互不相交 output-code
copies 各自都能 clean-decode 同一个 \(B_n\)，故在 address-scale control 下

\[
  |U_n^{\rm act}|
  \ge
  \sum_{s=1}^{R_n}L_{n,s}^{\rm act}
  \ge
  \frac{R_n\,2^{\Omega(m_n)}}{\operatorname{poly}(m_n)},
  \qquad
  m_n=\lceil\log_2(N_n+1)\rceil .
  \tag{473.2}
\]

所以 ordinary exposed-history PCPP/robust-PCPP composition 不能借“每次只读常数个
proof symbols”得到 address-scale union support。它必须在 decoder control、address/
alphabet、honest support 或 physical proof 量词之一支付 object scale。

## Honest-path ROM 展开

固定

\[
  B\in\{0,1\}^{N},\qquad
  z\in\Sigma^{P},\qquad
  a=\lceil\log_2|\Sigma|\rceil,\qquad
  \ell=\lceil\log_2(P+1)\rceil .
  \tag{473.3}
\]

令确定性 adaptive evaluator \(D(j;z)\) 在每个地址 \(j\in[N]\) 上至多读取 \(q\)
个 proof symbols。把 proof answers 视为外部输入时，其 query-address generation、
finite control 与 output circuit 的 fan-in-two size 为 \(g\)。定义

\[
  L^{\rm act}(D,z)
  :=
  \bigcup_{j\in[N]}
  \{\text{\(D(j;z)\) 的真实执行中读取的 proof positions}\}.
  \tag{473.4}
\]

这里不并入在虚假 answer sequence 下才会到达的 proof positions。

## 定理 473.1（singleton honest-path support forcing）

若

\[
  D(j;z)=B[j]\qquad(\forall j\in[N]),
  \tag{473.5}
\]

则

\[
  \operatorname{CC}(B)
  \le
  O\!\left(
    g+q\,|L^{\rm act}(D,z)|(\ell+a)+\log(N+2)
  \right).
  \tag{473.6}
\]

特别地，在 C455 的同一 hard-length 集合上，

\[
  g+q\,|L^{\rm act}(D,z)|(\ell+a)+\log(N+2)
  =
  \Omega(N/\log N).
  \tag{473.7}
\]

若 \(g\le cN/(2\log N)\)，则

\[
  |L^{\rm act}(D,z)|
  \ge
  c'
  \frac{N/\log N-g}{q(\ell+a)}.
  \tag{473.8}
\]

### 证明

把 \(z[p]\)（\(p\in L^{\rm act}(D,z)\)）硬接为常量。每次 proof read 用
\(|L^{\rm act}|\)-项 address mux 实现，单次成本
\(O(|L^{\rm act}|(\ell+a))\)。

关键是证明该有限 ROM 足够。对任意固定 \(j\)，按 query step \(t\) 归纳。第一个
query address 只依赖 \(j\) 与固定 control，因此与真实执行相同，并由定义属于
\(L^{\rm act}\)。假设前 \(t-1\) 个 query 与 answers 均与 \(D(j;z)\) 相同，则第
\(t\) 个 address 也相同；它仍属于该真实执行的 support，mux 返回硬接的真实 symbol。
故归纳保持到终止，展开电路输出 \(B[j]\)。

控制、至多 \(q\) 个 mux 与输入 bookkeeping 合计给出 (473.6)。代入 C455 的
\(\operatorname{CC}(B)=\Omega(N/\log N)\) 得 (473.7)--(473.8)。证毕。

### 有限 public-tape 版本

若 \(t\) 条已固定 public tapes \(\rho_1,\ldots,\rho_t\) 的 acceptance threshold
逐地址恢复 \(B\)，令 \(L_s^{\rm act}\) 为 tape \(s\) 在真实 proof 上的
all-address actual support，则同一证明逐 tape 展开，给出

\[
  \operatorname{CC}(B)
  \le
  O\!\left(
    tg+
    q(\ell+a)\sum_{s=1}^{t}|L_s^{\rm act}|
    +t\bigl(\log N+\log(t+2)\bigr)
  \right).
  \tag{473.9}
\]

这比把每条 tape 都按同一个 full-branch union support 计价更精确。

## 推论 473.2（exposed-history output-copy support）

取 C183 的 output code

\[
  C_{\rm out}:\{0,1\}^{N}\to\Gamma^{M}
  \tag{473.10}
\]

及其 \(q_D\)-query relaxed decoder。假设 clean-codeword completeness 为

\[
  \Pr_\rho[
    \operatorname{Dec}(C_{\rm out}(y),j;\rho)=y_j
  ]=1
  \quad
  (\forall y\in\{0,1\}^{N},\ \forall j\in[N]).
  \tag{473.11}
\]

令 C183 proof 含

\[
  R=\lceil T/M\rceil
  \tag{473.12}
\]

个互不相交 copies \(c_s=C_{\rm out}(B)\)。从 decoder 的 finite uniform
random-tape support 中任取一个共同 tape \(\rho_0\)（在 uniform 模型中即任意 tape）。
由 (473.11)，每个正概率 tape 对每个有限 pair \((y,j)\) 都必须正确；故固定
\(\rho_0\) 后仍在 clean codeword 上逐地址精确输出。
令 \(L_s^{\rm act}\) 为所得 deterministic decoder 在 copy \(s\) 上的 all-address
actual support，decoder control size 为 \(g_D\)，code-symbol bits 为
\(a_D=\lceil\log_2|\Gamma|\rceil\)，proof-address bits 为 \(\ell_D\)。则在 C455
hard lengths 上，

\[
  g_D+
  q_D|L_s^{\rm act}|(\ell_D+a_D)+\log(N+2)
  =
  \Omega(N/\log N)
  \qquad(\forall s\in[R]).
  \tag{473.13}
\]

固定一个正概率 honest PCPP tape。对每个 \(s\in[R]\)，令 full verifier tape
\(\tau_s\) 使用这个 PCPP tape、copy selector \(s\) 与共同 decoder tape \(\rho_0\)，
并令 \(U^{\rm act}\) 为所有 \(s,j\) 对应 honest executions 的 actual-query union。
C183 中这三部分随机性独立组合；perfect completeness 保证每条 \(\tau_s\) 都通过
PCPP check 并到达 copy \(s\) 的 decoder。因此
\(L_s^{\rm act}\subseteq U^{\rm act}\)。由于 copies 的 physical address sets 两两不交，

\[
  |U^{\rm act}|
  \ge
  \sum_{s=1}^{R}|L_s^{\rm act}|.
  \tag{473.14}
\]

因此若

\[
  g_D,q_D,\ell_D,a_D=(\log N)^{O(1)},
  \tag{473.15}
\]

则

\[
  |U^{\rm act}|
  \ge
  \frac{RN}{(\log N)^{O(1)}}.
  \tag{473.16}
\]

PCPP auxiliary proof 和 constraint queries 只能增加 whole-proof support，不能减少
(473.16)。这里共同固定的是 decoder tape \(\rho_0\)，而不是一条同时选择所有 copies
的 whole-verifier tape；不同 \(s\) 使用只在 copy selector 上不同的 \(\tau_s\)。
relaxed output \(\bot\) 也无效，因为 (473.11) 在 clean codeword 上要求 exact output。

对 C456 对齐的 published RW object，\(N=2^{\Theta(m)}\)，而 C183 的 ordinary
near-linear proof regime 满足 \(\ell_D=O(\log T)=m^{O(1)}\)。故 (473.16) 即为
(473.2)。如果 \(g_D\) 本身不是 address scale，则路线已经在 control 中支付
object scale，而不是获得 Closure。

## Lemma 473.3（family full-branch entropy boundary）

对任意

\[
  C:\{0,1\}^{N}\to\Gamma^{M}
  \tag{473.17}
\]

和满足 (473.11) 的 decoder，令 \(S\subseteq[M]\) 为跨所有 \(j\)、所有 random
tapes 和所有可能 answer branches 的 query-position union。则

\[
  |S|\log_2|\Gamma|\ge N.
  \tag{473.18}
\]

事实上，若 \(C(y)|_S=C(y')|_S\)，则对每个 \(j\) 和 random tape，adaptive
transcript 按 step 归纳相同；clean exactness 迫使 \(y_j=y'_j\)。故
\(y\mapsto C(y)|_S\) 单射，计数得到 (473.18)。对 \(R\) 个 disjoint copies，
full-branch support 至少为 \(RN/\log_2|\Gamma|\)。

式 (473.18) 是 family statement。若 code domain 真正缩成 singleton
\(\{B\}\)，其 entropy lower bound 退化为零；不能把它冒充 singleton 证明。
singleton honest-path 结论来自 C455 forcing 与 Theorem 473.1，而不是 family entropy。

## 对 Closure 的决定

1. ordinary exposed-history PCPP+RLDC 已落入明确的 support/control payment：
   \[
     g_D\text{ object-scale}
     \quad\lor\quad
     |U^{\rm act}|\ge R\,2^{\Omega(m)}/\operatorname{poly}(m).
   \]
2. source restriction 不会缩小这一二分。限制到 published \(B_n\) 时不能再用 family
   entropy，但 C455 对同一个 singleton 的 forcing 正好替代它。
3. 自适应也不是逃逸：Theorem 473.1 只跟踪真实 proof 上的执行，不枚举虚假 branches。
4. 下一项正向候选必须删除显式 coordinate-code copies，或引入一个新的
   information-theoretic batch opening；普通 robust PCPP composition 不再值得展开
   query generator。

## 证据与文献边界

* C455 提供同一 published \(B_n\) 的 forcing lower bound；C456 在 \(P=NP\)
  反证分支把它与 source-compatible local tableau 对齐。
* C183 的 proof 明确含 \(R=\lceil T/M\rceil\) 个 output-code copies；本文只使用
  clean decoder，不使用 PCPP soundness。
* Gur--Minzer--Weissenberg--Zheng, *3-Query RLDCs are Strictly Stronger than
  3-Query LDCs*, arXiv:2512.12960, Definition 1.4，明确要求完整 codeword 上
  \(\Pr[\operatorname{Dec}(C(m),i)=m_i]=1\)，即 \(\bot\) 只允许在 corrupted word 上。
* 精准先例检索日期为 2026-08-19；OpenAlex/arXiv 以
  “local decoder query support”、“information set”与“smooth decoder support”
  检索未定位到 (473.6) 的直接命名先例。本文不据此声称绝对首创；
  (473.18) 是标准 injectivity/entropy 论证，真正用于本项目的新判断是
  honest-path singleton forcing 与 C183 copy-sum 的结合。
* 本结果只关闭 C183/ordinary exposed-history output-copy route。它不排除新的
  target-dependent physical proof、object-scale control、computational commitment，
  或不经过 explicit coordinate code 的 global relation；不证明 \(P\ne NP\)。

## 来源

* [C183 exposed-history PCPP+RLDC baseline](183-exposed-history-pcpp-rldc-baseline-2026-08-16.md)。
* [C184 PCPP+RLDC communication boundary](184-known-pcpp-rldc-transform-and-acrr-communication-compression-2026-08-16.md)。
* [C455 published RW forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
* [C456 published RW source alignment](456-published-rw-output-source-alignment-and-direct-scale-boundary-2026-08-19.md)。
* [C471 singleton full-branch support forcing](471-rw-singleton-proof-support-forcing-gate-2026-08-19.md)。
