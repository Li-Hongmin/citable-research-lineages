> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mutual-information mixture closure in the no-resampling high-confidence region

## Purpose

The mutual-information mixture theorem gives a target-independent policy law but, in
its general form, leaves a perfect-completeness or linearity repair before invoking the
strongest RLDC lower bound.  The no-resampling Dall'Agnol--Gur--Lachish (DGL) reduction
closes a nontrivial region without that repair: if the mixed correct branch is sufficiently
reliable and the mixed wrong branch is at most one-third reliable, a one-shot fallback
already gives an adaptive relaxed LDC.

This is a composition theorem.  It is not a new DGL lower bound and it does not say that
ordinary distributional soundness supplies the robust defect used below.

## Theorem (MI mixture to no-resampling relaxed-LDC closure)

Let

\[
  \Pi:\{0,1\}^k\to\Sigma^P,
  \qquad |\Sigma|=A\ge2,
\]

be a common proof map.  For every target \(m\), let \(S\mid M=m\) have policy law
\(\mu_m\), and let \(\bar\mu=\mathcal L(S)\).  A policy may include all branch
randomness and the query strategy; each branch makes at most \(r\) adaptive queries to
\(\Sigma^P\).  Fix \(0<\rho<1\) and \(\alpha>\beta\).  Define the robust defect

\[
\mathcal D(m,s):=
\max\left\{
  \max_i(\alpha-\operatorname{Comp}_{m,i,s})_+,\;
  \max_{\substack{i,z:\ d_H(z,\Pi(m))\le\rho P}}
  (\operatorname{WrongAcc}_{m,i,s}(z)-\beta)_+
\right\}.
\tag{274.1}
\]

Assume \(\mathcal D\) is measurable, and put

\[
  \bar\delta=\mathbb E_{M,S\sim\mu_M}\mathcal D(M,S),
  \qquad I=I(M;S)\text{ in bits},
  \qquad \tau=\bar\delta+\sqrt{\tfrac{\ln2}{2}I}.
\tag{274.2}
\]

Choose \(\Delta\) with

\[
  \tau<\Delta<\frac{\alpha-\beta}{2},
  \qquad
  \beta_\Delta:=\beta+\Delta\le\frac13,
  \qquad
  2\alpha_\Delta-\beta_\Delta\ge1,
  \quad \alpha_\Delta:=\alpha-\Delta.
\tag{274.3}
\]

If \(\tau/\Delta\le1/2\), then there is a subfamily \(\mathcal F\subseteq\{0,1\}^k\)
of density at least \(1/2\) and a shattered coordinate set \(J\) of size

\[
  |J|=(1/2-o(1))k,
\tag{274.4}
\]

such that the target-independent law \(S\sim\bar\mu\) satisfies, for every
\(m\in\mathcal F\), \(i\in[k]\), and \(d_H(z,\Pi(m))\le\rho P\),

\[
  \mathbb E_{\bar\mu}\operatorname{Comp}_{m,i,S}\ge\alpha_\Delta,
  \qquad
  \mathbb E_{\bar\mu}\operatorname{WrongAcc}_{m,i,S}(z)\le\beta_\Delta.
\tag{274.5}
\]

Consequently, after restricting to representatives indexed by
\(u\in\{0,1\}^{J}\), there is a binary adaptive relaxed LDC with

\[
  q_{\mathrm{bin}}=1+\lceil\log_2 A\rceil r
\tag{274.6}
\]

queries and constant radius.  Its completeness is at least \(2/3\), and its wrong-output
probability on a nearby word is at most \(1/3\).  Therefore, for fixed
\(A,r,\rho,\alpha_\Delta,\beta_\Delta\),

\[
  |J|+\lceil\log_2A\rceil P
  \ge |J|^{1+1/O_{A,r,\rho}(1)}.
\tag{274.7}
\]

In particular, \(P\le k\,\operatorname{polylog}k\) is impossible whenever the hypotheses
hold for infinitely many \(k\).

If the marginal law \(\bar\mu\) has a uniform executable sampler, the resulting decoder is
algorithmic: sample an independent dummy \(U\leftarrow\{0,1\}^k\), run the sampler for
\(\mu_U\), and use the sampled policy in the one-shot branch.  Without that sampler,
\(274.7\) is still a semantic coding consequence but not an algorithmic decoder construction.

## Proof

For \(\bar D_m:=\mathbb E_{S\sim\bar\mu}\mathcal D(m,S)\), total variation and Pinsker
give

\[
\mathbb E_M\bar D_M
\le \bar\delta+\mathbb E_M\operatorname{TV}(\mu_M,\bar\mu)
\le \bar\delta+\sqrt{\tfrac{\ln2}{2}I}=\tau.
\tag{274.8}
\]

Markov yields a family \(\mathcal F\) of density at least \(1-\tau/\Delta\ge1/2\)
on which \(\bar D_m\le\Delta\).  The definition of the maximum in (274.1) then gives
\(274.5\).  Sauer--Shelah applied to \(\mathcal F\) gives a shattered set \(J\) of size
\(274.4\).  Choose one representative \(m_u\in\mathcal F\) for every pattern
\(u\in\{0,1\}^{J}\).

If two representatives differ at coordinate \(i\) and their proof words were within
\(\rho P\), (274.5) applied to the same target-independent mixture would give both
\(\alpha_\Delta\) correct-branch acceptance and at most \(\beta_\Delta\) wrong-branch
acceptance for the same proof, contradicting \(\alpha_\Delta>\beta_\Delta\).  Thus the
restricted proof map has symbol distance \(>\rho P\).  The \(A\)-ary Singleton bound gives
\(P=\Omega_{A,\rho}(|J|)\), so a constant fraction of a constant-radius corruption of the
tagged inline code remains in the proof suffix.

Encode each proof symbol by \(\ell=\lceil\log_2A\rceil\) bits and inline the \(J\)-message
bits.  On coordinate \(i\), read its inline bit \(b\), sample \(S\sim\bar\mu\), and run
the \(b\)-branch once.  Let

\[
  q_0:=\frac{1/3-\beta_\Delta}{1-\beta_\Delta}.
\tag{274.9}
\]

If the branch accepts, output \(b\); if it rejects, output \(b\) with probability \(q_0\),
otherwise output \(\bot\).  On a codeword, the inline bit is correct and the output
probability of the correct bit is at least

\[
  \alpha_\Delta+(1-\alpha_\Delta)q_0\ge\frac23
\]

by \(2\alpha_\Delta-\beta_\Delta\ge1\).  If the inline bit is wrong, the wrong output
probability is at most

\[
  \beta_\Delta+(1-\beta_\Delta)q_0=\frac13.
\]

The proof-symbol encoding changes at most \(\ell\) binary queries per proof query, which
proves (274.6).  Applying the adaptive DGL relaxed-LDC lower bound gives (274.7).
\(\square\)

## Scope

The theorem closes only the high-confidence no-resampling region (274.3).  Outside that
region, the marginal mixture still gives the positive-gap semantic decoder of note 273, but
one needs fresh resampling, a linear-proof RLDC theorem, a perfect-completeness repair, or a
different transcript-level mechanism.  The theorem also retains the essential max over all
coordinates and all target-relative nearby proofs; coordinate-wise or proof-wise averages
cannot replace (274.1).

## Sources

* Dall'Agnol, Gur, and Lachish, *A Structural Theorem for Local Algorithms with
  Applications to Coding, Testing, and Privacy*, ECCC TR20-154, Corollary 7.9:
  <https://eccc.weizmann.ac.il/report/2020/154/>.
* [Mutual-information mixture closure](273-mutual-information-mixture-closure-to-rldc-2026-08-17.md).
* [No-resampling high-confidence closure](249-no-resampling-high-confidence-rldc-closure-2026-08-17.md).
