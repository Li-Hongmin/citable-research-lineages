> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha auxiliary-to-systematic inversion gate（2026-08-19）

## 本轮改变的判断

Harsha 的 auxiliary polynomial
\(P=p(\widetilde A)\) 不只是“由 witness 正向生成”的黑箱。其定义式
本身包含三个可分离的线性因子；在一个可计算的 gate-incidence 覆盖条件下，
任意 \(P\) 的随机访问 evaluator 都可以反推出 \(\widetilde A\) 的任意目标坐标。
因此，若一个 RW Closure 方案真的能在 address scale 访问 Harsha 的 \(P\) 段，
它不能把 systematic output attachment 当作另一个独立问题：在该接口内，输出
已经可由同一个 evaluator 恢复。

这是一条正向的、source-specific Closure interface，而不是声称 published
RW 已经具备该 evaluator。真正剩余的核验点变成 \(P\) 段的地址映射、
\(\widehat C\) 的地址尺度评价，以及每个要恢复坐标的 gate-incidence map。

## Harsha polynomial transformation

Harsha Proposition 5.4.1 的式 (5.7) 对
\(q:F^m\to F\) 定义

\[
 p(q)(u,v,w,y_1,y_2,y_3)
 =
 \widehat C(u,v,w,y_1,y_2,y_3)
 \prod_{j=1}^{3}\bigl(q(u_j)-y_j\bigr),
\tag{439.1}
\]

其中 \(u_1=u,u_2=v,u_3=w\)，而 \(\widehat C\) 是 circuit-constraint
polynomial。Harsha 的 construction 给出每变量次数

\[
 \deg_{x_j}\widehat C\le |H|,
 \qquad
 D_C:=\deg(\widehat C)\le(3m+3)|H|.
\tag{439.2}
\]

取 \(Q:=|F|\)，并假设

\[
 Q>D_C+2.
\tag{439.3}
\]

这比 RW/Harsha 的 \(Q=\Theta((m|H|)^3)\) field-size 选择弱得多，所以参数上
不会引入新的 object-scale 扫描；\(Q\) 仍是 \(t'^{o(1)}\)。

## Coordinate-coverage interface

称一个 witness coordinate \(u\in F^m\) **covered**，如果有一个
address-scale 可计算的 pair
\[
 \operatorname{Inc}(u)=(v_u,w_u)\in(F^m)^2
\tag{439.4}
\]
使三变量多项式
\[
 g_u(Y_1,Y_2,Y_3)
 :=
 \widehat C(u,v_u,w_u,Y_1,Y_2,Y_3)
\tag{439.5}
\]
不是零多项式。这里的 address-scale 意味着 pair 的描述长度、生成时间和
对应 circuit 都是最终地址长度的多项式，而不是完整 \(C_x\) gate-list 的
线性扫描。

再假设存在两个同一 serialization 下的 field-symbol evaluators：

* \(\mathsf E_P(u,v,w,y_1,y_2,y_3)\) 返回 honest auxiliary
  \(P=p(q)\) 在该点的 field value；
* \(\mathsf E_C(u,v,w,y_1,y_2,y_3)\) 返回公开 polynomial
  \(\widehat C\) 在该点的 field value。

若 proof 只以二进制保存 \(P\)，要求该 serialization 能在
\(\lambda=\lceil\log_2Q\rceil\) 次 address-scale bit reads 后恢复一个 field
symbol；若只有 ECC image，则还必须给出同尺度的 \(\Gamma\)-symbol decoder。

## 定理 439.1（Harsha auxiliary-to-systematic inversion）

在上述条件下，给定一个 covered coordinate \(u\)，可以用至多
\(O(Q^3)\) 次 \(\mathsf E_P,\mathsf E_C\) 调用和
\(\operatorname{poly}(m,\lambda,Q)\) 个 field/Boolean gates 计算 \(q(u)\)。

若 \(\widetilde A\) 的 systematic prefix contains the RW history/output bits，
则同一个 procedure 给出这些 prefix bits 的 address-scale evaluator；它不需要
另选 proof、Merlin witness 或 coordinate-specific auxiliary strategy。

### 证明

令 \(v=v_u,w=w_u\)，并把真实的两个未知值记为
\(q(v),q(w)\)。非零多项式 \(g_u\) 在 \(F^3\) 上的零点数至多为
\(D_CQ^2\)。两个坏平面
\[
  Y_2=q(v),\qquad Y_3=q(w)
\]
一共至多 \(2Q^2\) 个点。由 (439.3)，存在
\((a,b)\in F^2\) 使
\[
 q(v)\ne a,\qquad q(w)\ne b,
\]
且 \(g_u(Y,a,b)\) 作为 \(Y\) 的一元多项式不恒为零。该一元多项式至多有
\(D_C\) 个根，所以至少有两个 \(y\in F\) 满足
\(\widehat C(u,v,w,y,a,b)\ne0\)。

对这样的 \(y\)，定义可计算的归一化值
\[
 R(y):=
 \frac{\mathsf E_P(u,v,w,y,a,b)}
      {\mathsf E_C(u,v,w,y,a,b)}
 =
 (q(v)-a)(q(w)-b)\,(q(u)-y).
\tag{439.6}
\]
选两个不同的非零点 \(y_0,y_1\)，令
\[
 c=\frac{R(y_0)-R(y_1)}{y_1-y_0}.
\]
因为 \(q(v)\ne a\) 且 \(q(w)\ne b\)，有 \(c\ne0\)，并且
\[
 q(u)=y_0+\frac{R(y_0)}{c}.
\tag{439.7}
\]

算法不需要知道 \(q(v)\) 或 \(q(w)\)：枚举 \(a,b,y\in F\)，用
\(\mathsf E_C\) 找到两个非零 denominator，再检查两个归一化 \(R\) 值是否
不同。坏 pair 的两个因子之一为零，所有 \(R\) 都相同为零；满足条件的 pair
必然被枚举到。总调用数为 \(O(Q^3)\)，(439.7) 给出正确值。证毕。

## RW Closure 的直接后果

若一个 proposed same-proof closure 同时提供：

1. \(P\) 段的 address-scale field-symbol evaluator；
2. \(\widehat C\) 的 address-scale evaluator；
3. systematic prefix 每个所需坐标的 address-scale \(\operatorname{Inc}\) map；
4. 同一个 canonical proof/serialization 上的 word consistency；

则 Proposition 439.1 将 Harsha auxiliary branch 直接接到 RW systematic output，
再由 systematic prefix 的 fixed projection 得到 parent-bit evaluator。于是该方案
进入最终的 \(P/\mathrm{poly}\) forcing contradiction interface，而不需要额外的
whole-parent half-lift 假设。

这把 Gate-I 的 non-half-lift 分支精确分成：

* **可逆 \(P\)-exposure：** 满足上述三项 evaluator/coverage 条件，直接闭合到
  systematic output；
* **不可逆或不暴露 \(P\)：** 必须说明哪一项失败，并将其代价记为
  object-scale \(\widehat C\)/gate metadata、非 address-scale coordinate map、
  只暴露 \(\Pi_{\mathrm{ZOS}}\) 的新 global relation，或 changed proof semantics。

## 证据边界

* 式 (439.1)--(439.2) 直接来自 Harsha thesis §5.4.1 Proposition 5.4.1；
  RW 的 source extraction 只保证 honest \(P=p(\widetilde A)\) 的正向构造。
* Theorem 439.1 是 evaluator/coverage 条件下的可逆性定理；它不声称
  published Theorem 3.5/4.1 已给出 \(\mathsf E_P,\mathsf E_C\) 或
  \(\operatorname{Inc}\)。
* 固定 \(x_0\) singleton 不影响这个“若有 evaluator 则闭合”的推论；但没有
  evaluator 时，定理不提供任何 \(P\ne NP\) 结论。
* 只暴露 \(\Pi_{\mathrm{ZOS}}\)、ECC image 或 per-address existential proof
  不自动满足本定理；这些是明确的 model-exit 分支。

## 来源

* Prahladh Harsha, *Robust PCPs of Proximity and Shorter PCPs*, §5.4.1,
  Proposition 5.4.1, equations (5.6)--(5.9)：
  <https:/[unbundled local reference].ttic.edu/~prahladh/papers/thesis/phdthesis.pdf>
* Ren--Williams TR26-118 revision 1, Theorems 3.4--3.5：
  <https://eccc.weizmann.ac.il/report/2026/118/revision/1/download>
* [note 389](389-harsha-auxiliary-factorization-no-local-inverse-2026-08-18.md)：
  RW source-level factorization and quantifier boundary。
