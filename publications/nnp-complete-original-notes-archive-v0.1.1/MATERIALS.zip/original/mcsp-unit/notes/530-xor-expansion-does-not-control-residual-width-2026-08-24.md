> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# XOR expansion does not control residual width (2026-08-24)

## Proposition 39 (product-fiber obstruction)

Let \(t,m\ge 1\), let
\[
 B_t=\{x\in\mathbb F_2^t:|x|\le \lfloor t/4\rfloor\},
 \qquad
 A=B_t\times\{0^m\}\subseteq\mathbb F_2^{t+m}.
\]
Cut the input after the first \(t\) coordinates.  The residual function at a prefix \(u\)
is
\[
 F_u(z)=1_A(u\Vert z).
\]
There are only two residuals: \(F_u=1_{\{0^m\}}\) when \(u\in B_t\), and \(F_u=0\)
otherwise.  Thus the residual width at this cut is at most \(2\).

On the other hand,
\[
 A+A=(B_t+B_t)\times\{0^m\},
\]
and \(B_t+B_t\) contains the Hamming ball of radius \(2\lfloor t/4\rfloor\).  Hence
\[
 \log_2\frac{|A+A|}{|A|}
 \ge \bigl(1-H_2(1/4)-o(1)\bigr)t,
 \tag{530.1}
\]
where \(H_2\) is binary entropy.  Therefore exponential XOR expansion, even with a
fixed two-valued residual family, does not imply a residual-width lower bound.

### Proof

The residual statement is immediate from the product definition.  If \(y\) has weight at
most \(2\lfloor t/4\rfloor\), split its support into two sets of size at most
\(\lfloor t/4\rfloor\); this writes \(y=b_1+b_2\) with \(b_1,b_2\in B_t\).  The standard
Hamming-ball estimate gives
\[
 |B_t|\le 2^{H_2(1/4)t+o(t)},
 \qquad
 |B_t+B_t|\ge 2^{t-o(t)},
\]
which proves (530.1). \(\square\)

## Proposition 40 (the missing splice-to-XOR interface)

Harper growth or any \(A+A\) estimate can yield a cross-NO residual family only with an
additional splice-to-XOR hypothesis.  Concretely, suppose a proposed construction supplies
prefixes \(u_i\) and suffixes \(z_j\), together with strings \(x_i\), and a loss parameter
\(\rho\), such that
\[
 u_i\Vert z_j\in A
 \quad\Longrightarrow\quad
 \operatorname{CC}(x_i\oplus x_j)\le S+\rho
 \tag{530.2}
\]
for every \(i,j\).  Then a Harper lower bound
\(\operatorname{CC}(x_i\oplus x_j)>S+\rho\) forces \(u_i\Vert z_j\notin A\), giving the
desired cross-NO pairs.  Without (530.2), high XOR complexity says nothing about the
piecewise splice \(u_i\Vert z_j\): Proposition 39 has exponential \(A+A\) growth but only
two residuals.

The ordinary truth-table cut has no general reason to satisfy (530.2).  A splice copies a
prefix from one table and a suffix from another, whereas XOR combines both complete tables;
turning one into the other is an additional circuit transformation whose cost must be proved.
Thus the Harper/XOR route is closed at the generic-set level.  Any remaining \(S\)-scale
residual lower bound must use MCSP-specific mixed-pair circuit structure (or prove a new
splice-to-XOR reduction), not additive expansion alone.

## Boundary and dependencies

This note rules out upgrading the existing Harper and restricted-energy statements by a
purely set-theoretic implication.  It does not give an MCSP counterexample: the product set
\(A\) is a structural obstruction, not a low-complexity truth-table class.  The MCSP question
therefore remains the mixed-pair problem identified by Proposition 38.

- [Proposition 34](526-affine-residual-route-boundary-2026-08-24.md)
- [Propositions 36--37](528-energy-route-obstruction-and-random-baseline-2026-08-24.md)
- [Proposition 38](529-middle-cut-equality-gadget-residual-boundary-2026-08-24.md)
