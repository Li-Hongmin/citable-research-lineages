> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Singleton-output distributional soundness 直接桥接 ACRR（2026-08-16）

## 核心观察

“同一全局 proof”与“同一理想 proof”不是同一个要求。若一个 dPCP/PCPP 系统的
有效输出语言只有一个词 `f_x`，则 distributional soundness 即使允许理想 proof 随
随机边变化，也可能已经足以保证指定坐标的 soundness：所有理想 proof 在该坐标都解码
同一个 `f_x[i]`。

这给出一个比直接要求全局 proof 唯一更窄、但更可攻击的正向接口。

## 定理：singleton-output bridge

固定输入 `x` 与输出词 `f_x ∈ {0,1}^ell`。设有一个统一 proof address space、proof
assignment `A`、每坐标的边分布 `P_i`、局部约束 `V` 和 decoder `D_i`，满足：

1. **完备性：** 存在同一个 honest assignment `A_x`，使所有局部约束接受，且
   `D_i(A_x)=f_x[i]`；
2. **单元素有效词：** 每一个 valid proof assignment 的 decoded word 都是同一个
   `f_x`；
3. **按坐标 distributional soundness：** 对任意候选 assignment `A` 和每个 `i`，在
   `e ~ P_i` 上，除至多 `delta` 的概率外，若 `A` 的局部视图被接受，则该局部视图
   与某个 valid proof assignment 的同一局部视图一致。这里理想 valid assignment
   可以依赖于 `e`，不要求全局唯一。

对坐标 `i` 与声明位 `b` 定义 verifier

```text
Q_{x,i,b}(A;e) = 1
  iff  V(A;e) accepts and D_i(A;e) = b.
```

则：

- 当 `b = f_x[i]` 时，`A_x` 给出完备性 1；
- 当 `b != f_x[i]` 时，任意 `A` 的接受概率至多 `delta`。

### 证明

若某个局部视图既被接受、又解码为错误位 `b != f_x[i]`，它不可能与任何 valid proof
assignment 的同一局部视图一致，因为所有 valid assignment 在坐标 `i` 都解码为
`f_x[i]`。因此所有错误声明的接受事件都包含在 distributional-soundness 的异常
事件中，概率至多 `delta`。完备性由 `A_x` 直接给出。

注意：证明从未要求不同随机边使用同一个理想 assignment；单元素 decoded language
已经消除了 phantom word，而 honest assignment `A_x` 仍是所有坐标共用的同一 proof。

## 对 RW/JK 的直接含义

若 `delta < 1/2`，则上述系统可以直接替换 note 171 的 dPCP component：J--K easy
circuit 作为同一个 proof table，`Q_{x,i,1}` 在所有坐标上复用它。这样不需要：

- 为每个坐标重新选择 proof；
- 假设全局 valid assignment 唯一；
- 把不同坐标的局部视图拼成一个新的 canonical history。

仍需额外满足 RW 接口的 proof length、局部 generator、uniformity、forcing 和地址尺度；
singleton bridge 只解决“distributional soundness 是否足以给 coordinate soundness”这
一个量词缺口。

## 与标准 dPCP 的差异

普通 dPCP 的 list-decoding soundness 允许一个 assignment 的不同局部视图由短 list 中
不同的 valid words 解释；即使 list 长度为 1，若有效 decoded language 含多个词，仍需
额外证明每个坐标的理想词相同。第 1 节的平均到坐标反例说明不能从平均界自动得到本定理
的第 3 条。

这并不排除加入一个独立的外层编码机制：若 singleton word 已被编码为 `C(f_x)`，且
外层 decoder 的诚实查询路径是 `lambda`-smooth，则平均 robust 局部错误可以按
`q_D lambda epsilon` 计入逐坐标错误。这个受限正向桥接已单独写入
[singleton robust dPCP bridge](../../rw-jk-succinct-reconstruction/statements/singleton-robust-dpcp-smooth-decoder-bridge.md)；
它新增了 smoothness 和统一 codeword 假设，不能反推普通 dPCP 自动具备坐标鲁棒性。

因此真正值得攻击的构造命题是：

> 对每个确定性 NP transducer，是否存在近线性、常数查询、统一可生成的
> singleton-output distributionally sound dPCP，使有效 decoded language 恰为该 transducer
> 的唯一输出词？

若能做到，这将给出一个独立的 PCP/编码定理；若能证明其必然有超线性代价，则直接形成
本项目所需的 general impossibility theorem。

## 按 DHK 原始量词的 sharpness 反例

DHK 的 Definition 3.6 要求：对每个候选 proof `Π`，存在理想对象
`\widetilde x(R),\widetilde\Pi(R)`，其中 `\widetilde x(R)` 对固定的随机串 `R` 有效，
并且**对每个固定 index `j`**，局部视图在 `R` 上以至少 `1-δ` 的概率与理想视图
一致或直接拒绝。`\widetilde x(R)` 可以依赖 `R`，但不依赖额外的 `j`；这仍不足以
产生一个与 `R` 无关的全局 valid word。

具体地，对 `n\ge2` 取二元关系

\[
  H_n=\{z\in\{0,1\}^n:z\ne 1^n\},
\]

令编码 `E` 为恒等编码，dPCP decoder 只读取 proof 的第 `j` 位并输出该位，所有
局部约束恒真且从不拒绝。对非法候选 proof `\Pi=1^n`，取随机 `I\leftarrow[n]`，令
`\widetilde x(R)=1^n-e_I`，并令理想 proof 等于该有效 assignment。对任意其他候选
proof `\Pi\ne1^n`，直接取 `\widetilde x=\Pi`。于是对每个固定 `j`，唯一非法候选
`\Pi=1^n` 的局部视图不一致只在 `I=j` 时发生，故该 decoder 满足 DHK 分布式
soundness，误差为 `δ=1/n`。但是 `1^n\notin H_n`，而且理想 valid word 随 `R` 变化；
不存在一个单一 valid assignment 解释该候选 proof 的全部坐标。

因此 distributional soundness 的误差可以任意小，却仍不能替代 singleton-output
条件。这个反例不是“平均坐标”措辞造成的：它直接满足 DHK 的逐固定 `j` 量词，缺口
正是 target concentration，而不是随机坐标分布。

## 输出投影接口：正向构造的最小附加条件

设 dPCP 针对满足 assignment `z=(y,w)` 的编码 `E(z)`，且所有满足 assignment 的
`y` 都等于同一个目标词 `f_x`。若存在统一的局部输出投影 `P_i`，满足

\[
  P_i(E(y,w))=y_i
  \qquad\text{对所有 }(y,w)\in SAT(\Phi_x),
\]

且 `P_i` 的查询数为 `q_{out}`，则把 dPCP decoder 的输出限制到 `P_i` 对应的符号，
再应用 singleton-output bridge，即得到同一 proof/address space 上的 coordinate-robust
verifier，查询数只增加 `q_{out}`。若 `P_i` 是 systematic 单坐标投影，则没有额外
查询；若它是一个局部 code decoder，则需把其 corruption/完备性参数显式并入预算。

这把 GM/DHK 型正向路线压缩成一个可检验命题：

> 能否为近线性、distributionally sound dPCP 构造一个统一的、局部可读取的
> **target-output projection**，而不重新发送完整 witness、为每个坐标更换 proof，或
> 引入 `T`-尺度 consistency channel？

普通 dPCP 的编码 `E` 不自动是 systematic，也不自动给出这样的 `P_i`；把 `y` 直接
附加到 proof 后再检查，仍需要一个把附加位与 `E(z)` 绑定的局部 consistency test。
这正是 note 184 所说的 history-channel 压缩问题，不能把“存在一个 dPCP decoder”
直接晋级为 ACRR 构造。

同一个逻辑也适用于**按坐标**的 list-decoding soundness：若对每个目标 index `i`，
任意候选 proof 都有一个 valid assignment list，使固定 `i` 的局部接受输出除至多
`δ` 外落在该 list 的投影中，而所有 list 成员的 target projection 都等于 `f_x[i]`，
则错误 target 声明的接受率至多 `δ`。因此 distributional soundness 不是唯一可能的
桥；真正不可省略的是：

1. soundness 必须对固定目标坐标成立，而不是只对均匀随机坐标平均成立；
2. 所有被允许的 valid words 在 target projection 上必须集中到同一个 `f_x`；
3. 该 projection 必须在同一 proof/address space 上局部可计算。

GM--Minzer--Weissenberg--Zheng 的公开 dPCP list soundness 是对随机 `j` 的平均界，
所以不能仅凭其近线性 proof 直接调用这条推论。把平均界提升为固定 `j` 又回到
coordinate-robust dPCP 的主问题；简单复制坐标只产生 note 174 所述的重加权，不能免费
完成这一步。

## GMWZ 参数的精确入口（而非黑箱替换）

Gur--Minzer--Weissenberg--Zheng 的 Theorem 1.6 明确给出：对任意 `epsilon>0`，存在
`L=epsilon^{-O(1)}`，以及大小 `N log^{C(epsilon)} N` 的 2-query dPCP，满足
`(L,epsilon)` list-decoding soundness；其字母表也写成依赖 `epsilon` 的常数。因而若
要用 singleton conditioning bridge 得到所有 `k` 个坐标的固定错误概率 `beta<1/2`，
必须把平均误差降到 `epsilon<=beta/k`。代入原参数只得到

```text
L = k^{O(1)},
alphabet = O_{k}(1),
proof length = N log^{C(k)} N.
```

这同时留下两个独立缺口：

1. `L=k^{O(1)}` 的列表没有被定理压成 singleton，也没有保证列表中所有候选词在
   目标坐标上取同一位；因此不能直接调用本 note 的 singleton bridge；
2. `C(epsilon)` 和字母表常数随 `epsilon=1/k` 变化，原定理没有给出对 `k` 统一的
   地址/字母表账本，不能把“对每个固定 epsilon 近线性”改写成 RW 所需的统一
   `poly(n,log T)` 构造。

所以 GMWZ 路线的真正晋级条件应写成一个新的 parameterized theorem：在
`epsilon=Theta(1/k)` 时，同时保持 target-list concentration（或 singleton projection）、
固定有限字母/统一指数、以及同一 global proof/address space。若不能做到，应证明
list-collapse 或 coordinate-normalization 必然支付超线性代价；仅引用 Theorem 1.6/1.7
的固定 `epsilon` 版本不构成 simultaneous coordinate-robust dPCP。

## GMWZ Theorem 11.3 不是隐藏 witness 的 shared relation-PCPP

这里还必须区分“一个 RLDC 码字含有一个全局串”和“一个 relation-PCPP 在同一地址空间
中验证一个隐藏 witness 的所有目标坐标”。GMWZ Theorem 11.3 的证明先为每个
`(i,b)` 定义不同的电路 `phi_{i,b}`：它检查候选外码字属于 `C_0`，并且解码出的第
`i` 位等于 `b`；随后为每个 `L_{i,b}=SAT(phi_{i,b})` 取一个独立的 PCPP
`Psi_{i,b}`，再把这些按坐标、按声明位的 proof blocks 拼接到最终 RLDC 码字中。其
decoder 先读取一个带声明位的 `B`-侧符号，才知道应当选择哪个 `Psi_{i,b}` 的
`A`-侧位置，并在该坐标专属 PCPP 上检查。

因此该定理解决的是“消息族的 RLDC 解码”，并没有自动给出以下更强接口：给定一个
关系 `R(x,y,w)`，隐藏 `w`、固定同一 proof/address space，且对所有 `i,b` 直接验证
`y_i=b`，同时不把 `k` 个坐标专属 PCPP 重新写入 proof。把 GMWZ 的 `C_0` 或
Theorem 11.3 直接称为 RW 的 simultaneous coordinate-robust dPCP，会漏掉这一步
relation/target-output projection 编译。

这条边界是源文结构的直接推论，而不是对 GMWZ 的负面评价：Theorem 11.3 给出了
近二次长度 RLDC 的强基线；本项目需要的新定理则是把 `SAT(phi)` 的全变量 assignment
改造成 `L_x={y:exists w R(x,y,w)}` 的目标投影关系，并保持统一 proof、target
concentration 和地址尺度。若该 projection compiler 只能支付 `k` 个独立 PCPP blocks
或重新暴露 `w`，则它回到 exposed-history 基线；若能在近线性长度、固定查询和
`epsilon=O(1/k)` 下完成，则才构成 ACRR 的顶级正向突破。

## Singleton bridge 的 target-channel 熵边界

singleton 条件消除了 phantom word，但不自动压缩目标词本身。令 `I` 为输出地址集，
`A` 为输出字母表，`ℱ⊆A^I` 为一族可能的 singleton target words，且 `|ℱ|=M`。
若一个静态 key `σ∈{0,1}^s` 与一个有限策略摘要 `τ∈{0,1}^r` 通过统一、确定性的
word evaluator

       E(σ,τ,i) ∈ A       (i∈I)

精确产生每个目标词，即对每个 `f∈ℱ` 存在 `(σ_f,τ_f)` 使
`E(σ_f,τ_f,i)=f(i)` 对所有 `i` 成立，则

       s+r ≥ ⌈log_2 M⌉.                         (SB-ENT)

证明是直接的：若两个不同目标词共用同一对 `(σ,τ)`，则 evaluator 在每个地址
上给出同一符号，矛盾。因此 `f↦(σ_f,τ_f)` 是到长度 `s+r` 比特字符串的单射。
二元、全输出族 `ℱ={0,1}^k` 特别给出 `s+r≥k`；对 GM--W--Z 型 message family，
任何把所有 message 的 target-binding 都压进一个有限静态摘要的方案都至少支付
`k` 比特。

这条界有一个必须保留的量词边界。若 Merlin 的后续响应是任意地址相关函数，而不是
长度 `r` 的有限摘要，那么 `τ` 的有效信息量没有被计入，(SB-ENT) 不适用；但这时
singleton bridge 只说明“每个地址的局部理想词都投影到同一 target”，并没有给出
JK 所需的 deterministic word-level seed 或同一 strategy 的可压缩描述。若不同地址
允许各自选择 `τ_i`，则量词退化为 `∀i∃τ_i`，不能替换成
`∃τ∀i`；这正是 distributional soundness 仍可能保留完整 target channel 的地方。

因此 singleton-output 路线形成一个精确三分：

1. 把目标词和策略压进静态、有限摘要，支付 (SB-ENT) 的熵；
2. 保留未压缩的交互策略，得到的是 distributional/interactive proof，而不是
   deterministic JK seed；
3. 放弃同一 strategy/word consistency，则重新出现 phantom witness，不能接入 ACRR。

这不是对一般 distributional-sound dPCP 的长度下界；它是把 note 149 的确定性熵界
直接接到 singleton bridge 后得到的 target-channel 审查定理。对 RW/JK，若目标族的
有效熵已经达到 `k` 而地址尺度只允许 `poly(n,log T)` 比特，则任何成功的正向构造
必须明确展示第 2 类交互如何同时满足 parent closure 和 smartness；仅引用
singleton/distributional soundness 不足以完成压缩。

## 与 RLDC 的接口

singleton bridge 本身只给 proof-level coordinate soundness。要进一步得到 RLDC，还需
把 proof assignment 识别为编码词，并补上 note 174 的 corruption/robust-completeness
条件。也就是说：

```text
singleton distributional soundness
        + robust codeword/corruption interface
        => coordinate-robust RLDC
```

不能把这个箭头误写成“普通 dPCP 自动推出 RLDC”。

## 证据边界

Dinur--Harsha--Kindler 的 distributional soundness 定义允许理想化 proof 依赖随机串，
并用它控制组合中的局部一致性；本 note 的 singleton bridge 是从该量词结构推导出的新
条件性引理，并非该论文已声明的 coordinate-robust theorem。Gur--Minzer--Weissenberg--
Zheng 的近线性 dPCP/PCPP 参数提供了构造基线，但其公开 list-decoding soundness 不自动
满足第 3 条。尤其是现有 Theorem 1.7 以 `SAT(phi)` 形式陈述 PCPP；要用于本 note，
还需一个把外部输出词 `y` 与私有 witness `w` 分开的统一编译器，处理
`L_x = { y : exists w, R(x,y,w) }`，不能把 `SAT(phi)` 的全部变量直接误当作唯一输出词。

## 证据来源

- [Dinur--Harsha--Kindler, distributional soundness](https://eccc.weizmann.ac.il/report/2015/085/download)
- [Gur--Minzer--Weissenberg--Zheng, dPCP/PCPP](https://eccc.weizmann.ac.il/report/2025/217/)
- [Ren--Williams, Range Avoidance and `E^prMA/_1`](https://eccc.weizmann.ac.il/report/2026/118/)
- [note 149：AM commitment 不是 deterministic JK seed](149-am-commitment-is-not-a-deterministic-jk-seed-2026-08-15.md)
