> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# OPS 近二次 Formula 下界的候选公式 \(\mathrm{ZPP}^{NP}\) refuter（2026-08-14）

## 结论

Oliveira--Pich--Santhanam（OPS）的 \(U_2\)-Formula 随机限制证明可作如下有限、
候选描述型的构造化。固定有理数 \(0<\alpha<2\)。存在常数 \(d>1,K>0\)，使得在充分大
\(n\) 上，令 \(N=2^n\)，

\[
s(n)=n^d,
\qquad
t(n)=\left\lfloor\frac{2^{\alpha n/2}}{K n}\right\rfloor
=2^{(\alpha/2-o(1))n}.
\tag{1}
\]

给定 \((1^N,F)\)，其中 \(F\) 是一个 size 至多 \(N^{2-\alpha}\) 的
\(U_2\)-formula，存在一个零错误、期望 \(\operatorname{poly}(N,|F|)\) 时间的
Las Vegas randomized \(P^{NP}\)-oracle search procedure，输出 \(x\in\{0,1\}^N\) 满足

\[
F(x)\ne \operatorname{GapMCSP}[s(n),t(n)](x)
\tag{2}
\]

（只在 promise 上要求右端有定义）。以下也把它简称为一个**接收候选公式描述**的
\(\mathrm{ZPP}^{NP}\) refuter；严格说这是其输出／search 版本。它是 OPS 非一致下界的
oracle-constructive 重述，而不是通常只接收 \(1^N\) 的 uniform refuter。
不同成功随机路径可以输出不同反例；这里是多值的零错误 search relation，不是标准
single-valued \(\mathrm{FZPP}^{NP}\) function。

后续对 uniform family 组合与 oracle-query 轮数的精确细化见
[note 071](071-unary-oracle-composition-and-transfer-boundary-2026-08-14.md)：固定显式生成器后可以
得到 \(1^N\)-only 的 \(\mathrm{ZPP}^{NP}\) refuter；在 \(1<\alpha<2\) 时，语法 support
还给出完全无需 support oracle 的 BPP refuter。但这些算法仍不满足现有强分离定理的低复杂度接口。

这里采用

\[
Y_s=\{x:\operatorname{CC}(x)\le s\},
\qquad
N_t=\{x:\operatorname{CC}(x)>t\},
\tag{3}
\]

并以 \(1\) 表示 YES。

## 由 OPS 参数得到的 good restriction

为使 restriction 分布精确可采样，取 \(b=b(\alpha)\) 为充分大的整数，令

\[
q=2^{-b},\qquad k=q^{-2},\qquad
r=\left\lfloor\frac{(1-\alpha/2)n}{b}\right\rfloor,
\qquad p_0=q^r.
\tag{4}
\]

则 \(p_0=\Theta(N^{-1+\alpha/2})\)。增大 \(b\) 后有 \(q\le10^{-3}\)、
\(cq^2\le1/2\)，并且 \(c^r\le2^{\alpha n/4}\)。令 \(\rho\) 取自 OPS 的
\(r\) 层 \(q\)-regular、\(k\)-wise independent restriction 的复合分布；它是
\(p_0\)-regular。写 \(V=\rho^{-1}(*)\)。每个 \(\rho\) 都可由 \(O(n^2)\) 个随机位给定，且其
第 \(i\) 个坐标可在 \(\operatorname{poly}(n)\) 时间内由 seed 和 \(i\) 算出。

即使输入公式小于 Lemma 30 的字面临界大小，OPS footnote 13 的未吸收递推仍给出

\[
\begin{aligned}
\mathbb E_\rho\bigl[L(F\upharpoonright\rho)\bigr]
&\le 1+(cq^2)+\cdots +(cq^2)^{r-1}
   +c^r p_0^2L(F)\\
&\le 2+D c^r,
\end{aligned}
\tag{5}
\]

其中 \(D=2^{2b}\) 是常数：由 \(p_0\le2^bN^{-1+\alpha/2}\) 及
\(L(F)\le |F|\le N^{2-\alpha}\) 得到该界。令

\[
M:=10(2+D c^r).
\tag{6}
\]

于是 Markov 不等式与 OPS Proposition 34 合起来说明，以至少 \(2/5\) 的概率同时有

\[
L(F\upharpoonright\rho)\le M,
\qquad |V|\ge p_0N/2.
\tag{7}
\]

特别地，\(M\le2^{\alpha n/4+O(1)}\)，而 \(p_0N=\Theta(2^{\alpha n/2})\)。

## 算法

对每个 \(i\in V\)，以一个 NP 查询判定它是否是受限函数的 essential variable：

\[
i\in W
\quad\Longleftrightarrow\quad
\exists a\in\{0,1\}^{V\setminus\{i\}}:\
F(\rho[a,i\leftarrow0])\ne F(\rho[a,i\leftarrow1]).
\tag{8}
\]

该谓词的证书是赋值 \(a\)，而公式求值在 \(\operatorname{poly}(N,|F|)\) 时间内完成。
因而 \(W\) 可用至多 \(N\) 个 NP 查询精确得到。令 \(S=V\setminus W\)。单次试验如下：

1. 抽取 \(\rho\)，计算 \(V,W,S\)。除非 \(|V|\ge p_0N/2\) 且
   \(|S|\ge p_0N/2-M\)，否则输出 \(\bot\)。
2. 将所有 \(*\)-坐标补为 \(0\)，得到 \(y\)。
3. 固定 \(W\) 上的补全为 \(0\)，并在 \(S\) 上均匀随机补全，得到 \(z\)。
4. 以 NP oracle 询问 \(\operatorname{CC}(z)\le t(n)\)。若答案为 YES，输出 \(\bot\)。
   若答案为 NO，则在 \(F(y)=0\) 时输出 \(y\)，在 \(F(y)=1\) 时输出 \(z\)。

独立重复常数次并输出第一个非 \(\bot\) 结果，给出 success probability 至少 \(2/3\)；
或者重复至首次非 \(\bot\)，给出期望多项式时间的 Las Vegas 版本。

## 正确性与成功概率

式 (8) 定义的是 \(F\upharpoonright\rho\) 的语义 support。若 (7) 成立，则任何
size-\(M\) 公式至多含 \(M\) 个不同变量，故 \(|W|\le M\)，并且本次试验通过第 1 步。
对任意通过第 1 步的 restriction，\(F\upharpoonright\rho\) 只依赖于 \(W\)，从而

\[
F(y)=F(z).
\tag{9}
\]

另一方面，\(y\) 的第 \(i\) 位可由 restriction generator 的 seed 和地址 \(i\) 计算；
将 \(O(n^2)\)-bit seed 硬连线，得到一个 size \(n^d\) 的 \(n\)-输入 circuit。因此

\[
y\in Y_{s(n)}.
\tag{10}
\]

存在绝对常数 \(A\)，使 size 至多 \(t\) 的 \(n\)-输入 Boolean circuits 总数至多

\[
2^{A t\log(t+n)}.
\tag{11}
\]

当 \(K\) 充分大时，第 1 步给出的 \(|S|\ge p_0N/2-M\) 使得

\[
A t(n)\log(t(n)+n)\le |S|/2.
\tag{12}
\]

而且 \(t(n)\le N\)，故语言 \(\{z:\operatorname{CC}(z)\le t(n)\}\) 属于 NP：
猜测 circuit 后逐真值表项验证即可。即使其余坐标固定，随机补全落入
\(\operatorname{CC}(z)\le t(n)\) 的概率也至多 \(2^{-|S|/2}\)。故在 (7) 的常数概率事件上，第 4 步以
\(1-2^{-\Omega(2^{\alpha n/2})}\) 的概率通过。oracle 回答 NO 时，严格有
\(z\in N_{t(n)}\)。结合 (9)--(10)：

\[
\begin{cases}
F(y)=0 &\Longrightarrow y\in Y_s\text{ 是反例},\\
F(y)=1 &\Longrightarrow z\in N_t\text{ 是反例}.
\end{cases}
\tag{13}
\]

所以每一个非 \(\bot\) 输出都正确；(7) 与计数界给出常数成功概率。

## 量词边界

这个构造保留了 OPS 下界本来的量词形状：

\[
\forall F\ \exists x_F.
\tag{14}
\]

它没有给出一个只由 \(N\) 决定的 \(x_N\)，也不能改写为 PFML 所需的固定输入断言。
对一个随机 Formula \(\mathcal F\)，要否定其 one-sided PFML 条件，至少须得到

\[
\exists y\in Y_s:\Pr_{F\sim\mathcal F}[F(y)=0]>0
\quad\text{或}\quad
\exists z\in N_t:\Pr_{F\sim\mathcal F}[F(z)=1]>1/4.
\tag{15}
\]

从 \(\forall F\,\exists x_F\) 对有限支撑至多只能以鸽巢原理得到某一固定输入的非定量正
失败概率；它既不保证该输入在 YES 端，也不把 NO 端错误提升到 \(>1/4\)。更具体地：

- 算法把候选公式 \(F\) 的描述作为输入；Chen--Jin--Santhanam--Williams Definition 1.1
  的普通 refuter 只接收 \(1^N\)。对固定 P-uniform 公式生成器可按 note 071 组合为
  unary \(\mathrm{ZPP}^{NP}\) refuter；但它仍不是相关 magnification theorem 所要求的
  polylogtime-uniform \(\mathrm{AC}^0\) refuter，因此不推出 \(P\ne NP\)。
- NP oracle 用于精确提取语义 support，并验证随机 completion 确属 NO instance。
  OPS/IMZ 的收缩界控制的是最小等价公式大小 \(L(F\upharpoonright\rho)\)，不是一个已给出的
  小 syntax。其 small-block/special-variable 论证也没有给出可迭代、仍以 Formula 为输出且
  保持同一 \(p^2\) shrinkage 的编译器：单轮可用 DAG sharing 避开 special child 的复制，
  但 DAG 已不属于下一轮 IMZ 收缩所要求的 Formula 类；将它重新展开可在 \(r=\Theta(n)\)
  层中累计 special-child 复制损失（每个至多两个 special variables 的 selector 可复制 child
  至多四份）。故本 note 不声称 \(P\) 或 BPP
  candidate-description refuter。
- 这不改变 [note 067](067-ops-anti-checker-formula-lifting-boundary-2026-08-14.md)
  的 Circuit--Formula 模型缺口，也不把 formula lower bound 升级为一般 circuit lower bound。

## 来源

- Igor Carboni Oliveira, Ján Pich, and Rahul Santhanam, *Hardness Magnification near
  State-of-the-Art Lower Bounds*, CCC 2019, Appendix A.1--A.3：Lemmas 28, 30, 33，
  Propositions 31, 34，以及 footnote 13。全文：
  `ResearchLibrary/lib/oliveira2019hardness/oliveira2019hardness.pdf`。
- Shuichi Hirahara and Rahul Santhanam, *On the Average-Case Complexity of MCSP and
  Its Variants*, CCC 2017, \S4.1：IMZ small-block/special-variable 论证的语义
  \(L(\cdot)\) 形式。全文：`ResearchLibrary/lib/shuichihirahara2017average/fulltext.md`。
- Lijie Chen, Ce Jin, Rahul Santhanam, and R. Ryan Williams, *Constructive Separations
  and Their Consequences*, TheoretiCS 3 (2024), Definition 1.1 与 \S7：ordinary refuter 和
  candidate-description nonuniform list-refuter 的不同接口。全文：
  `ResearchLibrary/lib/williams2024constructive/fulltext.md`。
