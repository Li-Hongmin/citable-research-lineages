> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Quasi-additive 的下一承重接口

## 决策

当前唯一值得继续的数学目标是裁决下面的二选一命题：

\[
\boxed{
  \text{对所有 }X,Y\subseteq\mathbb F_2^N,\quad
  (\mathrm{leaf})+(\mathrm{recursion})
  \Longrightarrow \alpha |X||Y|=O(N)
}
\]

这里限制

\[
\phi_c=\alpha,
\qquad
K(A,B)=\bigl(|X||Y|-|A||B|\bigr)h(\dim\operatorname{aff}A,
\dim\operatorname{aff}B),
\]

并要求

\[
\alpha|A||B|+K(A,B)\le 1
\]

对每个 parity-monochromatic 矩形成立，以及

\[
K(V)+K(W)\ge K(A,B)
\]

对每个横向或纵向二分成立。

若命题成立，纯“维数势”路线关闭；若命题失败，则反例本身就是构造递归势的线索。这里不再把“找到一个负坐标叶”误报成反例。

## 已确定的硬事实

1. 任意非负点对权重的单叶 parity-rectangle 方法至多给常数下界：随机仿射 parity 对每个不同点对给出四种标签等概率，因此某个有向单叶矩形捕获总权重至少四分之一。fractional cover、Khrapchenko 型比值和带描述权的同类方法全部被这一事实关闭。

2. 仿射 parity 叶的整数 cover 最多为 (2N)，但一般递归 protocol 可远大于线性；所以真正的承重对象必须记录递归分割，而不是只记录叶 cover。

3. Kamiyama/Ueno 的 quasi-additive LP 对任意输出字母都成立。把输出字母取为所有有向 affine parity 后，QA 值恰等于 Formula\(\circ\)XOR 的协议分割数。因此它是正确的全局目标，但还不是一个已构造的 MCSP 下界证书。

4. 纯维数 ansatz 中，递归超可加性不推出坐标叶势的总和非负。最小反例为 (N=2)：取 (X=\{00\})、(Y=\{01,10,11\})，令 (h(0,0)=a>0)、(h(0,1)=-2a)。所有递归约束成立，但两个坐标叶的 (K) 总和为 (-4a)。加入 leaf 约束后，最优值为 (\alpha=2/3)，而 (\alpha|X||Y|=2=N)。因此被关闭的只是“先证明每片坐标叶非负，再求和”的证明，不是整个纯维数命题。

5. 对若干 (N\le4) 的精确小规模 LP，未观察到超线性 (\alpha|X||Y|)；这只是定位证据，不是定理。根部仿射维数、交维数和最小证书数据也不足以决定递归协议数。

## 下一原子义务

优先证明或否定：

> **维数融资引理。** 在上述 leaf 与 recursion 联合约束下，所有高维负 (K) 的累计量都能由递归中出现的低维正 (K) 以 (O(N)) 的总预算支付。

证明成功则把这一整类对称势从主线移入“已关闭”；反例成功则要求保留递归碰撞谱（而非单纯的 affine dimension）作为下一种势函数参数。

## 当前文献边界

截至 2026-08-13 的定向检索，没有发现把 Formula\(\circ\)XOR 或 Formula-XOR 的 MCSP 下界推进到 (N^{1.01}) 的新结果。Riazanov–Sofronova–Sokolov 的 ITCS 2026 工作研究的是深度受限的 (\mathrm{AC}^0\circ\mathrm{XOR})，Carmosino–Dang–Jackman 的 STACS 2026 工作研究 XOR-simple-extension 的可解性；两者都不能提供这里所需的 Formula-XOR 模型 lifting。现有主线仍是递归 quasi-additive 证书，而不是继续扩张文献清单。

