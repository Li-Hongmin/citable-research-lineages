> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK canonical lift injectivity eliminates the collision branch（2026-08-19）

## 本轮改变的判断

C498 只使用了
\(M_d=|\widehat{\mathcal Z}_d|\le|\mathcal Z_d|\)，因而把
lift-collision 作为一个可能的 escape。这个余量在 C497 的 canonical-selector
定义下实际上不存在：canonical right inverse 使 \(G\) 在 \(\Gamma_0\) 上单射，而
\(\Gamma_d\) 的递归保证每一层 lift 所看到的 descendant chunks 都在
\(\Gamma_0\) 中。因此对所有 generator、所有 canonical selectors 和所有 \(d\ge0\)，
\(d\)-层 lift 在 \(\mathcal Z_d\) 上保持单射。

于是有严格恒等式
\[
M_d=|\widehat{\mathcal Z}_d|
   =|\mathcal Z_d|
   =|\Gamma_{d+1}|.
\tag{499.1}
\]

这不是对 published truth-table generator 的额外假设；它是 C497/C498 的定义层
结论。C498 的 lift-collision 分支应由本 note 修正为空分支。

## 定义

沿用 C497。令
\[
G:\{0,1\}^{n}\to\{0,1\}^{2n},\qquad
R=\operatorname{Range}(G),
\]
并固定 \(p:R\to\{0,1\}^n\) 满足 \(G(p(z))=z\)。定义
\[
\Gamma_0=\{u:p(G(u))=u\},
\qquad
\Gamma_{d+1}=\{u\in\Gamma_0:
\operatorname{left}(G(u)),\operatorname{right}(G(u))\in\Gamma_d\},
\]
以及
\[
\mathcal Z_d=\{z\in R:
\operatorname{left}(z),\operatorname{right}(z)\in\Gamma_d\}.
\]
对一个由 \(n\)-bit chunks 构成的字符串，\(\mathsf L_G\) 逐 chunk 应用 \(G\)，
并令 \(\mathsf L_G^0\) 为恒等映射。

## 定理 499.1（canonical-lift injectivity）

对每个 \(d\ge0\)，限制映射
\[
\mathsf L_G^d\big|_{\mathcal Z_d}:\mathcal Z_d\longrightarrow\{0,1\}^{n2^{d+1}}
\]
是单射。因此
\[
|\widehat{\mathcal Z}_d|=|\mathcal Z_d|=|\Gamma_{d+1}|.
\tag{499.2}
\]

### 证明

首先，\(G\) 在 \(\Gamma_0\) 上单射：若 \(u,v\in\Gamma_0\) 且
\(G(u)=G(v)=z\)，则
\[
u=p(G(u))=p(z)=p(G(v))=v.
\tag{499.3}
\]

对 \(d\) 归纳。\(d=0\) 时 \(\mathsf L_G^0\) 是恒等映射。设结论对
\(d-1\) 成立，取
\[
z=a\Vert b,\qquad z'=a'\Vert b'\in\mathcal Z_d.
\]
当 \(d\ge1\) 时，\(a,b,a',b'\in\Gamma_d\)，由 \(\Gamma_d\) 的定义，
\[
G(a),G(b),G(a'),G(b')\in\mathcal Z_{d-1}.
\tag{499.4}
\]
若 \(\mathsf L_G^d(z)=\mathsf L_G^d(z')\)，按左右半段比较得到
\[
\mathsf L_G^{d-1}(G(a))=
\mathsf L_G^{d-1}(G(a')),\qquad
\mathsf L_G^{d-1}(G(b))=
\mathsf L_G^{d-1}(G(b')).
\]
归纳假设和 (499.4) 给出 \(G(a)=G(a')\)、\(G(b)=G(b')\)。由于
\(a,a',b,b'\in\Gamma_d\subseteq\Gamma_0\)，再用 (499.3) 得到
\(a=a'\)、\(b=b'\)，即 \(z=z'\)。

最后，C498 的双射 \(u\mapsto G(u):\Gamma_{d+1}\to\mathcal Z_d\) 给出
\(|\mathcal Z_d|=|\Gamma_{d+1}|\)，从而得到 (499.2)。证毕。

## 对 C498 与 RW/JK Closure 的修正

1. **collision branch 为空。** 只要使用 C497 的 \(\Gamma_d\)、\(\mathcal Z_d\)
   和逐 chunk lift 定义，就有
   \[
   \kappa_d:=\log_2\frac{|\Gamma_{d+1}|}{M_d}=0
   \tag{499.5}
   \]
   （当 \(\mathcal Z_d\ne\varnothing\) 时）。因此不能把 lift-image collision
   作为 published generator 的独立逃逸。
2. **C497 的 payment 精确化。** 若 \(y\in\mathcal O_{k-i}\)，则其固定
   first-failure transcript 的 prefix fiber 至少有
   \[
   |\Gamma_{k-i+1}|^{\,2^{i-1}-1}
   \tag{499.6}
   \]
   个值，exact descriptor 至少支付
   \[
   (2^{i-1}-1)\log_2|\Gamma_{k-i+1}|
   \tag{499.7}
   \]
   bits。
3. 因而在给定 descriptor budget 下，剩余未闭合分支不能再称为
   “lift-collision/global-compression”；它必须是另一个真实的 global relation、
   target-specific descriptor、bottom/cover 机制，或明确退出 C497 的 canonical
   half-lift 模型。

## 有限核验

对 \(n=2\) 的全部
\[
16^4=65{,}536
\]
个函数 \(G:\{0,1\}^2\to\{0,1\}^4\)，按字典序 canonical selector 构造
\(\Gamma_d\)，并穷举 \(d=0,1,2,3\)。全部函数均满足
\[
|\widehat{\mathcal Z}_d|=|\mathcal Z_d|=|\Gamma_{d+1}|.
\]
该穷举只是对归纳证明的有限 sanity check，不替代定理证明。

## 证据边界

* 定理 499.1 是 generator-independent 的集合/递归定理；不要求 \(G\) 在整个
  domain 上单射，只要求 C497 的 canonical right inverse。
* 它把 C498 的 collision 余量删掉，但不自动给出 \(|\Gamma_d|\) 的增长下界；
  因此仍不单独闭合 published fixed singleton，也不证明 \(P\ne NP\)。
* 要接 C455，仍需证明 published canonical PCP image、同一 proof serialization
  与 C497 的 prefix fiber 对齐。

## 来源

* [C497](497-jk-canonical-liftable-range-projection-barrier-2026-08-19.md)：定义
  \(\Gamma_d,\mathcal Z_d,\widehat{\mathcal Z}_d\) 与 prefix-fiber barrier。
* [C498](498-jk-canonical-lift-phase-diagram-2026-08-19.md)：\(|\mathcal Z_d|\)
  与 \(|\Gamma_{d+1}|\) 的双射；本 note 修正其 collision 分支。
* Ren--Williams TR26-118 rev.1, Theorem 3.1：JK 的逐层 canonical range test。
