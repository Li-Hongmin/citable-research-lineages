> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Matroid-rank QA 状态的统一平均 no-go（2026-08-13）

## 设置

令 (C=X\times Y)，(m=|C|)。设叶分布 (mathscr D) 对每一个 cell (cin C) 都有相同的包含概率

\[
\Pr_{R\sim\mathscr D}[c\in R]=q .
\tag{1}
\]

这包括随机 affine-parity 叶再做独立行/列 (1/2)-thinning 的情形（在当前归一化下 (q=1/16)）。

固定一个碰撞 witness (h\subseteq C)。给每个 cell (e=(x,y)) 标记差向量

\[
d_e=x\oplus y\in\mathbb F_2^N,
\qquad
r_h=\operatorname{rank}\{d_e:e\in h\}.
\]

定义命中差向量的线性秩

\[
\rho_h(R)=\operatorname{rank}\{d_e:e\in h\cap R\}
\]

以及根归零的状态

\[
K_h(R)=\rho_h(R)-\frac{r_h}{m}|R|.
\tag{2}
\]

## QA 递归性

若 (R=V\dot\cup W)，则向量空间秩满足

\[
\rho_h(V)+\rho_h(W)\ge \rho_h(R),
\]

而 (|V|+|W|=|R|)。因此

\[
K_h(V)+K_h(W)\ge K_h(R),
\qquad K_h(C)=0.
\tag{3}
\]

这看似捕捉了 affine 叶中“多命中但低 difference-rank”的状态。

## 平均非负定理

**Lemma.** 对满足 (1) 的任意叶分布 (mathscr D)，都有

\[
\mathbb E_{R\sim\mathscr D}K_h(R)\ge0.
\tag{4}
\]

**证明。** 从 (h) 选出 (r_h) 个 cell (e_1,\ldots,e_{r_h})，使差向量 (d_{e_i}) 构成一组基。对每个 (R)，命中基向量仍线性独立，故

\[
\rho_h(R)
\ge \sum_{i=1}^{r_h}{\bf1}_{\{e_i\in R\}}.
\]

取期望并用 (1)，得到

\[
\mathbb E\rho_h(R)\ge q r_h.
\]

另一方面，

\[
\mathbb E\left[\frac{r_h}{m}|R|\right]
=\frac{r_h}{m}\sum_{c\in C}\Pr[c\in R]
=q r_h.
\]

两式相减即得 (4)。\(□)

## 后果

任意非负加权的 rank-state

\[
K=\sum_h\lambda_hK_h,
\qquad\lambda_h\ge0,
\]

仍满足 (mathbb E K\ge0)。若 LP 单色叶约束为

\[
\sum_{c\in R}\phi_c+K(R)\le1,
\tag{5}
\]

对叶分布取平均并用 (1)、(4)，便有

\[
q\sum_{c\in C}\phi_cle1,
\qquad
\sum_c\phi_cle q^{-1}=16.
\tag{6}
\]

故“按 witness 差向量取线性秩，再减去根密度”的 QA 状态不能绕过 AEKR thinning；其失败不是某个小 witness 的偶然现象，而是每个 matroid 基的逐 cell 包含概率直接强迫的平均不等式。

## 研究接口

要获得超线性目标，状态必须违反上述基下界机制：例如依赖**联合的投影关系/公式复杂度**，而不是命中 cell 集合上的单调 matroid 秩。Chukhin–Kulikov–Mihajlin 的 ξ 势正是这一方向：它对固定星邻域求和投影 KW 关系的公式复杂度，并利用强分离叶至多激活一个标签；Affine-parity 叶若能建立同等“激活容量”约束，才可能避免 (6)。

