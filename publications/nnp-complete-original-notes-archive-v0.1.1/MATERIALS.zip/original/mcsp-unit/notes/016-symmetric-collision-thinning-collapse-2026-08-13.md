> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 对称四点碰撞势的行列抽样坍缩（2026-08-13）

## 结论

令 (C=X\times Y)，其中 (X=f^{-1}(0))、(Y=f^{-1}(1)subseteq
\mathbb F_2^N)，并令 (mathcal H_4) 为 odd--odd affine collision
四点集。对

\[
 g(m)=\mathbf 1_{m=1}-\mathbf 1_{m=3},
 \qquad
 K(R)=\sum_{H\in\mathcal H_4}\lambda_Hg(|H\cap R|),
 \quad \lambda_H\ge0,
\]

若叶约束包含所有合法 affine-parity 子矩形，则

\[
 \sum_{c\in C}\phi_c\le 16.
 \tag{1}
\]

故该对称四点势不可能产生超常数（因而不可能产生超线性）quasi-additive
下界。

## 抽样

随机取

\[
 R_0=(X\cap\ell^{-1}(t))\times(Y\cap\ell^{-1}(1-t)),
 \qquad \ell(z)=r\cdot z\oplus b,
\]

其中 ((r,b,t)) 均匀。每个 (c=(x,y)) 满足

\[
 \Pr[c\in R_0]=\frac14.
 \tag{2}
\]

对 (R_0=A_0\times B_0)，独立保留每个 (x\in A_0) 和每个
(y\in B_0)，概率均为 (1/2)，令 (R=A'\times B')。这是合法
affine-parity 子矩形，且

\[
 \Pr[c\in R]=\frac14\cdot\frac12\cdot\frac12=\frac1{16}.
 \tag{3}
\]

若 (H) 是 odd--odd collision，则 (H\not\subseteq R_0)，所以
(G=H\cap R_0) 至多三条边。条件于 (R_0)，(H\cap R) 是二部图
(G) 的随机诱导边集。逐类计算（(m=|G|=3)）得到：

\[
\begin{array}{c|c|c|c}
 G & \Pr(M=1)&\Pr(M=3)&\mathbb E[g(M)]\\ \hline
 3K_2 &27/64&1/64&13/32\\
 K_{1,3}&3/16&1/16&1/8\\
 P_4&5/16&1/16&1/4\\
 K_{1,2}\sqcup K_2&11/32&1/32&5/16
\end{array}
\tag{4}
\]

对 (m=0,1,2)，显然 (mathbb E[g(M)]\ge0)（(m=0) 为 0，
(m=1) 为 (1/4)，(m=2) 只有正的一命中项）。故

\[
 \mathbb E[g(|H\cap R|)\mid R_0]\ge0,
 \qquad
 \mathbb E K(R)\ge0.
 \tag{5}
\]

对叶约束

\[
 \sum_{c\in R}\phi_c+K(R)\le1
\]

取上述抽样平均，使用 (3)--(5)，即得

\[
 \frac1{16}\sum_{c\in C}\phi_c
 +\mathbb E K(R)\le1
 \quad\Longrightarrow\quad
 \sum_{c\in C}\phi_c\le16.
\]

空 (A') 或 (B') 可视作空叶；其左端为 0，不影响平均。

## 最大叶的最小反例

若错误地只允许最大叶 (R_0)，上述行列抽样不可用，随机平均也确实
失败。取

\[
 N=3,\quad X=\{0\},\quad Y=\mathbb F_2^3\setminus\{0\},\quad
 H=\{(0,1),(0,2),(0,3),(0,4)\}.
\]

因 (1\oplus2\oplus3=0)，(H) 是 odd--odd collision。对 32 个
((r,b,t)) 等可能最大叶，

\[
 \#\{M=0,1,2,3}=(18,2,6,6),
 \qquad
 \mathbb E g(M)=\frac{2-6}{32}=-\frac18.
 \tag{6}
\]

式 (6) 只说明“最大叶平均”不足；在标准的所有子矩形叶模型中，式
(1) 已排除该势的任何超线性实例。
