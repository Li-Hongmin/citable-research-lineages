> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW high-arity folding quantifier and batch-opening gate (2026-08-19)

## 结论

高元 folding 的 raw-query 下界依赖一个不能省略的量词：允许对每个未读坐标作仍在协议
正确性域内的局部 completion。对 full raw family，这个条件成立，dense \(b\)-ary fold
必须读取全部 \(b\) 个 symbols；对 published RW singleton，它不自动成立，甚至固定
\(0^b\) 可使所有 folds 零查询。

因此，若 \(R\) 层 deterministic exact（或 zero-error）raw folds 的 arities 为
\(b_1,\ldots,b_R\)，每层都满足局部 completion binding，且

\[
  \prod_{r=1}^{R}b_r\ge T,
  \tag{475.1}
\]

则总 raw-query 数满足

\[
  Q\ge\sum_{r=1}^{R}b_r
  \ge R\,T^{1/R}.
  \tag{475.2}
\]

常数轮因而支付 \(T^{\Omega(1)}\)；若 \(T=2^{\Theta(m)}\) 且
\(Q=m^{O(1)}\)，则必须有 \(R=\Omega(m/\log m)\)。但 (475.2) 不能在没有
completion binding 的情况下套到 fixed singleton。

另一方面，任何新的 unconditional batch-opening/folding 接口，只要它在同一个 physical
proof 上 single-valued 地恢复 published \(B_n\) 的全部地址，就已经落入 C473/C474：短
physical proof 与小 address evaluator 都被 C455 forcing 排除。剩余出口必须显式支付
object-scale physical oracle/evaluator、失去 same-proof all-address recovery，或进入
computational/unpriced-oracle model exit。

## 定理 475.1（dense fold 的 completion-sensitive query bound）

令 \(F\) 为有限域，

\[
  L_\alpha(y)=\sum_{i=1}^{b}\lambda_i(\alpha)y_i,
  \qquad
  \lambda_i(\alpha)\ne0,
  \tag{475.3}
\]

并令 \(\mathcal Y\subseteq F^b\)。设 deterministic adaptive decision tree \(D\) 通过
raw coordinate queries，在每个 \(y\in\mathcal Y\) 上精确输出 \(L_\alpha(y)\)。固定
\(y\in\mathcal Y\)。若对坐标 \(k\) 存在 \(\delta\ne0\) 使

\[
  y+\delta e_k\in\mathcal Y,
  \tag{475.4}
\]

则 \(D\) 在 \(y\) 的真实执行上必须查询 \(k\)。特别地，若 \(\mathcal Y=F^b\)，则
每个真实执行都查询全部 \(b\) 个坐标。

若 randomized tree 在 \(\mathcal Y\) 中每个输入上的错误率至多
\(\varepsilon<1/2\)，则在满足 (475.4) 的坐标上

\[
  \Pr[D\text{ queries }k\text{ on }y]\ge1-2\varepsilon.
  \tag{475.5}
\]

故 full-family 情形有

\[
  \mathbb E[Q(y)]\ge b(1-2\varepsilon).
  \tag{475.6}
\]

### 证明

若 \(D\) 在 \(y\) 上未查询 \(k\)，则把输入改成 \(y+\delta e_k\) 不改变任何已见
answer；按 query step 归纳，两次 transcript 与最终输出相同。但 (475.3) 的正确值相差
\(\lambda_k(\alpha)\delta\ne0\)，矛盾。

随机情形对同一 random tape 耦合 \(y\) 与 \(y+\delta e_k\)。在“不查询 \(k\)”事件上，
两次输出相同而正确值不同，故至少一个输入出错。该事件的概率至多两输入错误率之和
\(2\varepsilon\)，即得 (475.5)--(475.6)。若错误率为零，由 \(F^b\) 有限还可先对所有
输入的概率一事件取有限交，再逐 tape 使用 deterministic 结论。证毕。

### 推论 475.1a（正半径 raw domain）

若某个 honest raw vector \(y^\star\) 满足

\[
  \{y\in F^b:\operatorname{wt}(y-y^\star)\le1\}
  \subseteq\mathcal Y,
  \tag{475.6a}
\]

则定理 475.1 对全部 \(b\) 个坐标适用，故 exact evaluator 在 \(y^\star\) 上查询至少
\(b\) 个坐标，而逐输入错误率至多 \(\varepsilon<1/2\) 时

\[
  \mathbb E[Q(y^\star)]\ge b(1-2\varepsilon).
  \tag{475.6b}
\]

因此任意固定相对半径 \(\rho>0\) 的 raw Hamming ball 在
\(\lfloor\rho b\rfloor\ge1\) 时已经足够。这里的 raw 不能删除：physical proof 的
Hamming 邻域只有在每个 raw-coordinate completion 都可由 correctness domain 内的近
proof 实现时，才推出 (475.6a)。非局部编码约束可能破坏这个投影，必须另证 local
realization，而不能由正半径符号自动推出。

## 推论 475.2（arity--round tradeoff）

设第 \(r\) 层的 deterministic exact（或 zero-error）evaluator 对一个
\(b_r\)-symbol dense raw fold 满足定理 475.1 的 completion 条件，且各层查询分别计价。
由定理 475.1 与 AM--GM，

\[
  Q\ge\sum_{r=1}^{R}b_r
  \ge R\left(\prod_{r=1}^{R}b_r\right)^{1/R}
  \ge R\,T^{1/R}.
  \tag{475.7}
\]

若每层改为逐输入错误率至多 \(\varepsilon<1/2\) 的 randomized evaluator，则相应结论是

\[
  \mathbb E Q
  \ge(1-2\varepsilon)\sum_{r=1}^{R}b_r
  \ge(1-2\varepsilon)R\,T^{1/R}.
  \tag{475.7a}
\]

在 exact/zero-error 情形，若 \(R=O(1)\)，则 \(Q=T^{\Omega(1)}\)。若 \(T=2^{\Theta(m)}\)、
\(Q\le m^d\)，则

\[
  \Theta(m)=\log T
  \le R\log(Q/R)
  \le O(R\log m),
  \tag{475.8}
\]

所以 \(R=\Omega(m/\log m)\)。这只是在 completion-bound raw-fold 模型中的
tradeoff，不是一般 interactive-proof round lower bound。

## 命题 475.3（singleton 量词反例）

令 \(\mathcal Y=\{y^\star\}\)。取 \(y^\star=0^b\)，则对所有 \(\alpha\)，

\[
  L_\alpha(y^\star)=0,
  \tag{475.9}
\]

故零 raw query 即可精确输出。更一般地，固定 \(y^\star\) 后可把
\(\alpha\mapsto L_\alpha(y^\star)\) 硬接进 control/advice；其成本可能很大，但 raw-query
下界本身为零。

因此 ordinary soundness 或 common-proof 量词不自动给出 (475.4)。若要把定理 475.1
用于 published RW singleton，必须证明：对每个未查询坐标，存在仍落在 soundness/
correctness domain 内的可实现 completion，并要求同一个 evaluator 在这些 completions
上保持精确。这是额外 binding theorem，而不是 folding 记号本身。

## 定理 475.4（RW singleton batch-opening Closure gate）

令 \(B_n\in\{0,1\}^{N_n}\) 是 C455 的 published hard output，
\(m_n=\lceil\log_2(N_n+1)\rceil\)，且

\[
  \operatorname{CC}(B_n)
  =\Omega(N_n/\log N_n).
  \tag{475.10}
\]

设一个 classical unconditional folding/batch-opening interface 使用同一个 physical proof
\(z_n\in\Sigma_n^{P_n}\)，并由 control size \(g_n\)、至多 \(q_n\) 次 adaptive reads 的
single-valued evaluator 对所有 \(j\in[N_n]\) 输出 \(B_n[j]\)。记

\[
  \ell_n=\lceil\log_2(P_n+1)\rceil,
  \qquad
  a_n=\lceil\log_2|\Sigma_n|\rceil.
  \tag{475.11}
\]

则 C473 与 \(L_n^{\rm act}\le P_n\) 给出

\[
  g_n+q_nP_n(\ell_n+a_n)+m_n
  =\Omega(N_n/\log N_n).
  \tag{475.12}
\]

若 \(P_n\) 很大，但同一个 \(z_n\) 有一个被计价的 single-valued address evaluator，大小
为 \(s_{z,n}\)，则 C474 给出

\[
  g_n+q_ns_{z,n}+q_n(\ell_n+a_n)+m_n
  =\Omega(N_n/\log N_n).
  \tag{475.13}
\]

故 \(P_n,q_n,g_n,a_n=m_n^{O(1)}\) 不可能同时成立；在 object-scale \(P_n\) 上，
\(s_{z,n},q_n,g_n,\ell_n,a_n=m_n^{O(1)}\) 也不可能同时成立。任何候选至少进入以下
一类：

1. forcing-scale physical support、control、alphabet 或 query payment；
2. forcing-scale charged address evaluator；
3. object-scale hardwired/unpriced oracle；
4. computational binding；
5. 不再是 same-proof、single-valued、all-address recovery，例如只有 proximity acceptance
   或 target-specific transcript。

### 证明

(475.12) 是 C473 的 honest-path expansion 在 \(L_n^{\rm act}\le P_n\) 下的直接代入；
(475.13) 是 C474 的 charged address-evaluator composition。两式分别与 (475.10) 比较
即得。证毕。

## 文献边界

精准检索日期为 2026-08-19。Ben--Sasson--Bentov--Horesh--Riabzev 的 FRI 摘要给出
block length \(N\) 上 strictly-linear prover、\(2\log N\) queries 与 logarithmic
verifier，并明确对象是 Reed--Solomon interactive oracle proof of proximity；这与
(475.8) 中“用多轮避开常数轮高元 raw-query payment”相容，但 proximity acceptance
不是定理 475.4 的 single-valued all-address recovery。Lavaur--Lacan 的 Boomy 摘要明确
把 batch opening 置于 polynomial commitment 与 selective-security 模型，因此属于
定理 475.4 的 computational-binding 边界，不是无条件信息论反例。

本文不据检索未命中声称一般 batch opening 不可能。未覆盖的正向目标是一个精确定义的
non-product global relation：它既不要求 local completion，也不把 object-scale oracle
或计算承诺伪装成 address-scale Boolean evaluator，同时仍能在同一 published singleton
上给出 Closure 所需的 single-valued target binding。

## 来源

* [C455 published RW forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
* [C473 honest-path support forcing](473-rw-honest-path-support-and-exposed-history-pcpp-gate-2026-08-19.md)。
* [C474 coding-layer/address-scale Closure](474-rw-coding-layer-address-scale-closure-dichotomy-2026-08-19.md)。
* Ben-Sasson, Bentov, Horesh and Riabzev,
  [*Fast Reed-Solomon Interactive Oracle Proofs of Proximity*](https://doi.org/10.4230/LIPIcs.ICALP.2018.14),
  ICALP 2018.
* Lavaur and Lacan,
  [*Boomy: Batch Opening Of Multivariate polYnomial commitment*](https://doi.org/10.62056/an5tx4e-),
  2025.
