> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Strong LTC + RLDC 给出 message-relative robustness，但不自动固定目标（2026-08-16）

## 目的

前面的下界区分了 relaxed ACRR 与 strong ACRR。这里给出一个严格的编码层正例：
strong LTC 与 RLDC 可以组合成同一个 global codeword 上的 **message-relative**
coordinate robustness。但它不自动成为固定实例 `x` 的 ACRR，因为另一个合法
codeword 可能编码不同消息；RW 的真正缺口是把 computation/NP relation 绑定到该
codeword，而不是重复解决坐标测试。

## 引理：强 LTC/RLDC 组合为 Sim-CR code

设 `C:{0,1}^k -> Sigma^N` 是距离大于 `2delta` 的编码，并有：

1. 一个非自适应 `q_T`-query strong LTC tester `T`，在 codeword 上完美接受，且
   对任意 `y` 满足 `dist(y,C) = d`，
   \[
     \Pr[T(y)=1]\le 1-\rho(d),
   \]
   其中 `rho(d)>0` 只依赖距离；
2. 一个 `q_D`-query RLDC decoder `D_i`，当
   `dist(y,C(m))<=delta` 时，对每个 `i` 有
   \[
     \Pr[D_i(y)\notin\{m_i,\bot\}]\le \eta<1/2;
   \]
3. 在 codeword 上 `D_i(C(m))=m_i` 恒成立。

令
\[
  \rho_*:=\inf_{d>\delta}\rho(d)>0,
\]
这一步是 strong tester 在目标 decoding radius `delta` 上的固定-gap假设（标准
单调 soundness 参数中就是 `rho(delta)`）。取常数
\[
  R=\left\lceil\log(1/6)/\log(1-\rho_*)\right\rceil.
\]
定义 `Q_{i,b}`：独立运行 `T` 共 `R` 次；若有一次拒绝则拒绝，否则运行
`D_i`，并在 `D_i=b` 时接受。

则 `Q_{i,b}` 是同一个 codeword address space 上的 message-relative coordinate
verifier：

- 对 `b=m_i` 和相应的 honest codeword 完美接受；
- 对任意 `y`，若 `dist(y,C)<=delta`，距离唯一性给出一个 `m_y`，相对于该 `m_y`
  的错误 `b!=(m_y)_i` 接受概率至多
  `max(eta,1/6)<1/2`；
- 查询数为 `Rq_T+q_D`，所有坐标共用同一个 codeword。

### 证明

若 `dist(y,C)<=delta`，距离唯一性给出 `m_y`，错误接受事件包含在
`D_i(y)=1-(m_y)_i` 中，概率至多 `eta`。若 `dist(y,C)>delta`，所有 `R` 次测试
同时接受的概率至多 `(1-rho_*)^R<=1/6`。这证明了相对于候选近邻消息 `m_y` 的
固定常数 soundness；它没有绑定外部目标 `f_x`。

## 已知正例（仅限 message-relative 模型）

Goldreich--Gur--Komargodski 已构造 binary linear codes，长度为近线性规模，同时具有
strong-LTC（一侧错误）和 constant-query relaxed local decoding；论文摘要还明确将其
解释为 strong canonical PCP of proximity for linear-code membership。

因此在“消息本身就是需要恢复的 output word、且目标消息不需由外部实例绑定”的模型中，
上述组合给出一个 uniform global proof/codeword、固定地址空间和逐坐标 soundness 的
正例。这与 note 180 的 LDC barrier 相容：该构造使用 relaxed decoder，允许 `bottom`，
并非 ordinary LDC。

但对 RW/ACRR，固定实例 `x` 只有一个目标词 `f_x`。若 `m'` 的某一位不同于
`f_x`，候选 proof `C(m')` 仍会被 strong LTC 接受，并由 RLDC 解码出 `m'_i`；它会
错误地通过关于 `f_x[i]` 的声明。因此还必须增加一个 **target-binding test**，证明
消息 `m=f_x` 或证明消息属于 `H_x`。这正是 relation-PCPP，而不是 strong LTC/RLDC
本身。

## 模块化正向定理：再加 target-binding test 即得到 ACRR

设 `H_x` 是允许的消息集合，并有一个与 codeword 共用地址空间的局部测试 `Bind_x`：

- 对每个 `m∈H_x`，`Bind_x(C(m))=1` 恒成立；
- 对每个 `m∉H_x`，若 `dist(y,C(m))<=delta`，则
  `Pr[Bind_x(y)=1]<=beta_B<1/2`。

定义新的 `Q_{x,i,b}`：先运行 `R` 次 strong-LTC tester，再运行 `Bind_x`，最后运行
`D_i` 并检查输出是否为 `b`。若 `H_x` 中所有消息在坐标 `i` 上都有同一个值
`f_x[i]`，则：

\[
  \text{strong LTC}+\text{RLDC}+\text{Bind}_x
  \Longrightarrow \text{fixed-target Sim-CR/ACRR}.
\]

证明按距离分两类：远离整个 code 由 LTC 拒绝；近某个 codeword 时，若消息不在
`H_x` 由 `Bind_x` 拒绝，若消息在 `H_x` 则 singleton-coordinate 性质和 RLDC
控制错误 bit。查询数只增加 `q_B`。因此 ACRR 的真正新对象可以等价地要求为一个
near-linear、地址尺度的 **target-binding test**；坐标解码外层已有编码层正例。

## 对 RW/NP relation 的精确缺口

若把消息 `m` 取为 RW computation history，则 message-relative verifier 还缺一条：

\[
  m\in\mathcal H_x
  \quad\Longleftrightarrow\quad
  m\text{ 是满足 }C_x\text{ 的合法 history},
\]

并且该关系必须由同一个 near-linear global proof 在地址尺度上局部验证。现有
strong-LTC/RLDC 只保证“给定消息的 codeword 可测试/可解码”，不保证消息满足
NP computation relation；把 `C_x` 再套一个 PCPP 会重新引入 note 179 的 shared
pair-PCPP 与 proof-length 问题。

所以当前正向目标可以精确改写为：

> 在 strong-LTC/RLDC 的已知 message-relative 外层之上，构造一个近线性、共享的
> relation-PCPP，证明被编码消息属于 `H_x`，并保持同一坐标 decoder 的 soundness。

这比“再设计一个 coordinate decoder”更窄，也更可能形成真正的 PCP/coding theorem。

## 证据边界

- strong-LTC + relaxed local decoder 的已知正例直接见 Goldreich--Gur--Komargodski；
  其摘要明确给出近线性 binary linear codes、strong-LTC 和 constant-query RLDC。
- 本 note 的组合引理是从 tester 的距离拒绝界和 RLDC 的错误输出界直接推导的；
  它不声称已有工作把该组合用于 RW/JK 或 NP relation。
- relation-PCPP 的缺口仍由 note 179 的 shared proof/地址尺度障碍控制。

## 来源

- [Goldreich--Gur--Komargodski, Strong LTCs with relaxed local decoders](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.CCC.2015.1)
- [GM--Minzer--Weissenberg--Zheng, RLDC/PCPP constructions](https://arxiv.org/html/2512.12960)
- [note 179: pair-language PCPP and shared ACRR](179-pair-language-pcpp-does-not-solve-shared-acrr-2026-08-16.md)
