> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha binary raw-segment local inverse (2026-08-19)

## 改变的判断

Harsha 的 binary alphabet reduction 不是用 ECC image 取代 large-alphabet oracle
\(\Gamma\)，而是保留 raw \(\Gamma\) bits，再附加逐 symbol 的
\(\Upsilon=\operatorname{ECC}(\Gamma)\)。因此，在 C398 的 source-compatible fixed
serialization 上再固定公开的 component-major flattening（每个 \(F^{2D}\) ZoS symbol
按 component、再按 field bit 排列）后，只要同一 canonical proof 有 arbitrary-address
exact bit evaluator，
就能用

\[
  2\lambda,
  \qquad
  \lambda=\lceil\log_2|F|\rceil,
\tag{485.1}
\]

次 bit reads 恢复 ZoS components \(1,D+1\)，再由 C483 恢复 \(P\)。binary/ECC
表示本身不再是独立的 component-extraction 障碍；真正仍缺的是同一 proof 的 exact
arbitrary-bit access 量词。

## Source representation

令

\[
  D=3m+3,
  \qquad
  \Pi_{\rm ZoS}(x)
  =(P_1(x),\ldots,P_D(x),Q_1(x),\ldots,Q_D(x))
  \in F^{2D}.
\tag{485.2}
\]

固定公开的 field encoding

\[
  \beta:F\hookrightarrow\{0,1\}^{\lambda}
\tag{485.3}
\]

及其在合法 codewords 上的 exact inverse。在 ZoS oracle type 上令
\(\Gamma(x)=\Pi_{\rm ZoS}(x)\in F^{2D}\)；Harsha 的 \(\widetilde A\) 与 \(P\)
是其他 oracle type，本结果只用 ZoS 的 raw segment。把 ZoS symbol
\(\Pi_{\rm ZoS}(x)\in F^{2D}\) 按该公开 flattening 编码为 \(2D\lambda\) raw bits。
Harsha §5.4.3 将 large-alphabet proof
\(\Gamma\) 扩成

\[
  \Gamma\circ\Upsilon,
  \qquad
  \Upsilon(i)=\operatorname{ECC}(\Gamma(i)),
\tag{485.4}
\]

而不是只发布 \(\Upsilon\)。C398 可把 systematic prefix、raw ZoS-\(\Gamma\) segment
与 \(\Upsilon\) segment 按公开 lexicographic order 序列化；oracle tag、field point、
component 与 bit offset 之间的坐标算术为 address scale。这里的 component-major
flattening 是 source-compatible 的公开坐标重排，不是 Harsha/RW published theorem
自动提供的 evaluator。

## 定理 485.1（raw-binary ZoS-to-\(P\) local inverse）

设 \(E_{\rm bit}\) 对同一 canonical C398/component-major serialization 的任意指定 raw-\(\Gamma\)
bit address exact 返回该 bit。更具体地，可查询

\[
 E_{\rm bit}(\operatorname{ZoS},x,c,r)
 =\beta\!\left(\Pi_{\rm ZoS}(x)[c]\right)_r,
 \qquad
 x\in F^D,\ c\in[2D],\ r\in[\lambda].
\tag{485.5}
\]

则存在 exact evaluator

\[
\begin{aligned}
 \operatorname{Dec}_c(x)
   &=\beta^{-1}\bigl(E_{\rm bit}(\operatorname{ZoS},x,c,1),\ldots,
                     E_{\rm bit}(\operatorname{ZoS},x,c,\lambda)\bigr),\\
 E_P(x)
   &=g_H(x_1)\operatorname{Dec}_{D+1}(x)+\operatorname{Dec}_1(x)
    =P(x).
\end{aligned}
\tag{485.6}
\]

每次 \(P\)-evaluation 使用恰好 \(2\lambda\) 次 proof-bit reads。若一个 bit evaluator
的 Boolean circuit size 为 \(s_{\rm bit}\)，则

\[
 s_P
 \le
 2\lambda s_{\rm bit}
 +\operatorname{poly}(D,\lambda)
 +O(|H|\mu_F),
\tag{485.7}
\]

其中 \(\mu_F\) 计一个 field operation 的 Boolean cost。

### 证明

固定 \(x\)。从 raw \(\Gamma\) segment 读取 (485.5) 中

\[
 (c,r)=(1,r),(D+1,r),
 \qquad r\in[\lambda].
\]

由 (485.3) exact 恢复 \(P_1(x)\) 与 \(Q_1(x)\)。C483 的第一条 division identity
给出

\[
 P(x)=g_H(x_1)Q_1(x)+P_1(x).
\]

query count 与 circuit composition 立即给出 (485.7)。证毕。

## 推论 485.2（binary-to-systematic conditional inversion）

再加 C439/C457 的 address-scale \(\widehat C\)-evaluator、nondegenerate incidence 与

\[
 |F|>\deg(\widehat C)+2,
\tag{485.8}
\]

则对每个 aligned systematic target \(u\)，可用

\[
 O(|F|^3\lambda)
\tag{485.9}
\]

次 proof-bit reads exact 恢复 \(q(u)\)，并且

\[
 s_q
 \le
 O(|F|^3)
 \left(
   2\lambda s_{\rm bit}+s_{\widehat C}
   +\operatorname{poly}(D,|H|,\lambda,\log|F|)
 \right).
\tag{485.10}
\]

在 Harsha/RW 参数中，\(D=O(\log n/\log\log n)\)、
\(\lambda=O(\log\log n)\)，故 component decoding overhead 仍为
\(\operatorname{polylog}(n)\)。

## 精确三分

\[
\boxed{
\begin{array}{ll}
\text{raw }\Gamma\text{ segment + exact arbitrary-bit evaluator}
  &\Longrightarrow P\text{-access by (485.6)};\\
\text{raw }\Gamma\text{ segment 显式物化}
  &\Longrightarrow \text{C447 object-scale accounting};\\
\text{无上述接口}
  &\Longrightarrow \text{access/binding model exit}.
\end{array}}
\tag{485.11}
\]

因此 actual Harsha binary conversion 中不存在“ECC 遮蔽了 ZoS components”的第四分支。

## ECC-only 与 observation kernel

若另行删除 raw \(\Gamma\) 而只保留 \(\Upsilon\)，则 code injectivity 本身不推出
partial observation 可恢复目标 component。令 \(\mathcal M\) 是同一实例允许的
materializations，\(O\) 是允许的 ECC observations，\(t\) 是目标 component；在线性
差分空间 \(V=\mathcal M-\mathcal M\) 上，exact recovery 的必要条件是

\[
  \ker(O|_V)\subseteq\ker(t|_V).
\tag{485.12}
\]

例如 injective code

\[
 \operatorname{Enc}(a,b)=(a,b,a,b)
\tag{485.13}
\]

在只观测 positions \(1,3\) 时不能恢复 \(b\)。若给出被完整计价的 exact decoder，或
读取一个 source-compatible efficiently decodable ECC 的完整 \(O(\log|\Sigma|)\)-bit
symbol，则可再次恢复 \(\Gamma\)；否则必须保留 (485.12) 的 binding 缺口。该分支不是
Harsha 的 actual \(\Gamma\circ\Upsilon\) representation，因为后者已经保留 raw
\(\Gamma\)。

## 量词边界

* **Arbitrary bit access.** verifier 在随机 line/point 上读取 bits，不等于可对每个预定
  \(x\) 调用 (485.5)。published soundness 不自动生成 \(E_{\rm bit}\)。
* **Same proof.** 所有 \(2\lambda\) queries 必须访问同一次发布的 canonical
  \(\Gamma\circ\Upsilon\)，不能为不同 target 选择不同 completions。
* **Exactness.** noisy/near proof 需要额外 local correction 或 target-wise binding；
  (485.6) 只从 exact raw bits 解码。
* **No new \(P\ne NP\) claim.** 本结果关闭 component extraction，不构造 published RW
  的 arbitrary-bit evaluator，也不补 C439 的 incidence/\(\widehat C\) 接口。

## 来源

* Prahladh Harsha, *Robust PCPs of Proximity and Shorter PCPs*, §5.4.3：binary
  proof 保留 \(\Gamma\) 并附加 \(\Upsilon=\operatorname{ECC}(\Gamma)\)。
* [C398：oracle-major binary serialization compiler](398-oracle-major-binary-serialization-compiler-rw-harsha-2026-08-18.md)。
* [C483：ZoS first-division local inverse](483-harsha-zos-first-division-local-inverse-2026-08-19.md)。
* C395、C397、C439、C447、C457。
