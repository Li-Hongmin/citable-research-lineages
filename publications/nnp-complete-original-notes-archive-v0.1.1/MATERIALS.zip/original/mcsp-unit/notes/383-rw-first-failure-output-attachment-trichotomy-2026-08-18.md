> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW 首失败块的 output-attachment 三分（2026-08-18）

## 本轮判定

本 note 把 C381 与 C382 合并成一个精确的 Gate-I 判定。对实际 RW 的
canonical PCP proof，JK 的 easy 分支可以在 forcing 硬度下被排除；但 success
分支只给出一个 \(2k\)-bit block。只有在另证该 block 的 top ancestry 落入
systematic output 区间后，它才携带父表 \(B\) 的已知坐标。若 ancestry 落在
auxiliary 区间，RW Theorem 3.5 没有给出它与 \(B\) 的关系；把 outsider 直接
当作 whole-parent accessor 是量词越界。

## 记号

令

\[
 G_k:\{0,1\}^k\to\{0,1\}^{2k},
 \qquad \Pi\in\{0,1\}^{L}
\]

是 Theorem 4.1 传给 JK 的 canonical proof。令

\[
 K=\lceil\log_2(L/k)\rceil,
 \qquad \Pi^+=\Pi 0^{k2^K-L},
\]

并把顶层串分成 \(2k\)-bit blocks \(Z_{K,a}\)。设
\(I_{\rm out}\subseteq[L]\) 是 Theorem 3.5 的 systematic witness 中实际输出
字段的位置，\(|I_{\rm out}|=b\)；在 RW 稳定递推里，这个字段包含
\(B_i\)，且 \(b=2n_i\)。

若 JK 在 level \(j\) 的 block \(Z_{j,u}\) 首次失败并输出
\(y=Z_{j,u}\notin\operatorname{Range}(G_k)\)，则对任意未被截断的祖先路径
\(\epsilon_{j+1},\ldots,\epsilon_K\)，定义

\[
 L_{G,0}(z)=G_k(\operatorname{left}_k z),
 \qquad
 L_{G,1}(z)=G_k(\operatorname{right}_k z).
\]

C382 给出

\[
 Z_{K,a}=L_{G,\epsilon_K}\circ\cdots\circ
 L_{G,\epsilon_{j+1}}(y),
\tag{383.1}
\]

其中 \(a\) 是该路径对应的 top-block index。一个 outsider 因而至多直接
产生一个顶层 \(2k\)-bit block；(383.1) 不产生整个 \(\Pi\)，也不产生整个
\(B_i\)。

## 首失败附着三分

固定一个 RW stage，并假设 forcing 下界为

\[
 \operatorname{CC}(B_i)>S_i.
\]

对一次 JK 调用，以下三种情形穷尽 source-level 可能性：

### (E) easy 分支

若 JK 返回 easy，则 C381 的 self-corrector composition 给出

\[
 \operatorname{CC}(B_i)
 \le (|G_k|+1)\log(T_i+2)^{O(1)}.
\tag{383.2}
\]

所以在

\[
 (|G_k|+1)\log(T_i+2)^{O(1)}<S_i
\tag{383.3}
\]

时，easy 不可能。特别地，\(|G_k|\le k^4\)、\(T_i=n_i^{O(1)}\)、
\(S_i=\Omega(n_i/\log n_i)\) 时，\(k=\operatorname{polylog}(n_i)\)
被排除，JK 必须进入 success outsider 分支。

### (O) success 且有 output attachment

若 success outsider 的 ancestry 对应的 top block 与 \(I_{\rm out}\) 有已知、
address-scale 可计算的附着关系，则 (383.1) 至多恢复该 top block 中的
\(2k\) 个 proof bits。更一般地，若使用 \(q\) 个这样的 success blocks，且
除这些 \(2kq\) 个 block bits 外只给一个 \(d\)-bit descriptor，来恢复一个
可能输出集合 \(\mathcal B\subseteq\{0,1\}^b\)，则 exact parent binding 必须满足

\[
 2kq+d\ \ge\ \log_2|\mathcal B|.
\tag{383.4}
\]

证明只是 transcript counting：固定 decoder 后，\((q\) 个 \(2k\)-bit blocks,
\(d\)-bit descriptor\()\) 至多有 \(2^{2kq+d}\) 种取值；若它们 exact
恢复 \(\mathcal B\)，该映射必须在 \(\mathcal B\) 上单射。对完整的 \(b\)-bit
parent family，(383.4) 化为

\[
 q\ge \frac{b-d}{2k}.
\tag{383.5}
\]

因此在 \(b\gg k\) 且 \(q,d=\operatorname{poly}(\log b)\) 时，单次或少数几次
outsider 不可能完成 family-level whole-parent closure。这个下界只对已经
证明 output/parent attachment 的 block channel 计数；它不把一个未证明的
auxiliary semantic map 偷换成免费信息。

### (A) success 但无 output attachment

若 first-failure block 的 top ancestry 不在 \(I_{\rm out}\)，或其 index/path
不能由 address-scale descriptor 确定，则 (383.1) 只恢复一个 auxiliary proof
block。Theorem 3.5 的 completeness/soundness 只保证 systematic witness/output
字段和 verifier 行为；它没有保证 auxiliary \(\Pi'\) 的该 block：

* 是 \(B_i\) 的函数；
* 在不同 canonical parent 之间提供 injective fingerprint；或
* 能由一个 \(n_i^{O(1)}\)-bit、非历史规模的 descriptor 绑定回 \(B_i\)。

所以从 RW source statements 只能推出

\[
 y\notin\operatorname{Range}(G_k),
\]

不能推出 \(B_i[j]=D(y,j)\)，更不能推出整个 \(B_i\) 的地址 evaluator。任何
继续声称 closure 的方案必须明确增加以下两者之一：

1. 一个新的 auxiliary-to-output relation theorem，并把其 descriptor/strategy
   信息计入 (383.4) 的 channel；或
2. 多个独立、可验证的 output-attached blocks，使其总 payload 达到 (383.4)
   的要求。

否则该方案只是 child outsider，而不是 parent reconstruction。

## 对 RW 稳定递推的直接后果

在稳定区 \(T_i=n_{i+1}=n_i^C\) 且 forcing 给出
\(S_i=\Omega(n_i/\log n_i)\) 时，(383.3) 排除
\(k=\operatorname{polylog}(n_i)\) 的 easy 分支。此时若一次 success call
只提供一个 \(2k\)-bit block：

* 走 (O) 路线，完整 \(B_i\) family 需要
  \(q=\Omega(n_i/k)\) 次 output-attached outsiders，或支付
  \(d=\Omega(n_i)\) 的 descriptor；二者都不是 address-scale 的单次 closure；
* 走 (A) 路线，必须先证明 auxiliary block 到 \(B_i\) 的新语义绑定；现有
  Theorem 3.5/4.1 没有该接口。

这把当前 Gate-I 精确收缩为：**在 easy 已被硬度排除后，证明一个真实的
output-attached multi-block/global relation，或者证明 auxiliary block 具有
同等强度且地址尺度可求值的 parent-binding。** 单个 success outsider 本身
不再被视为 closure。

## 证据边界

* C381：easy branch 与 RW Low-Degree Self-Corrector 的组合以及 (383.2)。
* C382：half-lift 公式 (383.1)；单个 success block 至多恢复一个 top block。
* Ren--Williams Theorem 3.1：JK success 只返回 \(y\notin\operatorname{Range}(G)\)。
* Ren--Williams Theorem 3.5：systematic witness/output 与 auxiliary proof 的量词；
  未提供 auxiliary block 的 parent binding。

本 note 是一个 source-specific attachment/trichotomy theorem；它不声称
\(P\ne NP\)、一般 dPCP/RLDC 不可能性，或 published RW 已经具有 output attachment。
