> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Uniform-policy two-query exponential RLDC gate（2026-08-19）

## 本轮改变的判断

Paper 05 的 binary two-query bottom-or-cubic dichotomy 只把 bottom 识别为逃离三查询普通 LDC 升级；它没有说明在更强的 uniform-policy 子模型里 bottom 是否仍能保住近线性 proof。

Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu 的 Theorem 1
(arXiv:2602.20278, version 2, 2026-02-28) 给出一个可直接接入的新门：
binary weak adaptive 2-query RLDC，只要 perfect completeness 且成功率
\(1/2+\varepsilon\)，码长就是 \(2^{\Omega_{\delta,\varepsilon}(k)}\)。
因此，在一个固定的 per-coordinate/per-claim policy 已经同时承担正确完备性和
错误 soundness 时，bottom 不是 near-linear 的出口；它至多是离开
uniform-policy 量词的信号。

## 定理 451.1（uniform-policy two-query exponential gate）

令
\[
  \Pi:\{0,1\}^{k}\longrightarrow\{0,1\}^{P}
\]
是一个 binary common-proof map。对每个坐标 \(i\in[k]\) 和 claim
\(b\in\{0,1\}\)，固定一个（可含 public randomness 的）one-query policy
\(\tau_{i,b}\)。假设存在常数 \(0<\rho<1\) 和 \(\beta<1/2\)，使得对所有
message \(m\)：

1. **uniform-policy completeness**
   \[
     \Pr[V_{i,m_i}^{\tau_{i,m_i}}(\Pi(m))=1]=1;
     \tag{451.1}
   \]
2. **uniform-policy target-relative soundness**
   \[
     \operatorname{dist}(z,\Pi(m))\le \rho P
     \Longrightarrow
     \Pr[V_{i,1-m_i}^{\tau_{i,1-m_i}}(z)=1]\le\beta .
     \tag{451.2}
   \]

Then there is a constant \(\delta=\delta(\rho)>0\) such that the binary inline map
\[
  C(m):=m\Vert\Pi(m)\in\{0,1\}^{k+P}
\]
is a weak adaptive \((2,\delta,1-\beta)\)-RLDC. Consequently, by
Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu, for all sufficiently large \(k\),
\[
  k+P\ge 2^{\Omega_{\rho,\beta}(k)}.
  \tag{451.3}
\]
In particular, \(P\) cannot be near-linear.

### 证明

先证 proof map 的距离。若 \(m\ne m'\) 且
\(\operatorname{dist}(\Pi(m),\Pi(m'))\le\rho P\)，取
\(i\) 使 \(m_i\ne m'_i\)。把 \(\tau_{i,m'_i}\) 看作 target \(m\) 的错误 policy：
由 (451.2)，它在 \(\Pi(m')\)（相对于 \(\Pi(m)\) 的近邻）上的接受率至多
\(\beta\)；但由 (451.1)，它在 \(\Pi(m')\) 上的接受率为 \(1\)，矛盾。因此不同
proof words 的相对距离严格大于 \(\rho\)。

若 \(d\) 是 proof map 的最小绝对距离，Binary
Singleton bound 给出
\(k\le P-d+1<(1-\rho)P+1\)。因此 \(k\ge2\) 时
\(P\ge k/[2(1-\rho)]\)，从而
\[
  \frac{P}{k+P}\ge\frac1{3-2\rho}.
\]
例如取
\(\delta(\rho):=\rho/[4(3-2\rho)]\)。总 corruption 不超过
\(\delta(\rho)(k+P)\) 时，proof suffix 距离目标 proof 小于 \(\rho P\)；同时
不同 inline codeword 的距离大于 \(2\delta(\rho)(k+P)\)，所以 RLDC 邻域中的目标是唯一的。

decoder 首先查询 inline bit \(m_i\)。若读到 \(b\)，执行固定 policy
\(\tau_{i,b}\)，只再查询一次 proof symbol；接受则输出 \(b\)，否则输出
\(\bot\)。在未损坏的 codeword 上，(451.1) 给出 perfect completeness。
若 inline bit 没有被改写，输出只能是正确 bit 或 \(\bot\)。若 inline bit 被
改写为 \(1-m_i\)，则 (451.2) 给出输出错误 bit 的概率至多 \(\beta\)，所以
输出 \(m_i\) 或 \(\bot\) 的概率至少 \(1-\beta>1/2\)。这正是 binary weak
adaptive 2-query RLDC 的条件。

最后应用外部 Theorem 1，得到 (451.3)。证毕。

## 量词边界与研究后果

* 该定理不适用于一般的 \(\forall m,i\,\exists\tau_{m,i}\) 语义：若 policy
  随 target 改变，inline bit 不能告诉 decoder 应该选哪一个 policy。
* 它也不适用于 proof alphabet 大于 binary、完备性不为 1、或原 verifier
 需要两次以上 proof query 的情形；这些情形仍回到 Paper 05 的 finite-view
  / GGS barrier。
* 因而 bottom 必须分成两种：它确实可以逃离三查询普通 LDC 的 cubic
  sharpening；但在定理 451.1 的 uniform-policy 子模型里，它不能逃离
  binary two-query RLDC 的指数长度下界。
* 对 RW/JK，下一步可检验的问题不是“bottom 是否存在”本身，而是实际
  canonical history 是否能提供一个对所有 target/coordinate 共用的完备
  one-query policy。若不能，policy channel 就是 Gate-II 的真实成本。

## 证据边界

定理 451.1 是外部 2-query RLDC lower bound 与 inline compiler 的严格组合；
它不声称 published RW/JK 已满足 uniform-policy 假设，也不证明 \(P\ne NP\)。
它的独立价值是把一个此前只被称作 bottom escape 的分支，精确收窄为
“必须离开 uniform-policy 量词或 binary 2-query 窗口”。

## 来源

* Block, Blocki, Cheng, Grigorescu, Li, Zheng, Zhu,
  *Exponential Lower Bounds for 2-query Relaxed Locally Decodable Codes*,
  arXiv:2602.20278, Theorem 1, version 2 (2026-02-28):
  <https://arxiv.org/abs/2602.20278>.
* [Shared-proof coordinate robustness paper](../../rw-jk-succinct-reconstruction/papers/05-shared-proof-coordinate-robustness-barriers/paper.md).
