> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW/JK public-input family lift 的熵记账闭合（2026-08-18）

## 本轮判定

C405 的 family route 只有在 source family 拥有**不由公开输入免费支付的 hidden
entropy**时才可能产生 parent-binding barrier。本 note 核对 Ren--Williams
Lemma 3.2、Theorem 3.5 的量词后，正式关闭一个容易混淆的路线：若 family 只是
固定 machine/context 下改变公开输入 \(x\)，则 canonical history、canonical
honest proof 都是 \(x\) 的确定函数；其 family entropy 至多是 \(|x|\) bits。若
decoder 可以读取 Theorem 3.5 的公开输入，这些 bits 已在 channel 中，不再提供
C405 的非平凡压力。published Theorem 4.3 更强：它固定 \(x_0=0^{n_0}\)，并令
\(f_i\) 忽略输入，所以实际 JK call 是 singleton。

这不是对所有 target-oblivious lift 的不可能性；它把 Gate-I 的 family 入口精确
收缩为两种仍有意义的对象：隐藏于公开输入之外的 source family，或绕开 family
entropy、直接绑定 published singleton hard parent 的新定理。

## 定理 406.1（canonical-history public-input entropy bound）

固定一个 RW machine/context \(M\)，输入长度为 \(n\)。对每个
\(x\in\{0,1\}^n\)，令 \(C_x\) 是 Lemma 3.2 的 circuit，令
\(\alpha_x\) 为其 lexicographically largest satisfying assignment。若
\(\mathsf{Sel}\) 是固定、确定性的 Theorem 3.4/3.5 honest-proof selector，写

\[
  \Pi_x=\mathsf{Sel}(C_x,\alpha_x).
\]

对任意随机输入 \(X\)（支持包含在 \(\{0,1\}^n\) 中），有

\[
  H(\alpha_X)\le H(X)\le n,
  \qquad
  H(\Pi_X)\le H(X)\le n.
\tag{406.1}
\]

若 decoder 的输入包含公开 \(X\)，则把 \(X\) 计入 C405 的 message channel 后，

\[
  H(\alpha_X)\le n,
\]

所以 (405.5) 在 \(S\le n\) 的范围内只能给出平凡不等式。特别地，不能把由公开
\(x\) 诱导的 \(2^S\) 个 targets 当成 hidden product-rich family，再用 C402/C405
声称出现了 RW parent-binding contradiction。

### 证明

\(\alpha_x\) 是固定 \(C_x\) 的唯一 lexicographically largest satisfying assignment，
故 \(x\mapsto\alpha_x\) 是确定函数。固定 selector \(\mathsf{Sel}\) 也使
\(x\mapsto\Pi_x\) 为确定函数。数据处理不等式给

\[
H(\alpha_X)\le H(X),
\qquad H(\Pi_X)\le H(X),
\]

而 \(X\) 的支持大小至多 \(2^n\)，故 \(H(X)\le n\)。将公开 \(X\) 作为 decoder
已有的 channel 一并计费即可得到结论。

若 selector 允许在多个 honest proofs 中任意选取，则它不再是同一个 canonical
object；任何 selector random tape、witness choice 或额外 advice 都必须显式加入
descriptor/transcript。不能把这部分选择熵当成由 Theorem 3.5 免费提供的 hidden
family entropy。

## 定理 406.2（identity specialization 是公开输入而非 hidden parent）

取合法的 deterministic identity machine

\[
M_{\rm id}(x)=x,
\qquad r=s=0,
\qquad \ell=n.
\]

Lemma 3.2 的 history 只有 output field，且 \(C_x(\mathrm{out})=1\) 当且仅当
\(\mathrm{out}=x\)。因此

\[
  \alpha_x=x,
  \qquad H(\alpha_X)=H(X).
\tag{406.2}
\]

并不存在额外的 witness/history entropy。Theorem 3.5 的 systematic prefix 直接
承载 \(x\)；对 target-oblivious decoder，恢复 \(x\) 需要支付 \(n\) bits，正是
C390 的 public-input 分支，而不是 address-scale hidden-parent 机制。

## 定理 406.3（公开 context 的一般数据处理界）

令 \(\Theta\) 表示生成一个 RW/JK 调用的全部公开 context：machine description、
输入 \(x\)、AVOID generator \(G\)、stage/length 参数以及固定 selector 的公开
seed。只要 canonical history/proof 是确定的 source-level 对象
\[
  \alpha_\Theta=\mathsf{Hist}(\Theta),\qquad
  \Pi_\Theta=\mathsf{Proof}(\Theta),
\]
则对任意随机 context \(\Theta\)，
\[
  H(\alpha_\Theta),\ H(\Pi_\Theta)\le H(\Theta).
\tag{406.3}
\]

若 decoder 只接收一个 \(m\)-bit 的公开 context encoding \(\widehat\Theta\)，则
\(H(\Theta)\) 应替换为 \(H(\widehat\Theta)\le m\)。因此改变 \(f_i\)、\(G\) 或
stage 只能产生一个新的 context；若这些变化要被 decoder 看见，它们的全部信息
必须计入 metadata。若变化不被 decoder 看见，则得到的不是可核验的同一
source-faithful canonical family。

### 证明

\(\alpha_\Theta\) 和 \(\Pi_\Theta\) 都是 \(\Theta\) 的确定函数，直接应用数据处理
不等式。固定 machine/context 下的 C406.1 是其特例。

## 2026-08-19 source-level audit of the proof image

本轮直接核对仓库保存的 Ren--Williams TR26-118 revision 1 文本抽取，而不是只沿用
本 note 的二手概括。原文 Theorem 3.4 的 proof sketch 明确写出

\[
\Pi=(\widetilde A,P,\Pi_{\mathrm{ZoS}}),
\]

其中 \(\widetilde A\) 是 witness 的 Reed--Muller 编码，\(P\) 与
\(\Pi_{\mathrm{ZoS}}\) 是 auxiliary proof oracles；同一段只保证给定 \(C,w\)
后可以在确定性 \(\operatorname{poly}(n)\) 时间构造一个诚实 proof。Theorem 3.5
随后把 \(w\) 取为 \(C_x\) 的 lexicographically largest satisfying assignment
\(\alpha_x\)，并说明给定该 witness 可以构造 completeness proof；Theorem 4.1
再把这样选出的 \(\Pi_x\) 作为 JK 的 hard truth table。由此得到以下 source-level
修正：

1. 若固定一个确定性的 honest-proof selector，\(x\mapsto\alpha_x\mapsto\Pi_x\)
   是 public context 的确定函数；所以 proof image 没有超出 C406.1/C406.3 的
   hidden leaf entropy。
2. 若允许对同一个 \(x\) 在 completeness 存在的多个 proof 中任意换 selector，
   selector 本身就是额外的 seed/advice，必须计入 context 或 descriptor；它不能
   被 Theorem 3.5 当作免费的 product-rich family。
3. published Theorem 4.3 固定 \(x_0=0^{n_0}\)，且 \(f_i\) 忽略输入，因此每个
   stable stage 的实际 canonical proof image 是 point mass。改变 \(x\)、machine、
   \(G\) 或 stage 会改变公开 context，而不是同一个 singleton 的 hidden family。

这项核对**关闭了“靠 existential honest-proof 选择制造 hidden leaf entropy”**的
黑箱入口；它没有证明一个固定 proof 的递归 leaf entropy 必然塌缩到零，也没有给出
systematic-output attachment、whole-parent evaluator 或新的 global relation。因而
C426 的剩余三分仍是精确边界：必须证明 actual proof image 的非平凡 leaf collapse，
证明递归 leaves 已附着 systematic output，或离开 common target-independent
\(G_k\)-range closure。

**来源定位。** 本地抽取
`units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md`
的 Theorem 3.4 proof sketch（约第 11--12 页）、Theorem 3.5 proof（约第 13 页）和
Theorem 4.1 proof（约第 14--15 页）给出上述量词；它们只支持“给定 witness 的
正向构造”，不支持“由 proof semantics 自动得到 address-scale 逆”。

## published RW singleton 的推论

Theorem 4.3 在每一层固定

\[
  x_0=0^{n_0},
  \qquad
  f_i(x)=B_i0^{T_i-2n_i},
\]

其中 \(f_i\) 与输入 \(x\) 无关，并只调用

\[
  \mathsf{Solve}_{f_i}(x_0,G_{n_{i+1}}).
\]

所以固定 \(i\) 时，\(C_{x_0}\)、\(\alpha_{x_0}\) 和 canonical honest proof
\(\Pi_{x_0}\) 都是 point mass。把 \(x\) 改成别的公开输入并不会生成新的 parent，
因为 \(f_i\) 忽略 \(x\)；把 \(f_i\)、\(G\) 或 stage 改掉则改变了 machine/context，
不是同一个 common-proof object 的 family lift，变化的信息必须计入公开 metadata。

## 对 Closure 计划的实际后果

C405 的 public-input 修正现在可作路线级关闭：

1. **关闭的路线：** 固定 RW/Harsha context、仅枚举公开 \(x\)，再把
   \(S>n\) 的 hidden family entropy 归因于 canonical history。
2. **仍开放的正攻：** 证明一个真正不由公开输入携带的 source family，并逐项核对
   source serialization、canonical selector、JK alignment 与 hard-target 条件；
   或者直接证明 published singleton 的 address-scale whole-parent evaluator。
3. **不能偷换：** 允许每个 \(x\) 另选一个 witness/proof、把 stage 或 machine
   description 当作免费 key，都会改变 common object 或增加 descriptor entropy。

因此下一步不再对公开 \(x\)-family 做 support 穷举。若不能给出 hidden source
mechanism，family/product-rich closure 入口应正式停止，研究转向 singleton-specific
attachment、systematic witness 的 (H_{\rm wit}) 递归 closure，或新的 global
relation theorem。

## 证据边界

* Ren--Williams Lemma 3.2：\(C_x\) 的 history 顺序为
  ((y_1,\ldots,y_r,\mathrm{out},z_{i,j}))，并取 lexicographically largest
  satisfying assignment。
* Ren--Williams Theorem 3.5：诚实 proof 的 systematic Reed--Muller prefix
  包含该 canonical assignment 的 (\mathrm{pfx},\mathrm{out}) 字段；proof selector
  在给定 (C_x,w) 后是确定性构造。
* Ren--Williams Theorem 4.3：固定 \(x_0\)，且 \(f_i\) 忽略输入；published call
  因而是 singleton。
* C390/C405 的信息界仍然有效，但必须区分 hidden target entropy 与公开输入
  entropy。本 note 不证明 \(P\ne NP\)，也不排除 x-aware compiler 或新的 hidden
  source family。

## 来源

- Ren--Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin--Arthur Queries*, ECCC TR26-118 revision 1，Lemma 3.2、Theorem 3.5、
  Theorem 4.3。
- [C390](390-harsha-family-lift-payload-barrier-2026-08-18.md)。
- [C405](405-recursive-closure-parent-binding-trichotomy-2026-08-18.md)。
