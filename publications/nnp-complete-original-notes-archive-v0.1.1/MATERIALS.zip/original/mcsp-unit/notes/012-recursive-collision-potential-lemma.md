> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 递归 affine-collision 势：一个可行的 quasi-additive 模板

## 1. 设置

令 (C=X\times Y)，
(mathcal Hsubseteq 2^C) 为一个 cell 超图。假设

\[
R\in\mathcal M(T_\oplus)
\quad\Longrightarrow\quad
 h\not\subseteq R\quad(\forall h\in\mathcal H).
\tag{H-ind}
\]

也就是说，每个 affine-parity 单色矩形都避开 (mathcal H) 的超边。
对 (h\in\mathcal H)，写 (q_h=|h|)，并取

\[
g_h:\{0,1,\ldots,q_h\}\to\mathbb R,
\qquad
g_h(a)+g_h(b)\ge g_h(a+b)
\quad(a+b\le q_h),
\qquad g_h(q_h)=0.
\tag{SA}
\]

给定非负权 (lambda_h)，定义

\[
K(R)=\sum_{h\in\mathcal H}\lambda_h,g_h(|h\cap R|).
\tag{1}
\]

## 2. 递归势引理

**Lemma 1.** 对任意矩形二分 (R=V\mathbin{\dot\cup}W)，有

\[
K(V)+K(W)\ge K(R),
\qquad K(C)=0.
\tag{2}
\]

**证明。** 对每个 (h)，置

\[
a=|h\cap V|,
\qquad b=|h\cap W|.
\]

则 (a+b=|h\cap R|\le q_h)，故 (SA) 给出

\[
g_h(|h\cap V|)+g_h(|h\cap W|)
\ge g_h(|h\cap R|).
\]

乘以 (lambda_h\ge0) 后求和即得 (2) 的第一式。根矩形 (C) 含有整条 (h)，故

\[
K(C)=\sum_h\lambda_h g_h(q_h)=0.
\qquad\square
\]

令 (m=|C|)。对 (R\ne C) 定义

\[
\psi_{c,R}=\frac{K(R)}{m-|R|}
\qquad(c\notin R),
\tag{3}
\]

并任意定义 (c\in R) 时的 (psi_{c,R})。则

\[
\sum_{c\notin R}\psi_{c,R}=K(R).
\]

由 Lemma 1，(3) 满足 Kamiyama--Ueno quasi-additive LP 的所有递归约束。因此，只要选择 (phi_c) 使

\[
\sum_{c\in R}\phi_c+K(R)\le1
\qquad(R\in\mathcal M(T_\oplus)),
\tag{4}
\]

就得到一个可行解，其目标值为 (sum_cphi_c)。

## 3. 最小 odd--odd collision 的具体势

若 (h=\{c_1,c_2,c_3,c_4\}) 含有不交奇子集 (I,J\) 满足

\[
\bigoplus_{i\in I}x_i
=
\bigoplus_{j\in J}y_j,
\qquad |I|,|J|\equiv1\pmod2,
\tag{5}
\]

则 (h) 不可能包含于 affine-parity 单色矩形。取

\[
g(0),g(1),g(2),g(3),g(4)=(0,1,0,-1,0).
\tag{6}
\]

全部 (a+b\le4) 的情形直接给出

\[
g(a)+g(b)\ge g(a+b).
\]

于是

\[
K_h(R)=
\mathbf 1_{|h\cap R|=1}
-
\mathbf 1_{|h\cap R|=3}
\tag{7}
\]

是合法递归势。单色矩形不能有 (|h\cap R|=4)，所以 (7) 暴露了第一种真正的递归补偿机制：

\[
\text{三命中负势}quad\leftrightarrowquad\text{一命中正势}.
\]

若 (mathcal H_4) 是全部四点 odd--odd collisions，

\[
K(R)=\sum_{h\in\mathcal H_4}\lambda_h
\left(
\mathbf 1_{|h\cap R|=1}-
\mathbf 1_{|h\cap R|=3}
\right)
\tag{8}
\]

则 Frontier B 的新证明义务严格变成：选择 (lambda_h\ge0) 和 (phi_c)，使 (4) 成立且

\[
\sum_{c\in E_a\times NO_b}phi_c>N^{1.01}.
\tag{9}
\]

## 4. 已关闭的退化情形

若 (K) 是 cell-additive，

\[
K(R)=\sum_{c\in R}w_c,
\qquad \sum_{c\in C}w_c=0,
\tag{10}
\]

则递归约束取等号。对均匀随机 affine parity 叶，任意 cell 被包含的概率为常数 (q>0)（按是否把方向和常数独立计数，(q=1/2) 或等价归一化的 (1/4)）。因此对所有单色叶约束取平均，

\[
q\sum_{c\in C}(\phi_c+w_c)le1,
\]

给出 (sum_cphi_c=O(1))。所以 additive signed 势也不能产生超线性目标；必须使用 (8) 这样的高阶 collision spectrum。

## 5. 目前的边界

Lemma 1 是完整证明。尚未证明的是 MCSP 语义的 collision-expansion：对每个 affine-separable (R\subseteq E_a\times NO_b)，三命中 collision 的加权质量是否能系统性超过一命中质量。小规模全碰撞 LP 尚未观察到超线性值；这只说明均匀 (lambda_h) 不足，不否定按语义自适应加权的 (8)。

因此下一实验应直接搜索 (lambda_h) 的结构（按 (x)-或 (y)-投影、collision codimension、及低电路描述复杂度分层），而不是再搜索新的 dimension-only ansatz。

## 6. 更强的定向 collision 势

计数型 g 仍把同一超边的所有三命中模式混在一起。可以保留一个定向三元组

$$
h=T\mathbin{\dot\cup}\{s\},\qquad |T|=3.
$$

并定义

$$
G_{T,s}(R)=\mathbf 1_{s\in R}-\mathbf 1_{T\subseteq R}.
$$

若 T 与 s 组成 odd--odd affine collision，则单色矩形不能同时含 T 与 s。对任意
R=V disjoint-union W，

$$
G_{T,s}(V)+G_{T,s}(W)-G_{T,s}(R)
=\mathbf 1_{T\subseteq R}-\mathbf 1_{T\subseteq V}-\mathbf 1_{T\subseteq W}\ge0.
$$

这里 singleton indicator 对不交并可加，而非空 T 不可能同时包含于两个不交子集；并且
G_{T,s}(C)=0。故

$$
K(R)=\sum_{(T,s)}\lambda_{T,s}G_{T,s}(R),\qquad \lambda_{T,s}\ge0
$$

直接满足 quasi-additive recursion。对单色 R，贡献为

$$
G_{T,s}(R)=
\begin{cases}
-1,&T\subseteq R\ (s\notin R),\\
+1,&s\in R\ (T\not\subseteq R),\\
0,&\text{otherwise}.
\end{cases}
$$

于是未决命题被精确化为：能否按 E_a times NO_b 的语义选择定向碰撞族，使每个大
affine-separable R 的 T 覆盖质量超过 spoiler s 质量。若能，再取 phi 使

$$
\sum_{c\in R}\phi_c+K(R)\le1
$$

即可得到 Frontier B 所需的超线性 QA 目标。该势不依赖仿射维数，只记录“一个三元组何时被递归矩形完整捕获，以及其唯一 collision spoiler 何时出现”。
