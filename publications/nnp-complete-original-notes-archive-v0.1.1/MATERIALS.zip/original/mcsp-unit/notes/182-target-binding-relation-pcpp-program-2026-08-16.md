> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Target-binding relation-PCP 是 ACRR 的唯一剩余主接口（2026-08-16）

## 结论地位

这是一个 theorem program，不是已证明的 PCP 定理，也不声称已经得到 `P != NP`。它把
旧 note 181 的编码层正例与 note 179 的 shared-proof 缺口合并成一个可证伪接口。

## 模块化定理

设 `C:{0,1}^k -> Sigma^N` 是具有固定检测半径 `δ` 的 strong-LTC，且有 `q_D` 查询
RLDC `D_i`。设 `H_x` 是实例 `x` 的合法 computation messages。若存在与 `C` 共用
地址空间的 `q_B` 查询测试 `Bind_x`，满足

\[
\begin{aligned}
 m\in H_x &\Longrightarrow Bind_x(C(m))=1,\\
 m\notin H_x,\ dist(y,C(m))\le\delta
 &\Longrightarrow \Pr[Bind_x(y)=1]\le\beta_B<1/2,
\end{aligned}
\]

并且 `H_x` 中所有消息的输出坐标 `i` 相同，则 strong-LTC、RLDC 和 `Bind_x` 组合成
固定目标的 coordinate-robust verifier。LTC 负责远离 code 的候选 proof，RLDC 负责
近合法 codeword 的坐标读取，`Bind_x` 负责排除“另一个合法 codeword 对应错误消息”。

若 `ρ_*` 是 strong-LTC 在 `d>δ` 上的拒绝下界，取

\[
R=\left\lceil\log(1/6)/\log(1-\rho_*)\right\rceil .
\]

则总查询数为 `Rq_T+q_B+q_D`。这一步是直接推导，未使用 RW/JK 特殊性质。

## 为什么这正是 RW 的缺口

RW history 的关系是

\[
  H_x=\{m:m\text{ 是满足 }C_x\text{ 的合法 computation history}\}.
\]

现有 strong-LTC/RLDC 只给“给定消息的 codeword 可测试、可局部解码”；它们不证明
`m\in H_x`。通用 pair-language PCPP 可处理公开 `y` 与私有 witness，但其 proof 一般
依赖 `(x,y)` 且长度是计算规模的多项式，因此不提供一个同时服务所有 `(i,b)` 的
`Pi_x`，也不满足 `poly(n,log T)` 地址尺度。把不同坐标分别编译后再拼接，会重新违反
同一 proof/address-space 和 word-consistency 量词。

## 顶级攻击的二分

### 正向命题

构造一个 shared target-binding relation-PCP，使：

1. 一个固定 `Pi_x` 服务所有坐标和声明位；
2. `Bind_x` 在合法 history 上完备，对非法 message 在近 codeword 上有常数 gap；
3. `N=\widetilde O(k)` 或给出明确的最优超线性 tradeoff；
4. `q_B`、proof map、decoder 和统一生成时间处于地址尺度；
5. 不把完整 history 或 nonuniform advice 隐藏在 `Pi_x`/key 中。

若这条命题成立，它本身是独立的 PCP/coding theorem；再按 note 181 接入 ACRR/RW。

### 反向命题

在固定 proof、公共地址空间、坐标级错误声明鲁棒和上述地址尺度下，证明：

- strong completeness 会给出 LDC，从而承受三查询 LDC 长度下界；或
- relaxed/`bottom` 版本至少给出 RLDC，并承受线性 RLDC 的超线性长度下界；或
- 任意 `Bind_x` 都必须支付超线性 proof、query、地址或 uniformity 代价。

这比“某个 dPCP 复制失败”一般得多，且不依赖特定 decoder 的实现细节。

## 最小实验与停止条件

下一次只允许检验一个候选 `Bind_x`，并输出完整的
`(N,q_B,q_total,uniformity,shared-proof)` 账本。出现以下任一情况即关闭该候选：

- proof 随坐标或声明位变化；
- soundness 只在平均坐标或 list 意义成立；
- 需要物化 `q`-bit seed、完整 history 或非均匀 advice；
- 只得到 `E^NP`/全表尺度而非 `poly(n,log T)`；
- 无法把非法 message 的拒绝事件与同一 codeword 地址空间绑定。

## 证据边界

- strong-LTC + RLDC 的 message-relative 组合和上述 `Bind_x` 模块化定理见旧 note 181；
- pair-language PCPP 的公开语义与其 proof/长度限制见旧 note 179；
- ACRR 接入 RW/JK 的条件充分性见旧 note 121；
- 本 note 没有把这些条件性结果升级成一般 impossibility 或 `P != NP`。
