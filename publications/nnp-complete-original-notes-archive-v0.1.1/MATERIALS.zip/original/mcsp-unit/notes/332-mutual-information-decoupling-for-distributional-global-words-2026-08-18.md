> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mutual-information decoupling for distributional global words

## Status and scope

This note gives a closure theorem between ordinary distributional soundness and the
same-word hypothesis used by indexed-channel/RLDC arguments. It is not a \(P\ne NP\)
theorem and does not claim that the mutual-information hypothesis is supplied by an
existing dPCP. The point is to identify the information quantity that must be small when
the ideal word is allowed to depend on the sampled coordinate and local transcript.

The result complements the policy-level \(I(M;S)\) mixture closure in C330 and the
rectangular-hull criterion: the random ideal word is decoupled from the entire local
transcript, not merely from the coordinate marginal or a policy descriptor.

## Theorem (transcript-information decoupling)

Let \(J\in[M]\) be the sampled coordinate, let \(X\in\Gamma\cup\{\bot\}\) be the local
decoder output, and let \(T=(J,X,U)\) be any finite transcript containing \(J\) and \(X\).
The auxiliary variable \(U\) may contain verifier randomness, proof answers, or any public
local view. Let \(Y\in\mathcal Y\subseteq\Gamma^M\) be a random ideal word, with no
independence assumption from \(T\). Count \(X=\bot\) as an error. If

\[
  \Pr[X\ne Y_J]\le\varepsilon,
  \qquad I_2(Y;T)\le\iota,
\tag{332.1}
\]

where mutual information is measured in bits, then there is a fixed
\(y^\star\in\mathcal Y\) such that

\[
  \Pr_T[X\ne y^\star_J]
  \le
  \varepsilon+\sqrt{\frac{\ln 2}{2}\,\iota}.
\tag{332.2}
\]

### Proof

Let \(P\) be the joint law of \((Y,T)\) and let \(Q=P_Y\otimes P_T\). Pinsker's
inequality with bits gives

\[
  \lVert P-Q\rVert_{\mathrm{TV}}
  \le
  \sqrt{\frac{\ln 2}{2}I_2(Y;T)}
  \le
  \sqrt{\frac{\ln 2}{2}\,\iota}.
\tag{332.3}
\]

For \(E=\{(y,t):X(t)\ne y_{J(t)}\}\), (332.1) and (332.3) imply

\[
  Q(E)\le
  \varepsilon+\sqrt{\frac{\ln 2}{2}\,\iota}.
\tag{332.4}
\]

Under \(Q\), \(Y\) is independent of \(T\), so \(Q(E)\) is the average, over
\(y\sim P_Y\), of \(\Pr_{T\sim P_T}[X(t)\ne y_{J(t)}]\). One \(y^\star\) in the
support of \(P_Y\) attains at most this average, proving (332.2). \(\square\)

## Converse and coding consequence

The theorem has an exact contrapositive form. If every fixed valid word has transcript
error at least \(\varepsilon+\gamma\), then

\[
  I_2(Y;T)\ge\frac{2\gamma^2}{\ln 2}.
\tag{332.5}
\]

Thus a distributional construction that genuinely avoids every fixed global word must
expose a quantitative amount of information about the ideal word in the local transcript.
This is a transcript-information cost, not automatically a seed-length lower bound.

Suppose in addition that \(\mathcal Y=\{y^{(1)},\ldots,y^{(L)}\}\) has relative Hamming
distance at least \(\Delta\), and put

\[
  \varepsilon_\star=
  \varepsilon+\sqrt{\frac{\ln 2}{2}\,\iota}.
\tag{332.6}
\]

If \(\varepsilon_\star<\Delta/2\), (332.2) enters the indexed-channel regime:
\(O(\log L/(\Delta-2\varepsilon_\star)^2)\) independent coordinate samples identify
the fixed candidate word by the score test. This is an RLDC consequence only when the
same \(y^\star\) can be selected for every proof in the relevant positive-radius
neighborhood (for example, because one common seed/coupling is fixed before the proof is
chosen). Pointwise application of (332.2) may produce \(y^\star_z\) depending on the
nearby proof \(z\), which is not a codeword map and does not suffice for RLDC soundness.

The missing uniformity is real even at zero error and zero information. Take two nearby
proof states \(z_0,z_1\), two separated valid words \(y^{(0)},y^{(1)}\), and let the
ideal-word law and local output be deterministically \(Y=X=y^{(b)}\) on \(z_b\). For
each \(z_b\), (332.1) holds with \(\varepsilon=\iota=0\); nevertheless no single word
explains both proof states. This is a two-row minimax obstruction, not a Pinsker loss.

The resulting route is

\[
  \text{small }I_2(Y;T)
  \Longrightarrow
  \text{fixed global word for one transcript law}
  \quad
  \begin{array}{c}
  \text{same word uniformly over nearby proofs}\\[-2pt]
  \Longrightarrow \text{indexed channel/RLDC}
  \end{array}
\tag{332.7}
\]

## Why the transcript, not only the coordinate, matters

Controlling \(I_2(Y;J)\) alone is insufficient. Let \(Y\) be a uniformly random codeword,
let \(J\) be uniform and independent of \(Y\), and let \(X=Y_J\). Then
\(I_2(Y;J)=0\), although the local output is generated from the ideal word. The relevant
variable is \(T=(J,X)\), for which \(I_2(Y;T)>0\). The theorem charges the information
revealed by the actual local view; otherwise a coordinate-independent random ideal word
could incorrectly be treated as a fixed-word explanation.

Likewise, a bound on \(I(Y;S)\) for a policy descriptor \(S\) does not by itself imply
(332.1) when the local verifier output carries additional target information. Conversely,
(332.1) applies even without a finite policy descriptor: it only asks for a joint law of
the ideal word and local transcript.

## Boundary for dPCP/RW use

Ordinary DHK distributional soundness does not state \(I_2(Y;T)=o(1)\), nor does it fix a
single \(Y\) before the coordinate, local randomness, and nearby-proof choice are sampled.
Hence it does not automatically trigger (332.2), and even pointwise decoupling does not
provide the uniform near-proof word needed by an RLDC. A proposed simultaneous
coordinate-robust dPCP must either

1. prove a small transcript-information bound and invoke this theorem to obtain a common
   word and the indexed-channel/RLDC consequence; or
2. prove the lower bound (332.5) and charge the resulting target information to its
   alphabet, query, descriptor, or proof length.

The result is intentionally weaker than a general impossibility theorem: a short global
seed can generate a highly correlated word, so mutual information need not lower-bound the
seed length. It is nevertheless stronger than a coordinatewise rectangularity test,
because it gives a quantitative sufficient condition for global-word closure under a
random ideal object.

## Relation to existing project results

Theorem 2.1 of the distributional-soundness paper applies after (332.2) has produced a
fixed separated word. C253 assumes same-seed word consistency directly; (332.2) gives a
different sufficient interface based on transcript decoupling. C330 charges \(I(M;S)\)
at the target-policy level; (332.5) charges \(I(Y;T)\) at the actual local-view level.
These quantities should not be conflated.
