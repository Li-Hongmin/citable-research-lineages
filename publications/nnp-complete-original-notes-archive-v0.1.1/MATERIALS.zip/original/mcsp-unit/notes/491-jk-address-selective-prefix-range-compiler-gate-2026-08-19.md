> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK address-selective prefix-range compiler gate（2026-08-19）

## 结论

令

\[
B=B_1\Vert\cdots\Vert B_m,
\qquad
B_j\in\{0,1\}^{2k}.
\]

考虑一族 AVOID generators

\[
G_r:\{0,1\}^k\to\{0,1\}^{2k},
\qquad r\in[m].
\]

若存在两个共同、被完整计价的 circuits：

\[
C_G(r,u)=G_r(u),
\qquad
U(r,j)\in\{0,1\}^k,
\]

并且 successor seeds 满足

\[
G_{j+1}\bigl(U(j+1,j)\bigr)=B_j
\qquad(j<m),
\tag{491.1}
\]

则

\[
\boxed{
\operatorname{CC}(B)
\le
O\!\left(
|C_G|+|U|+\operatorname{poly}(k,\log(m+2))
\right).
}
\tag{491.2}
\]

因此，对 forcing-hard singleton

\[
\operatorname{CC}(B)\ge S_B,
\]

任何统一的 address-selective generator/seed compiler 都必须支付

\[
|C_G|+|U|+\operatorname{poly}(k,\log(m+2))
=\Omega(S_B).
\tag{491.3}
\]

在 \(k=\operatorname{polylog}|B|\) 与
\(S_B=\Omega(|B|/\operatorname{polylog}|B|)\) 的窗口中，
\(C_G\) 与 \(U\) 不可能同时是 address-scale。

## 证明

给定 \(B\) 的 bit address \(a\)，用
\(\operatorname{poly}(k,\log(m+2))\)-size Boolean arithmetic 计算 block index
\(j\in[m]\) 与 block 内 offset \(t\in[2k]\)。

若 \(j<m\)，令 \(r=j+1\)，并计算

\[
u=U(j+1,j).
\]

由 (491.1)，

\[
C_G(j+1,u)=G_{j+1}(u)=B_j.
\tag{491.4}
\]

从该 \(2k\)-bit 输出选择第 \(t\) bit 即得到 \(B[a]\)。这条分支只调用一次
\(U\) 和一次 \(C_G\)，故成本不乘 \(m\)。

若 \(j=m\)，把最后一个 \(2k\)-bit block \(B_m\) hardwire，并用 \(O(k)\)-size
multiplexer 输出其第 \(t\) bit。合并两支得到 (491.2)，再与
\(\operatorname{CC}(B)\ge S_B\) 比较即得 (491.3)。

## JK prefix-range 推论

设第 \(r\) 次 address-selective JK 调用试图让顶层的第 \(r\) 个 block 成为首个
non-range block。其必要条件之一是

\[
\forall j<r\ \exists u_{r,j}\in\{0,1\}^k:
\quad
G_r(u_{r,j})=B_j,
\qquad
B_r\notin\operatorname{Range}(G_r).
\tag{491.5}
\]

若 proposed Closure interface 还以共同 circuit \(U(r,j)\) 产生这些 preimages，
则 (491.1) 是 (491.5) 的 diagonal \(r=j+1\)，所以直接适用 (491.2)。
换言之：

\[
\boxed{
\text{address-selective prefix range programming}
+
\text{uniform seed selection}
\Longrightarrow
\text{hard-parent address evaluator}.
}
\tag{491.6}
\]

nonmembership \(B_r\notin\operatorname{Range}(G_r)\) 与 returned outsider 的值对
(491.2) 并非必要；仅 uniform prefix coverage 已经足够重构除最后一块外的全部
parent，最后一块只有 \(2k\) bits。

若前缀中有 \(d_r\) 个 distinct blocks，则 (491.5) 还要求

\[
d_r\le |\operatorname{Range}(G_r)|\le 2^k.
\tag{491.7}
\]

这是纯容量必要条件；它不替代 (491.2) 的 selector-cost 结论。

## 尖锐量词边界

### Seeds 只存在

若只知道

\[
\forall j<m\ \exists u_j:\quad G_{j+1}(u_j)=B_j,
\]

而没有共同 \(U\)，则只能把 diagonal seed table

\[
(u_1,\ldots,u_{m-1})\in\{0,1\}^{k(m-1)}
\]

hardwire。由同一证明仅得到

\[
\operatorname{CC}(B)
\le
O\!\left(
|C_G|+k(m-1)+\operatorname{poly}(k,\log(m+2))
\right).
\tag{491.8}
\]

该 \(k(m-1)\) 项可以携带 message-scale 信息，不能由 seed 的逐点存在性删除。
Ren--Williams Theorem 3.1 在某层发现 non-range block 后立即返回；源文不会为
该层其他 in-range blocks 输出共同 seed selector。因此 actual JK success transcript
不提供 \(U\)。

### Per-call descriptors

若

\[
C_G(r,\sigma_r,u)=G_r(u)
\]

使用 \(d\)-bit descriptor \(\sigma_r\)，则必须计入生成
\(\sigma_r\) 的共同 circuit \(V(r)\)。此时 (491.2) 的右端增加 \(|V|\)。
若只给 descriptor table，则计入该表的 random-access circuit complexity；朴素
ROM 展开成本为 \(O(md)\)。逐 \(r\) 存在 small \(G_r\) 而没有共同 compiler
不足以推出 address-scale Closure。

### Adaptive seed generation

若 seed 由有限 adaptive computation 产生，则把其 transition/control 完整展开后
计入 \(|U|\)。若 computation 访问 fixed proof/ROM，则其 support 进入 C471。
未计价 unit-cost oracle 或地址依赖 physical proof 是 model exit，不是
(491.2) 的反例。

## 与既有结果的关系

* C417 计价一个 generator 下 returned outsiders 的 shared half-lift DAG。
  C491 处理不同 \(G_r\) 之间的 prefix-range programming，因而不被 C417 的
  DAG 定义直接覆盖。
* C471/C482 已说明任意 common-target extractor 必须支付 forcing scale。
  C491 的新增量是 source-specific compiler：每个 parent address 只需一次
  \(U\) 与一次 \(C_G\)，从而给出比枚举所有 calls 更尖的 (491.2)。
* C488 说明完整 first-failure frontier 支付 \(k2^i\) support；C491 说明试图通过
  多个 address-selected generators 避开完整 frontier 时，uniform seed map 本身
  已经是 parent evaluator。
* C489 证明 success output 对一般 parent family 非注入；C491 是独立的
  singleton circuit-cost gate，不使用 family entropy。

## 证据边界

本结果只关闭带有共同 generator compiler 与共同 seed selector 的
address-selective JK interface。特殊低复杂度或高度重复的 \(B\) 可以有小
prefix covers；纯 unordered range containment 也可能成立。若没有可计价的
seed/address map，这些存在性事实不能逐地址恢复 \(B\)，故尚未满足 Closure Gate I。

本结果不证明一般 AVOID generator 下界、不排除新 non-half-lift global relation，
也不证明 \(P\ne NP\)。
