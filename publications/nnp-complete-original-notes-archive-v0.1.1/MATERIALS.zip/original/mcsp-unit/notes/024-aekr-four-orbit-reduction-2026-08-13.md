> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# affine-biclique AEKR：四轨道严格约化（2026-08-13）

> **更正。** 本文的四轨道约化仍成立，但文中保留的最大叶命题 AEKR\(_0\) 已被 [027](027-aekr-max-leaf-counterexample-2026-08-13.md) 的 (N=3) 显式族反驳。含 thinning 的原始 AEKR 仍未判定。

## 结论

令 (R_0=A_0\times B_0) 为一个固定 affine-parity 最大叶，
\(\mathcal T_0=\{T\in\mathcal T:T\subseteq R_0\})。对行列独立以概率
\(1/2\) 保留，记所得子矩形为 (R(U,V))，并令

\[
A(U,V)=\mathbf 1\{\exists T\in\mathcal T_0:T\subseteq R(U,V)\}.
\]

若 \(\mathcal T\) 两两相交，则

\[
\boxed{\Pr_{U,V}[A(U,V)=1]\le\frac14.}
\tag{1}
\]

### 证明

固定一组 \((U,V)\)。考虑四个等概率轨道

\[
(U,V),\quad(\bar U,V),\quad(U,\bar V),\quad(\bar U,\bar V).
\]

若其中两个不同轨道都使 (A=1)，则存在 (T,T'\in\mathcal T_0)，分别完全包含在这两个子矩形中。两个轨道至少在行侧或列侧互补，因此这两个矩形不含共同 cell，遂 (T\cap T'=\varnothing)，矛盾。故四个轨道至多一个使 (A=1)，得到 (1)。

## 对全局 AEKR 的充分约化

令

\[
B(R_0)=\mathbf 1\{\exists T\in\mathcal T:T\subseteq R_0\}.
\]

则由 (1)

\[
\Pr[A]\le\frac14\Pr[B].
\tag{2}
\]

所以原目标

\[
\Pr[A]\le\frac1{16}
\]

在证明最大叶界的路线中，原本只剩一个最大叶 affine-EKR 命题：

\[
\boxed{\Pr_{R_0}[B(R_0)=1]\le\frac14.}
\tag{AEKR$_0$}
\]

这里必须使用每个 \(T\cup\{s\}\) 是 affine collision；但 [027](027-aekr-max-leaf-counterexample-2026-08-13.md) 给出满足当前 odd--odd 定义的 \(N=3\) 反例，命中率为 \(5/16\)。因此 AEKR\(_0\) 已关闭为假。

## 精确小例与边界

### 无公共核但达到 (AEKR\(_0\)) 的例子

取 (N=3)、(X=\{0,1,2\})、(Y=\{3,4,5\})、(s=(0,3))，以及

\[
a=(1,3),\quad b=(2,4),\quad c=(2,5),
\qquad
\mathcal T=\{\{a,b\},\{b,c\},\{c,a\}\}.
\]

三条 (T\) 两两相交、无公共 cell，且每个 (T\cup\{s\}) 是 affine collision。直接枚举 (2^{N+1}) 个最大叶给出

\[
\Pr[B]=\frac14,
\qquad
\Pr[A]=\frac3{128}<\frac1{16}.
\]

因此 (AEKR\(_0\)) 的常数 (1/4) 不能在这一层面改进；四轨道后仍有严格余量。

### 另一种无公共核的三角族

在 (N=3)、(X=\{0,1,2\})、(Y=\{3,4,5\})、(s=(0,3)) 下，cell 索引按
\((0,3),(0,4),(0,5),(1,3),(1,4),(1,5),(2,3),(2,4),(2,5)) 排列。集合

\[
\{(2,5),(0,4)\},\quad
\{(2,5),(1,3)\},\quad
\{(0,4),(1,3),(2,3)\}
\]

两两相交但无公共核；其最大叶命中概率为 (1/8)，故远低于上界。

## 当前未决点

含 row/column thinning 的完整 AEKR 仍未证明或反驳。参数空间表示可能有用：令 \(z=(r,t)\in\mathbb F_2^{N+1}\)，

\[
H_c=\{z:r\cdot x_c=t,\ r\cdot y_c=1-t\},
\qquad L(T)=\bigcap_{c\in T}H_c.
\]

每个 (H_c) 是 codimension-2 affine flat；collision 条件是
\(L(T)\cap H_s=\varnothing\)。将参数空间商掉
\(\operatorname{dir}(H_s))\) 后得到 \(\mathbb F_2^2\)；每个非空 \(L(T)\) 的投影避开 (0)，因而落在三条非零 affine 线之一或非零点。若同一投影线上的所有 (T) 还共享一个 cell (c)，则并集包含于“(c) 被叶包含”事件，概率至多 (1/4)。但“同一投影线”本身并不推出公共 cell：小规模枚举给出了无公共核的同线三角族。因此，剩余问题不是简单的三种 singleton projection 计数，而是证明碰撞条件与两两相交性共同限制这些投影族的并集概率。

此前的同线和 singleton 例子只是边界证据；027 的新族说明最大叶 \(1/4\) 上界本身不能作为完整 thinning 证明的中间步骤。
