> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Overlap-aware DPT obstruction for vertex-varying tags (2026-08-18)

## Theorem

Let \(U_0,U_1\subseteq X(k)\) be disjoint clusters with masses \(\mu_0,\mu_1\). For
\(i\in\{0,1\}\), sample \(A\) from \(U_i\) and then a uniformly random vertex of \(A\);
write the resulting vertex distribution as \(\nu_i\). Let

\[
  \chi:=\sum_{v\in X(1)}\min\{\nu_0(v),\nu_1(v)\}
      =1-\operatorname{TV}(\nu_0,\nu_1).
\]

Tag the two cluster tables by \(0,1\), and tag the complement by a disjoint symbol
\(\bot\). Let \(F:X(1)\to\Sigma\) be any vertex word, not necessarily constant-tag, and
let \(\tau_F(v)\in\{0,1,\bot\}\) be its tag projection. For \(0\le \zeta<1\), define

\[
  \lambda_i(F):=\Pr_{A\sim U_i}
  [\operatorname{dist}(T[A],F|_A)\le\zeta].
\]

Assume a tag disagreement contributes at least one symbol error. Then every \(F\) satisfies

\[
 (1-\zeta)(\lambda_0(F)+\lambda_1(F))\le 2-\chi.
 \tag{OA1}
\]

Consequently, with \(\mu_{\max}=\max\{\mu_0,\mu_1\}\), the total mass explained on the
two clusters obeys

\[
  \mu_0\lambda_0(F)+\mu_1\lambda_1(F)
  \le \frac{\mu_{\max}(2-\chi)}{1-\zeta}.
 \tag{OA2}
\]

If the complement table \(T^\star\) has agreement at most \(\varepsilon_\star\) with every
vertex word, then any DPT-to-global-word statement that guarantees mass
\(\kappa(\delta)\) must satisfy

\[
  \kappa(\delta)-\varepsilon_\star
  \le \frac{\mu_{\max}(2-\chi)}{1-\zeta}.
 \tag{OA3}
\]

This remains valid for arbitrary vertex-varying tags. In the disjoint-support case
\(\chi=0\), the inequality gives no nontrivial obstruction beyond the total cluster mass;
when \(\chi\) is close to one, a DPT mass larger than approximately \(\mu_{\max}\) is
impossible even without a constant-tag hypothesis.

## Proof

For \(i\in\{0,1\}\), put
\[
 g_i(A):=\frac1k|\{v\in A:\tau_F(v)=i\}|.
\]
On a face counted by \(\lambda_i(F)\), at most a \(\zeta\)-fraction of symbols differ,
so \(g_i(A)\ge 1-\zeta\). Therefore
\[
 \mathbb E_{v\sim\nu_i}[\mathbf 1_{\tau_F(v)=i}]
 \ge (1-\zeta)\lambda_i(F).
\]
At each vertex \(v\), the tags \(0\) and \(1\) are mutually exclusive. Hence
\[
\begin{aligned}
 &\mathbb E_{\nu_0}[\mathbf 1_{\tau_F=0}] +
   \mathbb E_{\nu_1}[\mathbf 1_{\tau_F=1}]\\
 &\qquad\le \sum_v\max\{\nu_0(v),\nu_1(v)\}
 =2-\sum_v\min\{\nu_0(v),\nu_1(v)\}=2-\chi.
\end{aligned}
\]
Combining the two displays proves (OA1). Since
\(\mu_0\lambda_0+\mu_1\lambda_1\le\mu_{\max}(\lambda_0+\lambda_1)\), (OA2) follows.
If a returned word explains total mass \(\kappa(\delta)\), the complement contributes at
most \(\varepsilon_\star\), so at least \(\kappa(\delta)-\varepsilon_\star\) comes from the
two clusters. Applying (OA2) proves (OA3). \(\square\)

## Why this is a real extension of the constant-tag gate

The earlier constant-tag argument treats a vertex word whose tag is globally fixed. The
present bound allows the tag to vary arbitrarily with the vertex, exactly as in the ordinary
DPT definition, where the output \(F:X(1)\to\Sigma\) is not required to have a constant tag.
The only replacement is the measurable overlap \(\chi\) of the two cluster incidence laws.
Thus a nonconstant-tag DPT proof can evade the mass threshold only by placing the two clusters
on nearly disjoint vertex support. This is the same cover/sheet escape that must be controlled
by an incidence or binding theorem; it is not removed by ordinary list soundness.

The result is source-independent and does not claim that the GMWZ HDX has a large \(\chi\).
For GMWZ, the missing positive theorem is now sharply stated: prove a lower bound on \(\chi\)
for the computation-generated heavy clusters, or construct a valid assignment with small \(\chi\).
The latter would be a concrete cover-aware obstruction. The DPT definition itself supplies
neither alternative.

## Relation to the published DPT interface

Gur--Minzer--Weissenberg--Zheng define DPT soundness by the existence of an arbitrary global
function \(F:X(1)\to\Sigma\) that explains a polynomial fraction of faces; no constant-tag
condition is part of that definition. The theorem above therefore applies to the actual
quantifier, while Proposition 3.9P' is the sharper special case when the tag is forced to be
constant. It does not upgrade the published list-decoding theorem to unique decoding.

Source: [GMWZ Definition 2.8](https://arxiv.org/html/2512.12960#S2.3.3) and [Lemma 6.2](https://arxiv.org/html/2512.12960#S6.2). The inequality (OA1)--(OA3) is derived here.
