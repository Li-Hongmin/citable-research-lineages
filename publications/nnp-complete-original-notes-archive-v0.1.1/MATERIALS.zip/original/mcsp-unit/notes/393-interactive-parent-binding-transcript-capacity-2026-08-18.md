> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 交互式 parent-binding 的 transcript 容量门（2026-08-18）

## 判定

C378 的多 outsider 计数可以提升为一个不依赖非自适应性的交互式定理。只要
挑战由公开输入、固定 descriptor 和此前 transcript 决定，所有 target-dependent
信息都必须通过 descriptor 或 response transcript 进入；自适应地选择下一个
AVOID instance、block index 或 proof query 不会免费增加 parent 信息。

因此，若一个 proposed RW closure 想用交互式 JK/PCP protocol 从少量 outsider
恢复一个 \(b\)-bit parent family，它必须支付至少 \(b\) bits 的 descriptor +
response transcript。\(q,k,\log P=\operatorname{polylog}(b)\) 的交互式逃逸仍然
不可能；它只能适用于 published singleton，或离开 exact same-parent binding。

## Theorem 393.1（adaptive transcript capacity）

令 \(\mathcal B\) 是一个 parent family，\(|\mathcal B|=M\)。对每个
\(B\in\mathcal B\)，协议有一个 descriptor
\(\sigma_B\in\{0,1\}^{d}\)，并运行至多 \(q\) 轮。第 \(t\) 轮的 challenge
由公开输入、固定算法、\(\sigma_B\) 和此前 transcript 唯一决定；response
\(R_t\) 的可能值数至多 \(2^{\ell_t}\)。设一个确定性 decoder \(D\) 从
\((\sigma_B,R_1,\ldots,R_q)\) 以及公开 transcript 规则 exact recover \(B\)。
则

\[
  d+\sum_{t=1}^{q}\ell_t\ \ge\ \log_2 M.
\tag{393.1}
\]

若第 \(t\) 轮 response 由一个 \(2k_t\)-bit outsider 和一个 index/path
\(\iota_t\in\mathcal I_t\) 组成，则可取

\[
  \ell_t\le 2k_t+\lceil\log_2|\mathcal I_t|\rceil.
\tag{393.2}
\]

若 index/path 是此前 response 的确定性函数，则第二项不需要重复计数；若它由
target-dependent oracle 额外给出，就必须把它作为 response bits 计入。

### 证明

令
\[
  \mathsf T(B):=(\sigma_B,R_1(B),\ldots,R_q(B)).
\]
如果 \(B\ne B'\) 但 \(\mathsf T(B)=\mathsf T(B')\)，则由协议的确定性 challenge
规则，两次运行的全部 challenges、indices 和 decoder 输入相同，故 \(D\) 输出
同一个 parent，不可能同时等于 \(B\) 和 \(B'\)。所以 \(B\mapsto\mathsf T(B)\)
是 injective。

而 transcript 的取值总数至多
\[
  2^d\prod_{t=1}^{q}2^{\ell_t}
  =2^{d+\sum_t\ell_t}.
\]
与 \(|\mathcal B|=M\) 比较即得 (393.1)。式 (393.2) 只是把 response 的值域按
outsider 与 index/path 分解。证毕。

## JK/RW 的具体化

在一条 adaptive JK protocol 中，第 \(t\) 个 outsider 的 block 宽度为 \(2k_t\)，
其返回位置若从长度 \(P_t\) 的 proof 中选择一个 \(2k_t\)-bit block，则
\[
  |\mathcal I_t|\le \left\lceil\frac{P_t}{2k_t}\right\rceil
  \cdot O(\log P_t)
\]
（是否需要额外的 stage/path bits 取决于协议公开的编码）。因此任何 exact
same-parent decoder 都满足一个保守的支付式

\[
  d+\sum_t\bigl(2k_t+\log_2|\mathcal I_t|\bigr)\ge \log_2|\mathcal B|.
\tag{393.3}
\]

若 index、stage 和 challenge 全由此前 outsider transcript 计算，则可以删除
重复的 index 项，得到更强的 \(d+2\sum_t k_t\ge\log_2|\mathcal B|\)；若协议把
proof response、sheet label 或 target-dependent challenge 当作“公开控制”，它们
不是免费控制，而应并入相应 \(\ell_t\)。

对 identity family \(\mathcal B=\{0,1\}^{b}\)，若
\[
  q,\quad k_t,\quad \log P_t,\quad d=\operatorname{polylog}(b),
\]
则 (393.3) 与 \(b\) 矛盾。因此自适应选择 generator、递归选择 first-failure
位置或交互式读取 Harsha auxiliary proof，都不能在 address scale 内完成
whole-parent exact binding。

## 对 Closure Theorem 的边界

* 该定理关闭的是 **interactive transcript 作为免费 parent channel** 的逃逸；
  它不适用于 published RW Theorem 4.3 固定 \(x_0\) 的 singleton，因为
  \(\log|\mathcal B|=0\)。
* 要把它用于 RW，必须先给出一个实际 parent family，或证明 proposed
  singleton-specific descriptor 是由一个 target-independent address-scale
  procedure 生成的；否则 descriptor 可能把整个 parent 作为未计价输入。
* 该定理只处理 exact same-parent binding。若协议只输出一个非注入 fingerprint、
 允许不同 addresses 使用不同 sheets/strategies，或接受 list/average semantics，
  则它已经离开本定理的 closure interface，须分别进入 C367、C289/C330 或
  static-package accounting。

所以 Gate-I 现在有一个明确二分：要么证明实际 RW proof family 使交互 transcript
包含 \(\Omega(b)\) bits 的 parent payload，要么证明它不需要 family-level
binding 而能直接给出 singleton 的 address-scale evaluator。前者是容量障碍，后者
仍是唯一未被本定理触及的正攻路线。

## 来源与关系

* Ren--Williams Theorem 3.1：每次 JK hard 输出只有一个 \(2k\)-bit outsider 及其
  stage/block 位置。
* C372/C373/C378：success semantic exit、单 outsider fiber 与多 outsider
  communication bound。
* C389/C390：Harsha auxiliary factorization 与 actual identity-family payload。

本定理是自足的 transcript-injectivity 论证；不声称 published singleton 已被
排除，不证明 \(P\ne NP\)，也不把交互式协议自动升级为 RLDC。
