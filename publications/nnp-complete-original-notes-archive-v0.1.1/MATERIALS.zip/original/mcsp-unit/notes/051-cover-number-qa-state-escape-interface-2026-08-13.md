> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 非 XOS cover-number QA 状态：唯一仍可逃逸的静态接口（2026-08-13）

## 一般构造

给一个固定原子族 \(\mathcal A\subseteq2^C\)，定义覆盖数

\[
F_{\mathcal A}(R)
=\min\{\,|I|:I\subseteq\mathcal A,\ R\subseteq\bigcup_{A\in I}A\,\}.
\tag{1}
\]

若 \(R=V\dot\cup W\)，分别覆盖 \(V,W\) 的原子族并集覆盖 \(R\)，故

\[
F_{\mathcal A}(R)\le F_{\mathcal A}(V)+F_{\mathcal A}(W).
\tag{2}
\]

于是

\[
K_{\mathcal A}(R)
=F_{\mathcal A}(R)-\frac{F_{\mathcal A}(C)}{|C|}|R|
\tag{3}
\]

满足 QA 方向

\[
K_{\mathcal A}(V)+K_{\mathcal A}(W)\ge K_{\mathcal A}(R),
\qquad K_{\mathcal A}(C)=0.
\tag{4}
\]

若每个合法 affine 叶 \(R\) 都能被至多 \(B\) 个原子覆盖，则叶值
\(K_{\mathcal A}(R)\le B-\frac{F_{\mathcal A}(C)}{|C|}|R|\)。当存在大叶且
\(F_{\mathcal A}(C)\) 超线性时，这一状态可能提供负补偿。

## 为什么它绕开前述 no-go

覆盖数是单调次可加，但通常不是 XOS/凸范数。故并不存在 Jensen 型
\(\mathbb E F(R)\ge qF(C)\) 的普适定理。小规模 LP 已能构造均匀包含概率 \(q<1/2\) 而
\(\mathbb E F(R)<qF(C)\) 的单调次可加函数；这正是 rank、范数、固定命中谱均不能实现的非线性缺口。

一个完全显式的 \(q<1/2\) 例子如下。取 \(C=\{0,1,2,3,4\}\)，原子族

\[
\mathcal A=\bigl\{\{0,1\},\{1,2\},\{0,3\},\{2,3\},
\{0,4\},\{2,4\},\{1,3,4\}\bigr\}.
\]

令 \(F=F_{\mathcal A}\)，并令 \(R\) 均匀取五个二元集合

\[
\{0,1\},\ \{1,2\},\ \{2,3\},\ \{3,4\},\ \{4,0\}.
\]

每个点的包含概率均为 \(q=2/5\)，且每个样本 \(R\) 本身是一个原子，故
\(\mathbb E F(R)=1\)。直接检查任意两个 \(\mathcal A\)-原子都不能覆盖 \(C\)，而
\(\{0,1\}\cup\{2,3\}\cup\{0,4\}=C\)，所以 \(F(C)=3\)。因而

\[
\mathbb E F(R)=1<\frac25\cdot3=\frac65=qF(C).
\]

这说明“次可加”本身不足以推出均匀叶分布下的平均非负；真正能逃逸 Jensen 的确是非 XOS 的 cover 状态，而不是又一个范数或 rank。

该例确实越过了子模边界：对 \(A=\{0,1\}\)、\(B=\{1,2\}\)，
\[
F(A)+F(B)=2<3=F(A\cup B)+F(A\cap B).
\]
因此 note057 的子模 base-vector 平均 no-go 不适用于它。

## 对 affine-parity 项目的实际义务

要把 (3) 变成非循环的研究状态，必须同时证明：

1. **叶覆盖义务：** 对所有 affine-parity 叶 \(R\)，\(F_{\mathcal A}(R)\le B\)，其中 \(B=O(1)\)；
2. **根覆盖下界：** \(F_{\mathcal A}(C)\ge |C|^{1+\varepsilon}\)（或目标 \(N^{1.01}\)）；
3. **原子固定性：** \(\mathcal A\) 在构造时不能依赖递归协议或待证明的叶树。

若取 \(\mathcal A\) 为全体 affine 叶，则 (1) 就是原问题的最小叶覆盖数，根下界完全循环；若取任意已知小原子族，叶覆盖义务通常失败。故这条接口明确说明了“真正全局语义状态”需要同时解决什么，而不能伪装成一个现成证明。

## 小结

静态 cell 权重、additive 向量范数、matroid rank、固定阶 hit-count 的平均 no-go 已关闭。剩下的非循环候选必须是类似 (3) 的**非 XOS 覆盖复杂度**，而其关键难点正是构造一个协议无关、对所有 affine 叶有常数覆盖数的原子族。
