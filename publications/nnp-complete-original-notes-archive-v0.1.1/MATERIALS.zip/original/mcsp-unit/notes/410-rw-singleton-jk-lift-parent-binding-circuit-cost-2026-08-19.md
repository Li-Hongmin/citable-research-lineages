> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW/JK singleton 的多 outsider half-lift parent-binding 电路代价（2026-08-19）

## 本轮改变的判断

C378 的多 outsider 容量界需要 target-oblivious parent family，因此不能直接约束
published Theorem 4.3 的 singleton (x_0)。本 note 给出 singleton-specific
替代：只要 proposed closure 仍然通过 JK 的 canonical half-lift，从有限个
(2k)-bit outsiders、已知 ancestry/path 和短 descriptor 恢复同一个 hard parent，
那么这些信息可以直接编译成 parent 的小电路。于是 published singleton 也必须支付
一个真实的 circuit-cost，而不是只有 family entropy 才能得到障碍。

## 模型

固定一个 JK generator

\[
  G_k:\{0,1\}^{k}\to\{0,1\}^{2k},
  \qquad s_G:=|G_k|,
\]

以及一个 binary proof 的 JK recursion depth (h). 对某个固定 canonical proof，
假设 closure transcript 暴露 (q) 个 outsider

\[
  y_t\in\{0,1\}^{2k},\qquad t\in[q].
\]

第 t 个 outsider 位于第 j_t 层，并给出一个未截断的左右路径
pi_t in {0,1}^{h-j_t}，使得按 C382 的 half-lift 可得到一个 top block
U_t in {0,1}^{2k}。令

\[
  \ell_t:=h-j_t,\qquad \ell:=\max_t\ell_t.
\]

所有 failure-node index、path、sheet/key、target-dependent strategy 和 descriptor
共计 (d) bits；从 parent address 到 ((t,\text{bit offset})) 的选择由一个
显式控制电路 (S) 完成，大小记为 (s_{\rm ctrl})。这里把 selector、adaptive
challenge rule 和任何 address arithmetic 都计入 (s_{\rm ctrl})，不允许把它们
藏在“给定 path”一句话中。

假设这些 top blocks 覆盖 parent (B\in\{0,1\}^{b})：存在一个 address map，
对每个 (a\in[b]) 选择某个 (t) 和 (U_t) 中的一个 bit，恰好得到 (B[a])。
这是假设一个 JK-lift closure 已经完成的最小形式；不假设 parent family 或随机
target。

## 定理 410.1（singleton JK-lift circuit-cost）

在上述模型下，存在一个 Boolean circuit evaluator (C_B)，以
(\lceil\log_2 b\rceil) 位 parent address 为输入，满足

\[
  C_B(a)=B[a]
\]

且

\[
  \operatorname{CC}(B)
  \le
  O\!\left(
    s_{\rm ctrl}+d
    +q\bigl(2k+\ell(s_G+k+\log b)\bigr)
  \right).
\tag{410.1}
\]

若 selector 已把所有 (y_t)、paths 和 offsets 作为硬常数处理，则 (2kq+d) 的
项可以删去；保留它们得到对 descriptor/advice 成本更保守的界。

### 证明

对每个 (t)，从 (y_t) 开始，沿 (pi_t) 的每一步只取当前 block 的左半或右半，
再调用一次 (G_k)。C382 的公式说明，经过 (ell_t) 步后得到 (U_t)。这一步的
电路大小为

\[
  O\bigl(\ell_t(s_G+k+\log b)\bigr),
\]

其中 (k) 计入半块选择与 wire control，\(\log b\) 计入路径/地址的固定算术。
把 (q) 条 lift 电路并联，得到所有 (U_t)。再接上控制电路 (S)，根据输入
address 选择相应的 (t) 与 block offset，并读出 (U_t) 的目标 bit。hardwire
(y_t)、descriptor 和 paths 的代价至多为 (O(2kq+d))；合并即得 (410.1)。
该 evaluator 正确计算同一个固定 parent (B)，故其 circuit size 给出
(\operatorname{CC}(B)) 的上界。证毕。

## Corollary 410.2（published RW 的 address-scale payment）

在 RW stable stage 取 (b_i=2n_i)、(L_i\le T_i^{c_0})、(T_i=n_i^C)，则

\[
  h_i=O(\log n_i).
\tag{410.2}
\]

若 (|G_{k_i}|\le k_i^4)，并且同一长度满足 forcing lower bound

\[
  \operatorname{CC}(B_i)\ge c\frac{n_i}{\log(n_i+2)},
\tag{410.3}
\]

则任何 closure satisfying the model of Theorem 410.1 必须支付

\[
  s_{\rm ctrl}+d
  +q_i\,O\!\left(k_i^4\log(n_i+2)+k_i\log(n_i+2)
  +2k_i\right)
  \ge \Omega\!\left(\frac{n_i}{\log(n_i+2)}\right).
\tag{410.4}
\]

在 (s_{\rm ctrl}+d=o(n_i/\log n_i)) 且 (k_i=\operatorname{polylog}(n_i)) 时，

\[
  q_i
  =\Omega\!\left(\frac{n_i}{k_i^4\log^2(n_i+2)}\right).
\tag{410.5}
\]

所以 singleton 也不能由 polylogarithmically many JK outsiders、短 descriptor
和 address-scale ancestry 完成 whole-parent binding。这个结论不使用 C378 的
family entropy；它直接使用 published hard parent 的 circuit lower bound。

## 与 C409 的合并

C409 说明：当 (k_i\lesssim n_i^{1/4}/\sqrt{\log n_i}) 时 forcing 排除 easy，
但一个 outsider 不足以承载 parent。定理 410.1 进一步说明，即使允许多个
output-attached outsiders，只要仍然沿 JK half-lift 独立重构，polylog 数量也不够；
必须支付 (410.4) 的近 object-scale lift/descriptor 代价。

因此对 published singleton，JK 路线现在有一个更精确的二分：

1. **JK-lift closure：** 支付 (q_i k_i^4\log n_i)、descriptor 或控制电路达到
   forcing scale；
2. **非 JK-lift global relation：** 新机制必须直接把多个 outsider/cover sheet 绑定
   到同一个 (B_i)，且不能被逐条 half-lift 编译回 (410.1)；
3. **large-width solver branch：** 采用 (k_i\ge n_i) 等 object-scale width，
   但另证 solver-success 在 (P=NP) 下产生 address-scale (P/\mathrm{poly})
   evaluator。

## 量词与证据边界

* 这是 singleton-specific circuit upper bound，不需要 parent family，也不把
  (x_0) 误当 hidden entropy。
* 所有 y-values、path、adaptive strategy、address map 都必须作为常数或显式
  (s_{\rm ctrl}) 计入；不能把完整 parent 藏在未计费 selector 中。
* 定理只覆盖 **JK canonical half-lift**。一个真正新的 global relation 可能共享
  大量计算、绕过逐 block lift；那正是仍值得攻击的 Closure 入口。
* 本 note 不证明 (P\ne NP)，但把 published singleton 的 JK-lift parent-binding
  缺口从“缺少 family 量词”提升为可直接与 forcing lower bound 比较的电路代价。

上游：C378、C382、C383、C407、C408、C409；Ren--Williams Theorems 3.1、3.5、
4.1、4.3。
