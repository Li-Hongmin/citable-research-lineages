> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Formula-XOR 的能量二分与 shrinkage 失效点

## 对象

设 \(F\) 是 Formula-XOR：上层为 De Morgan 公式，共有 \(S\) 个叶子；第 \(i\) 个叶子计算输入变量集合上的 parity，支持宽度为 \(w_i\)。定义

\[
\Gamma(F):=\sum_{i=1}^{S}w_i^2.
\]

本文给出两个互补结论：

\[
\boxed{
\Gamma(F)\text{ 小}\Longrightarrow\text{可提升为普通公式};
\quad
\Gamma(F)\text{ 大}\Longrightarrow\text{普通叶数 shrinkage 不适用}.}
\]

## 引理 1：能量 lifting

对任意 Formula-XOR 公式 \(F\)，存在等价的普通 De Morgan 公式 \(G\)，满足

\[
L(G)=O(\Gamma(F)).
\]

### 证明

令 \(P(w)\) 为 \(w\) 位 parity 的 De Morgan 公式叶数。用

\[
a\oplus b=(a\wedge\neg b)\vee(\neg a\wedge b)
\]

平衡递归，得到

\[
P(w)\le 4P(\lceil w/2\rceil)+O(1)=O(w^2).
\]

逐个把第 \(i\) 个 parity 叶替换为大小 \(O(w_i^2)\) 的公式，即得

\[
L(G)\le C\sum_iw_i^2=C\Gamma(F).
\qquad\square
\]

## 推论：低能量区域已经被普通公式下界覆盖

记

\[
Q_N:=\operatorname{MCSP}[2^{n^{1/3}},2^{n^{2/3}}],
\qquad N=2^n.
\]

已知

\[
L(Q_N)\ge N^{1.99}.
\]

因此，若 \(F\) 在该 promise 上正确，则

\[
\Gamma(F)\ge N^{1.99}.
\]

若 \(S\le N^{1+\varepsilon}\)，则

\[
\operatorname{RMS}(w_1,\ldots,w_S)
=\sqrt{\frac1S\sum_iw_i^2}
\ge N^{(0.99-\varepsilon)/2}.
\]

在 \(S=N^{1.01}\) 尺度：

\[
\operatorname{RMS}(w_i)\ge N^{0.49}.
\]

更粗地，若每个 \(w_i\le W\)，则

\[
SW^2<N^{1.99}
\Longrightarrow
F\text{ 不计算 }Q_N.
\]

## 引理 2：普通 leaf-shrinkage 的首个失效点

Hirahara–Santhanam 的普通公式证明先把公式分成叶数至多 \(\ell\) 的块 \(g_i\)，然后使用

\[
L(g_i)\le\ell
\Longrightarrow
|\operatorname{vars}(g_i)|\le\ell.
\]

这使 \(\ell\)-wise restriction 与完全独立 restriction 在每个 \(g_i\) 上具有相同分布，并允许应用 shrinkage exponent \(2\)。

Formula-XOR 中该蕴含为假。令

\[
P_m(x):=\bigoplus_{j=1}^{m}x_j.
\]

则

\[
L_\oplus(P_m)=1,
\qquad
|\operatorname{vars}(P_m)|=m.
\]

树分块仍成立，但“块的叶数控制变量数”是原证明中第一个失效的命题。

提高 restriction 的独立性不能单独修复问题。对独立 \(p\)-restriction \(\rho\)，

\[
\Pr[P_m\!\upharpoonright\!\rho\text{ 非常数}]
=1-(1-p)^m.
\]

若 \(pm\to\infty\)，该概率趋于 \(1\)。所以不存在仅以 Formula-XOR 叶数计量、对所有公式成立的

\[
\mathbb E_\rho[L_\oplus(F\!\upharpoonright\!\rho)]
\le O(p^\alpha)L_\oplus(F),
\qquad \alpha>0.
\]

## 能量在随机限制下的精确变化

令

\[
K_i\sim\operatorname{Bin}(w_i,p)
\]

为第 \(i\) 个 parity 叶限制后的支持宽度。则

\[
\mathbb E[K_i^2]
=p^2w_i^2+p(1-p)w_i.
\]

相加得到

\[
\boxed{
\mathbb E[\Gamma(F\!\upharpoonright\!\rho)]
=p^2\Gamma(F)+p(1-p)\sum_iw_i.}
\]

这说明 \(\Gamma\) 有二次收缩项，但同时存在一阶 incidence 项。能量收缩不等于上层公式收缩，也不保持 MCSP promise；它是正确势函数，但尚不是完整下界。

## 与 locality barrier 的关系

Chen 等证明，Frontier B 的 magnification 无条件产生带小 fan-in oracle 的高效 Formula-O-XOR；Tal 的 sign-rank、discrepancy 和 parity-correlation 下界又能扩展到同类 oracle 公式。因此，只把现有下界逐字推广到 parity leaves 仍不足以跨过 magnification 阈值。

~~~mermaid
flowchart LR
    F["Formula-XOR<br/>S ≤ N^(1+ε)"] --> E{"Γ(F)"}
    E -->|"Γ < N^1.99"| L["展开为普通 Formula<br/>与已知下界矛盾"]
    E -->|"Γ ≥ N^1.99"| H["宽 parity 叶集中"]
    H --> R["普通 leaf-shrinkage 失效"]
    H --> X["需要非局部、输入敏感的势函数"]
~~~

下一项证明义务不能再是通用随机限制 shrinkage，而必须同时使用

\[
\text{高 }\Gamma(F)
\quad+\quad
Q_N\text{ 的语义结构}.
\]

候选形式包括高能量与输入敏感性、仿射子空间行为或 promise 两侧可分性的矛盾。仅由语法参数 \(S,\Gamma\) 出发尚不能推出该矛盾。

## 能推出什么

\[
\begin{aligned}
&\text{低宽度／低能量 Formula-XOR 区域已关闭};\\
&\text{原普通公式 shrinkage 的直接推广已关闭};\\
&\text{剩余反例必须具有 }\Gamma(F)\ge N^{1.99}.
\end{aligned}
\]

## 不能推出什么

- 未证明 \(Q_N\notin\operatorname{Formula\mbox{-}XOR}[N^{1.01}]\)；
- 未证明高 \(\Gamma\) 本身导致计算失败；
- 未绕过 locality barrier；
- 未证明任何新的一般 Formula-XOR 函数下界。

## 原始来源

- Hirahara and Santhanam, *On the Average-Case Complexity of MCSP and Its Variants*, CCC 2017, DOI: 10.4230/LIPIcs.CCC.2017.7，尤其 Lemma 27、Theorem 28。
- Chen, Hirahara, Oliveira, Pich, Rajgopal and Santhanam, *Beyond Natural Proofs: Hardness Magnification and Locality*, ITCS 2020, DOI: 10.4230/LIPIcs.ITCS.2020.70，尤其 Frontier B、Theorem 2 与 §5.1.2。
- Tal, *Formula Lower Bounds Via the Quantum Method*, STOC 2017, DOI: 10.1145/3055399.3055472。
