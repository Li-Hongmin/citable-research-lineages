> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Finite-view strategy entropy barrier for simultaneous coordinate robustness (2026-08-17)

## Contribution

The remaining “long Merlin strategy” escape can be quantified whenever the verifier has a
finite visible view.  A strategy may be computationally unbounded and may depend on the
public coins, previous proof answers, and previous response bits.  If, in one execution, the
verifier sees only \(r\) public random bits, \(m\) response bits, and at most \(q\) proof
symbols from a fixed finite alphabet \(\Sigma\), then all response policies have a finite
union of reachable proof positions.  Enumerating that union turns simultaneous
coordinate robustness into a nonadaptive RLDC.  The arbitrary-alphabet lower bound of
Goldberg--Gur--Saraogi therefore forces the visible transcript entropy to reach the
\(\log\log k\) scale under near-linear proof length.

This is stronger than a statement about a bounded response alphabet: the strategy itself may
be an arbitrary function.  Only the verifier's finite visible view is charged.  The theorem
does not cover a verifier with unbounded time, an infinite/continuous response alphabet, or
a soundness condition that holds only for one selected policy.

## Model

Let

\[
  \Pi:\{0,1\}^{k}\to\Sigma^{P},\qquad |\Sigma|=A\ge2,
\]

be a common proof map.  For every message coordinate \(i\) and claim \(b\), let
\(V_{i,b}\) be a randomized adaptive verifier with the following per-execution limits:

* at most \(r\) public random bits;
* at most \(q\) proof-symbol queries;
* at most \(m\) observed Merlin-response bits.

All verifier randomness visible to the decoder is included in the \(r\) public bits; hidden
coins can be folded into the same finite view or are outside this theorem.
The response interface is the standard bit model: each observed response symbol contributes
one binary branch; an oracle/hash operation on an unbounded response string is outside the
model.

The response policy may be an arbitrary function of the public coins, the complete observed
history, and the proof answers.  Assume perfect completeness for the correct claim and, for
some fixed \(0<\rho<1\) and \(0\le\beta<1\), target-relative all-policy soundness:

\[
\begin{aligned}
  &\Pr[V_{i,m_i}^{\mathcal S}(\Pi(m))=1]=1
    &&\text{for some policy }\mathcal S=\mathcal S_{m,i},\\
  &d_H(z,\Pi(m))\le\rho P
    \Longrightarrow
    \Pr[V_{i,1-m_i}^{\mathcal S}(z)=1]\le\beta
    &&\text{for every policy }\mathcal S.
\end{aligned}
\tag{268.1}
\]

The first line permits a different honest policy for each target and coordinate.  The second
line is the crucial all-policy quantifier.

If policies are randomized, it is enough to enumerate deterministic policies: acceptance is
linear in the policy distribution, so a maximizing policy is an extreme point.

## Theorem

Put \(\sigma:=1-\beta\) and

\[
  Q:=1+2q\,2^{r+m}A^{q}.
\tag{268.2}
\]

There is a binary/finite-alphabet message-inline nonadaptive RLDC with query complexity at
most \(Q\), constant positive radius depending only on \(\rho,A\), and success gap
\(\sigma\).  Consequently, for fixed \(A,\rho,\sigma_0>0,c>0\), if \(\sigma\ge\sigma_0\) and

\[
  N:=k+P\le k(\log k)^c
\tag{268.3}
\]

for infinitely many sufficiently large \(k\), then

\[
  Q=\Omega_{A,\rho,\sigma_0,c}\!\left(\frac{\log k}{\log\log k}\right).
\tag{268.4}
\]

Equivalently, for all such lengths,

\[
  r+m+q\log_2 A+\log_2(q+2)
  \ge
  \log_2\log k-\log_2\log\log k-O_{A,\rho,\sigma_0,c}(1).
\tag{268.5}
\]

In particular, with fixed \(q,A\), a near-linear construction must expose
\(\Omega(\log\log k)\) public/response bits per execution.  An arbitrarily long but invisible
Merlin string is not an escape.

## Proof

### 1. Finite all-policy support

Fix \((i,b)\).  A complete execution is determined, for purposes of future proof addresses,
by its public random tape, its observed response transcript, and its proof-symbol answers.
There are at most

\[
  2^r\cdot 2^m\cdot A^q
\tag{268.6}
\]

such view paths.  Each path contains at most \(q\) proof-query nodes.  Let \(L_{i,b}\) be
the union of all proof positions reachable over all policies and all view paths.  Then

\[
  |L_{i,b}|\le q\,2^{r+m}A^q.
\tag{268.7}
\]

This counts addresses, not response policies: policies that induce the same visible path do
not enlarge the support.  The argument remains valid for arbitrary, computationally
unbounded policy functions because only the finite visible view is relevant.

### 2. Message-inline decoder

Use the tagged inline code

\[
  C(m)= (I,m_1)\cdots(I,m_k)\,(P,\Pi(m)_1)\cdots(P,\Pi(m)_P),
\]

over \(\Gamma=\{(I,0),(I,1)\}\sqcup\{(P,a):a\in\Sigma\}\).  The \(A\)-ary Singleton bound
and (268.1) imply that the proof image has relative distance \(>\rho\), so for all large
\(k\) the tagged code has a fixed positive relative radius \(\delta_0=\delta_0(\rho,A)\).
Invalid tags make the decoder output \(\bot\).

On an input within \(\delta_0\) of \(C(m)\), query the inline coordinate \(i\) and the two
supports \(L_{i,0},L_{i,1}\).  For each claim \(b\), enumerate all finite view policies,
compute their exact acceptance probability over the \(r\) public bits, and output \(b\) if
the maximum acceptance is above \((1+\beta)/2\); otherwise output \(\bot\).  The support
queries suffice to simulate every policy offline.  On the codeword, the honest policy makes
the correct claim pass with probability one, while the wrong claim is at most \(\beta\).  On a
\(\rho\)-near proof, a wrong inline bit can be output only if the wrong branch exceeds the same
threshold, which is excluded by all-policy soundness.  The decoder therefore has positive
radius and success gap \(\sigma\).  The query count is

\[
  1+|L_{i,0}|+|L_{i,1}|
  \le 1+2q2^{r+m}A^q=Q.
\tag{268.8}
\]

### 3. RLDC lower bound and entropy threshold

Apply the arbitrary finite-alphabet nonadaptive RLDC lower bound of
Goldberg--Gur--Saraogi (Theorem 1) to the tagged code.  With
\(a=\lceil Q/\sigma\rceil\), it gives, whenever the fixed radius exceeds
\(N^{-\sigma/(2Q)}\),

\[
  N\ge
  \left(
    \frac{\sigma^2 k}
    {38Q^4\log^2(A+2)\log^2 k}
  \right)^{1+1/a}.
\tag{268.9}
\]

Assume \(Q\le\eta\log k/\log\log k\).  The same constant contradiction used in the
growing-locality threshold gives

\[
  a\le \frac{2\eta}{\sigma_0}\frac{\log k}{\log\log k},
  \qquad
  \frac{\log k}{a}\ge\frac{\sigma_0}{2\eta}\log\log k,
\tag{268.10}
\]

whereas (268.3) and (268.9) imply

\[
  \frac{\log k}{a}
  \le (c+12)\log\log k+O_{A,\sigma_0,\eta}(1).
\tag{268.11}
\]

Choosing \(\eta<\sigma_0/[4(c+12)]\) is a contradiction.  In the same contradiction regime,
\(N^{-\sigma/(2Q)}\le(\log k)^{-\sigma_0/(2\eta)}<\delta_0\), so the GGS radius
hypothesis is valid.  This proves (268.4).  Taking logarithms in (268.2) gives (268.5).
\(\square\)

## Interpretation and boundary

This theorem closes a precise finite-view version of the “unbounded strategy” residual:
response computation may be arbitrary, but the visible transcript entropy contributes to the
same branch-support count as public randomness and proof answers.  It is not necessary to
enumerate or encode the full strategy.

The theorem does **not** cover:

1. verifier time or response alphabets that are genuinely unbounded/continuous, so that no
   finite visible view exists;
2. soundness quantified only for one selected policy, where the decoder cannot maximize over
   all policies without changing semantics; or
3. target-dependent proof/address spaces, which do not define a common proof map.

Thus the remaining positive target is sharper: a near-linear simultaneous coordinate-robust
PCP must either violate one of these explicit finite-view hypotheses, or supply a new
global coupling that is not reducible to a common finite view.

## Relation to existing closure modules

The support estimate refines the finite-policy support theorem and the common-strategy
public-randomness elimination.  Unlike the latter, it does not assume a single common
strategy; it pays for the union over all visible policies.  Unlike the fixed-locality
RLDC theorem, it translates the union-support lower bound directly into a lower bound on
\(r+m+q\log A\), which is the natural transcript-entropy parameter.

## Source

* Goldberg--Gur--Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally Decodable Codes via
  Robust Daisies*, arXiv:2511.21659, Theorem 1: <https://arxiv.org/abs/2511.21659>.
* Existing finite-policy support closure: [branch-support barrier](../../rw-jk-succinct-reconstruction/statements/strategy-support-acrr-rldc-barrier.md).
* Existing growing-locality threshold: [note 242](242-growing-query-threshold-for-near-linear-closure-2026-08-17.md).
