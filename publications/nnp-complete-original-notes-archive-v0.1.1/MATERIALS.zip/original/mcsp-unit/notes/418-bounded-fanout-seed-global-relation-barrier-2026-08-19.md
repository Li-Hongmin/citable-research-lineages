> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW bounded-fanout seed global-relation barrier（2026-08-19）

## 本轮改变的判断

C411 已把 same-proof global relation 的信息账本压成两端：要么 policy/coordinate
channel 携带线性 target information，要么给定 target 和 policy 后留下线性
residual total correlation。C411 特别保留了一个真实逃逸：一个很短的 shared
seed 可以被许多坐标重复使用，从而产生线性 total correlation；因此“seed 很短”
本身不是 residual-correlation lower bound。

本 note 关闭其中一个可检验的中间类。若 global relation 的非乘积性只来自一个
**条件独立、bounded-fanout 的 seed**，而每个坐标只读取 seed 的一个局部子集，
则 residual correlation 至多是 seed entropy 乘以 seed fanout。于是低 fanout、短
seed 的 relation 不能同时保持低 target channel 和 constant-probability whole-word
binding。要逃逸，必须让 seed 以 message-scale fanout 影响坐标，或引入 seed 后仍
存在的 non-product coupling。

这不是对任意 global relation 的不可能性；它把 C411 留下的“短 seed 复制”具体化
为一个有参数的正/负接口，并与 C393 的 transcript capacity、C417 的 half-lift
电路 payment 相接。

## 模型

令目标 \(X\) 在一个 \(b\)-bit、距离分离的 family 上均匀取值，令 \(S\) 是
policy/descriptor，令

\[
  Z=(Z_1,\ldots,Z_M)\in\Gamma^M
\]

是同一个 proof/address space 上产生的 global word。设有一个 seed

\[
  U=(U_1,\ldots,U_d)
\]

以及每个坐标的局部随机带 \(R_j\)。固定 \(Q:=(X,S)\)，假设：

1. \(U_1,\ldots,U_d\) 在给定 \(Q\) 后条件独立；每个 \(U_\ell\) 可以是有限
   alphabet，记其条件 entropy 为 \(H(U_\ell\mid Q)\)。
2. \(R_1,\ldots,R_M\) 在给定 \((Q,U)\) 后相互独立，并且与 \(U\) 条件独立。
3. 对每个坐标存在 seed-neighborhood \(N(j)\subseteq[d]\) 与局部函数
   \[
      Z_j=\phi_j(Q,U_{N(j)},R_j).
   \]
   令
   \[
      D_\ell:=|\{j:\ell\in N(j)\}|,
      \qquad D:=\max_\ell D_\ell.
   \]

假设每个 \(\rho\)-近 proof 产生的 \(Z\) 以概率至少 \(p\) 落在正确 canonical
word 的 \(t\)-球内，且 canonical family 的最小距离大于 \(2t\)。

删去所有 \(D_\ell=0\) 的 seed 坐标（它们不影响任何 \(Z_j\)），以下令每个
seed coordinate 至少被一个输出坐标使用。

## 引理 418.1（bounded-fanout conditional-correlation bound）

在上述模型下，

\[
 \operatorname{TC}_2(Z\mid X,S)
 \le
 \sum_{\ell:D_\ell\ge1}(D_\ell-1)H_2(U_\ell\mid X,S)
 \le (D-1)\sum_{\ell=1}^{d}H_2(U_\ell\mid X,S).
\tag{418.1}
\]

### 证明

写 \(Q=(X,S)\)，并令

\[
 W_j:=(U_{N(j)},R_j).
\]

给定 \(Q\) 后，各 \(Z_j\) 是对应 \(W_j\) 的独立坐标信道输出。条件 KL
data processing（等价地，total correlation 在逐坐标独立信道下不增加）给出

\[
 \operatorname{TC}_2(Z\mid Q)
 \le \operatorname{TC}_2(W\mid Q).
\tag{418.2}
\]

加入相互独立的 \(R_j\) 不改变右侧的 total correlation：局部 entropy 在
\(\sum_j H(W_j\mid Q)\) 与 \(H(W\mid Q)\) 中恰好各增加
\(\sum_j H(R_j\mid Q)\)。因此

\[
 \operatorname{TC}_2(W\mid Q)
 =\sum_j H_2(U_{N(j)}\mid Q)-H_2(U\mid Q).
\tag{418.3}
\]

由 seed 坐标在 \(Q\) 下条件独立，

\[
 \sum_j H_2(U_{N(j)}\mid Q)
 =\sum_\ell D_\ell H_2(U_\ell\mid Q),
 \qquad
 H_2(U\mid Q)=\sum_\ell H_2(U_\ell\mid Q).
\]

代入 (418.3) 即得 (418.1)。证毕。

该界的 fanout 因子不可一般删除：一个均匀 binary seed \(U_1\) 被同一组
\(D\) 个坐标复制，即 \(Z_1=\cdots=Z_D=U_1\)，满足
\(\operatorname{TC}_2(Z)=D-1\)，恰达到 (418.1)。所以本结果收费的是
“seed entropy × fanout”，而不是把 seed length 错当成 total correlation。

## 定理 418.2（bounded-fanout global-relation trichotomy）

在上述模型中，令 canonical proof family 的最小距离大于 \(2t\)，并令

\[
 p_b:=\Pr[d_H(Z,\Pi_b(X))\le t].
\]

则

\[
 I_2(X;S)+\sum_{j=1}^{M}I_2(X;Z_j\mid S)
 +(D-1)\sum_{\ell=1}^{d}H_2(U_\ell\mid X,S)
 \ge p_b b-1.
\tag{418.4}
\]

### 证明

C411 的 nearest-word/Fano 账本给出

\[
 I_2(X;S)+\sum_j I_2(X;Z_j\mid S)
 +\operatorname{TC}_2(Z\mid X,S)
 \ge p_b b-1.
\tag{418.5}
\]

用引理 418.1 上界 residual total correlation 即得 (418.4)。证毕。

## 推论 418.3（地址尺度的低-fanout 逃逸被关闭）

若 \(p_b\ge p_0>0\)，且

\[
 (D-1)\sum_\ell H_2(U_\ell\mid X,S)=o(b),
\qquad
 I_2(X;S)+\sum_j I_2(X;Z_j\mid S)=o(b),
\]

则 (418.4) 矛盾。更定量地，对任意 \(0\le\theta<p_0\)，至少有一项成立：

\[
 I_2(X;S)+\sum_j I_2(X;Z_j\mid S)
 \ge (p_0-\theta)b-1,
\tag{418.6}
\]

或

\[
 (D-1)\sum_\ell H_2(U_\ell\mid X,S)
 \ge \theta b-1.
\tag{418.7}
\]

特别地，binary \(d\)-bit seed 且 \(D,d=\operatorname{polylog}(b)\) 时，
residual correlation 只有 \(\operatorname{polylog}(b)\)；一个成功的 relation
必须把 \(\Omega(b)\) 比特放入 policy/coordinate channel。若该 channel 由
address-scale outsider、descriptor 或 adaptive transcript 提供，则分别进入
C393/C417 的 payload/control payment。

## 与 C411 和 RW closure 的精确关系

1. **C411 的剩余逃逸被参数化。** C411 允许短 seed 通过高 fanout 产生线性
   residual correlation；418.1 说明低 fanout 时这种现象不可能发生。因而真正
   未关闭的 seed 路线必须满足 message-scale fanout
   \(D\cdot H(U)=\Omega(b)\)，或 seed 坐标在给定 \(X,S\) 后仍有 non-product
   dependence。
2. **target channel 不能免费改名。** 若 \(\Omega(b)\) 信息在
   \(I(X;S)+\sum_jI(X;Z_j\mid S)\) 中出现，target-oblivious transcript 的
   adaptive capacity 受 C393 约束；若它来自可编译的 JK blocks，则 C417 的
   shared-DAG circuit payment 适用。
3. **真正的新 global relation 的边界。** 若 seed 不条件独立、坐标之间还有
   直接 post-seed coupling、或 \(Z_j\) 需要同时读取多个坐标的 joint proof
   state，则不满足本定理。这些正是需要另行构造或证明不可能的 global relation，
   不能被普通 distributional/list soundness 自动替代。

## 假设边界与非主张

* 这是 conditional-product/bounded-fanout barrier，不是一般 dPCP、PCPP、LDC
  或 RLDC 的无条件不可能性。
* \(D=\Theta(M)\) 的一个共享 bit 复制到所有坐标正是本定理允许的高-fanout
  逃逸；定理没有把它错误地收费成 seed length。
* 若 seed 坐标强相关，(418.3) 的可加 entropy 计算失效；这属于
  seed-after-conditioning 的 non-product global relation，应另行记账。
* published RW Theorem 4.3 的 \(x_0\) 是 singleton；将 (418.4) 用于 RW 必须
  先构造 target-relative family/common proof 量词，不能把 family entropy 偷换成
  singleton parent hardness。
* 本结果不证明 \(P\ne NP\)。它只把一个自然的 non-half-lift global-relation
  类压成了 fanout/information 二分。

## 证据边界

* C411：距离分离 family 的 Fano + residual-correlation identity；
* C393：adaptive transcript 的通信容量界；
* C417：可编译 half-lift DAG 的 singleton 电路代价；
* 引理 418.1 本身是 conditional KL data processing 与 entropy chain rule，
  不依赖具体 PCP 构造。
