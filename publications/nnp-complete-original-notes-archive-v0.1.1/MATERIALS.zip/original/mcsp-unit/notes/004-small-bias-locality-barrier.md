> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Small-bias locality 路线的尖锐关闭

## 对象

令

\[
\mathcal C_s
=
\operatorname{FORMULA}[s]\circ\operatorname{XOR}.
\]

Kabanets 等通过 \(\beta\)-biased 分布 fool \(\mathcal C_s\)。本文证明：

\[
\boxed{
\beta=2^{-\Theta(\sqrt s)}
\text{ 是该框架的必要尺度，且这种分布几乎不可能落在低电路复杂度真值表上}.}
\]

因此，优化其证明中的对数因子不能触发 Frontier B。

## 一、平均-seed locality 的充分条件

设

\[
H=\operatorname{GapMCSP}[a,b]
\]

且 \(G\) 以误差 \(\varepsilon\) fool 电路类 \(\mathcal C\)。记

\[
g:=
\Pr_z[\operatorname{CC}(G(z))\le a],
\]

以及

\[
\rho_b:=
\Pr_{U\sim U_N}
[U\text{ 不是 }H\text{ 的 NO instance}].
\]

若 \(H\in\mathcal C\)，则

\[
\Pr_z[H(G(z))=1]\ge g
\]

而

\[
\Pr_U[H(U)=1]\le\rho_b.
\]

故 fooling 要求

\[
g-\rho_b\le\varepsilon.
\]

于是

\[
\boxed{
g>\varepsilon+\rho_b
\Longrightarrow
H\notin\mathcal C.}
\]

大小至多 \(b\) 的 \(\log N\)-变量电路总数满足

\[
\#\operatorname{Circuit}[b]
\le
2^{O(b\log(b+\log N))}.
\]

因此

\[
\rho_b
\le
2^{-N+O(b\log(b+\log N))}
=o(1)
\]

在 Frontier B 的 \(b=2^{(\log N)^{2/3}}\) 下成立。

所以确实不必要求所有 seeds 都产生 YES instances；任意超过 fooling error 的常数比例已经足够。

## 二、\(\sqrt s\) 偏差尺度的必要性

取互不相交的 \(m\) 个二变量块，定义

\[
h_i(x)=(-1)^{x_{2i-1}\wedge x_{2i}},
\qquad
f(x)=\prod_{i=1}^{m}h_i(x).
\]

\(f\) 是 \(m\) 个 AND\(_2\) 输出的 parity。用平衡 De Morgan parity 公式可得

\[
L(f)=O(m^2).
\]

单个 \(h_i\) 的四个 Fourier 系数绝对值均为 \(1/2\)。由张量乘积，

\[
|\widehat f(S)|=2^{-m}
\qquad
(\forall S\subseteq[2m]),
\]

且

\[
\mu:=\mathbb E_U[f]=2^{-m}.
\]

固定 \(0<\alpha\le1/3\)，定义分布 \(D\) 相对均匀分布的密度

\[
\frac{D(x)}{U(x)}
=1+\alpha(f(x)-\mu).
\]

它非负且期望为 \(1\)，所以是合法分布。对任意非空 character \(\chi_S\)，

\[
|\mathbb E_D[\chi_S]|
=\alpha|\widehat f(S)|
=\alpha2^{-m}.
\]

故 \(D\) 是

\[
\beta=\alpha2^{-m}
\]

biased。另一方面，

\[
\begin{aligned}
\mathbb E_D[f]-\mathbb E_U[f]
&=\alpha\mathbb E_U[f(f-\mu)]\\
&=\alpha(1-\mu^2)
=\Omega(1).
\end{aligned}
\]

取 \(s=\Theta(m^2)\)，得到：

\[
\boxed{
\exists f\in\operatorname{FORMULA}[s],\
\exists D\text{ that is }2^{-\Theta(\sqrt s)}\text{-biased},
\quad
|\mathbb E_Df-\mathbb E_Uf|=\Omega(1).}
\]

因此，任何只以 small bias 为假设、constant-fool 所有 \(\mathcal C_s\) 的定理必须要求

\[
\beta\le2^{-\Omega(\sqrt s)}.
\]

Kabanets 等的

\[
\beta
=
2^{-O(\sqrt s\log s)}
\]

中，\(\log s\) 可能来自近似多项式 Fourier \(\ell_1\) 范数的粗界；但 \(\sqrt s\) 不可由该框架删除。

## 三、small bias 对低复杂度输出的反集中

若 \(D\) 是 \(\beta\)-biased，则 Fourier inversion 给任意 \(x\in\{0,1\}^N\)

\[
\Pr[D=x]
=2^{-N}
\;+
\sum_{\varnothing\ne S}
2^{-N}\widehat D(S)\chi_S(x)
\le
2^{-N}+(1-2^{-N})\beta
\le2^{-N}+\beta.
\]

大小至多 \(a\) 的 \(\log N\)-输入电路至多产生

\[
M_a
\le
2^{O(a\log(a+\log N))}
\]

张真值表。故

\[
\boxed{
\Pr_{X\sim D}[\operatorname{CC}(X)\le a]
\le
2^{O(a\log(a+\log N))}
(\beta+2^{-N}).}
\]

代入

\[
s=N^{1.01},
\qquad
a=2^{(\log N)^{1/3}},
\qquad
\log(1/\beta)=\Theta(\sqrt s)
\]

可得

\[
a\log(a+\log N)=o(\sqrt s)
\]

以及

\[
\Pr[\operatorname{CC}(X)\le a]
\le2^{-\Omega(N^{0.505})}.
\]

若使用 Kabanets 等实际的 \(\log(1/\beta)=\Theta(\sqrt s\log s)\)，指数相应增强为 \(-\Omega(N^{0.505}\log N)\)。

这与第一节的充分条件方向相反：

\[
g\text{ 必须大于常数}
\qquad\text{但}\qquad
g\le2^{-\Omega(N^{0.505})}.
\]

所以“多数固定 seeds 的输出电路远小于统一 evaluator”无法拯救 small-bias 构造。

更一般地，令

\[
a_0
=
c\,
\frac{\log(1/\beta)}
{\log(\log(1/\beta)+\log N)}
\]

并取足够小常数 \(c>0\)，则上式显示

\[
\Pr[\operatorname{CC}(X)\le a_0]
\le2^{-\Omega(\log(1/\beta))}.
\]

因此几乎所有输出的非一致电路复杂度也至少是 \(\widetilde\Omega(\log(1/\beta))\)，不仅统一 evaluator 很大。

## 四、路线裁决

~~~mermaid
flowchart LR
    S["Formula-XOR<br/>size s"] --> B["small bias 必须<br/>β ≤ 2^-Ω(√s)"]
    B --> A["输出分布反集中"]
    A --> C["几乎所有 truth tables<br/>CC ≥ ~Ω(√s)"]
    C --> X["无法进入 Frontier B<br/>YES threshold"]
~~~

以下路线永久关闭：

\[
\begin{aligned}
&\text{只改进 Kabanets 等证明中的 }\log s;\\
&\text{保留 small-bias 分布，改用平均-seed locality};\\
&\text{希望固定 seeds 自动拥有亚多项式非一致电路}.
\end{aligned}
\]

剩余接口必须同时满足：

\[
\boxed{
\begin{array}{l}
\text{fool }\operatorname{FORMULA}[N^{1.01}]
\circ\operatorname{XOR},\\
\Pr[\operatorname{CC}(G(z))
\le2^{(\log N)^{1/3}}]>\varepsilon+o(1),
\end{array}}
\]

但其输出分布不能要求 \(2^{-\Omega(\sqrt s)}\)-small bias。换言之，新 PRG 必须利用 Formula-XOR 的结构，而不能先 fool 所有 parity 再经通用近似多项式组合。

## 能推出什么

- all-seed locality 可放宽为正比例 good seeds；
- small-bias 框架仍无法满足该放宽；
- \(\sqrt s\) 是 small-bias-only fooling 的必要尺度；
- 下一构造必须离开通用 small-bias composition。

## 不能推出什么

- 未证明任意 Formula-XOR PRG 都需要 \(\sqrt s\) locality；
- 未排除非-small-bias、低复杂度 support 的 PRG；
- 未取得 Frontier B 下界。

## 原始来源

- Kabanets, Koroth, Lu, Myrisiotis and Oliveira, *Algorithms and Lower Bounds for De Morgan Formulas of Low-Communication Leaf Gates*, CCC 2020, DOI: 10.4230/LIPIcs.CCC.2020.15，Theorems 25、33–34。
- Cheraghchi, Kabanets, Lu and Myrisiotis, *Circuit Lower Bounds for MCSP from Local Pseudorandom Generators*, ICALP 2019, DOI: 10.4230/LIPIcs.ICALP.2019.39。
