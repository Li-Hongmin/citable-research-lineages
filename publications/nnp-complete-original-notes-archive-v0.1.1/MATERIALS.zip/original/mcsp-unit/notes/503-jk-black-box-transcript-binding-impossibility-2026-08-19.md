> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Black-box JK transcript binding impossibility (2026-08-19)

## 本轮改变的判断

C502 证明了一个固定的 hard outsider 仍可对应近
\(2^{T/2}\) 个不同 parents。这里把该事实升级为一个明确的
**black-box Closure compiler theorem**：

> 任何只把 AVOID generator、Jeřábek--Korten 的
> “hard/stage/position/outsider” transcript，以及一个 parent-dependent
> descriptor 作为输入的统一 binder，都不能在整个合法 parent family 上产生
> exact address evaluator，除非 descriptor 本身支付 \(\Omega(T)\) 信息。

这不是把 C502 重新命名。新增的量词是对**任意 black-box compiler** 的否定：
相同的 \(G\) 和相同 transcript 必须被同一个编译器处理，因而 descriptor
映射必须区分整个 parent fiber。该结论精确说明当前 Closure 路线必须引入
source-specific restriction \(f=f_i(x_0)\)、一个新的全局关系，或显式支付
object-scale information；不能从“child 很 hard”直接跳到 \(P/\mathrm{poly}\)。

## 定义

令 \(n=2^k\)，
\[
r_n=2\lceil\log_2(n+2)\rceil,\qquad
\mathcal S_n=\{0,1\}^n\setminus\{1^{r_n}v:v\in\{0,1\}^{n-r_n}\},
\]
并取 C501 的 sentinel-padded P-uniform generator \(G_n^\star\)。令
\[
m:=2^{k-1}-1,\qquad T:=n2^k.
\]

由于 \(|\mathcal S_n|^2>2^n\)（充分大的 \(n\)），而
\(|\operatorname{Range}(G_n^\star)|\le2^n\)，存在
\[
y_n=a\Vert b\notin\operatorname{Range}(G_n^\star),
\qquad a,b\in\mathcal S_n.
\tag{503.1}
\]
C501 的 canonical selector 给出
\(\mathcal S_n\subseteq\Gamma_0^\star\)，所以这个 \(y_n\) 的两个 halves
都位于 \(\Gamma_0^\star\)。同时 \(y_n\) 是 hard outsider：
\[
\operatorname{CC}(y_n)>\left\lfloor\eta\,\frac{n}{k}\right\rfloor
=\Omega(n/\log n).
\tag{503.2}
\]

对每个 \(\mathbf u=(u_1,\ldots,u_m)\in\mathcal S_n^m\)，定义长度为 \(T\) 的
parent table
\[
F_{\mathbf u}:=
(u_1\Vert u_1)\Vert\cdots\Vert
(u_m\Vert u_m)\Vert y_n.
\tag{503.3}
\]
记
\[
\mathcal F_n:=\{F_{\mathbf u}:\mathbf u\in\mathcal S_n^m\}.
\tag{503.3a}
\]
在 JK Theorem 3.1 的顶层 stage \(k\)，这些 \(F_{\mathbf u}\) 被分成
\(2^{k-1}\) 个 \(2n\)-bit blocks。前 \(m\) 个 blocks 在 range 中，最后一个
block 是唯一的 outsider \(y_n\)。

## 定理 503.1（black-box JK transcript-binding impossibility）

对充分大的 \(n=2^k\)，存在同一个
\[
\tau_n^\star=(\mathrm{hard},\,\mathrm{stage}=k,\,
\mathrm{position}=2^{k-1},\,y_n)
\tag{503.4}
\]
使得 JK Theorem 3.1 在每一个 \(F_{\mathbf u}\) 上都返回
\(\tau_n^\star\)。此外：

1. parent fiber 的大小为
   \[
   |\mathcal F_n|=|\mathcal S_n|^m
   \ge 2^{m(n-1)}
   =2^{(1-o(1))T/2};
   \tag{503.5}
   \]
2. \(\mathcal F_n\) 中存在
   \[
   \operatorname{CC}(F_{\mathbf u})
   =\Omega(T/\log T)
   \tag{503.6}
   \]
   的 parent；
3. 设 \(\mathsf E_n\) 是任意固定的 transcript-only binder。它接收
   \((G_n^\star,\tau_n^\star,s,j)\)，其中 \(s\in\{0,1\}^d\) 是所有
   parent-dependent information 的 descriptor，并输出一个 bit。若对每个
   \(\mathbf u\) 都存在 \(s_{\mathbf u}\) 使
   \[
   \mathsf E_n(G_n^\star,\tau_n^\star,s_{\mathbf u},j)
   =F_{\mathbf u}[j]\qquad(j\in[T]),
   \tag{503.7}
   \]
   则
   \[
   d\ge\log_2|\mathcal F_n|
   \ge(2^{k-1}-1)(n-1)
   =(1-o(1))T/2.
   \tag{503.8}
   \]
   若 descriptor 必须在所有 parents 间共享，则该 binder 根本不可能同时正确，
   因为 \(|\mathcal F_n|>1\)。

### 证明

由 (503.1)，最后一个 block 是唯一的 non-range block；每一个
\(u_j\Vert u_j\) 都在 range。因此 JK 在顶层 stage 的所有 range-membership
查询对前 \(m\) 个 blocks 返回 YES，对最后一个 block 返回 NO，并输出同一个
outsider \(y_n\)。这证明了 (503.4)。

不同的 \(\mathbf u\) 给出不同的 concatenated parent，故 (503.5) 成立。
在 C501 的 sentinel branch 中，
\[
\log_2|\mathcal S_n|
=\log_2(2^n-2^{n-r_n})\ge n-1,
\]
从而得到 descriptor payment (503.8)。

若两个不同 parents 使用同一个 descriptor \(s\)，则
\((G_n^\star,\tau_n^\star,s,j)\) 对每个 address \(j\) 完全相同，
\(\mathsf E_n\) 必须输出同一张 table，不可能同时等于两个不同的 parents。
因此 \(\mathbf u\mapsto s_{\mathbf u}\) 必须是 injective，得到
\(2^d\ge|\mathcal F_n|\)。

最后，输入地址长度为 \(\lceil\log_2(T+1)\rceil\)。标准 fan-in-two circuit
编码给出：大小至 \(c\delta T/\log_2(T+2)\) 的所有 circuits 总数至多
\(2^{C\delta T}\)。取固定足够小的 \(\delta>0\)，该数量小于
\(|\mathcal F_n|=2^{(1-o(1))T/2}\)，故 fiber 中存在满足 (503.6) 的 parent。
\(\square\)

## 对 Closure 的直接影响

定理 503.1 关闭了一个特定的黑箱跳步：
\[
\text{hard child}
\;+\;\text{stage/position/path}
\;\not\Rightarrow\;
\text{parent address binding}.
\]

它并不声称 Theorem 4.3 的具体单个 \(f_i(x_0)\) 必然等于
\(\mathcal F_n\) 中的某个 parent，也不声称 Ren--Williams 的 AVOID 算法会在
这些长度输出这个特定 \(y_n\)。因此它不能直接把 family entropy 转移给
published singleton。它的精确结论是：

* 只使用 Theorem 3.1 的黑箱 transcript 语义，不能得到 actual singleton 的
  \(P/\mathrm{poly}\) evaluator；
* 若要继续 Gate I，必须证明 \(f_i(x_0)\) 落入一个受约束的 source-specific
  subclass，并从该 subclass 给出 address-scale binding；
* 或者引入一个不从 transcript 展开的 global relation，并把其 parent-dependent
  information/控制成本显式计入；
* 允许每个 parent 使用不同的长 code、ROM 或 advice 只是在 descriptor 中重新
  命名这些信息，不是逃逸。

因此，C503 是一个可独立陈述的 RW/JK black-box impossibility theorem，但不是
一般 dPCP/RLDC 不可能性、不是 published singleton impossibility，也不是
\(P\ne NP\) 证明。

## 来源

* [C501](501-sentinel-padded-truth-table-generator-canonical-gamma-closure-2026-08-19.md).
* [C502](502-sentinel-hard-outsider-parent-binding-separation-2026-08-19.md).
* [C497](497-jk-canonical-liftable-range-projection-barrier-2026-08-19.md).
* Ren--Williams TR26-118 rev.1, Theorem 3.1 and Theorem 4.3:
  units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md.
