> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# CLL hard string 是 iterated decoder 的 outsider（2026-08-15）

## 定理

令

\[
  G_q:\{0,1\}^{q}\longrightarrow\{0,1\}^{2q}
\]

是固定 decoder。定义其 expansion：

\[
  \operatorname{Exp}_{G,0}(u)=u,\qquad
  \operatorname{Exp}_{G,h+1}(u)
  =
  \operatorname{Exp}_{G,h}(G_q(u)_{L})
  \Vert
  \operatorname{Exp}_{G,h}(G_q(u)_{R}),
\]

其中 \(G_q(u)_L,G_q(u)_R\) 是输出的两个 \(q\)-bit halves。按此定义，
\(\operatorname{Exp}_{G,d}\) 的长度是 \(q2^d\)。若 \(w_n\) 是长度
\(2q\,2^h=q2^{h+1}\) 的 truth table，并且

\[
  \operatorname{CC}(w_n)
  >
  q+(h+1)\lvert G_q\rvert+\operatorname{poly}(h,q),
\tag{1}
\]

则

\[
  w_n\notin\operatorname{Range}(\operatorname{Exp}_{G,h+1}).
\tag{2}
\]

### 证明

若 \(w_n=\operatorname{Exp}_{G,h+1}(u)\)，把 \(u\) 的 \(q\) 个 bit hardwire 进电路。
给定输出地址，沿深度 \(h+1\) 的二叉路径重复计算 \(G_q\)，每层选择相应的
left/right half，即得到 \(w_n\) 的一个多输出电路。其大小至多
\(q+(h+1)\lvert G_q\rvert+\operatorname{poly}(h,q)\)，与 (1) 矛盾。证毕。

## 应用于 CLL canonical hard strings

CLL 的 \(\Pi_{\mathrm{hard}}\) 字符串在无限多个 \(n\) 上满足

\[
  \operatorname{CC}(w_n)\ge\frac{2^n}{n}.
\]

因此，取 \(q(n)\) 为二的幂（一般 \(q\) 可零填充到下一个二的幂），选择二的幂长度
\(M_n=2q(n)2^{h(n)}\ge 2^n\)，并把 \(w_n\) 放在前 \(2^n\) 个 truth-table
entries、其余位置置零。固定多余的高位地址为零即可从 padded table 恢复 \(w_n\)，
所以若用标准 fan-in-2 电路度量，padded table 的复杂度至少为
\(\operatorname{CC}(w_n)-O(\log M_n)\)，仍为 \(2^n/n-o(2^n/n)\)。对任意固定常数 \(c\)，只要

\[
  q(n),\ \lvert G_{q(n)}\rvert\le n^c,\qquad h(n)=O(n),
\]

并将 \(w_n\) 按上述方式 zero-pad 到长度 \(2q(n)2^{h(n)}\)，充分大的 hard lengths
上都有

\[
  w_n\notin\operatorname{Range}(\operatorname{Exp}_{G,h+1}).
\tag{3}
\]

这是一条无条件的、针对**迭代 range** 的 outsider 结论；它不需要 universal
coverage lower bound，也不依赖 decoder 是线性、系统性或 canonical。

## 它没有说明什么

式 (3) 不推出某个底层 \(2q\)-bit leaf block 已经不在
\(\operatorname{Range}(G_q)\)。完全可能出现：

1. 所有 leaf blocks 都有 \(q\)-bit preimages；
2. 但两个相邻 leaf preimages 的 concatenation 在下一层不再是合法
   \(G_q\)-preimage；
3. 第一个 non-image 只在某个 parent 或更高节点出现。

因此 one-level coverage 与 full JK closure 必须严格区分。

## 第一出界节点的可行接口

假设每个 actual leaf block \(B_v\) 有一个 deterministic、word-consistent seed
\(S(v)\)，并且 \(S(v)\) 的每一位可以在 \(\operatorname{poly}(n)\) 时间/电路中随机访问。
对相邻 children 定义候选 parent

\[
  Z_v:=S(v_0)\Vert S(v_1).
\]

逐层检查 \(Z_v\in\operatorname{Range}(G_q)\)：

- 若某个 \(Z_v\notin\operatorname{Range}(G_q)\)，它就是一个可局部生成的
  non-range witness；
- 若所有检查都通过，并且每个 parent 都继续有同一 seed law 的 word-consistent
  preimage，则最终得到式 (2) 的 root seed，与 CLL hard lower bound 矛盾。

所以对 CLL history，任何成功的 whole-tree attempt 必须在以下两处之一失败：

\[
\boxed{
\text{leaf seed/accessor 不存在}
\quad\text{或}\quad
\text{某个 JK parent 是 non-range outsider}.
}
\]

难点不再是证明“有 outsider”：式 (3) 已经给出；难点是用
smart range query 在地址尺度找到第一个 \(Z_v\)，同时保持整词一致和 promise
条件。这个正是 RW/JK 剩余接口，而不是 generic PCP canonicality。

## 与已有结果的关系

- [note 150](150-cll-hard-string-forbids-polynomial-address-accessor-2026-08-15.md)
  排除了 CLL hard string 的 polynomial-address deterministic bit accessor；
- 本 note 进一步排除其 polynomial-size **iterated decoder range**；
- [note 105](105-jk-pair-lift-capacity-and-pair-rich-prefix-2026-08-15.md) 给出一般
  pair-lift 的容量障碍，但不指定一个已经证明 hard 的 history；
- [note 121](121-local-jk-smart-prma-would-separate-p-np-2026-08-15.md) 说明若能把
  第一 non-range 节点在 smart-\(\mathrm{prMA}\) 地址尺度输出，则可推出
  \(P\ne NP\)。

## 来源与边界

- Lijie Chen, Jiatu Li, Jingxun Liang, *Maximum Circuit Lower Bounds for
  Exponential-Time Arthur Merlin*, ECCC TR24-182 revision 2：
  [official report](https://eccc.weizmann.ac.il/report/2024/182/)。
- [note 150](150-cll-hard-string-forbids-polynomial-address-accessor-2026-08-15.md)。

本定理是 CLL hard string 与 JK expansion 的自足组合，不声称已经找到第一
non-range 节点，也不声称已经证明 \(P\ne NP\)。

核验日期：2026-08-15。
