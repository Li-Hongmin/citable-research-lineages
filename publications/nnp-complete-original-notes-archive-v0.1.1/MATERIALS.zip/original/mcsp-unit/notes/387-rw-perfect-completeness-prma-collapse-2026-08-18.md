> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW 完美完备 prMA 查询在 \(P=NP\) 下的 source-specific 确定化（2026-08-18）

## 命题

RW Definition 2.1 的 prMA 不是一般的 bounded-gap 版本，而具有完美完备性：
对每个 YES query，存在 witness \(w\) 使

\[
\Pr_r[V(q,w;r)=1]=1.
\tag{387.1}
\]

而对每个 NO query 与每个 witness \(w\)，

\[
\Pr_r[V(q,w;r)=1]\le 1/2.
\tag{387.2}
\]

令

\[
L_{\mathrm{all}}
:=
\{q:\exists w\;\forall r\;V(q,w;r)=1\}.
\tag{387.3}
\]

由于 witness 和随机带长度都是 \(\operatorname{poly}(|q|)\)，而 \(V\) 是
多项式时间确定性 verifier，(387.3) 是一个 \(\Sigma_2^P\) 语言。若 \(P=NP\)，
则 \(PH=P\)，所以存在一个固定的多项式时间算法 \(D_{\mathrm{all}}\) 决定
\(L_{\mathrm{all}}\)。

对 RW promise 两侧，\(D_{\mathrm{all}}\) 是正确的 promise-preserving simulator：

* YES query 由 (387.1) 给出一个对所有随机带都接受的 witness，故
  \(q\in L_{\mathrm{all}}\)；
* NO query 若存在对所有随机带都接受的 witness，则接受概率为 1，与 (387.2)
  矛盾，故 \(q\notin L_{\mathrm{all}}\)；
* gap query 上 \(D_{\mathrm{all}}\) 的值任意，不影响 promise 语义。

因此 published RW 的 smartness 加上 \(P=NP\) 已足以把实际 Reconf query
确定化，且不需要枚举 \(\operatorname{polylog}(t)\) 随机带。

## 对 C363 与 Gate-III 的后果

在 RW 标准 query 编码下，若 Reconf query 的描述长度为

\[
L=\operatorname{poly}(k,r,\log t),
\tag{387.4}
\]

则 \(D_{\mathrm{all}}\) 的运行时间为 \(L^{O(1)}\)。C363 的 failure-to-circuit
组合因此在 \(P=NP\) 下无需另加 promise-preserving simulator 假设：

\[
\mathsf{Solve}_f(x,G_k)\text{ failure}
\Longrightarrow
\operatorname{CC}(f(x))
\le (k+r+\log T)^{O(1)}.
\tag{387.5}
\]

这真正关闭了 Gate-III 的 promise-totalization 子门。C386 的
\(2^{O(R)}L^{O(1)}\) 枚举成本仍是一般 bounded-gap、非完美完备 prMA
格式的有效上界，但不应再作为 published RW Reconf 的必要成本。

## 仍未闭合的部分

该 source-specific collapse 不等于 \(P\ne NP\) 证明。它只把最终路线收缩为：

1. 若 \(k+r+\log T\) 保持 object-scale，C363 不能与 near-maximum forcing
   发生矛盾；
2. 若把 \(k,r\) 压到 address scale，failure 分支被硬度排除，Theorem 4.1
   只留下 \(y\notin\operatorname{Range}(G_k)\) 的 success outsider；
3. 仍需 C383 所要求的 output-attached multi-block 或 auxiliary-to-output
   parent-binding，才能把 outsider 变成同一个 hard parent 的地址 evaluator。

所以当前真正的 Gate-III 已经通过 promise 层，主要瓶颈回到 Gate-I：

\[
\boxed{\text{success outsider}\Longrightarrow
\text{same-parent address-scale evaluator}}
\]

## 证据边界

* Ren--Williams Definition 2.1（source extraction，第 7 页）给出完美完备性
  \(\Pr[A(x,w,r)\text{ accepts}]=1\) 与 NO 侧至多 \(1/2\)；
  Theorem 4.1 的 Reconf query 正是该 prMA oracle 的标准 verifier 编码。
* \(L_{\mathrm{all}}\in\Sigma_2^P\) 是直接的 \(\exists w\,\forall r\) 表达；
  \(P=NP\Rightarrow PH=P\) 给出多项式确定化。
* 本 note 只证明 published RW promise 层的 source-specific collapse；不声称
  非完美完备性的任意 promise-prMA 都在 \(P=NP\) 下 collapse，也不声称
  success outsider 已经附着到 parent。
