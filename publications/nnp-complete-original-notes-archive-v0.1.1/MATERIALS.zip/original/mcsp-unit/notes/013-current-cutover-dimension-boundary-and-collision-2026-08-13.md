> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 当前承重结论：维数势的唯一边界与递归碰撞势（2026-08-13）

## 1. 本轮改变的决策

本轮不再把“纯仿射维数 quasi-additive 势”作为一个未分解的黑箱问题。它已经被严格压缩到一个特殊情形；同时，正的距离势、近期 AC⁰∘XOR/strong-KW 迁移和 local-PRG 捷径均不能直接到达 Frontier B。

当前真正值得继续的原子问题是：

> 当一个大 parity-monochromatic 矩形的两侧都恰为 affine-independent（大小分别为仿射维数加一）时，能否用高阶 affine collision 的递归势给出超线性 QA 下界？

这比继续搜索一般的“参数缺口”更窄，也更容易被一个明确反例或一个有限证明义务终止。

## 2. 纯维数 ansatz 的严格融资定理

令 (X,Ysubseteqmathbb F_2^N) 不交，(m=|X||Y|)。限制 quasi-additive 证书为

\[
K(A,B)=(m-|A||B|)h(p,q),
\qquad p=\dim\operatorname{aff}A,quad q=\dim\operatorname{aff}B,
\]

并令 (phi_c\equiv\alpha)。叶约束和递归约束分别为

\[
\alpha|A||B|+K(A,B)\le 1,
\tag{leaf}
\]

对每个 parity-monochromatic 矩形，以及

\[
K(V)+K(W)\ge K(A,B)
\tag{recursion}
\]

对每个横向或纵向二分 (A\times B=V\dot\cup W)。若 (alpha\le0)，目标上界是平凡的；以下假设 (alpha>0)。

随机选择有向 affine parity。对每个 (x\ne y)，它以概率 (1/4) 产生 (\ell(x)=0,\ell(y)=1)，故存在一个合法单色矩形 (R=A\times B)，满足

\[
nk:=|A||B|\ge m/4.
\tag{1}
\]

设 (n=|A|, k=|B|, p=\dim\operatorname{aff}A, q=\dim\operatorname{aff}B)。

### 情形一：(h(p,q)\ge0)

叶约束直接给出

\[
\alpha m\le \frac{m}{nk}\le4.
\tag{2}
\]

### 情形二：(h(p,q)=-t<0)，且 (n>p+1)

取 (A_1\subset A) 为 affine basis，(|A_1|=p+1)，令 (A_2=A\setminus A_1)，(n_2=|A_2|=n-p-1>0)。必须有

\[
\dim\operatorname{aff}A_2<p.
\tag{3}
\]

否则两个子矩形都具有维数 ((p,q))，而递归左边减右边恰为 (m h(p,q)=-mt<0)，违反递归约束。

把递归约束代入，并记 (r=\dim\operatorname{aff}A_2<p)，得到

\[
(m-n_2k)h(r,q)\ge n_2kt.
\tag{4}
\]

由于 (A_2\times B) 仍是单色矩形，叶约束和 (4) 合并为

\[
n_2k(\alpha+t)\le1.
\tag{5}
\]

于是

\[
\alpha m\le \frac{m}{n_2k}
\le4\frac n{n-p-1}.
\tag{6}
\]

若 (n\ge2(p+1))，右侧不超过 (8)；若 (n<2(p+1))，则 (n\le2N+1)，从而

\[
\alpha m\le 8N+4.
\tag{7}
\]

交换 (A,B) 后，同样处理 (k>q+1) 的情形。因此，除 (O(N)) 外唯一剩下的是

\[
\boxed{h(p,q)<0,quad n=p+1,quad k=q+1.}
\tag{8}
\]

也就是说，抽到的承重矩形两侧都恰好是 affine-independent；“取 affine basis 再留下非空余集”的融资机制在这里确实失效。这是一个严格的新缩减，不是数值实验或启发式判断。

## 3. MCSP 语义路线的两个严格关闭点

### 3.1 正的距离势不能超线性

令 (E_a=\{x:\operatorname{CC}(x)\le a\})，(NO_b=\{y:\operatorname{CC}(y)>b\})，真值表长度为 (N=2^n)。若 (x\in E_a,y\in NO_b)，且它们的 Hamming 距离为 (d)，则把 (x) 的电路和至多 (d) 个例外 minterm 合并，可得

\[
\operatorname{CC}(y)\le a+O(d\log N).
\]

故 (d=\Omega((b-a)/\log N))。对所有非负 ((\phi,\psi)) 的 QA 势，求和坐标 parity 叶立即给

\[
\sum_{(x,y)\in E_a\times NO_b}\phi_{x,y}
\le O\!\left(\frac N{(b-a)/\log N}\right).
\]

用全部 affine parity 叶时上界甚至降到常数级。因而若要超过 (N^{1.01})，必须允许负的递归项；它们不能只编码距离或电路描述长度。

### 3.2 近期模型迁移没有现成桥

2024--2026 的定向原始文献检索没有发现直接得到 Formula-XOR/GapMCSP (N^{1.01}) 下界的定理。Riazanov--Sofronova--Sokolov 的 ITCS 2026 结果只给受限 AC⁰∘XOR 模型，并明确暴露了

\[
\forall L\ \exists y_L
\quad\text{与}\quad
\exists y\ \forall L
\]

之间的量词缺口；strong (KW_{\mathrm{XOR}}) 的近期 lifting 也要求固定坐标输出，而 Formula-XOR 叶可以为每一对输入选择任意 affine parity。Carmosino--Dang--Jackman 的 XOR-simple-extension 可解性则关闭了一条 total-MCSP 捷径，而非给出下界。local-PRG 的已知 locality 在 (s=N^{1.01}) 时约为 (N^{0.505+o(1)})，大于 Frontier B 的 (2^{(\log N)^{1/3}})。

## 4. 下一种可行势：定向 odd--odd affine collision

取一个四点 cell (H=\{(x_i,y_i)\}_{i=1}^4\)，若存在不交奇子集 (I,J) 使

\[
\bigoplus_{i\in I}x_i=\bigoplus_{j\in J}y_j,
\qquad |I|,|J|\text{ 为奇数},
\]

则 (H) 不可能整体落入同一个 affine-parity 单色矩形。对这类超边，除了对命中数作对称化，还可以保留一个方向。取一个三点子集 (T) 和一个 spoiler 点 (s)，令 (H=T\cup\{s\}) 为上述 collision cell，并定义

\[
G_{T,s}(R)=\mathbf1_{s\in R}-\mathbf1_{T\subseteq R}.
\tag{10}
\]

这是一个比只依赖 (|H\cap R|) 的势更强、但递归验证更简单的模板。对任意 (R=V\dot\cup W)，第一项完全可加，而

\[
\mathbf1_{T\subseteq V}+\mathbf1_{T\subseteq W}
\le \mathbf1_{T\subseteq R},
\]

故

\[
G_{T,s}(V)+G_{T,s}(W)\ge G_{T,s}(R).
\tag{11}
\]

并且 (G_{T,s}(C)=1-1=0)。因此任意非负权重 (\lambda_{T,s}) 的和

\[
K(R)=\sum_{T,s}\lambda_{T,s}G_{T,s}(R)
\tag{12}
\]

自动满足 QA 的递归约束。由于单色 affine-parity 叶不能包含整个 (T\cup\{s\})，在一个单色叶上，(G_{T,s}) 的唯一负值情形是 (T\subseteq R, s\notin R)。

这把单叶承重义务压缩成一个定向覆盖问题：能否选择 collision 三元组 (T) 和 spoiler (s)，使每个大 affine-separable 叶含有很多被选中的 (T)，而含有相应 spoiler 的数量较少？

对称化势的定义如下：

\[
g(0),g(1),g(2),g(3),g(4)=(0,1,0,-1,0).
\]

直接检查 (g(a)+g(b)\ge g(a+b))（(a+b\le4)）可知，对任意递归二分 (R=V\dot\cup W)，

\[
K_H(V)+K_H(W)\ge K_H(R),
\qquad
K_H(R)=\mathbf1_{|H\cap R|=1}-\mathbf1_{|H\cap R|=3}.
\]

对非负权重 (\lambda_H) 求和，得到合法的递归碰撞势。它第一次明确实现了

\[
\text{三命中负势}\quad\leftrightarrow\quad\text{一命中正势}。
\]

剩下的具体承重义务是：能否按 (E_a\times NO_b) 的电路语义选择 (\lambda_H\)，使每个 affine-separable 叶上的三命中质量系统性超过一命中质量，并让 (leaf) 的目标超过 (N^{1.01})。目前尚未证明，也没有把小规模 LP 当成证据。

### 定向势的下一承重义务

优先研究 (G_{T,s})，而不是先枚举对称化的四点权重。需要按 (E_a\times NO_b) 的语义选择 (\lambda_{T,s})，证明每个 affine-separable 叶上的三元组命中质量系统性超过 spoiler 命中质量；目前没有这样的不等式，也不把小规模 LP 当成证据。

## 5. 下一轮停止条件

只做一个有限问题：对定向势 (G_{T,s})，寻找一种由电路描述/低复杂度分层定义的 (\lambda_{T,s})，并证明或反驳一个单叶不等式。若该不等式失败，则停止继续堆叠“维数 + 碰撞”的启发式，转向更高阶的 quasi-additive/communication lifting；若成立，再检查是否能把总目标推进到 (N^{1.01})。
