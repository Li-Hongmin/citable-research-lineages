> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Smoothness barrier for the GMWZ field-lift compiler (2026-08-17)

## Contribution

The field-lifted singleton compiler in note 217 converts a distributionally sound dPCP
into one global proof with coordinate-robust output claims.  Its error bound contains the
outer decoder's smoothness parameter:

\[
  \beta_{\mathrm{wrong}}\le q_D\lambda\varepsilon .
\tag{233.1}
\]

This is not merely a proof artifact.  For the current Gur--Minzer--Weissenberg--Zheng
(GMWZ) 3-query RLDC, the decoder for message coordinate \(i\) reads an \(i\)-specific
proof block of size \(K\), while the whole codeword has length \(\Theta(kK)\).  Hence

\[
  \lambda=\Omega(k).
\tag{233.2}
\]

Therefore the black-box field-lift route must invoke the dPCP with
\(\varepsilon=O(1/k)\) to obtain a constant coordinate gap.  The published GMWZ theorem
then gives a list size and alphabet/exponent parameters depending on \(k\); its fixed
\(\varepsilon\), fixed-alphabet near-linear statement cannot be silently promoted to the
uniform RW/JK interface.

This is a parameter theorem about the current positive baseline, not an impossibility
result for all globally shared dPCPs.  A successful near-linear construction must make
the outer decoder globally smooth, share query support across coordinates, or introduce
a new mechanism not covered by the field-lift reduction.

## Smooth field-lift lemma

Let \(C:\{0,1\}^k\to\Gamma^M\) be an outer code.  For message coordinate \(i\), let
\(Q_i\) be the (possibly adaptive) set of outer positions queried by a decoder, and define

\[
  \lambda(C,D):=
  M\cdot\max_{i,t}\Pr[t\in Q_i\mid\text{the honest codeword path}].
\tag{233.3}
\]

Assume an inner dPCP has a uniform complete decoding distribution over the \(M\) output
positions and list-decoding error at most \(\varepsilon\).  Suppose every valid assignment
decodes to the same outer codeword \(C(m_x)\), as in the singleton-output field lift.
If the outer decoder makes at most \(q_D\) queries and never outputs a wrong bit on the
exact codeword, then the compiled verifier for the wrong claim has acceptance probability

\[
  \Pr[\mathrm{accept\ wrong\ claim}]
  \le q_D\lambda(C,D)\varepsilon .
\tag{233.4}
\]

### Proof

Couple the compiled execution to its honest execution.  Until the first locally accepted
projection different from \(C(m_x)\), the adaptive outer path is the honest path.  For an
outer query at position \(t\), let \(e_t\) be the probability, over the dPCP edge
distribution conditioned on \(t\), of an accepted projection differing from \(C(m_x)_t\).
Uniform complete decoding and list soundness give

\[
  \frac1M\sum_{t=1}^{M} e_t\le\varepsilon.
\tag{233.5}
\]

For each of at most \(q_D\) queries, the honest-path probability of visiting \(t\) is at
most \(\lambda/M\).  A union bound gives

\[
  \sum_{r=1}^{q_D}\sum_{t=1}^{M}\frac{\lambda}{M}e_t
  \le q_D\lambda\varepsilon.
\]

If no first wrong projection occurs, the outer decoder sees the exact codeword and cannot
output the wrong claim.  This proves (233.4). \(\square\)

## Block-local smoothness lower bound

Suppose that for every message coordinate \(i\), the honest decoder makes at least one
query in a block \(R_i\) of at most \(K\) proof positions, and all such blocks are
coordinate-specific.  Then for each \(i\), some \(t\in R_i\) is queried with probability
at least \(1/K\).  Hence

\[
  \lambda(C,D)\ge M/K.
\tag{233.6}
\]

This argument uses only the support size of one honest query distribution; it is unaffected
by adaptivity or by adding a constant number of extra queries.

## GMWZ instantiation

In the GMWZ RLDC construction, the codeword has two blocks of size \(2Kk\), so
\(M=4Kk\) up to the padding convention.  For a fixed \(i\), the decoder samples a position
from the \(B\)-part of the \(i\)-th PCPP block, whose size is \(K\) after repetition and
padding.  The source construction also uses an \(i\)-specific \(A\)-part.  Therefore

\[
  \lambda_{\mathrm{GMWZ}}\ge \Omega(k).
\tag{233.7}
\]

The precise constants and the negligible padding error do not affect this asymptotic
bound.  The cited construction has \(K=k\operatorname{polylog}(k)\), so its total length
is \(\widetilde O(k^2)\), while the fixed-coordinate query mass remains \(1/K\).

Combining (233.4) and (233.7), a constant wrong-claim gap requires

\[
  \varepsilon\le \frac{1}{2q_D\lambda_{\mathrm{GMWZ}}}
  =O(1/k).
\tag{233.8}
\]

## Consequence for the current dPCP theorem

The GMWZ dPCP theorem gives, for every fixed \(\varepsilon>0\), quasi-linear proof length,
constant query complexity, and constant alphabet depending on \(\varepsilon\) and the input
alphabet.  It also gives list size

\[
  L=\operatorname{poly}(1/\varepsilon).
\tag{233.9}
\]

At the value forced by (233.8), \(L=\operatorname{poly}(k)\), and the theorem's alphabet
constant and logarithmic length exponent are allowed to depend on \(k\).  Thus the
black-box composition proves neither:

* a fixed finite alphabet independent of the number \(k\) of output coordinates;
* a uniform \(N\operatorname{polylog}N\) construction with one fixed exponent;
* nor an RW address-scale verifier whose parameters are polynomial in the base address
  length rather than in the full history size.

This is exactly the point at which the current positive baseline stops.  The dPCP itself
is near-linear for each fixed error parameter, but the simultaneous coordinate requirement
forces an error parameter that changes with the number of coordinates.

## Research consequence

The field-lift route has a clean dichotomy:

1. **Globally smooth outer decoder:** \(\lambda=O(1)\), so fixed dPCP error can yield a
   constant coordinate gap.  Such an outer object must share query support across
   coordinates and should be tested against the RLDC/LDC barriers.
2. **Coordinate-private blocks:** \(\lambda=\Omega(k)\), so the dPCP error must be
   \(O(1/k)\), and the current GMWZ theorem loses uniform finite-alphabet/address-scale
   parameters.

Consequently, replacing GMWZ by a new dPCP with the same fixed-error parameters is not
enough.  The genuinely new target is a *globally smooth* RLDC/PCPP or a proof that every
such smooth object pays a superlinear length or LDC/RLDC cost.

## Evidence boundary

The GMWZ paper states that its 3-query RLDC has length
\(\widetilde O(k^2)\), and its construction stores one coordinate-specific PCPP block for
each message coordinate.  The dPCP theorem gives \(L=\operatorname{poly}(1/\varepsilon)\)
and fixed-\(\varepsilon\) constant-alphabet parameters.  The smoothness calculation above
is a direct support-counting consequence of that construction; it is not claimed as a
general lower bound for all RLDCs.

Source: Gur--Minzer--Weissenberg--Zheng, “3-Query RLDCs are Strictly Stronger than
3-Query LDCs,” arXiv:2512.12960, Theorems 3.12, 1.9, and the construction in Section 11.3;
the field-lift compiler and its \(q_D\lambda\varepsilon\) bound are in note 217.
