> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(p=O(\log N)\) 时 sampler range 属于 NP（2026-08-15）

## 定理

沿用 [note 091](091-noncanonical-sampler-decoder-image-range-2026-08-15.md) 的定义，令
\(N=2^m\)，并考虑固定 uniform schedules \(p=p(m)\)、\(t=t(m)\)。假设存在常数
\(c,d\) 使

\[
p(m)\le c\log_2N=cm,
\qquad
t(m)\le N^d.
\tag{1}
\]

并使用可在 \(\operatorname{poly}(N)\) 时间解析的 gate-list 语法。则固定语言

\[
L_{\mathrm{sam}}
 =
\bigcup_{m\ge1}\mathsf{SRange}_{m,p(m),t(m)}
\tag{2}
\]

属于 \(\mathsf{NP}\)。

## 证书与验证

对输入 \(y\in\{0,1\}^{N}\)，证书包含：

1. 一个长度为 \(\operatorname{poly}(N)\) 的 sampler 描述 \(E\)，门数不超过 \(t(m)\)；
2. 对每个 \(x\in\{0,1\}^{m}\)，一个代表 \(r_x\in\{0,1\}^{p}\)。

验证器先检查

\[
A_E(r_x)=x,
\qquad
B_E(r_x)=y_x
\tag{3}
\]

对所有 \(x\) 成立。于是每个地址都有代表，故 \(\operatorname{Full}(E)\) 成立，而且
选定代表的标签已经等于目标 truth table。

随后直接枚举所有 \(r,r'\in\{0,1\}^{p}\)，检查

\[
A_E(r)=A_E(r')
\Longrightarrow
B_E(r)=B_E(r').
\tag{4}
\]

式 (4) 正是 \(\operatorname{Cons}(E)\)。因为 \(p\le c\log_2N\)，枚举规模为
\(2^{2p}\le N^{2c}\)，每次电路值计算和 gate-list 解析都是
\(\operatorname{poly}(N)\)；总验证时间仍为 \(\operatorname{poly}(N)\)。因此 \(E\)
有效，并由式 (3)--(4) 得到 \(f_E=y\)，故 \(y\in L_{\mathrm{sam}}\)。

反向地，若 \(y=TT(f_E)\) 属于 sampler range，则取每个地址的任意代表 \(r_x\) 作为
证书；\(\operatorname{Full}\) 与 \(\operatorname{Cons}\) 保证验证通过。证毕。

## 与 \(p=m\) 端点的关系

当 \(p=m\) 时，note 093 已证明 \(\operatorname{Full}\) 强制地址映射为置换，
\(\operatorname{Cons}\) 自动成立。因此这里的证书可以进一步简化；但定理说明，
\(p=m+O(\log m)\) 以及更一般的 \(p=O(\log N)\) 仍没有逃出 NP 证书尺度。

## 路线含义

这个结论不是说 \(p>\Theta(\log N)\) 就一定得到更强语言；它只排除了一个便宜的参数区间：

\[
\boxed{
p=O(\log N)
\Longrightarrow
L_{\mathrm{sam}}\in\mathsf{NP}.
}
\tag{5}
\]

所以若要让 sampler range 成为一个可能承载 \(P\) vs \(NP\) 分离的新对象，必须至少进入
\(p=\omega(\log N)\) 的区间，或者提供一种不需枚举全部 fiber-pairs 的 succinct
certificate。note 089 的 PH-local merge 上界允许这样的 \(p\) 只要它仍为
\(N^{o(1)}\)，但当前没有对应的 range lower bound。

特别地，若在 \(p=O(\log N)\) 区间证明某个固定 \(L_{\mathrm{sam}}\notin P\)，就直接得到
\(P\ne NP\)；若证明固定 \(N^{1+\varepsilon}\) circuit lower bound，则得到更强的
\(NP\not\subseteq P/poly\)。本 note 不提供这些下界，只把 sampler 路线的第一个非平凡
参数区间定位为 \(p=\omega(\log N)\)。

原文核验日期：2026-08-15。
