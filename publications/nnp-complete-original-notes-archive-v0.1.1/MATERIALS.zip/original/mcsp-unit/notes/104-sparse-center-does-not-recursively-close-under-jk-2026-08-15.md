> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Sparse center + exception 不自动递归闭合（2026-08-15）

## 结论

外部回流报告把“中心编码 + 稀疏例外”列为可能的固定解压器路线。经与
[note 103](103-sparse-hamming-ball-decoder-and-budgeted-merge-obstruction-2026-08-15.md)
的显式 Hamming-ball decoder 对照，能严格晋级的结论是：

\[
\boxed{\text{一层的 center+sparse 表示不推出 JK 全树的 easy closure。}}
\]

真正足够的条件是一个贯穿整棵 JK 树的、可随机访问且指数稳定的 preimage labeling；逐块
拥有一个 range 表示并不够。

## 两层反例：稀疏 preimage 会失去预算

令

\[
N=2^m=2q,
\qquad
w=\left\lfloor\frac{q}{m+1}\right\rfloor,
\]

并使用 note 103 的 decoder。它的 range 是 Hamming 球

\[
\mathcal B_{N,w}=\{z\in\{0,1\}^N:\operatorname{wt}(z)\le w\}.
\]

取两个不相交的地址集 \(S_L,S_R\)，各含 \(w\) 个地址，并令 \(z_L,z_R\) 是它们的
指示向量。只要 \(N\ge 2w\)（这里对充分大的 \(m\) 显然成立），这样的集合存在，且
\(z_L,z_R\in\mathcal B_{N,w}\)。

任一 seed 若产生 \(z_L\)，则每个 \(x\in S_L\) 至少需要一个启用的地址槽。每个启用槽
至少贡献一个 flag 位，因此任一 preimage \(u_L\) 满足

\[
\operatorname{wt}(u_L)\ge w.
\]

同理，对任意产生 \(z_R\) 的 preimage \(u_R\)，有
\(\operatorname{wt}(u_R)\ge w\)。于是

\[
\operatorname{wt}(u_L\Vert u_R)
\ge 2w>w,
\]

从而

\[
u_L\Vert u_R\notin\mathcal B_{N,w}.
\tag{1}
\]

这说明：即使两个相邻子块各自位于 decoder range，任何把它们的 canonical address-list
preimages 直接拼接的下一层表示都可能离开同一 range。该反例只针对 note 103 的具体编码；
它不排除另一个使用不同 code 的 decoder。

## 全树条件，而非逐块条件

设 \(G\) 是一个候选 block decoder。对 JK 树第 \(i\) 层第 \(j\) 个实际出现的 block，要求存在
一个记录

\[
\rho_{i,j}=(c_{i,j},S_{i,j}),
\qquad |S_{i,j}|\le w,
\]

并有固定的 packed representation \(\operatorname{Rep}(\rho_{i,j})\) 满足

\[
G(\operatorname{Rep}(\rho_{i,j}))=z_{i,j}.
\]

还必须存在一个单一的 joint accessor

\[
A_n(i,j,\ell)=\operatorname{Rep}(\rho_{i,j})[\ell]
\]

其电路规模为 \(n^C\)，其中常数 \(C\) 与 JK 深度和 \((i,j)\) 无关，并且所有 bit 都遵循同一
packed layout。这一“whole-tree labeling”条件才足以支持 choice-robust 的二分：

1. 若首次出现 non-image block，则该 block 的 seed 的每一位都有 \(n^C\)-规模 accessor；
2. 若所有层的 blocks 都在 range，则按区间顺序合并其 seeds，最终得到 root seed，解码电路大小
   为 \(O(|G|h)\)（\(h\) 为树高）；
3. 若起始函数已知复杂度大于该 easy 分支上界，则必然出现一个 locally accessible outsider。

反过来，单独知道每个 block 有一个 center+sparse 表示，只给出逐块存在性，不给出
\(A_n\)，也不保证不同层的 records 可以 tree-compatibly 重选。逐 bit 逆过程若每层发出
固定数量查询，直接 inline 仍可能产生 \(Q^h\) 展开；因此不能把固定-query inverse 当作
exponent-stable normalization。

## 信息率筛选：slot-sparse residual 不能覆盖全部低复杂度表

还可得到一个独立的、只依赖计数的筛选规则。这里要明确组合模型：令总 seed 长度分成
\(q=q_c+q_s\)，并假设 decoder 形如

\[
G(c,u)=\Psi(C(c),D(u)),
\]

其中 \(D(u)\) 是 note 103 的 \(w\)-slot residual，且 \(\Psi\) 不读取未被 \(D\) 输出的
padding/layout bits；若这些 bits 被 \(\Psi\) 读取，就必须把它们计入 center budget \(q_c\)。
在此模型下，中心部分至多产生 \(2^{q_c}\) 个状态，残差使用 note 103 的 \(w\)-slot code，
故总 range 大小至多

\[
2^{q_c}\,V(N,w),
\qquad
V(N,w)=\sum_{r\le w}\binom Nr.
\]

若 \(w(m+1)\le q_s\) 且 \(w\ge1\)，则

\[
V(N,w)<2^{w(m+1)}\le 2^{q_s},
\]

所以总 range 严格小于 \(2^q\)。另一方面，令 \(J_m\) 为只依赖前 \(m-1\) 个变量的所有
\(m\)-变量 truth tables。因为

\[
|J_m|=2^q
\]

且 Lupanov 给出这些函数的电路规模至多
\(O(q/(m-1))\)（固定完备 fan-in-2 基下的常数模拟吸收在 \(O(\cdot)\) 中），任何覆盖
该低复杂度子族的 decoder 都不可能采用上述正预算的 slot-sparse residual。这个结论不是
一般 decoder 的下界：若残差使用最优组合数编码，普适必要条件仅为

\[
q_c+\log_2 V(N,w)\ge q,
\]

而实际 JK block family 是否具有达到该熵规模的独立成员数，仍未证明。

## 路线裁决与证据边界

- 可采纳：note 103 的显式两层非闭合反例；whole-tree labeling 作为充分条件；slot-sparse
  residual 的信息率 no-go。
- 不可采纳：外部报告中没有自足证明的“精确稀疏 Shannon \(\Theta\) 边界”以及由此推出的
  一般 decoder 下界。
- 当前最窄问题变为：能否为实际 JK blocks 构造一个共同的 whole-tree joint accessor，或证明
  任何 such accessor 都会触及已知的 batch-evaluation/MCSP 下界。一般 nonlinear,
  non-systematic near-linear covering decoder 仍是 unknown。

来源：本项目 note 103；Lupanov 上界的固定基版本见 ResearchLibrary 的 Jukna (2012)
Theorem 1.15。本文的递归反例与 whole-tree 条件是项目内自足推导，不宣称外部文献优先权。
