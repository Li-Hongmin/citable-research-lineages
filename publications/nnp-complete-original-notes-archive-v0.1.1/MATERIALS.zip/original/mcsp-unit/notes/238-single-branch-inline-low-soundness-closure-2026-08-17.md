> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Single-branch message-inline closure at low soundness (2026-08-17)

## Contribution

There is a sharper way to compile a binary target-relative shared-proof
interface into an RLDC than running both claim branches.  Put the message bit
itself in the codeword and use it to select the branch:

\[
  C(m):=m\,\|\,\Pi(m).
\]

On an uncorrupted codeword the inline bit is correct, so only the correct
branch is ever queried.  Consequently, **codeword rejection by the wrong
branch is not needed** for perfect completeness.  On a corrupted word, the
only way the decoder can output a wrong bit is that the inline bit was
corrupted and the selected wrong branch accepts.  This gives a perfect-complete
\((r+1)\)-query RLDC even for adaptive branch verifiers.

Combining this compiler with Cheng--Li--Mao's low-soundness theorem yields the
following all-query barrier.

## Theorem (single-branch low-soundness barrier)

Let

\[
  \Pi:\{0,1\}^{k}\longrightarrow\{0,1\}^{P}
\]

be a binary proof map.  For every \(i\in[k]\) and \(b\in\{0,1\}\), let
\(V_{i,b}\) be a randomized, possibly adaptive verifier making at most \(r\)
queries to the proof.  Write \(p_{i,b}(z)\) for its acceptance probability.

Assume a constant \(0<\rho<1\) and:

1. **Perfect correct-branch completeness**
   \[
     p_{i,m_i}(\Pi(m))=1
     \qquad\text{for every }m\in\{0,1\}^{k},\ i\in[k].
   \tag{238.1}
   \]
2. **Target-relative wrong-branch soundness**
   \[
     \operatorname{dist}(z,\Pi(m))\le\rho P
     \Longrightarrow
     p_{i,1-m_i}(z)\le\beta
   \tag{238.2}
   \]
   for every \(m,i,z\).

If

\[
  \beta<2^{-(r+1)},
\tag{238.3}
\]

then, for all sufficiently large \(k\), the inline length
\(N=k+P\) obeys

\[
\begin{cases}
  N=2^{\Omega_\rho(k)}, & r=1,\\[2mm]
  N=\widetilde\Omega_{\rho,\beta,r}
      \!\left(k^{\frac{r+1}{r-1}}\right), & r\ge2.
\end{cases}
\tag{238.4}
\]

The \(r=1\) line uses the binary two-query LDC/RLDC exponential lower bound.
For \(r\ge2\), the exponent is the standard binary \((r+1)\)-query LDC
exponent; odd query counts use the all-odd theorem of
Basu--Hsieh--Kothari--Lin and even query counts use the corresponding classical
bound.

## Proof

### 1. The proof image has constant distance

If \(m\ne m'\) and
\(\operatorname{dist}(\Pi(m),\Pi(m'))\le\rho P\), choose \(i\) with
\(m_i\ne m'_i\).  Applying (238.2) to target \(m\) and
\(z=\Pi(m')\) gives

\[
  p_{i,m'_i}(\Pi(m'))\le\beta,
\]

while (238.1) for \(m'\) gives the same quantity equal to \(1\), a
contradiction.  Thus the proof words are distinct and have relative distance
greater than \(\rho\).

The binary Singleton bound therefore implies, for sufficiently large \(k\),

\[
  \frac{P}{N}\ge\frac1{3-2\rho},
  \qquad N:=k+P.
\tag{238.5}
\]

Set

\[
  \delta_0:=\frac{\rho}{2(3-2\rho)}.
\tag{238.6}
\]

If \(y\) is within relative distance \(\delta_0\) of
\(C(m)=m\|\Pi(m)\), then its proof suffix \(z\) is within
\(\rho P/2\) of \(\Pi(m)\), hence within the neighborhood in (238.2).

### 2. One-branch inline decoder

Define a relaxed decoder for \(C\) as follows.  On input \((y,i)\), read the
inline bit

\[
  b:=y_i.
\]

Run \(V_{i,b}\) on the proof suffix \(z\).  If it accepts, output \(b\); if it
rejects, output \(\bot\).  The decoder makes at most \(r+1\) queries and is
adaptive exactly when \(V_{i,b}\) is adaptive.

On the uncorrupted codeword, \(b=m_i\), so (238.1) gives output \(m_i\) with
probability one.  This is perfect relaxed completeness, with no assumption on
\(p_{i,1-m_i}(\Pi(m))\).

Now let \(y\) be \(\delta_0\)-close to \(C(m)\).  If \(b=m_i\), the decoder
outputs either the correct bit or \(\bot\), never a wrong bit.  If \(b\ne m_i\),
the selected branch is the wrong branch, and a wrong output occurs only when it
accepts.  By (238.2), that probability is at most \(\beta\).  Hence \(C\) is a
perfect-complete binary

\[
  (r+1,\delta_0,1,\beta)\text{-RLDC}.
\tag{238.7}
\]

This is the key point: the bottom case is absorbed by the RLDC failure symbol,
while codeword-level wrong-branch acceptance is irrelevant because the inline
bit selects the correct branch on honest inputs.

### 3. Low soundness upgrades RLDC to LDC

Let \(Q=r+1\).  Cheng--Li--Mao's perfect-completeness theorem for possibly
adaptive binary RLDCs states that if \(s<2^{-Q}\), then the same code is a
nonadaptive \(Q\)-query LDC at any radius

\[
  0<\delta'<\frac{\delta_0}{2Q}(1-s2^Q),
\]

with decoding error at most

\[
  \frac{s2^Q}{2}+\frac{\delta'Q}{\delta_0}.
\tag{238.8}
\]

Taking \(s=\beta\) and, for example,

\[
  \delta'=\frac{\delta_0}{4Q}(1-\beta2^Q)
\]

makes the error in (238.8) equal to

\[
  \frac14+\frac{\beta2^Q}{4}<\frac12.
\]

Thus \(C\) is a constant-radius, constant-error binary \(Q\)-query LDC.  If
\(r\ge2\), then \(Q\ge3\), and the standard binary \(Q\)-query LDC lower bound
\[
  k\le\widetilde O\!\left(N^{1-2/Q}\right)
\]
gives the second line of (238.4).  If \(r=1\), \(Q=2\), and the binary
two-query lower bound gives \(N=2^{\Omega(k)}\).  \(\square\)

## Why this strengthens the existing low-soundness route

The earlier two-branch compiler in note 199 queried both \(V_{i,0}\) and
\(V_{i,1}\), resulting in \(2r\) proof queries (plus the inline bit) and
requiring a completeness accounting for the wrong branch on the codeword.  The
single-branch compiler above:

* uses \(r+1\), not \(2r+1\), queries;
* works for adaptive \(V_{i,b}\) because Cheng--Li--Mao's perfect-complete
  theorem allows adaptive relaxed decoders;
* requires no codeword-level rejection or soundness statement for the wrong
  branch;
* does not require a no-bottom/two-branch-mass condition.

It therefore closes a previously unisolated low-soundness adaptive escape, while
leaving the constant-\(\beta\) bottom regime untouched.

## Scope

The theorem still requires a family-level common proof map, binary inline
symbols, perfect correct-branch completeness, positive target-relative radius,
and exponentially small wrong-branch soundness.  It does not prove a constant
soundness impossibility, does not apply to arbitrary list/distributional
soundness, and does not supply the missing RW address-scale reconstruction.
Its role in the Closure Theorem program is precise: any binary candidate that
keeps bottom and avoids the LDC barrier must have wrong-branch soundness at least
\(2^{-(r+1)}\), or must leave the common-proof/message-inline model.

## Sources

* K. Cheng, X. Li, and S. Mao, *When Relaxation Doesn't Help: RLDCs with
  Small Soundness Yield LDCs*, arXiv:2603.03717, Theorems 1.4/3.1:
  <https://arxiv.org/abs/2603.03717>.
* A. Basu, J.-T. Hsieh, P. K. Kothari, and A. D. Lin,
  *Improved Lower Bounds for all Odd-Query Locally Decodable Codes*:
  <https://arxiv.org/abs/2411.14361>.
* A. R. Block et al., *Exponential Lower Bounds for 2-query Relaxed Locally
  Decodable Codes*:
  <https://arxiv.org/abs/2602.20278>.
* Related two-branch low-soundness compiler:
  [note 199](199-low-soundness-acrr-upgrade-to-ldc-2026-08-16.md).
