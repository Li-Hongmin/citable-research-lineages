> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mutual-information mixture closure from average robust defect to RLDC

**Status.** This note removes the policy-level supportwise hypothesis of note
272 at a semantic level.  The price is that the policy defect must be averaged
after taking the worst coordinate and worst target-relative proof.  Mutual
information then lets us replace target-dependent policy distributions by one
target-independent marginal mixture on a large message subfamily.

## 1. Setup

Let \(M\) be uniform on \(\{0,1\}^k\), let
\(\Pi:\{0,1\}^k\to\Sigma^N\) be one common proof map, and let \(S\mid M=m\)
have law \(\mu_m\) on a standard-Borel policy space.  Write
\[
\operatorname{Comp}_{m,i,s}
\]
for correct-claim acceptance at coordinate \(i\) on \(\Pi(m)\), and
\[
\operatorname{WrongAcc}_{m,i,s}(z)
\]
for wrong-claim acceptance on a proof \(z\) with
\(d(z,\Pi(m))\le\rho N\).  Fix \(\alpha>\beta\), and define the robust defect
\[
\mathcal D(m,s):=
\max\!\left\{
\max_i(\alpha-\operatorname{Comp}_{m,i,s})_+,\,
\max_{\substack{i,z:\\d(z,\Pi(m))\le\rho N}}
(\operatorname{WrongAcc}_{m,i,s}(z)-\beta)_+
\right\}\in[0,1].
\tag{273.1}
\]
Let
\[
\bar\delta:=\mathbb E_{M}\mathbb E_{S\sim\mu_M}\mathcal D(M,S),
\qquad
I:=I(M;S),
\tag{273.2}
\]
where \(I\) is measured in bits.  Let
\(\bar\mu:=\mathcal L(S)=\mathbb E_M\mu_M\) be the target-independent marginal
policy law.

## 2. Mixture closure theorem

For \(0<\Delta<(\alpha-\beta)/2\), put
\[
\tau:=\bar\delta+\sqrt{\frac{\ln 2}{2}\,I}.
\tag{273.3}
\]
If \(\tau<\Delta\), then there is a target subfamily
\[
\mathcal M_\Delta\subseteq\{0,1\}^k,
\qquad
|\mathcal M_\Delta|
\ge\left(1-\frac{\tau}{\Delta}\right)2^k,
\tag{273.4}
\]
such that, for every \(m\in\mathcal M_\Delta\), the **single target-independent
mixture** \(S\sim\bar\mu\) has
\[
\mathbb E_{\bar\mu}\operatorname{Comp}_{m,i,S}\ge\alpha-\Delta,
\qquad
\mathbb E_{\bar\mu}\operatorname{WrongAcc}_{m,i,S}(z)\le\beta+\Delta
\tag{273.5}
\]
for every coordinate \(i\) and every \(z\) in the target-relative
\(\rho N\)-ball.  Thus the mixture has gap
\[
g_\Delta:=\alpha-\beta-2\Delta>0.
\tag{273.6}
\]

### Proof

For each target define
\[
\bar D_m:=\mathbb E_{S\sim\bar\mu}\mathcal D(m,S).
\]
For any \([0,1]\)-valued function \(f\), the difference of its expectations
under two laws is at most their total variation distance.  Hence
\[
\begin{aligned}
\mathbb E_M\bar D_M
&\le \bar\delta+\mathbb E_M
\operatorname{TV}(\mu_M,\bar\mu)\\
&\le \bar\delta+
\sqrt{\frac{\ln2}{2}\,
\mathbb E_M D_{\mathrm{KL}}(\mu_M\Vert\bar\mu)}\\
&=\tau,
\end{aligned}
\tag{273.7}
\]
where the second line is Pinsker and Jensen, and the last equality is the
mutual-information identity in bits.

Markov's inequality gives
\[
\Pr_M[\bar D_M>\Delta]\le\frac{\tau}{\Delta}.
\tag{273.8}
\]
For \(m\) outside this exceptional set, the definition of \(\mathcal D\) gives
\[
\operatorname{Comp}_{m,i,s}
\ge\alpha-\mathcal D(m,s),
\qquad
\operatorname{WrongAcc}_{m,i,s}(z)
\le\beta+\mathcal D(m,s).
\]
Taking expectation under \(\bar\mu\) proves (273.5), and (273.4) follows from
(273.8). \(\square\)

## 3. Coding consequence

The mixture \(S\sim\bar\mu\) is independent of the target.  Inline the queried
message bit before the common proof and use the two claim branches with an
independent draw from \(\bar\mu\).  If the branch gap is amplified to constant
success, the resulting decoder has
\[
Q=O\!\left(q\,g_\Delta^{-2}\right)
\tag{273.9}
\]
proof queries, up to the usual finite-query amplification factor.  The
construction is valid on the restricted message family \(\mathcal M_\Delta\).
If \(d\) is its VC dimension, Sauer--Shelah gives
\[
\sum_{j\le d}\binom{k}{j}\ge|\mathcal M_\Delta|.
\tag{273.10}
\]
In particular, whenever \(\tau/\Delta\le1/2\),
\[
d\ge(1/2-o(1))k.
\tag{273.11}
\]
Thus any applicable GGS lower bound rules out near-linear proof length for the
mixture-closed subcode with fixed alphabet, radius, and \(g_\Delta\).

The reduction is information-theoretic unless the marginal policy law
\(\bar\mu\) has a uniform sampler or an equivalent address-scale description.
Under that additional algorithmic condition, (273.9) is an ordinary RLDC
decoder; without it, (273.7)--(273.11) remain a semantic mixture closure and
still rule out any claim that low mutual information alone is a free escape.

There is a simple sufficient uniformity condition.  Suppose a public sampler
\(\operatorname{Sam}(m;r)\) returns an executable policy view with law
\(\mu_m\), in time polynomial in the address-scale parameters, uniformly for
all \(m\).  A target-independent sampler for \(\bar\mu\) first chooses an
independent dummy \(U\leftarrow\{0,1\}^k\), then returns
\(\operatorname{Sam}(U;r)\).  Its law is exactly
\[
\mathcal L(\operatorname{Sam}(U;r))=\mathbb E_U\mu_U=\bar\mu.
\tag{273.12}
\]
The dummy message is internal randomness and is never compared with the
message encoded by the proof.  Thus uniform executable policy selection is
enough to turn the semantic mixture closure into the algorithmic RLDC in
(273.9); no separate compression of the marginal distribution is required.

## 4. Why this is stronger than supportwise selection

Note 272 requires \(\Pr_{S\sim\mu_m}[\mathsf{Rob}(m,S)]\ge1-\varepsilon\)
for each target.  The present theorem only assumes the average scalar defect
\(\bar\delta\) in (273.2); individual policies may each fail on some targets,
and no policy in the support of \(\mu_m\) needs to be robust.  The target
dependence is paid through
\[
\mathbb E_M\operatorname{TV}(\mu_M,\bar\mu)
\le\sqrt{(\ln2/2)I}.
\]
This is precisely the missing average-to-common mechanism.

The order of operations is essential.  Averaging each coordinate or each proof
separately does not control the max in (273.1), so it cannot imply (273.5).
That is the same phantom-witness boundary identified in notes 269 and 272.
The theorem therefore closes a broad distributional route only when its
soundness estimate controls a single robust defect functional.

## 5. Boundary and interpretation

If \(I=o(1)\) and \(\bar\delta=o(1)\), one may take a constant \(\Delta\) below
\((\alpha-\beta)/2\), obtaining a subfamily of density \(1-o(1)\) and a
linear-VC RLDC.  If \(I\) is merely \(o(k)\), the square-root term in (273.3)
can be too large; low Shannon information alone does not imply mixture closure
at a constant gap.  This square-root dependence is the exact Pinsker loss of
replacing target-dependent laws by the marginal law.

The remaining top-level positive target is therefore sharply stated: construct
a common-address dPCP whose *worst-case robust defect* has small average under
the target-selected strategy channel, and whose marginal strategy law is
uniformly samplable at address scale.  Such a construction would immediately enter the RLDC
barrier through (273.4)--(273.11).  Ordinary list soundness without a global
defect bound still lies outside this theorem.
