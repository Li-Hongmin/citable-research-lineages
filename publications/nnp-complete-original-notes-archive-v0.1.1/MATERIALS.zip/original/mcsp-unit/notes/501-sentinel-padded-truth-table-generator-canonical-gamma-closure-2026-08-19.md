> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Sentinel-padded truth-table generator with canonical \(\Gamma\)-closure (2026-08-19)

## 本轮改变的判断

C500 说明不能从“truth-table generator”这几个字直接读出 \(\Gamma_d\) 的下界。
但 Ren--Williams Theorem 4.3 的假设比其 Section 4.2 的一个具体 encoding 更宽：
它对任意 P-uniform 的
\[
G_n:\{0,1\}^{n}\longrightarrow\{0,1\}^{2n},
\qquad |G_n|\le n^4,
\]
都给出 infinitely-often smart range avoidance。由此可以主动选择一个
**sentinel-padded universal generator**：把字典序最大的 seed block 留给 universal
circuit descriptions，其余 seed 直接映射到 \(u\Vert u\)。这样同时得到：

* 每个低复杂度 truth table 都在 range 中，所以任何 outsider 都是 hard；
* 对 lexicographic canonical selector，几乎所有 seed 都在每一层 \(\Gamma_d\) 中；
* C497/C499 的 prefix-fiber payment 因而在每个深度都有近 \(n\)-bit 的单块熵。

这把 C500 的 encoding gate 变成一个可主动选择的正向接口。它仍不是 published
Section 4.2 的原始 generator，也还没有把 singleton RW proof 与该 \(\Gamma\)-family
绑定起来。

## 定义

令 \(n=2^k\)，并取
\[
r_n:=2\left\lceil\log_2(n+2)\right\rceil<n
\]
（只考虑充分大的 \(n\)）。固定一个标准 gate-list encoding，满足：

1. 一个 \(t\)-gate、\(k+1\)-input circuit 的 description 长度至多
   \[
   c_{\mathrm{enc}}(t+k+2)\log_2(t+k+2);
   \tag{501.1}
   \]
2. 从一个 \(n-r_n\)-bit string 解码出 circuit 并计算其 \(2n\)-bit truth table 的
   universal evaluator \(U_n\) 可由 size \(O(n^4)\) 的 P-uniform circuit 实现；
3. invalid descriptions 映射到 \(0^{2n}\)。

这些是普通 gate-list encoding 的直接有限化：单个 gate 的两个输入索引使用
\(O(\log(t+k+2))\) bits，逐地址模拟后复制到 \(2n\) 个 truth-table positions；
\(O(n^4)\) 的宽松上界足以吸收 validity checks 和 multiplexers。

定义
\[
\mathcal U_n:=\{1^{r_n}v:v\in\{0,1\}^{n-r_n}\},
\qquad
\mathcal S_n:=\{0,1\}^{n}\setminus\mathcal U_n.
\tag{501.2}
\]

定义 \(G_n^\star:\{0,1\}^{n}\to\{0,1\}^{2n}\)：
\[
G_n^\star(u):=
\begin{cases}
u\Vert u,&u\in\mathcal S_n,\\
U_n(v),&u=1^{r_n}v\in\mathcal U_n.
\end{cases}
\tag{501.3}
\]

所有 \(\mathcal U_n\) 中的 strings 都大于所有 \(\mathcal S_n\) 中的 strings；
这正是 sentinel branch 的作用。

## 定理 501.1（hard-output-preserving canonical \(\Gamma\)-closure）

对充分大的 \(n=2^k\)，\(G_n^\star\) 具有以下性质。

### (a) Universal range / outsider hardness

若 \(z\in\{0,1\}^{2n}\) 的 truth-table circuit complexity 满足
\[
\operatorname{CC}(z)\le t_n:=\left\lfloor\eta\frac{n}{k}\right\rfloor,
\tag{501.4}
\]
其中 \(\eta>0\) 只依赖于 \(c_{\mathrm{enc}}\) 且足够小，则
\[
z\in\operatorname{Range}(G_n^\star).
\tag{501.5}
\]
因此每一个 outsider \(z\notin\operatorname{Range}(G_n^\star)\) 满足
\[
\operatorname{CC}(z)>\Omega\!\left(\frac{n}{\log n}\right)
 =\Omega\!\left(\frac{|z|}{\log |z|}\right).
\tag{501.6}
\]

### (b) All-depth canonical seed lower bound

Let \(p_n\) be the lexicographically smallest right inverse on
\(\operatorname{Range}(G_n^\star)\), and define \(\Gamma_d^\star\) as in C497. Then
\[
\mathcal S_n\subseteq\Gamma_d^\star
\quad\text{for every }d\ge0,
\tag{501.7}
\]
and hence
\[
s_d^\star:=|\Gamma_d^\star|
\ge|\mathcal S_n|
=2^n-2^{n-r_n}
=\bigl(1-2^{-r_n}\bigr)2^n.
\tag{501.8}
\]

### (c) Every depth has a liftable outsider

Using C498/C499,
\[
|\mathcal O_d^\star|
=(s_d^\star)^2-s_{d+1}^\star
\ge(2^n-2^{n-r_n})^2-2^n>0
\tag{501.9}
\]
for all \(d\ge0\) and sufficiently large \(n\). Thus for every
\(2\le i\le k\), the C497 construction can place a liftable outsider at stage \(i\).

### (d) Uniform prefix-fiber payment

For \(d=k-i\), C497 and C499 give an exact descriptor lower bound
\[
\Delta_{k,i}
\ge
\bigl(2^{i-1}-1\bigr)
\log_2\!\left(2^n-2^{n-r_n}\right)
\ge
\bigl(2^{i-1}-1\bigr)(n-1).
\tag{501.10}
\]

At the top stage this is \(\Omega(T)\) bits when the parent length is
\(T=n2^k\); at every nontrivial stage it is at least one full \(n\)-bit block up to
the \(2^{i-1}-1\) multiplicity.

## 证明

For (a), let \(C\) be a circuit for \(z\) of size at most \(t_n\). By (501.1), for
sufficiently small fixed \(\eta\),
\[
c_{\mathrm{enc}}(t_n+k+2)\log_2(t_n+k+2)
\le n-r_n.
\tag{501.11}
\]
Thus \(C\) has an \((n-r_n)\)-bit padded description \(v\), and
\(G_n^\star(1^{r_n}v)=U_n(v)=z\). This proves (501.5) and (501.6).

For (b), take \(u\in\mathcal S_n\). The structured branch gives
\[
G_n^\star(u)=u\Vert u.
\]
Any other structured preimage of this output must equal \(u\); every universal-branch
preimage begins with \(1^{r_n}\) and is lexicographically larger than \(u\). Therefore
\[
p_n(G_n^\star(u))=u,
\]
so \(u\in\Gamma_0^\star\). If \(u\in\Gamma_d^\star\), both halves of
\(G_n^\star(u)=u\Vert u\) are again \(u\in\Gamma_d^\star\), proving
\(u\in\Gamma_{d+1}^\star\) by induction. This establishes (501.7)--(501.8).

For (c), C498 and C499 give
\[
|\mathcal O_d^\star|=(s_d^\star)^2-s_{d+1}^\star.
\]
Since \(s_d^\star\ge2^{n-1}\) and \(s_{d+1}^\star\le2^n\), the right-hand side is
positive for \(n\ge3\). Formula (501.10) is then C497's payment with
\(M_d=s_{d+1}^\star\), using C499's equality \(M_d=|\Gamma_{d+1}^\star|\).

Finally, applying Ren--Williams Theorem 4.3 to the P-uniform family
\(\{G_n^\star\}\) yields a smart-\(\mathrm{FP}^{\mathrm{prMA}}/1\) algorithm and an
infinite set of lengths on which its output \(B_n\) lies outside
\(\operatorname{Range}(G_n^\star)\). Part (a) upgrades that output immediately to
the forcing lower bound (501.6).

## Closure への直接影响

1. **Encoding ambiguity is no longer a logical obstruction to a chosen RW family.** We
   can fix \(G_n^\star\) explicitly before invoking Theorem 4.3, rather than infer
   \(\Gamma\) from an underspecified published encoding.
2. **The canonical-lift phase is maximally nondegenerate.** No depth can be dismissed as
   “there are too few canonical seeds”: \(s_d^\star\ge(1-o(1))2^n\), and every depth has
   an outsider.
3. **What remains is the singleton attachment.** Theorem 501.1 is a family/range theorem.
   It does not prove that the one canonical RW PCP proof used at a good length contains
   the structured \(\mathcal S_n\)-blocks, nor that its actual descriptor must range over
   the whole \(\Gamma^\star\)-family. A target-specific Closure still needs same-proof,
   whole-word and address-scale binding.
4. The strongest immediate conditional consequence is therefore precise:
   any proposed RW/JK closure that is uniform over the \(G_n^\star\) parent family and
   uses C497's exact descriptor model must pay (501.10), which is object-scale at the
   top stage. A singleton closure that avoids this payment must identify a genuinely
   target-specific/global relation rather than invoke canonical lift alone.

This note is not a proof of \(P\ne NP\), not a claim that the original published
truth-table encoding equals \(G_n^\star\), and not a universal dPCP/LDC impossibility
theorem. It is a constructive RW-specific generator theorem that removes the encoding
uncertainty while preserving the near-maximum forcing scale.

## 来源

* Ren--Williams, ECCC TR26-118 revision 1, Theorem 4.3 and Section 4.2; local extraction:
  'units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md'.
* Oliver Korten, *The Hardest Explicit Construction*, FOCS 2021 / arXiv:2106.00875,
  Theorem 7 and the \(C^\star\) recursive range construction; local record:
  'ResearchLibrary/lib/korten2021hardest/korten2021hardest.pdf'.
* [C497](497-jk-canonical-liftable-range-projection-barrier-2026-08-19.md).
* [C498](498-jk-canonical-lift-phase-diagram-2026-08-19.md).
* [C499](499-jk-canonical-lift-injectivity-eliminates-collision-branch-2026-08-19.md).
