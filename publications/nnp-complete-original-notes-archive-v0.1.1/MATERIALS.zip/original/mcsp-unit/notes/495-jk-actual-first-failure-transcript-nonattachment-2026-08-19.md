> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK actual first-failure transcript 的前缀非附着（2026-08-19）

## 本轮改变的判断

C488 给出了 actual JK 首失败层的完整 frontier-support 上界，C494 则说明
fixed-proof 的 prefix-local frontier 不能被 suffix failure 掩护；但二者都没有把
**published Theorem 3.1 实际返回的首个 outsider** 与目标 prefix 绑定起来。本 note
给出一个严格的 actual-recursion 量词分离：即使 generator、stage、failure index 和
returned outsider 全部固定，失败块之前的一个 range block 仍可携带任意 \(n\) bits 的
目标前缀。因而首失败输出本身没有 parent-binding；若把该成功 preimage/path 作为
额外 transcript 返回，则它必须至少携带这 \(n\) bits，进入 descriptor/payment 分支。

这不是对 Ren--Williams canonical PCP image 的反例；它证明的是：该 image 的额外
结构必须另行给出，不能从 JK 首失败语义自动推出。

## 定理 495.1（actual first-failure transcript non-attachment）

对每个 \(n\ge 1\)，令

\[
G_n:\{0,1\}^{n}\to\{0,1\}^{2n},
\qquad G_n(u)=u\Vert u,
\tag{495.1}
\]

并令

\[
y_n:=1^n0^n.
\tag{495.2}
\]

显然 \(y_n\notin\operatorname{Range}(G_n)\)。对每个 \(u\in\{0,1\}^n\)，取

\[
f_u:=(u\Vert u)\Vert y_n\in\{0,1\}^{4n}.
\tag{495.3}
\]

在 Theorem 3.1 的 JK recursion 中，\(T=4n\)，故
\(k=\lceil\log_2(T/n)\rceil=2\)，且初始 \(y_2=f_u\)。stage \(2\) 的两个 \(2n\)-bit
blocks 为

\[
z_1=u\Vert u\in\operatorname{Range}(G_n),
\qquad z_2=y_n\notin\operatorname{Range}(G_n).
\tag{495.4}
\]

因此无论实现采用顺序扫描还是任意“返回一个失败块”的 tie-break，唯一失败块都
是 \(z_2\)，并且 published output transcript

\[
\tau_u=(\mathrm{hard},\;\mathrm{stage}=2,\;\mathrm{block}=2,\;y_n)
\tag{495.5}
\]

对所有 \(u\) 完全相同。可是目标前缀

\[
B_u:=f_u[1,n]=u
\tag{495.6}
\]

遍历全部 \(2^n\) 个值。故不存在只依赖

\[
(G_n,\mathrm{stage},\mathrm{block},y_n)
\tag{495.7}
\]

的单值 map \(D\) 使 \(D(\tau_u)=B_u\) 对所有 \(u\) 成立。

### 证明

由 (495.1)，第一个 block \(u\Vert u\) 有唯一 preimage \(u\)；由 (495.2)，第二个
block 不在 range。于是 stage \(2\) 的 range tests 中恰有第二个 query 失败，算法
返回 (495.5)。该返回值与 \(u\) 无关，而 (495.6) 与 \(u\) 一一对应，故同一 transcript
对应 \(2^n\) 个不同目标前缀，单值恢复不可能。证毕。

## 路径/成功 preimage 的精确 payment

定理 495.1 使用的是 published output 以及 stage/block 的位置数据。若 proposed
closure 额外把失败之前的成功 preimage \(u\)（或任何能区分所有 \(u\) 的 path/descriptor
payload）放进 transcript，设该 side information 为 \(s_u\)，且 decoder 从
\((\tau_u,s_u)\) 精确恢复 \(B_u\)。因为 \(\tau_u\) 固定而 \(B_u\) 有 \(2^n\) 个值，
映射 \(u\mapsto s_u\) 必须是单射；对二进制 descriptor 有

\[
|s_u|\ge n.
\tag{495.8}
\]

若 transcript 还包含完整 \(2n\)-bit successful block 或其 canonical preimage，
(495.8) 正好由该 payload 支付。若它只包含 binary ancestry direction、stage 或 block
index，则这些量在本构造中固定，支付为零，仍不能绑定 \(B_u\)。

更一般地，若失败块前的目标投影在某个 \(G\)-range sibling family 上有 \(M\) 个可取值，
同样的构造给出

\[
H_\infty(B\mid G,\mathrm{stage},\mathrm{block},y)\ge \log_2 M,
\tag{495.9}
\]

所以任何 exact parent-binding descriptor 至少支付 \(\log_2 M\) bits；这是一条
information/descriptor lower bound，而非对单个 fixed parent 的 circuit lower bound。

## 对 RW/JK Closure 的裁决

1. Theorem 3.1/4.1 的 **hard** 返回值、一个 outsider、stage 和位置 path 不自动恢复
   output prefix；C487 的 semantic exit 在 actual recursion 中有了显式、P-uniform 的
   witness。
2. 若把先前所有 successful preimages 作为 path 返回，便进入 C488 的 frontier-support
   或 C417 的 half-lift/payment；不能再称为免费 first-failure attachment。
3. 因此 Gate I 现在有一个严格二分：

   * **published transcript branch：** 495.1 排除仅由 outsider/stage/path-position
     得到的 parent map；
   * **augmented path branch：** 必须证明 Ren--Williams canonical PCP image 强迫一个
     address-scale、同一 proof 的 selector，并把至少 (495.8) 的 payload 计入；若 selector
     不是 JK 输出而是新的 global relation，则属于 genuine model exit。

该结论与 C494 不冲突：C494 使用 fixed proof 上的反事实 prefix-local frontier；C495
说明 actual 首失败返回值并不暴露该 frontier 中的 sibling payload。只有另外证明
actual proof image 的 selector/attachment，才能把 C494 的 forcing payment 转移到
published RW object。

## 证据边界

* 依赖 Ren--Williams Theorem 3.1 的真实 stage/block 语义；构造中没有使用 leftmost
  tie-break，因为失败块唯一。
* \(f_u\) 是 JK 输入 truth-table family，不声称每个 \(f_u\) 都是 Theorem 4.1 的
  canonical PCP proof \(\Pi_x\)。因此本 note 是 source-level model-exit/quantifier
  separation，不是对 published RW canonical image 的不可能性定理。
* (495.8)--(495.9) 只对额外 transcript/descriptor 的信息量作下界；不把该 family
  结论静默转成 C455 published fixed-singleton 的 \(P\ne NP\) 矛盾。

## 来源

* [C487](487-rw-solver-success-parent-binding-support-trichotomy-2026-08-19.md)：
  solver-success 只给 child outsider 的三分。
* [C488](488-jk-first-failure-frontier-support-bound-2026-08-19.md)：actual 首失败
  层的完整 frontier-support 上界。
* [C494](494-jk-prefix-local-frontier-forcing-barrier-2026-08-19.md)：fixed-proof
  prefix-local frontier forcing。
* Ren--Williams TR26-118 rev.1, Theorem 3.1：逐 block range test、首个 non-range
  block 与 **hard** 输出。
