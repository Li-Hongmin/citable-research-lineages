> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 稠密 coAM 性质直接强制 leaf-level outsiders（2026-08-15）

## 构造一个 tailored property

令

\[
G_q:\{0,1\}^{q}\to\{0,1\}^{2q}
\]

是 P-uniform 统一 decoder family，且给定 \(1^q\) 可在
\(\operatorname{poly}(q)\) 时间生成其电路描述，记
\[
R_q=\operatorname{Range}(G_q).
\]

对输入长度 \(N\)，取一个可在 \(\operatorname{poly}(N)\) 时间计算的 schedule
\[
q=q(N),\qquad H=H(N),\qquad 2qH\le N,
\]
并要求数值 \(q(N),H(N)\le N^{O(1)}\)。这里的 decoder family 必须由一个统一的
多项式时间 transducer 从 \(1^q\) 生成 \(G_q\) 的描述，且 \(G_q\) 的逐位求值时间
为 \(\operatorname{poly}(q)\)；不能把非 uniform 的独立 \(G_q\) 直接当作一个
coNP/coAM language 的统一参数。
并把字符串 \(W\in\{0,1\}^{N}\) 的前 \(2qH\) 位分成 \(H\) 个连续的
\(2q\)-bit blocks \(B_0,\ldots,B_{H-1}\)。定义

\[
\Pi_G[N]
=
\{W:\ \forall j<H,\ B_j\notin R_q\}.
\tag{1}
\]

剩余的 \(N-2qH\) 位不受约束。若 \(G_q\) 的电路描述和求值均为
\(\operatorname{poly}(q)\)，则 \(\Pi_G\) 的补集属于 NP：证书只需给出
\((j,u)\)，其中 \(j<H\)、\(u\in\{0,1\}^{q}\)，并验证

\[
G_q(u)=B_j.
\tag{2}
\]

所以
\[
\Pi_G\in\mathrm{coNP}\subseteq\mathrm{coAM}.
\tag{3}
\]

## 密度下界

各 block 的约束彼此独立，故

\[
\frac{|\Pi_G[N]|}{2^N}
=
\left(1-\frac{|R_q|}{2^{2q}}\right)^H
\ge
\left(1-2^{-q}\right)^H.
\tag{4}
\]

若 \(H2^{-q}\le 1/2\)，由 Bernoulli 不等式

\[
\frac{|\Pi_G[N]|}{2^N}
\ge 1-H2^{-q}\ge\frac12>\frac1{32}.
\tag{5}
\]

例如可取
\[
q(N)=2^{\left\lfloor\frac12\log_2(N/2)\right\rfloor},\qquad
H(N)=\left\lfloor\frac{N}{2q(N)}\right\rfloor,
\tag{6}
\]
若 decoder 只在二的幂输入长度上定义，这个 schedule 正好保持该条件；在充分大的
\(N\) 上满足 (5)。小长度可把 \(\Pi_G[N]\) 定义为全集，不影响
稠密性与 coNP 性质。

## CLL 的 leaf-level 结论

Chen--Li--Liang 的 dense-coAM construction（Theorem 1.3）适用于任何满足
\(|\Pi_N|\ge 2^N/32\) 的 coAM 性质。因此对上面的 \(\Pi_G\)，在无限多个长度
\(N\) 上存在 canonical string
\[
W_N\in\Pi_G[N]
\]
以及相应的 single-valued AM protocol（带其定理允许的短 advice）。由式 (1)，
这个 \(W_N\) 的**每一个** \(2q(N)\)-bit leaf block 都满足

\[
B_j\notin\operatorname{Range}(G_{q(N)}).
\tag{7}
\]

这比“整棵 JK expansion 的 root 不在 range”更强：non-range 已被强制在叶层出现，
不需要 whole-tree labeler、subtree-lift 或 parent concatenation closure。

## 这条结果改变了什么、没有改变什么

它把当前路线的 hard branch 从

\[
\text{先构造 hard root，再寻找第一个 non-range parent}
\]

改成

\[
\text{直接用一个稠密 coAM 性质生成全体 leaf outsiders}.
\]

但这仍不是 \(P\ne NP\) 证明，原因有三：

1. CLL 的输出仍是 AM/短 advice 语义；式 (7) 不给一个
   \(\operatorname{poly}(\log q)\)-time deterministic bit accessor。
2. 若 decoder coverage 覆盖所有 size \(\le s(q)\) 的 truth tables，式 (7) 只说明
   这些 leaf blocks 的电路复杂度大于 \(s(q)\)；它不产生低复杂度 outsider。
3. CLL Theorem 1.3 的运行时间按输出长度 \(N\) 是 quasi-polynomial，而不是
   \(\operatorname{poly}(\log q)\)。因此要接回 P-vs-NP，仍需把 AM output/short
   advice 压到目标地址尺度，或证明一个 smart-\(\mathrm{prMA}\) 接口可直接消费
   式 (7) 的 leaf witness。

## 与 subtree-lift 的关系

note 153 需要完整目标串的 fixed-level exact local predicate，才能从 root false
下降到 boundary。这里的 tailored property 不提供该 predicate；它提供的是更强的
**存在性位置结论**：所有 leaf 都是 outsiders。因此两条路线的逻辑分工是：

\[
\begin{array}{c|c}
\text{方法}&\text{得到的结论}\\ \hline
\text{subtree-lift}&\text{有 exact local predicate 时，可搜索一个 outsider}\\
\text{tailored dense coAM}&\text{无 local predicate 时，AM 语义下强制所有 leaf outsider}
\end{array}
\]

若未来能把 CLL 的 single-valued AM output 规范化为 RW 的 smart query，而不把
Merlin strategy 误当 deterministic seed，则式 (7) 可直接替代递归 JK hard branch。

## 来源与边界

- Lijie Chen, Jiatu Li, Jingxun Liang, *Maximum Circuit Lower Bounds for
  Exponential-Time Arthur Merlin*, ECCC TR24-182 revision 2,
  [official report](https://eccc.weizmann.ac.il/report/2024/182/)。
  Theorem 1.3 对任意稠密 coAM 性质给出无限多长度上的 canonical output。
- [note 149](149-am-commitment-is-not-a-deterministic-jk-seed-2026-08-15.md)：
  AM commitment 与 deterministic JK seed 的量词/熵错配。
- [note 153](153-subtree-lift-boundary-search-without-whole-tree-labeler-2026-08-15.md)：
  有 exact local predicate 时的 boundary search。

本文给出的是 tailored-property 的条件性路线改写，不声称已经证明 \(P\ne NP\)。

核验日期：2026-08-15。
