> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Closure Gate normal form for the RW/JK route (2026-08-17)

## Status and purpose

This note turns the current RW/JK endgame into a finite, quantitative interface test.
It is not a new proof of (P\ne NP), and it is not an unconditional impossibility
theorem for every dPCP. Its purpose is sharper: a proposed reconstruction can enter the
main line only if it supplies one of the three normal forms below, or proves a new theorem
that genuinely escapes all three.

The starting point is a fixed canonical object (H_{A,n}\in\{0,1\}^{N_n}) produced from
a correct polynomial-time SAT decider (A), with a forcing lower bound

\[
  \operatorname{CC}(H_{A,n})>S_n,
  \qquad S_n=n^{\omega(1)}
\tag{222.1}
\]

on an infinite set of lengths. The sought contradiction is still

\[
  P=NP\Longrightarrow H_A\in P/\mathrm{poly},
\tag{222.2}
\]

for the same object and the same lengths.

## The normal-form theorem

Consider a proposed shared-proof reconstruction with the following intended semantics:

* all target coordinates use one proof address space;
* the output is supposed to be one fixed word (or one explicitly indexed, separated word
  family), rather than a different proof for every coordinate;
* any cover sheet, canonical key, finite strategy summary, or target descriptor is part of
  the reconstruction state;
* the final simulation is required at address scale: address length, verifier generation,
  and post-(P=NP) evaluation are (n^{O(1)}), not merely polynomial in an exponentially
  larger truth-table width (q_n).

Then every route that could establish (222.2) has the following exhaustive normal form.

### (A) Static-advice normal form

There is one length-(n) descriptor \(\sigma_n\in\{0,1\}^{s_n}\) and one common
random-access evaluator (E_n(a;\sigma_n)) for all (a\in[N_n]). If its fan-in-two
control size is (p_n), it makes at most (p_n) reads from the descriptor, and
\(\log N_n=n^{O(1)}\), then ordinary ROM expansion gives

\[
  \operatorname{CC}(H_{A,n})
  \le O\!\left(p_n^2+p_ns_n+p_n\log N_n\right).
\tag{222.3}
\]

Consequently, (222.1) forces

\[
  p_n^2+p_ns_n+p_n\log N_n=\Omega(S_n).
\tag{222.4}
\]

Thus a polynomial address evaluator with polynomial descriptor is already a
\(P/\mathrm{poly}\) closure, while a non-closing evaluator must pay forcing-scale
information or abandon common word consistency. This is the quantitative content of
C207/C220; cover labels and finite strategy summaries do not form additional escape
channels once they fit into one static \(\sigma_n\).

### (B) Global-word / coding normal form

The route instead exposes a distance-separated family

\[
  \mathcal C_n=\{C_n(m):m\in\{0,1\}^{k_n}\},
  \qquad
  \operatorname{dist}(C_n(m),C_n(m'))\ge\Delta_n.
\tag{222.5}
\]

All messages use the same proof space and a common target-independent local interface.
If a proof is globally explained by one word with error \(\varepsilon_n<\Delta_n/2\),
the indexed-list bridge gives a common word index using

\[
  O\!\left(q_n\,\frac{\log(L_n/\eta)}
  {(\Delta_n-2\varepsilon_n)^2}\right)
\tag{222.6}
\]

queries, where (L_n) is the candidate-family size. If, in addition, complete-decoding
incidence and honest-path smoothness are bounded, the selected proof map is a positive-
radius RLDC (C204/C218), so the applicable RLDC/LDC lower bound becomes the obstruction.

This branch is not triggered by ordinary coordinatewise list soundness or by
\(\forall i\,\exists w_i\) witnesses: those quantifiers allow phantom words. The actual
global-word condition, or an equivalent distributional target-normalization theorem, is
the required premise.

### (C) Structured PCPP normal form

The proposed interface may claim standard far-input PCPP semantics rather than a separate
global-word family. If it has constant alphabets and gap, 3 queries, a partition into
input/proof classes \(X,A,B\), uniform marginals on all three classes, perfect completeness,
and constant soundness for every extension of every input far from SAT, then the structured
PCPP lower bound gives

\[
  |X|+|A|+|B|\ge S_n^2/\operatorname{polylog}S_n.
\tag{222.7}
\]

Hence a near-linear construction must leave at least one of those standard PCPP
interfaces. This is the C208/C221 barrier, sourced to Cheng--Li--Mao Theorem 7.1.
It does not apply merely because a system is called a dPCP, distributional PCP, or
target-normalized verifier; the far-input/all-proof-extension quantifier and the three
uniform marginals must actually be proved.

## What remains after the normal form

The normal form leaves one explicit residual class, not an unbounded list of unnamed
obstacles:

\[
\text{bottom, cover, target descriptor, or address scale}
\quad\text{must either be absorbed into (A)--(C), or pay a new theorem-level cost.}
\tag{222.8}
\]

More concretely:

1. **Bottom:** if both claim branches can be simultaneously low, a positive-radius
   coding reduction is unavailable until the actual RW instance excludes this or a
   same-proof recovery rule handles it.
2. **Cover sheet:** local agreement may live on a nontrivial cover. A short sheet index is
   harmless only when it is part of the common \(\sigma_n\) in (A); otherwise the route has
   not supplied one global word.
3. **Target descriptor:** a descriptor that stores a computation history is not a
   reconstruction. Equation (222.4) measures this cost directly.
4. **Address scale:** a \(\operatorname{poly}(q_n)\) full-table search is not an
   \(n^{O(1)}\) address evaluator when \(q_n= n^{k(n)}\). This is the exact RW boundary,
   not a matter of presentation.

## Consequence for distributional soundness

Distributional soundness is therefore a mechanism candidate, not a fourth normal form.
It advances the route only if it proves a single separated global word (entering (B)), or
the full far-input PCPP quantifier (entering (C)). If it supplies neither, it cannot by
itself close the RW/JK contradiction: average coordinate error and ordinary list soundness
remain compatible with phantom words.

This gives a strict promotion rule for the next theorem attempt:

* a positive result must construct the global-word/indexed interface at RW address scale;
* a negative result must prove an RLDC/LDC, proof-length, support, or communication cost in
  a model broad enough to cover the proposed escape;
* a result that only rejects one decoder, one average-soundness instance, or one parameter
  choice remains a search record.

## Proof status and evidence boundary

The three implications are assembled from already proved modules, not silently strengthened:

* (A) is the finite-ROM expansion and forcing-scale descriptor bound in
  [C207/C220](220-rw-forcing-scale-advice-lower-bound-2026-08-17.md);
* (B) is the global-word-to-indexed-list bridge and the incidence-stable field-lift RLDC
  theorem in [C151](../../../rw-jk-succinct-reconstruction/statements/global-distribution-to-indexed-list-bridge.md)
  and [C204/C218](218-incidence-stable-field-lift-dpcp-forces-rldc-2026-08-17.md);
* (C) is the structured uniform-marginal PCPP barrier in
  [C208/C221](221-structured-uniform-marginal-pcpp-quadratic-barrier-2026-08-17.md),
  using Cheng--Li--Mao, Theorem 7.1
  ([arXiv:2603.03717](https://arxiv.org/abs/2603.03717)).

The note therefore records a closure normal form and a decision rule. It does **not** claim
that the actual RW canonical history currently satisfies (A), (B), or (C), and it does not
claim (P\ne NP) has been proved.
