> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# BMVY/DDL cover degree versus the target soundness window (2026-08-20)

## Decision

The finite-cover obstruction from note 202 is mathematically real, but its
agreement mass is much smaller than an inverse-polynomial soundness window in
the natural BMVY/DDL parameter regime. This is therefore a sharp
**base-sheet binding cost theorem**, not by itself an inverse-polynomial
agreement counterexample for GMWZ/BMVY.

## Source assumptions

Use the finite consecutive quotients from note 202. Let \(K\) be the test-face
dimension, \(d\ge 3K\) the symplectic-building dimension, and
\(\ell_0\ge2\) the fixed pro-\(\ell_0\) parameter in the BMVY filtration. Write

\[
  L_i=[\Gamma_i:\Gamma_{i+1}].
\]

The source-family parameter statement used here is that there are absolute
constants \(c_-,c_+>0\) such that, for the chosen consecutive layers,

\[
  \ell_0^{c_-d^2}\le L_i\le \ell_0^{c_+d^2}.
\tag{267.1}
\]

This is the quantified form of the source calculation (BMVY Appendix E.3 and the
filtration discussion in the proof of Theorem 2.13), not an independent counting
assumption. The same appendix computes
\([H(0):H(i)]=\ell_0^{(i/2)O(d^2)}\), while the main construction states explicitly that
\([H(i):H(i+1)]=\ell_0^{\Theta(d^2)}\) for every \(i\ge1\); the associated lattice
quotients preserve this finite index, giving (267.1). This replaces the previous
source-agnostic wording. If a later source version changes the filtration, (267.1)
must be rechecked rather than silently reused.

## Theorem (cover-degree/soundness-window alignment)

Under (267.1) and \(d=\Theta(K)\),

\[
  \log_2 L_i=\Theta(K^2\log_2\ell_0),
  \qquad
  L_i^{-1}=\exp\bigl(-\Theta(K^2\log\ell_0)\bigr).
\tag{267.2}
\]

Consequently:

1. The agreement lower bound supplied by Dikstein--Dinur's finite-cover lemma is
   \(1/L_i=\exp[-\Theta(K^2\log\ell_0)]\). For every fixed \(a>0\),
   \(L_i^{-1}<K^{-a}\) for all sufficiently large \(K\). More generally, this
   cover witness does not reach any target window \(\varepsilon_K\) satisfying
   \(\log(1/\varepsilon_K)=o(K^2\log\ell_0)\).

2. If a target-independent common-address sheet selector reads \(q\) symbols
   from an alphabet \(\Sigma\), has completeness \(\alpha>0\), and may use a
   static sheet descriptor of \(d_{\rm desc}\) bits, then

\[
      d_{\rm desc}+q\log_2|\Sigma|
      \ge \log_2 L_i-\log_2(1/\alpha)
      =\Theta(K^2\log_2\ell_0).
\tag{267.3}
\]

   This is the adaptive transcript bound from note 215 with the source
   parameters substituted.

3. In particular, a common proof of length
   \(N=K\,\operatorname{polylog}K\) together with a descriptor of the same
   near-linear scale cannot bind all \(L_i\) sheets over a fixed finite
   alphabet: \(q\le N\) and \(d_{\rm desc}=K\operatorname{polylog}K\) make the
   left side of (267.3) \(K\operatorname{polylog}K\), whereas the right side is
   \(\Theta(K^2\log\ell_0)\).

## Proof

Taking logarithms in (267.1) and using \(d=\Theta(K)\) gives the first part of
(267.2). The second follows from \(L_i^{-1}=2^{-\log_2L_i}\). Since
\(K^2\log\ell_0\gg\log K\) for fixed \(\ell_0\ge2\), the inverse-polynomial
comparison in item 1 follows.

For item 2, fix the decoder's random tape and descriptor. Its adaptive query
transcript is a padded word in \(\Sigma^q\), and one terminal transcript has only
one output sheet. Hence at most \(|\Sigma|^q\) sheets are correctly identified
for each fixed descriptor and random tape. Summing over at most
\(2^{d_{\rm desc}}\) descriptors and averaging over random tapes gives

\[
  \alpha L_i\le 2^{d_{\rm desc}}|\Sigma|^q,
\]

which is (267.3). For the near-linear comparison, repeated physical queries may be
cached, so we may take \(q\) to count distinct proof positions and hence \(q\le N\).
If \(q\) denotes raw query occurrences instead, the case \(q>N\) already pays more than
the proof length in the transcript term \(q\log_2|\Sigma|\), so it is an even stronger
escape rather than a loophole in the comparison.

## What this does and does not prove

The theorem is source-specific. It proves a quadratic-in-\(K\) sheet-entropy
cost for a base-word postprocessor, and it shows that the DD agreement witness is
too weak to hit an inverse-polynomial target window. It does **not** prove that
all near-linear dPCPs are impossible: a successful construction could use a
cover-free source, accept a lift-word, provide a target-normalized outer check,
or work in an exponentially small soundness regime. Nor does it identify the
exact GMWZ acceptance window; that source-specific comparison remains a separate
input check.

## Sources

* Dikstein--Dinur, *Agreement Theorems for High Dimensional Expanders in the Low
  Acceptance Regime: The Role of Covers*, arXiv:2308.09582,
  <https://arxiv.org/html/2308.09582>.
* Bafna--Minzer--Vyas, *Quasi-Linear Size PCPs with Small Soundness from HDX*,
  arXiv:2407.12762, Appendix E.3 and the filtration discussion in the proof of
  Theorem 2.13, <https://arxiv.org/html/2407.12762>.
* Dikstein--Dinur--Lubotzky, *Low Acceptance Agreement Tests via Bounded-Degree
  Symplectic HDXs*, arXiv:2402.01078,
  <https://arxiv.org/html/2402.01078>.
* Existing source-specific cover closure: [note 202](202-bmvy-ddl-parameter-closure-for-cover-obstruction-2026-08-16.md)
  and [note 215](215-bmvy-cover-sheet-closure-trilemma-2026-08-17.md).
