> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 三 cell 的 \(L\)-形交叉：联合 thinning 闭合（2026-08-13）

## 命题

取三个不同 cell

\[
a=(x_0,y_0),\qquad c=(x_0,y_1),\qquad u=(x_1,y_1),
\]

其中 \(x_0\ne x_1\)、\(y_0\ne y_1\)，且 \(X\cap Y=\varnothing\)。
令 \(E_L\) 为随机 affine 叶加独立 \(1/2\) 行、列 thinning 后，
至少两个 cell \(a,c,u\) 被完整保留的事件。则

\[
\boxed{\Pr(E_L)\le \frac7{256}<\frac1{16}.}
\tag{1}
\]

因而，若一个两两相交 witness 族的每个命中 witness 都包含
\(\{a,c\}\)、\(\{c,u\}\) 或 \(\{a,u\}\) 中至少一对，整个族的命中概率也满足
(1)。

## 参数分层

记三个 cell 的 affine 叶指标为 \(A,C,U\)。只需考察四个 affine 线性形式

\[
q_0=(x_0,1),\quad q_1=(x_1,1),\quad
p_0=(y_0,1),\quad p_1=(y_1,1),
\]

其中 \(A\) 要求 \(q_0z=0,p_0z=1\)，
\(C\) 要求 \(q_0z=0,p_1z=1\)，
\(U\) 要求 \(q_1z=0,p_1z=1\)。

由于 \(X\cap Y=\varnothing\) 且 \(x_0\ne x_1,y_0\ne y_1\)，

\[
\operatorname{rank}(q_0,p_0,p_1)
=\operatorname{rank}(q_1,p_0,p_1)=3.
\tag{2}
\]

四个形式的秩只有两种可能：

1. 秩为 \(4\)；
2. 秩为 \(3\)，此时唯一非平凡关系是
   \[
   q_0+q_1+p_0+p_1=0.
   \tag{3}
   \]

关系 (3) 的右端常数也相容，因为
\(0+0+1+1=0\)。

## 行列 thinning 计算

条件于 affine 叶中的可用模式：

- 仅 \(a,c\) 可用时，二者共享一行，保留概率 \(1/8\)；
- 仅 \(c,u\) 可用时，二者共享一列，保留概率 \(1/8\)；
- 仅 \(a,u\) 可用时，行、列均不同，保留概率 \(1/16\)；
- 三者均可用时，至少保留两者的概率为 \(3/16\)。

由 (2)，每个相邻 pair 的 affine 质量为 \(1/8\)。

若四形式秩为 \(4\)，每个取值模式等概率 \(1/16\)，故

\[
\begin{aligned}
\Pr(E_L)
&=\frac18\Pr(A C\bar U)
 +\frac18\Pr(\bar A C U)
 +\frac1{16}\Pr(A\bar C U)
 +\frac3{16}\Pr(A C U)\\
&=\frac18\left(\frac18-\frac1{16}\right)
 +\frac18\left(\frac18-\frac1{16}\right)
 +\frac1{16}\left(\frac1{16}-\frac1{16}\right)
 +\frac3{16}\cdot\frac1{16}\\
&=\frac7{256}.
\end{aligned}
\tag{4}
\]

若秩为 \(3\)，关系 (3) 强制：任意两个上述 cell 同时落叶即三者
同时落叶。因此只有最后一种模式贡献，且

\[
\Pr(E_L)=\frac3{16}\cdot\frac18=\frac3{128}.
\tag{5}
\]

取两种情形最大值即得 (1)。

## 对 pair-star 残余的作用

若唯一 pair \(P=\{a,u\}\) 与一个 row-star、一个 column-star 的交叉
分别产生 \(c=(x_a,y_u)\)，则

\[
\text{pair witness }P,\quad
\text{row-star}\supseteq\{a,c\},\quad
\text{column-star}\supseteq\{u,c\}
\]

的全部命中事件包含于 \(E_L\)，故该三 star 形态已经闭合。
这正是 star-forest 分解中的“混合中心”分支。

本引理不处理多组件 star forest 中交点不形成单一 \(L\)-形的情形；
后者仍是 note 042 所述的 residual cross-intersection 缺口。
