> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Selector lift and the multiblock equality boundary (2026-08-24)

> **Correction (2026-08-25).** Proposition 43's leading-constant uncertainty is resolved by
> [note 533](533-sharp-semantic-entropy-and-canonical-obdd-width-2026-08-25.md): a tree--pin
> circuit encoding and packed-selector family prove
> \(a_m(S)=(1+o(1))S\log_2S\) in the relevant variable range, and consequently give the tight
> lexicographic-order width bound
> \(\log_2W_{N/2}^{\mathrm{lex}}(\mathrm{MCSP}_S)=(1+o(1))S\log_2S\).
> [Note 534](534-balanced-cut-fourier-quotients-and-arbitrary-order-obdd-width-2026-08-25.md)
> further upgrades this to every deterministic OBDD variable order.
> Proposition 43 below is retained as the historical boundary that note 533 supersedes.

## Proposition 41 (selector-lift equality bound)

Let \(r<n-1\), let \(H\) be a family of \(r\)-variable truth tables, and embed each
\(h\in H\) into an \((n-1)\)-variable half-table by adding dummy variables. Suppose that
the duplicated table \(h\Vert h\) lies in \(A=\mathrm{MCSP}_S\) for every \(h\in H\).
For \(h,g\in H\), write \(M(h,g)\) for the \(n\)-variable table whose two middle blocks
are the extensions of \(h\) and \(g\). Define
\[
 \mathcal P_{r,S}
 =\{(h,g): \operatorname{CC}(M(h,g))\le S\}.
 \]
The map \((h,g)\mapsto (y\mapsto M(h,g)(0,y),M(h,g)(1,y))\) is injective after
identifying the dummy coordinates, and therefore
\[
 |\mathcal P_{r,S}|\le |\mathcal L_{r+1,S}|.
 \tag{531.1}
\]
Consequently the middle-cut width obeys
\[
 \boxed{
 W_{N/2}(\mathrm{MCSP}_S)
 \ge
 \frac{|H|^2}{2|\mathcal L_{r+1,S}|+|H|}.
 }
 \tag{531.2}
\]

### Proof

Join distinct \(h,g\in H\) whenever \(M(h,g)\in A\) or \(M(g,h)\in A\). Each accepted
ordered pair is a distinct \((r+1)\)-variable function: the selector bit chooses the two
halves, and the \(r\) live variables choose the coordinate inside a half. Hence the graph
has at most \(|\mathcal L_{r+1,S}|\) edges. An independent set \(I\subseteq H\) gives
distinct residuals, since \(h\Vert h\) is YES while \(h\Vert g\) is NO for distinct
\(h,g\in I\). The greedy bound
\(\alpha(G)\ge |H|^2/(2|E(G)|+|H|)\) proves (531.2). \(\square\)

If \(H\) consists of all \(r\)-variable tables whose circuits fit in \(S-O(1)\), then
\(|H|=|\mathcal L_{r,S-O(1)}|\), and (531.2) refines Proposition 38 by replacing the
full \(n\)-variable YES entropy in the denominator with the selector-scale quantity
\(|\mathcal L_{r+1,S}|\). This is the smallest direct-sum interface exposed by the equality
gadget; any \(\Omega(S)\) conclusion must now prove a strict entropy gap at this selector scale.

## Proposition 42 (multiblock equality has no exponential gain)

Let \(k\ge2\), \(N=km\), and let \(D_h=h^{\Vert k}\) be the \(k\)-fold diagonal table for
\(h\in H\subseteq\{0,1\}^m\), with \(D_h\in A\). For each binary block pattern
\(p\in\{0,1\}^k\setminus\{0^k,1^k\}\), let \(T_p(h,g)\) be the table obtained by placing
\(h\) in blocks with \(p_i=0\) and \(g\) in blocks with \(p_i=1\). Join \(h\ne g\) whenever
\(T_p(h,g)\in A\) for some such pattern or its complement. Then
\[
 |E(G)|\le (2^k-2)|A|,
 \qquad
 W_{m}(A)\ge
 \frac{|H|^2}{2(2^k-2)|A|+|H|}.
 \tag{531.3}
\]
Thus fixed \(k\), or more generally \(k=o(S)\), changes only a subexponential factor and
cannot beat the half-entropy exponent \(2\log|H|-\log|A|\).

### Proof

For a fixed pattern \(p\), the map \((h,g)\mapsto T_p(h,g)\) is injective. The number of
unordered pairs witnessed by that pattern is therefore at most \(|A|\); summing over the
\(2^k-2\) nonconstant patterns gives the edge bound. The same independent-set argument as
in Proposition 41 proves (531.3). \(\square\)

The obstruction is MCSP-specific as well. Let \(K\) be any family of \(r\)-variable tables
with
\[
 \operatorname{CC}(h)\le (S-C_k)/2\qquad(h\in K),
 \tag{531.4}
\]
where \(C_k\) is the fixed selector cost for a chosen pattern. A circuit for \(T_p(h,g)\)
is obtained by computing \(h\) and \(g\), then applying the fixed block selector, so
\[
 \operatorname{CC}(T_p(h,g))
 \le \operatorname{CC}(h)+\operatorname{CC}(g)+C_k\le S.
 \tag{531.5}
\]
The mixed graph on \(K\) is therefore complete for every fixed pattern; no independent-set
argument can extract a residual family from this large low-complexity core.

## Proposition 43 (current entropy boundary)

Write \(a_j(t)=\log_2|\mathcal L_{j,t}|\) and \(S=2^{\mu n}\), \(0<\mu<1\). The standard
ordered gate-list count gives
\[
 a_j(t)\le 2t\log_2(j+t)+O(t).
 \tag{531.6}
\]
Lupanov gives a family of all \(r\)-variable tables whenever
\[
 (1+\alpha_r)\frac{2^r}{r}\le S-O(1),
 \qquad
 \alpha_r=O(\log r/r),
 \tag{531.7}
\]
so only \(2^r=\Theta(S\log S)\) is currently certified with a basis-independent leading
constant. Therefore (531.2) yields no proved \(\Omega(S)\) exponent: the lower and upper
terms are both \(\Theta(S\log S)\), and their leading constants may cancel. Equivalently,
\[
 \Delta_n(S)
 :=2a_{n-1}(S-O(1))-a_n(S)
 \]
remains undetermined in sign at the \(\Omega(S)\) scale by the presently cited bounds.

To cross this boundary one needs a genuinely new two-source circuit direct-sum/lower-bound
theorem for selector splices. Harper expansion, generic additive energy, and multiblock
diagonalization do not supply it. This is a strict route closure, not an MCSP counterexample
and not a proof of \(P\ne NP\).

## Dependencies

- [Proposition 38](529-middle-cut-equality-gadget-residual-boundary-2026-08-24.md)
- [Propositions 39--40](530-xor-expansion-does-not-control-residual-width-2026-08-24.md)
