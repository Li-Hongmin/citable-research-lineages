> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 外部 P&NP 回流报告的吸收与路线筛选（2026-08-15）

## 输入与证据等级

本 note 处理下载文件

"[unbundled local reference]"

中的可复用数学内容。该文件是 ChatGPT Pro 导出，不能替代原始文献、项目权威 note
或可复现实验；报告中的阶段编号、穷举计数、哈希值和 Google Drive 写入声明均不作为
本项目证据。下面只吸收能独立核验的恒等式、量词约束和复杂度上界。

## 已吸收的三条主线

### 1. 固定 decoder 必须先统一，再谈放大

报告把 exact search、range decision 和 \(P\) vs \(NP\) 的条件推论集中到同一个固定
decoder 上。这一点已由 [note 089](089-fixed-ph-local-decompressor-merge-magnification-2026-08-15.md)
形式化：对固定 PH-local \(D_N\)，若 \(NP\subseteq P/poly\)，则同一个固定 range language
具有 \(N\ell(N)^{O(1)}\) 的上界；若 \(P=NP\)，则 exact inverse 有
\(\ell(N)^{O(1)}\) 单遍空间和更新时间。新 sampler 候选的参数和 fallback 条件已在
[note 091](091-noncanonical-sampler-decoder-image-range-2026-08-15.md) 中补齐。

### 2. 量词不能把一族语言自动合成一个固定硬语言

从

\[
\forall k\ \exists L_k\in\mathsf{NP}:\quad
L_k\notin\mathsf{SIZE}(n^k)
\]

不能直接推出存在一个 \(L\) 同时排除所有多项式大小。若要把指数族合并，必须给出统一
验证器/统一语言（例如带参数前缀的切片），并重新核对长度与电路指数。该量词边界已在
[note 076](076-kannan-quantifiers-coherent-avoid-and-time-scale-boundary-2026-08-14.md)
记录；本次报告再次确认它是路线筛选的硬条件，而非新的下界。

### 3. zero-list 方案先过信息率筛选

任意把 \(t\)-子集编码为不同二进制字符串的 rank 表示，至少需要

\[
\left\lceil\log_2\binom Nt\right\rceil
\]

位。这只是单射计数，不是电路下界；它只提供一个便宜的筛选规则：若候选 seed、索引和
局部随机访问结构的总描述长度没有明显小于上述 rank 长度，就不能宣称存在渐近压缩。
因此 zero-list 路线的下一步不是再做密度口号，而是给出一个可证明的局部随机访问器，
并逐项记账其 seed、查询和输出长度。

## 两个安全的基线比较

### 无条件枚举上界

对任意固定映射 \(D:\{0,1\}^{s}\to\{0,1\}^{N}\)，其 range-membership 可以用
对所有 \(2^s\) 个 seed 做等式比较并 OR，得到普通电路大小

\[
O(N\,2^s).
\]

当 \(s=\lceil\log_2N\rceil+\Delta\) 时，这个朴素上界是
\(O(N^2\,2^\Delta)\)，不是报告中未给证明的
\(N\operatorname{polylog}N+N2^\Delta\log N\)。后一个更强的式子若要使用，必须另给
具体的 trie/content-addressing 构造和门数证明，当前不晋级。

### PRG range 只是桥梁，不是下界

若 \(G:\{0,1\}^{s}\to\{0,1\}^{N}\)，则 \(R_G(y)=1[y\in\operatorname{Range}(G)]\) 在
生成器分布上恒为 \(1\)，而在均匀 \(y\) 上的接受率至多 \(2^{s-N}\)。这是一个直接的
区分优势计算；它说明“硬 range-membership \(\Rightarrow\) 该生成器不可能被同规模电路
高效区分”。但它不提供 \(R_G\) 的一般电路下界，也不单独推出 \(P\ne NP\)。

## 明确不采纳的报告主张

- “精确稀疏 Shannon 边界”的公式在导出文本中存在数学符号丢失，且没有给出自足证明；
  仅保留上面的 \(\log\binom Nt\) 信息率筛选，不把该 \(\Theta\) 式写入权威结论。
- 阶段 XXIV 的穷举数量、完整性哈希和 Drive 回写状态没有随报告提供可复现实验或本地
  原始文件，因此不晋级为项目事实。
- “zero-list 已有常数信息率”只作为研究直觉；只有 rank 长度比较是当前可核验的数学断言。

## 当前决策

报告没有缩短未解决的核心缺口：仍需构造一个固定、统一、PH-local、seed 为
\(N^{o(1)}\) 的 noncanonical decoder，并对同一固定 range language 证明超准线性
decision lower bound，或对 validity-restricted exact search 给出带 success bit 的相应下界。
因此本轮采取的动作是修正 sampler 候选的量词与 fallback 语义、保留上述三个筛选规则，
不把外部报告的未核验数值或强结论写成定理。

原始输入核验日期：2026-08-15。
