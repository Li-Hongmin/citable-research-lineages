> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 半率代数 block 的近线性 decoder（2026-08-15）

## 构造定理

取一族可显式构造的有限域 \(\mathbb F_{2^b}\)，以及大小为
\(N=2^m\) 的加性评价网格 \(H\subseteq\mathbb F_{2^b}\)（或 \(H^d\) 的固定
展平版本）。令
\[
q=\frac{Nb}{2}
\]
（一般 q 先取到相邻的此类参数，再做固定 zero-padding）。对
\(K=N/2\) 个 field coefficients
\[
a=(a_0,\ldots,a_{K-1})\in\mathbb F_{2^b}^{K},
\]
定义
\[
P_a(X)=\sum_{j=0}^{K-1}a_jX^j,\qquad
\operatorname{Eval}(a)=
\operatorname{enc}\bigl(P_a(\alpha_0),\ldots,P_a(\alpha_{N-1})\bigr).
\]
输入长度为 \(Kb=q\) bits，输出长度为 \(Nb=2q\) bits。

若评价点为加性 FFT 的标准网格，则存在 Boolean circuit
\[
G^{\rm alg}_q:\{0,1\}^{q}\longrightarrow\{0,1\}^{2q}
\]
满足
\[
G^{\rm alg}_q(a)=\operatorname{Eval}(a),
\qquad
|G^{\rm alg}_q|=O\!\left(N\log N\cdot b^2\right)
=q\,\operatorname{polylog}q.
\tag{1}
\]

## 复杂度证明

加性 FFT 将次数 \(<N/2\) 的多项式在 \(N\) 个网格点上的评价分解为
\(O(N\log N)\) 次 field additions、multiplications 和固定常数乘法。每个
\(\mathbb F_{2^b}\) 加法为 \(O(b)\) Boolean gates，乘法为 \(O(b^2)\) gates；
故总 gate 数为
\[
O(N\log N\cdot b^2).
\]
由于 \(Nb=2q\) 且 \(b=O(\log q)\)，得到式 (1)。域表示、网格和 FFT
分解均可由 \(m\) 的二进制描述 P-uniform 构造；若采用一般 evaluation points，
也可用标准 product/remainder-tree multipoint evaluation，代价仍为
\(N\operatorname{polylog}N\) 个 field operations。

这个 decoder 的 range 是一个半率 Reed--Solomon 型 codeword family，而不是
所有 \(2q\)-bit strings。它因此不违背 note 086 排除的 systematic/affine
全覆盖结论。

## 与 history-indexed closure 的组合

为同时支持 note 123 的 internal labels，保留 \(O(\log q)\) 个 tag bits，并把
剩余 \(q-O(\log q)\) bits 解释为 coefficients，再用零系数补到
\(K'\le N/2\) 个 field symbols；相应 leaf evaluation circuit 仍满足式 (1)。
对 internal tag 定义
\[
G_q(\iota_{\rm int}(\lambda))
 =
\iota(\lambda_0)\Vert\iota(\lambda_1).
\tag{2}
\]
只要 \(q\ge n+h+O(\log q)\)，label fields 可以放入同一 q-bit seed。于是：

1. 每个 algebraic leaf block 有一个 coefficient seed；
2. 每个 internal block 是两个 child labels 的串接，自动仍在
   \(\operatorname{Range}(G_q)\)；
3. 对固定 history index，整棵 JK tree 都有显式 word-consistent labels。

因此，若所有实际 leaf blocks \(B_{x,v}\) 都属于上述半率 algebraic family，
且 coefficient/label accessor P-uniform，则 note 123 的
\(\operatorname{BExp}_{G,h}\) closure 直接成立，同时
\[
|G_q|=q\,\operatorname{polylog}q.
\]

## Ren--Williams 路线的精确适用边界

Ren--Williams Theorem 3.4 在陈述层面把 \(P\) 与
\(\Pi_{\rm ZoS}\) 抽象成 auxiliary proof oracles；Harsha 的完整性构造更具体：
ZERO-ON-SUBCUBE 的 bundled proof 由 \(P_i,Q_i\) 组成，并在 completeness 时选为
满足 division identities 的低度多项式表；Circuit-SAT 构造中的 \(P\) 也由
\(\widetilde A\) 的局部多项式变换得到。因此，在**重排为 line-restricted blocks**
并固定这些 canonical polynomial witnesses 后，完整 PCP 的 leaf blocks 都可满足：

\[
\boxed{\text{“所有 canonical history blocks 都是半率 algebraic codewords”}}
\]

这不是对任意 auxiliary oracle 字符串的断言，而是对该特定 completeness witness
选择和 line layout 的条件。它解决了 leaf-level algebraic coverage，但仍没有给出
published JK 所需的 canonical lex-first preimages 或跨 line/跨 oracle 的
tree-compatible parent labels；因此不能仅凭本构造断言 \(\operatorname{Solve}_f\)
必然走 failure branch。

快速加性评价可由 Cantor 的 finite-field additive FFT 实现；其基本事实是
在加性网格上以 \(N\operatorname{polylog}N\) 次域运算完成多点评价
([Cantor 1989](https://doi.org/10.1016/0097-3166(89)90020-4))。
Harsha thesis 对该构造的直接描述见其 ROBUST-PCPP--ZERO-ON-SUBCUBE 与
ROBUST-PCP--CIRCUIT-SAT 段落：
[official thesis PDF](https:/[unbundled local reference].ttic.edu/~prahladh/papers/thesis/phdthesis.pdf)。
来源：Ren--Williams Theorems 3.4/3.5/4.1，官方报告：
[official report](https://eccc.weizmann.ac.uk/report/2026/118/revision/1/download)。
本文的加性 FFT decoder 与 closure 组合是项目内自足构造；不声称已经证明
\(P\ne NP\)。
