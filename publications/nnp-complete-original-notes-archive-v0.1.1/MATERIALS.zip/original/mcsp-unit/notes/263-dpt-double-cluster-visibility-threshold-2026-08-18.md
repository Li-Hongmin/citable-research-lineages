> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# DPT double-cluster visibility threshold (2026-08-18)

## Theorem

Consider a shared-top direct-product test on \(X(k)\) with vertex alphabet
\(\Sigma\). Let \(U_0,U_1\subseteq X(k)\) be disjoint clusters of masses
\(\mu_0,\mu_1\), and let \(f_0,f_1:X(1)\to\Sigma\) be their local global labels.
Add a tag alphabet \(\{0,1,\bot\}\), and form a left table \(T\) whose tag is
\(i\) and whose payload is \(f_i|_A\) on \(U_i\); outside \(U_0\cup U_1\), use a
tag-\(\bot\) low-agreement table \(T^\star\).

Suppose a proposed DPT-to-global-word theorem has the following target semantics:
whenever \(T\) has shared-top agreement at least \(\delta\), it outputs a single
vertex word \(F\) whose tag is constant on all vertices and for which

\[
  \Pr_A[\operatorname{dist}(T[A],F|_A)\le\zeta]\ge\kappa(\delta),
  \qquad \zeta<1/2.
\tag{DCV1}
\]

Assume the complement table satisfies the explicit low-agreement bound

\[
  \sup_H\Pr_A[\operatorname{dist}(T^\star[A],H|_A)\le\zeta]
  \le\varepsilon_\star.
\tag{DCV2}
\]

Then necessarily

\[
  \kappa(\delta)\le \max\{\mu_0,\mu_1,\varepsilon_\star\}.
\tag{DCV3}
\]

Consequently, a DPT theorem can force one global tagged word to see both clusters
only if its guaranteed mass is strictly larger than the heavier cluster (up to the
outside low-agreement term). A guarantee of merely
\(\kappa(\delta)\le\max\{\mu_0,\mu_1\}\) can be witnessed by selecting one cluster
alone and gives no double-cluster extraction.

## Proof

Let the constant tag of \(F\) be \(c\in\{0,1,\bot\}\). If \(c=0\), every face in
\(U_1\) has tag distance one from \(F\), so no such face can contribute to (DCV1)
because \(\zeta<1/2\). The disjoint \(\bot\)-tag convention excludes the complement,
so the close-face mass is at most \(\mu_0\). The same argument with the roles of
\(U_0,U_1\) exchanged handles \(c=1\). If \(c=\bot\), both tagged clusters are
excluded and (DCV2) bounds the complement contribution by \(\varepsilon_\star\).
Taking the maximum over the three possible constant tags proves (DCV3).
\(\square\)

## Interpretation for GMWZ

For the GMWZ Section 6 heavy clusters, the source guarantee has the form
\(\mu_i\ge\delta^{C_{\mathrm{cl}}}\). The DPT definition by itself gives only a total
global-word mass \(\kappa(\delta)\); it does not state that this mass is larger than
\(\max\{\mu_0,\mu_1\}\), nor that it is split between the two clusters. Therefore
the missing “double-cluster extraction” is a real quantitative condition, not a
choice of proof language. A positive closure theorem must prove, for the actual
computation-generated table, either

* \(\kappa(\delta)>\max\{\mu_0,\mu_1\}+\varepsilon_\star\), or
* a direct conditional guarantee that each cluster receives positive global-word mass.

The first condition contradicts (DCV3); the second can feed the cross-cluster
synchronization inequalities already proved in the project.

This theorem is deliberately conditional on a constant-tag base-word semantics. A
cover lift-word, a vertex-varying sheet tag, or an unrestricted list of local words
is outside (DCV1); those are precisely the remaining escape interfaces.

## Source boundary

The construction of \(T^\star\) and the low-agreement quantifier are the ones used in
GMWZ Lemma 6.3/Section 6 and the project source audit. The theorem is a new elementary
mass calculation on top of that interface; it is not a claim that GMWZ Theorem 6.1
already supplies (DCV1).

* [GMWZ singleton-language closure](209-gmwz-singleton-language-unique-decoding-closure-2026-08-17.md)
* [DPT variance and high-order incidence gate](200-pnp-return-evidence-audit-and-high-order-incidence-gate-2026-08-16.md)
* [Cross-cluster synchronization criterion](../../rw-jk-succinct-reconstruction/statements/cross-cluster-synchronization-for-direct-product-ud.md)
