> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# MCSP 论文库评估与成果分级（2026-08-25）

> **同日更新。** 本文原评估所列的 selector-scale entropy 缺口已由
> [note 533](533-sharp-semantic-entropy-and-canonical-obdd-width-2026-08-25.md) 关闭：在标准
> 固定有限 basis、单输出、fan-in \(\le2\) 模型下，现已得到
> \(\log_2W_{N/2}^{\mathrm{lex}}(\mathrm{MCSP}_S)=(1+o(1))S\log_2S\)。随后
> [note 534](534-balanced-cut-fourier-quotients-and-arbitrary-order-obdd-width-2026-08-25.md)
> 用 balanced-cut Fourier quotient 将同一紧界推广到每个 OBDD 变量顺序。因此项目最强结果
> 已从组合型 barrier 升级为渐近紧的 deterministic OBDD 下界；下文保留的是突破前的检索快照
> 与分级。该新定理仍不覆盖 free BDD、1-NBP、一般 BP 或 one-tape 时间。

## 检索边界

本次采用 `paper-lib` decision-search 模式，检索截至 2026-08-25，围绕四个决策：

1. 项目的 semantic-entropy/fiber barrier 是否已被 MCSP 文献直接给出；
2. Harper/XOR、equality、selector-lift 是否已有等价的 MCSP-specific 结论；
3. one-tape/ROBP residual-width 论证是否超出 CHLMY/CKLM 的模型和指数；
4. 该成果应按“新下界、可复用障碍定理、还是路线关闭”定位。

最近邻矩阵与缓存记录：
`[unbundled local reference]`。

证据等级严格区分：CKLM 2019、CHMY 2021、Oliveira--Santhanam 2018、Oliveira--Pich--Santhanam 2019、Atserias--Müller 2025、Krinkin 2026、Jukna 2012 为全文核验；Glinskih--Riazanov 2022 目前仅 Crossref/OpenAlex 元数据核验，未据此推断定理细节；Harper 1966 仅作基础工具记录。

## 直接支持的文献事实

- MMW 2019 已把资源受限压缩下界与强分离联系起来，并明确指出 canonical truth-table ordering 会改变结构；因此项目不能宣称“首次发现表示方式影响 magnification”。
- CKLM 2019 已给出基于 local PRG 的 MCSP 受限模型下界，包括约 $N^{2-o(1)}$ 的 general branching-program 与约 $N^{3-o(1)}$ 的 de Morgan formula 量级。项目的 state/occupancy 论证不是这些无条件指数的改进。
- CHMY 2021 已有随机 one-tape 的近 $N^{1.99}$ 下界、ROBP 相关结果及 subfunction/residual 方法；项目不能把 residual/equality 语言写成首次使用。
- Oliveira--Santhanam 2018 与 Oliveira--Pich--Santhanam 2019 确立 hardness-magnification 及 Gap-MCSP 的关键阈值接口；项目尚未给出 missing general-circuit Gap-MCSP lower bound。
- Atserias--Müller 2025 已用 distinguisher 给出一般及 uniform magnification，并包含 uniform MCSP 结论；其 uniform 结论的分离对象是 $P\ne NP^{\oplus P}$，不能把本项目的 quotient barrier 写成所有 magnification 路线的总瓶颈。
- Krinkin 2026 已覆盖单点 truth-table perturbation 的 (O(n)) 复杂度变化及 (O(nd_H)) telescoping；项目的新意只能放在其与 fiber/XOR/selector 结构的组合。

## 项目真正站得住的新增内容

### 1. 最强主结果：fiber-corrected semantic-entropy barrier

在仅假设 YES 保持的任意 truth-table map 下，项目把 Lupanov junta 下界与 gate-list counting 组合成

\[
\log|\mathcal L_S|=\Theta(\min\{2^n,S\log S\}),
\]

并证明当 $n'=\kappa n+O(1)$、源阈值 $S=2^{\mu_H n}$、目标阈值 $T=2^{\mu_1 n'}$、且 $\mu_H>\kappa\mu_1$ 时，某个 source-YES fiber 必须满足

\[
F=2^{\Theta(n2^{\mu_H n})}.
\]

这比“dummy padding 失配”强：它覆盖任意不要求高效、线性、局部或 systematic 的 exact map，并把可行路线收缩到 predicate-specific、超大纤维的编码。文献核验未发现同一表述已在 MCSP magnification 文献中直接给出；但其组成工具是经典的 Lupanov 与 circuit counting，故应称为“新的组合型 barrier theorem”，不称为新的电路下界。

### 2. 次强主结果：Harper/XOR 的 quotient-specific 关闭

项目证明最大 YES fiber 的 XOR 伙伴几乎全落在高复杂度区，并得到

\[
\log\frac{|\mathcal L_S+\mathcal L_S|}{|\mathcal L_S|}
\ge \left(\frac{1-\mu_H}{2}-o(1)\right)S.
\]

这足以排除 fixed-exponent exact affine/coset quotient 及低描述复杂度 quotient 的一大类方案。Harper 本身是基础工具；新意在于把它和 MCSP YES-fiber、target occupancy 及 materializer 资源账本接起来。它不推出任意 predicate-specific quotient 的 residual width，也不提供 splice-to-XOR reduction。

### 3. 局部新引理：selector-lift equality bound

Proposition 41 将 middle-cut equality gadget 精确收缩到 selector 尺度：

\[
W_{N/2}\ge \frac{|H|^2}{2|\mathcal L_{r+1,S}|+|H|}.
\]

这是当前最有希望成为独立可引用 lemma 的局部结果；但 Proposition 43 同时确认现有 Lupanov 与 gate-list 界只给出分母、分子均为 $\Theta(S\log S)$，尚不能推出 $\Omega(S)$ residual-width gap。固定块数的 multiblock equality 也只增加 $2^k-2$ 的模式因子，并不能指数放大。

## 与现有结果的精确非重叠

| 项目主张 | 当前可安全表述 | 不可表述为 |
|---|---|---|
| semantic entropy/fiber | 任意 YES-preserving map 的组合型编码障碍 | 首次发现 representation matters；新的 MCSP lower-bound exponent |
| Harper/XOR | 排除 exact coset/affine 与低描述 quotient 的统一路线 | 所有 quotient 的 residual-width lower bound |
| equality/selector | 新的 middle-cut graph/injection interface，暴露 selector-scale entropy gap | 已得到 $2^{\Omega(S)}$ residual width |
| one-tape/ROBP | 在 CHMY/CKLM 之上重述 handoff/state/occupancy 接口并明确逃逸模型 | 首次 residual 方法；超越 $N^{1.99}$ 或 $N^{2-o(1)}$ 指数 |
| magnification | quotient/fiber 路线的结构性关闭 | $P\ne NP$、$NP\not\subseteq P/poly$ 或 general-circuit Gap-MCSP 新下界 |

## 成果级别判断

按理论计算机科学论文的结果层级，当前最稳妥的判断是：

**“可形成一篇有明确主定理的中高水平 barrier/route-closure 论文；若只保留现有内容，尚不是突破性 MCSP lower-bound 或 hardness-magnification 定理。”**

更具体地说：

- 作为项目内部成果：已从若干 no-go 观察升级为一个可复用的 semantic-entropy/fiber 障碍体系，达到“研究方向可交付”的级别。
- 作为投稿成果：主定理若压缩为 Theorem 1 + Harper occupancy dichotomy，并补足与 MMW/CHMY/CKLM/Atserias--Müller 的逐条边界，具备理论论文的独立性；审稿人最可能要求证明该 barrier 覆盖的 quotient 类确实是公认接口，而非人为模型。
- 作为领域突破：目前不够。决定性缺口是 selector-scale entropy gap 或真正的 MCSP-specific splice-to-XOR/residual-width theorem；补上其中任一项，级别才可能跃迁到强结果。

## 下一步决策

不应继续堆叠 generic Harper、multiblock 或 point-flip 变体。最便宜且有区分力的下一步是二选一：

1. 证明 $\Delta_n(S)=2a_{n-1}(S-O(1))-a_n(S)=\Omega(S)$（需要新的两源电路 direct-sum/下界）；或
2. 明确限定一个公认的 predicate-specific quotient/ROBP handoff 模型，并证明 splice-to-XOR 或 charged-state 下界。

若两者均不能推进，应冻结当前正文，按“高质量结构性障碍论文”交付，而不要把未闭合的 (S)-级 residual barrier 写成已解决结果。
