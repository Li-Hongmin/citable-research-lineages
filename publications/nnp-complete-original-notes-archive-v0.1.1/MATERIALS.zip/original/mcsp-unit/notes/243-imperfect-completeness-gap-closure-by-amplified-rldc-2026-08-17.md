> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Imperfect-completeness gap closure by amplified RLDCs (2026-08-17)

## Contribution

The perfect-completeness hypothesis in notes 240--242 is not the real
escape, provided the two branch probabilities have a constant gap. A
constant number of independent repetitions, followed by a threshold test,
raises the correct branch to standard \(2/3\) completeness and lowers the
wrong-branch acceptance below \(1/3\). The resulting inline decoder is an
ordinary binary relaxed locally decodable code with constant locality. The
adaptive RLDC lower bound of Dall'Agnol--Gur--Lachish therefore rules out a
near-linear proof even when the original correct branch is only imperfectly
complete.

This is an application of a known coding lower bound, but it closes a real
RW/JK quantifier escape: replacing exact honest acceptance by a constant
success probability does not help unless the correct and wrong branches lose
their gap.

## Theorem

Let

\[
  \Pi:\{0,1\}^{k}\longrightarrow\{0,1\}^{P}
\]

be a binary proof map. For every \(i\in[k]\) and \(b\in\{0,1\}\), let
\(V_{i,b}\) be a randomized, possibly adaptive verifier making at most \(r\)
queries to the proof. Write \(p_{i,b}(z)\) for its acceptance probability.

Assume constants \(0<\rho<1\) and

\[
  0\le \beta<\alpha\le 1,
  \qquad \gamma:=\alpha-\beta>0,
\]

such that, for every \(m\in\{0,1\}^{k}\) and \(i\in[k]\),

1. **Imperfect correct-branch completeness**
   \[
     p_{i,m_i}(\Pi(m))\ge\alpha;
   \tag{243.1}
   \]

2. **Target-relative wrong-branch soundness**
   \[
     d_H(z,\Pi(m))\le\rho P
     \Longrightarrow
     p_{i,1-m_i}(z)\le\beta .
   \tag{243.2}
   \]

Then, for fixed \(r,\rho,\alpha,\beta\) and all sufficiently large \(k\),

\[
  N:=k+P
  \ge
  k^{\,1+\Omega_{r,\rho,\alpha,\beta}(1)}.
\tag{243.3}
\]

Consequently no \(N=k\,\operatorname{polylog} k\) family can satisfy
(243.1)--(243.2) with a fixed positive branch gap \(\alpha-\beta\).

The exponent is not optimized here. A direct use of Corollary 7.9 of
Dall'Agnol--Gur--Lachish gives an exponent of the form

\[
  1+\frac{1}{O\!\left((tr)^2\log^2(tr)\right)},
\tag{243.4}
\]

where \(t=t(\alpha,\beta)\) is the constant repetition count below.

## Proof

### 1. The proof image has constant relative distance

Suppose \(m\neq m'\) but

\[
  d_H(\Pi(m),\Pi(m'))\le\rho P.
\]

Choose \(i\) with \(m_i\neq m'_i\). Applying (243.2) to target \(m'\) and
\(z=\Pi(m)\), while applying (243.1) to target \(m\), gives

\[
  \alpha\le p_{i,m_i}(\Pi(m))
      =p_{i,1-m'_i}(\Pi(m))
      \le\beta,
\]

which contradicts \(\alpha>\beta\). Thus the proof image has relative
distance \(>\rho\). The binary Singleton bound yields

\[
  k\le(1-\rho)P+1.
\tag{243.5}
\]

For \(k\ge2\), this gives \(P/(k+P)\ge1/(3-2\rho)\). Set

\[
  \delta_0:=\frac{\rho}{2(3-2\rho)}.
\tag{243.6}
\]

If \(y\) is within relative distance \(\delta_0\) of

\[
  C(m):=m\Vert\Pi(m),
\]

then its proof suffix \(z\) is within \(\rho P/2\) of \(\Pi(m)\), so (243.2)
applies.

### 2. Constant repetition restores the standard RLDC gap

Choose an integer threshold \(\tau\) and a constant \(t=t(\gamma)\) so that

\[
  \beta<\frac{\tau}{t}<\alpha
\]

with a fixed margin, say at least \(\gamma/3\), on both sides. This is
possible after increasing \(t\) by \(O(1/\gamma)\). On a branch \(V_{i,b}\),
run \(t\) independent fresh random tapes and accept the amplified branch iff
at least \(\tau\) repetitions accept. Chernoff bounds give

\[
  \Pr[\text{amplified correct branch rejects on }\Pi(m)]
  \le e^{-\Omega(\gamma^2t)},
\]

and, for every \(z\) covered by (243.2),

\[
  \Pr[\text{amplified wrong branch accepts on }z]
  \le e^{-\Omega(\gamma^2t)}.
\tag{243.7}
\]

Fix \(t=t(\alpha,\beta)\) large enough that the two quantities in (243.7)
are at most \(1/3\). The amplified branch locality is

\[
  r':=tr=O_{\alpha,\beta}(r).
\tag{243.8}
\]

Now define the inline decoder on a received word \(y\): read the inline bit
\(b=y_i\), run the amplified \(V_{i,b}\) on the proof suffix, output \(b\) if
the amplified branch accepts, and output \(\bot\) otherwise.

On the codeword \(C(m)\), \(b=m_i\), and (243.7) gives correct output with
probability at least \(2/3\). On a word within radius \(\delta_0\), if
\(b=m_i\) the decoder outputs only \(m_i\) or \(\bot\); if \(b\neq m_i\), a
wrong output requires amplified wrong-branch acceptance, which has probability
at most \(1/3\). Therefore \(C\) is a binary weak adaptive

\[
  (r',\delta_0,2/3,1/3)\text{-RLDC}
\tag{243.9}
\]

in the convention where the first parameter after the radius is relaxed
completeness and the last is wrong-output probability.

### 3. Apply the adaptive imperfect-completeness lower bound

Dall'Agnol--Gur--Lachish prove that every constant-query binary relaxed LDC
with constant decoding radius and two-sided constant error has blocklength

\[
  n\ge k^{1+1/O(q^2\log^2q)}.
\tag{243.10}
\]

Their definition permits completeness \(2/3\), rather than exact honest
decoding, and relaxed decoding success \(2/3\). Substituting
\(q=r'=tr\) and the constant radius \(\delta_0\) into (243.10) gives
(243.3)--(243.4).
\(\square\)

## Consequence for the closure program

The binary fixed-locality bottom regime now has the following boundary:

* if \(\alpha=1\), note 240 handles every constant \(\beta<1\);
* if \(0<\alpha<1\) but \(\alpha>\beta\), this note restores the standard RLDC
  gap by constant repetition and gives the Dall'Agnol--Gur--Lachish barrier;
* if \(\alpha\le\beta\), the branch gap itself disappears. The distance
  argument fails at exactly this point, and no RLDC closure follows from the
  present reduction;
* if \(r\) grows, the repetition remains constant for fixed
  \(\alpha-\beta\), but the lower-bound exponent must be recomputed as a
  function of \(r\).

Thus imperfect completeness is not an independent near-linear escape. The
remaining genuinely different escape is a vanishing or reversed branch gap,
not merely replacing probability \(1\) by a constant below \(1\).

## Scope and non-claims

This is not a new RLDC lower-bound proof. The new step is the explicit
threshold amplification that maps the RW/JK two-branch verifier to the exact
imperfect-completeness RLDC hypothesis. It is binary and family-level. It
does not prove a lower bound when \(\alpha\le\beta\), for growing alphabets, or
for a verifier whose branch acceptance events cannot be independently
re-sampled.

## Sources

* M. Dall'Agnol, T. Gur, and O. Lachish, *A Structural Theorem for Local
  Algorithms with Applications to Coding, Testing, and Privacy*, ECCC
  Report TR20-154, Corollary 7.9. The paper states the adaptive constant-query
  relaxed-LDC lower bound and defines completeness and relaxed decoding at the
  \(2/3\) level:
  <https://eccc.weizmann.ac.il/report/2020/154/>.

* T. Gur and O. Lachish, *On the Power of Relaxed Local Decoding Algorithms*,
  SIAM J. Comput. 50(2), 2021. Their lower-bound techniques explicitly extend
  to valid-codeword decoding probability \(2/3\).

* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for Relaxed
  Locally Decodable Codes via Robust Daisies*, arXiv:2511.21659, Theorem 1,
  for the complementary arbitrary non-adaptive bound used in notes 240--242.
