> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Auxiliary-pad 黑箱下的 RW parent-binding 不可推出性（2026-08-18）

## 命题

只使用 Ren--Williams Theorem 3.5 中**允许固定多项式长度余量、且只约束
verifier 行为/完备性/可靠性与 systematic witness/output 字段**的 source-level
bullets，不能推出任意 auxiliary PCP block 到 output/history 的 parent map。原因是
这些 bullets 对 auxiliary oracle 没有语义绑定；它们只约束 systematic witness 部分
\(\widetilde w\)、verifier 的接受率，以及当最大 prefix 被固定时的 output 字段。
若某个接口把 proof length 写成精确等式，则本命题只适用于把 pad 重新标记为已有
auxiliary 坐标的版本；这里不声称能改变那个额外的 exact-length 条件。

设一个满足 Theorem 3.5 bullets 的 proof/verifier 为

\[
\Pi=(\widetilde w,\Pi_{\mathrm{aux}}),\qquad
V^\Pi(x,z).
\]

对任意在该长度余量内的 \(M\)，定义 auxiliary-pad 扩展

\[
\widehat\Pi=(\widetilde w,\Pi_{\mathrm{aux}},U),
\qquad
\widehat V^{(\widetilde w,\Pi_{\mathrm{aux}},U)}(x,z)
:=V^{(\widetilde w,\Pi_{\mathrm{aux}})}(x,z),
\tag{388.1}
\]

其中 \(U\in\{0,1\}^M\) 是 verifier 完全忽略的 pad。所有原有的
completeness、soundness、systematic-prefix 和 output-recovery bullets 保持不变；
proof length 只增加一个公开固定的 \(M\)，并仍落在原 source-level 的多项式长度界内。

但是 \(U\) 可以独立于 output/history 任意变化。因此，对一个长度为 \(d\) 的
descriptor \(\sigma\)，当其余输入只包含 Theorem 3.5 bullets、auxiliary block
\(y\) 与公开 block/path metadata 时，不能在所有这些保持性扩展上统一恢复 parent；
特别地，对 \(2^b\) 个 parent，若 \(d<b\)，必有两个 parent 共享同一个 \(\sigma\)。
此时不存在统一函数

\[
D(y,\mathrm{metadata},\sigma)
\]

能够在所有这些保持性扩展上恢复 parent output。

## 证明

由抽屉原理取两个 target \(m_0,m_1\)，其 systematic/output 字段不同但
descriptor 相同。把两个扩展的 pad 在被观察的 auxiliary block 上设置为同一个
\(y\)，并把公开的 block/path metadata 设为相同；其余 pad 位可任意补齐。由
(388.1)，两个 verifier 在所有随机带上的行为完全相同，故 Theorem 3.5 的所有
可见条件也完全相同。黑箱 decoder 因而得到相同的
\((y,\mathrm{metadata},\sigma)\)，却必须输出两个不同的 parent，矛盾。因此 exact
binding 一个 \(2^b\)-family 至少需要 \(d\ge b\) bits。

若允许 target-dependent descriptor 区分 \(m_0,m_1\)，则该 descriptor 已经承担
了 target information。对一个大小为 \(2^b\) 的 parent family，固定一个
auxiliary outsider/channel 后，单纯的 transcript counting 给出至少 \(b\) bits
的 descriptor；更一般的多 outsider 情形退化为 C378/C383 的
\[
\sum_t 2k_t+d\ge b.
\]

## 对 RW Gate-I 的直接后果

若 JK 的 first-failure ancestry 落入 auxiliary 区间，Theorem 3.1 只返回
\[
y\notin\operatorname{Range}(G_k).
\]
由 auxiliary-pad 保持性，不能从 Theorem 3.5/4.1 黑箱推出
\[
B_i[j]=D(y,j)
\]
或任何 whole-parent evaluator。要继续 Closure，必须至少证明下列之一：

1. published RW 的实际 auxiliary construction 不是 pad-invariant，并提供一个
   target-separated fingerprint 或 auxiliary-to-output relation；
2. first-failure block 必然落入 systematic output 区间，并支付 C383 的
   multi-block 覆盖成本；
3. descriptor 明确承担被 pad 隐藏的 parent information，并证明其不超过
   address scale。

这把“auxiliary block 也许暗含 parent binding”从 source-level 推测提升为一个
可证伪的构造性目标：必须读取并使用 Harsha PCP 的实际 auxiliary semantics，
而不能只调用 Theorem 3.5 的抽象 completeness/soundness。

## 证据边界

* 这是一个保持性/黑箱不可推出性定理：它证明现有 source bullets 不足以推出
  auxiliary attachment；其量词范围是上面明确的 suffix-closed、polynomial-slack
  bullet package。
* 它不证明 published RW 的实际 auxiliary oracle 存在一个被 verifier 忽略的 pad，
 也不证明所有可能的新 PCP 构造都失败。
* 因而它不是 \(P\ne NP\) 证明或一般 dPCP/RLDC 不可能性；其价值在于严格关闭
  “仅凭 Theorem 3.5 就得到 auxiliary parent map”的路线，并把下一正攻接口
  收缩到 source-specific auxiliary semantics。
