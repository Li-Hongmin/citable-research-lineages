> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 稀疏 Hamming 球的近线性 decoder 与 budget-free merge 障碍（2026-08-15）

## 结论

令 \(N=2^m=2q\)，并置
\[
w=\left\lfloor\frac{q}{m+1}\right\rfloor.
\]
存在一个固定的 fan-in-2 Boolean circuit
\[
G_q:\{0,1\}^{q}\longrightarrow\{0,1\}^{N}
\]
满足
\[
\operatorname{Range}(G_q)
=
\{y\in\{0,1\}^{N}:|y|\le w\},
\qquad
|G_q|=O(q\log^3 q).
\tag{1}
\]
在 promise \(|y|\le w\) 下，还存在一个同阶大小的 right inverse
\(R_q\) 使 \(G_q(R_q(y))=y\)。

这是一个 nonlinear、non-systematic 的 near-linear decoder，但只覆盖稀疏 Hamming 球，
不覆盖所有 size-\(q/\operatorname{polylog}q\) circuit truth tables。

## 构造

把 seed 解析为 \(w\) 个槽
\[
(e_j,a_j),\qquad e_j\in\{0,1\},\quad a_j\in\{0,1\}^{m},
\]
共 \(w(m+1)\le q\) 位；剩余 seed 位忽略。定义
\[
G_q(u)_x=\bigvee_{j:a_j=x} e_j.
\tag{2}
\]
为并行计算所有 \(N\) 个地址的值，建立两类 records：

- 对每个 \(x\in\{0,1\}^{m}\)，一个固定的 query record \((x,\mathrm{query})\)；
- 对每个 seed slot，一个 data record \((a_j,\mathrm{data},e_j)\)。

第一次用 Batcher sorting network 按 \((\mathrm{address},\mathrm{type})\) 排序，令同地址的
data records 位于 query record 之前。沿排序后的相同地址段计算 prefix-OR；query record
携带的累计位正是式 (2) 的 \(G_q(u)_x\)。第二次按
\((\mathrm{type},\mathrm{address})\) 排序，把 query records 恢复为地址顺序并读出 \(N\) 个
输出位。

共有 \(L=N+w=O(q)\) 条 records。每个 \(m\)-bit record comparator 可由
\(O(m)\) 个 fan-in-2 gates 实现；Batcher network 使用 \(O(L\log^2L)\) 个 comparators。
两次排序和 prefix-OR 的总门数因此为
\[
|G_q|=O(L\,m\log^2L)=O(q\log^3q).
\tag{3}
\]
重复地址、禁用槽和 seed padding 都被上述 OR 语义自然处理，故 (1) 的 range 恰为
Hamming 球。

## Promise canonical right inverse

给定一个 promise 输入 \(|y|\le w\)，建立 \(N\) 条
\[
(\,1-y_x,\ x\,)
\]
records，按该 key 排序，使 \(y_x=1\) 的地址在前。对排序后的前 \(w\) 条逐条输出
\((e_j,a_j)=(y_x,x)\)（等价地，若 key 的首位为 \(1-y_x\)，则
\(e_j=1-\mathrm{key}_j\)），其余槽置零；未用 seed 位也置零。这样
\(|y|<w\) 时多出的零地址不会被激活。该排序网络大小为
\(O(N\log^3N)=O(q\log^3q)\)，并满足
\[
G_q(R_q(y))=y\qquad(|y|\le w).
\tag{4}
\]
这只是给定完整 truth table 的 promise inverse；它不等于从一个 compact bit-accessor
免费物化 \(N\) 个 \(y_x\)。

## 非线性、非系统性与 budget-free merge 不能混淆

对充分大的 \(q\)（从而 \(w\ge1\)），式 (1) 的 range 含 \(0^N\) 和每个 singleton \(e_i\)。
因此它不可能是 affine range：
若一个 affine subspace 含 \(0^N\) 和全部 \(e_i\)，其线性维数至少为 \(N>q\)。
同样，固定 \(q\) 个 output coordinates 的 systematic projection 不可能同时覆盖
\(0^N\) 与所有投影外 singleton；这与 note 086 的一般反证一致。

更一般地，任何覆盖 \(0^N,e_1,\ldots,e_N\) 的
\(G:\{0,1\}^{q}\to\{0,1\}^{N}\) 都不可能有固定长度的 total
\(\mathrm{OR}\)-combiner \(M\) 满足
\[
G(M(u,v))=G(u)\lor G(v)
\qquad\text{对所有 }u,v.
\tag{5}
\]
反复合并 singleton codes 将产生所有 \(2^N\) 个 Boolean strings，但 \(G\) 的 range
至多只有 \(2^q\) 个元素。XOR-combiner 同理。因而 near-linear decoder 的 functional
decomposition 必须显式携带 budget/type；不能假设一个无溢出的固定长度 OR/XOR 合并器。

## 与一般 circuit coverage 的边界

这个构造只证明一个可复用的 sparse primitive：
\[
\{y:|y|\le q/\Theta(\log q)\}\subseteq\operatorname{Range}(G_q).
\]
它没有给出
\[
\mathcal C_{\log(2q),\,q/\operatorname{polylog}q}
\subseteq\operatorname{Range}(G_q),
\]
也没有把 Lupanov 的 local selector table 压缩成 \(q\) 个 seed bits。Lupanov 的直接
selector description 仍需 \(N\) 个独立 pattern bits；从 \(q\) bits 非线性地产生这些 bits，
正是原 global batch-decompression 问题。

因此本 note 的路线裁决是：
\[
\boxed{
\text{sparse Hamming-ball decoding is solved at }O(q\log^3q);
\quad
\text{general low-circuit coverage remains unknown.}
}
\]

## 文献与适用范围

- Batcher sorting network 只用于 \(O(L\log^2L)\) comparator 上界；本 note 的 decoder、
  right inverse 和 merge obstruction 都是自足推导。
- Jukna, *Boolean Function Complexity: Advances and Frontiers*, Theorem 1.15 的 Lupanov
  形式只作为 selector-description 的边界参照，不被误写成本文 decoder 的构造。
- \(N=2q=2^m\) 是本 note 的参数化端点；一般非二次幂长度需另行 padding 处理。

原文核验日期：2026-08-15。
