> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A source-safe joint alphabet--locality envelope

## Statement

Let
\[
  \Pi_k:\{0,1\}^k\longrightarrow\Sigma_k^{P_k},
  \qquad A_k:=|\Sigma_k|\ge2,
\]
be a common proof map.  For every message coordinate \(i\) and claim
\(b\in\{0,1\}\), assume an adaptive verifier of depth \(r_k\) satisfies perfect
correct-claim completeness and target-relative wrong-claim error at most
\(1-\sigma_0\) on every proof within relative radius \(\rho>0\), where
\(0<\sigma_0\le1\) and \(\rho\) are fixed.  Put
\[
  Q_k:=1+2\sum_{j=0}^{r_k-1}A_k^j,
  \qquad
  H_k:=\log_2\log_2(k+2)+\log_2(Q_k+2)
       +\log_2\!\bigl(\log_2(A_k+2)+2\bigr).
\]

If \(N_k:=k+P_k\le k(\log_2(k+2))^c\) for infinitely many \(k\), then there is a
constant \(c_*=c_*(\rho,\sigma_0,c)>0\) such that, for every sufficiently large
such \(k\),
\[
  \log_2 A_k\ge k/2
  \qquad\text{or}\qquad
  Q_k H_k\ge c_*\log_2 k .
\tag{300.1}
\]

Thus the GGS/inline route rules out a near-linear construction whenever the proof
alphabet carries \(o(k)\) bits per symbol and
\[
  Q_k\bigl(\log\log k+\log(Q_k+2)+\log\log(A_k+2)\bigr)=o(\log k).
\]
The conclusion is source-safe: it uses only the arbitrary finite-alphabet,
non-adaptive RLDC bound of Goldberg--Gur--Saraogi and an explicit
adaptive-to-nonadaptive decision-tree compilation.

## Proof

The two claim branches imply that distinct proof words have relative Hamming distance
greater than \(\rho\).  Write \(\ell_k=\log_2 A_k\).  If
\(\ell_k\ge k/2\), the first alternative in (300.1) holds.  Otherwise the
\(A_k\)-ary Singleton bound gives
\[
  k\le ((1-\rho)P_k+1)\ell_k,
\]
and hence
\[
  \frac{P_k}{N_k}\ge
  \frac{1}{2(1-\rho)\ell_k+1}.
\tag{300.2}
\]
The inline word uses two extra tags, so its alphabet has size \(A_k+2\).  Taking
\[
  \delta_{*,k}:=
  \frac{\rho}{2\bigl(2(1-\rho)\ell_k+1\bigr)}
\tag{300.3}
\]
ensures that a \(\delta_{*,k}\)-close inline word leaves the proof suffix within
relative distance \(\rho\) of the target proof.

If the GGS radius condition
\[
  \delta_{*,k}>N_k^{-\sigma_0/(2Q_k)}
\tag{300.4}
\]
fails, then \(N_k\ge k\) and (300.3) imply
\[
  Q_k\bigl(\log_2(\ell_k+2)+1\bigr)
  =\Omega_{\rho,\sigma_0}(\log_2 k),
\]
which already implies the second alternative in (300.1).

It remains to consider (300.4).  Fix a random tape.  Each branch is an
\(A_k\)-ary decision tree with at most \(\sum_{j<r_k}A_k^j\) internal nodes.
Querying the union of the two trees and the inline coordinate gives a non-adaptive
RLDC with \(Q_k\) queries, alphabet \(A_k+2\), radius \(\delta_{*,k}\), and
success at least \(\sigma_0\).  The GGS Theorem 1 therefore gives
\[
  N_k\ge
  \left(
    \frac{\sigma_0^2 k}
    {38Q_k^4\log_2^2(A_k+2)\log_2^2 k}
  \right)^{1+1/a_k},
  \qquad
  a_k:=\left\lceil Q_k/\sigma_0\right\rceil .
\tag{300.5}
\]

Suppose, toward a contradiction, that \(Q_kH_k\le\eta\log_2 k\), where
\(\eta>0\) is a sufficiently small constant.  Then
\[
  \log_2 D_k
  \le
  4\log_2(Q_k+2)
  + 2\log_2\!\bigl(\log_2(A_k+2)+2\bigr)
  + 2\log_2\log_2(k+2)+O(1)
  =O(H_k),
\]
where \(D_k\) is the denominator factor in (300.5).  Taking logarithms in
(300.5), using \(N_k\le k(\log_2(k+2))^c\), gives
\[
  \frac{\log_2 k}{a_k}
  \le
  c\log_2\log_2(k+2)+(1+1/a_k)\log_2D_k.
\tag{300.6}
\]
Since
\[
  \frac1{a_k}\ge\frac{\sigma_0}{Q_k+\sigma_0},
  \qquad
  1+\frac1{a_k}\le2,
\]
(300.6) implies
\[
  \frac{\sigma_0\log_2 k}{Q_k+\sigma_0}
  \le C_{\rho,\sigma_0,c}H_k.
\]
For \(\eta\) small enough this contradicts \(Q_kH_k\le\eta\log_2 k\), because
\(Q_k\ge1\) and \(\sigma_0\) is fixed.  This proves (300.1).
\(\square\)

## Scope

The theorem does not claim that the threshold is achievable.  If
\(\log_2 A_k=\Omega(k)\), the proof alphabet itself is a message-scale channel and is
an explicit model exit.  Otherwise (300.1) is a uniform necessary condition.  The
argument does not use the parameterized DGL transfer and therefore does not inherit any
unproved uniformity in a growing query or alphabet parameter.

## Source

Goldberg--Gur--Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally Decodable Codes
via Robust Daisies*, Theorem 1:
<https://arxiv.org/html/2511.21659>.
