> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK all-stage prefix-fiber entropy barrier（2026-08-19）

## 本轮改变的判断

C495 只在 \(i=2\) 展示了“失败块之前的一个 range sibling 可以隐藏任意前缀”。
该现象对任意首次失败 stage \(i\ge2\) 都成立：把唯一 outsider 放在该层最后一个
block，把前面的 \(2^{i-1}-1\) 个 range blocks 独立变化，再沿 JK 的 canonical lift
向上构造顶层 truth table。于是 hard、stage、failure index、outsider 和位置 path
全部固定，而失败之前的 contiguous top prefix 至少携带
\[
n(2^{i-1}-1)
\]
bits 的 parent information。任何 exact parent-binding descriptor 若只依赖这份
transcript，必须支付同样的信息量。

这给出 C490 面向 output prefix 的 all-stage 版本；C495 是 \(i=2\) 的特例。

## 定理 496.1（all-stage prefix-fiber entropy）

令
\[
G_n:\{0,1\}^{n}\to\{0,1\}^{2n},\qquad G_n(u)=u\Vert u,
\tag{496.1}
\]
并令固定 outsider
\[
y_n:=1^n0^n\notin\operatorname{Range}(G_n).
\tag{496.2}
\]

取整数 \(k\ge i\ge2\)，令
\[
m_i:=2^{i-1}-1.
\tag{496.3}
\]
对每个 seed tuple
\[
\mathbf u=(u_1,\ldots,u_{m_i})\in(\{0,1\}^{n})^{m_i},
\]
定义 stage-\(i\) 字符串
\[
Y_i(\mathbf u)
 :=(u_1\Vert u_1)\Vert\cdots\Vert
 (u_{m_i}\Vert u_{m_i})\Vert y_n
\in\{0,1\}^{n2^i}.
\tag{496.4}
\]

若 \(v=v_1\Vert\cdots\Vert v_{2^j}\) 且每个 \(v_r\in\{0,1\}^n\)，定义一层 lift
\[
\mathsf L_G(v):=G_n(v_1)\Vert\cdots\Vert G_n(v_{2^j}),
\tag{496.5}
\]
并令
\[
F_{\mathbf u}:=\mathsf L_G^{\,k-i}\bigl(Y_i(\mathbf u)\bigr)
\in\{0,1\}^{T},\qquad T=n2^k.
\tag{496.6}
\]

把 \(F_{\mathbf u}\) 作为 Theorem 3.1 的 truth-table input。则：

1. JK 在 stages \(k,k-1,\ldots,i+1\) 的所有 range tests 都通过，并到达
   \(Y_i(\mathbf u)\)；
2. 在 stage \(i\)，前 \(m_i\) 个 \(2n\)-bit blocks 在 range 中，最后一个 block
   是唯一 outsider \(y_n\)；
3. 所有 \(\mathbf u\) 产生同一个 augmented first-failure transcript
   \[
   \tau_{k,i}:=(\mathrm{hard},\mathrm{stage}=i,
      \mathrm{block}=2^{i-1},y_n);
   \tag{496.7}
   \]
4. 令 \(B_{\mathbf u}\) 为 \(F_{\mathbf u}\) 在最后一个 stage-\(i\) block 的
   ancestor interval 之前的 contiguous prefix，则
   \[
   |B_{\mathbf u}|=2n\,m_i\,2^{k-i}
   =n\,m_i\,2^{k-i+1}.
   \tag{496.8}
   \]
   映射 \(\mathbf u\mapsto B_{\mathbf u}\) 是单射。因此该固定 transcript 的
   parent-prefix fiber 至少有
   \[
   2^{nm_i}=2^{\,n(2^{i-1}-1)}
   \tag{496.9}
   \]
   个不同值。

### 证明

由 (496.1)，\(G_n\) 是单射，且其 range 恰为
\(\{u\Vert u:u\in\{0,1\}^n\}\)。对每个 \(j>i\)，\(F_{\mathbf u}\) 的 construction
正是把 \(Y_i(\mathbf u)\) 的每个 \(n\)-bit chunk 逐层施加 \(G_n\)；所以 stage \(j\)
的每个 \(2n\)-bit block 都在 range 中，且 canonical preimage 唯一。JK 因而精确
地形成 \(Y_i(\mathbf u)\)。

在 stage \(i\)，(496.4) 的前 \(m_i\) 个 blocks 形如 \(u_r\Vert u_r\)，最后一块
是 \(y_n\)，故唯一失败位置为 \(2^{i-1}=m_i+1\)，得到 (496.7)，与 \(\mathbf u\)
无关。

一层 lift 保持 chunk 顺序，并把每个 \(n\)-bit chunk 复制成两个相同 chunks。
因此 \(Y_i\) 的前 \(m_i\) blocks 在 \(F_{\mathbf u}\) 中仍构成一个 contiguous
prefix，且每个 block 的长度被放大 \(2^{k-i}\) 倍，得到 (496.8)。从该 prefix
中，在每个 block 的第一个 \(n\)-bit chunk 读取 \(u_r\)，所以不同的
\(\mathbf u\) 给出不同的 \(B_{\mathbf u}\)。证毕。

## Descriptor payment

设 \(s_{\mathbf u}\) 是额外 side information，且存在一个 single-valued decoder
\[
D(\tau_{k,i},s_{\mathbf u})=B_{\mathbf u}
\]
对上述全部 seed tuples 正确。由于 \(\tau_{k,i}\) 固定且 \(B_{\mathbf u}\) 有
\(2^{nm_i}\) 个值，\(s_{\mathbf u}\) 必须在这些 tuples 上单射。若 descriptor
按二进制、最大长度为 \(d\)，则
\[
d\ge nm_i=n(2^{i-1}-1).
\tag{496.10}
\]
对一般有限 alphabet \(\Sigma\)，相应地
\[
d\log_2|\Sigma|\ge n(2^{i-1}-1).
\tag{496.11}
\]
如果 side information 只包含 binary ancestry directions、stage 或 failure index，
这些量在本构造中完全固定，不贡献 (496.10)；若它包含前面 successful canonical
preimages，则正是这些 preimages 在支付该信息量。

## 对 systematic RW/JK Closure 的直接含义

在 \(P=NP\) 的 zero-round recompilation 和 Theorem 3.5 的 systematic binary
serialization 下，若 canonical proof 的 output \(B\) 位于 proof 前缀，则 C496
给出一个精确的 source-level dichotomy：

* 若 actual proof image 允许上述 prefix-fiber，则 outsider/stage/path-position
  不能完成 parent attachment；任何 augmented selector 必须支付
  \(n(2^{i-1}-1)\) bits，或使用被完整计价的新 global relation；
* 若 proposed closure 声称不存在该 fiber，则必须证明一个 canonical PCP image
  theorem，把 proof image 排除在 C496 的 prefix-fiber 之外。Theorem 3.1 的 JK
  semantics 本身不提供这一排除。

当 \(i=2\) 时，(496.10) 恢复 C495 的 \(n\)-bit payment；当 \(i=k\) 时，得到
顶层 prefix 版本的 \(n(2^{k-1}-1)\)-bit fiber。该结论仍是 family-level
source barrier，不把任意 \(F_{\mathbf u}\) 冒称为 Ren--Williams Theorem 4.1 的
canonical PCP proof，也不直接推出 \(P\ne NP\)。

## 证据边界

* 依赖 Theorem 3.1 的真实 stage/block recursion；唯一 outsider 使 tie-break 规则
  无关。
* \(G_n(u)=u\Vert u\) 与 \(F_{\mathbf u}\) 是显式 P-uniform JK 输入 family；C496
  不声称该 family 落在 Theorem 4.1 的 PCP-proof image。
* (496.10)--(496.11) 是 descriptor/entropy lower bound，不是单个 fixed parent 的
  circuit lower bound；要接 C455，仍需同一 hard object、同一长度集和一个统一
  address evaluator。

## 来源

* [C495](495-jk-actual-first-failure-transcript-nonattachment-2026-08-19.md)：\(i=2\)
  的 prefix non-attachment。
* [C490](490-jk-all-stage-success-fiber-entropy-boundary-2026-08-19.md)：all-stage
  success-fiber entropy（其 outsider 位于另一端）。
* [C488](488-jk-first-failure-frontier-support-bound-2026-08-19.md)：actual 首失败
  stage 与 forward lift。
* Ren--Williams TR26-118 rev.1, Theorem 3.1：逐层 range test、canonical preimage
  与首个 non-range block。
