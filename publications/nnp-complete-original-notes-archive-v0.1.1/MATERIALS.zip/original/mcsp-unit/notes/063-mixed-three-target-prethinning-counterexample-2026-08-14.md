> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mixed 三 target 的 pre-thinning (1/2) 上界反例（2026-08-14）

## 结论

note [061](061-common-center-mixed-three-target-closure-2026-08-13.md) 的
无条件残余命题中，若先忽略独立列 thinning，试图证明

\[
 \Pr_{r\in\mathbb F_2^N}[\exists S\in\mathcal F:S\subseteq B_r]
 \le \frac12,
 \qquad B_r:=\{d\in D:r\cdot d=1\},
\tag{1}
\]

则该命题已经在 \(N=5\) 为假。下面给出一个实际 affine row-star
实例，满足 three-target、线性独立、全局 inclusion-minimality 和两两
cell-intersection，且左侧为

\[
\frac{18}{32}=\frac9{16}>\frac12.
\tag{2}
\]

因此，不能把完整 AEKR 的证明普适地分解为“先从 affine 参数取得一个
额外 \(1/2\) 因子，再把其余 row/column thinning 因子相乘”。

## 实际 row-star 实例

在 \(\mathbb F_2^5\) 中取

\[
x_0=0,\qquad X=\{0,1\},\qquad
Y=D=\{8,16,6,13,4,24,29,21,2,7\},
\qquad s=(1,2).
\tag{3}
\]

故 \(a=x_s+x_0=1\)、\(b=y_s+x_0=2\)、\(c=a+b=3\)，且
\(X\cap Y=\varnothing\)。下列每个数集 \(S\) 表示 row-star cell
集 \(T_S=\{(0,y):y\in S\}\)：

\[
\begin{array}{c|l|c}
\text{type}&S&\bigoplus S\\ \hline
R&\{8,13,4\},\ \{16,4,21\},\ \{4,24,29\}&1\\
P&\{8,16,6,29\},\ \{8,6,24,21\},\
  \{16,6,13,24\},\ \{6,13,29,21\}&3\\
C&\{8,16,29,7\},\ \{8,24,21,7\},\
  \{16,13,24,7\},\ \{13,29,21,7\}&2
\end{array}
\tag{4}
\]

R 集合为奇数大小、P/C 集合为偶数大小；所以 (4) 正是 note 046 的
三个 target 条件。每个列向量集的秩等于其大小。

这不是抽象 binary-matroid 例：逐一对 (4) 检验 affine 方程系统，得到

\[
T_S\ \text{可行},\qquad T_S\cup\{s\}\ \text{不可行},\qquad
Q\cup\{s\}\ \text{对每个 }Q\subsetneq T_S\text{ 都可行}.
\tag{5}
\]

因此每个 \(T_S\) 都是关于 \(s\) 的 inclusion-minimal collision
witness。11 个集合也两两相交。作为简短的结构检查，三条 R 集合共同含
\(4\)，四条 P 集合共同含 \(6\)，四条 C 集合共同含 \(7\)；跨 type
的交点由其余两叶组成的 \(3\times4\) 设计给出。完整的有限核验见下方
proof bundle。

## 精确命中计数

令 \(H_S=\{r:r\cdot d=1\ \text{for all }d\in S\}\)。11 个集合的
解集是

\[
\begin{array}{c|c@{\qquad}c|c}
R_1&\{13,15,29,31\}&R_2&\{21,23,29,31\}\\
R_3&\{13,15,21,23\}&P_1&\{27,28\}\\
P_2&\{11,12\}&P_3&\{19,20\}\\
P_4&\{3,4\}&C_1&\{25,28\}\\
C_2&\{9,12\}&C_3&\{17,20\}\\
C_4&\{1,4\}&&
\end{array}
\tag{6}
\]

其并集为

\[
\{1,3,4,9,11,12,13,15,17,19,20,21,23,25,27,28,29,31\},
\tag{7}
\]

恰有 18 个元素，立即给出 (2)。所有计数为有限域上的整数枚举，没有使用
随机抽样或浮点优化。

可复现脚本位于
[proof bundle](../computations/bundles/n5-mixed-three-target-prethinning-counterexample/verify.py)。

## 边界

此例只推翻 (1)，即 **pre-thinning** 的无条件 \(1/2\) 上界。它不构成
完整 AEKR 的反例：真实问题还要求独立列保留、中心 row 的 affine 条件和
中心 row 保留。因而 note 061 的完整残余命题

\[
\Pr_{r,V}[\exists S\in\mathcal F:S\subseteq B_r\cap V]\le\frac14
\tag{8}
\]

并未由本例判定；任何继续证明该不等式的路线必须直接使用 thinning 与
mixed target 结构的联合信息，而不能先断言 (1)。
