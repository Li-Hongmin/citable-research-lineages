> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 有限深度 tree-closed decoder：显式构造并饱和 pair-lift 容量（2026-08-15）

## 定理

固定深度 \(h\ge 0\)、seed 长度 \(q\)，以及一个单射 leaf evaluator

\[
E:\{0,1\}^{r}\hookrightarrow\{0,1\}^{q}.
\tag{1}
\]

令

\[
\tau=\left\lceil\log_2(h+2)\right\rceil+2,
\qquad
2^{h+1}r+\tau\le q.
\tag{2}
\]

存在一个总电路

\[
G_{q,h,E}:\{0,1\}^{q}\longrightarrow\{0,1\}^{2q}
\tag{3}
\]

使以下 \(2q\)-bit 叶块族

\[
\mathcal A_E
 =
\{\,E(a)\Vert E(b):a,b\in\{0,1\}^{r}\,\}
\tag{4}
\]

的任意 \(2^h\)-叶 ordered tuple 都能沿同一个 decoder 逐层保持在
\(\operatorname{Range}(G_{q,h,E})\) 中。若 \(E\) 的电路大小为 \(S_E\)，则在标准
fan-in-2、允许 wire-copy/fanout 的模型中

\[
|G_{q,h,E}|
 =
O\!\left(S_E+q(h+1)\right).
\tag{5}
\]

当 \(h=O(\log q)\) 时，这是 \(S_E+q\,\operatorname{polylog}q\) 的近线性规模。

## 显式标签编码

把一个合法 seed 写成

\[
L_{\ell,w}
 =
(\operatorname{tag}=\ell,\;w,\;0^{\mathrm{pad}}),
\qquad
\ell\in\{1,\ldots,h+1\},
\quad
w\in\{0,1\}^{2^{\ell}r}.
\tag{6}
\]

式 (2) 保证最高层 payload 仍能放进 q bits。对 \(\ell=1\)，定义

\[
G(L_{1,(a,b)})
 =
E(a)\Vert E(b).
\tag{7}
\]

对 \(\ell\ge2\)，把 \(w=w_0\Vert w_1\) 等长拆分，并定义

\[
G(L_{\ell,w})
 =
L_{\ell-1,w_0}\Vert L_{\ell-1,w_1}.
\tag{8}
\]

非法 tag、过长 payload 或未使用的 seed 统一映到固定 \(2q\)-bit 字符串；该
totalization 不影响合法树。tag 比较、payload 选择和 zero-padding 只需
\(O(q(h+1))\) 个 fan-in-2 gates，式 (7) 的两次 \(E\) 调用贡献 \(O(S_E)\)。

## JK 闭合

对任意叶 tuple

\[
\bigl(B_1,\ldots,B_{2^h}\bigr),
\qquad
B_v=E(a_v)\Vert E(b_v),
\tag{9}
\]

为每个叶 \(B_v\) 选择

\[
u_v=L_{1,(a_v,b_v)}.
\]

相邻两个 \(u_v\) 的串接正是式 (8) 的一个 level-2 output；继续向上递归，level
\(\ell\) 的 parent seed 只需把 \(2^\ell\) 个 base payload 按顺序打包。最高层
payload 长度为 \(2^{h+1}r\)，由式 (2) 可容纳。因此这不是逐 bit 的不一致 witness
拼接，而是一个固定、整词一致的 right inverse：

\[
\operatorname{Rep}(a_1,b_1,\ldots,a_{2^h},b_{2^h})
 =
L_{h+1,(a_1,b_1,\ldots,a_{2^h},b_{2^h})}.
\tag{10}
\]

## 容量是紧的

由 \(E\) 的单射性，叶族的熵为

\[
\log_2|\mathcal A_E|=2r.
\]

所以

\[
2^h\log_2|\mathcal A_E|
 =
2^{h+1}r
 \le q-\tau.
\tag{11}
\]

这正好符合 pair/tree-lift 的必要容量：

\[
|\mathcal A_E|^{2^h}\le 2^q.
\tag{12}
\]

若把 \(r\) 增大到 \(2^{h+1}r>q\)，则不可能同时为所有叶 tuples 提供 q-bit
root seeds；这不是本构造失败，而是 note 105--106 的信息上界。故有限深度
tree closure 的正确资源分配是：

\[
\boxed{\text{每个叶块可用熵 } \le q/2^h,\quad
\text{剩余 bits 用于层级/地址标签。}}
\]

## 对 RW/PCP 路线的接口

若某个 RW systematic history 的所有指定叶块可写成式 (4)，并且共同的 \(E\) 有
\(n^{O(1)}\)-size、P-uniform random-access circuit，而

\[
q=n^{O(1)},\qquad h=O(\log n),
\]

则式 (5)、(10) 给出真正的 \(n^{O(1)}\) whole-tree labeler。若同一 history family
另有

\[
\operatorname{CC}(F_n)>n^{\omega(1)},
\]

则 JK 的 easy branch 会直接矛盾；结合 smart promise 的确定化，这正是 note 121
所需的 \(P\ne NP\) 充分接口。

但 Ren--Williams Theorem 3.5 只给出 Reed--Muller/auxiliary PCP 的 completeness
structure，并没有证明其 contiguous JK 叶块都共享一个满足式 (4) 的低熵 \(E\)。若
叶块携带的独立 line-polynomial information 超过 \(q/2^h\)，式 (12) 已无条件阻止
这种全 tuple closure；若它们低熵，则还需实际构造 \(E\)，不能把低度性本身当作
random-access evaluator。

## 结论边界

\[
\boxed{
\text{tree-compatible closure 本身不是不可能；}
\quad
\text{它要求一个容量紧的共享 leaf evaluator。}
}
\]

本 note 是显式 special-purpose decoder 构造，不是对 unrestricted \(G_q\) 的覆盖结论，
也不声称已证明 \(P\ne NP\)。

来源：note 105--106、123 的 pair/tree capacity 与 history-label 接口；Ren--Williams
Theorems 3.5、4.1（ECCC TR26-118 revision 1）。
