> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Succinct target-binding compiler 的精确复杂度边界（2026-08-16）

## 结论地位

本 note 修正 note 184 中过强的简写。`poly(n)` key 与完整 proof-address evaluator
确实给出强复杂度后果，但后果取决于 verifier 的随机性量词：完美的全随机性语义落在
`Sigma_2^P`，标准常数 soundness 的概率语义一般只给 `NP^PP`；只有随机位数为
`O(log n)` 时才可枚举并降到 `NP`。这里不对这些包含关系作无条件分离声明。

## Succinct target-binding compiler 模型

固定一个语言 `L`。对输入 `x`、长度 `n=|x|`，编译器提供：

* key `s`，长度 `p(n)=poly(n)`；
* proof-address evaluator `E_L(x,s,a)`，输入地址 `a` 长度 `ell(n)=poly(n)`，在
  `poly(n)` 时间输出对应 proof symbol；
* verifier `V_L(x,s;r)`，运行 `poly(n)` 时间，可调用 `E_L` 至多 `poly(n)` 次，随机
  串 `r` 长度 `R(n)=poly(n)`。

“无隐藏 advice”要求 verifier 没有第二个未计入的 proof/key oracle；所有被查询的 proof
位都由 `(x,s,a)` 通过 `E_L` 确定地产生。编译器和 evaluator 对 `L` 统一、P-uniform。

## 定理：两种 soundness 语义的上界

### 完美全随机性语义

若

\[
  x\in L \iff \exists s\in\{0,1\}^{p(n)}\;\forall r\in\{0,1\}^{R(n)}:
  V_L(x,s;r)=1,
\]

则 `L\in Sigma_2^P`。证明只是把 `s` 作为第一层存在量词、`r` 作为第二层全称量词；
`V_L` 的每次 proof 查询由 `E_L` 在多项式时间内展开。

### 标准 bounded-error 语义

若存在固定 gap，例如

\[
\begin{aligned}
 x\in L &\Longrightarrow \exists s\;\Pr_r[V_L(x,s;r)=1]\ge 2/3,\\
 x\notin L &\Longrightarrow \forall s\;\Pr_r[V_L(x,s;r)=1]\le 1/3,
\end{aligned}
\]

则 `L\in NP^{PP}`：猜测 `s`，再用一个 `PP` 查询比较接受随机串的数量是否至少为
`(2/3)2^{R(n)}`。若 `R(n)=O(log n)`，可以枚举所有随机串，因此同一模型降为
`NP`；若 `R=0`，就是普通 `NP` 关系。

## 对普适编译器的含义

若同一个 uniform compiler 对所有 `L\in NEXP` 都提供上述 `poly(n)` key、完整地址
evaluator 和相应语义，则得到：

* 完美全随机性版本：`NEXP\subseteq Sigma_2^P`；
* 一般 bounded-error 版本：`NEXP\subseteq NP^{PP}`；
* `O(log n)` 随机位版本：`NEXP\subseteq NP`。

这些是普适压缩编译器的复杂度后果，而不是已经证明的矛盾；目前不能把
`NEXP\not\subseteq NP^{PP}` 或 `NEXP\not\subseteq Sigma_2^P` 当作已知分离使用。
对单一 RW history 或单一固定实例，这个普适量词不成立，因此不能直接推出
`P\ne NP`。

## 与 ACRR/CC-TP 的关系

这给出一个精确的审查规则：若候选 `CC-TP` 声称 key 长度为 `poly(n,log T)`，且能从
key 随机访问全部 target-binding proof 位，那么必须明确它采用的是哪一种随机性语义，
并报告相应的 `Sigma_2^P`、`NP^PP` 或 `NP` 后果。若候选仍把完整 history、第二个
Merlin strategy 或非均匀 advice 隐藏在 evaluator 中，则不满足本模型，不能调用这些
复杂度边界。

因此正向路线的真实选择是：

1. 给出一个只针对 RW/NP relation 的特殊压缩，且证明它没有偷偷变成普适 NEXP 编译器；或
2. 接受普适版本带来的上述复杂度包含，并把它作为一个独立的 relation-PCP/复杂度结果；或
3. 证明任何满足 ACRR 量词的普适压缩都必须把 key/evaluator 长度提高到 history 尺度。

## 证据边界

量词到 `Sigma_2^P`、`NP^PP` 和低随机性 `NP` 的归类是本 note 的直接复杂度推导；
它不依赖 DGL、DHK 或 RW 的特殊结构，也不声称任何上述复杂度包含已被分离。note 184
中的通信熵下界和 exposed-history 基线仍然有效，但其“`NEXP\subseteq Sigma_2^P`”句子
现在仅保留为本 note 的完美全随机性特例。

## 来源

- [note 184：PCPP+RLDC 变换与 ACRR 通信压缩缺口](184-known-pcpp-rldc-transform-and-acrr-communication-compression-2026-08-16.md)
- [note 182：target-binding relation-PCP 程序](182-target-binding-relation-pcpp-program-2026-08-16.md)
