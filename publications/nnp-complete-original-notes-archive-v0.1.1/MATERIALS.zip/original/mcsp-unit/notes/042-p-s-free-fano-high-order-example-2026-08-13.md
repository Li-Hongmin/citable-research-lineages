> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# (p_s=0) separator 下的 (	au=3) 高阶族（2026-08-13）

## 目的

该构造排除“所有 (p_s=0) witness 自动有二点 cover”的可能性。它不是完整 thinning 反例；精确命中率仍低于 (1/16)。

## 构造

取 (n=5)，spoiler

\[
s=(x_s,y_s)=(0,31),
\]

固定列 (y_0=10)，并取七个行

\[
(x_0,ldots,x_6)=(22,15,6,17,24,1,8).
\]

令 Fano 线集

\[
\mathcal L=\{012,034,056,135,146,236,245\}
\]

（例如 (012) 表示 ({0,1,2})），并定义

\[
T_L=\{(x_i,y_0):i\in L\},\qquad L\in\mathcal L.
\]

七个 (T_L) 两两相交而无公共 cell，故覆盖数为 (	au=3)。

## 可审计的极小性检查

对 (p_s=0) 叶，令

\[
\rho_i=x_i+y_s,qquad \kappa=y_0+y_s.
\]

cell ((x_i,y_0)) 的方程变为

\[
r\cdot\rho_i=0,qquad r\cdot\kappa=1.
\]

所选七个行满足每条 Fano 线

\[
x_i+x_j+x_k=y_s,
\]

等价于 (ho_i+ho_j+ho_k=0)。于是每个三元组的 (p_s=0) 参数系统相容。取值 (y_0=10) 后，对每条线，(kappa) 不在该线三条 (ho) 的张成空间中，故 (p_s=0) 系统确实有解。

在 (p_s=1) 叶，右端切换为

\[
r\cdotho_i=1,qquad r\cdotkappa=0;
\]

由于 (ho_i+ho_j+ho_k=0)，三条行方程右端奇偶矛盾，故 (L(T_L)cap H_s=\varnothing)。逐一删除任意一个 cell 后，加入 spoiler 的 (p_s=1) 系统可解（可直接枚举 (2^5) 个 (r)），所以每个 (T_L) 都是关于 (s) 的 inclusion-minimal collision witness，且其 separator 为 (p_s=0)。

## thinning 质量

逐一枚举 (2^{n+1}=64) 个 ((r,t)) 以及叶内独立行列 (1/2) 抽样，得到

\[
\Pr[\exists L\in\mathcal L:T_L\subseteq R_{r,t}(U,V)]
 =\frac{11}{512}\approx0.021484<\frac1{16}.
\]

其中两个参数叶 ((r,t)=(6,0),(11,1)) 的条件命中率为 (1/4)，其余十四个有效叶各为 (1/16)；所有其余参数叶命中率为零。因而该例同时说明：

1. (p_s=0) 高阶族可有 (	au=3)，不能只用 (	au=2) 覆盖论证；
2. 固定叶的 (1/4) 质量仍会出现；
3. 仅靠 separator 与局部秩界尚不能推出跨参数 (1/16)，但该显式族没有超过目标界。

## 无共同 row/column 的变体

同一 Fano 线模式还可去掉共同列。取 (n=8)、(s=(0,128))，

\[
x=(134,133,131,135,129,130,132),
\qquad
y=(160,224,224,224,224,160,160),
\]

并令 (T_L=\{(x_i,y_i):i\in L\})。此时七个 witness 仍两两相交、无公共 row 或 column，且均为 (p_s=0) 的极小 collision。写

\[
\rho_i=x_i+128=(6,5,3,7,1,2,4),
\qquad
\kappa_i=y_i+128\in\{32,96\}.
\]

每条 Fano 线的 (ho)-和为零，并至少含一对相同 (kappa_i)，因此同样给出 (p_s=0) 相容与 (p_s=1) 奇偶矛盾；逐点删去后加入 spoiler 的系统均可解。取实际 row 集 ({0,129,ldots,135}) 与 column 集 ({128,160,224}) 时，精确 thinning 命中率为 (1/1024)。这只是结构性障碍，不是质量反例。
