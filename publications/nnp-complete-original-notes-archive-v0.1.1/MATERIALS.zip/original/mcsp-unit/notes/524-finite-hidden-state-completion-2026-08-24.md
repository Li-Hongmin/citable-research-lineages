> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Finite hidden-state completion (2026-08-24)

## Proposition 32

Consider the hidden continuation mechanism in Proposition 31. Assume it is a fixed
finite-control machine over a fixed finite alphabet, with a constant number of heads, at most
\(s_H\) contiguous work-tape cells, and at most \(T_H\) transitions. Its initial state is
independent of the unread source, and each transition depends only on the complete current state
and the next scanned source bit. Address domains and scheduler phases have at most
\(\operatorname{poly}(N+T_H)\) possibilities.

Let \(L_H\) be the total information in source-dependent irreversible output, write-only buffers,
or scheduler traces that can still affect future acceptance. Assume that this information is either
included in the hidden state or charged by the model. Then

\[
R\le 2^{O(s_H+L_H+\log(N+T_H))}.
\tag{524.1}
\]

Combining (524.1) with Proposition 31 and using \(T_H\le T\) gives

\[
h+\log W_Q+\log W_D+s_H+L_H+\log(N+T)
=\widetilde\Omega(S).
\tag{524.2}
\]

For fixed-alphabet contiguous source and target tapes, the configuration terms can be replaced by
tape sizes:

\[
h+s_Q+s_D+s_H+L_H+\log(N+T)
=\widetilde\Omega(S).
\tag{524.3}
\]

The bounded-error version requires the local-PRG additive error to satisfy
\[
\varepsilon_Y+\varepsilon_N+\eta_{\mathrm{PRG}}<1
\]
up to the \(o(1)\) probability that a uniform table is a NO instance.

## Proof

Fix a visible record at a source-prefix layer. A hidden complete state is determined by finite
control, the symbols in the \(s_H\) work cells, the constant number of head positions, scheduler
phase, and the charged irreversible information. The tape and control contribution is
\(O(s_H)\) bits. Polynomially many address and phase values contribute
\(O(\log(N+T_H))\) bits, and the charged information contributes \(L_H\) bits. Hence the number
of hidden states compatible with the visible record is at most
\[
2^{O(s_H+L_H+\log(N+T_H))}.
\]
Each hidden state induces at most one future acceptance residual, proving (524.1). Substitution
into Proposition 31 proves (524.2), and the fixed-alphabet configuration count from Corollary 30
proves (524.3).

## Boundary

The term \(L_H\) cannot be omitted. A machine can stream all \(N\) source bits into an uncharged
append-only output tape using \(O(1)\) work cells and \(O(N)\) time. The output history then carries
\(\Theta(N)\) bits and can produce \(R=2^{\Theta(N)}\), even though
\(s_H+\log(N+T_H)=O(\log N)\). If an output or timing trace never affects future acceptance, it need
not be charged for the acceptance-residual version. If full-trace equivalence is required, the
entire required transcript belongs in \(L_H\).

This is a conditional machine-resource boundary. It is not a time lower bound by itself and does
not prove \(P\ne NP\).

## Dependencies

- [Proposition 31](523-hidden-continuation-complexity-boundary-2026-08-24.md)
- [Corollary 30](522-fixed-alphabet-time-space-payload-boundary-2026-08-24.md)
