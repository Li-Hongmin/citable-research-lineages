> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Compatible affine-certificate conjecture

## 1. 语法版的两次失败

[[006-solver-specific-hitting-and-affine-certificate-gap]] 提出的仿射商证书引理，在按
给定语法树计量时不成立。

第一类反例来自不可达分支。令

\[
A_{R,d}
=
\bigvee_{j=1}^{d}(x_1\wedge\neg x_1)
\vee
\bigwedge_{i=1}^{R}x_i.
\]

叶数 \(S=2d+R\)，接受集只有 \(1^R\)，故每个相容 1-certificate 的秩为
\(R\)。但任一语法 0-certificate 必须为每个恒假分支付费：

\[
c_0=d+1.
\]

取 \(d=R^2\)，有

\[
\frac{c_0}{S/R}	o\infty.
\]

因此没有语义正规化时，甚至

\[
c_0=O(S/R)

\]

也为假。

## 2. 删除恒定子树后，常数 1 仍失败

不可达垃圾不是全部原因。在完整仿射空间

\[
W=\mathbb F_2^3
\]

上取变量 \(a,b,c\)，令

\[
A=
[((a\oplus c)\vee c)\wedge\neg b]
\vee
[((a\oplus b)\wedge b)\vee(\neg(a\oplus b)\wedge a)].
\]

逐点化简得

\[
A=a\vee b\vee c.
\]

该表示满足：

\[
S=7,
\qquad
A^{-1}(0)=\{000\};
\]

- 每个自然子树在 \(W\) 上均可取 \(0,1\)；
- 每个叶 occurrence 都会影响根函数；
- 不存在恒定或矛盾子树。

所有相容 1-certificate 的最小秩为

\[
R=2,
\]

而唯一拒绝点的最小语法 0-certificate 大小为

\[
c_0=4.
\]

于是

\[
\boxed{c_0R=8>S=7.}
\]

所以精确的 \(c_0R\le S\) 即使在强 syntactic irredundancy 条件下仍为假。
该反例只给常数比 \(8/7\)，不否定 \(c_0R=O(S)\)。

## 3. 正确的语义对象

对仿射子空间 \(W\subseteq\mathbb F_2^m\) 和函数
\(F:W\to\{0,1\}\)，定义

\[
\kappa_b(F;W)
=
\min_{x\in W:F(x)=b}
\min\{\operatorname{codim}_W(H):
x\in H\subseteq W, F|_H\equiv b\}.
\]

这就是 minimum parity-certificate complexity，而不是通常对输入取 maximum 的
\(C_\oplus(F)\)。再令

\[
L_W(F)
=
\min\{L(A):A\text{ 是 linear-form leaves 上的 De Morgan 公式，且 }A|_W=F\}.
\]

语法垃圾与不可达 profile 已被 \(L_W\) 自动商掉。当前最小候选定理是

\[
\boxed{
L_W(F)
\stackrel?{\ge}
\Omega\bigl(\kappa_0(F;W)\kappa_1(F;W)\bigr).}
\]

在 \(W\) 为独立叶变量的完整立方体时，标准 AND/OR 递推给出常数 \(1\) 的版本。
一般仿射像中，递推失败的唯一位置是 compatibility：两个子公式的最优单色仿射
certificate 可能位于互不相交的 fibers，无法合并。

截至 2026-08-13 的定向检索中，parity certificate complexity 与 parity/subspace
decision tree 已有系统研究，但未找到上述 minimum-certificate product 对
linear-form De Morgan formulas 的定理。该未命中只界定文献检索范围，不构成首创证明。

## 4. 与 MCSP 前沿的关系

若语义乘积下界成立，则 GapMCSP solver 的

\[
\kappa_1\ge N-o(N)
\]

会推出

\[
\kappa_0
\le
O(S/N).
\]

但在 \(S=N^{1.01}\) 时仍只得到 \(N^{0.01+o(1)}\)，不足以进入

\[
a=2^{(\log N)^{1/3}}
\]

的 YES 区。因此该猜想的价值是建立一个新的仿射公式下界工具，而非单独完成
Frontier B。完成主目标还需证明 rejecting-cell family 的全局覆盖提供额外压缩。

~~~mermaid
flowchart LR
    A["给定语法树"] --> J["不可达/冗余分支"]
    J --> X["c0R=O(S) 可失败"]
    A --> M["在 W 上最小化"]
    M --> L["语义复杂度 L_W(F)"]
    L --> C{"L_W ≥ Ω(κ0κ1)?"}
    C -->|"若真"| T["新 affine-formula 工具"]
    C -->|"若假"| R["需无界 compatibility 反例"]
    T --> G["仍需全 rejecting-cell 覆盖增益"]
~~~
