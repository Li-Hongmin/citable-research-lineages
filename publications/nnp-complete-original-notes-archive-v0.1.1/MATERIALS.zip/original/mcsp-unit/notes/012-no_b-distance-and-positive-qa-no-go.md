> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(NO_b\) 距离引理与正势 quasi-additive no-go

## 1. 由完整 \(NO_b\) 语义得到的距离

令输入是真值表 \(z\in\{0,1\}^{N}\)，其中 \(N=2^n\)，并记

\[
E_a=\{x:\operatorname{CC}(x)\le a\},
\qquad
NO_b=\{y:\operatorname{CC}(y)>b\}.
\]

若 \(x\in E_a\)、\(y\in NO_b\)，并令

\[
D=\{u\in\{0,1\}^{n}:x(u)\ne y(u)\},
\qquad t=|D|,
\]

则由 \(x\) 的电路和 \(D\) 的例外位置可以构造 \(y\)：

\[
y(u)=x(u)\oplus\bigvee_{v\in D}[u=v].
\]

每个等式谓词 \([u=v]\) 用 \(O(n)\) 个文字实现，故存在绝对常数 \(c\) 使

\[
\operatorname{CC}(y)\le a+c\cdot t(n+1)+c.
\]

因此

\[
\boxed{
d_H(x,y)>\delta_{a,b}:=
\frac{b-a-c}{c(n+1)}
}
\tag{D}
\]

（取正部）。这一步只使用 \(NO_b\) 的全包含语义，不使用 \(NO_b\) 的密度。

对 Frontier B 的

\[
a=2^{(\log N)^{1/3}},
\qquad
b=2^{(\log N)^{2/3}},
\]

有 \(\delta_{a,b}=N^{o(1)}\)，但仍严格趋于无穷。

## 2. 非负 \((\phi,\psi)\) 的严格上界

考虑 parity-KW 的 quasi-additive LP。若

\[
\phi_c\ge0,
\qquad
\psi_{c,R}\ge0
\quad(\forall c,R),
\]

则可只使用 \(2N\) 个坐标 parity 单色叶。记

\[
R_{j,t}=\{(x,y):x_j=t,\ y_j=1-t\}.
\]

每个 \(R_{j,t}\) 都是合法单色矩形。叶约束给出

\[
\sum_{c\in R_{j,t}}\phi_c\le1,
\]

因为其外部 \(\psi\)-项非负。对 \(t=0,1\) 及 \(j\in[N]\) 求和：

\[
\sum_{c\in X\times Y}d_H(x,y)\phi_c
\le 2N.
\]

应用 (D)，得到

\[
\boxed{
\sum_{c\in E_a\times NO_b}\phi_c
\le \frac{2N}{\delta_{a,b}}.}
\tag{P}
\]

所以所有同时满足 \(\phi,\psi\ge0\) 的“距离势”“电路描述数势”或其非负叠加，都不能达到

\[
N^{1.01}.
\]

若改用全部 affine parity 叶，随机线性型对每个点对被分离的叶数为固定比例；同样的非负求和把上界进一步压到常数。这与 notes 008 的随机 parity 结论一致。

## 3. 剩余的真实承重接口

欲超过 (P)，必须允许某些

\[
\psi_{c,R}<0.
\]

负项不能由汉明距离或单个电路描述直接产生；它必须通过 recursion 约束由低维、低复杂度矩形的正势融资。故下一个最小命题是：

\[
\boxed{
\text{若 }\phi\ge0\text{ 且 }\sum\phi>N^{1.01},
\text{ 则负 }\psi\text{ 是否必编码高阶 affine collision？}}
\]

三点情形的最小 collision 是

\[
x_1\oplus x_2\oplus x_3
=
y_1\oplus y_2\oplus y_3,
\]

它使任意两格可共享一个 parity 叶、三格不能共享一个叶。Ueno 的 triplet argument 正是利用这种三格模式产生负的外部 \(\psi\)；但若每个 triplet 独立，单色矩形可对每个 triplet 只取一格，扰动不累积。因此必须利用 \(NO_b\) 语义构造跨 triplet 的 circuit-description/collision 设计，而不是简单的三元组打包。

## 4. 结论

已严格关闭：

\[
\text{“}NO_b\text{ 的距离/密度语义”}
\Longrightarrow
\text{非负 quasi-additive 超线性证书}.
\]

未关闭：带负递归融资的语义势；它是唯一仍可能把 \(E_a\times NO_b\) 推到 \(N^{1.01}\) 的 LP 接口。

原始方法参照：Ueno, *Breaking the Rectangle Bound Barrier against Formula Size Lower Bounds*, MFCS 2010, Secs. 4 and 6; Hrubeš--Jukna--Kulikov--Pudlák, *On Convex Complexity Measures*, TCS 2010, Sec. 5.
