> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 双侧全局基数势的 mixed-subrectangle 线性 no-go（2026-08-13）

## 候选

令

\[
m=3k-1,
\qquad n=3\ell-1,
\qquad k,ell\ge2,
\]

并定义

\[
g(a)=a-\frac m2\left\lfloor\frac ak\right\rfloor,
\qquad
h(b)=b-\frac n2\left\lfloor\frac b\ell\right\rfloor.
\]

则 (g,h) 次可加，且

\[
g(0)=g(m)=0,
\qquad h(0)=h(n)=0,
\qquad g(m-a)=-g(a),
\qquad h(n-b)=-h(b).
\]

考虑双侧势

\[
K(A\times B)=\lambda\,[g(|A|)|B|+|A|h(|B|)].
\tag{1}
\]

横切时第一项次可加、第二项可加；纵切时相反，所以 (1) 满足 QA recursion，根值为零。

## mixed-subrectangle 叶约束

设 (R=A\times B) 是任意最大 affine-parity 叶，(a=|A|,b=|B|)。所有 (R'subseteq R) 的矩形也都是合法叶。

若 (a\ge k)，固定 (y\in B)，对所有 (|A'|=k) 的子集 (A'\subseteq A) 平均叶约束。因为 (h(1)=1)、(g(k)=-(k-1)/2)，每个 (A'\times\{y}) 的势为

\[
P_k=\lambda\bigl(g(k)+kh(1)\bigr)=\lambda\frac{k+1}{2}.
\]

故

\[
\Phi(A\times\{y\})
\le \frac ak(1-P_k),
\]

其中 (Phi(S)=\sum_{c\in S}\phi_c)。置

\[
r_k=(1-P_k)_+,
\]

并对 (y\in B) 求和：

\[
\Phi(R)\le \frac{ab}{k}r_k.
\tag{2}
\]

同理，若 (b\ge\ell)，取 ({x}\times B')（(|B'|=\ell)），得

\[
\Phi(R)\le \frac{ab}{\ell}r_\ell,
\qquad
r_\ell=\left(1-\lambda\frac{\ell+1}{2}\right)_+.
\tag{3}

若 (a<k,b<\ell)，则 (g(a)=a,h(b)=b)，直接使用 (R) 本身的叶约束：

\[
\Phi(R)+2\lambda ab\le1
\quad\Longrightarrow\quad
\Phi(R)\le1.
\tag{4}

以上均允许 (phi) 有符号。

## 每个最大叶的线性容量

由 (m<3k,n<3\ell)，分四类：

\[
\begin{array}{c|c}
\text{叶尺寸}&\text{上界}\\ \hline
a\ge k, b<\ell & \Phi(R)<3\ell \\ 
a<k, b\ge\ell & \Phi(R)<3k \\ 
a\ge k, b\ge\ell & \displaystyle
\Phi(R)\le ab\min\left(\frac1k,\frac1\ell\right)
<9\min(k,\ell)\\
a<k, b<\ell & \Phi(R)\le1
\end{array}
\tag{5}
\]

因此对所有 (lambda\ge0)，所有最大 affine 叶均满足

\[
\Phi(R)\le 9\max(k,\ell).
\tag{6}
\]

对均匀随机 ((r,b,t))，每个 cell ((x,y))（(x\ne y)）被最大叶

\[
R_{r,b,t}=(X\cap\ell^{-1}(t))
\times(Y\cap\ell^{-1}(1-t))
\]

命中的概率为 (1/4)。对 (6) 取平均，得到

\[
\boxed{
\sum_{c\in X\times Y}\phi_c
\le36\max(k,\ell).
}
\tag{7}
\]

若 (k,\ell=O(N))，这至多线性，不能达到 (N^{1+\delta})。

当 (lambda\ge2/\min(k+1,\ell+1)) 时 (r_k=r_\ell=0)，(5) 实际给出每最大叶 (Phi(R)\le1)，从而 (sumphi\le4)。但 (7) 已对任意 (lambda) 成立。

## 决策

双侧 anti-thinning 候选仍然是合法的递归势，但 mixed-subrectangle 叶容量把它限制为 (O(k+\ell))。因此它不是 (N^{1+\delta}) 的突破口；若要继续，必须让正的 mixed 子叶势不再可由固定 (k\times1)、(1\times\ell) 归一化捕获。

