> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK failure frontier 的 canonical-selector 修正（2026-08-19）

## 本轮改变的判断

note 420 的 frontier-to-parent barrier 把 canonical inverse 写成了

\[
p(G(s))=s\qquad(s\in\{0,1\}^k),
\tag{493.1}
\]

这会错误地要求 \(G\) 单射；Ren--Williams 的 AVOID generator 一般没有这个
假设。实际 JK 过程只选取 range block 的一个 canonical preimage（原文为
lexicographically smallest preimage），所以所需且总能满足的条件是

\[
p:R=\operatorname{Range}(G)\to\{0,1\}^k,
\qquad G(p(z))=z\quad(z\in R).
\tag{493.2}
\]

在 (493.2) 下，note 420 的 terminal decomposition、frontier 计数和
forcing-scale 结论全部成立。因此该 barrier 确实适用于非单射的 published JK
generator；不需要撤回 C420，只需把其适用假设降到 canonical right inverse。

## 修正后的定理

令 \(G:\{0,1\}^k\to\{0,1\}^{2k}\)，\(R=\operatorname{Range}(G)\)，并固定任意
selector \(p\) 满足 (493.2)。把补零后的 proof 切成 \(2k\)-bit 叶块。对一个
internal node \(v\)，若两个 child block 已定义且属于 \(R\)，定义

\[
z_v:=p(z_{v0})\Vert p(z_{v1}).
\tag{493.3}
\]

若 \(z_v\in R\)，称 \(v\) good；否则称其为 bad defined node；至少一个 child
未定义时称 \(v\) undefined。令 \(\mathcal F\) 为 bad leaves 与 bad defined
internal nodes 的并，令 \(\mathcal T\) 为从 root 递归展开非-good nodes 所得
terminal 集。

若高度为 \(H\)，则

\[
|\mathcal T|\le 1+2H|\mathcal F|.
\tag{493.4}
\]

对任意 proof prefix \(B\)，存在以地址为输入的 Boolean circuit \(C_B\)，满足

\[
\operatorname{CC}(B)
\le
O\!\left(|\mathcal T|\bigl(H(|G|+k+\log(L+2))+k+\log(L+2)\bigr)\right),
\tag{493.5}
\]

从而得到 note 420 的

\[
\operatorname{CC}(B)
\le O\!\left(HC_G(1+H|\mathcal F|)\right),
\qquad
C_G:=|G|+k+\lceil\log_2(L+2)\rceil.
\tag{493.6}
\]

特别地，在 forcing regime 中，若右端的 \(O(HC_G)\) 基础项为低阶，则

\[
|\mathcal F|=\Omega\!\left(\frac{\operatorname{CC}(B)}{H^2C_G}\right).
\tag{493.7}
\]

## 证明中唯一需要改写的步骤

若 \(v\) good，令 \(s_v=p(z_v)\)。由 (493.3) 有

\[
\operatorname{half}_\epsilon(s_v)=p(z_{v\epsilon}),
\qquad \epsilon\in\{0,1\}.
\]

因此由 (493.2)

\[
G(\operatorname{half}_\epsilon(s_v))
=G(p(z_{v\epsilon}))
=z_{v\epsilon}.
\tag{493.8}
\]

这正是 note 420 的 good-subtree expansion (420.5)。后续 terminal evaluator 只需
把每个 good terminal 的 \(s_v\) 作为常数，先计算 \(G(s_v)=z_v\)，再沿

\[
L_0(z)=G(\operatorname{left}_k z),
\qquad
L_1(z)=G(\operatorname{right}_k z)
\]

逐层生成叶块；整个过程从未使用 \(p(G(s))=s\) 对任意 seed \(s\) 成立。坏叶
直接 hardwire 其 \(2k\)-bit payload，terminal count 与 (493.4) 不变，故 (493.5)--
(493.7) 成立。

## 对 published JK 的含义

Ren--Williams Theorem 3.1 对每个 range block 选择 lexicographically smallest
preimage，正好给出一个满足 (493.2) 的 \(p\)。因此 C420 的 frontier barrier
可以用于任意（包括非单射）published generator。这个修正只扩大适用范围，不把
JK 的首个实际 outsider 误说成已经暴露了完整 frontier；C420/C488 的
“反事实 frontier”与“实际 query 数”区别仍然保留。

修正后的 source-level 三分不变：

1. frontier 足够稀疏时支付 (493.6) 的 parent evaluator；
2. frontier 达到 forcing scale 时支付 object-scale support；或
3. 提出不能展开为上述 canonical half-lift 的、被完整计价的 non-half-lift global
   relation。

## 证据边界

* 本 note 修正的是 C420 的 generator-injectivity 量词，不改变其 terminal-count
  或 circuit-cost 结论。
* \(p\) 可以是任意固定 canonical selector；无需有效计算，因为 terminal seeds
  已作为同一 fixed proof 的被计价常数输入。若 selector/seed 未计价，则进入
  descriptor/ROM model-exit，而不是反驳 (493.6)。
* 该结果仍是 fixed-proof、source-specific barrier；不证明 published RW 已有
  whole-parent attachment，也不证明 (P\ne NP) 或一般 dPCP/RLDC 不可能性。

## 来源

* [C420 / note 420](420-rw-full-jk-frontier-parent-binding-2026-08-19.md)：原
  frontier decomposition 与成本证明；本 note 仅替换其过强的 (420.2)。
* Ren--Williams TR26-118 revision 1, Theorem 3.1：逐 range block 选择
  lexicographically smallest preimage。
* [C488](488-jk-first-failure-frontier-support-bound-2026-08-19.md)：实际 JK
  首失败层的独立 frontier-support 结论。
