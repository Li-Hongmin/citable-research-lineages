> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Trimmed-incidence profile gives a full-proof RLDC (2026-08-17)

## Contribution

The heavy-core note 223 punctures a concentrated proof core and pays a completeness
loss. There is a stronger alternative for the same hypotheses: keep the entire proof,
retain perfect completeness, and charge the corruption probability to a single
trimmed-incidence functional. This removes the outside-disagreement assumption
\(\delta_K>0\) and is useful precisely in the highly nonuniform regime.

The resulting theorem is still a conditional family-level statement. It does not claim
that a current dPCP construction supplies the outer smoothness hypothesis or the RW
address-scale evaluator. It says that once those hypotheses are present, arbitrary
incidence profiles cannot evade the RLDC barrier by hiding behind a small set of heavy
vertices.

## Setup

Let

\[
  C:\{0,1\}^{k}\longrightarrow \Gamma^{M}
\]

be an injective code of relative distance at least \(\Delta>0\). Let one common proof
space \(V\) have alphabet \(\Sigma\). For each outer coordinate \(t\in[M]\), a local
dPCP decoder samples an edge \(e\) from \(\mathcal P_t\), reads at most \(q_P\) proof
positions, and outputs a symbol in \(\Gamma\). For every message \(m\), fix one
perfect-completeness assignment \(A_m\in\Sigma^V\) such that

\[
  D_t(A_m|_e)=C(m)_t
  \qquad(e\sim\mathcal P_t)\text{ almost surely}.
\tag{224.1}
\]

Let \(\mathcal Q\) choose \(t\) uniformly and then \(e\sim\mathcal P_t\), and write

\[
  \mu_v:=\Pr_{(t,e)\sim\mathcal Q}[v\in e],
  \qquad
  \mu(S):=\sum_{v\in S}\mu_v.
\tag{224.2}
\]

For the outer message decoder \(\mathsf{Dec}_i\), assume exact-codeword safety, meaning
that when every local answer equals the answer induced by \(A_m\), the decoder never
outputs a wrong symbol. Also assume the following honest-path domination. At each of its
at most \(q_D\) adaptive steps, after
all preceding local answers are honest,

\[
  \Pr[v\in e\mid\text{preceding answers honest}]
  \le \lambda\mu_v
  \qquad(v\in V).
\tag{224.3}
\]

No uniformity of \(\mu\) is assumed. The edge support is publicly determined before its
proof symbols are read, so an implementation may detect which positions a sampled edge
would touch.

## The trimmed-incidence functional

For a core \(K\subseteq V\), put

\[
  \kappa(K):=\mu(K),
  \qquad
  \tau(K):=\max_{v\in V\setminus K}\mu_v,
\tag{224.4}
\]

with \(\tau(V):=0\). For a relative corruption radius \(\rho\), define

\[
  \mathfrak R_\rho(\mu)
  :=
  \min_{K\subseteq V}
  \left(\kappa(K)+\rho |V|\,\tau(K)\right).
\tag{224.5}
\]

Equivalently, after sorting
\(\mu_{(1)}\ge\cdots\ge\mu_{|V|}\), it is enough to minimize over threshold
cores \(K_r=\{v:\mu_v\ge\mu_{(r)}\}\), with the usual tie convention:

\[
  \mathfrak R_\rho(\mu)
  =
  \min_{0\le r\le |V|}
  \left(\sum_{j\le r}\mu_{(j)}
  +\rho |V|\mu_{(r+1)}\right),
  \qquad \mu_{(|V|+1)}:=0.
\tag{224.6}
\]

The threshold form follows because, for a fixed outside maximum, including any position
above that maximum in the core is mandatory, while including a lower position only
increases the objective.

## Theorem (full-proof incidence closure)

Under (224.1)--(224.3), the proof map

\[
  \Pi(m):=A_m\in\Sigma^V
\]

is a weak adaptive

\[
  (q_Pq_D,\rho,1,s_\rho)\text{-RLDC},
  \qquad
  s_\rho\le q_D\lambda\,\mathfrak R_\rho(\mu).
\tag{224.7}
\]

In particular, for every chosen core \(K\),

\[
  s_\rho\le q_D\lambda
  \left(\mu(K)+\rho|V|\max_{v\notin K}\mu_v\right).
\tag{224.8}
\]

If the target family has at least two messages, (224.1) and the distance of \(C\) also
imply

\[
  \mu(D_{m,m'})\ge\Delta
  \quad\text{for }m\ne m',
  \qquad
  D_{m,m'}:=\{v:A_m(v)\ne A_{m'}(v)\},
\tag{224.9}
\]

so \(\Pi\) is injective. Thus the RLDC is a genuine code on the same proof address
space, not merely a decoder for one selected history.

## Proof

Fix \(m\), coordinate \(i\), and a received word \(z\) with
\(\operatorname{dist}(z,A_m)\le\rho\). Let

\[
  B:=\{v:z_v\ne A_m(v)\},
  \qquad |B|\le\rho|V|.
\]

Run the outer decoder and all dPCP local calls on \(z\), without aborting. On an honest
query step, (224.3) and a union bound give

\[
  \Pr[e\cap B\ne\varnothing
       \mid\text{preceding answers honest}]
  \le \lambda\mu(B).
\tag{224.10}
\]

If no queried edge meets \(B\), every local dPCP answer is exactly the answer on \(A_m\).
The outer decoder therefore follows its honest transcript and exact-codeword safety makes
it output \(m_i\), never a wrong symbol. A union bound over at most \(q_D\) adaptive steps
gives

\[
  \Pr[\text{wrong output}]
  \le q_D\lambda\mu(B).
\tag{224.11}
\]

For every core \(K\),

\[
  \mu(B)
  \le \mu(B\cap K)+\mu(B\setminus K)
  \le \mu(K)+|B|\tau(K)
  \le \kappa(K)+\rho|V|\tau(K).
\tag{224.12}
\]

Minimizing over \(K\) proves (224.7)--(224.8). On the uncorrupted proof \(z=A_m\),
every local answer is honest, so exact-codeword safety gives perfect completeness.

For (224.9), let \(S=\{t:C(m)_t\ne C(m')_t\}\). Its relative size is at least
\(\Delta\). For every \(t\in S\), an edge on which \(A_m\) and \(A_{m'}\) agree would
force the same local decoder distribution to output two different symbols with
probability one, contradicting (224.1). Hence the complete-decoding experiment hits
\(D_{m,m'}\) with probability at least \(\Delta\). The event is contained in the union
of vertex events \(v\in e\), giving (224.9). \(\square\)

## Consequences

### 1. Uniform incidence is only the zero-core choice

If \(\mu_v\le\chi/|V|\) for all \(v\), take \(K=\varnothing\). Then

\[
  s_\rho\le q_D\lambda\chi\rho.
\tag{224.13}
\]

This recovers the standard incidence-stable field-lift estimate, but (224.5) also
handles profiles with a small number of very heavy vertices.

### 2. Heavy mass versus residual smoothness

For \(K_\theta=\{v:\mu_v>\theta\}\),

\[
  |K_\theta|<q_P/\theta,
  \qquad
  \tau(K_\theta)\le\theta,
\]

and therefore

\[
  s_\rho
  \le q_D\lambda\bigl(\mu(K_\theta)+\rho|V|\theta\bigr).
\tag{224.14}
\]

Thus every nonuniform profile has a numerical tradeoff: reducing the residual
smoothness term costs the complete-decoding mass of the retained core. If that mass is
small enough for an external RLDC theorem, the full proof is already in the coding
barrier; if it is not, the construction has exposed a quantitatively large heavy channel.

### 3. Low-soundness upgrade

In the binary case, set \(Q=q_Pq_D\). If

\[
  q_D\lambda\,\mathfrak R_\rho(\mu)
  \le 2^{-Q}/2,
\tag{224.15}
\]

then the recent Cheng--Li--Mao low-soundness transformation applies to the
perfect-complete \(Q\)-query RLDC and yields a \(Q\)-query ordinary LDC at a smaller
positive radius. Their Corollary 1.7 consequently gives, for constant \(Q\) and
constant radius,

\[
  k\le O\!\left(|V|^{1-2/Q}\log |V|\right).
\tag{224.16}
\]

The precise radius after the transformation is the one supplied by their theorem; the
point here is that no uniform-marginal or linearity assumption is needed once (224.15)
holds.

For larger soundness, (224.7) still gives whichever general RLDC lower bound is valid in
the parameter window. The theorem does not silently replace a constant-soundness
RLDC by an LDC.

## Relation to the heavy-core/punctured theorem

The punctured theorem in note 223 can be stronger when one wants to discard a core and
retain a large radius: it removes the \(\mu(K)\) term from soundness at the price of
completeness and an outside-distance condition. The present theorem is stronger for
perfect-completeness and low-soundness barriers: it keeps all core symbols and needs only
the trimmed profile \(\mathfrak R_\rho(\mu)\). The two statements should be used together:

* a core with \(\mu(V\setminus K)<\Delta\) is an injective message channel of size at
  least \(k/\log_2|\Sigma|\);
* otherwise, whenever (224.15) or another RLDC lower-bound window holds, the full proof
  itself is the obstructed RLDC.

This is a quantitative closure of the nonuniform-incidence gate, not a claim that
GMWZ's published dPCP theorem supplies (224.3), the output code family, or the RW
address-scale reconstruction.

## Sources

* [GMWZ Theorem 3.12](https://arxiv.org/html/2512.12960), for the dPCP interface.
* [Cheng--Li--Mao, Theorem 1.4 and Corollary 1.7](https://arxiv.org/html/2603.03717),
  for the nonlinear low-soundness RLDC-to-LDC step and lower bound.
* [Heavy-core incidence dichotomy](223-heavy-core-incidence-dichotomy-for-shared-proof-robustness-2026-08-17.md),
  for the complementary punctured branch.
