> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Vanishing branch-gap versus locality: a quantitative phase boundary (2026-08-17)

## Contribution

Notes 243--244 close every fixed positive branch gap. The same mechanism gives a
more informative parameterized statement when the gap is allowed to shrink with
the message length. Let
\[
  \gamma_k:=\alpha_k-\beta_k>0
\]
be the correct-versus-wrong branch gap at length \(k\). A near-linear family
cannot make both locality and gap too small: the necessary budget is
\[
  \frac{r(k)}{\gamma_k^2}
  =\Omega\!\left(\log\log k\right),
\]
more precisely with the threshold correction
\(\log_2\log k-\log_2\log\log k-O_{\rho,c}(1)\).
Equivalently, for fixed branch locality, the gap must vanish at least on the
\(1/\sqrt{\log\log k}\) scale before this barrier stops applying.

This is a phase-boundary statement, not a construction at the boundary.

## Theorem

Fix \(0<\rho<1\) and \(c>0\). At each length \(k\), let
\(\Pi_k:\{0,1\}^k\to\{0,1\}^{P_k}\) be a binary proof map and let the two
branch verifiers have locality \(r(k)\). Assume the target-relative hypotheses
of note 243 hold with parameters \(\alpha_k,\beta_k\), uniformly over every
message and coordinate, with
\[
  \gamma_k:=\alpha_k-\beta_k>0.
\]
Assume branch acceptance events can be independently re-sampled.

If
\[
  N_k:=k+P_k\le k(\log k)^c
\tag{245.1}
\]
for infinitely many sufficiently large \(k\), then
\[
  \frac{r(k)}{\gamma_k^2}
  =\Omega_{\rho,c}\!\left(\log\log k\right).
\tag{245.2}
\]
In particular,
\[
  \gamma_k
  =O_{\rho,c}\!\left(
    \sqrt{\frac{r(k)}{\log\log k}}
  \right)
\tag{245.3}
\]
is necessary for any near-linear family.

## Proof

### 1. Gap amplification

Let \(t_k\) be the smallest repetition count for which an empirical threshold
between \(\beta_k\) and \(\alpha_k\) has both tails at most \(1/3\). A standard
Chernoff bound gives
\[
  t_k\le C\,\gamma_k^{-2}
\tag{245.4}
\]
for an absolute constant \(C\), after handling the integer threshold by increasing
\(C\) once.

The threshold inline decoder from note 243 is therefore a binary adaptive RLDC with
completeness at least \(2/3\), wrong-output probability at most \(1/3\), constant
radius \(\delta_0(\rho)\), and locality
\[
  r'_k=t_k r(k).
\tag{245.5}
\]

### 2. Decision-tree query count

Expose the two adaptive branch trees after fixing the random tape. The inline query plus
the union of the two depth-\(r'_k\) binary trees has size
\[
  Q_k:=1+2(2^{r'_k}-1).
\tag{245.6}
\]
This gives a non-adaptive binary \((Q_k,\delta_0,2/3,1/3)\)-RLDC whenever
\(Q_k\le N_k\).

If \(Q_k>N_k\), then \(2^{r'_k}=\Omega(N_k)\ge\Omega(k)\), so
\(r'_k=\Omega(\log k)\), which is already stronger than the desired lower bound.

### 3. GGS threshold

Assume \(Q_k\le N_k\). Put \(g_k=\log k/\log\log k\). If
\(Q_k\le\eta g_k\) for a sufficiently small constant
\(\eta=\eta(\rho,c)>0\), then \(N_k\ge k\) implies
\[
  N_k^{-(2/3)/(2Q_k)}
  \le
  \exp\!\left(-\frac{(2/3)\log k}{2\eta g_k}\right)
  =
  (\log k)^{-1/(3\eta)}
  <\delta_0
\]
for all large \(k\). Thus the radius condition of the GGS theorem is valid.

Applying its arbitrary-code non-adaptive RLDC bound with
\(\sigma=2/3\) gives
\[
  N_k\ge
  \left(
    \frac{(2/3)^2 k}
    {38Q_k^4\log^2 2\,\log^2 k}
  \right)^{1+1/\lceil 3Q_k/2\rceil}.
\tag{245.7}
\]
Taking logarithms and using \(N_k\le k(\log k)^c\) yields the same
constant contradiction as in note 242: for sufficiently small \(\eta\),
the left side contributes \(\Omega(\log\log k)\) through
\(\log k/\lceil3Q_k/2\rceil\), while the right side contributes only
\(O_{c,\rho}(\log\log k)\). Hence
\[
  Q_k=\Omega_{\rho,c}(g_k).
\tag{245.8}
\]
By (245.6),
\[
  r'_k
  \ge
  \log_2\log k-\log_2\log\log k-O_{\rho,c}(1).
\tag{245.9}
\]
Finally, (245.4)--(245.5) imply
\[
  \frac{r(k)}{\gamma_k^2}
  \ge
  \frac{r'_k}{C}
  =
  \Omega_{\rho,c}\!\left(\log\log k\right),
\]
which proves (245.2).
\(\square\)

## Interpretation

* Fixed \(r\) and fixed positive gap are impossible, recovering notes 243--244.
* Fixed \(r\) can only survive if \(\gamma_k\lesssim1/\sqrt{\log\log k}\), and
  this is merely necessary, not sufficient.
* A constant gap allows \(r(k)\) only at the \(\log\log k\) threshold.
* The theorem does not claim a construction for any of these boundary profiles.

Thus the remaining branch-gap escape is quantitatively narrow: it must pay either
vanishing robustness or growing locality.

## Scope and non-claims

The statement is binary, target-relative, family-level, and assumes independent
re-sampling of each branch verifier. It does not cover \(\gamma_k=0\), growing
alphabets, ordinary average/list soundness, or correlated randomness that prevents
the threshold amplification. It is an application of the existing GGS RLDC lower
bound, not a new coding lower-bound proof.

## Sources

* [note 243](243-imperfect-completeness-gap-closure-by-amplified-rldc-2026-08-17.md)
  for the imperfect-completeness amplification.
* [note 244](244-imperfect-completeness-growing-locality-threshold-2026-08-17.md)
  for the fixed-gap growing-locality calculation.
* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for Relaxed
  Locally Decodable Codes via Robust Daisies*, arXiv:2511.21659, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.
