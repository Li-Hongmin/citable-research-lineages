> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# History-indexed closure decoder：把相关 JK tree 保持在 range 内（2026-08-15）

## 定理

这个 note 给出一个非通用、但完全显式的正向模板：若 RW history 的 leaf blocks
有共同的 multi-output evaluator，可以把节点标签编码进 seed，使相关 JK tree
逐层保持在 decoder range 内。

固定深度 \(h\)、seed length \(q\)，以及 leaf blocks
\[
B_{x,v}\in\{0,1\}^{2q},
\qquad x\in\{0,1\}^{n},\quad v\in\{0,1\}^{h}.
\tag{1}
\]
假设 labels
\[
\lambda=(x,v,\ell,\tau),\qquad
\ell\in\{0,\ldots,h\},\quad
\tau\in\{\mathrm{leaf},\mathrm{internal}\}
\]
有一个 packed encoding \(\iota(\lambda)\in\{0,1\}^{q}\)，其中
\(q\ge n+h+O(1)\)，且 child-label 的编码可以由当前 label 的字段用
\(O(q)\) 大小电路产生。

再假设存在共同的 leaf-block circuit
\[
\mathcal E_n(x,v)=B_{x,v}\in\{0,1\}^{2q},
\qquad
|\mathcal E_n|=S_{\mathrm{leaf}}(n,q,h).
\tag{2}
\]
\(\mathcal E_n\) 对所有 \(x,v\) 共同有效；不是每个 history 单独硬接一个电路。

则存在 decoder
\[
G_{n,q}:\{0,1\}^{q}\to\{0,1\}^{2q}
\tag{3}
\]
满足
\[
|G_{n,q}|
\le
S_{\mathrm{leaf}}(n,q,h)+O(q\operatorname{polylog}q).
\tag{4}
\]

对 leaf label \(\lambda=(x,v,h,\mathrm{leaf})\)，定义
\[
G_{n,q}(\iota(\lambda))=B_{x,v}.
\tag{5}
\]
对 internal label \(\lambda=(x,v,\ell,\mathrm{internal})\)，定义
\[
G_{n,q}(\iota(\lambda))
=\iota(x,v0,\ell+1,\tau_0)
\Vert
\iota(x,v1,\ell+1,\tau_1),
\tag{6}
\]
其中 \(\tau_0,\tau_1\) 按下一层是 leaf 还是 internal 固定。未使用 seeds 任意
totalize，例如输出 \(0^{2q}\)。

## 证明

对每个固定 \(x\)，令底层 leaf string 为
\[
F_x=\mathop{\Vert}_{v\in\{0,1\}^{h}}B_{x,v}.
\tag{7}
\]
每个 leaf block 的 preimage 是 \(\iota(x,v,h,\mathrm{leaf})\)。若相邻 children
的 preimages 是
\[
u_0=\iota(x,v0,\ell+1,\tau_0),\qquad
u_1=\iota(x,v1,\ell+1,\tau_1),
\]
则 parent block 是 \(u_0\Vert u_1\)，正好等于式 (6) 的某个 decoder output。
对 \(\ell=h-1,\ldots,0\) 归纳，得到
\[
F_x\in\operatorname{Range}(\operatorname{BExp}_{G_{n,q},h}).
\tag{8}
\]

若 JK easy reconstruction 使用这个显式 label selector，则 root label
\(\iota(x,0,0,\mathrm{internal})\) 可 hardwire；按 \(G\) 的 left/right output
branch 逐层读取任意 leaf，得到
\[
\operatorname{CC}(F_x)
\le
O\!\left((|G_{n,q}|+q)h\right).
\tag{9}
\]
这只使用合法 preimages 的串接，不使用 lex-first 性质。

## 规模与硬度接口

若 \(q=n^{O(1)}\)、\(h=O(\log n)\)，且
\[
S_{\mathrm{leaf}}(n,q,h)=n^{O(1)},
\tag{10}
\]
则式 (4) 和 (9) 都是 \(n^{O(1)}\)。若同一个 \(F_x\) family 另有
\[
\operatorname{CC}(F_x)>n^{\omega(1)},
\tag{11}
\]
则式 (8)--(9) 直接矛盾。这是一个真正足以承载 \(P\) vs \(NP\) 反证的
special-purpose decoder route。

该模板的成本不能被隐藏：若 leaf label 子域在 \(G_{n,q}\) 中实现式 (2)，固定
\((x,v)\) 后，\(G\) 的相应 output coordinates 就计算 \(B_{x,v}\)。因此
\[
|G_{n,q}|\ge S_{\mathrm{leaf}}(n,q,h)-O(q).
\tag{12}
\]
decoder 不能比共同 leaf evaluator 神奇地更小。

## 与 canonical JK 的关系

上面的闭合对指定 label selector 成立。published JK 若改用 lex-first preimage，
可能选择另一个 seed，使下一层不再是式 (6) 的 label-concatenation。choice-robust
JK 的准确含义是：

- 显式 label selector 仍给出正确 easy reconstruction；
- lex-first 产生 non-range parent 时，该 parent 是合法 hard outsider；
- 但如何在 address scale 输出该 outsider，仍需 Local-JK/smart reconstruction。

因此本定理是存在性/构造性 closure lemma，不是对 published lex-history 的自动替换。

## 当前 RW 路线的精确缺口

对 RW stitched history，式 (2) 要同时对所有 input \(x\) 和所有 leaf addresses
\(v\) 生成完整 \(2q\)-bit block。已有 tableau argument 通常只给出
\[
\text{单 bit 时间 }R(n)
\quad\Longrightarrow\quad
\text{multi-output circuit 大小按 }qR(n)\text{ 或 }R(n)^2\text{ 计}.
\tag{13}
\]
当 \(q=n^{k(n)+O(1)}\) 且 \(R(n)\) 随 \(k(n)\) 超多项式增长时，式 (4) 不再是
\(n^{O(1)}\)。因此正向目标被精确化为
\[
\boxed{\text{构造 RW-specific }\mathcal E_n\text{，而不是 generic batch decoder。}}
\tag{14}
\]

要把本模板真正插入 RW theorem，还必须要求
\(\{G_{n,q}\}\) 能由 \(n\)（以及固定的 SAT machine \(A\)）P-uniform 构造；
“对每个 \(n\) 存在一个 history-specific decoder”本身不提供 uniformity。

## 来源与边界

- Jeřábek--Korten/GGM easy reconstruction：任意合法 preimages 的串接即可形成
  parent；choice-robust 版本见 note 083。
- Ren--Williams Theorem 3.1/4.1：
  [official report](https://eccc.weizmann.ac.il/report/2026/118/revision/1/download)。
- 式 (4)--(14) 是本项目对 history-indexed decoder 的自足构造与规模推导。

本 note 不给 generic \(q\to2q\) decoder，也不声称无条件证明 \(P\ne NP\)；它提供一个
可检验的 special-purpose positive interface。
