> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Finite-randomness completeness repair for selected-policy RLDC lifts（2026-08-19）

## 本轮改变的判断

note 271 与 Paper 05 Theorem 4.3 在一般
\(\alpha>\beta\) 时只得到 imperfect-complete semantic RLDC，因此不能直接调用
要求 perfect completeness 的 GGS/Block 下界。这里补上一个明确的、有限资源版本：
若 selected policy 的全部 verifier randomness 由至多 \(r\) 个 public bits 给出，且
proof alphabet 有限，那么可以枚举所有随机带和有限 proof-answer 决策树，精确计算
每个 claim branch 的接受率。这样不需要重复采样，也不需要假设
\(\alpha=1\)，便可恢复 perfect-complete nonadaptive RLDC；代价是 locality
\(2^r\) 乘以决策树规模。

这不是对任意 randomized selected-policy semantics 的无条件修复：隐藏的、未计价的
随机性或无限响应字母仍在本定理边界之外。它把 completeness gap 精确转化为一个
可核验的 public-randomness/locality 代价。

## 定理 467.1（finite-randomness completeness repair）

令
\[
  \Pi:\{0,1\}^k\longrightarrow\Sigma^P,
  \qquad |\Sigma|=A\ge2,
\]
并为每个 target \(m\) 与 coordinate \(i\) 选择一个 deterministic selected
policy \(\tau_{m,i}\)。令
\[
  S(m)=(\tau_{m,1},\ldots,\tau_{m,k}),
  \qquad F_s=\{m:S(m)=s\}.
\]

假设每个 fixed policy/claim branch：

* 使用至多 \(r\) 个 public-random bits；
* 至多查询 \(q\) 个 proof symbols，并可自适应地选择后续地址；
* 对某些常数 \(\alpha>\beta\) 和 \(0<\rho<1\)，满足
  \[
    \Pr[V_{i,m_i}^{\tau_{m,i}}(\Pi(m))=1]\ge\alpha,
    \tag{467.1}
  \]
  \[
    d_H(z,\Pi(m))\le\rho P
    \Longrightarrow
    \Pr[V_{i,1-m_i}^{\tau_{m,i}}(z)=1]\le\beta.
    \tag{467.2}
  \]

若一个 fiber \(F_s\) shattered 了 coordinate set \(I\) 且 \(|I|=d\)，则存在
一个 binary-message inline code
\[
  C_s:\{0,1\}^d\to\widehat\Sigma^{d+P},
  \qquad \widehat\Sigma=\Sigma\sqcup\{(I,0),(I,1)\},
\]
以及一个 perfect-complete、nonadaptive relaxed local decoder。其 proof-symbol
locality 至多为
\[
  Q_{\rm fin}=2^r\sum_{j=0}^{q-1}A^j,
  \tag{467.3}
\]
再加一个 inline-symbol query；在一个只依赖于 \(\rho,A\) 的固定正半径内，
该 decoder 在承诺球中从不输出错误 bit。

特别地，在 GGS 等要求 perfect completeness 的 arbitrary-alphabet nonadaptive
RLDC 下界适用、且其半径窗口包含该固定半径时，直接得到
\[
  d+P\ge
  \mathcal L_{Q_{\rm fin},\,A+2,\,\sigma_\star}(d),
  \tag{467.4}
\]
其中 GGS Definition 3.3 下 zero-wrong-output 意味着 relaxed soundness
parameter 可取 \(\sigma_\star=1\)（若采用更保守的匹配 convention，也可取任意固定
\(\sigma_\star<1\)）。于是这条 finite-randomness branch 不再需要
\(\alpha=1\)；它只需支付 \(2^r\) 决策树展开代价。

## 证明

取 \(F_s\) 的 shattered set
\(I=\{i_1,\ldots,i_d\}\)。对每个
\(x\in\{0,1\}^d\)，选一个 representative \(m_x\in F_s\) 满足
\((m_x)_{i_j}=x_j\)，并定义
\[
  C_s(x)=x\Vert\Pi(m_x),
\]
其中两个部分使用 disjoint alphabet tags。

先证 proof separation。若 \(x\ne x'\) 且
\(d_H(\Pi(m_x),\Pi(m_{x'}))\le\rho P\)，取一个
\(i_j\) 使两者在该坐标不同。由于两个 target 在同一 fiber，
\(\tau_{m_x,i_j}=\tau_{m_{x'},i_j}\)。将 \(\Pi(m_{x'})\) 看作 target
\(m_x\) 的近邻 proof，(467.1) 与 (467.2) 对同一个 policy/claim branch
分别给出至少 \(\alpha\) 和至多 \(\beta\) 的接受率，矛盾。因此 proof words
两两距离大于 \(\rho P\)。A-ary Singleton bound 随后给出
\(P=\Omega_{\rho,A}(d)\)，从而 inline code 具有只依赖 \(\rho,A\) 的正相对半径
\(\delta_\rho>0\)，并保证总距离至多 \(\delta_\rho(d+P)\) 时 proof suffix
仍在 \(\rho P\)-球内。

固定一个 inline coordinate \(i_j\) 和读出的 inline bit \(b\)。对每条 public
random tape \(\omega\in\{0,1\}^r\)，selected policy/claim branch 的自适应
query execution 是一个深度至多 \(q\)、分支字母表大小至多 \(A\) 的决策树。其
所有可能 query nodes 数至多
\[
  T_q(A):=\sum_{h=0}^{q-1}A^h.
\]
把所有 \(2^r\) 棵树的 query positions 一次性读出，最多读取
\(Q_{\rm fin}=2^rT_q(A)\) 个 proof symbols；离线即可在每条路径上模拟 policy
和 verifier，并精确计算该 claim branch 的 acceptance probability \(p_b(z)\)。

令 \(t=(\alpha+\beta)/2\)。若 \(p_b(z)\ge t\)，decoder 输出 \(b\)，否则
输出 \(\bot\)。在 uncorrupted codeword 上，inline bit 等于目标 bit，(467.1)
保证 \(p_b(\Pi(m_x))\ge\alpha>t\)，故 perfect completeness 成立。若 inline
bit 被翻转，而 proof suffix 仍在 \(\rho P\)-球内，则 (467.2) 给出
\(p_b(z)\le\beta<t\)，decoder 输出 \(\bot\)，绝不输出错误 bit。若 inline bit
没有翻转，decoder 只能输出正确 bit 或 \(\bot\)。因此承诺球内 wrong-output
probability 为零，得到所述 perfect-complete nonadaptive RLDC。
\(\square\)

## 非自适应特例与相图含义

若 fixed policy/claim branch 本身 nonadaptive，则每条 public tape 只有至多 \(q\)
个 query positions，(467.3) 改为
\[
  Q_{\rm fin}=q2^r.
  \tag{467.5}
\]
这给出一个直接的 completeness/locality tradeoff：

* \(r=O(1)\) 时，任意固定 \(\alpha>\beta\) 都可恢复常数-query
  perfect-complete RLDC，GGS/Block 下界可以直接使用；
* \(r=O(\log\log k)\) 时，代价为 polylog locality，仍可代入 GGS 的参数化长度
  下界；
* 若 \(2^r\) 达到 message scale，则 completeness repair 本身已经支付了
  address/target-scale 资源，不能再称为固定-locality closure。

因此 Paper 05 Theorem 4.3--4.5 中的 \(\alpha=1\) 条件应保留为一般 finite-view
模型的必要边界，但在 finite-public-randomness 子模型中可以由 Theorem 467.1
替代；这不是删除边界，而是把它精确化。

## 证据边界

* 定理要求所有 verifier randomness 都能用有限 public tape 枚举；隐藏随机性、连续
  response 或不可枚举 policy randomness 不在范围内。
* proof alphabet 必须有限，且 adaptive query tree 的 branch count 按 \(A^q\) 计价。
* 这是 selected-policy fiber 的 RLDC/compiler theorem，不是 ordinary dPCP 的一般
  impossibility，也不适用于 published RW 的 singleton without a family/fiber lift。
* 下界 (467.4) 仍须逐一定理核对 GGS/Block 的 alphabet、radius、query 与
  completeness convention；本 note 不把参数化 compiler 自动冒称为外部下界。

## 来源

* [note 271 selected-policy VC lift](271-selected-policy-vc-lift-to-rldc-2026-08-17.md)。
* [Paper 05 Theorem 4.3--4.5](../../rw-jk-succinct-reconstruction/papers/05-shared-proof-coordinate-robustness-barriers/paper.md)。
* Goldberg--Gur--Saraogi, arXiv:2511.21659, Theorem 1（仅在其 stated
  perfect-completeness/radius conventions 满足时调用）。
