> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact patchability-or-succinctness dichotomy for RW closure (2026-08-17)

## Purpose

The remaining RW/JK question is not whether one can write another local verifier.  The
question is which semantic mechanism closes a *single* canonical word.  The exact hitting
duality of note 227 gives a useful theorem-level split:

* if a common proof admits sufficiently rich first-hit patches, the proposed
  coordinate-robust reconstruction is an RLDC and inherits a proof-length lower bound;
* if those patches do not exist, the construction must expose a genuinely global coupling
  (or pay for a large descriptor).  A short address-scale coupling is already the
  (P/\mathrm{poly}) branch of the Closure Theorem.

This is a source-facing closure theorem, not a claim that RW or GMWZ already satisfies
either branch.

## Setup

For each base length \(n\), let

\[
  \Pi_n:\{0,1\}^{k_n}\to\Sigma^{N_n}
\]

be one common proof map, and let \(D_{n,i}\) be a randomized adaptive decoder making at
most \(Q_n\) proof-symbol reads and returning a requested symbol or \(\bot\).  Perfect
completeness means

\[
  D_{n,i}^{\Pi_n(m)}=m_i
  \qquad\text{with probability one}
  \tag{228.1}
\]

for every message \(m\) and coordinate \(i\).  On the honest proof and random tape
\(\omega\), write \(S_{n,m,i}(\omega)\subseteq[N_n]\) for the set of distinct positions
read by the adaptive execution.

For a radius \(\rho_n\), define the exact hitting value

\[
  H_n(\rho_n):=
  \max_{m,i}\max_{|B|\le \rho_nN_n}
  \Pr_\omega[S_{n,m,i}(\omega)\cap B\ne\varnothing].
  \tag{228.2}
\]

The quantity is about honest query sets, not a union bound on marginal incidences.

## Theorem (patchability-or-succinctness closure split)

Assume a proposed RW-specific reconstruction claims a common proof space and a target-
relative soundness guarantee at radius \(\rho_n\).  Consider the following two branches.

### Branch P: realizable first-hit patches

For every \(m,i\) and every \(B\subseteq[N_n]\) with \(|B|\le\rho_nN_n\), there is a
received proof \(z_{m,i,B}\) such that:

1. \(z_{m,i,B}\) differs from \(\Pi_n(m)\) only on \(B\); and
2. on every honest random tape whose first query path intersects \(B\), the execution
   on \(z_{m,i,B}\) outputs a wrong symbol (with probability one conditioned on that
   first hit).

Then the decoder's exact worst-case wrong-output probability is

\[
  s_n^\star=H_n(\rho_n).
  \tag{228.3}
\]

In particular, if the claimed robust soundness is \(s_n^\star\le1-\sigma\) for a
fixed \(\sigma>0\), the common proof map is a perfect-complete adaptive
\((Q_n,\rho_n,1,s_n^\star)\)-RLDC with \(s_n^\star\le1-\sigma\).  Whenever the fixed-parameter
sample-based RLDC lower bound applies, this forces the corresponding superlinear proof
length (for the constant-query regime recorded in note 226/C214, the exponent is

\[
  N_n\ge k_n^{\,1+1/O(Q_n^2\log^2(Q_n+2))}.
  \tag{228.4}
\]

The theorem only invokes (228.4) in the parameter window of that source theorem; it is
not an unconditional lower bound for every adaptive decoder.

### Branch S: address-scale static coupling

Suppose instead that, under the final complexity collapse (for example \(P=NP\) plus
the fixed PH/promise simulation used by the proposed reconstruction), every coordinate
of the *same* canonical object \(H_{A,n}\) is computed by one address evaluator

\[
  E_n(a;\sigma_n)=H_{A,n}[a],
  \qquad a\in[N_n],
  \tag{228.5}
\]

where \(\log N_n=n^{O(1)}\), the control size is \(p_n=n^{O(1)}\), and the common
descriptor \(\sigma_n\) (including cover sheet, key, and finite strategy summary) has
length \(d_n=n^{O(1)}\).  If descriptor reads use standard fan-in-two ROM expansion,
then

\[
  \operatorname{CC}(H_{A,n})
  =O(p_n^2+p_nd_n+p_n\log N_n).
  \tag{228.6}
\]

Thus any forcing statement

\[
  \operatorname{CC}(H_{A,n})>n^{\omega(1)}
  \tag{228.7}
\]

on the same infinite length set contradicts Branch S.  This is exactly the
\(P/\mathrm{poly}\) endpoint of the Closure Theorem: cover labels and finite strategy
summaries are not additional escape channels once they fit in one static address-scale
descriptor.

### Consequence

For a near-linear RW/JK candidate, avoiding both contradictions requires an explicit
failure of at least one premise, not a relabeling of it.  On every relevant length, at
least one of the following must occur:

* some radius-\(\rho_n\) corruption set is not realizable by a common-proof patch;
* a first hit does not force a wrong output (the bottom/absorption escape);
* the exact hitting value lies outside the claimed constant-soundness window;
* the family-level common-proof/RLDC hypotheses fail (for example there is only a
  single target, no distance-separated message family, or no common address space);
* the only global coupling uses superpolynomial descriptor information or a
  \(\operatorname{poly}(q_n)\), rather than address-scale, evaluator.

The first two bullets are the precise semantic content of the bottom/cover problem.  A
successful RW Closure proof must either rule them out by a source-specific theorem, or
turn their failure into Branch S.

## Proof

For Branch P, couple a corrupted execution with the honest execution using the same random
tape.  Until the first query in \(B\), the transcripts and adaptive query choices are
identical; therefore a wrong output is possible only after
\(S_{n,m,i}(\omega)\cap B\ne\varnothing\).  Maximizing over \(m,i,B\) gives the upper
bound \(s_n^\star\le H_n(\rho_n)\).  The assumed patch \(z_{m,i,B}\) has wrong output on
every first-hit tape, so its wrong-output probability is at least the same hitting
probability.  Maximizing again gives the reverse inequality and (228.3).  The RLDC
statement is then the definition of the resulting common proof map, and (228.4) is the
separate source-specific lower-bound corollary.

For Branch S, expand each static descriptor read into a standard multiplexer and hardwire
the resulting descriptor bits.  The ROM expansion gives (228.6), so (228.7) is impossible
for all sufficiently large lengths on the common infinite set.  No uniform generator for
\(\sigma_n\) is needed for the nonuniform \(P/\mathrm{poly}\) contradiction.
\(\square\)

## Research conjecture (RW-specific closure target)

For the actual canonical history produced by the RW/JK construction, prove a
**patchability-or-succinctness lemma**: at each forcing length, either Branch P holds for
a fixed positive radius with parameters in the RLDC lower-bound window, or the failure of
Branch P yields a single address-scale descriptor/evaluator satisfying Branch S.  This is
strictly stronger than ordinary dPCP list soundness and strictly weaker than a universal
family-level ACRR theorem.  It is the smallest source-specific statement that would turn
the current map of bottom, cover, descriptor, and address-scale escapes into a final
theorem-level route.

## Evidence boundary

* The exact equality (228.3) is the hitting duality of note 227.
* The pathwise/Lorenz RLDC consequences and the adaptive lower-bound window are recorded
  in note 226/C214.
* The ROM-to-circuit expansion and forcing-scale descriptor cost are recorded in notes
  204 and 220.

Nothing here proves that RW/JK or GMWZ satisfies the conjectured alternative.  The value of
the statement is that a future positive construction or impossibility theorem now has a
single source-facing target: prove the patchability-or-succinctness lemma, or refute it by
an explicit global-coupling counterexample.
