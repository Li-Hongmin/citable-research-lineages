> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Pairwise-intersecting collision family：affine-biclique EKR 边界

> **更正。** 本文只保留公共核情形与有限验证。最大叶版本的 AEKR 界已被 [027](027-aekr-max-leaf-counterexample-2026-08-13.md) 反驳；含 row/column thinning 的完整 AEKR 仍未判定。

## 候选势

令 \(\mathcal T\) 为 cell 集族，任意 \(T,U\in\mathcal T\) 满足
\(T\cap U\ne\varnothing\)。给定 spoiler \(s\notin T\)，并假设
\(T\cup\{s\}\) 对每个 \(T\in\mathcal T\) 都是 affine collision。定义

\[
A(R)=\mathbf 1\{\exists T\in\mathcal T:T\subseteq R\},
\qquad K(R)=\mathbf 1\{s\in R\}-A(R).
\]

Pairwise intersection 给出 QA recursion：
若 \(R=V\dot\cup W\)，则 \(A(V)+A(W)\le A(R)\)，从而
\(K(V)+K(W)\ge K(R)\)；且 \(K(C)=0\)。

## 已证的局部结果

若存在公共 cell \(c\in\bigcap_{T\in\mathcal T}T\)，则

\[
A(R)\le \mathbf 1\{c\in R\}\quad\text{逐点}.
\]

随机 affine 最大叶并独立 \(1/2\) 行、列 thinning 时，
\(\Pr(c\in R)=\Pr(s\in R)=1/16\)，故

\[
\mathbb E K(R)\ge0.
\]

这关闭了所有 star/common-core family。

最小无公共核的情形是 triangle：
\(\mathcal T=\{\{a,b\},\{b,c\},\{c,a\}\}\)。早期固定 \(N=2,3\) 的
MILP/枚举曾报告 \(3/64\) 等数值，但候选生成器的极小性判定后来发现方向错误；
因此这些有限数值全部降级为未审计线索，不作为证据。三角分支的可用结论应以
后续 note 031/033 的直接组合证明为准。

## 含 thinning 的剩余原子命题

尚未证明：

\[
\boxed{
\forall\,\mathcal T\text{ pairwise-intersecting},\quad
|T|\ge2,\quad
\Pr_{\ell,t,U,V}[\exists T\subseteq R]\le1/16.}
\tag{AEKR}
\]

若 (AEKR) 成立，则所有上述 \(K\) 都满足
\(\mathbb E K\ge0\)，因为 \(s\)-cell 的命中概率为 \(1/16\)；整个
pairwise-collision 非局部势路线关闭。

固定最大叶 \(R_0\) 后，四个行列补集轨道
\((U,V),(\bar U,V),(U,\bar V),(\bar U,\bar V)\) 中 \(A\) 至多一次，
只给出 \(\Pr[A\mid R_0]\le1/4\)，不能直接推出 (AEKR)：可能有
\(s\notin R_0\) 而 \(A\) 发生。故 (AEKR) 仍是独立的 affine-biclique
加权 EKR 问题，不应把数值检查当成证明。

当前决策：公共核势关闭；最大叶 (1/4) 版本已被 note 027 反驳；含 thinning
的 pairwise family 仍是可证伪的 lemma 目标，但其失败不会自动给出超线性 QA，
因为 thinning 可能把最大叶反例压回 (1/16) 以下。
