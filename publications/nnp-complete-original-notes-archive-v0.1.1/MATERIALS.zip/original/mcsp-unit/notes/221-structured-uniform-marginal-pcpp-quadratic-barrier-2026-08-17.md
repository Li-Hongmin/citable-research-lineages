> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Structured uniform-marginal PCPP quadratic barrier for simultaneous robustness

## 结论

本 note 把最新的 Cheng--Li--Mao PCPP 下界接到本项目的
simultaneous coordinate-robustness 目标。它关闭的是一个明确的、可发表的
正面路线：若统一 global proof 真能同时承担 coordinate binding，并且仍保持
标准 3-query PCPP 的输入/证明分层、均匀边缘、常数字母表和常数 soundness，
那么 proof length 不可能保持 near-linear，而必须达到二次量级（忽略
polylog 因子）。

这不是对所有 dPCP 或所有 coordinate-robust verifier 的无条件不可能性；
关键是标准 PCPP 的 far-input soundness 量词和三路 uniform-marginal 结构。

## 1. 结构化 PCPP

令 \(\phi:\Sigma_0^n\to\{0,1\}\) 是大小为 \(S\) 的电路，令
\(\mathrm{SAT}(\phi)=\{w:\phi(w)=1\}\)。考虑一个 3-query PCPP

\[
  \Psi=(X\cup(A\cup B),E,\Sigma,\{\Phi_e\}_{e\in E})
\]

其中 \(X\) 是显式输入位置，\(A,B\) 是两类 proof positions。假设：

1. \(\Sigma_0,\Sigma\) 都是固定有限字母表；
2. 每条超边 \(e=(x,a,b)\) 满足
   \(x\in X,\ a\in A,\ b\in B\)；
3. 采样的 \(x,a,b\) 的三个边缘分别在 \(X,A,B\) 上均匀；
4. 满足输入具有 perfect completeness；
5. 若 \(w\) 到 \(\mathrm{SAT}(\phi)\) 的相对距离至少为固定
   \(\eta>0\)，则任何延伸 \(T:X\cup A\cup B\to\Sigma\) 的约束违反率至少为
   固定 \(\delta>0\)。

最后一项是标准 PCPP 的 far-input soundness；它比“每个 proof 的局部输出
落在某个 list 中”强，因为它要求同一个远输入对所有 proof extension 都有
常数 rejection。

## 2. 二次长度定理

在上述假设下，Cheng--Li--Mao 的 Theorem 7.1 给出

\[
  |X|+|A|+|B|
  \ \ge\
  \frac{S^2}{\operatorname{polylog} S}.
  \tag{221.1}
\]

因此，任何同时满足这些结构条件的 proof system 都不能有
\(O(S\operatorname{polylog}S)\) 长度。这里的下界是直接调用外部定理，
本项目新增的是把其量词精确对齐到 shared-proof coordinate-robust 路线。

## 3. 对 RW/JK Closure Gate-I 的直接推论

设一个候选的 RW/JK attachment 试图对每个 stage relation \(\phi_i\)
构造一个固定 global proof，使：

* 所有 output coordinates 共用同一个 proof address space；
* 每次局部检查只读一个 input position、一个 \(A\)-position 和一个
  \(B\)-position；
* 三类位置均匀采样，alphabet 和 soundness gap 不随 stage 增长；
* simultaneous coordinate robustness 被解释为：只要输入词离
  \(\mathrm{SAT}(\phi_i)\) 有常数距离，任意同一 proof extension 都被
  常数概率拒绝；
* proof length 仍为 \(O(S_i\operatorname{polylog}S_i)\)。

那么 (221.1) 立即矛盾。故该正面路线必须显式放弃至少一项：

1. 从标准 PCPP 的 far-input soundness 退回较弱的 list/distributional
   输出语义；
2. 失去三路 uniform marginal 或 \(3\)-query 分层；
3. 让 alphabet、soundness 或 proof length 随 \(i\) 退化；
4. 把 output binding 放在额外的 target channel/descriptor 中，而不再由
   标准 PCPP 约束直接承担。

这条结论比仅把 shared proof 编译成 RLDC 更窄但更硬：它不需要构造完整的
target family、外码 field-lift 或 positive-radius RLDC；只要候选方案确实
声称自己是上述结构化 PCPP，就已有二次 proof-length barrier。

## 4. 与 GMWZ dPCP 的边界

GMWZ 的 dPCP 定理本身不能直接套用 (221.1)。dPCP 的解码/list 语义不自动
给出对远输入和所有 proof extensions 的 PCPP soundness，也不自动给出
上述 \(X,A,B\) 三类均匀边缘。因而本 note 不声称 GMWZ 当前定理已被二次
下界否定。

相反，若未来把 GMWZ/udPCP 路线增强到满足第 1 节的 PCPP 量词，那么
(221.1) 就是一个无需再做 RW-specific 参数审计的直接否定。若该增强只给
singleton output、分布式 soundness 或 target-normalized coordinate checks，
仍需先证明它们真的蕴含第 1 节的 far-input PCPP soundness；不能把这些词语
自动互换。

## 5. 研究状态

这是一个 source-backed、结构化的 quadratic barrier。它把“同时 coordinate
robust 的近线性 PCPP”从开放正面目标缩小为一个明确二分：

\[
\text{near-linear}
\quad\Longrightarrow\quad
\text{必须离开标准 PCPP far-soundness / uniform-marginal 接口}.
\]

它仍不完成 RW/JK 的 Closure Theorem，因为真正未知的可能正是一个
非标准、target-normalized、cover-aware 或 distributional 的接口；但它排除了
最自然的 standard-PCPP closure，不再只是一个具体 decoder 的失败记录。

来源：K. Cheng, X. Li, S. Mao, “When Relaxation Does Not Help: RLDCs with
Small Soundness Yield LDCs,” arXiv:2603.03717, Theorem 7.1：
<https://arxiv.org/abs/2603.03717>.
