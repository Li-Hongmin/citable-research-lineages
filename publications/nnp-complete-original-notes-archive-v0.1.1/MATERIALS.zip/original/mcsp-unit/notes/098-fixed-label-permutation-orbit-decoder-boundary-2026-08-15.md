> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定标签的置换轨道 decoder：一个具体 quotient 候选（2026-08-15）

## 定义

令 \(h_m(r)=r_1\)，并令 \(\mathsf{PermCirc}_{m,t}\) 是所有
\(\{0,1\}^{m}\to\{0,1\}^{m}\) 的 size-\(t\) 置换电路。定义

\[
\mathsf{Orb}_{m,t}(h)
=
\left\{
h_m\circ A^{-1}:A\in\mathsf{PermCirc}_{m,t}
\right\}.
\tag{1}
\]

每个 \(A\) 都给出 note 091 的有效 sampler

\[
E_A(r)=\bigl(A(r),h_m(r)\bigr),
\tag{2}
\]

因为地址映射是置换，Full 成立且 Cons 自动成立。因此
\(\mathsf{Orb}_{m,t}(h)\) 是 sampler range 的一个固定-label 子语言；它只暴露
置换逆的一个 bit，而不是 note 097 的整张逆表。

## 三个无条件边界

### 平衡性

每个 \(y\in\mathsf{Orb}_{m,t}(h)\) 都满足

\[
\lvert y^{-1}(1)\rvert=2^{m-1}.
\tag{3}
\]

所以 range-membership 至少有一个线性时间的必要筛选：非平衡 truth table 立即拒绝。

### 计数

固定 gate-list 语法下，若把 \(m\) 个 output-wire selectors 也计入描述，size-\(t\)
置换电路数量至多为
\(2^{O((t+m)\log(m+t+2))}\)。在常用的 \(t\ge m\) 区间，这退化为
\(2^{O(t\log(m+t))}\)；若采用固定 output convention，则旧的简写对所有 \(t\) 都成立。
以下新 note 099 使用带 output selectors 的完整计数，故

\[
\lvert\mathsf{Orb}_{m,t}(h)\rvert
\le
2^{O((t+m)\log(m+t+2))}.
\tag{4}
\]

这给出稀疏性上界，但不提供该语言的 circuit lower bound。

### 大规模退化

若 \(t\) 达到任意 \(m\)-输入 \(m\)-输出置换的通用综合规模，则每个平衡 truth table
都有某个置换 \(A_y\) 把 \(h_m\) 映为 \(y\)。于是

\[
\mathsf{Orb}_{m,t}(h)
=
\{y:\lvert y^{-1}(1)\rvert=2^{m-1}\},
\tag{5}
\]

其成员关系只需计数 1 的个数即可。因而 quotient 候选必须保持
\(t\ll 2^m\)，不能把“允许任意置换”当作压缩。

## 与 hard inverse 的关系

若某个置换 \(A_m\) 的逆电路很大，则
\(h_m\circ A_m^{-1}\in\mathsf{Orb}_{m,t}(h)\) 可能是 hard truth table；这正是
note 097 的单比特版本。但该事实仍只说明 range 中有 hard member：

\[
\text{hard orbit member}\not\Rightarrow
\text{hard orbit-membership language}.
\tag{6}
\]

此外，若允许 seed 同时选择任意标签电路 \(B\)，则 orbit 语言会重新扩张为
note 091 的一般 sampler range；固定 \(h\) 是为了避免把复杂性直接放进标签电路。

## 路线裁决

\(\mathsf{Orb}_{m,t}(h)\) 是目前最窄的 challenge/quotient 候选：

1. 它保留小置换的逆难度；
2. 它不把完整逆表作为输出；
3. 它有明确的平衡性和计数边界；
4. 但其 range-membership lower bound 仍未知，且大 \(t\) 会退化为容易的平衡性语言。

要让它触发 note 089 的 \(P\) vs \(NP\) 放大，仍需对同一固定
\(\bigcup_m\mathsf{Orb}_{m,t(m)}(h)\) 证明超准线性 decision lower bound；当前没有
这样的证明。本 note 只是把 quotient 分支压缩为一个可检验的 orbit-MCSP 问题。

原文核验日期：2026-08-15。
