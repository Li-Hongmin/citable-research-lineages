> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Multi-MCSP 与 iO 硬度不能直接转移到单输出 truth-table decoder（2026-08-15）

## 结论

当前 decoder 的目标是

$$
G_q:\{0,1\}^{q}\longrightarrow\{0,1\}^{2q},
\qquad
G_q(u)=\operatorname{TT}(C_u),
$$

其中输出是一个 $m$-变量**单输出**函数的完整 truth table，
$2q=2^m$。近邻文献中的 Multi-MCSP 与多输出 iO 结果不能直接给出该
$G_q$ 的 range 下界；缺失的是保持跨输出共享的单输出打包定理。

## 文献事实

Ilango--Loff--Oliveira 的 Multi-MCSP 定理证明：给定

$$
F:\{0,1\}^{n}\to\{0,1\}^{r}
$$

的完整多输出 truth table，判定是否存在一个共享电路同时产生全部 $r$ 个输出，在随机化
多项式时间 many-one reductions 下是 NP-hard。其核心对象是多输出 circuit complexity，
而不是把各输出分开后分别最小化。

Lu--Mazor--Oliveira--Pass 的 iO 工作进一步把多输出 Multi-MCSP 与近最优 obfuscation
联系起来：在 $NP\nsubseteq BPP$ 的假设下，不能有输出规模

$$
s+o(s/\log s)
$$

的有效多输出 iO。该工作同时明确指出，把 Multi-MCSP 的硬度限制到

$$
F:\{0,1\}^{n}\to\{0,1\}^{n}
$$

仍是困难的开放步骤；直接把多输出实例 padding 到同样的输入/输出宽度会使 truth-table
尺寸爆炸。这一障碍与本项目的单输出 decoder 问题相同，而不是已解决的 decoder lower
bound。

## 精确的打包障碍

给定多输出函数 $F$，最直接的单输出打包是

$$
h_F(x,j)=F_j(x),
\qquad
x\in\{0,1\}^{n},\ j\in\{0,1\}^{\lceil\log r\rceil}.
$$

正向方向容易：若 $F$ 有一个共享 size-$s$ 电路，则用一个 selector/multiplexer 得到
$h_F$ 的电路，代价约为 $s+O(r\log r)$。

反向方向没有已知的共享保持性：给定一个 size-$t$ 的 $h_F$ 电路，固定 $j$ 可以得到单个
$F_j$；把这 $r$ 个分量同时恢复出来的朴素方法是使用 $r$ 个固定后的副本，代价至多只有

$$
O(rt),
$$

而不是 $t+O(\operatorname{polylog}r)$。因此，当前不能从

$$
\operatorname{CC}(h_F)\le t
$$

推出一般电路模型中的

$$
\operatorname{CC}(F)\le t+o(t)
$$

；若把这个尚未证明的蕴含误用为等价，就会错误地把 Multi-MCSP 的
NP-hardness 转成单输出 MCSP 或 $G_q$ range 的 NP-hardness。

## 对当前 decoder 的直接后果

1. $G_q$ 的每个输出坐标是 $h_F(x,j)$ 中的一个地址位；这并不暴露一个能同时恢复
   $r$ 个共享输出的 circuit witness。
2. 一个固定 gate-list decoder 的 range membership 仍只是单输出 fixed-slice MCSP 的
   existential language；Multi-MCSP 的 randomized hardness 不自动作用于它。
3. iO 的近最优开销下界是 obfuscation 的安全性结果，不是对任意
   $q$-input/$2q$-output circuit map 的 size lower bound；把 $G_q$ 称为“隐式 iO”
   需要额外的 indistinguishability 与 syntax-hiding 结构。

因此，若要把这条路线接回 $P$ vs $NP$，需要一个新的、可验证的 sharing-preserving
packing 命题：

$$
\operatorname{CC}(F)\le s
\iff
\operatorname{CC}(h_F)\le s+g(n,r),
\qquad
g=o(s),
$$

并且该变换还要保持 truth-table 长度、uniformity 与 decoder 的 near-linear syntax
budget。当前文献没有给出这个命题。

## 证据边界

- Ilango, Loff, Oliveira, *NP-Hardness of Circuit Minimization for Multi-Output Functions*,
  CCC 2020, DOI
  [10.4230/LIPIcs.CCC.2020.22](https://doi.org/10.4230/LIPIcs.CCC.2020.22)，
  官方全文：[Dagstuhl PDF](https://d-nb.info/1366619218/34)。
- Lu, Mazor, Oliveira, Pass, *Lower Bounds on the Overhead of Indistinguishability
  Obfuscation*, IACR ePrint 2024/1524，官方全文：
  [IACR PDF](https://eprint.iacr.org/2024/1524.pdf)。
- 本 note 的 selector 打包与复制记账是项目内推导；它只证明“不能直接转移”，不证明
  一般 single-output MCSP 或 unrestricted decoder 的超线性下界。
