> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW Closure-Gate master trichotomy (2026-08-17)

## Purpose

The project now has three separate closure mechanisms: actual-history JK
capacity, global-package entropy closure, and the adaptive-to-nonadaptive RLDC
barrier. This note states the resulting **master trichotomy** in one place.
It is a closure theorem for the stated interface, not an unconditional
\(P\ne NP\) or general dPCP impossibility theorem.

## Theorem (RW Closure Gate)

At a stable Ren--Williams stage let

\[
 q_i=n_{i+1}=n_i^C,\qquad
 T_i=\max\{2^{cD^i n_0},n_{i+1}\},\qquad C>D+1 .
\]

Assume one selected actual history per input has length at most \(T_i^a\),
with input length \(\nu_i\le n_i\). Consider a proposed attachment with
payload dimension \(K_i=\Theta(q_i)\), proof length \(P_i\), and inline length
\(N_i=K_i+P_i\). Suppose \(N_i\le K_i(\log(K_i+2))^c\) on infinitely many
stages.

Assume the intended family-level code window is one in which the applicable RLDC
lower bound excludes \(P_i\le K_i(\log(K_i+2))^c\); this is the coding hypothesis
used in clause (II).

For every sufficiently large such stage, at least one of the following holds.

### (I) JK supply is already exponential

If the construction claims to obtain a non-range node from actual disjoint dyadic
aligned depth-\(h\) groups of the selected histories, then necessarily

\[
 \nu_i+a\log_2 T_i
 \ge q_i+\log_2(2q_i)+h .
\tag{279.1}
\]

Here “aligned” refers to the canonical JK partition, so the groups are disjoint. If
all sliding block windows are counted instead, the factor \(2^h\) is omitted from the
window count; the resulting bound is still \(2^{o(q_i)}\) in the RW recurrence and gives
the same asymptotic conclusion.

The RW recurrence gives \(\nu_i+a\log T_i=o(q_i)\). Reaching (279.1) by
increasing history length alone requires

\[
 T_i\ge
 2^{(q_i-\nu_i-O(\log q_i+h))/a},
\tag{279.2}
\]

which is outside the polynomial-in-\(T_i\) `Solve` regime.

### (II) A common global package pays a linear price

Assume instead that the construction supplies one fixed proof/address space and
a target-dependent global package \(S_i\) containing all coordinate/claim
policies. Let \(\bar\delta_i\) be its max-before-average robust defect and
\(I_i=I(M_i;S_i)\) its target mutual information. If the correct/wrong
acceptance margin is bounded below by a fixed \(\Delta>0\), and the package
has the common finite-alphabet/locality/radius hypotheses of Proposition
5.0I, then there are constants \(\varepsilon_\delta,\varepsilon_I>0\) such that

\[
 \bar\delta_i\ge\varepsilon_\delta
 \quad\text{or}\quad
 I_i\ge\varepsilon_I K_i.
\tag{279.3}
\]

If both quantities are smaller, Proposition 5.0I produces one fixed package on
a fiber of size \(2^{\Omega(K_i)}\). Sauer--Shelah and message inlining then
give a forbidden near-linear RLDC.

### (III) The finite-alphabet branch pays locality, alphabet, or gap

If the package is family-level, has a common proof map, positive target-relative
radius, and independently resamplable branch verifiers, define

\[
 \gamma_i=\alpha_i-\beta_i,
 \quad R_i=\Theta(r_i/\gamma_i^2),
 \quad Q_i=1+2\sum_{j<R_i}A_i^j,
\]

and \(\Lambda_i=1+\log\log(K_i+2)+\log\log(A_i+2)\). The adaptive
decision-tree expansion followed by the arbitrary-alphabet RLDC lower bound
gives the following dichotomy: if \(\log A_i\ge K_i/2\), the alphabet itself
is a message-scale channel; otherwise it forces

\[
 Q_i\Lambda_i=\Omega(\log K_i).
\tag{279.4}
\]

In the binary fixed-gap case this becomes
\(r_i\ge\log_2\log K_i-\log_2\log\log K_i-O(1)\).

If correct-claim completeness is imperfect, clause (III) has a stronger
full-ROC sub-branch.  Given a fixed-distance binary inner code of block length
\(\ell_i\), Corollary 6.8C' says that either the expanded length
\(\widehat N_i=d_i+\ell_iP_i\) leaves the near-linear window, or
\[
  (1+\ell_ir_i)\log(3+\ell_ir_i)=\Omega((\log K_i)^{1/3}).
\tag{279.4a}
\]
This sub-branch requires one target-independent full-ROC package after the
mutual-information mixture; it does not follow from ordinary average/list
soundness.

There is also a tail-sensitive replacement for the worst-case decision-tree
quantity in (III). For a fixed coordinate and random tape, let
\(U_i(\omega)\) be the union of all proof positions on the two claim branches,
over all possible answer paths, and write
\[
  \tau_i(T):=\Pr_\omega[|U_i(\omega)|>T],
  \qquad
  \tau(T):=\max_i\tau_i(T).
\tag{279.4b}
\]
Here \(\sigma_i:=1-\beta_i\) is the coordinate-(i) wrong-claim rejection
margin after the same branch amplification, and choose
\(0<\gamma<\sigma_i\). If \(\tau_i(T)\le\sigma_i-\gamma\), the bad tapes can be truncated and
\(O(\gamma^{-2})\) fresh tapes thresholded, producing a non-adaptive
finite-alphabet RLDC with
\[
  Q_i^{\mathrm{tail}}\le1+O(T/\gamma^2).
\tag{279.4c}
\]
Thus the GGS branch applies with \(Q_i^{\mathrm{tail}}\). In particular, whenever
\(N_i\le K_i(\log K_i)^c\), the first such quantile must satisfy
\[
  T_{\gamma,i}:=\inf\{T:\tau_i(T)\le\sigma_i-\gamma\}
  =\Omega\!\left(\gamma^2\frac{\log K_i}{\log\log K_i}\right)
\tag{279.4d}
\]
in the fixed-alphabet, fixed-gap window. If this quantile is smaller, the
support tail itself has mass \(>\sigma_i-\gamma\); hiding the large adaptive
tree on rare random tapes is therefore not a fourth escape. This refinement
requires uniform exposure of the finite supports and is recorded in
[note 335](335-quantile-branch-support-adaptive-closure-2026-08-18.md).

### Gate-II refinement: semantic transfer before the quantitative branches

The preceding clauses only apply after the RW promise queries have been given a
meaning on the physical near-proof space. A candidate physicalization \(\Phi\)
is **promise-preserving** if every target-relative \(\rho\)-near physical word is
mapped to the same visible transcript/claim semantics used in the RW smart-prMA
promise, with the claimed output bit retained.

For any proposed transcript-only attachment, the following ordered dichotomy is
exhaustive at the level of its advertised interface:

* If no promise-preserving \(\Phi\) is supplied, RW's theorem gives no
  target-relative corruption statement. An off-promise completion can agree with
  every canonical-history query and nevertheless accept a wrong branch. Thus
  this is a semantic model change, not a free instance of clause (II) or (III).
* If \(\Phi\) is supplied and induces a fixed visible transcript law, define the
  robust frontier \(\mathsf{ROC}_{i,b}(\alpha,\rho)\) for each coordinate/claim.
  If it exceeds the requested \(\beta\) for any \((i,b)\), the minimax dual gives
  one mixture of target-relative near proofs defeating every transcript-only
  postprocessor with completeness \(\alpha\). If it is at most \(\beta\) for all
  \((i,b)\), then, **provided the attachment also claims a common target family,
  positive radius, and all-policy semantics**, it is a common-proof relaxed-LDC
  interface and must pay the quantitative package/locality costs in (II)--(III).
  Without those extra family hypotheses it is only a low-ROC transcript filter,
  not yet an RLDC.

This refinement is not an additional assumption hidden in the trichotomy: it is
the exact logical order in which the RW promise can be connected to ACRR
corruption. If the low-ROC branch also claims a finite common-response evaluator
for a forced hard block \(B_i\), the RW common-strategy bound gives the independent
descriptor price

\[
  \operatorname{CC}(B_i)\le
  O\!\left(m_i(p_i+b_i d_i+m_i)\right).
\tag{279.5}
\]

Thus a near-maximum forcing threshold implies
\(d_i=\Omega(2^{m_i}/(m_i^2b_i))\). The descriptor bound is orthogonal to the
ROC dichotomy: it rules out address-scale finite common control even when a
physicalization happens to have low ROC.

### (IV) Otherwise the construction has left the closure model

If none of (I)--(III) is paid, then at least one advertised hypothesis is
false: the proof is not common/address-fixed, the target package is not a
single word-consistent global object, the radius or gap has left the stated
window, the alphabet itself carries message-scale information, the
alphabet/locality is outside the finite-window regime, or the
construction has no target-relative all-policy semantics. This is a model
change, not a fourth free escape.

## Proof

Clause (I) is the selected-history window count from the RW family/strategy
trilemma. Clause (II) is Proposition 5.0I: under the displayed defect and
information bounds, its fixed-package fiber has linear exponent, and the
resulting common decoder contradicts the assumed near-linear RLDC window. For
clause (III), independently amplify the two branch verifiers to constant
completeness/soundness gap. Exposing both adaptive decision trees creates
\(Q_i\) nonadaptive queries, while the inline tag gives a positive radius; the
arbitrary-alphabet RLDC bound then yields (279.4), as in Theorem 4.1 and the
joint phase-boundary calculation. If only a support quantile is bounded, use
\(Q_i^{\mathrm{tail}}\) in (279.4); otherwise (279.4d) records the required
tail payment. The Gate-II refinement is Proposition 8.2A
plus Corollary 8.2B: without promise transfer there is no corruption theorem;
with it, the robust ROC alternatives are exactly the high-ROC minimax branch or
the low-ROC common-proof branch. Finally, (279.5) is the common-strategy ROM
expansion from note 231. If any hypothesis needed by these reductions fails, the
failure is precisely clause (IV). \(\square\)

## Scope

This is a **closure gate**, not a claim that ordinary dPCP/list soundness already
satisfies the global-package hypotheses. It closes the three quantitative
channels currently available in the RW/JK line: history supply,
target-dependent package entropy/defect, and finite-alphabet locality/gap. A
top-level positive construction must therefore provide a new global coupling
(for example a genuinely distributional same-seed object) or leave the
common-proof model explicitly.

The theorem does not by itself prove \(P\ne NP\). It converts the final goal
into the remaining question whether the RW failure branch can supply a
promise-preserving physicalization with low ROC and a global package without
paying (279.3)--(279.5), or whether it must leave the finite common-address
model through genuinely non-transcript interaction.

## Sources in this project

* RW family--strategy trilemma: note 278 and Main Theorem 6.3.
* Average-defect common-fiber closure: Proposition 5.0I and note 277.
* Finite-alphabet adaptive closure and joint alphabet/locality envelope: Theorem
  4.1, Corollary 4.1C, notes 240--248, and note 300.
* Promise/ROC bridge: main-paper Proposition 8.2A and Corollary 8.2B, and
  note 266.
* RW finite common-strategy descriptor bound: note 231.
* External RLDC input: Goldberg--Gur--Saraogi,
  <https://arxiv.org/abs/2511.21659>.
