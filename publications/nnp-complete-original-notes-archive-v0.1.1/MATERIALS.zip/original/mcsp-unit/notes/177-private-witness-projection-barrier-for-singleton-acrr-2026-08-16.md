> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Private-witness projection barrier for singleton ACRR (2026-08-16)

## 目的

本 note 把 note 175 的最后一个缺口从“需要一个外部输入编译器”收紧为一个
可检验的投影问题。目标关系是

\[
  L_x=\{y\in\{0,1\}^{\ell}:\exists w\;R(x,y,w)\},
\]

并且在当前应用中希望 `L_x={f_x}` 是 singleton。所需 verifier 必须：

1. 公开的 `y` 只占 input/address space；
2. `w` 由同一个 global proof 隐藏并复用，而不是作为每次查询的公开输入；
3. 对错误的 `y_i=b` 给出常数拒绝概率；
4. 所有坐标共享同一 proof address space，并保持 word consistency。

这不是普通 `SAT(φ)`-PCPP 的直接实例化；不过，通用 pair-language PCPP 已经能在
语义上表达这个投影关系。真正未解决的是近线性参数、地址尺度和所有坐标共用同一
proof 的组合。

## 已核验的来源边界

Gur--Minzer--Weissenberg--Zheng 的 Theorem 1.7 对电路
\(\varphi:\Sigma_0^n\to\{0,1\}\) 给出 `SAT(φ)` 的 3-query PCPP；其输入词是
完整的 \(z\in\Sigma_0^n\)，语言定义为 \(\{z:\varphi(z)=1\}\)。
Theorem 11.1 的构造同样把 `X` 视为完整的 SAT assignment，并用 dPCP decoder
与该 assignment 的坐标比较。它没有声明对
\(\{y:\exists w\;R(x,y,w)\}\) 的私有 witness projection。

因此，令
\(\varphi_x(y,w)=R(x,y,w)\) 后直接调用该定理，得到的是对完整词
\((y,w)\) 的 PCPP，而不是对公开词 `y` 的 PCPP。这个量词差异不能在 RW 的
Reconf 查询中省略。

还有一个独立的参数障碍：若想把 Theorem 1.7 直接用于公开词 `y`，必须先提供
一个电路
\[
  \widehat\varphi_x(y)=1\quad\Longleftrightarrow\quad
  \exists w\;R(x,y,w).
\]
对一般关系 `R`，从 `R` 的电路构造这样的确定性投影电路没有已知的多项式规模
保证；朴素展开要枚举所有 `w`。若一个统一的多项式规模投影器对所有 NP 关系都
存在，把 `y` 取为一个判定位即可得到 NP 的多项式大小电路族（至少 NP
\(\subseteq\)P/poly 级别的后果）。所以“先把关系投影成 `\widehat\varphi_x`，
再调用近线性 PCPP”不是现有定理免费提供的步骤，而正是需要证明的新编译器。

## 命题：朴素 SAT-PCPP 投影不保持常数 proximity

不存在一个仅靠“把 witness 坐标当作额外 input 坐标，然后对其任意量化/忽略”
的黑箱转换，能从完整词 PCPP 得到对 `y` 的常数-proximity PCPP；即使
\(L_x\) 是 singleton 也如此。

### 证明（最小反例）

取 \(\ell=1\)，唯一合法输出为 \(y=0\)，并令存在一个合法 witness \(w=0^s\)。
在完整 assignment 空间中令

\[
  z^*=(0,0^s)\in\operatorname{SAT}(\varphi_x),
  \qquad z'=(1,0^s).
\]

任何把 `y` 作为一个普通 input 坐标、把 `w` 也放在同一 input word 中的转换，
都面对
\(\operatorname{dist}(z',\operatorname{SAT}(\varphi_x))\le 1/(s+1)\)。
当 `s` 足够大时，`z'` 虽然对应错误输出位，却离完整 SAT 语言任意近。
所以一个只承诺在距离至少 \(\eta>0\) 时拒绝的 PCPP，不能在 `z'` 上提供
常数 soundness。把 `w` 逐位 existentially quantifier 掉也无济于事：不同坐标
可以选择不同 witness，不能得到一个共同 global proof。

这个反例不依赖 PCPP 的具体构造；它只使用完整 assignment 与投影语言之间的
Hamming-distance 不相容。因此“先用 Theorem 1.7，再把 witness 坐标隐藏”不是
一个已证的 ACRR 构造。

## 必须新增的接口

要把 note 175 的 singleton-output bridge 真正接到 GM 参数，至少需要下面之一：

### Interface P (projection-robust PCPP)

对每个电路关系 `R(x,y,w)`，构造一个固定 proof system，其中 `y` 是唯一公开
input，`w` 只出现在 proof vertices；存在同一个 honest assignment，使所有
坐标解码为 `f_x`，且对任何 candidate proof 和错误声明 `y_i=b`，接受概率
至多 \(\delta<1/2\)。proof 长度、查询数、alphabet 和 uniformity 需保持
近线性/地址尺度。

### Interface C (distance-amplified projection compiler)

先把公开词编码为高距离 `Enc(y)`，再用一个 global proof 证明
\(\exists w\;R(x,y,w)\) 与 `Enc(y)` 的一致性；编译器必须保证：

\[
  y\notin L_x \quad\Longrightarrow\quad
  \operatorname{dist}(\operatorname{Enc}(y),\operatorname{Valid}_x)\ge\eta.
\]

这正是一个新的 robust projection/PCPP 定理，而不是普通 SAT-PCPP 的记号替换。

## 与通用 pair-language PCPP 的关系

已有的 pair-language PCPP 定义把 `x` 作为显式实例、把 `y` 作为隐式 oracle，并对
\(L(x)=\{y:(x,y)\in L\}\) 给出 proximity soundness。对
\(L_R=\{(x,y):\exists w\,R(x,y,w)\}\)，这确实隐藏了私有 witness，因而修正了
“只把 `w` 当作普通 input 坐标”的语义问题。

但该通用定理的 proof 长度是运行时间 `t` 的多项式，且 prover/proof 依赖完整的
`(x,y)`。它不提供：

1. 对固定 `x`、所有坐标 `i` 和声明位 `b` 共用一个 `Pi_x`；
2. `Q_{x,i,b}` 在同一地址空间中复用该 proof；
3. RW 所需的 `poly(n,log T)` 地址尺度或近线性 proof 长度。

所以 pair-language PCPP 解决了“私有 witness 投影是否可定义”，但没有解决
ACRR 的“单一 global proof + simultaneous coordinate robustness”。

## 与 distributional soundness 的关系

若 Interface P/C 已提供“每个局部接受视图除 \(\delta\) 异常外都与某个
valid global proof 一致”，且所有 valid proofs 在输出坐标上都解码同一 singleton
词，则 note 175 的 singleton bridge 立即给出 coordinate soundness。困难不再是
distributional quantifier，而是先构造一个有私有 witness、公开投影和常数距离放大
的 global proof system。

反过来，普通 dPCP list soundness 不提供该投影接口：它允许完整 valid words
\((y,w)\) 形成一个 list，且 list 中不同词可能在 `y` 坐标上不同；即使 `y` 的
合法投影是 singleton，也必须证明每个局部理想词都来自该投影，而不是被不同
`w`/不同局部视图拼成 phantom output。

## 晋级标准

这个障碍将后续工作压成两个顶级可检验方向：

1. **正面定理：** 构造 Interface P 或 C，并给出近线性 proof、常数查询、统一
   address generator；随后用 note 175 接入 RW/JK。
2. **一般下界：** 在明确的 projection-PCPP 模型（例如 proof-only witness、固定
   singleton output、坐标鲁棒性）中证明任何构造都需要超线性长度，或推出一个
   已知受限模型下的 RLDC/LDC 代价。

仅把 witness 坐标加入 `SAT(φ)` 输入、逐坐标重新编译 PCPP、复制一个错误坐标，
都不满足上述标准。

## 证据边界

- GM Theorem 1.7/11.1：直接支持“完整 SAT assignment 的近线性 PCPP”，不直接
  给出共享 proof 的私有 witness projection。
- pair-language PCPP 的标准定义/通用构造：支持公开 `y` 与私有 witness 的语义，
  但 proof 依赖 `(x,y)` 且长度为 `poly(t)`，不满足 ACRR 的共享与地址尺度。
- note 175 的 singleton bridge：是本项目推导的条件性量词引理。
- 最小反例只否定朴素黑箱投影，不否定存在全新的 projection-robust PCPP。

## 来源

- [GM--Minzer--Weissenberg--Zheng, Theorems 1.7 and 11.1](https://arxiv.org/html/2512.12960)
- [Probabilistically Checkable Arguments for all NP, Definition 3.3 and Theorem 3.4](https://eprint.iacr.org/2024/599.pdf)
- [Dinur--Harsha--Kindler, distributional soundness](https://eccc.weizmann.ac.il/report/2015/085/download)
- [Ren--Williams, Range Avoidance and `E^{prMA}/_1`](https://eccc.weizmann.ac.il/report/2026/118/)
