> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW Theorem 3.5 的二值 proof serialization source boundary（2026-08-18）

## 判定

原始 RW 文本确认了 Harsha proof 的**对象分解**，但没有规定 C396 所需的二值
坐标顺序。因此“连续 \(\Upsilon\) segment”是一个可选择的 source
representation，不能直接冒称为 published RW Theorem 3.5 已经提供的
serialization invariant。

## 原始来源核验

在 Theorem 3.4 的 proof sketch 中，RW 将 Harsha proof 写成三个函数：
\[
  \widetilde A:F^m\to F,\qquad
  P:F^{3m+3}\to F,\qquad
  \Pi_{\mathrm{ZoS}}:F^{3m+3}\to F^{6m+6},
\]
并记 \(\widetilde w=\widetilde A\)、\(\Pi'=(P,\Pi_{\mathrm{ZoS}})\)。随后 Theorem 3.5
把每个完整 proof 写成
\[
  \Pi=(\widetilde w,\Pi'),
\]
其中 \(\widetilde w\) 是 systematic Reed--Muller witness encoding 的 prefix，
\(\Pi'\) 是 auxiliary proof oracles。该 theorem 只给出 proof length、
randomness、query complexity 以及这些 oracle 的完备/可靠性量词。

Harsha thesis §5.4.3 的 binary conversion 则把大字母表 proof oracle
\(\Gamma\)（每个 symbol 是 \(a=\log|\Sigma|\) bits）扩成
\[
  \Gamma\circ\Upsilon,\qquad
  \Upsilon(i)=\operatorname{ECC}(\Gamma(i)),
\]
验证器对每个被查询的 \(i\) 同时读取 \(\Gamma(i)\) 与 \(\Upsilon(i)\)，并检查
\(\Upsilon(i)=\operatorname{ECC}(\Gamma(i))\)。这说明 ECC 是逐 symbol 的
product code；但它仍没有决定把所有 \(\Upsilon\) 坐标放成一个连续的全局
binary segment，还是按 symbol 与 \(\Gamma\) 交错排列。

## 对 C396 的精确影响

C396 的 Theorem 396.1 对以下 source-level 变体成立：

1. 保留 RW 要求的 \(\widetilde w\) systematic prefix；
2. 将 auxiliary \(\Gamma\) 与 \(\Upsilon\) 固定为公开、可逆的二值坐标映射；
3. 选择连续 \(\Upsilon\) segment，或给出 address-scale 可计算的 public
   coordinate permutation；
4. 在 verifier 查询前应用该映射的逆函数。

Hamming distance、ECC equality check 和 Harsha 的 alphabet-reduction 参数在这个
固定坐标重排下不变。但 published Theorem 4.1 只把 \(\Pi_x\) 当作 opaque
canonical proof 交给 JK，并没有给出上述 coordinate map、其 address-scale
evaluator，或它与 first-failure block 的 alignment 关系。

因此 C396 目前应读作一个**可实现的 source branch**，而不是 published RW
serialization theorem。剩余的最便宜核验是：在不移动 \(\widetilde w\) prefix
的前提下，显式写出 \(\Gamma/\Upsilon\) 的坐标 map，并证明其查询和 first-failure
path 描述仍是 address-scale；否则回到 C393 的 descriptor/transcript payment。

## 来源

* Ren--Williams, ECCC TR26-118 revision 1, Theorems 3.4--3.5 and 4.1:
  <https://eccc.weizmann.ac.il/report/2026/118/revision/1/download>.
* Prahladh Harsha, *Robust PCPs of proximity and shorter PCPs*, MIT thesis,
  §5.4.3:
  <https://dspace.mit.edu/handle/1721.1/26720>.
* C395--C396：线性 ECC source 与 product-code high-rank gate.
