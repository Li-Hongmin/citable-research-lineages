> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Per-coordinate dPCP 拼接是条件性接口，不是 RW 的直接替换（2026-08-16）

## 结论

把一个输出坐标复制 \(R\) 次，只会重加权平均 soundness，不能把普通 dPCP 的平均保证变成
RW 所需的固定坐标常数 gap。一个不同的、值得保留的正向想法是：对每个输出坐标 \(i\)
和候选值 \(b\) 单独编译

\[
  \varphi_{x,i,b}(w):=C_x(w)\land[\operatorname{out}_i(w)=b]
\]

的 dPCP，再把所有组件拼成一个全局 proof table。若该拼接表可以**直接作为 RW 的
J--K 输入**，则可得到不需要 lex-prefix 的 smart bit query；但标准 dPCP/udPCP 定理
没有给出这个“计算历史 proof 的可组合嵌入”。因此本 note 是严格的条件性正向引理，同时
明确当前路线的真正缺口。

## 1. 复制坐标的严格失败界

原输出长度为 \(n\)，第 \(i\) 个坐标复制为 \(R\) 份，新长度
\(N=n+R-1\)。若原 assignment 的错误坐标数为 \(B\)，且第 \(i\) 位错误指标为
\(e_i\in\{0,1\}\)，均匀采样新坐标时

\[
  B_R=B+(R-1)e_i,\qquad p_R=B_R/N .
\]

玩具实例已经给出不可绕过的下界：恒真约束、合法语言只有 \(0^n\)，但存在只在坐标
\(i\) 取 1 的 assignment。复制副本并令它们全部取同一个错误值仍满足所有等式，因此

\[
  \varepsilon'_R\ge \frac{R}{n+R-1}.
\]

要使该坐标获得固定 \(\delta>0\) 的采样权重，必须 \(R=\Omega(n)\)；而要求新的平均
soundness 仍小于 \(1/2\) 时，\(R/(n+R-1)>1/2\) 反而直接破坏这一要求。复制 decoder
输出、物理复制 proof，或给副本加 equality edge，都不能排除“所有副本一致地取错值”。
因此复制只是一条 reweighting trade-off，不是 coordinate-robust compiler。预算还必须分别
检查：只复制输出时增加 \(O(\log R)\) routing；重新编译或物理复制时 proof/graph 长度
随具体实现增加，不能默认落在
\(\operatorname{poly}(k,r,\log t)\) 内。

一种不要求 \(P_x\) 直接成为 J--K history 的分层组合方式见
[note 170](170-output-lifted-dpcp-composition-for-rw-reconf-2026-08-16.md)；它把 dPCP
proof 放进 RW 多输出函数的 output 区，但保留 q-scale Reconf。
若允许另定义一个先生成 \(P_x\) 再直接运行 J--K 的独立 Solve/Reconf，则可进一步去掉
history compiler；其条件性定理与 forcing 缺口见
[note 171](171-direct-dpcp-jk-tradeoff-and-forcing-gap-2026-08-16.md)。

## 2. 可行的条件性替代：按坐标、按候选 bit 编译

设 \(C_x(w)\) 是 RW 的 computation-history 电路，且所有满足 assignment 的合法 history
对确定性机器 \(M\) 的输出坐标都相同。对每个 \(i,b\) 构造 SAT 实例

\[
  \varphi_{x,i,b}(w)=C_x(w)\land[\operatorname{out}_i(w)=b].
\]

假设存在一个**同一地址规范**的 dPCP 编译器，满足：

1. 若 \(\varphi_{x,i,b}\) 可满足，则存在 proof \(\pi_{x,i,b}\) 使局部 verifier 完美接受；
2. 若 \(\varphi_{x,i,b}\) 不可满足，则任意 proof assignment 的接受率至多
   \(\epsilon<1/2\)；
3. 组件 proof 的地址、随机边、约束和 decoder 可由 \((x,i,b)\) 在
   \(\operatorname{poly}(k,r,\log t)\) 大小/时间内生成；
4. 令
   \[
     P_x:=\mathop{\Vert}_{i\in[t],\,b\in\{0,1\}}\pi_{x,i,b}
   \]
   （不可满足组件填入任意字符串）后，\(P_x\) 正是 J--K 所作用的 hard table；
   JK failure 给出的 \(O(k^4\log |P_x|)\)-size circuit 能在所有组件地址上统一求值。

在这些额外假设下，对每个 \(i\) 定义一个 prMA 查询 \(Q_{x,i,b}\)：Merlin 提交一个
描述 \(P_x\) 的全局电路 \(C\)，Arthur 只在组件 \((i,b)\) 内抽样一条 dPCP 随机边，
并用 \(C\) 读取该边涉及的 proof symbols。

若 \(f(x)_i=b\)，则 \(\varphi_{x,i,b}\) 可满足，拼接证明给出完美完备性；若不存在任何
合法 history 的输出位 \(b\)，则 \(\varphi_{x,i,b}\) 不可满足，任意 \(C\) 的接受率至多
\(\epsilon<1/2\)。于是只调用 \(Q_{x,i,1}\) 即可得到 \(f(x)_i\)，同一个全局 \(C\) 被所有
坐标复用，不会出现逐 prefix 重编译造成的 phantom witness。若每个组件长度为
\(L_*=\operatorname{poly}(t)\)，则 \(|P_x|=2tL_*=\operatorname{poly}(t)\)，所以
\(\log|P_x|=O(\log t)\)；组件拼接本身不引入指数长度。

这里的正向结论是一个接口引理，不是从标准 dPCP 定理自动得到的定理。若只有 list/unique
decoding 的平均保证，仍需先证明其 no-instance 版本确实给出第 2 条的固定 verifier gap。

## 3. 为什么它还不能直接接入 RW Theorem 4.1

RW Theorem 4.1 的 Solve_f 并不是把任意 proof table 交给 J--K：它先用 Theorem 3.5
为计算 \(f\) 构造一个固定的 computation-history PCP \(\Pi_x\)，再运行
\(\operatorname{JK}(G,\Pi_x)\)。failure 只保证这个特定 \(\Pi_x\) 有小电路。标准
dPCP/udPCP 定理分别给出各个 \(\varphi_{x,i,b}\) 的 proof，并没有证明

\[
  \Pi_x=P_x
  \quad\text{或}\quad
  \Pi_x\text{ 含有可由同一地址电路统一读取的 }P_x\text{ 区段}.
\]

把 \(f\) 改成“输出 \(P_x\)”也不能绕过这一点：Theorem 3.5 随后编码的是“计算 \(P_x\)”
的 history，而不是 \(P_x\) 本身。要把上述条件性查询变成 RW 的真实 Reconf，必须新增一个
compositional history compiler，保证拼接 dPCP proof 是 J--K 的 hard table，并保留
failure、small-circuit 和 smart-prMA 的同一量词。当前近线性 dPCP/udPCP 文献没有提供这一
嵌入接口；其定义与参数只能支持“表示层变短”的判断。

## 4. 路线裁决

* **已证的负面：** 纯坐标复制不能提供固定坐标 gap。
* **已证的条件性正面：** 若存在上述 compositional history compiler，则按
  \((i,b)\) 拼接 dPCP proof 可消除 lex-prefix 搜索，并保持一个全局 word-consistent
  proof circuit。
* **当前未证的核心：** 该 compiler 是否能在 RW 的
  \(\operatorname{poly}(k,r,\log t)\) 查询预算、J--K failure 语义和同一地址空间下实现。

因此下一步应证明或否定 compositional history compiler；不应再把“复制平均坐标”作为
独立路线，也不应把 Theorem 3.12/Lemma 4.2 直接写成 RW Theorem 4.1 的替代品。

## 5. 证据边界

近线性 dPCP/udPCP 的原始定义和定理来自
[Gur--Min--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/html/2512.12960)。
本 note 的拼接引理是由这些定义加上第 2 节四条额外接口假设推导出的条件性结果；
它不是该论文已经声明的 theorem。外部 Downloads 报告的固定 PH-local merge、量词和
rank 信息率筛选已在 [note 092](092-2026-08-15-chatgpt-pro-report-absorption-and-route-triage.md)
按证据边界吸收；本 note 不把报告中的未核验阶段编号、计数或回写状态当作数学依据。
