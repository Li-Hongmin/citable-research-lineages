> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Query-family/state tradeoff for adaptive oracle transcripts (2026-08-24)

## Theorem

Let \(A_n=\mathcal L_{\mu_H,n}\) on \(N=2^n\)-bit source tables. For each \(n\), let
\(M_n^O\) be a \(q_N\)-state oracle RTM with one fixed source-independent bit oracle
\(O\subseteq\{0,1\}^\ast\), running for
\[
t=N^{b+o(1)}
\]
steps (pad to \(t\ge N\)). Let \(\mathcal Q_N\) be the set of all query strings that can occur
over all source inputs, random tapes, and adaptive answer paths for this fixed machine and oracle,
and put \(D_N=|\mathcal Q_N|\). If \(M_n^O\) decides \(A_n\) exactly or with fixed bounded
error, define
\[
\rho_q=\limsup_{N\to\infty}
\frac{\log(1+\log_2 q_N)}{\log N},
\qquad
\rho_{\mathcal Q}=\limsup_{N\to\infty}
\frac{\log(1+\log_2 D_N)}{\log N}.
\]
Then
\[
\boxed{
\frac{\max\{1,b\}}2+\max\{\rho_q,\rho_{\mathcal Q}\}\ge\mu_H,
}
\qquad\text{equivalently}\qquad
\boxed{
\max\{1,b\}+2\max\{\rho_q,\rho_{\mathcal Q}\}\ge2\mu_H.
}
\]

If all queries have length at most \(\ell_N=N^{\delta+o(1)}\), then
\(D_N\le 2^{\ell_N+1}\), so \(\rho_{\mathcal Q}\le\delta\) and Corollary 23 follows. The
query-family form can be strictly stronger when long queries are drawn from a small structured
family.

## Proof

Fix a constant fooling error. For each fixed coin sequence, CHMY Lemma 22 hardwires the query
string and its oracle answer into the finite control. Restricting the query strings to
\(\mathcal Q_N\) gives a DTM with at most
\[
q_N\cdot 2D_N\cdot t
\]
states. CHMY's local-PRG theorem therefore supplies a generator whose seed length is
\[
\widetilde O\!\left(
(\sqrt t+O(1))\log(q_ND_Nt)
\right).
\]
Since
\[
\log(q_ND_Nt)
=N^{\max\{\rho_q,\rho_{\mathcal Q},0\}+o(1)},
\]
the generated \(N\)-bit tables have circuit complexity
\[
N^{\max\{1,b\}/2+\max\{\rho_q,\rho_{\mathcal Q}\}+o(1)}
\]
in the CHMY MCSP argument. If that exponent were below \(\mu_H\), every generator output
would lie in \(A_n\), while a uniformly random source table lies in \(A_n\) with probability
\(o(1)\) by circuit enumeration. Exact or bounded-error decision gives a constant
distinguishing gap, contradicting the PRG guarantee.

The query set may depend on the fixed source-independent oracle \(O\); no effectiveness of
\(\mathcal Q_N\) is required for the existence argument. The generator depends only on the
resulting state bound, not on oracle answers.

## Sharpness and scope

The factor \(D_N\) is a genuine refinement of a maximum-length bound: \(D_N\) can be polynomial
even when query strings have large formal length. The maximum in the exponent is forced by
\(\log(q_ND_Nt)=\log q_N+\log D_N+\log t\); it is not a sum of \(\rho_q\) and
\(\rho_{\mathcal Q}\). This is sharp at the CHMY hardwiring interface, not a claim that every
state/query family realizes the MCSP lower-bound endpoint.

Polynomial \(q_N\) or polynomial \(D_N\) has zero exponent contribution. A fixed advice string
for one length is not automatically charged; advice-dependent source access, hidden RAM, or a
free multi-bit answer is outside the fixed-oracle model. Finite collections of fixed relations
can be tagged into one oracle. A source-dependent oracle \(O_f\) is not covered.

## Source

Cheraghchi, Hirahara, Myrisiotis, and Yoshida, *One-Tape Turing Machine and Branching Program
Lower Bounds for MCSP*, STACS 2021, Lemma 22 and the oracle local-PRG corollary,
DOI: [10.4230/LIPIcs.STACS.2021.23](https://doi.org/10.4230/LIPIcs.STACS.2021.23).
