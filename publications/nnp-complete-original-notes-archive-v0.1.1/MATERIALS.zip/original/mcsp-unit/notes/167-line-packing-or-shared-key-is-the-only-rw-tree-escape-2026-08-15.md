> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW tree closure 的二选一参数边界：line packing 或 shared key（2026-08-15）

## 命题范围

本 note 把 notes 127--132 的正向构造与容量障碍合成为一个条件性参数定理。它不
声称已排除所有 PCP 编码，只分析两种明确的闭合机制：

1. 逐层串接每个 line restriction 的系数描述；
2. 用一个共享 history key 和随机访问电路共同生成所有 blocks。

令当前 JK/AVOID seed 长度为 \(k\)，每个输出 block 长度为 \(2k\)，固定 PCP
history 长度为 \(P\)。按 JK 对齐后可得到

\[
M:=\left\lfloor \frac{P}{2k}\right\rfloor
\]

个 leaf occurrences；若 \(M\) 足够大，完整二叉树的深度为
\(H=\lfloor\log_2 M\rfloor\)。设单个 line restriction 的独立系数描述长度为
\(d(k)\) bits。对 note 127/129 的半率 Reed--Muller/FFT primitive，

\[
d(k)=\Theta\!\left(\frac{k}{\rho(k)}\right),
\qquad
\rho(k)=\operatorname{polylog}k.
\tag{1}
\]

这里的 \(d(k)\) 只描述一条 line；它不是完整 PCP history 的长度。

## 逐层 coefficient packing 的上界

假设每个 child label 只是其 line coefficient description 的串接，且在某一层
有 \(2^h\) 个彼此独立的 line descriptions。一个 parent seed 只有 \(k\) bits，
因此保持同一 range 的必要条件是

\[
2^h d(k)\le k+O(\log k).
\tag{2}
\]

代入 (1) 得

\[
h\le \log_2\rho(k)+O(1)=O(\log\log k).
\tag{3}
\]

所以 line-level half-rate decoder 最多支持对数对数级深度；它本身不能覆盖
拥有 \(\Theta(\log k)\) 层的完整 JK tree。若要求整棵实际 history 的所有
line coefficients 都能由同一个 root seed 通过这种串接机制恢复，则还需

\[
M\,d(k)\le k+O(\log k),
\]

即

\[
P\le O\!\left(\frac{k^2}{d(k)}\right)
 =O\!\left(k\,\rho(k)\right).
\tag{4}
\]

式 (4) 是 line-packing 路线的必要条件，不依赖 JK 的 lex-first 细节。

## 代入 RW 参数

在 RW 稳定区，通常 \(T_i\asymp k=n_{i+1}\)，而 Theorem 3.5 只给出
\(P\le T_i^a\) 的 polynomial upper bound；Harsha 的具体 auxiliary-oracle
展开也是 \(T_i^{\Theta(1)}\) 量级，而不是 \(k\operatorname{polylog}k\)。

因此只要实际 proof 长度满足

\[
P=\omega\!\bigl(k\,\rho(k)\bigr),
\tag{5}
\]

就不能用 (4) 把所有独立 line descriptions 放进一个 \(k\)-bit root seed。
若 \(P=k^{1+\varepsilon}\)，则

\[
H=\Theta(\log k),\qquad
\log_2(k/d(k))=O(\log\log k),
\]

两者存在渐近间隔。这里的结论是：继续优化 additive FFT 只能改善
\(\rho(k)\) 的 polylog 因子，不能消除 (5) 所造成的深度缺口。

## 第二条路线：shared key + whole-block accessor

若不逐 line 串接，而是假设存在一个共享 key \(\sigma_x\) 和统一的完整 block
accessor

\[
\widehat A(\sigma,j)\in\{0,1\}^{2k},
\qquad
|\widehat A|=k\operatorname{polylog}k,
\]

并且 \(\widehat A(\sigma_x,j)=A(x,j)\)，所有 \(M\) 个 blocks 都由同一个
\(\sigma_x\) 和地址 \(j\) 生成，则只需

\[
|\sigma_x|+\lceil\log_2 M\rceil+O(1)\le k.
\tag{6}
\]

在这一条件下，note 131 的 tagged leaf/internal decoder 给出真正的
word-consistent tree closure：

\[
G(\operatorname{leaf}(\sigma_x,j))=\widehat A(\sigma_x,j),
\]

\[
G(\operatorname{int}(\sigma_x,v))
 =\operatorname{int}(\sigma_x,v_0)\Vert
  \operatorname{int}(\sigma_x,v_1).
\tag{7}
\]

因此，RW 路线若要避开 (4)，必须证明一个长度至多 \(k\) 的 shared key、一个
\(k\operatorname{polylog}k\)-size 的 P-uniform whole-block accessor，以及
lex-first/choice-robust 的同一 preimage 语义。Theorem 3.5 当前只给出
\(\operatorname{poly}(T_i)^{NP}\) 级 proof generation，没有给出这些对象。

## 为什么全局 RM tensor 不是 shared key

把完整低度多项式的 coefficient tensor 作为 shared key，需要在**覆盖所有
degree-bounded value tables、且没有额外压缩**的 generic 情形下区分
\(|H|^m\) 个自由 field values。对 RW 参数，令 \(t'_i\) 为 \(C_x\) 的大小，则

\[
|H|^m=\Theta(t'_i),\qquad t'_i\ge T_i\ge k,
\qquad
|\sigma_x|=\Omega(t'_i\log|F|)
\ge\Omega(T_i\log|F|)>k.
\tag{8}
\]

这违反 Theorem 4.1 中 AVOID seed 长度 \(k\le T_i\) 下的剩余预算；它是
time-scale global labeler（note 130），不是 base-\(k\) shared key。
式 (8) 是覆盖所有自由 tensor 的 generic 信息下界；对单个 canonical history，
可能存在更短的描述，因此不能把它单独升级为固定 history 的无条件 lower bound。

## 量词与边界

式 (2)--(4) 需要“line coefficients 在相应 occurrences 上独立可选”的前提。
若实际 PCP history 具有更强的跨 line 相关性，则可以绕开该计数；但必须把相关性
写成一个满足 (6)--(7) 的显式 shared-key/accessor 构造。低度性或单个 leaf
evaluation 并不自动提供这种相关性。

反过来，式 (6)--(7) 只是充分接口，不是已知构造。若 accessor 暴露一个高硬度
systematic coordinate，它还会触发 note 131 的直接复杂度矛盾；因此 shared key
必须同时保持 history 的 hardness、smartness 与 canonical/choice-robust 选择。

综上，当前可核验的二选一是

\[
\boxed{
\begin{array}{l}
\text{(A) canonical proof 长度 }P\le k\operatorname{polylog}k
\text{，再做 line packing；或}\\
\text{(B) 长度 }\le k\text{ 的 shared key + }k\operatorname{polylog}k
\text{ whole-block accessor。}
\end{array}}
\]

这不是 \(P\ne NP\) 的证明，但把剩余工作从“优化 decoder”收缩为两个可证伪的
结构性目标。

来源：Ren--Williams TR26-118 rev.1 Theorems 3.4--4.1；notes 127--132。
