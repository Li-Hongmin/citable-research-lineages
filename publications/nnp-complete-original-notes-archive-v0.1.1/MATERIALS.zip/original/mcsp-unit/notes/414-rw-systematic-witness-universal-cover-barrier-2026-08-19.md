> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW systematic witness 的 universal recursive-cover barrier（2026-08-19）

## 本轮改变的判断

C412 把 exact JK recursive cover 所需的 leaf correlation 定位为
```
sum leaf entropy - k.
```
C413 又把这笔 correlation 转成了 latent seed budget，但此前仍缺少一个能直接
落到 RW/Harsha history 的 source family。这里用 Ren--Williams Lemma 3.2 的
history 量词构造一个最小 source family：每个 NP query 都有唯一 witness，且
所有 query witness 同时出现在同一个 canonical assignment 中。于是任意声称

* 使用同一个 \(G_k\) 和 exact recursive cover；
* 只用 \(d\)-bit latent seed 产生 conditional-product leaves；
* non-output leaves 仍确定整个 canonical witness；

的 target-oblivious common-proof architecture 必须支付整个 \(qs\)-bit witness
payload。其必要条件是

\[
  qs\le k+(m-1)d,
\]

其中 \(m\) 是 recursive-cover 的 leaf 数。更一般地，若 policy \(S\) 已经携带
\(I(X;S)\) bits 的 source information，则正确的界是

\[
  qs-I(X;S)\le k+(m-1)d.
\]

因此这个结果不是把公开输入熵偷偷当成 hidden entropy：若 decoder 直接读取
\(X\)，则 \(I(X;S)=qs\)，该界按预期退化。

## RW source family

固定整数 \(q,s\ge1\)。令

\[
  X=(U_1,\ldots,U_q)\in(\{0,1\}^{s})^q
\]

均匀随机。定义一轮 NP-query machine \(M_{q,s}\)：输入为 \(X\)，第 \(j\) 个
query 的公开 query string 包含 \(U_j\)，其 NP relation 只有一个接受 witness，
即 \(w=U_j\)。所有 \(q\) 个 query 都被接受，machine 输出固定的 \(0\)；运行
时间和 query 数均为 \(\operatorname{poly}(qs)\)，每个 witness 长度为 \(s\)。

因此每个 query 的 lexicographically largest witness 仍是唯一的 \(U_j\)。按
Ren--Williams Lemma 3.2 的 history 顺序

\[
  (y_1,\ldots,y_r,\mathrm{out},z_{1,1},\ldots,z_{r,t}),
\]

本例 \(r=1,t=q\)，canonical satisfying assignment 的 history 部分为

\[
  \alpha_X=(y_1=q,\mathrm{out}=0,U_1,\ldots,U_q).
\]

除固定的 \(q,0\) 外，\(\alpha_X\) 恰好包含 \(X\)，所以

\[
  H_2(\alpha_X\mid S)=H_2(X\mid S)=qs-I_2(X;S).
\tag{414.1}
\]

这里的 machine 只是一个 source-level stress family，不是 published Theorem 4.3
的固定 singleton \(x_0\)。Theorem 3.5 的 PCP construction 会把该 canonical
assignment 放入 systematic Reed--Muller witness prefix；因此若一个 proposed
RW/Harsha cover 的 non-output leaves 能恢复该 prefix 中的 witness，条件
\(\alpha_X=\psi(L)\) 是明确可核验的 source obligation，而不是把不同坐标的
phantom witness 拼在一起。

### Visibility boundary for the stress family

这个 family 有一个必须保留的可见性边界：第 \(j\) 个 query string 明文包含
\(U_j\)，所以 query transcript \(Q\) 本身已经确定 \(X\)。更一般地，固定的
NP relation 给每个 query 取唯一 witness，或取 lexicographically largest
canonical witness 时，
\[
  W=\operatorname{Can}(Q)
\]
是 query transcript 的确定函数，故 \(H_2(W\mid Q)=0\)。若 policy \(S\)
能恢复 \(Q\) 或 \(W\)，并且 \(W\) 是 source \(X\) 的确定函数，则数据处理给出
\[
  I_2(X;S)\ge I_2(W;S)=H_2(W).
\tag{414.1a}
\]
在本例 \(W=X\) 时，package 若看见公开 query/context 就已经支付 \(qs\) bits；
这时 (414.3) 的 target-oblivious 假设不成立。因而 C414 的非平凡用途只在
两种语义下保留：package 不可见 query/context、而 leaves/seed 自己承担 witness
payload；或者 source family 有一个尚未被公开 query transcript 解释的新全局关系。
这正是 C406 的 public-context entropy bound 在 query-level 的特化，而不是一个
额外的 hidden-witness 来源。

## 定理 414.1（systematic-witness universal-cover barrier）

固定 \(G_k:\{0,1\}^{k}\to\{0,1\}^{2k}\)，令 \(R=\operatorname{Range}(G_k)\)，
并用其 canonical inverse 在深度 \(d_\mathrm{tree}\) 的完整二叉树上定义 exact JK
recursive cover；记叶数为 \(m=2^{d_\mathrm{tree}}\)，叶 tuple 为

\[
  L=(L_v)_{v\in\mathcal L}.
\]

令 \(S\) 是 policy/descriptor，令 \(\sigma\) 是 latent seed。假设：

1. 所有内部 block 对几乎处处的 \((L,S)\) 都在 \(R\)，即 recursive cover exact
   成立；
2. non-output leaf tuple 确定 canonical witness，存在确定函数
   \(\alpha_X=\psi(L)\)；
3. 给定 \((S,\sigma)\) 后，叶 blocks \(L_v\) 相互独立；
4. \(H_2(\sigma\mid S)\le d_\mathrm{seed}\)。

则

\[
\boxed{
  qs-I_2(X;S)-k
  \ \le\ \operatorname{TC}_2(L\mid S)
  \ \le\ (m-1)d_\mathrm{seed}.
}
\tag{414.2}
\]

特别地，若 \(S\) target-oblivious（\(I_2(X;S)=0\)），且 seed 只有 \(d\) bits，
则任何这样的 common-proof architecture 必须满足

\[
\boxed{qs\le k+(m-1)d.}
\tag{414.3}
\]

若 \(S\) 是至多 \(b\)-bit 的 target-dependent descriptor，则

\[
  qs\le k+b+(m-1)d.
\tag{414.4}
\]

### 证明

由 \(\alpha_X=\psi(L)\) 和数据处理，

\[
  H_2(L\mid S)\ge H_2(\alpha_X\mid S)
  =qs-I_2(X;S).
\tag{414.5}
\]

总相关性的定义给出

\[
  \sum_{v\in\mathcal L}H_2(L_v\mid S)
  =H_2(L\mid S)+\operatorname{TC}_2(L\mid S)
  \ge qs-I_2(X;S).
\tag{414.6}
\]

另一方面，C412 的 recursive-cover tree-correlation inequality 给出

\[
  \operatorname{TC}_2(L\mid S)
  \ge \sum_vH_2(L_v\mid S)-k.
\tag{414.7}
\]

合并 (414.6)--(414.7) 得到左侧。C413 的 latent-seed budget 在条件独立假设下
给出

\[
  \operatorname{TC}_2(L\mid S)
  \le (m-1)H_2(\sigma\mid S)
  \le(m-1)d_\mathrm{seed},
\tag{414.8}
\]

从而得到 (414.2)。target-oblivious 情形得到 (414.3)；若 \(S\) 是 \(b\)-bit
descriptor，则 \(I_2(X;S)\le H_2(S)\le b\)，得到 (414.4)。证毕。

## 直接解释

### 1. 关闭的架构分支

对这个 source family，以下三件事不能同时成立，除非满足 (414.3)/(414.4)：

1. address-scale 的 target-oblivious policy 和 common \(G_k\)；
2. 一个 \(d\)-bit seed 加独立 local randomness 生成所有 non-output leaves；
3. 所有 JK ancestors exact in-range，且 leaves 仍确定 systematic canonical witness。

例如 \(qs>k+(m-1)d\) 时，必须至少放弃一项：让 descriptor 携带 source
information、让 seed 变成 message-scale、引入 seed 之后仍存在的高阶 non-product
global relation，或放弃 exact recursive closure。

### 2. 这不是 singleton impossibility

published RW Theorem 4.3 的应用固定 \(x_0\)，并且 \(f_i\) 忽略输入；那是 singleton
对象，不能从本定理的 uniform \(X\) 熵直接推出矛盾。即便在本 stress family 中，
decoder 把公开 \(X\) 全部放进 \(S\)，也会得到 \(I(X;S)=qs\)，此时 (414.2) 不再
施加有内容的 payload lower bound。因而本定理是 target-oblivious common-proof
family barrier，而不是对 published singleton 的自动否定。

### 3. 对 actual Harsha/RW application 的四项 obligation

要把 (414.3) 变成 actual RW/Harsha 的 source theorem，还必须独立核验：

* **leaf partition**：所有 \(U_j\) 对应的 systematic witness bits 确实落在
  non-output recursive leaves，而不是 output/policy 区段；
* **deterministic recovery**：这些 leaves 的 tuple 真能确定同一个 canonical
  assignment，而非每个 coordinate 使用不同 accepted witness；
* **closure quantifier**：同一个 \(G_k\) 的每一级 canonical preimage 都在 range，
  并且失败概率是否为零（若只是 approximate cover，需使用 C412 的
  \(h_2(\delta)+(1-\delta)k+2km\delta\) 修正）。
* **query visibility**：若 actual package 能读取生成这些 witnesses 的公开 query
  transcript，则按 (414.1a) 将其 information 计入 \(S\)，不能再把该 family
  当作 target-oblivious hidden source。

在这四项没有完成前，(414.3) 只能作为 universal stress-test barrier，不能写成
“RW 已经不可能”。

## 与闭合路线的关系

* C411 说低 target channel 时必须支付 global residual correlation；
* C412 把该 correlation 精确定位到 JK recursive leaf tuple；
* C413 说明若 correlation 只经一个 latent seed 产生，就有 seed budget；
* C414 首次把 systematic-witness entropy \(qs\) 接到 actual RW/Harsha history
  量词，形成 source-level universal cover barrier。

所以当前 Gate-II 的 recursive-cover 逃逸被进一步压缩为：

\[
\text{short conditional-product seed}
\Longrightarrow (414.3)/(414.4),
\qquad
\text{其余方案}
\Longrightarrow
\text{必须展示新的 non-product global relation}.
\]

本 note 不证明 simultaneous coordinate-robust dPCP 不可能，也不证明
\(P\ne NP\)。它给出的是一个可直接检验的 RW source-family necessary condition；
一旦 actual leaf partition、same-proof witness binding 和 exact closure 被证明，
该条件才会晋级为 actual application 的 barrier theorem。

## 证据边界

* Ren--Williams Lemma 3.2：history 同时包含 round counts、output 和每个 NP query
  witness；
* Ren--Williams Theorems 3.4--3.5：PCP proof 的 systematic Reed--Muller prefix
  包含 satisfying assignment，并继承 history 的 \((pfx,out)\) 前缀；
* C406：公开 context 不能被当作 hidden target entropy；本 note 的 (414.1a) 是其
  canonical-query 特化；
* C412：exact recursive cover 的 tree-correlation inequality；
* C413：conditional-product leaves 的 latent-seed budget。

原文核对文件：
`units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md`，
Lemma 3.2、Theorems 3.4--3.5。该 stress family 和 (414.2) 是本项目的新推导，
不是 Ren--Williams 原文定理。
