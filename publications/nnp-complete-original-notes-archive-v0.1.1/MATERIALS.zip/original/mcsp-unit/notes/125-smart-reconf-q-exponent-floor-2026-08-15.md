> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Smart-Reconf 的 q 指数下限（2026-08-15）

## 定理（条件性参数下限）

采用 Ren--Williams Theorem 4.1 的记号。设
\[
 f_n:\{0,1\}^{n}\longrightarrow\{0,1\}^{t(n)}
\]
由固定的 SAT-oracle machine 计算；设 \(q(n)\) 是 AVOID 输入长度，
\(r(n)\) 是 adaptive-round 参数。假设：

1. 当候选 SAT 机器 \(A\) 正确时，相关 forcing 给出
   \[
   \operatorname{CC}(f_n)>n^{k(n)}
   \tag{1}
   \]
   （或对某个由 \(f_n\) 直接抽取的 stitched slice 给出同样下界）；
2. Theorem 4.1 的 \(\operatorname{Reconf}(x,i)\) 对每个实际 query 都保持
   smart-\(\mathrm{prMA}\) promise；
3. \(r(n)\le q(n)^d\)、\(t(n)\le q(n)^d\)，且 Reconf 的 query 描述长度与总执行时间
   都至多 \((q+r+\log t)^c\)，其中 \(c,d\) 是固定常数。

则在假设 \(P=NP\) 下，必有
\[
 q(n)=\Omega\!\left(n^{\,k(n)/D}\right)
 \tag{2}
\]
对某个固定常数 \(D\)（只依赖机器与参数编码）。特别地，当
\(k(n)\to\infty\) 时，\(q(n)\) 不可能是 \(n^{O(1)}\)。

更直接地，不把 \(r,t\) 吸收到 q 中时，存在固定 \(C\) 使
\[
 t(n)\,(q(n)+r(n)+\log t(n))^{C}>n^{k(n)}.
 \tag{3}
\]

## 证明

在 \(P=NP\) 假设下，\(PH=P\)。每个 smart-\(\mathrm{prMA}\) query 的 YES
条件可写成
\[
\exists w\;\forall z\;B(w,z)=1,
\]
这是固定 \(\Sigma_2^P\) 谓词；在 promise 的 NO 侧，所有 \(w\) 至多在半数
随机串上通过，因此该谓词为假。故存在一个固定确定性算法，在 query 描述长度的
多项式时间内回答 Reconf 实际发出的所有 query。

逐次替换这些 oracle answers，得到每个输出位
\(f_n(x)_i\) 的确定性电路，大小至多
\[
\bigl(q+r+\log t\bigr)^C.
\]
把 \(t(n)\) 个 bit-circuit 并列连接，得到 multi-output 电路
\[
\operatorname{CC}(f_n)
\le
t(n)\bigl(q(n)+r(n)+\log t(n)\bigr)^C.
\tag{4}
\]
与式 (1) 比较即得式 (3)。若 \(r,t\le q^d\)，则对 \(q\ge2\) 有
\[
n^{k(n)}
<
t\bigl(q+r+\log t\bigr)^C
\le O\!\left(q^{d(C+1)}\right)
\]
从而可取 \(D=d(C+1)\) 的某个固定倍数，得到式 (2)。证毕。

## 含义

这条下限不是对任意 decoder 的无条件 gate lower bound；它是：

\[
\boxed{
\text{若 forcing hardness 与 smart-Reconf 同时成立，}
\;q\text{ 的超多项式增长在 }P=NP\text{ 假设下是被迫的。}
}
\]

因此，单纯把 Theorem 4.1 的算法重新编码、或把 q-bit query 换成另一种
等价语法，不能得到输入尺度 \(n^{O(1)}\) 的 \(P=NP\) 反证。真正需要的新内容
必须改变至少一项：

- 让 query 的有效复杂度不随 q 的描述长度多项式增长；
- 让 forcing 输出的硬函数不是由 \(t\) 个 Reconf bit-circuits 直接拼接；
- 或利用额外的 range/JK 结构，在不逐位确定化 Reconf 的情况下构造
  \(n^{O(1)}\)-size easy circuit。

最后一项正是 note 121/123 的未解决正向接口；本定理把其必要性定量化。

## 文献边界

Ren--Williams Theorem 4.1 确实给出
\(\operatorname{Reconf}\) 的 q-scale smart-\(\mathrm{prMA}\) 算法，但没有给出
式 (3) 所需的 q 到 n 的压缩。来源：
[official report](https://eccc.weizmann.ac.il/report/2026/118/revision/1/download)。

本文不声称已经证明 \(P\ne NP\)；式 (2)--(3) 是在 forcing 假设与
\(P=NP\) 反设下的参数障碍。
