> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# AEKR 最大仿射叶界的显式反例（2026-08-13）

## 结论

在当前碰撞定义下，四轨道约化后的最大叶命题

\[
 \Pr_{r,t}\bigl[\exists T\in\mathcal T:T\subseteq R_{r,t}\bigr]\le \frac14
 \tag{AEKR\(_0\)}
\]

是假的。这里碰撞允许任意不交奇子集 \(I,J\) 满足
\(\bigoplus_{i\in I}x_i=\bigoplus_{j\in J}y_j\)。

## 反例

取 \(N=3\)，用三位二进制整数表示向量，令

\[
 X=\{1,3,4,5,6,7\},\qquad Y=\{0,2\},
 \qquad s=(3,2).
\]

在 \(X\times Y\) 中定义五个三元组（第二坐标均为 \(0\)）：

\[
\begin{aligned}
T_1&=\{(1,0),(4,0),(7,0)\},\\
T_2&=\{(1,0),(5,0),(6,0)\},\\
T_3&=\{(3,0),(4,0),(5,0)\},\\
T_4&=\{(3,0),(6,0),(7,0)\},\\
T_5&=\{(5,0),(6,0),(7,0)\}.
\end{aligned}
\]

它们两两相交；例如

\[
\begin{array}{c|cccccccccc}
\{i,j\}&12&13&14&15&23&24&25&34&35&45\\ \hline
T_i\cap T_j
&(1,0)&(4,0)&(7,0)&(7,0)&(5,0)&(6,0)&\{(5,0),(6,0)\}&(3,0)&(5,0)&\{(6,0),(7,0)\}.
\end{array}
\]

每个 \(T_i\cup\{s\}\) 都是 odd--odd affine collision：

* \(i=1,2,3,4\) 时，三个 \(T_i\) 的第一坐标异或均为
  \(2=y_s\)，故取 \(I=T_i\)、\(J=\{s\}\)；
* \(i=5\) 时，三行异或不是 \(y_s\)，但仍有合法的奇奇分解：
  \[
  5\oplus6\oplus3=0=0,
  \]
  左侧对应 \((5,0),(6,0),s=(3,2)\)，右侧取
  \(J=\{(7,0)\}\)。

两侧指标集均为奇数，且互不相交。因此该族满足 AEKR 的全部形式假设，尽管它是一个退化的“共同列”族。

## 完整参数枚举

仿射叶由
\[
R_{r,t}=\{(x,y):r\cdot x=t,\ r\cdot y=1-t\},
\qquad (r,t)\in\mathbb F_2^3\times\mathbb F_2
\]
给出。因为每个 \(T_i\) 的列坐标为 \(0\)，命中它必有 \(t=1\)。逐一解三个线性方程得到：

\[
\begin{array}{c|ccccc}
T_i&i=1&i=2&i=3&i=4&i=5\\ \hline
r&7&3&6&2&4
\end{array}
\]

这五个 \(r\) 两两不同，且其余 \(11\) 个 \((r,t)\) 不命中任何 \(T_i\)。故

\[
\Pr_{r,t}[\exists i:T_i\subseteq R_{r,t}]
 =\frac5{16}>\frac14.
\]

所以 notes 024 中把 AEKR\(_0\) 保留为待证命题的做法已被本反例取代；四轨道约化本身仍然正确，但不能再依靠最大叶 \(1/4\) 界完成原始 thinning 界。

## 对原始（含 thinning）AEKR 的影响

该反例尚未反驳完整的
\[
\Pr_{r,t,U,V}[\exists T_i:T_i\subseteq R(U,V)]\le\frac1{16}
\]
因为五个命中叶各自需要保留三行和共同的一列，故其完整命中概率为
\[
\frac5{16}\cdot\frac1{2^4}=\frac5{256}<\frac1{16}.
\]
因此当前严格结论是：

\[
\boxed{\text{AEKR\(_0\) 已反驳；含 thinning 的 AEKR 仍未判定。}}
\]

后续若要保留这条路线，必须直接分析 thinning 后的联合事件，或对碰撞族加入非退化语义条件；不能再先假设最大叶命中率至多 \(1/4\)。
