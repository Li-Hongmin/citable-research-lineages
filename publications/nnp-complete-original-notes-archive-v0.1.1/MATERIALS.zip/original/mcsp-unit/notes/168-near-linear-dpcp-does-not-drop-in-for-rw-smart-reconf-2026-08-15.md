> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 近线性 dPCP/udPCP 不能直接替代 RW 的 canonical smart-Reconf（2026-08-15）

## 结论

本 note 核验一个最可能改变当前路线判断的替代物：用近期的近线性 decodable PCP
(dPCP) 或 uniquely-decodable PCP (udPCP) 替代 Ren--Williams (RW) 中带
Reed--Muller systematic prefix 的 PCP history。

结论分成正负两部分：

1. 近线性表示层确实存在。Gur--Min--Weissenberg--Zheng 的 Theorem 3.12 给出
   对电路 SAT 的 2-query dPCP，长度 \(O(N\log ^C N)\)、常数 alphabet、perfect
   completeness 和 \((L,\varepsilon)\)-list-decoding soundness；其 Lemma 4.2 给出
   长度 \(O(N\operatorname{polylog}N)\) 的 projection、left-canonical udPCP，且有
   perfect completeness 与 unique-decoding soundness。原始定义和定理见
   [Gur--Min--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/html/2512.12960)，
   Definitions 3.6--3.10、Theorem 3.12、Lemma 4.2。
2. 这些性质不构成 RW 所需的 **同一 canonical history 的 smart prefix/bit oracle**。
   dPCP 的 list soundness 是对随机 \(t\) 的平均量词，udPCP 的 unique soundness
   也是对平均 decoding coordinate 的近似；两者都不保证某个固定 output coordinate
   的错误声明落在 prMA 的 NO 侧。left-canonical 只是在固定右邻域标记时局部唯一确定左标签，
   不唯一确定全局 assignment、proof 或 lexicographically largest witness。

因此，dPCP/udPCP 目前只能登记为“近线性约束/解码表示层”；要接入 RW，必须另证下面的
coordinate-robust 接口（第 5 节），而不是把 Theorem 3.12 或 Lemma 4.2 直接替换进
Theorem 4.1。

## 1. 与 RW 目标的逐项对齐

RW 对固定输入 \(x\) 构造 circuit \(C_x\)，其满足 assignment 编码一个完整 computation
history。令 \(\alpha_x\) 是其 lexicographically largest satisfying assignment，令
\(\operatorname{out}_i(\alpha_x)=f(x)_i\)。Theorem 4.1 的 Reconf 在 AVOID/JK failure
分支中需要对同一小电路所表示的 PCP proof 逐位查询，并保证每个实际 query 都在
prMA promise 内。

若把 \(C_x\) 交给 Theorem 3.12 的 dPCP，得到的是：

\[
  \forall w\in\operatorname{SAT}(C_x)\ \exists T_w
  \quad T_w\text{ 完全满足且解码为 }w,
\]

以及对任意 assignment \(T\)，存在至多 \(L\) 个合法词 \(y_1,\ldots,y_L\)，使

\[
 \Pr_{t,e}\bigl[\Phi_e(T(e))=1\ \land\ D_t(T(e))\notin
       \{(y_1)_t,\ldots,(y_L)_t\}\bigr]\le\varepsilon .
\]

udPCP 的对应 soundness 是：若 \(T\) 在至少 \(1-\varepsilon\) 比例的边上满足约束，
则存在某个 \(w\in\operatorname{SAT}(C_x)\)，使平均 decoding error 至多 \(\eta\)。
这两个量词都没有给出 RW 所需的

\[
\exists\text{ 一个固定 }T_x^*\quad
\forall i\quad D_i(T_x^*)=\operatorname{out}_i(\alpha_x)
\]

以及对每个错误的固定 \(i\) 的常数拒绝概率。

## 2. 固定坐标 soundness 的严格反例

平均 dPCP soundness 不能推出固定坐标的 prMA-NO promise。取 \(n\ge 1/\varepsilon\)，
\(\mathcal L=\{0^n\}\)。构造一个玩具 dPCP：取一个承载符号 \(a\) 的顶点和一个
dummy 顶点，用一条恒真约束边（或恒真自环）连接它们；assignment 的自由部分只有
\(a\in\{0,1\}\)，解码器定义为

\[
D_1(a)=a,\qquad D_t(a)=0\quad(t>1).
\]

符号 \(a=0\) 给出 perfect-complete proof，解码为 \(0^n\)。对任意 assignment，取合法列表
\(\{0^n\}\)：当 \(a=1\) 时，事件 \(D_t(a)\ne(0^n)_t\) 只在 \(t=1\) 发生，故其平均
概率为 \(1/n\le\varepsilon\)。这满足 dPCP 定义的 list soundness，但固定坐标查询

\[
\text{“约束通过且 }D_1(a)=1\text{”}
\]

在 assignment \(a=1\) 上以概率 \(1\) 接受，尽管 \(\mathcal L\) 中没有任何词的第一个 bit
为 \(1\)。

同一现象可以放进 left-canonical 的 udPCP：取 \(n\ge1/\eta\) 且一个二分图 \(A\)--\(B\)，唯一约束为
projection equality \(\Phi(a,b)=1\iff a=b\)，并令 \(D_1(a)=a\)、\(D_t(a)=0\)
\((t>1)\)。给定右邻居标签时左标签至多一个，故它是 left-canonical；但两个全局标签
\((a,b)=(0,0)\) 与 \((1,1)\) 都完全满足。后者只在 \(1/n\) 的 decoding coordinate
上偏离合法词 \(0^n\)，所以只要 \(\eta\ge1/n\) 就不违反 unique-decoding soundness。
left-canonical 是局部约束的唯一性，不能排除此现象。

所以把 dPCP decoder \(D_i\) 直接放进 RW 的最终 query，不能证明当
\(f(x)_i=0\) 时 query 在 NO promise；把前缀 \(p\circ1\) 换成若干固定坐标检查也只把
错误概率稀释到 \(1/|p|\)，除非另有坐标放大/robust outer check。

## 3. 每轮重新编译 prefix 的量词断裂

看似自然的旁路是每轮把

\[
C_{x,p}=C_x\land[\text{witness has prefix }p\circ1]
\]

重新编译成一个 dPCP/udPCP，再用 perfect completeness 判断该 prefix 是否可扩展。
这确实可以得到“每个 prefix 实例分别有一个近线性 PCP”的陈述，但不是 RW 的
drop-in replacement：

* JK failure 只给固定的 \(\Pi_x\) 一个小电路描述；它不控制重新编译得到的
  \(\Pi_{x,p}\) 的 circuit complexity、地址空间或 auxiliary labels。
* 不同 \(p\) 使用不同的 constraint graph 和 proof address space。逐轮切换
  \(\Pi_{x,p}\) 后，原证明中“同一 \(\Pi_x\) 的 lexicographic prefix 逐轮延长”的
  induction 消失；逐位得到的 bits 可能来自不同 witnesses/不同 proofs。
* 因而必须另证一个统一 embedding \(J(\Pi_x,p)\)，使所有 prefix queries 在同一地址
  空间中，并保持同一个全局 proof circuit 的 word consistency。这正是 notes 121、131、
  167 已标出的 shared-key/whole-history accessor 接口，不是 dPCP 定理本身的结论。

## 4. 可保留的正面参数

近线性 dPCP 仍有实际价值：对大小 \(N=\operatorname{poly}(t)\) 的 \(C_x\)，其 proof
length 为 \(N\operatorname{polylog}N\)，alphabet 为常数。论文的构造参数表还给出相关最终
构造的 constraint/decoding decision complexity 为 \(\operatorname{polylog}N\)；但定理
3.12 的 headline 本身只承诺长度、alphabet、完备性和 soundness，不能单凭 headline
推出任意地址上的统一 evaluator。这比 RW 旧 PCP 的 polynomial-length history 更接近
note 167 的 line-packing 窗口。

但“更短”只有在下列额外事实同时成立时才改变 RW 路线：

1. proof \(T_x^*\) 能由 JK failure 保证为 \(O(k^4\log t)\)-size 的统一 circuit；
2. 对固定 output coordinate/claimed bit，存在同一 proof address space 上的局部 verifier；
3. verifier 具有 coordinate-robust gap，而不仅是平均 list/unique decoding；
4. graph neighbor、constraint、decoder 和 output embedding 均可在
   \(\operatorname{poly}(k,r,\log t)\) 大小内统一生成。

第 2--4 条是新的接口假设。若只复制某个 output coordinate 以把单点错误放大为常数距离，
复制次数至少随 output/prefix 长度增长；这会增加 query/proof 参数，不能默认仍在 RW 的
address-scale budget 内。

## 5. 正确的条件性替代：coordinate-robust dPCP

可把仍然值得追求的正面命题精确写成如下接口。对每个 \(C_x\)、每个 output coordinate
\(i\) 和 bit \(b\)，存在统一电路 \(Q_{x,i,b}\)，其输入是 Merlin 提交的一个全局 proof
circuit \(C\)，并满足：

* **完备性：** 若存在满足 assignment \(w\) 且 \(\operatorname{out}_i(w)=b\)，则有一个
  同一地址空间中的 proof circuit \(C^*\)，使 \(Q_{x,i,b}(C^*)\) 接受概率 \(1\)。
* **坐标鲁棒 soundness：** 若不存在这样的 \(w\)，则对任意 \(C\)，
  \(\Pr[Q_{x,i,b}(C)=1]\le1/2\)。
* **统一性：** \(Q\) 的描述、地址 evaluator 和 decoder 在
  \(\operatorname{poly}(k,r,\log t)\) 大小内生成；当 JK failure 给出
  \(\operatorname{CC}(\Pi_x)\le O(k^4\log t)\) 时，\(C^*\) 确实落在同一 witness-size budget。

若这三个条件成立，便无需逐轮恢复 lex-prefix：\(C_x\) 的所有合法 computation histories
对 deterministic machine \(M\) 的 output 坐标相同，因此对每个 \(i\) 直接查询
\(Q_{x,i,1}\) 即得到 \(f(x)_i\)。同一个 \(C^*\) 可用于所有 \(i\)，所以不会引入
逐坐标 phantom witness；smartness 则由坐标鲁棒 soundness 逐 query 给出。

这是一条严格的**条件性正向路线**。Theorem 3.12/Lemma 4.2 只给普通 list/unique
decoding，尚未给 coordinate-robust \(Q\)，故不能把该接口宣称为已构造。

## 6. 与本项目外部报告吸收的关系

Downloads 导出报告
[unbundled local reference]
中的固定 PH-local merge、固定语言量词和 rank 信息率筛选，已在
[note 092](092-2026-08-15-chatgpt-pro-report-absorption-and-route-triage.md)
吸收并保留其证据边界；报告里的穷举计数、精确稀疏 Shannon \(\Theta\) 式及 Drive 写入
声明没有自足原始证明，仍不作为定理。本 note 的 dPCP 判断只采用上面列出的原始论文定义和
定理，不把外部报告的阶段编号或回写状态当数学证据。

## 7. 路线裁决

当前可提交的判断是：

\[
\boxed{
\text{near-linear dPCP/udPCP improves proof length, but does not close RW smart-Reconf.}
}
\]

真正的下一项数学目标不是再优化 dPCP 长度，而是证明一个 coordinate-robust、同地址空间、
可由 \(k,r,\log t\) 局部生成的 verifier；若该接口失败，notes 121、131、167 的 shared-key
边界仍是正确终点。

## 8. Conjecture/theorem program（升级后的主攻问题）

本节把“simultaneous coordinate robustness”从一个接口愿望改成可证伪的二向程序。这里的
目标不是把已有障碍再编号，而是决定近线性 dPCP 是否能真正进入 RW/JK 的地址尺度。

### 8.1 统一对象

称一族 \(\{(\Pi_k,\mathcal V_{k,i,b})\}\) 为 **SCR common-proof family**，若

* \(\Pi_k:\{0,1\}^k\to\Sigma^{P_k}\) 是一份对所有坐标共用的 proof map；
* 每个 \(\mathcal V_{k,i,b}\) 使用同一 proof address space，且允许自适应查询；
* 在精确 proof \(\Pi_k(m)\) 上，正确分支完美接受；
* 对每个 \(\rho P_k\)-近 proof，错误分支的接受概率至多 \(1-\sigma\)，其中
  \(\rho,\sigma>0\) 固定；
* 地址、约束和解码器均可由目标长度与局部参数统一生成。

这一定义故意把“同一 proof”“target-relative 近邻”“wrong-claim gap”放在同一个
量词中；逐坐标重新编译的 proof、只在平均坐标上成立的 list soundness、以及不同地址空间
上的 \(\Pi_{k,i,b}\) 都不算 SCR。

### 8.2 已证的底线（不是猜想）

对 SCR family，固定有限 alphabet、正半径和固定 gap 下，inline 加决策树展开给出
非自适应查询数

\[
 Q_{r,A}=1+2\sum_{j<r}A^j.
\]

Goldberg--Gur--Saraogi 的任意 finite-alphabet RLDC 下界随后给出：若
\(N_k=k+P_k\le k(\log k)^c\) 在无穷多个长度成立，则

\[
 Q_{r,A}=\Omega\!\left(\frac{\log k}{\log\log k}\right).
\]

因此“固定 alphabet、固定 locality、固定正半径、固定 wrong-claim gap、近线性长度”
已经不是正攻窗口。二元情形的更精确边界是：存在常数
\(C=C(\rho,\sigma,c)\)，所有

\[
 r\le \log_2\log k-\log_2\log\log k-C
\]

的分支都被排除；这里的 \(C\) 是参数化常数，不应写成无量词的“\(-O(1)\)”。
该底线是已证的 RLDC 闭合，不是一般 dPCP 不可能性。

### 8.3 主猜想：coordinate-normalization dichotomy

**猜想 SCR-Dichotomy。** 设 GMWZ 型近线性 dPCP/udPCP 具有固定有限 alphabet、
perfect completeness、正半径和常数级全局 soundness，并且最终输出词族具有常数相对距离。
若其 ordinary average/list/distributional 量词不能直接给出 SCR common-proof family，则
至少有一个可观测的代价：

1. **phantom branch：** 坐标投影的 rectangular hull 含有一个不在目标词族半径邻域内的词；
2. **index branch：** 任一 same-seed/global-word coupling 都必须携带
   \(I(M;S)=\Omega(k)\) 的目标信息，或从公共样本中支付
   \(R\log(|\Sigma|+1)=\Omega(k)\) 的候选索引信息；
3. **robustness branch：** 若上述两项均不发生，则存在同一地址空间的 coordinate-robust
   wrong-claim verifier，因而进入 8.2 的 RLDC locality/length 下界。
4. **address branch：** canonical/global proof 可能存在，但从该 proof 在
   \(\operatorname{poly}(k,\log T)\) 地址尺度恢复目标坐标的 evaluator 不存在，或其
   query/proof budget 已超过近线性窗口；若补上这样的 evaluator，则应回到第 3 项的
   RLDC 编译，而不能把全局 polynomial-time proof strategy 当作局部 decoder。

这里的“至少一个”是对**最终构造的统一量词**的猜想，而不是对所有 dPCP 的无条件
不可能性断言。当前已证明的子情形是：rectangular hull 的充要条件与投影熵/码距界，
same-seed 候选列表的 Fano/index 通道，以及 SCR 到 RLDC 的决策树编译。未证明的核心是
把一个具体近线性 GMWZ/PCPP 组合自动归入这四个分支。

这里的第四项不是技术性补充，而是当前最重要的文献边界。Paradise 的 Theorem 1.12
给出每个 NP-relation 的 smooth strong-canonical PCPP：canonical proof strategy 将合法
witness 双射到正确 proofs，且 verifier 只需对数随机性和常数查询；但该定理不提供
从 canonical proof 到任意 input/output 坐标的局部逆或 address-scale evaluator。
因此“存在唯一/强 canonical proof”与“同一 proof 上可同时做 coordinate-robust
wrong-claim verification”之间仍隔着一个真正的 coding/address theorem。

### 8.4 两条可晋级路线

* **正面路线：** 构造一个同地址空间、同一 global proof 的 coordinate-normalized
  relation-PCP，使错误坐标对任意伪造 proof 都有常数拒绝概率；若 locality 达到
  \(\Theta(\log_A\log k)\) 临界区或同时改变 alphabet/radius/gap，结果将是一个新的
  PCP/coding theorem，而不是 RW 的参数修补。
* **反面路线：** 在不假设特定 decoder 结构的前提下证明 SCR-Dichotomy，或至少证明
  GMWZ 的 projection/left-canonical/dPCP 组合必然落入 phantom/index 分支。这将是一个
  机制级的 coordinate-robust dPCP barrier，并直接解释为何普通 distributional soundness
  不能完成 RW Closure。

### 8.5 晋级与停止条件

只有出现以下任一结果，才继续扩大该路线：

1. 一份满足 8.1 全部量词且地址长度、proof length、alphabet、gap 参数完整的正面构造；
2. 一个对 GMWZ/PCPP 组合或更一般 shared-proof 模型的机制级不可能性定理；
3. 一个把 global-word distributional soundness 转成同一 seed、可按地址取值的 indexed
   channel，并在 8.2 的 RLDC 窗口中产生矛盾。

仅有新的具体 decoder 反例、再次重述平均到坐标的稀释、或没有同一 proof 量词的
prefix-recompilation，不触发路线晋级。

### 8.6 强 canonical PCPP 的精确接口边界

若一个 relation-PCP 的合法输出是唯一词 \(y_x\)，强 canonical PCPP 可以给出唯一的
global proof \(\Pi_x\) 以及对 \((y,\pi)\) 距离的拒绝保证。但要把它变成 RW 所需的
coordinate verifier，还必须有一个统一的 proof-only evaluator \(D_i\)，满足：

* 在 \(\Pi_x\) 上输出 \((y_x)_i\)；
* 在 \(\rho\)-近 proof 上只以小概率输出错误位或保持 \(\bot\)；
* 所有 \(D_i\) 访问同一 proof 地址空间，且 query 数在地址尺度内。

若每个 input-oracle query 都能由这样的 \(D_i\) 以 \(q_D\) 次 proof query 模拟，原
strong-canonical PCPP 的 \(q_P\)-query verifier 会给出 \(q_P+q_Iq_D\)-query 的
proof-only ACRR，随后进入 8.2 的 RLDC 下界。若没有 \(D_i\)，Paradise/DGG 的
canonicality 结论只给全局 proof 选择，不给 RW/JK 的 smart-Reconf；这正是
“address branch”的可检验缺口。

**来源边界：** Paradise, *Smooth and Strong PCPs*, Theorem 1.12（每个 NP-relation
的 smooth strong-canonical PCPP）与 Dinur--Goldreich--Gur, TR18-050 Rev.2
（strong-canonical PCP 的 UP/UMA 刻画）支持上述 canonicality 输入；它们没有被
引用为已经提供了本项目要求的 address-scale evaluator。
