> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 高阶 witness：覆盖数分层的可审计质量界（2026-08-13）

## 设置

令 Φ 是关于固定 spoiler 的 inclusion-minimal collision witness 族，且两两相交。对 (T\in\Phi)，记 (k=|T|)、

\[
p_T=|\pi_XT|,\qquad q_T=|\pi_YT|.
\]

秩增一给出

\[
\operatorname{rank}(A_T)\ge k+1,
\qquad \operatorname{rank}(A_T)\le p_T+q_T,
\]

所以 (p_T+q_T\ge k+1)。因此完整 affine-leaf 加行列 thinning 后，单个见证满足

\[
\Pr[T\subseteq R_z(U,V)]
\le 2^{-(k+1)}2^{-(p_T+q_T)}
\le 2^{-2k-2}.
\tag{1}
\]

固定 (k) 的族 Φ_k 的并界为

\[
\Pr[\exists T\in\Phi_k:T\subseteq R_z(U,V)]
\le |\Phi_k|2^{-2k-2}.
\tag{2}
\]

故 (|\Phi_k|\le2^{2k-2}) 时该阶单独已不超过 (1/16)。

## 覆盖数 τ=2 的粗界

若 {(a,b)} 是 Φ_k 的二点 cover，按是否含 (a,b) 分成 Φ_ab、Φ_a、Φ_b。取固定 (T_0\in\Phi_b)。每个 (T\in\Phi_a) 必须与 (T_0) 相交；因 (b\notin T)，交点只能在 (T_0\setminus\{b\}) 中。于是

\[
E_a\subseteq\bigcup_{c\in T_0\setminus\{b\}}\{a,c\subseteq R\},
\qquad \Pr(E_a)\le(k-1)/64.
\]

对称地 ​\(\Pr(E_b)\le(k-1)/64\)，而同时命中 (a,b) 的部分至多 (1/64)。故

\[
\Pr(E_{\Phi_k})\le(2k-1)/64.
\tag{3}
\]

这对 (k\le3) 给出目标量级；对 (k\ge4) 不足以推出 (1/16)。

## 覆盖数 τ≥3 的真实障碍

一般 intersecting (k)-uniform 族在 τ≥3 时可随底集增长，不能以固定常数替代 (|\Phi_k|)。Erdős–Lovász 的 τ=k 粗界 (|\Phi_k|\le k^k) 代入 (2) 在 (k=4) 仍给出 (1/4)。因此，秩增一和覆盖数分层只能产生 (1)–(3)，没有解决高阶跨-(z) 联合问题。

但三元、τ=3 是一个可关闭的小分支。Frankl–Ota–Tokushige（JCTA 74, 1996，Appendix §4.2）精确证明 `r(3)=10`，即严格 3-uniform、两两相交且覆盖数为 3 的族至多 10 条。对每个三元见证，(1) 给出单项质量至多 `2^{-8}=1/256`（因为 `p_T+q_T\ge4`），故该分支的并集质量至多 `10/256<1/16`。此处关键仍是严格固定 `k=3` 与 `τ=3`；不能替代一般 `k` 或 `τ=2` 分析。

## 已关闭的特殊子类

若每个见证同时固定第二个 spoiler 方程 (p_s=\varepsilon)，则参数质量 (1/4) 与四补集轨道界 (1/4) 相乘，直接得到 (1/16)（见 note 035）。

剩余接口：单一 separator 余维一约束下，(p_s) 在不同见证之间自由变化的高阶族。
