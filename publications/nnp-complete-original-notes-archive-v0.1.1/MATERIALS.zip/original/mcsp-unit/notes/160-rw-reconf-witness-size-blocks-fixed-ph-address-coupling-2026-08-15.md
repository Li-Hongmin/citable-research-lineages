> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW Reconf 的 witness 尺寸阻断固定 PH 地址耦合（2026-08-15）

## 原始接口中的承重参数

Ren--Williams Theorem 4.1 对 AVOID 实例
\[
G:\{0,1\}^{k(n)}\to\{0,1\}^{2k(n)}
\]
给出失败分支上的 Reconf。其输入是一个历史索引 \(x\) 和输出位 \(i\)，并以
smart-\(\mathrm{prMA}\) 查询重构该位。定理保证的运行时间和查询规模是
\[
\operatorname{poly}(k(n),r(n),\log t(n)).
\tag{1}
\]

但该规模并非只来自外层索引。原证明的每个 prefix 查询让 Merlin 提交一个 PCP
候选电路 \(C\)，其允许的门数预算为
\[
 K'(n)=\Theta(k(n)^4\log(t(n)+2)).
\tag{2}
\]
这里把原文的 O 上界取成一个固定槽位预算；增加常数倍的空槽不改变
Reconf 的语义。
在标准固定槽位的 fan-in-two gate-list 编码中，Merlin 消息必须容纳
\(\Theta(K'(n))\) 个门槽（另有 verifier、prefix 和低度自校正器字段）。这里说的是
消息域/查询格式的长度预算；某个具体的可接受 \(C\) 当然可能只用更少的门，不能把
预算下界误读成每个 witness 都恰有 \(K'(n)\) 个门。

## 对固定 decoder 的直接代入

若把该 AVOID 实例直接取为目标 decoder，并且满足 Theorem 4.1 的适用条件
\(k(n)=q\le t(n)\) 与 \(|G_q|\le q^4\)，则
\[
G_q:\{0,1\}^{q}\to\{0,1\}^{2q},
\qquad q=2^{m-1},
\]
由 (2)，RW Reconf 的 prMA 查询必须允许一个长度至少为
\[
\Theta\!\bigl(q^4\log(t+2)\bigr)=\Omega(q^4\log q)=2^{\Omega(m)}
\tag{3}
\]
量级的候选电路描述；这里用了 t≥q，所以
\(\log(t+2)=\Omega(\log q)=\Theta(m)\)。而 note159 所需的固定地址谓词只能允许
\(\operatorname{poly}(m)\) 长度的量词变量和 verifier。

这只是一个适用条件下的架构比较：Reconf 是针对给定 multi-output f 的程序，且其
保证位于 `Solve_f` 失败的分支；任意固定 decoder 并不会自动满足这些前提。

因此：

\[
\boxed{
\text{RW Theorem 4.1 的现有 Reconf 查询不能直接实例化 note159 的 fixed-PH
address coupling。}
}
\tag{4}
\]

把 (1) 重新写成 \(\operatorname{poly}(\log q)\) 不改变这个问题；候选 PCP 电路的
显式 witness 已经在 (2) 中占据 \(q^{\Omega(1)}\) 位。要得到地址尺度谓词，必须另证
一个**压缩且可验证的 PCP-circuit witness**，其描述长度为 \(\operatorname{poly}(m)\)，
并且能在所有地址上保持同一个 word-consistent history。RW 原定理没有提供这一步。

## 其他参数障碍

RW Theorem 4.3 的 smart-\(\mathrm{FP}^{\mathrm{prMA}}/1\) AVOID 求解器只在无限多个输入
长度上保证成功；即使把查询 witness 压缩，也还需证明这些 good lengths 与 coverage
和 forcing 的同一子序列相交。这个密度/对齐条件不能由“infinitely often”自动补出。

## 适用边界

本结论只排除**直接使用 RW Reconf 的 gate-list PCP witness**：

1. 它不是对所有 PCP、低度编码或新的整词 accessor 的 lower bound；
2. 若另有一个 \(\operatorname{poly}(m)\)-bit 的 canonical history key，并能从该 key
   验证所有地址位，(3) 不适用；
3. 这种新 key 正是 note140、note159 所列的未证明接口，而不是对 Theorem 4.1 的记号
   重写。

## 来源

- Ren--Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with Merlin--Arthur
  Queries*, ECCC TR26-118 revision 1, Theorem 4.1 and its Reconf proof:
  [official report](https://eccc.weizmann.ac.uk/report/2026/118/).
- 本 note 的 (2)--(4) 是对该定理参数与标准 gate-list 编码的直接推导；不声称一般
  \(P\ne NP\) 或任意 compressed-JK lower bound。
