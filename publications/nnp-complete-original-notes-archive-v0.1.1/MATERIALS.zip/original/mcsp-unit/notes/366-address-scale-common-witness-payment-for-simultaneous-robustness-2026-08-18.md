> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Address-scale common-witness payment for simultaneous coordinate robustness (2026-08-18)

## Decision

A symmetric two-branch lift does not evade the RW common-witness payment. If every
coordinate uses the same Merlin circuit, and that circuit's decoded proof word is the
entire target word, then every correct coordinate query carries a witness whose length is
already a fixed power of the target circuit complexity. Consequently, a simultaneous
coordinate-robust interface with polynomially address-scale query descriptions cannot
have near-maximum target complexity. The conclusion is unconditional once the stated
same-witness and decoder hypotheses are supplied; it does not claim that published RW
Reconf supplies them.

This closes the apparent all-zero escape in the one-sided payment lemma [note 365]: a
two-branch interface has a correct YES query at every coordinate, regardless of the target
Hamming weight.

## Setup

Let \(f\in\{0,1\}^{T}\), \(S=\operatorname{CC}(f)\), and
\(m=\lceil\log_2(T+1)\rceil\). A proof circuit \(C\) has a truth-table proof word
\(\Pi_C\). Fix a decoder \(\mathsf{Dec}_T\) and constants \(A,c_D,v_D,d_M>0\) such that

\[
 \operatorname{CC}\bigl(\mathsf{Dec}_T(\Pi_C)\bigr)
 \le A(s+\log(T+2))^{c_D}\log(T+2)^{v_D}
 \tag{366.1}
\]

for every circuit \(C\) of size \(s\), and every query of description length \(Q\) has
Merlin witness length at most \(Q^{d_M}\). The decoder bound includes the usual fixed-tape
simulation of a low-degree self-corrector; a different fixed decoder is allowed if it
satisfies (366.1).

Consider a simultaneous two-branch interface with queries \(q_{i,b}\), \(i\in[T]\),
\(b\in\{0,1\}\), satisfying:

1. one circuit \(C^\star\) is an admissible witness for every correct query
   \(q_{i,f_i}\);
2. \(\mathsf{Dec}_T(\Pi_{C^\star})=f\);
3. \(Q_i\) bounds the description length of \(q_{i,0}\) and \(q_{i,1}\).

No assumption is made about the incorrect branch beyond the usual soundness promised by
the proposed interface.

## Theorem (simultaneous common-witness payment)

For every \(i\in[T]\),

\[
 Q_i^{d_M}\ge s^\star,
 \qquad s^\star:=|C^\star|,
 \tag{366.2}
\]

and hence

\[
 Q_i
 \ge
 \left[
 \left(\frac{S}{A\log(T+2)^{v_D}}\right)^{1/c_D}
 -\log(T+2)
 \right]_+^{1/d_M}.
 \tag{366.3}
\]

In particular, if

\[
 S\ge 2^{\Omega(m)}/\operatorname{poly}(m),
 \tag{366.4}
\]

then \(Q_i=2^{\Omega(m)}\) for every coordinate on all sufficiently large lengths.
Thus the interface cannot be both whole-word binding and address-scale
\(Q_i=m^{O(1)}\).

### Proof

By item 1, \(C^\star\) is a legal Merlin witness for the correct branch at coordinate
\(i\). The witness-length bound gives (366.2). By item 2 and (366.1),

\[
 S
 =\operatorname{CC}(f)
 \le A(s^\star+\log(T+2))^{c_D}\log(T+2)^{v_D}.
\]

Rearranging gives

\[
 s^\star+\log(T+2)
 \ge
 \left(\frac{S}{A\log(T+2)^{v_D}}\right)^{1/c_D},
\]

and combining with \(s^\star\le Q_i^{d_M}\) yields (366.3). Under (366.4), the
right-hand side is \(2^{\Omega(m)}\) (with a changed constant in the exponent), while
\(m^{O(1)}\) is only polynomial. \(\square\)

### Seeded common-witness variant

The same payment survives a succinct seed, provided the seed is expanded to a proof
circuit by a fixed polynomial-size mechanism. More precisely, suppose the correct query
uses a witness \(u^\star\) of length at most \(Q_i^{d_M}\), and a fixed expansion
procedure turns \(u^\star\) into \(C^\star\) with
\[
 |C^\star|\le B(Q_i+1)^{d_M e}
\tag{366.5}
\]
for a constant \(e\). If the expanded circuit has the whole-word decoding property in
item 2, then
\[
 Q_i+1\ge
 \left[
 \frac{1}{B}
 \left(
 \left(\frac{S}{A\log(T+2)^{v_D}}\right)^{1/c_D}
 -\log(T+2)
 \right)
 \right]_+^{1/(d_M e)}.
\tag{366.6}
\]
This is obtained by substituting (366.5) for \(s^\star\) in the proof above. Thus a
short seed is not an escape when its expansion remains polynomial in the query
description. A purported escape must either abandon whole-word decoding, use a
superpolynomial/non-succinct expansion, or leave the standard decoder model.

## Why this is a genuine quantifier gate

The theorem has three explicit exits, none of which is a closure proof:

* If \(C_i\) may vary with \(i\), the payment does not apply. This is exactly the
  published Reconf quantifier gap isolated in [note 365](365-rw-reconf-common-witness-quantifier-gap-2026-08-18.md).
* If the shared witness is not required to decode to the entire \(f\), coordinatewise
  acceptance leaves a phantom-word/global-binding gap and cannot be fed into the static
  package theorem [note 364](364-rw-static-package-closure-theorem-2026-08-18.md).
* If the witness length is not polynomially bounded by the query description, or if the
  decoder violates (366.1), the proposed construction has left the standard succinct
  prMA/decoder model; \(P=NP\) does not repair that model exit.

The payment is therefore a dichotomy for the strongest natural positive proposal:
whole-word same-witness binding is object-scale, while address-scale queries must give up
that binding and pay for a separate descriptor/strategy or a new non-transcript coupling.
It is not a general dPCP impossibility theorem and does not by itself prove \(P\ne NP\).

## Relation to the RW source

Ren--Williams' published Reconf has one-sided final queries \(q_{\mathrm{pfx},i}\), and
its soundness allows a different accepted circuit for each address. Thus this theorem does
not retroactively apply to Theorem 4.1. It applies to a proposed simultaneous
coordinate-robust attachment only after that attachment explicitly supplies the missing
common-witness/whole-word quantifiers.

## Sources

* Ren--Williams, ECCC TR26-118, Theorem 4.1 and the Reconf proof:
  [ECCC TR26-118](https://eccc.weizmann.ac.il/report/2026/118/).
* [RW common-witness payment and quantifier gap](365-rw-reconf-common-witness-quantifier-gap-2026-08-18.md).
* [RW static-package Closure Theorem](364-rw-static-package-closure-theorem-2026-08-18.md).
