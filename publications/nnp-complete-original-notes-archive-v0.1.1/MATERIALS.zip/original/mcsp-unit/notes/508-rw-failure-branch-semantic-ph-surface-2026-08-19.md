> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW failure 分支的语义 PH surface：同词输出不需同一 Merlin witness（2026-08-19）

## 本轮改变的判断

C370 已把 published 'Reconf' 分解为共同 prefix 与地址化最终 query，但仍把
“共同 canonical proof”与“共同 selected response”分开。这里再把一个对最终
\(P/\mathrm{poly}\) 闭合重要、对 RLDC 不足的事实写成精确引理：在
'Solve_f(x,G)' failure 分支，RW 的每个实际最终 query 都在 'prMA' promise 内，
因此其 YES/NO 语义本身可以写成一个固定的 \(\Sigma_2^P\) 布尔表面。所有坐标
共享同一 prefix advice；不同坐标是否使用不同 Merlin circuit 不再是最终单表
闭合的独立障碍。

这不提供 address-scale 压缩，也不提供 common physical proof，因而不产生
RLDC/LDC 结论；它只把 Gate I 的正攻目标从“必须先绑定同一 witness”收窄为
“把现有单值 PH surface 压到地址尺度”。

## 定理 508.1（failure-branch semantic PH surface）

固定 Ren--Williams Theorem 4.1 的一次调用。设

* \(f:\{0,1\}^{n}\to\{0,1\}^{t}\)；
* 'Solve_f(x,G)' 没有输出 \(\{0,1\}^{2k}\setminus\operatorname{Range}(G)\)；
* \(r'=O(r\log(t+1))\)，
  \(\tau_x=\operatorname{pref}_{r'}(\Pi_x)\) 是完整性 PCP proof 的 canonical prefix；
* \(q_{x,\tau,i}\) 是 'Reconf(x,i)' 在 prefix 已固定为 \(\tau\) 后的最终
  'prMA' query。

把 query 的确定性验证电路记为

\[
  A_{x,\tau,i}(C,\rho)\in\{0,1\},
\]

其中 \(C\) 是 Merlin 提供的 proof-circuit witness，\(\rho\) 包含 Arthur 的
全部随机位（包括低度自校正器的随机位）。定义

\[
  W(x,\tau,i):=\exists C\ \forall \rho\;
      A_{x,\tau,i}(C,\rho)=1 .
  \tag{508.1}
\]

则：

1. \(W\) 是一个固定 \(\Sigma_2^P\) predicate；其输入、量词串和矩阵长度都由
   'Reconf' 的 query size 多项式有界。
2. 在上述 failure 分支的实际输入上，
   \[
      f(x)_i=W(x,\tau_x,i)\qquad(i\in[t]).
      \tag{508.2}
   \]
   因而 \((W(x,\tau_x,i))_{i\in[t]}\) 是同一个输出词的单值语义 surface。
3. 若 \(P=NP\)，则 \(\Sigma_2^P=P\)，所以存在一个固定确定性过程
   \(\mathcal D\) 直接计算 \(W\)。把 \(x,\tau_x\) 作为该长度的静态 advice 后，
   \[
      \operatorname{CC}(f(x))\le
      \operatorname{poly}\!\bigl(|x|+|\tau_x|+\log t+k+r\bigr).
      \tag{508.3}
   \]
   这里的多项式次数只依赖固定的 RW query 编码与 PH-collapse 模拟器。

### 证明

'prMA' 的 YES promise 正是存在一个 witness \(C\)，使得对所有均匀随机串
\(\rho\)，\(A_{x,\tau,i}(C,\rho)=1\)；有限随机串上的概率 1 等价于全体随机串
都接受。因此 YES query 满足 (508.1)。另一方面，NO promise 对每个 \(C\) 的接受
概率至多 \(1/2\)，故不可能有某个 \(C\) 对所有 \(\rho\) 都接受，(508.1) 为假。

Theorem 4.1 的 smartness 归纳保证 failure 分支的每一个实际 prefix query 与
最终 query 都在这两个 promise 集合的并中；其最终 query 的 YES/NO 答案又正是
\(f(x)_i\)。C370 证明所有坐标的 prefix 都等于同一 \(\tau_x\)，于是得到
(508.2)。

\(\exists C\forall\rho\) 是固定两层多项式层级谓词。若 \(P=NP\)，则
\(\Sigma_2^P=P\)，在输入 \((x,\tau_x,i)\) 上用固定确定性模拟器计算 \(W\)。
把 advice \(x,\tau_x\) 和地址 \(i\) 接入电路即可得到 (508.3)。证毕。

## RW 稳定阶段的尺度结论

在 Theorem 4.3 的稳定尾部，C370 的参数为

\[
  t=T_i=n_{i+1}=n_i^C,\qquad k=n_{i+1}=n_i^C,\qquad r_i=O(n_i),
  \qquad |B_i|=2n_i .
  \tag{508.4}
\]

故 (508.3) 的直接 surface 输入长度和确定化时间仍按
\(\operatorname{poly}(n_{i+1})\) 计价，而被 forcing 的 \(B_i\) 的地址长度仅为
\(\Theta(\log n_i)\)。因此该引理给出的是 C430/C450 所说的 object-scale
surface，而不是最终需要的 \(\operatorname{poly}(\log n_i)\) address-scale surface。
它排除了“每个地址不同 Merlin witness 本身就会破坏最终单值输出”的误读，
但没有压缩共同 prefix、query matrix 或量词 witness。

## 对 Closure 计划的精确影响

* **正向 Gate III：** 对最终 \(P=NP\Rightarrow H_A\in P/\mathrm{poly}\)，
  common physical proof 不是必要条件；一个固定层、单值、地址尺度的 PH surface
  已足够。RW failure 分支在语义上已经提供该 surface 的 object-scale 版本。
* **负向 RLDC/PCP 路线：** 若要把同一接口提升为 family-level common-proof
  coding object，仍必须证明 common proof、positive-radius 与 all-policy
  soundness；(508.1) 只是对实际 singleton 输出的语义判定，不能触发 C204/C507。
* **solver-success 分支：** 定理只适用于 'Solve' failure。成功时 Theorem 4.1
  只返回 child outsider，仍有 C372/C487 的 parent-binding 缺口。
* **剩余主瓶颈：** 新工作必须证明一个把
  \((x,\tau_x,i)\mapsto W(x,\tau_x,i)\) 的输入、量词和矩阵压到地址尺度的
  RW-specific compression，或证明这种压缩必然支付 C207/C450 的 forcing-scale
  成本。继续要求“同一 witness”而不处理这个尺度问题不会改变最终决策。

## 证据边界

这是对 Ren--Williams Theorem 4.1 的 failure-branch 语义重写，依赖原文的
'prMA' 完备性/可靠性和 smartness 量词；它不是新的 dPCP 构造、RLDC 下界或
无条件 \(P\ne NP\) 证明。量词串若仍为 object scale、PH 层数若增长、或实际
query 离开 promise，(508.1)--(508.3) 不提供额外结论。

## 来源

* Ren--Williams, ECCC TR26-118, Theorem 4.1、Theorem 4.3；本地抽取：
  'units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md'。
* [C370 RW Reconf prefix--selected-response factorization](370-rw-reconf-prefix-transcript-address-factorization-2026-08-18.md)。
* [C354 address-scale PH-surface closure](354-address-scale-ph-surface-closure-2026-08-18.md)。
* [C450 scale-complete RW Closure normal form](450-scale-complete-rw-closure-normal-form-2026-08-19.md)。
