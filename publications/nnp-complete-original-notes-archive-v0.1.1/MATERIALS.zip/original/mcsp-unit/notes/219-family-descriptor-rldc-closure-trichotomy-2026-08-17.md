> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Family--descriptor--RLDC closure trichotomy (2026-08-17)

## Purpose

The RW/JK endpoint has two apparently different escape routes. A
single \(A\)-dependent target may be reconstructed with a short static
descriptor, in which case the target is already in \(P/\mathrm{poly}\);
or one may keep a large target family in one common proof and one common
address space, in which case coordinate robustness is a coding statement.
This note makes the resulting trichotomy explicit. It is a closure theorem,
not a claim that the current RW construction satisfies its hypotheses.

## Theorem (family--descriptor--RLDC closure trichotomy)

For each base length \(n\), let \(\Theta_n\) be a target set and let
\(H_{n,\theta}\in\{0,1\}^{N_n}\) be its target word. Assume a proposed
reconstruction has one physical proof address space and one static target
descriptor \(d_\theta\in\{0,1\}^{s_n}\) for each \(\theta\). A random-access
evaluator \(E_n(d,a)\) has control size \(p_n\), fan-in two, and at most
\(p_n\) reads from the descriptor. The evaluator is word-consistent: the same
\(d_\theta\), proof address space, and strategy are used for every
\(a\in[N_n]\), and \(E_n(d_\theta,a)=H_{n,\theta}[a]\).

Suppose a subfamily is indexed by all messages \(m\in\{0,1\}^{k_n}\) and its
target words are \(C_n(m)\), where \(C_n\) has relative distance
\(\Delta_n>0\). Suppose further that this subfamily is supplied by a common
family-level dPCP with:

* perfect-completeness proofs \(A_m\) in the same address space \(V_n\);
* complete-decoding incidence at most \(\chi_n/|V_n|\) per proof position;
* an exact outer decoder with \(q_{D,n}\) adaptive output queries and
  honest-path smoothness at most \(\lambda_n/M_n\) per codeword position;
* \(q_{P,n}\) proof positions per dPCP local call, with the local calls
  composing with the outer decoder.

Then every attempted closure belongs to the following quantified alternatives.

### (I) Address-scale short branch

If, on an infinite set of lengths,

\[
  p_n^2+p_n s_n\le n^{O(1)},\qquad
  \log N_n\le n^{O(1)},
\tag{219.1}
\]

then every fixed target sequence \(\theta_n\) is in \(P/\mathrm{poly}\): for each
\(n\), hardwire \(d_{\theta_n}\) into the ordinary multiplexer expansion of
\(E_n\). In particular, any forcing lower bound
\(\operatorname{CC}(H_{n,\theta_n})>n^{\omega(1)}\) for the same target
\(\theta_n\) rules out this branch.

More quantitatively, if a target satisfies
\(\operatorname{CC}(H_{n,\theta})>S_n\), then every such evaluator obeys

\[
  p_n^2+p_n s_n=\Omega(S_n).
\tag{219.2}
\]

Thus a descriptor cannot be declared “free” while the target is forced hard.

### (II) Incidence-stable family branch

If the displayed family-level dPCP hypotheses hold, then for every

\[
  0<\rho<\frac{\Delta_n}{2\chi_n},\qquad
  \eta_n:=q_{D,n}\lambda_n\chi_n\rho<\frac12,
\tag{219.3}
\]

the selected honest proofs form a weak
\((q_{P,n}q_{D,n},\rho,1-\eta_n)\)-RLDC for the message family. In
particular, any applicable RLDC lower bound \(L_{\mathrm{RLDC}}\) gives

\[
  |V_n|\ge
  L_{\mathrm{RLDC}}\!\left(k_n,q_{P,n}q_{D,n},\rho,\eta_n\right).
\tag{219.4}
\]

For binary two-query composition, the exponential two-query Hamming-RLDC
lower bound applies. Hence a near-linear proof cannot satisfy (II) in that
parameter regime. For fixed finite alphabets and constant locality, the
corresponding superlinear RLDC lower bound applies whenever its radius and
error hypotheses are met.

### (III) Escape-payment branch

If neither (I) nor (II) is available, at least one of the following is a
mathematical cost of the proposed reconstruction, not a naming convention:

1. \(p_n^2+p_ns_n\) is superpolynomial, so the descriptor/evaluator itself
   carries forcing-scale information;
2. \(\log N_n\) is superpolynomial or the target set is not a full
   distance-separated family in one common proof
   space, so the family-level RLDC implication is unavailable;
3. incidence \(\chi_n\), decoder smoothness \(\lambda_n\), locality, proof
   length, or radius leaves the stated RLDC lower-bound window;
4. different addresses use different sheets, proofs, or strategies, violating
   word consistency and therefore failing the closure interface.

This is the promised classification: a proposed RW-specific construction can
avoid the coding barrier only by paying one of these explicit costs. It cannot
simultaneously retain a short address evaluator, a high-entropy
distance-separated family, and incidence-stable coordinate robustness.

## Proof

For (I), replace each descriptor read by a fan-in-two \(s_n\)-input multiplexer.
The standard ROM expansion gives an ordinary circuit of size
\(O(p_n^2+p_ns_n)\), with the descriptor bits hardwired and the address as the
only input. This proves (219.1)--(219.2).

For (II), apply the incidence-stable field-lift argument of note 218 with
the displayed parameters. Exactness on two codewords whose outer symbols
differ forces a differing local transcript on the complete-decoding
distribution; incidence then gives

\[
  \operatorname{dist}(A_m,A_{m'})\ge\Delta_n/\chi_n.
\]

If a received proof is within relative radius \(\rho\) of \(A_m\), the
first-hit argument and honest-path smoothness bound the probability that the
adaptive outer decoder touches a changed proof position by
\(q_{D,n}\lambda_n\chi_n\rho=\eta_n\). On the complementary event, the exact
codeword decoder follows the honest path and outputs \(m_i\). This gives
(219.3) and the RLDC in (219.4).

If (I) fails, the ROM inequality forces a superpolynomial descriptor/control
cost whenever the forcing target is superpolynomially hard. If (II) fails,
one of its explicit family, incidence, smoothness, locality, distance, or
common-address hypotheses is absent. These are exactly the alternatives in
(III). \(\square\)

## Consequence for the RW Closure Theorem

The conditional \(P=NP\Rightarrow H_A\in P/\mathrm{poly}\) theorem in note 204
is now the short-branch endpoint of this trichotomy. A future RW-specific
construction has only two ways to advance beyond it:

* prove a family-level branch and accept the resulting RLDC/proof-length
  lower bound; or
* prove that the actual RW target has an escape-payment parameter that is still
  \(n^{O(1)}\) **and** does not encode the history, which would be a genuinely
  new address-scale theorem rather than a relabelled descriptor.

The theorem does not prove \(P\ne NP\), and it does not assert that GMWZ or RW
already supplies the family-level hypotheses. Its value is that it turns the
remaining “bottom/cover/descriptor/address” discussion into a finite list of
quantitative obligations.

## Boundaries

The family branch is not triggered by one hard target, by ordinary list
soundness, or by per-coordinate \(\forall a\,\exists w_a\) witnesses. A single
target may evade RLDC lower bounds, but then it must still either admit the
short \(P/\mathrm{poly}\) evaluator of (I) or pay (III). Conversely, a large
family without incidence/smoothness does not automatically yield an RLDC; its
failure is precisely one of the escape parameters above.

## Evidence boundary

The RLDC implication is the incidence-stable field-lift theorem in note 218.
The ROM accounting is the closure lemma in note 204. The binary two-query
consequence uses the current exponential Hamming-RLDC lower bound of Block et
al.; the theorem is conditional on whichever exact alphabet, radius, and
query model the selected lower bound requires.
