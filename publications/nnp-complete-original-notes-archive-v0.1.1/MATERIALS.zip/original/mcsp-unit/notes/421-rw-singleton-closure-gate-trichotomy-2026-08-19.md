> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW singleton Closure-Gate trichotomy: finite common response vs. full JK frontier（2026-08-19）

## 本轮改变的判断

C231 与 C420 处理的是两个看似不同的 singleton 闭合接口：

* C231 假设同一 proof、同一 common response strategy 服务所有 parent
  addresses，并把它编译成一个 address circuit；
* C420 不假设已有一个 finite response strategy，而是对整棵 canonical JK
  recursion 的 failure frontier 做递归 interval decomposition。

本 note 把二者放进同一个 source-specific Closure Gate。对一个 forcing parent，
任何声称属于这两个接口之一的 closure 都必须支付相应的 parent-circuit 账本。若
一个方案两种账本都不满足，则它不是“把旧接口再优化一点”，而必须明确给出：

1. 不能展开成 canonical half-lift 的 non-half-lift global coupling；
2. 非有限 common-response 的 unbounded interaction；或
3. 改变 common proof/address、promise-preserving 或 target-binding 量词的 model exit。

这不是把剩余分支宣布为不可能，而是把 C420 的适用边界与真实 RW stable
参数写清：在 published stable recurrence \(k_i=n_i^C\) 下，C420 的
\(C_{G_i}\) 已是 object-scale，frontier 下界不能直接与
\(\operatorname{CC}(B_i)=\Omega(n_i/\log n_i)\) 比较；此时真正仍有非平凡压力的是
C231 的 finite common-response descriptor payment，或一个尚待构造的新 global
relation。

## 统一设置

固定一个 parent \(B\in\{0,1\}^{b}\)，令

\[
m:=\lceil\log_2(b+2)\rceil,\qquad
\operatorname{CC}(B)>S.
\tag{421.1}
\]

这里 \(\operatorname{CC}(B)\) 是以 \(m\)-bit address 计算 \(B[a]\) 的最小
fan-in-2 circuit size，\(S\) 是同一长度上的 forcing lower bound。

### 接口 F：finite common response

一个 finite common-response attachment 包含：

* 一个对所有 addresses 共用的 proof/response descriptor
  \(\sigma\in\{0,1\}^{d}\)；
* 一个显式 fan-in-2 control circuit，大小为 \(p\)，输入 address 与 public
  random tape；
* 每次执行至多 \(r\) 次对 \(\sigma\) 的 arbitrary read；
* 同一个 response rule 对所有 \(a\in[b]\) 给出 RW final-query 的
  \(1\) versus \(1/2\) gap：
  \[
  B[a]=1\Longrightarrow \Pr_R[\operatorname{Acc}(a,R;\sigma)=1]=1,
  \qquad
  B[a]=0\Longrightarrow
  \Pr_R[\operatorname{Acc}(a,R;\sigma)=1]\le\tfrac12.
  \tag{421.2}
  \]

所有 proof circuit、cover label、canonical key、prefix 与 strategy summary 若对
所有地址共用，都必须计入 \(d\)。这正是 C231 的 finite common-response model；
不要求 descriptor 是 P-uniform 生成的。

### 接口 J：full canonical JK frontier

固定 \(G_k:\{0,1\}^{k}\to\{0,1\}^{2k}\)、\(R_G=\operatorname{Range}(G_k)\) 与
canonical inverse \(p:R_G\to\{0,1\}^{k}\)，满足

\[
p(G_k(u))=u.
\tag{421.3}
\]

把 padded proof 切成 \(2^H\) 个 \(2k\)-bit leaves，并按 C420 定义 good、bad
defined internal、undefined nodes。令 \(\mathcal F\) 为所有 bad leaves 与 bad
defined internal nodes，令 \(\mathcal T\) 为 C420 的 good-seed/bad-leaf terminals，
并设

\[
C_G:=|G_k|+k+\lceil\log_2(L+2)\rceil,
\tag{421.4}
\]

其中 \(L\) 是 padded proof length。

## 定理 421.1（singleton Closure-Gate trichotomy）

在设置 (421.1)--(421.4) 下：

### (F) 若 attachment 属于 finite common-response 接口

则

\[
\operatorname{CC}(B)
\le O\!\left(m(p+rd+m)\right).
\tag{421.5}
\]

因此，只要 \(S\) 超过 \(O(m^2)\) 的 additive term，就有

\[
p+rd
\ge
\Omega\!\left(\frac{S}{m}\right).
\tag{421.6}
\]

### (J) 若 attachment 属于 full canonical JK frontier 接口

则

\[
|\mathcal T|\le 1+2H|\mathcal F|,
\qquad
\operatorname{CC}(B)
\le O\!\left(HC_G(1+H|\mathcal F|)\right).
\tag{421.7}
\]

只要 \(S/(HC_G)\to\infty\)，便有

\[
|\mathcal F|
\ge
\Omega\!\left(\frac{S}{H^2C_G}\right).
\tag{421.8}
\]

### (E) 若一个 proposed closure 在 (421.8) 的 domination condition
\(S/(HC_G)\to\infty\) 成立时仍声称不支付 (421.6)、不支付 (421.8)，且仍声称
自己完成了 whole-parent binding

那么它必须退出 F/J 两个接口至少一个假设：它要么提供一个不能编译成
finite common response 或 canonical half-lift 的 genuinely joint global relation，
要么使用 unbounded interaction/target-dependent proof-address semantics，或改变
promise-preserving、same-proof、same-parent 的量词。E 是一个 model-exit 分类，
不是对该新机制的不可能性证明。

若一个方案同时满足 F 与 J，则两个 payment 都成立；不能用 J 的 frontier sharing
取消 F 的 descriptor payment，也不能用 F 的 common descriptor 把 J 的
non-range frontier 当成不存在。

### 证明

对 F，取 \(c\,m\) 个独立 public tapes，其中常数 \(c\) 足够大。对每个 address
\(a\)，若 \(B[a]=1\)，(421.2) 使所有样本都接受；若 \(B[a]=0\)，Hoeffding
给出样本接受率超过 \(3/4\) 的概率至多 \(2^{-\Omega(m)}\)。对至多 \(b\) 个
addresses union bound 后，存在一个固定 tape multiset 同时分离所有地址。把
这些 tapes、\(\sigma\) 和 \(p\)-size control hardwire；每次 descriptor read
用一个 \(d\)-bit multiplexer 展开，地址计数与阈值比较支付 \(O(m^2)\) gates。
得到 (421.5)，再由 (421.1) 移项得到 (421.6)。

对 J，C420 的 good-subtree induction、frontier-to-terminal count 与 interval
evaluator 分别给出

\[
|\mathcal T|\le1+2H|\mathcal F|,
\qquad
\operatorname{CC}(B)
\le O\!\left(|\mathcal T|(HC_G+k+\log(L+2))\right).
\]

因 \(C_G\ge k+\log(L+2)\) 且 \(H\ge1\)，得到 (421.7)；在
\(S/(HC_G)\to\infty\) 时解出 (421.8)。若一个 attachment 不满足 F，也不满足带有
domination condition 的 J，则它按定义不在这两个接口的联合模型内，得到 E。若
domination condition 失败，J 仍可能是一个 object-scale representation，但本
定理不从它推出 forcing 矛盾。证毕。

## RW stable-stage specialization

取 published RW stable stage 的

\[
b_i=2n_i,\qquad
m_i=\Theta(\log(n_i+2)),\qquad
S_i=\Omega\!\left(\frac{n_i}{\log(n_i+2)}\right).
\tag{421.9}
\]

### finite common response

由 (421.6)，任何 F-interface closure 都必须支付

\[
p_i+r_i^{\rm read}d_i
\ge
\Omega\!\left(\frac{n_i}{\log^2(n_i+2)}\right),
\tag{421.10}
\]

其中 \(r_i^{\rm read}\) 是每次地址执行的 descriptor reads。特别地，若
\(p_i,r_i^{\rm read}\le(\log n_i)^{O(1)}\)，则

\[
d_i=\Omega\!\left(\frac{n_i}{\operatorname{polylog}(n_i)}\right).
\tag{421.11}
\]

这把 finite common proof/strategy/cover summary 的必要信息提升到 message scale；
改名为 canonical key、sheet、prefix 或 Merlin response 不会减少 (421.10) 中的
总 descriptor。

### full canonical JK frontier

C420 给出的 exact expression 是

\[
|\mathcal F_i|
\ge
\Omega\!\left(
\frac{n_i}
{\log(n_i+2)\,H_i^2 C_{G_i}}
\right)
\tag{421.12}
\]

仅在 \(S_i/(H_iC_{G_i})\to\infty\) 时有效。若
\(H_i=O(\log n_i)\)、\(|G_{k_i}|\le k_i^4\)，则在 address-scale width
\(k_i=\operatorname{polylog}(n_i)\) 时，(421.12) 近似为

\[
|\mathcal F_i|
\ge
\Omega\!\left(
\frac{n_i}
{(k_i^4+k_i+\log n_i)\log^3 n_i}
\right).
\tag{421.13}
\]

但 published RW stable recurrence 取 \(k_i=n_{i+1}=n_i^C\)。此时
\(C_{G_i}\ge k_i\)（并且通常 \(|G_{k_i}|\le k_i^4\)），故
\(H_iC_{G_i}\gg S_i\)，(421.8) 的 domination condition 失败；不能把
(421.12) 写成 published singleton 的 nontrivial frontier lower bound。这是本
trichotomy 的一个重要负结果：C420 关闭的是 address-scale canonical frontier
逃逸，不是 object-scale RW width。

## 对 Closure 计划的实际结论

定理 421.1 把当前 singleton 路线压成以下精确分叉：

\[
\begin{array}{c}
\text{finite common proof/response}
  \Longrightarrow
  \text{message-scale descriptor/control payment};\\[2mm]
\text{address-scale canonical JK recursion}
  \Longrightarrow
  \text{frontier payment};\\[2mm]
\text{published object-scale }k_i=n_i^C
  \Longrightarrow
  \text{neither payment alone closes the RW call};\\[2mm]
\text{因此剩余正攻}
  \Longrightarrow
  \text{new non-half-lift/global relation or stronger forcing/scale bridge}.
\end{array}
\tag{421.14}
\]

这不证明 \(P\ne NP\)，也不证明一般 dPCP/RLDC 不可能性。它的论文级增量是：
C231 的有限 common-response barrier 与 C420 的完整 recursive-frontier barrier
现在有一个共同的 singleton 量词与明确的 RW 参数边界；任何后续正攻必须说明自己
究竟是新 global relation，还是已经支付了 message/object-scale 信息。

## 证据边界与上游

* [C231](231-rw-final-query-common-strategy-lower-bound-2026-08-17.md)：RW
  final-query 的 common proof、\(1\) versus \(1/2\) gap 与 descriptor sampling；
* [C420](420-rw-full-jk-frontier-parent-binding-2026-08-19.md)：完整 canonical
  JK tree 的 terminal count 与 circuit evaluator；
* Ren--Williams Theorem 4.1、4.3：stable recurrence
  \(k_i=n_{i+1}=n_i^C\)、parent forcing scale 与 common proof source；
* 本 note 不把 E 分支冒称为已证明不可能，也不把 (421.12) 在
  \(k_i=n_i^C\) 时误写成有效 lower bound。
