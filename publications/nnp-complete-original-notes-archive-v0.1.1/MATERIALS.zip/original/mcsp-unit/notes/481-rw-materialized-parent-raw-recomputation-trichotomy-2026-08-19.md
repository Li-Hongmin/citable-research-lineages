> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW materialized-parent versus raw-recomputation closure trichotomy (2026-08-19)

## 改变的判断

C478--C479 的 raw branch 与 symbolic branch 可以进一步接到同一个
same-proof 量词上。一个 FRI-inspired/RW folded-symbol evaluator 不能把“读取已物化
parent”当成免费的第三种实现：若它在同一个 physical proof 上逐地址、single-valuedly
输出 published hard word，则读取到的 parent cells 要么进入 honest-path support
forcing，要么由一个被计价的同 proof address evaluator 生成。若这两个条件都没有，
ordinary FRI proximity soundness 只给随机 QUERY acceptance，不能完成 Gate I。

这给出一个只针对 Closure 接口的三分：

\[
  \boxed{
  \text{raw recomputation}
  \quad\lor\quad
  \text{same-proof materialized-parent payment}
  \quad\lor\quad
  \text{unbound/model exit}.
  }
  \tag{481.1}
\]

它不是一般 FRI/IOPP/PCS 下界；“payment”可以是 object-scale support、large
address evaluator，或另一个明确计价的 global relation。

## 同一 proof 上的支持分解

令

\[
  B\in\{0,1\}^{N},\qquad z=(z_R,z_M)\in\Sigma^{P}
  \tag{481.2}
\]

是一个固定 honest proof。\(R\) 表示 raw/base/fiber cells，\(M\) 表示显式存储的
folded parent cells；两者也可以是多个 layer 的不交地址集合。对每个
\(j\in[N]\)，令 \(D(j;z)\) 是固定 random tape 后的 adaptive evaluator，至多
读取 \(q\) 个 proof symbols，并满足

\[
  D(j;z)=B[j]\qquad(\forall j\in[N]).
  \tag{481.3}
\]

将真实执行中读取的地址按类型分开：

\[
  L_R^{\rm act}:=\bigcup_{j\in[N]}Q_R(j;z),
  \qquad
  L_M^{\rm act}:=\bigcup_{j\in[N]}Q_M(j;z).
  \tag{481.4}
\]

这里不包括虚假 answer branch 上才会访问的地址。令 \(g\) 计入 evaluator control、
address arithmetic、target map 与 output bookkeeping，令
\(\ell=\lceil\log_2(P+1)\rceil\)、\(a=\lceil\log_2|\Sigma|\rceil\)。

### 引理 481.1（raw/parent honest-path support payment）

在 (481.2)--(481.4) 下，

\[
  \operatorname{CC}(B)
  \le
  O\!\left(
    g+q\bigl(|L_R^{\rm act}|+|L_M^{\rm act}|\bigr)(\ell+a)+\log(N+2)
  \right).
  \tag{481.5}
\]

特别地，若 \(s_R\) 是 raw cells 的实际支持上界，则

\[
  |L_M^{\rm act}|
  \ge
  \frac{\Omega(N/\log N)-g}{q(\ell+a)}-s_R
  \tag{481.6}
\]

在 C455 的同一 hard-length 集合上成立（右端为负时只给出平凡的零下界）。因此，
当 control、query、alphabet 与 raw support 都是 address-scale 时，直接读取
materialized parent 必须暴露 \(N/\operatorname{polylog}N\) 级别的同一-proof cells。

#### 证明

把每个 \(z[p]\)，\(p\in L_R^{\rm act}\cup L_M^{\rm act}\)，硬接为常量，并用
有限 ROM mux 从地址输入恢复它。按每个 \(j\) 的 query step 归纳：第一个地址由
\(j\) 和固定 control 决定；若此前 transcript 与真实执行相同，则下一地址相同，
且按 (481.4) 属于真实 support，mux 返回同一个 symbol。故整个 adaptive transcript
与 \(D(j;z)\) 相同，输出为 \(B[j]\)。这正是 C473 的 honest-path ROM 展开，
但把 support 明确分解成 raw 与 materialized-parent 两类。式 (481.6) 由 C455
的 \(\operatorname{CC}(B)=\Omega(N/\log N)\) 移项得到。\(\square\)

## 被计价的 parent evaluator

支持支付不是唯一方式。设 folded parent cells 由同一个 fixed-proof evaluator

\[
  E_M:\{0,1\}^{\ell_M}\to\Sigma,
  \qquad |E_M|=s_M,
  \tag{481.7}
\]

逐地址生成；其描述、advice 与 alphabet encoding 均已计入 \(s_M\)。若 raw reads
也由一个 evaluator \(E_R\) 生成，大小为 \(s_R^{\rm ev}\)，则把每一次 proof read
替换为相应 evaluator call，得到

\[
  \operatorname{CC}(B)
  \le
  O\!\left(
    g+q_Rs_R^{\rm ev}+q_Ms_M
    +q(\ell+a)+\log(N+2)
  \right),
  \tag{481.8}
\]

其中 \(q_R+q_M\le q\)。纯 materialized-parent 路线取 \(q_R=0\)，(481.8) 就是
C474 的 coding-layer/address-evaluator composition；混合路线只需把 raw side 的
未计价部分改为 (481.5) 的 actual-support ROM。

因此，在 C455 hard lengths 且

\[
  q,g,\ell,a,q_R,q_M=(\log N)^{O(1)},
  \tag{481.9}
\]

若没有 raw-support payment，则

\[
  s_M=\Omega\!\left(\frac{N}{\operatorname{polylog}N}\right).
  \tag{481.10}
\]

把 parent 表作为未计价 ROM 只是在 (481.10) 中把该 object-scale 信息移出模型，
并没有得到 Gate-III 所需的 \(P/\mathrm{poly}\) evaluator。

## 定理 481.2（materialized-parent / raw-recomputation trichotomy）

考虑一个 FRI-inspired RW attachment，它要在同一个 proof 上对每个目标输出一个
folded symbol，并声称可用于 Closure。则必须明确落入以下分支之一：

1. **Raw recomputation.** 目标执行不读取 materialized parent。若 C478 的
   support-isolated physical completion 与 C475/C479 的 raw-family 条件成立，
   则 raw fiber 的 \(b^i\)-support 或 C478 的
   \(\nu-2\beta\) 查询下界生效。
2. **Same-proof materialized parent.** 目标执行读取 parent cells，且存在同一
   \(z\) 上的 (481.3) single-valued correctness。此时引理 481.1 强制 actual
   raw-plus-parent support payment；若改用被计价的 parent evaluator，则 (481.8)
   强制 evaluator payment。两者都保持同一个 published object 与同一地址量词。
3. **Unbound/model exit.** 若既没有 raw completion，也没有同一 proof 上的
   near-proof/single-valued parent correctness，则 ordinary FRI soundness 不能补上
   这个缺口。随机 QUERY acceptance、逐 challenge 的 prover oracle，或一个随 target
   变化的 phantom parent 都不构成 (481.3)，因此不能推出 \(H_A\in P/\mathrm{poly}\)。

### 证明

按目标 evaluator 是否访问显式 parent cells 分情况。否定分支是 1；若访问，则若
(481.3) 成立直接应用引理 481.1，或在存在 (481.7) 时按逐次 read 的 transcript
归纳应用 (481.8)。若 (481.3) 不成立，候选没有为同一个 \(z\) 提供 Gate-I 所需的
all-address single-valued map；ordinary FRI soundness 的随机查询量词弱于
(481.3)，所以不能完成该推导。三分只对声称使用该接口的候选作分类，不对所有
PCP/FRI 对象作不可能性断言。\(\square\)

## 对 Closure 的直接后果

在 C455 的 \(B_n\) 与同一 hard-length 集合上，(481.1) 把“读取 materialized
parent”从一个看似未计价的 loophole 改写为可观测的选择：

\[
  \text{raw completion/query payment}
  \quad\lor\quad
  \text{parent support/evaluator payment}
  \quad\lor\quad
  \text{尚未证明的 same-proof binding}.
  \tag{481.11}
\]

它仍然没有证明 \(P\ne NP\)。真正剩下的正攻问题被精确收窄为：能否为 published
RW/JK canonical history 证明第三分支不存在，同时不把 parent 信息偷偷提升到
object-scale advice。

## 来源

* [C478：FRI fold-graph local-completion and recovery gate](478-fri-fold-graph-local-completion-and-recovery-gate-2026-08-19.md)。
* [C479：FRI challenge-tree staticization trichotomy](479-fri-challenge-tree-staticization-trichotomy-2026-08-19.md)。
* [C473：RW honest-path support forcing](473-rw-honest-path-support-and-exposed-history-pcpp-gate-2026-08-19.md)。
* [C474：RW coding-layer/address-scale Closure](474-rw-coding-layer-address-scale-closure-dichotomy-2026-08-19.md)。
* [C455：published RW hard-output forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
