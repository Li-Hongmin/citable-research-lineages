> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Empty-link loss in the shared-top flag transfer (2026-08-18)

## Result

The flag factorization for the actual shared-top sampler is sound, but the
source instantiation must distinguish the empty link from nonempty links.  In
the Bafna--Minzer--Vyas--Yun (BMVY) complex used by Gur--Minzer--Weissenberg--
Zheng (GMWZ), the published local estimates give

\[
 \Gamma_{+}(d,q)=\operatorname{poly}(d)q^{-1/2}
 \quad\text{for nonempty links},
 \qquad
 \Gamma_{\varnothing}(d,q)\le \frac1{d-1}+\frac2{\sqrt q}
 \quad\text{for the empty link}.
\tag{EL1}
\]

The second term in (EL1) is the global graph estimate in BMVY Theorem 2.13,
item 6.  It cannot be silently replaced by \(O(q^{-1/2})\) when \(d\) is a
fixed constant.

Let

\[
 \lambda_0=\|D_s^k\|_{\mathbf 1^\perp},
 \qquad
 \lambda_1=\sup_{B\in X(s)}
       \|D^{\,d-s}_{\,k-s}\|_{\mathbf 1^\perp,X_B},
\]

where the norms use the conditional face measures.  Applying BMVY Lemma 2.8
globally and in every nonempty \(s\)-link gives

\[
 \lambda_0\le \sqrt{s/k}+P(k)\Gamma_{\varnothing}(d,q),
 \qquad
 \lambda_1\le
 \sqrt{\frac{k-s}{d-s}}+P(d-s)\Gamma_{+}(d,q),
\tag{EL2}
\]

for the polynomial loss \(P\) in that lemma.  This is the correct source
version of the flag estimate; using one common \(O(q^{-1/2})\) parameter is a
stronger statement and is not justified by Theorem 2.13 alone.

For the shared-top operator \(K_{d;k,s}^{\mathrm{top}}=T^*T\), the flag
variance identity gives

\[
 \sigma_2(K_{d;k,s}^{\mathrm{top}})
 \le \lambda_0^2+\lambda_1^2.
\tag{EL3}
\]

Consequently the spectral/mass gate still closes.  Fix the DPT soundness
parameter and let \(\mu_0>0\) be the heavy-cluster mass from GMWZ Lemma 6.2.
First choose a sufficiently large perfect square \(k=r^2\), so that the
\(s=r=\sqrt{k}\) contribution is
small.  Next choose the constant dimension \(d\) large enough that

\[
 P(k)/(d-1)\quad\text{and}\quad (k-s)/(d-s)
\]

are below the remaining \(\mu_0\)-budget.  Finally choose the BMVY field-size
parameter \(q\) large enough that

\[
 P(k)q^{-1/2}+P(d-s)\operatorname{poly}(d)q^{-1/2}
\]

is below the remaining budget.  Then

\[
 \sigma_2(K_{d;k,s}^{\mathrm{top}})<\mu_0/2,
 \qquad
 \Pr[A\in U_i,A'\in U_j]\ge \mu_0^2/2
\tag{EL4}
\]

for every pair of heavy clusters.  Thus the correction changes the parameter
order, not the conclusion: \(d\) must be chosen before the asymptotic field
parameter \(q\), and the empty-link \(1/d\) loss must be budgeted explicitly.

## Evidence boundary

BMVY Definition 2.4 requires local spectral control for every link, including
the empty link.  BMVY Theorem 2.13, item 5 and the link computations provide the
\(q^{-1/2}\)-scale input for nonempty links, while item 6 states the global
second-singular-value bound \(1/(d-1)+2/\sqrt q\).  BMVY Lemma 2.8 is the cited
down/up singular-value estimate.  The flag factorization (EL3) is proved in the
project's statement file and is independent of the source's down-up versus
shared-top sampling distinction.

This result closes only the shared-top spectral and heavy-cluster mass gate.  It
does not provide decoder-marginal transfer \(\xi_{ij}\), label synchronization,
cover-sheet binding, a common global word, or a unique-decoding theorem for
GMWZ.  The source-level claim is therefore a corrected positive bridge, not a
new PCP or \(P\ne NP\) result.

## Sources

* [BMVY, Definition 2.4](https://arxiv.org/html/2407.12762#S2.2), [Lemma 2.8](https://arxiv.org/html/2407.12762#S2.3), and [Theorem 2.13](https://arxiv.org/html/2407.12762#S2.5).
* [GMWZ, Definition 2.7 and Lemma 6.2](https://arxiv.org/html/2512.12960#S6.1).
* Project statement: [flag-conditioned spectral transfer](../../rw-jk-succinct-reconstruction/statements/flag-conditioned-spectral-transfer-for-shared-top-face.md).
