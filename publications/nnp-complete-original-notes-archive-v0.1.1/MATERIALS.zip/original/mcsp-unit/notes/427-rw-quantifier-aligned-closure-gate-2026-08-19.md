> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW quantifier-aligned Closure-Gate（2026-08-19）

## 本轮改变的判断

目前的 singleton parent-binding 障碍与 source-family 递归容量障碍不能被
无条件地揉成一个 family theorem：published Theorem 4.3 固定 \(x_0\) 后，
canonical proof image 是 point mass；而 C426/C425 需要一个 product-rich source
family。可以严谨合并的对象是一个**量词对齐的 Closure-Gate**：先声明 proposed
attachment 属于哪一种 normal form，再调用相应的 payment；若不属于这些
normal form，不能把已有 barrier 偷换成一般不可能性，必须显式给出新的
non-product global relation 或 model exit。

这一步把最终正攻从“继续增加局部障碍”改成一个可证伪的接口选择：

* singleton、同一 parent 的有限 common response 或 JK half-lift DAG；
* public-context product-rich family 的 exact recursive range closure；
* family-level、distance-separated canonical words 的 arbitrary latent coupling。

## 定理 427.1（量词对齐的 RW Closure-Gate）

固定一个 proposed same-object、same-address attachment，其 forcing parent 为
\(B\in\{0,1\}^{b}\)，地址长度 \(m=\lceil\log_2(b+2)\rceil\)，并假设
\(\operatorname{CC}(B)>S\)。以下三类接口分别有独立的必要 payment。

### (S) singleton 接口

若 canonical proof 是固定 singleton，且 attachment 属于以下任一接口：

1. 一个对所有地址共用的有限 descriptor/strategy，显式 address-control 大小
   为 \(p\)，descriptor 长度为 \(d\)，每次至多读取 \(r\) 次，并提供 RW 的
   \(1\) 对 \(1/2\) final-query gap；或
2. \(q\) 个 terminal \(2k\)-bit outsider 及 \(v\) 个不同的 canonical JK
   half-lift 内部节点组成的共享 DAG，descriptor/control 成本为 \(d+s_{\rm ctrl}\)，
   所有 lifted top blocks 覆盖 \(B\)；

则分别有

\[
 \operatorname{CC}(B)
 \le O\bigl(m(p+rd+m)\bigr),
 \tag{427.1}
\]

和

\[
 \operatorname{CC}(B)
 \le O\bigl(s_{\rm ctrl}+d+2kq
       +v(|G_k|+k+\log(b+2))\bigr).
 \tag{427.2}
\]

因此 \(S\) 超过相应 additive control term 时，finite-response 接口必须支付
\(p+rd=\Omega(S/m)\)，half-lift DAG 必须支付 message-scale terminal/control
或离开该 DAG 接口。这里的结论只作用于 singleton；不能由它推出 family-level
RLDC lower bound。

### (F) product-rich source-family 接口

令 \(\Theta\in\{0,1\}^{\nu}\) 是 deterministic canonical selector 的全部公开
context，且在一个 depth-\(d\) JK subtree 中有 leaf families
\(\mathcal A_1,\ldots,\mathcal A_{2^d}\)。假设每个 tuple

\[
 (a_1,\ldots,a_{2^d})
 \in\prod_{\ell=1}^{2^d}\mathcal A_\ell
\]

都由某个 \(\Theta\) 实现为同一 source-compatible canonical proof；所有 leaves
与递归内部 blocks 都是 non-output 且要求落在同一个
\(R_G=\operatorname{Range}(G_k)\)，其中 canonical preimage 在 \(R_G\) 上 injective。
令 \(M=\prod_\ell|\mathcal A_\ell|\)。则

\[
 \boxed{\log_2 M\le \min\{\nu,k\}.}
 \tag{427.3}
\]

特别地，对 aligned product-ECC、码率 \(R\)、block width \(2k\)，有

\[
 2^{d+1}Rk\le\min\{\nu,k\}.
 \tag{427.4}
\]

当 \(\nu,k\) 都是 address-scale 而 \(2^d\to\infty\) 时，固定正码率不能
同时保持 product-rich source、exact recursive range closure 与共同
target-independent \(G_k\)。这仍是 family-level 结论，不适用于 published
fixed-\(x_0\) singleton。

### (G) arbitrary target-independent latent coupling 接口

令 \(X\) 均匀取 \(2^b\) 个 target，canonical words \(\Pi_x\) 两两距离大于
\(2t\)。若 \(S\) 是完整 policy/descriptor/sheet package，\(W\) 是任意有限 latent
global state，产生的 \(Z\) 满足

\[
 X\longrightarrow(S,W)\longrightarrow Z,
 \qquad
 \Pr[d_H(Z,\Pi_X)\le t]=p_b,
\]

则

\[
 \boxed{I_2(X;S)+I_2(X;W\mid S)\ge p_b b-1.}
 \tag{427.5}
\]

所以 sublinear target-independent latent state 不能免费承担一个 constant-success
distance-separated family。若实际 relation 绑定的是 RW systematic Reed--Muller
prefix，则可用 Theorem 3.4 的 Schwarz--Zippel 距离下界实例化 (427.5)；该
实例化仍然需要 proposed closure 真正绑定该 prefix。

## 量词边界与 model-exit 规则

定理 427.1 是一个带显式 normal-form 假设的 union gate，而不是声称任意
reconstruction 都自动落入三类。具体地：

* (S) 可以直接作用于 published singleton；(F)、(G) 需要一个 target family，
  不能把改变 \(x\)、machine、\(G\) 或 stage 当作同一个 fixed-\(x_0\) hidden family；
* (F) 的 public-context 计数与 (G) 的 mutual-information payment 可以同时
  使用，但前提是同一个 family、同一 proof semantics 和同一 target distance；
* 若 proposed attachment 声称仍是 same-proof、same-address、address-scale
  closure，却既不满足 (S)，也没有 (F)/(G) 的明确 family/global-relation
  量词，则现有结果只允许记录为**model-exit branch**。它必须给出不能编译成
  finite common response 或 canonical half-lift 的新 global coupling，或明确
  放弃 common proof、target-independent range closure、word consistency、
  address-scale control、promise-preserving semantics 之一。

因此，不能把 (427.3) 或 (427.5) 套到 published singleton，也不能把 singleton
parent-circuit payment 宣称为一般 dPCP/RLDC impossibility。反过来，不能以
“singleton 没有 family entropy”为理由，跳过一个实际要求 product-rich family
和 exact recursive cover 的 proposed construction。

## 证明

(427.1) 是有限 common-response 的随机 tape 采样、union bound 和 descriptor
ROM 展开；(427.2) 是共享 JK half-lift DAG 的拓扑展开。两者分别就是 C231/C417
的 singleton parent-binding estimates。

对 (427.3)，一个 deterministic context 只产生一个 leaf tuple，因此实现
\(M\) 个不同 tuples 至少需要 \(M\le2^{\nu}\) 个 contexts。递归地应用 injective
canonical preimage 时，不同 leaf tuples 产生不同 root blocks，而 root blocks
都在 \(R_G\)，故 \(M\le|R_G|\le2^k\)。合并即得 (427.3)。Product-ECC 代入
\(|\mathcal A_\ell|=2^{2Rk}\) 得 (427.4)。

对 (427.5)，由距离 \(>2t\) 的 nearest-word decoding，事件
\(d_H(Z,\Pi_X)\le t\) 以概率 \(p_b\) 给出 \(X\) 的正确猜测；Fano 首先给出
\(I(X;S,Z)\ge p_b b-1\)。Markov 条件和 data processing 给出
\(I(X;Z\mid S)\le I(X;W\mid S)\)，再用 chain rule
\(I(X;S,Z)=I(X;S)+I(X;Z\mid S)\) 即得。

## 对 Closure Theorem 的直接含义

如果要完成 C181 的 \(P=NP\Rightarrow H_A\in P/\mathrm{poly}\) 终点，
下一项正攻不能再以“另一个局部 decoder”作为完成标准。它必须在以下三项中
至少选择一项并给出新证明：

1. 证明 actual published singleton 属于 (S) 且同时给出 address-scale
   whole-parent evaluator；
2. 证明 actual source family 的 leaf entropy collapse 或 systematic-output
   attachment，使其避开 (F) 的 product-rich 深递归容量门；
3. 构造 (G) 之外的真正 non-product、同一 proof 的 global relation，并精确
   说明其如何处理 bottom、cover、descriptor 和 address scale。

在这三项之外继续增加局部障碍不会改变 C181 的 Gate-I/II/III 判定。

## 证据边界

本定理合并并重新对齐 [C410](410-rw-singleton-jk-lift-parent-binding-circuit-cost-2026-08-19.md)、
[C417](417-rw-shared-half-lift-dag-parent-binding-2026-08-19.md)、
[C422](422-rw-arbitrary-joint-coupling-latent-state-information-barrier-2026-08-19.md)、
[C423](423-rw-systematic-rm-prefix-joint-coupling-barrier-2026-08-19.md)、
[C425](425-product-ecc-recursive-depth-rate-law-2026-08-19.md) 与
[C426](426-rw-source-context-double-capacity-theorem-2026-08-19.md)。它是一个
source-specific theorem program，尚未证明 RW actual instance 满足任一正向
normal form，也不证明 \(P\ne NP\)。
