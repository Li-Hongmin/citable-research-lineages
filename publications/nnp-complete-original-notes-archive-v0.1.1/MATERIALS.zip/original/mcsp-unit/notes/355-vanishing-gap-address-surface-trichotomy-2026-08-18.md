> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Vanishing-gap tradeoff for address-surface closure

## Contribution

The address-surface theorem (C353) was stated with a fixed acceptance gap. Its
sampling proof gives a quantitative boundary when the gap depends on the table
length. Near-maximum forcing therefore leaves no free vanishing-gap escape at
address scale: a polynomial-size joint surface must make the gap smaller than
every inverse polynomial in the address length, and in the near-maximum regime
it is forced to the square-root sampling boundary.

This is a parameter theorem for one forced table. It is not a family-level RLDC
impossibility theorem and does not by itself prove \(P\ne NP\).

## Theorem (gap--surface--forcing tradeoff)

Let \(H_n\in\{0,1\}^{N_n}\), let
\[
  \ell_n=\lceil\log_2(N_n+1)\rceil,
\]
and, for every address \(a\in[N_n]\), allow an arbitrary finite response
strategy. Let \(W_n(a,R)\in\{0,1\}\) be the resulting acceptance surface on
the fixed target proof, with fan-in-two complexity at most \(U_n\). Suppose
there are numbers \(\alpha_n>\beta_n\) and
\[
  \gamma_n:=\alpha_n-\beta_n>0
\]
such that
\[
H_n[a]=1\Rightarrow \Pr_R[W_n(a,R)=1]\ge\alpha_n,
\qquad
H_n[a]=0\Rightarrow \Pr_R[W_n(a,R)=1]\le\beta_n.
\tag{355.1}
\]

Then, for every fixed \(0<\delta<1\),
\[
\operatorname{CC}(H_n)
\le
C\,\frac{\ell_n+\log(1/\delta+2)}{\gamma_n^2}
\left(
 U_n+
 \log\!\left(
 \frac{\ell_n+\log(1/\delta+2)}{\gamma_n^2}+2
 \right)
\right),
\tag{355.2}
\]
for an absolute constant \(C\). Hence if
\(\operatorname{CC}(H_n)>S_n\), then necessarily
\[
 S_n\le
C\,\frac{\ell_n+\log(1/\delta+2)}{\gamma_n^2}
\left(
 U_n+
 \log\!\left(
 \frac{\ell_n+\log(1/\delta+2)}{\gamma_n^2}+2
 \right)
\right).
\tag{355.3}
\]

### Proof

Set
\[
 t_n=\left\lceil
 C_0\frac{\ell_n+\log(1/\delta+2)}{\gamma_n^2}
 \right\rceil.
\]
Draw \(t_n\) independent public tapes. For a fixed address, Hoeffding's
inequality bounds the probability that the empirical acceptance rate differs
from its expectation by more than \(\gamma_n/3\) by
\[
  2\exp(-2t_n\gamma_n^2/9).
\]
The choice of \(C_0\) makes the union bound over at most \(2^{\ell_n}\) valid
addresses at most \(\delta\). Thus some fixed multiset of tapes separates all
addresses after thresholding at \((\alpha_n+\beta_n)/2\). Hardwiring that
multiset into \(t_n\) copies of the surface costs \(O(t_nU_n)\); a counter and
comparator cost \(O(t_n\log(t_n+2))\). This is (355.2), and (355.3) follows by
rearranging. \(\square\)

## Address-scale consequences

Assume a near-maximum forcing window
\[
  S_n\ge \frac{N_n}{\ell_n^c}
\tag{355.4}
\]
for a fixed \(c>0\), and an address-scale surface
\[
  U_n\le \ell_n^d
\tag{355.5}
\]
for a fixed \(d\). Then:

1. For every fixed \(q>0\), the bound
   \(\gamma_n\ge\ell_n^{-q}\) is impossible on all sufficiently large hard
   lengths. Equivalently, an address-scale surface forces
   \(\gamma_n=\ell_n^{-\omega(1)}\).
2. For every fixed \(\varepsilon>0\), the bound
   \(\gamma_n\ge N_n^{-1/2+\varepsilon}\) is impossible on all sufficiently
   large hard lengths. Thus the surviving gap obeys
   \[
     \gamma_n\le N_n^{-1/2+o(1)}
\tag{355.6}
   \]
   along the hard-length subsequence.

For (1), substituting \(\gamma_n\ge\ell_n^{-q}\) into (355.2) makes the
right-hand side \(\ell_n^{O(1)}\), while (355.4) is exponential in
\(\ell_n\). For (2), substituting
\(\gamma_n\ge N_n^{-1/2+\varepsilon}\) gives
\[
 t_n=O(\ell_n N_n^{1-2\varepsilon}),
\]
and the right-hand side of (355.2) is
\(N_n^{1-2\varepsilon}\ell_n^{O(1)}=o(N_n/\ell_n^c)\), a contradiction.

## RW specialization

At a stable Ren--Williams stage, the forced table \(B_i\) has
\[
  N_i=2n_i,\qquad
  \ell_i=\Theta(\log n_i),\qquad
  \operatorname{CC}(B_i)=\Omega(N_i/\operatorname{polylog}N_i)
\]
on the near-maximum hard lengths supplied by the RW AVOID construction. If an
address-dependent finite strategy has a joint acceptance surface of size
\(\ell_i^{O(1)}\), then it cannot retain a constant or inverse-polynomial
address-scale gap. It must instead have
\[
  \gamma_i=\ell_i^{-\omega(1)}
  \quad\text{and, more sharply,}\quad
  \gamma_i\le N_i^{-1/2+o(1)}.
\]

The published Reconf branch is not contradicted: its final query has a fixed
\(1\) versus \(1/2\) gap, but its quantified circuit witness and common prefix
are object-scale. The theorem says that an attempted address-scale replacement
must pay either object-scale surface complexity or an essentially square-root-small
gap.

## Boundaries

* The proof uses only the fixed-target acceptance surface and the gap in
  (355.1); it does not assume target-relative robustness, a family of messages,
  or a common response strategy.
* The \(N^{-1/2+o(1)}\) boundary is a sampling barrier, not a claim that every
  smaller gap is achievable. Closing that residual requires a separate coding,
  communication, or RW-specific semantic theorem.
* An object-scale Boolean/PH surface, a non-Boolean uncharged random-access
  primitive, or an address space that depends on the target lies outside this
  statement.

## Sources

* [Address-surface closure](353-address-surface-closure-for-per-address-strategies-2026-08-18.md).
* [RW hard-table closure dilemma](232-rw-hard-table-closure-dilemma-2026-08-17.md).
* Ren--Williams, ECCC TR26-118, Theorems 4.1, 4.3, and 4.5:
  <https://eccc.weizmann.ac.il/report/2026/118/>.
