> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW recursive self-describing range-closure（2026-08-19）

## 本轮改变的判断

C425 的 product-ECC depth--rate law 关闭了一个重要但特定的逃逸：每个递归
leaf 都带有独立 payload、所有 leaf tuples 都可实现、并且同一个
\(G_k\) 覆盖所有递归 blocks。这个条件并不覆盖所有可能的正攻。若很多
blocks 共享同一个低度参数，递归 parent 可以只记录一个参数、一个起点和一个
depth；于是两半 preimage 的拼接仍可能由一个 \(k\)-bit seed 生成。

本 note 给出一个严格的 sufficient interface。它把“递归 range-closure”从一句
模糊的 shared structure 拆成可编译的 self-describing generator，并同时给出一个
shared-parameter/local-entropy upper bound。前者是 H_wit 的真实正向候选；后者
说明它不能直接覆盖具有独立 line/ECC payload 的完整 Harsha auxiliary proof。

## 递归自描述系统

固定 \(k\ge1\)、深度 \(D\ge1\)、以及一个有限参数集合 \(\Theta\)。令
\[
  M:=2^{D-1},\qquad
  U:=\{0,\ldots,M-1\}.
\]
对每个 \(\theta\in\Theta\)、\(u\in U\) 和 \(0\le j\le D-1\)，给定一个长度
\(k\) 的 descriptor
\[
  e(\theta,u,j)\in\{0,1\}^{k}.
\tag{434.1}
\]
这些 descriptors 在所有三元组 \((\theta,u,j)\) 上 injective，并且有
poly\((k)\)-size 的 encode/decode circuits。对 \(0\le j\le D-2\) 且
\(u\equiv0\pmod {2^{j+1}}\)，定义
\[
  P_j(\theta,u):=
  e(\theta,u,j)\,\Vert\,e(\theta,u+2^j,j)
  \in\{0,1\}^{2k}.
\tag{434.2}
\]
给定一个 tagged raw-block map
\[
  R:\Theta\times U\longrightarrow\{0,1\}^{2k}.
\tag{434.3}
\]

假设下面的 **range separation** 条件成立：

1. \(R(\theta,u)\) 对 \((\theta,u)\) injective；
2. 所有 \(R(\theta,u)\) 与所有 \(P_j(\theta,u)\) 互不相等；
3. \((\theta,u,j)\mapsto P_j(\theta,u)\) injective；
4. raw 和 recursive 两类输出都避开一个固定 filler word \(0^{2k}\)。

这些条件可以由常数长度的 branch tags 实现；tags 必须属于 proof
serialization，而不能藏在未计费的 descriptor 中。

## 定理 434.1（recursive self-describing range-closure）

在上述条件下，存在一个 generator
\[
  G:\{0,1\}^{k}\longrightarrow\{0,1\}^{2k}
\]
和 canonical inverse \(p\)（在 \(G\) 的有效输出上满足 \(G(p(z))=z\)），使得
对任意固定 \(\theta\in\Theta\)，长度 \(k2^{D}\) 的顶层串
\[
  Y_D(\theta):=
  R(\theta,0)\,\Vert\,R(\theta,1)\,\Vert\cdots\Vert R(\theta,M-1)
\tag{434.4}
\]
在 JK recursion 的每一层都完全落在 \(\operatorname{Range}(G)\)。具体地：

* 第一个 JK stage 的每个 block 是
  \(G(e(\theta,u,0))=R(\theta,u)\)；
* 经过 \(j+1\) 个 preimage stages 后，每个 \(2k\)-bit block 是
  \(P_j(\theta,u)\)（其中 \(0\le j\le D-2\)）；
* 下一次 canonical preimage 正好是 \(e(\theta,u,j+1)\)。

因此 JK 在 \(Y_D(\theta)\) 上返回 easy，而不是 outsider。
当 \(D=1\) 时 \(M=1\)，没有 recursive pair family；上述断言退化为单个
raw block 已在 \(\operatorname{Range}(G)\) 中。

### 证明

在有效 seed 上定义
\[
  G(e(\theta,u,0)):=R(\theta,u),
\qquad
  G(e(\theta,u,j+1)):=P_j(\theta,u).
\tag{434.5}
\]
对其余 \(k\)-bit seeds 定义 \(G(s):=0^{2k}\)。range separation 保证
每一个有效输出在 (434.5) 中有唯一的有效 seed，且 filler 不会成为有效输出，
所以 canonical inverse \(p\) 在这些输出上返回指定的 \(e(\theta,u,j)\)。

顶层 (434.4) 给出第一项。若当前 stage 的 blocks 是 \(R(\theta,u)\)，则
第一次应用 \(p\) 后得到相邻的 descriptors
\[
  e(\theta,2u,0)\,\Vert\,e(\theta,2u+1,0)
  =P_0(\theta,2u),
\]
它由 (434.5) 属于 range。归纳地，若当前 blocks 是
\(P_j(\theta,u)\)，其 canonical preimages 是
\(e(\theta,u,j+1)\)；相邻两个 preimages 拼接后正是
\(P_{j+1}(\theta,u)\)。在 \(j=D-2\) 时得到最后一个 in-range block，JK
完成全部 preimage stages 并进入 easy 分支。证毕。

## Seed budget

若 descriptors 的有效参数只需
\[
  \log_2|\Theta|+\lceil\log_2 M\rceil
  +\lceil\log_2(D+1)\rceil+\tau
  \le k
\tag{434.6}
\]
个 bits（\(\tau=O(1)\) 是 type/tag/padding 成本），并且 raw、encode、
decode circuits 的大小是 poly\((k)\)，则 \(G\) 可由一个
poly\((k)\)-size circuit 实现。定理的关键不是递归深度 \(D\) 本身，而是
同一个 \(\theta\) 被所有 levels 复用；depth 只需 \(\log(D+1)\) 个控制 bits。

## 共享参数与 local entropy 的必要界

上面的正向机制不能覆盖任意“看起来共享”的 family。令一个 depth-\(d\)
subtree 的 leaves 由一个 shared parameter \(\theta\) 和各 leaf 的 local
labels \(\nu_1,\ldots,\nu_{2^d}\) 产生。假设

* \(|\Theta|=2^s\)；
* 每个 \(\nu_\ell\) 有 \(2^h\) 个可能值；
* 所有 tuples
  \((\theta,\nu_1,\ldots,\nu_{2^d})\) 都由 source family 实现；
* 不同 tuples 产生不同的 ordered leaf-value tuples（否则应先把
  \((\theta,\nu_1,\ldots,\nu_{2^d})\) quotient 到实际 leaf values）；
* 所有 leaves 和递归 internal blocks 都必须落在同一个
  \(R_G=\operatorname{Range}(G)\)。

则 canonical-preimage map 从这些 tuples 到 root block 是 injective，因此
\[
  \boxed{s+2^d h\le k.}
\tag{434.7}
\]

证明是 C402 的多层 injectivity：不同 tuple 先在某个 leaf 上不同；沿
canonical preimage 逐层拼接后，root 的 \(2k\)-bit value 仍不同，而
\(|R_G|\le2^k\)。故 tuple 数 \(2^{s+2^dh}\) 不超过 \(2^k\)。

式 (434.7) 是 C425 的 shared-parameter refinement：当 \(s=0\) 时恢复
独立 product-leaf capacity；当 \(h=0\) 时允许任意递归深度的 single-parameter
closure。实际 source 若只有小的 local entropy，(434.7) 给出可量化的深度窗口，
而不是把所有 auxiliary blocks 直接归入“不可能”。

## 低度 polynomial stream 的正向实例

令 \(F\) 是 \(\lambda\)-bit 表示的有限域，令
\[
  q\lambda\le 2k-O(1),
\]
并令 \(\theta=(c_0,\ldots,c_\Delta)\in F^{\Delta+1}\) 是一个 univariate
polynomial 的系数向量，且 \(q\ge \Delta+1\)。把 raw block 定义为该
polynomial 在 \(q\) 个互异连续 public positions 上的 tagged evaluation
block；于是这些评价在系数向量上是 injective。若采用 injective canonical
descriptor（包含 \(\theta\)、block start \(u\)、level \(j\) 和固定 tags），则
充分的 seed budget 是
\[
  (\Delta+1)\lambda+\lceil\log_2 M\rceil
  +\lceil\log_2(D+1)\rceil+O(1)\le k.
\tag{434.8}
\]
Horner evaluation、descriptor packing 和 level arithmetic 都是
poly\((k)\)-size；因此定理 434.1 给出一个 poly\((k)\)-size 的 recursive
range-closure generator。

若是一个 affine-line restriction，则把 line base point 和 direction 加入
\(\theta\)，得到更一般的充分条件
\[
  (\Delta+1+2d)\lambda+\lceil\log_2 M\rceil
  +\lceil\log_2(D+1)\rceil+O(1)\le k.
\tag{434.9}
\]
在额外的 tagged serialization 和 injective descriptor 条件下，这扩展了 C394
的单层 line-block cover：C394 只保证原始 blocks 在 range 中，434.1 还保证
这些 blocks 的 JK preimage blocks 继续在 range 中。

## 对实际 RW/Harsha 的边界

定理 434.1 给出一个真实的 positive H_wit candidate，但当前
Theorem 3.5 并没有自动提供它的全部假设：

1. \(\widetilde A\)、\(P\) 和 \(\Pi_{\rm ZoS}\) 是多变量 oracle；逐 line
   descriptors 的 \(\theta\) 可能随 line 改变。若 line labels 在递归 subtree
   中有 local entropy \(h>0\)，(434.7) 会随着深度指数消耗 seed budget。
2. Harsha 的 binary conversion 和 RW 的 theorem 只给出 proof object
   decomposition，没有规定带 branch tags 的连续 global serialization。tags、
   block alignment 和 verifier inverse map 必须作为新的 source theorem。
3. 即使 auxiliary stream 满足 434.1，systematic output \(B\) 仍可能在
   first failure 之前产生一个 non-range block；这只解决 non-output
   recursive cover，不产生 whole-parent \(B\) 的 evaluator。

所以实际 RW Closure 的剩余二分现在更精确：
\[
\begin{array}{c}
\text{shared low-degree parameter with (434.6)}
 \Longrightarrow \text{recursive non-output cover is constructible};\\
\text{independent line/ECC local entropy}
 \Longrightarrow \text{(434.7) forces depth/rate payment};\\
\text{systematic output and global serialization}
 \Longrightarrow \text{still require a separate parent-binding theorem}.
\end{array}
\]

## 与 \(P\ne NP\) 的关系

本 note 不是 \(P\ne NP\) 证明，也不是一般 dPCP/RLDC impossibility。它的贡献是
提供一个此前缺失的正向 mechanism：**递归自描述 generator** 可以在共享低度
参数下闭合 JK，而 C425 的 product-rich barrier 只在 local entropy 真正独立时
触发。若要把它晋级为顶级 PCP/Range-Avoidance 定理，必须把 tagged
serialization、实际 Harsha oracle 参数和 systematic-output parent binding
全部接上；当前只完成了第一个抽象接口和其严格容量边界。

## 来源与检索边界

* Ren--Williams Theorems 3.4--3.5：\(\widetilde w=(\widetilde A)\)、
  \(P\)、\(\Pi_{\rm ZoS}\) 的 proof decomposition；
* [C394](394-algebraic-block-coverage-ecc-projection-gate-2026-08-18.md)：
  low-degree line-block 的单层 generator；
* [C402](402-jk-recursive-range-closure-capacity-2026-08-18.md)：
  canonical-preimage product capacity；
* [C425](425-product-ecc-recursive-depth-rate-law-2026-08-19.md)：
  product-ECC depth--rate law。

本轮针对 “recursive range closure”, “self-describing recursive encoding”,
“recursive PCP proof encoding” 和 “hierarchical locally decodable code” 做了
arXiv 精确检索（2026-08-19）；未将检索结果中的不相干论文纳入本结论，也不据此
宣称绝对首创。
