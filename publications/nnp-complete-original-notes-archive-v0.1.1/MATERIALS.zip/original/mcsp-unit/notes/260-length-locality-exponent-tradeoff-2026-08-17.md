> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Length--locality exponent tradeoff for shared-proof closure (2026-08-17)

## Contribution

Notes 240--242 treat fixed locality and the near-linear window separately.  The same
RLDC inequality gives a continuous phase diagram: a shared proof of length
\(k^{1+\varepsilon_k}\) forces locality on the order of
\(1/(\varepsilon_k+\log\log k/\log k)\).  Thus the \(\log k/\log\log k\) threshold is
the endpoint of a length--locality tradeoff, not an isolated near-linear calculation.

## Theorem

Fix \(0<\rho<1\), \(\sigma_0>0\), and a binary shared-proof interface with perfect
correct-branch completeness and target-relative wrong-branch error
\(\beta_k\le1-\sigma_0\).  Let \(r_k\) be the adaptive proof-query depth and expose the two
binary claim trees.  Write

\[
Q_k:=2^{r_k+1}-1,\qquad
a_k:=\left\lceil Q_k/\sigma_k\right\rceil,\qquad
\sigma_k:=1-\beta_k\ge\sigma_0,
\tag{260.1}
\]

and let \(N_k\) be the inline length.  Assume the constant-radius condition required by
the Goldberg--Gur--Saraogi lower bound, namely

\[
\delta_0>N_k^{-\sigma_k/(2Q_k)},
\tag{260.2}
\]

where \(\delta_0=\delta_0(\rho)>0\) is the standard inline radius.  If

\[
0\le\varepsilon_k,\qquad N_k\le k^{1+\varepsilon_k},\qquad D_k:=
\frac{38Q_k^4\log^2 2\,\log^2 k}{\sigma_k^2}<k,
\tag{260.3}
\]

then

\[
\frac1{a_k}
\le
\varepsilon_k+
\left(1+\frac1{a_k}\right)\frac{\log D_k}{\log k}.
\tag{260.4}
\]

Consequently, whenever \(Q_k\le k^{o(1)}\) and \(\varepsilon_k=o(1)\),

\[
Q_k
=\Omega_{\sigma_0}\!\left(
\frac1{\varepsilon_k+
(\log Q_k+\log\log k)/\log k}
\right)
\tag{260.5}
\]

whenever the denominator tends to zero.  In particular, if
\(\log Q_k=O(\log\log k)\), then

\[
Q_k=\Omega_{\sigma_0}\!\left(
\frac1{\varepsilon_k+\log\log k/\log k}
\right).
\tag{260.6}
\]

## Proof

The adaptive-to-nonadaptive decision-tree compilation gives a binary weak
\((Q_k,\delta_0,\sigma_k)\)-RLDC of length \(N_k\).  The arbitrary nonadaptive RLDC
bound of Goldberg--Gur--Saraogi gives

\[
N_k\ge
\left(\frac{k}{D_k}\right)^{1+1/a_k}.
\tag{260.7}
\]

Taking logarithms and using \(N_k\le k^{1+\varepsilon_k}\),

\[
(1+\varepsilon_k)\log k
\ge
\left(1+\frac1{a_k}\right)(\log k-\log D_k).
\tag{260.8}
\]

Rearrangement gives (260.4).  Since
\(\log D_k=4\log Q_k+2\log\log k+O_{\sigma_0}(1)\),
\(1+1/a_k\le2\), and \(a_k\le Q_k/\sigma_0+1\), (260.5)--(260.6) follow whenever
the displayed denominator is \(o(1)\); absorbing the additive \(1\) in \(a_k\) only
changes the constant.
\(\square\)

## Regimes

1. **Fixed locality.**  If \(Q_k=Q\) is constant and \(\varepsilon_k=o(1)\), then
   \(1/a_k\le\varepsilon_k+o(1)\), so a fixed \(Q\) forces a polynomially superlinear
   exponent \(1+\Omega_{\sigma_0}(1/Q)\).

2. **Near-linear length.**  If \(N_k\le k(\log k)^c\), then
   \(\varepsilon_k=c\log\log k/\log k\).  Equation (260.6) gives
   \(Q_k=\Omega(\log k/\log\log k)\), recovering the growing-locality threshold.

3. **Intermediate powers.**  If \(\varepsilon_k\gg\log\log k/\log k\) and
   \(Q_k\le(\log k)^{O(1)}\), then \(Q_k=\Omega(1/\varepsilon_k)\).  A route claiming
   proof length \(k^{1+\varepsilon_k}\) must therefore explicitly pay this locality.

The statement is a necessary-condition phase diagram.  It does not assert that any
point on the boundary is achievable, and it does not cover growing proof alphabets without
replacing the binary \(\log^2 2\) factor by the appropriate alphabet term.

## Source and relation to prior notes

* Goldberg--Gur--Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally Decodable Codes
  via Robust Daisies*, Theorem 1: <https://arxiv.org/abs/2511.21659>.
* Fixed-locality compilation: [note 240](240-adaptive-bottom-to-superlinear-rldc-closure-2026-08-17.md).
* Near-linear endpoint: [note 242](242-growing-query-threshold-for-near-linear-closure-2026-08-17.md).
