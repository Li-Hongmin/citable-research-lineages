> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Extended Frege 条件桥：同长度 SAT 见证与 augmented-EF 边界（2026-08-14）

## 结论

Pich--Santhanam 的 Extended Frege（EF）路线不是当前 MCSP／Formula／\(\mathrm{THR}\circ\mathrm{THR}\)
下界到 \(P\ne NP\) 的无条件捷径。它要求两个不同类型的新输入：

\[
\boxed{\text{同长度、一般-Circuit SAT 反例见证}}
\qquad+\qquad
\boxed{\text{EF 或 }\mathrm{EF}+w\text{ 的超多项式 proof lower bound}}.
\tag{1}
\]

现有 MCSP 的受限模型 decision lower bounds 不产生左盒；Resolution、
\(\mathrm{AC}^0\)-Frege、SoS 等弱／不同 proof-system lower bounds 也不产生右盒。

## Pich--Santhanam 的精确接口

固定 \(k\ge1\)。令 \(C\) 取遍有 \(n\) 个输入、至多 \(n\) 个输出、size 至多 \(n^k\) 的
一般 Boolean circuits。对 polynomial-time \(f=(f_1,f_2)\)，其 witnessing formula 为

\[
\begin{aligned}
w_n^k(f):={}&
[\operatorname{SAT}_n(x,y)\to\operatorname{SAT}_n(x,C(x))]\\
&\lor
[\operatorname{SAT}_n(f_1(C),f_2(C))
\land\neg\operatorname{SAT}_n(f_1(C),C(f_1(C)))].
\end{aligned}
\tag{2}
\]

记

\[
W_k(f):\quad \exists n_0\ \forall n\ge n_0,\quad w_n^k(f)\in\mathrm{TAUT}.
\tag{3}
\]

因此，若某个 \(C\) 在长度 \(n\) 的 satisfiable formula 上失败，\(f(C)\) 必须给出**同一长度**
的 formula 及其 satisfying assignment，且可直接验证 \(C\) 在该 formula 上失败。它不是“存在某个
错误长度”的 refuter，也不是针对受限 circuit class 的 distinguishing algorithm。

Pich--Santhanam 的 theorem 给出一个 universal constant \(\varepsilon>0\)：

\[
W_k(f)\ \land\
\mathrm{EF}+w^k(f)\text{ not p-bounded}
\quad\Longrightarrow\quad
\operatorname{SAT}_n\notin\operatorname{Circuit}[n^{\varepsilon k}]
\quad\text{i.o.}
\tag{4}
\]

其 bounded-arithmetic 版本是

\[
S^1_2\vdash W_{k,n_0}(f)\ \land\
\mathrm{EF}\text{ not p-bounded}
\quad\Longrightarrow\quad (4).
\tag{5}
\]

单个固定 \(k\) 的 (4) 只排除一个固定多项式 circuit bound；它本身不是 \(P\ne NP\)。要把
这一模式推进至无固定多项式大小的一般-circuit separation，须对任意大的 \(k\) 提供相应的条件。

## 两个缺口不可互换

### 1. \(W_k(f)\) 是一般 SAT circuit 的同长度 refuter

MCSP 下界处理的是以 truth table 为输入的语言：

\[
N=2^\ell,
\qquad
\operatorname{GapMCSP}[s,t]\notin
\mathrm{Formula}\circ\mathrm{XOR}[N^c]
\quad\text{或}\quad
\mathrm{Formula}[N^c].
\tag{6}
\]

(6) 不构造任何函数 \(f(C)=(x,y)\)，其中 \(C\) 是任意一般 \(n^k\)-size SAT solver，且
\(|x|=n\)。输入尺度也不同：

\[
\text{(6) 的 input 是 }N\text{-bit truth table}
\qquad\ne\qquad
\text{(2) 的 input 是 length-}n\text{ SAT formula}.
\tag{7}
\]

因此 Formula--XOR、one-tape、\(\mathrm{THR}\circ\mathrm{THR}\) 或 CAPP 的现有结果都不能
直接满足 (3)。

### 2. EF lower bound 不能由弱 proof-system lower bound 上推

若 (3) 成立，\(\mathrm{EF}+w^k(f)\) 的 added axioms 都是 tautologies。若 EF p-bounded，
它会为这些 axioms 给出 polynomial-size EF proofs，故

\[
\mathrm{EF}+w^k(f)\text{ not p-bounded}
\quad\Longrightarrow\quad
\mathrm{EF}\text{ not p-bounded}.
\tag{8}
\]

无条件 EF superpolynomial proof lower bound 仍未知。已知 Resolution、
\(\mathrm{AC}^0\)-Frege、Polynomial Calculus 或 SoS lower bounds 的 proof system、measure
及 encoding 均不同，且不存在把它们向上提升为 (8) 的一般 transfer。例如 Austrin--Risse 对其
\(\operatorname{Circuits}_s(f)\) encoding 证明：对每个 \(\eta>0\)，存在 \(d(\eta)\)，当
\(s\ge n^{d(\eta)}\) 时，SoS degree lower bound 为

\[
\operatorname{SoS\text{-}degree}(\operatorname{Circuits}_s(f))
=\Omega_\eta(s^{1-\eta}),
\tag{9}
\]

不是 EF 或 \(\mathrm{EF}+w\) lower bound。

## 路线裁决

Pich--Santhanam 提供的是一个清楚的**条件**桥，而非把已有弱下界自动放大的 theorem。若要沿此路
逐一排除任意固定 polynomial-size SAT circuits，所缺的最小新输入可精确写为：

\[
\begin{array}{ll}
\text{(A)}&\forall k\ \exists f_k\in P:\ W_k(f_k),\\[2mm]
\text{(B)}&\text{对任意大的 }k:\ W_k(f_k)\ \land\
  \mathrm{EF}+w^k(f_k)\text{ 不 p-bounded},\\[2mm]
\text{(C)}&\text{对任意大的 }k:\ S^1_2\vdash W_{k,n_0}(f_k)\ \land\
  \mathrm{EF}\text{ 不 p-bounded}.
\end{array}
\tag{10}
\]

其中 (B) 或 (C) 经 (4)--(5) 对任意所需 circuit exponent 取得 SAT lower bound，因而推出
\(P\ne NP\)；(A) 是该文单列的更强同长度-witnessing 假设，给出其 stated
\(NEXP\not\subseteq P/poly\) consequence。没有一个盒子由当前项目的 MCSP／Formula／
\(\mathrm{THR}\circ\mathrm{THR}\) 结果提供。这不是证明 (A)--(C) 不可能；它只关闭“把目前结果
直接代入 Pich--Santhanam”的路线。

## 来源

- Ján Pich and Rahul Santhanam, *Towards \(P\ne NP\) from Extended Frege lower bounds*,
  JACM 2026, DOI: [10.1145/3801091](https://doi.org/10.1145/3801091)。可公开核验的 ECCC
  TR23-199 版本：Theorem 2（pp. 7--8）和完整证明 Theorem 9（pp. 24--25）；
  [arXiv:2312.08163](https://arxiv.org/abs/2312.08163)。全文缓存：
  `ResearchLibrary/lib/pich2026p/`。
- Per Austrin and Kilian Risse, *Sum-of-Squares Lower Bounds for the Minimum Circuit Size
  Problem*, [arXiv:2311.12994](https://arxiv.org/abs/2311.12994), Theorem 1.1：式 (9) 的
  SoS lower bound，不提供 EF transfer。
- [note 067](067-ops-anti-checker-formula-lifting-boundary-2026-08-14.md)：现有
  Formula-to-Circuit 缺口；本 note 给出 proof-complexity 条件桥为何仍不能跳过该缺口。
