> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# GM–Minzer–Weissenberg–Zheng 的 RLDC 是 Sim-CR 的基准构造（2026-08-16）

## 结论

Gur--Minzer--Weissenberg--Zheng 的 3-query RLDC 构造可以重新解释为一个已经实现的、
具有 corruption model 的 simultaneous coordinate-robust proof/codeword：一个全局 codeword
同时承载所有坐标；构造为每个 `(i,b)` 准备 PCPP，但在第 `i` 个区域只存放真实 bit
对应的 proof block，并用 tag 让错误 bit 进入相反语言的 PCPP 检查。其长度是
`k^2 polylog(k)`，而不是近线性。

因此，当前主攻问题可以精确化为：

> 能否把 `k` 个坐标 PCPP blocks 的全局一致性压缩到近线性长度，而不失去固定坐标
> soundness、同一地址空间和 corruption robustness？

若不能，能否在“独立坐标 proof region”模型中证明一个一般的 direct-sum 下界？

这里的“近线性”必须和 query/alphabet 一起记账。已有工作在更宽松的常数查询参数下有
近线性 RLDC；本项目要攻的不是泛泛的 near-linear RLDC，而是固定小查询（尤其 2-query
dPCP、或不增加额外坐标查询的 PCPP）与同一 global proof 同时成立的组合。GM 论文也把
3-query PCPP/RLDC 的进一步 query-preserving 改进列为开放方向。

## 1. 论文中的结构

论文 Theorem 11.3 的构造先取一个高距离基码
`C0 : {0,1}^k -> Sigma0^(k/rho)`。对每个坐标 `i` 和候选 bit `b`，定义语言

```text
L_{i,b} = { w : exists m, C0(m) = w and m_i = b }.
```

然后为每个 `L_{i,b}` 使用一个 PCPP。令统一的 PCPP block 长度为
`K = k log^C(k)`，实际 codeword 包含：

1. `C0(m)` 的若干重复，用来把错误 message bit 变成大距离错误；
2. 对每个 `i`，只放入真实 bit `m_i` 对应的 `pi_{i,m_i}`，并在 proof symbol 中附加
   该 bit 的 tag。

总长度为 `Theta(k K) = k^2 polylog(k)`。解码器读取第 `i` 个 proof block 的 tag；若
tag 与候选 bit 不符，则调用相反 bit 的 PCPP。由于高距离基码使输入远离
`L_{i,1-m_i}`，PCPP soundness 使该错误路径输出 `bottom`。

## 2. 为什么这是同时坐标鲁棒

它满足 ACRR 的几个关键结构：

- 所有坐标共用同一个 global codeword；
- 坐标 `i` 的 proof block 由同一个 message `m` 的编码产生；
- 错误 bit 不靠平均坐标概率隐藏，而由对应 PCPP 的远距离 soundness 捕获；
- `bottom` 提供 relaxed rejection，正是固定坐标鲁棒性在 corruption model 下的安全出口。

但它没有解决本项目的全部接口：它是 RLDC codeword 而非 RW/JK 的 history proof，长度
是近二次，且 proof blocks 之间的共享只来自 `C0(m)`，不是一个 `k`-bit shared key。

## 3. 直接的压缩目标

设每个坐标的 PCPP block 在任意合法构造中都需要 `K_i` 个 symbols，并且不同坐标的
verifier 只能访问互不重叠的 proof regions。则该模型中有直接的长度下界

```text
length >= sum_i K_i.
```

证明只是地址区域不重叠：每个坐标的完备性/错误 bit soundness 都需要其对应 region；
删除任何一个 region 后，该坐标的 verifier 不能读取其完备 proof。这个下界只针对
“独立 region”模型，不能外推到存在真正共享局部编码的全局构造。

因此近线性 Sim-CR 若存在，必须满足至少一个新机制：

1. 多个坐标的 PCPP witness 在同一 proof symbols 上共享，而不是简单串接；
2. 一个 distributionally sound global proof 同时解释多个坐标；
3. 一种新的 code/proof 让错误单坐标在全局距离上放大，却不复制每个坐标的 verifier；
4. 或证明上述共享机制必然产生 LDC/RLDC 参数矛盾。

## 4. 与 ACRR/RW 的参数关系

把论文的 codeword 看成 RW/JK 的候选 global table，可以直接得到一个 q-scale 的
coordinate-robust object，但 `k^2 polylog(k)` 长度会把 J--K 的输入规模和 proof
table 规模一起推高。它因此是：

- **正向上界基准：** 证明 simultaneous coordinate robustness 在带 relaxed rejection
  的模型中并非空想；
- **压缩基准：** 任何近线性目标都必须超越“每坐标一个 PCPP”范式；
- **负向入口：** 若 RW 的 ACRR 在自然条件下能压缩到近线性，可能诱导一个比现有
  3-query LDC 下界更强的 code/proof object。

若进一步限制 proof/code 为线性，并能把 ACRR 的 corruption 语义正式转成线性 RLDC，
则 Goldberg--Gur--Saraogi 的结果给出 `q`-query 线性 RLDC 长度
`n = k^(1 + Omega(1/q))` 的下界；这是一条真实的超线性 barrier。但 RW/JK 的一般
proof 并不自动线性，因此该结论只覆盖受限模型，不能冒充一般 ACRR impossibility。
它本身也不证明 RW/JK 的 ACRR，也不证明一般近线性压缩不可能。

## 5. 下一项可证伪工作

只保留一个二选一任务：

* **共享构造：** 以 singleton-output bridge（note 175）为入口，尝试让一个
  distributionally sound proof 同时服务所有 `(i,b)`，并显式计算 proof length；
* **共享下界：** 在“坐标 proof regions 仅通过一个长度-s 的 shared key 耦合”模型中，
  证明 `s + key overhead` 或总长度必须达到 `Omega(k K)`，再检查该模型是否覆盖 RW
  的实际 Reconf。

任何只改善单个 PCPP block、复制标签或增加平均采样权重的工作，不满足新的晋级标准。

## 证据来源

- [GM–Minzer–Weissenberg–Zheng, Theorem 11.3 and Theorems 1.9–1.10](https://arxiv.org/html/2512.12960)
- [Goldberg–Gur–Saraogi, linear RLDC lower bound](https://arxiv.org/html/2511.21659)
- [DHK distributional soundness](https://eccc.weizmann.ac.il/report/2015/085/download)
- [Ren–Williams TR26-118](https://eccc.weizmann.ac.il/report/2026/118/)
