> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Selected-policy quantifier gap: perfect coordinate checks with a constant proof

**Status.** This note records a sharp semantic boundary for the RW/JK
coordinate-robustness program. It is a counterexample to any generic upgrade
from “for every target and coordinate there exists a target-dependent policy”
to a common-proof RLDC or dPCP statement. It is not an impossibility theorem
for ordinary PCPs; the point is that the selected-policy-only quantifier is too
weak to express a common proof.

## 1. Weak selected-policy semantics

Fix a proof alphabet (the proof will in fact be constant), a radius
`rho >= 0`, and a soundness threshold `beta < 1`. A common proof map is said
to satisfy **SP(rho,beta)** if, for every target `m` and coordinate `i`, there
is one policy `tau_{m,i}` selected before the verifier runs such that, for both
public claim bits `b`,

1. on the honest proof `Pi(m)`, the correct claim `b=m_i` is accepted with
   probability one; and
2. for every proof `z` with `dist(z,Pi(m)) <= rho`, the wrong claim
   `b != m_i` is accepted by the same selected policy with probability at most
   `beta`.

The policy may read the public claim bit, as an ordinary Merlin strategy does.
The crucial point is that `tau_{m,i}` may depend on the hidden target and on the
coordinate. No target-independent policy index or common strategy is required.

## 2. Counterexample

Let the message family be `M_k={0,1}^k`, let the proof length be any `P>=1`,
and set

\[
  \Pi(m)=0^P \qquad(m\in\{0,1\}^k).
\]

The verifier makes no proof queries, receives the public claim `b`, asks for
one response bit `a`, and accepts exactly when `a=1`. For target `m` and
coordinate `i`, choose the single policy

\[
  \tau_{m,i}(b)=\mathbf 1[b=m_i].
\]

Then the correct claim is accepted with probability one. On every proof in
the `rho`-ball, the same policy returns zero on the wrong claim, so wrong-claim
acceptance is zero, stronger than any prescribed `beta`. Thus SP(rho,beta)
holds for every radius and every `beta>=0`, despite the proof being constant.

Nevertheless no proof-only or common-address decoder can recover the message:
all targets induce exactly the same proof oracle. In particular, for a uniform
target, any decoder whose only target-independent input is the proof has error
at least `1/2` on every coordinate, and the map `Pi` is not injective. Hence
there is no induced positive-radius RLDC, no shared ACRR word, and no
message-inline decoder to which an RLDC lower bound could be applied.

## 3. What the example proves—and what it does not

The example is a quantifier separation, not a PCP lower bound. It proves that
the implication

\[
  \forall m,i\;\exists\tau_{m,i}\;\text{(coordinate completeness and
  wrong-claim soundness)}
  \quad\Longrightarrow\quad
  \text{common-proof RLDC}
\]

is false without an additional target-independent binding condition. The
selected strategy simply stores the target bit in an uncharged target-
dependent policy; the proof carries no information. If the intended protocol
does not permit such a policy, that restriction must be stated as part of the
model rather than inferred from selected-policy soundness.

The example therefore closes one tempting but invalid rescue of the Closure
Gate. A valid route must add at least one of the following:

- a single global selector `exists tau_m forall i` using one strategy/address
  space for every coordinate;
- soundness for every policy in a target-independent finite policy family;
- a finite pre-coordinate descriptor whose target information is charged by
  the strategy-inclusive entropy/core inequality; or
- a transcript-level ROC/robustness condition that rules out the
  target-dependent response channel.

These are exactly the extra hypotheses appearing, respectively, in C199,
C183/C256, and the ROC frontier C239. The counterexample is compatible with
all of them because it violates their common-policy or all-policy quantifiers.

## 4. Relation to phantom words

The familiar `forall i exists w_i` phantom-word example shows that separately
chosen witnesses need not concatenate to one legal word. The present example
is strictly sharper for the Closure Gate: even when one policy is selected per
`(m,i)` and it handles both claim values perfectly, the selected policy itself
can encode the target bit. Thus “selected-policy-only” is not merely missing a
word-consistency proof; without a target-independent binding rule it does not
force the proof map to carry any message information at all.

**Conclusion.** Selected-policy-only soundness must be treated as a semantic
escape class, not as an unfinished step toward RLDC. Any top-tier closure
theorem has to state and use a common selector, all-policy soundness, finite
strategy information accounting, or an equivalent robust transcript condition.
