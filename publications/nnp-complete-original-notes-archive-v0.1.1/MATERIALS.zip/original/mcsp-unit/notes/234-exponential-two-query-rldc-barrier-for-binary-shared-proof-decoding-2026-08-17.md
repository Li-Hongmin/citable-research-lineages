> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exponential 2-query RLDC barrier for binary shared-proof decoding (2026-08-17)

## Contribution

The recent exponential lower bound for binary Hamming 2-query relaxed locally
decodable codes gives a sharp restriction on one important version of the
shared-proof closure target.  If a single binary proof word directly supports
every message bit through a **one-output**, at-most-two-query relaxed decoder,
with perfect honest completeness and a fixed positive Hamming radius, then the
proof length is exponential in the message length.  Consequently, a binary
near-linear RW/JK closure cannot use this direct 2-query interface.

This is deliberately narrower than the two-claim ACRR interface in note 01.
Thresholding two claim verifiers generally uses more than two proof queries, so
the theorem below must not be presented as an automatic lower bound for every
coordinate-robust dPCP.  Its value is a clean phase-transition barrier at the
direct binary 2-query point.

## Direct shared-proof decoder

Let

\[
  \Pi:\{0,1\}^k\longrightarrow\{0,1\}^P
\]

be an injective proof map.  Fix constants \(\delta>0\) and
\(\varepsilon>0\).  Assume that every received word within relative Hamming
distance \(\delta\) of a codeword has a unique nearby codeword; a sufficient
condition is

\[
  \operatorname{dist}(\Pi(m),\Pi(m'))>2\delta
  \qquad(m\neq m').
\tag{234.1}
\]

For every coordinate \(i\in[k]\), let \(\mathsf{Dec}_i\) be a randomized,
possibly adaptive decoder which reads at most two bits of its received word and
outputs an element of \(\{0,1,\bot\}\).  Require:

\[
\Pr[\mathsf{Dec}_i^{\Pi(m)}=m_i]=1
\qquad\text{for every }m,i,
\tag{234.2}
\]

and, for every \(z\) satisfying
\(\operatorname{dist}(z,\Pi(m))\le\delta\),

\[
\Pr[\mathsf{Dec}_i^z\in\{m_i,\bot\}]
   \ge \frac12+\varepsilon .
\tag{234.3}
\]

The same proof word \(\Pi(m)\), the same physical address space, and the same
decoder family are used for all coordinates.  No linearity or projection
assumption is made.

## Theorem (binary direct-2-query barrier)

Under (234.1)--(234.3),

\[
  P\ge 2^{\Omega_{\delta,\varepsilon}(k)}.
\tag{234.4}
\]

### Proof

The pair \((\Pi,\{\mathsf{Dec}_i\}_{i\in[k]})\) is exactly a weak adaptive
\((2,\delta,1/2+\varepsilon)\)-RLDC over the binary alphabet: (234.2) is
perfect completeness, and (234.3) is the relaxed-decoding condition.  Theorem 1
of Block, Blocki, Cheng, Grigorescu, Li, Zheng, and Zhu therefore gives
\(P=2^{\Omega_{\delta,\varepsilon}(k)}\).  Condition (234.1) only makes the
“unique nearby codeword” promise explicit; it is not otherwise used in the
reduction.

The cited theorem applies even to adaptive decoders and only assumes the first
two weak-RLDC conditions.  It crucially uses binary symbols and perfect
completeness; the source explicitly leaves larger alphabets and imperfect
completeness outside its lower-bound theorem.

## RW/JK consequence

Suppose a proposed RW closure uses a binary proof map with

\[
  P=\operatorname{poly}(k),
\]

and claims a direct one-output, two-query decoder satisfying a fixed positive
radius and the perfect-completeness/relaxed-decoding conditions above.  Then
(234.4) is a contradiction for all sufficiently large \(k\).  In particular,
the near-linear target \(P=\widetilde O(k)\) is impossible in this restricted
model, independently of RW's particular PCP encoding or of linearity.

This closes a precise version of the binary (q=2) branch of Closure Gate I:
the direct decoder cannot remain at address scale.  Any surviving construction
must change at least one of the following:

1. use more than two proof queries;
2. use a non-binary alphabet;
3. give up perfect honest completeness;
4. let the radius or decoding gap vanish with (k);
5. use a genuinely different output/interaction model rather than a direct
   one-output relaxed decoder.

These are model escapes, not claims that a general simultaneous coordinate-robust
dPCP is impossible.

## Boundary with the existing two-claim ACRR compiler

The common-proof interface in note 01 has two verifiers
\(V_{i,0},V_{i,1}\), one for each claimed bit.  Its generic thresholding
compiler repeats both branches and has locality

\[
  O\!\left(q(\alpha-\beta)^{-2}\right),
\]

which need not equal two even when each claim verifier has (q=2) queries.
Therefore Theorem (234.4) does **not** automatically apply to that compiler.
To invoke the exponential bound, one must additionally supply a direct
two-query output rule \(\mathsf{Dec}_i\) with (234.2)--(234.3), or a separate
query-preserving conversion that keeps locality exactly two and preserves
perfect completeness.  The latter is not provided by ordinary thresholding.

This distinction is essential: the theorem rules out a sharply specified
low-query closure interface, not every route through two-branch coordinate
robustness, bottom behavior, distributional soundness, or cover-aware global
proofs.

## Source boundary

The external input is Theorem 1 and Definition 1 of:

> A. R. Block, J. Blocki, K. Cheng, E. Grigorescu, X. Li, Y. Zheng, and
> M. Zhu, *Exponential Lower Bounds for 2-query Relaxed Locally Decodable
> Codes*, arXiv:2602.20278v2 (2026).

Source: <https://arxiv.org/abs/2602.20278>.

The source theorem is a binary Hamming-RLDC theorem.  Extending (234.4) to
larger alphabets, imperfect completeness, or the general two-claim ACRR
interface requires a new argument and is not asserted here.

## What this changes

The new barrier is stronger than a generic “coordinate robustness implies some
RLDC” observation: at the exact direct binary 2-query point it upgrades the
length cost from superlinear to exponential.  The next Closure-Theorem attack
therefore should not spend effort trying to make a binary near-linear
one-output 2-query interface work.  The meaningful positive targets are now
the (q\ge3\), larger-alphabet, imperfect-completeness, or genuinely
two-branch/global-consistency regimes; each must be tested against its own
coding lower bound rather than imported into (234.4).
