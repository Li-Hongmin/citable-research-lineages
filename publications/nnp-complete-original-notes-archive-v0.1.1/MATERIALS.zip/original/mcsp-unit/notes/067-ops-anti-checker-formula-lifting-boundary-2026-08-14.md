> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# OPS anti-checker 的 Circuit--Formula lifting 边界（2026-08-14）

## 结论

Oliveira--Pich--Santhanam (OPS) 的 anti-checker 构造不能把其
\(U_2\)-Formula 下界自动提升为一般 Circuit 下界。

更精确地，OPS \S4.2 的顺序重用只支持如下**定性**事实：其给定的
anti-checker circuit 实现，若按不共享的公式语法直接展开，可能反复重算先前状态。
它不支持下列任一无条件断言：

\[
\begin{aligned}
&\text{该构造的展开必有 }2^{\Omega(t)}\text{ size};\\
&\text{任何等价 Formula 必有 }2^{\Omega(t)}\text{ size};\\
&\operatorname{GapMCSP}\notin\mathrm{Formula}[N^{2-\alpha}]
\Longrightarrow
\operatorname{GapMCSP}\notin\mathrm{Circuit}[N^{1+\varepsilon}].
\end{aligned}
\tag{1}
\]

因此 [000](000-cutover-2026-08-13.md) 中剩余的

\[
U_2\text{-}\mathrm{Formula}\ \longrightarrow\ \mathrm{Circuit}
\tag{2}
\]

模型缺口没有被 OPS 的 sequential-reuse remark 填补。这是一个有范围的路线关闭，
并非证明任何未来 Formula-to-Circuit transfer 不可能。

## OPS 实际构造

设 \(N=2^n\)，\(t=2^{10\beta n}\)，\(t_0=t-n^3\)。OPS 的 Lemma 17 所构造的
circuit 顺序计算

\[
a^{(i)}=((y_1,f(y_1)),\ldots,(y_i,f(y_i))),\qquad 1\le i\le t_0.
\tag{3}
\]

第 \(i\) 轮对每个 \(y\in\{0,1\}^n\) 以 \(a^{(i-1)}\) 为输入调用某个
\(C_{n,i}\)，得到近似计数，再选取 minimizer \(y_i\)。随后 \(D_{n,t_0}\)
列出至多 \(n^3\) 个 survivor，\(n^3\) 个 \(E_n\) 完成输出。

原文唯一的 Formula 结论是：后续轮次会 inspect 先前的 \(y_j\)，故在公式中相应 bits
need to be recomputed，overall complexity becomes ``prohibitive''；它还单独指出
min-selection 未必易于以 subquadratic Formula 模拟。该段没有给出门级 fan-out、live path、
不化简展开大小或语义 Formula lower bound。

## 精确但条件性的 DAG 引理

固定一个 fan-in-two DAG \(C\)、输出门 \(o\)，将每一次 gate use 复制而不做代数化简，
记结果为 \(\operatorname{Unf}(C,o)\)。对任一输入门 \(x\)，

\[
\operatorname{occ}_x(\operatorname{Unf}(C,o))
=\#\{\text{DAG 中从 }x\text{ 到 }o\text{ 的有向路径}\}.
\tag{4}
\]

这是从 \(o\) 反向拓扑归纳：每个 parent use 恰复制其 child 的每个 occurrence。

故若另行给出 gates \(g_0,\ldots,g_r\)，并证明每层从 \(g_{i-1}\) 到 \(g_i\)
至少有 \(b_i\) 条可拼接的 **live** paths，则

\[
\bigl|\operatorname{Unf}(C,g_r)\bigr|
\ge\prod_{i=1}^r b_i.
\tag{5}
\]

例如每层都有 \(b\ge2\) 条这样的路径时才得到 \(b^r\) 的**指定语法**展开界。要把 OPS 的
\(N\) 个候选调用变成 \(N^{t_0}\)，还须证明每个 candidate branch 对同一后续 state coordinate
均保持 live 且这些路径跨轮可拼接。

OPS Proposition 20 只断言存在 approximate-count circuits \(C_{n,i}\)；
minimizer 也只有 size upper bound。它没有给出式 (5) 所需的 path certificate：

\[
\begin{array}{c}
\text{state input}\to\text{count output 的 live path},\\
\text{count output}\to\text{chosen next-state bit 的 live path},\\
\text{以及它们跨 }\Omega(t)\text{ rounds 的可拼接性}.
\end{array}
\tag{6}
\]

所以“每轮把 state feed 给 \(N\) 个候选”不等于式 (5) 的假设。

## 两个必要区分

仅有顺序依赖不强迫指数展开：

\[
s_0=x,\qquad s_i=s_{i-1}\land z_i
\tag{7}
\]

有 \(t\) 轮 state chain，而直接 Formula 展开仅为 \(O(t)\)。

反过来，即使某个 chosen DAG 的 raw unfolding 指数大，也不能给出任意等价 Formula 的下界：

\[
s_0=x,\qquad
s_i=(s_{i-1}\land z_i)\lor(s_{i-1}\land\neg z_i).
\tag{8}
\]

不化简展开满足 \(\Theta(2^i)\) recurrence，但恒等式给出 \(s_i\equiv x\)，
故它有 size-one Formula。于是

\[
\text{raw unfolding cost}\not\Longrightarrow\text{semantic Formula lower bound}.
\tag{9}
\]

## 仍成立的弱界与路线裁决

若把 \(tn\) 个输出强制写成完全不共享的 Formula forest，则仅有平凡 leaf 下界

\[
tn=\Theta\!\left(n2^{10\beta n}\right)=N^{10\beta}\log N,
\tag{10}
\]

对一般所需的 \(N^{2-o(1)}\) 级别没有作用；对单一输出甚至不推出超常数下界。

因此下一条可检验入口必须是以下之一，而不是从 OPS remark 推导下界：

\[
\boxed{
\begin{array}{l}
\text{为 canonical anti-checker implementation 给出 persistent live-path certificate；或}\\
\text{给出可证明的 semantic Formula lower bound；或}\\
\text{发现新的 Formula-to-Circuit magnification/transfer theorem。}
\end{array}}
\tag{11}
\]

## 来源

- Igor Carboni Oliveira, Ján Pich, and Rahul Santhanam,
  *Hardness Magnification near State-of-the-Art Lower Bounds*, CCC 2019,
  \S4.1--4.2，尤其 Lemma 17、Proposition 20 与 pp. 19--20 的 Formula remark。
  全文：`ResearchLibrary/lib/oliveira2019hardness/oliveira2019hardness.pdf`。
- [note 000](000-cutover-2026-08-13.md)：当前 exact Gap-MCSP general-Circuit
  magnification 的模型缺口。
