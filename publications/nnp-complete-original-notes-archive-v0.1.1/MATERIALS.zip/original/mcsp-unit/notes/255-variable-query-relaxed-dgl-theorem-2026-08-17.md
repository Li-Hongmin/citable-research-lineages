> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A variable-query relaxed-DGL theorem and an adaptive RLDC barrier (2026-08-17)

## Status and contribution boundary

This note isolates a theorem that is useful independently of the RW/JK program. Dall'Agnol--Gur--Lachish (DGL) state their relaxed-local application with constant query complexity, although their structural theorem for ordinary robust local algorithms tracks a variable query parameter. Here we re-run the relaxed two-output argument with the query parameter retained. The result below is therefore a theorem derived from the DGL proof ingredients, not a claim that the source paper states this growing-query relaxed theorem.

The only imported combinatorial facts are DGL's daisy partition, volume lemma, error reduction, randomness reduction, and Claims 6.2--6.5. The parameter calculation is written out so that the extension can be checked without silently treating a growing query count as a constant.

### Source-status audit (2026-08-18)

The source distinction is precise. Dall'Agnol--Gur--Lachish Theorem 6.1 is a
variable-query theorem for the general robust-local model: after their
error/randomness reduction, the normalized parameter satisfies
`q=O(ell log ell)`, with sample factor
\(O(|\Sigma|^q\log|\Sigma|)N^{1-1/(2q^2)}\).  The relaxed-local application
Theorem 7.7, and the relaxed-LDC Corollary 7.8, are stated for
\(\ell=O(1)\).  Thus this note does not attribute the growing-\(Q\) relaxed
statement to the source.  It audits the source construction's Q-dependent
kernel, threshold, and Chernoff estimates and supplies the missing relaxed
two-output transfer under (255.2)/(255.2').  The source report is
<https://eccc.weizmann.ac.il/report/2020/154/>.

For the binary specialization, the other growth assumptions displayed after
DGL Theorem 6.1 are also met in this window: the normalized query count can be
taken with \(Q\ge\ell\), so (255.2) implies
\(\ell=o((\log N)^{1/3})\), which is stronger than the source's
\(\ell=o(\sqrt{\log N}/\log\log N)\) condition; the fixed alphabet
\(|\Sigma|=2\) satisfies the source alphabet-growth condition.  These are
source hypotheses, not additional conclusions of the derived theorem.

## 1. Variable-query relaxed structural theorem

Fix an explicit parameter \(z\). Let \(M_N\) be a binary relaxed local
algorithm with main input length \(N\), valid-input set \(V_N\), locality
\(\ell=\ell(N)\), error at most \(1/3\), and robustness radii at least a fixed
constant \(\rho>0\) on both output values. We assume the nondegenerate case in
which both values have a \(\rho\)-robust point for this \(z\); if one value is
absent, the corresponding constant-output problem is trivial and can be
handled separately. Let \(Q\) be the normalized query count after amplification
and randomness reduction, with

\[
  2\le Q\le C_0\ell\log(\ell+2).
\tag{255.1}
\]

Assume

\[
  Q^3=o(\log N).
\tag{255.2}
\]

We take \(|\Sigma|\ge 2\); the binary case has \(|\Sigma|=2\).
The same proof has a quantitative form: there is a constant
\(\eta=\eta(\rho,|\Sigma|)>0\) such that the hypothesis

\[
  Q^3\le \eta\log N
\tag{255.2'}
\]

is sufficient for all the estimates below (after increasing the finite-
length cutoff). We state the theorem with the cleaner asymptotic condition
(255.2), and record the quantitative consequence in Section 2.

### Theorem 1 (derived variable-query relaxed-DGL theorem)

There is a sample-based relaxed local algorithm \(N_N\), with the same valid-input set \(V_N\), whose sample complexity is at most

\[
  S(N)\le C_1\,2^Q Q\,N^{1-1/(2Q^2)}.
\tag{255.3}
\]

The constants depend only on the fixed error and robustness parameters. For a fixed finite alphabet \(\Sigma\), the factor \(2^Q\) is replaced by \(O(|\Sigma|^Q\log|\Sigma|)\), under the corresponding DGL alphabet-growth condition.

### Proof

Amplify \(M_N\) to error \(1/(16Q)\) and then apply DGL's randomness reduction. Repeated or dummy queries normalize every branch to exactly \(Q\) distinct positions. The resulting relaxed algorithm \(M'_N\) has error

\[
  \sigma=\frac1{8Q}
\tag{255.4}
\]

and a uniform distribution over a multi-collection of at most

\[
  |\widetilde\mu|=\frac{6N\log|\Sigma|}{\sigma}
  =O(NQ\log|\Sigma|)
\tag{255.5}
\]

query trees. The fixed-point inequality in the amplification step is the standard solution of \(Q=O(\ell\log(16Q))\), which yields (255.1); choosing \(Q\ge2\) makes \(5\sigma\le1/2\), the threshold used in DGL Claim 6.4.

If the raw normalized count is \(0\), the fixed explicit-input problem is
constant and is handled separately. If it is \(1\), pad to \(Q=2\); this only
changes the constant-query case and keeps the source-level theorem applicable.
Thus all uses of (255.1) below are in the \(Q\ge2\) regime.

For each output bit \(b\in\{0,1\}\), retain the tuples whose tree output is \(b\), and apply the DGL Section 6.1 sample construction. The two constructions use the same Bernoulli sample \(R\subseteq[N]\), with

\[
  \gamma=48|\Sigma|^Q\log|\Sigma|,
  \qquad p=\gamma N^{-1/(2Q^2)}.
\tag{255.6}
\]

The binary parameter checks are as follows. First,

\[
  \log p\le Q\log2+O(\log(Q+2))-\frac{\log N}{2Q^2}=-\omega(1)
\tag{255.7}
\]

by (255.2), so \(p=o(1)\). DGL Claim 6.2 gives, for every daisy layer \(j\),

\[
  |K_j|\le \gamma Q^2N^{1-\max\{1,j\}/Q},
  \qquad
  \frac{|K_0|}{N}=O(2^Q Q^2N^{-1/Q})=o(1).
\tag{255.8}
\]

Thus the fixed robustness radius dominates every kernel for sufficiently large \(N\). The phrase “sufficiently large” is uniform over all layers \(j\le Q\): (255.2) implies

\[
  \frac{N^{1/(2Q)}}{(Q+2)^3\log|\Sigma|}\longrightarrow\infty .
\tag{255.8a}
\]

In particular \(pN=\gamma N^{1-1/(2Q^2)}\to\infty\), so the source
cutoff that aborts when the Bernoulli sample exceeds \(2pN\) has probability
at most \(1/10\) after the same finite-length cutoff.

In the Chernoff estimates of Claims 6.4 and 6.5, the common term is

\[
  N^{1-\max\{1,j-1\}/Q}p^j
  =\gamma^jN^{1-\max\{1,j-1\}/Q-j/(2Q^2)}
  \ge \gamma^jN^{1/(2Q)}
\tag{255.9}
\]

for \(1\le j\le Q\). The daisy partition also gives

\[
  \log(20t_j)\le \frac{\max\{1,j-1\}}{Q}\log N+O(1),
\]

where \(t_j\) is the partition parameter in DGL Claims 6.4--6.5. Thus
(255.8a) dominates the additive threshold term uniformly in \(j\).

The \(j=1\) robust estimate, which is hidden by fixed-\(Q\) notation in the
source proof, has exponent

\[
  E_1=\frac{\rho\gamma}{48Q}N^{1-1/(2Q^2)}.
\]

The kernel union bound asks for
\(E_1\ge (\log|\Sigma|)\gamma Q^2N^{1-1/Q}+\log(10Q)\).
After division by \(\gamma N^{1-1/Q}\), this follows from

\[
  \frac{\rho}{48\log|\Sigma|\,Q^3}
  N^{1/Q-1/(2Q^2)}\longrightarrow\infty,
\]

which is implied by (255.8a), since
\(1/Q-1/(2Q^2)\ge 1/(2Q)\). For \(j>1\), the corresponding ratio is

\[
  \frac{N^{1-(j-1)/Q-j/(2Q^2)}}{Q^2N^{1-j/Q}}
  =\frac{N^{(2Q-j)/(2Q^2)}}{Q^2}
  \ge \frac{N^{1/(2Q)}}{Q^2},
\]

so the same uniform margin proves the \(j>1\) union bound. On a robust
input, Claim 6.5 therefore gives per-kernel-assignment error
\(|\Sigma|^{-|K_j|}/(10Q)\). Summing over the \(|\Sigma|^{|K_j|}\) assignments and the \(Q\) layers costs at most \(1/10\), exactly as in the source proof, now with all \(Q\)-dependence explicit.

For the branch with the correct value \(b\), DGL Claim 6.4 gives output \(b\)
with probability at least \(9/10\) on a valid input. For the opposite branch,
the same input is robust with value different from that branch, so Claim 6.5
bounds the probability of outputting the wrong bit by \(1/10\). On an input
outside the valid set, the relaxed-local definition supplies the
\(\{f(z,x),\bot\}\) guarantee; the two branch constructions preserve that
guarantee with the same constant error budget. The combined algorithm
outputs \(b\) only if the \(b\)-branch outputs \(b\) and the opposite branch
does not output \(1-b\), and outputs \(\bot\) otherwise. The shared sample
changes the constants only by a union bound, preserves \(V_N\), and gives
sample complexity (255.3). \(\square\)

## 1A. Imperfect-completeness common-proof closure

The preceding transfer also closes the fixed-gap imperfect-completeness interface.
This is the version that matches a coordinate-robust PCP whose correct branch is
not perfectly complete.

### Theorem 2 (derived adaptive ACRR barrier with growing locality)

Let
\[
  \Pi:\{0,1\}^{k}\to\{0,1\}^{P}
\]
be a common proof map. For every \(i\in[k]\) and \(b\in\{0,1\}\), let
\(V_{i,b}\) be a randomized adaptive verifier making at most \(r_k\) proof
queries. Assume constants \(0<\rho<1\) and \(\Delta>0\), and numbers
\(\alpha,\beta\) with \(\alpha-\beta\ge\Delta\), such that
\[
  \Pr[V_{i,m_i}^{\Pi(m)}\text{ accepts}]\ge\alpha,
\qquad
  d_H(z,\Pi(m))\le\rho P
  \Longrightarrow
  \Pr[V_{i,1-m_i}^{z}\text{ accepts}]\le\beta .
\tag{255.20}
\]
Let \(R=R(\Delta)\) be a sufficiently large constant and put
\[
  \ell_k:=2Rr_k,\qquad
  2\le Q_k\le C_0\ell_k\log(\ell_k+2),
\tag{255.21}
\]
where \(Q_k\) is the normalized query parameter of Theorem 1. If
\(Q_k^3=o(\log P)\), then \(\Pi\) has a binary relaxed local decoder of
constant radius and constant error, and
\[
  P\ge
  \left(
    \frac{k-1}{C_2\,2^{Q_k}Q_k\log(k+2)}
  \right)^{1/(1-1/(2Q_k^2))}.
\tag{255.22}
\]
The constants depend only on \(\rho,\Delta\).

In particular, the proof below shows that the image is injective, so \(P\ge k\).

Consequently, if \(P\le k(\log k)^c\) for infinitely many \(k\), then along
that subsequence
\[
  Q_k=\Omega_{\rho,\Delta,c}\bigl((\log k)^{1/3}\bigr),
\qquad
  r_k\log(r_k+2)=\Omega_{\rho,\Delta,c}\bigl((\log k)^{1/3}\bigr).
\tag{255.23}
\]
This is a derived theorem from the parameter-tracked transfer above; it is not
being attributed to DGL as a stated growing-query relaxed-LDC theorem.

### Proof

First, the proof map is injective with relative distance greater than \(\rho\).
If two messages differ at coordinate \(i\) but their proofs are within
\(\rho P\), use the proof of one message as \(z\) in (255.20) for the other.
The same branch then has acceptance at least \(\alpha\) by completeness and at
most \(\beta\) by wrong-branch soundness, a contradiction.

On a requested coordinate \(i\), run each of the two claim branches
independently \(R\) times and compare its empirical acceptance rate with
\(t=(\alpha+\beta)/2\). Output the unique branch above \(t\), and output
\(\bot\) otherwise. Chernoff bounds give, for \(R=O(\Delta^{-2})\), constant
completeness and error (for example \(5/6\) and \(1/6\)) on exact codewords.
On every \(\rho P\)-near proof, the wrong branch crosses \(t\) only with
constant probability below \(1/6\); hence the decoder outputs either the target
bit or \(\bot\), with no wrong output except on that event. Its adaptive locality
is at most \(\ell_k=2Rr_k\), and its robust radius is any fixed \(\delta<\rho\).

Apply Theorem 1 to this relaxed local algorithm. The shared-sample construction
can be reused for all \(k\) message coordinates; \(O(\log(k+2))\) independent
repetitions then recover the entire message with probability at least \(2/3\).
For a fixed sample tape there are at most \(2^S\) possible sampled binary words,
so averaging over the \(2^k\) messages gives
\((2/3)2^k\le2^S\). The sample bound (255.3) yields (255.22).

To obtain (255.23), suppose first that
\(Q_k^3\le\eta\log P\), where \(\eta>0\) is sufficiently small. Taking
logarithms in (255.22) and using \(P\le k(\log k)^c\) gives the same
\(\log k/(2Q_k^2)\) surplus as in (255.13a), while the prefactor contributes
only \(O(Q_k+\log\log k)\). Choosing \(\eta=\eta(\rho,\Delta,c)\) small
produces a contradiction. Hence \(Q_k^3>\eta\log P\ge\eta\log k\), proving
the first bound. Since \(Q_k=O_{\Delta}(r_k\log(r_k+2))\), the second follows.
\(\square\)

The theorem is complementary to the fixed-tape/GGS route: the latter gives
\(\Omega(\log k/\log\log k)\) in the nonadaptive expansion parameter, whereas
(255.23) controls adaptive branch locality without paying an exponential
decision-tree factor. It still requires the common proof map, a fixed positive
target-relative radius, a fixed completeness gap, and the source-audited
parameterized DGL transfer.

## 2. Consequence for binary relaxed LDCs

Let \(C:\{0,1\}^k\to\{0,1\}^N\) be a binary relaxed LDC with constant positive decoding radius and locality \(\ell\). Every codeword is a valid robust input for the preceding theorem. Apply Theorem 1 and repeat the sample decoder \(O(\log(k+2))\) times, using the same sampled coordinates for every message coordinate. A union bound gives recovery of the entire message with probability at least \(2/3\) from

\[
  S=C_2\,2^Q Q\log(k+2)\,N^{1-1/(2Q^2)}
\tag{255.10}
\]

sampled bits, where \(Q\) is as in (255.1).

For a fixed sample tape \(R\), the global decoder is a deterministic map from at most \(2^S\) sampled binary strings to candidate messages, and hence can be correct on at most \(2^S\) messages. Averaging over \(R\), while every message is decoded with probability at least \(2/3\), gives

\[
  \frac23\,2^k\le 2^S.
\tag{255.11}
\]

Consequently,

\[
  N\ge
  \left(\frac{k-1}{C_2\,2^Q Q\log(k+2)}\right)^{1/(1-1/(2Q^2))}.
\tag{255.12}
\]

For a fixed finite proof alphabet \(\Sigma\), the same shared-sample argument
uses at most \(|\Sigma|^S\) sampled words rather than \(2^S\). Thus
\[
  \frac23\,2^k\le|\Sigma|^S,
  \qquad
  S\ge\frac{k-1}{\log_2|\Sigma|},
\]
and substituting the finite-alphabet form of (255.3) changes only the
constant factor in (255.12). The exponent and all threshold consequences
below are unchanged; this is the form used for the finite-alphabet RW/JK
corollary.

If \(Q^3=o(\log k)\) and \(N\le k^{O(1)}\), then the prefactor is \(k^{o(1/Q^2)}\), and therefore

\[
  N\ge k^{1+\Omega(1/Q^2)}
   = k^{1+\Omega(1/(\ell^2\log^2(\ell+2)))}.
\tag{255.13}
\]

This is a growing-query adaptive RLDC lower bound in the sublogarithmic window;
it retains the DGL \(Q^2\)-exponent rather than replacing the adaptive query
count by an exponentially larger nonadaptive decision-tree expansion. It is
still weaker than the fixed-query two-query exponential results at the smallest
locality values.

### Quantitative near-linear threshold

The comparison with decision-tree expansion is about retaining the \(Q^2\)
exponent; it is not a claim of a uniformly stronger lower bound in every
parameter regime.

Under the quantitative hypothesis (255.2'), the same information bound gives a
more concrete obstruction. There is a constant
\(\eta=\eta(\rho)>0\) such that no binary relaxed LDC with

\[
  N\le k\log^c(k+2)
\]

can satisfy \(Q^3\le\eta\log N\) for all sufficiently large \(k\). Hence every
near-linear family must leave this window, and in particular

\[
  Q=\Omega\bigl((\log k)^{1/3}\bigr).
\tag{255.13a}
\]

To see the quantitative step, write
\(B=\log(C_2 2^Q Q\log(k+2))\) in (255.12). Since
\(1/(1-1/(2Q^2))\ge1+1/(2Q^2)\), the lower bound contributes
\(\log k/(2Q^2)\) beyond \(\log k\), while \(B=O(Q+\log\log(k+2))\).
If \(Q\ge\log\log(k+2)\), (255.2') makes
\(\log N\le2\log k\) (under the near-linear upper bound, for large \(k\)),
so \(\log k/(2Q^2)\ge Q/(4\eta)\), which dominates \(B\) for sufficiently
small fixed \(\eta\). If \(Q<\log\log(k+2)\), then
\(\log k/(2Q^2)\gg\log\log(k+2)\), so the same conclusion holds.
This contradicts \(\log N\le\log k+c\log\log(k+2)\). Since an injective code
has \(N\ge k\), failure of (255.2') implies
\(Q^3>\eta\log N\ge\eta\log k\), proving (255.13a).

## 3. RW/JK shared-proof corollary

Suppose a common proof map \(\Pi:\{0,1\}^k\to\{0,1\}^P\) has, for every message coordinate and claimed bit, an adaptive proof verifier of depth \(r\), perfect completeness on the correct claim, and wrong-claim acceptance at most a fixed \(\beta<1\) throughout a positive target-relative radius. Reading the inline claim bit and running only the selected branch gives a relaxed decoder of locality \(r+1\). If \(\beta>1/3\), repeat the selected branch \(t_\beta\) times and accept only if every copy accepts, where \(\beta^{t_\beta}\le1/3\). Thus

\[
  \ell=t_\beta(r+1),
  \qquad
  Q=O\!\left(t_\beta(r+1)\log(t_\beta(r+1)+2)\right).
\tag{255.14}
\]

Whenever \(Q^3=o(\log P)\), (255.12) applies with \(N=P\). In particular, a near-linear common proof \(P\le k\log^c k\) is impossible throughout the window

\[
  \bigl(t_\beta(r+1)\log(t_\beta(r+1)+2)\bigr)^3=o(\log k),
\tag{255.15}
\]

unless the shared-proof construction leaves the relaxed-LDC model (for example through bottom outputs, target-dependent proof spaces, or a failure of common-word consistency).

In the quantitative form (255.2'), the same conclusion reads as a direct
address-scale threshold: a near-linear shared proof with this compiler must
have \(Q=\Omega((\log k)^{1/3})\) (with the constant depending only on the
fixed robustness/error parameters).

## 4. Independent adaptive fallback: what Goldreich's proof does and does not give

The DGL transfer above is the sharper route in the parameter window stated in
this note, but its source paper states the relaxed extension only for constant
query complexity.  Goldreich's adaptive proof gives an independent check on the
scale, with a different status.  In Section 4 of the source, the parameter is

\[
  c_q=3(10q+2)q=\Theta(q^2),
  \qquad
  p=n^{-1/(c_q q)}\log(k+2),
\tag{255.B1}
\]

and the proof requires both

\[
  p<n^{-1/[30(q+1)^3]}
  \quad\text{and}\quad
  p>n^{-1/(2c_q)}\log n.
\tag{255.B2}
\]

The first inequality is the binding one when q grows.  Since

\[
 \frac1{c_q q}-\frac1{30(q+1)^3}
   =\Theta\!\left(\frac1{(q+1)^4}\right),
\]

it follows that the displayed choice of p satisfies (255.B2) only in a
window such as

\[
  q^4\log\log(n+2)=o(\log(n+2)).
\tag{255.B3}
\]

Tracking the q-dependent factors in the source's pivot and recursion gives
the conditional sample estimate

\[
  S\le n\,p\,q^{O(1)}.
\tag{255.B4}
\]

The source suppresses this polynomial in q, because q is fixed there.
Consequently, a parameter-uniform reproof of Section 4 would imply

\[
  n\ge k^{1+\Omega(1/q^3)}
\tag{255.B5}
\]

throughout (255.B3), and hence the near-linear necessary condition

\[
  q=\Omega\!\left(\left(\frac{\log k}{\log\log k}\right)^{1/4}\right).
\tag{255.B6}
\]

This is an independent adaptive fallback, not an upgrade of the main result:
the DGL-derived transfer in Sections 1--3 has the stronger (1/3)-scale in its
own stated window.  Also, (255.B5)--(255.B6) are **not** attributed to
Goldreich's source theorem.  To promote them to a theorem one must expand the
source's union bounds over the q recursion levels, the O(q^2) pivot trials,
and all admissible auxiliary assignments, and verify that the failure
probability remains o(1/k) uniformly under (255.B3).  Until that line-by-line
parameter audit is completed, these equations are a fallback target and not a
claim about the published theorem.

The source is:

* O. Goldreich, *Lower Bounds for Local Search and Local Decoding*, ECCC
  TR23-064, Theorem 4.8 and Section 4:
  <https://eccc.weizmann.ac.il/report/2023/064/>.

## 5. Self-contained combinatorial interface

For completeness, this section isolates the source lemmas used by the
variable-\(Q\) transfer. It also fixes the quantifiers that are easy to hide
when the query count is treated as a constant.

Let \(\mathcal S\) be a multi-collection of \(Q\)-subsets of \([N]\), so repeated
sets are allowed. For \(1\le j\le Q\), put

\[
  h_Q(j):=N^{\max\{1,j-1\}/Q}.
\tag{255.A1}
\]

A \(j\)-daisy with kernel \(K\) is a subcollection whose sets have petals
\(S\setminus K\) of size \(j\), and such that, for every \(1\le r\le j\),
each petal contains at least \(r\) coordinates that occur in at most
\(h_Q(r)\) sets of the whole multi-collection. (Equivalently, the petal
intersection condition is tested against the global coordinate multiplicities,
not just against the subcollection.)

### Lemma 4.1 (daisy partition)

There are disjoint subcollections
\(\mathcal D_0,\ldots,\mathcal D_Q\) partitioning \(\mathcal S\), and kernels

\[
  \varnothing=K_Q\subseteq K_{Q-1}\subseteq\cdots\subseteq K_1=K_0,
\]

such that \(\mathcal D_j\) is an \(h_Q\)-daisy with petals of size \(j\), and

\[
  |K_j|\le Q|\mathcal S|\,N^{-\max\{1,j\}/Q}.
\tag{255.A2}
\]

*Proof.* Let \(d_u\) be the multiplicity of coordinate \(u\) in \(\mathcal S\).
For \(j<Q\), take \(K_j=\{u:d_u\ge h_Q(j+1)\}\), put into
\(\mathcal D_j\) the remaining sets with \(|S\setminus K_j|=j\), and delete
them before continuing; take \(K_Q=\varnothing\) and put all remaining sets in
\(\mathcal D_Q\). Since \(\sum_ud_u=Q|\mathcal S|\),

\[
  |K_j|h_Q(j+1)\le Q|\mathcal S|,
\]

which is (255.A2). The kernels are nested. For \(j\ge1\), a failure at
petal-size witness \(r=1\) is impossible: such a set has
\(|S\setminus K_0|=0\) and would already have been assigned to \(\mathcal D_0\).
If the daisy condition first failed at a larger \(r\), choose the smallest
such witness. The set \(L\) of points in the petal with multiplicity at most
\(h_Q(r)\) then has size at most \(r-1\). Minimality gives at least \(r-1\)
points of multiplicity at most \(h_Q(r-1)\), so \(|L|=r-1\); every other petal
point lies in \(K_{r-1}\). Consequently
\(|S\setminus K_{r-1}|=r-1\), so \(S\) would have been removed at level
\(r-1\), contradicting \(S\in\mathcal D_j\). This is the greedy proof of the
DGL partition lemma.
\(\square\)

### Lemma 4.2 (simple-daisy refinement)

If every petal of a daisy intersects at most \(t\) other petals, the daisy can
be partitioned into \(t+1\) simple daisies of equal size (up to rounding).

*Proof.* Colour the petal-intersection graph equitably with \(t+1\) colours by
Hajnal--Szemerédi; each colour class has pairwise disjoint petals.
\(\square\)

### Lemma 4.3 (volume lemma)

Let \(M\) be a relaxed local algorithm with error \(\sigma\). If \(x\) is in
the domain of its partial function and \(y\) is a \(\rho\)-robust point with
the opposite value, then every subcollection \(\mathcal A\) of query sets
satisfying

\[
  \left|\bigcup_{S\in\mathcal A}S\right|<\rho N
\]

has query-distribution mass at most \(2\sigma\).

*Proof.* If \(\mu_x(\mathcal A)>2\sigma\), form \(w\) by taking \(x\) on the
union and \(y\) elsewhere. Then \(w\) is within distance \(\rho\) of \(y\).
On the branches in \(\mathcal A\), the algorithm sees exactly the same answers
as on \(x\); after removing the at most \(\sigma\) mass of erroneous branches
on \(x\), it outputs the value of \(x\) on \(w\) with probability greater than
\(\sigma\). This contradicts robustness of \(y\).
\(\square\)

### Lemma 4.4 (uniform variable-\(Q\) sampling transfer)

Assume the normalized algorithm \(M'_N\) has error
\(\sigma=1/(8Q)\), support size

\[
  m_0=6N\log|\Sigma|/\sigma,
\]

and query-tree collections of \(Q\)-sets. Let

\[
  \gamma=48|\Sigma|^Q\log|\Sigma|,
  \qquad p=\gamma N^{-1/(2Q^2)}.
\tag{255.A3}
\]

If \(Q^3=o(\log N)\), the DGL sample construction, run separately for each
output value and using the same Bernoulli sample, has sample complexity
\(O(\gamma N^{1-1/(2Q^2)})\), preserves the valid set, and has constant error.

*Proof.* Apply Lemma 4.1 to the collection of branch sets. For every layer,
(255.A2) gives

\[
  |K_j|\le \gamma Q^2N^{1-\max\{1,j\}/Q}.
\tag{255.A4}
\]

The sample algorithm enumerates every assignment to \(K_j\), and accepts an
output-\(b\) branch when at least

\[
  \tau_j=\frac{m_0}{4Q}p^j
\tag{255.A5}
\]

compatible petals are sampled. The \(j=0\) layer is never enumerated. For
\(j=1\), put
\[
  \alpha=\frac{12\log|\Sigma|}{\rho\sigma}
\]
and discard every \(j=1\) tuple whose singleton petal belongs to a petal class
of size at least \(\alpha\). Lemma 4.3 bounds the discarded mass together
with the \(j=0\) layer by \(4\sigma\) on a non-robust input. The remaining mass
is at least \(1-5\sigma\ge1/2\), so some layer has at least \(m_0/(2Q)\) tuples.
Lemma 4.2 partitions that layer into simple daisies, and Chernoff gives the
\(9/10\) completeness bound.

For a robust input of the opposite value, each fixed kernel assignment has
wrong-output mass at most \(\sigma m_0\). Lemma 4.2 and the upper-tail Chernoff
bound give, for every assignment,

\[
  \Pr[\text{wrong threshold at layer }j]
  \le \frac{|\Sigma|^{-|K_j|}}{10Q}.
\tag{255.A6}
\]

The only nonconstant-\(Q\) comparisons are

\[
  \frac{N^{1-(j-1)/Q-j/(2Q^2)}}{Q^2N^{1-j/Q}}
  \ge \frac{N^{1/(2Q)}}{Q^2}
\tag{255.A7}
\]

for \(j>1\), and

\[
  \frac{\rho}{48\log|\Sigma|Q^3}
  N^{1/Q-1/(2Q^2)}\to\infty
\tag{255.A8}
\]

for the capped \(j=1\) layer; the cap gives the intersection degree
\(\beta_1\le\alpha\). For \(j>1\), the daisy intersection bound gives
\(\beta_j\le 2N^{(j-1)/Q}\), which is absorbed by (255.A7). Both estimates
follow from \(Q^3=o(\log N)\). A union bound over all
\(|\Sigma|^{|K_j|}\) assignments and \(Q\) layers costs at most \(1/10\).
The two output branches share the sample and are combined by outputting \(b\)
only when its branch crosses its threshold and the opposite branch does not;
this changes only the absolute error constant. \(\square\)

Lemmas 4.1--4.4 are the complete structural interface needed by Theorem 1;
the remaining source-specific details are only the explicit construction of the
branch collections and the bookkeeping of the sample cutoff.

## 5. What is and is not proved

The theorem is a coding-theoretic result derived from the DGL proof ingredients.
It does not claim that DGL's paper states (255.3) for growing \(Q\), and it does
not prove \(P\ne NP\). The RW/JK corollary is a direct conditional application
of the shared-proof compiler, not a closure of the actual RW construction. The
combinatorial dependence on \(Q\) is now explicit in Lemmas 4.1--4.4; a journal
version should still expand the routine threshold and sampling pseudocode
rather than relying on the source's constant-query presentation.

## Sources

* M. Dall'Agnol, T. Gur, and O. Lachish, *A Structural Theorem for Local Algorithms with Applications to Coding, Testing, and Privacy*, ECCC TR20-154, Sections 5--7: <https://eccc.weizmann.ac.il/report/2020/154/>.
* O. Goldreich, *On the Lower Bound on the Length of Relaxed Locally Decodable Codes*, 2024: <https://www.wisdom.weizmann.ac.il/~oded/COL3/rldc-lb.pdf>.
* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally Decodable Codes via Robust Daisies*: <https://arxiv.org/abs/2511.21659>.
