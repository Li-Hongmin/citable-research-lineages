> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Distributional policy to growing-alphabet Closure Gate (2026-08-17)

## Status

This note gives a source-safe distributional extension of C303. It allows
target-dependent policy distributions and does not require one policy to be
robust for every target. The averaged statement is still required to control
the worst coordinate and worst target-relative nearby proof before averaging.
Perfect correct-claim completeness is retained so that the source-safe RLDC
envelope applies without importing an unproved imperfect-completeness repair.

## Theorem

Let $M$ be uniform on $\{0,1\}^{K}$ and let

$$
  \Pi:\{0,1\}^{K}\longrightarrow \Sigma_K^{P}
$$

be a common proof map, with $A_K:=|\Sigma_K|\ge2$. For each target $m$, let
$S\mid M=m$ have a standard-Borel policy law $\mu_m$. Fix
$0<\rho<1$, $0\le\beta<1$, and an adaptive branch depth $r_K$. Assume:

1. every policy in every $\mu_m$ has perfect correct-claim completeness on
   $\Pi(m)$;
2. for a policy $s$, define the worst wrong-claim defect

$$
 \mathcal D_{\rm w}(m,s):=
 \max_{\substack{i,z:\\d_H(z,\Pi(m))\le\rho P}}
 \bigl(\operatorname{WrongAcc}_{m,i,s}(z)-\beta\bigr)_+;
$$

3. writing

$$
 \bar\delta_K=\mathbb E_{M,S}\mathcal D_{\rm w}(M,S),
 \qquad I_K=I(M;S),
 \qquad
 \tau_K=\bar\delta_K+
 \sqrt{\frac{\ln 2}{2}I_K},
$$

there is a fixed $\Delta\in(0,(1-\beta)/2)$ with
$\tau_K\le\Delta/2$ on infinitely many $K$;
4. the proof length satisfies
$N_K:=K+P\le K(\log(K+2))^c$ on the same infinite subsequence.

Put

$$
 Q_K=1+2\sum_{j=0}^{r_K-1}A_K^j,
 \qquad
 H_{K,A}=\log\log(K+2)+\log(Q_K+2)
       +\log(\log(A_K+2)+2).
$$

Then, for all sufficiently large $K$ in that subsequence,

$$
  \log A_K\ge K/8
  \qquad\text{or}\qquad
  Q_K H_{K,A}=\Omega_{\rho,\beta,\Delta,c}(\log K).
\tag{304.1}
$$

Consequently, if $\log A_K=o(K)$ and
$Q_KH_{K,A}=o(\log K)$, no such distributional policy family can have
$\tau_K\le\Delta/2$ infinitely often.

The result is semantic for an arbitrary policy law. If the marginal law
$\bar\mu_K=\mathcal L(S)$ has a uniform address-scale sampler, the same
argument is an executable RLDC lower-bound reduction.

## Proof

Let $\bar\mu_K=\mathbb E_m\mu_m$. Pinsker and the mutual-information identity
give

$$
 \mathbb E_{m}\mathbb E_{s\sim\bar\mu_K}\mathcal D_{\rm w}(m,s)
 \le
 \bar\delta_K+\sqrt{\frac{\ln 2}{2}I_K}
 =\tau_K.
$$

Markov's inequality therefore gives a target family
$\mathcal M_\Delta$ of size at least

$$
 |\mathcal M_\Delta|
 \ge \left(1-\frac{\tau_K}{\Delta}\right)2^K
 \ge \frac12\,2^K.
\tag{304.2}
$$

For every $m\in\mathcal M_\Delta$, the single target-independent mixture
$S\sim\bar\mu_K$ has perfect correct-claim completeness and wrong-claim
acceptance at most $\beta+\Delta$ on every coordinate and every
$\rho P$-near proof. The mixture is common across this entire subfamily.

Sauer--Shelah applied to $\mathcal M_\Delta$ gives a coordinate set $J$ of
dimension $d\ge(1/2-o(1))K$ that is shattered by $\mathcal M_\Delta$.
Choose one representative target for each pattern on $J$. Sampling
$S\sim\bar\mu_K$ and using the common policy branches gives a $d$-bit
common-proof interface with gap

$$
 \sigma=1-(\beta+\Delta)>0.
$$

Inline the $d$ message bits. The two adaptive $A_K$-ary branch trees have
nonadaptive union size $Q_K$. Distinct representative proof words have
distance greater than $\rho P$; the $A_K$-ary Singleton bound gives the
shrinking inline radius

$$
 \delta_{*,K}\ge
 \frac{\rho}{2\bigl(2(1-\rho)\log_2 A_K+1\bigr)}.
$$

Thus the source-safe envelope of note 300 applies with message dimension $d$,
alphabet $A_K+2$, and query count $Q_K$. Since $d=\Theta(K)$ and
$d+P\le d(\log(d+2))^{c'}$ for a constant $c'$, it yields either
$\log(A_K+2)\ge d/2$ or
$Q_KH_{d,A_K+2}=\Omega(\log d)$. The first alternative implies
$\log A_K\ge K/8$ for large $K$, and the second is equivalent up to constants
to the second alternative in (304.1). \(\square\)

## Exact boundary

The max over coordinates and nearby proofs is inside
$\mathcal D_{\rm w}$; averaging coordinate errors first is insufficient and
does not imply this theorem. Ordinary dPCP average/list soundness therefore
remains outside the result. The perfect-completeness assumption is explicit:
if correct acceptance also has a policy defect, one needs a separate
imperfect-completeness-to-RLDC conversion (for example the high-confidence
mixture conditions in note 274), and C304 should not be invoked automatically.
Zero target-relative radius and message-scale alphabets are also model exits.

## Sources

* Mutual-information mixture closure, note 273.
* Source-safe joint alphabet--locality envelope, note 300.
* Growing-alphabet coordinate-normalization Closure Gate, note 303.
