> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Connected-neighborhood transcript uniformization

## Scope

The transcript-information theorem in C332 produces a fixed valid word for one
transcript law. This note gives a separate, quantitative condition under which
those pointwise words must be the same throughout a proof neighborhood. The
condition is continuity of the visible transcript law along a connected graph of
nearby proofs. It is a conditional closure theorem, not an unconditional dPCP or
\(P\ne NP\) result.

## Theorem (uniformization along a transcript-connected neighborhood)

Let \(\mathcal Z\) be a finite set of proof states and let \(\mathcal G\) be a
connected graph on \(\mathcal Z\). Let \(J\) have a fixed distribution
\(\lambda\) on \([M]\), and for each \(z\in\mathcal Z\) let

\[
  T_z=(J,X_z,U_z)
\]

have law \(P_z\); \(U_z\) is arbitrary public local transcript data and
\(X_z\in\Gamma\cup\{\bot\}\). Let
\(\mathcal Y\subseteq\Gamma^M\) satisfy the coordinate separation condition below.
If \(|\mathcal Y|=1\), the conclusion is immediate; assume otherwise.

\[
  \Delta_\lambda:=
  \min_{y\ne y'\in\mathcal Y}
  \Pr_{J\sim\lambda}[y_J\ne y'_J]>0.
\tag{333.1}
\]

For every \(z\), suppose there is a random \(Y_z\in\mathcal Y\) such that

\[
  \Pr[X_z\ne (Y_z)_J]\le\varepsilon,
  \qquad I_2(Y_z;T_z)\le\iota.
\tag{333.2}
\]

Write

\[
  \alpha:=\varepsilon+\sqrt{\frac{\ln 2}{2}\,\iota}.
\tag{333.3}
\]

Assume that every edge \(zz'\) of \(\mathcal G\) satisfies

\[
  \lVert P_z-P_{z'}\rVert_{\mathrm{TV}}\le\tau.
\tag{333.4}
\]

If

\[
  2\alpha+\tau<\Delta_\lambda,
\tag{333.5}
\]

then there is a single \(y^\star\in\mathcal Y\) such that, for every
\(z\in\mathcal Z\),

\[
  \Pr_{T_z}[X_z\ne y^\star_J]\le\alpha.
\tag{333.6}
\]

## Proof

For \(z\in\mathcal Z\) and \(y\in\mathcal Y\), define

\[
  e_z(y):=\Pr_{T_z}[X_z\ne y_J].
\tag{333.7}
\]

C332, applied separately to \(P_z\), gives a word \(y_z\in\mathcal Y\) with

\[
  e_z(y_z)\le\alpha.
\tag{333.8}
\]

Consider an edge \(zz'\). Since the event in (333.7) is a transcript event,
(333.4) implies

\[
  e_{z'}(y_z)\le e_z(y_z)+\tau\le\alpha+\tau.
\tag{333.9}
\]

Also \(e_{z'}(y_{z'})\le\alpha\). If \(y_z\ne y_{z'}\), then on the coordinate
event \(y_z(J)\ne y_{z'}(J)\), at least one of the two comparisons with \(X_{z'}\)
must be wrong. Therefore

\[
  e_{z'}(y_z)+e_{z'}(y_{z'})
  \ge
  \Pr_{J\sim\lambda}[y_z(J)\ne y_{z'}(J)]
  \ge\Delta_\lambda.
\tag{333.10}
\]

Equations (333.9)--(333.10) contradict (333.5). Hence \(y_z=y_{z'}\) on every
edge. Connectivity of \(\mathcal G\) gives one common word \(y^\star\), and
(333.8) gives (333.6) for every vertex. \(\square\)

## Smoothness-to-connectivity corollary

The TV hypothesis can be obtained directly from adaptive query smoothness. Let
\(\mathcal Z\subseteq\Sigma^N\) be a Hamming-connected family, with edges joining
proofs that differ at one position. Run the same randomized adaptive decoder on two
adjacent proofs using the same random tape, and let the visible transcript include
the queried addresses and returned symbols. If the differing position \(p\) is queried
with probability at most \(\chi/N\) on every proof in \(\mathcal Z\), then

\[
  \lVert P_z-P_{z'}\rVert_{\mathrm{TV}}\le\frac{\chi}{N}.
\tag{333.12}
\]

Indeed, the two executions are identical until the first query to \(p\). If that
query never occurs, their complete transcripts coincide; the coupling therefore
has disagreement probability at most the hit probability of \(p\). If only a
per-step bound \(\chi/N\) is known for an adaptive decoder of depth at most \(r\),
the same argument and a union bound give \(\tau\le r\chi/N\).

Consequently, under the hypotheses of the theorem, a smooth Hamming-connected
near-proof family has one common word whenever

\[
  2\alpha+\frac{\chi}{N}<\Delta_\lambda
\quad\text{(or }\;
  2\alpha+\frac{r\chi}{N}<\Delta_\lambda
  \text{ under per-step smoothness).}
\tag{333.13}
\]

This is an actual address-scale closure test: no canonical selector or proof
recompilation is needed once the transcript hit bound is proved. It also exposes the
remaining RW escape precisely. If the pointwise information bound holds but (333.13)
fails, then either the decoder has a query peak of the required size, the transcript
information is too large, or the valid-word family has too little weighted separation.

## Information--query-peak dichotomy

The smoothness assumption can be removed from the conclusion by exposing its exact
failure mode. Under the hypotheses of the theorem, define

\[
  h^\star:=
  \max_{z\in\mathcal Z}\max_{p\in[N]}
  \Pr_{T_z}[\text{the decoder queries proof position }p].
\tag{333.14}
\]

Then at least one of the following holds:

1. there is one \(y^\star\in\mathcal Y\) with
   \(\Pr_{T_z}[X_z\ne y^\star_J]\le\alpha\) for every \(z\); or
2. \(h^\star\ge\Delta_\lambda-2\alpha\).

To prove this, assume that the first alternative fails. The pointwise words \(y_z\)
from (333.8) cannot then be equal on every connected component; along a connecting
path there is an edge \(zz'\) with \(y_z\ne y_{z'}\). Since \(z,z'\) differ at one
proof position \(p\), the same-randomness coupling used in (333.12) gives
\(\lVert P_z-P_{z'}\rVert_{\mathrm{TV}}\le
\Pr_{T_z}[\text{query }p]\le h^\star\). The contrapositive bound (333.11) gives
\(h^\star\ge\Delta_\lambda-2\alpha\).

Thus a low-information construction can avoid a common word only by creating a
constant query peak (or by leaving the fixed-coordinate/separated-word model).
If every query step is \(\chi/N\)-smooth and the decoder has depth \(r\), the second
alternative becomes \(r\chi/N\ge\Delta_\lambda-2\alpha\). A source-specific
patchability lemma can now convert that peak into wrong-output probability; without
such a lemma, the dichotomy is a structural closure gate rather than an RLDC
impossibility theorem.

## First-hit patchability corollary

The query-peak branch becomes an actual soundness obstruction once the source supplies
a one-position patching property. Fix a target word \(y^{\mathrm{tar}}\in\mathcal Y\),
and write

\[
  \operatorname{Err}_z(y^{\mathrm{tar}}):=
  \Pr_{T_z}[X_z\ne y^{\mathrm{tar}}_J].
\tag{333.15}
\]

Assume \(\operatorname{Err}_z(y^{\mathrm{tar}})\le\beta\) for every \(z\). Suppose
moreover that for every adjacent edge \(zz'\) whose pointwise C332 words differ,
with changed proof position \(p\), the same-random-tape coupling has a first-hit
event \(H_{z,p}\) satisfying

\[
  \Pr[H_{z,p}]=\Pr_{T_z}[\text{the decoder queries }p],
  \qquad
  \Pr[X_z\ne y^{\mathrm{tar}}_J\mid H_{z,p}]\ge\gamma.
\tag{333.16}
\]

Here \(\gamma>0\) is a source-specific constant; the condition includes that the
first hit produces a non-\(\bot\) wrong output with respect to the forcing target.
Then

\[
  \text{no common word on }\mathcal Z
  \quad\Longrightarrow\quad
  \beta\ge\gamma\bigl(\Delta_\lambda-2\alpha\bigr).
\tag{333.17}
\]

Indeed, the query-peak dichotomy supplies an edge and a direction for which
\(\Pr[H_{z,p}]\ge\Delta_\lambda-2\alpha\); multiplying by the conditional lower
bound in (333.16) gives (333.17). Thus, if
\(\beta<\gamma(\Delta_\lambda-2\alpha)\), the connected-neighborhood theorem forces
one common word, and a separate target-binding lemma can identify it with
\(y^{\mathrm{tar}}\). This is the exact source-specific upgrade needed to turn C333
from a structural gate into a wrong-output lower bound. Ordinary average/list or
distributional soundness does not imply (333.16); proving it for the RW/JK history is
the remaining substantive experiment.

## Dichotomy and interpretation

The contrapositive is the useful obstruction form. If no single valid word has
error at most \(\alpha\) on the entire connected neighborhood, then every graph
connecting the pointwise word regions contains an edge with

\[
  \lVert P_z-P_{z'}\rVert_{\mathrm{TV}}
  \ge \Delta_\lambda-2\alpha.
\tag{333.11}
\]

Thus the remaining escape is not an unspecified “proof can change the word”: it
requires a quantitatively visible discontinuity in the local transcript. If the
near-proof graph has several transcript-connected components, the theorem gives one
word per component; the component index is then an explicit cover-sheet/descriptor
variable. A succinct RW reconstruction must either compress that index and bind it
uniformly, or prove that the relevant neighborhood is transcript-connected.

The fixed coordinate marginal in (333.1) is essential. If the law of \(J\) changes
with \(z\), replace \(\tau\) by a bound on the total variation of the full transcript
laws and replace \(\Delta_\lambda\) by the corresponding pairwise disagreement mass
under the comparison law; without such a common sampling reference, no conclusion is
available. Likewise, ordinary pointwise mutual-information bounds do not imply
(333.4). C332 plus (333.4) is a sufficient interface, not a consequence of ordinary
average/list soundness.

## RW/JK consequence

For an RW candidate, take \(\mathcal Z\) to be the target-relative near-proof states,
\(T_z\) to contain all addresses, answers, coins, and inline claims used by the
coordinate verifier, and \(\mathcal Y\) to be the valid stitched-word family. If a
uniform sampler gives a common coordinate law, then a proof of (333.4) at the
address scale, together with the C332 information bound, directly supplies the
same-word hypothesis needed by the RLDC compiler. If the bound fails, (333.11)
charges a local transcript discontinuity before any hidden descriptor or cover-sheet
argument is invoked.

This does not establish the RW bound: current dPCP/udPCP definitions do not provide
transcript connectivity of their entire positive-radius neighborhoods. The theorem
therefore isolates a concrete Gate-I target: prove transcript connectivity for the
actual canonical RW history, or prove a lower bound of the form (333.11) and charge
that discontinuity to proof length, query locality, alphabet, or descriptor entropy.

## Relation to C332

C332 is the pointwise step \((333.2)\Rightarrow(333.8)\). The present theorem is
the missing uniformity step \((333.8)+(333.4)\Rightarrow(333.6)\). The two hypotheses
must not be conflated: low mutual information can hold separately at every proof
while the selected words differ between disconnected transcript components.
