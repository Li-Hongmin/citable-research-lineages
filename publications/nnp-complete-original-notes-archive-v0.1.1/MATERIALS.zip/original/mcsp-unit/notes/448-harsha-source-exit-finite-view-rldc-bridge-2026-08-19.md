> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha source-exit to finite-view RLDC bridge（2026-08-19）

## 本轮改变的判断

C447 把 published Harsha factorized/table branches 关闭后，剩余正向路线必须提出
新的 non-product global relation。这个 source-exit 仍有一个严格入口条件：
只要它在一个 common proof/address space 上，以有限可见 view（public coins、
observed response bits、proof symbols）实现所有坐标的 target-relative robustness，
C268 就会把它编译回 RLDC。

因此，新的 global relation 若想避开 Paper 05 的 RLDC/LDC barrier，必须明确支付
可见 transcript entropy、增大 proof alphabet/locality/radius、改变 soundness
量词，或离开 finite-view/common-proof semantics。它不能只把 Harsha 的
factorization 改名为“global coupling”。

## 定理 448.1（finite-view source-exit bridge）

令 \(\Pi:\{0,1\}^k\to\Sigma^P\) 是一个 common proof map，\(|\Sigma|=A\ge2\)。
对每个 message coordinate \(i\) 与 claim \(b\)，设一个可能自适应的
non-product global verifier \(V_{i,b}\)：

* 每次执行使用至多 \(r\) 个 public random bits；
* 查询至多 \(q\) 个 common-proof symbols；
* 观察至多 \(t\) 个 response/global-state bits；
* 对正确 claim 存在 honest policy 使完美接受；
* 对所有 response policies，任何 \(\rho P\)-近 proof 上的错误 claim
  接受率至多 \(\beta<1\)。

则存在一个有限字母表 weak RLDC，其 locality 至多

\[
 Q_{\mathrm{view}}
 =
 1+2q\,2^{r+t}A^q,
\tag{448.1}
\]

半径为只依赖 \(\rho,A\) 的正数，且 correct-vs-wrong gap 为
\(\sigma=1-\beta\)。若沿用 GGS 型任意有限字母 RLDC 下界，并且

\[
 P+k\le k(\log k)^c
\tag{448.2}
\]

在无穷多个长度成立，则

\[
 Q_{\mathrm{view}}
 =
 \Omega_{A,\rho,\sigma,c}
 \!\left(\frac{\log k}{\log\log k}\right).
\tag{448.3}
\]

等价地，任何此类 near-linear source-exit 必须满足

\[
 r+t+q\log_2 A+\log_2(q+2)
 \ge
 \log_2\log k-\log_2\log\log k-O_{A,\rho,\sigma,c}(1).
\tag{448.4}
\]

### 证明

固定 \((i,b)\)。一次执行中 verifier 的 future proof addresses 只依赖：
public random tape、至多 \(t\) 个 observed response bits 和至多 \(q\) 个
proof-symbol answers。因此所有 policies 的 reachable proof positions 的并集
大小至多

\[
 q\,2^{r+t}A^q.
\]

在 proof 前内联一个 message symbol，并对两个 claim 分支枚举全部 finite views；
按照所有-policy soundness，正确分支在目标 proof 上通过，而错误分支在
\(\rho\)-近邻域内不超过 \(\beta\)。这给出 locality (448.1) 的 nonadaptive
finite-alphabet RLDC。应用 GGS lower bound 得 (448.3)；取 (448.1) 的二进制对数
即得 (448.4)。这正是 C268 的 finite-view support/compiler 证明。证毕。

## 与 C447 的合并推论

对一个声称替代 Harsha \(P=p(q)\) 的 new global relation，若目标是
address-scale、same-proof、word-consistent 且仍有有限可见 view，则：

1. **visible-view branch：** 进入定理 448.1，near-linear proof 必须支付
   \(\Omega(\log\log k)\) 级可见 transcript，或承受 RLDC/LDC proof-length
   下界；
2. **static singleton branch：** 若没有 message family 而只有 published
   \(x_0\) singleton，则进入 C207 的 finite-ROM forcing-scale descriptor
   payment；
3. **true source-exit：** 若既不支付上述 view/descriptor 成本，又不满足
   factorized C446 接口，则必须使用 unbounded/continuous response、target-specific
   proof/address spaces、或新的 soundness quantifier。此时它已经离开
   Paper 05 的 common-proof finite-view model，必须单独提出新的可证伪 theorem。

因此 C447+C448 将剩余正向目标精确收束为：

\[
\boxed{\text{non-product global relation}
\;+\;\text{unbounded or non-common visible state}
\;+\;\text{new soundness mechanism}.}
\]

仅把 \(\Pi_{\mathrm{ZoS}}\)、sheet index 或 per-coordinate Merlin witness
重新命名，不满足这个 source-exit 条件。

## 证据边界

* 定理 448.1 是有限 view 模型中的 source-exit barrier，不是任意 global relation
  的不可能性定理。
* 它要求 family-level common proof map；published RW fixed-\(x_0\) singleton
  不直接触发 RLDC branch，需用 C207/C446 的 singleton accounting。
* 若 response alphabet、verifier time 或 hidden state 真正无界，必须把新增资源
  明确纳入 descriptor/communication model；不能把它当作免费 global coupling。
* 本定理不证明 \(P\ne NP\)，但把下一篇正向 PCP/coding theorem 的必要接口写成
  可证伪的量词和资源条件。

## 来源

* [note 268](268-finite-view-strategy-entropy-barrier-2026-08-17.md)。
* [note 447](447-harsha-rw-source-closure-trichotomy-2026-08-19.md)。
* [Paper 05](../../rw-jk-succinct-reconstruction/papers/05-shared-proof-coordinate-robustness-barriers/paper.md)。
