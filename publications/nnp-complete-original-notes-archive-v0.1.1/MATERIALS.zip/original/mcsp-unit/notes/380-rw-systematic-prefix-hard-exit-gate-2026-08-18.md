> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW systematic-prefix hard-exit gate for JK (2026-08-18)

## Decision

The stable-stage output length \(T_i\) is not the JK proof length, but the
systematic output prefix still gives a stronger branch statement. On any
length where the padded RW target has a circuit lower bound, **every JK easy
branch already yields a small circuit for the hard parent**. Consequently an
address-scale child width cannot be rescued by either the trivial easy branch
or the recursive easy branch: once the parent is hard, JK must return a
success outsider.

This is a source-specific hard-exit theorem. It does not bind that outsider
back to the parent; the remaining semantic-exit problem is exactly C372/C377.

## Source interface

Fix a stage \(i\), write

\[
  f_i(x_0)=B_i\,0^{T_i-2n_i},
  \qquad N_i:=2n_i,
  \qquad L_i:=|\Pi_{x_0}|,
  \qquad r'_i:=r_i\lceil\log(T_i+1)\rceil .
\]

Theorem 4.1 invokes JK on the binary PCP proof \(\Pi_{x_0}\), so the truth-table
length seen by Theorem 3.1 is \(L_i\). The RW completeness construction uses a
systematic Reed--Muller encoding: under the fixed binary serialization used by
the source proof, the first \(r'_i+T_i\) proof bits have the form

\[
  \Pi_{x_0}[r'_i+j]=f_i(x_0)_j,
  \qquad 1\le j\le T_i.
\tag{380.1}
\]

The first \(N_i\) of these positions are therefore the parent table \(B_i\).
Equation (380.1) is the only provenance fact used below; no auxiliary-PCP or
intermediate-gate block is assumed to have a semantic label.

## Hard-exit theorem

Let \(G_k\) be the AVOID circuit used in the call
\(\operatorname{Solve}_{f_i}(x_0,G_k)\). Suppose JK returns the easy branch.
By Theorem 3.1 there is a circuit \(C_\Pi\) for the entire binary word
\(\Pi_{x_0}\) with

\[
  |C_\Pi|\le c_0\,|G_k|\,\log(L_i+2)
\tag{380.2}
\]

for a universal constant \(c_0\), including the trivial \(L_i\le k\) case.
Hardwire \(r'_i\), add the input index \(j\), and evaluate \(C_\Pi\) at the
address \(r'_i+j\). The standard binary addition gadget has
\(O(\log(L_i+2))\) gates. By (380.1), this gives a circuit for \(B_i\) of size

\[
  \operatorname{CC}(B_i)
  \le
  c_1\bigl(|G_k|+1\bigr)\log(L_i+2).
\tag{380.3}
\]

Hence, on every length satisfying

\[
  \operatorname{CC}(B_i)>S_i,
\tag{380.4}
\]

the easy branch is impossible whenever

\[
  \bigl(|G_k|+1\bigr)\log(L_i+2)<S_i/c_1.
\tag{380.5}
\]

Since JK has only the easy and hard exits, (380.5) forces a non-range
\(2k\)-bit success outsider.

### Proof

Theorem 3.1's easy output circuit computes each bit of its truth-table input,
which here is \(\Pi_{x_0}\). The fixed prefix location in (380.1) turns this
word circuit into an evaluator for the output coordinate \(j\): compute the
binary address \(r'_i+j\), invoke \(C_\Pi\), and restrict to
\(1\le j\le N_i\). The address gadget costs \(O(\log L_i)\), and the resulting
circuit computes the whole \(N_i\)-bit table \(B_i\). This proves (380.3);
(380.4)--(380.5) then exclude the easy branch. \(\square\)

## Address-scale corollary

Assume the usual RW size bound \(|G_k|\le k^4\), the stable relation
\(T_i=n_{i+1}=n_i^C\), and the source upper bound
\(L_i\le\operatorname{poly}(T_i)\). Then
\(\log(L_i+2)=O(\log n_i)\). If

\[
  \operatorname{CC}(B_i)\ge c\,\frac{n_i}{\log(n_i+2)}
\tag{380.6}
\]

on the same length, every easy branch must satisfy

\[
  k^4\,O(\log n_i)
  \ge
  \Omega\!\left(\frac{n_i}{\log n_i}\right),
  \qquad\text{hence}\qquad
  k=\Omega\!\left(\frac{n_i^{1/4}}{\sqrt{\log(n_i+2)}}\right)
\tag{380.7}
\]

up to constants and the fixed exponent in the PCP length bound. In particular,
\(k=(\log n_i)^{O(1)}\) cannot land in either JK easy branch on such a hard
length. It must produce a success outsider.

This conclusion is stronger than the C379 length correction: it does not
require \(L_i\le k\), and therefore also excludes the \(L_i>k\) recursive-easy
case. It is independent of the \(P=NP\) determinization used in C371.

## Exact boundary

The source theorem does not make (380.1) representation-independent. It
fixes the systematic witness/output prefix needed by its own PCP verifier, but
the machine-to-circuit compiler, field encoding, and binary serialization must
be held fixed when identifying the raw proof positions. If a proposed
implementation changes those conventions, (380.1) must be reproved as an
implementation-specific output-projection lemma. Without that lemma the
argument stops at C379 and cannot be promoted to an unconditional hard-exit
claim.

The theorem also does not solve parent binding: a success outsider remains only
\(y\notin\operatorname{Range}(G_k)\). Combining (380.7) with a parent-binding
evaluator would be the next Closure step; C372, C377, and C378 show why that
evaluator cannot be treated as free.

## Sources

* Ren--Williams Theorem 3.1: easy branch circuit for the complete truth-table
  input; local extraction, approximately lines 498--548.
* Ren--Williams Theorem 3.5 and the proof of Theorem 4.1: systematic
  \((pfx,out)\) prefix and the call JK\((G,\Pi_x)\); approximately lines
  765--907.
* Ren--Williams Theorem 4.3: \(f_i=B_i0^{T_i-2n_i}\), stable
  \(T_i=n_{i+1}\), and \(|G_k|\le k^4\); approximately lines 1035--1090.
* Project boundary note [080](080-rw-pcp-block-provenance-is-not-a-black-box-invariant-2026-08-14.md),
  which records the fixed-serialization requirement.

This is a source-specific branch theorem, not a \(P\ne NP\) proof and not a
general dPCP/RLDC impossibility theorem.
