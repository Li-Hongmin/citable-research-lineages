> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Range-rich JK success 的 parent-fiber barrier（2026-08-19）

## 本轮改变的判断

C489/C503 分别用一个特殊 generator 构造了 JK success-output 的 parent
non-injection。源文 Theorem 3.1 实际只使用一个更一般的事实：在第一层，把
parent truth table 分成若干 \(2n\)-bit blocks；只要前面的 blocks 在
\(\operatorname{Range}(G)\) 中、最后一个 block 不在 range，算法就返回这个唯一
outsider。由此可以把 parent-fiber 障碍从 \(G(u)=0^nu\) 或 sentinel generator
推广到任意 **range-rich** generator。

这关闭了一个更强的黑箱正攻：对一大类允许的 RW AVOID generators，不能把
“JK 返回一个 hard outsider”解释成 parent 的 generic fingerprint。任何在整个
range-rich parent family 上有效的 binder 都必须支付 parent-scale descriptor。
剩余的 published RW singleton 缺口因此更窄：必须利用实际
\(f_i(x_0)\)/canonical PCP image 的 source-specific 结构，而不能只调用
Theorem 3.1 的 success transcript。

## 设置

令 \(G\) 是一个满足 \(|G|\ge n\) 的 AVOID generator
\[
  G:\{0,1\}^{n}\to\{0,1\}^{2n},\qquad
  R:=\operatorname{Range}(G),\qquad r:=|R|.
\]
取任意 \(y\notin R\)。令 \(K\ge2\)，
\[
  T:=n2^K,\qquad m:=2^{K-1}-1.
\]
对每个 \(\mathbf z=(z_1,\ldots,z_m)\in R^m\)，定义长度 \(T\) 的 parent
\[
  F_{\mathbf z}:=z_1\Vert z_2\Vert\cdots\Vert z_m\Vert y .
  \tag{510.1}
\]
因为 \(F_{\mathbf z}\) 恰好由 \(2^{K-1}\) 个 \(2n\)-bit blocks 组成，且最后一个
block 是唯一的非-range block，JK Theorem 3.1 在其 top stage \(K\) 上直接检测到
这个 \(y\)。

## 定理 510.1（range-rich JK parent-fiber theorem）

对每个 \(\mathbf z\in R^m\)，运行 Ren--Williams Theorem 3.1 的
Jeřábek--Korten algorithm on \((G,F_{\mathbf z})\)。则：

1. 算法在 top stage 的唯一 NO range-membership query 对应最后一个 block，并返回
   同一个 outsider \(y\)；因此即使把下列信息全部公开，
\[
  \tau^\star=(\mathrm{hard},K,\mathrm{position}=2^{K-1},y),
  \tag{510.2}
\]
   所有 \(F_{\mathbf z}\) 共享同一 success transcript。
2. parent fiber 的大小为
\[
  |\mathcal F_{G,K}(y)|=r^m,\qquad
  \log_2|\mathcal F_{G,K}(y)|=m\log_2 r .
  \tag{510.3}
\]
3. 设 \(D\) 是一个固定 transcript-only binder。它接收
   \((G,\tau^\star,\sigma,j)\)，其中 \(\sigma\in\{0,1\}^{d}\) 是允许依赖
   parent 的 descriptor，并要求对每个 \(\mathbf z\in R^m\) 存在
   \(\sigma_{\mathbf z}\) 使
\[
  D(G,\tau^\star,\sigma_{\mathbf z},j)
    =F_{\mathbf z}[j]\qquad(j\in[T]).
  \tag{510.4}
\]
   则
\[
  d\ge m\log_2 r .
  \tag{510.5}
\]
4. 若 \(r\ge 2^{\gamma n}\)（固定 \(\gamma>0\)），则
\[
  d\ge \gamma n(2^{K-1}-1)
    =\frac{\gamma}{2}T-\gamma n .
  \tag{510.6}
\]
   若 \(K\) 足够大，fiber 中还存在一个 parent 满足
\[
  \operatorname{CC}(F_{\mathbf z})
    =\Omega_\gamma\!\left(\frac{T}{\log(T+2)}\right).
  \tag{510.7}
\]

### 证明

Theorem 3.1 的证明从 \(y_K=F_{\mathbf z}\) 开始，并在 top stage 将其分成
\(2^{K-1}\) 个连续 \(2n\)-bit blocks。前 \(m\) 个 blocks 属于 \(R\)，所以相应
SAT range-membership queries 全部为 YES；最后一个 block 是 \(y\notin R\)，其
query 为 NO。源文规定遇到 NO 时立即返回对应的 block，因此每个 parent 都返回
同一个 \(y\)，得到 (510.2)。

不同的 \(\mathbf z\) 给出不同的 concatenated parent，故 (510.3) 成立。若
\(\sigma_{\mathbf z}=\sigma_{\mathbf z'}\) 而 \(\mathbf z\ne\mathbf z'\)，则
(510.4) 在任意两张 parent 不同的地址上要求同一个 evaluator 输出两个不同 bit，
矛盾。因此 \(\mathbf z\mapsto\sigma_{\mathbf z}\) 必须 injective，得到
\(2^d\ge r^m\) 与 (510.5)。

若 \(r\ge2^{\gamma n}\)，代入 (510.3) 即得 (510.6)。最后，长度 \(T\) 的
fan-in-two circuits 在 size \(s=\delta T/\log(T+2)\) 时总数至多
\(2^{C\delta T+o(T)}\)，其中 \(C\) 为通用计数常数。另一方面，(510.6) 给出
\(|\mathcal F_{G,K}(y)|\ge2^{\gamma T/2-O(n)}\)。取
\(\delta<\gamma/(4C)\)，充分大的 \(K\) 下低复杂度 circuits 的总数小于该
fiber 大小，故 fiber 中存在满足 (510.7) 的 parent。证毕。

## Hard outsider 的同时选择

对任意 \(G:\{0,1\}^n\to\{0,1\}^{2n}\)，\(|R|\le2^n\)。另一方面，size
\(\delta n/\log(n+2)\) 的 circuits 所能产生的 \(2n\)-bit tables 数量至多
\(2^{C'\delta n+o(n)}\)。取固定足够小的 \(\delta\)，这些 low-complexity tables
与 \(R\) 的并仍少于全部 \(2^{2n}\) 个 strings。因此可以同时选择
\[
  y\notin R,\qquad
  \operatorname{CC}(y)=\Omega(n/\log n).
  \tag{510.8}
\]
这说明 parent-fiber 障碍并不依赖一个容易的 child outsider；(510.7) 则进一步
给出 parent 本身的 forcing-scale hardness。

## 对 RW/JK Closure 的直接影响

1. **Generic success fingerprint 已被 range-rich 条件关闭。** 只要一个允许的
   AVOID family 满足 \(|\operatorname{Range}(G_n)|\ge2^{\gamma n}\)，任何对其
   全部 JK parents 有效的 transcript-only binder 都要支付
\(\Omega(T)\) descriptor；知道 stage、position 和 hard outsider 仍不够。
2. **C501/C503 是特例，而不是唯一机制。** C501 的 sentinel generator 具有
\(|\operatorname{Range}(G_n^\star)|\ge|\mathcal S_n|=2^{n}-2^{n-r_n}\)，所以
(510.6) 直接恢复 C503 的 \((1-o(1))T/2\) 量级；C489 的
\(G(u)=0^nu\) 则是 \(r=2^n\) 的另一特例。
3. **对 published singleton 的边界保持诚实。** Theorem 4.3 每个长度只固定一个
   \(f_i(x_0)\)/canonical PCP proof；C510 的 parent family 不自动包含这个固定
   proof。因此本定理关闭的是 generic、family-uniform 的 success attachment，
   不是 published singleton 的无条件不可能性。
4. 任何想继续 Gate I 的方案必须明确至少一项新信息：实际 canonical PCP image
   的 source-specific restriction、同一 parent 的额外 descriptor，或一个不从
   JK transcript 展开的 global relation。把这类信息不计价地称为“success output”
   不是 Closure。

## 证据边界

* (510.1)--(510.5) 只使用 Ren--Williams Theorem 3.1 的 top-stage block partition
  与“遇到 NO 立即返回对应 block”语义；不依赖 sentinel encoding。
* range-rich 条件 \(r\ge2^{\gamma n}\) 是显式假设；若某个 generator encoding 的
  range 过小，必须另行计数，不能静默套用 (510.6)。
* (510.7) 是 family-level existence，不把 fiber 中的 hard parent 识别成
  Theorem 4.3 的 fixed \(f_i(x_0)\)。
* 本结果不是 \(P\ne NP\) 证明，也不是一般 dPCP/RLDC impossibility；它是一个
  可迁移的 RW/JK success parent-binding barrier。

## 来源

* Ren--Williams, ECCC TR26-118 revision 1, Theorem 3.1 proof。
* [C489](489-jk-success-output-noninjection-parent-entropy-barrier-2026-08-19.md)。
* [C503](503-jk-black-box-transcript-binding-impossibility-2026-08-19.md)。
* [C501](501-sentinel-padded-truth-table-generator-canonical-gamma-closure-2026-08-19.md)。
