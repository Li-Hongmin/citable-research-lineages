> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Robust ROC frontier for imperfect transcript postprocessing (2026-08-19)

## Contribution

The perfect-completeness support theorem in note 252 and the accept/reject-only frontier in
note 250 are two boundary cases of one exact statement.  For a fixed coordinate and claim,
an arbitrary randomized postprocessor of the visible transcript is a fractional test
\(f(\tau)\in[0,1]\): it outputs the claim with probability \(f(\tau)\), and otherwise outputs
\(\bot\).  The optimal worst-case wrong-claim probability at required completeness \(\alpha\)
is therefore a robust Neyman--Pearson/ROC linear program over honest and target-relative
wrong transcript distributions.

This theorem is deliberately semantic: it permits unbounded postprocessing, arbitrary
visible randomness, adaptive query addresses, and no fresh branch resampling.  It identifies
the exact remaining escape in the imperfect-completeness transcript regime rather than
silently treating the accept bit as a sufficient statistic.

## Model

Let
\[
  \Pi:\{0,1\}^{k}\longrightarrow\Sigma^{P}
\]
be a common proof map.  For each coordinate \(i\) and claim \(b\in\{0,1\}\), let
\(V_{i,b}\) be a randomized adaptive verifier.  Its visible transcript space
\(\mathcal T_{i,b}\) includes every public random coin, query address, proof answer,
response, and final verifier bit that the postprocessor may inspect.  Write
\(\mu_{m,i,b,z}\) for the transcript distribution when \(V_{i,b}\) runs on proof \(z\).

For fixed \((i,b)\), define the honest and wrong families
\[
 \mathcal H_{i,b}:=\{\mu_{m,i,b,\Pi(m)}:m_i=b\},
 \qquad
 \mathcal W_{i,b}(\rho):=\{\mu_{m,i,b,z}:m_i\ne b,\ d_H(z,\Pi(m))\le\rho P\}.
\tag{266.1}
\]

For \(0\le\alpha\le1\), define the robust ROC value
\[
 \mathsf{ROC}_{i,b}(\alpha,\rho):=
 \inf_{0\le f\le1}
 \left\{
   \sup_{W\in\mathcal W_{i,b}(\rho)}\mathbb E_W[f]
   :
   \inf_{H\in\mathcal H_{i,b}}\mathbb E_H[f]\ge\alpha
 \right\}.
\tag{266.2}
\]
If the feasible set is empty, set the value to \(1\).  For finite transcript spaces this is
the finite linear program
\[
 \min t\quad\text{s.t.}\quad
 \sum_\tau H(\tau)f_\tau\ge\alpha\ (H\in\mathcal H_{i,b}),\quad
 \sum_\tau W(\tau)f_\tau\le t\ (W\in\mathcal W_{i,b}(\rho)),\quad
 0\le f_\tau\le1.
\tag{266.3}
\]

## Exact frontier theorem

### Theorem 266.1

Among all randomized postprocessors that see only the visible transcript of \(V_{i,b}\),
the minimum possible worst-case probability of outputting the claim \(b\), subject to
outputting \(b\) with probability at least \(\alpha\) on every honest target with
\(m_i=b\), is exactly \(\mathsf{ROC}_{i,b}(\alpha,\rho)\).

Consequently, a transcript-only postprocessor with completeness at least \(\alpha\) and
wrong-claim probability at most \(\beta\) exists if and only if
\[
  \mathsf{ROC}_{i,b}(\alpha,\rho)\le\beta.
\tag{266.4}
\]

### Proof

Given a postprocessor \(F\), discard every outcome on which it outputs \(1-b\), replacing
it by \(\bot\).  On honest targets this does not decrease the probability of outputting
\(b\), and on wrong targets it cannot increase the probability of outputting the wrong
claim \(b\).  Thus we may assume that \(F\) outputs only \(b\) or \(\bot\).  Let
\(f(\tau)=\Pr[F(\tau)=b]\), including the postprocessor's private randomness.  The honest
completeness constraints and wrong-claim objective are exactly the two constraints in
(266.2), so every such \(F\) has worst-case error at least the ROC value.

Conversely, any feasible \(f\) defines a postprocessor that outputs \(b\) with probability
\(f(\tau)\) and \(\bot\) otherwise.  It has the required honest completeness and its
worst-case wrong-claim probability is the objective in (266.2).  Taking the infimum proves
the claim.  In the finite case, compactness gives an optimizer; in the general measurable
case, every value above the infimum is attained up to an arbitrary \(\varepsilon>0\).
\(\square\)

## Two exact specializations

### Perfect completeness

At \(\alpha=1\), every feasible \(f\) must equal \(1\) almost surely under every honest
distribution.  Hence \(f\) is forced to be one on the union of the essential honest
supports, and
\[
 \mathsf{ROC}_{i,b}(1,\rho)
 =
 \sup_{W\in\mathcal W_{i,b}(\rho)}W(H_{i,b}),
\tag{266.5}
\]
which is exactly the support-overlap parameter and filter of note 252.

### Accept/reject-only postprocessing

If the visible transcript is reduced to the verifier's accept bit, then \(f\) has two
values \(s\) and \(t\), according as the bit is one or zero.  The constraints in (266.3)
become
\[
  \alpha s+(1-\alpha)t\ge\frac23,
  \qquad
  \beta s+(1-\beta)t\le\frac13,
\tag{266.6}
\]
and the feasibility region is exactly the three inequalities of Theorem 3.4J.  Thus the
memoryless frontier is the two-point projection of the full transcript ROC theorem, not a
separate ad hoc calculation.

## Coding consequence

Suppose the common proof image has the positive radius needed by the inline construction and
for every \((i,b)\) the ROC value satisfies
\[
  \mathsf{ROC}_{i,b}(2/3,\rho)\le1/3.
\tag{266.7}
\]
Choosing the corresponding tests and reading the inline bit gives a variable-query relaxed
local decoder with the same proof-query locality and no fresh branch resampling.  The
variable-query DGL transfer of note 255 therefore applies.  In particular, for fixed finite
alphabet and near-linear tagged length, the locality must obey the threshold in Theorem
3.4D''.  If (266.7) fails, Theorem 266.1 says that no transcript-only postprocessor can
enter this RLDC closure at the stated \((2/3,1/3)\) parameters; the remaining route must
change the proof space, radius, completeness target, or use a genuinely global/interactive
mechanism.

The theorem does not claim that ordinary dPCP list or average soundness bounds the ROC value.
Producing a uniform low-ROC transcript test is itself the missing coordinate-robustness
theorem.

## Minimax adversarial-mixture certificate

In the finite transcript/finite wrong-family model, the ROC value has the dual form
\[
 \mathsf{ROC}_{i,b}(\alpha,\rho)
 =
 \max_{\lambda\in\Delta(\mathcal W_{i,b}(\rho))}
   \min_{f\in\mathcal F_{i,b}(\alpha)}
      \mathbb E_{W\sim\lambda}\mathbb E_W[f],
\tag{266.8}
\]
where
\[
 \mathcal F_{i,b}(\alpha):=
 \{f:\mathcal T_{i,b}\to[0,1]:
   \mathbb E_H[f]\ge\alpha\text{ for every }H\in\mathcal H_{i,b}\}.
\tag{266.9}
\]
This is finite von Neumann minimax applied to the bilinear payoff
\((f,\lambda)\mapsto\mathbb E_{W\sim\lambda}\mathbb E_W[f]).  Consequently, if
\(\mathsf{ROC}_{i,b}(\alpha,\rho)>\beta\), there is one distribution \(\lambda\) over
target-relative wrong proofs/transcript laws such that **every** transcript test satisfying
honest completeness \(\alpha\) has average wrong output greater than \(\beta\) under
\(\lambda\).  The individual wrong proof that violates a given test may depend on the test;
the mixture is the uniform certificate that replaces this quantifier swap.

A useful sufficient form is domination.  If some honest law \(H_0\in\mathcal H_{i,b}\) and
some wrong-law mixture \(\overline W_\lambda\) satisfy
\[
 \overline W_\lambda(\tau)\ge\eta H_0(\tau)
 \quad\text{for every transcript }\tau,
\tag{266.10}
\]
then \(\mathsf{ROC}_{i,b}(\alpha,\rho)\ge\eta\alpha\), because every feasible test
has \(\mathbb E_{H_0}f\ge\alpha\).  Thus a proof-graph patchability or distributional
soundness argument that constructs (266.10) immediately rules out all transcript-only
postprocessors at any target \(\beta<\eta\alpha\).

### Corollary 266.2 (small-support ROC certificate)

If the transcript space \(\mathcal T_{i,b}\) is finite and
\(\mathsf{ROC}_{i,b}(\alpha,\rho)>\beta\), then there are at most
\(|\mathcal T_{i,b}|+1\) target-relative wrong proofs \(z_1,\ldots,z_s\), weights
\(\lambda_1,\ldots,\lambda_s\), and corresponding transcript laws \(W_j\), such that
\[
 \sum_{j=1}^{s}\lambda_j\mathbb E_{W_j}[f]>\beta
 \qquad\text{for every }f\in\mathcal F_{i,b}(\alpha),
 \quad s\le|\mathcal T_{i,b}|+1.
\tag{266.11}
\]

Indeed, the dual certificate only depends on the mixture distribution
\(\overline W_\lambda=\sum_j\lambda_jW_j\), a point in the convex hull of transcript-law
vectors in \(\mathbb R^{|\mathcal T_{i,b}|}\).  Carathéodory's theorem represents that
point using at most \(|\mathcal T_{i,b}|+1\) laws without changing the minimax payoff.
Thus a transcript model with at most \(L\) visible symbols over an alphabet of size \(B\)
has a certificate using at most \(B^L+1\) wrong proofs.

## Boundary

This is an exact characterization of transcript-only postprocessing.  It does not cover a
postprocessor that obtains additional proof queries after seeing its first output, a new
outer code that changes the proof map, or a Merlin strategy whose future responses are not
part of the fixed visible transcript model.  Those are explicit extensions rather than
hidden consequences of acceptance/rejection statistics.
