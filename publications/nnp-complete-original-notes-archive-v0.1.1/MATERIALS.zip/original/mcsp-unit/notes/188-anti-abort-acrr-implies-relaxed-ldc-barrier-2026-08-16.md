> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Robust-near-oracle ACRR 已给出 relaxed-LDC 超线性长度障碍（2026-08-16）

## 结论地位

这是一个条件性、但参数完整的 ACRR→RLDC barrier。note 193 随后把其中的
`constant-distance` 假设由正半径 target-relative soundness 自动推出；本 note 保留
原始阈值化与 DGL 参数接口，便于对照。关键条件不是不加区分的
“all-oracle 错误 soundness”（那会与同一 verifier 对相反消息位的完备性冲突），而是：
对每个目标 codeword 的一个正半径邻域，错误声明保持 robust soundness。只要 proof map
是 constant-distance code、正确声明在 codeword 上完备、错误声明在该邻域内不接受，
阈值化两个声明 verifier 就是一个具有 constant robustness 的 relaxed local algorithm；
Dall’Agnol--Gur--Lachish 的 Theorem 7.7 直接把它变成 sample-based relaxed local algorithm。

在 constant alphabet、constant radius、`q` 次自适应查询下，ACRR 因而直接继承
robust-local/sample-based 的超线性长度下界：

\[
  N\ge k^{\,1+1/O(q^2\log^2(q+2))}.
\tag{1}
\]

因此 `N=k\,polylog k` 的正向构造必须放弃正半径邻域内的 robust-near-oracle
soundness、constant alphabet/query 或统一 code-family 语义等条件之一；在该
target-relative 模型中，constant distance 已由 note 193 自动推出。单纯允许所有近 proof
输出 `\bot` 已不再是逃逸；若只在某个受限 prover/circuit family 上保证 soundness，
则不满足本 barrier 的 robust-near-oracle 量词。

## ACRR 接口

令

\[
  C:\{0,1\}^k\to\Sigma^N
\]

是 injective code/proof map，字母表 `|\Sigma|=O(1)`，相对距离大于 `2\delta`。
对每个 `i\in[k]` 和声明位 `b`，给定至多 `q` 次查询的（可自适应）verifier
`V_{i,b}`。写

\[
  p_{i,b}(z):=\Pr[V_{i,b}^{z}=1].
\]

假设存在常数 `\beta<1`，满足：

1. **完美完备性：** 对任意 `m`，`p_{i,m_i}(C(m))=1`；
2. **robust-near-oracle 错误 soundness：** 存在 `delta_0>0`，对任意 `m` 和任意
   `z` 满足 `dist(z,C(m))\le\delta_0`，有 `p_{i,1-m_i}(z)\le\beta`。

这里没有对近 proof 上正确声明的接受率作额外 lower bound；这正是 relaxed-LDC
转换比 ordinary-LDC 转换更强的地方。

## 额外 DH 假设下的 smoothness→distance 推论

constant distance 只有在另行加入 note 187 的 **disagreement-hitting (DH)** 假设时，
才可以由 branch-conditional smoothness 推出；它不是普通 target-relative ACRR 的自动
结论。若对每个诚实 transcript 分支都有参数 `\lambda` 的条件 smoothness，取任意
`m,m'` 和任意 `i` 满足 `m_i\ne m'_i`，令
`D=\{j:C(m)_j\ne C(m')_j\}`。DH 给出

\[
  1-\beta
  \le \Pr[Q^{C(m)}_{i,m_i}\cap D\ne\varnothing]
  \le q\lambda\frac{|D|}{N}.
\]

所以

\[
  \operatorname{dist}(C(m),C(m'))
  \ge \frac{1-\beta}{q\lambda}.\tag{2}
\]

对任意不同消息总能选到一个这样的 `i`；故在显式 DH 下，当 `q,\lambda` 为常数时，
code family 具有 constant distance，并落入本 note 的 relaxed-LDC barrier。若 `q\lambda`
随参数增长，式 (2) 给出相应的距离—查询 trade-off，不能静默当作常数距离。

若没有 DH，note 193 仍可由 target-relative 正半径 soundness 单独推出距离；但若只
有 codeword 点 soundness，则本 note 的 constant-distance 仍需独立假设。note 192
说明不能用错误声明的全 oracle soundness 来补回 DH。

## 阈值编译为 relaxed decoder

取阈值

\[
  \theta:=\frac{1+\beta}{2},
  \qquad
  \Delta:=\theta-\beta=\frac{1-\beta}{2}>0.
\]

给定坐标 `i` 和 oracle `z`，对 `V_{i,0}`、`V_{i,1}` 各独立运行 `R` 次，令
`\widehat p_b` 为接受频率。若恰有一个 `\widehat p_b\ge\theta`，输出该 `b`；否则
输出 `\bot`。取

\[
  R=\Theta\!\left(\Delta^{-2}\right)
\]

并用 Hoeffding 界把每个频率估计误差压到 `\varepsilon_0<1/20`。

### 完备性

若 `z=C(m)`，正确分支的期望为 `1`，错误分支的期望至多 `\beta`。故 decoder 输出
`m_i` 的概率至少 `1-2\varepsilon_0>2/3`。

### 近 proof 上不输出错误位

若 `dist(z,C(m))\le\min\{\delta,\delta_0\}`，错误分支的期望仍至多 `\beta`。因此以概率至少
`1-\varepsilon_0`，错误分支不会越过阈值；decoder 只能输出 `m_i` 或 `\bot`。这对
所有 `i` 成立，正是 relaxed-LDC 的 relaxed-decoding 条件。

得到的 relaxed LDC 查询数为 `q'=2Rq=O(q(1-\beta)^{-2})`，解码半径为 `\delta`。
若按文献的显式 relaxed-LDC 定义列出 success-rate，则可使用其 Definition 7.3 /
Remark 7.4（引用 BGH+04）从完备性和 relaxed-decoding 条件补上；本 barrier 的长度
下界也可以直接走 Theorem 7.7 的 relaxed-local 版本，不依赖把这一步重新证明。

注意这里允许 verifier 自适应；阈值编译只使用接受概率。若目标模型要求 perfect
decoder completeness 而非通常的 bounded-error completeness，需要另行做 one-sided
放大；本定理采用 relaxed-LDC 文献的 bounded-error convention。

## 接入 robust-local/sample-based 下界

Dall’Agnol--Gur--Lachish 的 Theorem 7.7 把具有常数 robustness 的自适应 relaxed local
algorithm 转成 sample-based relaxed local algorithm，样本复杂度为

\[
  S=N^{1-1/O(q'^2\log^2(q'+2))}.
\tag{3}
\]

对 `k` 个坐标重复并复用同一批样本（将单坐标错误压到 `1/(3k)`），在原 codeword
上以常数概率同时恢复全部 `k` 个消息位。样本索引独立于消息，constant alphabet 的
样本内容至多携带 `O(S)` 比特信息；故必须有 `k\le O(S)`。整理即得式 (1)。这正是
该文对 relaxed LDC 的 Corollary 7.9 证明机制，现将其应用到 ACRR。

文献以二进制码表述；对固定常数 alphabet，可用固定长度 binary block encoding，令
`N`、距离和查询数只发生常数因子变化，因此同一指数下界仍适用。

## 对主攻路线的精确裁决

这条 barrier 删除了一个原先看似可行的逃逸：单纯允许近 proof 输出 `\bot`。只要
codeword 完备性和 robust-near-oracle 错误 soundness 仍在，阈值 decoder 已满足
relaxed-LDC 的两条核心条件，标准 implication 会补上 success-rate。因此正向构造若要
保持近线性，必须破坏以下至少一项：正半径邻域内的 robust soundness、constant
alphabet/query，或 relaxed-LDC 所需的统一 codeword 语义；不能把“另行放弃
constant distance”当作 target-relative 模型中的独立逃逸。

## 证据边界

* 阈值编译与 smoothness→distance 推导是本 note 的直接结果；Dall’Agnol--Gur--Lachish 的 sample-based 结构定理、
  Corollary 7.9 的长度下界及其对 success-rate 的标准 implication 是外部已知结果，
  本 note 不把它们冒称为新证明。
* 在本 note 的原始参数表述中写有 constant-distance injective code/proof map；note 193
  证明该条件可由 target-relative 正半径 soundness 推出。若只在 codeword 点、某个受限
  prover/circuit family 或 syntax-valid proof 上成立，则阈值 decoder 的 relaxed soundness
  不成立。
* 若 alphabet、query 或 radius 随参数增长，式 (1) 的常数依赖必须重新记账。

## 来源

- [Dall’Agnol--Gur--Lachish, TR20-154](https://eccc.weizmann.ac.il/report/2020/154/download)
- [GM--Minzer--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/html/2512.12960)
- [note 187: adaptive query-stability and disagreement-hitting](187-adaptive-query-stability-implies-ldc-2026-08-16.md)
- [note 192: family-level quantifier audit](192-family-quantifier-audit-for-acrr-barriers-2026-08-16.md)
