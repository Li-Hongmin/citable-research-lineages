> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha constraint-extension 的 source-interface barrier（2026-08-19）

## 本轮改变的判断

C439 把 Harsha 的 auxiliary-to-systematic 方向压成了三个 evaluator 条件，但其中
“\(\widehat C\) 的 address-scale 求值”并不是 RW 已发表定理中的现成接口。直接核对
Ren--Williams Lemma 3.2、Theorem 3.5 与 Harsha §5.4.1 后，剩余缺口可以精确写成：

1. 由 gate relation \(C'\) 构造的低度延拓 \(\widehat C\)，在 generic field point 上的加权
   gate-sum 是否有 poly\((\log t)\) evaluator；
2. 对需要恢复的 systematic 坐标，能否按地址生成一个确定的 gate-incidence pair。

RW 源文只给出 \(C_x\) 的 deterministic poly\((t)\)-time construction，以及 Harsha
proof 的正向 polynomial construction；它没有给出这两个 address-scale 接口。因此
C439 目前是一个正向条件定理，不是 published RW 的 closure。

## Harsha 的实际约束多项式

Harsha §5.4.1 先把大小为 \(n\) 的 circuit \(C\) 编成

\[
 C' : H^{3m+3}\longrightarrow\{0,1\},
\]

其中 \(C'(i_1,i_2,i_3,b_1,b_2,b_3)=1\) 当且仅当三个变量索引对应某个 gate 的输入/输出，
且 \((b_1,b_2,b_3)\) 是该 gate 的非法配置。随后取逐变量次数至多 \(|H|\) 的唯一低度
延拓 \(\widehat C\)，使

\[
 \widehat C|_{H^{3m+3}}=C'.
\]

若 \(\ell_h\) 是 \(H\) 上的 Lagrange 基，则对任意

\[
 \xi=(\xi_1,\ldots,\xi_{3m+3})\in F^{3m+3}
\]

有精确公式

\[
 \widehat C(\xi)=
 \sum_{a\in H^{3m+3}} C'(a)
 \prod_{j=1}^{3m+3}\ell_{a_j}(\xi_j).
\tag{440.1}
\]

这正是 C439 归一化反演所需要的 generic-point denominator；只知道
\(\widehat C\) 在 \(H^{3m+3}\) 上的值并不足以运行 C439，因为其 Schwartz--Zippel 搜索需要
在整个 \(F\) 中寻找两个非零 \(y\)-slice。

## 命题 440.1（object-scale weighted gate-sum boundary）

在只以 gate-list oracle 访问 \(C'\) 的黑箱模型中，精确计算 (440.1) 一般需要
\(\Omega(|C|)\) 次 gate-list probes；因此 Harsha 的 source construction 本身不能推出
poly\((\log |C|)\) 的 \(\widehat C\) evaluator。

### 证明

取 \(\xi\) 各坐标均不在 \(H\) 中，使每个 Lagrange 权重

\[
 w_a(\xi):=\prod_j\ell_{a_j}(\xi_j)
\]

非零。考虑由互不相同的合法 gate tuples \(a\) 构成的 gate-list family。对任意未被
算法询问的 tuple \(a\)，改变该 tuple 是否出现在 gate list 中，会把右端改变
\(w_a(\xi)\ne0\)，而不改变算法已经看到的回答。故少于全部 active tuples 的查询不能
区分两个输出不同的实例。一个大小为 \(|C|\) 的 gate list 可以含 \(\Theta(|C|)\) 个这样的
独立 tuple，得到 \(\Omega(|C|)\) 的 probe 下界。证毕。

这里的下界是明确的 black-box/source-representation 结论：如果某个特殊的 RW
machine 使 gate relation 具有额外的算术聚合结构，可以另行证明快速 weighted sum，
但那是新的 source lemma，不是 Lemma 3.2 的 object-scale construction 的形式后果。

## 命题 440.2（output incidence 仍是额外的 layout lemma）

Lemma 3.2 的 \(C_x\) 语义确实检查 computation history 的 `out` 字段；Harsha 的
\(C'\) 也把 output-gate 的非法配置写入 gate relation。因此可以断言“存在某个涉及
该 output 变量的 gate tuple”。但是要满足 C439 的条件，还必须在固定 serialization
下给出一个按地址运行的

\[
 \operatorname{Inc}(u)=(v_u,w_u)
\]

使 \(\widehat C(u,v_u,w_u,\cdot,\cdot,\cdot)\) 非零，并把 field coordinate \(u\) 正确映射到
history/output 变量。RW Theorem 3.5 只说明 systematic prefix 含有 history/output
字段，没有规定 gate enumeration、变量到 \(H^m\) 的坐标编码、output-gate 的固定槽位，
也没有给出该 incidence map 的运行时间。对一般 witness 坐标，这个 map 还可能需要
扫描 \(C_x\) 的 gate list；对 output 坐标，即使它可由一个新规定的 reserved gate
layout 得到，也必须作为新的 source theorem 声明和证明。

## C439 的 source-level 精确终点

结合 C439，任何 actual RW positive closure 必须显式提供以下三项接口：

* \(P=p(q)\) 的同一 binary/ECC serialization 上的 address-scale field-symbol evaluator；
* generic field points 上的 \(\widehat C\) evaluator，而不是只在 \(H^{3m+3}\) 上查询 gate relation；
* 至少对所需 output/history 坐标的 address-scale incidence/layout map。

若三者成立，C439 直接把 \(P\) 段接回 systematic output；若任一项只需扫描完整
\(C_x\) 或完整 gate relation，则其代价是 object-scale，不能导出 \(P/\mathrm{poly}\)
的最终闭合。若 proposed proof 只暴露 Π\(_{\rm ZoS}\)、ECC image，或使用不带固定
layout 的 per-address existential proof，则它已经离开 C439 的 factorized interface，
必须另证 same-proof、smartness 与 output attachment。

## 与 source-uniform barrier 的关系

本 note 不把“没有 source lemma”冒称为不可能性。对所有 source inputs \(x\) 构造统一
的 canonical-proof address evaluator 已被 C431（note 432）单独压到 succinct-circuit-value
barrier；因此实际正攻应固定 published \(x_0\) context，或明确声明一个严格受限的
source subclass。对该 singleton，C440 只说明 Harsha algebraic branch 尚未闭合，
不提供 \(P\ne NP\) 结论。

## 下一项最便宜的区分性检查

固定 RW 的 deterministic recompilation 与 canonical serialization 后，直接检查两件事：

1. `out`/prefix 变量是否有一个 reserved gate layout，使 \(\operatorname{Inc}(u)\) 可在
   poly\((\log t)\) 时间生成；
2. 该 layout 的 \(C'\) 是否有可证明的快速 weighted gate-sum，从而在 generic \(F\)
   points 评价 \(\widehat C\)。

若第二项不能证明，C439 不能升级为 actual closure；若能证明，则只剩 P 段 field-symbol
random access 与同一 proof serialization 的核验。

## 证据边界

* RW Lemma 3.2 只保证 \(C_x\) 可在 deterministic poly\((t(n))\) time given \(x\)
  构造；Theorem 3.5 只保证 systematic \(\widetilde w\) 前缀与 auxiliary \(P,\Pi_{\rm ZoS}\)
  的正向 PCP proof。
* Harsha Proposition 5.4.1、式 (5.6)--(5.8) 给出 \(C'\)、\(\widehat C\) 与 \(p(q)\) 的
  factorization；没有给出 \(\widehat C\) 的 random-access evaluation algorithm。
* 命题 440.1 只在 gate-list black-box/source-representation 模型中成立；它不排除
  一个针对特定 RW machine 的新算术聚合定理。
* 本 note 不证明一般 dPCP/RLDC impossibility，也不证明 \(P\ne NP\)。

## 来源

* Ren--Williams TR26-118 revision 1, Lemma 3.2 and Theorem 3.5；本地抽取：
  `units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md`。
* Prahladh Harsha, *Robust PCPs of Proximity and Shorter PCPs*, §5.4.1,
  Proposition 5.4.1, equations (5.6)--(5.8)；本地抽取：`[unbundled local reference]`。
* [note 432](432-source-uniform-actual-rw-accessor-barrier-2026-08-19.md)。
* [note 439](439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md)。
