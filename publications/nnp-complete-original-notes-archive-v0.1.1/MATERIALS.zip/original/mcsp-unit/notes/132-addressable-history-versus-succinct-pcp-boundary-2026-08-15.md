> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 地址可访问 history 与 succinct PCP 的边界（2026-08-15）

## 结论先行

本项目所需的对象是一个统一的随机访问电路

\[
A_n(x,j,\ell)=C_n(x)[2qj+\ell],
\tag{1}
\]

它只承诺从输入 \(x\)、block 地址 \(j\) 和位地址 \(\ell\) 生成一个固定 history
码字的坐标。这个承诺**不等于** succinct PCP：succinct PCP 还需要一个完整的短 proof、
验证器、完备性和声性，以及对所有验证查询位置的可解释编码。因而不能把 universal-LTC、
地址可访问码字或单个 RW block accessor 直接称为 succinct PCP。

真正安全的升级命题是条件性的：若在 (1) 之外还能给出长度为 \(\operatorname{poly}(n)\)
的 proof、一个 \(\operatorname{poly}(n)\)-时间 verifier，并且 verifier 的每个查询位置都能由
(1) 或同阶的统一 accessor 生成，则得到一个标准 succinct-PCP 候选。此时必须面对
Fortnow--Santhanam 的障碍；这不是当前 accessor 命题本身的下界。

## 文献直接支持的事实

1. Fortnow--Santhanam 的原始结果（ECCC TR07-096；论文版本 2008）证明：SAT 若有
   只按变量数多项式增长的 instance compression，除非
   \(\mathsf{NP}\subseteq\mathsf{coNP/poly}\)（该包含本身会导致多项式层级坍缩）；同一摘要
   明确给出 SAT 不存在只按变量数多项式长度的 succinct PCP，除非同一条件成立。见
   [ECCC TR07-096](https://eccc.weizmann.ac.il/report/2007/096/)。

2. Bronfman--Rothblum（ECCC TR21-084）把该边界与密码学区分开：标准 succinct PCP 在通常
   复杂性假设下被认为不可得；在次指数 LWE 假设下可以构造的是 succinct **PCA**，即只对
   高效生成的假 proof 保证 soundness，而不是信息论意义的 PCP。见
   [ECCC TR21-084](https://eccc.weizmann.ac.il/report/2021/084/)。

3. Goldreich--Gur 的 [universal-LTC](https://www.wisdom.weizmann.ac.il/~oded/VO/ultc.pdf)
   给出针对 \(M\) 个小电路的统一可测试编码，长度为
   \(\widetilde O(Ms)\)，但其定理是 local testing/encoding 结果，不提供一个从短消息和任意位置
   直接生成完整码字坐标的 \(A_n\)。因此 universal-LTC 不能替代本项目的 history-indexed
   block accessor；它至多是候选冗余结构的文献锚点。

## 对当前 RW 接口的精确含义

### 不是自动的 succinct PCP

若只知道 \(A_n\) 对一个固定 \(C_n(x)\) 有效，则可把 JK 的实际 block 逐位生成，但还没有：

- proof 长度是 \(\operatorname{poly}(n)\) 而非 \(\operatorname{poly}(t)\)；
- verifier 对所有查询的统一随机访问实现；
- soundness 对任意错误 proof 的保证；
- 与 Ren--Williams 编码约定一致的 canonical prover。

因此 note 131 的 tree-compatible decoder 是**充分的接口假设**，不是已知 succinct-PCP
构造，也不触发 Fortnow--Santhanam 定理。

### 一旦补齐 verifier，就会撞上已知压缩边界

若某个具体 RW/PCP implementation 同时满足：

\[
\text{proof length }p(n)=\operatorname{poly}(n),
\qquad
\text{all query bits in }\operatorname{poly}(n)\text{ time},
\tag{2}
\]

并且对 SAT 的变量数 \(n\) 保持标准 PCP 完备性与声性，那么它就是 succinct-PCP 候选，
而非仅是 decoder。由 Fortnow--Santhanam，(2) 的成功将需要面对

\[
\mathsf{NP}\subseteq\mathsf{coNP/poly}
\quad\text{（从而导致 PH collapse）},
\tag{3}
\]

不能把 (3) 改写成已证明 \(P\ne NP\)。在 LWE 假设下可转向 PCA，但那改变了 soundness 模型，不能直接用于 RW 的
信息论 completeness/soundness。

## 与 note 131 的互补障碍

note 131 已证明 systematic 坐标若满足

\[
C_n(x)[2qj+\ell]=f_n(x),
\]

则地址 accessor 立即给出

\[
\operatorname{CC}(f_n)\le S_A+O(q+\log L).
\]

因此在 forcing 输出 \(f_n\) 被选为高复杂度函数时，任何 poly\((n)\)-size accessor 都不能
访问这样的 systematic 坐标。这一障碍是**生成复杂度**；Fortnow--Santhanam 的障碍则是
**完整 succinct proof 的压缩/验证复杂度**。二者方向不同，不能互相替代：

\[
\boxed{
\text{addressable history}\;\not\Rightarrow\;\text{succinct PCP},
\qquad
\text{succinct PCP upgrade}\;\Rightarrow\;\text{known compression barrier}.
}
\]

## 研究决策

1. 不把 universal-LTC 或 succinct-PCP 文献当作 \(A_n\) 的构造；先要求一个固定的
   compiler、field/RM 坐标、PCP prover 和 query serializer。
2. 当前最窄的可证接口仍是 note 131 的 tree-compatible block accessor；若要使用
   succinct-PCP 文献，必须先显式证明从该 accessor 到 (2) 的 upgrade lemma。
3. 在没有 upgrade lemma 以前，文献只提供“若完整压缩成功则会触发条件性复杂性后果”的
   边界，不提供 \(P\ne NP\) 或一般 decoder lower bound。

本 note 的文献检索日期为 2026-08-15；Goldreich--Gur universal-LTC 记录保存在
ResearchLibrary，Fortnow--Santhanam 与 Bronfman--Rothblum 的 ECCC 记录见上述链接。
