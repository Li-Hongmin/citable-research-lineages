> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 静态 fractional-coloring 的精确线性上界（2026-08-13）

## 定理

令 \(C\) 为有限 cell 宇宙，\(|C|=m\)，\(\mathcal L\) 为合法 affine-parity 子矩形族。假设存在一个叶分布 \(\mathscr D\) 满足

\[
\Pr_{R\sim\mathscr D}[c\in R]=q>0
\qquad\forall c\in C.
\tag{1}
\]

则任意静态 cell 权重 \(\phi:C\to\mathbb R\)（无须预先假设非负）若满足

\[
\sum_{c\in R}\phi_c\le1
\qquad\forall R\in\mathcal L,
\tag{2}
\]

必有

\[
\boxed{\sum_{c\in C}\phi_c\le q^{-1}.}
\tag{3}
\]

## 证明

对 (2) 按 \(R\sim\mathscr D\) 取期望：

\[
1\ge \mathbb E_R\sum_{c\in R}\phi_c
=\sum_{c\in C}\phi_c\,\Pr[c\in R]
=q\sum_{c\in C}\phi_c.
\]

除以 \(q\) 即得 (3)。\(\square\)

## 当前 affine-parity 归一化

随机 affine 最大叶给定 cell 的保留概率为 \(1/4\)（一个 row 方程和一个 column 方程）。若再在保留的行、列中独立以 \(1/2\) 进行合法 thinning，则

\[
q=\frac14\cdot\frac12\cdot\frac12=\frac1{16},
\]

从而

\[
\sum_c\phi_c\le16.
\tag{4}
\]

这不是渐近 \(O(m)\) 估计，而是与 \(m=|C|\) 无关的常数上界。因而任何只把 cell 当作静态颜色、再以每个 affine 叶容量 \(\le1\) 约束的 fractional-coloring 方案，都不可能达到 \(m^{1+\epsilon}\) 或哪怕线性增长。

## 适用边界

要逃逸 (3)，必须放弃至少一个条件：

1. 使用递归状态 \(K(R)\)，使叶约束变成 \(\sum_{c\in R}\phi_c+K(R)\le1\)；
2. 让叶分布的 cell inclusion 概率高度不均匀（但随后需要控制最小质量，不能仅靠均匀抽样）；
3. 让权重依赖递归节点或全局语义，而非一组固定 cell 颜色。

即便引入 QA 状态，前述 note 047、049 说明 matroid-rank 和范数化 additive 状态仍受同一均匀平均障碍。

