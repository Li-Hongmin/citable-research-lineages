> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 同一中心的三 cell pair-cover：联合 thinning 闭合（2026-08-13）

## 命题

取同一 row 的三个不同 cell

\[
c_i=(x_0,y_i),\qquad i=0,1,2,
\]

其中 \(y_0,y_1,y_2\) 两两不同。令 \(E_{\ge2}\) 为 affine 叶加独立
\(1/2\) 行、列 thinning 后至少两个 \(c_i\) 被完整保留的事件。则

\[
\boxed{\Pr(E_{\ge2})\le \frac3{64}.}
\tag{1}
\]

同一 column 的结论由交换 row/column 得到。

## 证明

令

\[
q_0=(x_0,1),\qquad p_i=(y_i,1).
\]

任意两个 \(p_i,p_j\) 与 \(q_0\) 线性独立：\(p_i\ne p_j\)，且
\(q_0=p_i\) 将推出 \(x_0=y_i\)，被 \(X\cap Y=\varnothing\) 排除。
故 \(\operatorname{rank}(q_0,p_i,p_j)=3\)。

四个形式 \(q_0,p_0,p_1,p_2\) 的秩为 \(4\)，或为 \(3\) 且唯一关系为

\[
q_0+p_0+p_1+p_2=0.
\tag{2}
\]

条件于 affine 可用 cell 数：

- 恰有两个可用时，行及两列均需保留，概率 \(1/8\)；
- 三个均可用时，行需保留，且三列中至少两列保留，概率
  \[
  \frac12\left(\binom32 2^{-3}+2^{-3}\right)=\frac14.
  \]

若秩为 \(4\)，四个形式的取值均匀。\(q_0=0\) 且恰有两个
\(p_i=1\) 的概率为 \(3/16\)，三者均为 \(1/16\)，所以

\[
\Pr(E_{\ge2})
=\frac3{16}\cdot\frac18+\frac1{16}\cdot\frac14
=\frac5{128}.
\tag{3}
\]

若秩为 \(3\)，关系 (2) 在 \(q_0=0\) 时强制 \(p_0+p_1+p_2=0\)。
可用数至少二时只能恰有两个，三个可用不可能；每个二列模式的 affine
质量为 \(1/8\)，故

\[
\Pr(E_{\ge2})=3\cdot\frac18\cdot\frac18=\frac3{64}.
\tag{4}
\]

取 (3)、(4) 的最大值即得 (1)。

## 用法

若同一中心 row 的 connected-star 子族的 residual cross-intersection
可被三列 \(y_0,y_1,y_2\) 的 pair 事件覆盖，即每个命中 witness
包含其中至少两条对应 cell，则整个子族命中概率至多 \(3/64\)。
该结论与 note 043 的 \(L\)-形闭合互补。
