> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Full-ROC growing-alphabet adaptive-RLDC Closure Gate (2026-08-17)

## Status and purpose

This note extends the full-transcript mutual-information closure to a
polylogarithmic growing proof alphabet without assuming perfect correct-claim
completeness. The proof uses a constant-rate binary inner code for each proof
symbol and the variable-query adaptive relaxed-LDC theorem derived in note 255.
It is a source-safe transfer theorem: the DGL variable-query calculation is
recorded as a derived result in note 255, not attributed as a statement of the
source paper.

The conclusion is deliberately weaker than the fixed-alphabet GGS envelope:
when the binary expansion has raw locality
\(\ell_{\mathrm{bin}}=O(r\log A_K)\), the DGL normalization has
\(Q=O(\ell_{\mathrm{bin}}\log(\ell_{\mathrm{bin}}+2))\), so a near-linear package
must satisfy
\(\ell_{\mathrm{bin}}\log(\ell_{\mathrm{bin}}+2)
=\Omega((\log K)^{1/3})\) in the DGL window. This closes a
genuine imperfect-completeness, growing-alphabet subregime while leaving larger
alphabets and ordinary list soundness outside the hypotheses.

## Theorem

Let

$$
  \Pi_K:\{0,1\}^{K}\longrightarrow\Sigma_K^{P_K},
  \qquad A_K:=|\Sigma_K|\ge2,
$$

be a common proof map. For target \(m\), let \(S\mid M=m\) be a standard-Borel
global policy package. The package contains, for every coordinate \(i\) and
claim \(b\), an adaptive verifier making at most \(r_K\) proof-symbol queries
and a measurable transcript filter whose output is \(b\) or \(\bot\).
We may assume \(r_K\ge1\); if \(r_K=0\), add one dummy proof query.
Fix \(0<\rho<1\) and constants

$$
  2/3\le\alpha\le1,\qquad 0\le\beta\le1/3.
$$

For a target \(m\) and package \(s\), write \(C_{m,i,s}\) for correct-claim
output probability on \(\Pi_K(m)\), and \(W_{m,i,b,s}(z)\) for wrong-claim
output probability on a word \(z\) with
\(d_H(z,\Pi_K(m))\le\rho P_K\). Define

$$
\mathcal D_{\mathrm{ROC}}(m,s):=
\max\left\{
\max_i(\alpha-C_{m,i,s})_+,\;
\max_{\substack{i,b\ne m_i\\
d_H(z,\Pi_K(m))\le\rho P_K}}
(W_{m,i,b,s}(z)-\beta)_+
\right\}.
$$

Let

$$
\bar\delta_K=\mathbb E_{M,S\sim\mu_M}\mathcal D_{\mathrm{ROC}}(M,S),
\qquad
I_K=I(M;S)\ \text{in bits},
\qquad
\tau_K=\bar\delta_K+
\sqrt{\frac{\ln2}{2}I_K}.
$$

Assume that for a fixed
\(\Delta\in(0,(\alpha-\beta)/2)\) one has
\(\tau_K\le\Delta/2\) infinitely often, and on the same subsequence

$$
  K+P_K\le K(\log(K+2))^c,
  \qquad
  L_K\le(\log(K+2))^b,
$$

where \(L_K\) is the block length of a constant-rate binary inner code
\[
  E_K:\Sigma_K\longrightarrow\{0,1\}^{L_K}
\]
so necessarily \(L_K\ge\lceil\log_2 A_K\rceil\), with relative distance at least a fixed \(\eta_{\mathrm{in}}>0\) and unique
decoding from fewer than \(\eta_{\mathrm{in}}L_K/2\) errors. Assume additionally

$$
  \alpha-\Delta\ge\frac23,
  \qquad
  \beta+\Delta\le\frac13.
$$

Then there is a constant
\(\eta=\eta(\rho,\eta_{\mathrm{in}},\alpha,\beta,\Delta,c,b)>0\)
such that, for all sufficiently large \(K\) in the subsequence,

$$
  (1+L_Kr_K)\log(3+L_Kr_K)
  \ge \eta(\log(K+2))^{1/3}.
\tag{305.1}
$$

Equivalently, a full-ROC distributional package with
\((r_K\log A_K)\log(3+r_K\log A_K)=o((\log K)^{1/3})\), polylogarithmic
alphabet, and near-linear proof length cannot satisfy the displayed robust
defect and information conditions.

## Proof

Let \(\bar\mu_K=\mathcal L(S)\). Pinsker and the mutual-information identity
give

$$
\mathbb E_m\mathbb E_{s\sim\bar\mu_K}
\mathcal D_{\mathrm{ROC}}(m,s)
\le \tau_K.
$$

Markov leaves a target family \(\mathcal F_K\) of density at least \(1/2\) on
which the marginal package law \(\bar\mu_K\) has, simultaneously for all
coordinates and all target-relative \(\rho P_K\)-near proofs,

$$
  \mathbb E_{\bar\mu_K} C_{m,i,S}\ge\alpha-\Delta\ge2/3,
  \qquad
  \mathbb E_{\bar\mu_K} W_{m,i,b,S}(z)\le\beta+\Delta\le1/3.
\tag{305.2}
$$

Sauer--Shelah supplies a coordinate set \(J_K\) of size
\(d_K=(1/2-o(1))K\) shattered by \(\mathcal F_K\). Choose one representative
target \(m_u\) for every \(u\in\{0,1\}^{J_K}\), and restrict the proof map to
these representatives. If two representatives differ at coordinate \(i\)
but their proof words have distance at most \(\rho P_K\), the same marginal
package law in (305.2) would give both a correct output at least \(2/3\) and
a wrong output at most \(1/3\) on the same proof, a contradiction. Hence
the restricted proof words have pairwise distance \(>\rho P_K\).

Encode each proof symbol with \(E_K\) and leave the \(d_K\) inline message bits
in binary. The resulting binary code has length

$$
  \widehat N_K=d_K+L_KP_K.
$$

Its distance is at least \(\eta_{\mathrm{in}}L_K\rho P_K\). The \(A_K\)-ary
Singleton bound gives
\(d_K\le((1-\rho)P_K+1)\lceil\log_2A_K\rceil\), so
\(L_KP_K/(d_K+L_KP_K)\) is bounded below by a positive constant. Therefore
the binary code has a fixed positive relative distance, after reducing the
constant by a factor of two to absorb the \(+1\) term.

Given a binary word within that radius of an encoded codeword, each queried
inner block is decoded to a proof symbol unless it contains
\(\eta_{\mathrm{in}}L_K/2\) or more errors. The number of bad inner blocks is
at most \(2e/(\eta_{\mathrm{in}}L_K)\), where \(e\) is the total binary error
count. Choosing the binary radius small enough makes the decoded proof word
\(\rho P_K\)-close to the target proof. The decoder reads one inline bit,
decodes all \(L_K\) bits of each proof symbol queried by the package, and then
applies the package filter. Its adaptive query count is

$$
  q_K^{\mathrm{bin}}\le \ell_K^{\mathrm{bin}}:=1+L_Kr_K.
\tag{305.3}
$$

On an uncorrupted codeword, (305.2) gives completeness at least \(2/3\).
On a nearby word whose inline bit is wrong, (305.2) gives wrong output
probability at most \(1/3\). Thus this is a binary adaptive relaxed LDC with
constant radius and query count \(q_K^{\mathrm{bin}}\).

The variable-query adaptive relaxed-LDC theorem of note 255 says that, in the
window \(Q_K^3=o(\log\widehat N_K)\), where
\[
  Q_K\le C_0\ell_K^{\mathrm{bin}}\log(\ell_K^{\mathrm{bin}}+2),
\]
a binary relaxed LDC
with \(\widehat N_K\le d_K\operatorname{polylog}d_K\) cannot exist. The
assumed bounds on \(L_K\) and \(K+P_K\) imply
\(\widehat N_K\le K(\log(K+2))^{c+b+O(1)}
\le d_K\operatorname{polylog}d_K\). Therefore
\(\ell_K^{\mathrm{bin}}\log(\ell_K^{\mathrm{bin}}+2)
\ge\eta(\log K)^{1/3}\), proving (305.1) after absorbing \(C_0\).
\(\square\)

## Scope and exact boundary

The theorem requires a single global package containing all coordinate/claim
filters; separate coordinate-specific proofs do not satisfy the premise.
Ordinary average/list soundness does not provide the maximum over coordinates
and nearby proofs used in \(\mathcal D_{\mathrm{ROC}}\). The result also assumes
a constant-rate inner binary code; if \(\log A_K\) is super-polylogarithmic,
the binary expansion itself is a separate alphabet-size escape. The DGL
variable-query theorem used here is a derived source-safe statement from its
proof ingredients (note 255), not a claim that the source paper states the
growing-query relaxed-LDC corollary verbatim.

## Sources

* [Full-ROC mixture closure](275-mutual-information-mixture-to-full-roc-closure-2026-08-20.md).
* [Variable-query relaxed-DGL theorem](255-variable-query-relaxed-dgl-theorem-2026-08-17.md).
* [Dall'Agnol--Gur--Lachish, ECCC TR20-154](https://eccc.weizmann.ac.il/report/2020/154/).
