> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Short oracle-descriptor boundary (2026-08-24)

## Theorem

Let \(A=\mathcal L_{\mu_H,n}\), \(N=2^n\), and suppose a deterministic fixed-alphabet one-tape
source transducer \(G_n\) writes one query \(d(f)\) of length
\(\ell=N^{\delta+o(1)}\) in time \(N^{b+o(1)}\). If a fixed oracle relation \(R\) satisfies

\[
R(d(f))=1\quad\Longleftrightarrow\quad f\in A
\]

for every source table \(f\), then

\[
\boxed{\max\{1,b\}+2\delta\ge2\mu_H.}
\]

Thus a constant-length query descriptor forces \(b\ge2\mu_H\). The result does not cover
arbitrary implicit quotients: it assumes that the descriptor is a single oracle query whose
answer is the source predicate.

## Proof

Combine \(G_n\) with one query to \(R\). This is an oracle RTM with constant finite control,
time \(t=N^{\beta+o(1)}\), \(\beta=\max\{1,b\}\), and query length
\(\ell=N^{\delta+o(1)}\). CHMY, Corollary 22, gives a local PRG whose seed length and output
circuit complexity are

\[
\widetilde O\!\left(\sqrt t\,(\ell+\log t)\right)
=N^{\beta/2+\delta+o(1)}.
\]

If \(\beta/2+\delta<\mu_H\), every PRG output is in \(A\), while a uniformly random source
table is in \(A\) with probability \(o(1)\) by circuit enumeration. The oracle RTM therefore
distinguishes the PRG from uniform, contradicting the PRG guarantee. Hence the displayed
inequality.

## Boundary

This is stronger than a full-output descriptor count when \(\delta\) is small, because it
does not require target materialization or a CHMY handoff. It is nevertheless an interface
theorem: taking \(d(f)=f\) gives \(\delta=1\), while an arbitrary quotient need not expose a
single query relation \(R\).
