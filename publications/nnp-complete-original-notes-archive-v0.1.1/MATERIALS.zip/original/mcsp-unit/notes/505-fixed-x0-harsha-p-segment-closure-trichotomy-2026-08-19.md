> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定 \(x_0\) 的 Harsha \(P=p(q)\) 段闭合三分（2026-08-19）

## 本轮改变的判断

C457、C446 已分别说明 Harsha 的 \(P=p(q)\) 与 generic assignment access
在同一 source-compatible serialization 下可相互编译，C458 则关闭了仅凭
systematic Reed--Muller 网格表获得 generic point access 的黑箱捷径。本轮把这两点
和 published RW 的同一 hard output/长度集（C455--C456）合并，并把
target-dependent descriptor 明确计入 evaluator package：

> 对固定 \(x_0\) 的 Harsha source，若 \(P\)-段仍保持精确 factorization、同一
> proof/address space、output projection 与 source-compatible incidence，那么它只有
> forcing-scale package、object-scale grid/oracle table，或退出 factorization 三类；
> 不存在一个额外的 address-scale exact-access 分支。

这不是 \(P\ne NP\) 证明；它是当前唯一正攻的 \(P\)-段接口的路线关闭定理。它改变的
下一步判断是：不再继续寻找“把 \(P\) 当作独立短辅助字符串”的 evaluator，而只研究
不满足 Harsha factorization 的新 global relation。

## 固定 source 与 package

取 C455 的无限 hard-length 集合 \(\mathcal I\)。对 \(n\in\mathcal I\)，令

\[
 B_n=A'(1^n,a_n),\qquad N_n=|B_n|=2n,
 \qquad \operatorname{CC}(B_n)\ge cN_n/\log N_n .
\tag{505.1}
\]

在反证分支 \(P=NP\) 下，C456 给出同一个确定性 source machine 与 regular
source \(x_n=(1^n,a_n)\)。采用 C453 的 hist-first、C444 的 cell-time
serialization 和 C454 的 fresh output-check，记 \(q_n:F_n^{m_n}\to F_n\) 为
honest systematic assignment 的低度延拓，并满足

\[
q_n(u_{n,j})=B_n[j]\qquad (j\in[N_n]).
\tag{505.2}
\]

一个 \(P\)-access package \(\mathcal E_n\) 包含：

* 一个 generic-point field-symbol evaluator \(E_{P,n}\)，返回
  \(P_{q_n}=p(q_n)\) 的任意地址值，电路大小记为 \(s_{P,n}\)；
* 一个可能依赖 \(q_n\) 的 descriptor \(D_n\)，长度记为 \(d_n\)；
* 同一 serialization 上的 \(\widehat C\)-evaluator、incidence map 和 output map，大小分别为
  \(s_{C,n},s_{\mathrm{Inc},n},s_{\mathrm{out},n}\)。

所有 descriptor bits 都计入 \(d_n\)，不允许把它当作未计价 ROM。\(P\)-evaluator
只需满足 exact field-symbol semantics；不要求它来自某个特定实现。

## 定理 505.1（fixed-\(x_0\) Harsha \(P\)-segment trichotomy）

假设 C454 的每个 output coordinate 都有 Harsha (5.7) 所需的非退化 incidence，且
field size \(Q_n=|F_n|\) 满足 C439 的 \(Q_n>(3m_n+3)|H_n|+2\)。则存在
一个只依赖 \(m_n,Q_n\) 的多项式 \(K\)，使任何上述 exact package 都满足

\[
\operatorname{CC}(B_n)
\le K(m_n,Q_n)\bigl(
s_{P,n}+d_n+s_{C,n}+s_{\mathrm{Inc},n}+s_{\mathrm{out},n}+1
\bigr).
\tag{505.3}
\]

因此在 \(Q_n,m_n,s_{C,n},s_{\mathrm{Inc},n},s_{\mathrm{out},n}
=\operatorname{polylog}(N_n)\) 时，

\[
s_{P,n}+d_n=\Omega\!\left(\frac{N_n}{\operatorname{polylog}N_n}\right).
\tag{505.4}
\]

换言之，任何保持同一 exact factorized \(P=p(q)\) 接口的 package 至少支付
forcing scale；若它声称只有 address-scale 大小，就和 (505.1) 矛盾。

### 证明

Harsha §5.4.1 的式 (5.7) 是

\[
p(q)(u,v,w,y_1,y_2,y_3)=
\widehat C(u,v,w,y_1,y_2,y_3)
\prod_{r=1}^3(q(u_r)-y_r).
\tag{505.5}
\]

给定目标 \(u\in H_n^{m_n}\)，C454 产生同一 serialization 中的
\((v_u,w_u)\)，且相应三变量 slice 非零。C439 的两点归一化算法枚举
\((a,b,y)\in F_n^3\)，调用 \(E_{P,n}\) 和 \(E_{C,n}\)，在两个非零 denominator
上取差商，得到 \(q_n(u)\)。枚举、有限域运算和地址生成的电路大小是

\[
K(m_n,Q_n)(s_{P,n}+s_{C,n}+s_{\mathrm{Inc},n}+d_n+1).
\tag{505.6}
\]

这里 \(D_n\) 先被 hardwire 进 package；因此它的每一 bit 都已经计入 \(d_n\)，不能
再作为隐藏的 q-dependent oracle。将 \(u_{n,j}\) 的 output map 接在该 q-evaluator
之前，并用 (505.2) 输出 \(B_n[j]\)，得到 (505.3)。将 C455 的 (505.1) 代入即得
(505.4)。证毕。

## 为什么这确实覆盖了剩余 (P)-段实现

### 1. generic exact evaluator

这是定理 505.1 的 factorized branch。若 \(s_P+d\) 是
\(\operatorname{polylog}N\)，它直接把同一个 \(B_n\) 压到小电路；若不是，则已经
支付 forcing/object scale。

### 2. 只给 systematic grid table

若 \(P\)-段不提供 generic field-symbol evaluator，而只把
\(q_n|_{H_n^{m_n}}\) 作为黑箱表，C458 给出：对 generic point
\(z\in F_n^{m_n}\)，精确 query complexity 是

\[
 |H_n|^{k(z)},\qquad k(z)=|\{r:z_r\notin H_n\}|,
\tag{505.7}
\]

全 off-grid 时就是完整 \(|H_n|^{m_n}\) 表。这个分支不是 address-scale evaluator；
它把长表当作 object-scale ROM。

### 3. 结构化/自动序列表示

若某个额外结构能在 address scale 直接给出 generic \(q_n\)-evaluator，则它仍落入
定理 505.1（先由 C457 的 \(q\to P\) 方向生成 \(P\)，或直接由 (505.2) 触发
C459）。C460 的唯一 regular tableau 反例说明：offset-regular 的 local constraints
本身并不推出这种 solution automaticity；要保留该分支，必须提出一个新的
source-specific low-rank/parallelization theorem。若该结构不产生 generic evaluator，
则它尚未闭合 \(P=p(q)\) 的 exact access 量词。

### 4. 改变 factorization 或 proof 量词

不满足 (505.5) 的 non-product relation、不同 proof、per-address witness、未计价
global memory 或 off-grid approximate semantics，都不属于 Harsha \(P\)-segment
branch。它们可以是新的正攻方向，但必须重新证明 same-word、same-proof、smartness、
cover/bottom safety 和 address-scale；不能继续标为 (P=p(q)) closure。

## 结论与停止条件

在 C453--C456 的 source-compatible fixed-\(x_0\) 窗口内，Harsha \(P\)-段正攻现在
停止。后续只有两类工作仍会改变主线：

1. 给出一个不满足 (505.5) 的、仍能完成 Gate I--III 的 non-product global relation；或
2. 证明某个声明的 structured representation 确实产生 generic q-access，并接受
   (505.4) 的 forcing contradiction。

继续优化 \(\widehat C\) 的 offset-DP、重命名 systematic table，或把 q-dependent descriptor
留在未计价 ROM 中，都不再是独立路线。

## 证据边界

* 定理在 \(P=NP\) 反证分支、C455 的 published hard output 与 C456 的同一无限长度集上
  使用；不宣称无条件 \(P\ne NP\)。
* \(K(m,Q)\) 吸收 \(O(Q^3)\) 次 field-point 枚举、有限域算术、Inc/output 地址图和
  descriptor hardwiring；在 Harsha 最小字段实例中 \(Q,m=\operatorname{polylog}N\)。
* C458 的 grid lower bound 是 black-box exact/zero-error 结果；它不排除真正新的
  structured global relation，但要求该结构显式给出而不能从低度延拓自动推出。

## 来源

* Harsha, *Robust PCPs of Proximity and Shorter PCPs*, §5.4.1, Proposition 5.4.1,
  equations (5.6)--(5.9): <https:/[unbundled local reference].ttic.edu/~prahladh/papers/thesis/phdthesis.pdf>.
* Ren--Williams, ECCC TR26-118 revision 1, Lemma 3.2 and Theorems 3.4--3.5:
  <https://eccc.weizmann.ac.il/report/2026/118/revision/1/download>.
* [C439](439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md),
  [C444](444-cell-time-offset-regular-rw-unrolling-2026-08-19.md),
  [C454](454-rw-source-compatible-incidence-auxiliary-barrier-2026-08-19.md),
  [C455](455-published-rw-hard-output-forcing-scale-2026-08-19.md),
  [C456](456-published-rw-output-source-alignment-and-direct-scale-boundary-2026-08-19.md),
  [C457](457-harsha-q-p-generic-access-equivalence-2026-08-19.md),
  [C458](458-grid-to-generic-exact-query-lower-bound-2026-08-19.md),
  [C459](459-published-rw-generic-q-access-forcing-scale-2026-08-19.md),
  [C460](460-local-constraint-regularity-does-not-force-solution-automaticity-2026-08-19.md),
  [C446](446-harsha-auxiliary-circuit-hardness-transfer-2026-08-19.md).
