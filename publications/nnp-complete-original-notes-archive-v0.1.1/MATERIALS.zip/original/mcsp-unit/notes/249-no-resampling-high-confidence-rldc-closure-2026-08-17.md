> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No-resampling closure for the high-confidence branch region (2026-08-17)

## Contribution

The joint phase boundary in note 248 uses independent resampling to amplify an
arbitrary positive branch gap.  That assumption is not needed in the
high-confidence region.  A one-bit fallback after a branch rejection converts
the original two-branch verifier directly into the imperfect-completeness
relaxed-LDC model of Dall'Agnol--Gur--Lachish.

This closes a distinct escape: correlated or non-resampleable branch randomness
cannot preserve a fixed-alphabet, fixed-locality, near-linear proof whenever
the correct branch is sufficiently reliable and the wrong branch is at most
one-third reliable.

## Theorem

Fix a finite proof alphabet \(\Sigma\) of size \(A\ge2\), constants
\(0<\rho<1\), \(r\ge1\), and branch probabilities
\[
  0\le\beta\le\frac13,\qquad
  0\le\alpha\le1,\qquad
  2\alpha-\beta\ge1,
\tag{249.1}
\]
where \(\alpha\) is correct-branch completeness and \(\beta\) is
target-relative wrong-branch soundness.

Let
\[
 \Pi:\{0,1\}^k\longrightarrow\Sigma^P
\]
be a common proof map.  For every message coordinate \(i\) and claim \(b\),
let \(V_{i,b}\) be a randomized adaptive verifier making at most \(r\)
proof-symbol queries.  Assume
\[
 p_{i,m_i}(\Pi(m))\ge\alpha,
 \qquad
 d_H(z,\Pi(m))\le\rho P
 \Longrightarrow
 p_{i,1-m_i}(z)\le\beta.
\tag{249.2}
\]
No independent-resampling assumption is made.

Then the binary recoding of the inline proof is an adaptive relaxed LDC with
constant radius and query complexity
\[
 q_{\mathrm{bin}}=1+\lceil\log_2 A\rceil r.
\tag{249.3}
\]
Consequently, Dall'Agnol--Gur--Lachish imply
\[
 N_{\mathrm{bin}}
 \ge
 k^{\,1+1/O_{A,\rho,r}(1)}
\tag{249.4}
\]
for all sufficiently large \(k\).  Since
\(N_{\mathrm{bin}}=k+O_A(P)\), no \(k\,\operatorname{polylog} k\)
common-proof family can satisfy (249.2).

## Proof

### 1. Distance

If two proof words for distinct messages were within \(\rho P\), choose a
coordinate where the messages differ.  Completeness for one target and the
wrong-branch bound for the other would give \(\alpha\le\beta\), contradicting
(249.1).  Thus the proof image has symbol distance \(>\rho P\).

### 2. Binary recoding and radius

Fix an injective encoding
\(e:\Sigma\hookrightarrow\{0,1\}^{\ell}\), where
\(\ell=\lceil\log_2 A\rceil\).  The tagged binary codeword is
\[
 C(m):=m\ \Vert\ e(\Pi(m)),
\]
with the inline bit for coordinate \(i\) read directly and each proof symbol
represented by its \(\ell\)-bit block.

Distinct codewords have binary distance \(>\rho P\).  By the
\(A\)-ary Singleton bound, \(P=\Omega_{A,\rho}(k)\), so
\[
 \delta:=\frac{\rho P}{2(k+\ell P)}
\]
is a positive constant.  Moreover \(\delta\) is less than half the relative
distance of \(C\).

A binary word within distance \(\delta\) of \(C(m)\) induces, after mapping
each proof block to an arbitrary symbol when necessary, a proof word \(z\)
with \(d_H(z,\Pi(m))\le\rho P\).  Invalid block encodings are treated as
symbol errors.

### 3. Fallback postprocessing

Set
\[
 q_0:=\frac{1/3-\beta}{1-\beta}\in[0,1].
\tag{249.5}
\]
The decoder reads the inline bit \(b\), runs \(V_{i,b}\), outputs \(b\) if
the branch accepts, and, if it rejects, outputs \(b\) with probability
\(q_0\) and \(\bot\) otherwise.

On an exact codeword the inline bit is \(m_i\), so the probability of output
\(m_i\) is at least
\[
 \alpha+(1-\alpha)q_0\ge\frac23,
\]
where the last inequality is exactly \(2\alpha-\beta\ge1\).

On a nearby word with the wrong inline bit, an erroneous output occurs with
probability at most
\[
 \beta+(1-\beta)q_0=\frac13.
\]
With the correct inline bit, the decoder outputs only that correct bit or
\(\bot\).  Thus this is a binary adaptive relaxed LDC in the
Dall'Agnol--Gur--Lachish model, with constant radius and query complexity
\(1+\ell r\).

### 4. Lower bound

The adaptive relaxed-LDC lower bound of Dall'Agnol--Gur--Lachish gives
\[
 N_{\mathrm{bin}}\ge
 k^{1+1/O(q_{\mathrm{bin}}^2\log^2 q_{\mathrm{bin}})}.
\]
For fixed \(A\) and \(r\), the exponent is a fixed positive constant, yielding
(249.4).  Since \(\ell\) is constant, binary recoding changes the original
proof length only by a constant factor, contradicting near-linear length.

## Interpretation

This theorem is logically different from note 248:

* note 248 handles arbitrary positive gaps but uses independent resampling to
  amplify them and then invokes the arbitrary-alphabet non-adaptive RLDC bound;
* the present theorem needs no resampling, but closes the high-confidence
  region \(\beta\le1/3\), \(2\alpha-\beta\ge1\), for fixed alphabet and fixed
  locality.

The remaining no-resampling region is not a notational gap.  If
\(\beta>1/3\), or \(2\alpha-\beta<1\), the one-bit fallback cannot reach the
\(2/3\)-versus-\(1/3\) relaxed-LDC thresholds by this postprocessing alone.
A stronger local-code theorem or a different amplification mechanism would be
needed there.

## Scope

This is a reduction to the adaptive relaxed-LDC lower bound, not a new
coding lower-bound proof.  It is nevertheless a genuine closure of a
different verifier model: fixed shared proof, fixed finite alphabet, fixed
locality, no independent branch resampling, and the high-confidence branch
region.

## Sources

* M. Dall'Agnol, T. Gur, and O. Lachish, *A Structural Theorem for Local
  Algorithms with Applications to Coding, Testing, and Privacy*, Corollary
  7.9, <https://eccc.weizmann.ac.il/report/2020/154/>.
* [Joint alphabet--gap--locality boundary](248-joint-alphabet-gap-locality-phase-boundary-2026-08-17.md).
