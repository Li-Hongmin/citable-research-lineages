> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 全局行秩势：非有限命中、递归合法、且抗随机 thinning（2026-08-13）

## 目标

有限超边命中势已被随机 affine 最大叶 + 行列 thinning 关闭。本节给出一个不同类型的候选：它只依赖整行侧的全局基数，不能写成有限个 cell 超边命中计数；同时，存在明确的最大叶，使标准 (p=1/2) thinning 后势的条件期望仍为负。

这不是 (P\ne NP) 下界；它是一个把“随机 thinning 平均必关闭”从候选类中移出的可检验接口。

## 定义

令

\[
m=|X|=3k-1,
\qquad c=\frac{3k-1}{2},
\qquad k\ge 50.
\]

定义 (g:\{0,\ldots,m\}\to\mathbb R)：

\[
g(n)=n-c\left\lfloor\frac nk\right\rfloor .
\tag{1}
\]

所以

\[
g(n)=
\begin{cases}
n,&0\le n<k,\\
n-c,&k\le n<2k,\\
n-m,&2k\le n<m,\\
0,&n=m.
\end{cases}
\tag{2}
\]

取任意 (λ\ge0)，对矩形 (R=A\times B) 定义

\[
K(R)=\lambda\,g(|A|)\,|B|.
\tag{3}
\]

它是对整行侧 (A) 的非线性全局势，而非有限 cell 超边的命中和。

## 递归证明

函数 (g) 次可加：

\[
g(a+b)\le g(a)+g(b),
\qquad a+b\le m.
\tag{4}
\]

最短表示证明：允许生成元 (1) 的代价 (1)，生成元 (k) 的代价 (-c)。对 (n<m)，最优表示尽可能多使用 (k)，故代价正是 (1)。当 (n=m=2k+(k-1)) 时，最优代价为

\[
m-2c=0=g(m).
\]

拼接 (a,b) 的最优表示即得 (4)。

若 (R=V\dot\cup W) 为横向二分，写 (V=A_1\times B)、(W=A_2\times B)，则

\[
K(V)+K(W)-K(R)
=\lambda |B|\bigl(g(|A_1|)+g(|A_2|)-g(|A|)\bigr)\ge0.
\tag{5}
\]

若为纵向二分 (V=A\times B_1)、(W=A\times B_2)，则 (|B_1|+|B_2|=|B|)，于是

\[
K(V)+K(W)=K(R).
\tag{6}
\]

并且根矩形满足

\[
K(X\times Y)=\lambda g(m)|Y|=0.
\tag{7}
\]

故 (3) 是完整 QA recursion 的可行标量势。

## 抗 thinning 计算

取一个最大 affine 叶，其行侧大小

\[
q=\left\lfloor\frac{12k}{5}\right\rfloor
\]

（该大小是后续语义构造的待验证输入条件）。对叶内行、列分别以 (1/2) 独立保留。行侧 (Z\sim\mathrm{Bin}(q,1/2))，故

\[
\mathbb E[g(Z)]
=\frac q2-c\,\mathbb E\left\lfloor\frac Zk\right\rfloor
\le \frac q2-c\Pr[Z\ge k].
\tag{8}
\]

这里 (mathbb E Z=q/2\le 6k/5)，Hoeffding 给出

\[
\Pr[Z<k]\le \exp(-k/30).
\tag{9}
\]

由 (c=(3k-1)/2)，当 (k\ge50) 时

\[
\mathbb E[g(Z)]
\le\frac{6k}{5}-\frac{3k-1}{2}(1-e^{-k/30})<-rac k5.
\tag{10}
\]

列侧 (Z_B\sim\mathrm{Bin}(|B_0|,1/2)) 独立，(mathbb E Z_B=|B_0|/2)。因此

\[
\mathbb E[K(R)\mid R_0]
=\lambda\,\mathbb E[g(Z)]\,\frac{|B_0|}{2}<0.
\tag{11}
\]

所以“先取最大 affine 叶，再以 (p=1/2) 行列 thinning，并用 (mathbb E K\ge0) 关闭”对该势族不成立。

## 叶归一化（保守基准）

因为 (g(n)\le n)，令 (M=|X||Y|=m|Y|)，

\[
\lambda=\frac1{2M},
\qquad \phi_{(x,y)}=\lambda.
\tag{12}
\]

在 (g(|A|)\ge0) 的叶上，

\[
\sum_{(x,y)\in A\times B}\phi_{(x,y)}+K(A\times B)
\le \lambda |A||B|+\lambda g(|A|)|B|
\le 1.
\tag{13}
\]

在 (g(|A|)<0) 的叶上，第二项只会降低左端；故 (13) 对所有 affine-parity 叶成立。该归一化的目标值仅为

\[
\sum_{c\in X\times Y}\phi_c=\frac12.
\]

它只用于证明“候选合法且抗 thinning”，不宣称已得到超线性下界。

## 下一承重义务

当前负区间 (2k\le |A|<m) 的幅度为 (Theta(k))，但小行侧 ( |A|<k) 给出正势。因此要把 (3) 推到 (N^{1.01})，必须由 (E_a\times NO_b) 的语义证明：

\[
\text{大正势叶的 }|B|\text{ 总容量很小，}
\qquad
\text{而 }|A|\in[2k,m)\text{ 的负势叶承载大质量。}
\tag{14}
\]

若 (14) 失败，该候选仅说明“anti-thinning 不等于下界”；应转向同时依赖行、列全局秩的双侧势。

