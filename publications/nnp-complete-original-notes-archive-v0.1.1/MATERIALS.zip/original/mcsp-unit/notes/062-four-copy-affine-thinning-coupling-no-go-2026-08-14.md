> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 四副本 affine-thinning coupling 的不可能性（2026-08-14）

## 核

令

\[
D\subseteq\mathbb F_2^N\setminus\{0\},\qquad
r\sim\operatorname{Unif}(\mathbb F_2^N),\qquad
(v_d)_{d\in D}\sim\operatorname{Ber}(1/2)^D,
\]

且两者独立。定义

\[
Q_D(r,v):=\{d\in D:r\cdot d=1,\ v_d=1\}.
\tag{1}
\]

这是同中心 row-star 中固定中心已被叶包含并被保留以后，列差向量
\(d=y+x_0\) 所见的 affine-hyperplane 加独立列 thinning 核。

若存在四个同边缘副本 \(Q_1,\ldots,Q_4\stackrel{\rm marg}{\sim}Q_D\)，且

\[
Q_i\cap Q_j=\varnothing\quad(i\ne j)\quad\text{a.s.},
\tag{2}
\]

则任意两两相交的列集族至多在一个副本中命中。因此 (2) 原本会给出

\[
\Pr_{r,v}[\exists S\in\mathcal F:S\subseteq Q_D]\le\frac14.
\tag{3}
\]

下面说明：不存在对所有 \(D\) 都可用的这种四副本轨道/coupling。

## 定理

记

\[
H_a:=\{d\in D:a\cdot d=1\}\qquad(a\in\mathbb F_2^N).
\]

若 (2) 成立，则必存在 \(a_1,\ldots,a_4\in\mathbb F_2^N\) 使

\[
D\subseteq H_{a_1}\cup H_{a_2}\cup H_{a_3}\cup H_{a_4}.
\tag{4}
\]

特别地，对

\[
D_N:=\mathbb F_2^N\setminus\{0\},\qquad N\ge5,
\]

不存在满足 (2) 的四副本 coupling。

更贴近 row-star 环境地，任取 \(a\ne0\)，令

\[
D_{N,a}:=\mathbb F_2^N\setminus\{0,a\}.
\tag{5}
\]

当 \(N\ge6\) 时，对 \(D=D_{N,a}\) 也不存在满足 (2) 的四副本 coupling。
这个支持可由合法 AEKR 环境实现：取 \(x_0=0\)、\(x_s=a\)、
\(X=\{0,a\}\)、\(Y=D_{N,a}\)，以及任意 \(y_s\in Y\)，则
\(\{y+x_0:y\in Y\}=D_{N,a}\)。

## 证明

任意 \(d\in D\) 满足

\[
\Pr[d\in Q_D]
=\Pr[r\cdot d=1]\Pr[v_d=1]
=\frac14.
\tag{6}
\]

令 \(X_i(d)=\mathbf1_{d\in Q_i}\)。由 (2)，

\[
0\le\sum_{i=1}^4X_i(d)\le1,
\qquad
\mathbb E\sum_{i=1}^4X_i(d)=4\cdot\frac14=1.
\]

故对每个 \(d\)，上式几乎处处等于 \(1\)。\(D\) 有限，取所有 \(d\)
的概率一事件之交，得到

\[
D=Q_1\dot\cup Q_2\dot\cup Q_3\dot\cup Q_4
\quad\text{a.s.}
\tag{7}
\]

原始联合分布中 \(Q_D\subseteq H_r\) 几乎处处。对每个 \(i\)，在给定
\(Q_i\) 后按原始条件分布抽取 \(a_i\)；这是有限空间上的 regular conditional
distribution，且不改变 \(Q_i\) 的边缘。于是

\[
Q_i\subseteq H_{a_i}\quad\text{a.s.}
\]

与 (7) 合并即得 (4)。

最后取 \(D=D_N\) 且 \(N\ge5\)。任给四个 \(a_i\)，令

\[
W=\operatorname{span}\{a_1,a_2,a_3,a_4\}.
\]

则 \(\dim W\le4<N\)，所以存在 \(0\ne d\in W^\perp\)。此 \(d\in D_N\)，而

\[
a_i\cdot d=0\quad(i=1,\ldots,4),
\]

故 \(d\notin\bigcup_iH_{a_i}\)，与 (4) 矛盾。

对 \(D_{N,a}\) 的断言相同：此时 \(\dim W^\perp\ge N-4\ge2\)，故
\(W^\perp\) 至少有三个非零元；其中至多一个是被删掉的 \(a\)。选取另一非零
\(d\in W^\perp\setminus\{a\}\) 即再次违反 (4)。这证明两个特别情形。\(\square\)

## AEKR 边界

这关闭的只是下列普适步骤：

\[
\boxed{
\text{仅由 }Q_D\text{ 的边缘分布构造四个逐点 cell-disjoint 同分布副本}
\ \Longrightarrow\ (3).}
\]

它不构成完整 AEKR 的反例，也不排除：

1. 只适用于实际 witness-support \(D\) 的特殊 coupling；
2. 使用 XOR target、spoiler separator 或多组件 star-forest 结构的论证；
3. 非逐点互斥的加权/谱论证；
4. 直接控制跨参数 \(r\) 的联合质量。

因此，note [047](047-common-center-mixed-three-target-boundary-2026-08-13.md) 和
[061](061-common-center-mixed-three-target-closure-2026-08-13.md) 的剩余接口不能靠
“把单个 affine-thinning 核复制四次并互斥化”普适解决；任何有效证明必须使用上述额外结构中的至少一项。
