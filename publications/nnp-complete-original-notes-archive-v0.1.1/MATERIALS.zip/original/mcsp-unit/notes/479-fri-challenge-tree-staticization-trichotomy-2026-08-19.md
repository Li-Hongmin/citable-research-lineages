> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# FRI challenge-tree staticization trichotomy (2026-08-19)

## 改变的判断

FRI 的 challenge-dependent oracle layers 不能仅靠“分支数很多”排除静态化。对正式
honest FRI recursion，有三个严格不同的尺度：

\[
  \text{verbatim challenge tree}
  \quad\longrightarrow\quad
  \text{\(N\)-symbol layer polynomial}
  \quad\longrightarrow\quad
  \text{fixed-singleton evaluator}.
  \tag{479.1}
\]

逐 challenge-prefix 复制 oracle 会产生精确的几何级数成本；但把第 \(i\) 层视为
challenges 的多变量多项式后，其全部系数恰由 \(N\) 个 field symbols 参数化，而不是
\(|F|^iN/b^i\)。这个 \(N\)-symbol 结论对 full raw family 是尖锐的线性同构；
对固定 singleton 则不再是下界，零函数把整棵树压成常数 evaluator。

另一方面，symbolic compression 没有免费提供 local evaluation。对 typical
nondegenerate challenges，第 \(i\) 层一个 target symbol 是 \(b^i\) 个 base symbols
的 dense linear form；completion-rich raw family 因而支付 \(b^i\) 查询。对 fixed
RW singleton，只有再给同一 \(B_n\) 的逐地址 decoder，才能通过 C473/C474 把 symbolic
evaluator 计入 forcing scale。

## 正式参数

记

\[
  N=|L^{(0)}|=2^k,\qquad
  M=|F|,\qquad
  b=2^\eta,
  \tag{479.2}
\]

并令

\[
  R_\rho=\log_2(1/\rho),\qquad
  r=\left\lfloor\frac{k-R_\rho}{\eta}\right\rfloor .
  \tag{479.3}
\]

以下取正式 FRI 的 dyadic parameter regime：

\[
  R_\rho\in\mathbb Z_{\ge0},\qquad
  \rho=2^{-R_\rho},\qquad
  k\ge R_\rho+\eta,
  \tag{479.3a}
\]

从而 \(r\ge1\)，且下面的 terminal coefficient length 是整数。

正式 FRI 第 \(i\) 层 domain 长度为

\[
  |L^{(i)}|=\frac{N}{b^i}.
  \tag{479.4}
\]

第 \(i\) 层 honest oracle \(f^{(i)}\) 依赖 challenge prefix
\((x^{(0)},\ldots,x^{(i-1)})\in F^i\)。中间层 \(1\le i<r\) 发送整张
\(f^{(i)}\) table；完整 \(r\)-challenge prefix 的 terminal message 是
\(d+1\) 个系数，其中

\[
  d+1=\rho |L^{(r)}|
  =\frac{\rho N}{b^r}.
  \tag{479.5}
\]

## 定理 479.1（verbatim challenge-tree cost）

若静态对象逐字存储每个 challenge prefix 对应的 honest oracle，并把 received
\(f^{(0)}\) 也计入，则 field-symbol 长度精确为

\[
  P_{\rm enum}
  =
  N+
  \sum_{i=1}^{r-1}M^i\frac{N}{b^i}
  +M^r(d+1).
  \tag{479.6}
\]

若只计 prover auxiliary messages，删除首项 \(N\)。令

\[
  a=\frac Mb.
  \tag{479.7}
\]

代入 (479.5) 后，

\[
  P_{\rm enum}
  =
  N\left(
    \sum_{i=0}^{r-1}a^i+\rho a^r
  \right).
  \tag{479.8}
\]

所以

\[
  P_{\rm enum}
  =
  \begin{cases}
    N\dfrac{a^r-1}{a-1}+\rho Na^r,&a\ne1,\\[6pt]
    N(r+\rho),&a=1.
  \end{cases}
  \tag{479.9}
\]

当 \(a>1\) 且远离 \(1\) 时，最后中间层与 terminal 项之比由

\[
  \frac{\rho Na^r}{Na^{r-1}}
  =\rho a
  =\frac{\rho M}{b}
  \tag{479.10}
\]

精确决定；\(a\) 接近 \(1\) 时应保留 (479.8)，不能丢掉几何和式。

证明只需数节点：长度 \(i\) 的 challenge prefixes 有 \(M^i\) 个，每个节点存
\(N/b^i\) 个 symbols；terminal 有 \(M^r\) 个 coefficient vectors。证毕。

这个定理只计价 **verbatim** materialization，不是任意静态描述的下界。不同 prefixes
的 oracles 可以相同，也可以共享代数表示。

## 定理 479.2（symbolic layer collapse）

固定 \(i\le r\) 与 \(y\in L^{(i)}\)。令

\[
  \mathcal A_0(y)
  :=
  (q^{(i-1)}\cdots q^{(0)})^{-1}(y),
  \qquad
  |\mathcal A_0(y)|=b^i,
  \tag{479.11}
\]

并令

\[
  \mathcal P_i
  :=
  \{P\in F[X_0,\ldots,X_{i-1}]:
       \deg_{X_j}P<b\ \forall j\}.
  \tag{479.12}
\]

把 challenges 保留为形式变量，honest fold recursion 定义

\[
  \mathcal F_{i,y}(X_0,\ldots,X_{i-1})
  \in\mathcal P_i.
  \tag{479.13}
\]

则线性映射

\[
  \Phi_{i,y}:
  F^{\mathcal A_0(y)}
  \longrightarrow
  \mathcal P_i,
  \qquad
  f^{(0)}|_{\mathcal A_0(y)}
  \longmapsto
  \mathcal F_{i,y},
  \tag{479.14}
\]

是同构。特别地，

\[
  \dim_F\mathcal P_i=b^i.
  \tag{479.15}
\]

不同 \(y\in L^{(i)}\) 的 ancestor basins 构成 \(L^{(0)}\) 的 partition，故直和映射

\[
  F^{L^{(0)}}
  \xrightarrow{\ \cong\ }
  \bigoplus_{y\in L^{(i)}}\mathcal P_i
  \tag{479.16}
\]

也是线性同构，两侧维数都精确为

\[
  \frac{N}{b^i}\cdot b^i=N.
  \tag{479.17}
\]

### 证明

\(i=0\) 时是恒等映射。归纳地，固定 \(y\in L^{(i)}\)，其上一层 fiber
\(S_y\subseteq L^{(i-1)}\) 有 \(b\) 个 children，且

\[
  \mathcal A_0(y)
  =
  \bigsqcup_{z\in S_y}\mathcal A_0(z).
  \tag{479.18}
\]

由归纳假设，每个 child 的 base values 与
\(\mathcal P_{i-1}\) 独立同构。第 \(i-1\) 轮给出

\[
  \mathcal F_{i,y}
  =
  \sum_{z\in S_y}
  \ell_z^{(i-1)}(X_{i-1})
  \mathcal F_{i-1,z}(X_0,\ldots,X_{i-2}),
  \tag{479.19}
\]

而 \(b\) 个 Lagrange basis polynomials
\(\ell_z^{(i-1)}\) 构成次数 \(<b\) 的单变量多项式空间的一组基。因此 (479.19)
是

\[
  \bigoplus_{z\in S_y}\mathcal P_{i-1}
  \cong
  \mathcal P_i
  \tag{479.20}
\]

的同构。归纳完成；再对 \(y\) 作直和即得 (479.16)。证毕。

所以把第 \(i\) 层所有 challenge-dependent oracles 存成 raw coefficient table，
只需且恰需 \(N\) 个 field coefficients。若一个 \(F\)-symbol descriptor 必须对 full
family 精确恢复这些多项式，(479.16) 的单射性也强制 descriptor 至少有 \(N\) 个
symbols。这个结论不适用于 fixed singleton：例如 \(f^{(0)}=0\) 时，

\[
  \mathcal F_{i,y}\equiv0
  \tag{479.21}
\]

对所有 \(i,y\) 成立，整棵 challenge tree 由常数 evaluator 描述。

## 定理 479.3（composed-fold support）

固定 depth \(i\)、target \(y\in L^{(i)}\)，以及 base leaf
\(z_0\in\mathcal A_0(y)\)。令

\[
  z_{j+1}=q^{(j)}(z_j)
  \qquad(0\le j<i).
  \tag{479.22}
\]

则对固定 challenges \(\mathbf x=(x^{(0)},\ldots,x^{(i-1)})\)，

\[
  f^{(i)}(y)
  =
  \sum_{z_0\in\mathcal A_0(y)}
  c_{z_0}(\mathbf x)f^{(0)}(z_0),
  \tag{479.23}
\]

其中

\[
  c_{z_0}(\mathbf x)
  =
  \prod_{j=0}^{i-1}
  \lambda^{(j)}_{z_j}(x^{(j)}).
  \tag{479.24}
\]

对固定 leaf，

\[
  c_{z_0}(\mathbf x)\ne0
  \iff
  x^{(j)}
  \notin
  S_{z_{j+1}}\setminus\{z_j\}
  \quad(\forall j<i).
  \tag{479.25}
\]

独立均匀 challenges 因而给出

\[
  p_{\rm leaf}(i)
  :=
  \Pr[c_{z_0}(\mathbf x)\ne0]
  =
  \left(1-\frac{b-1}{M}\right)^i.
  \tag{479.26}
\]

全部 \(b^i\) 个 coefficients 同时非零，当且仅当第 \(j\) 轮 challenge 避开该
target 的全部 layer-\(j\) ancestors。该集合大小为 \(b^{i-j}\)，所以

\[
  p_{\rm dense}(i)
  =
  \prod_{j=0}^{i-1}
  \left(1-\frac{b^{i-j}}M\right)
  =
  \prod_{h=1}^{i}
  \left(1-\frac{b^h}M\right).
  \tag{479.27}
\]

同层所有 leaves 共享一个 challenge，故 (479.27) 不能由 leafwise 独立性推出；
它来自相关 fibers 的不交并恰为 ancestor set。

在正式参数 \(M\ge N\)、\(i\le r\)、\(R_\rho\ge\eta\) 下，

\[
  b^i\le b^r\le N\rho,
  \qquad
  \rho\le\frac1b.
  \tag{479.28}
\]

union bound 给出

\[
  p_{\rm dense}(i)
  \ge
  1-\frac{\sum_{h=1}^{i}b^h}{M}
  \ge
  1-\frac{b}{b-1}\rho
  \ge
  1-\frac1{b-1}.
  \tag{479.29}
\]

正式 \(b=4\) 时，右侧为 \(2/3\)。

若 base raw family 在每个 leaf 上提供 C475 的 completion，并要求对每个固定
\(\mathbf x\) 逐输入正确，则：

* deterministic exact evaluator 在 all-dense event 上满足 \(Q\ge b^i\)；
* pointwise error 至多 \(\varepsilon<1/2\) 的 randomized evaluator 满足
  \[
    \mathbb E_{\mathbf x,\mathrm{alg}}Q
    \ge
    (1-2\varepsilon)b^i p_{\rm leaf}(i);
    \tag{479.30}
  \]
* 若对 completion-rich family 中的每个 base input，错误率 \(\varepsilon\) 只对
  challenges 与 evaluator randomness 联合平均，则
  leafwise coupling 仍给出
  \[
    \mathbb E Q
    \ge
    b^i\,[p_{\rm leaf}(i)-2\varepsilon]_+.
    \tag{479.31}
  \]

(479.23)--(479.26) 由每层 Lagrange expansion 相乘得到。固定 coefficient 非零的
leaf 后，改变该 leaf 而不改变其余 base symbols 会改变正确输出；C475 的同 random-tape
耦合迫使该 leaf 被查询。逐 leaf 求和得到 (479.30)--(479.31)。

## 静态化三分

把以上结果应用到 FRI-inspired RW attachment，得到：

1. **Verbatim branch tree。** 若每个 challenge prefix 的 oracle 逐字物化，精确支付
   (479.6)--(479.10)。这是一种实现的成本，不是普遍下界。
2. **Full-family symbolic/raw route。** 一个完整 layer 的 challenge polynomial
   coefficient table 精确支付 \(N\) symbols；从 base table 在线重算 target，在
   completion-rich family 上支付 (479.30)--(479.31)。额外 redundancy 或新的
   data structure 不由本定理排除，必须单独计价。
3. **Fixed-singleton evaluator。** 对固定 \(f^{(0)}\)，symbolic evaluator
   \(E(\text{prefix},\text{address})\) 可以很小；零函数已给出严格反例。只有当同一
   evaluator 再与公开的逐地址 decoder 组合、single-valuedly 输出同一 published
   \(B_n[j]\) 时，才进入 C474 的 evaluator-composition forcing。若 symbols 显式
   物化，则 C473 对真实 proof 的 all-address actual support 计价；若没有 target
   decoder，则仍未完成 Gate I。

因此 ordinary FRI 的 interaction 不能单凭分支数成为 static-proof lower bound；
同样，small symbolic prover strategy 也不能单凭存在性成为 RW Closure。精确结论是

\[
  \boxed{
  \text{enumerate}
  \ \lor\
  \text{object-scale symbolic/raw}
  \ \lor\
  \text{charged target evaluator / model exit}.
  }
  \tag{479.32}
\]

这不证明一般 FRI/IOPP/PCS 下界，也不证明 arbitrary symbolic layer circuit 必须大，
更不证明 \(P\ne NP\)。

## 来源

* Ben-Sasson, Bentov, Horesh, Riabzev, *Fast Reed--Solomon Interactive Oracle Proofs of
  Proximity*, ECCC TR17-134 revision 2, Sections 3.2--3.4:
  <https://eccc.weizmann.ac.il/report/2017/134/revision/2/download>。
* [C478：FRI fold-graph local-completion and recovery gate](478-fri-fold-graph-local-completion-and-recovery-gate-2026-08-19.md)。
* [C475：high-arity folding quantifier gate](475-rw-high-arity-folding-quantifier-and-batch-opening-gate-2026-08-19.md)。
* [C473：honest-path support forcing](473-rw-honest-path-support-and-exposed-history-pcpp-gate-2026-08-19.md)。
* [C474：coding-layer/address-scale evaluator dichotomy](474-rw-coding-layer-address-scale-closure-dichotomy-2026-08-19.md)。
* [C229：finite-transcript expansion](229-finite-transcript-expansion-for-rw-closure-2026-08-17.md)。
