> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW hard-table closure dilemma (2026-08-17)

> **尺度修正（2026-08-18）**：本 note 原先声称“在 (P=NP) 下 stable solver
> branch 被 (\Omega(N/\log N)) near-maximum 下界排除”，该句不成立：
> (P=NP) 只给出 (N^{O(1)})-大小电路，而 (N^{O(1)}) 与 (N/\log N) 相容。
> 因此本 note 中从该句推出的“所有 hard length 都进入 reconstruction branch”
> 不再采用。ROM 条件下的 failure/reconstruction 代价仍然成立，但只对已知采用
> 该分支的长度成立。完整修正版见 [note 357](357-rw-hard-table-object-scale-correction-2026-08-18.md)。

## Statement

The RW construction gives more than isolated outsider tables: Theorem 4.5 extracts
infinitely many AVOID outputs with near-maximum circuit complexity.  Combining that
fact with the source-specific lower bound in note 231 yields a sharp closure dilemma.

For a hard output \(H_N\) of table length \(N\), write
\(m=\lceil\log_2N\rceil\).  On every sufficiently large hard length produced by the
RW truth-table-generator construction, one of the following must happen:

1. the solver branch is used (and, because an early solver branch outputs the all-zero
   table, which is already in the truth-table-generator range, this hard length is
   necessarily on the stable tail); or
2. the reconstruction branch is used, and in the straight-line ROM model every finite
   common-response realization of its final queries has

\[
  p+b\,d=\Omega\!\left(\frac{N}{\operatorname{polylog}N}\right),
\tag{232.1}
\]

where \(p\) is the address/control size, \(d\) is the common descriptor length, and
\(b\) is the number of descriptor reads per execution.  In a general fan-in-two
expansion with fixed polynomial overhead, the same argument gives the weaker but still
superpolynomial-in-\(m\) alternative \(p+bd\ge N^{\Omega(1)}\).

The stable solver branch becomes a polynomial-time generator in the *object* length under
\(P=NP\), but this does not contradict the near-maximum lower bound below: a polynomial
of \(N\) may be much larger than \(N/\operatorname{polylog}N\).  Thus the valid
consequence is only the following conditional branch statement:

\[
\boxed{
 P=NP
\ \Longrightarrow\
 \text{infinitely many RW hard lengths require object-scale common coupling,
 or else no finite common-response model exists.}
}
\tag{232.2}
\]

In particular, a uniform \(m^{O(1)}\)-size common strategy/descriptor for all RW
reconstruction hard lengths would complete the \(P\ne NP\) contradiction.  The current
RW theorem does not provide that strategy; note 232 proves that it cannot be a
finite address-scale compression of the existing failure branch.

## Derivation

Let \(A'\) be the smart-FP\({}^{\mathrm{prMA}}/1\) AVOID algorithm from Theorem 4.3.
Theorem 4.5 states that, for infinitely many lengths, its output table \(H_N\) has

\[
  \operatorname{CC}(H_N)\ge c\,\frac{N}{\log(N+2)}
\tag{232.3}
\]

for a fixed \(c>0\).  The construction chooses one advice bit between two branches.

### Solver branch

On the stable tail, the branch \(A_0\) simulates the corresponding \(BF_i\) using
SAT queries and runs in deterministic \(\operatorname{poly}(N)\) time once the SAT
oracle is replaced by a polynomial-time SAT decider.  Thus \(P=NP\) gives a
\(\operatorname{poly}(N)\)-size circuit for \(H_N\), contradicting (232.3) for
sufficiently large \(N\).  An early \(A_0\) branch cannot be a hard output at all,
because it outputs \(0^N\), which is in the range of the truth-table generator.  This
is why no separate assumption about infinitely many stable hard lengths is needed.

### Reconstruction branch

On a failure stage (stable or early), the first \(N=2n_i\) output bits are \(B_i\), and the final
queries \(q_{\pi_i,j}\) use one common PCP proof circuit.  They satisfy the same
perfect-completeness versus \(1/2\)-soundness gap for every address.  Apply note 231
with \(m=\lceil\log_2N\rceil\) and forcing scale
\[
  S=\Omega(N/\log(N+2)).
\]
The sampled-ROM expansion gives

\[
  \operatorname{CC}(B_i)
  \le O\!\left(m(p+b\,d+m)\right)
\]

in the straight-line model.  Combining with the hard-table lower bound yields

\[
  p+b\,d
  =\Omega\!\left(\frac{N}{m^2}\right)
\tag{232.4}
\]

up to constant and lower-order terms.  In the general finite fan-in-two model, note
230 gives a fixed polynomial expansion, so the conclusion is
\(p+bd\ge N^{\Omega(1)}\) when \(p,b\le m^{O(1)}\); the object-scale
\(N/\operatorname{polylog}N\) bound is specific to the straight-line ROM model.

If \(p,b\le m^{O(1)}\), then

\[
  d=\frac{N}{\operatorname{polylog}N}=2^{\Omega(m)}.
\tag{232.5}
\]

This is exactly the object-scale cost that an address-scale Closure Gate was supposed
to avoid.

## Dilemma theorem

Assume \(P=NP\) and suppose, for contradiction, that every sufficiently large hard
RW output admits a finite common-response implementation with
\[
  p,d,b\le(\log N)^{O(1)}.
\tag{232.6}
\]

At a hard length, if the construction uses the stable solver branch, the first part
contradicts (232.3).  If it uses the reconstruction branch, (232.5) contradicts
(232.6).  Since Theorem 4.5 supplies infinitely many hard lengths, no such
address-scale finite common strategy can exist under \(P=NP\).

Equivalently, a proof of a uniform address-scale common strategy for the actual RW
failure branch would turn the existing near-maximum hard-table theorem into a
\(P\ne NP\) proof.  Conversely, if \(P=NP\) is consistent with the current RW theorem,
the remaining hard lengths must use an object-scale descriptor/control circuit or a
strategy outside the finite common-response model.

## Boundaries

* The theorem uses the near-maximum hard-table conclusion of RW Theorem 4.5, not merely
  \(H_N\notin\operatorname{Range}(G)\).
* The solver-branch argument uses \(P=NP\) only on the stable tail.  It does not claim
  that early \(BF_i\) stages are polynomial in their current table length.
* The reconstruction conclusion concerns one common finite strategy and one address
  space.  Different strategies per address, unbounded interaction, or a new global PCP
  coupling are not covered.
* Therefore (232.2) is a closure dilemma, not yet an unconditional \(P\ne NP\) proof.
  The remaining top-level target is to show that the non-finite/non-common escape itself
  implies patchability, RLDC/LDC cost, or another general impossibility theorem.

## Source boundary

The source inputs are RW Theorem 4.3 (the \(A_0/A_1\) branch construction), Theorem 4.5
(infinitely many near-maximum hard AVOID tables), and Theorem 4.1 (the shared PCP proof
and the final-query promise gap).  The common-strategy expansion is note 231, based on
the sampling theorem in note 230.
