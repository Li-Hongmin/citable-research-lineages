> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK 首失败层的 frontier-support 下界（2026-08-19）

## 结论

设

\[
G:\{0,1\}^n\to\{0,1\}^{2n},
\qquad
f\in\{0,1\}^{T},
\qquad
k=\left\lceil\log_2(T/n)\right\rceil,
\]

并令 \(T'=n2^k\)、\(y_k=f0^{T'-T}\)。运行 Ren--Williams Theorem 3.1
的 Jeřábek--Korten 过程。若过程首次在 stage \(i\in[k]\) 返回 non-range block，
则完整失败层 \(y_i\) 满足 \(|y_i|=n2^i\)，并且

\[
\operatorname{CC}(f)
\le
O\!\left(
n2^i+(k-i)(|G|+n)+\log(T+2)
\right).
\tag{488.1}
\]

因此，若 \(\operatorname{CC}(f)\ge S\)，则

\[
n2^i+(k-i)(|G|+n)+\log(T+2)=\Omega(S).
\tag{488.2}
\]

特别地，当

\[
(k-i)(|G|+n)+\log(T+2)=o(S),
\]

首失败 frontier 必须满足

\[
|y_i|=n2^i=\Omega(S),
\qquad
i\ge \log_2(S/n)-O(1).
\tag{488.3}
\]

这给出 successful AVOID branch 的 source-derived joint relation：完整 \(y_i\) 的确
精确决定顶层 \(f\)，但它必须支付 frontier support。它不是一个免费的
non-half-lift global invariant。

## 证明

Theorem 3.1 从 \(y_k\) 开始向下运行。对每个已经通过 range test 的
stage \(j\in\{k,k-1,\ldots,i+1\}\)，把

\[
y_j=Z_{j,1}\Vert\cdots\Vert Z_{j,2^{j-1}},
\qquad |Z_{j,r}|=2n,
\]

并令

\[
x_{j,r}
=
\operatorname{lexmin}\{x\in\{0,1\}^n:G(x)=Z_{j,r}\}.
\]

算法定义

\[
y_{j-1}=x_{j,1}\Vert\cdots\Vert x_{j,2^{j-1}}.
\tag{488.4}
\]

故对每个 \(j>i\)，都有精确恒等式

\[
y_j
=
G(x_{j,1})\Vert\cdots\Vert G(x_{j,2^{j-1}})
=:G^{\oplus 2^{j-1}}(y_{j-1}).
\tag{488.5}
\]

lexicographic tie-break 只使 \(y_i\) canonical；由 \(y_i\) 向上恢复 \(y_k\) 只用
(488.5)。

给定顶层地址 \(a\in[T]\)，把相应的 \(n\)-bit chunk index 写成

\[
c=c_{\rm base}\Vert\epsilon_{i+1}\cdots\epsilon_k,
\qquad c_{\rm base}\in\{0,1\}^{i}.
\]

先用一个 hardwired multiplexer 从 \(y_i\) 的 \(2^i\) 个 \(n\)-bit chunks 中取出
\(c_{\rm base}\) 指定的 seed；成本为 \(O(n2^i)\)。随后对
\(j=i+1,\ldots,k\)，计算一次 \(G\)，并按 \(\epsilon_j\) 选择输出的左或右
\(n\)-bit half。每层成本为 \(O(|G|+n)\)。最后输出 \(a\) 指定的 bit；padding
截断和地址算术成本为 \(O(\log(T+2))\)。所得 fan-in-two circuit 计算 \(f\)，
从而得到 (488.1)--(488.3)。

关键是单个地址只沿一条 forward half-chain。若把全部 frontier 在每层完全展开，
会产生不必要的 object-scale 过计。

## systematic hard-parent 推论

设 JK 的顶层输入是一个 canonical proof \(\Pi\in\{0,1\}^{T}\)，且同一个 hard word
\(B\in\{0,1\}^{b}\) 有一个大小为 \(s_{\rm out}\) 的固定地址映射

\[
\Pi[\iota(a)]=B[a]
\qquad(a\in[b]).
\tag{488.6}
\]

将 (488.1) 的 \(\Pi\)-evaluator 与 \(\iota\) 复合，得到

\[
\operatorname{CC}(B)
\le
O\!\left(
n2^i+(k-i)(|G|+n)+s_{\rm out}+\log(T+2)
\right).
\tag{488.7}
\]

因此 C455 的 forcing 只能在另已证明 (488.6) 指向**同一个** C455 hard object、
同一 hard-length 集合时代入。C456 给出一个 source-aligned machine/serialization；
它不把任意 actual Solve 调用的 parent 自动等同于 C455 的 \(B_n\)。

## 对 successful-AVOID joint relation 的裁决

Ren--Williams Theorems 3.1/4.1 的 actual recursion 给出以下穷尽的已发表接口：

1. **returned outsider/path：** 一次成功调用只返回一个 \(2n\)-bit non-range block；
   canonical half-lift 受 C417 的 shared-DAG 电路代价约束。
2. **完整失败 frontier：** \(y_i\) 通过 (488.5) 精确恢复顶层，但由 (488.1)
   支付 \(n2^i\) support；在 C471 的 finite-ROM 模型中可取 \(2^i\) 个 \(n\)-bit
   symbols。
3. **index/control：** stage、failure index、path 与 fixed control 只决定位置，
   不决定 non-range block payload，必须计入 descriptor/control。

多次调用可以共享同一个 canonical \(\Pi\)，但源文没有给出不同 generators/calls
之间的 outsider coupling equation。故仅由 actual lex-first recursion 不能得到一个
同时满足 exact whole-word binding、address-scale cost 且逃离 C417/C471 的 joint
relation。

这是一项有范围的 source-route closure，不排除另行提出并证明的 non-half-lift
global relation。若 evaluator 使用未计价 unit-cost oracle、地址依赖 physical proof
或非单值关系，则它退出本定理与 C471 的 operational access 模型，而不是反驳
(488.1)。

## 与 C487 的关系

C487 的三分是 C372、C450 与 C471 的分类性推论；其 forcing 支只能在 parent 已另证
为同一个 hard object 时使用。C488 不依赖该分类，而是从 Theorem 3.1 的 actual
stage recursion 导出新的 quantitative frontier bound (488.1)。

## 来源与边界

* Ren--Williams Theorem 3.1：\(y_k=f0^{T'-T}\)、逐层 lexicographically first
  preimages、首个 non-range block 与 easy circuit。
* Ren--Williams Theorem 4.1：\(\operatorname{Solve}_f(x,G)\) 对 canonical
  \(\Pi_x\) 直接调用 Theorem 3.1；success 只返回一个 outsider。
* C372：success child 不自动绑定 parent。
* C416--C417：prefix attachment 与 returned-outsider half-lift DAG payment。
* C471：same-proof finite-ROM support forcing。

本结果不证明 \(P\ne NP\)，不把任意 Solve parent 与 C455 hard word 对齐，也不排除
新的、被完整计价的 non-product global relation。
