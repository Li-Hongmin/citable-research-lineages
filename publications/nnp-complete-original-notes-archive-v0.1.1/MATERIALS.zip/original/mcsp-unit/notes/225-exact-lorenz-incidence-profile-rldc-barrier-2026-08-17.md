> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact Lorenz incidence profile gives a universal RLDC barrier (2026-08-17)

## Contribution

Note 224 bounds the corruption mass by a trimmed-core functional.  There is a
strictly sharper quantity: among all corruption sets of a fixed cardinality, the
largest possible incidence mass is exactly the sum of the largest incidences.
This turns arbitrary nonuniformity into an explicit Lorenz-profile obstruction.

The result is a general theorem about any common-proof coordinate-robust compiler.
It does not assume uniform marginals, linearity, or a particular dPCP construction.
It remains conditional on the common proof, exact-codeword safety, and honest-path
domination interfaces; it does not claim that RW or the current GMWZ theorem already
supplies those interfaces.

## Setup

Let

\[
  C:\{0,1\}^{k}\longrightarrow \Gamma^{M}
\]

be an injective outer code.  A single proof space \(V\), with alphabet \(\Sigma\),
supports a perfect-completeness assignment \(A_m\in\Sigma^V\) for each message
\(m\).  For every outer coordinate \(t\), the local dPCP decoder samples an edge
\(e\sim\mathcal P_t\), reads at most \(q_P\) proof symbols, and returns a symbol in
\(\Gamma\).  Thus

\[
  D_t(A_m|_e)=C(m)_t
  \qquad\text{for }e\sim\mathcal P_t\text{ almost surely}.
\tag{225.1}
\]

Let \(\mathcal Q\) first choose \(t\) uniformly and then choose
\(e\sim\mathcal P_t\).  Define

\[
  \mu_v:=\Pr_{(t,e)\sim\mathcal Q}[v\in e].
\tag{225.2}
\]

An outer decoder \(\mathsf{Dec}_i\) makes at most \(q_D\) adaptive local calls.
Assume:

1. **Exact-codeword safety.** If all local answers are the answers induced by
   \(A_m\), then \(\mathsf{Dec}_i\) never outputs a wrong message symbol.
2. **Honest-path domination.** At every step, conditioned on preceding local answers
   being honest,
   \[
     \Pr[v\in e\mid\text{preceding answers honest}]
       \le \lambda\mu_v.
   \tag{225.3}
   \]

The proof corruption radius is denoted by \(\rho_{\mathrm{pf}}\), to keep it
distinct from the outer code and from RLDC soundness.

## Exact Lorenz profile

Write the incidences in decreasing order
\(\mu_{(1)}\ge\cdots\ge\mu_{|V|}\), and put

\[
  r_{\mathrm{pf}}:=\min\{\lfloor\rho_{\mathrm{pf}}|V|\rfloor,|V|\},
  \qquad
  \mathcal L_{\rho_{\mathrm{pf}}}(\mu)
    :=\sum_{j=1}^{r_{\mathrm{pf}}}\mu_{(j)}.
\tag{225.4}
\]

Equivalently,

\[
  \mathcal L_{\rho_{\mathrm{pf}}}(\mu)
   =\max\{\mu(B):B\subseteq V,\ |B|\le\rho_{\mathrm{pf}}|V|\}.
\tag{225.5}
\]

Equation (225.5) is just the rearrangement inequality, but it is the exact
incidence quantity relevant to worst-case Hamming corruption.

## Theorem (Lorenz-profile RLDC closure)

Under (225.1)--(225.3), the full proof map

\[
  \Pi:\{0,1\}^{k}\to\Sigma^V,\qquad \Pi(m):=A_m,
\]

is a weak adaptive

\[
  (Q,\rho_{\mathrm{pf}},1,s_{\mathrm{L}})\text{-RLDC},
  \qquad Q:=q_Pq_D,
\tag{225.6}
\]

with

\[
  s_{\mathrm{L}}
  \le \min\left\{1,\ q_D\lambda\,
  \mathcal L_{\rho_{\mathrm{pf}}}(\mu)\right\}.
\tag{225.7}
\]

In particular, any common-proof coordinate-robust compiler whose proof-incidence
Lorenz mass is small is automatically an RLDC, even when its incidence is maximally
nonuniform.

### Proof

Fix \(m,i\), and a received proof \(z\) with
\(\operatorname{dist}(z,A_m)\le\rho_{\mathrm{pf}}\).  Let

\[
  B:=\{v:z_v\ne A_m(v)\}.
\]

Then \(|B|\le r_{\mathrm{pf}}\).  On any honest-path step, (225.3) and a union
bound give

\[
 \Pr[e\cap B\ne\varnothing\mid\text{preceding answers honest}]
 \le\lambda\mu(B).
\tag{225.8}
\]

If none of the at most \(q_D\) queried edges meets \(B\), every local answer equals
the answer induced by \(A_m\).  Exact-codeword safety then forces the outer decoder to
output \(m_i\), so a wrong output can occur only after a query edge hits \(B\).
Another union bound gives

\[
  \Pr[\mathsf{Dec}_i^z\notin\{m_i,\bot\}]
  \le q_D\lambda\mu(B)
  \le q_D\lambda\mathcal L_{\rho_{\mathrm{pf}}}(\mu).
\tag{225.9}
\]

On \(z=A_m\), perfect completeness is immediate.  Finally, if \(m\ne m'\), let
\(S=\{t:C(m)_t\ne C(m')_t\}\).  For every \(t\in S\), every complete edge must
meet
\(D_{m,m'}:=\{v:A_m(v)\ne A_{m'}(v)\}\); otherwise the same local view would be
required to decode two different symbols.  Hence \(D_{m,m'}\ne\varnothing\), so
\(\Pi\) is injective.  This proves (225.6)--(225.7). \(\square\)

## Nonadaptive lower-bound consequence

Suppose the outer coordinate and edge choices are nonadaptive, so the induced proof
decoder is nonadaptive.  Let \(\eta\in(0,1]\).  If

\[
  q_D\lambda\mathcal L_{\rho_{\mathrm{pf}}}(\mu)\le 1-\eta
\tag{225.10}
\]

and

\[
  \rho_{\mathrm{pf}}>|V|^{-\eta/(2Q)},
\tag{225.11}
\]

then the robust-daisy lower bound of Goldberg--Gur--Saraogi gives

\[
 |V|
 \ge
 \left(
 \frac{\eta^2 k}
 {38Q^4\log^2|\Sigma|\,\log^2 k}
 \right)^{1+\frac{1}{\lceil Q/\eta\rceil}}.
\tag{225.12}
\]

Consequently, for fixed \(Q,\eta,\rho_{\mathrm{pf}},|\Sigma|\), any proposed
near-linear common-proof construction below the right-hand side of (225.12) must
obey the necessary condition

\[
  \mathcal L_{\rho_{\mathrm{pf}}}(\mu)
   >\frac{1-\eta}{q_D\lambda}.
\tag{225.13}
\]

This is an incidence-profile lower bound, not an assumption of uniform marginality:
the proof must expose enough mass on the top \(\rho_{\mathrm{pf}}|V|\) positions, or
pay the RLDC length exponent.

The cited theorem is stated for arbitrary query-set distributions in the
nonadaptive RLDC model and gives the explicit bound (225.12); it is not being
reinterpreted as an adaptive lower bound.

## Adaptive low-soundness consequence

For adaptive outer decoders, if the stronger condition

\[
  q_D\lambda\mathcal L_{\rho_{\mathrm{pf}}}(\mu)<2^{-Q},
\tag{225.14}
\]

holds, the nonlinear RLDC-to-LDC theorem of Cheng--Li--Mao applies directly to
(225.6).  For every

\[
  0<r<
  \frac{\rho_{\mathrm{pf}}}{2Q}
  \left(1-2^Q q_D\lambda\mathcal L_{\rho_{\mathrm{pf}}}(\mu)\right),
\tag{225.15}
\]

the same proof map admits a nonadaptive \(Q\)-query LDC decoder.  Thus the adaptive
route also cannot hide a sufficiently small Lorenz profile; it only has the
exponential-in-\(Q\) soundness window.

## Relation to the trimmed profile

The profile in note 224 satisfies

\[
  \mathcal L_{\rho_{\mathrm{pf}}}(\mu)
  \le
  \mathfrak R_{\rho_{\mathrm{pf}}}(\mu)
  :=
  \min_K\left(\mu(K)+\rho_{\mathrm{pf}}|V|
  \max_{v\notin K}\mu_v\right),
\tag{225.16}
\]

but the inequality can be strict.  Therefore (225.7) is the exact worst-case
incidence bound, while (224.5) remains useful only when one wants to display a
heavy-core/residual-smoothness tradeoff.  The new theorem should be used as the
primary RLDC closure statement; the trimmed formulation is a structural refinement.

## Boundary

The theorem does not assert that a current GMWZ dPCP supplies a common proof for a
distance-separated message family, exact-codeword safety for an outer message decoder,
or the honest-path domination (225.3).  It also does not turn adaptive RLDC lower bounds
into nonadaptive ones.  If the top-\(\rho_{\mathrm{pf}}\) incidence mass is large, this
barrier is silent; that is a real escape parameter, not a proof artifact.

## Sources

* [Goldberg--Gur--Saraogi, Theorem 1](https://arxiv.org/html/2511.21659), for the
  arbitrary-distribution nonadaptive RLDC length lower bound.
* [Cheng--Li--Mao, Theorem 1.4](https://arxiv.org/html/2603.03717), for the
  low-soundness adaptive RLDC-to-LDC transformation.
* [Trimmed-incidence full-proof closure](224-trimmed-incidence-profile-full-proof-rldc-closure-2026-08-17.md),
  for the structural predecessor and heavy-core interpretation.
