> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Conditional-independence entropy barrier for global-word closure

## Setup

Let \(\mathcal Y\subseteq\Gamma^M\) be a valid global-word family, with
\(|\Gamma|=Q\), minimum distance \(d\), and
\[
 V_Q(M,t)=\sum_{\ell=0}^{t}\binom M\ell(Q-1)^\ell.
\]
Let \(S\) be an arbitrary policy, public-randomness, or Merlin-strategy variable.
Conditioned on \(S=s\), suppose the coordinate outputs \(Z_1,\ldots,Z_M\)
are independent (their conditional distributions may depend on \(s\) and \(j\)).

For each \(s,j\), define conditional min-entropy
\[
 h_j(s):=H_\infty(Z_j\mid S=s)
 =-\log_2\max_{a\in\Gamma}\Pr[Z_j=a\mid S=s],
\qquad
 h(s):=\sum_{j=1}^M h_j(s).
\]
Let \(A_t=\{z:\min_{y\in\mathcal Y}d_H(z,y)\le t\}\).

## Theorem 1 (conditional product entropy barrier)

If \(h(s)\ge H\) for every \(s\) in a set of policy mass at least
\(1-\delta\), then
\[
 \Pr[Z\in A_t]
 \le
 \delta+(1-\delta)|\mathcal Y|V_Q(M,t)2^{-H}.
 \tag{1}
\]
Using the Singleton bound,
\[
 \Pr[Z\in A_t]
 \le
 \delta+(1-\delta)Q^{M-d+1}V_Q(M,t)2^{-H}.
 \tag{2}
\]

### Proof

Fix \(s\) in the good policy set. Conditional independence and the definition of
min-entropy imply that every vector \(z\in\Gamma^M\) has probability at most
\(2^{-h(s)}\le2^{-H}\). The set \(A_t\) is contained in the union of
\(|\mathcal Y|\) Hamming balls, each of size at most \(V_Q(M,t)\), so
\[
 \Pr[Z\in A_t\mid S=s]\le|\mathcal Y|V_Q(M,t)2^{-H}.
\]
Average over good and bad policies and use the trivial bound \(1\) on the bad
set. The Singleton bound gives (2). \(\square\)

## Corollary 2 (linear conditional information must collapse)

Assume full coordinate projections, relative distance \(\Delta=d/M\), and
\(t=\lfloor\varepsilon M\rfloor\) with
\(\Delta>H_Q(\varepsilon)\). If
\[
 h(s)\ge M\bigl(\log_2 Q-\kappa\bigr)
\]
on all but a \(\delta\)-fraction of policies, then
\[
 \Pr[Z\in A_t]
 \le
 \delta+
 2^{-\;M\left(\Delta\log_2 Q
 -H_Q(\varepsilon)\log_2 Q-\kappa\right)+O_Q(1)}.
 \tag{3}
\]
Consequently, any constant-success construction with conditionally independent
coordinate responses must have, on a non-negligible policy mass, a conditional
min-entropy deficit
\[
 \sum_j\bigl(\log_2 Q-h_j(s)\bigr)
 \ge
 M\bigl(\Delta-H_Q(\varepsilon)\bigr)\log_2 Q-O_Q(1).
 \tag{4}
\]
The same seed must therefore determine a linear amount of coordinate content in
the high-distance/small-radius regime.

## Scope

The theorem covers product responses conditional on a common policy or random tape.
It does not apply when the coordinate responses remain jointly correlated after
conditioning on \(S\); such residual correlation is exactly the additional global
coupling that a stronger construction would have to provide. It also does not turn
the min-entropy deficit directly into a lower bound on \(|S|\): a short seed can
deterministically generate a long correlated word. The theorem instead identifies
the necessary semantic event: successful same-seed closure must collapse conditional
coordinate entropy, not merely rename independent local witnesses.
