> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact random-access source-probe barrier (2026-08-24)

## Theorem

Let \(A_n=\mathcal L_{\mu_H,n}\subseteq\{0,1\}^N\), \(N=2^n\), with
\(0<\mu_H<1\) and \(S=N^{\mu_H}\). Consider a deterministic exact procedure whose only
dependence on the source table \(f\) is through bit probes
\[
\operatorname{read}(i)\longmapsto f_i,\qquad i\in[N].
\]
The procedure may have arbitrary deterministic work computation and may query any fixed
source-independent auxiliary oracle \(O\). Let \(u_N\) be the maximum number of source probes
on one run (counting repetitions only increases \(u_N\)). If the procedure decides \(A_n\)
exactly, then
\[
\boxed{
u_N\ge N-\log_2|A_n|.
}
\]
Using circuit enumeration,
\[
\log_2|A_n|=O(S\log S)=o(N),
\]
so
\[
\boxed{u_N\ge N-o(N).}
\]

## Proof

Unroll the deterministic procedure into its source-query decision tree. Fix an accepting leaf
\(\ell\), which exists because the zero function belongs to \(A_n\). Let \(I_\ell\subseteq[N]\)
be the set of distinct source coordinates queried along the path to \(\ell\), and let
\(a_\ell\in\{0,1\}^{I_\ell}\) be the observed values. Every completion
\(x\in\{0,1\}^N\) satisfying \(x|_{I_\ell}=a_\ell\) produces the same source answers,
the same fixed-oracle answers, and hence the same deterministic path to \(\ell\). Thus the
entire subcube
\[
C_\ell=\{x\in\{0,1\}^N:x|_{I_\ell}=a_\ell\}
\]
is accepted. Exactness gives \(C_\ell\subseteq A_n\), while
\[
|C_\ell|=2^{N-|I_\ell|}.
\]
Therefore \(N-|I_\ell|\le\log_2|A_n|\), so
\(|I_\ell|\ge N-\log_2|A_n|\). Since \(|I_\ell|\le u_N\), the claim follows.

## Quotient/evaluator consequence

Suppose a target quotient, evaluator, and target decider compose into a deterministic exact
source procedure and every source-dependent operation is a bit probe to the original table.
Then the total number of source probes in the composed run is at least \(N-o(N)\), regardless
of target range size, target random access, or fixed auxiliary-oracle computation.

This closes every genuinely sublinear source-probe implementation of an exact MCSP quotient.
It does not yield the \(2\mu_H\) time exponent: \(N-o(N)\) is a near-linear probe bound, and a
full scan is compatible with the surviving \(N^{1.01}\)-time scale.

## Quantifier boundary

The auxiliary oracle must be fixed before the source input and independent of \(f\):
\[
\exists O\ \forall f.
\]
If the oracle is \(O_f\), or if an evaluator may read \(f\) through an uncharged hidden RAM,
the subcube argument fails. Indeed, a one-bit source-dependent oracle
\(O_f(\epsilon)=1_{A_n}(f)\) decides any predicate with one query. The bounded-error randomized
extension is handled separately by [note 519](519-bounded-error-source-probe-boundary-2026-08-24.md);
zero-error procedures are covered after fixing their coins.

## Source

The only counting input is the standard circuit enumeration bound for
\(\mathcal L_{\mu_H,n}\), already used in the MCSP paper's semantic-entropy theorem.
