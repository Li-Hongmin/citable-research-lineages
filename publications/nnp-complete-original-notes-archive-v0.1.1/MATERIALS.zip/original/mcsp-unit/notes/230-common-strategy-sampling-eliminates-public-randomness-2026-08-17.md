> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Common-strategy sampling eliminates the public-randomness escape (2026-08-17)

## Contribution

The full-transcript expansion in note 229 enumerates every public random tape.  For one
finite target word this is unnecessary.  If one short strategy is valid for every address
with a fixed completeness/soundness gap, a small nonuniform sample of public tapes
simultaneously separates all addresses.  The resulting circuit is polynomial in the
address length and is independent of the original randomness length.

This is the sharper Closure Gate statement:

> high public randomness is not a valid escape from \(P/\mathrm{poly}\) once the same
> succinct strategy serves all addresses.

The only remaining strategy escape is therefore a large common response evaluator, a
different strategy for different addresses, or a gap that vanishes too quickly.

## Theorem (uniform-sample closure for one common strategy)

Let \(H_n\in\{0,1\}^{N_n}\), with
\(\ell_n=\lceil\log_2N_n\rceil\).  Let \(R\) be any public random string, possibly of
length \(r_n\).  Suppose there is one strategy \(\mathcal S_n\) used for every address
\(a\in[N_n]\), and a deterministic verifier \(V_n\) such that

\[
  p_a:=
  \Pr_R\!\left[
    V_n(a,\sigma_n,R,\mathcal S_n(a,R))=1
  \right]
\]

satisfies

\[
  H_n[a]=1\Longrightarrow p_a\ge\alpha,
  \qquad
  H_n[a]=0\Longrightarrow p_a\le\beta,
  \qquad
  \alpha-\beta\ge\gamma>0.
\tag{230.1}
\]

Assume the verifier and the common strategy have a fan-in-two implementation of size
\(u_n\), including the descriptor \(\sigma_n\), and that one evaluation on
\((a,R)\) produces the complete finite transcript and acceptance bit.  Then there exists a
multiset of

\[
  t_n=
  O\!\left(
    \frac{\ell_n+\log(1/\delta)}{\gamma^2}
  \right)
\tag{230.2}
\]

public random strings \(R_1,\ldots,R_{t_n}\) such that the deterministic circuit

\[
  C_n(a)=
  \mathbf 1\!\left[
    \frac1{t_n}\sum_{j=1}^{t_n}
    V_n(a,\sigma_n,R_j,\mathcal S_n(a,R_j))
    >
    \frac{\alpha+\beta}{2}
  \right]
\tag{230.3}
\]

computes \(H_n\) on every address, and

\[
  \operatorname{CC}(H_n)
  \le
  O\!\left(
    t_n\,\operatorname{poly}(u_n,\ell_n,\log(1/\gamma))
  \right).
\tag{230.4}
\]

The random strings \(R_j\), the descriptor, and any finite strategy constants are
nonuniform advice for this circuit; no algorithm is claimed to find the sample set
uniformly.

### Static transcript-table special case

If \(\mathcal S_n\) is a common transcript table \(\tau_R\) independent of the address,
and each transcript has length at most \(L_n\), then one may hardwire only
\(\tau_{R_1},\ldots,\tau_{R_{t_n}}\).  In this case (230.4) becomes

\[
  \operatorname{CC}(H_n)
  \le
  O\!\left(
    \frac{\ell_n+\log(1/\delta)}{\gamma^2}
    \operatorname{poly}(p_n,L_n,d_n,\ell_n,\log(1/\gamma))
  \right).
\tag{230.5}
\]

No factor \(2^{r_n}\) appears.

### Sampled-ROM variant

Suppose the common strategy/evaluator has a static descriptor
\(\sigma_n\in\{0,1\}^{d_n}\), a fan-in-two control circuit of size \(p_n\), and at most
\(b_n\) arbitrary bit-reads from the descriptor on one address/random-tape execution.
After selecting the sample tapes in (230.2), expand each read into a
\(d_n\)-input multiplexer and hardwire \(\sigma_n\).  Then

\[
  \operatorname{CC}(H_n)
  \le
  O\!\left(
    \frac{\ell_n+\log(1/\delta)}{\gamma^2}
    \bigl(p_n+b_nd_n+\ell_n\bigr)^{O(1)}
  \right).
\tag{230.7}
\]

Consequently every forcing family with \(\operatorname{CC}(H_n)>S_n\) satisfies the
descriptor lower bound

\[
  d_n
  =
  \Omega\!\left(
    \frac{\gamma^2 S_n}
    {(\ell_n+\log(1/\delta))\,b_n}
  \right)
\]

whenever the control-size term is smaller than \(S_n\).  The exponent hidden in the
polynomial of (230.7) depends on the circuit model; the clean linear form above is the
straight-line ROM case.  In either model, a polynomial-size descriptor is impossible at
near-maximum forcing scale when \(p_n,b_n,\gamma^{-1}\) are polynomial in the address
length.

## Proof

For a fixed address \(a\), draw \(R_1,\ldots,R_t\) independently from the public
randomness distribution and let \(Y_j(a)\) be the corresponding acceptance bit under
\(\mathcal S_n\).  Hoeffding's inequality gives

\[
  \Pr\!\left[
    \left|\frac1t\sum_jY_j(a)-p_a\right|>\gamma/3
  \right]
  \le 2e^{-2t\gamma^2/9}.
\]

Choose the constant in (230.2) large enough that this failure probability is at most
\(\delta/N_n\).  A union bound over all \(N_n\) addresses shows that a single multiset
\((R_1,\ldots,R_t)\) simultaneously estimates every \(p_a\) within \(\gamma/3\).
For that multiset, the threshold \((\alpha+\beta)/2\) separates the two cases in (230.1).
Hardwiring the sample tapes and unrolling the \(t_n\) evaluations gives (230.4).
\(\square\)

## Corollary (forcing-scale consequence)

Suppose the same canonical object satisfies

\[
  \operatorname{CC}(H_n)>S_n
\]

on an infinite set of lengths.  If
\[
  u_n,\ \gamma^{-1},\ \ell_n= n^{O(1)}
\]
and the common strategy is address-parametrized by that \(u_n\)-size implementation, then

\[
  S_n
  \le
  n^{O(1)}\bigl(\ell_n+\log(1/\delta)\bigr)\gamma^{-2}.
\tag{230.6}
\]

Consequently, a forcing scale \(S_n=n^{\omega(1)}\) rules out every
\(n^{O(1)}\)-size common strategy with constant gap, regardless of how many public random
bits it uses.  This is a stronger closure barrier than the full-enumeration inequality
in note 229.

## RW interpretation

At a stable RW stage the forced AVOID table is indexed by
\(m_i=\lceil\log_2(2n_i)\rceil\) bits.  If the canonical PCP/strategy, the verifier, and
the address response evaluator could all be compressed to \(m_i^{O(1)}\), then (230.5)
would give an \(m_i^{O(1)}\)-size circuit for the near-maximum hard table, even if the
original Reconf query used \(2^{\Theta(m_i)}\) or larger public randomness.  Therefore
randomness reduction is not the right standalone target.  The real missing object is a
short *common address-parametrized strategy/evaluator* for the same canonical history.

For the published RW Reconf, the Merlin witness is a gate-list circuit of size
\(O(k_i^4\log T_i)\), with \(k_i=n_{i+1}=2^{\Theta(m_i)}\) on the stable tail.  This
does not satisfy the \(m_i^{O(1)}\) premise of the corollary.  The theorem therefore
does not claim a contradiction from the existing result; it identifies exactly what a
new RW-specific compression theorem must provide.

## Boundaries

1. **Different strategies per address.**  If the response circuit is
   \(\mathcal S_{n,a}\) with no common short implementation, the union bound only yields
   an \(N_n\)-indexed strategy table.  This is target-specific history information, not
   whole-word consistency.
2. **Vanishing gap.**  If \(\gamma\) is smaller than every inverse polynomial in the
   address length, (230.2) may cease to be polynomial; this is a genuine quantitative
   escape.
3. **Unbounded/non-finite strategy.**  A strategy with no finite succinct evaluator is
   outside the theorem and must be handled by a separate communication or coding lower
   bound.
4. **Uniformity.**  The sample tapes may be hardwired, so the conclusion is
   \(P/\mathrm{poly}\), not necessarily uniform \(P\).

## Relation to prior closure notes

* Note 229 gives a full-enumeration transcript expansion; (230.5) is its
  finite-address sampling refinement.
* Note 228 supplies the complementary branch: if patches are realizable, exact hitting
  yields the RLDC route.
* Note 204 supplies the final forcing contradiction once (230.4) is at address scale.

The theorem is self-contained and does not claim that RW, GMWZ, or any current dPCP
construction has the required short common strategy.  Its new conclusion is that a
finite public-coin strategy cannot be the missing Closure Gate by itself: it must also
carry an object-scale common response description, or the proposed reconstruction already
falls into \(P/\mathrm{poly}\).  Equation (230.7) makes the same conclusion quantitative
for random-access descriptors rather than only finite transcript circuits.
