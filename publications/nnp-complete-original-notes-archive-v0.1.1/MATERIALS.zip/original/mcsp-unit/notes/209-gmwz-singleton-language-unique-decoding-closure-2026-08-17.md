> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# GMWZ 直接积放大的 singleton-language 唯一解码闭合（2026-08-17）

## 结论

Gur--Minzer--Weissenberg--Zheng（GMWZ）Section 6 的直接积放大通常只给
list-decoding soundness，因为 Lemma 6.2 为一个近满足左表产生多个簇函数
\(f_j\)，而底层 unique decoding 只把每个 \(f_j\) 解释为某个词
\(w_j\in\mathcal L\)。但若底层合法词族是 singleton

\[
\mathcal L=\{w^\star\}\subseteq\Sigma_0^n,
\]

则所有 \(w_j\) 自动等于同一个 \(w^\star\)。因此 GMWZ 的 list-soundness
证明在这一特例中直接闭合为同一 global word 的 distributional/unique-decoding
保证；不需要额外假设簇间 decoder disagreement、shared-top marginal transfer，或
选择某个簇作为目标。

这是一条 source-specific composition corollary，不是新的 dPCP 构造，也不表示
当前 RW 的私有 witness 关系已经具有 singleton-output 编译。

## 定理（singleton-language specialization）

设 \(\mathcal D_{\mathrm{ud}}\) 是一个 perfect-complete udPCP，合法解码词族为
\(\mathcal L=\{w^\star\}\)。设其 unique-decoding soundness 在基系统中足以使
GMWZ Section 6 的参数选择成立。对任意目标 list-soundness 参数
\(\varepsilon>0\)，令 \(\mathcal D_{\mathrm{dp}}=\operatorname{DP}_\varepsilon
(\mathcal D_{\mathrm{ud}})\) 为 GMWZ Theorem 6.1 的直接积放大系统。

则：

1. \(\mathcal D_{\mathrm{dp}}\) 保留 GMWZ Theorem 6.1 的 proof length、alphabet、
   degree、decision/decoding complexity 与 perfect completeness 参数；
2. 对任意候选放大 assignment \(T\)，若
   \(\operatorname{viol}_{\mathrm{dp}}(T)\) 是放大系统的约束违反率，则
   \[
   \Pr_{(t,a,b)\sim\mathcal Q_{\mathrm{dp}}}
   [\Phi_{\mathrm{dp}}(T;a,b)=1\ \wedge\
     D^{\mathrm{dp}}_t(a,T[a])\ne w^\star_t]
   \le \varepsilon;
   \tag{209.1}
   \]
3. 因而
   \[
   \Pr_{(t,a,b)\sim\mathcal Q_{\mathrm{dp}}}
   [D^{\mathrm{dp}}_t(a,T[a])\ne w^\star_t]
   \le \varepsilon+\operatorname{viol}_{\mathrm{dp}}(T).
   \tag{209.2}
   \]
   特别地，若放大 assignment 的违反率至多 \(\sigma\)，则它由同一个固定词
   \(w^\star\) 以误差至多 \(\varepsilon+\sigma\) 解释。选择
   \(\varepsilon+\sigma\le\eta_{\mathrm{out}}\) 即得到
   \((\sigma,\eta_{\mathrm{out}})\) 的 singleton unique-decoding 保证。

这里的“同一个词”是解码语义上的 global word：不同候选 assignment 仍可有不同的
proof/table。定理不声称 proof assignment 唯一。

## 证明

GMWZ Lemma 6.2 从任意近满足左 assignment 中抽取不交的重簇
\(\mathcal U_1,\ldots,\mathcal U_J\) 及函数
\(f_j:X(1)\to\Sigma\)。GMWZ Lemma 6.4 与底层 udPCP 的 unique-decoding soundness
给出每个 \(j\) 的词 \(w_j\in\mathcal L\)，并控制

\[
\Pr_{(t,u)\sim\mathcal Q_{\mathrm{ud}}}
  [D^{\mathrm{ud}}_t(u,f_j(u))\ne (w_j)_t]
\le \eta_{\mathrm{cl}},
\tag{209.3}
\]

其中 \(\eta_{\mathrm{cl}}\) 是 GMWZ 参数选择中的 cluster decoding error（在其
展示中为 \(5\sqrt\delta\) 量级）。由于 \(\mathcal L=\{w^\star\}\)，有
\(w_j=w^\star\) 对所有 \(j\)。

GMWZ Theorem 6.1 的 list-soundness 证明把放大 decoder 的错误事件与
\(\{(w_j)_t:j\in[J]\}\) 的列表外事件比较，并把不在重簇并集中的部分由 Lemma 6.2
控制。因此在 singleton 情形

\[
\{(w_j)_t:j\in[J]\}=\{w^\star_t\},
\]

其列表外事件正好是 (209.1) 左侧的错误解码事件；Theorem 6.1 的同一
\(\varepsilon\) 上界遂给出 (209.1)。把错误解码事件分成“约束满足且解码错误”和
“约束不满足”两部分，得到 (209.2)。完备性仍由 GMWZ Section 6.1 对同一个诚实
assignment 的构造给出。证毕。

## 这条闭合真正消除了什么

它消除了一个此前被误认为必须独立证明的 Gate-II 子问题：在底层合法词族已经
singleton 时，不需要从 shared-top 采样器证明

\[
\rho_{ij}<\Delta-2\eta,\qquad
\xi_{ij}=o(1),
\]

也不需要为每个簇传输一个 target index。cover 或簇的局部表仍可能不同，但它们
只能近似同一个解码词 \(w^\star\)。

这与项目中的一般 cluster-synchronization criterion 不矛盾：后者处理的是
\(|\mathcal L|>1\) 的候选词族；singleton 假设直接把词间距/同步问题退化掉。

## 对 RW Closure 的精确边界

这条推论尚未接上 RW/JK，原因是 GMWZ Theorem 6.1 的输入是一个词语言（论文中
写作 \(\mathrm{SAT}(\varphi)\)），而 RW 需要的是带私有 witness 的关系

\[
R(x,y,w),\qquad
\mathcal L_x=\{y:\exists w\ R(x,y,w)\}.
\]

即使每个 \(x\) 的输出词 \(y\) 在语义上唯一，也不能把所有满足 assignment
\((y,w)\) 直接当成 singleton 语言输入；那会重新暴露 witness，并把地址/证明长度
带回 history 尺度。要把本定理用于 RW，仍需一个新的 **singleton-output relation
compiler**，同时满足：

* 对同一 \(x\) 固定 global proof/address space；
* 所有合法 assignment 的 target projection 都是同一个 \(y_x\)；
* compiler 在 \(\varepsilon=\Theta(1/\ell)\) 或等价的 coordinate-robust 参数下
  保持统一 proof 长度与局部生成时间；
* 输出 projection 不把完整私有 witness 重新放回每个坐标查询。

因此，当前路线的最窄正向目标从“解决 GMWZ 的跨簇同步”收窄为：

> 为 RW 的 relation \(R(x,y,w)\) 构造近线性、统一、singleton-output 的 base
> udPCP/PCPP；一旦这个接口存在，GMWZ Section 6 的 direct-product list-to-global
> obstruction 在语义层面自动闭合。

这仍然没有解决 RW 的 address-scale、bottom、descriptor 或 same-history Gate-I；
它只把 GMWZ 侧的同步缺口从“需要证明”降为“只需证明 singleton-output relation
compiler”。

## 来源与证据边界

GMWZ Theorem 6.1 给出 direct-product dPCP 的长度、完备性与 list-decoding
soundness；其证明中 Lemma 6.2 产生簇函数，随后 Lemma 6.4/底层 udPCP unique
decoding 为每个簇选择 \(w_j\in\mathcal L\)。本推论只是在
\(\mathcal L=\{w^\star\}\) 下把列表集合塌缩为 singleton；它不是 GMWZ 已声明的
“relation-PCP”或 RW theorem。

来源：[GMWZ Theorem 6.1 and Section 6](https://arxiv.org/html/2512.12960)。
