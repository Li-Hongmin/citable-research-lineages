> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Finite-alphabet one-query smoothness gives an exponential closure (2026-08-17)

## Result

The binary exponential lower bound for two-query Hamming RLDCs does not immediately extend
to larger alphabets.  A shared-proof interface has additional structure, however: the first
query is the binary inline claim bit, and a one-query proof branch uses only one Boolean
predicate of one proof symbol.  If those typed predicates are smooth over the proof positions,
the symbol can be expanded into all subset-membership predicates and the interface becomes a
binary two-query RLDC.

This gives an exponential barrier for a fixed finite proof alphabet under a precise
smoothness hypothesis.  It does not close the unrestricted larger-alphabet problem: a single
proof position can still carry a nonsmooth query peak, and the expansion below cannot protect
against corrupting that whole position at constant relative distance.

## Theorem

Fix a finite alphabet \(\Sigma\) with \(A=|\Sigma|\ge2\), constants
\(0<\rho<1\), \(\beta<1/2\), and \(\lambda\ge1\).  Let

\[
  \Pi:\{0,1\}^k\longrightarrow\Sigma^P
\]

be a proof map.  For every message coordinate \(i\) and claim \(b\in\{0,1\}\), let
\(V_{i,b}\) be a randomized verifier making at most one proof-symbol query.  A random tape
\(R\) that makes a query induces a typed query

\[
  t=(j,S),
  \qquad j\in[P],\quad S\subseteq\Sigma,
\]

where the branch accepts exactly when the queried symbol lies in \(S\).  Assume:

1. \(p_{i,m_i}(\Pi(m))=1\) for every \(m,i\);
2. if \(d_H(z,\Pi(m))\le\rho P\), then
   \(p_{i,1-m_i}(z)\le\beta\) for every \(m,i,z\);
3. for every \(i,b\) and typed query \(t=(j,S)\),
   \[
     \Pr_R[t=(j,S)]\le\frac{\lambda}{P}.
   \tag{243.1}
   \]

Then there is a constant \(\delta>0\), depending only on
\(A,\rho,\beta,\lambda\), such that the binary code obtained by expanding every proof symbol
has a weak adaptive \((2,\delta,\alpha)\)-RLDC with perfect completeness and
\(\alpha>1/2\).  Consequently, by the exponential two-query Hamming-RLDC lower bound,

\[
  k+2^A P\ge 2^{\Omega_{A,\rho,\beta,\lambda}(k)},
  \qquad
  P\ge 2^{\Omega_{A,\rho,\beta,\lambda}(k)}.
\tag{243.2}
\]

The same conclusion holds if the branch sometimes makes no proof query; (243.1) is imposed
only on the tapes that do query.

## Proof

For each \(a\in\Sigma\), define its binary subset-membership expansion

\[
  E(a)\in\{0,1\}^{2^A},
  \qquad E(a)_S=\mathbf 1[a\in S]
  \quad(S\subseteq\Sigma).
\tag{243.3}
\]

Define the binary code

\[
  \widetilde C(m)=m\,\|,E(\Pi(m)_1)\,\|\cdots\|,E(\Pi(m)_P),
  \qquad N'=k+2^A P.
\tag{243.4}
\]

The expansion separates symbols: if \(a\ne a'\), then
\(d_H(E(a),E(a'))=2^{A-1}\).  The original assumptions force the proof image to have
relative distance greater than \(\rho\): otherwise two messages differing at coordinate
\(i\) would make the correct branch for one message and the wrong branch for the other both
accept on the same nearby proof.  The \(A\)-ary Singleton bound therefore gives, for all
sufficiently large \(k\),

\[
  P\ge c_0 k,
  \qquad c_0=c_0(A,\rho)>0.
\tag{243.5}
\]

Thus the binary code in (243.4) also has a positive constant relative distance: distinct
proofs differ in more than \(\rho P\) blocks, each contributing \(2^{A-1}\) bits, while
\(N'/P\le 2^A+c_0^{-1}\).

The binary decoder on input \(i\) first reads the inline bit \(y_i\), calling it \(b\).
It then samples the original random tape for \(V_{i,b}\).  If that tape makes a typed query
\(t=(j,S)\), the decoder reads the single binary coordinate \((j,S)\) in the expanded proof
and outputs \(b\) exactly when that bit is one; otherwise it outputs \(\bot\).  A no-query
tape is simulated directly from its fixed acceptance decision.  Hence the decoder makes at
most two binary queries and agrees exactly with the original branch on an uncorrupted expanded
codeword.

Let \(y\) be within relative distance \(\delta\) of \(\widetilde C(m)\), and let \(E_y\) be
the set of corrupted proof bits.  If the inline bit is uncorrupted, the selected branch is
the correct branch and can output only \(m_i\) or \(\bot\).  If the inline bit is corrupted,
the selected branch is the wrong branch.  On an uncorrupted typed proof bit its behavior is
exactly the original wrong branch on \(\Pi(m)\), whose acceptance probability is at most
\(\beta\).  By (243.1), the probability that the typed query hits a corrupted proof bit is

\[
  \sum_{t\in E_y}\Pr_R[t]
  \le \frac{\lambda |E_y|}{P}
  \le \lambda\delta\frac{N'}{P}
  \le \lambda\delta(2^A+c_0^{-1}).
\tag{243.6}
\]

Consequently the probability of a wrong binary output is at most

\[
  \beta+\lambda\delta(2^A+c_0^{-1}).
\tag{243.7}
\]

Choose \(\delta>0\) small enough that
\(\lambda\delta(2^A+c_0^{-1})<(1/2-\beta)/2\), and also smaller than half the binary
relative distance.  Then the decoder succeeds with probability

\[
  \alpha\ge1-\beta-\lambda\delta(2^A+c_0^{-1})>1/2,
\]

while it has perfect completeness on every binary codeword.  This is a weak adaptive
two-query Hamming RLDC.  The exponential lower bound for such binary RLDCs gives
\(N'\ge2^{\Omega(k)}\).  Since \(A\) is fixed, (243.2) follows. \(\square\)

## Scope and escape

The typed smoothness condition is stronger than smoothness of the proof address alone only
in notation: a fixed proof position may be queried with several predicates, but every typed
query still has probability at most \(\lambda/P\).  The theorem uses no target-relative
soundness on corrupted expanded words; it uses that condition only to obtain proof-image
distance, then charges arbitrary binary corruption through (243.6).

Without (243.1), one proof position may carry a query peak of constant probability.  Corrupting
all (2^A) expansion bits of that one position costs only (O(1/P)) of the expanded word but
can change the verifier answer with constant probability.  Thus the reduction does not silently
prove the open unrestricted finite-alphabet two-query RLDC problem.  It proves a sharp route
split: a finite-alphabet one-proof-query shared-proof construction with near-linear length
must be nonsmooth, or must leave the perfect-completeness/target-relative interface.

## Sources

* A. R. Block, J. Blocki, K. Cheng, E. Grigorescu, X. Li, Y. Zheng, and M. Zhu,
  *Exponential Lower Bounds for 2-query Relaxed Locally Decodable Codes*,
  arXiv:2602.20278, Theorem 1: <https://arxiv.org/html/2602.20278>.
* The finite-alphabet shared-proof compiler is
  [note 241](241-constant-alphabet-adaptive-bottom-closure-2026-08-17.md).
