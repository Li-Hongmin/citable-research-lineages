> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Directed collision 势的平均 no-go

## 结论

在 \(X\cap Y=\varnothing\) 的 parity-KW 关系上，所有形如

\[
G_{T,s}(R)=\mathbf 1[s\in R]-\mathbf 1[T\subseteq R],
\qquad |T|=3,\ s\notin T,
\]

的非负加权和都不能给出超常数的 quasi-additive 对偶目标。这个结论与 \(T\cup\{s\}\) 是否为 odd--odd affine collision 无关；因此也适用于按 \(E_a\)、\(NO_b\)、电路描述长度或任何其它 MCSP 语义加权的 directed collision 族。

## 1. 叶模型（去除 \(b/t\) 重复参数）

固定方向 \(t=0\)，把仿射线性型写成

\[
\ell_{r,b}(z)=\langle r,z\rangle\oplus b,
\qquad (r,b)\in\mathbb F_2^N\times\mathbb F_2.
\]

对应的叶矩形为

\[
R_{r,b}
=
\{(x,y)\in X\times Y:
\ell_{r,b}(x)=0,\ \ell_{r,b}(y)=1\}.
\tag{1}
\]

允许方向 \(t=1\) 只会重复同一平均式：\((b,t)\mapsto(b\oplus1,t\oplus1)\) 给出相同矩形。因此证明只对 \(t=0\) 平均，不把 \(b\) 与 \(t\) 当成两个独立的 offset。

对任意 cell \(c=(x,y)\)，令 \(d=x\oplus y\ne0\)。条件 \(c\in R_{r,b}\) 等价于

\[
\langle r,d\rangle=1,\qquad
\langle r,x\rangle+b=0.
\]

这是 \((r,b)\) 上两个独立的仿射方程，所以

\[
\Pr_{r,b}[c\in R_{r,b}]=\frac14.
\tag{2}
\]

这里均匀平均取遍 \(2^{N+1}\) 个 affine forms；空叶也可纳入平均，因为其 \(\phi\)-和及所有 \(G_{T,s}\) 都为零。

## 2. 三 cell 同时命中的秩界

令 \(T=\{c_1,c_2,c_3\}\) 为三个不同 cell，写 \(c_i=(x_i,y_i)\)，
\(d_i=x_i\oplus y_i\)。每个 \(c_i\in R_{r,b}\) 给出两条线性方程，其系数向量为

\[
A_i=(d_i,0),\qquad B_i=(x_i,1)
\quad\text{在 }\mathbb F_2^{N+1}\text{ 中}.
\tag{3}
\]

每对 \(A_i,B_i\) 线性独立，因为 \(d_i\ne0\)，而 \(B_i\) 的最后坐标为 \(1\)。

**秩主张：** 若三 cell 的方程组一致，则其系数秩至少为 \(3\)。

事实上，若秩至多 \(2\)，则

\[
\operatorname{span}\{A_1,B_1\}
\]

同时包含 \(A_i,B_i\)。在该二维空间中，最后坐标为 \(0\) 的非零向量只有 \(A_1\)，故 \(A_i=A_1\)，即 \(d_i=d_1\)。最后坐标为 \(1\) 的向量只有 \(B_1\) 与 \(A_1+B_1\)，故

\[
x_i=x_1
\quad\text{或}\quad
x_i=x_1\oplus d_1=y_1.
\]

第一种给出 \(c_i=c_1\)；第二种给出 \(c_i=(y_1,x_1)\)。第二种不可能，因为 \(x_i\in X\)、\(y_1\in Y\) 而 \(X\cap Y=\varnothing\)。这与三个 cell 两两不同矛盾，秩主张成立。

于是

\[
\Pr[T\subseteq R_{r,b}]
\le 2^{-3}=\frac18.
\tag{4}
\]

若方程组不一致，概率为 \(0\)，所以 (4) 仍成立。

## 3. Directed \(G_{T,s}\) 的平均值

由 (2)、(4)，对任意 \(s\notin T\)，

\[
\mathbb E_{r,b}G_{T,s}(R_{r,b})
=
\Pr[s\in R_{r,b}]
-\Pr[T\subseteq R_{r,b}]
\ge\frac14-\frac18
=\frac18.
\tag{5}
\]

令 \(\mathcal I\) 为任意 directed triple--spoiler 族，取 \(\lambda_i\ge0\)，

\[
K(R)=\sum_{i\in\mathcal I}\lambda_iG_i(R),
\qquad
\Lambda=\sum_{i\in\mathcal I}\lambda_i.
\]

逐项应用 (5)：

\[
\mathbb E_{r,b}K(R_{r,b})\ge\frac{\Lambda}{8}.
\tag{6}
\]

## 4. 代入 quasi-additive leaf 约束

对任意非负 cell 权 \(\phi_c\ge0\)，若

\[
\sum_{c\in R}\phi_c+K(R)\le1
\qquad
(\forall\text{ parity-monochromatic }R),
\tag{7}
\]

则对所有 \(R_{r,b}\) 平均。令 \(\Phi=\sum_{c\in X\times Y}\phi_c\)，由 (2) 和 (6)：

\[
\frac{\Phi}{4}+\frac{\Lambda}{8}\le1.
\]

所以

\[
\boxed{\Phi\le4-\frac{\Lambda}{2}\le4.}
\tag{8}
\]

这已经排除了 \(N^{1.01}\)，甚至排除了任何随 \(N\) 增长的目标。

若 \(K\) 通过

\[
\psi_{c,R}=\frac{K(R)}{|C|-|R|}
\quad(c\notin R)
\]

嵌入 quasi-additive LP，则只要各 \(G_i\) 的组合满足递归超可加性，(7) 正是其 leaf 约束；(8) 直接适用。

## 5. 对 MCSP 语义的含义

令 \(X=E_a\)、\(Y=NO_b\)。证明只使用 \(X\cap Y=\varnothing\)，没有使用密度、汉明距离、\(NO_b\) 的电路描述或任何平均情形事实。因此：

\[
\boxed{
\text{MCSP 语义加权不能使 directed spoiler 三元组在仿射叶平均中失衡。}}
\]

要逃逸 (8)，至少必须放弃以下一个条件：

\[
\phi\ge0,\qquad \lambda_i\ge0,\qquad |T|=3,\qquad
\text{只用 }G_{T,s}=\mathbf1_s-\mathbf1_T.
\]

其中最自然的下一步是允许 signed \(\lambda\)，或把 \(K\) 扩展为不能写成非负 directed triple 的更高阶 collision spectrum；单纯按 \(E_a/NO_b\) 重新加权不会改变结论。

## 6. 与已有平均式的关系

已有 affine-leaf 计算对单 cell 给出 \(1/4\) 的命中概率。这里新增的是三 cell 的秩至少 \(3\)，从而给出 \(1/8\) 的联合命中上界；这正好使 \(G_{T,s}\) 的平均值保持正的 \(1/8\) 裕量。它比仅观察某个具体四点 collision 的 \(q_1-q_3\) 更强，因为适用于所有不同 \(T\) 与所有 spoiler \(s\)。

参考：Ueno, *Breaking the Rectangle Bound Barrier against Formula Size Lower Bounds*, MFCS 2010；以及 parity 叶平均式 [[008-parity-kw-rectangle-weight-collapse]]。
