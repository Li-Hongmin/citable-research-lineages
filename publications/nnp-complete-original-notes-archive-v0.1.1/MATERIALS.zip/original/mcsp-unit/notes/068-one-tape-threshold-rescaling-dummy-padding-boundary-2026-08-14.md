> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One-tape MCSP 阈值重标定：dummy-padding 的指数损失（2026-08-14）

## 结论

令

\[
L_{\mu,n}:=\{f:\{0,1\}^n\to\{0,1\}:\operatorname{CC}(f)\le\lfloor2^{\mu n}\rfloor\},
\qquad N:=2^n.
\tag{1}
\]

McKay--Murray--Williams（MMW）的 streaming magnification 与
Cheraghchi--Hirahara--Myrisiotis--Yoshida（CHMY）的模拟给出一个固定但未数值化的小常数
\(\mu_*>0\)：

\[
L_{\mu_*}\notin\operatorname{DTIME}_1[N^{1.01}]
\quad\Longrightarrow\quad P\ne NP.
\tag{2}
\]

这里 \(\operatorname{DTIME}_1[t]\) 是 CHMY 的固定机器模型：一台只有 \(O(1)\) 个状态的
deterministic Turing machine，带一条 one-way read-only input tape 和一条 initially blank、
two-way read/write work tape，在 canonical \(N\)-bit truth table 上运行 \(O(t(N))\) 步。
证明允许把该固定 witness 取为

\[
0<\mu_*<\tfrac14.
\tag{3}
\]

对这个 \(\mu_*\)，整数 dummy-variable padding 可以把阈值**精确**对齐到
\(>1/2\) 的 Cheraghchi--Hirahara--Myrisiotis--Yoshida（CHMY）下界区间；但即使
慷慨假定该 padding 能在 \(\operatorname{DTIME}_1\) 中零指数损失地组成，所得的低阈值
时间下界至多是

\[
N'^{\,2\mu_*-o(1)},
\tag{4}
\]

其中 \(N'=2^{kn}\) 是 padded truth table 长度。由 (3)，指数严格小于 \(1/2\)，远小于
(2) 所需的 \(1.01\)。故这条精确阈值重标定不能关闭 one-tape magnification 缺口。

这只是 dummy-padding／固定变量扩张路线的关闭；它不排除具有新结构的阈值 transfer。

## MMW witness 的可取范围

CHMY 的完整版本附录重述 MMW 的论证：若 \(P=NP\)，则存在一个固定多项式 \(p\)，使
任意 time-constructible \(s\) 的 \(\operatorname{MCSP}[s]\) 有 update time \(p(s)\) 的
one-pass streaming algorithm。经其 Lemma 9 的 one-tape 模拟，并把多项式损失吸收进
另一个固定多项式 \(q\)，可写为

\[
P=NP\quad\Longrightarrow\quad
\operatorname{MCSP}[s]\in\operatorname{DTIME}_1[N\,q(s)].
\tag{5}
\]

若 \(q(t)\le Ct^d\) 且 \(s(n)=\lfloor2^{\mu n}\rfloor\)，则

\[
N\,q(s(n))\le C N^{1+d\mu}.
\tag{6}
\]

故先固定 \(C,d\)，再选择
\(0<\mu_*<\min\{1/4,0.01/d\}\)，可使右端为 \(O(N^{1.01})\)。把有限个例外长度
hard-wire 后取逆否，就得到 (2)。这只说明 MMW 的 existential witness 可以固定在 (3) 的
范围；文献并没有给出独立的数值 \(\mu_*\)，它也不是后续可以任意指定的 target exponent。

## 精确 padding 等式

令

\[
k:=\min\{j\in\mathbb N:j\mu_*>\tfrac12\},
\qquad
\mu_H:=k\mu_*.
\tag{7}
\]

由极小性与 (3)，

\[
\tfrac12<\mu_H\le\tfrac12+\mu_*<\tfrac34.
\tag{8}
\]

对 \(f:\{0,1\}^n\to\{0,1\}\)，定义

\[
E_k(f)(x,z):=f(x),
\qquad x\in\{0,1\}^n,\ z\in\{0,1\}^{(k-1)n}.
\tag{9}
\]

在 CHMY 所用的 bounded-fan-in、unbounded-fan-out \(\{\land,\lor,\neg\}\) circuit basis 上，

\[
\operatorname{CC}(E_k(f))=\operatorname{CC}(f).
\tag{10}
\]

其中 \(\le\) 由忽略 \(z\) 的 circuit 给出；反向取任一 \(E_k(f)\)-circuit，把所有 \(z\)-input
leaf 替为 \(x_1\)，不增 gate 数，所得 circuit 计算 \(f\)。因而对 \(N'=2^{kn}=N^k\)，

\[
f\in L_{\mu_H,n}
\quad\Longleftrightarrow\quad
E_k(f)\in L_{\mu_*,kn},
\tag{11}
\]

因为 \(\lfloor2^{\mu_Hn}\rfloor=\lfloor2^{\mu_*kn}\rfloor\)。所以阈值本身不是此
padding 的遗漏参数。

## 不可避免的长度指数损失

CHMY 的 oracle-strengthened theorem 特别蕴含：对任意
\(1/2<\lambda<\mu_H\)，

\[
L_{\mu_H}\notin
\operatorname{BPTIME}_1[N^{\,2(\lambda-o(1))}].
\tag{12}
\]

即使假定 (9) 可与一个 \(N'\)-bit low-threshold decider 作无额外指数的组成，若后者时间为
\((N')^a\)，则经 (11) 所得 high-threshold decider 的时间为

\[
(N')^a=N^{ka}.
\tag{13}
\]

由 (12)，这种理想化 transfer 至多排除

\[
a<\frac{2\lambda}{k}-o(1).
\tag{14}
\]

令 \(\lambda\uparrow\mu_H=k\mu_*\)，端点仅为 (4)。反过来，若想用 (12) 排除
\(N'^{1.01}\) 时间，需要

\[
1.01k<2\lambda<2k\mu_*,
\qquad\text{即}\qquad
\mu_*>0.505,
\tag{15}
\]

与 (3) 不相容。

普通的 materialized many-one reduction 更弱：它须先写出 \(N'=N^k\) 个 padded bits。
由 (3) 有 \(k\ge3\)，而 (8) 与 \(\lambda<\mu_H\) 给出

\[
2\lambda<\tfrac32<k.
\tag{16}
\]

所以单是输出生成的 \(N^k\) 时间已经高于 (12) 所排除的尺度；式 (13)--(15) 是把这个
不可避免成本也理想化移除后得到的最有利上界。

## 严格 one-tape 模型的额外接口

(13) 不是标准 \(\operatorname{DTIME}_1\) 的自动 composition theorem。令 target truth-table
变量顺序为 \((x,z)\)，则 (9) 的 canonical table 把每个 input bit 重复

\[
R=N^{k-1}
\tag{17}
\]

次。直接的 online generator 在发出首个 repeated block 前须知道 \(R\)，而一向只读输入带不预先
给出最终长度 \(n\)。先扫描 whole input 再模拟 target machine 则需要保存 source table 并做一带
work-tape simulation；MMW 与 CHMY 在此处所陈述的 simulation lemmas 并没有给出可直接用于该
composition 的 \(N'^{o(1)}\)-overhead guarantee。

因此 (14) 是对该 route 的**乐观上界**：即使补上这一 simulation interface，指数仍不足；未补上时，
dummy-padding 更不能作为 (2) 的证明。

变量 permutation 不改变 \(n\)，restriction 只有
\(\operatorname{CC}(f\upharpoonright\rho)\le\operatorname{CC}(f)\)，会把 NO instance 变为 YES
instance，均不能替代 (9) 的双向阈值等式。

## 来源

- Dylan M. McKay, Cody D. Murray, and R. Ryan Williams, *Weak Lower Bounds on
  Resource-Bounded Compression Imply Strong Separations of Complexity Classes*, STOC 2019,
  DOI: [10.1145/3313276.3316396](https://doi.org/10.1145/3313276.3316396), Theorem 1.3。
- Mahdi Cheraghchi, Shuichi Hirahara, Dimitrios Myrisiotis, and Yuichi Yoshida,
  *One-Tape Turing Machine and Branching Program Lower Bounds for MCSP*, STACS 2021,
  DOI: [10.4230/LIPIcs.STACS.2021.23](https://doi.org/10.4230/LIPIcs.STACS.2021.23),
  Theorems 1--3；完整版本 ECCC TR20-103 rev. 1, Appendix A Theorem 47、Lemma 9，及
  Lemma 16。全文缓存：`ResearchLibrary/lib/mahdicheraghchi2021one/`。
- [note 000](000-cutover-2026-08-13.md)：此前记录的 one-tape 阈值缺口；本 note 给出
  exact dummy-padding 为何不能消去它的定量版本。
