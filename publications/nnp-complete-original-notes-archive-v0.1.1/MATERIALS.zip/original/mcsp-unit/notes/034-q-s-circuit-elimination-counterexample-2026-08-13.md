> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# (q_s=1) 分支：cell-level 电路消去失败（2026-08-13）

## 决策

检验能否把固定 spoiler 的 (q_s=1) 极小 collision witness 看成一个保留在 cell 层面的二元拟阵电路族，并用 circuit elimination 或 circuit-EKR 给出联合质量界。

结论：**atom 层的二元拟阵电路消去成立，但不保留 cell witness 类；因此不能从标准电路消去得到 AEKR 的 cell-level 消去定理。**

## 显式反例

取 (N=3)，

\[
X=\{2,1,3,4\},\qquad Y=\{5,7,0\},\qquad s=(2,5),
\]

并记

\[
a=(3,0),\qquad b=(1,5),\qquad c=(4,7).
\]

令

\[
T_1=\{a,b\},\qquad T_2=\{c,b\}.
\]

两者相交于 cell (b)。写 (z=(r,t))，cell (u=(x,y)) 的叶方程为

\[
q_u z=(x,1)\cdot z=0,
\qquad p_u z=(y,1)\cdot z=1.
\]

直接解得

\[
L(T_1)=L(T_2)=\{(r,t)=(5,1)\}.
\]

在该参数上

\[
q_s z=(2,1)\cdot(5,1)=1,
\qquad p_s z=1.
\]

故 (T_i\cup\{s\}) 不相容，且均为关于 (s) 的 (q_s=1) collision witness。极小性由下列兼容参数核验：

\[
\begin{array}{c|c|c}
T_i&\text{删去第一个 cell 后与 }s\text{ 相容}&\text{删去 }b\text{ 后与 }s\text{ 相容}\\
\hline
T_1& (4,0),(7,1)&(2,1)\\
T_2& (4,0),(7,1)&(1,0)
\end{array}
\]

## 原子电路证书

在 (mathbb F_2^4) 中把每个 cell (u=(x,y)) 展开成两个 atom

\[
q_u=(x,1),\qquad p_u=(y,1).
\]

两条不相容证书分别是

\[
q_s+q_a+p_a+q_b=0,
\qquad
q_s+q_c+p_c+q_b=0.
\tag{1}
\]

每条式中的 (p)-atom 数为奇数 (1)，所以在 (L(T_i)) 上确实给出 (q_s z=1)。这四个 atom 各自不可删，故 (1) 是二元向量拟阵中的电路。

两电路同时含有 (q_s,q_b)。对称差为

\[
q_a+p_a+q_c+p_c=0,
\tag{2}
\]

这是一个不含 (q_s) 的四原子电路。它正是标准 binary circuit-elimination 可产生的对象；但它不对应 collision witness。

在 cell 层面，消去公共 cell (b) 后只剩

\[
\{a,c\}.
\]

其参数集为

\[
L(\{a,c\})=\{(5,1),(6,1)\},
\]

而 (q_s) 在这两个参数上的值分别为 (1,0)。因此 ({a,c}) 不是 (q_s=1) witness；其单点子集也不是（放大参数集后仍同时出现两种 (q_s) 值）。所以不存在

\[
T_3\subseteq (T_1\cup T_2)\setminus\{b\}
\]

满足 (q_s=1) 且为极小 collision witness。

## 含义

1. **消去失败的原因不是二元拟阵理论失效。** 原子依赖满足标准 circuit elimination；失败发生在把成对的 ((q_u,p_u)) 压回一个 cell 时，消去可能留下偶数 (p)-parity 的依赖 (2)，从而丢失 spoiler (q_s)。
2. 固定元素电路的 packing/covering 结果（例如 Lemos--Oxley, JCTB 96 (2006), DOI [10.1016/j.jctb.2005.07.001](https://doi.org/10.1016/j.jctb.2005.07.001)）要求原子电路按“只在固定元素相交”或覆盖数组织；本例的 cell 相交只保证共享 cell，不保证所选 atom 的交集模式，故不能直接给出 AEKR 权重界。
3. 更强的“对称差仍为单电路”也不是一般二元拟阵公理。Oxley 等的 *Circuit-Difference Matroids*（EJC 27(3), 2020, DOI [10.37236/93141](https://doi.org/10.37236/93141)）给出一般 binary matroid 中对称差可裂成多个电路的 (S_8) 例；只有额外的 circuit-difference/no-skew 条件才可排除该现象。当前 affine atom matroid 未满足或验证这些条件。
4. 因而 (q_s=1) 分支仍须使用 affine 参数与 row/column thinning 的联合结构；“把 witness 当作固定 (q_s) 的电路族，再套 EKR/消去”这条捷径已被本例关闭。

该反例不否定完整 thinning 的 (1/16) 命题；它只否定 cell-level circuit-elimination 作为证明接口。
