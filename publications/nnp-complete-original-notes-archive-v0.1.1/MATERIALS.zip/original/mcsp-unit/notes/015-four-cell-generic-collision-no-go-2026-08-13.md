> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 四点 affine-collision 势：generic 支撑的随机叶 no-go（2026-08-13）

## 目标

沿用 affine-parity QA 证书。对四点 cell

\[
H=\{c_i=(x_i,y_i):1\le i\le4\}\subseteq E_a\times NO_b,
\]

考虑对称碰撞势

\[
g_H(R)=\mathbf 1\{|H\cap R|=1\}-
       \mathbf 1\{|H\cap R|=3\}.
\]

它满足递归不等式，因此是目前最低阶、允许负递归融资的候选之一。本节证明：只要四点 cell 不高度退化，该势的任意非负加权和都不能给出超常数 QA 对偶值。

## 1. 递归合法性

置

\[
g(0),g(1),g(2),g(3),g(4)=(0,1,0,-1,0).
\]

直接枚举 $0\le u,v$ 且 $u+v\le4$ 得

\[
g(u)+g(v)\ge g(u+v).
\]

故对任意横向或纵向二分 $R=V\dot\cup W$，令

\[
q=|H\cap R|,
\quad q_V=|H\cap V|,
\quad q_W=|H\cap W|,
\]

则

\[
g_H(V)+g_H(W)\ge g_H(R).
\]

并且 $g_H(C)=g(4)=0$。

## 2. 仿射叶平均

取随机 $(r,b)\in\mathbb F_2^{N+1}$，令

\[
R_{r,b}=\{(x,y):r\cdot x+b=0,\ r\cdot y+b=1\}.
\]

记 $I_i=\mathbf 1\{c_i\in R_{r,b}\}$，$q=\sum_i I_i$。三点二项式恒等式给出

\[
g(q)=\sum_i I_i-2\sum_{i<j}I_iI_j
       +2\sum_{i<j<k}I_iI_jI_k.\tag{1}
\]

单格概率为 $\Pr[I_i=1]=1/4$。对 $i<j$，四条仿射方程的秩为

\[
2+\operatorname{rank}\{x_i\oplus x_j,\ y_i\oplus y_j\}.
\]

因而

\[
\Pr[I_iI_j=1]=
\begin{cases}
1/8,&x_i=x_j\text{ 或 }y_i=y_j\text{ 或 }x_i\oplus y_i=x_j\oplus y_j,\\
1/16,&\text{否则}.
\end{cases}\tag{2}
\]

定义特殊 pair 数

\[
s(H)=\#\{\{i,j\}:x_i=x_j\text{ 或 }y_i=y_j\text{ 或 }d_i=d_j\},
\qquad d_i=x_i\oplus y_i.
\]

代入 (1)--(2)，并丢弃非负三点项，得到

\[
\begin{aligned}
\mathbb E g_H(R_{r,b})
 &=1-2\sum_{i<j}\Pr[I_iI_j]
   +2\sum_{i<j<k}\Pr[I_iI_jI_k]\\
 &\ge \frac14-\frac{s(H)}8.\tag{3}
\end{aligned}
\]

故

\[
s(H)\le2\quad\Longrightarrow\quad
\mathbb E g_H(R_{r,b})\ge0,
\]

而 $s(H)=0$ 时下界为 $1/4$。

## 3. QA 对偶 no-go

令 $\lambda_H\ge0$，并令

\[
K(R)=\sum_H\lambda_Hg_H(R).
\]

由第 1 节，$K$ 满足全部递归约束；且 $K(C)=0$。若所有有正权的 $H$ 都满足 $s(H)\le2$，则由 (3)

\[
\mathbb E K(R_{r,b})\ge0.
\]

任意叶变量 $\phi_c$（甚至允许有符号）满足

\[
\sum_{c\in R}\phi_c+K(R)\le1
\qquad(\forall R\text{ affine-parity monochromatic})
\]

时，取随机叶平均。每个 cell 以概率 $1/4$ 被命中，故

\[
\frac14\sum_{c\in E_a\times NO_b}\phi_c+
\mathbb E K(R_{r,b})\le1,
\]

从而

\[
\boxed{\sum_c\phi_c\le4.}
\]

这关闭了所有 generic 四点 affine-collision 的非负加权势；结论与 $E_a$ 的电路描述及 $NO_b$ 的高复杂度语义无关。

## 4. 新的最小攻点

任何可能逃逸的四点权重都必须集中于

\[
s(H)\ge3,
\]

即至少三对共享低复杂度端点 $x$、共享高复杂度端点 $y$，或共享差向量 $d=x\oplus y$。因此“按电路描述长度、Hamming 距离或 generic odd--odd collision 加权”不能产生超常数；剩余问题严格缩减为三类退化族：

\[
\text{star}_x,\qquad \text{star}_y,\qquad \text{parallel}_d.
\]

若这三类也能通过额外的随机叶分布关闭，则整个四点路线淘汰；若不能，必须明确证明 $E_a/NO_b$ 语义如何在某一退化族上产生单叶三命中质量超过一命中质量。

