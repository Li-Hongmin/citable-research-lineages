> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 极小 collision witness 的秩增一引理（2026-08-13）

## 命题

令 (s) 是 spoiler，(T) 是一个 cell 集。写 (L(S)=\{z:A_Sz=b_S\})，其中每个 cell (c=(x,y)) 贡献两行

\[
q_c=(x,1),\quad q_cz=0,
\qquad
p_c=(y,1),\quad p_cz=1.
\]

假设：

1. (L(T)\neq\varnothing)；
2. (L(T\cup\{s\})=\varnothing)；
3. 对每个 (c\in T)，(L((T\setminus\{c\})\cup\{s\})\neq\varnothing)。

则

\[
\boxed{\operatorname{rank}(A_T)\ge |T|+1.}
\]

这里的极小性只针对相对于固定 spoiler (s) 的 collision，不要求 (T) 在见证族中不可由其他见证替代。

## 证明

令 (V=\operatorname{rowspan}(A_T))，并取 (z_0\in L(T))。因为 (A_Tz=b_T) 相容，

\[
\ell(v):=v\cdot z_0\qquad(v\in V)
\]

是良定义的线性泛函。对每个 (c=(x,y)\in T)，

\[
\ell(q_c)=0,\qquad \ell(p_c)=1.
\]

由 (T\cup\{s\}) 不相容，而 (T) 本身相容，线性不相容证书必给出某个

\[
w\in\{q_s,p_s,q_s+p_s\}\cap V
\]

使得 (w) 在 (ell) 下的值与 (s) 对 (w) 要求的右端相反。这就是参数 separator 三分法的同一线性证书。

记 (V_c=\operatorname{span}\{q_c,p_c\})，(V_{-c}=\sum_{d\in T\setminus\{c\}}V_d)。极小性蕴含

\[
w\notin V_{-c}.\tag{1}
\]

否则 (w) 已由删去 (c) 后的方程决定，且其 \(\ell\)-值不变；同一个错误的 (s)-方程仍会造成不相容，违背假设 3。

设 (k=|T|)，反设 \(\dim V\le k\)。由 (1)，每个 (V_{-c}) 都是 (V) 的真子空间，故余维至少为一。取线性泛函 (f_c\in V^*)，满足

\[
f_c|_{V_{-c}}=0,\qquad f_c(w)=1.
\]

对 (d\neq c)，(V_d\subseteq V_{-c})，所以 (f_c|_{V_d}=0)；而 (f_c(w)=1) 保证 (f_c\neq0)。这些 (f_c) 线性无关：在 (V_c) 中取一个向量 (u_c) 使 (f_c(u_c)=1)，则对 (d\neq c) 有 (f_d(u_c)=0)。因此 \(\dim V\ge k\)。在反设下恰有 \(\dim V=k\)，于是 (f_1,\ldots,f_k) 构成 (V^*) 的一组基。

对任意 (u\in V_c)，(f_d(u)=0)（(d\neq c)），故 (V_c) 被包含在所有 (k-1) 个独立核的交中，该交是一维空间。可是 (q_c,p_c) 线性独立：它们最后一个坐标相同为 (1)，而 (q_c\neq p_c)（因为 cell 的两端 (x\neq y)）。所以 \(\dim V_c=2\)，矛盾。故 \(\dim V\ge k+1\)。

## 直接后果与边界

若 (T) 是关于 (s) 的极小 witness，参数 (z) 同时包含 (T) 的概率至多

\[
2^{-(|T|+1)}.
\]

再乘以行、列 thinning：若 (a=|\pi_XT|)、(b=|\pi_YT|)，则

\[
\Pr[T\subseteq R_z(U,V)]
\le 2^{-(|T|+1+a+b)}.
\]

例如 \(|T|=3\) 且至少使用一行三列时，单个见证质量至多 (2^{-8})。这不是联合见证族的 (1/16) 证明：可同时存在的大量高阶见证仍可能形成较大的并集；剩余问题是用两两交叉性控制这些低质量事件的联合，而不是继续估计单个见证。
