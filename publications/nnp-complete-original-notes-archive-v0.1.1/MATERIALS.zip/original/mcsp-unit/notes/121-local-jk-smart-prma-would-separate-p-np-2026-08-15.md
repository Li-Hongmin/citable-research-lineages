> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Local-JK smart-\(\mathrm{prMA}\) 接口足以推出 \(P\ne NP\)（2026-08-15）

## 命题

本 note 把“把 RW/JK history 压到地址尺度”的目标写成一个可直接导致复杂度类分离的
充分条件。它**不**声称该接口已经存在。

设 \(A\) 是一个候选的确定性 polynomial-time SAT decider，令
\(k(n)\to\infty\)（例如
\(k(n)=\lfloor\log_2\log_2 n\rfloor\)），并令 \(H_A\) 是由
Ren--Williams/Jeřábek--Korten forcing 构造的 stitched language。假设以下两条：

1. **Forcing lower bound.** 当 \(A\) 确实决定 SAT 时，存在 \(n_0\) 使
   \[
   \operatorname{CC}\bigl((H_A)_n\bigr)>n^{k(n)}
   \qquad(n\ge n_0).
   \tag{1}
   \]
   这里 \((H_A)_n\) 是长度为 \(n\) 的 truth-table slice；该条是 RW/JK
   forcing 需要提供的硬度结论，而不是本 note 新证的事实。

2. **Local-JK smart interface.** 存在一个固定的确定性 oracle machine \(M\)，一位
   advice \(d_n\)，以及固定的 \(\mathrm{prMA}\) promise，使得：
   - \(M(1^n,x;d_n)\) 输出 \(H_A(x)\)；
   - \(M\) 的总运行时间、query 数量和每个 query 描述长度都是 \(n^{O(1)}\)；
   - 当 \(A\) 正确时，\(M\) 实际发出的每个 query 都落在 promise 内（smartness）。

   这里的 Local-JK 实现还必须满足以下语义条件，才能从 RW history 得到上述 \(M\)：
   每个 range block 的 preimage 由一个**整词一致**的 selector 给出；selector 的输入只含
   \(n,k(n)\)、block/history index 和 bit address，长度为 \((n+k(n))^{O(1)}\)，不得物化
   \(q=n^{k(n)+O(1)}\) 个 seed bits；choice-robust JK 的每一步都使用同一个合法
   \(q\)-bit word，而不是逐 bit 拼接不同 witnesses。

在这两条假设下，

\[
\boxed{P=NP\ \Longrightarrow\ \text{矛盾}.}
\]

因此 Local-JK smart interface 若能被构造，就足以证明
\[
\boxed{P\ne NP.}
\tag{2}
\]

## 已有的 smart 重构与真正缺口

Ren--Williams Theorem 4.1 已经给出了一个容易混淆但更弱的事实：对
\(G:\{0,1\}^{q}\to\{0,1\}^{2q}\)，其 Reconf 在 AVOID 失败分支上逐位重构
\(f(x)\)，使用 smart-\(\mathrm{prMA}\) queries，运行时间和 query size 为
\[
\operatorname{poly}\bigl(q,r(n),\log t(n)\bigr).
\tag{5}
\]
该定理覆盖完整 PCP/auxiliary proof history；因此“auxiliary blocks 完全没有
smart reconstruction”并不是准确表述。

本项目需要的却是不同的缩放：
\[
\operatorname{poly}\bigl(n+k(n),\log t(n)\bigr)
\quad\text{而不是}\quad
\operatorname{poly}\bigl(q(n),r(n),\log t(n)\bigr),
\tag{6}
\]
其中 stitched 参数通常满足 \(q(n)=n^{k(n)+O(1)}\)。也就是说，目标是把已知
smart-\(\mathrm{prMA}\) 接口中的 \(q\)-bit AVOID witness/range query 压到
\(\log q\)（或 base input \(n\)）尺度，同时保留 word consistency、PCP soundness
和 smartness。式 (6) 不是对 Theorem 4.1 的换记号；它是一个新的 succinct
range/preimage lemma。note 120 的 quantile bound 说明它不可能对任意
range history 成立，必须利用 RW history 的特殊结构。

## 证明

令
\[
\operatorname{Yes}_{\mathrm{prMA}}(B)
\iff
\exists w\ \forall r\; B(w,r)=1,
\tag{7}
\]
其中 \(B\) 是 oracle query circuit，\(w,r\) 的长度均为 query 描述长度的多项式。
式 (7) 是一个 \(\Sigma_2^P\) 谓词。若 query 属于 promise 的 YES 侧，它为真；若
query 属于 promise 的 NO 侧，每个 \(w\) 至多在一半随机串上通过，所以式 (7) 为假。

反设 \(P=NP\)。由 \(P=NP\Rightarrow PH=P\)，存在一个固定的确定性 polynomial-time
算法判定式 (7)。在运行 \(M\) 时，逐次把每一个 smart query 的 oracle answer 替换为
该算法的结果。由于 query 数量及长度均为 \(n^{O(1)}\)，且 \(M\) 的 advice \(d_n\)
只有一位，得到一个确定性 polynomial-time machine 计算 \(H_A\)。把每个长度 \(n\)
上的 \(d_n\) 硬接进电路，遂有

\[
H_A\in P/poly.
\tag{8}
\]

于是存在固定常数 \(c\)，使
\[
\operatorname{CC}\bigl((H_A)_n\bigr)\le n^c
\]
对所有充分大 \(n\) 成立。这与 \(k(n)\to\infty\) 时的式 (1) 矛盾。故
\(P\ne NP\)。证毕。

## 这个命题真正要求什么

上述证明把剩余工作精确分成三项，而不是笼统地要求“压缩 JK”：

1. **地址尺度：** 所有 range/preimage 查询必须在 \((n+k)^{O(1)}\) 长度内表达；
   直接提交 \(q\)-bit block、\(q\)-bit seed 或 \(q\)-bit prefix 都会把机器退回
   \(q=n^{k+O(1)}\) 尺度，不能推出式 (8)。
2. **整词一致：** 对同一 occurrence 的 \(q\) 个 bits，必须存在同一个
   \(u\in G_q^{-1}(z)\)。逐 bit 分别寻找某个 witness 不足以定义下一层 JK parent。
3. **smartness：** \(\mathrm{prMA}\) 只在实际执行的 query 上需要 promise；若 selector
   在非 promise 输入上任意失效，仍必须证明正确 history 不会触发这些输入。

这三个条件分别对应当前记录的三个独立障碍：

\[
\begin{array}{c|c}
\text{障碍} & \text{已有边界}\\ \hline
\text{q-scale address / explicit outsider} &
\text{notes 108--110}\\
\text{preimage accessor inflation} &
\text{note 120}\\
\text{systematic block 与 auxiliary JK block 的差异} &
\text{notes 079, 082--083}
\end{array}
\]

特别地，note 082 只给出某些 systematic output blocks 的 locally uniform preimage；
它没有给出 auxiliary Reed--Muller/PCP coordinates 或递归 JK blocks 的
Local-JK smart selector。因此它尚不足以应用本命题。

## 与 \(P=NP\) 下 smart collapse 的边界

本命题只使用 \(P=NP\Rightarrow PH=P\)，不使用
\(\#P=FP\)、\(PSPACE=P\) 或任何未证的随机性去除。它也不要求
\(\mathrm{prMA}\) 语言本身等于 \(P\)：只需实际 query 落在 promise，且 YES/NO
两侧由式 (7) 正确区分。

相反，若 Local-JK machine 的 query 长度为 \(q^{\Omega(1)}\)，或者其 advice/history
随 \(k\) 改变而不能由一个固定机器统一生成，则式 (8) 不成立。这正是
“\(\operatorname{poly}(q)\) 的 AVOID/search 算法”不能直接转成
\(\operatorname{poly}(n)\) 语言的尺度断点。

## 文献与证据边界

- Ren--Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin--Arthur Queries*, ECCC TR26-118 revision 1, Theorems 3.1, 4.1, 5.1
  ([official report](https://eccc.weizmann.ac.il/report/2026/118/revision/1/download))：
  提供 smart-\(E^{\mathrm{prMA}}/1\) 及 AVOID/JK 的原始接口。
- notes 078、082、083、108--110、120：给出本项目对 Local-JK、choice-robustness、
  地址尺度与 accessor 计数的组合边界。

式 (2) 是一个**充分条件定理**：它把“若能完成哪一个具体接口就会解决
\(P\) vs \(NP\)”严格化；它不是该接口存在性的证明，也不声称当前已经得到
\(P\ne NP\)。
