> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Growing-alphabet coordinate-normalization Closure Gate (2026-08-17)

## Status

This note combines the standard-Borel policy-fiber argument with the
source-safe growing-alphabet RLDC envelope. It formalizes the claim that
target-dependent, coordinate-normalized addressing cannot remain a
low-information escape while keeping one proof/address space and
supportwise target-relative robustness. It is a derived coding theorem, not
an unconditional dPCP impossibility theorem or a $P\ne NP$ result.

## Theorem

Let $M$ be uniform on $\{0,1\}^{K}$, and let

$$
  \Pi:\{0,1\}^{K}\longrightarrow \Sigma_K^{P}
$$

be one common proof map, where $A_K:=|\Sigma_K|\ge2$. Fix constants
$0<\rho<1$, $0\le\beta<1$, and $\gamma<1$. Let $S$ be an arbitrary
standard-Borel target-dependent policy object. For almost every policy value
$s$, write

$$
  F_s=\{m:\Pr[M=m\mid S=s]>0\}.
$$

Assume that the same policy family $\tau_s$, on the same proof/address space,
satisfies for every $m\in F_s$ and every coordinate $i$:

* the branch for the correct claim is perfectly complete on $\Pi(m)$;
* the opposite-claim branch accepts with probability at most $\beta$ on every
  $z$ with $d_H(z,\Pi(m))\le\rho P$;
* each branch is adaptive and makes at most $r_K$ proof-symbol queries.

Put

$$
 Q_K=1+2\sum_{j=0}^{r_K-1}A_K^j,
 \qquad
 H_{K,A}=\log\log(K+2)+\log(Q_K+2)
       +\log(\log(A_K+2)+2),
$$

with all logarithms base two. Suppose $I(M;S)\le\gamma K$ and

$$
  N_K:=K+P\le K(\log(K+2))^c
$$

for infinitely many $K$. Then, for all sufficiently large such $K$,

$$
  \log A_K\ge \frac{\vartheta_\gamma}{4}K
  \qquad\text{or}\qquad
  Q_K H_{K,A}\ge c_*\log K,
\tag{303.1}
$$

where $\vartheta_\gamma>0$ is any fixed constant below the smaller solution
of $H_2(\vartheta_\gamma)=1-\gamma$, and $c_*>0$ depends only on
$(\rho,\beta,\gamma,c)$. In particular, if

$$
  \log A_K=o(K),
  \qquad
  Q_KH_{K,A}=o(\log K),
\tag{303.2}
$$

then the supportwise policy channel must satisfy

$$
  I(M;S)=K-o(K).
\tag{303.3}
$$

If $M\to D\to S$ for a target-dependent descriptor $D$, then
$H(D)\ge I(M;S)$, so (303.2) forces $H(D)=K-o(K)$. Thus a
polylogarithmic key, cover-sheet label, or short target-normalized address
schedule cannot be the missing closure mechanism.

## Proof

The conditional entropy identity gives

$$
  H(M\mid S)=K-I(M;S)\ge(1-\gamma)K.
$$

Since $M$ has finite support, some policy fiber among the
almost-everywhere supportwise-good values has size at least

$$
  |F_s|\ge 2^{(1-\gamma)K-o(K)}.
$$

Sauer--Shelah supplies a coordinate set $J\subseteq[K]$ of size

$$
  d\ge(\vartheta_\gamma-o(1))K
$$

shattered by $F_s$. Pick one representative target in the fiber for each
binary pattern on $J$. Restricting $\Pi$ to these representatives gives a
$d$-bit proof family with the same policy $\tau_s$, radius, gap, and proof
alphabet.

Inline the $d$ message bits with two fresh tags. For each fixed random tape,
the two adaptive $A_K$-ary branch trees have at most
$\sum_{j<r_K}A_K^j$ internal nodes each. Their union, together with the inline
query, gives a nonadaptive relaxed decoder using $Q_K$ symbols over alphabet
$A_K+2$. The target-relative wrong-claim condition implies that distinct
representatives have proof distance strictly larger than $\rho P$. The
$A_K$-ary Singleton bound gives only

$$
  \frac{P}{d+P}\ge
  \frac{1}{2(1-\rho)\log_2 A_K+1}.
$$

Thus the inline radius may shrink with the alphabet. Taking

$$
  \delta_{*,K}:=
  \frac{\rho}{2\bigl(2(1-\rho)\log_2 A_K+1\bigr)}
$$

keeps the proof suffix inside the $\rho P$-neighborhood. The decoder still has
fixed success parameter $\sigma=1-\beta$. If the GGS radius condition for this
$\delta_{*,K}$ fails, the first branch of note 300 already gives the
$Q_KH_{K,A}$ alternative; if it holds, the GGS lower bound gives the same
alternative.

Because $d=\Theta_\gamma(K)$, the new inline length satisfies

$$
  d+P\le d(\log(d+2))^{c'}
$$

for a constant $c'=c'(c,\gamma)$. Apply the source-safe joint
alphabet--locality envelope (note 300) with message length $d$, alphabet
$A_K+2$, and query count $Q_K$. It yields either

$$
  \log(A_K+2)\ge d/2
$$

or $Q_KH_{d,A_K+2}=\Omega(\log d)$. The first alternative implies
$\log A_K\ge\vartheta_\gamma K/4$ for large $K$; the second is equivalent,
up to constants and additive $O(1)$ terms, to the second alternative in
(303.1). This proves (303.1).

For (303.3), apply (303.1) for every fixed $\gamma<1$. If both conditions
in (303.2) hold, the first alternative is eventually impossible, so
$I(M;S)>\gamma K$ for every fixed $\gamma<1$. Hence
$I(M;S)=K-o(K)$. The descriptor statement follows from data processing:
$I(M;S)\le I(M;D)\le H(D)$.

$$\square$$

## Exact boundary

The theorem requires one common proof/address space and supportwise robustness
for every target in a policy fiber. Ordinary average or list soundness, in
which different coordinates may use different witnesses or policy values, does
not provide that fiber and is not covered. Here “zero radius” means a zero
target-relative proof radius; the inline radius may shrink with \(\log A_K\),
which is precisely the radius-failure branch handled by note 300. A growing gap loss,
or an alphabet with $\log A_K=\Omega(K)$ is an explicit model exit. The
theorem also does not assert that the RW construction enters these hypotheses;
showing that it does, or proving an impossibility theorem for the remaining
model exits, is still the top-level open step.

## Sources

* Standard-Borel policy locality Closure Gate, note 288.
* Source-safe joint alphabet--locality envelope, note 300.
* Goldberg--Gur--Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally
  Decodable Codes via Robust Daisies*, Theorem 1:
  <https://arxiv.org/html/2511.21659>.
