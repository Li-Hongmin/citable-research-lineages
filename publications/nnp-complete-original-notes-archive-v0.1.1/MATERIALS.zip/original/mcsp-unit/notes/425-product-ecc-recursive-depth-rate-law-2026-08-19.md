> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Product-ECC recursive depth--rate law（2026-08-19）

## 本轮改变的判断

C424 把两个相邻 product-ECC blocks 的 recursive closure 门槛定为
\(R\le1/4\)。同一个容量论证可以沿完整 JK subtree 迭代：若每一层的
non-output leaves 仍有独立 ECC payload，则允许的码率随递归深度指数下降。

因此，对任意固定正码率（更一般地，任意 \(R\ge R_0>0\)）的 Harsha-style
product-ECC，**unbounded-depth 的 target-oblivious recursive range-closure
不可能在 product-rich source family 上成立**。这把 C400 的“单层可覆盖”与
C401 的“所有递归 non-output blocks 都覆盖”之间的缺口，从一个两层例子提升为
深度—码率定律。

结论仍是 source-level family theorem；它不把 actual RW/Harsha honest image
自动当成 full product family，也不适用于 published fixed-\(x_0\) singleton。

## 深度 \(d\) 的 aligned product-ECC subtree

令

\[
 E_0:\mathbb F_2^a\longrightarrow\mathbb F_2^b
\]

是 injective linear encoder，码率 \(R=a/b\)。在连续 product-ECC segment 中取
对齐的 JK width

\[
 b\mid 2k,\qquad q:=2k/b.
\tag{425.1}
\]

考虑一个深度为 \(d\) 的完整二叉 subtree。其 \(2^d\) 个 leaves 都是
\(2k\)-bit blocks；第 \(\ell\) 个 leaf 依赖 \(q\) 个 source symbols，且不同
leaves 依赖两两不相交的 symbol groups。令 \(\mathcal A_\ell\) 是第 \(\ell\) 个
leaf 在 source family 上的取值集合。由于 \(E_0\) injective，

\[
 |\mathcal A_\ell|=2^{qa}=2^{2Rk}.
\tag{425.2}
\]

假设 source family 对每个 tuple
\((a_1,\ldots,a_{2^d})\in\prod_\ell\mathcal A_\ell\) 都实现一个 canonical
proof，并且：

1. 所有 leaves 及其递归产生的内部 blocks 都是 non-output；
2. JK 使用同一个 \(G_k:\{0,1\}^k\to\{0,1\}^{2k}\) 与 canonical preimage
   \(p:R_G\to\{0,1\}^k\)，其中 \(R_G=\operatorname{Range}(G_k)\)；
3. proposed recursive cover 要求这些 leaves 和全部内部 blocks 都属于 \(R_G\)。

这里的“product-rich”是完整的 source-level 量词；若 tuple 由公开输入直接携带，
该输入熵必须在 parent-binding descriptor 中计账，不能冒充 hidden family entropy。

## 定理 425.1（recursive depth--rate law）

在上述假设下，

\[
 2^d\,q a\le k.
\tag{425.3}
\]

代入 \(q=2k/b\) 得

\[
 \boxed{R\le 2^{-(d+1)}}.
\tag{425.4}
\]

因此，若 \(R\ge R_0>0\)，任何这样的 recursive range-closure 都必须满足

\[
 d\le \log_2\!\frac1{2R_0}.
\tag{425.5}
\]

特别地，若 \(d>\log_2(1/(2R))\)，则固定码率 \(R\) 的 product-ECC
recursive cover 必然失败于某个 non-output subtree block。

### 证明

C402 的多层 product-closure 给出：若每个 leaf tuple 都被 source family 实现，
且所有递归内部 blocks 都在 \(R_G\)，则从 leaf tuples 到 root block 的
canonical-preimage 拼接映射是 injective。因此

\[
 \prod_{\ell=1}^{2^d}|\mathcal A_\ell|
 \le |R_G|\le2^k.
\]

用 (425.2) 展开左侧，得到

\[
 2^{2^d q a}\le2^k,
\]

从而 \(2^dqa\le k\)，即 (425.3)。再代入
\(qa=(2k/b)a=2Rk\)，得到 (425.4)。证毕。

## 深度增长的直接后果

若一个 proposed cover 要跨越的 product-rich subtree 深度满足
\(2^d\asymp L/k\)，其中 \(L\) 是 auxiliary/ECC segment 的长度尺度，则
(425.4) 要求

\[
 R=O(k/L).
\tag{425.6}
\]

这与 Harsha binary conversion 的 \(b=O(a)\) 参数形成严格张力：该条件给出
\(R\ge R_0>0\) 的固定正下界，而不是随 proof length 下降的
\(O(k/L)\) 码率。于是只要实际 source family 能提供这种深度随
\(\log(L/k)\) 增长的独立 leaves，固定率 product-ECC 不可能满足 C401 所需的
全递归 non-output range-closure。

这个推论并不说 Harsha 的 actual \(\Gamma_x\) image 已经 product-rich。若
\(\widetilde A_x\)、\(P_x\)、ZOS 链和 ECC image 只落在一个低维、强相关的
subfamily 中，(425.2) 的 leaf support 需要重新证明；那正是实际 RW source
仍未闭合的接口。

## 对 RW/Harsha Closure 的精确作用

* **关闭的路线：** 不能把 C400 的单层 universal block cover 逐层复用，
  同时假设每层仍保留独立的 full product-ECC payload，并把所有递归 blocks
  视为 non-output。固定正码率会在常数深度后触发 (425.4)。
* **仍开放的路线：** 只有三类出口没有被本定理直接关闭：
  1. actual ECC/Harsha image 的递归 leaf entropy 随深度快速塌缩；
  2. 某些递归 blocks 已经是 output-attached，因而不应要求 non-output cover；
  3. proposed relation 离开 target-independent common \(G_k\) range-closure，
     使用新的 non-product global relation。
* **singleton 边界：** published Theorem 4.3 固定 \(x_0\)，其 canonical proof
  是一个 point mass；不能仅凭 product-ECC 的 ambient alphabet 把它提升为
  \(\prod_\ell\mathcal A_\ell\) 的 family。
* **serialization 边界：** (425.1) 要求连续、对齐的 ECC codeword 坐标。交错或
  非对齐 serialization 必须重新证明 disjoint projection families；不能直接套用
  (425.4)。

所以本定理把当前 Gate-I 的 ECC 分支压缩为一个可核验的二选一：

\[
\boxed{
\text{证明 actual Harsha image 的递归 leaf entropy 塌缩，}
\quad\text{或}\quad
\text{承认固定率 product-ECC 不能提供深度递归 closure。}
}
\]

这不是 \(P\ne NP\) 证明，也不是对所有 PCP/ECC 方案的 impossibility theorem；
它是 C400/C401/C402 的 source-specific recursive depth--rate barrier。

## 上游与证据边界

* [C400](400-low-rate-product-ecc-universal-block-cover-2026-08-18.md)：单层
  product-ECC universal cover；
* [C402](402-jk-recursive-range-closure-capacity-2026-08-18.md)：多层
  canonical-preimage product capacity；
* [C424](424-product-ecc-recursive-closure-rate-gate-2026-08-19.md)：两层
  \(R\le1/4\) 特例；
* C389：Harsha auxiliary factorization 是正向生成式，不自动提供 local inverse；
* RW Theorem 3.5 与 Harsha §5.4.3：ECC serialization 与 actual proof source boundary。
