> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Parity--KW 单叶矩形权重的常数坍缩

## 1. 对象

令

\[
f:\mathbb F_2^N\to\{0,1\},\qquad
X=f^{-1}(0),\quad Y=f^{-1}(1),
\]

并令

\[
w:X\times Y\to\mathbb R_{\ge 0},
\qquad
W=\sum_{x\in X,y\in Y}w(x,y)>0.
\]

对仿射线性型

\[
\ell_{r,c}(z)=\langle r,z\rangle\oplus c
\]

及方向 \(t\in\{0,1\}\)，定义

\[
R_{\ell,t}
=
\bigl(X\cap\ell^{-1}(t)\bigr)
\times
\bigl(Y\cap\ell^{-1}(1-t)\bigr).
\]

这是一个合法的 parity--Karchmer--Wigderson 叶矩形：在其中每个点对上，
\(\ell(x)\ne\ell(y)\)。

## 2. 常数上界

若 \(r\in\mathbb F_2^N\) 与 \(c\in\mathbb F_2\) 独立均匀，则对任意
\(x\ne y\)，

\[
(\ell_{r,c}(x),\ell_{r,c}(y))
\sim U(\mathbb F_2^2).
\]

因此，对每个固定方向 \(t\)，

\[
\begin{aligned}
\mathbb E_{\ell}\,w(R_{\ell,t})
&=
\sum_{x,y}w(x,y)
\Pr[\ell(x)=t,\ell(y)=1-t]\\
&=\frac W4.
\end{aligned}
\]

故存在 \(\ell,t\) 使

\[
w(R_{\ell,t})\ge \frac W4.
\]

于是任何仅由“总点对质量除以最大合法单叶矩形质量”定义的下界都满足

\[
\boxed{
\frac{W}{\max_{\ell,t} w(R_{\ell,t})}
\le 4.}
\]

若把同一 \(\ell\) 的两个方向合并为 cut weight，则相应常数是 \(2\)；但两个方向的并集通常不是通信矩形，所以标准单叶版本的常数是 \(4\)。

## 3. Fractional-cover 形式

以上不仅关闭单个权重构造。给每个有向仿射 parity 矩形相同权重，使全部矩形权重之和为 \(4\)。每个
\((x,y)\in X\times Y\) 恰被总权重 \(1\) 覆盖，因为均匀随机仿射 parity 以概率 \(1/4\) 按指定方向分离该点对。因此该合法叶矩形族存在总代价 \(4\) 的 fractional cover。

由线性规划对偶，任何只使用这一 fractional-cover/非负矩形松弛的对偶下界同样至多为 \(4\)。允许 signed 点对权但仍以正总质量作归一化也不能逃逸：同一期望恒等式仍给出某个矩形的 signed mass 至少为总质量的四分之一。

## 4. 对 GapMCSP 路线的裁决

取

\[
E_a=\{z:\operatorname{CC}(z)\le a\},
\qquad
NO_b=\{z:\operatorname{CC}(z)>b\},
\]

并设候选 promise solver 满足

\[
E_a\subseteq f^{-1}(1),
\qquad
NO_b\subseteq f^{-1}(0).
\]

上述常数坍缩对任意非负权都成立，因而同时覆盖：

\[
E_a\times NO_b,
\quad
\text{按电路描述长度加权},
\quad
\text{任意 low-CC/high-CC 混合权重}.
\]

完整的 \(NO_b\) 语义在这个松弛中只保证端点是合法 0-input，不能产生额外增益。因此该方法不可能给出

\[
N^{1.01+\delta}
\]

下界，甚至不能给超常数下界。

这不否定 parity--KW 本身。仍可能有效的对象必须使用单叶容量之外的全局结构，例如：整数且互不交的协议分割、递归一致性、层级 LP，或不能写成非负单矩形覆盖的谱量。Karchmer--Kushilevitz--Nisan 的 fractional-cover/LP 工作是最接近的历史框架；本节的常数坍缩是针对任意 parity 叶族的独立论证，不归于该文献。

~~~mermaid
flowchart LR
    W["任意点对权 w"] --> A["随机仿射 parity"]
    A --> Q["每个方向期望 W/4"]
    Q --> R["存在合法叶矩形 ≥ W/4"]
    R --> C["单矩形比值 ≤ 4"]
    C --> X["关闭 nonnegative rectangle 路线"]
    X --> G["只保留全局协议/层级结构"]
~~~

