> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Robust-near-oracle ACRR 自动给出距离与 relaxed-LDC 障碍（2026-08-16）

## 结论地位

这是对 note 188/190 的参数合并：在**消息族、target-relative near-oracle** 量词下，
`constant-distance` 不需要再作为独立假设。正半径错误声明 soundness 先强制 code
distance；随后把两个声明 verifier 做阈值比较，直接得到 relaxed LDC。这里的贡献是
量词和参数的闭合，不声称重新证明 Dall’Agnol--Gur--Lachish 的 sample-based 下界。

## 定理（radius-to-relaxed-LDC）

令

\[
  C:\{0,1\}^k\to\Sigma^N
\]

为 injective code map，距离使用相对 Hamming 距离。对每个消息坐标
`i\in[k]` 和声明位 `b\in\{0,1\}`，给定至多 `q` 次（可自适应）查询的随机 verifier
`V_{i,b}`，并记

\[
  p_{i,b}(z)=\Pr[V_{i,b}^{z}=1].
\]

假设存在 `rho>0` 和 `alpha>beta`，使得：

1. **codeword 完备性：** 对所有 `m` 和 `i`，
   `p_{i,m_i}(C(m))\ge alpha`；
2. **目标相对的近邻错误 soundness：** 对所有 `m` 和满足
   `dist(z,C(m))\le rho` 的 `z`，
   `p_{i,1-m_i}(z)\le beta`。

则：

* 任意不同消息满足
  \[
    \operatorname{dist}(C(m),C(m'))>\rho.
  \]
* 取任意 `delta<rho`，该对象给出一个 `delta`-radius relaxed LDC，查询数
  \[
  q'=O\!\left(q(alpha-beta)^{-2}\right),
  \]
  字母表和码长不变；在合法 codeword 上逐位以常数概率输出正确消息位，在任意
  `delta`-近 proof 上只输出正确位或 `\bot`。

特别地，当 `rho`、`alpha-beta`、`|Sigma|` 和 `q` 为常数时，可调用已知 relaxed-LDC
  下界，得到
\[
  N\ge k^{\,1+1/O(q'^2\log^2(q'+2))}.
\]
因此近线性 Sim-CR 构造若想避开该障碍，必须破坏 target-relative 正半径 soundness、
固定常数查询/字母表，或统一 code-family 语义；“另行假设 constant distance”不再是
逃逸选项。

## 证明

若 `m\ne m'`，取 `i` 使 `m_i\ne m'_i`。反设
`dist(C(m),C(m'))\le rho`。以 `m` 为目标、`z=C(m')` 代入第二条，得到
`p_{i,m'_i}(C(m'))\le beta`；而以 `m'` 为目标的第一条给出同一概率至少为
`alpha>beta`，矛盾。

于是 code distance 严格大于 `rho`。取任意 `delta<rho`。这里不需要把两个可能的
`delta`-邻域强制做成不相交：relaxed-LDC 的近邻保证只要求相对于所声明目标不输出
错误位，允许输出 `\bot`，因此即使两个目标邻域发生重叠，下面的单边错误控制仍然成立。

令
\[
  theta=(alpha+beta)/2,\qquad epsilon=(alpha-beta)/8.
\]
对 `V_{i,0}`、`V_{i,1}` 各独立运行 `R=Theta(epsilon^{-2})` 次，并比较经验接受率：
若恰有一个达到 `theta` 就输出其声明位，否则输出 `\bot`。

在 `z=C(m)` 上，正确分支的均值至少为 `alpha`，错误分支均值至多 `beta`；Hoeffding
界说明以常数概率两者同时落在误差 `epsilon` 内，故输出 `m_i`。若
`dist(z,C(m))\le delta<rho`，错误分支仍满足均值至多 `beta`，所以在同一事件上它
不能越过 `theta`；decoder 只能输出 `m_i` 或 `\bot`，不可能输出错误位。查询数为
`q'=2Rq=O(q(alpha-beta)^{-2})`，即上式。

## 量词边界

这是 family-level 的 target-relative 定理。若 soundness 被改成“对所有消息、所有
oracle”的统一条件，note 192 的两行代入已经说明模型为空；若 verifier 得到消息或
目标实例作为 side information，则不能直接称为 LDC decoder。单一 RW/JK 目标只有
固定目标 ACRR，不自动产生这里的 code family。

## 证据边界

距离推导和阈值化是本 note 的直接证明。relaxed-LDC 的正式定义及其
`N\ge k^{1+1/O(q'^2\log^2(q'+2))}` 下界调用 Dall’Agnol--Gur--Lachish 的结构定理；
本 note 不把该外部下界冒称为原创。它也不处理非 constant `rho,alpha,beta,q,|Sigma|` 的精细
参数，或从 distributional soundness 自动构造 target-relative verifier。

## 来源

- [Dall’Agnol--Gur--Lachish, TR20-154](https://eccc.weizmann.ac.il/report/2020/154/)
- [Gur--Minzer--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/abs/2512.12960)
- [note 188：robust-near-oracle ACRR barrier](188-anti-abort-acrr-implies-relaxed-ldc-barrier-2026-08-16.md)
- [note 190：半径—距离耦合](190-distance-free-all-oracle-acrr-relaxed-ldc-barrier-2026-08-16.md)
- [note 192：家族量词审计](192-family-quantifier-audit-for-acrr-barriers-2026-08-16.md)
