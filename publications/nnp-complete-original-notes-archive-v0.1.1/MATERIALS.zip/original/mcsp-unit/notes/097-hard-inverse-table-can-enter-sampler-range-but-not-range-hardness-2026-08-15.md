> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Hard inverse 的整张 bit-table 可以进入 sampler range，但不产生 range hardness（2026-08-15）

## 条件构造

假设有一个固定、uniform 的置换族

\[
P_m:\{0,1\}^{m}\to\{0,1\}^{m},
\qquad
\lvert P_m\rvert\le t(m),
\tag{1}
\]

其逆电路复杂度记为 \(U_m=C(P_m^{-1})\)。令
\(b=\lceil\log_2m\rceil\)、\(M=m+b\)，并把 \(j\in\{0,1\}^{b}\) 解释为索引；当
\(j\ge m\) 时约定输出 \(0\)。

定义地址和标签

\[
\widehat A(r,j)=(P_m(r),j),
\qquad
\widehat B(r,j)=
\begin{cases}
r_j,&j<m,\\
0,&j\ge m.
\end{cases}
\tag{2}
\]

\(\widehat A\) 是 \(\{0,1\}^{M}\) 上的置换。标签 \(\widehat B\) 用一个 fan-in-2
多路选择树实现，门数为 \(O(m\log m)\)（取更保守的标准 gate-list 计数也只增加
\(\operatorname{poly}(m)\)）。因此

\[
E_m(r,j)=\bigl(\widehat A(r,j),\widehat B(r,j)\bigr)
\tag{3}
\]

是 note 091 的 \(p=M\) 有效 sampler，大小
\[
t(m)+\operatorname{poly}(m).
\tag{4}
\]

它定义的函数为

\[
F_m(y,j)=
\begin{cases}
(P_m^{-1}(y))_j,&j<m,\\
0,&j\ge m.
\end{cases}
\tag{5}
\]

故

\[
TT(F_m)\in
\mathsf{SRange}_{M,M,t(m)+\operatorname{poly}(m)}.
\tag{6}
\]

## 逆复杂度的传递

若存在 size-\(S\) 电路计算 \(F_m\)，则把 \(j=0,\ldots,m-1\) 逐个硬接入并行复制
\(F_m(y,j)\)，即可得到 \(P_m^{-1}\)。因此

\[
U_m\le O\bigl(mS+m\log m\bigr),
\qquad
C(F_m)\ge
\Omega\!\left(\frac{U_m-m\log m}{m}\right).
\tag{7}
\]

所以任何 circuit-size hard permutation 都给出 sampler range 中的 circuit-hard
truth tables。这个结论是严格的，但前提是置换族本身；Birget 的条件性结果直接给出
surjections，不自动给出 permutations。

## 为什么这仍不是 range lower bound

式 (6) 只说明 range **包含**一个 hard string。给定 \(TT(F_m)\) 作为输入时，逆函数的
整张表已经在输入中；range-membership 只需回答“它是否有某个短 sampler”，并不需要
从 \(P_m\) 重新求逆。因此

\[
\text{hard member in range}
\;\not\Rightarrow\;
\text{hard range language}.
\tag{8}
\]

特别地，\(M=\Theta(m)\)，输出长度 \(N'=2^{M}\)，所以此构造仍位于
\(M=\Theta(\log N')\) 的 NP-range 区间（note 094）。它不能绕过
\(p=\omega(\log N)\) 与 fiber-consistency 的主障碍。

## 路线裁决

该构造完成了当前唯一缺失的正向传递：hard inverse 可以稳定地产生 sampler range 中
的 hard truth table。失败点也被精确隔离：要从这里得到 \(P\ne NP\)，必须再构造一个
不会把逆表本身交给 range-membership 输入的 challenge/quotient 机制，并对同一个固定
range language 证明 lower bound。Birget 的 hard surjection、该条件性 permutation
构造和 note 091 的 sampler 语义都不能单独完成这一步。

原文核验日期：2026-08-15。
