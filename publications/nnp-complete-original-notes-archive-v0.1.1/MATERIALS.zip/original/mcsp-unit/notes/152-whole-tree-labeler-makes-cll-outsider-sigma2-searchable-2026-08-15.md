> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Whole-tree labeler 将 CLL outsider 降为 Σ₂-search（2026-08-15）

## 命题：强 labeler 下第一出界节点可搜索

令

\[
G_q:\{0,1\}^q\to\{0,1\}^{2q}
\]

是统一、可在 \(\operatorname{poly}(n)\) 时间求值的 decoder；\(q(n),h(n)\) 及其
电路描述也由 \(n\) 在多项式时间内给出。把长度
\(2q\,2^h\) 的表分成 \(2^h\) 个连续的 \(2q\)-bit blocks，记叶 block 为
\(B_\nu\)。假设 \(q=\operatorname{poly}(n)\)、\(h=O(n)\)，且给定一个统一
whole-tree labeler

\[
A_n(v,\ell),
\qquad v\in\{0,1\}^{\le h},\quad \ell\in[q],
\tag{1}
\]

其单 bit 电路大小为 \(a(n)=\operatorname{poly}(n)\)。对每个叶 \(\nu\)，令
\(\rho_\nu=A_n(\nu,\cdot)\)，并要求

\[
G_q(\rho_\nu)=B_\nu.
\tag{2}
\]

对内部节点 \(v\in\{0,1\}^{<h}\) 定义候选 parent seed word

\[
Z_v:=A_n(v0,\cdot)\Vert A_n(v1,\cdot)\in\{0,1\}^{2q}.
\tag{3}
\]

labeler 的 closure 要求是：只要 \(Z_v\in\operatorname{Range}(G_q)\)，就有

\[
G_q(A_n(v,\cdot))=Z_v.
\tag{4}
\]

这里 \(A_n(v,\cdot)\) 在失败节点及其上方可任意 totalize；(4) 只对 range
节点主张。这个假设比逐叶存在 preimage 强得多，正是 whole-tree、word-consistent
closure。

若顶层表 \(W_n=B_{\epsilon}\Vert\cdots\Vert B_{1^h}\) 满足

\[
\operatorname{CC}(W_n)>q+(h+1)|G_q|+\operatorname{poly}(h,q),
\tag{5}
\]

则至少有一个内部节点满足

\[
Z_v\notin\operatorname{Range}(G_q).
\tag{6}
\]

证明很直接：若所有 \(Z_v\) 都在 range，则 (4) 从叶向根逐层给出一个
\(\operatorname{Exp}_{G,h+1}\) 的 root seed，违反 (5)。这只是 note 151 的
iterated-range outsider 定理在有 labeler 时的局部化版本。

## \(\Sigma_2^P\) 搜索界

对固定节点 \(v\)，式 (6) 等价于

\[
\operatorname{NonRange}(v)
\;\Longleftrightarrow\;
\forall u\in\{0,1\}^q,\;G_q(u)\ne Z_v.
\tag{7}
\]

因为 \(A_n\) 可随机访问，给定 \((v,j)\) 可以在 \(\operatorname{poly}(n)\) 时间
计算 \(Z_v[j]\)。因此对任意固定深度 \(j<h\) 与 prefix \(p\in\{0,1\}^{\le j}\)，谓词

\[
\exists v\in\{0,1\}^{j},\ v\succeq p\;\operatorname{NonRange}(v)
\tag{8}
\]

属于固定的 \(\Sigma_2^P\)：外层猜 \(v\)（至多 \(h=O(n)\) bits），内层是式 (7)
的全称量词，\(G_q\) 的求值是多项式时间。先对 \(j=0,1,\ldots,h-1\) 检查是否
存在该深度的 non-range 节点；取最小的成功深度后，再沿 prefix 逐位用式 (8)
选择 0-分支（若存在）即可得到该深度的字典序最小节点。总查询数为
\(O(h^2)\)（只要任意节点则为 \(O(h)\)），再用 (1) 逐位生成
\(Z_{v^*}\)。故在参数以 \(n\) 计且允许 \(\Sigma_2^P\) oracle 时，存在

\[
\operatorname{FP}^{\Sigma_2^P}\text{-算法输出一个 }2q\text{-bit outsider}.
\tag{9}
\]

若再假设 \(P=NP\)，则 \(PH=P\)，式 (9) 降为 P-uniform 的多项式时间搜索。
这一步只说明“可找到 outsider”，不说明该 outsider 本身具有 CLL 的最大电路复杂度。

## 对 coverage 的硬冲突

把节点 \(v^*\) 固定后，\(Z_{v^*}\) 的 truth table 有一个大小

\[
O(a(n)+\operatorname{polylog}q)
\tag{10}
\]

的电路：输入是 \(\log(2q)\)-bit 地址，先判断落在左/右 half，再调用
\(A_n(v^*,\cdot)\) 的相应地址。于是若 decoder 还满足

\[
\{\text{size}\le s(q)\text{ truth tables}
\}\subseteq\operatorname{Range}(G_q)
\quad\text{且}\quad
s(q)\ge O(a(n)+\operatorname{polylog}q),
\tag{11}
\]

则 (6) 与 (10) 矛盾。换言之，**coverage 加上 whole-tree labeler 不可能同时成立**；
CLL hard string 的作用只是保证某个 parent 必须出界，而不是把该 parent 变成高复杂度
表。

## 对当前路线的精确含义

1. CLL 的 hard string 已由 note 150 排除了简单的 polynomial-address 叶 evaluator，
   因而式 (1)--(4) 不是现成的 CLL 结论。
2. 若未来得到式 (1)--(4)，则“存在 first outsider”不再是难点；难点变成构造
   whole-tree labeler，或证明其与 coverage 的冲突足以迫使某个可输出的 hard branch。
3. 不能把式 (9) 写成 \(P\ne NP\)。它是一个条件性搜索接口；要得到分离，还需把
   outsider 与 RW 的 smart-\(\mathrm{prMA}\) 失败分支接起来，并保证实际 query
   长度按 \(n\) 而不是按 \(q\) 计。

因此当前最窄的剩余问题是

\[
\boxed{\text{能否在不触发 (11) 的前提下，构造 CLL/RW history 的 whole-tree labeler？}}
\]

## 来源与边界

- Lijie Chen, Jiatu Li, Jingxun Liang, *Maximum Circuit Lower Bounds for
  Exponential-Time Arthur Merlin*, ECCC TR24-182 rev.2：
  <https://eccc.weizmann.ac.il/report/2024/182/>。
- [note 150](150-cll-hard-string-forbids-polynomial-address-accessor-2026-08-15.md)：
  CLL hard string 没有 polynomial-address deterministic leaf accessor。
- [note 151](151-cll-hard-string-is-an-iterated-decoder-outsider-2026-08-15.md)：
  iterated range outsider 的无条件版本。
- [note 121](121-local-jk-smart-prma-would-separate-p-np-2026-08-15.md)：
  smart first-outsider 接口若能按目标尺度实现，才可能连接到 \(P\ne NP\)。

本 note 是条件性接口与 coverage no-go，不声称已经证明 \(P\ne NP\)。

核验日期：2026-08-15。
