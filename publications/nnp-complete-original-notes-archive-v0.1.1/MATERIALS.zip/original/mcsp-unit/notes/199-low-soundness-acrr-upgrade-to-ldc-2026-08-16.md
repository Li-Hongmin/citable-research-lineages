> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 低 soundness ACRR 的 LDC 升级窗口（2026-08-16）

## 新结果

已有的 radius-to-relaxed-LDC 归约只说明：target-relative near-oracle ACRR 给出
一个允许 `bottom` 的 relaxed decoder。近期 Cheng--Li--Mao 证明，非自适应 RLDC 在
soundness 低于 `2^{-Q}` 时会升级为同查询数的普通 LDC。两步合起来得到一个新的
明确 barrier：

> 非自适应、`q`-query、完美正确分支、错误分支概率
> `beta < 1/(2^(2q)+2)` 的 family-level ACRR，直接给出 `2q`-query LDC。

证明没有使用 projection；两个 claim verifier 的局部查询可以完全不同，只要求它们
共用同一 codeword/proof oracle。

## 关键推导

对每个坐标同时独立运行 `V_{i,0}` 和 `V_{i,1}`，仅在恰有一个接受时输出相应 bit，
否则输出 `bottom`。这给出 `Q=2q` 的非自适应 RLDC：

```text
completeness >= alpha(1-beta),
soundness <= beta.
```

当 `alpha=1` 时，取 Cheng--Li--Mao 定理中的 `epsilon=beta`，其正半径条件变为

```text
1 - beta(2 + 2^(2q)) > 0.
```

因此 `beta < 1/(2^(2q)+2)` 足够。对 `q=1`，这把 `beta<1/6` 的一般非 projection
Sim-CR 送入二查询 LDC，从而进入指数长度障碍；这是比“binary projection”更宽的
结构范围，但只覆盖低 soundness 窗口。

还有一个自适应特例：若正确 claim 在 codeword 上完美接受、错误 claim 在 codeword 上
零接受，则两分支 decoder 自身完美完备，不需要原 verifier 非自适应。此时 Cheng--Li--Mao
的 perfect-completeness 版本只要求 `beta<2^(-2q)`，同样得到 `2q`-query LDC，半径
满足 `delta<rho(1-beta 2^(2q))/(4q)`。所以 adaptive 只有在伴随非零 codeword 错误
接受/不完美完备性时，才是本路线的真实边界。

对一般 adaptive verifier，固定随机带后把深度 `q` 的答案决策树全部位置并行查询即可
保持接受概率。若 `U=1+|Sigma|+...+|Sigma|^(q-1)`，两分支只需 `Q=2U` 个非自适应
查询；因此完美分支下同样有 `beta<1/(2^Q+2)` 的 LDC 升级窗口。这说明 adaptive
不是逻辑上的免费逃逸，但查询树展开可能破坏实际的地址尺度。

## 重要边界

这不是一般 ACRR 不可能性。若 `beta` 是普通常数，或 verifier 自适应且不满足上述
完美分支特例，proof 不是
消息族的 injective code map，现有推导只到 relaxed-LDC 或完全不适用。因而当前主线
更准确的二分是：

1. 低 soundness + 非自适应：LDC barrier；
2. 常数 soundness + 正半径：一般 relaxed-LDC barrier；
3. 单实例、无高熵 family 或 post-coordinate interaction：仍需新的 JK/通信障碍。

这把“允许 `bottom`”从一个二元标签问题细分成可量化的 soundness 相变，而不是把
所有 relaxed ACRR 都误报成普通 LDC。

## 证据边界

Cheng--Li--Mao 的低 soundness RLDC-to-LDC 是外部输入；本项目新增的是两分支 ACRR
到 RLDC 的精确参数合成及其 ACRR 窗口。该结论尚不足以解决 `P != NP`，但可作为
T2 反向路线的正式、可复核定理入口。

## 来源

* [Cheng--Li--Mao, arXiv:2603.03717](https://arxiv.org/abs/2603.03717)
* [ACRR top-tier program](189-top-tier-acrr-theorem-program-2026-08-16.md)
* [Radius-to-relaxed-LDC barrier](../../rw-jk-succinct-reconstruction/statements/radius-to-relaxed-ldc-barrier.md)
