> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Repeated-read 与非线性有限记忆的 Closure Gate（2026-08-19）

## 本轮改变的判断

C463 的全序 ROABP/OBDD 结果刻意留下了两个边界：允许重复读取，以及允许一般的
非线性工作状态。C449 已说明有限可见状态的 non-product 包装会回到 RLDC，但它的
参数是可见 transcript 数，不能直接处理一个 fixed-target、可以反复读取同一静态
descriptor 的地址机器。下面给出一个 singleton 版本的电路展开定理：只要每次状态
转移和每次静态 ROM 读取都按普通 fan-in-2 规模计价，重复读取和非线性状态不会产生
新的地址尺度逃逸。

## 定义：bounded-transition repeated-read evaluator

令 \(H\in\{0,1\}^N\)，地址长度为 \(m=\lceil\log_2(N+1)\rceil\)。一个
\((T,q,s,d,g)\)-evaluator 包含：

* 一条固定 descriptor \(\sigma\in\{0,1\}^d\)，所有地址共用同一条 \(\sigma\)；
* \(s\) 位工作状态和至多 \(T\) 个 transition；
* 总共至多 \(q\) 次对 \(\sigma[j]\) 的 bit-read。read 可以自适应，且允许重复同一
  个 \(j\)；
* 每个 transition 的 next-state、下一 read-index 和是否 read 的联合布尔逻辑，
  在给定地址、当前状态及最近读值后，由一个 fan-in-2 电路实现，大小至多 \(g\)。

初始状态、终止输出位和 evaluator 的控制描述均可依赖地址 \(a\)，但不依赖
目标 \(H\) 之外的另一份地址特定 advice。读到 \(\sigma[j]\) 的标准实现是一个
\(d\)-输入 multiplexer；若把它当作 unit-cost oracle，则不属于本定义。
transition 电路中的 hardwired constants 也属于 \(g\) 的描述成本；不允许把
目标 \(H\) 的位藏进一个未计价的 target-dependent transition truth table。

## 定理 465.1（repeated-read nonlinear-memory circuit expansion）

若上述 evaluator 对所有 \(a\in[N]\) 输出同一个对象的位

\[
E(a;\sigma)=H[a],
\]

则存在普通 fan-in-2 电路 \(C\)，满足

\[
 \operatorname{CC}(H)
 \le c_0\bigl(Tg+qd+m+1\bigr),
 \tag{465.1}
\]

其中 \(c_0\) 为绝对常数。特别地，重复读的次数按 \(q\) 逐次计价；非线性状态
不会改变这个上界，只会体现在每个 transition 的 \(g\) 中。

### 证明

把 evaluator 的 \(T\) 个 transition 按时间展开。第 \(t\) 步的 next-state、
read-index 和 read-control 电路复制一次，共产生至多 \(O(g)\) 个门。每次实际
读取 \(\sigma[j]\) 用固定的 \(d\)-输入 multiplexer 替换，规模为 \(O(d)\)；即使
同一个 \(j\) 被重复读取，也逐次替换，因此总读取开销为 \(O(qd)\)。把 \(\sigma\)
的每一位接到常数线上，地址 \(a\) 保留为 \(m\) 个输入，终止状态的输出位直接作为
电路输出。合并 \(Tg\)、\(qd\) 和地址/边界的常数项，得到 (465.1)。证毕。

## Forcing-scale 推论

若在同一无限长度集合上

\[
 \operatorname{CC}(H_N)>S_N,
 \qquad m_N=\lceil\log_2(N+1)\rceil,
\]

则任何满足上述 same-object、same-descriptor 语义的 evaluator 必须支付

\[
 Tg+qd+m_N+1=\Omega(S_N).
 \tag{465.2}
\]

因此在 \(d,g,m=\operatorname{poly}(m)\) 且 \(T,q=\operatorname{poly}(m)\) 的
地址尺度窗口内，不可能恢复 forcing-hard 对象。更定量地，若
\(Tg+m+1=o(S_N)\)，则

\[
 qd=\Omega(S_N);
 \tag{465.3}
\]

若 \(qd+m+1=o(S_N)\)，则 \(Tg=\Omega(S_N)\)。这把重复读取与非线性工作状态
归入一个清楚的二择一：要么读取本身承担 object-scale descriptor 代价，要么
状态转移承担 object-scale 计算代价。

## 对 C463 与 RW Closure 的含义

1. C463 的两个未覆盖词“repeated reads / nonlinear memory”并不自动构成
   model exit。只要它们由一个共同静态 descriptor、有限次读取和显式 fan-in-2
   transition 实现，定理 465.1 直接给出 address-scale 电路上界。
2. 在 RW 的 hard-length \(S_N\) 上，若 proposed evaluator 的地址、状态、转移和
   读取总成本均为 \(\operatorname{poly}(\log N)\)，则它直接进入 \(P/\mathrm{poly}\)
   Closure；若仍声称保持 same-object，则 (465.2) 强迫至少一个资源达到
   forcing scale。
3. 这一定理比 C207 的静态-ROM 公式更宽：它不要求 straight-line 控制，不要求
   每个地址最多一次读，也不要求状态是线性或 read-once 的。它补上的是 bounded-
   transition nonlinear RAM 这一具体 Gate-II 语义，而不是一般电路下界。

## 仍然开放的真正 model exits

定理不覆盖、也不能悄悄计入 (465.1) 的情形只有以下几类：

* 把长度为 \(d\) 的 ROM 读取当作 unit-cost oracle，或不计价一个任意大转移真值表；
* \(T\)、\(q\) 或 \(g\) 超过地址尺度，达到 object-scale；
* 不同地址使用不同 descriptor/proof/sheet，因而不再是一个 common object 的
  evaluator；
* read index 需要访问另一条未计价的 global memory，等价于把 descriptor 成本挪到
  第二个 ROM。

这些不是本定理的反例，而是必须在 Closure Theorem 中显式声明的新资源或新量词。
因此，当前 repeated-read/nonlinear-memory 分支已经从“未命名的 representation
逃逸”收紧为一个可检验的 bounded-transition payment gate；它仍不证明实际 RW
canonical history 有 evaluator，也不证明 \(P\ne NP\)。

## 与已有结果的关系

* C207/Note 220 给出静态 ROM evaluator 的 forcing-scale descriptor 下界；
  定理 465.1 将其推广到自适应、重复读取和非线性有限状态。
* C449/Note 449 处理有限可见 global-state 的 family-level RLDC 编译；定理 465.1
  处理 fixed-target singleton 的直接 fan-in-2 展开，避免把不存在的目标熵强行引入。
* C463/Note 463 负责 read-once ordered representation 的通信秩障碍；定理 465.1
  负责其余 bounded-transition evaluator 类，两者的交集是同一 common-address
  语义，而非一般 Boolean circuit lower bound。

## 证据边界

这是一个自足的模型化电路展开定理和 RW forcing-scale Closure Gate。它只依赖标准
fan-in-2 电路对显式 transition 与静态 ROM 的计价；它没有证明所有可能的 nonlinear
global relations 都能表示成该模型，更没有把条件性 Closure Theorem 晋级为
无条件 \(P\ne NP\) 证明。
