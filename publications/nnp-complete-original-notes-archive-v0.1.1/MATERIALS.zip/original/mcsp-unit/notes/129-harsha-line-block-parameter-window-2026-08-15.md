> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha PCP line-block 的半率参数窗口（2026-08-15）

## 参数计算

令 \(s\) 是 Ren--Williams Theorem 3.4 中输入电路 \(C_x\) 的大小，并采用
Harsha 的参数
\[
m=\left\lceil\frac{\log s}{\log\log s}\right\rceil,\qquad
|H|=s^{1/m},\qquad
|F|=\Theta\!\bigl(m|H|\bigr)^3.
\]
于是
\[
|H|=\Theta(\log s),\qquad
\log|F|=O(\log\log s).
\]

完整性证明中的三个 oracle families 可按固定平行线分块：

1. \(\widetilde A:F^m\to F\)，总度至多 \(d=m|H|\)；
2. \(P:F^{3m+3}\to F\)，总度至多 \(d'=(6m+3)|H|\)；
3. \(\Pi_{\rm ZoS}:F^{3m+3}\to F^{6m+6}\)，其每个 bundled component
   是相应的低度 \(P_i/Q_i\) polynomial。

一条 line 上的 degree-\(D\) restriction 由 \(D+1\) 个 field coefficients
决定。故最大 bundled line 的 coefficient description 长度为
\[
s_{\rm coeff}
 =
O\!\left((6m+6)d'\log|F|\right)
 =
O\!\left(m^2|H|\log|F|\right)
\quad\text{bits}.
\tag{1}
\]

同一 bundled line 的 evaluation block 长度为
\[
B_{\rm line}
 =
\Theta\!\left((6m+6)|F|\log|F|\right)
 =
\Theta\!\left(m|F|\log|F|\right)
\quad\text{bits}.
\tag{2}
\]
因为 \(|F|=\Theta(m|H|)^3\)，有
\[
\frac{B_{\rm line}}{s_{\rm coeff}}
=\Omega\!\left(\frac{|F|}{m|H|}\right)
=\Omega\!\left(m^2|H|^2\right)
=\operatorname{polylog}(s).
\tag{3}
\]
所以可以选
\[
q=\Theta(B_{\rm line})=\operatorname{polylog}(s)
\]
（再吸收 line address、oracle tag 和固定 padding），使每个 line block 的
coefficient seed 不超过 q bits，而输出 block 恰为 \(2q\) bits。

## Decoder 大小

对每个 line，seed 解析出其 \(P_i/Q_i\) coefficients 和 line address；用
加性 FFT 或标准 quasi-linear multipoint evaluation 产生该 line 的所有 field
values，再二进制展开。由 note 127，
\[
|G_q|=q\,\operatorname{polylog}q.
\tag{4}
\]
line address 只需
\[
O\!\left((3m+3)\log|F|+\log \#\text{segments}\right)
=O(\log s)
\]
bits，因此不会破坏式 (1)--(4) 的窗口。

将 PCP proof 按 \((\text{oracle family},\text{line address},\text{point})\)
的固定顺序排布，verifier 的原有 point query 只需执行一个固定地址转换；
这改变编码顺序但不改变 PCP 的接受关系。于是：

\[
\boxed{
\text{Harsha completeness proof 的每个 leaf line block
有一个 }q=\operatorname{polylog}(s)\text{、}
q\operatorname{polylog}q\text{ 大小的 decoder。}
}
\tag{5}
\]

## 不能越过的边界

式 (5) 只解决 leaf layer。JK 的下一层把两个 q-bit coefficient seeds 串接；
若相邻 lines 的 coefficients 独立，父节点需携带约 \(2s_{\rm coeff}\) bits，
继续递归后触发 note 128 的 \(R s_{\rm line}>q\) 容量界。要把式 (5) 推到
整个 \(\operatorname{Solve}_f\) failure branch，仍必须给出：

- canonical lex-first seed 与 algebraic seed 一致，或 choice-robust 的替代；
- 跨 line 的 whole-tree global labeler；
- 对 bundled proof 的 address/field representation 保持 word consistency。

Ren--Williams Theorem 4.1 目前只提供 q-scale 的 smart-\(\mathrm{prMA}\)
重构，不提供这些递归条件。[Ren--Williams official report](https://eccc.weizmann.ac.uk/report/2026/118/revision/1/download)

Harsha 的 polynomial-oracle completeness 细节见
[official thesis PDF](https:/[unbundled local reference].ttic.edu/~prahladh/papers/thesis/phdthesis.pdf)。
本文是一个可核验的 leaf-layer 正面参数结果，不声称已经证明 \(P\ne NP\)。
