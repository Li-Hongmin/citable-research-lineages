> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Colored truth-table isomorphism 扩大置换轨道的 P 闭合区间（2026-08-15）

## 结论

以下把 \(t=t(m)\) 视为一个固定且可由 \(m\) 在 \(\operatorname{poly}(n)\) 时间取得的参数日程；
这样 \(L_t\) 才是一个统一的语言，而不是把每个长度的阈值当作外部不可计算参数。

note 100 通过枚举 support-preserving completion 得到
\((D'_t+t)\log(m+t)=O(m)\) 时的 P 上界。若把剩余 direct-output 的任意重排交给
dense truth-table 的 **colored variable-isomorphism** 算法，则可以删除 \(D'_t\) 项：

\[
t(m)\log_2(m+t(m)+2)=O(m)
\quad\Longrightarrow\quad
L_t\in\mathsf P.
\tag{1}
\]

当 \(t\le m\) 时，足够的具体区间是

\[
t=O\!\left(\frac{m}{\log m}\right)
=O\!\left(\frac{\log n}{\log\log n}\right),
\qquad n=2^m.
\tag{2}
\]

这严格扩大了 note 100 的 \(t\) 约为 \(\log m\) 的闭合范围。

## Colored truth-table equivalence 子程序

使用如下 dense-table 问题：给定两个 \(m\)-变量 Boolean truth tables \(F,G\)，以及一个
变量分割 \(V\sqcup U\)，决定是否存在只置换 \(U\)、固定 \(V\) 的 \(\pi\)，使

\[
F(v,u)=G(v,\pi(u))
\quad\text{对所有 }(v,u)\in\{0,1\}^{|V|}\times\{0,1\}^{|U|}.
\tag{3}
\]

这是 Luks 对 Boolean-function structural equivalence 的 colored 版本：把 \(V\) 作为
singleton color classes、\(U\) 作为一个可置换 color class，原有的 truth-table variable
isomorphism 算法仍在输入表长度 \(2^m=n\) 的多项式时间内运行。这里使用的是变量坐标的
置换，不是 \(\{0,1\}^m\) 行地址的任意置换；颜色约束直接作为保色变量等价的输入限制。

## 归约

固定一个至多 \(t\) 门 gate list \(G\)。枚举 \(k\le t\) 个被 output selectors 选中的
distinct gate wires、它们到 \(k\) 个 output positions \(P\subseteq[m]\) 的有序双射，以及
遗漏的输入变量集合 \(J\subseteq[m]\)，\(|J|=k\)。写

\[
r=(v,u),\qquad v=r|_J,\quad u=r|_{[m]\setminus J},
\]

并令 \(g_G(v,u)\in\{0,1\}^k\) 是选定 gate wires 的输出向量。先检查

\[
\forall u,\qquad
v\longmapsto g_G(v,u)
\text{ 是 }\{0,1\}^k\text{ 上的双射}.
\tag{4}
\]

这是 \(n\cdot\operatorname{poly}(m,t)\) 时间的穷举。它等价于：无论 direct inputs 如何
排列，选定 gate outputs 与 direct outputs 合起来都能成为一个 \(m\)-bit 置换。

令 \(\operatorname{Pack}_P(w,z)\) 把 \(w\) 放到 \(P\) 的有序位置，把 \(z\) 按固定顺序
放到其余位置。对输入 truth table \(y\)，构造两个 \(m\)-变量 truth tables：

\[
H_{G,J,P}(v,u)
=
y\!\left(\operatorname{Pack}_P(g_G(v,u),u)\right),
\tag{5}
\]

\[
T_J(v,u)=r_1.
\tag{6}
\]

若 direct outputs 的真实排列为 \(\pi\)，其中 \(\pi\) 表示按 \(U\) 的固定坐标顺序置换 \(u\)，则相应
sampler/permutation 满足

\[
y(A_\pi(v,u))=T_J(v,u)
\quad\Longleftrightarrow\quad
H_{G,J,P}(v,\pi(u))=T_J(v,u).
\tag{7}
\]

因此对每个 \((G,K,P,J)\)，明确调用
\(\operatorname{ColorEq}(F=T_J,G=H_{G,J,P})\)，即按 (3) 检查
\(T_J(v,u)=H_{G,J,P}(v,\pi(u))\)；有一个候选通过就接受。

## 正确性与复杂度

若 \(y=h_m\circ A^{-1}\)，取 \(A\) 的真实 gate list、非直接 wires、output positions 和
遗漏集合 \(J\)。置换性给出 (4)，而真实 direct-output permutation \(\pi\) 使 (7) 成立，
所以 colored equivalence 子程序接受。

反向地，若某候选通过 (3)，取其见证 \(\pi\)，定义
\[
A_\pi(v,u)=\operatorname{Pack}_P(g_G(v,u),\pi(u)).
\]
由 (4)，对每个固定 \(u\)，\(g_G(\cdot,u)\) 是双射；再加上 direct coordinates 的
双射排列，\(A_\pi\) 是 \(\{0,1\}^m\) 的置换。式 (7) 给出
\(y(A_\pi(r))=r_1\)，故 \(y=h_m\circ A_\pi^{-1}\) 属于轨道。

gate lists 数量为 \(2^{O(t\log(m+t+2))}\)；\(K,P,J\) 的枚举只增加同阶因子。每个候选的
truth-table 构造、(4) 检查和 colored equivalence 都是 \(\operatorname{poly}(n,m,t)\)。
总时间为

\[
\operatorname{poly}(n,m,t)\,
2^{O(t\log(m+t+2))}.
\tag{8}
\]

在 (1) 下这是 \(n^{O(1)}\)，证明结论。

## 路线裁决

固定标签 \(h_m(r)=r_1\) 的置换轨道若要避开本 note 的统一多项式上界，就不能落在
\(O(m)\) 区间；一个简洁的充分困难尺度是

\[
t(m)\log(m+t(m)+2)=\omega(m)
\tag{9}
\]

式 (9) 只是一个简洁的充分困难尺度；更精确地说，定理排除的是左侧为
\(O(m)\) 的日程，非 \(O(m)\) 但振荡的日程不由本 note 分类。与 note 100 相比，困难区间从
\(t\) 约为 \(\log m\) 推到了 \(t\) 约为 \(m/\log m\)；换成 truth-table 长度后，仍有
\(t=O(\log n/\log\log n)\) 的完整算法性 no-go。

这不覆盖 \(t=n^\beta/(m+1)\) 的稀疏 hardness-magnification 族，也不提供一般电路下界。
它只说明：若要继续使用这个 fixed-label quotient，不能把 direct-coordinate permutation
本身当作未处理的组合爆炸；真正未解决的障碍必须来自 gate-output fiber map 或更大的
gate budget。

## 文献与适用边界

- Eugene M. Luks, *Hypergraph Isomorphism and Structural Equivalence of Boolean Functions*,
  STOC 1999, pp. 652--658, DOI 10.1145/301250.301427；ResearchLibrary
  luks1999hypergraph/info.yaml。本文只使用其 dense truth-table variable-permutation
  equivalence 的 colored restriction。
- 该结果作用于 \(m\) 个 Boolean variables 的坐标置换；不等同于对 \(2^m\) 个 truth-table
  rows 的任意 permutation，也不直接给一般 decoder range lower bound。

原文核验日期：2026-08-15。
