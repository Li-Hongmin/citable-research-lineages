> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Published RW 输出的 source 对齐与 direct-scale 边界（2026-08-19）

## 本轮改变的判断

C455 已把 forcing 下界实例化到 Ren--Williams Theorem 4.3 的同一个输出
\(B_n=A'(1^n)\)，但保留了它是否等于 C453--C454 source-compatible parent 的缺口。
在假设 \(P=NP\) 的 Closure 分支中，这个对象缺口可以关闭：prMA 的完美完备性允许
把所有 promised query 确定化，而 smartness 保证实际运行不访问 promise gap。于是
\(A'\) 可改写为一个固定确定性多项式时间 machine \(M\)，在 regular source
\(x_n=(1^n,a_n)\) 上逐字输出同一个 \(B_n\)。C453--C454 因而可以针对 published
hard output 实例化，而不是针对相邻的条件性 parent。

这仍不闭合 \(P\ne NP\)：published direct simulation 的时间、query encoding 与
witness scale 只保证 \(N_n^{O(1)}\)，并未给出 \(\operatorname{poly}(\log N_n)\)
random access。C457 进一步说明：同一 serialization 上 Harsha
\(P=p(q)\) 的 generic-point evaluator 与 generic \(q\)-access 多项式等价；剩余
factorized 缺口实质上是 actual proof table 的 generic \(q\)-random access。

## 设置

令 \(A'\) 是 Ren--Williams Theorem 4.3 对 truth-table generators
\[
  G_n:\{0,1\}^n\to\{0,1\}^{2n}
\]
给出的固定 smart-\(\mathrm{FP}^{\mathrm{prMA}}/1\) oracle algorithm，令 \(a_n\in\{0,1\}\)
为其正确 advice bit。取 C455 的无限 good-length 集合 \(\mathcal I\)，并记
\[
  B_n:=A'(1^n,a_n),\qquad N_n:=|B_n|=2n
  \qquad(n\in\mathcal I).
\tag{456.1}
\]

固定 prMA-complete verifier \(V(q,w;r)\)。其 witness 和 random tape 长度均为
\(|q|^{O(1)}\)，且 promise 为
\[
\begin{aligned}
q\in\Pi_{\rm YES}&\Longrightarrow
  \exists w\ \Pr_r[V(q,w;r)=1]=1,\\
q\in\Pi_{\rm NO}&\Longrightarrow
  \forall w\ \Pr_r[V(q,w;r)=1]\le\tfrac12.
\end{aligned}
\tag{456.2}
\]

## 定理 456.1（published hard-output source alignment）

假设 \(P=NP\)。存在一个固定确定性多项式时间 machine \(M\)，使对每个
\(n\in\mathcal I\)，在
\[
  x_n=(1^n,a_n)
\]
上有逐位和整词恒等
\[
  M(x_n)=B_n.
\tag{456.3}
\]
把 \(M\) 作为 C453 的 zero-round source machine，并采用该 note 的 hist-first
cell-time serialization 与 C454 的 fresh output-check block，则对每个
\(j\in[N_n]\)，对应 systematic Harsha coordinate \(u_j\) 满足
\[
  q(u_j)=B_n[j].
\tag{456.4}
\]
机器、layout rule 与 output-check gadget 对所有长度固定；只有 regular source
\(x_n\) 和长度参数变化。

### 证明

定义完整接受语言
\[
  L_{\rm all}:=
  \{q:\exists w\ \forall r\ V(q,w;r)=1\}.
\tag{456.5}
\]
由 witness、random tape 与 verifier 的多项式界，\(L_{\rm all}\in\Sigma_2^P\)。
在 \(P=NP\) 下，\(PH=P\)，故存在固定确定性多项式时间判定器 \(D_{\rm all}\)
决定 (456.5)。由 (456.2)，对每个 promised query，\(D_{\rm all}\) 在
\(\Pi_{\rm YES}\) 上输出 \(1\)，在 \(\Pi_{\rm NO}\) 上输出 \(0\)。

令 \(M\) 读取 source 的最后一位 \(a\)，模拟固定分支 \(A'_a(1^n)\)，并把每次
prMA oracle call 替换为 \(D_{\rm all}\)。Theorem 4.3 的 smartness 保证：在正确
advice \(a_n\) 下，所有实际 query 都属于
\(\Pi_{\rm YES}\cup\Pi_{\rm NO}\)；因此模拟不会读取 promise gap 上未定义的答案，
且每次 oracle answer、控制分支和输出均与 \(A'(1^n,a_n)\) 相同。这证明 (456.3)。
advice 序列不需要由 \(M\) 生成；在逐长度的 \(P/\mathrm{poly}\) 论证中，正确的一位
advice 作为 source bit 固定即可。

source \(x_n\) 是 unary block 加一个 advice bit，其 initialization track 可由固定有限状态
规则按地址生成。确定化后的 \(M\) 不发出 NP query，所以 C453 中可取
\[
  |x_n|=n+1,\qquad t(n+1)=n^{O(1)},\qquad r=s=0,
  \qquad \ell(n+1)=2n.
\tag{456.6}
\]
C453 的 projection equivalence 使每个 satisfying history 的 out block 等于
\(M(x_n)=B_n\)。C454 再用 equality gadget 强制
\(\mathrm{out}_j=\mathrm{sim}_j\)，故相应 systematic assignment polynomial 满足
\(q(u_j)=B_n[j]\)，得到 (456.4)。C454 中的 \(x_0\) 只是一次固定 context 的记号；
其证明逐 source 成立。对每个长度取 \(x_0=x_n\)，同时保持 \(M\) 与 serialization
uniform，即得整个长度族。证毕。

## 命题 456.2（published direct surface 仍是 object scale）

上述确定化直接给出的 bit evaluator 只有
\[
  \operatorname{CC}(B_n)\le N_n^{O(1)},
\tag{456.7}
\]
而非 \((\log N_n)^{O(1)}\)。更具体地，Theorem 4.3 的原始 induction 满足
\[
  s_i=n_i,\qquad r_i=O(n_i),
\tag{456.8}
\]
最终 \(A_0,A_1\) 也只保证在显式 unary input \(1^n\) 上运行于
\(\operatorname{poly}(n)\) 时间。忠实展开其 prMA query、witness、random tape 与
matrix computation 因而给出 object-scale surface。C455 的
\(\Omega(N_n/\log N_n)\) forcing 下界与 (456.7) 相容。

### 证明

Theorem 4.3 明确递推 \(s_{i+1}=\max\{s_i,n_{i+1}\}\)，故 \(s_i=n_i\)；同一证明
给出 \(r_i=O(n_i)\)，并只把最终 algorithms 的时间压到 \(\operatorname{poly}(n_i)\)。
在 \(P=NP\) 下用 \(D_{\rm all}\) 替换 oracle 仍只保留这个多项式于 \(n\) 的上界。
把固定地址 \(j\) 的完整模拟电路化得到 \(n^{O(1)}=N_n^{O(1)}\)，但没有任何源文步骤
把 query encoding、witness selection 或整段模拟压到 \(\operatorname{poly}(\log N_n)\)。
因此 Paper 04 Proposition 1.3 的 address-scale PH-surface 假设不能由 published direct
surface 自动满足。这里是 source-level 路线关闭，不是不存在另一种 succinct compiler
的下界。证毕。

## 对 Closure 的精确影响

1. C455 的 published \(B_n\) 与 C454 的 source-compatible systematic parent 已在
   \(P=NP\) 分支对齐；不再需要额外假设二者是同一个对象。
2. C453--C454 的 serialization 是本项目构造的等价 replacement，不是原文指定的 gate
   numbering；其合法性来自 history projection、out 语义与固定 machine uniformity。
3. stable/direct route 仍停在 object scale。要触发 C455 矛盾，必须再给出
   \(\operatorname{poly}(\log N_n)\) random access，不能只重新电路化 \(A_0/A_1\)。
4. 在 factorized Harsha route 中，\(\widehat D_{\rm inc}\)、incidence 与 published
   forcing object 已对齐。C457 进一步证明 \(P=p(q)\) generic access 与 \(q\)-access
   多项式等价；真正剩余的是 actual proof serialization 的 generic \(q\)-random access。
   若它为 \(\operatorname{poly}(\log N_n)\)，(456.4) 将直接违反 C455。

## 证据边界

* 结论只在假设 \(P=NP\) 的反证分支和 Theorem 4.3 的 good lengths 上使用；这正是
  Closure 所需的量词，不是无条件算法。
* 正确 advice bit 可以逐长度非一致固定；本文不证明其 P-uniform 生成。
* 命题 456.2 只关闭 published/direct representation，不排除新的 witness-compression、
  canonical-selection 或 RW-specific succinct surface。
* 本结果不提供 generic \(q\)-evaluator；C457 说明 \(P\)-access 只是它的等价表述。
  本结果不单独证明 \(P\ne NP\)。

## 来源

* Ren--Williams ECCC TR26-118 revision 1，Definition 2.1、Theorems 4.1、4.3、4.5。
* [C453 local-tableau compiler](453-rw-lex-prefix-preserving-local-tableau-compiler-2026-08-19.md)。
* [C454 source-compatible incidence](454-rw-source-compatible-incidence-auxiliary-barrier-2026-08-19.md)。
* [C455 published forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
