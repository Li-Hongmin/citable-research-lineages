> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 高阶极小 witness 的单边质量界与剩余缺口（2026-08-13）

## 单个 (k)-见证

固定 spoiler (s)，令 (T) 是关于 (s) 的 inclusion-minimal collision witness，

\[
|T|=k,
\qquad L(T)\ne\varnothing,
\qquad L(T\cup\{s\})=\varnothing,
\]

且删去 (T) 中任一 cell 后与 (s) 相容。由 note 032 的秩增一引理，

\[
\operatorname{rank}(A_T)\ge k+1.
\tag{1}
\]

设 (p=|\pi_X(T)|)、(q=|\pi_Y(T)|)。矩阵 (A_T) 的行只来自这 (p) 个
(q_x=(x,1)) 与这 (q) 个 (p_y=(y,1))，故

\[
\operatorname{rank}(A_T)\le p+q.
\tag{2}
\]

于是 (p+q\ge k+1)。随机 affine 参数命中 (T) 的概率至多
(2^{-(k+1)})，而行、列 thinning 保留其端点的概率为 (2^{-(p+q)})。因此

\[
\boxed{
\Pr[T\subseteq R_z(U,V)]
\le 2^{-(k+1)-(p+q)}\le 2^{-2k-2}.}
\tag{3}
\]

对 (k=3) 得 (2^{-8}=1/256)，正是 note 033 三元闭合所用的单边界。

## 均匀阶族的直接推论

若 \(\mathcal F_k\) 是所有大小为 (k) 的极小 witness 组成的有限族，则并界给出

\[
\Pr[\exists T\in\mathcal F_k:T\subseteq R_z(U,V)]
\le |\mathcal F_k|\,2^{-2k-2}.
\tag{4}
\]

所以只要

\[
|\mathcal F_k|\le 2^{2k-2},
\tag{5}
\]

该阶单独贡献就不超过 (1/16)。对混合阶族，同理有可审计的加权并界

\[
\Pr[\exists T:T\subseteq R_z(U,V)]
\le \sum_{k\ge1}|\mathcal F_k|\,2^{-2k-2},
\tag{6}
\]

其中 \(\mathcal F_k\) 表示大小为 (k) 的极小见证。

## 覆盖数二的粗界

设 \(\mathcal F_k\) 为均匀 (k)-元族，cover 为 \(\{a,b\}\)。取任意
\(B\in\mathcal F_b\)，其中 (b\in B)、(a\notin B)。每个
\(T\in\mathcal F_a\) 必须在 (B\setminus\{b\}) 中命中一个 cell；否则
\(T\) 与 (B) 不交。因此

\[
E_a\subseteq\bigcup_{c\in B\setminus\{b\}}\{a,c\text{ 被保留}\},
\qquad
\Pr[E_a]\le\frac{k-1}{64}.
\]

对称地 \(\Pr[E_b]\le(k-1)/64\)，而同时命中 (a,b) 的部分至多
\(1/64\)。故

\[
\Pr[E]\le\frac{2k-1}{64}.
\tag{7}
\]

这个界在 (k=3) 时不足以达到 (1/16)，三元情形需要 note 033 的
2-族分类；对 (k\ge4) 则更不足。它只说明覆盖数二的困难已经精确转化为高阶
cross-intersection 的联合质量，而不是单个见证的参数秩。

## 为什么这还不是完整高阶证明

一般两两相交的 (k)-uniform 族在覆盖数至少三时，族大小可以随底层点集增长；
Erdős--Lovász 的 \(\tau=k\) 粗界 (k^k) 代入 (4) 也不足以得到 (1/16)
（例如 (k=4) 时粗界给出 (1/4)）。因此，(1)--(3) 只排除“见证数受控”的
高阶分支，不能替代高阶 affine-biclique EKR。

当前已严格闭合：

* singleton / 二元极小见证：note 031；
* 全部极小见证为三元：note 033；
* 任意阶但每阶满足 (5) 或混合和式 (6) 足够小的族：本记录。

剩余原子问题是 (k\ge4)、覆盖数至少三、且见证族规模随 (N) 增长时的跨 affine 参数联合质量界。
