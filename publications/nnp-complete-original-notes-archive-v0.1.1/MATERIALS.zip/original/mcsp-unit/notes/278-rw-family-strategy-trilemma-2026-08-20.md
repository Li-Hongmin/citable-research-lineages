> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW family--strategy trilemma at the JK forcing scale

## Purpose

The RW attachment has two natural ways to manufacture the high-entropy family
needed by a JK/RLDC closure: vary the input/history, or keep one common proof and
vary a target-dependent reconstruction policy.  The first route is limited by the
actual number of history windows (C266).  The second route is limited by the
average-defect common-fiber theorem (C277).  Combining the two gives a source-specific
trilemma with explicit constant thresholds.

This is not a proof that the RW construction itself supplies either interface.  It is a
conditional theorem saying that an eventual closure cannot use both routes cheaply at the
same stable stage.

## Theorem (RW family--strategy trilemma)

Fix the RW recurrence

\[
 q_i=n_{i+1}=n_i^C,\qquad
 T_i=\max\{2^{cD^i n_0},n_{i+1}\},
 \qquad C>D+1,
\tag{278.1}
\]

and let each selected canonical/actual history have length at most \(T_i^a\), for a
constant \(a\).  Let \(\nu_i\le n_i\) be the input length.  Suppose a proposed closure
at this stage has a fixed finite proof alphabet and fixed locality/radius/gap parameters
for which the relevant RLDC lower bound rules out proof length

\[
 P_i\le K_i(\log(K_i+2))^b
\tag{278.2}
\]

for a payload dimension \(K_i=\Theta(q_i)\).  Then, for all sufficiently large stable
stages, at least one of the following must occur.

1. **History-supply payment.**  If the proposed JK forcing uses only actual disjoint
   dyadic aligned depth-\(h\) groups from the selected histories, then reaching the
   tree-capacity threshold \(|\mathcal T_{i,h}|>2^{q_i}\) requires

   \[
   \nu_i+a\log_2 T_i
   \ge q_i+\log_2(2q_i)+h.
   \tag{278.3}
   \]

   In particular, under the RW bounds \(\nu_i\le n_i\) and
   \(\log T_i=o(q_i)\), the existing input/history family is
   \(2^{o(q_i)}\) and cannot trigger JK capacity.  To force (278.3) by length alone
   requires \(T_i\ge 2^{(q_i-\nu_i-O(\log q_i+h))/a}\), making the corresponding
   `Solve` call exponential in the child width.

2. **Policy payment.**  Alternatively, suppose the closure supplies one common proof
   map \(\Pi_i:\{0,1\}^{K_i}\to\Sigma^{P_i}\) and a target-dependent global policy
   package \(S_i\), containing all coordinate/claim verifiers and filters in one common
   address space.  Let \(\bar\delta_i\) be the scalar max-before-average robust defect
   and \(I_i=I(M_i;S_i)\) its target mutual information, as in C277.  Fix any
   \(0<\eta<1/2\) and margin \(0<\Delta< (\alpha-\beta)/2\) with
   \(\alpha-\Delta\ge c>s\ge\beta+\Delta\).  There are constants
   \(\varepsilon_\delta=\eta\Delta/2>0\) and
   \(\varepsilon_I>0\), depending only on \(\eta\) and the coding window, such that
   a near-linear package (278.2) must satisfy

   \[
   \bar\delta_i\ge\varepsilon_\delta
   \qquad\text{or}\qquad
   I_i\ge\varepsilon_I K_i.
   \tag{278.4}
   \]

   More explicitly, one may take any fixed
   \(\varepsilon_I<(1-\eta)/8\), after increasing the minimum stage so that the
   additive entropy constants are absorbed.

3. **Model escape.**  If neither payment is made, the construction must leave at least
   one of the hypotheses used above: a common proof/address space, a finite fixed
   alphabet/locality coding window, the global package/max-before-average quantifier, or
   the near-linear length regime.

## Proof

For (1), C266 counts the disjoint dyadic groups used by the JK partition across all
selected histories:

\[
 |\mathcal T_{i,h}|
 \le \frac{2^{\nu_i}T_i^a}{2q_i2^h}.
\tag{278.5}
\]

Thus \(|\mathcal T_{i,h}|>2^{q_i}\) implies (278.3).  If one instead counts all sliding
block windows, the factor \(2^h\) is dropped, but the resulting upper bound is still
\(2^{o(q_i)}\) and the conclusion is unchanged. The RW recurrence gives
\(\nu_i+a\log T_i=o(q_i)\), so this condition fails in the existing polynomial-time
regime.  This argument counts one selected history per input; it does not count
unrelated Merlin candidates as actual labels.

For (2), assume for contradiction that both inequalities in (278.4) fail.  Then
\(\bar\delta_i\le\eta\Delta/2\), so the C277 target set has density
\(p_i\ge1/2\).  If also \(I_i\le\varepsilon_I K_i\), the C277 fiber exponent is

\[
 K_i+\log_2p_i-
 \frac{I_i/p_i+h_2(\eta)}{1-\eta}
 \ge
 K_i-
 \frac{2\varepsilon_I K_i+h_2(\eta)}{1-\eta}-1.
\tag{278.6}
\]

For any fixed \(\varepsilon_I<(1-\eta)/8\), this is at least
\(3K_i/4-O_{\eta}(1)\).  Sauer--Shelah therefore produces a shattered coordinate set
of size \(\theta K_i\) for a constant \(\theta>0\).  The fixed package on that fiber,
with the inline claim bit and binary recoding, is a fixed-locality positive-radius
adaptive RLDC.  Since \(P_i\le K_i(\log(K_i+2))^b\), this contradicts the assumed
RLDC lower-bound window.  Hence (278.4) holds.

The three cases exhaust the two available family-building routes and their stated
hypotheses.  \(\square\)

## Interpretation and boundary

The theorem upgrades the previous asymptotic statement “not both
\(\bar\delta=o(1)\) and \(I=o(K)\)” to an explicit constant-or-linear-information
payment whenever the coding window is fixed.  It also shows why replacing the single RW
input \(x_0\) by all inputs does not by itself supply the family needed by C277: the
history channel remains \(2^{o(q_i)}\), while a common-package closure would have to pay
the second alternative instead.  The result is conditional on the proposed global
package and the external RLDC lower bound; it is not an unconditional dPCP or
\(P\ne NP\) theorem.

## Sources

* C266 / note 261: RW multi-input tuple-supply bound.
* C277 / note 277: average-defect common-fiber closure.
* The main-paper RLDC lower-bound window stated in (278.2).
