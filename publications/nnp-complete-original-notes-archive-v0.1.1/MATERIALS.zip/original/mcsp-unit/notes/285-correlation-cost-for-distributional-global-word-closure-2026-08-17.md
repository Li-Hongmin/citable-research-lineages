> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Correlation cost for distributional global-word closure

## Setup

Let \(\Gamma\) have size \(Q\ge2\), let
\(\mathcal Y\subseteq\Gamma^M\) be the valid global-word family, and let
\(\mathcal P_j=\pi_j(\mathcal Y)\) with \(p_j=|\mathcal P_j|\). Let \(U\) be the
product distribution whose \(j\)-th coordinate is uniform on \(\mathcal P_j\).

Let \(\mu\) be any joint distribution on
\(\operatorname{Rect}(\mathcal Y)=\prod_j\mathcal P_j\) whose coordinate marginals
are the same uniforms as those of \(U\). Define the total correlation in bits by
\[
 \operatorname{TC}_2(\mu)
 :=D_2(\mu\|U)
 =\sum_{j=1}^M H_2(Z_j)-H_2(Z),
 \qquad Z\sim\mu.
\]
For \(t\ge0\), let
\[
 A_t:=\{z:\min_{y\in\mathcal Y}d_H(z,y)\le t\},
 \qquad \eta_t:=U(A_t).
\]

## Theorem 1 (correlation-cost inequality)

If \(p_t:=\mu(A_t)\), then
\[
 \operatorname{TC}_2(\mu)\ge d_2(p_t\|\eta_t),
 \tag{1}
\]
where \(d_2\) is binary relative entropy. In particular, for every
\(p_t\ge p_0>0\),
\[
 \operatorname{TC}_2(\mu)
 \ge p_0\log_2\frac1{\eta_t}-1.
 \tag{2}
\]

### Proof

Apply data processing for relative entropy to the indicator map
\(z\mapsto\mathbf 1_{A_t}(z)\). Under \(\mu\) it has Bernoulli parameter \(p_t\), and
under \(U\) it has parameter \(\eta_t\), proving (1). For (2),
\[
 d_2(p_t\|\eta_t)
 =p_t\log_2\frac{p_t}{\eta_t}
 +(1-p_t)\log_2\frac{1-p_t}{1-\eta_t}
 \ge p_t\log_2\frac1{\eta_t}-h_2(p_t)
 \ge p_0\log_2\frac1{\eta_t}-1.
\]
\(\square\)

## Corollary 2 (full-projection/high-distance regime)

Assume every \(\mathcal P_j=\Gamma\), the minimum relative distance is
\(\Delta=d/M\), and \(t=\lfloor\varepsilon M\rfloor\). By the product
anti-concentration bound,
\[
 \eta_t\le
 Q^{\,1-M(\Delta-H_Q(\varepsilon))+o(M)}
 \quad\text{when }\Delta>H_Q(\varepsilon).
\]
Hence any joint distribution with the same uniform coordinate marginals and
\(\mu(A_t)\ge p_0\) must satisfy
\[
 \operatorname{TC}_2(\mu)
 \ge
 p_0 M\bigl(\Delta-H_Q(\varepsilon)\bigr)\log_2 Q-O_Q(1).
 \tag{3}
\]
Thus non-negligible global-word probability requires a linear amount of
cross-coordinate statistical dependence whenever the product model is
exponentially anti-concentrated.

## Example and sharpness boundary

For \(\mathcal Y=\{0^M,1^M\}\), the product distribution \(U\) is uniform on
\(\{0,1\}^M\), while the same-seed distribution
\[
 \mu=\tfrac12\delta_{0^M}+\tfrac12\delta_{1^M}
\]
has the same uniform one-coordinate marginals and satisfies \(\mu(A_t)=1\) for
every \(t\ge0\). Its total correlation is \(M-1\) bits, matching the linear
lower-bound scale in (3) up to constants. A one-bit latent seed can generate this
distribution, so the theorem lower-bounds the statistical correlation carried by
the joint word, not the description length of every possible latent seed.

## Consequence for shared-proof constructions

C284 handles the zero-correlation endpoint \(\mu=U\). The present theorem gives the
interpolation: if an ordinary distributional/list composition wants a constant
probability of producing one globally valid word while preserving high-entropy
coordinate marginals and constant word distance, it must introduce a joint
correlation channel of linear total-correlation scale. A same-seed strategy is a
possible mechanism, but it must be analyzed as a genuinely joint object; independent
coordinate witnesses, random-tape choices with no common seed, and coordinatewise
Merlin responses cannot provide this for free.

The theorem is information-theoretic and does not itself lower-bound the number of
Merlin bits, seed bits, or proof symbols. Those stronger bounds require an additional
architecture relating the latent seed to the joint distribution.
