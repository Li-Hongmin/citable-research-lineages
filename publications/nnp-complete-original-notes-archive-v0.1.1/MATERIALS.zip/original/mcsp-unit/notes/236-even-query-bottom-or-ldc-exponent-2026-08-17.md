> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Even-query bottom-or-LDC exponent for binary shared proofs (2026-08-17)

## Contribution

The message-inline compiler already turns a target-relative shared-proof interface
into a binary LDC with one additional query. Combining it with the all-odd-query
LDC lower bound of Basu--Hsieh--Kothari--Lin gives a parameterized barrier for
every even branch locality. This extends the project’s cubic \(r=2\) barrier:
if each claim branch makes an even number \(r\ge2\) of proof queries and the
half-radius neighborhood has no bottom, then

\[
  k+P=\widetilde\Omega\!\left(k^{(r+1)/(r-1)}\right).
\]

The statement is nonlinear and allows adaptive branch verifiers. It is still a
family-level, binary, target-relative theorem; it is not a general dPCP
impossibility result.

## Interface and bottom parameter

Let

\[
  \Pi:\{0,1\}^{k}\longrightarrow\{0,1\}^{P}
\]

be a proof map. For every message coordinate \(i\) and claim \(b\), let
\(V_{i,b}\) be a randomized, possibly adaptive verifier making at most \(r\)
proof queries. Write \(p_{i,b}(z)\) for its acceptance probability.

Assume constants \(0<\rho<1\) and \(0\le\beta<\alpha\le1\) such that

\[
  p_{i,m_i}(\Pi(m))\ge\alpha,
\qquad
  \operatorname{dist}(z,\Pi(m))\le\rho P
  \Longrightarrow
  p_{i,1-m_i}(z)\le\beta .
\tag{236.1}
\]

Define the half-radius two-branch mass

\[
  \tau_{\rho/2}:=
  \inf_{m,i}\ \inf_{\operatorname{dist}(z,\Pi(m))\le\rho P/2}
       \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr).
\tag{236.2}
\]

Set

\[
  \varepsilon_0:=
  \max\{\beta,\,1-\tau_{\rho/2}+\beta\}.
\tag{236.3}
\]

The no-bottom regime is the fixed-gap condition
\(\varepsilon_0<1/2\). A stronger conventional choice is
\(\varepsilon_0\le1/3\).

## Theorem (even-query bottom-or-LDC exponent)

Let \(r\ge2\) be even. Under (236.1)--(236.3), for all sufficiently large \(k\),

\[
  k+P
  \ge
  \widetilde\Omega_{\rho,\alpha,\beta,\tau_{\rho/2},r}
       \!\left(k^{\frac{r+1}{r-1}}\right).
\tag{236.4}
\]

Equivalently, a binary near-linear family at an even branch locality \(r\) must
exhibit a half-radius bottom, let its radius/gap degenerate, or leave the common
proof/address-space model.

### Proof

First, distinct proof words have relative distance greater than \(\rho\). If
\(m\ne m'\) and
\(\operatorname{dist}(\Pi(m),\Pi(m'))\le\rho P\), choose \(i\) with
\(m_i\ne m'_i\). Completeness for \(m'\) gives

\[
  p_{i,m'_i}(\Pi(m'))\ge\alpha,
\]

while (236.1), applied with target \(m\) and received word
\(z=\Pi(m')\), gives the same probability at most \(\beta\), a contradiction.

Now inline the message:

\[
  C(m):=m\,\|\,\Pi(m),
  \qquad N:=k+P.
\tag{236.5}
\]

The binary Singleton bound applied to the \(2^k\) proof words implies, for \(k\ge2\),

\[
  \frac{P}{N}\ge\frac1{3-2\rho}.
\tag{236.6}
\]

Consequently \(C\) has constant relative distance at least
\(\rho/(3-2\rho)\). Put

\[
  \delta_0:=\frac{\rho}{2(3-2\rho)}.
\tag{236.7}
\]

If \(y\) is within relative distance \(\delta_0\) of \(C(m)\), its proof suffix
\(z\) is within distance \(\rho P/2\) of \(\Pi(m)\).

To decode coordinate \(i\), first query the inline bit \(b=y_i\), then run
\(V_{i,b}\) on the proof suffix, and output \(b\) if that verifier accepts and
\(1-b\) otherwise. This uses at most \(r+1\) queries. If \(b\ne m_i\), the
selected branch is the wrong branch, so the decoder errs with probability at most
\(\beta\). If \(b=m_i\), the half-radius mass and wrong-branch bound give

\[
  p_{i,m_i}(z)
  \ge \tau_{\rho/2}-p_{i,1-m_i}(z)
  \ge \tau_{\rho/2}-\beta,
\]

so the error probability is at most
\(1-\tau_{\rho/2}+\beta\). The same bound applies on the uncorrupted codeword,
because it lies in the half-radius neighborhood. Hence \(C\) is a binary
\((r+1)\)-query LDC with constant distance, constant radius, and error at most
\(\varepsilon_0<1/2\).

Since \(r\) is even, \(R:=r+1\) is odd and \(R\ge3\). Theorem 1.1 of
Basu--Hsieh--Kothari--Lin gives

\[
  k\le \widetilde O\!\left(N^{1-2/R}\right).
\]

Solving for \(N\) yields

\[
  N\ge\widetilde\Omega\!\left(k^{R/(R-2)}\right)
   =\widetilde\Omega\!\left(k^{(r+1)/(r-1)}\right),
\]

which is (236.4). \(\square\)

## Parameter examples

The first cases are

\[
  r=2:\quad N=\widetilde\Omega(k^3),
  \qquad
  r=4:\quad N=\widetilde\Omega(k^{5/3}),
  \qquad
  r=6:\quad N=\widetilde\Omega(k^{7/5}).
\]

The \(r=2\) line is compatible with the sharper GMWZ near-cubic bound already
used in note 01. The value of (236.4) is the uniform even-\(r\) statement,
not a claim to improve the best logarithmic factor at \(r=2\).

For \(r=1\), message-inline gives a direct two-query binary RLDC. The separate
exponential theorem of Block et al. therefore replaces (236.4) by

\[
  N=2^{\Omega(k)};
\]

this is the edge case recorded in notes 234--235.

## Scope and escapes

The proof uses the following exact features:

* one common binary proof map for all message coordinates;
* target-relative soundness on a positive-radius neighborhood;
* a fixed half-radius two-branch mass lower bound;
* constant even branch locality \(r\).

It does not rule out:

* odd branch locality, unless one separately invokes the corresponding even-query
  LDC bound after a query-preserving conversion;
* larger alphabets or growing alphabet size;
* vanishing radius or vanishing gap;
* ordinary average/list soundness without the target-relative quantifier;
* different proof/address spaces, unbounded interactive strategies, or a
  single-target construction with no injective message family.

The result therefore upgrades the bottom-or-cubic barrier to a query-parameterized
barrier, but does not close the general RW succinct smart reconstruction theorem.

## Sources

* A. Basu, J.-T. Hsieh, P. K. Kothari, and A. D. Lin, *Improved Lower Bounds for
  all Odd-Query Locally Decodable Codes*, arXiv:2411.14361, Theorem 1.1:
  <https://arxiv.org/abs/2411.14361>.
* T. Gur, D. Minzer, G. Weissenberg, and K. Z. Zheng, *3-Query RLDCs are
  Strictly Stronger than 3-Query LDCs*, arXiv:2512.12960:
  <https://arxiv.org/abs/2512.12960>.
* A. R. Block et al., *Exponential Lower Bounds for 2-query Relaxed Locally
  Decodable Codes*, arXiv:2602.20278:
  <https://arxiv.org/abs/2602.20278>.
