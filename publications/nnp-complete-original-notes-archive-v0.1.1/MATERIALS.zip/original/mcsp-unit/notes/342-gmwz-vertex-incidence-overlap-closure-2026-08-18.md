> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# GMWZ vertex-incidence overlap closes the varying-tag gate (2026-08-18)

## Proposition

Let \(X\) be an HDX and let \(U_i\subseteq X(k)\) have \(\mu_k\)-mass \(\mu_i>0\).
Sample \(A\) from \(U_i\), then a uniformly random vertex of \(A\), and call the induced
vertex distribution \(\nu_i\). Let \(\mu_1\) be the stationary vertex measure and let
\(\lambda_{k,1}\) be the second singular value of the weighted \(X(1)\)--\(X(k)\)
inclusion graph. Then

\[
  \operatorname{TV}(\nu_i,\mu_1)
  \le \frac{\lambda_{k,1}}{\sqrt{\mu_i}}.
  \tag{VI1}
\]

Consequently, for two clusters \(U_0,U_1\),

\[
  \chi:=1-\operatorname{TV}(\nu_0,\nu_1)
  \ge
  \left[
    1-\lambda_{k,1}
      \left(\mu_0^{-1/2}+\mu_1^{-1/2}\right)
  \right]_+.
  \tag{VI2}
\]

If both masses are at least \(\mu_\star\), then
\[
  \chi\ge \left[1-\frac{2\lambda_{k,1}}{\sqrt{\mu_\star}}\right]_+.
  \tag{VI3}
\]

For the HDX family used by Gur--Minzer--Weissenberg--Zheng, Theorem 2.9 gives
\[
  \lambda_{k,1}=\frac1k+\frac{k^{O(1)}}d.
  \tag{VI4}
\]
Thus choosing the dimension so that \(k^{O(1)}/d=o(\sqrt{\mu_\star})\) makes every pair of
heavy clusters have \(\chi=1-o(1)\). Combining (VI3) with the overlap-aware DPT obstruction
of note 341 yields the concrete source gate

\[
  \kappa(\delta)-\varepsilon_\star
  \le
  \frac{\mu_{\max}}{1-\zeta}
  \left(1+\frac{2\lambda_{k,1}}{\sqrt{\mu_\star}}\right).
  \tag{VI5}
\]

This closes the vertex-support/separated-tag escape for the GMWZ HDX whenever the right-hand
side is below the proposed DPT mass. It does not by itself synchronize the decoded cluster
words: cross-face marginal transfer, payload disagreement, cover-sheet binding, and the RW
address-scale interface remain separate conditions.

## Proof

For any vertex set \(V\subseteq X(1)\), the bipartite expander-mixing inequality for the
weighted inclusion graph gives

\[
 \left|
 \Pr_{A\sim X(k),\,v\in A}[A\in U_i,\ v\in V]
 -\mu_i\mu_1(V)
 \right|
 \le
 \lambda_{k,1}\sqrt{\mu_i\mu_1(V)}.
 \tag{VI6}
\]

Conditioning on \(A\in U_i\) and dividing by \(\mu_i\),

\[
  |\nu_i(V)-\mu_1(V)|
 \le
 \lambda_{k,1}\sqrt{\frac{\mu_1(V)}{\mu_i}}
 \le \frac{\lambda_{k,1}}{\sqrt{\mu_i}}.
\]

Taking the supremum over \(V\) proves (VI1). The triangle inequality for total variation
gives
\[
 \operatorname{TV}(\nu_0,\nu_1)
 \le
 \operatorname{TV}(\nu_0,\mu_1)+\operatorname{TV}(\nu_1,\mu_1),
\]
which proves (VI2)--(VI3). Equation (VI5) is Proposition 3.9T with
\(2-\chi\le 1+2\lambda_{k,1}/\sqrt{\mu_\star}\).
\(\square\)

## Exact residual: the mass gap

If the heavy-cluster threshold is \(\mu_\star=\delta^{C_{\rm cl}}\), then (VI3) and (VI4)
give \(\chi=1-o(1)\) whenever
\[
  \frac1k+\frac{k^{O(1)}}d=o(\delta^{C_{\rm cl}/2}).
\]
In that window (VI5) is asymptotically
\[
  \kappa(\delta)-\varepsilon_\star
  \le (1+o(1))\frac{\mu_{\max}}{1-\zeta}.
\]
This does not automatically close the GMWZ list endpoint: the greedy Lemma 6.2
decomposition gives a lower bound on each cluster mass but no upper bound on the largest
cluster, while DPT soundness only promises a total mass \(\kappa(\delta)\). A dominant cluster
can therefore absorb the entire DPT witness even when \(\chi=1-o(1)\). The remaining positive
condition is exactly the mass-gap inequality
\[
  \kappa(\delta)-\varepsilon_\star
  >
  \frac{\mu_{\max}(2-\chi)}{1-\zeta},
\]
or a separate theorem that extracts positive global-word mass from both clusters. This is a
quantitative source boundary, not a failure of the overlap calculation.

## Source boundary

The only external input is the explicit \(X(1)\)--\(X(k)\) inclusion singular-value clause in
[GMWZ Theorem 2.9](https://arxiv.org/html/2512.12960#S2.3.3), together with the elementary
expander-mixing inequality. This is different from the missing \(X(k)\)--\(X(\sqrt{k})\)
profile needed for cross-cluster decoder marginal transfer. Therefore it is a genuine
source-specific closure of the vertex-varying-tag/cover-support escape, not a claim that
GMWZ Theorem 6.1 already has unique decoding.
