> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Typed-query concentration is necessary below the smooth exponential regime (2026-08-17)

## Contribution

The smoothness hypothesis in the finite-alphabet one-symbol compiler can be
quantified rather than treated as an on/off assumption.  Let
\(\mu_k\) be the largest probability of any typed query \((j,S)\).  A
non-adaptive three-query binary compiler, using the inline bit and the two
candidate branch queries, gives a GGS radius test.  Therefore a near-linear
family cannot have \(\mu_k\) too small: it must contain a typed-query peak
of essentially \(N^{-1+\Theta(1)}\).

This leaves a sharp phase diagram:

* \(\mu_k=O(1/P)\) is in the smooth two-query exponential regime of note 243;
* \(\mu_k\) below \(N^{-1+\Theta(1)}\) is already incompatible with
  near-linear length by the three-query GGS bound;
* any surviving near-linear one-symbol construction must concentrate a
  typed query at least at the latter scale, or leave the target-relative
  perfect-completeness model.

## Theorem

Fix a finite proof alphabet \(\Sigma\) of size \(A\ge2\), constants
\(0<\rho<1\) and \(0\le\beta<1\), and a proof map
\(\Pi_k:\{0,1\}^k\to\Sigma^{P_k}\).  For each message coordinate \(i\)
and claim \(b\), let \(V_{i,b}\) make at most one proof-symbol query.
On a querying random tape write \(t=(j,S)\), where \(S\subseteq\Sigma\)
is the accepting symbol set, and define

\[
\mu_k:=\max_{i,b,t}\Pr_R[t=(j,S)].
\tag{246.1}
\]

Assume perfect correct-branch completeness
\[
p_{i,m_i}(\Pi_k(m))=1
\tag{246.2}
\]
and target-relative wrong-branch soundness
\[
d_H(z,\Pi_k(m))\le\rho P_k
\Longrightarrow
p_{i,1-m_i}(z)\le\beta.
\tag{246.3}
\]

Let \(N_k=k+P_k\).  Fix any constant
\(\theta\in(0,1-\beta)\).  If

\[
N_k\le k(\log k)^c
\tag{246.4}
\]
for infinitely many sufficiently large \(k\), then on those lengths

\[
\mu_k\ge
\frac{1-\beta-\theta}{2}\,
N_k^{-1+\theta/6}.
\tag{246.5}
\]

Equivalently, a family with
\(\mu_k=o(N_k^{-1+\theta/6})\) cannot have near-linear length.
Since \(\theta\) may be any fixed constant below \(1-\beta\), the
exponent can approach \(-1+(1-\beta)/6\).

## Proof

### 1. Expanded binary code

As in note 243, (246.2)--(246.3) force distinct proof words to have
symbol distance \(>\rho P_k\).  The \(A\)-ary Singleton bound gives
\(P_k\ge c_0 k\) for all large \(k\), with
\[
c_0=\frac{1}{2(1-\rho)\log_2 A}.
\tag{246.6}
\]

Encode \(a\in\Sigma\) by
\[
E(a)_S=\mathbf 1[a\in S],\qquad S\subseteq\Sigma,
\tag{246.7}
\]
and define
\[
\widetilde C_k(m)=m\,
\Vert E(\Pi_k(m)_1)\Vert\cdots\Vert E(\Pi_k(m)_{P_k}).
\tag{246.8}
\]
The length is \(N_k'=k+2^A P_k\).  Distinct symbols have
\(E\)-distance \(2^{A-1}\), so the expanded binary code has a fixed
relative distance
\[
\Delta_0=
\frac{\rho\,2^{A-1}}{2^A+c_0^{-1}}>0
\tag{246.9}
\]
for all sufficiently large \(k\).

### 2. A non-adaptive three-query decoder

On input \(i\), sample one random tape for \(V_{i,0}\) and one for
\(V_{i,1}\).  Their typed query locations are fixed before reading the
received word.  Query the inline bit \(y_i\) and the two corresponding
expanded bits (omitting a query on a no-query tape).  After reading
\(b=y_i\), simulate only \(V_{i,b}\): output \(b\) if that branch
accepts and output \(\bot\) otherwise.

On an exact codeword, \(b=m_i\) and (246.2) gives output \(m_i\) with
probability one.  Thus this is a perfect-complete non-adaptive
three-query decoder.

Let \(y\) be within relative distance \(\delta\) of
\(\widetilde C_k(m)\), and let \(F_y\) be its corrupted expanded proof
bits.  If \(y_i=m_i\), the decoder outputs only \(m_i\) or \(\bot\).
If \(y_i\ne m_i\), an uncorrupted typed bit behaves as the wrong branch
on the exact proof and accepts with probability at most \(\beta\).
The probability that the selected typed bit is corrupted is at most
\(\mu_k|F_y|\le\mu_k\delta N_k'\).  Hence

\[
\Pr[\text{output}\in\{m_i,\bot\}]
\ge 1-\beta-\mu_k\delta N_k'.
\tag{246.10}
\]

Set
\[
\delta_k=
\min\left\{\frac{\Delta_0}{2},
\frac{1-\beta-\theta}{2\mu_kN_k'}\right\},
\tag{246.11}
\]
with the second term interpreted as \(+\infty\) when \(\mu_k=0\).
Then the expanded code is a non-adaptive \((3,\delta_k,\theta)\)-RLDC
in the GGS sense.

### 3. GGS forces a typed-query peak

Goldberg--Gur--Saraogi's non-adaptive RLDC theorem says that if
\(\delta_k>(N_k')^{-\theta/6}\), then

\[
N_k'\ge
\left(
\frac{\theta^2 k}
{38\cdot 3^4\log^2(2)\log^2 k}
\right)^{1+1/\lceil3/\theta\rceil}.
\tag{246.12}
\]

The right-hand side is \(k^{1+\Omega_\theta(1)}\) up to polylogarithmic
factors, contradicting (246.4) for all sufficiently large \(k\).
Therefore \(\delta_k\le(N_k')^{-\theta/6}\).  Since the threshold is
eventually smaller than \(\Delta_0/2\), the second term in (246.11)
must be at most \((N_k')^{-\theta/6}\), which rearranges to

\[
\mu_k\ge
\frac{1-\beta-\theta}{2}\,(N_k')^{-1+\theta/6}.
\tag{246.13}
\]

Because \(P_k\ge c_0k\), \(N_k'\) and \(N_k\) differ only by a fixed
factor depending on \(A,\rho\), so (246.13) implies (246.5) after
adjusting the constant.  \(\square\)

## Scope

This is a concentration barrier, not the unrestricted finite-alphabet
two-query exponential theorem.  It assumes one proof-symbol query,
perfect correct-branch completeness, and target-relative soundness.
If \(\mu_k\) is larger than the threshold, the argument deliberately
does not decide whether a near-linear construction exists.  Note 243
handles the much smaller \(\mu_k=O(1/P_k)\) regime with an adaptive
two-query exponential lower bound.

## Source

* [note 243](243-finite-alphabet-one-query-smooth-exponential-closure-2026-08-17.md)
  for the adaptive two-query smooth compiler.
* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for
  Relaxed Locally Decodable Codes via Robust Daisies*, Theorem 1:
  <https://arxiv.org/html/2511.21659>.
