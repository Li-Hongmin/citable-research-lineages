> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Bounded writable-RAM Closure Gate（2026-08-19）

## 本轮改变的判断

C465 只把静态 descriptor 的重复读取与非线性控制状态展开为普通电路。一个更
强的 objection 是允许 evaluator 在运行中读写一条 target-dependent RAM，让全局
关系通过中途修改的 memory state 传播。下面把这一类 bounded writable-RAM
evaluator 也纳入同一个 forcing payment：只要 RAM 的物理长度、每次访问和控制
转移都计价，写操作不会成为新的地址尺度出口。

## 定义：bounded writable-RAM evaluator

令 \(H\in\{0,1\}^N\)，地址长度 \(m=\lceil\log_2(N+1)\rceil\)。一个 evaluator
以地址 \(a\in\{0,1\}^m\) 为输入，使用：

* 一条长度为 \(w\) 的 bit-RAM，初始内容是每个长度固定的一份 advice
  \(\sigma\in\{0,1\}^w\)；所有地址共用同一 \(\sigma\)；
* \(T\) 个显式 transition、至多 \(q\) 次 single-cell read/write（允许自适应和
  重复访问同一 cell）；
* \(s\) 位任意非线性控制状态；每个 transition 的 address、read/write flag、
  write bit、next-state 联合逻辑由 fan-in-2 电路实现，大小至多 \(g\)；
* 终止时从控制状态或 RAM 中产生一个输出 bit。

transition 电路的 hardwired constants 和初始化/输出控制均计入 \(g\) 或 \(w\)；
不允许把 \(H\) 的另一份未计价真值表藏入控制描述。若 RAM 访问被声明为
unit-cost oracle，或 RAM 长度不计入 \(w\)，则已经离开本模型。

## 定理 466.1（writable-RAM circuit expansion）

若 evaluator 对所有 \(a\in[N]\) 输出同一个对象的位

\[
E(a;\sigma)=H[a],
\]

则存在普通 fan-in-2 电路 \(C\)，满足

\[
\operatorname{CC}(H)
\le c_1\bigl(Tg+q(w+s+m)+m+1\bigr).
\tag{466.1}
\]

在单 cell、单 bit 的 RAM 模型中，\(s\) 只产生线性接线开销；若 transition
电路的大小 \(g\) 已包含 state-routing，则可简写为

\[
\operatorname{CC}(H)\le O(Tg+qw+m+1).
\tag{466.2}
\]

### 证明

按时间展开 \(T\) 个 transition。第 \(t\) 步的控制逻辑复制一次，产生 \(O(g)\)
个门。一个 RAM read \(M[j]\) 用 \(w\)-输入 multiplexer 替换，规模 \(O(w)\)；
一个 write \(M[j]\leftarrow b\) 用 \(w\) 个带地址选择的 conditional-update
单元替换，规模 \(O(w)\)。因此所有 \(q\) 次访问的总成本为 \(O(qw)\)；重复
访问不会复用一个未计价的 oracle。把初始 \(\sigma\) 的各位接到常数线，保留
地址 \(a\) 为输入，终止状态/内存位作为输出，即得到 (466.1)--(466.2)。证毕。

## Forcing-scale 推论

若在同一无限长度集合上

\[
\operatorname{CC}(H_N)>S_N,
\qquad m_N=\lceil\log_2(N+1)\rceil,
\]

则任何 same-object、same-RAM evaluator 必须满足

\[
Tg+q(w+s+m_N)+m_N+1=\Omega(S_N).
\tag{466.3}
\]

特别地，如果 \(T,q,w,g,s=\operatorname{poly}(m_N)\)，则
\(\operatorname{CC}(H_N)=\operatorname{poly}(m_N)\)，与 forcing 下界冲突。若
\(Tg+q(s+m_N)+m_N=o(S_N)\)，则

\[
qw=\Omega(S_N).
\tag{466.4}
\]

因此一个声称保持地址尺度的 writable-RAM closure 只能在以下两种情形中存活：

1. RAM 物理长度 \(w\) 或访问数 \(q\) 已达到 forcing/object 尺度；
2. RAM/访问被当作 unit-cost 未计价 oracle，因而不再是标准 fan-in-2
   reconstruction interface。

## 对 RW Closure 的含义

* C465 的 static-ROM gate 现在升级为对 bounded writable memory 的 gate；允许
  中途修改 memory、非线性状态和重复读写，不再是 read-once representation
  假设。
* 对 published RW singleton，这个结论不需要 family entropy 或 RLDC 编译：只要
  proposed same-object evaluator 的整个 mutable memory 在长度上是
  \(\operatorname{poly}(\log N)\)，它本身就给出 forcing-hard object 的
  \(P/\mathrm{poly}\) 电路。
* 因而 C450 的 genuine model-exit 可进一步具体化：若新 global relation 仍可由
  bounded writable memory 实现，它落入 (466.3)；真正未定义的只剩 unit-cost
  oracle、object-scale memory/time、或地址之间切换 physical proof。

## 证据边界

定理 466.1 是标准 RAM-to-circuit 展开，不是一般 nonlinear circuit lower bound，
也不声称所有 dPCP/global relation 都有 bounded writable-RAM 表示。它只说明：
“把非线性全局耦合放进一条有限可写 memory”并不能在不支付 memory/access
成本的情况下完成 RW 的地址尺度 Closure；实际 RW canonical history 是否有任何
这样的 evaluator 仍未证明，\(P\ne NP\) 也尚未由本项目得到。

## 与已有结果的关系

* C465/Note 465 处理静态 descriptor 的 adaptive repeated-read evaluator；
  C466 允许 descriptor 在运行中被覆盖和更新。
* C449/Note 449 的 finite-state RLDC 分支需要 family-level target entropy；
  C466 是 fixed-target singleton 的直接电路 payment，不偷用该量词。
* C463/Note 463 的通信秩障碍只覆盖 read-once ordered representations；
  C466 覆盖显式 bounded-RAM 的任意变量访问顺序和非线性更新。
