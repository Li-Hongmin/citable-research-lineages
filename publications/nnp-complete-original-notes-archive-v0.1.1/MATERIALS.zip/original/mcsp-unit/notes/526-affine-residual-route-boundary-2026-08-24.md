> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Affine-residual route boundary (2026-08-24)

## Proposition 34

Let \(A\subseteq\{0,1\}^N\), fix a cut \(t\), and put \(m=N-t\). For each prefix
\(u\in\{0,1\}^t\), define \(F_u(z)=1_A(uz)\). If every \(F_u\) is affine over
\(\mathbb F_2\), and \(r_t\) is the number of distinct residuals, then

\[
r_t\le 1+2|A|\,2^{-m}.
\tag{526.1}
\]

If \(|A|\le2^L\), this gives

\[
\log_2r_t\le \max\{0,L-m+1\}+1.
\tag{526.2}
\]

For \(A=\mathrm{MCSP}_S\), circuit enumeration gives
\[
\log_2|A|=O(S\log(N+S)).
\]
Thus affine residuals cannot yield \(2^{\Omega(S)}\) states at cuts with
\(N-t\gg S\log N\).

## Proof

The cylinders \(u\{0,1\}^m\) belonging to distinct prefixes are disjoint, so their fiber
cardinalities sum to at most \(|A|\). Every nonzero affine Boolean function on \(m\) variables
has support \(2^{m-1}\) or \(2^m\), and at most one residual is zero. Taking one prefix
representative per distinct nonzero residual,
\[
(r_t-1)2^{m-1}\le|A|,
\]
which proves (526.1)--(526.2).

## Explicit MCSP YES obstruction

Let \(B=2^{n-k}\), and let \(K_k\) be the set of truth tables constant on each of the
\(2^k\) consecutive blocks of length \(B\). Then \(K_k\) is a linear subspace of dimension
\(2^k\), and membership in \(K_k\) has a constant-width known-order ROBP (remember the first
bit of each block and reject on a change). By the Lupanov upper bound for arbitrary \(k\)-variable
functions, choose \(k\) with \(c2^k/k\le S\). Then \(2^k=\Theta(S\log S)\), every member lies in
\(\mathrm{MCSP}_S\), and
\[
\log_2|K_k|=2^k=\Theta(S\log S),
\]
matching the full MCSP YES-entropy scale, while the residual width stays \(O(1)\).

Likewise, an equality gadget
\[
A_{\mathrm{eq}}=\{u\Vert u:u\in K_k\}
\]
has \(2^{\dim K_k}\) distinct middle-cut residuals \(z\mapsto[z=u]\), but enlarging the YES
set to \(\mathrm{MCSP}_S\) can merge these residuals. Residual-width lower bounds are not
monotone under YES-set extension: \(A_{\mathrm{eq}}\) has large middle width, while
\(\{0,1\}^N\) has width \(1\). Therefore a fooling set inside a low-complexity subset does not
prove a lower bound for full MCSP. One must exhibit NO cross-combinations outside the entire
\(\mathrm{MCSP}_S\) set, which affine entropy, sparsity, and XOR closure do not provide.

This closes the affine-residual route as a general \(S\)-scale proof strategy; it does not resolve
the non-affine MCSP residual problem and does not prove \(P\ne NP\).

## Dependencies

- [Proposition 31](523-hidden-continuation-complexity-boundary-2026-08-24.md)
- [Proposition 33](525-unconditional-strong-local-residual-boundary-2026-08-24.md)
