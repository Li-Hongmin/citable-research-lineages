> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 定向三元组势的 QA 审计版 no-go

## 结论

令 \(X,Y\subseteq\mathbb F_2^N\) 且 \(X\cap Y=\varnothing\)，\(C=X\times Y\)。对任意三个不同 cell 的集合 \(T\subseteq C\)、任意 spoiler \(s\in C\setminus T\)，定义

\[
G_{T,s}(R)=\mathbf 1[s\in R]-\mathbf 1[T\subseteq R].
\tag{G}
\]

设 \(\lambda_{T,s}\ge0\)，并令

\[
K(R)=\sum_{(T,s)}\lambda_{T,s}G_{T,s}(R),
\qquad
\Lambda=\sum_{(T,s)}\lambda_{T,s}.
\tag{K}
\]

若 \(K\) 作为 quasi-additive 对偶势满足标准的叶约束，那么无论这些三元组是否来自 \(E_a\times NO_b\) 的 collision、权重是否按电路描述长度分层，都有

\[
\boxed{
\sum_{c\in C}\phi_c\le 4-\frac{\Lambda}{2}\le4.
}
\tag{NG}
\]

因此该非负 directed-spoiler 模板不可能产生 \(N^{1.01}\)，甚至不能产生随 \(N\) 增长的目标。证明只使用 \(X\cap Y=\varnothing\)；\(NO_b\) 的更强“所有高复杂度点均在右侧”语义不会改变这个平均上界。

下文把参数、仿射叶、rank 论证和 QA 的递归归一化逐项写出，以避免把 affine offset 与输出方向重复计数。

## 1. 仿射叶模型与参数去重

原始 affine-parity 关系可写为

\[
\ell_{r,\beta}(z)=\langle r,z\rangle\oplus\beta,
\qquad r\in\mathbb F_2^N,\;\beta\in\mathbb F_2,
\]

输出标签还可以带一个方向 \(\tau\in\mathbb F_2\)：

\[
R_{r,\beta,\tau}
 =\{(x,y)\in C:
      \ell_{r,\beta}(x)=\tau,
      \ell_{r,\beta}(y)=1\oplus\tau\}.
\tag{1}
\]

但 \(\tau\) 不是第二个 affine offset。令

\[
\beta'=\beta\oplus\tau;
\]

则

\[
R_{r,\beta,\tau}=R_{r,\beta',0}.
\tag{2}
\]

所以证明只需对唯一的方向 \(\tau=0\) 平均，写

\[
R_{r,\beta}
 =\{(x,y):
    \langle r,x\rangle\oplus\beta=0,
    \langle r,y\rangle\oplus\beta=1\}.
\tag{3}
\]

项目中常写的参数 \(z=(r,t)\in\mathbb F_2^{N+1}\) 正是这里的 \((r,\beta)\)；本 note 不再另引一个独立的 \(t\) 作为方向。故平均空间大小是 \(2^{N+1}\)，不是 \(2^{N+2}\)。把 \(\tau=1\) 的输出标签保留下来只会把 (3) 中的同一几何叶重复一次。

若 \(c=(x,y)\in C\)，置 \(d=x\oplus y\ne0\)。命中 \(c\in R_{r,\beta}\) 等价于

\[
\langle r,d\rangle=1,
\qquad
\langle r,x\rangle\oplus\beta=0.
\tag{4}
\]

在 \((r,\beta)\in\mathbb F_2^{N+1}\) 上，这两条方程的系数分别为

\[
A=(d,0),
\qquad B=(x,1).
\tag{5}
\]

它们线性独立：\(A\ne0\)，而 \(B\) 的最后坐标为 \(1\)。故

\[
\Pr_{r,\beta}[c\in R_{r,\beta}]=2^{-2}=\frac14.
\tag{6}
\]

## 2. 三 cell 联合命中的 rank 引理

**引理（rank-\(3\)）。** 若 \(T=\{c_1,c_2,c_3\}\subseteq C\) 是三个不同 cell，且 \(c_i=(x_i,y_i)\)、\(d_i=x_i\oplus y_i\)，则

\[
\Pr_{r,\beta}[T\subseteq R_{r,\beta}]\le\frac18.
\tag{7}
\]

**证明。** 每个 \(c_i\) 命中时给出两条方程

\[
A_i=(d_i,0)\quad\text{取值 }1,
\qquad
B_i=(x_i,1)\quad\text{取值 }0.
\tag{8}
\]

若这些方程不相容，联合概率为 \(0\)。设相容，并反设所有六个系数的秩至多 \(2\)。由于 \(A_1,B_1\) 独立，系数空间恰为

\[
S=\operatorname{span}\{A_1,B_1\}.
\]

在 \(S\) 中，最后坐标为 \(0\) 的非零向量只有 \(A_1\)，所以 \(A_i=A_1\)，即 \(d_i=d_1\)。最后坐标为 \(1\) 的向量只有 \(B_1\) 与 \(A_1+B_1\)，故

\[
B_i=B_1\quad\text{或}\quad B_i=A_1+B_1.
\]

第一种给出 \(x_i=x_1\)，再结合 \(d_i=d_1\) 得 \(y_i=y_1\)，从而 \(c_i=c_1\)，与 cell 两两不同矛盾。第二种给出

\[
x_i=x_1\oplus d_1=y_1,
\qquad
y_i=x_1.
\]

这要求 \(x_i=y_1\in X\) 且 \(y_1=x_i\in Y\)，违背 \(X\cap Y=\varnothing\)。故秩至少为 \(3\)。相容的秩-\(q\) 仿射方程组在均匀 \((r,\beta)\) 上的概率为 \(2^{-q}\)，于是得到 (7)。\(\square\)

注意：这个 rank 结论不需要 \(T\cup\{s\}\) 是 odd--odd collision，甚至不需要 \(T\) 是任何特殊的语义族；它对所有三个不同的 \(X\times Y\) cells 成立。

## 3. Directed 势的 affine-leaf 平均

由 (6) 和 (7)，对任意 \(s\notin T\)，有

\[
\mathbb E_{r,\beta}G_{T,s}(R_{r,\beta})
 =\Pr[s\in R_{r,\beta}]
  -\Pr[T\subseteq R_{r,\beta}]
 \ge\frac14-\frac18=\frac18.
\tag{9}
\]

因此对 (K) 中任意非负权重逐项求和：

\[
\mathbb E_{r,\beta}K(R_{r,\beta})
 \ge\frac18\sum_{(T,s)}\lambda_{T,s}
 =\frac{\Lambda}{8}.
\tag{10}
\]

这里允许 \(\lambda_{T,s}\) 任意依赖 \(x,y\)、\(\operatorname{CC}(x)\)、\(\operatorname{CC}(y)\)、collision codimension 或其它 MCSP 描述量；只要权重非负，(10) 不变。

## 4. QA 递归与 leaf normalization

令 \(m=|C|\)。Kamiyama--Ueno quasi-additive LP 的变量可按下述方式分组：

\[
\phi_c\quad(c\in C),
\qquad
\psi_{c,R}\quad(R\subseteq C\text{ 为矩形},\;c\notin R).
\]

对每个合法（affine-monochromatic）叶 \(R\)，叶约束是

\[
\sum_{c\in R}\phi_c
 +\sum_{c\notin R}\psi_{c,R}\le1.
\tag{leaf}
\]

对每个矩形 \(R\) 及其一次横向或纵向二分 \(R=V\dot\cup W\)，递归约束是

\[
\sum_{c\notin V}\psi_{c,V}
 +\sum_{c\notin W}\psi_{c,W}
 \ge
\sum_{c\notin R}\psi_{c,R}.
\tag{rec}
\]

对本 no-go，只需考虑由 \(K\) 诱导的标量外部势。定义

\[
K(C)=0,
\qquad
\psi_{c,R}=\frac{K(R)}{m-|R|}\quad(c\notin R,\;R\ne C),
\tag{11}
\]

而 \(R=C\) 时没有外部 cell，故不需要定义 \(\psi_{c,C}\)。这样

\[
\sum_{c\notin R}\psi_{c,R}=K(R).
\tag{12}
\]

对一次二分 \(R=V\dot\cup W\)，由于 \(s\) 只落在一个 child 中，

\[
\mathbf1[s\in V]+\mathbf1[s\in W]=\mathbf1[s\in R],
\]

而 \(T\) 若完整包含于某个 child，则必完整包含于 \(R\)，所以

\[
\mathbf1[T\subseteq V]+\mathbf1[T\subseteq W]
\le\mathbf1[T\subseteq R].
\]

从而

\[
G_{T,s}(V)+G_{T,s}(W)\ge G_{T,s}(R).
\tag{13}
\]

乘以 \(\lambda_{T,s}\ge0\) 后求和，得到

\[
K(V)+K(W)\ge K(R),
\qquad K(C)=0.
\tag{14}
\]

代回 (11)--(12)，(14) 正好就是 (rec)。因此，若某个 \((\phi,\psi)\) 证书的外部项属于该 directed 模板，那么其每个 affine 叶的 (leaf) 约束可写成

\[
\sum_{c\in R}\phi_c+K(R)\le1.
\tag{15}
\]

这一步是“leaf normalization”：\(\psi\) 的具体分配只负责把标量 \(K(R)\) 均匀摊到 \(C\setminus R\)，不改变递归不等式。它不把原本的递归 QA 问题错误地替换成无递归的矩形覆盖；(14) 是必须同时核对的根和内部节点条件。

## 5. 平均叶约束得到目标上界

假设 (15) 对所有合法 affine 叶成立。对 \(2^{N+1}\) 个唯一参数 \((r,\beta)\) 平均，令

\[
\Phi=\sum_{c\in C}\phi_c.
\]

由 (6)，即使 \(\phi_c\) 允许取负值，也有线性恒等式

\[
\mathbb E_{r,\beta}\sum_{c\in R_{r,\beta}}\phi_c
=\frac{\Phi}{4}.
\tag{16}
\]

结合 (10)、(15)：

\[
1\ge
\mathbb E_{r,\beta}\!\left[
\sum_{c\in R_{r,\beta}}\phi_c+K(R_{r,\beta})
\right]
\ge\frac{\Phi}{4}+\frac{\Lambda}{8}.
\]

故

\[
\boxed{\Phi\le4-\frac{\Lambda}{2}\le4.}
\tag{17}
\]

若完整 LP 另行要求 \(\phi_c\ge0\)，结论当然仍成立；证明本身并不依赖该附加符号条件。对 \(\psi\) 也不需要假设非负，(11) 可以是 signed 的，递归只依赖 (14)。

## 6. MCSP 语义与可逃逸边界

取

\[
X=E_a=\{z:\operatorname{CC}(z)\le a\},
\qquad
Y=NO_b=\{z:\operatorname{CC}(z)>b\}.
\]

上述证明仅使用 \(X\cap Y=\varnothing\)，所以对 MCSP 中按 circuit description、复杂度分层或 \(NO_b\) 全包含语义定义的任意非负 \(\lambda_{T,s}\) 都适用。特别地，不能通过“给更难的 \(y\) 更大权重”改变 affine-leaf 平均：每个 directed 三元组本身都有至少 \(1/8\) 的正平均裕量。

要离开 (17)，至少需要实质改变模板之一：

1. 允许 signed \(\lambda_{T,s}\)，使 (10) 的逐项正下界失效；
2. 使用不再是 \(\mathbf1_s-\mathbf1_T\) 的更高阶、跨多个 \(T\) 的谱量；
3. 放弃固定三元组的局部势，直接把跨行/跨列的全局递归状态编码进 \(K(R)\)。

单纯加入 MCSP 的密度、距离或描述长度权重，不足以跨越这个 no-go。

## 7. 审计状态

- 参数：唯一平均变量是 \(z=(r,\beta)\in\mathbb F_2^{N+1}\)；输出方向 \(\tau\) 已由 \(\beta\mapsto\beta\oplus\tau\) 吸收。
- 单 cell：两个独立方程，命中率 \(1/4\)。
- 三 cell：若相容，系数 rank 至少 \(3\)，联合命中率至多 \(1/8\)。
- QA：\(G\) 的超可加性给出根约束 \(K(C)=0\) 和所有横/纵递归；(11) 是合法的 \(\psi\) 归一化。
- 结论：非负 directed collision 模板的 QA 目标至多 \(4\)，与 MCSP 的具体语义无关。

本 note 是对既有 040-directed-collision-average-no-go 的模型和 QA 约束补全；它不是 \(P\ne NP\) 的证明，也不排除 signed 或真正全局的 collision 谱势。
