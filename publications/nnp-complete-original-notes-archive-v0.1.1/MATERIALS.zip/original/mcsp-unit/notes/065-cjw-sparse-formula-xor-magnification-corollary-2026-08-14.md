> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# CJW 稀疏 Formula--XOR 放大的直接推论（2026-08-14）

## 结论

令 \(\ell=\log_2N\)，\(N=2^\ell\)，并令

\[
s(\ell):=2^{\ell^{1/3}},
\qquad
L:=\operatorname{MCSP}[s].
\]

CJW 的稀疏语言放大定理，结合逐叶 XOR 到 \(U_2\)-formula 的展开，蕴含

\[
L\notin \mathrm{Formula}\circ\mathrm{XOR}[N^{1+\varepsilon}]
\quad\Longrightarrow\quad
\forall c>0,\quad
NP\not\subseteq\mathrm{Formula}\circ\mathrm{XOR}[N^c].
\tag{1}
\]

这里 Formula--XOR 是上层二叉 De Morgan 公式、叶为任意输入位的 parity；仿射常数项只造成常数开销。

因此当前 Frontier B 假设

\[
\operatorname{GapMCSP}[2^{\ell^{1/3}},2^{\ell^{2/3}}]
\notin\mathrm{Formula}\circ\mathrm{XOR}[N^{1.01}]
\tag{2}
\]

蕴含 (1)，取 \(\varepsilon=.01\)。这不是 \(P\ne NP\) 的证明。

## Gap 到 exact

若一个 Formula--XOR 家族 exact 计算 \(L\)，则它限制到下列 promise 后就是一个
\(\operatorname{GapMCSP}\) solver：

\[
\operatorname{CC}(x)\le2^{\ell^{1/3}}
\quad\text{与}\quad
\operatorname{CC}(x)>2^{\ell^{2/3}}.
\]

故

\[
(2)\Longrightarrow
L\notin\mathrm{Formula}\circ\mathrm{XOR}[N^{1.01}].
\tag{3}
\]

中间带 \(s(\ell)<\operatorname{CC}(x)\le2^{\ell^{2/3}}\) 不受 promise 约束，故不影响该
归约；NO 端采用 Chen 等 Definition 6 的严格 \(>t\) 约定。该方向不涉及 approximate
promise 或 NO 端的距离。

## CJW 的适用性

大小至多 \(s(\ell)\) 的 \(\ell\)-输入 fan-in-two circuits 的描述数至多

\[
2^{O(s(\ell)\log(s(\ell)+\ell))}=2^{N^{o(1)}}.
\tag{4}
\]

因此 \(L\in NP\)：猜测电路描述并逐真值表项验证的时间为
\(N\operatorname{poly}(s(\ell),\ell)=\operatorname{poly}(N)\)。并且 \(L\) 是
\(2^{N^{o(1)}}\)-sparse（非 \(2\) 的幂长度取空集）；更明确地，对每个固定
\(\beta\in(0,1)\) 和充分大的 \(N\)，

\[
\log_2\!\left(1+|L\cap\{0,1\}^N|\right)
\le O\!\left(2^{\ell^{1/3}}\ell^{1/3}\right)
\le N^\beta.
\tag{5}
\]

正式应用 CJW Theorem 1.1 时，对每个 \(\beta\) 取 \(N_\beta\)，使 (5) 对所有
\(N\ge N_\beta\) 成立，并定义 \(L_\beta\) 与 \(L\) 在这些长度一致、在较短长度没有
YES instance。于是每个 \(L_\beta\in NP\) 且是 \(2^{N^\beta}\)-sparse。\(L_\beta\)
与 \(L\) 仅有限长度不同；按标准的渐近非均匀 size 约定，有限修改可由固定的有限张公式补齐，
故不改变 Formula--XOR 下界。CJW 摘要的单语言表述正是这一步的简写，但其正式定理使用
\(\{L_\beta\}_{\beta\in(0,1)}\)。

其 Theorem 1.1(2) 的逐字结论是

\[
L_\beta\notin U_2\text{-}\mathrm{Formula}\text{-}\oplus[N^{1+\varepsilon}]
\quad\Longrightarrow\quad
\forall\text{ 固定整数 } k,\quad
NP\not\subseteq U_2\text{-}\mathrm{Formula}[N^k].
\tag{6}
\]

原文右端是普通 Formula，而非逐字的 Formula--XOR；但这不形成模型缺口。任意
\(N\)-位 parity 叶可用大小 \(O(N^2)\) 的 \(U_2\)-formula 实现，故对每个固定 \(c\)，

\[
U_2\text{-}\mathrm{Formula}\text{-}\oplus[N^c]
\subseteq
U_2\text{-}\mathrm{Formula}[O(N^{c+2})]
\subseteq
U_2\text{-}\mathrm{Formula}[N^k]
\tag{7}
\]

对某个固定整数 \(k>c+2\) 和充分大 \(N\) 成立。于是
\(NP\subseteq U_2\text{-}\mathrm{Formula}\text{-}\oplus[N^c]\) 会与 (6) 矛盾，得到 (1)。

## 纠正的边界

\[
\mathrm{Formula}[N^a]\subseteq
\mathrm{Formula}\circ\mathrm{XOR}[N^a]
\]

从较小类的下界不能反推较大类的同指数下界；这里不需要也不声称严格包含。但 CJW 的结论
量化所有固定 \(k\)，正好吸收 (7) 的常数指数损失。因此不能把“原文结论是普通 Formula”
当作本推论的模型障碍。

## 不推出 \(P\ne NP\)

\[
NP\not\subseteq\mathrm{Formula}\circ\mathrm{XOR}[N^c]
\quad(\forall c)
\not\Longrightarrow
P\ne NP.
\tag{8}
\]

\(P=NP\) 仅给出多项式时间算法，不给出固定多项式大小的 Formula--XOR 上界。

## 路线裁决

当前 Formula--XOR Gap 下界若获证，不仅给出 Chen 等 Frontier B 的 \(NQP\not\subseteq NC^1\) 后果，也经 CJW 给出 (1)。但它仍不是一般 circuit lower bound，且尚未获得 (2) 本身；本 note 只关闭“该假设没有稀疏同模型放大后果”的误判。

## 来源

- Lijie Chen, Ce Jin, and R. Ryan Williams, *Hardness Magnification for all Sparse NP Languages*, FOCS 2019, DOI: [10.1109/FOCS.2019.00077](https://doi.org/10.1109/FOCS.2019.00077), Theorem 1.1(2), pp. 3--4；摘要 p. 1 的单语言表述；证明 p. 14 的 parity \(O(n^2)\) 展开。
- Valentine Kabanets, Sajin Koroth, Zhenjian Lu, Dimitrios Myrisiotis, and Igor C. Oliveira, *Algorithms and Lower Bounds for De Morgan Formulas of Low-Communication Leaf Gates*, CCC 2020, DOI: [10.4230/LIPIcs.CCC.2020.15](https://doi.org/10.4230/LIPIcs.CCC.2020.15), p. 15:5 的条件性 Formula--XOR 表述。
- [note 000](000-cutover-2026-08-13.md)：Frontier B 的当前 Gap promise。
