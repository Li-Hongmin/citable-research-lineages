> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# GMWZ 共享顶面采样的 cover obstruction（2026-08-16）

## 结论地位（已由 note 202 闭合）

本 note 的原始“谱/余边界 gate”已由
[note 202](202-bmvy-ddl-parameter-closure-for-cover-obstruction-2026-08-16.md)
拆开处理：负面 cover obstruction 只需要 DDL 的截断 two-sided HDX 与 BMVY 群过滤
给出的有限连通 cover；swap-cocycle 只属于 DD 的 cover-aware 正面 theorem。故本 note
保留为 sampler/source 审计，正式的源特定已证明结论请引用 note 202。

本 note 给出一个 source-matched 的高价值定理门，而不是把外部 agreement theorem
误报成 GMWZ 的现成推论。两件事已经可以严格对齐：

1. GMWZ/BMVY 的 \((k,\sqrt{k})\) direct-product sampler 与 Dikstein--Dinur 的
   two-query (V)-test 是同一类“先取一个共同顶面，再取共同交面、最后独立取两面”的
   分布（只差 \(\sqrt{k}\) 的整数取整约定）；
2. BMVY 的复形是仿射 building \(\widetilde C_d\) 按离散群 \(\Gamma_i\) 的商，且构造中
   非平凡群元把任意顶点移动至少距离 \(4\)。这给出一个连通 cover，而不是 cover-free
   的 spherical-building 模型。

原先未决的 source-side gate 是“从 BMVY 局部谱陈述推出截断 two-sided HDX”。
DDL Theorem 3.15 已对同一 \(\widetilde C_d(\mathbb Q_p)\) 商族直接给出该截断谱界；
具体参数闭合与有限 cover 的量词见 note 202。这里仍不把结论外推为一般 dPCP
不可能性。

## 1. 采样匹配

GMWZ Definition 2.7 的抽样是：先均匀取 \(D\in X(d)\)，再取
\(B\subseteq D\) 且 \(|B|=\sqrt{k}\)，最后独立取
\(A,A'\in X(k)\) 满足 \(B\subseteq A,A'\subseteq D\)，比较
\(T[A]|_B\) 与 \(T[A']|_B\)。

Dikstein--Dinur 的 \(V\)-test 取

\[
d=2k-\sqrt{k+1}+1,
\]

先取 \(t\in X(d)\)，再在 \(t\) 内均匀条件取两个 \(k\)-面，且交大小为
\(\sqrt{k+1}\)。因此在把根号和面大小作一致的整数化后，两个测试的概率空间相同：
它们都不是单纯的 \(X(k)\leftrightarrow X(\sqrt{k})\) down-up walk，而是带共同顶面
条件的 shared-top law。任何把 BMVY Lemma 2.8 直接替换成该 law 的论证仍需显式的
条件谱比较；这与 C159--C160 的 sampler-normalization 警告一致。

## 2. BMVY 商复形确实产生有限连通 cover

设 \(\widetilde C_d\) 是 BMVY 使用的 affine building，
\(X_i=\Gamma_i\backslash\widetilde C_d\)，并取其群过滤中的
\(\Gamma_{i+1}<\Gamma_i\)，令 \(\ell=[\Gamma_i:\Gamma_{i+1}]>1\)。假设两层均满足对每个
\(1\ne\gamma\in\Gamma_j\) 和每个顶点 \(v\)，

\[
\operatorname{dist}(v,\gamma v)\ge 4. \tag{COV1}
\]

则商映射 \(\rho:X_{i+1}\to X_i\) 是一个有限、连通的 \(\ell\)-cover。

证明只用局部星形。满射和同态性来自商定义。给定顶点
\(\widetilde v\)，若两个邻点 \(u_1,u_2\) 在商中相同，则存在 \(\gamma\) 使
\(\gamma u_1=u_2\)。由于 (u_1,u_2) 都邻接 \(\widetilde v\)，有

\[
\operatorname{dist}(\gamma\widetilde v,\widetilde v)
\le \operatorname{dist}(\gamma\widetilde v,u_2)+
\operatorname{dist}(u_1,\widetilde v)\le 2,
\]

故由 (COV1) 得 \(\gamma=1\)，从而 \(u_1=u_2\)。商链接的满射同样由把一个代表
\(\gamma\widetilde v\) 拉回 \(\widetilde v\) 得到，因此每个链接映射是同构。连通性由
\(\widetilde C_d\) 连通给出。更高维面在链接中的同构随之保持。

BMVY Theorem 2.13 的构造段明确给出这样的群过滤与 (COV1)（其群元移动距离至少
4）；所以这里的有限 cover 不是人为添加的反例结构。无限的
\(\widetilde C_d\to X_i\) 只是 universal-cover 直觉，不能直接代替 DD 定义中的有限
\(\ell\)-cover。

## 3. cover-transfer 定理

令 \(X_{\le k}\) 表示只保留至 \(k\)-面层的截断复形。假设：

* (X_{\le k}) 是 \(\lambda\)-two-sided HDX，且 \(\lambda\le 0.99/k\)；
* \(\rho:Y\twoheadrightarrow X_{\le k}\) 是上节的有限连通 \(\ell\)-cover，且 \(\ell>1\)；
* \(\zeta<1/2\)。

则 Dikstein--Dinur 的 cover-obstruction lemma 给出一个二元局部函数族

\[
\mathcal F=\{f_r:r\in X(k)\},
\]

满足

\[
\operatorname{Agree}_{V}(\mathcal F)\ge 1/\ell,
\qquad
\forall H:X(0)\to\{0,1\},\quad
\Pr_{r\sim X(k)}[f_r\overset{1-\zeta}{\approx}H|_r]
\le \exp(-\Omega_\zeta(k)).
\tag{COV2}
\]

这里 \(V\) 就是第 1 节的 shared-top two-query test。该结论的逻辑意义是：在这些
参数下，常数级 agreement 不能被解释为一个 base-vertex global word；它至多能被
解释为 cover 上的 lift-word。

## 4. 对 simultaneous coordinate robustness 的含义

在 BMVY/DDL 参数窗口中，任何试图把 Section 6 的 tagged
table、DPT consistency 或普通 distributional soundness 黑箱升级为“同一 base proof
地址空间上的单一 global word”的方案，都会遇到 (COV2)。它必须明确选择下列一种逃逸：

1. 改用 cover-free 的复形（例如无连通 cover 的 spherical-building 路线）；
2. 把 cover sheet \(Y(0)\to X(0)\) 纳入 proof/address，证明 lift-word 的 sheet index
   仍可在 RW/JK 地址尺度绑定；
3. 加入超出普通 V-test agreement 的 coordinate-normalized outer check，使每个错误
   output bit 在同一 proof 上产生常数拒绝；
4. 若改用另一 source，则明确证明其截断谱/cover 假设不满足，并把该失败升级成
   同一 source family 上的 unique-decoding separation。

特别地，COV2 解释了 note 200 中 tagged-table 接口的剩余缺口：DPT 给出的 global
object 可能天然生活在 cover 的 sheet 上，因此“两个簇都从同一个 base global tag
得到正质量”不是一个纯粹的质量估计，而可能被拓扑 cover 阻断。

## 5. 不能宣称的结论

本 note **不**声称：

* GMWZ Theorem 2.9 单独已经证明 \(X_{\le k}\) 满足
  \(\lambda\le0.99/k\) 的全部截断 two-sided 条件；该缺口现在由 DDL Theorem 3.15
  对同一 source family 关闭，详细参数见 note 202；
* 普通 dPCP 一般不可能同时 coordinate-robust；
* cover obstruction 自动给出 RLDC/LDC 长度下界。

它把一个模糊的“phantom/global-word”问题压成一个已证的 source-specific 分叉：
BMVY/DDL 的带 cover source 必须显式绑定 sheet 或改用 coordinate-normalized outer
check；若要把该障碍推广成 RLDC/LDC 下界，仍需额外的 message-inline reduction。

## 来源

* Gur--Minzer--Weissenberg--Zheng, *3-Query RLDCs are Strictly Stronger than 3-Query
  LDCs*, Theorem 2.9 and Definition 2.7: <https://arxiv.org/html/2512.12960>
* Bafna--Minzer--Vyas, *Quasi-Linear Size PCPs with Small Soundness from HDX*,
  Theorem 2.13 and Appendix E: <https://arxiv.org/html/2407.12762>
* Dikstein--Dinur, *Agreement Theorems for High Dimensional Expanders in the Low
  Acceptance Regime: The Role of Covers*, Lemma 1.2 and Theorem 1.3:
  <https://arxiv.org/html/2308.09582>
* Dikstein--Dinur--Lubotzky, *Low Acceptance Agreement Tests via Bounded-Degree
  Symplectic HDXs*, Theorems 1.3 and 3.15:
  <https://arxiv.org/html/2402.01078>
