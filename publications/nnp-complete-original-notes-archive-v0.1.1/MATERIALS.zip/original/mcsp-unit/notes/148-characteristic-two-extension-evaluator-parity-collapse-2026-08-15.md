> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 特征 2 低度扩展 evaluator 的 parity 坍缩与素特征升级（2026-08-15）

## 结论

note 147 的计数论证在固定特征 2 上不能直接恢复整数
\(\#\mathrm{SAT}\)，因为 \(1/2\) 不存在；但它仍有一个严格的 parity 版本：

\[
\boxed{
\text{generic multilinear-extension evaluator over }\mathbb F_{2^b}
\Longrightarrow
\oplus\mathrm{SAT}\in\mathrm P
}
\]

如果 evaluator 还能对一族统一可构造的素域 \(\mathbb F_p\) 工作，则用同一插值和
CRT 可升级为 \(\#\mathrm{SAT}\in\mathrm{FP}\)。因此 C-W-Y 风格的特征 2
构造只有在“任意 table”与“固定 history”两个限制同时存在时，才避开这个通用坍缩。

## 特征 2 命题

令 \(D:\{0,1\}^{m}\to\{0,1\}\) 是 succinct Boolean circuit。设
\(\widetilde D:\mathbb F_{2^b}^{m}\to\mathbb F_{2^b}\) 是其 multilinear extension，
并假设 \(2^b>m\)、\(b=O(\log m)\)（或 field elements 与运算都有
\(\operatorname{poly}(m)\)-bit/time 表示）。若统一算法 \(E_m(D,\alpha)\) 能在
\(\operatorname{poly}(m+|D|)\) 时间内精确计算 \(\widetilde D(\alpha)\)，则
\(\oplus\mathrm{SAT}\in\mathrm P\)。

### 证明

对 \(t\in\mathbb F_{2^b}\)，定义对角限制

\[
  P_D(t):=\widetilde D(t,\ldots,t).
\]

令

\[
  c_w:=\sum_{x:\,|x|=w}D(x)\in\mathbb F_{2^b},
  \qquad 0\le w\le m.
\]

由 multilinear Lagrange 公式，

\[
  P_D(t)
  =
  \sum_{w=0}^{m}c_w\,t^w(1-t)^{m-w}.
\tag{1}
\]

多项式族
\[
  b_w(t):=t^w(1-t)^{m-w}
\]
是 \(\mathbb F_{2^b}[t]_{\le m}\) 的一组基：\(b_w\) 的最低次项是
\(t^w\)，系数为 \(1\)，所以从 \(w=0\) 到 \(m\) 的系数矩阵下三角且对角为 \(1\)。
由于 \(|\mathbb F_{2^b}|>m\)，取 \(m+1\) 个不同的 \(t\)，用 Vandermonde
插值先恢复 \(P_D\)，再在基 \(\{b_w\}\) 中恢复所有 \(c_w\)。每个 \(c_w\) 实际上
只可能是 \(0\) 或 \(1\)，分别表示重量 \(w\) 的 satisfying assignments 个数的
奇偶性。因此

\[
  \bigoplus_{x\in\{0,1\}^{m}}D(x)
  =
  \sum_{w=0}^{m}c_w
\]

可在 \(\operatorname{poly}(m+|D|)\) 时间内计算。由于 \(\oplus\mathrm{SAT}\) 是
\(\oplus\mathrm P\)-complete，得到 \(\oplus\mathrm{SAT}\in\mathrm P\)。证毕。

这里没有把 \(\oplus\mathrm P=\mathrm P\) 写成已知矛盾；它是一个尚未解决的复杂度
坍缩，只能作为 generic evaluator 的条件性障碍。

## 素特征升级

更强地，假设对每个 \(m\) 可以在多项式时间内列出一组素数
\(\mathcal P_m\)，满足

\[
  p>m\quad(p\in\mathcal P_m),
  \qquad
  \prod_{p\in\mathcal P_m}p>2^m,
\tag{2}
\]

并且 evaluator \(E_{m,p}\) 在 \(\mathbb F_p\) 上统一、精确且运行时间为
\(\operatorname{poly}(m+|D|+\log p)\)。对每个 \(p\)，取 \(m+1\) 个不同的
\(t\in\mathbb F_p\)，按式 (1) 插值得到

\[
  c_{w,p}\equiv
  \#\{x:|x|=w,\ D(x)=1\}\pmod p.
\]

对固定 \(w\)，用所有 \(p\in\mathcal P_m\) 做 CRT。因为
\(0\le c_w\le\binom mw<2^m<\prod p\)，CRT 唯一恢复整数 \(c_w\)，再求
\(\sum_w c_w\) 即得 \(\#\mathrm{SAT}(D)\)。总调用次数为
\((m+1)|\mathcal P_m|\)，只要 \(|\mathcal P_m|=\operatorname{poly}(m)\)，仍为
多项式时间。

条件 (2) 是故意显式写出的 uniformity 假设；不能用一个未给出构造的大素数替代
它。标准素数密度保证可以选取多项式大小的候选集合，但 evaluator 本身也必须允许
在这些素特征之间统一切换。

## 对 C-W-Y / RW 路线的精确边界

本 note 的 generic evaluator 要求同时覆盖：

1. 所有 succinct Boolean tables \(D\)；
2. 所有对角点评价 \(t\)；
3. 一个统一可构造的 field family。

C-W-Y 的 canonical PCP 低度扩展并不自动满足这三个条件。尤其是：

- 本项目采用的特征 2 模板只触发上面的 \(P=\oplus P\) 条件分支；
- 一个固定 history \(D_H\) 的 evaluator 不允许把 \(D\) 当作任意输入，因此不能运行
  \(\oplus\mathrm{SAT}\) 或 CRT 归约；
- local decoder 只从 proof oracle 反向读取 witness，仍不提供这里的 generic
  forward evaluator。

因此剩余可行目标仍是：

\[
\boxed{
\text{一个固定 history 的特征 2 whole-tree accessor，}
\text{而不是覆盖所有 }D\text{ 的通用 evaluator。}
}
\]

这是一条条件性复杂度障碍，不是一般 evaluator lower bound，也不声称已经证明
\(P\ne NP\)。

## 来源

- [C-W-Y, *Black-Box Constructive Proofs Are Unavoidable*](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.ITCS.2023.35)
  作为 canonical PCP 与低度扩展的构造背景。
- [note 147](147-generic-extension-evaluator-counting-collapse-boundary-2026-08-15.md)：
  特征零/大特征域的 \(\#\mathrm{SAT}\) 计数边界。
- [note 130](130-recursive-multivariate-polynomial-labeler-scale-2026-08-15.md)：
  全局多变量标签器的系数张量尺度。

核验日期：2026-08-15。
