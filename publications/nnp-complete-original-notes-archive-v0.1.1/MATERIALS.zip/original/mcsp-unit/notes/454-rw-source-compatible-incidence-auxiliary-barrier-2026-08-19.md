> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW source-compatible output incidence closes the remaining factorized auxiliary branch（2026-08-19）

## 本轮改变的判断

C453 把 Lemma 3.2 的直接 history predicate 编译成 hist-first 的
cell-time tableau circuit，并在 regular source 下给出 \(\widehat D\) 的
offset-regular evaluator。剩余接口中，C439 的 nondegenerate
incidence 不需要把 hard bit 写进 gate relation：Harsha 的 \(C'\) 只要在某个
固定 Boolean pattern 上标记一个包含目标变量的局部 gate 为非法，就已经说明
相应的三变量 slice 不是零多项式。

因此，在同一个 source-compatible serialization 中，output/equality block
可以显式生成 C439 所需的 incidence map。随后，\(P=p(q)\) 的任何同尺度
field-symbol evaluator 都会经 C439/C446 反演 systematic output，并支付
forcing-parent 的电路复杂度。真正剩下的 factorized 分支只有 \(P\)-evaluator
本身；这不是 \(P\ne NP\) 结论，因为 published RW 并未承诺该 serialization。

## 设置

固定 \(P=NP\) zero-round branch 中的 context \(x_0\)，令
\[
  B=M(x_0)\in\{0,1\}^{\ell}
\]
是 deterministic machine 的 output。取 C453 的 tableau compiler，并在
tableau variables 之后加入一个 fresh-variable output-check block。第 \(j\)
个 check 使用 out_j 与 deterministic tableau 的 output wire \(\mathrm{sim}_j\)，
由一个固定的 nontrivial fan-in-two gate gadget 检查
\[
  \mathrm{out}_j=\mathrm{sim}_j.
\]
所有 check gates 以连续 serial AND chain 接入最终 circuit output；每个
gadget 的 auxiliary variables 只在该 \(j\) 的 gadget 中出现。记得到的
hist-first circuit 为 \(D^{\mathrm{inc}}_{x_0}\)，其 Harsha gate relation 为
\(C'_{\mathrm{inc}}\)，低度延拓为 \(\widehat D_{\mathrm{inc}}\)。

Harsha 的关系 \(C'\) 对一个三元组只记录“这三个变量中的 gate 在给定
Boolean pattern 下是否非法”，变量的排列不影响其集合判定。对每个 \(j\)，
从 output-check gadget 选一个局部 gate，并将其三变量重新排列为
\[
  g_j=(u_j,v_j,w_j),\qquad u_j=\operatorname{index}(\mathrm{out}_j).
\]
由于 gadget 是固定且 nontrivial，选定一个固定
\(\beta^\star\in\{0,1\}^3\subseteq H^3\)，使该局部 gate 在
\(\beta^\star\) 上非法。fresh-variable 约束保证同一三元组不会被其他
gadget 重用。

## 定理 454.1（source-compatible incidence and auxiliary barrier）

在上述 serialization 下，存在一个由 \(j\) 的地址生成的
\[
  \operatorname{Inc}(j)=(g_j,\beta^\star)
\]
，其生成时间和电路大小为 \(\operatorname{poly}(m)\)，其中
\(m=\lceil\log_{|H|}N\rceil\)。它满足：

1. **Nondegenerate slice.**
   \[
   C'_{\mathrm{inc}}(g_j,\beta^\star)=1,
   \qquad
   Y\longmapsto
   \widehat D_{\mathrm{inc}}(u_j,v_j,w_j,Y_1,Y_2,Y_3)
   \text{ is not the zero polynomial.}
   \tag{454.1}
   \]
2. **Systematic projection.** 对任意满足赋值，hist projection 与 C453
   相同；其 out_j 位等于 \(B_j\)。因此若 \(q\) 是该 assignment 的
   Harsha polynomial，则
   \[
     q(u_j)=B_j.
     \tag{454.2}
   \]
3. **Auxiliary transfer.** 若同一 serialization 提供：
   * \(\widehat D_{\mathrm{inc}}\) 的 generic-point field-symbol evaluator
     \(E_D\)，大小为 \(s_D\)；
   * \(P=p(q)\) 的 generic-point field-symbol evaluator \(E_P\)，大小为 \(s_P\)；
   * \(j\mapsto g_j\) 与 \(H^m\) 地址编码的 evaluator，大小为
     \(s_{\mathrm{Inc}}+s_{\mathrm{out}}\)；
   且这些 evaluator 的 description、nonuniform 参数和地址控制均不含
   q-dependent 或 message-scale advice；

   则存在显式 \(K(m,|F|)=\operatorname{poly}(|F|,m)\)，使
   \[
     \operatorname{CC}(B)
     \le
     K(m,|F|)
     \bigl(s_P+s_D+s_{\mathrm{Inc}}+s_{\mathrm{out}}+1\bigr).
     \tag{454.3}
   \]
   特别地，在 \(|F|=\operatorname{poly}(m)\)、C453 的
   \(s_D,s_{\mathrm{Inc}},s_{\mathrm{out}}=\operatorname{poly}(m)\) 窗口内，
   一个 \(\operatorname{poly}(m)\)-size \(P\)-evaluator 会把
   forcing-hard parent \(B\) 压进 \(P/\mathrm{poly}\)。

### 证明

先看 (454.1)。所选局部 gate 在 \(\beta^\star\) 上是非法的，因此按
Harsha §5.4.1 的定义，
\[
  C'_{\mathrm{inc}}(g_j,\beta^\star)=1.
\]
Harsha 低度延拓在 \(H^{3m+3}\) 上与 \(C'\) 一致，所以固定
\((u_j,v_j,w_j)\) 后的三变量 slice 在 \(\beta^\star\) 处取非零值，
从而不是零多项式。C453 的 cell-time、连续 output block 和 fresh gadget
变量使三元组和 Boolean pattern 都能由 \(j\) 在 \(\operatorname{poly}(m)\)
时间生成；这正是 address-scale incidence。

对 (454.2)，C453 的 projection equivalence 说明所有 satisfying assignment
的 hist 部分恰是 Lemma 3.2 的 satisfying histories。fresh output-check
block 又强制 out_j 等于 deterministic output wire \(\mathrm{sim}_j=B_j\)，所以
systematic assignment coordinate \(u_j\) 的值为 \(B_j\)。

最后，把 \(\operatorname{Inc}(j)\) 代入 C439 的
auxiliary-to-systematic inversion。非零 slice 保证 C439 的枚举能找到
两个合法 denominator；\(O(|F|^3)\) 次 \(E_P,E_D\) 调用和有限域运算恢复
\(q(u_j)\)。再由 (454.2) 得到 \(B_j\)。将地址生成、有限域运算和这段
枚举对所有 \(j\) 的输入电路化，得到 (454.3)，也可直接引用 C446 的
复杂度转移。证毕。

## 对 RW Closure 的精确含义

* C453 + 定理 454.1 关闭了 source-compatible representation 中的
  **hist 语义、\(\widehat D\) layout 与 nondegenerate incidence** 三个接口。
* 若 \(P\) 也能在同一 proof/address space 以 \(\operatorname{poly}(m)\)
  访问，则 C439/C446 立即给出 parent evaluator，与 forcing lower bound
  矛盾；因此 \(P\)-evaluator 不能继续被视为中性辅助引理。
* 剩余正攻只有两类：证明 published RW 的 \(P\)-segment 确实有这种
  address-scale evaluator，或证明它必须退回 object/forcing scale；若两者
  都不成立，则必须退出 factorized \(P=p(q)\) relation，提出新的
  non-product global relation。

## 证据边界

* 这是 source-compatible compiler theorem，不声称 published RW 已规定
  fresh output-check、serial-AND 或 cell-time serialization。
* Harsha 的 \(C'\) 只证明非退化 incidence；它不把 \(B_j\) 直接 hardwire
  进 gate pattern，也不单独提供 \(P\)-evaluator。
* 定理依赖 \(P=NP\) zero-round deterministic recompilation、fixed machine、
  regular/address-succinct source 和 \(H\subseteq F\) 含 \(\{0,1\}\)。
* 本定理不证明 \(P\ne NP\)，但把 source-compatible Closure 的剩余
  factorized 缺口精确压缩为 \(P=p(q)\) 的 random access / forcing-scale
  barrier。

## 来源

* [note 453](453-rw-lex-prefix-preserving-local-tableau-compiler-2026-08-19.md)。
* [note 439](439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md)。
* [note 446](446-harsha-auxiliary-circuit-hardness-transfer-2026-08-19.md)。
* Harsha, *Robust PCPs of Proximity and Shorter PCPs*, §5.4.1,
  Proposition 5.4.1, equations (5.6)--(5.9)。
* Ren--Williams TR26-118 revision 1, Lemma 3.2 and Theorem 3.5。
