> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Finite-state normal form for non-product source exits（2026-08-19）

## 本轮改变的判断

C448 以“观察到 \(t\) 个 response bits”描述 finite-view source-exit。这个参数化
仍然把一个可能高度 non-product 的 global relation 写成了特定的交互格式。真正决定
RLDC 编译的不是 response 的来源，而是：固定 public tape 后，所有允许的策略在
给定 proof-answer transcript 上能诱导出的**可见状态 transcript 总数**是否有限。

下面把这个量直接作为接口参数。它覆盖任意有限状态、有限消息字母和有限轮 global
coupling，而不把它误称为 Harsha 的 \(P=p(q)\) factorization。

## 定理 449.1（finite-state non-product source-exit normal form）

令

\[
  \Pi:\{0,1\}^{k}\to\Sigma^{P},\qquad |\Sigma|=A\ge 2,
\]

是一个 common proof map。对每个 message coordinate \(i\) 和 claim \(b\)，给定一个
可能自适应的 verifier \(V_{i,b}\)，满足：

1. 每次执行使用至多 \(r\) 个 public random bits，并至多查询 \(q\) 个 proof symbols；
2. 固定 public tape 后，跨越所有允许的 global policies，在任意长度至多 \(q\) 的
   proof-answer transcript 上，verifier 能看到的 global-state transcript 属于一个
   固定集合 \(\mathcal V_{i,b}\)，且
   \[
     |\mathcal V_{i,b}|\le B;
   \]
3. 正确 claim 在 \(\Pi(m)\) 上存在完美接受的 policy；对每个
   \(z\) 满足 \(d_H(z,\Pi(m))\le \rho P\)，错误 claim 对所有 policies 的接受率
   至多 \(\beta<1\)。

这里的 global-state transcript 可以是任意 non-product 函数的有限摘要；它不要求
分解成 per-coordinate witness，也不要求 verifier 是 projection 或线性的。

则 message-inlining 后存在一个有限字母表 weak RLDC，其 locality 至多

\[
  Q_{\mathcal V}
  =1+2q\,2^r B A^q .
  \tag{449.1}
\]

在适用 GGS 任意有限字母 nonadaptive RLDC 下界、且

\[
  N:=k+P\le k(\log k)^c
\]

于无穷多个长度成立时，near-linear source-exit 必须满足

\[
  r+\log_2 B+q\log_2 A+\log_2(q+2)
  \ge
  \log_2\log k-\log_2\log_2\log k-O_{A,\rho,\beta,c}(1).
  \tag{449.2}
\]

特别地：

* 若 global state 是 \(h\) bits 的任意有限摘要，则 \(B\le 2^h\)，恢复 C448 的
  \(r+h+q\log A\) 预算；
* 若每轮从有限字母 \(\Omega\) 返回一个 state symbol，且最多 \(q\) 轮，则可取
  \(B\le |\Omega|^q\)，代价是 \(q\log|\Omega|\)；
* non-product 本身不构成 source-exit。真正的 exit 必须让 \(B\) 无界、让 physical
  proof/address space 随 target 改变，或改变 all-policy target-relative soundness
  的量词。

## 证明

固定 \((i,b)\)。一次执行中，future proof addresses 只依赖 public tape、已经读取的
proof symbols，以及该执行的 global-state transcript。因此所有 policies 可达到的
proof positions 的并集大小至多

\[
  q\,2^r B A^q .
\]

这一步只枚举可见状态，不枚举 policy 的内部计算；所以 global state 可以是任意
non-product 的函数，只要它的可见 transcript 集合大小受 \(B\) 控制。把 message bit
inline 到 proof word，并用 disjoint tags 区分 inline/proof symbols。由错误 claim 的
all-policy soundness，离 \(\Pi(m)\) 的承诺半径内，枚举所有 visible views 后的错误分支
仍不超过 \(\beta\)；在 \(\Pi(m)\) 上，honest policy 使正确分支达到 1。以阈值
\((1+\beta)/2\) 输出 claim，否则输出 \(\bot\)，即可得到 locality (449.1) 的
nonadaptive RLDC。

proof map 的 pairwise distance 与 \(A\)-ary Singleton/injectivity 给出只依赖
\((\rho,A)\) 的正半径（其 proof-suffix 错误预算取为 \(\rho P\)）。应用 GGS 的
finite-alphabet lower bound，并代入 (449.1)，得到 (449.2)。

证毕。

## 证据边界

定理 449.1 不是一般 non-product dPCP 的不可能性定理。它只关闭“有限可见状态包装”
这一类 source-exit；如果一个正向构造使用无界/连续 response、不可枚举的 global
state、target-dependent physical proof，或 selected-policy-only soundness，就必须把
该新资源和新量词明确写进定理，不能再把它归入 finite-state common-proof 模型。

同样，published RW fixed-\(x_0\) singleton 不会仅凭这一定理进入 family-level RLDC
分支；该情形仍需使用 C207/C446 的 forcing-scale descriptor accounting。

## 来源

* [C448 / note 448](448-harsha-source-exit-finite-view-rldc-bridge-2026-08-19.md)。
* [C268 / note 268](268-finite-view-strategy-entropy-barrier-2026-08-17.md)。
* Goldberg--Gur--Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally Decodable
  Codes via Robust Daisies*, arXiv:2511.21659, Theorem 1：
  <https://arxiv.org/html/2511.21659>。
