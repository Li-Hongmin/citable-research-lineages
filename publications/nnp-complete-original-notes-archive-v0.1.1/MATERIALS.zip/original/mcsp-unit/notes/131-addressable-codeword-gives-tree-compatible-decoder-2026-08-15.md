> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 地址可访问码字直接给出 tree-compatible decoder（2026-08-15）

## 条件化构造

设 \(k,L,q\) 是参数，并有一族 total codewords

\[
C_n:\{0,1\}^k\longrightarrow\{0,1\}^{2qL}.
\]

按固定顺序写成 blocks

\[
B_n(x,j):=C_n(x)[2qj\,..\,2q(j+1)-1],
\qquad j\in[L].
\]

假设存在一个统一的 multi-output block accessor

\[
A_n(x,j)=B_n(x,j),
\qquad
|A_n|\le S_A,
\tag{1}
\]

且 \(k+\lceil\log L\rceil+O(1)\le q\)。这里 \(A_n\) 是电路而不是“给出
\(B_n\) 的存在性”；它必须在一次调用中输出完整 \(2q\) bits。

固定一棵 \(L=2^h\) 叶的二叉树。用 \(q\)-bit seed 编码

\[
\operatorname{enc}_{\rm leaf}(x,j),
\qquad
\operatorname{enc}_{\rm int}(x,v),
\]

其中含有 mode tag、\(x\) 和 leaf/node address，其余位固定 padding。定义
\(G^{\rm addr}_{n,q}:\{0,1\}^q\to\{0,1\}^{2q}\)：

1. leaf mode 输出 \(A_n(x,j)=B_n(x,j)\)；
2. internal mode 输出
   \[
   \operatorname{enc}_{\rm int}(x,v_0)
   \Vert
   \operatorname{enc}_{\rm int}(x,v_1),
   \]
   其中 \(v_0,v_1\) 是 node \(v\) 的两个孩子；
3. malformed seed 映到固定 zero block。

于是

\[
|G^{\rm addr}_{n,q}|
\le S_A+O(q+\operatorname{polylog}q).
\tag{2}
\]

对每个 \(x\)，叶 blocks \(B_n(x,j)\) 都在
\(\operatorname{Range}(G^{\rm addr}_{n,q})\)；并且选择上述显式 seeds 后，每个
internal JK parent 也在该 range：

\[
\operatorname{enc}_{\rm int}(x,v_0)
\Vert
\operatorname{enc}_{\rm int}(x,v_1)
=
G^{\rm addr}_{n,q}(\operatorname{enc}_{\rm int}(x,v)).
\tag{3}
\]

这给出一个真正的 whole-tree、word-consistent labeling，而不是逐 bit 地寻找
不同 witnesses。

## Systematic coordinate 暴露障碍

若存在固定的 block/bit 坐标 \((j_n,\ell_n)\) 使

\[
C_n(x)[2qj_n+\ell_n]=f_n(x),
\tag{4}
\]

则任何满足式 (1) 的 accessor 都立即给出

\[
\operatorname{CC}(f_n)
\le S_A+O(q+\log L).
\tag{5}
\]

证明只需把 \(j_n,\ell_n\) hardwire 到 \(A_n\)，再接出指定输出位。因而若
\(\operatorname{CC}(f_n)>n^{k(n)}\) 且 \(k(n)\to\infty\)，就不可能同时有
\(q,S_A=n^{O(1)}\)。这不是 Universal-LTC 的测试下界，而是码字**生成/访问**
与函数电路复杂度之间的直接传递。

Goldreich--Gur 的 universal-LTC 只保证：给定一个码字 oracle，可以对
\(\{C(x):f_i(x)=1\}\) 做局部测试；它不把式 (5) 变成无效。局部测试复杂度、
码字坐标的生成复杂度和 JK 的整词 preimage 是三个不同接口，不能互相替代。

## 与标准 JK 的选择规则

式 (3) 使用的是一个显式 verified selector。若 JK 版本允许 choice-robust
preimages，则它可以直接使用该 selector。若 JK 固定选每个 block 的
lexicographically first seed，则还必须证明

\[
\operatorname{lexmin}G^{-1}(B_n(x,j))
\]

仍由 \((x,j)\) 的小访问器生成；仅有式 (1) 不足以推出这一点。故本构造解决的是
tree closure，不自动解决 canonicalization。

## 为什么 Universal-LTC 只解决表示层，不自动解决 RW

Goldreich--Gur 的 universal-LTC 定理对函数族
\(\{f_i:\{0,1\}^k\to\{0,1\}\}_{i\in[M]}\) 给出长度
\(\widetilde O(Ms)\) 的 code \(C(x)\)，其中每个 \(f_i\) 有 size-\(s\)
电路，并可对每个 \(f_i(x)=1\) 的子码作常数查询测试。这个结果说明：

- 若 RW 的完整 history 确实有一个短消息 \(x\)，并且每个 history block
  都有统一的 \(S_A=\operatorname{poly}(k+\log L)\) block accessor，那么式
  (1)--(3) 可把它变成 near-linear-size、tree-compatible decoder；
- 但 universal-LTC 的 theorem 本身只保证 code 和局部测试，不保证 RW 的
  \(\Pi_x\) 就是这样的 codeword，也不把一个
  \(\operatorname{TIME}[\operatorname{poly}(t)]^{NP}\) 的 proof generator
  自动降到 \(\operatorname{poly}(n)\)-size block accessor。

在 Ren--Williams 的 Theorem 3.5 中，\(\Pi_x\) 的 completeness proof 可在
\(\operatorname{poly}(t(n))^{NP}\) 资源内生成；当 \(t(n)=2^{\Theta(n)}\)
时，这个已知生成程序仍是指数于 \(n\) 的。把它直接作为 \(A_n\) 会使
\(S_A\) 和 \(q\) 回到 time-scale，而不是 note 121 所需的
\(\operatorname{poly}(n)\)-scale。

## 可晋级的精确接口

因此，RW 路线的剩余问题可以改写为一个明确的“地址可访问历史”命题：

\[
\boxed{
\begin{array}{l}
\text{存在固定 }k(n),L(n),q(n)=\operatorname{poly}(n)
\text{ 与统一 }A_n\text{，}\\
A_n(x,j)=\Pi_x[2qj..2q(j+1)-1],\quad
|A_n|=\operatorname{poly}(n),\\
\text{并且该 }A_n\text{ 与 RW 的 smart-prMA/JK 选择规则保持一致。}
\end{array}}
\tag{6}
\]

若式 (6) 成立，式 (2)--(3) 给出 whole-tree closure；再结合 note 121 的
\(P=NP\Rightarrow PH=P\) collapse，即可得到 \(P\ne NP\)。若式 (6) 失败，
失败原因必须落在 block accessor、canonicalization 或 smartness 三者之一，而
不能再笼统归因于“PCP 叶块没有代数结构”。

## 文献边界

Universal-LTC 的原始结果见：

- [Goldreich--Gur, *Universal Locally Testable Codes*](https://www.wisdom.weizmann.ac.il/~oded/VO/ultc.pdf)，Theorem 3.2；
- [Ren--Williams official report](https://eccc.weizmann.ac.uk/report/2026/118/revision/1/download)，Theorems 3.5 与 4.1。

本 note 的式 (1)--(3) 是把地址 accessor 接到 JK decoder 的自足组合引理；
Goldreich--Gur 的 universal-LTC 结果不被误述为已经提供式 (6)，也不产生
\(P\ne NP\) 结论。
