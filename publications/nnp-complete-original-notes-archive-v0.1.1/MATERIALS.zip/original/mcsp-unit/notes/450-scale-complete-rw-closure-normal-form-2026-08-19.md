> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Scale-complete RW Closure normal form（2026-08-19）

## 本轮改变的判断

已有的 Closure Theorem（note 204）说明了一个 address-scale、same-proof、
single-valued evaluator 一旦成立就会给出 \(P/\mathrm{poly}\) 矛盾；note 358
又指出不能把 RW 的 stable solver branch 自动当成已被下界排除。C447--C449
进一步关闭了 published Harsha 的 factorized branch 和 finite-state
non-product source-exit，但这些结果尚未放进同一个尺度完备的分类。

下面给出一个只在明确声明的接口模型内使用的 normal form。它的作用不是把
\(P\ne NP\) 的证明缺口改名为“已解决”，而是把每一个仍可能改变路线的出口写成
互斥的、可检验的成本条件。

## 定理 450.1（scale-complete RW Closure normal form）

令 \(H_N\in\{0,1\}^{N}\) 是 RW/JK forcing branch 在无限长度集合
\(\mathcal I\) 上产生的同一个 canonical object，令

\[
  m_N=\lceil\log_2(N+1)\rceil,\qquad
  \operatorname{CC}(H_N)>S_N\quad(N\in\mathcal I),
  \tag{450.1}
\]

并假设 \(S_N\) 最终超过每一个固定的 \(m_N\) 多项式。考虑一个声称在
\(P=NP\) 下把该对象压入 \(P/\mathrm{poly}\) 的 RW closure interface，要求它在
一个长度上始终针对同一个 \(H_N\)，并把所有非一致 selector、descriptor
和 proof/address data 明确计入成本。则，对每个 \(N\in\mathcal I\)，以下四类中的
至少一类成立：

### (S) stable object-scale solver

接口在该长度选择 RW 的 solver branch，并在 \(P=NP\) 确定化后给出一个大小为
\(U_N\) 的 evaluator，但只保证

\[
  U_N=N^{O(1)}\quad\text{或更一般地}\quad U_N\ge m_N^{\omega(1)}.
  \tag{450.2}
\]

这种 branch 与 near-maximum 的 \(S_N\le N/\operatorname{polylog}N\) 可以相容；
它本身不产生最终矛盾。若另有同一个 \(H_N\) 的 address-scale evaluator
\(U_N=m_N^{O(1)}\)，则转入 (A)。

### (A) address-scale single-object closure

存在一个固定的 single-valued evaluator \(E_N(a;\sigma_N)\)，对每个
\(a\in[N]\) 输出 \(H_N[a]\)，其地址、控制状态、collapsed promise/PH
查询和 descriptor \(\sigma_N\) 的总描述长度均为 \(m_N^{O(1)}\)。则

\[
  \operatorname{CC}(H_N)=m_N^{O(1)},
  \tag{450.3}
\]

与 (450.1) 矛盾。这里允许 \(\sigma_N\) 是每个长度的一份非一致 advice；若
selector 还可由固定算法生成，则得到更强的 uniform \(P\) evaluator。

### (R) common-ROM reconstruction payment

若 failure/reconstruction branch 使用同一个 proof/address space，并且所有地址
通过一个 straight-line/有限控制的 ROM evaluator 共享一个 descriptor
\(\sigma_N\in\{0,1\}^{d_N}\)，控制电路大小为 \(p_N\)，最多读取 descriptor
\(b_N\le p_N\) 次，且在 \(P=NP\) 下每个 collapsed query 已经是
address-scale 可计算的，则存在普通 fan-in-two circuit 满足

\[
  \operatorname{CC}(H_N)
  \le
  O\!\left(p_N^2+p_Nd_N+p_Nm_N\right).
  \tag{450.4}
\]

因此，在控制项已计入后，必有

\[
  p_N^2+p_Nd_N+p_Nm_N=\Omega(S_N).
  \tag{450.5}
\]

特别地，\(p_N=\operatorname{poly}(m_N)\) 而 \(S_N=N/\operatorname{polylog}N\)
时，descriptor 或控制器本身必须支付 object-scale 信息；把整张 history
改名为 \(\sigma_N\) 不构成压缩。

### (F) finite-state common-proof source-exit

若接口不是 Harsha factorization，却仍使用一个 common proof
\(\Pi:\{0,1\}^{k}\to\Sigma^{P}\)、target-relative all-policy wrong-claim
soundness、\(r\) 个 public random bits、\(q\) 次 proof 查询，并且固定 public
tape 后所有 global policies 可见的 state transcript 集合大小至多为 \(B\)，则
message inlining 给出 locality

\[
  Q_{\mathcal V}=1+2q\,2^r B|\Sigma|^q.
  \tag{450.6}
\]

在适用 finite-alphabet RLDC lower bound 且 \(k+P\le k(\log k)^c\) 的窗口内，

\[
  r+\log_2B+q\log_2|\Sigma|+\log_2(q+2)
  \ge
  \log_2\log_2 k-\log_2\log_2\log_2 k-O(1).
  \tag{450.7}
\]

因此有限状态的 non-product 包装不是新的免费出口。注意 (F) 是 family-level
结论；对 published fixed-\(x_0\) singleton，不能把不存在的目标熵强行引入，
仍应使用 (R) 或 singleton-specific forcing accounting。

### (E) genuine model exit

如果 (S)、(A)、(R)、(F) 都不能适用，则接口至少改变了一个承重量词或资源：

* 不再共享一个 physical proof/address space；
* visible global state 无界，或 query/address 随 target 改变；
* soundness 不再是 target-relative all-policy soundness；
* gap、长度对齐或同一 canonical object 条件失效；或
* 使用一个尚未定义的全局 coupling。

这不是现有 RW/JK 证明的第五个 branch，而是必须单独提出并证明的新模型。

## 证明

若接口选 solver branch，则 \(P=NP\) 只负责把实际 smart query 在其给定的
representation scale 上确定化，得到 (S)；除非另有 \(m_N\)-scale 压缩，不能从
\(U_N=N^{O(1)}\) 推出 (450.3)。

若存在 (A)，把固定的 \(\sigma_N\) 接到 evaluator 的常数线上，以
\(\lceil\log_2N\rceil=m_N\) 位地址作输入，即得到大小 \(m_N^{O(1)}\) 的
truth-table circuit，故 (450.3) 与 (450.1) 矛盾。

若存在 (R)，把每次 descriptor 读取替换为一个 \(d_N\)-输入多路选择器，
并展开有限控制流。至多 \(p_N\) 个控制/读取步骤给出
\(O(p_N^2+p_Nd_N+p_Nm_N)\) 大小的普通 fan-in-two circuit；固定
\(\sigma_N\) 后该电路逐地址输出 \(H_N\)，得到 (450.4)--(450.5)。这正是
ROM-advice accounting，而不是把 descriptor 当作免费 oracle。

若接口进入 non-product branch，且仍满足 (F) 的 common-proof、有限可见 state
和 all-policy 量词，枚举 public tape、state view、proof-answer transcript
后得到 (450.6) 的 nonadaptive RLDC；应用相应的 finite-alphabet lower bound
得到 (450.7)。

最后，若接口既不是上述 solver/evaluator/ROM/family finite-state 形式，又仍被
宣称为 Closure，则至少有一项定义域或量词已改变，正是 (E)。证毕。

## 对 Closure 计划的直接后果

1. 已发表 RW Theorem 4.1--4.3 的 Solve/Reconf 目前只落在 (S)：其时间和
   query 描述按 \(k\) 或显式 history length 计，而不是按 \(m=\log N\) 计。
2. C442--C446 已把 published Harsha branch 的剩余正攻压到同一 serialization
   上的 \(P=p(q)\) random access；一旦它是 (R) 且保持 address scale，便立即进入
   (450.4)，不能再作为中性辅助 lemma。
3. C449 已把有限状态的 non-product source-exit 归入 (F)。因此下一项真正有
   独立价值的工作只有两种：
   * 证明实际 RW singleton 进入 (A) 或 (R) 并支付 forcing contradiction；或
   * 构造一个明确属于 (E) 的新 global relation，并同时说明它怎样避开 (450.7)
     而不偷换 soundness/同一对象量词。

这一定理是条件性 Closure normal form，不是 \(P\ne NP\) 证明，也不是一般
dPCP/RLDC 不可能性定理。它的贡献是把“闭合”所需的地址尺度、descriptor、
common-proof 和 finite-state 资源一次对齐，阻止把对象尺度的求解器或 per-address
phantom witness 冒称为最终 evaluator。

## 来源

* [RW succinct smart reconstruction closure theorem](204-rw-succinct-smart-reconstruction-closure-theorem-2026-08-17.md)。
* [RW scale-complete Closure Audit](358-rw-scale-complete-closure-audit-2026-08-18.md)。
* [RW logical-scale collapse boundary](431-rw-logical-scale-collapse-boundary-2026-08-19.md)。
* [Harsha auxiliary-to-systematic inversion gate](439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md)。
* [Harsha auxiliary-to-systematic circuit-hardness transfer](446-harsha-auxiliary-circuit-hardness-transfer-2026-08-19.md)。
* [Finite-state non-product normal form](449-finite-state-global-relation-normal-form-2026-08-19.md)。
