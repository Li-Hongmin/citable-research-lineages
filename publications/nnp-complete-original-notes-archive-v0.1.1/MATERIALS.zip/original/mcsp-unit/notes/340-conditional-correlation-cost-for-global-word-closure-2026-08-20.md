> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Conditional-correlation cost for global-word closure (2026-08-20)

## Contribution

The policy-level closure gate previously had two endpoints: conditional product
responses (C286) and a joint distribution with fixed coordinate marginals (C285).
The missing middle is a quantitative statement for arbitrary residual dependence
after conditioning on the policy.  The theorem below charges that dependence by
conditional total correlation.  It is an information-theoretic barrier, not a
claim that every dPCP has conditional-product responses.

## Theorem (conditional-correlation closure inequality)

Let \(\Gamma\) be an alphabet of size \(A\ge2\), let
\(\mathcal Y\subseteq\Gamma^M\) be the valid global-word family, and put
\[
  \mathcal A_t:=\{z\in\Gamma^M:d_H(z,\mathcal Y)\le t\},
  \qquad
  B_{H,t}:=|\mathcal Y|V_A(M,t)2^{-H},
\]
where \(V_A(M,t)=\sum_{u\le t}\binom Mu(A-1)^u\).

Let \(S\) be any policy variable and let \(Z\in\Gamma^M\) be the resulting
random word.  For each policy value \(s\), let \(\mu_s\) be the conditional law
of \(Z\), let \(\nu_s=\bigotimes_{j=1}^M\mu_{s,j}\) be the product of its
coordinate marginals, and define
\[
  \operatorname{TC}_2(s):=D_2(\mu_s\|\nu_s)
   =\sum_{j=1}^M H_2(Z_j\mid S=s)-H_2(Z\mid S=s).
\tag{340.1}
\]
Let \(G\) be a set of policy values with \(\Pr[S\in G]\ge1-\delta\).  Assume
that for every \(s\in G\),
\[
  \sum_{j=1}^M H_\infty(Z_j\mid S=s)\ge H,
\tag{340.2}
\]
and that \(B_{H,t}\le1\).  Write
\[
  p:=\Pr[Z\in\mathcal A_t],
  \qquad
  \bar p_G:=\Pr[Z\in\mathcal A_t\mid S\in G],
  \qquad
  \Xi_G:=\mathbb E[\operatorname{TC}_2(S)\mid S\in G].
\]
Then
\[
  \Xi_G\ge \bar p_G\log_2\frac1{B_{H,t}}-1.
\tag{340.3}
\]
Consequently, if \(p\ge p_0>\delta\),
\[
  \Xi_G\ge
  \frac{p_0-\delta}{1-\delta}\log_2\frac1{B_{H,t}}-1.
\tag{340.4}
\]
Equivalently,
\[
  p\le \delta+(1-\delta)\frac{\Xi_G+1}{\log_2(1/B_{H,t})}.
\tag{340.5}
\]

### Proof

For \(s\in G\), (340.2) implies that every atom of the product law \(\nu_s\)
has probability at most \(2^{-H}\).  Hence
\[
  \nu_s(\mathcal A_t)\le B_{H,t}.
\]
Data processing for relative entropy under the indicator of \(\mathcal A_t\)
gives, with \(p_s=\mu_s(\mathcal A_t)\),
\[
  \operatorname{TC}_2(s)
  \ge d_2\bigl(p_s\,\|\,\nu_s(\mathcal A_t)\bigr)
  \ge p_s\log_2\frac1{B_{H,t}}-h_2(p_s)
  \ge p_s\log_2\frac1{B_{H,t}}-1.
\]
Average over \(s\in G\) to obtain (340.3).  Since
\(p\le\delta+(1-\delta)\bar p_G\), a lower bound on \(p\) gives
\(\bar p_G\ge(p_0-\delta)/(1-\delta)\), proving (340.4); rearranging gives
(340.5).  \(\square\)

## Full-projection consequence

Assume every coordinate projection of \(\mathcal Y\) is all of \(\Gamma\), the
minimum relative distance is \(\Delta=d/M\), and \(t=\lfloor\varepsilon M\rfloor\).
If \(H\ge M(\log_2 A-\zeta)\), the Singleton bound and the volume estimate give
\[
  \log_2\frac1{B_{H,t}}
  \ge
  M\bigl((\Delta-H_A(\varepsilon))\log_2 A-\zeta\bigr)-O_A(\log M),
\tag{340.6}
\]
where \(H_A\) is the \(A\)-ary entropy function.  Therefore, whenever
\(\Delta>H_A(\varepsilon)\) and \(\zeta<(Delta-H_A(\varepsilon))\log_2 A\),
constant global-word success on a policy-good mass forces
\[
  \Xi_G=\Omega_{A,\Delta,\varepsilon,\zeta,p_0,\delta}(M).
\tag{340.7}
\]
Thus a near-linear shared-proof construction cannot leave a third option in which
the policy carries little target information, the conditional coordinate outputs
retain almost all of their local entropy, and the residual joint correlation is
sublinear.  At least one of these quantities must be linear-scale (or the policy-good
mass must be small).

## Relation to the existing gates

* If \(\operatorname{TC}_2(s)=0\) on the good policies, (340.5) specializes to
  the conditional-product barrier in C286.
* If \(S\) is trivial and the coordinate marginals are uniform, (340.3) is the
  event-level form of the fixed-marginal correlation cost in C285.
* A short latent seed can still generate a word with linear total correlation, so
  (340.7) is not by itself a lower bound on seed length.  The seed/descriptor term
  must be charged separately by the policy-information gates C281/C287.

The new theorem therefore closes the *statistical* residual-correlation escape, but
not the possibility of a genuinely joint global relation whose correlation is carried
by a short seed.  That remaining mechanism is precisely the positive construction
target for the RW/JK attachment.

## Corollary (target-channel trichotomy)

There is a complementary identity that locates where the target information can enter.
Let \(M\) be uniform on a message set \(\mathcal M\), let
\(Y:\mathcal M\hookrightarrow\Gamma^M\) be injective with minimum distance greater
than \(2t\), and let \(Z\)
be any random output jointly distributed with a policy \(S\).  If
\[
  p=\Pr[d_H(Z,Y(M))\le t],
\]
then
\[
\begin{aligned}
 I_2(M;S)
 &+\sum_{j=1}^{M} I_2(M;Z_j\mid S)
 +\mathbb E\!\left[\operatorname{TC}_2(Z\mid M,S)\right]  \\
 &\ge p\log_2|\mathcal M|-1.
\end{aligned}
\tag{340.8}
\]
Here \(\operatorname{TC}_2(Z\mid M,S)\) is the total correlation of the coordinate
outputs after conditioning on both the target and the policy.

Indeed, nearest-word decoding and Fano give
\(I_2(M;S,Z)\ge I_2(M;Z)\ge p\log_2|\mathcal M|-1\).  The chain-rule identity
\[
 I_2(M;S,Z)
 = I_2(M;S)+\sum_j I_2(M;Z_j\mid S)
 -\operatorname{TC}_2(Z\mid S)
 +\operatorname{TC}_2(Z\mid M,S)
\]
and nonnegativity of \(\operatorname{TC}_2(Z\mid S)\) imply (340.8).

Thus a short policy and low-information coordinate marginals are compatible with
global decoding only if the responses retain large target-conditioned joint
correlation.  In the usual model of independent private randomness conditioned on
\((M,S)\), that last term is zero, so the target information must be visible through
the policy or the sum of the coordinate channels.  This corollary is an accounting
identity, not an unconditional lower bound on proof length; its role is to make the
remaining joint-relation interface explicit.
