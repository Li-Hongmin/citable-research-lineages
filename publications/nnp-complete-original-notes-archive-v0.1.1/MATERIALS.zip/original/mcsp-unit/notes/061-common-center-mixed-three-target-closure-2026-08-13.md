> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 同中心 mixed 三 target：union-flip 条件下的条件性闭合（2026-08-13）

## 结论边界

固定中心 row \(x_0\)，设 \(\mathcal F\) 是关于 spoiler
\(s=(x_s,y_s)\) 的 inclusion-minimal row-star witness 族。令

\[
d_y=y+x_0,\qquad a=x_s+x_0,\qquad b=y_s+x_0,
\qquad c=a+b .
\]

若对 witness 的所有列并集

\[
Y_*:=\bigcup_{S\in\mathcal F}S
\]

存在一个向量 \(w\) 满足

\[
w\cdot a=w\cdot b=0,
\qquad w\cdot d_y=1\quad(y\in Y_*),
\tag{UF}
\]

则 mixed \(R/C/P\) 同中心 row-star 子族满足更强的界

\[
\Pr_{z,U,V}[\exists T\in\mathcal F:T\subseteq R_z(U,V)]
\le {3\over64}< {1\over16}.
\]

因此 (UF) 足以补上目标的第二个 `1/2` 因子，但 (UF) 不是一般极小
witness 族自动满足的条件；无条件的 mixed 三 target 闭合仍未证明。

而且 (UF) 一旦存在 \(R\) 型 witness 就立即矛盾：对该 witness 的列求和会给
\(w\cdot a=|S|=1\)，与 \(w\cdot a=0\) 冲突。因此全局 (UF) 只能用于没有 \(R\)
型 witness 的退化 mixed（实际上是 \(C/P\)）子族；它是一个清晰的条件性边界，
不是一般三 target 命题的解决方案。

以下 state 计数先按 `a!=0` 写；若 `a=0`，则 spoiler row 与中心 row 相同，
`R` 型不可能，`C/P` 在中心 row 条件下等价于一个固定 separator，直接归入
note 045 的闭合。
在 `a!=0` 时，`b!=0` 且 `a!=b` 由 `X cap Y=emptyset` 得到，所以 `a,b`
在二元域上线性独立，四个 state 确实等概率。

## 1. row-star 的 target 结构

对 `T_S={(x_0,y):y in S}`，note 046 给出 `D_S={d_y:y in S}` 线性独立，且

\[
\begin{array}{c|c|c}
\text{type}&|S|\pmod 2&\bigoplus_{y\in S}d_y\\ \hline
R&1&a\\
C&0&b\\
P&0&c
\end{array}
\tag{1}
\]

对 inclusion-minimality 还可推出：真子集 `Q` 不能满足表 (1) 的任一行。
否则 `T_Q` 加 spoiler 已不相容，从而某个单点删除后的 witness 仍不相容。

固定 `r` 后，中心 row 方程为零时，活跃列集合是

\[
B_r=\{y:r\cdot d_y=1\}.
\]

以 `sigma=(r dot a,r dot b)` 分 state，可能活跃的类型为

\[
00:C,P,\qquad 10:R,C,\qquad 11:R,P,\qquad 01:\varnothing .
\tag{2}
\]

## 2. (UF) 如何给出 state 内的配对

记 `F_sigma` 为在 state `sigma` 中可活跃的 witness 列集族，并令

\[
J_\sigma:=\{y:\exists\,S\ne T\in F_\sigma, y\in S\cap T\}.
\]

全局条件 (UF) 显然蕴含 `w dot d_y=1` 对每个 `J_sigma` 成立。更弱的
state-wise 条件是：对每个含至少两个 witness 的 `F_sigma`，存在 `w_sigma` 使

\[
w_\sigma\cdot a=w_\sigma\cdot b=0,
\qquad w_\sigma\cdot d_y=1\quad(y\in J_\sigma).
\tag{UF-s}
\]

在 (UF-s) 下，平移 `r -> r+w_sigma` 保持 state。若 `r` 命中 `S`，而
`r+w_sigma` 命中 `T`，则 `S cap T` 中的某个 `y` 属于 `J_sigma`；它在
两边的活跃值恰好翻转，矛盾。因此

\[
\Pr_r[E_\sigma\mid\sigma]\le {1\over2}
\tag{3}
\]

对每个 state 都成立。全局 (UF) 是 (UF-s) 的简单充分条件。

这里对单 witness state 作一个小补充：若 `F_sigma={S}`，不需要 (UF-s)。
在固定 state 后，`S` 的列方程还剩至少 `|S|-1` 个独立约束；`C/P` 型有
`|S|>=2`，而 `R` 型 singleton 不可能（`d_y=a` 会给 `y=x_s`，与
`X cap Y=emptyset` 冲突），所以 `Pr[E_sigma|sigma] <= 1/2`。当
`|F_sigma|>=2` 时，`J_sigma` 非空，(UF-s) 的平移才用于上面的不交论证。

## 3. 从 state 配对到完整 thinning 界

四个 state 等概率；`01` 没有 witness。由 (3)，

\[
\Pr_r[\exists S\in F:S\subseteq B_r]
\le {1\over4}\left({1\over2}+{1\over2}+{1\over2}\right)
= {3\over8}.
\tag{4}
\]

固定 `r`，令

\[
F_r=\{S\in F:S\subseteq B_r\}.
\]

它是两两相交的列集族。对均匀随机列保留子集 `V subseteq B_r`，补集配对给出

\[
\Pr_V[\exists S\in F_r:S\subseteq V]
\le {1\over2}\,1[F_r\ne\varnothing].
\tag{5}
\]

结合 (4)：

\[
\Pr_{r,V}[\exists S:S\subseteq B_r\cap V]
\le {1\over2}\cdot {3\over8}={3\over16}.
\tag{6}
\]

命中 row-star 还必须满足中心 row affine 方程（参数概率 `1/2`）并保留中心
row（thinning 概率 `1/2`），所以

\[
\Pr_{z,U,V}[\exists T\subseteq R_z(U,V)]
\le {1\over2}\cdot {1\over2}\cdot {3\over16}
= {3\over64}< {1\over16}.
\tag{7}
\]

列-star 情形交换 row/column 即得。

## 4. 原先更强论证的缺口

仅对一个固定偶 witness `S_0` 构造

\[
w\cdot a=w\cdot b=0,\qquad w\cdot d_y=1\ (y\in S_0)
\]

是不够的。若 `r` 命中 `S`、`r+w` 命中 `T`，两两相交性只给出
`S cap T` 非空；交点不必属于 `S_0`，所以不能断言该交点的活跃位被 `w`
翻转。该论证不能推出 state 内不交，也不能推出 mixed 闭合。

这一点在真实 affine 配置中确实发生。取
`Y=(22,25,21,26,23,15,20,1,28,11)`、`x_0=10`、`s=(24,1)`，则
`D=(28,19,31,16,29,5,30,11,22,1)`、`a=18`、`b=11`。一个两两相交的
极小 row-star 子族含（集合下标按 `D` 的显示顺序）

\[
S_0=\{0,8,2,6\}_C,\qquad
T=\{9,2,3,5\}_C,\qquad
U=\{0,3,6\}_R .
\]

向量 `w=4` 保持 `a,b` 且翻转 `S_0`。但 `r=25` 时 state 为 `10`，活跃集
包含 `T`；`r+w=29` 时活跃集包含 `U`。两 witness 的交点为 `3`，而
`3` 不在 `S_0`，所以它没有被 `w` 翻转。这直接否定了“固定偶 witness
即可配对全族”的无条件步骤。

## 5. 当前未决范围

需要证明的无条件命题可写成：在 (1) 的三个 target、`D_S` 独立、真子集
target-free、以及列集两两相交的条件下，不必假设 (UF)/(UF-s)，仍有

\[
\Pr_{r,V}[\exists S:S\subseteq B_r\cap V]\le {1\over4}.
\]

小规模精确枚举（使用完整的真子集极小性条件）未发现超界；但数值观察不替代
上式证明。
