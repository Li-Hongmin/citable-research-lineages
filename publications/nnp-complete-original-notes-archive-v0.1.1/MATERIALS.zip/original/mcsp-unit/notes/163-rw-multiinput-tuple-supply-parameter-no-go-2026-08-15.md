> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW 多输入 history 的 tuple-supply 参数阻断（2026-08-15）

## 结论

把 Ren--Williams Theorem 4.1 中的多输出函数从常值函数改成多输入函数，在其
现有时间参数与单次调用语义下不能自动制造 JK capacity forcing 所需的 tuple-rich family。
即使作最乐观
假设：所有输入都对同一个 AVOID 实例走 failure 分支，并且每个 PCP history 的所有
aligned groups 都互不重复，tuple 总数仍满足

\[
|\mathcal T_h|
\le
2^n\frac{L(t)}{2k\,2^h},
\tag{1}
\]

其中 (n) 是 Theorem 4.1 的输入长度，(t) 是多输出长度，(k) 是同一个
AVOID decoder 的 seed length，(L(t)\le t^a) 是固定 PCP 编码的 proof length。
因而要达到 tree-capacity 的必要条件

\[
|\mathcal T_h|>2^k
\quad\Longrightarrow\quad
n+a\log_2 t>k+\log_2(2k)+h.
\tag{2}
\]

Theorem 4.3 的原阶段参数恰好落在相反的一侧；所以“把 (f_i) 改成多输入”不是当前
路线中只缺失的一行，而是需要改变输入熵或批量调用尺度的重构。

## 计数引理

设 \(X\subseteq\{0,1\}^n\) 是对固定 \(G:\{0,1\}^k\to\{0,1\}^{2k}\) 走
failure/easy-JK 分支的输入集合，并且对每个 \(x\in X\) 只选定 Theorem 3.5 的一条
canonical/actual PCP history \(\Pi_x\)。若把所有可能的 Merlin/PCP histories 都计入，
前因子应改成实际 history-pair 总数；本 note 不作这种未证的扩张。每个选定 history 长度至多

\[
L(t)\le t^a
\tag{3}
\]

（\(a\) 只依赖所选 PCP 构造）。一个深度 \(h\) 的**不重叠 aligned** JK group 占用

\[
2^h\cdot 2k
\tag{4}
\]

个连续 history bits。故每个 history 至多产生

\[
\left\lfloor\frac{L(t)}{2k\,2^h}\right\rfloor
\tag{5}
\]

个不重叠 group；不论不同 history 的 group 是否相同，distinct tuple 数都不超过
occurrence 数。由于 \(|X|\le2^n\)，得到式 (1)。若 JK root seed 的 range 只有
\(2^k\) 个元素，任何要求超过 \(2^k\) 个可同时闭合 tuples 的 forcing 都必须满足
式 (2)。这个上界只用长度和地址计数，不依赖 selector、leaf 的具体内容或 canonical
preimage 选择。

如果把 tuple 定义为允许重叠的滑动窗口，而不是本节的 aligned partition，则使用稍弱的
上界 (2^nL(t)/(2k))；这只去掉式 (1) 的 (2^h) 因子，仍足以给出后面的指数时间
阻断。式 (1) 只对明确选定的不重叠 aligned groups 计数。

## 代入 RW Theorem 4.3

沿用其阶段记号

\[
n_{i+1}=n_i^C,
\qquad
T_i=\max\{2^{cD^i n_0},n_{i+1}\},
\qquad
n=n_0,
\quad k=n_{i+1},
\quad t=T_i,
\tag{6}
\]

其中 (C>D+1)。则

\[
n+a\log T_i
 =O\!\left(D^i n_0+C^{i+1}\log n_0\right)
 =o\!\left(n_0^{C^{i+1}}\right)
 =o(k).
\tag{7}
\]

所以即使 \(X=\{0,1\}^{n_0}\)，且每个 history 的所有 aligned groups 都是新的，
也只有 (2^{o(k)}) 个候选 tuples，远低于 (2^k)。在稳定区 (T_i=k) 时，
上界更直观地是

\[
|\mathcal T_h|
\le 2^{n_0}k^{a-1}/2^{h+1},
\tag{8}
\]

仍为 (2^{o(k)})。反过来，若仅靠输入 history 数量供应 (2^k) 个 tuples，
式 (1)（忽略 (k,2^h) 的多项式因子）要求大致

\[
t\ge 2^{(k-n)/a}
\tag{9}
\]

（忽略 (k,2^h) 的多项式因子）。但 Theorem 4.1 的 Solve 运行时间是 (t^{O(1)})，
这会把 AVOID 求解推到 (2^{\Omega(k)}) 时间，失去 Theorem 4.3 所需的 polynomial
尺度。

## 为什么改写 (f_i) 仍不够

可以形式上定义

\[
f_i(x)=\pi_x(B_i),
\tag{10}
\]

其中 (B_i) 是一个固定 AVOID 输出、\(\pi_x\) 是可计算的 shift 或其他 group action。
这确实满足 Theorem 4.1 的多输入接口，但 RW induction 每一阶段只调用

\[
\operatorname{Solve}_{f_i}(x_0,G_{n_{i+1}})
\tag{11}
\]

一个 (x_0)，因此仍只得到一条 history。若把输入域扩大到
(\nu\le n_i\)（例如把 dummy input 扩成上一阶段宽度），式 (1) 仍说明输入熵和
history-position 熵在 (t=\operatorname{poly}(k)) 时不足以超过 (2^k)。形式上把
(\nu\) 直接扩大到 (\Omega(k)) 可以绕过这个计数，但随后必须处理 (2^\nu) 个独立
调用，或把它们显式批量编码进一个输出；这会改变 RW 的 polynomial/smart-prMA 语义，
不是 Theorem 4.3 的直接推论。把所有 transforms 显式拼进一个输出也会增加 (t)，不再是
原阶段参数。

此外，若 decoder range 对 \(\pi_x\) 不变，则一个 hard outsider 的整个 orbit 仍是
outsider，不能提供 range 内的 child tuples；若 range 不对该 action 不变，则从一个
outsider 推出 range 内 orbit 成员没有一般保证。故 group action 本身也没有补上
range-intersection 缺口。

## 路线边界

本 note 关闭的是一个具体的参数性尝试：

\[
\text{多输入 }f_i
\;+
\text{现有 }t=\operatorname{poly}(k)
\not\Longrightarrow
\text{JK tuple-richness}.
\]

它不证明单个固定 PCP history 内部不存在结构性 richness；若要继续使用 capacity forcing，
剩下的两条可能性是：

1. 从一个固定 history 内部证明非计数的 tuple-richness；或
2. 改变 (t/k) 尺度，接受超多项式 AVOID 时间并寻找新的 magnification 桥；这里的
   “超多项式”是相对于 RW 的 base-(n_0)/E-time 或 polynomial-in-(k) 预算而言。

Theorem 4.1 的逐实例蕴含

\[
\operatorname{Fail}(x,G)\Longrightarrow\text{该 }\Pi_x\text{ 可被 Reconf 重构}
\]

也不提供 \(|X|\) 很大的下界；输出坐标 (i) 只改变最后一个 smart 查询，不产生独立
histories。这里没有得到 circuit lower bound 或 (P\ne NP)。

## 来源边界

Ren--Williams, TR26-118 rev.1, Theorems 3.5, 4.1, 4.3；具体参数与证明位置见
[note136](136-rw-induction-uses-one-fixed-history-no-richness-2026-08-15.md) 与
[note140](140-rw-jk-three-way-barrier-and-surviving-interface-2026-08-15.md)。
式 (1)--(9) 是本项目的 occurrence-counting 推导，不把文献中的单一 history 误读成
independent family。
