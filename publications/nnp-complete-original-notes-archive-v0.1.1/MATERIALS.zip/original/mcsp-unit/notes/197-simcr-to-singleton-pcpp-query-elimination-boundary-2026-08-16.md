> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Sim-CR dPCP 与 singleton-output PCPP 的精确查询边界（2026-08-16）

## 结论地位

这是一个直接的归约定理，用来把“同时坐标鲁棒”目标放回当前 dPCP/PCPP 的已知
参数前沿。它不是 `P != NP` 结果，也不是新的 PCPP 构造；它精确说明 Sim-CR
要求解决的额外问题：把 PCPP 用来检查候选输出词的那一次输入查询，改写成 proof
内部、对同一 global proof 有效的坐标声明机制。

## Sim-CR 假设

固定一个输入 `x` 和唯一目标词 `f_x in {0,1}^ell`。唯一性可以来自一个关系
`R(x,y,w)`：所有满足 `R(x,y,w)` 的三元组在给定 `x` 下都有相同的 `y=f_x`。

设有统一 proof address space `Sigma^N`，以及对每个坐标 `i` 和声明位 `b` 的
随机 verifier `Q_{x,i,b}`。每个 verifier 至多读取 `q` 个 proof symbols，并满足：

1. **同一 proof 的完备性：** 存在 `Pi_x in Sigma^N`，对所有 `i`，
   `Q_{x,i,f_x[i]}(Pi_x)` 以概率至少 `alpha` 接受；
2. **逐坐标错误 soundness：** 对任意候选 proof `Pi`、任意 `i` 和
   `b != f_x[i]`，`Q_{x,i,b}(Pi)` 的接受概率至多 `beta`，其中
   `alpha>beta`。

这里的 soundness 是固定坐标、固定错误声明的量词；只给随机坐标平均错误率或一个
短 valid-word list 不足以使用下面的归约。

## 定理：Sim-CR(q) 给出 singleton PCPP(q+1)

对候选输出词 `y in {0,1}^ell`，构造 PCPP verifier `V_x`：均匀抽取
`i in [ell]`，查询输入 oracle 的一个符号 `y_i`，再运行
`Q_{x,i,y_i}`，并把它的 proof 查询作为其余查询。

则 `V_x` 是 singleton 语言 `{f_x}` 的 proximity `eta`、完备率 `alpha` 的
`(q+1)`-query PCPP 接口；当 `alpha=1` 时是 perfect-complete PCPP。在原始接受率记号下，
其远离输入的接受率至多 `1-eta(1-beta)`（取阈值化后的版本时可把常数写成任意固定的 gap），proof 长度仍为 `N`，
alphabet 不变，查询数为 `q+1`。

更直接地，在接受概率表述下：

* 若 `y=f_x`，使用同一个 `Pi_x`，每次采样的声明都正确，完备性至少为 `alpha`；
* 若 `dist(y,f_x)>=eta`，至少 `eta` 比例的坐标声明错误。对这些坐标，任意
  `Pi` 的接受率至多 `beta`；其余坐标接受率至多 `1`。故

```text
Pr[V_x^Pi accepts y] <= (1-eta)*1 + eta*beta
                         = 1 - eta*(1-beta).
```

若先把 `Q` 的正确分支阈值化为两个固定阈值之间的 gap，
可得到标准 PCPP 记号中的常数 soundness gap。证明只使用同一 `Pi_x` 的完备性和
逐坐标错误 soundness，不要求不同坐标重新选择 proof。

### 证明边界

上式中的 `1-beta` 来自对正确坐标只使用平凡上界 `1`；它不需要把完备性 `alpha`
归一化为 `1`。若 PCPP 定义使用“拒绝概率”或阈值化 verifier，应先固定相同的
normalization，再引用对应的 gap。

## 参数含义

1. **`q=1` 的 Sim-CR 是 2-query PCPP 的充分接口。** 若还能保持近线性 proof、
   常数 alphabet 和常数 proximity/soundness 参数，就得到当前公开构造尚未覆盖的
   singleton-output 2-query PCPP 参数窗口。
2. **`q=2` 的 Sim-CR 只给 3-query PCPP。** 这与 Gur--Minzer--Weissenberg--Zheng
   的近线性 3-query PCPP 基线在查询数上相同；因此“构造一个 2-query dPCP”本身
   不是 Sim-CR 的顶级结果，必须额外证明逐坐标 target binding、同一 proof 和
   RW 地址尺度。
3. **不能反向免费得到 Sim-CR。** 一个普通 PCPP 的 soundness 只对随机坐标
   平均成立，且其 proof 可能依赖整个候选输入词。要从 PCPP 反推出 Sim-CR，至少
   需要一个 one-input-query-separable verifier，并额外要求每个固定坐标的错误声明
   都有同一 soundness gap；这正是现有 list/distributional soundness 未自动给出的
   strengthened quantifier。

## 与 distributional soundness 的关系

若 distributionally sound dPCP 具有 singleton target-output projection，使每个有效
局部视图在坐标 `i` 都解码为同一个 `f_x[i]`，则 singleton bridge 可先给出本文所需的
`Q_{x,i,b}`，再应用本归约。因此 distributional soundness 的正向路线必须同时提供：

* 同一个 honest global proof；
* 对所有坐标的 target projection；
* 对错误坐标声明的固定 gap。

只有随机坐标平均输出、或每个坐标各自存在不同 ideal proof，均不能满足定理假设。

## 文献边界与新问题

Gur--Minzer--Weissenberg--Zheng 的公开定理给出近线性 2-query dPCP 和 3-query PCPP；
其 dPCP-to-PCPP 说明正是额外读取一个候选词坐标。该工作同时指出，近线性、常数
alphabet、小 soundness 的 2-query PCPP 仍未被现有下界排除。因而本文把主攻问题
收窄为：

> 能否构造一个近线性、统一可生成的 Sim-CR dPCP，或证明任何此类构造必然支付
> 超线性 proof、额外 input query，或 RLDC/LDC 型代价？

这比“普通 dPCP 是否能黑箱升级”为固定坐标鲁棒更精确，也直接连接到 PCPP 的已知
查询前沿。

## 证据边界

本文定理是本项目对 Sim-CR 定义的直接推导；它不声称文献已经给出 Sim-CR，也不把
GM--W--Z 的 3-query PCPP 误读为同时坐标鲁棒 dPCP。文献背景：

* [Gur--Minzer--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/html/2512.12960)，
  Theorems 1.6--1.8：2-query dPCP、3/4-query PCPP；
* [Dinur--Harsha--Kindler, TR15-085](https://eccc.weizmann.ac.il/report/2015/085/)，
  distributional soundness 的组合接口；
* [singleton-output bridge](175-singleton-output-distributional-soundness-bridge-2026-08-16.md)，
  从 singleton target projection 到 coordinate soundness 的条件桥接。
