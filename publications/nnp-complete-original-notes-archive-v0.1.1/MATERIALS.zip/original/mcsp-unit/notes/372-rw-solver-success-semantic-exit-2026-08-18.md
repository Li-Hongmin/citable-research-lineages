> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW Solve-success 的 parent--child semantic exit（2026-08-18）

## 本轮判定

本轮只判定一个 Gate-I 问题：在 \(P=NP\) 下把 RW 的 SAT-oracle 机器重编译为
\(r=s=0\) 后，若 \(\operatorname{Solve}_f(x,G)\) 成功输出
\(y\notin\operatorname{Range}(G)\)，这个 \(y\) 是否已经给出父对象
\(f(x)\)（或同一个 canonical history）的地址级信息？

答案是：**不能由 Ren--Williams Theorem 4.1 的现有语义推出。** 成功分支只
证明 child AVOID outsider；父对象与 child outsider 之间没有 source-level 的
绑定关系。故 address-scale width 只把问题从 failure/reconstruction 分支移到
solver-success semantic exit，并没有完成 Closure Theorem 的第二个箭头。

## 精确的源语义

令

\[
 f:\{0,1\}^n\to\{0,1\}^T,
 \qquad G:\{0,1\}^k\to\{0,1\}^{2k}.
\]

Theorem 4.1 的分支信息是：

* Solve_f(x,G) 输出一个长度 \(2k\) 的字符串；若其成功，JK 过程已经给出
  \(y\notin\operatorname{Range}(G)\)；
* 只有在 Solve_f(x,G) **没有**输出 range outsider 时，Reconf(x,i) 才逐位
  恢复同一个 \(f(x)\)，并且其 prMA 查询是 smart。

成功分支没有声明

\[
 y\mapsto f(x),
 \qquad
 y\mapsto f(x)_i,
 \qquad\text{或}\qquad
 \operatorname{CC}(f(x))\le \operatorname{poly}(|y|,\log T).
\tag{372.1}
\]

特别地，\(y\notin\operatorname{Range}(G)\) 是只关于 \(G\) 的 child 断言；它不
是关于父层 \(f(x)\) 的编码、指纹或局部投影断言。

## Semantic-exit lemma

把 Theorem 4.1 的成功分支抽象为唯一结论

\[
 \operatorname{Success}(f,x,G)\Longrightarrow
 y\notin\operatorname{Range}(G).
\tag{372.2}
\]

则不存在从 (372.2) 单独推出 parent evaluator 的逻辑蕴含。证明很直接：固定
一个 \(G\) 和任意 outsider \(y_G\notin\operatorname{Range}(G)\)。在只保留
Theorem 4.1 所陈述的成功语义的模型中，让成功输出为 \(y_G\)，而令父函数在
\(x\) 上分别取两个不同的值 \(f_0(x)\ne f_1(x)\)。同一个 \(y_G\) 同时满足
(372.2)，但不能决定任一父位 \(f_b(x)_i\)。因此从成功语义本身不能得到

\[
 f(x)_i=D(x,G,y,i)
\tag{372.3}
\]

也不能得到 \(f(x)\in P/\mathrm{poly}\)。这不是声称实际实现的
Solve_f 必然与 \(f\) 无关，而是说明：若要从成功分支得到 Closure，必须另外
证明一个没有写在 Theorem 4.1 中的 parent--child binding theorem。

## RW 递推中的具体含义

在 Theorem 4.3 的递推里，

\[
 f_i(x_0)=B_i\,0^{T_i-2n_i},
 \qquad
 B_{i+1}=\operatorname{Solve}_{f_i}(x_0,G_{n_{i+1}})
\]

若调用成功，现有结论只给出

\[
 B_{i+1}\notin\operatorname{Range}(G_{n_{i+1}}).
\tag{372.4}
\]

这说明下一层是一个 AVOID outsider（从而可获得相应的 child hardness），却不
说明 \(B_{i+1}\) 是 \(B_i\) 的地址可访问编码，也不说明通过 \(B_{i+1}\) 可以计算
\(B_i[j]\)。因此即使 \(P=NP\) 下某个 address-scale 过程能生成 \(B_{i+1}\)，它
仍然只是 child object 的生成器；不能代替对父 hard table \(B_i\) 的
\(P/\mathrm{poly}\) evaluator。

这正是 C371 三分中第三项的精确内容：

1. \(k=\operatorname{poly}(\log T)\) 时，forcing 排除 failure，只留下
   solver-success outsider；
2. outsider 语义本身不闭合父对象；
3. 还需要新的 parent--child binding，或另一个能直接把 solver-success 接到
   同一个 \(H_A\) 的 semantic-exit theorem。

## 可接受的新增接口

要使成功分支真正进入 Closure，至少需要证明下列一种 source-specific 结构：

* **地址绑定：** 存在统一 \(D\)，使
  \(\displaystyle f(x)_i=D(x,G,y,i)\)，且 \(D\) 的输入生成与计算达到
  \(\operatorname{poly}(\log T,k,|y|)\)；
* **全词绑定：** 存在地址可访问的 \(\Phi_{x,G}\)，满足
  \(f(x)=\Phi_{x,G}(y)\)，并且 \(\Phi\) 不是把完整 \(f(x)\) 作为 descriptor
  隐藏；
* **分离指纹：** \(y\) 或其短摘要是 \(f(x)\) 的 injective/target-separated
  fingerprint，且该摘要对所有地址共用。

任一接口都必须再核对 same-object、descriptor 信息量、cover/bottom、长度对齐
和 \(P=NP\) 下的地址尺度；它们不是 Theorem 4.1 的自动推论。没有这些接口时，
继续压缩 \(r\) 或共同 prefix 不会改变父对象仍未被恢复这一事实。

## 证据边界

* Ren--Williams Theorem 4.1 的成功/失败分支和 Reconf 逐位恢复语义见
  units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md，
  第 14--17 页（约 867--1008 行）。
* Theorem 4.3 的递推 \(B_{i+1}=\operatorname{Solve}_{f_i}(x_0,G_{n_{i+1}})\) 及
  BFi 分支见同一抽取第 17--19 页。
* C371 只把 \(P=NP\) 下的 round 项与 width/solver 分开；本 note 进一步关闭
  “solver outsider 自动恢复 parent”这一未陈述的语义跳步。

本 note 是 source-specific semantic-exit 结论，不是一般 AVOID 不可能性、RLDC
下界或 \(P\ne NP\) 证明。下一项真正改变路线的定理候选是：对实际 RW/JK
canonical construction 建立上述 parent--child binding，或证明任何此类 binding
都会支付 object-scale descriptor/target-binding 代价。
