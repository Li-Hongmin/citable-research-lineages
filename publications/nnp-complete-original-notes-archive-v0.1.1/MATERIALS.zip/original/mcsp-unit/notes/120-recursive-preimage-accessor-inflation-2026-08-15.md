> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Recursive preimage accessor 必然膨胀（2026-08-15）

## 命题

令

\[
G_q:\{0,1\}^{q}\to\{0,1\}^{2q},
\qquad
R_q=\operatorname{Range}(G_q),
\qquad
q=2^{m-1}.
\]

把一个 \(q\)-bit seed 看成 \(m-1\) 个地址变量的 truth table。固定 finite fan-in-two
basis。对任意 \(a\)，令 \(\mathsf{Seed}_{m,a}\) 是所有由 size-\(\le a\) 的
\((m-1)\)-variable circuits 产生的 \(q\)-bit seed。标准 gate-description counting 给出
某个绝对常数 \(C\) 使

\[
\log_2|\mathsf{Seed}_{m,a}|
\le
C\,a\log_2(a+m+2).
\tag{1}
\]

这里不要求 seed circuit 的描述 canonical；只需一个 size-\(\le a\) circuit 产生该
truth table。

取 \(A\subseteq R_q\)，记 \(M=|A|\)。考虑一个深度 \(j\) 的 JK witness forest，其叶
labels 遍历全部 \(A^{2^j}\)。若所有叶到 root 的 parent blocks 都在 \(R_q\)，则 note 106
的解码 injectivity 给出第 \(j\) 层恰有

\[
M^{2^j}
\tag{2}
\]

个不同的 \(2q\)-bit root blocks。每个 root block 的任意两个不同 preimages 必不同；
因此若这一层为每个 root occurrence 选择一个 preimage，且这些 \(q\)-bit seeds 都有
size-\(\le a_j\) 的 \((m-1)\)-variable accessors，则

\[
\boxed{
2^j\log_2 M
\le
C\,a_j\log_2(a_j+m+2).
}
\tag{3}
\]

证明只用两次计数：式 (2) 给出 \(M^{2^j}\) 个不同 seeds，式 (1) 限制 size-\(\le a_j\)
seeds 的总数。它允许每个 occurrence 使用不同 accessor，不要求 lex-first、uniform selector
或跨 occurrence 共享。

## 逐层 dichotomy

对任意 occurrence-wise preimage process，固定 \(j\) 并从叶向上运行：

* 若在深度 \(j\) 之前出现 non-range parent，得到 outsider；
* 若一直保持在 \(R_q\)，则式 (3) 强制该层至少一个 preimage accessor 满足
  \[
  a_j\log(a_j+m+2)=\Omega(2^j\log M).
  \tag{4}
  \]

因此“每层都保持 range 且 accessor exponent 不增长”不是一个仅仅缺乏构造的愿望；
它被 seed-description entropy 直接限制。该结论比 note 107 的固定 \(a_q\)-local closure
反证更细：它给出每个深度的膨胀量，而不把所有层压成同一个 \(a_q\)。

## 分位数强化：不是一个，而是大多数 root occurrences

把一个 range block 的最小 preimage-accessor 复杂度定义为

\[
\mu_q(z)=\min\{\operatorname{CC}_{m-1}(u):G_q(u)=z\},
\]

若 \(z\notin R_q\)，约定 \(\mu_q(z)=\infty\)。令 \(Z_j\) 是深度 \(j\) 的所有 root
occurrences 所得到的 distinct blocks。在前 \(j\) 层没有 outsider 时，式 (2) 给出

\[
|Z_j|=K:=M^{2^j}.
\]

对任意 accessor 预算 \(a\)，定义低复杂度 seed 集

\[
\mathsf{Low}_a=\{u\in\{0,1\}^q:
\operatorname{CC}_{m-1}(u)\le a\}.
\]

由式 (1)，\(|\mathsf{Low}_a|\le 2^{C a\log_2(a+m+2)}\)。而每个 seed 只映到一个
block，故

\[
\boxed{
\bigl|\{z\in Z_j:\mu_q(z)\le a\}\bigr|
\le 2^{C a\log_2(a+m+2)}.
}
\tag{4a}
\]

这一步不选定 occurrence-wise selector，也不要求 preimage 在不同 occurrences 之间共享：
它只使用不同 root blocks 的 preimage sets 互不相交。于是对任意固定
\(0<\rho<1\) 且 \(\rho K\ge2\)，取 \(a_\rho\) 为满足下式的最大非负整数：

\[
C a_\rho\log_2(a_\rho+m+2)\le \log_2(\rho K),
\tag{4b}
\]

则至少 \((1-\rho)K\) 个 root blocks 满足
\[
\mu_q(z)>a_\rho.
\tag{4c}
\]

特别取 \(\rho=1/2\)，且 \(K\) 足够大时，中位数尺度满足

\[
a_{1/2}\log(a_{1/2}+m+2)
=\Omega\!\left(2^j\log M\right).
\tag{4d}
\]

若 \(a_{1/2}\le q^{O(1)}\)，则
\[
a_{1/2}=\Omega\!\left(\frac{2^j\log M}{\log q}\right);
\]
若该多项式范围假设不成立，结论只会更强。因而在 coverage 代入
\(\log M=2^\ell=\Theta(s\log s)\) 且选择
\(2^j s\log s=\Theta(q)\) 的窗口中，只要整层仍在 range，至少一半 root
occurrences 的最小 preimage accessor 已达到

\[
\boxed{\Omega(q/\log q)}.
\tag{4e}
\]

所以“只存在一个复杂 preimage、其余 branch 仍可由小 selector 处理”的平均化逃逸也被排除；
剩余缺口是如何把这批大 accessor 组织成一个固定 uniform 的 hard language，而不是是否存在
足够多的复杂 occurrences。

更直接地，设 \(t\) 是 root occurrence 的任意索引，并设一个单一 joint selector

\[
A_j(t,\ell)\in\{0,1\},
\qquad \ell\in\{0,1\}^{m-1},
\]

在每个 \(t\) 上输出一个合法 preimage \(u_t\)，即
\(G_q(u_t)=z_t\) 且 \(u_t[\ell]=A_j(t,\ell)\)。把任意固定 \(t\) hardwire
进 \(A_j\)，不会增加 fan-in-two 电路大小，并得到一个计算 \(u_t\) 的
\((m-1)\)-variable accessor。因此 (4c) 立即给出

\[
\boxed{
\text{若 }A_j\text{ 对 }Z_j\text{ 的全部 root occurrences 正确，则 }
|A_j|\ge a_\rho.
}
\tag{4f}
\]

这个推论允许 \(A_j\) 只对一条具体 history 正确，甚至允许每个 occurrence 选择不同的
preimage；它不要求 \(A_j\) 是全局 right-inverse，也不要求 occurrence index 本身可高效生成。
在 coverage 窗口与 (4e) 相同的参数下，任何覆盖整层的 history-specific joint selector
都必须有 \(\Omega(q/\log q)\) 大小。故 canonical selector 的缺口已不能被“换成另一种
全局一致但只服务当前 history 的小 selector”来绕过。

同一计数还排除了随机化的部分覆盖逃逸。设
\(A_j(t,r,\ell)\) 是一个带随机串 \(r\) 的 joint selector，电路大小为 \(a\)；
对某个 root occurrence \(t\)，若存在一个 \(r\) 使
\(\ell\mapsto A_j(t,r,\ell)\) 是合法 preimage，则把 \(t,r\) 都 hardwire 后，
得到一个 size-\(a+O(1)\) 的 seed circuit。于是，记 \(S_A\subseteq Z_j\) 为至少有
一个成功随机串的 root blocks，有

\[
|S_A|
\le
2^{C(a+O(1))\log_2(a+m+2)}.
\tag{4g}
\]

若对均匀随机 root block 的成功概率平均为固定
\(0<\eta<1\)，则 \(|S_A|\ge\eta K\)，从而只要 \(\eta K\ge2\)，式
(4b)--(4e) 仍以 \(\rho=\eta\) 的形式给出同阶下界；\(\eta=1\) 已由 (4f)
覆盖。换言之，随机化可以改变同一 root 的 preimage 选择，却不能让一个小 selector
在超过其低复杂度 seed 容量的 root 集合上成功。

## 低复杂度覆盖的参数代入

令 \(A=A_\ell\) 为所有只依赖 \(\ell\) 个输入变量的 \(m\)-variable truth tables。则

\[
\log_2 M=2^\ell.
\tag{5}
\]

若 decoder coverage 满足
\(\mathcal C_{m,s}\subseteq R_q\)，并用 Lupanov 上界选择
\[
2^\ell=\Theta(s\log s),
\tag{6}
\]
则只要深度 \(j\) 仍保持 range，式 (3) 变为

\[
a_j\log(a_j+m+2)
=\Omega(2^j s\log s).
\tag{7}
\]

特别地，在

\[
s=\frac{q}{\log^{1+\varepsilon}q},
\qquad \varepsilon>0\ \text{固定},
\tag{8}
\]

的窗口中，可取
\[
2^\ell=\Theta\!\left(\frac{q}{\log^\varepsilon q}\right).
\]
取 \(j=\lceil\varepsilon\log_2\log q\rceil-1\)（并确保 \(j\ge0\)），则右侧达到
\(\Theta(q)\)。若 \(a_j\le q^{O(1)}\)，便有

\[
\boxed{a_j=\Omega\!\left(\frac{q}{\log q}\right).}
\tag{9}
\]

所以一个声称在该窗口中保持全 tree closure 的 representation，不能让所有 preimage
accessors 都停留在 \(\operatorname{poly}(m)\)，甚至不能停留在
\(o(q/\log q)\) 的规模；否则在达到该深度前就必须产生 non-range parent。

更细地，若候选 accessor 预算为
\(a_j\le q/\log^{1+\delta}q\)，则式 (7) 右侧至多
\(O(q/\log^\delta q)\)。当 \(0<\delta<\varepsilon\) 时，所有 range stages 至多支持
\[
2^j=O(\log^{\varepsilon-\delta}q)
\]
的数量级；再深一层便触发 accessor inflation 或 outsider。这给出了
\(\varepsilon\)（coverage slack）与 \(\delta\)（inverse slack）之间的直接 tradeoff。

作为直接推论，若存在一个对全部 \(R_q\) 有效的 joint right-inverse
\[
S_q(z,\ell)=u[\ell],
\qquad G_q(u)=z,
\]
且 \(|S_q|=a(q)\)，则把 \(z\) hardwire 到 \(S_q\) 即得到每个 occurrence 的
accessor，故式 (3) 对 \(a_j=a(q)\) 适用。于是同一 near-linear coverage window 中，
任何支持上述 full tree closure 的 global right-inverse 都必须满足
\[
|S_q|=\Omega(q/\log q).
\]
这排除的是小 inverse circuit，而不是 coverage decoder 本身；它也不说明任意 single
range query 都能找到该 inverse。

### 这个下界在原始 \(m\)-尺度上的含义

这里的参数化不是一个记号小事：\(q=2^{m-1}\)，所以

\[
\frac{q}{\log q}=\Theta\!\left(\frac{2^m}{m}\right).
\tag{10}
\]

因此，在上述 coverage/tree-closure 假设下，哪怕 joint selector 的 occurrence index
允许携带长度为 \(\Theta(q)\) 的历史地址，selector 仍不可能有
\(m^{O(1)}\) 大小；其 gate count 至少是对 \(m\) 指数级的
\(\Omega(2^m/m)\)。这只是对“给定 history 的整块 preimage 可随机访问”这一模型的
电路下界。它不能直接转化为 \(P\ne NP\)：selector 的输入本身可能已经长达
\(\Theta(q)\)，而且该结论尚未给出一个固定 \(m\)-uniform 的语言或 reduction。

## 证据边界

- 式 (1) 是有限 fan-in-two gate-list 的普通 description counting。
- 式 (2)--(4) 是 note 106 的 root/tree injectivity 加上 seed-function counting；
  式 (4a)--(4g) 是同一计数对最小 preimage complexity 分布及 history-specific
  joint selector 的分位数强化。
- 式 (5)--(9) 使用 note 107 的 Lupanov junta family；只在 coverage 已假设时适用。
- note 079 已给出单层、canonical range 内 accessor-incompressibility；本 note 的新增点是
  递归层级上的 entropy inflation，并允许 occurrence-wise、非 canonical 的 choices。
- 该结果仍是 accessor complexity lower bound / outsider dichotomy，不是 block 本身的
  circuit lower bound，也不产生 \(P\ne NP\)。真正未闭合的桥仍是：如何把被迫膨胀的
  preimage accessor 转换成固定 uniform 的 hard language，或证明 published JK history
  必须走到该膨胀层。
