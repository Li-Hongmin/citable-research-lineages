> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Systematic-output outsider from a tagged non-output cover（2026-08-18）

## 本轮判定

C400 只覆盖了 product-ECC 的 \(\Upsilon\) 区段，C394 只覆盖了低度代数
oracle 的 line-block；二者都没有自动覆盖 RW systematic witness 前缀中位于
output 之前或之后的原始 history bits。这里把真正需要的接口写成一个严格的
组合定理：若所有**非 output ancestry** 的 JK blocks 都有一个共同的 tagged
range cover，且 easy branch 已被同长度硬度排除，那么 JK 的首个 outsider 必然
附着在 systematic output 上。该结论只关闭位置量词；它仍不把一个 \(2k\)-bit
output block 自动升级为整个 \(B_i\)。

## JK ancestry

令

\[
 G_k:\{0,1\}^{k}\to\{0,1\}^{2k},\qquad
 \Pi\in\{0,1\}^{L},
\]

并按 JK 的标准零填充把 \(\Pi\) 放入长度 \(k2^h\) 的顶层串。对每个
递归 block \(Z_{j,u}\)，记 \(\mathsf A(j,u)\) 为它在顶层的 ancestry：
所有沿未失败左右路径能够从 \(Z_{j,u}\) lift 到的顶层 \(2k\)-blocks 的
坐标集合（C382 的 half-lift 公式）。令 \(I_{\rm out}\) 是 systematic witness
中实际 output bits 的坐标区间。称 \(Z_{j,u}\) **non-output**，如果其所有
top-block ancestry 都与 \(I_{\rm out}\) 不相交；否则称其 **output-attached**。

这个定义特意作用于所有 JK levels，而不只是原始 proof 的 top-level blocks：
JK 在下一层看到的是前一层的 preimage blocks，所以仅覆盖 \(\Pi\) 的直接
区段不足以保证递归过程中没有 auxiliary failure。

## Tagged-cover lemma

设有 \(r\) 个统一可计算的 branch generators

\[
 H^{(a)}:\{0,1\}^{s_a}\to\{0,1\}^{2k},
 \qquad a\in[r],
\]

并令 \(t=\lceil\log_2r\rceil\)。若

\[
 \max_a s_a+t\le k,
\tag{401.1}
\]

则存在一个 \(P\)-uniform generator \(G_k\)，其 range 包含所有

\[
 \bigcup_{a=1}^{r}\operatorname{Range}(H^{(a)}).
\tag{401.2}
\]

把 seed 的前 \(t\) 位解释为 branch tag，余下位送入相应 \(H^{(a)}\)，
多余位固定为零。若每个 \(H^{(a)}\) 的电路大小为 \(s_a^{O(1)}\)，
则 \(|G_k|=k^{O(1)}\)；固定有限 \(r\) 时，tag mux 只增加
\(k^{O(1)}\) 大小。

因此，若每个实际 non-output block 都属于某一个 branch range，则

\[
 Z_{j,u}\notin\operatorname{Range}(G_k)
 \quad\Longrightarrow\quad
 Z_{j,u}\text{ is output-attached}.
\tag{401.3}
\]

这一步只用抽象 range containment，不要求不同 branch 的 preimage 一致。

### RW/Harsha 的可用 branch

在 source-compatible serialization 下，目前已有两个可代入的 branch：

* C394 的低度 line-block generator，seed 长度可取
  \[
  s_{\rm line}=(\Delta+1+2d+2)\log_2|F|+O(\log k)。
  \]
* C400 的低码率 product-ECC generator，
  \[
  s_{\rm ecc}=Q_ka+\lceil\log_2b\rceil+1,
  \qquad Q_k=\lceil2k/b\rceil+1.
  \]

若还存在一个对 systematic witness 中**非 output 原始 bits**有效的统一 branch
\(H_{\rm wit}\)，则三个 branch 用两位 tag 合并，只需满足

\[
 \max\{s_{\rm line},s_{\rm ecc},s_{\rm wit}\}+2\le k.
\tag{401.4}
\]

C400 在 \(R=a/b\le1/3\) 且 \(k\ge6a+O(\log b)\) 时给出
\(s_{\rm ecc}\le k-1\) 的充分窗口；但它不产生 \(H_{\rm wit}\)。
同样，C394 的 line-major cover 不能被无条件地当成 published RW 的
systematic-prefix cover；若为得到 line-major 排列而移动 output prefix，还必须
重新证明 Theorem 3.5 的 source serialization 和 verifier query map。

还要区分**直接区段覆盖**与**递归 range-closure**。C394/C400 证明的是原始
代数/ECC stream 中的内部 intervals；JK 在一个 block 通过后，把它的某个
\(k\)-bit preimage 拼入下一层，所得 lower-level block 未必仍是同一种
line-block 或 product-ECC interval。因此要验证假设 2，必须另外证明非 output
branch 对 JK 的 half-preimage 运算保持封闭，或为每一层实际 preimage 提供同样
的 tagged description。单有原始 stream cover 不足以推出 (401.3)。

## Theorem 401.1（systematic-output hard-exit）

固定一个 RW stage。假设：

1. \(G_k(0^k)=0^{2k}\)，JK 每层返回最左的 non-range block；
2. 对 canonical proof \(\Pi\) 的每一个实际 non-output recursive block，
   \(Z_{j,u}\in\operatorname{Range}(G_k)\)；
3. easy branch 的 self-corrector bound 满足
   \[
   (|G_k|+1)\log(T+2)^{O(1)}<S,
   \tag{401.5}
   \]
   其中 \(\operatorname{CC}(B)>S\)；
4. output-attached block 的 ancestry/path 以及一个与 (I_{\rm out}) 相交的
   top ancestor 可由 address-scale descriptor 确定。

则 JK 必返回一个 success outsider \(y=Z_{j,u}\)，且 \(y\) 的 ancestry
output-attached。对任意指定的、未提前截断的 top ancestor \(a\)，C382 的
half-lift 给出该 top \(2k\)-bit block，电路规模为

\[
 O((h-j)|G_k|+hk).
\tag{401.6}
\]

### 证明

若 JK 没有 success，则它进入 easy branch；由 C381 的 honest
Low-Degree Self-Corrector composition，(401.5) 与
\(\operatorname{CC}(B)>S\) 矛盾。因此必有 first-failure block
\(y\notin\operatorname{Range}(G_k)\)。若 \(y\) 是 non-output，
假设 2 又给出 \(y\in\operatorname{Range}(G_k)\)，矛盾；故 \(y\) 必为
output-attached。给定其未截断 ancestry path，逐层使用
\[
 L_{G,0}(z)=G(\operatorname{left}_k z),\qquad
 L_{G,1}(z)=G(\operatorname{right}_k z)
\]
即可得到 (401.6)，这正是 C382 的 block-addressed lift。证毕。

## 这一步实际关闭了什么

Theorem 401.1 把当前 Gate-I 的位置问题压缩成一个 source obligation：

\[
\boxed{\text{构造 }H_{\rm wit}\text{ 并证明 non-output range 对 JK preimage 递归封闭，或证明其成本。}}
\]

如果该 obligation 成立，C400/C394 负责的 \(\Upsilon\) 与代数 auxiliary 区段
不再能成为 first-failure 的 off-output 逃逸；hardness 迫使 outsider 进入
systematic output ancestry。若该 obligation 不成立，则 C399 给出两种可量化的
出口：某个 non-output block 在 parent family 上有超过 \(2^k\) 个值，产生
non-output outsider；或者所有 non-output supports 都不超过 \(2^k\)，此时
parent information 必须分散到多个 blocks，并支付 C393 的
\(d+2kq\ge\log|\mathcal B|\) 容量代价。两者都不能被误写成 output attachment。

即使 Theorem 401.1 成立，它仍只提供一个 output-attached \(2k\)-bit block。
对完整 \(b\)-bit parent，仍需多个 attached blocks 或一个新的 global relation；
在 \(k,d,q=\operatorname{polylog}b\) 且有足够大 parent family 时，C393/C399
仍给出 \(2kq+d\ge\log|\mathcal B|\)。因此 C401 是 Gate-I 的位置闭合，
不是 whole-parent Closure，也不是 \(P\ne NP\) 证明。

## 证据边界

* C381：easy branch 到 hard parent 的 self-corrector composition；
* C382：正确的 single-half lift 与 ancestry path；
* C394：低度 line-block cover；
* C400：低码率 product-ECC cover；
* C399/C393：non-output family support 与 transcript-capacity 二分；
* Ren--Williams Theorem 3.5：systematic witness/output 与 auxiliary proof 的
  量词边界。

本 note 不声称 published RW 已有 \(H_{\rm wit}\)，不把 line-major 重排当成原文
既定格式，也不声称已完成 \(P\ne NP\)。
