> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 置换轨道稀疏指数的紧性与 C-J-W 量词修正（2026-08-15）

## 结论

沿用 [note 099](099-orbit-mcsp-sparsity-hardness-magnification-interface-2026-08-15.md)
的
\[
n=2^m,\qquad h_m(r)=r_1,\qquad
t_q(m)=\max\!\left\{1,\left\lfloor\frac{n^q}{m+1}\right\rfloor\right\}
\]
（固定有理数 \(q\in(0,1)\)）。本 note 得到三点：

1. Chen--Jin--Williams（C-J-W）稀疏 hardness magnification 的实参数族并不要求
   \(\beta\mapsto L_\beta\) 统一可计算；只需一个趋于 \(0\) 的有理参数序列和共同的
   \(n^{1+\varepsilon}\) 下界。
2. 固定 \(q\) 时，轨道的稀疏指数是紧的：
   \[
   \left|\mathsf{Orb}_{m,t_q}(h)\right|=2^{\Theta(n^q)}.
   \]
3. note 101 的 fiber-bijection 加 colored variable-isomorphism 在 \(t_q\) 尺度不能把候选压到
   多项式个；其中包含一个与 MCSP 精确对应的 shear 子轨道，但 full orbit 仍受 stabilizer
   cancellation 阻碍。

这些结果缩短了真正的 hardness 目标，但不提供一般 circuit lower bound 或 \(P\ne NP\)。

## C-J-W 的实参数量词不需要统一性

C-J-W Theorem 1.1 的假设是：存在同一个 \(\varepsilon>0\) 和一个 family
\(\{K_\beta:\beta\in(0,1)\}\)，使每个 \(K_\beta\in\mathsf{NP}\)、
\(K_\beta\) 是 \(2^{n^\beta}\)-sparse，并且
\[
K_\beta\notin\mathsf{SIZE}[n^{1+\varepsilon}]
\qquad\text{对所有 }\beta\in(0,1).
\tag{1}
\]
定理逐个要求 \(K_\beta\in\mathsf{NP}\)，没有要求由 \(\beta\) 统一计算同一台验证器。

因此，设 \(Q=\{q_j:j\ge1\}\subseteq\mathbb Q\cap(0,1)\) 满足
\(q_j\to0\)，并假设
\[
\exists\varepsilon>0\ \forall q_j\in Q:\quad
L_{q_j}\notin\mathsf{SIZE}[n^{1+\varepsilon}].
\tag{2}
\]
则可以为每个实 \(\beta\in(0,1)\) 构造 C-J-W 所需的 \(K_\beta\)。选取
\(q_j<\beta\)。由 note 099 的语法计数，存在常数 \(C_j\) 使充分大长度上
\[
\left|L_{q_j}\cap\{0,1\}^n\right|
\le 2^{C_j n^{q_j}}.
\]
取 \(N_\beta\) 使 \(C_j n^{q_j}\le n^\beta\) 对 \(n\ge N_\beta\) 成立，并令
\(K_\beta\) 等于 \(L_{q_j}\) 在长度至少 \(N_\beta\) 的截面、在较短长度上为空。
这是有限长度修改，故 \(K_\beta\in\mathsf{NP}\)，且仍满足 (1) 的 circuit lower bound：
若 \(K_\beta\) 有 \(n^{1+\varepsilon}\) 大小的电路族，替换有限多个短长度电路即可得到
\(L_{q_j}\) 的同样电路族，矛盾。于是 \(K_\beta\) 是 \(2^{n^\beta}\)-sparse。

所以把 note 099 中“必须先把有理参数统一升级到所有实 \(\beta\)”列为硬障碍是不准确的。
真正未解决的充分目标是
\[
\boxed{
\exists\varepsilon>0\ \exists Q\subseteq\mathbb Q\cap(0,1),\
\inf Q=0,\ \forall q\in Q:
L_q\notin\mathsf{SIZE}[n^{1+\varepsilon}].
}
\tag{3}
\]
C-J-W 还要求其余的复杂度类闭包假设；对这里的 \(\mathsf{NP}\)，该条件成立。

## 固定 \(q\) 时稀疏指数是紧的

note 099 的上界给出
\[
\left|\mathsf{Orb}_{m,t_q}(h)\right|
\le
2^{O((t_q+m)\log(m+t_q+2))}
=2^{O(n^q)}.
\tag{4}
\]
下面给出匹配的下界。固定一个能以常数个门实现 XOR 的有限完备 fan-in-2 basis；
Lupanov 所用的固定完备 basis 到该 basis 的常数模拟并入下述 \(C_q\) 和 \(O(1)\) 项。
取
\[
d=\lfloor qm\rfloor-C_q,
\]
其中常数 \(C_q\) 足够大。由 Lupanov 的 truth-table synthesis bound，对充分大的 \(m\)，
每个 \(d\)-变量函数 \(g\) 都满足
\[
\operatorname{CC}(g)
\le(1+o(1))\frac{2^d}{d}
\le t_q(m)-O(1).
\tag{5}
\]
把 \(g\) 嵌入 \(x\) 的固定 \(d\) 个坐标，并写
\(r=(b,x,w)\)，定义自逆 shear
\[
B_g(b,x,w)=(b\oplus g(x),x,w).
\tag{6}
\]
它是一个置换，且
\[
\left|B_g\right|\le \operatorname{CC}(g)+O(1)\le t_q(m).
\]
因此
\[
y_g=h_m\circ B_g^{-1},
\qquad
y_g(b,x,w)=b\oplus g(x)
\tag{7}
\]
属于 \(\mathsf{Orb}_{m,t_q}(h)\)。不同 \(g\) 给出不同 \(y_g\)，而
\[
2^d=\Theta_q(n^q),
\qquad
\#\{g:\{0,1\}^d\to\{0,1\}\}=2^{2^d}=2^{\Theta(n^q)}.
\tag{8}
\]
结合 (4)，得到
\[
\boxed{
\left|\mathsf{Orb}_{m,t_q}(h)\right|=2^{\Theta(n^q)}.
}
\tag{9}
\]

这说明 C-J-W 中的指数 \(q\to0\) 不是记号装饰：固定 \(q\) 的轨道不能被当作任何
\(\beta<q\) 的 \(2^{n^\beta}\)-sparse family。

## Shear 子轨道与 colored-GI 的结构性障碍

对 \(M=m-1\)，定义
\[
\mathsf{ShOrb}_{m,s}
=
\left\{
y_f(b,x)=b\oplus f(x):
\operatorname{CC}(f)\le s
\right\}.
\tag{10}
\]
因为 \(B_f(b,x)=(b\oplus f(x),x)\) 自逆，且 XOR 只增加常数门数，
\[
\mathsf{ShOrb}_{m,s}\subseteq
\mathsf{Orb}_{m,s+O(1)}(h).
\tag{11}
\]
并且 shear 子轨道的 membership 精确等价于一个 MCSP slice：
\[
y\in\mathsf{ShOrb}_{m,s}
\Longleftrightarrow
\left[
\begin{array}{l}
y(1,x)=\neg y(0,x)\quad\forall x,\\
\operatorname{CC}\bigl(y(0,\cdot)\bigr)\le s.
\end{array}
\right].
\tag{12}
\]
因此从长度 \(N=2^M\) 的 MCSP 实例 \((\operatorname{TT}(f),s)\) 到
\[
\operatorname{TT}(y_f)=
\bigl(\operatorname{TT}(f),\neg\operatorname{TT}(f)\bigr)
\tag{13}
\]
是线性时间、长度只增至 \(2N\) 的精确归约。但 (12) 只处理 restricted shear
suborbit，不能直接升级为 full orbit 的 hardness。

更具体地，固定 \(q\) 并取上面的 \(d\)。所有 \(d\)-变量 \(g\) 都能产生 (7)，所以
shear family 中已有 \(2^{\Theta(n^q)}\) 个 yes tables；然而“是否属于全部 shear 形状”
只需逐项检查
\[
y(1,x,w)=\neg y(0,x,w)
\quad\text{且不依赖被忽略的 }w,
\tag{14}
\]
是线性时间可判定的。这排除了“NP 加上稀疏熵/语法计数本身就带来成员关系困难”的论证。

在 note 101 的分解中，这整个 family 统一取
\[
k=1,\qquad J=\{b\},\qquad
g_{B_f}(b,x)=b\oplus f(x).
\]
对每个固定 \(x\)，\(b\mapsto b\oplus f(x)\) 都是双射，故 fiber-bijection 检查完全不剪枝。
colored Luks 只能把 \(x\) 的变量重命名取商；每个 \(S_M\)-等价类大小至多 \(M!\)，而
\[
\frac{2^{2^d}}{M!}
=2^{\,2^d-O(m\log m)}
=2^{\Theta(n^q)}.
\tag{15}
\]
所以 note 101 的局部 GI 机制在 \(t_q\) 尺度上必然还留下指数多个不同候选。

## Full orbit 的 stabilizer cancellation

令
\[
H_m=\{S:h_m\circ S^{-1}=h_m\}
\]
是 \(h_m\) 的 stabilizer。对 shear 元 \(y_f\)，所有 row permutations 的实现恰为
\[
\{A:h_m\circ A^{-1}=y_f\}
=B_f\circ H_m.
\tag{16}
\]
故 full orbit 的最小 witness cost 是
\[
\kappa(y_f)
=\min_{S\in H_m}\operatorname{CC}(B_f\circ S),
\tag{17}
\]
而不是 \(\operatorname{CC}(f)+O(1)\)。这里
\[
S(b,x)=(b,\sigma_b(x)),
\qquad
\sigma_0,\sigma_1\in
\operatorname{Sym}(\{0,1\}^{M}),
\]
所以 stabilizer 极大，可能通过 composition cancellation 给 \(y_f\) 一个更小的非-shear
witness。当前没有证明
\[
\operatorname{CC}(f)\le\operatorname{poly}(\kappa(y_f)).
\tag{18}
\]
因此 (13) 是 restricted suborbit 的 MCSP 归约，而不是 full \(\mathsf{Orb}\) 的归约。

## 非均匀 sparsity floor

note 099 的 support-junta 计数还给出：若
\[
D=t(2^t+1),
\]
则长度 \(n=2^m\) 的 yes-slice 大小 \(M_n\) 满足
\[
\log_2 M_n=O(D\log m+2^D).
\tag{19}
\]
把该截面中的每个字符串硬编码成 equality test 并 OR，得到
\[
\operatorname{SIZE}(L_t\upharpoonright\{0,1\}^n)
\le
n\,2^{O(D\log m+2^D)}.
\tag{20}
\]
若
\[
D\log m+2^D=o(m),
\tag{21}
\]
则 \(L_t\) 具有 \(n^{1+o(1)}\) 的非均匀上界，不可能满足任何固定
\(n^{1+\varepsilon}\) lower bound。特别地，\(D\le\log_2m-\omega(1)\) 时 (21) 成立；
而这一区间已经包含在 note 101 的 \(P\) 闭合区间内。

## 路线裁决

本 note 把 note 099 的充分目标精确改为 (3)，并证明固定 \(q\) 的稀疏指数不能再下降。
因此下一条真正的硬问题是：
\[
\text{是否存在共同 }\varepsilon>0\text{，使 }L_q
\notin\mathsf{SIZE}[n^{1+\varepsilon}]
\text{ 对一列 }q\downarrow0\text{ 成立？}
\]
colored-GI 的局部扩展已被 (15) 排除；纯计数、shear 子族和小 \(D\) 的硬编码也已关闭。
full orbit 的剩余核心是 stabilizer-coset circuit minimization，仍是 unknown。

## 文献与证据边界

- Lijie Chen, Ce Jin, and R. Ryan Williams, *Hardness Magnification for all Sparse NP Languages*,
  FOCS 2019, Theorem 1.1；本地全文与记录见
  ResearchLibrary/lib/williams2019hardness/，DOI
  [10.1109/FOCS.2019.00077](https://doi.org/10.1109/FOCS.2019.00077)。
- Stasys Jukna, *Boolean Function Complexity: Advances and Frontiers*, Theorem 1.15；
  本地全文见 ResearchLibrary/lib/jukna2012boolean/。
- 以上只使用 C-J-W 的逐个 family 量词和 Lupanov 的 synthesis upper bound；没有把
  MCSP/GI 近邻结果当作 full row-space orbit lower bound。

原文核验日期：2026-08-15。
