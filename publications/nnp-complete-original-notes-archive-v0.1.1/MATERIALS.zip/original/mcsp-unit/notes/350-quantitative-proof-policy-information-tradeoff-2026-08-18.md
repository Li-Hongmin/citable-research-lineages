> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Quantitative proof--policy information tradeoff for common-proof robustness

## Theorem

Fix a finite proof alphabet \(\Sigma\) of size \(A\ge2\), constants
\(0<\rho<1\) and \(\Delta>0\), and a common proof map
\[
  \Pi:\{0,1\}^{K}\longrightarrow \Sigma^{P}.
\]
For each target \(m\) and coordinate \(i\), let
\(\tau_{m,i}\) be a selected nonadaptive policy.  Assume that every selected
policy is supportwise robust:
\[
\Pr[V_{i,m_i}^{\tau_{m,i}}(\Pi(m))=1]\ge\alpha,
\]
and, for every \(z\) with \(d_H(z,\Pi(m))\le\rho P\),
\[
\Pr[V_{i,1-m_i}^{\tau_{m,i}}(z)=1]\le\beta,
\qquad \alpha-\beta\ge\Delta.
\tag{350.1}
\]
After constant gap amplification, let \(Q=1+O_A(q\Delta^{-2})\) be the
inline nonadaptive query count and let \(\sigma_0\in(0,1)\) be the resulting relaxed
success parameter.  For the GGS length conclusion below, additionally assume
supportwise perfect completeness, i.e. \(\alpha=1\), and use the inline compiler
from Paper 05 Theorem 4.3.  Under merely \(\alpha>\beta\),
the same construction gives only an imperfect-complete semantic RLDC unless a separate
completeness-preserving lower-bound theorem is supplied.  Let \(M\) be uniform on
\(\{0,1\}^{K}\), and let \(S\) be
the selected-policy vector
\[
  S=(\tau_{M,1},\ldots,\tau_{M,K});
\]
randomized policy selection is allowed provided (350.1) holds for every
\((m,s)\) of positive conditional probability.

For \(d\ge2\), define the GGS lower-bound function
\[
 \widehat A:=A+2,\qquad
 \mathcal L_{Q,\widehat A,\sigma_0}(d):=
 \left(
 \frac{\sigma_0^2d}
 {38Q^4\log_2^2(\widehat A)\log_2^2(d+2)}
 \right)^{1+1/\lceil Q/\sigma_0\rceil},
\tag{350.2}
\]
and put
\[
 d^\star(P):=
 \max\Bigl(\{1\}\cup
 \{2\le d\le K:d+P\ge\mathcal L_{Q,\widehat A,\sigma_0}(d)\}\Bigr)
\qquad(K\ge1).
\tag{350.3}
\]
For all sufficiently large \(P\) for which the GGS radius condition
\(\delta_0>P^{-\sigma_0/(2Q)}\) holds at a fixed tagged radius
\(\delta_0=\delta_0(\rho,A)>0\) supplied by the Singleton/tagging calculation,
\[
 I(M;S)\ \ge\
 K-\log_2\!\left(\sum_{j=0}^{d^\star(P)}\binom Kj\right).
\tag{350.4}
\]
The statement is also valid for a standard-Borel policy space, with \(S\) interpreted
through regular conditional laws.

In particular, for fixed \(A,Q,\rho,\Delta\), if
\[
 P\le K(\log(K+2))^c
\tag{350.5}
\]
on an infinite sequence, then with
\(\theta=1+1/\lceil Q/\sigma_0\rceil>1\),
\[
 d^\star(P)\le
 K^{1/\theta}(\log(K+2))^{O_{A,Q,\rho,\Delta,c}(1)}
 =o(K),
\tag{350.6}
\]
and therefore
\[
 I(M;S)=K-o(K).
\tag{350.7}
\]

## Proof

For a policy value \(s\), let
\[
 F_s:=\{m:\Pr[M=m\mid S=s]>0\},
\]
and write \(d_s=\operatorname{VCdim}(F_s)\).  Suppose \(F_s\) shatters a
coordinate set \(J\) of size \(d_s\).  Choose, for each \(u\in\{0,1\}^{J}\),
a representative \(m^{u}\in F_s\) with \(m^{u}|_J=u\), and define
\[
 C_s(u):=\Pi(m^{u})\in\Sigma^P.
\]
If \(u,u'\) differ at \(i\in J\) and
\(d_H(C_s(u),C_s(u'))\le\rho P\), the same selected policy
\(\tau_{s,i}\) sees \(C_s(u')\) as a \(\rho P\)-near proof for \(m^u\).
Completeness for \(m^u\) and wrong-claim soundness for \(m^u\) on that proof
would give acceptance of the same branch both at least \(\alpha\) and at most
\(\beta\), a contradiction.  Hence \(C_s\) is injective and has relative
distance greater than \(\rho\).

On a requested \(i\in J\), inline the bit \(u_i\), query the corresponding common
branch of \(\tau_{s,i}\), and output the inline bit on acceptance and \(\bot\) otherwise.
Under \(\alpha=1\), this is a perfect-complete nonadaptive RLDC of length \(d_s+P\),
alphabet \(\widehat A\), and constant relaxed success at least \(\sigma_0\).  The
Singleton/tagging calculation gives a positive radius \(\delta_0<\rho\); the proof
suffix remains within the \(\rho P\)-ball, while a flipped inline bit invokes the wrong
branch.  Thus the GGS theorem applies to the inline code.

The GGS theorem gives \(d_s+P\ge\mathcal L_{Q,\widehat A,\sigma_0}(d_s)\) whenever
\(d_s\ge2\) and the displayed radius condition holds.  This invocation uses the
supportwise perfect-completeness assumption \(\alpha=1\); without it, the cited GGS
theorem does not apply to the imperfect-complete semantic decoder.  By (350.3), every conditional fiber
therefore has \(d_s\le d^\star(P)\).  Since conditional entropy is bounded by the
logarithm of support size, Sauer--Shelah gives
\[
 H(M\mid S=s)\le
 \log_2|F_s|
 \le \log_2\!\left(\sum_{j=0}^{d^\star(P)}\binom Kj\right).
\]
Average over \(s\) and use \(I(M;S)=K-H(M\mid S)\) to obtain (350.4).

For (350.6), choose
\[
 d_0=C\,K^{1/\theta}(\log(K+2))^{(c+2\theta+2)/\theta}
\]
with \(C=C(A,Q,\sigma_0,c)\) sufficiently large.  Substitution in (350.2)
gives \(\mathcal L_{Q,A,\sigma_0}(d_0)>K(\log(K+2))^c\) for all large \(K\).
Consequently \(d^\star(P)<d_0\) under (350.5).  Since \(d_0=o(K)\),
\[
 \log_2\sum_{j\le d_0}\binom Kj
 \le d_0\log_2(eK/d_0)=o(K),
\]
which proves (350.7). \(\square\)

## Boundary

The theorem is a quantitative strengthening of the selected-policy VC lift: it
does not merely say that sublinear policy information is impossible at near-linear
proof length; it gives the exact entropy deficit allowed by a prescribed \(P\).
It uses supportwise robustness, a common proof/address space, fixed finite \(A\),
and the nonadaptive GGS lower bound.  Ordinary average/list soundness does not
imply the fiber hypothesis.  Adaptive branches can be substituted through the
source-audited variable-query transfer in note 255, but then the additional
\(Q^3=o(\log P)\) window must be stated explicitly.

The external coding input is Theorem 1 of Goldberg--Gur--Saraogi, whose stated
definition requires perfect completeness.  The present result is the
Sauer--Shelah/fiber composition with that theorem, not a claim that GGS state a
policy-information theorem.  Without \(\alpha=1\), the fiber/semantic-RLDC step remains
valid but the displayed GGS length consequence requires a separate
completeness-preserving lower bound.

## Sources

* [Selected-policy VC lift](271-selected-policy-vc-lift-to-rldc-2026-08-17.md).
* [Standard-Borel selected-policy closure](281-standard-borel-selected-policy-information-closure-2026-08-17.md).
* [GGS, Theorem 1](https://eccc.weizmann.ac.il/report/2025/192/download).
