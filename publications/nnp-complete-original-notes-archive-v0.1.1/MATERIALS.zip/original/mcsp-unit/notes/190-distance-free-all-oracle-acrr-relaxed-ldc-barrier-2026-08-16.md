> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Robust 半径—距离耦合：ACRR barrier 的严格边界（2026-08-16）

## 结论地位

本 note 是对 note 188 的量词与尺度校正。它保留一个正确的局部引理，但否定“完全
去掉常数距离/常数半径后仍自动得到超线性 LDC 下界”的过强推断。

正确分界是：

* robust-near-oracle 半径 `delta_0` 会直接下界 code distance；
* 当 `delta_0=Omega(1)` 时，阈值化 verifier 落入 Dall’Agnol--Gur--Lachish 的常数
  半径 relaxed-LDC barrier；
* 当 `delta_0=o(1)` 时，现有 DGL 定理不能直接给出同一超线性结论，且有恒等编码反例。

因此，ACRR 正向路线不能把“很小的鲁棒半径”静默当作常数半径；半径本身是必须记账的
资源。

## 半径—距离耦合引理

令 `Sigma` 为固定有限 alphabet，

```text
C : {0,1}^k -> Sigma^N
```

并对每个 `i in [k]`、`b in {0,1}` 给出统一的至多 `q` 次查询 verifier `V_{i,b}`。
记 `p_{i,b}(z)` 为其接受概率。假设：

1. **完美 codeword 完备性：** 对任意 `m,i`，
   `p_{i,m_i}(C(m))=1`；
2. **robust-near-oracle 错误 soundness：** 存在 `delta_0>0` 和 `beta<1`，对任意
   `m,i` 及满足 `dist(z,C(m))<=delta_0` 的 `z`，有
   `p_{i,1-m_i}(z)<=beta`。

则 `C` 的最小相对距离满足

```text
delta_C > delta_0.
```

### 证明

若存在 `m,m'` 在某个坐标 `i` 上不同，且
`dist(C(m),C(m'))<=delta_0`，令 `b=m_i`。对 `m'` 而言，`b=1-m'_i` 是错误声明；
由近邻 soundness，

```text
p_{i,b}(C(m')) <= beta.
```

但由 `m'` 的完备性，

```text
p_{i,m'_i}(C(m')) = 1,
```

且 `m'_i=b`，矛盾。不同消息必在某个坐标上不同，故所有 codeword 对的距离都超过
`delta_0`。

## 阈值化与正确的 DGL 接口

取 `theta=(1+beta)/2`，分别独立运行 `V_{i,0}`、`V_{i,1}` 多次并比较经验接受频率。
若 `z` 满足 `dist(z,C(m))<=delta`，其中

```text
0 < delta < min{delta_0, delta_C/2},
```

则错误分支不会越过阈值；decoder 只能输出 `m_i` 或 `bottom`。在 codeword 上，正确
分支完备而错误分支受 soundness 控制，所以得到一个查询数
`q'=O(q(1-beta)^(-2))` 的 relaxed local decoder。

这给出一个严格的条件性推论：如果 `delta_0=Omega(1)`、alphabet 和 `q` 都为常数，
则 `delta_C=Omega(1)`，并可调用 Dall’Agnol--Gur--Lachish 的 Theorem 7.7 / Corollary
7.9，得到

```text
N >= k^(1 + 1/O(q'^2 log^2(q'+2))).
```

这正是 note 188 的 barrier；无需把“constant distance”另列为独立假设，因为它由
常数 robust 半径推出。但不能把 `delta_0` 换成任意随 `N` 消失的半径后仍保留该结论。

## 小半径反例：恒等编码

取二元恒等编码

```text
C(m)=m,   N=k,
```

以及单查询 verifier

```text
V_{i,b}(z)=1  iff  z_i=b.
```

它在 codeword 上完美完备。若取 `delta_0<1/N`，任何满足
`dist(z,C(m))<=delta_0` 的 oracle 都只能是 `z=C(m)` 本身，因此错误声明的接受概率为
0，满足 robust-near-oracle soundness，查询数为 1，长度仅 `N=k`。

所以不能从“存在某个正但可能极小的 robust 半径”推出 DGL 的超线性长度下界。DGL 的
应用需要其常数半径/robustness regime；把 `delta_C=1/N` 代入常数半径结论会直接与该
反例冲突。

## 从 DGL 原证明提取的半径敏感窗口

本节的 proof draft 已收束为独立模块
[parameterized-dgl-small-radius-sample-theorem](../../../rw-jk-succinct-reconstruction/statements/parameterized-dgl-small-radius-sample-theorem.md)。
下文保留抽取过程与历史边界；正式引用时以该模块的定理、假设和证据边界为准。

虽然 Dall’Agnol--Gur--Lachish 的正式 Theorem 6.1 以
`max{rho_0,rho_1}=Omega(1)` 陈述，但其证明允许把半径依赖显式保留下来。令

```text
gamma = 48 * |Sigma|^q * ln|Sigma|,
K_*   = gamma * q^2 * N^(1-1/q),
p     = gamma * N^(-1/(2q^2)).
```

Claim 6.2 给出 `|K_1| <= K_*`，而其第二部分至少需要
`K_* < rho N/2`。更关键的是 Claim 6.5 的 `j=1` Chernoff 分支，对每个 kernel
assignment 给出指数项 `exp(-rho N p/(48q))`；为了对
`|Sigma|^{|K_1|}` 个 assignment 做 union bound，当前证明还需要

```text
rho * N * p / (48q) >= ln|Sigma| * K_* + ln(10q).
```

因此，一个比单纯 kernel 条件更严格、且与现有证明逐项相容的候选窗口是

```text
rho >= max {
  2 * gamma * q^2 * N^(-1/q),
  48q * (ln|Sigma| * K_* + ln(10q))
      / (gamma * N^(1-1/(2q^2)))
}.
```

展开第二项，其主导部分为
`48 q^3 ln|Sigma| * N^(-1/q+1/(2q^2))`。所以在固定 `q`、固定有限 alphabet
且保留 DGL 其余增长条件时，当前证明真正提示的尺度约为
`rho = N^(-1/q+1/(2q^2))`，而不是先前误写的 `N^(-1/q)`。后者只保证 kernel 不过大，
不足以完成 `j=1` 的 assignment union bound。

这仍不是 DGL 论文已单独陈述的定理，而是从其 Claim 6.2、Eq. (6.8)、Eq. (6.10)
和 Claim 6.5 的参数逐行抽取的待复核充分条件；还需检查小 `N`、整数 cap、
error/randomness reduction 以及 sample-based 算法的原始增长假设。恒等编码反例
`rho_0<1/N` 仍位于该候选窗口以下。

### rho 依赖的逐项审计

在 DGL 的现有证明中，`rho` 的依赖可按下表归并：

| 证明位置 | 需要的条件 | 当前窗口是否覆盖 |
|---|---|---|
| Claim 6.2 | `K_* < rho N/2` | 第一项 `2 gamma q^2 N^(-1/q)` |
| Claim 6.4 的 `D_0` 与 capped `D_1` | `|K_0|,|K_1|<rho N/2`，以及 `alpha=12 ln|Sigma|/(rho sigma)` | 第一项；`alpha` 的代入使被删集合体积仍至多 `rho N` |
| Claim 6.5 的 robust-input 量词 | `|K_1|/N<rho` | 第一项 |
| Claim 6.5 的 `j=1` Chernoff + assignment union bound | `rho Np/(48q)>=ln|Sigma| K_*+ln(10q)` | 第二项 |
| `j>1`、sampling cap、error/randomness reduction | 原 DGL 的 `q,|Sigma|,N` 增长条件 | 不引入新的 rho 项 |

因此，若把 DGL 的证明完整重写为允许 `rho=rho(N)` 的版本，并保留其余假设，
上面的两项不等式是一个足以复用同一 sample-based 算法和样本指数的参数窗口；它不是
仅凭 Claim 6.2 就能得到的结论。整数化、`alpha` 的取整和 `p<=1` 已在
[参数化 DGL 小半径 sample theorem](../../../rw-jk-succinct-reconstruction/statements/parameterized-dgl-small-radius-sample-theorem.md)
中单独写出；其中新增的 relaxed 两分支扩展仍明确保留 DGL 的合法增长域与 `bottom`
量词，不把它冒称为 DGL 原文的小半径定理。

若该参数化定理最终成立，则一个具有 `delta_0 >= rho_DGL(N,q,Sigma)` 的 ACRR，
在取 relaxed decoding radius `delta_0/2` 时仍可进入同一 RLDC sample lower bound；因为
完备性与错误分支的 robust-near-oracle 量词已经强制 `delta_C>delta_0`，从而
`delta_0/2<delta_C/2`。这会把 note 188 的常数半径 barrier 推进到显式的
半径—长度 tradeoff；目前只登记为待证明的升级方向。

### 参数化 DGL 扩展候选命题

把上面的审计压缩成一个可独立证明的目标：固定有限 `Sigma`、查询参数 `q`，并保留
DGL 对 `q`、`N`、`|Sigma|` 的原始增长假设。令 `M` 是误差率 `1/3` 的一侧
`rho`-robust `ell`-local algorithm；经过 DGL 的 error/randomness reduction 后取
`sigma=1/(8q)`、`gamma=48|Sigma|^q ln|Sigma|`、`p=gamma N^(-1/(2q^2))`，并令
`K_*=gamma q^2 N^(1-1/q)`。若窗口与 `0<rho<=1` 有交，并且

```text
K_* < rho N/2,
rho Np/(48q) >= ln|Sigma| K_* + ln(10q),
```

则目标是证明：DGL 的同一 sample-based construction 在所有原承诺输入上保持正确，
样本复杂度仍为 `O(gamma N^(1-1/(2q^2)))`，并保持相同的 robustness radius。

证明骨架只需重写原文的四个 rho 触点：第一条不等式给 Claim 6.2 的 kernel 上界和
Claim 6.5 的 robust-input 量词；`alpha=12 ln|Sigma|/(rho sigma)` 给 Claim 6.4
的 capped-daisy 体积估计；第二条不等式给 Claim 6.5 的 `j=1` assignment union
bound。其余 `j>1` Chernoff、sampling cap 与 error/randomness reduction 沿用原证明。
因此这不是新的编码假设，而是一个有明确参数窗口的 DGL 证明重参数化；正式晋级仍需
把 `alpha`、`p<=1`、小 `N` 和 relaxed-LDC 的距离/半径取整写成完整定理与证明。

### 四分支证明链（实参数版本）

在暂时忽略 `ceil`/`floor` 的实参数记号下，剩余证明可压缩如下。令 `K_*`、`p`、
`alpha` 如上，并假设两条窗口不等式成立。

1. **kernel：** 原 Claim 6.2 的逐层估计不含 `rho`，给出
   `|K_j|<=gamma q^2 N^(1-max{1,j}/q)`；第一条窗口使
   `|K_0|,|K_1|<rho N/2`。
2. **非 robust 分支：** 原 Claim 6.4 只用 `K_0,K_1<rho N/2` 和
   `alpha=12 ln|Sigma|/(rho sigma)`。因此 `D_0` 及被 cap 的 `D_1` 覆盖体积都小于
   `rho N`，volume lemma 仍给出各自至多 `2sigma` 的权重损失；其余 Chernoff 估计不变。
3. **robust 分支、`j>1`：** 原 Claim 6.5 的 `beta_j`、petal sampling 和
   `|Sigma|^{|K_j|}` union bound 均不再使用 `rho`，故原估计直接复用。
4. **robust 分支、`j=1`：** 对每个 assignment，原 Chernoff 项为
   `exp(-rho Np/(48q))`。第二条窗口把它压到
   `|Sigma|^{-K_*}/(10q)`, 而 `|K_1|<=K_*`，故对所有 kernel assignments 和
   `j=1` 一次 union bound 后仍至多 `1/10`。

加上 sampling step 的原错误概率，得到与 DGL 相同的常数正确率和样本复杂度。这个
四分支链条是当前参数化定理的核心；正式版本只需把实参数不等式替换成带常数 slack
的整数版本，并显式检查 `p<=1`、原论文的 `q=o(sqrt(log N))` 等域条件。

一个安全的整数化方式是取
`K^+=ceil(K_*)`、`alpha=ceil(12 ln|Sigma|/(rho sigma))`，并在 `|Sigma|>=2` 时把
`48` 换成 `56`：因为 `alpha <= 14 ln|Sigma|/(rho sigma)`，故 `j=1` 的 Chernoff
指数仍至少为 `rho Np/(56q)`。于是可用

```text
K^+ < rho N/2,
rho Np/(56q) >= ln|Sigma| K^+ + ln(10q),
p <= 1/2
```

作为一个无歧义的 rounded sufficient condition；它只改变常数，不改变上面的半径指数。

### 参数化 sample theorem 的证明草稿

下面把上一节的目标写成可逐行审查的命题。它不是 DGL 原文的陈述；`N` 指其
Section 6.1 的同一个 sample-based algorithm，所有未列出的假设（`q=o(sqrt(log N)`、
有限 alphabet 的增长条件、错误/随机性 reduction 的合法域）均沿用 DGL。

**命题（待最终形式化）。** 令 `M` 是一侧 `rho`-robust、错误率 `1/3` 的 `ell`-local
algorithm。经过 DGL Lemma 5.10 后，令 `q=O(ell log ell)`、`sigma=1/(8q)`，并取
`gamma=48|Sigma|^q ln|Sigma|`、`p=gamma N^(-1/(2q^2))`。若 `p<=1/2`，且取
`K^+=ceil(gamma q^2 N^(1-1/q))`、`alpha=ceil(12 ln|Sigma|/(rho sigma))` 后满足

```text
K^+ < rho N/2,
rho Np/(56q) >= ln|Sigma| K^+ + ln(10q),
```

则 DGL 的 `N` 在同一承诺域上以常数错误率计算 `M`，样本数为
`O(gamma N^(1-1/(2q^2)))`，并保留用于 robust-input 分析的半径 `rho`。

**证明草稿。** Lemma 5.8/5.9 的 error reduction 和 randomness reduction 不改变
robust radius，故只需检查 Section 6.2。

* 由 DGL Claim 6.2 的逐层 kernel 估计，`|K_j|<=gamma q^2 N^(1-max{1,j}/q)`；
  因而 `|K_0|,|K_1|<=K^+<rho N/2`。
* 在非 robust 分支（DGL Claim 6.4），`D_0` 的并集体积小于 `rho N/2`。对于被
  `alpha` cap 删除的 `D_1` 子集 `C`，有
  `|K_1|+|C|/alpha < rho N/2+|mu_x|/alpha <=rho N`，其中
  `|mu_x|=6N ln|Sigma|/sigma` 且 `alpha>=12 ln|Sigma|/(rho sigma)`。因此 volume
  lemma 的两个 `2sigma` 损失和原有错误率损失仍给出 `1-5sigma` 的有效票数；
  DGL 的后续 daisy/Chernoff 估计不含新的 `rho`。
* 在 robust 分支且 `j>1` 时，原 Claim 6.5 的 `beta_j`、petal sampling 和
  assignment union bound 只使用 `|K_j|` 的上界，完全沿用 DGL。
* 在 `j=1` 时，DGL 的单个 kernel assignment 失败概率在取整后至多
  `exp(-rho Np/(56q))`：这里用
  `alpha<=14 ln|Sigma|/(rho sigma)`（`|Sigma|>=2`、`rho<=1`、`sigma<=1/8`）。
  第二条窗口于是给出
  `exp(-rho Np/(56q)) <= |Sigma|^(-K^+)/(10q) <= |Sigma|^(-|K_1|)/(10q)`。
  对 `|Sigma|^{|K_1|}` 个 assignment 和所有 `j` 做原有 union bound，robust 分支
  仍以至少 `9/10` 的概率不误报。
* sampling step 的 `1/10` 失败概率、非 robust 分支的 `9/10` 成功率和 robust 分支
  的 union bound 与原文相同，故总错误率仍可压到 `1/3`。

唯一尚未写入该草稿的细节是 DGL 对实数参数的统一取整约定、`p` 的边界情形以及
`rho` 作为函数输入长度变化时的正式量词；这些不改变上述两个窗口条件，但必须在
最终定理中明确。

**固定参数的渐近形式。** 当 `ell`、`q` 和有限 alphabet `Sigma` 都固定时，存在常数
`C=C(q,Sigma)`，使得对充分大的 `N`，条件

```text
rho_N >= C * N^(-1/q+1/(2q^2))
```

同时蕴含上面的两条 rounded inequalities、`p<=1/2` 以及 DGL 的全部原始增长条件。
因此，参数化 DGL 扩展的最简论文表述是：固定查询复杂度下，robust radius 只要高于
`N^(-1/q+1/(2q^2))` 的常数倍，仍可转换为相同 sample exponent 的 sample-based
algorithm；这条渐近形式仍需把前述 proof draft 封装成正式命题。

### 可调 sampling 的 radius--sample tradeoff

DGL 取 `p=gamma N^(-1/(2q^2))` 是一个方便的安全点，并非证明中唯一可用的指数。
以下记 `q>=2`；`q=1` 时没有 `j>1` 的分支，可单独处理。
把采样概率改为

```text
p_a = gamma * N^(-a),   0<a<1/q^2,
```

并保持同一阈值定义，则 `j>1` 的 Chernoff/union-bound 指数的最小幂为
`N^(1/q-aq)`；因此 `a<1/q^2` 是一个统一的充分窗口（`j=q` 的无 kernel 情形也
需要该指数趋于无穷）。`j=1` 只需把 rounded 条件改成

```text
rho N p_a/(56q) >= ln|Sigma| K^+ + ln(10q).
```

这里的“最小幂”来自 robust 分支中每个固定 kernel assignment 的指数

```text
N^(1-(j-1)/q) * p_a^j
  = gamma^j * N^(1-(j-1)/q-a*j),
```

与 assignment 数 `|Sigma|^{K_j}` 的比较；相对于 `K_j <= gamma q^2
N^(1-j/q)`，最坏的幂差在 `j=q` 处为 `1/q-aq`。因此这一步同时覆盖
`2 <= j <= q-1` 的 union bound，以及 `K_q=emptyset` 时仍需单 assignment
失败概率趋于零的 `j=q` 分支。非 robust 分支沿用同一指数估计，采样步只需另外取
足够大的 `N` 使 `p_a<=1/2` 且 `N p_a` 趋于无穷；这些条件不改变固定 `q` 下的幂次。

于是固定 `q,Sigma` 时得到连续的候选 tradeoff：

```text
sample size S_a = Theta(N^(1-a)),
rho_a = Omega(N^(-1/q+a)).
```

原 note 的窗口是 `a=1/(2q^2)` 的特例；令 `a` 从下方逼近 `1/q^2`，候选 sample
exponent 可推进到 `1-1/q^2`，相应半径尺度推进到
`N^(-1/q+1/q^2)`。这只是把原证明中的幂次重新记账后的 theorem target，正式版本
仍需逐项重写 `j=q`、sampling cap、原始增长条件和所有常数 slack；`a` 在这里是固定
于给定 `q` 的常数，且命题只对充分大的 `N` 生效。不能直接冒称为 DGL 已发表结果。

### 对 ACRR 的条件性推论

设 `C:{0,1}^k -> Sigma^N` 的距离为 `delta_C`，ACRR 的错误声明在每个目标 codeword
的 `delta_0` 邻域内接受率至多 `beta<1`，且查询数为常数 `ell`。阈值放大后令
`q'=O(ell log ell)`，并取 relaxed decoding radius `delta_0/2`。若

```text
delta_0 >= rho_round(N,q',Sigma)
and delta_C > delta_0,
```

其中 `rho_round` 满足上面的 rounded sufficient condition，则参数化 DGL 命题一旦
正式化，就给出与常数半径情形相同的 sample exponent，进而通过全消息信息论得到

```text
N >= k^(1+1/O(q'^2 log^2(q'+2))).
```

这是真正的半径—长度 lower-bound theorem 候选；它依赖上述参数化 DGL 扩展和
family-level relaxed-LDC 接口，不应当当作已证的 ACRR 一般不可能性。

其推导链是明确的：对每个坐标把两个声明 verifier 各运行
`O((1-beta)^(-2))` 次并作阈值，得到查询数 `q'=O(ell log ell)` 的 relaxed local
algorithm；完备 codeword 上正确分支通过，`delta_0` 邻域内错误分支不越过阈值，因而
不会输出错误位。若 `delta_C>delta_0`，取 relaxed decoding radius `delta_0/2` 满足
定义要求。参数化 sample theorem 给出样本数
`S=N^(1-1/O(q'^2 log^2(q'+2)))`；在同一批样本上把每个位错误降到 `1/(3k)` 后，
全消息解码以常数概率成功，而样本至多携带 `O(S)` 个有限字母比特，故
`k<=O(S)`，整理得到上式。这里唯一仍需外部复核的不是信息论步骤，而是参数化 DGL
sample theorem 对全部原始增长条件、取整边界和 relaxed-LDC 定义的逐项封装；项目内
的 derived 版本已把这些条件显式列出。

这里必须调用 DGL Theorem 7.7 的 relaxed 版本，而不是把普通 Theorem 6.1 直接套用：
对声明 `b=0,1` 分别用对应的输出分支构造 `N_b`，最后在同一批样本上合并；valid
codeword 上要求正确输出，`delta_0` 邻域内只禁止错误输出，允许 `bottom`。因此
ACRR 不需要为近 codeword 上的正确声明提供额外完备性；这正是 relaxed-LDC 接口，
也是 C26 量词中必须保留的条件。

## 对 ACRR 主线的裁决

当前可保留的 barrier 是：

```text
统一 code family
+ 完美 codeword 完备性
+ 常数 q、有限 alphabet
+ 常数半径 robust-near-oracle 错误 soundness
=> relaxed-LDC
=> 超线性长度下界。
```

若 RW/ACRR 只给出 codeword 点 soundness、syntax-valid proof soundness、受限 circuit
family soundness，或半径随 `T` 缩到 `o(1)`，note 188/本 note 都不能直接推出一般
LDC barrier。这些正是需要继续攻击的真实逃逸，而不是可以由“允许 `bottom`”一笔带过的
细节。

此外，统一 code family 仍是必要量词：单个 RW 实例的 `V_{x,i,b}` 随 `x` 改变，不能
自动充当 LDC 的 `V_{i,b}`。必须另证 P-uniform universalization，且不能把消息编码进
实例或隐藏 advice。

## 证据边界

* 半径—距离耦合与恒等编码反例是本 note 的直接证明。
* Dall’Agnol--Gur--Lachish 的正式 robust-local 定理按常数 robustness 陈述；上面带
  `K_*` 与 assignment-union-bound 的窗口是从其证明细节提取的候选充分条件，不是
  文献原文定理，仍需独立逐行复核。
* 因此本 note 不把其长度结论无条件外推到任意 `delta_0=o(1)`；小半径窗口本身是
  当前可升级为新参数化 lower-bound theorem 的研究目标。
* 本 note 不声称一般 ACRR 不可能性；它精确划出可调用 RLDC 下界的半径与量词窗口。
* DGL 引言脚注提到的 `Theta(N^(-1/q))` 弱半径只针对一个固定 robust 输入；它不能
  直接替代本 note 对整个 codeword family 所需的 assignment union bound。把单点半径
  结论用于 ACRR/RLDC 全族，是当前最容易发生的量词错误。

## 来源

- [Dall’Agnol--Gur--Lachish, TR20-154](https://eccc.weizmann.ac.il/report/2020/154/download)
- [note 188: robust-near-oracle ACRR barrier](188-anti-abort-acrr-implies-relaxed-ldc-barrier-2026-08-16.md)
