> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 不用 whole-tree labeler 的 subtree-lift boundary search（2026-08-15）

## 命题

令

\[
G_q:\{0,1\}^q\to\{0,1\}^{2q},
\qquad
G_q(u)=G_0(u)\Vert G_1(u),
\]

并定义

\[
\operatorname{Exp}_{G,0}(u)=u,
\qquad
\operatorname{Exp}_{G,d+1}(u)
=
\operatorname{Exp}_{G,d}(G_0(u))
\Vert
\operatorname{Exp}_{G,d}(G_1(u)).
\tag{1}
\]

于是 \(\operatorname{Exp}_{G,d}(u)\) 是长度 \(q2^d\) 的字符串。给定目标串

\[
Y\in\{0,1\}^{q2^H},
\]

并假设 \(H,q,\log q\) 以及式 (2) 的局部谓词描述长度都由底层参数 \(n\) 在
多项式范围内控制；否则下面只是抽象的量词分类，而不是按 \(n\) 计的标准 PH 算法。
假设其每一位有一个固定、single-valued、精确的局部谓词

\[
Y(a,\ell),
\qquad a\in\{0,1\}^{H},\quad \ell\in[q],
\tag{2}
\]

并且该谓词属于 P（更一般地，属于某个固定的 PH 层，见下文）。对
\(p\in\{0,1\}^{H-d}\) 定义 subtree-lift 谓词

\[
\operatorname{Lift}(d,p)
\;:\Longleftrightarrow\;
\exists u\in\{0,1\}^{q}
\ \forall b\in\{0,1\}^{d}\ \forall\ell\in[q],
\quad
\operatorname{Exp}_{G,d}(u)[b,\ell]=Y(pb,\ell).
\tag{3}
\]

其中 \(\operatorname{Exp}_{G,d}(u)[b,\ell]\) 可沿 \(b\) 指定的单一路径递归求值，
时间为 \(O(d|G_q|+\operatorname{poly}(q))\)，不需要物化 \(2^d\) 个叶。
因此当 \(Y\) 的 bit predicate 属于 P 时，式 (3) 是固定的
\(\Sigma_2^P\) 谓词；关键是量词层数不依赖 \(d\) 或 \(H\)。

## 边界搜索算法

从根查询 \(\operatorname{Lift}(H,\epsilon)\)。

1. 若为真，用同一个 \(\Sigma_2^P\) 谓词逐位自归约出 root seed \(u\)。于是
   \(Y=\operatorname{Exp}_{G,H}(u)\)，并得到大小
   \(O(H|G_q|+q+\operatorname{poly}(H,q))\) 的 truth-table 电路。
2. 若为假，当前必有一个不 lift 的 subtree。若当前为 \((d,p)\)，查询
   \(\operatorname{Lift}(d-1,p0)\) 与 \(\operatorname{Lift}(d-1,p1)\)。
   - 若至少一个为假，就沿一个 false child 继续下降；
   - 若两个都为真，就停止。

   因为 \(\operatorname{Lift}(0,p)\) 总为真，下降至多 \(H\) 步后必到达一个
   \((d,p)\) 满足

\[
\neg\operatorname{Lift}(d,p),
\qquad
\operatorname{Lift}(d-1,p0),
\qquad
\operatorname{Lift}(d-1,p1).
\tag{4}
\]

对两个 true children 分别用固定的 \(\Sigma_2^P\) 自归约恢复 roots
\(u_0,u_1\in\{0,1\}^q\)，并令

\[
z:=u_0\Vert u_1\in\{0,1\}^{2q}.
\tag{5}
\]

则

\[
\boxed{z\notin\operatorname{Range}(G_q).}
\tag{6}
\]

否则存在 \(v\) 使 \(G_q(v)=u_0\Vert u_1\)。由式 (1)，

\[
\operatorname{Exp}_{G,d}(v)
=
\operatorname{Exp}_{G,d-1}(u_0)\Vert
\operatorname{Exp}_{G,d-1}(u_1),
\]

恰好等于当前 subtree 的目标串，和 \(\neg\operatorname{Lift}(d,p)\) 矛盾。

整个过程只调用 \(O(H+q)\) 个固定层 PH 查询，并输出一个明确的
\(2q\)-bit non-range outsider；不需要为所有中间 occurrences 构造
whole-tree word labels。

## 固定 PH 层的推广

如果式 (2) 不是 P 而属于某个固定的 \(\mathrm{PH}_c\) 谓词，则把式 (3) 的两个
新量词与原谓词合并，得到某个固定的 \(\mathrm{PH}_{c+O(1)}\) 谓词。具体是
\(\Sigma_k/\Pi_k\) 的极性可能使层数增加一或两层；本命题只使用“层数为固定常数，
不随 \(d,H\) 增长”这一点，不把它误写成统一的精确 \(\Sigma_{c+2}\) 归类。

## 与 CLL/RW 的边界

这条引理把 note 152 的强 whole-tree labeler 假设严格缩小为一个初始目标串的
fixed-level exact local generator：

\[
\boxed{
\text{完整初始 history/proof }Y\text{ 有固定、逐位一致的局部谓词}
}
\]

但它尚未闭合 CLL/RW 路线：

1. note 150 已排除 CLL canonical hard string 的 deterministic
   \(\operatorname{poly}(n)\)-size address accessor；因此 CLL 的 hard \(Y\) 不能
   直接作为式 (2) 的 P-time predicate。
2. CLL commit-and-evaluate 给的是“每个地址可由后续 Merlin strategy 回答”，其量词
   形状是逐地址的 \(\forall a\,\exists\) response，而式 (2) 要求同一个
   single-valued \(Y(a,\ell)\)。不同地址使用不一致的 strategies 会产生 phantom proof，
   不能代入式 (3)。
3. 若只知道 \(Y\) 的 predicate 属于固定 PH 层，式 (6) 仍只是
   \(\mathrm{FP}^{\mathrm{PH}}\) 搜索接口；在 \(P=NP\) 下可确定化，但输出 outsider
   不自动具有 CLL 的高电路复杂度，也不自动给出 \(P\ne NP\)。

因此与 note 152 相比，剩余问题从

\[
\text{所有递归节点的 whole-tree labeler}
\]

缩小为

\[
\boxed{
\text{完整初始 RW/CLL history 的 fixed-level、single-valued、exact local predicate}
}.
\]

## CLL 的参数障碍仍然存在

CLL Theorem 1.3 对长度为 \(N\) 的 canonical string 给出的 Arthur--Merlin 过程，
运行时间是

\[
T_N=2^{(\log N)^{O(k)}},
\qquad
\text{advice}=2^{(\log N)^{1/k}},
\tag{7}
\]

而不是地址长度 \(\log N\) 的多项式时间过程。即使把该过程成功固定成
single-valued 的 exact local predicate，subtree-lift 查询的时间和描述长度仍至少
继承 \(T_N\)。取 \(N=2^n\) 时这是 \(2^{n^{O(k)}}\)，不能作为
\(q=\operatorname{poly}(n)\) 的 decoder accessor。令 \(q\) 大到足以承载该过程又会把
整个接口退回 \(q\)-scale，而不是 P-vs-NP 所需的外部 \(n\)-scale。

所以 subtree-lift lemma 真正关闭的是**递归 preimage 膨胀**，没有关闭 CLL 的
**初始 history 地址时间**障碍；后者仍必须由新的构造性参数压缩解决。

## 来源与边界

- [note 150](150-cll-hard-string-forbids-polynomial-address-accessor-2026-08-15.md)：
  CLL hard string 排除确定性 polynomial-address accessor。
- [note 149](149-am-commitment-is-not-a-deterministic-jk-seed-2026-08-15.md)：
  AM commitment 与 deterministic word seed 的量词区别。
- [note 151](151-cll-hard-string-is-an-iterated-decoder-outsider-2026-08-15.md)：
  iterated decoder range 的根级 outsider。
- [note 152](152-whole-tree-labeler-makes-cll-outsider-sigma2-searchable-2026-08-15.md)：
  whole-tree labeler 版本的 first-outsider 搜索。

本 note 是严格的条件性 subtree-lift lemma，不声称已经证明 \(P\ne NP\)。

核验日期：2026-08-15。
