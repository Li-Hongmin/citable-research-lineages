> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact Gap-MCSP 到 approximate-MCSP 的扰动接口（2026-08-14）

## 结论

令 \(m\) 是函数变量数，\(N=2^m\) 是 truth table 长度，并采用固定的
fan-in-two De Morgan circuit 基。记

\[
E_s:=\{x\in\{0,1\}^N:\operatorname{Size}(x)\le s\},
\qquad
G_{s,t}:=\operatorname{GapMCSP}[s,t].
\]

存在绝对常数 \(c>0\)，使得对 \(t>s\)

\[
D_{s,t,m}:=\left\lfloor\frac{t-s}{cm}\right\rfloor+1
\tag{1}
\]

满足

\[
G_{s,t}^{\mathrm{NO}}
\subseteq
\left\{x:\ d_H(x,E_s)\ge D_{s,t,m}\right\}.
\tag{2}
\]

对任意整数 \(D\)，定义

\[
 A_{s,D}^{\mathrm{NO}}
 :=\left\{x\in\{0,1\}^N:\ d_H(x,E_s)\ge D\right\},
 \qquad
\operatorname{ApproxMCSP}[s,D]
:=(E_s,A_{s,D}^{\mathrm{NO}})
\tag{3}
\]

定义为以**绝对** Hamming 距离 \(D\) 给出的 promise。

故 exact \(G_{s,t}\) 是以距离 \(D_{s,t,m}/N\) 为 NO 端的
approximate-MCSP promise 的 restriction。特别地，任何类 \(\mathcal C\) 中对该
approximate promise 的 solver 都是 \(G_{s,t}\) 的 solver，因而

\[
G_{s,t}\notin\mathcal C
\quad\Longrightarrow\quad
\operatorname{ApproxMCSP}[s,D_{s,t,m}]\notin\mathcal C.
\tag{4}
\]

把 Oliveira--Pich--Santhanam (OPS) 的无条件公式下界代入后，这个由单点修补给出的直接
exact-to-approximate 接口仍不能触发 Atserias--Müller (AM) 的 sparse-language
magnification：Formula 指数至少差一个 \(N\) 的幂；在表面上指数对齐的 PFML
分支，AM 的通用去随机化仍损失一个 \(N\) 因子，且有固定 \(\varepsilon\) 的严格端点失配。因此它不是
\(P\ne NP\) 的捷径。

## 扰动引理

若两个 \(m\)-变量函数 \(f,g\) 的 truth tables 相差一位，则

\[
\bigl|\operatorname{Size}(f)-\operatorname{Size}(g)\bigr|\le cm.
\tag{5}
\]

确实，若变化位置为 \(a\in\{0,1\}^m\)，则 equality detector

\[
e_a(z)=\bigwedge_{i=1}^m (z_i=a_i)
\]

有 \(O(m)\)-size De Morgan circuit；把原 circuit 输出与 \(e_a\) 做一次常数大小的
XOR 修补，得到翻转该唯一 truth-table bit 的 circuit。反向同理。沿任意长度
\(r\) 的 Hamming path 望远镜求和，得到

\[
\operatorname{Size}(f')\le \operatorname{Size}(f)+cm\,d_H(f,f').
\tag{6}
\]

若 \(x\in G_{s,t}^{\mathrm{NO}}\)，而某个 \(y\in E_s\) 有
\(d_H(x,y)<D_{s,t,m}\)，则 (1) 与 (5) 给出

\[
\operatorname{Size}(x)
\le s+cm\bigl(D_{s,t,m}-1\bigr)
\le t,
\]

矛盾。于是 (2) 成立。该基本扰动界也由 Krinkin 2026 对任意固定有限完备基显式表述；
这里给出的证明固定了本单元所用的 De Morgan 模型。

## OPS 参数的精确像

OPS Theorem 5 说明：任意固定 \(0<\alpha<2\)，存在 \(d>1\)，使得

\[
G_{\alpha,m}:=
\operatorname{GapMCSP}
\left[m^d,\,2^{(\alpha/2-o(1))m}\right]
\notin U_2\text{-}\operatorname{Formula}[N^{2-\alpha}].
\tag{7}
\]

令 \(s=m^d\)、\(t=2^{(\alpha/2-o(1))m}\)。由 (1)，

\[
D_{s,t,m}
=\frac{2^{(\alpha/2-o(1))m}}{\operatorname{poly}(m)}
=N^{\alpha/2-o(1)}.
\tag{8}
\]

因此 (4) 给出真正的 approximate 下界：

\[
\operatorname{ApproxMCSP}
\left[m^d,N^{\alpha/2-o(1)}\right]
\notin U_2\text{-}\operatorname{Formula}[N^{2-\alpha}].
\tag{9}
\]

其 YES language \(\operatorname{MCSP}[m^d]\) 是 sparse NP language，因为 size
至多 \(m^d\) 的 circuit 描述数为

\[
2^{O(m^d\log m)}=2^{N^{o(1)}}.
\tag{10}
\]

所以 sparsity 不是这里的遗漏条件。

## 与 AM 阈值的比较

以下固定 \(0<\alpha<1\)。这已覆盖 OPS 定理能够提供、且这里需要比较的超线性
Formula 下界区间；OPS 本身允许更广的 \(0<\alpha<2\)。

AM 的 \(N^{-\varepsilon}\)-MCSP NO 端距离为 \(N^{1-\varepsilon}\)。对任意固定
\(0<\eta<\alpha/2\)，(8) 保证当 \(m\) 充分大时

\[
N^{\alpha/2-\eta}
\le D_{s,t,m}.
\tag{11}
\]

故令

\[
\varepsilon:=1-\alpha/2+\eta
\tag{12}
\]

时，\(G_{\alpha,m}\) 的 NO 端包含于该固定 \(N^{-\varepsilon}\)-MCSP 的 NO 端。AM
Theorem 9(a) 若要应用，要求

\[
N^{-\varepsilon}\text{-}\operatorname{MCSP}[m^d]
\notin\operatorname{FML}
\left[N^{1+2\varepsilon+o(1)}\right]
=\operatorname{FML}\left[N^{3-\alpha+2\eta+o(1)}\right].
\tag{13}
\]

而 (9) 只有 \(N^{2-\alpha}\) 的 Formula 下界，故至少缺失一个完整的指数 \(1\)。

对于 Theorem 9(b)，同一个固定 \(\varepsilon\) 要求

\[
N^{-\varepsilon}\text{-}\operatorname{MCSP}[m^d]
\notin\operatorname{PFML}
\left[N^{2\varepsilon+o(1)}\right]
=\operatorname{PFML}\left[N^{2-\alpha+2\eta+o(1)}\right].
\tag{14}
\]

普通 Formula 下界不能在同一大小直接变成 PFML 下界；但 AM Remark 22 给出可用的一般方向

\[
\operatorname{PFML}[S]\subseteq\operatorname{FML}[O(NS)].
\tag{15}
\]

所以对每个固定 \(\rho>0\)，(9) 至多推出

\[
\operatorname{ApproxMCSP}
\left[m^d,N^{\alpha/2-o(1)}\right]
\notin\operatorname{PFML}[N^{1-\alpha-\rho}].
\tag{16}
\]

它比 (13) 所需的指数至少低一个完整的 \(N\) 因子。等号
\(\varepsilon=1-\alpha/2\) 不能由 (8) 保证，因为其中的 \(o(1)\) 损失来自 OPS 的 NO
阈值及 \(m\)-gate 单点修补；本 note 不声称实际 promise inclusion 在等号处必然失败。

## 路线裁决

本 note 修正了一个容易遗漏的中间判断：exact Gap-MCSP 并非与所有 approximate
promise 都无关；它无条件给出 (9) 的极低距离 approximate lower bound。可是这条
直接嵌入没有消去 AM 的两个承重接口：

\[
\boxed{
\text{fixed-}\varepsilon\text{ endpoint / exponent margin}
\quad+\quad
\operatorname{PFML}\to\operatorname{Formula}\text{ derandomization loss }N.
}
\]

故下一步不应把 exact Gap 的 promise 当作 AM 的 fixed-distance premise 直接代入；
沿 AM 的这条 general-magnification 路线，任何可接入的新结果必须至少处理其中一个盒内障碍。这里没有证明
\(P\ne NP\)，也没有证明这两种障碍在未来方法下不可能跨越。

## 来源

- Igor Carboni Oliveira, Ján Pich, and Rahul Santhanam, *Hardness Magnification near
  State-Of-The-Art Lower Bounds*, CCC 2019, Theorems 4--5，尤其 Theorem 5 与
  Definition 9。全文：`ResearchLibrary/lib/oliveira2019hardness/oliveira2019hardness.pdf`。
- Albert Atserias and Moritz Müller, *Simple general magnification of circuit lower bounds*,
  arXiv:2503.24061v2, Definition of \(\varepsilon\)-MCSP and Theorem 9。
  Remark 22 给出 (15)。
  全文：`ResearchLibrary/lib/muller2025simple/muller2025simple.pdf`。
- Kirill Krinkin, *A Simple Constructive Bound on Circuit Size Change Under Truth Table
  Perturbation*, arXiv:2603.09379v1 (2026), Theorem 1。全文：
  `ResearchLibrary/lib/krinkin2026simple/krinkin2026simple.pdf`。
- [note 064](064-atserias-muller-uniform-magnification-interface-2026-08-14.md)：此前已
  关闭的 fixed \(\varepsilon<1\) Frontier-B promise 直接代入；本 note 补上 exact Gap
  能够达到的最小距离尺度。
