> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Growing-query threshold forced by the RLDC closure bound (2026-08-17)

## Contribution

Note 241 closes every fixed finite alphabet and fixed locality. The same
inequality gives a quantitative boundary for the first remaining escape:
letting the branch locality grow with the message length. This is a
necessary-condition theorem, not an existence result.

For a fixed proof alphabet \(A\ge2\), fixed radius parameter \(\rho>0\), and
fixed success gap \(\sigma=1-\beta\in(0,1]\), any near-linear construction must have
\[
  Q_{r,A}=\Omega\!\left(\frac{\log k}{\log\log k}\right),
\]
where \(Q_{r,A}=1+2\sum_{j<r}A^j\) is the non-adaptive query count obtained from
the two adaptive branch trees. Thus, for binary proofs, all branch localities
\[
  r\le \log_2\log k-\log_2\log\log k-\omega(1)
\]
are already ruled out by the existing RLDC lower bound. The remaining
growing-locality escape begins only near the \(\log\log k\) scale.

## Theorem

Fix constants \(A\ge2\), \(0<\rho<1\), \(\sigma_0>0\), and \(c>0\). Consider
the tagged finite-alphabet shared-proof interface of note 241, with
\(\sigma=1-\beta\ge\sigma_0\), and let
\[
  Q:=Q_{r,A}=1+2\sum_{j=0}^{r-1}A^j,\qquad
  a:=\left\lceil Q/\sigma\right\rceil .
\]
If its inline length obeys
\[
  N\le k(\log k)^c
\tag{242.1}
\]
for infinitely many sufficiently large \(k\), then
\[
  Q=\Omega_{A,\rho,\sigma_0,c}\!\left(\frac{\log k}{\log\log k}\right).
\tag{242.2}
\]
Equivalently, if \(Q=o(\log k/\log\log k)\), the interface cannot have
near-linear length.

For fixed \(A\), since \(Q_{r,A}=\Theta_A(A^r)\), there is a constant
\(C=C(A,\rho,\sigma_0,c)\) such that (242.2) implies
\[
  r\ge
  \log_A\log k-\log_A\log\log k-C.
\tag{242.3}
\]

## Proof

By note 241 and the arbitrary-alphabet RLDC theorem of
Goldberg--Gur--Saraogi, the tagged inline code satisfies
\[
  N\ge
  \left(
    \frac{\sigma^2 k}
    {38Q^4\log^2(A+2)\log^2 k}
  \right)^{1+1/a}.
\tag{242.4}
\]
The alphabet \(A\), \(\rho\), and \(\sigma_0\) are fixed, so all factors other
than \(Q\) and \(k\) hidden in (242.4) are constants.

Put \(g:=\log k/\log\log k\). We prove a uniform constant lower bound rather
than only excluding \(Q=o(g)\). Suppose \(Q\le\eta g\), where \(\eta>0\) will
be chosen from \(A,\sigma_0,c\). Since \(\sigma\ge\sigma_0\), for all large
\(k\),
\[
  a=\left\lceil Q/\sigma\right\rceil
  \le \frac{2\eta}{\sigma_0}g,
\qquad\text{and hence}\qquad
  \frac{\log k}{a}\ge\frac{\sigma_0}{2\eta}\log\log k.
\tag{242.5}
\]
Let
\[
  D:=38Q^4\log^2(A+2)\log^2 k/\sigma^2.
\]
Under \(Q\le\eta g\) and \(\sigma\ge\sigma_0\),
\[
  \log D\le 6\log\log k+O_{A,\sigma_0,\eta}(1).
\tag{242.6}
\]
The radius hypothesis of the GGS theorem also holds on this contradiction
branch. Indeed, \(N\ge k\) and \(N\le k(\log k)^c\) imply
\[
  N^{-\sigma/(2Q)}
  \le
  \exp\!\left(
    -\frac{\sigma_0\log k}{2\eta g}
  \right)
  =
  (\log k)^{-\sigma_0/(2\eta)}
  <\delta_0
\]
for all sufficiently large \(k\), where \(\delta_0>0\) is the fixed inline
radius from note 241. Thus (242.4) is legitimately applicable in the only
regime used for the contradiction.
Taking logarithms in (242.4) and using (242.1) gives
\[
  \frac{\log k}{a}
  \le c\log\log k+(1+1/a)\log D
  \le (c+12)\log\log k+O_{A,\sigma_0,\eta}(1).
\tag{242.7}
\]
Choose, for example,
\(\eta<\sigma_0/[4(c+12)]\). Equations (242.5) and (242.7) then contradict
each other for all sufficiently large \(k\). Thus \(Q\ge\eta g\), proving
(242.2). The fixed-\(A\) estimate \(Q_{r,A}=\Theta_A(A^r)\) gives (242.3).
\(\square\)

## Interpretation

For binary proofs, \(Q_{r,2}=2^{r+1}-1\). More precisely, the uniform constant in
(242.2) gives a constant \(C=C(\rho,\sigma_0,c)\) such that every
\[
  r\le\log_2\log k-\log_2\log\log k-C
\]
is excluded for all sufficiently large lengths in the family. The equivalent
\(-\omega(1)\) formulation is therefore valid, but the constant form is the one used
by the theorem. It does not claim that the threshold-scale
\(r\) construction exists; it only says that any surviving near-linear route
must pay at least this much query complexity.

If the proof alphabet \(A\) itself grows with \(k\), both the decision-tree
size \(Q_{r,A}\) and the \(\log|\Gamma|\) factor in the RLDC theorem grow.
That regime is not silently covered by (242.2); it requires a separate
parameter calculation.

## Sources

* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for Relaxed
  Locally Decodable Codes via Robust Daisies*, arXiv:2511.21659, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.
* The finite-alphabet inline compiler is in
  [note 241](241-constant-alphabet-adaptive-bottom-closure-2026-08-17.md).
