> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW singleton short-fingerprint Closure gate (2026-08-19)

## 本轮改变的判断

C367 的短指纹定理解决的是 payload family：多个目标由一个 separated
fingerprint 绑定时，公共 proof 会给出 RLDC。它有意不适用于 published RW 的
singleton \(B_n\)。本轮把这个单例缺口写成一个二分：

* 若短指纹没有一个公开的、同一地址空间上的 target-evaluation map，它不产生
  \(B_n\) 的 \(P/\mathrm{poly}\) evaluator，只是 transcript statistic；
* 若它有这样的 map，则把真实指纹硬接为该长度的常量，直接得到 \(B_n\) 的电路；
  若 map 只给固定接受 gap，则有限 public-tape sampling 给出 C469 的 forcing-scale
  上界。

因此“先压缩成 fingerprint，再从 fingerprint 恢复 singleton history”不是第四条
免费逃逸。它要么尚未闭合 Gate III，要么已经落入 common-package/forcing payment。
这里不需要假设有一个不存在的目标 family，也不把 singleton 指纹误套成 RLDC。

## 设置

取 C455 的无限 hard-length 集合 \(\mathcal I\)。对 \(n\in\mathcal I\)，令

\[
  B_n\in\{0,1\}^{N_n},\qquad
  m_n=\lceil\log_2(N_n+1)\rceil,\qquad
  S_n:=\operatorname{CC}(B_n)\ge cN_n/\log N_n .
  \tag{470.1}
\]

一个 **singleton fingerprint attachment** 由一个 target-dependent word
\(F_n\in\Lambda^{R_n}\)（或其 seed/descriptor）和一个声称的 target evaluator 组成。
若 evaluator 采用 common proof 的 fingerprint decoder，则 decoder、collapse 后的
promise 查询以及地址控制都算入下面的 finite control；不能把 proof oracle 或
candidate lookup 当作免费输入。

## 定理 470.1（singleton short-fingerprint Closure gate）

对每个 \(n\in\mathcal I\)，考虑以下三个接口分支；精确 map 视为先归入 (D)，
否则再检查固定-gap 的 randomized map (R)。

### (N) 只有指纹，没有 target evaluator

接口至多声称：一个 common proof 可以在若干地址上恢复 \(F_n\)，或可以验证
\(F_n\) 的短摘要；但没有一个公开 procedure \(G_n\) 将
\((j,F_n)\)（以及已计价的 seed/descriptor）变成 \(B_n[j]\)。
那么该接口没有推出 \(B_n\in P/\mathrm{poly}\)，因而不能完成 Gate III。
即使 \(|F_n|\) 很短，singleton 没有第二个候选目标可供 fingerprint
识别；C367 的 family-level sampling 结论在这里没有可用的 message index。

### (D) 精确 target evaluator

存在一个 Boolean circuit \(G_n(j,F)\)，对真实 \(F_n\) 满足

\[
  G_n(j,F_n)=B_n[j]\qquad(j\in[N_n]),
  \tag{470.2}
\]

其地址输入长 \(m_n\)，把 \(F\) 当作普通输入时的 fan-in-two 大小为 \(g_n\)。把
\(F_n\) 的每一位硬接成常量后，

\[
  \operatorname{CC}(B_n)\le g_n+O(m_n).
  \tag{470.3}
\]

所以在 C455 的 hard lengths 上 \(g_n=\Omega(N_n/\log N_n)\)。特别地，
一个 \(m_n^{O(1)}\)-size 的 candidate evaluator 不可能通过“指纹很短”逃过
forcing；其 target-evaluation 线路本身已经支付 forcing scale。

### (R) 固定 gap 的 randomized target evaluator

存在一个同一地址空间上的响应 \(E_n(j;F_n,R)\)，其中 \(R\) 为 public tape，且

\[
  B_n[j]=1\Rightarrow\Pr_R[E_n(j;F_n,R)=1]\ge\alpha_n,\qquad
  B_n[j]=0\Rightarrow\Pr_R[E_n(j;F_n,R)=1]\le\beta_n,
  \tag{470.4}
\]

令 \(\gamma_n=\alpha_n-\beta_n>0\)。假设在 \(P=NP\) collapse 后，单条 tape 的
finite control（包括 fingerprint decoder、promise query 和 address map）成本为
\(\kappa_n\)，至多读取 \(b_n\) 次 \(d_n\)-bit static package（该 package 可以是
\(F_n\)、seed 的展开或 descriptor），并按普通 mux 计价。取

\[
  t_n=O\!\left(\frac{m_n+\log(1/\delta_n+2)}{\gamma_n^2}\right).
  \tag{470.5}
\]

则

\[
  \operatorname{CC}(B_n)\le
  O\!\left(t_n\bigl(\kappa_n+b_nd_n+m_n+\log(t_n+2)\bigr)\right).
  \tag{470.6}
\]

因此只要 \(t_n,\kappa_n,b_n,d_n,m_n,\log(1/\gamma_n+2)\) 都是
\(m_n^{O(1)}\)，(470.6) 就与 (470.1) 矛盾。否则 gap、package、控制或 proof
address 资源已经支付 object/forcing scale，或接口离开同一 common-package 模型。

## 证明

分支 (N) 是量词检查：C367 的正向步骤需要一个可公开比较的候选集合和
\(Y(m)_i\) evaluator。singleton 只有 \(F_n\) 这一实际 target；恢复一个摘要并不
给出从地址到 \(B_n[j]\) 的算法。若没有 \(G_n\) 或 \(E_n\)，不能把摘要写成
\(P/\mathrm{poly}\) circuit，因此该接口只是 Gate-I/II 的中间 transcript，而不是
Gate III 的结论。

在 (D) 中，把真实 \(F_n\) 的符号逐个代入 \(G_n\) 的输入常量，得到只以 \(j\)
为输入、逐位输出 \(B_n[j]\) 的电路；常量代入不增加 fan-in-two gate 数，地址译码
只贡献 \(O(m_n)\)，故得 (470.3)。

在 (R) 中取 \(t_n\) 条独立 public tapes。由 Hoeffding 不等式和至多 \(2^{m_n}\)
个地址的 union bound，存在一组固定 tapes，使所有地址的经验接受率误差不超过
\(\gamma_n/3\)。在 \(P=NP\) 下把实际 smart promise query 换成固定 deterministic
control，阈值化经验率即可逐位恢复 \(B_n\)。每条 tape 的 control、普通 mux 展开、
地址和阈值 bookkeeping 分别贡献
\(O(\kappa_n+b_nd_n+m_n+\log(t_n+2))\)，复制 \(t_n\) 条 tapes 得 (470.6)。
这与 C469 的 common-package sampling 完全一致，但本定理明确指出 fingerprint
只有在附带 target-evaluation map 后才有 singleton 语义。

## 对 Closure 计划的直接后果

1. C367 的 family-level 短指纹路线仍可作为 RLDC/coding 攻击；不能把它直接说成
   published singleton 的闭合。
2. 对 singleton，任何声称“fingerprint 已绑定 history”的方案必须显式给出
   \(G_n\) 或 \(E_n\)，并报告其 generic address、candidate lookup、seed expansion
   和 promise-control 成本；这些成本不能藏在 fingerprint 名称里。
3. 这把附件中的 target-specific information 与 address-scale Gate-I 对齐：
   指纹若不可公开评价，Closure 未完成；若可公开评价，C455/C469 forcing gate
   立即接管。剩余真正的新方向只能改变 proof/soundness/global-relation 量词，或
   明确承担 object-scale payment。

## 证据边界

定理是 published RW singleton 的条件性 Closure gate，不是无条件的
\(P\ne NP\) 证明。它不声称 C367 的 RLDC lower bound 适用于 singleton，也不排除
一个尚未定义的 non-product global relation；后者必须另行说明它怎样提供
target-evaluation 而不落入 (D)/(R)。

## 来源

* [C367 short-fingerprint target-binding closure](367-short-fingerprint-target-binding-closure-2026-08-18.md)。
* [C469 RW singleton common-package Closure trichotomy](469-rw-singleton-closure-trichotomy-2026-08-19.md)。
* [C455 published RW hard-output forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
