> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 当前 dPCP/RLDC 前沿机制对 RW Gate I 的闭合分类（2026-08-19）

## 本轮改变的判断

这次核对的不是“文献是否存在近线性 dPCP”，而是一个更窄、会改变路线选择的命题：
Gur--Minzer--Weissenberg--Zheng（GMWZ）、BMVY/HDX 与 Cheng--Li--Mao（CLM）
是否已经提供了同时满足 RW Gate I 的新 soundness mechanism，或者至少逃离 C506 的
finite-view / bounded-state 范式。

原文核对结果是一个有范围的否定：三条机制分别落入

1. 坐标专属 PCPP block 与 list-soundness；
2. 有限轮 routing transcript 与普通/unique-decoding soundness；
3. 低 soundness 下 RLDC → LDC 的加强。

它们都可能是重要的 PCP/coding 工具，但在没有新增 target-binding relation 的情况下，
没有一条直接闭合 RW 的 singleton、same-proof、address-scale whole-word 接口。

## 命题 507.1（前沿机制的三分闭合）

设一个 proposed RW attachment 保持固定有限 proof alphabet、同一物理 proof/address
space、正半径和 target-relative wrong-claim 语义。若它只把下列三类文献机制作为黑箱
组件，则：

### (G) GMWZ dPCP / PCPP-to-RLDC

GMWZ Theorem 3.12 的 dPCP soundness 是

\[
  \forall T_A\;\exists W(T_A)\subseteq L,\ |W(T_A)|\le L_0\;\forall T_B,
\]

对输出不在列表 $W(T_A)$ 中的联合事件给出平均错误界；它不是相对于一个预先固定
的 RW target $f_x$ 的 wrong-bit 界。只有在额外加入 singleton target binding
\(W(T_A)\subseteq\{f_x\}\) 后，均匀坐标分布下的 conditioning 才给出

\[
  \Pr[V_{i,1-f_x[i]}(T_A,T_B)=1]\le k\varepsilon.
\tag{507.1}
\]

若要得到固定常数的坐标 gap \(\beta<1\)，必须有 \(\varepsilon\le\beta/k\)。在
同一 proof map、正半径和固定 locality 下，message-inline 编译于是进入 RLDC
长度下界；这正是 singleton-distributional bridge 与 C114/C117 的适用窗口。

GMWZ 的实际 RLDC 构造并没有提供这个 black-box replacement：Theorem 11.3 为每个
\((i,b)\) 使用独立的 relation/PCPP \(\Psi_{i,b}\)，把选中的 $k$ 个 proof blocks
拼接进长度

\[
  4Kk=\widetilde O(k^2)
\]

的 codeword（其中单 block $K=k\operatorname{polylog}k$）。这既不是近线性
shared relation-PCPP，也没有把 list-soundness 自动变成 RW 的 singleton wrong-claim
语义。把这些 blocks 黑箱压成一个短 common proof，正落入 C111 的 shared-proof
replacement barrier。

### (H) BMVY/HDX direct-product 与 routing

BMVY 的主定理给出 HDX 上的近线性、低 soundness PCP；其 routing 子程序是有限轮
（\(O(\log n)\)）的消息传递协议，且每个 round 的 outgoing message 是有限 transcript
的函数。该机制提供的是 assignment/edge 的一致性与普通 soundness（或 GMWZ 改造后
的 unique-decoding soundness），并不提供

\[
  \forall i,b,\ \forall z\in B_\rho(\Pi_x):
  \Pr[V_{x,i,1-f_x[i]}(z)=1]\le\beta
\]

这种固定 singleton target-relative all-policy 量词。

因此，一旦把 HDX/routing 封装进共同 proof 并保持 finite visible view，它进入
C506(F) 的 RLDC locality 账本；若只对一个固定 $H_A$ 使用共享 memory/transition
实现，则进入 C506(S) 的 RAM-to-circuit forcing 账本。HDX 的 global agreement 本身
不是第三种免费 address-scale coupling。

### (L) CLM low-soundness route

CLM Theorems 3.1 与 5.1 的结论是：perfect-complete $q$-query RLDC 在

\[
  s<|\widehat\Sigma|^{-q}
\tag{507.2}
\]

的 soundness threshold 下可转换为同 query 数的 ordinary LDC（不完美完备性版本要求
nonadaptive decoder）。所以若一个 RW attachment 通过把 wrong-claim error 压到
(507.2) 来消除 bottom，它并没有得到新的 closure escape，而是直接进入普通 LDC
长度下界。若 soundness 只保持常数级，则 CLM 转换不适用，机制仍只是通常的 RLDC
分支，不能自动补上 same-proof、target-binding 或 address-scale evaluator。

CLM 的 Theorem 7.1 另给出一个很具体的 3-query PCPP 长度下界，但它要求
\(X/A/B\) 三个查询边际均匀、固定字母表、perfect completeness 与指定的低
soundness 阈值；这些假设不能外推为一般 dPCP 不可能性。

## 推论：当前 Gate-I 的真实剩余

在上述三类黑箱机制内，若不新增一个 target-binding relation，则只有以下出口：

* GMWZ：支付 \(\varepsilon=O(1/k)\) 并承受 RLDC/长度代价，或保留坐标专属
  proof blocks；
* BMVY/HDX：让 visible transcript、memory 或 preprocessing 达到 C506 所计的
  规模，或改变 target-relative/all-policy 量词；
* CLM：进入 ordinary LDC，或停留在尚不能完成 RW attachment 的 constant-soundness
  RLDC 区间。

因此下一项真正值得投入的正攻，不是把这些组件再拼一次，而是构造一个明确写出
singleton target binding、same-proof word consistency 与 \(n^{O(1)}\) address map 的
新 relation-PCP/dPCP；反向则应证明这类 target-binding relation 必须支付超线性
proof/descriptor/locality。这个结论不证明一般 dPCP impossibility，也不证明
\(P\ne NP\)。

## 证据边界

* GMWZ：原文 Definitions 3.1--3.5、Theorem 3.12 与 Theorem 11.3；前者是
  list-decoding dPCP，后者显式使用 \((i,b)\)-indexed PCPP blocks。全文：
  [arXiv:2512.12960](https://arxiv.org/html/2512.12960)。
* BMVY/HDX：原文 Theorem 1.2 及其 routing/HDX 构造；全文：
  [arXiv:2407.12762](https://arxiv.org/html/2407.12762)。有限 transcript 只说明其可被
  C506 的 finite-view 账本检查，不自动给出一个数值上已闭合的 C506 lower bound。
* CLM：原文 Theorems 1.4--1.5（正文编号 3.1、5.1）与 Theorem 7.1；全文：
  [arXiv:2603.03717](https://arxiv.org/html/2603.03717)。低 soundness 的 LDC 转换
  和特定 PCPP 下界的适用条件必须分别保留。
* 该 note 是文献机制的路线闭合与量词分类，不是新的通用 dPCP 下界；RW Gate I、
  Gate II 与 Gate III 仍未完成。
