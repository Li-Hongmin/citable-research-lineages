> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Latent-top pair-incidence closes the shared-top transfer gate (2026-08-17)

## Purpose

The shared-top transfer step in the RW/JK closure program has two logically different
parts. First one must show that conditioning on the cross-cluster event does not change
the decoder view \((t,u)\) except through the shared face \(b\). Second one must show
that the cross-event mass is smooth as a function of \(b\). The GMWZ sampling order gives
the first part, even when the event is allowed to depend on the latent top face \(U\). The
remaining missing statement is exactly a latent-\(U\) pair-incidence profile.

This note records that positive closure criterion and the sharp decomposition showing why
the one-face BMVY profile alone is insufficient.

## 1. Shared-top sampler and the corrected factorization

Fix a shared-top direct-product sampler. Conditional on a shared face \(b\), sample

1. \(U\supseteq b\);
2. \(a_0,a_1\supseteq b\) independently conditional on \((U,b)\);
3. \(u\in b\), and then \(t\) from the base decoder law conditional on \(u\).

The last step is independent of the first two conditional on \(b\). Consequently the
stronger factorization

\[
 \Pr[t,u,U,a_0,a_1\mid b]
 =\Pr[t,u\mid b]\Pr[U,a_0,a_1\mid b]
 \tag{LTP1}
\]

holds. In particular, the GMWZ agnosticity identity is not the whole reason for the
factorization: the source sampling order itself separates the decoder view from the
top-face/left-face state.

Let \(C\) be any cross event measurable from \((U,a_0,a_1,b)\), but not from the sampled
\((u,t)\). Then (LTP1) implies

\[
 \Pr[t,u\mid b,C]=\Pr[t,u\mid b].
 \tag{LTP2}
\]

Thus the old restriction that \(C\) be a function only of the exposed
\((a_0,a_1,b)\) is stronger than necessary. The latent \(U\) matters through the
\(b\)-profile of \(C\), not through an additional \(t,u\)-bias.

## 2. Latent-top pair-incidence closure theorem

Let \(\nu\) denote the base marginal of \((t,u,b)\), and let

\[
 \gamma=\Pr[C],
 \qquad
 w(b)=\Pr[C\mid b].
 \tag{LTP3}
\]

Assume (LTP1), \(C\) is independent of \((u,t)\) conditional on \(b\), and the base
decoder law has the required \(t,u\) marginal (for example the uniform \(t\)-marginal
used by the GMWZ complete decoding distribution). If the latent-top profile satisfies

\[
 \mathbb E_b\lvert w(b)-\gamma\rvert\le \eta\gamma,
 \tag{LTP4}
\]

then the full-view distance satisfies

\[
 \operatorname{TV}\!\left(\nu_{(t,u,b)\mid C},\nu_{(t,u,b)}\right)
 \le \frac{\eta}{2}.
 \tag{LTP5}
\]

More generally, the identity is exact for the full view:

\[
 \operatorname{TV}\!\left(\nu_{(t,u,b)\mid C},\nu_{(t,u,b)}\right)
 =\frac{1}{2\gamma}\mathbb E_b\lvert w(b)-\gamma\rvert.
 \tag{LTP6}
\]

If the cross-cluster synchronization lemma has base-to-cross transfer error
\(\xi_{ij}\), then (LTP5) gives the explicit replacement

\[
 \xi_{ij}\le \eta_{ij}/2,
 \qquad
 \rho^{\mathrm{base}}_{ij}
 \le \eta_{ij}/2+
 \frac{\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j}
      {\gamma_{ij}}.
 \tag{LTP7}
\]

Hence the existing cross-word synchronization condition closes whenever the right-hand
side of (LTP7) is \(<\Delta-2\eta_{\rm word}\).

### Proof

By (LTP2), conditioning on \(C\) only reweights the \(b\)-marginal. Therefore

\[
 \nu_{(t,u,b)\mid C}(t,u,b)
 =\frac{w(b)}{\gamma}\nu_{(t,u,b)}(t,u,b),
\]

Taking the \(L_1\) distance gives (LTP6), and (LTP4) gives the full-view bound in
(LTP5). The \((t,u)\)-only distance is no larger by data processing, so it also obeys
(LTP5). Substitution into the already proved cross-cluster transfer inequality yields
(LTP7). No spectral estimate is used in this step.

## 3. The actual latent-\(U\) quantity

For the natural factorized event

\[
 C_{ij}=\{a_0\in U_i,\ a_1\in U_j\},
\]

write

\[
 p_i(U,b)=\Pr[a_0\in U_i\mid U,b],
 \qquad
 p_j(U,b)=\Pr[a_1\in U_j\mid U,b].
 \tag{LTP8}
\]

Conditional independence of \(a_0,a_1\) given \((U,b)\) gives

\[
 w_{ij}(b)=\mathbb E_{U\mid b}\!\left[p_i(U,b)p_j(U,b)\right],
 \qquad
 \gamma_{ij}=\mathbb E_b w_{ij}(b).
 \tag{LTP9}
\]

Let

\[
 \bar p_i(b)=\mathbb E_{U\mid b}p_i(U,b),
 \qquad
 c_{ij}(b)=\operatorname{Cov}_{U\mid b}\!\left(p_i(U,b),p_j(U,b)\right).
 \tag{LTP10}
\]

Then

\[
 w_{ij}(b)=\bar p_i(b)\bar p_j(b)+c_{ij}(b).
 \tag{LTP11}
\]

This yields a useful two-input sufficient profile. Suppose, for some \(\eta_{\rm marg}\ge0\)
and \(\kappa\in[0,1)\),

\[
 \mathbb E_b\left|\bar p_i(b)\bar p_j(b)-\bar\gamma_{ij}\right|
 \le \eta_{\rm marg}\bar\gamma_{ij},
 \qquad
 \mathbb E_b|c_{ij}(b)|\le \kappa\bar\gamma_{ij},
 \tag{LTP12}
\]

where \(\bar\gamma_{ij}=\mathbb E_b[\bar p_i(b)\bar p_j(b)]\). Since
\(\gamma_{ij}\ge(1-\kappa)\bar\gamma_{ij}\),

\[
 \operatorname{TV}\!\left(\nu_{(t,u,b)\mid C_{ij}},\nu_{(t,u,b)}\right)
 \le
 \frac{\eta_{\rm marg}+2\kappa}{2(1-\kappa)}.
 \tag{LTP13}
\]

The first term is the marginal \(b\)-profile targeted by BMVY-type incidence estimates;
the second term is the latent-top covariance cost. Thus a BMVY one-face profile can be
used here only after a separate bound on \(c_{ij}\).

### Proof of (LTP13)

From (LTP11), with \(\bar c=\mathbb E_b c_{ij}(b)\),

\[
 \begin{aligned}
 \mathbb E_b|w_{ij}-\gamma_{ij}|
 &\le
 \mathbb E_b|\bar p_i\bar p_j-\bar\gamma_{ij}|
 +\mathbb E_b|c_{ij}-\bar c|\\
 &\le (\eta_{\rm marg}+2\kappa)\bar\gamma_{ij}.
 \end{aligned}
\]

Also \(\gamma_{ij}=\bar\gamma_{ij}+\bar c\ge(1-\kappa)\bar\gamma_{ij}\). Apply
(LTP6).

## 4. Why the covariance term is necessary

The following finite model has perfectly flat one-face profiles but maximal latent
covariance. Let \(b,U,t\) be independent uniform bits. Conditional on \((U,b)\), let
\(a_0,a_1\) be independent and choose the events \(E_0=\{a_0\in U_0\}\),
\(E_1=\{a_1\in U_1\}\) so that

\[
 \Pr[E_0\mid U,b]=\mathbf 1_{\{U=0\}},
 \qquad
 \Pr[E_1\mid U,b]=
 \begin{cases}
 \mathbf 1_{\{U=0\}},&b=0,\\
 \mathbf 1_{\{U=1\}},&b=1.
 \end{cases}
 \tag{LTP14}
\]

Then \(\bar p_0(b)=\bar p_1(b)=1/2\) for every \(b\), so the marginal profile has
zero variance. Nevertheless

\[
 w_{01}(0)=1/2,\qquad w_{01}(1)=0,\qquad
 \gamma_{01}=1/4,
\]

and \(C_{01}=E_0\cap E_1\) forces \(b=0\). Therefore the total variation in (LTP6)
is exactly \(1/2\) for the full view \((t,b)\) (take \(u=b\) in this finite decoder-side
model). Here \(c_{01}(b)=1/4\) for \(b=0\) and \(-1/4\) for \(b=1\), so the missing
covariance term is visible and quantitatively necessary. For a general vertex-valued
\(u\), the same calculation is an upper-bound witness for the full view; whether the
\((t,u)\)-marginal also moves is precisely the separate \(u\)-incidence question already
present in the cross-cluster transfer criterion.

## 5. What this closes, and what it does not

The GMWZ Section 6.1 sampling order and Lemma 6.3 conditional independence provide
(LTP1) for the shared-top sampler. Thus the correct source-specific positive target is
not “make the event independent of latent \(U\)”; it is to prove (LTP4), or the more
structural pair of estimates (LTP12), for the actual computation-generated clusters.
The published agnosticity definition only controls the \(a\)-marginal after fixing
\(t,b\), and the BMVY one-face profile controls \(\bar p_i\); neither statement controls
\(c_{ij}\) or \(w_{ij}\).

If (LTP4) is proved with a parameter small enough for (LTP7), the right-face
\(\xi_{ij}\)-gate in the RW/GMWZ cross-cluster synchronization criterion is closed. This
is a genuine positive Closure component, not a new generic impossibility claim. It still
does not provide the Gate-I address-scale evaluator or the bottom/cover/descriptor parts
of the RW Succinct Smart Reconstruction Theorem.

## Sources and scope

The sampler and agnosticity definitions are GMWZ Definitions 3.4--3.5; the shared-top
construction is in Section 6.1 and the conditional independence used in Lemma 6.3 of
[Gur--Minzer--Weissenberg--Zheng](https://arxiv.org/html/2512.12960#S6.1). The one-face
incidence profile used for the marginal term is the BMVY \(X(K)\to X(s)\) profile and its
endpoint estimate in [Bafna--Minzer--Vyas](https://arxiv.org/html/2407.12762). Those
sources do not state (LTP4) or (LTP12) for the computation-generated cross event; proving
that estimate remains the source-specific theorem target.
