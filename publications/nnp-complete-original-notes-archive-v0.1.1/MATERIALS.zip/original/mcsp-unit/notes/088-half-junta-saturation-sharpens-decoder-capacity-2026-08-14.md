> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Half-junta saturation sharpens decoder capacity（2026-08-14）

## 结论

令 \(m\ge2\)，并设

\[
m=\log_2(2q),
\qquad q=2^{m-1},
\tag{1}
\]

并记

\[
\mathcal C_{m,s}
=\{TT(C):C\text{ 是 size-}\le s\text{ 的 }m\text{-variable circuit}\}.
\tag{2}
\]

[note 086](086-near-linear-covering-decoder-must-be-nonlinear-and-nonsystematic-2026-08-14.md)
只用 counting 得到

\[
\mathcal C_{m,s}\subseteq\operatorname{Range}(G_q)
\quad\Longrightarrow\quad
q=\Omega(s\log s).
\tag{3}
\]

本 note 确定式 (3) 的 sharp Lupanov-scale endpoint。设 \(L(r)\) 是所有 \(r\)-variable Boolean
functions 的最大 circuit complexity。若

\[
s\ge L(m-1),
\tag{4}
\]

则不存在任何 map

\[
G_q:\{0,1\}^q\to\{0,1\}^{2q}
\tag{5}
\]

满足 \(\mathcal C_{m,s}\subseteq\operatorname{Range}(G_q)\)。特别地，由 Lupanov upper bound，

\[
L(m-1)
\le
(1+\alpha_{m-1})\frac{q}{m-1},
\qquad
\alpha_r=O(\log r/r),
\tag{6}
\]

所以 coverage 必须满足严格 endpoint 条件

\[
\boxed{
s<(1+\alpha_{\log_2q})\frac{q}{\log_2q}.
}
\tag{7}
\]

其中 \(\alpha_{\log_2q}=O(\log\log q/\log q)\) 来自已核验的 Lupanov upper bound；式 (4)--(5) 的
矛盾本身是精确有限参数 cardinality argument。

该结论排除所有 decoders：systematic、affine、nonlinear、non-systematic、uniform 或 nonuniform
都不例外。near-linear syntax 与 normalized inverse 在这个 endpoint 上已经无关。

另一方面，式 (7) 不排除

\[
s=\frac{q}{\log^{1+\varepsilon}q}
\tag{8}
\]

或 sufficiently-small constant multiple of \(q/\log q\)。所以它 sharpen 但没有关闭 note 087 的
global-decompression frontier。本文没有证明 \(P\ne NP\)。

## 饱和 family

固定最后一个变量 \(x_m\)，考虑 half-junta family

\[
\mathcal H_m
=
\{f:\{0,1\}^m\to\{0,1\}:f(x_1,\ldots,x_m)
=h(x_1,\ldots,x_{m-1})\}.
\tag{9}
\]

每个 \((m-1)\)-variable truth table 唯一确定一个 \(f\in\mathcal H_m\)，故

\[
|\mathcal H_m|
=2^{2^{m-1}}
=2^q.
\tag{10}
\]

若式 (4) 成立，则每个 \(h\) 都有 size 至多 \(s\) 的 circuit；把同一 circuit 视为忽略 \(x_m\) 的
\(m\)-variable circuit，得到

\[
\mathcal H_m\subseteq\mathcal C_{m,s}.
\tag{11}
\]

但 input projection

\[
g(x_1,\ldots,x_m)=x_m
\tag{12}
\]

有 constant circuit complexity，并且 \(g\notin\mathcal H_m\)。因此

\[
|\mathcal C_{m,s}|
\ge |\mathcal H_m|+1
=2^q+1.
\tag{13}
\]

任意 \(q\)-bit-input map 只有

\[
|\operatorname{Range}(G_q)|\le2^q,
\tag{14}
\]

式 (13)--(14) 即与 coverage 矛盾。

## 为什么这比“全部 truth tables”更强

若要求 \(\mathcal C_{m,s}\) 已包含全部 \(m\)-variable functions，Lupanov threshold 是

\[
\left(1+o(1)\right)\frac{2^m}{m}
=
\left(2+o(1)\right)\frac{q}{\log q}.
\tag{15}
\]

half-junta saturation 只需全部 \((m-1)\)-variable functions，再加一个 outsider，故把矛盾 threshold
降到

\[
\left(1+o(1)\right)\frac{q}{\log q}.
\tag{16}
\]

factor \(2\) 的改进来自 exact range capacity，而不是更强 circuit lower bound。

在把 \(x_m\) 作为 truth-table ordering 的 most-significant coordinate 后，最简单的 decoder

\[
G_q(u)=u\Vert u
\tag{17}
\]

恰好覆盖 \(\mathcal H_m\)；其他固定 ordering 只差一个 output-coordinate permutation。该 map 以
\(2^q\) 个 outputs 饱和全部 codes，无法再容纳 \(x_m\)。这也说明
note 086 的 systematic collision 不是偶然：在饱和点上，甚至任意重新编码都没有额外 output slot。

## 对当前参数窗口的影响

若 JK 所需 coverage scale 为 \(s_\star(n)\)，则任何 surviving stretch map 必须满足

\[
s_\star(n)<L(m-1)
\le
(1+\alpha_{\log_2q})\frac{q}{\log_2q}.
\tag{18}
\]

所以候选参数不能只满足粗略

\[
q=\Omega(s_\star\log s_\star);
\]

在临界尺度还必须保留 leading-constant slack。特别地，若某一步要求的 \(s_\star\) 达到或超过
式 (7) 的显式 RHS，该 branch 已由 pure cardinality 排除，无需继续搜索 decoder construction。

两个稳妥而仍开放的 subwindows 是

\[
\boxed{
s_\star\le(1-\delta)\frac{q}{\log q}
\quad\text{或}\quad
s_\star=\frac{q}{\log^{1+\Omega(1)}q},
}
\tag{19}
\]

以及在其中寻找 note 087 的 global representation/decompression 与 actual-history normalization。

### 文献边界

检索与原文核验截止：2026-08-14。

- Stasys Jukna, *Boolean Function Complexity: Advances and Frontiers*, 2012 author-posted draft,
  Theorem 1.15：
  \[
  L(r)\le(1+\alpha_r)\frac{2^r}{r},
  \qquad
  \alpha_r=O(\log r/r).
  \]

式 (4)--(5)、(9)--(19) 是本项目的 exact saturation argument。
