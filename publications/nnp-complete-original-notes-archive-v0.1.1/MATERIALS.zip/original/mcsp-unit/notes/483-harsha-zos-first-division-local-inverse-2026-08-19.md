> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha ZoS first-division local inverse (2026-08-19)

## 改变的判断

Harsha 的 honest zero-on-subcube bundle 并非只给 \(P=p(q)\) 的全局一致性证明。
第一条 division identity 已经逐点给出从 \(\Pi_{\mathrm{ZoS}}\) 到 \(P\) 的常数
component 局部逆：

\[
  P(x)=g_H(x_1)Q_1(x)+P_1(x).
  \tag{483.1}
\]

因此，只要同一 canonical proof 提供 \(\Pi_{\mathrm{ZoS}}\) 的 exact
arbitrary-point field-symbol access，“只暴露 \(\Pi_{\mathrm{ZoS}}\)”就不是独立于
\(P\)-access 的新 Closure 分支。再加 C439/C457 的 constraint-extension evaluator
与 nondegenerate incidence，即可恢复 systematic \(q(u)\)。真正仍开放的是
binary/ECC-only access、random-line-only access，或 arbitrary near proof 上缺失
target-wise exact DivisionCheck 的情形。

## Source identity

令

\[
  D=3m+3,\qquad
  P_0=P=p(q):F^D\to F.
  \tag{483.2}
\]

对 \(H\subseteq F\)，定义公开消失多项式

\[
  g_H(T)=\prod_{h\in H}(T-h).
  \tag{483.3}
\]

Harsha §5.3.2 的逐变量 division chain 为

\[
  P_{i-1}(x)
  =
  g_H(x_i)Q_i(x)+P_i(x),
  \qquad 1\le i\le D.
  \tag{483.4}
\]

honest bundled oracle 的 component order 是

\[
  \Pi_{\mathrm{ZoS}}(x)
  =
  \bigl(
    P_1(x),\ldots,P_D(x),
    Q_1(x),\ldots,Q_D(x)
  \bigr)
  \in F^{2D}.
  \tag{483.5}
\]

在 \(i=1\) 代入 (483.4) 即得 (483.1)。所需 components 恰为

\[
  1,\qquad D+1.
  \tag{483.6}
\]

## 定理 483.1（ZoS-to-\(P\) exact local inverse）

设 \(E_{\mathrm{ZoS}}\) 对每个指定 \(x\in F^D\) exact 返回同一个 canonical
\(\Pi_{\mathrm{ZoS}}(x)\)，或允许 exact 读取 (483.6) 的两个 field components。
则存在 exact \(P\)-evaluator

\[
  E_P(x)
  =
  g_H(x_1)\,
  E_{\mathrm{ZoS}}(x)[D+1]
  +
  E_{\mathrm{ZoS}}(x)[1].
  \tag{483.7}
\]

若一次 block read 返回整个 \(F^{2D}\) symbol，则每次 \(P\)-evaluation 只需一次
ZoS block read；若接口按 flattened field components 访问，则只需两次 reads。
直接计算 \(g_H(x_1)\) 使用

\[
  |H|\text{ 次 field subtraction}
  +( |H|-1 )\text{ 次 multiplication},
  \tag{483.8}
\]

随后再用一次 multiplication 与一次 addition。若 \(\mu_F\) 是一个 field operation
的 Boolean circuit cost，则

\[
  s_P
  \le
  \begin{cases}
    s_{\rm block}+O(|H|\mu_F),&\text{bundled block access},\\
    2s_{\rm comp}+O(|H|\mu_F),&\text{component access}.
  \end{cases}
  \tag{483.9}
\]

该局部逆不使用插值、除法或额外 field-size 假设。

### 证明

从同一 \(x\) 读取 \(P_1(x)\) 与 \(Q_1(x)\)，公开计算 (483.3)，再应用
(483.1)。operation count 与 (483.9) 立即成立。证毕。

## 推论 483.2（canonical ZoS map 对 \(P\) 无 kernel）

若两份 exact division-valid bundles
\(\Pi_{\mathrm{ZoS}},\Pi'_{\mathrm{ZoS}}\) 作为 \(F^D\to F^{2D}\) 的函数相同，
则其 \(P_1,Q_1\) 逐点相同；由 (483.1)，

\[
  P=P'.
  \tag{483.10}
\]

特别地，不存在 honest same-\(\Pi_{\mathrm{ZoS}}\)/different-\(P\) completion。
canonical polynomial quotient 与 remainder 的唯一性给出同一结论，但 (483.1)
已经足够。

## 推论 483.3（ZoS-to-systematic conditional inversion）

再假设 C439/C457 的 source interface：

1. 对每个 target \(u\)，可在 address scale 生成 incidence pair
   \((v_u,w_u)\)；
2. \(\widehat C(u,v_u,w_u,Y_1,Y_2,Y_3)\not\equiv0\)；
3. 同一 serialization 有 \(\widehat C\) 的 exact field evaluator；
4.
   \[
     |F|>\deg(\widehat C)+2,
     \qquad
     \deg(\widehat C)\le D|H|.
     \tag{483.11}
   \]

则 C439 的 \(O(|F|^3)\)-point enumeration 中，每次 \(P\)-query 可由 (483.7)
替换，得到 exact target evaluator

\[
  E_q(u)=q(u)
  \tag{483.12}
\]

并满足

\[
  s_q
  \le
  O(|F|^3)
  \left(
    s_{\mathrm{ZoS}}
    +s_{\widehat C}
    +\operatorname{poly}(D,|H|,\log|F|)
  \right).
  \tag{483.13}
\]

这里 \(s_{\mathrm{ZoS}}\) 按 block model 计一次 read，按 component model 计两次
reads。若 target set 包含 C454/C456 对齐的 published RW output coordinates，则
C455 forcing 继续强制 (483.13) 的右侧达到
\(\Omega(N/\log N)\)。

## Staticization trichotomy

对 \(\Pi_{\mathrm{ZoS}}\) 分支，Closure 候选必须落入：

\[
  \boxed{
  \begin{array}{ll}
  \text{exact arbitrary-point canonical access}
    &\Longrightarrow P\text{-access by (483.7), then C439/C457};\\
  \text{explicit full oracle table}
    &\Longrightarrow \text{C447 object-scale proof length};\\
  \text{否则}
    &\Longrightarrow \text{decoder/binding/access model exit}.
  \end{array}}
  \tag{483.14}
\]

第一行消除了“exact \(\Pi_{\mathrm{ZoS}}\)-access 但没有 \(P\)-access”的假想分支。

## 量词与 serialization 边界

* **Honest/exact domain.** (483.7) 适用于 canonical honest division bundle，或任何
  在指定点 exact 满足第一条 (483.4) 的 bundle。Harsha soundness 对 arbitrary
  auxiliary oracle 的随机-line rejection 不推出每个预定 \(x\) 上
  \(P_0(x)=g_H(x_1)Q_1(x)+P_1(x)\)。对 arbitrary \(\Pi\)，右侧只定义一个
  induced \(\widehat P_0\)，不自动绑定 verifier 的 input \(P_0\)。
* **Binary/ECC-only domain.** 若 physical proof 只暴露未指定坐标语义的 binary encoding
  或 ECC image，
  还需从同一 canonical block exact 恢复 components \(1,D+1\) 的 decoder 与
  word-consistency；C485 对 C398/component-major raw-binary branch 给出该恢复，而
  朴素读取至少涉及两个 \(\lceil\log_2|F|\rceil\)-bit symbols。
* **Random-line access.** ordinary verifier 在随机 line 上读取 bundle，不等于对任意
  指定 \(x\) 的 address evaluator；若预定 \(x\) 不在该 line 上，(483.7) 没有输入。
* **Constraint/incidence.** ZoS-to-\(P\) 局部逆是无条件 source identity；继续
  \(P\to q\) 仍需 (483.11)、\(\widehat C\)-access 与 nondegenerate incidence。

因此本结果修正的是 C389/C439/C440 留下的 exact-ZoS source branch，不把
arbitrary-proof soundness 升级为 target-wise recovery，也不证明 published RW 已有
address-scale ZoS evaluator。

## 来源

* Prahladh Harsha, *Robust PCPs of Proximity and Shorter PCPs*, §5.3.2,
  equations (5.1), (5.4), and the bundled oracle definition on pp. 67--70:
  <https:/[unbundled local reference].ttic.edu/~prahladh/papers/thesis/phdthesis.pdf>。
* [C457：Harsha \(q\)--\(p(q)\) generic-access equivalence](457-harsha-q-p-generic-access-equivalence-2026-08-19.md)。
* [C439：Harsha auxiliary-to-systematic inversion gate](439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md)。
* [C440：constraint-extension source-interface barrier](440-harsha-constraint-extension-source-interface-barrier-2026-08-19.md)。
* [C389：actual auxiliary factorization boundary](389-harsha-auxiliary-factorization-no-local-inverse-2026-08-18.md)。
