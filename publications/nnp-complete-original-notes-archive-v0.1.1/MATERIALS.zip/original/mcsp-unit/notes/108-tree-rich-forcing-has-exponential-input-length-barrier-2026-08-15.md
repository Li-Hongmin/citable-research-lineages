> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Tree-rich forcing 的显式输入长度障碍（2026-08-15）

## 结论

note 107 把多层容量障碍嵌入了一个真实 RW systematic-prefix history，但该构造本身有
不可忽略的时间尺度：

\[
\boxed{
\text{只用枚举所有 }A^{2^h}\text{ leaf tuples 的 tree-rich forcing，}
\quad |\Pi_x|\ge 2^{\Omega(q)}.
}
\]

因此即使假设 \(P=NP\) 消除 JK 的 NP oracle，Theorem 3.1 的显式输入算法仍只得到
\(\operatorname{poly}(|\Pi_x|)\) 时间；这不是关于 \(q\) 的 polynomial-time hard-table
generator，不能直接推出 \(P\ne NP\)。

## 长度下界

设 \(A\subseteq R_q\)，并设

\[
K=|A|^{2^h}>2^q.
\]

为了让一条连续 systematic prefix 包含每个 \(2^h\)-leaf tuple，至少需要 \(K\) 个
groups；每个 group 含 \(2^h\) 个 \(2q\)-bit blocks。因此输出 prefix 长度满足

\[
T_0\ge 2q\cdot 2^h\cdot K
>2q\cdot 2^{h+q}.
\tag{1}
\]

在 Lupanov family 的典型参数中，若

\[
\log_2|A|=\Theta(s\log s),
\qquad
2^h s\log s=\Theta(q),
\]

则

\[
\log_2K=2^h\log_2|A|=\Theta(q),
\qquad
T_0^{\min}=2^{\Theta(q)}.
\tag{2}
\]

这不是 PCP auxiliary suffix 的产物；只要想在 systematic prefix 中逐一放入所有 leaf
tuples，式 (1) 已经成立；因此任何此类显式枚举都满足
\(T_0\ge 2^{\Theta(q)}\)（取最小 padding 时达到该阶）。

## 与 JK 运行时间的关系

Ren--Williams Theorem 3.1 的输入是显式 truth table \(f\in\{0,1\}^T\)，运行时间为

\[
\operatorname{poly}(T,|G|),
\]

并逐 stage 读取其 \(2q\)-bit blocks。对 note 107 的 \(r=0\) machine，\(T\) 至少为
\(T_0\)。在 \(P=NP\) 假设下，SAT queries 可以被确定化，但得到的 outsider 仍只保证在

\[
\operatorname{poly}(T_0,|G_q|)
=2^{O(q)}
\]

（或更大的 explicit-polynomial 尺度）内生成，而不是 \(\operatorname{poly}(q)\) 内生成。
将它看成长度 \(2q\) 的 truth table 时，这个算法不提供 P-uniform circuit family。

若令 \(q=2^{m-1}\) 是 decoder 的 block parameter，则 \(T_0=2^{\Theta(2^m)}\)；而
\(P\)-uniformity 针对的是 \(m\) 或 \(\log(2q)\) 的输入长度，二者相差一个指数层。

## 不能用 succinct output 偷换输入模型

把 tree-rich prefix 改成一个短程序、让 JK 按需生成第 \(j\) 个 block，会改变 Theorem 3.1
的输入模型：原定理接收显式 \(f\)，而不是一个 random-access generator。要得到
\(\operatorname{poly}(q)\)-time forcing，必须另证一个 compressed-JK theorem，至少同时提供：

1. 对 implicit \(f\) 的 range queries；
2. 对所有 stages 的 word-consistent preimage selection；
3. 在不展开 \(2^{\Omega(q)}\) 个 groups 的情况下，找到一个 non-image block。

这正是当前 range/search magnification 的核心缺口，不能把程序的短描述长度当成 explicit
truth-table input length 已经缩短。

## 路线裁决

当前 concrete-history 结果分成两层：

\[
\begin{array}{c|c}
\text{结果} & \text{证据尺度}\\ \hline
\text{覆盖 + systematic prefix 可强制某条 history 出 outsider}
  & \text{真实 RW/JK 结构，成立}\\
\text{同一结论给出 }P\text{-uniform hard table}
  & \text{需要压缩输入模型，尚未证明}\\
\text{由此推出 }P\ne NP
  & \text{仍无}
\end{array}
\]

note 109 已在一个明确的 random-access tuple 模型中给出受限的
\(\mathrm{FP}^{\Sigma_2^P}\) succinct forcing：当 \(h=O(\log q)\) 时，可以不枚举
\(2^{\Omega(q)}\) 个 groups；但这仍以 \(q\) 为参数，且在 \(P=NP\) 下才降为多项式。
真正改变 P-vs-NP 决策的后续问题因此收窄为：Ren--Williams 的实际 PCP/systematic
history 是否具有同样的 random-access、word-consistent 接口，并能进一步压到地址长度
\(m=\log(2q)\) 的多项式时间；否则仍需证明相应的 compressed-JK lower bound。
该受限构造不等于固定 NP/PH 语言中的 hard table，也不自动给出
\(P\ne NP\)。

### 来源与证据边界

- Ren--Williams, Theorem 3.1：显式 \(f\) 输入与 \(\operatorname{poly}(T,|G|)\) 时间。
- note 106/107：tree-capacity injectivity 与 systematic-prefix forcing。
- note 109：random-access tuple forcing 的 \(\mathrm{FP}^{\Sigma_2^P}\) 接口。

式 (1)--(2) 是直接长度记账；本文不把它升级为一般 compressed-JK 不可能性定理，也不
宣称 \(P\ne NP\)。
