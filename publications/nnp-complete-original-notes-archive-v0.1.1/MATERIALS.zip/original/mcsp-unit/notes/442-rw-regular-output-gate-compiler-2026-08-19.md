> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW 零轮 regular output-gate compiler（2026-08-19）

## 本轮改变的判断

C441 把 Gate III 写成了一个带有 output-gate pattern 的 layout 加 \(\widehat C\) evaluator。
需要先区分一个语义陷阱：规则化 equality gate 的局部关系只比较 `out_j` 与模拟线
\(v_j\)，并不把实际值 \(B_j=M(x_0)_j\) 直接写进 gate relation。因而 C442 能够
消除的是 C439 所需的 nonzero incidence/layout 缺口，而不是让 \(\widehat C\) 单独读出
parent bit。在 \(P=NP\) deterministic recompilation 的 \(r=s=0\) 分支，可以把
Lemma 3.2 的 \(C_x\) 重新编译成一个保持 history-prefix 的标准 fan-in-two circuit，
并在末尾放置规则化的 output/equality gates。该编译器不需要知道 hard parent 的
bit 值；它只需要把模拟 machine 的输出线与 `out_j` 变量相等地连接。

因此，在这个 source-compatible representation 下，C439 的 incidence/layout 条件
可以实际 discharge；remaining Gate-I/III 缺口仍是同一 proof 上的 \(P\)-evaluator、
Harsha \(\widehat C\) 在 generic field points 上的 address-scale 求值，以及 proof
serialization 的同一性。C441 的更强“单独由 output pattern 读出 \(B_j\)”接口只有在
output gate 真正 hardwire 了 \(B_j\) 时才成立，而标准模拟编译器并不提供这一点。

## 定理 442.1（regular output-gate compiler）

令 \(M\) 是 \(P=NP\) 分支中固定 context \(x_0\) 上的 deterministic machine，运行时间
至多 \(t\)，输出 \(\ell\) bits。假设使用标准固定 fan-in gate basis，并允许在 circuit
中预留 history variables 作为最前面的 input variables。则存在一个与 Lemma 3.2
语义等价的 circuit \(C^{\mathrm{reg}}_{x_0}\)，满足：

1. 前 \(\ell\) 个 input variables 是 `out_1,\ldots,out_\ell`；
2. 后续 subcircuit 是 \(M(x_0)\) 的标准时间展开，产生 simulation-output wires
   \(v_1,\ldots,v_\ell\)；
3. 对每个 \(j\)，有一个专用 equality gate \(e_j\) 检查
   \(\mathrm{out}_j=v_j\)，所有 \(e_j\) 连续排列，并接入一个固定 balanced-AND
   reduction，其输出是 \(C^{\mathrm{reg}}_{x_0}\) 的输出；
4. 给定 \(j\)，在 \(\operatorname{poly}(\log t,\ell)\) 时间可以生成 \(e_j\) 的三个
   variable indices，以及 Harsha \(C'\) 所需的两种 Boolean pattern；这些 indices
   在固定 \(H^m\simeq[N]\) 编码下也能在同样尺度转换成 field coordinates。

这里的 \(C^{\mathrm{reg}}_{x_0}\) 与原 \(C_{x_0}\) 在 history variables 上的可满足赋值
完全相同；增加的 compiler variables 位于 history prefix 之后。因此其 lexicographically
largest satisfying assignment 的 `out` prefix 仍是 \(M(x_0)\) 的输出。

### 证明

先把 \(M\) 在固定输入 \(x_0\) 上的至多 \(t\) 步 computation 用标准 fan-in-two
unrolling 编译成 circuit \(S\)。若某个 machine output bit 由多个末端 wires
表示，先用固定大小的 fan-in-two tree 汇合；记得到的 wires 为 \(v_1,\ldots,v_\ell\)。
把 `out_1,\ldots,out_\ell` 作为 circuit 的前 \(\ell\) 个 input variables，并在
\(S\) 之后按 \(j=1,\ldots,\ell\) 追加 equality gate \(e_j\)；三输入 Harsha gate
schema 可用一个固定 constant/duplicate slot 把二输入 equality 嵌入，故每个 gate
只引入 \(O(1)\) 个固定 pattern。最后追加一个 balanced-AND tree，计算
\(\bigwedge_{j=1}^{\ell}e_j\)，并把它作为 circuit output。

对任意 `out` assignment，\(S\) 的末端值唯一确定；AND reduction 输出 1 当且仅当
所有 equality gates 同时满足，也即 \(\mathrm{out}=M(x_0)\)。所以 \(C^{\mathrm{reg}}_{x_0}\) 的 history
projection 与 Lemma 3.2 中 \(C_{x_0}\) 相同。由于 auxiliary compiler variables
排在 history variables 之后，lexicographic maximization 先决定同一个 `out` prefix，
不会被后缀变量改变。

令 \(s_S(t)\) 为标准 unrolling 的 gate count。\(e_j\) 的 variable indices 是
\(j\)、\(s_S(t)+j\) 与固定 padding/constant indices 的组合；若需要将 output wire
通过固定 fan-in tree 汇合，只需把该 tree 的末端偏移写入同一规则。\(s_S(t)\) 与
这些偏移由 machine code、\(t\) 和固定 compiler 在 \(\operatorname{poly}(\log t)\)
时间内计算。把一个 index 写成 \(H^m\simeq[N]\) 的 base-\(|H|\) digits 需要
\(O(m\log|H|)\) 时间，仍是 \(\operatorname{poly}(\log t)\)。因此 \(e_j\) 的 gate
tuple 与两种 invalid patterns 都可按地址生成。证毕。

## 对 C439/C441 的精确推论

将 \(C^{\mathrm{reg}}_{x_0}\) 代入 Harsha Proposition 5.4.1，output/equality
gate 的 \(C'\)-coordinates 由定理 442.1 的 address-scale map 给出。对每个 output
coordinate \(u_j\)，取 equality gate 中的 output variable、simulation wire 和固定
constant/duplicate slot，得到 C439 所需的 pair \((v_{u_j},w_{u_j})\)；该 gate 的
非法配置保证相应的 \(\widehat C\)-slice 不是零多项式。这一步不需要知道 \(B_j\)。

若另有一个不含 message-scale advice 的 generic-point evaluator

\[
 \mathsf E_{\widehat C}(a)
 =\widehat C(a),
 \qquad
 \operatorname{size}(\mathsf E_{\widehat C})=\operatorname{poly}(m),
\]

并且同一 serialization 上有 C439 所需的 \(P=p(q)\) field-symbol evaluator，则 C439
反演直接恢复 \(q(u_j)\)，再得到 \(B_j\)。换言之，actual RW closure 的剩余正攻
已经不是“找 output incidence”，而是证明以下同一 proof 上的两个 evaluator：

> 对 \(C^{\mathrm{reg}}_{x_0}\) 的 Harsha gate relation，低度延拓 \(\widehat C\) 与
> auxiliary \(P=p(q)\) 在同一 serialization 上都有按 \(m=\log|B|\) 运行的 exact evaluator。

若这些 evaluator 只能通过完整 gate-list scan 得到，C440 的 object-scale barrier
适用；若它们存在且描述不含 message-scale advice，C439 才给出最终 \(P/\mathrm{poly}\)
矛盾。单独的 equality-gate layout 不触发 C441，因为 \(v_j\) 的真实值仍由整个
simulation constraint system 决定。

## 证据边界

* 定理 442.1 是一个新的 source-representation/compiler lemma；RW Lemma 3.2 只声称
  存在 deterministic poly\((t)\) construction，并没有规定该 serialization。因而不能
  把本定理的规则化 layout 冒称为 published Theorem 3.5 的既有格式。
* 该编译器只保证 history projection、lexicographic output prefix 与 C439 的
  nonzero incidence；它不提供 \(\widehat C\) evaluator，也不解决 auxiliary \(P\) 段的
  random access，更不把 \(B_j\) 直接 hardwire 到 equality gate pattern。
* 机器代码、运行时间界和固定 fan-in basis 必须是 evaluator 的公开 source data；
  不允许把 \(B\) 或完整 computation history 作为隐藏 advice。
* 本定理不证明 \(P\ne NP\)，也不证明一般 dPCP/RLDC impossibility；它把 actual RW
  Gate-I/III 的未决接口从“layout + evaluator”收缩到单一 \(\widehat C\) evaluator。

## 来源

* Ren--Williams TR26-118 revision 1, Lemma 3.2 and Theorem 3.5；本地抽取：
  `units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md`。
* Harsha, *Robust PCPs of Proximity and Shorter PCPs*, §5.4.1,
  Proposition 5.4.1, equations (5.6)--(5.8)；本地抽取：`[unbundled local reference]`。
* [note 441](441-zero-round-output-gate-closure-2026-08-19.md)。
