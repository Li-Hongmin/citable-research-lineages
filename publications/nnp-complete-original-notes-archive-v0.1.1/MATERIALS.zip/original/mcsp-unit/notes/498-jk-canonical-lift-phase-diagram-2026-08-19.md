> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK canonical-lift phase diagram（2026-08-19）

## 本轮改变的判断

C497 把首失败 prefix barrier 压到了 \(\Gamma_d\)、\(\mathcal Z_d\) 和
\(\widehat{\mathcal Z}_d\) 的 generator-specific 数量。C498 给出这些数量之间的
精确基数恒等式，因而在给定 descriptor budget 后把下一步分成 no-outsider、budget-closed entropy、residual outsider 三支，而不是继续笼统寻找 selector。

C499 进一步证明逐 chunk canonical lift 在 \(\mathcal Z_d\) 上必然单射，因此本 note
原先保留的 lift-collision 余量为空；下文的相应陈述均应按 C499 的严格恒等式读取。

令
\[
s_d:=|\Gamma_d|,\qquad
z_d:=|\mathcal Z_d|,\qquad
o_d:=|\mathcal O_d|,\qquad
m_d:=|\widehat{\mathcal Z}_d|.
\]
则
\[
z_d=s_{d+1},\qquad o_d=s_d^2-s_{d+1},\qquad m_d=s_{d+1}.
\tag{498.1}
\]

因此对每个深度 \(d\)：

1. **No-outsider branch:** \(o_d=0\)，等价于 \(s_d^2=s_{d+1}\)。由于
   \(s_{d+1}\le|\operatorname{Range}(G)|\le2^n\)，必有 \(s_d\le2^{n/2}\)；
2. **Entropy branch:** C497 的 payment 达到候选 descriptor budget；具体定量判据见下方的 \(\Delta_{k,i}>Q_{k,i}\)；
3. **Residual outsider branch:** \(o_d>0\) 但 C497 的 payment 尚未超过候选
   descriptor budget。C499 排除了 lift-collision；因此这支若要继续，必须给出另一个
   被计价的 global relation、target-specific descriptor、bottom/cover 机制，或明确
   退出 canonical half-lift 模型。

这里的“大/小”必须相对于候选 Closure 接口的 descriptor budget 定义，而不是绝对
基数判断。对给定 \(k\ge i\ge2\)，令 \(d=k-i\)、\(m_i=2^{i-1}-1\)，并记允许的
二进制 side information 上限为 \(Q_{k,i}\)。C497 真正支付的是

\[
\Delta_{k,i}:=m_i\log_2 s_{d+1}.
\tag{498.9}
\]

当 \(o_d>0\) 且 \(\Delta_{k,i}>Q_{k,i}\) 时，熵分支才在该预算下闭合；若
\(\Delta_{k,i}\le Q_{k,i}\)，则只能进入剩余 outsider 分支。此时

\[
\kappa_d:=\log_2\frac{s_{d+1}}{m_d}=0
\tag{498.10}
\]

（当 \(\mathcal Z_d\ne\varnothing\) 时）。因此若
\(\Delta_{k,i}\le Q_{k,i}\)，只能记录为尚未由 C497 闭合的 residual outsider 分支，
不能把它解释成 lift-collision。

## 定理 498.1（canonical-lift phase diagram）

令 \(G\)、\(p\)、\(\Gamma_d\)、\(\mathcal Z_d\)、\(\mathcal O_d\) 和
\(\widehat{\mathcal Z}_d\) 如 C497。对每个 \(d\ge0\)，有：

\[
\boxed{|\mathcal Z_d|=|\Gamma_{d+1}|}
\tag{498.3}
\]
以及
\[
\boxed{|\mathcal O_d|=|\Gamma_d|^2-|\Gamma_{d+1}|}.
\tag{498.4}
\]

若 \(\widehat{\mathcal Z}_d\ne\varnothing\)，则 C499 给出
\[
\kappa_d=0,
\tag{498.5}
\]
并且 \(d\)-层 lift 在 \(\mathcal Z_d\) 上保持单射。

### 证明

定义
\[
\Phi_d:\Gamma_{d+1}\to\mathcal Z_d,\qquad
\Phi_d(u)=G(u).
\]
若 \(u\in\Gamma_{d+1}\)，则 \(u\in\Gamma_0\)，所以
\(G(p(G(u)))=G(u)\) 且 \(p(G(u))=u\)；同时 \(G(u)\) 的左右 halves
属于 \(\Gamma_d\)，故 \(\Phi_d(u)\in\mathcal Z_d\)。由于 \(p(G(u))=u\)，
\(\Phi_d\) 是单射。

反之，给定 \(z\in\mathcal Z_d\)，令 \(u=p(z)\)。则 \(u\in\Gamma_0\)，
\(G(u)=z\)，且 \(z\) 的左右 halves 在 \(\Gamma_d\) 中，所以
\(u\in\Gamma_{d+1}\)。因此 \(\Phi_d\) 双射，得到 (498.3)。

把所有 \(2n\)-bit strings whose halves lie in \(\Gamma_d\) 与
\(\Gamma_d\times\Gamma_d\) 识别。其在 \(R\) 中的部分正是 \(\mathcal Z_d\)，
其不在 \(R\) 中的部分正是 \(\mathcal O_d\)。用 (498.3) 即得
\[
|\mathcal O_d|=|\Gamma_d|^2-|\mathcal Z_d|
 =|\Gamma_d|^2-|\Gamma_{d+1}|,
\]
即 (498.4)。

最后，\(\widehat{\mathcal Z}_d\) 是 \(\mathcal Z_d\) 在 lift map 下的 image，
所以 \(m_d=z_d=s_{d+1}\)，且 \(\kappa_d=0\) 正好等价于
image size 等于 domain size，即 lift 在 \(\mathcal Z_d\) 上单射。证毕。

## 对 RW/JK Closure 的直接含义

C497 的 outsider 假设在深度 \(d\) 上等价于 \(o_d>0\)，也就是
\[
s_d^2>s_{d+1}.
\tag{498.6}
\]
所以对 published generator，实际可检验的 Gate-I/II 分解是：

* 若 \(s_d^2=s_{d+1}\)，该深度没有可被上层 canonical lift 隐藏的 outsider；
  同时 \(s_d\le2^{n/2}\)，只能走一个低-capacity image-specific route；
* 若 \(s_d^2>s_{d+1}\) 且 \(\Delta_{k,i}>Q_{k,i}\)，C497 的 prefix-fiber entropy 直接支付
  parent-binding descriptor；
* 若 \(s_d^2>s_{d+1}\) 但 \(\Delta_{k,i}\le Q_{k,i}\)，这是 residual outsider 分支；
  C499 已排除 lift-collision，剩余路线必须给出另一个在同一 proof、同一地址空间、
  同一长度集上被完整计价的 global relation，或明确退出 C497 模型。

这把“published truth-table generator 是否能逃逸 C496”压成有限的
\((s_d,s_{d+1},m_d)\) 结构问题。它不假设任意 truth-table encoding 的额外性质，
也不把某一支冒称为 \(P\ne NP\) 证明。

## 证据边界

* (498.3)--(498.5) 是 canonical selector 的集合论恒等式；不需要 \(G\) 在整个
  domain 上单射。
* C499 给出 \(\kappa_d=0\)；因此 residual outsider 不是 lift-image collision，仍需
  另行构造并完整计价的 global relation 或其它 Closure 机制。
* 该 phase diagram 仍是 source-specific/family-level；要接 C455 的 fixed
  published hard output，必须再证明 canonical PCP image 与同一 generator 对齐。

## 来源

* [C497](497-jk-canonical-liftable-range-projection-barrier-2026-08-19.md)：liftable
  prefix-fiber barrier。
* [C496](496-jk-all-stage-prefix-fiber-entropy-barrier-2026-08-19.md)：duplication
  generator 特例。
* [C493](493-jk-frontier-canonical-selector-correction-2026-08-19.md)：canonical
  right inverse。
* [C499](499-jk-canonical-lift-injectivity-eliminates-collision-branch-2026-08-19.md)：
  证明 lift 在 \(\mathcal Z_d\) 上单射并修正 collision 分支。
* Ren--Williams TR26-118 rev.1, Theorem 3.1。
