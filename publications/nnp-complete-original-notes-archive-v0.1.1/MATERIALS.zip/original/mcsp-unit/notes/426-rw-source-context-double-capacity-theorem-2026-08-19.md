> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW source-context double-capacity theorem（2026-08-19）

## 本轮改变的判断

C406 只给出“canonical proof 的总 entropy 不超过 public context”，C425 只给出
“recursive range-closure 的 root capacity 不超过 \(k\)”。把两者放到同一个
product-rich subtree 量词下，可以得到一个更直接的 Gate-I 定律：

> 同一个递归 leaf tuple family 的总信息量，必须同时小于 public context
> 容量和 JK generator 的 root-range 容量。若 public context 与 \(k\) 都是
> address-scale，而 subtree 深度增长，则不能同时保留独立 ECC payload、same-proof
> source generation 和 target-oblivious recursive closure。

这把“公开输入不能冒充 hidden family”与“递归 range capacity”合成一个单一不等式，
避免在 actual RW source 上分别重复使用两个 family barrier。

## Source-context 模型

令 \(\Theta\in\{0,1\}^{\nu}\) 是生成 canonical proof 的全部公开 context：
machine/input description、stage 参数、固定 selector、serialization metadata
等。假设 proof selector 是确定函数

\[
 \Pi_\Theta=\operatorname{Sel}(\Theta).
\tag{426.1}
\]

在 \(\Pi_\Theta\) 的一个 depth-\(d\) JK subtree 中，设 \(2^d\) 个 leaves 的值
families 为 \(\mathcal A_1,\ldots,\mathcal A_{2^d}\)。假设 source family
product-rich，即每个 tuple

\[
 (a_1,\ldots,a_{2^d})\in\prod_{\ell=1}^{2^d}\mathcal A_\ell
\tag{426.2}
\]

都由某个公开 context \(\Theta\) 实现为同一 source-compatible canonical proof。
因此 tuple 是 proof 的确定投影，而不是独立重选的 phantom response。

令 \(G_k:\{0,1\}^k\to\{0,1\}^{2k}\)，\(R_G=\operatorname{Range}(G_k)\)，并
固定 JK 的 canonical preimage \(p:R_G\to\{0,1\}^k\)。若所有 leaves 与递归内部
blocks 都是 non-output，并且 proposed closure 要求它们都在 \(R_G\)，则可以同时
应用 source-context counting 与 C402 的 recursive product closure。

## 定理 426.1（double-capacity inequality）

在上述模型中，令

\[
 M:=\prod_{\ell=1}^{2^d}|\mathcal A_\ell|.
\]

则

\[
 \boxed{\log_2 M\le \min\{\nu,k\}.}
\tag{426.3}
\]

### 证明

先证 public-context 上界。不同 leaf tuples 给出不同的
\((a_1,\ldots,a_{2^d})\)，而一个固定 context \(\Theta\) 的 canonical proof
只有一个 tuple 投影。因此实现所有 \(M\) 个 tuples 至少需要 \(M\) 个不同的
contexts。由于 context 长度为 \(\nu\)，

\[
 M\le 2^\nu.
\tag{426.4}
\]

再证 recursive-range 上界。对每个 recursive-good tuple，逐层应用 canonical
preimage \(p\) 把 leaves 合并到 root。因为 \(p\) 在 \(R_G\) 上 injective，
不同 leaf tuples 给出不同 root blocks。所有 root blocks 都在 \(R_G\)，故

\[
 M\le |R_G|\le2^k.
\tag{426.5}
\]

合并 (426.4) 与 (426.5)，得到 (426.3)。证毕。

## Product-ECC 特例

若 leaves 是 aligned product-ECC blocks，\(E_0:\mathbb F_2^a\to\mathbb F_2^b\)
的码率为 \(R=a/b\)，且 \(b\mid2k\)，令 \(q=2k/b\)。每个 leaf family 满足

\[
 |\mathcal A_\ell|=2^{qa}=2^{2Rk}.
\]

于是 (426.3) 化为

\[
 \boxed{2^{d+1}Rk\le \min\{\nu,k\}.}
\tag{426.6}
\]

这同时包含：

* C425 的 recursive depth--rate law：
  \(2^{d+1}Rk\le k\)，即 \(R\le2^{-(d+1)}\)；
* C406 的 public-input entropy gate：
  \(2^{d+1}Rk\le\nu\)，否则 public context 根本不足以实现该
  product-rich source family。

## RW address-scale 后果

设 proposed closure 的 public context 和 generator width 都满足
\(\nu,k=\operatorname{polylog}(N)\)，而 product-rich subtree 深度满足
\(2^d\to\infty\)。对任意固定 \(R\ge R_0>0\)，(426.6) 最终失败。更具体地：

1. 若 \(2^{d+1}Rk>\nu\)，则 actual source family 不可能实现所有独立 leaf
   tuples；必须发生 leaf-entropy collapse，或 context 携带未计账的
   message-scale 信息；
2. 若 \(2^{d+1}Rk>k\)，则即使 source family 能实现这些 tuples，也不可能让
   一个 target-independent \(G_k\) 对所有 recursive blocks 保持 in-range；
3. 若 proposed relation 仍声称两者同时成立，它必须退出 common canonical proof、
   target-independent range closure 或 non-output 量词，转而给出新的 global relation。

当 \(2^d\asymp L/k\) 时，(426.6) 要求

\[
 R=O\!\left(\frac{\min\{\nu,k\}}{L}\right).
\tag{426.7}
\]

对于 Harsha 的 \(b=O(a)\) binary conversion，码率有固定正下界；因此长
auxiliary/ECC 段不可能在 product-rich、深递归、address-scale 三个条件下同时
闭合。

## 对 actual RW 的精确边界

定理 426.1 不把 published \(x_0\) singleton 提升成 family。对 Theorem 4.3，
\(\Theta\) 固定后只有一个 canonical proof，故 \(\nu\)-capacity 只说明公开
family route 没有被免费隐藏；它不直接给出 singleton impossibility。

若把 \(x\) 作为 family 参数，则 \(\nu\) 必须包含 \(x\) 和所有公开 query/
machine metadata。若 \(x\) 携带 \(2^{d+1}Rk\) bits，它已经是 message-scale
descriptor，不是 address-scale closure。若 \(\nu\) 保持 address-scale，则
product-rich 假设在深度增长时必然失败，不能再用 C425 把 ambient ECC alphabet
冒充 actual hidden payload。

因此 actual RW/Harsha 的剩余正攻被压成三选一：

\[
\boxed{
\begin{array}{c}
\text{证明 actual proof image 的 leaf entropy 塌缩；}\\
\text{证明某些递归 leaves 已附着 systematic output；}\\
\text{构造不依赖共同 }G_k\text{ recursive range closure 的新 global relation。}
\end{array}}
\tag{426.8}
\]

这不是 \(P\ne NP\) 证明，也不是对所有 dPCP/ECC 的 impossibility theorem；它是
C406 与 C425 的统一 source-specific capacity gate。

## 上游与证据边界

* [C406](406-rw-public-input-family-route-closure-2026-08-18.md)：canonical
  proof 是 public context 的确定函数；
* [C425](425-product-ecc-recursive-depth-rate-law-2026-08-19.md)：product-ECC
  recursive depth--rate law；
* [C402](402-jk-recursive-range-closure-capacity-2026-08-18.md)：recursive
  canonical-preimage injectivity；
* C389：Harsha auxiliary factorization 仍是正向生成式，不自动给出 local inverse；
* RW Theorem 3.5/4.3：proof selector 与 published fixed-\(x_0\) singleton 的来源边界。
