> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Heavy-core incidence dichotomy for shared-proof robustness (2026-08-17)

## Contribution

Uniform proof-position marginals are convenient but stronger than necessary for the
shared-proof-to-RLDC reduction. This note gives a punctured version that handles arbitrary
incidence profiles. A proposed construction can avoid the ordinary RLDC reduction only by
placing a message-scale amount of information in a heavy proof core, or by losing the
global-word distance/radius/completeness needed by the reduction.

The statement is independent of the RW implementation. Its relevance is that a nonuniform
GMWZ-style marginal is no longer an unquantified escape parameter.

## Setup

Let

\[
  C:\{0,1\}^{k}\longrightarrow\Gamma^{M}
\]

be an injective code of relative distance at least \(\Delta>0\). Let a family-level
dPCP use one proof vertex set \(V\), proof alphabet \(\Sigma\), and for every output
coordinate \(t\in[M]\) a local edge distribution \(\mathcal P_t\) and decoder \(D_t\).
For every message \(m\), choose one perfect-completeness assignment
\(A_m\in\Sigma^V\) satisfying

\[
  D_t(A_m|_e)=C(m)_t
  \qquad(e\sim\mathcal P_t)\text{ almost surely}.
\tag{223.1}
\]

Let \(\mathcal Q\) sample \(t\) uniformly and then \(e\sim\mathcal P_t\), and define
the (possibly nonuniform) incidence profile

\[
  \mu_v:=\Pr_{(t,e)\sim\mathcal Q}[v\in e],
  \qquad
  \mu(S):=\sum_{v\in S}\mu_v.
\tag{223.2}
\]

The sum \(\sum_v\mu_v\) is the local query count, so no uniform-marginal assumption is
being made.

For an outer message decoder \(\mathsf{Dec}_i\), assume exact-codeword safety and an
honest-path domination condition: at every one of its at most \(q_D\) query steps, the
induced local edge distribution satisfies

\[
  \Pr[v\in e\mid\text{the preceding answers are honest}]\le \lambda\mu_v
  \qquad(v\in V).
\tag{223.3}
\]

This is a relative smoothness condition. Uniform incidence plus ordinary smoothness is a
special case; (223.3) is strictly more informative when the incidence profile is skewed.

## Theorem (heavy-core / punctured-RLDC dichotomy)

Fix any core \(K\subseteq V\), write \(V_K:=V\setminus K\), and define

\[
  \kappa_K:=\mu(K),
  \qquad
  \tau_K:=\max_{v\in V_K}\mu_v,
\tag{223.4}
\]

and the outside disagreement mass

\[
  \delta_K:=\min_{m\ne m'}
  \mu\bigl(D_{m,m'}\cap V_K\bigr),
  \qquad
  D_{m,m'}:=\{v:A_m(v)\ne A_{m'}(v)\}.
\tag{223.5}
\]

Then the following hold.

### (i) Every pair has incidence disagreement

For every \(m\ne m'\),

\[
  \mu(D_{m,m'})\ge\Delta.
\tag{223.6}
\]

Consequently the proof map is injective. If \(\mu_*:=\max_v\mu_v\), then

\[
  |D_{m,m'}|\ge\Delta/\mu_*.
\tag{223.7}
\]

### (ii) Core branch

If

\[
  \mu(V_K)<\Delta,
\tag{223.8}
\]

then the restriction map

\[
  m\longmapsto A_m|_K
\]

is injective. Hence

\[
  |K|\ge k/\log_2|\Sigma|.
\tag{223.9}
\]

Thus a core that captures all but less than \(\Delta\) of the complete-decoding
incidence must itself contain message-scale information.

### (iii) Punctured RLDC branch

Assume \(\delta_K>0\) and \(\tau_K>0\). The punctured proof map

\[
  \bar A_m:=A_m|_{V_K}\in\Sigma^{V_K}
\]

has relative distance at least

\[
  \Delta_K^{\rm proof}:=
  \frac{\delta_K}{\tau_K|V_K|}.
\tag{223.10}

\]

Define a relaxed decoder that aborts whenever an honest-path local edge touches \(K\),
and otherwise runs the dPCP local decoder followed by \(\mathsf{Dec}_i\). For every

\[
  0<\rho<\frac{\delta_K}{2\tau_K|V_K|},
\tag{223.11}
\]

the punctured map is a weak adaptive

\[
  (q_Pq_D,\rho,c_K,s_K)\text{-RLDC},
  \qquad
  c_K\ge 1-q_D\lambda\kappa_K,
  \qquad
  s_K\le q_D\lambda\tau_K\rho|V_K|,
\tag{223.12}
\]

where \(q_P\) is the number of proof positions used by one dPCP local call. Any
RLDC lower bound whose hypotheses accept \((c_K,s_K)\) therefore applies to the
punctured proof length \(|V_K|\).

The two branches are not mutually exclusive: a useful core may be retained while the
remainder still gives an RLDC. The point is the quantitative alternative: a route that
removes the RLDC branch must either violate (223.8)--(223.11), or pay the core information
in (223.9).

## Proof

Fix \(m\ne m'\), and let

\[
  S:=\{t:C(m)_t\ne C(m')_t\}.
\]

By code distance, \(|S|/M\ge\Delta\). For every \(t\in S\), an edge on which
\(A_m\) and \(A_{m'}\) agree would receive the same decoded symbol under (223.1),
contradicting \(C(m)_t\ne C(m')_t\). Therefore

\[
  \Pr_{(t,e)\sim\mathcal Q}[e\cap D_{m,m'}\ne\varnothing]\ge\Delta.
\]

The event on the left is contained in the union of the vertex events \(v\in e\) for
\(v\in D_{m,m'}\). A union bound gives

\[
  \Delta
  \le \mu(D_{m,m'}),
\]

which proves (223.6), injectivity, and (223.7).

If \(A_m|_K=A_{m'}|_K\), then \(D_{m,m'}\subseteq V_K\), and hence

\[
  \Delta\le\mu(D_{m,m'})\le\mu(V_K),
\]

contradicting (223.8). Thus the restriction is injective, and counting its possible
values gives (223.9).

For the punctured map, (223.5) and the definition of \(\tau_K\) imply

\[
  \delta_K
  \le \mu(D_{m,m'}\cap V_K)
  \le \tau_K|D_{m,m'}\cap V_K|.
\]

This proves (223.10). Now let \(z\) be within relative radius \(\rho\) of \(\bar A_m\),
and let \(B\subseteq V_K\) be its corruption set. On an honest query step, (223.3)
and a union bound give

\[
  \Pr[e\cap K\ne\varnothing]\le\lambda\kappa_K,
  \qquad
  \Pr[e\cap B\ne\varnothing]
  \le \lambda\tau_K|B|
  \le \lambda\tau_K\rho|V_K|.
\tag{223.13}
\]

If no queried edge hits \(K\) or \(B\), every local answer is the honest answer and
exact-codeword safety makes the outer decoder output the correct message symbol, never
the wrong one. Union-bounding (223.13) over the at most \(q_D\) adaptive steps proves
(223.12). The radius in (223.11) is below half the punctured proof distance, so the
target proof is unique. \(\square\)

## Corollary: uniform marginals are only one point in the profile

If \(\mu_v\le\chi/|V|\) for every \(v\), take \(K=\varnothing\). Then
\(\tau_K\le\chi/|V|\), \(\kappa_K=0\), and (223.12) recovers the incidence-stable
RLDC mechanism in [C204/C218](218-incidence-stable-field-lift-dpcp-forces-rldc-2026-08-17.md)
up to the notation for the outer smoothness factor.

For a nonuniform profile, choose a heavy set

\[
  K_\theta:=\{v:\mu_v>\theta\}.
\]

Then \(|K_\theta|<q_P/\theta\), because \(\sum_v\mu_v\le q_P\), and the punctured
profile satisfies \(\tau_{K_\theta}\le\theta\). Hence every attempt to exploit highly
concentrated incidence has an explicit choice:

* if \(\mu(V\setminus K_\theta)<\Delta\), the heavy set is an injective message core
  of size at least (k/\log_2|\Sigma|);
* otherwise, if \(\delta_{K_\theta}>0\) and the completeness/radius expressions in
  (223.11)--(223.12) stay nondegenerate, the punctured proof is an RLDC;
* if neither conclusion holds, the failure is a concrete collapse of outside proof
  distance or of the RLDC radius/completeness, not merely “nonuniform marginals.”

## Boundary and relation to RW/JK

The theorem does not claim that GMWZ supplies (223.3), an output code family, or an
address-scale RW accessor. It is a profile-level theorem: it closes one proposed escape
from C204, while leaving bottom, cover, target descriptor, and q-scale address generation
as separate gates.

It also does not turn a single target into an RLDC. The family, common proof space, exact
decoding, and distance-separated output hypotheses are essential. A single RW canonical
history can still evade this family theorem and must be handled by the static-advice
forcing branch or by a genuinely new single-target closure theorem.

## Sources

* [GMWZ Theorem 3.12](https://arxiv.org/html/2512.12960), for the current dPCP interface
  and its uniform-marginal special case.
* [C204/C218](218-incidence-stable-field-lift-dpcp-forces-rldc-2026-08-17.md), for the
  uniform-incidence field-lifted construction.
* [C209/C222](222-closure-gate-normal-form-for-rw-jk-2026-08-17.md), for the global Closure
  Gate classification.
