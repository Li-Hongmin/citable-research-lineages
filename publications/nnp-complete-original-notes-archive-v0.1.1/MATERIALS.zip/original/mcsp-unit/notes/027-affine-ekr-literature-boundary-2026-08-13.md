> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 仿射／射影 EKR 文献边界：AEKR_0 精确检索（2026-08-13）

## 决策问题

当前 AEKR_0 需要判断：对随机最大仿射 parity 叶 R₀，任意成对相交的细胞见证族 T 是否满足
Pr[存在 T∈𝒯 使 T⊆R₀] ≤ 1/4。若有现成定理可直接推出该界，主证明可缩短；若参数不匹配，则需独立证明或寻找反例。

## 检索边界

- 检索日期：2026-08-13（亚洲东京时区）。
- 查询簇：finite affine/projective EKR；intersecting affine subspaces；cross t-intersecting affine families；Bollobás-type affine/projective set-pairs；biased q-subspace measure；intersecting bicliques/product rectangles。
- 来源边界：arXiv 开放全文、期刊页面／DOI 元数据、Crossref 与 OpenAlex；优先原始定理及其可读全文。该检索是针对 AEKR_0 的决策检索，不是穷尽式书目审计。

## 最接近的原始结果及边界

1. Guo–Xu 的有限仿射空间 EKR，以及 Gong–Lv–Wang 的非平凡扩展：固定维数 k-flat 的 0-／t-相交族在适当 n≥2k+t+2 条件下由固定点／t-flat star 达到最大。AEKR 的 T 是任意细胞集合，|T| 和交集 L(T) 的余维变化，目标是随机 parity 叶上的并集概率；不能把固定维数计数界直接转成 1/4。
2. Yao–Wang 的 cross t-intersecting affine families：固定维数两族的乘积极值由共同 t-flat star 给出。AEKR 不是两族固定维数平坦的乘积，而是不同余维参数平面的上升并，故不直接适用。
3. Hegedüs 的 affine Bollobás-type theorem，以及 Yu–Wang 对 affine/projective 版本的改进：控制有序对系统中对角不交、上三角相交的族数（仿射 m=2(qⁿ−1)/(q−1) 等界；射影 q=2 时给出 2ⁿ⁺¹−2 的相应界）。AEKR 只有一个 spoiler 与成对相交见证，不具备上三角有序对关系，也没有叶并集概率，因此不能推出 1/4。
4. D’haeseleer 的 projective/affine Hilton–Milner 结果：比较固定维数相交族的最大与第二大非平凡规模。它仍是均匀 k-space 族的基数问题，未覆盖 AEKR 的可变余维和随机叶事件。
5. Tanaka–Tokushige 的带偏置 q-子空间测度：在线性子空间格上给出 star 型测度界（如参数范围内 σ/(1+σ)）。AEKR 的样本是随机 affine parity 线性函数 z=(r,t)，事件是若干可变余维 affine 平面的并；且见证 T、U 相交并不保证 L(T)、L(U) 相交，故不能代入该测度定理。

## 结论

在上述外部文献边界内未找到可直接推出 AEKR_0 的 1/4 定理。最接近的 EKR、cross-EKR、Hilton–Milner、Bollobás-type 与 biased-subspace 结果都缺少至少一个关键条件（固定维数、上三角有序对结构、或相同的 affine-parity 叶并集测度）。不过项目内已有独立穷举构造的 N=3 显式反例（见同目录 027-aekr-max-leaf-counterexample-2026-08-13.md）：五个两两相交的三元 T_i 均满足 odd--odd affine collision，但最大叶命中率为 5/16>1/4。因此 AEKR_0 已被反驳；这不是外部文献定理，而是当前项目的可复核代数反例。含 row/column thinning 的完整 AEKR 仍未判定。

## 缓存记录

- ResearchLibrary 项目：[unbundled local reference]
- 记录矩阵：admitted-records-2026-08-13.json、literature-matrix.csv（9 条原始记录，含 D’haeseleer；Guo–Xu、Gong–Lv–Wang、Yao–Wang、Hegedüs、Yu–Wang、Tanaka–Tokushige、Hsieh、Frankl–Wilson 等）。
- 全文获取：fulltext-retrieval.csv；9 条中 5 条复用已有库全文，1 条新下载，1 条下载失败（DOI 返回 octet-stream），2 条无开放 PDF；无检索错误。
