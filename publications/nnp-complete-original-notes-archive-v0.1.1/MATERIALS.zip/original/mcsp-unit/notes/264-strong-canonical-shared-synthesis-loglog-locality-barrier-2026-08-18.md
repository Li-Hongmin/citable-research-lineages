> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Strong-canonical shared synthesis inherits the \(\log\log\) locality barrier (2026-08-18)

## Purpose

The strong-canonical PCP route has two logically different steps:

1. canonicalize one claim, producing a proof for a fixed \((i,b)\);
2. synthesize all these claim proofs in one target-independent proof/address space.

The first step has known class-complexity boundaries. The second is the actual
ACRR interface. This note gives a quantitative barrier for the second step:
if the synthesis really yields a family-level, target-relative, positive-radius
shared proof, then finite-alphabet near-linearity forces the adaptive branch
locality to reach the “log-log” scale. Thus a proposed strong-canonical
construction cannot hide the missing cross-coordinate synthesis inside a fixed
constant-query black box.

This is a derived coding theorem, not a new unconditional lower bound for all
PCPPs. Its value is that it turns the qualitative trichotomy into a single
parameter test for any future shared-canonical construction.

## Model

Let \(A\ge2\) be a fixed proof alphabet and let

\[
  \Pi_k:\{0,1\}^k\longrightarrow A^{P_k}
\]

be the proof map produced by a proposed shared synthesis. For every message
coordinate \(i\) and claim \(b\in\{0,1\}\), let \(V_{i,b}\) be an adaptive
branch verifier of depth at most \(r=r(k)\). The verifier sees the same proof
address space for every \((i,b)\). Assume constants

\[
  0<\rho<1,\qquad \sigma_0>0,\qquad
  \beta\le1-\sigma_0,
\]

and the following target-relative interface:

* \(V_{i,m_i}\) accepts \(\Pi_k(m)\) with probability one;
* if \(z\) is within relative Hamming distance \(\rho\) of \(\Pi_k(m)\), then
  \(V_{i,1-m_i}(z)\) accepts with probability at most \(\beta\);
* all claims use the same proof map and the same address space.

The strong-canonical PCPPs used to create the individual claim proofs may be
linear, self-correctable, or robust; none of those properties is used after the
shared synthesis has produced this interface. This is intentional: the theorem
tests the exact object that a successful synthesis must output.

## Theorem (shared-canonical locality barrier)

Let

\[
  Q_{r,A}:=1+2\sum_{j=0}^{r-1}A^j,
  \qquad
  N_k:=k+P_k .
\]

If \(N_k\le k(\log k)^c\) for infinitely many \(k\), then, for all sufficiently
large such \(k\),

\[
  Q_{r,A}
  =\Omega_{A,\rho,\sigma_0,c}
      \!\left(\frac{\log k}{\log\log k}\right).
  \tag{264.1}
\]

For fixed \(A\), this implies

\[
  r\ge
  \log_A\log k-\log_A\log\log k-O_{A,\rho,\sigma_0,c}(1).
  \tag{264.2}
\]

In particular, a shared strong-canonical synthesis with fixed finite alphabet,
constant branch locality, constant positive radius, and constant target-relative
gap cannot have near-linear proof length.

### Proof

If \(m\ne m'\), choose a coordinate \(i\) with \(m_i\ne m'_i\). Completeness
for \(m\) and wrong-branch soundness for \(m'\) imply
\[
  d_H(\Pi_k(m),\Pi_k(m'))>\rho P_k .
\]
Thus the proof image has relative distance \(>\rho\). Since it is an
\(A\)-ary code with \(2^k\) codewords, the Singleton bound gives
\[
  2^k\le A^{(1-\rho)P_k+1}.
\]
For all sufficiently large \(k\), this implies
\[
  \frac{P_k}{N_k}\ge
  c_{A,\rho}:=\frac{1}{1+2(1-\rho)\log_2 A}.
\]
Set \(\delta_0:=\rho c_{A,\rho}/2\).

Inline the message bit \(m_i\) before the proof suffix. On a word within
relative distance \(\delta_0\) of the codeword \(m\Vert\Pi_k(m)\), the proof
suffix is within \(\rho P_k/2\) of \(\Pi_k(m)\). The inline bit is either
correct or wrong. The correct branch is perfect; the wrong branch can output
the wrong bit with probability at most \(\beta\). This is a weak relaxed
decoder of depth \(r+1\) and success gap \(\sigma=1-\beta\ge\sigma_0\).

For a fixed random tape, each \(A\)-ary adaptive branch is a depth-\(r\)
decision tree with at most \(\sum_{j<r}A^j\) internal query nodes. Query the
union of both branch trees and the inline coordinate. The resulting decoder
is nonadaptive and uses at most \(Q_{r,A}\) symbols. Completeness, radius and
success probability are unchanged.

Apply the arbitrary-alphabet RLDC lower bound of Goldberg--Gur--Saraogi to
this decoder. With

\[
  a=\left\lceil Q_{r,A}/\sigma\right\rceil,
\]

it gives

\[
  N_k\ge
  \left(
    \frac{\sigma^2 k}
    {38Q_{r,A}^4\log^2(A+2)\log^2 k}
  \right)^{1+1/a}.
  \tag{264.3}
\]

Suppose \(Q_{r,A}\le\eta\log k/\log\log k\). Then

\[
  \frac{\log k}{a}
    \ge \frac{\sigma_0}{2\eta}\log\log k,
\]

while the logarithm of the denominator in (264.3) is at most
\(6\log\log k+O_{A,\sigma_0,\eta}(1)\). Taking logarithms of (264.3) and
using \(N_k\le k(\log k)^c\) gives the opposite bound

\[
  \frac{\log k}{a}
    \le (c+12)\log\log k+O_{A,\sigma_0,\eta}(1).
\]

Choosing \(\eta<\sigma_0/[4(c+12)]\) is contradictory. This proves (264.1),
and \(Q_{r,A}=\Theta_A(A^r)\) gives (264.2). The radius side condition in
the RLDC theorem holds because \(\delta_0\) is constant and \(N_k\ge k\).
\(\square\)

## What this says about strong-canonical PCPs

The theorem does not say that strong-canonical PCPPs are weak. It separates
their two uses:

* a logarithmic-randomness strong-canonical system for an NP-hard language has
  the known \(\mathrm{UP}\) consequence, and a polynomial-proof polynomially
  strong system has the corresponding \(\mathrm{UMA}\) consequence;
* separate canonical proofs for \((i,b)\) do not share an address space;
* a genuinely shared synthesis is subject to (264.1), unless it pays one of the
  explicit escapes: growing locality, growing alphabet, vanishing radius/gap,
  target-dependent address spaces, or superlinear proof length.

Thus the positive research target is no longer “canonicalize the history”. It
is a shared synthesis theorem that either beats the (264.2) locality threshold
with a new coding mechanism, or explains why its proof/target binding leaves the
RLDC model. A construction that merely invokes a canonical proof separately
for each target does not enter this theorem and has not solved simultaneous ACRR.

## Scope and boundary

The result is family-level and target-relative. It does not rule out a
single-target verifier, a verifier whose address space depends on \((i,b)\), a
non-positive-radius promise, or an interaction model not representable by a
finite branch tree. If \(A\) or \(r\) grows with \(k\), (264.3) must be
re-evaluated rather than treating the constants as fixed.

The theorem is therefore a promotion rule for the top-level program: any
claimed strong-canonical/shared-ACRR construction must state which side of
(264.1) it occupies, and must expose the first parameter that leaves the
finite-alphabet positive-radius RLDC regime.

## Sources

* Goldberg--Gur--Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally
  Decodable Codes via Robust Daisies*, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.
* Dinur--Goldreich--Gur, strong-canonical PCP class boundary, Theorems 3.1--3.2:
  <https://eccc.weizmann.ac.il/report/2018/050/>.
* The prior adaptive-to-nonadaptive derivation is recorded in
  [note 242](242-growing-query-threshold-for-near-linear-closure-2026-08-17.md).
