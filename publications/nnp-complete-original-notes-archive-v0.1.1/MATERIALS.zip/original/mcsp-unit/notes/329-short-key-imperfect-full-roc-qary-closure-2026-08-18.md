> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Short-key imperfect full-ROC q-ary Closure Gate

## Contribution

The direct q-ary envelope of note 328 assumes one target-independent package
law for the whole message family.  A common proposed escape is to let a short
target key choose the package.  This note closes that escape in the
imperfect-completeness, growing-alphabet setting: a key of at most
\(\gamma K\) bits leaves a largest key bucket with linear VC dimension, so the
note 328 envelope applies inside that bucket.

The conclusion is deliberately conditional on **same-key** full-ROC semantics.
Different coordinates or different messages within one key bucket may not use
different proof/address spaces.

## Theorem

Let
\[
  \Pi_K:\{0,1\}^{K}\longrightarrow\Sigma_K^{P_K},
  \qquad A_K:=|\Sigma_K|\ge2,
\]
be one common proof map.  Let
\(\kappa_K:\{0,1\}^{K}\to\{0,1\}^{t_K}\) be a target key.  For every key
\(\sigma\), coordinate \(i\), and claim \(b\), assume one package law
\(\mu_{\sigma}\) of adaptive proof-symbol verifiers and transcript filters,
with depth at most \(r_K\), such that for every
\(m\) satisfying \(\kappa_K(m)=\sigma\),
\[
  \mathbb E_{S\sim\mu_\sigma} C_{m,i,S}\ge\alpha,
  \qquad
  \mathbb E_{S\sim\mu_\sigma} W_{m,i,b,S}(z)\le\beta
  \quad(m_i\ne b)
\tag{329.1}
\]
for every \(z\) with
\(d_H(z,\Pi_K(m))\le\rho P_K\).  Here
\[
  0<\rho<1,\qquad 0\le\beta<\alpha\le1
\]
are fixed constants.  Put
\[
  Q_K:=1+2\sum_{j=0}^{r_K-1}A_K^j,
  \qquad
  H_K:=\log_2\log_2(K+2)+\log_2(Q_K+2)
       +\log_2\!\bigl(\log_2(A_K+2)+2\bigr).
\tag{329.2}
\]

Fix \(0\le\gamma<1\), and choose a constant
\(\delta_\gamma\in(0,1/2)\) satisfying
\[
  H_2(\delta_\gamma)<1-\gamma,
\tag{329.3}
\]
where \(H_2\) is binary entropy.  If
\[
  t_K\le\gamma K
  \qquad\text{and}\qquad
  K+P_K\le K\bigl(\log_2(K+2)\bigr)^{c_0}
\tag{329.4}
\]
on infinitely many sufficiently large \(K\), then on that subsequence either
\[
  \log_2(A_K+2)\ge \frac{\delta_\gamma K}{2},
\tag{329.5}
\]
or
\[
  Q_KH_K=\Omega_{\rho,\alpha,\beta,\gamma,c_0}(\log_2 K).
\tag{329.6}
\]

Thus a target-dependent package selected by a sub-\(K\)-bit key cannot preserve
both a non-message-scale alphabet and \(o(\log K)\) direct q-ary locality in
the near-linear proof-length regime.  The statement is a key-indexed
extension of note 328, not a claim about arbitrary target-specific verifiers.

## Proof

Partition the message cube into key buckets
\[
  \mathcal F_\sigma:=\{m:\kappa_K(m)=\sigma\}.
\]
Some bucket \(\mathcal F_{\sigma_\star}\) has size at least
\[
  |\mathcal F_{\sigma_\star}|\ge2^{K-t_K}
  \ge2^{(1-\gamma)K}.
\tag{329.7}
\]
Let \(d_\star\) be its VC dimension.  If
\(d_\star<\delta_\gamma K\), Sauer--Shelah gives
\[
  |\mathcal F_{\sigma_\star}|
  \le\sum_{j<\delta_\gamma K}\binom Kj
  \le 2^{K H_2(\delta_\gamma)+o(K)}
  <2^{(1-\gamma)K},
\]
contradicting (329.7).  Hence
\[
  d_\star\ge\delta_\gamma K.
\tag{329.8}
\]

Restrict to a shattered coordinate set \(J\) of size \(d_\star\), and choose
one representative \(m_u\in\mathcal F_{\sigma_\star}\) for every
\(u\in\{0,1\}^{J}\).  All these representatives use the same package law
\(\mu_{\sigma_\star}\).  If two proof words
\(\Pi_K(m_u),\Pi_K(m_v)\) were within \(\rho P_K\) and \(u_i\ne v_i\) for
some \(i\in J\), then (329.1) applied to the same proof and the same package
law would give both a correct output of probability at least \(\alpha\) and
the opposite output of probability at most \(\beta\).  Therefore the
restricted proof family has minimum distance greater than \(\rho P_K\).

Apply the direct q-ary construction of note 328 to this restricted family,
with message length \(d_\star\), proof length \(P_K\), and alphabet \(A_K\).
The \(A_K\)-ary Singleton bound and the disjoint inline tags give the radius
\[
  \delta_\star=
  \frac{\rho}{2\bigl(2(1-\rho)\log_2 A_K+1\bigr)}
\]
unless \(\log_2(A_K+2)\ge d_\star/2\).  Since
\(d_\star\ge\delta_\gamma K\), this exceptional case implies (329.5).

Otherwise the restricted tagged code is a weak q-ary RLDC with success
\(\sigma=\min\{\alpha,1-\beta\}\), alphabet \(A_K+2\), and nonadaptive query
count \(Q_K\) after the two adaptive claim trees are exposed.  Its length is
\[
  N_\star=d_\star+P_K\le K+P_K
  \le K(\log_2(K+2))^{c_0}
  \le d_\star(\log_2(d_\star+2))^{c_1}
\tag{329.9}
\]
for a fixed \(c_1=c_1(c_0,\delta_\gamma)\).  Thus the direct q-ary envelope
of note 328 applies with \(d_\star\) in place of \(K\).  It gives
\[
  Q_K\!\left(
    \log\log(d_\star+2)+\log(Q_K+2)
    +\log(\log(A_K+2)+2)
  \right)
  =\Omega(\log d_\star)
\]
in the non-message-scale branch.  Since
\(d_\star=\Omega_\gamma(K)\), this is (329.6), after changing constants.
\(\square\)

## Boundary

The same-key quantifier is essential.  If every \((m,i)\) has its own package,
the largest key bucket can be a singleton and no VC lift follows.  If the
package varies within a bucket after the coordinate is revealed, this theorem
does not apply; the model has returned to \(\forall i\,\exists S_{m,i}\).

The theorem also does not claim that a key of length \(\gamma K\) is impossible:
it only says that, below the explicit entropy threshold, the remaining bucket
still contains a linear shattered submessage.  For \(\gamma\to1\), the
constant \(\delta_\gamma\) may vanish, and the conclusion correspondingly
weakens.

## Relation to existing gates

* Note 275 removes target dependence by a mutual-information/Pinsker mixture.
  The present theorem instead keeps a discrete key and works inside its
  largest bucket.
* Notes 326--328 handle imperfect full-ROC packages with one common law;
  note 329 supplies the missing short-key extension without an inner-code
  hypothesis.
* This remains a coding Closure Gate.  It is not an unconditional dPCP
  impossibility or a \(P\ne NP\) theorem.

## Sources

* Full-ROC mixture interface: [note 275](275-mutual-information-mixture-to-full-roc-closure-2026-08-20.md).
* Direct imperfect q-ary envelope: [note 328](328-imperfect-full-roc-joint-alphabet-envelope-2026-08-18.md).
* Sauer--Shelah and arbitrary-finite-alphabet GGS are used exactly in the
  restricted-bucket reduction.
