> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Avoid、prefix truth-table generator 与目标 decoder 的尺度边界（2026-08-15）

## 原始文献中的可用结果

Gajulapalli--Li--Volkovich 的 ECCC TR24-049《Oblivious Classes Revisited: Lower Bounds and
Hierarchies》明确使用 truth-table generator 与 Range Avoidance 的组合。令 \(n\) 为地址位数、
\(N=2^n\)，令 \(s\) 为电路门数，并用

\[
L_{n,s}=(s+1)\bigl(7+\log(n+s)\bigr)
\]

位描述 \(n\)-input、size-\(s\) 电路。该文的 full generator 是

\[
\mathrm{TT}_{n,s}:\{0,1\}^{L_{n,s}}\longrightarrow\{0,1\}^{N},
\tag{1}
\]

把 gate-list 映为完整 truth table；只要 \(L_{n,s}<N\)，它是 input-expanding 的
Range Avoidance 实例。

为得到固定多项式尺度的显式 lower bound，该文改用

\[
E_{n,s}=5s\log s,
\qquad
\mathrm{PTT}_{n,s}:\{0,1\}^{E_{n,s}}
\longrightarrow
\{0,1\}^{E_{n,s}+1},
\tag{2}
\]

输出每个 truth table 的前 \(E_{n,s}+1\) 位。其 Lemma 2.15 给出

\[
\bigl|\mathrm{PTT}_{n,s}\bigr|=O(E_{n,s}^{3}),
\tag{3}
\]

并且该电路可在 \(O(E_{n,s}^{3})\) 时间内 uniform 构造。随后对
\(\mathrm{PTT}_{n,s}\) 运行 single-valued \(FS_2P\) 的 Avoid 算法，得到
\(f_{n,s}\notin\operatorname{Range}(\mathrm{PTT}_{n,s})\)，再定义完整表

\[
F_{n,s}=f_{n,s}\Vert 0^{N-E_{n,s}-1}.
\tag{4}
\]

因为每个 size-\(s\) 电路的 truth table 前缀都在式 (2) 的 range 中，式 (4) 不可能由
\(n\)-input、size-\(s\) 电路计算。该文由此得到显式 \(O_2P\) 语言的固定多项式
circuit lower bounds。

## 同形对象的最新 AVOID 用法

Ren--Williams 的 ECCC TR26-118（2026，§4.3）把同一个对象作为标准 AVOID 实例明确写出：
对 \(n=2^k\)，定义

\[
G_n:\{0,1\}^{n}\longrightarrow\{0,1\}^{2n},
\]

输入是 \(n\)-bit 的电路描述，输出该电路在 \(k+1\) 个输入变量上的完整 truth table。
因此在记号 \(q=n\) 下，它正是本项目研究的 \(q\to2q\) truth-table map，而不是只输出一个
assignment 的 universal evaluator。该文的 AVOID/硬度定理只使用这族 \(G_n\) 的 uniform
可构造性与输出语义；它没有声称

\[
|G_n|=n\operatorname{polylog}n,
\]

也没有给出 unrestricted decoder 的超线性一般下界。其结论是

\[
\text{smart-}E^{\mathrm{prMA}}/1
\text{ 存在近最大电路下界},
\]

不是 \(P\ne NP\) 或 NP-range 的结论。故这篇最新原始来源把“标准对象是什么”钉死了，
但没有填补本项目的 batch-size gap：目前可复用的具体上界仍是本 note 后文的
universal-circuit batching \(O(q^2)\)，而 \(q\operatorname{polylog}q\) 仍 unknown。

## 与本项目参数的精确换算

若令本项目的 seed 长度为

\[
q=E_{n,s}\asymp s\log s
\]

取原文地址参数 \(n=m\)，再取最近的二次幂 \(q'=2^{m-1}\ge q\)，把 PTT 的输入零填充到 \(q'\)，把
\(E_{n,s}+1\) 位输出零填充到目标长度 \(2q'=2^m\)。在这个 padding 比较下，
\(s\asymp q'/\log q'\)（目标 \(q'/\operatorname{polylog}q'\) 窗口的一个特例）与式 (2)
的信息尺度相符；这只是参数尺度比较，
不是把两个 generator 视为同一个 map。但是现有文献的
prefix generator 只有

\[
\lvert\mathrm{PTT}_{n,s}\rvert=O(q^3),
\]

不是目标的 \(q\operatorname{polylog}q\)。full generator 的逐输出 evaluator 也需要对大量
truth-table coordinates 复制电路；该文的 \(O(q^3)\) 结果没有提供
\(q\operatorname{polylog}q\) 的 full/batch generator，也没有证明后者不可能。

因此可严格记录：

\[
\boxed{
\text{已有 Avoid lower-bound 接口：}
\quad
\text{seed }q,\ \text{generator size }O(q^3);
\qquad
\text{目标接口：}
\quad
\text{generator size }q\operatorname{polylog}q.
}
\tag{5}
\]

这不是常数优化：若 \(s=q/\log^k q\)，普通逐门 batch evaluation 的规模约为
\(q s\)，而式 (3) 的 prefix construction 还多一个高次通用模拟开销。要把文献接口
推进到目标范围，必须产生新的批量 truth-table evaluator，或证明其在目标电路模型中
不可能。

还存在一个独立的地址尺度障碍。若 \(N=2q=2^m\) 且
\(q\asymp s\log s\)，目标参数给出
\[
s\asymp 2^m/\operatorname{poly}(m).
\]
即使把 generator 尺寸改进到 \(q\operatorname{polylog}q\)，现有 Avoid 过程按 seed
长度运行的时间仍是 \(2^{O(m)}\)，其逐位语言落在指数时间的 oblivious 类，而不是
NP。若把 prefix 长度压到 \(\operatorname{poly}(m)\) 以进入 NP 时间尺度，覆盖阈值也只
能降到 \(\operatorname{poly}(m)\)，不再是本项目的 \(q/\operatorname{polylog}q\) regime。

## 复杂度层级边界

Avoid 输出 \(f_{n,s}\) 的算法属于 single-valued \(FS_2P\)，因而得到的是
\(O_2P\) 中的显式 hard language，而不是已知的 NP 语言。把
\[
\text{“存在 size-\(s\) 电路计算 \(F_{n,s}\)”}
\]
改写为 range membership 确实是一个 NP witness 问题；但文献只给出了
\(FS_2P\) 的**找非像表**算法，并没有把该非像表的 bit predicate 降到 NP。
所以不能把 TR24-049 的结果改写成 \(P\ne NP\)。

对本项目而言，正确的两个可证伪目标是：

1. **正面目标：** 构造 size \(q\operatorname{polylog}q\) 的 fixed
   truth-table/prefix generator，并保留 exponent-stable inverse；然后研究其
   Range Avoidance 是否能在足够低的 uniform 类中实现；
2. **负面目标：** 在一个明确的受限模型（例如 materializing boundary bundles、
   OBDD/固定字典或有限深度）中证明从 \(O(q^3)\) 向
   \(q\operatorname{polylog}q\) 的压缩不可能，再说明该受限 lower bound 不能外推到
   unrestricted decoder。

这把当前未知点从“有没有任何 outsider”收窄为“能否把已有 Avoid/prefix generator
压缩到目标 batch-evaluation 尺度，同时不牺牲 coverage”。

### 文献边界

- Karthik Gajulapalli, Zeyong Li, Ilya Volkovich,
  *Oblivious Classes Revisited: Lower Bounds and Hierarchies*,
  [ECCC Report TR24-049 (2024)](https://eccc.weizmann.ac.il/report/2024/049/),
  Definitions 2.13--2.14, Lemma 2.15,
  Theorems 2.16--2.17 and 3.1--3.3。
- 本 note 只采用上述 generator 尺寸、Avoid 接口和 \(O_2P\) lower-bound 结论；
  不把它升级为 canonical decoder 的一般 lower bound，也不声称 \(P\ne NP\)。
- 最新同形对象核对：Hanlin Ren and Ryan Williams, *Near-Maximum Circuit Lower Bounds for
  Exponential Time with Merlin--Arthur Queries*, ECCC TR26-118 revision 1，§4.3，
  官方全文：[ECCC TR26-118](https://eccc.weizmann.ac.il/report/2026/118/revision/1/download)。
