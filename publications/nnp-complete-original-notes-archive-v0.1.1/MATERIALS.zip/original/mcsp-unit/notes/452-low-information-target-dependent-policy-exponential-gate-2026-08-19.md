> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Low-information target-dependent policy: exponential binary gate（2026-08-19）

## 本轮改变的判断

定理 451.1 只处理一个对所有 target 固定的 policy pair。这里把它推进到
target-dependent policy package：只要 package 与 target 的互信息没有携带近乎
全部 message entropy，条件分布中就存在一个指数大的共同 policy fiber；
Sauer--Shelah 从这个 fiber 提取线性维度的子消息，随后仍可调用 binary
two-query RLDC 的指数下界。

因此，在 binary、one-proof-query、perfect-complete 的窗口中，target dependence
只有两种真正的出口：policy channel 携带 \(K-o(K)\) bits，或退出 common
supportwise robustness / full claim-pair semantics。

## 定理 452.1（low-information target-dependent exponential gate）

令 \(M\) 均匀分布于 \(\{0,1\}^{K}\)，令
\[
  \Pi:\{0,1\}^{K}\longrightarrow\{0,1\}^{P}
\]
是一个 binary common-proof map。令 \(S\) 是 target-dependent policy package；
给定 \(s\)、坐标 \(i\) 和 claim \(b\)，package 含有一个（可含 public
randomness 的）one-proof-query verifier \(V_{i,b}^{s}\)。假设存在常数
\(0<\rho<1\)、\(\beta<1/2\)，使得对几乎所有 \(s\)，对每个
\[
  F_s:=\{m:\Pr[M=m\mid S=s]>0\}
\]
中的 target \(m\) 和每个坐标 \(i\)，都有

1. **supportwise perfect completeness**
   \[
     \Pr[V_{i,m_i}^{s}(\Pi(m))=1]=1;
   \]
2. **supportwise target-relative soundness**
   \[
     \operatorname{dist}(z,\Pi(m))\le\rho P
     \Longrightarrow
     \Pr[V_{i,1-m_i}^{s}(z)=1]\le\beta .
   \]

假设 \(I(M;S)\le\gamma K\)，其中固定 \(\gamma<1\)。则对任意
\(\theta\) 满足
\[
  H_2(\theta)<1-\gamma
\]
（并令 \(K\) 足够大），存在一个坐标集 \(J\subseteq[K]\)，
\(|J|\ge(\theta-o(1))K\)，使得 restricted inline map

\[
  u\longmapsto u\Vert\Pi(m_u),
  \qquad u\in\{0,1\}^{J},
\]
是一个 binary weak adaptive \((2,\delta(\rho),1-\beta)\)-RLDC。因而
\[
  |J|+P\ge 2^{\Omega_{\rho,\beta}(|J|)}
  =2^{\Omega_{\rho,\beta,\gamma,\theta}(K)}.
  \tag{452.1}
\]
特别地，\(P\le K(\log K)^{O(1)}\) 不可能在该窗口中成立。

这里的 package 必须同时包含每个 \((i,b)\) 的 claim-pair verifier；若只给
target 的正确 claim policy，错误 inline bit 时无法执行本归约。

### 证明

由
\[
  H(M\mid S)=K-I(M;S)\ge(1-\gamma)K
\]
以及条件熵的平均表示，任意固定
\(\varepsilon>0\) 后都可选取一个 supportwise-good 的 \(s_\star\)，使
\[
  H(M\mid S=s_\star)\ge(1-\gamma)K-\varepsilon K.
\]
于是
\[
  |F_{s_\star}|
  \ge 2^{H(M\mid S=s_\star)}
  \ge 2^{(1-\gamma-\varepsilon)K}.
\]
对集合 \(F_{s_\star}\subseteq\{0,1\}^{K}\) 应用 Sauer--Shelah。若其 VC
dimension 为 \(d\)，则
\[
  |F_{s_\star}|\le\sum_{j=0}^{d}\binom Kj.
\]
因此，任意满足 \(H_2(\theta)<1-\gamma-\varepsilon\) 的固定
\(\theta\) 下，充分大时 \(d\ge\theta K\)。取一个被
\(F_{s_\star}\) shattered 的 \(J\)，并对每个
\(u\in\{0,1\}^{J}\) 选一个 \(m_u\in F_{s_\star}\) 满足
\(m_u|_J=u\)。

对不同的 \(u,v\)，若 \(\operatorname{dist}(\Pi(m_u),\Pi(m_v))\le\rho P\)，
取 \(i\in J\) 使 \(u_i\ne v_i\)。同一个 package \(s_\star\) 的
\(V_{i,v_i}^{s_\star}\) 在 \(\Pi(m_v)\) 上由完备性以概率一接受，而把
\(\Pi(m_v)\) 代入 target \(m_u\) 的错误分支时，由 soundness 接受率至多
\(\beta\)，矛盾。故这些 restricted proof words 的两两相对距离严格大于
\(\rho\)。

令 restricted message length 为 \(d=|J|\)。Binary Singleton bound 给出
\[
  d\le P-d_{\rm proof}+1<(1-\rho)P+1,
\]
故 \(d\ge2\) 时 \(P\ge d/[2(1-\rho)]\)，从而
\[
  \frac{P}{d+P}\ge\frac1{3-2\rho}.
\]
固定
\[
  \delta(\rho):=\frac{\rho}{4(3-2\rho)}.
\]
总长度 \(d+P\) 内不超过 \(\delta(\rho)(d+P)\) 个错误时，proof suffix
仍在 \(\rho P\)-邻域内，且不同 inline codeword 的距离大于两倍该半径，
所以 RLDC promise 中的目标唯一。

decoder 先查询 inline bit \(b\)，再执行同一个固定
\(V_{i,b}^{s_\star}\) 的一次 proof query；接受则输出 \(b\)，否则输出
\(\bot\)。inline bit 正确时输出只能是正确 bit 或 \(\bot\)；inline bit
被翻转时，target-relative soundness 将错误输出概率限制为 \(\beta\)。
因此 relaxed success 至少为 \(1-\beta>1/2\)，正是 binary weak adaptive
2-query RLDC。应用 Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu
Theorem 1，得到 (452.1)。证毕。

## 量词边界

* 这是 supportwise 的定理：对 \(s\) 的后验支持中的每个 target 都要有同一
  policy package 的完备性与错误 soundness；普通 average/list soundness 不足。
* \(S\) 可取标准 Borel policy space；条件分布 \(M\mid S=s\) 的支持与熵论证
 仍然成立。若只希望避免测度论，可把 \(S\) 限制为有限或可数 package。
* \(\beta<1/2\)、binary proof、一次 proof query 和 perfect completeness 都是
  Block et al. 指数下界的真实接口；放宽任一项需回到 Paper 05 的其它 barrier。
* 定理不适用于 published RW/JK 的 singleton \(x_0\)（除非它被嵌入满足上述
  family/supportwise 量词的 target family），也不直接证明 \(P\ne NP\)。
  它关闭的是 Gate-II 中一类“低信息 target-dependent binary one-query policy”
  的廉价出口。

## 来源

* [note 451](451-uniform-policy-two-query-exponential-rldc-gate-2026-08-19.md)；
  固定 policy fiber 上的 inline compiler。
* Paper 05 Theorem 3.2；
  [shared-proof coordinate robustness paper](../../rw-jk-succinct-reconstruction/papers/05-shared-proof-coordinate-robustness-barriers/paper.md)。
* Block, Blocki, Cheng, Grigorescu, Li, Zheng, Zhu,
  *Exponential Lower Bounds for 2-query Relaxed Locally Decodable Codes*,
  arXiv:2602.20278, Theorem 1.
