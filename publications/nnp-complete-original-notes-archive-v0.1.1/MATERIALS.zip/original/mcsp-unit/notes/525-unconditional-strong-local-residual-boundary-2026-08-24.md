> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Unconditional strong-local residual boundary (2026-08-24)

## Proposition 33

Let \(0<\mu_H<1\), \(S=N^{\mu_H}\), and let an exact known-order ROBP of width
\(\mathfrak W\) decide \(\mathrm{MCSP}_{S}\). If \(\mu_H>1/2\), then

\[
\log_2\mathfrak W
\ge (2\mu_H-1)\log_2N-O\!\left((\log N)^{2/3}\right).
\tag{525.1}
\]

Combining this with the residual-width simulation in Proposition 31 gives the unconditional
protocol bound

\[
h+\log_2W_Q+\log_2W_D+\log_2R
\ge (2\mu_H-1)\log_2N-O\!\left((\log N)^{2/3}\right).
\tag{525.2}
\]

## Proof

Cheraghchi--Kabanets--Lu--Myrisiotis (CKLM, ICALP 2019, Lemma 24) construct, for every
branching-program size \(s\ge N\), a local PRG with constant additive fooling error whose output
bits have circuit complexity

\[
\lambda(s)\le s^{1/2}2^{O((\log s)^{2/3})}.
\]

Pad a smaller ROBP to size \(\max\{s,N\}\). If
\(\lambda(\max\{s,N\})<S\), every PRG output is an \(\mathrm{MCSP}_{S}\) YES instance. A
uniform \(N\)-bit table is NO with probability \(1-o(1)\), by circuit enumeration because
\(S=N^{\mu_H}=o(N/\log N)\). Thus the ROBP distinguishes the PRG from uniform by a constant
gap, contradicting CKLM's fooling guarantee. Therefore

\[
s^{1/2}2^{O((\log s)^{2/3})}\ge S,
\]

so

\[
\log_2s\ge2\mu_H\log_2N-O((\log N)^{2/3}).
\]

Since \(s\le(N+1)\mathfrak W\), (525.1) follows. Substituting
\(\mathfrak W\le(N+1)W_QW_D2^hR\) from Proposition 31 proves (525.2).

For bounded error, fix source-independent random tapes and require the same width bound for every
tape. Let \(\eta_{\mathrm{CKLM}}\) denote the additive fooling error
(\(\eta_{\mathrm{CKLM}}=1/3\) in the stated construction), and let
\(\delta_A=\Pr_{x\sim U_N}[x\in\mathrm{MCSP}_S]=o(1)\). If
\[
\varepsilon_Y+\varepsilon_N+\eta_{\mathrm{CKLM}}+\delta_A<1,
\]
averaging CKLM's fooling inequality over the random tape gives generator acceptance at least
\(1-\varepsilon_Y\), but uniform acceptance at most \(\varepsilon_N+\delta_A\), a contradiction.
For any fixed gap \(\varepsilon_Y+\varepsilon_N<1\), constant independent repetition and
thresholding reduce the errors to this regime. The resulting inequality has the same
\(\log N\) order, with a constant-factor loss depending only on the original errors.

## Boundary

This is unconditional but only logarithmic in \(N\). It does not remove the stronger
\(\widetilde\Omega(S)\) local-PRG interface in Proposition 31. In particular, an unconditional
\(2^{\Omega(S)}\) residual-width lower bound for low-threshold MCSP remains open; sparse YES sets,
small-width OBDDs for other sparse languages, and possible low-complexity XOR cancellations prevent
counting or entropy alone from supplying it.

## Dependencies

- [Proposition 31](523-hidden-continuation-complexity-boundary-2026-08-24.md)
- [Proposition 32](524-finite-hidden-state-completion-2026-08-24.md)
- CKLM, *Circuit Lower Bounds for MCSP from Local Pseudorandom Generators*,
  [LIPIcs.ICALP.2019.39](https://doi.org/10.4230/LIPIcs.ICALP.2019.39)
