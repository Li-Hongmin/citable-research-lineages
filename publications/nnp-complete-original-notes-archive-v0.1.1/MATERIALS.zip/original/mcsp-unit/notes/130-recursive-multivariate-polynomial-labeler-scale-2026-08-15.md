> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 递归多变量多项式标签器的闭合与全局尺度（2026-08-15）

## 结论先行

Harsha 的低度 PCP 叶块可以用
\(q_{\mathrm{line}}=\operatorname{polylog}(t')\) 个 bits 描述；但若要求同一个
decoder 沿 JK 树递归地产生所有相邻子标签，最直接的代数构造必须携带一个
**全局多变量多项式**的系数张量。其自然 seed 长度是

\[
q_{\mathrm{root}}
 =\Theta\!\left(|H|^m\log|F|\right)
 =\Theta(t'\log|F|),
\tag{1}
\]

其中 \(t'\) 是 Ren--Williams 中 Circuit-SAT 电路 \(C_x\) 的大小。于是它落在
time-scale \(t'\) 而不是 leaf-scale \(\operatorname{polylog}(t')\)。这给出一个
可实现的 whole-tree algebraic labeler，同时精确说明它为什么不能直接进入
\(P\) versus \(NP\) 的小 \(q\) forcing 窗口。

## 全局标签器的构造

令 \(F=\mathbb F_{2^b}\)，\(H\subseteq F\)，

\[
D:=|H|,
\qquad
A:F^m\to F,
\qquad
\deg_{x_j}A<D.
\]

用系数张量

\[
\mathbf a=(a_\alpha)_{\alpha\in\{0,\ldots,D-1\}^m}
\in F^{D^m}
\]

表示 \(A\)。固定一个二叉划分树，把 \(H^m\) 分成 leaf cells；每个 node \(v\)
带有一个固定的仿射重参数化。令

\[
\operatorname{Lab}(A,v)\in F^{D^m}
\]

为 \(A\) 在该 cell 上的低度 restriction 的 padded coefficient tensor。对每条
edge \(v\to v_b\)，存在固定线性 restriction map

\[
R_{v,b}:F^{D^m}\to F^{D^m},
\qquad
\operatorname{Lab}(A,v_b)=R_{v,b}(\operatorname{Lab}(A,v)).
\tag{2}
\]

在标准 affine/FFT 网格上，\(R_{v,b}\) 是逐坐标的 evaluation/interpolation
变换；共享中间结果后可由

\[
O\!\left(D^m\,\operatorname{polylog}(D^m)\,b^2\right)
\tag{3}
\]

个 Boolean gates 实现。cell address、family tag 与固定 padding 只增加
\(O(m\log|F|+\log t')\) bits。

定义一个带两个 mode 的 decoder \(G^{\mathrm{tree}}\)：

1. **internal mode**：seed 解析为
   \((v,\operatorname{Lab}(A,v))\)，输出
   \(\operatorname{Lab}(A,v_0)\Vert\operatorname{Lab}(A,v_1)\)；
2. **leaf mode**：seed 解析为 line restriction 的系数，输出该 restriction
   在固定评价网格上的 \(2q_{\mathrm{line}}\)-bit evaluation block（使用 note 127
   的 additive FFT decoder）。

适当 zero-padding 后，两个 mode 可放进同一个固定长度 seed。internal mode 的
输出正是两个 child seeds 的串接，因此对由同一个 \(A\) 产生的整棵树有

\[
\operatorname{Lab}(A,v_0)\Vert\operatorname{Lab}(A,v_1)
\in \operatorname{Range}(G^{\mathrm{tree}}).
\tag{4}
\]

这是真正的 tree-compatible、word-consistent closure；它不是只为每个 leaf
分别寻找 preimage。

## 全局 seed 的精确预算

系数张量有 \(D^m\) 个 field symbols。因此一个直接的 internal-mode 编码需要携带

\[
q_{\mathrm{root}}=D^m b+O(m\log|F|+\log t')
\tag{5}
\]

个 bits，才能无损区分全部 root polynomials。对 \(H^m\) 上任意 value table
\(w:H^m\to F\)，低度插值是双射；所以若 decoder 要覆盖所有这些可能的
completeness witnesses，则 root labels 至少有 \(|F|^{D^m}\) 个不同值，而
q-bit seed 至多只有 \(2^q\) 个值。于是

\[
q\ge D^m\log_2|F|.
\tag{6}
\]

式 (6) 是信息计数，不依赖 decoder 的线性、系统性或具体 gate layout。

## 代入 Harsha/Ren--Williams 参数

Ren--Williams/Harsha 取

\[
m=\left\lceil\frac{\log t'}{\log\log t'}\right\rceil,
\qquad
D=t'^{1/m}=\Theta(\log t'),
\]

从而

\[
D^m=\Theta(t'),
\qquad
q_{\mathrm{root}}=\Theta(t'\log|F|).
\tag{7}
\]

而 note 129 的单 line restriction 只需

\[
q_{\mathrm{line}}=\operatorname{polylog}(t').
\tag{8}
\]

这正是两种尺度的本质差别：line restriction 的自由度约为一条线的 degree，
global polynomial 的自由度约为 \(D^m=t'\)。在通常的 forcing 参数
\(t'=2^{\Theta(n)}\) 下，若把 AVOID seed 取到 \(q\asymp q_{\mathrm{root}}\)，
JK easy branch 的大小已经是指数于 \(n\) 的量级，不能与仅有
\(n^{k(n)}\) 的 forcing 下界形成所需矛盾。

## 不应过度外推的边界

式 (6) 只排除“覆盖所有 witness tables 的全局代数标签器”。对一个固定输入
family \(x\mapsto\Pi_x\)，实际出现的 root polynomials 可能只有 \(2^n\) 个，
因此纯信息论只给 \(q\ge n\)，并不能排除 \(q=\operatorname{poly}(n)\)。但是要
达到这个较小 q，必须额外构造一个统一的、地址可访问的压缩映射

\[
(x,\text{history index},\text{bit address})
\longmapsto
\operatorname{Lab}(A_x,v)[i]
\]

并证明它与 JK 的同一整词 preimage 兼容。Ren--Williams Theorem 3.5 只给出
completeness proof 可在 \(\operatorname{poly}(t')^{NP}\) 资源内生成；它没有给出
上述 \(n^{O(1)}\)-scale whole-tree accessor。

因此当前严格分层是：

\[
\begin{array}{c|c}
\text{单 line algebraic decoder}
  & q=\operatorname{polylog}(t')\\
\text{全局多变量 restriction labeler}
  & q=\Theta(t'\log|F|)\\
\text{RW 所需的固定 history 小 q labeler}
  & \text{unknown}
\end{array}
\]

最后一行若能在 \(q=\operatorname{poly}(n)\) 且保持 smartness/word consistency 的
条件下完成，将直接落入 note 121 的充分条件并推出 \(P\ne NP\)；本 note 不声称
该接口已经存在。

## 文献边界

Harsha 的 ZERO-ON-SUBCUBE 与 CIRCUIT-SAT completeness 构造、以及
Ren--Williams Theorems 3.4--4.1 的参数见：

- [Harsha official thesis](https:/[unbundled local reference].ttic.edu/~prahladh/papers/thesis/phdthesis.pdf)；
- [Ren--Williams official report](https://eccc.weizmann.ac.uk/report/2026/118/revision/1/download)。

本 note 的 restriction-labeler 是对这些低度多项式对象的自足组合构造；式 (6)--(8)
是参数和信息边界，不是已发表的 decoder lower bound，也不等价于 \(P\ne NP\)。
