> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Finite-randomness selected-policy phase diagram（2026-08-19）

## 本轮改变的判断

note 467 把 selected-policy 的固定 gap \(\alpha>\beta\) 编译成
perfect-complete、zero-wrong-output 的 nonadaptive RLDC；这里把该修复与
Sauer--Shelah 的 policy-fiber entropy 账本合并。结果是一个二择一：在
near-linear proof 长度下，若 selected-policy vector 没有携带几乎全部 target
entropy，则 verifier 的 finite public view 必须至少支付
\(\log\log K\) 级 locality。这个结论把 completeness gap、policy information
和 public-randomness/decision-tree 资源放进同一个可计算相图。

它仍是 shared-proof、selected-policy fiber 的 barrier theorem，不是一般 dPCP
不可能性，也不把 published RW singleton 自动提升为该 family interface。

## 定理 468.1（finite-randomness selected-policy phase diagram）

令
\[
  \Pi:\{0,1\}^{K}\longrightarrow\Sigma^{P},
  \qquad |\Sigma|=A\ge2,
\]
为一个 common proof map。每个 target \(m\) 与 coordinate \(i\) 选择一个
deterministic policy \(\tau_{m,i}\)，并令
\[
  S(m)=(\tau_{m,1},\ldots,\tau_{m,K}).
\]
假设每个 fixed policy/claim branch：

* 使用至多 \(r\) 个 public-random bits；
* 至多自适应查询 \(q\ge1\) 个 proof symbols；
* 对固定常数 \(\alpha>\beta\) 与 \(0<\rho<1\)，满足 note 467 的
  correct-claim completeness 和 \(\rho P\)-近 proof wrong-claim soundness。

令 \(M\) 在 \(\{0,1\}^{K}\) 上均匀，令 \(S=S(M)\)，并假设对某个
\(0\le\gamma<1\)，
\[
  I(M;S)\le\gamma K.
  \tag{468.1}
\]
记 \(\vartheta_\gamma\in(0,1/2]\) 满足
\[
  h_2(\vartheta_\gamma)=1-\gamma,
\]
并取任意固定 \(0<\varepsilon<\vartheta_\gamma\)。定义
\[
  d:=\left\lfloor(\vartheta_\gamma-\varepsilon)K\right\rfloor,
  \qquad
  T_q(A):=\sum_{j=0}^{q-1}A^j,
  \qquad
  Q:=1+2^rT_q(A),
  \qquad
  \widehat A:=A+2.
  \tag{468.2}
\]

Then, for all sufficiently large \(K\) on which the GGS radius condition
\[
  \delta_\rho>(d+P)^{-1/(2Q)}
  \tag{468.3}
\]
holds (where \(\delta_\rho=\delta_\rho(\rho,A)>0\) is the tagged-code radius
from note 467),
\[
  d+P\ \ge\
  \left(
    \frac{d}
    {38Q^4\log_2^2(\widehat A)\log_2^2(d+2)}
  \right)^{1+1/Q}.
  \tag{468.4}
\]
Equivalently,
\[
  P\ \ge\
  \left(
    \frac{d}
    {38Q^4\log_2^2(\widehat A)\log_2^2(d+2)}
  \right)^{1+1/Q}-d.
  \tag{468.5}
\]

Consequently, if \(P\le K(\log(K+2))^c\) on an infinite sequence, then on that
sequence either (468.3) fails and
\[
  Q\ge \frac{\log(d+P)}{2\log(1/\delta_\rho)},
  \tag{468.6}
\]
or (468.4) holds and
\[
  Q=\Omega_{A,\rho,\gamma,\varepsilon,c}
       \left(\frac{\log K}{\log\log K}\right).
  \tag{468.7}
\]
In particular, every such near-linear construction must satisfy
\[
  1+2^rT_q(A)
  =\Omega\left(\frac{\log K}{\log\log K}\right),
  \tag{468.8}
\]
and hence
\[
  r+\log_2T_q(A)
  \ge
  \log_2\log K-\log_2\log\log K-O_{A,\rho,\gamma,\varepsilon,c}(1).
  \tag{468.9}
\]

For nonadaptive selected branches, \(T_q(A)\) in (468.2) is replaced by \(q\), so
the visible resource is exactly \(r+\log_2 q\) up to an additive constant.

## 证明

By the mutual-information hypothesis and the standard conditional-entropy argument,
some policy fiber \(F_s=\{m:\Pr[M=m\mid S=s]>0\}\) has support at least
\(2^{(1-\gamma)K}\). Sauer--Shelah and the definition of
\(\vartheta_\gamma\) give a shattered coordinate set of size at least \(d\) for
all sufficiently large \(K\).

Choose representatives on that shattered set. The common policy on the fiber and the
\(\alpha>\beta\) hypotheses imply that their proof words are pairwise farther than
\(\rho P\), exactly as in note 467. Inline the shattered bits with two disjoint tags.
For each public tape, enumerate the complete depth-\(q\) proof-answer tree. The union
over all \(2^r\) tapes has at most \(2^rT_q(A)\) proof-symbol positions, so the
decoder is nonadaptive with total locality \(Q\), including the inline query.

Threshold the exactly computed acceptance rate at
\(t=(\alpha+\beta)/2\). On an uncorrupted codeword the correct inline claim passes,
so completeness is perfect. If the inline bit is wrong while the proof suffix remains
inside the \(\rho P\) ball, the wrong branch is below threshold; hence the decoder
outputs \(\bot\), never the wrong bit. If the inline bit is correct, it can output only
that bit or \(\bot\). Thus the derived code is a perfect-complete RLDC with
**zero wrong-output probability**, i.e. soundness parameter \(\sigma=1\) in the
GGS Definition 3.3, not merely an imperfect-complete semantic decoder.

Apply the arbitrary finite-alphabet nonadaptive RLDC lower bound of
Goldberg--Gur--Saraogi to the inline code of length \(d+P\), alphabet \(\widehat A\),
query count \(Q\), and \(\sigma=1\). Its displayed lower-bound function is exactly
(468.4), provided (468.3) holds. If (468.3) fails, taking logarithms gives (468.6).
The near-linear implication (468.7) is the same exponent calculation as the
GGS phase diagram: with \(Q=o(\log K/\log\log K)\), the exponent increment
\(1/Q\) beats every fixed polylogarithmic overhead, contradicting (468.4).
Finally substitute \(Q=1+2^rT_q(A)\) and take logarithms to obtain (468.8)--(468.9).
\(\square\)

## 证据边界与研究含义

1. 这里调用的是 GGS 的 nonadaptive arbitrary-finite-alphabet lower bound；其半径
   条件、标签字母表和 query convention 必须按 (468.2)--(468.3) 对齐，不能把该
   推论外推到未满足这些条件的 randomized semantics。
2. 定理需要 common proof、selected-policy fiber、有限 public randomness、有限
   proof alphabet 和 supportwise target-relative soundness。隐藏/连续 randomness、
   target-dependent physical proof 或 ordinary average/list soundness 不在范围内。
3. (468.8) 是一个资源下界，不是 simultaneous coordinate-robust PCP 的构造，
   也不排除 policy vector 本身携带 \(K-o(K)\) bits；后者正是
   \(I(M;S)>\gamma K\) 的另一条逃逸。
4. 对 RW/JK 的直接影响是：只要实际 canonical history 能被提升到这个 selected-policy
   common-proof interface，有限 public randomness 不能作为廉价的 completeness
   修补；near-linear proof 必须支付 visible locality 或 target information。它仍
   没有提供 actual RW singleton 的 Gate-I attachment，也没有给出 \(P\ne NP\)。

## 来源

* [note 467 finite-randomness completeness repair](467-finite-randomness-completeness-repair-selected-policy-rldc-2026-08-19.md)。
* [note 350 quantitative proof--policy information tradeoff](350-quantitative-proof-policy-information-tradeoff-2026-08-18.md)。
* [note 351 information-budget phase diagram](351-information-budget-proof-length-phase-diagram-2026-08-18.md)。
* Goldberg--Gur--Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally Decodable Codes via Robust Daisies*, Theorem 1 and Definition 3.3: [arXiv:2511.21659](https://arxiv.org/abs/2511.21659).
