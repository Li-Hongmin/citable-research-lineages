> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW systematic prefix 可强制 JK tree outsider（2026-08-15）

## 结论

note 106 的多层容量障碍可以嵌入一条实际的 Ren--Williams history，而不需要假设
auxiliary PCP oracle 的 provenance。关键是取一个没有 NP query 的 machine：此时
Theorem 3.5 使用的 history/input assignment 只有 output 字段；完整 SAT witness
另含 intermediate-gate values。Reed--Muller systematic prefix 仍直接从我们指定的
multi-output string 开始。

设

\[
G_q:\{0,1\}^{q}\to\{0,1\}^{2q},
\qquad
R_q=\operatorname{Range}(G_q),
\qquad
q=2^{m-1}.
\]

假设 \(G_q\) 是一个可由 \(q\) 在统一算法中取得的合法 RW/AVOID 电路实例，且其语法大小
满足 \(q\le |G_q|\le q^4\)；若原 decoder 更小，可用标准 dummy-gate padding 达到下界。
以下取 \(q(n)=2^n\)、\(m(n)=n+1\)，并要求 \(\ell(n),h(n),T_0(n)\) 都是
nice、time-constructible 的 schedules。

若 \(A\subseteq R_q\) 满足

\[
|A|^{2^h}>2^q,
\tag{1}
\]

且 \(A\) 有一个 uniform、按 index/coordinate 可计算的枚举，则存在一个 uniform、零
NP-round 的 RW multi-output machine，使得把它的 PCP proof 交给 JK 后，前 \(h\) 个 tree
stages 之内必返回 non-range outsider。若 \(A\) 只有非均匀给定，则同一构造只给非均匀
machine。

这只给出一个 concrete history-forcing 结果；它还没有把 outsider 变成 \(P\ne NP\) 分离。

## 显式 pair/tree-rich 输出

给定 \(A=\{a_1,\ldots,a_M\}\subseteq R_q\)，按字典序枚举所有
\(A^{2^h}\) tuples。对每个 tuple
\[
(a_v)_{v\in\{0,1\}^{h}},
\]
输出连续的 \(2^h\) 个 \(2q\)-bit blocks，依次为这些 \(a_v\)。在全部 tuples 后输出
零 blocks。若 \(0^{2q}\notin R_q\)，padding 已立即给出 outsider；以下为排除这个平凡
情形而假设 \(0^{2q}\in R_q\)。令原始输出长度 \(T_0\)
是 \(2q\) 的倍数且满足

\[
T_0\ge 2q\cdot 2^h|A|^{2^h}.
\]

令 \(k\) 满足

\[
2^{k-1}\ge 2^h|A|^{2^h},
\]

且令 \(T'=q2^k\) 大于 \(T_0\) 及 machine/compiler 产生的未补零 proof 长度；由已知的
polynomial proof-length bound 选取 \(k\)，故该 \(T'\) 也是 nice、time-constructible 的
schedule。按 JK 定理先把 proof 补零到 \(T'\)，再从开头切成 \(2q\)-bit blocks；这样顶层至少有
\(2^h|A|^{2^h}\) 个 blocks，足以容纳每个 tuple group。这个 multi-output function 只需
解码 output address、tuple index、leaf index 和一个 truth-table coordinate，就能查出对应
\(a_v\) 的 bit，因此在上述 uniform 枚举下是 uniform 且可在输出长度的多项式时间内生成；
它完全忽略输入，也不发 NP query。

## 为什么它确实进入 RW systematic prefix

对上述 machine，query-round 数 \(r=0\)。RW Lemma 3.2 的 history

\[
\operatorname{hist}=(\operatorname{out})
\]

没有 query-count 或 NP-witness 字段。完整的 CIRCUIT-SAT satisfying witness 仍可在该
assignment 后附带 intermediate-gate values；按 RW/PCP 的 witness convention，assignment
的 output 前缀位于编码最前。Theorem 3.4--3.5 的 systematic Reed--Muller encoding
因而给出一个 PCP proof \(\Pi_x=(\widetilde w,\Pi')\)，其中 \(\widetilde w\) 是该
assignment 的编码，且

\[
\Pi_x[1..T_0]=F_{q,A,h}(x).
\tag{2}
\]

式 (2) 只使用 theorem-level systematic prefix；不依赖 \(\Pi'\) 的 field ordering、PCP
auxiliary serialization 或 machine compiler 的 intermediate-gate order。

## JK stage forcing

JK 按上述标准先把 \(\Pi_x\) 补零到 \(T'=q2^k\)，再从开头切成 \(2q\)-bit blocks。
式 (2) 保证所有指定 groups 的顶层 blocks 都属于 \(A\subseteq R_q\)，且在上述非平凡
情形下 padding blocks 也属于 \(R_q\)。因此如果 JK 在顶层没有
立即找到 non-image，它会为每个 block 选一个 \(q\)-bit preimage，并把相邻 preimages
串接到下一 stage。

假设某个 group 在前 \(h\) stages 始终没有 non-image。它就给出 note 106 中的一个深度
\(h\) witness tree。对不同的 leaf tuples，根部 \(2q\)-bit blocks 两两不同；否则从根部
向叶递归解开每个 \(q\)-bit half，并应用 \(G_q\)，会得到相同的 leaf tuple。因此所有
groups 若都保持在 range，就产生

\[
|A|^{2^h}>2^q\ge |R_q|
\]

个不同的 range roots，矛盾。故至少一个 group 在深度至多 \(h\) 处产生 non-range block，
JK 返回 non-range outsider。

这个论证允许 JK 为每个 occurrence 选择任意 preimage；不要求 lex-first 的 choices 在不同
groups 之间一致。

## 局部小 preimage 闭包的反证

上面的 forcing 还可以把“canonical preimage 可能很复杂”的问题精确化。令
\(m=\log_2(2q)\)。对一个 occurrence \(v\)，称其 \(q\)-bit preimage
\(u_v\) 有 \(a_q\)-local accessor，若存在一个 \(m-1\)-variable circuit
\(U_v\) 满足

\[
U_v(z)=u_v[z],\qquad z\in\{0,1\}^{m-1},
\qquad \operatorname{CC}(U_v)\le a_q.
\tag{4}
\]

假设一个 tree-rich prefix 具有如下 **local inverse closure**：顶层叶 occurrence 可以各自
选择 \(a_q\)-local preimage；只要某个由两个已选 preimages 串接而成的 parent block 仍在
\(R_q\)，就能为该 parent occurrence 再选择一个 \(a_q\)-local preimage，继续到下一层。
这个假设允许每个 occurrence 选择不同的 circuit，不要求 lex-first，也不要求 selector 在
occurrence 之间共享。

若某个 parent block \(z_v=u_{v_L}\Vert u_{v_R}\) 不在 \(R_q\)，则它本身是一个
\(m\)-variable truth table：

\[
Z_v(b,z)=
\begin{cases}
U_{v_L}(z),&b=0,\\
U_{v_R}(z),&b=1.
\end{cases}
\tag{5}
\]

故

\[
\operatorname{CC}(Z_v)\le 2a_q+O(1).
\tag{6}
\]

对所有 \(A^{2^h}\) leaf tuples 运行这个选择规则时，note 106 的 injectivity 保证在
\(2^h\log_2|A|>q\) 时某个 occurrence 必在前 \(h\) 层成为 non-image。于是得到：

\[
\boxed{
A\subseteq\mathcal C_{m,s},\quad
2^h\log_2|A|>q,\quad
\mathcal C_{m,s}\subseteq R_q,\quad
2a_q+O(1)\le s
\quad\Longrightarrow\quad
\text{tree-rich prefix 上的 }a_q\text{-local inverse closure 不可能}.
}
\tag{7}
\]

证明不需要计算哪个 occurrence 先失败；对每个固定 \(q\)，容量先给出一个失败 occurrence，
式 (5)--(6) 再给出一个 size-\(\le s\) 的 non-range truth table，与 coverage 矛盾。该结果
严格区分两件事：它排除了“所有递归 choices 都保持同一小 accessor”的表示架构，但没有说明
published lex-first choice 必然复杂，也没有把 occurrence-specific 的非一致 choices 变成 uniform
NP 算法。因此它是 canonicalization 缺口的结构性 no-go，而不是 \(P\ne NP\) 证明。

同一论证也可写成一个不带 closure 假设的下界式。若
\(\mathcal C_{m,s}\subseteq R_q\) 且 \(2^h\log_2|A|>q\)，则任意在该
tree-rich prefix 上对全部 \(A^{2^h}\) groups 逐 occurrence 选择 preimages 的完整 process
（某个 parent 不在 range 时就在该处停止），都满足：

\[
\boxed{
\text{在停止前已选出的某个 occurrence }v\text{ 上，}\quad
\operatorname{CC}(U_v)>\frac{s-O(1)}2 .
}
\tag{8}
\]

更直接地，若所有已选 \(U_v\) 都有
\(\operatorname{CC}(U_v)\le (s-O(1))/2\)，则每一个由两个 child 组成的 parent 都是
size-\(\le s\) 的 truth table；coverage 会迫使它继续属于 \(R_q\)。容量式 (1) 最终又迫使
某个 parent non-range，矛盾。因此 coverage 并不保证存在一个小的 recursive inverse；它反而
迫使每条完整的 range branch 暴露出一个复杂 preimage accessor。这个 lower bound 针对任意
occurrence-wise choices，包含 published lex-first choices，但仍只是 accessor complexity
下界，不是对 block 本身的 circuit lower bound，也不等于 \(P\ne NP\)。

## 低电路 family 的参数

令 \(\mathcal C_{m,s}\) 是 size-\(\le s\) 的 \(m\)-variable truth tables。若 decoder coverage
满足

\[
\mathcal C_{m,s}\subseteq R_q,
\]

取整数 \(\ell\le m\)，并按固定完备 basis 的 Lupanov 常数（吸收 basis simulation 的
固定常数 slack）选择

\[
\frac{2^\ell}{\ell}\le c_0s,
\]

使全部 \(\ell\)-variable functions 都有 size-\(\le s\) 的实现。令

\[
A_\ell=\{h(x_1,\ldots,x_\ell):
h:\{0,1\}^{\ell}\to\{0,1\}\},
\qquad
|A_\ell|=2^{2^\ell}.
\]

这里把每个 \(h\) 视为 \(m\)-variable function，忽略剩余的 \(m-\ell\) 个 variables。

当

\[
2^h\,2^\ell>q
\tag{3}
\]

时，\(|A_\ell|^{2^h}>2^q\)，所以前述 concrete history 必在 \(h\) 层内产生 outsider。
由 Lupanov 的 \(2^\ell/\ell=O(s)\) 关系，若
\(s=q/\log^{1+\varepsilon}q\)，可以取
\(2^\ell=\Theta(q/\log^\varepsilon q)\)，而

\[
h=O(\log\log q)
\]

足以满足式 (3)。这把 note 106 的 universal tree obstruction 实现到一个明确的 RW
systematic-prefix history 上。

要得到一族而非单个参数的 uniform machine，可取 nice schedule
\(q(n)=2^n\)、\(m(n)=n+1\)，并令 \(\ell(n)\)、\(h(n)\) 按上述可计算公式选择；输出长度
\(T_0(n)\) 的二进制描述以及每个 output bit 都能在 \(\operatorname{poly}(\log T_0)\)
或输出总时间内取得。这里的 uniformity 只针对显式的 \(A_\ell\) family，不依赖从
\(a\in R_q\) 反求 preimage。

## 尚未解决的桥

这个 construction 的 machine 只是输出一个人为设计的 tree-rich string。它证明：

\[
\text{coverage}+\text{RW systematic prefix}
\Longrightarrow
\text{某条 concrete history 产生 outsider}.
\]

但它没有证明：

1. 该 outsider 属于一个固定 NP/EXP 语言的统一 hard witness family；
2. outsider 的生成或其 range-membership 能力导致 \(P=NP\) 矛盾；
3. 原 Ren--Williams lower-bound construction 所需的 PCP history 同时具有这种 richness。

因此当前最窄剩余接口是：把这个可控的 \(r=0\) history forcing 与固定复杂度下界、而不是
仅与任意输出 string，连接起来。不能把式 (1)--(3) 直接改写成 \(P\ne NP\)。

### 来源与证据边界

- Ren--Williams, ECCC TR26-118 revision 1，Theorem 3.5：\(r=0\) 时 systematic witness
  prefix 与输出字段的关系。
- Ren--Williams, Theorem 3.1：JK 的 stage-wise blocks 与 preimage concatenation。
- note 106：多层 tree-capacity injectivity。

本 note 的 machine 与 history-forcing construction 是项目内自足推导；不依赖未规范化的
auxiliary PCP suffix，也不宣称 \(P\ne NP\)。
