> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Systematic PCP block 的 preimage-accessor 障碍（2026-08-14）

## 结论

[note 078](078-relativization-interactive-compression-and-smart-prma-frontier-2026-08-14.md)
提出 Local-JK-preimage lemma：对 Ren--Williams encoded history 中实际出现、且属于 canonical
truth-table decoder range 的 block，寻找 compact 的 canonical preimage accessor。本 note 证明：
若该命题要求一个 ordinary Boolean circuit 逐位输出 preimage，则即使限制到 RW systematic PCP proof
的第一个实际 block，仍不存在 exponent 独立于 multi-output function 的 ordinary
poly\((n)\) universal accessor。

精确地，对每个整数常数 \(c\ge 1\)，存在常数 \(a_c\) 和一个 uniform deterministic
multi-output function \(f_c:\{0,1\}^n\to\{0,1\}^{t_c(n)}\)，其中可取 nice time bound

\[
t_c(n)=2^{n^{a_c}},
\tag{1}
\]

以及一列 canonical AVOID instances

\[
G_q:\{0,1\}^q\to\{0,1\}^{2q},
\qquad
q=2^{\lceil(\lfloor\log\log n\rfloor+C)\log_2 n\rceil}
=n^{\lfloor\log\log n\rfloor+O(1)},
\tag{2}
\]

使得 RW Theorem 4.1 在 \((f_c,G_q)\) 上调用 Jeřábek--Korten 时，PCP proof 的第一个
\(2q\)-bit block \(z_n\) 满足

\[
z_n\in\operatorname{Range}(G_q),
\tag{3}
\]

但

\[
\forall u\in G_q^{-1}(z_n):
\operatorname{CC}(i\mapsto u_i)>n^c.
\tag{4}
\]

所以 RW encoded-history、systematic PCP 与 canonical decoder 三项限制本身仍不足以推出
exponent 独立于 \(f\) 的 ordinary \(n^{O(1)}\)-size local preimage circuit。这个无条件结果不排除
\(\forall f\,\exists d_f\) 的 function-dependent polynomial bound，更不排除
poly\((n,\log t_f)\) bound。这个无条件结论本身不决定后一尺度；对当前 \(P\) vs \(NP\) 目标，
保留的候选接口包括利用 exact stitched machine \(M_A\) 的结构，或保留真正的 smart-prMA bit
access，而不能只说 block “来自 RW history”。

这个结果不排除

\[
smart\text{-}P^{prMA}/1
\tag{5}
\]

accessor。promise oracle 的作用正是允许无条件 ordinary circuit simulation 不成立；若 \(P=NP\)，
smart substitution 才把它降为 P/poly 并产生目标矛盾。

## Canonical range 中的 accessor-incompressible preimages

由式 (2)，\(2q\) 是二次幂；令 \(m=\log_2(2q)\)。固定一个有限 Boolean basis 和 fan-in-two
canonical circuit encoding，并令 \(G_q\) 解码长度恰为 \(q\) 的 descriptions，输出相应
\(m\)-variable function 的 \(2q\)-bit truth table。合法短描述可 padding 到长度 \(q\)，且 padding
不改变所编码函数；非法描述按固定 canonical 规则处理。标准 gate-list encoding 中每个 gate 使用
\(O(\log q)\) bits，因此存在与 \(q\) 无关的常数 \(a>0\)，使 range 包含所有由 size

\[
s_q=a q/\log q
\tag{6}
\]

circuits 计算的 truth tables。

取

\[
t_q=\left\lfloor\alpha\frac{q}{\log^2 q}\right\rfloor
\tag{7}
\]

其中 \(\alpha>0\) 相对 encoding 常数足够小。任意 \(t_q\)-element subset
\(A\subseteq[2q]\) 的 indicator truth table 可由 full DNF 计算，size 为

\[
O(t_qm)=O(q/\log q)\le s_q.
\tag{8}
\]

故这些 sparse tables 全部属于 \(\operatorname{Range}(G_q)\)。它们的数量满足

\[
\begin{aligned}
\log_2\binom{2q}{t_q}
&=\Omega\!\left(t_q\log\frac{2q}{t_q}\right)\\
&=\Omega\!\left(\frac{q\log\log q}{\log^2 q}\right).
\end{aligned}
\tag{9}
\]

另一方面，在同一个固定 finite basis 与 fan-in-two 模型中，令 \(\mathcal A_S\) 为 size 至多
\(S\) 的 circuits

\[
A:\{0,1\}^{\lceil\log q\rceil}\to\{0,1\}.
\tag{10}
\]

每个 \(A\) 定义一个 \(q\)-bit string \(u_A\)，其中 \(u_A[i]=A(i)\)。标准 circuit counting 给出

\[
|\mathcal A_S|
\le 2^{O(S\log(S+\log q))}.
\tag{11}
\]

每个 low-accessor string \(u_A\) 经 \(G_q\) 最多贡献一个 range element。取

\[
S_q=\beta\frac{q\log\log q}{\log^3 q}
\tag{12}
\]

且 \(\beta>0\) 相对式 (9) 的常数、\(\alpha\) 与 circuit-counting 常数足够小，则

\[
\log|\mathcal A_{S_q}|
<
\log\binom{2q}{t_q}
\tag{13}
\]

对充分大 \(q\) 成立。因此存在一个 sparse \(z\in\operatorname{Range}(G_q)\)，使

\[
\forall u\in G_q^{-1}(z):
\operatorname{CC}(i\mapsto u_i)>S_q.
\tag{14}
\]

这把 note 078 的一般 padded-identity sanity check 加强为 canonical truth-table decoder 自身的
range 内反例；accessor lower bound 近线性于 description length，损失仅 polylogarithmic factors。

## 把计数反例 uniform 地放入实际 RW block

固定常数 \(c\)，并取式 (2) 的 \(q\)，使

\[
n^c<S_q
\tag{15}
\]

对充分大 \(n\) 成立。下面给出一个 deterministic algorithm 构造所需 \(z_n\)。

1. 枚举所有 size 至多 \(n^c\) 的 accessor circuits \(A\)，计算 \(u_A\) 与 \(G_q(u_A)\)。
2. 按 lexicographic order 枚举式 (7) 的 sparse truth tables。
3. 输出第一个不属于集合
   \[
   \{G_q(u_A): |A|\le n^c\}
   \tag{16}
   \]
   的 sparse table \(z_n\)。

式 (9)--(15) 保证算法必定停止，且输出满足 (3)--(4)。accessor circuits 的数量 \(N_c\) 满足

\[
N_c\le 2^{O_c(n^c\log n)}.
\tag{17}
\]

最多检查 \(N_c+1\) 个 sparse candidates；即使使用直接 pairwise comparison，构造时间
\(R_c(n)\) 仍满足

\[
R_c(n)\le 2^{O_c(n^c\log n)}.
\tag{18}
\]

输出长度 \(2q\) 和每次 decoder evaluation 均被该上界吸收。选择足够大的常数 \(a_c\)，可使
\(t_c(n)\ge R_c(n)\) 且 \(t_c(n)\ge2q\)。

令 deterministic machine \(M_c\) 对每个 \(x\in\{0,1\}^n\) 忽略 \(x\) 的内容，计算 \(z_n\)，
并输出

\[
f_c(x)=z_n0^{t_c(n)-2q}.
\]

它在 nice bound \(t_c(n)\) 时间内运行且不发出 NP queries，因而满足 RW Theorem 4.1 对输出长度
恰为 time bound 的接口。RW Lemma 3.2 中

\[
r(n)=0
\quad\Longrightarrow\quad
r'(n)=0,
\tag{19}
\]

而 history variable order 是 \((y_1,\ldots,y_r,out,z,\ldots)\)；当 \(r=0\) 时，raw satisfying
assignment 的 prefix 正是唯一确定的 \(out=f_c(x)\)。RW Theorem 3.4 使用 systematic
Reed--Muller encoding，原 witness 作为 encoding prefix 保留。因此 Theorem 4.1 的
\(\mathsf{Solve}_{f_c}\) 所采用的 completeness proof \(\Pi_x\) 的前 \(2q\) bits 恰为

\[
\Pi_x[1..2q]=z_n.
\tag{20}
\]

Jeřábek--Korten 在 Theorem 3.1 的第一 stage 将 \(\Pi_x\) 机械切成连续 \(2q\)-bit blocks，
并为各 blocks 并行形成 SAT preimage queries；其中第一个 block 的 query 是

\[
\exists u\in\{0,1\}^q:\ G_q(u)=z_n.
\tag{21}
\]

由 (3)，该 query 为 YES。任何声称为这个实际 block 输出 size \(n^c\) ordinary circuit、逐位计算
某个合法 preimage 的 Local-JK theorem，都会与 (4) 矛盾。

这里必须区分 ordinary poly\((n)\) 与 poly\((n,\log t_c)\)。上述无条件构造给出的严格量词结论仅是

\[
\boxed{
\forall c\ge1\;\exists f_c\;\exists n_0(c)\;\forall n\ge n_0(c):
\min_{u\in G_q^{-1}(z_{c,n})}
\operatorname{CC}(i\mapsto u_i)>n^c
}
\tag{22}
\]

因此不存在常数 \(C,d\) 对所有 multi-output functions 都给出 size 至多 \(Cn^d\) accessor 的
universal theorem：给定 \(C,d\)，在式 (22) 中取 diagonal exponent \(c=d+1\) 即可。但构造 \(f_c\) 时
\(\log t_c=n^{a_c}\)，而 \(a_c\) 依赖于 \(c\)。增加对角化指数也同时增大 \(\log t_c\)；这个
无条件论证完全不能排除 poly\((n,\log t_c)\) accessor，甚至不能排除 \(O(\log t_c)\) size。

## 在 \(P=NP\) 假设下消除时间参数循环

固定 accessor threshold \(S(q)=\lfloor\sqrt q\rfloor\)。对一个长度至多 \(2q\) 的 prefix \(p\)，
定义

\[
\operatorname{ExtBad}(1^q,p)
\iff
\exists z\in\{0,1\}^{2q}\:
\left[
p\preceq z
\ \land\ |z|_1=t_q
\ \land\
\forall A,\ |A|\le S(q):
G_q(u_A)\ne z
\right].
\tag{23}
\]

unary parameter \(1^q\) 使输入长度为 \(\Omega(q)\)；\(z\) 与 \(A\) 的 descriptions 均为
\(q^{O(1)}\) 长。给定 \((z,A)\)，在全部 \(q\) 个 addresses 上求值 \(A\)、组成 \(u_A\) 并计算
\(G_q(u_A)\)，也只需 \(q^{O(1)}\) 时间。因此上述显式编码的语言
\(\operatorname{ExtBad}\) 属于 \(\Sigma_2^P\)。由于 \(\sqrt q=o(S_q)\)，式 (9)--(14) 保证
\(\operatorname{ExtBad}(1^q,\epsilon)\) 对充分大 \(q\) 为 YES。

若 \(P=NP\)，则 \(PH=P\)，所以存在一个固定 deterministic \(q^{K_0}\)-time decider \(D\) 判定
\(\operatorname{ExtBad}\)。从空 prefix 开始，逐 bit 查询 \(D(1^q,p0)\)，若为 YES 就附加 \(0\)，
否则附加 \(1\)；经过 \(2q\) 步得到 lexicographically first 坏 sparse table \(z_n\)。取整数常数
\(K\ge K_0+2\)，则整个 selector、写出 \(2q\) bits 以及后续 padding 的成本均为 \(O(q^K)\)。

取 nice bound \(t_*(n)=q(n)^K\)，并像上节一样把输出 padding 为
\(f_*(x)=z_n0^{t_*(n)-2q}\)。于是，在 \(P=NP\) 假设下存在一个固定 uniform deterministic
multi-output function \(f_*\)，使对充分大 \(n\)

\[
\min_{u\in G_q^{-1}(z_n)}
\operatorname{CC}(i\mapsto u_i)>\sqrt q,
\qquad
\log t_*(n)=O(\log q)=O(\log n\log\log n).
\tag{24}
\]

故对每个 fixed \(d\)，充分大 \(n\) 上都有

\[
\sqrt q>(n+\log t_*(n))^d.
\tag{25}
\]

这是真正针对 poly\((n,\log t)\) 的 conditional barrier，且同一个 \(f_*\) 同时击败所有 fixed
exponents。它不把 \(P=NP\) 当成已知事实：结论的准确形式是
“若 \(P=NP\)，则这样的固定 selector machine 存在”。这个 machine 仍是 adversarial
multi-output function，不是 exact stitched \(M_A\)。

## 为什么这不关闭 smart-prMA 与 exact \(M_A\)

式 (14) 只对 ordinary Boolean circuits 给下界。一个 smart-prMA oracle machine 可在不形成小 ordinary
circuit 的情况下逐位回答 preimage；若 \(P=NP\)，promise separator 才属于 P，并把该 accessor
编译为 ordinary polynomial circuits。这个 conditional collapse 正是候选证明所需的矛盾，不能被
无条件 counting 排除。

此外，\(f_c\) 是为击败给定 accessor exponent 而构造的 adversarial multi-output function，不是
note 076 的 SAT-machine-dependent stitched \(M_A\)。因此无条件式 (22) 与条件性式 (25) 关闭的
都是相应参数范围内

\[
\text{“RW systematic history + canonical }G_q\text{ 对所有 }f\text{ 自动可局部求逆”},
\tag{26}
\]

不是

\[
\text{“exact stitched }M_A\text{ 的 reachable blocks 可局部求逆”}.
\tag{27}
\]

当前保留的两条候选接口是：

\[
\begin{cases}
\text{利用 }M_A\text{ 的 lex-AVOID/self-reduction 特殊结构；}\
\text{或只要求 compact smart-prMA bit access，不要求返回 ordinary local circuit。}
\end{cases}
\tag{28}
\]

## 历史文献边界

Hirahara--Ilango--Williams 2024 Theorem 1.2 对任意 polynomial-time compression map
\(Eval:\{0,1\}^s\to\{0,1\}^N\) 给出 worst-case inverter circuits，size 为

\[
2^{4s/5}\operatorname{poly}(N,s).
\tag{29}
\]

其 Theorem 1.3 对 Search-MCSP 使用近最优 circuit encoding，得到指数
\(4/5\) 的 generic inversion improvement。应用到 \(G_q\) 时，式 (29) 是

\[
2^{4q/5}\operatorname{poly}(q),
\tag{30}
\]

远大于本项目所需的 poly\((n+\log t)\)。它说明 generic compression 可以严格优于 exhaustive
search，却没有把 description length \(q=n^{\Theta(\log\log n)}\) 消去；也不与 (14) 冲突。

检索与原文核验日期：2026-08-14。

- Hanlin Ren and Ryan Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin-Arthur Queries*, ECCC TR26-118, revision 1, 2026, Theorems 3.1, 3.4, 3.5 and 4.1.
- Shuichi Hirahara, Rahul Ilango, and R. Ryan Williams, *Beating Brute Force for Compression
  Problems*, STOC 2024, DOI `10.1145/3618260.3649778`, Theorems 1.2 and 1.3; open ECCC version
  TR23-171.

RW 的 systematic PCP prefix、JK block decomposition 和 HIW inverter upper bounds 是文献直接支持
的事实。式 (9)--(28) 是本项目的 counting、uniform diagonalization 与参数组合推论。本文不声称已经
证明 \(P\ne NP\)。
