> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Constant-alphabet adaptive bottom closure (2026-08-17)

## Contribution

The fixed-locality bottom barrier is not intrinsically binary. The proof map
may use any fixed finite alphabet \(\Sigma\). We tag the message-inline
coordinates separately from proof symbols, so the inline code is a code over
one fixed alphabet \(\Gamma\). An adaptive verifier whose proof answers lie in
\(\Sigma\) has an \( |\Sigma|\)-ary decision tree; exposing both claim trees
still gives a constant-size non-adaptive query set.

Goldberg--Gur--Saraogi's arbitrary-alphabet non-adaptive RLDC theorem therefore
rules out near-linear common proofs for every fixed finite proof alphabet and
every fixed branch locality, whenever the target-relative wrong-branch error is
any constant \(\beta<1\).

## Theorem

Let \(\Sigma\) be a fixed finite alphabet of size \(A\ge2\), and let

\[
  \Pi:\{0,1\}^{k}\longrightarrow\Sigma^{P}
\]

be a proof map. Write \(d_H\) for Hamming distance on \(\Sigma^P\). For every
\(i\in[k]\) and \(b\in\{0,1\}\), let \(V_{i,b}\) be a randomized, possibly
adaptive verifier making at most \(r\) proof-symbol queries. Its acceptance
probability on \(z\in\Sigma^P\) is \(p_{i,b}(z)\).

Assume fixed constants \(0<\rho<1\) and \(0\le\beta<1\), and:

1. **Perfect correct-branch completeness**
   \[
     p_{i,m_i}(\Pi(m))=1
     \qquad(m\in\{0,1\}^{k},\ i\in[k]);
   \tag{241.1}
   \]

2. **Target-relative wrong-branch soundness**
   \[
     d_H(z,\Pi(m))\le\rho P
     \Longrightarrow
     p_{i,1-m_i}(z)\le\beta
   \tag{241.2}
   \]
   for every \(m,i,z\).

Let

\[
  \Gamma:=\{(I,0),(I,1)\}\sqcup\{(P,a):a\in\Sigma\},
  \qquad |\Gamma|=A+2,
\]

and define

\[
  T_{r,A}:=\sum_{j=0}^{r-1}A^j,\qquad
  Q_{r,A}:=1+2T_{r,A},\qquad
  \sigma:=1-\beta,\qquad
  a_{r,A}:=\left\lceil\frac{Q_{r,A}}{\sigma}\right\rceil .
\tag{241.3}
\]

Then the inline length \(N:=k+P\) satisfies, for all sufficiently large \(k\),

\[
  N\ge
  \left(
    \frac{\sigma^2 k}
    {38Q_{r,A}^{\,4}\log^2(A+2)\log^2 k}
  \right)^{1+1/a_{r,A}}.
\tag{241.4}
\]

Consequently, for every fixed \(A,r,\rho,\beta\) with \(\beta<1\),
\(N=k\,\operatorname{polylog}k\) is impossible.

## Proof

### 1. Distance and inline radius

Let \(d\) be the minimum Hamming distance among distinct proof words. If
\(m\ne m'\) and
\(d_H(\Pi(m),\Pi(m'))\le\rho P\), choose \(i\) with
\(m_i\ne m'_i\). Apply (241.2) to target \(m'\) and
\(z=\Pi(m)\); (241.1) for \(m\) says that the same branch accepts with
probability one, contradicting \(\beta<1\). Hence the proof image has
relative distance greater than \(\rho\).

The \(A\)-ary Singleton bound gives

\[
  k\le (P-d+1)\log_2 A\le ((1-\rho)P+1)\log_2 A .
\]

For sufficiently large \(k\),

\[
  \frac{P}{N}\ge
  c_{\rho,A}:=
  \frac{1}{1+2(1-\rho)\log_2 A}.
\tag{241.5}
\]

Set \(\delta_0:=\rho c_{\rho,A}/2\). If a tagged inline word
\(y\in\Gamma^N\) is within relative distance \(\delta_0\) of
\(C(m)\). If a queried proof coordinate has an invalid tag, the decoder below
outputs \(\bot\). Otherwise, strip the \(P\)-tags on valid proof coordinates
and assign arbitrary \(\Sigma\)-symbols to unqueried invalid positions, thereby
forming \(z\in\Sigma^P\). Then
\(d_H(z,\Pi(m))\le\delta_0N\le\rho P/2\).

### 2. Tagged inline decoder

Define \(C(m)\in\Gamma^N\) by putting \((I,m_i)\) in its first \(k\)
coordinates and \((P,\Pi(m)_j)\) in its proof coordinates. The decoder reads
the inline symbol at coordinate \(i\). If it is \((I,b)\), it runs \(V_{i,b}\)
on the proof suffix, outputs \(b\) on acceptance, and outputs \(\bot\) on
rejection. Any other inline symbol causes immediate output \(\bot\). If a
proof query returns a symbol not of the form \((P,a)\), the decoder also
immediately outputs \(\bot\); otherwise it strips the \(P\)-tag and supplies
the underlying \(a\in\Sigma\) to \(V_{i,b}\).

On \(C(m)\), perfect completeness follows from (241.1). On a
\(\delta_0\)-close word, an invalid inline tag cannot produce a wrong bit. If
the tag is valid and \(b=m_i\), the decoder outputs the target or \(\bot\). If
\(b\ne m_i\), a wrong output requires the wrong branch to accept, which has
probability at most \(\beta\) by (241.2). Thus \(C\) is a weak adaptive
\((r+1,\delta_0,\sigma)\)-RLDC over \(\Gamma\), with
\(\sigma=1-\beta\).

### 3. Exposing both \(A\)-ary adaptive trees

Fix \(i\) and the random tape. For each \(b\in\{0,1\}\), the adaptive verifier
is an \(A\)-ary decision tree of depth at most \(r\), with at most
\[
  T_{r,A}=1+A+\cdots+A^{r-1}
\]
internal query nodes. Query non-adaptively the inline coordinate and the union
of the two trees' proof-query locations. The total number of queried
coordinates is at most \(Q_{r,A}=1+2T_{r,A}\).

After the answers arrive, the decoder reads the inline tag, selects the
corresponding tree, and simulates it exactly. Hence the non-adaptive decoder
has the same output distribution, including bottom, as the adaptive decoder.

### 4. Apply the arbitrary-alphabet RLDC lower bound

The non-adaptive \((q,\delta,\sigma)\)-RLDC theorem of
Goldberg--Gur--Saraogi applies to arbitrary finite \(\Gamma\). It states that,
when \(\delta>N^{-\sigma/(2q)}\),

\[
  \frac{k}{\log^2 k}
  \le
  38q^4\sigma^{-2}\log^2|\Gamma|\;
  N^{\,1-\frac1{\lceil q/\sigma\rceil+1}}.
\tag{241.6}
\]

Here \(q=Q_{r,A}\), \(|\Gamma|=A+2\), and \(\delta=\delta_0\) is a positive
constant. Since \(N\ge k\), the radius condition holds for sufficiently large
\(k\). Rearranging (241.6) gives (241.4).
\(\square\)

## Boundary

This closes the non-binary-symbol escape whenever the proof alphabet is fixed
finite. If \(A\) grows with \(k\), then both
\(\log|\Gamma|\) and the decision-tree size \(Q_{r,A}\) grow; (241.4) must be
re-evaluated rather than extrapolated. In particular, an alphabet growing fast
enough to make \(Q_{r,A}\) nonconstant remains a genuine escape from this
fixed-query theorem.

For \(A=2\), note 240 gives the cleaner binary statement
\(Q_{r,2}=2^{r+1}-1\), while note 239 gives the stronger exponential bound
for \(r=1,\beta<1/2\).

## Source

* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for Relaxed
  Locally Decodable Codes via Robust Daisies*, arXiv:2511.21659, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.

* The binary specialization is
  [note 240](240-adaptive-bottom-to-superlinear-rldc-closure-2026-08-17.md).
