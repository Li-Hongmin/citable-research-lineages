> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW exposed-history target-binding trilemma (2026-08-17)

## 结论

对 RW Theorem 4.3 的 exposed computational history，普通的 target-binding 组合只有
三种逻辑位置：

1. **保留 raw-history 坐标采样：** singleton/list 的 scalar average soundness 被完整
   history 的长度 \(L_i\) 稀释，逐位需要 \(\varepsilon_i=O(1/L_i)\)；
2. **把完整 history 注入一个 outer code：** 若编码器对所有 \(L_i\)-bit histories
   单射，则 proof/codeword 长度至少 \(L_i/\log_2|\Sigma|\)；
3. **两者都不做：** 必须给出新的 hidden-witness、target-normalized、共同地址空间
   relation compiler，不能从普通 exposed-history PCPP/dPCP 黑箱得到。

因此，RW 的真正正向目标不是“再加一层普通 outer code”，而是一个能在不暴露
\(T_i\)-bit history、又不承受 \(1/T_i\) scalar dilution 的 singleton-output
relation-PCP 定理。

## 定理（exposed-history target-binding trilemma）

固定 RW Theorem 4.3 的稳定阶段 \(i\)，记

\[
 n_{i+1}=n_i^C,\qquad T_i=n_{i+1},\qquad
 K_i=2n_i,\qquad m_i=\left\lceil\log_2(2n_i)\right\rceil .
\]

由 Lemma 3.2，完整 satisfying history 至少含有长度 \(T_i\) 的 'out' 字段。考虑
一个声称把该 history 接入同一 global proof 的编译器。则以下三类黑箱模型中：

### A. Raw-history scalar sampling

若 verifier 仍在完整 history 的普通坐标上采样，并且 soundness 只给

\[
\sum_{u\in U_i}\mu_u b_u\le\varepsilon_i,
\]

其中目标坐标没有被重新加权、没有 outer spreading，则

\[
\varepsilon_i\le \frac{\beta}{T_i}
\quad\text{(每个 target bit)},
\qquad
\varepsilon_i\le \frac{\beta K_i}{T_i}
\quad\text{(target block average)}.
\tag{212.1}
\]

### B. Injective full-history outer encoding

若编译器先取一个固定字母表 \(\Sigma\) 上的编码

\[
 E_i:\{0,1\}^{L_i}\hookrightarrow \Sigma^{N_i},
\qquad L_i\ge T_i,
\tag{212.2}
\]

再依靠 \(E_i(h)\) 做 target binding，则必有

\[
 N_i\log_2|\Sigma|\ge L_i\ge T_i.
\tag{212.3}
\]

在 RW 稳定阶段 \(m_i=\log_2(2n_i)\)，故
\(T_i=n_i^C=2^{C(m_i-1)}\)，所以

\[
 N_i\ge \frac{2^{C(m_i-1)}}{\log_2|\Sigma|}.
\tag{212.4}
\]

这不是 \(m_i^{O(1)}\) 的 address-scale proof；它仍暴露了 object-scale history。

### C. Succinct hidden-witness projection

若一个候选编译器既不满足 A 的 raw-history scalar sampling，也不满足 B 的
全 history 单射编码，则它必须把 private witness 隐藏在一个新的 relation-PCP
接口中，同时满足：

* 目标坐标有 \(\Omega(1)\) 的有效采样质量或等价的 target spreading；
* 所有目标坐标共用同一个 proof/address space；
* 同一个 hidden witness/strategy 对所有坐标保持 word consistency；
* proof、descriptor、query generator 在 \(m_i^{O(1)}\) 地址尺度可生成。

这就是 RW Closure Gate I 的真正未决对象，而不是已有 Theorem 3.5 的直接推论。

## 证明

分支 A 由 full-history target-density dilution 直接给出：均匀 raw-history 下单个
目标位的坐标权重至多 \(1/T_i\)，目标块的总权重至多 \(K_i/T_i\)。scalar average
bound 对任意坐标只能给出 \(\varepsilon_i/\mu_i\)，于是得到 (212.1)。

分支 B 只用有限集合计数。编码器 (212.2) 在 \(2^{L_i}\) 个输入上单射，而
\(\Sigma^{N_i}\) 至多有 \(|\Sigma|^{N_i}\) 个输出，因此
\[
2^{L_i}\le |\Sigma|^{N_i},
\]
即 (212.3)；稳定区代入 \(T_i=n_i^C=2^{C(m_i-1)}\) 得 (212.4)。

若 A、B 均不成立，任何成功的编译器都必须既避免 raw-history 的坐标稀释，又不把
全部 \(L_i\)-bit history 显式放入 codeword。它只能通过一个新的 hidden-witness
projection 来绑定目标；否则要么仍属于 A，要么仍属于 B。这给出三分。证毕。

## 这条三分真正关闭什么

它关闭了两个经常被混写的“正向捷径”：

1. **普通 dPCP + 输出位读取：** 即使合法输出投影 singleton，只要 dPCP 对完整
   history 做 scalar average，目标位仍只得到 \(1/T_i\) 权重；
2. **先编码整个 history 再做 coordinate robustness：** 码距可以修复
   raw-systematic-slot 的 proximity 问题，但 (212.3) 说明它不能同时变成
   \(m_i^{O(1)}\) 的 succinct proof。

因此，已有 exposed-history compiler 的正确定位是：它可以解决 target separation，
但不解决 address-scale compression。新的正向定理必须直接处理 private witness
projection，而不能只引用“有一个强 LTC/PCPP”。

## 量词边界

分支 B 假设编码器对**所有** \(L_i\)-bit histories 单射。若只对一个具体 canonical
history 做 hardwire，(212.3) 不适用；但这时编码器没有提供可复用的 relation-PCP
compiler，不能据此声称解决 RW 的统一 Gate I。

同样，分支 A 只针对 scalar average/list soundness；若一个未来 verifier 直接给出
coordinate-wise target predicate 或全局 non-scalar consistency，便不落在 A 中。这
正是可能形成新 PCP/coding theorem 的空间，而不是本定理的反例。

## RW 参数与论文级目标

Theorem 4.3 的稳定递推把 \(T_i\) 推到 \(n_i^C\)，而最终 AVOID 输出地址只需
\(m_i=\Theta(\log n_i)\) 位。故 A/B 两分都不能给出 \(m_i^{O(1)}\) 的统一
whole-word evaluator：A 需要 inverse-\(T_i\) soundness，B 需要
\(\Omega(T_i)\) proof length。若要得到 \(P/\mathrm{poly}\) 闭合，唯一未被这条
黑箱三分排除的路线是 C。

这把顶级论文问题具体化为一个可证伪的二择一：

* 构造 C：近线性、统一、singleton-output、hidden-witness、target-normalized
  relation-PCP；
* 证明 C 在一个足够一般的模型中必然支付 RLDC/LDC、descriptor entropy 或
  superlinear proof-length 代价。

## 证据边界

RW Theorem 4.3 的 \(T_i=n_i^C\) stable recurrence 和 Lemma 3.2 的 'out' 字段布局，
见本地逐字抽取
units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md，
以及正式报告 [Ren--Williams TR26-118](https://eccc.weizmann.ac.il/report/2026/118/)。

分支 A 是 [RW full-history dilution instantiation](211-rw-full-history-dilution-instantiation-2026-08-17.md)，
分支 B 是对 exposed-history injective encoding 的直接计数。本文不声称分支 C
一般不可能，也不声称 \(P\ne NP\) 已由 A/B 单独推出。
