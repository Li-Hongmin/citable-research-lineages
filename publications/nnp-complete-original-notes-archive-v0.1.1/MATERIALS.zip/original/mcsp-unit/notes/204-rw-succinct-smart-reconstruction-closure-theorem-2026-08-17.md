> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW succinct smart reconstruction：闭合定理与三重缺口（2026-08-17）

## 结论

RW/JK 路线最后缺的不是另一个局部障碍，而是一个把实际
canonical history 接回 forcing lower bound 的闭合定理。下面的条件性定理把
最终矛盾所需的量词一次写全；它本身不声称这些条件已经由现有 RW、PCP、dPCP
或 distributional-soundness 构造满足。

## 1. 条件性 Closure Theorem

设 \(A\) 是一个正确的多项式时间 SAT 决策器。对某个无限长度集合
\(\mathcal N\)，令

\[
H_{A,n}\in\{0,1\}^{N_n},\qquad n\in\mathcal N,
\]

是由 RW/JK 构造确定的同一个 canonical object；其 forcing 分支满足

\[
\operatorname{CC}(H_{A,n})>s_n,
\qquad
\forall c>0\ \exists n_c\ \forall n\in\mathcal N,\ n\ge n_c:
s_n>n^c.
\tag{204.1}
\]

假设存在一个固定、统一的 reconstruction interface，满足：

1. **同一对象与地址尺度。** 对每个 \(a\in[N_n]\)，机器
   \(\mathsf{Q}(1^n,a)\) 在 \(n^{O(1)}\) 时间内生成关于同一个 canonical
   history/proof 的查询；生成时间和描述长度均为 \(n^{O(1)}\)，
   \(\log N_n=n^{O(1)}\)，而不是
   \(\operatorname{poly}(q_n)\)（其中 \(q_n\) 可能是 \(n^{k(n)}\)）。
2. **全词一致性。** 所有地址查询共用同一个 proof、seed、strategy 和
   address space。若存在 cover lift，则 sheet index \(\sigma\) 由一个
   \(\operatorname{poly}(n)\)-bit selector 固定；不能为不同坐标更换 sheet、
   preimage 或 proof。对下面的 \(P/\mathrm{poly}\) 结论，该 selector 可以是
   每个长度的一份非一致 advice；若还要求得到 uniform \(P\) 算法，才需另加
   P-uniform 生成条件。
3. **Smartness 与 bottom 完整性。** 在 \(A\) 正确时，所有实际查询都落在
   其 promise 内；对每个 \(a\)，接口在 bottom、cover 或普通分支都给出
   \(H_{A,n}[a]\)，或者已经证明这些分支在该实际 instance 上不出现。
4. **有界 advice，而非历史编码。** descriptor、sheet index、canonical key 和
   strategy summary 的总长度为 \(n^{O(1)}\)；它们可以作为每个长度的
   \(P/\mathrm{poly}\) advice 被硬接进电路，但不能把 \(\Theta(N_n)\) 个 history
   bits 改名后携带。若目标是 uniform \(P\)，再要求这些字符串由固定算法统一生成。
5. **复杂度坍缩接口。** 在 \(P=NP\) 假设下，所有实际 promise queries 的
   verifier/selector 可以由固定的 \(P\)（更一般地，固定 PH collapse 后的
   \(P\)）过程确定化，且每个地址的总时间仍为 \(n^{O(1)}\)。
6. **长度对齐。** (204.1) 成立的长度集合 \(\mathcal N\) 与 reconstruction
   接口工作的长度集合有无限交集；forcing 使用的 \(H_{A,n}\) 正是接口恢复的
   同一个对象，而非不同 padding 或不同 history。

则

\[
P=NP\quad\Longrightarrow\quad
\{H_{A,n}\}_{n\in\mathcal N}\in P/\mathrm{poly},
\tag{204.2}
\]

从而与 (204.1) 矛盾；因此

\[
\boxed{P\ne NP.}
\tag{204.3}
\]

### 证明

在 \(P=NP\) 下，假设 5 将每个实际 smart query 确定化为
\(n^{O(1)}\)-时间过程。由假设 1、2、3、4，同一个过程对任意地址
\(a\) 输出 \(H_{A,n}[a]\)，且其额外工作状态只含 \(n^{O(1)}\) 位 advice。
把 \(n\)、\(A\) 的固定描述、该长度的 selector/advice 和该地址过程硬接进电路，并以
\(\lceil\log N_n\rceil\) 位地址作输入，得到一个统一的
\(n^{O(1)}\)-size circuit \(C_n\) 满足

\[
C_n(a)=H_{A,n}[a]\qquad(a\in[N_n]).
\]

故 \(\operatorname{CC}(H_{A,n})\le n^{O(1)}\)，与 (204.1) 冲突。假设 6
保证这两个结论作用于同一无限长度子集。若第 2、4 项的 advice 还 P-uniform
可生成，则同一构造给出 \(H_A\in P\)；但得到 \(P/\mathrm{poly}\) 矛盾只需
多项式长度 advice，不需要 uniformity。证毕。

这里的证明是条件性的：它没有证明假设 1--5 对 RW/JK 实际 canonical history
成立；它只精确说明一旦这些条件闭合，最后的 \(P=NP\Rightarrow\bot\) 不再有
复杂度或量词缺口。

## 1A. RW Theorem 4.1 的直接尺度审计（一个可证的 Gate-I 边界）

Closure Theorem 的 Gate I 不能把原始 `Reconf` 的 \(q\)-尺度保证直接重命名为
地址尺度保证。Ren--Williams Theorem 4.1 的精确参数是：对
\(G:\{0,1\}^{k}\to\{0,1\}^{2k}\)，`Reconf(x,i)` 的确定性运行时间和每个
prMA query 的规模为

\[
  \operatorname{poly}(k,r,\log t),
\]

而其 Merlin 电路 witness 的大小为

\[
  k'=O(k^4\log t).
\tag{204.4}
\]

该定理保证的是：在固定的 `Solve_f(x,G)` failure 分支上，对每个 \(i\) 单独
输出 \(f(x)_i\)，并且这些**实际执行的** query 是 smart；它没有给出一个
\(\operatorname{poly}(\log k)\)-大小的 random-access evaluator。这里的量词并非
“每个坐标重新选择一个证明”——正确的 PCP proof \(\Pi_x\) 可同时作为各个
query 的完备 witness——但 theorem 的算法预算仍然按 \(k\) 而不是按
\(\log k\) 计。

把这一点代入 Theorem 4.3 的真实递推：

\[
 n_{i+1}=n_i^C,
 \qquad
 T_i=\max\{2^{cD^i n_0},n_{i+1}\},
 \qquad
 f_i(x)=\operatorname{pad}_{T_i}(B_i),
\tag{204.5}
\]

其中 \(B_i\) 是长度 \(2n_i\) 的前一阶段 AVOID 输出，而 Theorem 4.1 在该阶段
取 \(k=n_{i+1}\)。因此失败分支给出的自然 bit evaluator 的规模至多是

\[
 (n_{i+1}+r_i+\log T_i)^{O(1)}.
\tag{204.6}
\]

在稳定区 \(T_i=n_{i+1}=n_i^C\)、\(r_i=O(n_i)\) 时，(204.6) 仍为
\(n_i^{O(C)}\)。可是 \(B_i\) 的 truth-table 地址长度只有

\[
 m_i=\lceil\log_2(2n_i)\rceil,
\]

所以这个直接 evaluator 至多是 \(2^{O(m_i)}\)-尺度，而不是
\(m_i^{O(1)}\)-尺度。即使假设 \(P=NP\) 把实际 smart promise query 确定化，
它只替换 query 的答案，不会把 (204.4)--(204.6) 中的 \(k\)-bit witness、
query 描述和运行时间压缩到地址长度。

因此得到一个严格但不越界的结论：**原始 RW Theorem 4.1/4.3 的直接
Reconf 编译不能实例化 Closure Theorem 的 Gate I。** 这不是一般性的
coordinate-robust impossibility theorem；它只证明若要闭合 C181，必须再加入一个
新的 \(m_i^{O(1)}\)-地址级压缩定理（例如同一 proof 的 succinct block accessor），
而不能只引用现有 `Reconf` 的逐位 smartness。

参数和量词直接来自 RW 原文 Theorem 4.1--4.3；本仓库的可检索抽取版见
`units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md`
（第 14--18 页），正式报告见
<https://eccc.weizmann.ac.il/report/2026/118/>。

## 2. 三个必须独立关闭的 Gate

### Gate I：RW attachment

必须从 RW/JK 的实际 \(A\)-dependent canonical history 构造统一的
\(\mathsf Q(1^n,a)\)。逐坐标重新编译 PCP、为每个地址选择不同 Merlin
strategy，或只给 \(q_n\)-scale 的 full-table search，都不满足假设 1--2。

有一个可直接检验的充分子接口：若 target-relative near-proof family 按单坐标
修改形成 Hamming 连通图，所有 transcript 使用同一坐标边缘，C332 的逐 proof
互信息/误差参数给出
\[
\alpha_n=\varepsilon_n+\sqrt{(\ln2/2)\iota_n},
\]
且 adaptive decoder 深度为 \(r_n\)、每步每个 proof position 的命中率至多
\(\chi_n/N_n\)，那么相邻 transcript law 的 TV 至多 \(r_n\chi_n/N_n\)。
当 \(2\alpha_n+r_n\chi_n/N_n<\Delta_n\) 时，C333 强制整个邻域共享一个
global word。再加 forcing-side target binding，便闭合 Assumption 1 的
same-object/whole-word 量词；这不是现有 RW Theorem 4.1 的自动推论，而是
一个明确的 Gate-I 实验目标。

也可以考虑一个 mixture-attachment 变体：若 RW 能给出依赖目标消息的 policy law
\(\mu_m\)，且存在统一可执行的 sampler \(\mathsf{Sam}(m;r)\) 生成它，同时
robust-defect 的平均值满足
\(\tau=\bar\delta+\sqrt{(\ln 2/2)I(M;S)}\) 小于固定 gap margin，
则 Proposition 3.4V 可把 \(\mu_m\) 换成与目标无关的 dummy-message marginal，
并在近满消息子族上得到 RLDC barrier。现有 RW Theorem 4.1 的 `Reconf` 并未
提供这一接口：它是 existential 的 smart promise-response 断言，不是 executable
policy law 的 sampler，也没有单一 worst-case defect 的上界。因此 3.4V 是新的
条件性 Gate-I 接口，而不是 RW 现有结论的自动改写。

### Gate II：escape classification

必须证明以下至少一项：

* bottom 分支被实际 RW 结构排除，或 bottom 上仍有同一 proof 的 coordinate
  reconstruction；
* cover lift 的 sheet index 有统一的 \(n^{O(1)}\)-bit binding；
* target descriptor/strategy summary 的信息量受 \(n^{O(1)}\) 控制，并且不能
  隐藏完整 history；对 \(P/\mathrm{poly}\) 结论允许非一致 advice，只有 uniform
  版本才需要额外的生成器；
* 任何大 support 或 private patch 都已进入已有 RLDC/LDC/cover barrier。

普通 list soundness、平均 coordinate soundness、局部 left-canonicality 或
逐地址 \(\forall a\,\exists w_a\) 都不够，因为它们允许不同地址使用不同的
phantom witness。

### 2A. 四个结构性逃逸口

上述三个 Gate 是证明接口的量词分解；从研究决策看，所有尚未闭合的逃逸可归并为
四类。这个分类不是新的不可能性定理，而是本项目今后接受一个“正向构造”或“负向
障碍”进入主线的最小判据。

* **Bottom：** 两个 claim branches 可以同时低接受。必须证明实际 RW instance
  排除这种 simultaneous rejection，或给出在 bottom 上仍保持同一 proof、同一地址空间
  的恢复规则。
* **Cover sheet：** 局部高 agreement 可能只在非平凡 cover 上有 global word。必须
  证明 canonical history 的 sheet 被统一绑定，或把 lift-word 本身作为目标并证明其
  地址级可恢复；普通 distributional/list soundness 不自动完成这一步。
* **Target descriptor：** 坐标查询可通过一个 descriptor、key 或策略摘要偷偷携带
  history。必须给出其 \(n^{O(1)}\) 信息预算并证明不能把 \(\Theta(N_n)\) 个目标位
  改名后藏入其中；否则所谓“重构”只是 advice 重新编码。
* **Address scale：** 即使 proof 量词与 smartness 正确，接口仍可能只在
  \(\operatorname{poly}(q_n)\) 而非 \(n^{O(1)}\) 时间工作。必须证明真实的
  random-access evaluator 达到地址尺度；否则 C182 的 RW scale boundary 仍然挡住
  Gate I。

这里有一个对最终反证很重要的归一化：**对
\(P/\mathrm{poly}\) 结论，cover sheet、descriptor、canonical key 与有限策略摘要
不是四种独立的信息通道。** 若它们在每个长度上可合并为一条静态字符串
\(\sigma_n\in\{0,1\}^{n^{O(1)}}\)，并且同一个地址 evaluator
\(E(1^n,a;\sigma_n)\) 在坍缩后的 promise/PH 查询上输出
\(H_{A,n}[a]\)，那么无论 \(\sigma_n\) 是否 P-uniform、是否语义上被称为
cover lift、或是否包含一段固定 strategy transcript，都可直接把
\(\sigma_n\) 作为该长度的 advice 硬接进电路。于是
\[
  P=NP\ \Longrightarrow\ H_A\in P/\mathrm{poly}
\]
无需再分别证明 “base sheet 唯一” 或 “selector 可统一生成”。真正尚未关闭的
Gate-II 情形因此只有两类：\(\sigma_n\) 需要超多项式信息，或不同地址必须
使用不同的 sheet/strategy（等价地，不能形成一个共同的静态 advice）。后一类
正是 whole-word consistency 的实质缺口，而不是 cover 术语本身。

### 2B. ROM-advice accounting lemma

上面的 advice 归一化还可以写成一个定量版本，避免把“随机访问静态 sheet”当成
不计成本的原语。设一个地址 evaluator 在长度 \(n\) 上输入地址
\(a\in\{0,1\}^{m_n}\)，并访问一条固定描述字符串
\(\sigma_n\in\{0,1\}^{d_n}\)。假设它的控制逻辑和普通布尔运算总数至多 \(p_n\)，
随机访问 \(\sigma_n[j]\) 的次数至多 \(r_n\le p_n\)，每个索引 \(j\) 由同一控制
逻辑算出；访问模型是标准 fan-in-2 布尔电路加一个只读 ROM。

**ROM-advice lemma.** 在上述模型中，存在普通 fan-in-2 电路
\(C_n(a)=E_n(a;\sigma_n)\)，满足

\[
  |C_n|=O\!\left(p_n^2+p_n d_n\right).
  \tag{204.7}
\]

证明：把 evaluator 的有限控制流展开成布尔电路；每次 ROM 读取替换为一个
\(d_n\)-输入多路选择器，大小 \(O(d_n)\)，并把至多 \(p_n\) 次读取与控制状态
合并。将固定 \(\sigma_n\) 的各位接到常数线上即可得到 (204.7)。因此若同一
对象满足 \(\operatorname{CC}(H_{A,n})>s_n\)，任何此类 evaluator 必须满足

\[
  p_n^2+p_n d_n=\Omega(s_n).
  \tag{204.8}
\]

这把“没有隐藏 advice”变成了可检验的成本二分：若 \(p_n=n^{O(1)}\) 且
\(d_n=n^{O(1)}\)，便直接进入 \(P/\mathrm{poly}\) 闭合；若 \(d_n\) 超多项式，
(204.8) 说明它本身已经承担 forcing 所需的历史信息；若不同地址使用不同 ROM
或不同 sheet，则它们不能由一条 \(\sigma_n\) 编译，回到 whole-word consistency
缺口。这里的 \(O(p_n^2)\) 是对任意有限控制流的保守展开；对 straight-line
evaluator 可改为 \(O(p_n+p_nd_n)\)。

因此，下一项可晋级的结果只有两种：构造一个同时处理这四类逃逸的 RW-specific
closure interface，或证明在一个明确、足够一般的 shared-proof/coordinate-robust
模型中，至少一类逃逸必然支付 RLDC/LDC、proof-length、support 或通信代价。单个
decoder 的失败、单个平均 soundness 反例或参数微调本身不再视为主线进展。

### Gate III：final collapse

必须把 \(P=NP\) 下的确定化、forcing lower bound、canonical object 与长度集合
写在同一个参数表中。仅有 \(E^{NP}\) 或 \(\operatorname{poly}(q_n)\) 的
outsider 生成器不能推出 \(P/\mathrm{poly}\)；只有地址级
\(n^{O(1)}\) 的 whole-word evaluator 才能调用 (204.2)。

## 3. 与已有障碍的精确关系

* C170 的 bottom-or-cubic 二分说明了为什么不能把通用
family-level ACRR 当作免费终点；Closure Theorem 只要求一个
RW-specific、single-target interface。
* C194 / note 208 把一个额外的 RW-specific Gate-I 情形单独闭合为二择一：
  在 range-invariant、proof/action-covariant 的输入轨道上，一次 base Solve 要么
  给 outsider，要么整个 failure orbit 进入 family-level RLDC barrier；因此多输入
  轨道不能被当作额外的独立 actual JK tuples。
* C179/ note 202 的 cover obstruction 说明 ordinary DPT agreement 不能自动给
base-global word；Closure Theorem 允许 cover，但把 sheet binding 明确列为条件。
* C176/C180 只关闭 BMVY/DDL 源上的两簇 arbitrary-right-label patch；它们不替代
Gate I，也不等价于全局 reconstruction。
* note 189 的 Conjecture A/B 仍是可发表的 barrier 方向；若某个 Gate 不能闭合，
  应把失败升级为一般 impossibility theorem，而不是继续增加局部 decoder note。

## 4. 当前判断

Closure Theorem 是最终矛盾的正确形式，但目前仍是**条件性闭合定理**。已核验的
source-specific cover/profile 结果缩小了 Gate II 的范围，却没有证明实际 RW
history 有 \(n^{O(1)}\) 地址级 accessor。下一步最有价值的证明对象不是另一个
平均 soundness 障碍，而是：

\[
\text{actual RW history}
\ \longrightarrow\
\text{same-proof, bottom/cover-safe, address-scale evaluator}.
\]

若该接口成立，(204.1)--(204.3) 给出严格的最终收尾；若它不能成立，失败必须
落入 descriptor、cover、bottom、support 或 RLDC/LDC 代价中的一个一般性定理。

这也固定了项目的论文级标准：细分 note 只是搜索轨迹，不以数量计贡献；真正的主
定理必须是 (i) simultaneous coordinate-robust shared-proof/PCP 的新构造，(ii) 足够
一般的 RLDC/LDC 或编码代价下界，或 (iii) 能把实际 RW history 接到 (204.2) 的
无条件 Closure Theorem。只有其中之一成立，才把结果视为 FOCS/STOC/CCC 级候选。

## 参考

* [RW/JK multi-input tuple-supply barrier](163-rw-multiinput-tuple-supply-parameter-no-go-2026-08-16.md)
* [ACRR bottom-or-cubic dichotomy](../../rw-jk-succinct-reconstruction/statements/acrr-bottom-or-cubic-dichotomy.md)
* [BMVY/DDL cover obstruction](202-bmvy-ddl-parameter-closure-for-cover-obstruction-2026-08-16.md)
* [BMVY incidence profile closure](203-bmvy-incidence-profile-closes-arbitrary-right-label-patch-2026-08-16.md)
* [Top-tier ACRR theorem program](189-top-tier-acrr-theorem-program-2026-08-16.md)
