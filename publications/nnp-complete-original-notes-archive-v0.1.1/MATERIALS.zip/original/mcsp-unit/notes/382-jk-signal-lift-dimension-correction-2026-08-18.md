> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK signal lift 的维数修正与 proof-level block binding（2026-08-18）

## 本轮判定

C377 的 signal-path 公式需要一个维数修正。若

\[
 G:\{0,1\}^{k}\to\{0,1\}^{2k},
\]

且 JK 在第 \(i\) 层的某个 block 为 \(Z_{i,u}\in\{0,1\}^{2k}\)，则把两半都送入
\(G\) 再拼接会得到 \(4k\) bits，不能等于上一层的单个 \(2k\)-bit block。正确的
逐层 lift 是：每次选定左半或右半，只对这一半应用 \(G\)。修正后，signal 路径
仍可在首块 regime 恢复顶层首块，但对一般 proof 只能恢复一个带地址的顶层
\(2k\)-bit block；它不自动恢复整个父表。

这一区分改变 Gate-I 的精确接口：success outsider 若要成为 parent accessor，至少
还需一个可验证的 top-block index/path，并证明该祖先 block 落在 systematic output
区间；Theorem 3.5 并未保证 JK 的 first-failure block 具有这一性质。

## JK block chain

令 \(Y_i\) 是第 \(i\) 层长度为 \(k2^i\) 的当前串，

\[
 Z_{i,1},\ldots,Z_{i,2^{i-1}}
\]

是它的连续 \(2k\)-bit blocks。若该层没有失败，令

\[
 X_{i,u}=P_G(Z_{i,u})\in\{0,1\}^{k},
 \qquad
 Y_{i-1}=X_{i,1}\Vert\cdots\Vert X_{i,2^{i-1}}.
\]

于是对每个 \(v\)，

\[
 Z_{i-1,v}=X_{i,2v-1}\Vert X_{i,2v}.
\tag{382.1}
\]

定义左右 half-lift

\[
 L_{G,0}(z):=G(\operatorname{left}_k(z)),
 \qquad
 L_{G,1}(z):=G(\operatorname{right}_k(z)).
\tag{382.2}
\]

由 \(G(X_{i,2v-1})=Z_{i,2v-1}\) 和
\(G(X_{i,2v})=Z_{i,2v}\)，(382.1) 给出精确关系

\[
 L_{G,\epsilon}(Z_{i-1,v})=Z_{i,2v-1+\epsilon},
 \qquad \epsilon\in\{0,1\}.
\tag{382.3}
\]

这才是 JK 递归中可用的单 block lift。C377 中的
\(G(u)\Vert G(v)\) 不是该关系，应由 (382.2) 替换。

## Block-addressed lift theorem

假设 JK 在第 \(j\) 层输出 success block

\[
 y=Z_{j,u},
\]

且第 \(j+1,\ldots,h\) 层均已完成而未提前停止。取任意
\(a\in\{(u-1)2^{h-j}+1,\ldots,u2^{h-j}\}\)。把 \(a-1\) 在该区间中的偏移写成
\(h-j\) 个 bits \(\epsilon_{j+1},\ldots,\epsilon_h\)。则

\[
 Z_{h,a}
 =L_{G,\epsilon_h}\circ\cdots\circ L_{G,\epsilon_{j+1}}(y).
\tag{382.4}
\]

### 证明

由 (382.3)，一次 lift 把 block index \(v\) 变为
\(2v-1+\epsilon\)。迭代 \(h-j\) 次后，所有可达 index 恰为
\((u-1)2^{h-j}+1\) 到 \(u2^{h-j}\)，并且每条左右选择路径给出对应的
\(Z_{h,a}\)。证毕。

若 \(G\) 的电路大小为 \(s_G\)，则固定 \((j,u,a)\) 后计算整个
\(Z_{h,a}\) 只需 \(h-j\) 次 half-lift，规模为

\[
 O((h-j)s_G+hk)
\tag{382.5}
\]

（后项是 block/path 控制的普通编码开销）。因此一个 success outsider 可以给出
一个 address-scale 的 **top-block evaluator**，前提是 descriptor 包含足够的
\(j,u,a\) 信息，且这条 ancestry 在 JK 中确实没有被更早的 failure 截断。

## 对 padded target 与实际 RW proof 的分别结论

### Padded target

若顶层串是 \(F_B=B0^{T-b}\)，且 \(b\le2k\)，首块 \(Z_{h,1}\) 的前 \(b\)
bits 正是 \(B\)。因此当 success block 是首块 ancestry 中的
\(Z_{j,1}\)，全左 half-lift 给出 \(Z_{h,1}\)，从而恢复 \(B\)。这保留 C377
首块结论，但其正确公式是

\[
 Z_{h,1}=L_{G,0}^{\,h-j}(Z_{j,1}),
\tag{382.6}
\]

而不是 \(\mathsf{Lift}_G^{h-j}\)（后者若定义为两次 \(G\) 的拼接会有错误的
输出长度）。当 \(b>2k\) 时，(382.6) 最多给出顶层首个 \(2k\)-bit block，
不能单独恢复整个 \(B\)。

### 实际 RW canonical PCP proof

Theorem 4.1 传给 JK 的对象是 \(\Pi_{x_0}\)，不是
\(f_i(x_0)=B_i0^{T_i-2n_i}\)。Theorem 3.5 只保证 systematic witness/output
字段位于 proof 的已知前缀；它没有保证：

* JK first-failure 的 block index \((j,u)\) 位于该前缀的 output 区间；
* block 的 top ancestor \(a\) 可由 address-scale 规则选定；
* systematic 区间之外的 auxiliary proof blocks 与 \(B_i\) 无关。

所以对实际 RW proof，(382.4) 只能给出一个**条件性 block-window attachment**：
若另证 success block 的 ancestry 落在 systematic output 区间，则该 block 的
\(2k\) bits 可由 \((y,j,u,a)\) 以 (382.5) 的规模计算；否则仍只有
\(y\notin\operatorname{Range}(G)\)，没有 parent-binding。C377 的 padded
signal/off-signal fiber 分解不能直接替换这一 proof-level 量词。

## Gate-I 的更新

正确的 success 分支现在分成三层，而不是“outsider 自动恢复 parent”：

1. **Block lift：** (382.4) 给出一个可验证 top block；
2. **Output attachment：** 需证明该 top block 覆盖 systematic output 位；
3. **Whole-parent closure：** 需用多个 block、额外 descriptor 或新 global relation
   绑定全部 \(B_i\)。当 \(k=\operatorname{poly}(\log b)\) 而 \(b\gg k\) 时，
   单个 success outsider 只覆盖 \(2k\) 个 proof bits；C378 的 family-level
   通信门仍说明多次 exact binding 不能在无 hidden advice 时保持 address-scale。

这是一条 source-level 修正与更窄的正向接口；它不声称 published RW 已满足
output attachment，也不构成 \(P\ne NP\) 或一般 RLDC 不可能性证明。

## 证据边界

* Ren--Williams Theorem 3.1 的 block 递归：
  `units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md`，
  约第 8--10 页。
* Theorem 3.5 的 systematic witness/output 前缀与 Theorem 4.1 的 canonical proof
  输入：同一文件约第 12--17 页。
* C377 的 padded signal/off-signal 分解及其适用范围：
  [C377](377-jk-padded-signal-offpath-parent-binding-2026-08-18.md)。
