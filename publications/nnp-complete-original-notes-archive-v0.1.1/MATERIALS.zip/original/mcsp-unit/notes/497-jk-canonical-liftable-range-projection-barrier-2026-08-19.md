> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK canonical-liftable range projection barrier（2026-08-19）

## 本轮改变的判断

C496 使用 \(G_n(u)=u\Vert u\)；其真正承重的性质不是形式上的 duplication，
而是每个 seed 及其所有 descendant chunks 都被 JK 的 canonical right inverse
固定。C497 把这一点抽象为 generator-specific quantity。

给定 \(G:\{0,1\}^n\to\{0,1\}^{2n}\) 和 canonical selector
\(p:\operatorname{Range}(G)\to\{0,1\}^n\)，定义深度-\(d\) canonical-liftable
seeds \(\Gamma_d\)。若 range 中存在 \(M_d\) 个经过 \(d\) 层 lift 后仍彼此可区分的、
两半都来自 \(\Gamma_d\) 的 blocks，那么在任意首次失败 stage \(i\) 放置最后 outsider
时，固定 first-failure transcript 的 prefix fiber 至少有
\[
M_{k-i}^{\,2^{i-1}-1}
\]
个值。任何 exact descriptor 因而至少支付
\[
(2^{i-1}-1)\log_2 M_{k-i}
\]
bits。

这给 published truth-table generator 一个明确的下一 gate：不是泛泛寻找 shared
selector，而是估计其 \(\Gamma_d\) 上的 prefix projection \(M_d\)。C499 进一步证明
\(M_d=|\Gamma_{d+1}|\)，所以 \(M_d\) 小只能反映 canonical-liftable range 本身小，
不能解释为 lift collision；若要成为 Closure escape，仍需另行给出被计价的
image-specific/global relation，不能把 C496 的显式 duplication 结论静默套用。

## 定义

令
\[
G:\{0,1\}^{n}\to\{0,1\}^{2n},\qquad
R=\operatorname{Range}(G),
\]
并固定 \(p:R\to\{0,1\}^n\) 满足 \(G(p(z))=z\)。

定义
\[
\Gamma_0:=\{u\in\{0,1\}^n:p(G(u))=u\}.
\tag{497.1}
\]
\(\Gamma_0\) 是 canonical right inverse 选出的 seed transversal。递归定义
\[
\Gamma_{d+1}:=
\{u\in\Gamma_0:
\operatorname{left}(G(u)),\operatorname{right}(G(u))\in\Gamma_d\}.
\tag{497.2}
\]

因此 \(u\in\Gamma_d\) 意味着：从 \(u\) 开始向上 lift \(d\) 层时，每一次新生成的
range block 都会被 canonical selector 回收到原来的 chunk。令
\[
\mathcal Z_d:=
\{z\in R:
\operatorname{left}(z),\operatorname{right}(z)\in\Gamma_d\}.
\tag{497.3}
\]

定义同样可被 lift 到上层、但在当前 stage 故意失败的 outsider 集合
\[
\mathcal O_d:=
\{y\in\{0,1\}^{2n}\setminus R:
\operatorname{left}(y),\operatorname{right}(y)\in\Gamma_d\}.
\tag{497.4}
\]

定义对 \(z\in\mathcal Z_d\) 的 \(d\)-层 lifted block，并记
\[
\widehat{\mathcal Z}_d:=
\{\mathsf L_G^{\,d}(z):z\in\mathcal Z_d\},
\qquad
M_d:=|\widehat{\mathcal Z}_d|.
\tag{497.5}
\]

若另有公开 projection \(\pi\) 和固定 decoder \(\rho_d\) 满足
\(\rho_d(\mathsf L_G^{\,d}(z))=\pi(z)\) 对所有 \(z\in\mathcal Z_d\) 成立，则
\(M_d\ge|\pi(\mathcal Z_d)|\)。这就是 lift 后仍可见的 range projection 条件。

## 定理 497.1（canonical-liftable prefix-fiber bound）

取 \(k\ge i\ge2\)，令 \(d=k-i\)、\(m_i=2^{i-1}-1\)，并取固定
\(y\in\mathcal O_d\)。假设 \(\mathcal Z_d\) 非空。对每个 tuple
\[
(z_1,\ldots,z_{m_i})\in\mathcal Z_d^{m_i},
\]
定义 stage-\(i\) frontier
\[
Y_i(z_1,\ldots,z_{m_i})
 :=z_1\Vert\cdots\Vert z_{m_i}\Vert y.
\tag{497.6}
\]

记
\[
\widehat z_r:=\mathsf L_G^{\,d}(z_r),\qquad
B_{\mathbf z}:=\widehat z_1\Vert\cdots\Vert\widehat z_{m_i},
\quad \mathbf z=(z_1,\ldots,z_{m_i}).
\tag{497.7}
\]
这里的 \(B_{\mathbf z}\) 正是顶层 truth table 在固定 stage-\(i\) 失败位置之前的
contiguous prefix；它不把 outsider \(y\) 或其位置信息重复计入 descriptor。

从该 frontier 向上 lift \(d\) 层：若当前字符串的 \(n\)-bit chunks 为
\(a_1,\ldots,a_{2^j}\)，下一层定义为
\[
\mathsf L_G(a_1\Vert\cdots\Vert a_{2^j})
 :=G(a_1)\Vert\cdots\Vert G(a_{2^j}).
\tag{497.8}
\]
记所得顶层 truth table 为 \(F_{\mathbf z}\)，长度为 \(T=n2^k\)。则：

1. JK 在 stages \(k,k-1,\ldots,i+1\) 全部通过，并精确到达 (497.6)；
2. stage \(i\) 的唯一 non-range block 是最后的 \(y\)，所以所有 tuple 共享
   \[
   \tau_{k,i}=(\mathrm{hard},i,2^{i-1},y);
   \tag{497.9}
   \]
3. 该 prefix 就是 \(B_{\mathbf z}\)，是 \(m_i\) 个 \(\widehat{\mathcal Z}_d\) blocks
   的串接，因此在固定 transcript 下至少有
   \[
   M_d^{m_i}
   \tag{497.10}
   \]
   个不同值；
4. 任意 single-valued decoder
   \[
   D(\tau_{k,i},s_{\mathbf z})=B_{\mathbf z}
   \]
   若对所有这些 prefix 正确，且二进制 side information 最大长度为 \(q\)，则
   \[
   q\ge m_i\log_2 M_d
   =(2^{i-1}-1)\log_2 M_d.
   \tag{497.11}
   \]

### 证明

取任意 \(z_r\in\mathcal Z_d\)，写
\(z_r=a_{r,0}\Vert a_{r,1}\)。由 (497.3)，两半属于 \(\Gamma_d\)。因此在
一次 lift 后，canonical selector 对 \(G(a_{r,b})\) 恢复的正是 \(a_{r,b}\)；
递归使用 (497.2)，继续 \(d\) 层时每个 descendant chunk 仍被 canonical
selector 原样恢复。故从顶层运行 JK，所有高于 \(i\) 的 range tests 都通过，
并到达 (497.6)。

在 stage \(i\)，前 \(m_i\) 个 blocks 属于 \(R\)，最后一个 block \(y\notin R\)，
所以唯一失败位置固定为 \(2^{i-1}\)，得到 (497.9)。

不同的 lifted block tuple
\((\mathsf L_G^d(z_1),\ldots,\mathsf L_G^d(z_{m_i}))\) 在相应的、顺序保持的
prefix coordinates 中直接出现；因此至少有 \(M_d^{m_i}\) 个 \(B_{\mathbf z}\) values，得到
(497.10)。固定 transcript 下，精确 decoder 的 side information 必须区分这些值，
故 descriptor map 至少有 \(M_d^{m_i}\) 个不同元素；二进制最大长度给出
(497.11)。证毕。

## 特例与 generator gate

对 C496 的 \(G_n(u)=u\Vert u\)，有
\[
\Gamma_d=\{0,1\}^n,\qquad
\widehat{\mathcal Z}_d=\{\mathsf L_G^{\,d}(u\Vert u):u\in\{0,1\}^n\},
\]
故 \(M_d=2^n\)，(497.10) 恢复
\(n(2^{i-1}-1)\) bits 的 C496 payment。

对 published truth-table generator，C497 不假设 \(\Gamma_d\) 大，也不假设任意
range block 的两半仍是 canonical seeds。下一步若要把该 barrier 接到 RW
singleton，必须在同一 generator、同一 canonical selector 和同一 proof
serialization 上证明一个下界
\[
\log_2 M_d\ge h_d.
\tag{497.12}
\]
或先证明某个 lift-visible projection 满足
\(|\pi(\mathcal Z_d)|\ge2^{h_d}\)。若 \(h_d\) 达到 address-scale closure 所需的 forcing 量级，则 (497.10) 关闭
augmented first-failure route；若 \(M_d\) 很小，则只能说明 \(\Gamma_{d+1}\) 本身小，不是 lift collision；仍必须另行构造被计价的 global relation，不能视为 C496 的反例。

## 证据边界

* 定理只依赖 canonical right inverse 与实际 JK 的逐层 range-test 语义；不需要
  \(G\) 在整个 domain 上单射。
* 若使用 projection \(\pi\)，必须有实际 proof/prefix 中公开且顺序保持的 lift-visible
  decoder \(\rho_d\)；通过未计价 selector 重新命名 projection 坐标，进入
  descriptor/model exit。
* C497 是 family-level entropy/descriptor theorem；它不自动转成 C455 的单个
  published hard output，也不证明 \(P\ne NP\)。

## 来源

* [C496](496-jk-all-stage-prefix-fiber-entropy-barrier-2026-08-19.md)：显式
  duplication generator 的 all-stage prefix fiber。
* [C493](493-jk-frontier-canonical-selector-correction-2026-08-19.md)：canonical
  right inverse 的正确量词。
* [C490](490-jk-all-stage-success-fiber-entropy-boundary-2026-08-19.md)：另一端
  outsider 的 all-stage fiber。
* [C499](499-jk-canonical-lift-injectivity-eliminates-collision-branch-2026-08-19.md)：
  证明 canonical lift 在 \(\mathcal Z_d\) 上单射并修正 \(M_d\) 的 collision 解释。
* Ren--Williams TR26-118 rev.1, Theorem 3.1：逐层 canonical preimage recursion。
