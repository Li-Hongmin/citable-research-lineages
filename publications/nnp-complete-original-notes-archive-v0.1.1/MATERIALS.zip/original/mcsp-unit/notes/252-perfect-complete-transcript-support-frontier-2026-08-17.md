> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Perfect-complete transcript-support frontier for shared-proof branches (2026-08-17)

## Result

The no-resampling branch can be analyzed without restricting the postprocessor to the
accept/reject bit.  For a fixed claim, collect every visible transcript that can occur on an
honest proof for any message carrying that claim.  Perfect completeness forces **every** such
transcript to be mapped to the claim.  The mass that a wrong branch places on this honest
transcript support is therefore an exact, not merely lower-bound, obstruction to any transcript
postprocessing.

This gives a sharp dichotomy: either the support-overlap parameter is bounded away from one and
the same proof immediately yields an RLDC, or no transcript postprocessor can obtain a better
wrong-branch error.  The statement permits arbitrary randomized, unbounded postprocessing and
does not use independent resampling.

## Model

Let

\[
  \Pi:\{0,1\}^{k}\longrightarrow\Sigma^{P}
\]

be a common proof map.  For every message coordinate \(i\) and claim \(b\in\{0,1\}\), let
\(V_{i,b}\) be a fixed randomized adaptive verifier.  Its visible transcript alphabet is
\(\mathcal T_{i,b}\); the transcript may include any public randomness, query addresses,
proof answers, response bits, and the final verifier output that the postprocessor is allowed to
see.  For a proof word \(z\), write

\[
  \mu_{m,i,b,z}\in\Delta(\mathcal T_{i,b})
\]

for the transcript distribution when \(V_{i,b}\) is run on \(z\).  Finite random tapes give
finite transcript alphabets; the same statement holds with essential supports in the general
measurable case.

For each \((i,b)\), define the honest transcript support

\[
  H_{i,b}:=
  \bigcup_{m:m_i=b}\operatorname{supp}\bigl(\mu_{m,i,b,\Pi(m)}\bigr).
\tag{252.1}
\]

At radius \(\rho\), define the support-overlap parameter

\[
  \omega_{i,b}(\rho):=
  \sup_{m:m_i\ne b}
  \sup_{z:\,d_H(z,\Pi(m))\le\rho P}
  \mu_{m,i,b,z}(H_{i,b}),
  \qquad
  \omega(\rho):=\max_{i,b}\omega_{i,b}(\rho).
\tag{252.2}
\]

The wrong branch is run with the fixed claim \(b\), while the target message in the second
supremum has bit \(1-b\).  Thus the transcript space is the same verifier-specific space on
both sides of the comparison.

## Exact frontier theorem

### Theorem 252.1

Fix \((i,b)\).  Among all (possibly randomized and computationally unbounded) postprocessors
\(F_{i,b}\) that see only the visible transcript of \(V_{i,b}\), impose perfect completeness

\[
  \Pr\bigl[F_{i,b}(\tau)=b\bigr]=1
  \quad\text{for every }m\text{ with }m_i=b,
  \quad \tau\sim\mu_{m,i,b,\Pi(m)}.
\tag{252.3}
\]

Then the minimum possible worst-case wrong-claim probability over all targets and all
\(\rho\)-near proof words is exactly \(\omega_{i,b}(\rho)\).  More explicitly:

1. every postprocessor satisfying (252.3) obeys
   \[
   \sup_{m:m_i\ne b}\sup_{z:d_H(z,\Pi(m))\le\rho P}
   \Pr_{\tau\sim\mu_{m,i,b,z}}[F_{i,b}(\tau)=b]
   \ \ge\ \omega_{i,b}(\rho);
   \tag{252.4}
   \]
2. equality is attained by the deterministic support filter
   \[
     F^*_{i,b}(\tau)=
     \begin{cases}
       b,&\tau\in H_{i,b},\\
       \bot,&\tau\notin H_{i,b}.
     \end{cases}
   \tag{252.5}
   \]

### Proof

By (252.3), every transcript in \(H_{i,b}\) is mapped to \(b\) with probability one:
each such transcript has positive probability under at least one honest message with bit \(b\).
Consequently, for every wrong target and every near proof,

\[
  \Pr[F_{i,b}(\tau)=b]
  \ge \Pr[\tau\in H_{i,b}]
  =\mu_{m,i,b,z}(H_{i,b}).
\]

Taking the two suprema proves (252.4).  The filter (252.5) maps every honest transcript to
the correct claim, so it has perfect completeness.  On a wrong target it outputs the wrong
claim exactly on \(H_{i,b}\), giving equality with (252.2). \(\square\)

## Shared-proof RLDC consequence

Suppose \(\omega(\rho)\le\beta<1\), and use the support filters (252.5) for every \((i,b)\).
Read the inline claim bit \(b=y_i\), run \(V_{i,b}\) on the proof suffix, and output \(b\) on
the support filter and \(\bot\) otherwise.  The resulting decoder has perfect completeness,
radius determined by the proof-image distance and the inline Singleton bound, and wrong-output
probability at most \(\beta\).  It makes exactly the same proof queries as \(V_{i,b}\); the
postprocessing adds no oracle query and no independent randomness.

Therefore Theorem 2.2 of the main paper, and its finite-alphabet/growing-locality refinements,
apply to **arbitrary transcript postprocessing** whenever the overlap parameter is bounded away
from one.  In particular, with fixed proof alphabet and fixed branch locality, a near-linear
family must have \(\omega(\rho)\to1\) (or leave perfect completeness, positive radius, the common
proof map, or the target-relative family quantifier).  If a proposed postprocessor claims a
wrong-branch error \(\beta<\omega(\rho)\), Theorem 252.1 rules it out before any coding lower
bound is invoked.

The filter need not be efficiently recognizable for an existential RLDC lower bound: standard
RLDC definitions measure query complexity, not computation time.  If uniform/local computation
is required, recognizability of \(H_{i,b}\) is an additional explicit gate rather than a hidden
assumption.

## Relation to earlier frontiers

The memoryless optimization in [note 250](250-optimal-static-postprocessing-frontier-for-no-resampling-rldc-closure-2026-08-17.md)
only sees the accept/reject bit and therefore permits imperfect completeness.  Theorem 252.1 is
different: it allows the entire visible transcript but assumes perfect completeness.  Its exact
optimum is support overlap, so no richer transcript statistic, claim-flipping rule, or correlated
postprocessing can beat the bound.

For imperfect completeness, honest transcripts need not all be sent to the claim, and the exact
frontier becomes a composite binary hypothesis-testing/linear-programming problem; Theorem 252.1
does not silently cover that regime.  Likewise, the theorem does not assert that ordinary dPCP
list soundness forces \(\omega<1\): proving such a support separation is itself a substantive
coordinate-robustness theorem.

## Source boundary

This is a self-contained transcript-support theorem.  Its coding consequences use the shared-proof
to RLDC compiler in the main paper and the non-adaptive RLDC lower bound of Goldberg--Gur--Saraogi,
Theorem 1: <https://arxiv.org/abs/2511.21659>.  It is not a proof of \(P\ne NP\), and it does not
claim an unconditional impossibility theorem for all dPCPs; it identifies the exact semantic
quantity that any such construction must separate.
