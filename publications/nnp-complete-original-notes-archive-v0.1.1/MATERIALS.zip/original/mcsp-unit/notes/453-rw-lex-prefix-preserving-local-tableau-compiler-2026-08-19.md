> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW Lemma 3.2 的 lex-prefix-preserving local-tableau compiler（2026-08-19）

## 本轮改变的判断

C444 已说明：固定有限状态机若主动采用 cell-time、track-major serialization，
则 Harsha 约束关系的低度延拓 \(\widehat C\) 可以在 address scale 精确求值。
但 C444 尚未证明这种新 circuit representation 保持 Ren--Williams
Lemma 3.2 所需要的 lexicographically largest hist 前缀和 output 语义。

这里补上这个语义接口：对 Lemma 3.2 的原始 circuit \(C_x\)，把其确定性求值
过程编译成一个 hist 位于最前面的局部 tableau circuit \(D_x\)。所有原始
满足赋值恰好有一个（或至少一个）合法 tableau 扩展，非法 hist 没有扩展，
所以 \(D_x\) 的 lexicographically largest satisfying assignment 的
hist projection 与 \(C_x\) 的 lexicographically largest satisfying assignment
完全相同。于是 y-prefix、out block 和 Theorem 3.5 的 soundness 语义都保留，
同时 \(D_x\) 可采用 C444 的 offset-regular layout。

## 设置

令 \(M\) 是 Ren--Williams Lemma 3.2 中的固定
\(\mathrm{TIME}[t(n)]^{\mathrm{NP}}\) machine，输入为 \(x\)，输出长度为
\(\ell(n)\)。令
\[
  C_x:\{0,1\}^{h_x}\to\{0,1\}
\]
是 Lemma 3.2 的 circuit，且其输入按
\[
  \mathrm{hist}=(y_1,\ldots,y_r,\mathrm{out},z_{1,1},\ldots,z_{r,t})
\]
排列。记 \(\alpha_x\) 为 \(C_x\) 的 lexicographically largest satisfying
assignment，并令 \(r'=r\lceil\log(t+1)\rceil\)。

固定一个确定性、有限状态的直接 history-predicate evaluator \(E_M\)。它不是
扫描 \(C_x\) 的任意 gate list，而是按 Lemma 3.2 证明中的定义，在输入
\((x,\mathrm{hist})\) 上模拟 \(M\)：检查每一轮被接受 query 的数目是否等于
\(y_i\)，并检查最终 output 是否等于 `out`。其运行时间为
\[
  T_{\mathrm{eval}}=\operatorname{poly}(t(n),|x|).
\]
这里的有限状态机描述只依赖固定 \(M\)、其 NP-query verifier 与 Boolean basis；
\(x\) 作为输入 track，若要得到 address-scale 结论，则要求其 bits 由
regular/address-succinct source 提供（published zero source \(x_0=0^{n_0}\) 满足
这一条件）。于是
\[
E_M(x,\mathrm{hist})=1\quad\Longleftrightarrow\quad C_x(\mathrm{hist})=1,
\]
但该等式来自 Lemma 3.2 的直接 history 语义，而不是一个对任意黑箱 circuit
的快速求值假设。

## 定理 453.1（lex-prefix-preserving local-tableau replacement）

存在一个 Boolean circuit
\[
  D_x:\{0,1\}^{h_x}\times\{0,1\}^{u_x}\to\{0,1\},
\]
其中第一段 hist 保持在最前面，满足：

1. **Projection equivalence**
   \[
     C_x(\mathrm{hist})=1
     \quad\Longleftrightarrow\quad
     \exists \zeta\in\{0,1\}^{u_x}\;D_x(\mathrm{hist},\zeta)=1.
     \tag{453.1}
   \]
2. **Lex-prefix preservation**：若 \(\alpha_x^{\mathrm{loc}}\) 是
   \(D_x\) 的 lexicographically largest satisfying assignment（按 hist、再按
   \(\zeta\) 排列），则
   \[
     \alpha_x^{\mathrm{loc}}|_{\mathrm{hist}}=\alpha_x.
     \tag{453.2}
   \]
   因而其前 \(r'\) 个 bits 与 out block 都与 Lemma 3.2 的
   \(\alpha_x\) 相同。
3. **Source-compatible size**：\(D_x\) 可由 \((M,x)\) 在
   \(\operatorname{poly}(t(n),|x|)\) 时间生成，且
   \(|D_x|=\operatorname{poly}(t(n),|x|)\)。
4. **Offset-regular layout**：若 \(x\) 是 regular/address-succinct source，
   则可把 \(D_x\) 的 tableau variables 按 track-major cell-time 编号，把所有
   local transition、initialization、boundary 和 final-output checks
   去重分解成 \(R=\operatorname{poly}(m)\) 个 offset families，并由
   \(s=\operatorname{poly}(m)\)-state digit automata 识别边界，其中
   \(m=\lceil\log_h N\rceil\) 是 Harsha 变量地址长度。

因此，把 \(D_x\) 而不是黑箱 \(C_x\) 送入 RW Theorem 3.5 的 PCP compiler
不会改变其 completeness、lexicographic-prefix soundness 或 output attachment
语义（只引入 polynomial size overhead）。在 \(R,s,|H|=\operatorname{poly}(m)\)
的 Harsha 参数下，C443/Proposition 1.62 给出一个在任意 generic field point
精确运行于 \(\operatorname{poly}(m)=\operatorname{poly}(\log N)\) 的
\(\widehat D\) evaluator。

### 证明

先让 \(D_x\) 的 auxiliary input \(\zeta\) 表示 \(E_M(x,\mathrm{hist})\) 的
完整 accepting computation tableau。用固定有限状态局部转移规则检查：

* 初始 configuration 正确装载 \(x\) 与 hist；
* 每个相邻 time layer 满足 \(E_M\) 的局部 transition；
* padding、边界和 final state 合法；
* final accept bit 等于 \(1\)。

把所有 local checks 用固定 fan-in-two gadgets 合取；使用连续 serial AND
chain，避免引入需要额外 affine-digit 处理的 heap-numbered balanced tree。
于是 \(D_x(\mathrm{hist},\zeta)=1\) 当且仅当 \(\zeta\) 是
\(E_M(x,\mathrm{hist})\) 的合法接受 tableau，得到 (453.1)。注意这里的
tableau 只把直接 history simulation 的工作空间放入第二段；它没有把一个任意
gate-list 的求值过程偷换成 address-scale evaluator。

若 \(C_x(\mathrm{hist})=1\)，确定性 evaluator 的真实 tableau 给出一个
\(\zeta\) 使 \(D_x=1\)；若 \(C_x(\mathrm{hist})=0\)，没有 tableau 能通过
final check。因此，\(D_x\) 的 satisfying assignments 在第一段 hist 上的
projection 恰好是 \(C_x\) 的 satisfying assignments。按 hist 在前的
字典序，\(D_x\) 的最大 satisfying assignment 必须先最大化其 hist projection，
故得到 (453.2)。

局部 gadget 的每个 gate 只访问常数个相邻 cell、track 和 time layer。按
\[
  I_\rho(\tau,c)=\rho L+\tau W+c,\qquad L=(T+1)W,
\]
编号后，以 \(z=\tau W+c\) 为 base address，其三个输入变量都形如
\[
  z+\rho_jL+\Delta_{\tau,j}W+\Delta_{c,j}.
\]
固定 machine、basis、padding 和 serial-AND pattern 只产生常数个 gate
families；regular source data 的边界由有限 digit automaton 识别。初始化中
hist、\(x\) 与 time-zero tape 的 copy 约束按连续 track 分段，每段仍是
固定 offset family。于是满足 C443 的 \(R,s\) 估计，且局部 tableau 编译和
\(\widehat D\) evaluator 的复杂度分别如上。证毕。

## 对 RW Closure 的直接后果

1. C440 的 black-box gate-list objection 不再适用于这个主动选择的
   source-compatible representation：约束延拓这一半可以用
   \(\operatorname{poly}(\log N)\) evaluator 处理。
2. 结合 C454 的 fresh output-check compiler，C439/Proposition 1.58 所需的
   nondegenerate incidence map 也可以在同一 serialization 上 address-scale
   生成；真正剩下的 source-level 条件是 \(P=p(q)\) field-symbol evaluator。
3. 若该 \(P\)-evaluator 也在 address scale 成立，C439/C446 立即恢复
   Lemma 3.2 的 systematic hist/output bits，并与 forcing hard parent 矛盾。
   所以它们不是中性辅助引理，而是 Gate III 的最后 algebraic interface。
4. 若 \(P\)-evaluator 只能扫描完整 auxiliary table，C446 把其成本转移回
   forcing-scale parent complexity；剩余 genuine positive target 是新的
   non-factorized global relation，而不是继续优化 \(\widehat C\) 的 weighted sum。

## 证据边界

* 这是对 Lemma 3.2 语义的 source-compatible replacement lemma，不声称
  published RW 已经规定这种 serialization。
* Theorem 3.5 的使用只依赖“输入 circuit 的 satisfying assignment 具有给定
  lex prefix/output 语义”和 polynomial size；若某个后续版本额外依赖
  \(C_x\) 的具体 gate numbering，则需要重新核对。
* regular/address-succinct source、固定 machine 与 serial output reduction
  是必要条件；任意未压缩 machine-code table 会退回 object-scale。
* 本定理不提供 \(P=p(q)\) evaluator，不直接证明 \(P\ne NP\)；它把
  singleton Gate-I 的约束延拓缺口正式移出，留下可独立检验的 auxiliary random-access
  缺口。

## 来源

* Ren--Williams TR26-118 revision 1, Lemma 3.2 and Theorem 3.5。
* [note 443](443-offset-regular-harsha-generic-evaluator-2026-08-19.md)。
* [note 444](444-cell-time-offset-regular-rw-unrolling-2026-08-19.md)。
* [note 439](439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md)。
* [note 454](454-rw-source-compatible-incidence-auxiliary-barrier-2026-08-19.md)。
