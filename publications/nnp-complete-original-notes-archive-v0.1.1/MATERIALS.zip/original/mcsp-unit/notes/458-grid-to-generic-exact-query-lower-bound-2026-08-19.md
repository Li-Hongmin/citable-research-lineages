> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Grid-to-generic 精确评价的 sharp query 下界（2026-08-19）

## 本轮改变的判断

C457 把 Harsha \(P=p(q)\) random access 等价地压到 generic \(q\)-access，但仍需区分
proof 中显式给出的 \(H^m\) systematic table 与任意 \(x\in F^m\) 上的 generic
evaluation。对 individual-degree 小于 \(|H|\) 的完整 Reed--Muller 空间，后者不能由
前者黑箱压缩：精确 query complexity 恰等于张量 Lagrange 展开中的非零系数数目。
特别地，若每个坐标都在 \(F\setminus H\)，必须读取全部 \(|H|^m\) 个 grid symbols。

这不排除 tableau-specific 小电路或特殊代数表示；它精确排除“低度延拓本身天然提供
generic random access”的黑箱推断。

## 定理 458.1（sharp grid-to-point query complexity）

设 \(F\) 为域，\(\varnothing\ne H\subset F\)，\(h=|H|\)，并令
\[
  \mathcal P_{H,m}
  :=
  \{q\in F[X_1,\ldots,X_m]:
    \deg_{X_i}q<h\ \text{ for every }i\}.
\]
算法只可查询 oracle table \(q|_{H^m}\)。对
\[
  x=(x_1,\ldots,x_m)\in F^m,\qquad
  k(x):=|\{i:x_i\notin H\}|,
\]
精确计算 \(q(x)\) 的 deterministic query complexity 与 zero-error randomized
query complexity 均恰为
\[
  h^{k(x)}.
\tag{458.1}
\]
特别地，
\[
  x\in(F\setminus H)^m
  \quad\Longrightarrow\quad
  Q_{\rm exact}=h^m.
\tag{458.2}
\]

### 证明

对 \(a\in H\) 定义一元 Lagrange 基
\[
  \ell_a(T)
  :=
  \prod_{\substack{b\in H\\b\ne a}}
  \frac{T-b}{a-b},
\]
并对 \(u=(u_1,\ldots,u_m)\in H^m\) 令
\[
  L_u(X):=\prod_{i=1}^m\ell_{u_i}(X_i).
\]
评价映射
\[
  \mathcal P_{H,m}\longrightarrow F^{H^m},
  \qquad q\longmapsto(q(u))_{u\in H^m}
\]
是线性同构，且
\[
  q(x)=\sum_{u\in H^m}q(u)L_u(x).
\tag{458.3}
\]

若 \(x_i\notin H\)，则对每个 \(a\in H\)，分子和分母均非零，所以
\(\ell_a(x_i)\ne0\)。若 \(x_i=c\in H\)，则
\(\ell_a(c)=\mathbf 1_{a=c}\)。因此
\[
  L_u(x)\ne0
  \quad\Longleftrightarrow\quad
  u_i=x_i\ \text{for every }i\text{ with }x_i\in H.
\tag{458.4}
\]
式 (458.3) 恰有 \(h^{k(x)}\) 个非零系数；查询这些点给出上界。

对下界，沿任意 deterministic decision tree 的全零回答路径运行。若算法停止时仍有
某个满足 \(L_z(x)\ne0\) 的 \(z\in H^m\) 未被查询，则零多项式与
\[
  q_z:=L_z
\]
在所有已查询点上不可区分，因为
\[
  L_z(u)=\mathbf 1_{u=z}\qquad(u\in H^m),
\]
但
\[
  0(x)=0,\qquad q_z(x)=L_z(x)\ne0.
\]
故每条正确路径必须查询 (458.4) 中的全部 \(h^{k(x)}\) 个点。

对 zero-error randomized algorithm，任一具有正概率的随机分支若在某个 oracle 上出错，
该 oracle 的错误概率即为正，违反 zero-error。因此每个正概率分支都是正确的
deterministic tree，并在零 oracle 上受到同一下界；最坏与期望 query complexity 均至少
\(h^{k(x)}\)。结合上界得到 (458.1)。证毕。

## 对 C457 / RW Closure 的后果

C456 的 systematic assignment symbols 给出
\[
  \{q(u):u\in H^m\},
  \qquad q(u_j)=B_n[j],
\]
而 C457 的 \(q\leftrightarrow P\) 等价需要 generic \(F^m\)-point access。若 generic
point 的全部坐标都在 \(F\setminus H\)，定理 458.1 强制 \(h^m\) 次黑箱 systematic
queries；这就是整个 grid。故下列推断无效：
\[
  \text{proof contains }q|_{H^m}
  \quad\Longrightarrow\quad
  q(x)\text{ is address-scale evaluable}.
\]
任何少于全表的成功 evaluator 必须利用 \(q\) 的额外结构，例如小电路、自动序列、
低秩 tensor network 或 tableau-specific parallelization；individual-degree bound 本身
不够。

## 证据边界

* sharp bound 依赖 individual-degree \(<h\)，此时 grid values 可任意独立。若只限制
  total degree，空间维数变小，需重新计算评价泛函的 support。
* 若某些 \(x_i\in H\)，精确下界降为 \(h^{k(x)}\)，而非统一 \(h^m\)。
* 下界覆盖 adaptive deterministic 与 zero-error randomized exact algorithms；不在此处
  声称 bounded-error approximate evaluation 下界。
* 结论是 black-box barrier，不排除 C453 actual tableau 的特殊结构。

## 来源

* 张量 Lagrange interpolation。
* [C457 \(q\)--\(p(q)\) access equivalence](457-harsha-q-p-generic-access-equivalence-2026-08-19.md)。
* [C456 published-output alignment](456-published-rw-output-source-alignment-and-direct-scale-boundary-2026-08-19.md)。
