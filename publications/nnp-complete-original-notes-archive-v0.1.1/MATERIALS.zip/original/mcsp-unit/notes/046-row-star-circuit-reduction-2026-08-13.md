> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 同中心 row-star witness 的 binary-circuit 重写（2026-08-13）

## 结论

固定中心 row \(x_0\)，令

\[
d_y:=y+x_0\qquad(y\in Y).
\]

若 \(T_S=\{(x_0,y):y\in S\}\) 是连通的 inclusion-minimal
collision witness，则：

1. \(\{d_y:y\in S\}\) 线性独立；
2. \(S\) 的三种 separator 类型分别给出固定 XOR target：

\[
\begin{array}{c|c|c}
\text{separator}&|S|\bmod 2&\bigoplus_{y\in S}d_y\\ \hline
q_s=1&1&x_s+x_0\\
p_s=0&0&x_0+y_s\\
q_s+p_s=0&0&x_s+y_s
\end{array}
\tag{1}
\]

因此固定 target \(\tau\) 的 witness 列集 \(S\) 恰对应向量 matroid 中
包含 \(\tau\) 的 circuit \(S\cup\{\tau\}\) 删除 \(\tau\) 后的集合。

## 证明

中心 row 方程为 \(q_{x_0}z=0\)，列方程为 \(p_yz=1\)。将二者相加得

\[
(d_y,0)\cdot z=1.
\tag{2}
\]

由 star-forest note 042，\(T_S\) 的投影图只有一个中心和 \(|S|\) 个叶，
故行列方程总数为 \(|S|+1\)。极小 witness 的秩增一给出

\[
\operatorname{rank} A_{T_S}\ge |S|+1.
\]

另一方面这正是方程总数，故 \(q_{x_0}\) 与 \(p_y\ (y\in S)\) 线性独立。
相加变换保持秩，因而 \(\{d_y:y\in S\}\) 线性独立。

若 \(k=|S|\)，则由 (2)

\[
r\cdot\Bigl(\bigoplus_{y\in S}d_y\Bigr)=k\pmod2.
\tag{3}
\]

三种不相容证书分别为：

- \(q_s=1\)：必须 \(k\) 奇且 \(\bigoplus S=x_s\)，于是
  \(\bigoplus d_y=x_s+x_0\)；
- \(p_s=0\)：必须 \(k\) 偶且 \(\bigoplus S=x_0+y_s\)，于是
  \(\bigoplus d_y=x_0+y_s\)；
- \(q_s+p_s=0\)：必须 \(k\) 偶且 \(\bigoplus S=x_s+y_s\)，于是
  \(\bigoplus d_y=x_s+y_s\)。

这给出 (1)。由于 \(d_y\) 独立而其总和为 \(\tau\)，
\(S\cup\{\tau\}\) 是一个 circuit；否则 \(\tau\) 落入某个真子集的 span，
与独立性矛盾。

## 研究含义

同中心 row-star 的两两 cell 相交性等价于其列集 \(S\) 两两相交。
固定 separator 时，note 045 的补集配对已经给出完整 \(1/16\)。
separator 可变时，剩余问题等价于：

\[
\text{至多三个指定 circuit 元素 }\tau
\quad+\quad
\text{两两相交的 circuit-deletion 族}
\quad\Longrightarrow\quad
\text{联合 affine--thinning 质量界。}
\]

这说明 varying-separator 缺口不是任意 set-family 问题，而是一个受
binary matroid circuit 约束的三-target 交叉族问题。
