> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# BMVY/DDL 入射谱闭合 arbitrary-right-label patch（2026-08-16）

## 结论

note 202 的 cover obstruction 需要单独记账 cover degree；它不自动说明
GMWZ 的任意参数窗口都落在 \(1/L_i\) agreement 区间。另一方面，若只问
GMWZ Section 6 中的两簇 face-separable patch，BMVY 的 down/up 算子谱界可以把
note 176 的高阶 \(L_2\) profile 在同一源族内闭合。于是这类 patch 不能再作为
arbitrary-right-label 的 unique-decoding 逃逸；剩余障碍必须是非 patchable 的全局
assignment，或者真的利用 cover sheet。

## 1. cover degree 的精确记账

用 \(\ell_0\) 表示 BMVY 过滤所选的 pro-\(\ell_0\) 素数，避免与 cover degree
\(L_i\) 混淆。BMVY 的相邻紧开正规子群满足

\[
[H(i):H(i+1)]=\ell_0^{\Theta(d^2)}.
\tag{203.1}
\]

对应的格子商 \(X_i=\Gamma_i\backslash\widetilde C_d\) 因而有相邻 cover

\[
L_i=[\Gamma_i:\Gamma_{i+1}],
\qquad
\log L_i=\Theta(d^2\log\ell_0),
\tag{203.2}
\]

在群—格子指数相同的通常归一化下就是 \(L_i=\ell_0^{\Theta(d^2)}\)；若采用
不同的有限商模型，(203.2) 应作为需要核对的格子指数，而不是把它自动替换为
常数 cover。DD Lemma 1.2 的 agreement 下界因此是

\[
\operatorname{Agree}\ge L_i^{-1}
 =\ell_0^{-\Theta(d^2)}.
\tag{203.3}
\]

这给出明确的 soundness gate：只有当目标协议的 agreement/acceptance 阈值不超过
\(L_i^{-1}\)（或能在该阈值重启 cover argument）时，note 202 才能直接击中它。
若 \(d,\ell_0\) 随 \(K\) 增长，则 (203.3) 可能很小；若它们对固定目标
soundness 是常数，\(L_i\) 也是关于 \(K\) 的常数。BMVY Theorem 2.13 的文字只
保证存在依赖目标 \(\delta\) 的 \(\ell_0\)，不能在没有参数选择的情况下声称
\(L_i=O(1)\) 或 \(L_i=\operatorname{poly}(K)\)。

来源：BMVY Theorem 2.13 的群过滤说明相邻指数为
\(\ell_0^{\Theta(d^2)}\)，并保持距离至少 \(4\)；见
[BMVY, Theorem 2.13 proof](https://arxiv.org/html/2407.12762)。

## 2. BMVY 的 containment/down operator

令 \(X\) 是带 BMVY 诱导测度的 \(d\)-维一侧 \(\gamma\)-local spectral expander。
对 \(s\le K\) 记

\[
D_{s}^{K}g(B)=\mathbb E[g(A)\mid A\in X(K),\ B\subseteq A],
\qquad B\in X(s).
\tag{203.4}
\]

BMVY Lemma 2.8 给出（\(\alpha=s/K\)，在其规定的
\(\alpha\in(1/K,1)\) 参数域内）

\[
\|D_s^K\|_{\mathbf 1^\perp\to L_2}
 \le \theta_{K,s}:=\sqrt{\frac{s+1}{K+1}}+\operatorname{poly}(K)\gamma.
\tag{203.5}
\]

端点 \(X(s)\to X(1)\) 不能把 Lemma 2.8 的 \(\alpha=1/s\) 边界值直接代入。
这里改用 BMVY Theorem 2.2 对 containment graph \(G_{s,1}\) 的二阶奇异值界：

\[
\theta_{s,1}\le \frac{2}{s+1}+O(s\gamma).
\tag{203.6}
\]

这里采用 BMVY 的 \(\mu_K,\mu_s\) 测度：先取顶面，再均匀取子面；这正是
shared-top sampler 的单个 \(A,B\) 边缘。若某个实现采用不同的边缘，需额外加入
总变差误差 \(\xi\)，并把下面的 \(\theta^2\) 项替换为
\(\theta^2+O(\xi)\)。

## 3. profile lemma

对任意 \(U\subseteq X(K)\)，令

\[
\mu=\Pr[A\in U],
\qquad
p(B)=\Pr[A\in U\mid B\subseteq A].
\]

把 \(1_U-\mu\) 代入 (203.5)，得到

\[
\mathbb E_B[(p(B)-\mu)^2]
 \le \theta_{K,s}^2\mu(1-\mu)
 \le \theta_{K,s}^2\mu.
\tag{203.7}
\]

这正是 note 176 的 profile 假设，且不需要从 DPT soundness 反推。若
\(s=\lceil\sqrt K\rceil\)，并选择 BMVY/DDL 参数使

\[
\operatorname{poly}(K)\gamma=o(K^{-1/4}),
\tag{203.8}
\]

则 \(\theta_{K,s}^2=O(K^{-1/2})\)。同理，由 (203.6)，若
\(s\gamma=o(s^{-1})\)，则

\[
\Pr[B\cap D=\varnothing]
 \le \frac{\theta_{s,1}^2}{\delta}
 =O\!\left(\frac1{s^2\delta}\right)
 =O\!\left(\frac1{K\delta}\right)
\tag{203.9}
\]

其中 \(D\subseteq X(1)\) 的质量为 \(\delta>0\)；这是 containment-graph expander
mixing 的直接应用。

## 4. arbitrary-right-label patch closure

取两个互不相交的 \(K\)-面簇 \(U_0,U_1\)，质量
\(\mu_i\ge\mu_0>0\)，左标签分别为 \(F_i|_A\)，且两个左词在顶点集合
\(D=\{u:F_0(u)\ne F_1(u)\}\) 上有质量 \(\delta>0\)。右标签 \(T_2[B]\) 任意，
不要求它是 vertex-word restriction。note 176 的碰撞不等式与 (203.7)--(203.9)
给出

\[
\operatorname{Viol}_{\rm patch}
\ge
\frac{\mu_0}{2}
\left[
1-O\!\left(\frac1{K\delta}\right)
  -O\!\left(\frac1{\mu_0\sqrt K}\right)
\right]_+.
\tag{203.10}
\]

因此对固定 \(\mu_0,\delta>0\)，\(K\) 足够大时

\[
\operatorname{Viol}_{\rm patch}\ge\mu_0/4.
\tag{203.11}
\]

若 exact projection amplifier 的 unique-decoding radius 小于 \(\mu_0/4\)，该
face-separable patch 不可能产生两个相距 \(\delta\) 的 decoded words。这个结论
比 note 175 的公共 vertex-word 版本更强：右侧可以是任意标签。

## 5. 精确边界

该闭合有三个不能省略的量词：

1. shared-top 的 \(A,B\) 单边缘必须是 BMVY 的 \(\mu_K\to\mu_s\) containment
   law；否则需要显式记入 \(\xi\)；
2. 需要 \(\operatorname{poly}(K)\gamma\) 足够小。DDL Theorem 3.15 给出
   \(\gamma=O(1/\sqrt p)\) 及 skeleton 的 two-sided 参数，因此可先取 \(p\) 足够大，
   但不能把“\(p\) 大”省略成无参数常数；
3. 结论只关闭 face-separable two-cluster patch。它不处理一个真正跨坐标的
   global assignment，也不消除 note 202 的 cover-sheet lift；后者仍需
   sheet-binding 信息成本或 cover-aware positive construction。

这一步把原来的二路 gate 收窄为：BMVY/DDL 源上的高阶 incidence profile 已有
可核验谱证明；真正的顶级未知只剩 cover-sheet binding、非 patchable global
assignment，或 RLDC/LDC 代价定理。

## 参考

* [BMVY, Lemma 2.8, Theorem 2.2 and Theorem 2.13](https://arxiv.org/html/2407.12762)
* [DDL, Theorem 3.15](https://arxiv.org/html/2402.01078)
* [DD, Lemma 1.2](https://arxiv.org/html/2308.09582)
* [项目 note 176](../../rw-jk-succinct-reconstruction/CLAIMS.md#c176)
