> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# ACRR 共同集中查询核心的信息下界（2026-08-16）

## 结论地位

本 note 将 note 187 中**显式加入的** disagreement-hitting 条件升级为一个一般的、与
smoothness 无关的共同核心定理。它不是一般 ACRR 不可能性：核心可以依赖坐标、消息或
诚实 transcript；本结果只排除一个对所有坐标和消息共用的短集中坐标集。

## 模型

令

\[
  C:\{0,1\}^k\to\Sigma^N
\]

是 injective proof/codeword map，且 `|Sigma|>=2`。对每个消息坐标 `i` 和声明位 `b`，令 `V_{i,b}` 是
至多 `q` 次（可自适应）查询的随机 verifier。假设：

1. `V_{i,m_i}` 在 `C(m)` 上以概率 `1` 接受；
2. 另行假设 disagreement-hitting：对任意 `m,m'` 与 `m_i\ne m'_i`，有
   `Pr_R[Q_{i,m_i}^{C(m)}(R)\cap D(m,m')\ne\varnothing]>=1-beta`，其中 `beta<1`。

记 `Q_{i,m_i}^{C(m)}(R)` 为 verifier 在诚实 codeword 上的实际查询位置集合。
对任意两个消息，记 `D(m,m')={j:C(m)_j != C(m')_j}`。

## 定理：共同核心必须承载全部消息

若存在一个与 `i,m` 无关的坐标集 `K subseteq [N]` 和常数 `theta>beta`，使得对所有
`m,i`

\[
  \Pr_R\bigl[Q_{i,m_i}^{C(m)}(R)\subseteq K\bigr]\ge\theta,
  \tag{1}
\]

则限制映射

\[
  C_K:m\longmapsto C(m)|_K
\]

是 injective。因此

\[
  |K|\ge \frac{k}{\log_2|\Sigma|}.
  \tag{2}
\]

### 证明

取任意 `m,m'`，并令 `i` 满足 `m_i != m'_i`。由显式 DH 假设，诚实查询路径满足

\[
  \Pr_R[Q_{i,m_i}^{C(m)}(R)\cap D(m,m')\ne\varnothing]
  \ge 1-\beta .
  \tag{3}
\]

这里不再从全 oracle soundness 推导 DH；note 192 说明这种推导在跨消息 family 中会
与完备性冲突。

若 `C(m)|_K=C(m')|_K`，则 `D(m,m')\cap K=\varnothing`。于是所有满足
`Q\subseteq K` 的分支都不会命中 `D(m,m')`，从而

\[
  \Pr_R[Q\cap D(m,m')\ne\varnothing]
  \le 1-\Pr_R[Q\subseteq K]
  \le 1-\theta
  < 1-\beta,
\]

与 (3) 矛盾。因此任意不同消息的 `K`-投影都不同，`C_K` injective；计数给出
`|\Sigma|^{|K|}\ge2^k`，即 (2)。\(\square\)

## 坐标依赖核心的边界

若每个坐标 `i` 有自己的 `K_i`，并且

\[
  \Pr[Q_{i,m_i}^{C(m)}\subseteq K_i]\ge\theta>\beta
\]

对所有 `m` 成立，则同一证明仍给出：对任意 `m,m'`，只要 `m_i\ne m'_i`，就有
`C(m)|_{K_i}\ne C(m')|_{K_i}`。因此联合投影
`C|_{\cup_iK_i}` injective，故

\[
  \left|\bigcup_iK_i\right|\ge k/\log_2|\Sigma|.
\]

但这不能推出每个 `K_i` 很大；系统式编码可以令不同坐标使用不同的小核心。这正是
一般集中查询核心尚未被本定理排除的分支。

## 对 ACRR 主线的含义

该定理把 note 189 Conjecture A 的集中分支细化为两个互斥问题：

* **共同核心：** 若声称一个短 `K` 对所有坐标和消息承载超过 `beta` 的查询质量，必须
  支付 `k/log|Sigma|` 的信息容量；因此真正的“短 shared key/core”不能低于消息尺度。
* **坐标/消息依赖核心：** 本定理没有给出超线性下界，需要新的 direct-sum、差异集合
  或 target-binding 论证，说明许多 `K_i` 不能共享编码位置而仍保持同一 global proof。

特别地，本结果不使用近 codeword 完备性、smoothness、constant distance 或 DGL 的
sample-based theorem；它只使用 codeword 完备性、显式 DH 条件和 injectivity。因此它
可以作为所有后续 ACRR/LDC 归约之前的独立组合障碍。DH 并不是普通 target-relative
ACRR 的自动后果。

## 不能推出的结论

不能从 (2) 推出 `N` 超线性于 `k`：当 `N=Theta(k)` 时，一个线性大小的共同核心并不
矛盾。也不能把逐坐标 `K_i` 自动合并为一个共同 `K`；合并需要额外的重叠、对称性或
target-binding 假设。故本 note 是一般性集中核心的精确第一步，而不是完整的 ACRR
impossibility theorem。

## 来源

- [note 187：adaptive query-stability 与 disagreement-hitting](187-adaptive-query-stability-implies-ldc-2026-08-16.md)
- [note 189：ACRR 顶级定理攻坚纲领](189-top-tier-acrr-theorem-program-2026-08-16.md)
- [note 192：ACRR 家族量词审计](192-family-quantifier-audit-for-acrr-barriers-2026-08-16.md)
