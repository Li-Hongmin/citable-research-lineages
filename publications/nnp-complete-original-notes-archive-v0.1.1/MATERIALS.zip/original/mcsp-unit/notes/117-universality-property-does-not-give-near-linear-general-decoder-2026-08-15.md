> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Universality property 不能把通用 batch decoder 自动降到近线性（2026-08-15）

## 判别问题

当前通用构造给出一个固定 gate-list truth-table map

$$
G_q:\{0,1\}^{q}\to\{0,1\}^{2q}
$$

的二次级别电路上界；目标是把它降到

$$
q\,\operatorname{polylog}q.
$$

本 note 检查 Huang--Li--Zhong 的 *Range Avoidance and Remote Point: New Algorithms and
Hardness* 是否通过 universality property 提供了这一步。结论是：没有。该框架把问题转移到
受限电路类的 TTC/universal circuit，而不是给 arbitrary fan-in-2 circuit 的近线性
`q -> 2q` batch decoder。

## 文献直接支持的内容

Huang--Li--Zhong 定义的 universality property 要求：对一个电路类 $\mathcal C$，存在
uniform universal circuit $U_{s,n}$，其输入包括一个 size-$s$ 电路的描述和一个 $n$-bit
assignment，输出该电路在该 assignment 上的值；其规模被记为 $s^c$（常数 $c$ 取决于
该类）。论文给出 AC$^0$、TC$^0$、NC$^1$ 等受限类的相应 universality 结果，并把
`C-Avoid`/`C-Remote-Point` 与 $E$ 或 $E^{NP}$ 的受限电路下界联系起来。

论文的核心等价关系是“受限类 Avoid 算法 $\Longleftrightarrow$ 相应指数时间语言的
受限电路下界”（在其明确的 stretch、uniformity 和输入编码条件下）。它不是

1. 任意 Boolean circuit 的 $q$-bit seed、$2q$ 个 truth-table 输出的 decoder；
2. size-$s$ general circuits 的全部 truth tables 都被一个 $q\operatorname{polylog}q$
   syntax map 覆盖；或
3. 一个直接的 $P\ne NP$ 证明。

## 为什么 universality 不改变本项目的二次上界

### 1. 受限类与一般电路不是同一个 range

令 $\operatorname{TTC}_{\mathcal C}(s,m)$ 表示 $\mathcal C$ 中 size-$s$、$m$ 输入电路
的 truth-table generator。universality property 只保证这个受限类的 evaluator 属于
（或可由）$\mathcal C$ 模拟；它没有把

$$
\{TT(C): C\text{ 是任意 fan-in-2 size-}s\text{ 电路}\}
$$

压缩成同样规模的 $\operatorname{TTC}_{\mathcal C}$。因此，将 AC$^0$/NC$^1$ 的 universal
construction 代入当前 decoder 目标，会改变 coverage family，而不是解决原 family。

### 2. 已知规模指数没有近线性保证

目标参数是 $s\approx q/\operatorname{polylog}q$、$m=\log_2(2q)$。文献中的
$U_{s,m}$ 规模是 $s^c$；文献并未给出 $c=1+o(1)$，也没有给出一个对所有 general
size-$s$ circuits 的 $O(s\operatorname{polylog}s)$ universal evaluator。即使只把
$U_{s,m}$ 当作一个受限类 evaluator，代价仍不是本项目所需的 near-linear syntax budget。

### 3. TTC 的“有一个 assignment 输出”不等于 batch truth-table 输出

universality circuit 的一次求值输出一个 bit。若要同时物化全部 $2^m=2q$ 个 assignment
的输出，必须复制 assignment/evaluation lanes 或提供可复用的 batch composition。对
general circuits，朴素复制正是 note 115 的

$$
O(2^m\,s\log(m+s))=O(q^2)
$$

上界来源。universality property 本身没有消除这项 materialization 成本，也没有提供
一个 whole-tree/right-inverse normalization。

## 对 P vs NP 路线的精确边界

由论文可记录的条件性桥梁是

$$
\text{restricted-class C-Avoid algorithm}
\Longleftrightarrow
\text{restricted circuit lower bound for }E/E^{NP},
$$

而不是

$$
\text{near-linear general TT decoder}
\Longrightarrow P\ne NP.
$$

要让该文献真正改变当前路线，至少还需一个新的、未在论文中给出的命题：

$$
\begin{aligned}
&\text{(i) 一个覆盖 general size-}s\text{ circuits 的 }q\operatorname{polylog}q
   \text{ decoder；}\\
&\text{(ii) 其 batch outputs 的 uniform random-access/evaluation；以及}\\
&\text{(iii) 与 JK 递归兼容的 whole-tree normalization。}
\end{aligned}
$$

在没有 (i)--(iii) 以前，universality property 只能作为受限电路类的 Range Avoidance
文献锚点，不能作为通用 decoder 的近线性构造或 lower bound。

## 证据边界

- Huang, Li, Zhong, *Range Avoidance and Remote Point: New Algorithms and Hardness*,
  ITCS 2026, DOI [10.4230/LIPIcs.ITCS.2026.79](https://doi.org/10.4230/LIPIcs.ITCS.2026.79)，
  官方开放全文：[Dagstuhl PDF](https://d-nb.info/1387946129/34)。
- 以上关于 $q^2$ 的计算是本项目对 batch materialization 的推导；论文的
  universality/Avoid 定理不包含该通用 decoder lower bound。
- 因此截至 2026-08-15，unrestricted
  $q\operatorname{polylog}q$ coverage decoder 的存在性与超线性一般电路下界仍是
  `unknown`；本 note 只关闭“直接把 universality property 当作近线性通用构造”这一条
  路线。
