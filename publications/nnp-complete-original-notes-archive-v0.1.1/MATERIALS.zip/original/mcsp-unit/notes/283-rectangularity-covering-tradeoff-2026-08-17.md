> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Rectangularity-covering tradeoff for coordinate-robust global words

## Statement

Let \(\Gamma\) be an alphabet of size \(Q\ge2\), and let
\(\mathcal Y\subseteq\Gamma^M\) be a family of valid global words. Define
\[
 p_j:=|\pi_j(\mathcal Y)|,\qquad
 d:=\min_{y\ne y'\in\mathcal Y}d_H(y,y').
\]
Assume the rectangular-hull closure condition
\[
 \operatorname{Rect}(\mathcal Y)\subseteq
 \bigcup_{y\in\mathcal Y}B_H(y,t),
 \qquad t=\lfloor\varepsilon M\rfloor.
 \tag{1}
\]
Let
\[
 V_Q(M,t):=\sum_{\ell=0}^{t}\binom M\ell(Q-1)^\ell
\]
be the \(Q\)-ary Hamming-ball volume.

## Theorem 1 (finite projection--covering inequality)

Under (1),
\[
 \sum_{j=1}^M\log_Q p_j
 \;\le\;
 (M-d+1)+\log_Q V_Q(M,t).
 \tag{2}
\]

### Proof

The rectangular hull has cardinality \(\prod_jp_j\). By (1), it is covered by
\(|\mathcal Y|\) Hamming balls of radius \(t\), hence
\[
 \prod_jp_j\le|\mathcal Y|V_Q(M,t).
\]
The Singleton bound for a \(Q\)-ary (possibly nonlinear) code of length \(M\)
and minimum distance \(d\) gives
\[
 |\mathcal Y|\le Q^{M-d+1}.
\]
Taking \(\log_Q\) proves (2). \(\square\)

## Asymptotic form

Write \(\Delta=d/M\). For fixed \(Q\) and
\(0\le\varepsilon<1-1/Q\), the standard \(Q\)-ary entropy bound gives
\[
 \frac1M\sum_{j=1}^M\log_Q p_j
 \le 1-\Delta+H_Q(\varepsilon)+o_M(1),
 \tag{3}
\]
where
\[
 H_Q(\varepsilon)
 =\varepsilon\log_Q(Q-1)
  -\varepsilon\log_Q\varepsilon
  -(1-\varepsilon)\log_Q(1-\varepsilon).
\]

In particular, if every coordinate is symbol-rich,
\(p_j=Q\) for all \(j\), then
\[
 \Delta\le H_Q(\varepsilon)+o_M(1).
 \tag{4}
\]
For binary words this is \(\Delta\le H_2(\varepsilon)+o_M(1)\). Thus a
constant-distance valid-word family with full coordinate projections cannot have
a black-box coordinatewise-to-global closure radius below the corresponding
entropy threshold.

## Theorem 2 (full-projection packing strengthening)

If every coordinate has full projection, \(p_j=Q\), then
\(\operatorname{Rect}(\mathcal Y)=\Gamma^M\). Assume \(|\mathcal Y|\ge2\), and let
\[
 r_d:=\left\lfloor\frac{d-1}{2}\right\rfloor .
\]
The Hamming balls of radius \(r_d\) around distinct words of \(\mathcal Y\) are disjoint,
whereas (1) covers the whole ambient space by the radius-\(t\) balls. Consequently,
\[
 |\mathcal Y|V_Q(M,r_d)
 \le Q^M
 \le |\mathcal Y|V_Q(M,t),
 \qquad
 V_Q(M,r_d)\le V_Q(M,t).
\tag{5}
\]
Since \(V_Q(M,\cdot)\) is strictly increasing up to radius \(M\), this implies
\[
 \left\lfloor\frac{d-1}{2}\right\rfloor\le t,
 \qquad d\le 2t+2.
\tag{6}
\]
Thus full coordinate projections plus rectangular closure force the minimum valid-word
distance to be at most twice the global correction radius (up to the integer endpoint).
This packing bound is stronger than (4) whenever \(t/M\) is small.

### Proof

The first inequality in (5) is the ordinary Hamming packing bound for a code of minimum
distance \(d\). Full projections make the rectangular hull equal to \(\Gamma^M\), and (1)
therefore gives the second inequality. Cancelling \(|\mathcal Y|\) yields the volume
comparison and hence (6). \(\square\)

## Theorem 3 (projection-packing refinement)

For arbitrary projection sizes \(p_j\), still assuming \(|\mathcal Y|\ge2\) and (1), the
same packing argument gives
\[
 \prod_{j=1}^M p_j\;V_Q(M,r_d)
 \le Q^M V_Q(M,t),
\qquad
 \sum_{j=1}^M\log_Q p_j
 \le M+\log_Q V_Q(M,t)-\log_Q V_Q(M,r_d).
\tag{7}
\]
This refinement combines projection entropy with minimum distance directly; it reduces to
(5) in the full-projection case and can be stronger than the Singleton-based bound (2)
when \(d\) is large.

### Proof

The covering premise gives
\(\prod_jp_j\le|\mathcal Y|V_Q(M,t)\), while Hamming packing gives
\(|\mathcal Y|V_Q(M,r_d)\le Q^M\). Eliminating \(|\mathcal Y|\) yields (7). \(\square\)

## Theorem 4 (weighted projection-packing refinement)

The same argument survives nonuniform coordinate sampling. Let
\(\lambda_1,\ldots,\lambda_M\ge0\) with \(\sum_j\lambda_j=1\), and define
\[
 d_\lambda(x,y):=\sum_{j=1}^M\lambda_j\,\mathbf 1[x_j\ne y_j],
 \qquad
 V_{Q,\lambda}(u):=
 \sum_{\substack{S\subseteq[M]\\\sum_{j\in S}\lambda_j\le u}}
 (Q-1)^{|S|}.
\tag{8}
\]
Assume the weighted rectangular-hull closure
\[
 \operatorname{Rect}(\mathcal Y)\subseteq
 \bigcup_{y\in\mathcal Y}\{z:d_\lambda(z,y)\le t\}.
\tag{9}
\]
If \(d_\lambda:=\min_{y\ne y'\in\mathcal Y}d_\lambda(y,y')\) and
\(0\le r<d_\lambda/2\), then
\[
 \prod_{j=1}^M p_j\;V_{Q,\lambda}(r)
 \le Q^M V_{Q,\lambda}(t),
 \qquad
 \sum_{j=1}^M\log_Qp_j
 \le M+\log_QV_{Q,\lambda}(t)-\log_QV_{Q,\lambda}(r).
\tag{10}
\]
Zero-weight coordinates are allowed; if \(d_\lambda=0\), the statement is vacuous
for positive packing radius, as it should be.

### Proof

Every weighted ball has the center-independent volume \(V_{Q,\lambda}(u)\).
The strict inequality \(2r<d_\lambda\) makes the radius-\(r\) balls around valid
words disjoint, while (9) covers the rectangular hull, whose size is
\(\prod_jp_j\), by radius-\(t\) balls. Thus
\[
 \prod_jp_j\le|\mathcal Y|V_{Q,\lambda}(t),
 \qquad
 |\mathcal Y|V_{Q,\lambda}(r)\le Q^M.
\]
Eliminating \(|\mathcal Y|\) proves (10). \(\square\)

The weighted form is the appropriate version when a dPCP samples coordinates
nonuniformly or when some coordinates are replicated more heavily than others.
It does not assume that the weights arise from an actual verifier, and therefore
remains a coding-level closure theorem rather than an unconditional dPCP lower bound.

## Theorem 5 (weighted product-rectangular anti-concentration)

Let \(Z=(Z_1,\ldots,Z_M)\) choose its coordinates independently and uniformly from
the projection sets \(\pi_j(\mathcal Y)\).  For weights \(\lambda\) as in Theorem 4,
define
\[
 V_{\mathbf p,\lambda}(t):=
 \sum_{\substack{S\subseteq[M]\\\sum_{j\in S}\lambda_j\le t}}
 \prod_{j\in S}(p_j-1).
\tag{11}
\]
Then
\[
 \Pr\!\left[d_\lambda(Z,\mathcal Y)\le t\right]
 \le
 \frac{|\mathcal Y|\,V_{\mathbf p,\lambda}(t)}
      {\prod_{j=1}^M p_j}
 \le
 \frac{Q^{M-d+1}\,V_{\mathbf p,\lambda}(t)}
      {\prod_{j=1}^M p_j}.
\tag{12}
\]
The second inequality uses the \(Q\)-ary Singleton bound and is valid when
\(|\mathcal Y|\ge2\).

### Proof

For a fixed \(y\in\mathcal Y\), the event
\(d_\lambda(Z,y)\le t\) is the disjoint union over error sets
\(S=\{j:Z_j\ne y_j\}\) with \(\sum_{j\in S}\lambda_j\le t\).  Its probability is
\[
 \frac{1}{\prod_jp_j}
 \sum_{\substack{S\subseteq[M]\\\sum_{j\in S}\lambda_j\le t}}
 \prod_{j\in S}(p_j-1)
 =
 \frac{V_{\mathbf p,\lambda}(t)}{\prod_jp_j}.
\]
Union bounding over \(y\) gives the first inequality in (12), and Singleton gives
the second. \(\square\)

For \(p_j=Q\) and uniform weights, (12) reduces to the ordinary product-rectangular
anti-concentration bound.  The weighted form shows that nonuniform sampling cannot
repair a high-entropy independent coordinate interface unless the mass is concentrated
on a small set of coordinates or the valid-word family has low distance/large overlap.
This is still a black-box product theorem; a same-seed/global coupling lies outside its
hypotheses.

## Interpretation for shared-proof PCPs

The theorem applies whenever the local interface can realize every symbol in each
coordinate through some valid proof word, while the valid global proof words are
separated. It then gives a coding-theoretic obstruction to simultaneously having:

- high coordinate projection entropy;
- constant proof-word distance;
- small global correction radius after coordinatewise explanations.

The hypothesis is deliberately stronger than ordinary distributional soundness and
deliberately weaker than a full code assumption: only projection sizes, minimum
distance, and rectangular-hull coverage are used. If projections are not full, (3)
quantifies the remaining escape through their average entropy. A concrete dPCP can
avoid the bound only by reducing projection entropy, increasing correction radius,
reducing word distance, or adding a joint same-seed relation that invalidates the
black-box rectangular-hull model.

This is a general coding theorem for the proposed RW/JK interface, not a claim that
existing dPCP constructions meet the hypotheses. The next positive target is to
prove either a near-linear construction outside the rectangular black-box model or
a source-specific lower bound showing that its projections and distance force (2)
to fail.
