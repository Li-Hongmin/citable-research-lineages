> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Balanced-cut Fourier quotients and arbitrary-order OBDD width (2026-08-25)

This note removes the lexicographic-order restriction from
[note 533](533-sharp-semantic-entropy-and-canonical-obdd-width-2026-08-25.md).  The new input
is a Fourier averaging lemma: every balanced partition of the truth-table coordinates admits a
small linear quotient with very few monochromatic fibers.  After fixing those exceptional cells,
the packed-selector family from note 533 remains recoverable from both sides of the partition.

Throughout, circuits are single-output, have fan-in at most two and unbounded fan-out, and use the
standard basis \(\{\mathsf{AND},\mathsf{OR},\mathsf{NOT}\}\).  Let \(N=2^n\),
\(S=\lfloor2^{\mu n}\rfloor\), where
\(0<\mu<1\) is fixed.

## Lemma 47 (balanced-cut quotient)

Let \(P\sqcup Q=\mathbb F_2^n\) with \(|P|=|Q|=2^{n-1}\).  For every \(1\le r<n\), there
is a surjective linear map
\[
 L:\mathbb F_2^n\to\mathbb F_2^r
\]
such that the number \(B_L\) of labels \(y\in\mathbb F_2^r\) for which the fiber
\(L^{-1}(y)\) is contained in \(P\) or in \(Q\) satisfies
\[
 \boxed{
 |B_L|
 \le
 2^r\frac{2^r-1}{2^n-1}.
 }
 \tag{534.1}
\]

### Proof

Put \(\chi=1_P-1_Q\) and use normalized Fourier coefficients
\[
 \widehat\chi(\alpha)
 =\mathbb E_x\chi(x)(-1)^{\alpha\cdot x}.
\]
For a codimension-\(r\) subspace \(K\), let
\[
 b_{x+K}=\mathbb E_{k\in K}\chi(x+k).
\]
Conditional expectation and Parseval give
\[
 \mathbb E_{x+K}b_{x+K}^2
 =\sum_{\alpha\in K^\perp}\widehat\chi(\alpha)^2.
 \tag{534.2}
\]
A monochromatic coset has \(b_{x+K}^2=1\), so its proportion among all \(2^r\) cosets is at
most (534.2).

Choose the \(r\)-dimensional space \(K^\perp\) uniformly.  Each nonzero character belongs to it
with probability
\[
 \frac{2^r-1}{2^n-1}.
\]
The balance assumption gives \(\widehat\chi(0)=0\), while Parseval gives
\(\sum_{\alpha\ne0}\widehat\chi(\alpha)^2=1\).  Hence the expectation of (534.2) is exactly
\((2^r-1)/(2^n-1)\).  Some \(K\) attains at most this value.  Taking any linear quotient
\(L\) with kernel \(K\) proves (534.1). \(\square\)

## Lemma 48 (two-sided recoverable easy family)

For every balanced partition \(P\sqcup Q=\mathbb F_2^n\), there is a family
\(\mathcal H_{P,Q}\subseteq\mathcal L_{n,S}\) such that both restriction maps
\[
 f\mapsto f|_P,
 \qquad
 f\mapsto f|_Q
 \tag{534.3}
\]
are injective on \(\mathcal H_{P,Q}\), and
\[
 \boxed{
 \log_2|\mathcal H_{P,Q}|
 \ge
 S\log_2S-O(S\log_2\log_2S).
 }
 \tag{534.4}
\]

### Proof

Reserve \(O(n^2)\) gates and apply Proposition 44 of note 533 with budget
\[
 S_0=S-O(n^2).
\]
Its construction gives an integer
\[
 r=\log_2S+\log_2\log_2S+O(1)<n
\]
and a set of freely assignable selector cells \(T\subseteq\mathbb F_2^r\) such that
\[
 |T|=S\log_2S-O(S\loglog S),
 \qquad
 2^r=O(S\log S),
 \tag{534.5}
\]
and every bit assignment on \(T\) extends to an \(r\)-variable function computed by at most
\(S_0\) gates.  Explicitly, \(T\) consists of the \(k2^q\) data cells of the packed-selector
construction; the remaining selector leaves may reuse the first component.

Apply Lemma 47 at this value of \(r\), and let \(B_L\) be the monochromatic fiber labels.  By
(534.1) and (534.5),
\[
 |B_L|
 =O\!\left(\frac{2^{2r}}{N}\right)
 =O\!\left(\frac{S^2\log^2S}{N}\right)
 =o(S),
 \tag{534.6}
\]
because \(S=N^\mu\) and \(\mu<1\).

Fix the values on \(T\cap B_L\) to zero and let the remaining cells of \(T\) vary freely.
For each resulting \(h:\mathbb F_2^r\to\{0,1\}\), define
\[
 f_h(x)=h(Lx).
\]
The standard basis computes each of the \(r\) linear forms defining \(L\) with
\(O(n)\) gates, hence computes \(L\) with \(O(nr)=O(n^2)\) gates.  Thus
\(f_h\in\mathcal L_{n,S}\).  Every free fiber \(L^{-1}(y)\), \(y\in T\setminus B_L\), meets
both \(P\) and \(Q\).  Either restriction in (534.3) therefore recovers every free value
\(h(y)\), proving both injectivities.  Finally,
\[
 \log_2|\mathcal H_{P,Q}|
 =|T\setminus B_L|
 \ge |T|-|B_L|,
\]
and (534.4) follows from (534.5)--(534.6). \(\square\)

## Lemma 49 (equality graph for an arbitrary coordinate cut)

Let \(A\subseteq\{0,1\}^N\), let \(P\sqcup Q=[N]\), and suppose
\(\mathcal H\subseteq A\) has both restriction maps to \(P\) and \(Q\) injective.  Then the
deterministic residual width after reading the coordinates in \(P\) obeys
\[
 \boxed{
 W_P(A)
 \ge
 \frac{|\mathcal H|^2}{2|A|+|\mathcal H|}.
 }
 \tag{534.7}
\]

### Proof

Join distinct \(f,g\in\mathcal H\) when either cross-table
\[
 f|_P\cup g|_Q,
 \qquad
 g|_P\cup f|_Q
\]
lies in \(A\).  The ordered cross-table map is injective because each side restriction is
injective on \(\mathcal H\).  Hence the graph has at most \(|A|\) edges.  An independent set
\(I\) has pairwise distinct residuals: the residual after \(f|_P\) accepts \(f|_Q\), whereas
the residual after \(g|_P\) rejects it for \(f\ne g\).  The greedy independent-set bound
\(\alpha\ge|\mathcal H|^2/(2|E|+|\mathcal H|)\) proves (534.7). \(\square\)

## Theorem 50 (tight arbitrary-order OBDD width for exponential-threshold MCSP)

For every permutation \(\pi\) of the \(N\) truth-table coordinates,
\[
 \boxed{
 \log_2W^\pi_{N/2}(\mathrm{MCSP}_S)
 =(1+o(1))S\log_2S.
 }
 \tag{534.8}
\]
Consequently the minimum width and minimum size of an OBDD for \(\mathrm{MCSP}_S\), optimized
over all variable orders, satisfy
\[
\boxed{
 \log_2\operatorname{OBDDwidth}(\mathrm{MCSP}_S)
 =\log_2\operatorname{OBDDsize}(\mathrm{MCSP}_S)
 =(1+o(1))S\log_2S.
}
\tag{534.9}
\]

### Proof

Let \(P\) be the first \(N/2\) coordinates in order \(\pi\), and let \(Q\) be the rest.
Apply Lemmas 48--49 with \(A=\mathcal L_{n,S}\).  Proposition 43 of note 533 gives
\[
 \log_2|A|\le S\log_2S+O(S),
\]
while (534.4) gives
\[
 \log_2|\mathcal H_{P,Q}|
 \ge S\log_2S-O(S\loglog S).
\]
Taking logarithms in (534.7) proves the lower bound in (534.8), uniformly for every \(\pi\).
For the upper bound, the prefix trie of \(A\) in any chosen order has at most \(|A|+1\) states
per layer and at most \(N(|A|+1)\) nodes.  This proves (534.8)--(534.9). \(\square\)

## Boundary

Theorem 50 is stated for deterministic oblivious read-once branching programs after optimizing
their global variable order.  [Note 536](536-identity-submatrices-and-ordered-nondeterministic-algebraic-width-2026-08-25.md)
observes that the same independent set is an identity submatrix and upgrades the sharp exponent
to strictly layered fixed-order nondeterministic, parity, and exact field-weighted programs.
Neither statement covers free BDDs whose queried variable may depend on the path, path-dependent
read-once nondeterministic programs, general branching programs, or one-tape computation.
The decisive quantifier order is
\[
 \forall\pi\ \exists L_\pi\ \exists\mathcal H_\pi.
\]
The Fourier quotient is selected nonconstructively as a function of the coordinate cut; this is
sufficient for a lower bound against every order but is neither one quotient that serves all
orders nor an efficient uniform transformation.

## Dependencies

- [Sharp semantic entropy and lexicographic width](533-sharp-semantic-entropy-and-canonical-obdd-width-2026-08-25.md)
- [Middle-cut equality gadget](529-middle-cut-equality-gadget-residual-boundary-2026-08-24.md)
- Normalized Fourier Parseval identity on \(\mathbb F_2^n\)
