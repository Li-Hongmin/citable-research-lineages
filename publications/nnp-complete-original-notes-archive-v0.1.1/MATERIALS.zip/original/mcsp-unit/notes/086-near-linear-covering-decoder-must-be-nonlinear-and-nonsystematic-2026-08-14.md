> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Near-linear covering decoder 必须 nonlinear 且 non-systematic（2026-08-14）

## 结论

[note 085](085-lupanov-block-packing-and-near-linear-decoder-window-2026-08-14.md) 把 generic JK
仍可能承重的参数压到 near-linear stretch map：需要

\[
G_q:\{0,1\}^q\to\{0,1\}^{2q},
\qquad |G_q|=q\operatorname{polylog}q,
\tag{1}
\]

并让其 range 覆盖足够多的 low-circuit truth tables，同时保持 fixed-exponent recursive
preimage selection。

本 note 确定这个对象的第一组结构边界。令

\[
m=\log_2(2q),
\qquad
\mathcal C_{m,s}
=\{TT(C):C\text{ 是 size-}\le s\text{ 的 }m\text{-variable circuit}\}.
\tag{2}
\]

若

\[
\mathcal C_{m,s}\subseteq\operatorname{Range}(G_q),
\tag{3}
\]

则必有两个无条件下界：

\[
\boxed{q=\Omega(s\log s),}
\tag{4}
\]

以及只要 \(s\ge c\log q\)，

\[
\boxed{|G_q|\ge q-O(1).}
\tag{5}
\]

所以 \(s=\Theta(q/\log q)\) 已处于 description-capacity 极限，而 near-linear syntax 仍未被 counting
排除。

另一方面，两个最自然的 near-linear candidates 严格失败：

\[
\boxed{
\begin{array}{c}
\exists J\subseteq[2q],\ |J|=q:\ G_q(u)|_J=u\text{ for every }u,\\
\text{或 }G_q\text{ affine}
\end{array}
\quad\Longrightarrow\quad
\{0,e_1,\ldots,e_{2q}\}\not\subseteq\operatorname{Range}(G_q).
}
\tag{6}
\]

其中 \(e_i\) 是 singleton truth table，且每个 \(e_i\) 只有 \(O(\log q)\) circuit complexity。因此任何
满足式 (3) 的 near-linear decoder 必须是 nonlinear、non-systematic 的 batch compression map。

定向文献检索没有找到式 (1)--(3) 的构造，也没有找到排除它的 superlinear general-circuit lower
bound。标准 gate-list / universal-evaluation 路线仍需对全部 \(2q\) assignments 批量求值，在
\(s=\Theta(q/\log q)\) 尺度给出 near-quadratic 而不是 near-linear syntax。当前正确裁决是

\[
\boxed{
\text{near-linear low-circuit-covering decoder：unknown；}
\quad
\text{linear/systematic shortcuts：已排除。}
}
\tag{7}
\]

此外，near-linear coverage 本身仍不够：JK recursion 需要一个 exponent-stable representation class
或 whole-tree coherent labeling。单查询 projection inverse 虽能保持 exponent，却已被式 (6) 排除。
因此存活对象还必须具有 non-systematic inverse 与 representation-specific normalization。

本文没有证明 \(P\ne NP\)。

## Description-capacity lower bound

先处理参数端点。由同一个 Lupanov upper bound，全部 \(m\)-variable functions 都有 size
\(O(2^m/m)=O(q/\log q)\) 的 circuit。因此存在绝对常数 \(C>0\)，使得若
\(s\log s>Cq\)，则 \(\mathcal C_{m,s}\) 已包含全部 \(2^{2q}\) truth tables（增大 \(C\) 也覆盖
\(s>2q\) 的平凡情形），与式 (3) 及 \(|\operatorname{Range}(G_q)|\le 2^q\) 矛盾。

若 \(s\) 有界，则式 (4) 平凡。故以下设 \(s\) 足够大，并只需考虑 \(s\log s\le Cq\)。先按
Lupanov upper bound 的隐含常数、再按前述 endpoint 常数选择足够小的 \(c_0>0\)，令 \(\ell\) 为满足
\(2^\ell/\ell\le c_0s\) 的最大整数。该选择保证 \(\ell\le m\)，并且

\[
\frac{2^\ell}{\ell}\le c_0s
\quad\text{且}\quad
2^\ell=\Theta(s\log s),
\tag{8}
\]

由 Jukna Theorem 1.15 的 Lupanov upper bound，每个 \(\ell\)-variable Boolean function 都有
size 至多 \(s\) circuit。把它们嵌入为忽略最后 \(m-\ell\) 个 variables 的 \(m\)-variable
functions，得到

\[
|\mathcal C_{m,s}|
\ge 2^{2^\ell}
=2^{\Theta(s\log s)}.
\tag{9}
\]

而任意 \(q\)-bit-input map 只有

\[
|\operatorname{Range}(G_q)|\le2^q.
\]

式 (3) 与式 (9) 因而推出式 (4)。特别地，若 \(s=\omega(q/\log q)\)，任何这样的 decoder 都因
range cardinality 不可能存在。

这里必须保留常数边界。足够小常数的 \(s=cq/\log q\) 与式 (4) 相容；若常数大到
\(\mathcal C_{m,s}\) 已包含全部 \(2^{2q}\) truth tables，则式 (3) 当然与 \(2^q\)-sized range 矛盾。

## Decoder syntax 至少线性

当 \(s\ge c\log q\) 时，\(\mathcal C_{m,s}\) 包含零函数和全部 singleton functions

\[
0,e_1,\ldots,e_{2q}.
\tag{10}
\]

记 \(G_i:\{0,1\}^q\to\{0,1\}\) 为 \(G_q\) 的第 \(i\) 个 output-coordinate function。若
\(G_i=G_j\) 作为 functions 相同，则所有 range strings 的第 \(i,j\) bits 都相等，与
\(e_i\in\operatorname{Range}(G_q)\) 矛盾。每个 \(G_i\) 也非恒定，因为 range 同时包含 \(0\) 与
\(e_i\)。

在标准 circuit convention 下，outputs 只能指定现有 input/gate wires；每个产生新 wire function 的
operation（包括 negation）都计入 \(S\)，只有 \(O(1)\) 个 constant sources 免费。因此一个具有
\(q\) 个 input wires 与 \(S\) 个 gates 的 fan-in-two circuit，至多提供

\[
q+S+O(1)
\]

个不同 wire functions。\(2q\) 个 output functions 必须彼此不同且非恒定，因此

\[
2q\le q+S+O(1),
\]

即得式 (5)。该证明只给 linear lower bound，完全不排除式 (1)。证明
\(|G_q|\ge q^{1+\varepsilon}\) 将是 explicit general multi-output circuit 的超线性下界；本项目没有
这样的论证。

## Systematic projection 不可能覆盖

设存在固定 coordinate set

\[
J\subseteq[2q],
\qquad |J|=q,
\]

使 \(G_q\) 在这些 coordinates 上 systematic：

\[
G_q(u)|_J=u.
\tag{11}
\]

取 \(t\notin J\)。零表 \(0^{2q}\) 与 singleton \(e_t\) 在 \(J\) 上都等于 \(0^q\)。若二者都在
range，则式 (11) 强制它们有同一个 preimage \(u=0^q\)，但 function \(G_q\) 对同一 input 不能有两个
outputs，矛盾。

因此任何从固定 \(q\) 个 output coordinates 直接读取 preimage 的 projection-systematic decoder，
甚至不能同时覆盖零表与全部 singleton tables。特别地，最自然的

\[
G_q(u)=u\Vert P(u)
\]

虽有单查询、递归稳定的 inverse \(u=z_L\)，却不满足 low-circuit coverage。

## Affine decoder 不可能覆盖

若 \(G_q\) affine，则其 range 是 \(\mathbb F_2^{2q}\) 的 affine subspace。若 range 包含零表，它
实际上是一个 dimension 至多 \(q\) 的 linear subspace。若还包含全部 \(e_i\)，则包含它们的 span

\[
\operatorname{span}\{e_1,\ldots,e_{2q}\}
=\mathbb F_2^{2q},
\]

其 dimension 为 \(2q\)，矛盾。因此快速 Walsh--Hadamard、Reed--Solomon-style linear encoding
不能直接满足式 (3)。

该结论只排除 affine range。本项目不把“可用 FFT-like algorithm 计算”与“affine”混同；非线性的
near-linear batch map 仍可能存在。

## Coverage 与 batch evaluation 的区别

若每个 gate-list circuit \(C\) 都有一个可有效计算的 code

\[
\operatorname{Enc}(C)\in\{0,1\}^q,
\qquad
G_q(\operatorname{Enc}(C))=TT(C),
\tag{12}
\]

则 \(G_q\circ\operatorname{Enc}\) 是 batch universal evaluator：一次输出 \(C\) 在全部
\(2q\) assignments 上的值。反之，任何这样的 batch evaluator 加 canonical padding 就给出满足
式 (3) 的 decoder。

但式 (3) 本身只要求每个 truth table **存在** 某个 code，不要求从 \(C\) 有效找到它。因此 arbitrary
code assignment 版本严格弱于 efficient batch evaluation；不能用后者的构造困难或 lower bound
冒充前者的不可能性。

现有安全 gate-list construction 为每个 assignment 复制 evaluator，正是 note 082 的
polynomially superlinear decoder。Valiant universal circuits 优化 single-assignment simulation，
但直接复制到全部 assignments 不给式 (1)。Korten 与 Li 的 truth-table generators 同样只提供
polynomial-size 或 description-length bounds，没有给 near-linear batch syntax。

## Recursive right-inverse closure

设 level \(i\) 的 block family 有 joint accessor size \(s_i\)。若一个 inverse-bit procedure 对该
accessor 发出 \(Q\) 次 queries，普通 circuit inlining 只给

\[
s_{i-1}\le Qs_i+n^{O(1)}.
\tag{13}
\]

经过 \(h=\Theta(\log T)=\Theta(n)\) levels，naive expansion 可达到 \(Q^h\)。这不是 lower bound：
共享或 algebraic normalization 可能压缩它；但式 (13) 说明 fixed-query local inversion 本身不自动
保持 fixed polynomial exponent。

一个充分而非循环的接口是存在 representation class \(\mathcal R_n\) 与 fixed \(C\)，使：

1. initial block family 属于 \(\mathcal R_n\)；
2. 每个 \(R\in\mathcal R_n\) 给出 size 至多 \(n^C\) 的 joint accessor；
3. 每次 range descent 都产生仍属于 \(\mathcal R_n\) 的 word-consistent preimage family；
4. 第一处 non-image block 也由当前 \(R\) 以 size \(n^C\) 访问；
5. \(C\) 与 level 和 \(h\) 无关。

这是待证明的 closure specification，不是从 coverage 推出的结构定理。对当前实际 JK history，一个更强而
直接的表述是存在 whole-tree labeling circuit

\[
D_n(i,j,\ell),
\qquad |D_n|\le n^C,
\tag{14}
\]

同时描述全部 actual JK edges。该 history-relative labeling 不自动给出对全部 range elements 或全部
compact accessors 的 universal normalization。projection-systematic map 为式 (14) 提供最简单的
单查询闭包，但已被式 (6) 排除。canonical gate-list decoder 有 coverage，却没有已知的
circuit-synthesis closure。

ignored padding 还说明“任取 preimage”在局部复杂度上不安全：若

\[
G(v,w)=G_0(v),
\]

selector 可以把任意高-accessor string 写入无效的 \(w\)。这只反驳 arbitrary-selector inference；
它不排除同一 map 另有 compact canonical selector。

所以真正存活的接口是

\[
\boxed{
\text{nonlinear, non-systematic near-linear coverage}
+
\text{representation-specific inverse normalization}.}
\tag{15}
\]

### 文献边界

检索与原文核验截止：2026-08-14。

- Stasys Jukna, *Boolean Function Complexity: Advances and Frontiers*, 2012 author-posted draft,
  Theorem 1.15。
- Leslie G. Valiant, *Universal Circuits (Preliminary Report)*, STOC 1976,
  DOI `10.1145/800113.803649`。本轮核验 metadata；它是 single-input universal-circuit 检索锚点，
  不作为式 (4)--(6) 的证明依据。
- Oliver Korten, *The Hardest Explicit Construction*, FOCS 2021, Theorem 1 and Theorem 7.
- Zeyong Li, *Symmetric Exponential Time Requires Near-Maximum Circuit Size*, STOC 2024,
  Definition 3.1 and Lemma 3.2.
- Oliver Korten and Toniann Pitassi, *Strong vs. Weak Range Avoidance and the Linear Ordering
  Principle*, FOCS 2024.

式 (4)--(6)、(8)--(15) 是本项目的 counting、linear-algebra 与 composition 推论。文献未命中只支持
“当前未找到”，不支持绝对不存在 near-linear decoder。
