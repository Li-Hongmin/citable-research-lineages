> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW seed-correlation/fanout global-relation barrier（2026-08-19）

## 本轮关闭的边界

C418 把 seed 坐标在 \((X,S)\) 下条件独立时的 residual correlation 收费为
“seed entropy \(\times\) fanout”。但它没有覆盖一个更强的逃逸：seed 坐标本身在
给定 target 与 policy 后仍然相关。本 note 在同一个 coordinate-factorized 模型中
保留这项相关性，并证明它只能以一个额外的 conditional total correlation 支付：

\[
 \operatorname{TC}_2(Z\mid X,S)
 \le
 \sum_{\ell}(D_\ell-1)H_2(U_\ell\mid X,S)
 +\operatorname{TC}_2(U\mid X,S).
\tag{419.1}
\]

因此，C411 的 global-word/Fano 账本给出三分：线性的 target/policy channel、
线性的 seed entropy\(\times\)fanout，或线性的 seed-after-conditioning
total correlation。该结论仍是 seed-factorized relation theorem，不是一般
dPCP、PCPP、LDC 或 RLDC 的无条件不可能性。

## 模型

令 \(Q:=(X,S)\)。目标 \(X\) 在一个 \(b\)-bit、最小距离大于 \(2t\) 的 canonical
family 上取值，\(Z=(Z_1,\ldots,Z_M)\) 是同一 proof/address space 上产生的
global word。设 seed \(U=(U_1,\ldots,U_d)\) 具有任意的条件联合分布

\[
  \operatorname{TC}_2(U\mid Q):=
  \sum_{\ell=1}^{d}H_2(U_\ell\mid Q)-H_2(U\mid Q).
\]

删去所有不被任何坐标读取的 seed coordinate。对每个坐标给定一个
neighborhood \(N(j)\subseteq[d]\) 和局部随机带 \(R_j\)，满足：

1. \(R_1,\ldots,R_M\) 在给定 \(Q\) 后彼此独立，并且与 \(U\) 条件独立；
2. \(Z_j=\phi_j(Q,U_{N(j)},R_j)\)；
3. \(D_\ell:=|\{j:\ell\in N(j)\}|\)，并令 \(D:=\max_\ell D_\ell\)。

条件独立的 local random tapes 是为了保证这里只收费 seed 与 seed-neighborhood
造成的依赖；若坐标在 seed 之后仍直接联合访问 proof state，则不属于本模型。

记
\[
 p_b:=\Pr[d_H(Z,\Pi_X)\le t],
\]
其中 \(\Pi_X\) 是 \(X\) 的 canonical word。

## 引理 419.1（seed correlation/fanout bound）

在上述模型下，

\[
 \operatorname{TC}_2(Z\mid Q)
 \le
 \sum_{\ell:D_\ell\ge1}(D_\ell-1)H_2(U_\ell\mid Q)
 +\operatorname{TC}_2(U\mid Q)
 \le
 (D-1)\sum_{\ell=1}^{d}H_2(U_\ell\mid Q)
 +\operatorname{TC}_2(U\mid Q).
\tag{419.2}
\]

### 证明

令 \(W_j:=(U_{N(j)},R_j)\)。给定 \(Q\)，每个 \(Z_j\) 是对应 \(W_j\) 的逐坐标
信道输出；条件 KL data processing（等价地，total correlation 在逐坐标信道下
不增加）给出

\[
 \operatorname{TC}_2(Z\mid Q)
 \le \operatorname{TC}_2(W\mid Q).
\tag{419.3}
\]

由 \(R_1,\ldots,R_M\) 在 \(Q\) 下相互独立且与 \(U\) 独立，

\[
\begin{aligned}
 \operatorname{TC}_2(W\mid Q)
 &=\sum_j H_2(U_{N(j)},R_j\mid Q)-H_2(U,R\mid Q)\\
 &=\sum_j H_2(U_{N(j)}\mid Q)-H_2(U\mid Q).
\end{aligned}
\tag{419.4}
\]

对子集熵使用子加性，

\[
 \sum_j H_2(U_{N(j)}\mid Q)
 \le \sum_{\ell:D_\ell\ge1}D_\ell H_2(U_\ell\mid Q).
\tag{419.5}
\]

把

\[
 -H_2(U\mid Q)
 =-\sum_\ell H_2(U_\ell\mid Q)+\operatorname{TC}_2(U\mid Q)
\]

代入 (419.4)--(419.5)，得到第一项。再用 \(D_\ell\le D\) 得到第二项。证毕。

### 两个 sharpness 例子

* 若 seed 坐标条件独立，一个均匀 binary seed 被 \(D\) 个坐标复制，则
  \(\operatorname{TC}_2(Z)=D-1\)，恢复 C418 的 fanout 项，故 \(D-1\) 不能删除。
* 若 \(U_1=\cdots=U_d=V\) 是同一个均匀 binary bit，且第 \(\ell\) 个输出只读取
  \(U_\ell\)，则 \(D_\ell=1\)，fanout 项为零，但
  \(\operatorname{TC}_2(U)=d-1\) 且输出的 total correlation 也可达到 \(d-1\)。
  这说明 seed-after-conditioning dependence 必须单独记账，不能被 seed length
  或 fanout 项替代。

## 定理 419.2（general seed-factorized trichotomy）

在上述模型中，若 canonical family 最小距离大于 \(2t\)，则

\[
 I_2(X;S)+\sum_{j=1}^{M}I_2(X;Z_j\mid S)
 +(D-1)\sum_{\ell=1}^{d}H_2(U_\ell\mid X,S)
 +\operatorname{TC}_2(U\mid X,S)
 \ge p_b b-1.
\tag{419.6}
\]

### 证明

C411 的 nearest-word/Fano 账本给出

\[
 I_2(X;S)+\sum_jI_2(X;Z_j\mid S)
 +\operatorname{TC}_2(Z\mid X,S)
 \ge p_b b-1.
\tag{419.7}
\]

将引理 419.1（取 \(Q=(X,S)\)）代入 (419.7) 即得 (419.6)。证毕。

## 推论 419.3（seed-after-conditioning escape 的精确边界）

若 \(p_b\ge p_0>0\)，且 target/policy channel 与 fanout 项均为 \(o(b)\)，则任何
成功 relation 都必须满足

\[
 \operatorname{TC}_2(U\mid X,S)=\Omega(b).
\tag{419.8}
\]

更定量地，对任意 \(0\le\theta<p_0\)，至少一项成立：

\[
 I_2(X;S)+\sum_jI_2(X;Z_j\mid S)
 \ge (p_0-\theta)b-1,
\tag{419.9}
\]

或

\[
 (D-1)\sum_\ell H_2(U_\ell\mid X,S)
 +\operatorname{TC}_2(U\mid X,S)
 \ge \theta b-1.
\tag{419.10}
\]

所以一个低 target-information、低 fanout 的短 seed 若要完成 constant-probability
whole-word binding，必须携带线性的 conditional total correlation。该相关性若可
进一步编译成 JK half-lift，则进入 C417/C410 的 circuit payment；若不能，则它
正是尚待构造或证明不可能的真正 global relation。

## 与 RW Closure 的边界

1. 这一定理推广 C418，但只覆盖 \(Z_j\) 通过各自 seed-neighborhood 和独立 local
   tape 生成的 coordinate-factorized relation。post-seed 的直接 joint coupling、
   joint proof-state query 或非局部 verifier 不满足假设。
2. \(\operatorname{TC}_2(U\mid X,S)\) 是 seed 坐标表示的相关性账本，不等同于 seed
   的比特长度；重复编码同一个 bit 可以使该量线性增大。若要把它转成 LDC/RLDC
   或 circuit 下界，还需要额外的 representation/minimality 定理。
3. published RW Theorem 4.3 的 \(x_0\) 是 singleton；将 (419.6) 用于 RW 仍需先
   建立 target-relative family/common-proof 量词，不能把 family entropy 偷换成
   singleton parent hardness。
4. 本 note 不证明 \(P\ne NP\)，也不证明 simultaneous coordinate-robust dPCP 的
   一般 impossibility；它只把 C411 留下的 seed-after-conditioning 分支显式化。

## 证据边界

* C411：距离分离 family 的 Fano + residual-correlation identity；
* C418：条件独立 seed 的 bounded-fanout 特例；
* 引理 419.1：条件 KL data processing、子集熵子加性与 chain rule。
