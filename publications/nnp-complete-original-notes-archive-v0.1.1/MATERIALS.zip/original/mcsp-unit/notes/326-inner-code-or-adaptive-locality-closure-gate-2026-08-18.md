> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Inner-code cost or adaptive-locality Closure Gate (2026-08-18)

## Theorem

Let
\[
  \Pi_K:\{0,1\}^{K}\longrightarrow\Sigma_K^{P_K},
  \qquad A_K:=|\Sigma_K|\ge2,
\]
be a common proof map. For every target-dependent global package, assume that
all coordinates and both claims use the same proof address space, with adaptive
depth at most \(r_K\). Assume the full-ROC hypotheses of the standard
distributional mixture interface: after replacing the target-dependent package
law by one target-independent marginal law on a subfamily of density at least
\(1/2\), every coordinate has correct-claim probability at least \(2/3\) and
every wrong claim has probability at most \(1/3\) on every
\(\rho P_K\)-near proof, for a fixed \(\rho>0\).

Suppose each proof symbol has a binary inner encoding
\[
  E_K:\Sigma_K\to\{0,1\}^{\ell_K}
\]
of relative distance at least \(\delta_{\rm in}>0\), with unique decoding from
fewer than \(\delta_{\rm in}\ell_K/2\) errors. No assumption
\(\ell_K=O(\log A_K)\) is made. Let \(d_K\) be the size of a shattered
coordinate set supplied by the density-\(1/2\) target subfamily, so
\(d_K=\Omega(K)\).

Fix \(c_0\ge0\). On every infinite subsequence on which the binary expansion
\[
  \widehat N_K:=d_K+\ell_KP_K
  \le d_K\bigl(\log(d_K+2)\bigr)^{c_0},
\tag{326.1}
\]
one has
\[
  \bigl(1+\ell_Kr_K\bigr)
  \log\!\bigl(3+\ell_Kr_K\bigr)
  \ge \eta\,(\log K)^{1/3},
\tag{326.2}
\]
for a constant \(\eta>0\) depending only on
\(\rho,\delta_{\rm in},c_0\) and the fixed ROC gap. Consequently, a
full-ROC package cannot simultaneously keep the binary expansion
near-linear and have
\[
  (1+\ell_Kr_K)\log(3+\ell_Kr_K)
  =o\!\bigl((\log K)^{1/3}\bigr).
\]
If (326.1) fails for every sufficiently large \(K\), the inner-code expansion
itself is the explicit proof-length escape.

## Proof

The mutual-information mixture argument and Markov's inequality leave a target
subfamily \(\mathcal F_K\subseteq\{0,1\}^K\) of density at least \(1/2\) on
which the same marginal package has the displayed \(2/3\)--\(1/3\) full-ROC
guarantee. Sauer--Shelah gives a shattered coordinate set \(J_K\) of size
\(d_K=\Omega(K)\). Choose one representative \(m_u\in\mathcal F_K\) for
each \(u\in\{0,1\}^{J_K}\), and restrict the proof map to these representatives.

If two representatives whose restrictions differ at a coordinate had proof
words at distance at most \(\rho P_K\), the common marginal package would
accept both the correct claim with probability at least \(2/3\) and the wrong
claim with probability at most \(1/3\) on the same proof. Hence the restricted
proof words are pairwise at distance \(>\rho P_K\).

Define the binary code
\[
  \widehat\Pi_K(u)
   :=u\ \Vert\
     E_K\!\left(\Pi_K(m_u)_1\right)\Vert\cdots\Vert
     E_K\!\left(\Pi_K(m_u)_{P_K}\right).
\]
Its length is \(\widehat N_K=d_K+\ell_KP_K\). The
\(A_K\)-ary Singleton bound applied to the restricted proof family gives
\[
 d_K\le\bigl((1-\rho)P_K+1\bigr)\log_2 A_K
 \le\bigl((1-\rho)P_K+1\bigr)\ell_K.
\tag{326.3}
\]
Therefore \(\ell_KP_K/\widehat N_K\) is bounded below by a positive constant
for all sufficiently large \(K\). Since proof distance is \(>\rho P_K\)
and each inner block has distance at least \(\delta_{\rm in}\ell_K\), the
binary code has a fixed positive relative distance
\[
  \widehat\rho
   \ge
   \frac{\delta_{\rm in}\rho\,\ell_KP_K}
        {d_K+\ell_KP_K}
   =\Omega_{\rho,\delta_{\rm in}}(1).
\tag{326.4}
\]

On a received binary word within a sufficiently small constant fraction of
\(\widehat\Pi_K(u)\), uniquely decode every queried inner block. The number of
bad inner blocks is at most \(2e/(\delta_{\rm in}\ell_K)\), so choosing the
binary radius according to (326.4) leaves a decoded proof within
\(\rho P_K\) of the target proof. Read the inline bit and run the common
package filter on the decoded proof symbols. This gives a binary adaptive
relaxed local decoder with constant radius, correct probability at least
\(2/3\), wrong-output probability at most \(1/3\), and query count
\[
  R_K\le 1+\ell_Kr_K.
\tag{326.5}
\]
The inline coordinate supplies both output values because \(J_K\) is shattered.

Apply the source-audited variable-query relaxed-DGL theorem to this binary
RLDC. In the window \(Q_K^3=o(\log\widehat N_K)\), its normalized query
parameter satisfies
\[
  Q_K\le C_1R_K\log(R_K+2),
\]
and the DGL sample-counting bound contradicts (326.1). Hence, on the
subsequence satisfying (326.1),
\[
  Q_K^3\ge c_1\log\widehat N_K
  \ge c_1\log d_K
  =\Omega(\log K)
\]
after decreasing the constant and absorbing the finite cutoff. Combining
this with the preceding upper bound on \(Q_K\) proves (326.2).
\(\square\)

## Boundary

The theorem is a coding/closure statement, not an unconditional dPCP
impossibility or a \(P\ne NP\) theorem. Its full-ROC and common-package
quantifiers are essential; ordinary average/list soundness does not provide
the target-independent marginal package used in the proof. The result does
not require an explicit rate-optimal inner code: any available binary inner
encoding is charged through its actual block length \(\ell_K\). Thus the
only remaining large-alphabet escape is to pay the corresponding binary
expansion length, or to leave the common-proof/full-ROC interface.

## Nonadaptive specialization: the sharper \(\log K/\log\log K\) gate

There is a strictly stronger branch when every package verifier is nonadaptive in
its proof-symbol queries. Assume, in addition to the theorem above, that for
every package, coordinate, and claim, the set of queried proof symbols is fixed
before any queried symbol is read (it may still depend on the coordinate, claim,
package, and private random tape). The inner decoder reads all \(\ell_K\) binary
coordinates of each queried symbol. Put

\[
  R_K:=1+\ell_K r_K.
\tag{326.6}
\]

On every infinite subsequence satisfying (326.1), one then has the sharper
necessary condition

\[
  R_K=\Omega\!\left(\frac{\log K}{\log\log K}\right).
\tag{326.7}
\]

Indeed, the binary code and its constant relative distance were already
constructed in the proof of (326.1)--(326.2). Nonadaptivity of the symbol query
sets means that the binary decoder is a nonadaptive \((R_K,\delta_*,2/3)\)-RLDC:
no decision-tree expansion and no variable-query DGL normalization is needed.
Apply the arbitrary-finite-alphabet GGS inequality with alphabet two, message
length \(d_K=\Theta(K)\), and block length
\(\widehat N_K\le d_K\operatorname{polylog}d_K\). The radius condition is
valid in the contradiction regime \(R_K\le\eta\log d_K/\log\log d_K\), since

\[
  \widehat N_K^{-\sigma/(2R_K)}
  \le d_K^{-\sigma/(2R_K)}
  \le (\log d_K)^{-\sigma/(2\eta)}
  <\delta_*
\]

for all sufficiently large \(K\). Note 242's quantitative GGS calculation,
with \(k=d_K\), then rules out this contradiction regime and gives (326.7).

This is not an adaptive-to-nonadaptive decision-tree claim: it uses the additional
nonadaptivity hypothesis exactly once, to keep the query count at
\(1+\ell_Kr_K\). Thus the full-ROC dichotomy has two distinct locality
thresholds:

* arbitrary adaptive package verifiers: (326.2), the source-audited
  \((\log K)^{1/3}\) DGL gate;
* nonadaptive package verifiers: (326.7), the sharper GGS
  \(\log K/\log\log K\) gate.

The inner-code expansion alternative and all full-ROC/common-package quantifiers
remain unchanged.

## Sources

* [Full-ROC growing-alphabet adaptive-RLDC Closure Gate](305-full-ROC-growing-alphabet-adaptive-rldc-gate-2026-08-17.md).
* [Variable-query relaxed-DGL theorem](255-variable-query-relaxed-dgl-theorem-2026-08-17.md).
* [Growing-query threshold for near-linear closure](242-growing-query-threshold-for-near-linear-closure-2026-08-17.md).
