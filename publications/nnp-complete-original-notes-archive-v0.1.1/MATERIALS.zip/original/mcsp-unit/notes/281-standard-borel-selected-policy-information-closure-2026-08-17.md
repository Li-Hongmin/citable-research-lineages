> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Standard-Borel selected-policy information closure (2026-08-17)

## Contribution

The finite-support version of the selected-policy argument is not the real
boundary. The same fiber/VC mechanism works for an arbitrary standard-Borel
policy object, including an unbounded Merlin strategy or a continuously
indexed target-dependent address schedule, provided the robustness guarantee is
supportwise for the *same* policy value.

Thus an unbounded strategy can evade the RLDC reduction only by carrying nearly
all target information, or by allowing a policy value to be good for some
posterior targets and bad for others. The latter is exactly the
coordinatewise/phantom-witness quantifier gap.

## Theorem

Let
\[
 \Pi:\{0,1\}^{K}\longrightarrow\Sigma^{P}
\]
be a common proof map, with a fixed positive radius \(\rho\). Let
\((\mathcal S,\mathcal B)\) be a standard Borel space of policy objects. For
each \(s\in\mathcal S\), write
\[
 \tau_s=(\tau_{s,1},\ldots,\tau_{s,K})
\]
for the policies used at all coordinates and claims. Let \(M\) be uniform on
\(\{0,1\}^{K}\), and let \(S\mid M=m\) have an arbitrary conditional law
\(\mu_m\) on \(\mathcal S\). A regular conditional distribution
\(p_s(m)=\Pr[M=m\mid S=s]\) exists.

Assume the following supportwise condition: for almost every \(s\), every
\(m\) with \(p_s(m)>0\), every coordinate \(i\), and every proof word
\(z\) with \(d_H(z,\Pi(m))\le\rho P\),
\[
 \Pr[V^{\tau_{s,i}}_{i,m_i}(\Pi(m))=1]\ge\alpha,
 \qquad
 \Pr[V^{\tau_{s,i}}_{i,1-m_i}(z)=1]\le\beta,
 \tag{281.1}
\]
where \(\alpha>\beta\). The policy object may be infinite or computationally
unbounded; only the displayed common-proof and supportwise semantics are used.

Put \(I=I(M;S)\) in bits. For every \(\varepsilon>0\), there is a policy
value \(s_\star\) satisfying (281.1) on a target fiber
\[
 F_{s_\star}:=\{m:p_{s_\star}(m)>0\}
\]
with
\[
 |F_{s_\star}|\ge 2^{K-I-\varepsilon}.
 \tag{281.2}
\]
Consequently, if \(I\le\gamma K\) for a fixed \(\gamma<1\), then the fiber has
a shattered coordinate set \(J\) of size
\[
 |J|\ge(\theta_\gamma-o(1))K,
 \qquad H_2(\theta_\gamma)=1-\gamma.
 \tag{281.3}
\]
On \(J\), the single policy vector \(\tau_{s_\star}\) gives a positive-radius
RLDC with locality \(O(q(\alpha-\beta)^{-2})\) for nonadaptive \(q\)-query
branches; the adaptive version uses the corresponding decision-tree or
variable-query parameter. Therefore every applicable RLDC lower bound applies
to the original proof length \(P\).

In particular, a near-linear common-proof construction in an RLDC lower-bound
window must satisfy
\[
 I(M;S)\ge K-o(K),
 \tag{281.4}
\]
unless it violates supportwise robustness or the common proof/address model.

## Proof

For the finite-valued random variable \(M\),
\[
 H(M\mid S)=K-I(M;S)
 =\mathbb E_{s}\bigl[H(M\mid S=s)\bigr].
 \tag{281.5}
\]
Hence, for every \(\varepsilon>0\), the set of \(s\) for which
\(H(M\mid S=s)\ge K-I-\varepsilon\) has positive measure (otherwise the
expectation would be smaller). Intersect it with the full-measure set on which
the supportwise hypothesis holds, and choose \(s_\star\) there. Since
conditional entropy is at most the logarithm of conditional support size,
\[
 \log_2|F_{s_\star}|
 \ge H(M\mid S=s_\star)
 \ge K-I-\varepsilon,
\]
which proves (281.2).

Apply Sauer--Shelah to \(F_{s_\star}\). Equation (281.2) yields (281.3).
For every shattered coordinate \(i\), choose one representative target for each
pattern on \(J\). All representatives lie in the same fiber, so they use the
same policy \(\tau_{s_\star,i}\). Correct and wrong branches have the common gap
\(\alpha-\beta\) on the same radius-\(\rho\) neighborhood. Independent
threshold amplification (or the relevant adaptive amplification) and message
inlining therefore give the claimed RLDC. The policy value \(s_\star\) is
hardwired into the existential decoder; no finite description of \(s_\star\) is
needed for a coding lower bound. \(\square\)

## Exact boundary

The theorem does **not** say that ordinary distributional/list soundness is
supportwise. If a policy \(s\) can be good for \(m\) on one coordinate and for
\(m'\) on another, the posterior support cannot be used as a common fiber; this
is the phantom-witness obstruction. Likewise, a merely averaged defect is
covered by the global-package theorem only after taking the worst coordinate
and nearby proof before averaging.

The result is information-theoretic. If the final application requires a
uniform decoder rather than the existential RLDC lower bound, a separate
description or sampler bound for \(s_\star\) is necessary. That algorithmic
requirement is additional; it is not needed for the coding obstruction itself.

## Relation to the RW Closure Gate

This theorem closes the “unbounded Merlin strategy” reading of the model-exit
clause whenever the strategy is one common policy vector and is supportwise
robust. The only remaining ways to avoid the RLDC conclusion are:

1. \(I(M;S)=K-o(K)\), i.e. the strategy/address channel carries essentially the
   full target;
2. the proof/address space changes with the target or coordinate; or
3. robustness is only coordinatewise/average/list quantified, so the posterior
   support is not a common robust fiber.

These are semantic alternatives, not hidden finite-support assumptions.
