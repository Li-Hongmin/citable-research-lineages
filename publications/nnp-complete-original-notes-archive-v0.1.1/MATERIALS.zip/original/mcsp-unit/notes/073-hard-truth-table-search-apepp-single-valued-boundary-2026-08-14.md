> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 高复杂度 truth-table 的 APEPP 完备性、canonical 单值化与低深度边界（2026-08-14）

## 结论

令 \(N=2^n\)，并对 [note 070](070-ops-candidate-formula-oracle-refuter-2026-08-14.md)
中的固定 \(0<\alpha<2\) 定义

\[
\mathsf{HardTT}_t(1^N)
=\{z\in\{0,1\}^N:\operatorname{CC}_n(z)>t(N)\},
\qquad
t(N)=\left\lfloor\frac{N^{\alpha/2}}{K\log_2N}\right\rfloor .
\tag{1}
\]

为把二次幂子序列写成标准 total search problem，以下在非二次幂输入及有限多个过小长度上作
平凡扩展，规定固定串 \(0^N\) 为合法输出；所有 hard-truth-table 陈述只针对 \(N=2^n\) 的
充分大长度。若不作这个扩展，下文的“完备”应读成 promise-preserving \(P^{NP}\) reductions
下的完备。

这个 relation 有四个必须分开的复杂度结论。

1. 均匀随机采样再用 NP oracle 排除 size-\(t\) truth tables，给出一个多值的
   \(\mathrm{SearchZPP}^{NP}\) solver。这个初等 sampler 本身不是 single-valued。
2. 对每个固定 \(0<\alpha<2\)，式 (1) 在 \(P^{NP}\) reductions 下是
   APEPP-complete。这里用到了 \(t(N)>N^\varepsilon\) 对某个固定
   \(\varepsilon>0\) 最终成立；分类不是 deterministic \(P^{NP}\) 算法。
3. 多值 sampler 并不代表 single-valuedness 未知。Li 的 all-length、无 advice
   canonical AVOID 定理给出 single-valued \(\mathrm{FS}_2^P\) 和
   single-valued \(\mathrm{FZPP}^{NP}\) solver。与固定 truth-table decoder 复合后，
   存在由 \(N\) 唯一决定的 \(h_N\in\mathsf{HardTT}_t(1^N)\)，并由此定义固定语言

   \[
   L(x)=h_{2^{|x|}}[x]\in S_2E\subseteq ZPE^{NP},
   \qquad
   \operatorname{CC}(L_n)>t(2^n)
   \quad\text{a.e.}
   \tag{2}
   \]

4. 已解决的是 canonicality，不是低深度 uniformity。现有 canonical solver 属于
   \(\mathrm{FS}_2^P\)／adaptive single-valued \(\mathrm{FZPP}^{NP}\)，不是 CJSW 所需的
   deterministic polylogtime-uniform \(\mathrm{AC}^0[\mathrm{qpoly}]\) generator；
   它也不保证对任意候选 \(F\) 产生 \(F(y)=F(z)\) 的 easy--hard pair。

因此 [note 071](071-unary-oracle-composition-and-transfer-boundary-2026-08-14.md)
中“普通随机 completion 不定义固定 truth table”的判断只适用于那个 sampler 本身，不能再写成
“现有理论不能选择固定 hard family”。对 constant-one 候选，固定 hard family 已知；
剩余障碍首先是生成器的计算模型。

## 初等多值 \(\mathrm{SearchZPP}^{NP}\) sampler

固定有限 fan-in-two basis。存在常数 \(A\) 使

\[
|\{z:\operatorname{CC}_n(z)\le t(N)\}|
\le 2^{A t(N)\log_2(t(N)+n+2)}
=2^{o(N)}.
\tag{3}
\]

在输入 \(1^N\) 上均匀采样 \(z\in\{0,1\}^N\)，以一个 NP query 判定
\(\operatorname{CC}_n(z)\le t(N)\)。YES 时重采；NO 时输出 \(z\)。一次成功概率为
\(1-2^{-N+o(N)}\)，所以期望轮数为 \(1+o(1)\)，每个成功输出都严格位于
\(\mathsf{HardTT}_t(1^N)\)。

若期望运行时间上界为 \(p(N)\)，在 \(3p(N)\) 步截断并把长运行改为 \(\bot\)，得到
worst-case polynomial-time 的零错误 solver：

\[
\Pr[B(1^N)\in\mathsf{HardTT}_t(1^N)]\ge\frac23,
\qquad
\Pr[B(1^N)\notin\mathsf{HardTT}_t(1^N)\cup\{\bot\}]=0.
\tag{4}
\]

这个具体 sampler 是多值的。一个极小反例是：随机取 \(u\)，用 NP oracle 检查
\(u,\neg u\) 都 hard，否则重采；成功后再公平随机输出 \(u\) 或 \(\neg u\)。所有成功输出都
hard，但每个地址 \(x\) 都满足

\[
\Pr[Z_x=0]=\Pr[Z_x=1]=\frac12.
\tag{5}
\]

所以重新运行这个 sampler 后读取第 \(x\) 位既不定义 ZPP decision procedure，也没有 BPP
probability gap。固定一条成功 random tape 只给出相对真实地址长度 \(n=\log N\) 的
exponential advice。下文的 canonical AVOID 定理使用的是另一种算法，因而不与这个反例冲突。

## APEPP / Range Avoidance 分类

APEPP 的标准 complete problem Empty 输入一个 expanding circuit

\[
\Phi:\{0,1\}^r\longrightarrow\{0,1\}^m,\qquad m>r,
\]

并要求输出 \(\operatorname{Range}(\Phi)\) 外的 \(m\)-bit string。

### Membership

size 至多 \(t(N)\) 的 \(n\)-input circuits 可用

\[
\ell(N)=O(t(N)\log(t(N)+n+2))=o(N)
\tag{6}
\]

bits 编码。固定一个 uniform decoder \(\Phi_{N,t}\)：它读取 circuit description，
在全部 \(N\) 个地址上评价该 circuit，并输出 truth table；无效 description 映到固定默认表。
忽略 padding bits，把输入补到 \(N-1\) 位。于是

\[
\Phi_{N,t}:\{0,1\}^{N-1}\longrightarrow\{0,1\}^N
\tag{7}
\]

是可由 \(1^N\) 在 \(\operatorname{poly}(N)\) 时间构造的 Empty instance，其 range
包含所有 size-\(t(N)\) truth tables。任何 range 外输出都属于
\(\mathsf{HardTT}_t(1^N)\)，故 \(\mathsf{HardTT}_t\in\mathrm{APEPP}\)。

### Hardness 与 power-of-two 长度

Korten Theorem 9 证明：对每个固定 \(0<\varepsilon<1\)，给定任意 \(1^m\) 并输出一张
circuit complexity \(>m^\varepsilon\) 的 \(m\)-bit table（\(\varepsilon\)-Hard），对
APEPP 在 \(P^{NP}\) reductions 下完备。这里采用 Korten 对非二次幂长度的约定：地址长度为
\(\lceil\log_2m\rceil\)，只要求前 \(m\) 个地址正确。

式 (1) 只列出 \(N=2^n\)，但这个子序列仍然 hard。固定

\[
0<\varepsilon<\delta<\alpha/2.
\tag{8}
\]

给定 Korten reduction 请求的任意长度 \(m\)，令

\[
Q=2^{\lceil\log_2m\rceil}<2m
\]

（若 \(m\) 已是二次幂则 \(Q=m\)）。在 \(Q\) 上调用式 (1) 的 solver，得到
\(\operatorname{CC}_Q(z)>t(Q)>Q^\delta\)。若 \(Q=m\)，直接输出 \(z\)；当 \(m<Q\) 时，
把 \(z\) 分成长度 \(m\) 的
prefix \(u\) 与 suffix，并把 suffix 以零补成另一个 \(m\)-bit string \(v\)。

若 \(u,v\) 都有 size \(m^\varepsilon\) circuits，则用一个 comparator、地址减法与 multiplexer
拼接二者，可得到 size

\[
2m^\varepsilon+O(\log m)<Q^\delta<t(Q)
\tag{9}
\]

的 circuit 计算 \(z\)，矛盾；最后一个不等式由 \(\delta<\alpha/2\) 对充分大 \(Q\) 成立。
因此 \(u,v\) 至少一个是合法的
\(\varepsilon\)-Hard 输出。以一个 NP query 判定
\(\operatorname{CC}_m(u)\le m^\varepsilon\)：NO 时输出 \(u\)，YES 时输出 \(v\)。
这把任意长度的 \(\varepsilon\)-Hard call 化为 power-of-two 的
\(\mathsf{HardTT}_t\) call，故 Korten reduction 可直接复合，得到 APEPP-hardness。

这个论证需要固定正指数。note 071 选取的一个方便的 CJSW-admissible MCSP threshold

\[
h(N)=2^{\sqrt{\log_2N}}=N^{o(1)}
\tag{10}
\]

对每个固定 \(\varepsilon>0\) 最终都小于 \(N^\varepsilon\)。所以 decoder 仍给出
\(\mathsf{HardTT}_h\in\mathrm{APEPP}\)，但 Korten fixed-\(\varepsilon\) Theorem 9 不证明
它 APEPP-hard；不能把 (1) 与 (10) 的完备性量词混写。

## canonical AVOID 给出的固定 hard family

Li Theorem 1.1 对每个 expanding circuit \(C\) 给出 all-input、无 advice 的
single-valued \(\mathrm{FS}_2^P\) AVOID solver。Theorem 1.5 结合
\(S_2^P\subseteq ZPP^{NP}\)，给出 single-valued \(\mathrm{FZPP}^{NP}\) 版本：
对每个 \(C\) 存在固定

\[
y_C\notin\operatorname{Range}(C)
\]

使算法以至少 \(2/3\) 概率输出 \(y_C\)，其余路径只输出 \(\bot\)。重复至成功是期望多项式时间、
零错误且 singleton-output 的 canonical 算法。

把它应用到固定 decoder (7)，得到由 \((N,t)\) 唯一决定的

\[
h_N:=y_{\Phi_{N,t}}\notin\operatorname{Range}(\Phi_{N,t}),
\qquad
\operatorname{CC}_n(h_N)>t(N).
\tag{11}
\]

decoder 的描述长度与 gate 数均为 \(\operatorname{poly}(N)\)，所以组合仍在
\(\operatorname{poly}(N)\) 时间内。给定 \(x\in\{0,1\}^n\)，完整运行该 canonical
过程并读取 \(h_{2^n}[x]\)，即得到式 (2)。Li 的更强 near-maximum 实例给出
\(\Omega(N/\log N)\) hardness；因此 OPS 的任意固定 \(\alpha<2\) threshold 以及
CJSW 的 \(N^{o(1)}\) threshold 在尺度和 canonicality 上都已经被覆盖。

这不 single-value 化 OPS candidate refuter。独立的 \(h_N\) 不保证对给定
\(F\) 有 \(F(h_N)=F(y)\)，也不 canonicalize 随机 restriction。只有在
\(F\equiv1\) 时，\(h_N\) 自动是反例。

## 去掉随机性的确定性边界

canonical randomized family 与 deterministic family 仍须分开。对任意阈值 \(q(n)\)，同一个
好长度集合（i.o. 或 a.e.）上有

\[
\begin{aligned}
&\exists R\in\mathrm{DTIME}(\operatorname{poly}(N)):
&&\operatorname{CC}_n(R(1^{2^n}))>q(n)\\
\Longleftrightarrow\quad
&\exists L\in E:
&&\operatorname{CC}_n(L_n)>q(n).
\end{aligned}
\tag{12}
\]

正向令 \(L(x)\) 为 \(R(1^{2^{|x|}})\) 的第 \(x\) 位；反向逐地址运行 \(L\) 并输出整张表。
同理，deterministic \(\mathrm{FP}^{NP}\) singleton 对应 \(E^{NP}\) address language。

Korten Theorem 10 进一步给出

\[
\mathrm{Empty}\in\mathrm{FP}^{NP}
\quad\Longleftrightarrow\quad
\exists L\in E^{NP}\text{ with a.e. circuit complexity }2^{\Omega(n)}.
\tag{13}
\]

对 OPS 的固定正指数阈值，APEPP-completeness 使 deterministic
\(\mathrm{FP}^{NP}\) 求解与 (13) 等价。Li 的 single-valued randomized solver 不蕴含这个
deterministic collapse。

## 与 CJSW 接口的最终边界

现有结果已经给出：

\[
\mathsf{HardTT}_t\in
\text{single-valued }\mathrm{FS}_2^P
\cap
\text{single-valued }\mathrm{FZPP}^{NP},
\tag{14}
\]

并对 OPS threshold 给出 APEPP-completeness。但 CJSW Proposition 4.3 要求的是
deterministic polylogtime-uniform \(\mathrm{AC}^0\)、quasipolynomial-size、显式总输出
quasipolynomial 的 unary singleton/list。若能把 (11) 编译到这个类，constant-one 候选已经
给出 CJSW list-refuter 并推出 \(P\ne NP\)。因此当前最先失配的是计算模型／oracle
adaptivity／低深度 uniformity，不是阈值、advice、全长度或 single-valuedness。

## 来源

- Oliver Korten, *The Hardest Explicit Construction*, FOCS 2021 /
  arXiv:2106.00875v3, Theorems 1, 9, 10。全文：
  ResearchLibrary/lib/korten2021hardest/korten2021hardest.pdf。
- Zeyong Li, *Symmetric Exponential Time Requires Near-Maximum Circuit Size:
  Simplified, Truly Uniform*, arXiv:2310.17762v2 (2024), Theorems 1.1, 1.5，
  Corollary 4.8。该工作已并入 Lijie Chen, Shuichi Hirahara, Zeyong Li, and Hanlin Ren,
  *Symmetric Exponential Time Requires Near-Maximum Circuit Size*, Journal of the ACM
  73(1), 2026, DOI: 10.1145/3778166。预印本全文：
  ResearchLibrary/lib/unknownarxiv2310a/unknownarxiv2310a.pdf。
- [note 071](071-unary-oracle-composition-and-transfer-boundary-2026-08-14.md)：
  OPS unary composition、CJSW 与 Student--Teacher 接口。
- [note 072](072-gapmcsp-affine-disperser-gate-elimination-boundary-2026-08-14.md)：
  CDJ affine-disperser 路线的 promise-specific 边界。
