> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Atserias--Müller 的 uniform MCSP magnification 接口（2026-08-14）

## 结论

Atserias--Müller, *Simple general magnification of circuit lower bounds*,
arXiv:2503.24061v2（2025-06-21），没有给出当前项目到

\[
P\ne NP
\tag{1}
\]

的直接捷径。它给出了一个新的、精确而独立的 approximate-MCSP 阈值；该阈值与已知下界只在
指数的下方相接，且其 promise 与模型均不能接入当前的 exact
\(\operatorname{GapMCSP}\)/Formula--XOR 前沿。

## 原始定理

以下记号中 \(n=2^\ell\)，而 \(n^{-\varepsilon}\)-MCSP 的 NO 端要求与每个
\(\sigma(\ell)\)-size circuit truth table 的 Hamming 距离至少 \(n^{1-\varepsilon}\)。

对任意 \(2^{n^{o(1)}}\)-sparse \(Q\in NP\)，其 Theorem 9 给出

\[
\begin{aligned}
n^{-\varepsilon}\text{-}Q
  &\notin\mathrm{FML}[n^{1+2\varepsilon+o(1)}]
   &&\Longrightarrow
   \forall c\ \ NP\not\subseteq\mathrm{FML}[n^c],\\
n^{-\varepsilon}\text{-}Q
  &\notin\mathrm{PFML}[n^{2\varepsilon+o(1)}]
   &&\Longrightarrow
   \forall c\ \ NP\not\subseteq\mathrm{FML}[n^c].
\end{aligned}
\tag{2}
\]

其 Theorem 10 的无条件端为

\[
n^{-\varepsilon}\text{-}\mathrm{MCSP}[2^{\sqrt\ell}]
\notin\mathrm{PFML}[n^{2\varepsilon-\delta}]
\qquad(0<\varepsilon,\delta\le1).
\tag{3}
\]

Theorem 27 的 uniform 版本是：给定 \(\delta,\varepsilon>0\)，存在
\(\gamma>0\)，使得

\[
\sigma(\ell)\le2^{\gamma\ell},\quad
n^{-\varepsilon}\text{-}\mathrm{MCSP}[\sigma]
\notin\mathrm{P\text{-}uniform\text{-}SIZE}[n^{1+\varepsilon+\delta}]
\Longrightarrow P\ne NP^{\oplus P}.
\tag{4}
\]

其 Theorem 11 是 \(\sigma(\ell)\le2^{o(\ell)}\) 和
\(n^{1+\varepsilon+o(1)}\) 的相应渐近表述。上述定理已由本地 v2 全文逐页核对；Theorem 25
同样只给出 \(\oplus P\not\subseteq NC^1\)，不改变下面的判断。

## 三个不可消去的失配

\[
\begin{array}{c|c|c}
&\text{Atserias--Müller} & \text{本单元的承重目标}\\ \hline
\text{promise}&n^{-\varepsilon}\text{-approximate MCSP}
&\operatorname{GapMCSP}[s,t]\\
\text{模型}&\mathrm{PFML}\ \text{或 P-uniform-SIZE}
&\mathrm{Formula}\circ\mathrm{XOR}\\
\text{指数}&2\varepsilon-\delta
&2\varepsilon+o(1)\ \text{或}\ 1+\varepsilon+o(1)
\end{array}
\tag{5}
\]

唯一对齐的是

\[
2^{\sqrt\ell}\le2^{o(\ell)}.
\tag{6}
\]

但 (3) 是较小类的下界：

\[
\mathrm{PFML}[n^{2\varepsilon-\delta}]
\subseteq
\mathrm{PFML}[n^{2\varepsilon+o(1)}]
\quad\text{在所需指数尺度上，}
\tag{7}
\]

所以 (3) 不能触发 (2)。令阈值参数改为 \(\varepsilon'\) 也无济于事：向
\(\varepsilon'>\varepsilon\) 改会使所需指数更大；向
\(\varepsilon'<\varepsilon\) 改则把 approximate promise 变为更小的 NO 端，(3) 的下界
不能单调迁移过去。更没有已知归约把该 approximate promise 无损变为当前 exact
GapMCSP promise，或把 ordinary probabilistic formulas 提升为 Formula--XOR / general
P-uniform circuits。

### 当前 Gap promise 不是该 approximate promise 的 restriction

这个失配甚至在恒等嵌入下有明确反例。令当前 Frontier B 参数为

\[
N=2^\ell,\qquad
a=2^{\ell^{1/3}},\qquad
b=2^{\ell^{2/3}},
\tag{8}
\]

并记 \(E_a\) 为 \(\ell\)-输入、circuit size 至多 \(a\) 的 truth tables。对任意固定的
\(0<\varepsilon<1\)，充分大 \(\ell\) 时存在一个 truth table \(y\)，使

\[
\operatorname{CC}(y)>b,
\qquad
d_H(y,E_a)<N^{1-\varepsilon}.
\tag{9}
\]

确实，重量恰为 \(b\) 的表有

\[
\binom Nb
\ge
2^{b(\ell-\ell^{2/3}-O(1))}
\tag{10}
\]

个；而 size 至多 \(b\) 的 \(\ell\)-输入 fan-in-2 circuits 至多

\[
2^{O(b\log(b+\ell))}
=2^{O(b\ell^{2/3})}.
\tag{11}
\]

故 (10) 最终严格大于 (11)，可选重量 \(b\) 而 circuit complexity 大于 \(b\) 的 \(y\)。
但零表属于 \(E_a\)，且

\[
d_H(y,0)=b=2^{\ell^{2/3}}=o\!\left(N^{1-\varepsilon}\right).
\tag{12}
\]

于是 \(y\) 是 \(\operatorname{GapMCSP}[a,b]\) 的 NO instance，却不是
\(N^{-\varepsilon}\)-approximate-MCSP 的 NO instance。特别地，不能把当前 Gap 下界
作为 (2)--(4) 的 approximate 前提直接代入。\(\varepsilon=1\) 时 approximate 问题退化为
exact MCSP，但仍留下 (7) 的指数、以及模型失配。

在 (4) 中，(3) 也不足够：它既不是 general P-uniform circuit 下界，且在
\(\varepsilon\le1\) 时其最好指数仍不超过目标的 \(1+\varepsilon\) 临界值；当
\(\varepsilon=1\) 时仍只从下方达到 \(2\)。

## 结论类也不等于 \(P\ne NP\)

式 (2) 的结论只排除 NP 的固定多项式 **formula** 上界；假设 \(P=NP\) 并不产生
\(P\subseteq\mathrm{FML}[n^c]\) 的任意固定指数上界。式 (4) 的结论也不能替代 (1)，因为

\[
NP\subseteq NP^{\oplus P},
\qquad
P\ne NP\Longrightarrow P\ne NP^{\oplus P},
\tag{13}
\]

而逆向没有由该定理给出：\(P=NP\) 仍不使 \(NP^{\oplus P}\) 自动坍缩到 \(P\)。

## 路线裁决

这篇此前遗漏的文献应加入历史图谱，但不替换 note
[000](000-cutover-2026-08-13.md) 的三前沿裁决，也不解除
note [012](012-direct-shortcut-literature-search-2026-08-13.md) 的 Formula--XOR 模型缺口。
它留下的独立阈值问题是

\[
n^{-\varepsilon}\text{-}\mathrm{MCSP}[2^{\sqrt\ell}]
\notin\mathrm{P\text{-}uniform\text{-}SIZE}[n^{1+\varepsilon+o(1)}],
\tag{14}
\]

其已知后果仅为 \(P\ne NP^{\oplus P}\)，而非 (1)。因此它不是当前 P versus NP 主线的
可接入桥；在未出现保持 promise 与模型的新归约前，不应将 (9) 当作主线替代目标。

## 来源

- Albert Atserias and Moritz Müller, *Simple general magnification of circuit lower bounds*,
  arXiv:2503.24061v2, 2025-06-21. 本地全文缓存于
  `ResearchLibrary/lib/muller2025simple/muller2025simple.pdf`，SHA-256
  `1850c5ef0960813f098e294fae792fad363101ce5433814c74d35542175cb9f6`。
