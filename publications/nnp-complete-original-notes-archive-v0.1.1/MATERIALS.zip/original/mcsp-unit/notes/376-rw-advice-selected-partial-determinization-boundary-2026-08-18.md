> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW advice-selected good lengths only give partial determinization (2026-08-18)

## 判定

Ren--Williams Theorem 4.3 的 smart-
\(\mathrm{FP}^{\mathrm{prMA}}/1\) 算法在每个长度用一位 advice 在两个分支
\(A_0,A_1\) 之间选择。\(A_0\) 的查询始终是 SAT 查询；\(A_1\) 的
\(\mathrm{prMA}\) 查询只在该长度确实落入 Theorem 4.3 所称的 failure/reconstruction
情形时保证 smart。因而在假设 \(P=NP\) 下，可以逐长度确定化**被 advice 选中且
确实为 good 的分支**，但不能由此推出整个算法在所有长度上成为一个统一的 \(P\)
算法。

这一区分会改变 Closure 的尺度判断：在 RW 当前 near-maximum forcing 窗口中，
逐长度确定化只给出 \(n^{O(1)}\)-大小的对象电路，而不是
\((\log n)^{O(1)}\)-大小的地址电路；\(\Omega(n/\log n)\) 的已发表硬度下界与前者
相容。因此不能把 “\(P=NP\) 消除 smart-prMA” 直接写成最终矛盾。

## 命题（good-length partial determinization）

设 \(\mathcal N_{\mathrm{good}}\) 是 Theorem 4.3 给出的无限长度集合。对每个
\(n\in\mathcal N_{\mathrm{good}}\)，令 advice 位 \(\alpha_n\in\{0,1\}\) 选择
正确输出 AVOID outsider 的分支，并记该输出为
\(y_n\in\{0,1\}^{2n}\)。假设：

1. \(A_0\) 只使用 SAT 查询，且其实际运行时间在输入长度 \(n\) 上为 \(n^{O(1)}\)；
2. 当 \(\alpha_n=1\) 时，Theorem 4.3 的 failure 条件成立，因此 \(A_1\) 在该长度
   发出的每个 \(\mathrm{prMA}\) 查询都满足其 promise；
3. 查询格式固定，随机带和 Merlin witness 长度均为查询描述长度的多项式。

则在 \(P=NP\) 下存在固定常数 \(c\)，使得对每个
\(n\in\mathcal N_{\mathrm{good}}\)，

\[
  \operatorname{CC}(y_n)\le n^c .
\tag{376.1}
\]

这里的结论只在 good 长度上成立；它不声称 \(A_1\) 在非 failure 长度上可被确定化。

### 证明

若 \(\alpha_n=0\)，则把 \(A_0\) 的 SAT oracle 替换为 \(P=NP\) 下的多项式时间
SAT 算法即可。Theorem 4.3 的源码审计表明，早期序列上 \(A_0\) 输出零串，稳定序列
上它模拟相应的 \(BF_i\)；两者在表示长度 \(n\) 上均为多项式时间过程。因此该分支
给出一个 \(n^{O(1)}\)-时间、从而 \(n^{O(1)}\)-大小的电路。

若 \(\alpha_n=1\)，则只需回答实际发出的 smart 查询。对固定格式的
\(\mathrm{prMA}\) 查询，先用标准概率放大把 YES/NO 间的常数 gap 降到
\(2^{-\operatorname{poly}(L)}\)，其中 \(L\) 是查询描述长度；经过放大，YES 条件
可写成

\[
  \exists C\;\forall \omega\; B(Q,C,\omega)=1,
\]

其中 \(C\) 是 Merlin 电路，\(\omega\) 是多项式长度的随机串，\(B\) 是多项式时间
谓词。这是一个固定层的 \(\Sigma_2^P\) 谓词。在 \(P=NP\) 假设下
\(PH=P\)，故该谓词可在 \(L^{O(1)}\) 时间内决定。由于 Theorem 4.3 在
\(\alpha_n=1\) 的 good 长度上保证所有实际查询都在 promise 内，逐次替换这些 oracle
答案即可把 \(A_1\) 变成 \(n^{O(1)}\)-时间过程。标准时间到电路转换得到 (376.1)。\(\square\)

## 这个命题没有给出的东西

### 1. 不是一个全长度的统一 \(P\) 算法

\(A_1\) 在非 failure 长度上可以发出 off-promise 查询；smartness 只对
\(\mathcal N_{\mathrm{good}}\) 中被选中的分支负责。另一方面，advice 序列
\((\alpha_n)\) 只由存在性证明给出，并没有一个已知的统一生成器。因此不能从
\(P=NP\) 推出整个 advice 算法在所有长度上属于 \(P\)，也不能把
\(A_0/A_1\) 的逐长度模拟自动改写成一个 uniform address evaluator。

### 2. 不与 RW 的 near-maximum 下界矛盾

Theorem 4.3 的硬 truth-table 子序列（Theorem 4.5 的 Korten reduction 所使用的输入）
在无限长度上给出的是

\[
  \operatorname{CC}(y_n)\ge c_0\,\frac{n}{\log(n+2)}
\]

型的下界；Korten reduction 后的 outsider 另有自己的输出长度参数。对这里的
truth-table 输出而言，(376.1) 只给出 \(n^c\) 上界。对固定 \(c\ge1\)，两者可以同时成立；
这正是 object-scale 与 address-scale 的差别。要从这条分支得到 \(P\ne NP\)，还需
新增至少一项：

* 在同一 good 长度集合上证明 \(\operatorname{CC}(y_n)>n^{\omega(1)}\)；或
* 给出一个真正的 \((\log n)^{O(1)}\)-地址 evaluator/PH surface；或
* 证明 solver-success / failure 两分支共同绑定到一个更强的 parent object，并在该
  关系上支付已有的 descriptor、cover、bottom 或 RLDC 成本。

## 对 Closure Theorem 的精确影响

该命题把“最终 Collapse”门拆成两个不能互换的前提：

1. **good-length determinization：** 在被选分支确实 smart 的长度上，\(P=NP\) 只
   提供表示长度尺度的电路；
2. **address-scale attachment：** 还必须把同一输出对象的地址映射压到
   \(\operatorname{poly}(\log n)\) 或最终输入尺度，或者把 forcing 下界提升到超过
   表示尺度。

因此，当前正攻不能再把 advice 选择、promise smartness 和 address compression
合并为一个口号。现有 C358 的 scale-complete audit 已关闭“near-maximum 自动排除
stable solver branch”的错误推理；本命题进一步把 advice/partial-promise 量词写成了
可直接核对的 source-level 边界。它不是 \(P\ne NP\) 证明，也不是一般 dPCP/RLDC
不可能性定理。

## 来源

* Ren--Williams, ECCC TR26-118 revision 1, Theorem 4.1--4.5；项目抽取版
  `units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md`,
  pp. 14--20。
* [C358](358-rw-scale-complete-closure-audit-2026-08-18.md)：stable object-scale
  与 address-scale 的五分审计。
* [C375](375-published-rw-recurrence-singleton-target-zero-entropy-2026-08-18.md)：
  published recurrence 的 singleton-target 量词边界。
