> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Affine 叶上的 star-label 激活容量（2026-08-13）

## 目的

Chukhin--Kulikov--Mihajlin 的第二势 ξ 对每条 star 边求和，并依靠“一个强分离叶至多激活一个标签”得到叶归一化。对 affine-parity 叶，这个归一化条件本身一般不成立：一个 affine 形式可以同时激活一颗 star 的很多边。

## 几何设置

取 row-star

\[
T=\{(x_0,y_i):1\le i\le d\}
\subseteq X\times Y,
\qquad d_i=x_0\oplus y_i\ne0.
\]

记 \(q_x=(x,1)\)、\(p_y=(y,1)\)，affine 叶由

\[
q_x\cdot z=0,
\qquad p_y\cdot z=1
\]

的行、列集合直积给出。对任意 \(r\in\mathbb F_2^N\)，取 \(z=(r,b)\) 且 \(b=r\cdot x_0\)。于是中心行 \(x_0\) 被保留，而

\[
(x_0,y_i)\in R_z
\iff p_{y_i}\cdot z=1
\iff r\cdot(y_i\oplus x_0)=1
\iff r\cdot d_i=1.
\tag{1}
\]

换言之，随着 \(r\) 变化，所有模式

\[
I_r=\{i:r\cdot d_i=1\}
\]

都是合法 affine 叶上的 star 命中模式（忽略额外的独立行/列 thinning；thinning 只会再乘同一因子，不改变容量结论）。

## 激活容量引理

给边赋非负权 \(w_i\ge0\)，设某个“逐标签”势在模式 \(I_r\) 上至少贡献

\[
\xi_r\ge\sum_{i:r\cdot d_i=1}w_i.
\tag{2}
\]

则存在 \(r\) 使

\[
\xi_r\ge\frac12\sum_{i=1}^dw_i.
\tag{3}
\]

**证明。** 对均匀 \(r\) 取期望。因 \(d_i\ne0\)，有

\[
\Pr_r[r\cdot d_i=1]=\frac12.
\]

故右端的期望为 \(\frac12\sum_iw_i\)，从而存在一个 \(r\) 达到该值。\(\square\)

## 叶归一化的直接后果

若一个 QA 状态要求每个 affine 叶满足 \(\xi_r\le1\)，并且含有上述逐标签下界 (2)，则

\[
\sum_{i=1}^d w_i\le2.
\tag{4}
\]

即使 star 的边数 \(d\to\infty\)，逐标签权重总和仍被常数 2 截断；不能像强 KW 叶那样让 ξ 在根处累积 \(d\) 个独立标签的贡献。

这个结论只用到了非零差向量和 affine 叶几何，不依赖 star 的线性独立性。若 \(d_i\) 线性独立，取 \(r\) 为对偶基全 1 向量甚至可一次激活全部 \(d\) 条边；一般情形至少有半数权重可被一个 \(r\) 同时激活。

## 研究边界

因此，把 Chukhin ξ 直接替换为“每个 collision/star 边一个 projection-KW 复杂度并求和”的 affine 版本会在叶归一化处失败，除非引入额外的全局编码/相消机制，使边项不再满足 (2) 的逐标签下界。可行的新状态必须利用多个 star 的联合关系、而不是单 star 的边标签求和。

