> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 单调子模 QA 状态的普适平均 no-go（2026-08-13）

这是 rank、coverage、entropy 等已知状态的统一封口，不依赖 affine 叶之间的相关性。

## 定理

令 \(F:2^C\to\mathbb R_{\ge0}\) 满足

\[
F(\varnothing)=0,\qquad
F\text{ 单调},\qquad
F(A)+F(B)\ge F(A\cup B)+F(A\cap B).
\]

令 \(\mathscr D\) 是任意叶分布，只要求每个 cell \(c\in C\) 的包含概率都相同：

\[
\Pr_{R\sim\mathscr D}[c\in R]=q.
\tag{1}
\]

则

\[
\boxed{\mathbb E_{R\sim\mathscr D}F(R)\ge qF(C).}
\tag{2}
\]

## 证明

固定 \(C\) 的一个顺序 \(c_1,\ldots,c_m\)，记前缀 \(P_i=\{c_1,\ldots,c_i\}\)，并定义边际权重

\[
w_{c_i}=F(P_i)-F(P_{i-1})\ge0.
\]

望远镜求和给出 \(\sum_{c\in C}w_c=F(C)\)。对任意 \(R\subseteq C\)，把其元素按同一顺序排列。由子模性的 diminishing returns，

\[
F(R\cap P_i)-F(R\cap P_{i-1})
\ge F(P_i)-F(P_{i-1})=w_{c_i}
\]

在 \(c_i\in R\) 时成立；求和得到模块下界

\[
F(R)\ge\sum_{c\in R}w_c.
\tag{3}
\]

对 (3) 取期望并使用 (1)：

\[
\mathbb E F(R)
\ge\sum_c w_c\Pr[c\in R]
=q\sum_cw_c
=qF(C).
\]

证毕。

## QA 后果

令

\[
K_F(R)=F(R)-\frac{F(C)}{|C|}|R|.
\]

子模性在不交二分上给出 \(F(V\cup W)\le F(V)+F(W)\)，故 \(K_F\) 是 QA/root-zero；但由 (2)

\[
\mathbb E K_F(R)\ge0.
\]

因此在均匀 cell-inclusion 的任何 affine 叶分布下，**所有单调子模状态**都不能提供负平均补偿。该结论同时覆盖：

- matroid rank、线性秩；
- coverage/feature-union；
- 凹命中数、熵型状态；
- 任意已知单调子模嵌入或 Lovász-extension 状态。

要逃逸，状态必须至少是**非子模**的全局语义对象；note051 的最小 cover number 正是这种非-XOS、非子模接口。

