> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Local-constraint regularity 不推出 solution automaticity（2026-08-19）

## 本轮改变的判断

C453 的 \(\widehat D\)-evaluator 之所以能在 address scale 运行，是因为它对
offset-regular **constraint relation** 做加权求和。不能由此推断唯一 satisfying
assignment \(q|_{H^m}\) 也有小 weighted-automaton 表示。一个固定确定性 local machine
已能在 regular unary source 上输出 equality matrix；其 tableau 约束、边界和 output
block 全部 regular，且 accepting tableau 唯一，但输出函数的 Hankel rank 强制
\(2^{\Omega(m_{\rm addr})}\) states。

因此 C458 留下的 tableau-specific structure 不能只写成“local constraints regular”。
若 actual C456 assignment 真有 \(\operatorname{poly}(m_{\rm addr})\)-state 表示，那已经是一项新的
source-specific automaticity/parallelization theorem，并会经 C459 触发 forcing
矛盾。

## 设置

域 \(F\) 上的 \(s\)-state weighted automaton 计算长度-\(r\) 字符串函数
\[
  f(z_1\cdots z_r)
  =
  \alpha^\top A_{z_1}\cdots A_{z_r}\beta,
\tag{460.1}
\]
其中 \(A_a\in F^{s\times s}\)。在任意切割 \(z=xy\) 处，其 Hankel matrix
\[
  H_f(x,y):=f(xy)
\]
秩至多 \(s\)，因为
\[
  H_f(x,y)
  =
  \bigl(\alpha^\top A_x\bigr)\bigl(A_y\beta\bigr).
\tag{460.2}
\]

## 定理 460.1（unique regular tableau with exponential solution rank）

存在一个固定确定性 machine \(M_{\rm eq}\)，使对无限多个 regular unary sources
\(1^n\)，其标准 hist-first、cell-time、track-major accepting tableau 满足：

1. local transition、initialization、boundary 和 output-check constraints 都属于常数个
   fixed-offset families，边界由常状态 digit automata 识别；
2. accepting tableau 唯一；
3. 若完整 assignment table 有 \(s\)-state weighted-automaton 表示，且连续 output
   block 通过 \(\operatorname{poly}(m_{\rm addr})\)-state regular transducer 从逻辑 output address
   取得，则
   \[
     s=2^{\Omega(m_{\rm addr})},
   \tag{460.3}
   \]
   其中 \(m_{\rm addr}\) 是 tableau address length。

特别地，fixed local rule、regular source 与 unique deterministic solution 一般不推出
\(\operatorname{poly}(m_{\rm addr})\)-state solution automaticity。

### 证明

取 \(n=2^{2k}\)。固定 machine \(M_{\rm eq}\) 在输入 \(1^n\) 上按
\((x,y)\in\{0,1\}^k\times\{0,1\}^k\) 的字典序输出
\[
  B_k(x,y):=\mathbf 1[x=y].
\tag{460.4}
\]
machine 维护 \(2k\)-bit output address，比较其前后两半，再输出一位；总时间
\(n\operatorname{polylog}n\)，machine description 固定。其标准 deterministic tableau
使用固定局部转移规则，unary source 和边界 regular，并且每个 cell-time value 唯一，
故 accepting tableau 唯一。tableau 总规模为 \(n\operatorname{polylog}n\) 的固定多项式，
所以
\[
  m_{\rm addr}=\Theta(\log n)=\Theta(k).
\tag{460.5}
\]

连续 output block 的 physical address 是 \((x,y)\) 的 regular affine/offset 编码。
若完整 assignment 有 \(s\)-state weighted representation，与该地址 transducer 复合，
便得到至多 \(\operatorname{poly}(m_{\rm addr})s\) states 的 weighted automaton 计算 \(B_k\)。
在读完 \(x\) 后切割，其 Hankel matrix 为
\[
  \bigl(B_k(x,y)\bigr)_{x,y\in\{0,1\}^k}
  =
  I_{2^k}.
\tag{460.6}
\]
任意域上该矩阵秩为 \(2^k\)。由 (460.2)，
\[
  \operatorname{poly}(m_{\rm addr})s\ge2^k,
\]
再用 (460.5) 得 \(s=2^{\Omega(m_{\rm addr})}\)。证毕。

## 命题 460.2（small solution automaton would be the missing evaluator）

若 \(q|_{H^m}\) 有 \(s\)-state weighted automaton
\[
  q(a_1,\ldots,a_m)
  =
  \alpha^\top A_{a_1}\cdots A_{a_m}\beta,
\]
则其 individual-degree \(<|H|\) 延拓在任意 \(z\in F^m\) 上满足
\[
  q(z)
  =
  \alpha^\top
  \prod_{i=1}^m
  \left(\sum_{a\in H}\ell_a(z_i)A_a\right)
  \beta.
\tag{460.7}
\]
因此 generic evaluation 只需
\(\operatorname{poly}(m,|H|,s,\log|F|)\) 运算。

### 证明

把 tensor Lagrange formula
\[
q(z)=\sum_{a\in H^m}q(a)\prod_i\ell_{a_i}(z_i)
\]
代入 weighted representation，并按坐标逐一交换有限求和与矩阵乘积，即得 (460.7)。
证毕。

## 对 RW Closure 的后果

* C443--C453 已给出小 automaton 计算 constraint extension \(\widehat D\)，但定理 460.1
  说明这不向唯一 solution \(q\) 传递。
* 若 actual C456 \(q_n\) 反而满足 \(s=\operatorname{poly}(m)\)，命题 460.2 会给出
  generic \(q_n\)-evaluator；C459 随即与 published
  \(\operatorname{CC}(B_n)=\Omega(N_n/\log N_n)\) 冲突。
* 因而下一正向命题必须明确提出超出 local regularity 的 actual-machine
  parallelization/low-rank invariant；不能把 C443 的 constraint automaton 重命名为
  solution automaton。

## 证据边界

* 反例关闭一般 implication，不单独证明 actual C456 machine 的 assignment table 在
  所有表示模型下都需指数 states。
* output restriction 使用 C453--C454 的连续 block / regular address transducer；
  任意不规则隐藏重排必须把 transducer complexity 计入。
* 结论针对 weighted automata/Hankel rank；不自动覆盖所有可能的 structured
  representations 或新 non-product relations。

## 来源

* Weighted-automaton Hankel-rank factorization。
* [C453 local-tableau compiler](453-rw-lex-prefix-preserving-local-tableau-compiler-2026-08-19.md)。
* [C458 grid-to-generic query lower bound](458-grid-to-generic-exact-query-lower-bound-2026-08-19.md)。
* [C459 generic-\(q\) forcing lower bound](459-published-rw-generic-q-access-forcing-scale-2026-08-19.md)。
