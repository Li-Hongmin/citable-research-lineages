> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Smooth coordinate-robust proof code 必然给出 LDC（2026-08-16）

## 结论地位

本 note 给出一个比“近 codeword 上额外假设高完备性”更自然的受限下界。只要局部
查询是非自适应且 smooth，honest proof 上的完美完备性会自动传递到常数比例 corruption
的近 proof；再与错误声明的坐标 soundness 比较接受频率，就得到普通 LDC。因而任何
近线性、常数查询的正向 ACRR 构造，若要避开 LDC 下界，必须明确使用非 smooth/adaptive
查询，或保留 relaxed/`\bot` 完备性缺口。

## 定义：smooth coordinate-robust proof code

令

\[
  C:\{0,1\}^k\to\Sigma^N
\]

是 injective proof/codeword map。对每个 `i\in[k]`、`b\in\{0,1\}`，给定一个
非自适应 `q`-query 随机 verifier `V_{i,b}`。随机串 `R` 决定有序查询元组
`I_{i,b}(R)=(I_{i,b,1}(R),\ldots,I_{i,b,q}(R))` 和局部 predicate；查询位置不依赖于
oracle 内容。假设：

1. **完美完备性：** 对任意 `m`，`V_{i,m_i}^{C(m)}` 以概率 `1` 接受；
2. **错误声明 soundness：** 对任意 `m`、任意 oracle `y\in\Sigma^N`，
   只要 `dist(y,C(m))<=delta_0`，就有
   `Pr[V_{i,1-m_i}^{y}=1]\le\beta`；
3. **`\lambda`-smoothness：** 对任意 `i,b,r,j`，
   `Pr_R[I_{i,b,r}(R)=j]\le\lambda/N`。

这里的 soundness 是 **target-relative near-oracle** 量词，而不是对所有 codeword
family 共用的全 oracle 量词；否则另一个消息的完备性会立即产生冲突（见 note 192）。
以下只讨论 `delta<=delta_0`。允许 verifier 对错误声明拒绝或输出 `\bot`；只把接受记为
`1`。`\lambda=1` 是均匀边缘的典型情形。

## 定理：自动获得近 proof 完备性

若 `dist(y,C(m))\le\delta N` 且 `delta<=delta_0`，则对正确声明 `m_i` 有

\[
  \Pr[V_{i,m_i}^{y}=1]
  \ge 1-q\lambda\delta .
\]

### 证明

令 `B` 为被 corruption 的坐标集合。若 `I_{i,m_i}(R)\cap B=\varnothing`，则
`V_{i,m_i}` 在 `y` 与 `C(m)` 上看到完全相同的局部视图，因而接受。由 union bound 和
逐次 query 的 smoothness，

\[
 \Pr_R[I_{i,m_i}(R)\cap B\ne\varnothing]
 \le \sum_{r=1}^{q}\sum_{j\in B}\Pr_R[I_{i,m_i,r}(R)=j]
 \le q|B|\lambda/N
 \le q\lambda\delta
\]

故正确声明的接受率至少为 `1-q\lambda\delta`。证毕。

## 定理：smooth ACRR 编译为 LDC

令

\[
  \gamma:=1-q\lambda\delta-\beta.
\]

若 `\gamma>0`，则 `C` 是一个 corruption radius `\delta`、字母表 `\Sigma`、查询数

\[
  O\!\left(\frac{q}{\gamma^2}\right)
\]

的普通 LDC。

### 证明

给定 oracle `y` 和 index `i`，分别独立运行 `V_{i,0}` 与 `V_{i,1}` 各
`R=Theta(\gamma^{-2})` 次，比较两种声明的接受频率，并输出频率更高的 bit。

若 `m_i=0` 且 `dist(y,C(m))\le\delta N`，上一个定理给出 `V_{i,0}` 的期望接受率
至少 `1-q\lambda\delta`，错误 verifier `V_{i,1}` 的接受率至多 `\beta`。两者间隔
至少 `\gamma`；错误分支的上界在这里正是 target-relative 条件且由
`delta<=delta_0` 保证。`m_i=1` 时同理。Hoeffding 界说明取
`R=Theta(\gamma^{-2})` 后错误概率至多 `1/3`；总查询数为
`2Rq=O(q/\gamma^2)`。这正是 LDC 的局部解码条件。证毕。

## 直接下界

在常数 alphabet、常数 `q,\lambda,\delta,\beta` 且 `\gamma>0` 的情形，上述对象是
普通常数查询 LDC。因此可直接调用三查询 LDC 下界：当 `q=3` 时，

\[
  N=\widetilde\Omega(k^3)
\]

（具体 polylog 因子取决于所采用的 LDC 下界版本）。特别地，`N=\widetilde O(k)` 的
smooth、三查询、强坐标鲁棒 proof code 不可能存在。

## 对 ACRR 的含义

这条 barrier 比 note 180 的假设更弱：note 180 直接把“近 proof 上正确声明高完备”
作为前提；本 note 从 perfect completeness 加 smooth 查询自动推出它。因此，一个
近线性、固定小查询的正向 ACRR 若要逃出该下界，至少必须明确满足以下之一：

1. **非 smooth 查询：** 少数 proof 坐标承载很大的查询质量，union-bound 传递失效；
2. **adaptive 查询：** 查询位置依赖已读符号，不能用固定 marginal 的 smoothness 直接
   耦合；
3. **relaxed 完备性：** 近 proof 上正确声明可能经常拒绝或输出 `\bot`，只留下 RLDC
   而非 LDC；
4. **非 codeword proof：** proof symbols 没有一个 injective message map `C`，不能直接
   作为 LDC codeword。

这四条是结构性逃逸，不是实现细节。尤其是“允许 `\bot`”必须在主定理中显式记账：
如果某个候选构造声称近 proof 上也保持固定高完备性，同时又使用 smooth、非自适应查询，
本定理立即把它送入 LDC 下界。

## 与现有路线的关系

- note 180 的 strong-completeness ACRR→LDC 是本定理的直接特例；本 note 解释了
  smoothness 为什么足以补上 strong-completeness。
- note 178 的线性 ACRR→RLDC 允许 relaxed/`\bot` 语义，因而不与本定理冲突。
- note 183--184 的 exposed-history PCPP+RLDC 基线通常保留 `\bot` 或显式 history，
  所以也不被本定理直接否定。
- GM--Minzer--Weissenberg--Zheng 的 3-query LDC 下界提供最终参数障碍；其 3-query
  RLDC 构造之所以能达到 `\widetilde O(k^2)`，正是因为 relaxed rejection 逃出了本定理。

## 证据边界

本 note 的新内容是一个纯局部概率耦合：完美完备 + 非自适应 smooth 查询
`\Rightarrow` 近 corruption 高完备，再与 **target-relative** 错误 soundness 做频率
比较得到 LDC。它不声称一般 ACRR 已被排除；非 smooth、adaptive、relaxed、单目标或
非 codeword proof 模型仍然开放。全 oracle family 量词的冲突见 note 192。

## 来源

- [GM--Minzer--Weissenberg--Zheng, Theorems 1.9--1.10](https://arxiv.org/html/2512.12960)
- [note 180: strong-completeness ACRR barrier](180-robust-completeness-acrr-implies-ldc-barrier-2026-08-16.md)
- [note 178: linear ACRR/RLDC barrier](178-linear-projection-acrr-implies-rldc-barrier-2026-08-16.md)
- [note 192: family-level quantifier audit](192-family-quantifier-audit-for-acrr-barriers-2026-08-16.md)
