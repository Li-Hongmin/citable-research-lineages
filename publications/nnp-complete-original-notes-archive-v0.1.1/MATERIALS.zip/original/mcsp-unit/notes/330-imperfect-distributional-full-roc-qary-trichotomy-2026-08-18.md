> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Imperfect distributional full-ROC q-ary Closure Trichotomy

## Contribution

Notes 275 and 328 can be composed without an inner code.  The resulting
statement closes a broad target-dependent package model in one theorem: a
near-linear construction with arbitrary proof alphabet must pay either

1. robust defect or target information in the package distribution,
2. a message-scale proof alphabet, or
3. the direct q-ary query envelope.

This is the imperfect-completeness analogue of the distributional
growing-alphabet gate.  Its hypotheses retain the essential global
full-ROC/max-before-average quantifier; ordinary average or list soundness
does not enter the theorem.

## Theorem

Let
\[
  \Pi_K:\{0,1\}^{K}\longrightarrow\Sigma_K^{P_K},
  \qquad A_K:=|\Sigma_K|\ge2,
\]
be one common proof map.  For a target \(m\), draw a global package
\(S\sim\mu_m\).  The package contains all coordinates and both claims in one
proof/address space, with adaptive proof-symbol depth at most \(r_K\).
Fix constants
\[
  0<\rho<1,\qquad 0\le\beta<\alpha\le1,
\]
and define the worst-coordinate, target-relative full-ROC defect
\[
\begin{aligned}
 \mathcal D(m,S):=\max\Bigl\{&
   \max_i(\alpha-C_{m,i,S})_+,\\
   &\max_{\substack{i,b,z:\ m_i\ne b\\
                    d_H(z,\Pi_K(m))\le\rho P_K}}
       (W_{m,i,b,S}(z)-\beta)_+
 \Bigr\}.
\end{aligned}
\tag{330.1}
\]
Let \(M\) be uniform on \(\{0,1\}^K\), put
\[
  \bar\delta_K:=\mathbb E_{M,S\sim\mu_M}\mathcal D(M,S),
  \qquad
  I_K:=I(M;S)\ \text{(bits)},
  \qquad
  \tau_K:=\bar\delta_K+\sqrt{\frac{\ln2}{2}I_K}.
\tag{330.2}
\]

Choose a fixed
\[
  0<\Delta<\frac{\alpha-\beta}{2},
\tag{330.3}
\]
and define
\[
  c_\Delta:=\alpha-\Delta,\qquad
  s_\Delta:=\beta+\Delta,\qquad
  \sigma_\Delta:=\min\{c_\Delta,1-s_\Delta\}>0.
\]
Let \(d_K\ge\kappa K\) be the shattered-coordinate dimension supplied by a
density-\(1/2\) subfamily, where \(\kappa>0\) is an absolute constant
(for example, \(\kappa=1/4\) works for all sufficiently large \(K\) by
Sauer--Shelah).  Put
\[
  Q_K:=1+2\sum_{j=0}^{r_K-1}A_K^j,
  \qquad
  H_K:=\log_2\log_2(K+2)+\log_2(Q_K+2)
       +\log_2\!\bigl(\log_2(A_K+2)+2\bigr).
\tag{330.4}
\]

Suppose \(K+P_K\le K(\log_2(K+2))^{c_0}\) on infinitely many sufficiently
large \(K\).  Then, for every such large \(K\), at least one of
\[
\boxed{\tau_K\ge\frac{\Delta}{2}}
\tag{330.5}
\]
or
\[
\boxed{\log_2(A_K+2)\ge\frac{\kappa K}{2}}
\tag{330.6}
\]
or
\[
\boxed{Q_KH_K\ge\eta\log_2K}
\tag{330.7}
\]
holds, where \(\eta=\eta(\rho,\alpha,\beta,\Delta,c_0)>0\).

Thus a target-dependent imperfect full-ROC package cannot simultaneously
have vanishing defect/information, a non-message-scale alphabet, and
sub-\(\log K\) direct q-ary locality in the near-linear proof-length regime.

## Proof

Assume first that \(\tau_K<\Delta/2\).  The mutual-information mixture
calculation gives
\[
  \mathbb E_M
  \mathbb E_{S\sim\bar\mu_K}\mathcal D(M,S)
  \le \tau_K,
  \qquad
  \bar\mu_K:=\mathcal L(S).
\tag{330.8}
\]
Markov therefore leaves a target subfamily
\(\mathcal F_K\) of density at least \(1/2\) on which
\[
  \mathbb E_{S\sim\bar\mu_K}\mathcal D(m,S)\le\Delta.
\]
By the definition of (330.1), the same target-independent law
\(\bar\mu_K\) satisfies
\[
  \mathbb E_{\bar\mu_K}C_{m,i,S}\ge c_\Delta,
  \qquad
  \mathbb E_{\bar\mu_K}W_{m,i,b,S}(z)\le s_\Delta
\tag{330.9}
\]
simultaneously for every \(m\in\mathcal F_K\), every coordinate and claim,
and every \(\rho P_K\)-near target proof.  The inequality
\(c_\Delta>s_\Delta\) follows from (330.3).

Sauer--Shelah supplies a shattered coordinate set \(J_K\) of size
\(d_K\ge\kappa K\).  Choose one representative of \(\mathcal F_K\) for
each pattern on \(J_K\).  Equation (330.9) is precisely the
target-independent imperfect full-ROC hypothesis of note 328, with message
length \(d_K\), proof length \(P_K\), alphabet \(A_K\), and success parameter
\(\sigma_\Delta\).

The tagged q-ary construction of note 328 gives an RLDC of length
\(N_\star=d_K+P_K\).  Since \(d_K\ge\kappa K\),
\[
  N_\star\le K+P_K
  \le d_K(\log_2(d_K+2))^{c_1}
\tag{330.10}
\]
for a fixed \(c_1=c_1(\kappa,c_0)\).  Applying its GGS calculation yields
either
\[
  \log_2(A_K+2)\ge d_K/2
\]
or
\[
  Q_KH_K=\Omega_{\rho,c_\Delta,s_\Delta,c_1}(\log d_K).
\]
Using \(d_K\ge\kappa K\) gives (330.6) or (330.7), after changing constants.

Consequently, if neither (330.6) nor (330.7) holds, the assumption
\(\tau_K<\Delta/2\) is impossible, and (330.5) follows.  This proves the
trichotomy.
\(\square\)

## Interpretation and boundaries

The first branch is an explicit package cost:
\[
  \bar\delta_K+\sqrt{\frac{\ln2}{2}I(M;S)}
  \ge\Delta/2.
\]
It includes either a constant robust ROC defect or a linear-scale amount of
target information.  The second branch is a proof alphabet carrying
\(\Omega(K)\) bits per symbol.  The third is the direct q-ary locality gate,
with no binary inner-code assumption.

The max over coordinates and all near proofs in (330.1) is essential.  If the
defect is only averaged over coordinates, if each coordinate has its own
package, or if the wrong-claim condition is only an ordinary list/average
statement, (330.8)--(330.9) do not follow.  The theorem is a closure
trichotomy, not an unconditional dPCP impossibility or a proof of
\(P\ne NP\).

## Sources

* Mutual-information/full-ROC mixture: [note 275](275-mutual-information-mixture-to-full-roc-closure-2026-08-20.md).
* Direct imperfect q-ary envelope: [note 328](328-imperfect-full-roc-joint-alphabet-envelope-2026-08-18.md).
* Sauer--Shelah and the arbitrary-finite-alphabet GGS theorem are used in the
  final coding step.
