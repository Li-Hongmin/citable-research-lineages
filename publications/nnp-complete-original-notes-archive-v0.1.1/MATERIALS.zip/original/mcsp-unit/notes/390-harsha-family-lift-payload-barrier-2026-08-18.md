> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha actual family-lift 的 auxiliary payload barrier（2026-08-18）

## 命题

把 RW Theorem 3.5 的**实际 Harsha proof selector**应用到一个合法的 identity
machine

\[
  M_{\mathrm{id}}(x)=x,\qquad x\in\{0,1\}^{b},
\tag{390.1}
\]

其中 machine 不发 NP query、运行时间 \(\operatorname{poly}(b)\)，并把输出长度取为
\(\ell=b\)。对每个 \(x\)，Theorem 3.5 的 systematic output field 因而是不同的
parent \(x\)，而 Harsha 的诚实 proof 由 C389 的固定
\(\operatorname{Aux}_{\mathrm{Harsha}}\) selector 生成。

固定一个 proof block/coordinate 及其公开 metadata，并考虑 target-oblivious
(hidden-parent) channel：decoder 不另外读取完整的 \(x\) 或 parent。若该观察
channel 的长度为 \(s\) bits，target-dependent descriptor 的长度为 \(d\) bits，则任何 exact decoder
\[
  D(y_x,\mathrm{metadata},\sigma_x)=x
\]
都必须满足

\[
  s+d+\lvert\mathrm{metadata}\rvert\ \ge\ b.
\tag{390.2}
\]

特别地，一个 JK outsider block 给出 \(s=2k\) bits；若 block/path metadata 与
descriptor 都保持 \(\operatorname{poly}(\log b)\) 地址尺度，且不把公开输入 \(x\)
偷偷计入 channel，则 \(k=\operatorname{poly}(\log b)\) 时不可能对这个 actual
Harsha family 做 whole-parent exact binding。若 decoder 可以直接读取 \(x\)，则
\(\lvert\mathrm{metadata}\rvert\ge b\) 是 (390.2) 的合法、但 object-scale 的
支付；C390 不排除这种 x-aware compiler。

## 证明

固定 proof coordinate 后，实际 honest-proof selector 给每个 target \(x\) 一个
确定的 observed string \(y_x\in\{0,1\}^{s}\)。把公开 metadata 与 descriptor
\(\sigma_x\in\{0,1\}^{d}\) 一起看成 decoder 的标签。若 (390.2) 不成立，则

\[
  2^{s+d+\lvert\mathrm{metadata}\rvert}<2^b.
\]

由抽屉原理存在 \(x\ne x'\) 具有相同的 \((y_x,\mathrm{metadata},\sigma_x)\)。
decoder 在这两个 target 上收到完全相同的输入，却必须输出不同的 parent，
矛盾。证毕。

## 与 published RW 的关系

这不是对 published Theorem 4.3 singleton call 的直接不可能性：该 theorem 每层
固定 \(x_0\)，令 \(f_i(x)\) 与 \(x\) 无关，并只调用 \(\mathrm{Solve}_{f_i}(x_0,G)\)。
因此 published call 本身没有 \(2^b\) 个 target parent，不能仅由 (390.2) 推出
其 outsider 不可绑定。

但 (390.2) 关闭了一个自然的正攻路线：把 actual Harsha construction 直接提升为
**target-oblivious** family-level simultaneous common-proof compiler，再用一个或
\(\operatorname{poly}(\log b)\) 个 JK outsider 完成 whole-parent binding。这样的
hidden-parent family lift 必须显式支付 parent payload；它不能把 auxiliary/ECC
semantics 当作免费 global key。若目标 \(x\) 本来就是公开输入，则应把 \(x\) 的
长度计入 metadata，C390 只给出该成本而非不可能性。

若允许 \(q\) 个 outsider blocks，式 (390.2) 变为

\[
  2\sum_{t=1}^{q} k_t+d+\lvert\mathrm{metadata}\rvert\ \ge\ b,
\tag{390.3}
\]

与 C378/C383 的 multi-outsider bound 一致；C390 的新增点是 parent family 由
实际 RW/Harsha 的 identity-machine specialization 直接提供，而不是抽象 pad 或
任意 proof family。

## Gate-I 后果

在 target-oblivious family-level 路线上，C390 强迫至少一个参数离开地址尺度：

1. outsider 数量或总 block payload 达到 \(\Omega(b)\)；
2. descriptor/metadata 承担 \(\Omega(b)\) bits；
3. 把 target/input 公开给 decoder（支付 \(\Omega(b)\) metadata）；或
4. 放弃同一固定 selector/common proof；或
5. 改为 published singleton-specific 的局部逆问题，并说明为什么 singleton
   的 hard parent 不能被短地址 surface 计算。

因此 C390 不解决 \(P\ne NP\)，但把 C389 的“family/capacity alternative”具体化为
一个 source-realizable、可直接核验的容量障碍。

## 证据边界

* RW Theorem 3.5 明确把 machine output 放进 systematic witness/output field；
  \(M_{\mathrm{id}}\) 是其允许的 \(r=s=0\)、多项式时间特例。
* C389 给出 actual Harsha honest proof 的固定 selector/factorization。
* (390.2)--(390.3) 只是有限 channel 的 injectivity/counting 定理，且只对
  target-oblivious/hidden-parent channel 构成地址尺度 barrier；不声称
  x-aware family compiler 或 published RW singleton 已被排除，也不声称一般
  dPCP/RLDC 不可能或 \(P\ne NP\)。

## 来源

- Ren--Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin-Arthur Queries*, ECCC TR26-118, revision 1:
  <https://eccc.weizmann.ac.il/report/2026/118/revision/1/download>.
- Harsha thesis record:
  <https://dspace.mit.edu/handle/1721.1/26720>.
- Project notes [C378](378-jk-parent-binding-multi-outsider-communication-barrier-2026-08-18.md),
  [C383](383-rw-first-failure-output-attachment-trichotomy-2026-08-18.md), and
  [C389](389-harsha-auxiliary-factorization-no-local-inverse-2026-08-18.md).
