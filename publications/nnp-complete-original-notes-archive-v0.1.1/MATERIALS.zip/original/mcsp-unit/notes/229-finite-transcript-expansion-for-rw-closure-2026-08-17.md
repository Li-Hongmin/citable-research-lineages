> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Finite-transcript expansion for the RW Closure Gate (2026-08-17)

## Contribution

The ROM lemma in notes 204/220 accounts for a static descriptor, but a proposed
reconstruction may try to hide the global word in a finite public-coin Merlin strategy.
For a single forced object this escape has a direct circuit expansion as well.  A
short common strategy does not create a new complexity class: enumerate its public
random tapes, hardwire the common responses, and compute the acceptance threshold for
each address.

The resulting tradeoff is useful even before a family-level RLDC reduction.  The full
enumeration bound below is a first, deliberately conservative expansion; the sampling
refinement in note 230 removes the dependence on the number of public random bits whenever
one short common strategy is available.

## Theorem (single-object finite-transcript expansion)

Let \(H_n\in\{0,1\}^{N_n}\), with address length
\(\ell_n=\lceil\log_2N_n\rceil\).  Suppose a public-coin reconstruction has:

* a descriptor \(\sigma_n\) of length \(d_n\);
* public randomness \(R\in\{0,1\}^{r_n}\);
* one common strategy \(\mathcal S_n\), used for every address \(a\in[N_n]\);
* on each public tape, a total Merlin transcript of length at most \(L_n\);
* a deterministic verifier/evaluator of fan-in-two size at most \(p_n\), taking
  \((a,\sigma_n,R,\tau_R)\) as input, where \(\tau_R\) is the transcript supplied by
  \(\mathcal S_n\).

Assume the same strategy has a uniform constant gap for every address:

\[
  H_n[a]=1
  \Longrightarrow
  \Pr_R[V_n(a,\sigma_n,R,\tau_R)=1]\ge\alpha,
\]
\[
  H_n[a]=0
  \Longrightarrow
  \Pr_R[V_n(a,\sigma_n,R,\tau_R)=1]\le\beta,
\qquad
\alpha-\beta\ge\gamma>0.
\tag{229.1}
\]

Assume also that the gap is represented by a known integer threshold
\(t_n\) satisfying
\(\beta 2^{r_n}<t_n\le\alpha 2^{r_n}\); this is automatic, for example, when
\(2^{r_n}\gamma\ge2\) and the endpoints are given with the usual rational encoding.

Then there is an ordinary fan-in-two circuit \(C_n\) computing \(H_n\) with

\[
  \operatorname{CC}(H_n)
  \le
  2^{r_n}\,
  \operatorname{poly}\!\bigl(
    p_n,L_n,d_n,\ell_n,\log(1/\gamma)
  \bigr).
\tag{229.2}
\]

The polynomial is universal for the fixed thresholding convention.  In particular, if
all quantities other than \(r_n\) are \(n^{O(1)}\) and

\[
  \operatorname{CC}(H_n)>S_n,
\tag{229.3}
\]

then

\[
  r_n
  \ge
  \log_2 S_n
  -
  O\!\left(
    \log(p_n+L_n+d_n+\ell_n+\log(1/\gamma)+2)
  \right).
\tag{229.4}
\]

For a forcing scale \(S_n=n^{k(n)}\) and polynomially bounded
\(p_n,L_n,d_n,\ell_n,\gamma^{-1}\), this gives

\[
  r_n\ge k(n)\log_2n-O(\log n).
\tag{229.5}
\]

Thus a finite public-coin strategy with \(r_n=O(\log n)\) and polynomial local
description is already a \(P/\mathrm{poly}\) evaluator for the forced object.  A strategy
that avoids the contradiction must expose a forcing-scale number of public random bits,
or a strategy/transcript description whose size is itself forcing-scale.

## Proof

For every public tape \(R\), hardwire the common transcript \(\tau_R\) into a copy of the
verifier circuit.  This gives a circuit \(W_{n,R}(a)\) of size
\(\operatorname{poly}(p_n,L_n,d_n,\ell_n)\) computing the acceptance bit for address
\(a\).  Put all \(2^{r_n}\) copies in parallel, add their output bits with a binary
counter, and compare the sum with \(t_n\).  The counter and comparator cost
\(\operatorname{poly}(2^{r_n},\log(1/\gamma))\).  The resulting circuit outputs one
exactly on the first case of (229.1) and zero on the second, proving (229.2).
Rearranging (229.2) gives (229.4), and substituting \(S_n=n^{k(n)}\) gives (229.5).
\(\square\)

## Strategy circuits rather than transcript tables

The theorem also covers a common strategy given by a short address-parametrized circuit
\(\mathcal S_n(a,R,h)\), provided its total response length is at most \(L_n\) and its
circuit size is \(s_n\).  Replace \(L_n\) in (229.2) by a polynomial in
\(L_n,s_n\).  The strategy may see the public address and prior public transcript; what
matters is that the *same* short strategy circuit is used for all addresses.

If instead every address is allowed an unrelated response table, the expansion has to
hardwire \(N_n2^{r_n}\) transcripts.  That is precisely a target-specific history
descriptor, not a common finite strategy.  The theorem therefore gives a clean
quantifier test for the whole-word condition:

\[
  \exists\mathcal S_n\ \forall a
  \quad\text{is a short strategy branch,}
\qquad
  \forall a\ \exists\mathcal S_{n,a}
  \quad\text{is not.}
\tag{229.6}
\]

## Consequences for the Closure Gate

Combine (229.2) with the patchability-or-succinctness split of note 228.

1. If first-hit patches are realizable, exact hitting gives the RLDC branch.
2. If patches are not realizable but a common finite strategy has
   \(2^{r_n}\operatorname{poly}(p_n,L_n,d_n)=n^{O(1)}\), (229.2) gives the
   \(P/\mathrm{poly}\) contradiction against any \(n^{\omega(1)}\) forcing bound.
3. Therefore a surviving RW-specific construction must either prove a genuinely
   non-patchable global relation, make the common strategy pay the lower bound (229.4),
   or leave the finite-transcript model altogether.  High public randomness by itself is
   not enough: note 230 can replace full enumeration by
   \(O(\gamma^{-2}\log N_n)\) fixed tapes when the same short strategy serves all addresses.

This closes the finite-horizon interactive version of the descriptor escape without
assuming a family-level code.  It is stronger than a static ROM count but weaker than a
universal impossibility theorem: an unbounded strategy, a strategy with
environment-scale transcript, or a construction for one fixed target with no short
address-parametrized representation remains outside the statement.

## RW scale corollary (enumeration-only)

At a stable Ren--Williams stage, write
\[
  m_i=\left\lceil\log_2(2n_i)\right\rceil,
  \qquad
  T_i=n_{i+1}=n_i^C=2^{\Theta(m_i)}.
\]
The near-maximum AVOID/Korten forcing scale is
\(S_i=\Omega(2^{m_i}/m_i)\) on the good lengths supplied by the construction.  Therefore
any *address-scale* common finite strategy whose verifier, descriptor, and transcript
parameters are \(m_i^{O(1)}\) must satisfy
\[
  r_i\ge m_i-O(\log m_i).
\tag{229.7}
\]
This is only the consequence of the full-enumeration expansion.  Reducing the strategy to
\(O(\log m_i)\) public randomness would certainly give a polynomial-size circuit for the
forced table, but note 230 shows that high public randomness is not by itself a valid
escape when a short common strategy circuit exists.

The published RW \`Reconf\` guarantee does not meet the address-scale hypothesis.  Its
query generation is polynomial in \(k_i=n_{i+1}\), and the Merlin gate-list bound is
\(O(k_i^4\log T_i)\); this is \(2^{\Theta(m_i)}\)-scale when the forced table is indexed
by \(m_i\) bits.  Corollary (229.7) therefore does not claim that the existing RW
algorithm already contradicts itself.  The sharper remaining target is the common
strategy circuit/address response: if that object can be made \(m_i^{O(1)}\), note 230
applies regardless of the randomness length; otherwise its description remains an
object-scale coupling.

## Relation to the time-hierarchy barrier

The universal finite-transcript compiler barrier in
[finite-transcript public-coin compilers](../../rw-jk-succinct-reconstruction/statements/finite-transcript-randomness-time-hierarchy-barrier.md)
enumerates response tables to contradict nondeterministic time hierarchy.  The present
lemma is different in quantifiers and consequence: it fixes one RW target \(H_n\), expands
the common strategy directly into a circuit, and compares the result with the target's
forcing lower bound.  It therefore applies even when no universal compiler for an entire
time class is claimed.

## Evidence boundary

The expansion is a self-contained circuit argument.  It does not assert that the actual
RW Reconf strategy has a short common circuit, nor that \(P=NP\) automatically supplies
one.  If the strategy is only existential with no finite summary, (229.2) cannot be
invoked; that is exactly the remaining global-coupling escape to be resolved by a
source-specific theorem.
