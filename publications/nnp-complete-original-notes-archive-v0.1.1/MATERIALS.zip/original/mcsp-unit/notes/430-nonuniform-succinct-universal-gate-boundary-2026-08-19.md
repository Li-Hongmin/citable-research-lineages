> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Nonuniform succinct universal-gate boundary（2026-08-19）

## 本轮改变的判断

C361 已关闭 uniform 的 generic Local-JK physicalization：对所有 succinct seed
generators 的 \(\operatorname{poly}(m)\)-time evaluator 会给出
\(\mathrm{EXP}=\mathrm P\)。但 C181 的最终目标允许 \(P/\mathrm{poly}\) evaluator，
不能把 uniform 结论直接当成非一致不可能性。下面的精化给出正确边界：

> generic、对所有 succinct seeds 都有效的 \(m^{O(1)}\)-大小 evaluator 会把
> \(\mathrm{EXP}\) 放进 \(P/\mathrm{poly}\)；这不是当前已知的无条件分离，因此
> 最终正攻必须限制到 actual RW canonical seed subclass，不能只调用 generic
> universal-gate evaluator。

## 推论 430.1（generic nonuniform gate）

令 \(q=2^m\)，\(G_q\) 为 RW universal truth-table generator。对固定常数
\(a\ge1\)，定义 \(\operatorname{SuccEval}^{(a)}_G\) 为：输入一个描述长度至多
\(m^a\) 的 succinct seed generator \(U\)，其输出
\(u[\ell]\) 满足 \(U(\ell)=u[\ell]\)，以及一个输出地址 \(r\in\{0,1\}^{m+1}\)；
输出 \(G_q(u)[r]\)。

若存在大小为 \(m^{O(1)}\) 的非一致电路族 \(D_m\)，在所有合法 \(U,r\) 上计算
\(\operatorname{SuccEval}^{(a)}_G(U,r)\)，则
\[
 \boxed{\mathrm{EXP}\subseteq\mathrm{P/poly}.}
\tag{430.1}
\]

### 证明

取标准 succinct circuit-value 问题。其输入是一个多项式大小的索引电路
\(U_C\)，给定 gate-list index 时生成一个至多 \(q/(cm)\)-门电路 \(C\) 的描述，
以及一个 \((m+1)\)-bit 输入 \(r\)。把 \(U_C\) 零填充到允许的 \(m^a\) 描述长度，
得到合法 succinct seed generator \(U\)。由于 \(G_q\) 的 seed 编码正是该
gate-list encoding，
\[
 \operatorname{SuccEval}^{(a)}_G(U,r)=G_q(u_C)[r]=C(r).
\]
Succinct circuit value 在该 padded gate scale 上是 EXP-complete。对每个原始输入
长度 \(N\)，固定多项式时间归约产生 \(m=m(N)=N^{O(1)}\) 的参数；把归约、
零填充和 \(D_{m(N)}\) 组合成一个电路，大小仍为 \(N^{O(1)}\)。于是每个 EXP
语言都有多项式大小的非一致电路，得到 (430.1)。\(\square\)

## 量词边界

1. 430.1 的量词是“对所有 succinct \(U\)”。一个固定的 published singleton
   seed \(U_m\) 不触发它。
2. 430.1 不声称 \(\mathrm{EXP}\not\subseteq\mathrm{P/poly}\)。现有可用的
   Karp--Lipton 边界是：若发生该包含，则得到相应的指数层次塌缩；这不是本项目
   可以当作矛盾使用的定理。
3. **在最终反证的 \(P=NP\) 分支中，generic gate 实际被排除。** 若同时假设
   \(P=NP\)，则 \(\mathrm{PH}=P\)，特别是 \(\Sigma_2^P=P\)。Karp--Lipton/Meyer
   的指数层次版本把 \(\mathrm{EXP}\subseteq\mathrm{P/poly}\) 提升为
   \(\mathrm{EXP}=\Sigma_2^P\)，从而得到 \(\mathrm{EXP}=P\)，与确定性时间层次
   定理矛盾。因此 generic nonuniform universal-gate physicalization 不能作为
   \(P=NP\) 反证中的 Closure 接口。
4. 因而 \(P=NP\) 下的 RW Closure 仍有一个窄的正向窗口：证明 actual
   canonical proof 的 seed 落在 syntactically evaluable subclass，并给出其
   gate values 的 address-scale evaluator；或者替换 \(G_q\) 为新的
   relation-PCP predicate。generic universal-gate 不能提供这个证明。

## 对 Gate-I 的结论

这一步把“generic Local-JK”与“actual RW-specific selector”严格分开：

\[
\text{generic succinct seed evaluator}
\Longrightarrow \mathrm{EXP}\subseteq\mathrm{P/poly},
\]

而

\[
\text{actual fixed canonical seed}
\not\Longrightarrow
\text{generic succinct evaluator}.
\]

所以下一项真正值得投入的对象不是再次证明 universal gate 的 EXP-hardness，
而是核验 Harsha/RW canonical proof 的 seed subclass 是否有一个可证明的
低地址复杂度，并同时保持 same-proof、range closure、bottom/cover safety。

## 证据边界

本 note 是 [C361](361-succinct-universal-gate-barrier-2026-08-18.md) 的非一致
精化，使用同一个 succinct circuit-value 归约；它不证明 \(P\ne NP\)，也不排除
一个实际结构化 RW selector。条件性 \(P=NP\) no-go 与主论文中的对应讨论见
Paper 04 Proposition 1.6。
