> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Quantile branch-support adaptive closure (2026-08-18)

## Contribution

The fixed-tape decision-tree exposure bound pays for the largest possible
\(A\)-ary tree. That is unnecessarily pessimistic when a randomized verifier
has rare tapes on which the two claim branches expose many proof positions. The
right parameter is the upper quantile of the *common* support of both branches.

This note gives the exact truncation and amplification statement. It is not an
average-query lower bound: a tail estimate is first converted into a bounded-query
decoder, and only then is a standard RLDC lower bound applied. The result is
strictly different from the honest-path Lorenz profile, because \(U_i(\omega)\)
contains every possible response path on the fixed tape, not only the path taken
by the honest proof.

## Theorem (quantile-support compiler)

Let \(\Sigma\) be a finite proof alphabet and let
\(\Pi:\{0,1\}^k\to\Sigma^P\) be a common proof map. For every message coordinate
\(i\) and claim \(b\in\{0,1\}\), suppose the branch verifier is adaptive and uses
at most \(r\) proof-symbol queries on every random tape. Assume

\[
  p_{i,m_i}(\Pi(m))=1,
  \qquad
  d_H(z,\Pi(m))\le \rho P
  \Longrightarrow
  p_{i,1-m_i}(z)\le 1-\sigma_0,
\tag{335.1}
\]

for fixed \(0<\rho<1\) and \(0<\sigma_0\le1\). The inline decoder reads a
message claim \(b\), then runs the branch \(b\).

For a coordinate \(i\) and a random tape \(\omega\), let
\(U_{i,b}(\omega)\subseteq[P]\) be the union of all proof positions queried by
the depth-\(r\) decision tree of branch \(b\), over every possible answer path.
Put

\[
  U_i(\omega):=U_{i,0}(\omega)\cup U_{i,1}(\omega),
  \qquad
  s_i(\omega):=|U_i(\omega)|,
\tag{335.2}
\]

and define the worst-coordinate tail

\[
  \tau(T):=\max_i\Pr_\omega[s_i(\omega)>T].
\tag{335.3}
\]

Assume that the support sets are uniformly exposable from \((i,\omega)\), as is
the case for a finite-time verifier. If \(\tau(T)\le\sigma_0-\gamma\) for some
\(\gamma>0\), then independent resampling gives a nonadaptive finite-alphabet RLDC for
the inline code with

\[
  \text{radius }\delta_0(\rho,|\Sigma|)>0,\qquad
  \text{completeness }\ge 2/3,\qquad
  \text{wrong output }\le1/3,
\tag{335.4}
\]

and query count

\[
  Q_T\le 1+R_\gamma T,
  \qquad R_\gamma=O(\gamma^{-2}).
\tag{335.5}
\]

Consequently, every source-audited RLDC lower bound applicable to the resulting
\((Q_T,\delta_0,2/3)\) decoder applies with \(Q_T\), rather than with the full
tree bound \(1+2\sum_{j<r}|\Sigma|^j\). In particular, in the GGS radius window,

\[
  N:=k+P\ge
  \left(
  \frac{(2/3)^2 k}
  {38Q_T^4\log^2(|\Sigma|+2)\log^2 k}
  \right)^{1+1/\lceil 3Q_T/2\rceil}.
\tag{335.6}
\]

For every fixed \(\gamma>0\), a near-linear family
\(N\le k(\log k)^c\) therefore satisfies

\[
  Q_T=\Omega_{\rho,\gamma,|\Sigma|,c}
  \left(\frac{\log k}{\log\log k}\right)
\tag{335.7}
\]

whenever \(\tau(T)\le\sigma_0-\gamma\), unless the GGS radius window fails; in
that failure branch \(Q_T=\Omega_{\rho,|\Sigma|,\sigma_0}(\log k)\) already.

## Corollary (tail necessity for near-linear families)

Fix \(c\ge0\) and \(0<\gamma<\sigma_0\).  Define the
\((\sigma_0-\gamma)\)-quantile support threshold

\[
  T_\gamma(k):=\inf\{T\ge0:\tau(T)\le\sigma_0-\gamma\}.
\tag{335.7a}
\]

If \(N_k\le k(\log k)^c\) for infinitely many sufficiently large \(k\), then

\[
  T_\gamma(k)
  =\Omega_{\rho,\gamma,|\Sigma|,c}
  \left(\gamma^2\frac{\log k}{\log\log k}\right).
\tag{335.7b}
\]

Equivalently, for every sufficiently small constant \(\eta>0\), every
\(T\) with \(1+R_\gamma T\le\eta\log k/\log\log k\) must satisfy
\(\tau(T)>\sigma_0-\gamma\).  Thus a near-linear construction cannot put all
large branch supports into a tail of probability smaller than the available
branch gap.

## Proof

Fix \(T\). On a random tape with \(s_i(\omega)\le T\), query every position in
\(U_i(\omega)\) once and simulate the branch selected by the inline claim. On a
tape with \(s_i(\omega)>T\), output \(\bot\) without querying the proof. This
truncation is legal because \(U_i(\omega)\) is determined before any received
proof symbols are seen.

On the exact proof and the correct inline claim, every good tape accepts, while
bad tapes only cause \(\bot\). Thus the correct-claim probability is at least
\(1-\tau(T)\). On a \(\rho P\)-near proof and the wrong inline claim, every good
tape has acceptance probability at most \(1-\sigma_0\), and a bad tape outputs
\(\bot\). Hence the wrong-output probability is at most \(1-\sigma_0\). The
gap between these two acceptance probabilities is at least
\(\sigma_0-\tau(T)\ge\gamma\).

Take \(R_\gamma=O(\gamma^{-2})\) independent tapes and threshold the number of
accepting repetitions halfway between \(1-\tau(T)\) and \(1-\sigma_0\). Hoeffding's
inequality gives completeness at least \(2/3\) and wrong-output probability at most
\(1/3\). Each repetition exposes at most \(T\) proof positions from the union of
the two branches, while the inline symbol is read once, so the union query count is
\(1+R_\gamma T\). The proof-distance and inline-radius argument is unchanged from
the fixed-tape compiler.

The GGS inequality is then exactly the standard lower bound for the nonadaptive
RLDC in (335.4). If its radius condition fails, rearranging
\(\delta_0\le N^{-(2/3)/(2Q_T)}\) gives \(Q_T=\Omega(\log N)=\Omega(\log k)\).
If it holds, the near-linear phase calculation for the GGS bound (with
\(\sigma=2/3\)) gives (335.7). \(\square\)

The tail statement follows by applying (335.7) to the first \(T\) for which
\(\tau(T)\le\sigma_0-\gamma\), and using \(R_\gamma=O(\gamma^{-2})\).

## Boundaries

* A bound on \(\mathbb E[s_i(\omega)]\) alone is not silently substituted for a
  bounded-query RLDC. It enters through Markov's inequality: if
  \(\mathbb E[s_i]\le\bar s\), then \(\tau(T)\le\bar s/T\), and one must choose
  \(T>\bar s/(\sigma_0-\gamma)\). The resulting \(Q_T\) records the tail cost.
* The theorem is about common two-branch support. Counting each branch separately
  would lose shared queries and can be strictly weaker.
* Uniform exposability is an implementation condition. Without it, (335.2) still
  defines an information-theoretic support bound, but not necessarily a legal
  finite-time decoder.
* The result does not turn ordinary list/distributional soundness into a common
  global proof. It applies only after the target-relative branch promise (335.1)
  is already available.

## Relation to existing closure mechanisms

The worst-case decision-tree lemma uses
\(s_i(\omega)\le2\sum_{j<r}|\Sigma|^j\) for every tape. The present theorem replaces
that deterministic envelope by a high quantile of \(s_i\), and pays only the tail
through the completeness gap \(\gamma\). The honest-path Lorenz profile is a
different quantity: it measures repeated reads on the single honest transcript and
does not control the off-path support needed to remove adaptivity.

The theorem is a conditional coding barrier, not a \(P\ne NP\) theorem and not an
unconditional impossibility result for dPCP constructions.

## Sources

* Main paper, Lemma 4.0 and Theorem 4.1.
* Main paper, Corollary 4.1A and the source-audited imperfect-completeness
  amplification.
* Goldberg--Gur--Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally Decodable
  Codes via Robust Daisies*, arXiv:2511.21659, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.
