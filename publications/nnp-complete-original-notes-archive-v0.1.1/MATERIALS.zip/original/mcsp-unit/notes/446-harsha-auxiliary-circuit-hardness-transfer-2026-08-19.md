> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha auxiliary-to-systematic circuit-hardness transfer（2026-08-19）

## 本轮改变的判断

C439 的反演不仅是一个“若有 evaluator 则可恢复 \(q\)”的算法性接口，还给出
一个定量的电路复杂度转移：在固定 \(\widehat C\)-evaluator 和 incidence map
下，\(P=p(q)\) 的 generic-point evaluator 至少和 systematic \(q\) 一样难，
只损失 Harsha field-size 与地址生成的多项式因子。

因此在 \(P=NP\) zero-round representation 中，即使 C444 已经解决
\(\widehat C\) 的 address-scale 求值，任何仍想通过 factorized \(P\) 段闭合的方案
都必须支付 parent 的 forcing-scale complexity；它不能把 \(P\) 当作一个独立的
polylog auxiliary string。这个结论适用于 published singleton，只要其 output
coordinates 的 incidence/serialization 接口成立。

## 定理 446.1（auxiliary circuit-hardness transfer）

令 \(q:H^m\to\{0,1\}\) 是 Harsha assignment，\(\widetilde q\) 是其低度延拓，
\(P_q=p(\widetilde q)\)，且 \(|F|=Q\)。假设：

1. 每个需要的 \(u\in H^m\) 有 address-scale 可生成的
   \(\operatorname{Inc}(u)=(v_u,w_u)\)，使 C439 的非退化条件成立；
2. \(\widehat C\) 有一个固定 field-symbol evaluator \(E_C\)，电路大小为 \(s_C\)；
3. \(P_q\) 有一个 generic-point field-symbol evaluator \(E_P\)，电路大小为
   \(s_P\)，输入是 \(3m+3\) 个 \(F\)-symbols 的二进制编码；
4. field arithmetic、\(E_C\)、incidence map 和 \(H^m\) 地址编码的 description
   不含 q-dependent advice。

记 \(S_q\) 为 \(q\) 在 \(\lceil\log_2|H^m|\rceil\)-bit 地址上的 Boolean circuit
complexity。则存在一个显式多项式 \(K(m,Q)\)，满足

\[
 S_q
 \le
 K(m,Q)\bigl(s_P+s_C+s_{\mathrm{Inc}}+1\bigr).
\tag{446.1}
\]

若一个 parent word \(B\) 的每一位满足
\(B_j=q(u_j)\)，且 \(j\mapsto u_j\) 有大小 \(s_{\mathrm{out}}\) 的 address map，
则

\[
 \operatorname{CC}(B)
 \le
 K(m,Q)\bigl(s_P+s_C+s_{\mathrm{Inc}}+s_{\mathrm{out}}+1\bigr).
\tag{446.2}
\]

因而

\[
 s_P
 \ge
 \frac{\operatorname{CC}(B)}{K(m,Q)}
 -s_C-s_{\mathrm{Inc}}-s_{\mathrm{out}}-1 .
\tag{446.3}
\]

在 Harsha 的最小字段参数 \(Q=\operatorname{poly}(m)\)，且 \(E_C\)、incidence
和 output map 都是 \(\operatorname{poly}(m)\) 时，若
\(\operatorname{CC}(B)>N^{k(N)}\)，则 \(P\)-evaluator 的电路大小至少为
\(N^{k(N)}/\operatorname{poly}(m)\)，不可能是 address-scale
\(\operatorname{poly}(m)\)。

### 证明

对任意输入地址 \(u\)，执行 C439 的有限枚举：生成
\(\operatorname{Inc}(u)\)，遍历 \((a,b,y)\in F^3\)，调用 \(E_P\) 和 \(E_C\)，
在一个满足非零条件的 slice 上取两个不同的 \(y\)，再用式 (439.7) 计算
\(q(u)\)。把 \(Q^3\) 次调用完全展开成一个 fan-in-two circuit；field division
只在已知非零 denominator 上使用，可以用有限域逆电路或平行枚举实现。其规模是
\[
 O\!\left(Q^3(s_P+s_C+s_{\mathrm{Inc}}+\operatorname{poly}(m,\log Q))\right),
\]
吸收地址 bit/base-\(|H|\) 转换后得到 (446.1)。

若 \(B_j=q(u_j)\)，把 \(j\) 先送入 output-address circuit，再调用上述 \(q\)
evaluator，即得 (446.2)。重排即为 (446.3)。证毕。

## 对 RW/Harsha closure 的直接后果

在 C444 的 fixed-machine cell-time representation 下，\(s_C,s_{\mathrm{Inc}}\)
可以是 \(\operatorname{poly}(m)\)。于是 factorized Harsha branch 的 singleton
闭合只有两种可能：

* \(P\)-evaluator 也在 \(\operatorname{poly}(m)\) 规模，进而 (446.2) 直接把
  forcing-hard parent \(B\) 压进 \(P/\mathrm{poly}\)，产生目标矛盾；
* \(P\)-evaluator 不在 address scale，而必须支付 (446.3) 的
  object/forcing-scale complexity，或退出 C439 的 same-serialization/factorized
  interface。

这比“P 段是否有一个短 accessor”更精确：在满足 source layout 后，短 accessor
不是未知的中性接口，而是与 forcing 下界直接冲突的对象。

## 证据边界

* 定理是 C439 的电路化推论；它不声称 published RW 已给出 \(E_P\)、\(E_C\) 或
  incidence map。
* 若 \(P\) proof 只作为 object-scale table 给出，(446.3) 允许它很大；完整
  Harsha table 的长度不自动等于一个 address evaluator。
* 若输出坐标不满足 \(B_j=q(u_j)\) 的 fixed projection，必须另证 output attachment；
  C442/C444 只处理 source-compatible representation。
* 本定理不单独证明 \(P\ne NP\)：它证明的是，在 forcing-hard parent 存在时，
  factorized Harsha auxiliary branch 无法同时保持短 \(\widehat C\)、短 \(P\) 和
  same-proof output attachment。

## 来源

* [note 439](439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md)。
* [note 442](442-rw-regular-output-gate-compiler-2026-08-19.md)。
* [note 444](444-cell-time-offset-regular-rw-unrolling-2026-08-19.md)。
* [note 220](220-rw-forcing-scale-advice-lower-bound-2026-08-17.md)。
