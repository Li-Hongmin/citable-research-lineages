> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Hidden continuation complexity boundary (2026-08-24)

## Proposition 31

Fix source-independent target input, oracle, scheduler, and random tape, together with a
known-order source scan of length \(N\). The initial
complete state is independent of the unread source, and every source-dependent object is created
causally by transitions from the current state and the next scanned source bit; no source-dependent
advice, preloaded RAM, or \(O_x\) is allowed. At source-prefix time \(t\), let \(v\) be a visible
record consisting of the complete counted source/target configurations and payload. Hidden
source-dependent objects may remain outside \(v\). For every reachable complete history \(C\) with
record \((t,v)\), define its future acceptance residual

\[
F_C:\{0,1\}^{N-t}\longrightarrow\{0,1\},
\qquad
F_C(z)=\text{the final decision on continuation }z.
\]

Let

\[
R=\max_{t,v}
\left|\{F_C:C\text{ reaches }(t,v)\}\right|.
\tag{31.1}
\]

Then the protocol has an equivalent length-\(N\) known-order ROBP of width

\[
\boxed{
\mathfrak W\le (N+1)W_QW_D2^hR.
}
\tag{31.2}
\]

Under the local-PRG interface of Proposition 10, every exact or bounded-error MCSP protocol
satisfies

\[
\boxed{
h+\log_2W_Q+\log_2W_D+\log_2R
=\widetilde\Omega(S),
\qquad S=N^{\mu_H}.
}
\tag{31.3}
\]

For bounded error, require
\(\varepsilon_Y+\varepsilon_N+\eta_{\mathrm{PRG}}<1\), up to the \(o(1)\) uniform-NO
probability, where \(\eta_{\mathrm{PRG}}\) is the local-PRG additive fooling error. Random tapes
must be source-independent and the same width bound must hold for every fixed tape.

## Proof

At layer \(t\), each visible record \(v\) contributes at most \(R\) residual functions, so the
total number of distinct residual functions is at most
\((N+1)W_QW_D2^hR\). Use these functions themselves as ROBP states. On input bit \(b\), send
\(F\) to

\[
\delta_t(F,b)(z)=F(bz),
\]

and at \(t=N\) use \(F(\epsilon)\) as the terminal label. The derivative is independent of the
history representing \(F\), so the resulting branching program is well-defined and proves (31.2).

Apply the local-PRG argument of Proposition 10 to this ROBP. If
\(\log(N\mathfrak W)=o_{\widetilde{\ }}(S)\), every generated table is in the MCSP YES class,
whereas a uniform table is NO with probability \(1-o(1)\). The acceptance gap
\(1-\varepsilon_Y-\varepsilon_N-o(1)\) exceeds \(\eta_{\mathrm{PRG}}\), contradicting the
fooling guarantee. Thus
\(\log(N\mathfrak W)=\widetilde\Omega(S)\). Absorb the polynomial \(N\)-factors in (31.2) to
obtain (31.3).

## Interpretation and boundary

If all source-dependent data is already in the visible complete state, then \(R=1\) and
Proposition 31 reduces to Proposition 29. If a pointer, RAM cell, query string, scheduler, or
answer buffer is omitted, \(R\) measures the number of distinct future acceptance behaviors that
the omission can hide. Therefore any such hidden channel that evades the visible-state barrier
must satisfy

\[
\log_2R=\widetilde\Omega(S)
-h-\log_2W_Q-\log_2W_D.
\]

This is a semantic continuation lower bound, not a time lower bound: an arbitrary oracle may
compute a difficult predicate and emit one bit while having only two final residual labels. To
turn (31.3) into a machine lower bound, the hidden transition mechanism itself must be charged
through Proposition 30 or an equivalent computational model.

The theorem uses acceptance residuals because the local-PRG interface tests only the final
language decision. If equality of future messages, addresses, timing, or oracle transcripts is
needed, replace \(F_C\) by full-trace residuals; the same right-congruence proof applies with a
possibly larger \(R\).

## Scope

Proposition 31 does not prove \(P\ne NP\), and it does not rule out a source-dependent oracle
preloaded before the scan. It converts every causally generated hidden escape into an explicit
residual-complexity term that can be attacked by a later computational lower bound.
