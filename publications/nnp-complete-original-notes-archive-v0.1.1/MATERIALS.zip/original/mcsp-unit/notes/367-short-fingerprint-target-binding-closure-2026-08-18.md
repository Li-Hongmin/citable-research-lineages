> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Short-fingerprint target-binding closure (2026-08-18)

## Decision

Whole-word common-witness payment is not the only way to close a shared-proof
construction. A strictly weaker interface already suffices: if a common proof
locally decodes an injective, separated **short fingerprint** of the target, and
the candidate target word is publicly evaluable, then sampling the fingerprint
recovers the target index and gives a relaxed local decoder for the whole target
family. The proof never decodes the target history itself.

Thus a proposed non-history target-binding mechanism has an exact new test. It
must either (i) provide no injective separated fingerprint, (ii) make candidate
evaluation/list recovery non-address-scale, (iii) lose target-relative average
soundness, or (iv) leave the common-proof/fixed-radius model. A short seed is not
an escape when it expands to such a public, separated fingerprint family.

This is a family-level closure theorem. It does not apply to one hardwired RW
instance with no payload family, and it does not claim an unconditional dPCP
impossibility or \(P\ne NP\).

## Interface

Let \(\mathcal M\) be a finite message set of size \(L\ge2\), and assume
\(|\Lambda|\ge2\). Each message \(m\) has
an injective target word

\[
  Y(m)\in\{0,1\}^{K},
\]

and a common-address proof

\[
  \Pi(m)\in\Sigma^{P}.
\]

The target word is the object whose coordinates are to be reconstructed. Let

\[
  \phi:\mathcal M\longrightarrow\Lambda^{R}
\]

be a public fingerprint map with relative distance

\[
  \Delta_\phi:=\min_{m\ne m'}
       \frac1R\bigl|\{j:\phi(m)_j\ne\phi(m')_j\}\bigr|>0.
\tag{367.1}
\]

For every fingerprint coordinate \(j\in[R]\), let \(D_j\) be a randomized
adaptive decoder making at most \(q\) queries to the same proof address space and
outputting a symbol in \(\Lambda\cup\{\bot\}\). The symbol \(\bot\) counts as an
error. Assume:

1. **Fingerprint completeness.** For every \(m,j\),
   \[
     \Pr[D_j^{\Pi(m)}=\phi(m)_j]=1.
   \tag{367.2}
   \]

2. **Target-relative average fingerprint soundness.** There are
   \(\rho>0\) and \(0\le\varepsilon<\Delta_\phi/2\) such that, for every \(m\)
   and every \(z\in\Sigma^P\) with \(d_H(z,\Pi(m))\le\rho P\),
   \[
     \frac1R\sum_{j=1}^{R}
       \Pr[D_j^{z}\ne\phi(m)_j]\le\varepsilon .
   \tag{367.3}
   \]

3. **Public candidate evaluation.** Given \(m\) and a requested target
   coordinate \(i\), the values \(\phi(m)_j\) and \(Y(m)_i\) are computable without
   proof queries. Brute-force evaluation over all \(L\) candidates is allowed
   when \(L\) is polynomial in the intended address scale. For larger \(L\), it
   is enough to assume an address-scale list-recovery/argmax procedure on sampled
   fingerprint symbols.

The key point is that \(D_j\) decodes only \(\phi(m)_j\), not \(Y(m)\) and not a
computation history.

## Theorem (short-fingerprint closure)

Under the interface above, fix \(0<\eta<1/2\) and put

\[
  g:=\Delta_\phi-2\varepsilon,
  \qquad
  s:=\left\lceil
       \frac{8\ln(2L/\eta)}{g^2}
      \right\rceil .
\tag{367.4}
\]

The proof map \(m\mapsto\Pi(m)\) is a \(\Sigma\)-ary locally decodable code for the
message \(Y(m)\) at relative radius \(\rho\), with adaptive locality at most

\[
  Q=sq
   =O\!\left(
      q\,\frac{\log(L/\eta)}{(\Delta_\phi-2\varepsilon)^2}
     \right).
\tag{367.5}
\]

On input coordinate \(i\), sample independent \(J_1,\ldots,J_s\) uniformly from
\([R]\), run \(D_{J_t}\) on the proof, and score each candidate \(a\in\mathcal M\)
by

\[
  A_a:=\frac1s\sum_{t=1}^s
     \mathbf 1[D_{J_t}^z=\phi(a)_{J_t}].
\tag{367.6}
\]

Return \(Y(\widehat m)_i\), where \(\widehat m\) is the highest-scoring
candidate (ties are arbitrary). If public candidate evaluation is only supplied
through a list-recovery algorithm, replace the exhaustive score scan by that
algorithm followed by the same fresh-sample scoring on its output list.

## Proof

Fix a target \(m\) and a proof \(z\) in its \(\rho\)-neighborhood. Let \(J\) be
uniform on \([R]\) and write \(W=D_J^z\). By (367.3),

\[
  \Pr[W\ne\phi(m)_J]\le\varepsilon,
  \qquad
  \mathbb E\,\mathbf 1[W=\phi(m)_J]\ge1-\varepsilon .
\tag{367.7}
\]

For \(a\ne m\), on the event \(W=\phi(m)_J\) the candidate \(a\) agrees only
when \(\phi(a)_J=\phi(m)_J\), which has probability at most \(1-\Delta_\phi\).
On the error event it can agree with probability at most one. Hence

\[
  \mathbb E\,\mathbf 1[W=\phi(a)_J]
    \le 1-\Delta_\phi+\varepsilon .
\tag{367.8}
\]

The true candidate's expectation is at least \(1-\varepsilon\), so the gap
between it and every wrong candidate is at least \(g\). Hoeffding's inequality,
with deviation \(g/4\), and a union bound over the \(L\) candidates show that all
empirical scores are within \(g/4\) of their expectations except with probability
at most \(\eta\), for the value of \(s\) in (367.4). On this event \(m\) is the
unique highest-scoring candidate, and the decoder returns \(Y(m)_i\).

It remains to verify code distance. Suppose \(m\ne m'\) and
\(d_H(\Pi(m),\Pi(m'))\le\rho P\). Apply (367.3) with target \(m\) and
\(z=\Pi(m')\). By (367.2), \(D_j^{\Pi(m')}=\phi(m')_j\), so the left side of
(367.3) is exactly the relative distance between \(\phi(m)\) and
\(\phi(m')\), at least \(\Delta_\phi\). This contradicts
\(\varepsilon<\Delta_\phi\). Therefore

\[
  d_H(\Pi(m),\Pi(m'))>\rho P
  \qquad(m\ne m').
\tag{367.9}
\]

The proof map is consequently injective and the decoder above has positive-radius
local correctness for every message coordinate \(Y(m)_i\). This is precisely a
relaxed (indeed, bounded-error) local decoder for the target family. The query
bound is (367.5), and public evaluation contributes no proof queries. \(\square\)

## Information payment and exact escapes

Since \(\phi\) is injective and its alphabet has size \(|\Lambda|\),

\[
  L\le |\Lambda|^R,
  \qquad
  R\ge\frac{\log_2 L}{\log_2|\Lambda|}.
\tag{367.10}
\]

Thus a payload family of size \(2^h\) requires a fingerprint of length
\(\Omega(h/\log|\Lambda|)\), even though the fingerprint may be much shorter than
the target/history length \(K\). In the constant-gap regime, (367.5) then charges
\(\Omega(q\log L)\) proof locality before any outer target decoder is used. Any
applicable RLDC/LDC lower bound therefore applies to this construction.

The theorem leaves exactly the following exits:

* **Non-injective or unseparated fingerprint.** Then sampled symbols cannot identify
  a target family; the mechanism has not supplied target binding.
* **Non-public candidate evaluation.** If \(Y(m)_i\) or \(\phi(m)_j\) cannot be
  evaluated/indexed at address scale, the missing target information is in the
  candidate-evaluation procedure. It must be charged as a descriptor/strategy
  package (the static-package and descriptor-information gates), or accepted as a
  model exit.
* **Coordinate-only soundness.** If (367.3) holds with a different fingerprint
  word for each coordinate or query transcript, the score samples need not have a
  common target and the theorem does not apply; this is precisely the phantom-word
  quantifier gap.
* **No common neighborhood.** A proof family with separate address spaces, a
  vanishing radius/gap, or superpolynomial expansion is outside the stated code
  model.

These are structural exits, not proof failures hidden by notation. In particular,
the theorem shows that replacing “decode the whole target” by “decode a short
injective target fingerprint” does not by itself evade the family-level closure.
What remains genuinely open is a non-transcript global coupling that is neither an
injective public fingerprint nor a finite/address-scale package, while still giving
coordinate-robustness for a single hard target.

## Relation to previous closure lemmas

Theorem 3.8B in the address-scale barriers paper recovers a target index by sampling
the full candidate codeword. The present theorem is strictly weaker in its positive
hypothesis: the common proof need only expose a short fingerprint, and no proof
query to a target-word coordinate is required. It therefore isolates the remaining
non-whole-word target-binding route. If that route supplies an injective fingerprint
for a payload family, it is already an RLDC construction and inherits the same
locality/length barriers. If the RW instance is single-target with no payload family,
the theorem intentionally makes no family-level inference.

## Evidence boundary

This is a self-contained sampling and distance argument. It does not assume that
Ren--Williams, Jeřábek--Korten, or GMWZ supply the fingerprint hypotheses, and it does
not promote ordinary dPCP list soundness to (367.3). Establishing (367.3) with a
common fingerprint, or proving that every address-scale relation compiler must fail
one of the four exits above, remains the substantive Closure Theorem program.
