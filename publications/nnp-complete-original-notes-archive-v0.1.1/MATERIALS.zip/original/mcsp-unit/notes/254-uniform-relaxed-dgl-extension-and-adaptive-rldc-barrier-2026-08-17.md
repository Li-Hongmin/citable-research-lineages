> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A uniform relaxed-DGL extension and an adaptive RLDC barrier (2026-08-17)

## Status

This note records a proof-audit candidate for a parameter extension of the relaxed part of
Dall'Agnol--Gur--Lachish (DGL). DGL state their relaxed-LDC application for
constant query complexity. The statement below is **derived here by tracking
their proof**, and is not being attributed to the source paper as a stated
growing-query theorem.

The extension is useful because it avoids the exponential decision-tree loss in
the adaptive-to-nonadaptive compiler. It gives a conditional adaptive barrier
with a \(Q^2\log^2 Q\) denominator rather than a \(2^r\) denominator.

## Uniform relaxed extension

Let \(M\) be a relaxed local algorithm on a binary oracle of length \(N\), with
valid inputs \(V\), query complexity \(\ell=\ell(N)\), error at most \(1/3\),
and two robustness radii bounded below by a fixed positive constant. Let

\[
  Q\le C_0\,\ell\log(\ell+2)
\tag{254.1}
\]

be the query bound after the error-reduction and randomness-reduction steps in
DGL (Claims 5.8--5.9). Assume the parameter regime in which DGL's general
sample theorem (Theorem 6.1) is nontrivial; a convenient binary sufficient
condition is

\[
  Q^3=o(\log N).
\tag{254.2}
\]

Then the two-output construction in DGL Theorem 7.7, with the same proof and
with \(Q\) retained as a parameter, gives a sample-based relaxed local
algorithm with the same valid inputs and sample complexity

\[
  S(N)\le C_1\,2^Q Q\,N^{\,1-1/(2Q^2)}.
\tag{254.3}
\]

The constants depend only on the fixed robustness/error parameters. More
generally, \(2^Q\) in (254.3) is replaced by the alphabet factor

\[
  O(|\Sigma|^Q\log|\Sigma|),
\]

and (254.2) is replaced by the corresponding DGL alphabet-growth condition.

### Why the constant-query restriction can be removed here

The relaxed proof in DGL Theorem 7.7 has three parameter-bearing steps:

1. Claim 5.8 reduces the error to \(1/(16Q)\), increasing locality to
   \(O(\ell\log(16Q))\).
2. Claim 5.9 reduces the randomness support and doubles the error, producing a
   \(Q\)-local algorithm with support size \(O(N\log|\Sigma|/\sigma)\).
3. The proof constructs one sample algorithm for each output bit and combines
   the two algorithms after sharing the sampling stage.

Every estimate in these three steps is uniform in \(Q\). The remaining bounds
are exactly those of DGL Theorem 6.1, whose proof already records the
nontrivial growth restrictions on \(Q\) and \(|\Sigma|\). No step in the
two-output relaxed construction uses \(Q=O(1)\) once those restrictions are
imposed. This yields (254.3). The statement should therefore be read as a
derived parameterized extension, pending a standalone write-up of the DGL
proof with all constants exposed.

The three potentially dangerous terms can be checked explicitly in the binary
case:

* The sampling probability is
  \(p=\Theta(2^Q\log|\Sigma|)\,N^{-1/(2Q^2)}\), so
  \(Q^3=o(\log N)\) implies \(p=o(1)\).
* The largest kernel has relative size at most
  \(O(2^Q Q^2\log|\Sigma|\,N^{-1/Q})\), which is \(o(1)\) under the same
  condition. Thus the fixed positive robustness radius still dominates every
  kernel.
* The two output branches only take a constant-factor union of the error
  events and reuse the same sampling stage. Their thresholds and petal cap are
  polynomial in \(Q\), already absorbed by the displayed \(2^Q Q\) prefactor.

Here is the parameter calculation behind the last sentence. In the notation
of DGL Section 6.2, after the two generic transformations one has

\[
  \sigma=\frac1{8Q},\qquad
  |\widetilde\mu|=\frac{6N\log|\Sigma|}{\sigma},\qquad
  \gamma=48|\Sigma|^Q\log|\Sigma|,
  \qquad p=\gamma N^{-1/(2Q^2)}.
\tag{254.3a}
\]

For the binary specialization, \(\log|\Sigma|=O(1)\), and hence

\[
  \log p\le Q\log 2+O(\log(Q+2))-
                    \frac{\log N}{2Q^2}=-\omega(1),
\tag{254.3b}
\]

because \(Q^3=o(\log N)\). The kernel estimate in DGL Claim 6.2 is

\[
  |K_j|\le \gamma Q^2N^{1-\max\{1,j\}/Q},
  \qquad
  \frac{|K_0|}{N}
    \le O(2^Q Q^2N^{-1/Q})=o(1).
\tag{254.3c}
\]

The latter follows already from \(Q^2=o(\log N)\), which is implied by
(254.2). Thus a fixed positive robustness radius dominates every kernel for
all sufficiently large \(N\).

The Chernoff exponents in Claims 6.4 and 6.5 have the common core

\[
  N^{1-\max\{1,j-1\}/Q}p^j
   =\gamma^jN^{\,1-\max\{1,j-1\}/Q-j/(2Q^2)}
   \ge \gamma^jN^{1/(2Q)},
  \qquad 1\le j\le Q.
\tag{254.3d}
\]

The \(j=1\) branch of Claim 6.5 has an even larger exponent. The source proof
compares these terms with the additive \(\log(20t)\) term using
\(\log t\le \max\{1,j-1\}\log N/Q+1\). Under \(Q^3=o(\log N)\),
\(N^{1/(2Q)}\gg\log N\), so the same comparison is uniform for every
\(1\le j\le Q\). Finally, Claim 6.5 gives per-kernel-assignment error
\(|\Sigma|^{-|K_j|}/(10Q)\); the union over the
\(|\Sigma|^{|K_j|}\) assignments and \(Q\) layers is therefore still at most
\(1/10\), with no hidden constant-query assumption. This is the exact point
at which the variable-\(Q\) extension uses the source proof rather than merely
its constant-query corollary.

These checks are the reason for imposing the stronger but convenient condition
(254.2), rather than silently substituting a growing \(Q\) into the source's
constant-query corollary.

For completeness, (254.2) also implies the two growth hypotheses explicitly
listed after DGL Theorem 6.1. The normalized query count satisfies
\(Q\ge\ell\) and \(Q=O(\ell\log(\ell+2))\), so it gives
\(\ell^3=o(\log N)\), hence
\(\ell=o(\sqrt{\log N/\log\log N})\). For the binary alphabet,
\(\log|\Sigma|=O(1)=o(\log N/\ell^3)\), which is the required
\(|\Sigma|=N^{1/\omega(\ell^3)}\) condition.

### Proof skeleton with variable \(Q\)

The parameterized relaxed step can be written without hiding the
constant-query substitution:

1. Normalize every branch of the amplified algorithm to exactly \(Q\) distinct
   queried positions. Repeated positions can be removed, and dummy queries can
   be appended; this preserves the output distribution.
2. After DGL error and randomness reduction, the error parameter is
   \(\sigma=1/(8Q)\) and the support of the random decision-tree distribution
   has size
   \[
      |\widetilde\mu|=O(N\log|\Sigma|/\sigma)=O(NQ\log|\Sigma|).
   \]
   The sampling parameters in the binary case are
   \[
      \gamma=O(2^Q\log|\Sigma|),\qquad
      p=\gamma N^{-1/(2Q^2)}.
   \]
3. For each output bit \(b\in\{0,1\}\), retain only the description tuples whose
   tree outputs \(b\), and run the Section 6.1 daisy construction on this
   collection. The two constructions share the random sample \(Q_{\rm samp}\).
4. For a valid input with value \(b\), the relaxed completeness condition gives
   the same large honest vote mass used in DGL Claim 6.4. For a robust input
   whose value is \(1-b\), relaxed soundness gives the same small wrong-output
   mass used in DGL Claim 6.5. Those two claims therefore remain valid with
   \(Q\) variable; their thresholds, cap, and kernel bounds are the explicit
   polynomial-in-\(Q\) quantities in Section 6.2.
5. Output \(b\) only when the \(b\)-construction crosses its threshold and the
   opposite construction does not; otherwise output \(\bot\). A union bound over
   the two branches changes only the absolute success/error constants.

The only imported combinatorial ingredients are DGL's daisy partition and
volume lemma. Their hypotheses are exactly the growth conditions verified
above. Thus the relaxed extension is a proof-level parameter substitution,
not an appeal to an unstated black-box growing-query theorem.

### Shared-sampling lemma

The global-decoder step needs one further quantifier, which is sometimes hidden
when the constant-query corollary is quoted. Let \(N_0,N_1\) be the two
sample-based constructions above, built from the same random sample
\(R\subseteq[N]\). On a valid input of value \(b\), the DGL analysis gives

\[
  \Pr[N_b(R)=b]\ge 9/10,
  \qquad
  \Pr[N_{1-b}(R)=1-b]\le 1/10.
\tag{254.12}
\]

On a robust input of value \(1-b\), the roles are reversed. Define the combined
algorithm to output \(b\) only if \(N_b(R)=b\) and
\(N_{1-b}(R)\ne1-b\), and to output \(\bot\) otherwise. Then the combined
algorithm has the same valid inputs, preserves the radius, and changes the
constant error by at most a factor two. Crucially, \(R\) is independent of the
explicit output index: DGL samples every oracle coordinate independently with
the same probability \(p\). The tuple collections and daisy partitions used by
the later enumeration stage may depend on the requested index, but they are
evaluated on this same \(R\). Hence the sampling stage can be reused
simultaneously for all \(k\) message coordinates.

After \(O(\log k)\) independent repetitions, every coordinate is correct on an
exact codeword with probability at least \(1-1/(3k)\). For every fixed
sample-index tape \(R\), the global decoder is a deterministic map from the
at most \(2^S\) sampled binary strings to candidate messages, and therefore
can be correct on at most \(2^S\) different messages. Averaging over \(R\) and
using per-message success at least \(2/3\) gives
\[
  (2/3)2^k\le 2^S,
\]
so \(S\ge k-O(1)\), which is (254.5) up to the harmless additive constant.
No success-rate assumption beyond the first two relaxed-decoding conditions is
used in this counting step.

## Consequence for binary relaxed LDCs

Let \(C:\{0,1\}^k\to\{0,1\}^N\) be a binary relaxed LDC with locality
\(\ell=\ell(k)\), constant positive decoding radius, and constant error. Apply
the extension above and repeat the resulting sample decoder \(O(\log k)\)
times, as in DGL Corollary 7.9, to reduce the error to \(1/(3k)\). The same
sampled coordinates can be reused for all \(k\) message coordinates. The
resulting global decoder reconstructs the entire message with probability at
least \(2/3\) from at most

\[
  C_2\,2^Q Q\log(k+2)\,N^{\,1-1/(2Q^2)}
\tag{254.4}
\]

binary samples. Since there are only \(2^S\) possible sample strings, the
information argument in DGL's proof gives

\[
  k-1\le C_2\,2^Q Q\log(k+2)\,N^{\,1-1/(2Q^2)}.
\tag{254.5}
\]

Equivalently,

\[
  N\ge
  \left(\frac{k-1}{C_2\,2^Q Q\log(k+2)}\right)^{
      \frac{1}{1-1/(2Q^2)}}.
\tag{254.6}
\]

If \(Q^3=o(\log k)\) (and \(N\le k^{O(1)}\), as in the intended
near-linear regime), the prefactor in (254.6) is
\(k^{o(1/Q^2)}\). Hence

\[
  N\ge k^{\,1+\Omega(1/Q^2)}
   = k^{\,1+\Omega(1/(\ell^2\log^2(\ell+2)))}.
\tag{254.7}
\]

The lower bound is weaker than the fixed-query exponential theorems at
\(\ell=1\), but it is materially stronger than expanding an adaptive tree into
\(2^\ell\) nonadaptive query locations.

## Application to RW/JK message-inline reconstruction

Suppose a binary common proof map \(\Pi:\{0,1\}^k\to\{0,1\}^P\) has branch
verifiers of adaptive depth \(r=r(k)\), perfect completeness on the correct
branch, positive target-relative radius, and wrong-branch acceptance at most a
fixed \(\beta<1\). Read the inline message bit \(b\), run only \(V_{i,b}\),
and output \(b\) on acceptance and \(\bot\) otherwise. This is a relaxed local
decoder of locality \(r+1\), with perfect completeness and error at most
\(\beta\). If \(\beta>1/3\), repeat the selected branch a fixed number of times
and accept only if every copy accepts; the resulting locality is

\[
  \ell=t_\beta(r+1),
  \qquad \beta^{t_\beta}\le 1/3.
\tag{254.8}
\]

The derived extension therefore gives, whenever

\[
  \bigl(t_\beta(r+1)\log(t_\beta(r+1)+2)\bigr)^3=o(\log N),
\tag{254.9}
\]

the explicit adaptive barrier (254.6) with

\[
  Q=O\!\left(t_\beta(r+1)\log(t_\beta(r+1)+2)\right).
\tag{254.10}
\]

In particular, in the near-linear regime \(N\le k\log^c k\), if
\(r^3\log^3(r+2)=o(\log k)\) and \(\beta\) is bounded away from \(1\), then

\[
  N\ge
  k^{\,1+\Omega(1/(r^2\log^2(r+2)))}.
\tag{254.11}
\]

This removes the \(2^r\) loss from the earlier decision-tree/GGS route in the
same sublogarithmic locality window.

## Boundary and proof obligation

The extension is not a citation that DGL already proved (254.3)--(254.11).
To promote it from a derived theorem candidate to a finished theorem, one must
write out the relaxed two-output construction with \(Q\) variable and verify:

* the exact DGL growth and alphabet conditions;
* preservation of the valid-input set, radius, and bottom semantics;
* error reduction and shared-sample reuse for all \(k\) coordinates; and
* the information-theoretic global-decoder step with the \(2^Q Q\log k\)
  prefactor.

If this parameter audit fails, the safe published statement remains notes 240
and 242: explicit decision-tree expansion followed by the arbitrary
nonadaptive GGS lower bound. No result here is an unconditional \(P\ne NP\)
theorem.

## Sources

* M. Dall'Agnol, T. Gur, and O. Lachish, *A Structural Theorem for Local
  Algorithms with Applications to Coding, Testing, and Privacy*, ECCC
  TR20-154, Theorem 6.1, Theorem 7.7, Corollaries 7.8--7.9:
  <https://eccc.weizmann.ac.il/report/2020/154/>.
* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for
  Relaxed Locally Decodable Codes via Robust Daisies*, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.
