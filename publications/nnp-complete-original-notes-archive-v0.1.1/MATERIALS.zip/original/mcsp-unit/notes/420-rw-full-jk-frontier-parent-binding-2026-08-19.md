> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW 完整递归 failure frontier 的 whole-parent binding barrier（2026-08-19）

## 本轮改变的判断

C416 只说明在固定 binary serialization、zero prefix 与 contiguous
leftmost-failure 条件下，首个 outsider 若完全没有 parent ancestry，就会迫使
prefix 有小电路。C410/C417 则分别处理有限条 JK half-lift path 与共享
half-lift DAG。剩下的一个更强反驳是：也许首个失败之后，完整的 JK 递归树仍有
很多分散 failure，但这些 failure 的递归前沿足够稀疏，因而可以共同绑定整个
parent。

本 note 对完整的反事实 JK recursion 建立一个严格的 frontier 量词。把 padded
proof 的 top blocks 作为叶子；只有当两个 child block 都已定义且在
$R=\operatorname{Range}(G_k)$ 中时，才向上定义 parent candidate。所有不在
range 中的 leaf 或 defined internal node 构成 failure frontier
$\mathcal F$。从根开始，good node 用一个 canonical inverse seed 作为 terminal，
其 descendant interval 可由 half-lift 生成；bad/undefined internal node 则递归
拆成两个 child。由此得到：

1. terminal 数满足
   \[
   |\mathcal T|\le 1+2H|\mathcal F|.
   \tag{420.1}
   \]
2. 若 $\mathcal F$ 稀疏，则整个 padded proof 的 top-block word、从而 parent
   prefix，有一个由 terminal seeds/payloads 与 canonical half-lifts 组成的小电路；
3. 在 RW stable window 中，若 $\mathcal F$ 只有 polylog 数量，则不能达到
   $\operatorname{CC}(B_i)=\Omega(n_i/\log n_i)$ 的 forcing parent。

这把“首个 outsider 必须 output-attached”提升为一个更强但仍有明确范围的结论：
任何 surviving closure 都必须处理近 object-scale 数量的 recursive non-range
frontier，或给出一个不能编译成 canonical JK half-lift 的真正 global relation。
这里的 $\mathcal F$ 是完整反事实 recursion 的 failure frontier，不是实际 JK
算法在首个失败时暴露的 query 数；两者不能互换。

## 精确定义

固定 $k$ 与 generator

\[
G=G_k:\{0,1\}^{k}\to\{0,1\}^{2k},
\qquad R:=\operatorname{Range}(G).
\]

固定 canonical inverse $p:R\to\{0,1\}^{k}$，满足

\[
p(G(s))=s\qquad(s\in\{0,1\}^{k}).
\tag{420.2}
\]

条件 (420.2) 是本 note 使用 half-lift identity 的必要假设；它特别要求所选
generator 在该 canonical encoding 下可逆。令 padded proof $\Pi^+$ 被补零并切成
$M=2^H$ 个 $2k$-bit top blocks。它们是高度为 $H$ 的完整二叉树的叶子，树根
覆盖整个 padded proof。对每个 node $v$ 写 $I_v$ 表示其连续的 leaf interval。
这里 $\operatorname{half}_0$ 与 $\operatorname{half}_1$ 分别表示一个 $2k$-bit
seed 的左、右 $k$-bit half。

叶 $v$ 的 block $z_v$ 就是 $\Pi^+$ 的对应 top block：若
$z_v\in R$，称 $v$ **good**；否则称 $v$ **bad leaf**。

对 internal node $v$，递归定义：

* 若两个 child 都有 defined block 且都属于 $R$，则定义
  \[
  z_v:=p(z_{v0})\Vert p(z_{v1})\in\{0,1\}^{2k}.
  \tag{420.3}
  \]
  若 $z_v\in R$，称 $v$ **good**；若 $z_v\notin R$，称 $v$
  **bad defined internal node**。
* 若至少一个 child 没有 defined block（这包括 child 已经是 bad defined
  internal node 或其下方存在更早的 failure），则 $v$ **undefined**，不赋予
  $z_v$ 值。

令

\[
\mathcal F:=\{\text{bad leaves}\}\cup
\{\text{bad defined internal nodes}\}.
\tag{420.4}
\]

注意：一个 bad defined internal node 的两个 children 必然已经 defined 且在
$R$ 中，因而两个 children 本身都是 good。一个
undefined node 本身不计入 $\mathcal F$，但它至少有 descendant in
$\mathcal F$。

## 引理 420.1（good subtree expansion）

若 node $v$ good，则 $v$ 的所有 descendants 都 defined 且 good。若 $v$ 是
internal，令 $s_v:=p(z_v)$，则

\[
z_{v\epsilon}=G\bigl(\operatorname{half}_{\epsilon}(s_v)\bigr),
\qquad \epsilon\in\{0,1\},
\tag{420.5}
\]

并且对 $v$ 的任一 descendant，沿其相对路径反复应用

\[
L_0(z):=G(\operatorname{left}_k z),
\qquad
L_1(z):=G(\operatorname{right}_k z)
\tag{420.6}
\]

可得到该 descendant 的实际 block。

### 证明

good internal node 的定义给出两个 child block defined 且在 $R$ 中，并由
(420.3) 有 $s_v=p(z_{v0})\Vert p(z_{v1})$。由 (420.2)，

\[
z_{v\epsilon}=G(p(z_{v\epsilon}))
 =G(\operatorname{half}_{\epsilon}(s_v)),
\]

即 (420.5)。两个 children 因而都是 good（若为 internal，则它们已 defined 且
block 在 $R$ 中；若为 leaf，则按 leaf 定义 good）。对 child 递归即可证明
整个 descendant subtree 都 good，并反复得到 (420.6)。证毕。

## 递归 terminal decomposition

定义 $\operatorname{Dec}(v)$：

* 若 $v$ good，输出一个 **good terminal**
  $(v,s_v=p(z_v))$，不再向下展开；
* 若 $v$ 是 bad leaf，输出一个 **bad-leaf terminal**
  $(v,z_v)$，其中 payload 是该 $2k$-bit block；
* 若 $v$ 是 bad defined internal node 或 undefined internal node，则输出
  $\operatorname{Dec}(v0)\cup\operatorname{Dec}(v1)$。

从 root 运行 $\operatorname{Dec}$，得到 terminal 集合 $\mathcal T$。由
Lemma 420.1，每个 good terminal 的 descendant interval 都由其 seed 唯一生成；
bad-leaf terminal 直接提供对应叶 block。因此这些 disjoint interval 恰好覆盖
所有 top blocks，并可共同恢复 $\Pi^+$ 的任意 prefix。

## 引理 420.2（frontier-to-terminal count）

对 $H\ge1$，有

\[
|\mathcal T|\le 1+2H|\mathcal F|.
\tag{420.7}
\]

### 证明

把 $\operatorname{Dec}$ 中实际被展开的 internal nodes 记为 $A$。这些 node
正是非-good internal nodes。若 $a\in A$ 是 bad defined internal node，则
$a\in\mathcal F$；若 $a$ undefined，则沿一个 undefined child 继续向下，有限
树性保证最终遇到某个 $f\in\mathcal F$。所以每个 $a\in A$ 是至少一个
$f\in\mathcal F$ 的 ancestor。一个 fixed $f$ 至多有 $H+1$ 个 ancestors，
故

\[
|A|\le (H+1)|\mathcal F|\le 2H|\mathcal F|.
\tag{420.8}
\]

$\operatorname{Dec}$ 的展开树是 full binary tree：每个 $a\in A$ 恰有两个
children，而 terminal 是其 leaves。因此 $|\mathcal T|=|A|+1$，结合 (420.8)
即得 (420.7)。若 $\mathcal F=\varnothing$，root 本身 good，等式退化为
$|\mathcal T|=1$。证毕。

## 定理 420.3（full recursive-frontier parent-binding barrier）

令 $B$ 是 $\Pi^+$ 的任意 $b$-bit prefix，$L:=2kM$ 是 padded proof length，
并令

\[
C_G:=|G_k|+k+\lceil\log_2(L+2)\rceil.
\tag{420.9}
\]

在上述 tree model 下，存在一个 fan-in-2 Boolean circuit $C_B$，输入为
$\lceil\log_2(b+2)\rceil$-bit address，输出 $B[a]$，且

\[
\operatorname{CC}(B)
\le
O\!\left(
|\mathcal T|\bigl(HC_G+k+\log(L+2)\bigr)
\right)
\le
O\!\left(
HC_G\bigl(1+H|\mathcal F|\bigr)
\right).
\tag{420.10}
\]

因而，在 forcing regime 且
$\operatorname{CC}(B)/(HC_G)\to\infty$ 时，

\[
|\mathcal F|
 =
\Omega\!\left(
\frac{\operatorname{CC}(B)}{H^2C_G}
\right)
\tag{420.11}
\]

（更精确地，右侧允许减去一个 $O(1/H)$ additive term）。

### 证明

先按 leaf interval 的左右端点排序 $\mathcal T$。每个 terminal $t$ 覆盖一个
连续 interval $I_t$。从输入 address $a$ 计算它所在的 top-block index 和
block offset，并用一个 interval comparator 判断 $a\in I_t$。每个 comparator
及其 one-hot/multiplexer 控制可由 $O(H+\log(L+2))$ 个 gates 实现；把所有
terminal 的控制合计记为同阶成本。

若 $t$ 是 bad-leaf terminal，则把其 $2k$-bit payload 作为常数线接入，并按
offset 读出目标 bit。若 $t$ 是 good terminal，hardwire
$s_t=p(z_t)$ 的 $k$ bits，先计算 $z_t=G(s_t)$；然后根据 address 在
$I_t$ 中的相对 $H$-bit path，逐层应用 (420.6)，直到得到目标 top block，
再读出其中对应 bit。一次 $G$、half selection、固定 wire/address control
的 fan-in-2 实现成本为 $O(C_G)$，故每个 good terminal 的 lift 成本至多
$O(HC_G+k+\log(L+2))$。bad-leaf terminal 的 payload 与 offset 成本不超过
同一个上界。对所有 terminals 并联并以 comparator 结果 mux，得到第一项上界。

由 $C_G\ge k+\log(L+2)$ 且 $H\ge1$，第一项为
$O(|\mathcal T|HC_G)$。再代入 (420.7)，得到第二项。若
$\operatorname{CC}(B)/(HC_G)$ 渐近发散，解出 $|\mathcal F|$ 即得 (420.11)。
证毕。

这里的 evaluator 只使用固定 proof 上的 terminal seeds/payloads 作为 hardwired
constants；若一个 proposed closure 把这些信息藏入未计费的 selector 或 descriptor，
则该 selector/descriptor 本身已经携带 parent-scale information，不属于
address-scale closure。

## RW stable-window 推论

在 Ren--Williams stable stage，取 $b_i\asymp n_i$、
$L_i\le T_i^{c_0}$、$T_i=n_i^C$。则

\[
H_i=O(\log(n_i+2)).
\tag{420.12}
\]

若 forcing 下界为

\[
\operatorname{CC}(B_i)\ge c\,\frac{n_i}{\log(n_i+2)}
\tag{420.13}
\]

且 $|G_{k_i}|\le k_i^4$，则只要右端 forcing scale 超过
$H_iC_{G_i}$，定理给出

\[
|\mathcal F_i|
\ge
\Omega\!\left(
\frac{n_i}
{(k_i^4+k_i+\log(n_i+2))\log^3(n_i+2)}
\right).
\tag{420.14}
\]

特别地，在 $k_i^4\gtrsim\log(n_i+2)$ 的常用 polylog-width 区间，

\[
|\mathcal F_i|
\ge
\Omega\!\left(\frac{n_i}{k_i^4\log^3(n_i+2)}\right).
\tag{420.15}
\]

所以一个只有 polylog 数量 failure nodes 的完整 recursive frontier，连同
polylog $k_i$、descriptor 与 address control，必然给出 polylog-size parent
evaluator，与 (420.13) 冲突。任何不支付该 frontier 规模的 closure 必须引入不能
编译为 (420.6) 的 non-half-lift global relation；C417 的 shared-DAG sharing
不能改变本定理的 terminal-count 账本。

## 与现有边界的关系

1. **比 C416 更强的量词。** C416 只定位 first failure 的 output attachment。
   本 note 统计完整反事实 tree 中所有 bad leaves 与 bad defined internal nodes，
   因而可以处理多个分散 failure 共同绑定 parent 的设想。
2. **比 C410/C417 更广的结构。** C410/C417 假设已经选出若干 outsider 并沿
   half-lift 回溯；本 note 直接从整棵递归树的 frontier 做 interval decomposition，
   覆盖任意共享或重复的 canonical half-lift 选择。
3. **不等于实际 query 数。** $|\mathcal F|$ 是由完整 proof 反事实计算出的数学
   failure frontier；真实 JK 过程可能在首个失败时停止，因而不会显式读取全部
   frontier。把 (420.14) 改写成 query lower bound 需要另一个 query-exposure
   theorem，本 note 不提供该定理。
4. **不排除新 global relation。** 关系若直接联合多个 outsider、使用 post-seed
   proof state、非局部 algebraic constraint，且不能展开为 (420.6) 的 terminal
   evaluator，则不在本定理假设内。这正是 Closure Gate 仍然开放的 positive/
   impossibility 接口。
5. **不是 $P\ne NP$。** 这是 fixed-proof、source-specific 的 parent-circuit
   upper bound 与 forcing barrier；它没有证明 RW attachment 存在，也没有把
   singleton proof 偷换成 hidden family，更没有关闭所有 simultaneous dPCP/LDC
   constructions。

## 证据边界与上游

* [C416](416-rw-prefix-first-failure-output-attachment-under-p-equals-np-2026-08-19.md)：
  $P=NP$ 重编译和 prefix-first-failure attachment；
* [C410](410-rw-singleton-jk-lift-parent-binding-circuit-cost-2026-08-19.md)：
  singleton pathwise half-lift payment；
* [C417](417-rw-shared-half-lift-dag-parent-binding-2026-08-19.md)：
  shared half-lift DAG payment；
* Ren--Williams, Theorems 3.1, 3.5, 4.1, 4.3：JK recursion、proof serialization、
  stable parent 与 forcing lower bound。
