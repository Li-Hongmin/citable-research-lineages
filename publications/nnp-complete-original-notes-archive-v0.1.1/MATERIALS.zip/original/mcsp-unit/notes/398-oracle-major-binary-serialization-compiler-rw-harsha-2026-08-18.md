> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Oracle-major binary serialization compiler for RW/Harsha（2026-08-18）

## 判定

C397 的 serialization boundary 可以在 source level 被正面处理：保留
systematic \(\widetilde w\) 前缀，把 Harsha auxiliary proof 的大字母表
\(\Gamma\) 与逐 symbol ECC oracle \(\Upsilon\) 分成两个连续 segment。这个
固定坐标重排不改变 Hamming 距离、ECC consistency check 或 verifier 的查询数；
在 RW 的 field-size 和 domain-size 参数下，global address 到
(oracle, field point, bit offset) 的 map 是 polylog 可计算的。

## Theorem 398.1（serialization compiler）

设 \(\widetilde w\) 是 RW Theorem 3.5 所需的 systematic witness prefix，
\(\Gamma:D\to\{0,1\}^a\) 是 Harsha auxiliary proof oracle，且
\(\Upsilon(i)=E_0(\Gamma(i))\in\{0,1\}^b\)，其中 \(D\) 的点用固定
\(\lambda\)-bit field representation 编号。定义
\[
 \operatorname{Ser}(\widetilde w,\Gamma,\Upsilon)
 :=
 \operatorname{bin}(\widetilde w)\,
 \Vert
 \operatorname{bin}(\Gamma(D))\,
 \Vert
 \operatorname{bin}(\Upsilon(D)),
\tag{398.1}
\]
每个 segment 内按 lexicographic domain order、再按 bit offset 排列。

若各 segment 长度及 \(D\) 的大小可由输入长度的 polylog-time 算术计算，则：

1. 给定 global binary address \(j\)，可以在
   \(\operatorname{poly}(\log|\operatorname{Ser}|,\lambda,\log|D|)\) 时间内确定
   segment、symbol index 和 bit offset，并把 symbol index 解码为其 field-point
   coordinates；
2. Harsha verifier 查询 \(\Gamma(i)\) 和 \(\Upsilon(i)\) 时，只需通过这个 map
   读取相应 bits，并执行原有的
   \(\Upsilon(i)=E_0(\Gamma(i))\) equality check；
3. 该序列化是固定坐标重排/拼接，故 proof Hamming distance、完备性、以及
   binary alphabet-reduction 的 robustness 参数不变；
4. \(\widetilde w\) 仍是整个 proof 的 systematic prefix。若 \(\Upsilon\) segment
   长度大于 \(4k\)，则除 segment 两端至多两个 top-level \(2k\)-blocks 外，
   所有内部 blocks 都满足 C396 的 product-ECC rank bound。

### 证明

对 \(j\) 先与已知 segment endpoints 比较并减法，得到 segment 内偏移；在
\(\Gamma\) 或 \(\Upsilon\) 段中分别除以 \(a\) 或 \(b\) 得 symbol index 与
bit offset。固定 domain enumeration 将 symbol index 写成
\(\lceil\log_{|F|}|D|\rceil\) 个 field coordinates，再用每个 field element 的
\(\lambda\)-bit representation 读出目标位。所有运算只作用于
\(O(\log|\operatorname{Ser}|)\)-bit integers，满足假设的 polylog bound。

Verifier 的原始查询只依赖 oracle type、domain point 和 symbol bit；替换为
(398.1) 的逆 map 后读取完全相同的 symbol bits，故 equality check 与查询数不变。
(398.1) 只是坐标重排和 segment 拼接，Hamming distance invariant 给出鲁棒性保持。
systematic \(\widetilde w\) 从未移动。最后，长度大于 \(4k\) 的 segment 至少含有
内部 top-level blocks；这些 blocks 直接应用 C396。证毕。

## RW 参数与边界

在 RW Theorem 3.4--4.1 的实例中，\(|F|=\operatorname{polylog}(t)\)、
\(\lambda=\log|F|=O(\log\log t)\)，而 \(m=O(\log t/\log\log t)\)；field-domain
enumerations 和 segment lengths 的 binary arithmetic 因而都在
\(\operatorname{polylog}(t)\) 时间内。该结论把 C397 的“coordinate map 未指定”
升级为一个显式可实现的 source serialization branch。

但它仍不等于 published RW Theorem 4.1 的既定 proof format：需要重新声明
\(\operatorname{Ser}\) 是 canonical proof 的编码，并把 JK 的 top-level block
alignment、\(\widetilde w\) 与 auxiliary segment 的边界纳入定义。C398 也不保证
first failure 必然落在内部 \(\Upsilon\) block；更左的 witness/\(\Gamma\) blocks
可能先失败，actual \(\Gamma_x\) image/entropy 和 singleton parent attachment
仍由 C396/C393 控制。

## 来源

* Ren--Williams, ECCC TR26-118 revision 1, Theorems 3.4--3.5 and 4.1:
  <https://eccc.weizmann.ac.il/report/2026/118/revision/1/download>.
* Harsha thesis, Lemma 2.4.5 and §5.4.3:
  <https://dspace.mit.edu/handle/1721.1/26720>.
* C396--C397：product-ECC rank gate 与 RW binary serialization boundary.
