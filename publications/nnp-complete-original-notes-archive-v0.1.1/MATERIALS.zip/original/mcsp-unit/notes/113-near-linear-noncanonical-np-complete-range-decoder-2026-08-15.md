> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 近线性 noncanonical decoder 的 NP-complete range 基准（2026-08-15）

## 结论

可以显式构造一个固定、uniform 的 decoder family

\[
G_q:\{0,1\}^{q}\longrightarrow\{0,1\}^{2q},
\qquad q=2^{m-1},
\]

满足：

1. \(\lvert G_q\rvert=O(q)\)（固定 fan-in-two 基）；
2. \(G_q\) 非线性且非系统性；
3. 固定 range language

\[
L_G=\bigcup_{m\ge m_0}
\operatorname{Range}(G_{2^{m-1}})
\subseteq\{0,1\}^{2^m}
\]

是 NP-complete。

这不是 \(P\ne NP\) 的证明，也不提供目标
\(\mathcal C_{m,s}\subseteq\operatorname{Range}(G_q)\) coverage。它给出一个可复核的
noncanonical 基准：near-linear decoder 的 range 本身可以具有完整 NP-hardness，困难不必来自
decoder 的语法大小。

## Decoder

令

\[
n_q=\left\lfloor\sqrt{q/16}\right\rfloor,
\qquad
d_q=\binom{n_q}{2}+\left\lceil\log_2(n_q+1)\right\rceil .
\]

对足够大的 \(q\)，有 \(d_q+n_q+1<q\)。把 seed
\(u\in\{0,1\}^q\) 分成：

- 前 \(d_q\) 位 \(X=(E,k)\)：无向图的上三角邻接位和一个二进制整数 \(k\)；
- 接着 \(n_q\) 位 \(w\)：候选顶点集合的指示向量；
- 剩余位：忽略。

定义 verifier bit \(V_q(X,w)\) 为：

\[
V_q(X,w)=1
\Longleftrightarrow
\bigl(|w|=k\bigr)
\land
\bigl(\text{\(w\) 选出的每一对顶点都是 \(X\) 中的边}\bigr).
\tag{1}
\]

令 \(G_q(u)\) 的前 \(q\) 个输出位为

\[
X\,0^{q-d_q},
\]

第 \(q+1\) 个输出位为 \(V_q(X,w)\)，其余 \(q-1\) 个输出位全为零：

\[
G_q(u)
=
\bigl(X\,0^{q-d_q}\bigr)
\ \Vert\
\bigl(V_q(X,w)\,0^{q-1}\bigr).
\tag{2}
\]

验证式 (1) 可用 \(O(n_q^2)\) 个局部门和加法/比较电路实现；复制输入位和常量输出至多再用
\(O(q)\) 个门。因此

\[
\lvert G_q\rvert=O(n_q^2+q)=O(q).
\tag{3}
\]

由于 \(q\) 是 \(m\) 的显式二次幂，\(n_q,d_q\) 和该 gate list 可在 \(O(q\operatorname{polylog}q)\)
时间内统一生成。小于 \(m_0\) 的有限长度可固定定义为全零 decoder。

## Range membership 是 NP-complete

对格式化的 \(d_q\)-bit instance \(X\)，定义 \(2q\)-bit 字符串

\[
\operatorname{Fmt}_q(X)
=
\bigl(X\,0^{q-d_q}\bigr)
\ \Vert\
\bigl(1\,0^{q-1}\bigr).
\tag{4}
\]

由式 (2)，有精确等价：

\[
\operatorname{Fmt}_q(X)\in\operatorname{Range}(G_q)
\Longleftrightarrow
X\text{ 编码的图含有大小为 \(k\) 的 clique}.
\tag{5}
\]

正向：range witness 的前 \(d_q\) 输出位强制其 instance 部分就是 \(X\)，而第 \(q+1\) 位为
\(1\) 强制式 (1) 成立。反向：给定 clique 的指示向量 \(w\)，将它放入 seed 即得到式 (4)。

语言 \(L_G\) 属于 NP：对输入 \(y\)（长度必须是 \(2q\) 且 \(q\) 为二次幂），猜测 \(q\)-bit
seed，按式 (2) 在多项式于 \(|y|\) 的时间内核验 \(G_q(u)=y\)；其他长度直接拒绝。

从 CLIQUE 的标准 padding 归约得到 NP-hardness。给定一个 \(n\)-vertex 图，取最小的二次幂
\(q\) 使 \(n_q\ge n\)，把多余顶点补成孤立点，并保留 \(k\ge2\)；这样 padding 不改变是否存在
\(k\)-clique，且 \(q=O(n^2)\)。输出 \(\operatorname{Fmt}_q(X)\) 的长度为 \(2q=O(n^2)\)。
故

\[
\boxed{L_G\text{ 是 NP-complete}.}
\tag{6}
\]

这里的 NP-hardness 只针对这个固定 noncanonical range language；它不等价于任何 MCSP
coverage，也不蕴含 \(P\ne NP\)。

## 非线性与非系统性

取 \(X\) 为完全图且 \(k=2\)，固定除两个 witness bits 外的 \(w\)-坐标为零，则式 (1) 的输出
限制为 \(w_1\land w_2\)，所以 \(G_q\) 不是 affine map，特别是非线性。

另一方面，seed 的剩余位被 decoder 完全忽略；存在两个不同 seeds 产生相同输出。因此 \(G_q\)
不是 injective。它虽然把 instance \(X\) 的一部分直接复制到输出，属于 partially systematic
的形式，但不是以下意义的 systematic projection：若存在固定 \(J\subseteq[2q]\)、\(|J|=q\)，使

\[
G_q(u)|_J=u\qquad\forall u,
\tag{7}
\]

则 \(G_q\) 必 injective，矛盾。故它排除了 note 086 中的 systematic projection shortcut（即使
允许输入重命名也一样）。

## 对当前 P versus NP 路线的意义

这个构造提供三条严格边界：

1. **近线性规模不排除 range hardness。** \(\lvert G_q\rvert=O(q)\) 与 NP-complete range
   可以同时成立；
2. **range hardness 不等于 coverage。** 本构造只在输出中保留一个显式 verifier bit，完全没有
   覆盖全部 size-\(s_m\) truth tables；
3. **NP-complete range 不等于 \(P\ne NP\)。** 若要得到分离，仍需独立证明这个固定 range
   language 不在 \(P\)（或不在相应的 \(N^{1+o(1)}\) 电路类）。

因此未来若构造出满足 coverage 的 near-linear decoder，不能仅凭“其 range 可能 NP-hard”推进；
关键仍是证明 coverage 与一个可放大的 range/search lower bound 同时成立。反过来，本构造可作为
测试 MMW/PH-local merge 接口的最小 noncanonical 实例：其逐位 evaluator 属于 \(P\)，而 exact
range search 至少包含 NP-complete witness search。

### 证据边界

- 式 (1)--(7) 是本项目的自足构造与 CLIQUE 归约；
- 只使用固定有限完备 fan-in-two 基、允许输入 fanout；
- 不声称已有一般 decoder lower bound，也不声称 \(P\ne NP\)；
- 与 note 111/112 的关系是：note 111 阻断“任意 decoder 都有短 outsider”，note 112
  阻断 coverage 下的短 outsider；本 note 补充一个 range-hard、但不 coverage 的正面基准。
