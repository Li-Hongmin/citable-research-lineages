> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mutual-information mixture to full transcript-ROC closure

## Purpose

The high-confidence theorem in note 274 converts an accept/reject branch into a
one-shot decoder by an explicit fallback.  That conversion has an artificial
numerical frontier: a richer transcript may already contain a better randomized
filter, even when the accept bit alone does not satisfy the fallback inequalities.
The following composition theorem removes that artifact.  It combines the
mutual-information mixture argument with the full transcript ROC viewpoint, and
then applies the relaxed-LDC lower bound without fresh branch resampling.

The theorem is conditional on a **global policy package**.  A package contains,
for every coordinate and both claims, its verifier and its transcript filter.
This is essential: separate target-dependent packages for different coordinates
would reintroduce the phantom-witness quantifier gap.

## Model

Let

\[
  \Pi:\{0,1\}^k\to\Sigma^P,
  \qquad A:=|\Sigma|\ge2,
\]

be one common proof map.  A policy package \(s\) specifies, for every
\((i,b)\in[k]\times\{0,1\}\), a randomized adaptive verifier \(V^s_{i,b}\)
and a measurable filter
\(f^s_{i,b}(\tau)\in[0,1]\).  On visible transcript \(\tau\), the filter
outputs the claim \(b\) with probability \(f^s_{i,b}(\tau)\), and otherwise
outputs \(\bot\).  Each branch makes at most \(r\) proof-symbol queries.

For a target \(m\), define the correct-branch and wrong-branch output
probabilities

\[
 C_{m,i,s}:=\mathbb E[f^s_{i,m_i}(\tau)\mid V^s_{i,m_i}(\Pi(m))],
\]

and, for \(m_i\ne b\),

\[
 W_{m,i,b,s}(z):=
 \mathbb E[f^s_{i,b}(\tau)\mid V^s_{i,b}(z)].
\]

The latter is required for every \(z\) with
\(d_H(z,\Pi(m))\le\rho P\).  Let \(S\mid M=m\) have law \(\mu_m\) on a
standard-Borel package space, let \(\bar\mu=\mathcal L(S)\), and set

\[
 \mathcal D(m,s):=\max\left\{
 \max_i(\alpha-C_{m,i,s})_+,
 \max_{\substack{i,b,z:\ m_i\ne b\\ d_H(z,\Pi(m))\le\rho P}}
       (W_{m,i,b,s}(z)-\beta)_+
 \right\}.
\tag{275.1}
\]

Write

\[
 \bar\delta=\mathbb E_{M,S\sim\mu_M}\mathcal D(M,S),
 \qquad I=I(M;S)\text{ in bits},
 \qquad \tau=\bar\delta+\sqrt{\tfrac{\ln2}{2}I}.
\tag{275.2}
\]

Assume that the displayed maximum is measurable; otherwise all expectations below
are understood as outer expectations, as in the standard-Borel mixture theorem.

## Theorem (full-ROC mixture closure)

Fix desired relaxed-decoder thresholds \(c>s\).  Suppose there is a
\(\Delta>0\) such that

\[
  \tau<\Delta,
  \qquad \alpha-\Delta\ge c,
  \qquad \beta+\Delta\le s,
  \qquad \tau/\Delta\le\tfrac12.
\tag{275.3}
\]

Then a message subfamily \(\mathcal F\subseteq\{0,1\}^k\) of density at least
\(1/2\) has a single target-independent package law \(S\sim\bar\mu\) satisfying

\[
 \mathbb E_{\bar\mu}C_{m,i,S}\ge c,
 \qquad
 \mathbb E_{\bar\mu}W_{m,i,b,S}(z)\le s
\tag{275.4}
\]

for every \(m\in\mathcal F\), every \(i,b\) with \(m_i\ne b\), and every
target-relative \(z\) in the displayed radius ball.  Consequently, after restricting to a shattered
coordinate set \(J\) with \(|J|=(1/2-o(1))k\), the inline proof map gives a
binary adaptive relaxed local decoder with

\[
 q_{\rm bin}=1+\lceil\log_2A\rceil r
\tag{275.5}
\]

queries, radius bounded below by a constant depending only on \(\rho,A\),
completeness at least \(c\), and wrong-output probability at most \(s\).

In particular, with \((c,s)=(2/3,1/3)\), every fixed-alphabet, fixed-locality
construction satisfying (275.1)--(275.3) is subject to the Dall'Agnol--Gur--Lachish
relaxed-LDC length lower bound.  No accept/reject-only inequalities such as
\(\beta+\Delta\le1/3\) or \(2(\alpha-\Delta)-(\beta+\Delta)\ge1\) are needed.

## Proof

For \(\bar D_m:=\mathbb E_{S\sim\bar\mu}\mathcal D(m,S)\), Pinsker, Jensen, and
the mutual-information identity give

\[
 \mathbb E_M\bar D_M
 \le \bar\delta+\mathbb E_M\operatorname{TV}(\mu_M,\bar\mu)
 \le \bar\delta+\sqrt{\tfrac{\ln2}{2}I}=\tau.
\tag{275.6}
\]

Markov gives a family \(\mathcal F\) of density at least
\(1-\tau/\Delta\ge1/2\) on which \(\bar D_m\le\Delta\).  The definition of the
maximum in (275.1), followed by expectation under \(\bar\mu\), is exactly (275.4).
Sauer--Shelah supplies a shattered coordinate set \(J\) of size
\((1/2-o(1))k\).  Choose one representative \(m_u\in\mathcal F\) for each
pattern \(u\in\{0,1\}^J\).

For coordinate \(i\), read the inline bit \(b\), sample one package
\(S\sim\bar\mu\), run \(V^S_{i,b}\) once, and apply \(f^S_{i,b}\).  The first
inequality in (275.4) gives completeness at least \(c\) on the restricted codeword.
If the inline bit is wrong, the second inequality gives wrong output at most \(s\)
on every \(\rho P\)-near proof.  Thus the decoder is already a relaxed local decoder;
there is no resampling or threshold amplification.  If two representatives differ
on coordinate \(i\) but their proof words were within \(\rho P\), applying (275.4)
to the same target-independent law would give both a correct output at least \(c\)
and a wrong output at most \(s\) on the same proof, contradicting \(c>s\).  Hence
the restricted proof map has symbol distance greater than \(\rho P\), and the
\(A\)-ary Singleton bound leaves a constant fraction of the tagged proof suffix.
Binary recoding costs the factor \(\lceil\log_2A\rceil\) in (275.5). \(\square\)

## Corollary (full-ROC defect-or-information lower bound)

Fix \(c>s\), and suppose the coding lower bound rules out
\(P\le k\,\operatorname{polylog}k\) for the resulting fixed-alphabet, fixed-locality
relaxed decoder.  Let

\[
 \gamma:=\min\{\alpha-c,\ s-\beta\}>0.
\tag{275.7}
\]

Then any near-linear common-proof construction carrying a global policy package as
above must satisfy, for all sufficiently large lengths on which the package exists,

\[
 \bar\delta+\sqrt{\tfrac{\ln2}{2}I(M;S)}
 \ \ge\ \frac{\gamma}{2}.
\tag{275.8}
\]

In particular, for the DGL thresholds \(c=2/3\), \(s=1/3\), a package with
\(\alpha>2/3\), \(\beta<1/3\) cannot simultaneously have vanishing robust defect and
vanishing target mutual information while retaining near-linear proof length.

### Proof

If \(\tau<\gamma/2\), choose \(\Delta=2\tau\) when \(\tau>0\), and any
\(0<\Delta<\gamma\) when \(\tau=0\).  Then
\(\tau<\Delta\), \(\tau/\Delta\le1/2\), and
\(\alpha-\Delta\ge c\), \(\beta+\Delta\le s\).  The theorem therefore produces the
forbidden relaxed decoder.  Hence a near-linear construction must have
\(\tau\ge\gamma/2\), which is (275.8). \(\square\)

## Interpretation and boundary

This theorem is a closure result for a stronger interface than raw branch
acceptance: the target-dependent package already contains a full transcript ROC
filter.  It therefore strictly separates two issues:

1. **Statistical closure.** Low mutual information plus a small worst-case robust
   defect forces one target-independent mixture of complete transcript filters.
2. **Construction.** Building those package-level filters from an ordinary dPCP,
   list decoder, or distributional-soundness statement remains a separate problem.

The theorem is not a claim that ordinary coordinatewise/list soundness supplies
the package or its global filter.  If \(S\) has a uniform executable sampler, a
dummy message sampled uniformly from \(\{0,1\}^k\) implements \(\bar\mu\) exactly;
otherwise the conclusion is semantic.  Conversely, if no package law satisfying
(275.3) exists, the full transcript ROC frontier of note 266 identifies the
remaining obstruction; it is not repaired by a more powerful postprocessor.

## Relation to the high-confidence accept/reject theorem

Note 274 starts with an accept/reject branch and constructs a filter by a scalar
fallback.  The present theorem starts after that construction and applies to an
arbitrary visible transcript.  Thus it removes the numerical high-confidence
restriction only by making the missing transcript filter explicit; it does not
claim to construct that filter from weaker dPCP hypotheses.

## Sources

* [Mutual-information mixture closure](273-mutual-information-mixture-closure-to-rldc-2026-08-17.md).
* [Robust ROC frontier for imperfect transcript postprocessing](266-robust-roc-frontier-for-imperfect-transcript-postprocessing-2026-08-19.md).
* [Variable-query relaxed-DGL theorem](255-variable-query-relaxed-dgl-theorem-2026-08-17.md).
