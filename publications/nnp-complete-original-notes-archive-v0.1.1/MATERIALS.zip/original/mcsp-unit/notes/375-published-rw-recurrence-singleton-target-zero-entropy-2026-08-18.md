> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Published RW recurrence is singleton-target at the JK call (2026-08-18)

## 判定

C374 的首块熵门不能直接闭合 Ren--Williams Theorem 4.3 的 published recurrence。
原因不是一个尚未算出的熵参数，而是该递推在每次 Solve 调用中只喂入一个固定
target。

在 Theorem 4.3 的 stage \(i\)，原文固定

\[
x_0=0^{n_0},
\qquad
f_i:\{0,1\}^{n_0}\to\{0,1\}^{T_i},
\]

并定义 \(f_i\) 忽略输入，输出上一阶段的固定 AVOID 字符串

\[
b_i:=\mathrm{BF}_i(G_{n_i})\in\{0,1\}^{2n_i}
\]

再补零到长度 \(T_i\)。随后实际调用的是

\[
\mathrm{Solve}_{f_i}(x_0,G_{n_{i+1}}),
\]

而不是对一族 \(x\in\{0,1\}^{n_0}\) 同时调用。令
\(\Pi_i:=\Pi_{x_0}\) 为这次调用中使用的 canonical PCP proof，并令

\[
Z_i:=\operatorname{pref}_{2n_{i+1}}(\Pi_i).
\]

对 published call 的目标分布 \(M_i\equiv x_0\)，有

\[
\Pr[Z_i=z_i]=1,
\qquad H_\infty(Z_i)=0.
\tag{375.1}
\]

因此 C374 的假设 \(H_\infty(Z_i)>k_i\)（这里
\(k_i=n_{i+1}\)）在该递推上不成立；把 (374.2) 代入 \(h=0\) 只得到平凡的上界，
不能强迫任何目标进入 JK 的 success 分支，也不能产生 descriptor 代价。

## 不能从此推出“全证明族零熵”

上述结论是 **published 调用的 singleton-target 事实**，不是说对所有输入 \(x\) 的完整
proof \(\Pi_x\) 已经被证明相同。Theorem 3.5 的 proof 写成

\[
\Pi_x=(\widetilde w_x,\Pi'_x),
\]

其中 systematic Reed--Muller 部分 \(\widetilde w_x\) 包含 satisfying assignment 的
prefix 和 output field；定理没有给 auxiliary proof \(\Pi'_x\) 任何 range-coverage 或
canonical-selector 条件。即使把 \(f_i\) 的输入人工扩展成全体 \(x\)，已核验的 source-level
事实至多是 decoded output word \(f_i(x)=b_i0^{T_i-2n_i}\) 与 \(x\) 无关；不能据此断言
完整首块 \(\operatorname{pref}_{2k}(\Pi_x)\) 或整个 \(\Pi_x\) 对 \(x\) 不变。

此外，Lemma 3.2 的 \(C_x\) 是按输入 \(x\) 编译的电路。即便机器语义上忽略 \(x\)，原文也
没有给出一个跨 \(x\) 的 auxiliary-proof 统一选择规则。因此把“输出字段固定”升级为
“完整 canonical proof 固定”需要另一个 source-specific theorem，不能作为 C374 的已证
前提。

## 对 Closure 的精确影响

1. **Family gate 暂不触发。** C374 需要一个实际使用的目标族以及同一个 \(G\) 对该族的
   首块 coverage；Theorem 4.3 的递推只提供每层一个 \(x_0\) 和一个 \(\Pi_i\)。
2. **剩余问题回到 single-target。** published source 仍留下 C372 的 solver-success
   parent--child semantic exit、C373 的 JK success fiber，以及 auxiliary/suffix 的
   target-binding 问题；首块熵不能替代这些接口。
3. **若要在 address scale 重新启用 C374，必须新增 family lift。** 至少要构造一族实际
   被同一 JK instance 使用的 canonical proofs，证明其首块 min-entropy 超过 child width，
   并同时给出首块到目标的统一绑定。只有在这些条件成立后，(374.2)--(374.6) 才能成为
   Closure 的 source-specific barrier。

结论是一个 published-source 量词修正与路线关闭，不是一般 dPCP/RLDC 不可能性定理，
也不是 \(P\ne NP\) 证明。

来源：Ren--Williams Theorem 3.5、Lemma 3.2、Theorem 4.1、Theorem 4.3；
[C374](374-rw-first-block-entropy-coverage-gate-2026-08-18.md)、[C372](372-rw-solver-success-semantic-exit-2026-08-18.md)、
[C373](373-jk-success-fiber-parent-binding-cost-2026-08-18.md)。
