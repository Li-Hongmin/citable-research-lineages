> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RRR constant-round delegation logical-scale gate (2026-08-19)

## 结论

设 \(m\) 为 RW 输出对象的逻辑地址长度，故对象尺度为

\[
  N=2^{\Theta(m)}.
  \tag{472.1}
\]

把 Reingold--Guy Rothblum--Ron Rothblum 2016（RRR16）的 published
bounded-space delegation construction 直接实例化到一个 declared、必要时经时钟填充的
object-scale 运行时间

\[
  T_m=2^{\Theta(m)},
  \qquad
  \log T_m\le S_m=m^{O(1)},
  \tag{472.2}
\]

不能同时得到 fixed-PH 接口所需的

\[
  \boxed{\text{常数轮}\quad\land\quad\text{总消息长度 }m^{O(1)}}.
  \tag{472.3}
\]

这是 RRR16 **具体构造的直接实例化门**，不是一般 information-theoretic interactive
proof 下界。式 (472.2) 中的 \(T_m\) 是允许使用的运行时间上界；本结论不把它冒称为
该计算的最优 bit-time 下界。

## RRR16 的构造参数

RRR16 Theorem 7 与 Corollary 8 处理

\[
  n\le T\le \exp(n),
  \qquad
  \log T\le S\le \operatorname{poly}(n),
  \tag{472.4}
\]

其中 \(\delta\in(0,1/2)\) 且
\(\operatorname{poly}(1/\delta)\le\log T\)。以下先取
\(1/\delta\in\mathbb N\)；一般参数取整只改变固定常数，不改变尺度结论。

并给出

\[
  \ell=(1/\delta)^{O(1/\delta)},
  \qquad
  C=T^{O(\delta)}\operatorname{poly}(S).
  \tag{472.5}
\]

仅凭 (472.5) 的大 \(O\) 上界不能推出通信下界。需要回到 Section 2 与 Section 8 的
实际 augmentation。该构造取

\[
  k=T^\delta,
  \qquad
  i_\star=\log_kT=1/\delta.
  \tag{472.6}
\]

一次 augmentation 的首个 prover message 显式给出 \(k-1\) 个中间 configurations
的 low-degree encoding（Figure 7, Step 1）。
若显式采用（必要时 padding 到）\(s_{\rm conf}=\Theta(S)\) bits 的 configuration
representation，则 LDE 的单射性给出该 prover message、因而也给出 total bit
communication 的 construction-level 下界

\[
  M_{\rm aug}\ge (k-1)s_{\rm conf}=\Omega(T^\delta S).
  \tag{472.7}
\]

Proposition 8.5 在第 \(i\) 层使用

\[
  \ell_i=(c/\delta^2)^i;
  \tag{472.8}
\]

故最终层 \(i=i_\star\) 的 construction-level 轮预算为

\[
  \ell_\star=(c/\delta^2)^{1/\delta}.
  \tag{472.9}
\]

Proposition 4.14 的 PCIP-to-IP 转换保留 \((\ell,a)\)，故不改善
(472.7)--(472.9) 所揭示的二端冲突。

## 定理 472.1（RRR16 direct-instantiation gate）

考虑满足 (472.2) 的 declared computation，并直接使用 (472.6)--(472.9) 的 RRR16
construction。

1. 若 \(\ell_\star=O(1)\)，则存在常数 \(\delta_0>0\) 使
   \(\delta\ge\delta_0\)。于是

   \[
     M_{\rm aug}\ge T_m^{\delta_0}S_m=2^{\Omega(m)}.
     \tag{472.10}
   \]

2. 若 \(M_{\rm aug}=m^{O(1)}\)，则由 (472.7)

   \[
     \delta\log T_m=O(\log m),
     \qquad
     \delta=O(\log m/m).
     \tag{472.11}
   \]

   若这一 \(\delta\) 已不满足 RRR16 的 admissibility 条件
   \(\operatorname{poly}(1/\delta)\le\log T_m\)，则 published theorem 不适用；若仍满足，
   则

   \[
   \begin{aligned}
     \log \ell_\star
       &=\frac1\delta\left(\log c+2\log\frac1\delta\right)\\
       &=\Omega(m),
     \qquad
     \ell_\star=2^{\Omega(m)}.
   \end{aligned}
   \tag{472.12}
   \]

因此 RRR16 的 direct object-scale instantiation 不能提供 (472.3)。

### 证明

函数 \(f(\delta)=(c/\delta^2)^{1/\delta}\) 在
\(\delta\downarrow0\) 时趋于无穷；故 \(f(\delta)=O(1)\) 强制
\(\delta\ge\delta_0>0\)，再由
\(T_m=2^{\Theta(m)}\) 与 (472.7) 得 (472.10)。

反向假设 (472.7) 为 \(m^{O(1)}\)。取对数并使用
\(\log T_m=\Theta(m)\) 得 (472.11)。于是

\[
  1/\delta=\Omega(m/\log m),
  \qquad
  \log(1/\delta)=\Omega(\log m),
\]

代入 (472.9) 即得 (472.12)。证毕。

## 2025 batching 改进仍未覆盖 exponential logical-time

Berger--Goyal--Hong--Kalai 2025 Theorem 8 把 unambiguous batching 推进到

\[
  T(n)\le n^{O(\sqrt{\log n/\log\log n})},
  \tag{472.13}
\]

并给出

\[
  \ell=(\log n)^{O(1/\delta)},
  \qquad
  a\le T^\delta S(\log n)^{O(1/\delta^2)}.
  \tag{472.14}
\]

该结果显著扩大 doubly-efficient information-theoretic IP 的时间区间，但在逻辑输入
\(n=\Theta(m)\) 下，(472.13) 仍为 \(2^{o(m)}\)，不覆盖
\(T_m=2^{\Theta(m)}\)。依赖 computational soundness 的 arguments/SNARKs 也不能替代
Closure 所需的无条件 soundness。

## 对 Gate I 的含义

RRR16 消除了一个重要但表面的候选：不能把“bounded-space computation 有常数轮
delegation”直接读成“exponential logical-time computation 有 address-scale PH
surface”。published construction 的递归深度与中间-configuration header 恰好保存了
被压缩的 object scale。

剩余正向目标没有被本定理排除：新的 unconditional、laconic、constant-round IP；不显式
发送 \(T^\delta\) 个 configurations 的新 batch primitive；或直接利用 RW 特有结构的
same-object/global relation。任何新候选仍需逐项计价 common proof、all-address support、
message length、rounds 与 soundness 量词。

## 证据边界

* 严格部分：RRR16 Section 2、Figure 7 与 Section 8 的 \(k=T^\delta\)、
  augmentation configuration header、Proposition 8.5 的层数/轮数，以及由这些公式
  得到的 (472.10)--(472.12)。
* 实例化约定：\(T_m=2^{\Theta(m)}\) 是对已知 object-scale simulation 选取的 declared
  upper bound，可通过 padding 使用；不是未知最优运行时间的下界。
* 范围：只关闭 RRR16 published construction 的直接实例化；不证明所有 interactive
  proofs 都有同样 tradeoff，不证明 \(P\ne NP\)。

## 来源

* Omer Reingold, Guy N. Rothblum, and Ron D. Rothblum,
  *Constant-Round Interactive Proofs for Delegating Computation*, ECCC TR16-061 rev. 2;
  STOC 2016. 重点：Theorem 7, Corollary 8, Sections 2 and 8.
* Bonnie Berger, Rohan Goyal, Matthew M. Hong, and Yael Tauman Kalai,
  *Efficiently Batching Unambiguous Interactive Proofs*, arXiv:2510.19075, 2025,
  Theorem 8.
* [C431 RW logical-scale collapse boundary](431-rw-logical-scale-collapse-boundary-2026-08-19.md)。
* [C455 published RW hard-output forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
* [C471 singleton common-proof support forcing gate](471-rw-singleton-proof-support-forcing-gate-2026-08-19.md)。
