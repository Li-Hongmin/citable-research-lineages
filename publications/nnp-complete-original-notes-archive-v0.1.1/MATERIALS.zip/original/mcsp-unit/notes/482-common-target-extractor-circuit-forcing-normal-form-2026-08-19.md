> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Common-target extractor circuit forcing and static-access normal form (2026-08-19)

## 改变的判断

C480 的 common-target interface 一旦落入标准 Boolean 静态访问语义，就不再需要寻找
新的 generic data-structure lower bound。把 once-published package 固定后，整个
all-address extractor 本身就是 target truth table 的电路。因此最强的一般 forcing 是

\[
  \operatorname{CC}(B)le |E|_Sle |E|,
  \tag{482.1}
\]

而且是尖锐的。显式 ROM/RAM、被计价 cell evaluator 与 raw/materialized hybrid
分别严格回到 C473、C474 与 C481。剩余正攻不能只是换一种标准数据结构；它必须给出
具体的 global/joint relation，并显式计入其 Boolean compilation cost，或者承认离开
Gate-I/P/poly 模型。

## 定理 482.1（common-target extractor circuit forcing）

固定

\[
  B\in\{0,1\}^{N},\qquad
  S\in\{0,1\}^{d},qquad
  m=\lceil\log_2(N+1)\rceil .
  \tag{482.2}
\]

令

\[
  E:\{0,1\}^{d}\times\{0,1\}^{m}\to\{0,1\}
  \tag{482.3}
\]

是一个 fan-in-two Boolean circuit；其 package inputs、target map、control 与 output
logic 全部属于同一被计价电路。若

\[
  E(S,j)=B[j]qquad(\forall j\in[N]),
  \tag{482.4}
\]

则把第一组 inputs 固定为 \(S\) 所得 residual circuit \(E|_S\) 满足

\[
  \operatorname{CC}(B)le |E|_S\le |E|.
  \tag{482.5}
\]

因此在 C455 的 published RW hard lengths 上，若

\[
  \operatorname{CC}(B_n)\ge c\frac{N_n}{\log N_n},
  \tag{482.6}
\]

则每个满足 (482.4) 的共同 extractor 都有

\[
  |E_n|\ge c\frac{N_n}{\log N_n}.
  \tag{482.7}
\]

### 证明

把 \(S\) 的每一位硬接为常量，不增加 gate 数。由 (482.4)，所得 circuit 对每个
address \(j\) 输出 \(B[j]\)，故它是 \(B\) 的 truth-table circuit；(482.5) 由
\(\operatorname{CC}(B)\) 的定义成立。代入 (482.6) 得 (482.7)。证毕。

这个界是尖锐的：取 \(S=\epsilon\)，令 \(E\) 为 \(B\) 的最小 truth-table circuit，
则 \(|E|=\operatorname{CC}(B)\)。所以不存在只由 (482.4) 推出的更强一般
\(|S|\)-下界；信息可以全部硬接入 \(E\)。反向地，把 \(S=B\) 并把 random access
作为未计价 primitive 只能缩小 control，不能缩小 Boolean compilation cost。

若 extractor 随机化，(482.5) 需要一条对所有 addresses 同时正确的共同固定 tape。
量词 \(\forall j\exists\rho_j\) 不够；它与 C480 中的 target-dependent package 一样，
没有形成一个 single-valued all-address circuit。

## 定理 482.2（标准静态访问正规形）

设一个候选接口声称由同一个 finite package \(S\) single-valuedly 恢复 \(B\) 的全部
addresses。则标准静态访问语义至少落入以下一种被计价正规形：

1. **Explicit finite ROM/RAM.** 若 fixed execution 每个 address 至多做 \(q\) 次
   reads，control size 为 \(g\)，所有真实 executions 的 position union 为
   \(L^{\rm act}\)，则 C473 给出
   \[
     \operatorname{CC}(B)
     \le
     O\!\left(g+q|L^{\rm act}|(\ell+a)+\log(N+2)\right).
     \tag{482.8}
   \]
2. **Charged cell evaluator.** 若每个 package cell 由 size \(s_S\) 的共同 address
   evaluator 生成，则 C474 的 read substitution 给出
   \[
     \operatorname{CC}(B)
     \le
     O\!\left(g+qs_S+q(\ell+a)+\log(N+2)\right).
     \tag{482.9}
   \]
3. **Hybrid support/evaluator.** raw 与 materialized-parent reads 任意混合时，分别对
   未计价 support 使用 (482.8)、对被计价 cells 使用 (482.9)，即 C481 的
   raw/materialized trichotomy。
4. **Compiled machine.** 对任何 bounded-word、finite-time machine，只要其静态
   memory access 与 operations 有一个被计价的 fan-in-two compilation
   \(C_{\rm sim}\)，就直接有
   \[
     \operatorname{CC}(B)\le C_{\rm sim}.
     \tag{482.10}
   \]
   具体 polynomial overhead 取决于 RAM semantics，不需要另立数学假设。

除此之外只剩两种逻辑状态：

\[
  \boxed{
  \begin{array}{l}
  \text{unpriced global oracle/cell-probe/unbounded or continuous state},\\
  \text{或 target/challenge-dependent package、bottom、非 single-valued output}.
  \end{array}}
  \tag{482.11}
\]

第一行无法编译为项目使用的 Boolean \(P/\mathrm{poly}\) evaluator，属于明确的 model
exit；第二行违反 C480 的 Gate-I 量词，不是 data-structure escape。

### 证明

前三项分别是 C473、C474、C481 的 transcript-preserving compilation。第四项把
machine 在固定 package 上的 all-address computation 编译为一个 Boolean circuit，
再应用定理 482.1。若某候选不允许这些 compilation，原因必须是 (482.11) 的未计价
primitive 或 Gate-I 量词失败。证毕。

## Published RW/FRI 的定位

对 RW stable stage 的 \(B_i\in\{0,1\}^{2n_i}\)，地址长度为

\[
  m_i=\Theta(\log n_i).
  \tag{482.12}
\]

RW Theorems 3.5/4.1 提供共同 canonical completeness proof 的候选与逐坐标
`Reconf`，但 published bounds 只保证 proof circuit、prefix 与 query procedure 为
\(n_i^{O(1)}\) 尺度；它们没有给出 C480 所需的

\[
  |S_i|+|E_i|=m_i^{O(1)},qquad
  \forall j\ E_i(S_i,j)=B_i[j].
  \tag{482.13}
\]

ordinary FRI 也只给 challenge-dependent oracle 与 random-QUERY acceptance。这个
source mapping 是 C204/C370/C480 已有边界；本 note 的新裁决是：在 (482.13) 真正
成立之前，不再从 generic RAM/ROM representation 寻找免费的第三条路。

## 边界

* 定理 482.1 是 fixed-target circuit forcing，不是一般 data-structure cell-probe
  lower bound。
* 定理 482.2 只分类能否进入 Boolean \(P/\mathrm{poly}\) Closure 的静态访问语义；
  它不排除新的、被完整计价的 global relation。
* 本 note 不证明 RW 已满足 Gate I，也不证明 \(P\ne NP\)。

## 来源

* [C481：materialized-parent/raw-recomputation trichotomy](481-rw-materialized-parent-raw-recomputation-trichotomy-2026-08-19.md)。
* [C480：ordinary FRI common-target extraction separation](480-ordinary-fri-common-target-extraction-separation-2026-08-19.md)。
* [C474：coding-layer/address-scale evaluator dichotomy](474-rw-coding-layer-address-scale-closure-dichotomy-2026-08-19.md)。
* [C473：honest-path support forcing](473-rw-honest-path-support-and-exposed-history-pcpp-gate-2026-08-19.md)。
* [C455：published RW hard-output forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
* Ren and Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin-Arthur Queries*, ECCC TR26-118, Theorems 3.5, 4.1, 4.3:
  <https://eccc.weizmann.ac.il/report/2026/118/>。
