> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW 协变 Solve 分支二择一：单次 outsider 或整轨道 RLDC barrier（2026-08-17）

## 结论

现有 orbit-lift 只说明：**如果**一个单目标接口已经具有 target-independent verifier
和完整的 proof/action covariance，那么它会自动变成 family-level ACRR。这里再把
这个观察接回 Ren--Williams 的实际 Solve/Reconf 分支，得到一个可直接检验的
RW-specific dichotomy：在一个真正协变的输入族上，Solve 的 success/failure 状态在整个轨道
上相同。因此不可能一边只调用一个 \(x_0\)，一边又把其余轨道点当作独立的“可能失败”
来提供额外的 closure entropy。

## 定理（covariant RW branch dichotomy）

令 \(\Gamma\) 是有限群，作用在输入集合 \(X\)、历史字符串空间
\(\{0,1\}^{T}\) 和 AVOID 输出空间 \(\{0,1\}^{2k}\) 上；记三个作用分别为
\(\tau_g,\rho_g,\bar\rho_g\)，且 \(\rho_g,\bar\rho_g\) 是 Hamming isometry。固定一个
输入 \(x_0\)，令 \(\mathcal O=\Gamma x_0\)。设

\[
  f(gx)=\rho_g f(x),
  \qquad
  \bar\rho_g(\operatorname{Range}(G_k))=\operatorname{Range}(G_k)
  \quad(g\in\Gamma).
  \tag{208.1}
\]

假设 RW 的 Solve_f 具有以下协变性：对每个 \(x\in\mathcal O\)，其 success/failure
状态满足

\[
  \operatorname{Succ}_f(gx,G_k)=\operatorname{Succ}_f(x,G_k),
\tag{208.2a}
\]

并且在两边都成功时

\[
  \operatorname{Solve}_f(gx,G_k)
  =\bar\rho_g\operatorname{Solve}_f(x,G_k)
  \tag{208.2}
\]

这里的等式允许算法的固定 canonical tie-breaking 也被
\(\Gamma\) 共轭。再假设在 failure 分支存在 canonical PCP histories \(\Pi_x\)，满足

\[
  \Pi_{gx}=\widetilde\rho_g\Pi_x,
  \tag{208.3}
\]

其中 \(\widetilde\rho_g\) 是同一 proof address space 上的 Hamming isometry。最后假设
Reconf 可以由一组 target-independent verifier \(V_{i,b}\) 表示：对某个固定
\(\rho>0\) 和 \(\alpha>\beta\)，对所有 \(x\in\mathcal O\)、坐标 \(i\) 及声明位 \(b\)，
记 \(p_{i,b}(z)=\Pr[V_{i,b}^{z}=1]\)，并且

\[
\begin{aligned}
  p_{i,f(x)_i}(\Pi_x)&\ge\alpha,\\
  \operatorname{dist}(z,\Pi_x)\le\rho
  &\Longrightarrow p_{i,1-f(x)_i}(z)\le\beta,
\end{aligned}
\tag{208.4}
\]

且这些 verifier 的 query/address semantics 与 (208.3) 协变。则恰有以下两种情形
之一：

1. **Solve 分支：** Solve_f(x_0,G_k) 成功，并输出
   \(y\notin\operatorname{Range}(G_k)\)。由 (208.1)--(208.2)，同一结论对整个
   \(\mathcal O\) 成立；只需运行一次 base call。
2. **Failure 分支：** Solve_f(x,G_k) 对所有 \(x\in\mathcal O\) 失败。此时
   \(x\mapsto\Pi_x\) 是一个 common-address、target-independent、target-relative
   coordinate-robust proof family。若 \(f(\mathcal O)\) 是长度-\(\ell\) 消息的完整
   \(\Gamma\)-orbit，则 \(x\mapsto\Pi_x\) 经阈值化成为 locality

\[
     Q=O\!\left(q(\alpha-\beta)^{-2}\right)
\tag{208.5}
\]

   的正半径 relaxed locally decodable code。任何适用的 family-level RLDC/LDC
   长度下界都因此作用于该 RW failure branch。

特别地，若 \(f(\mathcal O)=\{0,1\}^{\ell}\)，proof alphabet、原始 query 数、\(\rho\)
和 \(\alpha-\beta\) 固定，而 proof 长度处于 near-linear RLDC 窗口，则 failure branch
不可能成立；这时一次 base Solve 必须进入 outsider 分支。

## 证明

由 (208.2)，若 Solve_f(x_0,G_k) 成功，则对任意 \(g\)，输出是
\(\bar\rho_g y\)。由于 \(\bar\rho_g\) 保持 \(\operatorname{Range}(G_k)\) 不变，
\(y\notin\operatorname{Range}(G_k)\) 蕴含
\(\bar\rho_g y\notin\operatorname{Range}(G_k)\)。这给出第一种情形。

若 base call 失败，则 (208.2) 的成功/失败协变性迫使整个轨道都失败；这一步正是
把原 RW proof 中固定 \(x_0\) 的选择提升为全轨道量词，而没有枚举轨道。

在 failure branch，(208.3)--(208.4) 给出同一个 proof address space 上的 family-level
target-relative ACRR。对任意请求坐标 \(i\)，独立重复 \(V_{i,0}\) 与 \(V_{i,1}\)，
估计两个接受率并在阈值 \(\theta=(\alpha+\beta)/2\) 处输出；若没有唯一越过阈值的分支则输出 \(\bot\)。
Hoeffding 不等式给出 (208.5)。

若两个不同轨道消息 \(m\ne m'\) 的 proofs 距离不超过 \(\rho\)，取一个满足
\(m_i\ne m'_i\) 的坐标。以 \(m\) 为目标、\(\Pi_{m'}\) 为候选 near-proof，
(208.4) 给出错误分支至多 \(\beta\)；以 \(m'\) 为目标的完备性给出同一分支至少
\(\alpha\)，矛盾。因此 proof map 有正的相对距离，阈值化 decoder 的 RLDC 量词成立。
证毕。

## 这个二择一改变了什么判断

* **多输入并不会自动增加 actual JK richness。** 如果输入轨道只是通过 (208.1)
  生成，而 Solve 的状态协变，那么整个轨道的 success/failure 只需一次调用即可
  确定；不能把 \(2^{|x|}\) 个独立 failure histories 当成一条实际 history 的
  \(2^k\) 个 tuples。这与 [RW tuple-supply boundary](163-rw-multiinput-tuple-supply-parameter-no-go-2026-08-16.md)
  相容。
* **若 failure branch 真能共用 verifier，family barrier 是自动的。** 需要额外支付
  的不是“再找几个 \(x\)”；真正必须打破的是 target-independent query semantics、
  proof/action covariance、range invariance 或固定正半径。
* **这不是对 RW 的无条件结论。** Theorem 4.1 的原始 Reconf(x,i) 通常把 \(x\)
  写进 query description，且只给 \(k\)-尺度；因此 (208.3)--(208.4) 正是新的
  Gate-I 接口，不是现有 RW theorem 已经提供的性质。

## 适用边界与反例

1. 若 \(\operatorname{Range}(G_k)\) 不保持在 \(\bar\rho_g\) 下，则成功状态不必协变，
   二择一不能使用；这不是一个可忽略的技术条件。
2. 若 verifier 允许每个 \(x\) 使用不同的 descriptor、sheet 或 Merlin strategy，
   (208.4) 的 target-independent 假设失效；这时只能回到 Closure note 的
   descriptor/whole-word/ROM-advice 分支。
3. 若 orbit \(f(\mathcal O)\) 很小，RLDC 消息熵不足以触发 family-level 下界；需要
   full orbit 或另有独立的 target-entropy 估计。
4. 若 \(\rho=0\) 或 \(\alpha-\beta\to0\)，阈值化不产生固定参数 RLDC；这些是实质逃逸，
   不是证明中的常数损失。

## 与现有主线的关系

本定理把 [equivariant orbit lifting](../../rw-jk-succinct-reconstruction/statements/equivariant-orbit-lift-to-family-rldc.md)
的静态 family 结论与 RW Solve/Reconf 的 success/failure 量词接上；它不重复
ROM-advice 计账，也不声称当前 PCP/dPCP 构造满足协变性。若未来能为某个 RW stage
验证 (208.1)--(208.4)，则该 stage 的“只分析 \(x_0\)”策略立即升级为：一次 outsider
或一个可调用 RLDC 下界的整个 failure branch。这是一个可操作的 Closure Gate-I
判据，而不是局部 decoder 失败记录。

## 证据边界

证明只使用群作用、range invariance、同一 proof address space、target-relative
soundness 和标准阈值放大；RLDC 长度障碍通过现有
[radius-to-relaxed-LDC barrier](../../rw-jk-succinct-reconstruction/statements/radius-to-relaxed-ldc-barrier.md)
调用。它不证明 \(P\ne NP\)，也不把现有 Ren--Williams Theorem 4.1 的 q-scale
Reconf 误报成地址尺度接口。
