> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Product linear ECC 的 \(R>1/2\) block-rank gate（2026-08-18）

## 判定

Harsha 的 binary conversion 对每个大字母表符号独立使用
\[
  E_0:\mathbb F_2^a\longrightarrow\mathbb F_2^b,
  \qquad R:=a/b .
\]
因此若选择一个合法的 injective linear code \(E_0\) 且 \(R>1/2\)，其 product code
\(E_0^{\oplus N}\) 在自然的连续 \(b\)-bit codeword serialization 下已经有一个
source-level block-rank 结论；不需要知道 Spielman generator matrix 的细节。

## Theorem 396.1（interior block rank）

令 \(E_0:\mathbb F_2^a\to\mathbb F_2^b\) 是 injective linear code，令
\(R=a/b>1/2\)，并令
\[
  E=E_0^{\oplus N}:\mathbb F_2^{aN}\to\mathbb F_2^{bN}
\]
的输出按 \(N\) 个连续 \(b\)-bit codewords 排列。取一个完全位于该 ECC segment
内部、长度为 \(2k\) 的连续 block \(I\)，并令 \(r(I)\) 是投影
\(E(u)|_I\) 的 rank。则
\[
  r(I)\ \ge\
  a\left\lfloor\frac{2k-2b+2}{b}\right\rfloor
  \ \ge\ 2Rk-3a .
\tag{396.1}
\]
特别地，如果
\[
  k>\frac{3a}{2R-1},
\tag{396.2}
\]
则 \(r(I)>k\)。

### 证明

长度 \(2k\) 的区间在左右两端至多各截断一个 codeword 的至多 \(b-1\)
个坐标，所以至少包含
\(\left\lfloor(2k-2b+2)/b\right\rfloor\) 个完整的 \(b\)-bit codeword。
每个完整 codeword 对其对应的 \(a\)-bit 输入有 rank \(a\)，而不同输入
symbol 的 product coordinates 是直和。因此投影 rank 至少是这些完整
codeword 的 rank 之和，得到第一项。再用
\(\lfloor x\rfloor\ge x-1\) 和 \(R=a/b\) 得第二项；(396.2) 正好使
\(2Rk-3a>k\)。证毕。

## Corollary 396.2（uniform payload 的 outsider mass）

在 Theorem 396.1 的条件下，任意 \(G_k:\{0,1\}^k\to\{0,1\}^{2k}\) 的 range
至多 \(2^k\)。若 payload \(u\) 在 \(\mathbb F_2^{aN}\) 上均匀，且
\(r(I)>k\)，则
\[
  \Pr\!\left[E(u)|_I\in\operatorname{Range}(G_k)\right]
  \le 2^{k-r(I)} ,
\tag{396.3}
\]
所以至少 \(1-2^{k-r(I)}\) 的 payload 在该 block 上是 non-range。该事件与
更左 block 的 tie-break 无关：无论 first failure 是否先发生在别处，整个
word 至少含有一个 outsider block。

## 对 Harsha/RW 的精确边界

Harsha Lemma 2.4.5 与 §5.4.3 只要求 \(b=O(a)\)、常数相对距离和显式
\(O(a)\)-size encoder；C395 已核验 Spielman 提供合法的线性 source。若能在
该 source 中选择固定码率 \(R>1/2\)，并把 \(\Upsilon\) 的 \(b\)-bit
codewords 放入一个连续 proof segment，或给出一个 verifier 可计算的公开
coordinate permutation，那么 (396.1)--(396.3) 关闭了 C394 的
“需要核对具体 projection-rank profile”分支。

这仍不是 published RW Closure Theorem。尚未关闭的量词是：

1. Harsha/RW 的允许 code family 是否明确覆盖 \(R>1/2\)；
2. \(\Upsilon\) segment 的连续/公开置换是否与固定 proof serialization、
   systematic prefix 和 address-scale query map 同时兼容；
3. actual \(\Gamma_x\) payload family 在上述 high-rank projection 上是否有
   足够 image/entropy。Corollary 396.2 只对 uniform full-message family
   直接给出 outsider mass，不能替代 singleton \(x_0\) 的 parent attachment。

因此 C396 把下一步从“分析 Spielman 的矩阵”收缩为一个 source-level
rate/serialization audit，以及 actual \(\Gamma_x\) image 的独立证明；它不声称
\(P\ne NP\) 或所有允许的 ECC 都落入 high-rank 分支。

## 来源

* Harsha thesis, Lemma 2.4.5 and §5.4.3:
  <https://dspace.mit.edu/handle/1721.1/26720>.
* D. A. Spielman, *Linear-time encodable and decodable error-correcting codes*,
  IEEE TIT 42(6), 1996, DOI
  <https://doi.org/10.1109/18.556668>.
* C394--C395：低度 block coverage、线性 ECC source instantiation 与
  projection dichotomy.
