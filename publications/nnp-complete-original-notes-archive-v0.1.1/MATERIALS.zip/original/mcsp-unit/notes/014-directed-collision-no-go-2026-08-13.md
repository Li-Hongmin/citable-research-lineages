> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 定向 affine-collision 势的常数坍缩（2026-08-13）

## 命题

令 (X,Y\subseteq\mathbb F_2^N) 不交，(C=X\times Y)。对每个 cell (c=(x,y))，取随机 affine parity

\[
\ell_{a,b}(z)=a\cdot z+b,
\qquad (a,b)\sim\mathbb F_2^{N+1},
\]

并定义有向单色叶

\[
R_{a,b}=(X\cap\ell_{a,b}^{-1}(0))\times
(Y\cap\ell_{a,b}^{-1}(1)).
\]

对任意 (c=(x,y))，因为 (x\ne y)，两条方程

\[
a\cdot x+b=0,qquad a\cdot y+b=1
\]

独立，所以

\[
\Pr[c\in R_{a,b}]=\frac14.
\tag{1}
\]

现在取任意 collision 三元组 (T\subseteq C) 和 spoiler (s\in C\setminus T)，使 (T\cup\{s\}) 不能整体落入同一 affine-parity 单色叶，并定义

\[
G_{T,s}(R)=\mathbf1_{s\in R}-\mathbf1_{T\subseteq R}.
\tag{2}
\]

对任何 (T) 中固定的一个 cell (c_0)，事件 (T\subseteq R) 蕴含 (c_0\in R)，故

\[
\Pr[T\subseteq R]\le\frac14.
\tag{3}
\]

于是

\[
\boxed{\mathbb E_{a,b}G_{T,s}(R)\ge0.}
\tag{4}
\]

## 对 quasi-additive 证书的后果

对任意非负权重 (\lambda_{T,s}\ge0)，令

\[
K(R)=\sum_{T,s}\lambda_{T,s}G_{T,s}(R).
\]

此前的递归验证给出 (K(V)+K(W)\ge K(R))，且 (K(C)=0)。若 QA 叶约束为

\[
\sum_{c\in R}\phi_c+K(R)\le1
\tag{5}
\]

对每个 affine-parity 单色叶，则对随机 (R_{a,b}) 取平均，利用 (1) 与 (4)：

\[
\frac14\sum_{c\in C}\phi_c+\mathbb E K(R_{a,b})\le1.
\]

因此

\[
\boxed{\sum_{c\in C}\phi_c\le4.}
\tag{6}
\]

该结论甚至不要求 (\phi_c\ge0)。所以所有由“单个 spoiler 减去一个三元组包含事件”构成、且递归性依靠 (\lambda\ge0) 的定向 collision 势，都不能给出超常数 QA 下界；它们对 MCSP 语义也无特殊例外。

## 研究决策

定向 (G_{T,s}) 路线关闭。对称四点势

\[
g(0),g(1),g(2),g(3),g(4)=(0,1,0,-1,0)
\]

不满足上述单细胞支配关系：存在 collision cell (H) 使

\[
\Pr[|H\cap R|=3]>\Pr[|H\cap R|=1],
\]

因此它仍是唯一值得测试的低阶候选。下一步只检验对称四点势是否也能被某个随机叶平均不等式关闭；若能，四点碰撞谱整体移出主线。
