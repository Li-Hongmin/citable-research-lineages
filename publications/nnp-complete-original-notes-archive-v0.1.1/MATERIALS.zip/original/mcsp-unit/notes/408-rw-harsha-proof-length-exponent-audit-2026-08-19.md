> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW/Harsha proof length 的 \(18+o(1)\) 指数边界（2026-08-19）

## 本轮要改变的判断

C379 只保留了 \(\lvert\Pi_x\rvert\le\operatorname{poly}(t)\)，这不足以判断
stable-stage 的 JK 递归尺度。本 note 直接代入 RW Theorem 3.4 的 Harsha
serialization，得到一个更尖锐的 source-level 结论：

* 令 \(N\) 为 Theorem 3.4 所作用的 CIRCUIT-SAT 电路规模，按原文的最小字段
  实例取
  \[
    m=\left\lceil\frac{\log N}{\log\log N}\right\rceil,\qquad
    |F|=\Theta\!\left((mN^{1/m})^3\right).
  \]
* \(\widetilde A:F^m\to F\)、\(P:F^{3m+3}\to F\) 和
  \(\Pi_{\mathrm{ZoS}}:F^{3m+3}\to F^{6m+6}\) 的完整 oracle 表迫使
  大字母表 proof 至少有 \(\Theta(m|F|^{3m+3})\) 个 field symbols。
* 因而在常率二元化 \(b=\Theta(\log|F|)\) 下，
  \[
    |\Pi|=N^{18+o(1)}
  \]
  （若 RW 的 \(C_x\) 规模是 \(N=t^{c_0}\)，则为 \(t^{18c_0+o(1)}\)）。

这不是 \(P\ne NP\) 证明；它把“proof 只是 poly(\(T\))”收紧为一个会直接改变
Gate-I 参数选择的指数边界。

## 定理 408.1（Harsha oracle 表的 source-level 长度）

按 RW Theorem 3.4 proof sketch 的 source representation，完整 proof 至少包含

\[
  \widetilde A:F^m\to F,\qquad
  P:F^{3m+3}\to F,\qquad
  \Pi_{\mathrm{ZoS}}:F^{3m+3}\to F^{6m+6}.
\tag{408.1}
\]

若每个 oracle 的表按 field symbols 显式存储，则其 symbol 数满足

\[
\begin{aligned}
S(N)
&=|F|^m+|F|^{3m+3}+(6m+6)|F|^{3m+3}\\
&=\Theta\!\left(m|F|^{3m+3}\right).
\end{aligned}
\tag{408.2}
\]

在

\[
  m=\left\lceil\frac{\log N}{\log\log N}\right\rceil,
  \qquad
  |F|=\Theta\!\left((mN^{1/m})^3\right),
\tag{408.3}
\]

下，有

\[
  \log_N S(N)=18+o(1).
\tag{408.4}
\]

若 binary alphabet reduction 对每个 field symbol 使用长度
\(b=\Theta(\log|F|)\) 的显式常率 ECC，则

\[
  L_{\mathrm{bin}}(N)
  =\Theta\!\left(S(N)\log|F|\right)
  =N^{18+o(1)}.
\tag{408.5}
\]

### 证明

由 (408.2)，

\[
 \frac{\log S(N)}{\log N}
 =
 (3m+3)\left(
   3\frac{\log m}{\log N}+\frac{3}{m}
 \right)+o(1).
\]

由 \(m=\log N/\log\log N+O(1)\)，有

\[
 \frac{m\log m}{\log N}=1+o(1).
\]

展开上式得到

\[
 9\left(1+\frac1m\right)
 +9\frac{(m+1)\log m}{\log N}
 +o(1)
 =9+9+o(1)=18+o(1).
\]

binary 化只把每个 field symbol 乘以 \(\Theta(\log|F|)\)；该因子为
\(N^{o(1)}\)，不改变指数。证毕。

## 对 published RW stable stage 的直接推论

令 \(t_i\) 是 Theorem 3.5 中 machine-time 参数，令 \(N_i\) 是该 theorem
实际构造的 \(C_x\) 大小。原文只保证 \(N_i\le t_i^{c_0}\)（某个固定常数
\(c_0\)）；因此由定理 408.1，

\[
  |\Pi_i|=N_i^{18+o(1)}
  \le t_i^{18c_0+o(1)}.
\tag{408.6}
\]

在 Theorem 4.3 的 stable relation \(t_i=T_i=k_i=n_{i+1}\) 下，若采用该
source instantiation 的实际 proof，则严格可写为

\[
  L_i=|\Pi_i|=N_i^{18+o(1)}
  \le T_i^{18c_0+o(1)}.
\tag{408.7}
\]

只有在额外核验 \(N_i=\Theta(T_i^{c_0})\) 时，(408.7) 才能升级为
\(L_i=T_i^{18c_0+o(1)}\)；取最小字段实例且 \(N_i=\Theta(T_i)\) 时为
\(T_i^{18+o(1)}\)。一般情形的递归参数应保留为

\[
  h_i
  =\left\lceil\log_2(L_i/k_i)\right\rceil
  =\left\lceil\log_2\frac{N_i^{18+o(1)}}{T_i}\right\rceil,
\tag{408.8}
\]

而 top-level \(2k_i\)-bit blocks 的数量为

\[
  \frac{L_i}{2k_i}
  =\frac{N_i^{18+o(1)}}{2T_i}.
\tag{408.9}
\]

这严格排除了一个常见误读：\(T_i=k_i\) 并不意味着 JK 看到的 proof 长度为
\(k_i\)，也不意味着 trivial easy branch 自动触发。只要实际 \(N_i\) 满足
\(N_i^{18}\gg T_i\)，按 Harsha 表就需要处理超线性数量的 top blocks 和非平凡
递归深度；具体指数必须由 \(C_x\) 的 source construction 再核验。

## 对 Gate-I 的参数含义

### 1. 直接 top-block cover 不够

C398/C400 可以在 source-compatible 的 oracle-major serialization 下覆盖某些
\(\Gamma/\Upsilon\) 内部区段，但 (408.8)--(408.9) 说明这只处理了递归树的
顶层输入。JK 通过一个 block 后，下一层看到的是 canonical preimage 的拼接；
若没有 C401 的 non-output recursive range closure，辅助区段仍可能在更低层先
产生 outsider。

### 2. full-table generation 不是 address-scale random access

Theorem 3.4 的 completeness 只承诺：给定 witness，可以在
\(\operatorname{poly}(N)\) 时间生成完整 proof。它没有承诺一个
\(\operatorname{poly}(\log N)\)-size evaluator，能从一个地址直接生成
\(2k\)-bit block，更没有承诺该 evaluator 对 canonical preimage 递归保持。
所以不能把 (408.5) 的 full-table proof 自动当成 C401 所需的 \(H_{\rm wit}\)。

### 3. 该指数不自动给出不可能性

proof length 大并不单独推出 Range Avoidance 的 recursive cover 不可能：
\(\widetilde A\)、\(P\) 和 \(\Pi_{\mathrm{ZoS}}\) 都有代数结构，某些 block 可能
仍有短的随机访问描述。要得到负面定理，必须进一步证明其 block projection
rank、descriptor entropy 或 preimage product capacity；这正是
C394/C396/C402 的条件接口，而不是 (408.4) 的自动推论。

## 证据边界

* RW Theorem 3.4 proof sketch 明确列出 (408.1)，并说明 proof 由完整 oracle
  tables 组成；
* RW Theorem 3.5 只把 \(C_x\) 大小写成 \(\operatorname{poly}(t)\)，故
  \(c_0\) 必须保留为 source parameter；
* Harsha §5.4.3 的 binary conversion 是逐 symbol ECC，若选常率显式 ECC，
  只引入 \(\Theta(\log|F|)\) 的 \(N^{o(1)}\) 因子；
* 本 note 不声称所有允许的 proof serialization 都必须有 \(18+o(1)\) 指数，
  不把 source proof 的上界冒称为任意新 PCP 的下界，也不证明 \(P\ne NP\)。

因此，C408 的实际作用是把下一步收缩为一个明确的二分：

\[
\boxed{
\text{构造可递归、地址尺度的 Harsha block evaluator}
\quad\text{vs.}\quad
\text{证明其 projection/range/descriptor 代价}
}.
\]
