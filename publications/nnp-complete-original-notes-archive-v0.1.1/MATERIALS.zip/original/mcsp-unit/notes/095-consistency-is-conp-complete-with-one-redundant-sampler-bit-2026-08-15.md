> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 一个冗余采样位已经使 fiber-consistency 达到 coNP-complete（2026-08-15）

## 受限问题

令 \(p=m+1\)，把 sampler 输入写成 \((x,b)\)，其中
\(x\in\{0,1\}^{m}\)、\(b\in\{0,1\}\)，并固定地址输出为

\[
A(x,b)=x.
\tag{1}
\]

因此 \(\operatorname{Full}\) 自动成立。给定任意 fan-in-2 电路
\(B:\{0,1\}^{m+1}\to\{0,1\}\)，定义受限一致性问题

\[
\operatorname{ProjCons}(B)
:\Longleftrightarrow
\forall x,b,b'\quad B(x,b)=B(x,b').
\tag{2}
\]

这正是地址投影 sampler 的 \(\operatorname{Cons}\) 条件。

## 定理

\(\operatorname{ProjCons}\) 是 coNP-complete。

### 属于 coNP

若式 (2) 失败，证书只需给出 \(x,b,b'\)，使
\(B(x,b)\ne B(x,b')\)。电路值可在多项式时间计算，所以补问题属于 NP。

### coNP-hard

给定 CNF 公式 \(\varphi(x)\)，构造

\[
B_\varphi(x,b)=b\land\varphi(x).
\tag{3}
\]

若 \(\varphi\) 不可满足，则 \(B_\varphi\) 恒为 \(0\)，式 (2) 成立。若
\(\varphi(a)=1\) 对某个 \(a\) 成立，则

\[
B_\varphi(a,0)=0,\qquad B_\varphi(a,1)=1,
\]

式 (2) 失败。因此

\[
\operatorname{ProjCons}(B_\varphi)
\quad\Longleftrightarrow\quad
\varphi\text{ 不可满足}.
\tag{4}
\]

从 UNSAT 的多项式归约得到 coNP-hard。证毕。

同一构造可忽略更多冗余位，因此对任意 \(p=m+k\)、\(k\ge1\)，固定
\(A(x,z)=x\) 后的一致性问题仍然 coNP-complete。

## 与 sampler range 的关系

这个定理不直接给 \(\mathsf{SRange}\) 的 range lower bound。它说明的是：

1. \(p=m\) 时，Full 迫使地址为置换，Cons 自动化（note 093）。
2. \(p\ge m+1\) 时，即使地址只是最简单的投影，fiber-consistency 也有 coNP-complete
   的语义内容。
3. \(p=O(\log N)\) 时，note 094 仍可在 truth-table 输入长度 \(N\) 上穷举全部 fiber-pairs，
   所以 range 仍属于 NP；这不与本定理矛盾，因为 range 验证器允许在长度 \(N\) 的
   truth-table 输入上运行 \(N^{O(1)}\) 时间，并可穷举这些 fiber-pairs。
4. \(p=\omega(\log N)\) 时，穷举 \(2^{2p}\) 不再是一般的 \(N^{O(1)}\) 验证。任何试图
   保持 NP 证书的构造都必须提供新的 succinct consistency certificate；本定理表明
   该证书不能只是假设 fiber 一致性“显然”成立。

## 路线裁决

这给出了 sampler 分支的一个精确跳变：

\[
\boxed{
p=m:\ \text{置换端点；}\qquad
p\ge m+1:\ \text{出现 coNP-complete 的一致性障碍。}
}
\tag{5}
\]

它排除了把冗余采样位当作免费压缩的论证，但没有证明
\(\mathsf{SRange}\notin P\)、一般 circuit lower bound 或 \(P\ne NP\)。下一步若继续
\(p=\omega(\log N)\)，必须把一致性证书的具体机制写出来，或直接证明其 range language
的下界。

原文核验日期：2026-08-15。
