> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Representation-to-address black-box barrier (2026-08-18)

## Statement

The scale-complete audit in [note 358](358-rw-scale-complete-closure-audit-2026-08-18.md)
leaves a stable solver branch with an \(N^{O(1)}\)-time evaluator for an \(N\)-bit
object. The following two barriers make precise why this bound cannot be converted to a
\((\log N)^{O(1)}\) address evaluator by a black-box call to the object generator.

### Proposition 1 (streaming black-box lower bound)

Let \(h\in\{0,1\}^{N}\), and let \(\mathsf{Stream}_h\) be an oracle that, on each
invocation, emits the symbols \(h[0],h[1],\ldots,h[N-1]\) in this order and has no
other interface. An exact algorithm that must output \(h[a]\) for an arbitrary address
\(a\in[N]\), using only such invocations, has a worst-case execution with at least \(N\)
observed symbols.

#### Proof

Consider the query \(a=N-1\). An adversary answers \(0\) to every observed symbol. If
the algorithm halts after observing fewer than \(N\) symbols, some final stream position
was not observed. Two tables that agree with all observed answers and differ only at that
unobserved position induce the same transcript but have different correct outputs for the
corresponding address. The algorithm is therefore wrong on one of the two tables. Hence
exact worst-case access requires \(N\) observations. \(\square\)

The proposition is a black-box statement: rerunning a full-table `Solve` procedure is
still a streaming call, so it does not provide random access unless the procedure exposes
additional structure.

### Proposition 2 (counting separation between object and address scales)

Put \(N=2^m\) and \(s_m=2^{m/3}\). For all sufficiently large \(m\), there is a
table \(h_m:\{0,1\}^{m}\to\{0,1\}\) with the following two properties:

1. \(h_m\) has an object-scale \(O(N)\)-size generator: a circuit with \(N\) output
   wires can emit its full truth table on input \(1^m\).
2. No Boolean circuit of size at most \(s_m\), even with \(s_m\) nonuniform advice
   bits dedicated to length \(m\), computes \(h_m\) on all \(m\)-bit addresses.

#### Proof

The number of fan-in-two Boolean circuits of size at most \(s_m\) on \(m\) inputs is at
most

\[
  2^{O(s_m\log(s_m+m))}.
\]

Allowing an arbitrary \(s_m\)-bit advice string multiplies this count by \(2^{s_m}\),
which is still \(2^{2^{m/3}O(m)}\). The number of \(m\)-input Boolean tables is

\[
  2^{2^m}=2^N,
\]

and \(2^{m/3}O(m)=o(2^m)\). Thus, for large \(m\), the represented tables form a
strictly smaller set than all \(h_m\), so one can choose \(h_m\) outside it. Hardwiring
the chosen \(N\) output bits gives an \(O(N)\)-size object-scale generator. \(\square\)

Since every fixed polynomial \(m^c\) is eventually smaller than \(s_m\), the selected
tables have no polynomial-size address evaluator (with polynomial advice) on those
lengths, despite having a linear-size full-table representation. This is a
representation-scale separation, not a claim that the particular RW solver realizes the
selected nonuniform sequence.

## Consequence for RW closure

The two propositions close a specific invalid shortcut:

\[
  \text{stable }N^{O(1)}\text{ generator}
  \;\not\Rightarrow\;
  \text{address-scale }(\log N)^{O(1)}\text{ evaluator}.
\]

Therefore \(P=NP\) can only finish the stable RW branch after a new structural theorem
supplies an address-level relation, such as a single-valued PH acceptance surface, a
random-access self-reduction, or an equivalent succinct block accessor. Merely replacing
the published `Reconf`/`Solve` oracle calls by deterministic (P) procedures preserves
the representation scale \(N_i\) (or \(n_{i+1}\) in RW notation); it does not change the
input length to \(\log N_i\).

This note is a black-box barrier and does not rule out a future RW-specific compression
theorem. It sharpens the stable branch of the five-way audit in note 358: the remaining
positive target must exploit structure of the actual canonical history, not only its
object-scale computability.
