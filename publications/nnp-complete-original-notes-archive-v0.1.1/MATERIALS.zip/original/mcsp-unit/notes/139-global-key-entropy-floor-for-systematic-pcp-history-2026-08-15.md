> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 系统 PCP history 的 global-key 熵下限（2026-08-15）

## 命题

设 \(\operatorname{Enc}\) 是一个 systematic 编码：对每个 \(W\)-bit witness
\(w\)，其编码 \(\operatorname{Enc}(w)\) 在固定前缀中逐位包含 \(w\)。考虑一个统一
global-key evaluator

\[
\mathcal E(K,a)=\operatorname{Enc}(w_K)[a],
\tag{1}
\]

其中 \(K\) 是 \(c\)-bit key，\(a\) 是 proof address；允许任意 deterministic
postprocessing，但不允许额外读取 \(w_K\)。若该 evaluator 对一个 witness family
\(\mathcal W\) 正确，并且不同 \(w\in\mathcal W\) 产生不同 systematic prefix，则

\[
2^c\ge|\mathcal W|,
\qquad
c\ge\log_2|\mathcal W|.
\tag{2}
\]

若 key 不是 bit string 而是一个 gate-list description，令其 description length 为
\(d\)，同样有 \(2^d\ge|\mathcal W|\)；在每槽 \(O(\log d)\) bits 的语法中，这给出

\[
\operatorname{gate\ count}
\ge
\Omega\!\left(\frac{\log|\mathcal W|}{\log d}\right).
\tag{3}
\]

## 证明

若 \(w\ne w'\)，systematic 前缀中存在一个固定地址 \(a\) 使
\(\operatorname{Enc}(w)[a]\ne\operatorname{Enc}(w')[a]\)。因此一个相同的 key
\(K\) 不可能同时代表 \(w,w'\)：由式 (1)，它在同一地址 \(a\) 只能输出一个 bit。
故 \(w\mapsto K\) 必须在 \(\mathcal W\) 上单射，式 (2) 成立。门列表的描述计数
\(2^d\) 给出式 (3)。证毕。

## 对 RW/PCP history 的含义

Ren--Williams Theorem 3.4/3.5 的 Reed--Muller witness encoding 是 systematic 的；
因此若一个 single decoder 想对一个高熵的 witness family 同时提供：

1. 一个共享 global key；
2. 按 proof address 的统一随机访问；
3. 完整编码（包括 auxiliary history 所需的 systematic data）；

则 key 必须承载该 witness family 的 entropy。特别地，可取一个无约束的
Circuit-SAT 实例，使 \(W\)-bit assignment 全部合法；此时
\(|\mathcal W|=2^W\)，故 \(c\ge W\)。若 proof 长度 \(T\) 与 witness 长度同阶，
这排除 \(c=\operatorname{poly}(\log T)\) 的**统一高熵** global-key 方案。

这不是对单一固定 history 的 lower bound。某个特定 \(w^\star\) 可能有很短的
algorithmic description；但必须证明该短 description 由固定 P-uniform machine 从
外部输入产生，不能把 \(w^\star\) 作为 nonuniform advice 隐藏进 key。

## 与 full-JK closure 的组合

note 138 说明 universal full-depth closure 需要
\(s\log s=O(q^2/T)\)。本 note 给出另一侧的必要条件：

\[
\text{若 closure 依赖一个统一 global key 覆盖 }\mathcal W,
\qquad
q\ge \log|\mathcal W|.
\tag{4}
\]

因此“共享 global key”只有两种可能：

- **高熵 family：** 式 (4) 迫使 q 至少达到 witness entropy，不能把 q 压到
  \(\operatorname{poly}(\log T)\)；
- **单一 history：** 可能存在短 key，但必须建立 RW-specific 的 uniform construction，
  且不能再从 generic PCP systematicity 自动得到。

这把 note 138 的剩余正向目标进一步精确为：

\[
\boxed{
\text{为单一 actual history 构造 uniform short key，且证明该 key 不含隐式 witness advice。}
}
\]

## 证据边界

- Ren--Williams, ECCC TR26-118 revision 1, Theorems 3.4--3.5：systematic
  Reed--Muller witness prefix 与 encoded history。
- 式 (2)--(4) 是 injectivity 与描述计数的自足推导；它不排除 single-history
  algorithmic compression，也不声称 \(P\ne NP\)。
