> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha shared-global parameter 的 Closure trichotomy（2026-08-19）

## 本轮改变的判断

note 436 将 Harsha 的正攻收缩到一个看似仍可行的分支：多个 algebraic
line blocks 共享一个 global parameter，并由 tagged recursive inverse 继续通过
JK 的各层。这里还缺一个量词关键点。一个低熵的 shared parameter 可以闭合
auxiliary/non-output stream，但若它同时要生成一个具有 message-scale 自由度的
systematic output，就必须显式支付这些 target bits。否则所谓“共享参数”只是在
output attachment 之前闭合了错误的对象。

下面给出一个 source-family theorem，把这个分支分成三类：

1. shared parameter 覆盖 systematic output，并支付 message-scale target information；
2. shared parameter 只覆盖 auxiliary/non-output blocks，必须另证 output attachment；
3. 输出与辅助流通过不能分解为这种参数化 evaluator 的 non-product global relation，
   必须作为新的机制单独给出。

这不是 published fixed-​x_0 singleton 的不可能性，也不是 \(P\ne NP\) 证明；它
关闭的是把 auxiliary recursive closure 静默升级为 whole-parent Closure Theorem 的
量词跳跃。

## Shared-global line interface

令 \(\mathcal X\) 是一个 canonical proof family。对每个 \(x\in\mathcal X\)，记
\(\Pi_x\) 为固定 serialization 下的 proof，记 \(B(x)\in\{0,1\}^{b}\) 为其中的
systematic output parent。一个 shared-global line interface 由下列数据组成：

* 一个参数 \(\theta_x\in\Theta\)，其中 \(|\Theta|\le 2^s\)；
* 一个 target-dependent descriptor \(\delta_x\in\{0,1\}^{d}\)；
* 一组 target-independent address/line labels \(L\)，其取值只标记要输出的
  block、line、level 和 branch；
* 一个固定 evaluator \(\mathsf E\)，使被声称覆盖的 proof blocks 都由
  \(\mathsf E(\theta_x,\delta_x,L)\) 产生。递归 JK pair blocks 使用同一 \(\theta_x\)
  和同一套 canonical tagged inverse。

“target-independent” 是关键量词：若 line label、sheet index 或 address bank
随 \(x\) 变化，它们必须并入 \(\delta_x\)，不能在 interface 外免费传递。

## 定理 437.1（shared parameter 的 target-information payment）

设 \(X\) 在 \(\mathcal X\) 上均匀，且 \(B(X)\) 的支持大小为 \(2^h\)。若 systematic
output 的全部 \(h\) 个自由 bits 由同一个 evaluator 精确产生，即存在固定函数
\(\mathsf{Out}\) 使

\[
 B(X)=\mathsf{Out}(\theta_X,\delta_X),
\tag{437.1}
\]

则

\[
 \boxed{s+d\ge h.}
\tag{437.2}
\]

若允许另一个 target-dependent label \(J_X\) 作为 evaluator 输入，则必须把其
信息长度 \(r\) 计入 descriptor，得到 \(s+d+r\ge h\)。等价地，在随机变量形式下，

\[
 I(B(X);\theta_X,\delta_X,J_X)\ge H(B(X))=h,
\tag{437.3}
\]

其中右侧的等式使用了 (437.1) 的 exact recovery；若 \(B(X)\) 不是均匀的，
结论替换为 \(H(B(X))\)。

### 证明

由 exact recovery，

\[
 H(B(X)\mid\theta_X,\delta_X,J_X)=0.
\]

因此

\[
 H(B(X))=I(B(X);\theta_X,\delta_X,J_X)
 \le H(\theta_X,\delta_X,J_X)
 \le s+d+r.
\]

把 \(J_X\) 的 \(r\) bits 与 \(\delta_X\) 合并即得 (437.2)。证毕。

## 推论 437.2（Harsha recursive closure 的三分）

考虑 note 436 的 Harsha line-major/product-ECC interface，并假设一个共同的
\(G_k\) 与 canonical tagged inverse 在完整 recursive subtree 上成立。

### (i) 输出也在共同 range 中

若 systematic output blocks 也由同一 shared-global interface 产生，则

\[
 b_{\rm free}\le s+d+r.
\tag{437.4}
\]

在递归 generator 的 seed budget

\[
 s+\ell_{\rm addr}+\tau\le k
\tag{437.5}
\]

下，得到

\[
 b_{\rm free}\le k+d+r.
\tag{437.6}
\]

因此 identity source \(M_{\rm id}(x)=x\) 的 \(b\)-bit output 若要求整个 family
共用 address-scale closure，且 \(d+r=\operatorname{polylog}(b)\)，就不可能把
message-scale systematic parent 隐藏在 Harsha 的低度 shared parameter 中。
这与 note 435 的 \(h\le k+d\) support gate 相容，但这里明确把 line/global
parameter 和未计费的 target-dependent labels 一并纳入量词。

### (ii) shared parameter 只覆盖 auxiliary/non-output stream

若 \(B(x)\) 不由 evaluator 产生，则 (437.2) 不适用；但此时 generator 只证明了

\[
\text{auxiliary recursive closure},
\]

而不是 whole-parent reconstruction。要继续到 RW Closure，仍需一个独立的
first-failure/output-attachment evaluator，并把 path、sheet、descriptor 和
所有 recovered output bits 计入其 address-scale circuit。把 auxiliary 的
canonical inverse 直接称作 \(H_A\in P/\mathrm{poly}\) 不满足这个接口。

### (iii) 非参数化 global relation

若输出与辅助流确实共同闭合，但不存在一组 target-independent labels、短
\(\theta_x\) 和 fixed evaluator 使 (437.1) 成立，则它不属于 shared-global line
branch。剩下的是一个新的 non-product global relation；它必须单独证明 same-proof
consistency、address-scale generation、cover/sheet handling、bottom safety 和
systematic output attachment，不能用 (437.5) 或 note 436 的 leaf theorem 代替。

## 对 fixed-​x_0 singleton 的边界

本定理的 entropy payment 使用一个 \(2^h\)-大小的 source family。published
RW Theorem 4.3 固定 \(x_0\)，此时 \(h=0\)，所以 (437.2) 对 singleton 不产生
非平凡下界。singleton 可能恰好有一个短 \(\theta_{x_0}\)，但仍必须给出该对象的
canonical tagged inverse 和最终 output attachment；不能从 family-level 的低熵
事实反向推出 singleton 的 address-scale evaluator。

同样，若 verifier 直接读取完整 public input \(x\)，那么这些 \(b\) bits 属于
target channel，应计入 \(r\)，而不是称为“共享参数免费知道 output”。

## 对 Closure Program 的结论

在 note 436 的显式 Harsha interface 下，Gate-I 的 shared-global 分支现在可写成

\[
\boxed{
\begin{array}{c}
\text{shared parameter covers output}\Rightarrow\text{message-scale target payment};\\
\text{shared parameter covers auxiliary only}\Rightarrow\text{separate attachment gate};\\
\text{neither}\Rightarrow\text{new non-product global relation/model exit}.
\end{array}}
\]

这是一条 source-family Closure trichotomy。它没有证明 actual published singleton
落入哪一类，也没有排除所有未来的 non-product mechanism；但它阻止了把
“Harsha algebraic leaf cover + shared recursive parameter”误报为最终
Succinct Smart Reconstruction Theorem。

## 证据边界

* note 434：shared low-degree recursive self-describing range closure；
* note 435：systematic-output support gate；
* note 436：Harsha algebraic leaf cover 与 independent-line recursive-depth gate；
* note 411/423：global relation 的 residual-correlation 与 systematic RM prefix
  信息支付。

本 note 只使用有限熵与 exact-recovery 的直接论证；不把 Harsha 原文自动升级为
global serialization、canonical inverse 或 \(P/\mathrm{poly}\) accessor，也不声称
一般 dPCP/RLDC impossibility。
