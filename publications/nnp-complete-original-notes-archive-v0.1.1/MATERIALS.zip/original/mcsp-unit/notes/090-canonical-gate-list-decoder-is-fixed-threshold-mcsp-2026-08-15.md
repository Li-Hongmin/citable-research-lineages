> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Canonical gate-list decoder is fixed-threshold MCSP（2026-08-15）

## 结论

089 的固定 PH-local 解压器框架确实有一个最直接的实例，但这个实例不是新的 hard
language：在固定 truth-table 长度和阈值 schedule 下，它正是固定 slice 的 search-MCSP。

固定 \(m\ge1\)、\(N=2^m\)、阈值 \(s=s(m)\ge1\)，并令 \(\mathsf{Circ}_{m,s}\) 是带一个指定
输出、fan-in 至多二的布尔电路，门数至多 \(s\) 的集合。阈值 schedule \(s(m)\) 假设可由
\(m\) 在 \(\operatorname{poly}(q+m)\) 资源内取得。存在一个固定有限门基、按拓扑顺序排列且可
补零的 gate-list 编码

\[
\operatorname{Enc}_{m,s}:\mathsf{Circ}_{m,s}\hookrightarrow\{0,1\}^{q},
\qquad
q=O\bigl((s+1)\log(m+s+2)+\log(s+1)\bigr),
\tag{1}
\]

其解码器 \(\operatorname{Dec}_{m,s}\) 在无效码上返回一个固定的合法电路
\(C_0\in\mathsf{Circ}_{m,s}\)（例如门基含常数零门时取 \(C_0=0\)）。合法码要求门类型属于固定
有限基、每个来源只指向原始变量或较早的门，
并显式记录门数/输出线；剩余 bits 只作 ignored padding。定义

\[
D^{\mathrm{can}}_{m,s}(u)=TT\bigl(\operatorname{Dec}_{m,s}(u)\bigr)\in\{0,1\}^{N}.
\tag{2}
\]

则：

\[
\operatorname{Range}(D^{\mathrm{can}}_{m,s})
=
\{TT(C):C\in\mathsf{Circ}_{m,s}\}.
\tag{3}
\]

而且 \(D^{\mathrm{can}}_{m,s}(u)_i\) 属于统一的 \(P\) 关系：解析 gate list、把 \(i\) 解码成一个
\(m\)-bit assignment、再按拓扑顺序计算电路即可，时间为 \(\operatorname{poly}(q+m)\)。
因此它满足 note 089 的 PH-local 假设，甚至不需要 PH oracle。

这给出一个重要的路线裁决：

\[
\boxed{
\text{对 canonical gate-list decoder 的 range/search 下界}
\;=\;
\text{对固定阈值 MCSP/search-MCSP 的下界，至多差编码约定。}
}
\tag{4}
\]

所以 089 的 merge 定理为该 decoder 给出的流式和电路上界，本质上是
McKay--Murray--Williams 的 search-MCSP merge 机制的统一重述；它没有绕开 MCSP 的核心难点。

## 编码与范围等式

每个门记录其类型以及至多两个来源。来源要么是 \(m\) 个原始变量之一，要么是此前至多 \(s\)
个门之一，因此每个来源需要 \(a=\lceil\log_2(m+s+c)\rceil\) bits；门类型需要固定的
\(b=\lceil\log_2|\mathcal B|\rceil\) bits。指定输出、门数和尾部 padding 只需
\(O(a+\log(s+1))\) bits。因此可取

\[
q=s(b+2a)+a+\lceil\log_2(s+1)\rceil+O(1),
\tag{1a}
\]

并得到式 (1)。编码和解码都在 \(\operatorname{poly}(q+m)\) 时间内完成。

对任意 \(C\in\mathsf{Circ}_{m,s}\)，其编码 \(u=\operatorname{Enc}_{m,s}(C)\) 满足

\[
D^{\mathrm{can}}_{m,s}(u)=TT(C),
\tag{5}
\]

故右端包含于左端。反向包含由 \(\operatorname{Dec}_{m,s}(u)\in\mathsf{Circ}_{m,s}\) 直接得到；
无效码产生的常数零表已经在右端。于是式 (3) 是等式，不是仅仅的 coverage 包含关系。

逐位评估也不展开 \(N\) 个输出：输入坐标 \(i\) 只有 \(m\) bits，电路值只需沿 gate list
计算一次。令 \(\ell=q+m\)，便有

\[
\operatorname{Bit}_{D^{\mathrm{can}}}(m,s,u,i)
\in P\subseteq PH
\quad\text{并且运行时间为 }\ell^{O(1)}.
\tag{6}
\]

这解释了为什么“逐位局部可计算”本身不是候选 decoder 的困难来源；困难全部转移到从完整
truth table 找到一致的 gate list。

## 与 search-MCSP 的精确对应

固定 \((m,s)\)-slice 定义为

\[
\mathrm{MCSP}_{m,s}^{\mathrm{slice}}
=
\{y\in\{0,1\}^{N}:\exists C\in\mathsf{Circ}_{m,s},\ TT(C)=y\}.
\tag{7}
\]

由式 (3)，

\[
\mathrm{MCSP}_{m,s}^{\mathrm{slice}}
=\operatorname{Range}(D^{\mathrm{can}}_{m,s}).
\tag{8}
\]

定义 validity-restricted search 为：成功时返回满足
\(u\in\operatorname{Valid}_{m,s}\) 且 \(D^{\mathrm{can}}_{m,s}(u)=y\) 的字典序最小 seed，失败时
返回 failure flag。若 search-MCSP 规定输出某个合法 gate list，并采用与
\(\operatorname{Enc}_{m,s}\) 相同的长度、门类型、输入编号和字典序约定，则

\[
\operatorname{SearchRange}^{\mathrm{valid}}_{D^{\mathrm{can}},m,s}(y)
\]

的 success bit 就是式 (7) 的判定，成功时的 seed 就是 canonical search-MCSP 的输出。无效码上
的常数零约定保证 range 等式，但不能把无效 seed 当成 search 输出；因此 validity restriction
是必要的。若另一篇文献使用不同的 gate-list
语法，可由两个固定的 polynomial-time transducer 互相转换；这只引入
\(\operatorname{poly}(q+m)\) 的电路开销，不改变“固定阈值 MCSP”这一对象。

在 note 089 的 prefix-merge 谓词中加入显式的 \(\operatorname{Valid}_{m,s}(z)\) 即可处理这个
restriction。于是其两个条件结论在此实例化为：

\[
P=NP
\Longrightarrow
\mathrm{search\mbox{-}MCSP}_{m,s}^{\mathrm{slice}}
\text{ 有 }\operatorname{poly}(q+m)\text{ 空间/更新时间的单遍算法},
\tag{9}
\]

以及

\[
NP\subseteq P/poly
\Longrightarrow
\mathrm{search\mbox{-}MCSP}_{m,s}^{\mathrm{slice}}
\text{ 有 }N(q+m)^{O(1)}\text{ 大小的多输出电路}.
\tag{10}
\]

这在 MMW 2019 的参数条件下重现其 search-MCSP merge 上界，是同一架构的固定语法特例，而不是
一个新的 decompression theorem。

## 参数边界与 note 086 的一致性

对任意 map 覆盖该 slice，普适的信息下界只是

\[
q\ge\left\lceil\log_2\left|\mathrm{MCSP}_{m,s}^{\mathrm{slice}}\right|\right\rceil.
\tag{11}
\]

只有当

\[
m\ge\log_2(s\log s)+O(1)
\tag{11a}
\]

从而可以嵌入 note 086 使用的 \(\ell\)-variable Lupanov family 时，才可进一步推出：若一个
\(q\)-bit decoder 覆盖所有 size-\(s\) truth tables，则

\[
q=\Omega(s\log s).
\tag{11b}
\]

式 (1) 的 canonical gate-list 语法达到

\[
q=O\bigl((s+1)\log(m+s+2)\bigr).
\tag{12}
\]

因此在 \(m\le s^{O(1)}\) 且式 (11a) 成立的常见 regime，canonical syntax 的上界与该信息
下界同属 \(s\operatorname{polylog}s\) 量级；这不是任意小 \(m\) 的语义下界。继续压缩 seed
不是免费改进：若仍要求覆盖同一 size-\(s\) circuit class，首先要满足式 (11)；在 note 088
的特殊 \(N=2q\) 参数化下，还可再使用其 half-junta saturation endpoint，不能泛化到本节所有
\((m,s)\) slice。

## 对当前路线的裁决

这个实例留下两个互斥的研究方向：

1. **canonical branch**：直接证明固定 slice \(\mathrm{MCSP}_{m,s}^{\mathrm{slice}}\) 或其
   search 版本的超准线性
   lower bound。这是已知 MCSP/magnification 主战场，089 只提供统一接口。
2. **noncanonical branch**：构造与式 (3) 不同的 nonlinear decoder，使 range language 不等于
   MCSP，却仍有 coverage、PH-local evaluation 和 exponent-stable normalized inverse。note 086--088
   已排除 systematic/affine shortcuts 与部分容量端点，但没有给出此分支的构造或 impossibility。

若没有第二分支的额外结构，继续发明新的 gate-list syntax 只是在式 (7) 上做编码重命名，不会改变
P vs NP 的数学难点。下一个可证的目标应是：明确证明某一 noncanonical coverage map 的 range
不是固定阈值 MCSP，或给出它与 MCSP 的严格归约；否则 canonical branch 应直接并入现有 MCSP
文献，而不再单独宣称 decoder 突破。

## 文献边界

原文核验日期：2026-08-15。

- McKay--Murray--Williams, *Weak Lower Bounds on Resource-Bounded Compression Imply Strong
  Separations of Complexity Classes*, STOC 2019：`Circuit-Min-Merge`/`Stream-Merge` 直接处理
  小电路 truth-table 的 search compression。
- Atserias--Müller, *Simple general magnification of circuit lower bounds*, arXiv:2503.24061v2，
  Theorems 9--11、25、27：给出 approximate-MCSP 与 uniform magnification 的新阈值；其 uniform
  结论是条件性的 \(P\ne NP^{\oplus P}\) 路线，不是 canonical exact decoder 的一般
  \(P\ne NP\) 证明。
- Goldberg--Juvekar--Kabanets, ECCC TR26-091 (2026), *Non-Levin NP-Hardness of Implicit MCSP and
  PAC Learning under Few Assumptions*：研究由电路采样的 labeled-example 分布上的 ImpMCSP，
  不是这里的 lexicographic truth-table slice；其 NP-hardness 仍是条件性的 non-Levin 结果。
- Mazor--Pass, ECCC TR24-053 revision 2 (2026), *Gap MCSP is not (Levin) NP-complete in
  Obfustopia*：给出条件性的 Gap-MCSP non-Levin-hardness，不提供 canonical decoder 的
  Range/Search 一般电路下界。

截至本核验日期，canonical fixed truth-table decoder 的一般电路 Range/Search 超线性下界仍为
unknown；上述 MCSP/magnification 结果没有把它变成无条件的 \(P\ne NP\)。

式 (1)--(12) 是本项目的编码与范围等式；它们不声称已有文献中没有同样的规范化写法。该 note
的永久价值是固定对象、量词和参数转换，防止把 canonical MCSP 重参数化误当作新的非 MCSP
decompression problem。
