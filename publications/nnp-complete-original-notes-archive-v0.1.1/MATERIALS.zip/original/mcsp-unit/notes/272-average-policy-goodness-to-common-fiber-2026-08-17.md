> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Average policy-goodness yields a common robust fiber

**Status.** This note closes a narrow but important quantifier gap left by the
mutual-information lift in note 271.  It does **not** turn arbitrary average
acceptance into simultaneous coordinate robustness.  Instead it proves that a
small average mass of policy failures is harmless when the failure event is a
policy-level statement and the selected policy view has small mutual
information with the target.

## 1. Setup

Let \(M\) be uniform on \(\{0,1\}^k\).  Let \(S\) be a standard-Borel
observable policy view (finite and countable views are special cases), and for
each target \(m\), let \(S\sim\mu_m\) be the selected vector.  Assume the
robustness event below is measurable and regular conditional distributions
exist.  There is one common proof map

\[
  \Pi:\{0,1\}^k\to\Sigma^N.
\]

Write \(\mathsf{Rob}(m,s)\) for the full all-coordinate statement that the
fixed vector \(s\) has correct-claim acceptance at least \(\alpha\), wrong-claim
acceptance at most \(\beta<\alpha\) on every target-relative \(\rho N\)-near
proof, and the same proof/address space for all coordinates.  The policy
vector may contain one branch for each coordinate; \(\mathsf{Rob}\) is a
single event, not a separate average over coordinates.

Assume the **average policy-goodness** condition

\[
  \Pr_{S\sim\mu_m}[\mathsf{Rob}(m,S)]\ge 1-\varepsilon
  \qquad\text{for every }m,
  \tag{272.1}
\]

for some \(0\le\varepsilon<1/2\).  Set

\[
  I:=I(M;S).
\]

The point is that (272.1) is stronger than an averaged acceptance inequality:
it says that most selected policies are already valid simultaneous policies.

## 2. Average-to-common-fiber theorem

Define the good event

\[
  G=\mathbf 1[\mathsf{Rob}(M,S)].
\]

Then there is an observable policy value \(s_*\) for which the good fiber

\[
  F_{s_*}:=\{m:\mu_m(s_*)>0\text{ and }\mathsf{Rob}(m,s_*)\}
\]

satisfies

\[
  |F_{s_*}|
  \ge
  2^{\,k-(I+h_2(\varepsilon))/(1-\varepsilon)}.
  \tag{272.2}
\]

Consequently the selected-policy VC/RLDC lift of note 271 applies on one
common robust policy fiber even though a fraction \(\varepsilon\) of the policy
mass may be bad for each target.

### Proof

By (272.1), \(p:=\Pr[G=1]\ge1-\varepsilon\).  Since \(G\) is one bit,

\[
\begin{aligned}
H(M\mid S,G)
  &=H(M\mid S)-I(M;G\mid S)\\
  &\ge k-I-H(G)\\
  &\ge k-I-h_2(\varepsilon).
\end{aligned}
\tag{272.3}
\]

Let \(H_1=H(M\mid S,G=1)\) and \(H_0=H(M\mid S,G=0)\).  Since
\(H_0\le k\),

\[
  pH_1+(1-p)H_0\le pH_1+(1-p)k.
\]

Combining this with (272.3) gives

\[
  H_1\ge k-\frac{I+h_2(\varepsilon)}p
      \ge k-\frac{I+h_2(\varepsilon)}{1-\varepsilon}.
\tag{272.4}
\]

Now average \(H(M\mid S=s,G=1)\) over \(s\) under the conditional law
\(S\mid G=1\).  Some \(s_*\) has conditional entropy at least the right-hand
side of (272.4).  The support of \(M\mid(S=s_*,G=1)\) is exactly \(F_{s_*}\),
and entropy is at most the logarithm of support size.  This proves (272.2).
\(\square\)

## 3. Coding consequence

Let \(d_*\) be the VC dimension of \(F_{s_*}\).  Sauer--Shelah gives

\[
  \sum_{j=0}^{d_*}\binom{k}{j}
  \ge |F_{s_*}|
  \ge 2^{\,k-(I+h_2(\varepsilon))/(1-\varepsilon)}.
\tag{272.5}
\]

Thus, with the effective information deficit

\[
  \Gamma:=\frac{I+h_2(\varepsilon)}{(1-\varepsilon)k},
\]

every fixed \(\Gamma<1\) gives \(d_*\ge(\theta_\Gamma-o(1))k\), where
\(H_2(\theta_\Gamma)=1-\Gamma\).  In particular,

* \(I=o(k)\) and \(\varepsilon=o(1)\) imply \(d_*\ge(1/2-o(1))k\);
* \(I\le\gamma(1-\varepsilon)k\) with fixed \(\gamma<1\) gives
  \(d_*\ge(\theta_\gamma-o(1))k\);
* any sublinear-VC escape requires
  \(I\ge(1-\varepsilon)k-o(k)\), up to the binary entropy term.

On the common fiber, the fixed policy vector \(s_*\) supplies the two claim
branches for every shattered coordinate.  Therefore the RLDC construction and
the GGS length lower bound from note 271 apply with the same query, alphabet,
gap, and radius parameters.  This is an average-to-common-fiber closure
theorem, not a new PCP construction.

## 4. A defect-functional corollary

The hypothesis can be checked from one scalar robust defect, but not from
coordinate averages taken before the worst-case operation.  For a policy \(s\)
define

\[
\mathcal D(m,s):=
\max\!\left\{
\max_i\bigl(\alpha-\operatorname{Comp}_{m,i,s}\bigr)_+,\,
\max_{\substack{i,z:\\d(z,\Pi(m))\le\rho N}}
\bigl(\operatorname{WrongAcc}_{m,i,s}(z)-\beta\bigr)_+
\right\}\in[0,1].
\tag{272.6}
\]

Here \(\operatorname{Comp}\) is correct-claim acceptance and
\(\operatorname{WrongAcc}\) is wrong-claim acceptance.  If, for every target,

\[
\mathbb E_{S\sim\mu_m}\mathcal D(m,S)\le\eta\Delta
\tag{272.7}
\]

and \(0<\Delta<(\alpha-\beta)/2\), then Markov's inequality gives
\(\Pr[\mathcal D(m,S)>\Delta]\le\eta\).  Every policy in the remaining mass is
simultaneously robust with parameters
\[
\alpha'=\alpha-\Delta,\qquad \beta'=\beta+\Delta,
\qquad \alpha'-\beta'=\alpha-\beta-2\Delta>0.
\]
Applying (272.2) with \(\varepsilon=\eta\) therefore yields the same common
fiber and RLDC/GGS conclusion, with the reduced gap \(\alpha'-\beta'\).

This is the exact safe way to turn an averaged statement into the policy-level
event used above: the worst coordinate and worst nearby proof must be taken
*inside* \(\mathcal D\) before averaging over policies.  Averaging each
coordinate or each proof separately does not imply (272.7), and the
phantom-witness counterexamples remain possible.

## 5. Exact boundary

The policy-level event in (272.1) is essential.  A statement only of the form

\[
  \mathbb E_{S\sim\mu_m}[\operatorname{Acc}(m,S)]\ge\alpha,
  \qquad
  \mathbb E_{S\sim\mu_m}[\operatorname{Acc}(\text{wrong},S)]\le\beta
\]

does not imply that any individual \(s\) is robust on the target, let alone on
a common fiber.  It permits policies that trade coordinates or use different
target-dependent witnesses.  The constant-proof construction in note 269 is
an extreme instance of this quantifier failure.  Hence (272.2) should not be
advertised as an upgrade from ordinary average/list soundness; it applies only
after the protocol exposes a well-defined policy-good event.

Finiteness of the observable policy view is not needed: standard-Borel policy
spaces admit the required regular conditional law \(M\mid S=s\).  The proof
uses no bound on the ambient policy universe, and the mutual information
\(I(M;S)\) is the quantity charged for target dependence.  Nonmeasurable or
non-standard interactive strategy objects remain outside the theorem rather
than being silently treated as a finite policy channel.

## 6. Closure-program interpretation

This gives a precise intermediate target for a simultaneous coordinate-robust
PCP.  One may either prove (272.1) for a low-information selected-policy
channel, in which case note 271 and GGS force a near-linear-length barrier, or
show that every purported construction must violate policy-level goodness and
fall back to ordinary distributional/list soundness.  The latter is exactly
where a stronger global-word or coordinate-robust PCP theorem would still be
needed.
