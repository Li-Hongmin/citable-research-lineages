> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Valiant universal circuit 给出的二次 batch-generator 上界（2026-08-15）

## 结果

在固定有限完备 fan-in-two 基和标准 unbounded-fanout wire 模型下，可以把
size-\(s\) 电路的 truth-table generator 做到

\[
\operatorname{size}=O(Ts\log(n+s))
\tag{1}
\]

个门，其中 \(T\) 是要同时输出的 hardwired assignments 数目。这里使用 Valiant
的 universal circuit \(U_{n,s}\)：当 \(n\le s\) 时，它是一个固定组合电路，控制输入
\(c\in\{0,1\}^{r_{n,s}}\) 可编程为任意 \(n\)-input、size-\(s\) 电路，并满足

\[
\lvert U_{n,s}\rvert=O(s\log(n+s)),
\qquad
r_{n,s}=O(s\log(n+s)).
\tag{2}
\]

这里的 \(r_{n,s}\) 包括 universal circuit 所需的 gate-operation、source 和
input/output-selector controls；固定基、拓扑顺序和 dummy-gate padding 约定均并入常数。

文献依据是 Valiant, *Universal circuits (Preliminary Report)*, STOC 1976；这里
只使用其 universal-circuit size upper bound，不把它当作 unrestricted decoder lower bound。

## 批量构造

固定 \(T\) 个 \(n\)-bit assignments
\(a^{(1)},\ldots,a^{(T)}\)。把 \(T\) 个 \(U_{n,s}\) 的 data-input wires
分别硬接到这些 assignments，并共享同一组 control wires \(c\)。得到

\[
\operatorname{Batch}_{n,s,T}(c)
=
\bigl(
U_{n,s}(a^{(1)},c),\ldots,U_{n,s}(a^{(T)},c)
\bigr).
\tag{3}
\]

每个 copy 只复制 universal circuit 的 gates；controls 通过 wire fanout 共享。因此

\[
\lvert\operatorname{Batch}_{n,s,T}\rvert
=O\!\left(Ts\log(n+s)\right).
\tag{4}
\]

即使采用有界 fanout 并显式复制 controls，额外代价至多
\(O(T\,r_{n,s})=O(Ts\log(n+s))\)，仍属于同一上界。

若门基不把常量输入视为免费，硬接 assignment 只增加 \(O(Tn)\) gates；在
\(n\le s\) 时被式 (4) 吸收。

对每个 \(n\)-input、size-\(s\) 电路 \(C\)，Universal-circuit 定理给出一个 control
string \(c_C\)，满足 \(U_{n,s}(x,c_C)=C(x)\)。所以

\[
\{\operatorname{TT}(C):\operatorname{CC}(C)\le s\}
\subseteq
\operatorname{Range}(\operatorname{Batch}_{n,s,2^n}).
\tag{5}
\]

这里的 coverage 只需要控制串存在；Valiant 构造本身不自动给出从任意 gate-list
到 \(c_C\) 的 representation-specific canonical encoder。

## 代入本项目参数

令 \(N=2q=2^m\)，取 \(n=m\)，并选择

\[
s\le \frac{q}{K\log q}
\]

其中 \(K\) 取足够大的固定常数，使 \(r_{m,s}\le q\)。将 control string 零填充到
\(q\) 位（非法 padding 可 totalize 到固定零电路），得到一个

\[
G^{\mathrm{UC}}_q:\{0,1\}^{q}\longrightarrow\{0,1\}^{2q}
\]

的 fixed decoder。由式 (4)：

\[
\lvert G^{\mathrm{UC}}_q\rvert
=O\!\left(2q\cdot s\log(m+s)\right)
=O(q^2).
\tag{6}
\]

式 (5) 则说明它覆盖所有 \(m\)-input、size-\(O(q/\log q)\) truth tables。
若只输出前 \(T=q+1\) 个 assignments，得到同样 coverage-prefix 的
\(O(q^2)\)-size generator。

## 与已有 \(O(q^3)\) PTT 上界的关系

Gajulapalli--Li--Volkovich 的 TR24-049 Lemma 2.15 给出 prefix generator
\(\operatorname{PTT}_{n,s}\) 的 \(O(E^3)\) 上界，其中 \(E=\Theta(s\log s)\)。
式 (4) 用 Valiant universal circuit 将同一接口改进为

\[
O(E^2)
\]

量级（在 \(T=\Theta(E)\) 的 prefix regime；这里采用的是 universal-control
encoding，不声称与 gate-list PTT 是同一个 map）。这是一个真实的上界改进，但不是
\(E\operatorname{polylog}E\)：

\[
\boxed{
O(E^2)\ \text{已可由 universal-circuit batching 得到；}\qquad
E\operatorname{polylog}E\ \text{仍未构造。}
}
\tag{7}
\]

对完整 \(T=2q\) truth table，式 (6) 仍是 \(O(q^2)\)，所以它没有关闭
note 114 指出的 near-linear batch-evaluation 缺口。

## 关键限制

1. **这是 coverage upper bound，不是 range lower bound。**
   \(G^{\mathrm{UC}}_q\) 的 range 可能包含 universal circuit 控制语法产生的额外
   truth tables；式 (5) 只声明目标 class 被包含。
2. **控制串的 canonical inverse 未自动得到。**
   对 range/search 或 JK recursive normalization，需要一个固定、有效、最好
   exponent-stable 的 \(C\mapsto c_C\) 编码；Valiant 的 existence statement 本身不足以
   提供该接口。
3. **不能把复制 \(T\) 个 universal circuits 当作 near-linear。**
   每个 output assignment 都要承载一个 \(s\log s\)-规模 universal evaluator；
   共享 controls 不会消除 data-path 的 \(T\) 倍成本。
4. **不能外推 unrestricted lower bound。**
   \(O(q^2)\) 只是一条显式构造上界；note 087 的 materialization lower bound 适用于
   额外暴露 boundary bundles 的架构，不排除未知的跨 assignment nonlinear compression。

### 文献边界

- Leslie G. Valiant, *Universal circuits (Preliminary Report)*, STOC 1976,
  [DOI 10.1145/800113.803649](https://doi.org/10.1145/800113.803649)；
  摘要给出 \(O(s\log s)\) universal-circuit size。
- Gajulapalli--Li--Volkovich, TR24-049，PTT 的 \(O(E^3)\) 上界见其 Lemma 2.15。
- 式 (1)--(7) 是本项目对 universal-circuit batching 的自足推导；
  不声称 \(P\ne NP\)，也不声称已达到目标 \(q\operatorname{polylog}q\) decoder。
