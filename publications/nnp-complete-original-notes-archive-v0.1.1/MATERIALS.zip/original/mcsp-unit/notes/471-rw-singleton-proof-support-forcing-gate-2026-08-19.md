> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW singleton common-proof support forcing gate (2026-08-19)

## 本轮改变的判断

C469--C470 对 common static package 或 fingerprint evaluator 计价，但还没有把
“同一 physical proof 上允许任意自适应、非乘积查询”单独写成 singleton 定理。
本轮只保留 Gate III 已经需要的最小条件：在 \(P=NP\) 分支，所有查询已经形成一个
针对同一个 \(B_n\) 的单值 evaluator。把该 evaluator 在所有地址、所有可能的
proof-answer 分支上触及的 proof positions 取并集 \(L_n\)，即可把 proof 当作一个
有限 ROM 展开。

结果是一个与 finite-state、seed factorization、common-package 形状无关的支持下界：

\[
  g_n+q_nL_n\bigl(\ell_n+\lceil\log_2|\Sigma_n|\rceil\bigr)
  =\Omega\!\left(\frac{N_n}{\log N_n}\right),
  \tag{471.1}
\]

其中 \(g_n\) 是不展开 proof ROM 的控制电路大小，\(q_n\) 是最大 query 数，
\(\ell_n=\lceil\log_2(P_n+1)\rceil\) 是 proof-address 长度。故 address-scale
control、query 数、proof-address 长度和 union support 都为
\((\log N_n)^{O(1)}\) 时，直接与 C455 forcing 矛盾。剩余方案必须暴露
\(\Omega(N_n/\operatorname{polylog}N_n)\) 级 proof support、支付等价控制成本，
或根本没有 single-valued common-proof evaluator。

## 设置

取 C455 的无限 hard-length 集合 \(\mathcal I\)。对 \(n\in\mathcal I\)，令

\[
  B_n\in\{0,1\}^{N_n},\qquad
  S_n:=\operatorname{CC}(B_n)\ge cN_n/\log N_n,\qquad
  m_n=\lceil\log_2(N_n+1)\rceil .
  \tag{471.2}
\]

在 \(P=NP\) 分支，假设存在一个固定 target-dependent physical proof
\(z_n\in\Sigma_n^{P_n}\) 和一个确定性 evaluator \(D_n\)。输入地址
\(j\in[N_n]\) 后，\(D_n\)：

1. 最多自适应读取 \(q_n\) 个 proof symbols；
2. 每个下一查询地址由 address、此前读取的 proof symbols 和固定控制共同决定；
3. 在不把 \(z_n\) 当作免费 ROM 展开时，所有 finite control、address arithmetic
   和最终输出的 fan-in-two 大小为 \(g_n\)。

令 \(L_n\subseteq[P_n]\) 为在所有 \(j\) 和所有可能的 \(\Sigma_n\)-valued answer
paths 上可能被读取的 proof positions 的并集。令
\(\ell_n=\lceil\log_2(P_n+1)\rceil\) 且
\(a_n=\lceil\log_2|\Sigma_n|\rceil\)。

## 定理 471.1（singleton proof-support forcing gate）

若 \(D_n(j;z_n)=B_n[j]\) 对所有 \(j\in[N_n]\) 成立，则存在普通 Boolean circuit
\(C_n\) 满足

\[
  \operatorname{CC}(B_n)
  \le
  O\!\left(
      g_n+q_nL_n(\ell_n+a_n)+\log(N_n+2)
    \right).
  \tag{471.3}
\]

因此在 C455 的同一 hard-length 集合上，

\[
  g_n+q_nL_n(\ell_n+a_n)+\log(N_n+2)
  \ge
  \Omega\!\left(\frac{N_n}{\log N_n}\right).
  \tag{471.4}
\]

特别地，若 \(g_n,q_n,\ell_n,a_n,L_n=m_n^{O(1)}\) 在无限多个
\(n\in\mathcal I\) 上成立，则 (471.3) 与 (471.2) 矛盾。若 \(g_n\) 已低于
\(S_n/2\)，则存在绝对常数 \(c'>0\) 使

\[
  L_n\ge
  c'\frac{N_n/\log N_n-g_n}{q_n(\ell_n+a_n)}.
  \tag{471.5}
\]

换言之，单值 common-proof evaluator 若想逃避 forcing，必须在地址族上触及
forcing-scale 的 proof support；“每次只 query \(q_n\) 个位置”本身并不等于
一个小电路。

### 随机 gap 版本

若 evaluator 是 \(E_n(j;z_n,R)\)，在同一 proof/address space 上对每个地址有
\(\alpha_n-\beta_n=\gamma_n>0\) 的固定 acceptance gap，且 \(t_n\) 条 public tapes
可被 C470 的 finite-tape sampling 固定，则对这 \(t_n\) 条 tapes 的 support union
\(L_n^\star\)、每条 tape 的控制大小 \(g_n^\star\) 和 query 上界 \(q_n\)，有

\[
  \operatorname{CC}(B_n)
  \le
  O\!\left(
  t_n\bigl(
    g_n^\star+q_nL_n^\star(\ell_n+a_n)
    +m_n+\log(t_n+2)
  \bigr)\right).
  \tag{471.6}
\]

所以 randomized non-product relation 只有在 gap/randomness 使 \(t_n\) 变大，或
support/control 付出 forcing/object scale 时，才能避开 (471.4)。

## 证明

把真实 proof symbols \(z_n[\ell]\)（\(\ell\in L_n\)）逐个硬接为常量。对 evaluator
的第 \(r\) 次 query，先由 finite control 计算一个 \(\ell_n\)-bit 地址。由于
所有可能 answer paths 的 query 地址都在 \(L_n\)，该地址对应的 proof symbol 可以
用一个 \(L_n\)-项 mux 实现：逐项比较地址与 \(L_n\) 个固定位置，每次比较成本
\(O(\ell_n)\)，再选择 \(a_n\) 个 symbol bits 成本 \(O(a_nL_n)\)。因此一次
adaptive read 的 ROM 展开成本 \(O(L_n(\ell_n+a_n))\)，最多 \(q_n\) 次读取给出
\(O(q_nL_n(\ell_n+a_n))\)。

将这些 mux 接回原来的 finite control，得到一个只以 \(j\) 为输入的电路。它在
每个真实执行路径上模拟 \(D_n\)，并输出 \(B_n[j]\)；控制、地址 arithmetic 和
最终输出贡献 \(g_n+O(\log(N_n+2))\)，得到 (471.3)。把 C455 的
\(S_n=\Omega(N_n/\log N_n)\) 代入即得 (471.4)--(471.5)。

随机版本先按 C470 固定 \(t_n\) 条 tapes，使每个地址的经验接受率可由阈值恢复
\(B_n[j]\)。对每条 tape 做同样的 union-support ROM 展开，复制 \(t_n\) 个
finite controls 并加 threshold bookkeeping，得到 (471.6)。证毕。

## 对 Closure 计划的直接后果

1. 该定理不要求 proof relation 是 finite-state、factorized seed、static package
   或 product distribution；唯一的语义要求是同一个 physical proof 和一个
   single-valued address evaluator。
2. 它把“unbounded/global state”进一步拆成可计价的两项：若 state 最终只通过
   \(L_n\) 个 proof cells 影响输出，就必须按 (471.3) 支付；只有 query support
   本身达到 forcing scale，或 evaluator 仍不是单值 common-proof surface，才是
   真正的 model exit。
3. C471 仍不把 published RW 的 Reconf 直接认作该 evaluator。C370/C469 的
   \(\forall j\,\exists C_j\) 量词尚未给出一个固定 \(D_n\)；本定理的作用是：
   一旦有人补上 Gate-I 的 same-object/same-proof single-valued attachment，
   其 proof support 不能再被称为“免费局部 query”。
4. family-level RLDC barriers 不是本定理的证明前提；因此它也覆盖 singleton
   target-specific proof。它只给出 forcing/support 二分，不是无条件的
   \(P\ne NP\) 证明。

## 证据边界

* C455 supplies the lower bound on the same published \(B_n\) and the same infinite
  length set.
* The ROM expansion is an elementary finite fan-in-two circuit construction; it does
  not assume a succinct description of \(z_n\).
* If a query uses an uncharged unit-cost global oracle, an address-dependent physical
  proof, or a non-finite operation outside the stated evaluator model, (471.3) does not
  apply; those are explicit model exits, not silent Closure.

## 来源

* [C455 published RW hard-output forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
* [C469 RW singleton common-package Closure trichotomy](469-rw-singleton-closure-trichotomy-2026-08-19.md)。
* [C470 RW singleton short-fingerprint Closure gate](470-rw-singleton-fingerprint-closure-gate-2026-08-19.md)。
* [Branch-support barrier for finite-response ACRR](../../rw-jk-succinct-reconstruction/statements/strategy-support-acrr-rldc-barrier.md)。
