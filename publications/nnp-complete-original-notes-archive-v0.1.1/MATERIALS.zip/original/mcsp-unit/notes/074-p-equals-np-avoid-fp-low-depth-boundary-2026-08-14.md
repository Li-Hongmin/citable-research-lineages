> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(P=NP\) 下 AVOID 的确定化与低深度不可编译边界（2026-08-14）

## 结论

令

\[
C:\{0,1\}^r\longrightarrow\{0,1\}^m,\qquad m>r,
\]

且令 \(\mathsf{Avoid}(C)=\{y:y\notin\operatorname{Range}(C)\}\)。在假设
\(P=NP\) 下有

\[
\mathsf{Avoid}\in FP.
\tag{1}
\]

这可由 Li 的 single-valued \(\mathrm{FZPP}^{NP}\) 算法确定化得到，但其实不需要
single-valuedness 或 Li 的算法：直接对“当前前缀能否扩展成非像点”作
\(\Sigma_2^P\) 自归约即可。

把 (1) 应用于 Li/Korten 的固定 truth-table decoder 后，得到 deterministic
\(\operatorname{poly}(N)\)-time 的完整 truth-table generator；因此在 \(P=NP\) 下存在

\[
L\in E,\qquad
\operatorname{CC}(L_n)>\left\lfloor\frac{2^n}{n}\right\rfloor
\quad\text{对所有充分大 }n.
\tag{2}
\]

但这只回答 CJSW 接口的 **FP 分支**，不产生
polylogtime-uniform \(\mathrm{AC}^0[\mathrm{qpoly}]\) generator。后者在 \(P=NP\)
假设下反而不可能输出上述 hard tables：CJSW Lemma 2.5 会把这种 generator 的输出压回
\(\operatorname{polylog}(N)\) circuit complexity。故不存在一个可在 \(P=NP\) 下证明、并保持
所需 hardness 的一般

\[
FP\text{ full-table generator}
\Longrightarrow
\text{polylogtime-uniform }\mathrm{AC}^0[\mathrm{qpoly}]
\tag{3}
\]

编译。若对这个 hard-table family 建立右端，CJSW Proposition 4.3 已直接推出
\(P\ne NP\)。

## 直接的 \(\Sigma_2^P\) 前缀搜索

给定前缀 \(p\in\{0,1\}^{\le m}\)，定义

\[
\mathsf{Ext}(C,p)
\iff
\exists y\succeq p\;\forall x\in\{0,1\}^r\quad C(x)\ne y.
\tag{4}
\]

这是一个 \(\Sigma_2^P\) 谓词。由鸽巢原理，\(\mathsf{Ext}(C,\epsilon)\) 为真。
若 \(P=NP\)，则 \(PH=P\)，所以 (4) 可确定性多项式时间判定。由空前缀开始，在每一步先问
\(\mathsf{Ext}(C,p0)\)：若真则追加 \(0\)，否则追加 \(1\)。经过 \(m\) 步得到
lexicographically first 的 \(y\notin\operatorname{Range}(C)\)。电路显式给出全部输出，故
\(m\) 至多为输入描述长度的多项式，整个过程属于 \(FP\)。这证明 (1)。

这里的量词长度相对显式 AVOID instance 是多项式；当 instance 是由
\(N=2^n\) 隐式指定的 truth-table decoder 时，它们相对地址长度 \(n\) 是指数长度。
这个重标度正是下文低深度失配的来源。

## Li single-valued 算法的 seed-search 确定化

另一条证明精确解释了 canonicality 在 \(P=NP\) 下能给什么。设
\(M^{NP}(z;r)\) 是 single-valued \(\mathrm{FZPP}^{NP}\) solver。截断 expected-polynomial
运行后，可取一个 polynomial clock，使成功概率仍为正常数，且每条路径只输出固定
\(y_z\) 或 \(\bot\)。在 \(P=NP\) 下，用固定的 deterministic polynomial-time 算法精确模拟
每个 NP oracle query。于是

\[
\mathsf{Succ}(z,r):=[M^{NP}(z;r)\ne\bot]
\tag{5}
\]

属于 \(P\)，而

\[
\mathsf{SeedExt}(z,u)
\iff \exists v\;\mathsf{Succ}(z,uv)
\tag{6}
\]

属于 \(NP=P\)。对 (6) 逐位自归约可找到第一条成功 random tape \(r^*\)，再精确运行
\(M(z;r^*)\)；single-valuedness 保证输出正是 \(y_z\)。因此

\[
P=NP\quad\Longrightarrow\quad
\text{single-valued }\mathrm{FZPP}^{NP}\subseteq FP.
\tag{7}
\]

不能在尚未使用 \(P=NP\) 时仅猜一个 NP-oracle transcript：伪造的 NO answers 可能制造
假成功路径。上面的论证先把 oracle 本身确定化，因而没有这个漏洞。

## truth-table decoder 的推论

取 Li Definition 4.6 的 stack-program decoder

\[
TT_{n,s}:\{0,1\}^{L_{n,s}}\longrightarrow\{0,1\}^{2^n},
\qquad
L_{n,s}=(s+1)(7+\log(n+s)),
\tag{8}
\]

并令 \(s=\lfloor2^n/n\rfloor\)。对充分大 \(n\)，\(L_{n,s}<2^n\)，且每个 size-\(s\)
Boolean circuit 的 truth table 都在 decoder range 内。decoder 可在
\(\operatorname{poly}(N)\) 时间由 \(1^N\) 构造，其中 \(N=2^n\)。由 (1) 得到
deterministic \(\operatorname{poly}(N)\)-time 输出 \(h_N\)，满足

\[
h_N\notin\operatorname{Range}(TT_{n,s}),
\qquad
\operatorname{CC}_n(h_N)>s.
\tag{9}
\]

定义 \(L(x)=h_{2^{|x|}}[x]\)。生成整张表再读取一位耗时
\(\operatorname{poly}(2^{|x|})=2^{O(|x|)}\)，所以 \(L\in E\)，并得到 (2)。这也可由
Korten Theorem 10 的
\(\mathsf{Empty}\in FP^{NP}\) 与 a.e. exponential hard language 等价，以及
\(P=NP\Rightarrow E^{NP}=E\) 读出。

式 (2) 不与 \(P=NP\) 矛盾。\(P=NP\) 只把多项式层级在其自身输入尺度上折叠；这里完整表长
\(N\) 相对真实地址长度 \(n=\log N\) 是指数长，FP 的 \(N^{O(1)}\) 时间正对应
\(2^{O(n)}\) 时间。

## 第一处严格失配：逐位图的复杂度

对一般 deterministic full-table generator

\[
R(1^N)\in\{0,1\}^N,\qquad R\in FP,
\]

其逐位图

\[
g(n,i)=R(1^{2^n})_i
\tag{10}
\]

只保证属于 \(E\)。FP 算法可能包含 \(N^{\Theta(1)}\) 个顺序步骤；Li 算法的 succinct
history verification、selector 和 seed/prefix search 也没有给出常深度并行化。

相反，若 \(R_N\) 是 polylogtime-uniform、quasipolynomial-size、constant-depth circuit，
则输出位可通过对 gate/wire indices 作常数量词层的猜测与核验而落入 \(PH\)。CJSW Lemma 2.5
据此证明：若 \(P=NP\)，每个这样的 \(R_N(1^N)\) 都只有
\(\operatorname{polylog}(N)\) circuit complexity。它不可能等于 (9) 中 complexity
\(>N/\log N\) 的表。

因此当前承重问题不能再表述成“能否在 \(P=NP\) 下把 Li solver 编译为低深度 generator”。
精确表述是：构造这种低深度 hard-table generator 本身已经越过 CJSW 的
\(P\) versus \(NP\) 门槛；Li 给出的 canonicality、all-length 和 near-maximum threshold
均未提供所缺的低深度逐位计算。

## Li 证明内部的第一处失配

对 note 073 的 OPS/CJSW thresholds（其 decoder description length
\(\ell(N)=o(N)\)），不必经过 Li Corollary 4.7 的一般 stretch 转换；充分大时可直接
padding 为

\[
\Phi_{N,t}:\{0,1\}^{N/2}\longrightarrow\{0,1\}^{N}
\]

并调用 Theorem 4.3；所以 Corollary 4.7 中 Theorem 4.4 与 Lemma 4.5 的
\(FP^{NP}\) 后处理并不是这些 thresholds 的首个障碍。near-maximum
\(s=\lfloor N/\log N\rfloor\) stack-program decoder 则只有 \(L_{n,s}<N\)，通常并不满足
\(L_{n,s}\le N/2\)，仍需一般 stretch 处理；这不影响上面的直接 \(\Sigma_2^P\) 自归约。
对可直接代入的 OPS/CJSW thresholds，首个障碍已经在 Theorem 4.3 的核心构造内出现：

1. Lemma 3.2 的 `GGMEval` 沿一条 GGM path 连续调用 \(C\) 共 \(O(\log T)\) 次。
   代入 input length \(r=N/2\) 后，\(T=2r2^{2r}=N2^N\)，故依赖链长度为
   \(\Theta(N)\)，不是常深度。
2. Algorithm 1 对内部节点寻找 \(C\) 的 lexicographically first preimage。对
   truth-table decoder，这就是寻找最小 circuit description 或判定其不存在的 adaptive
   inversion，而不是一个因 decoder 固定就消失的局部操作。
3. Lemma 3.7 只证明正确 computational history 有长度 \(O(r\log T)=O(N^2)\) 的唯一
   succinct description，并不计算该 description。Lemma 3.8 用长度 \(\Theta(N)\) 的
   universally quantified index 压缩 \(2^{\Theta(N)}\) 个局部检查；这解释了
   \(FS_2^P\) 上界，却不能由 quasipolynomial-size \(AC^0\) 显式展开。
4. Lemma 4.2 的 selector 向叶子递归 \(O(\log T)=\Theta(N)\) 层，并反复执行一般
   circuit evaluation/equality。这个通用 primitive 可限制出 parity，故按原证明逐门编译成
   fixed-depth qpoly-size \(AC^0\) 会撞上标准 parity lower bound。

这只排除“原样低深度化 Li verifier/selector”，不排除一个结构完全不同的直接低深度算法；
但任何后者一旦输出上述 hard tables，已由 CJSW Proposition 4.3 构成突破。Li
Corollary 1.8 的 depth-3 MissingString 算法也不填补该接口：它处理显式列表，允许
\(2^{\operatorname{poly}(N)}\) 规模，不是 succinct decoder 上的 qpoly-\(N\) range avoidance。

## 截至 2026-08-14 的相邻文献决策检索

本轮命中的相邻结果没有改变上述接口：

- Guruswami--Lyu--Wang 与 Gajulapalli--Golovnev--Nagargoje--Saraogi 研究的是输入映射本身为
  low/constant-depth circuit 时的 range avoidance。truth-table decoder 包含一般 circuit
  evaluation，不属于该受限输入类；“AVOID for low-depth circuits”也不等于“由 low-depth
  uniform circuit 求解一般 succinct AVOID”。
- Li Corollary 1.8 的 MissingString 电路接收显式的 \(m\times n\) bit list 并输出一个
  \(n\)-bit missing string。若为目标 \(N\)-bit MCSP table 取 \(n=N\)，其允许规模
  \(2^{\operatorname{poly}(N)}\) 远大于 qpoly\((N)\)；若取 \(n=\operatorname{polylog}N\)，
  输出长度又不是 \(N\)。
- Korten--Pitassi Theorem 1 给出 \(\mathsf{Avoid}\le_m^P\mathsf{LOP}\)，而
  Hirsch--Volkovich Lemma 32 / Corollary 33 的相邻构造仍是 deterministic polynomial time
  配合 \(L_2^P\) oracle。它们是显式输入尺度上的 polynomial-time reduction/oracle
  statements，不给 CJSW 所需的 gate/wire polylogtime uniformity。

因此当前检索没有找到一个把显式实例尺度的 \(FP\)-AVOID 转成 CJSW generator 的已发表桥。
这是一次有明确模型筛选条件的未命中，不是“这种文献绝对不存在”的断言。

## 来源

- Zeyong Li, *Symmetric Exponential Time Requires Near-Maximum Circuit Size*,
  arXiv:2310.17762v2, Theorems 1.1, 1.5, 4.3，Definition 4.6，Corollaries 4.7--4.8。
- Lijie Chen, Ce Jin, Rahul Santhanam, Ryan Williams,
  *Constructive Separations and Their Consequences*, JACM，Lemma 2.5，Proposition 4.3。
- Oliver Korten, *The Hardest Explicit Construction*, FOCS 2021 / arXiv:2106.00875v3,
  Theorem 10。
- Venkatesan Guruswami, Xin Lyu, Xiuhan Wang, *Range Avoidance for Low-Depth Circuits
  and Connections to Pseudorandomness*, APPROX/RANDOM 2022。
- Karthik Gajulapalli, Alexander Golovnev, Satyajeet Nagargoje, Sidhant Saraogi,
  *Range Avoidance for Constant Depth Circuits: Hardness and Algorithms*,
  APPROX/RANDOM 2023。
- Oliver Korten, Toniann Pitassi, *Strong vs. Weak Range Avoidance and the Linear
  Ordering Principle*, FOCS 2024 / ECCC TR24-076, Theorem 1。
- Edward A. Hirsch, Ilya Volkovich, *Upper and Lower Bounds for the Linear Ordering
  Principle*, STACS 2026, Theorem 22，Theorem 31，Lemma 32，Corollary 33。

本文的直接前缀自归约、seed-search 量词核对，以及 FP/低深度逐位图的参数分离，是对上述接口的
本项目推论；它们不是所引论文逐字陈述的定理。
