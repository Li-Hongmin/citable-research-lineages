> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW stable-stage PCP proof-length gate (2026-08-18)

## 判定

Theorem 4.3 的稳定参数 \(T_i=n_{i+1}\) 不能直接推出其 JK 调用落入
Theorem 3.1 的 easy branch。这里混淆了两个不同的长度：\(T_i\) 是多输出函数
\(f_i\) 的输出长度，而 JK 接收的是 Theorem 4.1 先为 \(f_i\) 构造的 canonical PCP
proof \(\Pi_i\)。JK 的长度参数是

\[
  L_i:=|\Pi_i|,
\]

不是 \(T_i\)。原文只给出 \(L_i\le \operatorname{poly}(T_i)\)，没有给出
\(L_i\le T_i\)。因此“稳定阶段 \(T_i=k_i\)，所以 JK 直接 easy”不是 source-level
结论。

## 源码语义

Theorem 4.3 在 stage \(i\) 定义

\[
  f_i(x)=B_i0^{T_i-2n_i},
  \qquad k_i=n_{i+1},
  \qquad T_i=\max\{2^{cD^in_0},n_{i+1}\}.
\]

Theorem 4.1 对一般 (f) 的 `Solve_f` 先调用 Theorem 3.5，得到 proof

\[
  \Pi_x=(\widetilde w_x,\Pi'_x),
  \qquad |\Pi_x|\le \operatorname{poly}(t(n)),
\]

再执行

\[
  \operatorname{Je\v{r}ábek\text{--}Korten}(G,\Pi_x).
\]

所以对 published call \(\operatorname{Solve}_{f_i}(x_0,G_{n_{i+1}})\)，Theorem
3.1 的输入宽度是 \(k_i=n_{i+1}\)，而其 truth-table 长度是 \(L_i=|\Pi_{x_0}|\)。
Theorem 3.1 的 trivial easy 条件是

\[
  L_i\le k_i,
\tag{379.1}
\]

因为只有在它的 theorem-level 参数 \(T\le n\) 时，JK 才能直接 hardwire truth table。
稳定关系 \(T_i=k_i\) 并不蕴含 (379.1)。Theorem 3.5 的 Complexity bullet 只有

\[
  L_i\le \operatorname{poly}(T_i)=\operatorname{poly}(k_i),
\tag{379.2}
\]

而不是线性上界。其 systematic Reed--Muller 前缀保证 proof 中含有 witness/output
字段，但在原文给定的编码模型下没有提供足以把 (L_i) 精确压到 (k_i) 的跨构造
长度等式。

## 正确的分支分类

在稳定阶段只能写出下面的三分，而不能把第一项由 (T_i=k_i) 自动触发：

1. **短 PCP proof：** 若 \(L_i\le k_i\)，JK 进入 trivial easy branch，
   `Solve` 不输出 outsider，Theorem 4.1 的 failure/Reconf 语义适用。
2. **长 PCP proof、hard exit：** 若 \(L_i>k_i\) 且递归中出现 non-range block，
   JK 输出 \(2k_i\)-bit outsider；这只给出
   \(y\notin\operatorname{Range}(G_{k_i})\)，不提供父表的 parent binding（C372）。
3. **长 PCP proof、recursive easy：** 若 \(L_i>k_i\) 但所有递归 block 都在 range，
   JK 仍可能返回 easy 及一个 small circuit。此时仍属于 Theorem 4.1 的 failure
   分支；“\(L_i>k_i\)”本身不等于 hard exit。

因此，长度 \(L_i\) 只决定 trivial easy gate；要排除第三项，还需要 canonical proof
或其 systematic hard prefix 的 circuit-complexity 论证。反过来，即便第一项成立，
Reconf 恢复的是同一个 \(f_i(x_0)\)，也不会自动把下一层 outsider 绑定成父对象的
address evaluator。

## 对 Closure 的影响

这条 source audit 修正了一个可能的错误路线，但没有削弱 C371 的 width/solver
三分：在 \(P=NP\) 下，若 child width 与 query 描述都压到 address scale，failure
分支仍受重构电路上界约束；若失败被排除，剩余仍是 solver-success semantic exit。
新增加的独立 Gate-I 参数是

\[
  \text{PCP proof length }L_i
  \quad\text{以及}\quad
  \operatorname{CC}(\Pi_i),
\]

而不能只记账 \(f_i\) 的输出长度 \(T_i\)。一个真正的 RW Closure 证明必须至少做出
以下一项：

* 给出实际 canonical PCP construction 的 \(L_i\le k_i\) 或 \(L_i>k_i\) 的可核验界；
* 在 \(L_i>k_i\) 时证明 recursive easy branch 与 hard parent 的复杂度不相容；
* 直接构造从 hard/child outsider 到同一个父 history 的 address-scale binding。

在这些接口出现前，不能把 stable stage 标记为“JK 已知 easy”，也不能据此宣称
published RW 的 solver-success/failure 量词已经闭合。

## 证据边界

* Ren--Williams Theorem 3.1：JK 的长度参数是其 truth-table 输入长度 (T)，且
  (T\le n) 时直接返回 easy；见本地抽取
  `units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md`，
  约 498--548 行。
* Theorem 3.5：canonical PCP proof (Pi_x) 的长度只有
  (|\Pi_x|\le\operatorname{poly}(t(n)))；见约 765--850 行。
* Theorem 4.1：`Solve_f` 把 (Pi_x) 而非裸 (f(x)) 传给 JK；见约 867--907 行。
* Theorem 4.3：稳定阶段只说明 (T_i=n_{i+1})，并未把它等同为 (|\Pi_{x_0}|)；
  见约 1035--1090 行。

本 note 是一个 RW source-level 长度量词修正，不是 JK/RW 的一般不可能性定理，
也不是 (P\ne NP) 证明。
