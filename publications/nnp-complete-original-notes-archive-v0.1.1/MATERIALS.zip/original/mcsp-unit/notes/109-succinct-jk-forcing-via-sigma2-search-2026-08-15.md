> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Succinct JK forcing：\(h=O(\log q)\) 时的 \(\mathrm{FP}^{\Sigma_2^P}\) 正面引理与 NP 边界（2026-08-15）

## 结论

note 108 的指数长度障碍针对“把全部 \(A^{2^h}\) tuples 显式写入 truth table”。若输入改为
一个 random-access generator，且 \(h=O(\log q)\)，则可以不枚举这些 groups：

\[
\boxed{
\begin{array}{ll}
\text{给定一个候选 group：}&\text{canonical JK\(_h\) 的失败检测与 outsider 输出在 }\mathrm{FP}^{NP};\\
\text{在全部 groups 中寻找一个失败 group：}&\text{在 }\mathrm{FP}^{\Sigma_2^P};\\
M^{2^h}>2^q,\ A\subseteq\operatorname{Range}(G_q):&
\text{必存在失败 group。}
\end{array}}
\tag{1}
\]

这里的 \(\Sigma_2^P\) 不是记号上的装饰：一般情况下，\(\exists\) group 外层包住
“parent block 不在 range”这一 coNP 条件；后面的 \(h=1\) 小节给出一个
\(\Sigma_2^P\)-hard 构造。因此该正面引理在 \(P=NP\) 假设下才变成多项式时间
forcing（因为 \(P=NP\Rightarrow\mathrm{PH}=P\)），不能直接宣称为 NP-only 的
compressed-JK theorem。

## 输入模型与索引长度

令

\[
G_q:\{0,1\}^q\to\{0,1\}^{2q},\qquad R_q=\operatorname{Range}(G_q),
\]

并设 \(A=\{E(a):a\in I_M\}\subseteq R_q\)，其中
\(I_M=\{0,\ldots,M-1\}\)，\(M=|A|\)，\(r=\lceil\log_2M\rceil\)，且 \(E\) 是
injective 的 random-access enumeration；每个 \(E(a)\) 是 \(2q\)-bit block，给定
\((a,b)\) 可在 \(\operatorname{poly}(|E|,q)\) 时间输出 \(E(a)[b]\)。为简化
索引，可特别取 \(M=2^r\)；非二次幂时对 \(r\)-bit invalid indices 做显式拒绝。

置

\[
\ell=2^h,\qquad
F(j,t,b)=E(j_t)[b],
\]

其中一个 group index \(j\) 由 \(\ell\) 个 \(r\)-bit indices
\(j=(j_1,\ldots,j_\ell)\) 组成，\(1\le t\le\ell\)，\(1\le b\le2q\)。
于是 \(F\) 枚举 \(A^\ell\)，但没有显式列出 \(M^\ell\) 个 groups
\((M=|A|)\)。当 \(h=O(\log q)\) 时

\[
M\le |R_q|\le 2^q,\quad r=\lceil\log_2M\rceil\le q,\quad
|j|=\ell r\le q\,2^h=\operatorname{poly}(q);
\tag{2}
\]

故 group witness 本身仍是多项式长度。若使用一般的 \(F\)，应把
\(|j|\) 直接作为输入参数；不能把它错误地当成 \(O(\log M)\)。

若把这些 groups 真正串接成 JK 的显式输入，则每个 group 恰含
\(2^h\) 个顶层 blocks；二叉配对在前 \(h\) 个 stages 内不会跨越 group
边界。因此本 note 找到的失败 block 与该串接输入的实际 stage 对齐。总 group
数不是二的幂时，可在末尾增加任意 padding groups，再按 Ren--Williams
定理把总长度补到 \(q2^k\)；padding 若本身产生 non-image 只会更早结束 JK。
这一段只说明 alignment，不把指数长度的显式串接误称为多项式算法。
本文把 \(q\) 作为一元参数或显式 block-size 参数计入输入长度，并假设 \(G_q,F\) 的
统一电路描述大小为 \(\operatorname{poly}(q+|j|)\)。若只把 \(q\) 二进制编码而不计
输出 \(2q\) 位的成本，则下面的“多项式时间”应理解为参数化的
\(\operatorname{poly}(q+|j|)\) 时间，而不是标准二进制输入长度结论。

## Canonical JK\(_h\) 单组过程

对固定 \(j\)，先取叶 blocks

\[
z_{h,t}=F(j,t,\cdot)\in\{0,1\}^{2q}\quad(1\le t\le\ell).
\]

从叶向 root 逐层处理，层数为
\(\ell,\ell/2,\ldots,1\)。当前每个 \(2q\)-bit block \(z\)（包括最后的
singleton root parent）先做 range query \(z\in R_q\)。若否，立即输出这个
\(z\) 作为 non-image；若是，则用 lexicographic self-reduction 找到唯一规定的
whole-word preimage

\[
x(z)=\operatorname{lexmin}\{x\in\{0,1\}^q:G_q(x)=z\}.
\tag{3}
\]

若当前层不止一个 block，把相邻两个 \(q\)-bit words
\(x(z_{2u-1})\Vert x(z_{2u})\) 拼成下一层的 \(2q\)-bit parent block，并继续。
在 singleton root parent 上，式 (3) 给出最终 root seed。由于式 (3) 是确定的
lex-first 选择，相同 block 的不同 occurrences 使用相同 preimage；若改用非canonical
selector，则必须另行假设它具有同样的 word consistency。

单个 group 共访问小于 \(2\ell\) 个 blocks。每个 range query 是一个 NP
predicate

\[
\exists x\;[G_q(x)=z],
\]

而式 (3) 只需 \(q\) 次带 prefix 的同类 query。因此：

\[
\operatorname{Fail}_{G,F,h}(j)
\quad\text{及其第一个失败 block 的输出}\quad\in\mathrm{FP}^{NP},
\tag{4}
\]

时间和 query 数为
\(\operatorname{poly}(\ell,q,|G_q|,|F|)\)。这一步没有展开其他 groups。

## 容量保证失败 group 存在

假设 \(A\subseteq R_q\)，并且

\[
M^\ell>2^q.
\tag{5}
\]

反设每个 \(j\in A^\ell\) 的 canonical JK\(_h\) 都没有失败。由每个 parent
block 的式 (3) preimage，最终得到一个 \(q\)-bit root seed \(\rho(j)\)。

若 \(\rho(j)=\rho(j')\)，则从同一个 root seed 开始，反复施加确定的 \(G_q\)
并按左右坐标拆分，会恢复唯一的整棵 \(h\)-层 tree，特别恢复唯一叶 tuple
\((E(j_1),\ldots,E(j_\ell))\)。由于 \(E\) injective，有 \(j=j'\)。故

\[
M^\ell
\le\bigl|\{\rho(j):j\in A^\ell\}\bigr|
\le 2^q,
\]

与式 (5) 矛盾。因此至少存在一个失败 group；该论证对 lex-first 之外的任意
word-consistent selector 也成立。

## 找到失败 group 的复杂度

固定 group 的失败关系属于 \(\mathrm{P}^{NP}\)，由式 (4) 可写成

\[
L_{\mathrm{fail}}=\{(1^q,G,F,h,M):\exists j\in I_M^\ell\
\operatorname{Fail}_{G,F,h}(j)\}\in NP^{NP}=\Sigma_2^P.
\tag{6}
\]

这里 \(G,F\) 的电路描述、\(M\)、\(h\) 以及 invalid-index 规则都作为输入字段，
并要求 \(2^h,|j|\) 对输入长度至多多项式。对 group index 的每一位做标准
self-reduction，调用式 (6) 的判定器，即可在
\(\mathrm{FP}^{\Sigma_2^P}\) 中找到一个失败 \(j\)。随后重新运行该 group 的
canonical JK\(_h\)，输出第一个 non-image block。结合式 (5)，这在 promise
\(A\subseteq R_q\) 且 \(M^\ell>2^q\) 下总会成功。

若 \(P=NP\)，则

\[
P=NP\Longrightarrow P^{NP}=P,\qquad
NP^{NP}=NP=P,
\]

从而式 (6) 的 self-reduction 退化为多项式时间。这个推论可作为
“在 \(P=NP\) 假设内部使用 compressed forcing”的正面接口；它并不提供
无条件的 \(P\ne NP\) 证明。

## 低电路 family 的直接 random-access 实例

令 \(q=2^{m-1}\)，取 \(1\le d\le m-1\)，令 \(A_d\) 是所有只依赖前 \(d\) 个变量的
\(m\)-variable truth tables。令

\[
r=2^d,\qquad M=|A_d|=2^r,
\]

并把每个 \(a\in\{0,1\}^r\) 直接看作一个 \(A_d\) 成员的 truth-table
description。令 \(L=2^h\) 是叶数，并选择最小 \(h\) 使

\[
q<Lr\le 2q.
\tag{C1}
\]

则 group index \(j\) 本身只有 \(Lr\le2q\) 位，而 random-access leaf evaluator
只是

\[
F(j,t,b)=j_{\, (t-1)r+\operatorname{low}_d(b-1)}.
\tag{C2}
\]

若固定完备 basis 的 Lupanov 常数满足
\(2^d/d\le c_0s\)，并且 decoder coverage 给出
\(A_d\subseteq R_q\)，则

\[
M^L=2^{Lr}>2^q.
\]

因此 note 109 的 \(\mathrm{FP}^{\Sigma_2^P}\) 搜索必返回一个 non-range JK block；
在 \(P=NP\) 假设下，这个搜索对 \(q\) 的运行时间为多项式，且没有物化
\(M^L\) 个 groups。这里的“压缩”只相对于显式 truth-table 长度：
当 \(q=2^{m-1}\) 时，\(\operatorname{poly}(q)\) 仍可能是指数于地址长度 \(m\)。

## NP-only 的最小失败条件：\(\Sigma_2^P\)-hard 例子

下面的 \(h=1\) 构造说明：对一般 random-access 输入，不能把式 (6) 的
失败存在性判定自动降为一个 NP search；“有某个失败 group”本身没有给出
non-membership 的 NP 证书。该构造用于无容量 promise 的一般问题；它不声称
已经证明在 \(M^\ell>2^q\) 的 promise-search 模型下的 \(\Sigma_2^P\)-hardness。
后者需要避免一个与公式无关的、可直接输出的容量失败点，仍是独立问题。

给定 \(\Sigma_2^P\)-complete QBF

\[
\exists i\in\{0,1\}^r\ \forall x\in\{0,1\}^s\ \Phi(i,x).
\tag{7}
\]

取足够大的
\[
q\ge C\max\{2r,\ r+s,\ |\Phi|\}
\]
（\(C\) 为固定编码常数），为每个 \(i\) 选择
distinct \(q\)-bit seed \(u_i\)，以及 distinct top block
\(a_i\in\{0,1\}^{2q}\)。再为每个 \(i\ne j\) 选择 distinct \(q\)-bit
seed \(v_{i,j}\)，为每个 \((i,x)\) 选择 distinct \(q\)-bit seed
\(w_{i,x}\)。构造一个 poly\((q,|\Phi|)\)-size circuit \(G_q\)，其专用输入区域满足：

1. \(G_q(u_i)=a_i\)，且没有其他输入输出 \(a_i\)；
2. 对 \(i\ne j\)，\(G_q(v_{i,j})=u_i\Vert u_j\)；
3. witness input \(w_{i,x}\) 在 \(\neg\Phi(i,x)\) 时输出
\(u_i\Vert u_i\)，在 \(\Phi(i,x)\) 时输出一个带 disjoint tag 的 dummy；
4. 其他输入也输出 disjoint dummy。

标签、区域与 zero-padding 可在 \(q\) 位输入和 \(2q\) 位输出中分离；上述
seed 数量由该 \(q\) 下界保证，电路只需再计算 \(\Phi\)。
必要时用 dummy gates 使 \(|G_q|=O(q)\)。令 \(A=\{a_i\}\)，令 \(F\) 的 \(h=1\)
groups 枚举全部
\((a_i,a_j)\in A^2\)。因为每个 \(a_i\) 的 canonical preimage 是 \(u_i\)，
cross parent \(u_i\Vert u_j\)（\(i\ne j\)）总在 range，而 diagonal parent
\(u_i\Vert u_i\) 在 range 当且仅当
\(\exists x\,\neg\Phi(i,x)\)。因此

\[
\exists\text{ failed group}
\Longleftrightarrow
\exists i\,\forall x\,\Phi(i,x).
\tag{8}
\]

这是一个从式 (7) 到允许 \(G_q,F\) 随输入变化的 succinct-JK failure-existence
问题的多项式归约。它只证明复杂度边界；不把
\(\Sigma_2^P\nsubseteq P\) 当作已知定理，也不与
\(P=NP\) 的假设冲突（在该假设下 PH 会塌缩）。

## \(h\) 的指数边界与 note 108

当 \(h=O(\log q)\) 时，一组叶 tuple 只有 \(\ell=2^h=\operatorname{poly}(q)\)
个 blocks，式 (4) 可按需物化；外层 groups 仍可用式 (6) 的量词压缩。

当 \(h=\Theta(q)\) 时，即使 \(F\) 可以随机访问，单个 canonical root 的朴素求值
需要访问 \(\ell=2^h\) 个 leaves。若无额外 compositional structure，式 (4) 的
单组 \(FP^{NP}\) 上界本身已经指数于 \(q\)。因此本引理不反驳 note 108：

\[
\text{succinct group index compression}\quad\neq\quad
\text{succinct recursive tree evaluation}.
\]

对 \(h\) 超过对数尺度，仍需一个新的 compressed-JK composition theorem；不能只
把显式 tree-rich prefix 换成 \(F\) 就沿用 Ren--Williams Theorem 3.1。

还必须区分 decoder 参数 \(q\) 与原 truth-table 的地址长度 \(m\)。若
\(q=2^{m-1}\)，则本 note 的 \(\operatorname{poly}(q)\) forcing 仍可能是
\(2^{\operatorname{poly}(m)}\) 时间；它不是关于 \(m\) 的 P-uniform
hard-table generator。因而即使式 (1) 在 \(q\)-尺度上成立，要嵌回
Ren--Williams 的固定输入长度归约，仍需一个把 \(q\)-bit block 的计算进一步压到
\(\operatorname{poly}(m)\) 的独立压缩定理。

## 边界与证据

- 容量矛盾是 note 106 的 root-injectivity 论证在 random-access groups 上的直接应用。
- Ren--Williams Theorem 3.1 的原始输入是显式 truth table；本 note 的 \(F\) 输入模型
  是新的条件接口，不冒充该定理已有结论。
- 式 (4)--(8) 是本项目推导；\(\Sigma_2^P\)-hard 只说明一般 NP-only
  compressed forcing 缺少已知依据。
- 在 \(P=NP\) 下式 (6) 可以多项式化，但要把该算法嵌回具体 RW/AVOID 归约，仍需
  检查 query-round、promise 与输出语言的固定性；本 note 不宣称已经得到
  \(P\ne NP\)。
