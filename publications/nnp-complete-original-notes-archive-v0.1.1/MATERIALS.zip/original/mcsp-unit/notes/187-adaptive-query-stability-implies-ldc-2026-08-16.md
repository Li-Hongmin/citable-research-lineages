> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 自适应 query-stability 也把 coordinate-robust proof code 编译成 LDC（2026-08-16）

## 结论地位

这是 note 186 的自适应推广。它不要求查询位置预先固定，也不要求逐位置
smoothness；只要求在诚实 codeword 上，任意允许的 corruption 集不常被自适应查询树
命中。该条件足以把完美完备性传递到近 proof，再用两个错误声明的接受频率解码。
因此，“使用 adaptive 查询”本身不是逃逸；真正的逃逸必须制造一个小的 proof 坐标集，
使诚实查询路径以常数概率集中命中该集合，或放弃本定理的 codeword/完备性/soundness
假设。

## 模型：honest-path hitting

令

\[
  C:\{0,1\}^k\to\Sigma^N
\]

为 injective proof/codeword map。对每个消息坐标 `i` 和声明位 `b`，令 `V_{i,b}`
为使用随机串 `R`、至多 `q` 次查询的**自适应** verifier。给定 oracle `z` 和 `R`，
记

\[
  Q^{z}_{i,b}(R)=(j_1,\ldots,j_s),\qquad s\le q,
\]

为实际查询位置序列；`j_t` 可以依赖此前读取的符号，位置可重复。对消息 `m`、
corruption 集 `B\subseteq[N]`，定义诚实路径命中事件

\[
  \operatorname{Hit}_{i,m}(B;R)
  :=\bigl[Q^{C(m)}_{i,m_i}(R)\cap B\ne\varnothing\bigr].
\]

称 verifier 族在半径 `δ` 上是 `(δ,η)` honest-path stable，如果对所有 `m,i` 和
所有 `B` 满足 `|B|\le\delta N`，都有

\[
  \Pr_R[\operatorname{Hit}_{i,m}(B;R)=1]\le\eta .\tag{1}
\]

注意 (1) 只看正确声明在**诚实 codeword** 上的查询树；它允许错误声明和 corrupted
oracle 走完全不同的自适应分支。

## 定理：adaptive stability \(\Rightarrow\) LDC

假设：

1. **完美完备性。** `V_{i,m_i}` 在 `C(m)` 上以概率 `1` 接受；
2. **target-relative 错误 soundness。** 存在 `delta_0>0`，对所有 `m` 和满足
   `dist(z,C(m))<=delta_0` 的 `z`，有
   `Pr[V_{i,1-m_i}^{z}=1]\le\beta`；
3. **honest-path stability。** (1) 成立，且 `\eta+\beta<1`。

令 `y` 满足 `dist(y,C(m))\le\delta\le\delta_0`，并令 `B` 为发生改变的坐标。若诚实路径不命中
`B`，则自适应执行在 `C(m)` 与 `y` 上逐步读取相同符号，归纳得到同一查询位置、同一
完整 transcript 和同一输出。因此

\[
  \Pr[V_{i,m_i}^{y}=1]\ge 1-\eta,
  \qquad
  \Pr[V_{i,1-m_i}^{y}=1]\le\beta .\tag{2}
\]

令 `\gamma=1-\eta-\beta>0`。分别独立运行 `V_{i,0}` 与 `V_{i,1}` 各
`R=\Theta(\gamma^{-2})` 次，比较接受频率并输出频率较高的位。Hoeffding 界给出常数
错误概率（放大到 `1/3`），总查询数为

\[
  O\!\left(\frac{q}{(1-\eta-\beta)^2}\right).\tag{3}
\]

所以 `C` 是半径 `δ` 的随机局部可解码码；如果采用允许自适应查询的标准 LDC 定义，
这是普通 LDC。若目标下界只针对 nonadaptive LDC，则 (3) 首先给出 adaptive-LDC，
还需单独使用相应的 adaptive-LDC 下界，不能静默替换查询模型。

### 证明

取任意一次随机串 `R`。若诚实执行在 `C(m)` 上从未查询 `B`，则第一次查询时读取
的符号相同；假设前 `t-1` 次 transcript 相同，则 verifier 的第 `t` 个查询地址也
相同，且该地址不在 `B`，第 `t` 个符号仍相同。归纳到末尾，两个执行的输出相同。
完美完备性因此只会在命中事件上失效，给出正确声明的第一式；第二式直接是对任意
oracle 的错误声明 soundness。两种接受率相差至少 `\gamma`，对独立重复应用
Hoeffding 即得 (3)。

## 自适应 smoothness 的充分条件

honest-path stability 不等于非自适应。一个易检查的更强条件是：对每个 `i,m`、每个
诚实可达 transcript 前缀 `\tau`、每个下一步 `t` 和位置 `j`，在条件事件
“诚实执行已经产生 `\tau` 且尚未命中 `B`”下，随机下一查询满足

\[
  \Pr[\,J_t=j\mid\tau,\text{ no earlier hit }B\,]\le\frac{\lambda}{N}.
\tag{4}
\]

对任意 `|B|\le\delta N`，每一步条件命中概率至多 `\lambda\delta`；对最多 `q` 步
求和得到

\[
  \eta\le q\lambda\delta .\tag{5}
\]

因此 note 186 的非自适应 `\lambda`-smooth barrier 是 (4) 的特殊情形，而 (4) 还
覆盖了随机分支依赖已读符号的 verifier。要注意 (4) 是对**每个诚实 transcript 分支**
的条件边缘约束；仅有无条件的 query marginal smoothness，不能控制自适应分支漂移。

## 逃逸三分法

定义 honest-path concentration

\[
  \Lambda_\delta
  :=\max_{m,i,\,B\subseteq[N],\ |B|\le\delta N}
    \Pr_R[\operatorname{Hit}_{i,m}(B;R)=1].\tag{6}
\]

在完美完备性、半径 `delta<=delta_0` 内的 target-relative 错误 soundness `\beta`
固定的前提下：

\[
  \Lambda_\delta<1-\beta
  \quad\Longrightarrow\quad
  \text{adaptive LDC with }O\!\left(q/(1-\Lambda_\delta-\beta)^2\right)\text{ queries}.
\tag{7}
\]

所以任何想同时满足近线性长度、常数查询、固定坐标 soundness，却又声称不落入
LDC 下界的构造，必须至少满足以下一项：

- 存在一个 `|B|\le\delta N` 的 proof 坐标集使 `\Pr[Hit(B)]\ge1-\beta`；
- 完备性在近 proof 上允许 `\bot`/拒绝（即不再有本定理的稳定传递）；
- proof 不是 injective codeword，或错误声明 soundness 不满足 target-relative near-oracle
  量词；
- 查询数、alphabet 或长度参数离开目标 LDC 下界的范围。

第一项是一个可测量的“集中查询核心”，不是一句“adaptive 所以可能逃逸”。它给出
后续下界的明确入口：若能证明这种小核心必然导致 proof 长度、复制代价或某种
direct-sum 复杂度超线性，就得到一般性 barrier；若能构造它，则构造必须公开该核心
及其对 target-binding 的影响。

## 更强的必要条件：disagreement-hitting

稳定性只用于把 verifier 编译成解码器；即使完全不谈近 proof，也能得到一个独立的
必要条件。取任意 `m,m'` 满足 `m_i\ne m'_i`，定义两个 codeword 的差异集合

\[
  D(m,m'):=\{j\in[N]:C(m)_j\ne C(m')_j\}.
\]

若另外加入 **disagreement-hitting (DH)** 假设，则对正确声明 `m_i` 的诚实查询树有

\[
  \Pr_R\bigl[Q^{C(m)}_{i,m_i}(R)\cap D(m,m')\ne\varnothing\bigr]
  \ge 1-\beta .\tag{8}
\]

这里的 DH 是独立的额外组合假设：对所有 `m,m'` 与 `m_i\ne m'_i`，诚实查询树命中
`D(m,m')` 的概率至少为 `1-\beta`。在 target-relative soundness 下，`C(m')` 通常不在 `C(m)` 的
`delta_0` 邻域内，因此 (8) **不能**从原有 soundness 自动推出；试图用全 oracle
soundness 推导它正是 note 192 识别的 family-level 量词冲突。

在显式加入 DH 后，式 (8) 说明该 verifier 族给出一族 disagreement sets 的 fractional
hitting distribution。若再有分支条件 smoothness (4)，
把 `\Delta_{m,m'}:=|D(m,m')|/N` 记作这两个 codeword 的实际相对距离，则同时得到必要不等式

\[
  1-\beta
  \le \Pr[\operatorname{Hit}(D(m,m'))]
  \le q\lambda\Delta_{m,m'} .\tag{9}
\]

它不是新的 LDC 长度下界（尤其不能把 code distance 的下界直接代入右侧），但比“adaptive 可能集中”更精确：集中路径必须同时击中所有
相反消息的差异集合。后续一般性 barrier 的一个具体目标是证明：当这些差异集合具有
近线性 code 的组合结构时，满足 (8) 的低查询 hitting distributions 要么产生 LDC/RLDC，
要么迫使 proof 长度或查询核心的 direct-sum 代价超线性。

## 对 simultaneous coordinate-robust dPCP 的意义

普通 dPCP 的平均/list soundness 不给出 (1) 或 (6)：它既可能只约束随机坐标，也可能
允许不同随机分支对应不同理想词。DHK 式 distributional soundness 只有在 target
projection 集中到同一个 `f_x` 后，才可能转化为本 note 的错误声明 soundness；它仍需
检查 honest-path concentration，而不会自动提供 (1)。

因此“同时坐标鲁棒 + 一个全局 proof”的正面构造现在有一个严格的二叉测试：

1. 若证明 (1)（例如通过分支条件 smoothness），则它已经是 LDC 候选，必须支付相应
   LDC 长度代价；
2. 若不证明 (1)，需明确给出一个小的集中查询核心，并解释为何它不被 corruption、
   target-binding 或统一性击穿。

这把 note 186 的四个逃逸项中的 `adaptive` 拆成了可证伪的两部分：自适应且稳定的
查询仍受 LDC barrier；真正未知的是“自适应集中查询核心”能否在近线性 proof 中同时
保持 coordinate soundness。

## 证据边界

这是一个纯概率/决策树推导，不声称已经排除一般 nonlinear ACRR。式 (7) 是必要的
逃逸条件，不是“集中核心必然不可能”的证明。若要接入 GM--Minzer--Weissenberg--
Zheng 的三查询 LDC 下界，必须确认所采用的下界对 (3) 产生的 adaptive decoder 查询
模型适用；否则只能把 (7) 作为 adaptive-LDC barrier 的接口。

## 来源

- [GM--Minzer--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/html/2512.12960)
- [DHK, TR15-085](https://eccc.weizmann.ac.il/report/2015/085/)
- [note 186: smooth nonadaptive barrier](186-smooth-coordinate-robust-proof-implies-ldc-2026-08-16.md)
- [note 192: family-level quantifier audit](192-family-quantifier-audit-for-acrr-barriers-2026-08-16.md)
