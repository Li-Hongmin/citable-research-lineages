> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Pathwise Lorenz profile for adaptive shared-proof verifiers (2026-08-17)

## Contribution

The incidence theorem in note 225 assumes that every honest-path query is dominated by
a single global dPCP incidence profile.  That assumption is unnecessary.  For an
arbitrary adaptive shared-proof verifier, record the number of times each proof position
is read on the honest transcript.  The exact Lorenz prefix sum of this *pathwise*
query-count profile is the worst corruption mass that can make the transcript diverge.

This gives a general adaptive closure theorem, independent of dPCP edges, outer codes,
uniform marginals, or linearity.  A one-bit construction shows that the Lorenz bound is
tight using only the pathwise profile; no incidence-only argument can improve it.

## Setup

Let

\[
  \Pi:\{0,1\}^{k}\longrightarrow \Sigma^{N}
\]

be a common proof map.  For every requested message coordinate \(i\), let
\(\mathsf D_i\) be a randomized adaptive oracle algorithm making at most \(Q\) symbol
reads and returning a symbol in \(\{0,1,\bot\}\).  Assume exact honest-path correctness:

\[
  \mathsf D_i^{\Pi(m)}=m_i
  \qquad\text{with probability one}
\tag{226.1}
\]

for every \(m\) and \(i\).

For fixed \(m,i\) and verifier randomness \(\omega\), let
\(T_{m,i}(\omega)\) be the ordered multiset of proof positions read by
\(\mathsf D_i\) on the honest oracle \(\Pi(m)\).  Repeated reads are counted with
multiplicity.  Define the pathwise query-count profile

\[
  \nu_{m,i}(v)
  :=
  \mathbb E_\omega\bigl[\#\{\text{occurrences of }v
  \text{ in }T_{m,i}(\omega)\}\bigr].
\tag{226.2}
\]

Thus \(\sum_v\nu_{m,i}(v)\le Q\).  Let
\(\nu_{m,i,(1)}\ge\cdots\ge\nu_{m,i,(N)}\) be these values in decreasing order, and define

\[
  \mathcal L_\rho(\nu_{m,i})
  :=
  \sum_{j=1}^{\lfloor\rho N\rfloor}\nu_{m,i,(j)}
  =
  \max_{|B|\le\rho N}\sum_{v\in B}\nu_{m,i}(v).
\tag{226.3}
\]

The global pathwise Lorenz profile is

\[
  \Lambda_\rho
  :=
  \max_{m\in\{0,1\}^{k},\,i\in[k]}
  \mathcal L_\rho(\nu_{m,i}).
\tag{226.4}
\]

## Theorem (pathwise Lorenz closure)

Under (226.1), \(\Pi\) is a perfect-complete weak adaptive

\[
  (Q,\rho,1,s_\rho)\text{-RLDC},
  \qquad
  s_\rho\le \min\{1,\Lambda_\rho\}.
\tag{226.5}
\]

In particular, if \(\Lambda_\rho<1\), distinct proof words have relative distance
strictly larger than \(\rho\).

### Proof

Fix \(m,i\), and let \(z\) satisfy
\(\operatorname{dist}(z,\Pi(m))\le\rho\).  Write

\[
  B:=\{v:z_v\ne\Pi(m)_v\},
  \qquad |B|\le\lfloor\rho N\rfloor.
\]

Couple the execution on \(z\) and on the honest oracle \(\Pi(m)\) using the same random
tape.  Until the first read from \(B\), the two transcripts are identical, so the
adaptive algorithm makes exactly the same next query as on the honest path.  Therefore
the probability of a first hit of \(B\) is at most the probability that the honest
transcript reads \(B\), which by a union bound over read occurrences is

\[
  \Pr[\text{first hit of }B]
  \le
  \mathbb E_\omega[\#(T_{m,i}(\omega)\cap B)]
  =
  \sum_{v\in B}\nu_{m,i}(v).
\tag{226.6}
\]

If no first hit occurs, the corrupted execution has the same complete transcript as the
honest execution, and (226.1) forces output \(m_i\).  Hence a wrong output can occur only
after a first hit, giving

\[
  \Pr[\mathsf D_i^z\notin\{m_i,\bot\}]
  \le
  \sum_{v\in B}\nu_{m,i}(v)
  \le
  \mathcal L_\rho(\nu_{m,i})
  \le\Lambda_\rho.
\tag{226.7}
\]

On the uncorrupted proof, (226.1) gives perfect completeness.  If
\(\Pi(m)=\Pi(m')\) for distinct messages, the same oracle would force the decoder to
output two different values at a coordinate where \(m\) and \(m'\) differ, so \(\Pi\) is
injective.  If \(\Lambda_\rho<1\) and two distinct proof words were within radius
\(\rho\), applying (226.7) to one message and the other proof would contradict perfect
completeness for the second message.  Thus their distance is larger than \(\rho\).
\(\square\)

## Tightness of the profile

The dependence on \(\mathcal L_\rho\) cannot be improved using only the honest query
profile.  Let \(p=(p_1,\ldots,p_N)\) be any rational probability vector.  Take the
one-bit proof map

\[
  \Pi(0)=0^N,\qquad \Pi(1)=1^N,
\]

and let \(\mathsf D\) sample \(v\) with probability \(p_v\), read \(z_v\), and output
\(z_v\).  The honest-path profile is \(\nu(v)=p_v\).  For a corruption set \(B\), flip
exactly the coordinates in \(B\); for either target bit, the decoder is wrong with
probability exactly

\[
  p(B)=\sum_{v\in B}p_v.
\tag{226.8}
\]

Maximizing over \(|B|\le\rho N\) gives precisely
\(\mathcal L_\rho(p)\).  Arbitrary real profiles follow by approximation.  Hence any
stronger soundness bound must use additional semantic structure beyond the honest
query-count profile.

## Corollaries

### 1. Recovery of the dPCP incidence theorem

Suppose a \(q_D\)-step outer decoder is composed with local tests of width \(q_P\), and
on every honest path its per-position query count is dominated by

\[
  \nu_{m,i}(v)\le q_D\lambda\mu_v.
\tag{226.9}
\]

Then monotonicity of the Lorenz prefix sum gives

\[
  \Lambda_\rho
  \le q_D\lambda\,\mathcal L_\rho(\mu),
\tag{226.10}
\]

which recovers note 225 without requiring nonadaptive edge choices.

### 2. Coding lower bounds

If the decoder is nonadaptive, the resulting RLDC is in the arbitrary-distribution
nonadaptive model.  Thus the Goldberg--Gur--Saraogi lower bound applies whenever
\(\Lambda_\rho\le1-\eta\) and
\(\rho>N^{-\eta/(2Q)}\):

\[
  N\ge
  \left(
  \frac{\eta^2 k}
  {38Q^4\log^2|\Sigma|\,\log^2 k}
  \right)^{1+1/\lceil Q/\eta\rceil}.
\tag{226.11}
\]

For adaptive decoders, if \(\Lambda_\rho<2^{-Q}\), the Cheng--Li--Mao theorem converts
the same RLDC to a \(Q\)-query LDC at every radius

\[
  0<r<
  \frac{\rho}{2Q}(1-2^Q\Lambda_\rho).
\tag{226.12}
\]

### 3. Adaptive constant-soundness barrier

The low-soundness condition is not the only adaptive consequence.  If \(Q\) is constant,
\(\rho\) is a fixed positive radius, and

\[
  \Lambda_\rho\le 1-\sigma_0
  \qquad\text{for a fixed }\sigma_0>0,
\tag{226.13}
\]

then (226.5) is a constant-robustness adaptive RLDC: on every proof within the
\(\rho\)-ball, the decoder outputs either the requested bit or \(\bot\) with probability
at least \(\sigma_0\).  The sample-based structural theorem and relaxed-LDC lower-bound
corollary of Dall'Agnol--Gur--Lachish therefore give

\[
  N
  \ge
  k^{\,1+1/O(Q^2\log^2(Q+2))},
\tag{226.14}
\]

up to the fixed-alphabet and constant-parameter factors in their theorem.  Thus the
pathwise Lorenz closure rules out a near-linear adaptive common proof at ordinary
constant soundness as well; Cheng--Li--Mao is only the stronger low-soundness upgrade
to a full LDC.

### 4. Duality with profile-hitting lower bounds

The pathwise theorem is the upper-bound side of the profile-hitting method: every
corruption set is charged by its honest-path hitting probability.  To prove a stronger
lower bound, one must exhibit a family of *realizable* candidate proofs whose first
corruption hit forces the wrong output.  Average/list soundness alone does not provide
such candidate proofs; this is exactly the missing hypothesis isolated by the
profile-hitting propositions in the main paper.

## Boundary

The theorem assumes a fixed common proof map and exact honest-path correctness. It does
not turn ordinary dPCP list soundness, \(\forall i\,\exists\Pi_i\), or a per-coordinate
recompiled proof into a common proof. It also does not claim that RW or GMWZ supplies
the pathwise profiles at the address scale. The tightness example shows why an
incidence-only improvement is impossible; any further progress must exploit global
semantic coupling, distributional soundness, or a new code-theoretic restriction.

## Sources

* [Goldberg--Gur--Saraogi, Theorem 1](https://arxiv.org/html/2511.21659), for the
  arbitrary-distribution nonadaptive RLDC lower bound.
* [Cheng--Li--Mao, Theorem 1.4](https://arxiv.org/html/2603.03717), for the adaptive
  low-soundness RLDC-to-LDC transformation.
* [Dall'Agnol--Gur--Lachish, TR20-154](https://eccc.weizmann.ac.il/report/2020/154/),
  for the adaptive sample-based structural theorem and relaxed-LDC length consequence.
* [Exact Lorenz incidence profile](225-exact-lorenz-incidence-profile-rldc-barrier-2026-08-17.md),
  for the dPCP-incidence specialization.
