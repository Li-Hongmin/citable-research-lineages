> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Multicluster incidence-overlap gate for vertex-varying tags

## Purpose

The two-cluster overlap estimate in note 342 controls arbitrary vertex-varying
tags only through the quantity

\[
  \sum_v\max\{\nu_0(v),\nu_1(v)\}.
\]

The same argument has a finite-cluster form.  This matters for a direct-product
construction whose candidate labels are not binary: high-dimensional incidence
can force *all* heavy clusters to share almost the same vertex support, so a
vertex-varying tag cannot hide a large amount of cluster mass.  The statement is
source-independent at the counting level; the spectral corollary is the part that
uses an HDX inclusion operator.

## Multicluster theorem

Let \(U_1,\ldots,U_s\subseteq X_i(K)\) be pairwise disjoint clusters of face masses
\(\mu_1,\ldots,\mu_s>0\).  Sampling a face from \(U_a\) and then a uniformly
random vertex on that face induces a vertex distribution \(\nu_a\).  Define the
multicluster overlap

\[
  \mathsf{Ov}(\nu_1,\ldots,\nu_s)
  :=\sum_{v\in X_i(1)}\max_{1\le a\le s}\nu_a(v).
\tag{344.1}
\]

For the mass-weighted conclusion it is sharper to use

\[
  \mathsf{Ov}_{\mu}(\nu_1,\ldots,\nu_s)
  :=\sum_{v\in X_i(1)}\max_{1\le a\le s}\{\mu_a\nu_a(v)\}.
\tag{344.1a}
\]

Let a vertex word \(F\) carry a tag \(\tau_F(v)\in\{1,\ldots,s,\bot\}\).
For cluster \(a\), let \(\lambda_a(F)\) be the probability, over a random face
from \(U_a\), that \(F\) agrees with the prescribed cluster-\(a\) table on all
but a \(\zeta\)-fraction of its symbols.  Assume that a face counted by
\(\lambda_a(F)\) has at least a \(1-\zeta\) fraction of vertices carrying tag
\(a\); a tag mismatch costs at least one symbol error.  Then

\[
  (1-\zeta)\sum_{a=1}^s\lambda_a(F)
  \le \mathsf{Ov}(\nu_1,\ldots,\nu_s).
\tag{344.2}
\]

Consequently, with \(\mu_{\max}:=\max_a\mu_a\),

\[
  \sum_{a=1}^s\mu_a\lambda_a(F)
  \le
  \frac{\mu_{\max}}{1-\zeta}
  \mathsf{Ov}(\nu_1,\ldots,\nu_s).
\tag{344.3}
\]

The mass-weighted form is strictly sharper for nonuniform cluster masses:

\[
  \sum_{a=1}^s\mu_a\lambda_a(F)
  \le
  \frac{\mathsf{Ov}_{\mu}(\nu_1,\ldots,\nu_s)}{1-\zeta}.
\tag{344.3a}
\]

If the complement of \(\bigcup_aU_a\) contributes at most
\(\varepsilon_\star\) to the agreement mass of every candidate vertex word,
then any global-word guarantee of mass \(\kappa(\delta)\) obeys

\[
  \kappa(\delta)-\varepsilon_\star
  \le
  \frac{\mu_{\max}}{1-\zeta}
  \mathsf{Ov}(\nu_1,\ldots,\nu_s).
\tag{344.4}
\]

More precisely, the right-hand side in (344.4) can be replaced by
\(\mathsf{Ov}_{\mu}/(1-\zeta)\).

### Proof

For a face counted by \(\lambda_a(F)\), let \(g_a(A)\) be the fraction of its
vertices whose tag equals \(a\).  The assumption gives \(g_a(A)\ge1-\zeta\), and
hence

\[
  \mathbb E_{v\sim\nu_a}{\bf1}[\tau_F(v)=a]
  \ge (1-\zeta)\lambda_a(F).
\]

At each vertex only one tag can be present, so

\[
 \sum_{a=1}^s\mathbb E_{v\sim\nu_a}{\bf1}[\tau_F(v)=a]
 =\sum_v\sum_a\nu_a(v){\bf1}[\tau_F(v)=a]
 \le\sum_v\max_a\nu_a(v).
\]

This proves (344.2).  Multiplying by \(\mu_a\), summing, and using
\(\mu_a\le\mu_{\max}\) proves (344.3).  For (344.3a), multiply the
per-cluster inequality by \(\mu_a\) before summing.  At a fixed vertex,
\[
 \sum_a\mu_a\nu_a(v){\bf1}[\tau_F(v)=a]
 \le \max_a\{\mu_a\nu_a(v)\},
\]
because the tags are mutually exclusive.  Summing over \(v\) gives (344.3a).
The complement contributes at most \(\varepsilon_\star\), so subtracting it
from the total global-word agreement mass gives (344.4), and likewise its
mass-weighted refinement. \(\square\)

## Spectral incidence corollary

Let \(\mu_1\) denote the uniform vertex law, and suppose the weighted
\(X(1)\leftrightarrow X(K)\) inclusion operator has nontrivial singular value at
most \(\lambda_{K,1}\).  Expander mixing gives, for every cluster of mass
\(\mu_a\),

\[
  \operatorname{TV}(\nu_a,\mu_1)
  \le \frac{\lambda_{K,1}}{\sqrt{\mu_a}}.
\tag{344.5}
\]

The elementary inequality

\[
  \sum_v\max_a\nu_a(v)
  \le 1+\sum_{a=1}^s\operatorname{TV}(\nu_a,\mu_1)
\tag{344.6}
\]

therefore yields

\[
  \mathsf{Ov}(\nu_1,\ldots,\nu_s)
  \le 1+\lambda_{K,1}\sum_{a=1}^s\mu_a^{-1/2}.
\tag{344.7}
\]

In particular, if every cluster has mass at least \(\mu_\star\), then

\[
  \mathsf{Ov}(\nu_1,\ldots,\nu_s)
  \le 1+\frac{s\lambda_{K,1}}{\sqrt{\mu_\star}},
\qquad
  \kappa(\delta)-\varepsilon_\star
  \le
  \frac{\mu_{\max}}{1-\zeta}
  \left(1+\frac{s\lambda_{K,1}}{\sqrt{\mu_\star}}\right).
\tag{344.8}
\]

The weighted overlap admits a stronger spectral estimate.  Pointwise,
\[
 \max_a\{\mu_a\nu_a(v)\}
 \le \mu_{\max}\mu_1(v)
 + \sum_a\mu_a\bigl(\nu_a(v)-\mu_1(v)\bigr)_+.
\]
Consequently,
\[
 \mathsf{Ov}_{\mu}
 \le \mu_{\max}
 + \lambda_{K,1}\sum_{a=1}^s\sqrt{\mu_a}
 \le \mu_{\max}+\lambda_{K,1}\sqrt{s\mu_U},
\qquad \mu_U:=\sum_{a=1}^s\mu_a.
\tag{344.8a}
\]
Combining this with (344.3a) gives
\[
 \kappa(\delta)-\varepsilon_\star
 \le
 \frac{\mu_{\max}+\lambda_{K,1}\sum_a\sqrt{\mu_a}}{1-\zeta}.
\tag{344.8b}
\]

Thus the separated-tag escape is closed for every cluster count satisfying

\[
  \frac{s\lambda_{K,1}}{\sqrt{\mu_\star}}=o(1),
\tag{344.9}
\]

provided the proposed global-word mass exceeds the right side of (344.8).
For the GMWZ incidence estimate
\(\lambda_{K,1}=1/K+K^{O(1)}/d\), this gives a concrete high-order window
\(s(1/K+K^{O(1)}/d)=o(\sqrt{\mu_\star})\).  The theorem does not assert that
the published GMWZ construction supplies the required cluster decomposition or
that the remaining mass gap is automatically positive.

For nonuniform clusters, the sharper sufficient window is
\[
 \lambda_{K,1}\sqrt{s\mu_U}=o(\mu_{\max}),
\tag{344.9a}
\]
with the residual \(\mu_{\max}/(1-\zeta)\) term absorbed into the target mass
gap.  In the equal-mass regime this has the same order as (344.9), while for
highly nonuniform masses it can be strictly stronger.

## Boundary

The overlap theorem is a counting and incidence statement.  It does not close a
non-patchable global assignment, bind a connected cover sheet, or supply the RW
address-scale proof map.  If \(s\lambda_{K,1}/\sqrt{\mu_\star}\) is not small, the
bound records precisely the residual high-order incidence escape rather than ruling
it out.  This is the parameter that a future cover-aware or GMWZ-specific closure
theorem must improve.

## Relation to the main paper

The two-cluster case is Proposition 3.1 of
[Cover Obstructions for Shared-Top Direct-Product Tests](../../rw-jk-succinct-reconstruction/papers/03-cover-obstructions-for-shared-top-direct-product-tests/paper.md).
The present statement is its finite-cluster extension and is intended as a
source-checkable high-order incidence gate, not as a general dPCP impossibility
theorem.

## Sources

* GMWZ, arXiv:2512.12960, Theorem 2.9 item 3:
  <https://arxiv.org/html/2512.12960>.
* Project note 342, the two-cluster overlap-aware gate.
