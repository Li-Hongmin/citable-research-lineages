> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Near-linear OBDD 解压与 materialization barrier（2026-08-14）

## 结论

[note 086](086-near-linear-covering-decoder-must-be-nonlinear-and-nonsystematic-2026-08-14.md)
留下的问题是：是否存在

\[
G_q:\{0,1\}^q\to\{0,1\}^{2q},
\qquad |G_q|=q\operatorname{polylog}q,
\tag{1}
\]

覆盖所有 sufficiently-small circuit truth tables，并支持 JK recursion 所需的 normalized preimages。

本 note 得到一正一负两个严格结果。令

\[
N=2q=2^m.
\tag{2}
\]

第一，batch decompression 本身可以 near-linear：

\[
\boxed{
\begin{aligned}
L_{\mathrm{OBDD}}(t,m)&\le q
&&\Longrightarrow
&&\text{size-}t\text{ OBDD truth tables 可由 }N\operatorname{polylog}N\text{ decoder 覆盖},\\
L_{\mathrm{ANF}}(t,m)&\le q
&&\Longrightarrow
&&t\text{-sparse ANF truth tables 可由 }N\operatorname{polylog}N\text{ decoder 覆盖}.
\end{aligned}}
\tag{3}
\]

这些构造不逐 target node/gate 显式生成新的 \(N\)-bit truth-table bundle，而是用 global
sorting/join 或 subset transform 从压缩记录直接联合生成最终 \(N\) bits。因此“输出有 \(N\) bits”
或“要在全部 assignments 上求值”本身不蕴含 \(\Omega(Nt)\) cost。

第二，逐门 materialization 路线确实有近二次 barrier。对下面精确定义的 boundary-materializing
\(b\)-block simulator，若 program length 为 \(L\)，则

\[
\boxed{T_{\mathrm{gate}}\ge N\lfloor s/b\rfloor-L-O(1).}
\tag{4}
\]

若每个 \(b\)-gate macro 还由 literal Four-Russians dictionary 枚举全部 normalized block
behaviors，则

\[
\boxed{
T_{\mathrm{syn}}+L
=\Omega\!\left(
\frac{Ns\log\log(Ns)}{\log(Ns)}
\right).}
\tag{5}
\]

其中 \(T_{\mathrm{syn}}\) 是 gates 加 literal records/bits 的 syntax cost。当 \(N=2q\)、\(L\le q\)、
\(s=q/\operatorname{polylog}q\) 时，式 (5) 强制 \(T_{\mathrm{syn}}=q^{2-o(1)}\) 尺度，排除
near-linear literal syntax。但这个 lower bound **不适用于 unrestricted \(G_q\)**：纯 coverage 没有
gate-list encoder，且 unrestricted decoder 不必暴露任何 intermediate bundle。

所以新的最窄接口不是继续优化逐门 batch evaluation，而是寻找一个 representation class
\(\mathcal R\)，同时满足

\[
\boxed{
\begin{array}{c}
\text{每个目标 small circuit function 都有 }O(q)\text{-bit }\mathcal R\text{ description},\\
\mathcal R\text{ descriptions 可由 }q\operatorname{polylog}q\text{ circuit 联合解压},\\
\mathcal R\text{ 对 actual JK history 有 exponent-stable normalization}.
\end{array}}
\tag{6}
\]

OBDD 与 sparse ANF 分别满足第二行，但不满足第一行。本文没有证明 \(P\ne NP\)。

## OBDD 的 near-linear batch decoder

考虑一个固定 variable order 下、至多 \(t\) 个 nonterminal nodes 的 ordered read-once branching
program。每个 node record 包含 node id、level、0-child 与 1-child，共

\[
O(\log t+\log m)
\]

bits。全部 node table 因而只需

\[
L_{\mathrm{OBDD}}=O(t\log(t+m))
\tag{7}
\]

bits。若式 (7) 不超过 \(q\)，可把 table 与格式 bits 填入 decoder seed；malformed seeds 任意映射，
不影响 range coverage。

建立 \(N\) 个 query records

\[
(a,v_a),
\qquad a\in\{0,1\}^m,
\tag{8}
\]

初始 \(v_a\) 为 root id。对每个 level \(r\in[m]\)：

1. 把 \(N\) 个 query records 与 \(t\) 个 node-definition records 按
   \((\text{node id},\text{type})\) 排序，并令相同 id 的 definition 先于 queries；
2. 用 forward segmented propagation 把该 definition 的 child pair 广播给相同 id 的全部 queries；
3. 若 fetched node 的 level 为 \(r\)，按 assignment bit \(a_r\) 把 \(v_a\) 更新为相应 child；
   若该 node 跳过本层则保持 \(v_a\)，terminal ids 则 absorbing；
4. 按 assignment id 恢复 record order。

每个 record width 为 \(O(\log N)\)。Batcher-type sorting network 对 \(M=O(N)\) 个 records 使用
\(O(M\log^2M)\) comparators；一个 record comparator 有 \(O(\log N)\) circuit size。因此每层 cost

\[
O(N\log^3N),
\]

共 \(m=\log N\) 层，得到

\[
|G_q^{\mathrm{OBDD}}|=O(N\log^4N).
\tag{9}
\]

若 variable order 本身也编码在 seed 中，可在每层用 encoded variable index 从 \(a\) 选择 query bit；
这只再增加 polylog factor。终端 records 给出最后 output bit。故式 (9) 的 range 覆盖式 (7) 允许的
全部 OBDD truth tables。

该 construction 的关键是一次 join 同时服务全部 assignments；它没有为每个 OBDD node
materialize 完整 \(N\)-bit subfunction。

但 OBDD 不是一般 small-circuit canonical form。Bryant 的经典 OBDD 工作已明确指出 worst-case graph
size 可随变量数 exponential；因此式 (9) 不能推出式 (1)--(3) 对一般 circuits 的 coverage。

## Sparse ANF 的 near-linear batch decoder

一个 \(t\)-sparse algebraic normal form 写成

\[
f(x)=\bigoplus_{S\in\mathcal S}\prod_{i\in S}x_i,
\qquad |\mathcal S|\le t.
\tag{10}
\]

用 \(m\)-bit mask 编码每个 \(S\)，fixed-format description length
\(L_{\mathrm{ANF}}(t,m)=O(tm)\)。若 \(L_{\mathrm{ANF}}(t,m)\le q\)，先把这些
monomial records 与 \(N\) 个固定 mask records 排序，以 parity 合并 duplicates，得到 length-\(N\)
coefficient vector \(c\)。再执行 Boolean-lattice subset zeta transform：

\[
TT(f)[A]=\bigoplus_{S\subseteq A}c[S].
\tag{11}
\]

sorting/scatter cost 为 \(N\operatorname{polylog}N\)，式 (11) 只需 \(N\log N\) 个 XOR gates。因此

\[
|G_q^{\mathrm{ANF}}|=N\operatorname{polylog}N.
\tag{12}
\]

但极小 circuits 也可能有 dense ANF；例如 \(x_1\lor\cdots\lor x_m\) 的 ANF 含全部非空 monomials。
所以 sparse ANF 同样不覆盖一般 size-\(s\) circuits。

## Boundary-materialization lower bound

令 \(P\in\{0,1\}^L\) 是合法 fan-in-two gate-list program，描述 \(s\) 个 gates。每个 gate descriptor
可独立选择 constants \(0,1\)，也可投影任一 original variable。记

\[
V_{r,a}(P)
\]

为 gate \(r\) 在 assignment \(a\in\{0,1\}^m\) 上的值。固定 \(1\le b\le s\)，并令

\[
R=\{b,2b,\ldots,b\lfloor s/b\rfloor\}.
\]

称 simulator 是 boundary-materializing，若对每个 \(r\in R\)，其 circuit 中存在 \(N\) 条
designated wires，其 wire functions 恰为

\[
(V_{r,a})_{a\in\{0,1\}^m}.
\tag{13}
\]

program/control wires 可跨 coordinates 共享，外围 circuit 可任意 fan-in two。\(T_{\mathrm{gate}}\)
计每个产生新 wire function 的 operation，包含 negation；outputs 只能指定现有 wires，只有 \(O(1)\)
constants 免费。

对不同 pairs

\[
(r,a)\in R\times\{0,1\}^m,
\]

functions \(P\mapsto V_{r,a}(P)\) 两两不同且非恒定：

- 若 \(r\ne r'\)，选择合法 \(P\)，令 gate \(r\) 为 constant \(1\)、gate \(r'\) 为 constant \(0\)；
- 若 \(r=r'\) 而 \(a\ne a'\)，取一个区分 \(a,a'\) 的 input variable，并令 gate \(r\) 投影它；
- 把 gate \(r\) 在 constants \(0,1\) 间切换，得到非恒定性。

所以 circuit 必须承载 \(N|R|\) 个不同非恒定 wire functions。至多 \(L\) 个由 input wires 承担，其余
每个至少需要一个 gate，得到式 (4)。这不是 lane-by-lane 计费，而是 ordinary wire-function counting
加上“必须暴露 boundary bundles”的语法假设。

## Literal Four-Russians dictionary barrier

进一步要求每个 \(b\)-gate macro 使用显式 dictionary：对至多 \(2b\) 个 labeled boundary inputs 上、
size 至多 \(b\) 的每个 normalized block behavior，library 至少存一个 nonempty record，并把 records/bits
计入 cost。令 \(T_{\mathrm{syn}}\) 为 circuit gates 与 stored record bits 的 augmented syntax total；
因此 \(T_{\mathrm{syn}}\ge T_{\mathrm{gate}}\)。允许去重，但不允许用另一个 universal algorithm
替代 literal table。

取 \(r=\Theta(b)\) 个 \(x_i\) 与 \(r\) 个 \(y_j\)，并令 \(t=\lfloor b/3\rfloor\)。对每个含 \(t\) 条边的
\(E\subseteq[r]\times[r]\)，函数

\[
f_E=\bigvee_{(i,j)\in E}(x_i\land y_j)
\tag{14}
\]

只需 \(t\) 个 AND 与 \(t-1\) 个 OR gates，故 size 不超过 \(b\)。不同 \(E\) 给不同 functions：只令
\(x_i=y_j=1\) 且其余 inputs 为零即可检测 edge \((i,j)\)。因此 dictionary 至少有

\[
\binom{r^2}{t}=2^{\Omega(b\log b)}
\tag{15}
\]

records，故 \(T_{\mathrm{syn}}\ge2^{\Omega(b\log b)}\)。令
\(U=T_{\mathrm{syn}}+L\)。式 (4) 与 \(T_{\mathrm{syn}}\ge T_{\mathrm{gate}}\) 给

\[
U=\Omega(Ns/b),
\]

而式 (15) 给
\(b=O(\log(T_{\mathrm{syn}}+2)/\log\log(T_{\mathrm{syn}}+2))\)。若
\(T_{\mathrm{syn}}>Ns\)，式 (5) 已平凡成立；否则
\(\log T_{\mathrm{syn}}\le\log(Ns)\)，代回即得式 (5)。

式 (4)--(5) 覆盖逐门 bit-blast、显式 intermediate truth tables、bundle mux 与 literal
Four-Russians library。它们不覆盖 OBDD sorting/join、sparse-ANF transform 或任意不暴露 intermediate
bundles 的 global decoder。

## Universal normalization 的精确量词

令 \(D_{m,s}\subseteq\{0,1\}^L\) 是合法 circuit descriptions，定义

\[
\operatorname{BE}_{m,s}(d)=TT(C_d).
\tag{16}
\]

纯 coverage 只有

\[
\forall d\in D_{m,s}\ \exists u_d:\quad
G_q(u_d)=\operatorname{BE}_{m,s}(d).
\tag{17}
\]

要组成 batch evaluator，最弱的额外量词是存在单一 normalized bit selector

\[
\exists N_q\ \forall d\in D_{m,s}:\quad
G_q\bigl(N_q(d,1)\cdots N_q(d,q)\bigr)
=\operatorname{BE}_{m,s}(d).
\tag{18}
\]

若 \(|G_q|=S(q)\)、\(|N_q|=E(q)\)，则复制 \(q\) 份 \(N_q\) 并 hardwire \(\ell\)，得到

\[
\boxed{
\operatorname{CC}(\operatorname{BE}_{m,s})
\le S(q)+qE(q)+O(q).}
\tag{19}
\]

若 selector 是直接输出完整 code 的 shared multi-output circuit \(\widehat N_q\)，则

\[
\operatorname{CC}(\operatorname{BE}_{m,s})
\le S(q)+|\widehat N_q|.
\tag{20}
\]

项目参数 \(q=n^{\Theta(k(n))}\)、\(k(n)\to\infty\) 下，fixed-\(n^C\) bit selector 满足

\[
E(q)=n^C=q^{o(1)}.
\]

若 \(S(q)=q^{1+o(1)}\)，式 (19) 因而给出

\[
\operatorname{BE}_{m,s}\in\operatorname{SIZE}(q^{1+o(1)}).
\tag{21}
\]

要排除 universal normalization，需要相应的 explicit multi-output/direct-sum superlinear lower bound；
note 086 的 singleton counting 只有 linear strength。

actual-history whole-tree labeling 的量词更弱：

\[
\forall n\ \exists D_n
\]

只对一个 fixed initial history 及 descendants 正确。即使 global coverage 同时成立，它也不把 circuit
description \(d\) 作为变量输入，故不能构造式 (18)。同样，

\[
\forall d\ \exists N_{q,d}
\]

不能交换成 \(\exists N_q\ \forall d\)。因此不能把 JK 所需的 history-relative closure 偷换成更强的
universal encoder。

## 路线裁决

本 note 改变两项决策：

1. **停止优化 materializing evaluator。** 式 (4)--(5) 已给该架构足够强的 restricted lower bound。
2. **保留 global decompression。** 式 (9) 与式 (12) 证明 near-linear batch generation 可以真实发生；
   应寻找比 OBDD/sparse ANF 更强、对 general small circuits 覆盖的 canonical representation。

下一步不是证明式 (18) 的 universal normalization；那会把问题升级到式 (21) 的 explicit batch lower
bound。JK 路线只需 actual-history representation closure，量词必须保持较弱。

### 文献边界

检索与 metadata/abstract 核验截止：2026-08-14。

- Kenneth E. Batcher, *Sorting Networks and Their Applications*, AFIPS Spring Joint Computer
  Conference, 1968, DOI `10.1145/1468075.1468121`。本轮为 metadata anchor；式 (9) 的 circuit-size
  accounting 在本文自足给出。
- Randal E. Bryant, *Graph-Based Algorithms for Boolean Function Manipulation*, IEEE Transactions on
  Computers 35(8), 1986, DOI `10.1109/TC.1986.1676819`。摘要直接支持 ordered DAG representation
  及 worst-case exponential size 边界；本文的 batch decoder 是项目新构造。

式 (3)--(21) 中的 constructions、restricted lower bounds 与 quantifier separation 均为本项目推论，
不冒充 unrestricted circuit lower bound。
