> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Choice-robust JK 删除 lex-first output 障碍（2026-08-14）

## 结论

[note 082](082-time-dominating-blocks-have-locally-uniform-preimages-2026-08-14.md) 证明：放大 block
parameter 后，原 stitched systematic output 的每个 range block 都有一个固定、word-consistent、
locally uniform preimage；但该 note 保留了“它不一定是 lexicographically first preimage”的疑问。

本 note 证明这个疑问不是 Jeřábek--Korten easy reconstruction 的数学障碍。JK/GGM reduction 对每个
range block 可任取 preimage；只要每个 occurrence 的 \(q\) 个输出 bits 联合描述同一个合法 word，
最终 easy circuit 的正确性与 size 都不变。lex-first 的作用是提供一个方便的 deterministic selector，
以及 Li 2024 所需的唯一 history / single-valued certification；它不是 GGM 代数重构所必需。

因此 note 082 的边界应修正为

\[
\boxed{
\begin{array}{ll}
\text{stitched systematic output 的 fixed compact selector：}&\text{已证明；}\\
\text{lex-first output preimage 是否 compact：}&\text{不再是必需接口；}\\
\text{auxiliary PCP / recursive JK blocks 的 fixed compact selector：}&\text{unknown。}
\end{array}
}
\tag{1}
\]

这个结果不闭合 \(P\) versus \(NP\)：完整 JK tree 仍含非系统 Reed--Muller coordinates、PCP
auxiliary oracles 和递归产生的 blocks。对这些 occurrences，目前既没有 fixed compact selector，也没有
可局部认证的替代关系。

## Choice-robust JK lemma

令

\[
G:\{0,1\}^q\to\{0,1\}^{2q},
\qquad
G(x)=G_0(x)G_1(x),
\]

其中 \(G_0,G_1:\{0,1\}^q\to\{0,1\}^q\)。给定

\[
f'\in\{0,1\}^{q2^h},
\]

置 \(y_h=f'\)。在 stage \(i=h,h-1,\ldots,1\)，写

\[
y_i=z_{i,1}\cdots z_{i,2^{i-1}},
\qquad |z_{i,j}|=2q.
\tag{2}
\]

若某个 \(z_{i,j}\notin\operatorname{Range}(G)\)，它就是合法 AVOID output。否则，对每个 occurrence
\((i,j)\) 任取

\[
x_{i,j}\in G^{-1}(z_{i,j})
\]

并定义

\[
y_{i-1}=x_{i,1}\cdots x_{i,2^{i-1}}.
\tag{3}
\]

逐 stage 恒有

\[
y_i=G^{\otimes 2^{i-1}}(y_{i-1}),
\tag{4}
\]

与 \(x_{i,j}\) 是否 lex-first 无关。因此若所有 stages 都在 range 内，最终 \(y_0\in\{0,1\}^q\)
满足：将 \(y_0\) hardwire，并对一个 output address \(b_1\cdots b_h\) 依次计算

\[
G_{b_h}(G_{b_{h-1}}(\cdots G_{b_1}(y_0)\cdots)),
\tag{5}
\]

即可读出 \(f'\) 的相应 \(q\)-bit block，再以固定 selector 读取 block 内 coordinate。所得 circuit size
为

\[
O((|G|+q)h)=O(|G|\log(|f'|/q)).
\tag{6}
\]

这正是 Ren--Williams Theorem 3.1 中的 JK easy bound；最后的 block-coordinate selector 只增加
\(O(q)\)，由 \(|G|\ge q\) 吸收。式 (4)--(6) 只使用

\[
G(x_{i,j})=z_{i,j};
\]

没有使用 minimality、不同 occurrences 对同一个 \(z\) 选相同 preimage，或任何全局 ordering。
相同 block 出现在树的两个节点时可以选择不同 preimages；它们仍是两个不同 occurrences，式 (4)
逐节点成立。不同选择可能让下一层出现 published lex-history 中没有的 non-image，从而把原 easy branch
改成 hard branch；该 block 本身仍是合法 AVOID output。因此不变的是总搜索的 hard/easy dichotomy
及其正确性，不是每个输入走入的原分支。

## 固定 selector 的充分条件

代数存在性与算法化必须区分。对固定的 \(G\)，一个可替换 lex-first search 的 selector
\(S=S_G\) 至少应是 fixed total deterministic function

\[
S(i,j,z,\ell)\in\{0,1\},
\qquad \ell\in[q],
\]

并满足对每个 actual range occurrence

\[
\exists u_{i,j,z}\in\{0,1\}^q:\quad
u_{i,j,z}=S(i,j,z,1)\cdots S(i,j,z,q)
\ \land\ G(u_{i,j,z})=z.
\tag{7}
\]

式 (7) 的 word-level consistency 是承重点。逐 bit 的

\[
\forall\ell\ \exists u_\ell\in G^{-1}(z):
S(i,j,z,\ell)=u_\ell[\ell]
\tag{8}
\]

不够，因为不同 \(u_\ell\) 的 bits 拼起来未必仍是 preimage。

若 \(S\) 每 bit 在时间 \(\tau\) 内计算，则各 stage labels 的总长度是 \(O(|f'|)\)，物化它们的总耗时

\[
O(|f'|\tau),
\]

仍为 \(\operatorname{poly}(|f'|,|G|)\)，只要 \(\tau\) 是显式参数的 polynomial。若 \(S\) 不发出
NP queries，它不会增加 JK 的 NP round complexity；range/non-range queries 仍先检测 actual block
是否属于 promise domain。\(S\) 在 non-range inputs 上可以任意 totalize；式 (7) 的保证只在
membership 检测通过后调用。

若 \(S\) 使用 prMA promise oracle，则还需两项独立条件：actual execution 的每个 query 都在 promise
内；同一个 fixed advice/oracle execution 对全部 \(\ell\) 给出式 (7) 的同一个 word。smartness 本身
不自动提供 word consistency，但一个 deterministic smart machine 加固定 advice 一旦满足式 (7)，其
output 已是 single-valued，不必再要求 \(u\) 为 lex-first。

## 对 stitched output 的直接推论

note 082 不只证明逐块

\[
\exists u\in G_q^{-1}(B)
\]

有小 accessor；它给出了一个 fixed tableau-description generator：给定 \((n,k,j,\ell)\)，统一输出
第 \(j\) 个 systematic output block 所选 preimage 的第 \(\ell\) bit。canonical gate numbering 与
padding rule 保证所有 bits 描述同一个 word。因此它已经满足式 (7)，且

\[
\tau=\operatorname{poly}(n,k,\log R).
\tag{9}
\]

在 choice-robust JK 中，可对这些 occurrences 使用该 fixed selector，对其余 blocks 暂时保留
published lex-first selector。所得 hybrid history 仍是 deterministic、word-consistent 的合法 JK
history；有效的 hard/easy dichotomy 与式 (6) 不变，但具体 branch 可以改变。若 hybrid choice 产生
新的 hard outsider，还必须另行证明该 outsider 可由目标 succinct algorithm 输出；仅有 systematic
output selector 不提供这个 auxiliary-accessor 性质。

所以 exact stitched output 的 canonicalization 不再是剩余接口。真正的第一处缺口位于 output 之后：

\[
\text{raw intermediate values}
\to\text{non-systematic RM coordinates}
\to(P,\Pi_{ZoS})
\to\text{recursive JK blocks}.
\tag{10}
\]

尤其，small raw-witness accessor 不推出 small Reed--Muller accessor。一般非系统坐标是对长 witness 的
有限域线性组合；直接求值需要聚合 \(|w|\) 个 symbols。\(P=NP\) 不蕴含相应的 counting / Mod-\(p\)
collapse。因此不能仅把 note 082 的 selector 线性编码后宣称 auxiliary blocks 也已 locally accessible。

## 与文献中 lex-first 的实际关系

原文核验日期：2026-08-14。

- Korten 2021 Definition 15 的 inverter 只要求“produces such an \(x\) if it exists”。Theorem 7 从
  leaves 向 root 逐层取 preimages；若从未遇到 non-image，就得到 root seed 并构造 size
  \(O(|G|\log T)\) 的 easy circuit。没有 lex-min 要求。这是式 (2)--(6) 的原始先例。
- Li 2024 Section 1.2.3 footnote 2 明确说明：Korten 原 reduction 没有指定 lexicographically first；
  该条件对 CHR 与 Li 获得 single-valued algorithm 重要。Li Algorithm 1、Lemma 3.8 与 Lemma 4.2
  用 lex order 固定并比较 histories；该用途不能仅由逐块存在性替代。
- Ren--Williams 2026 Theorem 3.1 的 published implementation 取 lex-smallest preimages，但 easy
  circuit proof 只使用式 (4)。其 Theorem 5.1 proof sketch 进一步明确：searchSAT 返回的 witnesses
  可以不是 lex-largest；只需 computational history 有 lex-largest possible short control prefix，
  Theorem 4.1 的 reconstruction 仍成立。

因此准确边界是

\[
\boxed{
\text{lex-first per-block witnesses 可替换；}
\quad
\text{fixed / single-valued control data 不可删除。}
}
\tag{11}
\]

### 来源

- Oliver Korten, *The Hardest Explicit Construction*, FOCS 2021, Definition 15 and Theorem 7.
- Zeyong Li, *Symmetric Exponential Time Requires Near-Maximum Circuit Size*, STOC 2024,
  arXiv:2310.17762, Section 1.2.3 footnote 2, Algorithm 1, Lemmas 3.8 and 4.2.
- Hanlin Ren and Ryan Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin-Arthur Queries*, ECCC TR26-118 revision 1, 2026, Theorems 3.1, 4.1 and 5.1.

文献直接支持 arbitrary-preimage GGM reconstruction 与 lex-first 的 single-valued用途。式 (7)--(10)
是本项目对 compact selectors、word consistency 与 stitched/RW 对象的组合推论。本文不声称已经证明
\(P\ne NP\)。
