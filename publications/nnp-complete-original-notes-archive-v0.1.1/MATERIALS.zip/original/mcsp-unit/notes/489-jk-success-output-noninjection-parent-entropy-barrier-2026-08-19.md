> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK success 输出的 parent 非注入与熵下界（2026-08-19）

## 本轮改变的判断

C372 只从 Theorem 4.1 的接口语义说明 outsider 不自动绑定 parent。现在可以把这
个边界推进到 Ren--Williams 所实际调用的 Jeřábek--Korten 过程本身：存在一个
显式的、P-uniform 的 AVOID family，使得大量不同的 parent truth tables 都让
JK 在第一层输出同一个 outsider。因而任何对整个 parent family 都有效的
“success-output 是 parent fingerprint”定理，必须额外携带至少线性于 parent
长度的 descriptor/proof 信息。

这不是 published RW singleton 的无条件不可能性：Theorem 4.3 每个长度只固定一个
parent \(f_i(x_0)\)。它关闭的是把 JK 的 generic success semantics 黑箱地当成
singleton parent-binding 的路线。

## 显式 JK 实例

令 \(n\ge 1\)，\(k\ge 2\)，并取 P-uniform generator

\[
  G_n(u):=0^n u,\qquad u\in\{0,1\}^n.
  \tag{489.1}
\]

它的 range 恰为
\[
  \operatorname{Range}(G_n)=\{0^n v:v\in\{0,1\}^n\},
\]
大小为 \(2^n\)，且可由 \(O(n)\)-size circuit 实现。令
\[
  T:=n2^k,\qquad y:=1^n0^n.
\]

把长度 \(T\) 的 parent truth table 分成 \(2^{k-1}\) 个连续的 \(2n\)-bit blocks。
定义 family \(\mathcal F_{n,k}\subseteq\{0,1\}^T\)：

\[
  f(v_2,\ldots,v_{2^{k-1}})
  :=
  y\;\Vert\;0^n v_2\;\Vert\;\cdots\;\Vert\;0^n v_{2^{k-1}},
  \qquad
  v_j\in\{0,1\}^n.
  \tag{489.2}
\]

所以
\[
  |\mathcal F_{n,k}|=2^{n(2^{k-1}-1)}
  =2^{T/2-n}.
  \tag{489.3}
\]

## 定理 489.1（JK success-output non-injection）

对每个 \(f\in\mathcal F_{n,k}\)，运行 Ren--Williams 文本中 Theorem 3.1 的
Jeřábek--Korten algorithm on \((G_n,f)\)。由于 \(T=n2^k\)，其第一阶段的 current
string 为 \(y_k=f\)，并被分成 \(2^{k-1}\) 个 \(2n\)-bit blocks。第一块 \(y\)
不在 \(\operatorname{Range}(G_n)\)，而所有其余 blocks \(0^n v_j\) 都在
\(\operatorname{Range}(G_n)\)。因此第一阶段出现唯一的 NO range-membership query，
算法立即输出

\[
  \operatorname{JK}(G_n,f)=y
  \qquad\text{for every } f\in\mathcal F_{n,k}.
  \tag{489.4}
\]

特别地，JK success output 对 parent family 的 fiber 至少有大小
\[
  2^{T/2-n}.
  \tag{489.5}
\]

### 证明

Theorem 3.1 的证明从 \(y_k=f'\) 开始；这里 \(T'=T\)，所以没有 padding。第一阶段
按连续 \(2n\)-bit blocks 形成 range-membership SAT queries。对 (489.2)，第一块
\(1^n0^n\) 不可能等于 \(0^n u\)，而每个后续块 \(0^n v_j\) 都等于
\(G_n(v_j)\)。故只有第一块的 SAT query 返回 NO，按照定理的 success branch 立即
返回该 block \(y\)。这对所有 suffix choices 同时成立，得到 (489.4)；计数给出
(489.5)。证毕。

## 推论 489.2（generic parent-binding 的 descriptor 下界）

令 \(\sigma_f\in\{0,1\}^{d}\) 是一个可能依赖 \(f\) 的 static descriptor，并令同一
evaluator \(D\) 对所有 \(f\in\mathcal F_{n,k}\)、所有地址 \(j\in[T]\) 满足

\[
  D(j;y,\sigma_f)=f[j].
  \tag{489.6}
\]

则 \(f\mapsto\sigma_f\) 必须是 injective，因而

\[
  d\ge \log_2|\mathcal F_{n,k}|=T/2-n.
  \tag{489.7}
\]

更一般地，若 descriptor alphabet 为 \(\Sigma\)，则
\[
  d\log_2|\Sigma|\ge T/2-n.
  \tag{489.8}
\]

### 证明

若 \(f\ne f'\) 却有 \(\sigma_f=\sigma_{f'}\)，则 (489.6) 对任意两者不同的地址
给出同一个 \(D(j;y,\sigma)\) 同时等于 \(f[j]\) 与 \(f'[j]\)，矛盾。因此 descriptor
必须区分 \(|\mathcal F_{n,k}|\) 个 parents，得到 (489.7)--(489.8)。证毕。

## 与 RW Closure 的精确关系

1. **关闭 generic JK fingerprint 路线。** 仅知道
   \(Y=\operatorname{JK}(G,f)\notin\operatorname{Range}(G)\)，甚至知道 \(Y\) 是
   JK 第一层返回的唯一 outsider，都不能给出对整个 parent family 的 binding；
   同一个 \(Y\) 可对应 \(2^{T/2-n}\) 个 parents。
2. **连接 C487/C471。** 若 proposed Closure 要把这类 success output 绑定到
   family 中的 parent，必须携带至少 \(T/2-n\) bits 的 target-dependent descriptor，
   或者改用一个不再是 static finite-view/same-proof 的 global relation。前者进入
   C487 的 charged/object-scale 支；后者是 C487/C450 的 genuine model exit。
3. **不静默套到 published singleton。** RW Theorem 4.3 的实际递推在每个长度只
   选定一个 \(f_i(x_0)\) 和一个 \(B_{i+1}\)。因此 (489.7) 不能单独推出该固定
   singleton 的 descriptor 下界；要关闭 singleton，仍需证明该 fixed parent 落入
   一个 family、或另有 parent-specific support/forcing theorem。
4. **不能把 child hardness 转成 parent hardness。** (489.4) 的 y 是 child AVOID
   outsider；它对 suffix parent bits 完全不敏感。故从 child 的 range avoidance 不能
   自动得到 parent 的 whole-word evaluator 或 \(P/\mathrm{poly}\) 模拟。

## 证据边界

* (489.1)--(489.4) 直接使用 Ren--Williams extracted text 中 Theorem 3.1 proof：
  \(y_k=f'\)、连续 \(2n\)-bit blocks，以及遇到 NO range query 即返回对应 block。
* generator \(G_n(u)=0^n u\) 是显式 P-uniform、size \(O(n)\) 的 family；本结果不是
  任意 generator 的平均性质。
* 本结果是 JK family-level parent-binding barrier，不是 published RW singleton
  的无条件不可能性，也不是一般 AVOID/PCP/RLDC 下界或 \(P\ne NP\) 证明。

## 来源

* Ren--Williams, ECCC TR26-118 rev.1, Theorem 3.1 proof；本地抽取
  units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md
  第 498--558 行。
* [C372 RW Solve-success parent--child semantic exit](372-rw-solver-success-semantic-exit-2026-08-18.md)。
* [C450 scale-complete RW Closure normal form](450-scale-complete-rw-closure-normal-form-2026-08-19.md)。
* [C487 solver-success parent-binding/support trichotomy](487-rw-solver-success-parent-binding-support-trichotomy-2026-08-19.md)。
