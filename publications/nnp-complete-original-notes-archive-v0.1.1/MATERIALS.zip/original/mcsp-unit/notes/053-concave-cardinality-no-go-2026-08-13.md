> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 凹命中数势的平均 no-go（2026-08-13）

设 \(F(R)=f(|R|)\)，其中 \(f:[0,m]\to\mathbb R_{\ge0}\) 单调凹且 \(f(0)=0\)。定义

\[
K(R)=f(|R|)-\frac{f(m)}m|R|.
\]

由于 \(f\) 凹且过原点，\(f(s)\ge(s/m)f(m)\) 对每个 \(0\le s\le m\) 成立。因此逐叶已经有 \(K(R)\ge0\)，不仅平均非负；其 QA 次可加性来自凹函数的次可加性
\(f(a+b)\le f(a)+f(b)\)。

故任何只依赖命中数的平滑凹势（\(\sqrt{|R|}\)、\(\log(1+|R|)\)、分数幂、熵上界等）都不可能在叶上产生负补偿。要有负叶势，命中函数必须具备非凹的高阶负项；固定阶这类势已由 thinning 界关闭，剩余仍需全局非 XOS 状态。

