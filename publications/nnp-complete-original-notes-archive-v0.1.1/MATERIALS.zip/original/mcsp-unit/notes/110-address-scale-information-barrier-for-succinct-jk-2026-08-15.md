> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Succinct JK 的地址尺度信息障碍（2026-08-15）

## 结论

note 109 把显式 tree-rich 输入压缩成了 random-access group search，但其运行时间仍以
decoder block 参数 \(q\) 为尺度。这里把这个限制拆成两个不可混淆的事实：

\[
\boxed{
\begin{array}{ll}
\text{把全部 }A^L\text{ groups 逐个编码时的 group index:}&
  \text{信息长度严格大于 }q;\\
\text{显式返回一个 non-range block:}&
  \text{输出长度为 }2q.
\end{array}}
\tag{1}
\]

因此在 \(q=2^{m-1}\) 时，note 109 的 \(\operatorname{poly}(q)\) 算法不能直接改写为
\(\operatorname{poly}(m)\) 的算法。要达到地址长度 \(m\) 的目标，必须完全避免显式 group
witness 和 \(2q\)-bit outsider 的输出，改为一个新的 succinct circuit-valued
nonmembership 结构；这不是由 tree-capacity 注入自动给出的。

## Group witness 的信息长度

令 \(G_q:\{0,1\}^{q}\to\{0,1\}^{2q}\)，
\(R_q=\operatorname{Range}(G_q)\)，令 \(A\subseteq R_q\) 且
\(M=|A|\)。对 \(L=2^h\) 个叶的 tuple family \(A^L\)，任何单射的 group
编码

\[
\operatorname{Enc}:A^L\hookrightarrow\{0,1\}^{r_{\mathrm{grp}}}
\]

都满足

\[
r_{\mathrm{grp}}
\ge \left\lceil\log_2|A^L|\right\rceil
=\left\lceil L\log_2M\right\rceil.
\tag{2}
\]

若使用 note 109 的容量 forcing 条件

\[
M^L>2^q,
\tag{3}
\]

则必有

\[
r_{\mathrm{grp}}>q.
\tag{4}
\]

这不是电路下界，只是对“逐个 group 作为存在性见证”的不可压缩性：一个
\(\operatorname{poly}(m)\)-bit group witness 在 \(q=2^{m-1}\) 时至多命名
\(2^{\operatorname{poly}(m)}\) 个 groups，不能单射地覆盖满足式 (3) 的
\(A^L\)。

对 note 109 的低电路 family \(A_d\)，有

\[
\log_2|A_d|=2^d.
\]

选择 \(L\) 使 \(q<L2^d\le2q\) 时，式 (2) 给出
\(r_{\mathrm{grp}}\in(q,2q]\)。因此该实例的 random-access index 已经处于
\(q\)-bit 级别；它不是地址长度 \(m\) 上的 succinct witness。

## 固定宽度 injective group index 的 INDEX 电路下界

上面的式 (2)--(4) 是信息长度记账；若 group 由固定宽度的索引单射编码，并且编码结果
有一个统一随机访问器，还可以得到一个更强、完全无条件的电路下界。先看 note 109
使用的低电路族：令 \(A_d\) 是全部 \(d\)-变量 truth tables，令
\(L=2^h\)，并把一个 group index 写成

\[
 j=(j_{t,b})_{1\le t\le L,\;1\le b\le 2^d},
 \qquad |j|=r=L2^d.
\]

对每个 full \(2q\)-bit 坐标，只读取其 \(d\)-bit 投影
\(\operatorname{low}_d(b)\)；限制到每个投影的一份代表坐标后，叶 accessor 是

\[
 I_r(j,t,b)=j_{t,b}.
 \tag{2a}
\]

这里把 \(t,b\) 作为二进制 selector 输入，\(j\) 的 \(r\) 个位作为 data inputs。
每个 data input \(j_{t,b}\) 都是 essential 的：固定 selector 为 \((t,b)\) 后，输出
恰为该位。于是任何标准 fan-in-two Boolean circuit 计算 \(I_r\) 至少需要

\[
 \operatorname{CC}(I_r)\ge r-1.
 \tag{2b}
\]

证明是最基本的 support-counting：一个 fan-in-two gate 至多把两个此前分离的 input
supports 合并成一个；若输出依赖 \(r\) 个互相独立的 data inputs，至少需要 \(r-1\)
个产生新 wire-function 的 gates。NOT、常量和 selector wires 不会降低这个下界。

容量 forcing 取 \(L2^d>q\) 时，式 (2b) 给出

\[
 \operatorname{CC}(I_r)>q=2^{m-1}.
 \tag{2c}
\]

因此，在**原始 tuple-indexed、逐位读取 leaf table** 的模型中，叶 accessor 不仅不能
用 \(\operatorname{poly}(m)\) 电路实现，甚至至少是 decoder block seed 长度的线性规模。
把 note 082 的 time-to-circuit preimage 构造用于该 accessor 还会遇到更强的尺度冲突：
其门数/运行时间至少为 \(\Omega(r)\)，而局部 preimage 引理要求（对固定 \(\gamma>1\)）
类似 \(R^\gamma\lesssim q/\log q\) 的预算；这里 \(r>q\)，故该条件在大 \(q\) 时不可能成立。

上述线性下界其实不依赖 \(A_d\) 的原始布局。设任意
\[
 E:\{0,1\}^{r}\hookrightarrow\{0,1\}^{B}
\]
是 group 的固定宽度单射编码，并令
\[
 \operatorname{Acc}_E(j,k)=E(j)[k],
 \qquad k\in[B],
 \tag{2d}
\]
由一个 fan-in-two circuit 计算。对每个索引位 \(j_i\)，单射性保证存在某个
\(x\in\{0,1\}^{r}\) 使 \(E(x)\ne E(x\oplus e_i)\)；否则 \(E\) 在一条 \(i\)-方向边上
恒等，会与单射矛盾。于是存在输出坐标 \(k_i\) 使
\(\operatorname{Acc}_E(\,\cdot\,,k_i)\) 依赖 \(j_i\)。因此 \(\operatorname{Acc}_E\) 的
\(r\) 个 data inputs 全部 essential，和前面的 support-counting 一样得到
\[
 \operatorname{CC}(\operatorname{Acc}_E)\ge r-1.
 \tag{2d'}
\]
当 \(E\) 在整个 \(\{0,1\}^{r}\) 上总定义且单射地命名全部 \(A^L\) groups（特别是
note 109 的 \(A_d\)，因为 \(M^L=2^{L2^d}\)），并且
\(r\ge\lceil L\log_2 M\rceil>q\) 时，任何这种**固定宽度、逐位随机访问的
tuple-indexed encoding** 都不能在地址长度 \(m\) 上由 \(\operatorname{poly}(m)\) 电路读取。
若 \(E\) 只在一个非满的 valid-index 子集上单射，式 (2d') 需要先给出保持单射的
全域 totalization；否则只能从实际证明为 essential 的索引位得到较弱下界。
更精确地，对承诺域 \(S\subseteq\{0,1\}^{r}\) 定义
\[
 \Delta(S)=\{i:\exists x,\ x\in S,\ x\oplus e_i\in S\}.
\]
若 \(E\) 仅要求在 \(S\) 上单射且 \(\operatorname{Acc}_E\) 只在
\(S\times[B]\) 上正确，则同一 support 论证给出
\(\operatorname{CC}(\operatorname{Acc}_E)\ge|\Delta(S)|-1\)。
当 \(r=\lceil\log_2|S|\rceil\) 且 \(|S|>2^{r-1}\) 时，\(\Delta(S)=[r]\)，
于是仍恢复 \(r-1\) 下界；真正可能逃逸的是过宽地址或稀疏 valid domain。
要绕过该下界，必须放弃至少一个条件：不显式单射命名全部 groups、没有统一逐位 accessor，
或改用不把 group index 当作电路输入的结构化/代数不变量。此推广仍不是 unrestricted
decoder 的一般电路下界；它只精确排除固定宽度 injective random-access forcing 模型。
这里的 accessor 必须是一个统一的单输出电路 \(C(j,k)\)；若每个固定 \(k\) 另给一个
独立电路，或只提供 word-level/oracle indexing primitive，式 (2d') 不适用。

## 显式 outsider 的输出长度

若搜索算法的输出规范是显式给出一个
\(z\in\{0,1\}^{2q}\setminus R_q\)，在标准 bit-output 模型中仅写出 \(z\) 就需要

\[
\Omega(2q)=\Omega(2^m)
\tag{5}
\]

个输出步骤。故即使 nonmembership 判定本身属于某个固定 PH 层，也不能由此得到
\(\operatorname{poly}(m)\)-时间的显式 outsider generator。

把输出改成一个短电路 \(H_m:\{0,1\}^{m}\to\{0,1\}\) 并要求
\(TT(H_m)\notin R_q\)，可以绕过式 (5)，但这增加了一个新的证明义务：

1. 从 \(G_q\)、group family 和 PH search 构造 \(H_m\) 的统一电路；
2. 证明 \(H_m\) 的 truth table 确实逐位等于某个 non-range block；
3. 在不展开 \(2q\) 位的情况下验证该 nonmembership。

note 109 的 root-injectivity 只证明“某个 group 的某个节点不在 range”，不提供这三个
succinct circuit-valued 接口。

## 对 \(P\) versus \(NP\) 路线的严格裁决

由式 (2)--(5) 可排除以下偷换：

\[
\text{把 }\operatorname{poly}(q)\text{ 的 group search}
\quad\not\Rightarrow\quad
\text{把它当作 }\operatorname{poly}(m)\text{ 的 hard-table generator}.
\]

但不能把该信息/INDEX 障碍加强成所有结构化算法的 lower bound。一个特殊的 \(G_q\) 和
group family 可能不把 group index 作为逐位 accessor 的电路输入，而是存在代数不变量
直接给出一个短 \(H_m\)；式 (2) 与式 (2d') 排除的是固定宽度、injective、逐位随机访问的
group forcing 模板。

因此当前真正的二分是：

\[
\begin{array}{c|c}
\text{路线} & \text{状态}\\ \hline
\text{tuple-indexed random-access forcing} &
\text{已得 }\mathrm{FP}^{\Sigma_2^P}\text{，但尺度为 }q\\
\text{固定 decoder 的 succinct circuit-valued outsider} &
\text{仍 unknown}\\
\text{由此推出 }P\ne NP &
\text{仍未建立}
\end{array}
\]

下一步若继续正面构造，必须寻找不依赖固定宽度 injective random-access index、且能直接
生成短 \(H_m\) 的固定代数/电路结构；若继续负面路线，则应把式 (2d') 结合具体的
succinct access 模型，而不能宣称一般 Boolean circuit lower bound。

### 来源与证据边界

- note 106：tree-capacity root injectivity；
- note 108：显式 tree-rich 输入长度障碍；
- note 109：random-access tuple forcing 的 \(\mathrm{FP}^{\Sigma_2^P}\) 上界。

式 (2)--(5) 及式 (2d') 是本项目的自足信息/输出长度推导，不声称证明一般
\(P\ne NP\)，也不把固定 decoder 的 circuit lower bound 当作已知结果。
