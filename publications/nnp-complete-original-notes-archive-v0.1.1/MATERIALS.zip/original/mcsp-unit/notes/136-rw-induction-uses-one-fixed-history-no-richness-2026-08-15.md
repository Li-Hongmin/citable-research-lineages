> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Ren--Williams 迭代实际只使用一个固定 history：不能从输入变化推出 pair-richness（2026-08-15）

## 结论

Ren--Williams 的 Theorem 4.1 对一般的多输出函数 \(f(x)\) 给出逐输入的
PCP-history/AVOID 二分；但其 Theorem 4.3 的 lower-bound induction 实际把每一层的
函数定义成**常值函数**。因此该 induction 没有从不同输入 \(x\) 获得一族不同的
PCP proofs 或 JK leaf blocks。由 Theorem 4.1 本身不能推出本项目需要的

\[
|A|^{2^h}>2^q
\quad\text{或任何同类 pair/tree-richness。}
\tag{1}
\]

这不是说单个固定 proof 的内部 blocks 不可能丰富；只是现有定理没有给出这种结构性
丰富性。

## 逐层核对

在 Theorem 4.3 的 induction 中，固定起点

\[
x_0=0^{n_0}.
\]

第 \(i\) 层定义 \(BF_i\) 为 \(G_{n_i}\) 的 AVOID 求解器，并令

\[
f_i:\{0,1\}^{n_0}\to\{0,1\}^{T_i},
\qquad
f_i(x)=BF_i(G_{n_i})\,0^{T_i-2n_i}
\tag{2}
\]

（非长度 \(n_0\) 的输入再统一输出全零）。所以在该 induction 的实际调用上，

\[
f_i(x_0)=f_i(x)\quad\text{对所有 }x\in\{0,1\}^{n_0}.
\tag{3}
\]

Theorem 3.5 为每个输入提供一个 encoded history \(\Pi_x\)，但 Theorem 4.3 只把
\(x_0\) 送入 Theorem 4.1；实际使用的是单个

\[
\Pi_{x_0},
\]

及其一个固定的系统前缀和固定的输出 truth table。Reconf 逐位重建的是这个固定
\(f_i(x_0)\)，不是一族按 \(x\) 索引的 independent histories。

## 对 JK tree 计数的影响

JK 把一个固定的 \(\Pi_{x_0}\) 切成 \(2q\)-bit blocks，并在每一级对相邻 blocks
做 range query/拼接。即使这些 blocks 在数值上两两不同，也只有一个确定的 ordered
sequence

\[
(z_1,z_2,\ldots,z_M).
\]

pair-lift 或 tree-capacity 论证需要的是一个可证明的集合 \(A\) 及许多可同时出现的
ordered pairs（或者一个由多个 leaf tuples 组成的 family）。由 (2)--(3) 不能把
“输入 \(x\) 的数量”当作 \(|A|\)；该数量在实际 induction 中没有产生不同的
history。更准确地说，现有材料只给出

\[
\text{one fixed history}\quad+\quad\text{one fixed block sequence},
\]

而没有给出

\[
\text{many independently addressable histories}\quad\text{或}\quad
\text{tree-rich block family}.
\tag{4}
\]

因此 note 105--110 的容量 forcing 不能直接套到 Ren--Williams Theorem 4.3；若要套用，
还必须从这一个固定 sequence 内部证明 (1)，而不能靠改变 \(x\) 补充 entropy。

## 可行的两条补桥

要继续使用这条路线，至少需要二者之一：

1. **固定 history 的内部丰富性定理。** 证明某个 \(f_i(x_0)\) 的 PCP proof 在一个
   可定位的 systematic prefix 内确实含有足够多的 distinct blocks，并且这些 blocks
   的 JK tree 组合保持可追踪；目前 Theorems 3.1/3.5/4.3 没有这样的结论。
2. **改造 induction 为多输入函数。** 用一个统一的 \(f_i(x)\) 产生许多 distinct
   histories，同时保持 Theorem 4.1 的时间、round、witness-length 参数和最终的
   single-valued/smart 语义；这不是对现有常值 \(f_i\) 的记号重命名。

仅用 Reconf 的逐坐标输出重建不能替代这两个补桥：它能恢复固定 \(f_i(x_0)\) 的某一
位，但不自动制造 pair-rich leaves。

## 证据边界

- Ren--Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin--Arthur Queries*, ECCC TR26-118 revision 1：Lemma 3.2、Theorem 3.5、
  Theorem 4.1 与 Theorem 4.3，尤其 Section 4.2 中对 \(x_0\) 和 \(f_i\) 的显式定义。
- 本 note 的 (1)--(4) 是对这些定义的直接量词/依赖关系推导，不是新的 circuit
  lower bound，也不声称 \(P\ne NP\)。

\[
\boxed{\text{RW Theorem 4.3 gives one fixed history per induction stage; actual-history
richness remains unproved.}}
\]
