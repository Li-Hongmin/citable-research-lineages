> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW arbitrary joint coupling 的 latent-state information barrier（2026-08-19）

## 本轮改变的判断

C419 仍限制在 seed-factorized relation：坐标通过各自的 seed-neighborhood 产生，
seed 之后不再直接联合访问 proof state。于是 C419 明确留下一个更强的逃逸：
坐标可以共享一个任意的 post-seed joint coupling。

本 note 关闭的是其中所有**可由一个 target-independent latent state 表示**的情形。
不再假设 seed 坐标独立、bounded fanout 或 half-lift。只要在给定 policy 与一个
latent state 后，global word 由不再看见 target 的固定 kernel 产生，那么 whole-word
成功本身就迫使 policy 加 latent state 携带线性 target information。因而“直接 joint
coupling”不能仅靠短的 hidden state 逃过 C419；真正剩下的分支是 message-scale
latent state，target channel，或没有 target-independent conditional kernel 的
unbounded/joint-oracle semantics。

这是一条 family-level information theorem，不是 published RW singleton 的
\(P\ne NP\) 证明。

## 模型

令 \(X\) 在一个大小为 \(2^b\) 的消息族 \(\mathcal X_b\) 上均匀取值。对每个
\(x\in\mathcal X_b\)，给定一个 global word
\(\Pi_x\in\Gamma^M\)，并假设

\[
 d_H(\Pi_x,\Pi_{x'})>2t\qquad(x\ne x').
\tag{422.1}
\]

令 \(S\) 是 policy、descriptor、cover selector 或公开 transcript 的总包装，
\(W\) 是任意有限或可数的 latent global state。观察到的输出
\(Z\in\Gamma^M\) 满足 Markov 条件

\[
 X\;\longrightarrow\;(S,W)\;\longrightarrow\; Z,
\tag{422.2}
\]

即给定 \((S,W)\) 后，\(Z\) 由一个不再读取 \(X\) 的固定 kernel 产生。kernel
可以包含任意共享随机性、post-seed joint coupling 和联合 proof-state computation；
只有通过 \(S\) 或 \(W\) 进入的 target information 被计账。定义 whole-word 成功率

\[
 p_b:=\Pr[d_H(Z,\Pi_X)\le t].
\tag{422.3}
\]

Markov 条件是本定理的关键边界：若一个所谓 joint coupling 在给定 \((S,W)\) 后
仍直接读取 \(X\)，那部分输入已经是未计价的 target channel，不属于本模型。

## 引理 422.1（近邻词的 Fano 信息下界）

在 (422.1)--(422.3) 下，

\[
 I_2(X;S,Z)\ge p_b b-1.
\tag{422.4}
\]

### 证明

由最小距离条件，若 \(Z\) 落在某个 \(\Pi_x\) 的 \(t\)-球内，该 \(x\) 唯一。定义
\(\widehat X(Z)\) 为该唯一消息；若 \(Z\) 不在任一 \(t\)-球内则输出固定符号
\(\bot\)。于是
\(\Pr[\widehat X(Z)\ne X]\le1-p_b\)。Fano 不等式给出

\[
 H_2(X\mid S,Z)
 \le h_2(1-p_b)+(1-p_b)b
 \le 1+(1-p_b)b.
\]

因为 \(H_2(X)=b\)，得到 (422.4)。证毕。

## 定理 422.2（arbitrary joint-coupling latent-state trichotomy）

在上述模型中，任意成功率 \(p_b\) 都满足

\[
\boxed{
 I_2(X;S)+I_2(X;W\mid S)\ge p_b b-1.
}
\tag{422.5}
\]

若 \(H_2(W\mid S)\le h_b\)，则进一步有

\[
 I_2(X;S)+h_b\ge p_b b-1.
\tag{422.6}
\]

因此，对固定 \(p_b\ge p_0>0\) 的 whole-word relation，target/policy channel 与
latent-state channel 的总信息至少是 \(p_0b-O(1)\)。更精确地，对任意
\(0\le\theta\le p_0\)，至少有一项成立：

1. \(I_2(X;S)\ge\theta b-1\)（target/policy channel）；或
2. \(I_2(X;W\mid S)\ge(p_0-\theta)b-1\)（message-scale latent state）。

若 (422.2) 失败，即 joint kernel 在给定 package 后仍直接读取 target，则该读取
语义必须另行计价，不属于这两个 channel 的免费部分。

### 证明

由 (422.2) 的条件数据处理，

\[
 I_2(X;Z\mid S)\le I_2(X;W\mid S).
\]

将其代入 (422.4) 的 chain rule

\[
 I_2(X;S,Z)=I_2(X;S)+I_2(X;Z\mid S)
\]

即得 (422.5)。再用
\(I_2(X;W\mid S)\le H_2(W\mid S)\le h_b\) 得到 (422.6)。三分是
(422.5) 的直接分类。证毕。

## 推论 422.3（短 joint state 不能成为第四逃逸）

若 \(p_b\ge p_0>0\)、\(I_2(X;S)=o(b)\)，且
\(H_2(W\mid S)=o(b)\)，则 (422.6) 矛盾。特别地，一个
\(O(\operatorname{polylog} b)\)-bit 的 target-oblivious latent state，哪怕允许任意
post-seed 非乘积 coupling，也不能在常数成功率下绑定一个 \(b\)-bit、距离分离的
global-word family。

该推论比 C418/C419 少了 seed independence、fanout 和 coordinate-factorization
假设；它只要求 coupling 的全部 target-dependent content 能被 \(W\) 作为一个
conditional channel state 承载。

## 对 RW Closure 的精确作用

* **关闭的分支：** C419 的“post-seed direct joint coupling”若仍有一个
  target-independent kernel 和 sublinear \(W\)，现在进入 (422.6)，不能作为免费
  第四逃逸。
* **仍然开放的分支：** \(W\) 本身含有 \(\Omega(b)\) bits 的 message-scale state；
  policy \(S\) 携带同样规模的 target information；或 interaction 在给定 transcript
  后仍有未建模的 target access。前两者必须接到 C393/C417 的容量或电路 payment，
  最后一项必须明确给出新的 query/oracle semantics。
* **地址尺度边界：** 若 proposed relation 由一个 \(h_b=o(b)\)-bit 的共同 key、
  sheet、seed 或 joint transcript state 选择 target-independent kernel，则它不能
  绑定该 family。若 \(h_b=\operatorname{poly}(b)\)，定理本身不自动产生矛盾；必须
  再证明该 state 在实际 RW 参数下低于 forcing/object scale。
* **source 边界：** 可将本定理应用于 C390/C391 的 Harsha identity family 或
  C414 的 systematic-witness stress family，前提是先核验 same-proof、common
  family、距离分离与 target-independent kernel。published RW Theorem 4.3 的固定
  \(x_0\) singleton 没有 \(2^b\) 个 messages，不能直接套用 (422.5)。

本 note 不证明 simultaneous coordinate-robust dPCP 的一般不可能性，也不证明
\(P\ne NP\)。它把 C419 留下的“任意新 global relation”进一步压成一个明确的
latent-information/model-exit 接口。

## 证据边界

* 引理 422.1 只用距离分离与 nearest-word decoder 的 Fano 不等式；
* 定理 422.2 只用条件数据处理，不依赖 JK、half-lift、seed 独立或 fanout；
* C419 仍负责更细的 seed/fanout 账本，C417 负责可编译 half-lift 的 singleton
  电路 payment；
* 本 note 的 family-level 量词不能替换 published singleton，也不能把一个
  未证明存在的 RW family lift 当成已有构造。
