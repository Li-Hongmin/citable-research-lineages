> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Noncanonical sampler decoder 的 image-range 前沿（2026-08-15）

## 结论

canonical gate-list decoder 的 range 只是固定 MCSP slice。一个具体而不同的 noncanonical 候选是：
用一个小电路枚举带标签的地址，并要求它定义一个全支持、标签一致的函数。

固定、统一且可由 \(m\) 在 \(\operatorname{poly}(q+m+p)\) 资源内取得的 schedules
\(p=p(m)\ge m\) 与 \(t=t(m)\)，令 \(N=2^m\)。假设 \(t\) 足以编码下面的固定
fallback sampler。令
\(\mathsf{Sam}_{m,p,t}\) 是形如

\[
E:\{0,1\}^{p}\longrightarrow\{0,1\}^{m+1}
\tag{1}
\]

的 fan-in-2 电路；输出的前 \(m\) 位是地址，最后一位是标签。定义

\[
\begin{aligned}
\operatorname{Full}(E)&:\Longleftrightarrow
  \forall x\in\{0,1\}^{m}\;\exists r\in\{0,1\}^{p}:
  E(r)_{[m]}=x,\\
\operatorname{Cons}(E)&:\Longleftrightarrow
  \forall r,r'\in\{0,1\}^{p}:
  E(r)_{[m]}=E(r')_{[m]}
  \Rightarrow E(r)_{m+1}=E(r')_{m+1},\\
\operatorname{Valid}(E)&:\Longleftrightarrow
  \operatorname{Full}(E)\land\operatorname{Cons}(E).
\end{aligned}
\tag{2}
\]

当 \(E\) 有效时，定义唯一的函数

\[
f_E(x)=1
\quad\Longleftrightarrow\quad
\exists r:E(r)=(x,1).
\tag{3}
\]

固定一个 padded、拓扑有序、支持多 designated output wires 的 gate-list parser
\(\operatorname{Dec}_{m,p,t}\)，语法非法或语义无效时返回零函数的固定 sampler
\(E_0(r)=(r_{[m]},0)\)。假设 \(E_0\in\mathsf{Sam}_{m,p,t}\) 且
\(\operatorname{Valid}(E_0)\)；在有效时输出式 (3) 的 truth table，得到

\[
D^{\mathrm{sam}}_{m,p,t}:\{0,1\}^{q}\to\{0,1\}^{N}.
\tag{4}
\]

令

\[
\mathsf{SRange}_{m,p,t}
=
\{TT(f_E):E\in\mathsf{Sam}_{m,p,t},\ \operatorname{Valid}(E)\}.
\tag{5}
\]

则

\[
\operatorname{Range}(D^{\mathrm{sam}}_{m,p,t})
=
\mathsf{SRange}_{m,p,t}.
\tag{6}
\]

这是一个 noncanonical image-range candidate，可能严格大于 canonical MCSP；严格分离尚未
证明，截至当前核验也没有其一般电路 Range/Search 下界。

## 逐位 PH-local 性质

式 (2) 中 \(\operatorname{Full}(E)\) 是 \(\Pi_2^P\) 谓词，\(\operatorname{Cons}(E)\) 是
\(\Pi_1^P\) 谓词。给定 seed \(u\) 和地址 \(x\)，解码器的输出位可以写成

\[
D^{\mathrm{sam}}_{m,p,t}(u)_x=1
\quad\Longleftrightarrow\quad
\operatorname{SyntaxValid}(u)\land
\operatorname{Valid}(\operatorname{Dec}(u))\land
\exists r:\operatorname{Dec}(u)(r)=(x,1).
\tag{7}
\]

无效 seed 因为返回 \(E_0\)，式 (7) 只是在固定 PH 层上作 totalization；不需要展开完整的
\(N\)-bit 输出。电路值 \(E(r)\) 可逐门计算，且量词变量长度为 \(O(p+m)\)。只要

\[
p(m)\le\operatorname{poly}(q+m),
\tag{8}
\]

在上述统一 schedule 且满足式 (8) 时，式 (7) 属于某个与 \(m\) 无关的固定 PH 层，底层关系
运行时间为 \(\operatorname{poly}(q+m+p)\)。
因此 note 089 的 merge 上界适用于这个 sampler decoder；在 \(P=NP\) 下，它有
\(\operatorname{poly}(q+m+p)\) 空间/更新时间的单遍 exact inverse。

gate-list 只需记录每个门的类型、两个来源、门数和 \(m+1\) 个输出线。于是可取

\[
q=O\bigl((t+m+1)\log(p+t+m+2)\bigr).
\tag{9}
\]

当 \(p=m\) 且 \(t\ge m\) 时，这仍是 \(t\operatorname{polylog}t\) 量级的 seed。

## 对 canonical coverage 的严格包含

给定任意 \(m\)-input、size-\(s\) 的电路 \(C\)，令

\[
E_C(r)=(r,C(r)),
\qquad r\in\{0,1\}^{m}.
\tag{10}
\]

前 \(m\) 个输出可以直接指向输入线，最后一个输出接到 \(C\) 的输出线，所以在允许多输出
designated wires 的标准语法下，\(E_C\) 的门数为 \(s+O(1)\)；若输出复制被计门，则为
\(s+O(m)\)。显然 \(E_C\) 满足 Full 与 Cons，且 \(f_{E_C}=f_C\)。因此

\[
\mathsf{MCSP}_{m,s}^{\mathrm{slice}}
\subseteq
\mathsf{SRange}_{m,m,s+O(m)}.
\tag{11}
\]

但反向包含没有证明：一个小 sampler 电路可能通过地址枚举、重复和隐式搜索定义一个函数，
其直接 truth-table circuit 复杂度远大于 sampler 的门数。证明这种严格分离需要一般电路下界，
不能把“可能更强”写成已知事实。

## 不要与 ImpMCSP 混同

式 (5) 是对 truth table 的 image language；2026 年 Goldberg--Juvekar--Kabanets 研究的
ImpMCSP 则把 sampler 电路 \(E\) 本身作为输入，询问它所定义的函数是否有小电路。ImpMCSP 的
输入是 scrambled、可重复的 labeled-example sampler，而不是这里的 canonical lexicographic
truth table。两者共享 Full/Cons 语义，但量词方向不同：

\[
\begin{array}{c|c}
\text{本 note 的 sampler-range} & \exists E\;[\operatorname{Valid}(E)\land TT(f_E)=y\land |E|\le t]\quad (y\text{ 为输入})\\
\text{ImpMCSP} & (E,s)\mapsto[\exists C\;C=f_E\land |C|\le s]\quad (E\text{ 为输入})
\end{array}
\tag{12}
\]

所以 ImpMCSP 的条件性 NP-hardness 或 non-Levin 结果不能直接提供式 (5) 的 range/search 下界。
它们只说明 sampler 表示是一个有独立复杂度内容的邻近对象。

## 对 P vs NP 路线的裁决

这个构造把 noncanonical 分支从抽象要求具体化为一个有限目标：

\[
\boxed{
\text{对 }\mathsf{SRange}_{m,p,t}\text{ 或其 validity-restricted exact search，证明超准线性下界。}
}
\]

对统一 schedules 定义同一个固定语言

\[
L_{\mathrm{sam}}=\bigcup_{m\ge1}\mathsf{SRange}_{m,p(m),t(m)}
\subseteq\{0,1\}^{*}.
\tag{13}
\]

若由式 (9) 自洽推出 \(\ell(m)=q(m)+m+p(m)=N^{o(1)}\)，并且对某个固定
\(\varepsilon>0\)，\(L_{\mathrm{sam}}\) 在无限多个长度 \(N=2^m\) 上具有
\(N^{1+\varepsilon}\) 的 decision-circuit lower bound，则 note 089 会推出
\(NP\not\subseteq P/poly\)。只证明 search 电路下界并不自动给 decision 下界，除非下界明确
包含 success bit。当前没有这样的下界；因此这个 note 是一个具体 noncanonical candidate
与严格 coverage inclusion，而不是 \(P\ne NP\) 的证明。

### 来源与证据边界

原文核验日期：2026-08-15。

- McKay--Murray--Williams, STOC 2019：提供固定 PH-local merge/search 的先例架构。
- Halley Goldberg, Mandar Juvekar, Valentine Kabanets, ECCC TR26-091 (2026)：证明的是
  distributional/implicit MCSP 的条件性 non-Levin NP-hardness；只用于区分对象，不作为式 (5)
  的 lower-bound 证据。

式 (1)--(13) 是本项目的自足定义、范围等式和 coverage inclusion。严格分离
\(\mathsf{SRange}\) 与 canonical MCSP、或证明其一般 circuit lower bound，仍是 open。
