> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 全局 collision-graph / spectral 势：首个边界（2026-08-13）

## 1. QA 的根约束不可省略

Kamiyama 的 quasi-additive LP 对每个矩形（含根 (C=X\times Y)）施加递归约束。
根的右端是

\[
\sum_{c\in C\setminus C}\psi(c,C)=0,
\]

所以根二分 (C=V\dot\cup W) 必须满足

\[
F(V)+F(W)\ge0.
\tag{R0}
\]

任何把一个矩形势 (K(R)) 代入
(F(R)=\sum_{c\notin R}\psi(c,R)) 的构造，都必须验证

\[
K(C)=0,
\qquad K(V)+K(W)\ge K(R)
\]

也包括 (R=C)。遗漏根约束会制造假的无界 spectral 证书。

## 2. Fourier additive envelope 的方向

对线性型 (r\in\mathbb F_2^N)，置

\[
u_r(A\times B)=\Big(\sum_{x\in A}(-1)^{r\cdot x}\Big)
                 \Big(\sum_{y\in B}(-1)^{r\cdot y}\Big).
\]

它对横向或纵向分割均可加。若 \(\mathcal F\) 是一族线性型，则

\[
M(R)=\max_{r\in\mathcal F}u_r(R)
\]

满足 (M(V)+M(W)\ge M(R))，故

\[
K_+(R)=M(R)-\frac{M(C)}{|C|}|R|
\tag{1}
\]

满足 QA 递归且 (K_+(C)=0)。相应地

\[
K_-(R)=-\min_{r\in\mathcal F}u_r(R)
 +\frac{\min_{r\in\mathcal F}u_r(C)}{|C|}|R|
\tag{2}
\]

也满足 QA 递归。

若 \(\mathcal F\) 含常字符 (r=0)，则 (M(R)\ge|R|)、(M(C)=|C|)，从而

\[
K_+(R)\ge0.
\]

若 \(\mathcal F\) 含每个 affine-leaf 的方向，则该叶 (R=A\times B) 对某个 (r_0) 有

\[
u_{r_0}(R)=-|R|.
\]

因此 (2) 在叶上满足

\[
K_-(R)\ge |R|+
\frac{\min_r u_r(C)}{|C|}|R|\ge0,
\]

因为 \(\min_r u_r(C)\ge-|C|\)。于是完整 Fourier 的 max/min envelope 不能在 affine-parity 叶上提供负融资；只使用一个方向则无法约束其余方向的合法叶。

## 3. Tensor-Laplacian 图势的正性

令 (L_X,L_Y) 是非负边权图的 Laplacian，且 (\mathbf1^TL_X=\mathbf1^TL_Y=0)。置

\[
Q(A\times B)=
(\mathbf1_A^TL_X\mathbf1_A)(\mathbf1_B^TL_Y\mathbf1_B).
\]

则

\[
Q(C)=0,
\qquad Q(A\times B)=\operatorname{cut}_X(A)\operatorname{cut}_Y(B)\ge0.
\]

横向分割 (A=A_1\dot\cup A_2) 时

\[
Q(A_1\times B)+Q(A_2\times B)-Q(A\times B)
=2w_X(A_1,A_2)\operatorname{cut}_Y(B)\ge0,
\]

纵向亦同。因此 (Q) 是合法 QA 势，但在每个叶上非负，不能提高根目标。

## 4. 当前裁决

全局 graph/spectral 路线若只保留

\[
\text{(i) additive Fourier scores},
\quad\text{或}\quad
\text{(ii) tensor Laplacian cuts},
\]

不会产生 (N^{1.01}) 承重。真正未关闭的谱路线必须使用 collision hypergraph 的高阶相交结构，并同时满足根约束 (R0)；单纯二次谱矩阵或 Fourier envelope 不够。

小规模二次势 LP（(m\le25)，系数归一化 \(|W_{ij}|\le1\)）只得到约 (2.52) 的目标，最优解的碰撞边系数不稳定且常为零；这只是搜索线索，不是下界证据。

## 5. 超图染色势：严格新下界但至多线性

对碰撞超图 \(\mathsf H=(C,\mathcal H)\)，令 \(\chi(R)\) 为诱导超图的染色数。分别给两个子矩形使用不相交颜色集，故

\[
\chi(V)+\chi(W)\ge\chi(R).
\]

所以

\[
K_\chi(R)=\chi(R)-\frac{\chi(C)}{|C|}|R|
\]

是合法 QA 势。每个 affine-parity 单色叶不含碰撞超边，故 \(\chi(R)=1\)。取

\[
\phi_c=\frac{\chi(C)}{|C|}
\]

得到严格证书

\[
QA(T_\oplus)\ge\chi(\mathsf H).
\tag{3}
\]

但 \(\chi(\mathsf H)\) 有普适线性上界。对每个 cell \(c=(x,y)\)（\(X\cap Y=\varnothing\)），取

\[
j(c)=\min\{j:x_j\ne y_j\},
\qquad
\operatorname{col}(c)=(j(c),x_{j(c)}).
\]

这只使用至多 \(2N\) 种颜色。若一个 odd--odd collision 超边四点同色，则其碰撞等式在坐标 \(j\) 上左侧为奇数个 \(a\)，右侧为奇数个 \(1-a\)，不可能相等。因此

\[
\boxed{\chi(\mathsf H)\le2N.}
\tag{4}
\]

染色势路线是一个真实的全局 QA 结果，但不能达到 \(N^{1.01}\)。任何超图势若只依赖普通染色/独立分区，必须超越这一本质上的 first-differing-coordinate 线性着色。
