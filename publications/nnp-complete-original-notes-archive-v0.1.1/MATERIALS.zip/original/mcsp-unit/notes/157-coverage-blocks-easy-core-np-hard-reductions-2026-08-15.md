> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Coverage 阻断 easy-core padding 型 NP-hard range 归约（2026-08-15）

## 设置

对合法的 \(q\) 令

\[
G_q:\{0,1\}^{q}\to\{0,1\}^{2q},
\qquad R_q=\operatorname{Range}(G_q),
\]

并假设固定阈值 coverage

\[
\mathrm{TT}_{m(q),\le s(q)}\subseteq R_q,
\qquad m(q)=\log_2(2q).
\tag{1}
\]

这里 \(\mathrm{TT}_{m,\le s}\) 是所有由 \(m\) 个输入、大小至多 \(s\) 的电路产生的
长度 \(2^m=2q\) 真值表。

## Easy-core padding obstruction

定义一个 padding-range language，其输入形如

\[
\operatorname{Enc}(q,z,t),qquad |z|=2q,
\]

且 membership 只看核心 \(z\)：

\[
\operatorname{Enc}(q,z,t)\in L_G^{\mathrm{pad}}
\iff z\in R_q.
\tag{2}
\]

也可以把 \(t\) 固定为 canonical zero padding；关键是假设尾部不编码答案。

**定理（easy-core obstruction）。** 设源语言 \(K\) 有一个 NO 实例，且存在 many-one
reduction \(f\) 满足：对每个输入 \(x\)，

\[
f(x)=\operatorname{Enc}(q_x,z_x,t_x),
\qquad
z_x=\mathrm{TT}(h_x),
\qquad
\operatorname{CC}(h_x)\le s(q_x).
\tag{3}
\]

若 (1) 对这些合法 \(q_x\) 成立，并且 padding 满足 (2)，则所有 \(f(x)\) 都属于
\(L_G^{\mathrm{pad}}\)。因此 \(f\) 不可能是正确的 many-one reduction：NO 实例也会被映到
YES。证明只用 (1)--(3)，不使用 reduction 的 uniformity；所以对 P-uniform 和 P/poly
归约都成立。

这条定理的含义不是“coverage 排除 NP-hard range”，而是更窄、更严格的结论：

\[
\boxed{
\text{NP-hard reduction 的 NO 输出必须离开 covered easy core，}\\
\text{或让尾部参与 membership，或使用非标准 succinct output。}
}
\tag{4}
\]

## 已知 NO 输入给出的 unary hard-table 必要条件

设源语言 \(K\) 有一列显式可构造的 NO 输入 \(x_n\notin K\)，长度为
\(n\)，并令 \(f\) 是到 \(L_G^{\mathrm{pad}}\) 的正确 reduction。写

\[
f(x_n)=\operatorname{Enc}(q_n,z_n,t_n).
\]

正确性给出 \(z_n\notin R_{q_n}\)。若 coverage (1) 成立，则必有

\[
\operatorname{CC}(z_n)>s(q_n).
\tag{5}
\]

另一方面，若 \(f\) 是普通多项式时间 transducer 且 \(q_n\le n^{O(1)}\)，把固定的
\(x_n\) 硬接入 transducer，并以 \(m(q_n)\)-bit 地址选择输出位，就得到一个
\(\operatorname{poly}(n)\)-size 的 truth-table evaluator：

\[
\operatorname{CC}(z_n)\le n^{c_f}
\tag{6}
\]

对某个只依赖 reduction 的常数 \(c_f\)。因此任何同时满足 coverage 与 NP-hardness 的
reduction 都必须满足 \(s(q_n)\le n^{c_f}\)（忽略低阶对数）；它不能靠“NP-hard 输入”
免费产生超出自身输出电路规模的 hard table。若通过 padding 令 \(s(q_n)>n^{c_f}\)，
就会在这个已知 NO 输入上直接矛盾。

## 普通归约的尺度限制

标准多项式时间 many-one reduction 必须显式输出 \(f(x)\)，所以若核心长度为 \(2q_x\)，
则 \(q_x\le |x|^{O(1)}\)。当 \(q\asymp 2^n\) 时，长度 \(2q\) 已为指数级，不能由
普通输入长度 \(n\) 的 reduction 显式产生；这类目标必须改写成 succinct-output 问题，
不能冒充标准 range language 的 NP-hardness。

若先有较短表 \(z=\mathrm{TT}(h)\)，再通过变量复制或固定尾部得到长度 \(2q'\) 的
\(\operatorname{Pad}(z)\)，只有在实际验证

\[
\operatorname{CC}(\operatorname{Pad}(h))\le s(q')
\tag{7}
\]

后才能应用 (1)。padding 可能保留 \(\operatorname{CC}\) 的加性开销，但同时把 coverage
阈值和 truth-table 长度一起放大；不能默认相对 hardness 保持。特别是把一个长度 \(2^n\)
的 hard table 扩展到 \(2^m\) 时，阈值从约 \(2^n/n\) 变为 \(2^m/m\)，若 \(m-n\) 不是
很小的量，原来的 hardness 比例会被稀释。

## 与已知 noncanonical range 基准的关系

note 113 的近线性 decoder 通过显式 graph-and-verifier bit 得到了 NP-complete range，
但它没有 (1) 的 coverage；格式化输出本身可能落入一个简单 truth-table family，因此
不能直接把该 NP-hardness 迁移到 coverage decoder。相反，若某个未来构造同时满足 (1)，
任何沿用“实例直接写入输出、其余位固定/可压缩”的归约都必须先通过 (3) 的语义检查。

## 不应过度外推的边界

1. 单个 slice 的 \(|R_q|\le 2^q\) 只给密度 \(2^{-q}\)；在输入长度 \(2q\) 下它通常
   不是 polynomially sparse，不能直接套 Mahaney 的 sparse-NP-complete 结论。
2. (4) 不给一般 range-membership lower bound，也不证明 \(P\ne NP\)。它只排除一类
   最容易实现、最容易 padding 的 NP-hardness 路线。
3. 若 decoder 只在 powers of two 等子域定义，归约还必须显式保证 \(q_x\) 合法，或给出
   不改变语义的合法 rounding/padding；不能把非法长度的输出算作 range instance。
4. 若 \(G_q\) 仅 P/poly-uniform，range 只能按 advice 语言讨论；要称标准 NP 语言，需
   P-uniform 的 decoder generator/evaluator。

## 路线裁决

coverage 与 NP-hard range 可以在逻辑上同时存在，但其 NP-hardness 不能来自 covered
easy core 的普通 padding 归约。下一步若继续追求 range hardness，必须构造一个能由多项式
时间描述、却在 truth-table 语义上超过 \(s(q)\) 的 NO 输出；这正是当前缺口，而不是再增加
一个低复杂度 verifier bit。

本文是自足的参数/量词筛选，不声称已有一般 decoder lower bound 或 \(P\ne NP\)。
