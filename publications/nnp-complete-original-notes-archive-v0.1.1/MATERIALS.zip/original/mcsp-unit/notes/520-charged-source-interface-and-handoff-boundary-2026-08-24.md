> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Charged-source interfaces and asynchronous handoff (2026-08-24)

## 1. Source-probe factorization

Let \(A\subseteq\{0,1\}^N\). Fix source-independent advice and an auxiliary oracle \(O\).
Consider any randomized interactive evaluator which may perform arbitrary computation, query target
bits, exchange messages, and adaptively access the source only through explicit operations
\(\operatorname{read}(i)=x_i\). Count every source bit on which a target answer depends: if a
target operation is a function of \(w_j\) explicitly read source bits, charge \(w_j\). Let
\[
 Q=q_{\rm direct}+\sum_j w_j
 \]
be the total charged source-bit budget. If completeness on \(A\) is at least
\(1-\varepsilon_Y\), soundness outside \(A\) is at most \(\varepsilon_N\), and
\(\varepsilon_N<1-\varepsilon_Y\), then
\[
 \boxed{
 Q\ge
 \left(1-\frac{\varepsilon_N}{1-\varepsilon_Y}\right)
 \log_2\frac{2^N}{|A|}.
 }
\]

For \(A=\mathcal L_{\mu_H,n}\), this is
\[
 Q\ge
 \left(1-\frac{\varepsilon_N}{1-\varepsilon_Y}\right)(N-o(N)).
\]
Thus target-bit query count, target random access, and finite source--target communication do not
weaken the source-probe barrier when every source-dependent bit is charged.

### Proof

Fix all random tapes. Once the source answers seen so far are fixed, every message, target
address, and target answer is fixed as well. The complete interaction is therefore a decision tree
whose only branching variables are the charged source bits, of depth at most \(Q\). Apply the
boundary-neighbor proof of Proposition 26 to this tree. A target operation returning many bits
without revealing more than \(w_j\) source bits still has at most the same \(2^{w_j}\) possible
source-dependent answer patterns, so it can be expanded into \(w_j\) bit probes.

## 2. Sequential asynchronous handoff

Assume instead that a source phase reads the \(N\)-bit table in a fixed known order, ends in one of
\(W_Q\) complete configurations, and hands a payload \(m\in\{0,1\}^h\) to a target phase that no
longer reads the source. Suppose the composed exact or bounded-error computation is represented by
a length-\(N\) known-order ROBP. Assume the local-PRG interface used in Proposition 10: every
width-\(\mathfrak W\) length-\(N\) ROBP is fooled to constant error by a generator whose seed length
\[
 r=\widetilde O(\log(N\mathfrak W))
 \]
and whose every output table has circuit complexity at most \(r\). If the handoff payload is fully
charged as state, then
\[
 \mathfrak W\le (N+1)W_Q\,2^h
\]
(or \((N+1)W_QW_D2^h\) when target configurations are retained explicitly), and consequently
\[
 \boxed{h+\log_2W_Q=\widetilde\Omega(S),\qquad S=N^{\mu_H}.}
\]
If target configurations are retained explicitly in the width, the corresponding bound is
\[
\boxed{h+\log_2W_Q+\log_2W_D=\widetilde\Omega(S).}
\]

For bounded error, assume completeness \(1-\varepsilon_Y\), soundness \(\varepsilon_N\), and
\(\varepsilon_Y+\varepsilon_N<1\).

The randomized bounded-error case follows by fixing the random tapes before applying the ROBP
generator and then averaging: all generator outputs lie in \(\mathcal L_{\mu_H,n}\) when
\(r=o(S)\), while a uniform table is a NO instance with probability \(1-o(1)\).

The conclusion is conditional on the stated ROBP/local-PRG interface and on charging the whole
payload. If an evaluator can consult source-dependent RAM, an \(O_f\), or an uncharged payload
through random access, the ROBP width bound is false and this proposition does not apply.

## 3. Exact model boundary

Sparsity alone cannot imply a handoff lower bound: an unlimited source phase can compute
\(\mathbf 1_A(x)\), send one bit, and let the target repeat it. Therefore any claim that a short
payload is impossible must charge either the source probes, the complete payload state, or a
source-independent evaluator interface. A free source-dependent multi-bit answer is a model change,
not an escape from the charged-source theorem.

## Sources

Proposition 26 and the conditional prefix-state interface of Proposition 10 in the MCSP paper;
Harper's Boolean-cube edge-isoperimetric inequality
([Harper, 1966](https://doi.org/10.1016/S0021-9800(66)80059-5)).
