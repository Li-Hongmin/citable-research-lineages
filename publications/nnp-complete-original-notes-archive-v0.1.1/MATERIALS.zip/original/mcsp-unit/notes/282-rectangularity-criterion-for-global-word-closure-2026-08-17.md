> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Rectangularity criterion for global-word closure

## Purpose

The ordinary distributional/list quantifiers can choose a different valid word at
each coordinate. The right abstraction is the rectangular hull of the valid-word
family. This note gives an exact black-box criterion for when coordinatewise
explanations can be upgraded to one globally close word.

This is a combinatorial separation theorem. It does not claim that every concrete
dPCP has rectangular behavior, nor does it rule out a construction that proves a
same-seed coupling or an equivalent global constraint.

## Setup

Let \(\Gamma\) be a finite alphabet, \(M\ge 1\), and let
\(\mathcal Y\subseteq\Gamma^M\) be the family of valid global words. For each
coordinate \(j\in[M]\), write
\[
 \pi_j(\mathcal Y):=\{y_j:y\in\mathcal Y\}.
\]
Its rectangular hull is
\[
 \operatorname{Rect}(\mathcal Y)
 :=\prod_{j=1}^M \pi_j(\mathcal Y).
\]
Thus \(z\in\operatorname{Rect}(\mathcal Y)\) exactly when every coordinate of
\(z\) can be explained by some (possibly coordinate-dependent) valid word.

For \(\varepsilon\in[0,1]\), define the Hamming neighborhood
\[
 \mathcal Y_{\le\varepsilon}
 :=\left\{z\in\Gamma^M:
       \min_{y\in\mathcal Y}\frac{d_H(z,y)}{M}\le\varepsilon\right\}.
\]

A coordinatewise-to-global black-box principle at radius \(\varepsilon\) means:
for every \(z\in\Gamma^M\), if each coordinate \(z_j\) is realizable by some
valid word, then \(z\) is \(\varepsilon\)-close to one valid word. No relation
between the witnesses for different coordinates is assumed.

## Theorem 1 (rectangularity criterion)

The following are equivalent.

1. Every coordinatewise realizable word is \(\varepsilon\)-close to a single
   valid word.
2. \[
   \operatorname{Rect}(\mathcal Y)\subseteq\mathcal Y_{\le\varepsilon}.
   \tag{1}
   \]

### Proof

The coordinatewise premise in (1) is exactly
\(z\in\operatorname{Rect}(\mathcal Y)\): membership supplies, for every \(j\),
a word \(y^{(j)}\in\mathcal Y\) with \(y^{(j)}_j=z_j\). Therefore statement 1
is precisely the inclusion in statement 2. Conversely, every element of the
rectangular hull has those coordinate witnesses, so the inclusion implies the
black-box principle. \(\square\)

This equivalence is useful because it separates a semantic property of a concrete
construction from a quantifier slogan. A proof of global closure must establish
(1), or an equivalent joint coupling; coordinatewise soundness alone establishes
only membership in the rectangular hull.

## Failure certificate

If (1) fails, choose
\[
 z^\star\in\operatorname{Rect}(\mathcal Y)
 \setminus\mathcal Y_{\le\varepsilon}.
\]
For every \(j\), fix \(y^{(j)}\in\mathcal Y\) with
\(y^{(j)}_j=z^\star_j\). A local system that returns \(z^\star_j\) at coordinate
\(j\) then has perfect coordinatewise realizability, while no single valid word is
within relative distance \(\varepsilon\). Hence no theorem using only the
coordinatewise witnesses can produce the desired global word.

The certificate is robust to how the local witnesses are generated: they may be
indexed by coordinates, random tapes, or independent Merlin responses. What is
missing is a joint object whose choices are coupled across all coordinates.

## Example: two constant valid words

Let
\[
 \mathcal Y=\{0^M,1^M\}.
\]
Then \(\operatorname{Rect}(\mathcal Y)=\{0,1\}^M\). Every mixed word is
coordinatewise realizable, but a word with Hamming weight between
\(\varepsilon M\) and \((1-\varepsilon)M\) is farther than \(\varepsilon\) from
both valid words whenever \(\varepsilon<1/2\). In particular, for every
\(\varepsilon<1/2\), the black-box coordinatewise-to-global implication fails
maximally.

The example is not a claim about a particular PCP. It is a lower bound on what
can be inferred from rectangular (per-coordinate) information alone.

## Relation to distributional soundness

DHK-style distributional soundness is compatible with an ideal object whose
valid-word choice depends on the random tape. Such a mechanism can still be
globally coupled if one fixed seed determines one word and that same seed is
reused across sampled coordinates. The rectangularity theorem targets the weaker
case in which the coordinate answers are justified independently, or by
random-tape-dependent words without a same-seed joint guarantee.

Consequently, a positive shared-proof theorem must provide at least one of:

- a same-seed word \(Y(S)\) used for all coordinates under a fixed policy/random
  seed \(S\);
- a singleton target projection, so all valid witnesses agree on the decoded
  target word;
- an explicit proof that
  \(\operatorname{Rect}(\mathcal Y)\subseteq\mathcal Y_{\le\varepsilon}\);
- a stronger distributional/outer consistency statement that implies one of
  the preceding conditions.

Ordinary list soundness, \(\forall j\,\exists y^{(j)}\), or
\(\forall R\,\exists y(R)\) does not imply any of them.

## Scope

The theorem is a black-box criterion, not an unconditional impossibility result
for dPCP/PCPP. A concrete construction could make the rectangular hull small by
proving strong cross-coordinate correlations. The top-level positive target is
therefore precise: establish rectangular-hull containment (or an equivalent
same-seed/global-word coupling) at the RW/JK address scale, or prove a coding
lower bound showing that such containment costs superlinear proof length or
locality.
