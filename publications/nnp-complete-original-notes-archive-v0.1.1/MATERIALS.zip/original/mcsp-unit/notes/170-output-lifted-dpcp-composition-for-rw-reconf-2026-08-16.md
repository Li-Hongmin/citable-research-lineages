> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 输出提升式 dPCP 组合：绕开 history 替换，但不降低 RW 的 q 尺度（2026-08-16）

## 结论

note 169 的直接替换路线要求把逐坐标 dPCP 拼接表 \(P_x\) 本身变成 RW 的
J--K hard table，这需要尚未证明的 compositional history compiler。这里有一个更稳的
组合方式：令 \(P_x\) 作为一个新的多输出函数 \(F(x)\) 的**输出**，照常运行
RW Theorem 4.1 得到 \(F\) 的 computation-history PCP \(\Xi_x\)；在 Reconf 的最终 query
中，用低度自校正器读取 \(\Xi_x\) 的输出区 \(P_x\) 的局部 bits，再运行对应的 dPCP
verifier。

这条组合在明确的接口假设下成立，因而不再需要 \(\Xi_x=P_x\)。但它只消除
“dPCP proof 不能直接作为 J--K history”的嵌入缺口；query 仍然是
\(\operatorname{poly}(q,r,\log t)\)，没有解决本项目的 q 到输入尺度压缩，也没有单独
推出 \(P\ne NP\)。

## 1. 定义输出提升函数

设 \(C_x(w)\) 是 RW 为原多输出函数
\(g(x)\in\{0,1\}^{\ell}\) 构造的 computation-history SAT 电路，所有满足 assignment
的合法 history 对确定性机器的输出都一致。对每个 \(i\in[\ell]\)、\(b\in\{0,1\}\)，令

\[
  \varphi_{x,i,b}(w):=C_x(w)\land[\operatorname{out}_i(w)=b].
\]

假设 dPCP 编译器有一个确定性的 proof map \(\operatorname{Proof}(\varphi,w)\)，在给定
满足 assignment \(w\) 时生成完美完备 proof；proof alphabet 以固定长度二进制编码。
定义 \(\pi_{x,i,b}\) 为：

* 若 \(\varphi_{x,i,b}\) 可满足，取其 lexicographically first satisfying assignment
  \(w_{x,i,b}\)，令 \(\pi_{x,i,b}=\operatorname{Proof}(\varphi_{x,i,b},w_{x,i,b})\)；
* 若不可满足，令 \(\pi_{x,i,b}=0^{L_*}\)。

令

\[
  F(x):=P_x:=
  \mathop{\Vert}_{i\in[\ell],\,b\in\{0,1\}}\pi_{x,i,b},
  \qquad |P_x|=T_F=2\ell L_* .
\]

这里 \(L_*=\operatorname{poly}(t)\) 是单个 dPCP proof 的统一 padded length。若
\(\operatorname{Proof}\) 可由给定 witness 在 \(\operatorname{poly}(t)\) 时间生成，则
\(F\) 可由 SAT oracle 计算：所有 \((i,b)\) 的 prefix self-reductions 可并行批处理，
只需 \(O(\log t)\) 个自适应 oracle rounds，查询长度为 \(\operatorname{poly}(t)\)，总时间
仍为 \(\operatorname{poly}(t)\)。这是一个额外的 uniform proof-generation 假设，不能从
“存在 dPCP proof”四个字自动推出。

若 \(g(x)_i=b\)，则 \(\varphi_{x,i,b}\) 可满足；若 \(g(x)_i\ne b\)，则它不可满足。
因此 \(\pi_{x,i,1}\) 是“声明 \(g_i=1\)”的 dPCP proof，且在 \(g_i=0\) 时只是任意
padding 字符串。

## 2. 条件性组合引理

设 \(H=F\)，对 \(H\) 应用 RW Theorem 4.1，输入长度为 \(n\)、输出长度为 \(T_F\)，
并得到 Solve_H 和 Reconf_H。设某个 \(G\) 使 Solve_H(x,G) 对固定 \(x\) 处于
failure 分支；于是 theorem 给出一个 computation-history PCP \(\Xi_x\)，以及其
\(O(k^4\log T_F)\)-size 的小电路候选。

构造 \(\operatorname{Reconf}^{g}(x,i)\)：

1. 先照 Reconf_H 的 prefix rounds，使用同一组 smart-prMA queries 恢复
   \(\Xi_x\) 的 canonical prefix \(p_x\)；
2. 最终 query 中 Merlin 提交一个 circuit \(C\)，其 truth table 是候选 \(\Xi_C\)；
3. Arthur 检查 \(C\) 对 \(H\) 的 computation-history verifier，并检查
   \(p_x\) 的 prefix 条件；
4. 随机选择组件 \((i,1)\) 的 dPCP constraint/decoder edge。该边所需的每个
   \(P_x\)-symbol 不直接由 \(C\) 输出，而由低度自校正器从 \(\Xi_C\) 的
   \(\operatorname{out}\)-区读取；
5. 仅当该 dPCP edge 接受时输出 YES。

假设单组件 dPCP 满足：

* 若 \(\varphi_{x,i,1}\) 可满足，则存在 proof 使 verifier 完美接受；
* 若 \(\varphi_{x,i,1}\) 不可满足，则任意 proof assignment 的接受率至多
  \(\epsilon<1/2\)；
* 组件的随机边、decoder、输出偏移和自校正所需地址均可在
  \(\operatorname{poly}(k,r,\log T_F)\) 大小内生成。

则 \(\operatorname{Reconf}^{g}(x,i)\) 是 smart-prMA bit query，且输出
\(g(x)_i\)。

### 证明

若 \(g(x)_i=1\)，实际 \(\Xi_x\) 的输出区等于 \(F(x)=P_x\)，其中组件
\(\pi_{x,i,1}\) 来自可满足公式 \(\varphi_{x,i,1}\)，故实际 history circuit
作为 Merlin response 给出完备性。低度自校正器的错误概率可通过固定重复降到任意
小常数。

若 \(g(x)_i=0\)，则 \(\varphi_{x,i,1}\) 不可满足。对任意 Merlin circuit \(C\)：

* 若 computation-history verifier 的接受率不超过 \(1/2\)，最终 query 直接落在
  prMA 的 NO 侧；
* 否则，RW Theorem 3.5 的 soundness 分支适用。若 \(C\) 的 prefix 小于
  \(p_x\)，prefix 检查以高概率拒绝；若 prefix 等于 \(p_x\)，则其输出区必须等于
  正确的 \(F(x)=P_x\)。此时组件 \((i,1)\) 是不可满足公式的 dPCP proof，接受率至多
  \(\epsilon<1/2\)（加上自校正误差仍可留出常数 gap）。

因此所有实际 query 均满足同一 smart promise；同一 \(\Xi_x\) circuit 被所有坐标
复用，不存在逐坐标切换不同 dPCP witness 的 word-consistency 问题。证毕。

## 3. 复杂度与边界

若 \(L_*=\operatorname{poly}(t)\)，则 \(T_F=2\ell L_*=\operatorname{poly}(t)\)，
从而

\[
  \log T_F=O(\log t).
\]

所以这条组合不增加指数长度；但它仍把 dPCP verifier 嵌套在 RW 的 history query
内部，实际成本至少是

\[
  \operatorname{poly}\bigl(k,r,\log T_F,\text{local-dPCP-cost}\bigr)
  =
  \operatorname{poly}\bigl(k,r,\log t,\text{local-dPCP-cost}\bigr).
\]

若 dPCP 只给出存在性 proof、没有 uniform \(\operatorname{Proof}(\varphi,w)\)，则
\(F\) 甚至不一定是该 SAT-oracle machine 可计算的确定函数。若局部 constraint/decoder
不能按组件 index 在 \(\operatorname{poly}(k,r,\log t)\) 内生成，则最终 query 仍超出
RW 预算。

更重要的是，这条方法没有改变 J--K 的 hard table：J--K 仍作用于 \(\Xi_x\)，只是
\(\Xi_x\) 的输出区被解释为 \(P_x\)。因此它不能把 \(\operatorname{poly}(q,\cdots)\)
自动降到 \(\operatorname{poly}(n,\cdots)\)；也不能消除全输入 failure、hardness
threshold 或 actual-history tuple supply 等已有缺口。

## 4. 与直接替换的区别

直接替换要求

\[
  \Xi_x=P_x
  \quad\text{或至少 }P_x\text{ 是 }\Xi_x\text{ 的 choice-robust canonical 区段},
\]

这是 note 169 所指出的 compositional history compiler。输出提升只要求
\(P_x=\operatorname{out}(\Xi_x)\)，而这是 RW Theorem 3.5 本来就提供的；代价是必须
先把所有 dPCP components 作为一个多输出函数显式计算出来。

因此两条路线的逻辑地位不同：

* **直接替换：** 证明更短，但需要新的 history embedding；
* **输出提升：** 可以复用现有 history PCP，但输出长度、SAT-oracle 计算和 q-scale
  Reconf 仍在，不能单独构成 P vs NP 证明。

## 5. 证据边界

RW Theorem 4.1/3.5 的输入、history verifier、prefix soundness 和 failure-to-small-
circuit 语义来自 Ren--Williams 原始报告
[TR26-118 revision 1](https://eccc.weizmann.ac.uk/report/2026/118/revision/1/download)。
dPCP/udPCP 的完备性、soundness 与近线性 proof 参数来自
[Gur--Min--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/html/2512.12960)。

本 note 的输出提升引理需要三个额外事实：统一 proof map、组件局部生成、以及对
\(F\) 的 history output 进行低度自校正；它不声称这些条件已由现有两篇论文共同证明。

