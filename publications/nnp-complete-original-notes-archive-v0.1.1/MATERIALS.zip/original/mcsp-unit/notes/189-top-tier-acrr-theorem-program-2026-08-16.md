> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# ACRR 顶级定理攻坚计划：同时坐标鲁棒 PCP 与 RLDC/LDC 下界（2026-08-16）

## 结论地位

这是一份研究计划与可证伪命题集合，不是已经证明的主定理。项目标准正式改为：

> 目标是解决 `P != NP`，或得到至少 FOCS/STOC 量级的新 PCP/coding、
> circuit/Range-Avoidance 或一般不可能性定理；CCC 是专业基准，但不把局部
> decoder 失败当作终点。

现有约 168 个细分 note 是内部搜索轨迹，不按数量衡量贡献。本 note 只保留能改变
下一步数学决策的主问题、证伪条件和晋级门槛。

## 1. 核心问题：Sim-CR-ACRR

本计划的 headline 不是“再找到一个 RW/JK 局部接口”，而是回答：

> **Can near-linear decodable PCPs be made simultaneously coordinate-robust with one
> global proof?**

这一定理问题按双向夹击推进：正向寻找 shared target-binding/coordinate-robust
dPCP；反向把任何满足 ACRR 量词的对象归约到 RLDC/LDC 或超线性编码代价。若两边
都不能在明确参数窗口内形成一般定理，则该候选不再扩写局部障碍。

固定输入实例 `x`、输出词 `f_x in {0,1}^k`、proof 地址空间 `A_x`。要求存在一个
全局 proof `Pi_x`，以及对每个坐标 `i` 和声明位 `b` 的统一局部 verifier
`V_{x,i,b}`，满足：

1. **同一对象：** 所有 `(i,b)` 使用同一个 `Pi_x`、同一地址空间和同一策略；
2. **完备性：** `b=f_x[i]` 时，`V_{x,i,b}` 在 `Pi_x` 上以概率 1（或固定常数阈值）接受；
3. **逐坐标 soundness：** `b != f_x[i]` 时，对任意候选全局 proof，接受率至多
   `beta < 1/2`；
4. **地址尺度：** 查询、量词字符串和 verifier 描述大小为 `poly(n, log T)`，而非
   `q`-尺度的显式 history；
5. **整词一致：** 不能为不同坐标切换 proof、preimage、Merlin strategy 或 suffix；
6. **无隐藏 advice：** `Pi_x` 不能只是把完整 computation history 改名后塞进 advice；
7. **统一性：** graph、约束、decoder 与 output embedding 均由固定算法生成。

这一定义是 ACRR 主线的唯一一级开放接口。note 121 只证明其作为 RW/JK 输入时的
条件性充分性，不声称接口已经存在。

## 2. 双向主定理目标

### 目标 A：构造定理

构造 near-linear、constant-query 的 **simultaneous coordinate-robust dPCP/PCPP**，
或一个足以嵌入 RW/JK 地址尺度的 ACRR。最低交付必须同时给出：

`proof length, alphabet, query count, completeness, coordinate soundness,
address generation, uniformity, target binding, word consistency`。

普通 list-decoding/unique-decoding 的平均坐标保证不算目标 A；分别为每个坐标重新
编译 proof 也不算目标 A。

### 目标 B：一般性不可能性定理

证明任何满足上述 ACRR 量词的对象，在明确编码语义下都会产生过强的 RLDC/LDC，或
必须支付超线性 proof/encoding/locality 代价。最强的当前受限基线是：

* smooth 或低命中 adaptive query path 加上 disagreement-hitting，给出距离下界；
* codeword completeness 与**常数半径** target-relative robust-near-oracle wrong-bit
  soundness 已由 note 193 自动给出距离，并可阈值编译为 relaxed LDC，从而触发已知的
  超线性长度障碍。

因此在 family-level target-relative 模型中，集中核心不再是独立逃逸：note 193 已将
整个模型送入 relaxed-LDC barrier。集中核心问题只继续保留在单目标 RW/JK、
codeword-only soundness，或尚未完成 family lifting 的较弱模型中；那里不能直接调用
family-level LDC 下界。

当前新增的最小 family-lifting 接口是“equivariant orbit lifting”：若一个 base target
的 verifier 对所有坐标 target-independent，proof action 是 Hamming isometry，且
acceptance semantics 对完整 target/proof orbit 精确协变，则该单目标接口自动生成
orbit 上的 family-level ACRR，阈值化 locality 为
\(O(q(\alpha-\beta)^{-2})\)。full bit-flip orbit 下，这直接落入 family-level RLDC
barrier；因此任何成功的单目标构造必须明确打破 target-independent covariance、缩小
orbit、退化半径/gap，或离开 family-level proof-length 窗口。该判据比 public
address symmetrization 更强，不能把 C133 的 profile invariance 当作其前提；正式
陈述见 [Equivariant orbit lifting](../../rw-jk-succinct-reconstruction/statements/equivariant-orbit-lift-to-family-rldc.md)。
该 lift 对统一 acceptance-semantic defect \(\xi\) 稳定：只要
\(\alpha-\beta-2\xi>0\)，family gap 仍为正，locality 变为
\(O(q(\alpha-\beta-2\xi)^{-2})\)。因此“小的非协变实现误差”不是 full-orbit 的逃逸。

调用 RLDC/LDC 下界时必须区分单目标 ACRR 与 code-family 语义：note 192 证明，固定
verifier 对所有消息的全 oracle 错误 soundness 会与跨消息完备性冲突。本文的 ACRR
接口是单目标 RW/JK 语义；任何 family-level barrier 都必须显式改用 target-relative
near-oracle soundness，不能把两种量词直接拼接。note 193 表明，一旦完成这种 family
升级，集中查询核心本身已不是逃逸；剩余难点是证明 RW history 能否完成该升级。

### 目标 C：分布式 soundness 桥接

研究 distributional soundness 是否能在同一 proof 地址空间上强制一个固定目标词，
并进一步给出逐坐标错误声明的常数拒绝率。必须同时证明：

* 分布中的理想 word 不随随机串或局部视图变化；
* target projection 是 singleton/集中而非一个短 list；
* 组合后的 verifier 仍共用同一个 global proof；
* implicit history 通道已压到 `poly(n,log T)`。

distributional 一词本身不等于 ACRR；若缺少上述量词，目标 C 只得到 phantom-witness
separation，而不是正向定理。

更强的 black-box 量化边界现已固定：若该路线只暴露坐标加权平均错误率
`sum_j w_j e_j<=delta`，则最坏坐标错误率恰为 `min(1,delta/w_min)`；均匀输出坐标
下，常数 `delta` 不可能推出所有坐标的常数 gap，除非先把 distributional error 降到
`O(1/k)`。因此 C 的真正正向任务不是再调整 sampling，而是增加 coordinate-normalized
target binding、全局一致性或让错误坐标在外码中占常数质量。正式证明见
[weighted distributional-to-coordinate barrier](../../rw-jk-succinct-reconstruction/statements/distributional-to-coordinate-weight-barrier.md)。
这条 route 现在已有一个 source-specific top-tier theorem module：GMWZ/BMVY 的
shared-top sampler 与 Dikstein--Dinur 的 \(V\)-test 对齐；BMVY affine-building 群
过滤的相邻有限商在位移至少 4 时给出有限连通 cover；DDL Theorem 3.15 对同一商族
给出截断 two-sided 参数，取环境维数 \(d\ge3K\)、素数足够大即满足
\(\lambda<.99/K\)。因此 DD Lemma 1.2 已给出高 agreement、但对任何 base global
word 只有 \(\exp(-\Omega(K))\) 近似率的 face table；ordinary DPT/distributional
soundness 不能在该 source 上黑箱地产生 RW 所需的 base-address global word。负面结论
不需要 swap-cocycle；后者只属于 cover-aware 正面 theorem。正式记录见
[note 202](202-bmvy-ddl-parameter-closure-for-cover-obstruction-2026-08-16.md)；
它仍不外推为一般 dPCP 或 RLDC/LDC 不可能性。
对 TR25-217 的固定 `epsilon` 2-query dPCP/3-query PCPP，这还形成一个具体参数门槛：
singleton 输出若要得到固定坐标 `beta`-soundness，必须把 `epsilon` 降到 `O(1/k)`；
现有定理没有给出该衰减误差下统一受控的近线性指数。因此继续攻打 C 的正向路线时，
首要目标应是一个带 `epsilon=Theta(1/k)` 记账的 coordinate-normalized composition，
而不是把固定 `epsilon` 的 dPCP 直接接到坐标 decoder。

对 DHK 的具体黑箱接口，已核验的额外边界是：一次调用批处理 `k` 个 field-valued
坐标会把函数元组长度推到 `ell>=k`，并把其已知 answer-size 推到 `O(m(m+k))`；逐坐标
调用则只有逐个 `(Phi,F_i)` 存在 proof 的量词，且完备 assignment 的 `b_i=F_i(a)`
随坐标改变。因而 DHK 不能在不新增 output-independent shared commitment、共同地址
空间和外层 coordinate check 的前提下，直接成为 RW 的 simultaneous ACRR。这个结论是
对 DHK source-specific black-box substitution 的路线关闭，不是一般 dPCP separation；
正式记录见 [DHK batching barrier](../../rw-jk-succinct-reconstruction/statements/dhk-output-tuple-batching-barrier.md)。

还需排除一个更强的乐观解释：GM--W--Z 的 complete decoding distribution 即使满足
agnostic，且使用 robust dPCP 而非普通 list soundness，仍不能黑箱地产生固定坐标鲁棒性。
一个单自由符号、恒真约束的 singleton 反例可让平均错误率为 `1/n`，同时第一个坐标的
错误接受率为 `1`。所以正向构造必须增加 coordinate-normalized target binding、全局
语义检查或真正的外码放大；正式模块见
[agnostic average-to-coordinate separation](../../rw-jk-succinct-reconstruction/statements/agnostic-average-coordinate-separation.md)。

这里有一个严格的正向 conditioning bridge：若 singleton list soundness 对每个候选
proof 的列表只可能是 \(\{f_x\}\) 或空集，则在同一个 global proof 和同一个地址空间
上，固定坐标的错误声明接受率至多为 \(k\varepsilon\)（非均匀坐标权重为
\(\varepsilon/w_i\)）。因此 \(\varepsilon\le\beta/k\) 确实足以得到 simultaneous
coordinate robustness；证明见 [singleton distributional dPCP conditioning bridge](../../rw-jk-succinct-reconstruction/statements/singleton-distributional-dpcp-coordinate-conditioning-bridge.md)。
这解决的是 phantom-word 的一层量词缺口，而不是近线性构造本身：Gur--Minzer--Weissenberg--Zheng
的定理仍按每个固定 \(\varepsilon\) 给出参数，尚未提供 \(\varepsilon=\Theta(1/k)\)
时统一受控的字母表、对数指数和 RW/JK 地址生成。故该 bridge 将下一步明确收窄为：
在 \(1/k\) 级误差下保持近线性与统一性的参数化构造，或针对这一要求证明一般编码代价。

本日进一步得到一个更锋利的正向接口（主论文 Theorem 3.8）：不必把 \(L\) 个候选
proof 拼成 candidate bank；若单一 base proof 的 decoder 输出 \((a,b)\)，并存在一个
跨所有坐标共享的 indexed list \(Y=(y_1,\ldots,y_L)\)，使目标索引 \(s\) 满足
\(y_s=m^{(s)}\)，则附加 \(R=\lceil P_0/k\rceil\) 个 selector repetition 即可把
错误分支压到 \(\varepsilon+2\rho_\star\)，selector-symbol proof length 仅
\(N\le2P_0+k\)，与 \(L\) 无关；二进制编码只把长度乘上
\(\lceil\log L\rceil\)，并增加 \(O(\log L)\) 查询。于是即便
\(L=k^{O(1)}\)，长度仍可近线性，真正缺口被压缩为“indexed, globally labelled list”
的构造。普通 GMWZ list soundness 只有未标号的逐坐标集合，未给出这个共享 \(Y\)；
因此该接口是 T2/T3 的新正向定理目标，不是现有 dPCP 的黑箱推论。

进一步，把一个 \(\lambda\)-smooth 的外码 decoder 接在 indexed list 上，可把 codeword
坐标平均误差 \(\varepsilon\) 变成固定消息坐标错误
\(q_D\lambda\varepsilon+2\rho_\star\)，而 proof length 仍只为
\(N\le2P_0+k\)（主论文 Theorem 3.9）。这给出下一步最清晰的参数分叉：若所有可行
外码都强制 \(\lambda=\Theta(k)\)，则回到 \(\varepsilon=O(1/k)\)；若能在 indexed
global list 前提下实现 \(\lambda=O(1)\)，则可能绕开平均到坐标的旧障碍，形成新的
近线性 simultaneous ACRR。该推论仍是条件性 compiler，不把 GMWZ 当前 ordinary
list soundness 误当作 indexed/global list。

本轮把该正向接口再推进一步：Theorem 3.9A 允许目标 indexed word 只落在
外码字的固定 \(\delta\)-球内，只要 outer decoder 在整个近码字球上仍保持完备率
\(\alpha_C\)、错误率 \(\beta_C\)，并对近码字诚实 transcript 保持 \(\lambda\)-smooth。
同一 selector 编译的错误界精确变为
\(\beta_C+q_D\lambda\varepsilon+2\rho_\star\)，proof length 与 query count 不变。
这不是对现有 dPCP 的自动升级：它把新的承重缺口明确收束为近码字 smoothness；若
\(\lambda=\Theta(k)\)，仍需 \(\varepsilon=O(1/k)\)。正式陈述见
[approximate indexed-list outer-decoder bridge](../../rw-jk-succinct-reconstruction/statements/approximate-indexed-list-outer-decoder-bridge.md)。

再把 \(\varepsilon=O(1/k)\) 与 Proposition 3.10 的 indexed-label 信息界合并：
若某一候选路线实际暴露 \(L_k\ge\varepsilon_k^{-d}\) 个列表词，则必有
\(q\log_2|\Sigma|=\Omega(\log k)\)。因此固定 alphabet、固定 query 的路线必须先
证明 list 实际小于所有该幂次阈值，或放弃 target-independent local index channel；
这是一条参数化 no-go，不把 GMWZ 仅给出的 \(L=\operatorname{poly}(1/\varepsilon)\)
上界误作 list 下界。正式模块见
[inverse-linear indexed-channel tradeoff](../../rw-jk-succinct-reconstruction/statements/inverse-linear-index-channel-tradeoff.md)。

对这个正向接口还可以给出一个独立的 locality--alphabet 下界：若
target-independent decoder 必须在同一局部 transcript 中以完备率 \(\alpha\) 输出
\(L\) 个候选的 index，且最多查询 \(q\) 个 \(\Sigma\)-符号，则
\(\alpha L\le|\Sigma|^q\)。因此 fixed-alphabet、fixed-query 的普通 dPCP 不能
黑箱升级为 growing-list indexed decoder；binary labels 的 \(\Omega(\log L)\) 成本是
信息论必要条件。这条边界不证明 proof-length impossibility，但把 C128 的缺口精确
收窄为必须新增 index label channel、增大 locality，或增大回答字母表。正式证明见
[Indexed-label locality barrier](../../rw-jk-succinct-reconstruction/statements/indexed-label-locality-barrier.md)
与主论文 Proposition 3.10。

本轮又得到一个与 proof length 无关的 list-size 过滤器。若一个外层
\(q\)-ary code 只通过 coordinatewise list projection 绑定目标，并要求任意不含目标
的 \(L\)-列表在任意坐标分布 \(w\) 下都有至少 \(\gamma\) 的质量避开目标符号，则 elementary anti-mixing
计数给出
\[
  L\le \frac{8q}{3\gamma}\log\frac4\gamma
\]
（当消息数 \(M\ge8q/(3\gamma)\)）。因此 fixed alphabet、fixed binding quality
下，\(L=k^{\Omega(1)}\) 的 ordinary list 路线不能靠更长 outer code 解决 phantom
word；必须引入 indexed/global consistency、增大 alphabet、限制列表族或让绑定质量
衰减。这个结果只针对 coordinatewise-list black-box 模型，正式证明见
[anti-mixing code list-size barrier](../../rw-jk-succinct-reconstruction/statements/anti-mixing-code-list-size-barrier.md)；
它强化 C125 的量词障碍，但不替代 Theorem 3.8 的 indexed-list 正向目标。

这条过滤器现在可以升级为一般黑箱不可能性，而不再把 anti-mixing 当成额外设计假设，
并且不依赖坐标采样是否均匀。
设 binder 在坐标 \(j\) 只看到候选 \(L\)-列表的无标号 multiset；若所有含目标的
列表都以率至少 \(\alpha\) 完备，而所有不含目标的列表平均接受率至多
\(\beta<\alpha\)，则对每个被目标符号覆盖的坐标，把列表中一个同符号候选替换为目标
不会改变局部视图，却把列表变成含目标列表。因此不含目标列表必有至少
\(\gamma=1-\beta/\alpha\) 的未覆盖坐标，再由 C140 得
\[
  L\le \frac{8q}{3\gamma}\log\frac4\gamma
\]
（\(M\ge8q/(3\gamma)\)）。这允许任意随机 predicate 及其对目标、坐标的依赖，
真正排除的是整个 coordinatewise unlabelled-binding 黑箱；index/common-strategy/
cross-coordinate channel 仍是正面构造的明确逃逸口。正式陈述见
[coordinatewise unlabelled binding forces anti-mixing](../../rw-jk-succinct-reconstruction/statements/coordinatewise-list-binder-implies-anti-mixing.md)
与主论文 Proposition 3.6B。
同一替换证明还给出定量 trilemma：若含目标替换列表 \(T_j\) 的完备性基准为
\(\alpha\)，则覆盖坐标上的 deficit 满足
\[
  \sum_{j\ {\rm covered}}w_j(\alpha-a_{x,j}(T_j))_+
  \ge \bigl(\alpha(1-u_E(x,S))-\beta\bigr)_+ .
\]
若所有替换列表的损失至多 \(\delta<\alpha\)，仍可用
\(\gamma=1-\beta/(\alpha-\delta)\) 套用同一列表长度界；大列表因而必须显式支付
完备性损失，或离开无标号 coordinatewise 模型。正式式为主论文 (3.6j)--(3.6k)。

进一步，若该 index channel 在正半径邻域内仍以 gap \(\alpha-\beta>0\) 强制输出真实
index，则 index 的 \(\log_2L\) 位本身构成同 locality 的 relaxed LDC；因此任何适用的
relaxed-LDC/LDC 长度下界都会直接作用于 robust label channel。这条归约现在作为 C131
纳入项目标准：它把“同时绑定真实 index”从一个模糊的构造愿望提升为可直接调用的
coding-theoretic barrier。它不适用于 Theorem 3.8 允许附近 proof 切换到另一 list word
的普通 indexed-list 量词；正式表述见 [Robust indexed labels enter the RLDC barrier](../../rw-jk-succinct-reconstruction/statements/robust-indexed-label-rldc-barrier.md)
与主论文 Corollary 3.11。后续若主攻正面构造，必须明确说明如何避开该正半径
target-index 量词；若主攻一般下界，则应把适用的 RLDC/LDC 长度下界、alphabet/locality
参数和 RW 地址尺度逐项接上，而不能只重复普通 list soundness 的玩具反例。

一个更窄但可证伪的正向接口现在单独立项为 C132：允许 decoder 的错误 index 不是
逐次正确，而只要求归一化平均 index-error 至多 \(\eta\)，同时要求错误向量分布对
index 坐标置换交换。交换性把平均错误精确均匀化到每个坐标；若完备率
\(\alpha>\eta\)，即可得到 raw \(q\)-query RLDC，阈值放大后 locality 为
\(O(q(\alpha-\eta)^{-2})\)，并且 near-proof 量词自动强制 proof-map 距离。
这给 T1 一个真正的构造目标：从 distributional soundness 或公开对称化中证明同一
global proof 的 exchangeability；若做不到，则需要证明对称化、字母表或查询代价的
一般下界。该接口不把 ordinary list soundness 当作现成答案，正式证明见
[exchangeable approximate-index bridge](../../rw-jk-succinct-reconstruction/statements/exchangeable-approximate-index-rldc-bridge.md)。

C133 随后关闭了一个不能偷渡进 T1 的“免费对称化”想法：若 target-coordinate
wrong-bit profile 满足 \(p_{gs,gz}(gi)=p_{s,z}(i)\)，任何公开、目标无关的群 wrapper
都会精确保持整个错误剖面；协变异常坐标选择器 \(c(gs)=g c(s)\) 只是其特例，其平均
index-error 仍为 \((1-\alpha)/\ell\)，但异常坐标的错误率为 \(1-\alpha\)。Hadamard
family 给出完全显式的 realization。因此真正需要证明的是打破 equivariance、
target-independent error law 或 C132 级 orbit-averaged 条件，而不是单独展示
proof/address symmetry。正式分离见
[equivariant symmetrization separation](../../rw-jk-succinct-reconstruction/statements/equivariant-symmetrization-does-not-imply-exchangeability.md)。
注意 query-specific 的指数下界必须按接口记账：直接逐位读取 index 是 \(q\)-query
raw RLDC；若要求标准 \(2/3\) 完备/错误参数，需阈值放大到
\(Q=O(q(\alpha-\beta)^{-2})\)。只有在二元情形把 index 位内嵌进 codeword 后，才得到
raw \((q+1)\)-query（放大后 \(Q+1\)）RLDC；在 \(q=1\)、完美 indexed completeness、
\(\beta\le1/3\) 时才可合法调用 binary 2-query 指数下界，且结论作用于
\(\ell+N\) 而非未经内嵌的 \(N\)。

若把 singleton bridge 限定为目标 proof 的近邻 soundness，并放进一个
message-oblivious 的 target family，则完备性与 \(k\varepsilon\) 错误界会自动强制
proof-map 距离，随后可直接 message-inline 成正半径 \(q+1\)-query RLDC。于是固定
locality/alphabet、\(\varepsilon=\Theta(1/k)\)、常数近邻半径与
\(P=O(k\,\operatorname{polylog}k)\) 不能同时成立；这条组合障碍已正式写入
[target-relative singleton distributional dPCP to RLDC barrier](../../rw-jk-succinct-reconstruction/statements/singleton-distributional-dpcp-rldc-barrier.md)。
同时，若把 C90 的“所有候选 proof”量词直接保留到 message-oblivious family，则两个
不同目标的完备性/错误 soundness 会立即冲突；所以目标近邻限制不是技术装饰，而是
使 family 模型非空的必要条件。

## 3. 当前已核验基线与真正缺口

### 已核验基线

1. 暴露完整 history 后，近线性 PCPP + RLDC 能实现坐标语义，但 history 通道仍是
   `T`-尺度，不能直接接入 ACRR。
2. Meir 的 simultaneous linear verifier (SLV) 已展示“同一个 proof 同时验证多条线性
   断言”的正向机制，但其 soundness 保证是“若断言离合法子空间的相对距离为
   `epsilon`，则拒绝率至少为 `rho * epsilon`”。若把一条 RW 输出位嵌入长度为 `T`
   的完整 history 向量，原始坐标约束的距离只有 `epsilon=1/T`，因此直接套用 SLV
   **只能认证** `rho/T` 级别的拒绝下界，不能认证 ACRR 所需的常数 gap；这不是对所有
   额外 verifier 检查的上界或一般不可能性结论。要从该机制得到常数坐标鲁棒性，必须
   增加一个把相反目标类分离到常数距离的全局编码/target-binding 层，或另加独立的
   coordinate-robust check；这不是 SLV 定理自动提供的地址尺度压缩。
   更精确地，若 `W_{i,b}` 是声明 `b` 的合法 assignment 类、`x_*` 是诚实 history，
   令 `Delta_i=dist(x_*,W_{i,1-f_x[i]})`，则该黑箱转移只认证错误声明的拒绝率至少
   `rho*Delta_i`；要达到 ACRR 错误接受率 `beta`，至少需要
   `rho*Delta_i >= 1-beta`。原始坐标类的 `Delta_i=1/T`，而外层 target-binding code
   的职责正是把 `Delta_i` 提升到常数尺度。
3. 编码层本身已有一个强正例：Dinur--Evra--Livne--Lubotzky--Mozes 的 Good LTC 给出
   显式的常率、常距离、常查询代码。因此“把相反目标类拉到常数距离”不应再被当作
   编码理论上的未知黑箱；ACRR 真正未解决的是能否让同一个近线性 global proof 同时
   验证 `h\in H_x`、绑定该编码消息，并在 `poly(n,log T)` 地址尺度保持 word consistency。
   这一区分与 strong-LTC/RLDC 的 message-relative 正例一致：编码层可以完成，
   relation-PCP/target-binding 层仍是瓶颈。
   一个更细的组合接口现已固定为
   [robust message-PCPP composition](../../rw-jk-succinct-reconstruction/statements/robust-message-pcpp-to-acrr-composition.md)：
   若消息 oracle 上的 relation-PCPP 对 `gamma`-远离 `H_x` 的输入有 `beta_B` soundness，
   且每个错误输出位的消息都离 `H_x` 超过 `gamma`，则可用 RLDC 模拟其消息查询，
   在同一个 `C(m)||pi` 地址空间中得到 ACRR，错误率至多
   `max{epsilon_far,beta_B+(q_M+1)eta_D}`。这不是现有 RW 构造；它把 target-binding
   的正向任务精确拆成 `gamma`-target separation 与 `poly(n,log T)` message-PCPP，
   并说明 ordinary pair-language PCPP 的 proximity soundness 本身不够。
   若外层码 `C:{0,1}^k\to\Sigma^M` 的相对距离为 `delta_C`，则对
   `W_{i,b}={C(m):m_i=b}` 有 `dist(W_{i,0},W_{i,1})>=delta_C`；因此 SLV 的
   `rho*Delta_i` 转移在编码层确实能把原始 `1/T` 提升到常数，但前提是同一 proof
   还要证明编码消息属于实例关系 `H_x`。
4. 平均 list/unique soundness 不推出指定坐标鲁棒性；复制坐标只改变统计权重，不能
   排除“所有副本一致取错”的 assignment。
5. smooth/non-adaptive 以及满足 honest-path low-hitting 的 adaptive 方案会进入 LDC/RLDC
   barrier；disagreement-hitting 给出显式的 distance--query tradeoff。
6. 常数半径、固定 `alpha-beta>0` 的 robust-near-oracle soundness 即使允许 `bottom`，
   也可由 note 193 阈值编译为 `Q=O(q(alpha-beta)^(-2))` 的 adaptive relaxed LDC，
   并继承显式下界 `N>=k^(1+1/O(Q^2 log^2(Q+2)))`；同一正半径先强制 code distance。
   `bottom` 不是自动逃逸，但缩小半径仍是实质逃逸。

5. 最新的 shared-target-binding patch-boundary 模块把“坐标专属 verifier 能否独立
   强制错误”压成了可复用的不等式：若相反目标类与共享 base 的距离为 `Delta_i`，
   wrong-class certificate 在距离至少 `eta_i` 时的接受上界为 `beta_i`，候选全局
   proof 对重复 base 的平均腐蚀为 `gamma(W)`，则在任意 `tau<Delta_i-eta_i` 下
   `Pr[wrong] <= beta_i+zeta_i+gamma(W)/tau`。因此超过 `beta_i+zeta_i` 的常数
   forcing 必须支付共享 base 的成比例修改。这已经把 GM--W--Z wrapper 的复制反例
   提升为一个机制级定理，但仍不是一般 dPCP 不可能性；一般化的关键仍是证明所有
   非共享 target-binding 机制也必须暴露可付费的全局一致性通道。

6. profile-hitting 的 full-patch 端点已经可单独表述：若所有 private patches 能联合
   实现，且首次命中 patch boundary 就强制错误声明，则 patchable 区域在 honest query
   path 上的总质量至多为 `delta`，其余至少 `1-delta` 必须由 non-patchable global
   channel 承担。它仍是条件性结果，但为“集中查询核心/全局耦合代价”提供了统一的
   质量指标；下一般化问题是从 near-linear proof graph 的结构推出 patchability，或
   直接为该 non-patchable channel 建立编码信息下界。

7. 在 message-oblivious 的 family-level 语义下，若共同核心之外全部可联合 patch，
   且 disagreement hitting 仍成立，则上述质量下界与消息投影计数合并，迫使共同核心
   长度至少 \(k/\log_2|\Sigma|\)。这把“private patches + 短 shared key”从直觉障碍
   升级为可证伪的线性信息门槛；要得到超线性结果，下一步必须处理坐标/消息依赖核心，
   或把 non-patchable channel 的局部性进一步转成 RLDC/LDC 代价。

8. profile-rich 假设还可进一步削弱为一个 fractional certificate：实际 forcing
   profiles 与 honest query sets 之间的 hitting game 有精确 minimax 对偶。若能从
   具体 dPCP proof graph 构造一个分布 (lambda)，使每条允许的 query set 以至少
   (eta) 命中 (lambda)-profile，则错误声明 soundness 必须满足
   (deltageeta)。这为一般性 barrier 提供了比“所有小集合都可实现”更现实的
   可证伪接口。

9. **对具体近线性 dPCP 的首个攻坚检查已经收窄。** GM--Minzer--Weissenberg--Zheng
   的构造链保留 projection constraints；其中间 udPCP 还显式保持 left-canonical，
   但最终组合只保证 projection。因而 projection-rigidity 模块只能给出一侧结论：
   若左侧标签保持 honest、只改右侧集合 `P_B`，则每条 incident edge 都被拒绝，
   `Pr[accept] <= 1-mu(E(A,P_B))`；若右侧保持 honest，再加 left-canonical，则只
   得每个改动左点至少一条坏边，均匀 `d_A`-左正则时
   `Pr[accept] <= 1-|P_A|/(d_A|A|)`。这不是 C50 所需的逐边双向刚性，也不处理
   双侧同时修改。更强的是，最小两边图
   `π_0(0)=π_0(1)=0, π_1(0)=0, π_1(1)=1` 已给出一个 left-canonical 但可由
   `(0,0,0)` patch 到 `(1,0,1)` 的全边通过反例；所以不能再尝试从
   `projection + left-canonical` 直接推 C50。正式推论与证据边界见 C52/投影模块。

   因此下一次具体攻击只有两个可判定出口：

   * 证明该组合的 final dPCP 具有额外的逐边反向 injectivity/bi-rigidity（或可量化
     target-binding 星形扩张），并将其接入 C50--C51；
   * 或证明该性质在 composition 中确实丢失，立即停止把 left-canonical 当作
     simultaneous coordinate robustness 的替代品，转向 shared target-binding 或
     RLDC/LDC 归约。

10. **distributional 路线的熵审查。** singleton-output bridge 已经足以消除
    phantom target，但若 target word 与有限的 Merlin strategy summary 通过同一
    deterministic evaluator 生成，则摘要长度至少为目标族熵（C53）。因此一个真正的
    near-linear 正向构造必须在以下两项中明确选择：支付静态 target channel 的熵，或
    保留不可压缩的交互策略并另外证明 JK 的 parent closure、smartness 与 word
    consistency。仅把 distributional soundness 改名为 singleton target 不会自动完成
    history compression。

11. **近似 target-channel 熵界。** note 195 将上述审查从 exact deterministic evaluator
    升级到共同 randomized evaluator：若有限摘要对目标词族的平均 Hamming 误差为
    `eta<1/2`，则摘要长度至少为 `log|F|-kH_2(eta)`。这给 distributional 正向路线一个
    可直接证伪的晋级条件：只有在有效目标族熵足够低、或策略摘要不再有限/共同，才可能
    规避该界；后者必须另行证明 JK 的 parent closure 与 word consistency。

12. **INDEX 顺序是最后的量词分叉。** 若坐标暴露前先提交共同摘要，note 195 给出
    one-way random-access lower bound；若 Merlin 在看到坐标后才响应，短响应当然可能，
    但量词变成 `forall i exists tau_i`，不能直接形成 JK 的 deterministic word/parent
    seed。因此后续所有正向构造必须明确属于哪一侧，并在 index-aware 一侧额外证明同一
    strategy 的 parent closure；否则只是把 phantom witness 重新命名为交互协议。

13. **Key-indexed 二分已达到主定理候选。** 正式模块将短 key 选择的 verifier family
    分桶；每桶自动进入 relaxed-LDC sample reduction，得到 `h-s` 熵与
    `N^(1-theta)` 的定量不等式。它比纯 C54 更强，因为允许 target-dependent key，
    但要求同 key 桶内不切换 verifier。后续优先验证 RW/GM--W--Z 的候选是否满足这一
    量词；若满足，主线转为完整 barrier proof；若不满足，缺口被精确定位到
    target-specific hardwiring 或 index-aware strategy。

14. **半空间 canonical proof 合成已成为首个具体的双向攻击接口。** GKK 的 Theorem 3.2
    给每个 `(i,b)` 一个线性 canonical proof，但没有共享 proof。若存在统一对象
    `D(m)=m||C(m)||R(m)`，能以 `r` 次局部访问合成任一 half-space proof symbol，且
    错误 half-space 在常数输入半径内对任意 proof 保持 `beta_H<1/2`，则
    [shared half-space canonical-proof synthesis barrier](../../rw-jk-succinct-reconstruction/statements/shared-halfspace-canonical-synthesis-barrier.md)
    将其编译为 `Q<=1+q_C+q_P r` 的正半径 RLDC。这个接口比抽象 shared-key 更贴近
    具体 PCPP 构造：正向路线要么完成该合成并接受 RLDC 长度代价，要么证明
    half-space robust soundness、局部性或共同地址空间中的某一项必然失效。该定理
    不声称所有 dPCP 不可能，也不把 GKK 的分别构造误读成 simultaneous proof。

    适用性必须按有效目标族熵 `h=log|M|` 记账：GM--W--Z 的 full message family 有
    `h=k`，而固定 `n`-bit RW transducer 一般只有 `h<=n`。不能把 output length `k`
    自动当成 target-family entropy；否则会把 C55 的真实 barrier 误报成 RW 的无条件
    超线性下界。

    C56 把 index-aware 逃逸再量化：若坐标揭示后的 Merlin 响应只有 `r` 比特，并且
    错误声明对每个响应都保持 sound，则枚举响应只把 relaxed decoder 的 locality 放大为
    `Q_r=O(2^r q_0 (alpha-beta)^(-2))`。因此常数响应长度仍受 C55 的 RLDC barrier；
    `r=O(log k)` 已把 locality 推到 `poly(k)` 并使 DGL 指数退化；任意未压缩策略则
    退出有限响应模型，必须另证 JK parent closure，而不能把它当作免费绕过。

    该响应账本现在还有一个定量 subthreshold：在统一 DGL bound（含
    `|Sigma|^{Q_r}` overhead）、`N<=k polylog k`、`s<=(1-epsilon)k` 的窗口内，固定
    `c<1/3` 时 `r<=c log log k` 不能无限发生。因此任何无限 family 必须支付
    `r>=(1/3-o(1)) log log k`，或明确离开统一 DGL/radius/gap regime。该结论是条件性
    参数定理，不是所有 interactive PCP 的无条件下界；自足表述见
    [index-response loglog barrier]
    (../../rw-jk-succinct-reconstruction/statements/index-response-loglog-barrier.md)。

    这条 shared-key 结论与半径参数现已合成为
    [ACRR radius--key--length trilemma]
    (../../rw-jk-succinct-reconstruction/statements/acrr-radius-key-length-trilemma.md)。
    它把主线的可行性审查压成 (RKL-1)--(RKL-3)：若不支付 `Omega(k)` descriptor 熵，且
    仍处于 DGL 半径窗口与固定 query/alphabet，就必须支付显式超线性 proof length。
    这不是新外部下界，而是可直接用于筛选正向构造的总参数定理。

    对无 key 的 message-inline 特例，新增的
    [message-inline radius--proof-length gap]
    (../../rw-jk-succinct-reconstruction/statements/message-inline-radius-proof-length-gap.md)
    把 proof-relative 半径显式换算为 `delta=rho_{P,k}P/(2(k+P))`。在参数化 DGL
    窗口内，总长度必须满足 (G2)；若 `P<=k`，则任何进入窗口的候选都会与
    `N=k+P<=2k` 矛盾。该二分现在只把半径衰减 `rho_{P,k}->0` 留作短 proof
    逃逸；固定正半径的短 proof 可能性已由
    [message-inline Singleton barrier]
    (../../rw-jk-succinct-reconstruction/statements/message-inline-singleton-barrier.md)
    通过一般 Singleton 界关闭。C92 仍以参数化 DGL 的完整 admissible-growth
    封装为条件，不冒称一般不可能性定理。

14. **Sim-CR 的输入查询边界已闭合。** 若同一 global proof 对每个固定输出坐标的错误
    声明均 sound，则把候选输出词的一个坐标作为额外输入查询，直接得到 singleton-output
    `(q+1)`-query PCPP。于是 `q=1` 的 Sim-CR 会进入 2-query PCPP 的前沿；`q=2` 只
    达到现有 3-query PCPP 基线。这个归约不能反向把普通 dPCP 的平均/list soundness
    升级为 Sim-CR；真正的正向核心是消除该输入查询并保留逐坐标 target binding。详见
    [C57：Sim-CR 到 singleton PCPP 的查询边界](../../rw-jk-succinct-reconstruction/README.md)。

15. **Binary `q=1` 路线已有一般指数障碍。** message-inline 编译表明，若 Sim-CR 的
    proof alphabet 为二元、同一 global proof、完美完备、正半径且 `q=1`，即使局部
    verifier 非 projection、甚至自适应，也得到 binary weak adaptive 2-query Hamming
    RLDC。Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu 的 Theorem 1 给出指数长度
    下界，因此 binary non-projection `q=1` 的 near-linear family-level 构造已关闭；
    真正剩余的是非二元、`q>=2`、不完美完备性、零半径或单目标量词。详见
    [Message-inline RLDC compiler](../../rw-jk-succinct-reconstruction/statements/message-inline-rldc-compiler.md)
    与 [Block et al. 2026](https://arxiv.org/html/2602.20278)。

    进一步，固定有限 proof alphabet 也不能把“短 proof”作为独立逃逸：q-ary
    Singleton 界先由同一 family-level target-relative 正半径量词推出
    \(P=\Omega(k)\)，再经固定符号块二值化进入一般 RLDC 下界。于是 T1/T2 若要保留
    近线性长度，必须让 alphabet 增长、半径退化、family-level 量词失效，或改变
    target-relative/统一地址空间语义；仅把 binary 改成固定非二元 alphabet 不足以
    改变主判断。正式推导见
    [message-inline Singleton barrier]
    (../../rw-jk-succinct-reconstruction/statements/message-inline-singleton-barrier.md)。

16. **有限响应的真正代价是 branch support，而不是响应数量。** 若每个
    post-coordinate response 族虽可任意大但为有限，且所有 adaptive branches 的 union
    support 大小为 `L`，则一次读取该 support、离线枚举响应并阈值化两个 claim maxima，
    就得到 locality `L` 的 proof-only relaxed LDC。该 refinement 关闭了“增加大量有限
    Merlin responses 但仍访问短共同地址集”的伪逃逸；剩余的无界策略候选必须扩大
    branch support、改变量词，或真正离开有限轮次/有限响应字母表的策略模型。这里的
    响应字母表可以随码长增长，只要每个实例仍有限；标准 finite-horizon interactive
    Merlin 接口的全部 view-tree policies 仍是有限族，因此长策略描述本身不构成逃逸。
    在 descriptor 分桶的 payload family 中，同一论证把最大桶内的全策略 union support
    `L_*` 直接代入 key--support--length 不等式；响应字符串长度不再是独立逃逸参数。详见
    [branch-support barrier](../../rw-jk-succinct-reconstruction/statements/strategy-support-acrr-rldc-barrier.md)。
    对标准有限时间 bit-model 验证器，任意有限 Merlin 字符串也只能诱导有限 view tree；
    所以“无界策略”只有在验证器时间或信息模型本身无界时才真正离开该边界。

17. **有限消息字母与有限策略族不会产生新的地址尺度逃逸。** 这一点现在可以写成
    一个独立的 q-ary 编译器。设消息字母为有限集 \(\Gamma\)，同一 global proof 对每个
    坐标的正确声明完备率至少为 `alpha`；对目标半径内的每个错误声明、以及该声明的
    每一个有限策略都满足错误率至多 `beta<alpha`。若每个 `(i,a)` 的策略族为
    `P_{i,a}`，并令
    \[
      L=\max_i\left|\bigcup_{a\in\Gamma,\pi\in P_{i,a}}
        \operatorname{Supp}(V_{i,a,\pi})\right|,
      \qquad B=\max_{i,a}|P_{i,a}|,
    \]
    则阈值化同一 proof 的所有 \((|\Gamma|,B)\) 分支得到 q-ary relaxed decoder，
    locality 为
    \[
      O\!\left(
        L\,\frac{\log(|\Gamma|B/\eta)}{(\alpha-\beta)^2}
      \right).
    \]
    没有 finite-policy 压缩时，取 \(L=|\Gamma|q\) 即得
    \(O(|\Gamma|q\log(|\Gamma|/\eta)/(\alpha-\beta)^2)\)。证明和精确量词见
    [q-ary coordinate-robustness compiler](../../rw-jk-succinct-reconstruction/statements/qary-coordinate-robustness-rldc-compiler.md)。

    这把顶级攻坚的逃逸口进一步收窄：增加有限响应数量本身没有帮助；真正的代价是
    共同地址空间上暴露的 union support `L`。因此任何 near-linear 构造若仍满足
    common-address、all-policy、target-relative soundness，就自动进入 q-ary RLDC/LDC
    的长度障碍；若要绕开，必须明确改变至少一个量词（selected-policy-only、独立
    target proof、无界策略）、改变地址空间，或让 alphabet/locality/radius 付出可见代价。
    该结论是 C149--C150 的一般化过滤器，不是对 ordinary list soundness 的无条件
    不可能性断言。

### 新增正向桥：global-word distributional soundness 到 indexed channel

本轮把 T3 的正向入口收窄成一个可直接检验的定理。设同一 proof `z` 在所有坐标上
由某个固定候选词 `y^(s(z))` 解释，且平均错误率不超过
`epsilon < Delta/2`，候选词族两两相对距离至少 `Delta`。对 `r` 个独立坐标
采样并按匹配分数选最大候选，Hoeffding 给出
`r = ceil(2 log((L-1)/eta)/(Delta-2 epsilon)^2)`、`Q = r q`，
并以概率至少 `1-eta` 恢复 `s(z)`。若该条件对目标 proof 的整个 `rho`-球成立，
则得到 bounded-error indexed local decoder，并由词间分离推出 proof-map 的距离分离。
这是一条真正的正向机制：它不再把“每坐标存在一个局部答案”误当成同一全局词，
而是把 global-word 条件的代价明确记为 `O(q log(L/eta)/(Delta-2 epsilon)^2)`。

正式陈述见 [global-word distribution to indexed list bridge](../../rw-jk-succinct-reconstruction/statements/global-distribution-to-indexed-list-bridge.md)，
并登记为 C151。该定理仍是条件性的：候选族必须已知且两两分离，且 target binding、
history compression 和 JK parent closure 尚未由现有 dPCP 结果提供；ordinary list
soundness 不能自动推出它。因而 T3 的下一项唯一高价值问题是：能否在近线性地址尺度
证明这一 global-word 假设，或证明它必然支付 RLDC/LDC 型超线性代价。

C152 把该正向桥直接翻译回标准 dPCP 量词。若 satisfied-edge list soundness 的列表外
错误率为 `epsilon_list`，assignment 的不满足率为 `sigma`，且列表在坐标并集意义下
围绕一个中心词的半径为 `kappa`，则中心词的 global-word 错误率至多
`epsilon_list + sigma + kappa`。因此只要这三个损失之和小于候选词距的一半，C151
就产生 indexed channel。这里的 `sigma` 说明标准 dPCP 的“只在满足边上计错”不能被
忽略，`kappa` 则精确量化 phantom-word 混合；二者都必须由新构造或一般下界处理。
正式陈述见 [satisfying-list collapse to global-word bridge](../../rw-jk-succinct-reconstruction/statements/satisfying-list-collapse-to-global-word-bridge.md)。

还有一个更直接的 source-specific 接口：udPCP 的 unique-decoding soundness 已经给出
`exists w forall sampled coordinates` 的 global-word 量词。若有效词族两两距至少为
`Delta` 且误差 `eta_u<Delta/2`，则 C151 直接给出 indexed channel。于是对当前文献
路线，真正需要攻的是保持 unique decoding、保持词族分离并实现可计算的 index selection；
不是重新证明 global-word 存在。最终 dPCP 若只保留 list soundness，仍需支付 C152 的
`sigma+kappa` 损失。正式接口见
[udPCP unique-decoding to global-word index](../../rw-jk-succinct-reconstruction/statements/udpcp-unique-decoding-to-global-word-index.md)。

本轮又排除了一个过强的障碍定位：在 projection dPCP 上，标准 right-alphabet reduction
可以保留 unique decoding。若基系统的满足率阈值为 `epsilon_sat`、解码误差为 `eta_u`，
右侧编码的相对距离为 `delta_C`，则对每个右点按投影符号分布选最大质量符号，码距
集中引理给出恢复后的基 assignment 违约率至多 `2 epsilon'/delta_C`。所以当
`epsilon'<=delta_C epsilon_sat/2` 时，新系统仍由同一个 global word 解释，且解码误差
仍为 `eta_u`。这不是把 GMWZ 的 list theorem 升格为 unique decoding；它说明若输入
已经是 projection udPCP，alphabet reduction 本身不是必然损失。正式定理登记为 C154，
见 [projection right-alphabet reduction preserves unique decoding](../../rw-jk-succinct-reconstruction/statements/projection-right-alphabet-reduction-preserves-udpcp.md)。

进一步核对 GMWZ 的 right-degree reduction：其 Lemma 4.4 已明确证明，若输入 projection
dPCP 已有 unique decoding，
则每个右点的 expander sampler 可把任意新右侧 assignment 随机投影回一个旧 assignment。
expander mixing 只引入 `lambda=O(d'^{-1/2})` 的满足率误差；因此新系统在
`epsilon'<=epsilon_0-lambda` 时仍由同一个 global word 解释，解码误差不变。也就是说，
right-degree regularization 同样不是 UD→list 的必然损失点。C155 的正式陈述见
[projection right-degree reduction preserves unique decoding](../../rw-jk-succinct-reconstruction/statements/projection-right-degree-reduction-preserves-udpcp.md)。
当前最有价值的 source-specific 攻击已收窄为：追踪 unique decoding 是否在 gap
amplification、HDX routing 或真正的 dPCP composition 中首次失效；若这些步骤也能保留它，
就得到一个远强于当前 list-only 终点的 composition theorem。这里的 C155 是该文献结论的
自足重述与路线定位，不把它计作本项目新定理。

### GMWZ 第 6 节：首个可定位的 UD→list 量词损失

对 GMWZ Section 6 的证明逐行核对后，首个已确认的损失点不是右侧字母表或 right-degree
regularization，而是 direct-product gap amplification 的簇分解。其 Lemma 6.2 将一个左侧
表分成互不相交的重簇 \(\mathcal U_i\)，并为每个簇选出一个全局函数 \(f_i:X(1)\to\Sigma\)。
随后 base udPCP 的 unique-decoding 只分别给出

\[
 \Pr_{(t,u)\sim\mathcal Q_{\rm hdx}}
 [D_t(u,f_i(u))\ne (w_i)_t]\le\eta_i,
\]

而 Theorem 6.1 的最终证明使用列表 \(\{w_i\}\)，没有证明所有 \(w_i\) 相同。因而这里不是
“普通 list soundness 可能不够”的泛泛担忧，而是一个具体的同步量词缺失。

可把所需补桥写成下列 elementary synchronization criterion。令

\[
 Y_i(t,u):=D_t(u,f_i(u)),
 \qquad
 \rho_{ij}:=\Pr_{(t,u)\sim\mathcal Q_{\rm hdx}}[Y_i(t,u)\ne Y_j(t,u)].
\]

若每个簇的错误率至多 \(\eta\)，则 union bound 给出

\[
 \operatorname{dist}(w_i,w_j)\le \rho_{ij}+2\eta.
\tag{S}
\]

因此，只要候选词族具有相对距离 \(\Delta\)，并且对所有簇对都能证明

\[
 \rho_{ij}<\Delta-2\eta,
\]

就必有 \(w_i=w_j\)，从而可把 GMWZ 的 list 终点收回 global-word/UD 终点。当前 Lemma 6.2
只给出 \(\mathcal U_i\) 的 disjointness、每簇的局部 closeness 以及簇外排除条件，并不给
\(\rho_{ij}\) 的上界；因此 (S) 是一个精确的 source-specific 攻击目标，而不是现有定理的
隐含推论。若候选词族没有统一的 \(\Delta\)-separation，则必须先补这一假设或改用
target-relative/global-word 的替代量词。

这也给出下一轮的停止规则：若能从 HDX/direct-product 一致性推出 (S)，便得到一个实质的
UD-preserving gap-amplification theorem；若能构造满足 GMWZ Lemma 6.2 所有显式簇条件、但
\(\rho_{ij}\ge\Delta-2\eta\) 的 assignment，则得到一个针对该 proof skeleton 的严格
同步障碍。仅凭“存在多个 \(w_i\)”本身，尚不足以声称 GMWZ 构造不可能保持 UD。

这里还必须分开一个更早的量词。令 \(\xi_{ij}\) 表示在共享 \(s\)-面上、条件于
\(A\in\mathcal U_i,A'\in\mathcal U_j\) 后，base decoder 所见的 \((t,u)\) 边缘与其
未条件化分布之间的全变差距离。即使每个簇质量有常数下界，且 shared-top-face 的
两步算子有小二阶奇异值，也不能一般推出 \(\xi_{ij}=o(1)\)：在完全复形上取等大
顶点分割 \(V=S\sqcup T\)、\(k=2,s=1\)，\(\mathcal U_0=\{A:A\subseteq T\}\) 与
\(\mathcal U_1=\{|A\cap S|=1\}\)，cross event 强制共同顶点落在 \(T\)，而均匀
base decoder 的边缘仍以相等概率落在 \(S,T\)，故 \(\xi_{01}\ge 1/2\)。这不是
GMWZ 特定 HDX 的反例，而是说明谱 gate 之后还缺一个独立的 incidence-smoothness
定理；正式边界见 [heavy-cluster mixing does not imply decoder-marginal transfer]
(../../rw-jk-succinct-reconstruction/statements/heavy-cluster-mixing-does-not-imply-decoder-marginal-transfer.md)。
因此 T3 的正面攻击必须证明 Lemma 6.2 产生的特定簇满足该边缘转移，或证明任何此类
转移都支付 RLDC/LDC 型编码代价；不能再把 \(\xi_{ij}\) 当作 pair mixing 的自动副产物。
更强地，在 GMWZ Lemma 6.2 所用的 direct-product-test 假设下，取其低全局
agreement 表 \(T^{*}\)，并把任意给定的互不相交重簇 \(U_i\) 上的左表改写为
\(f_i|_A\)、其余位置保留 \(T^{*}[A]\)，即可同时满足该 lemma 的两条显式结论：
簇内距离为零，簇外的 shared-face 匹配仍由 \(T^{*}\) 的低 agreement 和同一个
direct-product soundness 步骤排除。因此仅从 Lemma 6.2 的输出量词出发，不可能推出
任何簇的 incidence regularity；必须使用额外的语义约束或修改 gap-amplification。
若额外语义试图把这些簇词暴露成同一地址空间的 index channel，则 prefix-free
决策树立即给出 \(\alpha J\le|\Sigma|^q\)。由于黑箱允许
\(J\le\delta^{-C}\)，在 \(\delta=\Theta(1/k)\) 时固定字母表必须支付
\(q=\Omega(\log k)\)；这条 selector 代价见
[cluster-only common-address selector barrier](../../rw-jk-succinct-reconstruction/statements/cluster-only-common-address-selector-barrier.md)。

保留一个更强、但明确条件化的正向出口：若 computation-generated 的每个簇函数
\(f_i\) 都在其重簇上接近同一个全局 vertex word \(g\)，且对每个实现的左面
\(A\)，条件于 \(A\) 的共同顶点 \(u\) 密度至多为 \(\Lambda/k\)，则可直接按错误集合
的质量计算
\[
\rho^{\rm cross}_{ij}\le
\frac{\Lambda(\mu_i\varepsilon_i+\mu_j\varepsilon_j)}{\gamma_{ij}}.
\]
在 \(\gamma_{ij}\ge\mu_0^2/2\) 时，跨簇 disagreement 至多
\(4\Lambda\varepsilon/\mu_0^2\)；若 cross marginal 与 base decoder 分布的 TV 距离为
\(\xi_{ij}\)，base 误差再加 \(\xi_{ij}\)。这使“全局一致性”从直觉变成一个可检验的 semantic
positive interface；但同步所需的 decoder 词误差必须在同一跨簇条件分布下计量，不能
未经 TV transfer 直接使用 base 分布误差。GMWZ Lemma 6.2 不自动提供全局 \(g\) 或
left-incidence smoothness；在其 \(\mu_0=\delta^C\) 记号下，若
\(f_i\) 与 \(T_1[A]\) 的误差为 \(\delta\)、而 \(T_1[A]\) 与 \(g|_A\) 的误差为
\(\kappa_i\)，则 base-distribution \(o(1)\) disagreement 至少需要
\(\Lambda(\delta+\max_i\kappa_i)+\xi_0=o(\delta^{2C})\)。正式命题见
[global-consistency cross-cluster transfer](../../rw-jk-succinct-reconstruction/statements/global-consistency-cross-cluster-transfer.md)
与主论文 Lemma 3.9I；该桥的 \(\gamma_{ij}^{-1}\) 损失在纯概率空间层面可达到，
所以若要改善它必须证明额外的 incidence anti-concentration；它是 T1/T3 的条件接口，
不是对现有 GMWZ 定理的升级。
GMWZ Section 6 对抽取词的 base decoder error 给出 \(5\sqrt\delta\) 级别；即使
乐观地补上全局 \(g\)、\(\Lambda\)-smoothness 与 TV transfer，仍需满足
\(\xi_0+4\Lambda(\delta+\max_i\kappa_i)/\delta^{2C}+10\sqrt\delta<\Delta\)。
这把 source 的实际误差参数也纳入同步 gate；它不是对未来 robust outer decoder 的
不可能性结论。

本轮把“能否真的拼接两个簇”压成了一个更窄的 assignment-level 命题。若存在两个
完美 base assignments \(F_0,F_1\)、两组左 \(k\)-faces \(U_0,U_1\) 和一个 vertex
labeling \(H\)，使 \(H|_A=F_i|_A\)（\(A\in U_i\)），则在右侧写入
\(H|_B\)、在 \(U_i\) 写入 \(F_i|_A\) 会让两簇的所有 projection edges 精确通过；
总 violation 只来自外部面。若 decoder-weighted word separation
\[
\Gamma_{01}=\frac1{|I|}\sum_t {\bf1}[w_{0,t}\ne w_{1,t}]
\min\{\Pr[U_0\mid t],\Pr[U_1\mid t]\}
\]
超过目标 unique-decoding 误差，就得到真实的 UD 反例，而不只是 Lemma 6.2 的黑箱
量词反例。可用 disagreement set \(D=\{F_0\ne F_1\}\) 的随机二染色生成候选
\(H,U_0,U_1\)；但在完整复形的基准计算中，若 \(|D|/|X(1)|=c/k\)，
两簇质量约为 \((1-c/(2k))^k\) 与
\((1-c/(2k))^k-(1-c/k)^k\)，外部混合质量约为
\(1-2(1-c/(2k))^k+(1-c/k)^k\)，而 \(\Gamma_{01}\) 只有
\(O(c/k)\)。这说明简单随机拼接在大 \(k\) 时通常无法同时满足“小 violation”
和“常数 UD 反例”；真正的 source attack 必须找到结构化、低混合的 disagreement
profile，或证明 HDX incidence 强制上述 tradeoff。正式命题见
[face-separable patchability obstruction](../../rw-jk-succinct-reconstruction/statements/face-separable-patchability-obstruction.md)
与主论文 Proposition 3.9J。若找不到这样的 profile，下一步就转向证明该 tradeoff
是 GMWZ HDX 的一般性质，而不是继续堆叠黑箱 cluster note。

进一步可把这个 tradeoff 写成一个真正的 sampler theorem target。若实际
\(X(1)\to X(k)\) 对所有 disjoint \(R,S\) 满足
\[
\Pr[A\cap S=\varnothing]\le e^{-k\mu(S)}+\varepsilon_{\rm fa},\qquad
\Pr[A\cap R=\varnothing,\ A\cap S\ne\varnothing]
\le k\mu(S)e^{-(k-1)\mu(R)}+\varepsilon_{\rm fa},
\]
则随机 split 的 \(\Gamma_{01}\) 至多
\(\operatorname{dist}(w_0,w_1)(4/k+\varepsilon_{\rm fa})\)。完整复形中这由
超几何/负相关直接成立；GMWZ 当前 Theorem 2.9 的 inclusion singular-value
条目并不自动给出这种高阶 face-avoidance。于是下一次实验不再是“寻找任意簇”，
而是二选一：从 GMWZ 的 HDX 构造证明该 sampler bound，得到 UD-preserving
方向；或构造违反它的 \(R,S\)，再用 C171 形成 source-specific UD 反例。

谱审查给出了一个更直接的已证门。对 Section 6 实际的 random split，若
complete decoding distribution 的坐标边缘与左 \(X(k)\)-面边缘均匀，令
\(\lambda_k\) 为 \(X(1)\leftrightarrow X(k)\) 的第二奇异值，则
\(\Gamma_{01}\le\sqrt2\lambda_k\)：\(U_0\) 避开 \(S\)、\(U_1\) 避开
\(R\)，expander mixing 给 \(\mu_0\le\lambda_k^2/s\)、\(\mu_1\le\lambda_k^2/r\)；
基础确定性完美解码给输出词距离不超过 \(r+s\)，再优化
\(\min\{2a,\lambda_k^2/a\}\)（\(a=\max\{r,s\}\)）即可。GMWZ Theorem 2.9
在 Section 6 参数下 \(\lambda_k=O(1/k)\)，所以同一 random-split family
已不能提供常数 UD 反例。FP8 仍保留为更强的距离加权尾界目标；主线应转向
decoder-conditioned 非均匀 patch 或真正跨坐标的 global assignment。

进一步把残余问题参数化：若对随机 split 的每个坐标有
\(\theta_i(t)\le\kappa\mu_i\)，则 \(\Gamma_{01}\le2\kappa\lambda_k^2\)。
所以 GMWZ 的 agnostic 只差一个 event-wise smoothness 证明；若该 smoothness
失败，失败证据本身就是坐标集中型 face event，可直接作为 source-specific
反例搜索对象。这比笼统追求 FP8 更窄，也更贴近 distributional-soundness 路线。

随后发现 C173 可完全去掉 random-split 限制：对任意公共 vertex labeling H，令
E_i={u:H(u)≠F_i(u)}。每个 U_i 面避开 E_i，E_0∪E_1 覆盖 base disagreement，
所以同一 mixing 计算给 Γ≤min{δ,2λ_k²}≤√2λ_k。由此 GMWZ 的
λ_k=O(1/k) 已关闭整个 C171 face-separable obstruction class。后续若要找到
source-specific 反例，必须构造非 vertex-word 右标签，或证明真正跨坐标的 global
assignment；这正是顶级论文路线的下一道实质门。

再进一步，C176 把非 vertex-word 右标签写成 collision gate：若两簇的
right-face 条件质量 p_i(B) 只偏离其全局质量 μ_i 一个 L2 参数 η，且右面
避开 disagreement 的质量为 ρ，则任意单右标签都会产生
\(\frac{\min\mu_i}{2}[1-\rho-4\eta^2(1/\mu_0+1/\mu_1)]_+\) 的投影冲突。
X(1)↔X(s) 的谱可控 ρ；唯一未决的 source calculation 是
X(k)↔X(√k) 的 L2 incidence profile。这已经把下一步从“寻找 patch”变成
一个明确的 HDX/distributional-soundness 定理目标。

### 回流报告吸收后的 source audit

外部回流再次提出了“固定 PH-local 解压器”和“distributional soundness + RLDC/LDC”两条
路线。前者在条件模型中可作为复杂度 benchmark，但全表 `FP^NP`/`E^NP` 搜索不能替代
base-address 的 RW/JK 接口；后者只有在 singleton target、同一 global proof、同一
strategy 和坐标级 soundness 都同时成立时才进入主线。详见合并吸收记录
[note 200](200-pnp-return-evidence-audit-and-high-order-incidence-gate-2026-08-16.md)。

原始来源核验后，不能把 GMWZ Theorem 2.9 的条目静默升级为任意
\(X(k)\to X(\sqrt{k})\) profile：该定理给出 \(X(1)\leftrightarrow X(i)\) 谱、
局部 link expansion 和 \((k,\sqrt{k})\) direct-product test，但没有直接给出所需的
高阶 \(L_2\) incidence。Bafna--Minzer 的结果仍说明低 soundness 不能由 spectral
expansion 单独推出，通常需要额外的 Unique-Games coboundary expansion。
不过在 BMVY 的精确 \(\mu_K\to\mu_{\sqrt K}\) 边缘内，BMVY Lemma 2.8 已给出高阶
profile，端点 \(\mu_{\sqrt K}\to\mu_1\) 由 Theorem 2.2 补上；这已经关闭
BMVY/DDL 源上的 arbitrary-right-label 两簇 patch（C180），但不关闭 cover sheet
或真正跨坐标的 global assignment。正式记录见
[note 203](203-bmvy-incidence-profile-closes-arbitrary-right-label-patch-2026-08-16.md)；
后续不再把该 source-specific gate 拆成更多局部 decoder note。

一个更锋利的正向/反向二分是把 GMWZ 的 direct-product test 直接作用于簇常值表。
若 (T_U[A]) 在簇 (U) 上为全 1、外部为全 0，且
(p(B)=\Pr[A\in U\mid B])，则

\[
 \operatorname{Acc}(T_U)=1-2\mu(1-\mu)+2\operatorname{Var}(p(B)).
\]

高 variance 因而等价于 DPT 一致性 excess；低 variance 可直接进入 C176。真正新的
定理目标是证明高 variance 时 DPT 能在两个重簇上同时提取近似 vertex words，并把
误差送回 C175/C176。DPT 现有定义只给一部分面上的 global-word 近似，不自动给出
双簇重质量或 exact common label，所以这条 “DPT-to-patch dichotomy” 仍是开放接口，
但比继续盲攻 raw (X(k)\to X(\sqrt{k})) profile 更可能形成领域级机制。

### 未解决的核心缺口

* **集中核心：** 在单目标、codeword-only soundness 或尚未完成 family lifting 的模型中，
  查询可能把几乎所有信息压在小坐标集合上；现有 smoothness/LDC 归约不能直接覆盖。
* **target binding：** dPCP 的局部 assignment 可能来自不同全局对象；需要 singleton
  target 或更强的 distributional consistency。
* **history compression：** 任何正向构造必须把完整 computation relation 压到地址尺度，
  且不能把 history 重新命名成 advice。

这三项是互相耦合的主缺口；单独优化 line decoder、FFT 或一个坐标的 PCP 不会改变它们。

## 4. 优先攻击的两个可证伪命题

### Conjecture A：弱语义下 Sim-CR dPCP 的集中核心二分

在**单目标、codeword-only soundness，或尚未完成 target-relative family lifting**的
语义下，对固定常数 alphabet、query 和 soundness gap，任何满足 ACRR 量词的 near-linear
proof code，要么：

* 在某个固定 `delta` 下具有足够的距离/诚实路径 hitting，从而可归约到 relaxed LDC；
* 要么存在一个集中查询核心 `K`，使诚实查询树以至少 `1-beta` 的概率落入 `K`，并且
  `K` 的大小、复制代价或地址描述长度满足一个超线性下界。

这不是当前定理。第一分支已由 note 186--193 在 target-relative family 模型下实现；
第二分支只针对上述较弱语义，仍是下一项真正的一般性下界目标。证明它将把 note 168
的玩具分离升级为可发表的 barrier theorem。

note 191 已先处理第二分支的共同核心特例：若一个坐标集对所有消息和目标坐标承载
超过错误 soundness `beta` 的诚实查询质量，则该集的投影必须编码全部消息，大小至少
`k/log|Sigma|`。因此剩余的真正开放对象是坐标/消息依赖的集中核心，以及能否对这类
核心建立 direct-sum 或 target-binding 代价定理。

这一缺口现在有一个更宽但仍严格的交叉边界：若 target-dependent verifier 只由 `s` 位
 descriptor 分桶，而每个目标在同桶内由至多 `r` 个共同物理地址位置的 specifying
 core 区分，则不需要 DGL 半径窗口也有
 `h-s <= log(r+1)+r log(eN|Sigma|/r)`。因此完整 `k`-bit family、`N=poly(k)`、
 `s=o(k)` 时，`r=o(k/log k)` 的“短 descriptor + 小 target-specific core”不能成为
 逃逸。该结果仍是 one-shot 同桶 core-hitting 的条件定理；独立 oracle 和无界坐标后
 策略不在其量词内。正式证明见 [descriptor-restricted specifying-set barrier]
 (../../rw-jk-succinct-reconstruction/statements/message-dependent-core-hitting-barrier.md)。

### Conjecture B：distributional soundness 不能黑箱产生 ACRR

任何只给平均坐标/list 的 distributional-soundness 组合器，若没有额外的 singleton
target-binding、全局 proof consistency 或 coordinate-robust outer check，就不能推出
ACRR 的逐坐标 soundness。可证伪的最小形式是构造一族 assignment，使每个坐标分别有
可接受的局部解释，但不存在一个对全部坐标同时有效的 global word/strategy。

若 Conjecture B 被证明为一般 separation，路线仍有独立价值：它明确告诉我们必须新增
哪一种 target-binding 机制，而不是继续堆叠平均 soundness。

## 5. 路线选择与停止规则

正向路线只保留一个主候选和一个备用候选：

* **主候选：** shared key + coordinate-robust verifier。首先验证
  `(K_x,i,b) -> V_{x,i,b}` 是否在地址尺度生成，并把所有坐标绑定到同一 key；
* **备用候选：** line-packing。只有当完整 canonical proof 长度满足
  `P <= k * polylog(k)` 时才继续；若 `P = omega(k*polylog(k))`，按 note 167
  的容量计算立即关闭，不再优化局部 decoder。

出现以下任一情况，立即关闭候选，不追加局部 note：

1. 每个坐标或 prefix 使用不同 proof；
2. 需要显式物化 `q`-bit seed、完整 truth table 或完整 history；
3. 只有平均/list soundness，没有指定坐标的常数 gap；
4. 把 history 隐藏在 nonuniform advice 或“canonical key”名称下；
5. 只得到 `E^NP`/全表尺度 outsider，却声称在 `poly(n,log T)` 地址尺度完成重构。

## 6. 晋级标准与交付物

| 里程碑 | 交付物 | 晋级标准 |
|---|---|---|
| M0 | 定义、符号、证据边界 | 已完成；以 ACRR、`n,q,T,P,s,i` 为权威记号 |
| M1 | average-to-coordinate 一般 separation 或集中核心下界 | 必须逐条满足原 dPCP/PCPP 量词，并给参数化代价 |
| M2 | 一个 shared-key ACRR 或 Sim-CR dPCP 构造 | 完整 proof/query/uniformity/soundness/target-binding 账本 |
| M3 | 连续论文模块 | 不依赖百余篇内部 note，外部读者可独立核验 |

只有 M1、M2 或 M3 之一能升级为新的 PCP/coding、circuit/Range-Avoidance 或一般
impossibility theorem 时，才把路线视为顶级论文候选。否则归档为搜索轨迹。

## 7. 外部依据与边界

* Ren--Williams 的 TR26-118 摘要明确其近最大 `2^n/n` 的 `E^{prMA}/_1` 下界使用
  Range Avoidance、PCP 与带 round/witness-length 记账的 `P^NP` 分析；这解释了 ACRR
  地址尺度问题的来源，但没有给出 ACRR。[ECCC TR26-118](https://eccc.weizmann.ac.il/report/2026/118/)
* Gur--Minzer--Weissenberg--Zheng 的 3-query RLDC 工作给出近二次长度 RLDC、并与同参数
  LDC 的近三次长度下界形成分离，同时使用近线性 PCPP 与 2-query dPCP；这提供了目标 B
  的参数参照，不自动推出 Sim-CR dPCP 不可能。[arXiv:2512.12960](https://arxiv.org/abs/2512.12960)
* Or Shalom Meir 的博士论文第 4.5 节给出 simultaneous linear verifier：同一 proof
  可同时验证多条线性子空间断言，但定理的 rejection ratio 按被违反断言的相对距离
  缩放；它是“同时 proof”先例，而不是本项目所需的固定坐标常数鲁棒接口。
  [Meir, *Combinatorial Constructions of Probabilistic Proof Systems*](https://www.wisdom.weizmann.ac.il/~oded/PDF/or-phd.pdf)
* Dinur--Evra--Livne--Lubotzky--Mozes 的 Good LTC 给出显式常率、常距离、常查询的
  locally testable codes；它可作为 ACRR 的 outer target-distance 层，但论文不提供
  RW computation relation 的 shared/address-scale binding。证据见
  [Good Locally Testable Codes](https://arxiv.org/abs/2207.11929)（Theorem 4.1）。
* Dinur--Harsha--Kindler 将 distributional soundness 用于模块化 PCP composition；它是
  目标 C 的候选工具，不是 ACRR 的现成全局一致性接口。[ECCC TR15-085](https://eccc.weizmann.ac.il/report/2015/085/)

还有两条与本项目的压缩目标直接相关的文献边界。Gur--Minzer--Weissenberg--Zheng
的 TR25-217 给出近线性 2-query dPCP 与 3-query PCPP，但明确把低 soundness 的
2-query PCPP 留作开放问题；因此 T2 的成功不能只被解释为把现有 dPCP 接一层
coordinate decoder。[TR25-217](https://eccc.weizmann.ac.il/report/2025/217/download)
另一方面，Bronfman--Rothblum 对 succinct PCP 的综述性边界指出，信息论 succinct
PCP 在标准复杂度假设下被认为不可行，已知的短 PCA 依赖 LWE 等计算假设；这类
computational soundness 不满足本项目对任意伪造 proof 的 ACRR soundness。[TR21-084](https://eccc.weizmann.ac.il/report/2021/084/)

以上三条是外部文献直接支持的背景事实；Conjecture A/B、集中核心代价和 ACRR 构造均
是本项目待证明的研究命题。

## 8. 第二阶段：逃逸矩阵与唯一攻坚入口

C58 关闭的是一个重要的窄架构，但“非二元/非 projection/更高查询”不能再被当作
笼统的剩余希望。今后每个候选必须先落入下面的量词矩阵，并给出相应的定理入口。

| 候选模型 | 已有可用归约或边界 | 继续研究的唯一理由 |
|---|---|---|
| 二元、projection、2-query、完美完备、正半径 target-relative | 直接成为 binary 2-query weak RLDC；C58 给指数长度下界 | 关闭，不再优化局部 decoder |
| 固定有限 alphabet、常数 query、正半径 target-relative | 直接进入 relaxed-LDC/RLDC 语义；C31/C55 给超线性或参数化下界 | 只有在证明 family lifting 失败、或给出新的非 LDC 语义时继续 |
| 非二元 projection | 定长符号编码后进入固定查询数 binary RLDC；因此固定 alphabet、正半径的近线性 family-level 构造仍受超线性下界约束，但二元 2-query 指数下界不能自动搬运 | 只有在证明 alphabet reduction 的指数强化、或明确离开固定 alphabet/正半径/family-level 量词时继续；不能把符号拆成 `log|Sigma|` 位就宣称得到 binary 2-query 指数界 |
| 非 projection、固定 query | C57 给 singleton-output `(q+1)`-query PCPP | `q=1` 若构成近线性 2-query PCPP，本身就是独立前沿结果；`q>=2` 必须说明为何不退化为已知 3-query 基线 |
| 不完美完备性 | C58 的指数下界不能直接使用 | 必须同时给出完备性放大、同一 global proof、target binding 和参数成本；若放大改变 proof/query 尺度，则按新参数重新审计 |
| 无正半径、仅 codeword-point soundness | 不自动形成 LDC/RLDC；C31 不适用 | 必须证明新的 codeword-only impossibility，或明确承认这是 ACRR 的真正逃逸而非继续套 LDC 术语 |

矩阵中的“继续研究”不是开放式许可，而是门槛：候选必须在地址尺度给出完整的
`(proof, alphabet, queries, completeness, target-relative soundness, uniformity)` 记账，
并且在第一步就说明它是否产生一个同一 global proof 的 codeword family。缺少这一量词
时，候选只记为路线描述，不进入主定理程序。

### 单目标量词的 payload-lifting 检验

“RW 只给一个目标”不能直接当作 family-level barrier 的反例。固定 context `u` 后，
若存在 `h` 位自由 payload `m`，输出坐标直接携带 `m`，而 verifier、proof 地址空间、
正半径和 target-relative gap 都对 `m` 不变，则
`C_u(m)=m||Pi_{u,m}` 已是 `(q+1)`-query family-level RLDC。正式证明见
[payload lifting family barrier](../../rw-jk-succinct-reconstruction/statements/payload-lifting-family-barrier.md)。
因此 T2/T3 的新构造必须在第一步给出一个明确逃逸：payload-dependent verifier 或
address space、仅有低熵子族、半径/完备性退化、逐坐标换 proof，或者只在 interactive
parent closure 中成立。逐坐标存在 Merlin 响应、重新编译 PCP 或单个 hardwired target
都不满足该 lifting 接口。

进一步，若 payload-dependent verifier 只是由 `s` 位 descriptor 选择，且坐标揭示后的
响应至多 `r` 位，则按 descriptor 分桶后仍进入 key-indexed RLDC tradeoff；有效 query
数为 `Q_r=O(2^r q_0(alpha-beta)^(-2))`。在固定 alphabet、`r=O(1)`、近线性 proof
的 DGL 窗口中，完整 `k`-bit payload 迫使 `s>=k-o(k)`。所以 T2/T3 不能把“verifier
依赖 payload”作为笼统正向证据：必须展示近乎全消息的 descriptor、未压缩交互策略、
逐消息独立地址空间，或明确离开 RLDC 半径/长度 regime。

一个更强、可直接检验的有限模式子类也已封闭：若 target-dependent address permutation、
bank selector 或 strategy 只取 `R` 个 mode，且所有 mode 都在同一物理 proof oracle 上对
错误 bit 保持 soundness，则枚举所有 `(bit,mode)` 给出 locality
`O(R q (alpha-beta)^(-2) log(R+2))` 的 RLDC。该 universal-address strengthening 见
[payload lifting family barrier](../../rw-jk-succinct-reconstruction/statements/payload-lifting-family-barrier.md)。
因此只有“仅真实 target mode sound”“每个 target 使用独立 oracle”或“无界交互策略”仍是
真正未封闭的地址/策略逃逸；有限 bank 或地址置换本身不再计为免费逃逸。

还可去掉短 core 计数中常被单独假设的 specifying-set 条件：若同 descriptor 桶内每个
目标每坐标都有一个完整策略，且错误声明对所有策略 sound，则该完整策略的 full
branch-support union `K_m` 自动区分同桶的所有 codewords。于是 `|K_m|<=r` 直接给出
`h-s<=log(r+1)+r log(eN|Sigma|/r)`，无需 DGL 正半径窗口；这把 target-specific
small-core 逃逸也接回标准有限时间 all-policy 量词。详见
[finite-time policy specifying-core barrier](../../rw-jk-succinct-reconstruction/statements/finite-time-policy-specifying-core-barrier.md)。
其尾界进一步说明：在高熵近线性桶中，短 core 的目标比例为指数小；因此必须同时
支付大 complete-policy core 与大 all-policy branch support，不能把信息藏在少数
从不完整的策略分支里。尾界积分还给出最大桶上 `Omega(k/log k)` 的平均 core 成本
（固定字母表、`N=k^{O(1)}`、`h-s=Omega(k)`）。

RW 侧的实际 history 容量路线也已抽成独立预算定理：长度 `L` 的 canonical history 在
`2q`-bit 对齐下至多提供 `L/(2q)` 个连续 JK windows；若 forcing 需要超过 `2^q`
个 actual tuples，则必须有 `L>2q2^q`。RW 当前 `L_i<=T_i^a`、`log T_i=o(q_i)`
参数区不满足该条件。该结论只关闭 actual-history/window-count forcing，不排除
compressed tuple oracle 或全新的 JK theorem；正式模块见
[RW fixed-history capacity budget](../../rw-jk-succinct-reconstruction/statements/rw-fixed-history-capacity-budget.md)。

对 compressed tuple oracle 还可给出一个直接语义障碍：若它以 key 长度 `d_i`、accessor
大小 `a_i` 在 base-address 复杂度下逐位暴露前一阶段的 AVOID outsider `B_i`，则
coverage 逆否给出的 `CC(B_i)>s(n_i)` 与 accessor 合成的
`CC(B_i)<=a_i+d_i+O(log L_i+log q_i)` 矛盾。故剩余压缩路线必须隐藏旧 payload、
承担 coverage-scale key/selector 成本或改变 target-binding 语义；正式模块见
[RW address-scale payload obstruction](../../rw-jk-succinct-reconstruction/statements/rw-address-scale-payload-obstruction.md)。

## 9. 三个可证伪的顶级定理入口

### T1：非二元 projection 的可验证 alphabet reduction

设 `Sigma` 为固定有限 alphabet。目标不是声称任意 `Sigma`-ary projection 都能二元化，
而是寻找一个明确的附加条件：每个局部 symbol、projection 约束和目标 decoder 都有
统一的 Boolean slice/bit-extractor，且该替换保持目标相对半径 `rho`、完美完备性和
错误 gap（允许显式的查询放大 `w(Sigma)`）。若能证明所得 binary code 是
`O(w(Sigma))`-query weak RLDC，则 C58 的指数下界或其参数化版本可被调用；若证明
任何近线性 dPCP 都不满足该 slice 条件，则得到一个可独立陈述的 alphabet/decoder
障碍。第一项未证明前，不把“非二元”写成障碍已被突破。

这里有一个可直接使用的基线传递（它不是 C58 的指数强化）。若 `e:Sigma -> {0,1}^ell`
 是固定 injective 编码，且一个 family-level Sim-CR code `C:{0,1}^k -> Sigma^N`
 具有正半径 `rho`、完美完备性和错误上界 `beta`，则块编码
 `C_bin(m)=e(C(m)_1)||...||e(C(m)_N)` 给出一个二元 weak adaptive
 `q*ell`-query RLDC，半径为 `rho/ell`，错误概率至多 `beta`。证明只需把每个二元
 块解析成一个 `Sigma` 符号；若某块非法则输出 `bottom`，否则至多有 `ell` 倍的符号
 Hamming 误差，正好落回原 Sim-CR 假设。这个传递不要求 projection。因而固定
 `|Sigma|`、常数 `q` 和正半径本身并不是近线性构造的逃逸；它只留下查询常数改变后的
 一般 RLDC/relaxed-LDC 下界。C58 的指数结论仍仅在 `q*ell=2` 的二元情形可直接调用。
对 growing alphabet，Singleton 与块编码还给出 (S10)--(S12) 的 locality/window/length
兼容式；因此真正需要 T1 的，是证明 alphabet 增长足以离开该参数区，或证明半径
退化、符号关系与 shared target binding 之间存在新的编码代价，而不是简单把 binary
换成固定非二元。

结合 C55，非二元逃逸还受到一个直接的容量条件约束。对无 key 的全消息族取
`h=k,s=0`，若 message-inline code 长度为 `N=k+P=k L(k)`，其中 `L(k)=polylog(k)`，且 C55 的 DGL
窗口成立，则

\[
  k^{\theta}
  \;\le\;
  O\!\left(|\Sigma|^{Q}\log|\Sigma|\,L(k)^{1-\theta}\log k\right),
  \qquad
  \theta=\frac{c_D}{Q^2\log^2(Q+2)}.
\]

因此固定 `Q` 时，`|Sigma|=polylog(k)` 不可能支持近线性 proof；更一般地，若
`|Sigma|=k^{a}`，则必须满足（忽略 polylog 因子）`aQ >= theta`。这不是新的 RLDC
下界，而是 C55 在 T1 参数上的可检验 corollary：alphabet 增长若想成为真正逃逸，
必须达到足以承载消息熵的尺度，或同时让 `Q`/半径离开 DGL 窗口。

### 14A. 通用 shared-synthesis 编译器的去重裁决

本轮对“任意目标集合上的 shared canonical-proof synthesis ⇒ RLDC”做了最小去重
检查。其抽象形式如下：若同一对象

\[
  D(m)=C(m)\,\|\,R(m)
\]

能在所有坐标和声明之间，用至多 \(r\) 次局部访问合成 proof symbol；且对应的
target-relative verifier 在 \(C(m)\) 的固定正半径内具有完备率
\(\alpha\) 与错误分支上界 \(\beta<\alpha\)，则把 codeword 与 shared object
拼入同一个 proof map 后，直接得到 locality

\[
  O\!\left((q_C+q_P r)(\alpha-\beta)^{-2}\right)
\]

的 relaxed local decoder。该推导不需要线性 half-space、systematic code 或某个
特定目标集合；它已经是主论文 Theorem 3.5（以及 statement
[radius-to-relaxed-LDC barrier](../../rw-jk-succinct-reconstruction/statements/radius-to-relaxed-ldc-barrier.md)）
的直接特例。C79 的 GKK half-space 版本只是在 soundness 半径和 synthesis locality
上给出一个具体实例化。

因此这里不再新增一个同义的“generic shared-synthesis theorem”作为独立贡献。该
抽象编译器本身不是新的顶级定理；真正可晋级的两条路是：

1. 构造一个此前不存在的 \(D,R,S\)，并同时满足 RW 地址尺度、singleton/coordinate-
   robust soundness 与全局 word consistency；或
2. 证明一个超出 Theorem 3.5 适用范围的一般下界，例如对 distributional/list
   soundness、index-aware strategy 或 hidden relation binding 给出不可绕过的编码代价。

若候选只重述上述编译而没有新的构造或更宽的 lower bound，本项目将其视为路线说明，
不再晋级为新 note 或新的 CLAIM 编号。

### T2：非 projection 的输入查询消除

以 C57 为基线，尝试在 `q=1` 的同一 global proof 上消除候选输出词的那一次输入查询，
同时保留固定坐标的 target-relative soundness。成功将给出近线性 singleton-output
2-query PCPP；失败则应证明一个明确的 query-elimination tradeoff（例如输入查询只能
通过增加 proof 长度、alphabet 或 soundness gap 消除）。`q=2` 不作为首选正向目标，除非
构造能严格超出已有 3-query PCPP 参数，而不是重新命名一个额外查询。

这里先排除一个容易漏掉的反例：若 proof alphabet 为二元，可以把候选输出词直接拼到
proof 前面，得到 `C(m)=m||Pi_m`。正式的 message-inline compiler 表明，这会把任意
binary、非 projection、`q=1` Sim-CR 送入 binary 2-query RLDC 的指数障碍；因此 T2 的
非 projection 研究不能停留在“多一个输入查询”的表面，而必须同时改变 alphabet、
radius、family-level 量词或 query 数。

对 `q=2`，同一编译器只给 3-query RLDC。当前公开结果在固定 alphabet、常数半径下有
近二次长度的 3-query RLDC 构造，而一般 relaxed-LDC 下界只给超线性尺度；因此不能把
C58 的指数障碍形式外推到 binary、非 projection、`q=2`，但也不能把它当作近线性逃逸：
固定 `q`、固定 alphabet、正半径的 family-level 构造仍被一般超线性下界排除。这个分支只有在额外证明
systematic/target-binding 结构能把 RLDC 提升为更强的 LDC，或证明 RW 的 proof family
不可能实现该结构时，才值得继续。

一个新的、参数化的升级已经封闭了其中的低 soundness 窗口：非自适应 ACRR 的两个
claim branch 可先给出 `2q`-query RLDC；若正确分支完美完备且错误概率满足
`beta < 1/(2^(2q)+2)`，近期 RLDC-to-LDC 定理把它升级为同查询数普通 LDC。这不是
一般常数-soundness barrier，但它明确说明“保留 bottom”只有在较高错误概率、adaptive
查询伴随非零 codeword 错误接受/不完美完备性，或其他量词逃逸下才可能继续发挥作用；
若 codeword 上错误分支零接受，adaptive perfect-completeness 特例也被关闭。正式推导见
[low-soundness ACRR implies LDC](../../rw-jk-succinct-reconstruction/statements/low-soundness-acrr-implies-ldc.md)。

非自适应子类又可向前推进一步。若 proof map `Pi:{0,1}^k->{0,1}^P` 任意（无需线性），
且每个 `V_{i,b}` 仅要求分支内非自适应、正确分支完美完备、错误分支在 target-relative
半径内接受至多 `beta`，则把 message bit inline 后预先查询两个分支的并集，得到
`Q<=2q+1` 的**非自适应 RLDC**。这不需要 projection、proof-map 线性或 codeword 上
错误分支零接受；[Goldberg--Gur--Saraogi Theorem 1](https://arxiv.org/html/2511.21659)
因此给出 `N=k^{1+Omega(1/q)}`（固定参数）。正式定理见
[nonadaptive message-inline ACRR barrier](../../rw-jk-succinct-reconstruction/statements/nonadaptive-message-inline-acrr-barrier.md)。
它仍不能外推为自适应或 codeword-only ACRR。

### T3：distributional soundness 的 singleton/global-word 分离

对 DHK/GM--W--Z 风格组合，要求同一个 global proof 和同一个 target word。若组合器只
给出 `forall i exists tau_i`，则必须构造满足原始 dPCP/udPCP 定义的 phantom-word
分离；若能给出 `exists tau forall i` 的固定策略，还必须补上 coordinate-robust outer
check。目标是二选一：

* 证明一个一般 separation，说明平均/list/distributional soundness 黑箱不能产生 ACRR；或
* 构造 singleton target-binding + coordinate-robust outer check，并把 proof/history
  通道压到 `poly(n,log T)`。

“存在一个局部答案”或“每个坐标分别有一个 Merlin 响应”不计入成功，因为它们不提供
JK 所需的整词一致性和 parent closure。

## 9A. 最终闭合定理：RW succinct smart reconstruction

本项目真正的终点不是再得到一个一般 ACRR 障碍，而是把实际
RW/JK canonical history 接回 forcing lower bound。为此，独立 note 204
把最后的条件写成了一个闭合定理：若同一个 \(H_{A,n}\) 同时具有
超多项式 forcing、\(n^{O(1)}\) 地址级同一-proof evaluator、bottom/cover-safe
word consistency、\(n^{O(1)}\) 的非隐藏 descriptor，以及 forcing 与
reconstruction 长度的无限交集，则

\[
P=NP\Longrightarrow H_A\in P/\mathrm{poly},
\]

与 \(\operatorname{CC}(H_{A,n})>n^{k(n)}\)、\(k(n)\to\infty\) 矛盾。
这不是把缺口改名成定理：它明确留下三个必须独立闭合的 gate。

* **Gate I（RW attachment）：** 从实际 \(A\)-dependent canonical history 生成
  同一 proof、同一 strategy、同一 address space 的逐位 smart evaluator；
* **Gate II（escape classification）：** 处理 bottom、cover sheet、target
  descriptor 和大 support，而不是只排除平均/list soundness；
* **Gate III（final collapse）：** 证明确定化、forcing object 和长度集合在同一
  参数子集上相交。只有在地址成本为 \(n^{O(1)}\) 时，\(P=NP\) 才会产生
  \(P/\mathrm{poly}\) 电路；\(\operatorname{poly}(q)\) 或 \(E^{NP}\) full-table
  搜索不够。

因此 C180 关闭的是 BMVY/DDL 源上的 arbitrary-right-label patch，而不是 Gate I；
C179 说明 cover sheet 不能被 ordinary DPT 黑箱消去，而 Closure Theorem 将
sheet binding 作为显式条件。下一阶段不再增加同类局部障碍，除非它能把
Gate I--III 中至少一个提升为一般 impossibility、PCP/coding 或 Range-Avoidance
定理。正式条件性定理见
[note 204](204-rw-succinct-smart-reconstruction-closure-theorem-2026-08-17.md)。

## 10. 第二阶段的停止与晋级规则

从本节起，新增工作只有在一个月内能改变以下至少一个判断时才进入主线：

1. 给出 T1/T2/T3 之一的完整定理、反例或参数化不可能性；
2. 把现有 C55/C57/C58 提升为覆盖明确 escape class 的一般下界；
3. 给出可独立投稿的新 PCP/coding、circuit/Range-Avoidance 或一般 impossibility theorem。

以下情况直接停止该候选，不再增加局部 note：

* 只有 average/list/unique decoding，没有固定坐标的 target-relative 常数 gap；
* 不同坐标切换 proof、strategy、prefix 或 preimage；
* 需要物化 `q`-bit seed、完整 history，或把它们藏进 nonuniform advice；
* 只得到 `E^NP`/全表尺度的 outsider，却把它表述为 `poly(n,log T)` 地址尺度；
* 只因为 C58 未覆盖该模型，就把非二元或非 projection 当作正向证据；
* 证明只使用论文中的平均 soundness 术语，却没有逐条对照目标相对量词。

这一阶段的交付物不是第 169 个局部障碍，而是 T1/T2/T3 中一个可独立核验的 theorem
module；否则内容回到搜索轨迹，不改变项目主线。

## 11. Shrinking-error corridor 与下一项主定理（2026-08-19）

在 C489--C492 之后，继续改变 JK success package、generator row 或 selector 的包装已不再
改变 Gate I 的判断：一旦 row/seed map 由共同且完整计价的地址级电路给出，它本身就是
parent evaluator；若只逐点存在，则 message-scale table 仍未消失。因此主攻回到 T3，
并把两个容易混淆的参数分开记为

\[
 \varepsilon_{\rm dec}:=\text{dPCP/list-decoding error},
 \qquad
 \eta_{\rm prox}:=\text{PCPP/RLDC proximity radius}.
\]

本阶段的精确窗口是

\[
 \boxed{
 \varepsilon_{\rm dec}=\Theta(N^{-1}),\qquad
 P=N^{1+o(1)},\qquad
 q,\log|\Sigma|=\operatorname{polylog}N .
 }
 \tag{11.1}
\]

### 11.1 当前文献给出的严格裁决

检索与全文核对截至 2026-08-19。Gur--Minzer--Weissenberg--Zheng 的
Theorems 1.6、3.12、10.2 具有量词

\[
 \forall\varepsilon>0\ \exists C(\varepsilon),L(\varepsilon):
 \qquad
 P=N\log^{C(\varepsilon)}N,\qquad
 L=\operatorname{poly}(1/\varepsilon),\qquad
 |\Sigma|=O_\varepsilon(1).
 \tag{11.2}
\]

这只对固定 \(\varepsilon\) 给出 quasi-linear 保证。其 Section 10 的一次
right-regularization 取 \(d'=O(\varepsilon^{-100})\)，并把离散分母从
\(J=O(N\operatorname{poly}_\varepsilon(\log N))\) 变为 \(d'J\)。把
\(\varepsilon=N^{-1}\) 代入其已证明的参数记账，只得到

\[
 P\le O\!\left(N^{101}\operatorname{poly}_{1/N}(\log N)\right),
 \tag{11.3}
\]

而不是 (11.1)。式 (11.3) 说明**现有证明不提供** shrinking-error uniformity；它不是
对同一构造真实最小长度的下界，也不是一般 dPCP 不可能性。Theorem 11.1 的
dPCP-to-PCPP 变换还只有

\[
 s\le \varepsilon+L(1-\eta_{\rm prox}),
 \qquad
 \eta_{\rm prox}\ge1-\varepsilon^{C+1},
 \tag{11.4}
\]

并不产生固定坐标的 indexed/global target binding。

反向文献也没有关闭 (11.1)。Goldberg--Gur--Saraogi 的非自适应 RLDC 下界需要

\[
 \delta>n^{-\sigma/(2q)},
 \qquad
 n\ge
 \left(
 \frac{\sigma^2k}{38q^4\log^2|\Sigma|\log^2k}
 \right)^{1+1/\lceil q/\sigma\rceil};
 \tag{11.5}
\]

当 \(q=\operatorname{polylog}k\) 时，其指数仍与 \(k^{1+o(1)}\) 相容。
Cheng--Li--Mao 的二次 PCPP 下界则要求三查询、常数 proximity、固定 alphabet、
特定低 soundness，并要求 \(X,A,B\) 三个查询边际分别均匀。故它不能外推到一般
shared/indexed proof 或 shrinking-radius 窗口。

因此当前裁决是严格的三分：

\[
 \boxed{
 \text{GMWZ 已证明参数不够}
 \ \land\
 \text{GGS/CLM 现有下界不排除}
 \ \land\
 \text{窗口 (11.1) 仍开放}.}
 \tag{11.6}
\]

### 11.2 唯一正向接口

[Address-Scale Barriers for Shared-Proof Coordinate Robustness](../../rw-jk-succinct-reconstruction/papers/Address-Scale-Barriers-for-Shared-Proof-Coordinate-Robustness/paper.md)
的 Theorems 3.8、3.9、3.9A 已把后半段编译器完成。若一个 common-address
indexed-global dPCP 的 proof length 为 \(P_0\)、局部查询数为 \(q\)、list size 为
\(L\)，并接入一个 \(q_D\)-query、\(\lambda\)-smooth outer decoder，则 selector
编译后

\[
 P'\le2P_0+k,
 \qquad
 q'=q_Dq+2,
 \tag{11.7}
\]

\[
 \log|\Sigma'|
 =\max\{\log|\Sigma|,\log L,\log|\Gamma|\}+O(1),
 \tag{11.8}
\]

\[
 \operatorname{err}
 \le \beta_C+q_D\lambda\varepsilon_{\rm dec}+2\rho',
 \qquad
 \alpha_C>\beta_C+q_D\lambda\varepsilon_{\rm dec}+2\rho'.
 \tag{11.9}
\]

其中 indexed-label 的信息税只有

\[
 q\log|\Sigma|\ge\log L+\log\alpha.
 \tag{11.10}
\]

所以 \(L=\operatorname{poly}(k)\) 与 polylog locality/alphabet 仍可兼容。真正未证明且
不得再拆散的 source lemma 是

\[
 \boxed{
 \text{RW/JK relation}
 \Longrightarrow
 \text{stable index}
 +\text{one global word}
 +\text{uniform address generator}
 +\text{fully charged control}.}
 \tag{11.11}
\]

### 11.3 攻坚顺序与停止条件

```mermaid
flowchart LR
  U["理解：固定 (11.1) 与量词"] --> P["计划：正向 source lemma / 反向 counterfamily"]
  P --> A["执行 A：构造 (11.11)"]
  P --> B["执行 B：同地址、无稳定 index 的反例或代价"]
  A --> J{"参数与量词同时闭合？"}
  B --> J
  J -->|是| T["晋级：uniform indexed-global relation-dPCP ⇒ ACRR"]
  J -->|否且有一般代价| N["晋级：shrinking-error / index-binding no-go"]
  J -->|原文参数未定| R["回顾：冻结 unresolved corridor，改攻新构造"]
```

执行 A 只有在同一个 proof、同一个地址空间和同一个全局 indexed list 上完成 (11.11)
才算成功；逐坐标 proof、未标号 list、target-dependent ROM 或未计价 strategy 立即停止。
执行 B 只有在覆盖 polylog query/alphabet 或证明显式 source obstruction 时才晋级；重复
constant-radius RLDC barrier 不算新结果。后续新增工作必须直接改变 A、B 或 (11.6) 中
至少一个判断。

### 11.4 Actual-source 裁决与优先级修正（2026-08-19）

对 RW Theorems 3.5、4.1--4.3 的逐式核对表明，(11.11) 不能作为一个未分层的
“唯一缺口”。实际 source 同时表现出三个不同结论。

**Canonical singleton 已经是 global。** 在 Theorem 4.1 的 failure 分支中，同一个
canonical proof \(\Pi_x\) 与同一个 lexicographically maximal prefix \(pfx_x\) 服务所有
输出坐标，并且

\[
 \exists\Pi_x\ \exists pfx_x\ \forall i:
 \qquad
 \operatorname{Reconf}(x,i)=f(x)_i .
 \tag{11.12}
\]

所以不能把 actual source 的缺口表述成“每个坐标选择不同 canonical word”。

**一般 sound-proof family 没有稳定 global labels。** 这个断裂可在 RW 自己的
computational-history relation 内实现。令 \(M_h\) 作 \(h\) 个 adaptive rounds，每轮只作一个
YES NP query，其中 \(0^s\) 是合法 witness 而 \(1^s\) 不是；机器把各轮答案串
\(a\in\{0,1\}^h\) 原样输出。对 \(a_j=1\) 填入 \(0^s\)，对 \(a_j=0\) 填入 sentinel
\(1^s\)。Lemma 3.2 的 history check 只按 witness 是否满足 query 决定模拟答案，不证明
一个被填入不合法 witness 的 YES query 为 NO；故存在

\[
 \{w_a:a\in\{0,1\}^h\},
 \qquad
 f_{\rm pfx}(w_a)=a,
 \qquad
 f_{\rm out}(w_a)=a .
 \tag{11.13}
\]

lexicographically maximal history 是 \(w_{1^h}\)。Theorem 3.4 为每个 \(w_a\)
给出 perfect-accepting proof，而 Theorem 3.5 只在 prefix 等于 \(1^h\) 时强制
canonical output。因此 perfect-accepting outputs 覆盖

\[
 \{0,1\}^h,
 \tag{11.14}
\]

尽管每个输出坐标的符号集合只有 \(\{0,1\}\)。任何覆盖这些 source-valid candidates
的 global output list 都需 \(2^h\) 个词；逐坐标给两个符号不能产生同一 two-slot
global labeling。这是主论文 Lemma 2.10 的 coordinatewise-mixing separation 在
actual RW relation 中的 source instantiation。它关闭的是

\[
 \text{RW sound proofs}
 \not\Rightarrow
 \text{list-size-preserving indexed global list},
 \tag{11.15}
\]

而不否定 (11.12) 的 canonical singleton。

**最终 \(P=NP\) 分支首先受尺度而非 label 阻挡。** 对最终反证，可以先把固定
SAT-oracle machine 重编译成确定性 machine。此时 \(r=s=0\)、\(pfx=\epsilon\)，
C416/C456 又把同一 published hard output \(B_n\) 对齐到每个 satisfying history；
max-prefix label 因而不再是第一障碍。可是令

\[
 b=|B_n|,\qquad m=\lceil\log_2(b+1)\rceil ,
 \tag{11.16}
\]

则 C456 的 deterministic relation circuit、exposed witness 和普通 PCP/dPCP 仍在
\(b^{O(1)}=2^{O(m)}\) 尺度。即使一个理想 uniform theorem 给出

\[
 P=N_{\rm rel}^{1+o(1)},
 \tag{11.17}
\]

它也只改善 proof **length**；它不提供一个 \(m^{O(1)}\)-size circuit 来随机访问同一
honest proof，更不使 succinct-CSP satisfiability 落入 \(P=NP\) 所能确定化的
polynomial hierarchy。故 (11.1) 是有价值的 PCP frontier，但不是当前 RW Closure 的
第一承重门。

实际下一项主定理必须直接构造或排除以下 **non-systematic address-scale relation
proof**。对同一 hard word \(B_n\)，寻找一个共同 circuit witness \(C_n^\star\) 和
verifiers \(\mathcal V_{n,j,b}\)，满足

\[
 |C_n^\star|+
 |\mathcal V_n|+
 |\text{all address/control logic}|
 =m^{O(1)},
 \tag{11.18}
\]

\[
 \Pr[\mathcal V_{n,j,B_n[j]}(C_n^\star)=1]=1
 \qquad(\forall j),
 \tag{11.19}
\]

\[
 \sup_C
 \Pr[\mathcal V_{n,j,1-B_n[j]}(C)=1]\le\beta<1/2
 \qquad(\forall j).
 \tag{11.20}
\]

这里 \(C_n^\star\) 不能只是计算 systematic \(B_n\)-cells 的短 circuit，否则 C482/C486
立即触发 forcing；它必须由 JK success structure、Harsha auxiliary algebra 或新的
non-product global relation 完成 claim verification。若 (11.18)--(11.20) 成立，
\(P=NP\) 将 smart perfect-complete prMA claims 确定化为 \(m^{O(1)}\)-size
address evaluator，与 C455 的 forcing lower bound 矛盾。若能证明所有这类
non-systematic verifier 都编译回 exact target access，则得到相应的一般
impossibility theorem。

从现在起，只有两条工作会改变主决策：

\[
 \boxed{
 \begin{array}{ll}
 (+)&\text{从 actual JK/Harsha success relation 构造 (11.18)--(11.20);}\\
 (-)&\text{证明任意满足 (11.19)--(11.20) 的 source verifier 支付 forcing scale.}
 \end{array}}
 \tag{11.21}
\]

只改进 ordinary proof length、固定-\(\varepsilon\) PCP 参数或无标号 list，不再作为
RW Closure 的下一脉冲；除非它同时给出 (11.18) 的 locally computable common proof。
