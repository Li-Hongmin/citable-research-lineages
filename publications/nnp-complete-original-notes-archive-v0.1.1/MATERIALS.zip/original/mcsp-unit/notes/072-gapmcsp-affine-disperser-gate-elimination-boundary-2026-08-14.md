> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# GapMCSP 的 affine-disperser 反例与 gate-elimination 边界（2026-08-14）

## 结论

令 \(N=2^n\)，并记

\[
H_t=\{x\in\{0,1\}^N:\operatorname{CC}_n(x)\le t(n)\}.
\tag{1}
\]

对固定有限 fan-in-two basis，存在绝对常数 \(A\)，使

\[
|H_t|\le 2^\ell,
\qquad
\ell=\left\lceil A\,t(n)\log_2(t(n)+n+2)\right\rceil.
\tag{2}
\]

只要 \(1\le\ell\le N-1\)，就存在与 \(H_t\) 不交、维数至少 \(N-\ell\) 的 affine
subspace。对 [note 070](070-ops-candidate-formula-oracle-refuter-2026-08-14.md) 的参数

\[
t(n)=\left\lfloor\frac{2^{\alpha n/2}}{Kn}\right\rfloor,
\qquad 0<\alpha<2,
\tag{3}
\]

有 \(\ell=o(N)\)。因此充分大 \(N\) 上，存在维数大于 \(3N/4\) 的 affine subspace
\(S\) 满足

\[
S\subseteq\{x:\operatorname{CC}_n(x)>t(n)\}.
\tag{4}
\]

所以 \(\operatorname{GapMCSP}[s,t]\) 在每个 \(d\le3N/4\) 上都不是
dimension-\(d\) affine disperser；这对任何与 promise 一致的 total extension 也成立。

Carmosino--Dang--Jackman（CDJ）Theorem 5/14 的 affine refuter 只覆盖 size 严格小于

\[
3N-4d
\tag{5}
\]

的 \(B_2\)-circuits。式 (5) 为正只可能在 \(d<3N/4\)，而 GapMCSP 在这些维数上已经
不是 affine disperser；\(d\ge3N/4\) 时 (5) 为零或负，严格 size bound 为空。故 CDJ 的
affine-disperser corollary 不能直接用于
[note 071](071-unary-oracle-composition-and-transfer-boundary-2026-08-14.md)。

直接运行 CDJ Algorithm 2 仍有一个严格的一侧信息。在端点 \(\alpha=1\) 上，任意 leaf-size
至多 \(N\) 的 \(U_2\)-formula 作为 \(B_2\)-circuit 都可得到维数
\(\Omega(N)\) 的常值 affine subspace。若常值为 \(1\)，随机点几乎必为
GapMCSP-NO，因而给出反例；若常值为 \(0\)，同样的随机高点却与 NO 标签一致。
下文给出一个合法 \(U_2\)-formula，使 Algorithm 2 的实际输出为常值 \(0\)、且整个输出
subspace 都不含 YES truth table。因此 CDJ 输出不能自动后处理为所需 easy--hard pair。

这个结论关闭的是 affine-disperser corollary 与“常值 subspace 自动给反例”的直接实例化，
不排除加入新的 promise-specific 论证。\(1<\alpha<2\) 时，
[note 071](071-unary-oracle-composition-and-transfer-boundary-2026-08-14.md) 已用原公式的大量
未读坐标给出更强的 BPP refuter；\(\alpha<1\) 时最坏候选 size 本来也超过 CDJ 的线性阈值。

## 稀疏集的 affine 避开引理

**引理。** 设 \(H\subseteq\mathbb F_2^N\)、\(1\le\ell\le N-1\)，且
\(|H|\le2^\ell\)。则存在维数 \(N-\ell\) 的 affine subspace \(S\) 使
\(S\cap H=\varnothing\)。

若 \(|H|<2^\ell\)，任取满秩线性映射

\[
L:\mathbb F_2^N\longrightarrow\mathbb F_2^\ell.
\]

此时 \(|L(H)|<2^\ell\)，故存在 \(y\notin L(H)\)；fiber
\(L^{-1}(y)\) 即为所需的 \(N-\ell\) 维 affine subspace。

若 \(|H|=2^\ell\)，取不同的 \(h_1,h_2\in H\)。因为 \(\ell\le N-1\)，可选满秩
\(L\) 使非零向量 \(h_1-h_2\) 位于 \(\ker L\)。于是
\(L(h_1)=L(h_2)\)，从而仍有

\[
|L(H)|<2^\ell.
\]

再取一个未命中的 fiber 即得结论。较直接但弱一维的证明，是使用 rank-\((\ell+1)\)
映射；因此 \(N-\ell-1\) 是安全边界，但不是这里的最强边界。

## 对低 circuit-complexity truth tables 的应用

令 \(q=\lfloor t(n)\rfloor\)，basis 中 binary gate types 的数目为 \(b\)。size 至多
\(q\) 的 circuit descriptions 数可粗略上界为

\[
(q+1)(n+q+2)\bigl[b(n+q+2)^2\bigr]^q
\le 2^{Aq\log_2(q+n+2)}
\tag{6}
\]

；不同 descriptions 计算同一函数只会减少 truth tables 数目，所以 (2) 成立。

由 (3)，

\[
\ell
=O\!\left(t(n)\log(t(n)+n)\right)
=O(N^{\alpha/2})
=o(N).
\tag{7}
\]

充分大 \(N\) 上可取 \(\ell<N/4\)。稀疏集引理给出维数
\(N-\ell>3N/4\) 的 \(S\) 避开 \(H_t\)，于是 (4) 成立。若
\(d\le3N/4\)，在 \(S\) 内取任意 \(d\)-维 affine subspace，仍全部位于
GapMCSP 的 NO 端。

CDJ 只对 total Boolean functions 定义 affine disperser，但这里没有 partial-function 的
定义歧义：\(S\) 完全位于 promise domain 的 NO 端。因此它同时否定：

1. 要求每个大 affine subspace 同时遇到 YES 与 NO 的 promise 版本；
2. 只检查完全落在 promise domain 内子空间的版本；
3. 任意与 GapMCSP promise labels 一致的 total extension。

## 为什么直接的 sensitivity 标签也不迁移

CDJ 对 MUX/XOR 的直接 gate-elimination refuter 在发现变量依赖性被破坏时，可以利用目标函数
已知的敏感标签输出反例。GapMCSP 没有同一性质。对每个坐标 \(i\)，充分大 \(n\) 上都有

\[
\operatorname{CC}(0^N),\operatorname{CC}(e_i)\le s(n),
\qquad
\operatorname{GapMCSP}(0^N)=\operatorname{GapMCSP}(e_i)=1.
\tag{8}
\]

所以候选不读变量 \(i\) 并不产生一对标签不同的 GapMCSP 输入；常数一候选甚至与 (8) 的
两点都一致。这说明“发现候选违反目标 sensitivity 后立即输出反例”在第一步就没有可直接迁移的
标签。它与 affine no-go 一起排除了把现有 CDJ 算法仅作接口重命名的方案，但不是对所有未来
gate-elimination 技术的不可能性定理。

## \(\alpha=1\)：CDJ 输出只给常值 \(1\) 一侧

在端点 \(\alpha=1\)，给定 leaf-size 至多 \(N\) 的 \(U_2\)-formula \(F\)。把它看作
\(B_2\)-circuit，则 binary-gate 数 \(\sigma(F)\le N-1\)，所读变量数
\(\eta(F)\le N\)，所以 CDJ 的 measure 满足

\[
\mu(F)=\sigma(F)+\eta(F)\le2N-1.
\tag{9}
\]

在 Algorithm 2 中取 \(d=N/2-1\)（取整不影响结论）。由

\[
\mu(F)<4(N-d)
\]

可在 polynomial-\(N\) 时间得到维数
\(\delta\ge d=\Omega(N)\) 的 affine subspace \(S\)，且 \(F|_S=c\) 为常数。式 (2)
给出

\[
\Pr_{z\sim S}[\operatorname{CC}_n(z)\le t(n)]
\le\frac{|H_t|}{|S|}
\le2^{\ell-\delta}
=2^{-\Omega(N)},
\tag{10}
\]

因为此时 \(\ell=O(\sqrt N)\)。

若 \(c=1\)，直接输出均匀 \(z\in S\) 是 bounded-error 反例；加最终一次
\([\operatorname{CC}(z)\le t]\in NP\) 查询并在 YES 时重采，可得到每个成功输出都严格正确的
零错误版本。若 \(c=0\)，同样的随机高点满足候选值与 NO label 都为 \(0\)，不产生反例。
CDJ 输出的 affine basis 与 base point 只有 polynomial-\(N\) 显式性，并不保证 base point
作为 \(n=\log N\) 地址函数具有 size-\(s(n)\) circuit。

## 合法 \(U_2\)-formula 的坏 \(0\) 分支

上述 \(c=0\) 不是可以靠“CDJ base point 应当很简单”排除的偶然分支。令

\[
H_s=\{x:\operatorname{CC}_n(x)\le s(n)\},\qquad
\ell_s=\left\lceil A\,s(n)\log_2(s(n)+n+2)\right\rceil,\qquad
r=\ell_s+1.
\tag{11}
\]

任选 \(r\) 个坐标 \(X=\{a_1,\ldots,a_r\}\)。由

\[
|\operatorname{proj}_X(H_s)|\le |H_s|\le2^{\ell_s}<2^r
\]

可取 \(b\in\{0,1\}^r\setminus\operatorname{proj}_X(H_s)\)。定义 literal

\[
\lambda_i=
\begin{cases}
x_{a_i},&b_i=0,\\
\neg x_{a_i},&b_i=1,
\end{cases}
\qquad
\lambda_i=0\Longleftrightarrow x_{a_i}=b_i.
\tag{12}
\]

再取彼此不同且不在 \(X\) 中的 \(u_i,v_i,q,q'\)，并令

\[
F_b(x)=
(\neg x_q\wedge\neg x_{q'})
\ \vee\
\bigvee_{i=1}^r
\left[
(\lambda_i\wedge x_{u_i})
\vee
(\lambda_i\wedge x_{v_i})
\right].
\tag{13}
\]

这是 leaf-size \(4r+2=\operatorname{poly}(n)\) 的 \(U_2\)-formula；因此对任意固定
\(0<\alpha<2\)，充分大 \(n\) 时都有 \(4r+2\le N^{2-\alpha}\)。而且
\(F_b(0^N)=1\)。

运行 CDJ Algorithm 2。每个 \(x_{a_i}\) 经两份 \(\lambda_i\) 具有 fanout \(2\)，而
\(u_i,v_i\) 各只有 fanout \(1\)。因此算法处理任一个对应的底层 AND gate 时，都选择
\(x_{a_i}\) 并固定

\[
x_{a_i}=b_i,
\]

从而同时消掉第 \(i\) 个双项。处理辅助 AND gate 时固定 \(q=1\) 或 \(q'=1\)。
最终整个 OR 变为常数 \(0\)，实际输出一个

\[
S\subseteq\{x:x_X=b\},
\qquad
\dim S\ge N-r-1,
\qquad
F_b|_S=0.
\tag{14}
\]

由 \(b\notin\operatorname{proj}_X(H_s)\)，有

\[
S\cap H_s=\varnothing.
\tag{15}
\]

所以 CDJ 输出的每个点都不是 YES truth table；其 base point 也不可能提供 low witness。
这个例子严格关闭“任意 CDJ 常值 subspace 自动含有所需同值 easy--hard pair”的后处理，
但不否定利用 \(F_b\) 其他结构的算法。事实上 \(F_b\) 只读
\(\operatorname{poly}(n)=o(N)\) 个坐标，note 071 的语法-support 方法仍能 refute 它。

## 来源

- Marco Carmosino, Ngu Dang, and Tim Jackman, *Constructive Separations from Gate
  Elimination*, arXiv:2604.23958v1 (2026), Definitions 2, 4, 11，Theorem 5/14 与
  Corollary 6；全文：
  `ResearchLibrary/lib/jackman2026constructive/jackman2026constructive.pdf`。
- [note 070](070-ops-candidate-formula-oracle-refuter-2026-08-14.md)：OPS 参数和 GapMCSP
  promise labels。
- [note 071](071-unary-oracle-composition-and-transfer-boundary-2026-08-14.md)：当前
  分参数的 \(\mathrm{BPP}/\mathrm{BPP}^{NP}_{tt}/\mathrm{SearchZPP}^{NP}\) refuter。
