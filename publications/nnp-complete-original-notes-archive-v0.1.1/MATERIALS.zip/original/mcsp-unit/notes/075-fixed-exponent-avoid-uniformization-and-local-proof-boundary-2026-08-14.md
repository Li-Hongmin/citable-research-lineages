> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定指数 AVOID、量词统一与局部证据边界（2026-08-14）

## 结论

令 \(N=2^n\)，并令

\[
\mathsf{Easy}_{n,t}
=\{y\in\{0,1\}^N:\operatorname{CC}_n(y)\le t(n)\}.
\]

[note 074](074-p-equals-np-avoid-fp-low-depth-boundary-2026-08-14.md) 证明
\(P=NP\) 只把显式 AVOID 降到 \(FP\)，没有自动给出 CJSW 所需的低深度 generator。本 note
确定这个缺口的固定指数边界。

对每个固定 \(k\ge1\)，有

\[
P=NP
\Longrightarrow
\exists R_k\in
\text{polylogtime-uniform }AC^0[O(N)]
\quad
\forall^{\infty}n,\quad
\operatorname{CC}_n(R_k(1^N))>n^k.
\tag{1}
\]

所以固定 polynomial threshold 的低深度 hard-table generator 在 \(P=NP\) 下确实存在。
CJSW 的 super-quasipolynomial threshold 不能由 (1) 对 \(k\) 作 diagonalization 得到；精确量词差是

\[
\forall k\;\exists R_k
\qquad\not\Rightarrow\qquad
\exists R\;\forall k.
\tag{2}
\]

在 \(P=NP\) 假设下，右式反而被 CJSW Lemma 2.5 排除。任何完成 (2) 的结构性统一都已越过
\(P\) versus \(NP\) 门槛，而不是确定化之后的例行编译。

三个历史模板也在同一参数处关闭：

1. full-DNF 可把 polynomial-description decoder 编译为 uniform depth two，但 description
   一旦 super-polynomial in \(n\)，尺寸越过 qpoly\((N)\)；
2. Cook--Levin／标准 witness-enriched／当前 rectangular-PCP 模板没有给出长度
   \(<N-L\) 的共享整表证据；输出 proof tail 不能靠 padding 修复；
3. CJSW Parity 的短串 padding list 全部仍有 \(\operatorname{poly}(n)\) circuit complexity，
   因而在 super-quasipolynomial MCSP threshold 下全是 YES instances。

未关闭的是一种新的、非黑箱的 uniformization／circuit-complexity amplification；本文不声称此类
方法不存在。

## 固定指数条件构造

固定 \(k\)。取一个 uniform truth-table decoder

\[
\Phi_{n,k}:\{0,1\}^{L}\longrightarrow\{0,1\}^{N},
\qquad
L=O(n^k\log(n^k+n))=n^{O_k(1)},
\tag{3}
\]

其 range 包含 \(\mathsf{Easy}_{n,n^k}\)，并把非法 circuit descriptions 映到固定默认表。
令 \(r=L+1<N\)，且对 \(z\in\{0,1\}^r\) 定义

\[
Y_z:=0^{N-r}z.
\tag{4}
\]

候选 \(Y_z\) 有 \(2^{L+1}\) 个，而 \(|\operatorname{Range}(\Phi_{n,k})|\le2^L\)，故至少一个
\(Y_z\) 位于 range 外。令 \(z_{n,k}\) 为 lexicographically first 这样的 \(z\)。给定
prefix \(u\preceq z\)，定义

\[
\begin{aligned}
\mathsf{Ext}_{k}(1^n,u)
\iff{}&\exists v\in\{0,1\}^{r-|u|}
\;\forall D\in\{0,1\}^{L}
\;\exists x\in\{0,1\}^{n}\\
&\operatorname{Eval}(D,x)\ne Y_{uv}[x].
\end{aligned}
\tag{5}
\]

因 \(k\) 固定，所有量词长度及 \(\operatorname{Eval}\) 时间均为 \(\operatorname{poly}(n)\)，所以
\(\mathsf{Ext}_k\in\Sigma_3^P\)。若 \(P=NP\)，则 \(PH=P\)；对 (5) 逐位自归约，可在
\(\operatorname{poly}(n)\) 时间求出 \(z_{n,k}\)。

定义 \(R_k(1^N)=Y_{z_{n,k}}\)。其输出电路只有 \(N\) 个常数 output gates；uniformity machine
在给定 output index 后，以 \(\operatorname{poly}(n)=\operatorname{polylog}(N)\) 时间计算对应的
\(z_{n,k}\) bit。因此 \(R_k\) 是 polylogtime-uniform、linear-size、constant-depth family。
又因 \(R_k(1^N)\notin\operatorname{Range}(\Phi_{n,k})\)，其 circuit complexity 严格大于
\(n^k\)。这证明 (1)。

同一证明适用于任意满足 decoder description length \(L(n)=n^{O(1)}\) 的固定 threshold family。

## full-DNF decoder 的正面边界

对每个 output address \(x\in\{0,1\}^n\)，函数

\[
D\longmapsto\operatorname{Eval}(D,x)
\]

是 \(L\)-bit Boolean function，故可写成至多 \(2^L\) 个 minterms 的 DNF。把全部 \(N\) 个
coordinates 并排，得到 depth-two decoder，尺寸

\[
O(NL2^L).
\tag{6}
\]

uniformity algorithm 只需解码 \((x,D)\) 并在 \(\operatorname{poly}(t,n)\) 时间计算
\(\operatorname{Eval}(D,x)\)。所以

\[
L=n^{O(1)}
\Longrightarrow
\Phi_{n,t}\in
\text{polylogtime-uniform }AC^0[\mathrm{qpoly}(N)].
\tag{7}
\]

但 CJSW 取

\[
t(n)\ge2^{(\log n)^{\omega(1)}}
\tag{8}
\]

并处在有 hard NO instances 的 \(t=o(N/n)\) 范围，以压过任意固定 uniformity exponent。
此时 \(L=\Theta(t\log(t+n))\) 对 \(n\) 为
super-polynomial，式 (6) 的 \(2^L\) 不再是 qpoly\((N)=2^{n^{O(1)}}\)。因此同一个
full-DNF 技巧不能同时满足 (7) 与 CJSW 的 domination quantifier。

## 任意 covering decoder 的输入长度下界

这个量词障碍不只是标准 circuit encoding 的冗余。在 \(t=o(N/n)\) 范围内，取最大整数
\(q\le n\) 使

\[
Cq2^q\le t
\]

（\(C\) 为固定 basis 的常数）。每个 \(q\)-input Boolean function 都有 size 至多
\(Cq2^q\) 的 DNF；忽略其余 \(n-q\) 个输入，可得 \(\mathsf{Easy}_{n,t}\) 中
\(2^{2^q}\) 张不同 truth tables。因此

\[
\log_2|\mathsf{Easy}_{n,t}|
\ge2^q
=\Omega\!\left(\frac{t}{\log t}\right).
\tag{9}
\]

若任意 map \(F:\{0,1\}^a\to\{0,1\}^N\) 满足
\(\mathsf{Easy}_{n,t}\subseteq\operatorname{Range}(F)\)，则

\[
a\ge\log_2|\mathsf{Easy}_{n,t}|
=\Omega\!\left(\frac{t}{\log t}\right).
\tag{10}
\]

所以在 (8) 下，任何 covering decoder 的 input length 都是 super-polynomial in \(n\)。
对其输入作存在／全称搜索不是 \(PH\) 关于 compact parameter \(n\) 的短量词。换编码不能把
\(P=NP\) 的 polynomial-scale collapse 自动抬升到这里。

## 为什么 proof-tail padding 不增加有效 stretch

设

\[
G:\{0,1\}^a\longrightarrow\{0,1\}^{N+K}
\]

并把前 \(N\) bits 解释为 truth table。要保证每个 range outsider 的前 \(N\) bits 都是 hard，
充要条件是

\[
\mathsf{Easy}_{n,t}\times\{0,1\}^K
\subseteq\operatorname{Range}(G).
\tag{11}
\]

必要性由 contrapositive 立即得到；充分性同样直接。因而

\[
a\ge\log_2|\mathsf{Easy}_{n,t}|+K.
\tag{12}
\]

若 construction 输入由 circuit description \(D\)、proof \(w\) 和为饱和全部 proof tails 而加入的
自由 \(K\) bits 构成，则

\[
a=L+|w|+K,\qquad
N+K-a=N-L-|w|.
\tag{13}
\]

output padding 完全抵消；扩张仍要求 \(|w|<N-L\)。只为每个 easy table 提供一个合法 proof
tail 不够，因为其余 tails 会成为带 easy prefix 的 range outsiders。

对直接输出 \(N\) bits 的 decoder，无效 witness 映到 easy table 本身并非问题；真正需要的是一个
跨全部 \(N\) addresses 共享、总长 \(<N-L\)、且能在目标弱模型中恢复整表的证据。逐地址
Cook--Levin traces 或全表 tableau 使用 \(\Theta(Nt)\) 量级的显式历史；RSW 明确把
rectangular PCP 用作 \(FP^{NP}\) circuit-analysis framework 的组件，其所述结果不是上述共享
decoder theorem。这关闭的是这些标准模板，不是所有可能的 succinct proof systems。

## Parity padding 与低深度 AVOID hitting set 的碰撞

CJSW Proposition 4.7 的 Parity list-refuter 枚举长度 \(\operatorname{poly}(n)\) 的短串并以零补到
\(N=2^n\) bits。每张所得 truth table 都可由 \(\operatorname{poly}(n)\)-size circuit 计算；在
(8) 的 MCSP threshold 下它们全属于 \(\mathsf{Easy}_{n,t}\)，所以不能 refute constant one。
任何 padding、repetition、projection 或 fixed-code embedding，只要对每个短串都保留
\(\operatorname{poly}(n)\) 的 circuit upper bound，就有同一失败。

GLW Theorems 5--6 的 oblivious AVOID hitting sets 也揭示相同冲突。标准 pairwise-independent
support 可取全部 affine truth tables

\[
h_{a,b}(x)=a\cdot x\oplus b,
\]

其中每张表只有 \(O(n)\) circuit complexity。若一个 decoder range 覆盖
\(\mathsf{Easy}_{n,t}\)（\(t\ge O(n)\)），它必覆盖整个 affine support；从每张表任选一个 preimage，
即可在 decoder inputs 上放置一个 distribution，使 outputs 精确 pairwise independent。
因此 GLW 用来证明“该 support 中必有 range outsider”的 simplicity/stretch hypotheses，不可能同时
适用于这个 easy-covering decoder。GGNS 的 fixed-locality algorithm 覆盖略宽的 stretch regime；
在与 GLW 重叠的参数内有上述严格冲突，重叠外不能仅凭本论证排除新的 decoder。

这不排除一个新的 transformation \(A\) 将短串 \(y\) 映为 \(A(y)\)，并从 Parity obstruction
强制某个 \(A(y)\) 具有 super-polynomial general circuit complexity；但这种
circuit-complexity amplifier 本身就是缺失的突破性接口。

## 回顾：现在真正剩下的最小命题

固定指数已经有 (1)，历史 padding 与 witness 模板已由 (10)--(13) 定位。剩余问题不是普通的
determinization，而是确定下列量词交换是否能利用 nested decoder structure 实现：

\[
\left[
\forall k\ \exists R_k:\operatorname{CC}(R_{k,n})>n^k
\right]
\stackrel{?}{\Longrightarrow}
\left[
\exists R\ \forall k:\operatorname{CC}(R_n)>n^k
\right],
\tag{14}
\]

同时保持一个固定的 polylogtime-uniform \(AC^0[\mathrm{qpoly}]\) family。CJSW Lemma 2.5 表明：
若 (14) 对本文 \(R_k\) 成立，则 \(P=NP\) 假设自身产生矛盾。因此 (14) 是一个等价于突破、但比
“把 FP 编译到 AC0”更精确的攻击接口。

## 来源

- Lijie Chen, Ce Jin, Rahul Santhanam, Ryan Williams,
  *Constructive Separations and Their Consequences*, Lemma 2.5，Propositions 4.3、4.7。
- Venkatesan Guruswami, Xin Lyu, Xiuhan Wang,
  *Range Avoidance for Low-Depth Circuits and Connections to Pseudorandomness*,
  APPROX/RANDOM 2022，Theorems 5--6。
- Karthik Gajulapalli, Alexander Golovnev, Satyajeet Nagargoje, Sidhant Saraogi,
  *Range Avoidance for Constant-Depth Circuits: Hardness and Algorithms*,
  APPROX/RANDOM 2023，Theorems 1--2。
- Hanlin Ren, Rahul Santhanam, Zhikun Wang,
  *On the Range Avoidance Problem for Circuits*, FOCS 2022。
- Zeyong Li, *Symmetric Exponential Time Requires Near-Maximum Circuit Size*,
  arXiv:2310.17762v2。

式 (1)、(5)、(9)--(14) 及其参数组合是本项目推论；文献只承重其中明确标注的复杂度上界、
hitting-set 与 constructive-separation 接口。本文没有证明 \(P\ne NP\)。
