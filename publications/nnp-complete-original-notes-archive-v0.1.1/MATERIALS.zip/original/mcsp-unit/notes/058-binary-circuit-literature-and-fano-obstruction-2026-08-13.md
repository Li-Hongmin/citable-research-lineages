> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Binary circuit-deletion 族：文献边界与 Fano 障碍（2026-08-13）

## 决策

检索目标是判断：同中心 row-star 的重写

\[
 S\longmapsto S\cup\{\tau\}
\]

是否可以借助 binary-matroid 的 circuit elimination、circuit-difference 或固定元素
packing/covering 定理，推出两两相交的 deletion 族必须有公共列，进而得到
AEKR thinning 的第二个 \(1/2\) 因子。

结论：**不能。** 甚至在 Fano 二进制拟阵 \(F_7\)（它本身是
circuit-difference matroid）中，也有固定 target 的四个同阶 deletion 集两两相交但无
公共元素。该族还可嵌入真实的 affine collision 实例；其完整 thinning 质量为
\(1/64\)，所以不构成 AEKR 反例，却精确说明单靠 circuit 交叉结构不能闭合证明。

检索日期：2026-08-13。使用本地 ResearchLibrary 的
`mcsp-affine-ekr-boundary-2026` 项目矩阵、Semantic Scholar、OpenAlex/Crossref，以及
对开放 PDF 的定理核对。

## 1. 二元拟阵的可用事实及其边界

对任意 binary matroid，若 \(C_1,C_2\) 是相交 circuit，则

\[
 C_1\triangle C_2
\]

是若干个两两不交 circuits 的并。这只是 binary cycle-space 事实，不保证对称差本身
仍是单个 circuit，也不保证一族相交 circuits 有公共元素。

Drummond--Fife--Grace--Oxley, *Circuit-Difference Matroids*, EJC 27(3) (2020),
DOI 10.37236/9314, arXiv:2001.08982，定义 circuit-difference matroid 为“任意相交的
两个 circuits 的对称差仍是一个 circuit”。其主定理是：连通 regular matroid
属于该类，当且仅当不存在一对 skew circuits。该定理不能迁移到当前 affine atom
拟阵：当前对象一般非正则，且即便要求 circuit-difference，下面的 \(F_7\) 族仍然
没有公共 deletion 元素。

Cho--Oxley--Wang, *The symmetric strong circuit elimination property*,
arXiv:2508.00132 (2025)，把“保留两个指定非公共元素”的强 circuit elimination
刻画为连通拟阵无 skew circuits；但它仍只产生 atom 层 circuit，不能保证把成对的
\((q_u,p_u)\) atom 压回同一个 cell 后保持 spoiler 的奇偶证书。note 034 的显式
消去失败正是这个压缩障碍。

Seymour, *Packing and covering with matroid circuits*, JCTB 29 (1980),
DOI 10.1016/0095-8956(80)90067-2，以及 Lemos--Oxley, *Matroid packing and
covering with circuits through an element*, JCTB 96 (2006), DOI
10.1016/j.jctb.2005.07.001，属于 circuit 的 packing/covering（后者特别针对
through a fixed element）接口；它们没有 affine parameter \(z\)、upward rectangle
测度或独立 row/column thinning。当前 witness 只保证“共享一个 cell”，不保证所选
atom circuit 共享同一个固定 atom，故不能直接套用固定元素 packing/covering 界。

## 2. Fano 固定 target 的无公共列族

把 \(\mathbb F_2^3\setminus\{0\}\) 看作 Fano 向量拟阵。取六个列向量

\[
 u_0=001,\quad u_1=100,\quad u_2=101,\quad
 u_3=111,\quad u_4=011,\quad u_5=010,
\]

以及固定 target

\[
 \tau=110.
\]

定义四个 deletion 集

\[
\begin{aligned}
 S_1&=\{u_1,u_2,u_3\},\\
 S_2&=\{u_0,u_1,u_4\},\\
 S_3&=\{u_0,u_2,u_5\},\\
 S_4&=\{u_3,u_4,u_5\}.
\end{aligned}
\]

逐式计算有

\[
 \bigoplus_{u\in S_i}u=\tau\qquad(i=1,2,3,4).
\]

每个 \(S_i\) 线性独立，因此 \(S_i\cup\{\tau\}\) 是一个 circuit（Fano 中为
补某条 line 的四元 circuit）。同时

\[
 |S_i\cap S_j|=1\quad(i\ne j),
 \qquad \bigcap_{i=1}^4 S_i=\varnothing.
\]

Fano 拟阵的 circuits 是七条三元 lines 及其七个四元补集；直接检查可见相交
circuits 的对称差仍是单个 circuit，所以这里甚至处在 circuit-difference 类中。
因此下述推理路线不成立：

\[
\text{固定 target circuit-deletion} + \text{两两相交}
\ \Longrightarrow\ \text{公共 deletion 元素}.
\]

这不是任意 set-system 反例，而是固定 XOR target、固定 deletion 大小 3 的 binary
向量拟阵反例。

## 3. 嵌入真实 affine collision witness

用四比特整数表示 \(\mathbb F_2^4\)。取

\[
 X=\{0,6\},\qquad
 Y=\{1,2,3,4,5,7,8\},\qquad
 s=(6,8),
\]

中心 row 为 \(x_0=0\)，四个 witness 为

\[
\begin{aligned}
 T_1&=\{(0,4),(0,5),(0,7)\},\\
 T_2&=\{(0,1),(0,4),(0,3)\},\\
 T_3&=\{(0,1),(0,5),(0,2)\},\\
 T_4&=\{(0,7),(0,3),(0,2)\}.
\end{aligned}
\tag{1}
\]

这里 \(x_s+x_0=6\)，而四个列集的 XOR 都是 6；每个 witness 的大小为 3，故属于
同一个 odd row-star target。逐个删去一个 cell 后，与 spoiler \(s\) 相容；可取的
参数 \(z=(r,t)\)（所有 \(t=0\)）如下：

\[
\begin{array}{c|ccc}
S_i & \text{删去第一个列} & \text{删去第二个列} & \text{删去第三个列}\\
\hline
\{4,5,7\}&r=9&r=15&r=14\\
\{1,4,3\}&r=14&r=9&r=15\\
\{1,5,2\}&r=14&r=15&r=9\\
\{7,3,2\}&r=14&r=15&r=9
\end{array}
\]

直接代入 \(q_{(x,y)}z=0\)、\(p_{(x,y)}z=1\) 即核验表中每个参数满足相应的
\(T_i\setminus\{cell\}\) 与 \(s\)；而 \(T_i\cup\{s\}\) 无解。因此 (1) 是
真实的 inclusion-minimal collision witness 族。它们两两相交（每对恰共享一个
column cell），但没有公共 cell。

## 4. 完整 thinning 的精确质量

对上述实例，非零的 affine 参数恰为

\[
 r\in\{2,3,4,5,10,11,12,13\},\qquad t=0,
\]

共 8 个。每个这样的 \(z\) 的最大 affine 叶含中心 row 0，并包含且只包含某一个
三列集 \(S_i\)（另外四个参数还可能包含列 8；该列不属于任何 \(S_i\)，不影响命中
概率）。因此在独立 \(1/2\) 行、列 thinning 下，命中该 witness 的条件概率为

\[
 \mu_z=\frac12\cdot\left(\frac12\right)^3=\frac1{16}.
\]

所有其他 24 个 \(z\) 的 \(\mu_z=0\)，于是

\[
 \sum_z\mu_z=8\cdot\frac1{16}=\frac12,
 \qquad
 \Pr_{z,U,V}[\exists i:T_i\subseteq R_z(U,V)]
 =\frac{1/2}{2^{N+1}}=\frac1{64}<\frac1{16}.
\]

所以该族不是完整 AEKR 反例；它给出的严格信息是：

1. “固定 target 的 circuit-deletion 两两相交族有公共列”是假的；
2. 该族的第二个 \(1/2\) 因子来自 affine 参数只激活 8 个叶，而不是来自
   circuit packing/covering；
3. 完整证明必须联合利用 target-support、另一侧（column 或 spoiler）方程与
   thinning，而不能只在 binary circuit 交叉图上做 EKR。

## 5. 相关文献的精确边界

* Bérczi--Király--Kobayashi, *Covering Intersecting Bi-set Families under Matroid
  Constraints*, SIAM J. Discrete Math. 30 (2016), 1758--1774,
  DOI 10.1137/15M1049099。其 Theorem 1.3/2.2 处理满足（mixed/active）交集闭包
  的 bi-set 族，并给出有向弧 cover 的次模/拟阵 min--max 条件；AEKR 只有 cell-level
  两两相交，未满足该闭包，也没有弧 cover 目标或 thinning 测度。
* Frankl--Ota--Tokushige, *Covers in Uniform Intersecting Families...*, JCTA 74
  (1996), DOI 10.1006/j.jcta.1996.0035，的 \(3\)-uniform、\(\tau=3\) 精确界只适用
  固定三元族；不能覆盖可变大小 affine witness。
* Tanaka--Tokushige, *Extremal problems for intersecting families of subspaces with
  a measure*, EJC (2025), DOI 10.1016/j.ejc.2025.104156，使用按子空间维数加权的
  \(q\)-biased measure；不是 affine-parity 参数加独立 row/column thinning。
* Chang--Liu--Liu, *A sharp p-biased product bound for r-cross-intersecting families*,
  arXiv:2606.15618，以及 *The Frankl--Tokushige product conjectures for
  r-cross-intersecting families*, arXiv:2607.21589，在独立 subset 族、
  \(p=1/2,r=4\) 时形式上给 \(1/16\)；AEKR 是一个相关的 affine rectangle 事件，
  不能编码成四个独立 cross-intersecting subset 族。

因此，当前文献没有直接给出

\[
\text{pairwise-intersecting fixed-target binary circuit-deletion family}
\ \Longrightarrow\ 1/16\text{ affine--thinning bound}.
\]

该接口应标记为“circuit-only 路线关闭；需要 affine-support/双侧 thinning 结构”。
