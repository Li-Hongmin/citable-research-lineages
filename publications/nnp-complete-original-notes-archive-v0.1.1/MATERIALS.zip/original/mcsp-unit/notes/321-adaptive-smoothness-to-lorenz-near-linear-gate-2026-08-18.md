> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Adaptive smoothness forces the near-linear Lorenz gate (2026-08-18)

## Theorem

Fix \(0<\rho<1\) and \(c\ge0\). Let

\[
  \Pi_k:\{0,1\}^k\longrightarrow\{0,1\}^{N_k},
  \qquad N_k\le k(\log k)^c,
\]

be a common-proof family. For every message coordinate \(i\), let \(D_{k,i}\) be an
adaptive decoder which reads at most \(r_k\ge1\) proof symbols and outputs
\(\{0,1,\bot\}\). Assume honest-path completeness error at most \(\varepsilon_k\):

\[
  \Pr[D_{k,i}^{\Pi_k(m)}\ne m_i]\le\varepsilon_k
  \qquad(m\in\{0,1\}^k,\ i\in[k]).
\tag{321.1}
\]

Assume also the following conditional honest-path smoothness. At every query step,
conditioned on any honest transcript prefix that reaches that step, every proof position
is queried with probability at most \(\chi_k/N_k\). (Early stopping is allowed; only
actual query steps are counted.) Then the following implication holds for all
sufficiently large lengths in the family:

\[
  \varepsilon_k+r_k\chi_k\rho\le\frac1{12}
  \quad\Longrightarrow\quad
  r_k\log(r_k+2)\ge
  \eta(\rho,c)(\log k)^{1/3}.
\tag{321.2}
\]

Equivalently, every near-linear family with
\(r_k\log(r_k+2)=o((\log k)^{1/3})\) must violate the smooth low-defect window:

\[
  \varepsilon_k+r_k\chi_k\rho>\frac1{12}
\tag{321.3}
\]

eventually. Thus a positive-radius adaptive construction cannot simultaneously have
small honest error, low query depth, and an honest query distribution whose point masses
are \(O(1/N_k)\) with a fixed constant.

## Proof

For fixed \(m,i\), let \(\nu_{m,i}(v)\) be the expected number of occurrences of proof
position \(v\) on the honest execution. The conditional smoothness hypothesis gives

\[
  \nu_{m,i}(v)\le \frac{r_k\chi_k}{N_k}\qquad(v\in[N_k]).
\tag{321.4}
\]

Consequently the sum of the largest \(\lfloor\rho N_k\rfloor\) values of
\(\nu_{m,i}\), the pathwise Lorenz mass of the top \(\rho N_k\) positions, is at most

\[
  \Lambda_{\rho,k}\le \rho N_k\frac{r_k\chi_k}{N_k}\le r_k\chi_k\rho.
\tag{321.5}
\]

Apply the pathwise Lorenz closure to (321.1). It gives an adaptive relaxed local decoder
of radius \(\rho\), completeness at least \(1-\varepsilon_k\), and wrong-output probability
at most

\[
  s_k\le\varepsilon_k+\Lambda_{\rho,k}\le\varepsilon_k+r_k\chi_k\rho.
\tag{321.6}
\]

Under (321.2), both \(\varepsilon_k\le1/12\) and \(s_k\le1/12\). The full Boolean message
cube supplies robust points for both output values, and

\[
  2\varepsilon_k+\Lambda_{\rho,k}
  =\varepsilon_k+s_k\le\frac14<1
\]

forces \(\Pi_k\) to be injective, hence \(N_k\ge k\). The source-audited variable-query
relaxed-DGL transfer then has normalized query parameter

\[
  Q_k\le C_0r_k\log(r_k+2).
\tag{321.7}
\]

If \(Q_k^3\le\eta_0\log N_k\), its shared-sample counting contradiction rules out
\(N_k\le k(\log k)^c\). Therefore \(Q_k^3>\eta_0\log N_k\ge\eta_0\log k\), and (321.2)
follows after absorbing the fixed constants \(C_0,\eta_0\) into \(\eta(\rho,c)\).
\(\square\)

## Interpretation and boundary

The theorem is a composition of two independently checkable mechanisms:

1. conditional \(\chi/N\)-smoothness converts directly into the exact adaptive Lorenz
   profile needed by the pathwise first-hit argument; and
2. the variable-query relaxed-DGL transfer converts a low-Lorenz adaptive relaxed decoder
   into the near-linear locality threshold.

It is stronger than a fixed-\(r_k\) incidence statement because it retains the growing
query parameter and gives the explicit product \(r_k\chi_k\rho\). It is not an
unconditional dPCP impossibility theorem: a construction may escape by using non-smooth
or target-dependent addressing, a larger honest error, a larger Lorenz mass, a bottom/cover
mechanism, or a proof family outside the common-address model.

The smoothness assumption is conditional on every honest transcript prefix. A marginal
bound only after averaging over coordinates, or a bound for one selected policy, does not
imply (321.4). Likewise, the theorem does not claim that current GMWZ dPCP/PCPPs supply
the common proof map, target-relative radius, or this pathwise smoothness at RW address
scale. The variable-query DGL step is the derived extension recorded in note 255; the
source theorem states its relaxed application in the constant-query regime.

## Sources and links

* [Adaptive imperfect-completeness Lorenz envelope](../../rw-jk-succinct-reconstruction/statements/adaptive-imperfect-lorenz-envelope.md).
* [Pathwise Lorenz profile](226-pathwise-lorenz-profile-adaptive-shared-proof-closure-2026-08-17.md).
* [Variable-query relaxed-DGL theorem](255-variable-query-relaxed-dgl-theorem-2026-08-17.md).
* Dall'Agnol--Gur--Lachish, TR20-154: <https://eccc.weizmann.ac.il/report/2020/154/>.
