> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Computation-witness 与 auxiliary PCP bits 不自动跨越 RW 的 hardness 尺度（2026-08-15）

## 命题范围

本 note 只检查 Ren--Williams Theorems 3.4--3.5 的 computation-witness/auxiliary PCP
proof 是否会把第 \(i\) 阶段的 AVOID 输出自动提升为下一阶段
Jeřábek--Korten (JK) 所需的 hard truth table。结论是一个无条件的
hardness-transfer 缺口，不是对这种 transfer 的一般不可能性证明。

记第 \(i\) 阶段的旧输出为

\[
B_i\in\{0,1\}^{2n_i},
\qquad
q_i:=n_{i+1},
\qquad
T_i:=\max\{2^{cD^i n_0},q_i\},
\tag{1}
\]

并令 \(F_i\) 是将 \(B_i\) 补零到长度 \(T_i\) 后得到的 table。Theorem 3.5 对固定
输入 \(x_0\) 产生一条 canonical PCP history

\[
\Pi_i=(\widetilde w_i,\Pi_i'),
\qquad
L_i:=|\Pi_i|\le T_i^a,
\tag{2}
\]

其中 \(a\) 是 PCP 构造的固定常数，
\(\widetilde w_i\) 是 Reed--Muller systematic witness 部分，
\(\Pi_i'\) 是 auxiliary proof oracles。RW 的 Solve 在下一阶段 JK 中实际使用的是
\(\Pi_i\)，而不是自动使用 \(B_i\) 的电路复杂度。

## 1. 旧 AVOID block 没有下一尺度的自动硬度

若直接把 \(B_i\) 或 \(F_i\) 作为 truth table，标准 truth-table 电路给出

\[
\operatorname{CC}(B_i)=O(n_i\log n_i),
\qquad
\operatorname{CC}(F_i)=O(n_i\log T_i).
\tag{3}
\]

这里的上界只需把 \(2n_i\) 个固定 bits 用地址多路复用，并在补零区输出常数。因而
\(B_i\notin\operatorname{Range}(G_{n_i})\) 本身不蕴含
\(\operatorname{CC}(B_i)\) 很大。

下一阶段 JK 的 hard/easy 门槛是

\[
S_i:=\Theta\!\bigl(|G_{q_i}|\log T_i\bigr).
\tag{4}
\]

即使把 \(G_q\) 改成 near-linear size（\(|G_q|=q\operatorname{polylog}q\)），在
\(q_i=n_i^C\) 下仍有

\[
\frac{S_i}{\operatorname{CC}(B_i)}
\gtrsim
\frac{n_i^{C-1}}{\operatorname{polylog}(n_i)}\longrightarrow\infty.
\tag{5}
\]

在原文允许的 \(|G_q|\le q^4\) 情形，缺口更大。因此旧 AVOID block 的 outsider 性质
不能自动跨到下一阶段 JK 阈值。

## 2. 单一 canonical PCP history 的必要长度条件

### 引理（固定 proof 的位置上界）

设 \(\Pi_i\) 是一条固定的 canonical proof，长度 \(L_i\)，而下一阶段 JK block 宽度
为 \(2q_i\)。任何由 \(\Pi_i\) 的 aligned \(2q_i\)-bit blocks 组成的深度 \(h\) 连续
tuple，均由一个起始位置确定。因此实际 tuple occurrences 满足

\[
|\mathcal T_h(\Pi_i)|
\le
\max\!\left\{0,
\left\lfloor\frac{L_i}{2q_i}\right\rfloor-2^h+1
\right\}
\le \frac{L_i}{2q_i}.
\tag{6}
\]

这个计数已经包括 \(\widetilde w_i\) 与全部 \(\Pi_i'\) bits；若只取 systematic prefix，
数量只会减少。特别地，若要从一条固定 proof 得到超过 \(2^{q_i}\) 个实际 tuples，
必要条件是

\[
L_i>2q_i\,2^{q_i}.
\tag{7}
\]

由 (2)，RW 的稳定阶段 \(T_i=q_i\) 时 \(L_i\le q_i^a=2^{o(q_i)}\)。早期阶段
\(\log T_i=O(D^i n_0)\)、\(q_i=n_0^{C^{i+1}}\)，且 \(C>D+1\)，同样有

\[
L_i\le T_i^a=2^{o(q_i)}.
\tag{8}
\]

因此固定 computation history 无法仅凭其位置数量提供 JK capacity 所需的
\(>2^{q_i}\) 个 aligned tuples。

### 推论（hard block 的长度必要条件）

对一条长度 \(L_i\) 的 proof，平凡硬编码电路给出

\[
\operatorname{CC}(\Pi_i)\le O(L_i\log L_i).
\tag{9}

\]

所以要越过下一阶段门槛 (4)，至少需要

\[
L_i\log L_i\gtrsim S_i.
\tag{10}
\]

这只是必要条件。若 \(L_i\log L_i<S_i\)，则所有长度为 \(L_i\) 的 proofs 都不可能
达到 JK hard 门槛；若 (10) 成立，也不能推出 canonical \(\Pi_i\) 是 hard。

例如稳定阶段 \(T_i\asymp q_i\) 且使用最坏 \(|G_{q_i}|\le q_i^4\) 时，若 PCP 长度
指数 \(a<4\)，则 \(L_i\log L_i=o(q_i^4\log q_i)\)，hard 分支在长度上就不可能。
对 near-linear \(G_q\)，(10) 可能在较小的 \(a\) 下有容量，但仍然没有 hardness
lower bound。

## 3. Systematic witness、auxiliary bits 与候选家族的量词

Theorem 3.5 的 completeness 只给出

\[
\exists\,\Pi_i=(\widetilde w_i,\Pi_i')
\quad
\text{被 verifier 以概率 1 接受}.
\tag{11}

\]

在 Reed--Muller code 空间（个别次数小于 \(|H|\)）中，完整 systematic message
\(w_i=\widetilde w_i|_{H^m}\) 唯一确定 \(\widetilde w_i\)。这保证表示的一致性，但不
保证 \(w_i\)、\(\widetilde w_i\) 或 \(\Pi_i'\) 有任何 circuit lower bound。将两个
systematic windows 任意拼接通常得到另一个 message，而不是同一条 canonical history。

若考虑固定 \(x_i\) 的所有候选 computation witnesses 与 auxiliary proofs，安全的
计数上界只是

\[
|\mathcal W_i|\le 2^{N_i},
\qquad
|\mathcal P_i|\le 2^{L_i},
\tag{12}
\]

其中 \(N_i\) 是 raw computation witness 长度，\(\mathcal P_i\) 是长度 \(L_i\) 的
候选 PCP strings。输入 \(\lceil\log L_i\rceil\) bits、大小至多 \(S\) 的 Boolean circuits 数量为

\[
2^{O(S\log S)}.
\tag{13}
\]

因此只有在候选 accepted family 已知满足

\[
|\mathcal P_i|>2^{O(S_i\log S_i)}
\tag{14}
\]

时，计数才可推出“至少存在一个 proof 的 circuit complexity 超过 \(S_i\)”。
Theorem 3.4--3.5 没有给出 (14)，更没有给出一个能在
\(\operatorname{TIME}[\operatorname{poly}(T_i)]^{NP}\) 中选出该 hard member 的程序。
即使 (14) 另由外部假设成立，RW 归纳使用的仍是某个 canonical \(\Pi_i\)，不能把

\[
\exists\,\Pi\text{ hard and accepted}
\]

替换成

\[
\operatorname{CC}(\Pi_i)>S_i
\]

而不增加新的选择接口。

## 4. 局部随机访问不是全局 hardness transfer

PCP verifier 与 Reed--Muller self-corrector 只提供对固定 \(\Pi_i\) 的局部 bit access：
每次使用 \(O(\operatorname{polylog}T_i)\) queries/randomness 恢复一个位置。这不等于
有一个全局 hard address-to-bit function。

对固定 proof，直接把 \(L_i\) 个 bits 硬编码并做地址多路复用，即可得到规模
\(O(L_i\log L_i)\) 的全表电路；若另有一个每位大小 \(a(T_i)\) 的局部 evaluator，
朴素并行化也只给出 \(O(L_i a(T_i))\) 的上界。局部可访问性因此不会自动产生

\[
\operatorname{CC}(\Pi_i)>S_i.
\tag{15}
\]

要获得真正的跨尺度 transfer，必须额外证明一个对所有地址共享的 batch evaluator
或 whole-tree labeler，并证明其输出函数的 circuit lower bound；Theorems 3.4--3.5
本身不提供该接口。

## 结论与边界

当前可证的判断是

\[
\boxed{
\text{computation-witness/auxiliary PCP bits 给出表示与局部验证，}
\text{但没有无条件的跨尺度 hardness transfer。}
}
\]

这不是说某种特别设计的 auxiliary padding、hard witness 或 batch labeler 不可能存在；
它们若能保证 (10)、(14) 或 (15) 的反向不等式，就会成为新的独立假设/构造。当前
RW Theorems 3.4--3.5 只保证一条可验证的 canonical history，不能从其 systematic
prefix、低度系数、候选 witness 家族或局部随机访问自动推出下一阶段 JK hard block。

来源：Ren--Williams, ECCC TR26-118 rev.1, Theorems 3.1, 3.4, 3.5, 4.1, 4.3；与
[note164](164-rw-fixed-history-rm-block-supply-boundary-2026-08-15.md)、
[note165](165-near-linear-decoder-does-not-close-rw-scale-gap-2026-08-15.md) 联读。
