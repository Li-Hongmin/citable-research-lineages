> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed coverage outsider is an \(E^{NP}\)-hard-table construction (2026-08-15)

## Question and quantifiers

Let

\[
q_m=2^{m-1},\qquad N_m=2q_m=2^m,
\]

and let \(G_m:\{0,1\}^{q_m}\to\{0,1\}^{N_m}\) be a fixed decoder family. We use the concrete
uniformity convention that a gate-list for \(G_m\) is generated from \(1^{q_m}\) in
\(q_m^{O(1)}\) time, has size \(q_m^{O(1)}\), and can be evaluated within the same bound. Write

\[
R_m=\operatorname{Range}(G_m).
\]

Assume a coverage schedule \(s_m\) satisfies

\[
\mathcal C_{m,\le s_m}\subseteq R_m,
\tag{1}
\]

where \(\mathcal C_{m,\le s_m}\) is the set of truth tables of \(m\)-input Boolean circuits of
size at most \(s_m\), in the same fixed finite basis used for \(\operatorname{CC}\) below and in
Korten's hard-table theorem. The issue is whether one can produce, uniformly and with an NP oracle,
some \(z_m\notin R_m\) without first proving a new circuit lower bound.

## The equivalence

Define the following two statements, with all schedules fixed and time-constructible.

* **OutGen\(_G^{\mathrm{NP}}\).** There is one oracle machine \(O^{\mathrm{NP}}\) which, for all
  sufficiently large \(m\), on \(1^m\), outputs a full \(N_m\)-bit string \(z_m\notin R_m\) in
  time \(q_m^{O(1)}\), with NP queries of polynomially bounded length. Finite exceptional lengths
  may be hardwired.
* **Hard-\(E^{\mathrm{NP}}\)(\(s\)).** There is a language \(L\in E^{\mathrm{NP}}\) such that, for
  all sufficiently large \(m\),
  \[
  \operatorname{CC}(L_m)>s_m,
\tag{2}
  \]
  where \(L_m:\{0,1\}^m\to\{0,1\}\) is the length-\(m\) slice of \(L\).

Under coverage (1),

\[
\boxed{\mathrm{OutGen}_G^{\mathrm{NP}}\quad\Longleftrightarrow\quad
\mathrm{Hard\text{-}}E^{\mathrm{NP}}(s).}
\tag{3}
\]

### OutGen \(\to\) Hard-\(E^{\mathrm{NP}}\)

Given \(O^{\mathrm{NP}}\), define \(L_m(x)=z_m[x]\) in the fixed lexicographic truth-table
ordering. On input \(x\in\{0,1\}^m\), an \(E^{\mathrm{NP}}\) machine simulates
\(O^{\mathrm{NP}}(1^m)\), retains the \(x\)-th output bit, and answers its NP queries using its
NP oracle. Since

\[
q_m^{O(1)}=2^{O(m)},
\]

this is an \(E^{\mathrm{NP}}\) computation. The output is outside \(R_m\), so (1) implies

\[
\operatorname{CC}(L_m)=\operatorname{CC}(z_m)>s_m.
\]

### Hard-\(E^{\mathrm{NP}}\) \(\to\) OutGen

Conversely, suppose \(L\in E^{\mathrm{NP}}\) satisfies (2). On \(1^m\), enumerate all
\(x\in\{0,1\}^m\), run the \(E^{\mathrm{NP}}\) machine for \(L(x)\), and output the resulting
truth table \(z_m=\operatorname{TT}(L_m)\). The enumeration costs

\[
2^m\cdot 2^{O(m)}=2^{O(m)}=q_m^{O(1)},
\]

so it is an allowed \(O^{\mathrm{NP}}\). If \(z_m\in R_m\), coverage (1) would give
\(\operatorname{CC}(L_m)\le s_m\), contradicting (2). Hence \(z_m\notin R_m\).

The equivalence is therefore semantic and does not use a special representation of the
preimage; the cost is the unavoidable full-table output cost.

## Near-linear coverage consequence

For the target window

\[
s_m\ge \frac{q_m}{\operatorname{poly}(m)}
=\frac{2^{m-1}}{\operatorname{poly}(m)},
\tag{4}
\]

Hard-\(E^{\mathrm{NP}}\)(\(s\)) is an exponential circuit lower bound: for every fixed
\(0<\alpha<1\), (4) eventually dominates \(2^{\alpha m}\). Thus any \(q\)-scale
\(\mathrm{FP}^{\mathrm{NP}}\) full-table outsider transducer (time \(q_m^{O(1)}\), equivalently
\(E^{\mathrm{NP}}\)-scale when reindexed by \(m\)) for a decoder with (1) would give an
\(E^{\mathrm{NP}}\) language requiring \(2^{\Omega(m)}\)-size circuits.

This is a genuine barrier, not a counting slogan. A short circuit \(H_m\) generated at
address scale would be a different object; if \(\operatorname{CC}(H_m)\le s_m\), (1) puts its
truth table back in the range. A full-table algorithm necessarily spends
\(\Omega(N_m)=\Omega(q_m)\) output steps and lives at \(E^{\mathrm{NP}}\)-scale.

## Relation to APEPP/Empty

Korten, *The Hardest Explicit Construction* (FOCS 2021; arXiv:2106.00875), defines the
Empty problem as: given a Boolean circuit with \(n\) input wires and \(m>n\) output wires, output
an \(m\)-bit string outside its range. The paper proves that the restricted \(n\mapsto2n\) version
is complete for Empty under circuit-inverter reductions, and that a \(P^{\mathrm{NP}}\) algorithm
for Empty is equivalent to an \(E^{\mathrm{NP}}\) language with \(2^{\Omega(n)}\) circuit
complexity. Our \(G_m:q_m\mapsto2q_m\) shape is exactly this output ratio.

The fixed-family equivalence (3) is weaker than an algorithm for all Empty instances: it only
uses one prescribed \(G_m\). If the outsider procedure instead works for every \(P\)-uniform
\(q\mapsto2q\) circuit, Korten's complete problem applies directly, with the instance length
measured in the \(q\)-bit circuit description. For one fixed decoder, (3) is the correct
statement; it already says that a successful \(q\)-scale \(\mathrm{FP}^{\mathrm{NP}}\) outsider
route is an explicit \(E^{\mathrm{NP}}\) lower-bound construction.

There is also a converse at the level of solver existence. Korten's Theorem 10 says that
the unrestricted Empty problem has a \(P^{\mathrm{NP}}\) algorithm exactly when
\(E^{\mathrm{NP}}\) contains a language with \(2^{\Omega(m)}\) circuit complexity; the paper's
hardness amplification gives the standard near-maximum \(2^m/(2m)\) scale. Consequently, when
the coverage threshold lies in the two-sided window
\[
2^{\alpha m}\le s_m\le (1-\eta)\frac{q_m}{m}
\quad\text{for fixed }0<\alpha<1,\ \eta>0,
\tag{5a}
\]
and the
\(G_m\) descriptions obey the uniformity convention above,

\[
\boxed{
\text{a \(q\)-scale }\mathrm{FP}^{\mathrm{NP}}\text{ solver for this fixed family exists}
\ \Longleftrightarrow\
E^{\mathrm{NP}}\text{ has a }2^{\Omega(m)}\text{ circuit lower bound}.
}
\tag{5}
\]

The reverse implication in (5) invokes the unrestricted Empty solver and then specializes it
to \(G_m\); it is not a claim that the fixed family is APEPP-complete under reductions.

## What this does and does not prove

\[
\boxed{
\begin{array}{ll}
\text{fixed coverage + }q\text{-scale }\mathrm{FP}^{\mathrm{NP}}\text{ full-table outsider} &\Rightarrow
 E^{\mathrm{NP}}\text{ has }2^{\Omega(m)}\text{ circuit lower bounds};\\
\text{fixed coverage alone} &\not\Rightarrow \text{an outsider at address scale};\\
\text{the }E^{\mathrm{NP}}\text{ lower bound} &\not\Rightarrow P\ne NP\text{ by itself}.
\end{array}}
\]

To obtain \(P\ne NP\) through the Ren--Williams/JK route, the outsider must still be tied to a
SAT-candidate forcing lower bound and be queryable at the base-\(n\) scale (note 121). Replacing
that missing interface by a generic Empty call merely moves the problem to the explicit
\(E^{\mathrm{NP}}\) circuit-lower-bound frontier; it does not close the complexity-class gap.

This note is a parameter equivalence and route boundary. It does not claim a new unconditional
circuit lower bound or \(P\ne NP\).

## Source boundary

- Korten, *The Hardest Explicit Construction*, FOCS 2021 / arXiv:2106.00875, Definitions 3 and
  16, Lemma 3, and Theorem 10 (local ResearchLibrary record korten2021hardest).
- The coverage obstruction and the fixed-decoder quantifier distinction use notes 111 and 157.
