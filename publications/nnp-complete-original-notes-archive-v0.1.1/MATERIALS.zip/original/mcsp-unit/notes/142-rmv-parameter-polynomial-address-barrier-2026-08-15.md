> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RMV 参数体系的 polynomial-address 边界（2026-08-15）

## 命题

本 note 只约束 Chen--Li--Liang Theorem 5.1/6.1 所使用的 RMV 重构架构，不是对
所有 PCP 重构算法的下界。

设历史长度为 \(T\)，外部地址/输出长度为 \(m\)，RM 参数为 \(r,d,h,q\)。沿用该文
的条件：\(d=O(1)\)、\(h=\operatorname{poly}(r)\)、\(q=h^{\Theta(1)}\)，以及

\[
  h^{1/100}\le m.
\tag{1}
\]

为了把长度为 \(\operatorname{poly}(T)\) 的 PCP 历史嵌入
\(\mathrm{RM}_{r,h,q}\)，其编码空间必须满足

\[
  q^r\ge |\Pi|=T^{\Omega(1)}.
\tag{2}
\]

由于 \(\log q=\Theta(\log h)\)（论文的 Theorem 5.1 取 \(q=h^{100}\)），(2) 给出

\[
  r\log h=\Omega(\log T).
\tag{3}
\]

Theorem 6.1 的 evaluation protocol 具有时间上界

\[
  m^{\,O\!\left(d(1+\log r)^d\right)}.
\tag{4}
\]

因此，该**已给出的 RMV 复杂度保证**若要落在 \(m^{O(1)}\)，就必须取

\[
  r=O(1).
\tag{5}
\]

由 (3) 和 (5)，

\[
  \log h=\Omega(\log T),
  \qquad h=T^{\Omega(1)}.
\tag{6}
\]

再由 (1)，得到

\[
  m=T^{\Omega(1/100)}.
\tag{7}
\]

换言之，在这套 RMV 参数体系中，polynomial-time evaluation 只有在外部地址长度
本身已经是历史长度 \(T\) 的多项式时才被该定理保证。若

\[
  T=2^{n^\gamma}
  \qquad(\gamma>0\text{ 固定}),
\]

而目标地址长度是 \(m=\operatorname{poly}(n)\)，则 (7) 不可能成立；标准选择
\(h=m^{100}\) 给出的 \(r=\Omega(n^\gamma/\log n)\)，正是

\[
  m^{O((\log n)^d)}
\]

的准多项式地址时间边界。

## 证明范围与不能推出的内容

上面的推导只使用论文明确的编码容量、参数条件和 evaluation-time **上界**。它说明：

1. 在 Theorem 6.1 的 RMV/递归局部提取器中，没有一个仅靠重新选择 \(r,h,q\) 的
   参数窗口，能同时保持 \(T=2^{n^\gamma}\)、\(m=\operatorname{poly}(n)\) 和论文
   已证明的 \(m^{O(1)}\) evaluation guarantee；
2. 这不是任意重构算法的时间下界。论文的上界变成准多项式，不排除另一种 PCP、
   HSG 或整词访问器具有更快实现；
3. 即使把 \(m\) 放大到满足 (7)，得到的也是 \(T\)-尺度重构，不能直接填补
   Ren--Williams/JK 所需的 base-address \(n\)-尺度接口。

因此，下一步若仍沿 RW/JK 路线，必须改变至少一个结构性接口：缩短编码历史、替换
RMV 递归局部提取器，或直接构造一个不依赖 \(r\)-层递归的整词 preimage accessor。
继续调节 \(h=m^{100}\) 的常数不会改变这个结论。

## 文献边界

- Chen--Li--Liang, *Maximum Circuit Lower Bounds for Exponential-time Arthur Merlin*,
  ECCC TR24-182，Theorems 5.1、6.1：
  [official report](https://eccc.weizmann.ac.il/report/2024/182/)。
- Ren--Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin--Arthur Queries*, ECCC TR26-118：
  [official report](https://eccc.weizmann.ac.il/report/2026/118/revision/1/download)。

本 note 是一个架构内参数排除，不是一般 PCP lower bound，也不声称已经证明
\(P\ne NP\)。
