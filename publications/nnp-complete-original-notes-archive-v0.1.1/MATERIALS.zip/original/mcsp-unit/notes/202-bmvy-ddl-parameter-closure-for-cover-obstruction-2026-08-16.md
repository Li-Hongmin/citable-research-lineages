> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# BMVY/DDL 参数闭合：shared-top DPT 的源特定 cover obstruction（2026-08-16）

## 结论

本 note 关闭 note 201 中唯一的负面谱门，但只在明确的 BMVY/DDL 源族内作结论。
固定目标面维数 \(K\)，取环境维数 \(d\ge 3K\)，并取素数 \(p\) 足够大。对
BMVY 构造中的仿射辛 building

\[
\widetilde C_d(\mathbb Q_p)
\]

的有限商 \(X_i=\Gamma_i\backslash\widetilde C_d\)，选取群过滤中的两个相邻层级

\[
\Gamma_{i+1}<\Gamma_i,
\qquad L_i=[\Gamma_i:\Gamma_{i+1}]>1,
\]

并要求两层都满足 BMVY 的“非平凡群元移动每个顶点至少距离 \(4\)”条件。则

1. \(X_i^{\le K}\) 是 \(\lambda\)-two-sided HDX，其中
   \(\lambda\le 0.99/K\)；
2. \(X_{i+1}^{\le K}\to X_i^{\le K}\) 是有限、连通、\(L_i\)-重 cover；
3. 因而 Dikstein--Dinur Lemma 1.2 给出 Boolean face table
   \(\{f_A:A\in X_i(K)\}\)，满足 shared-top \(V\)-test 的
   \(\operatorname{Agree}\ge 1/L_i\)，但对任意 base vertex word
   \(H:X_i(0)\to\{0,1\}\)，

\[
\Pr_{A\in X_i(K)}[f_A\overset{1-\zeta}{\approx}H|_A]
\le \exp(-\Omega_\zeta(K)),
\qquad \zeta<1/2.
\]

因此，BMVY/GMWZ 的 ordinary shared-top DPT 或 distributional/list soundness
不能黑箱地升级为同一 base 地址空间的 global word。该结论是一个**已证明的源特定
障碍**，不是一般 dPCP、PCPP、RLDC/LDC 的不可能性定理。

## 1. 采样参数确实匹配

BMVY Definition 2.12 的 \((K,\sqrt K)\) direct-product tester 先取顶面
\(D\)，再取共同交面 \(B\)，最后条件独立取 \(A,A'\subseteq D\)；见
[BMVY, Definition 2.12](https://arxiv.org/html/2407.12762)。

Dikstein--Dinur 的 \(V\)-test 取

\[
d_V=2K-\sqrt{K+1}+1
\]

的顶面，并条件于两个 \(K\)-面交大小为 \(\sqrt{K+1}\)；见
[Dikstein--Dinur, Definition 2.8](https://arxiv.org/html/2308.09582)。

所以在根号和面大小作同一整数化后，两者是同一个 shared-top law。这里不需要把
BMVY Theorem 2.13 的 DPT soundness 当作谱定理；我们只使用其 source family 和
上述采样定义。

## 2. 截断 two-sided HDX 门由 DDL Theorem 3.15 关闭

Dikstein--Dinur--Lubotzky Theorem 3.15 对任意 \(\widetilde C_d(\mathbb Q_p)\) 的
有限商给出：其 \(K\)-skeleton 的 two-sided local spectral parameter 为

\[
\lambda_K\le
\max\left\{\frac{C}{\sqrt p},\frac{1}{d-K+1}\right\},
\tag{2.1}
\]

其中 \(C\) 为绝对常数；见
[DDL, Theorem 3.15](https://arxiv.org/html/2402.01078)。

取 \(d\ge 3K\)，则第二项至多 \(1/(2K+1)\)。再取 \(p\) 使

\[
\frac C{\sqrt p}\le \frac1{2K},
\]

便有 \(\lambda_K<0.99/K\)。注意这里的 \(d\) 是 affine-building 的环境维数，
而 \(K\) 是施加 DD Lemma 1.2 的截断面维数；不能把两者混写成同一个参数。

这一步正是 note 201 原先保留为 gate 的内容。它不依赖 BMVY Theorem 2.13 的
“\(X(1)\leftrightarrow X(i)\)”谱陈述，而是调用 DDL 对同一 \(\widetilde C_d\) 商族的
完整截断局部谱定理。

## 3. 有限连通 cover 来自 BMVY 的群过滤

为避免把 cover degree 错记成常数，记 BMVY 过滤所用的 pro-\(\ell_0\) 素数为
\(\ell_0\)，把相邻商的 cover degree 记为 \(L_i\)。BMVY 的构造取一列有限指数群

\[
\Gamma_{i+1}\subsetneq\Gamma_i
\]

并令 \(X_i=\Gamma_i\backslash\widetilde C_d\)。BMVY 同时明确给出相邻过滤层的指数

\[
[H(i):H(i+1)]=\ell_0^{\Theta(d^2)},
\qquad
\log [\Gamma_i:\Gamma_{i+1}]
=\Theta(d^2\log\ell_0)
\tag{3.2}
\]

（在群—格子指数相同的归一化下）。因此后文的
\[
L_i:=[\Gamma_i:\Gamma_{i+1}]
\]
不能未经参数选择写成 \(O(1)\) 或 \(\operatorname{poly}(K)\)。

其构造明确保证：对每个非单位
\(\gamma\in\Gamma_i\)，任意顶点 \(v\) 都有

\[
\operatorname{dist}(v,\gamma v)\ge 4.
\tag{3.1}
\]

这同时保证商映射不识别同一 lifted vertex 的两个邻点，因此在每个链接上是局部
同构。由于 \(\Gamma_{i+1}<\Gamma_i\) 且指数有限，商映射

\[
X_{i+1}\longrightarrow X_i
\]

是有限的 \(L_i\)-重 cover，\(L_i=[\Gamma_i:\Gamma_{i+1}]>1\)；building 的连通性
给出 cover 的连通性。限制到 \(K\)-skeleton 后仍是 cover。

这里必须使用两个相邻有限商，而不能把无限的
\(\widetilde C_d\to X_i\) 直接称为 DD 意义下的有限 cover。

所以 DD Lemma 1.2 的 agreement 下界应精确写成 \(1/L_i
=\ell_0^{-\Theta(d^2)}\)。只有当协议的目标 agreement 阈值不超过这个数时，
该 cover obstruction 才能直接击中该参数窗口；这一步的影响另见
[note 203](203-bmvy-incidence-profile-closes-arbitrary-right-label-patch-2026-08-16.md)。

BMVY 的过滤、指数和距离条件见
[BMVY, Theorem 2.13 proof](https://arxiv.org/html/2407.12762)。

## 4. 应用 DD Lemma 1.2

把 \(X_i^{\le K}\) 视为 \(K\)-维复形。由第 2 节，
\(\lambda_K\le0.99/K\)；由第 3 节，它有连通 \(L_i\)-cover。于是对任意
\(\zeta<1/2\)，DD Lemma 1.2 给出一个 Boolean face ensemble，使

\[
\operatorname{Agree}_V(\mathcal F)\ge 1/L_i,
\]

但对每个 \(H:X_i(0)\to\{0,1\}\) 都有

\[
\Pr_{A\in X_i(K)}
\bigl[f_A\overset{1-\zeta}{\approx}H|_A\bigr]
\le \exp(-\Omega_\zeta(K)).
\tag{4.1}
\]

这正是“高 agreement、无 base global word”的 cover obstruction。DD Lemma 1.2
本身只需要 two-sided HDX 和 connected cover；它**不需要** swap-cocycle expansion。
见 [Dikstein--Dinur, Lemma 1.2](https://arxiv.org/html/2308.09582)。

## 5. swap-cocycle 的正确位置

swap-cocycle/cosystolic expansion 是 DD 的 cover-aware **正面** theorem 所需的
额外结构，而不是上述负面 Lemma 1.2 的前提。DDL 对同一辛商族还给出
swap-cocycle expansion（Theorem 1.3；并在 Claim 4.9 中把它与 suitable-complex
参数合并），见
[DDL, Theorem 1.3](https://arxiv.org/html/2402.01078)。

因此本 note 的逻辑分层是：

* 负面结论（4.1）：DDL 截断谱 + BMVY 有限群过滤 cover + DD Lemma 1.2；
* 正面 cover-aware 解释：再使用 swap-cocycle 与 DD 的 cover-aware theorem。

不能把 swap-cocycle 错写成负面 cover obstruction 的必需 gate。

## 6. 对 simultaneous coordinate robustness 的精确含义

任何声称由 ordinary DPT、distributional soundness 或 list soundness 自动产生
“同一 base proof 地址空间、所有坐标共享一个 global word”的方案，在上述
BMVY/DDL 参数窗口中至少必须做出一个可检验的逃逸：

1. 使用没有该有限 connected cover 的 source；
2. 把 cover sheet index 显式纳入 proof/address，并证明它在目标地址尺度可绑定；
3. 加入 coordinate-normalized outer check，使指定错误 bit 在同一 proof 上产生常数拒绝；
4. 改变量词（例如允许 cover 上的 lift-word），而不再宣称 base-word consistency。

这关闭的是一个具体 source 的 black-box upgrade，不是“近线性 dPCP 一定不可能”。
要升级为 RLDC/LDC 下界，仍需额外的 message-inline reduction；本 note 不声称已完成
该 reduction。

## 结论等级

这是一个可晋级到主论文的 source-specific theorem module：它把 C179 从“待证明的
谱/余边界 gate”升级为“谱 gate 已由 DDL 关闭，负面 cover obstruction 已证”。剩余
的顶级问题是：能否在不触发该 obstruction 的 source 上构造 simultaneous
coordinate-robust proof，或把 sheet-binding 形式化为 RLDC/LDC 型超线性代价。
