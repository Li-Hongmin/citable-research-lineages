> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# q_s=1 极小二元 witness 的指数星族（2026-08-13）

## 命题

对每个 (N\ge3)，存在不交 (X,Y\subseteq\mathbb F_2^N)、spoiler (s)，以及

\[
|mathcal T|=2^{N-1}-1
\]

个两两相交的极小二元 (q_s=1) collision witness。它们共享一个 cell (b)。因此任何把各 witness 的单独命中质量直接相加的权重法都会指数发散；必须先处理公共核/重叠。

## 构造

取三个独立向量 (e_1,e_2,e_3\in\mathbb F_2^N)，令

\[
\delta=e_1+e_2,
\qquad y_b=e_1+e_3,
\qquad s=(e_1,y_b),
\qquad b=(e_2,y_b).
\]

按 (delta)-平面两点 coset 划分 (mathbb F_2^N)。特殊 coset ({e_1,e_2}) 的两点都放入 (X)；每个其余 coset 选一个代表放入 (X)，另一个点放入 (Y)。选择代表时令 (e_3\in X)、(e_2+e_3\in X)，于是 (y_b=e_1+e_3\in Y)。

对每个 (x\in X\setminus\{e_1,e_2})，令

\[
a_x=(x,x+delta),
\qquad T_x=\{a_x,b\}.
\]

代表的选择排除了 (x=e_1+e_2+e_3)，且 (x+delta\in Y)，所以这些 cell 合法。共有

\[
|X|-2=(2^{N-1}+1)-2=2^{N-1}-1
\]

个 witness，且均含 (b)。

## 碰撞与极小性

记 (q_u=(x_u,1))、(p_u=(y_u,1))。由于 (x+delta=(x+e_1+e_2))，有 atom 证书

\[
q_s=q_{a_x}+p_{a_x}+q_b.
\tag{1}
\]

等价地，collision 的奇奇证书可直接写成

\[
e_1+x+e_2=x+delta=y(a_x),
\]

即行侧 \(\{e_1,x,e_2\}\) 与列侧 \(\{y(a_x)\}\) 都是奇数且 xor 相等。

右侧含一个 (p)-atom，故在 (L(T_x)) 上 (q_s=1)，从而 (T_x\cup\{s\}) 不相容。

验证 (L(T_x)\ne\varnothing)：令 (u=x+e_2)。两 cell 的叶方程等价于

\[
u\cdot r=0,
\qquad e_3\cdot r=0,
\qquad delta\cdot r=1,
\]

再取 (t=x\cdot r)。代表的选择保证 (delta\notin\operatorname{span}\{u,e_3\})，故该系统可解。

删去 (a_x) 后，只剩 (b,s)。取 (r) 满足 (delta\cdot r=0)、(e_3\cdot r=1)，再取 (t=e_2\cdot r)，即得相容参数。

删去 (b) 后，只剩 (a_x,s)。需解

\[
(x+e_1)\cdot r=0,
\qquad (x+e_2+e_3)\cdot r=0,
\qquad delta\cdot r=1.
\]

同样由代表选择（排除 (e_1,e_2,e_1+e_2+e_3) 的相应 coset 取向）可解。因此每个 (T_x) 关于 (s) 极小。

## 对加权路线的边界

每个 (T_x) 的参数质量至少 (2^{-3}=1/8)，行列 thinning 再给至少 (2^{-4})（两行、至多两列），故其单独命中质量至少 (2^{-7}=1/128)。于是

\[
\sum_{x} \Pr[T_x\subseteq R_z(U,V)]
\ge {2^{N-1}-1\over128},
\]

而联合事件仍满足

\[
\Pr[\exists x:T_x\subseteq R_z(U,V)]
\le \Pr[b\subseteq R_z(U,V)]=1/16.
\]

所以任何只依赖 (sum_T) 单 witness 权重的 EKR/电路势都不能给出目标；必须使用公共 cell 的重叠、fractional cover 或递归状态。
