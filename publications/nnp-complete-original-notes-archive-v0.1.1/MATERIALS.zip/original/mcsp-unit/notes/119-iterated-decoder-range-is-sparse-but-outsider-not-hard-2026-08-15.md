> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 迭代 decoder 的 range 可以稀疏，但 tree outsider 不自动变硬（2026-08-15）

## 定义

给定

$$
G_q:\{0,1\}^{q}\to\{0,1\}^{2q},
\qquad
G_q(u)=L_q(u)\Vert R_q(u),
$$

定义与 JK block 对齐的 $h$ 层展开。为简记，对任意 seed $u$ 写

$$
u^{L}:=L_q(u),\qquad u^{R}:=R_q(u),
\qquad
u^{L},u^{R}\in\{0,1\}^{q},
$$

再令

$$
\operatorname{BExp}_{q,0}(u)=G_q(u),
\qquad
\operatorname{BExp}_{q,h+1}(u)
 =
\operatorname{BExp}_{q,h}(u^{L})
\Vert
\operatorname{BExp}_{q,h}(u^{R}).
\tag{1}
$$

输出长度为

$$
N_{q,h}=2q\,2^h.
\tag{2}
$$

这正是 JK tree 的完整 leaf string：它包含 $2^h$ 个 $2q$-bit range blocks，
而不是只保留某个中间 parent block。

## 无条件的稀疏性事实

若 $G_q$ 是 uniform、可在其输出长度的多项式时间内求值，则

$$
L_{\mathrm{BExp}}
 =
\{(q,h,y):y\in\operatorname{Range}(\operatorname{BExp}_{q,h})\}
\tag{3}
$$

属于 NP：证书是一个 $q$-bit root seed，验证者按式 (1) 生成 $N_{q,h}$ 个输出位并比较
$y$。同时

$$
\left|\operatorname{Range}(\operatorname{BExp}_{q,h})\right|
\le 2^q.
\tag{4}
$$

若 $2^h=q^\alpha$（固定 $\alpha>0$），则 $N_{q,h}=2q^{1+\alpha}$，而 yes-slice
至多为

$$
2^q
\le
2^{N_{q,h}^{\,1/(1+\alpha)}}.
\tag{5}
$$

所以迭代确实把 range 变成一个 $2^{N^\beta}$-级别的稀疏 NP 语言，其中
$\beta=1/(1+\alpha)<1$。这里首先是固定参数 $(q,h)$ 的输出 slice；若把参数也编码进
语言，仍需按总输入长度重新核对稀疏性。若取 $h=q$，则
$N_{q,h}=2q2^q$，式 (4) 甚至给出
$|\operatorname{Range}|\le N_{q,h}/(2q)\le N_{q,h}/q$ 的 polynomial sparsity；这里的说法只针对固定
$(q,h)$ 的输出 slice，把 $(q,h)$ 一并编码后的全语言还需另行按总输入长度分桶。

这只是计数与验证上界；它没有给出该 sparse language 的 NP-hardness 或任何电路下界。
对 polynomially sparse 的情形，确定性 NP-hardness 本身就会触发 Mahaney 型后果，不能把
它当作一个免费中间结论。

## tree outsider 的复杂度上限

设 $A\subseteq\operatorname{Range}(G_q)$，且每个 $a\in A$ 都是一个 $m$-变量、
size-$s$ 电路的 truth table，其中 $2q=2^m$。对任意 leaf tuple

$$
(a_1,\ldots,a_{2^h})\in A^{2^h},
$$

令 $Y(a_1,\ldots,a_{2^h})$ 为按顺序串接这些 blocks 的长度
$N_{q,h}$ 字符串。把它看成一个 $(m+h)$-变量函数

$$
Y(t,x)=a_t(x),
\qquad
t\in\{0,1\}^{h},\ x\in\{0,1\}^{m}.
\tag{6}
$$

每个 $a_t$ 有 size-$s$ 电路时，直接用 $2^h$ 个地址选择 minterms 和 gated copies
即可得到

$$
\operatorname{CC}(Y)
\le
O\!\left(2^h(s+h)+2^h m\right)
 =
O\!\left(2^h(s+m+h)\right).
\tag{7}
$$

（若允许共享更强，右侧只会更小。）因此，即使 JK capacity argument 找到某个
$Y\notin\operatorname{Range}(\operatorname{BExp}_{q,h})$，当
$s=q/\operatorname{polylog}q$ 时，它仍可能只有

$$
O\!\left(N_{q,h}/\operatorname{polylog}q\right)
$$

的 flat truth-table circuit。它是 expansion range 的 outsider，却不是
$N_{q,h}^{1+\varepsilon}$-级别的 hard function。

这里的 raw nonmembership 需要用直接的 root-image 计数，而不能把某一次
lex-first JK 选择失败单独当作证书：同一个 leaf tuple 可能存在另一组非 canonical
preimages。若所有 $A^{2^h}$ 个 leaf tuples 都在
$\operatorname{Range}(\operatorname{BExp}_{q,h})$，则它们各自有一个 $q$-bit root
seed，而一个 root seed 只能产生一个确定的 leaf tuple，故必有
$|A|^{2^h}\le2^q$。当 $|A|^{2^h}>2^q$ 时，才由此直接得到某个 raw outsider。
式 (7) 不要求该 outsider 在 range；只使用叶块各自的低复杂度。故

$$
\text{tree-capacity outsider}
\;\not\Rightarrow\;
\text{hard truth table}.
\tag{8}
$$

这解释了为什么 note 107--110 的多层 forcing 即使被压缩，也还不能直接接上
P vs NP 的 circuit lower-bound threshold。

## 对路线选择的结论

迭代 expansion 提供一个明确的新对象 $L_{\mathrm{BExp}}$，但要让它改变
$P$ vs $NP$ 决策，仍需至少一个额外命题：

1. 对 $L_{\mathrm{BExp}}$ 的固定语言给出超出其叶块拼接上界的 circuit lower bound；或
2. 证明该语言在适当 reduction 下具有足够强的 hardness magnification 性质；或
3. 给出不是逐叶低复杂度拼接的 tree-normalization，使 outsider 的 flat complexity
   不再受式 (7) 控制。

仅凭 $\lvert\operatorname{Range}(\operatorname{BExp})\rvert\le2^q$、NP verifier 与
JK injectivity，三者都不能完成上述任一项。

## 证据边界

- 式 (1)--(8) 是本项目对 JK expansion 的自足推导。
- note 105--110 给出 pair-lift/tree-capacity 与 compressed-JK 的相应接口。
- 本 note 不声称 sparse range NP-hard，也不声称得到 $P\ne NP$；它只排除
  “迭代后稀疏，所以 outsider 自动足够硬”这一推理。
