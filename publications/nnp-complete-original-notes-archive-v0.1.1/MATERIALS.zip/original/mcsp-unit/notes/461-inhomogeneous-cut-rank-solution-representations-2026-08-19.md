> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Inhomogeneous cut-rank representations 也不能提供 solution automaticity（2026-08-19）

## 本轮改变的判断

C460 的 weighted-automaton 反例若只写成同一组矩阵 \(A_a\)，会留下一个自然的
表示逃逸：tableau 的不同地址位可能使用位置相关的 \(A_{i,a}\)。本 note 把结论
扩展到所有具有 bounded cut interface 的 **inhomogeneous algebraic branching
programs (ABP)**，等价地覆盖固定顺序的 tensor-train / matrix-product
representations。结论不依赖位置齐次性：只要输出地址映射是一个计入状态数的
cut-respecting regular transducer，equality output block 仍强制
\(2^{\Omega(m_{\rm addr})}\) 的宽度。

因此，C443 的 offset-regular constraint evaluator 不能通过把 solution
automaton 改成位置相关的矩阵乘积来获得一个新的 address-scale solution
representation。若 actual C456 assignment 在这一整类模型中有
\(\operatorname{poly}(m_{\rm addr})\) 宽度，下面的 tensor-Lagrange 公式会给出
generic \(q\)-evaluator，并由 C459 触发 published forcing 矛盾。

## 定义：inhomogeneous ABP 与 cut rank

长度为 \(r\) 的函数 \(f:\Delta^r\to F\) 有一个宽度至多 \(s\) 的 inhomogeneous
ABP 表示，如果存在中间维数 \(w_0,\ldots,w_r\le s\)、向量
\(\alpha\in F^{w_0}\)、\(\beta\in F^{w_r}\)，以及

\[
 A_{i,a}\in F^{w_{i-1}\times w_i}
 \qquad (i\in[r],\,a\in\Delta),
\]

使得

\[
 f(z_1,\ldots,z_r)
 =
 \alpha^{\top}A_{1,z_1}A_{2,z_2}\cdots A_{r,z_r}\beta.
\tag{461.1}
\]

矩阵可以随位置 \(i\) 任意变化；所以该定义严格包含 C460 的 homogeneous
weighted automaton。

在第 \(t\) 个切割处，令

\[
 L_t(x)=\alpha^{\top}A_{1,x_1}\cdots A_{t,x_t},
 \qquad
 R_t(y)=A_{t+1,y_1}\cdots A_{r,y_{r-t}}\beta.
\]

则

\[
 f(xy)=L_t(x)R_t(y),
\tag{461.2}
\]

故任意 middle-cut matrix 的秩至多 \(w_t\le s\)。这也是 tensor-train
representation 的 middle bond dimension 上界。

## 定理 461.1（位置相关 ABP 的 equality-width lower bound）

存在固定 deterministic local machine \(M_{\rm eq}\)，在 regular unary source
\(1^{2^{2k}}\) 上输出连续 block

\[
 B_k(x,y)=\mathbf 1[x=y],
 \qquad x,y\in\{0,1\}^k,
\tag{461.3}
\]

其 standard hist-first、cell-time、track-major tableau 具有固定-offset local
constraints、regular boundaries 与唯一 accepting assignment。设完整 assignment
table 在物理地址上有宽度 \(s\) 的 inhomogeneous ABP 表示，并设连续 output
block 的逻辑字符串 \(x\Vert y\) 到 physical address 有一个 \(u\)-state、
synchronous、cut-respecting regular address transducer；synchronous 指每个逻辑
地址符号产生固定长度的 physical-symbol 串，cut-respecting 指 transducer 读完
逻辑前缀 \(x\) 时已经产生一个 physical-address 前缀，后续输出不改写该前缀。
则

\[
 us\ge 2^k.
\tag{461.4}
\]

特别地，若 \(u=\operatorname{poly}(m_{\rm addr})\) 且
\(m_{\rm addr}=\Theta(k)\)，则

\[
 s=2^{\Omega(m_{\rm addr})}.
\tag{461.5}
\]

这里没有假设 \(A_{i,a}\) 对 \(i\) 齐次；只要 transducer 的状态复杂度被计入，
位置相关矩阵不能成为新的 address-scale 逃逸。

### 证明

把 physical assignment ABP 与从逻辑地址生成 physical address 的 transducer
有限状态一起作标准 product construction。把每个固定长度的 physical-symbol 串
展开到 ABP 的位置层，
不会增加超过其 \(u\) 个控制状态的乘法因子。由于 transducer cut-respecting，
读完对应逻辑前缀 \(x\) 时，product ABP 的中间接口只需记录原 ABP 的状态和
transducer 的状态，故其 middle width 至多 \(us\)。于是由 (461.2)，

\[
 \operatorname{rank}_F
 \bigl(B_k(x,y)\bigr)_{x,y\in\{0,1\}^k}
 \le us.
\tag{461.6}
\]

左侧矩阵是 \(I_{2^k}\)，在任意域 \(F\) 上秩为 \(2^k\)，得到 (461.4)。再用
\(m_{\rm addr}=\Theta(k)\) 得 (461.5)。证毕。

## 命题 461.2（inhomogeneous ABP 仍会产生 generic evaluator）

设 \(q|_{H^m}\) 有宽度 \(s\) 的 inhomogeneous ABP 表示

\[
 q(a_1,\ldots,a_m)
 =
 \alpha^{\top}A_{1,a_1}\cdots A_{m,a_m}\beta.
\tag{461.7}
\]

令 \(\ell_a\) 是 \(H\) 上的 Lagrange 基函数。其 individual-degree
 \(<|H|\) 延拓满足

\[
 q(z_1,\ldots,z_m)
 =
 \alpha^{\top}
 \prod_{i=1}^{m}
 \left(\sum_{a\in H}\ell_a(z_i)A_{i,a}\right)
 \beta.
\tag{461.8}
\]

若矩阵条目具有总长度
\(O(m|H|s^2\log|F|)\) 的显式或 address-scale 生成描述，则在
\(|H|,|F|=\operatorname{poly}(m)\) 时，generic point evaluation 只需
\(\operatorname{poly}(m,s,\log|F|)\) 次算术运算；位置相关性没有改变
grid-to-generic 的接口性质。

### 证明

将 tensor Lagrange identity

\[
 q(z)=\sum_{a\in H^m}q(a)\prod_i\ell_{a_i}(z_i)
\]

代入 (461.7)，再按坐标交换有限求和与矩阵乘积，得到 (461.8)。直接逐层矩阵
乘法给出所述多项式复杂度。证毕。

## 对 RW Closure 的直接后果

* C460 的 homogeneous 假设不再是表示模型的薄弱点；位置相关的
  ROABP、tensor-train 和 finite-width matrix-product solution representations
  也被定理 461.1 关闭。
* 若 actual C456 assignment 的此类表示宽度为
  \(s=\operatorname{poly}(m_{\rm addr})\)，命题 461.2 会产生 generic
  \(q_n\)-evaluator；在 C459 的 same-output projection 与 polylogarithmic
  field/address regime 下，这与
  \(\operatorname{CC}(B_n)=\Omega(N_n/\log N_n)\) 矛盾。
* 因而 factorized source 路线若要继续正攻，必须提供超出 bounded-cut
  matrix-product 模型的非线性 global relation，或明确支付一个
  \(2^{\Omega(m_{\rm addr})}\) 的 cut interface；把 \(A_a\) 改写为 \(A_{i,a}\)
  本身不够。

## 证据边界

* 该结果针对 bounded-cut-factorization 表示；一般 Boolean circuit 可以在
  \(O(k)\) 大小内计算 equality，故本定理不声称 equality 本身具有一般电路下界。
* cut-respecting regular address transducer 的状态数必须计入。若通过一个不规则
  的大规模重排把 \(x,y\) 交错，需把重排描述/控制成本计入；不计成本的重排属于
  model exit，而不是 free solution automaticity。若 address transducer 是
  asynchronous，但每个逻辑 cut 只可能落在 \(v=\operatorname{poly}(m_{\rm addr})\)
  个 physical layers，则 (461.4) 变为 \(vus\ge2^k\)，结论不变。
* 命题 461.2 需要矩阵条目的总描述也处于 address scale；把
  \(m|H|s^2\) 个 field symbols 作为未计价 ROM 会退回 C450 的 common-ROM/model-exit
  分支。定理 461.1 是表示类 impossibility，不是 actual C456 assignment 在所有
  模型下的无条件下界，也不单独证明 \(P\ne NP\)。

## 来源

* [C460 local-constraint/solution-automaticity separation](460-local-constraint-regularity-does-not-force-solution-automaticity-2026-08-19.md)。
* [C458 grid-to-generic exact-query lower bound](458-grid-to-generic-exact-query-lower-bound-2026-08-19.md)。
* [C459 published-RW generic-\(q\) forcing lower bound](459-published-rw-generic-q-access-forcing-scale-2026-08-19.md)。
