> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Hidden-witness Skolemization and the Closure Gate (2026-08-17)

## 结论地位

这是一个 relation-PCP / shared-proof 的条件性闭合定理。它不声称一般
hidden-witness compiler 不存在，也不直接推出 \(P\ne NP\)。它证明一个更窄但
可复用的事实：

> private witness 只有在同一个 witness（或同一个 finite summary）能在坐标揭示前
> 统一服务所有目标位时，才可能进入 JK 的 word-consistent 语义；一旦这个统一
> selector 存在，hidden witness 本身不再是对 RLDC/LDC barrier 的逃逸。

因此 Branch C 的真正新内容不能只是“把 witness 放到 proof 里”，而必须打破
下面的 Skolem-to-RLDC 闭合，或者证明它只在 address-scale / descriptor 成本下
成立。

## 模型

固定公开实例 \(x\)。令 \(\mathcal M_x\subseteq\{0,1\}^k\) 是目标词族。对每个
\(m\in\mathcal M_x\)，令 \(W_x(m)\) 是非空的 private-witness 集合。一个候选
relation compiler 给出同一物理地址空间上的 proof map

\[
  P_x(m,w)\in\Sigma^N,\qquad w\in W_x(m).
\]

对每个坐标 \(i\in[k]\) 和声明 \(b\in\{0,1\}\)，有同一个
target-independent verifier \(V_{x,i,b}\)。它可以自适应地查询 proof oracle，
但不能读取 \(m\)、\(w\) 或一个随 \((m,i,b)\) 改变的地址空间。写

\[
  p_{x,i,b}(z)=\Pr[V_{x,i,b}^{z}=1].
\]

这里的 target-independent 只排除 hidden target 选择 verifier；实例 \(x\)、坐标
\(i\) 和声明 \(b\) 仍然可以显式进入 verifier。

## 定理：global witness selector \(\Rightarrow\) RLDC

假设存在一个（不要求可计算的）global selector
\[
  s_x:\mathcal M_x\to\bigcup_m W_x(m)
\]
满足 \(s_x(m)\in W_x(m)\)，并令
\[
  C_x(m)=P_x(m,s_x(m)).
\]

设存在常数 \(\alpha>\beta\) 和 \(\rho\ge0\)，使得对所有
\(m\in\mathcal M_x\) 和 \(i\in[k]\)：

1. **同一 witness 的完备性**
   \[
     p_{x,i,m_i}(C_x(m))\ge\alpha;
   \tag{213.1}
   \]
2. **target-relative wrong-claim soundness**
   \[
     \operatorname{dist}(z,C_x(m))\le\rho
     \Longrightarrow
     p_{x,i,1-m_i}(z)\le\beta.
   \tag{213.2}
   \]

则：

* \(C_x:\mathcal M_x\to\Sigma^N\) 是单射，且
  \[
    \operatorname{dist}(C_x(m),C_x(m'))>\rho
    \qquad(m\ne m');
  \tag{213.3}
  \]
* 直接运行 \(V_{x,i,0}\) 和 \(V_{x,i,1}\)，再做常数次独立重复与阈值化，
  得到一个 \(O(q(\alpha-\beta)^{-2})\)-query、半径 \(\rho\) 的 weak RLDC，
  其 message family 是 \(\mathcal M_x\)；
* 若 \(\Sigma\) 是固定有限字母表、查询数和 \(\alpha-\beta,\rho\) 为常数，
  则任何适用的固定参数 RLDC 长度下界都直接作用于 \(N\)。特别地，二元
  一查询 proof verifier 可经 message-inline 变成二查询 binary RLDC，进入
  现有二查询指数下界窗口。

### 证明

先取 \(m\ne m'\)，并选坐标 \(i\) 使 \(m_i\ne m'_i\)。若
\(\operatorname{dist}(C_x(m),C_x(m'))\le\rho\)，把
\(z=C_x(m')\) 代入 (213.2)，得到
\[
  p_{x,i,m'_i}(C_x(m'))\le\beta.
\]
但 (213.1) 对 \(m'\) 给出同一概率至少为 \(\alpha\)，矛盾。因此 (213.3) 成立，
从而 \(C_x\) 单射。

对请求坐标 \(i\)，独立估计两个声明分支的接受率；输出唯一超过阈值
\(\theta\in(\beta,\alpha)\) 的 bit，否则输出 \(\bot\)。在 \(C_x(m)\) 上，正确
分支均值至少 \(\alpha\)，错误分支至多 \(\beta\)。若输入词在
\(C_x(m)\) 的 \(\rho\)-邻域内，错误分支仍由 (213.2) 至多为 \(\beta\)，而
正确分支即使任意也不会让 decoder 输出错误 bit。Chernoff/Hoeffding 放大给出
常数成功率和 stated locality。整个过程中 proof 地址空间始终是同一个
\([N]\)。证毕。

## 关键量词：为什么 \(\exists w\,\forall i\) 是 Closure Gate

上一定理的 selector 不是技术性写法，而是 JK 所需的 word-consistency 量词：

\[
  \exists w_m\ \forall i\; \text{the same }P_x(m,w_m)
  \text{ answers coordinate }i.
\tag{213.4}
\]

若候选 compiler 只给
\[
  \forall i\ \exists w_{m,i},
\tag{213.5}
\]
则不能构造 \(C_x(m)\)，也不能把不同坐标的局部答案串成一个 parent seed。

最小 phantom-witness 例子是合法全局词族
\(\{00,11\}\)。对声明 \(y=01\)，第一个坐标可由 witness \(00\) 支持，第二个
坐标可由 witness \(11\) 支持，所以 (213.5) 成立；但没有一个共同 witness 支持
整个 \(01\)。这不是 dPCP 的实现细节，而是量词交换
\(\forall i\exists w_i\not\Rightarrow\exists w\forall i\) 的直接反例。

因此，普通 relation-PCP 的“每个公开坐标存在一个 private witness”不能直接成为
RW/JK 的 smart query。必须先证明一个 global selector、一个同地址的 fixed
strategy，或一个能生成同一 selector 的短摘要。

## 有限 strategy summary 的第二个分支

若 compiler 没有 literal selector，而是在坐标揭示前提交一个有限摘要
\(S\in\{0,1\}^s\)，并且条件于同一个 \(S\)：

* 每个坐标使用固定的 target-independent policy；
* 错误声明对该摘要下的所有 policy 都 target-relative sound；
* 所有 policy 仍查询同一物理 proof 地址空间；

则不能把 \(S\) 当作“免费 hidden witness”。在高熵 message family 上，已有
strategy-inclusive entropy--core bound 给出
\[
 H(M)\le I(M;S)
 +N h_2\!\left(\frac{\mathbb E R}{N}\right)
 +\mathbb E R\log_2|\Sigma|,
\tag{213.6}
\]
其中 \(R\) 是所有 honest complete policies 的 shared proof support 联合大小。
当 \(H(M)=k\)、\(N=k^{O(1)}\)、\(I(M;S)\le\gamma k\) 时，
\[
  \mathbb E R=\Omega(k/\log k).
\tag{213.7}
\]

所以 hidden-witness route 只有三个严谨出口：

1. **global selector：** 直接进入定理 213.1 的 RLDC/LDC barrier；
2. **finite shared summary：** 支付 \(I(M;S)\) 或一个
   \(\Omega(k/\log k)\) 的共同 proof core；
3. **post-coordinate / unbounded strategy：** 保留 (213.5) 或任意地址相关响应，
   因而不再有 deterministic word/parent seed；这正是需要另证的交互式
   JK-closure 问题，而不是已完成的 relation-PCP。

若 verifier 为每个 \(m\) 改变 proof 地址空间、或直接看见完整目标 \(m\)，则上述
family-level RLDC 归约不适用；这两种改变本身就是 descriptor/address escape，
必须单独记账。

## 对 RW Closure Gate I 的直接含义

对 RW 的 private computation history，任意声称“隐藏 witness 后在
\(\operatorname{poly}(m,\log T)\) 地址尺度同时读取所有 output bits”的接口，
必须在上述三类中明确落点：

* 若存在一个固定 history/proof selector 对所有 output coordinates 有效，则
  它不再是 RLDC 逃逸；
* 若 selector 被一个 \(o(k)\)-bit common summary 驱动，则 (213.6)--(213.7) 计入
  descriptor/core；
* 若每个 coordinate 重新选择 witness/strategy，则得到的是 phantom word，不能
 直接作为 JK parent；
* 若 summary 或 address map 长度达到 \(T_i\) 尺度，则回到 note 212 的
  object-scale branch，而非 succinct hidden-witness closure。

这把 Branch C 的最小可证伪接口压缩为：构造一个同时满足
\(\exists w\,\forall i\)、target-relative soundness、共同地址空间、近线性
proof 和 address-scale generation 的 relation-PCP；或者在一个明确包含
post-coordinate/unbounded strategy 的模型中证明新的编码/通信下界。仅仅把 witness
从 input word 挪进 proof，不会改变这个量词分类。

## 证据边界

定理 213.1 的证明是自足的，只有距离、阈值化和同一 proof 地址空间的量词。
其 RLDC 长度后果调用已有 fixed-parameter RLDC lower bounds；二查询 binary
特例可参照 Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu 的
[Exponential Lower Bounds for 2-query RLDCs](https://arxiv.org/abs/2602.20278)，
该论文明确证明二元 Hamming RLDC 的二查询指数长度下界。现有 GMWZ dPCP/udPCP
结果则只提供各自模型中的 list/unique-decoding 量词，并不自动提供 (213.4)、
target-relative near-oracle soundness 或 RW address-scale generation。

本 note 不把 hidden-witness selector theorem 冒称为一般 ACRR 不可能性，也不声称
现有 RW/GMWZ 已满足其假设；它的作用是把“隐藏 witness”从模糊的正向希望变成一个
严格的 Closure Gate。
