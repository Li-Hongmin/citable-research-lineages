> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定 decoder 的短电路 nonmembership 边界（2026-08-15）

## 问题

固定一个 decoder family

\[
G_q:\{0,1\}^{q}\longrightarrow\{0,1\}^{2q},
\qquad q=2^{m-1},
\]

是否总能在 \(\operatorname{poly}(m)\) 描述长度内构造

\[
H_m:\{0,1\}^{m}\to\{0,1\},
\qquad
\operatorname{TT}(H_m)\notin\operatorname{Range}(G_q)?
\tag{1}
\]

这里 \(G_q\) 必须视为固定 family；不能把 note 109 中随 QBF 或随
random-access 输入变化的 \(G\) 结果外推到本问题。

## 严格的负面结论：固定 decoder 可以覆盖所有短电路

令 \(p:\mathbb N\to\mathbb N\) 是任意固定多项式。记
\(\mathcal C_{m,p}\) 为至多 \(p(m)\) 个 fan-in-two gates、\(m\) 个输入的
规范化 Boolean circuits，令

\[
D_{m,p}=|\mathcal C_{m,p}|.
\]

固定一套有限完备基、拓扑门序和 source-address 约定后，标准门表编码给出

\[
\log_2D_{m,p}
\le c\,p(m)\log\bigl(p(m)+m+2\bigr).
\tag{2}
\]

同一编码可取一个显式语法长度

\[
\ell_{m,p}=O\!\left(p(m)\log\bigl(p(m)+m+2\bigr)\right)
\]

使每个 \(C\in\mathcal C_{m,p}\) 都有一个至多 \(\ell_{m,p}\) 位的合法
gate-list description；取常数使 \(\ell_{m,p}\le q\)（对足够大的 \(m\)）。
将该 description 放入前 \(\ell_{m,p}\) 个 seed 位，其余
\(q-\ell_{m,p}\) 位补零。定义固定的
enumerator decoder \(G^{[p]}_q\)：

\[
G^{[p]}_q(w)
=
\operatorname{TT}\bigl(C_w\bigr)
\quad\text{若 \(w\) 编码 \(C_w\in\mathcal C_{m,p}\)，}
\tag{3}
\]

而 invalid description 映射到 \(0^{2q}\)。于是

\[
\boxed{
\forall H_m\ \bigl(|H_m|\le p(m)\bigr),\qquad
\operatorname{TT}(H_m)\in\operatorname{Range}(G^{[p]}_q)
}
\tag{4}
\]

（有限个小 \(m\) 可用固定 padding 处理）。因此对这个固定 decoder family，
任何 size-\(p(m)\) 的短电路都不能作为式 (1) 的 outsider。

### 电路大小与统一性

令 \(U_{m,p}(w,u)\) 是标准 universal evaluator：输入为 circuit description
\(w\) 与 \(m\)-bit address \(u\)，输出 \(C_w(u)\)。逐 gate 模拟和
address multiplexer 给出

\[
|U_{m,p}|=\operatorname{poly}\bigl(p(m),m\bigr).
\]

对所有 \(u\in\{0,1\}^m\) 复制一个 \(U_{m,p}(\,\cdot\,,u)\)，便得到
\(2^m=2q\) 个输出 wires。因此

\[
|G^{[p]}_q|
\le 2q\cdot\operatorname{poly}\bigl(p(m),m\bigr).
\tag{5}
\]

若 \(p(m)=m^k\)，式 (5) 是

\[
q\cdot(\log q)^{O(k)},
\]

即固定 \(k\) 下的 near-linear \(q\,\operatorname{polylog}q\) decoder。该构造
可由 \(m\) 统一展开为电路；它没有使用可变的 QBF、输入 \(F\) 或 note 109
的 group search。

更强地，取

\[
p_\star(m)=m^{\lceil\log m\rceil}.
\]

则 \(p_\star(m)\) 超过每个固定多项式 \(m^k\)（对足够大的 \(m\)），而
\[
\log D_{m,p_\star}
=m^{O(\log m)}
=2^{o(m)}
\ll q.
\]
对应的显式语法长度 \(\ell_{m,p_\star}\) 也为 \(2^{o(m)}\)，所以同样可
零填充到 \(q\) 位。

同一 enumerator construction 覆盖所有固定多项式大小的 \(H_m\)，且

\[
|G^{[p_\star]}_q|
=q\cdot 2^{o(m)}
=q^{1+o(1)}.
\tag{6}
\]

所以即使把 decoder 语法放宽到 \(q^{1+o(1)}\)，也不能通过“对任意
\(\operatorname{poly}(m)\) 电路做统一对角化”得到式 (1)；一个固定 decoder
可以预先覆盖所有这些电路的 truth tables。

## 这不是一般 circuit lower bound

式 (4)--(6) 是一个存在性反例，结论只对指定的 enumerator decoder family
成立。它不证明每个固定 \(G_q\) 都覆盖短电路，也不排除某个给定 decoder
具有可计算的代数 invariant。确切的量词是：

\[
\forall p\ \exists\text{ fixed }G^{[p]}:
\quad
\{\operatorname{TT}(H):|H|\le p(m)\}
\subseteq\operatorname{Range}(G^{[p]}_q).
\tag{7}
\]

因此不存在一个对所有 fixed decoder 都有效的、仅以
\(\operatorname{poly}(m)\) 大小为保证的 outsider theorem。若要对某个具体
decoder 建立式 (1)，必须使用其额外结构，而不能只用
\[
|\operatorname{Range}(G_q)|\le2^q<2^{2q}.
\]

## 对代数、graph-like 与 parity 路线的精确边界

### 一个真正可行的代数例子

对 systematic-zero decoder

\[
G_q(x)=x\Vert0^q,
\]

取常数一函数 \(H_m\equiv1\)。其 truth table 为 \(1^{2q}\)，最后 \(q\)
bits 非零，故不在 range；这是 \(O(1)\)-size 的式 (1) 构造。它说明
“固定 decoder”本身不排除短 outsider，排除的是无条件的统一保证。

### 线性 decoder 的 parity 条件

若 \(G_q\) 是 \(\mathbb F_2\)-线性映射，令
\[
R_q=\operatorname{Range}(G_q),\qquad
R_q^\perp=\{w\in\{0,1\}^{2q}:w\cdot z=0\ \forall z\in R_q\}.
\]

若能统一构造一个 \(w_m\in R_q^\perp\) 和一个地址
\(a_m\in\{0,1\}^{m}\) 使 \(w_m[a_m]=1\)，则令 \(H_m\) 为
address \(a_m\) 上的 point mass：

\[
H_m(u)=\mathbf 1[u=a_m].
\]

它有 \(O(m)\) 大小，并满足
\[
w_m\cdot\operatorname{TT}(H_m)=w_m[a_m]=1,
\]
从而 \(\operatorname{TT}(H_m)\notin R_q\)。但若 \(w_m\) 或其非零坐标
没有 \(\operatorname{poly}(m)\)-time 的统一描述，这个 parity 论证只是一条
存在性观察，不能产出 P-uniform \(H_m\)。随机线性 decoder 的 dual witness
一般没有已知短描述；不能把“余维为 \(q\)”误写成“有短 parity check”。

同样，graph-like decoder 只有在其 complement 含有一个可统一定位的短
forbidden pattern 时才能给出式 (1)。没有该 pattern 时，range 的稀疏性本身
只给出一个可能具有接近 \(q/\log q\) 电路复杂度的非像表，不给出
\(\operatorname{poly}(m)\) 电路。

## 容量、输出与 diagonalization 障碍

### 容量不够以推出短 outsider

长度 \(2q=2^m\) 的所有表共有 \(2^{2q}\) 个，而 range 至多 \(2^q\) 个；
但 size-\(p(m)\) 电路的 truth tables 数量只有
\[
2^{O(p(m)\log(p(m)+m+2))}=2^{\operatorname{poly}(m)}.
\tag{8}
\]

式 (8) 远小于 \(2^q=2^{2^{m-1}}\)，所以一个固定 range 完全可以覆盖所有
短电路表；不能用全空间的 pigeonhole 直接推出短 outsider。

### Lexicographic diagonalization 的时间尺度

对任意固定 \(G_q\)，逐字典序寻找第一个
\(z\notin\operatorname{Range}(G_q)\) 至多需要 \(2^{2q}\) 个候选及 range
queries。注意 range membership 是 NP，但“某个 prefix 仍有
non-range extension”已经包含一个外层存在与 range nonmembership 条件；
不能把它误写成普通 prefix-SAT。即便允许相应的
\(\Sigma_2^P\)/nonmembership oracle 做逐位定位，得到的也只是关于 \(q\) 的
\(\operatorname{poly}(q)\) 时间和一个显式 \(2q\)-bit 输出。由于
\(q=2^{m-1}\)，这既不是 \(\operatorname{poly}(m)\) 时间，也不能保证
输出的表有 \(\operatorname{poly}(m)\)-size circuit。

### 显式输出下界

如果要求算法直接返回 \(z\in\{0,1\}^{2q}\setminus R_q\)，写出输出本身就需
\(\Omega(2q)=\Omega(2^m)\) bit steps。把输出改成短 \(H_m\) 可以绕过写出成本，
但必须额外证明 \(H_m\) 的整张 truth table 非像；这正是式 (4) 的固定 enumerator
decoder 可以阻断的接口。

## 严格裁决

\[
\boxed{
\begin{array}{ll}
\text{任意 fixed }G_q\text{ 都有短 }H_m\text{：}&\text{错误；}\\
\text{某些 algebraic/graph-like }G_q\text{ 有短 }H_m\text{：}&\text{可由显式 invariant 证明；}\\
\text{仅凭 }|R_q|\le2^q\text{ 统一生成 poly}(m)\text{ outsider：}&\text{未知且被式 (4)--(6) 阻断。}
\end{array}}
\]

这条裁决不把可变 \(G\) 的 \(\mathrm{FP}^{\Sigma_2^P}\) 结果外推到固定 decoder，
也不宣称一般的 Boolean-circuit lower bound 或 \(P\ne NP\)。

### 来源与证据边界

- 式 (2)、(5)、(8) 是标准电路编码、universal evaluation 与计数推导；
- 式 (3)--(7) 是本项目对固定 enumerator decoder 的构造；
- systematic-zero 与 parity 小节是具体充分条件，不是任意 decoder 的结论；
- 本 note 不提供对候选 near-linear decoder 的最终 nonmembership 证明。
