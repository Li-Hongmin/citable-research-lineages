> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Sharp semantic entropy and canonical OBDD width (2026-08-25)

We use the standard single-output circuit model over the fixed basis
\(\{\mathsf{AND},\mathsf{OR},\mathsf{NOT}\}\), with fan-in at most two and unbounded
fan-out.  Write
\[
 \mathcal L_{m,s}
 =\{f:\{0,1\}^m\to\{0,1\}:\operatorname{CC}(f)\le s\},
 \qquad
 a_m(s)=\log_2|\mathcal L_{m,s}|.
\]

This note corrects the unresolved-leading-constant conclusion in
[Proposition 43 of note 531](531-selector-lift-and-multiblock-equality-boundary-2026-08-24.md).
The missing comparison is settled by a canonical tree--pin encoding and a packed-selector
Lupanov family.  The resulting canonical-order OBDD bound is unconditional, but it is not an
arbitrary-order OBDD, general branching-program, or one-tape lower bound by itself.
[Note 534](534-balanced-cut-fourier-quotients-and-arbitrary-order-obdd-width-2026-08-25.md)
subsequently adds a balanced-cut Fourier quotient and upgrades the conclusion to every OBDD
variable order.  [Note 536](536-identity-submatrices-and-ordered-nondeterministic-algebraic-width-2026-08-25.md)
extracts an identity submatrix from the same witness and further upgrades the fixed-order result
to strictly layered nondeterministic, parity, and exact field-weighted programs.

## Proposition 43 (tree--pin circuit enumeration)

For all \(m,s\ge2\),
\[
 \boxed{
 a_m(s)
 \le
 (s+1)\log_2(m+s+2)+O(s).
 }
 \tag{533.1}
\]
In particular, if \(s\ge m^2\), then
\[
 a_m(s)\le s\log_2s+O(s).
 \tag{533.2}
\]

### Proof

Fix a circuit with \(q\ge1\) gates and delete every gate that does not reach the unique output.
Every non-output gate then feeds at least one input-pin occurrence of another gate.  Choose one
such consumer pin for each non-output gate.  The chosen \(q-1\) incidences form a rooted tree on
the gates, oriented toward the output: acyclicity forces every chosen path to terminate at the
unique gate with no chosen consumer, namely the output.  Mark the two input slots of a binary
gate as left and right.  The chosen incidences are therefore a rooted plane binary slot-tree,
of which there are fewer than \(4^q\).

If the circuit has \(b\) binary gates and \(u\) unary gates, then \(b+u=q\) and it has
\(2b+u\) actual input pins.  The tree occupies \(q-1\) pins, leaving
\[
 (2b+u)-(q-1)=b+1\le q+1
\]
free pins.  The tree paths canonically name all gates.  After recording the gate type at each
node, each free pin has at most \(m+q+2\) possible sources: an input, a tree node, or, if allowed,
one of two constants.  Hence the number of codes for \(q\)-gate circuits is at most
\[
 4^q3^q(m+q+2)^{q+1}
 \le 12^q(m+q+2)^{q+1}.
 \tag{533.3}
\]
The decoding is unique: the plane tree recovers the gates and tree pins, while the source list
recovers every remaining pin.  Invalid cyclic codes only overcount.  Arbitrary fan-out and
parallel wires are represented by repeated gate addresses.  A circuit may admit several tree
choices, but this again only overcounts.

Summing (533.3) over \(0\le q\le s\) gives
\[
 |\mathcal L_{m,s}|
 \le m+2+\sum_{q=1}^s12^q(m+q+2)^{q+1},
\]
which implies (533.1).  If \(s\ge m^2\), then
\[
 (s+1)\log_2(m+s+2)=s\log_2s+O(s),
\]
proving (533.2). \(\square\)

The proof does not divide every gate-list class by \(q!\); such a division would be invalid for
a chain, which has a unique topological order.  The tree records the \(q-1\) forced incidences
instead, leaving only \(q+1\) free pins and therefore the sharp leading coefficient one.

## Proposition 44 (packed-selector semantic lower bound)

There is a constant \(C\) such that, whenever
\[
 m\ge \log_2s+\log_2\log_2s+C,
 \tag{533.4}
\]
one has
\[
 \boxed{
 a_m(s)
 \ge
 s\log_2s-O(s\log_2\log_2s).
 }
 \tag{533.5}
\]
Consequently, throughout the regime (533.4) and \(s\ge m^2\),
\[
 a_m(s)=(1+o(1))s\log_2s.
 \tag{533.6}
\]

### Proof

Put \(L=\log_2s\) and
\[
 q=\left\lfloor L-3\log_2L\right\rfloor.
\]
Lupanov's uniform upper bound gives a number
\[
 U_q=\left(1+O\!\left(\frac{\log q}{q}\right)\right)\frac{2^q}{q}+O(1)
 \tag{533.7}
\]
such that every \(q\)-variable Boolean function has a circuit with at most \(U_q\) gates.
Let
\[
 k=\left\lfloor\frac{s}{U_q+7}\right\rfloor,
 \qquad
 t=\lceil\log_2k\rceil.
 \tag{533.8}
\]

For each tuple \((f_1,\ldots,f_k)\) of arbitrary \(q\)-variable functions, use \(t\) address
bits to select one component.  Complete the selector tree to \(2^t\) leaves, reusing \(f_1\)
at unused addresses.  After sharing one negation of each address bit, a binary multiplexer tree
uses at most
\[
 3(2^t-1)+t\le7k
\]
additional gates.  The resulting function therefore has a circuit of size at most \(s\).
Restriction to the address of leaf \(i\) recovers \(f_i\), so the tuple-to-function map is
injective.  Thus the resulting family \(H\) satisfies
\[
 \log_2|H|=k2^q.
 \tag{533.9}
\]
Since \(2^q=\Theta(s/L^3)\), equations (533.7)--(533.9) yield
\[
 k2^q
 \ge
 \frac{s q}{1+O(\log q/q)+O(q/2^q)}-2^q
 =sL-O(s\log L).
 \tag{533.10}
\]
Moreover,
\[
 k=\Theta(L^4),
 \qquad
 t=4\log_2L+O(1),
 \qquad
 q+t=L+\log_2L+O(1).
 \tag{533.11}
\]
Hence (533.4) supplies all variables needed by the construction, and (533.10) proves
(533.5). \(\square\)

For \(S=\lfloor2^{\mu n}\rfloor\), fixed \(0<\mu<1\), and every fixed constant \(C_0\),
the same estimates give the explicit correction to note 531:
\[
 \Delta_n(S)
 :=2a_{n-1}(S-C_0)-a_n(S)
 \ge S\log_2S-O(S\log_2\log_2S).
 \tag{533.12}
\]

## Theorem 45 (tight canonical-order OBDD width for exponential-threshold MCSP)

Fix \(0<\mu<1\), put \(N=2^n\), and let \(S=\lfloor2^{\mu n}\rfloor\).  Read an
\(n\)-variable truth table in lexicographic order, and let
\(W^{\mathrm{lex}}_{N/2}(\mathrm{MCSP}_S)\) denote the deterministic OBDD width immediately
after the first \(N/2\) table bits.  Then
\[
 \boxed{
 \log_2 W^{\mathrm{lex}}_{N/2}(\mathrm{MCSP}_S)
 =(1+o(1))S\log_2S.
 }
 \tag{533.13}
\]
The minimum size of a lexicographic-order OBDD for \(\mathrm{MCSP}_S\) has the same logarithmic
asymptotic.

### Proof

The family in Proposition 44 uses
\[
 r=\log_2S+\log_2\log_2S+O(1)=\mu n+O(\log n)<n-1
\]
variables.  Embed it by dummy variables into each \((n-1)\)-variable half-table.  For every
\(h\in H\), the diagonal table \(h\Vert h\) ignores the leading selector variable and hence
belongs to \(\mathrm{MCSP}_S\).  Proposition 38's equality graph gives
\[
 W^{\mathrm{lex}}_{N/2}(\mathrm{MCSP}_S)
 \ge
 \frac{|H|^2}{2|\mathcal L_{n,S}|+|H|}.
 \tag{533.14}
\]
Here \(S\ge n^2\), so Propositions 43--44 imply
\[
 \log_2|H|\ge S\log_2S-O(S\log\log S),
 \qquad
 \log_2|\mathcal L_{n,S}|\le S\log_2S+O(S).
\]
Taking logarithms in (533.14) proves the lower bound in (533.13).

For the reverse inequality, a prefix trie for the finite set \(\mathcal L_{n,S}\) has at most
\(|\mathcal L_{n,S}|\) live states and one dead state at every layer.  Therefore
\[
 W^{\mathrm{lex}}_{N/2}(\mathrm{MCSP}_S)
 \le |\mathcal L_{n,S}|+1
 \le 2^{S\log_2S+O(S)}.
 \tag{533.15}
\]
The same trie has at most \(N(|\mathcal L_{n,S}|+1)\) nodes, and the lower bound on one layer
also lower-bounds total OBDD size. \(\square\)

## Boundary and literature comparison

Theorem 45 is the sharp lower bound for one prescribed truth-table order.  Note 534 supplies the
additional argument needed for an arbitrary permutation of the \(N\) table coordinates, and
note 536 upgrades the common fixed-order witness to strictly layered nondeterministic, parity,
and exact field-weighted programs.  None of these results bounds free or path-dependent read-once
programs, general branching programs, or one-tape computation.  In particular they neither
improve the CHMY one-tape exponent nor prove the MMW magnification hypothesis.
[Note 539](539-canonical-identity-witness-is-online-cheap-2026-08-25.md) makes the MMW boundary
explicit: the packed tuple index can itself be stored online with \(O(S\log S)\) space and
\(O(n)\) update, so the identity witness alone does not charge transition complexity.

CHMY already obtained exponential read-once branching-program consequences from local HSGs, so
Theorem 45 is not the first exponential OBDD lower bound for MCSP.  Glinskih--Riazanov prove
\(N^{\Omega(\log\log N)}\) for the stronger read-once nondeterministic model and a tight
\(N^{\Theta(\log\log N)}\) bound at the linear threshold.  The author-dissertation version
explicitly leaves stronger bounds at exponentially large thresholds open.  The new point here is
the asymptotically tight \(S\log S\) exponent for deterministic lexicographic-order width.

## Dependencies

- [Proposition 38](529-middle-cut-equality-gadget-residual-boundary-2026-08-24.md)
- [Propositions 41--43, corrected here](531-selector-lift-and-multiblock-equality-boundary-2026-08-24.md)
- Jukna, *Boolean Function Complexity*, Lemma 1.12 and Theorem 1.15
- Cheraghchi--Hirahara--Myrisiotis--Yoshida, STACS 2021
- Glinskih--Riazanov, LATIN 2022; Glinskih's 2024 dissertation, Chapter 3
