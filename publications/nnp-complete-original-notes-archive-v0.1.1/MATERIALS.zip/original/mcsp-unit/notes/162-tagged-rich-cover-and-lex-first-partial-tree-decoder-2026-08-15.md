> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Tagged rich-cover 与 lex-first partial-tree decoder（2026-08-15）

## 结论

一个很大的 rich range subfamily 的熵可以很大，同时同一个 near-linear decoder 仍可对一族高度耦合的
actual trees 提供 lex-first、整词一致的 partial labeler。因而 pair/tree capacity 真正限制的是
**实际支持的 leaf tuples 数量**，不是被覆盖集合本身的大小。

具体地，令

\[
2q=2^m,
\qquad
h\ge 1,
\qquad
\lambda=\lceil\log_2(h+1)\rceil,
\tag{1}
\]

并取整数 \(r\ge0\) 满足

\[
1+\lambda+r+h+2\le q.
\tag{2}
\]

则存在一个固定 decoder

\[
G_q:\{0,1\}^q\longrightarrow\{0,1\}^{2q}
\tag{3}
\]

具有以下性质。这里对每个满足式 (2) 的固定 \((h,r)\) 分别构造 decoder；记号中省略这两个
schedule 参数，但 decoder 不依赖后面选择的 \(x\)：

1. \(|G_q|=O(q\log q)\)；
2. \(G_q\) 不是 affine map，也不存在 fixed systematic projection；
3. \(G_q\) 的 range 包含一个大小为 \(2^{q-1}\) 的自然 truth-table class；
4. 对每个 \(x\in\{0,1\}^r\)，同一个 \(G_q\) 对一棵深度 \(h\) 的完整二叉树提供
   lex-first canonical labels；
5. 这些 trees 只给出 \(2^r\) 个由共同 \(x\) 耦合的 leaf tuples，不给出 rich covered class 的
   任意 leaf 组合。

所以这个构造明确反驳（注意这里只使用一个 rich subfamily，而不是全部 MCSP coverage）

\[
\text{large ambient coverage}
\Longrightarrow
\text{actual-history partial labeler 不可能}
\tag{4}
\]

这一推断；它不反驳 universal pair/tree capacity，也不说明 RW history 具有所需标签结构。

## Rich-cover mode

对 \(z\in\{0,1\}^{q-1}\)，记

\[
d(z)=0\Vert z\in\{0,1\}^{q}.
\tag{5}
\]

定义

\[
\mathcal A_q
=
\{d(z)\Vert d(z):z\in\{0,1\}^{q-1}\}.
\tag{6}
\]

若把长度 \(2q=2^m\) 的字符串按最高位地址切成两个相邻半表，则 \(\mathcal A_q\) 正是：

- 忽略该地址变量；并且
- 在全零地址上取值为零

的所有 \(m\)-variable truth tables。因此

\[
|\mathcal A_q|=2^{q-1}.
\tag{7}
\]

把 seed 的第一位作为 mode tag。对 tag-one seeds 定义

\[
G_q(1\Vert z)=d(z)\Vert d(z).
\tag{8}
\]

于是

\[
\mathcal A_q\subseteq\operatorname{Range}(G_q).
\tag{9}
\]

特别地，rich covered family 已远大于一层 universal pair closure 所允许的
\(2^{q/2}\) 边界；下面的 partial closure 因而不可能被误解成 \(\mathcal A_q^2\) 的全覆盖。

## Tree-label mode

令

\[
b=q-1-\lambda-r-h,
\tag{10}
\]

由式 (2) 有 \(b\ge2\)。一个 canonical tree label 使用 tag zero，编码为

\[
L(x,v,j)
=
0\Vert\operatorname{bin}_{\lambda}(j)
\Vert x
\Vert v0^{h-j}
\Vert0^b,
\tag{11}
\]

其中

\[
x\in\{0,1\}^r,
\qquad
0\le j\le h,
\qquad
v\in\{0,1\}^{j}.
\]

对 internal labels，定义

\[
G_q(L(x,v,j))
=
L(x,v0,j+1)\Vert L(x,v1,j+1),
\qquad j<h.
\tag{12}
\]

对 leaf labels \(v\in\{0,1\}^h\)，令

\[
e(x,v)
=
0\Vert x\Vert v\Vert0^{q-1-r-h}
\in\{0,1\}^{q},
\tag{13}
\]

并定义

\[
G_q(L(x,v,h))
=
e(x,v)\Vert e(x,v).
\tag{14}
\]

式 (14) 的每个 leaf block 都属于 \(\mathcal A_q\)。对任意固定 \(x\)，从这些 leaves
向上应用式 (12)，得到一棵深度 \(h\) 的整词一致 witness tree。也就是说，若

\[
T_x
=
\bigl(e(x,v)\Vert e(x,v)\bigr)_{v\in\{0,1\}^h},
\tag{15}
\]

则 \(T_x\) 可沿同一个 \(G_q\) 逐层保持在 range 中。

## Lex-first canonical 性

还需排除 tag-zero 的非法 encodings。对任何不是式 (11) 的 tag-zero seed，把输出定义为首位为
一的 dummy string。为保证非线性，可令某个固定 output coordinate 等于两个 padding bits
\(a,b\) 的 AND，例如

\[
G_q(u)=1\Vert(a\land b)\Vert0^{2q-2}
\tag{16}
\]

在相应非法分支上；其他非法 encodings 可使用同一 totalization。存在一个非法 subcube：固定
\(j=0\) 却令 path 的第一位为一，并让两个 padding bits 自由变化，所以式 (16) 确实在一个
二维 subcube 上计算 AND。

现在固定任一 actual-tree target。

- 非法 tag-zero seeds 的输出首位为一，而式 (12)、(14) 的输出首位均为零，因此不会碰撞；
- 不同 leaf labels 由式 (13) 给出不同 outputs；
- internal output 的左右两半是不同的 child labels，所以不会等于左右两半相同的 leaf output；
- 一对 child labels 唯一确定 \((x,v,j)\)，所以不同 internal labels 的 outputs 也不同。

故每个 actual-tree target 都有唯一的 canonical tag-zero preimage。leaf target 还在
rich-cover mode 中有一个 tag-one preimage，但所有 tag-zero strings 在字典序上都早于 tag-one
strings。因此

\[
\boxed{
L(x,v,j)\text{ 是相应 actual-tree target 的 lex-first preimage}.
}
\tag{17}
\]

于是从 leaves 开始逐层选择 lex-first preimages，历史不会离开式 (11) 的 canonical labels。
这比“存在某组指定 preimages”更强，但仍只对式 (15) 的 synthetic tree family 成立。

## 非线性与非 systematic 性

若 \(G_q\) 是 affine map，则把任一 output coordinate 限制到一个输入 subcube 后仍应 affine。
式 (16) 在上述非法 subcube 上给出 \(a\land b\)，矛盾。因此 \(G_q\) 非 affine。

同时，三个不同的 padding assignments

\[
(a,b)\in\{(0,0),(0,1),(1,0)\}
\]

在该非法 subcube 上产生相同 output，故 \(G_q\) 不是 injective。若存在固定
\(J\subseteq[2q]\)、\(|J|=q\)，使

\[
G_q(u)|_J=u
\qquad\text{对所有 }u\in\{0,1\}^q,
\tag{18}
\]

则 \(G_q\) 必须 injective，与上述 collision 矛盾。所以该 decoder 不是 fixed-projection
systematic decoder。

## Circuit size

Rich-cover mode 只需 wiring。Tree mode 需要：

1. 比较 \(j\) 与 \(0,\ldots,h\)；
2. 检查 path 在第 \(j\) 位之后是否全零；
3. 在第 \(j+1\) 个 path coordinate 写入 child bit；
4. 在 internal、leaf 与 invalid outputs 间选择。

用 fan-in-two Boolean circuits，逐 coordinate 的 \(O(\log h)\)-bit compare 和 multiplexer 给出

\[
|G_q|=O(q\log h+q)=O(q\log q).
\tag{19}
\]

因此这是一个真正的 near-linear nonlinear decoder family，而不是把 tree 数据逐节点硬接进
\(G_q\)。这里的 partial labeler 只说明存在并给出这些 \(q\)-bit labels；若把 \(x,v,j\)
作为地址做随机访问，其普通 fan-in-two 电路成本仍需单独计量。本构造不声称得到
\(\operatorname{poly}(m)\)-size labeler；若要讨论该尺度，应另加
\(r,h=\operatorname{poly}(m)\) 及地址编码假设。

## 容量只约束实际 tuple family

一般地，令

\[
\mathcal T\subseteq \mathcal A^{2^h}
\tag{20}
\]

是某个 decoder 实际支持、且其 whole-tree witness **由 root block 递归决定** 的 leaf tuple 集。
把每个 tuple 映到其 root block；root block 相同会逐层强制全部 child seeds 相同，最终强制所有
leaf blocks 相同。所以这个映射 injective，并且只有

\[
|\mathcal T|\le2^q.
\tag{21}
\]

只有额外知道 \(\mathcal T=\mathcal A^{2^h}\) 时，式 (21) 才变成

\[
|\mathcal A|^{2^h}\le2^q.
\tag{22}
\]

在当前构造中，支持的 tuples 是

\[
\mathcal T=\{T_x:x\in\{0,1\}^r\},
\qquad
|\mathcal T|=2^r,
\tag{23}
\]

而不是 \(\mathcal A_q^{2^h}\)。所有 leaves 共享同一个 \(x\)，这是实质性的全局耦合。跨全部
\(x\) 与 tree positions 的 actual nodes 只有

\[
O(2^{r+h}),
\tag{24}
\]

由式 (2) 严格低于 seed capacity。故

\[
|\mathcal A_q|=2^{q-1}
\]

与 lex-first partial-tree closure 完全可以同时成立。

## 一般 tagged-union 推论

式 (8) 还可替换成任意（不要求覆盖全部 MCSP slice 的）

\[
H_q:\{0,1\}^{q-1}\to\{0,1\}^{2q}
\tag{25}
\]

而保留 tag-zero tree mode；这里的 coverage 仍只指所选 rich subfamily。所得 decoder 大小为

\[
|H_q|+O(q\log q),
\tag{26}
\]

并覆盖 \(\operatorname{Range}(H_q)\)。因此 OBDD、sparse ANF 或其他 near-linear
decompressor 可以和 partial tree labeler 直接作 tagged union，只损失一个 description bit。
这进一步说明，rich-subfamily coverage 与 actual-history closure 在没有 tuple-richness 假设时是近乎正交的
资源。

## 对当前路线的边界

本构造改变的是一个否定性决策：不能再试图仅从

\[
\text{coverage class 很大}
\quad\text{或}\quad
\text{range entropy 接近 }q
\]

推出 actual-history partial labeler 不存在。要应用 pair/tree capacity，必须证明实际 history 的
tuple family 具有足够多的独立组合，而不仅是 leaves 各自来自一个大集合。

本构造没有证明 RW encoded history 的 blocks 可写成式 (13)，也没有构造 RW leaf evaluator，
更没有证明其 leaves 共享一个短 \(x\) 后就只剩地址 \(v\)。因此不能把式 (17) 外推为 RW/JK
实例已有 lex-first labeler，也不产生电路下界或 \(P\ne NP\)。

相关边界：

- [note 105](105-jk-pair-lift-capacity-and-pair-rich-prefix-2026-08-15.md)：一层 pair-rich capacity；
- [note 106](106-multilevel-jk-tree-capacity-obstruction-2026-08-15.md)：多层 universal tree capacity；
- [note 123](123-history-indexed-closure-decoder-template-2026-08-15.md)：history-indexed 正向模板；
- [note 137](137-finite-depth-tree-closed-decoder-saturates-capacity-2026-08-15.md)：有限深度全 tuple
  closure 的容量紧构造。

式 (5)--(26) 是本项目的自足构造与计数；没有使用新的外部文献主张。
