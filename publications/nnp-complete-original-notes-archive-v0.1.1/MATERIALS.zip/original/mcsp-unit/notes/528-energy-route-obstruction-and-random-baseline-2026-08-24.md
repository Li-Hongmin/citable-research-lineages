> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Energy-route obstruction and random-shift baseline (2026-08-24)

## Proposition 36

For a proper nonempty \(A\subsetneq\mathbb F_2^N\), write
\[
 m_A(r):=|A\cap(A\oplus r)|.
\]
Uniformly sampling \(r\) from \(A^c\) gives
\[
 \mathbb E_{r\in A^c}m_A(r)
 \le \frac{|A|^2}{2^N-|A|}.
 \tag{528.1}
\]
Consequently, for \(1\le t\le|A^c|\) and \(R\) consisting of \(t\) shifts sampled uniformly
without replacement from \(A^c\),
\[
 \mathbb E\!\left[\frac{E_A(R)}{t|A|}\right]
 \le \frac{|A|}{2^N-|A|},
 \qquad
 \Pr\!\left[\frac{E_A(R)}{t|A|}\ge\delta\right]
 \le \frac{|A|}{\delta(2^N-|A|)}.
 \tag{528.2}
\]

The proof is the identity
\[
\sum_{r\in\mathbb F_2^N}m_A(r)=|A|^2
\]
followed by deletion of the nonnegative \(r\in A\) terms and Markov's inequality. This gives an
exponentially small energy baseline for genuinely random NO shifts, but it does not control an
adversarial or efficiently generated residual family.

## Proposition 37 (stabilizer-free generic obstruction)

There are arbitrarily large finite-dimensional sets \(A\subseteq\mathbb F_2^N\) with trivial
stabilizer and arbitrarily large entropy, together with a non-affine family
\(R'\subseteq A^c\), \(|R'|\le|A|\), for which
\[
 \frac{E_A(R')}{|A|\,|R'|}\longrightarrow\frac23.
 \tag{528.3}
\]

### Construction and proof

Let \(K\ne\{0\}\) be a subspace, let \(a,b\) be independent in \(\mathbb F_2^2\), and put
\(c=a+b\). Work in
\[
 G=(\mathbb F_2^2\times K)\times\mathbb F_2.
\]
Choose a point \(p\in\mathbb F_2^2\times K\), and define
\[
 A=\bigl(((\{0,a,b\}\times K)\times\{0\})\bigr)
 \cup\{(p,1)\},
 \qquad
 R=(\{c\}\times K)\times\{0\},
 \qquad
 R'=R\setminus\{(c+k_0,0)\}
 \quad(k_0\in K).
\]
Then \(R'\cap A=\varnothing\), \(|R'|=|K|-1\), and \(|A|=3|K|+1\). For every
\(r\in R'\), the two cosets \((a+K)\times\{0\}\) and \((b+K)\times\{0\}\) are mapped into
one another, while the \(0+K\) coset and the marker are mapped outside \(A\). Hence
\[
 m_A(r)=2|K|,
 \qquad
 \frac{E_A(R')}{|A|\,|R'|}
 =\frac{2|K|}{3|K|+1}\to\frac23.
\]
The stabilizer is trivial: a shift with last coordinate \(1\) sends the three \(K\)-cosets to a
slice containing only one point of \(A\), while a shift with last coordinate \(0\) must fix the
singleton marker and is therefore zero.

## Boundary for MCSP

Propositions 36--37 isolate the exact status of the energy route:

* random NO shifts have exponentially small energy by counting alone;
* adversarial non-affine, stabilizer-free, high-entropy families need not have small energy;
* the missing statement is therefore genuinely MCSP-specific, not a generic additive-combinatorics
  consequence.

The construction in Proposition 37 is not an MCSP counterexample. Embedding its three-coset
pattern into the full \(\mathrm{MCSP}_S\) set would require a new circuit lower bound ensuring that
the fourth coset is outside \(\mathrm{MCSP}_S\). No such embedding is claimed here.

## Dependencies

- [Proposition 35](527-restricted-additive-energy-cross-combination-boundary-2026-08-24.md)
- [Proposition 6](../papers/02-truth-table-quotients-do-not-close-one-tape-mcsp-magnification/paper.md)
