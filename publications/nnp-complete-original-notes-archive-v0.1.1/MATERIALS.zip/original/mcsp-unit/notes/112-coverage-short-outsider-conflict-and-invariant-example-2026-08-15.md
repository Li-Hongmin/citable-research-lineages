> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Coverage 与短 outsider 的硬冲突；结构化 invariant 的对照例（2026-08-15）

## 结论

令 \(q=2^{m-1}\)、\(N=2q=2^m\)，以及
\(G_q:\{0,1\}^{q}\to\{0,1\}^{N}\)。
若 decoder coverage 满足

\[
\mathcal C_{m,s_m}
=
\{TT(C):C\text{ 是 }m\text{-input、size}\le s_m\}
\subseteq\operatorname{Range}(G_q),
\tag{1}
\]

则任何显式 circuit-valued outsider \(H_m\) 必满足

\[
TT(H_m)\notin\operatorname{Range}(G_q)
\quad\Longrightarrow\quad
\operatorname{CC}(H_m)>s_m.
\tag{2}
\]

因此当 \(s_m\) 超过所有固定的 \(m\)-多项式（特别是
\(s_m=q/\operatorname{polylog}q=2^m/\operatorname{poly}(m)\)）时，不存在
poly\((m)\)-size 的 \(H_m\) 能逃出 range。这个结论不是一般 circuit lower bound；
它只是 coverage 定义本身对“短 circuit-valued outsider”路线的封闭。

相反，如果不要求式 (1)，公开的 nonlinear graph/invariant 结构确实可以同时给出
near-linear decoder 和 \(O(m)\)-size outsider。下面的例子说明：困难不在
nonlinearity/non-systematicity 本身，而在于同时覆盖全部低复杂度 truth tables。

## Coverage no-go

式 (1) 直接给出式 (2)：若
\(\operatorname{CC}(H_m)\le s_m\)，则 \(TT(H_m)\in\mathcal C_{m,s_m}\)
从而属于 \(\operatorname{Range}(G_q)\)，矛盾。

若 \(H_m\) 由一个统一的时间 \(m^c\) 算法逐位计算，则标准
time-to-circuit simulation 给出

\[
\operatorname{CC}(H_m)\le O(m^c\log m).
\tag{3}
\]

所以只要 \(s_m/m^c\to\infty\)，任何此类 P-uniform family 都不可能成为
range outsider。对 \(s_m=q/\operatorname{polylog}q\)，式 (3) 对每个固定 \(c\)
最终都严格小于 \(s_m\)。

结合 note 110，这排除了两种常见偷换：

1. 用 \(q\)-bit group index 的 \(\operatorname{poly}(q)\) 搜索冒充
   \(m\)-地址上的 \(\operatorname{poly}(m)\) outsider；
2. 先用 P/PH-local 算法生成一个 poly\((m)\)-size 电路，再声称其 truth table
   自动离开覆盖所有 size-\(s_m\) 表的 range。

若要保持式 (1) 而得到 outsider，输出表示本身必须具有复杂度大于 \(s_m\)；
它不能是一个固定多项式大小的普通 Boolean circuit。

## 结构化 invariant 对照例

下面构造一个不满足式 (1) 的固定 decoder，展示公开 invariant 如何产生短 outsider。
把 \(q\)-bit words 按 \(\mathbb F_2^q\) 处理，并令 \(S\) 是 cyclic left shift。
定义

\[
L=I+S+S^2.
\]

由于 \(q=2^{m-1}\) 不被 \(3\) 整除，循环多项式
\(1+x+x^2\) 与 \(x^q-1\) 在 \(\mathbb F_2[x]\) 中互素，故 \(L\)
可逆。再定义局部 nonlinear map

\[
\psi(x)_i=x_i\land x_{i+1}
\quad (i\ {\rm mod}\ q),
\]

并令

\[
G_q(x)=\bigl(Lx,\;Lx\oplus\psi(x)\bigr).
\tag{4}
\]

这是一个 size \(O(q)\) 的 nonlinear、non-systematic \(q\)-to-\(2q\) circuit。
其 range 有公开的 graph relation：若输出写为 \((u,v)\)，则

\[
(u,v)\in\operatorname{Range}(G_q)
\Longleftrightarrow
v=u\oplus\psi(L^{-1}u).
\tag{5}
\]

取 \(H_m\) 的 truth table 为

\[
TT(H_m)=0^{2q-1}1.
\tag{6}
\]

这是一个 \(O(m)\)-size 的 point function。其前 \(q\) 位全为零；若它等于
\(G_q(x)\)，则 \(Lx=0\)，从而 \(x=0\)，于是 \(\psi(x)=0\)，但其后 \(q\)
位不全为零，和式 (6) 矛盾。因此

\[
TT(H_m)\notin\operatorname{Range}(G_q),
\qquad
\operatorname{CC}(H_m)=O(m).
\tag{7}
\]

这个例子并不覆盖所有 size-\(s_m\) truth tables；它只说明：
“有公开 invariant \(\Rightarrow\) 有短 outsider”是可实现的，但不能直接用于
目标 coverage decoder。

## 对 P versus NP 路线的裁决

当前固定 decoder 的选择出现严格二分：

\[
\begin{array}{c|c}
\text{要求} & \text{结论}\\ \hline
\text{公开 invariant、允许牺牲 coverage} &
  \text{可构造 \(O(q)\)-size nonlinear decoder 与 \(O(m)\)-size outsider}\\
\text{覆盖全部 size-}s_m\text{ tables，且 }s_m\gg\operatorname{poly}(m) &
  \text{poly\((m)\)-size outsider 被定义性排除}\\
\text{覆盖全部低复杂度 tables，并证明 range lower bound} &
  \text{仍是核心 open route}
\end{array}
\]

所以下一步不能再寻找“任意 decoder 的短 outsider”。若目标是 coverage，
必须直接攻击固定 range language 的成员关系/搜索复杂度，或构造一种能表达
复杂度 \(>s_m\) 的 succinct object；普通短电路表示必然失败。

### 来源与证据边界

- note 086/088：coverage 的容量与低复杂度包含；
- note 110：group-index 与显式输出的地址尺度障碍；
- 式 (4)--(7) 为本项目的自足线性代数/电路构造。
- 本 note 不声称证明任意 decoder lower bound，也不声称 \(P\ne NP\)。
