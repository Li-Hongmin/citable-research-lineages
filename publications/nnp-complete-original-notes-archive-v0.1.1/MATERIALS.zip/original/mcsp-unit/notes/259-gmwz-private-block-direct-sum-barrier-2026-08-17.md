> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# GMWZ private-block direct-sum barrier (2026-08-17)

## Scope

This note isolates an exact limitation of the coordinate-private PCPP-to-RLDC
architecture in GMWZ, Theorem 11.3. It is a **black-box architectural theorem**,
not a lower bound for all simultaneous coordinate-robust dPCPs.

## Proposition (private-block direct sum)

In the GMWZ construction, for every message coordinate \(i\in[k]\) and claimed bit
\(b\in\{0,1\}\), the circuit \(\varphi_{i,b}\) defines a separate language
\(\mathcal L_{i,b}\), and a separate PCPP \(\Psi_{i,b}\) is invoked. After padding,
each selected proof \(\pi'_{i,m_i}\) has \(2K\) symbols, where

\[
K=k\log^{C'}k.
\tag{259.1}
\]

The valid codeword therefore contains the disjoint private suffix

\[
P(m)=\pi'_{1,m_1}\,\pi'_{2,m_2}\cdots\pi'_{k,m_k}
\in(\Sigma\times\{0,1\})^{2Kk}.
\tag{259.2}
\]

Consider a compiler that preserves the following black-box interface:

1. coordinate \(i\) is verified only through its own private block;
2. the block is sampled at the same local PCPP addresses as in
   \(\Psi_{i,m_i}\); and
3. no symbol is shared by two different coordinate blocks (permutations,
   padding, and local relabelling are allowed).

Then every such compiler has proof-suffix length at least \(2Kk\). In particular,

\[
|P(m)|=\Omega(k^2\log^{C'}k),
\tag{259.3}
\]

so an address-preserving modification of this architecture cannot produce a
near-linear \(k\operatorname{polylog}k\) shared proof.

### Proof

For a fixed \(i\), the verifier must be able to read every address in the padded
\(A\)- and \(B\)-sides of \(\Psi_{i,m_i}\). Under (1)--(3), none of these addresses
can be represented by a symbol belonging to another coordinate. Thus the image of
the \(i\)-th private block contains at least \(2K\) independently addressable slots.
The \(k\) coordinate blocks are disjoint, so summing gives \(2Kk\). Substituting
(259.1) yields (259.3). \(\square\)

## What this does and does not prove

The proposition is exactly the direct-sum cost visible in the source construction:
GMWZ first builds \(\Psi_{i,b}\) for each \((i,b)\), pads every invocation to a common
\(K\), and concatenates the \(k\) selected proof blocks. The decoder reads a declaration
bit and then chooses the corresponding coordinate-specific PCPP block. See
[GMWZ, Theorem 11.3 and its construction](https://arxiv.org/html/2512.12960#S11.SS3),
especially the proof-block definition and decoder steps.

It does **not** rule out a new construction that shares symbols across coordinates.
Such a construction must replace (1)--(3) by a common-address synthesis map

\[
S_{x,i,b,j}(D_x)=\Pi_x[i,b,j]
\tag{259.4}
\]

with one global proof descriptor \(D_x\), one physical address space, and a
coordinate-robust soundness theorem. This is the actual Closure-Theorem target.
If (259.4) has bounded shared-object query complexity, message inlining turns it
into a relaxed local decoder; the corresponding RLDC lower bounds then constrain any
attempt to make the proof near-linear. Therefore the only nontrivial escape from the
proposition is not cheaper padding or address relabelling, but a genuinely new
cross-coordinate synthesis theorem.

## Minimax boundary for patchability

The private-block proposition also identifies why the minimax certificate in note 262
cannot be silently promoted to a general shared-proof lower bound. For a fixed target
\(i\), let \(\mathscr S_i\) be the honest query-set family and let \(\mathscr B_i\) be
realizable patches supported inside the private block \(R_i\). Note 262 applies to
\((\mathscr S_i,\mathscr B_i)\) and gives the exact value

\[
v_i=\min_{\mu\in\Delta(\mathscr S_i)}\max_{B\in\mathscr B_i}
\gamma_B\Pr_{S\sim\mu}[S\cap B\ne\varnothing].
\tag{259.5}
\]

But a target-independent certificate would require a single realizable patch family
\(\mathscr B\) and one dual distribution \(\lambda\) that hits the allowed query sets
for every coordinate in the intended target class. The private construction supplies
only the disjoint families \(\mathscr B_i\), not such a common \(\mathscr B\). Hence the
minimax theorem sharpens the *missing hypothesis* for a general lower bound; it does
not manufacture a common patch from coordinate-private blocks.

## Source-specific forcing cap

For GMWZ, the private-block product condition is not the only issue. A patch supported
only in \(R_i\) leaves the repeated common block
\(\mathcal C_0(m)^r\) unchanged. Let \(b=1-m_i\) be the wrong declaration bit and let
\(\mathcal L_{i,b}\) be the corresponding codeword language. Every word in
\(\mathcal L_{i,b}\) differs from \(\mathcal C_0(m)\) on at least \(1-\mu\) of its
coordinates, because \(\mathcal C_0\) has relative distance \(1-\mu\). Therefore, if
the PCPP \(\Psi_{i,b}\) has soundness at this distance

\[
\Pr[\text{its sampled constraint accepts}]
\le \varepsilon_{\mathrm{pcpp}}
\tag{259.6}
\]

for every right- and left-side assignment, then every private-only patch satisfies

\[
\Pr[\operatorname{Dec}(y,i)=b]
\le \varepsilon_{\mathrm{pcpp}}+\varepsilon_{\mathrm{pad}},
\qquad
\varepsilon_{\mathrm{pad}}=O(\log^{-10}k).
\tag{259.7}
\]

Indeed, the first block makes the decoder's sampled input exactly
\(\mathcal C_0(m)\). The event of outputting \(b\) is contained in the event that the
tag is \(b\) and the corresponding \(\Psi_{i,b}\) constraint accepts. Apply (259.6) to
the induced \(A\)- and \(B\)-assignments and then transfer from the padded sampling
distribution to the original PCPP distribution.

The extra term is the statistical-distance error from padding the \(A\)- and \(B\)-sides
to length \(K\). In the parameterization of Theorem 11.3, the premise (259.6) is
supplied by its PCPP hypothesis whenever \(1-\mu\ge 1-\delta^C\), with
\(\varepsilon_{\mathrm{pcpp}}=2\delta\).

Consequently, the product-patch direct-sum theorem cannot be instantiated with a forcing
quality \(\eta>\beta\) from these private-only patches whenever
\(\varepsilon_{\mathrm{pcpp}}+\varepsilon_{\mathrm{pad}}\le\beta\). The obstruction is
semantic rather than combinatorial: disjoint private strings can be merged into one global
word, but the wrong-claim PCPP soundness prevents any such local string from forcing a
wrong output with the constant quality needed by the direct-sum contradiction. A successful
patchability proof must therefore either alter the shared common block, use a
non-PCPP semantic forcing event, or accept a larger wrong-claim error.

## Common-core necessity

The preceding cap yields a quantitative localization lemma. Partition the proof positions
for target \(i\) into a common core \(C\) and a private region \(R_i\). Suppose every
patch supported only in \(R_i\) has wrong-output probability at most
\(\varepsilon_{\mathrm{priv}}\). If a patch \(B\subseteq C\cup R_i\) has wrong-output
probability at least \(\eta>\varepsilon_{\mathrm{priv}}\), then

\[
\Pr_{\omega}\!\left[S_i(\omega)\cap(B\cap C)\ne\varnothing\right]
\ge \eta-\varepsilon_{\mathrm{priv}}.
\tag{259.8}
\]

Indeed, compare the execution on \(B\) with the execution on the private-only patch
\(B\cap R_i\), using the same random tape. Until the honest path first reads
\(B\cap C\), the transcripts are identical; on the complementary event the private-only
cap applies.

If, in addition, every honest query step hits a core position with probability at most
\(\lambda/M\), where \(|C|=M\), and the decoder makes at most \(Q\) proof queries, then

\[
|B\cap C|
\ge \frac{(\eta-\varepsilon_{\mathrm{priv}})M}{Q\lambda}.
\tag{259.9}
\]

Thus a constant-quality semantic forcing event cannot hide entirely in the private blocks:
it must spend a proportional amount of support in the shared core whenever that core is
smooth. This is the exact point at which a proposed GMWZ escape enters the
output-homogeneous/field-lift RLDC branch; without core smoothness, (259.8) remains the
correct statement.

### Literal GMWZ parameter specialization

The common-core term is not merely asymptotic in the GMWZ layout. In Theorem 11.3, the
repeated common block consists of r = 2ρK copies of C₀(m), each of length k/ρ. Hence
its physical support is

$$M_core = r · |C₀(m)| = 2Kk. \tag{259.10}$$

The first decoder step samples one repetition and one coordinate uniformly, so each
common-core position is sampled with probability exactly 1/M_core. Therefore a mixed
patch with wrong-output quality η > ε_priv must satisfy the literal specialization of
(259.8)--(259.9),

$$|B ∩ C| ≥ (η − ε_priv) · 2Kk. \tag{259.11}$$

In the padded core-plus-selected-private portion, the total support is 4Kk, so any such
patch occupies at least

$$|B ∩ C|/(4Kk) ≥ (η − ε_priv)/2. \tag{259.12}$$

Additional auxiliary padding can only weaken this normalized statement, not the absolute
lower bound (259.11). Consequently, if the admissible near-proof radius is smaller than
(η − ε_priv)/2 on this core-plus-private scale, no constant-quality forcing patch exists
at all; otherwise the only semantic escape from the private PCPP cap is a constant-fraction
corruption of the shared repetition block. This is a source-specific radius/support
tradeoff, not a general shared-proof impossibility.

## Relation to the field-lift route

The field-lifted one-proof compiler changes the relation so that every valid lifted
history projects to the same outer codeword. It therefore abandons the private-block
hypothesis rather than compressing the GMWZ direct sum. Its remaining question is the
dual profile problem: list soundness gives an upper Lorenz budget, while a patchability
theorem would give the matching lower hitting budget. See
[dual profile closure](258-dual-profile-closure-for-field-lifted-dpcp-2026-08-17.md).

## Boundary

This is not a theorem that simultaneous coordinate-robust dPCPs require quadratic
length. It only says that the specific coordinate-private, disjoint-block black box
has an unavoidable \(\Omega(kK)\) suffix. A top-level result must therefore either

* construct the shared synthesis map (259.4), with fixed-address global soundness; or
* prove a general coding/RLDC theorem showing that every such shared synthesis pays a
  comparable superlinear cost.
