> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# AEKR projection-line correction: the (t)-flip lemma

## Set-up

Write the affine parameter as (z=(r,t)inmathbb F_2^{N+1}).  For a cell
(c=(x,y)), let

\[
H_c=\{r\cdot x=t, r\cdot y=1-t\}.
\]

For the spoiler (s), the two mismatch coordinates of a parameter (z) are

\[
\pi(z)=(r\cdot x_s+t,\ r\cdot y_s+t+1)\in\mathbb F_2^2.
\]

The spoiler leaf is (pi^{-1}(0)).  A collision witness (T) has
(L(T)=\bigcap_{c\in T}H_c) disjoint from this leaf, so
(\pi(L(T))) is either a nonzero point or an affine line avoiding (0).

## A valid same-line lemma (one projection direction)

The involution (\tau(r,t)=(r,t+1)) flips the two mismatch coordinates,

\[
\pi(\tau z)=\pi(z)+(1,1).
\]

For a fixed (r), every separated cell (c) is contained in exactly one of
the two leaves (t=0,1).  Hence, if (T\) is contained at (t) and (T') is
contained at (t+1), then a shared cell (c\in T\cap T') would have to be
contained at both orientations, which is impossible.  Therefore, for every
fixed (r), at most one of the two parameters (z,\tau z) can satisfy

\[
A(z):=\mathbf 1\{\exists T\in\mathcal T:T\subseteq R(z)\}.
\tag{1}
\]

If all witnesses have the common projection line

\[
\Lambda=\{(0,1),(1,0)\},
\]

then (A\) is supported on (pi^{-1}(\Lambda)), a half of parameter space,
and this half is partitioned into the (\tau)-pairs above.  Equation (1)
therefore gives the rigorous bound

\[
\Pr_z[A(z)=1]\le \frac12\cdot\frac12=\frac14.
\tag{2}
\]

The same argument works for either of the other two projection lines only if
there is an additional affine involution that flips exactly the corresponding
single mismatch coordinate (equivalently, a global affine form separating all
rows from all columns, in the required orientation).  Such a separator does
not exist for arbitrary disjoint (X,Y\).

## Why the unrestricted “same line is immediate” claim is not proved

The inclusion (L(T)\subseteq\{q=1\}) alone gives only a (1/2) bound.  The
fact that (|T|\ge2) gives codimension at least (3), hence
(\Pr[L(T)]\le1/8), but a union of many such flats is not controlled by this
individual estimate.  Pairwise intersection of the cell sets does not force
a common cell.  For example, with

\[
X=[2,5,1,3],\quad Y=[4,7,0,6],\quad s=(2,4),
\]

the family (cell indices in the (4\times4) grid)

\[
\{\{6,7\},\{6,14\},\{7,14\}\}
\]

is pairwise intersecting, has no common cell, and all three (L(T)) have the
same projection line (\{(0,1),(1,0)\}).  Its maximal-leaf hit probability is
(1/8), so it is consistent with (2) but disproves the tempting “same line
implies common core” shortcut.

Likewise, all three singleton projection points can occur in a pairwise
intersecting no-core family (for (N=3),
(X=[5,7,4,0],Y=[3,6,1,2],s=(5,3))); thus a proof cannot simply exclude the
three-singleton case by a finite ​\(\mathbb F_2^2\) projection argument.

## Consequence

The four-orbit thinning reduction remains valid, but the maximal-leaf bound
(\Pr[B]\le1/4) is still open in the unrestricted model.  Any manuscript claim
that every common projection line gives (2) must either restrict to the diagonal
line above or state and prove the needed single-coordinate-flip symmetry.

