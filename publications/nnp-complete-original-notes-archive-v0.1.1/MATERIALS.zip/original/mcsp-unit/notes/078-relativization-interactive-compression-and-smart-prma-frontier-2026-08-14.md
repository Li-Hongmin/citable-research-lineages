> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 相对化障碍、交互压缩三难与 smart-prMA 前沿（2026-08-14）

## 结论

[note 077](077-strong-explicit-self-simulation-and-fixed-alternation-compression-boundary-2026-08-14.md)
把剩余接口定位为：将 SAT-machine-dependent stitched language \(H_A\) 的

\[
T(n)=n^{\Theta(\log\log n)}
\]

时间逐位计算，压成 polynomial-length、fixed-alternation、polytime-local 的 sound-and-complete
对象。本 note 对该接口作四项裁决。

1. fixed-depth、quasipolynomial-size、polytime-local-wiring circuit 的 output-bit languages 恰好是
   \(PH\)，并非比“证明 \(H_A\in PH\)”更弱的中间类。
2. 这个压缩不可能由 relativizing 方法一般性完成；存在满足 \(P^O=NP^O\) 的 oracle，仍有
   mildly-superpolynomial-time language 不在 \(PH^O\)。自然相对化的 stitched AVOID 也有同一反例。
3. PCP、sum-check、IOP、IP、succinct EF 与小 discrepancy set 分别卡在 proof length、round count、
   global-strategy consistency、succinct reflection 或 witness cardinality；它们没有提供现成下沉。
4. 当前两个最具体、可证伪的正面接口是：stitched computation 的 poly-size succinct tableau circuit；
   或 Ren--Williams 式的 succinct smart-\(P^{prMA}/1\) AVOID。任一接口若成功，已经足以证明
   \(P\ne NP\)，但它们不像普通逐位 P 算法那样被 time-to-circuit simulation 无条件排除。

## local-wiring 表示类恰为 PH

令 \(\mathcal U\) 是如下 output-bit languages 的集合：对每个 address length \(n\)，\(2^n\) 个输出位
由一个 depth \(d=O(1)\)、size \(2^{n^{O(1)}}\) 的 Boolean circuit 给出；给定 gate IDs、gate type
和 output address，local wiring 可在 \(\operatorname{poly}(n)\) 时间计算。所有常数允许依赖语言，
但不依赖 \(n\)。则

\[
\boxed{\mathcal U=PH.}
\tag{1}
\]

\(\mathcal U\subseteq PH\) 由逐层交替量化 polynomial-length gate IDs 得到。反向，若

\[
L(x)=Q_1y_1\cdots Q_jy_j\,V(x,y_1,\ldots,y_j),
\qquad |y_i|=n^{O(1)},\quad V\in P,
\tag{2}
\]

则展开 \(j\) 层量词树。叶节点常数由 uniformity machine 在 polynomial time 运行 \(V\) 得到；
所得 circuit depth 为 \(j+O(1)\)，size 为 \(2^{n^{O(1)}}\)，并有上述 local wiring。

所以 note 077 的 fixed-alternation/local-wiring compression 就是目标语言的 \(PH\)-membership。
这里必须保持 SAT-machine dependence：\(H_A\) 的 circuit hardness 只在候选 \(A\) 确实是
polynomial-time SAT decider 时成立。对每个候选 \(A\) 在“\(A\) 正确”的前提下证明 \(H_A\in PH\)，
会排除正确的 polynomial-time SAT machine，故推出 \(P\ne NP\)；它不自动给出一个无条件的
\(PH\not\subseteq P/poly\) witness。

## 保持 collapse 前提的 oracle 反例

取 \(O=\mathrm{TQBF}\)。则

\[
P^O=NP^O=PH^O=PSPACE.
\tag{3}
\]

相对化 deterministic time hierarchy 给出

\[
L^O\in DTIME^O\!\left(n^{\lceil\log\log n\rceil}\right)\setminus P^O,
\tag{4}
\]

故 \(L^O\notin PH^O\)。所以不存在一个 relativizing transformation，能对每个满足
\(P^O=NP^O\) 的 oracle，把所有 mildly-superpolynomial deterministic \(O\)-computations 压入
fixed \(PH^O\)。这个反例保留了反证所需的 collapse 假设。

也可将 coherent AVOID 相对化。令 decoder 覆盖 size-\(n^k\) 的 \(O\)-oracle circuits，并用
\(CC^O\) 测量 oracle-circuit complexity。若 \(P^O=NP^O\)，fixed-\(k\) prefix self-reduction 仍在
\(P^O\) 中工作；取 \(k(n)=\lfloor\log\log n\rfloor\)，可 stitch 得

\[
H_A^O\in DTIME^O(n^{O(\log\log n)}),
\qquad
CC^O((H_A^O)_n)>n^{k(n)},
\tag{5}
\]

因而 \(H_A^O\notin P^O/poly\)。若目标 compression 自然相对化，则

\[
H_A^O\in PH^O=P^O\subseteq P^O/poly,
\tag{6}
\]

矛盾。故只把 SAT solver 当 black-box oracle，再使用 tableau、PH collapse 或 local wiring 的证明
不够；成功机制必须利用 ordinary Boolean computation 在加入 arbitrary oracle gates 后会失效的结构。

## 交互压缩三难

考虑 perfect-completeness public-coin protocol。若它有 \(r\) 轮，prover messages 为 \(a_i\)，随机
挑战为 \(\rho_i\)，则 exact semantics 是

\[
H_A(x)=1\iff
\exists a_1\forall\rho_1\cdots\exists a_r\forall\rho_r\;
V(x,a_1,\rho_1,\ldots,a_r,\rho_r)=1.
\tag{7}
\]

soundness \(<1\) 已保证 NO instance 对每个 prover strategy 至少有一条拒绝路径。从 protocol 得到
fixed \(PH\) 必须同时有

\[
r=O(1),\qquad
\sum_i(|a_i|+|\rho_i|)=n^{O(1)},\qquad
\operatorname{time}(V)=n^{O(1)}.
\tag{8}
\]

- PCP 可降低 randomness/query count，但 proof/oracle 长度仍为 \(T^{O(1)}\)。只量化被查询的 answers
  会允许不同随机路径使用不一致的长 proof。
- 标准 sum-check 对 \(T\)-step tableau 使用
  \(\Theta(\log T)=\Theta(\log n\log\log n)\) 个 address variables，因而需要同阶轮数。把变量分成
  fixed \(j\) blocks 会使显式 message 含 \(T^{\Omega(1/j)}\) 个 coefficients，仍为 super-polynomial。
- constant-round IOP 仍把一个 \(T^{1+o(1)}\) 或 \(T^{O(1)}\) 的 oracle 作为全局 existential object。
- Merkle commitments、Fiat--Shamir 与 SNARK 只给 computational soundness 或依赖额外假设，不给
  所需 unconditional exact predicate。
- \(IP=PSPACE\) 不给 fixed round；即使先证明 \(H_A\in PSPACE\)，\(P=NP\) 也不推出
  \(PSPACE=P\)。

共同缺口是

\[
\boxed{\text{短逐路径 transcript}\not\Rightarrow
\text{短且跨所有随机路径一致的 prover strategy}.}
\tag{9}
\]

## proof complexity 与 sampling 证书的边界

ordinary EF 可以显式定义普通 circuit gates，但标准 computation proof 长度为
\(\operatorname{poly}(T)\)。将其 succinctly encode 后，“巨大 proof 的每一行是否合法”需要新的
succinct reflection，而不再是普通 EF verification。对 \(H_A\) 和其补集都给出 polynomial-size、
fixed-PH 可验的 succinct EF certificates，已经会把 \(H_A\) 放入 fixed \(PH\)。

MCSP/refuter 的“小量 discrepancy points”还有无条件障碍。对任意
\(X\subseteq\{0,1\}^n\)，存在 size \(O(n|X|)\) 的 DNF，在 \(X\) 上与任意目标函数完全一致。因此若

\[
\forall C\ (|C|\le s)\ \exists x\in X:\ C(x)\ne H_A(x),
\tag{10}
\]

则必须有

\[
|X|=\Omega(s/n).
\tag{11}
\]

对 \(s=n^{\lfloor\log\log n\rfloor}\)，这仍是 super-polynomial。故 polynomial-query hitting set
不能认证 stitched threshold；剩余只能是非采样的 succinct range-nonmembership certificate。

## 正面接口一：succinct tableau circuit

假设 \(A\) 是正确的 polynomial-time SAT decider，\(M_A\) 是相应 stitched AVOID machine。当前
最具体的 special-purpose 命题是：是否存在 fixed \(c\)，使每个 \((n,x)\) 的真实
\(T=n^{\Theta(\log\log n)}\)-step computation tableau 都有 size \(n^c\) 的 ordinary circuit

\[
C_{n,x}(t,p)
\tag{12}
\]

随机访问任意 time/position bit？若有，则可猜测 \(C_{n,x}\)，再 universal quantize polynomial-length
\((t,p)\)，检查 initial configuration、每个 local transition 和 output：

\[
\exists C_{n,x}\ \forall(t,p):
\operatorname{ValidLocalTableau}(A,n,x,C_{n,x},t,p,b).
\tag{13}
\]

determinism 保证对真实 output \(b\) 存在 certificate，对错误 \(b\) 不存在。因此

\[
H_A\in\Sigma_2^P\cap\Pi_2^P,
\tag{14}
\]

并在 \(A\) 正确时立即推出 \(P\ne NP\)。一般 computation 版本已被 oracle/time-hierarchy 反例否定；
special \(M_A\) 版本的最便宜下一实验，是定位 lex-prefix/self-reduction computation 中首次需要
\(n^{\Omega(k)}\)-size configuration function 的步骤。

## 正面接口二：succinct smart-prMA AVOID

令固定 prMA promise 为

\[
\Pi_Y=\{B:\exists w\ \forall r\ B(w,r)=1\},
\qquad
\Pi_N=\{B:\forall w\ \Pr_r[B(w,r)=1]\le 1/2\}.
\tag{15}
\]

总语言

\[
S=\{B:\exists w\ \forall r\ B(w,r)=1\}\in\Sigma_2^P
\tag{16}
\]

分离 \(\Pi_Y\) 与 \(\Pi_N\)。若 deterministic oracle machine 的正确-advice execution 是 smart 的，
即每个实际 query 都在 promise 内，则以 \(S\) 替换 promise oracle 不改变输出。若 \(P=NP\)，则
\(S\in P\)。对固定 machine、固定 promise，且 runtime/query length 为 \((n+k)^c\) 的 construction，
替换后的确定性时间 exponent 是与 \(k\) 无关的常数。正确的每长度 advice bit 可硬接进 circuits，故

\[
smart\text{-}P^{prMA}/1\subseteq P/1\subseteq P/poly
\qquad(P=NP).
\tag{17}
\]

于是最小尚未被普通 time-to-circuit simulation 预先封死、但足以推出矛盾的 class separation 是

\[
\boxed{smart\text{-}P^{prMA}/1\not\subseteq P/poly.}
\tag{18}
\]

Ren--Williams 2026 已给出 near-maximum-hard language 位于 \(smart\text{-}E^{prMA}/1\)，并给显式
输入 AVOID 的 smart-\(FP^{prMA}/1\) 求解。所需改变是把显式 \(m\)-bit AVOID instance 的
\(\operatorname{poly}(m)\) 求解，变成从 compact \((n,k,x)\) 在 \(\operatorname{poly}(n+k)\) 时间返回
同一个 coherent outsider bit。

令 canonical decoder description length

\[
q=\Theta(n^k\log(n^k+n))=n^{k+O(1)}.
\tag{19}
\]

代入 Ren--Williams encoded history，success 分支的第一个 Jeřábek--Korten preimage query 已量化

\[
\exists u\in\{0,1\}^q:\ G_q(u)=z,
\tag{20}
\]

故 witness/query size 为 \(q^{\Omega(1)}\)。failure/Reconf 分支保持 smartness 与 coherence，但其
prefix 长度为 \(q\operatorname{polylog}q\)，Merlin circuit size 仍为 \(q^{O(1)}\)。所以首次断点不是
advice 或 smartness，而是显式 preimage interface。

更精确的缺失命题是 Local-JK-preimage lemma：只对 RW encoded-history 的特殊 blocks \(z\) 与
canonical \(G_q\)，用 \(\operatorname{poly}(n+k,\log T)\)-size smart-prMA query 规范地区分
\(z\notin Range(G_q)\) 与 \(z\in Range(G_q)\)；后一情形返回同尺度 local circuit，逐位计算 lex-first
\(q\)-bit preimage，而不显式提交它。一般 \(G\) 的 padded identity 已否定无约束版本，所以两个特殊
结构限制不可删除。

最直接的否证实验是：在这些特殊 blocks 中找一个 range element，使其每个 preimage 的 bit-accessor
都需要 super-polynomial circuit。任一显式 \(q\)-bit preimage、\(q\operatorname{polylog}q\)-prefix、
\(q^{\Omega(1)}\)-size Merlin circuit，或 machine/promise 随 \(k\) 改变，都会使该接口失败。

## 空间压缩不会单独闭合

当前 decoder description、coherent suffix 和 direct configuration 长度均为

\[
n^{\Theta(k)}\operatorname{poly}(k),
\qquad k=\lfloor\log\log n\rfloor.
\tag{21}
\]

所以直接 enumeration 只给 \(H_A\in DSPACE(n^{O(\log\log n)})\)。流式枚举仍需保存同阶 rank，
重算 lex prefix 会产生同阶递归深度，逐分支重猜 prefix 则非法交换“同一个 suffix 对所有 decoders
一致”的量词。Savitch 不压缩 configuration length。

这些实现障碍不能证明 \(H_A\notin PSPACE\)；新算法仍可能做到 polynomial space。但即使得到
\(H_A\in PSPACE\)，也没有从 \(P=NP\) 到 \(PSPACE=P\) 的 collapse。真正改变决策的结果仍须是
fixed alternation/poly-length，即 \(H_A\in PH\)，或上面的 smart-prMA route。

## 来源与证据边界

检索与原文核验日期：2026-08-14。

- Scott Aaronson and Avi Wigderson, *Algebrization: A New Barrier in Complexity Theory*, TOCT 2009.
- Lijie Chen, Ce Jin, Rahul Santhanam, and Ryan Williams, *Constructive Separations and Their
  Consequences*, TheoretiCS 2024. DOI: `10.46298/theoretics.24.3`.
- Hanlin Ren and Ryan Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin-Arthur Queries*, ECCC TR26-118, revision 1, 2026.

Ren--Williams 的 smart-\(E^{prMA}/1\) lower bound、显式输入 AVOID solver 与 prMA 定义，以及标准
PCP/sum-check/IP、EF、PH 与 oracle hierarchy 事实是文献支持的输入。式 (1)、(4)--(14)、
(17)--(21) 对 stitched \(H_A\) 的组合裁决与参数测试是本项目推论。本文不声称已经证明
\(P\ne NP\)。
