> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 仿射叶 cover 层级与 quasi-additive 目标

## 1. 单叶兼容性的精确判据

设

\[
Q=\{(x_i,y_i):i\in I\}\subseteq X\times Y.
\]

存在仿射线性型 \(\ell\) 与 \(t\in\mathbb F_2\)，使

\[
\ell(x_i)=t,
\qquad
\ell(y_i)=1-t
\qquad(\forall i),
\]

当且仅当

\[
\boxed{
\operatorname{aff}\{x_i:i\in I\}
\cap
\operatorname{aff}\{y_i:i\in I\}
=\varnothing.}
\]

充分性来自有限维仿射空间中两个不交仿射子空间可由仿射超平面分离；必要性来自 \(\ell\) 在两者上分别恒为不同值。等价的失败证书是存在奇数大小的指标集 \(I_0,J_0\)，使

\[
\bigoplus_{i\in I_0}x_i
=
\bigoplus_{j\in J_0}y_j.
\]

特别地，因 \(X\cap Y=\varnothing\)，任意两个点对总能共处一个合法 parity 叶。因此 pairwise fooling set 的最大值为 \(1\)；第一个真实冲突必是高阶 odd--odd affine collision。

## 2. Cover 层级的尖锐边界

[[008-parity-kw-rectangle-weight-collapse]] 已证明 fractional cover 至多为 \(4\)。整数 cover 也不能给超线性下界：坐标 parity 的两个方向给

\[
X\times Y
\subseteq
\bigcup_{j=1}^{N}\bigcup_{t\in\{0,1\}}
\bigl(X\cap\{x_j=t\}\bigr)
\times
\bigl(Y\cap\{y_j=1-t\}\bigr),
\]

故

\[
\operatorname{cov}_{\oplus}(f)\le2N.
\]

该量级可达。对 \(f=OR_N\)，零输入集为 \(\{0^N\}\)。若仿射 parity 叶族覆盖所有 \(y\ne0\)，其线性部分 \(r_1,\ldots,r_k\) 必须满足

\[
\bigcap_{i=1}^{k}\ker r_i=\{0\};
\]

故 \(r_i\) 张成 \(\mathbb F_2^N\)，从而 \(k\ge N\)。坐标 parity 达到该界，所以

\[
\boxed{
\sup_f\operatorname{cov}_{\oplus}(f)=\Theta(N).}
\]

另一方面，递归协议叶数没有多项式通用上界。大小至多 \(S\) 的 affine-leaf De Morgan 公式数量至多

\[
2^{S(N+4)}.
\]

而 \(N\) 变量 Boolean 函数共有 \(2^{2^N}\) 个，故存在 \(f\) 满足

\[
L_{\operatorname{Formula}\circ XOR}(f)
\ge
\frac{2^N}{N+4}.
\]

于是存在严格层级：

\[
\boxed{
\operatorname{fcov}\le4
\;<\;
\operatorname{cov}=O(N)
\;<\;
\operatorname{recursive\ protocol}
=2^{\Omega(N)}\text{ in the worst case}.}
\]

## 3. 第一个确定逃逸层：quasi-additive LP

对任意有限 total relation

\[
T\subseteq X\times Y\times Z,
\]

令 \(C=X\times Y\)，\(\mathcal R(T)\) 为全部非空矩形，\(\mathcal M(T)\) 为具有某个共同合法输出 \(z\) 的单色矩形，\(\mathcal P(R)\) 为 \(R\) 的所有一次横向或纵向二分。

Kamiyama 对 Ueno 的 quasi-additive LP 给出的原文形式使用自由实变量

\[
\phi_c
\quad(c\in C),
\qquad
\psi_{c,R}
\quad(c\in C,R\in\mathcal R(T)),
\]

最大化

\[
\sum_{c\in C}\phi_c,
\]

并满足两类约束：

\[
\sum_{c\in R}\phi_c
+
\sum_{c\in C\setminus R}\psi_{c,R}
\le1
\qquad(\forall R\in\mathcal M(T)),
\tag{leaf}
\]

以及对每个 \(R\in\mathcal R(T)\) 和 \(\{V,W\}\in\mathcal P(R)\)，

\[
\sum_{c\in C\setminus V}\psi_{c,V}
+
\sum_{c\in C\setminus W}\psi_{c,W}
\ge
\sum_{c\in C\setminus R}\psi_{c,R}.
\tag{recursion}
\]

其最优值记为 \(QA(T)\)。Ueno--Kamiyama 定理对任意 relation 成立：

\[
\boxed{QA(T)=CP(T),}
\]

其中 \(CP(T)\) 是把完整通信矩阵递归二分成单色叶矩形所需的最少叶数。Kamiyama 还给出计算 \(CP(T)\) 的整数规划，并证明其线性松弛与整数规划无 integrality gap。

定理只使用抽象输出集合 \(Z\) 与合法关系 \((x,y,z)\in T\)，不要求 \(z\) 是输入坐标。因此令 \(Z\) 为全部带方向的仿射 parity，并置

\[
T_{\oplus}
=
\{(x,y,(\ell,t)):
\ell(x)=t,\ \ell(y)=1-t\},
\]

即可得到

\[
QA(T_{\oplus})
=CP(T_{\oplus})
=L_{\operatorname{Formula}\circ XOR}(f).
\]

随机 parity 的常数 cover 只击穿不含递归补偿的 rectangle 松弛；变量 \(\psi_{c,R}\) 遍历所有非单色矩形，并强制每次横/纵二分的一致性，所以该常数 cover 不产生 quasi-additive 可行上界。

## 4. GapMCSP 的精确下一命题

令

\[
X=E_a=\{z:\operatorname{CC}(z)\le a\},
\qquad
Y=NO_b=\{z:\operatorname{CC}(z)>b\},
\]

并把 \(T_\oplus\) 限制到 \(X\times Y\)。任何正确的 GapMCSP Formula--XOR totalization 都给该 relation 一个同样大小的递归协议。因此，只需构造 \((\phi,\psi)\) 满足 `(leaf)` 与 `(recursion)` 且

\[
\boxed{
\sum_{c\in E_a\times NO_b}\phi_c>N^{1.01}}
\]

即可得到 Frontier B 所需下界，进而触发相应 hardness magnification。

这是一种精确刻画，不是现成下界。新的数学负担全部集中为一个递归势能证书：

\[
\begin{cases}
\text{每个 parity-monochromatic leaf 的净势}\le1,\\
\text{势在每次横/纵二分下不增},\\
\text{根矩阵总势}>N^{1.01}.
\end{cases}
\]

该证书必须使用 \(NO_b\) 包含全部高复杂度真值表的语义；若只使用密度或单叶容量，便退回 notes 004、008 已关闭的路线。

~~~mermaid
flowchart LR
    F["fractional cover ≤ 4"] --> I["integer cover = Θ(N)"]
    I --> Q["quasi-additive LP"]
    Q -->|"QA = CP"| P["递归 parity-KW 协议"]
    P --> M["Formula-XOR 叶数"]
    M --> G["GapMCSP Frontier B"]
~~~

## 5. 原始来源

- Naoyuki Kamiyama, *A Note on the Quasi-Additive Bound for Boolean Functions*, Journal of Math-for-Industry 4-B (2012), 119--122; arXiv:1012.5130.
- Kenya Ueno, *Breaking the Rectangle Bound Barrier Against Formula Size Lower Bounds*, MFCS 2010.
- Mauricio Karchmer, Eyal Kushilevitz and Noam Nisan, *Fractional Covers and Communication Complexity*, SIAM Journal on Discrete Mathematics 8(1), 1995.

