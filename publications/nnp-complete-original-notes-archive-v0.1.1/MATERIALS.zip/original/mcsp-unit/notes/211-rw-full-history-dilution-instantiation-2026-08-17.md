> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW full-history dilution: a source-specific Gate-I barrier (2026-08-17)

## 结论

抽象的 target-density barrier 可以直接落到 Ren--Williams Theorem 4.3 的 stage
\(i\)，但必须把量词写窄：它只排除**把完整 RW history 当作普通 dPCP 坐标、再用
scalar average/list soundness 读取输出位**的组合，不排除新的 target-normalized
relation compiler。

RW 的 \(f_i\) 被定义为：先输出 \(B F_i\) 的 \(2n_i\)-bit AVOID 结果，再补零到总长
\(T_i\)。Lemma 3.2 的 satisfying assignment

\[
\mathrm{hist}=(y_1,\ldots,y_r,\mathrm{out},z_{1,1},\ldots,z_{r,t})
\]

把 'out' 作为一个长度 \(\ell=T_i\) 的连续字段。因此，只要 dPCP 的坐标分布仍把
这个完整 history 的普通坐标作为采样空间，RW 输出坐标 \(J_i\)（大小
\(K_i=2n_i\)）的质量最多是 \(K_i/T_i\)，而单个目标位的质量最多是 \(1/T_i\)。

结合 singleton full-history dilution，得到：

\[
\varepsilon_i\le \frac{\beta}{T_i}
\quad\text{(每个输出位的 constant smartness)},
\tag{211.1}
\]

\[
\varepsilon_i\le \frac{2\beta n_i}{T_i}
\quad\text{(输出块平均 constant soundness)}.
\tag{211.2}
\]

在 RW 稳定区 \(T_i=n_{i+1}=n_i^C\) 时，这变成

\[
\varepsilon_i\le \beta n_i^{-C},
\qquad
\varepsilon_i\le 2\beta n_i^{1-C}.
\tag{211.3}
\]

这比只按输出长度 \(2n_i\) 记账的 \(O(1/n_i)\) 要强得多，说明当前 dPCP fixed-\(\epsilon\)
结果不能黑箱实例化为 RW 的 address-scale Gate I。

## 定理（RW full-history instantiation）

固定 RW Theorem 4.3 的一个 stage \(i\)，并令 \(x_0=0^{n_0}\)。按原文定义

\[
 f_i(x)=\operatorname{pad}_{T_i}(B F_i),
\]

其中 \(B F_i\) 的输出占前 \(2n_i\) 位，其余位为零。令
\(K_i=2n_i\)，并令 \(\Pi\) 是由 Lemma 3.2/Theorem 3.5 的完整 computational-history
relation 产生的任意 singleton-output dPCP 证明系统。假设：

1. 合法 decoded histories 在 \(J_i\) 上投影为同一个 target word；
2. dPCP 的 scalar list-outside bound 是
   \[
   \sum_{u\in U_i}\mu_u b_u(\Pi)\le \varepsilon_i;
   \]
3. 'out' 的 \(T_i\) 个普通 history 坐标均在 dPCP 的坐标空间中，且不使用
   target-normalized reweighting 或 outer spreading。特别地，在均匀 raw-history 采样下，
   \(\mu_u=1/L_i\)，其中 \(L_i\ge T_i\) 是完整 history 的坐标数。

则对每个 target 坐标 \(j\in J_i\) 及错误声明 \(c\ne f_i(x_0)_j\)，

\[
\Pr[V_{i,j,c}\text{ accepts}]
\le \min\{1,L_i\varepsilon_i\}.
\tag{211.4}
\]

进一步，对输出块的平均 list-outside 率有

\[
\frac1{K_i}\sum_{j\in J_i}
\Pr[\text{coordinate }j\text{ is list-outside}]
\le \min\{1,L_i\varepsilon_i/K_i\}.
\tag{211.5}
\]

因此，若希望逐位错误率不超过 \(\beta<1\)，必须有

\[
\varepsilon_i\le \beta/L_i\le \beta/T_i;
\tag{211.6}
\]

若只要求输出块平均错误率不超过 \(\beta\)，也必须有

\[
\varepsilon_i\le \beta K_i/L_i\le 2\beta n_i/T_i.
\tag{211.7}
\]

### 证明

Lemma 3.2 的输入历史显式含有长度 \(\ell=T_i\) 的 'out' 字段；故完整 dPCP
坐标数满足 \(L_i\ge T_i\)。在 singleton target projection 下，错误声明事件
包含于对应坐标的 list-outside 事件。对均匀坐标分布应用加权不等式
\(\mu_j b_j\le\varepsilon_i\)，得到 \(b_j\le L_i\varepsilon_i\)，即 (211.4)；对
\(J_i\) 求和并除以 \(K_i\)，得到 (211.5)。要求右端分别不超过 \(\beta\)，并用
\(L_i\ge T_i\)，得到 (211.6)--(211.7)。证毕。

## RW 稳定区的代入

RW Theorem 4.3 取

\[
n_{i+1}=n_i^C,\qquad
T_i=\max\{2^{cD^i n_0},n_{i+1}\}.
\]

在稳定区 \(i\ge i^\star\)，原文明确给出 \(T_i=n_{i+1}=n_i^C\)。因此

\[
\varepsilon_i\le \beta n_i^{-C}
\quad\text{(逐位)},\qquad
\varepsilon_i\le 2\beta n_i^{1-C}
\quad\text{(输出块平均)}.
\tag{211.8}
\]

这是一条参数级 source-specific barrier，而不是把“history 很长”当作直觉。它只
使用原文中明确的 'out' 字段长度和 stable recurrence；不把 Theorem 3.5 的
\(\operatorname{poly}(T_i)\) 上界误当作额外的 history 下界。

## 为什么它不直接证明一般不可能性

该定理的假设 3 是刻意的黑箱组合假设。未来构造可以通过以下方式避开它：

* 让 verifier 的坐标分布直接归一化到 \(J_i\)，使 \(\mu(J_i)=\Omega(1)\)；
* 把一个输出位编码到常数比例的 code coordinates，使错误位不再只是一个 raw slot；
* 直接给 target projection 一个 coordinate-wise/global predicate，而不是从完整
  history 的 scalar average 中提取；
* 使用同一 proof 的 target-binding relation compiler，把私有 witness 移出普通
  history 采样空间。

但这些都已经是新的 PCP/coding theorem；它们不能由现有 Theorem 3.5 的 exposed
history 记号自动获得。特别地，把 'out' 位放在 systematic prefix 中并不会改变
均匀 full-history 的密度。

## 证据边界

RW 原文 Theorem 4.3 的 stage 定义和 \(T_i\) recurrence，以及 Lemma 3.2 的
'out' 字段布局，见本地逐字抽取：

units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md，
Lemma 3.2 与 Theorem 4.3；正式来源为
[Ren--Williams TR26-118](https://eccc.weizmann.ac.il/report/2026/118/)。

本定理是 [full-history target-density dilution barrier](210-full-history-target-density-dilution-closure-barrier-2026-08-17.md)
的 RW-specific instantiation。它不声称现有 RW canonical history 已经满足某个
target-normalized compiler，也不声称由此单独推出 \(P\ne NP\)。
