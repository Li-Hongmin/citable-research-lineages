> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定 separator、同中心连通 star 的完整 thinning 闭合（2026-08-13）

## 命题

固定 spoiler \(s=(x_s,y_s)\)。设 \(\mathcal F\) 是关于 \(s\) 的
inclusion-minimal collision witness 族，且：

1. \(\mathcal F\) 两两相交；
2. 每个 \(T\in\mathcal F\) 都是同一中心 row \(x_0\) 的连通 star
   \[
   T=T_S=\{(x_0,y):y\in S\};
   \]
3. 所有 \(T\in\mathcal F\) 具有同一个 separator 方程
   \[
   \sigma(z)=b,\qquad
   \sigma\in\{q_s,\ p_s,\ q_s+p_s\},\quad b\in\mathbb F_2.
   \]

则随机 affine 叶后再以 \(1/2\) 独立 thinning 行、列，有

\[
\boxed{
\Pr_{z,U,V}\bigl[\exists T\in\mathcal F:T\subseteq R_z(U,V)\bigr]
\le \frac1{16}.
}
\tag{1}
\]

同中心 column-star 情形由交换两侧得到。

## 参数支持

写

\[
q_{x_0}=(x_0,1),\qquad q_{x_0}z=0
\]

为中心 row 的叶方程。任意 \(T_S\) 的命中必满足
\(q_{x_0}z=0\) 以及 \(\sigma(z)=b\)。

这两个方程要么不相容，要么线性独立：

- \(\sigma=q_s,\ b=1\)：若 \(q_s=q_{x_0}\)，则
  \(q_{x_0}z=0\) 与 \(q_s z=1\) 矛盾；
- \(\sigma=p_s,\ b=0\)：若 \(p_s=q_{x_0}\)，则 \(y_s=x_0\)，
  与 \(X\cap Y=\varnothing\) 矛盾；
- \(\sigma=q_s+p_s,\ b=0\)：其最后坐标为 \(0\)，而
  \(q_{x_0}\) 的最后坐标为 \(1\)，不可能相等。

故非空时参数支持

\[
Z_0=\{z:q_{x_0}z=0,\ \sigma(z)=b\}
\]

至多有 \(2^{N-1}\) 个点（总参数空间为 \(2^{N+1}\)），即

\[
\Pr_z[z\in Z_0]\le\frac14.
\tag{2}
\]

## 固定参数的列补集配对

固定 \(z\in Z_0\)，令

\[
B_z=\{y\in Y:p_yz=1\}
\]

为该叶的列集，并定义

\[
\mathcal S_z=\{S:T_S\in\mathcal F,\ S\subseteq B_z\}.
\]

由于 \(\mathcal F\) 两两相交，\(\mathcal S_z\) 是两两相交的列集族：
任意 \(S,S'\in\mathcal S_z\) 满足 \(S\cap S'\ne\varnothing\)。

对任意列保留子集 \(V\subseteq B_z\)，令

\[
H_z(V)=\{\exists S\in\mathcal S_z:S\subseteq V\}.
\]

若 \(H_z(V)\) 与 \(H_z(B_z\setminus V)\) 同时成立，则存在
\(S\subseteq V\)、\(S'\subseteq B_z\setminus V\)，从而
\(S\cap S'=\varnothing\)，矛盾。因此

\[
\mathbf 1_{H_z(V)}+\mathbf 1_{H_z(B_z\setminus V)}\le1.
\]

在均匀随机 \(V\subseteq B_z\) 下，补集配对给出

\[
\Pr_V[H_z(V)]\le\frac12.
\tag{3}
\]

中心 row \(x_0\) 还必须被保留，独立概率为 \(1/2\)。故固定 \(z\) 的完整
thinning 命中概率满足

\[
\mu_z\le\frac12\cdot\frac12=\frac14.
\tag{4}
\]

结合 (2)：

\[
\Pr_{z,U,V}[\exists T\in\mathcal F:T\subseteq R_z(U,V)]
=\frac1{2^{N+1}}\sum_z\mu_z
\le\frac{2^{N-1}}{2^{N+1}}\cdot\frac14
=\frac1{16}.
\]

## 边界

本结论要求所有 witness 共用同一个 separator 方程，并且投影图都是同一
中心的单连通 star。若 separator 在 witness 间变化，或 witness 含多个
star-forest 组件，列补集配对仍成立于单一子族，却不能直接跨子族相加。
这正是一般 affine-biclique AEKR 尚未闭合的最小接口。
