> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Lupanov block packing 与 near-linear decoder 窗口（2026-08-14）

## 结论

[note 084](084-range-membership-forces-hardness-scale-2026-08-14.md) 对 canonical decoder 证明：若
stitched truth table 的最后一个 \(2q\)-bit hard block \(B\) 属于 \(\operatorname{Range}(G_q)\)，则

\[
q=\Omega(n^k\log q).
\]

本 note 删除 range membership 假设。真正的原因不是 decoder，而是 Lupanov 对任意 truth table 的
最坏情形 circuit upper bound。若

\[
H=0^{2^n-2q}B,
\qquad \operatorname{CC}(H)>n^k,
\tag{1}
\]

则对充分大 \(n\) 与 \(k\ge2\)，无条件有

\[
\boxed{q=\Omega(n^k\log q).}
\tag{2}
\]

所以 note 084 的 scale barrier 在单 suffix block 上比原陈述更普遍：任何把全部 hardness 压入
\(2q\) 个连续 coordinates 的方案都必须支付该尺度，不论 block 是否在某个 AVOID map 的 range。

该结论对连续的 \(r\) 个 suffix blocks 推广为

\[
\boxed{rq=\Omega\!\left(n^k\log(rq)\right).}
\tag{3}
\]

因此分散 hardness 可以让单个 \(q\) 变小，但不能让总 suffix payload \(rq\) 低于 hardness scale。

对 JK 路线，分散 blocks 还有第二个独立约束。若所有 blocks 都在 range，并有一个 size \(a(n)\) 的联合
preimage accessor，且 stretch map \(G_q\) 的语法 size 为 \(S(q)\)，则不经过 JK recursion 已有

\[
\operatorname{CC}(H_n)
\le S(q)+q\,a(n)+O(q+n).
\tag{4}
\]

而 generic JK easy branch 要给出新信息，必须同时满足

\[
S(q)\log T<n^{k(n)}
\le S(q)+q\,a(n)+O(q+n).
\tag{5}
\]

当 \(a(n)=n^c\)、\(\log T=\Theta(n)\)、\(k(n)\to\infty\)，且采用
\(S(q)=q^{d+o(1)}\) 的固定语法时，任何 fixed \(d>1\) 最终都没有参数窗口。故 note 082 的
copied-evaluator quadratic decoder 不能通过“把 hardness 分到更多 systematic blocks”修复。
在 RW 的 \(S(q)=|G_q|\ge q\) convention 下，generic JK 仍可能有窗口的 decoder 必须达到

\[
\boxed{S(q)=q^{1+o(1)}}
\tag{6}
\]

并同时满足 fixed-exponent recursive selector closure。

这不是 \(P\ne NP\) 的证明。hard branch 产生的 compact non-image，以及 near-linear stretch map
配合递归 selector，仍未关闭。

## Single-block packing lemma

令

\[
m=\log_2(2q),
\]

其中 \(2q\le2^n\) 是二次幂。把 \(B\in\{0,1\}^{2q}\) 看成 \(m\)-variable Boolean function。
Jukna 2012 Theorem 1.15 所述 Lupanov upper bound 给出：对任意 \(m\)-variable function \(f\)，

\[
\operatorname{CC}(f)
\le
(1+\alpha_m)\frac{2^m}{m},
\qquad
\alpha_m=O\!\left(\frac{\log m}{m}\right),
\tag{7}
\]

这里 circuit basis 是 fan-in-two \(\{\land,\lor,\neg\}\)。因此

\[
\operatorname{CC}(B)
\le
(1+o(1))\frac{2q}{\log(2q)}.
\tag{8}
\]

另一方面，由式 (1)，若 \(B\) 有 size \(s\) circuit，则检测 address 的前 \(n-m\) bits 是否全为
\(1\)，再调用 \(B\)，得到

\[
\operatorname{CC}(H)\le s+O(n).
\]

故

\[
n^k-O(n)
<\operatorname{CC}(B)
\le(1+o(1))\frac{2q}{\log(2q)},
\tag{9}
\]

这就证明式 (2)。它严格加强 note 084 的 range-membership lemma；note 084 的 accessor-to-evaluation
no-go 仍然有效。

## 多 block packing

把 input 写成

\[
(y,x)\in\{0,1\}^{n-m}\times\{0,1\}^{m}.
\]

每个 aligned \(2q\)-bit block 是固定 \(y\) 后的一个 \(m\)-variable function。

### 连续 suffix

先设 \(H\) 仅在连续的最后 \(r\) 个 blocks 上可能非零。取

\[
s=\lceil\log_2 r\rceil.
\]

最后 \(r\) blocks 位于最后 \(2^s\) blocks 内。检测最前面的 \(n-m-s\) address bits 是否全为
\(1\)，然后把其余 \(m+s\) bits 交给一个任意 truth table 的 Lupanov circuit；未使用的
\(2^s-r\) blocks 填零。由式 (7)，

\[
\operatorname{CC}(H)
\le
(4+o(1))\frac{rq}{\log(rq)}+O(n).
\tag{10}
\]

若 \(r\) 是二次幂，不需要向上 padding，常数可写成

\[
\operatorname{CC}(H)
\le
(1+o(1))\frac{2rq}{\log(2rq)}+O(n).
\tag{11}
\]

式 (3) 立即由 \(\operatorname{CC}(H)>n^k\) 与式 (10) 得到。

### 任意散布的 blocks

设非零 block indices 为

\[
a_1,\ldots,a_r\in\{0,1\}^{n-m}.
\]

用 equality circuits 比较 \(y=a_j\)，生成 \(s\)-bit label \(j\)，并计算 active flag

\[
e(y)=\bigvee_{j=1}^r[y=a_j].
\]

总 cost 为

\[
O\!\left(r(n-m)\right).
\]

构造一个 \((m+s)\)-variable function \(F(j,x)\)，令前 \(r\) 个 labels 分别承载相应 block，
其余 labels 输出零，最后输出 \(e(y)\land F(j,x)\)。active guard 保证 \(y\) 不在给定 locations 时
输出零。Lupanov bound 给 \(F\) size

\[
O\!\left(\frac{rq}{\log(rq)}\right).
\]

所以一般有

\[
\boxed{
\operatorname{CC}(H)
\le
O\!\left(
\frac{rq}{\log(rq)}
+r\bigl(n-\log(2q)\bigr)
\right).
}
\tag{12}
\]

相应必要条件是

\[
\frac{rq}{\log(rq)}
+r\bigl(n-\log(2q)\bigr)
=\Omega(n^k).
\tag{13}
\]

与连续 suffix 不同，显式 location dictionary 有 \(O(r(n-m))\) circuit cost；若这一项已经达到
\(n^k\)，该上界不能单独从 hardness 推出式 (3)。

## Joint-selector composition

令完整 truth table 分块为

\[
H_n=B_{n,1}\cdots B_{n,M},
\qquad |B_{n,j}|=2q.
\]

假设每个 block 都在 \(\operatorname{Range}(G_q)\)，并有所选 preimage

\[
u_{n,j}\in\{0,1\}^q,
\qquad G_q(u_{n,j})=B_{n,j},
\]

并有同一个 circuit

\[
A_n(j,\ell)=u_{n,j}[\ell],
\qquad |A_n|\le a(n).
\tag{14}
\]

对 non-range occurrences 可任意 totalize。给定 \(H_n\) 的 address，先解析 \((j,b)\)。复制 \(q\)
份 \(A_n\)，分别 hardwire \(\ell=1,\ldots,q\)，物化完整 \(u_{n,j}\)；随后运行语法 size
\(S(q)=|G_q|\) 的 \(G_q\)，再用 \(O(q)\) gates 选择第 \(b\) 个 output。于是得到式 (4)。

这个 upper bound 不要求任何单独 block 承载 \(H_n\) 的 hardness，也不使用 JK recursion。
逐 block 的

\[
\forall j\ \exists A_{n,j}
\]

不能推出式 (4)；承重点是同一个 fixed joint accessor \(A_n(j,\ell)\)。

## Decoder exponent window

令

\[
a(n)=n^c,
\qquad
S(q)=q^{d+o(1)},
\qquad
\log T=\Theta(n),
\qquad
k=k(n)\to\infty.
\tag{15}
\]

若 generic JK easy circuit 真能低于 stitched hardness，则必须有

\[
S(q)\log T<n^k.
\tag{16}
\]

若式 (4) 自身已经低于 \(n^k\)，则不需要 JK 就已矛盾。JK 可能增加信息的唯一窗口是式 (5)。
由式 (15)--(16)，忽略 subpolynomial factors，

\[
q\lesssim n^{(k-1)/d}.
\tag{17}
\]

同时，式 (5) 右端必须由 \(q n^c\) 承担，故

\[
q\gtrsim n^{k-c}.
\tag{18}
\]

对任意 fixed \(d>1\) 与 fixed \(c\)，当 \(k(n)\to\infty\) 时，式 (17)--(18) 最终不相容。
所以 polynomially superlinear decoder syntax 没有 distributed-hardness + fixed-polynomial joint
selector 的 generic-JK 参数窗。

更精确地，写 \(d=1+\delta(n)\)。式 (17)--(18) 相容的必要条件是

\[
\delta(n)(k(n)-c)\le c-1+o(1).
\]

所以 \(q^{1+o(1)}\) 只是必要的粗分类；要在 fixed \(c>1\) 下真正保留窗口，需要
\(\delta(n)=O(1/k(n))\)。特别地，\(S(q)=q\operatorname{polylog}q\) 通过这一参数检查。
这仍只给出必要窗口；要真正闭合，还需证明如下 representation-specific 递归命题：给定当前 level 的 fixed-polynomial joint accessor，
或者产生一个具有同尺度 accessor 的 non-image block，或者为下一 level 产生 fixed、word-consistent、
fixed-exponent joint selector，并且 exponent 在 \(O(\log T)\) stages 中不增长。

## 路线裁决

\[
\begin{array}{c|c}
\text{情形}&\text{裁决}\\ \hline
\text{single hard suffix block}&\text{由式 (2) 关闭 small-}q\text{ easy route}\\
\text{连续 }r\text{ 个 hard suffix blocks}&rq\text{ 必须满足式 (3)}\\
\text{arbitrary scattered blocks}&\text{保留 location term，见式 (13)}\\
S(q)=q^{d+o(1)},\ d>1&\text{generic JK 参数窗最终为空}\\
S(q)=q^{1+O(1/k)}&\text{可能有参数窗，仍缺 recursive selector closure}\\
\text{compact top-level / later non-image}&\text{hard branch 仍存活}
\end{array}
\tag{19}
\]

因此下一项最便宜的决定性问题不是 auxiliary PCP 的任意局部优化，而是：是否存在一个 near-linear
stretch map \(G_q:q\to2q\)，使实际 RW/JK histories 的 preimage selection 对 fixed-polynomial joint
accessors 闭合；若不存在，则当前 generic JK 路线关闭到 hard-branch-only。

### 来源与证据边界

原文核验日期：2026-08-14。

- Stasys Jukna, *Boolean Function Complexity: Advances and Frontiers*, 2012 author-posted draft,
  Section 1.4, Theorem 1.15（Lupanov 1958a）。本地全文：
  `ResearchLibrary/lib/jukna2012boolean/jukna2012boolean.pdf`。
- Oliver Korten, *The Hardest Explicit Construction*, FOCS 2021, Definition 4, Theorem 7 and
  Figure 2。其 GGM reconstruction 包含 \(B=G(u)\Rightarrow
  \operatorname{CC}(B)\le |G|+O(q)\) 的单层 folklore bound。
- Hanlin Ren and Ryan Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin-Arthur Queries*, ECCC TR26-118 revision 1, 2026, Theorem 3.1。

式 (2)--(6)、(10)--(19) 是本项目把 Lupanov packing、joint selector composition 与 JK 参数账本
组合后的推论。本文没有证明 near-linear decoder 或 recursive selector closure 存在，也不声称证明
\(P\ne NP\)。
