> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Strong-canonical PCP 仍未把 RW/JK 重构降到地址尺度（2026-08-15）

## 结论

Chen--Li--Liang 的强 canonical Reed--Muller PCP 与 local HSG 确实解决了一个先前的
语义缺口：承诺后的多项式若不是指定的 canonical history，PCP verifier 会按距离
拒绝，因此 commit-and-evaluate 可以保持 single-valued。可是其重构协议在所需参数
范围仍为

\[
  m^{O((\log\log T)^2)},
\tag{1}
\]

而不是对长度为 \(T\) 的 history 的 \(m^{O(1)}\) 地址级算法。这里 \(m\) 是输出/属性
输入长度，\(T\) 是被压缩的确定性计算时间。

这意味着“canonical proof 已解决”与“RW/JK 可以在外部输入长度上运行”是两个不同
命题；前者不能直接推出 \(P\ne NP\)。

## 参数核对

Chen--Li--Liang 的 Theorem 5.1 要求

\[
  n\le m\le T,
  \qquad
  |M|\le \log\log T,
\]

并在 reconstruction 分支给出时间 \(m^{O((\log\log T)^2)}\)。其 Theorem 6.1 的
local HSG 使用低度 Reed--Muller 多项式。证明中可取

\[
  h=m^{100},
  \qquad
  r=\Theta\!\left(\frac{\log T}{\log h}\right),
\tag{2}
\]

其中 \(r\) 是多项式变量数；定理的参数条件还要求

\[
  h^{1/100}\le m.
\tag{3}
\]

所以在保持 field/协议的地址表示为 \(m^{O(1)}\) 的范围内，\(h\) 至多是
\(m^{100}\)，而当

\[
  T=2^{m^{\gamma}}\qquad(\gamma>0\text{ 固定})
\]

时，(2) 给出

\[
  r=\Omega\!\left(\frac{m^{\gamma}}{\log m}\right),
  \qquad
  (1)=m^{O((\log m)^2)}.
\tag{4}
\]

因此，当前 HSG/commit-and-evaluate 架构不能把指数时间 history 自动变成多项式
地址时间。把 \(h\) 增大来压低 \(r\) 会违反 (3) 或把 field/评估成本带回
\(T\)-scale；这只是该架构的参数裁决，不是一般重构下界。

## 它解决了什么、没有解决什么

强 canonical PCP 给出：

1. 正确 history 的 canonical Reed--Muller codeword；
2. 错误承诺若远离 canonical codeword，则被 verifier 以与距离成正比的概率拒绝；
3. 在 HSG 失败时，commit-and-evaluate 对固定承诺提供一致的随机访问值。

它没有给出：

1. 一个 \(q\)-bit deterministic seed \(u\) 使所有 JK 相邻 block 的 preimages 能以
   同一整词规则串接；
2. 一个对 arbitrary RW history block 的 near-linear Boolean decoder；
3. 把 (1) 降成 \(m^{O(1)}\) 的地址级 smart query。

尤其，commitment \(\alpha\) 是协议 transcript 中的 Merlin 消息，不是可直接馈入
固定 \(G_q:\{0,1\}^q\to\{0,1\}^{2q}\) 的 canonical seed。把它硬编码为 seed
会重新引入 witness/advice；把它留在协议中则需要重新证明 JK 的 word consistency
与 smartness。

## 近期低空间重构结果的边界

Pyne--Tell 的 *Composing Low-Space Algorithms*（TR25-140 revision 1）给出一个
不同但有启发性的结果：对长度 \(t=n^d\) 的字符串 \(f\) 和大小 \(n^c\) 的
read-once branching program，若 generator 失败，\(\mathrm{REC}\) 可以在
\(t\,n^{O(1)}\) 时间输出一个描述长度 \(\operatorname{polylog}n\) 的 oracle
machine；该 machine 在索引 \(j\) 上的评估时间仍为 \(n^{O(1)}\)。

这说明“短描述”与“快随机访问”必须分开记账：若把 \(t\) 取为
\(2^{m^{\gamma}}\)，则 \(n=t^{1/d}\) 仍是指数于 \(m\) 的量。该结果针对
logspace/ROBP 结构，也没有把 RW 的一般 PCP history 或 AVOID circuit 变成
poly(\(m\)) 的 word accessor。

## 对 P vs NP 路线的精确含义

当前可保留的正向目标不是“再找一个 canonical PCP”，而是一个更强的替换定理：

\[
\boxed{
\begin{array}{c}
\text{对 }T=2^{m^{\gamma}}\text{ 的 RW canonical history，}\\
\text{在 HSG 失败分支给出 }m^{O(1)}\text{ 的 single-valued、smart、整词一致访问；}\\
\text{并且该访问可嵌入 JK/AVOID 的实际 query。}
\end{array}}
\tag{5}
\]

式 (5) 若成立，才真正消除 note 140 的地址尺度障碍；若只得到 (1) 或
\(n^{O(1)}\)-time short-description machine，仍停留在指数/准多项式外部尺度。

## 文献边界

- Lijie Chen, Jiatu Li, Jingxun Liang, *Maximum Circuit Lower Bounds for
  Exponential-time Arthur Merlin*, ECCC TR24-182, Theorems 5.1、6.1：
  [official report](https://eccc.weizmann.ac.il/report/2024/182/)。
- Edward Pyne, Roei Tell, *Composing Low-Space Algorithms*, ECCC TR25-140
  revision 1, Theorem 2.4：
  [official report](https://eccc.weizmann.ac.il/report/2025/140/)。
- Ren--Williams, ECCC TR26-118 revision 1：
  [official report](https://eccc.weizmann.ac.il/report/2026/118/revision/1/download)。

本 note 是参数与接口边界，不是一般重构下界，也不声称已经证明 \(P\ne NP\)。
