> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 多层 JK tree-capacity 障碍（2026-08-15）

## 定理

令

\[
G:\{0,1\}^{q}\to\{0,1\}^{2q},
\qquad R=\operatorname{Range}(G),
\]

并取 \(A\subseteq R\)。固定 \(h\ge1\)。假设对每一个叶标签
\[
(a_v)_{v\in\{0,1\}^{h}}\in A^{2^h}
\]
都存在一个深度 \(h\) 的二叉 witness tree：

1. 每个叶节点 \(v\) 有 \(q\)-bit seed \(u_v\)，满足 \(G(u_v)=a_v\)；
2. 每个内部节点把左右 child seeds 串接成一个 \(2q\)-bit string，并要求该 string 属于 \(R\)；
3. 每个非根内部节点再选择一个 \(q\)-bit preimage，供上一层继续串接。

则

\[
\boxed{|A|^{2^h}\le |R|\le 2^q.}
\tag{1}
\]

特别地，

\[
\log_2|A|\le \frac{q}{2^h}.
\tag{2}
\]

## 证明

对每个叶标签 tuple 任取一个满足假设的 witness tree，并令
\(\Phi_h(a_v)\in R\) 是其根部由两个 child seeds 串接得到的 \(2q\)-bit root block。
证明 \(\Phi_h\) 在 \(A^{2^h}\) 上 injective。

若两个 leaf tuples 的 root blocks 相同，则它们的前、后 \(q\) bits 分别相同，所以两个
root child seeds 相同。对相同 seeds 应用 \(G\)，得到两个 root child blocks 相同；再对
每个 child 重复同一论证。递归到底层后，所有 leaf seeds 相同，再应用 \(G\) 得到所有
leaf labels 相同。因此不同 leaf tuples 不会映到同一个 root block，式 (1) 成立。

该证明允许不同 leaf tuples 使用完全不同的 preimage choices；不要求 lex-first、canonical
selector 或同一个全局 inverse。

## Junta 等号端点的递归饱和

令 \(\operatorname{BExp}_{q,h}\) 表示同一递归的代数 leaf expansion：
\(\operatorname{BExp}_{q,0}(u)=G(u)\)，且若
\(G(u)=u^L\Vert u^R\)，则
\(\operatorname{BExp}_{q,h+1}(u)
=\operatorname{BExp}_{q,h}(u^L)\Vert
\operatorname{BExp}_{q,h}(u^R)\)。只有在额外要求 whole-tree validity 时，才要求其中
的内部 \(2q\)-bit blocks 也属于 \(R\)。

上面的容量式在等号处还有一个不能忽略的加强。固定整数 \(1\le r\le m\)，令
\(\mathcal J_{m,r}\) 为所有忽略同一组 \(r\) 个输入变量的 \(m\)-变量函数的 truth tables。由于
\(2q=2^m\)，有

\[
\lvert\mathcal J_{m,r}\rvert
 =2^{2^{m-r}}
 =2^{q/2^{r-1}}.
\tag{2a}
\]

取 \(h=r-1\)，则

\[
\lvert\mathcal J_{m,r}\rvert^{2^h}=2^q.
\tag{2b}
\]

因此，如果不是只假设“所有 tuple 都有某种抽象 witness”，而是确实有

\[
\mathcal J_{m,r}^{\,2^h}
 \subseteq \operatorname{Range}(\operatorname{BExp}_{q,h}),
\tag{2c}
\]

那么 \(\operatorname{BExp}_{q,h}\) 的 domain 与式 (2c) 的 target 已经同样大，必有

\[
\operatorname{Range}(\operatorname{BExp}_{q,h})
 =\mathcal J_{m,r}^{\,2^h},
\qquad
\operatorname{BExp}_{q,h}\text{ 在这些 outputs 上为双射}.
\tag{2d}
\]

证明只是有限集计数：每个 target string 至少需要一个 root seed，而 root seed 总数正好为
\(2^q\)。若 (2c) 还要求 JK 的每个内部节点都落在同一 \(R=\operatorname{Range}(G)\)，则
每个 seed 都被 valid witness 用尽；再加入任意一个额外 leaf block，或要求任意一个超出
\(\mathcal J_{m,r}^{\,2^h}\) 的 tuple，都会把所需 distinct roots 提升到 \(>2^q\)，从而
立即产生 non-image。

这不是对 concrete RW history 的丰富性证明；它是 whole-tree normalization 在 junta endpoint
上的精确饱和边界。特别地，任何声称在该端点同时保留“全 tuple closure”和一个非平凡 hard
branch 的表示，都必须明确指出它放弃了 (2c) 的全树覆盖，或改变了 root seed 长度。

## 与 JK 多层 history 的关系

Ren--Williams Theorem 3.1 的每个 stage 都执行相邻 preimage 的串接。于是，若某个候选
representation class 声称对 \(A\) 的**所有** \(2^h\)-叶组合都能连续保持在同一 range，
它必须满足式 (1)。因此只要

\[
2^h\log_2|A|>q,
\tag{3}
\]

这种 universal \(h\)-level closure 就不可能。

这不是对一条 concrete JK history 的自动断言。实际输入 \(f\) 只产生一个叶序列；要触发式
(3)，必须另外证明该 history 的 leaf tuples 足够丰富，或显式构造一个 pair/tree-rich
prefix。具体地，若 JK 顶层有至少
\(2^h|A|^{2^h}\) 个 blocks，可以把每个
\(A^{2^h}\) leaf tuple 放在一个连续的 \(2^h\)-block group 中，其余 blocks 填入零表。
所有顶层 blocks 都在 \(R\)；若所有后续 stages 也在 \(R\)，则每个 group 产生一个 root
block，且上面的 injectivity 给出 \(|A|^{2^h}\) 个不同 roots。只要该数超过 \(2^q\)，
某个 group 必在深度至多 \(h\) 处产生 outsider。note 105 是 \(h=1\) 的特例。

## 对低复杂度 truth tables 的尺度

令 \(N=2^m=2q\)，并取一个能嵌入 \(m\) variables 的 Lupanov family。对
\(s\) 足够大且 \(m\ge\log_2(s\log s)+O(1)\)，存在常数 \(c>0\) 和 family
\(A_s\subseteq\mathcal C_{m,s}\) 满足

\[
\log_2|A_s|\ge c\,s\log_2 s.
\tag{4}
\]

因此 universal \(h\)-level closure 必须满足

\[
2^h\,s\log s=O(q).
\tag{5}
\]

例如令

\[
s=\frac{q}{\log^{1+\varepsilon}q},
\qquad \varepsilon>0\ \text{固定}.
\]

则 \(s\log s=\Theta(q/\log^\varepsilon q)\)，取

\[
h=\left\lceil \varepsilon\log_2\log q\right\rceil+O(1)
\]

就违反式 (5)。换言之，在这个仍未被一层 counting 排除的 near-linear window 中，
一个对所有 covered low-circuit tables 都可递归 \(h\) 层的 universal representation class
仍然不可能；\(h\) 只需 \(O(\log\log q)\)。

这正是 JK 的尺度分离：若允许选择足够长的 truth-table input，使 stage depth 超过该
\(O(\log\log q)\)，则**全覆盖 + 全树 closure** 架构必在某一层产生 outsider。它没有说明
Ren--Williams 的单个 PCP history 已包含这些所有 leaf combinations。

## 路线含义

当前可证明的分层是：

\[
\begin{array}{c|c}
\text{假设} & \text{状态}\\ \hline
\text{覆盖 low-circuit tables} & \text{near-linear window 仍可能存在}\\
\text{对所有 covered tables 的一层 closure} & \text{式 (2) 排除大 coverage}\\
\text{对所有 covered tables 的 }h\text{-level closure} & \text{式 (3)--(5) 排除更宽窗口}\\
\text{某一固定 RW/JK history 的 rich-tree witness} & \text{仍 unknown}
\end{array}
\]

所以下一决定性问题不是继续加强 universal counting，而是二选一：

1. 从 RW encoded PCP history 证明实际 leaf tuples 的丰富性，并把式 (1) 转成 concrete
   non-range block；或
2. 构造一种只对单一 history 适用、但能保持 \(n^C\) joint accessor 的非 universal
   normalization。

两条路线都没有给出 \(P\ne NP\)；它们只精确化了“whole-tree labeling”必须逃离的容量边界。

### 来源与证据边界

- Ren--Williams, ECCC TR26-118 revision 1, Theorem 3.1：相邻 preimage 的 stage-wise
  concatenation。
- note 105：一层 pair-lift capacity 与 pair-rich prefix。
- Lupanov family：ResearchLibrary 中 Jukna (2012) Theorem 1.15。

式 (1)--(5) 为本项目自足推导；不把 universal closure no-go 外推为 actual-history lower
bound 或 \(P\ne NP\)。
