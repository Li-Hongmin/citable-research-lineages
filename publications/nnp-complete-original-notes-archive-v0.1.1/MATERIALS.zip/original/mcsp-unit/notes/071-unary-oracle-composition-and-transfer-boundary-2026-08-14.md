> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 候选公式 refuter 的 unary 组合、truth-table 降阶与转移边界（2026-08-14）

## 结论

令 [note 070](070-ops-candidate-formula-oracle-refuter-2026-08-14.md) 中的参数为

\[
N=2^n,\qquad s_0(n)=n^d,\qquad
t(n)=2^{(\alpha/2-o(1))n}.
\tag{1}
\]

该构造有三个此前未分开的统一化层次。

1. 对显式 P-uniform 的 \(U_2\)-formula 生成器 \(G(1^N)=F_N\)，组合

   \[
   R_G(1^N):=\operatorname{OPSRef}(1^N,G(1^N))
   \tag{2}
   \]

   是一个只接收 \(1^N\) 的 \(\mathrm{ZPP}^{NP}\) refuter；因此“输入含 \(F\)”本身并不
   阻止 unary refutation。对任意非一致序列 \(\{F_N\}\)，则一般只能保留候选描述输入，
   或写成带 \(F_N\) advice 的 \(\mathrm{ZPP}^{NP}/\mathrm{poly}\) 过程。

2. 若不以 NP oracle 验证最终随机 completion 的 circuit complexity，则所有 semantic-support
   查询可一次并行提交。这给出 candidate-description

   \[
   \mathrm{BPP}^{NP}_{tt}
   \tag{3}
   \]

   refuter。零错误版本的每次试验需要第二轮 NP 查询；它不是
   \(\mathrm{FP}^{NP}_{tt}\)-searchSAT。

3. 在严格子区间 \(1<\alpha<2\)，甚至不需要 OPS restriction 或 semantic-support
   查询。给定公式的语法 support 只有至多 \(N^{2-\alpha}=o(N)\) 个坐标；把这些坐标固定为
   \(0\)，在其余坐标随机补全，便直接得到同值 easy--hard pair。于是该区间有

   \[
   \text{candidate-description }\mathrm{BPP}
   \quad\text{及}\quad
   \mathrm{SearchZPP}^{NP}\text{（只作最终 circuit-existence 查询）}.
   \]

当前可核验的转移定理均不能使用这些算法。最薄的剩余失配是

\[
\boxed{\mathrm{BPP}\text{ / }\mathrm{BPP}^{NP}_{tt}\text{ / }\mathrm{ZPP}^{NP}}
\quad\xrightarrow[\text{尚无可适用定理}]{\ ?\ }\quad
\boxed{\mathrm{polylog\text{-}uniform\ AC}^0[\mathrm{qpoly}]}
\quad\text{或指定的 uniform }\mathrm{AC}^0\text{ Student--Teacher 接口}.
\tag{4}
\]

所以本 note 修正“候选输入绝不能 unary 化”以及“全部参数都需要 support oracle”的过强读法，
但不产生 \(P\ne NP\)。
下文的 \(\mathrm{ZPP}^{NP}\) refuter 按 CJSW 的 randomized-refuter 语义理解：每条成功路径
可以输出不同的合法反例；它是一个多值零错误 search relation，不是标准 single-valued
\(\mathrm{FZPP}^{NP}\) function。

## unary 组合命题

设 \(G\) 是一个确定性 polynomial-time 生成器；在每个充分大的 \(N=2^n\) 上，
\(G(1^N)\) 输出 size 至多 \(N^{2-\alpha}\) 的 \(U_2\)-formula \(F_N\)。令

\[
A_G(x):=G(1^{|x|})(x)
\]

表示先生成相应公式再评价它的算法。对任意

\[
s_0(n)\le s'(n)<t(n),
\tag{5}
\]

式 (2) 以期望 \(\operatorname{poly}(N)\) 时间输出 \(x\in\{0,1\}^N\)，且

\[
F_N(x)\ne\operatorname{MCSP}[s'(n)](x).
\tag{6}
\]

事实上，note 070 的构造总得到一对满足

\[
\operatorname{CC}(y)\le s_0(n),\qquad
\operatorname{CC}(z)>t(n),\qquad
F_N(y)=F_N(z)
\tag{7}
\]

的 completion。若共同值为 \(0\)，取 \(x=y\)；若共同值为 \(1\)，取 \(x=z\)。
式 (5) 立即给出 (6)。生成 \(F_N\)、运行 refuter 和评价 \(F_N\) 都是
\(\operatorname{poly}(N)\) 时间，故组合仍是一个 \(\mathrm{SearchZPP}^{NP}\) relation solver。
若采用常数次并行试验并允许
输出 \(\bot\)，则得到 CJSW 意义自然延伸下的 \(\mathrm{ZPP}^{NP}\) refuter。

这也表明 YES 阈值不必固定为 \(n^d\)。例如可取

\[
s'(n)=2^{\lfloor\sqrt n\rfloor}
      =2^{\lfloor\sqrt{\log N}\rfloor},
\tag{8}
\]

它仍远小于 \(t(n)\)。更明确地，忽略不影响渐近量级的取整，
\[
2^{\sqrt n}=n^{\sqrt n/\log_2 n},
\qquad
\frac{\sqrt n/\log_2 n}{(\log n)^c}\longrightarrow\infty
\quad(\forall c>0).
\]
所以其指数属于 \((\log n)^{\omega(1)}\)，达到
Chen--Jin--Santhanam--Williams Proposition 4.3 所需的 super-quasipolynomial MCSP 阈值。
因此该 proposition 的障碍不是参数 (1)，而是 refuter 复杂度 (4)。

注意 CJSW Definition 1.1 允许 refuter 依赖被 refute 的算法。故固定 \(G\) 后
\(\forall G\,\exists R_G\) 的量词形状是合法的，且 \(R_G\) refute 的正是 \(A_G\)；不合法的是
把任意非一致 \(\{F_N\}\) 的无限描述硬连线进一个有限的 uniform machine。这只覆盖上述受限
formula-generator 类，不是对一般 P 或一般 circuit class 的 constructive separation。

## \(1<\alpha<2\)：语法 support 直接给出无 oracle 的 BPP refuter

令 \(\operatorname{supp}_{\mathrm{syn}}(F)\) 为给定 \(U_2\)-formula 描述的叶标签中出现的
不同输入变量，并记

\[
r_F=|\operatorname{supp}_{\mathrm{syn}}(F)|,\qquad
D=N-r_F,\qquad
\ell_t=\left\lceil A\,t(n)\log_2(t(n)+n+2)\right\rceil ,
\]

其中 \(2^{\ell_t}\) 上界 size-\(t(n)\) truth tables 的数目。OPS 以叶数定义 formula size，
所以

\[
r_F\le |F|\le N^{2-\alpha}.
\]

只要 \(D>\ell_t\)，无需抽 restriction即可得到下面的计数界和 Las Vegas 算法。取 \(y=0^N\)；在
\(\operatorname{supp}_{\mathrm{syn}}(F)\) 上仍令 \(z_i=0\)，在其余 \(D\) 个坐标上均匀
采样 \(z\)。于是

\[
\operatorname{CC}(y)=O(1)\le s_0(n),\qquad
F(z)=F(y),
\]

并且即使已固定 support 坐标，

\[
\Pr[\operatorname{CC}(z)\le t(n)]
\le 2^{\ell_t-D}.
\]

因此：

- 若 \(F(y)=0\)，确定性输出 \(y\)；
- 若 \(F(y)=1\) 且 \(D-\ell_t\ge2\)，直接输出一次 \(z\) 是 BPP refuter，唯一失败事件是
  \(\operatorname{CC}(z)\le t(n)\)（YES 区与 promise gap 都含在这个事件内），其概率至多
  \(1/4\)；
- 零错误版本只在 \(F(y)=1\) 时询问最终的
  \([\operatorname{CC}(z)\le t(n)]\in NP\)：NO 时输出 \(z\)，YES 时重采。

单次带 \(\bot\) 版本只有一个最终 NP query；重复至成功的 Las Vegas search 跨失败 trial
是自适应的，但期望 query 数至多

\[
\bigl(1-2^{\ell_t-D}\bigr)^{-1}.
\]

固定 \(1<\alpha<2\) 时，

\[
r_F\le N^{2-\alpha}=o(N),\qquad
\ell_t=O(N^{\alpha/2})=o(N),
\]

故 \(D-\ell_t=N-o(N)\)，BPP 错误为 \(2^{-N+o(N)}\)，Las Vegas 期望 query 数为
\(1+o(1)\)。扫描叶标签、评价 \(F(0^N)\) 和采样 completion 都可在
\(\operatorname{poly}(N,|F|)\) 时间完成。对 P-uniform \(G\) 再与生成器组合，得到 unary
BPP 或 unary 多值 \(\mathrm{SearchZPP}^{NP}\) refuter。

输出 \(z\) 仍随随机路径改变，故这个简化不产生 single-valued
\(\mathrm{FZPP}^{NP}\)。[note 073](073-hard-truth-table-search-apepp-single-valued-boundary-2026-08-14.md)
说明独立的 canonical AVOID 定理确实能选择固定 hard table，但它不保证该表与任意 \(F\)
在某个 low input 上同值。

## 非自适应随机版本

以下是覆盖全部 \(0<\alpha<2\) 的 OPS restriction 版本；在 \(1<\alpha<2\) 时上一节更强。
固定常数 \(L\)。预先抽取 \(L\) 个 restriction seeds。对每个试验、每个自由坐标 \(i\)，并行询问

\[
i\in W
\iff
\exists a:\
F(\rho[a,i\leftarrow0])\ne F(\rho[a,i\leftarrow1]).
\tag{9}
\]

所有查询只依赖 \((F,\rho,i)\)，故组成一个 truth-table NP query batch。收到答案后计算
\(S=V\setminus W\)。若

\[
|V|\ge p_0N/2,
\qquad
|S|\ge p_0N/2-M,
\tag{10}
\]

则按 note 070 随机补全 \(S\) 并输出对应的 \(y\) 或 \(z\)，但不询问
\(\operatorname{CC}(z)\le t\)。

OPS shrinkage 只用于保证单次试验满足 (10) 的概率至少 \(2/5\)。一旦 (10) 成立，
semantic support 的定义无条件给出 \(F(y)=F(z)\)，而计数界给出

\[
\Pr[\operatorname{CC}(z)\le t\mid \rho,W,S]
\le 2^{-|S|/2}.
\tag{11}
\]

若所有试验都未通过 (10)，则输出任意 \(N\)-bit string。取充分大的常数 \(L\)；由各试验独立性，
输出不是反例的概率至多
\[
(3/5)^L+L\cdot2^{-\Omega(2^{\alpha n/2})}<1/3.
\tag{12}
\]
于是对所有充分大的 \(n\) 得到 (3)。

若要求每个非 \(\bot\) 输出都严格正确，则需在得到 \(z\) 后再询问
\(\operatorname{CC}(z)\le t\)。该查询依赖第一批 support answers，故每次试验是两轮 NP 查询；
重复到成功的 Las Vegas wrapper 仍是自适应的 \(\mathrm{SearchZPP}^{NP}\) relation solver。

## 为什么不能转成现有强分离

### CJSW 的 MCSP refuter

CJSW Proposition 4.3 只需 refute constant-one algorithm，但要求 refuter 本身是

\[
\text{polylogtime-uniform }\mathrm{AC}^0
\text{、quasipolynomial size、输入仅 }1^N.
\tag{13}
\]

这里的三种尺度不能混同。refuter 的 circuit size、显式总输出长度和枚举时间是
\(N\) 的 quasipolynomial；其证明在假设 \(P=NP\) 下，把每张输出表的 circuit complexity
压成
\[
2^{(\log\log N)^{O(1)}}
\]
，即 \(n=\log N\) 的 quasipolynomial。MCSP threshold 则须是 \(n\) 的
super-quasipolynomial，等价地在 \(N\)-记号下至少为
\(2^{(\log\log N)^{\omega(1)}}\)。式 (8) 满足这一点。

Proposition 4.3 后的 list-refuter 扩展只要求显式列表中有一张反例表，不要求有效选出它；
单表是 singleton list。所有高表保证和阈值比较必须发生在同一个无限长度子序列上。
式 (2) 的 NP oracle、随机限制和随机 completion 都不属于 (13)；CJSW 的压缩论证也不适用于一般
\(\mathrm{ZPP}^{NP}\) 输出。

令 \(F\equiv1\) 不修复此点。此时随机输出一张高 circuit-complexity truth table 本来就是
普通 BPP 可做的计数事实；突破性前提是以 (13) 的极弱 uniform circuit 生成该表，而不是以
随机性或 NP oracle 生成它。[note 073](073-hard-truth-table-search-apepp-single-valued-boundary-2026-08-14.md)
进一步核实：现有 canonical AVOID 定理已经能在 single-valued
\(\mathrm{FS}_2^P/\mathrm{FZPP}^{NP}\) 中选择一张固定 hard table。故 advice、全长度与
single-valuedness 也不是 constant-one 情形的缺口；首先失配的是 (13) 的低深度计算模型。

### constant-one 已使 deterministic completion 成为突破级前提

对 good restriction \(\rho\)，令 \(W\) 为 semantic support，\(S=V\setminus W\)。若想通过
枚举 completion 去掉随机性，所需的最小性质是由同一个跨长度 uniform family 显式输出总长度
quasipolynomial 的集合

\[
H_{n,F,\rho}\subseteq\{0,1\}^{S}
\]

并保证其中某个 \(u\) 满足

\[
\operatorname{CC}\!\left(\rho[W\leftarrow0,S\leftarrow u]\right)>t(n).
\tag{14}
\]

枚举 \(y_\rho=\rho[V\leftarrow0]\) 与这些 completion 后，无需评价 \(F(y_\rho)\)：共同值为
\(0\) 时 \(y_\rho\) 是反例，共同值为 \(1\) 时 (14) 中的 completion 是反例。

但取合法的常数公式 \(F_{\mathbf 1}\equiv1\) 时，\(W=\varnothing\)。任何满足 (13)--(14) 的
deterministic list construction 已经显式包含一张 complexity \(>t(n)\) 的 truth table。再取
式 (8) 的 exact MCSP threshold，便直接成为 CJSW constant-one list-refuter，推出 \(P\ne NP\)。
因此缺口不是一个普通 PRG fooling 引理，也不是一般意义下 canonical 地逃离 range；它要求在
(13) 的极弱模型中逃离所有 size-\(t\) circuit truth tables。
若一个小种子 generator 的每个固定 seed 输出本身都有 size \(<t\) 的 address circuit，它尤其不可能
满足 (14)。

### Ren--Williams 的 searchSAT 假设

Ren--Williams Theorem 5.1 的假设是确定性的全域 search reduction：

\[
\mathrm{searchSAT}\in\mathrm{FP}^{NP}_{tt}.
\tag{15}
\]

式 (3) 是随机算法；其输入是受 size 限制的候选 MCSP formula 描述；其输出是该候选的
counterexample truth table。它既不接收任意 SAT formula，也不输出 satisfying assignment，且没有
把 (9) 的 oracle answers 编码为同长度 SAT witness 的归约。因此，式 (3) 并未满足 (15) 的假设；
准确的接口关系是

\[
\underbrace{\mathrm{BPP}^{NP}_{tt}\text{-candidate refutation}}_{\text{随机、受限候选输入、输出反例}}
\quad\ne\quad
\underbrace{\mathrm{FP}^{NP}_{tt}\text{-searchSAT}}_{\text{确定性、任意 SAT 输入、输出见证}}.
\tag{16}
\]

### Student--Teacher 接口

Grosser--Carmosino Definition 3.1 与 Theorem 3.3 所用的 Teacher 针对

\[
\Phi_b(X)\equiv
\forall D\ (|D|\le n^b\Longrightarrow \operatorname{TT}(D)\ne X).
\]

对一次候选 \(X\)，其 feedback 为

\[
CX_b(X)=
\begin{cases}
\mathrm{YES},&\operatorname{CC}(X)>n^b,\\
D,&|D|\le n^b\text{ 且 }\operatorname{TT}(D)=X.
\end{cases}
\tag{17}
\]

Theorem 3.3 要求 \(S(1^N,b)\) 是确定性的 polylogtime-uniform
\(\mathrm{AC}^0[\mathrm{qpoly}]\) Student，\(b\) 以二进制给出，总共只调用 \(CX_b\)
常数次，并在规定的无限参数族上解 \(\mathrm{SIZE}[n^b]\)-Avoid。

对覆盖全部 \(0<\alpha<2\) 的 OPS restriction 算法，最终 circuit-existence query 在阈值降到
\(n^b\) 后可由 (17) 承担；但 semantic-support query

\[
Q_i(F,\rho)\equiv
\exists a:\ F(\rho[a,i\leftarrow0])\ne F(\rho[a,i\leftarrow1])
\tag{18}
\]

不是这种 feedback。令
\(D_i(a)=F(\rho[a,i\leftarrow0])\oplus F(\rho[a,i\leftarrow1])\)。当
\(F(a,i)=i\) 时，\(Q_i=1\) 而 \(D_i\equiv1\)；当 \(F\equiv0\) 时，\(Q_i=0\) 而
\(D_i\equiv0\)。两种情形中 Teacher 都只看到一个常数大小 circuit，不能据此判定 \(Q_i\)。
而且 \(N\) 个非自适应 NP queries 不是常数次 Teacher calls；随机的
\(\mathrm{BPP}^{NP}_{tt}/\mathrm{ZPP}^{NP}\) Student 也不是所需的 deterministic uniform
\(\mathrm{AC}^0\) Student。在 \(1<\alpha<2\) 时语法-support 算法已经消掉这些 queries，
但它仍是随机 polynomial-time 生成器，不是 deterministic uniform \(\mathrm{AC}^0\) Student。
即使令 \(F\equiv1\)，canonical AVOID 也只把生成器降到
\(\mathrm{FS}_2^P/\mathrm{FZPP}^{NP}\)，仍遇到上一小节的计算模型障碍。因此 note 071
不能直接满足 Theorem 3.3 的前提；这里排除的是直接接口代入，不声称排除未来所有非黑盒归约。

## 路线裁决

notes 070--071 的 candidate refuter 可精确分层为

\[
\begin{array}{c}
\text{全部 }0<\alpha<2:\quad
\mathrm{BPP}^{NP}_{tt}\text{（bounded error）},\quad
\mathrm{SearchZPP}^{NP}\text{（zero error）},\\[1mm]
1<\alpha<2:\quad
\mathrm{BPP}\text{（bounded error）},\quad
\mathrm{SearchZPP}^{NP}\text{（只作最终 CC query）},\\[1mm]
\text{P-uniform candidate family}:\quad
\text{相应的 }1^N\text{-only unary refuter}.
\end{array}
\tag{19}
\]

但已核验的 CJSW、Ren--Williams、Atserias--Müller、Pich--Santhanam、
Grosser--Carmosino 与 CDJ 接口都要求 (19) 没有提供的低复杂度生成、一般 searchSAT、approximate-MCSP
语言级 uniform lower bound、同长度 SAT witnessing，或 affine-disperser 性质。故本脉冲在此停止：
保留 (19) 作为精确 randomized candidate construction，不把它报告为 \(P\ne NP\)，下一主线不再
尝试纯接口重命名。

## 来源

- [note 070](070-ops-candidate-formula-oracle-refuter-2026-08-14.md)：算法、OPS 参数、semantic
  support 与计数界。
- Lijie Chen, Ce Jin, Rahul Santhanam, and R. Ryan Williams, *Constructive Separations and
  Their Consequences*, TheoretiCS 3 (2024), Definition 1.1, Lemma 2.5, Proposition 4.3；全文：
  `ResearchLibrary/lib/williams2024constructive/fulltext.md`。
- Hanlin Ren and R. Ryan Williams, *Near-Maximum Circuit Lower Bounds from Weak
  Derandomization*, 2026, Theorem 5.1；全文：
  `ResearchLibrary/lib/ren2026near/fulltext.md`。
- Stefan Grosser and Marco Carmosino, *Student-Teacher Constructive Separations and
  (Un)Provability in Bounded Arithmetic: Witnessing the Gap*, STOC 2025, Definition 3.1 与
  Theorem 3.3，DOI: `10.1145/3717823.3718216`。截至 2026-08-14 已通过 ACM eReader 的
  free-access proceedings 全文核对；ResearchLibrary 当前仅缓存 metadata：
  `ResearchLibrary/lib/stefangrosser2025student/info.yaml`。
- [note 064](064-atserias-muller-uniform-magnification-interface-2026-08-14.md) 与
  [note 069](069-extended-frege-same-length-witnessing-boundary-2026-08-14.md)：另外两个不匹配的
  uniform / same-length transfer 接口。
- [note 072](072-gapmcsp-affine-disperser-gate-elimination-boundary-2026-08-14.md)：GapMCSP 的
  高维单色 affine subspace、CDJ corollary 的参数无交叠与常值-\(0\) 后处理反例。
