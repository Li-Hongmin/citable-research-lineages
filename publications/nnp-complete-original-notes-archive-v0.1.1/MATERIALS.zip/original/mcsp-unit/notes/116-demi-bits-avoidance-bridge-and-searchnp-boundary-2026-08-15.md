> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Demi-bits 到 Range Avoidance 的条件性桥梁（2026-08-15）

## 文献事实

Ren--Wang--Zhong, ECCC TR25-191 的主定理给出：若存在

$$
G:\{0,1\}^{a}\longrightarrow\{0,1\}^{10a}
$$

的 demi-bits generator，则 Range Avoidance 不属于 `SearchNP`。这里的 `SearchNP` 是允许
非确定性分支、但要求每条接受分支都输出合法非像的搜索类；它不等同于 `FNP`，所以该
定理不能直接改写成 $P\ne NP$。该文还证明了适当 stretch 的 demi-bits 可导出
proof-complexity generator，并指出 truth-table generator 是 Rudich 型假设下的候选
demi-bits generator。

本文只把这些陈述作为原始文献支持的条件性桥梁，不把密码学假设或 proof-complexity
结论当作一般电路下界。

## Demi-bits 安全性本身蕴含的条件性分离

这里有一个不依赖 Avoid 定理的简单推论。对任意可由多项式大小电路计算的伸展映射

$$
G_a:\{0,1\}^{a}\to\{0,1\}^{b(a)},\qquad b(a)>a,
$$

其 range membership 属于 NP：证书是 seed，验证只需计算 $G_a$。若假设 $P=NP$，则
range 的补集属于 P。于是可以定义一个多项式大小的 adversary

$$
\operatorname{Adv}(y)=1\iff y\notin\operatorname{Range}(G_a).
$$

它在所有 generator 输出上为 0，而在均匀 $b(a)$-bit 输入上的接受率至少

$$
1-2^{a-b(a)}.
$$

因此，只要 demi-bits 安全性要求抵抗的 NP/poly 大小超过这个判定器的多项式规模，
该安全性就直接蕴含 $P\ne NP$。这只是“安全性假设 $⇒$ 分离”，不是对 truth-table
generator 安全性的证明；真正困难的正是证明这个补集判定器不存在于相应的 adversary 类。

## 与当前 decoder 参数的精确对应

对 $N=2q=2^m$，取 $m$-input、size-$s$ 电路的固定 gate-list truth-table map。一个具体
拓扑 gate-list 编码的长度满足

$$
r_{m,s}=O\bigl(s\log(m+s+2)\bigr).
$$

若 $s\le q/(K\log q)$，则 $r_{m,s}\le q$（取 $K$ 足够大），把描述零填充到 $q$ 位后得到
一个

$$
\mathrm{TT}_{m,s}^{\mathrm{pad}}:\{0,1\}^{q}\to\{0,1\}^{2q}
$$

的 stretch-2 truth-table generator。它正处在本项目的 near-linear-covering decoder 窗口：
seed 与 output 都是 $\Theta(q)$，而 coverage 包含全部 size-$s$ 真值表。

但这里有三个不能跳过的区别：

1. TR25-191 的 Avoid 定理要求 stretch-10 demi-bits（或相应的 extractor/hash 组合），
   不能仅由 stretch-2 的 coverage 性质推出；
2. “truth-table map 是候选 demi-bits”是 Rudich 型条件性判断，不是已证安全性；
3. `Avoid ∉ SearchNP` 是搜索复杂度结论，不是固定 truth-table range 的
   $N^{1+\varepsilon}$ 电路下界。

因此当前最强可核验定位是：

$$
\boxed{\text{near-linear TT decoder + demi-bits 安全性}}
\quad\Longrightarrow\quad
\text{条件性 SearchNP-Avoid 障碍},
$$

而 coverage 本身仍不产生 $P\ne NP$ 或一般 decoder lower bound。

这条桥梁把“近线性 truth-table generator”与密码学/证明复杂度的已知障碍接上，但没有
缩短本项目的无条件缺口：仍需构造或排除 $q\operatorname{polylog}q$ 的 unrestricted
batch decoder，并处理 JK 所需的 whole-tree normalization。

## 来源与证据边界

- Hanlin Ren, Yichuan Wang, Yan Zhong, *Hardness of Range Avoidance and Proof Complexity
  Generators from Demi-Bits*, ECCC Report TR25-191 (2025), 官方全文：
  <https://eccc.weizmann.ac.il/report/2025/191/>。
- 本 note 的参数换算是项目内推导；其只证明 description-length 对齐，不证明两个 map
  相同，也不证明任何 demi-bits 假设。
