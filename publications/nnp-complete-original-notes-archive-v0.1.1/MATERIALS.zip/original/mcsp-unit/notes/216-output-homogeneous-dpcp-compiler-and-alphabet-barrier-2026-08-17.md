> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Output-homogeneous dPCP compiler and the target-alphabet barrier (2026-08-17)

## Summary

There is one clean positive way to use ordinary dPCP list soundness for a
shared-proof coordinate check.  The valid-word language must carry a
target-oblivious output projection that is the same at every decoded position.
Then a locally decoded symbol with the wrong projected value cannot belong to
any list word, so list soundness becomes fixed-claim soundness without a
singleton list and without choosing a different proof for each coordinate.

The same observation gives a sharp obstruction.  If one common
target-oblivious symbol channel must carry \(M\) different global output
words, its alphabet has size at least \(M\).  Thus the compiler is useful for
one bit or a constant-size output alphabet, but it cannot hide a \(k\)-bit
target in a fixed alphabet.  This is an output-channel theorem, not a
completed RW address-scale construction.

## The output-homogeneous compiler

Let \(\mathcal D\) be a dPCP for a language
\(\mathcal L\subseteq\Sigma_0^n\).  Write its left decoder as
\[
  D_t:A\longrightarrow\Sigma_0,\qquad t\in[n],
\]
and let \(\mathcal P_t\) be the usual edge distribution.  Assume there is a
target-oblivious projection
\[
  \pi_t:\Sigma_0\longrightarrow\Gamma
\]
for every \(t\), and a target \(m\in\Gamma\), such that
\[
  \pi_t(w_t)=m
  \qquad
  \text{for every }w\in\mathcal L\text{ and every }t\in[n].
  \tag{OH}
\]
The maps \(\pi_t\) are part of the public verifier and do not depend on the
chosen valid word.

For a claimed symbol \(b\in\Gamma\), define \(V_b\) by sampling
\(t\leftarrow[n]\), sampling \(e=(a,c)\sim\mathcal P_t\), checking the dPCP
constraint on the two queried symbols, and accepting exactly when
\[
  \pi_t(D_t(T_A[a]))=b.
\]
The verifier uses the same proof/address space as \(\mathcal D\) and makes the
same two proof queries.

### Theorem 1 (output-homogeneous dPCP compiler)

Suppose \(\mathcal D\) has perfect completeness and
\((L,\varepsilon)\)-list-decoding soundness.  Under (OH), the verifier \(V_b\)
satisfies

1. **perfect completeness:** the branch \(b=m\) accepts with probability one on
   every satisfying assignment;
2. **target-relative wrong-claim soundness:** for every left assignment
   \(T_A\) and every right assignment \(T_B\),
   \[
   \Pr[V_b(T_A,T_B)\text{ accepts}]\le\varepsilon
   \quad\text{for every }b\ne m.
   \tag{1}
   \]

The list size \(L\) does not appear in (1).  If \(\Gamma=\{0,1\}\), this is a
simultaneous two-branch coordinate-robust verifier with locality two and gap
\(1-\varepsilon\), provided the target-relative neighborhood is supplied by
the surrounding code/proof interface.  “Simultaneous” here means that every
decoded position \(t\) uses the same proof and the same target bit; it does not
mean that a fixed finite alphabet already carries \(k\) independent output
coordinates.

#### Proof

Fix \(T_A\).  By list soundness there are \(w^{(1)},\ldots,w^{(L)}\in\mathcal L\)
such that
\[
\Pr_{t,e}\!\left[
  \Phi_e(T_A[a],T_B[c])=1
  \ \land\
  D_t(T_A[a])\notin\{w^{(j)}_t:j\in[L]\}
\right]\le\varepsilon.
\]
If the verifier accepts a wrong claim \(b\ne m\), then
\(\pi_t(D_t(T_A[a]))=b\).  By (OH), every listed symbol
\(w^{(j)}_t\) has projection \(m\), so the decoded symbol cannot equal any
\(w^{(j)}_t\).  The wrong-claim event is therefore contained in the displayed
list-soundness error event.  Completeness is immediate from a satisfying
assignment and (OH). \(\square\)

The theorem is stronger than a singleton-list assumption in one narrow sense:
the list may contain many different hidden witnesses, as long as their public
output projection is identical.  It is weaker than a general simultaneous
multi-output theorem because (OH) asks one common projection at every dPCP
position.

## Coded output projection

The alphabet obstruction applies only when the whole target is placed in one
symbol.  A codeword projection spreads the target across positions and gives a
second, more useful positive interface.

Let
\[
  C:\{0,1\}^k\longrightarrow\Gamma^M
\]
have an adaptive \(q_D\)-query decoder \(\mathsf{Dec}_i\) for each message
coordinate \(i\).  Assume perfect completeness and that, on the honest
codeword \(C(m)\), every query step is \(\lambda\)-smooth:
\[
  \Pr[\text{the next query is }j\mid\text{all previous answers are honest}]
  \le \frac{\lambda}{M}. \tag{4}
\]

### Theorem 2 (coded output-homogeneous dPCP compiler)

Suppose the dPCP language has a fixed instance \(x\), target
\(m=m_x\), and public maps \(\pi_t:\Sigma_0\to\Gamma\) such that every valid
word \(w\) obeys
\[
  \pi_t(w_t)=C(m)_t\qquad\text{for every }t\in[M]. \tag{5}
\]
If the dPCP has perfect completeness and
\((L,\varepsilon)\)-list-decoding soundness, then the same global dPCP proof
supports every output coordinate \(i\) with at most \(2q_D\) proof queries and
wrong-claim probability
\[
  \Pr[V_{i,1-m_i}\text{ accepts}]
  \le q_D\lambda\varepsilon. \tag{6}
\]

The verifier runs \(\mathsf{Dec}_i\); for each codeword query \(t\), it runs the
dPCP local test and feeds \(\pi_t(D_t(T_A[a]))\) to the outer decoder only
when that local test accepts.  A rejection or bottom response aborts.  It
accepts the claimed bit exactly when
the outer decoder returns that bit.  All coordinates use the same proof and
the same address space.

#### Proof

Fix a candidate proof and use list soundness to obtain valid words
\(w^{(1)},\ldots,w^{(L)}\).  By (5), every list word projects at position \(t\)
to the same symbol \(C(m)_t\).  Hence a locally accepted dPCP response whose
projection differs from \(C(m)_t\) is contained in the list-soundness error
event, and the average probability of such a wrong accepted codeword symbol
is at most \(\varepsilon\).

If the outer decoder outputs \(1-m_i\), there is a first queried position at
which the supplied symbol differs from the honest codeword symbol; otherwise
the decoder sees the honest codeword and perfect completeness forces output
\(m_i\).  Before that first error, the query path is the honest path, so (4)
applies.  A union bound over the at most \(q_D\) query steps gives
\[
 \Pr[V_{i,1-m_i}\text{ accepts}]
 \le
 \sum_{r=1}^{q_D}\sum_{t=1}^{M}
       \frac{\lambda}{M}\,
       \Pr[\text{locally accepted dPCP response at }t\text{ is wrong}]
 \le q_D\lambda\varepsilon .
\]
The verifier uses two dPCP queries per outer query, proving the complexity
claim. \(\square\)

Theorem 2 is the multi-bit counterpart of Theorem 1.  It removes the
\(|\Sigma_0|\ge2^k\) cost by spreading the target through \(C(m)\), but it
does not remove the smoothness cost.  If the decoder for coordinate \(i\)
is supported on only \(s_i\) codeword positions, then necessarily
\(\lambda\ge M/s_i\).  Thus a coordinate-local outer code can turn the
average dPCP error into a fixed-coordinate guarantee only by paying either
global mixing (\(\lambda=O(1)\)), smaller \(\varepsilon\), or larger query
locality.  This is the exact quantitative form of the output-channel tradeoff.

## Instantiation from a circuit relation

Suppose a circuit relation \(\varphi_x(z)\) has a deterministic output bit
\(m_x\) on every satisfying assignment.  Add an explicit output field
\(b_t\in\{0,1\}\) to every assignment symbol and enforce
\[
  b_1=b_2=\cdots=b_n,
  \qquad
  b_1=\operatorname{out}_x(z).
\]
The resulting language \(\widehat{\mathcal L}_x\) satisfies (OH) with
\(\pi_t(b_t,z_t)=b_t\).  The equality/output gates add only \(O(n)\) circuit
size when the symbol projection is local.  Therefore any dPCP theorem for
\(\widehat{\mathcal L}_x\) immediately gives the two-query verifier in Theorem 1
with the same proof length up to the dPCP compiler overhead.

In particular, the current GMWZ dPCP theorem for a circuit of size \(N\) gives
a proof of size \(N\log^{C}N\), constant alphabet for fixed soundness, and
the compiler above gives the output-bit verifier at that same scale.  This is
a genuine positive simultaneous-proof theorem for an output-homogeneous
one-bit channel.  It does **not** compress the hidden assignment: if \(z\) is
a full computation history, \(N\) is still history-scale.

## The target-alphabet barrier

The positive compiler cannot simply be repeated for a full \(k\)-bit target
using a fixed alphabet.  The obstruction is independent of PCP details.

### Lemma 2 (common target-oblivious symbol channel)

Let \(\mathcal M\) be a set of \(M\) target words, and suppose a common family of
maps
\[
  \pi_t:\Sigma_0\longrightarrow\mathcal M,
  \qquad t\in[n],
\]
has the property that for every \(m\in\mathcal M\) there is a valid word
\(w^{(m)}\) with
\[
  \pi_t(w^{(m)}_t)=m
  \qquad\text{for all }t.
  \tag{2}
\]
Then
\[
  |\Sigma_0|\ge M.
  \tag{3}
\]

#### Proof

Fix any position \(t\).  For each \(m\in\mathcal M\), choose the symbol
\(\sigma_m=w^{(m)}_t\).  Equation (2) gives
\(\pi_t(\sigma_m)=m\).  Hence the image of \(\pi_t\) contains all \(M\)
targets, so \(|\Sigma_0|\ge|\operatorname{im}\pi_t|\ge M\). \(\square\)

For \(\mathcal M=\{0,1\}^k\), (3) is \(|\Sigma_0|\ge2^k\).  Thus a
target-oblivious, one-symbol-per-position output channel cannot carry a
full \(k\)-bit target over a fixed finite alphabet.  Encoding the target in a
descriptor or in a separate selector avoids (3) only by moving the same
\(k\) bits into an explicit target channel; it is not a hidden-word
compression.

## Why this does not yet close RW/JK

Theorem 1 resolves the **semantic** phantom-witness problem for an
output-homogeneous one-bit relation, but it leaves the address-scale problem:

* the computation/history assignment is still an \(N\)-symbol input to the
  dPCP;
* a \(k\)-bit output cannot be made homogeneous in one fixed alphabet without
  paying the target-channel entropy from Lemma 2;
* replacing the common symbol by \(k\) separate dPCP invocations loses the
  one-proof quantifier;
* ordinary GMWZ list soundness remains an average decoded-symbol statement,
  so an output projection is needed before Theorem 1 applies.

This yields an exact positive/negative split:
\[
\begin{array}{c}
\text{output-homogeneous projection}
\ \Longrightarrow\
\text{simultaneous wrong-claim soundness},\\[2mm]
\text{full target-homogeneous projection over fixed alphabet}
\ \Longrightarrow\
\text{alphabet/target-channel cost}.
\end{array}
\]

The remaining top-tier construction target is therefore not “find another
list-decoding theorem.”  It is to compress a multi-bit output relation into a
common proof/address space while violating neither Lemma 2 nor the
history-scale communication bound.  A success would be a genuinely new
relation-PCPP/dPCP theorem; a general proof that every such compression must
pay one of these channels would be an independent impossibility theorem.

## Sources and evidence boundary

The dPCP list-soundness interface used above is the standard one in
Gur--Minzer--Weissenberg--Zheng, where a left assignment is explained by a
list of valid words and the decoded symbol is compared against that list.
Their Theorem 1.6 supplies the near-linear two-query dPCP for circuit SAT.
The output-homogeneous compiler and Lemma 2 are deductions here, not claims
that GMWZ already provide a multi-output shared relation-PCPP.  The
output-homogeneous hypothesis is the single-bit projection specialization of
the singleton-output bridge, but the proof here shows explicitly that an
ordinary finite list is enough once the projection is homogeneous.

* [GMWZ Theorem 1.6 and dPCP definitions](https://arxiv.org/html/2512.12960)
* [DHK distributional soundness](https://eccc.weizmann.ac.il/report/2015/085/download)
* [Current address-scale closure theorem](204-rw-succinct-smart-reconstruction-closure-theorem-2026-08-17.md)
