> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK 全阶段 success-fiber 熵边界（2026-08-19）

## 本轮改变的判断

C489 只分析 JK 在顶层第一阶段立即返回 outsider 的情形。对实际的逐层
Jeřábek--Korten recursion，可以把同一非注入现象推广到任意首次 success stage
\(i\)。在显式 P-uniform generator \(G_n(u)=0^n u\) 上，固定一个 outsider block
后，stage-\(i\) frontier 的其余 blocks 可以独立变化，并沿着上层的唯一 range
preimage chain lift 到顶层 parent。于是同一个 JK output 的 parent fiber 至少有
\(2^{n(2^{i-1}-1)}\) 个元素。

这与 C488 形成尖锐的两端：完整 frontier 可以逐址恢复 parent，但要支付
\(n2^i\) 个 frontier bits；只保留 returned outsider/path 则留下至少
\(n(2^{i-1}-1)\) bits 的 family-level ambiguity。\(i=1\) 时熵下界退化为零，
正好说明最底层只能靠 C488 的 forward half-chain；\(i=k\) 时恢复 C489 的
\(T/2-n\) 线性熵。

## 定理 490.1（all-stage JK success-fiber bound）

令 \(n\ge1\)、\(k\ge2\)、\(i\in\{1,\ldots,k\}\)，取

\[
  G_n(u)=0^n u,\qquad
  T=n2^k,\qquad
  y=1^n0^n.
  \tag{490.1}
\]

令 \(m_i=2^{i-1}\)。对任意
\(v_2,\ldots,v_{m_i}\in\{0,1\}^n\)，定义 stage-\(i\) frontier

\[
  w_i(v_2,\ldots,v_{m_i})
  :=
  y\Vert 0^n v_2\Vert\cdots\Vert0^n v_{m_i}
  \in\{0,1\}^{n2^i}.
  \tag{490.2}
\]

定义 lift operator
\[
  L_j(a_1\Vert\cdots\Vert a_{2^j})
  :=
  G_n(a_1)\Vert\cdots\Vert G_n(a_{2^j}),
\tag{490.3}
\]
其中每个 \(a_r\in\{0,1\}^n\)。令
\[
  f_{i,v}:=
  L_{k-1}\circ L_{k-2}\circ\cdots\circ L_i
  \bigl(w_i(v_2,\ldots,v_{m_i})\bigr)
  \in\{0,1\}^{T},
\tag{490.4}
\]
并在 \(i=k\) 时把空复合解释为恒等映射。令
\[
  \mathcal F_{n,k,i}:=\{f_{i,v}:v_2,\ldots,v_{m_i}\in\{0,1\}^n\}.
\tag{490.5}
\]

则：

1. 对每个 \(f\in\mathcal F_{n,k,i}\)，Theorem 3.1 的 JK procedure 在
   stage \(i\) 首次遇到唯一的 non-range block，并输出同一个 \(y\)；
2. 映射 \(v\mapsto f_{i,v}\) 是 injective，且
   \[
     |\mathcal F_{n,k,i}|
     =
     2^{n(2^{i-1}-1)}.
   \tag{490.6}
   \]
3. 若同一 evaluator \(D\) 和 target-dependent descriptor
   \(\sigma_f\in\{0,1\}^{d}\) 满足
   \[
     D(j;y,\sigma_f)=f[j]
     \qquad
     (f\in\mathcal F_{n,k,i},\ j\in[T]),
   \tag{490.7}
   \]
   则
   \[
     d\ge n(2^{i-1}-1).
   \tag{490.8}
   \]

### 证明

把 \(f_{i,v}\) 在长度 \(n2^j\) 的 stage-\(j\) current string 上记为
\(y_j\)。由 (490.4)，对每个 \(j>i\)，
\[
  y_j=L_{j-1}(y_{j-1})
      =G_n^{\oplus 2^{j-1}}(y_{j-1}).
  \tag{490.9}
\]
因此 \(y_j\) 的每个连续 \(2n\)-bit block 都形如 \(0^n u=G_n(u)\)，所有更高层
range tests 都通过。到 stage \(i\) 时，current string 正是 \(w_i\)：第一块
\(y=1^n0^n\) 不在 \(\operatorname{Range}(G_n)\)，其余块 \(0^n v_r\) 都在
range。故第一次 NO query 恰在第一块，JK 立即输出 \(y\)，证明 (1)。

由于 \(G_n\) 在其 range 上的 preimage \(u\) 唯一，(490.9) 的 lift 对每个 frontier
block 保持可区分性，所以不同的 \(v\) 给出不同的顶层 \(f_{i,v}\)，得到 (490.6)。
若两个不同 parents 共用同一 descriptor \(\sigma\)，则 (490.7) 在它们不同的某个
地址上要求同一 evaluator 输出两个不同 bits，矛盾；因此 descriptor map injective，
得到 (490.8)。证毕。

## 推论 490.2（顶层 fiber 含 near-maximum hard parent）

当 \(i=k\) 且 \(T\) 是 2 的幂（例如 \(n=2^r\)），
\[
  |\mathcal F_{n,k,k}|=2^{T/2-n}.
\]
标准 fan-in-two circuit counting 给出：对某个绝对常数 \(c>0\)，该 family 中存在
一个 parent \(f^\star\) 满足
\[
  \operatorname{CC}(f^\star)\ge c\,\frac{T}{\log_2(T+2)}.
  \tag{490.10}
\]
同时 JK 在 \((G_n,f^\star)\) 上仍输出同一个 \(y\)。

### 证明

含 \(\ell=\log_2T\) 个输入、大小至多 \(s\) 的 fan-in-two circuits 数量至多为
\(2^{O(s\log(s+\ell))}\)。取 \(s=cT/\log(T+2)\) 且令 \(c\) 足够小，该数量小于
\(2^{T/2-n}=|\mathcal F_{n,k,k}|\)（对充分大的 \(T\)）。故 family 中至少有一个
truth table 不被这些 circuits 计算，得到 (490.10)；其 JK output 由定理 490.1
仍为同一个 \(y\)。证毕。

## 与 C488/C489 和 RW Closure 的关系

* \(i=k\) 时，定理 490.1 正好给出 C489；其 hard-member 推论还说明同一 success
  output fiber 中存在近最大电路复杂度的 parent。
* \(i=1\) 时，family entropy 为零；这不是漏洞，而是精确的 phase boundary：一个
  \(2n\)-bit frontier block 已经决定其上层 lift，剩余成本由 C488 的
  \(n2^i+(k-i)(|G|+n)\) forward reconstruction 支付。
* 中间 stage 同时有两种不可免费逃逸：若暴露完整 frontier，支付 C488 的 support；
  若只给 outsider 加短 descriptor，支付 (490.8) 的 family entropy；若两者都不适用，
  必须提出新的 non-product/global relation。
* 该 family-level theorem 仍不能静默套到 published Theorem 4.3 的单个
  \(f_i(x_0)\)。它关闭的是“JK success output 一般就是 parent fingerprint”的路线，
  不是 singleton-specific binding 的最终不可能性，也不是 \(P\ne NP\) 证明。

## 证据边界

* 只使用 Ren--Williams Theorem 3.1 的 \(y_k=f'\)、逐层 range test、lexicographically
  selected preimage 与 first-NO return semantics；\(G_n(u)=0^n u\) 使 preimage chain
  显式且唯一。
* (490.10) 是标准有限电路计数的 family-level 存在性，不把该 hard parent 认作
  C455 的 published \(B_n\)。
* 未计价 global oracle、地址依赖 physical proof、非单值关系和 fixed-singleton
  target channel 都不在定理范围内；它们必须作为另一个 Closure model 单独证明。

## 来源

* Ren--Williams Theorem 3.1 proof；本地抽取
  units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md
  第 498--558 行。
* [C488 JK first-failure frontier-support bound](488-jk-first-failure-frontier-support-bound-2026-08-19.md)。
* [C489 JK success-output non-injection](489-jk-success-output-noninjection-parent-entropy-barrier-2026-08-19.md)。
