> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Tree PCP 的张量维数 tradeoff 仍挡住地址尺度（2026-08-15）

## 文献事实

Mour--Rosen--Rothblum 的 Tree PCP（ECCC TR25-091, revision 1）给出了一个重要的
正向组件：证明可以在线增长，且 tree code 同时具有强局部可测试性和局部可纠错性。
其 Theorem 1.5 对**每个固定常数** \(\gamma>0\) 给出每一步新增证明长度和查询规模
\(t^\gamma\operatorname{poly}(|C|)\)。

Section 7 的具体 tensor-tree 实现还显示，若张量维数记为 \(m\)，则单次局部测试的
查询上界（忽略常数）为

\[
  Q_{\mathrm{test}}
  \;=\;
  t^{\,2/m}\operatorname{polylog}(t),
\tag{1}
\]

而论文为得到其 soundness 选择的重复次数为

\[
  \lambda
  \;=\;
  (\log t)^{\,a m+O(1)}
\tag{2}
\]

其中 \(a>0\) 是只依赖底层树码参数的常数（论文中指数写成
\((1+1/\mu)m+O(1)\)）。其它 codeword 数量和电路大小因子只会再乘上
\(\operatorname{poly}(\log t,|C|)\)。

## 地址尺度计算

令目标基础输入长度为 \(n\)，而被压缩的计算历史长度为

\[
  T=2^{n^\eta},
  \qquad \eta>0\text{ 固定},
\tag{3}
\]

并暂时把 \(m\) 当作可随 \(T\) 变化的整数。令 \(L=\log T\)。若按论文的 tester
和重复策略执行，忽略只会增加成本的多项式因子，其**显示 query budget** 的核心
乘积为

\[
  \widehat Q_m
  :=
  T^{2/m}(\log T)^{a m+O(1)}
  =
  \exp\!\left(\frac{2L}{m}+a m\log L+O(\log L)\right).
\tag{4}
\]

对 \(m>0\) 用算术--几何平均不等式，

\[
  \frac{2L}{m}+a m\log L
  \;\ge\;
  2\sqrt{2aL\log L}.
\tag{5}
\]

因此，即使形式上允许 \(m\) 随长度变化，这个显示 budget 表达式的最小数量级也是

\[
  \widehat Q_m
  =
  \exp\!\bigl(\Omega(\sqrt{L\log L})\bigr)
  =
  \exp\!\bigl(\Omega(n^{\eta/2}\sqrt{\log n})\bigr),
\tag{6}
\]

这不是 \(\operatorname{poly}(n)\)。固定 \(m\) 时，障碍更直接：论文给出的
\(Q_{\mathrm{test}}\) 上界本身带有 \(2^{\Theta(n^\eta/m)}\) 这一尺度。

等价地，若要求论文显示的两项预算都落在 \(\operatorname{poly}(n)\)，(1) 需要

\[
  m=\Omega\!\left(\frac{n^\eta}{\log n}\right),
\tag{7}
\]

而 (2) 同时需要 \(m=O(1)\)（因为 \(\log\log T=\Theta(\log n)\)），两者不相容。

## 对 RW/JK 路线的精确含义

这项工作比普通 LTC 更接近所需接口：它确实提供在线编码、局部测试和局部纠错。
但它仍不能直接提供 Ren--Williams/JK 所需的

1. \(\operatorname{poly}(n)\)-时间的固定 history block accessor；
2. 一个确定、canonical、整词一致的 \(q\)-bit preimage selector；
3. 在 \(T=2^{n^\eta}\) 时的 \(\operatorname{poly}(n)\) smart query。

上述 tradeoff 说明：把 RMV 换成该 Tree PCP 的 tensor-tree tester，单靠调张量维数
不能让**论文当前显示的预算**填补地址尺度缺口。要继续推进，必须改变至少一个结构：避免
\((\log T)^{\Theta(m)}\) 的全局 soundness 放大、找到不依赖 \(T^{2/m}\) 的局部约束，
或证明 RW 的实际 history 只需测试一个远小于全树的可访问子族。

## 适用范围与谨慎边界

论文 Theorem 1.5 的正式量词是“对每个固定常数 \(\gamma\)”；将 \(m\) 作为长度参数
变化只是对 Section 7 显示公式的架构诊断，不是论文已经证明的可变参数定理；而且
(1)--(2) 是上界/选定重复次数，不是对任何替代实现的下界。因此 (6) 只能说明该
具体显示方案没有 polynomial-address 窗口，不是所有 Tree PCP 或所有 PCP 重构算法的
一般下界。

## 来源

- Mour--Rosen--Rothblum, *Tree PCPs*, ECCC TR25-091 revision 1：
  [official report](https://eccc.weizmann.ac.il/report/2025/091/revision/1/download)。
  Theorem 1.5 给出固定 \(\gamma\) 的在线 Tree PCP；Section 7（尤其
  Proposition 4.9、Theorem 1.5 的证明）给出 (1)--(2) 的参数来源。
- Ren--Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin--Arthur Queries*, ECCC TR26-118：
  [official report](https://eccc.weizmann.ac.il/report/2026/118/revision/1/download)。

本 note 是结构化参数边界，不声称已经证明 \(P\ne NP\)。
