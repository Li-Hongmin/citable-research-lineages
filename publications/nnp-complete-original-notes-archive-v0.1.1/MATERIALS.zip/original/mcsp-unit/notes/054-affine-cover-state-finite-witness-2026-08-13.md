> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 全体 affine 叶的 cover-number 状态：有限反例与 thinning 阈值（2026-08-13）

## 状态

若 \(\mathcal L_\oplus\) 是所有 affine 最大叶，令

\[
F_{\oplus}(R)=\min\{k:R\subseteq L_1\cup\cdots\cup L_k,\ L_i\in\mathcal L_\oplus\}.
\]

则 \(F_\oplus\) 单调、次可加，且每个最大叶 \(L\) 满足 \(F_\oplus(L)=1\)。因此

\[
K_\oplus(R)=F_\oplus(R)-\frac{F_\oplus(C)}{|C|}|R|
\]

满足 QA/root-zero；它是一个真正的全局非 XOS 状态，而非 rank 或 coverage 统计。

## 一个有限 affine 例子

取 \(N=4\)，

\[
X=\{0,2,4,7,13\},\qquad
Y=\{1,8,9,10,15\},\qquad C=X\times Y.
\]

对所有 \(r\in\mathbb F_2^4\setminus\{0\}\) 和 \(b\in\mathbb F_2\)，最大叶

\[
L_{r,b}
=\{x:r\cdot x=b\}\times\{y:r\cdot y=1-b\}
\]

均非空，共 30 片。每个 cell 被恰好 8 片包含，故均匀最大叶分布的包含概率

\[
q=\frac8{30}=\frac4{15}.
\]

逐片枚举给出

\[
F_\oplus(C)=4.
\]

任意三片的并集都漏至少一个 cell；四片
\(L_{1,0},L_{2,0},L_{4,1},L_{8,0}\) 的并集则覆盖全部 \(C\)。

因为每个样本叶本身是一个原子，

\[
\mathbb E F_\oplus(L)=1
<\frac4{15}\cdot4=\frac{16}{15}
=qF_\oplus(C).
\]

所以一般“单调次可加状态必有 \(\mathbb E F\ge qF(C)\)”是假的；全局 cover 状态确实可产生负平均。

## thinning 后的门槛

若在最大叶内独立以 \(1/2\) 抽取行、列，cell 包含率降为

\[
q_{\rm thin}=\frac1{15}.
\]

每个 thinned leaf 仍被其母最大叶一片覆盖，故 \(F_\oplus(R)\le1\)。要让平均补偿变负，需要

\[
F_\oplus(C)>15.
\]

因此，在当前 QA-LP 中，cover-number 状态将 AEKR thinning 缺口精确转化为一个全局叶覆盖数问题：

\[
\boxed{\text{证明 }F_\oplus(E_a\times NO_b)>16\text{（更强则目标 }N^{1.01}\text{）。}}
\]

这不是现成证明：若 \(\mathcal L_\oplus\) 为全体合法 affine 叶，根 cover number 本身就是待下界的 Formula\(\circ\)XOR 复杂度；但它给出唯一不受静态平均 no-go 的可写 QA 状态和明确阈值。
