> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Birget 的 surjective-inverse 边界与 sampler 路线（2026-08-15）

## 文献事实

Birget, *On the circuit-size of inverses*（arXiv:0912.3730；IJFCS 22(8), 2011）
研究与本项目相同的“短电路满射是否有短右逆”问题。原文的 Theorem 3.4 与
Corollary 3.5 给出：

\[
\begin{aligned}
&\text{若每个 Boolean circuit 都有 polynomial-size semi-inverse，}\\
&\text{则 }\Pi_2^P=\Sigma_2^P;\\
&\text{若每个 surjective circuit 都有 polynomial-size semi-inverse，}\\
&\text{则 }\Pi_2^P=\Sigma_2^P.
\end{aligned}
\tag{1}
\]

原文 Theorems 4.3--4.4 的反向表述是：在
\(\Pi_2^P\ne\Sigma_2^P\) 假设下，存在无限多个 surjective circuits，其所有 inverse
都超过任意预先给定的多项式；并可拼成 polynomially balanced、length-equality preserving
的 total surjection，具有 circuit-size one-way 性质。

## 与 sampler 的参数对应

对 note 091 的 sampler \(E\)，其地址分量

\[
A_E:\{0,1\}^{p}\to\{0,1\}^{m}
\tag{2}
\]

在 Full 条件下正是 surjection。若有右逆
\(R_E:\{0,1\}^{m}\to\{0,1\}^{p}\)，满足

\[
A_E(R_E(x))=x,
\tag{3}
\]

则标签函数可直接写成

\[
f_E(x)=B_E(R_E(x)).
\tag{4}
\]

因此 Birget 的对象解释了 note 093 的二难：当地址置换/满射确实存在 hard inverse
时，sampler 可以在地址层隐藏复杂性；当所有这类地址都有短逆时，式 (4) 把 range
拉回 MCSP（note 093 的式 (9)）。

Birget 的 Theorem 4.3 还把输入输出长度限制在常数倍关系的 surjection 子族中。映射到
\(N=2^m\) 的 sampler 参数，这属于 \(p=\Theta(m)=\Theta(\log N)\) 的区间；因此它
并不提供 note 094 所排除的 \(p=\omega(\log N)\) range 机制。

## 不能直接升级为 P vs NP 证明

需要保留四个边界：

1. Birget 的结论以 \(\Pi_2^P\ne\Sigma_2^P\) 为条件，不能无条件推出 \(P\ne NP\)。
2. 其 hard inverse 是对一个 surjective circuit family 的 search/inversion 性质，
   不是固定 truth-table image language 的 decision lower bound。
3. 本项目的 sampler 还要求标签 fiber-consistency，并把 \(B_E\circ R_E\) 的 truth
   table 放入一个统一 decoder range；Birget 不分析这个 range。
4. Theorem 4.4 允许非均匀 circuit families；本项目若要触发 note 089，仍需固定、
   uniform、PH-local 的 decoder schedule。

所以该文献把“hard right inverse”确认成一个真实的复杂度边界，而不是当前问题的解答：

\[
\boxed{
\text{Birget 支持 hard-inverse 分支的条件性可行性；}
\quad
\text{sampler range/search lower bound 仍未得到。}
}
\tag{5}
\]

## 路线决策

继续研究 sampler 时，不应再把“存在短 surjection 但无短 inverse”本身当作新定理。
真正尚缺的是把这种 inverse hardness 稳定地转移到同一个固定
\(L_{\mathrm{sam}}\) 的 decision/range-membership 下界；而 \(p=\Theta(\log N)\) 时
该语言已属于 NP（note 094）。若要避开这一尺度，必须构造
\(p=\omega(\log N)\) 的 uniform sampler，并同时解决 fiber-consistency 的 coNP 障碍
（note 095）。

原文核验日期：2026-08-15。

来源：[arXiv:0912.3730](https://arxiv.org/abs/0912.3730)，
[IJFCS 发表信息](https://doi.org/10.1142/S0129054111009124)。
