> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Sentinel hard outsider does not bind the JK parent (2026-08-19)

## 本轮改变的判断

C487 的 solver-success semantic exit 还可以提出一个反驳：也许 success 返回的
outsider \(Y\) 本身已经很 hard，因此它可能携带足够信息来绑定 parent。C501
允许把这个反驳在一个合法的 RW Theorem 4.3 generator family 上完全击穿：

* 每个 canonical-lift depth \(d\) 都存在一个 **hard outsider**
  \(y_d\in\mathcal O_d^\star\)；
* 在固定这个同一个 hard outsider、stage、位置和 hard 标志后，仍有近
  \(2^{T/2}\) 个不同的 parents；
* 顶层这些 parents 中还有 near-maximum-hard members。

因此“返回一个 hard child”与“返回同一个 parent 的 address binding”是两个
严格不同的量词；即使把 C501 的 \(\Gamma_d\) 做到近满，success-output-only
路线仍没有 family-level parent binding。

## 定理 502.1（hard outsider / hard parent separation）

沿用 C501 的 \(G_n^\star\)、\(\mathcal S_n\)、canonical selector \(p_n\) 和
\(\Gamma_d^\star\)。令 \(n=2^k\) 足够大，\(2\le i\le k\)，并写
\[
d:=k-i,\qquad m_i:=2^{i-1}-1.
\tag{502.1}
\]

### (a) 每个深度都有 hard liftable outsider

存在
\[
y_{n,d}\in\mathcal O_d^\star
\]
满足
\[
\operatorname{CC}(y_{n,d})
>\left\lfloor\eta\,\frac{n}{k}\right\rfloor
\tag{502.2}
\]
（\(\eta\) 是 C501 中的固定常数）。

### (b) 固定 hard outsider 后的 parent fiber

对每个 tuple
\[
\mathbf u=(u_1,\ldots,u_{m_i})\in\mathcal S_n^{m_i},
\]
令 \(z_j:=u_j\Vert u_j\in\mathcal Z_d^\star\)，并用 C497 的
stage-\(i\) construction 把 \(y_{n,d}\) 放在最后一个 block，再向上 lift
\(d\) 层得到 parent \(F_{\mathbf u}\)（长度 \(T=n2^k\)）。则所有
\(F_{\mathbf u}\) 的 JK transcript 完全相同：
\[
\tau_{n,i,d}
=(\mathrm{hard},\mathrm{stage}=i,
  \mathrm{block}=2^{i-1},y_{n,d}).
\tag{502.3}
\]

不同 tuples 给出不同的 pre-failure prefixes，且
\[
\bigl|\{F_{\mathbf u}:\mathbf u\in\mathcal S_n^{m_i}\}\bigr|
=|\mathcal S_n|^{m_i}.
\tag{502.4}
\]
因此任何 exact family-level parent-binding descriptor \(s_{\mathbf u}\) 满足
\[
|s_{\mathbf u}|
\ge
m_i\log_2|\mathcal S_n|
\ge
(2^{i-1}-1)(n-1)
\tag{502.5}
\]
（二进制 side information）。

### (c) 顶层 fiber 含 hard parents

在 \(i=k\) 时，\(T=n2^k\)，fiber 大小为
\[
|\mathcal S_n|^{2^{k-1}-1}
=2^{(1-o(1))T/2}.
\tag{502.6}
\]
存在一个 universal constant \(\delta>0\)，使得对所有充分大的 \(n\)，该 fiber
中有 parent \(F\) 满足
\[
\operatorname{CC}(F)
>\delta\,\frac{T}{\log_2(T+2)}.
\tag{502.7}
\]

## 证明

由 C501，\(\mathcal S_n\subseteq\Gamma_d^\star\) 对所有 \(d\)。考虑所有
\[
y=a\Vert b,\qquad a,b\in\mathcal S_n.
\]
共有 \(|\mathcal S_n|^2\) 个这样的 strings，而
\(|\operatorname{Range}(G_n^\star)|\le2^n\)。因为
\(|\mathcal S_n|^2>2^n\) 对充分大的 \(n\) 成立，至少一个这样的 \(y\) 不在
\(\operatorname{Range}(G_n^\star)\)。它的两个 halves 在 \(\Gamma_d^\star\)，故
\(y\in\mathcal O_d^\star\)；C501(a) 再给出 (502.2)。

对每个 \(u\in\mathcal S_n\)，structured branch 的 block
\[
z_u=u\Vert u
\]
属于 \(\mathcal Z_d^\star\)。因此可以直接应用 C497：前
\(m_i\) 个 blocks 取 \(z_{u_1},\ldots,z_{u_{m_i}}\)，最后一块固定取
\(y_{n,d}\)，再向上做 \(d\) 层 canonical lift。所有成功 stages 的 canonical
preimages 都由 C501 的 \(\mathcal S_n\subseteq\Gamma_d^\star\) 保证，stage \(i\)
只在最后一个 block 失败，所以得到固定 transcript (502.3)。C499 保证不同
\(z_u\) 的 lifted images 不 collision，故 (502.4) 及其 prefix injectivity 成立；
取对数即得 (502.5)。

最后考虑 \(i=k\)。此时没有上层 lift，parent family 的长度为 \(T=n2^k\)，且
\[
\log_2|\mathcal S_n|^{2^{k-1}-1}
\ge(1-o(1))T/2.
\]
另一方面，输入长度 \(\lceil\log_2 T\rceil\) 上大小至
\(s=\delta T/\log_2(T+2)\) 的 fan-in-two circuits 数量至多
\(2^{C\delta T}\)，其中 \(C\) 为固定编码常数。取
\(\delta<1/(4C)\)，其总数小于 fiber 大小；于是 fiber 中存在满足
(502.7) 的 hard parent。

## 对 Closure 的直接影响

1. **Hard child is not a parent fingerprint.** 该定理不只固定 outsider；它固定了
   一个本身已经 hard 的 outsider。因而“把 success 输出升级成 hard object”仍不能
   自动得到 parent binding。
2. **The obstruction survives maximal canonical \(\Gamma\).** 这里
   \(|\Gamma_d^\star|\ge(1-o(1))2^n\) 对所有深度，故失败不能归因于 canonical
   seeds 太少或 lift collision。
3. **Exact remaining gate.** 要把这条 barrier 接到 \(P\ne NP\)，仍需证明
   actual RW singleton 的 canonical PCP image 具有该 family-level variation，或
   提供一个对该 family 统一且 address-scale 的 parent-binding relation。若只针对
   每个 fixed parent 另附 descriptor，则 C502 的熵结论不适用，而 descriptor/program
   本身必须回到 C455 的 forcing-scale 计价。

本定理是一个 source-specific family-level impossibility/barrier；不声称
Ren--Williams Theorem 4.1 的实际 singleton PCP proof 落入该 fiber，不证明一般
dPCP/LDC 不可能性，也不证明 \(P\ne NP\)。

## 来源

* [C501](501-sentinel-padded-truth-table-generator-canonical-gamma-closure-2026-08-19.md).
* [C497](497-jk-canonical-liftable-range-projection-barrier-2026-08-19.md).
* [C499](499-jk-canonical-lift-injectivity-eliminates-collision-branch-2026-08-19.md).
* [C487](487-rw-solver-success-parent-binding-support-trichotomy-2026-08-19.md).
* Ren--Williams TR26-118 rev.1, Theorem 3.1 and Theorem 4.3.
