> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Interleaved handoff boundary (2026-08-24)

## 1. Model

Let \(A\subseteq\{0,1\}^N\). Consider a source-to-target protocol whose source input is read in
the known order \(x_1,\ldots,x_N\). During the scan, the source side has at most \(W_Q\) complete
source-dependent configurations and the target side at most \(W_D\) complete configurations;
these include finite controls, work tapes, head/address positions, and scheduler phase. Every
source-dependent object outside these configurations is stored in one complete payload tape of at
most \(h\) bits; this includes payload content, length/stop markers, addresses, timing metadata,
and source-dependent query or answer buffers. The source and target may update these objects in an
arbitrary interleaved schedule, but no source-dependent RAM or oracle is available outside the
counted state.

After the source scan ends, the target may continue arbitrarily without reading the source. Fixing
all random tapes turns the protocol into a known-order read-once branching program, with the final
decision as its terminal label.

### Proposition 29 (interleaved charged-handoff boundary)

Under the local-PRG interface of Proposition 10, every exact or bounded-error MCSP protocol in the
model above satisfies

\[
\mathfrak W\le (N+1)W_QW_D2^h,
\tag{29.1}
\]

for a length-\(N\) known-order ROBP, and therefore

\[
\boxed{
h+\log_2W_Q+\log_2W_D=\widetilde\Omega(S),
\qquad S=N^{\mu_H}.
}
\tag{29.2}
\]

If the target control is absent or source-independent, set \(W_D=1\). Arbitrary interleaving and
random access to the counted payload do not improve Proposition 28. The bounded-error assertion
assumes completeness \(1-\varepsilon_Y\), soundness \(\varepsilon_N\), and
\(\varepsilon_Y+\varepsilon_N<1\), together with the same constant-error local-PRG guarantee as
Proposition 10.

## 2. Proof

Fix the random tapes. At a source-prefix boundary \(t\in\{0,\ldots,N\}\), record the complete
triple

\[
(t,q_t,d_t,m_t),
\]

where \(q_t\) is the source control state, \(d_t\) the target control state, and \(m_t\) the entire
payload tape. There are at most \((N+1)W_QW_D2^h\) such records. Given the record and the next
source bit, the interleaved transition is fixed; any target-only suffix after \(t=N\) is absorbed
into the terminal label. These records are therefore the states of a length-\(N\) known-order ROBP,
proving (29.1).

Let \(r=\widetilde O(\log(N\mathfrak W))\) be the seed length supplied by the local-PRG interface.
If \(r=o(S)\), every generated truth table lies in the source YES class
\(\mathcal L_{\mu_H,n}\). Completeness gives generator acceptance at least \(1-\varepsilon_Y\),
whereas a uniform truth table is a NO instance with probability \(1-o(1)\), so its acceptance is
at most \(\varepsilon_N+o(1)\). Since \(\varepsilon_Y+\varepsilon_N<1\), this contradicts the
constant-error fooling guarantee. Hence

\[
\log(N\mathfrak W)=\widetilde\Omega(S).
\]

Combining this with (29.1), and absorbing \(\log(N+1)\) into soft factors, yields (29.2).

## 3. Exact boundary

The theorem fails if the payload tape is only a pointer to source-dependent RAM, if an oracle
answer is source-dependent but omitted from \(m_t\), or if a one-bit operation may compute an
arbitrary predicate of the unread source. The protocol

\[
m(x)=\mathbf 1_A(x),\qquad W_Q=W_D=1,\qquad h=1
\]

then decides \(A\) with a source-independent target. This is not a counterexample to (29.2): it
violates the complete-state hypothesis by hiding source dependence outside the counted payload.

Thus the new boundary is specifically an interleaving result. It does not turn sparsity alone into
a communication lower bound, and it does not prove \(P\ne NP\); the remaining MCSP problem is to
charge the time or space required to create a non-measurable source-dependent channel.

## Sources

- Proposition 10 and Proposition 28 in the MCSP paper in this directory.
- Harper, *Optimal Numberings and Isoperimetric Problems on Graphs*, *J. Combin. Theory* 1
  (1966), 385--393, [doi:10.1016/S0021-9800(66)80059-5](https://doi.org/10.1016/S0021-9800(66)80059-5).
