> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 单一 separator 的 codim-2 子分支闭合（2026-08-13）

## 固定第二个 spoiler 方程

设 \(\mathcal F\) 是关于固定 spoiler \(s\) 的两两相交 collision-witness 族。假设每个 \(T\in\mathcal F\) 都满足

\[
q_s\cdot z=1,
\qquad p_s\cdot z=\varepsilon
\quad\text{for every }z\in L(T),
\]

其中同一个 \(\varepsilon\in\mathbb F_2\) 对全族固定。因为 \(X\cap Y=\varnothing\)，\(q_s=(x_s,1)\) 与 \(p_s=(y_s,1)\) 线性无关；这两个 affine 方程把参数空间限制到余维二子空间，质量为 (1/4)。更一般地，记三种 separator 状态为

\[
S_Q=\{q_s=1\},\qquad S_P=\{p_s=0\},\qquad S_D=\{q_s+p_s=0\}.
\]

对 anchor 估计需要如下精确独立性：对任意 cell \(a=(x_a,y_a)\)，若对应交集非空，则

\[
\operatorname{rank}\{q_a,p_a,\sigma\}=3,
\qquad \sigma\in\{q_s,p_s,q_s+p_s\},
\tag{1}
\]

其中 separator 方程右端分别为 \(1,0,0\)。事实上，若 \(q_s\in\operatorname{span}(q_a,p_a)\)，末坐标迫使 \(q_s=q_a\) 或 \(q_s=p_a\)。前者与 \(q_a=0,q_s=1\) 矛盾，后者需 \(x_s=y_a\)，与 \(X\cap Y=\varnothing\) 矛盾。若 \(p_s\in\operatorname{span}(q_a,p_a)\)，两种可能为 \(p_s=p_a\) 或 \(p_s=q_a\)：前者与 \(p_a=1,p_s=0\) 矛盾，后者需 \(y_s=x_a\)，仍与不交性矛盾。最后，若 \(q_s+p_s\in\operatorname{span}(q_a,p_a)\)，末坐标迫使非零情形为 \(q_s+p_s=q_a+p_a\)；但在 \(H_a\) 上 \((q_a+p_a)\cdot z=1\)，与 separator 方程 \(q_s+p_s=0\) 矛盾。若上述等式造成空交，则事件本身为空；故非空支持必满足 (1)，从而

\[
\Pr_z[H_a\cap S_\sigma]\le 2^{-3}.
\tag{2}
\]

固定一个满足这两个方程的 (z)。对叶 \(R_z=A_z\times B_z\) 的行、列保留，四个补集样本

\[
(U,V),\quad(\bar U,V),\quad(U,\bar V),\quad(\bar U,\bar V)
\]

给出互不相交的子矩形。若两个不同样本都包含见证，则这两个见证不相交，违反 \(\mathcal F\) 的两两相交性。因此固定 \(z\) 时命中概率至多 (1/4)，总概率至多

\[
\frac14\cdot\frac14=\frac1{16}.
\]

该证明不要求 witness 大小有界。

## τ=2 且全族共用一个 separator

设 \(\{a,b\}\) 是见证族的二点 cover，但只假设每个见证都落在同一个
\(S_\sigma\)（不要求第二个 spoiler 方程固定）。令 \(E_a\)（分别 \(E_b\)）为命中某个含 anchor \(a\)（分别 \(b\)）的见证事件。由 (1)--(2)，每个 anchor 的参数支持都包含于
\(H_a\cap S_\sigma\)（分别 \(H_b\cap S_\sigma\)），质量至多 \(1/8\)。固定参数 \(z\) 后，四个行列补集轨道中至多一个能命中两两相交族，故

\[
\Pr(E_a)\le \frac18\cdot\frac14=\frac1{32},
\qquad
\Pr(E_b)\le \frac1{32}.
\]

由于全族每个见证含 \(a\) 或 \(b\)，\(E=E_a\cup E_b\)，从而

\[
\boxed{\Pr(E)\le \frac1{16}.}
\]

这一步不使用 residual cross-intersection，也不依赖见证阶数。

## 共同行／列 anchor 子类

在 \(q_s=1\) 归一化下平移使 \(x_s=0\)。若所有见证共用同一列 \(y_0\)，则它们的行投影组成相交族。若 \(y_0\ne0\)，命中要求 \(r\cdot y_0=0\)，提供一个额外 (1/2) 参数因子；条件于该参数，行侧独立 (1/2) 抽样的补集配对给出至多 (1/2) 的相交族命中率，再乘 (t=1)、列 \(y_0\) 保留和行侧条件，得到总概率至多 (1/16)。

若 \(y_0=0\) 且 \(|T|\ge2\)，每个 cell 的列方程 \(p_c=(0,1)\) 与 \(q_s=(0,1)\) 重合；删去任一 cell 后错误的 spoiler 方程仍由剩余 cell 决定，违反极小性。因此高阶极小 witness 的共列情形自动落入 \(y_0\ne0\)。共同行情形完全对偶：\(x_0=0\) 会与 \(q_s\) 重合，\(x_0\ne0\) 时由额外的行方程给出同样的 (1/16) 界。

## 余下边界

若不同见证的 \(p_s\) 常值不同，或单个见证的 \(p_s\) 在 \(L(T)\) 上自由变化，则只能逐子族应用本引理，不能把多个余维二支持直接相加后保留 (1/16)。因此尚未关闭的单一 separator 分支是：只有一个余维一方程，而第二个 spoiler 方程在见证之间自由变化或缺失；这正是当前高阶 affine-biclique EKR 的最小未决接口。
