> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# GMWZ factorized cross-cluster synchronization gate (2026-08-18)

## Result

The shared-top spectral calculation and the common-reference transfer can be
combined into one explicit source-level gate. This is the cheapest quantitative
test of whether the GMWZ Section 6 list endpoint can be upgraded to one decoded
word. It is conditional on a common reference word and does not claim that the
published construction has either property.

Let \(U_i,U_j\subseteq X(k)\) be two heavy clusters, let
\(\mu_0=\min\{\mu_i,\mu_j\}\), and let \(C_{ij}\) be the factorized shared-top
event. Assume the hypotheses of Proposition 3.9S, in particular

\[
 \theta_0^2,\theta_1^2\le \mu_0/4.
\tag{FG1}
\]

Assume further that there is one vertex word \(g\) and cluster functions
\(f_i,f_j\) such that every face in \(U_\ell\) differs from \(g\) on at most an
\(\varepsilon_\ell\)-fraction of its vertices. Suppose the decoder incidence on
cluster \(\ell\) is \(\Lambda_\ell/k\)-smooth, and the base decoder outputs have
error at most \(\eta\) relative to the corresponding words \(w_i,w_j\). If the
valid-word family is \(\Delta\)-separated, then

\[
\operatorname{dist}(w_i,w_j)
\le
 \frac{4\theta_0}{\sqrt{\mu_0}}
 +\frac{2\theta_0^2+4\theta_1^2}{\mu_0}
 +\frac{2(\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j)}{\mu_0^2}
 +2\eta .
\tag{FG2}
\]

Consequently, the two cluster words are equal whenever the right-hand side of
(FG2) is \(<\Delta\).

### Proof

Proposition 3.9S gives

\[
 \gamma_{ij}=\Pr[C_{ij}]\ge\mu_0^2/2,
 \qquad
 \xi_{ij}\le
 \frac{4\theta_0}{\sqrt{\mu_0}}
 +\frac{2\theta_0^2+4\theta_1^2}{\mu_0}.
\tag{FG3}
\]

The global-reference transfer inequality (Lemma 3.9I) gives, under the base decoder
distribution,

\[
 \rho_{ij}
 \le \xi_{ij}
 +\frac{\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j}
 {\gamma_{ij}}
 \le \xi_{ij}
 +\frac{2(\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j)}{\mu_0^2}.
\tag{FG4}
\]

For a sampled coordinate, a disagreement between \(w_i\) and \(w_j\) is charged to
the decoder disagreement or to one of the two decoder errors. Hence
\(\operatorname{dist}(w_i,w_j)\le\rho_{ij}+2\eta\). Substituting (FG3) into
(FG4) proves (FG2), and \(\Delta\)-separation gives the final implication.

## Source-scale consequence

If \(\Lambda_i,\Lambda_j\le\Lambda\), \(\varepsilon_i,\varepsilon_j\le\varepsilon\),
and \(\eta=5\sqrt\delta\), then

\[
 \operatorname{dist}(w_i,w_j)
 \le
 \frac{4\theta_0}{\sqrt{\mu_0}}
 +\frac{2\theta_0^2+4\theta_1^2}{\mu_0}
 +\frac{4\Lambda\varepsilon}{\mu_0^2}
 +10\sqrt\delta.
\tag{FG5}
\]

If the only available common-reference estimate is the native GMWZ-scale bound
\(\varepsilon\le\delta+\kappa\), where \(\kappa\) is an additional semantic
coherence error, then the positive synchronization route requires

\[
 \frac{4\theta_0}{\sqrt{\mu_0}}
 +\frac{2\theta_0^2+4\theta_1^2}{\mu_0}
 +\frac{4\Lambda(\delta+\kappa)}{\mu_0^2}
 +10\sqrt\delta
 <\Delta.
\tag{FG6}
\]

In particular, even if the spectral terms vanish and \(\kappa=0\), a necessary
scale for this route to remain nonvacuous is
\(\delta=O(\mu_0^2)\). With the heavy-cluster parameter
\(\mu_0=\delta^{C_*}\), the term \(4\Lambda\delta/\mu_0^2\) is
\(4\Lambda\delta^{1-2C_*}\); it diverges when \(C_*>1/2\) and stays bounded away
from zero at \(C_*=1/2\). Thus the published cluster-scale error cannot by itself
provide the common-reference coherence needed for unique decoding in the usual
heavy-cluster regime. A successful positive upgrade must supply a stronger
computation-generated global-word invariant, an anti-concentration estimate that
removes the \(1/\gamma_{ij}\) conditioning loss, or a modified amplifier with a
different synchronization mechanism.

This is a quantitative source-specific barrier, not a general dPCP impossibility:
the common word \(g\), the smooth incidence hypothesis, and the stronger coherence
are not consequences of GMWZ Lemma 6.2. It also leaves the RW address-scale,
bottom, cover-sheet, and descriptor gates untouched.

## Sources and scope

The spectral/mass and conditioned-marginal estimate is Proposition 3.9S / note 207;
the common-reference transfer is Lemma 3.9I and the statement
global-consistency-cross-cluster-transfer.md. GMWZ Section 6 supplies only one
word per cluster and a \(5\sqrt\delta\) base-decoder error; it does not supply the
common-reference hypothesis used here. Therefore (FG6) closes a parameter test,
not the published list-to-singleton gap.
