> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK recursive-cover 的 latent-seed budget（2026-08-19）

## 本轮改变的判断

C340/C411 指出：线性 residual correlation 本身不能推出 seed-length lower bound；
一个短 seed 可以在许多坐标之间重复制造相关性。C412 则说明 JK recursive cover
需要超过 root capacity 的 leaf correlation。本 note 把两者接起来，处理一个自然且
可证伪的 global-relation architecture：

> leaves 只通过一个 latent seed \(U\) 相关，给定 policy 和 \(U\) 后彼此独立。

在这个模型中，tree-correlation 不能超过 \((m-1)H(U)\)。于是高熵
recursive cover 必须支付一个显式的 seed budget；短 seed 不是免费的第三条路。

## 定理 413.1（latent-seed recursive-cover budget）

沿用 C412 的设置。令 \(\mathcal T_d\) 为深度 \(d\) 的完整二叉树，叶数
\(m=2^d\)，\(L=(L_v)_{v\in\mathcal L}\) 为 \(2k\)-bit leaves，\(G_k\) 的
canonical inverse 递归在整棵树上 exact closed。设 \(S\) 是 policy/descriptor，
\(U\) 是一个 latent seed，并假设

\[
  L_v\ \text{在给定 }(S,U)\text{ 后相互独立}.
\tag{413.1}
\]

则

\[
  \boxed{
  \sum_{v\in\mathcal L}H_2(L_v\mid S)-k
  \ \le\
  \operatorname{TC}_2(L\mid S)
  \ \le\
  (m-1)H_2(U\mid S).
  }
\tag{413.2}
\]

特别地，若 \(U\) 只有 \(d\) bits，且每个 leaf 满足
\(H_2(L_v\mid S)\ge h_v\)，则

\[
  H_2(U\mid S)
  \ge
  \frac{\left(\sum_v h_v-k\right)_+}{m-1},
  \qquad m\ge2.
\tag{413.3}
\]

### 证明

左侧不等式是 C412 的 Theorem 412.1。对右侧，写
\(I_v:=I_2(U;L_v\mid S)\) 和 \(I_*:=I_2(U;L\mid S)\)。由 (413.1)，

\[
\begin{aligned}
  \operatorname{TC}_2(L\mid S)
  &=\sum_v H_2(L_v\mid S)-H_2(L\mid S)\\
  &=\sum_v I_v-I_*.
\end{aligned}
\tag{413.4}
\]

因为 \(L\) 包含每个 \(L_v\)，有 \(I_*\ge\max_v I_v\)。又每个
\(I_v\le H_2(U\mid S)\)，所以

\[
  \sum_v I_v-I_*
  \le \sum_v I_v-\max_v I_v
  \le (m-1)H_2(U\mid S).
\]

这证明右侧，合并即得 (413.2)。若
\(\sum_vh_v>k\)，将 (413.2) 左侧代入并整理得到 (413.3)。证毕。

## 解释与边界

### 1. 短 seed architecture 的直接关闭

若 \(m\) 个 non-output leaves 各保留 \(h\) bits 条件 entropy，则

\[
  H_2(U\mid S)\ge\frac{(mh-k)_+}{m-1}.
\tag{413.5}
\]

因此，给定 seed 后条件独立的 cover 若想承载超过 \(k\) bits 的总 leaf entropy，
必须让 seed 的 conditional entropy 达到相应预算。尤其当 \(m=2\) 时，seed 至少
承载 \(h_1+h_2-k\) bits；这正是 C402 两-block product barrier 的 correlated
版本。

### 2. 什么被排除，什么仍然开放

定理 413.1 排除的是明确的 conditional-product architecture：所有跨 leaf 的
相关性都经过 \(U\)，且一旦给出 \((S,U)\)，各 leaf 使用独立 private randomness。
它不排除：

* 一个不能压缩为单一 seed 的 global relation；
* leaves 在给定 \((S,U)\) 后仍有高阶联合约束；
* cover sheet、interactive transcript 或全局 algebraic equation 直接耦合整棵树。

这些路线必须被作为新的 source-specific mechanism 明确写出，不能继续称为
“短 seed cover”。

### 3. 对 RW/Harsha 的最小 source obligation

若 \(L_v\) 是 non-output canonical witness blocks，且一个 proposed \(H_{\rm wit}\)
声称它们由一个地址尺度 policy \(S\)、一个 \(d=\operatorname{polylog}(n)\)-bit
latent seed \(U\) 和独立 local randomness 生成，同时保持 JK recursive closure，
则必须满足

\[
  \sum_v H_2(L_v\mid S)
  \le k+(m-1)d.
\tag{413.6}
\]

若 systematic-witness entropy test 给出左侧大于该值，三者不能同时成立：

1. address-scale short seed；
2. conditional-product leaf generation；
3. exact recursive range closure。

这比单纯的 \(|R|\le2^k\) 更精确，因为它允许相关性存在，但给出了相关性的
可计价来源。

## 与 C411/C412/C410 的关系

* C412 给出 root capacity 对 leaf correlation 的下界；
* C413 把该 correlation 上界转成 latent-seed 长度预算；
* C411 处理整个 global word 的 target-channel / residual-correlation 三分；
* C410 处理不依赖 family entropy 的 singleton JK half-lift circuit cost。

所以当前 recursive-cover 逃逸被压成：

\[
\begin{array}{c}
\text{conditional-product short seed}
  \Longrightarrow \text{(413.6) seed payment};\\
\text{independent JK half-lifts}
  \Longrightarrow \text{C410 circuit payment};\\
\text{其余方案}
  \Longrightarrow \text{必须展示新的 non-product global relation}.
\end{array}
\tag{413.7}
\]

本定理不证明 published RW singleton 已满足或违反 (413.1)，也不把 seed budget
误写成一般 global-relation impossibility。它把 C340 留下的“短 seed 仍可能产生
线性 correlation”收缩为一个明确的、可核验的模型分支。

## 证据边界

* C412：recursive-cover tree-correlation inequality；
* C411：global-relation residual-correlation trichotomy；
* C410：singleton JK-lift parent-binding circuit cost；
* C402：product-rich recursive range-closure capacity。

这是一个 latent-seed architecture theorem，不是 \(P\ne NP\) 证明或一般
dPCP/RLDC 不可能性定理。
