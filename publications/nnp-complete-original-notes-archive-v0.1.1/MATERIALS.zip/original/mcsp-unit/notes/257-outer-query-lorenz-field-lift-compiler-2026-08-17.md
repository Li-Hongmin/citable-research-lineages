> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Outer-query Lorenz bound for the field-lifted one-proof compiler (2026-08-17)

## Contribution

The field-lift compiler does not need a pointwise smoothness bound on the outer
decoder.  Its exact wrong-claim cost is the Lorenz mass of the honest outer-query
profile at the dPCP error budget.  This strictly refines the usual
\(q_D\lambda\varepsilon\) estimate and separates the two mechanisms that can make
the compiler fail: concentration of outer queries, and local dPCP list error.

## Setup

Let

\[
C:\{0,1\}^{k}\longrightarrow\Gamma^{M}
\]

be an outer code.  For each \(i\in[k]\), let
\(\mathsf{Dec}_i\) be an adaptive outer decoder that makes at most \(q_D\)
queries.  On the exact codeword it never outputs the wrong bit, and it outputs
the correct bit with probability at least \(\alpha\).

Fix a message \(m\).  On the honest oracle \(C(m)\), let
\(T_{m,i}(\omega)\) be the ordered multiset of outer positions queried by
\(\mathsf{Dec}_i\) on random tape \(\omega\), and set

\[
p_{m,i}(t):=\mathbb E_\omega[\#\{\text{occurrences of }t\text{ in }T_{m,i}(\omega)\}].
\tag{257.1}
\]

Thus \(\sum_t p_{m,i}(t)\le q_D\).  For \(0\le\varepsilon\le1\), define the
fractional top-\(\varepsilon M\) mass

\[
\operatorname{Lor}_{\varepsilon}(p)
 :=\max\left\{\sum_{t=1}^{M}p(t)e(t):
 0\le e(t)\le1,\ \sum_t e(t)\le\varepsilon M\right\}.
\tag{257.2}
\]

Equivalently, if (p_{(1)}\ge\cdots\ge p_{(M)}), then

\[
\operatorname{Lor}_{\varepsilon}(p)
 =\sum_{j\le\lfloor\varepsilon M\rfloor}p_{(j)}
 +(\varepsilon M-\lfloor\varepsilon M\rfloor)
 p_{(\lfloor\varepsilon M\rfloor+1)},
\tag{257.3}
\]

with the evident conventions at the endpoints.  Put

\[
\Lambda^{\mathrm{out}}_{\varepsilon}
 :=\max_{m,i}\operatorname{Lor}_{\varepsilon}(p_{m,i}).
\tag{257.4}
\]

Now apply a \(q_P\)-query dPCP to the lifted relation from the field-lift compiler:
every valid lifted word projects to the same codeword \(C(m)\), and for every proof
assignment \(z\) the per-position probabilities

\[
e_t(z):=\Pr_{e\sim\mathcal P_t}
 [\text{the local edge is accepted and its decoded symbol differs from }C(m)_t]
\tag{257.5}
\]

satisfy \(M^{-1}\sum_t e_t(z)\le\varepsilon\) by dPCP list soundness.
The compiled verifier aborts on a rejected edge or \(\bot\), and otherwise feeds the
decoded symbols to \(\mathsf{Dec}_i\). Each local dPCP invocation uses fresh edge
randomness; equivalently, (257.5) may be read as a bound on every conditional
local-call error probability before the first wrong projection.

## Theorem (outer-query Lorenz field lift)

For every candidate proof assignment \(z\), the compiled wrong-claim verifier has
acceptance probability at most

\[
\Pr[V_{i,1-m_i}(z)=1]
 \le \operatorname{Lor}_{\varepsilon}(p_{m,i})
 \le \Lambda^{\mathrm{out}}_{\varepsilon}.
\tag{257.6}
\]

The correct branch on the honest proof has acceptance probability at least \(\alpha\).
Consequently, if

\[
\Lambda^{\mathrm{out}}_{\varepsilon}<\alpha,
\tag{257.7}
\]

the field-lift compiler gives a simultaneous coordinate-robust one-proof system with
gap at least \(\alpha-\Lambda^{\mathrm{out}}_{\varepsilon}\), using at most
\(q_Pq_D\) proof queries and one common proof/address space.

### Proof

Couple a compiled execution on \(z\) with the honest outer execution using the same
outer randomness.  Until the first locally accepted projection that differs from
\(C(m)_t\), every non-aborting local answer is the honest codeword symbol.  Hence the
outer decoder follows its honest path.  A wrong output therefore implies a first
wrong accepted projection.  By a union bound over the honest query occurrences,

\[
\Pr[V_{i,1-m_i}(z)=1]
 \le \sum_{t=1}^{M}p_{m,i}(t)e_t(z).
\tag{257.8}
\]

The right side is at most (257.2), because \(0\le e_t(z)\le1\) and
\(\sum_t e_t(z)\le\varepsilon M\).  The last inequality in (257.6) is the
definition of (257.4).  On the honest proof every local edge is accepted and every
projection equals \(C(m)\), so exact-codeword safety gives the stated completeness.
\(\square\)

## Exact consequences

1. **Uniform outer path.** If \(p_{m,i}(t)\le q_D\lambda/M\) for all \(m,i,t\),
   then
   \[
   \Lambda^{\mathrm{out}}_{\varepsilon}\le q_D\lambda\varepsilon,
   \tag{257.9}
   \]
   recovering the standard smoothness estimate.

2. **Private blocks.** If an honest decoder distributes its \(q_D\) query mass
   uniformly on a coordinate-private block of \(K\) positions, then
   \[
   \operatorname{Lor}_{\varepsilon}(p_{m,i})
   =q_D\min\{1,\varepsilon M/K\}.
   \tag{257.10}
   \]
   Thus a constant branch gap requires the dPCP error budget to be below the
   private-block fraction, not merely below an unspecified smoothness constant.

3. **Profile rather than a worst coordinate.** The bound depends on the sorted
   honest-query profile, so a decoder may have a few heavier positions without paying
   the crude \(M\max_t p(t)\) bound, provided their total top-\(\varepsilon M\) mass is small.
   Conversely, no argument using only the honest profile can improve (257.6): take a
   local-error vector \(e\) supported on the top positions and saturate the budget.

4. **Coding closure.** If the field-lifted proof family is exact on honest codewords and
   \(\Lambda^{\mathrm{out}}_{\varepsilon}\le1-\eta\), the resulting common proof is an
   adaptive \((q_Pq_D,\rho,\eta)\)-RLDC whenever the chosen positive radius is valid.
   The pathwise Lorenz theorem then applies to the proof-position profile. Hence a
   proposed address-scale construction must pass two independent Lorenz tests: one on
   outer output positions (257.4), and one on proof positions.

## Boundary

The theorem is a composition statement, not a new dPCP construction. It uses the exact
GMWZ list-soundness quantifier: the average probability of an accepted decoded symbol
outside a short list is at most \(\varepsilon\). The lifted relation is what makes every
word in that list project to the same \(C(m)\). Without this output-homogeneity, the
error vector in (257.5) need not be defined relative to one target word, and the theorem
does not follow.

It also does not remove the address-scale bottleneck. For the published GMWZ RLDC, the
coordinate-private support makes (257.10) force an inverse-linear error budget, so the
alphabet and proof parameters become \(k\)-dependent. A globally smooth outer decoder is
still the only way for a fixed-error field lift to enter the near-linear regime.

## Sources

* [GMWZ dPCP definition and list soundness](https://arxiv.org/html/2512.12960), Definition 1.3.
* [Field-lifted one-proof output-relation compiler](217-field-lifted-one-proof-output-relation-dpcp-compiler-2026-08-17.md).
* [Pathwise Lorenz closure](226-pathwise-lorenz-profile-adaptive-shared-proof-closure-2026-08-17.md).
