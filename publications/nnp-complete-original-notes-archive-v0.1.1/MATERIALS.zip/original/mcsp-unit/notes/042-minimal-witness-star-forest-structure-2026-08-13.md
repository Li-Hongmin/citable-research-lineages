> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 极小 witness 的 star-forest 结构与剩余 AEKR 接口（2026-08-13）

## 模型

固定 \(X,Y\subseteq\mathbb F_2^N\)，\(X\cap Y=\varnothing\)，以及
spoiler \(s=(x_s,y_s)\)。cell 集 \(T\subseteq X\times Y\) 的投影记为

\[
R(T)=\{x:\exists y,\ (x,y)\in T\},\qquad
C(T)=\{y:\exists x,\ (x,y)\in T\}.
\]

写

\[
q_x=(x,1),\qquad p_y=(y,1),
\]

并令 \(q_xz=0,\ p_yz=1\) 是 affine leaf 的行、列方程。于是

\[
L(T)=
\{z:q_xz=0\ (x\in R(T)),\ p_yz=1\ (y\in C(T))\}.
\tag{1}
\]

因此 \(L(T)\) 只依赖投影二部图的顶点集，而不依赖同一
row--column 对是否重复出现。

## Star-forest 引理

把 \(T\) 看成二部图 \(G_T\)，左顶点为 \(R(T)\)，右顶点为 \(C(T)\)，
每个 cell 为一条边。

**引理。** 若 \(T\) 是关于 \(s\) 的 inclusion-minimal collision witness，
即

\[
L(T)\ne\varnothing,\qquad L(T\cup\{s\})=\varnothing,
\]

且删去任意 \(c\in T\) 后 \(L((T\setminus\{c\})\cup\{s\})\ne\varnothing\)，
则 \(G_T\) 的每条边至少有一个端点度为 \(1\)。因而 \(G_T\) 是
star forest（每个连通分量是一颗星）。

**证明。** 若 \(c=(x,y)\) 的两个端点在 \(G_T\) 中均有度至少 \(2\)，
删去 \(c\) 不改变 \(R(T)\) 或 \(C(T)\)。由 (1)

\[
L(T\setminus\{c\})=L(T),
\]

从而

\[
L((T\setminus\{c\})\cup\{s\})
=L(T\cup\{s\})=\varnothing,
\]

与极小性矛盾。故每条边有叶端点。若一个连通分量不是星，则它含有一条
两端均为非叶顶点的边，矛盾。证毕。

## 直接质量后果

设 \(k=|T|\)，\(c(T)\) 为 \(G_T\) 的连通分量数，\(p=|R(T)|\)，
\(q=|C(T)|\)。star forest 的每个分量是树，故

\[
p+q=k+c(T).
\tag{2}
\]

另一方面，极小 witness 的秩增一引理给出

\[
\operatorname{rank}A_T\ge k+1.
\tag{3}
\]

所以随机 \(z\) 命中 \(L(T)\) 的质量至多 \(2^{-(k+1)}\)；条件于
\(z\in L(T)\)，行、列各以 \(1/2\) 保留后完整保留 \(T\) 的概率为
\(2^{-(p+q)}\)。因此

\[
\boxed{
\Pr[T\subseteq R_z(U,V)]
\le 2^{-(k+1+p+q)}
=2^{-(2k+c(T)+1)}.
}
\tag{4}
\]

特别地，连通 star (\(c(T)=1\)) 满足
\(\operatorname{rank}A_T=p+q=k+1\)，所以其行、列方程线性独立。

## 连通 star 的 XOR 证书

设 \(T\) 是中心 row \(x_0\) 的连通 star，列集为 \(S\)，
\(|S|=k\)。由于

\[
\dim\operatorname{span}\{q_{x_0}\}\cup\{p_y:y\in S\}=k+1,
\]

碰撞不相容证书唯一确定一个

\[
w\in\{q_{x_s},p_{y_s},q_{x_s}+p_{y_s}\}
\]

及 \(\alpha\in\mathbb F_2\)，使

\[
w=\alpha q_{x_0}+\sum_{y\in S}p_y,
\tag{5}
\]

且该向量关系的右端常数与 \(w\) 的 spoiler 常数不一致。
极小性迫使每个 \(p_y\) 的系数均为 \(1\)；否则删去对应 cell 后
同一不相容证书仍存在。

取第一坐标，(5) 给出

\[
\bigoplus_{y\in S}y
=w_{\mathrm{first}}+\alpha x_0.
\tag{6}
\]

故同一中心、同一 \((w,\alpha)\) 的所有连通 star witness 都是同一个
XOR target 的列表示族。中心 column 的情形完全对偶。

若两颗连通 star 都是 row-star 且中心不同，则它们不可能共享 cell；
若都为 column-star 且中心不同，同样不可能。若 row-star 与 column-star
同时出现，任何交点只能是两中心的唯一 cell；两两相交于是强制所有这类
stars 共同包含该 cell。

## 唯一 pair + 非锚点高阶 witness 的剩余接口

设见证族 \(\mathcal F\) 两两相交，唯一选定的二元 witness 为
\(P=\{a,u\}\)，并存在 \(T_0\in\mathcal F\) 满足 \(u\in T_0\)、\(a\notin T_0\)、
\(|T_0|\ge3\)。由于 \(P\) 是 cover，任意见证属于

\[
\mathcal F_a=\{T:a\in T,\ u\notin T\}
\quad\text{或}\quad
\mathcal F_u=\{T:u\in T,\ a\notin T\},
\]

另加 \(P\)。对任意 \(T\in\mathcal F_a\)，
\(T\cap(T_0\setminus\{u\})\ne\varnothing\)；对偶地，若选定
\(T_1\in\mathcal F_a\)，则每个 \(T\in\mathcal F_u\) 与
\(T_1\setminus\{a\}\) 相交。这是 residual cross-intersection 的唯一
一般覆盖关系。

式 (4) 对每个高阶 witness 给出指数小的单项质量，但不能对
\(T_0\setminus\{u\}\) 的不同交点直接求和：其大小可随 \(N\) 增长。
若所有 witnesses 共含某一 cell，则事件直接被该 cell 命中事件包含，
概率至多 \(1/16\)；若只含同一 row/column，还需利用 (5)--(6) 的
XOR-target 分层。一般 star forest 族仍可能由多个 disjoint stars 组成。

因此目前可审计的最小未决接口是

\[
\boxed{
\text{多组件 star forest 的 residual cross-intersection，
\text{以及同中心连通 stars 的多 XOR-target 联合质量。}}
\]

这条结构引理不等于完整的 affine-biclique AEKR：
它尚未推出
\(\Pr_{z,U,V}[\exists T\in\mathcal F:T\subseteq R_z(U,V)]\le1/16\)。
一个合法的“唯一 pair + 两个高阶支”实例及其精确质量见
[note 039](039-one-edge-pair-star-obstruction-2026-08-13.md)。
