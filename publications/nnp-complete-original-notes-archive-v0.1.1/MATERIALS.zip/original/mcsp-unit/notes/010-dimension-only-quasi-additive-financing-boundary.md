> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 纯维数 quasi-additive 势的融资边界

## 1. 对称 ansatz 的精确降维

沿用 [[009-affine-leaf-cover-hierarchy-and-quasi-additive-target]] 的 quasi-additive LP。令

\[
C=X\times Y,qquad m=|X||Y|,
\]

并限制到

\[
\phi_c\equiv\alpha,
\qquad
\psi_{c,R}
=g\!\left(dim\operatorname{aff}A,dim\operatorname{aff}B,mathbf1[c\in R]\right),
\]

其中 \(R=A\times B\)。由于 LP 中 \(\psi_{c,R}\) 只在 \(c\notin R\) 时出现，第三个参数不可见。令

\[
h(p,q)=g(p,q,0),
\qquad
K(A,B)=\bigl(m-|A||B|\bigr)h(p,q),
\]

则全部约束精确化为

\[
\alpha|A||B|+K(A,B)\le1
\qquad
(A\times B\text{ 为 parity-monochromatic}),
\tag{leaf}
\]

以及对每个横向或纵向二分 \(R=V\mathbin{\dot\cup}W\)，

\[
K(V)+K(W)\ge K(R).
\tag{recursion}
\]

常数势 \(h\equiv k\) 时，递归约束强制 \(k\ge0\)。把 `(leaf)` 对至多 \(2N\) 个坐标 parity 叶求和，并使用

\[
\sum_{j,t}|R_{j,t}|
=
\sum_{x,y}d_H(x,y)ge m,
\]

即可得到

\[
\alpha m\le2N.
\]

所以最简单的 dimension-blind quasi-additive 证书至多线性。

## 2. 坐标叶非负性不由递归推出

把上述证明推广到一般 \(h(p,q)\) 的自然尝试，是从 `(recursion)` 推出

\[
\Delta(h)
:=
\sum_{j,t}K(X_{j,t},Y_{j,1-t})ge0.
\]

该命题在 \(N=2\) 已经失败。取

\[
X=\{00\},
\qquad
Y=\{01,10,11\},
\qquad
m=3,
\]

并设

\[
h(0,0)=a>0,
\qquad
h(0,1)=-2a.
\]

于是：

- singleton rectangle 的 \(K\) 值为 \(2a\)；
- 两点 column set 的仿射维数为 (1)，相应 \(K=-2a\)；
- 根矩形的系数 \(m-|X||Y|=0\)，故 \(K=0\)。

所有非平凡递归二分都满足

\[
2a+(-2a)ge0,
\qquad
2a+2age-2a.
\]

但两个非空坐标 parity 叶各有势 \(-2a\)，所以

\[
\boxed{\Delta(h)=-4a<0.}
\]

交换 (X,Y) 并取 (h(0,0)=1,h(1,0)=-1) 给出同一机制。(N=1) 时相关系数均退化，因此 (N=2) 是最小维数。

## 3. Leaf 约束仍限制最终目标

上述反例不产生超线性 QA 值。加入 `(leaf)` 后，singleton 与两点叶分别给

\[
\alphale1-2a,
\qquad
2\alpha-2ale1.
\]

最优交点为

\[
a=\frac16,
\qquad
\alpha=\frac23,
\qquad
m\alpha=2=N.
\]

所以已经严格排除的是分离式论证

\[
\text{先由 recursion 证明所有坐标叶净势非负，
再对 leaf constraints 求和}.
\]

尚未排除的命题是

\[
\boxed{
(leaf)+(recursion)
\Longrightarrow
\alpha|X||Y|=O(N)
}
\]

对所有 affine-dimension-only ansatz 是否成立。

反例揭示了唯一需要控制的机制：

\[
\text{负的高维叶势}
\longleftarrow
\text{正的低维矩形势融资}.
\]

因此下一原子引理不应要求 (K\ge0)，而应界定：沿任意递归矩形分割，负势能够由仿射维数下降融资的累计次数是否至多 (O(N))。根部维数、交维数及 minimum affine-certificate 数据本身不足以决定递归协议数；小维度实例已出现这些根签名相同而协议叶数不同的函数。

~~~mermaid
flowchart LR
    R["recursion 超可加"] --> P["低维正势"]
    P --> F["融资高维负势"]
    F --> X["坐标叶和可为负"]
    X --> J["必须联合 leaf 约束"]
    J --> O{"累计融资 ≤ O(N)?"}
~~~

