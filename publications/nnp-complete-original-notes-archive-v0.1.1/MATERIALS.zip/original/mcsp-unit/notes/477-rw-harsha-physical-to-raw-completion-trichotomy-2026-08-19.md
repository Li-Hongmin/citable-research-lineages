> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW/Harsha physical-radius 到 raw-completion 的量词三分（2026-08-19）

## 本轮改变的判断

C476 的 dense-fold barrier 需要的不是“physical proof 很近”这一句，而是：在
honest raw vector 周围，每个 raw coordinate 的一格 completion 都由 correctness
domain 中的某个 physical proof 实现。Ren--Williams 的 published PCP 接口明确把
proof 写成

\[
  \Pi=(\widetilde w,\Pi'),
\]

其中 \(\widetilde w\) 是 witness 的 Reed--Muller 编码，\(w=\widetilde w|_{H^m}\)
是 systematic witness；但其 soundness 只保证一个被接受的 proof 的
\(\widetilde w\) 接近某个合法低度多项式。这个陈述本身既不把所有 physical 邻居
投影成 raw completion，也不把 off-code 邻居纳入 single-valued raw evaluator 的
correctness domain。

因此，published RW/Harsha 上的高元 folding 必须先通过下面的 source-specific
completion 三分；不能把 C476 的 raw-family 前提静默替换成 physical Hamming 半径。

## 设置

令 \(z^\star\) 是固定 honest proof，\(\rho_{\rm raw}\) 是候选 folding 接口从
physical proof 提取 raw 向量的映射，\(\mathcal D\) 是其声称的 correctness domain。
称 raw 坐标 \(j\) 有 **physical one-cell completion**，若对某个
\(\delta\ne0\)，存在

\[
  z^{(j,\delta)}\in\mathcal D,
  \qquad
  \operatorname{dist}(z^{(j,\delta)},z^\star)\le1,
  \qquad
  \rho_{\rm raw}(z^{(j,\delta)})
   =\rho_{\rm raw}(z^\star)+\delta e_j .
\tag{477.1}
\]

若只对一组坐标 \(J\) 存在这样的 completion，则称 completion support 为 \(J\)。

## 定理 477.1（RW/Harsha physical-to-raw completion 三分）

对 published RW/Harsha 型 proof 与任意 dense linear raw fold，按其 correctness
domain 与 raw projection，候选至少落入下面三类接口之一；混合方案必须逐坐标说明
自己属于哪一类：

### A. 直接 systematic/off-code completion

若 \(\rho_{\rm raw}\) 是若干互不相同 physical proof cells 的直接投影，且
\(\mathcal D\) 包含 honest proof 的所有一-cell 邻居，则每个 raw coordinate 都满足
(477.1)。因此 C476 定理 476.1/476.4 直接给出：逐点错误至多
\(\varepsilon<1/2\) 时，每个 dense coordinate 的查询概率至少
\(1-2\varepsilon\)；允许 \(\bot\) 时至少
\(\max\{0,\nu-2\beta\}\)。

更一般地，只对 completion support \(J\) 可用时，C476 至少强制

\[
  \mathbb E Q(z^\star)
  \ge |J|\,\max\{0,\nu-2\beta\}.
\tag{477.2}
\]

### B. codeword/decoded-domain

若 \(\mathcal D\) 只允许 Reed--Muller codeword（或只在其解码域上定义 raw
projection），则 physical 半径不提供 raw completion。确实，Ren--Williams 的
Theorem 3.4--3.5 使用总次数至多 \(d=m|H|\) 的多项式、\(|F|\ge\alpha d^3\)。
对两个不同 codeword，Schwartz--Zippel 给出 evaluation-table 距离至少

\[
  d_{\rm RM}\ge |F|^m\left(1-\frac d{|F|}\right)>1.
\tag{477.3}
\]

所以半径小于 \(d_{\rm RM}\) 的 codeword 邻域中没有第二个合法 codeword；改变
\(w|_{H^m}\) 的 raw coordinate 不能由一个同半径的合法 encoded proof 实现。
若 raw projection 使用半径小于 \(d_{\rm RM}/2\) 的唯一解码器，同样的结论对所有
该物理球中的 received words 成立：它们都解码回同一个 codeword。
在这个分支 C476 的 raw-completion 前提不成立，必须另证一个允许 off-code
completion 的 global relation，或为 decoded raw value 支付新的非局部 binding/repair
成本。

### C. mixed / unspecified projection

若 proof 物理半径只实现某些 raw completions，或 \(\mathcal D\) 对 off-code 邻居没有
single-valued 语义，则只能对实际 completion support 应用 (477.2)。其余坐标不能被
视为已经通过 C476；候选必须明确它们由哪一种 nonlocal code constraint、cover/sheet
binding 或新的 global relation 绑定。只引用“\(\widetilde w\) 是 systematic”并不能
自动把所有 generic/raw fold 输入变成 physical one-cell completions。

### 证明

分支 A 中，直接投影意味着改变对应 physical cell 即实现
\(\rho_{\rm raw}(z^\star)+\delta e_j\)，故 C476 的耦合证明逐坐标适用；只在 \(J\)
上求和得到 (477.2)。分支 B 中，任意改变 raw witness 后得到不同 codeword；由
Schwartz--Zippel 的距离下界，这两个 encoded tables 的 physical 距离至少
\(d_{\rm RM}>1\)，因此不存在半径一的合法 completion。分支 C 只是按
completion 的实际存在集合限制同一耦合论证；未实现的坐标没有可调用的邻居，不能
由 physical radius 推出 raw-domain 命题。证毕。

## 对 Closure 的直接影响

1. **C476 现在有了 published-source 入口。** 若候选把 raw fold 输入放在
   \(\widetilde w\) 的 systematic physical cells 上，并声称对所有一-cell physical
   邻居仍 single-valuedly 正确，则它立即支付 dense arity；这是真正的 Gate-II
   source-specific 应用。
2. **普通 Reed--Muller proximity 不足以触发 C476。** Published soundness 的
   “\(\widetilde w\) 接近某个合法多项式”是 codeword proximity 结论，不是 raw
   completion 结论。把两者混写会错误关闭 published factorized branch。
3. **剩余正攻被精确定位。** 要继续走高元 folding，必须给出 (i) off-code 邻居上的
   single-valued raw semantics，或 (ii) 一个 nonlocal global relation，证明其在
   physical 半径内仍绑定每个未读 raw coordinate；否则只能退回 C471 的 support/forcing
   支付或 C459 的 generic-access forcing gate。

本定理是 source-specific 量词闭合，不是一般 PCP/FRI/PCS 不可能性，也不证明
\(P\ne NP\)。

## 来源

* Ren--Williams, ECCC TR26-118 revision 1, Theorems 3.4--3.5（proof
  \(\Pi=(\widetilde w,\Pi')\)、systematic witness prefix 与 proximity soundness）。
* [C476 positive-radius completion barrier](476-positive-radius-completion-barrier-for-high-arity-folding-2026-08-19.md)。
* [C471 singleton proof-support forcing gate](471-rw-singleton-proof-support-forcing-gate-2026-08-19.md)。
* [C459 published RW generic-access forcing](459-published-rw-generic-q-access-forcing-scale-2026-08-19.md)。
