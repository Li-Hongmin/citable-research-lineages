> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(E_a\times NO_b\) 的 affine-kernel 承重引理（2026-08-13）

## 命题

设真值表空间为 \(V=\mathbb F_2^N\)，

\[
E_a=\{x:\operatorname{CC}(x)\le a\},\qquad
NO_b=\{y:\operatorname{CC}(y)>b\}.
\]

考虑任意 affine-parity 叶协议覆盖关系
\(T=E_a\times NO_b\)。第 \(i\) 个叶使用

\[
\ell_i(z)=r_i\cdot z\oplus c_i,
\]

并只接收满足 \(\ell_i(x)\ne\ell_i(y)\) 的点对（叶的方向 \(t_i\) 只进一步限制行列，
不改变这个必要条件）。令

\[
K=\bigcap_i\ker r_i,\qquad q=\operatorname{codim}K=\operatorname{rank}\{r_i\}.
\]

则

\[
\boxed{E_a\oplus K\subseteq E_b.}
\tag{K}
\]

若 \(0\in E_a\)（MCSP 参数 \(a\) 足够大时成立），特别地 \(K\subseteq E_b\)；一般情形只可对任意固定 \(x_0\in E_a\) 写 \(x_0\oplus K\subseteq E_b\)。

## 证明

对 \(d=x\oplus y\)，

\[
\ell_i(x)\oplus\ell_i(y)=r_i\cdot d.
\]

若 \(d\in K\)，右侧对所有 \(i\) 为零，故没有任何叶能接收 \((x,y)\)。
而协议必须覆盖 \(E_a\times NO_b\)，所以任意 \(x\in E_a\) 与 \(d\in K\) 都满足
\(x\oplus d\notin NO_b\)，即 \(x\oplus d\in E_b\)。这正是 (K)。

## 直接的叶数下界

固定有限门基。大小至多 \(b\) 的 \(n\)-变量电路数满足

\[
|E_b|\le 2^{L_b},\qquad L_b=O\bigl(b\log(n+b)\bigr).
\]

在 \(0\in E_a\) 时取 \(x=0\) 于 (K)，得 \(K\subseteq E_b\)。故

\[
N-q=\dim K\le L_b,
\]

而 \(q\le s\)（\(s\) 为叶数），从而

\[
\boxed{s\ge N-L_b.}
\tag{1}
\]

在 Frontier-B 参数 \(b=2^{(\log N)^{2/3}}\) 下，\(L_b=N^{o(1)}\)，故任意 affine-leaf
协议至少需要 \(N-N^{o(1)}\) 个叶。这个结论确实使用了 \(NO_b\) 的全包含语义，
不是密度或距离估计。

## 加强：低复杂度平移的商空间容量

若 \(a\ge Cn\)，则 \(E_a\) 含有所有重量至多

\[
m=\left\lfloor a/(Cn)\right\rfloor
\]

的真值表（每个点谓词是一个 \(n\)-文字 minterm）。令 \(Q=V/K\)，
\(\dim Q=q\)。从 \(N\) 个单位向量中取在 \(Q\) 中成基的 \(q\) 个，
它们的重量至多 \(m\) 的和给出至少

\[
B(q,m)=\sum_{j=0}^{\min(m,q)}\binom qj
\]

个不同余类。因此 (K) 还蕴含

\[
2^{N-q}B(q,m)\le |E_b|,
\qquad
N-q+\log_2 B(q,m)\le L_b.
\tag{2}
\]

式 (2) 是语义的 affine-leaf capacity 不变量；它把 \(NO_b\) 的“所有高复杂度点均被拒绝”
转为一个低复杂度集合不能容纳太多 \(K\)-余类的精确约束。

## 3. 方向感知的列侧约束

同一覆盖还给出一个与叶方向有关的对偶条件。写
\(b_i=t_i\oplus c_i\)，并对固定 \(y\in NO_b\) 定义

\[
J_y=\{i:\ell_i(y)=1-t_i\}.
\]

若 \(x\) 不被任何叶与 \(y\) 配对，则对所有 \(i\in J_y\) 都有
\(\ell_i(x)=\ell_i(y)\)，因此

\[
F_y:=y+\bigcap_{i\in J_y}\ker r_i
\quad\text{满足}\quad
F_y\cap E_a=\varnothing .
\tag{3}
\]

若 \(E_a\) 含所有重量至多 \(m\) 的真值表，记
\(q_y=\operatorname{rank}\{r_i:i\in J_y\}\)。若 \(q_y\le m\)，从这些行中取
\(q_y\) 个独立列，便可用至多 \(q_y\) 个坐标解出 syndrome
\(R_{J_y}y\)。于是 \(F_y\) 含一个重量至多 \(q_y\le m\) 的向量，和 (3) 矛盾。
所以对每个 \(y\in NO_b\)，都有

\[
\boxed{\operatorname{rank}\{r_i:i\in J_y\}\ge m+1.}
\tag{4}
\]

这是比全局 defect kernel 更强的 orientation-aware 双侧约束：行侧对每个
\(x\in E_a\) 要求至少 \(N-L_b\) 个相容叶独立，列侧对每个
\(y\in NO_b\) 要求至少 \(m+1\) 个反向叶独立。但它仍是线性容量信息；要得到
\(N^{1+\delta}\)，还需把不同 \(x,y\) 的方向族之间的递归不相容性编码进势。

## 4. 方向编码的组合覆盖约束

从行侧秩条件，对每个 \(x\in E_a\) 选一个 \(q_0\)-元独立子集
\(B_x\subseteq I_x\)，其中 \(q_0=(N-L_b)_+\)。于是

\[
E_a\subseteq
\bigcup_{\substack{B\subseteq[s],\,|B|=q_0\\ \operatorname{rank}(B)=q_0}}
\{z:r_i\cdot z=b_i\ (i\in B)\}.
\]

每个仿射空间的大小为 \(2^{N-q_0}\le2^{L_b}\)，从而

\[
|E_a|\le {s\choose q_0}2^{N-q_0}.
\tag{5}
\]

若 \(s=q_0+k\) 且 \(0<k\le q_0\)，则

\[
k\log_2\!\frac{e(q_0+k)}k
\ge \log_2|E_a|-(N-q_0).
\tag{6}
\]

这是真正使用叶方向与偏置的组合覆盖约束，而非全局核的简单重述。
在 Frontier-B 参数中 \(L_b\) 远大于 \(\log|E_a|\)，(5)--(6) 仍不足以
推出 \(N^{1.01}\)；它把剩余问题精确压缩为行侧与列侧独立叶集之间的
交叉秩/递归融资。

## 对主线的裁决

这个引理给出唯一不靠随机 thinning 的语义桥，但其量级只有
\(s\ge N-N^{o(1)}\)，不足 \(N^{1.01}\)。因此：

1. 任何只记录叶线性部分的非局部势，至多看到 \(K\subseteq E_b\) 的维数容量，不能
   单独触发 magnification；
2. 若要超线性，势必须继续记录递归中各叶的方向/行列依赖，不能压缩为 defect 的
   单一线性核；
3. (2) 可作为未来语义势的必要条件：候选势若在所有 \(K\)-余类上给出超过
   \(L_b\) 的独立承重，即与 \(E_a\oplus K\subseteq E_b\) 矛盾。

因此当前最小剩余问题不是再改进距离或随机 parity，而是构造一个真正依赖
“不同叶的行列方向相容性”的递归势；纯 defect-kernel 路线已关闭到线性精度。
