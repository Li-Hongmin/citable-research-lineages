> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW scale-complete Closure Audit (2026-08-18)

## Statement

The previous RW Closure-Gate trichotomies treated the failure/reconstruction
branch in detail but did not explicitly retain the stable solver branch after
the object-scale correction of note 357. The following audit is the
scale-complete version.

Let \(H_N\in\{0,1\}^N\) be a hard truth-table object on an infinite set of
RW lengths, with
\[
  \operatorname{CC}(H_N)>S_N,\qquad
  \ell_N=\lceil\log_2(N+1)\rceil .
\tag{358.1}
\]

Assume the RW construction has the following two branch semantics.

* On a solver branch, after replacing the actual smart promise queries by
  deterministic procedures under \(P=NP\), the output is computable in
  \(N^{d_{\rm sol}}\) time for one fixed constant \(d_{\rm sol}\).
* On a failure/reconstruction branch, all addresses use one proof/address
  space, a \(1\) versus \(1/2\) public-coin gap, and a finite straight-line
  ROM response implementation with control size \(p_N\), descriptor length
  \(d_N\), and at most \(b_N\) descriptor reads.

Then every proposed RW-to-\(P/\mathrm{poly}\) closure falls into at least one
of the following five cases.  Case (A) refines the stable branch (S), and case
(F) is available only after the proposed attachment has been upgraded to the
stated family-level interface; they are not additional unconditional
consequences of the RW source theorem.

### (S) Stable object-scale solver

The solver branch remains an \(N^{d_{\rm sol}}\)-size evaluator. It is not
excluded by a forcing lower bound \(S_N=O(N^{d_{\rm sol}})\). In particular,
the RW near-maximum scale
\[
  S_N=\Omega(N/\operatorname{polylog}N)
\]
is compatible with this branch.

### (A) Address-scale solver compression

The solver branch has an additional evaluator of size
\(\ell_N^{O(1)}\) (or a fixed-depth PH surface whose total quantified input
length is \(\ell_N^{O(1)}\)). Then the address-surface sampling theorem
\[
  \operatorname{CC}(H_N)
  \le
  O\!\left(
  \frac{\ell_N+\log(1/\delta)}{\gamma_N^2}
  \right)
  \times \operatorname{poly}(\ell_N)
\tag{358.2}
\]
holds whenever the gap is bounded below by a fixed constant
\(\gamma_N\ge\gamma_0>0\); under \(P=NP\), the PH version
also collapses to this evaluator. Thus a forcing scale
\(S_N=2^{\Omega(\ell_N)}/\operatorname{poly}(\ell_N)\) contradicts (A).

### (R) Reconstruction descriptor payment

If a hard length is known to use the failure/reconstruction branch, then the
common proof and gap give
\[
  \operatorname{CC}(H_N)
  \le O\!\left(\ell_N(p_N+b_Nd_N+\ell_N)\right)
\tag{358.3}
\]
in the straight-line ROM model. Consequently
\[
  p_N+b_Nd_N
  =\Omega\!\left(\frac{S_N}{\ell_N}\right)
\tag{358.4}
\]
whenever the control term is smaller than the forcing threshold. For
\(S_N=\Omega(N/\operatorname{polylog}N)\) and
\(p_N,b_N\le\ell_N^{O(1)}\), the descriptor is object-scale:
\[
  d_N=\Omega\!\left(N/\operatorname{polylog}N\right) .
\tag{358.5}
\]

### (F) Family-level coding payment

If the same proposed attachment is upgraded from the one hard object to a
target-relative family with a common proof, positive radius, and fixed
alphabet/locality window, then the RW family--strategy trichotomy applies:
history supply must pay the JK capacity threshold, or global policy defect/
mutual information must pay a constant/linear target cost, or the
finite-alphabet locality/RLDC lower bound is violated. This branch is
conditional on the family lift; a single-target evaluator does not create it.

### (E) Model exit

If none of (S), (A), (R), or (F) is available, at least one advertised hypothesis has
changed: the solver is not object-scale, the proof/address space is not
common, the gap vanishes, the descriptor is not finite, the family lift lacks
target-relative semantics, or the construction uses a new non-transcript
global coupling. This is a model change, not a free additional proof branch.

## Proof

On a stable solver length, the first hypothesis gives a circuit of size at
most \(N^{d_{\rm sol}}\) after \(P=NP\) determinization. This contradicts
(358.1) only when \(S_N>N^{d_{\rm sol}}\); it does not contradict the
near-maximum RW bound \(N/\operatorname{polylog}N\). If the solver branch
also has an address-scale Boolean or fixed-depth PH surface, Hoeffding
sampling and (under \(P=NP\)) PH collapse give (358.2), which is the
address-scale contradiction.

On a failure/reconstruction length, hardwiring a logarithmic-size sample of
public tapes and expanding each ROM read gives (358.3). Combining with
(358.1) gives (358.4), and the near-maximum specialization gives (358.5).
If the attachment is family-level, the independent history-supply,
global-package, and RLDC alternatives are exactly the conditional branches
of the RW family--strategy Closure Gate. These cases exhaust the stated
solver/reconstruction semantics; any omitted case is (E).
\(\square\)

## Consequence for the \(P\ne NP\) program

The audit identifies the only two ways the current RW hard-table theorem can
feed a \(P/\mathrm{poly}\) contradiction:

1. compress the **stable solver** from object scale \(N^{O(1)}\) to address
   scale \(\ell_N^{O(1)}\); or
2. prove that every relevant hard length enters a reconstruction/family branch
   and then close its descriptor, promise, cover, bottom, and locality costs.

The near-maximum lower bound alone does neither. In particular, \(P=NP\)
determinizes SAT/prMA queries at the representation scale supplied by RW; it
does not turn a length-\(N\) computation into a polynomial-in-\(\log N\)
random-access evaluator.

This is a source-specific closure audit, not a \(P\ne NP\) proof and not a
general dPCP impossibility theorem. It replaces the invalid claim that
stable solver lengths are automatically eliminated. Sources: RW
Theorems 4.1--4.5; notes 204, 279, 354, 357; and the ROM expansion in
note 231.
