> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定阶数命中数势的 thinning no-go（2026-08-13）

## 定理

令 \(C=X\times Y\)，\(X\cap Y=\varnothing\)。设 \(\mathcal H\) 是有限 cell 超边族；每个 \(H\in\mathcal H\) 的大小 \(q_H\le Q\)，且没有 affine-parity 单色叶包含 \(H\)。给定

\[
g_H:\{0,\ldots,q_H\}\to\mathbb R,\qquad g_H(0)=g_H(q_H)=0,
\]

并满足

\[
g_H(a)+g_H(b)\ge g_H(a+b)\qquad(a+b\le q_H).
\tag{SA}
\]

取 \(\lambda_H\ge0\)，令

\[
K(R)=\sum_H\lambda_Hg_H(|H\cap R|).
\]

假设每个非零项满足 \(g_H(1)>0\) 且

\[
\frac{\max_{2\le j\le q_H}|g_H(j)|}{g_H(1)}\le B.
\tag{1}
\]

若 QA 叶族包含所有 affine-parity 子矩形，则任意叶变量 \(\phi_c\) 满足

\[
\boxed{\sum_{c\in C}\phi_c\le
4\max\{16Q^2,B^2(Q-2)^2\}.}
\tag{2}
\]

特别地，固定 \(Q,B\) 时目标为 \(O(1)\)。

## 证明

由 (SA)，任意二分 \(R=V\dot\cup W\) 满足

\[
K(V)+K(W)\ge K(R),
\]

且 \(K(C)=0\)。

随机取有向 affine parity 最大叶

\[
R_0=(X\cap\ell^{-1}(0))\times(Y\cap\ell^{-1}(1)).
\]

每个 cell 以概率 \(1/4\) 落入 \(R_0\)。条件于 \(R_0=A_0\times B_0\)，独立保留每个行、列，概率

\[
p=\min\{(4Q)^{-1},[B(Q-2)]^{-1}\},
\]

得到合法子矩形 \(R=A'\times B'\)，每个 cell 以概率 \(p^2/4\) 被保留。

当 \(B=0\) 或 \(Q=2\) 时，第二个约束删去（相应倒数视为
\(+\infty\)）；以下只需 \(p\le(4Q)^{-1}\)。

固定 \(H\)，写 \(G=H\cap R_0\)。因 \(H\) 不是任何最大合法叶的子集，\(m=|G|\le q_H-1\le Q-1\)。条件于 \(R_0\)，把 \(G\) 看成二部图，记 thinning 后边数为 \(M\)。

若 \(m=0\)，贡献为零。若 \(m\ge1\)，对每条边要求其两个端点保留、其余所有出现端点删除，得到互不相交的“恰一边”事件。因此

\[
\Pr[M=1]\ge m p^2(1-p)^{2Q-2}\ge mp^2/2.
\tag{3}
\]

两条不同边同时保留的概率至多 \(p^3\)，故

\[
\Pr[M\ge2]\le {m\choose2}p^3
\le \frac{m(Q-2)}2p^3.
\tag{4}
\]

由 (1)、(3)、(4)，

\[
\mathbb E[g_H(M)\mid R_0]
\ge g_H(1)m p^2
\left((1-p)^{2Q-2}-\frac{B(Q-2)p}{2}\right)\ge0.
\tag{5}
\]

对 \(H\) 求和，\(\mathbb E K(R)\ge0\)。平均叶约束

\[
\sum_{c\in R}\phi_c+K(R)\le1
\]

给出

\[
\frac{p^2}{4}\sum_c\phi_c\le1,
\]

即 (2)。

最后，(1) 不排除非零次可加势。若 \(g(1)<0\)，由
\(g(k)\le g(k-1)+g(1)\) 与 \(g(k)+g(q-k)\ge0\) 矛盾；若 \(g(1)=0\)，同样两式推出 \(g\equiv0\)。故非零项必有 \(g(1)>0\)。

## 含义

所有固定阶数、系数动态范围有界的“超边命中数”递归势都被关闭。若 \(B=O(1)\)，要达到 \(N^{1.01}\)，必须至少有

\[
Q=\Omega(N^{0.505-o(1)}).
\]

因此下一路线必须使用随 \(N\) 增长阶数的全局谱/通信势，或保留超出单个超边命中数的递归状态。
