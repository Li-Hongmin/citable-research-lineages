> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Canonical locally-decodable PCP 仍是单向的（2026-08-15）

## 新的最接近结果

Chen--Williams--Yang 的 *Black-Box Constructive Proofs Are Unavoidable*
（ITCS 2023）给出一个比普通 NEXP PCP 更贴近本项目的构造。其 Theorem 3.7
对一个运行时间为 \(T(n)\) 的验证器 \(V(x,y)\) 给出 PCP verifier \(PCP_V\)，同时满足：

\[
\begin{array}{c}
\text{randomness }O(\log T),\qquad
\text{query }O(1),\qquad
\text{decision time }\operatorname{polylog}(T),\\
\text{smooth},\quad \text{strong},\quad \text{canonical},\quad
AC^0[2]\text{-locally decodable}.
\end{array}
\tag{1}
\]

其 Definition 3.5 的 canonical 性质给出一个映射

\[
\Pi_V(x,y)\in\{0,1\}^{2^{\ell(n)}},
\tag{2}
\]

使得 PCP verifier 的完美接受 proof 恰好是某个满足 \(V(x,y)=1\) 的 witness
\(y\) 所对应的 \(\Pi_V(x,y)\)。Definition 3.6 则给出反向的 local decoder：
对接近某个 canonical PCP witness 的 oracle \(\pi\)，一个
\(\operatorname{poly}(\ell(n))\)-size 的 \(AC^0[2]\) oracle circuit 能以常数概率恢复
一个满足原 verifier 的 witness。

这是目前最接近 RW/JK 的“canonical + local”组合，但两者的方向不同：

\[
\boxed{
\text{witness}\xrightarrow{\ \Pi_V\ }\text{PCP proof}
\quad\text{vs.}\quad
\text{PCP proof}\xrightarrow{\ \text{local decoder}\ }\text{witness}.
}
\]

## 对指数历史的参数

令实际计算历史长度为

\[
T(n)=2^{n^\eta}.
\]

则 PCP oracle 的地址长度为

\[
\ell(n)=\Theta(\log T(n))=\Theta(n^\eta),
\]

而 Theorem 3.7 的局部解码器规模为
\(\operatorname{poly}(\ell(n))=\operatorname{poly}(n)\)。因此，若已经拥有一个
接近 canonical proof 的 oracle，确实可以在地址尺度恢复历史 witness 的坐标。

但这个结论的输入是 proof oracle。它没有给出

\[
(x,y,i)\longmapsto \Pi_V(x,y)[i]
\tag{3}
\]

的 \(\operatorname{poly}(n)\)-size circuit；(3) 正是本项目所需的 forward whole-word
accessor/right-inverse 方向。

## 构造中的具体尺度障碍

Theorem 3.7 的 CktSAT 构造把一个满足赋值 \(y\) 的所有 gate values 写成

\[
A:[h]^m\to\{0,1\},
\]

再取其唯一低度扩展 \(\widehat A:F^m\to F\)。论文明确把一个 canonical proof
piece 写成 \(\widehat A\) 的完整评价表（再加 ECC 和 polynomially many copies）。

当底层电路有 \(s=h^m\) 个 gates 时，在任意非布尔点评价 \(\widehat A(\alpha)\)
通常是 \([h]^m\) 个 \(A\)-值的 Lagrange 线性组合。因此：

\[
\operatorname{cost}\bigl(\Pi_V(x,y)[i]\bigr)
\le O(s\operatorname{polylog}s)
\]

是构造直接给出的尺度，而不是
\(\operatorname{poly}(\log s)\)。对 NEXP history，\(s\) 可为
\(T(n)^{\Theta(1)}\)，所以该 canonical forward map 仍是 \(T\)-scale
表示。Theorem 3.7 的 \(AC^0[2]\) 结论只约束反向 decoder 的 oracle 电路，不改变
这个 forward 评价成本。

这不是任意 canonical proof map 的下界：若特定 history 的 gate-value table
\(A_H\) 有额外代数结构，(3) 仍可能简化。它只是说明不能把 Theorem 3.7 的
“locally decodable”直接解释成 history accessor。

## 与 RW/JK 的精确接口

这条结果把剩余任务压成一个单向补全：

1. 使用 canonical PCP 的 \(\Pi_V\) 与 local decoder，固定要验证的隐式 history；
2. 构造一个 history-specific、word-consistent 的 forward accessor
   \[
   \operatorname{Acc}_H(i,\ell)=\Pi_V(x,H)[i,\ell]
   \]
   大小 \(n^{O(1)}\)；
3. 再把每个 \(2q\)-bit block 的 accessor 规范化为固定 \(q\)-bit seed，并证明
   JK 父层仍使用同一 selector law。

若第 2 步只对单一 history 成立，不会自动推出 NEXP 的 uniform proof generator；
若它对所有 \((x,y)\) 成立，则会给出一种非常强的 uniform canonical proof
compression。当前文献只给第 1 步和反向 local decoding，未给第 2--3 步。

## 与已知 NEXP 下界的关系

Chen--Williams--Yang 进一步证明：对其 canonical PCP，若 NEXP 没有某电路类的
小 witness，则相应 PCP witness 也不能被同类小电路近似；反向则可构造
polylog\((N)\) 的 black-box constructive property。这提供了一个条件性桥梁：

\[
\text{小 PCP witness family}
\xRightarrow{\text{local decoder}}
\text{相应 NEXP witness 小电路}.
\]

但文献没有无条件证明该小电路不存在，因此不能把这个桥梁升级为
\(P\ne NP\)。一个只针对单一 fixed history 的 forward accessor 甚至弱于
“小 PCP witness family”；它只有在能统一覆盖一族输入/历史时，才会触发该下界框架。

## 结论

\[
\boxed{
\text{canonical + locally-decodable PCP}
\;\not\Rightarrow\;
\text{canonical forward history accessor}.
}
\]

本结果不是 PCP lower bound，也不声称解决 \(P\) vs \(NP\)。它把下一步从
“寻找 canonical PCP”进一步缩窄为“证明某个具体 implicit history 的
forward proof block 有地址级电路，并验证它能与 JK selector 闭合”。

## 来源

- Lijie Chen, Raghavendra Srinivas, R. Ryan Williams, Kai Yang,
  *Black-Box Constructive Proofs Are Unavoidable*, ITCS 2023：
  [paper page](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.ITCS.2023.35)；
  [full PDF](https://drops.dagstuhl.de/opus/volltexte/2023/17538/pdf/LIPIcs-ITCS-2023-35.pdf)。
  关键位置：Definitions 3.5--3.6、Theorem 3.7、Algorithm 1。
