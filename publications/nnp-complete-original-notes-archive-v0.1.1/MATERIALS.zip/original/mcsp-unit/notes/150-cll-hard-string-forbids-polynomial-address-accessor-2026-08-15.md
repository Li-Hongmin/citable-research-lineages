> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# CLL hard string 排除 polynomial-address deterministic accessor（2026-08-15）

## 结论

Chen--Li--Liang 的 main theorem 不只说明 AM protocol 能输出 canonical hard
strings；它还无条件排除了这些 strings 在 base input length 上的 deterministic
random-access evaluator。

设 \(w_n\in\{0,1\}^{2^n}\) 是 CLL 构造在无限多个长度 \(n\) 上输出的
\(\Pi_{\mathrm{hard}}\) 字符串，则

\[
  \operatorname{CC}(w_n)\ge \frac{2^n}{n}
\tag{1}
\]

在这些长度成立。不存在统一的 \(n^{O(1)}\)-size bit-accessor

\[
  A_n(i)=w_n[i],\qquad i\in\{0,1\}^{n},
\tag{2}
\]

即使允许一个 \(n^{O(1)}\)-bit 的 nonuniform seed/advice 也不行。

## 证明

若存在统一 deterministic \(A_n\) 满足式 (2)，把 \(i\) 作为 \(n\)-bit 输入，
即可得到大小 \(n^{O(1)}\) 的电路计算 \(w_n\) 的每个 truth-table 位。因此

\[
  \operatorname{CC}(w_n)\le n^{O(1)}
\]

对所有充分大的 \(n\) 成立，与 (1) 在无限多个 hard lengths 上矛盾。

若 accessor 写成 seed 形式

\[
  S(1^n)\in\{0,1\}^{q(n)},\qquad
  E(S(1^n),i)=w_n[i],
\]

其中 \(q(n)=n^{O(1)}\)，且 \(S,E\) 都是 polynomial-time/uniform，那么直接复合
\(E(S(1^n),i)\) 即得同样的 polynomial-size circuit。若 \(S(1^n)\) 是任意
nonuniform advice，固定每个 \(n\) 后把它硬接进 \(E\)，仍得到
\(n^{O(1)}\)-size circuit，依然违反 (1)。

## 为什么 AM commit-and-evaluate 不被此命题排除

CLL 的协议只保证：存在 Merlin 的 commitment/evaluation strategies，使 Arthur
在地址 \(i\) 上输出 \(w_n[i]\)；评价阶段的 Merlin strategy 仍携带 history。
它没有一个独立于 Merlin 的 deterministic \(E(\alpha,i)\)。因此：

\[
\text{interactive oracle access}
\;\not\Rightarrow\;
\text{deterministic polynomial-address accessor}.
\]

这与 [note 149](149-am-commitment-is-not-a-deterministic-jk-seed-2026-08-15.md)
的信息下界完全一致：短 commitment 不是独立的 whole-word seed。

## 对 RW/JK 的直接影响

如果尝试把 CLL 的 canonical hard string 当作 RW/JK 的固定 history，并要求
\(q=\operatorname{poly}(n)\) 的 leaf evaluator 输出其完整 \(2q\)-bit block，则
固定 block 坐标的输出已经给出式 (2) 类型的 accessor；这条路线在 hard lengths
上无条件失败。

因此 CLL history 只能以两种方式进入后续构造：

1. 保留 AM/interactive evaluation，把 Merlin strategy 作为协议内部状态，而不把
   它伪装成 \(G_q\) 的 deterministic seed；
2. 不直接 evaluatorize hard output，而是利用 JK/AVOID 的 non-range branch，
   让 hard string 只通过 promise/smart query 间接出现。

第二条仍是开放接口；它不能由 CLL 的 canonicality 或 local decoding 自动得到。

## 复杂度边界

CLL 的 hard strings 属于 exponential-time Arthur--Merlin 的构造，并且只在无限多个
长度上落入 \(\Pi_{\mathrm{hard}}\)。上述矛盾是对 deterministic accessor 的
无条件 lower bound，不是 \(P\ne NP\) 证明，也不把 AMEXP lower bound 改写成
NP lower bound。

## 来源

- Lijie Chen, Jiatu Li, Jingxun Liang, *Maximum Circuit Lower Bounds for
  Exponential-Time Arthur Merlin*, ECCC TR24-182 revision 2：
  [official report](https://eccc.weizmann.ac.il/report/2024/182/)。
  Theorem 1.3 给出 dense \(coAM\) property 的 canonical string；对
  \(\Pi_{\mathrm{hard}}\) 的推论给出 (1) 的无限长度下界。
- [note 149](149-am-commitment-is-not-a-deterministic-jk-seed-2026-08-15.md)：
  commitment 与 deterministic seed 的信息语义区分。
- [note 124](124-leaf-evaluator-is-hard-function-accessor-2026-08-15.md)：
  固定 block evaluator 向输出函数复杂度的传递。

核验日期：2026-08-15。
