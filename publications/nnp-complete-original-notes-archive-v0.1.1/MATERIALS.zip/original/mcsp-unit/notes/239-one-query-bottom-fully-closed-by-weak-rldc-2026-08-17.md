> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One-query bottom is fully closed by the binary weak-RLDC bound (2026-08-17)

## Contribution

The \(r=1\) edge case is stronger than the low-soundness statement in note 238.
After message-inline compilation, a one-proof-query target-relative interface is
already a **weak adaptive two-query binary RLDC**. The decoder may output
\(\bot\) whenever the selected branch rejects, so simultaneous rejection causes
no difficulty. The only possible wrong output is an acceptance by the wrong
branch after the inline message bit has been corrupted.

Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu prove that every weak adaptive
two-query binary RLDC with success rate \(1/2+\varepsilon\) has exponential
length. Hence the entire one-query bottom regime is excluded for every
constant wrong-branch error \(\beta<1/2\), without a no-bottom assumption and
without requiring the wrong branch to reject on honest proofs.

## Theorem

Let

\[
  \Pi:\{0,1\}^{k}\longrightarrow\{0,1\}^{P}
\]

be a binary proof map. For each \(i\in[k]\) and \(b\in\{0,1\}\), let
\(V_{i,b}\) be a randomized, possibly adaptive verifier making at most one query
to the proof. Assume \(0<\rho<1\) and:

* **Perfect correct-branch completeness**
  \[
    p_{i,m_i}(\Pi(m))=1;
  \tag{239.1}
  \]
* **Target-relative wrong-branch soundness**
  \[
    \operatorname{dist}(z,\Pi(m))\le\rho P
    \Longrightarrow
    p_{i,1-m_i}(z)\le\beta .
  \tag{239.2}
  \]

If \(\beta<1/2\), then the inline length \(N=k+P\) satisfies

\[
  N=2^{\Omega_{\rho,\beta}(k)}.
\tag{239.3}
\]

## Proof

As in note 238, (239.1)--(239.2) force the proof image to have relative distance
greater than \(\rho\): two proof words within distance \(\rho P\) would make the
correct branch for one target both accept with probability \(1\) and be the wrong
branch for the other target with probability at most \(\beta\). The binary
Singleton bound therefore gives

\[
  \frac{P}{k+P}\ge \frac1{3-2\rho}
\tag{239.4}
\]

for all sufficiently large \(k\). Let

\[
  C(m):=m\,\|\,\Pi(m),\qquad
  \delta_0:=\frac{\rho}{2(3-2\rho)}.
\tag{239.5}
\]

If \(y\) is \(\delta_0\)-close to \(C(m)\), its proof suffix is within
\(\rho P/2\) of \(\Pi(m)\).

The relaxed decoder for coordinate \(i\) reads the inline bit \(b=y_i\), runs
\(V_{i,b}\) on the proof suffix, outputs \(b\) if it accepts, and outputs
\(\bot\) otherwise. It makes at most two adaptive queries.

On \(C(m)\), \(b=m_i\) and (239.1) gives perfect completeness. On a
\(\delta_0\)-corrupted word, if \(b=m_i\), the output is \(m_i\) or \(\bot\).
If \(b\ne m_i\), a wrong output can occur only when the wrong branch accepts,
which has probability at most \(\beta\) by (239.2). Therefore the decoder
outputs \(m_i\) or \(\bot\) with probability at least

\[
  1-\beta=\frac12+\left(\frac12-\beta\right).
\tag{239.6}
\]

Thus \(C\) is a weak adaptive \((2,\delta_0,1/2+\varepsilon)\)-RLDC with
\(\varepsilon=1/2-\beta>0\). Theorem 1 of
Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu yields
\[
  N=2^{\Omega_{\delta_0,\varepsilon}(k)}
   =2^{\Omega_{\rho,\beta}(k)}.
\]
\(\square\)

## Consequence for the Closure program

This closes the full binary \(r=1\) branch of the shared-proof model:

* simultaneous rejection/bottom is allowed;
* the wrong branch may accept on the honest proof;
* the verifier may be adaptive;
* no two-branch mass lower bound is needed.

The remaining one-query escapes must therefore leave at least one of the
following assumptions: binary proof alphabet, common family-level proof map,
positive target-relative radius, perfect correct-branch completeness, or
wrong-branch error bounded below \(1/2\).

For \(r\ge2\), the analogous single-branch compiler only gives an
\((r+1)\)-query RLDC. Constant-error near-linear RLDCs exist in some such
query regimes, so the \(r\ge2\) bottom branch is not closed by this argument.
The low-soundness extension \(\beta<2^{-(r+1)}\) is the separate theorem in
note 238.

## Sources

* A. R. Block et al., *Exponential Lower Bounds for 2-query Relaxed Locally
  Decodable Codes*, Definition 1 and Theorem 1:
  <https://arxiv.org/abs/2602.20278>.
* The all-\(r\) single-branch low-soundness extension:
  [note 238](238-single-branch-inline-low-soundness-closure-2026-08-17.md).
