> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Generic low-degree extension evaluator 的计数坍缩边界（2026-08-15）

## 结论

低度扩展的正向 evaluator 必须区分两种对象：

1. 对任意 succinct Boolean table \(D:\{0,1\}^{m}\to\{0,1\}\) 给出 multilinear
   extension \(\widetilde D(\alpha)\)；
2. 只对一个固定 RW/C-W-Y history \(D_H\) 给出若干 proof coordinates。

第一种在可有效表示的特征零（或足够大的特征）域上已经太强：它直接给出
\(\#\mathrm{SAT}\)。第二种不受这个计数论证排除，仍是本项目必须单独构造的
history-specific accessor。

## 命题（特征零版本）

设 \(\mathcal F_m\) 是一族可有效表示的特征零域，域运算和长度为
\(\operatorname{poly}(m)\) 的有理数输出的精确算术均在 \(\operatorname{poly}(m)\) 时间内完成。
对每个 \(m\)，给定一个 \(m\)-输入 Boolean circuit \(D\)，令
\(\widetilde D:\mathcal F_m^m\to\mathcal F_m\) 为满足

\[
  \widetilde D(x)=D(x)\qquad(x\in\{0,1\}^{m})
\]

的唯一逐变量次数至多一的多项式。若存在统一算法

\[
  E_m(D,\alpha)=\widetilde D(\alpha)
\]

对所有 succinct \(D\) 和所有 \(\alpha\in\mathcal F_m^m\) 在
\(\operatorname{poly}(m+|D|)\) 时间内精确求值，则
\(\#\mathrm{SAT}\in\mathrm{FP}\)，从而 \(\mathrm P=\mathrm{NP}\)。

### 证明

对任意 \(D\)，在 \(\mathcal F_m\) 中取

\[
  \alpha=(1/2,\ldots,1/2).
\]

multilinear extension 的 Lagrange 公式给出

\[
  \widetilde D(\alpha)
  =
  \sum_{x\in\{0,1\}^{m}}D(x)
    (1/2)^{|x|}(1-1/2)^{m-|x|}
  =
  2^{-m}\#\{x:D(x)=1\}.
\]

运行 \(E_m(D,\alpha)\)，再乘 \(2^m\)，便精确得到 satisfying-assignment 数。
对 Boolean circuit \(D\) 这就是 \(\#\mathrm{SAT}\)；故
\(\#\mathrm{SAT}\in\mathrm{FP}\)，并有 \(\mathrm{NP}\subseteq\mathrm P\)。证毕。

## 大特征有限域的安全表述

同一个计算在特征 \(p>2^m\) 的域上也成立：若
\(\alpha=(1/2,\ldots,1/2)\) 可表示，则

\[
  2^m\widetilde D(\alpha)\equiv \#\mathrm{SAT}(D)\pmod p.
\]

由于计数在 \([0,2^m]\) 内，单个 \(p>2^m\) 的余数已经确定整数答案。这里必须把
\(p\)、域表示和算术的**统一可构造性**列为假设；不能把“存在一个大素数”悄悄当成
\(\operatorname{poly}(m)\)-时间的 uniform setup。若这些数据只作为 nonuniform advice，
结论相应只能写成非均匀版本，不能直接写成 \(\mathrm P=\mathrm{NP}\)。

## 为什么这不是 C-W-Y 的直接反例

C-W-Y 的 canonical PCP construction 使用有限域中的 gate-value table 与低度扩展。
对于本项目核验的特征 \(2\) 参数化模板，此时 \(2^m=0\)，\(1/2\) 不存在；上述
\(\#\mathrm{SAT}\) 读取公式失效。特征 2 上即使 evaluator 给出有限域值，也不能由
上述公式直接恢复整数计数；任何 parity 或更强的坍缩都需要另外证明，不能未经论证
就升级为 \(\#\mathrm{SAT}\) 或 \(P=NP\)。对固定特征 2 的 parity 坍缩，见
[note 148](148-characteristic-two-extension-evaluator-parity-collapse-2026-08-15.md)。

更关键的是，C-W-Y 的 \(\widetilde A\) 不是一个任意输入 Boolean table 的 evaluator：
它服务于一个给定 witness 的 gate-value table \(A\)。即使某个固定 history 的
\(\widetilde A_H(\alpha)\) 有地址级电路，也不等于存在统一的
\(E(D,\alpha)\) 覆盖所有 succinct \(D\)。因此本命题只排除“通用、特征零/大特征、
任意-table”的 shortcut，不排除 history-specific 特征 2 accessor。

## 对 RW/JK 路线的实际裁决

note 130 的全局系数张量下界与本命题形成两层筛选：

\[
\begin{array}{c|c}
\text{generic multilinear evaluator} &
\text{large characteristic }\Rightarrow \#\mathrm{SAT}\text{ collapse}\\
\text{global tree labeler for all tables} &
q\ge D^m\log|F|\\
\text{one fixed characteristic-2 history} &
\text{仍 unknown}
\end{array}
\]

所以可行的剩余路线不是把 C-W-Y 的 local decoder 误读成通用正向 evaluator，而是：

1. 固定一个具体 history \(H\)，利用其特有的代数关系构造
   \(\operatorname{Acc}_H(i,\alpha)\)；
2. 证明该 accessor 的输出在 JK 的同一 seed law 下可递归闭合；
3. 若想改用大特征域，必须同时承担上面的计数坍缩风险，并明确说明 uniform
   field setup。

本 note 不给出一般 evaluator lower bound，也不声称得到 \(P\ne NP\)；它只把
“generic extension shortcut”从开放候选降为一个可精确审查的条件分支。

## 来源

- Lijie Chen, Raghavendra Srinivas, R. Ryan Williams, Kai Yang,
  *Black-Box Constructive Proofs Are Unavoidable*, ITCS 2023，
  [paper page](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.ITCS.2023.35)，
  [full PDF](https://drops.dagstuhl.de/opus/volltexte/2023/17538/pdf/LIPIcs-ITCS-2023-35.pdf)。
  该文的 canonical PCP/低度扩展只作为构造背景；本 note 的计数推导是自足的。
- [note 130](130-recursive-multivariate-polynomial-labeler-scale-2026-08-15.md)：
  全局多变量标签器的系数张量与 seed 预算。
- [note 146](146-canonical-locally-decodable-pcp-is-one-way-2026-08-15.md)：
  canonical PCP 的正向/反向方向区别。

核验日期：2026-08-15。
