> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Published singleton 的 recursive-support ceiling（2026-08-18）

## 本轮判定

C402 给出的 singleton 检查是：若一个固定 canonical proof 的 non-output
recursive block 或相邻 pair 支持超过 \(2^k\)，则不可能把所有这些对象保持在同一个
\(G_k:\{0,1\}^k\to\{0,1\}^{2k}\) 的 range 内。本 note 给出它在 published RW
singleton 上的精确适用窗口，并关闭一个容易重复的错误路线：当 \(k\) 达到 proof
length 的对数尺度时，单个 proof 的 occurrence 数本身已经小于 \(2^k\)，因此
C402 不可能由纯 support counting 触发。

## 递归 occurrence 上界

令固定 proof 为 \(\Pi\in\{0,1\}^{L}\)，令 \(G_k\) 的 block width 为 \(2k\)。把
\(\Pi\) 右侧补零到长度 \(k2^h\)，其中

\[
 h=\left\lceil\log_2\frac{L}{k}\right\rceil
\]

（若 \(L\le k\)，取 \(h=0\)）。在 JK 的第 \(j\) 层，最多有 \(2^{j-1}\) 个
\(2k\)-bit block。因此所有层的 block occurrence 总数满足

\[
 N_{\rm block}
 \le \sum_{j=1}^{h}2^{j-1}
 =2^h-1
 <\frac{2L}{k}.
\tag{404.1}
\]

不论哪些 block 被标记为 non-output，固定 proof 上的 distinct-value support 都不
超过 occurrence 数：

\[
 |\mathcal Z_{\rm no}|\le2^h-1.
\tag{404.2}
\]

同理，所有相邻 block pair occurrence 的数目至多

\[
 N_{\rm pair}
 \le \sum_{j=1}^{h}(2^{j-1}-1)
 =2^h-h-1<2^h,
\tag{404.3}
\]

故

\[
 |\mathcal P_{\rm no}^{(2)}|<2^h.
\tag{404.4}
\]

这两个上界只用固定 proof 的递归树形状，不使用 ECC、线性、proof alphabet 或
source family 假设。

## C402 的必要窗口

若

\[
 2^k\ge2^h,
\tag{404.5}
\]

则由 (404.2)--(404.4) 自动得到

\[
 |\mathcal Z_{\rm no}|\le2^k,
 \qquad
 |\mathcal P_{\rm no}^{(2)}|\le2^k.
\tag{404.6}
\]

所以 C402 的 singleton support 反证要成立，至少必须有

\[
 2^h>2^k,
 \quad\text{即}\quad
 k<\log_2\frac{L}{k}+1.
\tag{404.7}
\]

一个方便的充分条件使 C402 必然失效是

\[
 2^k\ge\frac{2L}{k}
 \quad\Longleftrightarrow\quad
 k+\log_2 k\ge\log_2(2L).
\tag{404.8}
\]

这不是说 C402 在 (404.7) 之外一定成立；它只说明在该窗口之外，固定 proof 的
support cardinality 不可能单独制造矛盾。

## 代入 published RW 参数

Ren--Williams Theorem 4.1 传给 JK 的是 canonical PCP proof \(\Pi_{x_0}\)，而不是
只有 \(B_i\) 的 padded output。若

\[
 L_i=|\Pi_{x_0}|\le T_i^{c_0}
\]

对固定常数 \(c_0\) 成立，则 C402 的 singleton support 检查在

\[
 k_i\ge c_0\log_2 T_i+O(\log\log T_i)
\tag{404.9}
\]

之后必然失效。稳定递推中 \(T_i=n_i^{C}\)、父表长度 \(b_i=2n_i\)，所以

\[
 k_i=\Omega(\log b_i)
\]

已经足以把 support ceiling 推到 proof length 的数量级（常数取决于 PCP proof
length exponent）。当 \(k_i\) 取 \((\log b_i)^2\) 或更大的 address-scale
polylog 时，C402 不能作为 singleton barrier。

另一方面，若把 \(k_i\) 压到 C402 可能非平凡的 \(O(\log b_i)\) 窗口，C381 的
easy-branch hard-exit 仍可排除 easy（其充分窗口为

\[
 k_i^4\log(T_i+2)^{O(1)}<\operatorname{CC}(B_i)
\]

的情形），但 \(2k_i=o(b_i)\)。于是 C377/C383 的 block-width gate 立即留下
whole-parent binding 缺口：一个 outsider 只能暴露 \(O(\log b_i)\) 个父表 bits，
其余信息必须由多个 outsiders、descriptor 或新的 global relation 提供。

因此 published singleton 的参数图被严格分成三段：

1. \(k_i\) 太大：support counting 按 (404.6) 自动失效；
2. \(k_i=O(\log b_i)\)：C402 可能非平凡，但 single outsider 不足以绑定整个父表；
3. \(k_i\) 更小：easy branch 仍可被 C381 排除，但 parent-binding 信息缺口更大。

这证明了：**C402 不能单独闭合 published singleton 的 Gate-I。** 它要成为主定理
必须进入 family/product-rich 量词，或与一个新的 whole-parent relation theorem
结合；不能继续以固定 proof 的 support 穷举替代该量词。

## 与 C402 的关系及证据边界

* C402 的 product-capacity inequality 仍然正确；本 note 只给出 singleton 上的
  occurrence ceiling。
* C381 只排除在明确参数窗口内的 JK easy branch，不把 success outsider 变成
  whole-parent evaluator。
* C377/C382/C383 说明 \(2k\)-bit success block 的 signal lift、output attachment
  和 parent binding 是三个不同接口。
* \(L_i\le T_i^{c_0}\) 是 RW PCP proof-length 上界的参数化假设；若采用不同 PCP
  编码，应以实际 \(L_i\) 重新代入 (404.8)，不能把 \(c_0\) 当作原文的统一最优常数。

本 note 是一个 source-scale route-closure theorem，不证明 \(P\ne NP\)，也不否定
family-level C402 barrier；它的作用是把下一步从 singleton support 穷举切换到
family-level recursive closure 或新的 forcing object。
