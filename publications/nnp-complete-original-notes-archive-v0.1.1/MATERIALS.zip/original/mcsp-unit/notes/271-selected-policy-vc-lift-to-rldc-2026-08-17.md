> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Selected-policy VC lift to an RLDC

## Main result

The entropy--distance theorem of note 270 can be strengthened whenever the
message family is the full Boolean cube.  A small family of selected-policy
vectors contains a large fiber; Sauer--Shelah then supplies many coordinates
that are jointly shattered inside that fiber.  On those coordinates the
selected policy is common, so the usual message-inline argument becomes a
genuine RLDC.  This removes the all-policy-soundness assumption from the
selected-policy route, at the price of a VC-dimension loss.

## Theorem

Let
\[
  \Pi:\{0,1\}^k\longrightarrow\Sigma^N
\]
be a common proof map.  For every target \(m\) and coordinate \(i\), choose
one policy \(\tau_{m,i}\), and let
\[
  S(m)=(\tau_{m,1},\ldots,\tau_{m,k}),\qquad
  B=|\operatorname{supp}S|.
\]
For a fixed policy and claim bit, assume the verifier is nonadaptive and
queries at most \(q\) proof symbols.  Suppose constants
\(\alpha>\beta\) and \(\rho>0\) satisfy

\[
 \Pr[V_{i,m_i}^{\tau_{m,i}}(\Pi(m))=1]\ge\alpha,
\tag{271.1}
\]

and, whenever \(\operatorname{dist}_H(z,\Pi(m))\le\rho N\),

\[
 \Pr[V_{i,1-m_i}^{\tau_{m,i}}(z)=1]\le\beta.
\tag{271.2}
\]

Let \(d\) be the maximum VC dimension of a fiber
\[
  F_s=\{m:S(m)=s\}.
\]
Then there is a \(d\)-bit message code
\[
  C_s:\{0,1\}^{d}\to\Sigma^N
\]
with a positive-radius relaxed local decoder using
\[
  Q=O\!\left(q(\alpha-\beta)^{-2}\right)
\tag{271.3}
\]
queries and constant completeness/soundness.  In particular, whenever an
arbitrary-alphabet RLDC lower bound applies to \(Q,\rho,\Sigma\),

\[
 N\ge
 \left(
 \frac{\sigma^2d}
 {38Q^4\log_2^2|\Sigma|\,\log_2^2 d}
 \right)^{1+1/\lceil Q/\sigma\rceil}
\tag{271.4}
\]

in the corresponding radius window, where \(\sigma>0\) is the resulting
soundness gap.

Moreover, Sauer--Shelah gives

\[
 B\sum_{j=0}^{d}\binom{k}{j}\ge 2^k.
\tag{271.5}
\]

Consequently, if \(B=2^{o(k)}\), then \(d=\Omega(k)\).  More generally, for
every fixed \(\gamma<1\), if \(B\le2^{\gamma k}\), then
\(d\ge\delta_\gamma k-o(k)\) for some \(\delta_\gamma>0\) depending only on
\(\gamma\).  Thus fixed-query, constant-radius selected-policy protocols with
subexponentially many policy vectors cannot have near-linear proof length in
any RLDC lower-bound window.

Conversely, if a finite-policy route has \(d=o(k)\), then
\[
  \log_2 B\ge k-o(k),
\]
again by Sauer--Shelah.  So evading the linear-fiber conclusion requires a
policy channel whose support carries essentially the full target entropy, not
merely a few extra strategy bits.

## Proof

Choose a fiber \(F_s\) of maximum VC dimension \(d\), and let
\(I=\{i_1,\ldots,i_d\}\) be shattered by that fiber.  For each
\(x\in\{0,1\}^d\), fix a representative \(m_x\in F_s\) with
\[
  (m_x)_{i_j}=x_j\qquad(j\in[d]).
\]
Define \(C_s(x)=\Pi(m_x)\).  The policy used at \(i_j\) is the same policy
\(\tau_{s,i_j}\) for every representative, because all representatives lie in
the same fiber.

To decode \(x_j\), run the two claim branches
\(V_{i_j,0}^{\tau_{s,i_j}}\) and
\(V_{i_j,1}^{\tau_{s,i_j}}\), using independent constant repetitions, and
threshold their empirical acceptance rates between \(\beta\) and \(\alpha\).
The correct branch has mean at least \(\alpha\) on \(C_s(x)\), while the wrong
branch has mean at most \(\beta\) on every \(\rho N\)-near word by (271.2).
Chernoff amplification gives a constant probability of outputting \(x_j\) on
the uncorrupted codeword and never outputs the wrong bit except with constant
error; if neither threshold is reached it outputs \(\bot\).  Each repetition
uses at most \(q\) positions, proving (271.3).

The proof words in one fiber are automatically separated: if
\(m,m'\in F_s\) differ at coordinate \(i\) and
\(\operatorname{dist}_H(\Pi(m),\Pi(m'))\le\rho N\), the common policy at \(i\)
would satisfy (271.1) for \(m'\) and (271.2) for \(m\) on the same proof,
contradicting \(\alpha>\beta\).  Thus \(C_s\) is a legitimate positive-radius
RLDC code map.  Applying the arbitrary-alphabet RLDC lower bound gives
(271.4).

Finally, Sauer--Shelah bounds every fiber of VC dimension at most \(d\) by
\(\sum_{j\le d}\binom{k}{j}\).  Summing over the at most \(B\) fibers yields
(271.5).  If \(B\le2^{\gamma k}\) with \(\gamma<1\), the binomial entropy
estimate forces \(d\) to be a positive linear fraction of \(k\). \(\square\)

## Quantitative finite-policy length corollary

The preceding argument gives an explicit proof-length exponent, not only a
qualitative near-linear obstruction, when the cited lower bound's completeness convention
is met.  For the GGS bound specifically, assume supportwise perfect completeness
\(\alpha=1\) and use the inline compiler; the GGS code length is then \(d+N\) over the
tagged alphabet \(\widehat\Sigma=\Sigma\cup\{0,1\}\).  For \(0\le\gamma<1\), let
\(\theta_\gamma\in(0,1/2]\) be defined by
\[
  H_2(\theta_\gamma)=1-\gamma,
\tag{271.6}
\]
with \(\theta_0=1/2\). If \(B\le2^{\gamma k}\), then the entropy form of
Sauer--Shelah implies
\[
  d\ge (\theta_\gamma-o(1))k.
\tag{271.7}
\]
Consequently, writing \(a=\lceil Q/\sigma\rceil\), the GGS bound in the
applicable radius window yields, for all sufficiently large \(k\),
\[
  d+N\ge
  \left(
    \frac{c_\gamma\,\sigma^2 k}
    {38 Q^4\log_2^2|\widehat\Sigma|\,\log_2^2 k}
  \right)^{1+1/a}
\tag{271.8}
\]
for any fixed \(c_\gamma<\theta_\gamma\). In particular, when
\(Q,\widehat\Sigma,\sigma\) are fixed, no bound of the form
\(N\le k\log^C k\) can hold for any fixed \(C\); equivalently, the proof suffix obeys the
same superlinear lower bound up to subtracting \(d=O(k)\). The case
\(B=2^{o(k)}\) is obtained by taking every fixed \(c_0<1/2\) in place of
\(c_\gamma\). Thus the finite selected-policy branch has a concrete
proof-length phase transition: a sublinear-VC escape requires
\(\log_2B\ge k-o(k)\), while any fixed entropy deficit
\((1-\gamma)k\) incurs the exponent
\(1+1/\lceil Q/\sigma\rceil\).

The statement remains conditional on the explicit hypotheses of the VC lift
and on the GGS radius window. It is not a claim that ordinary dPCPs satisfy
those hypotheses.

There is one additional completeness repair that does not require \(\alpha=1\): if all
verifier randomness is a finite public tape of \(r\) bits and the proof alphabet is finite,
one can enumerate every adaptive proof-answer tree exactly.  The resulting inline decoder
is perfect-complete and nonadaptive with proof locality
\(2^r\sum_{j<q}|\Sigma|^j\) (or \(q2^r\) for nonadaptive branches), so a perfect-complete
RLDC lower bound can be applied whenever this expanded locality remains in its radius
window.  This finite-randomness subcase and its proof are recorded in
[note 467](467-finite-randomness-completeness-repair-selected-policy-rldc-2026-08-19.md);
the unrestricted randomized case remains only an imperfect-complete semantic lift.

## Shannon-entropy version

Finite support is not needed if the selected-policy channel has low Shannon
entropy. Let \(M\) be uniform on \(\{0,1\}^k\), let \(S=S(M)\), and write
\[
  h_S:=H_2(S).
\tag{271.9}
\]
The image of \(S\) is finite because the message cube is finite, even if the
ambient policy space is arbitrary. If \(p_*=\max_s\Pr[S=s]\), then
\[
  h_S=\mathbb E[\log_2(1/\Pr[S])]\ge\log_2(1/p_*),
\]
so some fiber \(F_{s_*}\) has
\[
  |F_{s_*}|\ge2^{k-h_S}.
\tag{271.10}
\]
Applying Sauer--Shelah to this single fiber gives
\[
  \sum_{j=0}^{d_*}\binom{k}{j}\ge2^{k-h_S},
\tag{271.11}
\]
where \(d_*\) is its VC dimension. Thus the entire VC/RLDC lift above
continues to hold with the support exponent \(\log_2 B\) replaced by
the Shannon entropy \(h_S\). In particular, if \(h_S\le\gamma k\), then
\(d_*\ge(\theta_\gamma-o(1))k\) and (271.8) applies; if
\(h_S=o(k)\), then \(d_*\ge(1/2-o(1))k\). Conversely,
\(d_*=o(k)\) forces
\[
  h_S\ge k-o(k).
\tag{271.12}
\]
This removes the finite-support assumption from the low-information regime:
an infinite or continuously indexed policy universe can evade the theorem
only by carrying essentially linear target entropy under the uniform message
distribution, or by leaving the common proof/address and fixed-branch
hypotheses.

## Randomized policy selection and mutual information

The same argument handles a randomized selected-policy channel, provided the
observable policy view is finite and every policy in the selected support is
robust. Let \(\mathcal S\) be a finite set of policy vectors. For each
\(m\in\{0,1\}^k\), draw \(S\) from a distribution \(\mu_m\) on \(\mathcal S\).
Assume that for every pair \((m,s)\) with \(\mu_m(s)>0\), the policy vector
\(s\) satisfies (271.1)--(271.2) for all coordinates, with the same
\(\alpha>\beta\) and \(\rho\). Let \(M\) be uniform and set
\[
  I_S:=I(M;S),\qquad H(M\mid S)=k-I_S.
\tag{271.16}
\]
There is a policy value \(s_*\) with
\[
  H(M\mid S=s_*)\ge k-I_S.
\]
Its conditional support
\[
  F_{s_*}:=\{m:\mu_m(s_*)>0\}
\]
satisfies
\[
  |F_{s_*}|\ge 2^{H(M\mid S=s_*)}\ge2^{k-I_S}.
\tag{271.17}
\]
Indeed, conditional entropy is at most the logarithm of conditional support
size. Applying Sauer--Shelah to this single support fiber and then repeating
the VC/RLDC construction proves:

* if \(I_S\le\gamma k\), a fiber has
  \(d\ge(\theta_\gamma-o(1))k\), so the quantitative GGS bound (271.8)
  applies under the same \(\alpha=1\) inline-completeness condition;
* if \(I_S=o(k)\), then \(d\ge(1/2-o(1))k\);
* if every such fiber has \(o(k)\) VC dimension, necessarily
  \(I_S\ge k-o(k)\).

Thus target-independent randomization is not an additional escape: it is
charged by mutual information as soon as the supportwise robustness
quantifier holds. This is the exact finite-view distributional interface
needed by the lift. An average-over-policies guarantee alone does not imply
the supportwise hypothesis; allowing bad policies in the conditional support
reopens the selected-policy quantifier gap of note 269.

## Adaptive branch extension

If each fixed policy/claim branch is an adaptive binary decision tree of depth
\(r\), query all nodes in the union of the two trees before thresholding.  The
union has at most
\[
  Q_r=2(2^r-1)
\]
proof positions (an inline claim bit can be added as one further position).
Replacing \(q\) by \(Q_r\) in (271.3)--(271.4) gives the same VC lift.  Thus
adaptivity changes the quantitative query parameter, but not the
policy-fiber/Sauer--Shelah mechanism.

## Adaptive barrier without decision-tree expansion

The VC lift also avoids the exponential \(Q_r\) loss when the adaptive
variable-query barrier applies. Let \(\Delta=\alpha-\beta>0\). On the shattered
fiber, repeat each fixed policy/claim branch independently
\(t=O(\Delta^{-2})\) times and accept it when its empirical acceptance rate
exceeds \((\alpha+\beta)/2\). Chernoff bounds give a new adaptive branch with
correct acceptance at least \(2/3\), wrong-claim acceptance at most \(1/3\)
throughout the same \(\rho N\)-ball, and depth
\[
  \ell=O(r\Delta^{-2}).
\tag{271.13}
\]
The policy is common on the entire fiber, so the amplified branches and the
message-inline decoder satisfy the hypotheses of the variable-query adaptive
RLDC barrier (Theorem 3.4D'' of the main paper).

Consequently, if \(N\le d(\log d)^C\) on infinitely many lengths for a fixed
finite alphabet and fixed positive radius, then
\[
  \ell\log(\ell+2)=\Omega\!\left((\log d)^{1/3}\right).
\tag{271.14}
\]
For fixed \(\Delta\), this is
\[
  r\log(r+2)=\Omega\!\left((\log d)^{1/3}\right),
\tag{271.15}
\]
up to constant-factor changes in the logarithm. In particular, when the
entropy/support argument gives \(d=\Omega(k)\) and the original proof length
is \(N\le k(\log k)^C\), a selected-policy construction with
\(r=o((\log k)^{1/3}/\log\log k)\) is impossible. This adaptive conclusion
uses the variable-query theorem directly and does not replace \(r\) by the
exponential decision-tree union \(2(2^r-1)\).

## Consequence and boundary

This theorem is stronger than note 270 in the direction relevant to coding
barriers: it turns a large policy fiber into an actual RLDC rather than only a
distance-separated subfamily.  It is weaker than C199 because the resulting
RLDC decodes only a shattered coordinate set and the policy vector may still
depend on the fiber.

The selected-policy escape therefore has a precise dichotomy:

1. \(B=2^{o(k)}\): a linear-size shattered submessage exists, and the RLDC
   lower bound applies;
2. \(B=2^{k-o(k)}\) is necessary if the selected-policy fiber is to have
   sublinear VC dimension; the policy vector then carries essentially all
   target information, quantified by note 270;
3. the policy family is not finite/publicly describable, or the proof/address
   space is target-dependent.

The theorem does not claim that every ordinary dPCP satisfies its hypotheses.
It identifies the missing general impossibility statement: a near-linear
simultaneous coordinate-robust compiler must either expose a linear-information
strategy channel or violate the common finite-policy/address model.

The RLDC bound used in (271.4) is the arbitrary-alphabet lower bound of
Goldberg--Gur--Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally
Decodable Codes via Robust Daisies*, Theorem 1.
