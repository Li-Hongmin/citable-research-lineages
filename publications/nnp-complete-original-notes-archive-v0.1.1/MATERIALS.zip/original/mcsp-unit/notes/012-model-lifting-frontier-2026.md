> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Formula--XOR / AC⁰∘XOR 的模型 lifting 裁决（2026-08-13）

## 决策问题

目标：把近期的 AC⁰∘XOR 或 strong (KW_{oplus}) 下界迁移为

\[
\operatorname{GapMCSP}[a,b]\notin \operatorname{Formula}\circ\operatorname{XOR}[N^{1.01}],
\]

或至少得到一个可独立证明的 model-lifting lemma。

检索范围：2024--2026，关键词

\[
\text{Formula-XOR},\quad \mathrm{AC}^{0}\circ\mathrm{XOR},\quad
KW_{\mathrm{XOR}},\quad \text{strong composition},\quad \mathrm{MCSP}.
\]

截止日：2026-08-13。新纳入 ResearchLibrary 的记录和 PDF：

- Riazanov--Sofronova--Sokolov, *Lower Bounds Beyond DNF of Parities*, ITCS 2026；
- Chukhin--Kulikov--Mihajlin, *Toward Better Depth Lower Bounds: Strong Composition of XOR and a Random Function*, STACS 2025；
- Carmosino--Dang--Jackman, *Simple Circuit Extensions for XOR in PTIME*, arXiv:2511.16903（作为 MCSP 负边界）。

## 1. AC⁰∘XOR 线：可迁移部分与量词缺口

Riazanov--Sofronova--Sokolov 研究

\[
\mathcal C_{\mathrm{Ria}}=
\bigvee_{i=1}^{M}\bigl(C_i\circ A_i\bigr),
\]

其中 (C_i) 为常深度 De Morgan 电路，(A_i) 为非奇异仿射变换；主模型为

\[
\mathrm{Or}\circ(\Pi_0\circ\mathcal B).
\]

它包含 DNF(circ)XOR，并给中间层、内积、仿射 disperser 指数下界；其 informal Theorem 4 的量级为：若函数是 (n^{1/3-o(1)})-affine disperser，则需要
(2^{n^{\Omega(1)}}) 大小的该模型。

可迁移的机制是“(k)-parity limit”。对 (A\subseteq\mathbb F_2^N)，点 (y) 是 (k)-parity limit，当且仅当

\[
\forall L\leq\mathbb F_2^N,
\operatorname{codim}L=k,
\quad y\in L\Longrightarrow A\cap L\neq\varnothing .
\tag{PL}
\]

若 (k)-CNF(circ)XOR 接受 (A)，则它也接受每个 (k)-parity limit。对有限的线性系统族 \(\mathscr L)，Claim 12 给出有限族版本：只需对每个 (L\in\mathscr L) 保持 (A\cap L\neq\varnothing)。这提示一种可能的 MCSP 证书：令 (A=E_a)、(B=NO_b)，寻找 (B) 中大量满足 (PL) 的点，再把它们转为递归协议叶。

但论文本身明确指出，现有 top-down 证明只有

\[
\forall L\ \exists y_L\in B:\ y_L\text{ 是 }k\text{-limit of }A_i,
\tag{Q1}
\]

而 $\vee\circ\wedge\circ\vee\circ\mathrm{XOR}$ 需要

\[
\exists y\in B\ \forall L\in\mathscr L:\ y\text{ 是 }k\text{-limit of }A_i.
\tag{Q2}
\]

论文还指出，仿射 extractor 可由 $\vee\circ\wedge\circ\vee\circ\mathrm{XOR}$ 计算，因此对任意仿射映射的统一 $y$ 不可能无条件成立。故将 Q1 直接提升为 Q2 是错误的；它正是 Formula$\circ$XOR 的首个模型 lifting 缺口。

### 可检验的最小 lifting 命题

对 $A,B\subseteq\mathbb F_2^N$，以及公式节点 $v$ 的实际仿射系统族 $\mathscr L_v$，定义

\[
\mathrm{UAL}_k(A,B;\mathscr L_v):
\quad
\exists y\in B\quad
\forall L\in\mathscr L_v,
\ y\in L\Rightarrow A\cap L\neq\varnothing .
\]

若能证明：对每个大小 $s\le N^{1.01}$ 的 Formula$\circ$XOR 递归节点，都存在至少

\[
M\ge N^{1.01}/\operatorname{polylog}N
\]

个可分离的 UAL 见证，且见证不被左右子树重复融资，则得到目标的超线性叶数下界。现有 ITCS 2026 只提供 Q1，不提供 UAL；这不是记号差异，而是量词 \(\exists\forall\) 与 \(\forall\exists\) 的实质差异。

### MCSP 语义下的更早坍缩

对当前 GapMCSP 参数，UAL 还有一个独立的平凡化障碍。令真值表长度为 $N=2^n$。所有重量至多

\[
t:=\left\lfloor\frac{a}{c n}\right\rfloor
\]

的字符串都在 $E_a$：把每个 1 位置写成一个 $n$-字面项，再取至多 $t$ 项的 DNF，电路规模至多 $ctn\le a$。

**稀疏球命题。** 若 $L\subseteq\mathbb F_2^N$ 是任意余维 $k$ 的仿射子空间，且 $k\le t$，则

\[
L\cap E_a\neq\varnothing .
\tag{SB}
\]

证明：写 $L=\{x:Hx=b\}$，其中 $H$ 为秩 $k$ 的 $k\times N$ 矩阵。取 $H$ 的 $k$ 个线性无关列作为基；用它们表示 $b$，得到一个支撑至多 $k$ 的解 $x$。由上面的 DNF 构造，$x\in E_a$。

于是当 $k\le t$ 时，每个 $y\in\mathbb F_2^N$ 都是 $E_a$ 的 $k$-parity limit，而且是对所有 affine systems 同时成立：

\[
\forall y\quad
\forall L\ni y,
\operatorname{codim}L=k\le t,
\quad L\cap E_a\neq\varnothing .
\]

在 $a=2^{n^{1/3}}$ 的 magnification 参数下，$t\asymp a/n\gg n=\log N$。因此所有 $k\le t$（特别是 $k=\operatorname{polylog}N$）的 UAL 对 $(E_a,NO_b)$ 都退化为“所有点都是见证”，不能产生下界。若要使 parity-limit 语义真正区分 $NO_b$，必须推进到

\[
k>t\asymp a/\log N,
\]

这远超当前 AC⁰$\circ$XOR 的 $k$-limit 技术，并会引入约 $2^{\Theta(k\log N)}$ 个仿射系统。故 ITCS→GapMCSP 的障碍不只是 Q1/Q2 量词顺序；在目标语义上，低 $k$ 的统一见证本身是平凡的。

## 2. strong $KW_\oplus$ 线：强关系不蕴含 Formula--XOR 下界

Chukhin--Kulikov--Mihajlin 定义

\[
KW_f\circledast KW_g:
\]

输入矩阵 $X\in(f\diamond g)^{-1}(1)$、$Y\in(f\diamond g)^{-1}(0)$，输出 $(i,j)$，满足

\[
X_{i,j}\neq Y_{i,j}
\quad\land\quad
g(X_i)\neq g(Y_i).
\tag{SKW}
\]

其 Theorem 3：若 $f$ 为 $0.49$-balanced，则

\[
L(KW_{\oplus_m}\circledast KW_f)
\ge n^{2-o(1)}L_{3/4}(f),
\qquad n=m\log m,
\]

随机 $f$ 给出 $n^{3-o(1)}$ 叶下界。证明使用两阶段子可加势：先用 Khrapchenko 图势追踪 XOR 外层，再用第二个势转为许多 $KW_{OR}\circledast KW_f$ 实例。

这里的输出关系严格强于 Formula$\circ$XOR 叶关系。Formula$\circ$XOR 的一个叶只需指定一个仿射形式 $\ell_i$，要求

\[
\ell_i(X)\neq\ell_i(Y),
\]

不要求存在固定的原始坐标 $j$，也不要求同一叶在所有输入对上使用同一 $j$。因此

\[
\text{strong }KW_{\oplus}\text{ protocol}
\Longrightarrow
\text{Formula--XOR protocol}
\]

的方向只能是“强协议可投影为弱协议”；弱协议叶数可能因合并不同 (j) 而骤降，故强关系的下界不能反推弱关系的下界。

### 精确反例（排除直接 lifting）

令

\[
F(X)=\bigoplus_{i=1}^{m}\bigoplus_{j=1}^{r}X_{i,j}.
\]

作为 Formula$\circ$XOR，$F$ 只需一个叶（整张输入的单一仿射 parity）。但在

\[
KW_{\oplus_m}\circledast KW_{\oplus_r}
\]

中，对每个格点 $(i,j)$ 取 $X=e_{i,j}$、$Y=0$。则 $F(X)=1,F(Y)=0$，且唯一满足 (SKW) 的输出是 $(i,j)$。不同格点要求不同叶标签，所以任意强协议至少有 $mr$ 个叶：

\[
L_{\mathrm{strong}}\ge mr,
\qquad
L_{\mathrm{Formula}\circ\mathrm{XOR}}(F)=1.
\]

因此，任何声称“strong $KW_{\oplus}$ 的 $N^{3-o(1)}$ 下界自动给 Formula$\circ$XOR 的 $N^{1.01}$ 下界”的命题均为假；必须先证明一个保持叶数的 inner-coordinate quotienting lemma，而该 lemma 被此反例排除（除非改变目标关系或限制叶族）。

### 2.1 linear-diversity 接口也在 affine parity 处退化

Podolskii--Shekhovtsov 的 linear diversity 是**一个固定 gadget** 的参数：固定 Alice 输入后，所得 Bob 侧非恒定线性函数（按取反识别）的最大个数。其 lifting 定理要求 diversity $k\ge2$，并给出

\[
 R^{\rm cc}_{\to\oplus}(f\circ g^n)
 =\Theta(\log k\,R^{\rm dt}(f)).
\tag{LD}
\]

对 Formula$\circ$XOR 的任一 affine 叶

\[
 \ell(x,y)=a\cdot x\oplus b\cdot y\oplus c,
\]

固定 $x$ 后，Bob 侧始终是同一个线性部分 $b\cdot y$，至多因常数项而取反。因此

\[
 \operatorname{ldiv}(\ell)\le1,
\]

且当 $b\ne0$ 时恰为 $1$；若 $b=0$ 则固定后恒定，diversity 为 $0$。特别地，单比特 affine gadget $g(x,y)=x\oplus y$ 的两个固定输入只产生 $y$ 与 $\neg y$，按取反识别后仍只有一个函数。故 (LD) 的 $\log k$ 因子在 $k=1$ 时为零，不能为定向 affine-collision/QA 递归势提供任何通信下界。

这不是把多片叶简单并列就能修复的：linear diversity 计算的是同一 gadget 在不同 Alice 输入下的 Bob 线性族，而 Formula 的每片叶都把自己的系数 $b$ 固定在叶标签中。除非另行证明一个“共同 gadget 编码”

\[
 \{\ell_t\}_{t\le s}\ \leadsto\ f\circ g^n
 \quad\text{且}\quad \operatorname{ldiv}(g)\ge2
\]

并控制编码后的协议大小，否则不能把 (LD) 应用于 Formula 叶。这样的共同编码本身相当于重新引入一个 Index/IP 型 gadget，并非由 affine parity 叶自动给出。

### 2.2 与定向 QA 的形式接口：只能得到条件性蕴含

若额外假设一个编码引理：每个 QA 递归节点的 affine 叶族可无损表示为同一个 gadget $g$ 的半结构通信协议，且每次 QA 分割对应至多 $O(1)$ 次协议查询，那么 (LD) 才能给出条件性转移

\[
 R^{\rm dt}(f)\ge D
 \Longrightarrow
 R^{\rm cc}_{\to\oplus}(f\circ g^n)\ge\Omega(\log k\,D),
\]

再由通信协议到公式分割的已知模拟，得到 QA 叶数下界。当前 Formula--XOR 叶没有共同 $g$，而且定向碰撞势记录的是三点/四点 affine collision 的方向，并不产生“固定 Alice 输入后有 $k$ 个可区分 Bob 线性形式”。所以该编码引理正是未证明的新增假设，不能当作现有 lifting 的推论。

### 2.3 strong-KW 与定向碰撞势的最小不相容例

在强关系中，一个输出 $(i,j)$ 必须给出原始坐标差异；定向 QA 叶只要求某个 affine 形式 $\ell(X)\ne\ell(Y)$。取全局 parity

\[
 F(X)=\bigoplus_{i,j}X_{i,j}.
\]

对每个 $(i,j)$，输入对 $(e_{ij},0)$ 的强关系唯一合法输出是 $(i,j)$，故 strong-KW 协议需要至少 $mr$ 个叶；但 QA/Formula 只用一个叶 $\ell=F$。因此任何把定向 QA 势直接转成 strong-KW 图势的叶数保持式

\[
L_{\rm strong}\le \operatorname{polylog}(mr)\,L_{\rm QA}
\]

都被该例否定。要获得正向蕴含，必须限制 affine 叶支持（例如每叶支持 $O(1)$ 个坐标）或在目标关系中保留“任意 affine witness”而非固定 $(i,j)$；这两种限制均不覆盖当前 Formula--XOR/MCSP 目标。

### 2.4 Gavinsky 2024/2025：唯一可迁移的是函数级的弱下界

Gavinsky 的 approximate-majority 关系 $\widetilde{\mathrm{Maj}}$ 允许中间 Hamming 重量任意输出，但要求重量至多 $n/3$ 时输出 $0$、至少 $2n/3$ 时输出 $1$。其定理是对所有一致完成功能 $f$ 取最小后仍有

\[
 \bar R^{\oplus}(\widetilde{\mathrm{Maj}})=\min_{f\,\mathrm{consistent}}R^{\oplus}(f)=\Omega(\sqrt n).
\tag{G}
\]

若某个一致完成 $f$ 有 $s$ 个 affine-parity 叶的 Formula--XOR 表示，顺序查询这些叶即可得到一个至多 $s$ 次的确定性 parity-query 算法；于是

\[
 s\ \ge\ D^{\oplus}(f)\ \ge\ R^{\oplus}(f)\ \ge\Omega(\sqrt n).
\tag{G-weak}
\]

这是严格可迁移的**函数级**结论，但仅给 $\Omega(\sqrt n)$ 的叶/叶门下界，且在 $N=2^n$ 的真值表参数下只有 $\Omega(\sqrt{\log N})$，远低于 $N^{1.01}$。

若先固定一个 completion $f$，再定义 $T_{\oplus,f}$ 为 $f^{-1}(1)\times f^{-1}(0)$ 上输出任意分离两点的 affine parity，则标准 KW 对应给出

\[
 \mathrm{CP}(T_{\oplus,f})=L_{\mathrm{Formula}\circ\mathrm{XOR}}(f)
 \ge D^{\oplus}(f)\ge\Omega(\sqrt n).
\]

因此 Gavinsky 确实给出每个固定 completion 的弱 affine-KW 分割下界；缺失的是把这个逐 completion 的结论合并为 MCSP 关系 $T_{\oplus}|_{E_a\times NO_b}$ 的单一 QA 证书。

但它不能直接变成 **MCSP 关系**的 Formula--XOR KW 仿射叶分割下界，最小模型失配有三层：

1. (G) 先对一致完成功能 $f$ 取最小，再分析同一个 $f$ 的 parity-query 协议；KW/QA 关系的每个输入对可选择不同 affine 见证，并没有一个全局 $f$。把 pair-dependent witness 统一成 $f$ 正是未解决的 unambiguity 量词，不能无损完成。
2. Gavinsky 的确定性 parity-query 深度 $k$ 叶是余维至多 $k$ 的**单输入 affine 子空间**（最多 $2^k$ 块）；Formula--XOR KW 叶是两侧矩形上满足 $\ell(X)\ne\ell(Y)$ 的一条 affine 形式。前者的 transcript 约束不等于后者的 pairwise witness 约束。
3. 即使把 parity-query 树展开成公式，方向只有 $k$ queries $\Rightarrow O(2^k)$ 个 affine 条件；反向由 Formula 直接逐叶查询只有 $D^{\oplus}(f)\le s$。因此 (G) 不能给出 partition leaves 的超线性下界，更不能绕过 strong-KW 的固定坐标失配。

所以 Gavinsky 结果可作为“所有 MCSP completion 的 affine-query 函数复杂度至少 $\sqrt n$”的低参数 sanity check，但不存在通往当前 Promise-MCSP QA/Formula--XOR $N^{1.01}$ 目标的直接 lifting。

## 3. 精确模型关系

记 $\mathsf{FX}[s]$ 为上层任意二叉 De Morgan 公式、叶为任意 affine parity 的模型；$\mathsf{AC}^0_d\circ\mathsf{XOR}[s]$ 为深度 $d$ 的有界深度电路。

\[
\mathsf{AC}^0_d\circ\mathsf{XOR}[s]
\subseteq
\mathsf{FX}[s^{O(d)}]
\tag{M1}
\]

成立：展开 fan-out、将无界 fan-in 二叉化并复制子电路即可。反向多项式大小包含关系目前不能假定；它会触及一般 Formula 与常深度 AC⁰$\circ$XOR 的深度下界问题。

ITCS 模型

\[
\mathsf{Or}\circ(\Pi_0\circ\mathcal B)
\subseteq
\mathsf{AC}^0\circ\mathsf{XOR}
\]

是一个受限底层模型：每个分支只允许一个共同的非奇异 affine coordinate system $A_i$，再接 CNF/常深度电路；Formula$\circ$XOR 允许每个叶独立选择 affine form，并在递归树的不同节点重复、交叉使用它们。故不能把 ITCS 下界按大小指数直接重标记为 Formula$\circ$XOR 下界。

strong KW 是关系层面的严格 refinement，而不是电路类包含：

\[
R_{\mathrm{strong}}\subsetneq R_{\mathrm{leaf}},
\]

反例见上一节。

## 4. MCSP 结果的负边界

Carmosino--Dang--Jackman (arXiv:2511.16903) 证明 XOR-simple-extension 问题 fixed-parameter tractable，并刻画最优 XOR 电路为 XOR$_2$ 二叉树；这排除了通过 $f=\mathrm{XOR}$ 的 simple-extension 归约证明 total MCSP ETH-hard 的一条路线。它既没有 Formula$\circ$XOR 下界，也没有 GapMCSP 的 $N^{1.01}$ 结果，故只作为“不能从 XOR 电路最优结构直接得到 MCSP hardness”的边界证据。

## 5. 当前裁决与下一步

截至 2026-08-13，没有发现已发表或公开预印本把上述结果直接 lifting 到

\[
\operatorname{GapMCSP}[2^{(\log N)^{1/3}},2^{(\log N)^{2/3}}]
\notin\mathsf{Formula}\circ\mathsf{XOR}[N^{1.01}].
\]

可保留且具体的唯一接口是：

\[
\boxed{\text{证明 UAL}_{k}(E_a,NO_b;\mathscr L_v)\text{ 的递归、不重复融资版本}}
\]

或者构造反例，证明所有 UAL 型势均不能超过 $O(N)$。

两条直接捷径已关闭：

1. ITCS 的 $\forall L\exists y_L$ 不能交换成 Formula 所需的 $\exists y\forall L$；
2. strong $KW_{\oplus}$ 的固定 inner-coordinate 输出不能压到 Formula$\circ$XOR 的可变 parity 叶输出，global parity 给出 $1$ 对 $mr$ 的反例。

3. ITCS 2025 linear-diversity lifting 需要同一 gadget 的至少两个不同 Bob 线性函数；任意 affine parity 叶固定后只有一个 Bob 线性部分，diversity $\le1$，故该路线在当前模型上形式关闭。

4. Gavinsky 的 unambiguous parity-query 下界只给一致完成功能的 $D^{\oplus}$/Formula 弱下界 (G-weak)；其“先选全局 $f$”与 KW 的“每对输入可选 affine witness”量词不同，且 query transcript 的 affine 子空间不是 KW 仿射叶矩形。

### 来源

- [Riazanov--Sofronova--Sokolov, ITCS 2026](https://doi.org/10.4230/LIPIcs.ITCS.2026.112)，尤其 Definition 9、Claim 12、Discussion/Problems 20；
- [Chukhin--Kulikov--Mihajlin, STACS 2025](https://doi.org/10.4230/LIPIcs.STACS.2025.26)，尤其 Definition of strong composition、Theorem 3；
- [Carmosino--Dang--Jackman, arXiv:2511.16903](https://arxiv.org/abs/2511.16903)。
