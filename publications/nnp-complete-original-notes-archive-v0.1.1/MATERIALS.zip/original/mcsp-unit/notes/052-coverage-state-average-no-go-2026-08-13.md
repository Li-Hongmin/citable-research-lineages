> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Coverage/submodular union 状态的平均 no-go（2026-08-13）

令每个 cell \(c\) 覆盖一个非负权特征集合 \(S_c\subseteq\Omega\)，定义

\[
F(R)=\sum_{\omega\in\Omega}w_\omega\,
\mathbf 1\{\exists c\in R:\omega\in S_c\},
\qquad w_\omega\ge0.
\tag{1}
\]

这是最一般的加权 coverage function，且满足并集次可加性：
\(F(V\cup W)\le F(V)+F(W)\)。故

\[
K(R)=F(R)-\frac{F(C)}{|C|}|R|
\]

是 QA/root-zero 状态。

若叶分布对每个 cell 的包含概率均为 \(q\)，则对任意 \(\omega\)（只要其被至少一个 cell 覆盖），

\[
\Pr[\omega\text{ 被 }R\text{ 覆盖}]
=\Pr[R\cap\{c:\omega\in S_c\}\ne\varnothing]
\ge q.
\]

于是

\[
\mathbb E F(R)\ge q\sum_{\omega:\,S_\omega\ne\varnothing}w_\omega
=qF(C),
\qquad \mathbb E K(R)\ge0.
\]

因此 coverage functions（包括常见的 feature-union、随机命中、集合覆盖下界的所有正权 union 统计）也不能绕过均匀 affine thinning。真正的 cover-number 状态 \(F_{\mathcal A}\) 与 coverage function 不同：它是“最小覆盖数”（非 XOS），正因如此才可能出现 note 051 的 \(EF<qF(C)\)。

