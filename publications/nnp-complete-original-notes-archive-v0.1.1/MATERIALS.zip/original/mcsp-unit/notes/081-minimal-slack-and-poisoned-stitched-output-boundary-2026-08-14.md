> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Minimal slack 与 poisoned stitched output 的边界（2026-08-14）

## 结论

[note 080](080-rw-pcp-block-provenance-is-not-a-black-box-invariant-2026-08-14.md)
把 Local-JK 问题收缩到 Ren--Williams systematic proof 中可规范定位的 exact output blocks。本 note
裁决这些 blocks 是否仅由 stitched AVOID 的布局就必然有 compact canonical preimage accessor。

1. 原始 minimal-slack construction 每层只有 \(L_k+1\) 个自由 bits；固定一个 \(2q_k\)-bit
   accessor-hard range block 后，剩余候选数不足以完成原 AVOID pigeonhole。故原 exact
   \(M_A\) 的 lex-first block 是否可 compact inversion 仍是 unknown。
2. zero prefix、sparse suffix、suffix coherence 和 block alignment 均不蕴含 compact inversion。
   同一布局中存在 canonical decoder range elements，使每个 preimage accessor 都需要
   \(q_k^{1-o(1)}\) size。
3. 若允许每层增加同阶的 \(2q_k\)-bit payload，则在 \(P=NP\) 假设下可构造一个单一
   suffix-coherent 的 poisoned stitched language \(H^\dagger\)。它仍有
   \(n^{O(\log\log n)}\) uniform time 和 a.e. super-polynomial circuit lower bound，但每个长度的
   systematic output 中都有一个实际 aligned range block，其所有 preimage accessor 大于
   \(\sqrt{q_k}\)。因为 full-output time \(T(n)\) 满足 \(\log T=\Theta(n)\)，这击败每个 fixed
   \(\operatorname{poly}(n,\log T)\) bound。

因此 Local-JK 若只假设“exact output、sparse/coherent stitching、canonical decoder”，则已经太宽；
它必须使用原 minimal-slack bit budget、原 lex-first rule 或更强的 exact-\(M_A\) 特性。本 note
没有否定该最窄命题，也不声称证明了 \(P\ne NP\)。

## 原 minimal slack 为什么不能强制坏块

沿用 [note 076](076-kannan-quantifiers-coherent-avoid-and-time-scale-boundary-2026-08-14.md) 的
canonical decoder

\[
\Phi_{n,k}:\{0,1\}^{L_k}\to\{0,1\}^{N},
\qquad N=2^n,
\]

其中 \(L(n,k)\) 是统一可计算的整数函数，且 \((d,x)\mapsto\Phi_{n,k}(d)[x]\) 有
\(\operatorname{poly}(L_k,n,k)\)-time uniform evaluator；其 range 覆盖 size \(n^k\) 的 easy
truth tables。给定旧 tail 后，原构造只改变

\[
\Delta_k=L_k+1
\]

bits，因而有 \(2^{L_k+1}>|\operatorname{Range}(\Phi_{n,k})|\) 个 candidates。若先固定一个
\(2q_k\)-bit prefix \(z_k\)，自由 candidates 降为

\[
2^{L_k+1-2q_k}<2^{L_k},
\]

原 pigeonhole 不再适用。即使让 prefix 遍历 note 079 的 sparse accessor-hard family，其 entropy 也仅为

\[
R(q_k)=\Theta\!\left(\frac{q_k\log\log q_k}{\log^2q_k}\right)<2q_k,
\]

仍不足以补回固定 \(2q_k\) bits 的损失。这只是现有 cardinality proof 的失败；它不证明原
lex-first \(w_k\) 不会偶然产生 accessor-hard block。

## Poisoned construction

固定充分大的常数 \(C\)，取二次幂

\[
q_k=2^{\lceil(k+C)\log_2 n\rceil},
\qquad 2q_k\mid N
\]

（充分大 \(n\)）。令 \(G_{q_k}:\{0,1\}^{q_k}\to\{0,1\}^{2q_k}\) 为 note 079 的
canonical truth-table decoder。若 \(P=NP\)，则 \(PH=P\)，所以 note 079 的固定
\(\Sigma_2^P\) predicate \(\operatorname{ExtBad}\) 有一个固定 polynomial-time decider。逐位
self-reduction 得到一个 sparse table

\[
z_k\in\operatorname{Range}(G_{q_k})
\]

且

\[
\min_{u:G_{q_k}(u)=z_k}
\operatorname{CC}(i\mapsto u_i)>\sqrt{q_k}.
\tag{1}
\]

设旧 tail 长度为 \(r_{k-1}^\dagger\)。固定 \(z_k\) 后，让

\[
v_k\in\{0,1\}^{L_k+1}
\]

保留原 AVOID 的全部自由度。定义唯一的 \(0\le a_k<2q_k\) 使

\[
a_k\equiv-(L_k+1+r_{k-1}^\dagger)\pmod{2q_k},
\tag{2}
\]

并置

\[
\operatorname{tail}_k^\dagger
=z_kv_k0^{a_k}\operatorname{tail}_{k-1}^\dagger,
\qquad
r_k^\dagger=2q_k+(L_k+1)+a_k+r_{k-1}^\dagger.
\tag{3}
\]

在固定 \(z_k,0^{a_k},\operatorname{tail}_{k-1}^\dagger\) 后，\(v_k\) 仍有
\(2^{L_k+1}\) 个取值，而 decoder range 至多有 \(2^{L_k}\) 个元素。取 lexicographically first
\(v_k\) 使

\[
H_{n,k}^\dagger
=0^{N-r_k^\dagger}\operatorname{tail}_k^\dagger
\notin\operatorname{Range}(\Phi_{n,k}).
\tag{4}
\]

其 prefix 可扩展性由固定的 predicate

\[
\exists v\succeq p\ \forall d\in\{0,1\}^{L_k}\ \exists x\in\{0,1\}^n:
\Phi_{n,k}(d)[x]\ne
Y_{z_k,v,a_k,\operatorname{tail}_{k-1}^\dagger}[x]
\]

表达，因而属于统一的 \(\Sigma_3^P\)。式 (2) 只依赖已知长度而不依赖 \(v_k\) 的值，所以定义没有
循环。

式 (2) 给 \(r_k^\dagger\equiv0\pmod{2q_k}\)。因为 \(2q_k\mid N\)，式 (4) 中 tail 的绝对起点
\(N-r_k^\dagger\) 是 \(2q_k\)-block boundary，故 \(z_k\) 是输出中的一个实际 aligned JK block。
旧 tail 的绝对起点仍为

\[
(N-r_k^\dagger)+2q_k+(L_k+1)+a_k=N-r_{k-1}^\dagger,
\]

所以所有旧 blocks 的绝对位置不变。这一固定长度布局的 filler 同余不能误写成只让新增 payload
长度被 \(2q_k\) 整除。

由 \(L_k\le n^{k+c}\operatorname{poly}(k)\) 且 \(q_k=n^{k+C+O(1)}\)，有

\[
r_k^\dagger=n^{k+O(1)}<2^n
\tag{5}
\]

对 \(k\le\lfloor\log_2\log_2n\rfloor\) 和充分大 \(n\) 成立。选择

\[
k(n)=\lfloor\log_2\log_2n\rfloor,
\qquad H_n^\dagger=H_{n,k(n)}^\dagger,
\]

则式 (4) 给

\[
\operatorname{CC}(H_n^\dagger)>n^{k(n)}
\tag{6}
\]

对充分大 \(n\) 成立。

## Uniform time 与 full-output embedding

两个 selector 都由固定 machine 完成：先用显式含 \(1^{q_k}\) 的 \(\operatorname{ExtBad}\) prefix
self-reduction 生成 \(z_k\)，再用上面的固定 \(\Sigma_3^P\) predicate 对 \(v_k\) 做 prefix
self-reduction。假设 \(P=NP\)，先固定一个 polynomial-time SAT decider，再通过 \(PH=P\) induction
固定这两个 PH decider；其 polynomial exponents 不依赖输入中的 \(k\)。predicates 的显式长度、
selector 步数和 decoder evaluation 总计为

\[
n^{O(k)},
\]

其中大 \(O\) 常数不依赖 \(k\)。因此

\[
H^\dagger\in DTIME\!\left(n^{O(\log\log n)}\right).
\tag{7}
\]

令 deterministic multi-output machine 忽略其 \(n\)-bit 输入内容，先构造 \(H_n^\dagger\)，再输出
完整的 \(N\)-bit truth table，并以零 padding 到一个可 time-construct 的 nice bound

\[
T(n)=2^{\,n+\lceil B(k(n)+C')\log_2n\rceil}
\tag{8}
\]

（在上述 collapse algorithms 固定后，取固定 \(B,C'\) 足够大）。先计算完整短 tail，再流式写出
\(T(n)\) bits，selector、存储和输出均为 \(O(T(n))\)。该 machine 没有 NP queries，所以 RW systematic satisfying
assignment 没有 query-answer header，output 从 proof prefix 的第一个坐标开始。于是式 (3) 中的
\(z_{k(n)}\) 确实是 systematic output 内的实际 JK block，而不是依赖 compiler 或 auxiliary PCP
serialization 的 block。

由式 (8)，

\[
\log T(n)=\Theta(n),
\]

而

\[
\sqrt{q_{k(n)}}
=n^{\frac12\log\log n+O(1)}.
\tag{9}
\]

故对每个固定 \(d\)，充分大 \(n\) 时式 (1) 大于 \((n+\log T)^d\)。准确量词为

\[
P=NP\Longrightarrow
\exists H^\dagger\,\exists F^\dagger\,\exists\{G_{q_k}\}\,
\forall d\,\exists n_0\,\forall n\ge n_0:
\begin{cases}
\operatorname{CC}(H_n^\dagger)>n^{k(n)},\\
z_{k(n)}\text{ 是 }F^\dagger\text{ systematic output 中的 aligned block},\\
z_{k(n)}\in\operatorname{Range}(G_{q_{k(n)}}),\\
\min_{u:G_{q_{k(n)}}(u)=z_{k(n)}}\operatorname{CC}(u\text{-accessor})
>(n+\log T)^d.
\end{cases}
\tag{10}
\]

这表明任何覆盖所有同尺度 suffix-coherent stitched variants 的 ordinary Local-JK theorem，都不能仅
以现有布局性质为依据。它没有关闭原 bit-for-bit minimal-slack \(M_A\)。

## Smart-prMA 与 2026 AM 结果的尺度边界

smart-prMA 的 promise substitution 必须保留实际 query length。无条件地，用总语言

\[
S=\{B:\exists w\ \forall r\ B(w,r)=1\}\in\Sigma_2^P
\]

替换 promise oracle，只在 smart execution 上保持答案并得到 \(P^S/1\)。在 \(P=NP\) 下才有
\(S\in P\)，从而把一个固定、runtime/query length 至多 \(L^c\) 的 smart machine 编译成
size \(\operatorname{poly}(L)\) ordinary circuits。若 query 显式含 \(q\)-bit preimage 或 block，
则 \(L\ge q\)；这个 substitution 只给 \(q^{O(1)}\)，不能消去 \(q\)。

Ghentiyala--Li--Stephens-Davidowitz（STOC 2026）证明的

\[
BPP^{Avoid}\subseteq AM\cap coAM,
\qquad
prBPP^{Avoid}\subseteq prAM\cap prcoAM
\]

是对高效归约到显式-input Avoid 的 decision problems 的结论；它不把 Avoid search 本身放入这些类。
其 SearchAMA 结果同样以完整 circuit \(C:\{0,1\}^N\to\{0,1\}^{N+1}\) 为输入。应用到
\(G_q\) 时，电路描述、候选和通信仍有 \(\Omega(q)\) 长度，复杂度为 \(q^{O(1)}\)。把短 wiring
program 代替完整 \(G_q\) 定义的是新的 SuccinctAvoid 问题，不在这些定理的范围内。因此该工作没有
给出 \(\operatorname{poly}(n,\log T)\) local accessor，也不改变式 (10) 的边界。

## 证据边界

检索与核验日期：2026-08-14。

- Hanlin Ren and Ryan Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin-Arthur Queries*, ECCC TR26-118, revision 1, 2026.
- Surendra Ghentiyala, Zeyong Li, and Noah Stephens-Davidowitz, *Range Avoidance, Arthur--Merlin,
  and TFNP*, STOC 2026, DOI `10.1145/3798129.3800898`, ECCC TR25-210.
- Zeyong Li, *Symmetric Exponential Time Requires Near-Maximum Circuit Size*, STOC 2024,
  arXiv:2310.17762.
- Shuichi Hirahara, Rahul Ilango, and R. Ryan Williams, *Beating Brute Force for Compression
  Problems*, STOC 2024, DOI `10.1145/3618260.3649778`.

RW 的 systematic output prefix、canonical JK decomposition，以及上述显式-input AM/TFNP 结论是
文献直接支持的事实。minimal-slack entropy calculation、poisoned construction、alignment 和量词链是
本项目推论。
