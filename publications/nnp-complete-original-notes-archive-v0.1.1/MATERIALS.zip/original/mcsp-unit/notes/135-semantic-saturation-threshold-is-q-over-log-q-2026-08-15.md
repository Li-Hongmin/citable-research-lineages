> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 语义 saturation threshold 位于 \(q/\log q\) 尺度（2026-08-15）

## 定义

令

\[
m\ge3,\qquad q=2^{m-1},\qquad
\mathcal C_{m,s}=\{TT(C):C\text{ 是 }m\text{-variable、size}\le s\text{ 的有限完备基电路}\}.
\]

定义语义容量阈值

\[
\sigma_m=\min\{s:|\mathcal C_{m,s}|>2^q\}.
\tag{1}
\]

任何 \(q\)-bit map \(G_q:\{0,1\}^q\to\{0,1\}^{2q}\) 若覆盖
\(\mathcal C_{m,s}\)，都必须有 \(s<\sigma_m\)。

## 夹逼定理

对固定有限 fan-in-two basis，有

\[
\boxed{
\left(\frac12-o(1)\right)\frac{q}{\log_2q}
\ \le\ \sigma_m\ \le\
\left(1+o(1)\right)\frac{q}{\log_2q}.
}
\tag{2}
\]

### 下界：电路语义数量不能超过 \(2^q\)

令 \(s\ge m\)。一个至多 \(s\) 门的有向 gate-list 可由门数、每个门的 basis opcode、两个
source indices 以及 output index 指定，因此其数量至多为

\[
(s+1)(m+s+O(1))\,|B|^s(m+s+O(1))^{2s}.
\tag{3}
\]

所以

\[
\log_2|\mathcal C_{m,s}|
\le 2s\log_2(m+s+O(1))+s\log_2|B|+O(\log(m+s)).
\tag{4}
\]

若

\[
s\le\left(\frac12-\delta\right)\frac{q}{\log_2q}
\tag{5}
\]

其中 \(\delta>0\) 固定，则

\[
\log_2(m+s+O(1))=(1-o(1))\log_2q,
\]

代入 (4) 得

\[
\log_2|\mathcal C_{m,s}|
\le(1-2\delta+o(1))q<q.
\tag{6}
\]

故 \(|\mathcal C_{m,s}|<2^q\)，从而 \(\sigma_m\) 不会低于式 (2) 的左端。这里使用的是
syntactic overcount，因此不依赖不同 gate-list 是否语义相同。若 \(s<m\)，同一计数直接给出
\(\log_2|\mathcal C_{m,s}|=O(m^2)=o(q)\)，不影响该渐近下界。

### 上界：half-junta saturation

固定一个被忽略的变量。所有只依赖其余 \(m-1\) 个变量的函数构成大小恰为

\[
2^{2^{m-1}}=2^q
\]

的 family。由 Lupanov 上界，每个这类函数的 circuit size 至多

\[
L(m-1)\le(1+o(1))\frac{2^{m-1}}{m-1}
 =(1+o(1))\frac q{\log_2q}.
\tag{7}
\]

再加入一个依赖被忽略变量的 projection，得到至少 \(2^q+1\) 个 size-\(\le L(m-1)\) 的
不同 truth tables。因此 \(\sigma_m\le L(m-1)\)，即式 (2) 右端。该部分是
[note 088](088-half-junta-saturation-sharpens-decoder-capacity-2026-08-14.md) 的有限参数
饱和论证。

## 对 decoder frontier 的含义

式 (2) 说明纯 range-capacity 方法只能把语义 saturation threshold 定位到一个常数因子
窗口。它不能排除

\[
s=\frac q{\log^{1+\varepsilon}q}
\quad\text{或}\quad
s=c\frac q{\log q}\ (c<1/2),
\]

因为在这些尺度上，电路语义集合本身可能少于 \(2^q\)，容量没有迫使 range 溢出。反过来，
式 (2) 也不是 decoder-size lower bound：即使 \(|\mathcal C_{m,s}|\le2^q\)，仍可能没有
小电路实现一个覆盖 map。

因此当前问题分成两个不可混同的阈值：

\[
\begin{array}{c|c}
\text{语义容量阈值 }\sigma_m&\Theta(q/\log q)\text{（常数尚未由此夹逼确定）}\\
\text{覆盖 map 的 circuit size}&q\operatorname{polylog}q\text{ 是否存在仍 unknown}.
\end{array}
\]

任何试图在 \(s=q/\log^{1+\varepsilon}q\) 窗口中推出一般 decoder lower bound 的论证，必须使用
语义计数之外的结构（例如 inverse normalization、materialization、局部性或 JK tree
closure）；单纯再加强 pigeonhole 不会改变式 (2) 的信息尺度。

本文不声称 \(P\ne NP\)，也不把语义数量阈值误写成一般 circuit lower bound。
