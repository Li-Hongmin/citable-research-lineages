> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Restricted additive energy and non-affine cross-combinations (2026-08-24)

## Proposition 35

Let \(\varnothing\ne A\subseteq\mathbb F_2^N\) be the YES set \(\mathcal L_{n,S}\), and let
\(\varnothing\ne R\subseteq\mathbb F_2^N\) be any finite family of candidate residual shifts. Define

\[
 E_A(R):=\sum_{r\in R}|A\cap(A\oplus r)|,
 \qquad
 \theta_A(R):=\frac{E_A(R)}{|A|\,|R|}.
\]

For independent uniform \(r\in R\) and \(a\in A\),

\[
 \Pr[r\oplus a\in A]=\theta_A(R),
 \qquad
 \Pr[r\oplus a\notin A]=1-\theta_A(R).
\]

The additive energy obeys the unconditional injection bound

\[
 E_A(R)\le |A|^2,
 \qquad
 \boxed{\Pr[r\oplus a\notin A]\ge
 \max\!\left\{0,1-\frac{|A|}{|R|}\right\}.}
 \tag{527.1}
\]

If \(C_\oplus\) is a constant such that
\(\operatorname{CC}(f\oplus g)\le\operatorname{CC}(f)+\operatorname{CC}(g)+C_\oplus\), then

\[
 R\subseteq \mathcal L_{n,\,2S+C_\oplus}^{\,c}
 \quad\Longrightarrow\quad
 \theta_A(R)=0.
 \tag{527.2}
\]

## Proof

Let
\[
 \Gamma_A(R)=\{(r,a)\in R\times A:r\oplus a\in A\}.
\]
The map
\[
 (r,a)\longmapsto(r\oplus a,a)
\]
is injective from \(\Gamma_A(R)\) into \(A\times A\), with inverse
\((b,a)\mapsto(b\oplus a,a)\). Hence
\(|\Gamma_A(R)|=E_A(R)\le|A|^2\), proving (527.1). If \(r\in R\) and
\(r\oplus a\in A\), then
\[
 \operatorname{CC}(r)
 \le \operatorname{CC}(r\oplus a)+\operatorname{CC}(a)+C_\oplus
 \le 2S+C_\oplus,
\]
contradicting (527.2). \(\square\)

## MCSP consequence

Let \(q=\lfloor(S+4)/(2n+3)\rfloor\) and let
\(\mathbb B_q=\{h:|h|\le q\}\subseteq A\) be the low-weight YES family used in
Proposition 6 of the active paper. Put
\[
 R_q:=(A+\mathbb B_q)\setminus A.
\]
The Harper growth argument (paper equations (3l.32)--(3l.34)) gives, in the fixed-exponent
regime \(S=\lfloor2^{\mu_H n}\rfloor\),
\[
 \log_2\frac{|A+\mathbb B_q|}{|A|}
 \ge\left(\frac{1-\mu_H}{2}-o(1)\right)S.
 \tag{527.3}
\]
Since \(A\subseteq A+\mathbb B_q\),
\[
 |R_q|\ge\left(2^{((1-\mu_H)/2-o(1))S}-1\right)|A|.
\]
Applying (527.1) yields
\[
 \Pr_{r\in R_q,\,a\in A}[r\oplus a\notin A]
 \ge 1-2^{-((1-\mu_H)/2-o(1))S+1}.
 \tag{527.4}
\]
Thus the full MCSP YES set has a canonically defined, exponentially large family of non-affine
cross-combinations that are NO with overwhelming pairwise probability. This is a semantic
cross-NO statement; it does not by itself imply a residual-width lower bound, because a
residual family of size at most \(|A|\) can have \(\theta_A(R)=1\).

## Exact missing parameter and sharpness

The unresolved quantity for a prospective \(S\)-scale residual theorem is the restricted energy
\[
 E_A(R)=|A|\,|R|\,\theta_A(R).
\]
For \(|R|\le|A|\), (527.1) is vacuous. Non-affinity alone cannot repair this: if \(A=K\) is
a linear subspace and \(R=K\), then \(|R|=|A|\) and every cross-combination remains in \(A\).
Conversely, the threshold \(2S+C_\oplus\) in (527.2) is exact for the additive-composition
argument: it uses only two \(S\)-size circuits and cannot be replaced by an \(S\)-threshold
without an additional circuit lower bound.

Consequently, the missing full-MCSP interface can be stated precisely as a target for a residual
family \(R\) with \(|R|\le|A|\):
\[
 E_A(R)\le 2^{-\Omega(S)}|A|\,|R|,
 \tag{527.5}
\]
or an equally strong direct NO cross-combination theorem. No such bound is established here.
Proposition 35 rules out the claim that entropy, XOR closure, or mere non-affinity alone supplies it.

## Dependencies

- [Proposition 6 and equations (3l.32)--(3l.34)](../papers/02-truth-table-quotients-do-not-close-one-tape-mcsp-magnification/paper.md)
- [Proposition 34](526-affine-residual-route-boundary-2026-08-24.md)
- [Proposition 31](523-hidden-continuation-complexity-boundary-2026-08-24.md)
