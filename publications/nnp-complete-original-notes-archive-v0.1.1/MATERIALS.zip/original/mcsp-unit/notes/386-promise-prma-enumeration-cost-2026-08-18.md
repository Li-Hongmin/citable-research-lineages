> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# promise-prMA 的枚举模拟成本与 RW 地址尺度（2026-08-18）

> **source-specific 限定：** 本 note 讨论的是一般 bounded-gap、非完美完备
> promise-prMA。published RW Reconf 的完美完备 query 已由
> [C387](387-rw-perfect-completeness-prma-collapse-2026-08-18.md) 通过
> \(\Sigma_2^P\) collapse 确定化；(386.2) 不是其必要成本。

## 命题

固定一个 prMA query format。令 \(q\) 的描述长度为 \(L\)，Merlin witness 长度和
verifier 的确定性运行时间均为 \(L^{O(1)}\)，Arthur 的随机带长度为 \(R=R(q)\)。
promise 的两侧满足

\[
\begin{aligned}
q\in\Pi_{\mathrm{YES}}
&\Longrightarrow
\exists w\;\Pr_{r\in\{0,1\}^{R}}[V(q,w;r)=1]\ge 2/3,\\
q\in\Pi_{\mathrm{NO}}
&\Longrightarrow
\forall w\;\Pr_{r\in\{0,1\}^{R}}[V(q,w;r)=1]\le 1/3.
\end{aligned}
\tag{386.1}
\]

假设 \(P=NP\)，并固定一个运行时间为 \(m^{d_A}\) 的 SAT 判定器 \(A_{\mathrm{SAT}}\)。
则存在一个对 gap 输入任意定义、在 promise 上正确的确定性模拟器
\(D_{\mathrm{enum}}\)，其运行时间满足

\[
\operatorname{time}(D_{\mathrm{enum}}(q))
\le
2^{O(d_A R)}L^{O(d_A)}.
\tag{386.2}
\]

因此 \(R=O(\log L)\) 时得到地址尺度的 \(L^{O(1)}\) 模拟；而
\(R=\operatorname{polylog}(t)\) 且 \(L=\operatorname{poly}(k,r,\log t)\) 时，
(386.2) 不自动是 \(\operatorname{poly}(L)\)，更不能自动是
\(\operatorname{poly}(k,r,\log t)\)。

## 证明

构造一个非确定性机器 \(N_q\)。它猜测长度至多 \(L^{O(1)}\) 的 witness \(w\)，
枚举全部 \(2^R\) 个随机带，运行 \(V(q,w;r)\)，并在接受次数至少
\(\lceil(2/3)2^R\rceil\) 时接受。于是

\[
\operatorname{time}(N_q)=2^R L^{O(1)}.
\]

用 Cook--Levin 把 \(N_q\) 和固定输入 \(q\) 编译成 SAT 公式
\(\varphi_q\)，其长度为 \((2^R L^{O(1)})^{O(1)}\)。在
\(P=NP\) 假设下运行 \(A_{\mathrm{SAT}}\) 判定 \(\varphi_q\)，得到 (386.2)。

若 \(q\in\Pi_{\mathrm{YES}}\)，completeness 给出一个 witness 使接受比例至少
\(2/3\)，故 \(\varphi_q\) 可满足；若 \(q\in\Pi_{\mathrm{NO}}\)，所有 witness
接受比例至多 \(1/3\)，故 \(\varphi_q\) 不可满足。gap 输入不影响结论，因为
模拟器只需在 promise 上正确。证毕。

## RW 直接后果

RW Theorem 4.1 的 Reconf query 满足

\[
L=\operatorname{poly}(k,r,\log t),
\qquad
R=O(\log t)+\operatorname{polylog}(t)
\]

其中后一个项来自 Low-Degree Self-Corrector 的随机带。将 (386.2) 代入
failure-to-circuit 组合，只能得到一个一般的

\[
\operatorname{CC}(f(x))
\le
2^{O(R)}\operatorname{poly}(k,r,\log t)
\tag{386.3}
\]

型上界（固定 \(A_{\mathrm{SAT}}\) 的指数吸收到 \(O(\cdot)\) 中）。若
\(R=O(\log\log t)\)，枚举路线仍可能是地址尺度；若 \(R=\Theta(\log t)\)，该
路线的成本达到 \(t^{\Theta(1)}\) 的 object-scale；若 \(R=(\log t)^c\) 且
\(c>1\)，则枚举路线甚至达到 \(t^{(\log t)^{c-1}}\) 量级。

这不是对所有更聪明 simulator 的下界：\(P=NP\) 可能与某个特殊 query format
共同蕴含更快的 promise-preserving 算法。它严格关闭的只是以下推理：

\[
P=NP
\Longrightarrow
\text{无需分析随机带即可得到地址尺度的 prMA 确定化}.
\]

要把 C363 升格为真正的 address-scale Gate-III 定理，仍需证明
\(R=O(\log L)\)、给出独立的 \(\operatorname{poly}(L)\) promise-preserving
simulator，或改造 Reconf 消除该随机阈值层。C384 的“promise gap 不能被
\(P=NP\) 自动 totalize”与本命题相容；本命题把其成本边界定量化。

## 证据边界

* RW Definition 2.1 给出 prMA verifier 的标准 query-length 多项式界；
  Theorem 4.1 的 Reconf 明确使用 \(O(\log t)\) PCP randomness 与
  \(\operatorname{polylog}(t)\) Low-Degree Self-Corrector randomness。
* (386.2) 是枚举随机带后调用固定 SAT 判定器的上界，不是 promise-prMA 的
  unconditional lower bound，也不排除 source-specific faster simulator。
* 本 note 不构成 \(P\ne NP\) 证明；它把 Gate-III 的剩余正攻接口从“泛泛
  collapse”收缩为一个可测的随机阈值/模拟器参数命题。
