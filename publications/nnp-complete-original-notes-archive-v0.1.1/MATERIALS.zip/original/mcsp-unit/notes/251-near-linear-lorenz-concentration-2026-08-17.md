> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Near-linear Lorenz concentration for shared-proof decoders (2026-08-17)

## Result

The pathwise Lorenz closure can be inverted quantitatively.  A fixed-query,
positive-radius shared-proof decoder cannot merely have a bounded heavy core
when its length is near-linear: the top \(\rho N\) proof positions must carry
almost all of the honest query mass.

This is a decoder-intrinsic theorem.  It does not assume a dPCP incidence law,
linearity, projection, or a particular proof construction.

## Theorem

Fix constants \(A\ge 2\), \(Q\ge 2\), \(0<\rho<1\), and \(c>0\).  Let
\(\Sigma\) be an alphabet of size \(A\).  For infinitely many \(k\), let

\[
  \Pi_k:\{0,1\}^{k}\longrightarrow\Sigma^{N_k}
\]

be a common proof map, and let \(D_{i,k}\) be a nonadaptive decoder that
makes at most \(Q\) proof-symbol queries for each message coordinate \(i\).
Assume exact honest correctness

\[
  D_{i,k}^{\Pi_k(m)}=m_i
  \qquad\text{with probability one}
\tag{251.1}
\]

for every \(m\) and \(i\).  For the honest query distribution, let
\(\nu_{m,i,k}(v)\) be the probability that position \(v\) is queried, and set

\[
  \Lambda_{\rho,k}
  :=
  \max_{m,i}
  \sum_{j=1}^{\lfloor\rho N_k\rfloor}
       \nu_{m,i,k,(j)},
\tag{251.2}
\]

where the probabilities are listed in decreasing order.  If

\[
  N_k\le k(\log k)^c
\tag{251.3}
\]

on those lengths, then there is a constant
\(C=C(A,Q,\rho,c)\) such that

\[
  1-\Lambda_{\rho,k}
  \le
  C\,\frac{\log\log(k+2)}{\log(k+2)}
\tag{251.4}
\]

for every sufficiently large length in the infinite set.  If
\(\Lambda_{\rho,k}\ge1\), (251.4) is interpreted trivially.

Equivalently, a fixed-\(Q\), fixed-alphabet, positive-radius shared-proof
family of near-linear length must have a \(\rho N_k\)-position heavy set that
captures \(1-o(1)\) of the honest query mass.

## Proof

If \(\Lambda_{\rho,k}<1\), Proposition 7.3 of the main paper gives a
nonadaptive weak RLDC with success

\[
  \sigma_k:=1-\Lambda_{\rho,k},
\]

radius \(\rho\), locality \(Q\), and block length \(N_k\).  Exact correctness
also makes \(\Pi_k\) injective, so

\[
  N_k\ge \frac{k}{\log_2 A},
\qquad
  \log N_k=\Theta_{A}(\log k).
\tag{251.5}
\]

First suppose that the radius condition in Goldberg--Gur--Saraogi's
nonadaptive RLDC theorem fails:

\[
  \rho\le N_k^{-\sigma_k/(2Q)}.
\]

Taking logarithms and using (251.5) gives

\[
  \sigma_k
  \le
  \frac{2Q\log(1/\rho)}{\log N_k}
  =
  O_{A,Q,\rho}\!\left(\frac1{\log k}\right),
\tag{251.6}
\]

which is stronger than (251.4).

Otherwise the theorem applies and gives

\[
  \frac{k}{\log^2 k}
  \le
  38Q^4\sigma_k^{-2}\log^2 A\,
  N_k^{\,1-\frac1{\lceil Q/\sigma_k\rceil+1}}.
\tag{251.7}
\]

Assume toward a contradiction that

\[
  \sigma_k>K\,\frac{Q\log\log k}{\log k}
\tag{251.8}
\]

for a sufficiently large constant \(K=K(A,Q,c)\).  Then
\(\log(1/\sigma_k)=O_{A,Q,K}(\log\log k)\).  Put
\(a_k=\lceil Q/\sigma_k\rceil\).  Taking logarithms in (251.7) and using
(251.3) yields

\[
  \frac{\log N_k}{a_k+1}
  \le
  \bigl(c+O_{A,Q,K}(1)\bigr)\log\log k.
\tag{251.9}
\]

By (251.5), (251.9) implies

\[
  a_k+1
  \ge
  c_1(A,Q,c,K)\frac{\log k}{\log\log k}.
\tag{251.10}
\]

On the other hand,
\[
  a_k+1\le \frac{Q}{\sigma_k}+2
  <
  \frac1K\frac{\log k}{\log\log k}+2
\]
by (251.8), contradicting (251.10) once \(K\) is chosen larger than the
constant hidden in (251.10).  Hence (251.8) is impossible, proving (251.4).
\(\square\)

## Interpretation

The result turns the fixed-parameter RLDC barrier into an asymptotic profile
law:

* if the top \(\rho N\) positions capture a constant amount less than one,
  the length is polynomially superlinear by the RLDC lower bound;
* if the length is \(k\,\mathrm{polylog}(k)\), the heavy set must capture
  \(1-O(\log\log k/\log k)\) of all honest query mass.

Thus a near-linear construction cannot evade the coding barrier by a moderate
amount of query concentration.  It must make almost every honest query pass
through a \(\rho\)-fraction of the proof, or leave one of the common-proof,
exact-correctness, positive-radius, fixed-locality assumptions.

The statement is written for \(Q\ge2\), where the GGS theorem is the relevant
general nonadaptive input.  The one-query binary endpoint has a separate,
stronger exponential RLDC lower bound.

The theorem is a necessary condition, not an impossibility theorem for all
shared proofs: a construction may deliberately use such an almost-total heavy
core, but then the core itself becomes the next object that must be bound
semantically or charged as target-dependent information.

## Source boundary

The only external input is Goldberg--Gur--Saraogi,
*Nearly Tight Lower Bounds for Relaxed Locally Decodable Codes via Robust
Daisies*, Theorem 1:
<https://arxiv.org/abs/2511.21659>.  The pathwise Lorenz-to-RLDC compiler is
Proposition 7.3 of the main paper and its full adaptive formulation is in
[note 226](226-pathwise-lorenz-profile-adaptive-shared-proof-closure-2026-08-17.md).
