> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Minimal collision witness 的参数秩下界（2026-08-13）

## 定义

固定 spoiler (s)，称 cell 集 (T) 为 inclusion-minimal witness，若

\[
L(T)\ne\varnothing,qquad L(T)\cap H_s=\varnothing,
\]

且对每个 (c\in T)，

\[
L(T\setminus\{c\})\cap H_s\ne\varnothing.
\tag{M}
\]

设 (k=|T|)。以下假设 (H_s) 非空（否则 spoiler 本身不是合法 cell 约束）。

## 定理

令 (A_T) 为 (T) 的参数线性系统的系数矩阵，即每个 (c=(x_c,y_c)) 提供两行

\[
q_c=(x_c,1),qquad p_c=(y_c,1).
\]

若 (T) 满足 (M)，则

\[
\boxed{\operatorname{rank}A_T\ge k+1.}
\tag{1}
\]

## 证明

在扩展空间 (E=\mathbb F_2^{n+2}) 中定义

\[
e=(0,\ldots,0,1),
\qquad
\widehat q_c=(q_c,0),
\qquad
\widehat p_c=(p_c,1),
\]

以及

\[
U_c=\operatorname{span}\{\widehat q_c,\widehat p_c\},
\qquad
V=\sum_{c\in T}U_c,
\qquad W=U_s.
\]

齐次化变量为 (w=(z,1))。因此

\[
L(T)\ne\varnothing\Longleftrightarrow e\notin V,
\qquad
L(T)\cap H_s=\varnothing\Longleftrightarrow e\in V+W.
\tag{2}
\]

条件 (M) 等价于

\[
e\notin V_{-c}+W,qquad V_{-c}=\sum_{d\ne c}U_d,
\tag{3}
\]

对所有 (c\in T) 成立。

商去 (W)，置

\[
Q=(V+W)/W,qquad \overline U_c=(U_c+W)/W,qquad \overline v=e+W.
\]

由 (2)–(3)，

\[
\overline v\notin\sum_{d\ne c}\overline U_d
\quad(c\in T).
\tag{4}
\]

先取分解 (overline v=\sum_c\overline u_c)，其中
(overline u_c\in\overline U_c)。式 (4) 保证每个 (overline u_c\ne0)，且这些向量线性无关：若
(\sum_{c\in S}\overline u_c=0) 对某非空 (S)，则从总和中消去 (S) 得
(overline v\in\sum_{d\ne c}\overline U_d)（任取 (c\in S)），矛盾。因此

\[
\dim Q\ge k.
\tag{5}
\]

若某个 (overline U_i) 维数为 (2)，假设 (dim Q=k)。则上述 (overline u_c) 构成 (Q) 的基。取
(overline w\inoverline U_isetminus\langle\overline u_i\rangle)。对每个 (j\ne i)，
(\sum_{d\ne j}\overline U_d) 含有除 (overline u_j) 外的 (k-1) 个基向量，又由 (4) 不含 (overline v)，故恰为这些基向量的张成空间；于是 (overline w) 的 (overline u_j)-系数为零。对所有 (j\ne i) 均如此，推出 (overline w\in\langle\overline u_i\rangle)，矛盾。故此时

\[
\dim Q\ge k+1.
\tag{6}
\]

剩下所有 (overline U_i) 都是一维。由于每个 (U_i) 与 (W) 都是二维，

\[
\dim(U_i\cap W)=1.
\]

若两个交线不同，则它们张成 (Wsubseteq V)，与 (e\notin V) 及 (e\in V+W) 矛盾。因此所有交线相同，从而

\[
\dim(V\cap W)\ge1.
\tag{7}
\]

由 (5)、(7) 及 (dim W=2)，

\[
\dim V
=\dim(V+W)-2+\dim(V\cap W)
\ge k+1.
\]

最后 (e\notin V) 使得投影 (V\to\mathbb F_2^{n+1})（删去扩展坐标）单射，所以
(dim V=\operatorname{rank}A_T)，得到 (1)。
(square)

## 概率后果与局限

若 (r_T,c_T) 是 (T) 使用的行、列数，则

\[
\Pr_{z,U,V}[T\subseteq R_z(U,V)]
=2^{-\operatorname{rank}A_T-r_T-c_T}
\le 2^{-(k+1+r_T+c_T)}.
\tag{8}
\]

对 (k=3)，(r_T+c_T\ge4)，故单个最小三元 witness 的质量至多 (2^{-8}=1/256)。一般 (k) 只能使用 (r_Tc_T\ge k)，即 (r_T+c_T\ge\lceil2\sqrt{k}\rceil)；(8) 仍不能控制大量 witness 的并集。

## p_s-free 高阶族的障碍

秩界不能推出固定 (z) 的额外 (1/2)。例如 (n=3,s=(0,1))，取

\[
\mathcal T=\{\{(1,2),(1,3)\},\{(1,2),(1,7)\},\{(1,3),(1,7)\}\}.
\]

三条 witness 两两相交，且每条 (L(T)) 上均满足 (p_s=0)。在 (z=(2,0)) 的叶上，它们变成同一行的三个二元 witness；独立行列 thinning 命中至少一条的条件概率恰为 (1/4)。因此“单一 separator 类型”本身不能把固定叶质量从 (1/4) 降至 (1/8)。该族的全局质量为 (5/128<1/16)，所以它是障碍而非完整反例。
