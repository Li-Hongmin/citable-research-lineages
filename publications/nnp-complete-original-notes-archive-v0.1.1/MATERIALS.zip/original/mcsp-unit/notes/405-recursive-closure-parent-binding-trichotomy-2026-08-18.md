> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Recursive closure--parent binding 的失败质量三分（2026-08-18）

## 本轮结果

C402 只给出“若所有 product-rich tuples 都递归 in-range，则总 entropy 至多 \(k\)”；
C378 只给出“若每个 parent 都由 outsider transcript 精确恢复，则 transcript
必须携带 parent entropy”。本 note 将两者合并成一个定量三分：对一个
product-rich source family，要么 recursive range-closure 只能覆盖至多 \(2^k\)
个 targets，要么非输出递归失败有定量质量；若所有 good targets 又被硬度排除，则
每个 target 都必须暴露一个 failure transcript，并由该 transcript/descriptor 支付
整个 parent family 的信息量。

## 模型

令

\[
 G:\{0,1\}^{k}\to\{0,1\}^{2k},\qquad
 R=\operatorname{Range}(G),
\]

并固定 canonical preimage \(p:R\to\{0,1\}^{k}\)，满足 \(G(p(z))=z\)。
考虑一个深度为 \(d\) 的 full binary subtree。每个 leaf \(\ell\in[2^d]\) 有一个
block family \(\mathcal A_\ell\subseteq R\)，并假设 source family 对每个 tuple

\[
 a=(a_1,\ldots,a_{2^d})\in
 \mathcal T:=\prod_{\ell=1}^{2^d}\mathcal A_\ell
\]

都实现同一个 source-compatible subtree：每个内部 node 的 children 是前一层
canonical blocks，且该 node 被要求为 non-output。

对 tuple \(a\)，称它为 **good**，如果该 subtree 的每一个内部 node 都属于 \(R\)；
否则称为 **recursive-bad**。令

\[
 M:=|\mathcal T|=\prod_{\ell=1}^{2^d}|\mathcal A_\ell|,
 \qquad
 S:=\log_2 M.
\]

## Theorem 405.1（recursive closure--failure-mass bound）

good tuples 的数量至多为 \(|R|\le2^k\)。因此

\[
 |\mathcal T_{\rm good}|\le2^k,
 \qquad
 \Pr_{a\sim\mathrm{Unif}(\mathcal T)}
 [a\text{ recursive-bad}]
\ge 1-\frac{2^k}{M}
=1-2^{k-S}.
\tag{405.1}
\]

### 证明

对每个 good tuple，令 \(\Phi(a)\in R\) 为根 block。映射 \(\Phi\) 是 injective。
事实上，若两个根相同，则 canonical preimage 相同；把该 \(k\)-bit preimage
按左右 halves 分开，得到两个 child preimages。由于 \(p\) 在 \(R\) 上 injective，
左右 child blocks 分别相同。递归向下即可得到所有 leaves 相同。故
\(|\mathcal T_{\rm good}|\le|R|\le2^k\)，除以 \(M\) 得 (405.1)。证毕。

该证明不依赖线性 ECC、proof alphabet、具体 serialization 或 singleton；
关键量词是每一个 leaf tuple 都被 source family 实现。

## Theorem 405.2（first-failure transcript entropy）

令 \(N_d=2^d-1\) 为 subtree 的内部 node 数。假设每个 recursive-bad target
产生一个 first-failure transcript

\[
 \tau(a)=(v(a),y(a)),
\]

其中 \(v(a)\in[N_d]\) 是失败 node，\(y(a)\in\{0,1\}^{2k}\) 是该 node 的
non-range block；再允许一个 target-dependent descriptor
\(\sigma(a)\in\{0,1\}^{D}\)。在 good target 上令 \(\tau(a)=\bot\)，其中
\(\bot\) 是一个固定 flag。若在一个 parent family \(\mathcal T\) 上，给定
\((\tau(a),\sigma(a))\) 可以 exact recover \(a\)，则令

\[
\rho:=\Pr_{a\sim\mathrm{Unif}(\mathcal T)}
 [a\text{ recursive-bad}].
\]

有熵不等式

\[
 D+h_2(\rho)+\rho\bigl(2k+\log_2 N_d\bigr)\ \ge\ S,
\tag{405.2}
\]

其中 \(h_2\) 是 binary entropy。特别地，若所有 targets 都必须 recursive-bad
（\(\rho=1\)），则

\[
 D+2k+\log_2 N_d\ge S.
\tag{405.3}
\]

### 证明

令 \(F\) 表示是否 recursive-bad。由 exact recovery，目标 tuple \(a\) 是
\((F,\tau,\sigma)\) 的确定函数，因此

\[
 S=H(a)\le H(F,\tau,\sigma).
\]

有 \(H(F)=h_2(\rho)\)；条件于 \(F=1\)，\(\tau\) 的值域至多
\(N_d2^{2k}\)，故

\[
 H(F,\tau)\le h_2(\rho)+\rho(2k+\log_2N_d).
\]

descriptor 至多贡献 \(D\) bits，合并即得 (405.2)。当 \(\rho=1\) 时得到
(405.3)。证毕。

## Corollary 405.3（hard-target recursive-cover trichotomy）

假设 proposed RW/JK attachment 对每个 good target 都给出一个 circuit upper bound
\[
\operatorname{CC}(H_a)\le E
\]
（例如 JK easy branch 的 self-corrector bound），而 parent family 满足
\[
\operatorname{CC}(H_a)>E
\qquad\text{for every }a\in\mathcal T.
\]
则 good target 不存在，故 \(\rho=1\)。任何只暴露一个
\(2k\)-bit recursive outsider、node index 和 \(D\)-bit descriptor 的 exact
whole-parent closure 必须满足

\[
 D+2k+\log_2(2^d-1)\ge
 \sum_{\ell=1}^{2^d}\log_2|\mathcal A_\ell|.
\tag{405.4}
\]

因此在 \(S\gg k+d\) 的 product-rich regime，不能同时拥有：

1. 所有 non-output recursive nodes 都 target-independently in-range；
2. hard targets 排除 good/easy branch；
3. 单个 address-scale outsider 加短 descriptor 精确绑定 whole parent。

至少一个条件必须退出。这是 C401/C402/C378 的同一量词下的三分，而不是把
singleton support 或 abstract family entropy 偷换成 published RW 事实。

## RW/Harsha 适用边界

* 对 C402 的 \(M>2^k\) family，(405.1) 给出 failure mass，而不只是“存在一个
  outsider”。
* **Public-input accounting is mandatory.** 若 family tuple \(a\) 是一个公开
  \(n\)-bit 输入 \(x\) 的确定函数，则
  \(S=H(a)\le H(x)\le n\)。若 decoder 可以直接读取 \(x\)，则 (405.2) 应写成
  \[
  n+D+h_2(\rho)+\rho(2k+\log_2N_d)\ge S,
  \tag{405.5}
  \]
  这在 \(S\le n\) 时是平凡的。因此 \(M_{\rm pair}(u,v)\) 只证明
  target-oblivious generator 的 family-level barrier；它不能在公开输入已携带
  \(u,v\) 时直接推出 RW 的 parent-binding impossibility。
* 若 source-specific cover 只保证 non-output nodes in-range，则 recursive-bad
  event 必须落在 output-attached ancestry；此时 (405.2)--(405.4) 计量的是
  output/failure transcript 的 parent-binding 代价。
* Theorem 4.3 的 published \(x_0\) 是 singleton，不能直接令
  \(\mathcal T\) 为 \(2^S\)-大小的 parent family；需要 target-oblivious family
  lift 或新的 forcing family。
* 若在固定 public \(x\) 下声称存在多个 canonical histories，必须把 selector
  randomness、hidden advice 或 witness choice 的熵显式加入 descriptor；不能把它
  当作免费 family entropy。
* 若 descriptor 本身包含完整 target/history，(405.2) 仍成立，但只说明它支付了
  message-scale information；不能把这种 descriptor 宣称为 address-scale closure。
* Theorem 405.2 对 first-failure node/value 的值域作了显式计数；若协议还暴露
  additional transcript、random tape 或 sheet index，应将其比特长度加到
  \(D+2k+\log N_d\)，不能免费忽略。

## 结论

Theorem 405.1 是 C402 的 quantitative family-strengthening，Theorem 405.2 是
C378 的 entropy form。二者合起来把 RW-specific Closure 的 family route 压成
一个可证伪接口：构造 product-rich source family 并验证 hard-target condition，
即可得到非输出 recursive failure mass 或 message-scale binding payment。当前结果
仍不证明 \(P\ne NP\)，但已达到可以作为独立 recursive-cover barrier theorem
继续发展的精确形式。
