> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Published RW 输出的 forcing 尺度（2026-08-19）

## 本轮改变的判断

C454 及 C450 的 forcing-side 前提可以对 Ren--Williams 已发表的 AVOID 输出
直接实例化，而不必把“forcing-hard parent”作为未核验假设。代价是要把对象限定为
RW Theorem 4.3 的同一个确定输出 \(B_n=A'(1^n)\)，并只在其 infinitely-often
good lengths 上陈述。这个结果关闭的是 forcing 参数核验，不是 RW-specific
address-scale reconstruction；它也不把 C454 的 source-compatible zero-round
parent 认作 published RW 的 canonical serialization。

## 定理 455.1（published RW hard-output forcing scale）

令 \(A'\) 是 Ren--Williams Theorem 4.3 在 truth-table-generator family
\(G_n:\{0,1\}^n\to\{0,1\}^{2n}\) 上得到的 smart-
\(\mathrm{FP}^{\mathrm{prMA}}/1\) 算法。则存在无限集合
\(\mathcal I\subseteq\{2^k:k\ge1\}\)，使得对每个 \(n=2^k\in\mathcal I\)，令

\[
  B_n:=A'(1^n),
  \qquad N_n:=|B_n|=2n.
\]

则 \(B_n\notin\operatorname{Range}(G_n)\)，并且

\[
  \operatorname{CC}(B_n)
    > 0.1\,\frac{2^k}{k}
    = \Omega\!\left(\frac{N_n}{\log_2(N_n+2)}\right).
  \tag{455.1}
\]

这里的电路复杂度是把 \(B_n\) 视为长度 \(N_n\) 的 truth table 的最小
fan-in-two Boolean circuit size。

### 证明

Theorem 4.3 给出一个 smart、单比特 advice 的 AVOID 算法，并保证在无限多个
输入长度 \(n=2^k\) 上输出 \(B_n\notin\operatorname{Range}(G_n)\)。在同一节
Theorem 4.5 的证明开头，作者直接从这个算法取出无限多个 \(k\)，并明确写出：
\(A'(1^{2^k})\) 是长度 \(2^{k+1}\) 的 truth table，且不能由大小
\(0.1\cdot 2^k/k\) 的电路计算。令 \(n=2^k\)、\(N_n=2^{k+1}=2n\)，即得

\[
  \operatorname{CC}(B_n)>0.1\,2^k/k.
\]

由于 \(\log_2(N_n+2)=k+1+o(1)\)，这等价于 (455.1)。证毕。

## 对 Closure 的直接推论

1. 若一个 proposed closure 在同一无限集合 \(\mathcal I\) 上，为同一个
   \(B_n\) 提供地址长
   \(\ell_n=\lceil\log_2(N_n+1)\rceil\) 的 single-object evaluator，且其
   电路大小为 \(\ell_n^{O(1)}\)，则与 (455.1) 矛盾。因此这类 evaluator 不能
   只由 RW Theorem 4.1--4.3 的 object-scale Reconf 自动得到。
2. 若 closure 属于 C450 的 common-ROM 模型，控制大小为 \(p_n\)，descriptor
   长度为 \(d_n\)，且至多 \(b_n\le p_n\) 次读取，则 ROM 展开给出

\[
      \operatorname{CC}(B_n)
      \le O\!\left(p_n^2+p_nd_n+p_n\ell_n\right).
\]

   因而在 \(\mathcal I\) 上必须有

\[
      p_n^2+p_nd_n+p_n\ell_n
      =\Omega\!\left(\frac{N_n}{\log N_n}\right).
\tag{455.2}
\]

   特别地，若 \(p_n,\ell_n=\operatorname{polylog}(N_n)\)，descriptor 本身必须
   支付 \(N_n/\operatorname{polylog}(N_n)\) 级信息；把整张 history 改名为
   descriptor 不是地址尺度压缩。
3. 该 forcing 事实仍不能排除 stable solver branch：在 \(P=NP\) 下，RW
   Solve/BF 只给出 \(N_n^{O(1)}\)-规模的 object-scale evaluator，而
   \(N_n^{O(1)}\) 与 \(N_n/\log N_n\) 下界相容。要得到最终矛盾，仍须证明
   stable branch 也有 \(\ell_n^{O(1)}\) random-access evaluator，或证明新的
   超过 \(N_n^{\omega(1)}\) forcing 下界。

## 证据边界

* (455.1) 是对 published RW Theorem 4.3/4.5 的直接参数抽取，不是新的
  \(P\ne NP\) 证明。
* \(B_n\) 是 RW AVOID 输出；本 note 不声称它等于 C454 中 source-compatible
  tableau 的零轮 parent \(M(x_0)\)，也不声称 published RW 采用 C453/C454 的
  cell-time serialization、fresh output-check 或 \(P=p(q)\) evaluator。
* Theorem 4.3 只给出 infinitely-often 长度；任何 Closure 结论仍需与这组
  长度对齐，并针对同一个 \(B_n\) 保持 common proof、whole-word consistency
  和 smartness。

## 来源

* Ren--Williams, ECCC TR26-118 revision 1, Theorem 4.3 及 Theorem 4.5 proof
  （Section 4.2）；本地抽取：
  units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md。
* [C450 scale-complete RW Closure normal form](450-scale-complete-rw-closure-normal-form-2026-08-19.md)。
* [C454 source-compatible incidence/auxiliary barrier](454-rw-source-compatible-incidence-auxiliary-barrier-2026-08-19.md)。
