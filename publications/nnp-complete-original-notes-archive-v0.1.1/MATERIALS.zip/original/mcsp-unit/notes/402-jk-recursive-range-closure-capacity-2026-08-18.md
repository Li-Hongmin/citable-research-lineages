> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK recursive range-closure 的乘法容量界（2026-08-18）

## 本轮判定

C401 的条件 2 不是“把每个原始 proof 区段覆盖”就能免费得到的。若两个
non-output blocks 的值可以独立组合，那么它们的 canonical preimage 拼接后也
必须落入同一个 \(2^k\)-大小的 generator range；这给出一个乘法而非加法的
容量界。结果与 ECC 的线性无关，直接作用于 JK 的递归结构。

## 预像映射

令

\[
 G:\{0,1\}^{k}\to\{0,1\}^{2k},
 \qquad R=\operatorname{Range}(G),
\]

并固定 JK 使用的 canonical preimage map

\[
 p:R\to\{0,1\}^{k},
 \qquad G(p(z))=z.
\tag{402.1}
\]

由于 \(G(p(z))=z\)，\(p\) 在 \(R\) 上必为 injective：若
\(p(z)=p(z')\)，则 \(z=G(p(z))=G(p(z'))=z'\)。因此

\[
 |R|\le 2^k,\qquad |p(A)|=|A|\quad(A\subseteq R).
\tag{402.2}
\]

## Theorem 402.1（two-block product closure）

设 \(\mathcal A,\mathcal B\subseteq R\) 是两个 non-output block-value families。
假设 source family 具有以下 product-rich 性质：对每个
\((a,b)\in\mathcal A\times\mathcal B\)，存在一个 canonical proof 使得
\(a,b\) 是相邻的 non-output blocks，并且 JK 的下一层 block

\[
 c(a,b):=p(a)\Vert p(b)
\tag{402.3}
\]

也是 non-output。若 C401 的 recursive range-closure 假设成立，即所有这些
\(c(a,b)\) 都属于 \(R\)，则

\[
 |\mathcal A|\,|\mathcal B|\le |R|\le 2^k,
 \qquad\text{即}\qquad
 \log_2|\mathcal A|+\log_2|\mathcal B|\le k.
\tag{402.4}
\]

### 证明

映射

\[
 (a,b)\longmapsto p(a)\Vert p(b)
\]

在 \(\mathcal A\times\mathcal B\) 上 injective：若两个拼接相同，则左右各
\(k\)-bit half 分别相同；由 \(p\) 的 injectivity 得到 \(a=a'\)、\(b=b'\)。
根据 recursive range-closure，所有这些不同的拼接都在 \(R\) 中，故
\(|\mathcal A||\mathcal B|\le|R|\)。再用 \(|R|\le2^k\) 即得 (402.4)。证毕。

## Corollary 402.2（多层 product closure）

设一个深度为 \(d\) 的完整二叉 JK subtree 的 leaves 分别来自 families
\(\mathcal A_1,\ldots,\mathcal A_{2^d}\)。假设每一个 leaf tuple 都由 source
family 实现，且所有由 (402.1) 逐层拼出的内部 blocks 都是 non-output 并落在
\(R\)。则

\[
 \prod_{\ell=1}^{2^d}|\mathcal A_\ell|\le |R|\le2^k,
 \qquad
 \sum_{\ell=1}^{2^d}\log_2|\mathcal A_\ell|\le k.
\tag{402.5}
\]

证明是 Theorem 402.1 的归纳：根 block 的值由其两个 child blocks 的
canonical preimage halves 唯一决定；因此 leaves 的 tuple 到 root block 的
映射始终 injective。这个结论的关键量词是“每一个 leaf tuple 都实现”，而
不是只存在一条实际 proof。

## Singleton 版本的直接检查

对一个固定 canonical proof，不需要 family independence 也有一个较弱的
检查：若在所有 JK levels 中出现的 non-output recursive block-value 集合
\(\mathcal Z_{\rm no}\) 的大小超过 \(2^k\)，则不可能所有这些 blocks 都落在
\(R\)。同样，若出现的 distinct adjacent non-output pair 集合超过 \(2^k\)，
则 (402.3) 的 injectivity 也排除 recursive range-closure。于是 C401 的
条件 2 至少要求

\[
 |\mathcal Z_{\rm no}|\le2^k,
 \qquad
 |\mathcal P_{\rm no}^{(2)}|\le2^k.
\tag{402.6}
\]

这两个量可以直接从一个给定 proof 和一个候选 \(G_k\) 的 JK trace 计算；但在
当前 RW 参数下，尚未证明它们超过 \(2^k\)，所以不能把 (402.6) 冒称为
published singleton 的不可能性。

## 对 RW/Harsha Closure 的意义

1. **C401 的 recursive obligation 有真实代价。** 原始 \(\Upsilon\)
   product-ECC cover 和低度 line cover 只说明直接 stream intervals 可描述；
   若 non-output witness/auxiliary blocks 形成两个近乎独立的 families，
   (402.4) 强迫它们的总 entropy 不超过 \(k\)。
2. **Family-level 正攻被明确压缩。** 若能在同一 source-compatible
   serialization 下构造两个 non-output witness groups，使
   \(\log|\mathcal A|+\log|\mathcal B|>k\)，则任何共同 \(G_k\) 都会在
   non-output ancestry 处失败；这不是 output attachment，而是一个严格的
   recursive-cover barrier。对 target-oblivious family lift，它可与 C390/C391
   的 payload/RLDC barrier 叠加。
3. **Published singleton 仍有边界。** Theorem 4.3 固定 \(x_0\)，所以
   product-rich family 量词不能自动套用；要得到 singleton-specific 结论，必须
   直接证明 (402.6) 的 block/pair support 超过 \(2^k\)，或证明实际 history
   的地址级生成不可能满足 recursive closure。

RW Lemma 3.2 的 history 顺序

\[
 (y_1,\ldots,y_r,\mathrm{out},z_{1,1},\ldots,z_{r,t})
\]

确实把 NP-query witnesses 放在 systematic output 之外；但原文没有给出这些
\(z_{i,j}\) 在一个 hidden-parent family 上的 product-rich 独立性，也没有给出
singleton trace 的 support 下界。因此本 note 关闭的是“递归封闭无成本”这一
假设，不是对实际 RW source 的最终定理。

### 一个 source-realizable product-rich stress test

为确认该量词不是空的，取一个合法的两查询机器 \(M_{\rm pair}\)。输入为
\(x=(u,v)\)，其中 \(u,v\in\{0,1\}^{2k}\)；机器在同一轮提出两个 NP 查询，
第一个查询只接受 witness \(u\)，第二个只接受 witness \(v\)，最后输出固定的
单比特 \(0\)。两个查询都有唯一满足 witness，所以 Lemma 3.2 的 lexicographically
largest history 在 systematic prefix 中包含

\[
 (y_1=2,\mathrm{out}=0,z_{1,1}=u,z_{1,2}=v).
\tag{402.7}
\]

在保持这两个 witness blocks 相邻的 source-compatible serialization 下，

\[
 \mathcal A=\mathcal B=\{0,1\}^{2k}
\]

满足 Theorem 402.1 的 product-rich hypothesis，而
\(\log|\mathcal A|+\log|\mathcal B|=4k>k\)。因此不存在一个与 \(x\) 无关的
\(G_k:\{0,1\}^{k}\to\{0,1\}^{2k}\)，能让这两个 non-output witness
blocks 及其下一层 preimage 拼接在整个 family 上都保持 in-range。

这个 stress test 是 RW/Harsha source 的真实 machine specialization，但它有
两个明确边界：输入 \(x=(u,v)\) 本身是公开的，且 published Theorem 4.3 固定
singleton \(x_0\)。所以它关闭的是 **target-oblivious family-level recursive
cover**，不是 singleton-specific \(P\ne NP\) 证明；若要把它升级为主定理，必须
再给出一个不把 \(x\) 直接作为 parent descriptor 的 common-proof 量词。

## 证据边界

* C382：JK 的 single-half lift 与下一层 block 的拼接公式；
* C399：actual proof-family block support dichotomy；
* RW Lemma 3.2 / Theorem 3.5：history 中 \(y,\mathrm{out},z\) 的顺序与
  systematic output prefix；
* C401：systematic-output hard-exit 的条件性位置定理。

本 note 是一个递归 range-closure 容量定理；不证明 \(P\ne NP\)，不声称
published RW singleton 已满足 product-rich hypothesis，也不把 family-level
barrier 直接升级为一般 dPCP/RLDC 不可能性。
