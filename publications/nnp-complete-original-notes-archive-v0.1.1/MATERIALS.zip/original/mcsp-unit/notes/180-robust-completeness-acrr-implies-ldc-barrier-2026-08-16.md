> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Strong coordinate robustness implies an LDC barrier (2026-08-16)

## 定义：strong projection-robust ACRR

令 `C:{0,1}^k -> Sigma^N` 是一个 injective codeword map。对每个坐标 `i` 和
声明位 `b`，有一个非自适应 `q`-query verifier `V_{i,b}`。假设存在常数
`alpha,beta` 与 corruption radius `delta`，对任意 `y` 满足
`dist(y,C(m))<=delta`：

\[
\Pr[V_{i,m_i}^y=1]\ge 1-\alpha,
\qquad
\Pr[V_{i,1-m_i}^y=1]\le \beta,
\]

并且 `alpha+beta<1`。这里要求对所有近 codeword 都有正确声明的高完备率；这比
普通 ACRR 的 honest-proof completeness 强得多。

## 定理：strong ACRR 给出非 relaxed LDC

上述对象给出一个 `O(q/(1-alpha-beta)^2)`-query LDC，具有相同的长度 `N`、字母表
和 corruption radius `delta`。

### 证明

设 `Delta=1-alpha-beta>0`。对给定 `i`，分别独立运行 `V_{i,0}` 和 `V_{i,1}`
各 `R=Theta(Delta^{-2})` 次，比较两种声明的接受频率，输出频率更高的 bit。

当 `m_i=0` 时，正确声明的期望接受率至少 `1-alpha`，错误声明至多 `beta`；
当 `m_i=1` 时同理。Hoeffding 界给出常数 `R` 后错误概率至多 `1/3`。查询数为
`2Rq=O(q/Delta^2)`，且对每个近 codeword、每个坐标成立。因此这是标准 LDC，
不是允许 `bottom` 的 RLDC。

## 3-query 后果

若 `q=3`、`Sigma` 为常数、`delta=Omega(1)`，则该 LDC 满足现有三查询 LDC 长度
下界
\[
  N=Omega(k^3/log^6 k).
\]
因此强 ACRR 不可能同时拥有近线性长度和固定三次查询。

## 为什么这不是一般 ACRR 下界

普通 ACRR/Sim-CR 只保证 honest proof 上正确声明完备，近 proof 可能全部拒绝；
此时上面的频率比较无法构成 LDC，只能得到 note 178 的 RLDC 型归约。也就是说：

1. **强完备 + 错误声明 soundness** ⇒ LDC barrier；
2. **允许 `bottom`/拒绝近 proof** ⇒ 只得到 RLDC，非线性近线性构造仍可能存在；
3. 任何顶级正向构造若想避开三查询 LDC 下界，必须明确使用 relaxed rejection、
   自适应性，或放弃近 codeword 上的 uniform high completeness。

这把 `bottom` 从实现细节提升为结构性分界，而不是声称一般 ACRR 已被排除。

## 与现有路线的关系

- note 178 覆盖“线性 + relaxed robustness”并调用线性 RLDC 下界；
- 本 note 覆盖“非线性也可、但要求近 proof 高完备”的强模型，并调用普通 LDC 下界；
- note 179 的 shared pair-PCPP 若同时满足本 note 的 strong-completeness 条件，立即
  落入该 barrier；否则其正面逃逸必须显式依赖 `bottom` 或低完备。

## 证据边界

Gur--Minzer--Weissenberg--Zheng 的公开 Theorem 1.10（引用三查询 LDC 下界）给出
常数字母表、常数距离参数下的 `Omega(k^3/log^6 k)` 下界。本 note 的新内容是把
两个声明位 verifier 通过频率比较组合成 LDC；不把结论外推到普通 relaxed ACRR。

## 来源

- [GM--Minzer--Weissenberg--Zheng, Theorems 1.9--1.10](https://arxiv.org/html/2512.12960)
- [Goldberg--Gur--Saraogi, RLDC lower bound](https://arxiv.org/html/2511.21659)
