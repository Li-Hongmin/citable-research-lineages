> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 仿射-profile 正规化与低局部性断点

> 后续结果：[small-bias locality 路线](004-small-bias-locality-barrier.md) 已被严格关闭；剩余目标必须使用不以全局 small bias 为核心的低复杂度 support 分布。

## 一、仿射-profile 可多项式正规化

设 Formula-XOR 表示为

\[
F(x)=A(P_1(x),\ldots,P_S(x)),
\]

其中

\[
P(x)=p_0+Mx,\qquad
r:=\operatorname{rank}_{\mathbb F_2}M.
\]

高斯消元选取 \(\operatorname{rowspan}(M)\) 的一组基

\[
Q_1,\ldots,Q_r.
\]

映射

\[
Q:\mathbb F_2^N\to\mathbb F_2^r
\]

满射，并且存在 \(a_i,c_{ij}\in\mathbb F_2\)，使

\[
P_i(x)=a_i\oplus\bigoplus_{j=1}^{r}c_{ij}Q_j(x).
\]

把外层公式 \(A\) 的第 \(i\) 个叶替换为该仿射 parity 的平衡 De Morgan 公式，得到 \(B\)。由 parity 的二次公式上界，

\[
L(B)
\le C\sum_{i=1}^{S}
\left|\{j:c_{ij}=1\}\right|^2
\le CSr^2
\le CS^3.
\]

因此

\[
\boxed{
F(x)=B(Q(x)),
\qquad
Q(\mathbb F_2^N)=\mathbb F_2^r,
\qquad
L(B)=O(Sr^2).}
\]

这彻底消除了“外层公式只在不可达 profile 外显得敏感”的问题，且不产生指数膨胀。

对每个 \(j\)，存在 \(d_j\) 使

\[
Q(d_j)=e_j.
\]

所以正规化后的坐标 influence 有真实输入解释：

\[
\Pr_q[B(q)\ne B(q+e_j)]
=
\Pr_x[F(x)\ne F(x+d_j)].
\]

## 二、低秩 canonical quotient

若只要求得到 \(A\) 在可达仿射子空间上的规范函数，可以枚举全部 \(2^r\) 个 profile，再写成固定顺序 DNF：

\[
\operatorname{time}
=O((|A|+Sr)2^r+\operatorname{poly}(|M|)),
\qquad
L_{\mathrm{DNF}}=O(r2^r).
\]

故

\[
r=O(\log S)
\Longrightarrow
\text{多项式时间、大小的 canonical quotient}.
\]

任意秩则存在复杂性障碍。问题

\[
\operatorname{AFFINE\mbox{-}ONE}
=
\{(M,b,A):\forall y,\ A(b+My)=1\}
\]

是 coNP-complete：属于 coNP；取 \(M=I,b=0\) 即 Formula-TAUT。即使要求 \(M\) 可逆、每行稠密且互异仍成立，例如偶数维时可取 \(M=J+I\)。

所以能识别常函数规范形的一般多项式时间 canonical quotient 将推出

\[
P=coNP.
\]

这不妨碍上一节的基变换；它说明基变换后继续删除普通公式内部的所有语义冗余，本身已经触及原问题的困难度。

## 三、显式高宽冗余族

令 \(n\) 为偶数，\(S=n+1\)，并取

\[
a_i=\mathbf1+e_i\quad(i\le n),
\qquad
a_{n+1}=\mathbf1,
\qquad
z_i=a_i\cdot x.
\]

前 \(n\) 行组成 \(J+I\)，在偶数维可逆；同时

\[
\sum_{i=1}^{n+1}a_i=0.
\]

故可达 profile 为

\[
W=\left\{z:\bigoplus_{i=1}^{S}z_i=0\right\}.
\]

所有内层 parity 两两不同，宽度为 \(n-1\) 或 \(n\)。外层函数

\[
A(z)=\bigoplus_{i=1}^{S}z_i
\]

的每个坐标在全立方体上均 essential，但

\[
A|_W\equiv0.
\]

因此，高宽、语法 essentiality、总 incidence energy 都不能代替仿射依赖分析。

## 四、2020 Formula-XOR 下界没有覆盖 magnification 阈值

Kabanets 等证明标准 MCSP 满足

\[
\operatorname{MCSP}
\notin
\operatorname{FORMULA}[\widetilde\Omega(N^2)]
\circ\operatorname{XOR}.
\]

其局部 PRG 为大小 \(s\) 的 Formula-XOR 提供种子长度

\[
d=
O\!\left(
\sqrt{s}\log s\log(1/\varepsilon)+\log N
\right).
\]

同一构造中，给定种子与输出坐标，计算一个 PRG 输出位的电路大小也依赖

\[
\log(1/\delta)
=\Theta(\sqrt{s}\log s\log(1/\varepsilon)).
\]

对 \(s=N^{1.01}\)，这是

\[
N^{0.505+o(1)}.
\]

因此该 PRG 生成的真值表只能保证具有 \(N^{\Omega(1)}\) 规模的电路。论文也明确指出，其 MCSP 下界需要阈值参数

\[
\ell=N^{\Omega(1)}.
\]

Frontier B 则是 promise 问题

\[
\operatorname{GapMCSP}
\!\left[
2^{(\log N)^{1/3}},
2^{(\log N)^{2/3}}
\right].
\]

为了让 PRG 输出成为 YES instances，逐位计算复杂度必须至多 \(2^{(\log N)^{1/3}}\)（或先相应放宽 Frontier B 的常数参数）；NO 端的 \(2^{(\log N)^{2/3}}\) 不能替代这个要求。仅写成 \(N^{o(1)}\) 也不够，因为该记号允许远大于两者的函数。所以两者不能拼接：

\[
\boxed{
\text{Formula-XOR 下界模型已正确}
\quad\text{但 PRG locality 太高}.}
\]

### 充分条件的严格形式

令 \(\mathcal C\) 为候选判定模型。假设

\[
G:\{0,1\}^d\to\{0,1\}^N
\]

以误差 \(\varepsilon<1/3\) fool \(\mathcal C\)，且给定种子 \(z\) 与坐标 \(j\)，输出位 \(G(z)_j\) 可由大小

\[
a(N)\le 2^{(\log N)^{1/3}}
\]

的电路计算。固定 \(z\) 后，该坐标电路就是 \(G(z)\) 所表示布尔函数的电路，故

\[
\operatorname{CC}(G(z))\le a(N).
\]

所有 PRG 输出因而都是 Gap-MCSP 的 YES instances。

令

\[
b(N):=2^{(\log N)^{2/3}}.
\]

大小至多 \(b\) 的电路总数至多

\[
2^{O(b\log b)}=2^{o(N)}.
\]

所以均匀随机 \(N\)-bit 真值表以概率 \(1-o(1)\) 是 NO instance。若某个 \(C\in\mathcal C\) 正确解决该 promise，则

\[
\Pr_z[C(G(z))=1]=1,
\qquad
\Pr_U[C(U)=1]=o(1),
\]

与 \(\varepsilon<1/3\) fooling 矛盾。因此

\[
\boxed{
\text{上述 local PRG}
\Longrightarrow
\operatorname{GapMCSP}[a,b]\notin\mathcal C.}
\]

取

\[
\mathcal C=
\operatorname{FORMULA}[N^{1.01}]
\circ\operatorname{XOR}
\]

即可精确触发 Frontier B。

~~~mermaid
flowchart LR
    A["Formula-XOR<br/>s=N^1.01"] --> P["现有 PRG"]
    P --> L["local output complexity<br/>N^0.505+o(1)"]
    L --> M["标准 MCSP<br/>threshold N^Ω(1)"]
    T["Magnification"] --> U["Gap-MCSP YES threshold<br/>2^((log N)^(1/3))"]
    M -. "不覆盖" .-> U
~~~

## 五、主线重定位

仿射-profile 正规化已经解决，不再是主障碍。当前最薄、直接连接 magnification 的命题是：

\[
\boxed{
\begin{array}{l}
\text{构造 fool }\operatorname{FORMULA}[N^{1+\varepsilon}]
\circ\operatorname{XOR}\text{ 的 local PRG，}\\
\text{其每个输出位由至多 }
2^{(\log N)^{1/3}}
\text{ 规模电路计算。}
\end{array}}
\]

等价地，需要打破现有

\[
\text{outer formula size }s
\longmapsto
\widetilde\Theta(\sqrt s)
\]

的 locality 开销，一直降到 \(2^{(\log N)^{1/3}}\)，而不仅是缩短全局 seed。

这一路线一旦在 \(s=N^{1.01}\) 达成，即把 Formula-XOR 的已知下界机制推入 Frontier B 的精确 MCSP 阈值区；结合已有 hardness magnification 将给出相应复杂度分离。

## 能推出什么

- 可达仿射 profile 的依赖可用 \(O(Sr^2)\) 开销完全消除；
- \(r=O(\log S)\) 的完整语义规范化可显式完成；
- 任意秩的完全 canonical 化至少 coNP-hard；
- 现有 Formula-XOR MCSP 下界与 magnification 的精确断点是 local output complexity。

## 不能推出什么

- 未构造 \(2^{(\log N)^{1/3}}\)-local PRG；
- 未证明 \(\widetilde\Theta(\sqrt s)\) locality 是必要的；
- 未得到 Frontier B 的 \(N^{1.01}\) 下界；
- 未解决 \(P\) 与 \(NP\)。

## 原始来源

- Kabanets, Koroth, Lu, Myrisiotis and Oliveira, *Algorithms and Lower Bounds for De Morgan Formulas of Low-Communication Leaf Gates*, CCC 2020, DOI: 10.4230/LIPIcs.CCC.2020.15，尤其 Theorems 33–34。
- Chen, Hirahara, Oliveira, Pich, Rajgopal and Santhanam, *Beyond Natural Proofs: Hardness Magnification and Locality*, ITCS 2020, DOI: 10.4230/LIPIcs.ITCS.2020.70，尤其 Frontier B。
