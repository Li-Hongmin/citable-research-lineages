> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Adaptive short-oracle transcript boundary (2026-08-24)

## Theorem

Let \(A_n=\mathcal L_{\mu_H,n}\) with source length \(N=2^n\). Let \(M_n^O\) be a fixed
finite-control oracle RTM with one-way read-only source input, running for
\[
t=N^{b+o(1)}
\]
steps, where \(t\) is padded to at least \(N\). Queries to one fixed bit-answer oracle
\(O\subseteq\{0,1\}^\ast\) may be adaptive, but every query has length at most
\[
\ell=N^{\delta+o(1)}.
\]
If \(M_n^O\) decides \(A_n\) exactly or with fixed bounded error, then
\[
\boxed{\max\{1,b\}+2\delta\ge 2\mu_H.}
\]

The query count is not an extra parameter: it is at most \(t\). A finite family of fixed
relations is encoded into one oracle with a constant tag. A uniform \(n\)-indexed family can
include a binary encoding of \(n\), which changes query length only by \(O(\log n)\). If only
the total queried length
\[
L=\sum_i |q_i|=N^{\delta_{\mathrm{tot}}+o(1)}
\]
is known, then \(\delta\le\delta_{\mathrm{tot}}\) gives the weaker but valid
\(\max\{1,b\}+2\delta_{\mathrm{tot}}\ge2\mu_H\). The sharp interface parameter supplied by the
oracle PRG is the maximum query length.

## Proof

Set \(\beta=\max\{1,b\}\). CHMY's oracle-RTM local-PRG result (Lemma 22 and the oracle
corollary; Corollary 23 in the published STACS numbering and Corollary 22 in the ECCC
version) applies to adaptive queries. For constant fooling error and \(O(1)\) finite control,
the seed length is
\[
\widetilde O\!\left((\sqrt t+O(1))\log(q\,2^\ell t)\right)
=N^{\beta/2+\delta+o(1)},
\]
since \(q=O(1)\) and \(\log(q2^\ell t)=\ell+O(\log t)\).

CHMY's locality statement, used in their MCSP lower-bound argument, makes each generated
\(N\)-bit table computable by a circuit of size
\[
N^{\beta/2+\delta+o(1)}.
\]
If \(\beta/2+\delta<\mu_H\), every generator output belongs to \(A_n\). A uniformly random
source table belongs to \(A_n\) with probability \(o(1)\), by circuit enumeration. The machine
therefore distinguishes the generator from uniform by a constant gap, contradicting the local-PRG
fooling guarantee. Thus \(\beta/2+\delta\ge\mu_H\).

## Static random-access specialization

Let \(N'=N^{\kappa+o(1)}\) and write \(B_{n',T}=\mathcal L_{n',T}\) for the target-YES
set. Suppose \(G_n\) writes a descriptor \(d_n(f)\) of length \(N^{\delta+o(1)}\) in
\(N^{b+o(1)}\) steps, and a fixed uniform evaluator \(E(n,d,i)\) returns the \(i\)-th bit of a
target table. If
\[
f\in A_n
\quad\Longleftrightarrow\quad
\bigl(E(n,d_n(f),0),\ldots,E(n,d_n(f),N'-1)\bigr)\in B_{n',T},
\]
define one fixed relation
\[
R(\langle n,d\rangle)=1
\quad\Longleftrightarrow\quad
\bigl(E(n,d,0),\ldots,E(n,d,N'-1)\bigr)\in B_{n',T}.
\]
The query \(\langle n,d_n(f)\rangle\) has the same \(N\)-exponent as \(d_n(f)\), since the
binary prefix \(n\) has length \(O(\log n)\). Thus a single oracle query decides \(A_n\), so
the same boundary follows. The evaluator may be arbitrarily slow or computationally strong
because it has been absorbed into the fixed oracle relation; this is precisely why the descriptor
must be membership-sufficient.

This specialization does not cover an evaluator that reads the source table, accesses an
uncharged RAM, depends on the particular source instance, or receives an unbounded multi-bit
answer at zero cost. Such interfaces hide an oracle or leave the standard CHMY oracle-RTM model.
Bit-serializing a multi-bit answer charges its length to the time and restores the stated model.

## Consequence

The single-query descriptor boundary is therefore not the true limit of the short-query method:
all adaptive fixed-oracle transcripts with short maximum queries are excluded in the same
\(2\mu_H\) exponent. The remaining general case is an implicit/random-access quotient without a
fixed membership-sufficient oracle relation or without a complete static descriptor; this note
does not claim a lower bound for that broader semantic interface.

## Source

Cheraghchi, Hirahara, Myrisiotis, and Yoshida, *One-Tape Turing Machine and Branching Program
Lower Bounds for MCSP*, STACS 2021, Lemma 22 and the oracle local-PRG corollary,
DOI: [10.4230/LIPIcs.STACS.2021.23](https://doi.org/10.4230/LIPIcs.STACS.2021.23).
