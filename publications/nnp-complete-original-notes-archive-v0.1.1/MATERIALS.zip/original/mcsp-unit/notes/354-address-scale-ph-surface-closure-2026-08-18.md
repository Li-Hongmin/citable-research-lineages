> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Address-scale PH surface closure for per-address strategies

## Contribution

Note 353 charged an address-dependent strategy whenever its joint
address--randomness acceptance surface had a small Boolean circuit.  The
remaining apparent loophole is to describe that surface by a fixed-depth
polynomial-hierarchy predicate, while allowing an unrelated finite strategy
for every address.  At the address scale this loophole also closes
conditionally: under \(P=NP\), a uniform fixed-depth PH surface collapses to
an address-scale polynomial-time evaluator, and the same sampling argument
reconstructs the forced table.

The essential word is **surface**.  A collection of statements
\(\forall a\,\exists \mathcal S_a\) does not by itself define a single-valued
Boolean surface; different addresses may use incompatible witnesses.  The
theorem below assumes that the selected acceptance bit is already a
single-valued PH predicate.

## Theorem (address-scale PH-surface closure)

Let \(H_n\in\{0,1\}^{N_n}\), let
\(\ell_n=\lceil\log_2(N_n+1)\rceil\), and let \(R\) be a public random tape.
For every valid address \(a\in[N_n]\), an arbitrary finite response strategy
\(\mathcal S_{n,a}\) may be used.  Suppose there is one uniform Boolean
surface
\[
  W(1^n,a,R)\in\{0,1\}
\]
with the following properties:

1. \(W\) is in a fixed level of \(\mathrm{PH}\), with a fixed number of
   quantifier blocks;
2. the address, random tape, quantified strings, and matrix computation all
   have length and running time \(n^{O(1)}\);
3. \(W(1^n,a,R)\) equals the verifier acceptance bit on the fixed target
   proof when \(\mathcal S_{n,a}\) is selected.

Assume constants \(\alpha>\beta\) and
\(\gamma=\alpha-\beta>0\) satisfy
\[
  H_n[a]=1\Longrightarrow
  \Pr_R[W(1^n,a,R)=1]\ge\alpha,\qquad
  H_n[a]=0\Longrightarrow
  \Pr_R[W(1^n,a,R)=1]\le\beta .
\tag{354.1}
\]

If \(P=NP\), then
\[
  \operatorname{CC}(H_n)=n^{O(1)} .
\tag{354.2}
\]
Consequently, if on an infinite set of lengths
\[
  \operatorname{CC}(H_n)>n^c
  \quad\text{for every fixed }c>0,
\tag{354.3}
\]
then the existence of the uniform address-scale PH surface implies
\[
  P\ne NP.
\tag{354.4}
\]

In particular, if \(N_n=2^{\Omega(n^\eta)}\) for some \(\eta>0\) and the
forcing threshold is \(N_n/\operatorname{polylog}N_n\), then (354.3) holds.

## Proof

For fixed \(n\), \(P=NP\) implies \(\mathrm{PH}=P\).  Hence the fixed PH
predicate \(W(1^n,a,R)\) is evaluated by a uniform deterministic machine in
time \(n^{O(1)}\), and therefore by a fan-in-two circuit of size \(n^{O(1)}\)
on the address and random-tape inputs.

Choose
\[
  t_n=
  O\!\left(\frac{\ell_n+\log(1/\delta+2)}{\gamma^2}\right)
\tag{354.5}
\]
independent public tapes.  Hoeffding's inequality and a union bound over at
most \(2^{\ell_n}\) valid addresses give a fixed multiset of tapes for which
every empirical acceptance rate is within \(\gamma/3\) of its expectation,
with failure probability at most \(\delta\).  Hardwire this multiset into a
circuit, evaluate the \(t_n\) copies of \(W\), and threshold the empirical
average at \((\alpha+\beta)/2\).  This circuit computes \(H_n\) and has size
\[
  O\!\left(t_n\bigl(n^{O(1)}+\log(t_n+2)\bigr)\right)
  =n^{O(1)},
\tag{354.6}
\]
because \(\ell_n\le n^{O(1)}\) by the address-scale hypothesis.  This proves
(354.2), and (354.3) then contradicts \(P=NP\).

\(\square\)

## What the theorem does and does not assume

The strategies \(\mathcal S_{n,a}\) need not be shared, and the theorem does
not require a family-level code or an RLDC reduction.  It only requires that
their selected acceptance bits admit one fixed-depth, single-valued PH
surface at address scale.  A relation of the form
\[
  \forall a\,\exists \mathcal S_a
\]
is insufficient: the existential choices may be inconsistent across
addresses, and replacing them by one PH predicate would be an additional
word-consistency theorem.

The result also does not apply when a quantified response, random-access
descriptor, or proof history has length \(2^{\Omega(n)}\), when the PH depth
grows with \(n\), when the gap \(\gamma\) vanishes, or when the surface is not
Boolean/single-valued.  Those are genuine model exits rather than hidden
consequences of \(P=NP\).

For an unconditional version, replace the PH assumption by an explicit
address-scale \(P\)-time surface evaluator; then (354.2) holds without
assuming \(P=NP\).  The PH formulation is the useful RW interface: it turns
the final collapse into a precise conditional theorem while permitting
address-dependent strategies.

## The published RW scale boundary

The proposition does not silently assert that the published RW Reconf
object already supplies its PH surface. In Theorem 4.1, the final query can
use a Merlin circuit witness of size
\[
  k'=O\!\left(k^4\log(t+2)\right).
\tag{354.7}
\]
At a stable RW stage, the forced \(2n_i\)-bit table has address length
\(\ell_i=\lceil\log_2(2n_i)\rceil=\Theta(\log n_i)\), whereas the next
decoder width is \(k=n_{i+1}=n_i^C=2^{\Theta(\ell_i)}\). Thus a direct
translation of the published Reconf verifier has quantified strings and
circuit descriptions at object scale \(k'\), not at the \(\ell_i^{O(1)}\)
address scale required in (354.1).

The collapse \(P=NP\) (and hence \(\mathrm{PH}=P\)) only simplifies a
predicate at the scale at which its quantified strings and matrix are given;
it does not compress a \(k'\)-bit witness to a polynomial-size
\(\ell_i\)-address evaluator. Consequently, the missing RW interface is
precisely a single-valued, fixed-depth PH surface whose every quantified
string, random tape, and matrix is polynomial in the base/address parameter.
Proving such a compression, or proving that it must incur object-scale cost,
is a separate theorem. C354 is conditional on that interface and makes no
stronger claim about the currently published Reconf construction.

### Quantifier-length cost corollary

The address-scale hypothesis can be weakened to a quantitative statement.  Suppose the
surface is written as a fixed-depth PH predicate
\[
  W(1^n,\sigma_n,a,R),
\]
where \(\sigma_n\) is a length-\(d_n\) descriptor (possibly nonuniform advice), and let
\(L_n\) upper-bound the total length of the address, random tape, descriptor, all quantified
strings, and the matrix description.  For this fixed PH surface, assume the deterministic
algorithm supplied by \(P=NP\) has running time \(L^{c_*}\) on total input length \(L\),
for a constant \(c_*\) independent of \(n\).  Then the sampling proof gives
\[
  P=NP\quad\Longrightarrow\quad
  \operatorname{CC}(H_n)
  \le
  O\!\left(t_n\bigl(L_n^{c_*}+\log(t_n+2)\bigr)\right),
\tag{354.8}
\]
with \(t_n\) as in (354.5).  Consequently, if the forcing lower bound is
\(\operatorname{CC}(H_n)>S_n\), then
\[
  P\ne NP
  \quad\text{or}\quad
  L_n=\Omega\!\left(
    \left(\frac{S_n}{t_n}\right)^{1/c_*}
  \right)
\tag{354.9}
\]
along the relevant lengths (up to the harmless counter/comparator term).

This is the precise form of the scale boundary.  If \(S_n=2^{\Omega(\ell_n)}\) and
\(t_n=\operatorname{poly}(\ell_n)\), then under \(P=NP\) the PH surface must itself have
input/quantifier/matrix scale \(2^{\Omega(\ell_n)}\); allowing a quantified witness or a
descriptor does not make an object-scale representation address-scale.  The corollary is
not an unconditional lower bound on PH predicates: it is a forcing-conditioned trichotomy
between \(P\ne NP\) and an explicitly charged object-scale surface.

## Relation to the closure program

* Note 353 gives the unconditional Boolean-surface sampling bound, with no
  common strategy.
* The present theorem upgrades the evaluator hypothesis from a small Boolean
  circuit to a fixed-depth PH description at the base/address scale.
* It is stronger than a common-strategy smart query, but weaker than the
  unproved claim that the published RW Reconf object has such a surface.
* It remains a single-table closure theorem.  It is not a general dPCP
  impossibility theorem, an RLDC lower bound, or an unconditional \(P\ne NP\)
  proof.

Thus the remaining RW escape is now sharply stated: either the acceptance
surface has object-scale Boolean/quantified state, its quantifier depth or
response alphabet leaves the fixed address-scale PH model, or the proposed
physicalization fails to define a single-valued target-relative surface.

## Sources

* [Address-surface closure](353-address-surface-closure-for-per-address-strategies-2026-08-18.md).
* [RW succinct smart reconstruction closure theorem](204-rw-succinct-smart-reconstruction-closure-theorem-2026-08-17.md).
* Ren--Williams, *Range Avoidance and \(E^{\mathrm{prMA}}/1\)*, Theorem 4.1:
  <https://eccc.weizmann.ac.il/report/2026/118/>.
