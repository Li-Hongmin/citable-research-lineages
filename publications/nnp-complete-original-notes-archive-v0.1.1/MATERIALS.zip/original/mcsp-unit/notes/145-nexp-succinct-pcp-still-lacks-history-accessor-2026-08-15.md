> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# NEXP 的 succinct constant-query PCP 已存在，但仍不提供 RW history accessor（2026-08-15）

## 先修正路线判断

上一条路线边界需要精化。并非“已有工作都没有 succinct PCP”：Gur--O'Connor--Spooner
给出了一个真正针对 NEXP 的 succinct PCP 构造。准确的结论是

\[
\text{succinct NEXP verifier}
\;\not\Rightarrow\;
\text{canonical history/proof accessor}.
\]

这一区分会改变后续搜索重点：不再寻找另一个 generic succinct PCP，而是直接研究
隐式见证表到固定 proof block 的规范化接口。

## 文献中的正面定理

论文先定义 Oracle-3SAT。给定一个小的布尔公式 \(B\)，存在一个隐式见证表

\[
A:\{0,1\}^{s}\longrightarrow\{0,1\},
\]

要求对所有地址 \(z,b_1,b_2,b_3\) 都有

\[
B\!\left(z,b_1,b_2,b_3,
 A(b_1),A(b_2),A(b_3)\right)=1.
\tag{1}
\]

这正是把指数长度见证写成一个小描述、可局部查询的 oracle relation。

其 Theorem 6.2 对任意 \(T(n)\)-时间非确定性机器给出 Cook--Levin reduction
\(R_M(x,T)\)，满足：

\[
R_M(x,T)\in\mathrm{Oracle\text{-}3SAT}
\iff
\exists w\;M(x,w)=1,
\]

而 \(R_M(x,T)\) 是一个只含 \(O(\log T(n))\) 个变量、大小
\(\operatorname{poly}(n,\log T(n))\) 的公式。于是当
\(T=2^{n^\eta}\) 时，指数长度历史/见证的**约束描述**确实保持在
\(\operatorname{poly}(n)\) 规模。

Theorem 6.3(ii) 再给出 NEXP 的 robust PZK-PCP 参数；Theorem 7.1(ii) 总结为

\[
\mathrm{NEXP}\subseteq \mathrm{PZK\text{-}PCP}[\operatorname{poly}(n),1].
\tag{2}
\]

也就是说，证明长度为指数级，验证器使用 \(\operatorname{poly}(n)\) 随机位，却只读
常数个 proof symbols。这是本项目目前找到的最接近“succinct history verification”
的原始结果。

## 它真正提供了什么

对 \(T=2^{n^\eta}\) 的计算，(1) 可把局部 transition constraints 变成一个
poly\((n)\)-size 的公式；(2) 则提供一个 poly\((n)\)-time verifier 的 constant-query
检查层。因此，RW/JK 路线不必再证明一个全新的 generic succinct PCP theorem。

更具体地说，若把真实历史写成隐式见证表 \(A_H\)，则 PCP verifier 可以随机抽查由
\(B\) 指定的局部关系。这里的随机性和查询位置由 \(x\)、公式和随机串决定，而不是由
指数长度公式本身逐项展开。

## 低度多项式也没有把 proof 压成 \(n^{O(1)}\) seed

Construction 6.4 用一个多项式 \(\widehat C\) 隐藏见证 \(A\)，并把它的**完整评价表**
\(\pi_C\) 放进 proof；它满足

\[
  \sum_{c\in H^k}\widehat C(b,c)=A(\gamma_2(b)).
\tag{2a}
\]

对本项目要编码的 \(T\)-步 history，见证地址宽度取
\(s=\Theta(\log T)\)；在这一参数区间，
\(m_2=s/\log |H|\)，而 \(\widehat C\) 的每变量次数为
\(O(|H|)\)，其中 \(|H|=\Theta(\log T)\)。因此其完整系数向量有

\[
  (O(|H|))^{m_2+k}
  =
  2^{\Theta\!\left(
       \frac{\log T}{\log\log T}\log\log T
     \right)}
  =
  T^{\Theta(1)}
\tag{2b}
\]

个系数槽位；按完整系数向量存储时是 \(T^{\Theta(1)}\) 量级（常数和 \(k\)
不改变该尺度）。所以“\(\widehat C\) 是低度多项式”只说明 verifier 可以局部评价
一个**已给定的 polynomial oracle**；它没有给出 \(\operatorname{poly}(n)\)-bit
的 canonical history/proof seed。对没有另一个短描述的 \(A=A_H\)，构造仍需承载
指数长度的信息；这里是对该构造的表示规模诊断，不是任意多项式表示的下界。

## 仍缺的不是 verifier，而是 proof oracle 的值

PCP 定义中的 proof 是 oracle \(\pi\)。定理保证：

\[
x\in L
\Longrightarrow
\exists\pi\quad
\Pr_\rho[V^\pi(x;\rho)=1]=1,
\]

但没有给出一个

\[
(x,\alpha)\longmapsto \pi_x[\alpha]
\tag{3}
\]

的 \(n^{O(1)}\)-size、确定、canonical 电路。对 NEXP 来说，\(A_H\) 本身就是
指数长度对象；把它写进 proof 或低度扩展，并不等于能从 \((x,\alpha)\) 在地址尺度
计算出对应 symbol。

论文的 Definition 3.1 所称 locally computable proof 也不是 (3)：它说的是存在一个
高效 oracle 算法 \(f\)，用至多 \(\ell\) 个**已有 proof oracle 查询**来生成另一个
proof 的 symbol。组合、alphabet reduction 等步骤因此不会破坏零知识，但 \(f\) 仍然
依赖底层 \(\pi_0\)，没有把 oracle 替换成短 seed 或 canonical selector。

## 一个清晰的复杂度分界

设某个 NEXP-complete 语言有 verifier \(V\)，随机位数为 \(r(n)\)，且存在对所有输入
都定义的 uniform deterministic accessor \(A(x,\alpha)=\pi_x[\alpha]\)，其中
\(\pi_x\) 在 yes-instance 上是一个完备 proof。则：

- 若 \(r(n)=O(\log n)\)，枚举所有随机串并运行 \(V\)，得到
  \(\mathrm{NEXP}\subseteq\mathrm P\)；
- 若 \(r(n)=\operatorname{poly}(n)\)，随机抽样运行 \(V\)，得到
  \(\mathrm{NEXP}\subseteq\mathrm{BPP}\)。

因此，对所有 NEXP 输入都给出 canonical proof accessor 已经是一个极强的额外结论，
不能从“查询数为常数”直接推出。对本项目的单一 fixed history，这个复杂度推论不自动
适用；但它说明为什么真正需要的是 history-specific、无隐式 witness advice 的构造。

## 对 RW/JK 的精确接口

Gur--O'Connor--Spooner 结果把目标压缩为以下三个独立条件：

1. **succinct constraint layer**：由 Theorem 6.2 得到 \(B_H\)；
2. **constant-query verifier layer**：由 Theorem 7.1 得到 (2)；
3. **canonical block layer**：仍需构造
   \[
   A_H(i,\ell)=\pi_H[\text{block }i,\ell]
   \]
   以及一个 word-consistent 的 \(q\)-bit normalized right inverse。

前两层已有正面文献支持，第三层仍是本项目的未解接口。若第三层只对一个 fixed
history 成立，不能把它泛化为 NEXP 的 uniform proof generator；若它对所有 NEXP
输入成立，则会触发上面的 P/BPP 复杂度后果。

因此当前最窄、最有价值的实验是：固定 \(B_H\)，研究其隐式见证表 \(A_H\) 的某个
canonical proof block 是否存在 \(q\)-bit decoder，而不是继续优化 generic PCP 的
query composition。

## 结论

\[
\boxed{
\begin{array}{c}
\text{Oracle-3SAT + NEXP constant-query PCP}\\
\text{解决了 succinct verification}\\
\text{但没有解决 canonical history/proof access}
\end{array}
}
\]

这是一条真实的正向进展，但不推出 \(P\ne NP\)。它把 RW/JK 的剩余问题从
“有没有 succinct PCP”缩窄为“能否对一个具体隐式历史构造 canonical whole-word
proof accessor，并保持下一层 decoder closure”。

## 来源

- Tom Gur, Jack O'Connor, Nicholas Spooner, *A Zero-Knowledge PCP Theorem*,
  arXiv:2411.07972：
  [paper page](https://arxiv.org/abs/2411.07972)；
  [full PDF text](https://api.repository.cam.ac.uk/server/api/core/bitstreams/[private coordination reference omitted]/content)。
  关键位置：Theorem 6.2（succinct Oracle-3SAT Cook--Levin）、Theorems 6.3/7.1
  （NEXP robust/constant-query PCP）、Definition 3.1（locally computable proofs）。
