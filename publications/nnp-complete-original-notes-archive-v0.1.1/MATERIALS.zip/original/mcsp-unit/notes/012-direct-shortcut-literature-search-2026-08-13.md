> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 直接捷径检索：Formula--XOR / MCSP (2026	ext{-}08	ext{-}13)

## 决策问题

是否已有近期定理直接给出

\[
\operatorname{GapMCSP}
\left[2^{(\log N)^{1/3}},2^{(\log N)^{2/3}}\right]
\notin \operatorname{Formula\mbox{-}XOR}[N^{1.01}],
\]

或通过 DNF-of-parities、local PRG、平均情形 MCSP、XOR-simple-extension、communication lifting 绕开该缺口？

检索边界：原始论文与作者/会议版本，覆盖 2020--2026；搜索日期 2026-08-13。

## 结果

| 路线 | 原始结果 | 参数 | 接入裁决 |
|---|---|---|---|
| local PRG | Kabanets–Koroth–Lu–Myrisiotis–Oliveira, CCC 2020, Thm. 33--34 | seed (O(\sqrt{s}\log s\log(1/\varepsilon)+\log N))，local output 同阶；推出标准 MCSP (\notin\mathrm{Formula}[\widetilde\Omega(N^2)]\circ\mathrm{XOR}) | 高阈值 MCSP 的 YES 输出复杂度约 (N^{0.505+o(1)})（(s=N^{1.01})），大于 Frontier B 的 (2^{(\log N)^{1/3}})，不能拼接 |
| locality barrier / 结构化归约 | Chen–Hirahara–Oliveira–Pich–Rajgopal–Santhanam, ITCS 2020, Prop. 43 | Frontier B 可被 (N^{1.01})-size Formula-O-XOR 表示，oracle fan-in (N^\varepsilon)；InnerProduct 下界也扩展到该模型 | 排除从 InnerProduct 通过局部/结构化归约直接得到目标下界 |
| DNF-of-parities 之后 | Riazanov–Sofronova–Sokolov, ITCS 2026, Thm. 4 及 §3 | (\mathrm{Or}\circ(\Pi^0\circ\mathbb B)) 中 (n^{1/3-o(1)})-affine disperser 需指数大小；Mid 需 (2^{\Omega(\sqrt n)})，IP 指数 | 深度受限且弱于一般 Formula-XOR；论文明确更强 (\vee\circ\wedge\circ\vee\circ\mathrm{XOR}) 需两个 oblivious steps，正是未解决量词障碍 |
| XOR-simple-extension | Carmosino–Dang–Jackman, STACS 2026 | XOR 最优电路为 (n-1) 个 XOR2 的二叉树；XOR-SEP (\in\mathrm P) | 直接关闭“用 XOR-SEP 推 total MCSP ETH-hardness”的捷径；候选转向 MUX |
| 平均情形 MCSP | Ilango–Ren–Santhanam, STOC 2022, Thm. 2.1 | OWF (\Longleftrightarrow\) 存在 (n^\delta)-local sampler 使 (\mathrm{GapMCSP}[s,sn^{5\delta}]) 平均困难；强版 (\mathrm{GapMCSP}[n^\delta,o(n\log n)]) | 是平均情形/密码学等价，不是 nonuniform Formula-XOR 最坏情形下界；不能直接反证任意非一致公式 |
| oracle / multivalued MCSP | Huang–Ilango–Ren, SICOMP 2025；Ilango, ECCC TR23-165 rev.1 | minimum oracle circuit size 近最优 NP-hard 近似；随机 oracle 下 (\mathrm{mvMCSP}^O) 准多项式 NP-hard | relativized/oracle 结论，不能推出标准 MCSP 或 (P\ne NP) |
| 条件普通 MCSP 归约 | Hirahara–Ilango, FOCS 2025, DOI 10.1109/FOCS63196.2025.00087 | 在 subexponentially-secure NIWI 等假设下，MCSP 对确定性拟多项式非自适应归约 NP-hard | 条件且归约模型远弱于 Formula-XOR 下界；不提供无条件 (N^{1.01}) 结论 |
| ImpMCSP / Total-Learn | Goldberg–Juvekar–Kabanets, ECCC TR26-091 (2026) | 在 iO 与 proof-complexity 假设下，Gap-ImpMCSP/全支持学习对 randomized half-Levin reductions NP-hard，并排除 randomized Levin reductions | 输入是采样器的隐式函数，不是显式真值表 MCSP；不能直接接入本项目 |
| communication / parity lifting | Podolskii–Shekhovtsov, ITCS 2025 | linear diversity (k\Rightarrow\Omega(\log k)) 的 decision-tree→parity-tree/半结构通信 lifting | 不直接产生 Formula-XOR 下界；可作为 affine-leaf 递归协议的候选技术接口 |
| KW 强组合 | Chukhin–Kulikov–Mihajlin, arXiv:2410.10189 | 随机 (f) 的 (\mathrm{KW}_{\mathrm{XOR}}\star\mathrm{KW}_f) 需 (n^{3-o(1)}) leaves | 强组合不直接蕴含标准 Formula depth/MCSP；仅邻近启发 |

## 结论

\[
\boxed{\text{截至检索日，没有已知直接捷径。}}
\]

最可接入的不是新的 MCSP 下界，而是把 ITCS 2025 的 parity-tree/communication lifting 接到当前
\(\mathrm{QA}(T)=\mathrm{CP}(T)\) 的 affine-leaf 递归协议，检验能否控制
\[
\text{leaf affine information}\;+
\text{recursive collision profile}
\]
而非只用叶子仿射维数。若失败，则 local PRG 的输出复杂度缺口仍是硬边界。

## 来源

- [Kabanets et al., CCC 2020](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.CCC.2020.15)
- [Chen et al., Beyond Natural Proofs, ITCS 2020](https://doi.org/10.4230/LIPIcs.ITCS.2020.70)
- [Riazanov–Sofronova–Sokolov, ITCS 2026](https://doi.org/10.4230/LIPIcs.ITCS.2026.112)
- [Carmosino–Dang–Jackman, STACS 2026](https://doi.org/10.4230/LIPIcs.STACS.2026.23)
- [Ilango–Ren–Santhanam, STOC 2022](https://doi.org/10.1145/3519935.3520051)
- [Huang–Ilango–Ren, SICOMP 2025](https://doi.org/10.1137/23M1608483)
- [Ilango, ECCC TR23-165 revision 1](https://eccc.weizmann.ac.il/report/2023/165/)
- [Hirahara–Ilango, FOCS 2025](https://www.rahulilango.com/papers/MCSP-Proceedings-2025.pdf)
- [Goldberg–Juvekar–Kabanets, ECCC TR26-091](https://eccc.weizmann.ac.il/report/2026/091/)
- [Podolskii–Shekhovtsov, ITCS 2025](https://doi.org/10.4230/LIPIcs.ITCS.2025.78)
- [Chukhin–Kulikov–Mihajlin, arXiv:2410.10189](https://arxiv.org/abs/2410.10189)
