> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Uniform projection quantifier barrier for the RW singleton compiler (2026-08-18)

## Decision

GMWZ Section 6 does close its cluster list to one decoded word when its input
language has a singleton valid-word family.  That observation does not remove the
RW private-witness problem.  For a relation

\[
R(x,y,w),
\qquad
L_x=\{y:\exists w\;R(x,y,w)\},
\]

the apparently innocuous preprocessing step

\[
\widehat\phi_x(y)=1\quad\Longleftrightarrow\quad
\exists w\;R(x,y,w)
\tag{368.1}
\]

is already an existential projection of the NP relation.  A uniform small-circuit
construction of (368.1) would itself have a major complexity consequence; a
per-instance circuit does not automatically give a uniform shared dPCP or an
address-scale RW evaluator.  Thus “apply GMWZ to \(\widehat\phi_x\)” is not a
free singleton-output compiler.

## Quantifier-separated proposition

Let \(R(x,w)\) be a polynomial-time verifier for an NP language
\[
L=\{x:\exists w\;R(x,w)\}.
\]

Consider the dummy-output projection
\[
\widehat\phi_x(b)=1
\quad\Longleftrightarrow\quad
 b=1\ \wedge\ \exists w\;R(x,w).
\tag{368.2}
\]

The following three regimes are distinct.

1. If one uniform polynomial-time procedure maps \(x\) to a circuit
   \(\widehat\phi_x\) of size \(|x|^{O(1)}\) satisfying (368.2), then
   \(L\in P\): construct the circuit and evaluate it at \(b=1\).

2. If there is only one joint nonuniform family of circuits
   \(\widehat\Phi_n(x,b)\) of size \(n^{O(1)}\) satisfying
   \(\widehat\Phi_n(x,b)=1\iff b=1\wedge\exists w\,R(x,w)\) for all
   \(|x|=n\), then \(L\in P/\mathrm{poly}\).

3. If for every individual \(x\) there merely exists a small circuit
   \(\widehat\phi_x(b)\), with no uniform generator and no joint circuit in \(x\),
   this statement alone gives no \(P\), \(P/\mathrm{poly}\), or dPCP construction.
   The circuit may encode information specific to that one instance and must be
   counted as a descriptor/key in any RW closure argument.

### Proof

For (1), the procedure constructs \(\widehat\phi_x\) in polynomial time and its
value at 1 is exactly the membership predicate for \(L\).  For (2), hardwire the
length-dependent advice defining \(\widehat\Phi_n\) and evaluate at the constant
second input \(b=1\); this gives a polynomial-size circuit for \(L\) at length \(n\).
The per-instance existence in (3) supplies only a separate one-input circuit for
each \(x\), which cannot be assembled into a circuit over all \(x\) without an
additional uniformity or joint-family hypothesis.  \(\square\)

The same distinction applies to a multi-bit output relation.  A circuit deciding
(368.1) for a fixed \(x\) is not yet a procedure for finding the unique \(y_x\):
one additionally needs a uniform prefix/projection interface, or an address-scale
way to evaluate the output relation.  This is exactly the target-output projection
obligation, not a consequence of GMWZ list soundness.

## Consequence for GMWZ-to-RW composition

GMWZ Theorem 6.1 takes an explicit circuit \(\phi\) and applies its singleton
specialization only after the valid-word language has already been fixed.  Setting
\(\phi=\widehat\phi_x\) therefore has one of the following meanings:

* in the uniform case, the NP projection has already been decided in polynomial time;
* in the joint nonuniform case, the projection circuit is a polynomial advice object
  and must be charged in the static-package/descriptor accounting;
* in the per-instance case, the result is not a uniform common proof/address-space
  compiler and cannot be used for the RW forcing family.

Alternatively, feeding GMWZ the explicit pair word \((y,w)\) avoids (368.1), but
then the valid words need not have a singleton output projection.  Different local
clusters can use different witnesses, and the published list endpoint does not
provide the required \(\exists w\,\forall i\) selector for the same output word.

Consequently the exact positive target remains a **hidden-witness target-output
projection compiler**: one common proof, one address space, a singleton (or
injectively separated short-fingerprint) public output, target-relative soundness,
and address-scale generation.  The GMWZ singleton-language corollary removes only
the cross-cluster synchronization subproblem after this compiler exists.

## Scope and relation to existing gates

This note sharpens the boundary already isolated in the private-witness projection
barrier and the GMWZ singleton-language closure.  It corrects a common quantifier
slippage: “a small circuit exists for every fixed instance” is not the same as a
uniform or joint circuit family, and neither statement by itself supplies a shared
RW proof.  It does not prove a lower bound against all relation-PCPPs, does not
prove that GMWZ fails on every singleton relation, and does not imply
\(P\ne NP\).

The remaining decision is therefore binary and concrete:

* construct the hidden-witness target-output projection at near-linear/address
  scale; or
* prove a general cost theorem for that projection (descriptor entropy, proof
  length, locality, or a target-channel/RLDC payment).

## Sources

* [GMWZ singleton-language unique-decoding closure](209-gmwz-singleton-language-unique-decoding-closure-2026-08-17.md).
* [Private-witness projection barrier for singleton ACRR](177-private-witness-projection-barrier-for-singleton-acrr-2026-08-16.md).
* [Hidden-witness Skolemization and the Closure Gate](213-hidden-witness-skolemization-and-rldc-closure-gate-2026-08-17.md).
* [RW static-package Closure Theorem](364-rw-static-package-closure-theorem-2026-08-18.md).
