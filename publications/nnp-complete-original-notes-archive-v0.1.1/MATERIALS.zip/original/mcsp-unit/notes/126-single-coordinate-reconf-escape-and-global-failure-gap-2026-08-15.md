> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 单坐标 Reconf 可绕开输出长度，但需要全输入 failure（2026-08-15）

## 命题

采用 Ren--Williams Theorem 4.1。设
\[
f_n:\{0,1\}^{n}\to\{0,1\}^{t(n)}
\]
由固定 SAT-oracle machine 计算，\(G_n:\{0,1\}^{q(n)}\to\{0,1\}^{2q(n)}\)
是一个固定 AVOID 实例。取一个 P-uniform 可计算的输出坐标
\(i(n)\in[t(n)]\)，定义单坐标语言
\[
L_n(x):=f_n(x)_{i(n)}.
\]

假设对每个 \(x\in\{0,1\}^{n}\)，\(\operatorname{Solve}_f(x,G_n)\) 都没有成功输出
Range\((G_n)\) 外的字符串，而且实际 \(\operatorname{Reconf}(x,i(n))\) 查询
均为 smart-\(\mathrm{prMA}\) queries。则在 \(P=NP\) 假设下，存在固定 \(C\) 使
\[
\operatorname{CC}(L_n)
\le
\bigl(q(n)+r(n)+\log t(n)\bigr)^C.
\tag{1}
\]

因此，若 forcing 能同时给出
\[
\operatorname{CC}(L_n)>n^{k(n)},
\tag{2}
\]
则在 \(P=NP\) 下必有
\[
q(n)+r(n)+\log t(n)
=\Omega\!\left(n^{k(n)/C}\right).
\tag{3}
\]
特别地，若 \(r(n),\log t(n)\le q(n)^d\)，则
\[
q(n)=\Omega\!\left(n^{k(n)/(Cd)}\right)
\]
（调整固定常数后成立）。这里没有 \(t(n)\) 个输出电路的乘法。

## 证明

Theorem 4.1 的 \(\operatorname{Reconf}(x,i)\) 在给定 failure 分支时，运行时间和
query 描述长度为
\[
\operatorname{poly}(q,r,\log t).
\]
在 \(P=NP\) 假设下，\(PH=P\)，而每个实际 smart-\(\mathrm{prMA}\) query 的 YES
条件是固定 \(\Sigma_2^P\) 谓词
\[
\exists w\;\forall z\;B(w,z)=1.
\]
逐次确定化这些 oracle answers，就得到计算
\(x\mapsto f_n(x)_{i(n)}\) 的确定性电路，大小满足式 (1)。与式 (2) 比较得到式
(3)。证毕。

## 关键量词与真正缺口

Theorem 4.1 的原始结论是逐点的：
\[
\text{若给定 }(x,G_n)\text{ 处于 failure 分支，则 Reconf 正确输出 }f_n(x)_i.
\]
它**没有自动给出**
\[
\forall x\;\operatorname{Solve}_f(x,G_n)\text{ failure}.
\tag{4}
\]
若 (4) 只对一个 \(x\) 成立，只得到一个孤立输出位，不能组成 \(L_n\) 的统一电路；
若只对一部分 \(x\) 成立，也不能直接推出 \(L_n\) 的全局 circuit lower bound。

所以，单坐标路线比 note125 的 multi-output 路线少了 \(t(n)\) 因子，但必须补上
一个新的全局 forcing 结论：

\[
\boxed{
\text{存在统一 }G_n\text{，使所有输入 }x\text{ 同时落在 Reconf 的 failure 分支。}
}
\tag{5}
\]

另一种可能是：对某些 \(x\) 的 success 分支本身能产生统一可计算的 hard outsider，
并与 failure 分支拼成一个 P-uniform hard language；这需要额外的 choice-robust
selector，不能从 Theorem 4.1 的逐点语句直接推出。

## 与现有 q-scale 障碍的关系

式 (3) 说明，单坐标抽取确实绕开了 note125 中的 \(t\) 输出因子，但没有自动把
q-scale 变成 n-scale。note 121 的 Local-JK 接口仍需同时保证：

1. 同一个 \(G_n\) 对所有 \(x\) 的 failure/success 分支可统一处理；
2. 每个 query 的描述长度降到 \((n+k(n))^{O(1)}\)；
3. 失败分支的整词 preimage 与 choice-robust JK 保持一致。

Theorem 4.1 已提供 q-scale smart-\(\mathrm{prMA}\) Reconf，但没有提供式 (5) 或
上述 n-scale 压缩。[Ren--Williams 官方报告](https://eccc.weizmann.ac.uk/report/2026/118/revision/1/download)
只支持前一个 q-scale 事实。

本文给出的是一个可检验的单坐标充分接口与量词缺口，不声称已经证明
\(P\ne NP\)。
