> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW forcing-scale advice lower bound for address-scale reconstruction

## 结论

本 note 把 Closure Theorem 中的“no hidden advice”条件定量化到
RW/JK 的 forcing 尺度。结论只针对标准 fan-in-2 电路和有限静态
descriptor/ROM 模型；它不声称排除任意交互协议，也不声称现有 RW
history 已具有地址级 evaluator。

## 1. ROM-to-circuit lemma

令 \(H_n\in\{0,1\}^{N_n}\)，\(\ell_n=\lceil\log_2 N_n\rceil\)。假设一个
地址级重构器由以下对象组成：

* 一条长度 \(s_n\) 的静态 descriptor \(\sigma_n\)；
* 一个 fan-in-2 控制电路 \(E_n(a)\)，输入地址
  \(a\in\{0,1\}^{\ell_n}\)，大小至多 \(p_n\)；
* 在一次地址计算中至多 \(p_n\) 次对 \(\sigma_n\) 的 bit-read，read
  地址由 \(E_n\) 的中间值给出；
* 在相同的 \(E_n,\sigma_n\) 下，对所有地址输出同一个对象 \(H_n[a]\)。

在标准二进制多路复用实现中，存在绝对常数 \(c_0\) 使

\[
  \operatorname{CC}(H_n)
  \le c_0\bigl(p_n^2+p_ns_n+p_n\ell_n+1\bigr).
  \tag{220.1}
\]

证明是把每个 ROM read 展开成一个 \(s_n\)-输入 multiplexer；控制线路
复制至多 \(O(p_n^2)\)，地址输入与输出复用至多 \(O(p_n\ell_n)\)。这正是
标准 ROM-advice expansion；若一个实现把 multiplexer 当作 unit-cost
oracle，则 (220.1) 不适用，必须把该模型差异列为逃逸。

## 2. Forcing-scale descriptor theorem

设在同一无限长度集合 \(\mathcal N\) 上，RW/JK 的同一个 canonical object
满足

\[
  \operatorname{CC}(H_n)>S_n,
  \qquad n\in\mathcal N.
  \tag{220.2}
\]

若存在上述共同地址 evaluator，则由 (220.1) 得到必要条件

\[
  p_n^2+p_ns_n+p_n\ell_n+1
  > S_n/c_0.
  \tag{220.3}
\]

特别地，只要 \(p_n>0\)，

\[
  s_n
  >
  \frac{S_n/c_0-p_n^2-p_n\ell_n-1}{p_n}.
  \tag{220.4}
\]

这不是对某个 descriptor 选择的平均界，而是每一个满足同一 proof、同一
address space、同一静态 advice 语义的 evaluator 都必须支付的成本。

### RW 参数化推论

若对某个固定常数 \(c,b,d\) 有

\[
  p_n\le n^c,
  \qquad \ell_n\le n^b,
  \qquad s_n\le n^d,
  \qquad S_n\ge n^{k(n)},
  \tag{220.5}
\]

且 \(k(n)>\max\{2c,c+d,c+b\}+2\) 在无穷多个 \(n\) 上成立，则 (220.1)
给出

\[
  \operatorname{CC}(H_n)
  =O\!\left(n^{\max\{2c,c+d,c+b\}}\right)
  < n^{k(n)}\le S_n,
\]

与 (220.2) 矛盾。更精确地，在

\[
  k(n)>\max\{2c,c+b\}+2
\]

的长度上，任何 \(p_n\le n^c\) 的 evaluator 必须满足

\[
  s_n=\Omega\!\left(n^{k(n)-c}\right).
  \tag{220.6}
\]

因此当 RW forcing 指数 \(k(n)\to\infty\) 时，一个真正的地址尺度
\(n^{O(1)}\) evaluator 不能携带 \(n^{O(1)}\) 的 descriptor；它至少要把
接近 forcing scale 的信息放回静态 advice，除非它离开 ROM/finite-summary
模型。

## 3. 对 Closure Theorem 的含义

该推论把 C181 的 Gate-II 分成两个严格可检验的分支：

1. 若 descriptor、cover sheet、canonical key 和有限 strategy summary
   可以合并为 \(n^{O(1)}\) bits，且 evaluator/地址生成是 \(n^{O(1)}\)，
   则 (220.1) 直接与 forcing 冲突；这正是 C181 的
   \(P/\mathrm{poly}\) 终点，而非一个需要额外 entropy 论证的直觉。
2. 若仍要保留同一对象与地址级 evaluator，则 (220.6) 强迫 descriptor
   或 strategy summary 达到 \(n^{k(n)-O(1)}\)；这已经不是“隐藏少量
   history metadata”，而是 forcing-scale information。若该 descriptor
   同时对一个距离分离的完整 target family 可复用，则转入 C205/C204 的
   family--descriptor--RLDC 分支；若不可复用，就必须明确承认它是
   target-specific、超多项式 advice，而不是 RW 的 succinct closure。

这里没有把 \(p_n^2+p_ns_n\) 的代数下界冒充成一般 PCP/LDC 不可能性：它依赖
共同静态 descriptor、有限 read、标准 fan-in-2 expansion 和同一个对象的
全地址一致性。交互式 Merlin strategy 若不是由有限 summary 控制，或每个
地址使用独立 proof/address space，都不满足本命题假设；这些正是剩余研究
对象，而不是已被本 note 关闭的漏洞。

## 4. 与原始 RW Reconf 的尺度边界

原始 RW Reconf 在 \(k=n_{i+1}\) 尺度运行。若把它直接当成地址 evaluator，
则 \(p_n\) 至少按 \(n_{i+1}^{\Omega(1)}\) 计，而不是按
\(\log(2n_i)\) 计；它落在 C182 的 q-scale 分支，不能使用 (220.6) 得到
地址级矛盾。相反，本命题说明：一旦有人补上真正的
\(\operatorname{poly}(\log N_n)\)-或 \(n^{O(1)}\)-地址级压缩，且 descriptor
仍只有 \(n^{O(1)}\) bits，那么该补丁不再是“可能还要继续优化”的中间件，
而会立即触发 C181 的 forcing contradiction。

## 5. 状态

这是一条已证明的定量 closure barrier / escape-cost theorem。它没有证明
RW/JK 实际 canonical history 存在地址级 evaluator，因此不等于
\(P\ne NP\) 证明；它的贡献是把最终未知接口的 target-specific
descriptor 分支从“可能隐藏信息”收紧为 (220.4)--(220.6) 的 forcing-scale
下界，并与 C204/C205 的 family-level RLDC 分支形成互斥的下一步选择。
