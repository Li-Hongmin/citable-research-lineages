> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exposed-history PCPP + RLDC 基线与 ACRR 的真正压缩缺口（2026-08-16）

## 结论地位

本 note 给出一个严格的正向基线，但它**不**是 succinct ACRR，也不声称得到
`P != NP`。它证明：一旦允许把完整 computation history 作为 PCPP oracle/proof 的
显式部分，近线性 PCPP 与 RLDC 可以组合成同一个 proof address space 上的
coordinate-robust verifier。于是剩余问题不是“如何再设计一个坐标 decoder”，而是
如何在不暴露完整 history 的情况下实现同一 target-binding test。

这条组合的通用 PCPP+RLDC 变换并非本项目原创：其 pair-language 形式已由 Mie09 型
结果给出，并在 [Athamnah--Ron-Zewi--Rothblum, Appendix A, Lemma A.3](https://eccc.weizmann.ac.il/report/2025/090/download/)
中明确记账。本文的作用是把该已知变换按 RW/JK 的坐标 target 重新展开，并指出其
`n'`-长度编码通信正是 ACRR 的压缩瓶颈；详细的先例—缺口对应关系见
[note 184](184-known-pcpp-rldc-transform-and-acrr-communication-compression-2026-08-16.md)。

## 设置

设 `H_x \subseteq Sigma_0^T` 是实例 `x` 的合法 computation histories；这里把验证
history 所需的中间门值和 witness bits 一并放进 `h`，使“`h\in H_x`”可由一个确定性
电路检查。并假设确定性
机器的所有合法 history 都有相同输出词 `f_x\in{0,1}^ell`。取一个输出编码

\[
  C_{out}:{0,1}^{\ell}\to\Gamma^M
\]

其 `q_D`-query RLDC 在半径 `delta_D` 内满足：完整 codeword 上精确输出，近 codeword
上输出错误位的概率至多 `beta_D<1/2`，否则允许 `bottom`。

为使输出区在距离中占常数权重，取
`R=ceil(T/M)` 个 codeword copies，并令 `Z_x` 是所有字符串

\[
  z=(h,c_1,\ldots,c_R),
  \qquad h\in H_x,\quad c_1=\cdots=c_R=C_{out}(f_x).
\]

假设 `Z_x` 可由一个大小为 `N_x` 的电路 `phi_x` 判定，并对 `SAT(phi_x)` 使用一个
完美完备 PCPP。PCPP 的 proximity 参数记为 `delta_P`，当输入 oracle 距 `Z_x` 超过
该半径时，任意 auxiliary proof 的接受率至多 `beta_P`。

## 定理：暴露 history 的 shared coordinate robustness

定义全局 proof 为

\[
  Pi=(z,\pi_{PCPP}),
\]

其中 `z` 是上述 history 与 codeword copies，`pi_{PCPP}` 是 PCPP auxiliary
assignment。对坐标 `i` 和声明位 `b`，查询一个 PCPP 局部约束，均匀抽取一个 copy
`c_r`，运行 `C_out` 的局部 decoder `D_i`，仅当 PCPP 约束通过且 `D_i(c_r)=b` 时接受。

若

\[
  \beta_P<1/2,
  \qquad
  \beta_D+\frac{\delta_P}{w_C\delta_D}<1/2,
\]

其中 `w_C` 是 codeword copies 在 `z` 的距离度量中所占的权重（取
`R=ceil(T/M)` 可令 `w_C>=1/2`），则该 verifier 满足：

1. 所有坐标共用同一个 `Pi` 和同一个 proof address space；
2. 正确声明位在 honest proof 上完美接受；
3. 错误声明位对任意候选 `Pi` 的接受率小于 `1/2`。

总查询数至多 `q_P+q_D`，其中 `q_P` 是 PCPP 查询数；若 `N_x=poly(T)`，全局 proof
长度为

\[
  T+RM+N_x\,polylog(N_x)=O(T+M+N_x\,polylog N_x).
\]

### 证明

设候选 oracle 部分为 `z`。

- 若 `z` 距 `Z_x` 大于 `delta_P`，PCPP 直接给出接受率至多 `beta_P`，故错误声明
  的接受率也至多 `beta_P`。
- 若 `z` 距 `Z_x` 不超过 `delta_P`，则平均 copy 距离至多
  `delta_P/w_C`。由 Markov 不等式，随机 copy 以至多
  `delta_P/(w_C delta_D)` 的概率不在 `delta_D` 半径内；在其余 copy 上，RLDC 输出
  错误位的概率至多 `beta_D`。因此错误声明的接受率至多
  `beta_D+delta_P/(w_C delta_D)`。

完备性来自合法 history、所有 copies 的同一输出 codeword，以及 PCPP 和 RLDC 的完美
完备性。两种情况覆盖所有候选 proof，证毕。

## 与已知近线性 PCPP 的参数对接

Gur--Minzer--Weissenberg--Zheng 的 3-query PCPP 对大小为 `N_x` 的 circuit 给出
`N_x polylog(N_x)` 规模、完美完备和可调常数 soundness。因而上述基线在
`N_x=O(T polylog T)` 且 output-code 部分可统一生成时达到
`T polylog T` 级别；它是一个真实的 shared-proof 坐标鲁棒构造，而不是逐坐标拼接
不同 proof。

但该结论只是在**暴露 history**的模型中成立：`Pi` 明确包含 `h` 和 `R` 个 output
codeword copies。对 RW/JK 而言，Merlin 需要给出一个可统一读取的短描述；若这个描述
实际上编码了任意 `T` 位 history，就违反 ACRR 的“无隐藏完整 history/advice”条件。
若 `phi_x` 只以显式大小 `T` 生成，verifier 生成本身也仍是 `T`-尺度，而非
`poly(n,log T)` 地址尺度。

## 精确的压缩命题

因此，target-binding relation-PCP 的非平凡版本可以等价表述为：把上述

\[
  (h,c_1,\ldots,c_R,\pi_{PCPP})
\]

替换成一个长度至多 `s=poly(n,log T)` 的共享 key，并仍能在同一地址空间上模拟
`q_P+q_D` 次查询，同时保持错误声明的常数拒绝率。任何只把 `h` 改名为 canonical
key、或把 `h` 的所有位 hardwire 进 nonuniform advice 的方案，都只是重述基线，不是
ACRR 构造。

这给出一个可证伪的二分：

- 若能完成该压缩，得到新的 succinct relation-PCP/ACRR 定理；
- 若能证明任何这种压缩都诱导 RLDC/LDC 或必须付出超线性长度，即得到一般性
  impossibility theorem。

## 普适 succinct compiler 的复杂度后果

还有一个必须单独记账的边界。若对一个 NEXP-complete 的 history relation，存在长度
`p(n)=poly(n)` 的 key `s` 和统一多项式时间 evaluator `E(x,s,a)`，能够生成上面全局
proof 的任意地址符号，并且 PCPP verifier 的随机串长度也是 `poly(n)`，则该语言满足

\[
  x\in L
  \Longleftrightarrow
  \exists s\in\{0,1\}^{p(n)}\;\forall r\;V(E(x,s);r)=1.
\]

因此得到 `NEXP\subseteq Sigma_2^P`（量词字符串和局部 evaluator 都是多项式长度）。
若 evaluator 是确定性的 canonical 生成器而非存在性 key，并且 verifier 的随机位数为
`O(log n)`，则枚举随机串得到 `NEXP\subseteq P`；随机位数为 `poly(n)` 时至少得到
相应的 `NEXP\subseteq BPP` 判定。这个推论不是 NEXP-specific history accessor 已经
存在的证据，而是为什么“普适短 key”本身已经是重大复杂度压缩。

该量词后果不能直接套到 RW 的单一 fixed history：RW 只要求一个特定 `x` 的
history-specific selector，并没有给出对所有 NEXP 输入的统一 proof generator。若把
普适性、短 key 和地址 evaluator 三项同时宣称，则必须正面承担上述复杂度坍缩，而不能
把它称作普通 dPCP 的参数优化。

## 证据边界

- PCPP 定义要求 oracle 词并不属于 proof assignment 的短描述；将 oracle 一并放入
  `Pi` 是本 note 明确的 baseline，而非 ACRR 的偷偷实现。
- 近线性 PCPP 的参数来自
  [Gur--Minzer--Weissenberg--Zheng, Theorem 1.7](https://arxiv.org/html/2512.12960)。
- RLDC 的定义与近线性构造见同文 Definition 1.4 / Theorem 1.9；本 note 的组合证明
  是直接的参数推导，不声称原文已经给出 RW target-binding。
- 通用 PCPP+RLDC 的 `n'+cc(n)` 通信变换见
  [Athamnah--Ron-Zewi--Rothblum, Appendix A, Lemma A.3](https://eccc.weizmann.ac.il/report/2025/090/download/)。
- ACRR 的无隐藏 history、地址尺度和 RW/JK 充分性条件见旧
  [note 121](121-local-jk-smart-prma-would-separate-p-np-2026-08-15.md) 与新单元
  [RW/JK 单元入口](../../rw-jk-succinct-reconstruction/README.md)。
