> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Standard-Borel policy--locality Closure Gate (2026-08-17)

## Contribution

The standard-Borel policy fiber theorem and the adaptive-to-nonadaptive
finite-alphabet RLDC lower bound combine into one quantitative barrier for
simultaneous coordinate robustness.  A target-dependent policy may be an
unbounded strategy and may choose a different address schedule for each
target, but if one common proof/address space is retained and the policy is
supportwise robust, then a policy carrying only a sublinear amount of target
information exposes a large common fiber.  On that fiber, message inlining
produces an RLDC.  The Goldberg--Gur--Saraogi bound then forces the exposed
branch locality to reach the \(\log K/\log\log K\) scale in every fixed
finite alphabet near-linear regime.

This is a closure theorem for the policy/locality escape.  It is not an
unconditional impossibility theorem for ordinary list or distributional
soundness, and it does not prove \(P\ne NP\).

## Theorem

Fix a finite proof alphabet \(\Sigma\) of size \(A\ge2\), constants
\(0<\rho<1\), \(0\le\beta<1\), and \(\gamma<1\).  Let

\[
  \Pi:\{0,1\}^{K}\longrightarrow \Sigma^{P}
\]

be one common proof map.  For a uniformly random target
\(M\in\{0,1\}^{K}\), let \(S\) be an arbitrary standard-Borel policy object.
For a policy value \(s\), write
\(\tau_{s,i,b}\) for the verifier strategy used at coordinate \(i\) when
the claimed bit is \(b\).  Assume that for almost every \(s\), every target
\(m\) in the posterior support

\[
  F_s:=\{m:\Pr[M=m\mid S=s]>0\}
\]

and every coordinate \(i\), the same policy family \(\tau_s\) satisfies

\[
 \Pr[V^{\tau_{s,i,m_i}}_{i,m_i}(\Pi(m))=1]=1,
 \tag{288.1}
\]

and, for every \(z\in\Sigma^P\) with
\(d_H(z,\Pi(m))\le \rho P\),

\[
 \Pr[V^{\tau_{s,i,1-m_i}}_{i,1-m_i}(z)=1]\le\beta.
 \tag{288.2}
\]

Suppose the branch verifier makes at most \(r\) adaptive proof-symbol
queries.  If

\[
 I_2(M;S)\le \gamma K,
 \tag{288.3}
\]

then there is a binary message set of dimension

\[
 d\ge (\theta_\gamma-o(1))K,
 \qquad H_2(\theta_\gamma)=1-\gamma,
 \tag{288.4}
\]

and a finite-alphabet nonadaptive RLDC with message length \(d\), inline
length \(N=d+P\), alphabet size \(A+2\), positive constant radius, success
parameter \(\sigma:=1-\beta\), and query count

\[
 Q_{r,A}:=1+2\sum_{j=0}^{r-1}A^j.
 \tag{288.5}
\]

Consequently, for all sufficiently large \(d\),

\[
 N\ge
 \left(
 \frac{\sigma^2 d}
 {38Q_{r,A}^{4}\log^2(A+2)\log^2 d}
 \right)^{1+1/\lceil Q_{r,A}/\sigma\rceil}.
\tag{288.6}
\]

provided the GGS radius condition
\[
 \delta_0>N^{-\sigma/(2Q_{r,A})}
\tag{288.7}
\]
holds, where \(\delta_0=\delta_0(\rho,A)>0\) is the constant inline radius
constructed below.  In the low-locality contradiction regime
\(Q_{r,A}\le\eta\log K/\log\log K\), (288.7) does hold for all sufficiently
large \(K\), so this qualification does not weaken the near-linear threshold.
In particular, if \(A,\rho,\beta,\gamma\) are fixed and

\[
  N\le K(\log K)^c
\tag{288.8}
\]

for infinitely many sufficiently large \(K\), then

\[
  Q_{r,A}=\Omega_{A,\rho,\beta,\gamma,c}
  \left(\frac{\log K}{\log\log K}\right).
\tag{288.9}
\]

For fixed \(A\), this is equivalently

\[
 r\ge \log_A\log K-\log_A\log\log K-O_{A,\rho,\beta,\gamma,c}(1).
\tag{288.10}
\]

Thus, along any near-linear sequence with
\(Q_{r,A}=o(\log K/\log\log K)\), the supportwise/common-proof model must
have \(I(M;S)=K-o(K)\): the policy channel carries essentially the whole
target.  More generally, for every fixed \(\gamma<1\), (288.8) is the
alternative to (288.3).

### Address-scale descriptor corollary

Suppose in addition that the policy is generated from a target-dependent
descriptor \(D\in\{0,1\}^{\ell_K}\) and target-independent fresh randomness,
so \(M\longrightarrow D\longrightarrow S\).  Data processing gives
\(I_2(M;S)\le I_2(M;D)\le H_2(D)\le\ell_K\).  Consequently, in the
near-linear regime, any route with
\(Q_{r,A}=o(\log K/\log\log K)\) must have
\[
 \ell_K\ge K-o(K).
\tag{288.11}
\]
Thus a \(\operatorname{poly}(\log K)\)-bit canonical key, cover-sheet selector,
or finite strategy summary cannot close a low-locality common-proof interface:
it must pay the growing-locality threshold, carry forcing-scale target
information, or leave the supportwise/common-address model.

## Proof

The conditional-entropy identity gives

\[
 H(M\mid S)=K-I_2(M;S)\ge (1-\gamma)K.
\]

As in the standard-Borel selected-policy theorem, some policy value \(s_\star\)
in the full-measure supportwise-good set has

\[
 |F_{s_\star}|\ge 2^{(1-\gamma)K-o(K)}.
\]

Sauer--Shelah therefore supplies a coordinate set
\(J\subseteq[K]\) with \(|J|=d\) as in (288.4) that is shattered by
\(F_{s_\star}\).  For every pattern on \(J\), choose one representative
target in this same fiber.  Restricting to these representatives gives a
common proof map on \(d\) message bits.  The policies \(\tau_{s_\star,i,b}\)
are identical for all representatives, while (288.1)--(288.2) remain valid
for each representative.

Tag the inline coordinates by \((I,0),(I,1)\), and proof coordinates by
\((P,a)\) for \(a\in\Sigma\).  Invalid tags cause immediate output \(\bot\).
For a claimed bit \(b\), read the inline tag and run the corresponding branch
on the proof suffix.  Perfect completeness in (288.1) holds on every selected
codeword.  If the inline bit is wrong on a word within the chosen constant
radius, the stripped proof word is within \(\rho P\) of the representative
proof, so (288.2) bounds the probability of a wrong output by \(\beta\); if
the inline bit is correct, the decoder outputs that bit or \(\bot\).

It remains to choose a positive inline radius.  The proof image of the
representatives has relative distance greater than \(\rho\): otherwise two
representatives with different values at some \(i\in J\) would make the
correct branch for one target accept the other target while (288.2) bounds the
opposite branch by \(\beta<1\).  The \(A\)-ary Singleton bound then gives
\(P/(d+P)\ge c_{\rho,A}>0\) for all large \(d\).  Taking, for example,
\(\delta_0=\rho c_{\rho,A}/2\) makes every \(\delta_0\)-close tagged word
have its proof suffix within \(\rho P\) of the corresponding proof.

For fixed randomness, each adaptive branch is an \(A\)-ary decision tree of
depth at most \(r\), with at most \(\sum_{j<r}A^j\) internal query nodes.
Query the inline location and the union of the two branch trees.  This gives
the nonadaptive query count (288.5) and exactly preserves the output, including
\(\bot\).  The arbitrary-finite-alphabet RLDC lower bound of
Goldberg--Gur--Saraogi, in the form recorded in note 241, now gives (288.6).
The GGS bound applies whenever (288.7) holds.  For the near-linear threshold,
one only needs the contradiction branch
\(Q_{r,A}\le\eta\log K/\log\log K\); there
\[
 N^{-\sigma/(2Q_{r,A})}
 \le
 \exp\!\left(-\frac{\sigma\log K}{2\eta\,(\log K/\log\log K)}\right)
 =(\log K)^{-\sigma/(2\eta)}
 \longrightarrow 0,
\]
so (288.7) is valid for all sufficiently large \(K\).

Finally, under (288.8), \(N=O(d(\log d)^c)\) because \(d=\Theta(K)\).  The
explicit constant contradiction in note 242, with \(d\) in place of \(K\),
applies to (288.6) and proves (288.9); (288.10) follows from
\(Q_{r,A}=\Theta_A(A^r)\).  \(\square\)

## Exact boundary

The supportwise quantifier is essential.  Ordinary average, list, or
coordinatewise distributional soundness can use different witnesses or policy
values at different coordinates, so they do not create the common fiber used
above.  The theorem also assumes one fixed proof/address space, a fixed finite
alphabet, a positive target-relative radius, and perfect correct-branch
completeness.  Growing alphabets, vanishing gaps, target-dependent proof spaces,
or residual strategies that are not supportwise common are not covered.

This theorem is the quantitative policy/locality part of the RW Closure Gate.
To reach an unconditional \(P\ne NP\) consequence one would still need to show
that the concrete RW/PCP construction enters this common-proof, supportwise
interface, or prove a separate impossibility theorem for the model exits above.

## Sources

* Standard-Borel selected-policy fiber theorem:
  [note 281](281-standard-borel-selected-policy-information-closure-2026-08-17.md).
* Finite-alphabet adaptive-to-nonadaptive RLDC closure:
  [note 241](241-constant-alphabet-adaptive-bottom-closure-2026-08-17.md).
* Growing-query calculation:
  [note 242](242-growing-query-threshold-for-near-linear-closure-2026-08-17.md).
* Goldberg, Gur, and Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally
  Decodable Codes via Robust Daisies*, arXiv:2511.21659, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.
