> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Succinct easy-core 归约与 ExtOut 的 q-尺度边界（2026-08-15）

## 设定

对 m≥1 令

\[
q_m=2^{m-1},
\qquad N_m=2q_m=2^m,
\qquad G_m:\{0,1\}^{q_m}\to\{0,1\}^{N_m},
\]

并写 R_m=Range(G_m)。假设某个阈值 s_m 满足 coverage

\[
\mathcal C_{m,\le s_m}\subseteq R_m,
\tag{1}
\]

其中 C_{m,≤s_m} 是 m 个输入变量、门数至多 s_m 的真值表集合。

## 定理：succinct easy-core obstruction

令 m=m(n)≤n^{O(1)}，并令

\[
B:\{0,1\}^{n}\times\{0,1\}^{m(n)}\to\{0,1\}
\tag{2}
\]

是一个固定的逐位谓词。对每个 x∈{0,1}^n，定义长度 N_m 的表

\[
Y_x[a]=B(x,a),
\qquad a\in\{0,1\}^{m}.
\tag{3}
\]

若在 x 被硬接入后，函数 a↦B(x,a) 有电路大小

\[
\operatorname{CC}(Y_x)\le b(n,m)\le s_m,
\tag{4}
\]

则由 (1) 立即得到

\[
Y_x\in R_m.
\tag{5}
\]

因此，任何声称

\[
x\in K
\iff
Y_x\in R_m
\tag{6}
\]

的归约，如果存在 x∉K 且 (4) 对该 x 成立，就不可能正确。这里的输出不需要
显式写出 N_m 位；只要归约给出一个统一的逐地址描述 B(x,a)，结论仍然成立。

### 固定 PH 谓词的推论

若 B 属于一个固定的 PH_k 层，且所有量词变量、底层验证和 m(n) 的取得都在
poly(n+m) 尺度内，则

\[
P=NP\Longrightarrow B\in P.
\]

于是存在只依赖该固定谓词的常数 c，使得硬接入 x 后

\[
\operatorname{CC}(Y_x)\le (n+m)^c.
\tag{7}
\]

如果在某个显式的 NO 输入序列上有

\[
s_{m(n)}>(n+m)^c,
\tag{8}
\]

那么假设 P=NP 会使 (6) 矛盾。因此：

\[
\boxed{
\text{fixed-PH 全地址 succinct coupling + coverage + (8)
\Longrightarrow P\ne NP.
}
\tag{9}
\]

这与 note159 的 outsider coupling 是同一复杂度机制，但 (9) 直接阻断的是“把一个
succinct、逐地址生成的 easy 表作为 reduction 输出”的路线，而不是要求 reduction 显式
物化整个 2q-bit 表。

对 s_m=q_m/(log q_m)^d，只要 m(n) 相对于 log n 足够大，使
q_m/(log q_m)^d>(n+m)^c，条件 (8) 自动成立。不能只写
s_m=2^{Ω(m)} 而省略 m 与源输入长度 n 的关系。

## 量词尺度：succinct range 不是自动的 PH 语言

若 B 与 G_m 都是 P-uniform，且 G_m(u)[a] 由一个 random-access evaluator 计算，相关的
succinct membership 关系可写成

\[
\mathsf{SR}_{G,B}
 =\left\{x:\exists u\in\{0,1\}^{q_m}
        \ \forall a\in\{0,1\}^{m}\;
        G_m(u)[a]=B(x,a)\right\}.
\tag{10}
\]

只有在 q_m≤poly(n) 且 G_m(u)[a] 可在输入长度的多项式时间内计算时，
(10) 才能按通常编码视为一个 Sigma_2^P 型关系。若 q_m=2^{Theta(m)} 且
m 以源输入长度 n 为基准，见证 u 本身是指数长；此时 (10) 属于 succinct/
exponential-hierarchy 尺度，不能把它冒称为普通 Sigma_2^P 归约。这个区别不影响
(5) 的语义阻断，但决定了所谓“NP-hard range”究竟是哪一个复杂度问题。

更精确地，若 m(n)≤n^{O(1)}，G_m 有 poly(q_m)-time random-access evaluator，且 B
可由同样尺度的确定性算法计算，则 (10) 至少属于 NEXP：猜测 q_m-bit 的 u，枚举全部
m-bit 地址并逐位检查即可，运行时间仍为 2^{poly(n)}。因此 q_m 指数于 n 时，正确的
比较对象是 NEXP/succinct range，而不是把一个指数长 seed 当作 NP 证书。

即使假设 NP⊆P/poly，也只能得到显式 N_m-尺度的 selector。对显式输入
y∈{0,1}^{N_m}，关系

\[
R_m(y)\iff\exists u\in\{0,1\}^{q_m}:G_m(u)=y
\tag{10a}
\]

属于 NP；对每个 seed prefix 固定其已知位后，扩展关系仍是 NP。于是把 NP⊆P/poly
的电路逐位自归约地串接，可以得到一个 poly(N_m)-size 的电路 S_m，使得

\[
y\in R_m\Longrightarrow G_m(S_m(y))=y.
\tag{10b}
\]

这只是显式表输入的 selector：它需要先看到全部 N_m 个 bits，不能把一个
succinct 的地址谓词 B(x,a) 自动变成 poly(m)-size 的公共 seed。对每个 child block
独立求出的 S_m(y) 也不保证父节点满足
G_m(u)=u_{\mathrm{left}}\Vert u_{\mathrm{right}}；whole-tree consistency 仍需
额外的联合关系和更大尺度的 selector。

逐地址地写成

\[
\forall a\;\exists w_a\;V(x,a,B(x,a),w_a)
\tag{11}
\]

也不能替代 range 所需的公共 seed

\[
\exists u\;\forall a\;G_m(u)[a]=Y_x[a].
\tag{12}
\]

不同地址可以使用互不一致的 w_a。最小反例是令地址为 0,1，只有

\[
V(0,0,0)=1,
\qquad V(1,1,1)=1,
\]

其余输入拒绝。表 01 满足逐地址的 (11)，但不存在一个单一 w 使两地址同时
满足；因此逐位 SAT self-reduction 不会自动生成 JK 所需的 word-consistent seed。

这个量词交换错误在 coverage 的自然参数区间甚至可以做到对所有目标表都成立。若
s_m 足以覆盖零表和全部 singleton 表 e_a，则对任意 Y∈{0,1}^{N_m} 都有

\[
\forall a\;\exists u_a\in\{0,1\}^{q_m}:
\qquad G_m(u_a)[a]=Y[a].
\tag{12a}
\]

当 Y[a]=0 时取零表的 seed；当 Y[a]=1 时取 e_a 的 seed。另一方面，
|R_m|≤2^{q_m}<2^{N_m}，所以存在某个 Y 使

\[
\neg\exists u\;\forall a\;G_m(u)[a]=Y[a].
\tag{12b}
\]

因此逐地址可计算、逐地址 witness，甚至固定 PH 位谓词，都不会自动给出同一个
全局 seed；这里不是一个技术性 PCP 缺口，而是公共 seed 与逐坐标可行性的严格量词差异。

## Generic ExtOut 仍是 q-尺度

对任意固定 G_q，定义一个前缀 p 的可扩展 outsider 谓词

\[
\operatorname{ExtOut}_q(p)
\iff
\exists y\in\{0,1\}^{2q-|p|}
\ \forall u\in\{0,1\}^{q},
\quad G_q(u)\ne p y.
\tag{13}
\]

以 q-尺度编码时，(13) 是固定常数层的量词关系；但它的输入和量词长度仍按
q 计。寻找 lexicographically first outsider 时，第 j 位必须查询
ExtOut_q(p0)，其中 p 已含 j−1 个已确定的 bit。到 j=Theta(q) 时，前缀状态本身已有
Theta(q) bits，所以 P=NP 至多把该 self-reduction 降到 poly(q)，不会自动降到 poly(m)。

### 黑盒说明为何不能去掉前缀状态

对每个 r∈{1,…,2^q−1}，可构造一个大小为 poly(q) 的 decoder G_{q,r}，其 range 为

\[
R_{q,r}=\{0,1,\ldots,r-1\}
\subseteq\{0,1\}^{2q}
\tag{14}
\]

（seed 映射到 min(u,r−1)，数值按 2q-bit 二进制编码）。其 lexicographically
first outsider 正好是整数 r。因此对这族 decoder，短于 q bits 的统一 summary 不可能
恢复所有 lex-first outsiders；不同 r 会产生 2^q 个不同答案。这个例子只说明
generic prefix compression 不存在，不能宣称每个特殊 decoder 都没有短 outsider。

另一方面，任何 R_q 的大小至多 2^q，其 lex-first outsider 的整数值至多 2^q。
因此它的前约 q bits 可能被容量事实固定为零，但剩余约 q bits 仍可携带完整的
rank 信息；容量并没有把地址尺度自动压到 m=log_2(2q)。

## 路线裁决

\[
\boxed{
\begin{array}{ll}
\text{succinct easy 表 + coverage:}&\text{仍会被覆盖吞掉；}\\
\text{逐地址 witness:}&\text{不等于公共 JK seed；}\\
\text{generic ExtOut self-reduction:}&\text{固定 PH 但仍是 }q\text{-尺度；}\\
\text{真正未解接口:}&\text{poly}(m)\text{-size、全地址一致的 history/preimage labeler。}
\end{array}}
\tag{15}
\]

本 note 不宣称 P≠NP，也不排除特殊 decoder 存在短 outsider；它把“succinct 输出”与
“address-scale coupling”之间容易混淆的量词和长度边界固定下来。

## 来源与证据边界

- (1)--(9) 是 coverage 的直接语义推论；其关键新增点是 Y_x 只需按地址定义，
  不需作为普通 many-one reduction 的显式输出。
- (10)--(12) 只是编码尺度分类，不能把指数长见证算作标准 PH 见证。
- (13)--(14) 是 generic ExtOut 的自归约与黑盒族说明；它们不构成对每个固定 decoder
  的绝对不可能性。
- 外部 ChatGPT 导出文件只提供路线线索；阶段编号、Drive 写回和穷举哈希声明均未作为
  数学证据采用。
