> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Imperfect full-ROC polynomial-alphabet locality threshold

## Contribution

The trichotomy of note 330 leaves a direct query envelope
\(Q_KH_K=\Omega(\log K)\).  When the proof alphabet is at most polynomial in
the message length, this envelope has an explicit first-order consequence:
the nonadaptive query support obtained from the two adaptive claim trees is
already \(\Omega(\log K/\log\log K)\).  This is the imperfect-completeness,
target-dependent-package analogue of the perfect-completeness threshold in
note 242.

## Theorem

Assume the hypotheses of the imperfect distributional full-ROC trichotomy in
note 330.  In particular, there is one common proof map
\(\Pi_K:\{0,1\}^K\to\Sigma_K^{P_K}\), a target-dependent global package
\(S\sim\mu_m\), a fixed ROC margin, and infinitely many sufficiently large
\(K\) for which
\[
 K+P_K\le K(\log_2(K+2))^{c_0},
 \qquad
 \tau_K\le \Delta/2.
 \tag{331.1}
\]
Let \(A_K=|\Sigma_K|\),
\[
 Q_K=1+2\sum_{j=0}^{r_K-1}A_K^j,
 \qquad
 H_K=\log_2\log_2(K+2)+\log_2(Q_K+2)
      +\log_2(\log_2(A_K+2)+2).
 \tag{331.2}
\]
Suppose that, on the same subsequence, the alphabet is polynomially bounded:
\[
 \log_2(A_K+2)\le B\log_2(K+2)
 \tag{331.3}
\]
for a fixed constant \(B\).  Then there is a constant
\(c_*=c_*(\rho,\alpha,\beta,\Delta,c_0)>0\) such that
\[
 Q_K\ge c_*\frac{\log_2 K}{\log_2\log_2(K+2)}
 \tag{331.4}
\]
for every sufficiently large \(K\) in that subsequence.

If the alphabet is fixed, \(A_K=A\ge2\), then
\[
 r_K\ge \log_A\log K-\log_A\log\log K-O_{A,\rho,\alpha,\beta,\Delta,c_0}(1).
 \tag{331.5}
\]

Thus a target-dependent imperfect full-ROC package with common proof/address
space, positive radius, fixed ROC margin, polynomial proof alphabet, and
\(o(\log K/\log\log K)\) direct query support cannot have near-linear proof
length.  The statement does not cover ordinary average/list soundness: the
max-before-average full-ROC defect and the common package quantifier remain
essential.

## Proof

Under (331.1) and \(\tau_K\le\Delta/2\), note 330 gives, for a constant
\(\eta>0\), either
\[
 \log_2(A_K+2)\ge \kappa K/2
 \quad\text{or}\quad
 Q_KH_K\ge\eta\log_2K.
 \tag{331.6}
\]
The first alternative contradicts (331.3) for all sufficiently large \(K\).

Set \(g_K=\log_2K/\log_2\log_2(K+2)\).  Suppose, for contradiction, that
\(Q_K\le\eta' g_K\), where \(\eta'>0\) is a sufficiently small constant.
Then
\[
 \log_2(Q_K+2)\le \log_2\log_2(K+2)+O_{\eta'}(1),
 \tag{331.7}
\]
while (331.3) gives
\[
 \log_2(\log_2(A_K+2)+2)
 \le \log_2\log_2(K+2)+O_B(1).
 \tag{331.8}
\]
Consequently
\[
 H_K\le 3\log_2\log_2(K+2)+O_{B,\eta'}(1),
 \tag{331.9}
\]
and therefore
\[
 Q_KH_K\le 3\eta'\log_2K+o(\log K).
 \tag{331.10}
\]
Choosing \(\eta'<\eta/4\) contradicts the second alternative in (331.6).
This proves (331.4), after decreasing the constant to absorb finitely many
small values of \(K\).

For fixed \(A\),
\(Q_K=1+2(A^{r_K}-1)/(A-1)=\Theta_A(A^{r_K})\).  Taking logarithms in
(331.4) gives (331.5).  \(\square\)

## Boundary

The polynomial-alphabet assumption is substantive.  If
\(\log A_K\) is itself of order \(K^\theta\) or larger, the third term of
\(H_K\) can be much larger than \(\log\log K\), and (331.6) alone does not
force the same query threshold.  Such an alphabet is an explicit remaining
message-channel escape, not an omission in the proof.

The theorem is a corollary of the q-ary GGS envelope after the
mutual-information/Pinsker mixture and Sauer--Shelah fiber extraction in note
330.  It is therefore a coding/closure theorem under a global full-ROC
interface; it is not a new claim about all dPCP constructions and does not
by itself imply \(P\ne NP\).

## Sources

* [Imperfect distributional full-ROC q-ary Closure Trichotomy](330-imperfect-distributional-full-roc-qary-trichotomy-2026-08-18.md).
* [Growing-query threshold for near-linear closure](242-growing-query-threshold-for-near-linear-closure-2026-08-17.md).
