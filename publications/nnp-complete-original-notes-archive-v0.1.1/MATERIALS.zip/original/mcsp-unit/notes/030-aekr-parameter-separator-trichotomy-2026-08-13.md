> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# AEKR 参数空间的三类 separator 引理（2026-08-13，修订）

## 设置

令参数 (z=(r,t)\in\mathbb F_2^{n+1})，cell (c=(x_c,y_c))，并写

\[
q_c=(x_c,1),\qquad p_c=(y_c,1).
\]

包含 (c) 的 affine-parity 叶参数平面是

\[
H_c=\{z:q_c\cdot z=0, p_c\cdot z=1\}.
\]

对 cell 集 (T)，令 (L(T)=\bigcap_{c\in T}H_c)。假设 (L(T)\neq\varnothing)，但 (L(T)\cap H_s=\varnothing)。

## 三类 separator

增广线性系统的不相容给出某个

\[
(\alpha,\beta)\in\mathbb F_2^2\setminus\{(0,0)\}
\]

使 \(\alpha q_s+\beta p_s\) 属于 \(A_T) 的行空间，且右端不相容。若左零组合在 (T) 的方程上系数为 \(\lambda)，则

\[
\lambda b_T+\beta=1,
\qquad
(\alpha q_s+\beta p_s)\cdot z=1+\beta
\quad(z\in L(T)).
\]

因此每个可命中的 collision witness 至少属于以下三类之一：

\[
\mathsf R_s:q_s\cdot z=1,qquad
\mathsf C_s:p_s\cdot z=0,qquad
\mathsf P_s:q_s\cdot z+p_s\cdot z=0.
\]

这是可靠的参数层耦合；它本身只给余维一约束，不能推出完整 thinning 的 (1/16) 界。

## 固定 affine 叶的可靠轨道界

固定一个 (z)，记其叶为 (R_z=A_z\times B_z)。在 (A_z)、(B_z) 内独立以概率 (1/2) 选择行、列。四个补集样本

\[
(U,V),\quad(\bar U,V),\quad(U,\bar V),\quad(\bar U,\bar V)
\]

对应互不相交的子矩形。若 witness 族两两相交，这四个样本中至多一个能命中见证；故固定 (z) 有

\[
\mu_z:=\Pr_{U,V}[\exists T:T\subseteq R_z(U,V)]\le\frac14.
\tag{1}
\]

注意：该四轨道论证只比较同一个 (z) 的四个子矩形，不能把不同 parity 标签的样本当作等权，也不能把 (t=0,1) 两个不同叶的条件概率直接相加。

## 参数平均的真实粗界

由 (1) 只能得到

\[
\frac1{2^{n+1}}\sum_{z\in\mathbb F_2^{n+1}}\mu_z\le\frac14,
\qquad
\sum_z\mu_z\le2^{n-1}.
\tag{2}
\]

不同 (z) 的叶大小可能不同；因此“16 个标签/轨道等概率”或“固定 (r) 的两个 (t) 叶概率相加再减半”均需额外的平衡假设，不能用于任意 (X,Y)。碰撞条件只说明含 spoiler 的叶不能命中包含 (s) 的 witness，并不自动给剩余叶再提供一个 (1/2) 因子。

## 当前未决接口

要达到目标

\[
\frac1{2^{n+1}}\sum_z\mu_z\le\frac1{16},
\]

还需真正的跨 (z) 联合质量不等式。三类 separator 是可复用的代数入口；在一个 separator 类型中，第二个 spoiler 方程若统一固定，则可用余维二加固定叶轨道界闭合（见 note 035）。若该方程在不同 witness 间自由变化，当前仍是高阶 affine-biclique EKR 的最小未决分支。
