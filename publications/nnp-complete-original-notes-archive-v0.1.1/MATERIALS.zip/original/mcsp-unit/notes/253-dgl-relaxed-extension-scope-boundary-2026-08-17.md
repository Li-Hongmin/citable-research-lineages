> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# DGL relaxed-extension scope boundary for growing locality (2026-08-17)

## Decision

The single-branch inline compiler is valid for every finite branch locality, but
the Dall'Agnol--Gur--Lachish (DGL) paper does **not** by itself justify the
growing-locality adaptive relaxed-LDC lower bound that one might want to plug
into it.  The source theorem for general robust local algorithms and the
relaxed-LDC application have different stated quantifiers.

This is a literature-scope result, not a claim that the desired growing-
locality relaxed extension is false.

## What DGL actually states

The general structural theorem (Theorem 6.1, equivalently Theorem 1 in the
paper) starts with a robust local algorithm of query complexity `ell` and,
under its explicit growth assumptions, produces a sample-based algorithm with
sample exponent of the form

\[
  n^{1-1/(2q^2)},\qquad q=O(\ell\log \ell),
\]

up to the alphabet-dependent prefactor.  The proof itself records a nontrivial
range condition, including

\[
  \ell=o\!\left(\sqrt{\frac{\log n}{\log\log n}}\right)
\]

and an alphabet-growth restriction.  Thus this theorem is not a blanket
constant-free statement for arbitrary growing locality.

The relaxed extension is stated separately as Theorem 7.7.  Its hypothesis is
explicitly

\[
  \text{query complexity }\ell=O(1),
  \qquad \rho_0,\rho_1=\Omega(1),
\]

and Corollary 7.8 consequently states the relaxed-LDC consequence only for
`q=O(1)`.  Corollary 7.9, the relaxed-LDC blocklength lower bound, is likewise
stated only for constant `q`.  The proof invokes the relaxed-specific
two-output construction and does not state a theorem uniform in a growing
`ell`.

Therefore the implication

\[
\text{growing-locality relaxed decoder}
\Longrightarrow
N\ge k^{1+1/O(q^2\log^2 q)}
\]

is not currently licensed by DGL alone.  It would require a new proof that
extends the relaxed construction and all its parameter conditions; it cannot
be cited as a consequence of Theorem 6.1 merely by replacing a constant by a
function of `k`.

## Consequence for the RW/JK route

For a binary proof map with branch verifiers of adaptive depth `r`, the
message-inline decoder itself is valid at locality `r+1` for any finite `r`:
the inline bit selects the branch, and a wrong output can occur only when the
wrong branch accepts.  To obtain a theorem for `r=r(k)` with currently
available literature, the safe compiler is instead the explicit decision-tree
expansion.  For each random tape, the two branch trees have at most
`2^r-1` proof-query nodes each, so their union with the inline position has

\[
  Q_r\le 1+2(2^r-1)=2^{r+1}-1
\]

nonadaptive queries.  The arbitrary-alphabet nonadaptive RLDC theorem of
Goldberg--Gur--Saraogi can then be applied with this `Q_r`, subject to its
radius condition.  This is the route used in notes 240 and 242; it is the
presently justified growing-locality barrier.

If the branch verifiers are already nonadaptive, no tree expansion is needed:
the inline compiler has total locality `r+1`, and the same GGS theorem applies
with `Q=r+1`.

## What remains open

There are two distinct, non-equivalent possible upgrades:

1. Prove a growing-`ell` version of the DGL relaxed extension, including the
   valid-input, bottom, radius, error-reduction, and alphabet-growth bookkeeping.
2. Keep the existing nonadaptive GGS route, which is already stated with
   arbitrary query parameter, and optimize the adaptive-to-nonadaptive loss or
   exploit additional RW structure.

Until (1) is proved, a paper may use DGL for the fixed-locality relaxed-LDC
   corollary and GGS for the growing-locality decision-tree compiler, but should
not claim that DGL itself supplies the latter.

## Sources

* M. Dall'Agnol, T. Gur, and O. Lachish, *A Structural Theorem for Local
  Algorithms with Applications to Coding, Testing, and Privacy*, ECCC
  TR20-154, Theorem 6.1, Theorem 7.7, Corollaries 7.8--7.9:
  <https://eccc.weizmann.ac.il/report/2020/154/>.
* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for
  Relaxed Locally Decodable Codes via Robust Daisies*, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.

