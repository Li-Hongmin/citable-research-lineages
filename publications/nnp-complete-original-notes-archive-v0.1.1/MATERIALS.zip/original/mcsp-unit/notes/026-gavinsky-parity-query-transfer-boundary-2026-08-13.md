> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Gavinsky parity-query 结果与 Formula-XOR 的迁移边界（2026-08-13）

## 直接结果

Gavinsky 的结果研究单输入函数/关系的 parity-query 协议：每次查询一个输入的线性型；确定性协议的叶是输入空间中的仿射子空间。其定理给 approximate-majority 的 unambiguous randomized parity-query complexity Omega(sqrt(n))，而普通 randomized parity-query complexity 为 O(1)。证明使用“大仿射子空间不能同时落在低重量与高重量区域”的事实。

## 为什么不能直接给当前 MCSP 下界

当前目标是二方关系 Ea x NO_b -> ell，要求 ell(x) != ell(y)，并由 AND/OR 递归得到不交 affine product rectangles。这与单输入仿射分割有三个不可省略的差异：

1. 单输入叶是一个仿射子空间；本问题叶是 A x B，碰撞条件由两端 affine hull 是否相交决定。
2. Gavinsky 的 unambiguous 量词是先选一个与关系一致的函数，再分析其仿射分割；MCSP QA 需要一个静态势同时满足全部 product leaves 和全部横/纵递归切分。
3. approximate-majority 的重量两端直接提供稠密的低/高区域；Ea x NO_b 的 NO_b 是电路复杂度语义集合，不能替换为 Hamming 高重量集合。已有 kernel/capacity 估计对此只给 N-o(N) 的线性秩。

因此，Gavinsky 论文提供的是“仿射分割可用大子空间几何下界”的方法启发，不是当前 Frontier-B 的可代入定理。要迁移它，至少需要新的二方 lifting lemma：把 affine-subspace weight-separation 变成对所有 affine product rectangles 的递归不交分割下界；目前尚无此 lemma。

## 本轮最小可复用判断

`unambiguous parity-query lower bound` 不推出 `Formula-XOR MCSP lower bound`。真正的缺口不是 parity 叶本身，而是二方 product-rectangle 的递归相容性，以及 NO_b 的非几何复杂度语义。

来源：D. Gavinsky, *Unambiguous parity-query complexity*, arXiv:2401.11274（预印本 2024；期刊版 Random Structures & Algorithms 2025；本轮检索日期 2026-08-13）。
