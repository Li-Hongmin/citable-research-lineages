> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 平均 list soundness 与固定坐标鲁棒性的分离；RLDC 接口（2026-08-16）

## 摘要

本 note 给出一个一般性的黑箱分离：标准 dPCP 的平均 list-decoding soundness 不会
推出指定坐标的常数拒绝概率。分离甚至发生在完美完备、平凡约束、list size 1 的系统中。
随后给出一个条件性 RLDC 编译引理，明确指出还缺少哪一条逐坐标 robust-completeness
接口。两者共同构成 ACRR 主线的第一个可证伪负向边界。

## 1. 平均到坐标的严格分离

对每个 `n >= 2`，令合法输出语言为 `L_n = {0^n}`。

构造一个二查询 dPCP 的平凡约束系统：有两个 proof vertices `u,v`，唯一边 `(u,v)`
的约束恒真；每个输出坐标都使用同一条边。解码器定义为：

```text
D_1(a_u, a_v) = a_u,
D_t(a_u, a_v) = 0  (2 <= t <= n).
```

取全零 assignment 得到完美完备性。任意 assignment 若 `a_u = 0`，解码词为 `0^n`；
若 `a_u = 1`，解码词为 `e_1`。对任意 assignment，取 list `{0^n}`（它属于 `L_n`），
则“边被满足且解码不在 list 中”的概率至多 `1/n`。因此，对任意固定常数
`epsilon > 0`，当 `n >= 1/epsilon` 时，该系统满足 `(1, epsilon)`-list-decoding
soundness。

但是对真实词 `0^n` 的第一个坐标，错误声明 `b = 1` 在上述错误 assignment 下以概率
1 被接受。故存在一个满足标准 dPCP 平均 list soundness 的系统，却没有任何固定坐标的
常数 soundness。

### 定理（黑箱分离）

任何只使用标准平均 list-decoding soundness、完美完备性和 proof 长度/查询数参数，且
不加入坐标级语义检查、全局一致性或额外 corruption 结构的黑箱变换，都不能保证输出一个
对每个指定坐标和错误声明均有固定拒绝率的 Sim-CR-dPCP。

证明是上述族的直接代入：变换的输入满足其全部平均假设，而第一个坐标的错误局部视图
可以在不违反任何约束的情况下始终出现。要排除它，变换必须使用输入中未被平均
list-soundness 假设承诺的新结构。

## 2. 复制的定量下界

将第一个坐标复制 `R` 次，并只加入副本相等约束。错误 assignment 令所有副本取 1，
仍满足所有新增等式；在新长度 `N = n + R - 1` 上，错误坐标质量为

```text
w_R = R / (n + R - 1).
```

因此：

- 若要求该坐标权重至少为固定 `delta`，则
  `R >= delta (n - 1) / (1 - delta) = Omega(n)`；
- 若同时要求新的平均 soundness 小于 `1/2`，则任何 `w_R > 1/2` 的复制方案在该族
  上必然失败；
- 复制 decoder、复制整份 proof 或增加 equality edges 都不能排除“所有副本一致地取错”。

这不是说所有 coordinate amplification 都不可能，而是说它不能仅靠平均坐标重加权完成；
必须复制语义检查、引入 outer robust test，或证明更强的 distributional/coordinate
soundness。

## 3. 从 Sim-CR 到 RLDC 的最小条件性接口

下面是一个足够条件，而不是对普通 dPCP 的自动推论。设有编码
`C : {0,1}^k -> Sigma^N`、局部测试 `T` 和解码器 `D_i`，每次最多读取 `q0` 个 symbols。
假设：

1. 对任意 message `m`，在 `C(m)` 上所有相关测试完美接受，且 `D_i` 输出 `m_i`；
2. 若 `y` 与 `C(m)` 的距离至多 `delta`，则对每个 `i` 有
   `Pr[T(y) = 1 and D_i(y) = m_i] >= 2/3`；
3. 在同一分布下，对每个 `i` 有
   `Pr[T(y) = 1 and D_i(y) = 1 - m_i] <= 1/3`。

定义 `Dec(y,i)`：运行一次局部测试；若测试拒绝则输出 `bottom`，否则输出 `D_i(y)`。
则 `Dec` 是一个 `q0`-query RLDC：正确 codeword 完美解码；对任意 `delta`-近的 `y`，
每个坐标都以至少 `2/3` 的概率输出正确位或 `bottom`，且错误位不能以同样的接受事件
通过。若测试和解码使用不同的局部视图，查询数改为两者之和。

普通 dPCP 的平均 list soundness 只给出一个短 list 和一个对随机坐标/边的联合概率界，
不提供第 2 条的逐坐标 robust-completeness，也不提供第 3 条的错误位界；第 1 节的
反例说明这两个条件不能从平均假设中黑箱推出。因此“Sim-CR-dPCP implies RLDC”只有
在显式给出上述编码与腐蚀模型时才是合法的 reduction。

## 4. distributional soundness 的精确缺口

Dinur--Harsha--Kindler 的 distributional soundness 解释：对任意 proof 和随机串，除小
概率外，一个接受的局部视图可以由某个理想化的有效 proof 解释；这个理想 proof 可以随
随机串变化。它比普通 list soundness 更适合组合，但仍不自动给出 ACRR 所需的“一个固定
`Pi_x` 对所有坐标、所有错误声明同时负责”。

因此正向目标应明确为新增的 **single-word distributional soundness**：除拒绝事件外，
所有被接受的坐标局部视图必须由同一个全局 word/proof 解释，并且对指定错误声明仍有
常数概率拒绝。若不能从该定义推出这一强化，应给出满足原定义的 separation theorem，
而不是把 distributional 一词当作整词一致性的同义词。

## 5. 与主线的关系

* note 169 的复制反例是本 note 定理的参数化版本；本 note 把它提升为对标准平均
  dPCP 假设的黑箱分离；
* note 173 的 Sim-CR-dPCP 是要攻的正向对象；本 note 给出其最小反向接口；
* note 171 的 direct dPCP--J--K 只有在第 3 节的逐坐标条件和 RW 的 forcing/地址尺度
  同时成立时，才可能升级为顶级主定理。

本 note 不声称已经得到一般性 superlinear lower bound，也不声称普通 dPCP 无法被加强；
它只关闭“平均 list soundness 可免费变成固定坐标鲁棒性”的黑箱路线。

## 证据来源

- [Gur--Minzer--Weissenberg--Zheng, dPCP/RLDC definitions and Theorems 1.6--1.10](https://arxiv.org/html/2512.12960)
- [Dinur--Harsha--Kindler, distributional soundness](https://eccc.weizmann.ac.il/report/2015/085/download)
- [Ren--Williams, Range Avoidance and E^prMA/_1](https://eccc.weizmann.ac.il/report/2026/118/)

