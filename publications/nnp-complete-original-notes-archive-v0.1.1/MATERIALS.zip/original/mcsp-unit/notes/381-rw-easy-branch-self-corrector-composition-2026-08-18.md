> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW easy-branch self-corrector composition (2026-08-18)

## Stronger branch closure

C380 used the systematic prefix as a direct raw-bit projection. The RW proof
already supplies a more robust projection: its final query evaluates
\(\widetilde{\mathrm{out}}(\Pi)\) with the Low-Degree Self-Corrector. Composing
that fixed decoder with the circuit returned by JK's easy branch removes the
need to identify arbitrary auxiliary-PCP or intermediate-gate blocks.

The resulting statement is:

\[
\boxed{\text{JK easy on }\Pi_{x_0}
\Longrightarrow
\text{a small circuit for the whole target }f_i(x_0).}
\]

The remaining serialization assumption is only the fixed proof-to-field
encoding already needed to define the RW verifier and its self-corrector
queries; no semantic provenance for non-systematic blocks is used.

## Composition lemma

Let \(L=|\Pi_{x_0}|\), and let \(t'\) be the compiled CIRCUIT-SAT circuit
size used in the RW PCP instantiation (Theorem 3.5), so \(t'\le
\operatorname{poly}(T_i)\). Let \(s_\Pi\) be the size of a circuit computing
the binary proof word \(\Pi_{x_0}\), and let \(\mathcal D_{j}\) be the source
decoder that returns the \(j\)-th output bit from a proof oracle. Suppose its
fixed-tape implementation, with the low-degree parameters instantiated from
this \(t'\), has:

* at most \(q_{\mathrm{LD}}(t')\) proof-oracle queries;
* control/address circuit size at most \(p_{\mathrm{LD}}(t')\);
* each proof-oracle query address and field-symbol extraction computable from
  the target index \(j\) in \(p_{\mathrm{LD}}(t')\) gates.

For the honest canonical proof \(\Pi_{x_0}\), Theorem 2.3's self-corrector is
correct with probability \(1\) on every random tape. Fixing any one tape
therefore gives

\[
  \mathcal D_j(\Pi_{x_0})=f_i(x_0)_j
\tag{381.1}
\]

for all output coordinates. Replacing each oracle call in \(\mathcal D_j\)
by the proof circuit \(C_\Pi\) yields a circuit for the target with size

\[
  \operatorname{CC}(f_i(x_0))
  \le
  c\Bigl(q_{\mathrm{LD}}(t')\bigl(s_\Pi+p_{\mathrm{LD}}(t')\bigr)
       +p_{\mathrm{LD}}(t')\Bigr).
\tag{381.2}
\]

This is ordinary circuit composition: copy \(C_\Pi\) once per decoder query,
feed it the decoder-computed proof address, and apply the fixed field/bit
projection. The fixed tape is hardwired.

## Easy-branch corollary

If JK on \(G_k\) returns easy, Theorem 3.1 gives

\[
  s_\Pi\le c_0|G_k|\log(L+2).
\tag{381.3}
\]

Combining (381.2)--(381.3) gives

\[
  \operatorname{CC}(f_i(x_0))
  \le
  c_1\!\left[
    q_{\mathrm{LD}}(t')\,|G_k|\log(L+2)
    +q_{\mathrm{LD}}(t')p_{\mathrm{LD}}(t')
    +p_{\mathrm{LD}}(t')
  \right].
\tag{381.4}
\]

In the RW instantiation, Theorem 3.4/3.5 take
\(m=\lceil\log t'/\log\log t'\rceil\), \(|H|=t'^{1/m}\), and
\(\Delta=m|H|\), where \(t'\le\operatorname{poly}(T_i)\) is the compiled
 circuit size. Thus \(|H|=\log(t'+2)^{O(1)}\) and
\(\Delta=\log(t'+2)^{O(1)}\); Theorem 2.3's running-time bound
\(\operatorname{poly}(\Delta,\log|F|,m)\) gives
\(q_{\mathrm{LD}}(t')=\log(t'+2)^{O(1)}\) and
\(p_{\mathrm{LD}}(t')=\log(t'+2)^{O(1)}\). Since
\(L_i\le\operatorname{poly}(T_i)\) and \(t'\le\operatorname{poly}(T_i)\),
substitution into (381.4) yields

\[
  \operatorname{CC}(B_i)
  \le
  (|G_k|+1)\,\log(T_i+2)^{O(1)}
\tag{381.5}
\]

on every easy branch, since \(B_i\) is a fixed prefix of \(f_i(x_0)\).

For \(|G_k|\le k^4\), stable \(T_i=n_i^C\), and
\(L_i\le\operatorname{poly}(T_i)\), the right-hand side of (381.5) is

\[
  k^4\,\log(n_i+2)^{O(1)}.
\tag{381.6}
\]

Therefore any same-length lower bound

\[
  \operatorname{CC}(B_i)>\frac{n_i}{\log(n_i+2)}
\tag{381.7}
\]

rules out JK easy whenever

\[
  k< n_i^{1/4}/\log(n_i+2)^{O(1)}.
\tag{381.8}
\]

In particular, \(k=\operatorname{polylog}(n_i)\) forces JK to output a
success outsider, even when \(L_i>k\). This closes the recursive-easy
loophole from C379 without using a raw proof-prefix address identity.

## Boundary and remaining target

The decoder \(\mathcal D_j\) is not an invented all-proof projection. It is
the fixed honest-proof execution of the low-degree self-corrector already used
in RW's final query \(q_{\mathrm{pfx},j}\). The statement therefore assumes
only the source's proof serialization and field-symbol access needed to write
that query. It does not assume that auxiliary proof blocks have a semantic
meaning, nor that a Merlin circuit accepted for one coordinate is accepted for
another.

The conclusion is still only a hard-exit theorem. The success output remains
\(y\notin\operatorname{Range}(G_k)\), with no implication
\(y\mapsto B_i\). Thus the live Closure problem is now sharply:

\[
\text{address-scale }k
\Longrightarrow
\text{JK success outsider}
\quad\text{and then}\quad
\text{parent binding for that outsider}.
\]

This note is not a \(P\ne NP\) proof and not a general dPCP/RLDC
impossibility theorem.

## Sources

* Ren--Williams Theorem 2.3: the low-degree self-corrector is exact on an
  honest polynomial on every random tape.
* Ren--Williams Theorems 3.1, 3.5, and 4.1: JK easy circuit, the PCP proof
  parameters, and the final output-bit self-corrector query.
* Local source extraction:
  units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md,
  approximately lines 426--431 and 915--1008.
* C380 for the direct systematic-prefix specialization.
