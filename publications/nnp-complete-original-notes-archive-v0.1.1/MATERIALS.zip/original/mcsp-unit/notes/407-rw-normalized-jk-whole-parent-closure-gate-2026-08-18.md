> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW/JK normalized hard-exit 与 whole-parent binding Gate（2026-08-18）

## 本轮要改变的判断

附文把最终缺口命名为 **RW Succinct Smart Reconstruction Theorem**。本 note
只处理其中最便宜、且可以由已有 source-level 结果直接合成的一步：把
C381/C383/C392 的 easy、first-failure attachment 和 parent-binding 量词放进同一个
参数化定理。

结论不是“JK outsider 自动恢复 RW parent”。准确的结论是：

* 对归一化的 padded target，easy 被同长度硬度排除后，首个 outsider 必在 signal
  ancestry；当 parent 宽度 \(b\le 2k\) 时，它确实给出 whole-parent evaluator；
* 当 \(b>2k\) 时，它至多给出一个 output-attached \(2k\)-bit block。对一个真正的
  target-oblivious parent family，单个或少数 outsiders 加 address-scale descriptor
  必须支付 parent entropy；
* 对 published RW canonical PCP proof，前两项只有在另证 proof-level
  non-output range cover/递归封闭时才能使用。否则 first failure 仍可能是 auxiliary
  block，不能被写成 Closure。

这把 Gate-I 压成一个明确的 source obligation，而没有把 toy padded target、hidden
family 和 published singleton 混为一谈。

## 记号与模型

固定一个 JK stage。令

\[
  G=G_k:\{0,1\}^k\to\{0,1\}^{2k},
  \qquad R=\operatorname{Range}(G),
\]

并选 **lexicographically first** canonical preimage \(p:R\to\{0,1\}^k\)。假设
generator 已归一化为

\[
  G(0^k)=0^{2k}.
\tag{407.1}
\]

于是自动有 \(p(0^{2k})=0^k\)；若采用其他 canonical tie-break，则必须把这一
等式作为单独假设保留。JK 在每一层返回**最左**的 non-range block。对长度 \(T\)
的 parent

\[
  B\in\{0,1\}^{b},
  \qquad F_B=B0^{T-b},
\]

把 \(F_B\) 右侧补零到 \(T'=k2^h\)，其中

\[
  h=\left\lceil\log_2(T/k)\right\rceil.
\]

第 \(j\) 层的连续 \(2k\)-bit blocks 记为 \(Z_{j,u}\)。如果一层所有 blocks
在 \(R\) 中，则按 JK 规则把每个 \(Z_{j,u}\) 替换成 \(p(Z_{j,u})\)，形成下一层。
定义左右 half-lift

\[
  L_{G,0}(z)=G(\operatorname{left}_k z),\qquad
  L_{G,1}(z)=G(\operatorname{right}_k z).
\tag{407.2}
\]

C382 的 ancestry 公式说明：一个在第 \(j\) 层的 block，沿一条未截断的左右路径
至顶层只恢复一个 top \(2k\)-bit block，而不是整个 parent。

令 \(E(G,T)\) 表示 JK easy branch 与 RW Low-Degree Self-Corrector 复合后得到的
parent 电路上界；C381 给出在 RW 参数下可取

\[
  E(G,T)=(|G|+1)\log(T+2)^{O(1)}.
\tag{407.3}
\]

## 定理 407.1（归一化 padded hard-exit）

对任意 \(B\)，运行上述规范化 JK 于 \(F_B\)。若

\[
  \operatorname{CC}(B)>E(G,T),
\tag{407.4}
\]

则 JK 不会进入 easy branch，而会返回某个 first-failure block

\[
  y=Z_{j,u}\notin R.
\]

该 block 的 ancestry 与 signal 区间相交，即至少有一个未截断 top ancestor
覆盖 \(F_B\) 的前

\[
  2k\left\lceil\frac{b}{2k}\right\rceil
\]

个 signal/padding bits；tail \(0^{T'-b}\) 不会产生 first failure。特别地：

1. 若 \(b\le 2k\)，则 signal 只有首个 top block。给定其 ancestry path，逐层应用
   (407.2) 得到

   \[
     Z_{h,1}=L_{G,0}^{\,h-j}(y),
\tag{407.5}
   \]

   其前 \(b\) bits 正是 \(B\)。若路径和层号由 \(d\)-bit address descriptor 给出，
   整个 \(B\) 的 evaluator 大小为

   \[
     O((h-j)|G|+hk+d).
\tag{407.6}
   \]

2. 若 \(b>2k\)，则同一 lift 只恢复一个 output-attached top block \(Z_{h,a}\)，其中

   \[
     a\le\left\lceil b/(2k)\right\rceil.
\tag{407.7}
   \]

   单个 outsider 不自动恢复其余 parent bits。

### 证明

顶层的前 \(\lceil b/(2k)\rceil\) 个 blocks 是 signal blocks；其后的 top blocks
全为 \(0^{2k}\)，由 (407.1) 落入 \(R\)。把某个 lower-level block 称为
signal-ancestral，若它的 top ancestry 与这前缀相交。任何没有 signal ancestry
的 lower-level block 都只由零 top blocks 的 canonical preimages 组成，因而仍是
\(0^{2k}\)；这是 \(p(0^{2k})=0^k\) 的递归保持。若 signal block 数为奇数，或
lower-level block 正好跨越 signal/tail 边界，它可能由一个 signal half 与一个零
half 组成；这类边界 block 仍是 signal-ancestral，不能误称为全零 tail。因此在
每个未停止层，所有非-signal-ancestral blocks 都在 \(R\)，最左 tie-break 只能在
signal ancestry 中首次失败。

若没有 first failure，C381 的 self-corrector composition 给出
\(\operatorname{CC}(B)\le E(G,T)\)，与 (407.4) 矛盾，故必有 outsider。
对任意未截断 ancestry path，C382 的 block-lift 公式逐层给出对应的 top block；
当 \(b\le2k\) 时只有首块，路径全为左分支，得到 (407.5)，再截取前 \(b\) bits
即得 \(B\)。每次 lift 调用一次 \(G\)，并支付路径/地址控制的普通编码开销，得到
(407.6)。当 \(b>2k\) 时同一论证只确定一个 top block，得到 (407.7)。证毕。

## 定理 407.2（whole-parent binding 的信息下界）

令 \(\mathcal B\subseteq\{0,1\}^{b}\) 是一个真正的 target-oblivious parent
family，\(M=|\mathcal B|\)。假设一个统一 evaluator 对每个 \(B\in\mathcal B\)
最多观察 \(q\) 个 output-attached \(2k\)-bit blocks，并得到总长度为 \(d\) bits
的 descriptor；descriptor 计入所有 failure-node index、ancestry path、query
addresses、sheet/key 和 target-dependent strategy 信息。若这些信息能 exact recover
整个 \(B\)，则

\[
  d+2kq\ \ge\ \log_2 M.
\tag{407.8}
\]

若只有一次 first-failure transcript，则把其 node index 的值域单独计数，得到

\[
  d+2k+\lceil\log_2 N_{\rm fail}\rceil
  \ \ge\ \log_2 M,
\tag{407.9}
\]

其中 \(N_{\rm fail}\) 是可能的 failure-node 数；若 node index 已包含在 \(d\) 中，
则使用 (407.8) 而不重复收费。

### 证明

固定统一 evaluator。给定 descriptor 后，至多有 \(2^{2kq}\) 种 block response
串；因此可见 transcript 总数至多 \(2^{d+2kq}\)。exact recovery 要求不同 parent
产生不同 transcript，否则 evaluator 在两者上输出相同 parent，矛盾。于是
\(M\le2^{d+2kq}\)，得到 (407.8)。若把 first-failure node 从 descriptor 中取出，
其值域至多 \(N_{\rm fail}\)，同样的计数给出 (407.9)。证毕。

## RW-specific Closure Gate

定理 407.1--407.2 合起来给出以下 source-specific 三分。

### (P) Padded/signal branch

若对象确实是 \(F_B\)，generator 满足 (407.1)，easy 被 (407.4) 排除，且
\(b\le2k\)，则 single outsider 加地址路径给出 whole-parent evaluator。这个
分支是一个可检验的正向 Closure candidate，但其参数必须同时满足

\[
  (|G|+1)\log(T+2)^{O(1)}<\operatorname{CC}(B)
  \quad\text{and}\quad b\le2k.
\tag{407.10}
\]

在 published RW 稳定区 \(b=2n_i,\ k=n_{i+1}=n_i^C\) 时，第二个条件容易满足，
但第一个条件通常不满足：\(|G_k|\le k^4\) 使 easy upper bound 远大于已知
\(\operatorname{CC}(B_i)=\Omega(n_i/\log n_i)\)。因此 (P) 不是 published RW
的现成矛盾。

### (O) Output-attached but block-limited branch

若 \(b>2k\)，或实际 proof 只证明了若干 output-attached top blocks，则 whole-parent
closure 必须满足 (407.8)。当 \(\log M=\Theta(b)\)、\(q,d=\operatorname{polylog}(b)\)
而 \(k=\operatorname{polylog}(b)\) 时，单个或少数 outsiders 不可能 exact bind
整个 parent。这个分支把“一个 outsider 是 parent accessor”的说法改成了可核验的
payload 定理。

### (A) Auxiliary/no-attachment branch

对实际 RW canonical PCP proof，Theorem 3.5 只给出 systematic witness/output
字段及 auxiliary proof 的 source semantics；它没有保证 JK first-failure block
的 top ancestry 落在 output 区间。若缺少 C401 所需的 non-output tagged cover 与
JK preimage 递归封闭，则 C382 只给出一个 auxiliary top block，不能应用 (407.8)
的 output-channel 结论，也不能推出 \(B_i\) 的任何坐标 evaluator。

因此 actual RW Gate-I 的最小正向义务是：

\[
\boxed{
  \text{证明 }H_{\rm wit}\text{ 的 non-output recursive range cover}
  \ \Longrightarrow\
  \text{first failure output attachment}
}
\tag{407.11}
\]

这正是 C401 的 source obligation；C394/C400 只覆盖各自的 algebraic/ECC 内部区段，
不能替代 \(H_{\rm wit}\)。即使 (407.11) 成立，仍须通过 (407.8) 处理 whole-parent
信息量。

## 与最终 \(P\ne NP\) Closure 的关系

这一步没有关闭 Gate III。若假设 \(P=NP\)，C181/C358 的最终矛盾还要求：

1. RW 的**同一个** \(H_A\) 在 forcing lower-bound 成立的同一无限长度集上被重构；
2. solver branch 也必须从 object scale 压到 address scale，不能只得到
   \(N^{O(1)}\)-size evaluator；
3. promise、cover sheet、bottom、descriptor 和 uniformity 的成本均已计入。

定理 407 只说明：在 padded positive branch 中，signal recovery 的精确参数是
什么；在 output-attached branch 中，parent payload 的必要信息量是什么；在
auxiliary branch 中，缺少哪一个 source theorem 就不能继续。它不证明
\(P\ne NP\)，不证明一般 dPCP/RLDC 不可能，也不声称 published RW 已满足
\(H_{\rm wit}\)。

## 证据边界与上游

* C381：RW easy branch 与 Low-Degree Self-Corrector 的组合上界；
* C382：JK single-half lift 与 block ancestry；
* C383：easy/output-attachment/auxiliary 三分；
* C392：归一化 \(G(0^k)=0^{2k}\) 与 padded signal/easy dichotomy；
* C401：systematic-output hard-exit 所需的 tagged non-output cover；
* C405/C406：recursive failure transcript 的 entropy 记账与公开输入不能冒充 hidden
  family。

本 note 的 novelty 是把这些 source-level 接口写成同一个参数化 Gate，而不是增加
一个新的局部 decoder 反例。它的成功条件仍然是一个可证伪的 \(H_{\rm wit}\) 构造或
其代价下界；在该条件尚未证明前，Closure Theorem 仍未完成。
