> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW Reconf common-witness payment and quantifier gap (2026-08-18)

## Decision

The published RW Reconf proof does not give a common Merlin witness across
addresses.  Its final prMA query for address \(j\) may use a different circuit
\(C_j\), and the source theorem only guarantees that the query answer is the
correct bit.  Therefore the complexity of the canonical PCP proof \(\Pi_x\)
cannot be charged to each individual query.  A valid common-witness payment
theorem exists, but it applies only after a new attachment adds the missing
same-witness/whole-word quantifier.

## Setup

Let \(f(x)\in\{0,1\}^{T}\) be the RW target, let
\[
  S=\operatorname{CC}(f(x)),\qquad
  m=\lceil\log_2(T+1)\rceil ,
\]
and let \(\Pi_x\) be the canonical PCP proof used in the completeness argument.
Assume the fixed low-degree self-corrector has a deterministic fixed-tape
simulation with the following property: from a circuit of size \(s\) for a
proof word \(\Pi\), the decoded output word has a circuit of size at most
\[
  (s+\log(T+2))^{c_{\rm LD}}\log(T+2)^{v_{\rm LD}}
\tag{365.1}
\]
for constants \(c_{\rm LD},v_{\rm LD}\) independent of \(x,T\).

Fix the prMA query encoding used by RW, and let \(d_{\rm MA}\) be a constant
such that a query of description length \(Q\) has Merlin witness length at most
\(Q^{d_{\rm MA}}\).

## Theorem (common-witness query payment)

Suppose a proposed RW attachment has the following stronger property on a
failure length:

* every address query uses one and the same Merlin circuit \(C^\star\);
* the truth table of \(C^\star\) is a proof word \(\Pi^\star\) whose decoded
  output is the entire target \(f(x)\);
* for at least one \(1\)-coordinate, the corresponding final prMA query is a
  YES instance with witness \(C^\star\).

If \(Q\) is the description length of that query and
\(s^\star=\operatorname{CC}(\Pi^\star)\), then
\[
  Q
  \ge
  \Omega\!\left((s^\star)^{1/d_{\rm MA}}\right)
  \ge
  \Omega\!\left(
    \left(\frac{S}{\log(T+2)^{v_{\rm LD}}}\right)^{1/(c_{\rm LD}d_{\rm MA})}
  \right).
\tag{365.2}
\]
Thus if \(S=2^{\Omega(m)}/\operatorname{poly}(m)\), a common-witness query
has description length \(2^{\Omega(m)}\), and its explicit generation is not
address-scale.

## Proof

By (365.1), the decoded target has a circuit of size at most
\((s^\star+\log(T+2))^{c_{\rm LD}}\log(T+2)^{v_{\rm LD}}\).  Hence the forcing
lower bound \(S\) gives the second inequality in (365.2), after absorbing the
additive logarithmic term.  An encoding of \(C^\star\) has length
\(\Omega(s^\star)\) under the standard bounded-fan-in circuit encoding.  Since
the chosen query is YES and its witness is required to be \(C^\star\), the
protocol's witness bound gives \(Q^{d_{\rm MA}}=\Omega(s^\star)\).  The RW
algorithm writes an ordinary query circuit explicitly, so generating it costs
\(\Omega(Q)\).  \(\square\)

## Exact quantifier gap in published Reconf

The source proof of RW Theorem 4.1 does **not** satisfy the theorem's first
bullet.  For each prefix query \(q_{\mathrm{pfx}}\) and final coordinate query
\(q_{\mathrm{pfx},j}\), Merlin may send any circuit \(C\) accepted by that query.
Completeness exhibits the canonical \(\Pi_x\) as one valid witness, but soundness
only constrains the decoded prefix/output of an accepting \(C\); it does not
force \(C\) to equal \(\Pi_x\), nor does it force the witnesses for two addresses
to agree.  A short coordinate-specific witness is therefore not ruled out by
\(\operatorname{CC}(\Pi_x)\).

Consequently, the common-witness theorem is a **conditional payment lemma**, not
a direct barrier for published Reconf.  It identifies the exact missing
interface: a new attachment must either bind one proof circuit/decoded word
across all addresses, or explicitly account for the target information carried
by the family \(\{C_j\}_j\).  The latter is precisely the descriptor/strategy
escape charged by C364 and the family-level policy-information results.

## Consequence for the Closure program

The tempting inference

> “Reconf has a canonical proof witness, so \(P=NP\) gives a short common
> address evaluator”

is invalid.  The source gives smartness and correct answers for each query, not
same-witness consistency.  Therefore a positive RW Closure proof must add one of:

1. a common-witness theorem strong enough to invoke (365.2);
2. a single-valued address surface whose target-dependent package is explicitly
   charged by C364; or
3. a new non-transcript global coupling that is not represented by per-address
   prMA witnesses.

This narrows the live positive target without claiming a general dPCP
impossibility or \(P\ne NP\).

## Sources

* Ren--Williams, ECCC TR26-118, Theorem 4.1 and its proof, especially the
  final query \(q_{\mathrm{pfx},i}\), the canonical witness \(\Pi_x\), and the
  soundness statement for arbitrary accepting circuits.
* Ren--Williams, Lemma 3.2 and the low-degree self-corrector discussion in
  units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md.
* [RW static-package Closure Theorem](364-rw-static-package-closure-theorem-2026-08-18.md).
* [RW reconstruction-width/round conservation](363-rw-reconstruction-width-round-conservation-2026-08-18.md).
