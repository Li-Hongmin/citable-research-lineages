> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW 固定 PCP history 的 Reed--Muller block-supply 边界（2026-08-15）

## 结论

Ren--Williams Theorem 3.5 的 Reed--Muller systematic prefix 不能从单个固定
completeness history 强制出 JK capacity 所需的内部 tuple-richness。真正无条件的上界
来自完整 proof 的显式长度，而不是来自低度多项式的系数计数：若

\[
|\Pi_{x_0}|\le T^a
\tag{1}
\]

（(a) 是固定 PCP 构造常数），则所有 sliding (2k)-bit windows 数至多 (T^a)，
而不重叠 aligned depth-(h) JK tuples 至多

\[
O\!\left(\frac{T^a}{2k\,2^h}\right).
\tag{2}
\]

Theorem 4.3 阶段中

\[
k=n_{i+1}=n_i^C,
\qquad
T=T_i=\max\{2^{cD^i n_0},n_{i+1}\},
\qquad C>D+1,
\tag{3}
\]

故

\[
\log T=o(k),
\qquad
T^a=2^{o(k)}<2^k.
\tag{4}
\]

所以单一固定 history 连足够多的 block occurrences 都没有；更不可能仅由 RM 低度性
推出超过 (2^k) 个可同时闭合 tuples。这个结论已经同时计入 auxiliary PCP bits，
不把它们误当成 RM 系数。

## RM 参数只给表示，不给可交换性

Theorem 3.4/3.5 使用大致参数

\[
m=\Theta\!\left(\frac{\log T}{\log\log T}\right),
\qquad
|H|,|F|=\operatorname{polylog}T,
\tag{5}
\]

并令 \(\widetilde w\) 是在 (H^m) 上编码 witness (w) 的 Reed--Muller extension。
系统性只说明

\[
\widetilde w\!\restriction_{H^m}=w;
\tag{6}
\]

任意 (H^m) 上的 message 都有唯一的 individual-degree (<|H|) 插值。因此低度
条件本身不强制 systematic windows 重复、低电路复杂度或 pair closure：一个固定
polynomial 只给一个固定的 window 顺序，把两个 windows 任意拼接通常对应另一个
message，而不是同一 canonical history。若只统计 systematic prefix，它至多是完整
proof 的子区段；若跨越或落在 \(\Pi'\) auxiliary oracles，则只能使用总长度界 (1)。

系数维数也不能替代位置计数。对总次数至多 (d=m|H|) 的多项式族，形式上有

\[
|\mathcal P_d|\le |F|^{\binom{m+d}{m}},
\tag{7}
\]

但该上界在当前参数下可能大于 (2^k)，并且只适用于完全落在 RM 段的 tuple；它不
约束 auxiliary bits，也不说明不同多项式能在一个 fixed history 中交换出现。故正式
的 fixed-history no-go 使用 (1)--(4)，不使用未经证明的系数压缩。

## Systematic payload 与 auxiliary proof 的分工

在 RW induction 中，(f_i(x_0)) 的显式输出是前一阶段 AVOID 输出及 padding；PCP
systematic witness prefix 还包含 satisfying assignment 的中间门值。该 prefix 可被
编码为单一 canonical witness，但现有定理没有给出它的 aligned blocks 具有独立组合性。
其余 computation-witness/auxiliary proof 内容 \(\Pi'\) 可能承载困难性，但对它们本 note
只使用总长度 bound；候选 Merlin circuits 的数量不能当作同一 actual history 的
leaf family。

因此潜在的突破接口被精确缩小为：证明某个固定 canonical computation witness 或
auxiliary PCP proof 内部存在可定位、可组合的 richness；RM degree、field size 和
systematicity 三者单独都不提供该接口。

## 适用边界

式 (2) 统计的是一条选定的 canonical/actual history。若把所有可能 PCP/Merlin histories
都纳入，应改以前因子 \(N_{\mathrm{hist}}\) 计数；那是一个新的 witness-family 假设，
不能由 Theorem 3.5 的 completeness 自动提供。式 (4) 只关闭“在 RW 原阶段尺度中，
靠一条固定 history 的 RM/auxiliary block 数量触发 capacity”这一尝试，不证明该 history
不含某个具体、非计数的 hard block，也不推出 (P\ne NP)。

来源：Ren--Williams, ECCC TR26-118 rev.1, Theorems 3.4--3.5 与 4.3；本地全文
`ResearchLibrary/lib/ren2026near/ren2026near.pdf`。与 [note163](163-rw-multiinput-tuple-supply-parameter-no-go-2026-08-15.md)
合并后，当前路线只剩固定 history 内部的结构性 richness 或新的 compressed witness
接口。
