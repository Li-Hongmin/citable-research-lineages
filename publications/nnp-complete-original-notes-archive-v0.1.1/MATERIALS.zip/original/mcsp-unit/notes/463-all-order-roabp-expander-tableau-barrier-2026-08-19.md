> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All-order ROABP 也不能提供 solution automaticity（2026-08-19）

## 本轮改变的判断

C461 的 equality block 需要 cut-respecting 地址映射：如果把 \(x,y\) 交错读取，
equality 本身可以用很小的 ordered branching program 计算。这个 note 消除该
变量排列逃逸。取一个固定、常度、具有常数边扩张率的显式 expander family
\(\{G_k\}\)，并令

\[
 f_k(z_1,\ldots,z_k)
 :=
 \bigwedge_{\{u,v\}\in E(G_k)}(z_u\lor z_v).
\tag{463.1}
\]

在任意变量顺序的任意宽度-\(s\) inhomogeneous algebraic branching program
(ROABP)，\(f_k\) 都强制

\[
 s=2^{\Omega(k)}.
\tag{463.2}
\]

一个固定 deterministic machine 可以在 unary input \(1^{2^k}\) 上连续输出
\(f_k\) 的完整 truth table，运行时间 \(2^k\operatorname{poly}(k)\)，其
hist-first/cell-time tableau 仍有固定局部约束和唯一 accepting assignment。
因此，C461 的 bounded-cut lower bound 可升级为**任意 read-once 变量排列**
的表示类 barrier；但它仍不覆盖一般 nonlinear Boolean circuits。

## Expander source

固定一个常数 \(d\) 和 \(h>0\)，以及一个 polynomial-time uniform 的
\(d\)-regular graph family \(G_k\)（取无限多个 \(k\) 即可），满足对所有
\(S\subseteq V(G_k)\) 且
\[
 k/3\le |S|\le 2k/3,
\]
都有
\[
 |E(S,V\setminus S)|\ge hk.
\tag{463.3}
\]

标准显式 constant-degree expander constructions 提供这样的 family；machine
description 固定，给定 \(k\) 后可在 \(\operatorname{poly}(k)\) 时间生成所需邻接
表。定义 \(f_k\) 如 (463.1)。对 \(1^{2^k}\)，机器枚举所有
\(z\in\{0,1\}^k\)，逐个计算 (463.1)，并按字典序写出 \(2^k\) 个输出位。
所以总时间为 \(2^k\operatorname{poly}(k)\)，output block 连续；标准
cell-time、track-major tableau 的 local transition、input boundary 和
output-check 仍是固定-offset families，且 deterministic accepting tableau 唯一。
其 tableau address length 满足
\[
 m_{\rm addr}=\Theta(k).
\tag{463.4}
\]

## 引理 463.1（每个 balanced cut 都有线性 induced matching）

令 \(S\) 是任意满足 \(k/3\le |S|\le2k/3\) 的变量集合。跨 cut 的边数由
(463.3) 至少为 \(hk\)。由于 \(G_k\) 的最大度为 \(d\)，跨 cut 的边图中可以
贪心选出一个 induced matching \(M\)，满足
\[
 |M|\ge \frac{hk}{2d(d+1)}=:c_{\rm exp}k.
\tag{463.5}
\]

### 证明

每选一条跨 cut 边 \((u,v)\)，删除所有至少有一个端点落在
\(N[u]\cup N[v]\) 的跨 cut 边。被删除的边数至多
\(2d(d+1)\)。贪心直到没有边，得到 (463.5)。被选边端点之间没有额外边，
故它们构成 induced matching。证毕。

## 定理 463.2（all-order ROABP width lower bound）

对任意变量排列 \(\pi\)，令一个宽度-\(s\) inhomogeneous ABP 按
\(z_{\pi(1)},\ldots,z_{\pi(k)}\) 依次读取变量，并精确计算 \(f_k\)。则
\[
 s\ge 2^{c_{\rm exp}k}.
\tag{463.6}
\]

### 证明

取 \(\pi\) 的前 \(\lfloor k/2\rfloor\) 个变量为 \(S\)，则 \(S\) 是 balanced
cut。由引理 463.1 取跨 cut induced matching
\[
 M=\{(u_1,v_1),\ldots,(u_t,v_t)\},
\qquad t\ge c_{\rm exp}k,
\]
其中 \(u_i\in S\)、\(v_i\notin S\)。

在该 communication matrix 的行/列限制中，把所有不属于
\(\{u_i,v_i:i\le t\}\) 的变量固定为 \(1\)，只让 matching 端点自由变化。
由于 \(M\) 是 induced matching，所有仍可能未满足的 clauses 正好是
\((z_{u_i}\lor z_{v_i})\)。因此得到一个 \(2^t\times2^t\) 子矩阵
\[
 \bigotimes_{i=1}^{t}
 \begin{pmatrix}0&1\\1&1\end{pmatrix}.
\tag{463.7}
\]
基本矩阵的 determinant 为 \(-1\)，故 (463.7) 在任意域上的秩为 \(2^t\)。

ABP 在 cut \(S\mid(V\setminus S)\) 处的 prefix/suffix factorization 使完整
communication matrix 的秩至多为其 cut width \(s\)。秩不小于任意子矩阵的秩，
故 \(s\ge2^t\ge2^{c_{\rm exp}k}\)。证毕。

## 命题 463.3（任意变量顺序仍给 generic evaluator）

若 \(q|_{H^m}\) 有一个宽度 \(s\) 的 inhomogeneous ROABP，变量读取顺序为
\(\pi\)，即
\[
 q(a_1,\ldots,a_m)
 =
 \alpha^\top
 \prod_{i=1}^{m} A_{i,a_{\pi(i)}}\beta,
\tag{463.8}
\]
且矩阵条目总描述处于 address scale，则其 individual-degree
\(<|H|\) 延拓满足
\[
 q(z)=
 \alpha^\top
 \prod_{i=1}^{m}
 \left(\sum_{a\in H}\ell_a(z_{\pi(i)})A_{i,a}\right)
 \beta.
\tag{463.9}
\]

在 \(|H|,|F|=\operatorname{poly}(m)\)、\(s=\operatorname{poly}(m)\) 时，这给出
address-scale generic evaluator；因此对 C456 的 actual assignment，C459 的
same-output projection 仍排除该表示。任意变量排列 \(\pi\) 不改变这一
grid-to-generic 推论。

## 对 RW Closure 的直接后果

* C461 留下的“把 equality 的 \(x,y\) 交错读取”不再适用于
  expander-CNF truth-table source；任意固定 read-once 变量顺序都支付
  \(2^{\Omega(k)}=2^{\Omega(m_{\rm addr})}\) 宽度。
* 因而 factorized solution route 若仍是 ROABP、OBDD 或 fixed-order
  tensor-train，不能通过不规则但一次性的变量排列获得 address-scale
  automaticity。
* 剩余正向路线必须使用重复读取/非 read-once 非线性状态、带 message-scale
  interface 的 global relation，或显式退出该 representation class。矩阵描述和
  变量排列生成成本都必须计入；未计价 ROM 仍进入 C450 的 common-ROM 分支。

## 证据边界

* \(f_k\) 本身有 \(O(k)\) 个图子句，故有 \(\operatorname{poly}(k)\) 大小的普通
  Boolean circuit；定理只关于 all-order ROABP/OBDD/tensor-train，不是一般电路
  下界。
* 需要一个固定、uniform 的常度 expander family；这是标准显式图构造输入，
  不是本 note 对一般图的额外猜想。
* 定理覆盖每个变量恰读一次的 ordered representation。允许重复读取、任意
  nonlinear memory、或把变量内容藏入未计价 physical permutation 的模型仍需
  单独分析。
* 该 source-specific representation barrier 不证明 \(P\ne NP\)，也不声称 actual
  C456 assignment 在所有模型下有 unconditional lower bound。

## 来源

* [C461 inhomogeneous cut-rank barrier](461-inhomogeneous-cut-rank-solution-representations-2026-08-19.md)。
* [C459 published-RW generic-\(q\) forcing lower bound](459-published-rw-generic-q-access-forcing-scale-2026-08-19.md)。
* Standard explicit constant-degree expander constructions and the
  prefix/suffix rank factorization for ordered branching programs.
