> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW systematic output 的 recursive range-support gate（2026-08-19）

## 本轮改变的判断

C433/434 给出了一个真实的正向机制：共享低度参数可以让 raw blocks
及其 JK preimage blocks 同时落在一个 \(G_k\) 的 range 中。但这个机制不能
把 Ren--Williams systematic output 的任意 target-varying block 也一并吸收。
对合法的 identity source family，output bits 在 source family 上是自由的；
共同 \(G_k\) 的 range 只有 \(2^k\) 个值。因此，任何声称

* 使用同一个 target-oblivious \(G_k\)；
* 把 systematic output block 当作 non-output range block；
* 对整个 identity family 保持 exact closure；

的方案，都先要通过一个直接的 support-capacity gate。若加入 \(d\)-bit
target-dependent descriptor，唯一能得到的放宽是 \(h\le k+d\)，即 descriptor
必须显式支付缺失的 target information。

这不是一般 dPCP 不可能性，也不是 published fixed-\(x_0\) singleton 的
\(P\ne NP\) 证明；它是 C433 正向 branch 的 source-specific 输出边界。

## Identity source 与 systematic output interval

取 Ren--Williams Theorem 3.5 允许的 identity machine
\[
  M_{\mathrm{id}}(x)=x,\qquad x\in\{0,1\}^{b},
\tag{435.1}
\]
不发 NP query，输出长度为 \(b\)。按 Theorem 3.5 的 history 顺序，canonical
satisfying assignment 的 out 字段等于 \(x\)。Theorem 3.4 的 Reed--Muller
编码是 systematic 的；在固定 binary serialization 下，设这 \(b\) 个 output bits
占据一个已知的 interval \(I_b\)（若实现使用固定 tags，则把 tags 从自由
bit 数中扣除）。

取 \(h\) 个互不相交的 output positions，并令
\[
  Z(x)\in\{0,1\}^{\ell}
\]
是这些 positions 及其固定 serialization tags 所形成的一个 block。记其中
真正随 \(x\) 变化的 bit 数为 \(h\)；对任意
\(a\in\{0,1\}^{h}\)，都存在一个 \(x\) 使 \(Z(x)\) 的自由位等于 \(a\)。
这只是 \(M_{\mathrm{id}}\) 的输入 \(x\) 可以任意选择，不使用任何关于
Harsha auxiliary oracle 的未证明独立性。

固定
\[
  G_k:\{0,1\}^{k}\longrightarrow\{0,1\}^{\ell},
  \qquad R_k=\operatorname{Range}(G_k),
  \qquad |R_k|\le 2^k .
\tag{435.2}
\]
在 C433 的二进制 JK 情形 \(\ell=2k\)；以下论证只使用
\(|R_k|\le2^k\)。

## 定理 435.1（systematic-output support gate）

若对每个 \(x\in\{0,1\}^{b}\) 都有
\[
  Z(x)\in R_k,
\tag{435.3}
\]
则
\[
  \boxed{h\le k.}
\tag{435.4}
\]

更一般地，若一个 \(d\)-bit descriptor \(\sigma(x)\) 可以从
\(2^d\) 个 generators
\[
  G_{k,\sigma}:\{0,1\}^{k}\to\{0,1\}^{\ell}
\]
中选择一个，并要求
\(Z(x)\in\operatorname{Range}(G_{k,\sigma(x)})\)，则
\[
  \boxed{h\le k+d.}
\tag{435.5}
\]

### 证明

由 output positions 的自由性，\(Z(x)\) 的自由投影包含全部 \(2^h\) 个
patterns；因而这些 \(2^h\) 个 block values 两两不同。若 (435.3) 成立，
则它们都是 \(R_k\) 的元素，所以
\[
  2^h\le |R_k|\le2^k,
\]
得到 (435.4)。

对于 descriptor 版本，把每个 pattern 送到一对
\((\sigma,z)\)，其中
\(z=Z(x)\in\operatorname{Range}(G_{k,\sigma})\)。不同的 \(z\) 给出不同的
pair，因此
\[
  2^h
  \le\sum_{\sigma\in\{0,1\}^{d}}
       |\operatorname{Range}(G_{k,\sigma})|
  \le 2^d2^k,
\]
得到 (435.5)。证毕。

## 递归版本

设一个 JK subtree 的 leaves 是 \(Z_1(x),\ldots,Z_m(x)\)，每个 leaf 的自由
bit 集彼此不交，且 identity source 可以任意指定这些自由 bits 的联合取值。
令 leaf \(\ell\) 的自由熵为 \(h_\ell\)。若所有 leaves 及其 canonical
preimage 拼接得到的内部 blocks 都在同一个 \(R_k\) 中，则 C402 的
canonical-preimage injectivity 给出
\[
  \boxed{\sum_{\ell=1}^{m}h_\ell\le k.}
\tag{435.6}
\]
若整个递归 cover 由一个 \(d\)-bit descriptor 选择 generator，则相应地
\[
  \boxed{\sum_{\ell=1}^{m}h_\ell\le k+d.}
\tag{435.7}
\]

证明是把任意 leaf pattern 映射到 root block（以及 descriptor）：
canonical preimage 在 range 上 injective，故不同 leaf tuples 给出不同 root
values；再分别使用 \(|R_k|\le2^k\) 或 \(2^d\) 个 range 的并界。
式 (435.6) 也可视为 C412 的 uniform product-rich 特例，但这里的
product-richness 由 identity machine 的 output bits 直接实现，而不是把
Harsha auxiliary image 假定为 product family。

在固定 tags 只占 \(\tau\) 个 bits 的 \(2k\)-bit block 中，
\(h\ge2k-\tau\)。因此只要 \(\tau<k\)，即使一个这样的 systematic output
block 也不能对整个 identity family 保持共同 \(G_k\)-range；若多个 block
被要求递归封闭，(435.6) 更强地按总自由 output entropy 计费。

## 对 C433/H_wit 的精确边界

定理 435.1 把正向机制的适用范围分开：

1. C433 可以覆盖共享低度参数的 auxiliary/non-output stream，前提是其
   descriptors、tags 和 recursive pair blocks 满足自己的 seed budget；
2. 它不能把 identity-family 的任意 systematic output block 也放进同一个
   target-oblivious range。若 output block 有 \(h>k\) 个自由 bits，必须出现
   non-range failure，或 descriptor 携带至少 \(h-k\) 个 target information；
3. 若 C401 的 non-output recursive closure 已被证明且 easy branch 被 hardness
   排除，那么首个 outsider 的 ancestry 必须 output-attached；435.1 说明
   “把 output 也当作 H_wit range”不是第三条免费路线；
4. 对完整 \(b\)-bit parent，output-attached outsiders、path 和 descriptor
   仍需另行支付 whole-parent 信息；435.1 不把一个 \(2k\)-bit block
   自动升级为 \(b\)-bit evaluator。

## Singleton 与 source-family 边界

定理的量词是 identity family 的所有 \(x\) 共用一个 \(G_k\)（或一个短
descriptor family）。published RW Theorem 4.3 固定 \(x_0\)，所以一个
singleton block 可能恰好落在 \(R_k\)，不能从 (435.4) 直接推出其失败。
同样，若 verifier/selector 直接读取完整 \(x\)，这些 \(b\) bits 是显式
target channel，必须计入 descriptor 或 metadata；不能再称为 target-oblivious
closure。

因此，本 note 关闭的是：
\[
\text{identity-family systematic-output universal cover}
\quad\text{with }h>k+d,
\]
而不是：
\[
\text{published singleton auxiliary }H_{\rm wit}
\quad\text{or}\quad P\ne NP.
\]

## 来源与证据边界

* Ren--Williams Theorem 3.5：identity machine 的 out 字段及 systematic
  witness prefix；
* C391：actual Harsha identity-family 的 common-proof/RLDC family boundary；
* C402：JK recursive range-closure 的 canonical-preimage capacity；
* C412：分布版 tree-correlation inequality；
* C423：systematic Reed--Muller prefix 的 source-family distance boundary；
* C433/434：shared low-degree recursive self-describing positive mechanism。

本 note 是一个 source-realizable support theorem；不声称一般 dPCP/RLDC
不可能性，也不证明 \(P\ne NP\)。
