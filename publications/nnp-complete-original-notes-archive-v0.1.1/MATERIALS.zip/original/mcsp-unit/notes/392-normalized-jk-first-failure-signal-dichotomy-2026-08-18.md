> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Normalized JK first-failure 的 signal/easy 二分（2026-08-18）

## 判定

在一个可显式规范化的 AVOID generator 上，RW 的 padded target

\[
  F_B=B0^{T-b},\qquad b\le 2k,
\]

不再有 C383 所留下的 off-signal tail ambiguity：若把每层 hard 输出规定为
**最左的 non-range block**，并要求

\[
  G_k(0^k)=0^{2k},
\tag{392.1}
\]

则 JK 对 \(F_B\) 只有二分：

1. 在 signal path 首次失败，输出携带 \(B\) 的 signal block；或
2. 所有 signal/tail blocks 都通过，JK 返回 easy，并给出整个 \(F_B\) 的小电路。

这不是 published RW 已经满足的无条件 Closure；它是一个明确的 generator-normalization
与 tie-break 接口，并把剩余缺口压缩到 generator 是否可规范化以及 \(k\) 的尺度。

## 规范化 JK

固定 \(G=G_k:\{0,1\}^k\to\{0,1\}^{2k}\)，要求 (392.1)，并在每个阶段使用
lexicographically first preimage \(P_G(z)\)。对长度 \(T\) 的 \(F_B\)，令

\[
  h=\left\lceil\log_2(T/k)\right\rceil,\qquad
  T'=k2^h,\qquad
  Y_h=F_B0^{T'-T}.
\]

阶段 \(j\) 的当前串 \(Y_j\) 被分成 \(2^{j-1}\) 个连续 \(2k\)-bit blocks
\(Z_{j,1},\ldots,Z_{j,2^{j-1}}\)。若存在 block 不在
\(\operatorname{Range}(G)\)，算法返回最小的 index \(u\) 及该 block；否则令

\[
  Y_{j-1}
  =
  P_G(Z_{j,1})P_G(Z_{j,2})\cdots
  P_G(Z_{j,2^{j-1}}).
\tag{392.2}
\]

这个 tie-break 仍然满足 Ren--Williams Theorem 3.1 的输出要求：返回的 block
不在 range；若没有失败，原证明的 easy circuit 结论不变。这里新增的是对实际
padded target 的位置分类。

## Theorem 392.1（signal/easy dichotomy）

设 \(b\le2k\)，且 \(G(0^k)=0^{2k}\)。在上述规范化 JK 中：

* 若算法在阶段 \(j\) 返回 hard，那么返回的 block 必为 \(Z_{j,1}\)；
* 令 \(y=Z_{j,1}\)，并设 \(j+1,\ldots,h\) 是其未停止的祖先阶段。对每个祖先层，
  公开左右 half-lift path 后，正向计算 \(G\) 恢复 \(Z_{h,1}\)；因此

  \[
    \operatorname{pref}_{b}
    \bigl(\mathsf{Lift}_{G}^{\,h-j}(y)\bigr)=B,
  \tag{392.3}
  \]

  其中 \(\mathsf{Lift}_G(u\Vert v)=G(u)\Vert G(v)\) 只是两个 half-lift 的简写；
* 若算法没有返回 hard，则 Theorem 3.1 的 easy branch 给出一个大小
  \(O(|G|\log(T+2))\) 的电路计算整个 \(F_B\)，因而也计算 \(B\)。

### 证明

在顶层 \(Y_h\) 中，第一 block 为
\[
  Z_{h,1}=B0^{2k-b},
\]
其余 blocks 全为 \(0^{2k}\)。由 (392.1)，所有 tail blocks 都在
\(\operatorname{Range}(G)\)。若 signal block 不在 range，最左 non-range tie-break
立即返回 \(Z_{h,1}\)；若 signal block 在 range，则 (392.2) 令其两个 canonical
preimages 成为下一阶段的第一 \(2k\)-bit block。由于 \(P_G(0^{2k})=0^k\)，所有
tail blocks 在下一阶段仍为 \(0^{2k}\)。归纳得到：在任何尚未停止的阶段，唯一可能的
最左 non-range block 是 signal block \(Z_{j,1}\)。这证明第一项。

若阶段 \(j\) 在 signal 上停止，则在每个未停止的祖先层 \(r>j\)，
\[
  Z_{r,1}=G(\operatorname{left}_k Z_{r-1,1})
          \Vert G(\operatorname{right}_k Z_{r-1,1}).
\]
从 \(y=Z_{j,1}\) 逐层正向应用两个 half-lift 即得到 \(Z_{h,1}\)，其前 \(b\) bits
正是 \(B\)，得到 (392.3)。若 signal 在所有阶段均在 range，JK 到达 easy branch；
Theorem 3.1 的结论直接给出 \(F_B\) 的电路，因而给出 \(B\) 的电路。证毕。

## 对 RW Closure 的精确后果

若
\[
  \operatorname{CC}(B)>O(|G_k|\log(T+2)),
\tag{392.4}
\]
则 easy 分支被排除，规范化 JK 必在 signal path 输出一个可 lift 的 outsider。这
比 C383 的三分少了 off-signal 分支，但不自动给出 published RW 的电路矛盾：
在 Theorem 4.3 的稳定递推中，\(k=n_{i+1}=n_i^C\)，而已知硬度只有
\(\operatorname{CC}(B_i)=\Omega(n_i/\log n_i)\)，同时 \(|G_k|\le k^4\)。于是
\(O(k^4\log T)\) 仍远大于该硬度阈值。

反过来，若把 \(k\) 压到 \(\operatorname{polylog}(b)\)，则通常 \(b>2k\)，(392.3)
不再恢复整个 parent；此时 C383/C390 的 block-width、descriptor 或 RLDC barrier
重新成为主约束。因此 C392 关闭的是 **off-signal tie-break ambiguity**，不是
published RW 的 address-scale closure。

## 规范化与 Korten reduction 的兼容性

条件 (392.1) 不是对 truth-table generator 的额外语义负担。设原来的
\(G_n:\{0,1\}^{n}\to\{0,1\}^{2n}\) 的编码中，\(e_n\) 是常零电路的一个 \(n\)-bit
描述；于是 \(G_n(e_n)=0^{2n}\)。令 \(\tau_n\) 为交换 \(0^n\) 与 \(e_n\) 的置换（若二者相同
则取恒等置换），并定义

\[
  \widetilde G_n(x)=G_n(\tau_n(x)).
\tag{392.5}
\]

\(\tau_n\) 可由固定常数比较器在 \(O(n)\) 大小、确定性多项式时间内产生，因此
\(\{\widetilde G_n\}\) 仍是 \(P\)-uniform family，输出宽度不变，且

\[
  \operatorname{Range}(\widetilde G_n)=\operatorname{Range}(G_n),
  \qquad \widetilde G_n(0^n)=0^{2n}.
\tag{392.6}
\]

电路大小只增加 \(O(n)\)；RW Theorem 4.3 中的固定 \(n^4\) 上界可在充分大的 \(n\)
上吸收该项（或把常数 \(1\) 改成任意固定常数），而其递推只使用多项式大小界。
更重要的是，Theorem 4.5 的 Korten reduction 只需要输出 \(f\) 位于 truth-table
generator 的 range 之外。由 (392.6)，规范化前后的 range 完全相同，所以该 reduction
及其 \(s\)-、\(k\)-参数不变。

因此，C392 可应用于一个与 published RW/Korten family 同 range 的 normalized
\(P\)-uniform family；剩余缺口确实是 address-scale 与 parent-attachment，而不是
generator normalization。这里不声称原文排版中选用的具体输入标签本身已经把 \(0^n\)
指定为常零描述；(392.5) 给出了无损的域重标记。

## 来源与边界

* Ren--Williams, ECCC TR26-118 revision 1, Theorem 3.1：每层 SAT block 检查、非
  range hard 输出和 all-range easy circuit；
* Ren--Williams, Theorem 4.1/4.3：\(F_B=B0^{T-b}\) 型 RW padded target；
* C377/C382/C383：signal half-lift、off-signal fiber 与原有三分。

本定理不证明 \(P\ne NP\)，不声称 published RW 已使用 normalized generator，也不
把 object-scale \(k=n_{i+1}\) 的 signal recovery 冒称为 address-scale Closure。
