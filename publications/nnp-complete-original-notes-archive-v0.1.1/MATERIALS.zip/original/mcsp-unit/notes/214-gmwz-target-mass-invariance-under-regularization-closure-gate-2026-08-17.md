> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# GMWZ target-mass invariance under right regularization (2026-08-17)

## 摘要

Gur--Minzer--Weissenberg--Zheng 的右度正则化（Lemma 8.2）会把每个语言坐标
\(t\) 的左侧副本做成 \([M]\) 上的均匀分布，但不会改变外层坐标
\(t\in[n]\) 的均匀采样。因此它能修复右侧度数/离散化，却不能把一个藏在完整
history 中的固定 RW 坐标自动变成常数质量的 target-normalized query。

更定量地，若把该正则化后的全局 list-soundness 黑箱投影到 singleton 目标坐标，
要得到每个坐标的错误率 \(\beta\)，发表定理给出的参数必须满足

\[
  2\varepsilon^{1/5}+\frac{|B|}{M}\le \frac{\beta}{n}.
\tag{214.1}
\]

因此至少需要

\[
  \varepsilon\le \left(\frac{\beta}{2n}\right)^5,
  \qquad
  M\ge \frac{n|B|}{\beta},
\tag{214.2}
\]

而正则化后的左侧长度为 \(nM+|A|\)，故由该黑箱得到

\[
  |Z|+|A|=nM+|A|
  \ge \frac{n^2|B|}{\beta}+|A|.
\tag{214.3}
\]

这是一条定理参数上的来源特定闭合门，不是对所有未来 target-normalized
dPCP 的一般不可能性定理。

## 设置

令 \(\mathcal D\) 是 GMWZ Definition 1.3 意义下、语言
\(\mathcal L\subseteq\Sigma_0^n\) 的 projection dPCP。对每个语言坐标 \(t\)，
\(\mathcal P_t\) 是 decoding distribution；list-soundness 先均匀取
\(t\in[n]\)，再按 \(\mathcal P_t\) 取边。对候选 assignment \(T\)，写

\[
 e_t(T)=\Pr_{e\sim\mathcal P_t}
 [\Phi_e(T(e))=1\land D_t(T(e))\notin Y_t],
\]

其中 \(Y\) 是该 assignment 的合法 decoded-word list。发表的
\((L,\delta)\)-list-soundness 只给

\[
 \frac1n\sum_{t=1}^n e_t(T)\le \delta .
\tag{214.4}
\]

若目标语言在坐标 \(i\) 上是 singleton（所有合法词的第 \(i\) 位都等于
\(y_i^\star\)），则错误声明 \(b\ne y_i^\star\) 的接受事件包含在
\(e_i(T)\) 中。因此 (214.4) 对固定坐标只给

\[
 \Pr[\text{wrong claim at }i]
 \le e_i(T)\le n\delta .
\tag{214.5}
\]

对目标集合 \(J\) 的平均错误率同理至多 \(n\delta/|J|\)。这一步只使用非负性，
与 proof 的内部图结构无关。

## GMWZ Lemma 8.2 的正则化保持外层目标质量

GMWZ Lemma 8.2 从 \(\mathcal D\) 构造 \(\mathcal D'_M\)，左侧为

\[
 Z=[n]\times[M],
\]

所以长度是 \(nM+|A|\)。对每个固定 \(t\)，新的 decoding distribution 在
\(\{t\}\times[M]\) 上均匀；但 \(t\) 仍由外层 dPCP 定义均匀抽取。其 list-soundness
参数是

\[
 \delta_M=2\varepsilon^{1/5}+\frac{|B|}{M}.
\tag{214.6}
\]

因此

\[
 \Pr_{\mathcal D'_M}[\text{outer coordinate}=t]=\frac1n,
 \qquad
 \Pr[\text{left copy}=(t,r)\mid t]=\frac1M.
\tag{214.7}
\]

把 (214.6) 代入 (214.5)，仅靠发表的全局 list-soundness，要得到 simultaneous
固定坐标错误率 \(\le\beta\)，必须要求 (214.1)。由于两项均非负，(214.2) 随即成立；
再用 \(|Z|=nM\) 得到 (214.3)。

## Sharpness 与量词边界

这是“正则化黑箱不能闭合”的 sharp 参数审计，而不是声称每个 GMWZ dPCP
实例都实现了最坏坐标集中。sharpness 已由一般 singleton 一坐标反例给出：
可以有一个同一 proof/address space 上的候选 assignment，使所有错误质量集中在
坐标 \(i\)。任何只知道 (214.4) 的算法无法区分该 assignment 与错误质量分散的
assignment，故不能从标量平均式推出比 \(n\delta\) 更强的固定坐标界。

同样，(214.2)--(214.3) 只对“先应用 GMWZ Lemma 8.2，再用其全局
list-soundness 做坐标投影”的黑箱路线成立：

* 若新 verifier 直接给出 target-normalized \(t\)-分布，(214.7) 不适用；
* 若外码让一个错误目标位在常数比例的被采样坐标上扩散，(214.5) 的
  singleton 投影模型已被改变；
* 若 soundness 直接是非标量的全局 target-binding 条件，也不受 (214.4) 限制。

因此这条结果没有关闭真正的 Closure Gate I；它把正向目标精确缩小为：构造一个
**改变外层目标质量或改变 soundness 量词**的 hidden-witness relation compiler。
仅仅继续做右度正则化、左侧复制或离散化，不能完成这一步。

## 与 RW 参数的关系

若 RW 的完整 history 有 \(n=L_i\) 个外层坐标，而最终 AVOID 只读取一个或
\(K_i\) 个坐标，则 (214.5) 分别给出 \(L_i\delta_M\) 与
\(L_i\delta_M/K_i\) 的黑箱界。稳定阶段 \(L_i\gg K_i\) 时，固定坐标要求的
\(\delta_M=O(1/L_i)\) 与近线性 GMWZ 定理的固定参数窗口不相容；若试图用 \(M\)
压低 \(|B|/M\)，(214.3) 又直接把证明长度推到 history-square 级别。

这不是把 GMWZ 的 dPCP 定理误报成失败：它明确说明 GMWZ 的 regularization
组件解决的是“内部图的均匀性”，而 RW Closure 需要的是“外层 target 的统一性”。
两者是不同的轴。

## 来源与证据边界

来源事实是 GMWZ 的 dPCP 定义和 Lemma 8.2：
[arXiv:2512.12960](https://arxiv.org/html/2512.12960) 中 Definition 1.3
给出先均匀取 \(t\in[n]\) 的 list-soundness；Lemma 8.2 给出
\(Z=[n]\times[M]\)、长度 \(nM+|A|\)、固定 \(t\) 下的均匀左侧副本，以及
\(2\varepsilon^{1/5}+|B|/M\) 的 soundness。式 (214.1)--(214.7) 是本项目对
这些来源条款与 RW fixed-coordinate 目标的直接推导；不把它升级为一般
coordinate-robust dPCP 下界，也不声称 \(P\ne NP\) 已由此得到。
