> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW small-width AVOID calls: a block-exposure Closure Gate（2026-08-19）

## 本轮改变的判断

C363 说明：在 \(P=NP\) 的 deterministic recompilation 下，若把 RW 的
AVOID/JK 调用宽度压到 address scale，则一次失败的 Solve 调用已经会把
整个 parent 压进小电路。因此，small-width 调用在 forcing parent 上必须成功，
并暴露一个 Range-Avoidance outsider。C416 又说明，在 fixed binary serialization、
zero query prefix 和 contiguous leftmost-failure 规则下，这个首 outsider 不能把
canonical ancestry 完全藏在 parent 之后；否则 parent 同样有小电路。

这两个事实还没有完成 Closure：ancestry 与 parent 相交只绑定一个或若干
\(2k\)-bit block，不等于恢复整个 \(b\)-bit parent。本 note 把剩余条件写成一个
可核验的 block-coverage gate，并把 C417 的共享 half-lift DAG 代价推广到不同
宽度的 generator-labelled DAG。

## 固定设置

固定一次 \(P=NP\) deterministic recompilation 后的 padded output
\[
  f\in\{0,1\}^{T},
  \qquad
  B:=f[1,b],
  \qquad
  \ell:=\lceil\log_2(T+1)\rceil .
\]
假设同一长度上的 forcing bound 为
\[
  \operatorname{CC}(B)>S.
\tag{433.1}
\]

取 zero query prefix 和固定 binary serialization，使 canonical proof 的前缀就是
\(B\)。考虑 \(q\) 次 AVOID generator 调用
\[
  G_t:\{0,1\}^{k_t}\longrightarrow\{0,1\}^{2k_t},
  \qquad
  |G_t|\le k_t^4,
  \qquad 1\le t\le q.
\tag{433.2}
\]
令
\[
  L_t:=k_t+r+\ell,
\tag{433.3}
\]
其中 \(r\) 是 deterministic-recompile 后保留的 source-round/query 参数。
C363 的 source-specific perfect-completeness simulator 给出一个固定常数
\(c_0\)，使得若第 \(t\) 次 Solve 失败，则
\[
  \operatorname{CC}(B)\le C_0L_t^{c_0}.
\tag{433.4}
\]

对第 \(t\) 次调用，记 \(\Pi\) 为固定 binary proof，\(H_t\) 为其 JK
recursion depth。C416 的 prefix-first-failure bound 可写成
\[
  \operatorname{CC}(B)
  \le
  C_1\left(
    (|G_t|+k_t)\log\!\left(\frac{|\Pi|}{k_t}+2\right)
    +\log(|\Pi|+2)
  \right)
\tag{433.5}
\]
只要首个 outsider 的 canonical ancestry 与 \(B\) 不相交。常数 \(C_1\) 吸收
padding、地址算术和固定 tie-break 的开销。

因此本 gate 的 forcing 假设应明确包含两种 easy branch：
\[
  S>
  \max\!\left\{
    C_0\max_{1\le t\le q}L_t^{c_0},\;
    C_1\max_{1\le t\le q}
    \left[
      (|G_t|+k_t)\log\!\left(\frac{|\Pi|}{k_t}+2\right)
      +\log(|\Pi|+2)
    \right]
  \right\}.
\tag{433.6}
\]

## 定理 433.1（small-width AVOID block-exposure Closure Gate）

在设置 (433.1)--(433.6) 下：

1. 每一次 Solve 调用都必须成功输出一个不在
   \(\operatorname{Range}(G_t)\) 中的 outsider；

2. 每个调用返回的首 outsider \(y_t\) 都满足
   \[
     \mathsf A_t(y_t)\cap[1,b]\ne\varnothing ,
\tag{433.7}
\]
   其中 \(\mathsf A_t(y_t)\) 是按 C416 定义的 canonical top-block ancestry；

3. 若所有 attached outsiders 通过一个 shared half-lift DAG 精确覆盖整个
   parent \(B\)，则存在 fan-in-two circuit 满足
   \[
   \operatorname{CC}(B)
   \le
   O\!\left(
      s_{\rm ctrl}+d
      +2\sum_{t=1}^{q} k_t
      +\sum_{u\in V_{\rm int}}
        \bigl(
          |G_{\tau(u)}|+k_{\tau(u)}+\log(b+2)
        \bigr)
   \right),
\tag{433.8}
\]
   从而也有较粗的界
   \[
   \operatorname{CC}(B)
   \le
   O\!\left(
      s_{\rm ctrl}+d+2\sum_{t=1}^{q}k_t
      +v\max_t\bigl(|G_t|+k_t+\log(b+2)\bigr)
   \right),
\tag{433.9}
\]
   其中 \(V_{\rm int}\) 是不同的 internal half-lift nodes，
   \(v=|V_{\rm int}|\)，\(\tau(u)\) 标记 node \(u\) 所使用的 generator，
   \(d\) 是显式 descriptor，\(s_{\rm ctrl}\) 是 address-control circuit
   的大小。

### 证明

若某次 Solve 失败，则 (433.4) 与 (433.1)、(433.6) 矛盾，故得到结论 1。
若首 outsider 的 ancestry 与 \([1,b]\) 不相交，则 (433.5) 与同一 forcing
bound 矛盾，故得到结论 2。

对结论 3，按 shared DAG 的拓扑序展开。第 \(t\) 个 terminal outsider 的
\(2k_t\) 个 payload bits 进入 evaluator，数据选择和 offset 选择合计付出
\(O(2k_t)\)。若 internal node \(u\) 的 predecessor 为 \(z\)，方向为
\(\epsilon\in\{0,1\}\)，则
\[
  z_u=G_{\tau(u),\epsilon}
       \bigl(\operatorname{half}_{\epsilon}(z)\bigr).
\tag{433.10}
\]
一次这样的 half-lift、固定 wire control 和地址边界处理可由
\[
  O\!\left(|G_{\tau(u)}|+k_{\tau(u)}+\log(b+2)\right)
\]
个 fan-in-two gates 实现。相同 internal node 被任意多条地址路径复用时只展开
一次。最后接入显式的 \(s_{\rm ctrl}\)-size selector，读取 descriptor \(\sigma\)
的成本计入 \(d\)，并按 block-coverage 假设输出 \(B[a]\) 对每个
\(a\in[b]\)。这给出 (433.8)，再取最大值即得 (433.9)。证毕。

## 地址尺度推论

若
\[
  k_t,r,\ell,q,v,d,s_{\rm ctrl}
  \le(\log(b+2))^{O(1)}
  \quad\text{for all }t,
\tag{433.11}
\]
且 \(|G_t|\le k_t^4\)，则 (433.9) 右端为
\(\operatorname{polylog}(b)\)。因此在
\[
  \operatorname{CC}(B)=\Omega\!\left(\frac{b}{\log(b+2)}\right)
\tag{433.12}
\]
的 forcing regime 中，任何 exact whole-parent binding 都必须退出至少一个
条件：terminal payload 或 terminal 数量达到 message scale，DAG/control 达到
forcing scale，descriptor 携带 message-scale 信息，或 attachment 不是
可编译的 canonical half-lift DAG。

## 量词边界

式 (433.7) 只说首 outsider 的 ancestry 与 \(B\) 相交；它不说已经恢复了整个
\(B\)，也不自动给出一个跨多个 \(2k_t\)-bit blocks 的 common selector。
“attached outsiders 精确覆盖整个 parent”是额外的 Closure Gate，不能从
“同一个 proof”或“共享同一 ancestry”一句话推出。

定理 433.1 只覆盖 generator-labelled shared half-lift DAG。一个直接联合多个
outsider、使用非局部代数约束、或从 proof 的其他坐标计算 \(B\) 的新关系，只要
不能展开成 (433.10)，就不在本定理范围内；它必须作为新的 non-half-lift global
relation 单独给出证明。反过来，把完整 parent 藏在未计费的 selector、sheet
index 或 descriptor 中，不是 address-scale closure，而是 (433.8) 中的
message-scale payment。

## 与 \(P\ne NP\) 的关系

本 note 是一个新的、RW-specific 的 Closure Gate：它把 small-width
AVOID 的二分、首失败位置附着和 whole-parent half-lift 覆盖放在同一条可检验
链上。它没有证明 actual RW instance 一定满足 whole-parent coverage，也没有
证明 non-half-lift global relation 不存在。因此它不证明 \(P\ne NP\)；真正的
最终矛盾仍需把一个实际 canonical \(B\) 通过 address-scale evaluator 放进
\(P/\mathrm{poly}\)，并与同一 \(B\) 的 forcing lower bound 在相同长度集合上对齐。

## 来源

* [C363](363-rw-reconstruction-width-round-conservation-2026-08-18.md)：失败的
  Solve 调用在 \(P=NP\) 下给出小电路；
* [C416](416-rw-prefix-first-failure-output-attachment-under-p-equals-np-2026-08-19.md)：
  fixed serialization 下首 outsider 的 parent attachment；
* [C417](417-rw-shared-half-lift-dag-parent-binding-2026-08-19.md)：共享
  half-lift DAG 的 parent-circuit payment。
