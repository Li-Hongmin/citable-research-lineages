> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW logical-scale collapse boundary（2026-08-19）

## 本轮改变的判断

本项目此前已经记录了 object-scale 与 address-scale 的区别，但还没有把它直接
代入 Ren--Williams Theorem 4.3--4.5 产生的最终 hard language。原文递推给出的
输入对象大小是 \(N=2^{\Theta(m)}\)，其中 \(m\) 才是最终语言的逻辑地址长度。
因此，\(P=NP\) 下把 SAT/prMA 查询在其**显式对象长度**上确定化，只能得到
\(2^{O(m)}\) 时间（以及相应的 \(\mathrm{EXP}/1\) 电路上界），并不得到
\(m^{O(1)}\) 的 \(P/\mathrm{poly}\) evaluator。

这把 Gate III 的缺口改写成一个可核验的 source-level 命题：若不再证明一个
真正按 \(m=\log N\) 运行的 random-access evaluator，RW 的已发表递推与
\(P=NP\) 确定化本身不会闭合最终矛盾。

## 定理 431.1（RW 逻辑地址尺度的条件性坍缩边界）

令 \(G_{2^m}\) 是 Ren--Williams Theorem 4.3 使用的 truth-table generator，
令 \(B_m\in\{0,1\}^{2^{m+1}}\) 表示其 AVOID 输出，并令
\(\mathcal L\) 是 Theorem 4.5 的 bit language：输入 \(a\in\{0,1\}^m\) 指定
\(B_m\) 的一个坐标（固定一位的 off-by-one 约定不影响结论）。假设：

1. \(P=NP\) 下，Theorem 4.1 的固定格式 smart-prMA 查询可在其**显式查询编码**
   长度 \(q\) 的 \(q^{O(1)}\) 时间内确定化；
2. 使用原文 Theorem 4.3 的递推
   \[
     n_{i+1}=n_i^C,\qquad T_i=\max\{2^{cD^i n_0},n_{i+1}\},
     \qquad r_i=O(n_i),
   \]
   以及它的单比特 advice 选择 \(A_0/A_1\)。

则在 \(P=NP\) 假设下：

* 稳定 solver 分支 \(A_0\) 在逻辑输入长度 \(m\) 上运行于 \(2^{O(m)}\) 时间；
* 在其 smartness 保证成立的 failure 长度，逐位 reconstruction 分支 \(A_1\)
  也在 \(2^{O(m)}\) 时间内输出 \(B_m\)；
* 由原文的一位 advice 选择得到
  \[
    \mathcal L\in\mathrm{EXP}/1\subseteq\mathrm{EXP}/\mathrm{poly},
    \qquad
    \operatorname{CC}(B_m)\le 2^{O(m)}.
  \tag{431.1}
  \]

因此，Theorem 4.5 的 near-maximum 下界

\[
  \operatorname{CC}(B_m)>\frac{2^m}{\operatorname{poly}(m)}
\tag{431.2}
\]

与这个 object-scale 上界相容，不产生 \(P=NP\) 矛盾。

### 证明

对稳定分支，原文先给出 \(B_i\) 的 `Solve` 运行时间至多 \(T_i^D\)，并在稳定
尾部有 \(T_i=n_{i+1}=n_i^C\)。最终语言的输入长度 \(m\) 只记录
\(B_m\) 的地址，而相应的显式 AVOID 实例长度为 \(n_i=2^{\Theta(m)}\)。
故 SAT 查询在假设 1 下被替换后，\(A_0\) 的总时间仍为
\(n_i^{O(1)}=2^{O(m)}\)。

对 failure 分支，Theorem 4.1 给出每个 `Recon`\(_i(j)\) 的确定性开销
\(\operatorname{poly}(n_{i+1},r_i,\log T_i)\)，且一次重构调用只使用 smart
查询。由 \(r_i=O(n_i)\)、\(n_{i+1}=n_i^C\) 和 \(n_i=2^{\Theta(m)}\)，
每个调用以及全部 \(2n_i\) 个输出位的总开销仍是 \(2^{O(m)}\)；假设 1
只把每个查询替换为其显式长度的多项式时间确定过程，不改变这个尺度。

原文把一位 advice \(\alpha_n\) 用来选择 \(A_0\) 或 \(A_1\)：非 good 长度取
\(\alpha_n=0\)，只调用 \(A_0\)；在 good failure 长度取 \(\alpha_n=1\)，此时
\(A_1\) 的所有查询均在 promise 内。于是同一 advice 选择在逻辑输入长度 \(m\)
上给出 \(2^{O(m)}\)-时间算法，编译为大小 \(2^{O(m)}\) 的电路，得到
\(431.1\)。而 \(431.2\) 只排除 \(2^m/\operatorname{poly}(m)\) 大小，仍低于
一般的 \(2^{O(m)}\) 上界。证毕。

## 推论 431.2（真正的 address-scale 闭合条件）

若在同一个 canonical \(B_m\) 上另有一个统一、same-proof、single-valued 的
evaluator，其地址、descriptor、collapsed query 以及控制状态长度和运行时间均为
\(m^{O(1)}\)，则 \(P=NP\) 下抽样/阈值化或直接确定化给出

\[
  \operatorname{CC}(B_m)\le m^{O(1)}.
\tag{431.3}
\]

这才与 \(431.2\) 矛盾。换言之，原文 `Solve`/`Reconf` 的 smartness 只有在
\(n_i=2^{\Theta(m)}\) 的对象尺度上确定化；要进入 \(431.3\)，必须新增一个
按 \(m=\log |B_m|\) 工作的 RW-specific block/word accessor，或一个等价的
single-valued PH surface。

## 量词与边界

* 该结论使用的是 Theorem 4.3--4.5 的实际 truth-table generator 和一位 advice，
  不是对任意 \(G_q\) 的 generic universal-gate 归约。
* 它不把逐地址 \(\forall a\,\exists C_a\) 改写成一个共同 proof；failure 分支的
  smartness 只在原文保证的 good lengths 上被使用。
* 它不声称 \(\mathrm{EXP}\not\subseteq\mathrm{P/poly}\)，也不证明 \(P\ne NP\)。
  它只证明：若不增加 address-scale 结构，现有 RW 递推至多到
  \(\mathrm{EXP}/1\) 这一层。

## 来源

* Ren--Williams, TR26-118 revision 1, Theorems 4.1--4.5；本地抽取见
  `units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md`
  第 14--20 页。
* [RW succinct smart reconstruction closure theorem](204-rw-succinct-smart-reconstruction-closure-theorem-2026-08-17.md)。
* [RW scale-complete Closure Audit](358-rw-scale-complete-closure-audit-2026-08-18.md)。
* [Nonuniform succinct universal-gate boundary](430-nonuniform-succinct-universal-gate-boundary-2026-08-19.md)。
