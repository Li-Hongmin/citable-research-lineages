> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Imperfect completeness does not lower the growing-locality threshold (2026-08-17)

## Contribution

Note 243 closes imperfect completeness for fixed branch locality whenever the
correct and wrong branches have a fixed positive gap. The same amplification
leaves the first growing-locality threshold unchanged: a binary near-linear
construction with gap \(\alpha-\beta\ge\gamma_0>0\) must have branch locality
of order at least \(\log\log k\), up to the
\(\log\log\log k\) correction already present in the perfect-completeness
analysis.

## Theorem

Fix \(0<\rho<1\), \(\gamma_0>0\), and \(c>0\). Consider binary shared-proof
interfaces with branch locality \(r=r(k)\), satisfying the hypotheses of
note 243 with

\[
  \alpha-\beta\ge\gamma_0
\]

for all sufficiently large \(k\). If

\[
  N:=k+P\le k(\log k)^c
\tag{244.1}
\]

for infinitely many sufficiently large \(k\), then

\[
  r(k)\ge
  \frac{1}{t(\gamma_0)}
  \left(
    \log_2\log k-\log_2\log\log k
  \right)-O_{\rho,\gamma_0,c}(1),
\tag{244.2}
\]

where \(t(\gamma_0)=O(1/\gamma_0^2)\) is a constant repetition count.

Equivalently, if

\[
  r(k)\le
  \frac{1}{t(\gamma_0)}
  \left(
    \log_2\log k-\log_2\log\log k
  \right)-\omega(1),
\]

then no such near-linear family exists.

## Proof

### 1. Amplification

Apply the threshold amplification from note 243 with
\(t=t(\gamma_0)\) repetitions. The inline decoder is a binary weak adaptive
RLDC with completeness at least \(2/3\), wrong-output probability at most
\(1/3\), constant radius \(\delta_0=\delta_0(\rho)\), and branch locality
\[
  r':=t\,r(k).
\tag{244.3}
\]

### 2. Decision-tree expansion

For each fixed random tape, each amplified branch is a binary adaptive tree of
depth at most \(r'\). Querying the inline bit and the union of both branch
trees produces a non-adaptive decoder with
\[
  Q:=1+2(2^{r'}-1)
\tag{244.4}
\]
queries, preserving completeness, soundness, and radius. If the right-hand
side of (244.4) exceeds \(N\), the decoder can simply query the whole word;
in that case \(2^{r'}=\Omega(N)\ge\Omega(k)\), which is already stronger than
(244.2). Hence it suffices to consider \(Q\le N\).

### 3. GGS contradiction below the threshold

The non-adaptive arbitrary-code RLDC bound of
Goldberg--Gur--Saraogi gives, with \(\sigma=2/3\),
\[
  N\ge
  \left(
    \frac{\sigma^2 k}
    {38Q^4\log^2 k}
  \right)^{1+1/\lceil Q/\sigma\rceil},
\tag{244.5}
\]
provided \(\delta_0>N^{-\sigma/(2Q)}\). The binary alphabet contributes only
a constant \(\log^2 2\) factor.

Put \(g=\log k/\log\log k\). Suppose, for a sufficiently small constant
\(\eta=\eta(\rho,\gamma_0,c)>0\), that \(Q\le\eta g\). Since \(N\ge k\),
\[
  N^{-\sigma/(2Q)}
  \le
  \exp\!\left(
    -\frac{\sigma\log k}{2\eta g}
  \right)
  =
  (\log k)^{-\sigma/(2\eta)}
  <\delta_0
\]
for all sufficiently large \(k\), so the radius condition in (244.5) is
valid.

Writing \(a=\lceil Q/\sigma\rceil\), taking logarithms in (244.5), and using
(244.1), yields
\[
  \frac{\log k}{a}
  \le
  c\log\log k+O(\log Q+\log\log k)
  =
  (c+O(1))\log\log k.
\tag{244.6}
\]
On the other hand \(a\le 2\eta g/\sigma\) for large \(k\), so
\[
  \frac{\log k}{a}
  \ge
  \frac{\sigma}{2\eta}\log\log k.
\tag{244.7}
\]
Choosing \(\eta\) smaller than the reciprocal of the constant in (244.6)
gives a contradiction. Therefore
\[
  Q=\Omega_{\rho,\gamma_0,c}\!\left(\frac{\log k}{\log\log k}\right).
\tag{244.8}
\]

Finally, (244.4) and \(r'=t r(k)\) imply
\[
  2^{t r(k)}=\Omega\!\left(\frac{\log k}{\log\log k}\right),
\]
which is exactly (244.2).
\(\square\)

## Boundary

This closes the entire sub-threshold growing-locality region for a fixed
positive branch gap, including imperfect honest-proof completeness. The
remaining regimes are genuinely different:

* the branch gap \(\alpha-\beta\) vanishes with \(k\), so \(t(\alpha-\beta)\)
  is no longer constant;
* the locality lies in the threshold window
  \(r=\Theta(\log\log k)\);
* the proof alphabet grows with \(k\);
* or the verifier does not provide independently resamplable branch
  acceptance events.

The result is a RW/JK application of the existing RLDC lower bound, not a new
coding lower-bound proof.

## Sources

* [note 243](243-imperfect-completeness-gap-closure-by-amplified-rldc-2026-08-17.md)
  for threshold amplification and the constant-gap imperfect-completeness
  compiler.
* [note 242](242-growing-query-threshold-for-near-linear-closure-2026-08-17.md)
  for the explicit GGS threshold calculation and its radius-condition check.
* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for Relaxed
  Locally Decodable Codes via Robust Daisies*, arXiv:2511.21659, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.
