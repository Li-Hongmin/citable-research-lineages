> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha auxiliary factorization does not supply a local parent inverse（2026-08-18）

## 本轮判定

对 published RW Theorem 3.5 的实际 Harsha 实例，auxiliary proof 不是一个可以
任意忽略的 pad；诚实 proof 有明确的代数因子分解。但是该因子分解仍没有给出
从一个 auxiliary block、公开坐标和短 descriptor 到 output/history 的局部逆。
因此 C388 的 pad 保持性 barrier 不能直接冒充 published RW 的实际 auxiliary
不可能性；真正能从原文推出的新结论是一个**source-specific factorization /
quantifier-separation gate**。

## 原文中的实际诚实 proof

令 \(C_x\) 是 RW Lemma 3.2 为输入 \(x\) 产生的 Circuit-SAT 电路，令
\(\alpha_x\) 是 Theorem 3.5 证明中选取的 lexicographically largest satisfying
assignment，\(\widetilde A_x\) 是它的 Reed--Muller encoding。Harsha thesis
Section 5.4.1 的 Proposition 5.4.1 定义了多项式变换

\[
  q\longmapsto p(q),\qquad
  p(q)(x_1,\ldots,x_{3m+3})
  =
  \widehat C(x_1,\ldots,x_{3m+3})
  \prod_{j=1}^{3}\bigl(q(x_{(j-1)m+1},\ldots,x_{jm})-x_{3m+j}\bigr).
\tag{389.1}
\]

对诚实 witness，可以选取

\[
  P_x=p(\widetilde A_x).
\]

Section 5.3.2 的 zero-on-subcube verifier 使用 \(P_x\) 的逐变量除法链
\((P_{x,1},\ldots,P_{x,m},Q_{x,1},\ldots,Q_{x,m})\)，并把这些函数 bundle 成
\(\Pi_{\mathrm{ZOS},x}:F^{{3m+3}}\to F^{6m+6}\)。因此，在 Harsha 的大字母表
表示下，诚实 proof 可写成

\[
  \Gamma_x
  =
  \bigl(\widetilde A_x,\;P_x,\;\Pi_{\mathrm{ZOS},x}\bigr).
\tag{389.2}
\]

Section 5.4.3 的二元化再附加 \(\Upsilon_x=\mathrm{ECC}(\Gamma_x)\)，所以在
固定 source-compatible serialization 下，RW 使用的诚实 proof 具有形式

\[
  \Pi_x
  =
  \operatorname{Bin}\!\left(
      \widetilde A_x,\,
      p(\widetilde A_x),\,
      \operatorname{ZOS}\!\left(p(\widetilde A_x)\right),\,
      \operatorname{ECC}(\Gamma_x)
  \right).
\tag{389.3}
\]

这确认了 C388 的边界：actual Harsha auxiliary construction 不是被 verifier
忽略的自由 pad，而是由所选 honest witness 经过固定完整性构造得到的 proof
completion。

## 但 source theorem 没有给出局部逆

RW Theorem 3.4 的 soundness 量词是：对**任意** proof
\(\Pi=(\widetilde w,\Pi')\)，若 verifier 接受概率超过 \(1/2\)，则
\(\widetilde w\) 接近某个合法低度 witness；这里 \(\Pi'\) 只作为任意 auxiliary
oracle 被量化，source statement 没有要求

\[
  \Pi'=
  \operatorname{Aux}_{\mathrm{Harsha}}(\widetilde w)
  :=
  \bigl(p(\widetilde w),\operatorname{ZOS}(p(\widetilde w))\bigr).
\tag{389.4}
\]

Theorem 3.5 继承的 soundness 结论也只把 systematic polynomial
\(\widetilde w'\) 的 prefix 与 output 联系起来；它没有推出对任意 auxiliary
位置 \(v\) 存在

\[
  \operatorname{out}(\alpha_x)
  =
  D\!\left(\Pi_x[v],\,v,\,\sigma_x\right)
\tag{389.5}
\]

的统一、地址尺度函数 \(D\)。式 (389.3) 是一个**正向生成式**，不是
source-level 的随机访问或可逆性定理；尤其 \(\operatorname{ZOS}\) 部分可依赖
整个 \(P_x\) 的除法链，而不是某个 output 坐标的局部值。

## 可无条件提取的唯一 payload bound

若人为构造一个同一 Harsha construction 下的 parent family
\(\mathcal B\)（固定 auxiliary 坐标、path metadata 与 serialization），并让
一个 first-failure block 暴露 \(2k\) bits、descriptor 暴露 \(d\) bits，则无论该
block 位于 \(P\)、\(\Pi_{\mathrm{ZOS}}\) 还是二元 ECC 区段，exact parent binding
都必须满足

\[
  2k+d\ \ge\ \log_2|\mathcal B|.
\tag{389.6}
\]

这是 block-channel 的信息容量结论；它并不使用 auxiliary 的 verifier-ignored
假设。它只有在能把 published singleton RW call 提升为足够大的 actual parent
family 时，才会成为对 Closure 的直接 barrier。published Theorem 4.3 当前固定
\(x_0\) 并只调用一个 \(f_i(x_0)\)，所以 (389.6) 不能被自动套用到该 singleton
调用。

## Gate-I 的精确剩余接口

原文核验后，Gate-I 不再是“auxiliary 是否可能是任意 pad”，而是必须在以下
两条中至少完成一条：

1. **实际逆定理：** 对 Harsha 的具体 \(\operatorname{Aux}_{\mathrm{Harsha}}\)，
   证明某个 first-failure block/path 具有 address-scale、target-separated
   fingerprint，并给出 \(D\) 或 whole-parent evaluator；
2. **实际 family/容量定理：** 构造一个同一 serialization 下的 sufficiently
   large RW parent family，证明 auxiliary/ECC block 与 descriptor 只携带
   (389.6) 的 payload，从而排除 address-scale exact binding。

C388 仍然关闭“只从 Theorem 3.5 抽象 bullets 免费得到 auxiliary parent map”的
黑箱路线；C389 则说明即使读取 Harsha 的实际 semantics，也只得到 (389.3)
的正向 factorization，不能把它误写成局部逆或 \(P\ne NP\) 证明。

## 证据边界

* RW TR26-118 revision 1：Theorem 3.4、Theorem 3.5、Theorem 4.1，以及
  Theorem 3.4 proof sketch 对 \( \widetilde A,P,\Pi_{\mathrm{ZOS}}\) 的说明。
* Prahladh Harsha, *Robust PCPs of Proximity and Shorter PCPs*, MIT PhD thesis
  (2004), Sections 5.3.2, 5.4.1, 5.4.3，尤其 Proposition 5.4.1 和 Lemma 5.4.4。
* 这是 actual-source factorization 与量词边界；不声称已证明
  \(\operatorname{Aux}_{\mathrm{Harsha}}\) 不可逆，也不声称 published RW 已具有
  或不具有 output attachment。
* 因而它不是 \(P\ne NP\)、一般 dPCP/RLDC 不可能性，或对所有新 PCP 构造的
  lower bound。

## 来源

- Ren--Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin-Arthur Queries*, ECCC TR26-118, revision 1:
  <https://eccc.weizmann.ac.il/report/2026/118/revision/1/download>.
- Harsha thesis record:
  <https://dspace.mit.edu/handle/1721.1/26720>.
