> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Linear projection-robust ACRR implies an RLDC lower bound (2026-08-16)

## 目的

把“ACRR 可能跨入 RLDC/LDC 代价区间”变成一个精确的受限模型定理。结论不声称
一般 ACRR 是线性的；它说明：只要 proof symbols 本身形成线性编码，且同一个局部
test/decoder 对近码字给出 coordinate-robust rejection，那么该对象已经是 RLDC，
可直接套用线性 RLDC 下界。

## 定义：linear projection-robust proof code

令
\[
  C:\{0,1\}^{k}\to\Sigma^{N}
\]
是一个线性编码（对二元消息，坐标可嵌入有限域字母表）。一个
`(q,\delta,\sigma)` projection-robust proof code 包含：

- 一个至多 `q` 次查询、且查询位置不依赖已读符号的随机局部测试 `T`；
- 对每个 `i∈[k]`，一个至多 `q` 次查询、且非自适应的局部 decoder `D_i`，输出
  `0,1,⊥`；
- 同一个 proof/codeword address space `Σ^N`，不允许按坐标更换 proof。

要求：

1. **完备性：** 对所有 `m`，`T(C(m))=1` 且 `D_i(C(m))=m_i` 恒成立；
2. **坐标鲁棒性：** 定义组合 decoder `B_i`：先运行 `T`，若拒绝则输出 `⊥`，否则运行 `D_i`。
   若 `y` 与 `C(m)` 的距离至多 `δ`，则对每个 `i`，
   \[
     \Pr[B_i^y(i)\in\{m_i,\bot\}]\ge \sigma;
   \]
3. **测试/解码的统一性：** 查询分布、decoder 和 proof 地址由 `(i, randomness)`
   统一生成，不使用依赖 `m` 的 advice 或完整 history。

这里把 `T` 单列出来，是为了允许 verifier 先检查局部一致性再输出 `⊥`；若 `D_i`
本身已经包含测试，取 `T` 为恒真即可。总查询数若需同时调用 `T` 和 `D_i`，记为
`q_tot≤q_T+q_D`。

## 定理：受限 ACRR 到 RLDC 的精确归约

上述对象本身就是一个**非自适应** `(q_tot,δ,σ)`-RLDC（把 `T` 的拒绝映射为 `⊥`）。因此，
若 `C` 为二元线性编码且 `q_tot` 为常数，则对充分大的 `k` 有
\[
  N \ge
  \left(\frac{\sigma^2 k}
  {38q_{\rm tot}^4\log^2|\Sigma|\,\log^2 k}\right)^{1+1/\lceil q_{\rm tot}/\sigma\rceil},
\]
在标准常数参数 `σ=2/3, δ=Ω(1), |Σ|=O(1)` 下，
\[
  N=k^{1+\Omega(1/q_{\rm tot})}.
\]
特别地，若 `N=O(k)`，则
\[
  q_{\rm tot}=\Omega(\log k/\log\log k).
\]

### 证明

把 proof/codeword `C(m)` 作为 RLDC 的 codeword。给定 oracle `y` 和 index `i`，
运行组合 decoder `B_i^y(i)`。完备性与坐标鲁棒性分别正是 RLDC 的完备性和 relaxed
local decoding 条件。线性条件保持不变。于是直接应用 Goldberg--Gur--Saraogi 的
线性 RLDC 下界：
其定理对非自适应 `q_tot`-query `(q_tot,δ,σ)`-RLDC 给出上述显式公式，标准参数下推出
`N=k^{1+Ω(1/q_tot)}`。

## 对 ACRR 的含义

这给出一个真正的、但明确受限的 impossibility theorem：

> 若 RW 所需的 projection-robust PCPP 能被实现为线性 proof code，且其
> coordinate-robust verifier 对常数比例 corruption 仍满足统一 `⊥` 语义，
> 则固定常数查询与近线性长度不可能同时成立。

因此任何近线性、固定小查询的正面构造必须至少逃出一个条件：

1. proof/code 非线性；
2. verifier 自适应或不满足该 RLDC 形式；
3. 只有平均/list soundness，没有逐坐标 corruption robustness；
4. proof symbols 不是可复用的单一 codeword，或使用额外非均匀信息。

这不是一般 ACRR 的下界：非线性 proof 不能直接套该定理，普通 dPCP 也不自动提供
RLDC 的近码字语义。它却把“构造 vs. 下界”的顶级路线切成一个精确边界，而不是
停留在类比层面。

## 与现有材料的关系

- note 174 给出了从坐标鲁棒 verifier 到 RLDC 的条件接口，但未写出线性下界的
  明确参数定理；本 note 完成该拼接。
- note 176 将 GM 的 `k^2 polylog(k)` RLDC 作为非线性/relaxed 基准；本 note 说明
  线性近线性目标的受限版本已经被 GGS 下界封住。
- note 177 的 projection-robust PCPP 接口若能额外证明线性 proof/code，立即落入
  本定理；否则必须明确其非线性来源与代价。

## 证据边界

GGS 的公开定理针对线性 RLDC，并明确给出
\[
N\ge\left(\frac{\sigma^2 k}
{38q^4\log^2|\Sigma|\log^2 k}\right)^{1+1/\lceil q/\sigma\rceil}.
\]
本 note 的新内容是把一类 projection-robust ACRR 的语义逐项映射到该定义；不把
这个受限结果外推为一般 nonlinear ACRR impossibility。

## 来源

- [Goldberg--Gur--Saraogi, Theorem 1 and Corollaries 2--3](https://arxiv.org/html/2511.21659)
- [Gur--Minzer--Weissenberg--Zheng, RLDC/PCPP interface](https://arxiv.org/html/2512.12960)
- [note 174: average-to-coordinate separation](174-average-to-coordinate-separation-and-rldc-interface-2026-08-16.md)
