> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha/RW source-level closure trichotomy（2026-08-19）

## 本轮改变的判断

C408、C445、C446 现在可以组成一个完整的 **published Harsha/RW source-level
barrier theorem**。在 Harsha 的实际 oracle representation 内，试图把 RW 的
canonical history 接到 address-scale Closure 的方案只有三类：

1. 显式保留 \(P\) 或 \(\Pi_{\mathrm{ZoS}}\) 的 oracle table，支付
   \(N^{18+o(1)}\) proof length；
2. 保留 factorized \(P=p(q)\) 并给出 generic-point evaluator，支付 parent 的
   forcing-scale circuit complexity（C446）；
3. 把 oracle table 压缩成 target-dependent descriptor，支付 family entropy 或
   singleton forcing-scale advice（C445/C207）。

若三者都不发生，方案已经离开 published Harsha factorized/source interface，必须
另证一个新的 non-product global relation。这个 trichotomy 不是一般 dPCP
不可能性；它是对 RW/Harsha 核心 source chain 的严格 closure 分类。

## 定理 447.1（published Harsha/RW source-level closure trichotomy）

令 \(C\) 是 Harsha reduction 作用的电路，大小为 \(N\)，并取原始最小字段参数

\[
 m=\left\lceil\frac{\log N}{\log\log N}\right\rceil,\qquad
 |F|=\Theta\!\left((mN^{1/m})^3\right).
\tag{447.1}
\]

考虑一个声称在该 source representation 上完成 RW/JK address-scale closure 的
方案。假设它保留 Harsha 的 gate relation \(C'\)、低度延拓 \(\widehat C\) 和
assignment polynomial \(q\)，并且需要把 q 的 systematic/output coordinates
接到一个共同 proof/address space。则以下分支成立：

### (A) Explicit-oracle branch

若 binary proof 显式存储 \(P:F^{3m+3}\to F\) 或
\(\Pi_{\mathrm{ZoS}}:F^{3m+3}\to F^{6m+6}\) 的完整 field-symbol table，
则其 field-symbol 数至少为

\[
 |F|^{3m+3}
 =N^{18+o(1)},
\tag{447.2}
\]

并在显式常率 binary encoding 下仍为 \(N^{18+o(1)}\)。若同时存储两者，
还多一个 \(O(m)\) 因子。因而该 branch 不是 near-linear/address-scale proof。

### (B) Factorized-evaluator branch

若方案不显式存表，而用同一 serialization 上的 generic-point \(P=p(q)\)
evaluator，并且有 C439 所需的 \(\widehat C\)-evaluator、incidence map 和
output projection，则 C446 给出

\[
 \operatorname{CC}(B)
 \le
 \operatorname{poly}(m,|F|)
 \bigl(s_P+s_{\widehat C}+s_{\mathrm{Inc}}+s_{\mathrm{out}}+1\bigr).
\tag{447.3}
\]

所以对 forcing-hard parent，若前三个 source maps 是 address-scale，\(s_P\)
必须支付 forcing/object scale；若 \(s_P=\operatorname{poly}(m)\)，则直接进入
\(P/\mathrm{poly}\) 矛盾。

### (C) Descriptor-compressed branch

若 oracle table 不显式存储，而由一个共同 evaluator architecture 加
target-dependent descriptor \(\sigma\) 生成：

* 对高熵 assignment family，C445 给出
  \[
  \log|\mathcal Q_N|
  \le d+O(R(m,|F|)s\log(Rs+m+|F|));
  \tag{447.4}
  \]
  因而 near-linear descriptor/evaluator 不能覆盖
  \(\log|\mathcal Q_N|=\Omega(N)\) 的 family；
* 对 published singleton，C207 的 ROM expansion 给出 forcing-scale
  descriptor payment，只要 evaluator 对所有 output coordinates 共用一个
  finite-summary address interface。

### (D) Source-exit branch

若方案既不显式支付 (A)，也不满足 factorized \(P=p(q)\) 的 (B)，且 descriptor
也不落入 (C)，则它没有保持 published Harsha source interface。它必须明确给出
一个新的 non-product global relation，并重新证明 same-proof、same-word、
smartness、cover/bottom safety 和 address-scale；不能把该方案继续标记为
Harsha \(P\)-oracle closure。

## 证明

(A) 是 C408 的 oracle-table 计数。由 (447.1)，
\[
\log_N |F|^{3m+3}
=(3m+3)\left(3\frac{\log m}{\log N}+\frac{3}{m}\right)
=18+o(1),
\]
故 (447.2) 成立。

(B) 直接应用 C446：C439 的 \(O(|F|^3)\) field-point enumeration 把
generic \(P\)-evaluator 编译成 q-evaluator，再经 fixed output projection 得到
parent circuit。其 size overhead 只依赖 \((m,|F|)\) 与固定 source maps。

(C) family 分支应用 C445 的 evaluator-description counting；singleton 分支应用
C207 的 finite-ROM-to-circuit expansion。两者分别给出 entropy payment 与
forcing payment。

剩余所有实现方式都必须改变至少一个 source-level choice：不再显式使用 Harsha
oracle table、不再保持 \(P=p(q)\) factorization、或不再提供共同 descriptor/
address space。这正是 (D) 的 source-exit。证毕。

## RW closure 的直接推论

在 C444 的 cell-time serialization 下，\(\widehat C\) 和 equality/output
incidence 可以达到 address scale，但这只消除了 constraint-side 的一个接口；
定理 447.1 表明，published Harsha branch 的另一半不能同时保持 near-linear
proof 与短 \(P\)-accessor。于是 RW/JK 项目的正向突破必须是：

\[
\boxed{\text{一个不等于 Harsha }P=p(q)\text{ 的、仍具 same-word/address-scale
global relation}}
\]

或者证明该 non-product relation 也落入 Paper 05 的 RLDC/cover/descriptor
barriers。这个结论把“继续优化 Harsha proof table”从主攻路线中正式移出，
而把顶级攻击点收束到真正的新 PCP/coding mechanism。

## 证据边界

* 定理 447.1 只覆盖 published Harsha source representation 及其显式表、
  factorized evaluator、descriptor-compression 三类实现。
* 它不证明任意新 dPCP/global relation 不可能，也不证明 \(P\ne NP\)。
* \(N^{18+o(1)}\) 是显式 Harsha oracle table 的 source-level 尺度，不是所有
  可能 PCP proof 的下界。
* singleton 的 C207 分支仍依赖共同静态 descriptor、有限 ROM read 和同一对象
  的全地址一致性；交互式或真正 non-product relation 必须单独建模。

## 来源

* [note 408](408-rw-harsha-proof-length-exponent-audit-2026-08-19.md)。
* [note 439](439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md)。
* [note 444](444-cell-time-offset-regular-rw-unrolling-2026-08-19.md)。
* [note 445](445-harsha-auxiliary-oracle-entropy-transfer-barrier-2026-08-19.md)。
* [note 446](446-harsha-auxiliary-circuit-hardness-transfer-2026-08-19.md)。
* [note 220](220-rw-forcing-scale-advice-lower-bound-2026-08-17.md)。
