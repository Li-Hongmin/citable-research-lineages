> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Range membership 强制 hardness scale（2026-08-14）

## 结论

[note 082](082-time-dominating-blocks-have-locally-uniform-preimages-2026-08-14.md) 用显式 tableau
证明：放大 canonical decoder 的 input length \(q\)，可让 stitched truth table 的最后一个非零 block
进入 decoder range，并取得 compact gate-list accessor。该证明留下一个疑问：\(q\gg n^k\) 是否只是
\(O(R^2)\) tableau simulation 的技术损失。

答案是否定的。这个尺度差距不依赖 tableau size 或 direct-connection uniformity。设

\[
H=0^{2^n-2q}B,
\qquad |B|=2q,
\qquad \operatorname{CC}(H)>n^k,
\tag{1}
\]

其中 \(2q\le2^n\) 是二次幂，使最后一个 block 与 address suffix 对齐。

固定 canonical encoding，使每个 \(q\)-bit string \(u\) 都解码为一个 size 至多
\(A_{\mathrm{enc}}q/\log q\) 的 circuit \(C_u\)，invalid descriptions 也映到同尺度的固定 trivial
circuit。令 \(G_q(u)=TT(C_u)\)。只要

\[
B\in\operatorname{Range}(G_q),
\tag{2}
\]

就必有

\[
q=\Omega(n^k\log q).
\tag{3}
\]

因此任何让这个 hard block 真正进入 canonical range 的方法，都已经把 block scale 推过原
\(n^k\) hardness threshold。改进 tableau gate count 不能消除该障碍。

进一步，small gate-list accessor 只压缩 description，不压缩 evaluation。沿 stitched diagonal
\(k(n)\to\infty\)，若存在 fixed-exponent polynomial-size 联合 evaluator，能从同样 fixed-exponent
的 accessor 计算 \(B_n\) 的任一 truth-table bit，则 \(H_n\) 也有 fixed polynomial-size circuit，
直接违背 stitched hardness。

所以当前路线严格分成两个互不替代的接口：

\[
\boxed{
\text{compact description access}
\not\Rightarrow
\text{compact circuit evaluation}.}
\tag{4}
\]

这个 no-go 不证明 \(P\ne NP\)；它说明 note 082 的 locally uniform preimage 不能仅靠更好的
time-to-circuit simulation 变成最终 JK contradiction。

## Range-membership scale lemma

把 \(x\in\{0,1\}^n\) 写成 prefix 与最后

\[
m=\log_2(2q)
\]

个 bits。由式 (1)，若 \(B\) 有 size \(s\) circuit，则

\[
H(x)=
\bigl[x_1\cdots x_{n-m}=1^{n-m}\bigr]
\land B(x_{n-m+1},\ldots,x_n)
\tag{5}
\]

有 size \(s+O(n)\) circuit。因此

\[
\operatorname{CC}(B)>n^k-O(n).
\tag{6}
\]

另一方面，式 (2) 意味着存在合法 \(q\)-bit gate-list description \(u\)，其所编码 circuit
计算 \(B\)。按 canonical decoder 的最大 encoding budget，

\[
\operatorname{CC}(B)\le A_{\mathrm{enc}}\frac q{\log q}.
\tag{7}
\]

合并式 (6)--(7)，对 \(k\ge2\) 与充分大 \(n\)，

\[
A_{\mathrm{enc}}\frac q{\log q}>n^k-O(n)=\Omega(n^k),
\]

即得式 (3)。证明没有使用 \(B\) 的生成时间 \(R\)，也没有使用 tableau、oblivious simulation 或
gate-list 的 local uniformity。

这个结论还修正一个可能的错误优化方向。Pippenger--Fischer 蕴含 circuit-size consequence

\[
TIME(R)\subseteq SIZE(O(R\log R)),
\tag{8}
\]

这里只使用该 consequence，不判断原 simulation 是否具有 poly\((\log R)\)-time direct-connection
uniformity。仅由 size theorem 不能宣称这种 stronger property；当前项目也没有核验到它。即使额外
证明它，并把 note 082 的
\(O(R^2)\) gate count 降为 \(O(R\log R)\)，式 (3) 仍然成立，因为它只依赖 range budget 与
hardness。

## 为什么 JK easy bound 仍不矛盾

对 note 082 的 canonical decoder，JK/GGM easy reconstruction 给出的 theorem-level size bound 是

\[
O(|G_q|\log T).
\tag{9}
\]

RW Theorem 3.1 按假设使用一个语法 size \(|G_q|\ge q\) 的给定 circuit；不足时可加 dummy gates
padding。note 082 采用的安全实现给出 \(|G_q|=O(q^2\operatorname{polylog}q)\)。由式 (3)，
式 (9) 不是一个低于 \(n^k\) 的 upper bound，因而不能与 \(\operatorname{CC}(H)>n^k\) 矛盾。

这里的结论是“published upper bound 不足以认证 small circuit”，不是声称重建 circuit 的最小 size
必为式 (9)。若要继续，必须利用 \(G_q\) 或 selected descriptions 的额外结构，证明一个真正低于
\(n^k\) 的 specialised evaluation circuit；单纯缩短 description accessor 不够。

## Accessor-to-evaluation no-go

这里重新绑定 diagonal family：令

\[
k(n)=\lfloor\log_2\log_2 n\rfloor,
\qquad H_n=0^{2^n-2q_n}B_n,
\qquad B_n\in\operatorname{Range}(G_{q_n}),
\qquad \operatorname{CC}(H_n)>n^{k(n)}.
\]

设 \(u_{n,j}\) 是第 \(j\) 个 actual range block 所选的 gate-list description，并有一个 fixed
circuit family 给出联合 accessor

\[
A_n(j,\ell)=u_{n,j}[\ell]
\tag{10}
\]

且存在固定常数 \(c\)，使 \(|A_n|\le n^c\) 对所有充分大 \(n\) 成立；对 non-range occurrences 可
任意 totalize。这只说明可以快速读取 quasipolynomially large circuits 的 wiring。

假设进一步存在 fixed-exponent polynomial-size oracle circuit \(E_n^{A_n}\)，使用
\(Q(n)=\operatorname{poly}(n)\) 次 \(A_n\) calls，并在 actual selected range occurrences 上满足

\[
E_n^{A_n}(j,b)=G_{q_n}(u_{n,j})[b].
\tag{11}
\]

把 \(A_n\) 的 circuit 复制进每个 oracle gate，所得 ordinary circuit size 至多
\(|E_n|+Q(n)|A_n|=\operatorname{poly}(n)\)，且其 polynomial exponent 不依赖 \(k(n)\) 或 \(j\)。
对最后一个 block index \(j_*\)，式 (2) 与 (11) 给

\[
E_n^{A_n}(j_*,b)=B_n[b].
\]

再与式 (5) 的 prefix test 组合，就得到 \(H_n\) 的 fixed polynomial-size circuit。因为
\(k(n)\to\infty\)，这与 \(\operatorname{CC}(H_n)>n^{k(n)}\) 对充分大 \(n\) 矛盾。

故至少在当前 hard family 上，不可能同时拥有：

1. actual selected range descriptions 的 fixed-exponent polynomial-size 联合 accessor；
2. 对这些 descriptions 的 polynomial-size 联合 local evaluator。

## 对 auxiliary PCP 路线的含义

对 Ren--Williams proof

\[
\Pi=(\widetilde w,P,\Pi_{\mathrm{ZoS}}),
\tag{12}
\]

systematicity 只保留 raw witness coordinates。现有 theorem 保证完整 \(\Pi\) 可在总时间
\(\operatorname{poly}(|C|)\) 生成，不保证从 compact witness accessor 到 \(P\) 或
\(\Pi_{\mathrm{ZoS}}\) 的 compact per-coordinate prover。decodable PCP 的 local access direction
是从 proof
读取 witness symbol，也不是从 witness 局部生成 proof。

因此 auxiliary blocks 需要的正面接口必须显式强于 compact gate-list access，例如：固定 representation
下，prover coordinate 可由特殊低深度/稀疏依赖公式计算。若这种 prover structure 还能与
word-consistent recursive JK selector 及 polynomial-size local evaluation 组合成式 (10)--(11)，
则它不可能对当前 hard family 普遍成立。

### 来源与证据边界

原文核验日期：2026-08-14。

- Hanlin Ren and Ryan Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin-Arthur Queries*, ECCC TR26-118 revision 1, 2026, Theorems 3.1 and 3.4.
- Prahladh Harsha, *Robust PCPs of Proximity and Shorter PCPs*, PhD thesis, 2004, Sections 5.3--5.4.
- Irit Dinur and Prahladh Harsha, *Composition of Low-Error 2-Query PCPs Using Decodable PCPs*,
  preliminary version, FOCS 2009, Definitions 3.1--3.2.
- Nicholas Pippenger and Michael J. Fischer, *Relations among Complexity Measures*, JACM 1979,
  DOI `10.1145/322123.322138`；这里只使用 \(O(R\log R)\) circuit-size consequence，不归因
  未核实的 direct-connection uniformity。

式 (1)--(7) 与 (10)--(11) 是本项目的自足推论。关于 auxiliary PCP 的陈述只记录现有 theorem 没有给出
locally encodable prover；不把 absence from theorem 当成 impossibility proof。
