> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All-query bottom-or-LDC exponent for binary shared proofs (2026-08-17)

## Contribution

The message-inline compiler does not intrinsically depend on the branch locality
being even.  For every fixed branch query bound \(r\ge 2\), a binary,
target-relative shared-proof interface with positive radius and a fixed
half-radius no-bottom gap yields an \((r+1)\)-query binary LDC.  The standard
binary \(R\)-query LDC envelope

\[
  k\le \widetilde O(R,\rho,\varepsilon)\!\left(N^{1-2/R}\right),
  \qquad R\ge 3,
\]

therefore gives

\[
  N=k+P
  =\widetilde\Omega_{\rho,\varepsilon,r}
     \!\left(k^{(r+1)/(r-1)}\right).
\tag{237.1}
\]

For odd \(R\), the displayed envelope is the all-odd-query theorem of
Basu--Hsieh--Kothari--Lin; their introduction records that the same exponent
for even \(R\) was already known classically.  Thus the application below is
uniform in \(r\), while the external lower-bound provenance splits by the parity
of \(R=r+1\).

This is a scope correction and strengthening of note 236, not a claim of a new
general dPCP impossibility theorem.

## Shared-proof interface

Let

\[
  \Pi:\{0,1\}^{k}\longrightarrow\{0,1\}^{P}
\]

be a binary proof map.  For every message coordinate \(i\in[k]\) and claim
\(b\in\{0,1\}\), let \(V_{i,b}\) be a randomized, possibly adaptive verifier
making at most \(r\) proof queries.  Write \(p_{i,b}(z)\) for its acceptance
probability on received word \(z\).

Assume constants

\[
  0<\rho<1,\qquad 0\le\beta<\alpha\le1,
\]

such that

\[
  p_{i,m_i}(\Pi(m))\ge\alpha,
\qquad
  \operatorname{dist}(z,\Pi(m))\le\rho P
  \Longrightarrow
  p_{i,1-m_i}(z)\le\beta .
\tag{237.2}
\]

Define the half-radius two-branch mass

\[
  \tau_{\rho/2}:=
  \inf_{m,i}\ \inf_{\operatorname{dist}(z,\Pi(m))\le\rho P/2}
       \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr),
\tag{237.3}
\]

and

\[
  \varepsilon_0:=
  \max\{\beta,\;1-\tau_{\rho/2}+\beta\}.
\tag{237.4}
\]

The fixed-gap no-bottom hypothesis is
\(\varepsilon_0<1/2\).  It is stronger than merely requiring that one of the two
branches accept on an honest proof: it also rules out simultaneous rejection on
the entire half-radius neighborhood.

## Theorem (all fixed query localities)

For every fixed integer \(r\ge2\), under (237.2)--(237.4), every sufficiently
large \(k\) satisfies

\[
  k+P
  \ge
  \widetilde\Omega_{\rho,\alpha,\beta,\tau_{\rho/2},r}
       \!\left(k^{\frac{r+1}{r-1}}\right).
\tag{237.5}
\]

Equivalently, a binary near-linear common-proof construction at fixed branch
locality \(r\) must exhibit a half-radius bottom, let its radius or gap
degenerate, or leave the target-relative common-proof/address-space model.

### Proof

First, distinct proof words have relative distance greater than \(\rho\).  If
\(m\ne m'\) and
\(\operatorname{dist}(\Pi(m),\Pi(m'))\le\rho P\), choose \(i\) with
\(m_i\ne m'_i\).  Completeness for \(m'\) gives

\[
  p_{i,m'_i}(\Pi(m'))\ge\alpha,
\]

whereas (237.2), applied with target \(m\) and received word
\(z=\Pi(m')\), gives the same probability at most \(\beta\), a contradiction.

Inline the message:

\[
  C(m):=m\,\|\,\Pi(m),
  \qquad N:=k+P.
\tag{237.6}
\]

The binary Singleton bound applied to the \(2^k\) proof words implies, for all
sufficiently large \(k\),

\[
  \frac{P}{N}\ge\frac1{3-2\rho}.
\tag{237.7}
\]

Consequently \(C\) has constant relative distance at least
\(\rho/(3-2\rho)\).  Put

\[
  \delta_0:=\frac{\rho}{2(3-2\rho)}.
\tag{237.8}
\]

If \(y\) is within relative distance \(\delta_0\) of \(C(m)\), its proof suffix
\(z\) is within distance \(\rho P/2\) of \(\Pi(m)\).

To decode coordinate \(i\), first query the inline bit \(b=y_i\), then run
\(V_{i,b}\) on the proof suffix, and output \(b\) if that verifier accepts and
\(1-b\) otherwise.  This is a possibly adaptive \((r+1)\)-query decoder.

If \(b\ne m_i\), the selected branch is the wrong branch, so the decoder errs with
probability at most \(\beta\) by (237.2).  If \(b=m_i\), then

\[
  p_{i,m_i}(z)
  \ge \tau_{\rho/2}-p_{i,1-m_i}(z)
  \ge \tau_{\rho/2}-\beta,
\]

and hence the error probability is at most
\(1-\tau_{\rho/2}+\beta\).  The same estimate applies on the uncorrupted
codeword because it lies in the half-radius neighborhood.  Thus \(C\) is a
binary \((r+1)\)-query LDC with constant distance, constant radius, and error
at most \(\varepsilon_0<1/2\).

Let \(R=r+1\ge3\).  The standard binary \(R\)-query LDC lower bound gives

\[
  k\le \widetilde O\!\left(N^{1-2/R}\right).
\]

For odd \(R\) this is the all-odd-query theorem of
Basu--Hsieh--Kothari--Lin; for even \(R\) the same exponent is a classical
binary LDC bound, explicitly noted in their introduction.  Solving for \(N\)
yields

\[
  N\ge\widetilde\Omega\!\left(k^{R/(R-2)}\right)
   =\widetilde\Omega\!\left(k^{(r+1)/(r-1)}\right),
\]

which is (237.5).  \(\square\)

## Parameter profile

\[
\begin{array}{c|c|c}
r & R=r+1 & \text{proof length lower bound}\\
\hline
2 & 3 & \widetilde\Omega(k^3)\\
3 & 4 & \widetilde\Omega(k^2)\\
4 & 5 & \widetilde\Omega(k^{5/3})\\
5 & 6 & \widetilde\Omega(k^{3/2})\\
6 & 7 & \widetilde\Omega(k^{7/5})
\end{array}
\]

The \(r=2\) line is compatible with the sharper near-cubic
Gur--Minzer--Weissenberg--Zheng bound already used elsewhere in this unit.
For \(r=1\), the inline construction has two queries and the separate binary
weak-RLDC theorem gives the exponential bound recorded in notes 234--235.

## Scope and escapes

The proof uses exactly:

* one common binary proof map for all message coordinates;
* target-relative soundness on a positive-radius neighborhood;
* a fixed half-radius two-branch mass lower bound;
* a fixed finite branch locality \(r\).

It does not rule out larger alphabets, imperfect completeness, vanishing radius or
gap, ordinary average/list soundness, different proof/address spaces, unbounded
interaction, or a single-target construction with no injective message family.
It also does not establish that an arbitrary RW/dPCP interface satisfies the
hypotheses.  Its role in the Closure Theorem program is a uniform escape
classification: any proposed binary common-proof reconstruction must either use
bottom (or a degenerating parameter), or pay the displayed LDC proof-length cost.

## Sources

* A. Basu, J.-T. Hsieh, P. K. Kothari, and A. D. Lin, *Improved Lower Bounds for
  all Odd-Query Locally Decodable Codes*, arXiv:2411.14361, Theorem 1.1 and the
  introduction's even-query comparison:
  <https://arxiv.org/abs/2411.14361>.
* T. Gur, D. Minzer, G. Weissenberg, and K. Z. Zheng, *3-Query RLDCs are
  Strictly Stronger than 3-Query LDCs*, arXiv:2512.12960:
  <https://arxiv.org/abs/2512.12960>.
* A. R. Block et al., *Exponential Lower Bounds for 2-query Relaxed Locally
  Decodable Codes*, arXiv:2602.20278:
  <https://arxiv.org/abs/2602.20278>.
