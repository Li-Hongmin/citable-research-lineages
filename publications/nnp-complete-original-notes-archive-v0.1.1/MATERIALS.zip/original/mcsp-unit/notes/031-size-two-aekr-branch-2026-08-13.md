> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# AEKR 的 singleton / 二元 witness 分支（2026-08-13）

## 固定 cell 与固定 pair 的质量

令 (C=X\times Y)，其中 (X,Y\subseteq\mathbb F_2^n)。对均匀
(z=(r,t)\in\mathbb F_2^{n+1})，先取

\[
R_z=A_z\times B_z,
\qquad
A_z=\{x:r\cdot x=t\},
\qquad
B_z=\{y:r\cdot y=1-t\},
\]

再独立以 (1/2) 保留 (A_z,B_z) 中的行列。

对任意 cell (c)，

\[
\Pr[c\in R_z(U,V)]=\frac14\cdot\frac14=\frac1{16}.
\tag{1}
\]

对两个不同 cell (a=(x_1,y_1),b=(x_2,y_2))，若 (x_1=x_2)，则包含二者的参数方程含有三个独立约束

\[
r\cdot x_1=t,\qquad r\cdot y_1=1-t,\qquad r\cdot y_2=1-t;
\]

故参数 (z) 的质量至多 (2^{-3})，而 thinning 还需保留一个行、两个列，概率 (2^{-3})。若 (y_1=y_2)，同理。若行列均不同，thinning 概率为 (2^{-4})，参数约束仍至少三阶。因此

\[
\Pr[a,b\in R_z(U,V)]\le\frac1{64}.
\tag{2}
\]

## 全为二元 witness 时

设 \(\mathcal T\) 是一个两两相交的二元 cell 集族，且每个 (T\in\mathcal T) 都是 collision witness。任意两两相交的 2-uniform 集族或者是 star（所有边共有一个 cell），或者包含于一个 triangle（三条边 \(\{a,b\},\{a,c\},\{b,c\}\)）。

* star 情形：事件被某个 cell 被保留所包含，故由 (1)
  \[
  \Pr[\exists T\subseteq R_z(U,V)]\le\frac1{16}.
  \]
* triangle 情形：命中事件是三条 pair 事件的并，由 (2)
  \[
  \Pr[\exists T\subseteq R_z(U,V)]\le3\cdot\frac1{64}<\frac1{16}.
  \]

因此在“所有最小 witness 均为二元集”的分支中，完整 thinning AEKR 界成立；singleton witness 直接落入 star 界。

## 边界

该结论不处理同时含有大小至少 3 的最小 witness 的一般族。不能把一个大 witness 任意替换为其全部二元子集，因为替换后未必保持与其他 witness 两两相交。故一般 AEKR 仍需处理真正的高阶交叉族。
