> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mixed separator 的 spoiler-state 分区与 \(\tau=2\) 边界（2026-08-13）

## 状态分区

固定 spoiler \(s=(x_s,y_s)\)，写

\[
q_s(z)=r\cdot x_s+t,\qquad p_s(z)=r\cdot y_s+t,
\qquad z=(r,t).
\]

三种 separator 在四个 spoiler 状态 \(\sigma=(q_s,p_s)\) 上的支持为

\[
\begin{array}{c|c}
\text{类型}&\text{可命中的状态}\\ \hline
R:q_s=1&10,11\\
C:p_s=0&00,10\\
P:q_s=p_s&00,11\\
\end{array}
\]

状态 \(01\) 对所有 collision witness 都不可命中。若 \(X\cap Y=\varnothing\)，则
\(q_s,p_s\) 独立，四个状态各占 \(2^{n-1}\) 个参数。令

\[
\bar\mu_\sigma=2^{-(n-1)}\sum_{z:\,(q_s,p_s)=\sigma}\mu_z.
\]

于是完整 thinning 概率为

\[
\Pr(E)=\frac14\bigl(\bar\mu_{00}+\bar\mu_{10}+\bar\mu_{11}\bigr),
\tag{1}
\]

目标 \(\Pr(E)\le 1/16\) 等价于三活跃状态的条件质量和不超过 \(1/4\)。仅按状态逐一使用四补集矩形界
\(\mu_z\le1/4\) 得不到这个和式界。

## 最小 mixed 状态表：不能逐状态加一半

取 \(n=3\)、

\[
X=\{2,3,7\},\qquad Y=\{5,1,4,6\},\qquad s=(2,5).
\]

以下三条极小二元 witness 两两相交且覆盖数为 \(2\)：

\[
\begin{aligned}
T_1&=\{(7,4),(3,6)\} &&(CR),\\
T_2&=\{(7,6),(3,6)\} &&(R),\\
T_3&=\{(7,4),(7,6)\} &&(C).
\end{aligned}
\]

直接枚举行列 thinning 得到唯一非零的 \(\mu_z\)：

\[
\begin{array}{c|c|c|c}
z=(r,t)&(q_s,p_s)&\text{叶中的行/列数}&\mu_z\\ \hline
(1,1)&10&(2,2)&3/16\\
(3,0)&11&(2,3)&1/8\\
(5,0)&00&(2,3)&1/8
\end{array}
\]

因此

\[
\sum_z\mu_z=\frac7{16},\qquad
\Pr(E)=\frac{1}{2^{4}}\sum_z\mu_z=\frac7{256}<\frac1{16}.
\]

特别地，状态 \(10\) 可以达到 \(\mu_z=3/16\)；任何试图先证明每个活跃状态
\(\mu_z\le1/8\) 的路线都是错误的。

## 真正的高阶 \(\tau=2\) 形态

mixed \(\tau=2\) 并不必然由三角形 pair 子族控制。一个可复现的 pair-star 加高阶例子是

\[
\begin{gathered}
n=4,\quad X=\{6,2,5,13,3\},\quad Y=\{14,0,9,11,4,7\},\quad s=(3,9),\\
a=(5,9),\\
\{(6,0),a\},\ \{(2,4),a\},\ \{(13,11),a\}\quad(RP),\\
T_0=\{(6,0),(2,4),(13,11)\}\quad(C).
\end{gathered}
\]

四个 witness 两两相交；全族无公共 cell，但由 \(\{a,(6,0)\}\) 覆盖，故
\(\tau=2\)。三个 pair 事件只出现在状态 \(11\)，各个非零参数叶的质量为
\(7/64\)；\(T_0\) 只在状态 \(10,00\) 各贡献 \(1/64\)。并集的精确值为

\[
\sum_z\mu_z=\frac{23}{64},\qquad
\Pr(E)=\frac{23}{2048}<\frac1{16}.
\]

这说明 pair-star 与高阶 witness 的跨状态耦合确实存在，不能把 \(\tau=2\) 简化为 triangle。

## 已闭合与未决范围

若族中含有一个无公共点的 triangle pair 子族，则任意其它 witness 与三条边都相交，必含 triangle 的至少两个顶点，因而包含其中一条 pair；整个命中事件被三条 pair 事件覆盖，质量至多 \(3/64\)。全三元族则由 note 033 闭合。

还可严格关闭 pair-star 中至少两条 pair 边的情形。若中心为 \(a\)，边为 \(\{a,u_i\}\)，则所有不含 \(a\) 的 witness 都含每个 \(u_i\)。含 \(a\) 的整支由 note 037 的两个 \(W\)-扇区给出质量至多 \(3/64\)。任意两个 distinct cells 同时保留的全局质量至多 \(1/64\)（系数秩至少 3 且 row/column 数至少 3），任意三个 distinct cells 同时保留的质量至多 \(1/128\)（秩至少 3 且 row/column 数至少 4）。故两条边时总质量至多 \(3/64+1/64=1/16\)，三条或更多边时至多 \(3/64+1/128=7/128<1/16\)。

剩余未决范围可缩为：没有 pair witness 的高阶族，以及 pair-star 只有一条 pair 边的情形（除非能进一步证明后一情形不可能或自动产生第二条边）。已有小规模计算只作为启发式边界；由于部分早期候选生成器曾出现极小性判定方向错误，本文不把这些搜索峰值当作数值上界。可复现的显式 mixed 例子仍严格低于 \(1/16\)，但不替代一般证明。当前最小未决命题是：在 note 037 的 \(W=0/1\) 两扇区分解下，能否用 collision 电路或额外 affine 秩把上述最后两类的联合质量压到 \(1/16\)。

### 仅一条 pair 边的结构障碍

极小性本身不能把最后一类排除。取

\[
\begin{gathered}
n=4,\quad X=\{2,13,11,8,4,6\},\quad
Y=\{0,14,3,1,15\},\quad s=(4,3),\\
P=\{(2,0),(2,1)\},\\
A=\{(2,0),(2,14),(11,3)\},\qquad
B=\{(2,1),(2,15),(11,3)\}.
\end{gathered}
\]

这是三条 inclusion-minimal witness；它们两两相交，且 \(\tau=2\)，而选定族中只有一条 pair \(P\)。\(A,B\) 分别位于 \(P\) 的两个端点支，并在 residual cell \((11,3)\) 处 cross-intersect。逐参数、逐行列子集计算给出

\[
\sum_z\mu_z=\frac9{16},\qquad
\Pr(E)=\frac9{512}<\frac1{16}.
\]

因此“极小性自动产生第二条 pair”以及“\(P\) 事件与高阶支不相交”均为假；此处仍需真正的 residual cross-intersection 与 affine separator 的联合质量不等式。
