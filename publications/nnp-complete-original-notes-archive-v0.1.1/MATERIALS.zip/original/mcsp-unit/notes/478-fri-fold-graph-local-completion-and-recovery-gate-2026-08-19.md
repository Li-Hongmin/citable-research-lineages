> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# FRI fold-graph local-completion and recovery gate (2026-08-19)

## 改变的判断

正式 FRI 没有把 C476 的 local-completion gate 自动关闭，也没有提供它所需的
single-valued recovery。精确边界是：

1. 对固定 fold fiber，FRI 的 Lagrange fold 在 challenge 不落入该 fiber 时是 dense 的；
   challenge 落入 fiber 时则退化为 one-hot evaluation。
2. physical Hamming 邻域是否实现一个 fiber 内的一坐标 raw completion，是 layered
   fold graph 的投影问题。terminal code distance 或 whole-layer unit vector 都不是正确的
   判据。
3. ordinary FRI soundness 只约束随机 QUERY 的接受概率，不给每个预定 target 一个
   non-bottom、低错误的 folded-symbol decoder。若另加这种 recovery，且 decoder 不能免费
   读取已物化父符号，则 C476 才开始计价。

因此 FRI-style proximity acceptance 仍是 C475--C476 范围外的接口。把它用于 RW
正线时，必须另外证明 target-wise recovery，并支付 raw recomputation 或中间 oracle 的
address/evaluator 成本。

## 正式 FRI 的 fold 与退化 challenge

令 \(F\) 为特征二的有限域。正式 FRI 第 \(i\) 层使用 additive coset
\(L^{(i)}\subseteq F\)，固定一个 \(\eta\)-维 additive subgroup
\(L_0^{(i)}\)，并记

\[
  b=2^\eta,
  \qquad
  q^{(i)}(X)=\operatorname{Zero}_{L_0^{(i)}}(X),
  \qquad
  L^{(i+1)}=q^{(i)}(L^{(i)}).
  \tag{478.1}
\]

对 \(y\in L^{(i+1)}\)，fiber

\[
  S_y=\{z\in L^{(i)}:q^{(i)}(z)=y\}
  \tag{478.2}
\]

是大小 \(b\) 的 coset。verifier 从整个 \(F\) 均匀选择 challenge \(x^{(i)}\)，honest
prover 令

\[
  f^{(i+1)}(y)=P_y(x^{(i)}),
  \qquad
  P_y=\operatorname{interpolant}(f^{(i)}|_{S_y}).
  \tag{478.3}
\]

正式主参数取 \(\eta=2\)，即 \(b=4\)，协议本身允许一般常数 \(\eta\)。

### 引理 478.1（FRI Lagrange-support dichotomy）

对 \(\alpha\in S_y\)，写

\[
  \lambda_\alpha(x)
  =
  \prod_{\beta\in S_y\setminus\{\alpha\}}
  \frac{x-\beta}{\alpha-\beta}.
  \tag{478.4}
\]

则：

\[
  x\notin S_y
  \Longrightarrow
  \lambda_\alpha(x)\ne0
  \quad(\alpha\in S_y),
  \tag{478.5}
\]

而若 \(x=\alpha_0\in S_y\)，则

\[
  \lambda_{\alpha_0}(x)=1,
  \qquad
  \lambda_\alpha(x)=0
  \quad(\alpha\ne\alpha_0).
  \tag{478.6}
\]

因此对固定 fiber，退化概率为

\[
  \Pr[x^{(i)}\in S_y]=\frac{b}{|F|}.
  \tag{478.7}
\]

一层中存在退化 fiber 当且仅当 \(x^{(i)}\in L^{(i)}\)，其概率为

\[
  \frac{|L^{(i)}|}{|F|};
  \tag{478.8}
\]

发生时恰有一个 fiber 退化。因而该层所有 fibers 同时 dense 的概率是
\(1-|L^{(i)}|/|F|\)。

证明直接来自 (478.4)：在 \(x\notin S_y\) 分支，全部分子与分母非零；在
\(x=\alpha_0\) 分支，Lagrange basis 在插值节点上是 Kronecker delta。ECCC 正式版
Equation (36) 只用于前一分支，并在后一分支明确写成
\(f^{(i+1)}(y)=f^{(i)}(x^{(i)})\)。

## Layered fold graph 的正确 completion 判据

令第 \(j\) 层为 \(V_j=F^{X_j}\)，线性 fold 为

\[
  T_j:V_j\to V_{j+1},
  \qquad 0\le j<R.
  \tag{478.9}
\]

定义

\[
  S_0=I,
  \qquad
  S_j=T_{j-1}\cdots T_0,
  \qquad
  A_i=T_{R-1}\cdots T_i,
  \tag{478.10}
\]

并令 terminal condition 是线性码 \(C_R\le V_R\)。可出现在 exact graph word 第
\(i\) 层的增量空间为

\[
  W_i=\operatorname{Im}(S_i)\cap A_i^{-1}(C_R).
  \tag{478.11}
\]

固定 \(T_i\) 的一个 fiber \(S_y\subseteq X_i\)，令
\(\pi_y:V_i\to F^{S_y}\) 为限制映射。C476 所需的是 fiber-restricted star

\[
  \pi_y(\Delta x_i)=a e_k,
  \qquad a\ne0,\ k\in S_y,
  \tag{478.12}
\]

而不是更强的 whole-layer 条件 \(\Delta x_i=a e_k\)。

### 定理 478.2（fiber-local completion classification）

存在满足 (478.12) 的 exact graph increment，当且仅当

\[
  e_k\in\pi_y(W_i).
  \tag{478.13}
\]

等价地，对每个 \(\phi\in F^{S_y}\)，

\[
  \pi_y^\top\phi
  \in
  \ker(S_i^\top)+A_i^\top C_R^\perp
  \Longrightarrow
  \phi_k=0.
  \tag{478.14}
\]

若 physical weight 对全部 stored layers 求和，则最小 completion weight 精确为

\[
  \delta_{i,y,k}
  =
  \min_{\substack{u\in V_0,\ a\ne0:\\
                   S_Ru\in C_R,\\
                   \pi_y(S_i u)=a e_k}}
  \sum_{j=0}^{R}\operatorname{wt}(S_j u),
  \tag{478.15}
\]

空集时取 \(\infty\)。

证明中，(478.13) 是 (478.11)--(478.12) 的直接投影。又有

\[
  W_i^\perp
  =
  \ker(S_i^\top)+A_i^\top C_R^\perp.
  \tag{478.16}
\]

这里不需要 \(A_i\) 满射：若 \(q:V_R\to V_R/C_R\) 是 quotient map，则
\(A_i^{-1}(C_R)=\ker(qA_i)\)，所以
\[
  (A_i^{-1}(C_R))^\perp
  =\operatorname{im}(A_i^\top q^\top)
  =A_i^\top C_R^\perp.
\]
有限维对偶于是给出 (478.14)；exact graph word 由 base increment \(u\) 唯一产生为
\((S_0u,\ldots,S_Ru)\)，故得到 (478.15)。

### 推论 478.3（support-isolated physical completion）

令 \(z^\star\) 是存储全部 graph layers 的 honest physical proof，且
\(\mathcal D\) 包含其相对半径 \(\rho\) 的 physical Hamming 球。假设目标
\((i+1,y)\) 的 raw evaluator 只把 \(S_y\) 作为 raw input（或对 fiber 外的
layer changes 不敏感），并且对每个 \(k\in S_y\) 都存在达到
\(\delta_{i,y,k}\le\rho P\) 的增量。若 evaluator 在该球上 wrong-symbol error
至多 \(\beta\)，且 honest non-bottom mass 至少 \(\nu\)，则

\[
  \Pr[\text{query }k]\ge\max\{0,\nu-2\beta\},
  \qquad
  \mathbb E Q_y\ge
  |S_y|\max\{0,\nu-2\beta\}.
\tag{478.17}
\]

这是 C476 的 bottom-aware coupling 直接应用于 (478.12)--(478.15)：physical
completion 可能同时改变 fiber 外的 stored cells，但这些变化不进入目标 raw
transcript。若 evaluator 可以查询并依赖这些 fiber 外 cells，则
\(e_k\in\pi_y(W_i)\) 单独不够；必须改用一个 support-isolated increment，或把
这些额外变化纳入新的 indistinguishability/descriptor 论证。

### 两个排除错误直觉的推论

设每个 \(T_j\) 都按 disjoint nonempty fibers 分块，且每个 fiber coefficient 非零。
则全部 \(T_j\) 满射。

第一，若 \(t\) 是 \(k\) 的 terminal ancestor，并定义

\[
  d_t(C_R)
  :=
  \min\{\operatorname{wt}(c):c\in C_R,\ c_t\ne0\},
  \tag{478.18}
\]

则 \(d_t(C_R)<\infty\) 已足以实现 (478.12)。选择达到 \(d_t\) 的 codeword，给每个
非零 terminal coordinate 选择一条祖先路径，并在 \(t\)-路径强制经过 \(y,k\)；非零
path coefficients 允许缩放。所得 suffix weight 至多

\[
  (R-i+1)d_t(C_R),
  \tag{478.19}
\]

若连同全部 prefix layers 一起存储，则该构造的总 weight 为
\((R+1)d_t(C_R)\)。所以 repetition、RS 或 GRS terminal distance \(>1\) 并不阻止
fiber-local completion；只要目标 terminal coordinate 出现在某个 codeword support 中，
completion 就存在。

第二，若 \(R-i\ge2\)，目标 \(i+1\) 层坐标 \(y\) 在下一 fold 中有另一个 sibling，
则可在目标 fiber 只改变 \(k\)，并在该 sibling 的 \(T_i\)-fiber 内选择一个第 \(i\)
层坐标放置补偿，使两条路径在下一层抵消。于是即使 \(C_R=\{0\}\)，(478.12) 也可能
成立。故 terminal distance 不是 (478.13) 的必要条件。

这同时说明：小 physical graph distance 不自动给出 raw completion，而 whole-layer
unit vector 的缺失也不自动排除 raw completion。唯一尖锐的一般判据是 (478.13)。

### 推论 478.4（two-round sibling-cancellation weight bound）

再假设每个 \(T_j\) 按 disjoint fibers 分块，所有 fiber coefficients 非零，且
\(T_{i+1}\) 的 fibers 大小至少为 \(2\)。若 \(R-i\ge2\)，则对每个
\(k\in S_y\)，存在一个满足 (478.12) 且 terminal
increment 为 \(0\in C_R\) 的 graph increment；若 physical proof 按 stored layer
symbols 计重，其重量至多

\[
  \delta_{i,y,k}\le 2(i+2).
\tag{478.20}
\]

构造如下：在目标 fiber \(S_y\) 只放置 \(k\) 的非零值；选择
\(T_{i+1}\)-fiber 中的 sibling \(y'\ne y\)，在其一个 child 上放置第二个非零值，
使 \(T_{i+1}\) 在共同 parent 上的两个贡献相消。于是 layer \(i+2\) 及其后全部为零。
由于每个 \(T_j\) 都满射，可向前逐层选取至多两个 nonzero preimages；layer
\(0,\ldots,i+1\) 每层至多两个非零 symbols，得到 (478.20)。

所以，对任何 \(\rho P\ge2(i+2)\) 的 physical radius，只要 target raw transcript
只看 \(S_y\)，C476 的 bottom-aware bound 已适用于该目标：

\[
  \mathbb E Q_y\ge |S_y|\max\{0,\nu-2\beta\}.
\tag{478.21}
\]

该推论只计未编码的 stored-layer symbols；若每层另有 ECC/commitment 编码，必须把
上述 increment 的编码后物理重量重新证明。对最后一层 \(i=R-1\)，没有 sibling
cancellation；此时仍需 terminal code 在目标坐标有非零 support，或另给 binding
mechanism。

## Proximity acceptance 不产生逐目标 recovery

考虑 \(N\) 个二元 fibers，令

\[
  c_i=y_{i,0}+\alpha y_{i,1},
  \qquad \alpha\ne0,
  \tag{478.22}
\]

并让 verifier 均匀抽取 \(i\)，读取两个 leaves 与 \(c_i\)，检查 (478.22)。honest
fold graph 完全接受。只改变一个 leaf、保持 parent oracle 不变，physical Hamming
距离为一，而随机 consistency test 的接受概率仍为

\[
  1-\frac1N.
  \tag{478.23}
\]

在被修改的 target fiber 上，已物化 parent 已不再等于新的 raw fold。随机 test 的高
接受率既不保证这个 parent 是正确 symbol，也不保证预定 target 上有 non-bottom decoder。
target decoder 当然可以重新读取两个 leaves 并计算正确值；对 \(b\)-ary FRI fiber，这一
直接修复读取全部 \(b\) 个 raw symbols，正是 C476 计价的对象。

正式 FRI 的量词与这个例子一致。\(f^{(0)}\) 是 received oracle；prover 看见各轮
challenge 后依次提交 \(f^{(1)},\ldots,f^{(r-1)}\)，末层提交低次 interpolant 的系数。
Theorem 3.3 的 soundness 是：当 \(f^{(0)}\) 远离 RS code 时，以高概率对 COMMIT
randomness，任意 adaptive prover oracles 的随机 QUERY 接受率受界。它没有断言任意
corrupted committed layer 在每个坐标仍是由前层唯一决定的 fold。

此外，对固定 \(f^{(0)}\) 与固定 challenges，honest exact layers 是确定的 singleton。
定理 478.2 的 graph-family completions通常会同时改变更早层乃至 \(f^{(0)}\)，因此也不能
被静默解释为“同一 received word 周围的 prover-proof completion”。

## 对 C476 与 RW 正线的后果

若一个 FRI-inspired RW candidate 要在每个 target 上输出 folded symbol，则必须明确
选择：

1. **Raw recomputation：** 条件于 (478.5) 的 dense fiber，逐点恢复参数满足
   \(\nu-2\beta\ge\gamma>0\) 时，C476 给出 \(\mathbb E Q\ge\gamma b\)。
2. **读取 materialized parent：** 必须证明 corrupted/near proof 上的 single-valued
   correctness，并按 C473/C474 计入 physical support 或 address evaluator；ordinary
   FRI soundness不提供这一步。
3. **拒绝或 bottom：** 若没有逐 target 的正 non-bottom margin，则留在
   \(\nu\le2\beta\) 的 bottom escape，而不是完成 RW recovery。
4. **新的 global/computational relation：** 重新说明 binding、proof length、address
   与模型假设；不能把它称为未计价的 raw fold。

所以本结果既不证明一般 FRI/IOPP/PCS 下界，也不证明 \(P\ne NP\)。它关闭的是一条明确
的错误桥：

\[
  \text{FRI proximity acceptance}
  \not\Longrightarrow
  \text{C476 target-wise local recovery}.
  \tag{478.24}
\]

## 来源

* Ben-Sasson, Bentov, Horesh, Riabzev, *Fast Reed--Solomon Interactive Oracle Proofs of
  Proximity*, ECCC TR17-134 revision 2, Sections 3.2--3.4, Theorem 3.3 and Equation (36):
  <https://eccc.weizmann.ac.il/report/2017/134/revision/2/download>。
* 同文 ICALP 2018 版本，Section 2.1--2.2：
  <https://doi.org/10.4230/LIPIcs.ICALP.2018.14>。
* [C475：high-arity folding quantifier gate](475-rw-high-arity-folding-quantifier-and-batch-opening-gate-2026-08-19.md)。
* [C476：positive-radius and bottom-aware completion barrier](476-positive-radius-completion-barrier-for-high-arity-folding-2026-08-19.md)。
