> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# ACRR 接口收束与外部报告吸收记录（2026-08-16）

## 0. 输入与状态核对

本记录吸收附件
`[unbundled local reference]`。
附件声称最新提交为 `918667b`、最新笔记为 168；本地权威仓库实际为
`8333911`（`Add direct dPCP J-K tradeoff`），且已有 169–171。因此附件中的
仓库编号、提交状态和“最新成果”只作为候选索引，以下判断以本地笔记、RW 原始报告和
dPCP 原始论文为准。

## 1. 统一剩余接口：ACRR

将当前真正未解决的对象统一记为 **Address-Scale Coordinate-Robust Reconstruction
(ACRR)**。对 computation instance `C_x`、输出坐标 `i` 和声明位 `b`，需要同一
proof/key `K_x` 与同一地址空间上的查询 `Q_{x,i,b}`，满足：

1. **同一对象：** 所有坐标复用同一个 `K_x`，不能逐坐标更换 witness、preimage 或
   proof address space；
2. **完备性：** 正确位的查询接受；
3. **坐标鲁棒性：** 错误位对任意候选 proof 有固定常数拒绝率；
4. **地址尺度：** query、量词字符串和 verifier 描述在
   `poly(n, log T)`，而不是 `q^{Ω(1)}`；
5. **整词一致性：** 逐位自归约不能让不同坐标选择不相容的全局词；
6. **无隐藏 advice：** `K_x` 不能只是把完整 history 换名后塞入非均匀 advice；
7. **统一性：** graph、constraint、decoder 和 output embedding 可由固定算法生成。

note 121 已证明：若 RW/JK 真能提供 ACRR，则在相应 forcing 假设下足以推出
`P ≠ NP`。note 159 给出固定 PH 地址谓词的静态充分条件。二者都是**条件定理**，
不是现有构造。

## 2. 已核验的路线裁决

### 2.1 复制平均 soundness 不能产生 ACRR

note 169 的参数化反例是严格的。把长度 `n` 的输出坐标 `i` 复制 `R` 次，均匀
采样的新长度为 `N=n+R-1`。若存在只在 `i` 位错误、但满足所有原约束的 assignment，
并让副本全部取同一错误值，则任何只复制坐标/等式的编译都满足

\[
  \varepsilon'_R\ge \frac{R}{n+R-1}.
\]

要给固定坐标常数权重，必须 `R=Ω(n)`；若仍要求平均 soundness `<1/2`，则
该错误 assignment 直接把 gap 推过 `1/2`。因此普通 average/list/unique decoding
不能黑箱升级为 coordinate-robust verifier；必须新增独立的语义检查、外码放大或
coordinate-robust/fortified soundness。物理复制 proof 与 equality edge 也不能排除
“所有副本一致地取错”。

### 2.2 line packing 与 shared key 是不同的条件性出口

note 167 的二分应保留限定：

* **line packing：** canonical proof 长度 `P ≤ k·polylog(k)`，使
  实际 line 描述在 JK seed 中可打包；
* **shared key：** 长度至多 `k` 的统一 key，加上
  `k·polylog(k)`-size whole-block accessor。

这不是对所有 PCP 的一般不可能性。它只说明在这两类机制中，继续优化单条 line 的
polylog 因子不能替代完整 tree closure；RW 当前材料尚未提供任一出口。

### 2.3 直接 dPCP--J--K 是当前最强的正向接口，但仍非证明

note 171 定义了独立的 conditional `Solve/Reconf`：对每个 `(i,b)` 编译

\[
  \varphi_{x,i,b}(w)=C_x(w)\land[\operatorname{out}_i(w)=b],
\]

拼接 canonical dPCP proof table `P_x`，直接运行 `JK(G, P_x)`。若
dPCP 具有统一 proof map、固定二进制编码、局部 component generator，以及
unsatisfiable instance 的接受率 (<1/2)，则 J--K 返回的 easy circuit 可在同一个
全局 table 上回答所有坐标查询；这消除了 lex-prefix 的 phantom-witness 问题。

但它仍缺四件事：

1. 没有统一 `G` 的 hard-instance forcing 或全输入 failure；
2. 没有把 canonical dPCP table 的复杂度下界传给 `g`；
3. query/easy circuit 仍在 `q` 尺度，未压到 `n = log q` 地址尺度；
4. dPCP headline theorem 本身未自动给出上述 proof map、padding、局部生成和统一
   no-instance 接口。

因此它是当前最值得继续检查的**条件性构造**，不是 `P ≠ NP` 证明。

## 3. 研究决策

### 保留

* 以 ACRR 作为 RW/JK 主线的唯一一级开放接口；
* 将 note 169 的复制 no-go 发展成独立的 average-to-coordinate separation theorem；
* 将 note 171 作为唯一主正向候选，优先检查 forcing、proof-table hardness transfer
  和 `q`-to-`n` 压缩三者中的一个；
* 保留 note 170 作为复用 RW history 的备用组合，不再把它误称为 direct replacement。

### 已被本轮战略决策修订的管理项

* 本轮用户明确把目标提升为 `P != NP` 或 FOCS/STOC 量级定理，并要求把 RW/JK
  重构作为独立一级主线。因此不移动旧 note，但新增
  `units/rw-jk-succinct-reconstruction/` 作为权威入口；旧目录只保留历史材料和
  MCSP 三条原始主线。
* 不把附件中的 `918667b`、阶段编号、Issue 清单或“最新 note 168”当作事实；
* 不再把平均 dPCP soundness、lex-first 命名或 `E^NP`-尺度全表 outsider 说成
  地址尺度 ACRR。

## 4. 证据边界

本记录中的 RW/J--K 语义来自 Ren--Williams 原始报告
[TR26-118 revision 1](https://eccc.weizmann.ac.il/report/2026/118/revision/1/download)，
dPCP/udPCP 定义与参数来自
[Gur--Min--Weissenberg--Zheng](https://arxiv.org/html/2512.12960)。

ACRR、line-packing/shared-key 二分和直接 dPCP--J--K 组合是本项目在这些定义上作出的
条件性推导；它们不等于原论文已证明的定理。附件中关于仓库状态、重复编号、Issue
规划和“项目阶段”的内容属于管理建议，不作为数学证据。
