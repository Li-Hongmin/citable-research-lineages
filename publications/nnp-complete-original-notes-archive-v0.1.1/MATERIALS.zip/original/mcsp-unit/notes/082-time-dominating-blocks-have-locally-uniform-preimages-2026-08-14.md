> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Time-dominating blocks 有 locally uniform preimages（2026-08-14）

## 结论

[note 081](081-minimal-slack-and-poisoned-stitched-output-boundary-2026-08-14.md) 在
\(q=n^{k+O(1)}\) 的近最小 block scale 上保留了原 exact stitched output 的 preimage-accessor
问题。本 note 找到一个正面尺度：若增大 \(q\) 使 canonical decoder 的 circuit budget 支配该 block
的 uniform bit-generation time，则标准 tableau circuit 本身给出 locally accessible preimage。

精确地，设 \(z_\theta\in\{0,1\}^{2q}\) 的任一 bit 可由固定 deterministic multitape Turing
machine 在时间 \(R(\theta)\) 内计算。可取 universal constant \(\gamma=2\)，使只要

\[
R(\theta)^\gamma
\le a\frac q{\log q},
\tag{1}
\]

其中 canonical truth-table decoder \(G_q\) 的 range 包含所有 size 至多
\(a q/\log q\) 的 circuits，就存在

\[
u_\theta\in G_q^{-1}(z_\theta)
\]

满足

\[
\operatorname{CC}(i\mapsto u_\theta[i])
\le \operatorname{poly}(|\theta|+\log q+\log R(\theta)).
\tag{2}
\]

应用于 note 076 的原 minimal-slack \(H_{n,k}\)：若其 bit time 为

\[
R(n,k)=n^{Ak+O(1)},
\]

则可取二次幂

\[
q(n,k)=2^{\lceil D(k+C)\log_2n\rceil},
\qquad D>\gamma A,
\tag{3}
\]

使 systematic output 中所有 \(2q\)-bit blocks 都有某个 size \(n^{O(1)}\) preimage accessor。除最后
一块外它们全为零；最后一块由式 (1)--(2) 处理。因此 exact stitched output 上“是否至少存在 compact
preimage”的问题闭合。RW 的 published JK history 选 lexicographically smallest preimage；本引理
不保证该 canonical preimage compact。故仍有两个不同的未知接口：output blocks 的 canonicalization，
以及 systematic output 之后的 encoded witness / auxiliary PCP blocks。

该结论不与 note 081 的 poisoned construction 冲突：poison selector 的 bit time 为 \(q^{K_0}\)，
故任意固定放大 \(q=n^{Dk+O(1)}\) 后仍有 \(R^\gamma\gg q\)，式 (1) 失败。真正的边界是

\[
\boxed{\text{canonical circuit capacity }q/\log q
\quad\text{vs.}\quad
\text{uniform block bit-time }R^\gamma,}
\]

而不是 sparse layout、alignment 或 lex-firstness。本文没有解决 auxiliary PCP blocks，也不声称证明
\(P\ne NP\)。

## Locally uniform preimage lemma

固定 finite fan-in-two basis 与 note 079 的 gate-list encoding

\[
G_q:\{0,1\}^{q}\to\{0,1\}^{2q}.
\]

可用 standard universal-circuit evaluation 为每个 truth-table coordinate 复制 evaluator，使
\(|G_q|=O(q^2\operatorname{polylog}q)\le q^4\)（充分大 \(q\)），满足 RW Theorem 4.1 的 size
条件。

令 \(m=\log_2(2q)\)，并假设 fixed machine \(M\) 在输入 \((\theta,j)\)、\(j\in\{0,1\}^m\) 上输出
\(z_\theta[j]\)，时间不超过 \(R=R(\theta)\)。直接展开它的 space--time tableau：time coordinate
有 \(R\) 个值，每条 tape 只需 \(O(R)\) 个可能访问的位置，每个下一时刻 cell 由上一时刻的 fixed
局部邻域通过 constant-size transition circuit 决定。由此得到

\[
C_\theta:\{0,1\}^m\to\{0,1\},
\qquad |C_\theta|=O(R^2).
\tag{4}
\]

可取一个规则 gate numbering，使给定 gate-list address 后，其 gate type、输入 wires、input/constant
label 可在

\[
\operatorname{poly}(|\theta|+\log R+\log q)
\tag{5}
\]

时间内计算：gate ID 解码为 tableau 的 time/tape/position/local-component 坐标，wiring 只需 fixed
local transition 与 \(O(\log R)\)-bit整数地址运算；初始行中的 \(\theta\) 可硬接进该长度的 accessor。
把这个 polynomial-time local generator 作普通 time-to-circuit simulation，得到 size 为式 (5) 的
固定多项式的 Boolean accessor。这里不依赖一个只陈述 \(TIME(R)\subseteq SIZE(O(R\log R))\) 而未
保证 direct-connection uniformity 的黑箱定理。

gate-list 对 \(|C_\theta|\) 个 gates 使用

\[
O(|C_\theta|\log(|C_\theta|+m))
\le O(R^2\log q)
\tag{6}
\]

bits。由式 (1)，调整 encoding 的 fixed constant 后，gate 数不超过 \(a q/\log q\)，且完整编码
占用至多 \(q\) bits；故 \(C_\theta\) 是 \(G_q\) 接受的合法短描述。
其余位置按 canonical padding rule 填充，形成 \(q\)-bit string \(u_\theta\)。accessor 先判断地址属于
gate list 还是 padding，再调用式 (5) 的 local generator。因此得到式 (2)，且

\[
G_q(u_\theta)=TT(C_\theta)=z_\theta.
\]

注意，这个 lemma 给的是某个 locally uniform preimage，不保证它是 lexicographically first
preimage。JK 的 SAT range query 以任一合法 preimage 为 witness，但 published deterministic
recurrence 把每块的 lexicographically smallest preimage 拼成下一层 string。把本文的
\(u_\theta\) 代入该 recurrence，需要重新证明 canonicality/coherence 或设计一个接受 verified local
preimages 的变体；不能由存在性直接推出。

## 原 stitched output 的参数代入

在 \(P=NP\) 假设下先固定一个 polynomial-time SAT decider \(A\)。note 076 的两个 fixed-PH prefix
self-reductions 随之变成固定 deterministic algorithms；存在依赖 \(A\) 但不依赖 \(n,k\) 的常数
\(A_0,B_0\)，使

\[
H_{n,k}[x]
\quad\text{可在时间}\quad
R(n,k)\le n^{A_0k+B_0}
\tag{7}
\]

内计算。这里可先生成长度 \(r_k=n^{k+O(1)}\) 的 lex-first coherent tail，再读取地址 \(x\)；不要求
这个算法已经是 address-scale polynomial time。

取式 (3) 中固定 \(D>\gamma A_0\) 并增大 \(C\) 吸收 \(B_0\)、encoding constants 与
poly\((k)\) factors。对 \(k\le\lfloor\log_2\log_2n\rfloor\) 和充分大 \(n\)，同时有

\[
r_k<2q,\qquad 2q\mid 2^n,\qquad q<2^n.
\tag{8}
\]

把完整 truth table

\[
H_{n,k}=0^{2^n-r_k}\operatorname{tail}_k
\]

按 \(2q\) 分块。由式 (8)，除最后一块外均为 \(0^{2q}\)，有固定 trivial preimage。最后一块

\[
B_{n,k}=0^{2q-r_k}\operatorname{tail}_k
\tag{9}
\]

的 bit algorithm 只需把 block address 平移到 \(H_{n,k}\) 的全局 address，再运行式 (7)。由
\(D>\gamma A_0\)，

\[
R(n,k)^\gamma
<a\frac q{\log q}
\]

对充分大 \(n\) 成立，故式 (2) 给 \(B_{n,k}\) 的 accessor size

\[
\operatorname{poly}(k\log n)\le n^{O(1)}.
\tag{10}
\]

令 \(k(n)=\lfloor\log_2\log_2n\rfloor\)，并把 \(H_n\) 作为一个无 NP queries 的 deterministic
multi-output machine 的 output prefix；其 nice full-output time 可取

\[
T(n)=2^n n^{O(k(n))},
\qquad \log T=\Theta(n).
\]

Ren--Williams Theorem 4.1 允许任意 nice block parameter \(q(n)\le T(n)\) 与 size 至多 \(q^4\) 的
AVOID instance，故式 (3) 满足 theorem-level 参数限制。因为无 query-answer header，完整 output
从 systematic proof 的第一个坐标开始；式 (8) 保证其 blocks 与 JK partition 对齐。结合式 (10)，
所有 systematic output blocks 都至少有一个 \(\operatorname{poly}(n,\log T)\)-size preimage
accessor。更强地，可统一选择这些 preimages：给定 block index \(j\) 与 description address \(i\)，
一个固定 algorithm 判断 \(j\) 是否为最后的非零 block；零块返回固定 padded-zero description，最后
一块调用式 (5) 的 tableau-description generator。因此

\[
(n,k,j,i)\longmapsto u_{n,k,j}[i]
\]

可在 \(\operatorname{poly}(n,k,\log R)\) 时间计算，并给出同尺度 circuits。这里的 coherence 只覆盖
第一层 systematic output blocks；它不使这些 choices 等于 published JK 的 lex-first choices。

## 放大 \(q\) 的 hardness-ratio 代价

式 (3) 的正面结论不能免费代入 stitched lower bound。原 construction 只认证

\[
\operatorname{CC}(H_{n,k})>n^k,
\]

而 locally uniform preimage 使用的 tableau circuit 有 size \(R^2=n^{2A_0k+O(1)}\)，并要求

\[
q\ge n^{2A_0k+O(1)}.
\tag{11}
\]

JK Theorem 3.1 的 easy branch 给 \(H\) 的 circuit size \(O(|G_q|\log T)=q^{O(1)}\log T\)，远大于
\(n^k\)。式 (2) 只压缩这个大 circuit 的 **description accessor**；它不压缩 gate count、depth 或
evaluation time。故不能从式 (2) 推出与 \(\operatorname{CC}(H_{n,k})>n^k\) 的矛盾。

这与 note 076 的 exponent-ratio 记账一致：若 bit-time exponent 为 \(A_0k\)，让 decoder capacity
覆盖 time-unrolling 必须把 block exponent 提高到至少 \(2A_0k\)。要让该引理直接承重最终 lower-bound
矛盾，仍需一个 transformation，把 locally accessible 大 description 转换为 size \(n^{O(1)}\) 的
smart query / reconstruction，而不显式求值全部 \(q\) gates。

## 为什么这还没有闭合 RW route

第一处缺口已经出现在 output block 的 canonicalization。Theorem 3.1 在所有 satisfiable block
queries 上选择 lexicographically smallest \(q\)-bit preimage，而式 (2) 只构造某个 preimage：

\[
\exists u\in G_q^{-1}(B):\operatorname{CC}(u\text{-accessor})\le n^{O(1)}
\quad\not\Longrightarrow\quad
\operatorname{CC}(\min_{\rm lex}G_q^{-1}(B)\text{-accessor})\le n^{O(1)}.
\tag{12}
\]

后续 JK stages 依赖前一层所选 preimages 的同一个确定拼接；逐块存在但彼此不 coherent 的 circuits
不自动定义 published history。

Jeřábek--Korten 处理的输入不是只含 systematic output，而是完整 completeness proof

\[
\Pi_x=(\widetilde w,\Pi').
\]

RW 黑箱只固定 \(\widetilde w\) 中的 query-prefix/output 坐标。它不保证 intermediate-gate values、
Reed--Muller extension、robust-PCP oracle \(P\) 或 zero-on-subcube oracle \(\Pi_{ZoS}\) 的任一 block
有 time \(R\ll q^{1/\gamma}\) 的 uniform bit generator。Theorem 3.5 只给整个 \(\Pi_x\) 可在
\(\operatorname{poly}(T)\) 时间构造；从这一上界直接代入式 (1) 会要求 \(q>T\) 的某个固定幂，
而 Theorem 4.1 要求 \(q\le T\)。因此当前严格结论是

\[
\boxed{
\begin{array}{ll}
\text{exact output blocks 的某个 compact preimage：}&\text{已证明；}\\
\text{exact output blocks 的 lex-first compact preimage：}&\text{unknown；}\\
\text{auxiliary PCP / recursive JK blocks：}&\text{unknown。}
\end{array}
}
\tag{13}
\]

下一个决定性问题分成两个互斥方向：证明 JK 可改用 verified locally uniform preimages 而保持
smartness/coherence；或直接压缩 \(\min_{\rm lex}G_q^{-1}(B)\)。即使 output canonicalization 成功，
仍需让 RW completeness prover 的 auxiliary blocks 具有式 (1) 的 local generator，或证明重构不必
访问它们。

## 文献边界

检索与原文核验日期：2026-08-14。

- Hanlin Ren and Ryan Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin-Arthur Queries*, ECCC TR26-118, revision 1, 2026, Theorems 3.1, 3.5 and 4.1.
- Zeyong Li, *Symmetric Exponential Time Requires Near-Maximum Circuit Size*, STOC 2024,
  arXiv:2310.17762, Lemmas 3.7--3.8.
- Oliver Korten and Toniann Pitassi, *Strong vs. Weak Range Avoidance and the Linear Ordering
  Principle*, FOCS 2024, DOI `10.1109/FOCS61266.2024.00089`.

Li 的 structured Korten history 仍保存 \(q\)-bit frontier labels；Korten--Pitassi 的 LOP 输出仍是显式
minimal element。二者都不直接给式 (2) 的 address-scale compression。式 (1)--(13) 是本项目将
standard locally uniform tableau simulation 与 canonical truth-table decoder 组合得到的尺度引理。
