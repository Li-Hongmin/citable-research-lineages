> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Ordinary FRI does not supply common-target extraction (2026-08-19)

## 改变的判断

ordinary FRI 的完备性与 soundness 只约束一个 received oracle、challenge-dependent
prover strategy 与随机 QUERY acceptance。它们不含外部 RW target
\(A_n\)、target index \(j\)，也不产生跨所有 \(j\) 的共同 extraction object。
因此 C479 的 fixed-singleton symbolic evaluator 不能仅由 ordinary FRI 语义升级为
RW Gate I。

## 定理 480.1（common-target extraction separation）

令一个 ordinary FRI instance 为

\[
  \mathcal I=(f^{(0)},V,P),
  \tag{480.1}
\]

其中 \(P\) 可依赖 challenge prefix。设 \(\mathsf T\) 是只由 \(\mathcal I\)
导出的 challenge-independent package 与 evaluator：

\[
  \mathsf T(\mathcal I)=(S,E).
  \tag{480.2}
\]

ordinary FRI 的完备性与 proximity soundness 不蕴含

\[
  \forall A\in\{0,1\}^{N}\ \forall j\in[N],
  \qquad E(S,j)=A[j].
  \tag{480.3}
\]

更精确地，即使把 \(A\) 限制为两个 fixed singleton targets，仍存在具有完全相同
FRI 数据与 transcript distributions 的两个扩张结构，使 (480.3) 不能同时成立。

### 证明

固定同一个 \(\mathcal I\)，取

\[
  A,A'\in\{0,1\}^{N},\qquad
  A[j_0]\ne A'[j_0].
  \tag{480.4}
\]

构造两个扩张结构 \((\mathcal I,A)\) 与 \((\mathcal I,A')\)。ordinary FRI 的
全部数据、prover strategy、verifier 与 transcript law 在两者中逐字相同；因此两者
满足完全相同的 FRI assertions。由 (480.2)，\((S,E)\) 在两者中也相同，于是

\[
  E(S,j_0)
\]

不可能同时等于 \(A[j_0]\) 与 \(A'[j_0]\)。故 ordinary FRI assertions 不能单独
推出 (480.3)。证毕。

这个分离不是 proof-size lower bound。它定位的是缺失量词：若允许 \(S\) 直接依赖
\(A\) 且不限制长度，取 \(S=A\) 即使 extraction 平凡；真正的 Gate-I 陈述必须同时
限制 derivation、size 与 access。

## 定义 480.2（common-target extraction interface \(H\)）

对 RW target \(A_n\in\{0,1\}^{N_n}\)，接口 \(H\) 由一个一次发布、
challenge-independent、来自同一 FRI/RW attachment 的 descriptor \(S_n\)，以及
single-valued extractor \(E_n\) 构成，并满足

\[
  |S_n|+\operatorname{size}(E_n)=n^{O(1)},
  \tag{480.5}
\]

\[
  \forall j\in[N_n],\qquad
  E_n(S_n,j)=A_n[j].
  \tag{480.6}
\]

这里的 \(n\) 是 truth-table address scale，故 \(\log N_n=n^{O(1)}\)。若 extractor
随机化，必须存在一条对所有 \(j\) 共同固定的 tape，或给出 zero-error 的共同固定；
量词

\[
  \forall j\ \exists S_{n,j}
  \tag{480.7}
\]

不满足 \(H\)。同样，只有 common prover strategy 而没有 target map (480.6) 也不够。

## 推论 480.3（FRI 路线裁决）

ordinary FRI 入口在 Gate I 处严格停止。继续正攻只有两个不同任务：

\[
  \boxed{
  \text{construct }H
  \quad\lor\quad
  \text{prove every admissible }H\text{ pays forcing scale}.
  }
  \tag{480.8}
\]

若 \(H\) 成立，则取共同静态对象为 \(S_n\)，C181 的 same-object/all-address 量词
得到满足；若 \(S_n\) 是一个 proof/codeword address space，则 C473/C474 对其真实
support 或 charged evaluator 计价。challenge-tree branch count、ordinary proximity
soundness 与 fixed-singleton symbolic strategy 本身均不能替代 \(H\)。

## 边界

* 定理 480.1 是模型分离，不排除带显式 RW attachment 的新 FRI-derived construction。
* (480.5) 是 Closure 所需的 address-scale budget，不由 ordinary FRI 提供。
* 本 note 不证明一般 FRI/IOPP/PCS 下界，也不证明 \(P\ne NP\)。

## 来源

* Ben-Sasson, Bentov, Horesh, Riabzev, *Fast Reed--Solomon Interactive Oracle Proofs of
  Proximity*, ECCC TR17-134 revision 2, Sections 3.2--3.4:
  <https://eccc.weizmann.ac.il/report/2017/134/revision/2/download>。
* [C479：FRI challenge-tree staticization trichotomy](479-fri-challenge-tree-staticization-trichotomy-2026-08-19.md)。
* [C474：coding-layer/address-scale evaluator dichotomy](474-rw-coding-layer-address-scale-closure-dichotomy-2026-08-19.md)。
* [C473：honest-path support forcing](473-rw-honest-path-support-and-exposed-history-pcpp-gate-2026-08-19.md)。
* [C181：RW succinct smart reconstruction Closure Theorem](204-rw-succinct-smart-reconstruction-closure-theorem-2026-08-17.md)。
