> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 直接把 dPCP proof table 交给 J--K：独立 tradeoff 与剩余 forcing 缺口（2026-08-16）

## 结论

前两份 note 把“逐坐标 dPCP proof”放入 RW Theorem 4.1 的 history 结构，因而留下
compositional-history compiler 的疑问。其实可以定义一个**独立的** AVOID
Solve/Reconf：

1. 对输入 \(x\)，用 SAT oracle 生成一个 canonical dPCP proof table \(P_x\)；
2. 直接运行 \(\operatorname{JK}(G,P_x)\)；
3. 若 J--K 返回 easy circuit \(C\)，把同一个 \(C\) 作为 dPCP proof circuit，在
   \((i,1)\)-组件上查询 \(g(x)_i\)。

这给出一个严格的条件性 smart-prMA tradeoff，不需要 \(\Xi_x=P_x\)，也不需要 RM
prefix self-reduction。它是对 note 169 的重要修正：直接 J--K 使用本身并不需要
history compiler；需要 history compiler 的只是“把该新算法伪装成 RW Theorem 4.1 的
原始 Solve”。但这条独立算法仍没有提供 P vs NP 所需的 hard-instance forcing、全输入
failure 或 \(q\)-到输入尺度压缩。

## 1. 条件性 dPCP 组件

设 \(g:\{0,1\}^{n}\to\{0,1\}^{\ell}\) 是要重构的多输出函数，且对每个输入 \(x\)
有一个 computation-history SAT 电路 \(C_x(w)\)，满足所有 satisfying histories
的 deterministic output 都等于 \(g(x)\)。对 \(i\in[\ell]\)、\(b\in\{0,1\}\) 定义

\[
  \varphi_{x,i,b}(w):=
  C_x(w)\land[\operatorname{out}_i(w)=b].
\]

假设一个 dPCP 编译器满足四条明确接口：

* proof length 为统一的 \(L_*=L(\operatorname{poly}(t))\)，alphabet 可固定二进制编码；
* 给定满足 assignment \(w\)，存在确定性的
  \(\operatorname{Proof}(\varphi,w)\) 在 \(\operatorname{poly}(t)\) 时间生成 proof，
  且 verifier 完美接受；
* 不可满足公式的任意 proof assignment 接受率至多
  \(\epsilon<1/2\)；
* 给定 \((x,i,b)\)、随机 edge 和 proof address，constraint/decoder 的局部描述在
  \(\operatorname{poly}(k,r,\log t)\) 时间/电路大小内生成。

定义 canonical component：

\[
 \pi_{x,i,b}=
 \begin{cases}
 \operatorname{Proof}(\varphi_{x,i,b},w_{x,i,b}),&
       \varphi_{x,i,b}\text{ satisfiable},\\
 0^{L_*},&\text{otherwise},
 \end{cases}
\]

其中 \(w_{x,i,b}\) 是 lexicographically first satisfying assignment，并令

\[
  P_x=\mathop{\Vert}_{i\in[\ell],\,b\in\{0,1\}}\pi_{x,i,b},
  \qquad T=|P_x|=2\ell L_* .
\]

若 proof map 是 uniform 的，则 \(P_x\) 可由 SAT oracle 计算：所有组件的
lex-first witness 可按 bit position 并行自归约，只需 \(O(\log t)\) 个 adaptive
rounds，查询长度和总时间为 \(\operatorname{poly}(t)\)。若只有“存在 proof”而没有
这个 proof map，\(P_x\) 不是一个确定的 oracle-computable table，下面的算法不成立。

## 2. 独立 J--K 算法

定义 \(\operatorname{Solve}^{\mathrm{dPCP}}_g(x,G)\)：

1. 用上节的 SAT-oracle 过程显式生成 \(P_x\)；
2. 对 \(G:\{0,1\}^{k}\to\{0,1\}^{2k}\) 运行
   \(\operatorname{JK}(G,P_x)\)。

由 J--K 定理，输出二者之一：

* hard：\(y\notin\operatorname{Range}(G)\)；
* easy：大小 \(O(|G|\log T)\) 的电路 \(C\)，其 truth table 恰为 \(P_x\)。

若 \(G\) 大小至多 \(k^4\)，整个过程的时间是
\(\operatorname{poly}(T,|G|)^{NP}\)；J--K 的 NP witness length 为 \(k\)，其 query
rounds 为 \(O(k+\log(T/k))\)，再加上生成 \(P_x\) 所需的
\(O(\log t)\) witness-extraction rounds。这里不需要构造或查询 RW 的
computation-history PCP \(\Xi_x\)。

## 3. 独立 Reconf 与 smartness

在 Solve 返回 easy 的 failure 分支，定义
\(\operatorname{Reconf}^{\mathrm{dPCP}}_g(x,i)\) 为一个 prMA query：

* Merlin 提交大小 \(O(|G|\log T)\) 的电路 \(C\)，解释为候选 proof table；
* Arthur 在组件 \((i,1)\) 的 dPCP verifier 中抽样随机 edge；
* 用 \(C\) 读取该 edge 所需的 proof symbols；
* 当且仅当局部 dPCP constraint 接受时输出 YES。

### 正确性

若 \(g(x)_i=1\)，则 \(\varphi_{x,i,1}\) satisfiable，\(P_x\) 的
\((i,1)\)-组件是完美完备 proof。J--K easy 电路 \(C\) 的 truth table 恰为 \(P_x\)，
所以 Merlin 的真实 \(C\) 使 query 以概率 1（或在 decoder/routing 误差下至少
\(2/3\)）接受。

若 \(g(x)_i=0\)，则 \(\varphi_{x,i,1}\) unsatisfiable。对任何 Merlin 电路 \(C\)，
其输出在该组件上只是一个任意 proof assignment；由 dPCP 的 no-instance soundness，
接受率至多 \(\epsilon<1/2\)。因此 query 自动位于 prMA 的 NO 侧。

所以在每个具体 \((x,G)\) failure 实例上，

\[
 \operatorname{Reconf}^{\mathrm{dPCP}}_g(x,i)=g(x)_i,
\]

并且所有实际 query 都是 smart 的。这个证明不需要 lex-prefix、RM self-corrector、
auxiliary PCP 或跨组件的 canonical history；同一个 easy circuit 直接承载全部组件。

## 4. 与 RW Theorem 4.1 的关系

这不是 Theorem 4.1 的直接替换，而是一个新的 Solve/Reconf theorem：

* Theorem 4.1 把 J--K 作用在 computation-history PCP \(\Xi_x\)，再用 prefix
  soundness 恢复原函数输出；
* 本构造把 J--K 直接作用在 \(P_x\)，并用 dPCP no-instance soundness 判断单个输出位。

因此，本构造不需要证明 \(\Xi_x=P_x\)。若试图把它写回 Theorem 4.1 的固定
Solve_f 接口，才会重新遇到 history embedding 问题。note 170 的 output-lift 仍有价值，
但它比本构造多了一层 history PCP；在相同 dPCP proof map 假设下，直接 J--K 是更短的路线。

## 5. 这条路线还没有解决什么

### (a) 没有 hard-instance forcing

J--K 的二分只说明：每个 \(P_x\) 要么是 hard outsider 的来源，要么是 easy 并可被
small circuit 重构。它没有说明存在一个统一 \(G\)，使所有输入 \(x\) 都落在 easy
failure 分支，也没有说明某个 canonical \(P_x\) 必须超过
\(O(|G|\log T)\) 的 circuit threshold。若只有一个 \(x\) 失败，只得到一个输出点，
不能组成硬语言。

### (b) proof table 的 hardness 尚未从 \(g\) 传递

\(P_x\) 是 dPCP proof 的 canonical 编码。即使 \(g\) 的输出复杂，proof map 可能把
相关信息放在非局部约束中；反之，\(P_x\) 也可能在简单实例上是常值或低复杂度。现有
dPCP 完备性/列表 soundness 没有给 canonical proof 的 circuit lower bound。

### (c) q 尺度仍然存在

Easy circuit 的大小是 \(O(|G|\log T)\)，Reconf query 描述和 verifier evaluation
仍至少是 \(\operatorname{poly}(k,\log T)\)。因此这条路线没有把 J--K 的 \(k\)-bit
witness 或 \(G\) 描述压到输入 \(n\) 尺度；它只去掉了 RM prefix/auxiliary history
的额外复杂度。

### (d) standard dPCP 的 uniformity 必须真实核验

Theorem 3.12/Lemma 4.2 的 headline 给出 proof length、completeness 和 soundness，
但要代入上面的算法，还需实际构造：

* lex-first witness 到 proof 的 deterministic map；
* \((x,i,b)\) 到 verifier edge/decoder 的局部 generator；
* 对 unsatisfiable \(\varphi\) 的统一 no-instance soundness；
* 固定 binary encoding、padding 和组件 offset。

这些是可检查的接口，不应由“存在一个 dPCP”自动补齐。

## 6. 路线裁决

本 note 得到的最强安全结论是：

\[
\boxed{
\text{若四条 dPCP 接口成立，则 dPCP proof table 可直接进入 J--K，}
\text{并给出 q-scale smart-prMA 重构。}
}
\]

它相对于 note 169 的实质进展是移除了“必须复用 RW Theorem 4.1 history”的误解；
相对于最终 P vs NP 目标，仍缺少 hard-instance forcing、proof-table hardness
transfer 和输入尺度压缩。因此下一项真正有区分力的实验/证明应检查这三项之一，
而不是继续优化 prefix accessor。

## 7. 证据边界

J--K 的 easy/hard 输出、circuit size \(O(|G|\log T)\)、query witness length \(k\)
和 round bound 来自 Ren--Williams Theorem 3.1
[TR26-118 revision 1](https://eccc.weizmann.ac.uk/report/2026/118/revision/1/download)。

dPCP/udPCP 的定义、完备性、soundness 和近线性 proof 参数来自
[Gur--Min--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/html/2512.12960)。
本 note 的直接 Solve/Reconf 是由两组接口组合得到的条件性新推论，不是上述论文已经声明的
theorem。

