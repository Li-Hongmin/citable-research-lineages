> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Dual profile closure for field-lifted dPCPs (2026-08-17)

## Contribution

Note 257 gives the upper side of the field-lift argument: dPCP list soundness bounds
the wrong-claim probability by an outer-query Lorenz functional.  This note gives the
matching lower-side condition.  If the dPCP can realize the relevant local error
profiles and the first wrong projection forces the wrong claim, then the same honest
query profile is a necessary soundness cost.  Consequently a near-linear outer RLDC can
be field-lifted at fixed error only if its dPCP relation destroys top-set patchability
through a genuinely global coupling.

## Honest-path profiles

Fix a target message \(m\), coordinate \(i\), and an outer decoder with honest query
sequence
\[
J_{m,i,1}(\omega),\ldots,J_{m,i,\ell(\omega)}(\omega),
\qquad \ell(\omega)\le q_D .
\]
For a set \(S\subseteq[M]\), write
\[
h_{m,i}(S):=
\Pr_\omega[\{J_{m,i,r}(\omega):r\le\ell(\omega)\}\cap S\ne\varnothing],
\qquad
H_{m,i}(r):=\max_{|S|\le r}h_{m,i}(S).
\tag{258.1}
\]
For a fractional local-error profile \(e\in[0,1]^M\), define the first-error functional
\[
\Phi_{m,i}(e):=
\mathbb E_\omega\!\left[
1-\prod_{r=1}^{\ell(\omega)}
(1-e_{J_{m,i,r}(\omega)})
\right].
\tag{258.2}
\]
Fresh local dPCP randomness is assumed.  Thus, conditioned on an honest prefix, the
product is the probability that no queried local call returns a wrong accepted
projection.

Let \(\mathcal E_m\subseteq[0,1]^M\) be the set of error profiles realizable by global
dPCP proof assignments for the lifted target \(C(m)\).  The profile is
\[
e_t(z)=\Pr_{e\sim\mathcal P_t}
[\text{edge accepted and decoded symbol}\ne C(m)_t].
\tag{258.3}
\]
For the field-lifted relation, GMWZ list soundness implies
\[
\mathcal E_m\subseteq
\mathcal B_\varepsilon:=
\{e\in[0,1]^M:\sum_t e_t\le\varepsilon M\}.
\tag{258.4}
\]

## Theorem (dual profile closure)

Assume the compiled verifier aborts on rejection or \(\bot\), never outputs a wrong bit
on the exact outer codeword, and accepts the correct bit with probability at least
\(\alpha\) on the honest proof.

1. **Universal upper bound.** For every \(z\) with profile \(e(z)\in\mathcal E_m\),
\[
\Pr[V_{i,1-m_i}(z)=1]
\le \Phi_{m,i}(e(z))
\le \sum_t p_{m,i}(t)e_t(z)
\le \operatorname{Lor}_{\varepsilon}(p_{m,i}),
\tag{258.5}
\]
where \(p_{m,i}(t)\) is the expected honest query count and the last inequality uses
(258.4).

2. **Patchability lower bound.** Suppose that for every \(S\subseteq[M]\) with
\(|S|\le r\), there is a global proof assignment \(z_S\) such that its wrong accepted
projection profile contains the indicator \(1_S\) on the first honest hit, \(z_S\) lies
in the soundness neighborhood for target \(m\), and every first hit of \(S\) forces
acceptance of the wrong claim.  Then any robust soundness budget \(\delta\) must satisfy
\[
H_{m,i}(r)\le\delta .
\tag{258.6}
\]

3. **Exact one-query duality.** If each honest execution queries exactly one outer
position, then
\[
H_{m,i}(r)
=\max_{|S|\le r}\sum_{t\in S}p_{m,i}(t)
=\operatorname{Lor}_{r/M}(p_{m,i}).
\tag{258.7}
\]
Hence, when every \(r\)-set is patchable, the Lorenz upper bound and the robust-soundness
lower bound coincide exactly. For a multi-query nonadaptive decoder, (258.6) remains the
correct lower bound, while the Lorenz expression is generally only its union-bound upper
relaxation because several queried positions may lie in the same patch set.

### Proof

Until the first wrong accepted projection, every non-aborting local answer equals the
honest codeword symbol, so the outer query sequence is the honest sequence.  Conditioned
on a fixed honest random tape, the probability of a first wrong local answer is (258.2).
The elementary inequality
\[
1-\prod_r(1-u_r)\le\sum_r u_r
\tag{258.8}
\]
and averaging over \(\omega\) give
\[
\Phi_{m,i}(e)
\le\sum_t p_{m,i}(t)e_t.
\tag{258.9}
\]
The last inequality in (258.5) is the linear-program definition of the Lorenz mass.

For the lower bound, use \(z_S\).  Until the first honest query in \(S\), the patched
execution has the same transcript as the honest execution; the assumed forcing property
then makes the wrong branch accept on every first-hit tape.  Therefore its wrong-claim
probability is at least \(h_{m,i}(S)\), which cannot exceed \(\delta\).  Maximizing over
\(S\) proves (258.6). If each execution has one query, then
\(h_{m,i}(S)=\sum_{t\in S}p_{m,i}(t)\), giving (258.7). With multiple queries,
the equality can fail because query indicators overlap; the set-hitting functional
\(H_{m,i}\) must then be retained.
\(\square\)

## Near-linear consequence

Suppose an outer code family has fixed alphabet, fixed locality, a fixed positive radius,
and \(M=k\,\operatorname{polylog}k\).  The near-linear RLDC lower bound forces the top
\(\rho M\) honest-query positions to carry \(1-o(1)\) of the query mass (the proof-position
analogue is the pathwise Lorenz theorem).  Therefore a fixed-error field lift can survive
only if the corresponding top-set error profiles are **not** realizable with first-hit
forcing.  In the nonadaptive case, full patchability at the dPCP error budget would make
(258.6) incompatible with the near-one Lorenz mass and any constant branch gap.

This is the precise positive/negative split:

* a new dPCP/PCPP construction must prove global coupling that suppresses the top-set
  error profiles, not merely average list soundness; or
* a general barrier theorem must prove that the required top-set profiles are realizable
  (or that failure of realizability yields a short global descriptor/evaluator).

Ordinary list soundness alone gives only (258.4), so it cannot supply the second branch.
Conversely, the theorem does not claim that GMWZ realizes every \(S\); it isolates the
exact missing quantifier.

## Sources

* [GMWZ dPCP list soundness](https://arxiv.org/html/2512.12960), Definition 1.3.
* [Outer-query Lorenz field-lift bound](257-outer-query-lorenz-field-lift-compiler-2026-08-17.md).
* [Profile-hitting necessity](../../rw-jk-succinct-reconstruction/statements/profile-hitting-necessity-for-coordinate-robustness.md).
* [Patchability-or-succinctness closure split](228-exact-patchability-or-succinctness-closure-dichotomy-2026-08-17.md).
