> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(p=m\) sampler endpoint 是置换逆变换问题（2026-08-15）

## 命题

沿用 [note 091](091-noncanonical-sampler-decoder-image-range-2026-08-15.md) 的
\(\mathsf{Sam}_{m,p,t}\)，固定 \(p=m\)。对任意 sampler \(E\)，写

\[
A_E(r)=E(r)_{[m]}\in\{0,1\}^{m},
\qquad
B_E(r)=E(r)_{m+1}\in\{0,1\}.
\tag{1}
\]

则

\[
\operatorname{Valid}(E)
\quad\Longleftrightarrow\quad
A_E\text{ 是 }\{0,1\}^{m}\text{ 上的置换}.
\tag{2}
\]

在此情形下，\(\operatorname{Cons}(E)\) 自动成立，而且

\[
f_E(A_E(r))=B_E(r)
\qquad
\text{对所有 }r\in\{0,1\}^{m}.
\tag{3}
\]

因此

\[
\mathsf{SRange}_{m,m,t}
=
\left\{
y:\ \exists E,\ |E|\le t,
A_E\text{ 为置换},\
\forall r\ B_E(r)=y_{A_E(r)}
\right\}.
\tag{4}
\]

这里 \(y_{A_E(r)}\) 表示由 \(A_E(r)\) 索引的 truth-table 位。

## 证明

当 \(p=m\) 时，\(A_E\) 是从一个大小为 \(2^m\) 的有限集合到自身的映射。
\(\operatorname{Full}(E)\) 说它满射；有限等势集合上的满射等价于单射，故等价于置换。
若 \(A_E\) 是单射，则

\[
A_E(r)=A_E(r')\Longrightarrow r=r',
\]

所以 \(\operatorname{Cons}(E)\) 的前件只在 \(r=r'\) 时成立，\(\operatorname{Cons}(E)\)
自动为真。对任意 \(r\)，置换性又保证地址 \(A_E(r)\) 的唯一代表是 \(r\)，由式 (3)
得到式 (3) 和式 (4)。证毕。

## 复杂度下降

假设 \(t=t(m)\le 2^{O(m)}=N^{O(1)}\)，并使用固定、可解析的 gate-list 语法。
给定 \(y\in\{0,1\}^{2^m}\)，式 (4) 的见证是一个长度为
\(\operatorname{poly}(2^m)\) 的 sampler 描述 \(E\)。条件

\[
\begin{aligned}
A_E\text{ 为置换}
&\Longleftrightarrow
\forall r\ne r'\ A_E(r)\ne A_E(r'),\\
\forall r\ B_E(r)=y_{A_E(r)}
&\Longleftrightarrow
\forall r\ \bigl(B_E(r)=y_{A_E(r)}\bigr)
\end{aligned}
\tag{5}
\]

都是多项式时间可验证的全称条件：\(r,r'\) 只有 \(m\) 位，电路值逐门计算，\(y\) 的
地址寻址可用 \(O(2^m)\) 大小的选择电路完成。因此

\[
\mathsf{SRange}_{m,m,t}\in\Sigma_2^P
\tag{6}
\]

对固定 uniform schedule 成立。相比 \(p>m\) 时直接使用 \(\Pi_2^P\) 的
\(\operatorname{Full}\) 谓词，\(p=m\) 删除了 \(\forall x\exists r\) 中的内层存在量词。

同样，给定 decoder seed \(u\) 与地址 \(x\)，其输出位在语义有效时只需检查

\[
A_{\operatorname{Dec}(u)}\text{ 为置换}
\quad\land\quad
\exists r\,[A_{\operatorname{Dec}(u)}(r)=x\land B_{\operatorname{Dec}(u)}(r)=1].
\tag{7}
\]

第一个条件是 coNP，第二个是 NP；加上语法检查和固定零 fallback，逐位关系属于
\(\Delta_2^P=P^{NP}\)（因而也属于固定 PH）。

## 可逆地址族的包含关系

设 \(\mathcal A_{m,t}\) 是所有可由 size-\(t\) 有效 sampler 出现的地址置换。假设存在
一个统一的逆电路上界 \(u=u(m,t)\)：对每个 \(A\in\mathcal A_{m,t}\)，都有
一个计算 \(A^{-1}\) 的电路，size 至多 \(u\)。若 \(y=TT(f_E)\in\mathsf{SRange}_{m,m,t}\)，
由式 (3)

\[
f_E(x)=B_E(A_E^{-1}(x)).
\tag{8}
\]

把 \(B_E\) 与 \(A_E^{-1}\) 串接，得到一个直接计算 \(f_E\) 的电路，故

\[
\mathsf{SRange}_{m,m,t}
\subseteq
\mathsf{MCSP}_{m,O(t+u(m,t))}^{\mathrm{slice}}.
\tag{9}
\]

另一方面，note 091 的 identity-address 构造给出

\[
\mathsf{MCSP}_{m,s}^{\mathrm{slice}}
\subseteq
\mathsf{SRange}_{m,m,s+O(m)}.
\tag{10}
\]

所以任何具有统一小逆电路的地址族都不会产生已知的“超出 MCSP”的 noncanonical
机制；它至多把 MCSP 阈值从 \(s\) 改成 \(O(t+u)\)。

## 对 P vs NP 路线的裁决

\(p=m\) 端点已经把 sampler 分支压缩成一个明确的二难：

1. 若地址置换有统一小逆电路，则式 (9) 把 range 拉回固定 MCSP slice；
2. 若要得到真正新的 range 语言，必须使用 size-\(t\) 可计算但没有
   \(u(m,t)=\operatorname{poly}(m,t)\) 逆电路的置换，并证明相应的 inverse-circuit
   下界或 range-membership 下界。

第二项需要一般 Boolean 电路的逆置换下界；本 note 没有声称该下界已知，也没有证明
\(P\ne NP\)。它排除了“只换一个容易求逆的地址重排”这条伪 noncanonical 路线，并把
剩余难点明确定位为小电路置换的 worst-case inversion barrier。

原文核验日期：2026-08-15。
