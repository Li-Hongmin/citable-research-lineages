> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha auxiliary-oracle entropy-transfer barrier（2026-08-19）

## 本轮改变的判断

C439 说明：在 nonzero gate incidence 与 generic \(\widehat C\) evaluator 存在时，
一个 \(P=p(q)\) evaluator 可以反推出 systematic \(q\)。因此，\(P\) 段不能被
当作“与 target 无关的短辅助 oracle”。对一个高熵 witness family，这个反演会
把任何短 \(P\)-evaluator 编译成短 \(q\)-evaluator，再由描述计数得到消息尺度下界。

这给出一个 Harsha-specific 的 no-hidden-advice 定理。它不适用于 published
RW 的 singleton \(x_0\)（此时 family entropy 可能为零），但严格关闭了
“先给一个所有 targets 共用的 polylog \(P\)-accessor，再从中恢复整个 family”
这一逃逸。

## 定理 445.1（auxiliary-oracle entropy transfer）

令 \(H^m\) 有 \(N\) 个坐标，\(F\) 为 Harsha field，\(|F|=Q\)，并固定一个
gate relation \(C'\)、其延拓 \(\widehat C\)、一个 address-scale incidence map
\(\operatorname{Inc}(u)\)，以及一个不依赖 target 的 \(\widehat C\)-evaluator。
令 \(\mathcal Q_N\subseteq\{0,1\}^{H^m}\) 是一族 assignment functions，记
\(K=\log_2|\mathcal Q_N|\)。对 \(q\in\mathcal Q_N\)，令 \(P_q=p(\widetilde q)\)
为 Harsha 式

\[
 P_q(u,v,w,y_1,y_2,y_3)
 =
 \widehat C(u,v,w,y_1,y_2,y_3)
 \prod_{j=1}^{3}\bigl(\widetilde q(u_j)-y_j\bigr).
\tag{445.1}
\]

假设存在一个固定 evaluator architecture \(\mathsf E\)，大小为 \(s\)，以及每个
target 一个 descriptor \(\sigma_q\in\{0,1\}^{d}\)，使 \(\mathsf E(\sigma_q,\xi)\)
在 C439 所需的所有 field points 上精确输出 \(P_q(\xi)\)。假设：

1. 每个目标坐标 \(u\) 的 \(\operatorname{Inc}(u)\) 可在
   \(\operatorname{poly}(m,\log Q)\) 大小的电路中生成；
2. C439 的非退化条件和 \(|F|>(3m+3)|H|+2\) 成立；
3. evaluator architecture、\(\widehat C\)-evaluator、incidence map 和 field
   arithmetic 的 description 不携带未计入的 target-dependent advice。

则存在常数 \(c\) 和一个只依赖 \((m,Q,s,d)\) 的多项式 \(R\)，使

\[
 K
 \le
 d+
 O\!\left(
 R(m,Q)\,s\,
 \log\!\bigl(R(m,Q)s+m+Q\bigr)
 \right).
\tag{445.2}
\]

特别地，在 Harsha 的最小字段实例 \(Q=\operatorname{poly}(m)\)、incidence 与
\(\widehat C\)-evaluator 也为 \(\operatorname{poly}(m)\) 时，若
\(K=\Omega(N)\)，则不可能同时有 \(s,d=\operatorname{poly}(m)\)。任何共同的
address-scale \(P\)-accessor 必须携带

\[
 d+\operatorname{poly}(m)\,s
 =\Omega\!\left(\frac{N}{\log N}\right)
\tag{445.3}
\]

量级的信息/电路描述。

### 证明

由 C439，对任意 \(q\) 和任意目标坐标 \(u\)，枚举
\((a,b,y)\in F^3\)，调用 \(\mathsf E(\sigma_q,\cdot)\) 与固定
\(\widehat C\)-evaluator，在一个非零 slice 上取两个不同的 \(y\)，即可计算
\(\widetilde q(u)\)，再限制到 \(H^m\) 得到 \(q(u)\)。把该过程编译成一个
address evaluator \(D_{\sigma_q}\)：它只需硬接 \(\sigma_q\)，生成
\(\operatorname{Inc}(u)\)，枚举 \(O(Q^3)\) 个 field triples，并完成有限域运算。
因此 \(D_{\sigma_q}\) 的电路规模至多为

\[
 S=R(m,Q)\,s+\operatorname{poly}(m,Q).
\tag{445.4}
\]

若 evaluator architecture 也允许随 target 改变，则其电路 description 长度
\(O(s\log(s+m+Q))\) 一并计入 descriptor；下述计数不变。大小至多 \(S\)、
输入长度 \(m\) 的 fan-in-two circuits 数量不超过

\[
 2^{O(S\log(S+m))}.
\]

再乘上 \(2^d\) 个 descriptors，所有可由该 \(P\)-evaluator family 产生的
assignment functions 数量至多为

\[
 2^{d+O(S\log(S+m))}.
\]

它必须覆盖 \(\mathcal Q_N\)，故
\(K\le d+O(S\log(S+m))\)，吸收 \(\operatorname{poly}(m,Q)\) 项后得到
(445.2)。当 \(K=\Omega(N)\) 且 \(Q=\operatorname{poly}(m)\) 时，若 \(s,d\) 都是
\(\operatorname{poly}(m)\)，右端仅为 \(N^{o(1)}\)，矛盾；整理即得 (445.3)。
证毕。

## 对 RW/Harsha closure 的精确含义

* C444 可以在 cell-time representation 下提供固定的 \(\widehat C\)-evaluator，
  但它不削弱定理 445.1：若 \(P\)-evaluator 仍要区分
  \(2^{\Omega(N)}\) 个 canonical assignments，它必须把 target information
  放进 descriptor 或 evaluator description。
* 若只研究 published \(x_0=0^{n_0}\) singleton，\(K=0\) 的计数界是空的；
  这正是 actual RW Gate-I 仍未闭合的量词边界，而不是可以偷换成 family theorem
  的理由。
* 若 descriptor 达到 forcing scale，则进入 C207/C220 的
  forcing-scale advice lower bound；若 descriptor 保持短而 family 具有共同
  word-consistent proof，则应转入 RLDC/LDC 或 distributional-soundness barrier。
* 因而 Harsha 的 \(P\) oracle 只有三种可解释状态：已有 q-level access、携带
  message-scale target information、或离开 factorized \(P=p(q)\) interface。

## 证据边界

本定理是 C439 的信息论/电路计数推论，不声称 published RW 提供 evaluator，
也不证明 singleton 的 \(P\ne NP\)。它要求 family-level 的高熵
\(\mathcal Q_N\)、固定 incidence 和 target-independent \(\widehat C\) source。
它不是一般 dPCP/RLDC impossibility；其价值是把 Harsha auxiliary branch 的
“隐藏 advice”精确接到 message entropy，而不是把完整 proof table 的长度误作
address-scale evaluator。

## 来源

* [note 439](439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md)。
* [note 444](444-cell-time-offset-regular-rw-unrolling-2026-08-19.md)。
* [note 220](220-rw-forcing-scale-advice-lower-bound-2026-08-17.md)。
