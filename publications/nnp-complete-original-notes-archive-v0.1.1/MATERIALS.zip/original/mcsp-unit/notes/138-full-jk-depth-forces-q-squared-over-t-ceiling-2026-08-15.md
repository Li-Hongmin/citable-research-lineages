> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 全 JK 深度下 universal closure 的 \(q^2/T\) 上限（2026-08-15）

## 命题

令

\[
G_q:\{0,1\}^{q}\to\{0,1\}^{2q},
\qquad
q=2^{m-1},
\]

并令 \(\mathcal C_{m,s}\) 是所有 \(m\)-变量、size 至多 \(s\) 的 truth tables。假设：

1. \(\mathcal C_{m,s}\subseteq\operatorname{Range}(G_q)\)；
2. 对每个 \(A\subseteq\mathcal C_{m,s}\)，每个 \(2^h\)-叶 ordered tuple
   都有一个深度 \(h\) 的 word-consistent JK witness tree，所有内部 blocks
   仍在同一个 \(\operatorname{Range}(G_q)\) 中。

在能嵌入 Lupanov \(\ell\)-variable family 的参数区间，必有

\[
2^h\,s\log s=O(q).
\tag{1}
\]

若 JK 对长度 \(T\) 的显式 truth table 运行完整递归，取

\[
2^h=\Theta(T/q),
\tag{2}
\]

则得到

\[
\boxed{s\log s=O(q^2/T).}
\tag{3}
\]

## 证明

取最大整数 \(\ell\le m\)，使固定完备 fan-in-2 basis 的 Lupanov 常数 \(C_L\) 满足

\[
C_L\,2^\ell/\ell\le s.
\]

于是 \(\mathcal C_{m,s}\) 至少包含忽略 \(m-\ell\) 个变量的 family

\[
A_\ell
=\{f(x_1,\ldots,x_\ell):f:\{0,1\}^{\ell}\to\{0,1\}\},
\qquad
|A_\ell|=2^{2^\ell}.
\tag{4}
\]

多层 JK capacity lemma 给出

\[
|A_\ell|^{2^h}\le2^q,
\]

所以

\[
2^h\,2^\ell\le q.
\tag{5}
\]

在 \(s\) 足够大、\(\ell<m\) 且 \(\ell=\Theta(\log s)\) 的区间，这个最大性选择给出
\(2^\ell=\Theta(s\log s)\)；Lupanov 关系

\[
L(\ell)=O(2^\ell/\ell)
\]

保证该 \(\ell\)-variable family 确实落在 \(\mathcal C_{m,s}\) 中。若最大性端点为
\(\ell=m\)，则 \(2^\ell\) 更大，式 (1) 只会更强。代入式 (5) 即得式 (1)。
Ren--Williams/Jeřábek--Korten 的 stage decomposition 对
\(T'=q2^k\) 的 zero-padded table 使用 \(k=\Theta(\log(T/q))\) 个 stage，因此
完整递归的叶数满足式 (2)。代入式 (1) 得式 (3)。证毕。

## 参数含义

式 (3) 是对 **universal** representation 的参数上限，不是对一条 concrete history
的下界。它给出三个直接后果：

1. 若 \(T\ge q^{2+\delta}\)，则 \(q^2/T\le q^{-\delta}\)，式 (3) 对任何
   \(s\ge2\) 都不可能成立；全深度 JK 不能同时覆盖任何非平凡的低电路 family。
2. 若 \(s=q/\log^{1+\varepsilon}q\)，则式 (3) 要求
   \(T=O(q\log^{1+\varepsilon}q/\log s)=q\,\operatorname{polylog}q\)；
   proof 长度一旦远超近线性，universal closure 立即失效。
3. 因而半率 algebraic leaf decoder 之类的构造若要进入 RW full proof，不能把
   每一层都当作对所有 covered tables 的 universal closure；必须利用 actual history
   的相关性、一个共享 global key，或改变 JK 的分块/递归接口。

这也解释了为什么 note 137 的有限深度构造可以成立：它只支持叶熵
\(q/2^h\)，而不声称覆盖 \(\mathcal C_{m,s}\) 的 near-saturation family。

## 与 \(P\) vs \(NP\) 路线的边界

这个上限排除了一个看似自然但过强的正向目标：

\[
\text{near-linear coverage}
\;+\;
\text{对整张 RW PCP table 的 universal JK closure}.
\]

它没有排除两种仍可能改变复杂度结论的对象：

- 只对一个 fixed history 有效的 joint labeler；
- 不要求每个 JK parent 都在同一 range 的 compressed-JK/search 算法。

因此下一步不应再尝试把 note 137 的有限深度标签器直接扩展成 universal full-table
decoder，而应从 RW 的实际 PCP history 中证明共享 global key，或设计新的
history-specific range predicate。本文不声称 \(P\ne NP\)。

来源：Ren--Williams Theorem 3.1（ECCC TR26-118 revision 1）、notes 106、137；
式 (1)--(3) 为本项目对 stage depth 与 Lupanov family 的自足推导。
