> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Ueno--Chukhin 势到 affine-parity QA 的迁移边界

日期：2026-08-13

## 0. 结论

Ueno 的 quasi-additive (QA) 框架本身**完全适用于** affine-parity 叶：只需把合法叶族从坐标单色矩形换成

\[
\mathcal L_{\oplus}
 =\{A\times B:\exists\ell\text{ affine parity},\
                    \ell|_A=0,\ell|_B=1\}.
\]

但 Chukhin--Kulikov--Mihajlin (CKM) 的 second-stage measure 不能无损迁移。其 leaf normalization 使用 strong-KW 的**固定坐标标签** `(i,j)`；一片 Formula--XOR 叶可以同时命中任意多条坐标边。故现有 CKM 证明只给出

\[
\mathrm{CP}_{\rm strong\text{-}KW}\nobreak\gg
\mathrm{CP}_{\rm Formula\circ XOR}
\]

的强关系下界，不能反向推出后者。

## 1. Ueno QA 的关系无关形式

给关系 \(R=(X,Y,\Lambda)\)，其中一个合法叶是 \((A,B,\lambda)\)，满足
\[
\lambda\in\bigcap_{(x,y)\in A\times B}\Lambda(x,y).
\]
若矩形势 \(\mu\) 满足

\[
\mu(A\times B)\le 1\quad\text{(每个合法叶)},
\]
\[
\mu(r)\le \mu(r_1)+\mu(r_2)
\quad\text{(任意水平/垂直二分)},
\]

则归纳给出
\[
\mu(X\times Y)\le \mathrm{CP}_{\Lambda}(R).
\]

Ueno 的 LP 变量 \(V_c,V_{c,r}\) 正是上述势的坐标化；对任意关系有
\[
\mathrm{QA}(R)=\mathrm{CP}(R).
\]
因此对于 \(\Lambda(x,y)=\{\ell:\ell(x)\ne\ell(y)\}\)（所有 affine parity），QA 是精确的 Formula\(\circ\)XOR 协议分割数，而不是仅仅一个下界。

## 2. CKM second-stage measure 的精确依赖

CKM 对 strong \(\mathrm{KW}_{\oplus_m}\circledast\mathrm{KW}_{f}\) 在一个协议节点构造图 \(G_S\)。若边
\(e=(u,v)\) 的外层坐标标签为 \(i\)，并取该边的内层投影，则

\[
\xi_S(A\times B)
 =\sum_{e=(u,v)}
   \mathsf L\!\left(\operatorname{proj}_{i(e)}\!\mathcal B_A(u)
       \times\operatorname{proj}_{i(e)}\!\mathcal B_B(v)\right).
\]

每项的公式大小 \(\mathsf L\) 对矩形分割次可加，所以 \(\xi_S\) 递归次可加。关键是 leaf normalization：strong-KW 叶固定一个坐标对 \((i,j)\)。同一叶不能同时服务两条具有不同外层标签的边；因此至多一项非零，\(\xi_S(\text{leaf})\le1\)。这正是 CKM 的 Lemma 15 的逻辑。与第一阶段的 Khrapchenko 势结合，得到其 \(n^{2-o(1)}\mathsf L_{3/4}(f)\) 强关系下界。

## 3. affine-parity leaf normalization 失败：最小反例

令输入为 \(m\times r\) 矩阵，取
\[
F(X)=\bigoplus_{i=1}^{m}\bigoplus_{j=1}^{r}X_{i,j}.
\]
这是一个 Formula\(\circ\)XOR，单个 affine 叶 \(\ell=F\) 即可计算。另一方面，在
\(\mathrm{KW}_{\oplus_m}\circledast\mathrm{KW}_{\oplus_r}\) 中，输入对
\[
(X,Y)=(e_{i,j},0)
\]
要求输出该唯一的坐标对 \((i,j)\)，不同格点不能合并为一个 strong-KW 叶；所以 strong 协议需要至少 \(mr\) 个叶。

因此，若把 CKM 的 \(\xi\) 项改成适用于 affine 叶的内层公式大小，则同一全局 affine 叶会同时命中多条边，叶值一般为 \(\Omega(m)\)（按格点计甚至 \(\Omega(mr)\)），而非 \(\le1\)。任何普适的叶数保持式
\[
\mathrm{CP}_{\rm strong}\le \operatorname{polylog}(mr)\,\mathrm{CP}_{\rm affine}
\]
均被该例排除。

更一般地，设 \(E\) 是任意边族，\(H_e\ge0\) 且
\(H_e(A_e\times B_e)\ge1\)。若存在一个 affine parity \(\ell\) 同时分离所有
\(A_e\times B_e\)，则对该单叶 \(L_\ell\)
\[
\sum_{e\in E}H_e(L_\ell)\ge |E|.
\]
所以所有“逐边非负求和 + 每边至少一单位”的 second-subadditive 模板，只有在把总边权归一化到 \(O(1)\) 后才可能满足 QA 叶约束；若根值依赖 \(|E|\) 的累积，该模板必然坍缩。Parity 外层正好提供这样的共同 affine separator，故这不是 CKM 参数的偶然损失，而是模型级 no-go。

## 4. 唯一可写的条件性 transfer lemma

设每个递归节点给出带权边族 \((E_S,w_e)\)，并令
\[
\xi_S(r)=\sum_{e\in E_S}w_e\,H_e(r),
\]
其中每个 \(H_e\) 对水平/垂直分割次可加。若能额外证明
\[
\tag{LC}
\sup_{\text{affine-parity leaf }L}
\sum_{e:\,L\text{ separates }e}w_eH_e(L)\le1,
\]
且在节点间有 CKM 型递归（允许固定损失 \(1-\varepsilon_S\)），则
\[
\mathrm{CP}_{\rm affine}(X\times Y)
 \ge \xi_{\rm root}(X\times Y)\prod_S(1-\varepsilon_S).
\]
证明只是 Ueno 的 QA 归纳：`(LC)` 是 leaf normalization，次可加性负责递归，沿树求和。

当前模型的实质问题正是 `(LC)`：任意 affine parity 可为全局 parity，命中 \(\Theta(mr)\) 条 strong-KW 边；因此 `(LC)` 不可能由“所有 affine 叶”这一模型假设推出。若只知道一个命中上界 \(\rho\)，除以 \(\rho\) 后根势同时损失 \(\rho\)，CKM 的超二次增益便不再自动保留。

## 5. MCSP promise 与量词顺序

令 \(X=E_a=\{f:\mathrm{CC}(f)\le a\}\)，\(Y=NO_b=\{g:\mathrm{CC}(g)>b\}\)。MCSP promise 只改变关系的根集合；它不改变 affine 叶可以命中多条边这一事实。因此 MCSP 不能单独修复 `(LC)`。

要得出 GapMCSP 的 Formula\(\circ\)XOR 下界，必须一次性构造
\[
\exists(\phi,\{V_{c,r}\})\quad
\forall\text{ affine leaves }L,
\forall\text{ recursive partitions }(r_1,r_2),
\text{QA constraints},
\]
并证明根目标 \(\sum_c\phi_c\ge N^{1.01}\)。CKM 的证明只对给定的 random/0.49-balanced \(f\) 与强关系，先选图、再按协议节点清理；这对应的是
\(\forall f\;\exists\text{图/势}\) 的局部构造，不能交换成 MCSP 所需的
\(\exists\text{单一势}\;\forall L,r\) 的量词。

更细的缺口是协议依赖性：CKM 先固定一个候选 strong-KW 协议 \(P\)，再沿 \(P\) 的节点选择/清理 \(G_S\) 与 \(\xi_S\)，实际量词是
\[
\forall P\;\exists\{G_S(P),\xi_S(P)\}.
\]
Ueno QA 则要求一组协议无关的变量
\[
\exists\{\phi_c,V_{c,r}\}\quad\forall L,r_1,r_2.
\]
从 CKM 到 QA 还缺一个 protocol-independent **globalization lemma**：把依赖 \(P\) 的图清理编码成固定 \(V_{c,r}\)，同时保持叶容量与根值。简单并列所有候选图会按图数累加叶容量，摧毁目标增益；目前没有该引理。

## 来源

- Kenya Ueno, *Breaking the Rectangle Bound Barrier against Formula Size Lower Bounds*, MFCS 2010: <https://www.lab2.kuis.kyoto-u.ac.jp/~kenya/MFCS2010.pdf>（QA 定义、次可加性、`QA(R)=CP(R)`）。
- Nikolai Chukhin, Alexander S. Kulikov, Ivan Mihajlin, *Toward Better Depth Lower Bounds: Strong Composition of XOR and a Random Function*, STACS 2025: <https://arxiv.org/html/2410.10189>（second-stage \(\xi\)、leaf normalization、递归损失）。
