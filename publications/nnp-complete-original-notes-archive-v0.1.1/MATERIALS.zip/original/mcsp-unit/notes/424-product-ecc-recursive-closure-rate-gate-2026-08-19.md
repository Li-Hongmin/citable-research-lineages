> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Product-ECC recursive closure 的码率门槛（2026-08-19）

## 本轮改变的判断

C400 只说明低码率 product-ECC 的单个 \(2k\)-bit interval 可以被一个
\(k\)-bit seed 的 generator 覆盖；C402 说明这种覆盖若要沿 JK 的
canonical half-preimage 递归保持，就必须支付乘法容量。本 note 把两者在一个
source-realizable 的 aligned product-ECC window 中合并，得到一个明确的码率门槛：

> 当每个 non-output block 含有约 \(2Rk\) bits 的独立 ECC payload 时，两个相邻
> blocks 的 recursive range-closure 要求 \(4Rk\le k\)。因此固定码率
> \(R>1/4\) 的 product-ECC 虽可在一层被 range-cover，却不可能在一个
> product-rich family 上同时满足下一层的 JK range-closure。

这不是对 published \(x_0\) singleton 的结论；它是把实际 Harsha/ECC source branch
的正向 cover 精确接到 C402 递归容量上的 family-level barrier。

## Aligned product-ECC family

令

\[
 E_0:\mathbb F_2^a\longrightarrow\mathbb F_2^b
\]

是 injective linear encoder，码率 \(R=a/b\)。把 product code

\[
 E_0^{\oplus N}(u_1,\ldots,u_N)
\]

按连续的 \(b\)-bit codeword 排列。固定一个 JK width \(k\)，并先考虑对齐窗口

\[
 b\mid 2k,
 \qquad q:=2k/b.
\tag{424.1}
\]

取两个相邻、完全位于 \(\Upsilon\) segment 内的 \(2k\)-bit blocks。令
\(\mathcal A,\mathcal B\) 分别为这两个 blocks 在 product-code family 上的取值集合，
并要求它们所依赖的 \(q\) 个 source symbols 两两不相交。由于 \(E_0\) injective
linear，

\[
 |\mathcal A|=|\mathcal B|=2^{qa}=2^{2Rk}.
\tag{424.2}
\]

这里的 product-rich family 是一个 source-level stress family：两个 symbol
groups 可以独立取任意值。它不是说 published RW 的固定 honest payload image
已经包含整个 message space。

## 定理 424.1（two-level product-ECC rate barrier）

令 \(G_k:\{0,1\}^k\to\{0,1\}^{2k}\)，\(R_G=\operatorname{Range}(G_k)\)，
并令 \(p:R_G\to\{0,1\}^k\) 是 JK 使用的 canonical preimage。假设：

1. 两个 aligned product-ECC blocks 的所有值均为 non-output recursive blocks；
2. 对每个 \((a,b)\in\mathcal A\times\mathcal B\)，source family 都实现一个
   canonical proof，其中 \(a,b\) 相邻，且下一层 block
   \(p(a)\Vert p(b)\) 仍为 non-output；
3. proposed recursive cover 要求这些 blocks 以及所有
   \(p(a)\Vert p(b)\) 都属于 \(R_G\)。

则

\[
 4Rk=2qa\le k.
\tag{424.3}
\]

特别地，在 aligned window 上若 \(R>1/4\)，不可能存在一个与 payload 无关的
generator 同时实现上述两层 non-output recursive range-closure。

### 证明

由 (424.2)，

\[
 |\mathcal A|\,|\mathcal B|=2^{2qa}.
\]

假设 3 允许应用 C402 的 two-block product-closure 定理。canonical preimage
\(p\) 在 \(R_G\) 上 injective，因此映射

\[
 (a,b)\longmapsto p(a)\Vert p(b)
\]

在 \(\mathcal A\times\mathcal B\) 上 injective，且其像包含在
\(R_G\) 中。于是

\[
 2^{2qa}=|\mathcal A|\,|\mathcal B|
 \le |R_G|\le 2^k.
\]

取 \(\log_2\)，并代入 \(q=2k/b\)、\(R=a/b\)，得到

\[
 2qa=4ak/b=4Rk\le k.
\]

证毕。

## 与单层 universal cover 的精确关系

C400 的单层 seed budget 在同一个 aligned window 中只要求大约

\[
 qa=2Rk
\]

个 payload bits（再加 offset/tag 开销）不超过 \(k\)，所以它允许的主要窗口是
\(R<1/2\)。定理 424.1 的递归要求把两个独立 blocks 的 payload 合并，门槛下降为
\(R\le1/4\)。因此存在一个真实的 source-level gap：

\[
 \boxed{
 1/4<R<1/2:
 \text{单层 auxiliary cover 可行，但两层 target-oblivious recursive cover 不可行。}
 }
\tag{424.4}
\]

当 \(R\le1/4\) 时，本定理不构成 closure 构造；它只说明该容量门不再由这两个
blocks 单独触发。仍需处理 segment 边界、JK half-preimage 的描述、systematic
output attachment 以及 whole-parent binding。

## 对 RW/Harsha Closure 的作用与边界

* **关闭的 source branch：** 若一个固定率 \(R>1/4\) 的显式 linear ECC 被放入
  连续 \(\Upsilon\) segment，且 proposed Gate-I 需要对一个 product-rich payload
  family 让所有 non-output recursive blocks 保持 in-range，那么 C400 的单层
  cover 不能直接升级为 C401 所需的 recursive closure。
* **仍开放的低率 branch：** 选择 \(R\le1/4\) 可能避开这个两层容量门，但不提供
  output attachment，也不处理 Harsha 的实际 nonlinear image；需要新的 closure
  论证或更深层的 product subtree capacity。
* **对齐是实质假设：** (424.1) 让相邻 blocks 依赖不相交的完整 codeword
  groups。若 binary serialization 不保持该对齐，必须重新给出两个独立 projection
  families；不能把 (424.3) 自动套到任意交错坐标。
* **不能套 singleton：** published Theorem 4.3 固定 \(x_0\)，没有这里所需的
  \(\mathcal A\times\mathcal B\) product-rich quantifier。公开输入本身若携带两个
  payloads，也必须在任何 parent-binding 论证中计入 descriptor；本定理不把输入
  熵冒充为隐藏历史熵。

因此本 note 的严格结论是一个**码率—递归深度 gate**，不是 \(P\ne NP\) 证明，
也不是对所有 PCP/ECC 实现的 impossibility theorem。它把 C400/C401/C402 的
接口压缩为一个可核验的 source obligation：若想保留 address-scale 的
non-output recursive cover，必须进入 \(R\le1/4\) 的低率分支，或改变
product-rich / target-independent / same-proof 量词。

## 上游与证据边界

* [C400](400-low-rate-product-ecc-universal-block-cover-2026-08-18.md)：单层
  product-ECC universal block cover；
* [C402](402-jk-recursive-range-closure-capacity-2026-08-18.md)：canonical
  half-preimage 的 two-block product capacity；
* [C396](396-product-linear-ecc-rate-greater-half-block-rank-2026-08-18.md)：
  high-rate block-rank gate；
* RW Theorem 3.5 与 Harsha §5.4.3：systematic prefix、
  \(\Gamma/\Upsilon\) product-ECC serialization 的 source boundary。
