> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha generic-point evaluator for offset-regular gate relations（2026-08-19）

## 本轮改变的判断

C440 的 gate-list 下界只适用于黑箱 source representation；它不排除某个固定的
time-unrolling 把所有 gate tuples 组织成少量“同一 base address 加固定偏移”的族。
对这种更强的布局，可以直接把 Harsha 的 Lagrange 延拓评价写成一个有限状态的
digit-DP，而不扫描完整 gate list。于是 \(\widehat C\) 的 generic-point evaluator
可以作为一个严格的 source lemma 被攻，而不是继续把 object-scale scan 当作唯一可能。

这个结果是条件性的：C442 只规则化了 output/equality block，没有证明完整的
deterministic simulation subcircuit 具有这里的 offset-regular serialization。

## 定义 443.1（offset-regular gate relation）

令 \(H=\{0,\ldots,h-1\}\subseteq F\)，\(N=h^m\)，并用
\(\operatorname{enc}_m(z)\in H^m\) 表示 \(z\in[N]\) 的 base-\(h\) 小端数字。令

\[
  S_m:=\{(i_1,i_2,i_3,\beta_1,\beta_2,\beta_3):
       C'(i_1,i_2,i_3,\beta_1,\beta_2,\beta_3)=1\}.
\]

称 \(S_m\) 是 \(R\)-族 offset-regular 的，如果它可以写成互不相交的并

\[
 S_m=\biguplus_{\tau=1}^{R}
 \left\{\bigl(\operatorname{enc}_m(z+\delta_{\tau,1}),
                 \operatorname{enc}_m(z+\delta_{\tau,2}),
                 \operatorname{enc}_m(z+\delta_{\tau,3}),
                 \beta_\tau\bigr):z\in I_\tau\right\},
\tag{443.1}
\]

其中 \(\beta_\tau\in H^3\)，且对 \(z\in I_\tau\) 三个 \(z+\delta_{\tau,j}\) 都落在
\([N]\) 内；\(I_\tau\subseteq[N]\) 是由常数状态的逐位数字
自动机识别的区间（允许若干半开区间的有限并），每个带符号偏移
\(\delta_{\tau,j}\) 的 base-\(h\) 数字、区间端点和族描述都能在
\(\operatorname{poly}(m,\log h)\) 时间生成。若若干族原本相交，要求先用一个
大小为 \(\operatorname{poly}(m)\) 的确定性数字自动机去重；这一步的状态数计入
下述复杂度。

## 定理 443.2（offset-regular \(\widehat C\) evaluator）

设 \(S_m\) 是 \(R\)-族 offset-regular，且去重后的逐位自动机状态数为 \(s\)。
给定任意 generic point
\(\xi=(\xi^{(1)},\xi^{(2)},\xi^{(3)},\eta)\in F^{3m+3}\)，可以在

\[
  O\!\left(R\,m\,s^2\,h\right)
\]

次基本域运算（外加生成 \(O(mh)\) 个一元 Lagrange 值的代价）中精确计算
\(\widehat C(\xi)\)，其中 \(\widehat C\) 是 \(C'\) 在 \(H^{3m+3}\) 上逐变量低度延拓。
特别地，当 \(R,s,h=\operatorname{poly}(m)\) 时，\(\widehat C\) 有
\(\operatorname{poly}(m)=\operatorname{poly}(\log N)\) 的 exact evaluator。

### 证明

写 \(\ell_a\) 为 \(H\) 上的 Lagrange 基。对族 \(\tau\)，其贡献是

\[
 W_\tau(\xi)=
 \left(\prod_{q=1}^{3}\ell_{\beta_{\tau,q}}(\eta_q)\right)
 \sum_{z\in I_\tau}\prod_{j=1}^{3}\prod_{r=0}^{m-1}
 \ell_{d_r(z+\delta_{\tau,j})}\!\left(\xi^{(j)}_r\right),
\tag{443.2}
\]

其中 \(d_r(u)\) 是 \(u\) 的第 \(r\) 个 base-\(h\) 数字。

从低位到高位扫描 \(z\)。对每个 \(j\)，维护计算
\(z+\delta_{\tau,j}\) 的有限 carry/borrow 状态；区间 \(I_\tau\) 的端点约束
也由一个有限 borrow/comparison 状态维护。每次读入 \(z\) 的一位 \(a\in H\)，
状态唯一决定三个输出数字 \(b_j\in H\) 及下一状态。令 \(M_{\tau,r}\) 是这一层的
\(s\times s\) 转移矩阵，其 \((q,q')\) 元为所有导致 \(q\to q'\) 的 \(a\) 的权重和：

\[
 (M_{\tau,r})_{q,q'}=
 \sum_{a:\,q\xrightarrow{a}q'}
 \prod_{j=1}^{3}\ell_{b_j}\!\left(\xi^{(j)}_r\right).
\tag{443.3}
\]

初始状态固定为零 carry/borrow，终止向量只接受无溢出且满足 \(I_\tau\) 的状态。因此

\[
 \sum_{z\in I_\tau}\prod_{j,r}\ell_{d_r(z+\delta_{\tau,j})}
    =e_{\mathrm{start}}^{\mathsf T}
      M_{\tau,0}M_{\tau,1}\cdots M_{\tau,m-1}e_{\mathrm{acc}}.
\tag{443.4}
\]

将 (443.4) 乘以三个 pattern 权重并对 \(\tau\) 求和，即得到
\(\sum_{a\in H^{3m+3}}C'(a)\prod_k\ell_{a_k}(\xi_k)=\widehat C(\xi)\)。
每层矩阵的每个元素至多枚举 \(h\) 个输入数字，故总成本为
\(O(Rms^2h)\)；有限域乘法和 Lagrange 值生成的成本另计。证毕。

## 对 RW/C442 的精确含义

如果 deterministic simulation 的每一类局部 gate 都能在一个重新规定的
serialization 中写成有限个

\[
  (z+\delta_1,z+\delta_2,z+\delta_3)
\]

的 offset 族（例如 cell-time unrolling 中局部邻接线的固定地址偏移），且边界与
gate-type 只需 \(\operatorname{poly}(m)\) 个数字自动机状态，那么定理 443.2
给出 C439 所需的 generic-point \(\widehat C\) evaluator。C442 的连续 equality
 block 可直接加入有限个 offset 族；balanced-AND block 若采用
 \(p\mapsto(2p+1,2p+2)\) 的堆式编号，则还需要单独证明相应的有限状态
 affine-digit 关系，不能仅由本定理自动得到。

但以下三点仍未由 C442 或 RW Lemma 3.2 得到：

1. published \(C_x\) 是否允许这种 cell-time/offset serialization；
2. 模拟机的所有局部 gate 是否只有 \(\operatorname{poly}(m)\) 个族，而不是需要
   message-scale gate metadata；
3. 同一 serialization 上 auxiliary \(P=p(q)\) 是否也有 address-scale field-symbol
   evaluator。

因此定理 443.2 只把 C440 的“可能存在快速 weighted sum”具体化为一个可检验的
source hypothesis；它还不是 actual RW closure，也不单独推出 \(P\ne NP\)。

## 证据边界与停止条件

* 这是对 Harsha 延拓公式的有限状态求值定理，不是对任意 gate list 的快速算法；
  黑箱模型中的 \(\Omega(|C|)\) 下界仍然成立。
* 若真实 RW serialization 的 gate tuple 需要按一个未压缩的 wire permutation
  或任意 machine-code 表查找，offset-regular 假设失败，C440 的 object-scale
  barrier 仍是当前结论。
* 下一步只需对固定 \(P=NP\) machine 的 chosen unrolling 给出（或否定）三个
  offset-regular 证书：gate-family 分解、地址偏移生成器、边界自动机。若这三者
  无法在 \(\operatorname{poly}(m)\) 描述，则本正攻在此停止，不继续扩展抽象自动机。

## 来源

* Harsha, *Robust PCPs of Proximity and Shorter PCPs*, §5.4.1,
  Proposition 5.4.1, equations (5.6)--(5.8)；本地抽取：
  [unbundled local reference]
* [note 439](439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md)。
* [note 440](440-harsha-constraint-extension-source-interface-barrier-2026-08-19.md)。
* [note 442](442-rw-regular-output-gate-compiler-2026-08-19.md)。
