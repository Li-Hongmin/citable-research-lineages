> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Growing-alphabet/locality phase boundary for shared-proof robustness (2026-08-17)

## Contribution

The fixed-alphabet assumption in the constant-locality closure can be relaxed without
losing a quantitative theorem.  When the proof alphabet is allowed to depend on the
message length, the same tagged inline compiler and the arbitrary-alphabet RLDC bound
give a single tradeoff between the branch-tree size and the alphabet scale.  In the
near-linear regime, the product

\[
 Q_k\bigl(1+\log\log(k+2)+\log\log(A_k+2)\bigr)
\]

must be at least a constant multiple of \(\log k\).  Consequently a one-query branch
with near-linear length can evade the fixed-alphabet barrier only by using an alphabet
of size at least \(2^{k^{\Omega(1)}}\); a merely polynomial, quasipolynomial, or
\(2^{k^{o(1)}}\)-size alphabet is not enough.  This closes the most natural growing-
alphabet escape up to the doubly-exponential-scale boundary where the RLDC radius
condition itself becomes vacuous.

## Theorem

Let \(A_k\ge2\), let \(\Sigma_k\) be a proof alphabet of size \(A_k\), and fix
constants \(0<\rho<1\), \(\sigma_0>0\), and \(c>0\).  Suppose

\[
 \Pi_k:\{0,1\}^k\longrightarrow \Sigma_k^{P_k}
\]

is a common proof map.  For each message coordinate \(i\) and claim \(b\), let
\(V_{i,b}\) be a randomized adaptive verifier making at most \(r_k\ge1\) proof-symbol
queries.  Assume, uniformly over messages, coordinates, and nearby proof words,

\[
 p_{i,m_i}(\Pi_k(m))=1,
 \qquad
 d_H(z,\Pi_k(m))\le \rho P_k
 \Longrightarrow
 p_{i,1-m_i}(z)\le 1-\sigma_k,
 \tag{247.1}
\]

where \(\sigma_k\ge\sigma_0\).  Put

\[
 T_k:=\sum_{j=0}^{r_k-1}A_k^j,
 \qquad Q_k:=1+2T_k,
 \tag{247.2}
\]

and

\[
 \Lambda_k:=1+\log\log(k+2)+\log\log(A_k+2).
 \tag{247.3}
\]

If the tagged inline length \(N_k:=k+P_k\) satisfies

\[
 N_k\le k(\log k)^c
 \tag{247.4}
\]

for infinitely many sufficiently large \(k\), then on those lengths

\[
 Q_k\Lambda_k
 =\Omega_{\rho,\sigma_0,c}(\log k).
 \tag{247.5}
\]

All logarithms are base two; changing the base only changes the constant.  The
statement is meaningful for arbitrary \(A_k\), including growing alphabets.

### Consequences

1.  If \(A_k\le 2^{k^{o(1)}}\), then \(\log\log(A_k+2)=o(\log k)\).  A fixed
    branch depth (hence bounded \(Q_k\)) is incompatible with (247.4).
2.  For a one-query branch, \(Q_k=3\), so any near-linear family must satisfy
    \(\log\log(A_k+2)=\Omega(\log k)\), equivalently
    \(A_k\ge 2^{k^{\Omega(1)}}\) along the near-linear lengths.
3.  For fixed \(A\), (247.5) reduces to the fixed-alphabet threshold
    \(Q_k=\Omega(\log k/\log\log k)\).  Thus the theorem strictly extends the
    fixed-alphabet result rather than replacing it.

## Proof

### 1. Tagged code and its radius

The two conditions in (247.1) force the proof image to have symbol distance greater
than \(\rho P_k\): if two messages had proof words within that distance, a coordinate
where they differ would make one correct branch accept with probability one and the
same branch, viewed against the other target, be a wrong branch with probability at
most \(1-\sigma_k<1\).

The \(A_k\)-ary Singleton bound gives

\[
 k\le ((1-\rho)P_k+1)\log A_k.
 \tag{247.6}
\]

If \(\log A_k\ge k/2\), then \(\log\log(A_k+2)=\Omega(\log k)\), and (247.5) is
already true because \(Q_k\ge3\).  We may therefore assume \(\log A_k<k/2\).  From
(247.6),

\[
 P_k\ge \frac{k}{2(1-\rho)\log A_k},
 \qquad
 \frac{P_k}{N_k}\ge
 \frac{1}{1+2(1-\rho)\log A_k}.
 \tag{247.7}
\]

Use the tagged alphabet

\[
 \Gamma_k=\{(I,0),(I,1)\}\sqcup\{(P,a):a\in\Sigma_k\},
 \qquad |\Gamma_k|=A_k+2.
\]

The tagged codeword places \((I,m_i)\) in the inline coordinates and
\((P,\Pi_k(m)_j)\) in the proof coordinates.  Define

\[
 \delta_{0,k}:=
 \frac{\rho}{2\bigl(1+2(1-\rho)\log A_k\bigr)}.
 \tag{247.8}
\]

If a tagged word is \(\delta_{0,k}\)-close to the tagged codeword, stripping valid
proof tags and assigning arbitrary symbols to invalid positions produces a proof word
within \(\rho P_k\) of \(\Pi_k(m)\).  Invalid inline or proof tags simply cause the
decoder to output \(\bot\).  Thus the tagged inline decoder has a positive radius,
although that radius is allowed to shrink with \(A_k\).

### 2. Non-adaptive expansion

For a fixed random tape, each branch verifier is an \(A_k\)-ary decision tree of depth
at most \(r_k\), with at most \(T_k\) internal query nodes.  Querying the inline
coordinate and the union of the two branch trees gives a non-adaptive decoder with at
most \(Q_k\) queries over \(\Gamma_k\).  It simulates the selected branch after reading
the inline tag, and has perfect completeness and success parameter

\[
 \sigma_k\ge\sigma_0.
 \tag{247.9}
\]

This is exactly the arbitrary-alphabet non-adaptive RLDC obtained by the finite-alphabet
compiler; no assumption that \(A_k\) is constant has been used.

### 3. The radius condition in the only regime that matters

Let \(\ell_k=\log\log(k+2)\) and \(a_k=\log\log(A_k+2)\), so
\(\Lambda_k=1+\ell_k+a_k\).  We prove (247.5) by contradiction.  Suppose, for a
small constant \(\eta>0\),

\[
 Q_k\Lambda_k\le \eta\log k.
 \tag{247.10}
\]

Since \(\delta_{0,k}^{-1}\le C_\rho\log(A_k+2)\),

\[
 \log(1/\delta_{0,k})\le C'_\rho(1+a_k)
 \le C'_\rho\Lambda_k.
 \tag{247.11}
\]

On the other hand, \(N_k\ge k\) and (247.10) imply

\[
 \frac{\sigma_k\log N_k}{2Q_k}
 \ge \frac{\sigma_0\Lambda_k}{2\eta}.
 \tag{247.12}
\]

Choosing \(\eta\le \sigma_0/(4C'_\rho)\) makes the right-hand side larger than
\(\log(1/\delta_{0,k})\) for all sufficiently large \(k\).  Consequently

\[
 \delta_{0,k}>N_k^{-\sigma_k/(2Q_k)},
 \tag{247.13}
\]

which is precisely the radius hypothesis in Goldberg--Gur--Saraogi's arbitrary-
alphabet RLDC theorem.

### 4. GGS contradiction

Write \(a=\lceil Q_k/\sigma_k\rceil\) and

\[
 D_k:=38Q_k^4\sigma_k^{-2}\log^2(A_k+2)\log^2 k.
\]

Under (247.10), \(Q_k\le\log k\) and hence

\[
 \log D_k\le 7\Lambda_k+O_{\rho,\sigma_0}(1).
 \tag{247.14}
\]

The GGS theorem and (247.13) give

\[
 N_k\ge \left(\frac{k}{D_k}\right)^{1+1/a}.
 \tag{247.15}
\]

Taking logarithms and using (247.4),

\[
 \frac{\log k}{a}
 \le c\log\log k+(1+1/a)\log D_k
 \le (c+15)\Lambda_k+O(1).
 \tag{247.16}
\]

Since \(a\le 2Q_k/\sigma_0\), (247.10) gives the opposite bound

\[
 \frac{\log k}{a}
 \ge \frac{\sigma_0}{2\eta}\Lambda_k.
 \tag{247.17}
\]

Choose \(\eta<\sigma_0/[4(c+16)]\), also satisfying the radius choice above.  Equations
(247.16) and (247.17) contradict one another for all sufficiently large \(k\).  Therefore
(247.10) is impossible, proving (247.5).  \(\square\)

## Boundary and interpretation

The theorem does not claim that the threshold-scale construction exists.  It says that
the near-linear route cannot evade the fixed-alphabet closure by choosing a moderately
growing alphabet: either the branch-tree query count grows, or the alphabet reaches a
scale at which \(\log\log A_k\) itself is comparable to \(\log k\).  At that extreme scale
the tagged code's positive radius becomes so small that the present arbitrary-alphabet RLDC
bound no longer yields a contradiction; this is an explicit boundary, not an unexamined
assumption.

This is a parameterized application of the arbitrary-alphabet RLDC lower bound, not a new
coding lower-bound proof.  Its new closure value is the simultaneous accounting of the
Singleton radius loss, the branch-tree query growth, and the alphabet factor in the GGS
bound.  It turns the previously open “growing alphabet” escape into a falsifiable scale
condition for the RW/JK interface.

## Source

* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally
  Decodable Codes via Robust Daisies*, Theorem 1:
  <https://arxiv.org/html/2511.21659>.
* The fixed-alphabet specialization is
  [note 242](242-growing-query-threshold-for-near-linear-closure-2026-08-17.md).
