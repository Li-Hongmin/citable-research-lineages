> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 模式像相交的 MCSP affine-cover 下界（2026-08-13）

令真值表空间 \(V=\mathbb F_2^N\)，

\[
E_a=\{x:\operatorname{CC}(x)\le a\},\qquad
NO_b=\{y:\operatorname{CC}(y)>b\}.
\]

设 \(t\) 片 affine 叶使用线性部分 \(r_1,\ldots,r_t\) 与偏置 \(b_j\)，并定义模式映射

\[
L(x)=(r_1\cdot x+b_1,\ldots,r_t\cdot x+b_t)\in\mathbb F_2^t,
\qquad q=\operatorname{rank}\{r_j\}.
\]

若 \(L(x)=L(y)\)，则每一坐标上两值相同，故没有一片方向为
\(0\)-row/\(1\)-column 的叶能同时包含 \((x,y)\)。因此全覆盖 \(E_a\times NO_b\) 的必要条件是

\[
L(E_a)\cap L(NO_b)=\varnothing.
\tag{1}
\]

## 低复杂度行像是满商空间

若 \(a\ge Cnq\)，则 \(E_a\) 含有所有 Hamming weight 至多 \(q\) 的真值表。对任意 syndrome
\(w\in\operatorname{im}L\)，从 \(r_j\) 中取秩为 \(q\) 的列基，再取相应 \(q\) 个单位向量；其至多 \(q\)-稀疏和 \(x_w\) 满足 \(L(x_w)=w\)。故

\[
\operatorname{im}L\subseteq L(E_a).
\tag{2}
\]

反向包含显然成立，因而 \(L(E_a)=\operatorname{im}L\)。

## 高复杂度列像也是满商空间

固定 \(w\in\operatorname{im}L\)。纤维 \(L^{-1}(w)\) 是大小
\(2^{N-q}\) 的仿射子空间。若

\[
N-q>L_b,\qquad
|E_b|\le2^{L_b},
\]

则该纤维不可能全包含在 \(E_b\)，存在
\(y_w\in L^{-1}(w)\cap NO_b\)。于是

\[
\operatorname{im}L\subseteq L(NO_b).
\tag{3}
\]

结合 (2)–(3)，得到 \(L(E_a)\cap L(NO_b)=\operatorname{im}L\ne\varnothing\)，违反覆盖必要条件 (1)。

因此有严格下界

\[
\boxed{
F_\oplus(E_a\times NO_b)>
\min\!\left\{\frac{a}{Cn},\,N-L_b\right\}.
}
\tag{4}
\]

在 Frontier-B 参数 \(a=2^{n^{1/3}}, b=2^{n^{2/3}}\)（\(N=2^n\)）下，(4) 只有 \(N^{o(1)}\) 量级，不能替代 \(N^{1.01}\)；但它给出一个无需随机 thinning、直接来自 MCSP 语义的可复核 cover 下界。

