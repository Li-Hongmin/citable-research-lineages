> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# GMWZ private-slot fanout dichotomy (2026-08-18)

## Purpose

The disjoint-block statement for the GMWZ PCPP-to-RLDC compiler is exact but
deliberately narrow: it assumes that no physical proof symbol is shared by two
coordinate blocks. The natural escape is to relabel or merge slots across
coordinates. This note records the sharp counting statement for that escape.
It is a source-specific black-box theorem, not a lower bound for arbitrary
simultaneous coordinate-robust dPCPs.

## Proposition (fanout lower bound)

In the GMWZ Theorem 11.3 interface, write \(S=2K\) for the padded number of
symbols in one selected coordinate PCPP block, where

\[
K=k\log^{C'}k.
\tag{265.1}
\]

Consider a compiler that keeps the black-box local address semantics but is
allowed to share physical proof symbols across coordinates. Formally, let

\[
\phi:[k]\times[S]\longrightarrow[P]
\tag{265.2}
\]

map every logical slot \((i,j)\) to its physical proof position. Assume only
that, for each fixed \(i\), the map \(j\mapsto\phi(i,j)\) is injective; hence the
compiler has not identified two distinct addresses of the same source PCPP.
Define the cross-coordinate fanout

\[
d:=\max_{v\in[P]}\left|\phi^{-1}(v)\right|.
\tag{265.3}
\]

Then

\[
P\ \ge\ \frac{kS}{d}
   =\frac{2Kk}{d}
   =\Omega\!\left(\frac{k^2\log^{C'}k}{d}\right).
\tag{265.4}
\]

Consequently, if a proposed compiler has proof length
\(P\le k\log^c k\), then necessarily

\[
d\ \ge\ 2k\log^{C'-c}k.
\tag{265.5}
\]

When \(C'\ge c\), every physical symbol must serve \(\Omega(k)\) logical
coordinate slots. More generally, fanout \(d\le k^\theta\) forces

\[
P=\Omega\!\left(k^{2-\theta}\log^{C'}k\right).
\tag{265.6}
\]

## Proof

There are \(kS\) logical slot incidences. A physical position \(v\) can account
for at most \(d\) of them by definition of (265.3). Since every logical slot
must be represented, double counting gives \(kS\le dP\), which is (265.4).
Substituting \(S=2k\log^{C'}k\) and \(P\le k\log^c k\) gives (265.5); the
\(k^\theta\) specialization is (265.6). No soundness or coding assumption is
used beyond the stated address-preserving black-box interface. \(\square\)

## Interpretation

This yields a precise architecture dichotomy.

* If \(d=O(1)\), one recovers the disjoint private-block cost
  \(\Omega(k^2\log^{C'}k)\).
* If \(d=k^\theta\) for a fixed \(\theta<1\), the proof remains polynomially
  superlinear.
* A near-linear proof is possible only after a genuinely high-fanout synthesis:
  one physical symbol must simultaneously stand for
  \(k/\operatorname{polylog}(k)\) (and, when \(C'\ge c\), \(\Omega(k)\)) source
  slots.

Thus padding removal, permutations, and ordinary local relabelling cannot be the
missing theorem. The only remaining black-box escape is a common-address map

\[
S_{x,i,b,j}(D_x)=\Pi_x[i,b,j]
\]

whose same physical symbols serve many coordinates and whose soundness is proved
for all those uses at once. That is exactly the shared-synthesis/coordinate-robust
PCP problem, not a cheaper implementation of the private-block construction.

## Scope

The proposition does not apply when a compiler changes the source semantics, uses
message-dependent or target-dependent address maps, compresses several source
slots into a new algebraic symbol, or abandons the GMWZ black-box PCPP interface.
Those are legitimate research directions, but each is a new synthesis theorem
rather than an optimization of Theorem 11.3.

The source construction and its private blocks are described in [GMWZ,
Theorem 11.3](https://arxiv.org/html/2512.12960#S11.SS3), where the \(k\) selected
coordinate PCPP blocks are padded to a common \(K\) and concatenated.
