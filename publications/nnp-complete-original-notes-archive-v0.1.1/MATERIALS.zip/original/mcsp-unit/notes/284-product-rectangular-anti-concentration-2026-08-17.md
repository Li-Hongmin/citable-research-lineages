> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Product-rectangular anti-concentration for global-word closure

## Setup

Let \(\Gamma\) be an alphabet of size \(Q\ge2\), and let
\(\mathcal Y\subseteq\Gamma^M\) be a valid global-word family. Write
\[
 \mathcal P_j:=\pi_j(\mathcal Y),\qquad p_j:=|\mathcal P_j|.
\]
Let \(Z=(Z_1,\ldots,Z_M)\) be the product distribution in which the \(Z_j\) are
independent and each \(Z_j\) is uniform on \(\mathcal P_j\). Thus every coordinate
has a valid local explanation, but no common seed is imposed.

For \(t\ge0\), write
\[
 \mathcal Y_{\le t}:=\{z:\min_{y\in\mathcal Y}d_H(z,y)\le t\},
 \qquad
 V_Q(M,t):=\sum_{\ell=0}^{t}\binom M\ell(Q-1)^\ell .
\]

## Theorem 1 (product-rectangular anti-concentration)

For every \(t\),
\[
 \Pr[Z\in\mathcal Y_{\le t}]
 \le
 \min\left\{1,\,
 \frac{|\mathcal Y|\,V_Q(M,t)}{\prod_{j=1}^M p_j}\right\}.
 \tag{1}
\]
If the minimum distance of \(\mathcal Y\) is \(d\), then
\[
 \Pr[Z\in\mathcal Y_{\le t}]
 \le
 \min\left\{1,\,
 \frac{Q^{M-d+1}V_Q(M,t)}{\prod_j p_j}\right\}.
 \tag{2}
\]

### Proof

The support of \(Z\) is exactly
\(\operatorname{Rect}(\mathcal Y)=\prod_j\mathcal P_j\), and every supported word has
probability \((\prod_jp_j)^{-1}\). For each \(y\in\mathcal Y\), the ball
\(B_H(y,t)\) contains at most \(V_Q(M,t)\) supported words. A union bound over
\(y\) proves (1). The Singleton bound
\(|\mathcal Y|\le Q^{M-d+1}\) gives (2). \(\square\)

## Full-projection consequence

If \(p_j=Q\) for every coordinate and
\(t=\lfloor\varepsilon M\rfloor\) with
\(0\le\varepsilon<1-1/Q\), then
\[
 \Pr[Z\in\mathcal Y_{\le t}]
 \le
 Q^{\,1-M\left(\Delta-H_Q(\varepsilon)\right)+o(M)},
 \qquad \Delta=d/M.
 \tag{3}
\]
Therefore, whenever \(\Delta>H_Q(\varepsilon)\), an independently mixed
coordinatewise explanation is exponentially unlikely to be globally
\(\varepsilon\)-close to any valid word.

For binary \(\mathcal Y=\{0^M,1^M\}\), this gives
\[
 \Pr[\operatorname{dist}(Z,\mathcal Y)\le\varepsilon M]
 \le 2^{1-M(1-H_2(\varepsilon))},
\]
for independent uniform bits \(Z_j\). The local projections are perfect, yet the
global-word probability decays exponentially for every \(\varepsilon<1/2\).

## Consequence for distributional soundness

The theorem distinguishes two mechanisms that are often conflated:

- **Product/coordinate mixing:** each coordinate receives a locally valid explanation
  independently, or from unrelated Merlin responses. This is subject to (1)--(3).
- **Joint same-seed mixing:** one seed \(S\) first selects a complete word \(Y(S)\),
  and all sampled coordinates use that same word. The product argument does not apply;
  the seed supplies cross-coordinate correlation.

Hence a distributional dPCP theorem that only certifies coordinate marginals, or permits
the ideal word to change independently with the sampled coordinate, cannot yield a global
word with non-negligible probability in the full-projection/high-distance regime. To
survive the bound it must either introduce a common seed/strategy, reduce projection
entropy, lower the proof-word distance, enlarge the correction radius, or pay an
explicit correlation channel.

This is a general probabilistic coding theorem, not an impossibility statement about
DHK-style constructions with a verified same-seed coupling.
