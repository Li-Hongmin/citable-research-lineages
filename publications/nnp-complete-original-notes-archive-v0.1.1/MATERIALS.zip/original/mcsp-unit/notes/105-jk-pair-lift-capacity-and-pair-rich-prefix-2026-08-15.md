> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK pair-lift 容量障碍与 pair-rich prefix（2026-08-15）

## 结论

Ren--Williams 的 Jeřábek--Korten Theorem 3.1 在每一层把相邻两个 \(q\)-bit preimages
串接成下一层的一个 \(2q\)-bit block。这个具体结构给出一个与 decoder 语法无关的容量引理：

\[
\boxed{
\text{若一层要求覆盖 }M\text{ 个子块的全部有序 pair，且下一层仍在同一 range，}
\quad M\le 2^{q/2}.
}
\]

它可以被一个 pair-rich 的 JK 输入前缀实际触发；但该构造只保证产生一个 non-range outsider，
没有把 outsider 变成 \(P\ne NP\) 证明。

## Pair-lift capacity lemma

令

\[
G:\{0,1\}^{q}\longrightarrow\{0,1\}^{2q},
\qquad R=\operatorname{Range}(G).
\]

取 \(A\subseteq R\)，并设对每一个有序 pair \((a,b)\in A^2\)，都存在
\(u\in G^{-1}(a)\)、\(v\in G^{-1}(b)\)，使得

\[
u\Vert v\in R.
\tag{1}
\]

对每个 pair 任取一个满足式 (1) 的 concatenation。不同的 ordered pairs 不可能给出同一个
\(2q\)-bit string：若 \(u\Vert v=u'\Vert v'\)，前后 \(q\) bits 分别相同，因而

\[
a=G(u)=G(u'),\qquad b=G(v)=G(v').
\]

所以

\[
|A|^2\le |R|\le 2^q,
\qquad |A|\le 2^{q/2}.
\tag{2}
\]

该证明允许每个 pair 自适应选择任意 preimage；不依赖 lex-first、唯一译码或 sparse syntax。

更一般地，若 \(P\subseteq A^2\) 是实际出现的 ordered-pair 集，并且每个
\((a,b)\in P\) 都能选出式 (1) 的 parent block，则

\[
|P|\le |R|\le 2^q.
\tag{3}
\]

这就是 history-specific 判据：实际某一层若出现多于 \(2^q\) 个不同的 child pairs，下一层
必有一个 non-image block，与 preimage selector 的选择无关。

## 与 JK Theorem 3.1 的精确对齐

在该定理的 stage \(i\)，当前字符串 \(y_i\) 被切成 \(2q\)-bit blocks

\[
z_1,\ldots,z_{2^{i-1}}.
\]

若所有 \(z_j\in R\)，算法选取满足 \(G(x_j)=z_j\) 的 \(q\)-bit witnesses，并令

\[
y_{i-1}=x_1\Vert x_2\Vert\cdots\Vert x_{2^{i-1}}.
\]

于是下一 stage 的 blocks 恰为

\[
x_1\Vert x_2,\ x_3\Vert x_4,\ \ldots .
\tag{4}
\]

若式 (4) 中出现的 distinct ordered pairs 数超过 \(2^q\)，由式 (3) 至少有一个下一层
block 不在 \(R\)，JK 直接返回 hard outsider。注意这里的 pair 是实际 history 中的 pair；
不能把任意 decoder 的 range coverage 自动替换成“实际 history 包含所有 pair”。

## Pair-rich prefix 构造

设 \(A=\{a_1,\ldots,a_M\}\subseteq R\)，且 \(M^2>2^q\)。选取一个 JK 顶层，使其有至少
\(2M^2\) 个 \(2q\)-bit blocks。对每个 \(1\le r,s\le M\)，连续放置两个顶层 blocks
\(z_{2\ell-1}=a_r,z_{2\ell}=a_s\)，并让 \(\ell\) 依次遍历全部 \(M^2\) 个 ordered pairs。
于是前 \(2M^2\) 个顶层 blocks 的序列可记为

\[
\bigl(a_r,a_s\bigr)_{1\le r,s\le M}
\tag{5}
\]

的任意枚举，即每个 ordered pair \(A^2\) 恰出现一次；剩余 blocks 可填为任意已知的 range
element，例如零表。顶层所有 blocks 都在 \(R\)，所以 JK 必须先选择各自 preimages。
由于不同 \(a\in A\) 的任何 selected preimages 也不同，式 (4) 的前 \(M^2\) 个 parent
blocks 两两不同。若它们全部在 \(R\)，则式 (3) 要求 \(M^2\le2^q\)，矛盾；故第二层必
出现 non-image。

该前缀可以嵌入一个任意长的 \(f\) 中。若希望同时要求 \(f\) 具有高 circuit complexity，
固定前缀后对剩余 suffix 做计数：长度为 \(T\) 的 fan-in-two circuit 总数至多

\[
2^{O(S\log(T+S))}
\]

（这里 \(S\) 是 gate bound）。只要 suffix 长度大于该描述数的指数，便存在延伸该前缀且
复杂度超过 \(S\) 的 \(f\)。这是存在性延伸，不是一个 uniform hard-language construction。

## 覆盖低复杂度表时的临界窗口

令 \(N=2^m=2q\)，并令 \(\mathcal C_{m,s}\) 是 size-\(\le s\) 的 \(m\)-variable truth tables。
若

\[
s\ge L(m-2),
\]

其中 \(L(r)\) 是所有 \(r\)-variable functions 的最大 circuit complexity，则
\(\mathcal C_{m,s}\) 至少包含：

1. 所有只依赖前 \(m-2\) 个 variables 的函数，数量为 \(2^{2^{m-2}}=2^{q/2}\)；
2. 一个不依赖该变量集合的 outsider，例如 projection \(x_{m-1}\)。

因此可取 \(A\subseteq\mathcal C_{m,s}\) 满足

\[
|A|=2^{q/2}+1>2^{q/2}.
\]

任何覆盖 \(\mathcal C_{m,s}\) 的 \(q\)-bit decoder 都覆盖 \(A\)，所以 pair-rich prefix 会在
第二 JK stage 强制出现 non-image。Jukna 的 Lupanov bound 给出

\[
L(m-2)\le(1+o(1))\frac{2^{m-2}}{m-2}
= (1+o(1))\frac{q}{2(m-2)}.
\tag{6}
\]

这把“覆盖 + 对所有覆盖块保持 universal one-lift closure”的排除窗口推进到大约
\(q/(2\log q)\) 的 leading scale；它仍不排除更稀疏的
\(q/\log^{1+\varepsilon}q\) 窗口，也不说明实际 RW history 已经 pair-rich。

## P vs NP 边界

本 note 严格证明的是：

\[
\text{large low-circuit coverage}
\land
\text{universal JK one-lift closure}
\quad\Longrightarrow\quad
\text{矛盾}.
\]

JK 本身只需要一条由给定 \(f\) 产生的 concrete history；若该 history 的 pair 集很小，容量
引理不会触发。Pair-rich prefix 可人为构造一条 history，但其 hard suffix 只有非均匀存在性，
未给出固定的 NP 语言或 \(P\ne NP\) 分离。因此当前真正的缺口仍是：

\[
\text{把 history-specific outsider 变成固定、uniform、复杂度可控的 hardness witness。}
\]

### 来源与证据边界

- Ren--Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with Merlin--Arthur
  Queries*, ECCC TR26-118 revision 1，Theorem 3.1：核验了 stage blocks、witness concatenation
  与下一层分块；本 note 的式 (2)--(6) 是项目内推导。
- Lupanov 上界：ResearchLibrary 中 Jukna (2012) Theorem 1.15。

不把 pair-rich prefix 的非均匀 hard-suffix 存在性写成 uniform \(P\ne NP\) 结果。
