> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# NC⁰ Hamming-slice 采样下界不等于 decoder range 下界（2026-08-15）

## 结论

Kane–Ostuni–Wu（KOW）的 locality 下界可以关闭一个**加强后的采样路线**，但不能关闭本项目的原始 coverage 命题：

\[
\operatorname{Slice}_{N,p}\subseteq \operatorname{Range}(G_q)
\quad\not\Rightarrow\quad
G_q(U_q)\approx \operatorname{Unif}(\operatorname{Slice}_{N,p}).
\tag{1}
\]

所以“低 locality 不能采样 Hamming slice”不能直接推出“低 locality decoder 不能覆盖全部 slice”，更不能推出一般 near-linear decoder 的 range 下界。

## 文献支持的采样下界

KOW 将 \(d\)-local function 定义为每个输出位至多依赖 \(d\) 个输入位；常数 \(d\) 包含 NC⁰。令

\[
D_{N,p}=\operatorname{Unif}\{y\in\{0,1\}^N:|y|=p\}.
\]

其 Theorem 1.2（由 Theorem 5.10 推出）说明：当 \(d\) 与 \(p/N\) 都是常数时，任意

\[
F:\{0,1\}^a\to\{0,1\}^N
\]

的 \(d\)-local map 都满足

\[
\operatorname{TV}\bigl(F(U_a),D_{N,p}\bigr)
\ge 1-O(N^{-1/2}).
\tag{2}
\]

对非 dyadic 比例，Theorem 5.7 给出更强的指数型远离界；Theorem 1.1 还覆盖了随 \(N\) 缓慢增长的 locality 与更宽的 \(p/N\) 区间。这里的结论对象始终是**输出分布**，不是 range。

原始来源：Kane–Ostuni–Wu, [ECCC TR24-031](https://eccc.weizmann.ac.il/report/2024/031/download)，STOC 2024 版本；本地全文在
`ResearchLibrary/lib/danielmkane2024locality/`。

## 为什么不能转成 coverage 下界

Coverage 只说每个 slice 点至少有一个 seed。即便 \(q\ge\lceil\log_2|D_{N,p}|\rceil\)，也可以把一个 seed 映到每个 slice 点，再把其余几乎所有 seeds 都映到固定点 \(y_0\)。所得 map 仍满足

\[
D_{N,p}\subseteq\operatorname{Range}(G_q),
\]

但 \(G_q(U_q)\) 可以与均匀 slice 的总变差距离接近 \(1\)。因此 KOW 的前提不能由 range coverage 推出。

本项目的稀疏-list decoder 还存在两个额外失配：其 sorting network 的输出 locality 不是常数；并且 uniform seed 产生的输出按 slot/address 碰撞数加权，既未证明是 slice-uniform，也未证明接近 slice-uniform。故 KOW 不能给出其 \(O(q\operatorname{polylog}q)\) circuit 的反证。

## 与 Range Avoidance 的相邻边界

Huang–Li–Zhong 的 ITCS 2026 结果将某些受限类（包括 NC⁰/AC⁰）的 Avoid 算法与 \(\mathrm E^{\mathrm{NP}}\) 电路下界联系起来，并给出 NC⁰-Avoid 的算法与时间界；见 [ITCS 2026 论文页](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.ITCS.2026.79)。这研究的是“给定受限电路找一个 range outsider”，不是“覆盖某个 truth-table family 的 decoder 是否存在”。

因此目前可晋级的路线裁决是：

\[
\boxed{
\text{NC}^0/\text{低 locality}+\text{近均匀 slice sampling：可由 KOW 关闭；}
\quad
\text{仅 coverage 的一般 }G_q\text{：仍 unknown。}
}
\]

这也保留了一个精确的加强版问题：若未来候选 decoder 同时满足局部性和对目标 slice 的近均匀输出分布，则可直接调用 KOW，而无需先证明一般 range lower bound。
