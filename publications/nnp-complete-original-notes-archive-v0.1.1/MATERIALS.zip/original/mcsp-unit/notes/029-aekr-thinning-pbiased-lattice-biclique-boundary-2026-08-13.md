> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 完整 thinning 的 p-biased／格 EKR 文献边界（2026-08-13）

## 决策问题

检查是否存在原始定理可直接证明完整 AEKR：对随机 affine-parity 叶再独立以 1/2 保留行、列后，成对相交 collision 见证族的命中概率是否总满足
Pr[存在 T⊆R] ≤ 1/16。

## 检索边界

- 日期：2026-08-13（亚洲东京时区）。
- 查询簇：p-biased intersecting/cross-intersecting families；random subset inclusion probabilities；direct-product and Boolean-lattice EKR；H-intersecting graph families under product measure；bipartite matching/biclique EKR。
- 来源：arXiv 全文、开放期刊／作者 PDF、DOI 元数据、OpenAlex；精确决策检索，非穷尽书目审计。

## 最接近结果与参数失配

1. Chang–Liu–Liu（arXiv:2606.15618）证明：若 F₁,…,Fᵣ 是 r-cross-intersecting 子集族且 p≤(r−1)/r，则 ∏ μp(Fᵢ)≤pᵣ。形式上 r=4、p=1/2 给 1/16，但 AEKR 只有一个由 affine-parity 叶和 U×V 诱导的相关矩形族，约束是见证 T 两两共享 cell，不是从四个独立族各选一集后有共同 cell；不存在可用编码。
   最新同作者预印本 Chang–Liu–Liu（arXiv:2607.21589，2026-07-23）进一步在不等偏置下证明 ∏μ_{p_i}(F_i)≤∏p_i（各 p_i≤(r−1)/r），但假设仍是 r 个独立子集族的逐次共同点交，故同样不能编码 AEKR。
2. Wu–Li–Liu–Feng（arXiv:2510.26642）证明 cross-t p-biased product ≤(p₁p₂)ᵗ，但主乘积界需 pᵢ<1/(t+1)。取 t=2 只能覆盖 p<1/3，排除 AEKR 的 p=1/2 行列 thinning；其对象仍是独立坐标子集。
3. Fishburn–Frankl–Freed–Lagarias–Odlyzko（1986，DOI 10.1137/0607009）及 Friedgut（2008，DOI 10.1007/s00493-008-2318-9）给随机独立子集的 p-biased EKR／稳定性；普通相交族在 p=1/2 只有 1/2 星界，且不处理相关 biclique 采样。
4. Ellis–Filmus–Friedgut（JEMS 2012，DOI 10.4171/JEMS/320）给 G(n,p) 中 pairwise edge intersection 含固定 triangle／odd cycle 的图族界；AEKR 矩形是 bipartite、只共享任意 cell，且 U×V 采样不是独立边 G(n,p)。
5. Ahlswede–Aydinian–Khachatrian（1998，DOI 10.1006/eujc.1998.0223）和 Wang–Zhang（EJC 2011，#P237）处理 direct-product 的固定 rank／rank-slice lattice EKR；Filmus（JCTA 2017，DOI 10.1016/j.jcta.2017.04.008）处理单 Boolean 格的 weighted complete intersection。AEKR 遍历所有 rank、还耦合随机 affine 叶参数，不能把 cardinality 或独立 p-weight 直接转为 1/16。
6. Mammoliti（AJC 2025，arXiv:1811.07481）处理 complete k-partite k-graph 的固定-size vertex-disjoint matchings。AEKR 的 T 可共享行或列，且随机对象是 induced biclique U×V，不是 matching。

7. 覆盖数分支的精确小参数结果：Frankl–Ota–Tokushige（JCTA 74, 1996，开放作者 PDF `https://www.renyi.hu/~pfrankl/j79.pdf`）在 Appendix §4.2 明确证明 `r(3)=10`：严格 3-uniform、pairwise-intersecting 且 `τ=3` 的族至多 10 条，并列出 7 个极值构型。该结论要求固定 uniformity=3 和覆盖数恰为 3；AEKR 的见证 T 允许变大小并由仿射叶/行列参数耦合产生，不能直接套用。

## 结论

没有发现可直接推出完整 thinning AEKR ≤1/16 的外部定理。最强的数值近邻是 Chang–Liu–Liu 的 r-cross p-biased 乘积界，但其共同交／独立族假设与 AEKR 的相关 affine-biclique 事件不相容；不能把形式上的 r=4、p=1/2 代入。完整 thinning 仍需独立处理 affine 参数 z、行列保留和 collision 结构，或给出反例；本检索到此停止。

## 2026-08-14：SDP 与 r-cross 接口的精确失配

Suda--Tanaka--Tokushige，*A semidefinite programming approach to a
cross-intersection problem with measures*，Math. Programming 166 (2017),
113--130，arXiv:1504.00135，DOI 10.1007/s10107-016-1106-3，其 Theorem 2 的确给
独立 Boolean-cube product measures 下的 cross-intersecting 两族乘积界；其 Theorem 4
也允许在给定二部图上写一般 cross-independent SDP。

但固定一个 affine 叶后，AEKR 的随机 cell 集是 \(W=U\times V\)，不是 cell 上的
product measure。两个同一 row、不同 column 的叶内 cells 满足

\[
\Pr[c,c'\in W]=\frac12\left(\frac12\right)^2=\frac18,
\]

而若把每个 cell 的边缘 \(1/4\) 误当独立 \(p=1/4\)，该联合质量会是 \(1/16\)。
故不能把 Suda--Tanaka--Tokushige 的 product-measure theorem 直接代入。把端点编码为
\(U\sqcup V\) 虽恢复 \(p=1/2\) 的独立性，却只得到普通 intersecting-upset 的
\(1/2\) 界，丢失矩形的第二个补集因子。对固定 \(z\) 自定义“矩形 cell-disjoint”图可
由其一般 SDP 框架重述四轨道 \(\mu_z\le1/4\)，但图随 \(z\) 变化，且没有跨参数的
\(1/4\) certificate。

Chang--Liu--Liu 的 \(r=4\) 结论要求任何四个 cross-choice 有**共同** ground element。
AEKR 仅有 pairwise cell intersection。note [058](058-binary-circuit-literature-and-fano-obstruction-2026-08-13.md)
的 Fano 实现中

\[
\begin{aligned}
T_1&=\{(0,4),(0,5),(0,7)\},\\
T_2&=\{(0,1),(0,4),(0,3)\},\\
T_3&=\{(0,1),(0,5),(0,2)\},
\end{aligned}
\]

相对于 \(s=(6,8)\) 都是 inclusion-minimal odd--odd witnesses，且两两相交而
\(T_1\cap T_2\cap T_3=\varnothing\)。取 \((T_1,T_2,T_3,T_1)\) 已违反
四重共同交的量词。因而这两个文献接口只能提供固定叶的定制 SDP 语言，不能严格导出完整
\(1/16\) 界。

## 缓存

ResearchLibrary 项目：[unbundled local reference] 20 条全文批处理报告 `fulltext-retrieval.csv` 统计：existing-library=13、downloaded=2、download-failed=2、no-open-pdf=3、error=0、total=20；新增可读 PDF 包括 FOT 1996 覆盖数论文与 Chang–Liu–Liu 2026-07-23 不等偏置更新。`admitted-records-2026-08-13.json` 与 `literature-matrix.csv` 均已更新为 20 条记录，且下载记录带本地路径、大小和 SHA-256。
