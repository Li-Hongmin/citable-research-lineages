> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 三元极小 witness 的完整 thinning 闭合（2026-08-13）

## 命题

固定 spoiler (s)。设 (mathcal F_3) 是所有关于 (s) 的极小三元 collision witness 组成的两两相交族：

\[
|T|=3,qquad L(T)\ne\varnothing,qquad L(T\cup\{s\})=\varnothing,
\]

且删去 (T) 的任一点后即与 (s) 相容。对随机
\(z=(r,t)\in\mathbb F_2^{N+1}\)，先取合法 affine-parity 叶，再独立以概率 (1/2) 保留行列。则

\[
\boxed{
\Pr_{z,U,V}[\exists T\in\mathcal F_3:T\subseteq R_z(U,V)]
\le {1\over16}.}
\tag{A}
\]

等价地，若 \(\mu_z\) 是固定 \(z\) 后的 thinning 命中概率，则

\[
\sum_{z\in\mathbb F_2^{N+1}}\mu_z\le 2^{N-3}.
\tag{B}
\]

## 1. 单个三元 witness 的质量

令 \(p(T)\) 与 \(q(T)\) 为 \(T\) 使用的不同 row、column 数。极小 witness 的秩增一引理（见 note 032）给出

\[
\operatorname{rank}A_T\ge |T|+1=4.
\]

因此

\[
\Pr[T\subseteq R_z(U,V)]
\le 2^{-4-p(T)-q(T)}.
\tag{1}
\]

三条不同 cell 至少使用两行一列或一行两列，故 \(p(T)+q(T)\ge4\)。所以

\[
\Pr[T\subseteq R_z(U,V)]\le 2^{-8}=1/256.
\tag{2}
\]

同理，任意固定 pair \(P\) 的质量满足

\[
\Pr[P\subseteq R_z(U,V)]\le 2^{-6}=1/64,
\tag{3}
\]

而固定 cell 的质量为 \(1/16)。以下只使用 (2)、(3)。

## 2. 覆盖数 \(\tau(\mathcal F_3)=1\)

若所有 witness 共有 cell \(c\)，则命中事件包含于 \(\{c\in R_z(U,V)\}\)，故概率至多 \(1/16\)。

## 3. 覆盖数 \(\tau(\mathcal F_3)=2\)

取 cover \(\{a,b\}\)。分解

\[
\mathcal F_{ab}=\{T:\{a,b\}\subseteq T\},\quad
\mathcal F_a=\{T:a\in T,b\notin T\},\quad
\mathcal F_b=\{T:b\in T,a\notin T\}.
\]

令

\[
A=\{T\setminus\{a\}:T\in\mathcal F_a\},\qquad
B=\{T\setminus\{b\}:T\in\mathcal F_b\}.
\]

由于原 witness 两两相交，\(A,B\) 是 cross-intersecting 的 2-uniform 族：
\[
e\cap f\ne\varnothing\qquad(e\in A,f\in B).
\tag{4}
\]
\(\tau=2\) 保证 \(A,B\ne\varnothing\)。此外

\[
\Pr[\exists T\in\mathcal F_{ab}:T\subseteq R]\le
\Pr[\{a,b\}\subseteq R]\le1/64=4/256.
\tag{5}
\]

### 3a. \(A\) 有公共点

若 \(A=\{\{u,x\}\}\) 是 singleton，则由 (4)
\(B\subseteq\operatorname{star}(u)\cup\operatorname{star}(x)\)。故

\[
\Pr[E_A]\le1/256,qquad
\Pr[E_B]\le 2/64=8/256.
\]

若 \(|A|\ge2\)，取 \(\{u,x\},\{u,y\}\in A\)，\(x\ne y\)。任意 \(f\in B\) 要么含 \(u\)，要么必须等于 \(\{x,y\}\)。于是

\[
\Pr[E_A]\le1/64=4/256,qquad
\Pr[E_B]\le1/64+1/256=5/256.
\]

两种情形与 (5) 合计均不超过

\[
(1+8+4)/256=(4+5+4)/256=13/256<1/16.
\tag{6}
\]

### 3b. \(A\) 无公共点且含不交 pair

取不交 \(e_1=\{u,v\},e_2=\{w,x\}\in A\)。由 (4)，\(B\) 的每条边必须从 \(\{u,v\}\) 与 \(\{w,x\}\) 各取一点，故 \(|B|\le4\)，从而

\[
\Pr[E_B]\le4/256.
\tag{7}
\]

取任意 \(f_0=\{p,q\}\in B\)。再次由 (4)，\(A\subseteq\operatorname{star}(p)\cup\operatorname{star}(q)\)，故

\[
\Pr[E_A]\le 2/64=8/256.
\tag{8}
\]

与 (5) 合计为 \(16/256=1/16\)。

### 3c. \(A\) 无公共点且无不交 pair

一个无公共点且两两相交的 2-uniform 族必恰为三角形的子族；无公共点迫使它包含三条边。设三角形顶点为 \(u,v,w\)。任意 \(f\in B\) 必须同时与 \(\{u,v\},\{u,w\},\{v,w\}\) 相交，故 \(f\) 本身是这三条边之一。因此

\[
\Pr[E_A],\Pr[E_B]\le3/256,
\]

再加 (5) 得 \(10/256<1/16\)。这完成 \(\tau=2\) 分支。

## 4. 覆盖数 \(\tau(\mathcal F_3)=3\)

对任意 3-uniform intersecting family，任一成员本身是 3-cover，故 \(\tau\le3\)。经典 Erdős--Lovász 精确结果为

\[
f(n,3,3):=\max\{|\mathcal F|:\mathcal F\subseteq\binom{[n]}3,
\mathcal F\text{ intersecting},\ \tau(\mathcal F)\ge3\}=10.
\tag{9}
\]

见 Erdős--Lovász, *Problems and results on 3-chromatic hypergraphs and some related questions*, 1975；该精确值亦由 Frankl--Wang（arXiv:2207.05487v4, §1，定义 \(f(n,k,s)\) 后紧接着明确写出 \(f(n,3,3)=10\)）重述。这里的 \(n\) 是 cell 的实际底集大小；若 \(n<6\)，结论也由 \(\binom n3\le10\) 直接成立。因这里 \(\tau=3\)，有 \(|\mathcal F_3|\le10\)。结合 (2)：

\[
\Pr[\exists T\in\mathcal F_3:T\subseteq R]
\le10/256<1/16.
\tag{10}
\]

综上得到 (A)，再乘以参数总数 \(2^{N+1}\) 即得 (B)。

## 5. 边界

该结论只关闭“所有极小 witness 均为三元”的分支。一般族仍可能同时含有 \(|T|\ge4\) 的极小 witness；此时 (9) 不适用，需新的高阶 intersecting-family 质量定理。
