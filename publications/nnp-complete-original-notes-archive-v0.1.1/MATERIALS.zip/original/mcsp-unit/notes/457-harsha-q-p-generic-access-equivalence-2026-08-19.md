> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha \(q\)--\(p(q)\) generic random access 的多项式等价（2026-08-19）

## 本轮改变的判断

C454 将 factorized Harsha branch 的剩余接口写成 auxiliary
\(P=p(q)\) 的 generic-point evaluator。Harsha Proposition 5.4.1 的定义式同时给出
反向归约：一旦能在 generic points 访问 assignment polynomial \(q\)，评价 \(P\)
只需要三个 \(q\)-values 和一个 \(\widehat D\)-value。结合 C439 已证明的
\(P\to q\) 反演，在 C453--C454 的非退化 serialization 下，
\[
  q\text{-access}\equiv_{\operatorname{poly}(m,|F|)}P\text{-access}.
\]
因此 \(P\)-segment 不是独立的 algebraic random-access 难题；真正未决的是实际 proof
serialization 是否提供 generic \(q\)-access。显式写出 \(P\) 的全表不能替代这一接口。

## 定理 457.1（forward evaluator）

令 \(q:F^m\to F\)，令
\(\widehat D:F^{3m+3}\to F\)，并按 Harsha 式 (5.7) 定义
\[
\begin{aligned}
P_q(u,v,w,y_1,y_2,y_3)
&=
\widehat D(u,v,w,y_1,y_2,y_3)\\
&\qquad\cdot(q(u)-y_1)(q(v)-y_2)(q(w)-y_3).
\end{aligned}
\tag{457.1}
\]
若 \(q\) 与 \(\widehat D\) 的 generic-point evaluators 大小分别为 \(s_q,s_D\)，则
\(P_q\) 有大小
\[
  s_P\le 3s_q+s_D+\operatorname{poly}(m,\log|F|)
\tag{457.2}
\]
的 evaluator。每次评价至多调用三个 \(q\)-values 和一个 \(\widehat D\)-value；若
\(u,v,w\) 重复，只需调用不同坐标。

### 证明

输入 \(x=(u,v,w,y_1,y_2,y_3)\) 后，分别评价
\[
q(u),\quad q(v),\quad q(w),\quad \widehat D(x),
\]
再执行三次减法与三次乘法，即由 (457.1) 得到 \(P_q(x)\)。没有和式、全表扫描、
canonical quotient 选择或额外 advice。电路化域运算给出 (457.2)。证毕。

## 定理 457.2（bidirectional access equivalence）

再假设 \(\widehat D\) 本身有大小 \(s_D\) 的 generic-point evaluator，并且有
C454 的 address-scale incidence map：对每个 target coordinate \(u\)，可生成
\((v_u,w_u)\)，使
\[
  (Y_1,Y_2,Y_3)\longmapsto
  \widehat D(u,v_u,w_u,Y_1,Y_2,Y_3)
\]
不是零多项式；并假设 C439 的 field-size 条件。则
\[
\begin{aligned}
s_P
&\le 3s_q+s_D+\operatorname{poly}(m,\log|F|),\\
s_q
&\le O(|F|^3)(s_P+s_D)
   +\operatorname{poly}(m,|F|).
\end{aligned}
\tag{457.3}
\]
因此在 \(|F|=\operatorname{poly}(m)\) 且 \(s_D=m^{O(1)}\) 的 Harsha 参数窗口下，
\[
  s_P=m^{O(1)}
  \quad\Longleftrightarrow\quad
  s_q=m^{O(1)}.
\tag{457.4}
\]

### 证明

第一式是定理 457.1。第二式正是 C439 的 auxiliary-to-systematic inversion：
枚举 \(a,b,y\in F\)，在非零 slice 上找到合法 denominator，比较两个不同的 \(y\)
即可恢复 \(q(u)\)；总共使用 \(O(|F|^3)\) 次 \(P_q,\widehat D\) 评价以及
\(\operatorname{poly}(m,|F|)\) 的地址与域运算。证毕。

## 对 published RW Closure 的后果

C456 已把 C453--C454 systematic coordinates 与 C455 的同一个 published hard output
对齐：
\[
  q(u_j)=B_n[j].
\tag{457.5}
\]
故在 good lengths 上，一个 \(\operatorname{poly}(m)\) generic \(q\)-evaluator 会直接
给出 \(B_n\) 的 address circuit；一个 \(\operatorname{poly}(m)\) \(P_q\)-evaluator
则经 (457.3) 得到同样结论。两者都与
\[
  \operatorname{CC}(B_n)=\Omega(N_n/\log N_n)
\]
冲突。剩余事实不是“Harsha proof 中没有 \(P_q\)”：honest proof 包含其显式 oracle
table。缺的是把 \(q\) 或 \(P_q\) 的 object-scale table 编译成
\(\operatorname{poly}(\log N_n)\) 的 generic-point evaluator。

## 证据边界

* forward direction 假设 generic \(F^m\)-point \(q\)-access；只在 \(H^m\) 上暴露
  systematic symbols 或只暴露其 ECC image 不满足该假设。C458 进一步证明完整
  individual-degree 空间中的精确 black-box 转换在全 generic point 需要整个 \(H^m\) grid。
* equivalence 使用 address-scale \(\widehat D\)-evaluator、C454 的非退化 incidence 与 C439
  的 field-size 条件；没有这些接口，\(P\to q\) 不自动成立。
* 该结果关闭的是问题定位，不构造 generic \(q\)-access，不证明 \(P\ne NP\)。

## 来源

* Harsha, *Robust PCPs of Proximity and Shorter PCPs*, Proposition 5.4.1，式 (5.7)。
* [C439 auxiliary-to-systematic inversion](439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md)。
* [C454 source-compatible incidence](454-rw-source-compatible-incidence-auxiliary-barrier-2026-08-19.md)。
* [C456 published-output source alignment](456-published-rw-output-source-alignment-and-direct-scale-boundary-2026-08-19.md)。
