> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Binary projection Sim-CR 的 2-query 指数长度障碍（2026-08-16）

## 结论地位

这是一个一般性但有明确结构范围的 coordinate-robust impossibility theorem。它把
**binary proof alphabet + projection local decoding + 2 queries + target-relative
near-oracle soundness** 直接归约到 Hamming RLDC；调用最新的 2-query RLDC 指数下界后，
排除近线性 proof。它不声称排除非二元 alphabet、非 projection verifier 或更高查询数，
这些正是后续正向构造必须明确承担的逃逸。

## Projection Sim-CR 模型

令

```text
C : {0,1}^k -> {0,1}^N
```

为所选 honest proof map。对每个消息 `m`，写 `C(m)=Pi_m`。给定坐标 `i`，一个
projection verifier 随机选择至多两个 proof positions，读取相应二元符号，检查局部
约束 `V_i`，并由同一局部视图的 decoder `D_i` 输出 `0`、`1` 或 `bottom`。假设：

1. **完美完备性：** 对所有 `m,i`，在 `Pi_m` 上局部约束总接受且
   `D_i(Pi_m)=m_i`；
2. **目标相对坐标 soundness：** 存在 `rho>0`、`beta<1/2`，使对所有 `m`、
   所有满足 `dist(z,Pi_m)<=rho` 的 `z` 和所有 `i`，

```text
Pr[ V_i(z) accepts AND D_i(z) != m_i ] <= beta.
```

这里 decoder 可以自适应选择第二个位置；查询总数仍至多 2。该模型把“错误声明”写成
projection decoder 的错误输出，避免另跑两个 claim-specific verifiers。

## 定理：Projection Sim-CR(2) 给出 weak 2-query RLDC

在上述假设下，`C` 是一个 binary weak adaptive `(2,rho,1-beta)`-RLDC，且其 codeword
distance 严格大于 `rho`。

### 证明

定义 RLDC decoder `Dec(z,i)`：运行 projection verifier 的局部查询；若局部约束失败则
输出 `bottom`，否则输出 `D_i` 的值。

在合法 codeword `Pi_m` 上，完美完备性给出 `Dec(Pi_m,i)=m_i`，所以 RLDC 完美完备。
若 `dist(z,Pi_m)<=rho`，只有事件

```text
V_i(z) accepts AND D_i(z) != m_i
```

会导致错误输出，其概率至多 `beta`；因此

```text
Pr[Dec(z,i) in {m_i,bottom}] >= 1-beta > 1/2.
```

最后证明距离。若存在 `m != m'` 且 `dist(Pi_m,Pi_{m'})<=rho`，取坐标 `i` 使
`m_i != m'_i`。以 `m` 为目标、`z=Pi_{m'}` 代入 soundness：因为 `Pi_{m'}` 自身满足
局部约束且 decoder 输出 `m'_i != m_i`，错误事件概率为 1，与 `beta<1` 矛盾。因此
不同 codewords 距离严格大于 `rho`，目标在半径 `rho` 内唯一，RLDC 定义成立。

## 指数下界推论

Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu（arXiv:2602.20278，版本 2，
2026-02-28）的 Theorem 1 证明：任何 binary weak adaptive
`(2,delta,1/2+epsilon)`-RLDC 都满足

```text
N >= 2^{Omega_{delta,epsilon}(k)}.
```

取 `delta=rho`、`epsilon=(1/2-beta)`，上面的 Projection Sim-CR(2) 于是满足

```text
N >= 2^{Omega_{rho,beta}(k)}.
```

因此，任何 binary、projection、2-query、完美完备且具有常数目标相对鲁棒性的
Sim-CR family 都不可能有近线性 proof。

## 这条障碍真正关闭什么

它不是一般 Sim-CR 不可能性；它精确关闭一个最自然的 dPCP 架构：把同一 binary proof
同时当作 codeword，由 projection decoder 直接输出指定 message bit。对于该架构，
“把 average/list soundness 升级成 fixed-coordinate robustness”不只是会触发普通
RLDC 的超线性界，在 2 queries 下甚至触发指数界。

## 逃逸边界

1. **非二元 alphabet：** 上述指数下界的论文明确只处理 binary Hamming RLDC，并指出
   对更大 alphabet 的同一证明仍是开放问题；当前只能回退到一般 relaxed-LDC 的
   polynomial 超线性下界。
2. **非 projection / claim-specific verifier：** 若两个声明使用不同查询位置，或
   decoder 不能从一次局部视图直接输出一个 bit，则不能把它压成 2-query RLDC；这正是
   C55/C56 的 finite-response 与 shared-key 账本所覆盖的剩余模型。
3. **不完美完备性：** 指数下界依赖 perfect completeness；仅有常数完备率时，不能
   直接调用该定理。
4. **更高查询数：** 对 `q>=3`，该文给出的指数结论不适用；需使用 DGL/RLDC 的
   polynomial 超线性下界或新的技术。

所以当前双向研究分叉变得精确：要构造近线性 simultaneous coordinate-robust dPCP，
必须至少使用非二元 alphabet、非 projection 的全局机制、更多查询，或证明一个超越
现有 RLDC 下界的新编码结构；否则 binary projection 2-query 路线已被指数障碍关闭。

## 来源与证据边界

* [Block et al., Exponential Lower Bounds for 2-query RLDCs](https://arxiv.org/html/2602.20278)，
  Theorem 1 与其 binary/perfect-completeness 适用范围；
* [Gur--Minzer--Weissenberg--Zheng](https://arxiv.org/html/2512.12960)，2-query dPCP
  的 projection/decoding 背景与 3-query RLDC/PCPP 参数；
* [Key-indexed ACRR/RLDC dichotomy](../../rw-jk-succinct-reconstruction/statements/key-indexed-acrr-rldc-dichotomy.md)，
  非二元或 claim-specific 逃逸的 family-level barrier。

本文的归约和距离证明是直接推导；指数数量级完全归因于 Block et al. 的外部定理，
不把它冒称为本项目独立证明。
