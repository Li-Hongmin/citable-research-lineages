> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Non-product global coupling 的有限视图—有界状态闭合范式（2026-08-19）

## 本轮改变的判断

C505 关闭了 Harsha 的 factorized \(P=p(q)\) 段，但仍留下一个容易被过度泛化的
“新 global relation”名称。C449 与 C466 实际覆盖了两种不同量词：

* 在有共同 proof 的 source family 上，有限可见 global state 会编译成 RLDC；
* 在固定 singleton 上，若 global state 由显式 bounded transition/RAM 实现，则可
  直接展开成普通电路。

本 note 将二者合成一个 normal-form theorem。它不声称所有可能的 global relation
都落入其中；它证明的是：任何声称同时保持 address-scale、common-proof、标准
fan-in-2 计价和原 all-policy soundness 的方案，必须先说明自己为何不属于这两个
可计价模型之一。否则“non-product”只是改名，不是新的 Closure 机制。

## 两种资源账本

### Family-visible-view 模式

令
\[
\Pi:\{0,1\}^{k}\to\Sigma^P,\qquad |\Sigma|=A\ge2,
\]
是 common proof map，且不同 message 的 proof 距离大于 \(2\rho P\)。每个
coordinate/claim verifier：

* 使用至多 \(r\) 个 public random bits；
* 查询至多 \(q\) 个 common-proof symbols；
* 在固定 public tape 和 proof-answer transcript 后，可见 global-state transcript
  的总数至多 \(B\)；
* 在 honest proof 上对正确 claim 完美接受，对半径 \(\rho P\) 内的错误 claim
  对所有 policies 的接受率至多 \(\beta<1\)。

这里的 global state 可以是任意 non-product 函数；\(B\) 只计数 verifier 实际可见的
state transcripts，不要求其按坐标分解。

### Singleton bounded-state 模式

令 \(H\in\{0,1\}^N\)，地址长度
\(m=\lceil\log_2(N+1)\rceil\)。一个 common-object evaluator 使用：

* 一份所有地址共享的 \(w\)-bit static/writable memory；
* \(T\) 个显式 transitions，至多 \(q\) 次自适应 read/write；
* \(s\) 位任意 nonlinear control state；
* 每个 transition 的 fan-in-2 控制电路大小至多 \(g\)。

memory、transition truth table、初始化和输出控制均计价；unit-cost global oracle
不属于此模式。

## 定理 506.1（global-state source-exit normal form）

对一个 proposed non-product global relation，若它保持 common proof/address space、
single-valued target semantics 和原 all-policy target-relative soundness，则它要么落入
以下两种可计价实现之一，要么必须显式声明后面的 model exit：

### (F) Family-visible-view 分支

若它可在上述 family-visible-view 模式下作用于一个 \(k\)-bit message family，则
inline compiler 给出 weak RLDC，locality 至多
\[
Q_{\mathrm{view}}=1+2q\,2^r B A^q .
\tag{506.1}
\]
当 \(P+k\le k(\log k)^c\) 在无穷多个长度成立，并适用 finite-alphabet RLDC
下界时，必有
\[
r+\log_2 B+q\log_2 A+\log_2(q+2)
\ge
\log_2\log k-\log_2\log_2\log k-O_{A,\rho,\beta,c}(1).
\tag{506.2}
\]

### (S) Singleton bounded-state 分支

若它只作用于一个 fixed target \(H\)，但可在上述 bounded-state 模式下运行并对所有
地址输出 \(H[a]\)，则存在普通 fan-in-2 电路满足
\[
\operatorname{CC}(H)
\le
O\!\left(Tg+q(w+s+m)+m+1\right).
\tag{506.3}
\]
因此，在同一无限 hard-length 集合上
\(\operatorname{CC}(H_N)>S_N\) 时，
\[
Tg+q(w+s+m_N)+m_N+1=\Omega(S_N).
\tag{506.4}
\]

所以一个同时声称 near-linear proof、address-scale global state 和 hard-target
Closure 的方案，若不支付 (506.2) 的 finite-view/RLDC 代价，也不支付 (506.4) 的
forcing-scale circuit 代价，就必须退出至少一个原始量词：

1. visible state/transcript 无界或不可枚举；
2. memory、transition、preprocessing 或访问达到 object scale；
3. 每个地址切换 physical proof、descriptor 或 sheet；
4. 把 global oracle/transition 当作 unit-cost；
5. 改变 all-policy target-relative soundness 或 proof-radius 语义。

这些是 model exits，而不是尚未命名的 address-scale non-product relation。

## 证明

在 (F) 分支，固定 coordinate/claim。一次执行中 future proof addresses 只依赖
public tape、至多 \(q\) 个 proof symbols 和一个来自至多 \(B\) 个可见 state
transcripts 的标签。因此所有 policies 可达到的 proof positions 的并集大小至多
\[
q\,2^r B A^q.
\]
把一个 message bit inline 到 proof word，并枚举有限 views，可得到
(506.1) 的 nonadaptive weak RLDC；完美完备性和错误 claim 的 all-policy soundness
给出正确/错误 gap。调用 C449 的有限字母 RLDC 下界即得 (506.2)。

在 (S) 分支，按 transition 时间展开。每个 transition 复制 \(O(g)\) 个门；每次
memory read 用一个 \(w\)-input multiplexer，每次 write 用 \(w\) 个 conditional
update 单元，故总 memory cost 为 \(O(qw)\)。保留地址输入、控制状态和终止输出，
得到 (506.3)，再与 forcing lower bound 比较得到 (506.4)。这正是 C466 的
writable-RAM expansion；只读 descriptor 是 \(s=0\) 的特例 C465。

若 (F) 与 (S) 都不成立，则不能同时使用 finite visible-view compiler 和标准
bounded-state circuit expansion。逐项检查两个定义，剩下的正是上面五类 model
exit；不存在一个既不改变资源量词、又不落入任一电路/编码展开的第三类“免费”
global coupling。证毕。

## 对 RW/JK Closure 的直接后果

在 C505 已关闭 Harsha \(P=p(q)\) 后，任何新机制都必须先标注自己属于 (F)、(S)
还是 model exit：

* 试图用 finite sheet index、有限摘要、有限轮 response 或有限策略状态保持
  common proof，进入 (F)，而不是自动获得 whole-word consistency；
* 试图把相关性放入可写 memory、非线性状态或重复读，进入 (S)，并由 C455 的
  forcing scale 收费；
* 只有真正无界/不可枚举的 global state、object-scale preprocessing、target-dependent
  proof，或新的 soundness 量词仍在范式之外。

因此，当前 top-level 正攻不再是“寻找任意 non-product relation”，而是证明一个
满足上述 model-exit 之一、同时仍能完成 Gate I--III 的新 PCP/coding theorem；否则
新 relation 只是 C449/C466 已有 barrier 的重命名。

## 证据边界

* (F) 需要 message family、common proof、positive radius 和 all-policy soundness；
  published RW fixed-\(x_0\) singleton 不会仅凭 (506.2) 自动进入 RLDC 分支。
* (S) 是标准 fan-in-2 RAM/transition 模型；不覆盖 unit-cost global oracle、未计价
  任意 transition truth table 或地址依赖 physical proof。
* 定理是 source-exit classification，不是一般 dPCP/global-relation impossibility，
  也不证明 \(P\ne NP\)。

## 来源

* [C449 finite-state non-product normal form](449-finite-state-global-relation-normal-form-2026-08-19.md)。
* [C465 repeated-read nonlinear-memory gate](465-repeated-read-nonlinear-memory-closure-gate-2026-08-19.md)。
* [C466 bounded writable-RAM gate](466-bounded-writable-ram-closure-gate-2026-08-19.md)。
* [C455 published RW forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
* [C505 fixed-\(x_0\) Harsha \(P\)-segment closure](505-fixed-x0-harsha-p-segment-closure-trichotomy-2026-08-19.md)。
