> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW Closure 的 promise-prMA 确定化门（2026-08-18）

> **适用范围修正：published RW 的 Reconf query 具有完美完备性，故本 note 的
> generic bounded-gap 警告不适用于 source theorem。** 见
> [C387](387-rw-perfect-completeness-prma-collapse-2026-08-18.md)：在
> \(P=NP\) 下，\(\exists w\forall r\,V(q,w;r)=1\) 属于 \(\Sigma_2^P=P\)，
> 足以模拟实际 RW promise 两侧。本 note 只保留对非完美完备性、非标准 query
> format 的泛化审计。

## 本轮判定

C363 与 C371 中“在 \(P=NP\) 下把 smart-prMA query 确定化”的表述必须带一个
额外的 source-level 条件。RW 的 Reconf query 不是一个已经给出总判定算法的
NP 语言，而是 promise-prMA 查询：

\[
\begin{aligned}
q\in\mathsf{YES}
&\Longrightarrow
\exists w\;\Pr_{r}[V(q,w;r)=1]\ge 2/3,\\
q\in\mathsf{NO}
&\Longrightarrow
\forall w\;\Pr_{r}[V(q,w;r)=1]\le 1/3.
\end{aligned}
\tag{384.1}
\]

gap 区间的输入不受语义约束。RW 的 smartness 只保证 canonical branch 实际生成的
query 落在 promise 内；它没有给出 gap 输入的 totalization，也没有说明如何把
随机阈值谓词在地址尺度内计算。因此

\[
P=NP\not\Rightarrow
\text{所有 smart-prMA queries 都有多项式时间确定化器}
\tag{384.2}
\]

不能作为无条件的量词替换。这里不是一个已证明的复杂度分离，而是 C363/C371
所需充分条件没有被 \(P=NP\) 单独提供的 source audit。

## 计数边界

令 \(L=|q|\)，令 \(w\) 的长度和 verifier 的运行时间均为 \(L^{O(1)}\)，并令
随机带长度为 \(R(L)\)。对固定 \(w\)，阈值谓词

\[
\Pr_r[V(q,w;r)=1]\ge 2/3
\]

需要计算一个 \(2^{R(L)}\) 项的计数阈值。一般而言，这不是 NP 判定；把 Merlin
witness 的存在性再加上随机阈值，直接落在类似 NP-with-threshold / NP\({}^{\mathrm{PP}}\)
的上界，而不是普通 NP。即便 \(P=NP\)，也没有由此推出该 promise problem 的
totalization 或其固定格式的确定性模拟。

这一区分也解释了为什么“query 在 promise 内”本身不够：smartness 是关于实际
输入落点的语义保证，不是一个可以被模拟器用来识别 promise 的算法。

## 可判定的短随机带特例

若对固定 query format 有

\[
R(L)\le c\log(L+2),
\tag{384.3}
\]

则所有随机带可在 \(L^{O(1)}\) 时间内枚举。对给定 \(w\)，接受比例阈值成为
一个确定性多项式时间谓词；于是 YES 条件是 NP 谓词，NO 条件的反面也是 NP
谓词。在 \(P=NP\)（从而 \(P=coNP\)）下，任意落在 promise 内的 query 都可由
一个 \(L^{O(1)}\)-时间算法判定。更一般地，只要 source 直接提供一个
promise-preserving simulator

\[
D(q)=
\begin{cases}
1,&q\in\mathsf{YES},\\
0,&q\in\mathsf{NO},
\end{cases}
\qquad
\operatorname{time}(D(q))\le L^{O(1)},
\tag{384.4}
\]

则不需要枚举随机带，C363 的 Reconf-to-circuit 组合才可以合法执行。该 simulator
必须对 gap 输入任意定义，但在 promise 上与 (384.1) 一致；它不要求先判定输入
是否属于 promise。

因此 Gate-III 至少有三个可接受的正向接口：

1. 证明 RW 固定 query format 存在 (384.4) 的 promise-preserving simulator；
2. 把随机带压到 (384.3) 的可枚举窗口，并用 \(P=NP\) 完成阈值判定；
3. 改造 Reconf，使其使用一个无 gap 的、可在 \(P=NP\) 下 totalize 的谓词。

## 对 RW 参数的直接审计

RW Low-Degree Self-Corrector 的随机带长度是 \(\operatorname{polylog}(t)\)。若
Reconf query 的描述长度只有

\[
L=\operatorname{poly}(k,\log t),
\]

则 source statement 并不推出 \(R=O(\log L)\)。当 \(R\) 是 \((\log t)^c\)（\(c>1\)）
量级时，枚举随机带的代价可达 \(t^{\Omega(1)}\)，相对于最终地址长度
\(\log T\) 可能已经是对象尺度。故不能把 C363 中的确定化步骤解释为

\[
\text{\(P=NP\) 自动把 RW Reconf 变成地址尺度的确定性 evaluator}.
\]

C371 的 \(r=s=0\) 确定性重编译只消掉 encoded-history 的 round/prefix 记账；它不
消除 (384.1) 的 promise-threshold 层，也不替代 (384.4)。在没有上述额外接口时，
此前的 width/round conservation 结论应读作条件性版本：

\[
\text{若有固定格式 promise-preserving simulator，}
\quad
\text{failure}\Longrightarrow
\operatorname{CC}(f(x))\le
(k+r+\log T)^{O(1)}.
\tag{384.5}
\]

## Closure 计划中的位置

该审计把最终无条件矛盾链的 Gate-III 精确改写为

\[
P=NP
\;+\;
\text{RW query-format simulator (384.4)}
\Longrightarrow
H_A\in P/\mathrm{poly},
\]

再与同一 \(H_A\) 的 forcing 下界对齐。仅有 smartness、共同 canonical proof 或
\(r=s=0\) 重编译，都不足以删除 simulator 这一项。Gate-I 的 output/auxiliary
attachment 与 Gate-II 的 bottom、cover、descriptor 分类仍然独立存在；本 note
不声称其中任何一项已经闭合，也不声称存在一般 promise-prMA 下界。

## 证据边界

* C363 的 Reconf 预算与失败分支结论见
  [note 363](363-rw-reconstruction-width-round-conservation-2026-08-18.md)；
  本 note 把其中的“固定格式确定化”改为显式假设。
* C371 的 \(P=NP\) 确定性重编译与 width/solver 三分见
  [note 371](371-rw-deterministic-recompile-width-trichotomy-2026-08-18.md)；
  本 note 补充其 promise 层没有随 \(r=s=0\) 消失。
* promise-prMA 的 gap 语义、RW Self-Corrector 的随机带和 Reconf 接口来自
  Ren--Williams, ECCC TR26-118, Theorems 3.5 and 4.1 的 source extraction。

该结果是一个量词/充分条件审计：它关闭“仅凭 \(P=NP\) 自动 totalize RW query”的
推理，但不是 \(P\ne NP\) 证明、promise complexity separation 或一般 dPCP/RLDC
不可能性定理。
