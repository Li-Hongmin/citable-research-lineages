> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha assignment grid-only generic-access barrier (2026-08-19)

## 改变的判断

Harsha 的 assignment interpolation 包含 C458 的
individual-degree 插值子空间，而不是只有一个宽松的 total-degree 黑箱模型。因而若
proposed RW/Harsha closure 只提供 systematic table
\(\widetilde A|_{H^m}\)，不能把“低度延拓”本身当作 generic-point random access：
在所有坐标离开 \(H\) 的点上，精确、零错误的黑箱查询必须读取整个 \(H^m\) 表。

## Source specialization

令 \(h=|H|\)，并令 \(A:H^m\to\{0,1\}\subseteq H\) 为任意 assignment。Harsha
明确允许逐变量次数至多 \(|H|\) 的插值；取标准张量 Lagrange representative \(q_A\)
（次数严格小于 \(|H|\)）则满足
\[
 \deg_{X_i}q_A<h\quad(i\in[m]),\qquad q_A|_{H^m}=A.
\tag{484.1}
\]
\(q_A\) 的 total degree 因而至多 \(m(h-1)\le mh\)，落在 Harsha
Proposition 5.4.1 的允许范围内；因此它是该 source promise 中的合法子族。特别地，
对 \(z\in H^m\)，张量 Lagrange 基
\[
 L_z(X)=\prod_{i=1}^m\ell_{z_i}(X_i)
\]
在 \(H^m\) 上是单点指示函数；因此 \(L_z\) 本身对应一个合法的 Boolean assignment
（唯一一个 grid point 取 1，其余取 0）。

## 定理 484.1（Harsha grid-only exact generic barrier）

设算法只能查询 \(q_A|_{H^m}\)，并要在预定
\(x\in F^m\) 上精确输出 \(q_A(x)\)，其中
\[
 k(x):=|\{i:x_i\notin H\}|.
\]
即使只要求算法对 Boolean assignment family
\(A:H^m\to\{0,1\}\) 正确，deterministic 或 zero-error randomized query
complexity 仍至少为
\[
 h^{k(x)}.
\tag{484.2}
\]
特别地，\(x\in(F\setminus H)^m\) 时必须查询全部 \(h^m\) 个 systematic symbols。

### 证明

张量 Lagrange 展开给出至多 \(h^{k(x)}\) 个非零系数，查询这些 entries 即得上界。
对下界，沿所有回答为 0 的 decision-tree path 运行。若仍有某个
\(z\in H^m\) 满足 \(L_z(x)\ne0\) 而未被查询，则零 assignment 与单点 assignment
\(\mathbf 1_{\{z\}}\) 在所有已查询 grid 点上的回答完全相同，但其插值在 \(x\) 处分别为
0 与 \(L_z(x)\ne0\)。故该路径不能正确停止，必须查询所有这样的 \(z\)，其数目为
\(h^{k(x)}\)。zero-error randomized 的每个正概率分支同样必须正确，故服从同一下界。
\(\square\)

## 对 RW/Harsha Closure 的精确含义

若一个 proposed evaluator 的输入只有 systematic \(H^m\) table，那么它在 generic
off-grid point 上不能是 address-scale exact evaluator；C483 的 ZoS 局部逆并不会改变这
个黑箱事实。任何低于 \(h^{k(x)}\) 的方案必须显式使用额外结构，例如：

* tableau/cell-time 的小描述与可计价 evaluator；
* 自动序列、低秩 tensor/branching representation 或其他 source-specific global
  relation；
* 非 exact、非零错误或改变 proof/address 量词的接口。

这些额外结构不是“由 Reed--Muller 插值免费提供”的。对 C439/C457 所需的 generic
\(q\)-access，若未给出其中一项，系统表、ECC image 或 random-line transcript 都不能
替代它；若给出并且仍为 address-scale，则进入 C459 forcing branch。

## 证据边界

本定理只关闭 grid-only black-box exact access，并要求 proposed semantics 至少覆盖
上述标准插值子族。它不排除 actual RW tableau 的特殊 poly\((\log N)\) evaluator，也
不适用于 bounded-error approximation 或允许额外 descriptor/oracle 的模型；因此不单独
证明 \(P\ne NP\)。

## 来源

* Harsha thesis §5.4.1, pp.72--73：任意 \(H^m\) assignment 可被逐变量次数至多
  \(|H|\) 的 polynomial extension 表示，total degree 至多 \(m|H|\)；Proposition 5.4.1。
  标准张量 Lagrange representative 的严格次数界是本 note 的显式选择。
* [C458 sharp grid-to-generic theorem](458-grid-to-generic-exact-query-lower-bound-2026-08-19.md)。
* [C459 published RW generic-\(q\) forcing](459-published-rw-generic-q-access-forcing-scale-2026-08-19.md)。
* [C483 exact ZoS local inverse](483-harsha-zos-first-division-local-inverse-2026-08-19.md)。
