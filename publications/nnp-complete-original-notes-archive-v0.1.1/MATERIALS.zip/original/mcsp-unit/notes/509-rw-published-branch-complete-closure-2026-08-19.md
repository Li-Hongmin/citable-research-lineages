> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Published RW 两分支的 branch-complete Closure gate（2026-08-19）

## 本轮改变的判断

C508 只处理了一次 Solve failure 调用的语义 surface，C487 只处理了
Solve success 的 parent-binding 缺口。两者现在可以在 Theorem 4.3 的同一个
published hard output 上对齐：每个 good length 都由 advice 选择 reconstruction
\(A_1\) 或 solver \(A_0\) 分支，而 C455 给出的 forcing 下界针对的正是这两个分支
共同输出的 \(B_n=A'(1^n)\)。因此，若想把 RW 路线闭合，不必要求一个同时覆盖两种
执行路径的单一物理接口；只需分别证明两个 branch-local 接口，并在每个 hard length
上至少满足其中一个。无限鸽巢原则随后把其中一支提升到无限 hard-length 集合。

failure 分支的接口可以比 common-proof 弱：一个固定的、single-valued 的
\(\Sigma_2^P\) surface 就够了。不同地址使用不同 Merlin circuit 不构成额外出口。
但该 surface 的**总输入、量词和矩阵长度**必须压到地址尺度；否则 C455 的同一
truth-table forcing 会把它收费到 object scale。success 分支则仍必须证明同一
parent \(B_n\) 的 charged binding；child outsider 本身不够。

## 记号与 published hard lengths

令 \(\mathcal I\) 是 C455 给出的无限集合。对 \(n\in\mathcal I\)，设

\[
  B_n=A'(1^n),\qquad N_n=|B_n|=2n,
  \qquad
  \operatorname{CC}(B_n)
    \ge c_0\frac{N_n}{\log(N_n+2)} .
  \tag{509.1}
\]

Theorem 4.3 的正确 advice bit 记为 \(\alpha_n\)。在 \(\alpha_n=1\) 的 good
length，\(A_1\) 来自一个失败的 Solve 调用，并逐位运行 Reconf；在
\(\alpha_n=0\) 的 good length，\(A_0\) 走 solver-success 路径。令

\[
  \mathcal I_F=\{n\in\mathcal I:\alpha_n=1\},\qquad
  \mathcal I_S=\{n\in\mathcal I:\alpha_n=0\}.
  \tag{509.2}
\]

这里的分类只对 C455 的 hard good lengths 使用；非 good length 上的 advice 行为
不进入结论。

## 定理 509.1（failure branch 的 exact surface payment）

对每个 \(n\in\mathcal I_F\)，存在同一个 failure 调用的 canonical prefix
\(\tau_n\)，以及一个固定的 \(\Sigma_2^P\) predicate

\[
  W_F(\langle 1^n,\sigma,a\rangle)
   =\exists C\;\forall\rho\;
       A_F(1^n,\sigma,a,C,\rho),
  \tag{509.3}
\]

其中 \(\sigma_n\) 可以包含 \(\tau_n\) 或其任何声称的 succinct replacement，且

\[
  W_F(\langle 1^n,\sigma_n,a\rangle)=B_n[a]
  \qquad(a\in[N_n]).
  \tag{509.4}
\]

设 \(L_n\) 是一次 (509.3) surface evaluation 的总表示长度上界：它包括地址、
source/context、descriptor、Merlin witness、随机串、矩阵描述及其生成所需的
计价工作空间。若 \(P=NP\)，则存在常数 \(c_*\) 与固定 evaluator，使

\[
  \operatorname{CC}(B_n)
   \le O(L_n^{c_*}+L_n).
  \tag{509.5}
\]

因此在 \(n\in\mathcal I_F\) 上，必有

\[
  L_n
   =\Omega\!\left(
      \left(\frac{N_n}{\log(N_n+2)}\right)^{1/c_*}
     \right).
  \tag{509.6}
\]

特别地，若一个 proposed failure compiler 把完整 surface（而不是只把地址 \(a\)
本身）压到 \((\log N_n)^{O(1)}\)，则 (509.5) 与 (509.1) 矛盾。因此，在
\(P=NP\) 的反证分支中，C508 的 semantic surface 不能被一个真正的 address-scale
PH representation 实现；若无条件证明该 representation 存在，即立即得到
\(P\ne NP\)。

### 证明

由 C508，failure 调用的共同 prefix 与最终 query 给出

\[
  B_n[a]=\exists C\;\forall\rho\,A_{x_n,\tau_n,a}(C,\rho).
\]

把任何声称的 prefix/accessor compression 记为 descriptor \(\sigma_n\)，便得到
(509.3)--(509.4)。这是固定层 \(\Sigma_2^P\) 语言；在 \(P=NP\) 时
\(\Sigma_2^P=P\)，故同一个确定性算法在总输入长度 \(L_n\) 上以
\(L_n^{c_*}\) 时间计算它。固定 \(\sigma_n\) 和该长度的 source/context 为常量，
把地址 \(a\) 接到这个 evaluator 上，就得到 (509.5) 的 truth-table circuit。
将 (509.1) 代入并吸收加法项即得 (509.6)。这里没有使用同一个 Merlin witness，
也不需要 public-tape sampling：\(\exists C\forall\rho\) 已经是 exact Boolean
surface。证毕。

## 定理 509.2（success branch 的 parent-binding payment）

对每个 \(n\in\mathcal I_S\)，Theorem 4.1 的 published success 语义只给出

\[
  Y_n=\operatorname{Solve}_{f_n}(x_n,G_n)
  \notin\operatorname{Range}(G_n).
  \tag{509.7}
\]

若一个 proposed closure 另给出同一个 \(B_n\) 的 charged parent-binding attachment，
其 package/support、控制电路、访问次数与地址/符号长度分别为
\(L_n^{\rm pkg},g_n,q_n,\ell_n,a_n\)，则 C487 给出

\[
  \operatorname{CC}(B_n)
   \le O\!\left(
      g_n+q_nL_n^{\rm pkg}(\ell_n+a_n)+\ell_n
     \right).
  \tag{509.8}
\]

结合 (509.1)，任意真正的 address-scale attachment 都与 forcing 矛盾；若不满足
同一 object、single-valued、普通 ROM/support 计价中的任一项，则它已进入 C487 的
semantic/model-exit 分支，不能再由 (509.7) 自动称为 RW Closure。

## 推论 509.3（branch-complete Closure criterion）

假设存在一个固定 branch-local theorem，在每个 \(n\in\mathcal I\) 上满足以下至少
一项：

* 若 \(\alpha_n=1\)，给出定理 509.1 中 \(L_n=(\log N_n)^{O(1)}\) 的 exact
  surface；
* 若 \(\alpha_n=0\)，给出定理 509.2 中
  \(g_n,q_n,L_n^{\rm pkg},\ell_n,a_n=(\log N_n)^{O(1)}\) 的 charged
  parent-binding。

则 \(P\ne NP\)。事实上，\(\mathcal I_F\cup\mathcal I_S=\mathcal I\)，故至少一支
在无限多个 hard lengths 上出现。若 \(\mathcal I_F\) 无限，定理 509.1 在
\(P=NP\) 下与 (509.1) 矛盾；若 \(\mathcal I_S\) 无限，定理 509.2 与 (509.1)
矛盾。长度集合、forcing object 与 output word 在两支中始终是同一个 \(B_n\)。

## 对 Closure 计划的直接影响

1. **failure 正攻已精确化。** 下一步不是再绑定一个共同 Merlin circuit，而是
   证明 \(\tau_n\)、query matrix 和 quantified witness 存在 address-scale
   succinct representation；若 representation 长度仍为
   \(N_n^{\Omega(1)}\)，C509 已给出其 forcing payment。
2. **success 正攻不能绕过 parent。** 需要从 actual published \(Y_n\) 建立与同一
   \(B_n\) 的 parent-binding；只证明 \(Y_n\) hard 或 \(Y_n\notin\operatorname{Range}(G_n)\)
   都不够。
3. **两支不必共享同一物理协议，但必须共享 branch-complete 量词。** 这比要求
   一个覆盖所有 execution paths 的统一 dPCP 更弱，也比逐地址的局部反例更接近最终
   \(P\ne NP\) 闭合；任何缺失分支都不能被 advice 量词静默跳过。
4. 该结果是 conditional Closure gate，不是 \(P\ne NP\) 证明；它把最终正攻的
   最小承重点压缩成两个明确目标：failure 的 address-scale PH compression，或
   success 的 same-parent charged binding。

## 证据边界

* C455 的 lower bound 只在 infinitely-often hard lengths 上成立；C509 不把它扩大
  到所有长度。
* C508 的 exact surface 只适用于 Theorem 4.1 的 failure invocation；C509 通过
  Theorem 4.3 的 \(A_1\) reconstruction branch 使用它，不把 success child 当作
  failure output。
* C487 的 (509.8) 要求 same-object、single-valued 与普通 package/support 计价；
  未计价 global oracle 或改变 soundness/length 量词的方案必须另立 theorem。
* 509.1--509.6 仍在 \(P=NP\) 反证分支中使用 PH collapse；没有据此声称已经证明
  \(P\ne NP\)。

## 来源

* [C508](508-rw-failure-branch-semantic-ph-surface-2026-08-19.md)。
* [C487](487-rw-solver-success-parent-binding-support-trichotomy-2026-08-19.md)。
* [C455](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
* [Ren--Williams Theorem 4.1--4.3](../../thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md)。
