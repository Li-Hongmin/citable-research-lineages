> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK parent-binding 的多 outsider 通信下界（2026-08-18）

## 判定

C377 的 block-width 门可以推广到多次 success 调用。设 parent 是一个
\(b\)-bit family，固定的 JK/AVOID 调用每次只输出一个 \(2k\)-bit outsider；即使允许
\(q\) 次调用、调用之间自适应选择、以及 \(d\)-bit 的 target-dependent descriptor，
只要这些调用共享同一 parent-binding decoder，就必须满足

\[
  2kq+d\ \ge\ \log_2|\mathcal B|.
\tag{378.1}
\]

特别地，对完整 family \(\mathcal B=\{0,1\}^b\)，

\[
  q\ \ge\ \frac{b-d}{2k}.
\tag{378.2}
\]

因此当地址长度 \(\ell=\lceil\log_2(b+1)\rceil\) 且
\(k,q,d=\ell^{O(1)}\) 时，任何 family-level exact parent binding 都不可能成立：
所需 success 调用数至少为 \(b/\ell^{O(1)}\)，这在地址尺度上是超多项式的。

这是一个 source-specific RW/JK closure barrier，而不是 \(P\ne NP\) 证明。published
RW Theorem 4.3 在每个调用固定 \(x_0\)，实际 parent 是 singleton；因此要调用本定理，
必须先证明 family lift，或给出一个不把 parent bits 藏进 descriptor 的 uniform
diagonalization。该 singleton 边界不能被通信计数偷换掉。

## 多次 success 的模型

令 \(\mathcal B\subseteq\{0,1\}^b\)。固定一组 public JK 实例
\(G_1,\ldots,G_q\) 和调用规则；第 \(t\) 次调用可自适应地依赖此前的 outsider，
但不直接读取 \(B\)。每次输出

\[
  Y_t(B)\in\{0,1\}^{2k}.
\]

允许一个依赖 \(B\) 的 descriptor
\(\sigma_B\in\{0,1\}^d\)，并假设存在一个 exact decoder

\[
  E(G_1,\ldots,G_q,Y_1,\ldots,Y_q,\sigma_B)=B
  \qquad\text{for every }B\in\mathcal B.
\tag{378.3}
\]

调用索引、\(G_t\) 的公开描述和自适应控制规则都视为 public；若它们本身携带
target-dependent information，则必须计入 \(\sigma_B\) 或 success transcript。

## 通信定理

在上述模型中，映射

\[
  B\longmapsto
  \bigl(Y_1(B),\ldots,Y_q(B),\sigma_B\bigr)
\]

必须是 injective。否则两个不同 parent 产生完全相同的 decoder 输入，违反
(378.3)。而 transcript 的取值数至多为 \(2^{2kq}\)，descriptor 的取值数至多
为 \(2^d\)，故

\[
  |\mathcal B|\le 2^{2kq+d},
\]

即得 (378.1)。

自适应性不改变计数：后续调用的 public address/instance 是此前输出的函数，
不会额外增加超出输出 transcript 的信息。若每次调用的 block 宽度为 \(k_t\)，
相同证明给出更一般的

\[
  \sum_{t=1}^{q}2k_t+d\ \ge\ \log_2|\mathcal B|.
\tag{378.4}
\]

## 与 C377 的 signal/off-signal 分解

在 padded target \(F_B=B0^{T-b}\) 且 \(b\le2k\) 的 regime，C377 将每个
success output 分成 signal 与 off-signal 两类。对一个固定 off-signal fiber，
输出值对 parent 不变；因此该 fiber 内的通信下界实际上只由 signal outputs 和
descriptor 承担：

\[
  2k\,q_{\mathrm{sig}}+d
  \ \ge\ \log_2|\mathcal F_{\mathrm{off}}|.
\tag{378.5}
\]

这比只用 (378.1) 更强：重复收集 off-signal outsiders 不会增加 parent information。
只有 signal path、另一个 target-dependent object，或 message-scale descriptor
能够减少剩余 fiber。

## RW 参数推论

对 RW 的 stage-\(i\) parent \(B_i\in\{0,1\}^{2n_i}\)，令
\(b_i=2n_i\)、\(\ell_i=\Theta(\log n_i)\)。若一个拟议的 address-scale closure
只允许

\[
  k_i,\ q_i,\ d_i\le \ell_i^{O(1)}
\]

并试图对一个 \(2^{b_i}\)-规模的 parent family 做 exact binding，则 (378.2) 要求

\[
  q_i\ge \Omega\!\left(\frac{n_i}{\ell_i^{O(1)}}\right).
\tag{378.6}
\]

这远超任何 \(\ell_i^{O(1)}\)-time/address procedure。若坚持 \(q_i=1\)，则
(378.1) 退化为 \(2k_i+d_i\ge2n_i\)，即 child width 或 descriptor 必须达到
parent 的 object scale；这正是 C377 的短-block结论的多调用版本。

## 证据边界

* C377 的 signal/off-signal 结构与 padded target：note
  377-jk-padded-signal-offpath-parent-binding-2026-08-18.md。
* Ren--Williams Theorem 4.1 的 success 输出仅为一个 \(2k\)-bit outsider；
  Theorem 4.3 的实际递推固定 \(x_0\) 并使用 singleton target。
* 本定理是一个通信/计数 barrier，适用于 family-level 或明确禁止
  message-scale hidden advice 的 parent-binding 模型；它不对 published
  singleton call 直接推出 impossibility，也不声称 \(P\ne NP\)。
