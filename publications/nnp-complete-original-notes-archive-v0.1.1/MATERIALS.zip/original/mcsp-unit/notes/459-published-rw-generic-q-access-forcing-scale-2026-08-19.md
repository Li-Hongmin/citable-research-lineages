> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Published RW generic \(q\)-access 的 forcing-scale 下界（2026-08-19）

## 本轮改变的判断

C457 把 Harsha 的 \(P=p(q)\) generic access 与 assignment polynomial \(q\) 的
generic access 做成双向多项式归约。更直接地，结合 C456 对同一个 published hard
output 的 systematic-coordinate 对齐，可以把 forcing 下界直接转成
\(q\)-evaluator 的电路下界：

\[
  \text{在 source-compatible factorized interface 内，generic \(q\)-access
  不能是 address-scale polylog evaluator；它必须支付 forcing-scale 复杂度。}
\]

这关闭了一个容易混淆的出口：Reed--Muller self-correction 可以用少量
**oracle queries** 读取一张长 proof table，但这不等于一个不带长 ROM 的
Boolean value evaluator。

## 设置

取 C455 的无限 good-length 集合 \(\mathcal I\)。对 \(n\in\mathcal I\)，记

\[
  B_n=A'(1^n,a_n),\qquad N_n=|B_n|=2n,
  \qquad
  \operatorname{CC}(B_n)\ge c\,\frac{N_n}{\log N_n}.
\tag{459.1}
\]

在 \(P=NP\) 分支中，按 C456 取同一个确定性 source-compatible machine \(M\)，
并用 C453--C454 的 hist-first serialization、fresh output-check 与 output map。令
\(q_n:F_n^{m_n}\to F_n\) 为该 serialization 中 honest systematic assignment 的
低度多项式，满足

\[
  q_n(u_{n,j})=B_n[j]\qquad(j\in[N_n]).
\tag{459.2}
\]

设：

* \(E_{q,n}\) 是一个 single-valued generic-point field-symbol evaluator，
  电路大小为 \(s_{q,n}\)；
* \(s_{\mathrm{out},n}\) 计入 output-address map \(j\mapsto u_{n,j}\)；
* 所有 evaluator 的描述和非一致参数都计入上述电路大小，不另附一个
  message-scale oracle/ROM。

## 定理 459.1（generic \(q\)-evaluator forcing lower bound）

在上述条件下，对每个 \(n\in\mathcal I\)，有

\[
  \operatorname{CC}(B_n)
  \le s_{q,n}+s_{\mathrm{out},n}
     +\operatorname{poly}(m_n,\log|F_n|).
\tag{459.3}
\]

因此

\[
  s_{q,n}
  \ge \operatorname{CC}(B_n)-s_{\mathrm{out},n}
     -\operatorname{poly}(m_n,\log|F_n|).
\tag{459.4}
\]

特别地，若

\[
  \log|F_n|,m_n,s_{\mathrm{out},n}
  =\operatorname{polylog}N_n,
\tag{459.5}
\]

则

\[
  s_{q,n}=\Omega\!\left(\frac{N_n}{\log N_n}\right).
\tag{459.6}
\]

因而 source-compatible factorized branch 中不存在
\(m_n^{O(1)}=\operatorname{poly}(\log N_n)\)-size generic \(q\)-evaluator。

### 证明

给定地址 \(j\)，先用 output map 生成 \(u_{n,j}\)，再调用一次
\(E_{q,n}(u_{n,j})\)。由 (459.2)，输出恰为 \(B_n[j]\)。把地址转换、field-symbol
encoding 与一次 evaluator 调用电路化即得 (459.3)。移项得到 (459.4)；代入 C455 的
(459.1) 与 (459.5) 即得 (459.6)。证毕。

## 对 Closure 的直接影响

1. **坐标重排不够。** C398 这样的连续 segment 只给出
   “address \(\mapsto\) proof-table cell”；若该 cell 仍由长 ROM 提供，不能把
   \(q_n\) 变成小电路。
2. **Reed--Muller self-correction 不够。** 它是 query-efficient oracle
   procedure；将 proof table 视为 ROM 后，必须按 C450 的 common-ROM 展开支付
   descriptor/table 复杂度。
3. **factorized branch 已完成尺度闭合。** 在 C453--C456 的
   source-compatible/published alignment 下，任何不支付 (459.6) 的方案必须
   退出 \(P=p(q)\) factorization、退出同一 word/address space，或引入一个新的
   non-product global relation。

## 证据边界

* 定理在 \(P=NP\) 的反证分支、C453--C454 的 source-compatible serialization、
  C456 的 systematic-coordinate 对齐和 C455 的 infinitely-often hard lengths 下成立；
  不需要 \(\widehat D\)-evaluator，不是无条件的 \(P\ne NP\) 证明。
* 若 evaluator 使用一个未计价的 q-dependent ROM，结论不适用；但那正是
  common-ROM/model-exit 分支，不能继续称为 address-scale value evaluator。
* 定理关闭的是 Harsha factorized source branch，不排除新的 non-product
  PCP/coding theorem。

## 来源

* [C455 published RW forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
* [C456 published-output source alignment](456-published-rw-output-source-alignment-and-direct-scale-boundary-2026-08-19.md)。
* [C450 scale-complete Closure normal form](450-scale-complete-rw-closure-normal-form-2026-08-19.md)。
