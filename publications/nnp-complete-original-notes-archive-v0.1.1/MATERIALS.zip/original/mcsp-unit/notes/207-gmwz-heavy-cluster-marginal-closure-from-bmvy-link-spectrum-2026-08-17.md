> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# GMWZ heavy-cluster marginal closure from the BMVY link spectrum (2026-08-17)

## The source-specific statement

This note instantiates the latent-top covariance theorem for the actual heavy clusters
\(\mathcal U_i\) supplied by GMWZ Lemma 6.2. The quantifier is the
GMWZ direct-product/cross-cluster distribution: sample the shared top face \(U\), the
shared \(s\)-face \(b\subseteq U\), and two \(k\)-faces \(a_0,a_1\) independently
conditioned on \((U,b)\). After \(b\) is fixed, the decoder view \((u,t)\) is sampled
from the base decoder law and is independent of \((U,a_0,a_1)\). This is not a claim
that the one-output dPCP marginal itself samples a top face first.

The conclusion is a genuine source-specific closure of the \(\xi_{ij}\) gate for
factorized heavy-cluster events. It does not yet synchronize the decoded words or
close the RW address-scale gate.

## Parameters

Take \(k=r^2\) to be a perfect square and put \(s=r=\sqrt{k}\), as in the
GMWZ direct-product tester. Let \(\mathcal U_i,\mathcal U_j\subseteq X(k)\)
be two disjoint heavy clusters from GMWZ Lemma 6.2. Write

\[
 \mu_i=\Pr[a\in\mathcal U_i],\qquad
 \mu_j=\Pr[a\in\mathcal U_j],\qquad
 \mu_0=\min\{\mu_i,\mu_j\}.
\]

GMWZ supplies \(\mu_0\ge\delta^{C_*}\) for a constant \(C_*\). Define

\[
 r_i(b)=\Pr[a\in\mathcal U_i\mid b],\qquad
 \sigma_i^2=\operatorname{Var}_b r_i(b).
\]

Let \(\theta_0\) be a uniform \(X(k)\to X(s)\) centered-incidence bound and let
\(\theta_1\) be a uniform \(s\)-link \(X_b(k-s)\to X_b(d-s)\) centered-incidence
bound:

\[
 \sigma_i^2\le \theta_0^2\mu_i,\qquad
 \operatorname{Var}_{U\mid b}\Pr[a\in\mathcal U_i\mid U,b]
 \le \theta_1^2r_i(b).
 \tag{GMC1}
\]

The BMVY local-spectral lemma supplies these with separate empty-link and
nonempty-link parameters:

\[
 \theta_0\le \sqrt{\frac{s}{k}}+\operatorname{poly}(k)\Gamma_{\varnothing},
 \qquad
 \theta_1\le \sqrt{\frac{k-s}{d-s}}+\operatorname{poly}(d-s)\Gamma_+,
 \tag{GMC2}
\]

whenever the relevant links satisfy the one-sided local-spectral hypothesis. For the
BMVY source, \(\Gamma_+=\operatorname{poly}(d)/\sqrt q\) on nonempty links, while
\(\Gamma_{\varnothing}\le 1/(d-1)+2/\sqrt q\) by Theorem 2.13, item 6. The
partite BMVY/GMWZ family also has the alternative link-graph estimate obtained from
their Theorem 2.13 and Lemma 2.11.

## Heavy-cluster \(\xi\)-closure

**Theorem.** Assume

\[
 \theta_0^2\le \frac{\mu_0}{4},
 \qquad
 \theta_1^2\le \frac{\mu_0}{4}.
 \tag{GMC3}
\]

For the factorized event
\[
 C_{ij}=\{a_0\in\mathcal U_i,\ a_1\in\mathcal U_j\},
\]
let \(\gamma_{ij}=\Pr[C_{ij}]\), and let \(\xi_{ij}\) be the total variation between
the conditioned decoder view \((t,u)\mid C_{ij}\) and its base law. Then

\[
 \gamma_{ij}\ge \frac{\mu_i\mu_j}{2}\ge\frac{\mu_0^2}{2},
 \tag{GMC4}
\]

and

\[
 \xi_{ij}
 \le
 \frac{4\theta_0}{\sqrt{\mu_0}}
 +\frac{2\theta_0^2+4\theta_1^2}{\mu_0}.
 \tag{GMC5}
\]

In a parameterized source family with fixed heavy-cluster mass \(\mu_0>0\), choosing
\(k,d\) and the local-expansion parameter so that \(\theta_0=o(1)\) and
\(\theta_1=o(1)\) gives \(\xi_{ij}=o(1)\). This is a source-parameter statement,
not an asymptotic claim about the single fixed complex used at one theorem setting.
With \(s=\sqrt{k}\) (and \(k\) restricted to perfect squares) and negligible
local-spectral error, it is enough to
take \(k\gg\mu_0^{-2}\) and \(d\gg k/\mu_0\).

### Proof

For each \(b\), put
\[
 p_i(U,b)=\Pr[a_0\in\mathcal U_i\mid U,b],\qquad
 p_j(U,b)=\Pr[a_1\in\mathcal U_j\mid U,b].
\]
Conditional independence gives
\[
 w_{ij}(b):=\Pr[C_{ij}\mid b]
 =\mathbb E_{U\mid b}[p_i(U,b)p_j(U,b)].
 \tag{GMC6}
\]

Let \(\bar\gamma=\mathbb E_b[r_i(b)r_j(b)]\). By Cauchy--Schwarz and (GMC1),
\[
 |\bar\gamma-\mu_i\mu_j|
 \le \sigma_i\sigma_j
 \le \theta_0^2\sqrt{\mu_i\mu_j}
 \le \frac14\mu_i\mu_j,
 \tag{GMC7}
 \]
and hence \(\bar\gamma\ge3\mu_i\mu_j/4\). Moreover,
\[
 \gamma_{ij}
 =\bar\gamma+\mathbb E_b c_{ij}(b)
 \ge \mu_i\mu_j-(\theta_0^2+\theta_1^2)\sqrt{\mu_i\mu_j}
 \ge \frac12\mu_i\mu_j,
\]
which proves (GMC4).

The centered-product decomposition gives
\[
 \mathbb E_b|r_i(b)r_j(b)-\bar\gamma|
 \le \mu_j\sigma_i+\mu_i\sigma_j+\sigma_i\sigma_j.
 \tag{GMC8}
\]
Using (GMC1), (GMC4), and \(\mu_i,\mu_j\ge\mu_0\),
\[
 \frac{\mathbb E_b|r_i r_j-\bar\gamma|}{\bar\gamma}
 \le \frac{4\theta_0}{\sqrt{\mu_0}}
 +\frac{2\theta_0^2}{\mu_0}.
 \tag{GMC9}
\]

 Write \(c_{ij}(b)=\operatorname{Cov}_{U\mid b}(p_i,p_j)\). The link contraction in
 (GMC1) yields
 \[
 \mathbb E_b|c_{ij}(b)|
 \le \theta_1^2\sqrt{\mu_i\mu_j}.
 \tag{GMC10}
 \]
Together with (GMC4), this gives the covariance ratio
\[
 \kappa_{\rm top}:=
 \frac{\mathbb E_b|c_{ij}(b)|}{\bar\gamma}
 \le \frac{4\theta_1^2}{3\sqrt{\mu_i\mu_j}}
 \le \frac{2\theta_1^2}{\mu_0}\le\frac12.
 \tag{GMC11}
\]
The latent-top identity from C190/206 now gives
\[
 \xi_{ij}\le
 \frac{\eta_{\rm marg}+2\kappa_{\rm top}}
 {2(1-\kappa_{\rm top})}.
\]
Since \(\kappa_{\rm top}\le1/2\), this is at most
\(\eta_{\rm marg}+2\kappa_{\rm top}\); substituting (GMC9) and (GMC11) proves (GMC5).
\(\square\)

## Consequence for the GMWZ parameter window

The source theorem gives the heavy clusters \(\mu_0\ge\delta^{C_*}\), while BMVY
Lemma 2.8 and the source's link expansion give (GMC2). At the purely geometric level,
\[
 \theta_0^2=O(k^{-1/2})+\operatorname{poly}(k)
 \left(\frac1{d-1}+\frac1{\sqrt q}\right),\qquad
 \theta_1^2=O(k/d)+\operatorname{poly}(d)q^{-1/2}.
\tag{GMC12}
\]
Thus the \(\xi\)-gate is not an independent asymptotic mystery in this
factorized cluster regime: it is closed by an explicit choice of the source constants,
first choosing \(d\) to absorb the \(1/(d-1)\) term and then choosing \(q\) to
absorb the \(q^{-1/2}\) terms. The local-spectral error must lie below the two
displayed mass thresholds.
The remaining synchronization inequality is the already separate one
\[
 \rho_{ij}^{\rm base}
 \le \xi_{ij}
 +\frac{\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j}{\gamma_{ij}},
 \tag{GMC13}
\]
so the proof still needs the common-word/label-error term and the direct-product
soundness gap.

## What this does not prove

This theorem does not upgrade GMWZ list-decoding to unique decoding. It only closes the
conditioned decoder-marginal gate for factorized heavy-cluster events. It does not handle
non-factorized cross events, cover-sheet assignments, arbitrary right labels, or the
RW/JK address-scale reconstruction. Those are separate obligations in the Closure
program.

## Sources

* GMWZ, [Definition 2.7 and Theorem 2.9](https://arxiv.org/html/2512.12960#S2.3.3).
* GMWZ, [Lemma 6.2 and Lemma 6.3](https://arxiv.org/html/2512.12960#S6.2).
* BMVY, [Lemma 2.8, Lemma 2.11, and Theorem 2.13](https://arxiv.org/html/2407.12762).
* [Latent-top covariance theorem](206-bmvy-link-spectrum-closes-latent-top-covariance-2026-08-17.md).
