> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Key-indexed ACRR 二分：短 target key 或 relaxed-LDC 超线性代价（2026-08-16）

正式定理见
[key-indexed ACRR / RLDC dichotomy](../../rw-jk-succinct-reconstruction/statements/key-indexed-acrr-rldc-dichotomy.md)。

## 新主结果

允许不同的短 key `sigma` 选择不同的 coordinate verifier family，但要求同一 key 桶内
所有消息共用同一 verifier 语义，并满足 target-relative near-oracle soundness。对每个
key 桶，阈值化立即给出一个 valid-input relaxed local decoder；DGL 的 sample reduction
和共同样本信息论收尾于是作用于该桶的消息熵。

若消息总熵为 `h`、key 长度为 `s`，则某个桶至少有 `h-s` 比特熵，进而满足

```text
h-s <= C |Sigma|^Q log|Sigma| · N^(1-theta) · log(k+2),
theta = Theta(1/(Q^2 log^2(Q+2))).
```

所以在固定查询/alphabet 与 DGL 半径窗口中，`s=o(k)` 强制 proof length 超线性；近线性
proof 则迫使 shared key 接近 `k` 比特。这把 C54 的 target-channel 熵界与 RLDC/LDC
barrier 合成一个二分，而不是两个互不相干的局部观察。

## 适用边界

该结果要求 key 桶内 verifier 不再看到完整 target message，并要求 robust radius 足以
调用 DGL（或参数化小半径版本）。若 Merlin 在看到坐标后才发送任意新响应，模型变成
`forall i exists tau_i`，不再有共同 word/parent seed；若 verifier 直接读完整 target，
则是 target-specific hardwiring，不能调用该定理。因而它是 family-level、target-relative
的 top-tier barrier candidate，不是单一 RW 实例的无条件结论。

该定理还给出一个有限 response 版本：若 Merlin 在看到坐标后发送 `r` 比特响应，且
错误声明对所有响应均 sound，则穷举响应只把 locality 放大到
`Q_r=O(2^r q_0(alpha-beta)^(-2))`。所以常数长度响应仍无法绕开 barrier；响应长度
本身必须承担 query complexity 代价，或者变成未压缩的任意函数而退出有限模型。

## 对 RW 与 GM--W--Z 的量词审查

对 GM--W--Z 型 full message family，`M={0,1}^k`，所以 `h=k`，C55 的二分直接作用于
message channel：若 shared key 是 `o(k)`，就必须支付其 relaxed-LDC 的超线性 proof
代价。

对一个固定输入长度为 `n` 的 deterministic RW transducer，若目标词只取自
`{f_x: x in {0,1}^n}`，则有效目标族熵至多 `h<=n`，即使输出词长度 `k` 远大于 `n`。
此时 C55 只能给 `h-s` 的界，不能把它替换成 `k-s`；若 key 本身就是输入 `x`，甚至
可能有 `s=n`、`h-s=0`。因此要把 C55 用于 RW，必须另证一个高熵实例族、把多个独立
inputs 合并到同一 family，或证明 computation relation 的 target channel 本身有
`h=Omega(k)` 的有效熵。这个要求是实质量词条件，不是记号重命名。

## 为什么值得升级

它给出一个清晰的论文级主张形式：任何试图把 simultaneous coordinate robustness
压到 near-linear proof 的构造，必须在同一 key 桶内支付近线性 target entropy，或者
突破 DGL/RLDC 的 sample lower bound。剩余开放问题已收窄为：RW/GM--W--Z 型构造是否
满足该 key-indexed 量词，或是否能利用 index-aware interaction 保持 JK parent closure。

## 来源

* [正式 theorem module](../../rw-jk-succinct-reconstruction/statements/key-indexed-acrr-rldc-dichotomy.md)
* [Dall'Agnol--Gur--Lachish](https://eccc.weizmann.ac.il/report/2020/154/)
* [C54 approximate target-channel entropy barrier](195-approximate-target-channel-entropy-barrier-2026-08-16.md)
