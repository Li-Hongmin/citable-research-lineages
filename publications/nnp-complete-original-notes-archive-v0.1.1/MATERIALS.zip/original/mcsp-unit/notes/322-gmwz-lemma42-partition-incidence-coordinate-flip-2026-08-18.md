> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# GMWZ Lemma 4.2: partition-incidence coordinate-flip barrier (2026-08-18)

## Status and scope

This note records a source-specific obstruction for the PCPP-to-udPCP construction in
Gur--Minzer--Weissenberg--Zheng (GMWZ), arXiv:2512.12960, Lemma 4.2. It is not a
lower bound for arbitrary udPCPs or dPCPs. The point is to expose exactly which
incidence pattern a proposed coordinate-robust upgrade of that construction would
have to avoid.

The construction starts from a \(k\)-uniform PCPP hypergraph
\(\Psi_0=(V_0,E_0,\ldots)\), with input vertices \([n]\subseteq V_0\), partitions
\(E_0\) evenly into \(E_{0,t}\) (\(t\in[n]\)), and creates a left vertex
\((e,s)\) for every \(e\in E_{0,s}\). Its left alphabet is a map on
\(e\cup\{s\}\) whose restriction to \(e\) satisfies the original PCPP constraint;
the \(k+1\) right-neighbor constraints only check agreement. The decoder for
coordinate \(s\) reads \(F_{e,s}(s)\). These are exactly the definitions in
GMWZ Lemma 4.2, especially lines 903--923 of the public version:
<https://arxiv.org/html/2512.12960>.

## The incidence-flip lemma

Let

\[
  \lambda_t:=\Pr_{e\sim E_0}[t\in e],
  \qquad
  a_t:=\Pr_{e\sim E_{0,t}}[t\in e].
\]

Take the binary singleton language

\[
  \mathcal L=\{0^n\},
\]

which is obtained by choosing a circuit \(\varphi\) accepting exactly \(0^n\).
Fix a coordinate \(t\), and modify a perfect-completeness right assignment \(A_0\)
by changing only the right label at \(t\) from \(0\) to \(1\). For every left
vertex \((e,s)\), keep the left map equal to \(A_0\) on \(e\). If \(s\notin e\),
set its extra \(s\)-component to the modified right label at \(s\); if \(s\in e\),
there is no extra independent component.

Then:

1. Every left symbol remains in its constrained alphabet, since its restriction to
   \(e\) is unchanged and still satisfies \(\Phi_{0,e}\).
2. The base agreement slots labelled \(t\) fail once for each occurrence of \(t\) in
   \(e\). In addition, when \(s=t\) and \(t\in e\), the graph still has the extra
   \(s\)-slot (the map has no independent second \(t\)-value, but the slot is a
   repeated agreement check), so that slot fails as well. Put
   \[
      \gamma_t:=\Pr_{(e,s)}[s=t\land t\in e]=\frac{a_t}{n},
   \]
   where the last equality uses the equal partition and the uniform compiled-left
   distribution. Hence the exact violated-edge fraction is
   \[
      \varepsilon_t^{\mathrm{flip}}=\frac{\lambda_t+\gamma_t}{k+1}
      =\frac{\lambda_t+a_t/n}{k+1}.
   \tag{322.1}
   \]
   The partition index contributes only through the self-incidence term \(\gamma_t\).
3. All decoded coordinates \(s\ne t\) are still \(0\). Coordinate \(t\) is decoded
   as \(1\) exactly on those \(e\in E_{0,t}\) with \(t\notin e\). Its error rate
   relative to the unique legal word \(0^n\) is therefore \(1-a_t\), and the full
   decoding error is
   \[
      \varepsilon_t^{\mathrm{dec}}=\frac{1-a_t}{n}.
   \tag{322.2}
   \]

Consequently, any claimed

\[
  \left(\eta,\frac{\rho\eta}{2(k+1)}\right)
\text{-unique-decoding soundness}
\]

for this explicit Lemma-4.2 construction must satisfy, for every \(t\),

\[
  \eta\ \ge\ \min\left\{\frac{2(\lambda_t+a_t/n)}{\rho},\;\frac{1-a_t}{n}\right\}.
\tag{322.3}
\]

Indeed, if \(\eta\) were smaller than both terms, then (322.1) would lie inside
the soundness promise while (322.2) would exceed the allowed decoding error. The
only legal word is \(0^n\), so the existential choice of \(w\in\mathcal L\) in
GMWZ Definition 3.10 cannot absorb the error.

## What this adds beyond the generic \(1/n\) tax

The usual black-box argument only says that average coordinate error \(\eta\) does
not imply a worst-coordinate bound without \(\eta\le\beta/n\). Equation (322.3)
identifies the concrete attack and the exact construction parameter controlling it:

* \(\lambda_t\) is the original PCPP incidence of input coordinate \(t\), and
* \(a_t\) is the self-incidence created by the arbitrary edge partition.

If some \(t\) has \(\lambda_t\ge\lambda_0\) and \(a_t\le1-\theta\), then

\[
  \eta\ge\min\{2\lambda_0/\rho,\theta/n\}.
\tag{322.4}
\]

Thus an \(\eta=o(1/n)\) upgrade of this construction is possible only if every
coordinate with non-negligible original incidence is assigned almost exclusively to
hyperedges that already contain that same coordinate:

\[
  1-a_t\le n\eta
  \quad\text{whenever }\lambda_t>\rho\eta/2.
\tag{322.5}
\]

This is a structural partition-incidence escape, not a parameter tweak. Under a
balanced/random partition where \(a_t\) remains \(O(k/n)\) and a smooth PCPP has
\(\lambda_t=\Theta(k/n)\), (322.3) recovers the tight \(\Omega(1/n)\) coordinate
scale, now by an explicit assignment in the actual GMWZ graph.

A deterministic proof-only corollary is also available. Let
\[
  \mu:=\Pr_{e\sim E_0}[e\cap[n]=\varnothing].
\]
Because every edge is assigned to exactly one part \(E_{0,s}\),
\[
  \frac1n\sum_{t=1}^n(1-a_t)
  =1-\frac{1}{|E_0|}\sum_{t=1}^n
      |\{e\in E_{0,t}:t\in e\}|
  \ge\mu.
\tag{322.6}
\]
Hence some \(t\) has \(1-a_t\ge\mu\). If, in addition, every input coordinate
satisfies \(\lambda_t\ge\lambda_0/n\), then (322.3) gives
\[
  \eta\ge \frac1n\min\left\{\frac{2\lambda_0}{\rho},\mu\right\}.
\tag{322.7}
\]
This removes the random-partition assumption, while retaining the explicit
source condition that the PCPP actually contains a nonzero proof-only edge mass.

## Persistence through the GMWZ regularization layer

The same assignment can be transported through the three graph operations used in
the proof of GMWZ Lemma 4.5 (edge repetition, left copying, and the right-side
expander replacement), and through the final matching augmentation, before the
separate HDX routing of Section 5.

Let \(d\) denote the regularization degree and \(C\) the left-copy parameter. In the
initial graph, the degree of the right input vertex \(t\) (counting the repeated slot
when \(t\in e\)) is
\[
  |E_0|\left(\lambda_t+\frac1n\right).
\]
After edge repetition and left copying, the right-side expander replacement creates
right vertices carrying the \(t\)-label in the same proportion
\((\lambda_t+1/n)/(k+1)\). The final
left side has \(Cd(k+1)|E_0|\) vertices. Hence the fraction of matching right
vertices carrying the flipped \(t\)-label is exactly
\[
  \frac{\lambda_t+1/n}{k+1}.
\tag{322.8}
\]

Assign every such right vertex the flipped underlying label, keep the left labels
from the Lemma-4.2 attack, and set the additional \(\Sigma_0\)-symbol on each
matching right vertex to the decoder output of its matched left vertex. All matching
output-equality checks are then satisfied. The base half of the final regular graph
has defect \((\lambda_t+a_t/n)/(k+1)\); at worst all matching edges incident to a
\(t\)-labelled right vertex fail their underlying base check. Therefore the complete
regularized graph has a near assignment with
\[
  \varepsilon_t^{\mathrm{reg}}
  \le
  \frac{2\lambda_t+(1+a_t)/n}{2(k+1)},
  \qquad
  \varepsilon_t^{\mathrm{dec}}=\frac{1-a_t}{n}.
\tag{322.9}
\]

Consequently, any final regularized udPCP with soundness pair
\((\eta,\varepsilon)\) must obey
\[
  \eta<\frac{1-a_t}{n}
  \quad\Longrightarrow\quad
  \varepsilon<
  \frac{2\lambda_t+(1+a_t)/n}{2(k+1)}.
\tag{322.10}
\]
Otherwise the transported assignment lies inside the soundness promise but decodes
too far from the singleton language. This is a persistence statement, not a new
impossibility theorem: the displayed GMWZ Lemma 4.5 soundness
\(\varepsilon=\Theta(\eta^5)\) can evade (322.10) by making the rejection threshold
small. It shows precisely that the later regularization does not remove the
incidence attack; it hides it behind a vanishing soundness parameter.

## Boundary of the claim

The conclusion is deliberately conditional on the pair \((\lambda_t,a_t)\). The
published Lemma 4.2 permits a partition for which \(a_t=1\) for every \(t\) whenever
each hyperedge can be assigned to one of its input coordinates. In that degenerate
orientation, the displayed flip does not change the decoded \(t\)-coordinate, so
(322.3) is vacuous. Therefore this note does **not** prove that every near-linear
udPCP has a \(1/n\) barrier. It proves that the specific GMWZ edge-partition route
must either pay the incidence tax or supply a new orientation/target-normalized
decoding relation. Subsequent regularization steps cannot be treated as if they
automatically remove this source-level dichotomy.

The proof uses only the exact graph/alphabet definitions and Definition 3.10 of GMWZ;
it does not assume canonical proof selection, list soundness, or a JK closure. It is
therefore an independent source-specific module that can be combined with the RW
closure theorem only after the common-proof and address-space hypotheses are supplied.
