> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Minimax patchability certificates for adaptive shared proofs (2026-08-17)

## Contribution

The exact hitting duality gives a lower bound for a fixed honest query policy.  The
following finite-game form is stronger as a proof interface: it optimizes over all
honest query-set distributions at once and gives an equivalent adversarial certificate.
It separates the decoder's query-design freedom from the semantic question of which
corruption sets can be realized by one global proof.

## Theorem (minimax patchability certificate)

Fix a target \((m,i)\).  Let \(\mathscr S\) be a finite family of possible honest query
sets, and let \(\mathscr B\) be a finite family of realizable corruption sets.  For each
\(B\in\mathscr B\), let \(\gamma_B\in[0,1]\) be a first-hit forcing probability: a
candidate proof differing from the honest proof only on \(B\) outputs the wrong symbol with
conditional probability at least \(\gamma_B\) whenever the honest path first hits \(B\).
Define the patchability value

\[
 v(\mathscr S,\mathscr B,\gamma):=
 \min_{\mu\in\Delta(\mathscr S)}
 \max_{B\in\mathscr B}
 \gamma_B\,\Pr_{S\sim\mu}[S\cap B\ne\varnothing].
 \tag{262.1}
\]

Then every adaptive decoder whose honest query-set distribution is supported on
\(\mathscr S\), and whose target-relative wrong-output soundness is measured against all
patches in \(\mathscr B\), satisfies

\[
  \operatorname{soundness}_{m,i}
  \ge v(\mathscr S,\mathscr B,\gamma).
 \tag{262.2}
\]

Moreover, finite minimax gives the exact dual certificate

\[
 v(\mathscr S,\mathscr B,\gamma)=
 \max_{\lambda\in\Delta(\mathscr B)}
 \min_{S\in\mathscr S}
 \sum_{B\in\mathscr B}
 \lambda_B\gamma_B\,\mathbf 1[S\cap B\ne\varnothing].
 \tag{262.3}
\]

Thus a distribution \(\lambda\) on realizable patches is a lower-bound certificate if it
hits every allowed honest query set with weighted probability at least \(\eta\): then every
decoder in the model has wrong-output soundness at least \(\eta\).

### Proof

Let \(\mu_D\) be the honest query-set distribution of a decoder \(D\).  For each patch
\(B\), couple the execution on the patched proof with the honest execution using the same
random tape.  Until the first read in \(B\), the two transcripts and adaptive query choices
are identical.  The forcing assumption therefore gives wrong output probability at least

\[
  \gamma_B\,\Pr_{S\sim\mu_D}[S\cap B\ne\varnothing].
\]

Taking the maximum over \(B\) and using \(\mu_D\in\Delta(\mathscr S)\) proves (262.2).
The payoff matrix
\(A_{S,B}=\gamma_B\mathbf 1[S\cap B\ne\varnothing]\) is finite, so von Neumann minimax

\[
  \min_\mu\max_B\mathbb E_{S\sim\mu}A_{S,B}
  =\max_\lambda\min_S\mathbb E_{B\sim\lambda}A_{S,B}
\]

is exactly (262.3). \(\square\)

## Universal \(t\)-patch corollary

Let \(N\) be the proof length, let \(\mathscr B_t\) contain every \(t\)-subset of
\([N]\), and suppose every honest query set has between \(q_0\) and \(Q\) distinct
positions.  With \(\gamma_B=1\), the uniform distribution on \(\mathscr B_t\) is a dual
certificate.  Consequently

\[
  \operatorname{soundness}_{m,i}
  \ge
  1-\frac{\binom{N-q_0}{t}}{\binom Nt}.
 \tag{262.4}
\]

The bound is tight in the abstract query-set game: a uniform distribution on all
\(q_0\)-subsets attains equality.  For \(t=\lfloor\rho N\rfloor\) and
\(q_0=o(\sqrt N)\),

\[
  1-\frac{\binom{N-q_0}{t}}{\binom Nt}
  =1-(1-\rho)^{q_0}+o(1).
\tag{262.5}
\]

Without the \(o(\sqrt N)\) restriction, the exact binomial ratio in (262.4) is the
statement to use; its logarithm differs from \(q_0\log(1-\rho)\) by
\(O(q_0^2/N+q_0/N)\).

The lower endpoint \(q_0\) is essential.  If empty or arbitrarily small honest query sets
are admitted, the minimax value can be zero; the theorem records query utilization rather
than charging a nominal query budget.

## Product-patch direct-sum corollary

The same certificate gives a useful multi-target consequence when local patches can be
composed into one global proof.  Let the target set be \([k]\), let \(R_i\) be pairwise
disjoint proof regions, and assume every honest query set for target \(i\) is contained in
\(R_i\).  For each \(i\), suppose there is a distribution \(\lambda_i\) on realizable
patches \(B_i\subseteq R_i\) and a number \(\eta>0\) such that

\[
\inf_{S\in\mathscr S_i}
\mathbb E_{B_i\sim\lambda_i}
\bigl[\gamma_{i,B_i}\mathbf 1[S\cap B_i\ne\varnothing]\bigr]\ge\eta .
\tag{262.6}
\]

Assume, in addition, that any choice of local patches on a set \(T\subseteq[k]\) can be
combined into one valid global patched proof, and that the first-hit forcing guarantee
for target \(i\) is unchanged when patches on \(R_j\), \(j\ne i\), are added.  If every
patch in the support of every \(\lambda_i\) has size at most \(\tau\), choose

\[
t=\min\!\left\{k,\left\lfloor\frac{\rho N}{\tau}\right\rfloor\right\}\ge1.
\tag{262.7}
\]

Sample a uniform \(t\)-subset \(T\), sample \(B_i\sim\lambda_i\) independently for
\(i\in T\), and take the union \(B_T=\bigcup_{i\in T}B_i\).  The union has size at most
\(\rho N\), and for every fixed target \(i\),

\[
\Pr[\text{wrong output on }i]
\ \ge\ \eta\,\frac{t}{k}.
\tag{262.8}
\]

Thus any target-relative decoder with error at most \(\beta\) for every
\(\rho N\)-near proof must satisfy

\[
\eta\,\frac{1}{k}
\min\!\left\{k,\left\lfloor\frac{\rho N}{\tau}\right\rfloor\right\}
\le \beta .
\tag{262.9}
\]

If \(\eta>\beta\), let
\[
t_\star=\left\lfloor\frac{\beta k}{\eta}\right\rfloor+1\le k.
\tag{262.10}
\]
Then (262.9) forces
\(\lfloor\rho N/\tau\rfloor<t_\star\), and hence, up to the floor effect,
\[
\tau>\frac{\rho N}{t_\star}
=\Omega_{\rho,\eta,\beta}\!\left(\frac Nk\right).
\tag{262.11}
\]
For a disjoint \(k\)-block architecture with \(N=\Theta(kK)\), this rules out
independently composable forcing patches of size \(o(K)\) whenever \(\eta>\beta\).
When \(\eta\le\beta\), the product-patch inequality remains valid but by itself gives
no contradiction with the target error budget.

The proof is a direct coupling: target \(i\) belongs to \(T\) with probability \(t/k\);
conditioned on \(i\in T\), patches on other regions are invisible to the \(i\)-query
transcript, and (262.6) supplies the conditional error \(\eta\).  This is a conditional
direct-sum theorem: without the product-realizability and region-locality hypotheses,
private coordinate blocks alone do not imply (262.8).

## Fractional and restricted certificates

The dual does not require all small corruption sets to be realizable.  A proof graph may
provide a sparse family \(\mathscr B\) and a distribution \(\lambda\) supported only on those
patches.  To prove a constant lower bound it is enough to establish

\[
  \inf_{S\in\mathscr S}
  \mathbb E_{B\sim\lambda}
  [\gamma_B\mathbf 1[S\cap B\ne\varnothing]]\ge\eta.
 \tag{262.12}
\]

This is strictly weaker than universal patchability and strictly stronger than an average
list-soundness statement: the same global proof patch must exist for every \(B\) in the
support, and its first-hit forcing probability must be certified.

If query sets depend on \((m,i)\), apply the theorem separately and take the maximum over
\((m,i)\).  If the proof graph imposes additional restrictions on honest query sets, use
\(\mathscr S_{m,i}\) rather than all subsets of size at most \(Q\); replacing the actual
support by a larger family only weakens the certificate.

## Consequences for coordinate-robust PCPs

The theorem gives a clean generalization of the Lorenz/profile barriers.

* Marginal-incidence bounds upper-bound the hitting payoff for a fixed patch, but cannot
  certify a lower bound without a realizable patch distribution \(\lambda\).
* A successful shared-proof construction must therefore defeat the dual certificate by
  making patches non-realizable, making first hits semantically absorb into \(\bot\), or
  concentrating honest query sets on a family outside the certificate.
* If a positive-radius family lift has a certificate value below its target-relative gap,
  the exact hitting theorem and the RLDC lower bounds apply.  If the value is large, the
  decoder is already forced into the corresponding soundness cost, independently of whether
  its query policy is adaptive.

For the GMWZ private-coordinate architecture, the direct-sum note 259 supplies a concrete
patch family but not a universal shared-proof lower bound: the separate coordinate blocks
make \(\mathscr B\) private rather than common.  The present theorem identifies precisely
what a stronger source-specific result would need to add—a \(\lambda\) that simultaneously
hits the allowed common query sets.  For RW/JK, this is a sharper formulation of the
remaining patchability-or-succinctness conjecture in note 228.

## Scope

This is a finite combinatorial theorem conditional on the stated realizable-patch and
first-hit hypotheses.  It does not assert that ordinary dPCP/list soundness supplies
\(\mathscr B\), nor that GMWZ or RW has a common patch distribution.  It also does not by
itself prove \(P\ne NP\); its value is a reusable certificate that can turn a future
proof-graph patchability lemma into an adaptive shared-proof lower bound without redoing
decoder-specific analysis.

## Sources

* [Exact hitting duality](227-exact-hitting-duality-for-shared-proof-robustness-2026-08-17.md).
* [Pathwise Lorenz profile](226-pathwise-lorenz-profile-adaptive-shared-proof-closure-2026-08-17.md).
* [RW patchability-or-succinctness split](228-exact-patchability-or-succinctness-closure-dichotomy-2026-08-17.md).
