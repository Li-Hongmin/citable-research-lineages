> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW/JK shared half-lift DAG 的 parent-binding 电路代价（2026-08-19）

## 本轮改变的判断

C410 已经排除了“把每个 outsider 各自沿一条 canonical path lift，再拼成 parent”
的低成本方案，但它的表述按 outsider 逐条计费。一个可能的反驳是：多个
output-attached outsiders 共享 JK 中间块，因而不应支付每条路径的全部

\(\lvert G_k\rvert\)-成本。这个反驳可以在更一般的模型中直接处理。

本 note 允许任意共享中间计算：所有 outsider 和 lift 节点组成一个有向无环图，
同一个中间 block 可以被任意多条 parent-address 路径复用。结论是，收费量从
“路径总长度”下降为“不同的 half-lift 调用数”，但每个终端 outsider 的
\(2k\)-bit payload 仍必须显式进入 evaluator。因此共享只能减少重复的 generator
调用，不能把一个 address-scale 的 half-lift DAG 变成 message-scale parent 的
免费 global relation。

这严格扩大了 C410 的覆盖范围：任何仍可编译成 canonical half-lift DAG 的方案，
即使使用缓存、合并路径或共享 sheet，也承受同一个 parent-circuit payment；
只有不能写成这种 DAG 的新 non-product/global relation 才留在 Closure Gate 外。

## 模型

固定

\[
 G_k:\{0,1\}^k\to\{0,1\}^{2k},\qquad
 L_0(z):=G_k(\operatorname{left}_k z),\quad
 L_1(z):=G_k(\operatorname{right}_k z).
\]

考虑一个固定 canonical proof 上的 parent \(B\in\{0,1\}^b\)。一个
**shared half-lift DAG** 包含：

* \(q\) 个 terminal nodes，分别暴露 outsider blocks
  \(y_t\in\{0,1\}^{2k}\)；
* \(v\) 个 internal nodes。每个 internal node \(u\) 选一个先前 node
  \(p(u)\) 及方向 \(\epsilon(u)\in\{0,1\}\)，其 block value 定义为
  \[
    z_u=L_{\epsilon(u)}(z_{p(u)});
  \]
* 一个 descriptor \(\sigma\) 和 address-control circuit \(S\)。它们描述
  node/path/offset 的选择、sheet/key、adaptive rule 以及从 parent address
  到某个 DAG node 的控制。descriptor 的总显式成本记为 \(d\)，控制电路大小
  记为 \(s_{\rm ctrl}\)。

允许同一个 node 有任意多个 downstream consumers；因此 DAG 不要求各条路径
  独立，也不把共享的 intermediate block 重复计数。每个 parent address
  \(a\in[b]\) 经 \(S\) 选择一个 node 及其一个 bit offset，并输出 \(B[a]\)。
 这里 \(S\) 必须是显式 address-control；不能把完整 \(B\) 隐藏在一个未计费的
  selector 中。

令
\[
 C_G:=|G_k|+k+\lceil\log_2(b+2)\rceil.
\]
一次 half-lift（包括取左/右 half、固定地址算术和 wire control）可由
\(O(C_G)\) 个 fan-in-2 gates 实现。terminal payload 的数据选择成本按
\(O(2kq)\) 计入；若某个具体 selector 已将该成本包含在
\(s_{\rm ctrl}\) 中，只会得到更强的界。

## 定理 417.1（shared half-lift DAG payment）

在上述模型中，若 shared half-lift DAG 对同一个 parent 精确计算
\(C_B(a)=B[a]\)（所有 \(a\in[b]\)），则存在 fan-in-2 Boolean circuit 满足

\[
 \operatorname{CC}(B)
 \le
 O\!\left(
   s_{\rm ctrl}+d+2kq+vC_G
 \right).
\tag{417.1}
\]

因此在 forcing 下界 \(\operatorname{CC}(B)>S_B\) 下，任何这样的 closure
必须支付

\[
 s_{\rm ctrl}+d+2kq+vC_G=\Omega(S_B).
\tag{417.2}
\]

### 证明

按 DAG 的拓扑序，把每个 terminal block 的 \(2k\) 个常数线接入 evaluator。
对 internal node \(u\)，复用其 predecessor 已计算的 \(2k\)-bit wire，取其由
\(\epsilon(u)\) 指定的 \(k\)-bit half，再调用一次 \(G_k\)。half 选择、固定
wire control 与地址边界处理的总成本为 \(O(C_G)\)。由于同一个 DAG node 只有
一次定义，即使它被许多 parent addresses 复用，也只需支付一次该成本；所有
internal nodes 合计为 (O(vC_G))。

最后接上 \(S\)。它根据输入 address 选择目标 node 与 bit offset；将 \(q\) 个
terminal blocks 的可见 bits 接入 selector 的数据端，至多支付 \(O(2kq)\) 的
数据选择成本，descriptor 与控制逻辑支付 (O(s_{\rm ctrl}+d))。由模型假设，
输出正好是 \(B[a]\)，故所得 circuit 是 \(B\) 的 address evaluator，得到
(417.1)。

## 与逐路径界的关系

若每个 outsider 使用一条长度 \(\ell_t\) 的独立 path，展开成 DAG 后
\[
 v\le\sum_{t=1}^q\ell_t.
\]
代入 (417.1) 即恢复 C410 的逐 outsider 界（忽略同一常数项的记账约定）。
若多条路径共享中间 node，则 \(v\) 可以严格小于该总长度；(417.1) 仍然成立，
因为它按实际不同的 half-lift 调用计费，而不是按路径重复制图。故“共享路径”
不是 C410 的未覆盖反例。

## 地址尺度推论

### 推论 417.2（polylog DAG 不能绑定 forcing parent）

设 \(b\to\infty\)，且
  \(k,q,v,s_{\rm ctrl},d\le(\log(b+2))^{O(1)}\)，以及
\(|G_k|\le k^4\)。则右端 (417.1) 为 \(\operatorname{polylog}(b)\)。因此在
\[
 \operatorname{CC}(B)\ge \Omega\!\left(\frac{b}{\log(b+2)}\right)
\]
的 forcing regime 中，任何 exact parent binding 都必须退出至少一个条件：

1. terminal outsider 数量或其 explicit payload 达到 message scale；
2. shared half-lift node 数量/控制电路达到 forcing scale；
3. descriptor 携带 message-scale 信息；或
4. attachment 不是可编译的 canonical half-lift DAG，而是一个尚待给出证明的
   non-product/global relation。

特别地，增加 DAG 缓存、复用同一 lift 结果或让多个 coordinate 共用中间块，不能
单独实现 RW 所需的 address-scale whole-parent evaluator。

### 推论 417.3（与 C416 的首失败附着合并）

在 C416 的 fixed binary serialization、zero prefix、contiguous leftmost-failure
条件下，若首个 outsider 被证明 output-attached，并且 closure 使用若干个
output-attached blocks 的 shared half-lift DAG，则直接适用 (417.1)。

* 若 \(b\le2k\)，一个 attached block 已包含整个 parent 的 top block，\(q=1\)；
  C416 的路径只是该 DAG 的一条 unary chain，\(v\) 等于其 lift depth。
* 若 \(b>2k\)，多个 attached blocks 仍须由 DAG 的 terminal/payload 或一个新的
  non-product relation 共同绑定；DAG sharing 只减少 \(v\)，不减少终端 payload
  \(2kq\)。

这把 C416 后的剩余命题精确化为：若不支付 (417.2)，必须真正构造一个不能
编译成 half-lift DAG 的 global relation；仅声称“共享同一 proof”或“缓存路径”
不构成新机制。

## 假设边界

1. **只覆盖 canonical half-lift。** 一个关系可以直接联合多个 outsider、使用
   非局部 algebraic constraint，或从 proof 的其他 coordinates 计算 parent；只要
   它不能展开成上述 DAG，定理不适用。这正是有意义的 positive/global-relation
   目标，而不是被本定理偷换掉的路线。
2. **descriptor 与 selector 必须显式计费。** 若 selector 的 truth table 或
  adaptive strategy 包含完整 parent，则它已落入 \(d\) 或 \(s_{\rm ctrl}\) 的
   message-scale payment，不能称为 address-scale closure。
3. **固定 singleton 也适用。** 定理只要求一个固定 parent 的 exact evaluator，
   不需要 target-oblivious family entropy；若再有 family 量词，可叠加 C378/C407
   的 payload counting，但本定理本身不把 singleton 冒称 family。
4. **不是一般 dPCP/LDC 不可能性，也不是 \(P\ne NP\)。** 结论只关闭 shared
   half-lift 这一具体 RW/JK 机制；新的 global relation 仍可能成功，并且是下一步
   唯一值得投入的正攻接口。

## 与现有结果的精确增量

* C410：按 \(q\) 个独立/显式 path 给出
  \(q\ell(|G|+k+\log b)\) 级 payment。
* C417：允许任意共享 path/intermediate block，把路径总长度替换成实际 DAG
  node 数 \(v\)，从而覆盖缓存与跨坐标复用的最强 half-lift 变体。
* C416：在 \(P=NP\) deterministic recompilation 下先证明 first-failure 的
  output attachment；C417 再判断该 attachment 是否仍只是可编译的 half-lift
  DAG。

本 note 不声称已构造或排除所有 global relation；它把“共享 half-lift”从未命名
逃逸升级为一个有明确复杂度账本的 source-specific barrier。

## 证据边界

* C382/C416：half-lift 与 prefix-first-failure attachment 的路径公式；
* C410：singleton pathwise parent-binding circuit-cost；
* Ren--Williams Theorem 3.1、4.1、4.3：JK outsider、RW proof 与 stable parent
  的来源；
* C417 的证明本身只使用 fan-in-2 circuit composition，不依赖 family entropy、
  dPCP 或 \(P\ne NP\)。
