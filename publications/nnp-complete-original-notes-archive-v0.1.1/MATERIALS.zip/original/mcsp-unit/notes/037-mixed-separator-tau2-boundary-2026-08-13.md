> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 混合 separator、二点 cover 的精确缺口（2026-08-13）

## 结论

设 Φ 是固定 spoiler (s=(x_s,y_s)) 的两两相交、关于 inclusion-minimal collision witness 族，且

\[
\{a,b\}\text{ 是 }Φ\text{ 的 cover}.
\]

把含 (a)（不含 (b)）与含 (b)（不含 (a)）的 witness 的 residual families 记为

\[
\mathcal A=\{T\setminus\{a\}:a\in T,b\notin T\},\qquad
\mathcal B=\{T\setminus\{b\}:b\in T,a\notin T\}.
\]

则 (\mathcal A,\mathcal B) cross-intersecting；但这一本身不足以推出完整 thinning 的 (1/16) 界。以下是混合三类 separator 后仍可审计的最强直接分解。

## 参数分解

令

\[
d_a=x_a+y_a,\qquad d_b=x_b+y_b,\qquad w=x_s+y_s,
\qquad u_a=x_s+x_a,
\]

并把 (z=(r,t)) 的 cell 方程写成

\[
r\cdot x+t=0,\qquad r\cdot y+t=1.
\]

在 anchor (a) 的支持 (H_a) 上，

\[
r\cdot d_a=1,qquad t=r\cdot x_a,qquad
q_s=r\cdot u_a,qquad p_s=q_s+r\cdot w.
\tag{1}
\]

故三类 separator

\[
Q:(q_s=1),\qquad C:(p_s=0),\qquad D:(q_s+p_s=0)
\]

按 (W=r\cdot w) 精确折叠为

\[
\begin{array}{c|c}
W=0&D\text{ 自动成立；}Q\text{ 与 }C\text{ 互补（}p_s=q_s\text{），但两者均落入 }D,\\
W=1&D\text{ 不可能，且 }Q\Leftrightarrow C\Leftrightarrow(q_s=1).
\end{array}
\]

所以 anchor (a) 的混合事件只可能落在

\[
S_a^0=\{r\cdot d_a=1,\ r\cdot w=0\},
\qquad
S_a^1=\{r\cdot d_a=r\cdot w=r\cdot u_a=1\},
\tag{2}
\]

并且 (b) 有完全对称的 (S_b^0,S_b^1)。若相应线性方程独立，随机 (z) 的质量分别为

\[
\Pr(S_a^0)=\frac18,\qquad \Pr(S_a^1)=\frac1{16}.
\tag{3}
\]

若依赖，支持只会收缩；例如 (u_a=d_a+w)（等价于 (y_a=y_s)）时 (S_a^1=\varnothing)。

## 可得粗界与真正缺口

固定 (z) 后四个补集矩形两两不交，故两两相交的 witness 族至多命中其中一个：

\[
\mu_z\le\frac14.
\tag{4}
\]

由 (2)--(4)，直接得到

\[
\Pr(E_a)\le\frac{3}{64},\qquad
\Pr(E_b)\le\frac{3}{64},\qquad
\Pr(E_a\cup E_b)\le\frac{3}{32}.
\tag{5}
\]

对固定单一 separator，四补集与余维二支持可把两 anchor 的并集降到 (1/16)；混合族中 (W=0) 与 (W=1) 是互不相交的参数扇区，故两个单一-separator 证明不能相加后保留 (1/16)。

标准 cross-intersection 只给出互补矩形下的

\[
\nu_z(\mathcal A)+\nu_z(\mathcal B)\le1,
\]

不足以弥补 (5) 中的二分因子。因而剩余原子命题是：

\[
\boxed{\text{在 }W=0/1\text{ 两扇区之间，用 affine collision 的额外秩／电路结构加强 cross-intersection。}}
\]

## 有限证据的审计状态

早期 N=3 枚举曾报告候选值
\[
P=\frac{184}{3584}=\frac{23}{448}<\frac1{16},
\]
但其候选生成器后来发现极小性判定方向错误，故该数值不再作为证据。当前只保留上面的代数分解与可复核显式例子；未审计的搜索峰值不用于支持一般结论。
