> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 多叶 affine-kernel 的线性闭合（2026-08-13）

## 结论

从

\[
E_a\oplus K\subseteq E_b,
\qquad K=\bigcap_{i=1}^s\ker r_i,
\]

再加入所有自然的子集核、秩和熵不变量，仍不能推出
\(s\ge N^{1+\delta}\)。这些信息的最强普适结论是

\[
s\ge N-L_b.
\]

下面给出逐点加强、rank-sum 的上限，以及一个可递归实现的达到等号族。

## 1. 逐点多叶核

令第 \(i\) 个叶的方向为 \(t_i\)，其仿射线性型为
\(\ell_i(z)=r_i\cdot z\oplus c_i\)。定义

\[
I_x=\{i:\ell_i(x)=t_i\},
\qquad
K_x=\bigcap_{i\in I_x}\ker r_i.
\]

若 \(d\in K_x\)，则对每个与 \(x\) 相容的叶
\[
\ell_i(x\oplus d)=\ell_i(x)=t_i,
\]
所以没有这些叶能接收 \((x,x\oplus d)\)。协议覆盖
\(E_a\times NO_b\)，遂

\[
\boxed{x\oplus K_x\subseteq E_b\qquad(x\in E_a).}
\tag{K_x}
\]

因而

\[
\dim K_x\le L_b,
\qquad
\operatorname{rank}\{r_i:i\in I_x\}\ge N-L_b.
\tag{3}
\]

对任意 \(U\subseteq E_a\)，令
\(K_U=\bigcap_{x\in U}K_x\)。则

\[
U\oplus K_U\subseteq E_b,
\qquad
|K_U|\,|\pi_{K_U}(U)|\le |E_b|\le2^{L_b}.
\tag{4}
\]

式 (4) 是所有直接的 \(K_S\)/商空间容量约束；注意对任意叶子集
\(S\) 的 \(K_S=\bigcap_{i\in S}\ker r_i\)，只有在某个 \(I_x\subseteq S\) 时才能把
\(x\oplus K_S\) 放进 \(E_b\)。对一般 \(S\) 不能偷换这一包含关系。

## 2. rank-sum/entropy 只给线性

记 \(q=N-L_b\)。由 (3)，对每个 \(x\)，
\(\operatorname{rank}(I_x)\ge q\)，而
\(\operatorname{rank}(I_x)\le|I_x|\)。故任意概率分布 \(\mu\) 于 \(E_a\) 上均有

\[
q\le \mathbb E_\mu|I_x|
 =\sum_{i=1}^s\Pr_\mu[i\in I_x]\le s.
\tag{5}
\]

把 \(I_x\) 看作随机 bit 向量时，熵只给
\(H(I_x)\le s\)；(3) 不强迫这些 bit 有任何熵。故 rank-sum、matroid 次模性和无额外语义的熵估计均不能超过 (5)。

## 3. 达到等号的递归族

取任意子空间 \(W\le\mathbb F_2^N\)，\(\dim W=L\)，令
\(H\subseteq W\)，并考虑关系

\[
T=H\times(\mathbb F_2^N\setminus W).
\]

在商空间 \(Q=\mathbb F_2^N/W\) 取基泛函
\(r_1,\ldots,r_q\)，其中 \(q=N-L\)，并令所有方向为 \(t_i=0\)。
对 \(x\in H\) 有 \(r_i(x)=0\)，对每个 \(y\notin W\) 至少一个 \(r_i(y)=1\)。顺序查询
\(r_1(y),\ldots,r_q(y)\)，在首次出现 1 时输出该 \(i\)，得到标准 \(\mathrm{OR}_q\) 的递归协议，恰有 \(q\) 个叶。

此时

\[
K=W,
\qquad H\oplus K=W,
\qquad s=q=N-L,
\]

且 \(I_x=[q]\) 对所有 \(x\in H\)。因此行 matroid 是自由 matroid，所有局部核/秩容量均达到等号，活动模式熵为 0。这个例子甚至保留递归不交性；所以仅凭 affine 行 matroid、\(K_S\) 和 (4)，不能推出超线性叶数。

## 4. 对 MCSP 主线的含义

上述族不是在声称 \(E_a, E_b\) 本身是子空间；它证明的是一个方法边界：任何只从
\(E_a\oplus K\subseteq E_b\) 及其线性核/熵后果出发的证明，都无法排除该族。
要越过 \(N-L_b\)，必须使用 \(E_b\) 的非子空间语义（例如高阶 affine collision、描述复杂度的联合约束），或直接使用递归叶之间的非线性相容性；继续增加纯 rank/entropy 账本不会产生 \(N^{1+\delta}\)。

\[
\boxed{\text{affine-kernel/matroid/entropy}\ \Longrightarrow\ O(N)\ \text{至多；超线性必须离开该接口}.}
\]

## 5. 任意关系的线性 cover 上限

这个 no-go 不依赖子空间等号族。对任意不交的
\(X,Y\subseteq\mathbb F_2^N\)，所有坐标叶

\[
R_{j,t}=(X\cap\{x:x_j=t\})
       \times(Y\cap\{y:y_j=1-t\}),
\qquad 1\le j\le N, t\in\{0,1\},
\]

是合法 affine-parity 矩形，并覆盖 \(X\times Y\)：任意 \(x\ne y\) 至少有一个坐标不同。因此

\[
\operatorname{cov}_{\oplus}(X,Y)\le2N.
\tag{6}
\]

从行向量角度，把每个坐标放入两份、偏置分别取 \(0,1\)。对任意 \(x\)，恰有一份行向量处于活动方向；活动行包含标准基，秩为 \(N\)，总行数为 \(2N\)。所以任何只使用
“每个叶的线性方向 + 活动集合的 matroid/rank/entropy”而不使用递归不交路径的下界，普适上最多是线性；其上界甚至与 \(E_a,NO_b\) 的语义无关。

注意 (6) 是 cover 而非递归 partition 上界。递归 QA 的真正困难正是把这些有重叠的坐标叶改造成互不交的矩形树；因此本节只关闭 rank/cover/entropy 接口，不能关闭全局递归势。
