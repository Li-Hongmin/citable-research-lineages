> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK uniform range-cover selector gate（2026-08-19）

## 结论

C491 只处理了固定对角线 \(G_{j+1}\) 覆盖第 \(j\) 个 parent block 的情形。
跨多个 JK calls 的 proposed closure 可能更一般：对每个 block，另选一行
generator \(G_r\) 来覆盖它。本 note 把这类 **uniform range cover** 一次压成
parent evaluator。

令

\[
B=B_1\Vert\cdots\Vert B_m,
\qquad B_j\in\{0,1\}^{2k},
\]

并令

\[
G_r:\{0,1\}^k\to\{0,1\}^{2k},
\qquad r\in[R].
\]

若存在共同且完整计价的 circuits

\[
C_G(r,u)=G_r(u),
\qquad
\mathsf R(j)\in[R],
\qquad
\mathsf U(r,j)\in\{0,1\}^k,
\]

使得

\[
G_{\mathsf R(j)}\bigl(\mathsf U(\mathsf R(j),j)\bigr)=B_j
\qquad(j<m),
\tag{492.1}
\]

则

\[
\boxed{
\operatorname{CC}(B)
\le
O\!\left(
|C_G|+|\mathsf R|+|\mathsf U|
+\operatorname{poly}(k,\log(m+R+2))
\right).
}
\tag{492.2}
\]

因此，对 forcing-hard singleton，任何这样的 uniform range-cover compiler 都必须
支付 forcing scale：

\[
|C_G|+|\mathsf R|+|\mathsf U|
+\operatorname{poly}(k,\log(m+R+2))
=\Omega(\operatorname{CC}(B)).
\tag{492.3}
\]

## 证明

给定 \(B\) 的 bit address，先用
\(\operatorname{poly}(k,\log(m+2))\)-size arithmetic circuit 计算 block index
\(j\in[m]\) 与 block 内 offset \(t\in[2k]\)。

若 \(j<m\)，计算

\[
r=\mathsf R(j),
\qquad
u=\mathsf U(r,j),
\qquad
z=C_G(r,u).
\]

由 (492.1)，\(z=B_j\)，最后选择 \(z_t\)。该地址只调用一次 row selector、一次
seed selector 和一次 generator compiler，因此成本不乘 \(m\)。

若 \(j=m\)，把最后一个 \(2k\)-bit block \(B_m\) hardwire，并用
\(O(k)\)-size multiplexer 选择其第 \(t\) bit。合并两支得到 (492.2)。

## 逐点存在的精确边界

若只有

\[
\forall j<m\ \exists r_j\in[R],\ \exists u_j\in\{0,1\}^k:
\qquad G_{r_j}(u_j)=B_j,
\tag{492.4}
\]

而没有共同的 \(\mathsf R,\mathsf U\)，则可以把 pair table

\[
((r_1,u_1),\ldots,(r_{m-1},u_{m-1}))
\]

hardwire。由同一地址选择电路只得到

\[
\operatorname{CC}(B)
\le
O\!\left(
|C_G|+(m-1)(k+\lceil\log_2(R+1)\rceil)
+\operatorname{poly}(k,\log(m+R+2))
\right).
\tag{492.5}
\]

式 (492.5) 中的 table term 不能由逐点 range membership 删除；它可以携带
message-scale parent information。若每一行还使用 \(d\)-bit generator descriptor
\(\sigma_r\)，则必须另外计入生成 \(\sigma_r\) 的共同 circuit；只有逐行存在而
没有 selector 时，朴素 descriptor table 还要支付 \(Rd\) bits（或其 random-access
控制电路复杂度）。

## 与 JK / RW 的精确关系

对一次 JK call，\(r\) 是该次调用固定的 generator，(492.4) 只是说不同 parent
blocks 分别落入某些调用的 ranges。C492 的新增量是：即使允许任意 row assignment
\(j\mapsto r_j\)，只要这个 assignment 和 seeds 能由同一 address-scale circuits
统一生成，就已经得到整个 parent 的逐地址 evaluator。

C491 是 C492 的对角特例
\(\mathsf R(j)=j+1\)，并且
\(\mathsf U(\mathsf R(j),j)=U(j+1,j)\)。C492 还覆盖：

* 一个 generator 覆盖许多 blocks；
* row assignment 是非单调或 address-dependent 的；
* 多个 generator 的 range 形成一个带 selector 的 set cover。

Ren--Williams Theorem 3.1 每次调用只固定一个 \(G\)，返回首个 outsider 后立即
停止，并不输出跨 calls 的共同 \(\mathsf R\) 或 \(\mathsf U\)。因此 published
Theorem 4.3 的 fixed singleton 不能自动套用 (492.2)；若未来的 Closure interface
声称有这种 range-cover compiler，它必须明确给出并计价这两个 selector。

## 证据边界

本结果只关闭带有可编译 row/seed selector 的 JK range-cover interface。低复杂度
parent、纯存在性的 unordered range cover、未计价 ROM/global state、地址依赖 proof
以及不能展开成 selector-plus-generator 的新 non-product relation 均不在定理范围内。
它不证明一般 AVOID generator 下界，也不证明 \(P\ne NP\)。

## 来源

* [C491](491-jk-address-selective-prefix-range-compiler-gate-2026-08-19.md)：对角
  prefix-range compiler gate；
* [C417](417-rw-shared-half-lift-dag-parent-binding-2026-08-19.md)：共享
  half-lift DAG 的 selector/payment 账本；
* Ren--Williams Theorem 3.1、4.1、4.3：JK calls、success outsider 与 published
  fixed singleton 的来源。
