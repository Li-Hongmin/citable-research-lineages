> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Local hitting 与 parity-profile shrink 的边界

## 1. 比 local PRG 更弱的充分对象

令

\[
Y_a=\{x\in\{0,1\}^N:\operatorname{CC}(x)\le a\},
\qquad
H=\operatorname{GapMCSP}[a,b],
\]

并记

\[
\rho_b=
\Pr_{U_N}[U_N\text{ 不是 }H\text{ 的 NO instance}].
\]

设 \(\mathcal C\) 对取补封闭。若存在集合 \(S\subseteq Y_a\)，能够击中每个
由 \(\mathcal C\) 中函数定义、均匀密度至少 \(1-\rho_b\) 的集合，则

\[
H\notin\mathcal C.
\]

证明：若 \(C\in\mathcal C\) 正确判定该 promise，拒绝集

\[
A=\{x:C(x)=0\}
\]

包含全部 NO instances，故 \(\Pr_U[A]\ge1-\rho_b\)。Hitting 性给出
\(y\in S\cap A\)。但 \(S\subseteq Y_a\)，所以 promise 正确性又要求
\(C(y)=1\)，矛盾。

这严格弱于 fooling：它不要求逼近接受概率，也不要求 fool 单个 parity。因此
[[004-small-bias-locality-barrier]] 中的 Fourier 反集中定理不能直接排除它。

## 2. 通用 succinct HSG 不是独立捷径

Santhanam 的 semantic sampling 定理把下列对象联系起来：低复杂度字符串上的伪随机
分布、低复杂度字符串上的 hitting sets，以及 MCSP 的零错误平均情形困难性[^santhanam]。
在当前有限类版本中，通用 HSG 的负担可直接看出：

\[
\boxed{
\text{证明每个稠密 }\mathcal C\text{-集合都含 }Y_a\text{ 中的点}
}
\]

本身就是排除一个完全避开 \(Y_a\) 的稠密 \(\mathcal C\)-natural property。枚举所有
\(Y_a\) 元素可以把存在的 hitting set 规范化，却不能证明 hitting 性。

因此：

- 只击中某个候选 Gap-MCSP solver 的拒绝集，是目标下界反证的重述；
- 击中所有稠密 \(\mathcal C\)-集合，是更强的零错误平均情形陈述；
- “先构造 universal local HSG”并没有移除数学负担。

若进一步要求由候选 solver 的描述高效生成一个反例点，问题就变成 constructive
separation/refuter，而非普通 HSG。Chen--Jin--Santhanam--Williams 的结果表明，
在远低于当前 \(a\) 的阈值上，极低统一复杂度的 MCSP refuter 已足以推出
\(P\ne NP\)[^constructive]。所以可行的较弱接口应是逐个候选公式的结构性存在定理，
而不是预设一个廉价的统一 refuter。

对 PRG 版本还有一个精确的有限 min--max 边界。令

\[
v=
\min_{D\in\Delta(Y_a)}
\max_{T\in\mathcal C^{\pm}}
\left(\mathbb E_DT-\mathbb E_UT\right).
\]

有限零和博弈给出

\[
v=
\max_{Q\in\Delta(\mathcal C^{\pm})}
\min_{y\in Y_a}
\left(
\mathbb E_{T\sim Q}T(y)-
\mathbb E_{U,T\sim Q}T(U)
\right).
\]

若不存在误差 \(\varepsilon\) 的低复杂度支持分布，抽样

\[
k=O\!\left(\frac{\log|Y_a|}{\varepsilon^2}\right)
=O\!\left(\frac{a\log(a+\log N)}{\varepsilon^2}\right)
\]

个测试并取阈值，可得到一个避开全部 \(Y_a\)、但具有 \(\Omega(\varepsilon)\)
密度的 \(\operatorname{THR}_k\circ\mathcal C^{\pm}\) 性质。对
\(a=2^{(\log N)^{1/3}}\)，该放大只有 \(N^{o(1)}\) 的规模松弛。
所以低复杂度支持 PRG 的纯存在性，近乎等价于排除稍大 Formula-XOR 类中的稠密
natural property；显式 sampler 则是更强的要求。

## 3. 标准递归 restriction 的参数下界

考虑 AW/IMZ/CKLM 型坐标 restriction：每轮以比例 \(p\) 保留变量，用 \(t\) 轮
first-hit 覆盖坐标，并以 \(k\)-wise 独立分布填充残余变量。若未覆盖概率至多
\(\eta\)，则

\[
t
\ge
\frac{\log(N/\eta)}{-\log(1-p)}
=
\Omega\!\left(\frac{\log(N/\eta)}p\right).
\]

全宽 parity 在一轮后仍非恒定的概率为

\[
1-(1-p)^N.
\]

典型残余变量数为 \(m=\Theta(pN)\)。若有限独立性只通过“所有依赖至多
\(k\) 个变量的函数均被精确 fool”这一黑盒使用，则必须 \(k\ge m\)：均匀偶校验
分布是 \((m-1)\)-wise independent，却对 \(m\)-bit parity 有偏差 \(1\)。标准
first-hit multiplexer 与 residual filler 因而具有局部复杂度

\[
L_{\rm coord}
=\Omega\!\left(
\max\left\{pN,\frac{\log(N/\eta)}p\right\}
\right)
\ge
\Omega\!\left(\sqrt{N\log(N/\eta)}\right).
\]

即使只要求常数覆盖，也有

\[
L_{\rm coord}=\Omega(\sqrt N)
\gg
2^{(\log N)^{1/3}}.
\]

这排除了“坐标 restriction + 普通 shrinkage + 有限独立 residual filler + first-hit
recycling”模板在 Frontier B 参数下的直接使用。

## 4. 仿射 restriction 也不能依靠叶消失

对与候选公式无关的仿射 restriction

\[
x=x_0+Ty,
\qquad \operatorname{rank}(T)=r,
\]

parity \(v\cdot x\) 被固定当且仅当 \(vT=0\)。对均匀非零 \(v\)，

\[
\Pr_v[vT=0]
=
\frac{2^{N-r}-1}{2^N-1}
\approx2^{-r}.
\]

因此对任意这样的 restriction 分布，总存在全宽 parity，其被固定概率至多约
\(2^{-r}\)。只要 \(r\to\infty\)，任何通过“固定常数比例 XOR 叶”来证明通用
shrinkage 的引理都是假的。

## 5. 收紧后的唯一结构接口

剩余候选不应要求 parity 叶消失，而应缩减 outer formula 的非线性结构：

\[
\boxed{
\begin{gathered}
\text{构造与候选公式无关、输出坐标具有 }N^{o(1)}\text{ 电路复杂度的随机仿射 restriction；}\\
\text{对每个 }A(P_1,\ldots,P_S)\text{，以常数概率使其在可达 parity profile 上的}\\
\text{非线性复杂度缩小常数因子，同时每轮误差为 }O(\varepsilon/\log S).
\end{gathered}}
\]

若该 profile-shrink 引理成立，\(O(\log S)\) 轮即可避免 \(1/p\) 覆盖成本和
指数小 bias。若它为假，所需反例必须保持大量 outer nonlinear structure，而不能
只指出 parity 叶继续存活。

~~~mermaid
flowchart LR
    P["完整 local PRG"] -->|"small-bias 路线已关闭"| X["不可用"]
    H["通用 local HSG"] -->|"semantic sampling / avg-hardness"| C["循环或更强"]
    R["标准递归 restriction"] -->|"全宽 parity: Ω(√N) locality"| X
    Q["parity-profile restriction"] --> O["只缩 outer nonlinear structure"]
    O --> T["当前唯一未关闭原子命题"]
~~~

[^santhanam]: Rahul Santhanam, *Pseudorandomness and the Minimum Circuit Size Problem*, ECCC TR19-155, 2019, Propositions 2--3. 本文使用的是其 semantic-sampling 机制在固定 distinguisher 类和目标密度下的直接有限版本；不把它外推成一般 natural-proofs 等价。
[^constructive]: Lijie Chen, Ce Jin, Rahul Santhanam, and Ryan Williams, *Constructive Separations and Their Consequences*, TheoretiCS, 2024, Proposition 4.3.
