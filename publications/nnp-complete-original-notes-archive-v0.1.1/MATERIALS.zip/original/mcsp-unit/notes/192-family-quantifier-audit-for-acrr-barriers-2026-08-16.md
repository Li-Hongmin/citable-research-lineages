> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# ACRR 家族量词审计：全 oracle 错误 soundness 的冲突（2026-08-16）

## 结论地位

这是对 note 186、187 中 family-level barrier 模型的基础修正。若 verifier
`V_{i,b}` 不带消息 `m`（或目标实例 `x_m`）作为额外输入，则“对所有消息的完备性”与
“对所有 oracle 的错误声明 soundness”不能同时成立。此前由该组量词推出的
disagreement-hitting/LDC 表述，必须改用一致的 target-relative 模型，或明确声明为
空模型中的形式推导。

## 冲突定理

令 `C:{0,1}^k -> Sigma^N`，并假设存在 `m,m'` 与坐标 `i` 使
`m_i=0`、`m'_i=1`。设 `V_{i,0},V_{i,1}` 是不依赖消息的固定 verifiers。若

1. `Pr[V_{i,m'_i}^{C(m')}=1]=1`（完备性）；
2. 对每个消息 `u`、每个 oracle `z`，若 `b!=u_i`，则
   `Pr[V_{i,b}^{z}=1]<=beta`，其中 `beta<1`（全 oracle 错误 soundness），

则矛盾。事实上，把 `u=m`、`b=1`、`z=C(m')` 代入第二条，得到
`Pr[V_{i,1}^{C(m')}=1]<=beta`；第一条却给出同一概率为 `1`。

因此只要消息族在某个坐标上有两个取值，当前 family-level 定义没有任何实例。

## 三种一致的替代语义

### 1. 固定目标 ACRR

对单一实例 `x` 和单一目标词 `f_x`，只要求 `V_{x,i,b}` 对 `b!=f_x[i]` sound。
该模型正是 RW/JK 的实际目标，但没有一个可直接用于 LDC 长度下界的消息族。

### 2. target-relative family soundness

对每个 `m`，只要求错误分支在目标 codeword 的邻域内 sound，例如存在 `delta_0>0`
使

\[
  \operatorname{dist}(z,C(m))\le\delta_0
  \Longrightarrow
  \Pr[V_{i,1-m_i}^{z}=1]\le\beta .
\]

这与另一个消息的 codeword 不冲突；若再有近 codeword 上正确分支的完备性，才能进行
普通 LDC 阈值编译；若只保留 codeword 点完备性，则通常只能得到 relaxed-LDC 型接口。
这是 note 180、188、190 应采用的 family-level 语义。

### 3. 带消息/实例参数的 verifier

若 `V_{m,i,b}` 显式得到 `m` 或等价的目标实例，则全 oracle soundness 可以成立，但
这种 verifier 已把消息作为 side information，不能直接视为 LDC decoder。任何长度下界
归约必须重新证明 side information 没有把待解消息泄漏给 decoder。

## 对既有 notes 的修正范围

* note 186：把全 oracle 错误 soundness 改为 target-relative near-oracle soundness；
  smoothness 到近 codeword 完备性及频率解码的证明在该语义下成立。
* note 187：把 adaptive LDC barrier 同样改为 target-relative soundness；原文的
  disagreement-hitting 不能再宣称由全 oracle soundness 自动推出。若单独加入
  disagreement-hitting 作为额外组合假设，相关组合引理仍可保留。
* note 188：主定理本来已使用 target-relative near-oracle soundness；其中“由
  disagreement-hitting + smoothness 自动得到 code distance”的段落只能保留为额外
  假设下的推论，不能归因于普通 ACRR。
* note 191：共同核心信息下界是“显式 disagreement-hitting 假设”的条件定理，不能
  再称为一般 family-level ACRR 的直接后果。

## 主线含义

这项修正不会削弱 RW/JK 的单目标 ACRR 纲领；它反而把两个问题分开：

1. RW/JK 是否存在地址尺度的单目标、同一 proof、逐坐标 robust reconstruction；
2. 若要调用 RLDC/LDC 下界，如何把单目标接口提升为不泄漏消息的 target-relative
   code family。

第二步不是记号替换，而是必须单独证明的 reduction。今后所有 ACRR→LDC 声明都必须在
这三种语义中明确其量词位置。

## 证据边界

冲突定理是两行代入，不依赖 PCP、DGL 或外部下界。它只修正 family-level barrier 的
适用范围，不给出 `P != NP`，也不排除在 target-relative 或单目标模型中存在新的
coordinate-robust 构造。

## 来源

- [note 186：smooth coordinate-robust proof code](186-smooth-coordinate-robust-proof-implies-ldc-2026-08-16.md)
- [note 187：adaptive query-stability](187-adaptive-query-stability-implies-ldc-2026-08-16.md)
- [note 188：robust-near-oracle ACRR barrier](188-anti-abort-acrr-implies-relaxed-ldc-barrier-2026-08-16.md)
