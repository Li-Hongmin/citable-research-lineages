> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Near-linear decoder 仍不能闭合 RW 的递归尺度跳跃（2026-08-15）

## 命题（限定为直接 padded-hard-output 桥）

设 \(G_n:\{0,1\}^n\to\{0,1\}^{2n}\) 是一族 AVOID circuits，记

\[
S(n)=|G_n|,
\qquad
J(G_n,f)\text{ 的 hard 分支门槛为 }\Omega(S(n)\log T),
\tag{1}
\]

其中 \(f\) 的 truth-table 长度为 \(T\)。这是 Jeřábek--Korten Theorem 3.1 的
“easy circuit size \(O(S(n)\log T)\) / hard outsider”二分。

若第 \(i\) 阶段成功得到

\[
\operatorname{CC}(B_i)>cS(n_i)\log T_i,
\tag{2}
\]

并试图把 \(B_i\)（补零或忽略变量）直接当成下一阶段宽度 \(k=n_{i+1}\) 的 hard
truth table，则必须至少有

\[
S(k)\log T_{i+1}\lesssim \operatorname{CC}(B_i).
\tag{3}
\]

对 near-linear family \(S(n)=n\,\operatorname{polylog}n\)，RW 的阶段递推却要求

\[
n_{i+1}=n_i^C,
\qquad
T_{i+1}\ge T_i^{D},
\tag{4}
\]

其中 \(D>1\) 是 Theorem 4.1 的固定运行时间指数；一般只能由
\(T_{i+1}=\max\{2^{cD^{i+1}n_0},n_{i+2}\}\) 得到上式。在稳定区（取最小的 \(i_*\)
使 \(2^{cD^{i_*}n_0}\le n_{i_*+1}\)，并考察 \(i\ge i_*\)）有
\(T_i=\Theta(n_{i+1})\)，且 \(C>D+1\)。若把下一阶段宽度记为 \(k=n_{i+1}\)，则

\[
\frac{S(k)\log T_{i+1}}{S(n_i)\log T_i}
\ge
\frac{k}{n_i}\cdot\operatorname{polylog}^{-1}(n_i)
\ge
\frac{n_i^{C-1}}{\operatorname{polylog}(n_i)}
\longrightarrow\infty.
\tag{5}
\]

所以仅凭 (2) 这个已知下界，无法证明它已经跨过下一阶段 near-linear decoder 的
JK 门槛。这是“传递证据不足”，不是对实际 \(B_i\) 硬度的不可能性。把 \(k=n_{i+1}\) 压回到 \(n_i\operatorname{polylog}n_i\) 可以缓解 (5)，但
这就不再是 RW 的 \(n_{i+1}=n_i^C\) 递推；随后还必须重新满足
\(T_{i+1}\ge T_i^D\)。因此这不是把 \(G\) 从 \(n^4\) 改成 near-linear 就能消掉的
局部参数问题。

## 证明边界

式 (3) 只针对“在稳定且长度兼容区直接把 \(B_i\) 嵌入下一阶段 truth table”的桥：若 \(B_i\) 是 padded
extension，限制额外地址变量可恢复 \(B_i\)，因此 padded table 的电路复杂度至少不低于
\(B_i\)，但没有额外的 hardness 增益。若下一阶段 PCP proof 的 computation-witness 或
auxiliary bits 产生新的复杂度，可能绕过 (3)；现有 Theorem 4.3 没有给出这种内部
hardness transfer，note164 已说明其位置数量也不足以触发 capacity。

同样，令 \(f_i(x)=\pi_x(B_i)\) 的小电路 group action 至多增加
\(\operatorname{poly}(n_i)\) 的实现成本；它不会把 (2) 自动放大到 (3) 的下一尺度。
若 range 对 action 不变，整个 orbit 仍是 outsider；若不变，则 range-intersection
没有一般保证。

## 路线含义

near-linear \(G_n\) 确实把单阶段 JK 门槛从 \(n^4\) 降到约
\(n\operatorname{polylog}n)，但在 RW induction 中仍存在

\[
\text{hardness transfer at }n_i
\quad\ll\quad
\text{next-stage time/PCP threshold }T_{i+1}\ge T_i^D
\]

（decoder width is \(k=n_{i+1}\)）。

因此要继续闭合递归，必须新增一个非直接接口：

1. 对 canonical computation witness/auxiliary PCP proof 给出跨尺度 hardness transfer；或
2. 改造 Theorem 4.1，使 \(T_i^D\) 的时间支配不再要求 \(k\gg n_i\)；或
3. 放弃 JK 递归，直接构造 base-\(m\) fixed-PH/smart-prMA address coupling。

本命题不证明一般 decoder lower bound，也不推出 \(P\ne NP\)；它只关闭“near-linear
decoder 自动修复 RW 递归尺度”的直接乐观路线。

来源：Ren--Williams TR26-118 rev.1, Theorem 3.1 与 Theorem 4.3；与
[note163](163-rw-multiinput-tuple-supply-parameter-no-go-2026-08-15.md)、
[note164](164-rw-fixed-history-rm-block-supply-boundary-2026-08-15.md) 联读。
