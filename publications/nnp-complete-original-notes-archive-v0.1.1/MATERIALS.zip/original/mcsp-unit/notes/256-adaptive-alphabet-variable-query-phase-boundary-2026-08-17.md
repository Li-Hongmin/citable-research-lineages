> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Adaptive-query--alphabet phase boundary from the variable-DGL transfer (2026-08-17)

## Scope

This note combines the variable-query relaxed-DGL transfer of [note 255](255-variable-query-relaxed-dgl-theorem-2026-08-17.md) with the finite-alphabet information argument. It is a derived theorem, not a statement quoted from Dall'Agnol--Gur--Lachish (DGL): the source presents the relaxed application at constant query complexity, while the growth window below is obtained by retaining the \(Q\)- and alphabet-dependence in its proof.

The result is complementary to the GGS decision-tree phase boundary. GGS charges an adaptive verifier by the exposed \(A^r\)-node tree. The present theorem charges the same verifier by the normalized query parameter \(Q\) appearing in the DGL sampling proof, and therefore does not replace a depth-\(r\) adaptive branch by its full decision tree.

## The derived transfer hypothesis

Let \(\Sigma_k\) be a proof alphabet of size \(A_k\ge2\), write
\[
  L_k:=\log_2 A_k.
\]
For a relaxed local decoder over \(\Sigma_k\), let \(Q_k\ge2\) denote the normalized query count after the DGL error and randomness reductions. The parameterized DGL proof gives, in the growth window
\[
  W_k:=Q_k^3L_k+Q_k^2\bigl(\log_2(Q_k+2)+\log_2(L_k+2)\bigr)
       \le \eta\log_2 N_k,
\tag{256.1}
\]
for a sufficiently small constant \(\eta=\eta(\rho,\sigma_0)>0\), a shared-sample relaxed decoder with
\[
  S_k\le C\,A_k^{Q_k}\,Q_k(L_k+1)\,
  N_k^{\,1-1/(2Q_k^2)}.
\tag{256.2}
\]
The harmless factor \(Q_k(L_k+1)\) absorbs finite-alphabet support and threshold bookkeeping; omitting it only strengthens the conclusion. Equation (256.2) is precisely the finite-alphabet form of note 255 with all growth terms retained.

## Theorem (joint adaptive-query--alphabet boundary)

Let
\[
  \Pi_k:\{0,1\}^k\longrightarrow\Sigma_k^{P_k}
\]
be a common proof map. For every message coordinate \(i\) and claim bit \(b\), suppose an adaptive verifier makes at most \(r_k\) proof-symbol queries, accepts the correct claim perfectly, and accepts every wrong claim with probability at most \(1-\sigma_0\) on the target-relative \(\rho\)-ball, where \(0<\rho<1\) and \(\sigma_0>0\) are fixed. Assume both bit values occur in every nonconstant coordinate, and let \(Q_k\) be the normalized query count of the two-branch relaxed decoder.

If
\[
  P_k\le k(\log_2(k+2))^c
\tag{256.3}
\]
for infinitely many sufficiently large \(k\), then on those lengths
\[
  Q_k^3\log_2 A_k
  +Q_k^2\!\left(\log_2(Q_k+2)+\log_2\log_2(A_k+2)\right)
  =\Omega_{\rho,\sigma_0,c}(\log_2 k).
\tag{256.4}
\]

In particular, for a fixed alphabet this gives
\[
  Q_k=\Omega\!\left((\log k)^{1/3}\right),
\]
and, whenever the normalization satisfies \(Q_k=O(r_k\log(r_k+2))\),
\[
  r_k\log(r_k+2)=\Omega\!\left((\log k)^{1/3}\right).
\]
For a growing alphabet the two escape parameters are charged jointly; neither \(A_k\) nor \(Q_k\) can be suppressed from (256.4).

## Proof

Run the two claim branches in parallel and apply the fixed constant amplification that reduces the wrong-claim probability to at most \(1/3\). The resulting proof-only relaxed decoder has the same target-relative radius and a constant error. The common proof map is injective: if \(\Pi_k(m)=\Pi_k(m')\) for messages differing at a nonconstant coordinate, perfect completeness for one message contradicts wrong-claim soundness for the other at distance zero. Hence
\[
  A_k^{P_k}\ge2^k,\qquad
  P_k\ge k/L_k.
\tag{256.5}
\]

Assume, toward a contradiction, that the left-hand side of (256.4) is at most \(\eta\log k\), with \(\eta\) chosen smaller than the constant in the transfer window. Then
\[
  L_k\le \eta\log k/Q_k^3,
\]
so \(\log L_k=O(\log\log k)\), and (256.5) gives
\[
  \log P_k\ge \log k-O(\log\log k).
\tag{256.6}
\]
Thus (256.1) holds with \(N_k=P_k\) after decreasing \(\eta\), and the sample decoder (256.2) is available.

For every fixed sample tape, the decoder sees at most \(S_k\) sampled words and can be correct on at most \(A_k^{S_k}\) messages. Averaging over the sample tape gives
\[
  \frac23\,2^k\le A_k^{S_k},\qquad
  S_k\ge\frac{k-1}{L_k}.
\tag{256.7}
\]
Combining (256.2), (256.3), and (256.7), and taking logarithms, yields
\[
  \frac{\log k}{4Q_k^2}
  \le Q_kL_k
     +O_{\rho,\sigma_0,c}\!\left(\log\log k+\log(Q_k+2)+\log(L_k+2)\right).
\tag{256.8}
\]
The factor \(4\) absorbs the \(O(\log\log k)\) loss in replacing \(\log P_k\) by \(\log k\) in (256.6). Multiplying by \(4Q_k^2\) gives
\[
  \log k\le
  4Q_k^3L_k
  +O_{\rho,\sigma_0,c}\!\left(
      Q_k^2\bigl(\log\log k+\log(Q_k+2)+\log(L_k+2)\bigr)
    \right).
\tag{256.9}
\]
This contradicts the assumed \(o(\log k)\)-scale of the left-hand side in (256.4), after fixing \(\eta\) sufficiently small. Therefore (256.4) holds.
\(\square\)

## Interpretation and boundaries

1. The theorem is not an unconditional growing-alphabet theorem from the DGL paper. Its exact scope is the explicit transfer window (256.1), which is the condition under which the displayed DGL sampling proof has \(p=o(1)\), negligible kernels, and uniform Chernoff margins.
2. The result is adaptive in the original verifier depth: it uses \(Q_k\), not the \(A_k^{r_k}\) decision-tree size. Thus it can be strictly stronger than the GGS/compiler route when \(r_k\) grows while the normalized DGL query count remains sublogarithmic.
3. The theorem does not prove \(P\ne NP\), and it does not assert that every near-linear construction violates the DGL hypotheses. A construction may leave the common-proof model, lose a fixed target-relative radius or gap, or enter the complementary regime where the growth-window inequality itself is false.
4. The proof uses the proof-only relaxed decoder; no message-inline tag is needed. If an implementation insists on an inline tag, replace \(P_k\) by the total codeword length and recheck the radius separately.

## Sources

* M. Dall'Agnol, T. Gur, and O. Lachish, *A Structural Theorem for Local Algorithms with Applications to Coding, Testing, and Privacy*, ECCC TR20-154, Sections 5--7.
* [Variable-query relaxed-DGL theorem and adaptive RLDC barrier](255-variable-query-relaxed-dgl-theorem-2026-08-17.md).
* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally Decodable Codes via Robust Daisies*, Theorem 1 (for the complementary arbitrary-alphabet decision-tree route).
