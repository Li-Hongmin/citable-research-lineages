> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW PCP block provenance 不是黑箱不变量（2026-08-14）

## 结论

[note 079](079-systematic-pcp-block-preimage-accessor-barrier-2026-08-14.md) 证明：当
multi-output machine 没有 NP queries，且输出以指定 \(2q\)-bit string \(z\) 开头时，
Ren--Williams completeness proof 的第一个 Jeřábek--Korten block 恰为 \(z\)。本 note 核验该
论证能否推广到 exact stitched machine \(M_A\) 的任意实际 block。

裁决是否定的。RW TR26-118 的黑箱定理只规范 systematic prefix 中

\[
(pfx,out),
\tag{1}
\]

的位置。它没有规范 machine-to-circuit compiler、intermediate-gate ordering、
Reed--Muller coordinate bijection 或 auxiliary PCP proof serialization。因此对 output prefix
之后的一个连续 \(2q\)-bit block，诸如

\[
\text{“它来自 }A\text{ 的内部 trace”},\qquad
\text{“它来自 PCP auxiliary oracle”}
\tag{2}
\]

都不是现有 theorem statement 定义的不变量。故不能从 RW 黑箱推出：

\[
\text{exact }M_A\text{ 的每个 YES block 都有可由其语义解释的 provenance。}
\tag{3}
\]

这不否定某个完全固定的 concrete implementation 可能满足更强性质；它否定的是把该性质当作
RW theorem 的 representation-independent consequence。

## 黑箱实际固定了什么

RW Lemma 3.2 把 circuit input 明确排成

\[
hist=(y_1,\ldots,y_r,out,z_{1,1},\ldots,z_{r,t})
\tag{4}
\]

并令 \(r'=r\lceil\log(t+1)\rceil\)。因此 satisfying assignment 的前 \(r'\) bits 是 query-count
prefix，随后是 machine output。特别地，\(r=0\) 时 assignment 从 \(out\) 开始。

RW Theorem 3.4 前的定义令 CIRCUIT-SAT valid witness \(w\) 包含 satisfying assignment 和其上的
intermediate-gate values。Reed--Muller code 是 systematic；encoded-history 段进一步明确，
satisfying assignment 作为 \(\widetilde w\) 的 prefix 保留。由此得到唯一稳定的坐标结论：

\[
\Pi_x[1..r'+|out|]=(pfx,out).
\tag{5}
\]

这足以支持 note 079 的 \(r=0\) first-block embedding，也足以读取 exact \(M_A\) 的 output
coordinates。它不确定 assignment 之后的 gate values 或 \(\Pi'\) 中任意 block 的语义。

## 缺失的规范化选择

Lemma 3.2 只说 \(C_x\) 可在 deterministic poly\((t)\) 时间构造，并在 proof 中语义描述
“according to \(hist\) 模拟 \(M(x)\)”。它没有固定：

- machine model 与 machine-to-circuit compiler；
- gate basis、copy/padding gates、gate numbering；
- satisfying assignment 之后 intermediate values 的顺序。

Theorem 3.4 令 \(w\in\{0,1\}^N\) 通过一个 fixed bijection \([N]\leftrightarrow H^m\) 解释为
Reed--Muller message，但没有 canonicalize：

- finite field representation、\(H\) 的选择与顺序；
- \([N]\leftrightarrow H^m\) 的具体 bijection；
- auxiliary tables \(P\) 与 \(\Pi_{\mathrm{ZoS}}\) 的生成器和 serialization。

Theorem 3.4 的 completeness statement 是“对每个 valid \(w\)，存在
\(\Pi=(\widetilde w,\Pi')\)”，其 proof sketch 引用 Harsha 的 PCP construction。Theorem 3.5
仍只选择一个 completeness proof；Theorem 4.1 随后把该 proof 交给 JK。Theorem 3.1 会机械切分
已经给定的 proof string，却不会补足上述 representation choices。

因此一个 normalized exact-\(M_A\) block lemma 至少必须把以下 artifact 作为假设的一部分：

\[
\boxed{
\text{compiler + gate order + field encoding + RM bijection
+ PCP prover + oracle serialization}.
}
\tag{6}
\]

在这些对象固定以前，“第 \(j\) 个 block 的 provenance”不是 theorem-level mathematical object。

## SAT 语义等价也不能补足 provenance

内部 wrapper 不能改变式 (5)：只要 SAT answers 与 stitched \(out\) 相同，raw assignment 的
\((pfx,out)\) prefix 就相同。因此“让 SAT decider 在内部计算一个坏 \(z\)”不能无条件把 \(z\)
变成第一 block；这一更强说法是假的。

反方向也同样重要。在 \(P=NP\) 假设下，note 079 的 \(\operatorname{ExtBad}\) selector 可嵌入一个
extensionally correct 的 polynomial-time SAT decider wrapper，同时仍返回原 SAT bit。若额外固定一个
syntax-directed、保留 dead/copy gates 的 compiler、gate order 和 block alignment，则可让 selector
bits 出现在 intermediate-gate suffix 的某个完整 \(2q\)-bit block。优化 compiler 可以删除这些
gates、代数化简或任意重排，因此该 embedding 只反驳 implementation-invariant 的广义命题，不反驳
一个指定 compiler 下的 normalized exact-\(M_A\) lemma。

故 SAT answer function 或 stitched semantic output 都不足以决定 proof suffix；但语义等价 wrapper
本身也不足以在 RW 黑箱中强迫任意具体 suffix。

## 为什么当前不做 provenance 计算

项目、ECCC record、arXiv source 与公开代码线索中均未找到上述 concrete compiler/prover。
更重要的是，完整 PCP 不是一个可用很小 \(N\) 展开的 sanity check。Theorem 3.4 proof sketch 包含

\[
P:F^{3m+3}\to F.
\tag{7}
\]

即使乐观取 \(\alpha=1\)、\(N=4\)、\(m=2\)，field-size lower bound 已给 \(|F|\ge64\)，于是
\(P\) 有

\[
64^9=2^{54}
\tag{8}
\]

个 entries；即使每项只用一 byte，也需要约 \(16\) PiB。实际 construction 要求足够大的
\(\alpha\)，且还存在 \(\Pi_{\mathrm{ZoS}}\)。更小参数又不满足 theorem 的 asymptotic
instantiation。

可以自定义一个只生成 raw witness 与 systematic RM prefix 的 toy implementation，但它既省略
auxiliary proof，又自行选择所有恰好决定 block provenance 的 conventions。这样的实验只能检查
bookkeeping，不能支持或否证式 (3)，故现在不在 OMEN 上启动。

## 剩余的最窄接口

当前严格保留两种前进方式。

1. 只使用 theorem-level invariant：把所需 range/preimage 性质约束在 \((pfx,out)\) prefix，
   尤其是 first output block。
2. 从作者或独立形式化中取得一套完整 concrete implementation，然后把 local inversion lemma
   明确写成 implementation-specific statement。

在第二种 artifact 出现以前，研究不再把 arbitrary PCP blocks 的来源当作 exact \(M_A\) 的可用
特殊结构。该结论与 note 079 共同把剩余数学问题压缩为：

\[
\text{exact stitched output prefix 是否具有足够强的 range/preimage 结构？}
\tag{9}
\]

原文核验日期：2026-08-14。

- Hanlin Ren and Ryan Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin-Arthur Queries*, ECCC TR26-118, revision 1, 2026, Theorem 3.1, Lemma 3.2,
  Theorems 3.4, 3.5 and 4.1.
- Prahladh Harsha, *Robust PCPs of Proximity and Shorter PCPs*, PhD thesis, 2004, Section 5.

式 (1)、(4)--(5) 是 RW 原文直接支持的 prefix facts；式 (2)--(3)、(6)--(9) 是本项目对
representation freedom、可执行性与剩余接口的推论。本文不声称已经证明 \(P\ne NP\)。
