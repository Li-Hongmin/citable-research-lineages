> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact hitting duality for shared-proof coordinate robustness (2026-08-17)

## Contribution

The pathwise Lorenz theorem upper-bounds soundness by a union bound on the number of
honest reads.  The exact adaptive quantity is smaller and more structural: the maximum
probability that a corruption set intersects the honest query set.  When the relevant
corruption sets are semantically realizable by patched proofs that force a wrong output
after the first hit, this upper bound is also a lower bound.  Soundness is then exactly
the value of a hitting game.

This identifies the precise missing theorem for a shared-proof PCP: not a better
incidence estimate, but a patchability/realizability statement for error sets.

## Setup

Let \(\Pi:\{0,1\}^{k}\to\Sigma^N\) be a common proof map and let
\(\mathsf D_i\) be a randomized adaptive decoder making at most \(Q\) reads.  Assume

\[
  \mathsf D_i^{\Pi(m)}=m_i
  \qquad\text{with probability one}.
\tag{227.1}
\]

For honest randomness \(\omega\), let \(S_{m,i}(\omega)\subseteq[N]\) be the set of
distinct positions read by \(\mathsf D_i\) on \(\Pi(m)\).  For a family
\(\mathcal B_{m,i}\) of candidate corruption sets, define its hitting value

\[
  \operatorname{Hit}_{m,i}(\mathcal B_{m,i})
  :=
  \max_{B\in\mathcal B_{m,i}}
  \Pr_\omega[S_{m,i}(\omega)\cap B\ne\varnothing].
\tag{227.2}
\]

The radius-\(\rho\) universal family is
\(\mathcal B_\rho=\{B\subseteq[N]:|B|\le\lfloor\rho N\rfloor\}\).

## Upper bound: no first hit, no wrong output

For any received proof \(z\) satisfying
\(\operatorname{dist}(z,\Pi(m))\le\rho\), let
\(B=\{v:z_v\ne\Pi(m)_v\}\).  Couple the execution on \(z\) with the honest execution
using the same randomness.  Until the first query in \(B\), the transcripts and adaptive
query choices agree.  Thus

\[
  \Pr[\mathsf D_i^z\notin\{m_i,\bot\}]
  \le
  \Pr_\omega[S_{m,i}(\omega)\cap B\ne\varnothing]
  \le
  \operatorname{Hit}_{m,i}(\mathcal B_\rho).
\tag{227.3}
\]

Taking the maximum over \(m,i\), the common proof map is a perfect-complete RLDC with
soundness at most

\[
  \operatorname{Hit}_\rho
  :=
  \max_{m,i}\operatorname{Hit}_{m,i}(\mathcal B_\rho).
\tag{227.4}
\]

The pathwise Lorenz bound in note 226 follows from

\[
  \Pr[S\cap B\ne\varnothing]
  \le \mathbb E|S\cap B|
  =\sum_{v\in B}\nu(v),
\tag{227.5}
\]

and is therefore a generally looser, but efficiently summarized, upper bound.

## Lower bound: realizable first-hit forcing

Fix \(m,i\) and \(B\in\mathcal B_{m,i}\).  Suppose there is a candidate proof
\(z_{m,i,B}\) satisfying:

1. \(z_{m,i,B}\) differs from \(\Pi(m)\) only on \(B\);
2. on every random tape for which the honest query set first intersects \(B\), the
   execution on \(z_{m,i,B}\) eventually outputs \(1-m_i\) (or, more generally, does so
   with conditional probability at least \(\gamma_{m,i,B}\)).

Then every target-relative soundness guarantee \(s\) for the decoder satisfies

\[
  s\ge
  \gamma_{m,i,B}\,
  \Pr_\omega[S_{m,i}(\omega)\cap B\ne\varnothing].
\tag{227.6}
\]

Indeed, the candidate is within the target radius, and its wrong-output probability is
at least the first-hit probability times the conditional forcing probability.

### Exact duality theorem

If the above forcing condition holds with \(\gamma_{m,i,B}=1\) for every
\(m,i\) and every \(B\in\mathcal B_\rho\), then the worst-case soundness of this decoder is

\[
  s^\star=\operatorname{Hit}_\rho.
\tag{227.7}
\]

The upper inequality is (227.3), and the lower inequality follows by choosing a
\((m,i,B)\) attaining the maximum in (227.4).  For a restricted realizable family
\(\mathcal B_{m,i}\), the same statement holds with its restricted hitting value.

Thus a soundness target \(s<\operatorname{Hit}_\rho\) is possible only if at least one
high-hitting corruption set is not patchable, or if its first hit does not force a wrong
output.  This is a semantic obstruction, not an incidence or query-distribution
obstruction.

### Corollary: usage-adjusted universal-patch lower bound

Let \(t=\lfloor\rho N\rfloor\), and write

\[
  \bar q_{m,i}:=\mathbb E_\omega\lvert S_{m,i}(\omega)\rvert
  =\sum_{v=1}^{N}\Pr_\omega[v\in S_{m,i}(\omega)].
\tag{227.11}
\]

If every \(B\subseteq[N]\) with \(\lvert B\rvert\le t\) is realizable and has
first-hit forcing, then the exact duality implies

\[
  s^\star\ge
  \max_{m,i}
  \frac{t}{N}\frac{\bar q_{m,i}}{Q}.
\tag{227.12}
\]

Indeed, for fixed \((m,i)\), choose \(B\) to be the \(t\) positions with largest
inclusion probabilities.  Then

\[
  \mathbb E\lvert S_{m,i}\cap B\rvert
  \ge \frac{t}{N}\bar q_{m,i},
  \qquad
  \Pr[S_{m,i}\cap B\ne\varnothing]
  \ge \frac{\mathbb E\lvert S_{m,i}\cap B\rvert}{Q},
\tag{227.13}
\]

because every query set has size at most \(Q\).  Apply (227.6) and maximize over
\((m,i)\).  In the full-use case \(\bar q_{m,i}=Q\), this gives
\(s^\star\ge t/N=\rho-o(1)\).  Thus a positive-radius decoder with target error
strictly below the radius cannot coexist with universal first-hit patchability and
full-use honest paths.  If a decoder deliberately uses fewer than \(Q\) distinct
positions on some honest paths, (227.9) records exactly the resulting utilization loss
rather than charging the nominal query budget.

## Fractional version

Let \(\Lambda_{m,i}\) be a distribution over realizable corruption sets.  If every honest
query set \(S\) satisfies

\[
  \Pr_{B\sim\Lambda_{m,i}}[S\cap B\ne\varnothing]\ge\zeta,
\tag{227.8}
\]

and every \(B\) in the support has first-hit forcing probability one, then

\[
  s\ge\zeta.
\tag{227.9}
\]

This follows by averaging (227.6) over \(B\sim\Lambda_{m,i}\).  It is the exact
fractional-hitting form of the profile-hitting method: a proof architecture can evade a
large universal hitting value only by making the corresponding error-set distribution
non-realizable or non-forcing.

## Examples and relation to Lorenz mass

For one-query samplers, \(S=\{v\}\) and
\[
\operatorname{Hit}_\rho
=\sum_{j\le\lfloor\rho N\rfloor}\nu_{(j)}
=\mathcal L_\rho(\nu).
\]
For multi-query samplers the inequality can be strict.  If \(N=4\), the honest query
set is uniformly one of the six two-element subsets, and \(\rho=1/2\), then
\(\mathcal L_\rho=1\), while every two-element corruption set is hit with probability
\(5/6\).  The hitting functional retains the overlap information discarded by the
Lorenz union bound.

## Consequences for RW/JK and dPCP

The theorem separates the remaining route into two explicit tasks:

* To obtain a positive shared-proof construction, prove that the candidate error sets
  needed by the RW/JK wrong-claim tests are not universally patchable, or that a first
  local discrepancy does not force a wrong global output.
* To obtain a general impossibility theorem, prove a realizable-patch/forcing lemma for a
  sufficiently rich family of error sets.  Then (227.7) gives the exact soundness and
  C213/C214 supply the RLDC length barrier.

Ordinary dPCP list soundness supplies neither side: it does not provide one fixed global
proof for each patched set, and it does not imply first-hit forcing.  Conversely, a
coordinate-specific recompiled proof can make every set realizable only by abandoning
the common-address-space quantifier.

## Boundary

The exact duality is conditional on (227.6).  It is not a claim that GMWZ, RW, or
distributional soundness automatically realizes the required patch family.  It also does
not equate a local query hit with a semantic error unless the explicit forcing condition
is proved.  These are the two genuine research targets left after the incidence profile
has been optimized.

## Sources

* [Pathwise Lorenz profile](226-pathwise-lorenz-profile-adaptive-shared-proof-closure-2026-08-17.md),
  for the upper first-hit argument and RLDC consequences.
* [Profile-hitting propositions in the main paper](../../rw-jk-succinct-reconstruction/papers/Address-Scale-Barriers-for-Shared-Proof-Coordinate-Robustness/paper.md),
  for the existing fractional-hitting formulation.
