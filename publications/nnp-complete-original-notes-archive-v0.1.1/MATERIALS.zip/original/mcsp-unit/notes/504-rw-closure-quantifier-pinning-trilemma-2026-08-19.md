> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW Closure quantifier-pinning trilemma (2026-08-19)

## 本轮改变的判断

当前 RW/JK 路线的困难不是“还没有找到足够多的 selector”，而是
Closure 的量词已经被三个独立结果钉死：

1. 若一个 address evaluator 对所有 succinct seed generators 都成立，
   C429 将其归约为 \(\mathrm{EXP}\subseteq\mathrm{P/poly}\)，在 \(P=NP\)
   分支中与指数层次塌缩矛盾；
2. 若它对固定 source machine 的所有输入 \(x\) 都成立，C431 将其提升为
   \(E=P\)（在 \(P=NP\) 分支中），同样不可作为无条件 Closure；
3. 若它只依赖 JK 的 hard transcript、却对所有合法 parent \(f\) 成立，
   C503 强制 descriptor 支付 \(\Omega(T)\)。

因此剩余的正攻窗口不是“再弱化 generic evaluator”，而是一个严格的
**singleton-specific, source-specific, seed-specific** relation：
它必须固定 \(x_0\)、固定 canonical proof/seed subclass 和实际的
\(f_i(x_0)\)，并且使用 transcript 之外的全局约束；否则会落入上述三种
已关闭量词之一。

## 定理 504.1（RW Closure 量词钉死三分）

令 \(B_m\in\{0,1\}^{N_m}\) 是 Ren--Williams Theorem 4.3--4.5
产生的同一 hard table，\(N_m=2^{\Theta(m)}\)，并考虑一个声称在
\(P=NP\) 下构造 \(m^{O(1)}\)-size、single-valued、same-object address
evaluator 的 Closure 接口。若该接口满足下列任一量词扩张，则该扩张不能
成为一个一致的最终 \(P\ne NP\) 证明前提：

### (G) Generic-seed extension

接口对所有描述长度 \(m^{O(1)}\) 的 succinct seed generators \(U\) 和所有
输出地址都正确。则 C429 的 succinct circuit-value 归约给出
\[
\mathrm{EXP}\subseteq\mathrm{P/poly}.
\tag{504.1}
\]
在额外假设 \(P=NP\) 时，\(\mathrm{PH}=P\)，Karp--Lipton/Meyer
塌缩把 (504.1) 提升为 \(\mathrm{EXP}=P\)，违反确定性时间层次定理。

### (X) Source-uniform extension

接口对固定 deterministic source machine 的所有输入 \(x\) 都能在
\(P=NP\) 下访问 Theorem 3.5 canonical proof 的任意地址，且保持同一
proof/address semantics。则 C431 的 source-uniform accessor reduction
给出
\[
P=NP\Longrightarrow E=P,
\tag{504.2}
\]
同样违反时间层次定理。

### (F) Transcript-black-box extension

接口固定一个 \(G_n\)，但对每一个产生相同
\((\mathrm{hard},\mathrm{stage},\mathrm{position},y)\) transcript 的合法
parent \(f\) 都要求 exact whole-parent binding。则 C503 给出
\[
d\ge (1-o(1))T/2
\tag{504.3}
\]
的 parent-dependent descriptor 下界；若 descriptor 在 parents 间共享，则
exact binding 直接不可能。

因此，任何不落入上述矛盾或 object-scale payment 的 Closure 必须同时满足：

* source input 固定为一个 \(x_0\)（或一个严格受限的 source subclass）；
* seed/generator 固定为一个 source-compatible canonical subclass，而不是
  generic succinct seed；
* parent 固定为实际 \(f_i(x_0)\)，并由额外 source relation 证明它不是
  transcript fiber 中的任意元素；
* 所有 parent-dependent global state 都有显式地址尺度预算，不能以
  descriptor、ROM、sheet 或 strategy 名义隐藏 \(\Theta(T)\) bits。

### 证明

(G) 是 C429 的非一致 succinct universal-gate reduction；(X) 是 C431 的
source-uniform accessor reduction；(F) 是 C503 的 top-stage transcript
fiber injectivity。三者的前提量词互不相容，但每一支都覆盖一个自然的
“把 published Reconf 变成 Closure”尝试。排除三支后，剩余接口必须同时
违反三支中的至少一个泛化量词，故得到上述四条 singleton-specific 条件。
\(\square\)

## 这一定理真正关闭什么

定理 504.1 不是把 actual singleton 也宣称为不可能。它关闭的是路线选择：

\[
\begin{array}{c}
\text{generic seed evaluator}\\
\text{source-uniform evaluator}\\
\text{transcript-only family binder}
\end{array}
\quad\Longrightarrow\quad
\text{不能作为最终 Closure}.
\]

因此，下一项正攻必须给出一个同时满足 same-proof、whole-word、address-scale
和 \(P=NP\)-smartness 的**新 source relation**。例如，若某个 relation
能从 \(f_i(x_0)\) 的 canonical history 直接生成每个地址的输出，而不暴露
全 parent 或 family descriptor，则它不被 504.1 的三支自动排除；但该 relation
本身必须成为新的独立定理，不能从 ordinary list soundness、JK hard child
或 Reconf 逐位 smartness 直接推出。

定理 504.1 是一个 Closure-program classification，不是 \(P\ne NP\) 证明，
也不是一般 dPCP/RLDC impossibility theorem。

## 来源

* [C429 / note 430](430-nonuniform-succinct-universal-gate-boundary-2026-08-19.md).
* [C431 / note 432](432-source-uniform-actual-rw-accessor-barrier-2026-08-19.md).
* [C503](503-jk-black-box-transcript-binding-impossibility-2026-08-19.md).
* Ren--Williams TR26-118 rev.1, Theorems 3.1, 4.1, 4.3--4.5.
