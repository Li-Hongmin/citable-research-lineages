> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定 (P:q_s+p_s=0) separator 的八轨道闭合（2026-08-13）

## 结论

设 \(X,Y\subseteq\mathbb F_2^N\) 且 \(X\cap Y=\varnothing\)，
\(s=(x_s,y_s)\in X\times Y\)。令 \(\mathcal F\) 是关于固定 spoiler
\(s\) 的两两相交极小 collision-witness 族，并假设所有
\(T\in\mathcal F\) 的 affine 参数支持
都满足同一个 \(P\)-separator

\[
q_s(z)+p_s(z)=0.
\tag{1}
\]

把行列 thinning 等价地写成：先独立均匀取全局
\(U\subseteq X,V\subseteq Y\)，再使用

\[
R_z(U,V)=(U\cap A_z)\times(V\cap B_z),
\qquad
A_z=\{x:q_xz=0\},\quad B_z=\{y:p_yz=1\}.
\tag{2}
\]

则

\[
\boxed{\Pr_{z,U,V}[\exists T\in\mathcal F:T\subseteq R_z(U,V)]\le 1/16.}
\tag{3}
\]

这个结论不要求 witness 为连通 star；多组件 star forest 亦适用，事实上只用到
两两 cell 相交与公共 \(P\)-separator。

## 八轨道

令 \(\delta=(0,1)\in\mathbb F_2^{N+1}\)，并记
\(z^\delta=z+\delta\)。由于最后坐标翻转，

\[
A_{z^\delta}=X\setminus A_z,
\qquad B_{z^\delta}=Y\setminus B_z,
\tag{4}
\]

而 \(q_s+p_s\) 的线性形式最后坐标为 \(0\)，故

\[
z\text{ 满足 (1)}\Longleftrightarrow z^\delta\text{ 满足 (1)}.
\tag{5}
\]

固定一个 \(z\)（满足 (1)）和全局 \(U,V\)。考虑以下八个样本：

\[
\begin{array}{ll}
z:&(U,V),\ (U\triangle A_z,V),\ (U,V\triangle B_z),\
   &(U\triangle A_z,V\triangle B_z);\\[2mm]
z^\delta:&(U,V),\ (U\triangle A_{z^\delta},V),\ (U,V\triangle B_{z^\delta}),\
   &(U\triangle A_{z^\delta},V\triangle B_{z^\delta}).
\end{array}
\tag{6}
\]

这里 \(\triangle\) 是对称差。严格地说，(6) 的每个变换都是
\(\Omega_P=\{(z,U,V):q_s(z)+p_s(z)=0\}\) 上的测度保持双射：前四个在每个
\(z\)-纤维内对 \(U,V\) 作对称差；后四个先把 \(z\) 换成 \(z^\delta\)，再在目标
纤维对 \(U,V\) 作对称差。因此不需要假设八元组给出自由群轨道。对固定 \(z\)，
前四个对应矩形的行侧分别在
\(U\cap A_z\) 或其补集内、列侧分别在 \(V\cap B_z\) 或其补集内，故任意
两个不同样本至少在行或列上不交。对后四个样本同理。跨两组时，(4) 给出

\[
(U\cap A_z)\cap(U'\cap A_{z^\delta})=\varnothing
\]

（其中 \(U'\) 是 \(U\) 或 \(U\triangle A_{z^\delta}\)），故矩形仍在行侧不交。
因此八个矩形两两 cell-disjoint。两两相交的 \(\mathcal F\) 至多在八个样本中的
一个样本上命中。

令 \(I\) 为命中事件的指示函数。上述八个双射使八项变换后的指示函数期望都等于
\(\Pr[I=1\mid P]\)，而逐点和至多 \(1\)，故

\[
8\Pr[I=1\mid P]\le1.
\tag{7}
\]

若某一组的 \(A_z\) 或 \(B_z\) 为空，则该组四个矩形全空，对命中事件的贡献为
零；因此不影响上述轨道计数。非空时八个作用确实给出互不相交的矩形。

于是，在 \(P\)-支持内

\[
\Pr_{z,U,V}[E\mid q_s+p_s=0]\le 1/8.
\tag{8}
\]

由于 \(q_s+p_s\) 是非零线性形式，支持 (1) 恰占参数空间的一半，故由 (8)

\[
\Pr[E]\le \frac12\cdot\frac18=\frac1{16}.
\]

## 边界与含义

关键是 \(P\)-separator 在 \(t\mapsto t+1\) 下保持不变；相同八轨道对
(R:q_s=1) 或 (C:p_s=0) 不成立，因为该翻转把支持送到非活跃状态。
故固定 (R/C) 仍需额外的 affine 参数配对，不能把本结论误读为一般
“固定单 separator”闭合；一个可检验的 R/C 充分条件见
[note 060](060-fixed-RC-separator-affine-complement-criterion-2026-08-13.md)。
