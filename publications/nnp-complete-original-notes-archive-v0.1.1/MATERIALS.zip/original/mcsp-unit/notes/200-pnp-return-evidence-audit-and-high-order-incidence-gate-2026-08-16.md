> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# P&NP 回流报告吸收与高阶 incidence 主定理门（2026-08-16）

## 结论地位

本文件是对 `[unbundled local reference]` 的合并吸收记录，
不是把回流报告的阶段编号、实验计数或云端写入声明晋级为项目事实。报告的战略判断与
当前项目方向一致：内部 note 数量不是贡献指标，真正的目标是可独立发表的新 PCP/coding、
Range-Avoidance/circuit 定理，或一般不可能性定理。

## 已吸收的战略内容

1. **主问题升级。** 项目 headline 固定为：一个近线性 dPCP/PCPP 是否能在同一个
   global proof 和同一个地址空间内，对所有 output coordinates 同时实现 target binding
   与常数 soundness；否则是否必然付出 RLDC/LDC 型长度、locality 或编码代价。
2. **distributional soundness 只作为机制候选。** 它必须额外给出 singleton target、
   同一 proof/strategy 的 word consistency，以及 RW/JK 地址尺度；平均或 list soundness
   本身不算完成。
3. **固定局部解压器路线降为条件性 benchmark。** 若有 poly(n)-key、全地址 evaluator
   和固定 PH/随机性量词，确实可得到相应的复杂度包含或搜索上界；但这不是当前
   GMWZ/RW 的已证接口，也不能把全表 `FP^NP` 搜索冒称为 base-address 结果。

## 原始来源核验后的硬边界

Gur--Minzer--Weissenberg--Zheng 的 Theorem 2.9 明确给出的是：

* (X(1)\leftrightarrow X(i)) inclusion graph 的第二奇异值；
* 局部 link expansion；
* ((k,\sqrt{k})) direct-product test 的 soundness。

其 Section 6 的 dPCP 采用共享顶层 face、共享 (\sqrt{k})-face、再选两个 (k)-faces
的抽样，并给出 list-decoding soundness 与 agnostic complete decoding distribution。
这些条目没有直接给出本项目 C176 所需的 (X(k)\leftrightarrow X(\sqrt{k})) L2 incidence
profile，也没有把 agnostic 量词升级成 arbitrary right labels 的 event-wise smoothness。

这不是文字上的小缺口：Bafna--Minzer 的 direct-product testing 结果明确指出，低
soundness direct-product testing 不能只由 spectral expansion 推出，还需要
Unique-Games coboundary expansion。因此下一步不能把“有 X(1)-level spectrum”或“有
direct-product test”静默换成高阶 incidence mixing。

## 唯一 source-specific 主定理分叉

令 (s=\sqrt{k})，令

\[
 p_i(B)=\Pr[A\in U_i\mid B],\qquad \mu_i=\Pr[A\in U_i].
\]

当前 C176 已证明：若

\[
 \mathbb E_B[(p_i(B)-\mu_i)^2]\le \eta^2\mu_i,
\]

且 (X(1)\leftrightarrow X(s)) 的谱控制 disagreement-avoiding mass，那么任意单一
right label 都产生显式 projection collision。因而真正的主定理目标只有两个互斥方向：

* **正向：** 从 GMWZ 所用 HDX 的 coboundary/direct-product 结构证明所需的高阶 L2
  incidence profile，并将 C176 提升为 arbitrary-right-label patch closure；
* **反向：** 在保持 GMWZ Theorem 2.9 条件的复形中构造 profile 失败的两簇/右标签，
  从而得到一个 source-specific unique-decoding separation。

若两条都不能在明确参数窗口内推进，则停止增加具体 decoder 障碍；这时应把结果写成
“spectral expansion 与 high-order target binding 的精确分界”，而不是继续扩写局部反例。

## 比 raw profile 更锋利的下一实验：DPT variance dichotomy

对一个簇 (U\subseteq X(k))，令 (T_U[A]) 在 (A\in U) 时为全 1 向量、否则为全
0 向量。对共享 (s)-face (B)，设 (p(B)=\Pr[A\in U\mid B])，则该常值表的
direct-product 一致性概率严格等于

\[
 \operatorname{Acc}(T_U)=\mathbb E_B[p(B)^2+(1-p(B))^2]
 =1-2\mu(1-\mu)+2\operatorname{Var}(p(B)).
\]

因此高阶 incidence 的 L2 偏差不是一个与 DPT 无关的抽象参数：它正是簇常值表的
一致性 excess。对 GMWZ 的重簇质量窗口，下一项高价值实验是证明一个**定量二分**：

* variance 小时，直接使用 C176 的 arbitrary-right-label collision gate；
* variance 大时，调用 GMWZ 的 ((k,\sqrt{k}))-DPT，从常值表提取一个近似 vertex
  word，再把近似误差传入 C175/C176 的 collision 估计。

这里仍有真实缺口：DPT 的定义只保证在给定 acceptance 下有一个 global word 在一部分
面上近似，而不是自动给出两个簇各自的重质量、精确公共标签或坐标级误差。因此这是一条
新的 theorem target（“DPT-to-patch dichotomy”），不是把 DPT soundness 误报成 C176
所需的 L2 profile；若无法完成重质量提取，仍回到 profile 反例分支。

### Tagged-table interface（可证部分）

给两个 disjoint clusters (U_0,U_1) 及其 global labels (f_0,f_1)，在增大的字母表中
把 (T[A]) 写成带 tag 的 ((0,f_0|_A)) 或 ((1,f_1|_A))。对补集使用一个
GMWZ Lemma 6.3 型的 pairwise anti-agreement table (T^star)：相交两面在每个共同顶点
都不相同，并让第三个 tag 与 0、1 分离。则对共享 (B) 的两次 (k)-face 抽样，tagged
DPT 的 acceptance 恰为

\[
 \mathbb E_B[p_0(B)^2+p_1(B)^2].
\]

这是一个严格的接口：若该值至少为 (\alpha)，DPT soundness 给出某个单一 global
tagged word 在至少 (\kappa(\alpha)) 的面质量上近似 (T)；anti-agreement 部分至多
贡献 (\theta)，故至少 (\kappa(\alpha)-\theta) 的质量来自两个真实簇，并由同一个
global label 解释。若进一步有一个**双簇质量提取条件**，保证这部分质量在 (U_0,U_1)
两侧各自都为正，则把 tag 投影成 vertex partition、把 label 投影成 (H)，即可进入
C175 的公共 vertex-word collision gate；若 variance 小，则直接进入 C176。

目前未证明的正是粗体条件：DPT 定义只给总质量下界，可能把全部近似质量集中在一个
簇上。因而不能把上述接口写成 GMWZ 已有的 simultaneous coordinate robustness；它把
缺口精确压成“两个重簇的共同 global tag 提取”，这是值得继续攻击的单一 lemma。

## 未晋级的回流主张

以下内容暂不写入 claims 或主定理：

* “稀疏 Shannon 边界”的精确常数/Theta 定理；需要逐条回到 Lupanov、计数下界及其
  适用模型，回流文本本身不提供自足证明。
* 固定解压器 `Range(D)` 的统一 PH-local 反演、`NP⊆P/poly` 后的多输出电路大小，
  以及由此推出的复杂性分离；这些只能作为条件模型，不能替代当前 source-specific
  GMWZ/RW 证明。
* 回流报告列出的穷举次数、哈希、Drive 回写状态；它们是外部报告元数据，不是数学证据。

## 证据来源

* GMWZ, *3-Query RLDCs are Strictly Stronger than 3-Query LDCs*, Theorem 2.9、
  Definition 2.7--2.8、Theorem 6.1：
  <https://arxiv.org/html/2512.12960>
* Bafna--Minzer, *Characterizing Direct Product Testing via Coboundary Expansion*：
  <https://arxiv.org/abs/2308.09668>
* 回流候选文件（仅作待核验输入）：
  `[unbundled local reference]`
