> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Pair-language PCPP resolves projection semantics, not shared ACRR (2026-08-16)

## 已核验的正面事实

对关系 `R(x,y,w)` 定义 pair language
\[
  L_R=\{(x,y):\exists w\;R(x,y,w)\},
  \qquad L_R(x)=\{y:(x,y)\in L_R\}.
\]
标准 pair-language PCPP 的 verifier 收到显式 `x`、随机访问的隐式 `y` 和 proof
`π`；若 `y` 属于 `L_R(x)`，存在 proof 完美接受；若 `y` 距 `L_R(x)` 至少 `δ`，
任意 proof 的接受概率小于 `1/2`。已有通用定理给出常数查询，但 proof 长度是
计算时间 `t` 的多项式，verifier 的运行时间是 `poly(|x|,log t,1/δ)`。

这说明“公开输出 + 私有 witness”在语义上不是不可定义的；note 177 的障碍必须
表述为参数/共享障碍，而不是存在性障碍。

## 命题：pair-language PCPP 不自动给 ACRR

设 `f_x` 是 singleton 输出。将上述 PCPP 应用于 `L_R`，最多得到：对每个公开词
`y`，一个依赖 `(x,y)` 的 proof `π_{x,y}`。这不能推出 ACRR 所需的单一 proof
`Π_x`，因为对不同坐标/声明位，候选词不同：

\[
  \pi_{x,f_x},\quad
  \pi_{x,y^{(i,0)}},\quad
  \pi_{x,y^{(i,1)}}
\]

一般是不同的 proof，且 PCPP 的完备性/ soundness 没有给出它们可嵌入同一个
address space 的 word-consistent 映射。

若把所有 `k` 个坐标声明一次性拼成一个 oracle
\(Y=(y^{(1,0)},y^{(1,1)},\ldots,y^{(k,1)})\)，通用 pair PCPP 的输入长度已经
是 `Theta(k·ell)`，proof 长度变成该计算规模的多项式；这会物化坐标批次，不能作为
RW 的 `poly(n,log T)` 地址-scale interface。

因此，pair-language PCPP 给出的是

\[
  \text{private-witness semantics}
  \quad\not\Rightarrow\quad
  \text{single global proof + simultaneous coordinate robustness}.
\]

## 参数缺口的精确形式

ACRR 需要一个新的 **shared pair-PCPP**：

1. 固定 `x` 只生成一个 proof `Π_x`；
2. `y`/声明位只作为局部 oracle 或 decoder target，不改变 proof address space；
3. 对每个坐标 `i` 与 bit `b`，同一个 `Π_x` 完备地证明 `f_x[i]=b`（正确时），
   并对错误 `b` 给常数 soundness；
4. proof 长度近线性，verifier 只依赖 `poly(|x|,log ell)` 地址信息。

通用 pair-language PCPP 的 proof 依赖 `(x,y)`，所以没有满足第 1–2 条；其 `poly(t)`
proof 也没有满足第 4 条。GM 的近线性 `SAT(φ)`-PCPP 改善了长度，但输入词仍是
完整 SAT assignment，并没有自动补上 shared pair-PCPP 的量词。

## 可发表的双向程序

这把主定理压缩成两个可检验命题：

- **正向：** 构造 shared pair-PCPP，并证明它能由 GM/dPCP 或 distributional
  soundness 组合；这是一个独立的 PCP theorem。
- **反向：** 在“固定 proof、公共地址空间、所有 pair targets 共用 proof”的模型中，
  证明 shared pair-PCPP 必须付出超线性长度，或归约到 RLDC/LDC 的已知下界。

只有逐坐标重新运行通用 pair-PCPP、或把所有声明拼成一个巨大 oracle，不能算完成这
个目标。

## 证据边界

- pair-language PCPP 的定义和通用 `poly(t)` 构造直接见 [2024/599, Def. 3.3 and
  Thm. 3.4](https://eprint.iacr.org/2024/599.pdf)。
- GM 的近线性定理直接针对 `SAT(φ)` 完整输入词，见
  [Theorem 1.7](https://arxiv.org/html/2512.12960)。
- “不自动共享 proof”是由两者量词/输入依赖直接推导出的本项目边界，不是文献已声明
  的 impossibility theorem。
