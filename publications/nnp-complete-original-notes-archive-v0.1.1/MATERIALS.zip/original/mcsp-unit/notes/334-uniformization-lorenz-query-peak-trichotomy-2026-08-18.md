> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Transcript uniformization versus pathwise Lorenz mass (2026-08-18)

## Contribution

This note combines two previously separate closure mechanisms. C333 says that a
connected near-proof neighborhood with small transcript information can avoid a
single global word only by putting a constant amount of transcript mass on one
changed proof position. C226/C320 say that a common proof with low pathwise query
concentration becomes a relaxed local decoder and therefore cannot have near-linear
length at sufficiently low locality. The combination gives a single peak--Lorenz--
locality trichotomy.

The statement is conditional on the same target-relative and common-address
quantifiers as those two ingredients. It does not claim that the current RW or GMWZ
construction supplies them.

## Theorem (uniformization--Lorenz query-peak trichotomy)

Fix constants \(0<\rho<1\) and \(c\ge0\). Let

\[
  \Pi_k:\{0,1\}^k\longrightarrow\Sigma^{N_k},
  \qquad N_k\le k(\log(k+2))^c,
\tag{334.1}
\]

be a common proof map with adaptive decoders of depth at most \(r_k\). Let
\(\mathcal Z_k\) be a Hamming-connected family of target-relative near proofs.
The honest proof states used by the pathwise Lorenz argument need not be vertices of
this graph; they are included separately in the peak parameter below.
Assume the C333 transcript setup on \(\mathcal Z_k\): there is a fixed coordinate
marginal \(\lambda_k\), a separated valid-word family \(\mathcal Y_k\), and
parameters \(\varepsilon_k,\iota_k\) such that

\[
  \alpha_k:=\varepsilon_k+
  \sqrt{\frac{\ln 2}{2}\,\iota_k},
  \qquad
  \delta_k:=\Delta_{\lambda_k}(\mathcal Y_k)-2\alpha_k>0.
\tag{334.2}
\]

For \(z\in\mathcal Z_k\) and proof position \(p\), let

\[
  h_k^{\mathrm{nbhd}}:=
  \max_{z\in\mathcal Z_k}\max_{p\in[N_k]}
  \Pr[\text{the decoder queries }p\text{ on }z].
\]
Let \(h_k^{\mathrm{hon}}\) be the same maximum over all honest proof states
\(\Pi_k(m)\), and put
\[
  h_k:=\max\{h_k^{\mathrm{nbhd}},h_k^{\mathrm{hon}}\}.
\tag{334.3}
\]

Assume that whenever C333 produces a common word on \(\mathcal Z_k\), a
target-binding map identifies it with the same common proof object \(\Pi_k\), and
the resulting message decoders have honest-path error at most \(\epsilon_k\).
Assume also that the source-audited variable-query DGL closure applies to this
common-proof family in the form of C320: for some
\(\eta=\eta(\rho,c)>0\),

\[
  \epsilon_k+\Lambda_{\rho,k}\le\frac1{12}
  \quad\Longrightarrow\quad
  r_k\log(r_k+2)\ge\eta(\log(k+2))^{1/3},
\tag{334.4}
\]

where \(\Lambda_{\rho,k}\) is the pathwise Lorenz mass.

Then, for all sufficiently large \(k\), at least one of the following holds:

\[
\begin{array}{ll}
{\rm (P)} & h_k\ge\delta_k,\\[1mm]
{\rm (L)} & \epsilon_k+\rho N_k r_k h_k>\dfrac1{12},\\[1mm]
{\rm (Q)} & r_k\log(r_k+2)\ge\eta(\log(k+2))^{1/3},
\end{array}
\tag{334.5}
\]

or one of the C333 transcript, separation, or target-binding hypotheses fails.

Equivalently, in the low-locality regime where (Q) is false, every surviving
construction must either expose the query peak (P), or pay the pathwise Lorenz
mass in (L).

## Proof

Suppose (P) fails, so \(h_k<\delta_k\). The contrapositive part of C333 then gives
one common valid word throughout \(\mathcal Z_k\). By the target-binding hypothesis,
this is a common proof map for the message decoders, so the pathwise Lorenz closure
of C226 applies.

For a fixed honest message and coordinate, let \(\nu(v)\) be the expected number of
occurrences of proof position \(v\) in the adaptive honest transcript. The probability
that \(v\) is queried is at most \(h_k\), and the transcript has at most \(r_k\)
query steps; hence

\[
  \nu(v)\le r_k h_k
  \qquad (v\in[N_k]).
\tag{334.6}
\]

Summing the largest \(\lfloor\rho N_k\rfloor\) coordinates gives

\[
  \Lambda_{\rho,k}\le \rho N_k r_k h_k.
\tag{334.7}
\]

If (L) also fails, then
\(\epsilon_k+\Lambda_{\rho,k}\le1/12\) by (334.7). C320/C226 now force (Q), a
contradiction. Therefore, when both (P) and (Q) fail, (L) must hold.
\(\square\)

## Patchability upgrade

The peak alternative has a direct source-specific interpretation. Suppose the
first-hit patchability condition of C333 holds with target error bound
\(\beta_k\) and forcing constant \(\gamma_k>0\). If

\[
  \beta_k<\gamma_k\delta_k,
\tag{334.8}
\]

then the no-common-word branch is impossible. Consequently, under (334.8), a
near-linear construction in the low-locality regime must satisfy (L), unless it
leaves the C333 target-binding model:

\[
  \epsilon_k+\rho N_k r_k h_k>\frac1{12}
  \quad\text{or}\quad
  r_k\log(r_k+2)\ge\eta(\log(k+2))^{1/3}.
\tag{334.9}
\]

Thus a successful coordinate-robust construction cannot hide the remaining
uniformity failure in a single high-incidence proof position if that position is
semantically patchable. It must instead concentrate enough honest query mass to
defeat the Lorenz closure, pay growing locality, or abandon the common-word
interface.

## Code-image specialization

The target-binding hypothesis is automatic in the canonical code-image model.
Suppose the valid-word family in C333 is chosen to be

\[
  \mathcal Y_k=\mathcal C_k:=\operatorname{Im}(\Pi_k)
  =\{\Pi_k(m):m\in\{0,1\}^k\}.
\tag{334.10}
\]

Then the common word \(y^\star\) produced by C333 is, by definition,
\(\Pi_k(m^\star)\) for some message \(m^\star\). If \(\Pi_k\) is injective,
this message is unique; uniqueness is not needed for the Lorenz argument.
Therefore the trichotomy above applies without a separate target-binding assumption:
the only remaining alternatives are the C333 transcript/separation hypotheses,
(P), (L), and (Q). In particular, under first-hit patchability with
\(\beta_k<\gamma_k\delta_k\), the code-image specialization yields

\[
  h_k<\delta_k
  \ \text{and}
  \epsilon_k+\rho N_k r_k h_k\le\frac1{12}
  \quad\Longrightarrow\quad
  r_k\log(r_k+2)\ge\eta(\rho,c)(\log(k+2))^{1/3},
\tag{334.11}
\]

unless the connected-neighborhood transcript or separation hypothesis fails.
Thus target-binding is a genuine extra issue only when the dPCP supplies a
larger valid-word family than the actual proof-code image.

## Coding-scale collapse of the peak branch

There is a second simplification in the actual coding regime. Suppose that
\(\Pi_k\) is injective, \(A_k:=|\Sigma_k|\ge2\), and assume \(r_k\ge1\).
Injectivity gives

\[
  A_k^{N_k}\ge 2^k,
  \qquad\text{hence}\qquad
  N_k\ge\frac{k}{\log_2 A_k}.
\tag{334.12}
\]

Consequently, whenever

\[
  \frac{\rho\,\delta_k\,k}{\log_2 A_k}>\frac1{12}
\tag{334.13}
\]

holds, the peak alternative (P) implies the Lorenz alternative (L):

\[
  h_k\ge\delta_k
  \quad\Longrightarrow\quad
  \rho N_k r_k h_k>\frac1{12}.
\tag{334.14}
\]

In particular, if \(\delta_k\ge\delta_0>0\) and
\(\log A_k=o(k)\) (including every fixed proof alphabet), then (334.13)
holds for all sufficiently large \(k\). In this coding-scale regime, the
trichotomy does not need first-hit patchability for its length/locality
conclusion: either the C333 transcript/separation hypotheses fail, or (L)
holds, or (Q) holds. First-hit patchability remains useful only if one wants
to turn the peak itself into a direct semantic wrong-output lower bound.

## Scope and boundary

The estimate (334.6) uses only total honest hit probability and does not assume a
per-step \(\chi/N\) smoothness bound. It is therefore weaker in its hypotheses than
C321, while C333 supplies the missing semantic alternative when the peak is not
small.

The theorem is not an unconditional dPCP lower bound. In particular, ordinary
list/distributional soundness may fail to provide the C333 mutual-information,
fixed-marginal, or target-binding assumptions; and a high query peak may be
semantically harmless unless the first-hit patchability condition is proved. The
result identifies the exact remaining source-specific experiment rather than
silently assuming it.

## Sources

* C333, [connected-neighborhood transcript uniformization](333-connected-neighborhood-transcript-uniformization-2026-08-18.md).
* C226, [pathwise Lorenz profile](226-pathwise-lorenz-profile-adaptive-shared-proof-closure-2026-08-17.md).
* C320/C321, [adaptive smoothness-to-Lorenz near-linear gate](321-adaptive-smoothness-to-lorenz-near-linear-gate-2026-08-18.md).
* Dall'Agnol--Gur--Lachish, TR20-154, and the source-audited variable-query transfer used
  in C320.
