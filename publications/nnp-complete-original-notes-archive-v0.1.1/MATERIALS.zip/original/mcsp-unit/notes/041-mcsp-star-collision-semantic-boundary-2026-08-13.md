> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# MCSP 的 star collision：语义方向约束与单叶负平均反例

## 1. 语义先排除一个方向

令真值表长度为 \(N=2^n\)，

\[
E_a=\{x:\operatorname{CC}(x)\le a\},
\qquad
NO_b=\{y:\operatorname{CC}(y)>b\}.
\]

若四个 cell \(c_i=(x_i,y_i)\) 存在 odd--odd affine collision

\[
\bigoplus_{i\in I}x_i=\bigoplus_{j\in J}y_j,
\qquad
|I|,|J|\ {\rm odd},\quad I\cap J=\varnothing,
\tag{1}
\]

且 \(|J|=1\)，则对应的高复杂度端点满足

\[
y_j=\bigoplus_{i\in I}x_i.
\tag{2}
\]

一个 \(p\)-输入 XOR 可以由 \(p\) 个大小-\(a\) 电路和 \(O(p\log N)\) 个连接实现，故

\[
\operatorname{CC}(y_j)\le |I|a+O(|I|\log N).
\tag{3}
\]

在本项目的参数区间 \(b\gg a+\log N\) 下，(3) 与 \(y_j\in NO_b\) 矛盾。

因此所有四 cell odd collision 中，**高复杂度侧的 odd 支持不能是 singleton**。四点情形只可能保留

\[
|I|=1,\qquad |J|=3,
\tag{4}
\]

即一个低复杂度 \(x\) 等于三个高复杂度 \(y\) 的 XOR。这个方向约束是真正使用 \(NO_b\) 语义的跨-\(z\) 引理。

## 2. 该语义约束并不保证正的单叶势

下面构造满足 (4) 的最小反例族。取

\[
x=0\in E_a.
\]

选 \(y_1,y_2\) 为线性独立的随机真值表，令

\[
y_3=y_1\oplus y_2,
\]

再选 \(y_4\notin\operatorname{span}\{y_1,y_2\}\)。由

\[
|E_b|\le 2^{O(b\log(b+\log N))}=2^{o(N)}
\]

及随机抽样，\(y_1,y_2,y_3,y_4\) 可以同时属于 \(NO_b\)，且彼此不同；坏样本比例为 \(o(1)\)。

令

\[
H=\{(0,y_1),(0,y_2),(0,y_3),(0,y_4)\}.
\tag{5}
\]

则

\[
0=y_1\oplus y_2\oplus y_3
\]

是一个 row-singleton/column-triple odd collision。由于四个 \(y_i\) 彼此不同且 \(y_4\notin\operatorname{span}\{y_1,y_2\}\)，不存在另一个 column-singleton collision。

## 3. 精确 affine-leaf 平均

固定方向 \(t=0\)，取

\[
\ell_{r,b}(z)=\langle r,z\rangle\oplus b,
\qquad(r,b)\in\mathbb F_2^N\times\mathbb F_2,
\]

并令

\[
R_{r,b}
=\{(u,v):\ell_{r,b}(u)=0,\ \ell_{r,b}(v)=1\}.
\]

因为所有 \(H\) 的 row 都是 \(0\)，当 \(b=1\) 时叶为空；当 \(b=0\) 时，四个 cell 的命中模式为

\[
(\langle r,y_1\rangle,\langle r,y_2\rangle,
\langle r,y_1\oplus y_2\rangle,\langle r,y_4\rangle)
=(a,b,a\oplus b,c).
\]

由 \(y_1,y_2,y_4\) 线性独立，\((a,b,c)\) 在 \(\mathbb F_2^3\) 上均匀。于是：

\[
\Pr_{r,b}[|H\cap R_{r,b}|=1]=\frac1{16},
\qquad
\Pr_{r,b}[|H\cap R_{r,b}|=3]=\frac3{16},
\]

且 \(\Pr[|H\cap R|=4]=0\)。所以对

\[
g(0),g(1),g(2),g(3),g(4)=(0,1,0,-1,0)
\]

有

\[
\boxed{
\mathbb E_{r,b}g(|H\cap R_{r,b}|)
=-\frac18.}
\tag{6}
\]

等价地，在 \(2^{N+1}\) 个 affine forms 上

\[
q_1-q_3=-2^{N-2}.
\]

这严格反驳了：

\[
\text{“NO}_b\text{ 的完整语义}
\Longrightarrow
\text{每个四点碰撞势的单叶平均非负”。}
\]

## 4. 对下一步的含义

语义目前给出的最强四点方向约束是 (4)，但 (5)--(6) 说明它不足以关闭 symmetric \(g\) 势。于是：

\[
\boxed{
\text{single-separator / 单个 collision 的平均分析已经到边界。}}
\]

必须研究跨多个 \(H\) 的全局约束，例如：

\[
\begin{array}{c}
\text{同一 }x\text{ 的 star 超边族的总权重}\\
\downarrow\\
\text{多个 }x\in E_a\text{ 之间的 XOR 碰撞闭包}\\
\downarrow\\
\text{是否强迫一个 }y\text{ 落入低复杂度集。}
\end{array}
\]

单个 star 可有负平均，但只给一个 row restriction；要达到 \(N^{1.01}\)，必须证明大量 star 的权重无法独立叠加，或者构造能利用这种叠加的递归势。

## 5. 严格状态

已证明：

- \(NO_b\) 禁止四点 collision 的高侧 singleton；
- 该方向约束仍允许 row-singleton/column-triple star；
- star 给出 symmetric \(g\) 的严格负单叶平均。

尚未证明：

- star 族的全局 quasi-additive 目标是否仍至多 \(O(N)\)；
- 不同低复杂度 \(x\) 的碰撞闭包是否能触发低复杂度高侧端点。

这两个问题比 affine-kernel rank 更接近 MCSP 语义，也是当前合理的下一原子接口。
