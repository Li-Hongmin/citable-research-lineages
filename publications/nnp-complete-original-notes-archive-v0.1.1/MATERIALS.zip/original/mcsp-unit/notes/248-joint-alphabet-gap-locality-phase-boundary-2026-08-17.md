> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Joint alphabet--gap--locality phase boundary (2026-08-17)

## Contribution

The growing-alphabet theorem and the vanishing-gap theorem are two projections of
one parameterized obstruction.  After amplifying a correct-versus-wrong branch
gap \(\gamma_k\), the relevant locality is not the original \(r_k\) but the
decision-tree depth

\[
 R_k=O\!\left(\frac{r_k}{\gamma_k^2}\right).
\]

For an \(A_k\)-ary proof alphabet, exposing both adaptive branch trees therefore
creates

\[
 Q_k=1+2\sum_{j=0}^{R_k-1}A_k^j
\]

non-adaptive queries.  The arbitrary-alphabet RLDC bound then gives a single
necessary budget for all three escape parameters.  This also corrects the
previously overstated \(\log k/\log\log k\) factor in note 245: in the binary
case the direct consequence is a \(\log\log k\) threshold for
\(r_k/\gamma_k^2\).

## Theorem

Fix \(0<\rho<1\) and \(c>0\).  For each \(k\), let \(\Sigma_k\) be an alphabet
of size \(A_k\ge2\), and let

\[
 \Pi_k:\{0,1\}^k\longrightarrow\Sigma_k^{P_k}.
\]

For every message coordinate \(i\) and claim \(b\), let \(V_{i,b}\) be a
randomized adaptive verifier making at most \(r_k\ge1\) proof-symbol queries.
Write \(p_{i,b}(z)\) for its acceptance probability.  Assume that, uniformly
over messages \(m\), coordinates \(i\), and proof words \(z\),

\[
 p_{i,m_i}(\Pi_k(m))\ge\alpha_k,
 \qquad
 d_H(z,\Pi_k(m))\le\rho P_k
 \Longrightarrow
 p_{i,1-m_i}(z)\le\beta_k,
\tag{248.1}
\]

where \(\gamma_k:=\alpha_k-\beta_k>0\).  Assume the branch randomness can
be independently resampled.

Let \(C_0\) be a sufficiently large absolute constant, set

\[
 t_k:=\left\lceil C_0\gamma_k^{-2}\right\rceil,\qquad
 R_k:=t_k r_k,\qquad
 Q_k:=1+2\sum_{j=0}^{R_k-1}A_k^j,
\tag{248.2}
\]

and

\[
 \Lambda_k:=1+\log\log(k+2)+\log\log(A_k+2).
\tag{248.3}
\]

If \(N_k:=k+P_k\le k(\log k)^c\) for infinitely many sufficiently large
lengths, then

\[
 Q_k\Lambda_k=\Omega_{\rho,c}(\log k).
\tag{248.4}
\]

All logarithms are base two.  The constants in the \(\Omega\)-term are
independent of \(A_k,r_k,\alpha_k,\beta_k\).

## Proof

### 1. Image distance and the tagged radius

If two distinct messages \(m,m'\) had proof words at distance at most
\(\rho P_k\), choose \(i\) with \(m_i\ne m'_i\).  Completeness for \(m\)
and soundness for target \(m'\), applied to \(z=\Pi_k(m)\), would give

\[
 \alpha_k
 \le p_{i,m_i}(\Pi_k(m))
 =p_{i,1-m'_i}(\Pi_k(m))
 \le\beta_k,
\]

contradicting \(\gamma_k>0\).  Thus the proof image has symbol distance
greater than \(\rho P_k\).  The \(A_k\)-ary Singleton bound gives

\[
 k\le\bigl((1-\rho)P_k+1\bigr)\log A_k.
\tag{248.5}
\]

If \(\log A_k\ge k/2\), then (248.4) is immediate because
\(Q_k\ge3\) and \(\log\log(A_k+2)=\Omega(\log k)\).  Otherwise
\[
 \frac{P_k}{N_k}\ge
 \frac{1}{1+2(1-\rho)\log A_k}.
\]
Use the tagged alphabet
\[
 \Gamma_k=\{(I,0),(I,1)\}\sqcup\{(P,a):a\in\Sigma_k\}
\]
and the tagged radius
\[
 \delta_{0,k}:=
 \frac{\rho}{2\bigl(1+2(1-\rho)\log A_k\bigr)}.
\tag{248.6}
\]
Invalid inline or proof tags make the decoder output \(\bot\).  A tagged word
within radius \(\delta_{0,k}\) with valid tags has proof suffix within
\(\rho P_k\) of \(\Pi_k(m)\).

### 2. Amplification and decision-tree expansion

Repeat each branch \(t_k\) times on fresh random tapes and accept the
amplified branch when its empirical acceptance exceeds a threshold strictly
between \(\beta_k\) and \(\alpha_k\).  Hoeffding's inequality and the choice
of \(C_0\) give, on the exact proof, correct-branch acceptance at least \(2/3\),
while on every proof covered by (248.1), wrong-branch acceptance is at most
\(1/3\).  The amplified branch has adaptive depth at most \(R_k\).

The tagged inline decoder reads the inline bit, runs the amplified branch
selected by that bit, outputs the bit if the branch accepts, and otherwise
outputs \(\bot\).  It is therefore a binary-message RLDC over the alphabet
\(\Gamma_k\) with radius \(\delta_{0,k}\), completeness \(2/3\), and
wrong-output probability at most \(1/3\).

For a fixed random tape, each branch is an \(A_k\)-ary decision tree of depth
\(R_k\), with at most \(\sum_{j<R_k}A_k^j\) query nodes.  Querying the inline
symbol and the union of both branch trees produces a non-adaptive decoder with
at most \(Q_k\) queries and exactly the same output distribution.

### 3. Apply the arbitrary-alphabet RLDC bound

If \(Q_k>N_k\), then \(Q_k\Lambda_k\ge N_k\ge k\), so (248.4) is trivial.
Assume otherwise.  Suppose for contradiction that
\[
 Q_k\Lambda_k\le\eta\log k
\tag{248.7}
\]
for a sufficiently small constant \(\eta=\eta(\rho,c)\).  As in the
Singleton calculation,
\[
 \log(1/\delta_{0,k})=O_\rho\!\bigl(1+\log\log(A_k+2)\bigr)
 =O_\rho(\Lambda_k).
\]
Equation (248.7) implies
\[
 \frac{(2/3)\log N_k}{2Q_k}
 \ge \frac{\Lambda_k}{3\eta},
\]
so \(\delta_{0,k}>N_k^{-(2/3)/(2Q_k)}\) for small enough \(\eta\).

The arbitrary-alphabet theorem of Goldberg--Gur--Saraogi, applied with
\(q=Q_k\), message length \(k\), block length \(N_k\), and alphabet
\(|\Gamma_k|=A_k+2\), gives
\[
 N_k\ge
 \left(
 \frac{(2/3)^2 k}
 {38Q_k^4(2/3)^{-2}\log^2(A_k+2)\log^2 k}
 \right)^{1+1/\lceil 3Q_k/2\rceil}.
\tag{248.8}
\]
Under (248.7), the logarithm of the denominator in (248.8) is
\(O(\Lambda_k)\).  Taking logarithms and using
\(N_k\le k(\log k)^c\) yields
\[
 \frac{\log k}{\lceil3Q_k/2\rceil}
 \le O_{\rho,c}(\Lambda_k).
\tag{248.9}
\]
But \(\lceil3Q_k/2\rceil\le2Q_k\), so (248.7) gives the reverse bound
\[
 \frac{\log k}{\lceil3Q_k/2\rceil}
 \ge \frac{\Lambda_k}{2\eta},
\]
which contradicts (248.9) for sufficiently small \(\eta\).  This proves
(248.4). \(\square\)

## Binary and fixed-gap corollaries

For \(A_k=2\),
\[
 Q_k=2^{R_k+1}-1,\qquad
 R_k=\Theta\!\left(\frac{r_k}{\gamma_k^2}\right),
\]
and \(\Lambda_k=\Theta(\log\log k)\).  Hence (248.4) gives the precise
threshold
\[
 \frac{r_k}{\gamma_k^2}
 \ge
 \log_2\log k-\log_2\log\log k-O_{\rho,c}(1).
\tag{248.10}
\]
This is the corrected form of note 245.  In particular, fixed \(r_k\) can
survive this barrier only if
\(\gamma_k=O(1/\sqrt{\log\log k})\).

If the alphabet and gap are both bounded below by constants, (248.10) reduces
to the growing-locality threshold \(r_k=\Omega(\log\log k)\).  If the gap is
constant but the alphabet grows, (248.4) reduces to the growing-alphabet
boundary in note 247.

## Scope

The theorem is a parameterized application of the arbitrary-alphabet RLDC
lower bound, not a new coding lower-bound proof.  Its value is the joint
phase diagram: an attempted near-linear shared-proof construction cannot
simultaneously keep alphabet scale, amplified branch locality, and
correct-versus-wrong gap below the budget in (248.4).  The theorem leaves open
only the boundary regimes where at least one of those quantities pays the
required cost, or where independent branch resampling and a single common
proof address space fail.

## Source

* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for Relaxed
  Locally Decodable Codes via Robust Daisies*, Theorem 1:
  <https://arxiv.org/html/2511.21659>.
* [Growing-alphabet/locality phase boundary](247-growing-alphabet-locality-phase-boundary-2026-08-17.md).
* [Corrected vanishing-gap boundary](245-vanishing-branch-gap-locality-phase-boundary-2026-08-17.md).
