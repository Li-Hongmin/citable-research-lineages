> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW closure trichotomy: forcing-scale advice versus family RLDC cost (2026-08-17)

## Contribution

The conditional Closure Theorem and the recent RLDC phase diagram control two
apparently different failure modes.  The former is a single-target,
`P/poly` contradiction; the latter applies only after a common proof has been
lifted to a target-relative family.  The following proposition puts the two
interfaces in one theorem-level trichotomy.  It is a derived composition of the
ROM-advice lemma and the adaptive-to-nonadaptive RLDC compilation; it is not a
claim that the RW construction already satisfies either positive interface.

## Proposition (forcing--RLDC closure trichotomy)

Let (H_nin{0,1}^{N_n}) be the canonical object produced by a fixed RW/JK
construction on an infinite set of lengths, and suppose

\[
  \operatorname{CC}(H_n)>S_n.
\tag{261.1}
\]

Assume that a proposed reconstruction has an address evaluator with one common
proof/strategy and one static descriptor (sigma_n) of length (d_n).  Its
finite control has size (p_n), uses at most (p_n) random-access reads from
(sigma_n), and after the relevant (P=NP) (or fixed-PH) collapse it computes
(H_n[a]) for every address (ain[N_n]).  Then, for every (n), at least one
of the following branches holds.

1. **Forcing-scale descriptor cost.**

   \[
     p_n^2+p_nd_n+p_n\log N_n=\Omega(S_n).
   \tag{261.2}
   \]

   In particular, if (p_n,log N_n=n^{O(1)}) and (S_n) dominates every
   polynomial, then (d_n) is superpolynomial.  A polynomial-size static
   descriptor cannot close the single-target RW contradiction.

2. **Family lift and RLDC cost.**  The same proof/address space extends to a
   target-relative family of (k_n)-bit messages, with perfect completeness,
   radius (ho>0), binary proof alphabet, adaptive branch depth (r_n), and
   target-relative error at most (1-sigma_n), where the resulting inline
   length is (N_n).  Writing

   \[
     Q_n=2^{r_n+1}-1,
     \qquad a_n=\left\lceil Q_n/\sigma_n\right\rceil,
     \qquad
     D_n=\frac{38Q_n^4\log^2 2\,\log^2 k_n}{\sigma_n^2},
   \]

   whenever the GGS radius condition and (D_n<k_n) hold,

   \[
     \frac1{a_n}
     \le
     \varepsilon_n+
     \left(1+\frac1{a_n}\right)
     \frac{\log D_n}{\log k_n},
     \qquad
     N_n\le k_n^{1+\varepsilon_n}.
   \tag{261.3}
   \]

   Thus a near-linear family lift cannot keep both bounded locality and a
   fixed positive target gap; the surviving locality must obey the quantitative
   length--locality tradeoff of note 260.

3. **No certified family lift.** The proposed reconstruction does not satisfy
   at least one of the hypotheses needed in branch 2: common target-relative
   proof semantics, same address space, all-message completeness, a positive
   radius, or the incidence/smoothness conditions needed to turn the proof map
   into an RLDC.  This is not a free escape: it is the exact missing Gate-I/II
   statement that must be proved or upgraded to a general impossibility theorem.

The branches are exhaustive as a proof audit: branch 1 is forced whenever the
single-target evaluator exists, branch 2 is forced whenever the family lift is
actually established, and otherwise branch 3 records the missing quantifier or
parameter rather than silently treating a family theorem as a single-target
one.

## Proof

For branch 1, expand the finite control and replace each read of the fixed
descriptor by a (d_n)-input multiplexer.  The resulting ordinary fan-in-two
circuit has size

\[
  O(p_n^2+p_nd_n+p_n\log N_n),
\]

where the last term accounts for address generation and wiring.  It computes
(H_n), so (261.1) implies (261.2).  Under (P=NP), the assumed smart
queries are deterministic polynomial-time queries; hardwiring the length-(n)
descriptor gives the corresponding (P/mathrm{poly}) circuit.  Notice that
uniform generation of (sigma_n) is not used.

For branch 2, the common proof map supplies a weak RLDC after the standard
message-inline construction.  An adaptive depth-(r_n) binary decoder is
compiled by exposing both branch trees, giving (Q_n=2^{r_n+1}-1) proof
queries.  Applying the arbitrary nonadaptive RLDC lower bound of
Goldberg--Gur--Saraogi to the resulting code gives

\[
  N_n\ge
  \left(\frac{k_n}{D_n}\right)^{1+1/a_n}.
\]

Taking logarithms and using (N_n\le k_n^{1+\varepsilon_n}) yields (261.3).
The only nontrivial semantic requirement is the family lift itself: a
single-target proof or a per-coordinate recompiled proof does not supply this
branch.  If that requirement is absent, the audit remains in branch 3.
\(\square\)

## Consequences for the RW program

The proposition gives a concrete closure test for a proposed RW-specific
construction.

* A short common key does not evade forcing: if it really supports every
  address after (P=NP), (261.2) turns the forcing lower bound into a direct
  descriptor lower bound.
* A genuinely family-level coordinate-robust proof cannot be judged only by
  the single-target Closure Theorem.  It must pass (261.3), and hence pay the
  length--locality cost from note 260 (or leave its binary/positive-radius
  hypotheses).
* A construction that is neither a short single-target evaluator nor a
  certified family lift has not yet closed the route.  Its missing item must be
  named explicitly: bottom handling, cover-sheet binding, target descriptor,
  common proof quantifiers, radius/gap, or incidence/smoothness.

For the current GMWZ source, the private coordinate-specific PCPP blocks fall
in branch 3 until a cross-coordinate synthesis map is supplied; if one insists
on preserving those private blocks, note 259 gives the direct-sum proof-length
cost.  This does not prove a general shared-proof impossibility.  Conversely,
the family field-lift compiler of note 218 enters branch 2 once its incidence
and smoothness hypotheses are verified, while note 260 then supplies the
explicit exponent/locality boundary.

## Scope

This trichotomy is a closure theorem for the stated models, not a proof of
(P\ne NP), not a general lower bound for arbitrary PCPs, and not a claim that
ordinary distributional/list soundness supplies branch 2.  The unresolved
mathematical question is whether the actual RW canonical history can satisfy
branch 1 with polynomial descriptor cost while avoiding the family hypotheses in
branch 2, or whether a general theorem forces it into one of those two costs.

## Sources

* [RW succinct smart reconstruction Closure Theorem](204-rw-succinct-smart-reconstruction-closure-theorem-2026-08-17.md).
* [RW forcing-scale advice lower bound](220-rw-forcing-scale-advice-lower-bound-2026-08-17.md).
* [Incidence-stable field lift forces an RLDC](218-incidence-stable-field-lift-dpcp-forces-rldc-2026-08-17.md).
* [Length--locality exponent tradeoff](260-length-locality-exponent-tradeoff-2026-08-17.md).
* [GMWZ private-block direct-sum barrier](259-gmwz-private-block-direct-sum-barrier-2026-08-17.md).
* Goldberg--Gur--Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally Decodable Codes via Robust Daisies*, Theorem 1, <https://arxiv.org/abs/2511.21659>.
