> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 用小电路 witness 直接替换 RW/Reconf 的 \(q\)-bit preimage 会失败（2026-08-15）

## 动机

Ren--Williams Theorem 4.1 的 Reconf 已经在 AVOID 失败分支上给出
smart-\(\mathrm{prMA}\) reconstruction，但其 query/witness 尺度含有 AVOID 输入长度
\(q\)。一个最直接的压缩想法是：把 Jeřábek--Korten 的
\[
\exists u\in\{0,1\}^{q}\quad G_q(u)=z
\tag{1}
\]
替换为“存在一个 \(m=\log_2(2q)\) 变量的小电路 \(C\)，其 truth table 是 \(u\)”。
本 note 证明：对 tree-rich range，这个替换在信息上对大多数 blocks 都不完备。

## Succinct-preimage 谓词

固定
\[
G_q:\{0,1\}^{q}\to\{0,1\}^{2q},
\qquad q=2^{m-1},
\]
以及一个有限 fan-in-two basis。对预算 \(a\)，定义
\[
\operatorname{SRange}_{q,a}(z)
\iff
\exists C:\{0,1\}^{m-1}\to\{0,1\}
\quad
|C|\le a\ \land\ G_q(\operatorname{TT}(C))=z.
\tag{2}
\]

这正是“用 size-\(a\) 的随机访问 circuit 代替 \(q\)-bit seed witness”的最宽泛
语义版本；它不要求 \(C\) 是 canonical，也不要求不同 occurrences 共享同一个
circuit。

## Tree-rich blocks 上的容量定理

令 \(A\subseteq\operatorname{Range}(G_q)\)，\(|A|=M\)，并考虑 note 120 的深度
\(j\) witness forest。假设前 \(j\) 层没有 non-range parent，则 root blocks 的集合
\(Z_j\) 有
\[
K=M^{2^j}
\tag{3}
\]
个 distinct elements。由于每个 seed truth table 只能由一个 \(\operatorname{TT}(C)\)
产生一个 \(G_q\)-output，而 size-\(a\) seed circuits 的数量满足
\[
\log_2|\mathsf{Seed}_{m,a}|
\le C_0a\log_2(a+m+2),
\tag{4}
\]
得到
\[
\bigl|\{z\in Z_j:\operatorname{SRange}_{q,a}(z)\}\bigr|
\le
2^{C_0a\log_2(a+m+2)}.
\tag{5}
\]

因此，对任意固定 \(0<\rho<1\)，若 \(a_\rho\) 满足
\[
C_0a_\rho\log_2(a_\rho+m+2)\le\log_2(\rho K),
\tag{6}
\]
则至少 \((1-\rho)K\) 个 root blocks 不满足
\(\operatorname{SRange}_{q,a_\rho}\)。这允许每个 occurrence 自己选 circuit，
所以不是 canonicality 造成的障碍；随机化也不能增加低复杂度 seed 的总容量，因为
固定 random tape 后仍只是一个 size-\(a+O(1)\) seed circuit（见 note 120 式
(4g)）。

在 coverage family
\[
\log_2 M=\Theta(s\log s),
\qquad
s=\frac{q}{\log^{1+\varepsilon}q},
\tag{7}
\]
并取
\[
2^j s\log s=\Theta(q),
\tag{8}
\]
式 (6) 给出
\[
a_{1/2}=\Omega(q/\log q)=\Omega(2^m/m).
\tag{9}
\]
所以把 \(q\)-bit preimage witness 直接换成 \(m^{O(1)}\)-size circuit，只能覆盖
tree-rich root set 的至多
\[
2^{O(\operatorname{poly}(m)\log m)}
\]
个 blocks，而不是其中固定比例。

## 对 Reconf 压缩路线的精确含义

这个结果排除的是以下**通用替换**：

\[
\text{q-bit range witness}
\quad\Longrightarrow\quad
\text{poly}(m)\text{-size seed-accessor witness}.
\tag{10}
\]

它不排除 Ren--Williams 对实际 PCP history 使用的另一个可能性：query circuit
可以证明一个 PCP proof 的低度数/consistency 性质，而不显式给出
\(\operatorname{TT}(C)\) 作为 \(G_q\) 的 preimage。要在地址尺度得到
Local-JK smart interface，至少必须采取以下一种新结构：

1. 证明实际 RW blocks 落在一个比 tree-rich \(Z_j\) 小得多、且每个 block 有
   \(m^{O(1)}\)-size preimage accessor 的结构化子族；
2. 用 PCP/低度数关系直接验证 range membership，而不把 preimage 逐位表示成
   一个小 seed circuit；
3. 改变 JK 的 reduction，使其只需要一个可验证的 algebraic certificate，而不是
   \(G_q(u)=z\) 的完整 witness。

原始 Theorem 4.1 的 Merlin circuit 是 PCP proof 的 circuit，大小为
\(q^{O(1)}\)；它不能仅凭“proof 可随机访问”自动降为式 (2) 中的
\(m^{O(1)}\) seed circuit。反过来，式 (5)--(9) 也不证明实际 RW history 是
tree-rich；若没有这类 richness，当前计数不能对具体 history 施加下界。

## 结论边界

\[
\boxed{
\text{generic succinct-preimage substitution is incomplete;}
\quad
\text{RW-specific algebraic/PCP compression remains open.}
}
\tag{11}
\]

这一步把“把 Reconf 的 witness 变短”拆成两个不同问题：
小电路能否表示某个 preimage（式 (2)），以及 PCP consistency 是否能在不表示
preimage 的情况下直接完成。前者在 tree-rich range 上已被式 (5)--(9) 排除；
后者才是仍可能改变 \(P\) vs \(NP\) 决策的真正结构性路线。

## 来源与证据边界

- Ren--Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin--Arthur Queries*, ECCC TR26-118 revision 1, Theorems 3.1, 4.1
  ([official report](https://eccc.weizmann.ac.il/report/2026/118/revision/1/download))：
  给出原始 \(q\)-scale Reconf/PCP 接口。
- note 120：式 (1)、(4a)--(4g) 的 seed counting、quantile 与 randomized-selector
  strengthening。

本 note 不声称 generic decoder 的一般 lower bound，也不声称已经证明
\(P\ne NP\)；它只排除一种具体而自然的 succinct-witness 编译。
