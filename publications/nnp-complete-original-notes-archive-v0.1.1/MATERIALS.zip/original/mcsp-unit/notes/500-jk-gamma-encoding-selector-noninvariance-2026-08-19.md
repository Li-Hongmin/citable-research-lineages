> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK Γ phase is encoding/selector dependent (2026-08-19)

## 本轮改变的判断

C499 确实删除了 canonical lift 的 collision 分支，但它把下一个问题压成
\(|\Gamma_{d+1}|\) 的下界。这个数量不是 range 或输出长度的不变量：它依赖于
fixed-length circuit encoding、invalid-description 处理以及 canonical selector 的具体规则。
因此，在这些数据没有固定之前，不能把“对 published truth-table generator 证明
\(|\Gamma_{d+1}|\) 足够大”当作已定义的下一个定理。

Ren--Williams TR26-118 的 Section 4.2 只说，对 \(n=2^k\)，\(G_n\) 的 input 是“用 \(n\)
bits 描述的 \((k+1)\)-input circuit”，output 是它的 \(2n\)-bit truth table。这对
Theorem 4.3--4.5 的 range avoidance 已经足够，但不足以确定 C497 中的 \(\Gamma_d\)。

## 定理 500.1（range-preserving \(\Gamma\)-phase non-invariance）

There are P-uniform generator families with the same input/output lengths, the same
range, and linear-size generator circuits, but with exponentially different canonical
lift profiles.

Take \(n=2m\) (and in particular \(m=2^{k-1}\) when \(n=2^k\)). For a two-bit local
input, define

\[
\begin{array}{c|cccc}
u&00&01&10&11\\ \hline
g_A(u)&0000&0000&1000&1001\\
g_B(u)&1000&0000&0000&1001
\end{array}
\tag{500.1}
\]

Write each local output as \(L_iR_i\) with \(|L_i|=|R_i|=2\). For
\(u=(u^{(1)},\ldots,u^{(m)})\), define

\[
G_X(u):=L_1\cdots L_mR_1\cdots R_m,
\qquad X\in\{A,B\},
\tag{500.2}
\]
where \(L_iR_i=g_X(u^{(i)})\). Then \(G_X:\{0,1\}^{n}\to\{0,1\}^{2n}\) is
P-uniform and has circuit size \(O(n)\). Both families have exactly the same range:

\[
\operatorname{Range}(G_A)=\operatorname{Range}(G_B),
\tag{500.3}
\]

because both local ranges are \(\{0000,1000,1001\}\), and the global map only
concatenates the local left and right halves. In fact \(G_B=G_A\circ\pi\) for a fixed
four-point permutation \(\pi\), applied independently to every local block; this is a
P-uniform recoding of the input labels, not a change of the output range.

Let \(p_X\) be the lexicographically smallest right inverse and let \(\Gamma_d^X\) be
the C497 sets. The local canonical representatives are

\[
S_A=\{00,10,11\},\qquad S_B=\{00,01,11\}.
\tag{500.4}
\]

Because the fibers are products and the input order is block-lexicographic,
\(\Gamma_0^X=S_X^m\). A local representative contributes to \(\Gamma_1\) exactly when
both of its two output halves belong to \(S_X\). For \(A\), the representatives
\(00\mapsto0000\) and \(10\mapsto1000\) qualify, while \(11\mapsto1001\) does not.
For \(B\), only \(01\mapsto0000\) qualifies. Hence

\[
|\Gamma_0^A|=|\Gamma_0^B|=3^m,
\qquad
|\Gamma_1^A|=2^m=2^{n/2},
\qquad
|\Gamma_1^B|=1.
\tag{500.5}
\]

Moreover \(\Gamma_1^B\) consists of the single all-\(01\) input. Its image has both
halves equal to \(0^n\), while \(0^n\notin\Gamma_1^B\), so

\[
\Gamma_2^B=\varnothing.
\tag{500.6}
\]

For \(A\), the qualifying local states \(00,10\) are stable under the same test, so
\(|\Gamma_d^A|=2^m\) for every \(d\ge1\). This proves the claimed asymptotic
separation while preserving the full output range.

## 证明与证据边界

The product description gives (500.3) and the product formula for \(\Gamma_0\). The
three local checks listed above give (500.5); the image of the unique \(B\)-state gives
(500.6). The maps are implemented by a constant-size local lookup followed by
concatenation, hence are P-uniform with size \(O(n)\subseteq O(n^4)\).

This is a generator/recoding theorem, not a claim that either toy family is the
Ren--Williams truth-table generator. Its force is narrower and precise: the hypotheses
“P-uniform, \(\{0,1\}^n\to\{0,1\}^{2n}\), size at most \(n^4\), and a given range” do not
determine the C497 phase. The published RW lower bound does not need this phase, so the
observation does not challenge Theorems 4.3--4.5.

## 对 Closure program 的直接影响

1. **C499 remains valid.** Canonical lifts are injective once \(G\) and \(p\) are fixed;
   the new result concerns the size of the domain on which the lift can be iterated.
2. **The next gate is an encoding-normalization gate.** To seek a published-generator
   lower bound on \(|\Gamma_{d+1}|\), first specify the exact circuit encoding, the map for
   invalid strings, and the selector tie-break. Then prove an image-specific structural
   property of that encoding, or prove that the property is invariant under all allowed
   recodings.
3. **A range-only closure theorem cannot use C497's \(\Gamma\)-payment.** Any such theorem
   must replace \(|\Gamma_d|\) by a recoding-invariant quantity, or explicitly charge the
   encoding/selector as part of the common descriptor.
4. The cheapest discriminating next observation is therefore finite: fix one concrete
   encoding used by the published generator and compute the first nontrivial \(\Gamma_1\)
   and \(\Gamma_2\) profiles. Until that is done, a claimed asymptotic \(\Gamma\)-lower bound
   remains an ungrounded assumption rather than a Closure theorem.

This note does not prove a published-generator impossibility, a universal dPCP/LDC
lower bound, or \(P\ne NP\). It closes only the unjustified jump from C499's
generator-independent injectivity to an encoding-free lower bound on \(|\Gamma_d|\).

## 来源

* Ren--Williams, ECCC TR26-118 revision 1, Section 4.2 and the paragraph defining the
  truth-table generator before Lemma 4.4; local extraction:
  'units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md'.
* [C499](499-jk-canonical-lift-injectivity-eliminates-collision-branch-2026-08-19.md).
* [C497](497-jk-canonical-liftable-range-projection-barrier-2026-08-19.md).
