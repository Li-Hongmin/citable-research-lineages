> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW fixed-machine cell-time unrolling gives an offset-regular \(\widehat C\) evaluator（2026-08-19）

## 本轮改变的判断

C443 的 offset-regular 假设不是空泛的：对一个固定有限状态、局部转移的
deterministic machine，可以选择 cell-time、track-major 的变量布局，使每类局部
gate 的三个变量索引都是同一 base address 加固定偏移。若输出检查使用同样
offset-friendly 的串行 AND reduction，则整个零轮 circuit 的 Harsha relation
\(C'\) 落入 C443，因而 generic-point \(\widehat C\) 有 address-scale exact evaluator。

这仍然是一个新的 source representation lemma。RW Lemma 3.2 只给出
poly\((t)\)-time 可构造的 \(C_x\)，没有规定该布局；任意输入字符串、任意
wire permutation 或未压缩的 machine description 都会退出本结论。

## 定理 444.1（cell-time offset-regular unrolling）

令 \(M\) 是固定的 deterministic multi-tape finite-state machine，使用常数大小的
alphabet、state set 和固定 fan-in Boolean basis。给定时间上界 \(T\)，在带有常数
padding cells 的 \(W=O(T+|x|)\) 宽度 configuration tableau 上，按
cell-time、track-major 顺序编号所有局部状态变量：

\[
  I_{\rho}(\tau,c)=\rho L+\tau W+c,\qquad
  0\le \tau\le T,\quad 0\le c<W,\quad L=(T+1)W .
\tag{444.1}
\]

则存在一个语义等价的 fan-in-two circuit \(S_{M,T,x}\)，其 gate relation 的支持
可去重地分解为常数个 offset-regular 族。每个局部 gate family 取
\(z=\tau W+c\) 为 base address，三个变量索引具有形式

\[
  I_{\rho_j}(\tau+\Delta_{\tau,j},c+\Delta_{c,j})
  =\rho_jL+z+\Delta_{\tau,j}W+\Delta_{c,j}
  =z+\delta_j ,
\tag{444.2}
\]

其中 \(\rho_j,\Delta_{\tau,j},\Delta_{c,j}\) 只由 gate type 决定；合法的
\((\tau,c)\) 区间由常数个半开区间给出。初始、边界和最终输出约束也只增加常数个
相同类型的族，前提是它们的固定数据由 address-succinct/regular source 生成。

若把 out 变量放在一个连续 track，并用连续 equality gates 加一个串行
fan-in-two AND chain 检查所有 output bits，则得到的零轮
\(C^{\mathrm{cell}}_{x_0}\) 满足 C443 的条件。因而在
\(R,s,|H|=\operatorname{poly}(m)\) 的 Harsha 参数下，其
\(\widehat C\) 在任意 generic field point 可由
\(\operatorname{poly}(m)=\operatorname{poly}(\log N)\) 大小的 evaluator 精确计算。

### 证明

有限状态 machine 的一次局部更新只读取有限个相邻 cell、有限个相邻 time
layer 和有限个 track。把该固定局部 Boolean function 编译为常数大小的
fan-in-two gate gadget；每个 gadget gate 的三个变量都对应某个
\((\rho_j,\tau+\Delta_{\tau,j},c+\Delta_{c,j})\)。代入 (444.1) 即得 (444.2)。

在两端加入固定 padding cells 后，所有局部邻接地址都保持在合法范围内；因此
每种 \((\Delta_{\tau,j},\Delta_{c,j})\) 的合法 base set 是常数个区间。初始
configuration、padding 和 final-output copy 同样由有限种局部 pattern 描述。
固定 gate gadget 的非法 Boolean patterns 只有常数多个，按 gate type 分族后可
去重。输出 equality block 的两个变量 track 都按 bit index 连续编号；串行
AND 的 accumulator、前一 accumulator 和当前 equality wire 的编号差也是常数，
故仍是 offset family。最后应用定理 443.2。证毕。

## 对 RW closure 的精确含义

在 \(P=NP\) zero-round branch，若 Lemma 3.2 的 deterministic machine 被明确选为
上述固定有限状态 machine 的 cell-time unrolling，且 RW 的输入取
\(x_0=0^{n_0}\)（或更一般的 regular/address-succinct source），则 C444 将 C439
所需的 generic-point \(\widehat C\) evaluator 从假设升级为一个已证明的
representation-level evaluator。C442 的 equality block 也能并入；为保持
offset-regular，本文使用串行 AND chain，而不是自动假设 heap-numbered
balanced tree。

但 C444 不提供：

1. published RW Lemma 3.2 所承诺的任意 \(C_x\) 都采用该 serialization；
2. arbitrary \(x\) 的输入 bits、任意 P-uniform circuit description 或 machine-code
   table 的 address-scale regularity；
3. 同一 proof serialization 上 auxiliary \(P=p(q)\) 的 field-symbol evaluator；
4. 因此也不单独推出 C439 的 \(P/\mathrm{poly}\) collapse 或 \(P\ne NP\)。

## 停止条件

若 fixed RW source 不能公开承诺 track-major tableau、regular source data 和
offset-friendly output reduction，则 C444 只保留为一个可迁移的 representation
lemma，不继续把它写成 published RW closure。下一项真正的 Gate-I 问题随即只剩
\(P=p(q)\) 段的 same-serialization address-scale evaluator。

## 来源

* Ren--Williams TR26-118 revision 1, Lemma 3.2；本地抽取：
  units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md。
* [note 439](439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md)。
* [note 440](440-harsha-constraint-extension-source-interface-barrier-2026-08-19.md)。
* [note 443](443-offset-regular-harsha-generic-evaluator-2026-08-19.md)。
