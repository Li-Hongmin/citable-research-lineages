> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# ACRR 到 Cheng--Li--Mao 结构化 PCPP 的量词分离（2026-08-18）

## 本轮判定

本轮只判断一个桥接命题：标准的 common-proof、target-relative ACRR，是否可以
黑箱地转成 Cheng--Li--Mao（以下简称 C--L--M）Theorem 7.1 所需的结构化 3-query
PCPP，从而自动得到二次级 proof-length 下界。

结论是否定的。可以写出一个精确的**条件桥**，但 ACRR 的通常假设并不提供其中
最关键的 far-input/all-proof 量词；此外还缺少三路均匀边缘、C--L--M 所需的极小
soundness，以及 hidden-witness 投影的统一生成。因而不能把“ACRR 有共同 proof”
改名为“已经进入 C--L--M 结构化 PCPP”。

## C--L--M 的源定理边界

C--L--M Theorem 7.1（arXiv:2603.03717，源文第 7 节）考虑电路
\(\varphi:\Sigma_0^n\to\{0,1\}\)，令
\(L=\operatorname{SAT}(\varphi)\)，且 \(|\varphi|=N\)。一个 3-query PCPP 的
每条超边写成

\[
e=(t,a,b)\in X\times A\times B,
\]

并要求在边分布 \(P\) 下，\(t\)、\(a\)、\(b\) 的三个边缘分别在
\(X,A,B\) 上均匀。若输入词 \(w:X\to\Sigma_0\) 与 \(L\) 的所有词都
\(\eta\)-远，则对**任意**扩展 \(T:X\cup A\cup B\to\Sigma\)，有

\[
\Pr_{(t,a,b)\sim P}
  [\Phi_{t,a,b}(T(t),T(a),T(b))=1]
\le \delta,
\qquad \delta=|\Sigma|^{-3}/16.
\tag{369.1}
\]

在固定字母表和固定正参数下，C--L--M 得到

\[
\ell\ge \frac{N^2}{\operatorname{polylog}N}.
\tag{369.2}
\]

这里的“任意 \(T\)”不是 target-relative near-proof；它是对一个 far input 的
全体 proof assignments 的 all-proof soundness。

## 条件桥：何时 ACRR 确实落入 Theorem 7.1

设 \(\Pi:M\to\Sigma^P\) 是一个 common proof map。要从它得到 C--L--M
结构化 PCPP，必须额外给出下列 **CLM-lift** 数据：

1. 有一个显式输入域 \(X\)、语言 \(L=\operatorname{SAT}(\varphi)\subseteq
   \Sigma_0^X\)，以及一个统一构造的电路 \(\varphi\)；\(M\) 必须与该语言的
   输入词对齐，而不是只作为隐藏 witness 的投影像出现。
2. 每个 ACRR 的局部调用可在不增加查询数的情况下写成一条
   \(X\times A\times B\) 超边：一个输入位置、一个 \(A\)-proof 位置和一个
   \(B\)-proof 位置。边分布的三个边缘必须精确均匀；自适应调用必须先有一个
   保持 3-query 的非自适应化定理。
3. 对每个 \(x\in L\)，存在一个扩展 \(T_x\) 使全部局部约束完美接受。
4. **Far-input lift（承重条件）**：对每个 \(w\) 满足
   \(\operatorname{dist}(w,L)\ge\eta\)，以及每个扩展 \(T\)，都成立 (369.1)。
5. 字母表大小固定，且 wrong-claim gap 已经压到
   \(\beta\le |\Sigma|^{-3}/16\)。若只能得到常数 \(\beta\)，重复会增加查询数，
   不再是 C--L--M 的 3-query 定理。

在这些条件下，把 \(\Phi_{t,a,b}\) 取为上述局部调用的约束，立即得到一个满足
C--L--M 假设的 PCPP，于是 (369.2) 成立。这是一个精确的条件桥，而不是新的
无条件下界。

## 非蕴含：标准 ACRR 缺少哪一个量词

论文 01 的 ACRR 条件（以二元、完美正确分支为例）是

\[
\begin{aligned}
& p_{i,m_i}(\Pi(m))=1,\\
& \forall z\in B_\rho(\Pi(m)):\quad
  p_{i,1-m_i}(z)\le\beta .
\end{aligned}
\tag{369.3}
\]

它的量词是“固定目标 \(m\) + 该目标 proof 的近邻 + 错误 claim”。C--L--M
需要的量词则是

\[
\forall w\;[\operatorname{dist}(w,L)\ge\eta]\;\forall T\quad
\Pr[\Phi(T)\text{ accepts}]\le\delta .
\tag{369.4}
\]

两者没有逻辑蕴含关系。特别地，(369.3) 对所有不落在任一目标近邻中的 proof
assignment 不作任何约束；把局部关系在这些 off-promise assignment 上改成高接受，
并不改变 (369.3)，却直接破坏 (369.4)。这只是量词分离，不是说未来不能设计一个
额外的局部 relation test 来证明 (369.4)；但该 test 必须作为新定理，而不能从
ACRR 定义中免费获得。

同样，若 ACRR 的查询依赖 \((i,b)\)、随机分支或历史状态，通常只能得到一族
不同的边缘分布，不能自动分解成一个固定的 \(A\) 与 \(B\) 并分别均匀。复制地址
或按坐标拼接虽然可以强行均匀化，却可能支付 \(\Omega(|X|)\) 的 proof/地址长度，
这正是 GMWZ Theorem 11.3 的 coordinate-private 二次长度现象，而不是近线性
shared-proof 桥。

## 另外两个独立缺口

### Hidden-witness projection

若 RW 接口是关系
\(R(x,y,w)\)，想把 \(y\) 当作 C--L--M 的显式输入，必须统一构造

\[
\widehat\varphi_x(y)\Longleftrightarrow \exists w\;R(x,y,w).
\]

这不是语法上的消元。若该投影有统一多项式时间生成器，dummy-output 特例已经触及
\(P=NP\)；若只有非一致电路族，必须按 \(P/\mathrm{poly}\) advice 记账；逐实例
存在小电路而没有 joint generator 则不产生复杂性结论。这个投影门沿用 C368，
不能在本桥中省略。

### Soundness scale

Theorem 7.1 的 \(\delta=|\Sigma|^{-3}/16\) 是定理假设，不是“任意常数 gap”的
记号。普通 ACRR/RLDC 的固定 \(\beta<1\) 只有在另一个保持查询预算的放大器把
\(\beta\) 压到该尺度时才可使用；否则最多进入 C--L--M 的一般 RLDC 转换，而不能
调用其结构化 3-query PCPP 下界。

## 对当前 Closure 计划的决定

因此本轮关闭以下黑箱路线：

\[
\text{common-proof ACRR}
\centernot\Longrightarrow
\text{C--L--M structured PCPP}
\Longrightarrow
\text{quadratic proof lower bound}.
\]

仍然开放、且有论文价值的正向接口只有两种：

* 证明 RW 的实际 hidden-witness history 具有 far-input all-proof lift，并同时满足
  三路 uniform-marginal 与地址尺度生成；或
* 构造一个新的 relation-PCPP theorem，直接提供这些条件，而不是把普通 ACRR 的
  target-relative guarantee 重命名为 PCPP soundness。

如果上述 lift 成立，(369.2) 是可直接调用的外部下界；如果 lift 不成立，当前正确
的结论是量词/语义 model exit，而不是已经得到新的 CLM barrier。

## 证据边界

* C--L--M Theorem 7.1、Theorem 7.2 的完整量词和参数来自本地抽取
  `[unbundled local reference]` 第 1166--1343 行，并与公开版本 arXiv:2603.03717 对照。
* ACRR 的 (369.3) 来自论文 01 的定义 (1.1) 和 Theorems 2.1--2.2。
* GMWZ 的 coordinate-private proof accounting、list/udPCP 量词缺口见论文 01
  Propositions 6.13--6.17；hidden-witness 投影门见 C368。
* 本 note 是量词边界与条件桥，不声称一般 ACRR 不可能性、C--L--M 新下界或
  \(P\ne NP\)。
