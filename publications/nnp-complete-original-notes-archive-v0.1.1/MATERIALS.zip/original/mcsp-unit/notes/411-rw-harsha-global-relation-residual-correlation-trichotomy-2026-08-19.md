> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW/Harsha global-relation residual-correlation 三分（2026-08-19）

## 本轮改变的判断

C340 给出了任意 policy-conditioned global word 的条件总相关性下界，但尚未把它
接到 RW/Harsha 的实际 proof family。这里把 C389--C391 的 source-realizable
identity family 接入该 accounting，得到 Gate-II 的一个精确三分：一个成功的
same-proof global relation 必须支付

1. policy 中的 target information；
2. 各坐标响应中可见的 target information；或
3. 给定 policy 和 target 后的线性尺度 residual joint correlation。

第三项是唯一没有被普通 descriptor/transcript counting 自动排除的 global-relation
逃逸。若它仍可编译成有限个 canonical JK half-lift，则 C410 立即收取 circuit
cost；否则 proposed construction 已经离开当前 JK-lift model，必须给出新的
global-relation theorem，而不能再以 ordinary list soundness 代替。

## 定理 411.1（RW/Harsha identity-family global-relation trichotomy）

令 \(X\) 在 \(\{0,1\}^{b}\) 上均匀。设

\[
  \Pi_b:\{0,1\}^{b}\hookrightarrow \Gamma^{M_b}
\]

是固定的 canonical proof selector，并令其最小 Hamming 距离大于 \(2t_b\)。在
C389 的 Harsha identity-machine specialization 中，可以取这一个 selector；若再
满足 C391 的 simultaneous wrong-claim soundness，则该距离条件由同一共同 proof
接口推出，而不是额外的 family assumption。

设 \(S\) 是 global-relation 的 policy/descriptor，\(Z\in\Gamma^{M_b}\) 是在
同一个 proof/address space 上产生的随机 global word，并令

\[
  p_b:=\Pr\bigl[d_H(Z,\Pi_b(X))\le t_b\bigr].
\]

定义二进制互信息和条件 total correlation

\[
  \mathsf{TI}_b
  := I_2(X;S)+\sum_{j=1}^{M_b}I_2(X;Z_j\mid S),
  \qquad
  \mathsf{RC}_b
  :=\mathbb E\!\left[\operatorname{TC}_2(Z\mid X,S)\right].
\]

则

\[
  \boxed{\mathsf{TI}_b+\mathsf{RC}_b
  \ \ge\ p_b\,b-1.}
  \tag{411.1}
\]

因此，若 \(p_b\ge p_0>0\)，则对任意 \(0\le\theta<p_0\)：

* 若 \(\mathsf{RC}_b\le\theta b\)，则
  \[
    I_2(X;S)+\sum_j I_2(X;Z_j\mid S)
    \ge (p_0-\theta)b-1;
  \tag{411.2}
  \]
* 若 \(\mathsf{TI}_b\le\theta b\)，则
  \[
    \mathsf{RC}_b\ge(p_0-\theta)b-1.
  \tag{411.3}
  \]

这就是 source-family 上的两端三分：低 target information 迫使线性 residual
correlation；低 residual correlation 迫使线性 target channel。

### 证明

由于 \(d_H(\Pi_b(x),\Pi_b(x'))>2t_b\)，最近词解码在事件

\[
  d_H(Z,\Pi_b(X))\le t_b
\]

上唯一确定 \(X\)。令 \(E\) 表示该事件。Fano 不等式给出

\[
  I_2(X;S,Z)\ge I_2(X;Z)
  \ge p_b\log_2|\{0,1\}^{b}|-1
  =p_b b-1.
  \tag{411.4}
\]

另一方面，链式法则与 total-correlation 恒等式给出

\[
\begin{aligned}
 I_2(X;S,Z)
  &=I_2(X;S)+I_2(X;Z\mid S)\\
  &=I_2(X;S)+\sum_j I_2(X;Z_j\mid S)
    -\operatorname{TC}_2(Z\mid S)
    +\operatorname{TC}_2(Z\mid X,S).
\end{aligned}
\tag{411.5}
\]

因 \(\operatorname{TC}_2(Z\mid S)\ge0\)，将 (411.4) 与 (411.5) 合并即得
(411.1)。两条 corollary 只是移项。证毕。

## 与 RW closure 的三条边界

### 1. 低 residual-correlation 分支不是免费 global relation

若 \(\mathsf{RC}_b=o(b)\)，(411.2) 要求 policy 与坐标响应合计携带

\[
  \Omega(b)
\]

比特的 target information。对 C390 的 actual Harsha identity family，若这些
信息被声称由 target-oblivious 的 \(q\) 个 \(2k\)-bit outsider、地址/path 和
descriptor 提供，C393 的 adaptive transcript capacity 与 C390 的实际 family
payload 迫使

\[
  2\sum_{t=1}^{q}k_t+d+|\mathrm{metadata}|\ge b.
  \tag{411.6}
\]

所以 \(q,k_t,d,|\mathrm{metadata}|=\operatorname{polylog}(b)\) 的路线不能位于
这一分支。这里的结论只针对 target-oblivious family lift；published RW
Theorem 4.3 的固定 \(x_0\) singleton 没有 \(b\)-bit family entropy，不能把
(411.6) 偷换成 singleton impossibility。

### 2. 低 target-information 分支是真正的 joint-correlation 逃逸

若 policy 与各坐标 channel 的总互信息为 \(o(b)\)，(411.3) 强迫

\[
  \mathsf{RC}_b=\Omega(b).
\]

这项不能被误称为“短 seed 已经被排除”：一个短 latent seed 可以在许多坐标
之间产生线性 total correlation。C340 的信息论结果只关闭了“低 policy、低坐标
信息、低 residual correlation”三者同时成立的统计逃逸；它没有给出 seed-length
下界。因此这正是 Closure Theorem 需要单独处理的 genuine global relation。

### 3. JK 可编译性给出 singleton 的第三个出口

若上述 joint relation 实际上仍由 \(q\) 个 canonical JK outsider、深度至多
\(\ell\) 的已知 half-lift path、长度 \(d\) 的 descriptor 和显式控制电路
\(s_{\mathrm{ctrl}}\) 生成同一个 parent \(B\)，则 C410 的 singleton 上界给出

\[
  \operatorname{CC}(B)
  \le O\!\left(
    s_{\mathrm{ctrl}}+d
    +q\bigl(2k+\ell(|G_k|+k+\log b)\bigr)
  \right).
  \tag{411.7}
\]

因此在 forcing 长度上，若右端低于 \(\operatorname{CC}(B)\) 下界，该 global
relation 不能是 JK half-lift 的重新命名。任何成功构造必须明确展示一个不能被
(411.7) 编译的全局耦合；否则它已经支付了 object-scale control/descriptor cost。

## 对 Closure Theorem 的精确推进

定理 411.1 把 Gate-II 的未闭合部分压成一个可证伪接口：

* **target channel branch：** 证明 policy/coordinate information 达到线性尺度，
  然后由 C390/C393 排除 address-scale target-oblivious lift；
* **JK branch：** 证明 residual correlation 虽然线性，但仍具有 C410 的
  half-lift 形式，从而由 forcing lower bound 收费；
* **new global-relation branch：** 给出一个不满足前两项的 source-specific
  global coupling，并同时证明 same-proof、address-scale、smartness、cover/bottom
  safety。没有这第三类新机制，不能声称已经完成 RW Attachment。

这不是 \(P\ne NP\) 证明，也不是一般 dPCP/RLDC 不可能性。它的新增内容是把
C340 的 residual-correlation endpoint 接到 actual Harsha/RW source family 和
C410 singleton circuit gate，明确指出：在现有模型中，真正尚未解决的不是“是否
还存在统计相关性”，而是“能否把线性相关性组织成一个不付 object-scale 代价的
新 global relation”。

## 依赖与证据边界

* C340：任意 policy-conditioned global word 的 conditional-correlation
  inequality 与 target-channel accounting；
* C389--C391：Harsha actual factorization、identity-family payload 以及
  simultaneous coordinate/RLDC barrier；
* C393：adaptive transcript capacity；
* C410：singleton JK-lift parent-binding circuit cost。

本 note 不把 C391 的 family interface 偷换成 published singleton，不把 (411.3)
误写成 seed-length lower bound，也不把任何未给出的 global relation 当作已存在。
