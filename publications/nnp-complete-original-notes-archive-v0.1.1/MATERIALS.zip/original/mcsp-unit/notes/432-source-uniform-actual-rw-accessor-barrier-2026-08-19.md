> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Source-uniform actual-RW accessor barrier（2026-08-19）

## 本轮改变的判断

431 只说明已发表 \(A_0/A_1\) 递推在逻辑地址长度 \(m\) 上仍是
object-scale。还需要区分另一种看似更强的正攻：对所有 RW source inputs
\(x\) 给出一个统一的、按 \(m\) 运行的 canonical-proof random-access evaluator。
这种“source-uniform Gate-I”并不是普通技术补丁；它本身已经足以计算
succinct circuit value。因而正向路线只能是 fixed published singleton 或一个
严格受限的 source subclass，不能把全体 Theorem 3.5 实例统一压缩后再声称闭合。

## 定理 432.1（source-uniform actual-RW accessor barrier）

取一个固定的确定性 machine \(M_{\mathrm{SCV}}\)，其输入 \(x\) 是一个
\(2^{O(|x|)}\)-门电路的 succinct gate-list generator 和一个输入地址，机器在
\(2^{O(|x|)}\) 时间内模拟该电路并输出一个 bit。取相应的标准
E-complete succinct circuit-value 语言并记为 \(\mathsf E\)；由确定性时间层次定理，
\(\mathsf E\notin P\)。

假设一个 proposed RW closure interface 满足：

1. 对每个 \(x\)，它使用 Theorem 3.5 的固定 serialization 和 canonical
   honest-proof selector，返回同一个 proof \(\Pi_x\) 的任意地址 bit；
2. 在 \(P=NP\) 假设下，所有 selector/PH/prMA 子过程都能由一个统一算法在
   \(|x|^{O(1)}\) 时间内确定化；地址 \(a\) 的长度也是 \(|x|^{O(1)}\)；
3. 该接口适用于固定的 \(M_{\mathrm{SCV}}\) 的所有输入 \(x\)，而不是只适用于
   一个 published \(x_0\)。

则

\[
  P=NP\quad\Longrightarrow\quad \mathsf E\in P,
\tag{432.1}
\]

与 \(\mathsf E\notin P\) 矛盾。因此，一个对所有 \(x\) 的 source-uniform
address-scale canonical-proof accessor 若能被无条件构造出来，本身就已经蕴含
\(P\ne NP\)；它不能作为 \(P=NP\) 反证中的免费中间引理。

### 证明

令 \(x=(U_C,r)\)，其中 \(U_C\) succinctly 描述一个至多 \(2^{c|x|}\) 门的
电路 \(C\)，\(r\) 是输入。\(M_{\mathrm{SCV}}\) 是固定确定性 machine，因此在
RW Theorem 3.5 中可取 \(r(n)=s(n)=0\)，并令 \(t(n)=2^{O(n)}\)。Lemma 3.2
产生的 computational history 没有 NP-query prefix；其 systematic witness
prefix 的 output field 就是 \(C(r)\)。在固定 serialization 下，该 output bit
位于一个由 \(n\) 和 \(M_{\mathrm{SCV}}\) 唯一确定的地址 \(a_{\mathrm{out}}(n)\)，
且 \(|a_{\mathrm{out}}(n)|=O(n)\)。

在 \(P=NP\) 下，假设 2 把 proposed accessor 变成一个 \(n^{O(1)}\)-时间
过程。对任意 \(x=(U_C,r)\)，计算

\[
  M_{\mathrm{SCV}}(x)
  =
  \Pi_x[a_{\mathrm{out}}(n)]
  =
  C(r).
\tag{432.2}
\]

这给出 \(\mathsf E\) 的 polynomial-time decider，得到 (432.1)。但
\(\mathsf E\notin P\) 是确定性时间层次定理的直接后果，故上述 source-uniform
accessor 不能在 \(P=NP\) 分支中同时存在。证毕。

## 对当前 Closure 计划的精确后果

* 该 barrier **不适用于** Theorem 4.3 的 published \(x_0=0^{n_0}\) singleton：
  量词没有遍历 \(x\)，所以不能把一个新的 succinct circuit-value instance
  编码进 source input。
* 它关闭的是“先对所有 RW machines/inputs 建一个通用 address-scale proof
  evaluator，再把它应用到 singleton”的捷径；这种 evaluator 若已被证明，就已经
  是一个独立的 \(P\ne NP\) 结果。
* 因而真正可行的正攻必须固定 source context，并在该 context 内证明
  non-systematic auxiliary/recursive blocks 的 address-scale selector，或提出
  不把 output bit 作为可访问 systematic prefix 的新 global relation。
* 该结果和 430 的 generic universal-gate barrier 量词不同：432 直接使用
  actual RW Theorem 3.5 的 computational-history/output-prefix 语义，而不是把
  arbitrary succinct seed 当成 \(G_q\) 的输入。

## 证据边界

本 note 不声称 published singleton 已有 accessor，也不证明一般
PCP/dPCP/RLDC 不可能性。它只说明：任何对所有 source inputs 的
address-scale canonical-proof 统一定理，已经包含一个独立的
\(P\ne NP\) 证明；因此 Gate-I 必须保持 singleton/source-subclass 量词。

## 来源

* Ren--Williams TR26-118 revision 1, Lemma 3.2 and Theorem 3.5；
  本地抽取见 units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md
  第 9--15 页。
* [RW logical-scale collapse boundary](431-rw-logical-scale-collapse-boundary-2026-08-19.md)。
* [Nonuniform succinct universal-gate boundary](430-nonuniform-succinct-universal-gate-boundary-2026-08-19.md)。
