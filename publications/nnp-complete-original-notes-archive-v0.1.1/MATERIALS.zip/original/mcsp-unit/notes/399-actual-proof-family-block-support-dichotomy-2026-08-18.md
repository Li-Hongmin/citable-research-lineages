> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Actual proof-family block-support dichotomy（2026-08-18）

## 判定

C396 的 rank/linearity 条件可以进一步去掉。对任意固定 canonical proof
family，只要把 proof 切成 \(2k\)-bit blocks，就有一个纯 support-counting
dichotomy：要么某个 block 在 family 上出现超过 \(2^k\) 个不同值，从而
任意 \(G_k\) 都无法覆盖整个 family；要么所有 block 的 support 都不超过
\(2^k\)，此时 family 的全部 parent 信息必须分散到至少
\(\log_2|\mathcal B|/k\) 个 blocks，并由 C393 支付相同的 transcript capacity。

## Theorem 399.1（support dichotomy）

令 \(\mathcal B\) 是大小 \(M\) 的 parent family，令
\[
  \Pi:\mathcal B\hookrightarrow\{0,1\}^{P}
\]
是 injective canonical proof selector。把 \(P\) 个坐标切成 \(m\) 个长度
\(2k\) 的 blocks（最后不足一块可补固定零并计入 public metadata），并记
\[
  S_j:=\{\Pi(x)|_{B_j}:x\in\mathcal B\}.
\]
对任意 \(G_k:\{0,1\}^k\to\{0,1\}^{2k}\)，\(|\operatorname{Range}(G_k)|\le2^k\)。
于是：

1. 若存在 \(j\) 使 \(|S_j|>2^k\)，则
   \(S_j\setminus\operatorname{Range}(G_k)\neq\varnothing\)；更精确地，至少
   \(|S_j|-2^k\) 个**不同的 block values** 是 outsiders。相应 parent 的
   multiplicity 可能不同，所以这里不自动给出 uniform parent fraction。
2. 若所有 \(j\) 都满足 \(|S_j|\le2^k\)，则
   \[
      M=|\Pi(\mathcal B)|
      \le\prod_{j=1}^{m}|S_j|
      \le2^{km},
   \tag{399.1}
   \]
   因而 \(m\ge\log_2M/k\)。任何 exact parent decoder 若只观察至多 \(q\)
   个 \(2k\)-bit block responses 和一个总长 \(d\) 的 descriptor（adaptive
   challenges、indices 与 path 的 target-dependent 部分均计入 descriptor/
   transcript），都满足
   \[
      d+2kq\ge\log_2M .
   \tag{399.2}
   \]

### 证明

第一项是 \(|\operatorname{Range}(G_k)|\le2^k<|S_j|\) 的抽屉原理。第二项中，
\(\Pi(\mathcal B)\) 嵌入到 \(\prod_jS_j\)，故得到 (399.1)。最后，固定
descriptor 和每轮 response 后，C393 的公开 challenge rule 决定整个
transcript；可见 transcript 总数至多 \(2^{d+2kq}\)，exact recovery
要求至少 \(M\) 个不同 transcript，得到 (399.2)。证毕。

## 对 RW/Harsha Closure 的影响

Theorem 399.1 适用于 nonlinear actual \(\Gamma_x\)、任意固定 ECC
serialization，以及 C398 的 oracle-major source branch；不需要把
\(\Gamma_x\) image 视为完整线性 message space，也不需要先证明 Spielman
的 projection rank。

它把 Gate-I 的 family-level 选择压成两条：

* **support-large branch：** 某个 block 出现 \(>2^k\) 个 actual values，
  因而至少一个 target 的该 block 对任何 \(G_k\) 是 outsider；若能再证明
  first-failure/path 与 parent 的 output attachment，这条路线可接 RW；
* **support-small branch：** 所有 block support \(\le2^k\)，则 exact
  parent binding 必须支付 (399.2)，在 \(M=2^b\)、\(k,d,q=\operatorname{polylog}(b)\)
  时被排除。

第一分支只给存在性而不是 uniform target mass，也不保证 outsider 位于
systematic output 或 \(\Upsilon\) segment；published RW 的 singleton
\(x_0\) 仍完全逃逸 family counting。故 Theorem 399.1 是 actual-family
Closure barrier，不是 \(P\ne NP\) 或一般 dPCP/RLDC impossibility theorem。

## 来源

* C393：adaptive transcript capacity。
* C396--C398：product rank gate、RW serialization boundary 与 oracle-major
  source compiler。
* Ren--Williams Theorem 3.1（JK range size）与 Theorem 3.5（canonical proof
  object decomposition）.
