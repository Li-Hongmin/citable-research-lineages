> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 同中心 mixed separator 的三 target 边界（2026-08-13）

## 代数归约

固定中心 row \(x_0\)，写

\[
q_0=(x_0,1),\qquad
d_y=y+x_0,\qquad
a=x_s+x_0,\qquad b=y_s+x_0.
\]

在中心 row 的叶 \(q_0z=0\) 上，列 \(y\) 可用当且仅当

\[
r\cdot d_y=1.
\]

由 note 046，连通 star \(T_S\) 的三种证书成为

\[
\bigoplus_{y\in S}d_y=
\begin{cases}
a,&|S|\text{ 奇}\quad(R:q_s=1),\\
b,&|S|\text{ 偶}\quad(C:p_s=0),\\
a+b,&|S|\text{ 偶}\quad(P:q_s+p_s=0).
\end{cases}
\tag{1}
\]

所以固定 \(r\) 时，R 型只在 \(r\cdot a=1\) 支持；C 型只在
\(r\cdot b=0\) 支持；P 型只在 \(r\cdot(a+b)=0\) 支持。因而活跃的
\((r\cdot a,r\cdot b)\) 状态是
\[
00:\ C,P,\qquad 10:\ R,C,\qquad 11:\ R,P,
\]
而 \(01\) 不活跃。

## 已有粗界

固定 \(r\) 后，列补集配对仍给出列命中条件概率至多 \(1/2\)，中心 row
保留再给 \(1/2\)。但 mixed 三型的参数支持最多为 \(3/4\)，故只能得到

\[
\Pr(E)\le\frac34\cdot\frac12\cdot\frac12=\frac3{16},
\]

不足目标 \(1/16\)。普通 cross-intersection 不会自动提供缺失的二分因子。

## 边界实例

随机正确 minimal 条件搜索得到同中心、无二点 cover 的 mixed 族：

\[
\begin{gathered}
N=5,\quad
X=\{10,4,24,16,30,9,8\},\\
Y=\{22,25,21,26,23,15,20,1,28,11\},\quad
s=(24,1),\quad x_0=10.
\end{gathered}
\]

其列集为

\[
\begin{array}{c|c}
C&\{20,21,22,28\},\ \{20,25,26,28\}\\
P&\{15,21,25,26\},\ \{15,20,21,23\}\\
R&\{20,22,26\},\ \{20,21,25\},\ \{21,23,26\},\ \{22,23,25\}.
\end{array}
\]

八个 star witness 均 inclusion-minimal 且两两相交；完整枚举得到

\[
\sum_z\mu_z=1.0078125,\qquad
\Pr(E)=0.0157471<\frac1{16}.
\]

该实例不是反例，只说明 mixed 三 target 的 residual 结构确实可同时出现，
不能按固定 separator 子族直接求和闭合。

## 最小未决接口

\[
\boxed{
\text{同中心、三 target }(a,b,a+b)\text{ 的两两相交 circuit-deletion 族，
\text{需额外 affine/circuit 结构给出第二个 }1/2\text{ 因子。}}
\]
