> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed-alphabet time--space--payload boundary (2026-08-24)

## Corollary 30

Assume the interleaved charged-handoff model of Proposition 29 is implemented by fixed source and
target machines with standard contiguous work tapes: the finite control, alphabet, tracks, and
number of heads are independent of \(N\). Let the source and target work tapes use at most \(s_Q\)
and \(s_D\) cells, respectively,
and let the total running time be at most \(T\), with \(T\ge N\). Assume all source-dependent data
outside finite controls is in the counted \(h\)-bit payload, and every target address or head
position lies in a range of size at most \(N'+T+O(1)\), where \(N'=N^{O(1)}\). Under the same
local-PRG and error assumptions as Proposition 29,

\[
\boxed{
h+s_Q+s_D+\log_2(N'+T)=\widetilde\Omega(S),
\qquad S=N^{\mu_H}.
}
\tag{30.1}
\]

Consequently, if \(T=N^{O(1)}\), then

\[
\boxed{h+s_Q+s_D=\widetilde\Omega(S).}
\tag{30.2}
\]

If \(h+s_Q+s_D=o(S)\), then

\[
T=2^{\widetilde\Omega(S)}.
\tag{30.3}
\]

## Proof

For fixed finite alphabets and a fixed finite control, a source configuration is determined by its
finite control, at most \(s_Q\) work-tape symbols, and polynomially many head/address positions;
hence

\[
\log_2 W_Q=O\!\left(s_Q+\log(N+T)\right).
\]

The same count for the target gives

\[
\log_2 W_D=O\!\left(s_D+\log(N'+T)\right).
\]

Substitute these estimates into Proposition 29:

\[
\log(N\mathfrak W)
\le O\!\left(h+s_Q+s_D+\log(N'+T)\right).
\]

Its lower bound \(\widetilde\Omega(S)\) proves (30.1). If \(T=N^{O(1)}\) and
\(N'=N^{O(1)}\), the logarithmic term is \(O(\log N)=o(S)\), proving (30.2). Rearranging
(30.1) under \(h+s_Q+s_D=o(S)\) gives \(\log(N'+T)=\widetilde\Omega(S)\); since
\(N'=N^{O(1)}\), this implies (30.3).

The conclusion fails if a control family grows with \(N\), if sparse-RAM address entropy is not
counted, or if an address range, shared RAM, random seed, or source-dependent pointer is omitted
from the counted state. Those omissions
recreate the hidden-channel counterexample of Proposition 29.

## Scope

This is conditional on the local-PRG/ROBP interface and the complete-state hypothesis. It is a
full \(S\)-scale state boundary for the interleaved interface, not an unconditional one-tape
lower bound and not a proof of \(P\ne NP\).
