> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW Reconf 的共同 prefix--selected-response 量词分解（2026-08-18）

## 本轮判定

本轮只定位 published RW Reconf 在 failure 分支中真正与地址有关的最窄状态。
原文 Theorem 4.1 的逐位重构并不是为每个地址重新跑一套完整历史搜索：所有前缀轮次
都与目标地址无关，地址只进入最后一个 prMA query。因而 published Reconf 可以
精确分解为一条共同的、目标依赖的 prefix transcript，加上一个地址参数化的最后查询。
但这条共同 prefix 不应误读成“共同 response strategy”：canonical proof 是每个
正确分支的共同完备 witness，而 prMA 的语义仍允许按地址选择不同的接受 witness。

这给 Gate-I 一个更窄的接口，但没有自动带来地址尺度闭合：在 RW 稳定阶段，这条
共同 prefix 以及最后查询中的 Merlin 电路仍然是 object-scale。

## 源定理的精确分解

固定一个 Solve_f(x,G_k) failure 调用。令

\[
  r'=O(r\log(t+1)),\qquad
  k'=O(k^4\log(t+2)),
\]

其中 \(t\) 是 \(f\) 的输出长度，\(r\) 是输入的非自适应 NP-query round 参数，
而 \(k'\) 是 Theorem 4.1 给出的 PCP proof circuit 大小上界。令

\[
  \tau_x:=\operatorname{pref}_{r'}(\Pi_x)
       \in\{0,1\}^{r'}
\]

为 canonical PCP proof 的长度-\(r'\) 前缀。则在 failure 分支上，Reconf(x,i) 的
前 \(r'\) 轮得到的 pfx 对所有 \(i\in[t]\) 都等于同一个 \(\tau_x\)，并且最后
查询只有地址参数 \(i\) 不同。写 \(q_{x,\tau,i}\) 表示把该共同 prefix 和地址送入
最后查询的生成器，则

\[
  f(x)_i=1
  \quad\Longleftrightarrow\quad
  q_{x,\tau_x,i}\text{ 是 prMA 的 YES 实例}.
\tag{370.1}
\]

等价地，把最后查询中的附加条件改成输出位等于 \(b\)，可同时写出两个 claim
分支。这里的 YES 是“存在一个接受的 Merlin circuit”；(370.1) 不表示
Reconf 算法必须对所有 \(i\) 选取同一个 circuit。所有这些实际 query 都在 failure
假设下是 smart 的；查询生成、验证器和每个 query 的显式描述长度仍只得到

\[
  \operatorname{poly}(k,r,\log(t+2)),
\tag{370.2}
\]

而不是 \(\operatorname{poly}(\log t)\)。

### 证明

RW 原文在 Theorem 4.1 的 proof 中先维护长度-\(r'\) 的 pfx，每一轮查询
\(q_{\mathrm{pfx}}\) 都不包含目标地址；只有在 prefix 完成后才构造
\(q_{\mathrm{pfx},i}\)。failure 分支的 smartness 归纳证明该 pfx 正好是
\(\Pi_x\) 的长度-\(r'\) 前缀。原文随后说明，最终 query 在 \(f(x)_i=1\) 时有
\(\Pi_x\) 作为接受 witness，而在 \(f(x)_i=0\) 时对任意 witness 都以至少常数概率
拒绝。因此 (370.1) 成立；Theorem 4.1 同时给出 (370.2)。证毕。

## 共同完备 witness 与共同 response 的量词分离

源完备性确实给出一个 canonical circuit \(C_x^\star\)，其 truth table 是
\(\Pi_x\)，并且对每个 \(i\) 满足 \(f(x)_i=1\) 的最终 query，\(C_x^\star\)
都是一个接受 witness。因此在语义上可以写成

\[
  f(x)_i=1\Longrightarrow
  \exists C\;[\Pr_R V_{x,\tau_x,i}(C;R)=1],
  \qquad
  f(x)_i=0\Longrightarrow
  \forall C\;[\Pr_R V_{x,\tau_x,i}(C;R)\le\tfrac12].
\tag{370.3}
\]

第一项中的同一个 \(C_x^\star\) 可同时作为所有 YES 坐标的一个见证；但是
prMA 查询本身只承诺存在性。它不要求一个重构器在所有坐标上选择并显式使用
\(C_x^\star\)，也不排除不同坐标各自存在较短的 \(C_i\)。因此

\[
\text{共同 canonical 完备 witness}
\;\not\Rightarrow\;
\text{共同 selected response strategy}.
\tag{370.4}
\]

这正是 [note 231](231-rw-final-query-common-strategy-lower-bound-2026-08-17.md)
与 [note 365](365-rw-reconf-common-witness-quantifier-gap-2026-08-18.md) 之间的
量词接口：231 的 ROM/sampling payment 需要一个静态 descriptor 和共同 response
rule；published Theorem 4.1 只给出 (370.3)。若要调用 231 的下界，必须新增
same-response binding，或对所有可接受 \(C_i\) 施加 whole-word/descriptor 记账。

## Prefix-advice factorization

由 (370.1) 可得一个更具体的条件性推论。假设在 \(P=NP\)（或一个固定 PH-collapse
假设）下，RW 固定格式的 smart prMA query 在总输入长度 \(L\) 上有统一确定化器
\(\mathcal D\)，运行时间至多 \(L^{c_*}\)。令

\[
  L=\operatorname{poly}(k,r,\log(t+2))
\]

上界 enc(x,\tau,i) 的长度。则在 failure 分支上

\[
  f(x)_i=\mathcal D(\operatorname{enc}(x,\tau_x,i)),
  \qquad i\in[t].
\tag{370.5}
\]

所以把 \(x\) 与同一条 \(\tau_x\) 作为该长度的非一致 advice 硬接进电路，只能得到

\[
  \operatorname{CC}(f(x))
  \le O\!\left(L^{c_*}+L\right).
\tag{370.6}
\]

这比“每个地址各有一条独立 prefix transcript”更强，因为所有地址确实共享
\(\tau_x\)；但它仍然不是 whole-proof common-response 定理。最后 query 的接受
witness \(C_i\) 可以随地址 \(i\) 改变，canonical \(\Pi_x\) 只是每个正确分支的
一个共同完备 witness，不是 source theorem 强制的 selected response。

## RW 稳定阶段的尺度

在 Theorem 4.3 的稳定尾部，源参数为

\[
  T_i=n_{i+1}=n_i^C,\qquad
  k=n_{i+1}=n_i^C,\qquad
  r_i=O(n_i),
\]

而被 forcing 的 AVOID 输出表 \(B_i\) 只有 \(N_i=2n_i\) 位，地址长度

\[
  \ell_i=\lceil\log_2 N_i\rceil=\Theta(\log n_i).
\]

因此共同 prefix 的长度和最后 query 的 witness 上界分别满足

\[
  |\tau_i|=O(n_i\log n_i),
  \qquad
  k'_i=O(n_i^{4C}\log n_i),
\tag{370.7}
\]

均远大于 \(\ell_i^{O(1)}\)。即便 \(P=NP\) 把实际 smart query 在其给定输入尺度
上确定化，(370.5)--(370.6) 仍只是 object-scale evaluator；它不会把 \(\tau_i\) 或
\(k'_i\) 自动压缩成地址尺度。

## 对 Closure 计划的决定

C370 把 Gate-I 的正向目标收窄为下列三种之一：

1. 证明 canonical prefix \(\tau_i\) 有一个 \(\ell_i^{O(1)}\)-bit 的随机访问/生成
   器，并且最后 query 的 witness/验证矩阵也在同一地址尺度；
2. 直接以 \((a,R)\) 为输入构造一个 single-valued、固定层 PH acceptance surface，
   不再显式 materialize \(\tau_i\)；或
3. 证明任意保留 (370.1) 的压缩都必须支付
   \(|\tau_i|\)、\(k'_i\) 或等价 descriptor 的 object-scale 成本，从而进入
   已有的 address-surface/ROM payment 分支。

仅引用“最后一个 query 才依赖 \(i\)”不能完成 Closure；它至多把完整 adaptive
transcript 压缩成一条共同 prefix advice。这个 advice 在 published RW 参数下仍是
object-scale。

## 证据边界

* RW Theorem 4.1 的原文抽取见
  units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md
  第 14--18 页，尤其是 pfx 归纳、最终 \(q_{\mathrm{pfx},i}\) 和 query-size
  估计。
* RW 第 5 节还明确利用“只有最后 query 依赖 \(i\)”把前面 query 的答案作为 advice；
  C370 将这一源级观察改写成同一 failure 分支上的 prefix-advice factorization，
  并把“共同完备 witness”与“共同 selected response”的量词分开。
* 参数 \(k=n_{i+1}\)、\(r_i=O(n_i)\)、\(T_i=n_{i+1}\) 来自同一抽取的 Theorem 4.3；
  尺度纠正与分支边界见 [note 357](357-rw-hard-table-object-scale-correction-2026-08-18.md)
  和 [note 358](358-rw-scale-complete-closure-audit-2026-08-18.md)。
* C370 是 source-specific factorization/scale result，不是一般 ACRR 或 RLDC
  不可能性定理，也不是 \(P\ne NP\) 证明。它不排除未来的 succinct prefix accessor、
  新的 single-valued PH surface，或离开 published Reconf 模型的 Closure 机制。
