> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed-PH address coupling upgrades an outsider to \(P\ne NP\) (2026-08-15)

## Why a generic outsider is not enough

For a fixed decoder family \(G_m:\{0,1\}^{q_m}\to\{0,1\}^{2q_m}\), note 158 shows that a
full-table \(q_m^{O(1)}\)-time outsider generator is naturally an \(E^{\mathrm{NP}}\)-scale
hard-table construction. If \(P=NP\), its NP queries can be removed, but its
\(q_m^{O(1)}=2^{O(m)}\) running time remains. Thus \(P=NP\) alone does not turn that table into
a polynomial-size circuit.

The missing ingredient can be stated without an interactive protocol: every output bit must be
coupled to one fixed low-level predicate at the **address scale**.

## Fixed-PH address-coupling theorem

Let \(m=m(n)\) be a time-constructible schedule with \(m(n)\le n^{O(1)}\), and let
\[
q_{m(n)}=2^{m(n)-1},\qquad N_{m(n)}=2^{m(n)}.
\]
Assume:

1. \(G_m\) has the fixed coverage property
   \[
   \mathcal C_{m,\le s_m}\subseteq\operatorname{Range}(G_m).
   \tag{1}
   \]
2. A uniform outsider procedure supplies \(z_m\notin\operatorname{Range}(G_m)\) for all
   sufficiently large \(m\).
3. There is a fixed level \(k\) of the polynomial hierarchy and one uniform
   \(\mathrm{PH}_k\) predicate \(Q\) such that, for every \(a\in\{0,1\}^{m(n)}\),
   \[
   Q(1^n,a)=z_{m(n)}[a].
   \tag{2}
   \]
   The predicate description and all quantified strings have length polynomial in \(n\);
   \(Q\) is not allowed to call the full-table outsider or to use \(n\)-dependent advice.
4. The coverage threshold dominates every fixed polynomial on this schedule:
   for every fixed \(D>0\), \(s_{m(n)}\ge n^D\) eventually (equivalently,
   \(\log s_{m(n)}/\log n\to\infty\)).

Then
\[
\boxed{P\ne NP.}
\tag{3}
\]

### Proof

Assume \(P=NP\). Then every fixed \(\mathrm{PH}_k\) predicate is decidable in deterministic
polynomial time, with an exponent independent of \(n\). Compose that decider with \(Q\), hardwire
\(1^n\), and leave \(a\in\{0,1\}^{m(n)}\) as the input. This gives an \(m(n)\)-input circuit
\(B_n\) with
\[
\operatorname{CC}(B_n)\le n^{D_0}
\tag{4}
\]
for a fixed \(D_0\). By assumption 4, \(s_{m(n)}\ge n^{D_0+1}\) eventually. By (2),
\(\operatorname{TT}(B_n)=z_{m(n)}\). Condition (1) then puts \(z_{m(n)}\) in the decoder range,
contradicting assumption 2. Hence \(P\ne NP\).

The proof only uses a single fixed PH level. The most concrete special case is a SAT-coupled
compiler: \(Q(1^n,a)\) is the predicate that a uniformly generated CNF
\(\varphi_{n,a}\) is satisfiable. Under \(P=NP\), evaluating \(Q\) is polynomial, so the same
contradiction follows.

The superpolynomial threshold in assumption 4 is essential for a theorem whose hypotheses do
not know the exponent of the hypothetical \(P=NP\) decider. A fixed-power version is valid only
with the explicit requirement \(s_{m(n)}\ge n^{D_0+\varepsilon}\), where \(D_0\) is the
resulting evaluator exponent (or with an equivalent uniform upper bound on that exponent);
one cannot simply increase an arbitrary fixed \(D\) after the collapse.

## SAT/JK forcing corollary

Let \(A\) be a candidate SAT machine and suppose a Ren--Williams/Jeřábek--Korten forcing
construction supplies a stitched table \(H_A\) with
\[
\operatorname{CC}((H_A)_n)>n^{k(n)},\qquad k(n)\to\infty,
\tag{5}
\]
whenever \(A\) is correct. If, in addition to the four assumptions above, there is a uniform
address map \(\Gamma_A(n,x)\in\{0,1\}^{m(n)}\) of polynomial-size circuits such that
\[
H_A(x)=z_{m(n)}[\Gamma_A(n,x)]
\tag{6}
\]
for every \(x\), then \(P=NP\) makes the right side polynomial-size by the proof above. Composing
\(\Gamma_A\) with \(B_n\) yields \(\operatorname{CC}((H_A)_n)\le n^{O(1)}\), contradicting (5) for
large \(k(n)\).

This is a static, address-local alternative to the smart-\(\mathrm{prMA}\) interface in note 121.
It makes the required SAT coupling explicit: the outsider table must be the source of the forcing
table's bits, not merely an unrelated \(E^{\mathrm{NP}}\)-hard table.

## Exact boundary

The generic outsider statement from note 158 does **not** imply condition 3. Its output bits may
only be computable by running a \(2^{O(m)}\)-time NP-oracle transducer, which remains an
\(E\)-scale computation under \(P=NP\). Likewise, a separate PH predicate for each address with
inconsistent advice or witnesses does not define one word-consistent table; (2) requires one
fixed predicate and the same schedule for all addresses.

Therefore the route is split cleanly:

\[
\boxed{
\begin{array}{ll}
\text{generic full-table outsider} &\Rightarrow E^{\mathrm{NP}}\text{ hard table};\\
\text{fixed PH address coupling + coverage} &\Rightarrow P\ne NP;\\
\text{no address coupling} &\text{leaves the }E^{\mathrm{NP}}\text{ barrier intact}.
\end{array}}
\]

This is a sufficient-condition theorem. It does not assert that Ren--Williams/JK currently
provides the fixed predicate \(Q\) or the address map \(\Gamma_A\).

## Relation to prior notes

- Note 158 gives the \(q\)-scale outsider \(\Longleftrightarrow E^{\mathrm{NP}}\)-hard-table
  reindexing.
- Note 121 gives a smart-\(\mathrm{prMA}\) sufficient interface for \(P\ne NP\).
- This note isolates the noninteractive, fixed-\(\mathrm{PH}\), all-address condition that would
  bridge the two; it does not claim that bridge is known.
