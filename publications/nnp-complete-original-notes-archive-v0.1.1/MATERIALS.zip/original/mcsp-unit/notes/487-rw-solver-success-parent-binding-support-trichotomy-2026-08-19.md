> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW solver-success 的 parent-binding / support 三分（2026-08-19）

## 本轮改变的判断

C372 与 C471 不能直接拼成无条件 Closure。C372 说明 RW Theorem 4.1 的
Solve-success 语义只有

\[
  Y_n=\operatorname{Solve}_{f_n}(x_n,G_n)\notin\operatorname{Range}(G_n),
\]

并没有说明 child outsider \(Y_n\) 能恢复 parent \(f_n(x_n)\)。C471 则从相反的
方向出发：一旦已经有同一个 object 上的 single-valued、common-proof evaluator，
proof support 就必须支付 forcing-scale 代价。

本 note 把两者合成一个精确的 source-specific 三分。它不声称 published RW 已经
进入第二支，也不把第三支冒称为不可能性；它只说明：任何想利用 solver-success
完成 Closure 的方案，必须明确提交一个 parent-binding theorem，或承认自己已经
离开现有 RW 语义/计价模型。

## 设置与定义

令 \(\mathcal I\) 为 C455 的无限 good-length 集合。对每个 \(n\in\mathcal I\)，取一个
parent \(P_n=f_n(x_n)\)，以及 RW 成功分支的 child

\[
  Y_n=\operatorname{Solve}_{f_n}(x_n,G_n),
  \qquad
  Y_n\notin\operatorname{Range}(G_n).
  \tag{487.1}
\]

称一个 **charged parent-binding attachment** 为以下数据：

1. 目标对象是同一个 \(P_n\)，并且对所有地址 \(j\in[N_n]\) 使用同一个
   physical package。package 可以包含 \(Y_n\)、proof、sheet/descriptor，但其
   所有可读取单元都必须按普通 fan-in-two ROM 计价；把 \(Y_n\) 作为免费的全局输入
   不属于此定义。
2. 在 \(P=NP\) 确定化后，存在一个固定 evaluator \(D_n\)，对所有地址满足
   \[
     D_n(j;Y_n,z_n)=P_n[j].
     \tag{487.2}
   \]
   这是 whole-word、single-valued 的绑定；
   \(\forall j\,\exists C_j\) 或每个地址更换 proof 不满足此条件。
3. evaluator 最多进行 \(q_n\) 次自适应 package reads，控制电路大小为 \(g_n\)。
   令 \(L_n\) 为所有地址以及所有可能 package-answer paths 上可能读取的 package
   positions 的并集，\(\ell_n\) 为 package-address 长度，\(a_n\) 为 package
   symbol 的 bit 长度。

这里的 package 统一包含 child \(Y_n\) 与 physical proof；如果某个方案声称
“直接读取 \(Y_n\)”而不把这些 bits 计入 \(L_n\) 或 \(g_n\)，那只是一个未计价的
global oracle/model exit，而不是 address-scale reconstruction。

## 定理 487.1（solver-success parent-binding/support 三分）

在只使用 RW Theorem 4.1 成功语义 (487.1) 的前提下，任何声称由 solver-success
分支完成 Closure 的方案都落入以下三类之一：

### (U) 语义未绑定（semantic exit）

方案没有证明一个满足 (487.2) 的同一 parent-binding map。则从 (487.1) 不能推出
任何 parent address evaluator，甚至不能推出 \(Y_n\) 与 \(P_n\) 的 target-separated
fingerprint 关系。该分支只提供 child AVOID outsider，不提供 Closure 的第二个箭头。
这不是对实际 Solve 实现“不存在 binding”的断言，而是说明该 binding 不能从
Theorem 4.1 的成功语义自动获得。

### (B) 有限视图绑定（charged binding）

方案证明了 charged parent-binding attachment。则存在普通 fan-in-two circuit
\(C_n\)，满足

\[
  \operatorname{CC}(P_n)
  \le
  O\!\left(
     g_n+q_nL_n(\ell_n+a_n)+\log(N_n+2)
  \right).
  \tag{487.3}
\]

因此，只要同一 \(P_n\) 在同一长度集合上满足
\(\operatorname{CC}(P_n)\ge S_n\)，就有

\[
  g_n+q_nL_n(\ell_n+a_n)+\log(N_n+2)
  \ge S_n/O(1).
  \tag{487.4}
\]

特别地，若 \(g_n,q_n,L_n,\ell_n,a_n\) 都是
\((\log N_n)^{O(1)}\)，则不能在 forcing-scale
\(S_n=N_n/\operatorname{polylog}N_n\)
上成立。

### (X) 模型/量词出口（genuine model exit）

方案声称存在 parent 绑定，但它不满足 charged attachment 的至少一项：例如
parent 与 child 使用不同 physical proof/address space，\(Y_n\) 通过未计价 global
state 影响输出，evaluator 仍是多值关系，或成功分支的 soundness/长度量词被改写。
这不是 (487.1) 的推论，必须作为新的 global relation 单独定义并证明；它对应
C450 的 genuine model-exit 分支。

三分的重点不是把 (X) 判为错误，而是禁止把 (X) 的新量词静默称为现有 RW
Closure。

## 证明

### (U) 的语义非蕴含

固定一个 \(G\) 和一个 \(y\notin\operatorname{Range}(G)\)。在只保留 (487.1) 的
语义模型中，令两个 parent \(P^{(0)}\ne P^{(1)}\) 共用同一个 child \(y\)。两者
都满足 \(y\notin\operatorname{Range}(G)\)，但同一个 \((G,y)\) 不能决定任一 parent
bit。因此不存在仅由 (487.1) 推出的固定

\[
  P_n[j]=D(x_n,G_n,Y_n,j)
  \tag{487.5}
\]

或等价的全词恢复、injective fingerprint 结论。实际 Solve 实现是否额外具有这种
关系是另一个待证明命题；Theorem 4.1 本身没有提供它。

### (B) 的 ROM 展开

把真实 package 单元固定为常量。第 \(r\) 次自适应 read 的地址由 finite control
产生；因为所有可能 answer paths 的地址都落在 \(L_n\)，该 read 可用一个
\(L_n\)-项 mux 实现，成本
\(O(L_n(\ell_n+a_n))\)。至多 \(q_n\) 次 read 加上控制和最终输出，得到
(487.3)。将 forcing 下界代入即可得 (487.4)。这正是 C471 的证明，但现在明确
要求 package 同时承载 solver-success child 与 parent-binding proof，因此不会把
“child outsider”误算成“parent evaluator”。

### (X) 的必要性

若方案不属于 (U)，它必须额外声称某种 parent-binding 关系；若该关系又不满足
有限 package、同一 object、single-valued 或普通计价中的任一条件，就不在 (B)
的 ROM 展开域内。此时它改变了 C450 的承重量词或资源，故只能归入 (X)，并须
给出新的 global relation 定理，而不能由 (487.1) 自动晋级。

## 对 published RW Closure 的直接推论

C455 的 forcing 输出为同一无限集合 \(\mathcal I\) 上的 \(B_n=A'(1^n)\)，满足

\[
  \operatorname{CC}(B_n)=\Omega(N_n/\log N_n).
\]

因此，若某个 solver-success 方案把这个同一个 \(B_n\)（或 C456 已对齐且具有同一
forcing 下界的 parent）绑定到一个 address-scale common package，便进入 (B)，由
(487.3) 与 C455 矛盾。反过来，Ren--Williams Theorem 4.1--4.3 目前只明确给出
(487.1)；其 Solve-success outsider 没有 published 的 parent-binding map，所以
现阶段仍停在 (U)/(S) 边界，而不是 \(P\ne NP\) 证明。

这也精确修正 C450 的 branch 解释：

* 只得到 \(Y_n\notin\operatorname{Range}(G_n)\)，且生成/模拟仍按 \(N_n^{O(1)}\)
  计价，是 stable object-scale solver；
* 一旦补上同一 parent 的 address-scale charged binding，就进入 (A)/(R)，并被
  C471 forcing 关闭；
* 若补上的绑定依赖未计价 global relation 或改变 same-proof/target 量词，则是
  (E)，必须另立定理。

## 证据边界

* C372 只排除从 Solve-success outsider 语义自动得到 parent binding；它不声称
  实际 RW 的 child 与 parent 必然无关。
* C471/C455 的 forcing 只在同一个 hard object、同一长度集合和计价 evaluator
  上使用；不能把 parent 的下界转移给不相同的 child。
* 本 note 是 source-specific Closure classification，不是一般 AVOID、PCP、RLDC
  不可能性，也不是无条件的 \(P\ne NP\) 证明。

## 来源

* [C372 RW Solve-success parent--child semantic exit](372-rw-solver-success-semantic-exit-2026-08-18.md)。
* [C450 scale-complete RW Closure normal form](450-scale-complete-rw-closure-normal-form-2026-08-19.md)。
* [C455 published RW hard-output forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
* [C471 singleton common-proof support forcing gate](471-rw-singleton-proof-support-forcing-gate-2026-08-19.md)。
