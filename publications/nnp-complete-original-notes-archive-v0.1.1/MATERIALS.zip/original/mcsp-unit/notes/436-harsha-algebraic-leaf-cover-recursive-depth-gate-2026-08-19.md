> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha algebraic leaf-cover 与 recursive-depth gate（2026-08-19）

## 本轮改变的判断

Harsha 的实际诚实 proof 不是任意 opaque padding：
\[
\Gamma_x=(\widetilde A_x,\;P_x,\;\Pi_{\mathrm{ZoS},x}),
\qquad
P_x=p(\widetilde A_x),
\]
并且 \(\Pi_{\mathrm{ZoS},x}\) 来自 \(P_x\) 的逐变量除法链。对一个固定的
source-compatible、line-major serialization，低度多项式的每个 bundled line
block 确实可以用短 coefficient/line descriptor 生成；再与低率 product-ECC
branch 做 tagged union，可以得到一个实际的**顶层 leaf \(H_{\rm wit}\)**
候选。

但这不等于 recursive closure。JK 的下一层看到的是这些 descriptors 的拼接；
若相邻 line descriptors 保留独立熵，则一个共同 \(G_k\) 的 root range 只能承载
\(k\) bits，总深度 \(d\) 必须支付
\[
  2^d s_{\rm alg}\le k.
\]
因此本 note 把正攻精确分成两段：

1. **leaf layer：** Harsha algebraic oracles 与 \(\Upsilon\) 可以进入同一个
   tagged top-level range cover；
2. **recursive layer：** 只有同一 line/global parameter 被跨层复用，或出现新的
   non-product global relation，才能绕过 descriptor entropy gate。

这是一条 source-parameterized 正向/负向接口，不是 \(P\ne NP\) 证明，也不把
actual published singleton 自动当成 independent-line family。

## Harsha 参数与 bundled algebraic oracles

令 \(N\) 是 Theorem 3.4 中 Circuit-SAT 电路大小，采用 Harsha/RW 的参数
\[
 m=\left\lceil\frac{\log N}{\log\log N}\right\rceil,\qquad
 |H|=N^{1/m},\qquad
 \lambda=\lceil\log_2|F|\rceil ,
\]
其中 \(|F|=\Theta((m|H|)^3)\)。按 Harsha 的 source construction，考虑三个
algebraic oracle families：

* \(\widetilde A:F^m\to F\)，总度 \(\Delta_A\le m|H|\)；
* \(P:F^{3m+3}\to F\)，总度 \(\Delta_P\le(6m+3)|H|\)；
* \(\Pi_{\mathrm{ZoS}}:F^{3m+3}\to F^{6m+6}\)，每个 bundled component
  是相应 \(P_i/Q_i\) 的低度 polynomial，度数不超过 \(\Delta_P\)。

最后一项使用 Harsha §5.3.2 的 polynomial division-chain source fact；若某个
具体 arithmetization 采用不同的 degree bound，应把 \(\Delta_P\) 替换为其实际
上界，而不改变下面的计账。

设一个 scalar/vector oracle family \(O_r\) 的 domain dimension 为 \(d_r\)，
component count 为 \(c_r\)，并把一条 affine line 的全部 bundled components
连续排列。一个 line descriptor 需要：

* \(c_r(\Delta_r+1)\) 个 field coefficients；
* line base point 与 direction，共 \(2d_r\) 个 field elements；
* line start、oracle/component tag、padding 与 branch tag。

因此可取
\[
s_r
 \le
 \bigl(c_r(\Delta_r+1)+2d_r+2\bigr)\lambda
 +O(\log(m+2)).
\tag{436.1}
\]
对 \(\Pi_{\mathrm{ZoS}}\)，\(c_r=6m+6\)、\(d_r=3m+3\)，所以
\[
s_{\rm alg}:=\max_r s_r
 =O(m^2|H|\lambda).
\tag{436.2}
\]

## 定理 436.1（Harsha top-level algebraic leaf cover）

假设 proof serialization 满足以下 source interface：

1. \(\widetilde A,P,\Pi_{\mathrm{ZoS}}\) 的 bundled line segments 使用固定、
   可逆且 address-scale 可计算的 line-major permutation；
2. 每个 \(2k\)-bit block 要么完整落在一个 bundled algebraic line segment
   内，要么由固定 boundary padding 单独标记；
3. 一个合法 low-rate product-ECC encoder \(E_0:\mathbb F_2^a\to\mathbb F_2^b\)
   满足
   \[
     Q_ka+\lceil\log_2 b\rceil+1\le k,\qquad
     Q_k=\left\lceil\frac{2k}{b}\right\rceil+1.
   \tag{436.3}
   \]

若
\[
 \max\{s_{\rm alg},\,Q_ka+\lceil\log_2b\rceil+1\}
 +\lceil\log_2(R+1)\rceil
 \le k,
\tag{436.4}
\]
其中 \(R=O(m)\) 是 algebraic component/boundary/ECC branch 数，则存在一个
polynomial-size、\(P\)-uniform generator
\[
  H_k:\{0,1\}^{k}\to\{0,1\}^{2k}
\]
覆盖所有满足上述 serialization 条件的 algebraic line blocks 与 product-ECC
internal blocks。

### 证明

对每个 algebraic branch，把 seed 解析成 (436.1) 的 coefficient、line、start
和 tag 字段。沿该 line 用 Horner evaluation 计算所需 field values；vector
component 逐项并行计算。有限域加乘、地址算术和 padding 都可由
\(k^{O(1)}\) 大小电路实现。对 product-ECC branch，使用 Theorem 400.1 的
\(Q_k\) 个 source symbols 与 codeword offset 描述。最后用
\(\lceil\log_2(R+1)\rceil\) 位选择 branch，并把短 seed 零填充到 \(k\) bits。
条件 (436.4) 保证所有 branch 都能嵌入同一个 tagged generator；故每个实际
top-level block 都在 \(\operatorname{Range}(H_k)\)。证毕。

在 Harsha 参数下，若把一个 bundled algebraic line 的完整输出长度取为
\[
  2k=\Theta\bigl((6m+6)|F|\lambda\bigr),
\tag{436.5}
\]
则
\[
 k=\Theta(m|F|\lambda),\qquad
 \frac{k}{s_{\rm alg}}=\Omega(m^2|H|^2).
\tag{436.6}
\]
所以 leaf cover 的 seed budget 在 \(N\) 的 polylogarithmic 地址尺度内可满足；
这不是把 line-block 当成障碍的理由。

## 定理 436.2（independent-line recursive-depth gate）

沿用 \(H_k\) 与 canonical preimage \(p\)。设一个 depth-\(d\) JK subtree 的
\(2^d\) 个 non-output leaves 分别来自 \(2^d\) 个 line-descriptor families，
每个 family 有至少 \(2^{s_{\rm alg}}\) 个值，且 source/interface 使所有
descriptor tuples 都可实现为同一个 common serialization。若所有 leaves 及其
canonical-preimage internal blocks 都要求落在
\(\operatorname{Range}(H_k)\)，则
\[
  \boxed{2^d s_{\rm alg}\le k.}
\tag{436.7}
\]

更一般地，若第 \(\ell\) 个 leaf 的 descriptor entropy 是 \(s_\ell\)，则
\[
  \sum_{\ell=1}^{2^d}s_\ell\le k.
\tag{436.8}
\]

### 证明

每个 descriptor tuple 给出一个 leaf tuple。由于 \(p\) 在
\(\operatorname{Range}(H_k)\) 上 injective，沿 JK tree 从 leaf tuple 到 root
block 的映射 injective。所有 root blocks 都在同一 range，故不同 tuple 的
数量不超过
\[
  |\operatorname{Range}(H_k)|\le2^k.
\]
另一方面，product-rich 假设给出至少
\(2^{\sum_\ell s_\ell}\) 个不同 leaf tuples。比较两式得到 (436.8)，等熵特例
给出 (436.7)。证毕。

## Harsha proof 的深度后果

由 (436.6)--(436.7)，在 independent-line branch 上可支持的递归深度至多
\[
 d\le \log_2\frac{k}{s_{\rm alg}}
 =O(\log(m|H|))
 =O(\log\log N).
\tag{436.9}
\]

而 C408 的 complete-table Harsha serialization 有
\[
 |\Pi_x|=N^{18+o(1)}
\]
量级，JK 看到的完整 proof 的树高是
\[
 D_{\rm proof}
 =\Theta(\log|\Pi_x|)
 =\Theta(\log N).
\tag{436.10}
\]
因此，一个把所有可能 line descriptors 当作 independent/product-rich 的
universal \(H_{\rm wit}\) 不能跨越整份 proof 的 recursive tree：它在
\(O(\log\log N)\) 深度后就触发 (436.7)。

这不是对 actual singleton 的自动不可能性。若实际 \(\Gamma_x\) 的不同 lines
由一个共享 global parameter 强相关，C433 的 single-parameter branch 可能在
局部深度内继续闭合；但必须显式证明：

1. global parameter 的长度与 address-scale \(k\) 相容；
2. line tags、boundary blocks 与 canonical preimage 的 serialization 一致；
3. 跨越不同 lines 的 subtree 不重新引入
   \(\sum s_\ell>k\) 的 local entropy；
4. 该 closure 最终仍能绑定 systematic output parent。

若这四项不能同时成立，剩余路线是 output-attached failure、message-scale
descriptor，或新的 non-product global relation，而不是把顶层 leaf cover
误称为完整 Closure Theorem。

## 与 C433/C434 的关系

* C433/434 给出 shared-parameter recursive generator 与 systematic-output
  support gate；
* Theorem 436.1 首次把 Harsha 的 \(\widetilde A,P,\Pi_{\mathrm{ZoS}}\) 与
  product-ECC 放入同一个 source-compatible top-level branch；
* Theorem 436.2 说明这一步不能自动递归：共享同一 line/global parameter 是
  必要的正向接口，independent-line family 则支付 (436.7)；
* C401/C416 仍负责把 non-output cover 接到 output-attached first failure；
  C417/C434 负责 whole-parent 与 systematic-output 信息支付。

所以当前实际 RW Gate-I 被压成一个可核验三分：
\[
\boxed{
\begin{array}{c}
\text{shared global line parameter with tagged recursive inverse};\\
\text{independent-line entropy, forcing }2^d s_{\rm alg}\le k;\\
\text{a new non-product global relation or model exit}.
\end{array}}
\]

## 证据边界

* C389：Harsha honest proof 的 \((\widetilde A,P,\Pi_{\mathrm{ZoS}})\) 正向
  factorization，不提供局部逆；
* C398：保留 systematic prefix 的 oracle-major binary serialization branch；
* C400：product-ECC top-level universal block cover；
* C402/C425：canonical-preimage product capacity 与 recursive depth--rate law；
* C433/434：shared-parameter closure 与 systematic-output support gate；
* note 129：Harsha line-block 的具体 \(m,|H|,|F|\)、degree 与 seed/output
  参数窗口。

本 note 的 Theorem 436.1 是在显式 serialization/degree interface 下的正向
leaf-layer theorem；Theorem 436.2 是对 independent-line universal branch 的
容量障碍。两者都不证明 published \(x_0\) singleton 的 \(P\ne NP\) 结论。
