> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Middle-cut equality gadget and the half-entropy threshold (2026-08-24)

## Proposition 38

Let \(N=2m\), let \(A\subseteq\{0,1\}^{N}\), and let
\(H\subseteq\{0,1\}^{m}\) satisfy
\[
 h\Vert h\in A\qquad(h\in H).
 \tag{529.1}
\]
Define the undirected graph \(G_H\) on \(H\) by joining distinct \(h,g\) whenever
\[
 h\Vert g\in A\quad\text{or}\quad g\Vert h\in A.
 \tag{529.2}
\]
If \(W_{m}(A)\) is the width at the middle cut of any known-order ROBP for \(1_A\), then
\[
 \boxed{
 W_m(A)\ge \alpha(G_H)
 \ge \frac{|H|^2}{2|A|+|H|}.
 }
 \tag{529.3}
\]

Equivalently, with \(d=\log_2|H|\) and \(L=\log_2|A|\),
\[
 \log_2 W_m(A)
 \ge 2d-\log_2\!\left(2^{L+1}+2^d\right).
 \tag{529.4}
\]
In particular, a family of diagonal YES tables with
\[
 2\log_2|H|-\log_2|A|=\Omega(\Gamma)
 \]
forces \(W_m(A)\ge 2^{\Omega(\min\{\Gamma,\log|H|\})}\).

### Proof

There are at most \(|A|\) ordered pairs \((h,g)\) with \(h\Vert g\in A\), because
\((h,g)\mapsto h\Vert g\) is injective. Hence \(G_H\) has at most \(|A|\) edges. A greedy
independent-set bound gives
\[
 \alpha(G_H)\ge\frac{|H|^2}{2|E(G_H)|+|H|}
 \ge\frac{|H|^2}{2|A|+|H|}.
 \]
For an independent set \(I\subseteq H\), each prefix \(h\in I\) has a distinct residual at the
middle cut: its suffix \(h\) is accepted by (529.1), while for every \(g\in I\setminus\{h\}\),
the suffix \(g\) is rejected because \(h\Vert g\notin A\). Therefore the middle layer has at
least \(|I|\) states. \(\square\)

## MCSP specialization

For \(A=\mathrm{MCSP}_{S}\), take \(H\) to be any family of \((n-1)\)-variable truth tables
whose circuit implementations can be lifted to the \(n\)-variable duplicated table \(h\Vert h\)
within budget \(S\). For example, every \(h\) of circuit size at most \(S-O(1)\) belongs to
such an \(H\), since the duplicated function ignores the first address bit. Consequently,
\[
 \log W_{N/2}(\mathrm{MCSP}_S)
 \ge
 2\log|\mathcal L_{n-1,S-O(1)}|
 -\log\!\left(2|\mathcal L_{n,S}|+
 |\mathcal L_{n-1,S-O(1)}|\right).
 \tag{529.5}
\]

This is an unconditional MCSP residual lower bound. It becomes \(S\)-scale exactly when the
half-table YES entropy exceeds one half of the full-table YES entropy by an \(S\)-scale margin.
The presently available \(\Theta(S\log S)\) entropy estimates do not determine that leading
constant, so (529.5) does not yet prove the desired \(\widetilde\Omega(S)\) bound in the full
parameter range.

## Sharpness of the entropy interface

The half-entropy threshold is optimal for this purely diagonal method. For
\(A_{\mathrm{diag}}=\{h\Vert h:h\in H\}\), the middle width is \(|H|\), while (529.3) gives
at least \(|H|/3\). Conversely, \(A_{\mathrm{prod}}=H\Vert H\) has the same diagonal YES
family but every middle residual is identical, so its width is \(1\). Thus no argument using only
\(|A|\) and the diagonal family can bypass the half-entropy comparison; an improvement must use
MCSP-specific restrictions on mixed pairs.

## Boundary

The obstruction is no longer an arbitrary non-affine cross-combination: it is the concrete
half-entropy inequality
\[
 2\log|\mathcal L_{n-1,S-O(1)}|>\log|\mathcal L_{n,S}|.
 \tag{529.6}
\]
Any improvement of the circuit-entropy constants that establishes (529.6) with an
\(\Omega(S)\) margin immediately yields an \(\Omega(S)\) middle-cut residual lower bound, and
therefore an unconditional \(S\)-scale width barrier for MCSP. Conversely, if the two entropies
are equal to leading order, the equality gadget alone cannot force that barrier.

## Dependencies

- [Proposition 34](526-affine-residual-route-boundary-2026-08-24.md)
- [Propositions 36--37](528-energy-route-obstruction-and-random-baseline-2026-08-24.md)
- [MCSP active paper](../papers/02-truth-table-quotients-do-not-close-one-tape-mcsp-magnification/paper.md)
