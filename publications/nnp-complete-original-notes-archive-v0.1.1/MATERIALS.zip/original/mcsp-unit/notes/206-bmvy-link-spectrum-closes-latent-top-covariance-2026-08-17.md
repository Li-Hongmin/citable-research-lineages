> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# BMVY link spectrum closes the latent-top covariance gate (2026-08-17)

## Scope

In the GMWZ direct-product/cross-cluster analysis, the test samples a top face \(U\), then
two left faces \(a_0,a_1\) independently conditional on \((U,b)\), where the common
face \(b\) has size \(s\). (The one-output dPCP marginal is sampled by first choosing a
left face and then \(b,u,t\); the top-face law below is the DPT disintegration used for
the cross event.) The remaining right-face gate is therefore not a generic
pair-agnosticity question: for a factorized cluster event it is a covariance question
for the conditional top-face averages. This note proves the exact spectral reduction.

The result is source-specific and conditional on the link incidence operator having the
stated singular-value bound. It does not claim that GMWZ's published list-decoding
theorem already contains the resulting latent-\(U\) profile.

## Setup

Let \(X\) be a \(d\)-dimensional partite complex. Fix \(b\in X(s)\), and sample

* \(U\in X(d)\) conditional on \(U\supseteq b\);
* \(a\in X(k)\) conditional on \(b\subseteq a\subseteq U\).

Write \(X_b\) for the link of \(b\). Its top and left dimensions are \(d-s\) and
\(k-s\). Let

\[
 T_b f(U):=\mathbb E[f(a)\mid U,b]
\]

be the conditional inclusion operator from \(k\)-faces to \(d\)-faces. Let
\(\lambda_b\) be its nontrivial \(L_2\) operator norm, i.e. the norm after removing
the constant functions, and put \(\lambda_*=\sup_b\lambda_b\).

For a \(k\)-face cluster \(\mathcal U_i\), let \(f_i=1_{\mathcal U_i}\),

\[
 p_i(U,b)=T_bf_i(U),\qquad
 \mu_i(b)=\mathbb E_{U\mid b}p_i(U,b),\qquad
 \mu_i=\mathbb E_b\mu_i(b).
\]

For the GMWZ factorized event
\(C_{ij}=\{a_0\in\mathcal U_i,\ a_1\in\mathcal U_j\}\), conditional independence
given \((U,b)\) gives

\[
 w_{ij}(b)=\Pr[C_{ij}\mid b]
 =\mathbb E_{U\mid b}[p_i(U,b)p_j(U,b)].
 \tag{LTC1}
\]

## Link-spectrum covariance theorem

**Theorem.** Assume \(k-s>1\) and \(\lambda_*<1\). Then, for every \(b\),

\[
 \operatorname{Var}_{U\mid b}p_i(U,b)
 \le \lambda_b^2\,\mu_i(b)(1-\mu_i(b))
 \le \lambda_*^2\mu_i(b).
 \tag{LTC2}
\]

Consequently,

\[
 \mathbb E_b\left|\operatorname{Cov}_{U\mid b}(p_i,p_j)\right|
 \le \lambda_*^2\sqrt{\mu_i\mu_j}.
 \tag{LTC3}
\]

Let \(\bar\gamma_{ij}=\mathbb E_b[\mu_i(b)\mu_j(b)]\). If

\[
 \mathbb E_b|\mu_i(b)\mu_j(b)-\bar\gamma_{ij}|
 \le \eta_{\rm marg}\bar\gamma_{ij},\qquad
 \kappa_{\rm top}:=\frac{\lambda_*^2\sqrt{\mu_i\mu_j}}{\bar\gamma_{ij}}<1,
 \tag{LTC4}
\]

then the full-view transfer error of the shared-top event satisfies

\[
 \operatorname{TV}\!\left(\nu_{(t,u,b)\mid C_{ij}},\nu_{(t,u,b)}\right)
 \le \frac{\eta_{\rm marg}+2\kappa_{\rm top}}
 {2(1-\kappa_{\rm top})}.
 \tag{LTC5}
\]

The same bound holds for the exposed \((t,u)\)-view by data processing. Thus the
latent-top part of the GMWZ cross-cluster transfer gate is closed whenever the right
side of (LTC5), plus the existing cluster-error term, is below the synchronization gap.

### Proof

The operator \(T_b\) maps constants to constants. Hence

\[
 p_i(U,b)-\mu_i(b)=T_b(f_i-\mu_i(b))(U).
\]

The centered \(L_2\) contraction gives

\[
 \operatorname{Var}_{U\mid b}p_i
 \le \lambda_b^2\operatorname{Var}_{a\mid b}f_i
 =\lambda_b^2\mu_i(b)(1-\mu_i(b)),
\]

which proves (LTC2). Cauchy--Schwarz in \(U\), followed by Cauchy--Schwarz in \(b\),
gives

\[
 \mathbb E_b|\operatorname{Cov}_{U\mid b}(p_i,p_j)|
 \le \mathbb E_b\sqrt{\operatorname{Var}(p_i)\operatorname{Var}(p_j)}
 \le \lambda_*^2\sqrt{\mu_i\mu_j},
\]

which is (LTC3). Decompose

\[
 w_{ij}(b)=\mu_i(b)\mu_j(b)+c_{ij}(b),\qquad
 c_{ij}(b)=\operatorname{Cov}_{U\mid b}(p_i,p_j).
\]

The latent-profile identity from note 205 gives

\[
 \operatorname{TV}=\frac{\mathbb E_b|w_{ij}(b)-\gamma_{ij}|}{2\gamma_{ij}},
 \qquad \gamma_{ij}=\mathbb E_bw_{ij}(b).
\]

By (LTC4) and (LTC3),

\[
 \mathbb E_b|w_{ij}-\gamma_{ij}|
 \le(\eta_{\rm marg}+2\kappa_{\rm top})\bar\gamma_{ij},\qquad
 \gamma_{ij}\ge(1-\kappa_{\rm top})\bar\gamma_{ij},
\]

which proves (LTC5).

## What BMVY supplies

BMVY Lemma 2.8, applied inside the link \(X_b\), gives the generic conditional bound

\[
 \lambda_b\le
 \sqrt{\frac{k-s}{d-s}}+\operatorname{poly}(d)\gamma_b,
 \tag{LTC6}
\]

in the parameter range \(1<k-s<d-s\), provided the link has the required one-sided
local spectral-expander parameter \(\gamma_b\). In the BMVY partite family, their
link-wise color graph bound together with their Lemma 2.11 gives the alternative
source-specific route

\[
 \lambda_b\le \operatorname{poly}(d)\,\frac{2}{\sqrt{\mathfrak q}},
 \tag{LTC7}
\]

for the relevant weighted incidence graph, where \(\mathfrak q\) is the field/complex
parameter in their construction. The measures must be the conditional face measures
of the shared-top sampler; an implementation with a different marginal needs an extra
total-variation comparison.

The one-face BMVY profile controls the marginal term in (LTC4), but it must be used with
the correct scale. If \(\sigma_i^2=\operatorname{Var}_b\mu_i(b)\), then the centered
product identity gives

\[
 \mathbb E_b|\mu_i(b)\mu_j(b)-\bar\gamma_{ij}|
 \le \mu_j\sigma_i+\mu_i\sigma_j+\sigma_i\sigma_j.
 \tag{LTC8}
\]

If \(\sigma_i^2\le\theta^2\mu_i\) and
\(\bar\gamma_{ij}\ge c_\gamma\mu_i\mu_j\), this implies

\[
 \eta_{\rm marg}\le \frac1{c_\gamma}\left(\frac{\theta}{\sqrt{\mu_i}}+
 \frac{\theta}{\sqrt{\mu_j}}+\frac{\theta^2}{\sqrt{\mu_i\mu_j}}\right).
 \tag{LTC9}
\]

Therefore constant cluster mass yields \(O(\theta+\theta^2)\), while a vanishing mass
window must retain the displayed \(\mu_i,\mu_j\) dependence. The stronger
\(O(\theta/\mu_0)\) shorthand is not valid from the variance profile alone; it requires
a relative profile \(\sigma_i\le\theta\mu_i\), or an equivalent extra hypothesis.

## Finite sanity check

For the complete link with \(n=8,d=6,k=4,s=2\), the conditional inclusion matrix has
second singular value \(1/2\). Exhaustive enumeration of the \(15\) top and \(15\) left
faces verifies (LTC2) for all tested indicator clusters and verifies (LTC3) for random
pairs. This is only a normalization check; the theorem is the operator argument above.

## Boundary and status

This closes the latent-\(U\) covariance gate for factorized cluster events under the
link-spectral and marginal-product hypotheses. It does not handle non-factorized
cross events, cover-sheet assignments, or the RW address-scale evaluator. In particular,
it is a source-specific Closure module, not a proof that GMWZ's full coordinate-robust
construction already exists.

## Sources

* Bafna--Minzer--Vyas, [Lemma 2.8, Lemma 2.11, and Theorem 2.13](https://arxiv.org/html/2407.12762).
* Gur--Minzer--Weissenberg--Zheng, [shared-top construction and Lemma 6.3](https://arxiv.org/html/2512.12960#S6.1).
* [Latent-top pair-incidence identity](205-latent-top-pair-incidence-closes-shared-top-transfer-2026-08-17.md).
