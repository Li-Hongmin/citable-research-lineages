> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 小置换轨道的 membership 算法性闭合（2026-08-15）

## 定理

固定有限 fan-in-2 basis、拓扑 gate-list 语法和 output selectors。令
\(n=2^m\)、\(h_m(r)=r_1\)，并沿用
\(\mathsf{Orb}_{m,t}(h)=\{h_m\circ A^{-1}:A\in\mathsf{PermCirc}_{m,t}\}\)。
对统一 schedule \(t=t(m)\)，假设 \(t(m)\) 是固定、可由 \(m\) 在
\(\operatorname{poly}(n)\) 时间内取得的参数序列，并置

\[
D_t=t(2^t+1).
\tag{1}
\]

为保护 \(r_1\) 可能是一个未被 gate support 捕获的直接输出，再置

\[
D'_t=D_t+1.
\tag{2}
\]

若

\[
\bigl(D'_t+t\bigr)\log_2(m+t+2)=O(m),
\tag{3}
\]

则全长度语言

\[
L_t=\bigcup_{m\ge1}\mathsf{Orb}_{m,t(m)}(h)
\tag{4}
\]

（非二次幂长度拒绝）属于 \(\mathsf P\)。

例如，满足
\[
t(m)\le \log_2m-2\log_2\log_2m+O(1)
\tag{5}
\]
的 schedule 满足 (3)；用 truth-table 长度 \(n=2^m\) 表示，这已经关闭了
\(t=O(\log\log n-2\log\log\log n)\) 的一整段参数区间。

## 枚举算法

输入是显式 truth table \(y\in\{0,1\}^{n}\)。算法枚举以下有限对象：

1. 一个至多 \(t\) 门的拓扑 gate list \(G\)；
2. \(k\le t\) 个被 output selectors 选中的非直接 gate wires、\(k\) 个 output positions
   \(P\subseteq[m]\)，以及两者之间的有序双射；
3. 被直接 selectors 遗漏的 \(k\) 个输入变量 \(J\subseteq[m]\)；
4. 令 \(S\) 为这 \(k\) 个 gate wires 的原始输入 support，定义受保护的直接变量集合
   \[
   R=(S\setminus J)\cup(\{1\}\setminus J),
   \tag{6}
   \]
   把 \(R\) 中的直接输入变量注入到剩余 output positions 的一个映射 \(\phi\)。

对每个枚举项，把尚未指定的直接 output positions 按字典序填入剩余的
\([m]\setminus J\) 输入变量，得到一个完整的 \(m\)-输入、\(m\)-输出电路 \(A'\)。逐个
枚举 \(r\in\{0,1\}^{m}\)，检查

\[
A'\text{ 是置换}
\qquad\text{且}\qquad
y_{A'(r)}=r_1.
\]

有一个枚举项通过就接受。

## 完整性

若 \(y=h_m\circ A^{-1}\)，取真实电路 \(A\) 的 gate list、非直接输出集合 \(K\)、遗漏变量
\(J\)、输出位置 \(P\) 和真实映射 \(\phi\)。置换性迫使直接 selectors 两两不同，所以
\(|J|=|K|=k\)。每个 gate wire 至多依赖 \(2^t\) 个输入，故

\[
|S|\le k2^t.
\tag{7}
\]

固定 \([m]\setminus J\) 后，\(K\) 个 gate outputs 对 \(J\) 必须是双射；否则两个输入会有
相同的完整 \(A\)-输出。若 \(1\in J\)，则 \(f=h_m\circ A^{-1}\) 只依赖 \(K\) 的输出坐标和
\(S\setminus J\) 的直接输出坐标；若 \(1\notin J\)，则 \(f\) 是 \(r_1\) 对应的直接
output position \(\phi(1)\)，而该 position 已由 \(R\) 保护。统一地，\(f\) 只依赖
\(K\cup R\)，共至多

\[
k+|R|\le D'_t
\tag{8}
\]

个坐标。枚举项保留 \(R\) 中直接 output positions 的值；只改变其余直接输出的填充不会改变
\(f\)。同时，固定
的 gate outputs 对 \(J\) 仍是双射，故任何对剩余直接 inputs 的排列填充都保持 \(A'\) 为置换。
因此真实 \(A\) 对应的枚举项通过 (5)。

反向地，任何通过 (5) 的 \(A'\) 本身就是 size-\(t\) 置换，且
\(y(A'(r))=r_1\) 对所有 \(r\) 成立，故 \(y=h_m\circ A'^{-1}\) 属于轨道。算法正确。

## 运行时间

固定 \(G\) 后，\(k,J,P,\phi\) 的总枚举数至多为

\[
2^{O((D'_t+t)\log(m+t+2))}.
\tag{9}
\]

每个候选只需 \(n\) 次门电路求值和一个显式 collision check，因此总时间至多为

\[
\operatorname{poly}(n,m,t)\cdot
2^{O((D'_t+t)\log(m+t+2))}.
\tag{10}
\]

由 (3)，式 (10) 是 \(n^{O(1)}\)。这证明 \(L_t\in\mathsf P\)，不是只给出 NP 证书。

## 对主路线的裁决

note 099 的 support-junta 计数现在升级为一个算法性 no-go：

\[
\boxed{
(D'_t+t)\log(m+t+2)=O(m)
\Longrightarrow
L_t\in\mathsf P.
}
\tag{11}
\]

因此小置换轨道不能承载所需的 range-membership hardness；任何继续使用固定标签置换
quotient 的路线，至少必须进入
\[
(D'_t+t)\log(m+t+2)=\omega(m)
\]
的参数区间。这个结论不覆盖 \(t=n^{\beta}/(m+1)\) 的 hardness-magnification 族，
也不提供一般 \(t\) 的 circuit lower bound；它只关闭了一个此前尚未被算法性排除的低门区间。

原文核验日期：2026-08-15。
