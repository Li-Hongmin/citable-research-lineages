> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW 首块熵与 \(k\)-bit range coverage gate（2026-08-18）

## 结论

C373 给出了单个首块 fiber 的 parent-binding 代价。本 note 把它提升到目标族的
coverage 量词：一个输入长为 \(k\) 的 AVOID decoder 最多覆盖 \(2^k\) 个
\(2k\)-bit 首块值。因此，若 RW canonical proof 族的首块具有超过 \(k\) bits
的 min-entropy，则不可能让同一个 \(G\) 对所有目标都进入首块 coverage。

这不是对单一 hard target 的下界；它精确区分了两种 Closure：

* **single-target：** 首块可以被一个 \(G\) 特别覆盖，熵 gate 不触发；
* **simultaneous family：** 首块必须对所有目标共用同一个 range，首块熵直接
  产生 success 分支和 descriptor 代价。

## 首块 coverage 定理

令 \(M\) 是目标变量，\(\Pi_M\) 是同一 proof/address space 中的 canonical proof，
并令

\[
 Z:=\operatorname{pref}_{2k}(\Pi_M)\in\{0,1\}^{2k}.
\]

固定 \(G:\{0,1\}^{k}\to\{0,1\}^{2k}\)，记
\(R=\operatorname{Range}(G)\)，故 \(|R|\le 2^k\)。若 \(Z\) 的 min-entropy

\[
 H_\infty(Z)\ge h,
\qquad
 \max_z\Pr[Z=z]\le 2^{-h},
\tag{374.1}
\]

则

\[
 \Pr[Z\in R]\le |R|\,2^{-h}\le 2^{k-h}.
\tag{374.2}
\]

换言之，至少

\[
 1-2^{k-h}
\tag{374.3}
\]

的目标首块不在 \(G\) 的 range 中。对这些目标，只要具体 JK 实现把首个
non-range block 作为 success output（或该 block 是唯一首层 non-range block），
solver-success 会在第一层发生，不能调用 failure/Reconf 的 whole-word recovery。

### 证明

由 (374.1)，任意 \(z\in R\) 的概率至多 \(2^{-h}\)。对 \(R\) 求和得到
\(\Pr[Z\in R]\le |R|2^{-h}\)，再用 \(|R|\le2^k\)。证毕。

## Descriptor 熵代价

设 \(\mathcal M\) 是均匀目标族，\(|\mathcal M|=2^H\)，且目标到 canonical proof
\(\Pi_M\) 是 injective（或 proof 至少能确定目标）。在未覆盖的首块分支上，若
一个共同的 decoder 使用首块 \(Z\) 与 target-dependent descriptor \(S\)，并精确恢复
目标：

\[
 D(Z,S)=M,
\tag{374.4}
\]

则

\[
 H(S)\ge H(M\mid Z)
          \ge H-\log_2|\operatorname{supp}(Z)|
          \ge H-2k.
\tag{374.5}
\]

若整个目标族都满足首块 coverage，则 \(Z\in R\)，从而
\(\log|\operatorname{supp}(Z)|\le k\)，增强为

\[
 H(S)\ge H-k.
\tag{374.6}
\]

式 (374.5) 说明：首块输出至多揭示 \(2k\) bits；它不能让一个高熵目标族免费
获得同一 parent-binding descriptor。式 (374.6) 则说明，即使首块 coverage
成功，range 本身只能承载 \(k\) bits 的 target information。

## RW 参数窗口

对 \(M=x\in\{0,1\}^{n_i}\) 的 family，若首块映射 \(x\mapsto Z_x\) 具有
min-entropy \(h_i\), 则：

* published RW stable stage 的 \(k_i=n_{i+1}=n_i^C\) 满足 \(k_i\gg n_i\)；
  因而单凭输入族熵不能排除首块 coverage。这解释了为什么 C374 不替代 C278
  的 history-supply 或 policy-information trilemma；
* 任何真正 address-scale attachment 若取
  \(k_i=\operatorname{poly}(\log T_i)\)，而实际首块族仍有
  \(h_i>k_i\)，则 (374.3) 给出一个常数甚至趋近 1 的 solver-success 质量；
  这部分目标不能进入 published failure/Reconf；
* 要保留 simultaneous address-scale Closure，必须把首块熵压到 \(k_i\) bits
  以内，或者让 target descriptor 支付至少 \(h_i-k_i\)（未覆盖时至少
  \(h_i-2k_i\)）的 information。后者在近线性 family 中是 message-scale
  payment，而不是地址尺度压缩。

## 与 C373 和 RW canonical proof 的关系

C373 对一个固定 \(z\notin R\) 展示了 suffix fiber；C374 说明在高熵目标族中，
这样的 uncovered \(z\) 不能只靠挑选 \(G\) 对所有目标消除。Theorem 3.5 只保证
\(\widetilde w\) 的 systematic witness 部分，未给出 \(\Pi'\) 的后缀 coverage，
所以它也不自动提供 (374.2) 的反向结构。一个成功的 RW-specific 正向构造必须
明确证明：

1. 首块族的熵确实降到 \(k\) bits；
2. 每个首块都由同一 \(G\) 的 range 覆盖；
3. 进入后续 JK stages 后，structured suffix 仍有统一 target binding。

只证明“每个目标存在一个合法 PCP proof”不满足这三个条件。

### Published recurrence 的量词边界（C375）

Theorem 4.3 的实际递推在每个 stage \(i\) 固定 \(x_0=0^{n_0}\)，并令

\[
f_i(x)=B_i\,0^{T_i-2n_i}
\]

对所有输入 \(x\) 都相同，随后只调用
\(\mathrm{Solve}_{f_i}(x_0,G_{n_{i+1}})\)。因此该 published call 的实际目标分布是
singleton；若 \(Z_i\) 表示所使用的唯一 proof 的首块，则

\[
H_\infty(Z_i)=0.
\]

这解释了为什么 C374 不会自动在 Theorem 4.3 上产生 family-level success 质量。
若人为把输入扩成一个 \(x\)-family，Theorem 3.5 只保证 systematic witness/output 字段的
语义，并未给 auxiliary \(\Pi'_x\) 或完整首块一个统一 selector；所以不能把“\(f_i\) 忽略
输入”升级为“完整 canonical proof 族零熵”。这一精确 source audit 见
[C375](375-published-rw-recurrence-singleton-target-zero-entropy-2026-08-18.md)。

## 边界

本定理是信息论的 family-level coverage gate，不是一般 ACRR/RLDC 不可能性定理，
也不是 \(P\ne NP\) 证明。它不排除 single-target hardwiring，也不判断实际 RW
canonical family 的首块 min-entropy；它把该未知量变成一个可直接测量、会改变路线
选择的参数。

来源：Ren--Williams Theorem 3.1、3.5、4.1；C373；以及本项目对
systematic-prefix 与 auxiliary-proof 量词的审计。
