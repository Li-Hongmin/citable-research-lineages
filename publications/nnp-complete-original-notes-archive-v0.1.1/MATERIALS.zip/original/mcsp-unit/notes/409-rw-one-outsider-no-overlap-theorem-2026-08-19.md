> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW/JK single-outsider Closure 的三尺度不重叠定理（2026-08-19）

## 本轮改变的判断

C380/C381 已分别给出两件事：在 source-compatible systematic projection 下，足够小的
JK width (k) 会排除 easy branch；而一个成功 block 的 half-lift 至多暴露一个
(2k)-bit top block。此前这两条结果仍可能被误读为“再调一个合适的 (k) 就能完成
parent closure”。本 note 证明，在 published RW 的稳定参数和同长度 forcing 下，
这两个要求没有重叠窗口：

* 排除 easy 所需的是 (k=O(n_i^{1/4}/sqrt{log n_i})) 以下；
* 一个 outsider 单独承载长度 2n_i 的 parent 则至少需要 k >= n_i。

因此，**single-outsider + direct output block** 不是 published RW 的 Closure
接口。下一步必须引入多个 attached blocks、一个新的 global relation，或改变
forcing object；继续在单个 (k) 上优化不能改变这个结论。

## 假设与记号

固定 Ren--Williams Theorem 4.3 的稳定 stage (i)。令

\[
  b_i=2n_i,
  \qquad T_i=n_{i+1}=n_i^C,
  \qquad L_i=|\Pi_{x_0}|,
  \qquad |G_k|\le k^4.
\]

假设采用 source-compatible 的二进制 proof serialization，使 Theorem 3.5 的
systematic output projection 可由 proof address (r'_i+j) 读取；这正是 C380 的
假设。再假设在同一无限长度集上有 forcing lower bound

\[
  \operatorname{CC}(B_i)\ge s_i,
  \qquad s_i\ge c\,\frac{n_i}{\log(n_i+2)}.
\tag{409.1}
\]

Theorem 3.5 只需给出 (L_i\le T_i^{c_0})（固定 (c_0)），故

\[
  \log(L_i+2)=O(\log n_i).
\tag{409.2}
\]

这里不假设 first failure 已在 output 区间；先只分析即使它已经 output-attached
时，single-outsider 路线是否有参数窗口。

## 定理 409.1（hard-exit / one-block capacity 不重叠）

在上述假设下，存在常数 (c_1,c_2>0)，使得对充分大的 (n_i)：

1. 若
   \[
      k\le c_1\frac{n_i^{1/4}}{\sqrt{\log(n_i+2)}},
   \tag{409.3}
   \]
   则 C380/C381 的 easy-branch 上界低于 (s_i)，因而 JK 必返回一个
   (2k)-bit non-range outsider。

2. 若这一个 outsider 通过已知 ancestry/path 只用于恢复一个 top
   (2k)-bit block，则要直接恢复整个 (b_i=2n_i)-bit parent，必要条件是
   \[
      2k\ge b_i,
      \qquad\text{即}\qquad k\ge n_i.
   \tag{409.4}
   \]

3. 区间 (409.3) 与 (409.4) 对充分大的 (n_i) 不相交。于是以下三段互斥地覆盖
   所有 (k)：

   \[
   \begin{array}{c|c|c}
   k\text{ 尺度}&\text{easy 是否由 forcing 排除}&\text{single outsider 是否足以装下 parent}\\
   \hline
   k\ll n_i^{1/4}/\sqrt{\log n_i}&\text{是}&\text{否，除非引入额外全局关系}\\
   n_i^{1/4}/\sqrt{\log n_i}\lesssim k<n_i&\text{未知}&\text{否}\\
   k\ge n_i&\text{未知，C380 不再给出排除}&\text{宽度上可以，但 hard-exit 未闭合}.
   \end{array}
   \tag{409.5}
   \]

特别地，published 选择 (k_i=n_{i+1}=n_i^C) 落在第三段；它不能由
C380/C381 推出 success outsider。选择 address-scale (k_i=\operatorname{polylog}(n_i))
落在第一段；它能推出 outsider，却不能由 single block 恢复 parent。

### 证明

由 C380/C381，任何 easy branch 都给出

\[
  \operatorname{CC}(B_i)
  \le c_2(k^4+1)\log(L_i+2).
\tag{409.6}
\]

代入 (409.2)，若

\[
  c_2(k^4+1)\log(L_i+2)<c\frac{n_i}{\log(n_i+2)},
\]

则与 (409.1) 矛盾。取 (c_1) 足够小即得 (409.3)。

另一方面，C382 的正确 half-lift 只从一个 outsider 恢复一个顶层
(2k)-bit block；它不把左右两半拼成 (4k) bits，也不自动产生别的
output-attached blocks。因此在没有额外 global relation、descriptor 或第二个
独立 outsider 的前提下，exact 恢复 (b_i)-bit parent 至少要求该 block 的
payload 长度 (2k) 不小于 (b_i)，即 (409.4)。显然

\[
  c_1 n_i^{1/4}/\sqrt{\log n_i}<n_i
\]

对充分大的 (n_i) 成立，得到不相交性和 (409.5)。证毕。

## 稳定 stage 的直接参数后果

把 published 的 (k_i=n_i^C) 代入 easy 上界，只能得到

\[
  c_2(k_i^4+1)\log(L_i+2)
  =n_i^{4C+o(1)},
\tag{409.7}
\]

而 forcing 侧只有 (\Omega(n_i/\log n_i))。所以 stable call 既没有由
forcing 排除 easy，也没有一个 source-level 理由使 first failure 落在
systematic output。C408 的 Harsha proof-length 审计只把 (L_i) 的实际规模
收紧到 (N_i^{18+o(1)})（在标准 field-table serialization 下）；它不会反转
(409.7)，因为该长度只增加 (409.6) 的对数因子。

反过来，把 (k_i) 压到 address scale 会使 (409.6) 小于 forcing threshold，
这是一个真正的 hard-exit；但此时 (2k_i=o(b_i))。若允许 (q) 个 output-attached
outsiders 和 (d)-bit descriptor，在 target-oblivious parent family 上，C378
给出必要条件

\[
  2k_iq+d\ge \log_2|\mathcal B|.
\tag{409.8}
\]

对 identity-size (b_i)-bit family，右端为 (b_i)；因此
\(k_i,q,d=\operatorname{polylog}(b_i)\) 仍不能完成 whole-parent binding。
published Theorem 4.3 的 (x_0) 是 singleton，不能把 (409.8) 偷换成对该
singleton 的无条件不可能性；它只说明 single-outsider 路线没有 source-independent
容量闭合。

## 对 Closure Theorem 的新边界

定理 409.1 把 Gate-I 的选择压成三个真正不同的问题：

1. **address-scale hard exit + multi-block/global relation：** 证明多个 outsider
   的同一对象绑定，或直接构造一个 relation-PCP，使 (2kq+d) 不按 C378 线性支付；
2. **large-width semantic closure：** 在 (k\ge n_i) 的 object-scale 区间，证明
   即使 JK 可能进入 easy，solver-success branch 仍能给出同一个 (H_A\in P/\mathrm{poly})；
3. **forcing-object redesign：** 选择一个父对象的 forcing 下界与 JK width 同尺度，
   使 (409.3) 和 (409.4) 的不重叠不再适用。

在没有这三者之一前，不能把“C380 已强制 outsider”升级为 Closure Theorem，
也不能把 published stable (k_i=n_i^C) 写成 hard-exit。

## 证据边界

* C380/C381：systematic projection 与 easy-branch hard-exit 上界；
* C382：single outsider 只恢复一个 (2k)-bit top block；
* C378：多 outsider/descriptor 的 target-oblivious parent-binding 容量界；
* C408：Harsha proof length 的 source-level (18+o(1)) 指数审计；
* Ren--Williams Theorems 3.1, 3.5, 4.1, 4.3：JK 输入 proof、systematic
  history/output 与 published stable recurrence。

本定理是对 **single-outsider direct-block Closure route** 的 source-specific
路线关闭，不是 (P\ne NP) 证明，也不是对所有 RW-specific global relation
构造的不可能性定理。它保留的正攻正是用户所说的 Closure Theorem，而不是继续
增加局部 decoder 障碍。
