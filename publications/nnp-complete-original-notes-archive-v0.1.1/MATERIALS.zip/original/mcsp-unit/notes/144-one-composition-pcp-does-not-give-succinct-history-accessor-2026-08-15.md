> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 单次组合 PCP 仍不提供 succinct history accessor（2026-08-15）

## 要区分的接口

设基础输入长度为 \(n\)，而 Ren--Williams/JK 路线需要处理长度

\[
  T=2^{n^\eta},\qquad \eta>0,
\]

的固定计算历史。所需的对象不是一个“存在某个证明”的断言，而是一个固定、整词一致的访问器

\[
  A_n(i,\ell)=\Pi_n[i,\ell],
\]

其中 \(i\) 是历史块地址，\(\ell\) 是块内坐标，且 \(A_n\) 的电路规模为
\(n^{O(1)}\)。若还要把访问到的词送入 decoder，则需要一个确定的 canonical
right inverse；同一历史词在不同 occurrence 上不能由彼此无关的 selector 重新编码。

这比 PCP verifier 的要求强得多。PCP 只需要从一个存在的 proof oracle 中读取少数位置，
并不要求 proof 本身由输入在地址尺度上可计算地产生。

## 文献事实：一次组合确实降低了局部验证成本

Amireddy--Behera--Srinivasan--Sudan--Willumsen 的 *Ideals, Macaulay Bases, and PCPs*
（ECCC TR25-165, revision 3）给出了一次组合的 PCP 构造。其正式参数以显式的
有限域/代数簇和显式 3-COLOR 实例为输入；Theorem 2.3 的随机性、查询数和 proof size
都由 \(q,m,d,k\) 以及该显式实例的规模控制。其 Lemma 2.5 给出一个有
\(O(\log N)\) 随机位、\(O(1)\) query、polylog alphabet、\(N^{O(1)}\) proof size
的 3-COLOR PCP（这里 \(N\) 是显式图的顶点/实例规模）。论文的主贡献是把两类
robust assignment tester 只组合一次，而不是把 verifier 变成一个 history encoder。

Goldreich 的 *Proving PCP Theorem with 1.5 Proof Compositions*（ECCC TR25-182）
同样说明了低查询、低随机性的 PCP 可以通过不同的组合方式获得；它也没有声明
canonical proof encoder 或整词随机访问器。

## 把 Cook--Levin 历史代入时，规模参数不会变成 \(n\)

对 \(T\)-步计算作普通 Cook--Levin 编码，得到的显式约束/图规模记为

\[
  N=T^{O(1)}.
\]

因此，Lemma 2.5 型结论至多给出

\[
  O(\log N)=O(\log T)=O(n^\eta)
\]

个随机位和 \(N^{O(1)}=T^{O(1)}\) 量级的 proof。前一项对 \(n\) 仍是多项式，
但后一项并没有把证明或历史压缩成 \(\operatorname{poly}(n)\) 个可生成的标签。
更关键的是，verifier 得到的是 proof oracle 的少数**查询答案**；论文没有给出

\[
  (i,\ell)\longmapsto \Pi_n[i,\ell]
\]

的 \(n^{O(1)}\)-size 电路。把 \(N\) 替换成 \(n\) 需要一个新的 succinct PCP/zero-on-variety
定理，而不是把现有显式定理的符号重命名。

## 为什么一次组合不自动给 canonical inverse

固定 decoder \(G_q:\{0,1\}^q\to\{0,1\}^{2q}\) 还需要：

1. 对指定的 history block，存在一个固定的 proof/word 表示；
2. 该表示在所有 occurrence 上保持 word consistency；
3. 从 block 到 seed 的选择是确定且可寻址的（例如 lex-first valid seed）；
4. 组合后的父 block 仍能沿同一个规范化规则继续访问。

PCP 的 soundness/completeness 只说明“存在一个满足局部测试的 proof”或“任意 proof
有较低接受率”。同一 oracle input 通常有许多等价 proof，局部测试本身不选出其中一个
canonical proof，也不保证两个子 proof 拼接后仍属于同一 \(G_q\) 的 range。因此，
一次组合消除了一个 verifier-composition 层，并没有消除 decoder 的 range/selector
问题。

## 可证伪的下一个正向目标

若要把这条文献路线接到地址尺度，至少需要一个单独的 **succinct zero-on-variety
history tester**，其输入是大小 \(2^{n^\eta}\) 的隐式 transition circuit，却同时满足：

\[
\begin{aligned}
&\text{query locations and predicates are computable in }n^{O(1)},\\
&\text{a fixed accepted proof has a word-consistent }n^{O(1)}\text{-size accessor},\\
&\text{the accessor admits a canonical }q\text{-bit normalized right inverse}.
\end{aligned}
\]

现有 TR25-165/TR25-182 的正式结论没有给出这三个附加性质。因而它们是 RW/JK 的
有用局部验证组件，但不是“已有 succinct history decoder”的文献证明。

## 结论与边界

本 note 的新判断是：

\[
\boxed{
\text{one-composition/low-query PCP}
\;\not\Rightarrow\;
\text{succinct canonical history accessor}.
}
\]

这不是 PCP 的一般下界，也不推出 \(P\ne NP\)。它只关闭了一个容易混淆的替代路线：
不能把“显式实例上的常数 query”直接当成“对 \(2^{n^\eta}\) 长历史的
poly\((n)\) 整词访问器”。

## 来源

- Amireddy--Behera--Srinivasan--Sudan--Willumsen, *Ideals, Macaulay Bases, and PCPs*,
  ECCC TR25-165 revision 3：
  [official report](https://eccc.weizmann.ac.il/report/2025/165/)。
- Oded Goldreich, *Proving PCP Theorem with 1.5 Proof Compositions*, ECCC TR25-182：
  [official report](https://eccc.weizmann.ac.il/report/2025/182/)。
