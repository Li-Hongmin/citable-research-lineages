> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Low-rate product ECC 的 universal block-cover gate（2026-08-18）

## 判定

C396 的 high-rank 分支不是唯一的合法 ECC 选择。若选择一个显式
injective linear ECC \(E_0:\mathbb F_2^a\to\mathbb F_2^b\) 的固定码率
\(R=a/b<1/2\)，则每个 \(\Upsilon\) 内部 \(2k\)-bit block 只由常数个
source symbols 决定；在一个明确的 seed-budget 不等式下，可以构造
\(P\)-uniform \(G_k\) 覆盖所有可能的 product-ECC blocks。这个结果把
“ECC auxiliary 是否可被 range-cover”从未知 image 问题变成了码率和
segment-boundary 参数。

## Theorem 400.1（product-ECC universal block cover）

令 \(E_0:\mathbb F_2^a\to\mathbb F_2^b\) 是 injective linear encoder，
其编码电路大小为 \(O(a)\)，令 \(R=a/b<1/2\)。把
\(E_0^{\oplus N}\) 的 codewords 连续排列。定义
\[
  Q_k:=\left\lceil\frac{2k}{b}\right\rceil+1 .
\]
若
\[
  Q_k a+\lceil\log_2 b\rceil+1\le k,
\tag{400.1}
\]
则存在 \(P\)-uniform、大小 \(k^{O(1)}\) 的
\[
  G_k:\{0,1\}^k\to\{0,1\}^{2k}
\]
使得每一个完全位于该 product-ECC stream 内的长度 \(2k\) interval
都落在 \(\operatorname{Range}(G_k)\)。

### 证明

seed 编码包含：

1. 至多 \(Q_k\) 个 source symbols，共 \(Q_ka\) bits；
2. 第一个 codeword 内的起始 offset \(\sigma\in\{0,\ldots,b-1\}\)，需
   \(\lceil\log_2b\rceil\) bits；
3. 一个 tag/length convention，需 1 bit。

Generator 在这些 symbols 上并行运行 \(E_0\)，从 offset \(\sigma\)
开始截取连续 \(2k\) bits，并按需要补固定 padding。一个长度 \(2k\)
interval 至多穿过 \(Q_k\) 个 codewords，故该 seed 覆盖所有 interval。
(400.1) 允许零填充到恰好 \(k\) bits。每次编码调用大小 \(O(a)\)，总电路
大小 \(O(Q_ka)=O(k)\)；若 \(a,b\) 及 offset arithmetic 是 uniform
可计算的，则得到 \(P\)-uniform generator。证毕。

## 码率窗口

因为
\[
 Q_ka\le 2Rk+2a,
\]
一个方便的充分条件是
\[
 (1-2R)k\ge 2a+\lceil\log_2 b\rceil+1.
\tag{400.2}
\]
例如 \(R\le1/3\) 且 \(k\ge6a+O(\log b)\) 时成立。Harsha 的
alphabet-reduction 只要求常数相对距离、\(b=O(a)\) 与显式 encoder；
因此这是一个合法的 source-level rate branch，前提是所选显式 good-code
family 在该固定 rate 提供这些参数。

## RW/JK 影响与边界

若 C398 的 \(\Upsilon\) segment 足够长，Theorem 400.1 可以覆盖其中所有
内部 top-level blocks，与 proof family、\(\Gamma_x\) 的 nonlinear image
和 parent distribution 无关。它不覆盖 \(\widetilde w/\Gamma\) 与
\(\Upsilon\) 的 boundary blocks；这些需要 padding、单独 generator branch
或 public metadata。

更重要的是，覆盖 auxiliary \(\Upsilon\) 不等于 forcing first failure
进入 systematic output：\(\widetilde w\) 或 \(\Gamma\) 的 block values
可能也落在同一个 \(G_k\) range。要把该 gate 接成 RW Closure，还必须证明
systematic output 有一个不在 auxiliary-cover range 中的 target-separated
block，或证明所有非输出 blocks 都可被同一个 generator 覆盖并处理边界。
因此 C400 是一个正向编码 theorem，不是 \(P\ne NP\) 或 published singleton
closure。

## 来源

* Harsha thesis, Lemma 2.4.5 and §5.4.3:
  <https://dspace.mit.edu/handle/1721.1/26720>.
* C396--C399：product rank、serialization、support 与 actual-family
  dichotomies.
