> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 已知 PCPP+RLDC 变换与 ACRR 的通信压缩缺口（2026-08-16）

## 结论地位

本 note 把 note 183 的 exposed-history 组合放回一个已有的通用 PCPP 变换中，并由此
精确定位 ACRR 的新问题。这里的 PCPP+RLDC 组合不是本项目的新定理；真正的新目标是
在不传输完整 implicit history 的情况下保留同一 proof、指定坐标鲁棒性和 RW 地址尺度。

## 已知变换：pair-language PCPP 加 RLDC

设 `L` 是显式输入 `x` 长度为 `m`、隐式输入 `w` 长度为 `n` 的 pair language。设

\[
  C_n:\{0,1\}^n\to\{0,1\}^{n'}
\]

是相对距离为 `δ`、解码半径 `δ/2`、查询复杂度 `q_RLDC(n)` 的 relaxed locally
decodable code。令

\[
  L' = \{(x,C_n(w)):(x,w)\in L\}.
\]

如果 `L'` 有通信复杂度 `cc(n)`、查询复杂度 `q(n)`、proximity 参数 `δ/2`、soundness
`1/2` 的 PCPP，那么对任意 `α>0`，已有变换给出 `L` 的 PCPP：

\[
\begin{aligned}
  \text{communication} &= n' + cc(n),\\
  \text{queries} &= q(n)+q_{\mathrm{RLDC}}(n)\,O(1/\alpha),\\
  \text{proximity} &= \alpha,\\
  \text{soundness} &= 1/2.
\end{aligned}
\]

验证时间增加 `T_RLDC(n)O(1/α)`，prover 时间增加编码时间 `T_enc(n)`。证明的第一段
直接放置 `C_n(w)`；随后运行 `L'` 的 PCPP；若其局部检查通过，再随机抽取隐式坐标并用
RLDC 做局部解码。这个结果是 Mie09 型 pair-language PCPP 变换，在
[Athamnah--Ron-Zewi--Rothblum, Appendix A, Lemma A.3](https://eccc.weizmann.ac.il/report/2025/090/download/)
中被明确陈述。

## 对 exposed-history 基线的精确解释

在 note 183 中，把 `w` 取为完整 computation history（长度记为 `T`），把输出词或
target-binding message 经过 `C_T` 编码，再对编码后的关系运行 PCPP，正是上述变换的
一个坐标化实例。它确实解决了三个语义问题：

1. 所有坐标使用同一个隐式 history/codeword 与同一个 auxiliary proof；
2. RLDC 负责读取坐标，避免为每个坐标重新选择 witness；
3. PCPP 负责把编码对象绑定到同一个关系，而不是允许逐坐标 phantom witness。

但这条变换的通信下界是结构性的：第一段必须承载 `C_T(w)`。对二进制 injective code，
`n'\ge T`；对一般有限字母表，通信比特数至少满足相应的注入熵下界。因此只要 RW 的
history 长度 `T` 超过 `poly(n,\log T)`，已知变换就不能满足 ACRR 的地址尺度。把这段
编码词改名为 `canonical key`，或把它放进 nonuniform advice，都不会改变这个通信
事实。

这也修正 note 183 的贡献表述：它是一个严格的 exposed-history 正向基线和参数化实例，
不是一个尚未被文献覆盖的 PCPP+RLDC 组合定理。

## 真正的顶级目标：communication-compressed target-binding PCPP

需要研究的对象可精确定义为一个压缩变换 `CC-TP`。对同一个关系 `L_x`、同一个全局
proof address space 和所有输出坐标 `i`，要求：

1. **同一 proof：** 一个 `\Pi_x` 同时服务所有 `(i,b)`，不允许 `\Pi_{x,i,b}`；
2. **完备性：** `b=f_x[i]` 时同一 honest proof 以概率 1（或固定高阈值）接受；
3. **坐标鲁棒性：** `b\ne f_x[i]` 时任意候选 proof 的接受率至多 `\varepsilon<1/2`；
4. **压缩通信：** 第一段 implicit-history/target-binding 通道长度
   `s(n,T)=poly(n,\log T)`，而不是 `n'\ge T`；
5. **局部性与统一性：** query、随机边、decoder 和 verifier 描述都在
   `poly(n,\log T)`，且由固定算法生成；
6. **无隐藏 advice：** `s` 不能只是完整 history 的非均匀重编码。

这就是 ACRR 的通信版本。它比“近线性 dPCP”多一个关键量词：近线性 proof 长度本身
不够，必须同时压缩 implicit history 的通信，并保持 target-binding。

## 与 distributional soundness 的关系

distributional soundness 可能帮助第 1--3 项，尤其是组合多个局部检查时维持同一全局
对象；但它本身不删除 `n'` 这段通信。要把它升级成 `CC-TP`，必须另证一个“分布式
一致性 + 压缩 history channel”定理。仅有平均坐标/list soundness，不能替代坐标鲁棒性；
仅有 shared address space，也不能替代 target-binding。

## 两个互斥的可交付结果

### 正向结果

构造 `CC-TP`，并给出完整参数 `s,q,\varepsilon`、uniformity、同一 proof 语义和与
RW/JK 的地址尺度对齐。这将是一个独立的 succinct relation-PCP/ACRR 定理；如果还能
保持近线性总 proof 长度，则其价值高于单纯的 RW 应用。

### 反向结果

证明任意满足 `CC-TP` 的对象必然给出某种过短 RLDC/LDC，或证明对某一关系必须有
`s=\Omega(T)`、超线性 query 或额外 uniformity 代价。在线性 projection-robust 特例中，
已有 RLDC/LDC 下界可作为校验；一般非线性情形仍需新的 reduction，不能把类比写成定理。

## 复杂度边界

如果一个统一 compiler 对所有 NEXP history relations 都提供 `poly(n)` key 和完整
proof-address evaluator，复杂度后果取决于 verifier 的随机性量词。完美全随机性时可写成

\[
  x\in L \Longleftrightarrow \exists s\in\{0,1\}^{poly(n)}\;\forall r\;V(E(x,s);r)=1,
\]

从而得到 `NEXP\subseteq\Sigma_2^P`。标准 bounded-error 语义一般只给
`NEXP\subseteq NP^{PP}`；若随机位为 `O(log n)` 才进一步降到 `NP`。精确量词和证明见
note 194。这个边界只约束普适 compiler，不排除单一 fixed RW history 的特殊压缩，但
说明 `CC-TP` 不是普通 dPCP 的常数优化。

## 证据边界与研究决策

- 已知 PCPP+RLDC 变换：见上述 Mie09 型 Lemma A.3；本项目不把它重新计为原创定理。
- note 183 的 exposed-history 证明保留为该变换在 coordinate target 上的直接实例。
- note 121、181、182 给出 ACRR/RW 接口、编码层组合和 target-binding 纲领。
- note 194 给出完美、bounded-error 与低随机性三种复杂度语义的精确归类。
- 当前最有价值的下一项不是再造一个逐坐标 dPCP，而是判定 `CC-TP` 是否存在，或给出
  一般性 RLDC/LDC/通信下界。若候选 proof 仍显式包含 `T` 位 history，则立即归类为
  exposed-history baseline，不晋级为 ACRR 构造。
