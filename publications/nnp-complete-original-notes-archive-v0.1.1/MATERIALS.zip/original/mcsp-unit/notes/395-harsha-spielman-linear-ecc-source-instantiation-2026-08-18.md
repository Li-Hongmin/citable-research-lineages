> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Harsha--Spielman 线性 ECC 的 source instantiation（2026-08-18）

## 判定

Harsha 的二元化步骤可以合法地选用线性 ECC；“ECC 可能只是任意非线性码”不再
是 Gate-I 的真实未知量。剩余未知量是该线性码在 actual Harsha payload family
上的 block-projection profile，而不是线性性本身。

## 原始来源核验

Harsha thesis 的 Lemma 2.4.5 只要求
\[
  \mathrm{ECC}:\{0,1\}^{a}\to\{0,1\}^{b},\qquad b=O(a),
\]
具有常数相对距离，并由大小 \(O(a)\) 的显式电路计算。Section 5.4.3 将这里的
\(a\) 取为 \(\log|\Sigma|\)，再次要求 \(b=O(\log|\Sigma|)\)、常数相对距离和
大小 \(O(\log|\Sigma|)\) 的显式电路，并明确引用 Spielman [Spi96]。

Spielman, *Linear-time encodable and decodable error-correcting codes*,
IEEE Transactions on Information Theory 42(6), 1996, DOI
[10.1109/18.556668](https://doi.org/10.1109/18.556668)，其 IEEE 摘要明确描述
“asymptotically good, linear error-correcting codes”，并给出线性大小的
logarithmic-depth encoding circuits。因而在 Harsha 的参数窗口中，可以选择一个
固定率、固定距离的线性 Spielman code；这保持 \(b=O(a)\)、显式编码电路和
Harsha/RW 的 robustness 参数。

小参数长度可直接硬编码，故该结论只需对充分大的 \(a\) 成立。

## 对 C394 的升级

C394 的 Corollary 394.2 不必再把“ECC 是 injective linear code”当作没有来源的
额外猜想：它对上述合法的 Spielman instantiation 是 source-realizable。于是
linear-ECC projection dichotomy 的真正待核对量只剩

1. 线性 codeword 的 block projection ranks；
2. actual identity/payload family 的 \(\Gamma_x\) 是否在这些 projection 上提供
   足够大的 image/entropy；
3. first-stage outsider 的位置、path 和 descriptor 是否能在 C393 的 transcript
   capacity 里统一计价。

注意：Spi96 的线性码可供选择，不等于 RW Theorem 3.5 已经对每一个允许的 ECC
实现量化了 rank profile；本 note 只把一个满足原有参数的合法实例晋级为 source
evidence，不把所有 ECC 版本混为一谈。

## 边界

该 source audit 不证明 actual published singleton \(x_0\) 必然产生某个高-rank
block，也不把 identity family 的 nonlinear valid-proof image 自动视为完整
\(\mathbb F_2^L\) message space。它只消除“线性 ECC 分支没有 RW 来源”的疑问，
并把下一项实际数学问题收缩为 payload image/rank 与 parent-binding 的联合定理。

## 来源

* Prahladh Harsha, *Robust PCPs of proximity and shorter PCPs*, MIT PhD thesis,
  Lemma 2.4.5 and §5.4.3, 2004:
  <https://dspace.mit.edu/handle/1721.1/26720>.
* D. A. Spielman, *Linear-time encodable and decodable error-correcting codes*,
  IEEE TIT 42(6), 1996, DOI
  <https://doi.org/10.1109/18.556668>.
