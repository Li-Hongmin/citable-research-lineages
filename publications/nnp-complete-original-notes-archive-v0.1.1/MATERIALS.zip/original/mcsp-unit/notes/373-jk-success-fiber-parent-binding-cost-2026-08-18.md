> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK success 输出的 parent-fiber 与 binding 代价（2026-08-18）

## 结论

C372 只使用了 Theorem 4.1 的分支量词。直接展开 Ren--Williams Theorem 3.1
的 JK 算法后，可以得到更强的 source-specific 结论：

> 一个成功输出的 2k-bit outsider 本身不能区分长度 T 的父表；对满秩的
> \(G\)，精确 parent binding 至少要支付约 T/2 bits 的额外信息。

这里的下界针对 JK 的真实“首个非 range block”输出，不是抽象的黑箱计数。它关闭
“给成功 outsider 加一个短的、与地址无关的 selector 就能恢复父表”的 generic
路线；若实际 RW canonical proof 要逃逸，必须证明其 proof family 不落入下面的
fiber，或提供另一个 target-binding 关系。

## JK 首块纤维定理

令 G:{0,1}^k→{0,1}^{2k}，记 R=|Range(G)|，并取
z∈{0,1}^{2k}\Range(G)。取一个与 JK 顶层对齐的表长 T=2km，m≥2。
对每个序列 (r_2,…,r_m)∈Range(G)^{m−1}，定义

    F_(r_2,...,r_m) := z || r_2 || ... || r_m.

把这些 F 直接作为 Theorem 3.1 的 truth table 输入（若采用原文的
T′=k·2^h padding，只需把 T 取为该对齐长度）。JK 在顶层首先检查
2k-bit block z；所有其余顶层 blocks 都在 Range(G) 中。由于 z 不在
Range(G)，SAT 查询只有这一个 NO，算法输出

    JK(G,F_(r_2,...,r_m)) = ("hard", z)    for every (r_2,...,r_m).

因此同一个 success output 的 fiber 至少有 R^(m−1) 个彼此不同的父表，
即需要 (m−1)log_2 R bits 才能区分。
把“顶层、第一 block”作为额外的公开 transcript 也不改变这个纤维，因为它对所有
序列都相同。

证明：Theorem 3.1 的证明从 y_h=f′ 开始，把 y_h 分成连续的 2k-bit blocks；
若某个 block 不在 range，立即返回该 block。对上述 F，第一个 block 是唯一的
非 range block z，所以无论并列 NO 的 tie-break 如何实现，都得到相同输出。证毕。

## 信息论 binding 下界

设存在一个统一的 exact decoder
E(G,y,σ,a)=F_(r_2,...,r_m)[a]，对所有 Range(G)^(m−1) 个序列和所有地址 a
成立，其中 y=z 是 JK success output，而 σ 是允许依赖该序列的 descriptor。
若两个序列产生同一个 σ，则 decoder 对所有地址会推出两个 F 相同，矛盾。因此
序列到 σ 必须 injective，从而

    |σ| ≥ (m−1) log_2 R.

若 descriptor 必须对整个 parent family 共同固定，则 exact decoder 甚至不可能
成立；若 descriptor 可以随目标变化，上式表明它只是把 suffix 重新编码。对满秩
嵌入 G(x)=x||0^k，有 R=2^k，故

    |σ| ≥ (m−1)k = T/2−k.

这已经是 parent object scale，而不是 address scale。

## 同一纤维中的高复杂度父表

令 N_≤s(T) 表示输入地址长度 ceil(log T) 的 size-≤s 电路所能计算的
T-bit truth tables。标准门编码给出

    N_≤s(T) ≤ 2^(C s log(T+s))

其中 C 是固定常数。若

    C s log(T+s) < (m−1) log_2 R,

则上述 fiber 中至少有一个 F_(r_2,...,r_m) 满足 CC(F)>s，但它仍产生同一个
JK outsider z。对满秩嵌入且 k=poly(log T) 时，右侧为 T/2−k，可取
s=Theta(T/log T)（常数取小），得到 near-linear-hard parent 与同一个
2k-bit success output 的碰撞。

这说明“success outsider 很短，所以它应当携带父 hard table”不是信息论有效的推理；
高复杂度本身不会消除 JK success fiber。

## 对 RW Closure 的精确边界

在 Theorem 4.1 中，JK 的输入不是任意 F_(r_2,...,r_m)，而是由 canonical PCP proof Pi_x
产生的 truth table。因此上述 fiber 构造不是实际 RW canonical proof family 的
无条件反例，也不是 P≠NP 定理。它给出的边界是：

1. JK Theorem 3.1 本身不能提供 parent--child binding；对满秩 G，其 success
   output 的 generic fiber 可达到 2^(T/2−O(k))；
2. 任何声称从 JK outsider 得到地址 evaluator 的证明，必须使用 RW canonical
   proof family 的额外结构，明确排除该 fiber，或把 canonical proof 的 target-binding
   信息写入 descriptor/trace；
3. 若该额外 trace/descriptor 仍要精确恢复任意可变 suffix，则上面的信息下界强制
   object-scale 信息，不能称为 address-scale Closure。

因此 C371 的 address-scale solver 分支现在进一步分成：

    child outsider  versus  parent-binding trace/key.

前者由 JK 自动给出，后者是尚未证明且可能支付 T-scale 的新定理接口。

## Canonical proof 的首块覆盖边界

Theorem 3.5 的 completeness 只保证
\(\Pi=(\widetilde w,\Pi')\)，其中 \(\widetilde w\) 是某个合法 witness 的
Reed--Muller 编码；\(\Pi'\) 是 auxiliary proof oracles。即使 \(r=0\) 时
\(\widetilde w\) 的开头系统地包含 \(f(x)\) 的输出字段，这也只控制 proof 的一段
systematic prefix，不控制 \(\Pi'\) 的后续 \(2k\)-bit blocks 是否落在
\(\operatorname{Range}(G)\)。

因此，C373 不能被错误地改写成“RW canonical proof 已经必然落入该 fiber”，但也
不能反过来声称 Theorem 3.5 自动排除了它。要把实际 canonical family 接入
parent-binding，至少需要补充以下一种条件：

* **首块覆盖：** 对每个实际 \(\Pi_x\)，其首个 JK block 属于
  \(\operatorname{Range}(G)\)，从而 JK 必须继续向下读取 proof；或
* **结构化后缀：** 即使首个 non-range block 出现在后缀，也有一个
  \(o(T)\)-bit、统一且可执行的 descriptor 能恢复所有被跳过的 range blocks；
  或
* **显式 tie-break/唯一非像：** 证明具体 JK 实现选中的 block 对整个 canonical
  family 具有 target-binding，而不是只输出一个短的 non-range word。

这三个条件都不在 Theorem 3.5 的 completeness/soundness 量词中。故当前准确的
Gate-I 结论是：**systematic prefix 本身既不是 parent binding，也不是
first-block coverage；二者必须作为 RW-specific 新定理单独证明。**

## 来源边界

* Ren--Williams Theorem 3.1 的实际流程：从 y_h=f′ 分块，遇到首个 non-range
  block 立即返回；见本地抽取
  units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md
  第 8--10 页（约 498--548 行）。
* Theorem 4.1 只把该 JK 输出嵌入 Solve，并在相反的 failure 分支给出 Reconf；
  见同一抽取第 14--17 页。
* 本 note 的 fiber、injectivity 和电路计数是项目内自足推导；它关闭的是从 JK
  success output 到 parent evaluator 的 generic black-box 路线，不声称实际
  canonical proof family 已被完全分类。
