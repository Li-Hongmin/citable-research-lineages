> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Incidence-stable field lift: a shared dPCP becomes an RLDC (2026-08-17)

## Status

This note closes a stronger part of the field-lift route than note 217. It shows that a
family-level shared dPCP does not need an extra “near-proof soundness” axiom if its complete
decoding distribution is incidence-smooth: the proof map itself becomes a relaxed locally
decodable code. Thus a near-linear construction must pay in at least one of proof-position
incidence, outer-decoder smoothness, output-code distance, perfect completeness, or the
common-address/family quantifiers.

The statement is deliberately family-level. It does not rule out a verifier hardwired to
one target instance.

## Setup

Let

\[
  C:\{0,1\}^k\longrightarrow\Gamma^M
\]

be an injective code of relative distance at least \(\Delta_C>0\). Let a dPCP have a
single proof vertex set \(V\), finite proof alphabet \(\Sigma\), local edge distributions
\(\mathcal P_t\) for \(t\in[M]\), local decoders \(D_t\), and at most \(q_P\) proof
positions per local call. Its decoded language is

\[
  \mathcal L=C(\{0,1\}^k)\subseteq\Gamma^M.
\]

For every message \(m\), choose one perfect-completeness proof assignment
\(A_m\in\Sigma^V\), so that every sampled local edge is satisfied and

\[
  D_t(A_m|_e)=C(m)_t
  \qquad\text{for }t\in[M],\ e\sim\mathcal P_t
  \text{ almost surely}.
  \tag{1}
\]

Let \(\mathcal Q\) be the complete decoding distribution: choose \(t\) uniformly and
then \(e\sim\mathcal P_t\). Assume the following incidence bound for every proof vertex
\(v\):

\[
  \Pr_{(t,e)\sim\mathcal Q}[v\in e]\le \frac{\chi}{|V|}.
  \tag{2}
\]

Finally let \(\mathsf{Dec}_i\) be an adaptive \(q_D\)-query decoder for \(C\), with
perfect exact-codeword behavior

\[
  \mathsf{Dec}_i^{C(m)}=m_i
  \quad\text{with probability one},
  \tag{3}
\]

and no wrong output on an exact codeword. Conditioned on an honest transcript, assume
that each query step asks any fixed codeword position with probability at most
\(\lambda/M\).

## Theorem 1 (incidence-stable field-lift barrier)

Under (1)--(3), the selected proof map

\[
  m\longmapsto A_m\in\Sigma^V
\]

has relative distance at least

\[
  \operatorname{dist}(A_m,A_{m'})\ge \frac{\Delta_C}{\chi}
  \qquad(m\ne m').
  \tag{4}
\]

Moreover, compose \(\mathsf{Dec}_i\) with the local dPCP test: on every outer query, run
the corresponding local test, abort with \(\bot\) on rejection or a bottom response, and
otherwise feed the decoded symbol to \(\mathsf{Dec}_i\). This gives a common-address
decoder on the proof map with at most \(q_Pq_D\) proof queries, where \(q_P\) is the
dPCP query count. For every radius \(0<\rho<\Delta_C/(2\chi)\) and every proof assignment \(z\) satisfying

\[
  \operatorname{dist}(z,A_m)\le\rho,
\]

put \(\eta=q_D\lambda\chi\rho\). Then

\[
  \Pr[\mathsf{RLDec}_i^z=m_i]\ge 1-\eta,
  \qquad
  \Pr[\mathsf{RLDec}_i^z\notin\{m_i,\bot\}]\le\eta.
  \tag{5}
\]

In particular, if \(\eta<1/2\), the proof map is a weak adaptive
\((q_Pq_D,\rho,1-\eta)\)-RLDC with perfect completeness. If \(\Sigma\) is fixed, a
fixed binary encoding gives the corresponding binary RLDC with the usual constant-factor
query and radius conversion. Consequently:

* for binary proofs and \(q_Pq_D=2\), the exponential 2-query Hamming-RLDC lower bound
  applies;
* for fixed finite alphabets and constant \(q_Pq_D\), every applicable adaptive RLDC
  lower bound applies, in particular a fixed-parameter superlinear length lower bound.

For a concrete constant-parameter choice, take
\[
  \rho_\star=\min\left\{\frac{\Delta_C}{4\chi},
    \frac{1}{4q_D\lambda\chi}\right\}.
\]
Then \(\rho_\star>0\), the nearest codeword is unique, and
\(q_D\lambda\chi\rho_\star\le1/4\). Hence fixed \(\Delta_C,\chi,\lambda,q_D\) already
force the corresponding constant-radius RLDC lower bound; the construction cannot hide
behind choosing an extremely small but fixed radius.

## Proof

Let \(m\ne m'\), and write
\(S=\{t:C(m)_t\ne C(m')_t\}\). By code distance,
\(|S|/M\ge\Delta_C\). For every \(t\in S\), a local edge tuple on which
\(A_m\) and \(A_{m'}\) agree would receive the same decoder output under both proofs,
contradicting (1). Hence

\[
  \Pr_{(t,e)\sim\mathcal Q}[A_m|_e\ne A_{m'}|_e]\ge\Delta_C.
  \tag{6}
\]

If \(B=\{v:A_m(v)\ne A_{m'}(v)\}\), the event in (6) implies
\(e\cap B\ne\varnothing\). By (2),

\[
  \Pr_{\mathcal Q}[e\cap B\ne\varnothing]
  \le \sum_{v\in B}\Pr_{\mathcal Q}[v\in e]
  \le \chi\frac{|B|}{|V|}.
  \tag{7}
\]

Combining (6) and (7) proves (4), and in particular makes the proof map injective.

Now fix \(z\) at distance at most \(\rho\) from \(A_m\), and let
\(B=\{v:z(v)\ne A_m(v)\}\). Equations (2) and a union bound give

\[
  \Pr_{t\sim[M],\ e\sim\mathcal P_t}[e\cap B\ne\varnothing]
  \le \chi\rho.
  \tag{8}
\]

Consider the first outer decoder query whose local dPCP edge meets \(B\). Before that
event, the transcript is the honest codeword transcript, so the \(r\)-th query asks each
fixed position \(t\) with probability at most \(\lambda/M\). Applying (8) conditionally
at each first-hit step and union bounding over at most \(q_D\) steps yields

\[
  \Pr[\text{some queried local edge meets }B]
  \le q_D\lambda\chi\rho=\eta.
  \tag{9}
\]

If no queried edge meets \(B\), every local test and decoded symbol is exactly the honest
one. By (3), the outer decoder returns \(m_i\), never the wrong bit. Thus a wrong output
is contained in the event in (9), and the correct output has probability at least
\(1-\eta\). This proves (5) and the RLDC conclusion. \(\square\)

## Consequence for the field-lifted compiler

Note 217 used dPCP list soundness to obtain a wrong-claim bound for an arbitrary proof of a
single output-homogeneous relation. The present theorem gives a different, family-level
route: for a family of output codewords, perfect completeness plus incidence smoothness
already gives near-proof target binding, without an indexed list or singleton list. The
price is that the selected honest proofs themselves become an RLDC code.

For the GMWZ dPCP theorem, the complete decoding distribution is explicitly uniform on
both sides of its bipartite proof graph. Therefore any instantiation whose two proof sides
have comparable size has \(\chi=O(1)\). If the field-lift also supplies a constant-distance
output code and an \(O(1)\)-smooth outer decoder, then a family-level construction with
binary 2-query dPCP and one outer query would produce a binary 2-query RLDC, hence an
exponential proof-length lower bound. With a constant number of outer queries the same
argument gives the corresponding constant-query RLDC lower bound.

This is not a claim that GMWZ supplies the required output family, field lift, or
address-scale outer decoder. It is a sharp closure test for any proposed construction:
near-linear length can survive only by making at least one of \(\chi\), \(\lambda\), or
the inverse output distance grow, or by leaving perfect-completeness/common-address/
family-level semantics.

## Corollary 2 (GMWZ uniform marginals fix the incidence parameter)

Let the dPCP constraint graph be bipartite with left and right vertex sets \(A,B\), and
let every local edge contain one vertex from each side. If the complete decoding
distribution has uniform marginals on both sides, then

\[
 \Pr_{\mathcal Q}[v\in e]=
 \begin{cases}
 |A|^{-1},&v\in A,\\
 |B|^{-1},&v\in B.
 \end{cases}
\tag{10}
\]

Consequently the incidence hypothesis (2) of Theorem 1 holds with the exact choice

\[
 \chi_{\rm reg}=\frac{|A|+|B|}{\min\{|A|,|B|\}}
 =1+\frac{\max\{|A|,|B|\}}{\min\{|A|,|B|\}}.
\tag{11}
\]

In particular, if the two sides are within a constant factor, then
\(\chi_{\rm reg}=O(1)\). Theorem 1 therefore applies to any field-lifted output
family built on this dPCP with constant relative output distance and constant-smooth
outer decoding. For a balanced graph, the proof distance is at least
\(\Delta_C/2\), and the admissible RLDC radius is any
\(\rho<\Delta_C/4\) before the decoder-smoothness constraint is imposed.

### Proof

For \(v\in A\), the event \(v\in e\) is exactly the event that the left endpoint of
the sampled edge is \(v\), whose probability is \(1/|A|\) by the uniform left
marginal. The right-side statement is identical. Taking the larger of these two
incidences and multiplying by \(|A|+|B|\) gives (11). \(\square\)

Gur--Minzer--Weissenberg--Zheng Theorem 3.12 explicitly supplies uniform marginals on
both sides, perfect completeness, two queries, and constant alphabets. Thus the
incidence parameter is not an independent escape for a balanced instantiation of that
theorem. The corollary still does not provide the missing output family, field lift, or
address-scale outer decoder; it only removes one proposed way of evading Theorem 1.

## Relation to RW/JK

The theorem does not by itself prove \(P\ne NP\). It says that the most attractive
address-scale closure interface—constant-distance output spreading, regular shared proof,
and constant-smoothness coordinate decoding—would already solve a stronger coding problem
than the RW/JK contradiction can afford. Thus a successful RW closure must either exhibit a
non-incidence-smooth hidden channel, use a genuinely relaxed/bottom branch, or prove a new
family-level construction outside the standard dPCP-to-RLDC regime.

## Sources

* [GMWZ Theorem 3.12](https://arxiv.org/html/2512.12960) (uniform left/right complete
  decoding marginals, perfect completeness, 2-query dPCP, list soundness).
* [Field-lifted one-proof output-relation compiler](217-field-lifted-one-proof-output-relation-dpcp-compiler-2026-08-17.md).
* [Exponential lower bounds for 2-query RLDCs](https://arxiv.org/html/2602.20278).
