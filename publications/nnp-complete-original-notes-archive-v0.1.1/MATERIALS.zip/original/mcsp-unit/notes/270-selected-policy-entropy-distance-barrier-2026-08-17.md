> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Selected-policy entropy--distance barrier

## Contribution

The selected-policy counterexample of note 269 is not merely a degenerate
constant-proof construction.  In the full finite-policy model, target
information carried by selected policies has an exact sphere-packing cost.
No all-policy soundness or common selector is assumed.  The conclusion is a
distance/entropy theorem, not an RLDC theorem: the policy vector may still
depend on the target, so the result deliberately stops before message-inline
decoding.

## Theorem

Let \(\mathcal M\) be a finite message family, \(C:\mathcal M\to\Sigma^N\) a
common proof map, and \(i\in[k]\) the message coordinates.  For each pair
\((m,i)\), choose one policy \(\tau_{m,i}\) from a finite policy universe.
Write

\[
  S(m):=(\tau_{m,1},\ldots,\tau_{m,k})
\]

for the selected-policy vector.  The verifier at coordinate \(i\) and claim
\(b\) is target-independent once its policy is fixed.  Assume constants
\(\alpha>\beta\) and \(\rho\ge0\) such that, for every \(m,i\),

\[
\Pr[V_{i,m_i}^{\tau_{m,i}}(C(m))=1]\ge\alpha,
\tag{270.1}
\]

and, for every \(z\) with
\(\operatorname{dist}_H(z,C(m))\le\rho N\),

\[
\Pr[V_{i,1-m_i}^{\tau_{m,i}}(z)=1]\le\beta.
\tag{270.2}
\]

Let

\[
  t=\left\lfloor\frac{\rho N}{2}\right\rfloor,\qquad
  \operatorname{Vol}_{|\Sigma|}(N,t)
  =\sum_{j=0}^{t}\binom Nj(|\Sigma|-1)^j .
\]

Then every fiber of \(S\) is a code of minimum Hamming distance
strictly larger than \(\rho N\).  Consequently,

\[
 |\mathcal M|
 \le
 |\operatorname{supp}S|\,
 \frac{|\Sigma|^N}{\operatorname{Vol}_{|\Sigma|}(N,t)}.
\tag{270.3}
\]

For a uniformly distributed \(M\in\mathcal M\), the equivalent entropy form
is

\[
 H(M)
 \le H(S)+N\log_2|\Sigma|
       -\log_2\operatorname{Vol}_{|\Sigma|}(N,t).
\tag{270.4}
\]

If each coordinate policy has at most \(B_i\) possible values, then
\(|\operatorname{supp}S|\le\prod_i B_i\).  For fixed
\(A=|\Sigma|\) and \(0<\rho<2(A-1)/A\),

\[
 \log_2\operatorname{Vol}_{A}(N,\lfloor\rho N/2\rfloor)
 = N h_A(\rho/2)-O(\log N),
\]

where
\[
 h_A(x)=H_2(x)+x\log_2(A-1).
\]
Thus a \(k\)-bit uniform family must satisfy

\[
 \log_2|\operatorname{supp}S|
 \ge
 k-N\bigl(\log_2 A-h_A(\rho/2)\bigr)-O(\log N).
\tag{270.5}
\]

In particular, for binary proofs and \(N=(1+o(1))k\),

\[
 \log_2|\operatorname{supp}S|
 \ge H_2(\rho/2)\,k-o(k).
\tag{270.6}
\]

## Proof

Fix one selected-policy vector \(s\), and take distinct \(m,m'\) in its
fiber.  Choose a coordinate \(i\) with \(m_i\ne m'_i\).  If
\(\operatorname{dist}_H(C(m),C(m'))\le\rho N\), then the policies at \(i\)
are identical because \(S(m)=S(m')=s\).  Apply (270.2) for target \(m\) to
the near proof \(z=C(m')\).  Since \(m'_i=1-m_i\), it gives

\[
 \Pr[V_{i,m'_i}^{\tau_{m,i}}(C(m'))=1]\le\beta.
\]

But (270.1) for target \(m'\), with the same policy, gives the opposite
quantity at least \(\alpha\), a contradiction.  Hence the proof words in
each fiber have pairwise distance \(>\rho N\).

Hamming balls of radius \(t=\lfloor\rho N/2\rfloor\) around words in one
fiber are disjoint.  Their total size is at most \(|\Sigma|^N\), so that
fiber has size at most
\(|\Sigma|^N/\operatorname{Vol}_{|\Sigma|}(N,t)\).  Summing over the
policy fibers proves (270.3).  Taking logarithms gives the uniform entropy
form; the general form follows from
\(H(M)\le H(S)+H(M\mid S)\) and the same bound on every conditional fiber.
The asymptotic estimates are the standard \(A\)-ary Hamming-ball volume
estimate. \(\square\)

## Interpretation for the Closure Gate

The theorem is strictly weaker than C199/C183: it does not produce a common
decoder because different policy vectors may be used for different targets.
It is nevertheless stronger than the zero-information counterexample in
note 269.  It gives a quantitative trichotomy:

1. a common policy vector (or a global selector) enters the RLDC closure;
2. a finite selected-policy family must pay the entropy in (270.5), or the
   proof length must pay the corresponding sphere-packing rate; or
3. the protocol leaves the finite-policy/common-address model.

For a binary proof with \(N\approx k\), any constant-radius selected-policy
protocol whose policy vector has \(o(k)\) bits is impossible, even though
selected-policy-only soundness is allowed.  The result does not contradict
note 269: there the policy vector is essentially the target itself, so its
entropy is \(k\) bits and (270.5) is paid in full.

This is the sharp boundary currently available without adding all-policy
soundness.  To obtain a superlinear RLDC lower bound one still needs a common
selector, a policy-independent soundness family, or a transcript/ROC
condition that removes the target-dependent policy channel.
