> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 定向势平均关闭、对称 collision 势仍可逃逸

## 1. 定向三元组的平均 no-go

固定有向 (T\subseteq C) 与 spoiler (s\notin T)，记

\[
G_{T,s}(R)=\mathbf 1_{s\in R}-\mathbf 1_{T\subseteq R}.
\]

对均匀随机 affine leaf

\[
R_{r,b,t}=\{(x,y):r\cdot x+b=t,\quad r\cdot y+b=1-t\},
\]

任意 cell (c=(x,y)), (x\ne y)，满足

\[
\Pr[c\in R_{r,b,t}]=\frac14.
\]

若 (T\ne\varnothing)，则事件 (T\subseteq R_{r,b,t}) 包含事件 (s_0\in R_{r,b,t})（任取 (s_0\in T)），因而

\[
\Pr[T\subseteq R_{r,b,t}]\le\frac14.
\]

故

\[
\boxed{\mathbb E G_{T,s}(R_{r,b,t})\ge0.}
\]

非负加权和仍有非负平均。将所有单叶约束取平均时，这一整类定向势不能降低根部平均容量，因而不能绕开随机 affine-coloring 的常数上界。

## 2. 对称 quasi-additive 势的严格反例

定向势的 no-go 不可推广到所有 (g(|h\cap R|))。取 (n=3) 与

\[
h=\{(0,1),(0,2),(0,3)\}\subseteq\mathbb F_2^3\times\mathbb F_2^3.
\]

由于

\[
1\oplus2\oplus3=0,
\]

有

\[
\operatorname{aff}\{0\}\cap\operatorname{aff}\{1,2,3\}\ne\varnothing,
\]

而每个二 cell 子集可由 affine parity 分离；故 (h) 是 inclusion-minimal collision。

定义

\[
g(0),g(1),g(2),g(3)=(0,1,-1,0).
\]

直接检查 (a+b\le3) 的有限种情形可得

\[
g(a)+g(b)\ge g(a+b),\qquad g(3)=0.
\]

于是 (K_h(R)=g(|h\cap R|)) 满足每个递归二分

\[
K_h(V)+K_h(W)\ge K_h(V\mathbin{\dot\cup}W),\qquad K_h(C)=0.
\]

枚举 (4\cdot2^3=32) 个有向 affine leaves，得到精确分布

\[
\#\{|h\cap R|=0,1,2,3\}=(20,0,12,0).
\]

因此

\[
\boxed{\mathbb E K_h(R)=-\frac{12}{32}=-\frac38<0.}
\]

这个反例说明：

\[
\text{collision + quasi-additivity}
\not\Longrightarrow
\text{随机叶平均非负}.
\]

它不自动给出 MCSP 下界；仍须把许多 collision 的负势同时安排到所有 affine-separable 叶上，并控制正势泄漏。因而静态 fractional-coloring 路线只对 cell-additive 与定向 (G_{T,s}) 已关闭，对高阶 symmetric collision spectrum 尚未关闭。

## 3. 可检验的下一命题

设 (mathcal H_3) 为 (E_a\times NO_b) 上的最小三-cell affine collisions，并令

\[
K(R)=\sum_{h\in\mathcal H_3}\lambda_h,g(|h\cap R|),\qquad \lambda_h\ge0,
\]

其中 (g=(0,1,-1,0))。下一项最小证明义务是二选一：

\[
\begin{array}{ll}
\text{(A)}&\text{存在语义加权 }\lambda_h\text{，使所有单色 }R\text{ 上 }K(R)\text{ 足够负；}\\
\text{(B)}&\text{证明任意此类 }\lambda_h\text{ 都有某个单色叶 }R\text{ 满足 }K(R)\ge0,
\end{array}
\]

从而关闭 triple-collision 静态路线。

