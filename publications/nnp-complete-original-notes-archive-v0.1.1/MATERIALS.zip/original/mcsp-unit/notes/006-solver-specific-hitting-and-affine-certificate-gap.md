> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Solver-specific hitting 与仿射证书缺口

## 1. 精确目标

记

\[
E_a=\{x:\operatorname{CC}(x)\le a\},
\qquad
NO_b=\{x:\operatorname{CC}(x)>b\},
\]

以及

\[
\mathcal D_s=\operatorname{FORMULA}[s]\circ\operatorname{XOR}.
\]

下列命题与目标下界严格等价：

\[
\boxed{
\forall C\in\mathcal D_s,
\quad
NO_b\subseteq C^{-1}(0)
\Longrightarrow
E_a\cap C^{-1}(0)\ne\varnothing.}
\]

它要求 \(E_a\) 只击中条件子族

\[
\mathcal A_s^b
=
\{C^{-1}(0):C\in\mathcal D_s,\ NO_b\subseteq C^{-1}(0)\},
\]

而不是所有稠密 \(\mathcal D_s\)-集合。故 [[005-local-hitting-and-profile-shrink-boundary]]
中的通用 HSG/零错误平均情形等价并未直接关闭它。

另一方面，任何只使用

\[
\Pr[C(U)=0]\ge1-\rho_b
\]

而不使用 \(NO_b\subseteq C^{-1}(0)\) 的证明，都会退化为通用 dense-HSG 论证。

## 2. 稀有接受集迫使相容接受证书满秩

写

\[
C(x)=A(P_1(x),\ldots,P_S(x)),
\]

其中 \(A\) 是 read-once De Morgan 公式树，每个 \(P_i\) 是仿射 parity。
若一组与某个可达接受 profile 相容的 1-certificate 指定了若干 \(P_i\) 的值，
且这些仿射方程的秩为 \(r\)，则其全部解构成密度 \(2^{-r}\) 的接受仿射子空间。

GapMCSP solver 的接受集包含于 \(\{\operatorname{CC}\le b\}\)，所以

\[
\Pr[C(U)=1]
\le
\rho_b
=
2^{-N+O(b\log(b+\log N))}
=
2^{-N+o(N)}.
\]

因此每个相容 1-certificate 都满足

\[
\boxed{r\ge N-o(N).}
\]

这是无需 PRG 的真实结构约束。

## 3. 普通 certificate-product 捷径是假的

不能由上式直接推出大小 \(O(S/N)\) 的相容 0-certificate。

首先，对指定的 0/1 输入，不存在一般的 cross-certificate 乘积界。取

\[
A
=
x_1\vee\bigl(x_2\vee\cdots\vee(x_d\vee AND_m)\bigr).
\]

在 \(x_1=\cdots=x_d=0\)、\(AND_m=1\) 的接受输入上，最小 1-certificate
大小为 \(m\)；任一拒绝证书大小为 \(d+1\)。于是

\[
m(d+1)\gg m+d=L(A).
\]

其次，即使 outer profile cube 中存在短 0-certificate，它也可能与 parity image
不相交。只有与某个可达拒绝 profile 相容的证书才产生实际 truth table。

所以此前候选蕴含

\[
\text{接受证书秩 }N-o(N)
\Longrightarrow
\text{相容拒绝证书大小 }O(S/N)
\]

尚未证明，不能作为结果使用。

## 4. 最小新引理

当前第一个待判定命题是：

\[
\boxed{
\begin{gathered}
P:\mathbb F_2^N\to\mathbb F_2^S\text{ 为仿射映射，}\ A\text{ 为大小 }S\text{ 的 De Morgan 树；}\\
\text{若每个与 }\operatorname{im}P\text{ 相容的 1-certificate 秩至少 }R,\\
\text{则是否存在一个相容 0-certificate，大小 }O(S/R)?
\end{gathered}}
\]

普通公式归纳在这里遇到两个精确障碍：

- OR 节点的两个拒绝证书需要同时相容，线性方程可能冲突；
- AND 节点的接受证书秩只有次可加性，并可能因共享 parity 发生大规模依赖。

若该仿射商证书引理成立，Frontier B 的 \(S=N^{1.01}\)、\(R=N-o(N)\)
只会先给出

\[
q=N^{0.01+o(1)}
\]

个拒绝方程。高斯消元至多产生重量 \(q\) 的解和

\[
\operatorname{CC}(y)=O(q\log N),
\]

仍远大于

\[
a=2^{(\log N)^{1/3}}.
\]

而且这个点位于 promise gap 内，不能迭代调用 solver 正确性。因此即使引理成立，
还需要第二个真正使用 \(NO_b\subseteq C^{-1}(0)\) 的全局压缩机制。

## 5. 单个仿射 cell 的计数边界

低复杂度 truth tables 的数量满足

\[
|E_a|
\le
2^{O(a\log(a+\log N))}.
\]

随机余维 \(q\) 的仿射 coset 与 \(E_a\) 相交的概率至多

\[
|E_a|2^{-q}.
\]

故当

\[
q\gg a\log(a+\log N)
\]

时，确实存在完全避开 \(E_a\) 的仿射 cell。这严格排除仅靠“一个拒绝 cell 很大”
或 leaf sampling 完成目标。

真正剩余的对象是整个拒绝 cell family：

\[
NO_b
\subseteq
\bigcup\mathcal R,
\qquad
E_a\cap\bigcup\mathcal R=\varnothing,
\]

其中 \(\mathcal R\) 由同一大小 \(N^{1.01}\) 的 outer formula 组织。需要证明这种
全局覆盖迫使某些 cell 的重叠、嵌套或线性依赖产生一个 easy point；单证书、单
subspace 与纯密度参数均不足。

~~~mermaid
flowchart LR
    G["NO_b 全部被拒绝"] --> R["所有相容 1-cert<br/>rank N-o(N)"]
    R --> Q{"仿射商证书引理?"}
    Q -->|"若真"| B["0-cert ≈ N^0.01"]
    B --> X["仍在 promise gap"]
    Q -->|"若假"| D["找线性相容性反例"]
    X --> F["必须分析全部 rejecting cells"]
    D --> F
~~~
