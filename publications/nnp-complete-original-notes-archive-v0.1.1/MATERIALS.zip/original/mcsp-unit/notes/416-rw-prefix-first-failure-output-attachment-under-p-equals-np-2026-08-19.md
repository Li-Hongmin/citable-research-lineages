> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(P=NP\) 重编译下 RW 首失败块的前缀附着定理（2026-08-19）

## 本轮改变的判断

C383/C401 把 actual RW Gate-I 的位置缺口写成了
\(H_{\rm wit}\)：若首个 JK outsider 可能来自 output 之后的 auxiliary 区段，
就不能把它当成 parent accessor。对最终反证所需的 \(P=NP\) 分支，这个缺口可以
进一步缩小。

在 \(P=NP\) 下，把固定 SAT-oracle machine 直接重编译为确定性 machine 后，
Lemma 3.2 的 query-count prefix 为空。若采用 Theorem 3.5 的固定 binary
serialization，使 systematic \((pfx,out)\) prefix 成为 proof 的真实前缀，
则 hard parent \(B\) 本身位于 canonical proof 的最前端。对按 contiguous block
顺序选择首个 non-range block 的 JK 实现，若首个 outsider 的 ancestry 完全在
\(B\) 之后，则 \(B\) 可以沿同一棵已通过的 JK preimage tree 用小电路重构。

因此在 forcing lower bound 排除该小电路时，首个 outsider 必须附着于 \(B\)；
不需要另证 C401 所要求的 non-output witness cover。这个结果只关闭
\(P=NP\) deterministic-recompile 分支中的**位置量词**，不关闭
\(2k\)-bit block 到整个 \(b\)-bit parent 的 multi-block binding。

## JK 前缀路径引理

令
\[
  G_k:\{0,1\}^{k}\to\{0,1\}^{2k},
  \qquad G_{k,0}(u):=G_k(u)_{[1,k]},
  \qquad G_{k,1}(u):=G_k(u)_{[k+1,2k]} .
\]
令 \(\Pi\in\{0,1\}^{L}\)，并按 JK 规则补零到
\(L'=k2^H\)，其中 \(H=\max\{0,\lceil\log_2(L/k)\rceil\}\)。在 level \(H\) 的顶层串为
\(Y_H=\Pi0^{L'-L}\)；每个通过 range test 的 \(2k\)-bit block 选择一个
preimage，并把相邻的 \(k\)-bit preimages 串接成下一层 \(Y_{j-1}\)。

固定 contiguous、leftmost tie-break：在一个 level 中所有 range queries 并行完成，
若有多个 non-range block，返回最左的一个。对任一 block occurrence \(v\)，记
\(\mathsf A(v)\) 为其所有未截断 top \(2k\)-bit ancestors 的坐标集合。

### 定理 416.1（prefix-first-failure attachment）

设 \(B=\Pi[1,b]\) 是 proof 的前 \(b\) bits。若 JK 返回的首个 outsider \(y\)
满足
\[
  \mathsf A(y)\cap[1,b]=\varnothing ,
\tag{416.1}
\]
则存在一个 Boolean circuit \(C_B\)，以 \(\lceil\log_2 b\rceil\) 位地址为输入，
计算 \(B\)，且
\[
  \operatorname{CC}(B)
  \le
  O\!\left((|G_k|+k)H+\log(L+2)\right).
\tag{416.2}
\]

### 证明

条件 (416.1) 与 contiguous leftmost tie-break 意味着，在首个失败出现以前，
每个从底层 \(Y_0\) 到 \(B\) 中任一地址的 JK path 上的 block 都通过了
range test。对这样的 path，若当前 block 的左右方向由
\(\epsilon\in\{0,1\}\) 指定，则输出 half 正是
\(G_{k,\epsilon}\) 作用于该 block 的 \(k\)-bit preimage：
\[
  Z_{\rm parent}[a]
  =
  G_{k,\epsilon}\bigl(Z_{\rm child}\bigr)[r].
\tag{416.3}
\]

把 JK 的底层 \(k\)-bit seed \(Y_0\) hardwire。给定地址，固定的二进制算术电路
在每一层取得相应的 block/half 方向；用一个 \(k\)-bit multiplexer 在
\(G_{k,0}\) 与 \(G_{k,1}\) 之间选择，并逐层复合 \(H\) 次。每层的开销为
\(O(|G_k|+k)\)，地址和边界选择只需 \(O(\log(L+2))\) 个门。由 (416.3)，
得到的电路在每个 \(a\in[b]\) 上输出 \(\Pi[a]\)，即计算 \(B\)。证毕。

这里没有使用 output 之后 block 的取值，也没有要求 auxiliary proof 有任何
semantic label；只使用首失败之前的 prefix-respecting tree。

## RW deterministic-recompile 推论

设 \(B\) 是一个 forcing hard parent。假设在 \(P=NP\) 下，固定 SAT-oracle
machine 被一个确定性 SAT decider 重编译，并以 zero-padding 得到
\[
  \widehat f(x)=B\,0^{\widehat T-b},
  \qquad r=s=0 .
\tag{416.4}
\]
于是 Lemma 3.2 的 \(r'=r\lceil\log(\widehat T+1)\rceil\) 为零。若固定的
Theorem 3.5 binary serialization 满足
\[
  \Pi[1,b]=\widehat f(x)[1,b]=B ,
\tag{416.5}
\]
且
\[
  \operatorname{CC}(B)>
  C\bigl((|G_k|+k)\log(\lvert\Pi\rvert/k+2)+\log(\lvert\Pi\rvert+2)\bigr),
\tag{416.6}
\]
则 JK 的首个 outsider 必满足
\[
  \mathsf A(y)\cap[1,b]\ne\varnothing .
\tag{416.7}
\]

否则定理 416.1 与 (416.6) 矛盾。故在该分支中，\(H_{\rm wit}\) 的
non-output recursive-cover obligation 不再是位置附着的必要前提。

在 published stable 参数的粗略窗口
\[
  |G_k|\le k^4,\qquad
  |\Pi|\le T^{O(1)},\qquad
  \operatorname{CC}(B)=\Omega(n/\log n),
\]
当 \(k=\operatorname{polylog}(n)\) 时，右侧 (416.6) 为
\(n^{o(1)}\operatorname{polylog}(n)\)，故被 forcing lower bound 排除。
这与 C380/C383 的 easy-branch audit 相容，但更强之处在于：即使 JK 走
hard/success 分支，也不能把首个 outsider 放到 \(B\) 之后。

## 对 Closure 的精确剩余缺口

定理 416.1 只给出 output-attached ancestry，不给出 whole-parent reconstruction。
当 \(b>2k\) 时，C382 的 half-lift 仍最多恢复一个 top \(2k\)-bit block；要恢复
整个 \(B\)，仍需

* 至少 \(\lceil(b-d)/(2k)\rceil\) 个可验证的 output-attached blocks，或
* 一个不能编译成逐块 half-lift 的新 global relation。

因此 C410 的 singleton circuit payment 与 C383 的 multi-block payload bound
仍然有效。新的 Gate-I 形状是
\[
\text{prefix-first-failure attachment}
\quad\Longrightarrow\quad
\text{multi-block/global-relation parent binding}.
\]

## 假设边界

1. **Serialization。** (416.5) 需要固定 binary serialization；Theorem 3.5 的
   abstract \(\Pi=(\widetilde w,\Pi')\) 若未指定坐标编码，不能自动提供它。
2. **Tie-break。** 原始 JK 只需返回某个 non-range block；leftmost 版本可由并行
   SAT answers 选出且不改变 easy/hard correctness，但若使用任意 tie-break，
   (416.1) 不再推出 prefix order。
3. **Nonzero \(pfx\)。** 若 \(r'>0\)，只能得到
   \(B\) 前面长度 \(r'\) 的 prefix obstruction；需另证该 prefix 的 cover，
   或先做 \(P=NP\) deterministic recompilation。
4. **不是 \(P\ne NP\)。** 本结果仍条件于 \(P=NP\) 的重编译、固定 serialization
   和 forcing lower bound；它只删除一个位置量词，不提供 whole-parent evaluator。

## 证据边界

* Ren--Williams Lemma 3.2：history 顺序为 \((y_1,\ldots,y_r,out,z_{i,j})\)；
  deterministic recompilation 时 \(r=0\)。
* Ren--Williams Theorem 3.5：systematic \((pfx,out)\) proof prefix。
* Ren--Williams Theorem 3.1 与 Korten/GGM easy reconstruction：通过 block 的
  preimage path 给出 \(O((|G|+k)H)\) 的 composition circuit。
* C371：\(P=NP\) 下 round/pfx 可重编译为零，但 width/solver 仍保留。
* C380/C383：RW hard-exit 与单 outsider output-attachment 的原边界。

本 note 不把 abstract Theorem 3.5 的未指定序列化冒称为已核验事实，也不把
output-attached block 冒称为 parent closure。
