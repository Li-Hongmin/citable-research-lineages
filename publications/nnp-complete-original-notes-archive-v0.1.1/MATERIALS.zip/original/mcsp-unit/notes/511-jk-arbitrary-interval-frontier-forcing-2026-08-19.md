> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK 任意连续区间的 frontier forcing barrier（2026-08-19）

## 本轮改变的判断

C494 只把 canonical JK frontier 限制到 proof prefix。Ren--Williams
Lemma 3.2 / Theorem 3.5 的 machine output 实际位于 canonical witness 的中间连续区间
\((r'+1,\ldots,r'+\ell)\)，因此 prefix 版本不能直接替代 output attachment。
本 note 将 C494 推广到任意 contiguous physical bit interval：若一个固定的
binary/systematic serialization 把目标 output 放在区间 \(I\)，则只计入与 \(I\)
相交的 failure frontier；一般区间的两个边界只带来一个常数因子。

这进一步缩小 actual RW closure 的 half-lift 逃逸：output 区间内的 frontier 稀疏时，
同一个 canonical proof 的该区间仍有小电路；若该区间本身是 forcing-hard，则必须支付
interval-local frontier，或提出不能展开成 canonical half-lift 的 global relation。

## 设置

令
\[
G:\{0,1\}^{k}\to\{0,1\}^{2k},\qquad R=\operatorname{Range}(G),
\]
并固定 canonical right inverse
\[
p:R\to\{0,1\}^{k},\qquad G(p(z))=z\quad(z\in R).
\tag{511.1}
\]
将一个固定 binary proof 补零为 \(\Pi^+\)；把它切成 \(2^H\) 个连续的 \(2k\)-bit leaves。
每个 node \(v\) 覆盖一个 leaf interval \(I_v\)。若两个 children 已定义且属于 \(R\)，令
\[
z_v:=p(z_{v0})\Vert p(z_{v1});
\tag{511.2}
\]
若 \(z_v\in R\)，称 \(v\) good；若 \(v\) 是 leaf，则其 payload 总是已定义；否则称
为 undefined。bad defined internal nodes 与 bad leaves 组成 failure frontier
\(\mathcal F\)。

固定任意非空 contiguous physical bit interval
\[
I=[a,b]\subseteq[1,|\Pi^+|]
\]
以及与之相交的 leaf index interval \(J_I\)。定义 interval-local frontier
\[
\mathcal F_I:=\{f\in\mathcal F:I_f\cap J_I\neq\varnothing\},
\tag{511.3}
\]
其中 \(I_f\) 是 \(f\) 覆盖的 leaf interval。

## 定理 511.1（arbitrary-interval frontier barrier）

从 root 开始，对 \(J_I\) 做局部 terminal decomposition：

1. node \(v\) good 时输出一个 good terminal；
2. \(v\) 是 leaf 时输出其 \(2k\)-bit payload；
3. 否则只递归那些与 \(J_I\) 相交的 children。

记 terminals 为 \(\mathcal T_I\)。则
\[
|\mathcal T_I|
\le 1+(H+1)(|\mathcal F_I|+2).
\tag{511.4}
\]

令
\[
C_G:=|G|+k+\lceil\log_2(|\Pi^+|+2)\rceil.
\]
存在一个以 physical bit address 为输入、在 \(I\) 上计算同一个 proof substring
\(\Pi^+[a..b]\) 的 Boolean circuit \(C_I\)，满足
\[
\operatorname{CC}(\Pi^+[a..b])
\le
O\!\left((HC_G+\log(|\Pi^+|+2))|\mathcal T_I|\right)
\tag{511.5}
\]
以及
\[
\operatorname{CC}(\Pi^+[a..b])
\le
O\!\left(HC_G\bigl(1+H(|\mathcal F_I|+2)\bigr)\right).
\tag{511.6}
\]

因此，对任意 forcing-hard target interval \(B_I=\Pi^+[a..b]\)，若
\(\operatorname{CC}(B_I)\ge S\)，则
\[
|\mathcal F_I|
\ge
\Omega\!\left(\frac{S}{H^2C_G}\right)-O(1).
\tag{511.7}
\]

### 证明

若 \(v\) good，令 \(s_v=p(z_v)\)。由 (511.2) 和 (511.1)，
\[
G(\operatorname{half}_\epsilon(s_v))=z_{v\epsilon},
\qquad \epsilon\in\{0,1\}.
\tag{511.8}
\]
故固定 \(s_v\) 后，沿任意 descendant path 至多应用 \(H\) 次
\[
L_0(z)=G(\operatorname{left}_k z),
\qquad
L_1(z)=G(\operatorname{right}_k z),
\tag{511.9}
\]
即可得到该 good terminal 覆盖的所有 leaf payload。leaf terminal 则直接 hardwire
其 \(2k\)-bit payload。

令 \(A_I\) 为 decomposition 中被展开的 non-good nodes。若 \(v\in A_I\) 是
bad defined node 且 \(I_v\) 与 \(J_I\) 相交，则 \(v\in\mathcal F_I\)。若 \(v\)
undefined，任选其 descendant failure \(f\)。当 \(I_f\) 与 \(J_I\) 相交时，把 \(v\)
charge 给 \(f\)；固定 \(f\) 至多有 \(H+1\) 个 ancestors。若所选 \(f\) 不与
\(J_I\) 相交，而 \(I_v\) 与 \(J_I\) 相交，则 \(I_v\) 必跨过 \(J_I\) 的左或右边界。
每个 depth 至多有两个这样的 boundary nodes，因此共至多 \(2(H+1)\) 个。
于是
\[
|A_I|\le(H+1)|\mathcal F_I|+2(H+1).
\tag{511.10}
\]
局部展开树从一个 root 出发，每个 expanded node 至多产生两个 children，故其
terminal 数至多为 \(|A_I|+1\)，得到 (511.4)。

最后，对每个 terminal hardwire seed 或 leaf payload；由输入地址计算其相对 path，
并用比较器和 multiplexer 选择落入 \(I\) 的 terminal。每个 good terminal 的代价为
\(O(HC_G)\)，边界比较与 selector 代价由
\(O(\log(|\Pi^+|+2))\) 吸收，得到 (511.5)。代入 (511.4) 得 (511.6)，再整理得
(511.7)。证毕。

## 与 RW/JK canonical output 的对齐

原文 Lemma 3.2 的 computational-history 顺序是
\[
(y_1,\ldots,y_r,\mathrm{out},z_{i,j}),
\]
而 Theorem 3.5 保证：当长度-\(r'\) prefix 固定时，后续
\((r'+1,\ldots,r'+\ell)\)-th bits 等于 machine output。因此 output 是
canonical witness 中的中间 contiguous interval，而不是 proof 的最前缀。

若采用被明确计价的 source-compatible binary/systematic serialization，使 canonical
honest proof 的 witness assignment prefix 在物理 proof 中保持连续，且
\(\mathrm{out}\) 的 \(\ell\) 个 bits 位于区间 \(I_{\mathrm{out}}\)，则定理 511.1 可直接作用于
\(\Pi^+[I_{\mathrm{out}}]\)。在该 honest proof 上，systematic witness bits 与
Theorem 3.5 的 canonical polynomial bits 一致；因此若这个物理 output substring
正是 forcing object，interval-local frontier 必须支付 (511.7)。

这一步有明确边界：Theorem 3.5 的 soundness 只说任意高接受 proof 的 decoded
\(\widetilde w'\) 接近低度多项式；它不自动把 decoded coordinate 变成 arbitrary
near-proof 的 physical raw neighbor。若 proposed closure 只访问 decoded-domain
coordinate、改变 serialization，或使用 nonlocal relation，则必须另证 raw-to-decoded
binding，并进入 C477/C478 所标记的 model/global-relation 分支；不能把 (511.7) 偷换成
一般 decoded-output lower bound。

## 对 Closure 的直接含义

1. **output-prefix 误对齐被修正。** C494 现在有 arbitrary-interval 版本，覆盖
   Theorem 3.5 的真实 output 区间；两个边界只增加 \(+2\) 的常数项。
2. **suffix failure 仍不能掩护 output interval。** 只要 interval-local frontier
   稀疏，canonical half-lift evaluator 就小；forcing-hard output 必须在该区间支付
   frontier，或提出被完整计价的 non-half-lift global relation。
3. **这仍不是 \(P\ne NP\) 证明。** \(\mathcal F_I\) 是 fixed canonical proof
   上的反事实 frontier，不等于实际 JK query 集；还需要证明 published RW 的
   output substring、forcing object 和同一长度集合确实通过 source-compatible
   physical serialization 对齐。

## 来源

* [C494](494-jk-prefix-local-frontier-forcing-barrier-2026-08-19.md)：prefix-local
  decomposition 与 canonical right-inverse evaluator。
* Ren--Williams TR26-118 revision 1, Lemma 3.2 / Theorems 3.1, 3.5, 4.1：history
  顺序、JK block recursion 与 canonical output interval。
* [C477](../rw-jk-succinct-reconstruction/CLAIMS.md)：physical proof 与 raw completion
  的量词边界。
