> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW hard-table closure：object-scale solver 分支不能由 near-maximum 下界排除（2026-08-18）

## 裁决

先前将 RW hard-table 分支写成“(P=NP) 下 stable solver branch 被 near-maximum
下界排除，因此所有充分大的 hard length 都进入 reconstruction branch”是不成立的。
错误在于混用了两个尺度：RW Theorem 4.5 给出的下界是相对于输出表长 (N) 的

\[
  \operatorname{CC}(H_N)\ge cN/\log(N+2),
\]

而 (P=NP) 只把 stable solver branch 变成一个对输入长度（在 truth-table-generator
实例上与表长 (N) 同阶）运行 (N^{O(1)}) 的过程。一个 (N^D)-大小的电路并不与
(cN/\log N) 下界矛盾。若以地址长度 (m=\lceil\log_2N\rceil) 表示，这只是

\[
  2^{O(m)}\quad\text{vs.}\quad 2^m/\operatorname{poly}(m),
\]

同样没有矛盾。

因此，C255 / note 232 的正确结论不是“hard length 必然在 reconstruction branch”，
而是下面的尺度三分：

1. **stable solver branch：** 在 (P=NP) 下至多得到一个 object-scale
   (N^{O(1)}) evaluator；这与 RW 的 near-maximum 下界相容。
2. **failure/reconstruction branch：** 若采用一个共同地址空间、有限 descriptor 的
   straight-line ROM 实现，则公共 (1\) 对 (1/2) gap 和抽样展开给出
   \[
     p+bd=\Omega\!\left(\frac{N}{\operatorname{polylog}N}\right),
   \]
   一般 fan-in-two 展开至少给出 (p+bd=N^{\Omega(1)})（在控制规模和读取次数为
     ((\log N)^{O(1)}) 时）。
3. **model exit：** 不同地址的无共同 evaluator、vanishing gap、非有限交互或新的
   global coupling 不受上述 ROM 结论约束。

只有额外证明 stable solver branch 也有 (m^{O(1)}) 的地址尺度 evaluator，或者把
forcing 下界提高到相对于 (N) 的 (N^{\omega(1)})，才能在该分支得到矛盾。现有
RW Theorems 4.1--4.5 没有这两项中的任何一项。

## 直接验证

RW Theorem 4.3 的稳定尾部满足 (T_i=n_{i+1}=n_i^C)。在 (P=NP) 下，
`BF_i` 中的 SAT 查询可确定化，但其总时间仍是 (n_i^{O(C)}=N_i^{O(1)})，其中
(N_i=2n_i) 是输出表长。Theorem 4.5 的 near-maximum 结论只要求

\[
  \operatorname{CC}(H_{N_i})=\Omega(N_i/\log N_i),
\]

故不能从二者推出 stable branch 不存在。early solver branch 输出的零表属于
truth-table-generator 的 range，这一事实仍然成立；它只排除 early solver branch
成为 hard length，并不排除 stable solver branch 成为 hard length。

failure branch 的 ROM/抽样计算不受此修正影响：它条件性地作用于已经知道采用
reconstruction 的 hard length。修正后的结论是一个 branch trichotomy，而不是把
RW 的 near-maximum theorem 误写成 (P\ne NP) 的 object-scale contradiction。

## 对 Closure program 的影响

这次修正使 Gate I 更精确：

* 若要从 stable branch 得到最终矛盾，目标必须是把 `BF_i` 压到
  (m_i^{O(1)}) 的 random-access evaluator，而不是只证明它在 (N_i) 上多项式；
* 若只研究 failure branch，则必须先证明 hard lengths 有足够多的 failure branch，
  或给出一个对 stable branch 也适用的 address-scale/complexity lower bound；
* C353--C355 的单表 acceptance-surface 与 vanishing-gap 结论仍然有效，因为它们
  明确以地址长度和 forced-table complexity作比较，没有使用错误的
  (N^{O(1)}\not\ge N/\log N) 推理；
* C181/C204 的最终 Closure Theorem 也不变：它要求 forcing lower bound 相对于
  最终 evaluator 参数为超多项式，或要求真正的 address-scale evaluator。RW
  near-maximum output bound 本身尚未满足该条件。

## 范围

这是对本仓库既有 C255 / note 232 的尺度纠正，不是对 RW Theorem 4.5 的否定，
也不是 (P=NP) 或 (P\ne NP) 的结论。它关闭了一条错误的“stable branch 自动消失”
推理，并把下一步压缩为一个可检验问题：能否为 RW stable branch 构造真正的
address-scale accessor，或证明该 accessor 必须支付 object-scale 代价？

来源：Ren--Williams, ECCC TR26-118, Theorems 4.1--4.5；本仓库旧版
[note 232](232-rw-hard-table-closure-dilemma-2026-08-17.md) 的 branch claim 由本 note
取代。
