> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW native-width Harsha block capacity gate（2026-08-19）

## 本轮改变的判断

note 436 的递归深度界使用一个与 bundled algebraic line 输出长度匹配的微块宽度
\(\kappa\)。但 published RW/JK 在每个 stage 使用的是 native

\[
  G_K:\{0,1\}^{K}\to\{0,1\}^{2K},
\]

其中 \(K\) 由该 stage 的 AVOID 调用决定。若 \(K\gg\kappa\)，不能直接把
\(\kappa\)-block cover 当成对 native \(G_K\) 的 recursive closure：一个 native
block 可能包含许多 line segments，而 canonical preimage 仍只有 \(K\) bits。

下面把 C402/C436 的容量论证推广到这个 native-width 情形。结论是：只要这些
line segments 在 source family 中确实具有独立 local entropy，native block 变宽并
不会恢复完整 recursive closure；它至多把每个 leaf 的 descriptor 数量按比例增加，
该比例随后在 range capacity 中抵消。因而“先在小代数块上 cover，再把它打包进
published 大宽度 \(G_K\)”不是一个未计费的 Gate-I 逃逸。

## Native block interface

固定一个可逆、address-scale 可计算的 line-major binary serialization。设一个完整
bundled algebraic line segment 的长度为 \(2\kappa\) bits。对每个完整 segment，假设
source family 至少有 \(2^{s_*}\) 个不同的 descriptor/value，并且一个 native
\(2K\)-block 中的 \(r\) 个完整 line segments 可以独立组合：所有
\(2^{r s_*}\) 个组合都由同一 proof family 实现。至多两条跨 segment 的 boundary
片段被排除在这 \(r\) 个完整 segment 之外。

令
\[
  G_K:\{0,1\}^{K}\to\{0,1\}^{2K},
  \qquad R_K=\operatorname{Range}(G_K),
\]
并令 canonical inverse
\(p_K:R_K\to\{0,1\}^{K}\) 在 range 上满足
\(G_K(p_K(z))=z\)。考虑一个 depth-\(d\) JK subtree，含有
\(2^d\) 个这样的 non-output native leaves。假设所有 leaf blocks 及其逐层
canonical-preimage 拼接得到的 internal blocks 都属于同一个 \(R_K\)。

## 定理 438.1（native-width recursive capacity）

在上述 interface 下，必须有

\[
  \boxed{2^d r s_*\le K.}
\tag{438.1}
\]

若 \(K\ge6\kappa\)，则每个 native block 至少含有

\[
  r\ge \frac{K}{2\kappa}
\tag{438.2}
\]

个完整 line segments，因而

\[
  \boxed{2^d s_*\le 2\kappa,\qquad
  d\le \log_2\!\left(\frac{2\kappa}{s_*}\right).}
\tag{438.3}
\]

特别地，右端与 native width \(K\) 无关。

### 证明

给定一个 leaf tuple，按 JK 的 canonical inverse 逐层拼接，得到 root
native block。不同的 leaf tuples 在至少一个 leaf segment 上不同，因此其有序
root block 也不同；canonical-preimage 拼接只是可逆的坐标重排和连接。由假设，
所有 root blocks 都在 \(R_K\)，而
\[
  |R_K|\le2^K.
\]
另一方面，\(2^d\) 个 leaves 各自有 \(r\) 个可独立选择的 segment，每个 segment
有至少 \(2^{s_*}\) 个值，所以 leaf tuple 至少有
\(2^{2^d r s_*}\) 个不同取值。比较两边得到 (438.1)。

若 \(K\ge6\kappa\)，一个长度 \(2K\) 的区间删除两端最多两个 boundary pieces
后，至少保留
\(\lfloor K/\kappa\rfloor-2\ge K/(2\kappa)\) 个完整长度
\(2\kappa\) 的 segment，得到 (438.2)。代回 (438.1) 即得 (438.3)。证毕。

## Harsha 参数推论

在 note 436 的 source-compatible Harsha interface 中，bundled line 输出和一个
line descriptor 可分别取

\[
  \kappa=\Theta(m|F|\lambda),
  \qquad
  s_*=\Omega(m^2|H|\lambda)
\tag{438.4}
\]

在这里的 \(s_*\) 是一个**实际 product-rich line family** 的熵下界；它不是
仅由 descriptor 的编码上界自动得到的。由于
\(|F|=\Theta((m|H|)^3)\)，有

\[
  \frac{2\kappa}{s_*}
  =O\!\left(\frac{|F|}{m|H|}\right)
  =O((m|H|)^2),
\]

从而 independent-line branch 满足

\[
  d=O(\log(m|H|))=O(\log\log N).
\tag{438.5}
\]

这个结论现在适用于 native \(K\)，不要求把 RW 的 generator 宽度改成
\(\kappa\)。它仍只覆盖 source family 中 line descriptors 真正可独立变化的
分支；若实际 Harsha proof 的 lines 由一个共享 global parameter 强耦合，必须
改用 shared-parameter 或 non-product 分析。

## 与 published RW proof height 的对接

令 \(L\) 是固定 binary proof 长度，native JK tree height 为

\[
  D_{\rm native}=\left\lceil\log_2(L/K)\right\rceil.
\tag{438.6}
\]

在 \(K\ge6\kappa\) 且
\(D_{\rm native}>\log_2(2\kappa/s_*)\) 时，independent-line universal
range closure 不能跨越完整 native tree。对 Harsha 的
\(L=N^{18+o(1)}\) source length，只要
\(\log(L/K)=\Omega(\log N)\)，左侧是 \(\Omega(\log N)\)，而 (438.5) 只有
\(O(\log\log N)\)。在 published stable branch \(K=T_i\) 时，这个条件需要用
实际 \(N_i=|C_{x_0}|\) 与 \(T_i\) 的关系核验；不能仅由 \(T_i=K\) 推出。

于是 native-width Gate-I 形成严格三分：

1. \(K<6\kappa\)：native width 本身处于 algebraic address-scale 窗口，可使用
   note 436 的微块分析，但仍需证明 output attachment 和 whole-parent binding；
2. \(K\ge6\kappa\) 且有 product-rich independent lines：定理 438.1 限制递归
   深度，完整 proof height 超过该上界时 universal cover 失败；
3. 若要跨越该深度，必须证明 shared global parameter、实际 line entropy collapse
   或新的 non-product global relation。把微块 generator 的输出直接拼成 native
   \(G_K\) 而不证明 canonical inverse/seed capacity，不满足 RW/JK closure 量词。

## 证据边界

* \(r,s_*\) 的 product-rich 假设是承重条件；Harsha honest proof 的单个固定
  \(x_0\) 不自动提供它。
* boundary 对齐、line-major serialization 和 native block 的固定坐标 map 必须
  由 source-compatible 编码显式给出；published Theorem 3.5/4.1 没有自动提供
 这些实现细节。
* 定理 438.1 不绑定 systematic output parent，不排除真正的 non-product global
  relation，也不证明 \(P\ne NP\)。它关闭的是把小 line-block cover 未经容量核算
 升级为 native-width recursive closure 的模型跳跃。

## 来源

* [C402](402-jk-recursive-range-closure-capacity-2026-08-18.md)：canonical-preimage
  product capacity；
* [note 436](436-harsha-algebraic-leaf-cover-recursive-depth-gate-2026-08-19.md)：
  Harsha line descriptor 与微块参数；
* [note 398](398-oracle-major-binary-serialization-compiler-rw-harsha-2026-08-18.md)：
  source-compatible line-major serialization；
* [note 408](408-rw-harsha-proof-length-exponent-audit-2026-08-19.md)：Harsha proof
  length and native tree scale。
