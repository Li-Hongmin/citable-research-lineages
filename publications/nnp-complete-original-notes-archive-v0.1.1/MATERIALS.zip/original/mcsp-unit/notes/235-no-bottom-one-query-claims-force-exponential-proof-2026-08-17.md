> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No-bottom one-query claim verifiers force exponential proof length (2026-08-17)

## Contribution

Note 234 rules out a direct binary two-query relaxed decoder. The present note
connects that barrier to the project’s actual two-branch coordinate interface.
If each claim branch reads only one proof symbol, and an honest proof has no
simultaneous acceptance of the two claims (the no-bottom condition), then the
two branches themselves compose into a direct binary two-query RLDC. The
exponential 2-query RLDC lower bound therefore forces exponential proof length.

Thus, in this low-query model, bottom is not merely a nuisance in the analysis:
it is the only way to avoid the direct 2-query coding barrier.

## Two-branch interface

Let

\[
  \Pi:\{0,1\}^k\longrightarrow\{0,1\}^P
\]

be an injective proof map. Fix constants \(\delta>0\) and
\(\beta<1/2\), and assume distinct proof words have distance greater than
\(2\delta\). For every message coordinate \(i\in[k]\) and claim
\(b\in\{0,1\}\), let \(V_{i,b}\) be a randomized verifier that reads at most
one proof symbol. Write \(p_{i,b}(z)\) for its acceptance probability on
received word \(z\).

Assume the following two properties.

### Perfect branch separation on honest proofs

For every message \(m\) and coordinate \(i\),

\[
  p_{i,m_i}(\Pi(m))=1,
  \qquad
  p_{i,1-m_i}(\Pi(m))=0.
\tag{235.1}
\]

The second equality is the no-bottom condition: the two claims are never both
accepted on the same honest proof.

### Target-relative wrong-branch soundness

For every \(m,i\) and every \(z\) satisfying
\(\operatorname{dist}(z,\Pi(m))\le\delta\),

\[
  p_{i,1-m_i}(z)\le\beta.
\tag{235.2}
\]

No lower bound on the correct branch at a corrupted word is assumed. This is
important: relaxed decoding is allowed to output \(\bot\), so only the wrong
branch needs to be controlled.

## Theorem (no-bottom two-branch barrier)

Under (235.1)--(235.2),

\[
  P\ge 2^{\Omega_{\delta,\,1/2-\beta}(k)}.
\tag{235.3}
\]

### Proof

For coordinate \(i\), independently sample the random coins of
\(V_{i,0}\) and \(V_{i,1}\), query their at-most-one proof locations, and define
\(\mathsf{Dec}_i(z)\) as follows:

* output \(b\) if exactly the branch \(V_{i,b}\) accepts;
* output \(\bot\) if both branches accept or both reject.

The decoder makes at most two queries. On an honest codeword \(\Pi(m)\), the
correct branch accepts with probability one and the wrong branch never accepts,
so \(\mathsf{Dec}_i(\Pi(m))=m_i\) with probability one.

Now let \(z\) be within distance \(\delta\) of \(\Pi(m)\). A wrong decoder
output can occur only when the wrong branch accepts. Hence

\[
  \Pr[\mathsf{Dec}_i(z)\neq m_i,\ \mathsf{Dec}_i(z)\neq\bot]
  \le p_{i,1-m_i}(z)\le\beta,
\]

and therefore

\[
  \Pr[\mathsf{Dec}_i(z)\in\{m_i,\bot\}]
  \ge 1-\beta>\frac12.
\tag{235.4}
\]

Thus \((\Pi,\mathsf{Dec})\) is a weak adaptive
\((2,\delta,1-\beta)\)-RLDC over the binary alphabet. Applying Theorem 1 of
Block, Blocki, Cheng, Grigorescu, Li, Zheng, and Zhu gives (235.3). \(\square\)

## RW/JK consequence

Suppose a proposed simultaneous coordinate-robust RW/JK proof uses two claim
verifiers with one proof query each, and satisfies a fixed positive radius,
perfect honest completeness, and (235.1)--(235.2). Then a near-linear or even
polynomial proof length is impossible. The obstruction is independent of
linearity, projection structure, or the internal PCP encoding.

The result also gives a precise interpretation of the bottom escape. If a
near-linear binary construction remains at this one-query-per-claim interface,
then at least one of the following must fail:

1. honest-proof branch separation (bottom occurs);
2. perfect completeness;
3. a fixed positive Hamming radius;
4. the binary alphabet;
5. the two-query total after composing the claims.

In particular, merely proving that the wrong claim has acceptance probability
less than one on honest proofs is not enough: any positive simultaneous
acceptance can make the composed decoder output \(\bot\) and lose perfect
completeness. Exact no-bottom separation is the condition needed for the
exponential theorem.

## Relation to the general ACRR compiler

The common-proof interface of note 01 allows each claim verifier to make \(q\)
queries and only assumes a completeness/soundness gap. Its generic thresholding
compiler uses repeated evaluations of both branches and has locality
\(O(q(\alpha-\beta)^{-2})\). Therefore (235.3) does not automatically apply
when \(q>1\), or when one-query branches lack (235.1).

The theorem is consequently a source-specific classification, not a general
coordinate-robust dPCP impossibility result:

* a bottom construction may evade the direct 2-query reduction;
* three or more total proof queries enter a different RLDC regime;
* larger alphabets and imperfect completeness are outside the cited exponential
  lower bound;
* cover-aware or interactive global strategies require separate analysis.

What is closed is the exact “one query per binary claim + no bottom + positive
radius” corner of Closure Gate I.

## Source boundary

The coding input is Definition 1 and Theorem 1 of:

> A. R. Block, J. Blocki, K. Cheng, E. Grigorescu, X. Li, Y. Zheng, and
> M. Zhu, *Exponential Lower Bounds for 2-query Relaxed Locally Decodable
> Codes*, arXiv:2602.20278v2 (2026).

Source: <https://arxiv.org/abs/2602.20278>.

The cited lower bound is specifically for binary Hamming RLDCs, even adaptive,
and crucially assumes perfect completeness. Extending (235.3) to larger
alphabets, imperfect completeness, or the general two-branch ACRR model is a
separate problem.

## Status of the Closure program

This result does not close the full RW succinct smart reconstruction theorem.
It does sharpen one of its four structural escape gates: if bottom is excluded
and the claim branches are genuinely one-query binary branches, the remaining
proof cannot stay near-linear. The positive program must therefore either
construct bottom-safe robustness at a higher query/alphabet regime, or prove a
new general lower bound for the surviving regime.
