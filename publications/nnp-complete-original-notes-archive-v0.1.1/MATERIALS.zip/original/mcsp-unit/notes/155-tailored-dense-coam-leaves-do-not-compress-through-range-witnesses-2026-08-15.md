> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Tailored dense-coAM leaf outsiders 不由 Range-NP witness 压缩（2026-08-15）

## 结论

沿用 [note 154](154-dense-coam-property-forces-leaf-outsiders-2026-08-15.md)。令

\[
G_q:\{0,1\}^{q}\to\{0,1\}^{2q},
\qquad R_q=\operatorname{Range}(G_q).
\tag{1}
\]

把长度为 \(N\) 的字符串的前 \(2qH\) 位分成 \(H\) 个 leaf blocks，并定义

\[
\Pi_G[N]=\{W:\forall j<H,\ B_j\notin R_q\}.
\tag{2}
\]

tailored dense-coAM 性质解决了“哪个 leaf 是 outsider”的组合选择：CLL 的 dense-coAM
构造在无穷多个长度给出 \(W_N\in\Pi_G[N]\)，所以每个 \(B_j\notin R_q\)。它没有
解决叶内容的低地址尺度生成。本文不声称 \(P\ne NP\)。

## 1. Range-NP witness 的零信息边界

对显式 block \(b\in\{0,1\}^{2q}\)，membership 关系是

\[
b\in R_q
\iff
\exists u\in\{0,1\}^{q}\;\forall \ell\in[2q],
G_q(u)_\ell=b_\ell .
\tag{3}
\]

给定 \(u\) 后扫描全部输出位只需 \(\operatorname{poly}(q)\) 时间，因此 (3) 是 NP
验证，而 \(\operatorname{Out}_q=\{b:b\notin R_q\}\) 属于 coNP。对任意
\(W\in\Pi_G[N]\)，range-witness oracle 在每个真实 leaf 上都只返回“无 witness”。

更精确地，设 deterministic reconstruction scheme 只使用 \((N,q,j)\)、长度为 \(a\)
的 advice，以及固定的 range-witness oracle，并声称对**每个** \(W\in\Pi_G[N]\)
输出第 \(j\) 个 leaf。oracle 不以隐藏的 \(W\) 为参数，所以给定 advice 后的
transcript 和输出是确定的，最多产生 \(2^a\) 个不同 leaf blocks。

记

\[
M_q=2^{2q}-|R_q|.
\]

每个 leaf 可以独立取任意 outsider；覆盖所有可能的第 \(j\) 个 leaf 必须满足

\[
2^a\ge M_q,
\qquad a\ge \log_2 M_q.
\tag{4}
\]

因为 \(|R_q|\le 2^q\)，有

\[
M_q\ge 2^{2q}-2^q\ge 2^{2q-1},
\qquad a\ge 2q-1.
\tag{5}
\]

若要重构整个 \(W\)（包括 \(H\) 个 leaf 和其余自由 bits），则

\[
|\Pi_G[N]|=M_q^H2^{N-2qH},
\qquad
a\ge H\log_2M_q+N-2qH.
\tag{6}
\]

note 154 的密度估计给出 \(|\Pi_G[N]|\ge 2^N/32\)，于是至少需要 \(a\ge N-5\) 位
来覆盖全部性质成员。这是 deterministic information lower bound，不是 AM 交互的下界；
它只说明未压缩的 leaf information 必须留在 Merlin strategy、额外 advice 或新的
canonical summary 中。

## 2. 单个 outsider 仍在 \(q\)-尺度

对前缀 \(p\in\{0,1\}^{r}\)，定义

\[
\operatorname{ExtOut}_q(p)
\iff
\exists y\in\{0,1\}^{2q-r}\quad py\notin R_q.
\tag{7}
\]

展开 (3) 的补集可得

\[
\operatorname{ExtOut}_q(p)
\iff
\exists y\;\forall u\in\{0,1\}^{q},\quad G_q(u)\ne py .
\tag{8}
\]

给定 \(u,y\)，不等式可由扫描输出坐标在确定性多项式时间内判定，所以 (7) 属于
\(\Sigma_2^P\)。逐位自归约得到

\[
b_q^*=\operatorname{lexmin}(\operatorname{Out}_q)
\in \operatorname{FP}^{\Sigma_2^P}.
\tag{9}
\]

若 range 覆盖所有 size-\(\le s(q)\) truth tables，则
\(\operatorname{CC}(b_q^*)>s(q)\)。但输出 \(2q\) 位本身需要 \(\Omega(q)\) 时间；即使
\(P=NP\) 使 (9) 降为确定性 polynomial-time，它仍是 \(\operatorname{poly}(q)\)-time，
而不是目标的 \(\operatorname{poly}(\log q)\) 或 base-\(n\) 尺度。tailored 性质没有改变
这个单块搜索尺度。

## 3. CLL 按位读取是条件性接口

在 CLL Theorem 1.3 的 conformity/resiliency 语义下，固定其正确 advice \(\alpha_N\)，
令 \(x_N\) 为 canonical 输出，并定义查询

\[
Q_{N,a,b}=\{\text{模拟协议；输出非 }\bot\text{ 且第 }a\text{ 位为 }b\}.
\tag{10}
\]

正确 advice 下，\(b=x_N[a]\) 的查询完备率为 1，而 \(b\ne x_N[a]\) 的错误率至多
\(1/3\)。逐个地址运行 (10) 可以交互式读取叶块；在命中长度上，note 154 保证这些
叶块都是 range outsiders。

但这不等于 smart-prMA accessor：

1. CLL 的 advice 长度为 \(2^{(\log N)^{1/k}}\)，运行时间为
   \(2^{(\log N)^{O(k)}}\)。当 \(N=\operatorname{poly}(n)\) 时，运行时间仍可能是准多项式；
   当地址尺度取 \(n=\log N\) 时，advice、运行时间以及输出整块的 \(\Omega(q)\) 成本都
   不在 \(\operatorname{poly}(n)\) 内。
2. 不能把任意 advice 交给 Merlin 就宣称 (10) 是 promise 查询。错误 advice 的 resiliency
   只保证某个输出或 \(\bot\)，不保证存在产生该输出的完备策略；不同地址的二值查询
   未必共享同一个合法 promise witness。
3. 若去掉 Merlin 而得到 deterministic、polynomial-address、word-consistent accessor，
   则会撞上 note 150 对 CLL hard string 的 accessor 排除。

## 4. 足以推出分离的 smart-prMA 接口（仍未证）

至少需要一个统一局部编译器，满足：

\[
\begin{aligned}
&\text{由 }(n,N,a,b)\text{ 在 }\operatorname{poly}(n)\text{ 时间生成查询；}\\
&\text{advice/commitment 在 }\operatorname{poly}(n)\text{（/1 路线为 }O(1)\text{）长度内给定；}\\
&\text{同一 fixed strategy 对所有地址返回同一个完整 word，且位逐一一致；}\\
&\text{所有实际查询满足同一个 prMA promise，命中长度有无限多个。}
\end{aligned}
\tag{11}
\]

若 (11) 成立，则在 \(P=NP\)（或相应的 \(NP\subseteq P/poly\)）假设下可将固定层查询
确定化/电路化，得到大小 \((n+\log q)^{O(1)}\) 的叶 accessor。若 coverage 同时排除
所有大小不超过 \(s(q)\) 的叶表，且 \((n+\log q)^{O(1)}\le s(q)\) 在无穷多个长度成立，
就得到矛盾并推出相应复杂性分离。这只是充分接口；CLL Theorem 1.3 与 note 154 当前
都没有提供 (11)。

## 证据边界

- note 154 给出 tailored coAM 性质、密度和所有 leaf outsider 的存在性；
- note 149/150 给出 AM commitment 与 deterministic accessor 的信息/复杂度边界；
- note 121 给出低尺度 smart-prMA accessor 足以推出 \(P\ne NP\) 的充分条件。

本文新推论是 (4)--(11)，不声称证明一般 range lower bound 或 \(P\ne NP\)。

来源：Carmosino--Liu--Lyu, *Maximum Circuit Lower Bounds for Exponential-Time Arthur
Merlin*, ECCC TR24-182 revision 2，原文核验日期 2026-08-15：
<https://eccc.weizmann.ac.il/report/2024/182/>。
