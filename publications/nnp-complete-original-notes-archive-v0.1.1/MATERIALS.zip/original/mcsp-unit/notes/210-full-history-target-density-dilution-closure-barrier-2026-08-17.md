> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Full-history target-density dilution barrier (2026-08-17)

## 结论

把一个 singleton-output dPCP 的平均/list soundness 黑箱地应用到**完整 computation
history**，再读取其中少数 RW 输出坐标，会付出完整 history 的密度因子，而不是只付出
输出长度的密度因子。这个因子是一个精确的加权不等式，不依赖 PCP 的具体图结构：

* 若完整 proof/assignment 的坐标分布为 \(\mu\)，目标坐标集合为 \(J\)，则目标坐标
  的平均错误率至多为 \(\varepsilon/\mu(J)\)；
* 单个目标坐标 \(i\) 的错误率至多为 \(\varepsilon/\mu_i\)；
* 在长度 \(L\) 的完整 history 上均匀采样时，固定坐标的黑箱保证是
  \(L\varepsilon\)，目标集合大小 \(K\) 的平均保证是 \(L\varepsilon/K\)。

因此，若 RW 的 target bits 只是长度 \(L\) history 中的 \(K\) 个普通坐标，而 verifier
仍对整个 history 均匀采样，那么常数 simultaneous coordinate robustness 要求

\[
\varepsilon\le \beta/L\quad\text{(每个目标坐标)},\qquad
\varepsilon\le \beta K/L\quad\text{(目标块平均)}.
\tag{210.1}
\]

这严格加强了只按输出长度 \(K\) 记账的 \(O(1/K)\) 条件。它不排除一个真正的
target-normalized / target-binding compiler；它证明的是：**普通 full-history dPCP
的 scalar average soundness 不能直接完成 RW Closure Gate I。**

## 定理（加权 full-history dilution）

令 \(U\) 是完整 assignment 的坐标集，\(\mu\) 是 dPCP 在 \(U\) 上的输出坐标分布。
对候选全局 proof \(\Pi\)，记

\[
b_u(\Pi)=\Pr[\text{局部约束接受且 decoder 在坐标 }u\text{ 落在 list 外}\mid u].
\]

对目标坐标 \(i\in J\)，再记 \(p_i(\Pi,c)\) 为声明
\(c\ne y_i^\star\) 的接受率。singleton 投影只用于下面这一点：
\(p_i(\Pi,c)\le b_i(\Pi)\)。非目标坐标的 list 允许包含私有 witness 的不同符号；
定理不把它们误当成 singleton。

假设合法 decoded words 在目标坐标 \(J\subseteq U\) 上投影为同一个 singleton
word \(y^\star|_J\)，并且 dPCP 只提供如下 scalar average guarantee：

\[
\sum_{u\in U}\mu_u b_u(\Pi)\le\varepsilon
\qquad\text{for every candidate }\Pi.
\tag{210.2}
\]

写 \(\mu_J=\sum_{u\in J}\mu_u\)。则：

1. 对任意 \(i\in J\)，错误声明接受率满足
   \[
   p_i(\Pi,c)\le b_i(\Pi)\le \min\{1,\varepsilon/\mu_i\}.
   \tag{210.3}
   \]
2. 目标集合上的加权平均 list-outside 率满足
   \[
   \frac{1}{\mu_J}\sum_{i\in J}\mu_i b_i(\Pi)
   \le \min\{1,\varepsilon/\mu_J\}.
   \tag{210.4}
   \]
3. 这些界只由 (210.2) 推出时是 sharp 的：若 \(i_\star\) 是最小正权重坐标，存在
   一个 singleton、单全局 assignment 的一边 dPCP，使得所有错误质量集中在
   \(i_\star\)，并达到 \(\min\{1,\varepsilon/\mu_{i_\star}\}\)。

### 证明

因为每一项非负，(210.2) 直接给出
\(\mu_i b_i(\Pi)\le\varepsilon\)，而 singleton 投影给出
\(p_i(\Pi,c)\le b_i(\Pi)\)，即 (210.3)。对 \(i\in J\) 求和，再除以
\(\mu_J\)，得到 (210.4)。

sharpness 取唯一合法词为 \(0^{|U|}\)，让所有局部约束恒真；选一个自由左符号
使 decoder 只在 \(i_\star\) 输出该符号、其余坐标恒输出 \(0\)。诚实 assignment
取自由符号 \(0\)，候选 assignment 取 \(1\)。此时只有 \(i_\star\) 产生错误，平均
错误质量正好是 \(\mu_{i_\star}\)。通过把 \(i_\star\) 的错误概率混合为
\(\varepsilon/\mu_{i_\star}\)（或加入等价的随机局部边）即可达到上界。整个构造使用
同一 proof/address space，故不是逐坐标换 proof 的量词伪影。

## 完整 history 的推论

若 \(U=[L]\) 且 \(\mu_u=1/L\)，目标坐标集 \(J\) 大小为 \(K\)，则

\[
p_i(\Pi,c)\le \min\{1,L\varepsilon\},\qquad
\frac1K\sum_{i\in J}b_i(\Pi)\le\min\{1,L\varepsilon/K\}.
\tag{210.5}
\]

所以要得到每个目标坐标的错误率至多 \(\beta<1\)，标量 average theorem 至少需要
\(\varepsilon\le\beta/L\)；若只要求目标块的平均错误率至多 \(\beta\)，也至少需要
\(\varepsilon\le\beta K/L\)。

这两个阈值分别对应不同的 Closure 目标，不能把它们混写：RW 的 JK/Reconf 通常需要
每个声明位都 smart，而不是只在目标块上平均正确。

## RW/PCP 参数含义

设一个拟议的 RW relation compiler 把完整 canonical history 的 \(L_n\) 个坐标交给
普通 dPCP，只有 \(K_n\) 个坐标是最终 AVOID/JK 输出，且 dPCP 的 scalar soundness
是在整个 history 上计量。只要 target projection 是 singleton，(210.5) 给出：

\[
\varepsilon_n\le \beta/L_n\quad\text{(逐目标 smartness)},\qquad
\varepsilon_n\le \beta K_n/L_n\quad\text{(目标平均)}.
\tag{210.6}
\]

因此，若 \(L_n\gg K_n\)，把一个固定 \(\varepsilon\) 的近线性 dPCP 定理直接套在
完整 history 上，并不能得到地址级 coordinate robustness。必须至少加入以下一项：

1. **target-normalized sampling：** 目标坐标在 verifier 的坐标分布中有
   \(\mu_J=\Omega(1)\)，而不是 \(K_n/L_n\)；
2. **target-binding outer code：** 一个错误目标位会在常数比例的被采样 code coordinates
   上产生错误，而不是只改一个 raw history slot；
3. **非标量的全局 soundness：** 直接排除“所有错误都集中在一个目标坐标”的候选
   proof，而不是仅给 (210.2)；
4. **显式压缩/共享投影：** 在保持同一 proof/address space 的同时，把 private
   witness 从坐标采样分布中移出，并证明 target projection 的 uniformity 与
   word consistency。

没有这四项中的任一项，普通 full-history list/distributional soundness 只给
\(L_n\)-尺度的错误界，不能实例化 RW Succinct Smart Reconstruction 的 Gate I。

## 与现有结果的关系和边界

这不是对未来 coordinate-normalized dPCP 的不可能性定理。它只对“先对完整 history
做 scalar average soundness，再把少数目标坐标当作普通坐标读取”的黑箱组合给出 sharp
参数障碍。若一个新构造直接在目标坐标上给 coordinate-wise robust soundness，或让
目标 codeword 占据常数采样质量，则 (210.1) 不适用；那正是项目所要寻找的新机制。

同样，(210.6) 只需要实际 history 长度 \(L_n\) 的下界。现有 RW/PCP 文献给出的
“history 长度至多 \(T_n^{O(1)}\)”本身不是一个下界，不能仅凭上界把
\(L_n\) 替成 \(T_n^{O(1)}\)。若某个具体 compiler 的 exposed history 确实包含
\(L_n\ge L_{\min,n}\) 个坐标，则应把 (210.6) 中的 \(L_n\) 换成
\(L_{\min,n}\)。这一区分避免把 proof-size upper bound 误报成 hardness lower bound。

## 论文级晋级含义

这个定理把 Closure Gate I 的正向目标从“再做一次普通 dPCP”收窄为一个明确的
**target-density / target-binding theorem**：需要构造一个在 \(K/L\ll1\) 时仍能给出
常数固定坐标 gap 的全局 proof，或者证明任何这种构造必须支付 RLDC/LDC、proof length
或 descriptor 熵代价。它把 full-history dilution 变成可直接对照新 PCP/coding theorem
的量化接口，而不是口头的“witness 会淹没 output”。

## 来源与证据边界

加权不等式是本项目直接推导；singleton target projection 只保证错误事件包含在
list-outside 事件中。关于固定 \(\varepsilon\) 的近线性 dPCP 参数与其不提供统一
\(\varepsilon\to0\) 账本，见 [GMWZ](https://arxiv.org/html/2512.12960) 及
[weighted distributional-to-coordinate barrier](../../rw-jk-succinct-reconstruction/statements/distributional-to-coordinate-weight-barrier.md)。
本 note 不声称 RW 当前 canonical history 已满足某个具体 \(L_n\) 下界，也不声称
GMWZ 的 future target-normalized construction 不存在。
