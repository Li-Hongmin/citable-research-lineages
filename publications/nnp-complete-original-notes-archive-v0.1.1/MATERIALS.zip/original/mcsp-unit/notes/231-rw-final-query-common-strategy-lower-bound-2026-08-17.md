> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW final-query common-strategy lower bound (2026-08-17)

## Contribution

Ren--Williams Theorem 4.1 already has one shared-proof property stronger than a
per-coordinate existential statement: after the canonical prefix is fixed, all final
queries \(q_{\mathrm{pfx},j}\) use the same PCP proof circuit \(\Pi_x\).  Only the final
output-bit test depends on \(j\).  This note applies the common-strategy sampling theorem
to that exact failure branch.

At a stage where the reconstructed AVOID output also satisfies a circuit lower bound
\(\operatorname{CC}(B_i)>S_i\), every finite common-response implementation must pay

\[
  p_i=\Omega(S_i/m_i)
  \quad\text{or}\quad
  b_i d_i=\Omega(S_i/m_i)
\tag{231.1}
\]

in the straight-line ROM model.  Here \(m_i\) is the address length, \(p_i\) is ordinary
control size, \(d_i\) is the common static descriptor length, and \(b_i\) is the number
of descriptor reads per execution.  Public randomness is not an escape, and neither is
a short finite strategy summary.

This is a source-specific address-scale lower bound.  It does not claim that every
coordinate-robust construction is impossible, and it does not by itself prove
\(P\ne NP\).  It rules out a precisely specified finite common-strategy compression of
the existing RW failure branch.

## RW failure-branch setup

Use the notation of Theorem 4.3:

\[
  B_i:=BF_i(G_{n_i})\in\{0,1\}^{2n_i},\qquad
  k_i:=n_{i+1},\qquad
  T_i:=\max\{2^{cD^i n_0},n_{i+1}\}.
\tag{231.2}
\]

On the stable tail \(i\ge i^\star\), \(T_i=k_i=n_i^C\).  Put

\[
  m_i:=\lceil\log_2(2n_i)\rceil,\qquad N_i:=2n_i.
\tag{231.3}
\]

If \(BF_{i+1}\) fails on \(G_{n_{i+1}}\), Theorem 4.1 supplies, for every
\(j\in[T_i]\), a smart prMA query after one common prefix

\[
  \pi_i\in\{0,1\}^{r'_i},\qquad r'_i=O(r_i\log T_i).
\tag{231.4}
\]

For the first \(N_i\) coordinates these queries compute \(B_i[j]\).  The source proof
uses one and the same PCP proof \(\Pi_{x_0}\), represented by one circuit \(C_i\), for
all final queries \(q_{\pi_i,j}\).  Their promise gap is

\[
  B_i[j]=1\Longrightarrow
  \Pr_R[V_i(j,R,C_i)=1]=1,
  \qquad
  B_i[j]=0\Longrightarrow
  \forall C\;\Pr_R[V_i(j,R,C)=1]\le\tfrac12.
\tag{231.5}
\]

The public tape \(R\) contains the PCP-verifier and low-degree-self-corrector coins.
Its original length is irrelevant to the sampling argument below.

## Finite common-response model

Fix \(i\) and the selected prefix \(\pi_i\).  A finite ROM implementation of the final
queries consists of:

* a static descriptor \(\sigma_i\in\{0,1\}^{d_i}\) containing the prefix, the common
  proof/strategy summary, a cover label, and finite auxiliary constants;
* a fan-in-two control circuit of size \(p_i\), taking \((j,R)\) and producing the
  verifier computation and common response transcript;
* at most \(b_i\) arbitrary reads of \(\sigma_i\) during one execution.

The same \(\sigma_i\) and response rule must work for every \(j\in[N_i]\).  The response
may be a long Merlin message; only its random access is required to be finite.

## Theorem (RW common-strategy lower bound)

Assume that, on the same length,

\[
  B_i\notin\operatorname{Range}(G_{n_i}),
  \qquad
  \operatorname{CC}(B_i)>S_i.
\tag{231.6}
\]

If the final queries admit the finite common-response model above, then

\[
  \operatorname{CC}(B_i)
  \le
  O\!\left(m_i\,(p_i+b_i d_i+m_i)^{O(1)}\right).
\tag{231.7}
\]

In the straight-line ROM expansion, the sharper bound is

\[
  \operatorname{CC}(B_i)
  \le O\!\left(m_i(p_i+b_i d_i+m_i)\right).
\tag{231.8}
\]

Consequently, whenever the control term is below the forcing scale,

\[
  p_i+m_i=o(S_i/m_i)
  \quad\Longrightarrow\quad
  d_i=\Omega\!\left(\frac{S_i}{m_i b_i}\right).
\tag{231.9}
\]

Equivalently, up to the additive \(m_i\)-scale terms, (231.1) holds.

### Near-maximum specialization

If the forcing side supplies

\[
  S_i=\Omega\!\left(\frac{n_i}{\log(n_i+2)}\right),
\tag{231.10}
\]

then \(n_i=2^{m_i-1}\), and (231.9) gives

\[
  d_i=\Omega\!\left(\frac{2^{m_i}}{m_i^2b_i}\right).
\tag{231.11}
\]

Thus \(p_i,b_i\le m_i^{O(1)}\) forces
\(d_i=2^{\Omega(m_i)}\), not an \(m_i^{O(1)}\)-size address-scale strategy.

## Proof

Apply the common-strategy sampling theorem to the \(N_i\) addresses with

\[
  \ell_i=\lceil\log_2N_i\rceil=m_i,\quad
  \alpha=1,\quad\beta=\tfrac12,\quad\gamma=\tfrac12,\quad\delta=1/3.
\]

Hoeffding and a union bound give one fixed multiset of \(O(m_i)\) public tapes whose
empirical acceptance rate separates the two cases in (231.5) simultaneously for every
\(j\).  Hardwire those tapes and \(\sigma_i\).  Expanding each descriptor read into a
standard multiplexer gives (231.7); the straight-line ROM expansion gives (231.8).
Combining (231.8) with (231.6) gives (231.9), and substitution of (231.10) gives
(231.11). \(\square\)

## Consequence for the actual RW interface

The published construction has two different scales:

1. \(B_i\) has address length \(m_i=\Theta(\log n_i)\);
2. the shared prefix has length \(r'_i=O(r_i\log T_i)\), which can be
   \(O(n_i\log n_i)\) on the stable tail;
3. the source Merlin proof circuit has gate-list size
   \(O(k_i^4\log T_i)\), with \(k_i=n_{i+1}=2^{\Theta(m_i)}\).

Hence the published Reconf is compatible with (231.7): it pays object-scale cost.
What (231.7)--(231.12) rule out is a claim that the same final queries can be compressed
to \(m_i^{O(1)}\) finite common control and descriptor while retaining (231.6).
The lower bound applies to the total descriptor, so renaming the prefix, cover label, or
strategy summary does not evade it.

## Boundaries

* Mere non-membership \(B_i\notin\operatorname{Range}(G_{n_i})\) does not imply (231.6);
  the forcing lower bound must hold on the same lengths.
* The theorem rules out finite common-response/ROM compression of this RW branch.  It
  does not rule out unbounded interactive strategies, different strategies per address,
  or a genuinely new globally coupled PCP construction.
* It does not use a family-level ACRR assumption and does not itself prove an RLDC lower
  bound.  A complete closure theorem still needs a patchability/RLDC branch or a new
  global coupling outside the finite common-descriptor model.

## Source boundary

The used source facts are Theorem 4.1 and the proof of Theorem 4.3: Reconf is smart on
the failure branch; the same \(\Pi_x\) is a valid Merlin witness for every coordinate;
the final query has the \(1\) versus \(\le1/2\) gap; and
\(k_i=n_{i+1}\), \(T_i=\max\{2^{cD^in_0},n_{i+1}\}\), with
\(T_i=n_{i+1}=n_i^C\) on the stable tail.  The local source extraction is
units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md,
Theorem 4.1 and the proof of Theorem 4.3.
