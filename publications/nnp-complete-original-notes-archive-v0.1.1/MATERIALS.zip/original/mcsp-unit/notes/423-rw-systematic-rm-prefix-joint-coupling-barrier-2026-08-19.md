> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW systematic Reed--Muller prefix 的 arbitrary-joint-coupling barrier（2026-08-19）

## 本轮改变的判断

C422 对任意距离分离的 family 给出 latent-state information barrier，但它把
距离作为外部假设。这里把该假设直接从 Ren--Williams Theorem 3.4/3.5 的
systematic Reed--Muller witness 中导出，得到一个更贴近实际 source 的 Gate-I
接口：

> 对 RW 的 identity family，只要 proposed global relation 实际绑定
> systematic witness prefix，而不是只绑定一个未解释的 auxiliary/output 槽，
> 任意 post-seed joint coupling 若由 sublinear target-independent state 产生，
> 都必须携带线性 input information。

这仍是 family-level source theorem，不是 published Theorem 4.3 的 fixed-\(x_0\)
singleton，也不直接推出 \(P\ne NP\)。

## RW source family 与 systematic prefix

取合法的 identity machine

\[
 M_{\mathrm{id}}(x)=x,\qquad x\in\{0,1\}^{b},
\tag{423.1}
\]

其运行时间取为 \(\operatorname{poly}(b)\)，不发 NP query，输出长度为 \(b\)。
对每个 \(x\)，RW Lemma 3.2 产生 Circuit-SAT 电路 \(C_x\)，其 lexicographically
largest satisfying assignment \(w_x\) 的 output field 等于 \(x\)。因此
\(x\ne x'\) 时 \(w_x\ne w_{x'}\)。

按 RW Theorem 3.4 的 systematic PCP 实例，把 \(w_x\) 看成
\(H^m\) 上的 Boolean table，并令
\(\widetilde w_x:F^m\to F\) 为其 Reed--Muller extension。记

\[
 D:=m|H|,\qquad Q:=|F|^m.
\tag{423.2}
\]

Theorem 3.4 保证 \(\widetilde w_x\) 的总次数至多 \(D\)，并把其完整 truth table
作为 proof 的 systematic witness field。

## 引理 423.1（systematic RM 距离）

对任意 \(x\ne x'\)，

\[
 d_H(\widetilde w_x,\widetilde w_{x'})
 \ge \left(1-\frac{D}{|F|}\right)Q.
\tag{423.3}
\]

在 RW 的参数选择 \(|F|\ge \alpha D^3\) 下，

\[
 \delta_{\mathrm{RM}}
:=1-\frac{D}{|F|}
 \ge 1-\frac{1}{\alpha D^2}.
\tag{423.4}
\]

### 证明

\(w_x\ne w_{x'}\) 意味着 \(\widetilde w_x-\widetilde w_{x'}\) 是一个非零的
多变量多项式，总次数至多 \(D\)。Schwartz--Zippel 给出它在 \(F^m\) 上的零点
数至多 \(D|F|^{m-1}\)。因此至少有
\((1-D/|F|)|F|^m\) 个 field positions 不同，得到 (423.3)；代入
\(|F|\ge\alpha D^3\) 得 (423.4)。证毕。

## 定理 423.2（RW systematic-prefix latent-state barrier）

令 \(X\) 在 \(\{0,1\}^b\) 上均匀取值，令
\(Z\in F^{F^m}\) 是同一个 systematic witness address space 上生成的 global
word。设 \(S\) 是完整 policy/descriptor/cover/transcript package，\(W\) 是任意
latent global state，并满足

\[
 X\longrightarrow(S,W)\longrightarrow Z.
\tag{423.5}
\]

若对某个

\[
 t_b<\frac{\delta_{\mathrm{RM}}Q}{2}
\tag{423.6}
\]

有

\[
 \Pr\!\left[d_H(Z,\widetilde w_X)\le t_b\right]=p_b,
\tag{423.7}
\]

则

\[
\boxed{
 I_2(X;S)+I_2(X;W\mid S)\ge p_b b-1.
}
\tag{423.8}
\]

若 \(H_2(W\mid S)\le h_b\)，则

\[
 I_2(X;S)+h_b\ge p_b b-1.
\tag{423.9}
\]

### 证明

由引理 423.1，\(\{\widetilde w_x\}_{x\in\{0,1\}^b}\) 的最小距离大于
\(2t_b\)。因此半径 \(t_b\) 的 nearest-word decoder 从 \(Z\) 唯一恢复 \(X\)
（不在任何球内时输出 \(\bot\)）。Fano 给出
\(I_2(X;S,Z)\ge p_b b-1\)。条件数据处理和 (423.5) 给出
\[
 I_2(X;Z\mid S)\le I_2(X;W\mid S),
\]
合并 chain rule 即得 (423.8)，再用
\(I_2(X;W\mid S)\le H_2(W\mid S)\le h_b\) 得到 (423.9)。证毕。

## 推论 423.3（实际 source 上的 joint-coupling 逃逸分类）

若 \(p_b\ge p_0>0\)、\(I_2(X;S)=o(b)\)，且
\(H_2(W\mid S)=o(b)\)，则 systematic-prefix relation 与 (423.5)--(423.7)
矛盾。特别地，任何 target-oblivious、\(O(\operatorname{polylog} b)\)-state 的
arbitrary joint coupling 都不能以常数概率在半个 systematic RM 距离内绑定
整个 identity-family witness prefix。

因此，针对 RW/Harsha 的该 family lift，剩余正向路线至少要明确选择一项：

1. 让 \(S\) 或 \(W\) 携带 \(\Omega(b)\) bits 的 input information；
2. 不绑定 systematic witness prefix，而只绑定 output/auxiliary 槽；
3. 放弃 target-independent kernel，使用在给定 package 后仍直接读取 target
   的 interaction/oracle semantics。

## 与 published RW Closure 的边界

* \(M_{\mathrm{id}}\) 是 Theorem 3.5 允许的 source-level specialization；它把
  RW 的 systematic witness 量词变成可直接测量的 RM code distance。
* 定理只处理 witness-prefix address space。若一个 proposed closure 只给出
  binary auxiliary/ECC suffix 的 whole-word 接近性，必须另行证明该接近性投影到
  prefix；不能把 (423.8) 自动套到任意 suffix。
* 对 published Theorem 4.3，\(f_i\) 忽略输入且每层固定 \(x_0\)，没有
  \(2^b\) 个 target codewords；因此 (423.8) 不能直接给出 singleton forcing
  矛盾。
* Theorem 3.4 的 systematic field 是 source fact；它没有给出从某个 auxiliary
  block 到 output 的局部逆，也没有给出 actual RW family lift。该定理只关闭
  “已绑定 systematic prefix 但声称 joint state 很短”的分支。

## 证据边界

* RW Lemma 3.2：identity machine 的 satisfying assignment output field 等于 \(x\)；
* RW Theorem 3.4：systematic Reed--Muller witness、总次数 \(m|H|\) 与
  \(|F|\ge\alpha(m|H|)^3\) 的参数；
* C422：任意 target-independent latent-state channel 的 Fano/data-processing
  闭合；
* 引理 423.1 只用 Schwartz--Zippel，不把 Harsha auxiliary factorization
  偷换成局部逆。

本 note 不声称已完成 RW Gate I，不声称一般 dPCP/RLDC 不可能性，也不声称
\(P\ne NP\)。
