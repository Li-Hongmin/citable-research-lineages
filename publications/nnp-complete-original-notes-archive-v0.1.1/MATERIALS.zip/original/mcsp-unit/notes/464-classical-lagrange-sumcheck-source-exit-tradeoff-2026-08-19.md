> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Classical Lagrange sum-check source-exit tradeoff（2026-08-19）

## 本轮改变的判断

C458 排除了从 \(H^m\) systematic table 黑箱精确评价 generic \(q(u)\)，C448--C450
则要求新的 non-product global relation 明确支付 proof、visible state 或 soundness 量词。
最自然的候选是把 tensor Lagrange identity 写成 sum-check。这个候选确实给出
polylogarithmic online verification，但在标准的显式 round-polynomial、target-independent
full-LDE 模型中，不能同时保持 near-linear common proof 与 polylogarithmic visible
transcript。

更精确地，单次执行的一次 opening 不能当作 single-valued generic evaluator：跨越所有
public challenges 的 proof-address support 恰为整张 \(F^m\) LDE。在 published Harsha
参数下，该 support 长度为 \(N^{6+o(1)}\)。因此 classical sum-check 是一个严格的
finite-state non-product relation，但不是免费的 RW source-exit。

## Lagrange global relation

令 \(F\) 为有限域，\(H\subsetneq F\)，\(h=|H|\ge2\)，并令

\[
 \mathcal P_{H,m}
 =\{q\in F[X_1,\ldots,X_m]:\deg_{X_i}q<h\}.
\]

记 \(\ell_a\) 为 \(H\) 上的 Lagrange basis。对 \(u\in F^m\)，定义

\[
 \lambda_u(T):=\sum_{a\in H}\ell_a(u)\ell_a(T),
 \qquad
 W_u(X):=\prod_{i=1}^m\lambda_{u_i}(X_i).
\tag{464.1}
\]

对每个 \(z\in H^m\)，有 \(W_u(z)=\prod_i\ell_{z_i}(u_i)=L_z(u)\)。因此

\[
 q(u)
 =\sum_{z\in H^m}q(z)L_z(u)
 =\sum_{z\in H^m}G_{q,u}(z),
 \qquad
 G_{q,u}(X):=q(X)W_u(X),
\tag{464.2}
\]

且

\[
 \deg_{X_i}G_{q,u}\le d:=2(h-1).
\tag{464.3}
\]

## 定理 464.1（classical sum-check 的 proof--transcript tradeoff）

取 common target-independent proof

\[
 \Pi(q)=q|_{F^m}\in F^P,
 \qquad P=|F|^m,
\tag{464.4}
\]

并用标准 \(m\)-round public-coin sum-check 验证 claim \(b=q(u)\)：第 \(j\) 轮 prover
发送一个次数至多 \(d\) 的单变量多项式 \(g_j\)，verifier 检查相邻 sum identity，
再均匀选择 \(r_j\in F\)；最终检查

\[
 g_m(r_m)=z(r_1,\ldots,r_m)W_u(r_1,\ldots,r_m),
\tag{464.5}
\]

其中 \(z\) 是 received proof word。则：

1. **完备性与近邻 soundness。** 协议 perfect-complete。对任意
   \(d_H(z,\Pi(q))\le\rho P\)、任意 \(b\ne q(u)\) 与任意 causal prover policy，
   \[
    \Pr[\operatorname{accept}]
    \le \rho+\frac{md}{|F|}
    =\rho+\frac{2m(h-1)}{|F|}.
   \tag{464.6}
   \]

2. **精确资源。** 每轮显式发送 \(d+1=2h-1\) 个 field symbols，public tape
   属于 \(F^m\)。固定 challenge tape 后，能够继续到 final query 的消息 transcript
   数恰为
   \[
    B_{\rm cont}=|F|^{md}=|F|^{2m(h-1)}.
   \tag{464.7}
   \]
   若按 bit 计价，
   \[
    r=m\log_2|F|,
    \qquad
    t=m(2h-1)\log_2|F|.
   \tag{464.8}
   \]
   单次执行只查询一个 proof symbol，但跨越所有 policies 与 public tapes 的 reachable
   proof-address support 恰为
   \[
    L=F^m,
    \qquad |L|=P.
   \tag{464.9}
   \]

3. **near-linear proof 与 polylog transcript 不可兼得。** 固定
   \(\beta<1\)。假设 wrong-claim all-policy soundness 至多 \(\beta\)，即使在
   \(z=\Pi(q)\) 上也成立，并且 \(u\notin H^m\)。则存在只依赖 \(\beta\) 的
   \(c_\beta>1\)，使
   \[
    \frac{|F|}{h}\ge c_\beta,
    \qquad
    \frac Pk=\left(\frac{|F|}{h}\right)^m\ge c_\beta^m,
    \qquad k:=h^m.
   \tag{464.10}
   \]
   因而对任意固定常数 \(C,D\)，充分大的 \(k\) 上不可能同时有
   \[
    P\le k(\log k)^C,
    \qquad
    t\le(\log k)^D.
   \tag{464.11}
   \]

### 证明

诚实 prover 发送 \(G_{q,u}\) 的逐前缀 partial sums，(464.2) 给出完备性。
对 wrong claim，第一轮消息与诚实 partial-sum polynomial 不同。只要当前 cheating
polynomial 与诚实 polynomial 不同，随机 \(r_j\) 使二者重新相等的概率至多
\(d/|F|\)；若未重新相等，下一轮 sum identity 强制差异继续存在。若所有轮都未
重新相等，则 final check 只有在 \(r\) 落入 received proof 的坏点集合时才可能通过。
union bound 给出 (464.6)。

次数至多 \(d\) 的 polynomial 有 \(d+1\) 个 coefficients。每轮继续条件是一个非零
linear sum constraint，恰留下 \(d\) 个自由 field symbols，故 (464.7) 成立。
final address 只由 \(r\in F^m\) 决定；每个 \(r\) 都可由某个满足逐轮 linear
constraint 的 policy 到达，所以 support 恰为 (464.9)。

最后证明必要的 scale separation。若 \(d\ge |F|-1\)，取任意 \(a\in H\)，令
\(\delta_a^F\) 为 \(F\) 上在 \(a\) 取 \(1\)、其余点取 \(0\) 的 Lagrange polynomial；
其次数为 \(|F|-1\le d\)。把诚实第一轮 polynomial 改为

\[
 g_1^\star+c\delta_a^F,
\tag{464.12}
\]

可匹配任意错误的初始 sum。若 \(r_1\ne a\)，prover 从第二轮起切回诚实 policy，
故 wrong claim 的接受率至少 \(1-1/|F|\)。于是 all-policy soundness \(\le\beta\)
迫使以下二者之一成立：

\[
 |F|\le(1-\beta)^{-1}
 \quad\text{或}\quad
 |F|\ge d+2=2h.
\tag{464.13}
\]

又因 \(H\subsetneq F\)，第一种情形中的 \(h\) 有只依赖 \(\beta\) 的常数上界，且
\(|F|/h\ge1+1/h\)。故两种情形统一给出某个 \(c_\beta>1\) 的 (464.10)。

若 \(P/k\le(\log k)^C\)，则 \(c_\beta^m\le(\log k)^C\)，所以
\(m=O_{\beta,C}(\log\log k)\)。由 \(h=k^{1/m}\)，此时

\[
 h=\exp\!\left(\Omega_{\beta,C}
       \left(\frac{\log k}{\log\log k}\right)\right),
\]

而 \(t\ge2h-1\) 超过任意 \((\log k)^D\)。反之，若 \(t\le(\log k)^D\)，则
\(h\le(\log k)^D\)，从而 \(m=\Omega(\log k/\log\log k)\)，并有

\[
 \frac Pk\ge
 \exp\!\left(\Omega_\beta
       \left(\frac{\log k}{\log\log k}\right)\right)
 \gg(\log k)^C.
\]

这证明 (464.11)。证毕。

## Harsha 参数推论

取 published Harsha 尺度

\[
 m=\left\lceil\frac{\log N}{\log\log N}\right\rceil,
 \qquad h^m=N,
 \qquad |F|=\Theta((mh)^3).
\tag{464.14}
\]

则 classical Lagrange sum-check 具有

\[
 P=|F|^m=N^{6+o(1)},
 \qquad
 r=(6+o(1))\log_2N,
 \qquad
 t=(12+o(1))(\log_2N)^2,
\tag{464.15}
\]

并且

\[
 \Pr[\operatorname{accept\ wrong}]
 \le \rho+O((mh)^{-2}).
\tag{464.16}
\]

所以 online verifier 与 visible transcript 都处于 address-scale polynomial，但
common proof、all-policy support 与 causal-policy table 仍处于 \(N^{6+o(1)}\)
object scale。该协议不能产生 C459 所排除的 small generic-\(q\) evaluator。

## Grid-only 与 C449 边界

若 common proof 只包含 \(q|_{H^m}\)，则 final random opening \(q(r)\) 不存在；当
\(r\in(F\setminus H)^m\) 时，C458 强制 exact black-box opening 读取全部 \(k=h^m\)
个 grid symbols。若改为让 received grid word自己定义 interpolation，则对任意
\(a\in H^m\) 与 generic \(u\)，单点扰动

\[
 z=\pi+\delta e_a
\]

会把 target value 改变 \(\delta L_a(u)\ne0\)，诚实执行相对于 \(z\) 的 sum-check
因而 perfect-accept 一个相对于原 \(\Pi(q)\) 的 wrong claim。没有 distance-binding
的 raw grid 不能满足 C448/C449 的 near-proof target-relative soundness。

full-LDE 协议的 transcript 有限，故形式上进入 C449；代入
\(B_{\rm cont}\) 的一般 locality 上界非常宽松。对这一具体协议，reachable-address
compiler 可尖化为直接读取同一个 \(F^m\) support，即 locality 至多 \(1+P\)。这个
bound 仍是整张 proof，不能把 per-run one opening 误写成 decoder locality \(1\)。

## 证据边界

* 定理只关闭显式 coefficient/evaluation 形式的 classical sum-check 与自然
  target-independent full LDE；它不是任意 IOP 或 polynomial commitment 的下界。
* 若 round polynomial 由新的 query-succinct information-theoretic commitment 打开，
  必须重新证明其 physical proof length、target independence、near-word binding 与
  all-policy soundness；不能把 cryptographic commitment 当作免费 common proof。
* 计算 soundness 上界时使用独立均匀 field challenges。计算挑战、computational
  soundness、target-dependent proof spaces 或 selected-policy-only 量词属于不同模型。
* 本定理是对一个具体 non-product source-exit 的有范围路线关闭，不证明 \(P\ne NP\)。

## 来源

* [C458 / note 458](458-grid-to-generic-exact-query-lower-bound-2026-08-19.md)。
* [C449 / note 449](449-finite-state-global-relation-normal-form-2026-08-19.md)。
* [C450 / note 450](450-scale-complete-rw-closure-normal-form-2026-08-19.md)。
* Classical sum-check protocol and tensor Lagrange interpolation.
