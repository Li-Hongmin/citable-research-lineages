> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW coding layer versus address-scale Closure (2026-08-19)

## 本轮改变的判断

Cohen--Yankovitz 与 Kumar--Mon 说明：近线性、常数率、正半径的 RLCC/RLDC coding
layer 确实可以做到 polylogarithmic locality；但 locality 只描述 decoder 读取
codeword 的次数，不描述同一个 fixed codeword 的 address-scale value evaluator。
本 note 把这个缺口写成一个与具体 code construction 无关的组合定理。

对 RW 的 published hard output，若一个 codeword/共同 proof 的地址 evaluator 已经是
\(\operatorname{poly}(\log N)\)，它会直接与 C455 forcing 矛盾；若把整个 codeword
作为 hardwired advice 或未计价 ROM，则支付的是 codeword/object scale，而不是
Gate III 所需的 address scale。因而 coding layer 本身不能完成 RW Closure；剩余正攻
必须提供新的 non-product/global relation，或证明一个真正的 codeword-address
compression theorem。

## 设置

令 \(B\in\{0,1\}^{N}\)，\(m=\lceil\log_2(N+1)\rceil\)，并把 \(B\) 视为其
truth table；\(\operatorname{CC}(B)\) 是计算地址到 \(B[j]\) 的最小 fan-in-two
Boolean circuit size。令

\[
  C:\{0,1\}^{K}\longrightarrow \Gamma^{P}
\]

是一个 injective code，\(h\in\{0,1\}^{K}\) 是固定 message，\(z=C(h)\) 是固定
physical codeword。设 \(\iota:[N]\to[K]\) 是 output-coordinate map，满足

\[
  h_{\iota(j)}=B[j]\qquad(j\in[N]).
  \tag{474.1}
\]

设 \(\mathsf{Dec}\) 是一个 clean-codeword decoder。它可以 adaptive，最多查询
\(q\) 个 \(z\) 的 symbols；在某个固定的 clean random tape \(\rho\) 上，

\[
  \mathsf{Dec}^{z}_{\rho}(\iota(j))=h_{\iota(j)}
  \qquad(j\in[N]).
  \tag{474.2}
\]

这一定义覆盖 finite-randomness perfect-complete RLDC/RLCC：若 clean completeness 为 1，
则可固定一个正概率的 clean tape。连续 randomness 不被静默纳入本定理。令
\(g_{\rm dec}\) 计入 decoder control、query-address arithmetic、target map、
output bookkeeping，以及固定 tape \(\rho\) 的描述和被读取的 tape bits 的电路大小；令

\[
  E_z:\{0,1\}^{\lceil\log_2(P+1)\rceil}\to\Gamma
  \tag{474.3}
\]

是同一个 fixed codeword 的 single-valued address evaluator，电路大小为 \(s_z\)。
\(E_z\) 的描述、非一致 advice 与 alphabet encoding 均计入 \(s_z\)；不允许另附
一个未计价的 \(P\)-symbol ROM。

## 定理 474.1（coding-layer/address-scale Closure dichotomy）

在 (474.1)--(474.3) 下，

\[
  \operatorname{CC}(B)
  \le
  O\!\left(
    g_{\rm dec}
    +q\,s_z
    +q(\lceil\log_2(P+1)\rceil+\lceil\log_2|\Gamma|\rceil)
    +\log(N+2)
  \right).
  \tag{474.4}
\]

因此，在 C455 的 published RW hard lengths 上，若 \(B=B_n\)、

\[
  \operatorname{CC}(B_n)\ge c\,\frac{N_n}{\log N_n},
  \tag{474.5}
\]

则

\[
  q_ns_{z,n}+g_{{\rm dec},n}
  +q_n\bigl(\log(P_n+2)+\log|\Gamma_n|\bigr)
  =\Omega\!\left(\frac{N_n}{\log N_n}\right).
  \tag{474.6}
\]

特别地，如果

\[
  q_n,g_{{\rm dec},n},\log P_n,\log|\Gamma_n|
  =\operatorname{polylog}N_n,
  \tag{474.7}
\]

则

\[
  s_{z,n}=\Omega\!\left(\frac{N_n}{\operatorname{polylog}N_n}\right).
  \tag{474.8}
\]

也就是说，任何对同一 codeword 的 \(\operatorname{poly}(\log N)\)-size address
evaluator 都被 forcing 排除。

### 证明

给定 output address \(j\)，先用 \(\iota\) 和 decoder control 生成目标坐标及第一个
query address。将 decoder 的每一次 proof read 替换为一次 \(E_z\) 调用；后续 query
address 由此前得到的真实 symbols 和同一 clean tape 决定。按 query step 归纳，模拟
transcript 与真实执行完全相同，因此最后输出 \(h_{\iota(j)}=B[j]\)。每次调用
\(E_z\) 的电路成本为 \(s_z\)，其地址和 alphabet bookkeeping 成本为
\(O(\log(P+2)+\log|\Gamma|)\)，总共至多 \(q\) 次；加上 decoder control 即得
(474.4)。代入 (474.5) 并移项得到 (474.6)--(474.8)。证毕。

## 推论 474.2（近线性 RLCC 不自动提供 RW Closure）

Cohen--Yankovitz 的 ECCC TR23-110 Theorem 1.1 给出显式 binary linear RLCC（因而
RLDC），其 locality 为 \(q=(\log P)^{2+o(1)}\)，并具有常数 rate 与正半径；
Kumar--Mon 的 STOC 2024 版本 Corollary 4.1 给出 \(O(\log^{69}P)\) 的同类基线。
将任一这类 decoder 黑箱接到 C455 的 \(B_n\) 时，(474.8) 仍要求 fixed codeword
\(z_n=C_n(h_n)\) 的 evaluator 支付 \(N_n/\operatorname{polylog}N_n\) 级复杂度。

因此以下三种情形严格分开：

1. **address-scale codeword evaluator**：由 (474.8) 在 C455 长度上不可能；
2. **hardwired codeword / charged ROM**：至少按 \(P_n\) symbols 计价，若
   \(P_n\) 与 history/message 同尺度，则仍是 object-scale，不是 Gate III；
3. **未计价 global oracle 或新的 joint relation**：前者已经离开 Boolean
   \(P/\mathrm{poly}\) evaluator 模型，后者才是尚未被 (474.4) 覆盖的真正正向目标。

这里没有把 RLCC 的存在性结果误写成 RW/JK 的 same-proof history attachment；
RLCC 的 locality 是 decoder 读取次数，而不是 proof-symbol 的可计算地址生成器。

## 与 C473 的关系

C473 关闭了 C183 中显式 \(R=\lceil T/M\rceil\) 个 output-code copies 的
honest-path support 逃逸。定理 474.1 更一般：即使去掉这些 copies，只保留一个
whole-history codeword，只要 Closure 仍通过一个可计价的 codeword-address evaluator
调用 clean decoder，就已经落入 (474.4)。所以“把 copies 合并成一个 RLCC”并不会
自动解决 address scale；它只把问题从 support payment 改写为 codeword-address
compression。

## 证据边界

* C455 是 published RW Theorem 4.3/4.5 在 infinitely-often lengths 上的 forcing
  下界；本 note 只在同一 \(B_n\) 与同一长度集上使用它。
* (474.4) 是一个 clean-codeword black-box composition theorem，不是对所有
  dPCP/RLDC 的长度下界，也不是无条件 \(P\ne NP\) 证明。
* 若 decoder 依赖未计价的 full codeword table、continuous global state 或新的
  joint relation，必须显式承认已经改变了 Closure 模型；本 note 不把这些模型
  静默归入 \(P/\mathrm{poly}\)。
* 对外部文献的参数核验记录在 ResearchLibrary 的
  n-np-acrr-paper-program-2026/literature-matrix.csv；精确来源为
  [Cohen--Yankovitz, ECCC TR23-110](https://eccc.weizmann.ac.il/report/2023/110/)
  与 [Kumar--Mon, arXiv:2306.17035](https://arxiv.org/abs/2306.17035)。

## 来源

* [C455 published RW forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
* [C473 honest-path support forcing](473-rw-honest-path-support-and-exposed-history-pcpp-gate-2026-08-19.md)。
* [Cohen--Yankovitz, ECCC TR23-110](https://eccc.weizmann.ac.il/report/2023/110/)。
* [Kumar--Mon, arXiv:2306.17035](https://arxiv.org/abs/2306.17035)。
