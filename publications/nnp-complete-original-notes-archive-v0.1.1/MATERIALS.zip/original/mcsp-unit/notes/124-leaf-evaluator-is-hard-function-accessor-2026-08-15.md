> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Leaf evaluator 本身就是 history 输出函数的访问器（2026-08-15）

## 命题

考虑 Ren--Williams Theorem 3.5 的固定机器 \(M\)。对每个输入
\(x\in\{0,1\}^{n}\)，令 \(\Pi_x\) 是其 canonical PCP history，长度为
\(P(n)\)。按固定地址把 \(\Pi_x\) 分成
\(L=2^h\) 个 \(2q\)-bit blocks

\[
 B_{x,v}=\Pi_x[2qv+1\ldots 2q(v+1)],
 \qquad v\in\{0,1\}^{h},
\]

允许末尾固定 zero-padding。假设输出字段在一个固定的 output-aligned block
\(v_\star\) 内：Theorem 3.5 中的

\[
 \Pi_x[r'(n)+1\ldots r'(n)+\ell(n)]=f(x)
\]

全部落在 \(B_{x,v_\star}\) 中，且 \(\ell(n)\le 2q\)。

若存在一个统一电路

\[
 \mathcal E_n(x,v)=B_{x,v}
\]

以及固定的 bit-selector（只解析 \(v_\star\) 和 block 内坐标），大小分别为
\(S_{\rm leaf}(n)\) 与 \(O(q+h+\ell)\)，则

\[
 \operatorname{CC}(f_n)
 \le S_{\rm leaf}(n)+O(q+h+\ell).
 \tag{1}
\]

若输出字段跨越 \(L_{\rm out}\) 个 blocks，而每个 block 仍由同一个
\(\mathcal E_n\) 访问，则较保守地有

\[
 \operatorname{CC}(f_n)
 \le L_{\rm out}S_{\rm leaf}(n)+\operatorname{poly}(q,h,\ell).
 \tag{2}
\]

这里的 \(\operatorname{CC}(f_n)\) 是把所有 \(\ell(n)\) 输出位作为 multi-output
电路的大小；若只取一个固定输出位，式 (1) 对该位单独成立。

## 代入 Ren--Williams 的输出参数

在 Theorem 3.5/4.1 的记号中，输出区间是
\[
 [r'(n)+1,\ r'(n)+t(n)],
 \qquad
 r'(n)=r(n)\lceil\log(t(n)+1)\rceil .
\]
因此，按 \(2q\)-bit blocks 分割时，真正与输出区间相交的 blocks 数满足
\[
 L_{\rm out}
 \le
 \left\lceil\frac{t(n)}{2q}\right\rceil+1 .
 \tag{2a}
\]
这里的 \(+1\) 只处理输出区间落在 block 边界两侧的情形；前缀长度
\(r'(n)\) 只决定这些 blocks 的地址，不增加需要读取的 block 数。于是一般情形
的式 (2) 可具体写成
\[
 \operatorname{CC}(f_n)
 \le
 \left(\left\lceil\frac{t(n)}{2q}\right\rceil+1\right)
 S_{\rm leaf}(n)
 \operatorname{poly}(q,h,t(n)).
 \tag{2b}
\]
若 \(2q\ge t(n)\)，就回到 output-aligned 的常数个 block；若 \(q\ll t(n)\)，
缩小 \(q\) 只会把硬输出分散到更多 blocks，并不会免费消除
\(S_{\rm leaf}\) 成本。

## 证明

Theorem 3.5 的 completeness 规定，\(\Pi_x\) 的 systematic 前缀包含
\(pfx_x\)，其后的 \(\ell(n)\) 个字段正是 \(f(x)\)。在 output-aligned 情形，
先把 \(v=v_\star\) hardwire 到 \(\mathcal E_n\)，再把该 \(2q\)-bit 输出的
\(\ell(n)\) 个指定坐标接到输出，即得到计算 \(f_n(x)\) 的电路。解析固定地址、
截取坐标和末尾 padding 只需 \(O(q+h+\ell)\) 大小。跨多个 blocks 时分别调用
\(\mathcal E_n\)，并用固定 selector 拼接，得到式 (2)。证毕。

## 对 history-indexed closure decoder 的含义

note 123 的正向模板若要求

\[
 |G_{n,q}|\le S_{\rm leaf}(n)+O(q\operatorname{polylog}q)
\]

并且 \(S_{\rm leaf}(n)=n^{O(1)}\)，由 note 123 的
\(|G_{n,q}|\ge S_{\rm leaf}(n)-O(q)\) 再结合式 (1)，在
output-aligned 情形同时推出

\[
 |G_{n,q}|\ge \operatorname{CC}(f_n)-O(q\operatorname{polylog}q).
 \tag{3}
\]

因此，当所选 \(f_n\) 已有 superpolynomial circuit lower bound 时，任何共同
leaf evaluator 以及由它直接实现的 decoder 都必须是 superpolynomial。这个结论
不是新的 \(P\ne NP\) 证明；它准确说明正向模板真正需要攻克的对象是

\[
 \boxed{\text{在不显式计算 }f_n\text{ 的前提下，利用 range/JK 结构取得 easy branch。}}
 \tag{4}
\]

若只要求任意 \(x,v\) 的 evaluator、而不要求 output-aligned block，式 (2) 仍给出
同一障碍；若 \(L_{\rm out}\) 不是常数，还必须把其规模纳入参数，不能把一次
leaf evaluation 误写成整个 history 的 multi-output evaluation。

## 与文献参数的边界

Ren--Williams Theorem 3.5 只保证每个 \(\Pi_x\) 存在并可由

\[
 \mathrm{TIME}[\operatorname{poly}(t(n))]^{NP}
\]

机器生成，且 PCP verifier 使用 \(O(\log t(n))\) randomness 和
\(\operatorname{polylog}(t(n))\) queries；它没有给出从 \(x,v\) 到完整 \(2q\)-bit
block 的 \(n^{O(1)}\)-size common evaluator。Theorem 4.1 的
\(\operatorname{Reconf}(x,i)\) 是 q-scale 的 smart-\(\mathrm{prMA}\) reconstruction，
不能直接替代式 (1) 所需的 P-uniform \(n\)-scale evaluator。

来源：Ren--Williams, *Range Avoidance and Circuit Lower Bounds*, Theorem 3.5
与 Theorem 4.1，官方报告：
<https://eccc.weizmann.ac.il/report/2026/118/revision/1/download>。

本文只给出一个必要条件与参数澄清，不声称已经证明 \(P\ne NP\)。
