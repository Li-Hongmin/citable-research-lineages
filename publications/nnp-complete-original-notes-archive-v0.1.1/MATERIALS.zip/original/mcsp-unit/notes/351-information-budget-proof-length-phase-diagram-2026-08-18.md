> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Information-budget / proof-length phase diagram for common coordinate robustness

## Contribution

Note 350 gives an exact lower bound on the policy mutual information in terms of
the largest fiber VC dimension allowed by the proof length. The present note
records the inverse form under supportwise perfect completeness: a policy information budget \(I(M;S)\le\gamma K\)
forces a polynomially superlinear proof length, with the exponent inherited from
the nonadaptive RLDC lower bound. Thus the result is a continuous phase diagram,
not only a near-linear contradiction.

## Theorem (nonadaptive phase diagram)

Fix \(0<\rho<1\), a finite proof alphabet \(\Sigma\) of size \(A\ge2\), a gap
\(\Delta>0\), and a common proof map

\[
  \Pi:\{0,1\}^{K}\longrightarrow\Sigma^{P}.
\]

Assume the supportwise target-relative robustness hypotheses of note 350 with
supportwise perfect completeness \(\alpha=1\), and use the inline compiler.  After
constant-gap amplification let \(Q\) be the fixed inline query count
and \(\sigma_0>0\) the relaxed-success parameter. Let \(M\) be uniform and let
\(S\) be the selected-policy vector, allowing randomized selection only when
every policy in the conditional support satisfies the same robustness bounds.

For \(0\le\gamma<1\), let \(\vartheta_\gamma\in(0,1/2]\) be defined by

\[
  h_2(\vartheta_\gamma)=1-\gamma,
\tag{351.1}
\]

where \(h_2\) is binary entropy. If

\[
  I(M;S)\le\gamma K,
\tag{351.2}
\]

then, for every fixed \(\varepsilon\in(0,\vartheta_\gamma)\) and all sufficiently
large \(K\) for which the GGS radius condition holds,

\[
 \widehat A:=A+2,\qquad d:=\left\lfloor(\vartheta_\gamma-\varepsilon)K\right\rfloor,
 \qquad
 P\ge
 \left(
 \frac{\sigma_0^2d}
 {38Q^4\log_2^2(\widehat A)\log_2^2(d+2)}
 \right)^{1+1/\lceil Q/\sigma_0\rceil}-d.
\tag{351.3}
\]

Consequently, with

\[
  \theta_Q:=1+1/\lceil Q/\sigma_0\rceil>1,
\tag{351.4}
\]

there is a constant \(c_{\gamma,A,Q,\sigma_0}>0\) such that

\[
  P\ge c_{\gamma,A,Q,\sigma_0}
       \frac{K^{\theta_Q}}{(\log(K+2))^{2\theta_Q}}
\tag{351.5}
\]

for all sufficiently large \(K\). In particular, any fixed positive fraction of
unpaid target information forces a genuinely superlinear proof exponent.

## Proof

The information budget gives

\[
  H(M\mid S)=K-I(M;S)\ge(1-\gamma)K.
\tag{351.6}
\]

Hence some conditional fiber \(F_s=\{m:\Pr[M=m\mid S=s]>0\}\) has
\(H(M\mid S=s)\ge(1-\gamma)K\), and therefore

\[
  |F_s|\ge2^{(1-\gamma)K}.
\tag{351.7}
\]

Let \(d_s=\operatorname{VCdim}(F_s)\). Sauer--Shelah and the standard binomial
entropy estimate give, for every fixed \(\varepsilon>0\),

\[
  d_s\ge(\vartheta_\gamma-\varepsilon)K
\tag{351.8}
\]

for all sufficiently large \(K\): otherwise
\(\log_2|F_s|\le K h_2(\vartheta_\gamma-\varepsilon)+O(\log K)\),
which is strictly below \((1-\gamma)K\).

Choose a shattered coordinate set of size
\(d=\lfloor(\vartheta_\gamma-\varepsilon)K\rfloor\). The inline RLDC construction in
note 350 has length \(d+P\), alphabet \(\widehat A\), and perfect completeness. Its
proof image is injective and has relative distance greater than \(\rho\), so Theorem 1
of Goldberg--Gur--Saraogi gives \(d+P\) at least the right-hand side of (351.3),
which is exactly (351.3). Replacing \(d\) by a constant fraction of
\((\vartheta_\gamma-\varepsilon)K\) and absorbing the subtracted \(d\) yields (351.5).
\(\square\)

## Adaptive consequence

If the selected branches are adaptive and the variable-query transfer of note 255
is used, the same fiber has \(d=\Omega_\gamma(K)\). Therefore, on any sequence
\(P\le K(\log K)^c\), the derived DGL inequality forces

\[
  Q_K^3=\Omega_{\rho,\Delta,c,\gamma}(\log K),
  \qquad
  r_K\log(r_K+2)=\Omega_{\rho,\Delta,c,\gamma}((\log K)^{1/3}),
\tag{351.9}
\]

provided the transfer window \(Q_K^3=o(\log P)\) is the branch under test. This
is the information-budget version of the adaptive locality barrier; it is derived
from the parameter-tracked DGL argument, not attributed to DGL as a stated
growing-query theorem.

## Boundary and interpretation

* The theorem assumes supportwise perfect completeness in addition to a common proof/address space and supportwise,
  target-relative wrong-claim soundness. Ordinary average or list soundness does
  not supply the common fiber needed for the RLDC reduction.
* The finite alphabet and fixed \(Q,\rho,\Delta\) assumptions are explicit. If the
  alphabet or locality grows, the GGS constants and exponent must be recomputed.
* Equation (351.3) is a necessary condition, not an achievability statement. It
  does not by itself produce \(P\ne NP\), nor does it assert that the RW canonical
  history satisfies the supportwise interface.

## Sources

* [Quantitative proof--policy information tradeoff](350-quantitative-proof-policy-information-tradeoff-2026-08-18.md).
* [Variable-query relaxed-DGL theorem](255-variable-query-relaxed-dgl-theorem-2026-08-17.md).
* [Goldberg--Gur--Saraogi, Theorem 1](https://eccc.weizmann.ac.il/report/2025/192/download).
