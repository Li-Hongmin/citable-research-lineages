> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 代数 leaf coverage 不自动给出 JK tree closure（2026-08-15）

## 容量引理

设 \(G_q:\{0,1\}^{q}\to\{0,1\}^{2q}\)，并有一族 leaf blocks
\[
\{B_\sigma:\sigma\in\Sigma\}\subseteq\operatorname{Range}(G_q).
\]
假设每个 leaf occurrence 的 canonical preimage 至少携带
\(s_{\rm line}\) bits 的独立 line-polynomial information，并且存在
\(R\) 个 occurrence 的系数可以独立选择；于是这 \(R\) 个 blocks 的 ordered
preimage tuples 至少有
\[
2^{R s_{\rm line}}
\]
种不同值。若 JK 的某一 parent level 要求所有这些 tuples 的串接仍落在
\(\operatorname{Range}(G_q)\)，则必须有
\[
R\,s_{\rm line}\le q.
\tag{1}
\]
否则 parent range 至多 \(2^q\) 个字符串，不能承载全部不同的
\(R\)-tuple concatenations。

证明只是 injectivity：两个不同的 ordered tuples 不可能产生同一个
\(Rq\)-bit concatenation；而 parent seed 只有 q bits。证毕。

## 对半率 algebraic leaves 的解释

半率 FFT decoder（note 127）只说明每个 line block 的**单独** evaluation
vector 可以由 \(s_{\rm line}\) bits 的系数描述产生，且输出为 \(2q\) bits。
若父节点把 \(R\) 个相邻 line blocks 的 canonical coefficient seeds 直接串接，
则式 (1) 给出可保持这种表示的最大范围：
\[
R\le q/s_{\rm line}.
\tag{2}
\]
当 JK tree 深度继续增加、\(R=2^j\) 超过该范围时，必须出现至少一种新的
全局压缩：

1. 不同 line restrictions 之间有可证明的共享参数；
2. parent seed 改用一个能随机访问整个子树的 global polynomial/circuit label；
3. 或只要求实际 history 的一个受限 tuple 集合，而不是所有独立系数选择。

半率 leaf evaluator 本身不提供上述任一项。

## 与 Harsha/Ren--Williams PCP 的关系

Harsha 的完整性构造确实可把 \(\widetilde A\)、变换后的 \(P\) 以及
ZERO-ON-SUBCUBE 的 \(P_i,Q_i\) 选为低度多项式表；因此 line-restricted leaf
blocks 可以进入 note 127 的 range。可是不同平行 lines 的 restriction
coefficients 一般不是由一个 q-bit local label 独立恢复的。若要令 JK 在
\(\log(T/q)\) 层都保持 range，必须证明一个 whole-tree labeler：
\[
A_j(\text{history index},\text{block address},\ell)
\]
能在 \(n^{O(1)}\) 或 \(q\operatorname{polylog}q\) 规模下共同访问所有
parent labels。这个条件正是 note 123 的 tree-compatible normalization，
并非 additive FFT 自动给出的结论。

更具体地，若 line coefficients 在 \(R\le D_{\perp}+1\) 条平行线上的自由度
确实独立（\(D_{\perp}\) 是横向多项式次数），则至少在
\(2^j s_{\rm line}>q\) 的层级之后，任意“逐 line coefficient 串接”的
closure 必然失败。若实际 PCP 的横向系数有更强相关性，必须把这种相关性
写成并验证一个新的 parent-label 构造，不能由低度性本身推出。

## 结论

\[
\boxed{
\text{半率代数 decoder 解决 leaf-level batch evaluation；}
\quad
\text{JK tree 仍需要独立的 whole-tree compression。}
}
\]

因此 note 127 是真实的 special-purpose 正向 primitive，但尚不足以断言
\(\operatorname{Solve}_f\) 的 failure branch 或 \(P\ne NP\)。相关低度 PCP
构造见 Harsha thesis 的 ZERO-ON-SUBCUBE 与 CIRCUIT-SAT 章节：
[official thesis PDF](https:/[unbundled local reference].ttic.edu/~prahladh/papers/thesis/phdthesis.pdf)；
Ren--Williams 的 smart-Reconf 接口见
[official report](https://eccc.weizmann.ac.uk/report/2026/118/revision/1/download)。
