> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 同时坐标鲁棒 dPCP：ACRR 与 RLDC/分布式 soundness 的主定理纲领（2026-08-16）

## 结论地位

这是新的主攻纲领，不是已证明定理。目标是得到一个能独立发表的 PCP/coding theorem、
一般性 impossibility theorem，或 Range-Avoidance/circuit consequence；不把条件性
ACRR 充分条件本身当作最终贡献。

## 1. 精确定义候选：Sim-CR-dPCP

设 `f_x ∈ {0,1}^ℓ` 是确定性 computation instance `x` 的输出词。
一个 `Sim-CR-dPCP` 候选由统一的 proof address space `Pi_x`、局部随机边分布和
查询族 `Q_{x,i,b}` 组成。要求：

1. **完备性：** 对 `b=f_x[i]`，同一个 `Pi_x` 使 `Q_{x,i,b}` 以概率 1（或固定
   完备阈值）接受；
2. **坐标级 soundness：** 对 `b ≠ f_x[i]`，任意候选全局 proof `pi` 都满足
   `Pr[Q_{x,i,b}(pi)=1] ≤ ε < 1/2`；
3. **共用对象：** 所有 `(i,b)` 使用相同地址空间与同一全局 proof，而不是分别选取
   `pi_{x,i,b}`；
4. **近线性/局部性：** proof 长度、查询数、alphabet 和 verifier 描述显式记账；
5. **统一性：** 给定 `(x,i,b)` 可在规定的地址尺度生成随机边、decoder 与约束。

这一定义严格强于普通 dPCP 的平均 list-decoding soundness。后者只保证对任意
assignment 存在一个短 list，使“满足且解码不在 list 中”的联合概率很小；它不自动给出
每个固定坐标、每个错误声明的常数拒绝率。

## 2. 正向问题：能否构造

优先尝试把近线性 dPCP/PCPP 的全局 consistency 直接强化为 Sim-CR-dPCP，要求：

- proof map 在给定 satisfying assignment 时确定且可统一生成；
- 所有坐标的 decoding distributions 作用于同一 proof；
- 错误坐标的拒绝事件不是被平均坐标稀释；
- 组合过程保留固定 address space 和同一 strategy；
- 代价不超过近线性 proof 与常数查询，或明确给出最优 tradeoff。

不能把 note 169 的“复制某坐标”当作 amplification：存在所有副本一致取错的 assignment
时，新错误质量至少为 `R/(n+R-1)`，这只产生 reweighting，不产生语义鲁棒性。

## 3. 反向问题：是否隐含 RLDC/LDC 下界

需要先给出一个正式的 reduction interface：

\[
  (\Pi_x,\ Q_{x,i,b},\ \text{corruption model})
  \longmapsto
  (\mathcal C,\ \mathsf{Dec},\ \delta,\ \text{length}).
\]

只有当 proof symbols 能作为编码词、候选 proof 的局部修改能转化为 codeword
corruption、且 decoder 的 `⊥` 语义与坐标 soundness 对齐时，才能声称推出 RLDC；
否则只是类比。目标是寻找一条参数上足够强的蕴含，使同时坐标鲁棒的近线性 proof 与已知
3-query LDC 长度下界发生冲突，或反过来解释为何 RLDC 的 relaxed rejection 正是 ACRR
不可避免的缺口。

## 4. 分布式 soundness 路线

distributional soundness 的价值在于组合多次 verifier 时保持对全局对象的分布式一致性；
它比平均 list 约束更接近 ACRR 的“同一 word”要求。但必须证明它还控制指定坐标和错误
声明，不能只控制随机坐标或一个短 list。最小可证伪问题是：

> 是否存在一个具有近线性长度、常数查询和固定坐标 soundness 的 distributionally
> sound dPCP；若存在，它是否给出 Sim-CR-dPCP，若不存在，能否从定义构造一般下界？

## 5. 参数与证据边界

Ren--Williams 报告的公开摘要确认其结果是 `E^{prMA}/_1` 的近最大
`2^n/n` 电路下界，并以 Range Avoidance、PCP 和带 witness-length/round 记账的
`P^NP` 分析为核心；这支持本项目的背景动机，但不提供 Sim-CR-dPCP。

Gur--Minzer--Weissenberg--Zheng 的 Theorem 1.6 给出 size
`N log^C N` 的 2-query dPCP 与 list soundness；Theorem 1.7 给出 3-query PCPP；
Theorem 1.9 给出长度至多 `k^2 log^C k` 的 3-query RLDC，而 Theorem 1.10 给出同
参数 3-query LDC 的 `~Ω(k^3)` 下界。它们说明 RLDC/LDC 是有力的
参数参照，但没有直接证明 Sim-CR-dPCP 的构造或不可能性。

Dinur--Harsha--Kindler 的 distributional soundness 是为多次 modular composition
控制一致性与 soundness 累积而提出；它是本路线的候选工具，不是 ACRR 的现成接口。

## 6. 晋级门槛

从本 note 开始，新增实验或引理只有在至少满足以下一项时进入主线：

- 给出 Sim-CR-dPCP 的完整构造与参数；
- 给出从 Sim-CR-dPCP 到 RLDC/LDC 或其下界的正式 reduction；
- 给出 distributional-soundness 到坐标鲁棒性的定理或一般 separation；
- 给出与 RW/JK、Range Avoidance 或电路下界的非条件性新联系。

否则只保留为内部搜索记录，不再以 note 数量或局部 decoder 改进衡量进展。

## 证据来源

- [Ren--Williams, TR26-118 revision 1](https://eccc.weizmann.ac.il/report/2026/118/)
- [Gur--Minzer--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/html/2512.12960)
- [Dinur--Harsha--Kindler, TR15-085](https://eccc.weizmann.ac.il/report/2015/085/)
