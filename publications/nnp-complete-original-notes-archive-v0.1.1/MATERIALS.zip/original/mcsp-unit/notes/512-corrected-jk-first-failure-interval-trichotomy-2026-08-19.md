> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# C416 纠正：leftmost-normalized JK 首失败与任意目标区间的有序三分（2026-08-19）

## 本轮改变的判断

C416/Proposition 1.41 的“prefix 不与首个 outsider ancestry 相交 \(\Rightarrow\)
只需一个 \(k\)-bit bottom seed”表述过强。其隐含错误是把 stage-\(i\) 失败块之前的
多个 good blocks 当成一个更低层的 good subtree；但 JK 在 stage \(i\) 发现首个
non-range block 后并没有运行 stage \(i-1\)，所以这些 blocks 的 preimages 之间
不必共同落入一个 range block。

采用 C392 的 leftmost tie-break normalization 后，正确的 source-level 结论是一个
ordered interval trichotomy：

* 目标区间在首个 outsider 的 top ancestor 左侧时，必须支付该区间所覆盖的
  stage-\(i\) good-block canonical preimages；
* 目标区间与 outsider ancestor 相交时，returned outsider 只附着这一 ancestor
  block，不能自动绑定区间外的 parent bits；
* 目标区间在右侧时，JK 返回值对该区间没有免费语义，必须支付相应 frontier/support
  或提出新的 non-half-lift global relation。

这把 C416 的正确特殊情形保留下来，同时删除一个不受原假设支持的
\(O((|G|+k)H)\) 普遍上界。
## 设置

按 Ren--Williams Theorem 3.1，把补零后的 proof \(\Pi^+\) 切成 JK stages，并在
每个 parallel stage 的所有 NO blocks 中返回最小 index。原文只规定“若某个 block
的 SAT query 回答 NO，则返回相应 block”，没有指定同一轮多个 NO blocks 的
tie-break；所有 answers 已经并行可用，所以选择最小 index 不增加轮数、witness
长度或渐近时间，并保持 Theorem 3.1 的 hard/easy 结论。

在这个 C392-normalized recursion 中，设首次返回 non-range block 的 stage 为
\(i\)，其在 \(y_i\) 中的 block index 为
\(j^\star\)，对应 outsider 为 \(y\)。令 \(A^\star\) 是该 stage-\(i\) block 在顶层
\(\Pi^+\) 中覆盖的 ancestor interval；其长度为
\(2n\,2^{k-i}\) bits（这里 \(n\) 是 JK generator 的 input width，\(k\) 是 JK
height）。固定 canonical right inverse
\[
p:\operatorname{Range}(G)\to\{0,1\}^{n},
\qquad G(p(z))=z.
\tag{512.1}
\]

对任意 contiguous target interval \(I\)，令 \(Q_i(I)\) 是所有 stage-\(i\) block
\(z_{i,j}\) whose top ancestor interval intersects \(I\) 的 index 集合。若
\(I\) 严格位于 \(A^\star\) 左侧，则 \(Q_i(I)\subseteq[j^\star-1]\)，因而每个
\(z_{i,j}\) 都在 range 中。

## 定理 512.1（corrected leftmost-normalized first-failure trichotomy）

### (L) 左侧区间：canonical-preimage support

若 \(b(I)<\min A^\star\)，则存在一个以 \(I\) 内 physical bit address 为输入的
circuit \(C_I\)，计算 \(\Pi^+[I]\)，并满足
\[
\operatorname{CC}(\Pi^+[I])
\le
O\!\left(
n\,\lvert Q_i(I)\rvert
\,+\,(k-i+1)(|G|+n)
\,+\,\log(|\Pi^+|+2)
\right).
\tag{512.2}
\]
该 circuit hardwires \(p(z_{i,j})\) for \(j\in Q_i(I)\)，先用一次 \(G\) 生成
对应的 stage-\(i\) block，再沿 \(k-i\) 个 higher stages 选择 half。

因此，C416 的低成本结论只有在 \(|Q_i(I)|=O(1)\)（例如目标完全位于一个 good
subtree）时才成立。单凭“首个 outsider 的 ancestry 不与 prefix 相交”不能推出
\(|Q_i(I)|=1\)。

### (A) 相交区间：单 block attachment

若 \(I\cap A^\star\neq\varnothing\)，则 returned outsider \(y\) 与 \(I\) 有物理
ancestor attachment：\(y\) 加已知 stage/path 可生成 \(A^\star\) 内的对应 top bits，
代价为 \(O((k-i+1)(|G|+n))\)。但这只覆盖 \(A^\star\cap I\)；若 \(I\) 延伸到
其它 ancestor intervals，仍需额外 block payload/preimage 或同一 parent 的 global
binding。故“attached”不等于 whole-parent attachment。

### (R) 右侧区间：returned outsider 不提供免费 binding

若 \(a(I)>\max A^\star\)，Theorem 3.1 的已发表语义只保证在更早的
non-range block \(y\) 返回；它没有给出 \(I\) 中 stage-\(i\) blocks 的
preimages，也没有跨 calls 的 coupling equation。一个普适但 object-aware 的
support upper bound 是
\[
\operatorname{CC}(\Pi^+[I])
\le
O\!\left(
2n\,\lvert Q_i(I)\rvert
\,+\,(k-i)(|G|+n)
\,+\,\log(|\Pi^+|+2)
\right),
\tag{512.3}
\]
由 hardwire \(I\) 所覆盖的 stage-\(i\) block payloads 并向上 half-lift 得到。
若目标区间 forcing-hard 且这个 support 仍未达到 forcing scale，则必须提供
被完整计价的 non-half-lift/global relation；returned outsider 本身不能充当其
descriptor。

## 证明

在 (L) 中，首个失败块按 stage-\(i\) 的 left-to-right order 位于所有
\(Q_i(I)\) 之后，因此这些 blocks 的 range membership 与 canonical preimages
\(p(z_{i,j})\) 已由同一次 JK 调用确定。给定 top address，可计算它所属的
stage-\(i\) ancestor block \(j\)，选择对应 \(n\)-bit seed，调用一次 \(G\) 得到
\(z_{i,j}\)，随后沿每个 higher-stage half direction 调用
\(G(\operatorname{left}_n(\cdot))\) 或
\(G(\operatorname{right}_n(\cdot))\)。每个 address 只走一条 path，得到 (512.2)。

(A) 是同一 forward half-lift identity 作用于 outsider block。它只能生成该
outsider 的 ancestor interval，不能生成不相交 intervals 的 payload，故不推出
whole-parent binding。

(R) 中直接 hardwire 每个与 \(I\) 相交的 stage-\(i\) block 的 \(2n\)-bit payload，
再沿 \(k-i\) 个 higher stages 做 half-lift，即得 (512.3)。Theorem 3.1 对首个
outsider 右侧的数据没有额外 coupling 结论，因此低于该 support 代价的统一
attachment 必须另加 global relation。证毕。

## 对 C416 与 Closure 的修正

1. C416 的“一个 bottom seed”应改成 \(n|Q_i(I)|\)-bit canonical-preimage
   support；只有单 good-subtree 情形才退化为一个 seed。
2. C488 的完整 \(n2^i\)-bit frontier bound 仍正确；(512.2) 是其 left-of-first-
   failure、区间局部版本，(512.3) 是右侧 target 的直接 support 版本。
3. C511 的 arbitrary-interval counterfactual frontier barrier 仍独立成立；它
   负责把 sparse interval-local frontier 排除为 forcing-hard target 的逃逸，
   而 C512 负责说明 normalized returned outsider 在区间顺序上的语义范围。
4. 该纠正不证明 \(P\ne NP\)。它降低了已声明的 attachment 强度，但提高了
   Closure 账本的可靠性：剩余正攻必须真正绑定多个 stage-\(i\) blocks，或提出
   新 global relation。

## 反例机制（为何 C416 原上界不成立）

取 \(i\ge3\)，令首个失败块为 \(j^\star\ge3\)。则前两个 stage-\(i\) blocks
\(z_{i,1},z_{i,2}\) 可以分别属于 \(R\)，但它们的 canonical preimages
\(p(z_{i,1})\Vert p(z_{i,2})\) 不必属于 \(R\)：JK 在 stage \(i\) 失败后不会检验
这个更低层 concatenation。于是 prefix 中相应的多个 ancestor intervals 不能由
一个 \(n\)-bit seed 统一生成；至少需要相应数量的 preimage seeds，正是
(512.2) 的 \(n|Q_i(I)|\) 项。

一个完全显式的 \(n=2\) 局部例子是
\[
G(00)=0010,\quad G(01)=0111,\quad
G(10)=1000,\quad G(11)=1101.
\]
这里 \(G\) injective，且 \(0001\notin R=\operatorname{Range}(G)\)。令
\(z_{3,1}=0010\)、\(z_{3,2}=0111\)、\(z_{3,3}=0001\)，并把 \(z_{3,3}\)
作为 stage \(3\) 的首个失败 block（后续 blocks 任取）。前两个 blocks 都通过
range test，但
\[
p(z_{3,1})\Vert p(z_{3,2})=00\Vert01=0001\notin R.
\]
因此它们不能由一个更低层 good block 的 single seed 统一 half-lift；旧 C416
的 one-seed evaluator 在这个最小局部结构上已经失效。

## 来源

* [C416](416-rw-prefix-first-failure-output-attachment-under-p-equals-np-2026-08-19.md)：
  被纠正的 prefix-first-failure 上界。
* [C392](392-normalized-jk-first-failure-signal-dichotomy-2026-08-18.md)：
  leftmost tie-break normalization 及其对 Theorem 3.1 的无损兼容性。
* [C488](488-jk-first-failure-frontier-support-bound-2026-08-19.md)：完整
  first-failure frontier support。
* [C511](511-jk-arbitrary-interval-frontier-forcing-2026-08-19.md)：任意区间的
  counterfactual frontier barrier。
* Ren--Williams TR26-118 revision 1, Theorem 3.1：stage 顺序、parallel range
  tests、某个 non-range block 的返回与 canonical preimages；原文未指定
  leftmost tie-break。
