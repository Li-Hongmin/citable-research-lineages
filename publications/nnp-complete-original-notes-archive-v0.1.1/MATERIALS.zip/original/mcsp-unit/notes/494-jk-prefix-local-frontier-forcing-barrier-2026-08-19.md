> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# JK prefix-local frontier forcing barrier（2026-08-19）

## 本轮改变的判断

C420 统计了完整 canonical JK recursion 的 failure frontier。对 published singleton，
suffix 中的大量 failure 可能遮蔽真正的 parent 前缀：完整 frontier 很大，并不说明
前缀本身不能被一个短 canonical half-lift evaluator 生成。本 note 把 terminal
decomposition 限制到目标 prefix，得到一个更强的 source-specific barrier：

* 不要求 contiguous/leftmost first-failure tie-break；
* 只计入与目标 prefix 相交的 failure nodes；
* suffix failure 不再为 parent binding 提供免费“掩护”。

因此，若 forcing-hard parent 的 canonical JK tree 在其 output prefix 内 failure
稀疏，则该 parent 仍有小电路；否则 prefix 内必须支付大量 failure payload，或
提出不能展开成 canonical half-lift 的新 global relation。

## Canonical tree and prefix-local frontier

令

\[
G:\{0,1\}^{k}\to\{0,1\}^{2k},\qquad
R=\operatorname{Range}(G),
\]

并固定 canonical selector
\[
p:R\to\{0,1\}^{k},\qquad G(p(z))=z\quad(z\in R).
\tag{494.1}
\]

这里可取 JK 的 lexicographically smallest preimage；不要求 \(G\) 单射。把补零后的
proof \(\Pi^+\) 切成 \(2^H\) 个 \(2k\)-bit leaves。对每个 node \(v\)，若两个
children 已定义且在 \(R\) 中，定义

\[
z_v:=p(z_{v0})\Vert p(z_{v1}).
\tag{494.2}
\]

若 \(z_v\in R\)，称 \(v\) good；若 \(z_v\notin R\)，称 \(v\) bad defined；若至少
一个 child 未定义，称 \(v\) undefined。令

\[
\mathcal F=\{\text{bad leaves}\}\cup\{\text{bad defined internal nodes}\}.
\tag{494.3}
\]

固定一个 proof prefix \(B=\Pi[1,b]\)。令 \(J_B\) 是所有与这段 prefix 有非空 bit
交集的 leaf indices；它是一个连续的 prefix interval。定义

\[
\mathcal F_B:=\{f\in\mathcal F:I_f\cap J_B\ne\varnothing\},
\tag{494.4}
\]

其中 \(I_f\) 是 \(f\) 覆盖的 leaf interval。注意 \(\mathcal F_B\) 不是实际 JK
执行暴露的 query 集，而是固定 canonical proof 上的数学 failure frontier 在
parent prefix 内的部分。

## 定理 494.1（prefix-local frontier barrier）

对 \(J_B\) 作如下局部 terminal decomposition：

1. 若 node \(v\) good，输出一个 good terminal；
2. 若 \(v\) 是 leaf，输出其 \(2k\)-bit payload；
3. 否则只递归 \(I_{v0}\) 或 \(I_{v1}\) 与 \(J_B\) 相交的 children。

记所得 terminals 为 \(\mathcal T_B\)。则

\[
|\mathcal T_B|
\le 1+(H+1)(|\mathcal F_B|+1).
\tag{494.5}
\]

令

\[
C_G:=|G|+k+\lceil\log_2(L+2)\rceil,
\]

其中 \(L=|\Pi^+|\)。存在一个以 prefix bit address 为输入的 Boolean circuit
\(C_B\)，计算同一个 \(B\)，并满足

\[
\operatorname{CC}(B)
\le
O\!\left(
(H C_G+\log(L+2))\,|\mathcal T_B|
\right)
\le
O\!\left(
H C_G\bigl(1+H(|\mathcal F_B|+1)\bigr)
\right).
\tag{494.6}
\]

因此，在
\(\operatorname{CC}(B)/(H C_G)\to\infty\) 的 forcing regime 中，

\[
|\mathcal F_B|
=
\Omega\!\left(
\frac{\operatorname{CC}(B)}{H^2 C_G}
\right)-O(1).
\tag{494.7}
\]

## 证明

### 1. Good subtree identity

若 \(v\) good，令 \(s_v=p(z_v)\)。由 (494.2)，
\[
\operatorname{half}_\epsilon(s_v)=p(z_{v\epsilon}),\qquad \epsilon\in\{0,1\}.
\]

结合 (494.1)，
\[
G(\operatorname{half}_\epsilon(s_v))
=G(p(z_{v\epsilon}))
=z_{v\epsilon}.
\tag{494.8}
\]

所以一个 good terminal 的 seed \(s_v\) 唯一生成其整个 descendant interval；这
正是 C493 修正后的 half-lift identity。

### 2. 局部 terminal 数量

令 \(A_B\) 是局部 decomposition 中被展开的非-good nodes。对任意
\(v\in A_B\)：

* 若 \(v\) 是 bad defined node，\(v\in\mathcal F_B\)；
* 若 \(v\) undefined，沿其 descendants 选择一个 failure \(f\in\mathcal F\)。
  若 \(I_f\cap J_B\ne\varnothing\)，把 \(v\) 记到 \(f\) 上。一个固定 \(f\) 至多
  有 \(H+1\) 个 ancestor；
* 若所选 failure 都不与 \(J_B\) 相交，则 \(I_v\) 必须跨过 \(J_B\) 的唯一边界。
  对 prefix interval，每个 depth 至多有一个这样的 boundary node，共至多 \(H+1\)
  个。

故
\[
|A_B|\le(H+1)|\mathcal F_B|+(H+1).
\tag{494.9}
\]

局部展开树的每个内部节点至多有两个 children，因此 leaves 数至多为
\(|A_B|+1\)，得到 (494.5)。

### 3. Circuit evaluator

对每个 good terminal，hardwire 其 \(k\)-bit seed \(s_v\)，先计算
\(z_v=G(s_v)\)，再依据输入地址在 descendant interval 中的相对 path，至多做
\(H\) 次
\[
L_0(z)=G(\operatorname{left}_k z),\qquad
L_1(z)=G(\operatorname{right}_k z).
\]

对 bad-leaf terminal，直接 hardwire 其 \(2k\)-bit payload。terminal intervals 按
地址排序；比较器、边界判断和 mux 的成本由 \(O(\log(L+2))\) 吸收。将所有
terminals 并联，便得到 prefix \(B\) 的 address circuit，成本为 (494.6) 的第一项。
代入 (494.5) 即得第二项与 (494.7)。证毕。

## 对 RW/JK Closure 的直接含义

1. **移除 leftmost 假设。** C416 的“首个 outsider 位于 parent 之后”需要
   contiguous leftmost tie-break；C494 不需要任何实际 first-failure 选择规则。
2. **suffix failure 不再有帮助。** C420 的完整 \(|\mathcal F|\) 可被 suffix
   failure 主导；C494 迫使真正与 \(B\) 相交的 \(\mathcal F_B\) 也达到 forcing
   scale，除非使用新的 non-half-lift relation。
3. **published singleton 参数。** 在 \(P=NP\) deterministic recompilation、
   source-compatible binary serialization 下，若 \(B_i\) 是 proof 的 output prefix，
   \(H_i=O(\log n_i)\)、\(|G_{k_i}|\le k_i^4\)，则
\[
|\mathcal F_{B_i}|
=
\Omega\!\left(
\frac{\operatorname{CC}(B_i)}
{(k_i^4+k_i+\log(n_i+2))\log^3(n_i+2)}
\right)-O(1).
\tag{494.10}
\]

因此一个只在 suffix 暴露 outsider、而 parent prefix 内保持 canonical range
closure 的方案不能绕过 forcing；它要么支付 prefix-local frontier，要么明确证明
跨 frontier 的新 global coupling。
4. **量词边界。** \(\mathcal F_B\) 是固定 proof 的反事实数学对象，不等于实际
   JK query 数。C494 不证明 \(P\ne NP\)，也不声称 ordinary JK 已给出
   same-proof whole-parent attachment。

## 证据边界

* 依赖 C493 的 canonical right inverse \(G\circ p=\mathrm{id}_R\)，不依赖 \(G\)
  injective。
* prefix-local decomposition 只使用 fixed proof 上的 terminal seeds/payloads；
  若 proposed closure 把这些常数藏进未计价 selector/ROM，仍属于 descriptor/model
  exit。
* 该定理排除的是 canonical half-lift 在 parent prefix 内的稀疏-frontier 逃逸；
  一个被完整计价、不能展开成 (494.8) 的 non-half-lift global relation 仍然开放。

## 来源

* [C493](493-jk-frontier-canonical-selector-correction-2026-08-19.md)：非单射
  canonical right inverse 与 good-subtree identity。
* [C420](420-rw-full-jk-frontier-parent-binding-2026-08-19.md)：完整 frontier
  terminal decomposition 与 circuit cost。
* [C416](416-rw-prefix-first-failure-output-attachment-under-p-equals-np-2026-08-19.md)：
  leftmost tie-break 版本的 prefix attachment。
* Ren--Williams TR26-118 revision 1, Theorems 3.1, 3.5, 4.1：JK recursion、
  canonical preimage selection 与 RW output-prefix source.
