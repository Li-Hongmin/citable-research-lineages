> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 稀疏真值表的 Shannon 边界校正（2026-08-15）

## 结论

必须区分：

- \(m\)：布尔函数的**输入变量数**；
- \(N=2^m\)：真值表长度；
- \(p\)：真值表中取值为 \(1\) 的行数。

下载报告中把这三个尺度混在一起，并给出一个没有自足证明的全参数
\(\Theta\)-公式；该公式不晋级。本轮能直接核验的严格事实是：

\[
2\le p\le \log_2 m-c\log_2\log_2 m
\quad\Longrightarrow\quad
\max_{f:\,|f^{-1}(1)|=p} \operatorname{CC}(f)
=(2+o(1))m
\tag{1}
\]

在 Red'kin 所用的有限完备二输入基中成立。把该基的每个 gate 用固定的
\(\{\land,\lor,\neg\}\) 或其他固定完备 fan-in-two 基模拟，只改变常数因子，故仍有
\(\Theta(m)\) 的结论。

因此，极稀疏 truth table 不是高复杂度 witness：即使选择最坏的 \(p\)-稀疏函数，在
\(p\le \log m-O(\log\log m)\) 的区间，其电路复杂度也只有线性于 \(m\)，而不是线性于
\(N=2^m\)。

## 文献事实与参数翻译

Red'kin 的 \(F_{m,p}\) 是所有恰在 \(p\) 个 \(m\)-bit 输入上取 \(1\) 的函数。其
Theorem 2 在

\[
2\le p\le \log m-c\log\log m
\]

时给出 Shannon function

\[
L(F_{m,p})\sim 2m
\]

（论文使用的 \(B_0\) 基包含几乎所有二输入非线性函数；Theorem 4 对一个不冗余的
完备基 \(B_5\) 给出相同渐近量）。原始记录与全文见
[Red'kin, *Asymptotics for the Complexity of Boolean Functions with Small Number of Ones*](https://www.mathnet.ru/eng/mzm12691)。

这里的 \(2m\) 不是 \(2^m\)：\(m\) 是输入宽度。翻译到真值表长度 \(N=2^m\) 后，
(1) 仍然只是 \(2\log_2 N+o(\log N)\) 门。

## 可独立核验的计数下界（不冒充全参数上界）

令

\[
K(m,p):=p\bigl(m-\log_2 p\bigr),
\qquad 1\le p\le 2^{m-1}.
\]

因为

\[
\log_2\binom{2^m}{p}
=\Theta\!\bigl(K(m,p)\bigr)
\]

（在 \(p\le 2^{m-1}\) 的适当端点范围内），而大小至多 \(S\) 的固定有限基
fan-in-two 电路总数至多

\[
2^{O(S\log(S+m))},
\]

所以至少存在一个 \(p\)-稀疏函数满足

\[
\operatorname{CC}(f)
=\Omega\!\left(
\frac{K(m,p)}{\log(K(m,p)+m)}
\right).
\tag{2}
\]

式 (2) 只是计数得到的存在性下界；它不提供对所有 \(p\) 的匹配上界，也不应被写成
报告中的“精确 Shannon 边界”。Red'kin 的结果在小 \(p\) 区间给出了更强的、且基于
结构参数的匹配渐近。

## 对 zero-list / range-avoidance 路线的直接影响

若候选 outsider 真值表只含

\[
p\le \log_2 m-c\log_2\log_2 m
\]

个 \(1\)，则即使它是该稀疏层中最难的函数，也只有 \(O(m)\)-size 电路。注意这里的
目标复杂度是 \(m\)-变量 truth table 的 circuit complexity；不能把输出长度
\(N=2^m\) 错当成门数尺度。

所以：

\[
\boxed{
\text{极稀疏 }(p\lesssim\log m)\text{ outsider}
\;\not\Rightarrow\;
\text{超线性 hard truth table}.
}
\]

要让稀疏选择路线接近本项目的 hardness-magnification 窗口，必须把 \(p\) 推出该小稀疏
区间，并同时提供一个**匹配的上界/随机访问构造**；单靠组合数
\(\binom{2^m}{p}\) 或“缺失一个稀疏点”不够。

## 与已有记录的关系

- [note 092](092-2026-08-15-chatgpt-pro-report-absorption-and-route-triage.md) 正确地
  拒绝了下载报告中未经证明的全参数 \(\Theta\)-式；本 note 只补入 Red'kin 的可核验小
  稀疏区间和计数下界。
- [note 103](103-sparse-hamming-ball-decoder-and-budgeted-merge-obstruction-2026-08-15.md)
  的 Hamming-ball decoder 仍可作为表示层 primitive，但其 range 中的极稀疏点不能自动
  作为 hard outsider。
- 该校正不产生 \(P\ne NP\)，也不提供一般 decoder 的 circuit lower bound；它删除的是一条
  参数混淆的错误捷径。

文献与参数核验日期：2026-08-15。Red'kin PDF 已缓存至 ResearchLibrary。
