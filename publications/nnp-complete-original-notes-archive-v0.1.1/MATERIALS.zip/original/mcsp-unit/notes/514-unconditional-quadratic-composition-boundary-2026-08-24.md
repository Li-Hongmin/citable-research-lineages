> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Unconditional quadratic composition boundary (2026-08-24)

## Claim

Let \(Q_n\) be a pointwise-exact map from \(N=2^n\)-bit source tables to
\(N'=N^{\kappa+o(1)}\)-bit target tables. Assume:

* \(M_Q\) is a fixed deterministic one-tape transducer with a one-way read-only source
  tape, one two-way read--write work tape, and a fresh sequential write-only output tape;
* \(M_Q\) writes \(O(1)\) output bits per step and halts in \(T_M=N^{b+o(1)}\) steps;
* \(D\) is a target CHMY one-tape decider running in
  \(T_D=(N')^{a+o(1)}\) steps, with exact correctness or preserved bounded error.

The literal handoff is not itself a CHMY run: its read-only input tape still contains \(f\), not
\(Q(f)\). A source decider nevertheless exists in

\[
 O\!\left((T_M+N'+T_D)^2\right)
 =N^{2\max\{b,\kappa,\kappa a\}+o(1)}
 \]

time. Since explicit output implies \(b\ge\kappa\), the CHMY lower bound yields

\[
\boxed{\max\{b,\kappa a\}\ge\mu_H.}
\]

## Proof

Use logical tapes \(W_M,O,W_D\). Simulate \(M_Q\) while redirecting its output to \(O\);
rewind \(O\); then simulate \(D\) with \(O\) as its one-way input and \(W_D\) as its work
tape. This constant-tape machine uses

\[
U=O(T_M+N'+T_D)
\]

steps and decides the source predicate by pointwise exactness. The standard one-tape simulation
of CHMY Section 2.2 and Lemma 9 takes \(O(U^2)\) steps, preserving bounded error under
deterministic simulation. If
\(\beta=\max\{b,\kappa,\kappa a\}<\mu_H\), choose
\(\max\{\beta,\tfrac12\}<\lambda<\mu_H\); the resulting \(N^{2\beta+o(1)}\)-time source decider contradicts
the CHMY lower bound below \(N^{2\lambda-o(1)}\).

## Boundary

This result is unconditional for the stated fresh-output model, but it does not provide the
near-additive handoff needed for the \(2\mu_H\) bound. The one-tape simulation is an upper
compilation cost, not a claim that quadratic overhead is necessary for every semantic
composition. Thus the remaining general window is

\[
\mu_H\le\max\{b,\kappa a\}<2\mu_H,
\]

unless an additional shared-work-tape, synchronous-handoff interface is proved.
