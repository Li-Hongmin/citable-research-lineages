> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Newton 命中谱与全局势边界（2026-08-13）

## 固定超边的精确谱

条件于随机 affine 最大叶 \(R_0\)，令 \(G=H\cap R_0\) 为其保留下来的二部图。对行列以概率 \(p\) 独立 thinning，令 \(M\) 为诱导边数。写

\[
g(m)=\sum_{k=1}^{q}\Delta^k g(0)\binom{m}{k}.
\]

则有精确恒等式

\[
\mathbb E[g(M)\mid G]
=\sum_{\varnothing\ne S\subseteq E(G)}
\Delta^{|S|}g(0)\,p^{|V(S)|},
\tag{1}
\]

其中 \(V(S)\) 是边集 \(S\) 的端点集合。故对于固定 \(q\)，任何命中数势的 thinning 符号问题都等价于有限个二部图上的多项式不等式；不存在隐藏的渐近步骤。

## 结论

若存在 \(p>0\)，使所有 collision 可达图 \(G\) 都满足

\[
\mathbb E[g_H(M)\mid G]\ge0,
\tag{2}
\]

则所有相应非负加权势的 QA 目标都满足

\[
\sum_c\phi_c\le 4/p^2.
\tag{3}
\]

这把“局部命中数势是否能超线性”精确地降为一个有限图谱问题。四点势的安全区为

\[
0<p\le\frac{3-\sqrt3}{2},
\]

其极限由 \(K_{1,3}\) 图型给出；取 \(p=1/2\) 即 note 016 的常数 16。

## 真正的逃逸边界

固定 \(q\) 的命中数势在 \(p\) 足够小时必被 (3) 关闭；例如令
\(a=g(1)>0\)、\(B_-=\max_{j\ge2}(-g(j))_+\)，则

\[
p\le\min\left\{\frac1{4q},
\frac{a}{B_-\max(1,q)}\right\}
\]

保证一命中项压过所有多命中负项。要逃逸，必须至少满足一个条件：

1. 超边阶数 \(q\) 随 \(N\) 增长；
2. \(B_-/a\) 随 \(N\) 增长；
3. 势不再只依赖单个超边的命中数，而保留全局相交图/谱/协议状态。

前两种会使 thinning 概率 \(p\) 降低，并把平均叶上界 \(4/p^2\) 推高；这给出了构造高阶势时的定量成本。第三种是目前唯一没有被局部抽样直接关闭的方向。

## 决策

不再搜索固定阶数、有限动态范围的 collision 权重。下一主线改为：

\[
\boxed{\text{构造依赖全局 collision graph 的递归势，或证明其 leaf capacity。}}
\]

候选输入包括：

- collision graph 的独立数/谱半径；
- Ueno/Chukhin 型递归子可加图势；
- affine-leaf 对整个 edge-label 集合的有效秩，而非单个命中数。

任何候选必须同时通过：

\[
\text{(i) QA recursion}\quad+\quad
\text{(ii) affine leaf normalization}\quad+\quad
\text{(iii) thinning resistance}.
\]
