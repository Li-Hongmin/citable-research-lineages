> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Global average defect to a common full-ROC fiber

## Purpose

The full-ROC mixture theorem (note 275) replaces target-dependent package laws by
a marginal law when the mutual information is \(O(1)\).  A different mechanism
handles the larger regime \(I=o(k)\): first discard targets whose *average*
policy defect is large, then use the policy-level entropy/fiber argument to find
one fixed package on an exponentially large subfamily.  This avoids Pinsker
loss and does not require a sampler for the marginal law.

The package is still global: it contains all coordinate/claim verifiers and
filters.  The theorem therefore does not upgrade ordinary coordinatewise
averages or list soundness.

## Theorem (average-defect common-fiber closure)

Let
\[
  \Pi:\{0,1\}^k\to\Sigma^P,\qquad |\Sigma|=A\ge2,
\]
be a common proof map.  A package \(s\) contains, for every \((i,b)\), an
adaptive verifier with at most \(r\) proof-symbol queries and a transcript filter
that outputs \(b\) or \(\bot\).  For target \(m\), let
\(C_{m,i,s}\) be correct-claim output probability and let
\(W_{m,i,b,s}(z)\) be wrong-claim output probability for
\(m_i\ne b\) and \(d_H(z,\Pi(m))\le\rho P\).

Let \(S\mid M=m\sim\mu_m\), where \(M\) is uniform on \(\{0,1\}^k\), and write
\[
\mathcal D(m,s):=
\max\left\{
\max_i(\alpha-C_{m,i,s})_+,\,
\max_{\substack{i,b,z:\,m_i\ne b\\d_H(z,\Pi(m))\le\rho P}}
(W_{m,i,b,s}(z)-\beta)_+
\right\}\in[0,1].
\tag{277.1}
\]
Put
\[
\bar\delta:=\mathbb E_{M,S\sim\mu_M}\mathcal D(M,S),
\qquad I:=I(M;S)\text{ in bits}.
\tag{277.2}
\]

Choose constants \(0<\eta<1/2\) and
\(0<\Delta<(\alpha-\beta)/2\), and define
\[
p:=1-\frac{\bar\delta}{\eta\Delta}.
\tag{277.3}
\]
Assume \(p>0\), \(\alpha-\Delta\ge c>s\ge\beta+\Delta\).  Then there is a
fixed package \(s_\star\) and a target fiber \(F\subseteq\{0,1\}^k\) with
\[
 |F|\ge
 2^{\,k+\log_2p-\frac{I/p+h_2(\eta)}{1-\eta}},
\tag{277.4}
\]
such that \(s_\star\) has correct output at least \(c\) and wrong output at most
\(s\) for every coordinate and every target-relative \(\rho P\)-near proof in \(F\).

Consequently, Sauer--Shelah gives a shattered coordinate set \(J\) satisfying
\[
\sum_{j\le |J|}\binom{k}{j}\ge |F|,
\tag{277.5}
\]
and the inline proof map restricted to \(J\) is a binary adaptive relaxed LDC with
\[
q_{\rm bin}=1+\lceil\log_2A\rceil r
\tag{277.6}
\]
queries, constant radius, completeness at least \(c\), and wrong output at most \(s\).
For \((c,s)=(2/3,1/3)\), the DGL relaxed-LDC lower bound applies.

In particular, if \(\bar\delta=o(1)\), \(I=o(k)\), and \(\eta,\Delta,c,s\) are fixed
with the displayed strict margins, then \(\log_2|F|=k-o(k)\) and
\(|J|=(1/2-o(1))k\).  Thus every fixed-alphabet, fixed-locality near-linear proof
must violate at least one of: global package structure, \(o(1)\) average defect,
or \(o(k)\) package mutual information.

## Proof

Let
\[
d_m:=\mathbb E_{S\sim\mu_m}\mathcal D(m,S).
\]
Since \(\mathbb E_Md_M=\bar\delta\), Markov gives a target set
\[
T:=\{m:d_m\le\eta\Delta\}
\]
with \(|T|\ge p2^k\).  Let \(M_T\) be uniform on \(T\), and let \(S\mid M_T=m\)
retain the law \(\mu_m\).  Because \(T\) is a function of \(M\),
\[
I(M_T;S)\le I(M;S)/p.
\tag{277.7}
\]
For every \(m\in T\), Markov applied to \(S\sim\mu_m\) gives
\[
\Pr[\mathcal D(m,S)>\Delta]\le\eta.
\tag{277.8}
\]
On the event \(\mathcal D(m,S)\le\Delta\), the package is simultaneously robust
with thresholds \(\alpha-\Delta\) and \(\beta+\Delta\), hence with \(c\) and \(s\).

Apply the average-to-common-fiber entropy argument to the conditional message
distribution \(M_T\).  Its entropy is
\[
H(M_T)=\log_2|T|\ge k+\log_2p.
\]
If \(G\) is the event in (277.8), then
\[
H(M_T\mid S,G=1)
\ge H(M_T)-\frac{I(M_T;S)+h_2(\eta)}{1-\eta}.
\tag{277.9}
\]
Using a regular conditional law of the finite-valued \(M_T\) given the
standard-Borel \(S\), some package value \(s_\star\) has conditional target
support at least the exponential of the right-hand side.  Explicitly, take
\[
F:=\{m:\Pr[M_T=m,\ G=1\mid S=s_\star]>0\}.
\]
Because \(G\) is the deterministic event \(\mathcal D(M_T,S)\le\Delta\),
every target in this support has \(\mathcal D(m,s_\star)\le\Delta\), which
proves (277.4).

Sauer--Shelah gives (277.5).  On a shattered coordinate set, choose one target
for each message pattern.  The fixed package \(s_\star\) is a single decoder for
all representatives.  If two representatives differing at \(i\) had proof
distance at most \(\rho P\), the same package would have correct output at least
\(c\) for one claim and wrong output at most \(s\) for the opposite claim on the
same proof, contradicting \(c>s\).  The resulting symbol distance, inline bit,
and binary recoding give (277.6) and the relaxed-LDC conclusion. \(\square\)

## Boundary

The theorem is stronger than the marginal-mixture route only in the information
regime: \(I=o(k)\) is enough, but it requires a policy-level defect and returns a
single fixed package rather than a target-independent randomized mixture.  If
\(\bar\delta\) is merely a constant, the target set \(T\) may have no useful
density.  If the defect is averaged before taking the worst coordinate or nearby
proof, (277.8) is false and the theorem does not apply.  Standard dPCP/list
soundness remains outside the package hypothesis.

## Sources

* [Average policy-goodness to a common robust fiber](272-average-policy-goodness-to-common-fiber-2026-08-17.md).
* [Mutual-information mixture to full transcript-ROC closure](275-mutual-information-mixture-to-full-roc-closure-2026-08-20.md).
