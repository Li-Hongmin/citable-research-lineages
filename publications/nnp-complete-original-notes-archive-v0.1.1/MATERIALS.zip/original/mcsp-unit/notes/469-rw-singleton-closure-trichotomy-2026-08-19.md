> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW singleton Closure trichotomy: prefix factorization is not physicalization (2026-08-19)

## 本轮改变的判断

published RW Reconf 的 source-level factorization 已经足以把最后的 Closure 缺口写成
一个可检验的 singleton interface。对 C455 的同一个 forced output \(B_n\)，C456 在
\(P=NP\) 分支给出 source-compatible deterministic machine，C370 则给出一条对所有地址
共同的 prefix \(\tau_n\) 加最后地址参数化 query 的分解。若这条分解进一步被 physicalize
成一个共同 static package 和一个有固定接受 gap 的 single-valued address surface，
C364 直接把 \(B_n\) 放进 \(P/\mathrm{poly}\)，与 published forcing 下界矛盾。

因此，“所有地址共享一个 prefix”本身不是 Closure；它只把剩余问题精确收缩为：
要么证明 \(\tau_n\) 与 selected response 能由同一个 address-scale package 产生，
要么证明任何这样的 package 必须支付 object-scale 成本，或明确退出 finite
common-response/global-package 模型。canonical 完备 witness 仍不等于共同 selected
response。

## 设置

令 \(\mathcal I\) 为 C455 的无限 good-length 集合。对 \(n\in\mathcal I\)，记

\[
N_n=|B_n|=2n,
\qquad
S_n:=\operatorname{CC}(B_n)\ge cN_n/\log N_n,
\qquad
m_n=\lceil\log_2(N_n+1)\rceil .
\tag{469.1}
\]

在 \(P=NP\) 分支，C456 取同一个 source-compatible machine \(M\) 和 regular source
\(x_n=(1^n,a_n)\)，使 \(M(x_n)=B_n\)。C370 的 published Reconf factorization 写成

\[
B_n[j]=\mathcal Q_n(x_n,\tau_n,j),
\qquad j\in[N_n],
\tag{469.2}
\]

其中 \(\tau_n\) 是对所有地址相同的 canonical prefix，
\(|\tau_n|=O(n\log n)\)，而 \(\mathcal Q_n\) 的最后一步允许地址 \(j\) 选择自己的
prMA accepting witness。式 (469.2) 是语义分解，不是一个已经 physicalize 的
address evaluator。

称一个在 \(\mathcal I\) 上的 **common-package attachment** 为以下数据：

1. 一个同一的 target object \(B_n\)，不是逐地址替换的 history；
2. 一个 target-dependent static package
   \(\sigma_n\in\{0,1\}^{d_n}\)，可以包含 \(\tau_n\)、cover/sheet index、descriptor
   和 strategy summary；
3. 一个对所有地址共用的 evaluator
   \(E_n(j;\sigma_n,R)\)，其中 \(R\in\{0,1\}^{u_n}\)，并存在 gap
   \(\gamma_n=\alpha_n-\beta_n>0\)，使
   \[
   B_n[j]=1\Rightarrow \Pr_R[E_n(j;\sigma_n,R)=1]\ge\alpha_n,
   \qquad
   B_n[j]=0\Rightarrow \Pr_R[E_n(j;\sigma_n,R)=1]\le\beta_n;
   \tag{469.3}
   \]
4. 在 \(P=NP\) collapse 后，evaluator 的 finite control 对每个地址产生至多
   \(p_n\) 个 collapsed queries，每个 query 描述长度至多 \(L_n\)，确定性控制时间
   （不展开 package ROM）为 \(\kappa_n\)，并至多读取 package \(b_n\) 次；按普通
   fan-in-two 计价，
   \[
   \kappa_n=O(p_nL_n^{c_\star}+p_n^2)
   \tag{469.4}
   \]
   对固定 collapse exponent \(c_\star\) 成立；
5. 所有实际 queries 都在同一个 smart promise 内，且 (469.3) 的 package、地址空间
   和 object 对所有 \(j\) 一致。

这里不要求每个地址显式使用同一个 Merlin circuit；但如果 selected response 随地址
变化，它必须由同一个 \(E_n\) 和 \(\sigma_n\) 产生。仅有
\(\forall j\,\exists C_j\) 不满足本定义。

## 定理 469.1（RW singleton common-package Closure trichotomy）

若 common-package attachment 在 \(\mathcal I\) 上成立，则对任意
\(0<\delta_n<1/4\)，令

\[
t_n=\left\lceil C\frac{m_n+\log(1/\delta_n+2)}{\gamma_n^2}\right\rceil
\tag{469.5}
\]

其中 \(C\) 为绝对常数。则在 \(P=NP\) 分支上，

\[
S_n
\le
O\!\left(t_n\bigl(\kappa_n+b_nd_n+m_n+\log(t_n+2)\bigr)\right).
\tag{469.6}
\]

所以 C455 的 forcing bound 强制

\[
\kappa_n+b_nd_n+m_n+\log(t_n+2)
 =
\Omega\!\left(\frac{N_n}{t_n\log N_n}\right).
\tag{469.7}
\]

特别地，若在无限多个 \(n\in\mathcal I\) 上

\[
p_n,b_n,d_n,L_n,m_n,\log(1/\gamma_n+2),\log(1/\delta_n+2)
 =m_n^{O(1)},
\tag{469.8}
\]

则 (469.6) 给出 \(S_n=m_n^{O(1)}\)，与 (469.1) 矛盾。因而任何声称完成
published RW singleton Closure 的方案，至少落入以下一个出口：

* **量词出口：** 不再使用同一个 \(B_n\)、同一个 package 或同一个 address space；
  逐地址 proof/strategy \(C_j\) 只能属于这个出口；
* **信息/控制付款：** \(d_n\)、\(b_n\)、\(p_n\)、\(L_n\) 或 package ROM 展开已达到
  forcing/object scale；
* **gap/randomness 付款：** \(\gamma_n\) 变小到使 \(t_n\) 超过 address scale，或
  public randomness 不能被有限地固定；
* **model exit：** 采用没有共同 static package 的 non-product/global relation，
  或改变 smartness、same-object、proof/address、或 length-alignment 量词；
* **stable branch：** 只得到 published RW 的 \(N_n^{O(1)}\) object-scale solver，
  这与 \(S_n=\Omega(N_n/\log N_n)\) 并不矛盾。

## 证明

取 \(t_n\) 条 public tapes。由 Hoeffding 不等式和至多 \(2^{m_n}\) 个地址的 union
bound，存在一组固定 tapes，使所有地址的经验接受率误差不超过
\(\gamma_n/3\)。在 \(P=NP\) 下将每个实际 promise query 用固定 deterministic
collapse simulator 替换，阈值化这些经验接受率即可逐位恢复 \(B_n\)。

对每条 tape，finite control 的成本为 \(\kappa_n\)；每次读取同一个长度 \(d_n\) 的
package ROM 用标准 mux 展开，\(b_n\) 次读取成本 \(O(b_nd_n)\)；地址和阈值 bookkeeping
成本为 \(O(m_n+\log(t_n+2))\)。复制 \(t_n\) 条 tapes 得 (469.6)。将 (469.1) 代入并
移项即得 (469.7)。若 (469.8) 成立，\(t_n=m_n^{O(1)}\)，而右侧
\(N_n/(t_n\log N_n)\) 超过任意 \(m_n^{O(1)}\)，故矛盾。

## 对 Gate-I 的精确影响

C370 的共同 prefix 只证明 (469.2)。在 published 稳定参数中，
\(|\tau_n|=O(n\log n)\)，最终 prMA witness 上界也按 object-scale 参数给出；因此
直接把 \(\tau_n\) 硬接进 \(\sigma_n\) 已落入 (469.7) 的信息付款。反过来，若声称
\(\tau_n\) 被压成 address-scale seed，就必须给出一个满足 (469.3)--(469.4) 的共同
physicalization；否则只是把每个地址的 phantom witness 换了名字。

这把 Closure 的正攻压成两个互斥选择：

1. 证明一个真正的 common-package attachment；定理 469.1 随即与 C455 冲突，从而
   得到 \(P=NP\Rightarrow\bot\) 的 published-object 闭合；或
2. 构造一个明确退出 common-package/finite-view 模型的 non-product global relation，
   并重新证明 same-object、smartness、cover/bottom 和 length alignment。仅声称
   “canonical proof 是共同 witness”不能跳过这一步；C365/C370 已隔离该量词缺口。

## 证据边界

* 定理只在 \(P=NP\) 反证分支、C455 的同一 \(B_n\) 与同一无限 good-length 集合上
  使用；它不是无条件的 \(P\ne NP\) 证明。
* 定理是 C364 的 published-RW source-specific instantiation，并不声称 published
  Reconf 已满足 common-package attachment。
* 逐地址 Merlin witnesses、target-dependent physical proofs、未计价 global memory
  或新的 non-product soundness 量词不在 (469.3) 的范围内；它们必须作为 model exit
  单独证明，不能静默纳入 Closure。

## 来源

* [C364 static-package Closure Theorem](364-rw-static-package-closure-theorem-2026-08-18.md)。
* [C370 RW prefix--selected-response factorization](370-rw-reconf-prefix-transcript-address-factorization-2026-08-18.md)。
* [C455 published RW forcing scale](455-published-rw-hard-output-forcing-scale-2026-08-19.md)。
* [C456 published-output source alignment](456-published-rw-output-source-alignment-and-direct-scale-boundary-2026-08-19.md)。
* [C365 common-witness quantifier gap](365-rw-reconf-common-witness-quantifier-gap-2026-08-18.md)。
* [C366 address-scale common-witness payment](366-address-scale-common-witness-payment-for-simultaneous-robustness-2026-08-18.md)。
