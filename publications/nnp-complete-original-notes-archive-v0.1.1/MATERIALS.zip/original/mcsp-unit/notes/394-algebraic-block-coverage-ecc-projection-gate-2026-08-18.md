> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Algebraic block coverage 与 ECC projection gate（2026-08-18）

## 判定

Harsha proof 的大字母表部分与二元 ECC 部分应分开处理。低度多项式 oracle 的
连续 line-block 可以由短的系数/line 描述生成，因此不能把这部分直接当成
address-scale 的障碍。相反，一个线性 ECC 的 binary block projection 有一个
明确的 rank 二分：某个 block 的 projection rank 超过 JK generator 的输入宽度
时，很多 family targets 的该 block 必然是 outsider；若所有 block rank 都不超过
输入宽度，则 payload 必须分散到至少 \(L/k\) 个 blocks，C393 的 interactive
transcript capacity 再强制 object-scale parent information。

这把 actual Harsha attack 的 source-level 断点收缩为：证明所用 ECC 的 projection
profile，或构造一个既保留 PCP robustness 又具有短 algebraic block descriptions
的替代 code。这里不把 RW 原文只写下的“ECC”标签自动升级为 linear-code 假设。

## Theorem 394.1（low-degree line-block coverage）

令 \(F\) 是具有显式 \( \lambda \)-bit 表示的有限域，令
\(P:F^d\to F\) 是总次数至多 \(\Delta\) 的多项式。把一条仿射线写成
\(\ell_{a,v}(t)=a+tv\)，并把 line restriction
\(P(\ell_{a,v}(t))\) 的一段连续 \(s\) 个 field values 按 binary 表示串接，
其中 \(2k=s\lambda\)。若

\[
  k\ \ge\ (\Delta+1+2d+2)\lambda+O(\log k),
\tag{394.1}
\]

则存在一个 \(P\)-uniform generator
\[
  G^{\mathrm{line}}_k:\{0,1\}^{k}\to\{0,1\}^{2k}
\]
且 \(|G^{\mathrm{line}}_k|=k^{O(1)}\)，其 range 包含每一个这样的 line-block。

### 证明

输入描述包含：\(\Delta+1\) 个 univariate coefficient field elements、line
base point \(a\in F^d\)、direction \(v\in F^d\)、segment start \(t_0\)，以及
component/tag 和必要的 padding。所需 bits 为
\((\Delta+1+2d+2)\lambda+O(\log k)\)，由 (394.1) 可零填充到 \(k\) bits。
generator 解析这些字段，在 \(s\) 个点上用 Horner evaluation 计算
\[
  \sum_{j=0}^{\Delta}c_j(t_0+r)^j
\]
并输出其 binary encodings。有限域加乘和系数解析有 uniform polynomial-size
circuits；当 \(\Delta,d,\lambda\le k\) 时，整个电路大小可取 \(k^{O(1)}\)。
任一实际 line restriction 的系数、line 和 start 都给出一个输入描述，所以对应
block 落在 range。证毕。

### 重新分块的含义

把 oracle truth table 按 affine lines 分段，并用一个公开地址 permutation 重新编号，
不会改变 proof length；verifier 只需在查询前应用逆 permutation。因此
Theorem 394.1 是一个可嵌入 relation-PCP 的正向 block-cover interface，而不是
对原始 binary serialization 的自动结论。它覆盖 \(Ã\) 以及任何已知总次数上界的
代数 auxiliary oracle。

## Corollary 394.2（linear ECC projection dichotomy）

令 \(E:\mathbb F_2^{L}\to\mathbb F_2^{P}\) 是 injective linear code，把输出分成
\(m\) 个 \(2k\)-bit blocks，并记第 \(j\) 个 block projection 的 rank 为 \(r_j\)。
对任意 generator \(G_k\) 都有 \(|\operatorname{Range}(G_k)|\le2^k\)。

1. 若某个 \(r_j>k\)，则对均匀 message \(u\in\mathbb F_2^L\)，至多
   \(2^{k-r_j}\) 的比例满足 \(E(u)|_{I_j}\in\operatorname{Range}(G_k)\)；因而至少
   \(1-2^{k-r_j}\) 的 messages 在 top level 存在 non-range block，并触发某个
   first-stage outsider（未必正好是第 \(j\) 个 block，因为更左的 block 也可能先失败）。
2. 若所有 \(r_j\le k\)，则
   \[
     L=\operatorname{rank}(E)
       \le \sum_{j=1}^{m}r_j
       \le mk,
   \tag{394.2}
   \]
   所以 \(m\ge L/k\)。任何从至多 \(q\) 个 block responses 和 \(d\)-bit descriptor
   exact recover message 的 protocol 还必须满足
   \[
     d+2kq\ge L
   \tag{394.3}
   \]
   （C393）。

### 证明

对线性映射 \(u\mapsto E(u)|_{I_j}\)，其 image 是
\(\mathbb F_2^{r_j}\)；均匀 \(u\) 的 projection 均匀分布。generator range 与该
image 的交集大小至多 \(2^k\)，得到第一项。第二项由将 \(E\) 写成所有 block
projection 的直积映射并使用 rank subadditivity 得到。式 (394.3) 是 C393.1
在每个 response 长度 \(2k\) 时的特例。证毕。

## 对 Harsha/RW Closure 的精确边界

Harsha 的 \(\widetilde A\)、\(P=p(\widetilde A)\) 与 zero-on-subcube 链若保持
明确的低度上界，可进入 Theorem 394.1 的 algebraic branch。二元
\(\operatorname{ECC}(\Gamma_x)\) 是否是 linear、其 block projection ranks 是否
满足 Corollary 394.2 的条件，则必须回到所选 ECC 的原始定义核对；RW Theorem 3.4/3.5
的 source statement 本身没有给出这些参数。

因此实际正攻只有两种：

* 证明 Harsha 所用 ECC 的 projection profile 使所有 relevant blocks 都有
  \(k\)-bit 以内的短描述，并进一步证明这些描述可统一绑定 parent；或
* 证明某个 rank \(>k\) 的 block 对 identity/payload family 产生稳定 outsider，
  或利用 \(m\ge L/k\) 与 C393 排除 address-scale exact binding。

本 note 不声称原文 ECC 已被证明线性，不声称所有 auxiliary blocks 已经落入
low-degree branch，也不证明 \(P\ne NP\)。它把 Gate-I 的“auxiliary proof”拆成
一个可正攻的 algebraic block-cover 问题和一个可核验的 ECC projection 问题。

## 来源与关系

* Ren--Williams Theorems 3.4--3.5：\(\widetilde A\)、\(P\)、zero-on-subcube
  auxiliary 与 binary ECC serialization。
* Harsha thesis §§5.3.2, 5.4.1, 5.4.3：低度/除法链的代数构造与二元化。
* C389：actual Harsha factorization 的 source-level 量词边界。
* C393：自适应 transcript 的 parent-binding 容量下界。
