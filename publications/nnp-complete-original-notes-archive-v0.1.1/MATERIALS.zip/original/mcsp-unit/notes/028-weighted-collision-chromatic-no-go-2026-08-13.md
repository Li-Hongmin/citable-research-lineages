> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 加权 collision-染色 / 独立数势的普适上界（2026-08-13）

## 目标

检验一个不同于 AEKR 的非局部状态：把所有 odd--odd affine collision 组成超图，
再用独立集、加权 fractional chromatic number 或超图熵构造 QA 势。

结论是严格的路线关闭：这类势最多线性（独立数势甚至至多常数），且结论不使用
(E_a,NO_b) 的密度或电路语义。

## 全碰撞超图

令 (C=X\times Ysubseteq\mathbb F_2^N\times\mathbb F_2^N)，其中 (X\cap Y=\varnothing)。
定义

\[
\mathsf H_{\rm aff}=(C,\mathcal E),
\qquad
E=\{(x_i,y_i)\}_i\in\mathcal E
\iff
\operatorname{aff}\{x_i\}\cap\operatorname{aff}\{y_i\}\ne\varnothing .
\]

有限域上的 affine 分离定理给出：(R=A\times B) 是 affine-parity 单色叶，
当且仅当 (R) 不含 (mathsf H_{\rm aff}) 的超边。因此这里使用的是所有阶数的
collision，而不只是四点 collision。

更强地，若 (I\subseteq C) 是任意独立集，令
(A=\pi_X(I),B=\pi_Y(I))。若 (\operatorname{aff}A\cap\operatorname{aff}B\ne\varnothing)，
从两侧的有限 affine 表示中挑出相应 cell 即得到 (I) 内的一条 collision 边；
故独立性迫使 (\operatorname{aff}A\cap\operatorname{aff}B=\varnothing)。于是存在一个
affine parity 叶 (R_{\ell,t}) 包含 (I)。换言之，

\[
\{\text{独立集}\}=\{I:I\subseteq R_{\ell,t}\text{ 对某个 affine 叶}\}.
\tag{0}
\]

因此下面的 fractional cover 已经允许比实际 Formula--XOR 叶更宽的静态对象。

## 第一差异着色

对 (c=(x,y)\in C)，令

\[
 j(c)=\min\{j:x_j\ne y_j\},
 \qquad
 \kappa(c)=(j(c),x_{j(c)}).
\]

这是至多 (2N) 色，且是 (mathsf H_{\rm aff}) 的合法着色。事实上，若一条边
(E) 的所有 cell 颜色均为 ((j,b))，而 affine hull 相交，则存在系数
(\alpha_i,\beta_i\in\mathbb F_2) 满足

\[
\sum_i\alpha_i=\sum_i\beta_i=1,
\qquad
\bigoplus_i\alpha_i x_i=\bigoplus_i\beta_i y_i .
\]

在坐标 (j) 上，等式左侧为 (b)，右侧为 (1-b)，矛盾。因此

\[
\boxed{\chi_f(\mathsf H_{\rm aff})\le \chi(\mathsf H_{\rm aff})\le 2N.}
\tag{1}
\]

这比只对四点超图着色更强：任意阶 odd--odd collision 都被排除。

## 加权 fractional chromatic QA 势

给任意非零权 (w:C\to\mathbb R_{ge0})，先按
(|w|_infty) 归一化；以下写成 (0le w_cle1)。定义加权独立集覆盖数

\[
 p_w(R)=\min\left\{
 \sum_{I\in\mathcal I(R)}\lambda_I:
 \lambda_I\ge0,
 \sum_{I\ni c}\lambda_I\ge w_c\ (c\in R)
 \right\},
\]

其中 (mathcal I(R)) 是 (\mathsf H_{\rm aff}[R]) 的独立集族。

### 递归性

若 (R=V\mathbin{\dot\cup}W)，将 (V,W) 的两个 cover 使用不相交的颜色名合并，
得到

\[
p_w(R)\le p_w(V)+p_w(W).
\tag{2}
\]

令 (W_0=\sum_{c\in C}w_c>0)，

\[
\rho=\frac{p_w(C)}{W_0},
\qquad
K_w(R)=p_w(R)-\rho\sum_{c\in R}w_c .
\]

则 (K_w(C)=0)，且由 (2) 满足 QA 递归约束。对任意非空合法叶 (R)，
(mathsf H_{\rm aff}[R]) 无边，故

\[
p_w(R)=\max_{c\in R}w_c.
\]

取

\[
\phi_c=\rho w_c
\]

得到逐叶精确恒等式

\[
\sum_{c\in R}\phi_c+K_w(R)=p_w(R)=\max_{c\in R}w_c\le1.
\]

因此这个最自然的语义加权 QA 证书的目标值恰为

\[
\sum_{c\in C}\phi_c=p_w(C).
\tag{3}
\]

### 普适上界

第一差异色类 (I_{j,b}=\kappa^{-1}(j,b)) 都是独立集。以

\[
\lambda_{j,b}=\max_{c\in I_{j,b}}w_c
\]

覆盖每个 cell，得到

\[
p_w(C)
\le\sum_{j=1}^{N}\sum_{b\in\{0,1\}}
\max_{c\in I_{j,b}}w_c
\le2N.
\tag{4}
\]

结合 (3)：

\[
\boxed{\text{任意加权 fractional-chromatic collision 势的目标}\le2N.}
\]

这不仅限制比例型的 \(\phi\)。若任取 \(\phi\) 而仍使用同一个
\(K_w\)，每个合法叶满足

\[
\sum_{c\in R}\phi_c
\le 1-\max_{c\in R}w_c+\rho\sum_{c\in R}w_c .
\]

随机 affine 有向叶对每个 cell 的命中率为 (q=1/4)。对上式平均并丢弃非正项
(-\mathbb E\max_R w)，得到

\[
q\sum_{c\in C}\phi_c
\le 1+\rho qW_0
=1+q\,p_w(C),
\]

即

\[
\boxed{\sum_c\phi_c\le4+p_w(C)\le 2N+4.}
\tag{4'}
\]

所以即使 \(\phi\) 不与语义权成比例，该整个 \(K_w\)-势族仍至多线性。

所以它不可能达到 \(N^{1.01}\)。一般权只需恢复缩放：
\[
\frac{p_w(C)}{\|w\|_\infty}\le2N.
\]
该界对任意权 \(w\) 成立，权可编码 \(E_a\) 或 \(NO_b\) 的全部语义；
语义加权不能逃逸第一差异着色。

## 独立数势更弱：至多常数

令

\[
\alpha_w(R)=\max\left\{\sum_{c\in I}w_c:I\subseteq R\text{ independent}\right\}.
\]

它也满足 (alpha_w(R)\le\alpha_w(V)+\alpha_w(W))。但在合法叶上
(alpha_w(R)=\sum_{c\in R}w_c)，而 (alpha_w(C)\le W_0)。故根归一化势

\[
K_\alpha(R)=\alpha_w(R)-
\frac{\alpha_w(C)}{W_0}\sum_{c\in R}w_c
\]

在每个合法叶上非负。于是任意可行 (phi) 必须满足

\[
\sum_{c\in R_{\ell,t}}\phi_c\le1
\quad\text{对所有 affine parity 叶 }R_{\ell,t}.
\]

对均匀随机 affine ((\ell,t))，每个 (x\ne y) 以概率 (1/4) 落入指定有向叶，
故平均约束给出

\[
\boxed{\sum_{c\in C}\phi_c\le4.}
\tag{5}
\]

因此最大独立集、加权独立集、其任何只在叶上取线性正规化的变体，连超线性都不能给。

## 超图熵的裁决

Körner--Marton 超图熵由独立集分布定义。使用上面的显式 (2N)-着色（令随机
独立集为包含顶点的颜色类）立即得到

\[
H(\mathsf H)\le \log\chi(\mathsf H)
\le \log(2N).
\]

若采用标准的 fractional-entropy 版本，还可将第一项加强为
(H(\mathsf H)\le\log\chi_f(\mathsf H))。

所以直接把 collision 超图熵作为 QA 势至多给 (O(\log N))；指数化后回到
(chi_f)，已由 (4) 压到 (2N)。要超过线性，必须使用不能归结为
“独立集 cover + 第一差异着色”的递归状态，例如带有跨叶历史的有向 collision
协议；单纯增加超图阶数、独立数或 fractional chromatic 不足。

## 裁决

\[
\boxed{
\begin{array}{c}
\text{all-order collision hypergraph}\\
+\text{independence / weighted fractional chromatic / entropy}
\end{array}
\Longrightarrow O(N)\text{（独立数为 }O(1)\text{）}.
}
\]

这是一条与 AEKR 不同的严格路线关闭；剩余的超线性机会只能来自真正的递归
历史状态，而不是静态超图参数。

## 文献入口

Newman--Wigderson 的 hypergraph-entropy 方法把独立集熵用于公式下界，说明了
该类势的自然性；本文的 (1)--(5) 给出其在 affine-collision 关系上的直接边界。
原始文献：[Newman--Wigderson, *Lower Bounds on Formula Size of Boolean
Functions using Hypergraph-Entropy*](https://www.math.ias.edu/~avi/PUBLICATIONS/MYPAPERS/HNW96/entropy.pdf)。
