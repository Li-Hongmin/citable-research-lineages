> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Kannan 量词、coherent AVOID 与时间尺度边界（2026-08-14）

## 结论

[note 075](075-fixed-exponent-avoid-uniformization-and-local-proof-boundary-2026-08-14.md) 得到

\[
P=NP\Longrightarrow
\forall k\ \exists R_k\in
\text{polylogtime-uniform }AC^0[O(N)]
\quad
\operatorname{CC}(R_k(1^N))>n^k,
\qquad N=2^n.
\tag{1}
\]

本 note 确定 (1) 与经典 circuit diagonalization 的精确关系。

1. Kannan 1982 的 polynomial-hierarchy 定理同样只有
   \(\forall k\exists L_k\)，不是一个 \(L\in PH\setminus P/poly\)。原论文得到单一
   \(P/poly\) lower-bound witness 时，语言已经上移到 super-polynomial time。
2. AVOID 的 nested easy sets 确实允许人为构造 suffix-coherent 的 \(R_k\)。所以缺口不是
   “不同 \(k\) 的答案完全不兼容”。
3. 在 \(P=NP\) 下令 \(k=k(n)\to\infty\)，可以把这些答案缝成一个单一的
   \(n^{O(\log\log n)}\)-time 语言，且具有 \(n^{\Omega(\log\log n)}\) 的 a.e. circuit
   lower bound。量词交换在略高于 \(P\) 的尺度是可行的。
4. 它不可能保持一个固定的 polylogtime-uniform \(AC^0[\mathrm{qpoly}]\) family。更一般地，
   当前 construction 的 uniform running-time exponent 与 hard exponent 都线性增长于 \(k\)；
   padding 把前者压回常数时，也把现有论证能认证的后者压回常数。

因此 note 075 的障碍可进一步收紧为：需要的不是 coherence 本身，而是一个让
“hardness exponent / uniform-time exponent”无界增长的 transformation。

## Kannan 1982 的精确量词

Kannan 的 Theorem 2 原文结论是：对每个非负整数 \(k\)，存在

\[
L_k\in\Sigma_2^P\cap\Pi_2^P
\quad\text{使得}\quad
L_k\notin SIZE(O(n^k)).
\tag{2}
\]

这里电路是 fully nonuniform 的 AND/OR/NOT circuits；不同 input lengths 的电路甚至不要求形成
recursive sequence。式 (2) 的量词是

\[
\forall k\ \exists L_k,
\tag{3}
\]

而

\[
\Sigma_2^P\not\subseteq P/poly
\iff
\exists L\in\Sigma_2^P\ \forall c\quad L\notin SIZE(n^c).
\tag{4}
\]

所以 (2) 不推出 (4)。把 (2) 简写成“\(\Sigma_2^P\) 没有 polynomial-size circuits”会隐藏这个
关键量词差；单一 PH 语言的 unrestricted super-polynomial circuit lower bound 仍将蕴含
\(P\ne NP\)。

Kannan 原论文的 Lemma 4 的确得到单一语言：对任意 increasing、time-constructible、
super-polynomial bound \(f\)，在 \(\Sigma_2TIME(f)\cap\Pi_2TIME(f)\) 中存在没有 small
circuits 的语言。Theorem 4 给出独立的定量版本：存在 universal constant \(\ell\)，对任意
time-constructible \(f\) 满足

\[
n\le f(n)\le 2^{n/20},
\]

存在

\[
L\in\Sigma_2TIME(f)\cap\Pi_2TIME(f)
\quad\text{且}\quad
L\notin SIZE(O(f^{1/\ell})).
\tag{5}
\]

对该范围内的 super-polynomial \(f\)，式 (5) 给出单一 \(P/poly\) lower-bound witness。现代文献
通过相应的截断／padding，把 scaled consequence 表述为 super-polynomial constructible \(S\) 下的
\(NTIME[S]^{NP}\not\subseteq P/poly\)，或概括为 \(\Sigma_2EXP\) 的 circuit lower bound；它不是
\(\Sigma_2^P\not\subseteq P/poly\)。这与 (1) 的 fixed-exponent／single-language 裂缝完全同型。

## suffix-coherent fixed-exponent AVOID

令 \(\Phi_{n,k}:\{0,1\}^{L_k}\to\{0,1\}^N\) 为对 \((n,k)\) uniform 的 canonical decoder，
range 等于 \(\mathsf{Easy}_{n,n^k}\)，并选择 padded encodings 使这些 easy sets 随 \(k\) nested。
对某个与 \(k\) 无关的 universal constant \(c\)，可取

\[
L_k\le n^{k+c}\operatorname{poly}(k),\qquad
\Delta_k=L_k+1,\qquad
r_k=\sum_{j\le k}\Delta_j\le n^{k+c+1}\operatorname{poly}(k).
\tag{6}
\]

假设已经选择 tail \(z_{k-1}\in\{0,1\}^{r_{k-1}}\)。在

\[
Y_w=0^{N-r_k}wz_{k-1},
\qquad w\in\{0,1\}^{\Delta_k},
\tag{7}
\]

中有 \(2^{L_k+1}\) 个 candidates，而 \(|\operatorname{Range}(\Phi_{n,k})|\le2^{L_k}\)。故至少
一个 \(Y_w\) 不在 decoder range。令 \(w_k\) 为 lexicographically first such block，并置

\[
z_k=w_kz_{k-1}.
\tag{8}
\]

固定 \(k\) 时，给定 \(w\) prefix 的可扩展性仍由一个 polynomial-length
\(\Sigma_3^P\) predicate 表示。在 \(P=NP\) 下可逐位求出 \(w_k\)。因此 (1) 可加强为：每个
新 fixed-exponent avoider 保留所有旧 tail blocks。

这个 coherence 不给出 fixed-\(n\) inverse limit。对固定 \(n\)，
\(\mathsf{Easy}_{n,n^k}\) 最终等于全部 truth tables，且 \(r_k<N\) 也最终失败。更重要的是，
计算最新 block 仍必须处理 \(L_k=n^{k+O(1)}\) 长度的 circuit descriptions。

## 可以完成的 delayed stitching

coherence 不是得到单一高复杂度语言所必需的，但使结构更透明。取

\[
k(n)=\lfloor\log_2\log_2 n\rfloor
\tag{9}
\]

（在小长度上任意定义），并令 \(H_n\) 是上节在 exponent \(k(n)\) 处得到的 truth table。
因为

\[
r_{k(n)}=n^{O(\log\log n)}=2^{O(\log n\log\log n)}<2^n,
\tag{10}
\]

pigeonhole construction 对充分大 \(n\) 有效。

这里可以使用一个统一的 meta-algorithm，而不需要把无限多个 machines 写入一个 decider：给定
\((n,k)\)，统一生成式 (7) 的固定三层 quantified predicate。若 \(P=NP\)，取一个固定的
polynomial-time SAT algorithm，按标准 \(PH=P\) induction 求解该 predicate。predicate size、
block 数和逐位 self-reduction 的总成本都是 \(n^{O(k)}\)，其中大 \(O\) 的常数与 \(k\) 无关。
因此由 \(H_n\) 定义的语言 \(H\) 满足

\[
H\in DTIME\!\left(n^{O(\log\log n)}\right),
\qquad
\operatorname{CC}(H_n)>n^{\lfloor\log\log n\rfloor}
\tag{11}
\]

对充分大 \(n\) 成立，特别地 \(H\notin P/poly\)。

这不是 \(P\ne NP\) 结论：即使 \(P=NP\)，略高于 polynomial time 的语言仍可不在
\(P/poly\)。式 (11) 是 Kannan scaled-time phenomenon 的 AVOID 版本，并说明真正丢失的是固定
polynomial exponent，而不是单一语言本身。

## fixed polylog uniformity 的直接屏障

下面的观察不依赖上述 lexicographic construction。

设一个固定 family

\[
R\in\text{polylogtime-uniform }AC^0[\mathrm{qpoly}(N)]
\tag{12}
\]

在 unary input \(1^N\) 上输出 \(N=2^n\) bits，并定义 truth-table language

\[
L_R(x)=R(1^{2^{|x|}})[x].
\tag{13}
\]

qpoly\((N)=2^{n^{O(1)}}\) size circuits 的 gate ID 长度为 \(n^{O(1)}\)。给定一个 output gate，
固定深度的 unbounded-fan-in gate evaluation 可写成固定层数、对 polynomial-length gate IDs 的
alternating quantifiers；uniformity machine 在 \(\operatorname{poly}(n)\) 时间给出 wiring predicate。
故

\[
L_R\in PH.
\tag{14}
\]

若 \(P=NP\)，则 \(PH=P\)，所以存在常数 \(c_R\) 使

\[
\operatorname{CC}((L_R)_n)\le n^{c_R}.
\tag{15}
\]

因此在 \(P=NP\) 假设下，任何 fixed family (12) 都不可能同时避开所有 polynomial circuit
thresholds。suffix coherence、不同的 lexicographic rule 或跨长度 schedule 都不能绕过 (14)--(15)；
若它们成功，成功本身已经证明 \(P\ne NP\)。

## padding 的 exponent-ratio 记账

考虑一个 fixed-\(k\) per-bit uniform construction：它在 base length \(q\) 上计算任意指定的
truth-table bit，并保证该表的 circuit complexity 大于 \(q^k\)。假设这个具体实现的 worst-case
per-bit 工作量有下界 \(\Omega(q^{a(k)})\)。把它 lift 到 \(m\) variables，令

\[
\theta_k=\frac{\log q}{\log m}.
\tag{16}
\]

若仍使用这个实现的 padded construction 必须在固定 \(m^C\) 时间内运行，则必要地

\[
\theta_k a(k)\le C.
\tag{17}
\]

原 lower bound 换算到 \(m\) 尺度只能认证

\[
q^k=m^{\theta_k k}
\le m^{Ck/a(k)}.
\tag{18}
\]

当前显式 self-reduction 在 worst-case suffix bit 上必须至少物化／遍历 \(L_k\ge q^k\) 量级的
quantified description，而上节已有统一上界 \(q^{O(k)}\)，所以这个直接实现的工作 exponent 满足
\(a(k)=\Theta(k)\)。式 (18) 能认证的
exponent 因而有常数上界。要仅靠此类 padding 保证 super-polynomial hardness，至少需要新的
fixed-\(k\) construction 满足

\[
\frac{k}{a(k)}\longrightarrow\infty,
\tag{19}
\]

而现有 AVOID construction 的比例为常数量级。

对本文的 suffix tables 还有一个更直接的 sanity check。把 \(q\)-variable table 以 zero-prefix
方式嵌入 \(m\)-variable table 后，它只有 \(r_k=q^{k+O(1)}\) 个可能非零 coordinates，因而有
size \(O(mr_k)\) 的 DNF。结合 (17) 与 \(a(k)=\Theta(k)\)，这个 upper bound 也是
\(m^{O(C)}\)。所以对本文的具体 sparse family，padding 后不但现有 lower-bound guarantee 变弱，
输出本身也确有固定 polynomial-size upper bound。

## 历史 uniformization 工具为何停在同一处

- McCreight--Meyer union theorem 可把一个有效列举的 uniform complexity-class union 表示成某个
  recursive time bound，但该 bound 不必是 polynomial；它不把增长的 \(n^{a(k)}\) 压成固定指数，
  也不直接作用于 fully nonuniform circuit families。
- Blum speedup 讨论一个 recursive function 是否存在 asymptotically optimal uniform program；它既不
  保持固定 PH level，也不提供针对 \(P/poly\) 的 single-language circuit lower bound。
- delayed diagonalization 可以把 stages 放到越来越稀疏的 lengths，但稀疏 schedule 不改变
  \(n^{a(k)}\) 中 exponent 随 \(k\) 增长。padding 后仍受 (18) 约束。
- Karp--Lipton 使用“整个 class 具有 polynomial circuits”的假设，并在 proof 中固定一个 circuit-size
  exponent。它不能在 polynomial hierarchy 内猜测长度为 \(n^{k(n)}\)、其中 \(k(n)\to\infty\) 的
  circuits。

这些工具支持 (11) 一类 scaled-time union，却没有提供从 (1) 到 fixed family (12) 的量词交换。

## 下一接口

本轮关闭了“先强制 coherence，再用普通 union／padding”的路线。仍未关闭的最小正面命题是以下
任一项：

1. fixed-\(k\) hard-table construction 的 uniform-time exponent \(a(k)=o(k)\)；
2. 不逐位访问 \(n^{\Theta(k)}\) description space、却能保持 easy-range coverage 的新 decoder；
3. 把 mildly super-polynomial uniformity 的 (11) 压到 fixed polynomial time，同时放大一般 circuit
   complexity 的非黑箱 transformation。

任一项若进一步完成从 (1) 到 fixed family (12) 的目标，就必须越过 (14)--(15)；完成这一步在
\(P=NP\) 假设下已经是矛盾核心，而不是 bookkeeping。

## 来源与证据边界

文献核验日期：2026-08-14。

- Ravi Kannan, *Circuit-size lower bounds and non-reducibility to sparse sets*, Information and Control
  55(1--3):40--56, 1982, Theorem 2, Lemma 4, Theorem 4.
  DOI: `10.1016/S0019-9958(82)90382-5`; MIT technical report handle: `1721.1/149016`.
- E. M. McCreight and Albert Meyer, *Classes of computable functions defined by bounds on computation:
  preliminary report*, STOC 1969: complexity-class union theorem. DOI: `10.1145/800169.805423`.
- Manuel Blum, *A machine-independent theory of the complexity of recursive functions*, JACM 14(2),
  1967: Blum complexity measures and speedup framework. DOI: `10.1145/321386.321395`.
- Richard Ladner, *On the structure of polynomial time reducibility*, JACM 22(1), 1975:
  delayed diagonalization. DOI: `10.1145/321864.321877`.
- Richard Karp and Richard Lipton, *Some connections between nonuniform and uniform complexity classes*,
  STOC 1980. DOI: `10.1145/800141.804678`.
- Ryan Williams, *Nonuniform ACC Circuit Lower Bounds*, JACM 61(1), 2014, p. 6: modern statement of
  Kannan's scaled-time consequence. DOI: `10.1145/2559903`.

Kannan 的定理陈述与 scaled-time 结论是文献直接支持的事实。式 (6)--(19)、coherent block
construction、mildly super-polynomial stitching 及 exponent-ratio criterion 是本项目的新推论。
本文不声称已经证明 \(P\ne NP\)。
