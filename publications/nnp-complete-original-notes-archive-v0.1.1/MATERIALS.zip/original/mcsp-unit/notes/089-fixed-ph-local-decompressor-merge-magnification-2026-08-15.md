> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定 PH-local 解压器的 merge magnification（2026-08-15）

## 结论

令

\[
D_N:\{0,1\}^{s(N)}\to\{0,1\}^N,
\qquad
\ell(N)=s(N)+\lceil\log_2N\rceil,
\tag{1}
\]

是一族固定解压器。假设输出位关系属于某个固定 PH 层，并有一个运行时间为
\(\operatorname{poly}(\ell(N))\) 的统一机器/谓词计算任意输出位

\[
\operatorname{Bit}_D(N,z,i)=D_N(z)_i.
\tag{2}
\]

并假设从 \(N\) 可在 \(\operatorname{poly}(\ell)\) 时间和空间内取得 \(s(N)\) 及该 family
所需的统一参数。这里 \(N,z,i\) 的编码总长为 \(O(\ell)\)；“固定”排除了把目标串作为非均匀
advice 偷放进 decoder。定义 total exact inverse

\[
\operatorname{SearchRange}_{D,N}(y)=
\begin{cases}
(1,\min_{\rm lex}D_N^{-1}(y)),&y\in\operatorname{Range}(D_N),\\
(0,0^{s(N)}),&y\notin\operatorname{Range}(D_N).
\end{cases}
\tag{3}
\]

则有两个条件上界：

1. 若 \(P=NP\)，式 (3) 有确定性单遍 streaming algorithm，其空间、每输入位最坏更新时间和
   最终报告时间均为 \(\ell^{O(1)}\)。
2. 若 \(NP\subseteq P/poly\)，式 (3) 有多输出 Boolean circuit family，满足

\[
\operatorname{size}=N\ell^{O(1)},
\qquad
\operatorname{depth}=\ell^{O(1)}\log N.
\tag{4}
\]

所以，对同一个显式固定的 PH-local decoder，若能排除第一类 streaming algorithm，就推出
\(P\ne NP\)；若能排除式 (4) 的搜索电路，就推出
\(NP\not\subseteq P/poly\)，从而也推出 \(P\ne NP\)。

这个命题没有构造 hard decoder，也没有给出任何新的电路下界。它把当前 decoder 路线压缩成一个
精确的条件目标：困难必须来自**固定表示的均匀快速反演**，而不只是 range cardinality。

## 区间最小代表

对连续区间 \(I\subseteq[N]\)，定义

\[
\sigma_I(y)=
\begin{cases}
(1,\min_{\rm lex}\{z:D_N(z)|_I=y|_I\}),&\text{集合非空},\\
(0,0^s),&\text{否则}.
\end{cases}
\tag{5}
\]

设 \(I_1,I_2\) 相邻且不交，\(\sigma_{I_t}(y)=(1,z_t)\)。令

\[
E(z_1,z_2)=
\{z:
D_N(z)|_{I_1}=D_N(z_1)|_{I_1}
\ \land\
D_N(z)|_{I_2}=D_N(z_2)|_{I_2}
\}.
\tag{6}
\]

由于 \(z_t\) 在 \(I_t\) 上复现真实输入 \(y\)，式 (6) 恰好等于

\[
\{z:D_N(z)|_{I_1\cup I_2}=y|_{I_1\cup I_2}\}.
\tag{7}
\]

因此若任一子摘要为 failure，父摘要也必为 failure；否则

\[
\sigma_{I_1\cup I_2}(y)
=
\begin{cases}
(1,\min_{\rm lex}E(z_1,z_2)),&E(z_1,z_2)\ne\varnothing,\\
(0,0^s),&E(z_1,z_2)=\varnothing.
\end{cases}
\tag{8}
\]

这是承重的 merge identity。它解释了为什么合并时不用保存区间的 raw bits：两个子代表已经通过
decoder 自身复现了这些 bits。

## Merge 的复杂度

给定 seed prefix \(p\)，判断它是否能扩展为式 (6) 中的 seed，可写为

\[
\exists z\succeq p\;
\forall j\in I_1\cup I_2:\
\begin{cases}
D_N(z)_j=D_N(z_1)_j,&j\in I_1,\\
D_N(z)_j=D_N(z_2)_j,&j\in I_2.
\end{cases}
\tag{9}
\]

索引 \(j\) 只有 \(O(\log N)\) bits。PH 对有限布尔组合封闭，而式 (9) 的 \(\exists z\) 与
\(\forall j\) 只在原固定 PH 谓词上增加常数个量词层，所以它仍属于某个与 \(N\) 无关的固定 PH
层。依次询问 \(s\) 个 prefix-extension 问题，即可恢复式 (8)
的字典序最小 seed；故 merge 属于 \(FP^{PH}\)，输入和输出长度都是 \(O(\ell)\)。singleton
区间也用同样的 prefix search 从当前输入位产生式 (5) 的摘要。

若 \(P=NP\)，则 \(PH=P\)，每次 leaf/merge 计算均耗时 \(\ell^{O(1)}\)。按 binary-counter
方式维护至多 \(O(\log N)\) 个相邻区间摘要；一次输入更新至多触发 \(O(\log N)\) 次 merge。因此
总空间为

\[
O(\ell\log N)=O(\ell^2),
\tag{10}
\]

最坏更新时间和最终合并、报告时间均为 \(\ell^{O(1)}\)。若 \(N\) 不是二次幂，流结束后按区间
顺序合并栈中剩余的 \(O(\log N)\) 个相邻 blocks；merge 不要求两个子区间等长。完成收尾后的
唯一根摘要就是式 (3)。

若 \(NP\subseteq P/poly\)，则每个固定 PH 层也包含于 \(P/poly\)。一个自足的闭包理由是：
\(NP/poly\subseteq P/poly\)，因为可把 advice 作为 NP 语言的第二输入，再将其硬接入假设给出的
电路；若 oracle 已有 polynomial-size circuits，则一次 NP-oracle 层可先以这些 circuits 代换
oracle，再落入 \(NP/poly\)。对 PH 层数归纳，并用 \(P/poly\) 对补封闭即可。

于是每个 leaf/merge 函数都有 \(\ell^{O(1)}\)-size、\(\ell^{O(1)}\)-depth circuits；其指数只依赖
固定 family \(D\) 与固定 PH 层，不依赖 \(N\)。把 \(s+1\) 个输出位的 circuits 合并只再乘
\(O(s)\le O(\ell)\)。将 merge 放在一棵有 \(N\) 个叶子的平衡树上，得到式 (4)。

## 固定 range language 的决策推论

令

\[
L_D=\bigcup_N\bigl(\operatorname{Range}(D_N)\cap\{0,1\}^N\bigr).
\tag{11}
\]

式 (3) 的 success bit 直接决定 \(L_D\)。因此在 \(NP\subseteq P/poly\) 假设下，

\[
L_D\in SIZE\bigl(N\ell(N)^{O(1)}\bigr).
\tag{12}
\]

特别地：

- 若 \(s(N)=N^{o(1)}\)，则式 (12) 为 \(N^{1+o(1)}\)；对这个同一固定语言证明某个固定
  \(\varepsilon>0\) 的 \(N^{1+\varepsilon}\) lower bound（例如在无限多个长度上成立），都会推出
  \(NP\not\subseteq P/poly\)。
- 若 \(s(N)=\operatorname{polylog}N\)，则式 (12) 为 \(N\log^{O(1)}N\)；证明
  \(L_D\notin\bigcup_c SIZE(N\log^cN)\) 足以得到同一结论。

这两个推论不能只靠短 seed 或小 range 得到；必须先给出一个 fixed PH-local family \(D\)，再对它的
exact inversion 或 fixed range language 证明相应下界。

## 与 MMW 2019 的关系及边界

McKay--Murray--Williams 的 `Circuit-Min-Merge^A` 接受若干小电路及按序不交区间，返回满足所有
区间约束的最小规模、再按字典序最先的 size-\(\le s\) oracle circuit。其 Theorem 1.2 使用相关但
不同的 `Stream-Merge`，给出带短 \(\Sigma_3SAT^A\) queries 的单遍 search-MCSP algorithm；
Theorems 1.3--1.4 分别导出 streaming 与 circuit magnification。式 (5)--(10) 可视为
`Circuit-Min-Merge` 架构对**固定 PH-local map**的二叉特化与直接抽象；本文不把它归为 MMW 已
明确陈述的定理，也不主张该抽象的文献优先权。

必须保留四条边界：

1. decoder family 必须固定且逐位 PH-local；任意 truth table 作为 decoder advice 会使命题失真。
2. 结果处理 exact lexicographic inversion；它不自动给 approximate inversion 或 range avoidance。
3. 上界不产生下界，更不提供满足目标下界的 decoder。
4. [note 086](086-near-linear-covering-decoder-must-be-nonlinear-and-nonsystematic-2026-08-14.md)
   与 [note 087](087-near-linear-obdd-decompression-and-materialization-barrier-2026-08-14.md) 的
   coverage/normalization 缺口仍在：range coverage 只保证 preimage 存在，不保证这里要求的
   exponent-stable inverse lower bound 或其可证明性。

### 来源与核验范围

原文核验日期：2026-08-15。

- Dylan M. McKay, Cody D. Murray, and R. Ryan Williams,
  *Weak Lower Bounds on Resource-Bounded Compression Imply Strong Separations of Complexity Classes*,
  STOC 2019, DOI `10.1145/3313276.3316396`；核验了 Theorems 1.2--1.4、Sections 2.1--3 的
  `Circuit-Min-Merge` 与 Section 4 的 `Stream-Merge`。作者公开全文缓存为 ResearchLibrary 条目
  `dylanmmckay2019weak`。

式 (5)--(12) 为本项目在上述思想基础上的自足推导。外部 ChatGPT 导出只作为命题线索，不作为
证明或文献证据；其中的阶段编号、穷举计数、哈希、Drive 写入声明和未附原始证明的其他结论均未
导入本 note。
