> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 强显式自模拟与 fixed-alternation compression 边界（2026-08-14）

## 结论

[note 076](076-kannan-quantifiers-coherent-avoid-and-time-scale-boundary-2026-08-14.md) 把候选突破接口写成

\[
\operatorname{CC}(Y_{n,k})>n^k,
\qquad
Y_{n,k}(x)\text{ 可在 }n^{a(k)}\text{ 时间逐位计算},
\qquad
\frac{k}{a(k)}\to\infty.
\tag{1}
\]

本 note 修正该判断：在普通、可编译为 Boolean circuits 的逐位模型中，(1) 的第三项不只是未知，
而与前两项直接矛盾。标准 time-to-circuit simulation 给出

\[
\operatorname{CC}(Y_{n,k})
\le O(T_k(n)\log T_k(n)),
\tag{2}
\]

故

\[
T_k(n)\le n^{a(k)}
\quad\Longrightarrow\quad
a(k)\ge k.
\tag{3}
\]

因此普通 padding、direct product、decoder 优化或“更快逐位输出同一张 hard table”不能作为一个与
hardness 同时成立的中间引理。若在 \(P=NP\) 假设下推出 (1)，式 (2) 会立即给出矛盾；这已经是
证明 \(P\ne NP\) 的终点，而不是还能独立优化的前置模块。

历史文献中的弱显式 hard-table construction 不违反 (2)：它们以 truth-table length
\(N=2^n\) 为输入尺度，在 \(\operatorname{poly}(N)=2^{O(n)}\) 时间输出整张表，而 CJSW 需要的是
address length \(n\) 上具有 poly\((n)\)-time local wiring、fixed-PH output evaluation 的强 uniformity；
后者在 \(P=NP\) 假设下才降为 deterministic poly\((n)\)-time random access。

剩余的最小接口应改写为：在 \(P=NP\) 假设下，把 note 076 的 mildly super-polynomial address
computation 压成一个 polynomial-length、fixed-alternation、random-access 可验对象。标准 tableau、
succinct tableau、IW amplification 与当前 encoded-history reconstruction 都没有给出这一压缩。

## 强显式自模拟定理

对每个固定 \(k\)，令 deterministic multitape Turing machine \(M_k\) 在输入
\(x\in\{0,1\}^n\) 上输出 \(Y_{n,k}[x]\)，worst-case time 为 \(T_k(n)\ge n\)。Pippenger--Fischer
simulation 给出一个计算 \(M_k\) 在 length \(n\) 上行为的 Boolean circuit，size 为

\[
O(T_k(n)\log T_k(n)).
\tag{4}
\]

机器描述依赖 \(k\) 只改变式 (4) 的常数，不改变关于 \(n\) 的 exponent。若

\[
\operatorname{CC}(Y_{n,k})>n^k
\tag{5}
\]

对充分大 \(n\) 成立，且 \(T_k(n)=O(n^{a_k})\)，那么 \(a_k<k\) 将给出

\[
\operatorname{CC}(Y_{n,k})
\le O(n^{a_k}\log n)
=o(n^k),
\tag{6}
\]

与 (5) 矛盾。因此

\[
\boxed{a_k\ge k.}
\tag{7}
\]

若只使用 elementary computation-tableau simulation

\[
TIME(T)\subseteq SIZE(T^2\operatorname{polylog}T),
\]

仍有 \(a_k\ge k/2-o(1)\)，已经足以排除 \(a(k)=o(k)\)。更一般地，任何满足

\[
TIME(T)\subseteq SIZE((T+n)^c)
\tag{8}
\]

的逐位模型都强制

\[
a_k\ge k/c-O(1).
\tag{9}
\]

式 (7)--(9) 只使用 direct per-bit computation；不使用 lex-first、AVOID self-reduction、decoder
description length 或 \(P=NP\)。

## 对 fixed-exponent AVOID 的裁决

note 075 在 \(P=NP\) 下为每个 fixed \(k\) 构造

\[
Y_{n,k}\notin\mathsf{Easy}_{n,n^k}.
\tag{10}
\]

因此任何计算该 \(Y_{n,k}\) 的普通 deterministic machine 自动受 (7) 约束。已知构造的
\(n^{O(k)}\) upper bound 与这个必要条件在 exponent 尺度上相合；其线性 dependence on \(k\) 不是
lexicographic search 的偶然低效。

这也修正 note 076 的 padding 解释。若 base function 在 \(q\) variables 上有 hardness \(q^k\)，
padding 到 \(m\) variables 后要由 fixed \(m^C\)-time algorithm 逐位计算，则该 padded function
本身已经有 \(m^{O(C)}\)-size circuits。任何声称仍保留 super-polynomial general-circuit hardness 的
direct padding guarantee 都会立即与 time-to-circuit simulation 冲突。

不能把该结论加强成“算法必须读取全部 decoder description”。令

\[
\Phi'(z,u)=\Phi(z)
\tag{11}
\]

即可任意增加无用 decoder-input bits 而不改变 range 或 avoider；description 本身也可加入 no-op
gates／unused encoding fields。若 decoder range 恰等于 easy set，
算法还可完全忽略 decoder，以更高时间暴力构造 outsider。真正稳健的 lower bound 是 (2)，不是
对某种编码的 read/query lower bound。

## 强显式与弱显式必须分开

Korten 的 Hard Truth Table problem 以 \(1^N\) 为输入，要求输出一张 \(N\)-bit table，其 complexity
接近 \(N/\log N\)。Korten Theorem 1 给出到 `Empty` 的 polynomial-time reduction。结合
[note 074](074-p-equals-np-avoid-fp-low-depth-boundary-2026-08-14.md)，在 \(P=NP\) 下这确实产生
\(\operatorname{poly}(N)\)-time 整表 construction。

但令 \(N=2^n\)，其 address function 的直接时间上界只是

\[
\operatorname{poly}(N)=2^{O(n)}.
\tag{12}
\]

near-maximum lower bound \(\Omega(2^n/n)\) 与 (12) 完全相容。CJSW 的 polylogtime-uniform generator
要求给定 gate IDs 后在 \(\operatorname{poly}(n)\) 时间恢复 local wiring；指定 output 的求值属于
fixed PH，并在 \(P=NP\) 假设下成为 deterministic \(\operatorname{poly}(n)\)-time random access。
这是 strong explicitness，不能由 polynomial total-output time in \(N\) 自动得到。

## 历史 amplification 保持同一比率

固定 note 076 给出的那个统一 stitched decider \(A\)，令 \(T_A(n)\) 是它的 worst-case address
computation time，并令

\[
\rho_A(n)=\frac{\log S(n)}{\log T_A(n)},
\tag{13}
\]

其中 \(S\) 是已认证的 general-circuit lower bound。note 076 给出
\(T_A(n)\le n^{O(\log\log n)}\)，而 (2) 对同一个 \(A\) 给出
\(T_A(n)\ge n^{\Omega(\log\log n)}\)；故 \(\rho_A=\Theta(1)\)。这里不能逐长度对所有 machines
取 pointwise infimum，因为一台只 hardwire 某个固定 length 的 machine 会破坏这种定义。

1. 在本文核对的标准参数化中，IW／Yao XOR／direct-product lemmas 放大 average-case error，但
   reconstructed circuit size 至多保留 \(S^{O(1)}\) 并伴随 polynomial time overhead；它们不使
   \(\rho_A\to\infty\)。
2. Kannan Theorem 4 给出 time \(f\) 对 hardness \(f^{1/\ell}\)，其中 \(\ell\) 为 universal constant；
   它也具有 constant log-hardness／log-time ratio。
3. Korten Theorem 11 的 hardness extractor 在显式 \(M\)-bit input table 上运行
   \(\operatorname{poly}(M)\) time，并输出长度
   \[
   N=\Omega\!\left(\sqrt{\frac{s}{\log M}}\right)
   \]
   的 near-maximum-hard table。它是高时间尺度内的 hardness density amplification，不是 address
   computation 的 class descent。
4. Cook/tableau reduction 需要 \(T\operatorname{polylog}T\) 长度；把 tableau succinct 化则把验证
   上移到 succinct／exponential-time complexity，而非 fixed polynomial hierarchy。
5. NP 内部的 hardness amplification（O'Donnell；Trevisan；Gopalan--Guruswami）以前提语言已经在
   NP 且具有 average-case hardness 为起点；它不把一个 quasipolynomial-time worst-case-hard language
   下沉到 NP。

所以所有只满足

\[
S'\le S^{O(1)},
\qquad
T_{A'}\ge T_A^{\Omega(1)}
\tag{14}
\]

的 black-box transformation 都保持 \(\rho_{A'}=O(1)\)，不能得到一个 P/PH language 的
super-polynomial general-circuit lower bound；这里 (14) 的隐藏常数必须独立于 \(n\) 和 stitched
stage，且 \(S,T_A,S',T_{A'}\) 已按同一个 target address length 重参数化。

## 最新 encoded-history reconstruction 的尺度检查

Ren--Williams 2026 Theorem 4.1 给出一个重要的新机制。若一个 multi-output computation 长度为
\(T\)，则在相应 AVOID solver 失败时，可以在

\[
\operatorname{poly}(q,r,\log T)
\tag{15}
\]

时间内恢复 computation 的一个 output bit；这里 \(q\) 是 AVOID instance input length，\(r\) 是
NP-query round complexity。式 (15) 确实把对 \(T\) 的 dependence 从 polynomial 降到 polylogarithmic。

但是将它用于 truth-table hardness 时，\(q\) 不能免费消失。一个 stretch-two AVOID instance

\[
G:\{0,1\}^q\to\{0,1\}^{2q},
\qquad q=2^{m-1}
\tag{16}
\]

把 \(2q=2^m\) output bits 解释为完整的 \(m\)-variable truth table；一般 \(q\) 可向上取最近的
power of two，只损失常数因子。若其 outsider 要有
circuit complexity 大于 \(s\)，则至少需要

\[
q=\Omega(s/\log s).
\tag{17}
\]

理由甚至不需要 easy-set counting：在 \(s\) 不超过该 truth-table universe 的最大复杂度这一非空
范围内，每张 \(2q\)-bit truth table 都有 size \(O(q\log q)\) 的 full DNF；
若 \(q=o(s/\log s)\)，根本不存在 complexity 大于 \(s\) 的 outsider。因此 Ren--Williams 当前
stated upper bound 中的参数 \(q\) 至少处于 target-hardness scale；这不是 Reconf 的 runtime lower bound。

这里有一个应当排除的假障碍。若直接输出原始 \(N=2^n\)-bit table，则 \(q=N/2\)，式 (15) 只认证
一个 exponential-in-\(n\) upper bound，不能提供目标 local uniformity。但可以先输出较小的
\(m\)-variable table，再把它 lift 为忽略其余 variables 的 \(n\)-variable function。对目标
\(s=n^K\)，标准 truth-table decoder 可取

\[
m=\log_2(2q)=\Theta(\log(s\log s)),
\qquad
q=\min\{2^j:2^j\ge C s\log s\}=\Theta(s\log s),
\tag{18}
\]

其 input 足以编码 size-\(s\) circuits，outsider 的 complexity 大于 \(s\)，restriction 保证 lift 后
lower bound 仍成立。这把 \(q\) 从 \(\Theta(N)\) 降到 \(n^{K+o(1)}\)，却没有给出
\(n^{O(1)}\operatorname{poly}(K)\) 的 bound，其中 \(O(1)\) exponent 必须独立于 \(K\)。把 (18)
代入 (15)，论文当前认证的只是 \(n^{O(K)}\) upper bound；由“大参数出现在 upper bound”不能反推
Reconf 必须花费 \(n^{\Omega(K)}\) 时间。

另一个不对称是：Reconf 只让 failure branch 的每个 output bit 局部化；success branch 的 outsider
由 Solve 显式输出 \(2q\) bits，Theorem 4.1 本身没有给出它的快速 random access。当前 theorem
处理显式 AVOID circuits，没有提供对 succinct、uniform decoder 的 \(\operatorname{poly}(n)\)-time
local solver。

故 encoded history 消除了对 computation length \(T\) 的一项表面障碍，但没有消除
easy-range cardinality／explicit-output 参数。它没有违反 (2)，也尚未产生 CJSW 所需的 strong
explicit generator。

## 下一最小接口：random-access fixed-alternation compression

在 \(P=NP\) 反证假设下固定一个 polynomial-time SAT machine，并令 \(H\) 是 note 076 相对于该
machine 构造的 stitched language：

\[
H\in DTIME(n^{O(\log\log n)}),
\qquad
H\notin P/poly
\quad(P=NP\text{ 假设下}).
\tag{19}
\]

一个足够且精确的缺失命题是：对这个 \(H\)，存在 fixed \(j,c\)、语言 \(G\in\Sigma_j^P\)，以及
统一 map

\[
R(1^n,x)\in\{0,1\}^{n^c},
\qquad
R\text{ 可在 }n^c\text{ 时间计算},
\tag{20}
\]

使得对所有 \(x\in\{0,1\}^n\)，

\[
H(x)=G(R(1^n,x)).
\tag{21}
\]

若 \(P=NP\)，则 \(G\in P\)，由 (20)--(21) 得 \(H\in P\subseteq P/poly\)，与 (19) 矛盾。因此
(20)--(21) 会直接证明 \(P\ne NP\)。对这个 fixed \(H\)，该命题实质上就是 \(H\in PH\) 的
many-one 形式（反向可取 identity reduction）；它是精确重述，不是一个已知更弱的 compression。

在 proof-object 语言中，它要求一个 sound-and-complete fixed-quantifier semantics

\[
H(x)=Q_1y_1\cdots Q_jy_j\;V(x,y_1,\ldots,y_j),
\qquad |y_i|\le n^{O(1)},\quad V\in P,
\]

即把一个 \(n^{\Theta(\log\log n)}\)-step address computation 压成：

\[
\boxed{
\text{poly}(n)\text{-length}
+\text{fixed alternation}
+\text{poly}(n)\text{-time random access/local wiring}
+\text{sound/complete }P\text{-verifier semantics}
}.
\tag{22}
\]

标准 tableau 违反第一项；succinct tableau／recursive reachability 离开 fixed PH；现有 PCP/encoded
history 保留 oracle、promise、round 或 explicit-instance 参数。式 (22) 而非 \(a(k)=o(k)\) 的裸优化，
是当前最小的 contradiction-producing interface。

## 来源与证据边界

检索与原文核验日期：2026-08-14。

- Nicholas Pippenger and Michael J. Fischer, *Relations Among Complexity Measures*, JACM 26(2):361--381,
  1979. DOI: `10.1145/322123.322138`.
- Ravi Kannan, *Circuit-size lower bounds and non-reducibility to sparse sets*, Information and Control 55,
  1982. DOI: `10.1016/S0019-9958(82)90382-5`.
- Russell Impagliazzo and Avi Wigderson, *P = BPP if E requires exponential circuits: Derandomizing the
  XOR lemma*, STOC 1997. DOI: `10.1145/258533.258590`.
- Oliver Korten, *The Hardest Explicit Construction*, FOCS 2021, Theorems 1 and 11.
  DOI: `10.1109/FOCS52979.2021.00051`; arXiv: `2106.00875`.
- Lijie Chen, Ce Jin, Rahul Santhanam, and Ryan Williams, *Constructive Separations and Their Consequences*,
  TheoretiCS 2024, Lemma 2.5. DOI: `10.46298/theoretics.24.3`.
- Hanlin Ren and Ryan Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with
  Merlin-Arthur Queries*, ECCC TR26-118, revision 1, 2026, Theorem 4.1.
- Ryan O'Donnell, *Hardness Amplification within NP*, STOC 2002,
  DOI: `10.1145/509907.510015`; Luca Trevisan, *On Uniform Amplification of Hardness in NP*, STOC 2005,
  DOI: `10.1145/1060590.1060595`; Parikshit Gopalan and Venkatesan Guruswami, *Hardness Amplification
  within NP against Deterministic Algorithms*, JCSS 77(1), 2011, DOI: `10.1016/j.jcss.2010.06.008`.

Pippenger--Fischer、Kannan、Korten、CJSW、Ren--Williams 与 NP amplification 的定理陈述是文献
直接支持的事实。式 (3)、(7)、(9)、(13)--(14)、(17)--(18) 及其对 notes 075--076 的组合裁决是本项目
推论。本文不声称已经证明 \(P\ne NP\)。
