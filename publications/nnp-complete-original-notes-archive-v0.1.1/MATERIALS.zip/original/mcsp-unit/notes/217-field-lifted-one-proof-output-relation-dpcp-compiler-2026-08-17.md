> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Field-lifted one-proof output-relation dPCP compiler (2026-08-17)

## Status

This note gives a positive, fully shared-proof construction at the history/output-code
scale. It is a genuine simultaneous coordinate-robust dPCP compiler, but it does not
compress the hidden history to the RW address scale. Its purpose is to separate the
semantic global-word problem from the remaining length and smoothness problems.

## Setup

Let \(R_x:\Sigma_H^{n_H}\to\{0,1\}\) be a uniformly generated circuit relation and let
\(F_x:\Sigma_H^{n_H}\to\{0,1\}^k\) be a uniformly generated output circuit. Assume all
satisfying histories have the same output:

\[
  R_x(h)=R_x(h')=1\quad\Longrightarrow\quad F_x(h)=F_x(h')=:m_x .
  \tag{1}
\]

Assume \(R_x\) is satisfiable, so that the lifted language below has perfect-completeness
witnesses.

Let

\[
  C:\{0,1\}^k\longrightarrow\Gamma^M
\]

be an explicit outer code with an adaptive decoder \(\mathsf{Dec}_i\) for every message
coordinate \(i\). We require:

1. On \(C(m)\), \(\mathsf{Dec}_i\) outputs either \(m_i\) or \(\bot\), never \(1-m_i\),
   and outputs \(m_i\) with probability at least \(\alpha\).
2. On the honest-answer path, every query step asks position \(t\in[M]\) with probability
   at most \(\lambda/M\).

Assume \(M\ge n_H\), pad \(h\) to length \(M\), and use the lifted alphabet
\(\Sigma_0=\Sigma_H\times\Gamma\). For
\(u=((h_t,\gamma_t))_{t=1}^M\), define

\[
  \widehat R_{x,C}(u)=1
  \quad\Longleftrightarrow\quad
  R_x(h)=1,\qquad
  (\gamma_1,\ldots,\gamma_M)=C(F_x(h)),
  \tag{2}
\]

with padded history coordinates fixed to a public symbol. A standard Boolean circuit-size
bound is

\[
  S\le \operatorname{size}(R_x)+\operatorname{size}(F_x)
    +\operatorname{size}(C)+O(M+n_H+k).
  \tag{3}
\]

At every position use the public projection
\(\pi_t(h_t,\gamma_t)=\gamma_t\). By (1), every valid word of
\(\widehat R_{x,C}\) projects to the same word \(C(m_x)\), even when hidden histories differ.

## Theorem 1 (field-lifted one-proof compiler)

Fix \(\varepsilon>0\) and apply the Gur--Minzer--Weissenberg--Zheng 2-query dPCP theorem to
\(\widehat R_{x,C}\). The resulting dPCP has proof length

\[
  P_{\mathrm{dPCP}}=O\!\left(S\log^{c(\varepsilon,\Sigma_0)}S\right),
  \tag{4}
\]

finite proof alphabet, perfect completeness, and
\((L(\varepsilon),\varepsilon)\)-list-decoding soundness. There is a single proof
\(\Pi_x\) and, for every output coordinate \(i\) and claim \(b\), a verifier
\(V_{x,i,b}\) using at most \(2q_D\) proof queries such that

\[
  \Pr[V_{x,i,m_{x,i}}(\Pi_x)=1]\ge\alpha,\qquad
  \Pr[V_{x,i,1-m_{x,i}}(z)=1]\le q_D\lambda\varepsilon
  \tag{5}
\]

for every candidate global proof \(z\). Thus \(\alpha-q_D\lambda\varepsilon>0\) gives a
simultaneous coordinate-robust one-proof system with a constant branch gap. All coordinates
and both claims use the same proof and address space.

### Proof

Run \(\mathsf{Dec}_i\). Whenever it queries a codeword position \(t\), run the dPCP local
test for decoded position \(t\). Abort on rejection; otherwise feed
\(\pi_t(D_t(\cdot))\) to \(\mathsf{Dec}_i\). Accept claim \(b\) exactly when the outer
decoder returns \(b\). Each local dPCP test uses two proof queries.

For a satisfying lifted word, every projected symbol is \(C(m_x)_t\), and the outer decoder
never outputs the wrong bit on the exact codeword, so the correct branch accepts with
probability at least \(\alpha\).

Fix any candidate dPCP proof \(z\). List soundness supplies valid lifted words
\(u^{(1)},\ldots,u^{(L)}\), and every one projects to \(C(m_x)\). If the compiled verifier
accepts the wrong claim and no locally accepted response has a wrong projection, the outer
decoder sees the honest codeword throughout its transcript and cannot output
\(1-m_{x,i}\). Therefore an accepting execution has a first locally accepted wrong
projection. Before that event the query path is honest, so the probability of querying \(t\)
is at most \(\lambda/M\). The dPCP list error averaged over \(t\), followed by a union
bound over at most \(q_D\) outer queries, gives

\[
\begin{aligned}
  \Pr[V_{x,i,1-m_{x,i}}(z)=1]
  &\le \sum_{r=1}^{q_D}\sum_{t=1}^{M}
       \frac{\lambda}{M}
       \Pr[\text{locally accepted projection at }t\text{ is wrong}]\\
  &\le q_D\lambda\varepsilon .
\end{aligned}
\]

This is one global proof argument; no coordinate-specific proof or Merlin strategy is
introduced. \(\square\)

## Parameter consequences

* If \(M=\Theta(k)\) and a coordinate decoder is supported on \(O(1)\) positions, then
  \(\lambda=\Theta(k)\), so constant wrong-claim soundness requires
  \(\varepsilon=O(1/k)\).
* If an outer code has constant \(q_D,\lambda\) and exact-codeword safety, fixed
  \(\varepsilon\) suffices and (4) is near-linear in the lifted relation size. An ordinary
  3-query LDC in this regime is subject to the known cubic length lower bound, while a
  relaxed code may retain a bottom escape.
* If \(n_H\) is a full computation-history length, then \(S\ge n_H\) and the proof remains
  \(n_H\operatorname{polylog}n_H\)-scale. The theorem solves shared proof/output consistency
  but does not provide the polynomial-in-address-length evaluator required by RW/JK closure.

The output field must be present at every dPCP input position. Putting code symbols only on
the \(k\) output coordinates leaves the other decoded positions without a target-oblivious
projection; the field lift makes the projection global without increasing the alphabet beyond
\(|\Sigma_H||\Gamma|\).

## Evidence boundary

This is a deduction from the lifted relation (2), the output-homogeneous compiler, and the
GMWZ dPCP theorem. It is not a claim that GMWZ already supplies a succinct hidden-history
relation-PCPP. The unresolved top-tier question remains whether the lifted relation can be
compressed from history scale to RW address scale, or whether every such compression must pay
an RLDC/LDC or target-channel cost.

* [GMWZ Theorem 1.6 and detailed Theorem 3.12](https://arxiv.org/html/2512.12960)
* [Output-homogeneous dPCP compiler](216-output-homogeneous-dpcp-compiler-and-alphabet-barrier-2026-08-17.md)
* [Address-scale closure theorem](204-rw-succinct-smart-reconstruction-closure-theorem-2026-08-17.md)
