> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 稀疏 range 与非注入 descriptor 的精确边界（2026-08-24）

## 本轮结论

当前论文的 Corollary 18 只约束 \(Q(A+A)\) 中的 target-NO **输出数**；它不能排除固定两个 target 值的 predicate-specific quotient。这个缺口不是计数疏漏，而是一个精确的反例边界：

* 对任意谓词 \(A\subseteq\{0,1\}^{N}\)，令
  \(Q_A(f)=y_{\rm yes}\)（\(f\in A\)）及
  \(Q_A(f)=y_{\rm no}\)（\(f\notin A\)），其中 \(y_{\rm yes}\in\mathcal L_{n',T}\)、\(y_{\rm no}\notin\mathcal L_{n',T}\)。则 \(Q_A\) 是 exact、\(|Q_A(\{0,1\}^{N})|=2\) 的 non-injective quotient；对平衡谓词，其两个 fibers 可以各自有 \(2^{\Theta(N)}\) 个元素。
* 任何能从 descriptor 直接读出这两个标签的 evaluator，已经给出 \(A\) 的决策算法。因此对 \(A=\mathcal L_S\)，低成本 label-only evaluator 的排除不是 range 的几何结论，而是原 MCSP 的 one-tape 下界本身。

这把“稀疏 range 是否自动关闭剩余窗口”精确化为

\[
\boxed{\text{sparse range alone: no; exact label evaluator: source decision.}}
\]

## 设置

沿用论文 Proposition 8 的参数。令

\[
A=\mathcal L_S\subseteq\{0,1\}^{N},\qquad
S=\lfloor N^{\mu_H}\rfloor,\qquad
N'=N^{\kappa+o(1)},
\]

并令 \(B=\mathcal L_{n',T}\) 为 target-YES 集。对充分大的 \(n'\)，电路计数保证同时存在 \(y_1\in B\) 与 \(y_0\notin B\)。所谓 exact predicate quotient，是存在两个固定 target tables \(y_1\in B\)、\(y_0\notin B\)，使

\[
Q(f)=y_1\Longleftrightarrow f\in A,\qquad
Q(f)=y_0\Longleftrightarrow f\notin A.
\tag{513.1}
\]

这里不要求 \(Q\) 注入，也不要求 \(Q(A+A)\) 含有任何多于这两个值的输出。

### 定理 513.1（label-only descriptor 下界）

设 \(Q\) 满足 (513.1)。设 descriptor 生成器 \(G_n\) 在 canonical source tape 上计算

\[
d_n(f)=G_n(f)
\]

并且存在确定性 evaluator \(V_n\)，只接收 \(d_n(f)\)（不必 materialize \(N'\) 个 target bits），输出一位

\[
V_n(d_n(f))=\mathbf 1_A(f)
\qquad\text{对所有 }f\in\{0,1\}^{N}.
\tag{513.2}
\]

假设 \(G_n\) 与 \(V_n\) 的串接满足 Proposition 8 所要求的 CHMY one-tape handoff，且

\[
\operatorname{time}(G_n)=N^{b+o(1)},\qquad
\operatorname{time}(V_n)=(N')^{c+o(1)}.
\tag{513.3}
\]

则

\[
\boxed{\max\{b,\kappa c\}\ge 2\mu_H.}
\tag{513.4}
\]

该结论不使用 descriptor 的注入性、长度下界、\(Q(A+A)\) 的 range 大小，亦不需要 evaluator 生成完整 target table。

#### 证明

在 source truth table \(f\) 上先运行 \(G_n\)，再把 descriptor 按约定 handoff 给 \(V_n\)。由 (513.2)，该复合机对每个 \(f\) 精确判定 \(f\in\mathcal L_S\)。由 (513.3) 及 \(N'=N^{\kappa+o(1)}\)，其总时间为

\[
N^{o(1)}\bigl(N^{b+o(1)}+(N')^{c+o(1)}\bigr)
=N^{\max\{b,\kappa c\}+o(1)}.
\]

若 \(\max\{b,\kappa c\}<2\mu_H\)，取

\[
\tfrac12<\lambda<\mu_H,\qquad
\max\{b,\kappa c\}<2\lambda,
\]

则得到 \(N^{2\lambda-o(1)}\) 时间的确定性 CHMY source decider，违反论文式 (9) 的 one-tape MCSP lower bound。故 (513.4) 成立。\(\square\)

### 推论 513.2（固定标签的 sparse-range 反例）

任意谓词 \(A\) 都有一个满足 (513.1) 的 map \(Q_A\)，且

\[
Q_A(\{0,1\}^{N})=\{y_1,y_0\},\qquad
Q_A(A+A)\subseteq\{y_1,y_0\}.
\tag{513.5}
\]

令 \(d_A(f)=\mathbf 1_A(f)\)，并令 \(V_A\) 查一位 descriptor 后直接输出该位；则

\[
|d_A(\{0,1\}^{N})|=2,
\qquad
\text{\(d_A\) non-injective whenever both sides are nonempty}.
\tag{513.6}
\]

而 \(V_A\circ d_A=\mathbf 1_A\)。特别地，对 \(A=\mathcal L_S\)，这个 quotient 有固定 target-YES/NO 输出、常数 range 和巨大的 fibers；若其 descriptor 生成在 \(N^{b+o(1)}\) 时间内完成，则生成器本身就是 source MCSP decider，定理 513.1 给出

\[
b\ge 2\mu_H\quad\text{（若 label lookup 为 \(N^{o(1)}\)）}.
\tag{513.7}
\]

因此，仅由 range 稀疏、fiber 非注入或 descriptor 短，不能得到独立于 MCSP 决策的几何/信息下界；任何此类无条件下界都必须利用 one-tape 计算、共同 descriptor、prefix/handoff 或 MCSP-specific 语义。

## 与现有结果的关系

1. Corollary 18 的 target-NO range-richness 结论仍正确：它的前提是低 occupancy inflation。\(Q_A\) 直接处于另一支，即把所有 source sumset 输出压到两个标签，occupancy inflation 为 \(|A+A|/(2|A|)\)，正好支付 Proposition 7 的乘法分解；不能从该支推出第三个 target-NO 值。
2. Corollary 17 要求 descriptor 能完整求值 \(Q(f)\)。定理 513.1 更弱：只要 evaluator 能输出 target decision bit，就已经关闭同一指数窗口；完整 \(N'\)-bit materializer 不是必要条件。
3. 这不是 \(P\ne NP\) 的证明。若声称 \(Q_A\) 有低成本 descriptor，定理 513.1 将把该声称直接转化为 CHMY 所禁止的 source MCSP decider；尚未构造这样的 descriptor。

## 可证伪检查

要声称一个“稀疏 range、non-injective、implicit-output”方案逃过该边界，必须至少指出以下一项失败：

\[
\begin{array}{c}
\text{(i) evaluator 不能从 descriptor 输出 exact target decision bit;}\\
\text{(ii) descriptor/evaluator 串接不满足 CHMY handoff;}\\
\text{(iii) 其输出只在 promise 子集上正确，而非 (513.2) 的全体 truth tables;}\\
\text{(iv) 时间指数已达到 }2\mu_H\text{。}
\end{array}
\]

否则该方案已等价于一个 source MCSP 决策器，而不是一个新的 quotient escape。
