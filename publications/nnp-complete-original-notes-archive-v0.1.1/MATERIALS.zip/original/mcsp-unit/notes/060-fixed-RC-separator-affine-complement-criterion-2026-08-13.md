> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 固定 \(R/C\) separator 的 affine-complement 八轨道闭合（2026-08-13）

## 结论

固定 \(s=(x_s,y_s)\in X\times Y\)，其中
\(X,Y\subseteq\mathbb F_2^N\) 且 \(X\cap Y=\varnothing\)。令
\(\mathcal F\) 是关于 \(s\) 的两两相交极小 collision-witness 族，并写

\[
X_*=\bigcup_{T\in\mathcal F}\pi_X(T),\qquad
Y_*=\bigcup_{T\in\mathcal F}\pi_Y(T).
\tag{1}
\]

考虑随机 \(z=(r,t)\)，以及全局均匀独立的
\(U\subseteq X,V\subseteq Y\)；记

\[
A_z=\{x:q_xz=0\},\qquad B_z=\{y:p_yz=1\},
\qquad
R_z(U,V)=(U\cap A_z)\times(V\cap B_z).
\tag{2}
\]

若全族共用 \(R\)-separator \(q_s(z)=1\)，并存在
\(\delta=(v,b)\in\mathbb F_2^{N+1}\) 使

\[
q_s\cdot\delta=0,\qquad
q_x\cdot\delta=1\quad
\text{for every }x\in X_*,
\tag{3R}
\]

则

\[
\boxed{\Pr_{z,U,V}\big[\exists T\in\mathcal F:
T\subseteq R_z(U,V)\big]\le\frac1{16}.}
\tag{4R}
\]

对偶地，若全族共用 \(C\)-separator \(p_s(z)=0\)，并存在
\(\delta=(v,b)\) 使

\[
p_s\cdot\delta=0,\qquad
p_y\cdot\delta=1\quad
\text{for every }y\in Y_*,
\tag{3C}
\]

则同样有

\[
\boxed{\Pr_{z,U,V}\big[\exists T\in\mathcal F:
T\subseteq R_z(U,V)\big]\le\frac1{16}.}
\tag{4C}
\]

结论不使用 witness 的连通性；因此特别适用于固定 \(R/C\) separator
下的多组件 star-forest 族。

## 线性可检验形式

因为 \(q_x=(x,1)\)，条件 (3R) 等价于

\[
v\cdot x_s+b=0,\qquad v\cdot x+b=1\quad(x\in X_*).
\]

消去 \(b\) 后，它等价于

\[
v\cdot(x+x_s)=1\qquad(x\in X_*).
\tag{5R}
\]

因此只需对差向量集合
\(D_R=\{x+x_s:x\in X_*\}\) 做一次 GF(2) 线性一致性检查：
\(D_R\) 必须落在某个线性函数值为 \(1\) 的仿射超平面内。
等价地，每个线性关系

\[
\bigoplus_{x\in S}(x+x_s)=0
\]

都必须有 \(|S|\) 为偶数。找到这样的 \(v\) 后取
\(b=v\cdot x_s\) 即得到 \(\delta\)。\(C\) 情形把
\((X_*,x_s)\) 换为 \((Y_*,y_s)\)。

条件只要求并集投影 \(X_*,Y_*\)，比要求全部 \(X\setminus\{x_s\}\) 或
\(Y\setminus\{y_s\}\) 更弱；未出现在任何 witness 中的端点不影响命中事件。

## \(R\) separator 的八轨道证明

设
\[
H_R=\{z:q_s(z)=1\}.
\]
所有 witness 的参数支持都包含在 \(H_R\) 中，因此
\(E:=\{\exists T\in\mathcal F:T\subseteq R_z(U,V)\}\) 在
\(z\notin H_R\) 时不发生。

固定 \(z\in H_R\)。由于 \(q_s\cdot\delta=0\)，有
\(z+\delta\in H_R\)。由于每个 witness 的行方程要求
\(q_x(z)=0\)，而其参数支持又包含在 \(H_R\)，故 \(x_s\) 不会出现在
\(X_*\)（否则 \(q_s=1\) 与该行方程矛盾）。又因 \(q_s(z)=1\)，
\(x_s\notin A_z\)；对每个 \(x\in X_*\)，
\(q_x(z+\delta)=q_x(z)+1\)。故

\[
A_{z+\delta}\cap X_*
=X_*\setminus(A_z\cap X_*).
\tag{6}
\]

把 thinning 改写成全局均匀的 \(U,V\) 后，固定 \(z,U,V\)，考虑四个
\(z\)-样本

\[
(U,V),\quad
(U\mathbin\triangle A_z^*,V),\quad
(U,V\mathbin\triangle B_z^*),\quad
(U\mathbin\triangle A_z^*,V\mathbin\triangle B_z^*),
\tag{7}
\]

以及四个 \(z+\delta\)-样本

\[
(U,V),\quad
(U\mathbin\triangle A_{z+\delta}^*,V),\quad
(U,V\mathbin\triangle B_{z+\delta}^*),\quad
(U\mathbin\triangle A_{z+\delta}^*,V\mathbin\triangle B_{z+\delta}^*),
\tag{8}
\]

其中
\[
A_z^*=A_z\cap X_*,\qquad B_z^*=B_z\cap Y_*.
\]

同一组的四个限制矩形分别在行侧或列侧取互补子集，故两两
cell-disjoint。两组之间，(6) 使行侧分别包含于互不相交的
\(A_z^*\) 与 \(A_{z+\delta}^*\)，故也 cell-disjoint。若某组的
\(A_z^*\) 或 \(B_z^*\) 为空，则该组所有限制矩形为空，对 \(E\) 的贡献为零。

全局 \(U,V\) 均匀，且 \(z\mapsto z+\delta\) 保持 \(H_R\)；每个“换到
\(z+\delta\) 并在目标纤维作对称差”的变换也是
\(H_R\times2^X\times2^Y\) 上的测度保持双射。因此不需要把八元组视为自由群
轨道：八个变换后的命中指示函数期望相同，而逐点至多一个为真。
由于 \(\mathcal F\) 两两相交，八个样本至多有一个能命中 \(E\)：
若两个样本分别含有 \(T,T'\in\mathcal F\)，则
\(T\cap T'\ne\varnothing\)，却同时包含于两个 cell-disjoint 限制矩形，
矛盾。于是

\[
8\Pr[E\mid z\in H_R]\le1,
\qquad
\Pr[E\mid z\in H_R]\le\frac18.
\tag{9}
\]

非零线性形式 \(q_s\) 的方程 \(q_s(z)=1\) 占全部参数的一半，结合
\(E\subseteq H_R\) 得 (4R)。

## \(C\) separator 的对偶证明

令 \(H_C=\{z:p_s(z)=0\}\)。在 \(H_C\) 上 \(y_s\notin B_z\)，因为
\(B_z\) 要求 \(p_y(z)=1\)；固定 separator 又意味着 \(y_s\) 不会出现在
\(Y_*\)（否则该列方程与 \(p_s=0\) 矛盾）。条件 (3C) 给出
\(z+\delta\in H_C\)，并且

\[
B_{z+\delta}\cap Y_*
=Y_*\setminus(B_z\cap Y_*).
\tag{10}
\]

使用 (7)--(8) 的同一八个对称差样本；现在两组之间的列侧
\(B_z^*\) 与 \(B_{z+\delta}^*\) 不交，故八个限制矩形仍两两
cell-disjoint。于是
\(\Pr[E\mid z\in H_C]\le1/8\)，而 \(H_C\) 也占参数空间一半，
从而得到 (4C)。

## 任一侧补翻的统一版本

上述条件不必预先指定行侧。对固定 \(R\)-separator，只要
\(q_s\cdot\delta=0\) 且满足下列任一条件即可：

\[
q_x\cdot\delta=1\ (x\in X_*)
\qquad\text{或}\qquad
p_y\cdot\delta=1\ (y\in Y_*).
\tag{12R}
\]

第二种情形中使用列侧
\[
B_{z+\delta}\cap Y_*=Y_*\setminus(B_z\cap Y_*),
\]
八轨道的跨组不交性由列侧而非行侧给出。其线性检查为
\(v\cdot(y+x_s)=1\)（\(y\in Y_*\)），因为 \(q_s\cdot\delta=0\)
先确定 \(b=v\cdot x_s\)。

对固定 \(C\)-separator，只要 \(p_s\cdot\delta=0\) 且

\[
q_x\cdot\delta=1\ (x\in X_*)
\qquad\text{或}\qquad
p_y\cdot\delta=1\ (y\in Y_*),
\tag{12C}
\]

同样成立。这里行侧条件的线性检查为
\(v\cdot(x+y_s)=1\)，列侧条件为
\(v\cdot(y+y_s)=1\)。因此固定 \(R/C\) 的 affine-complement
子类是四个可检验线性分支的并，而非仅两条固定方向。

## 边界

这是一个充分条件，而不是一般固定 \(R/C\) separator 的证明。
条件失败的最小线性障碍是存在奇支持关系

\[
\bigoplus_{x\in S}(x+x_s)=0,\qquad |S|\ \text{奇},
\tag{11}
\]

此时不可能有 \(v\) 同时满足 \(v\cdot(x+x_s)=1\)；\(C\) 情形对偶。
例如 \(x_s=0\)、\(X_*=\{1,2,3\}\subseteq\mathbb F_2^N\) 时
\(1+2+3=0\)，所以不存在 R-complement \(\delta\)。这只说明本八轨道
配对不可用，并不构成 AEKR 质量界的反例；一般 \(R/C\) 缺口仍需别的
affine 参数配对或 residual cross-intersection 论证。

该边界可在合法 witness 族中同时发生。取 \(N=4\)，
\[
X=\{3,11,1,9\},\quad Y=\{10,7,12,2\},\quad s=(11,2),
\]
以及
\[
T_1=\{(9,0),(9,8),(12,3)\},\qquad
T_2=\{(9,0),(9,8),(14,3)\}.
\]
两者都是 \(R\)-separator 的极小 witness，均为两组件 star forest，且共享
\((9,0),(9,8)\)。其 \(X_*=\{9,12,14\}\)、\(Y_*=\{0,3,8\}\)；
两个 \(R\)-补翻分支均不一致（行侧的奇依赖为
\((9+11)+(12+11)+(14+11)=0\)，列侧的奇依赖为
\((0+11)+(3+11)+(8+11)=0\)，故亦无同时满足
\(q_s\cdot\delta=0,\ p_y\cdot\delta=1\) 的解）。逐项枚举的完整命中率为
\(1/512\)，故这只是轨道法的真实边界，不是质量反例。
