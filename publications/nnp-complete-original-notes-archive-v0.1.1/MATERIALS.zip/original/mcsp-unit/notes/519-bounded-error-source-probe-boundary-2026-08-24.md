> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Bounded-error source-probe boundary (2026-08-24)

## Theorem

Let \(A\subseteq\{0,1\}^N\) be nonempty. A randomized procedure may perform arbitrary
computation, query one fixed source-independent auxiliary oracle \(O\), and access the source
table \(x\) only through adaptive bit probes. Suppose its worst-case number of probes is \(q\),
its completeness is at least \(1-\varepsilon_Y\) on \(A\), and its soundness is at most
\(\varepsilon_N\) outside \(A\), with \(\varepsilon_N<1-\varepsilon_Y\). Then

\[
 \boxed{
 q\ge
 \left(1-\frac{\varepsilon_N}{1-\varepsilon_Y}\right)
 \log_2\frac{2^N}{|A|}.
 }
\]

In the symmetric error case \(\varepsilon_Y=\varepsilon_N=\varepsilon<1/2\),

\[
 q\ge\frac{1-2\varepsilon}{1-\varepsilon}\left(N-\log_2|A|\right).
\]

For \(A=\mathcal L_{\mu_H,n}\), circuit enumeration gives
\(\log_2|A|=O(N^{\mu_H}\log N)=o(N)\). Hence every fixed-error source-probe procedure for
MCSP has

\[
 \boxed{q\ge\frac{1-2\varepsilon}{1-\varepsilon}\,(N-o(N)).}
\]

If both error probabilities are \(o(1)\), this strengthens to \(q=N-o(N)\).

## Proof

For \(x\in A\), write
\[
 B_x=\{i\in[N]:x\oplus e_i\notin A\},\qquad d_x=|B_x|.
\]
The edge-isoperimetric inequality for the Boolean cube (Harper) gives

\[
 \sum_{x\in A}d_x\ge |A|\log_2(2^N/|A|),
\]

so some \(x\in A\) has \(d_x\ge\log_2(2^N/|A|)\). Fix this \(x\), and let \(y_i=x\oplus e_i\)
for \(i\in B_x\). For one random tape \(r\), follow the computation on \(x\). If it accepts and
does not probe coordinate \(i\), then the computation on \(y_i\) receives exactly the same source
answers and the same fixed-oracle answers, and therefore also accepts. If \(q<d_x\), summing over
the \(d_x\) boundary neighbors and averaging over \(r\) gives

\[
 \sum_{i\in B_x}\Pr[M(y_i)=1]
 \ge (1-\varepsilon_Y)(d_x-q).
\]

Every \(y_i\notin A\), so the left side is at most \(\varepsilon_Nd_x\). Rearranging yields

\[
 q\ge d_x\left(1-\frac{\varepsilon_N}{1-\varepsilon_Y}\right),
\]

and the claim follows. If \(q\ge d_x\), the same conclusion is immediate.

## Sharpness and scope

The constant cannot be improved from sparsity alone. For \(A=\{0^N\}\), sample
\(q=pN\) distinct coordinates, accept with probability \(1-\varepsilon\) when all sampled bits are
zero, and reject otherwise, where
\[
 p=\frac{1-2\varepsilon}{1-\varepsilon}.
\]
The all-zero input is accepted with probability \(1-\varepsilon\), while every nonzero input is
accepted with probability at most \((1-\varepsilon)(1-p)=\varepsilon\), up to rounding. Thus the
bound is asymptotically tight for fixed symmetric error.

The result applies to adaptive randomized probes and any fixed source-independent \(O\). It does
not apply to a source-dependent oracle \(O_x\), hidden uncharged RAM, or free multi-bit source
answers. It is a probe lower bound, not a \(2\mu_H\)-time lower bound; a near-linear full scan still
fits the surviving one-tape time window.

## Source

Harper's Boolean-cube edge-isoperimetric inequality
([Harper, 1966](https://doi.org/10.1016/S0021-9800(66)80059-5)), already used in the MCSP paper's
XOR-dispersion arguments; and the circuit-enumeration bound for \(\mathcal L_{\mu_H,n}\) used in
Proposition 25.
