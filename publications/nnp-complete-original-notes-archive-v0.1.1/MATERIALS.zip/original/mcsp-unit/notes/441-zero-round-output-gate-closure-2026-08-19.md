> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW 零轮重编译下的 output-gate closure（2026-08-19）

## 本轮改变的判断

C440 说明 Harsha 的 \(\widehat C\) generic evaluator 不是已发表 RW 的现成接口。对最终的
\(P=NP\) 反证，还可以把这个缺口进一步压缩：在 deterministic recompilation 分支，
RW Lemma 3.2 的 query-history 参数变成 \(r=s=0\)，\(C_x\) 的语义只剩下检查
`out` 是否等于重编译 machine 的输出。于是一个能按地址定位 output gate、并在该
gate slice 上评价 \(\widehat C\) 的算法，已经直接给出 hard parent 的 \(P/\mathrm{poly}\) evaluator。
它不是通往 Closure 的普通辅助 lemma，而是 Closure 本身的 Gate-III 形式。

## 零轮的 source 语义

令 \(M\) 是 \(P=NP\) 假设下得到的 deterministic recompilation，输入为固定 RW
context \(x_0\)，输出

\[
 B=M(x_0)\in\{0,1\}^{\ell}.
\]

把 \(M\) 作为 \(r=s=0\) 的 machine 代入 Lemma 3.2。此时 computational-history
input 只有

\[
 \mathrm{hist}=(\mathrm{out}_1,\ldots,\mathrm{out}_{\ell}),
\]

而 \(C_{x_0}\) 接受当且仅当

\[
 \mathrm{out}_j=B_j\qquad(j\in[\ell]).
\tag{441.1}
\]

Harsha §5.4.1 的 \(C'\) 对 \(C_{x_0}\) 的每个 output/equality gate
记录非法 Boolean configuration。故对每个 \(j\)，存在一个合法 gate index tuple

\[
 g_j=(i_{j,1},i_{j,2},i_{j,3})\in H^{3m}
\]

以及两种固定的 Boolean pattern \(\boldsymbol\beta_j^{(0)},\boldsymbol\beta_j^{(1)}\in H^3\)，使得

\[
 C'(g_j,\boldsymbol\beta_j^{(b)})=1
 \quad\Longleftrightarrow\quad b\ne B_j,
\tag{441.2}
\]

其中“(b)”表示 output variable 的候选值；具体 tuple 形状由 output-gate
encoding 决定，不影响下面的结论。

## 定理 441.1（zero-round output-gate closure）

假设固定 binary/field serialization 具有以下两个 address-scale 接口：

1. 给定 \(j\in[\ell]\)，能在 \(\operatorname{poly}(m)\) 时间生成一个 output-gate
   index tuple \(g_j\) 以及两种 pattern \(\boldsymbol\beta_j^{(0)},\boldsymbol\beta_j^{(1)}\)；
2. 给定任意 \(C'\)-coordinate \(a\in H^{3m+3}\)，能在 \(\operatorname{poly}(m)\) 时间
   评价 Harsha 低度延拓 \(\widehat C(a)\)，其中 \(m\) 是最终 hard parent 的逻辑地址长度；
   evaluator 的全部描述/非一致参数也计入该 \(\operatorname{poly}(m)\) 大小，不能暗含
   message-scale 的 \(B\) advice。

则在 \(P=NP\) 分支中，\(B\) 有一个 \(\operatorname{poly}(m)\)-size circuit：对输入
   \(j\)，计算两次 \(\widehat C(g_j,\boldsymbol\beta_j^{(0)})\) 与
   \(\widehat C(g_j,\boldsymbol\beta_j^{(1)})\)，根据 (441.2) 输出 \(B_j\)。因此若同一长度上

\[
 \operatorname{CC}(B)>\operatorname{poly}(m),
\]

上述两个接口就已经给出与 forcing lower bound 的直接矛盾。

### 证明

由 Harsha 的定义，\(\widehat C\) 在 \(H^{3m+3}\) 上等于 \(C'\)。因此对 output-gate index tuple
\(g_j\)，两次 evaluator 调用返回的正是 (441.2) 的两个 \(C'\)-值。恰有一个
Boolean pattern 是合法的，故两值确定 \(B_j\)。tuple 与 pattern 由 \(j\) 的地址
电路生成，field arithmetic 和两次 \(\widehat C\) evaluator 也只有 \(\operatorname{poly}(m)\)
大小；把它们串成一个按 \(j\) 工作的 circuit 即得 \(B\) 的 \(P/\mathrm{poly}\) evaluator。
证毕。

## 与 C439/C440 的关系

* C439 的 \(P=p(q)\) 反演需要 \(P\)-evaluator、\(\widehat C\)-evaluator 与 incidence map；
  定理 441.1 表明，在 \(r=s=0\) 的最终 branch，后两项已经足以直接读出 output，
  不必先暴露 \(P\)；
* C440 的 object-scale weighted-sum barrier 因而不是外围技术问题：若只能扫描
  完整 gate list，不能得到定理 441.1 的第二项；若能以 address scale 完成 weighted
  sum，便已经完成最终 parent evaluator；
* 若 output gate 的 tuple 不能按地址生成，缺口正是 C440 的 layout/incidence 分支，
  不能用“\(C_x\) 检查了 out”这句语义描述替代。

## 量词与证据边界

1. \(r=s=0\) 来自 \(P=NP\) 下把固定 SAT-oracle machine 确定化；它不是对原始
   Theorem 3.5 的任意 machine 的无条件假设。
2. 定理要求固定 output-gate serialization；RW Theorem 3.5 只给出 systematic
   \(\widetilde w\) 前缀和 auxiliary proof 分解，没有给出该 layout。
3. 这里的 \(\widehat C\) evaluator 是对固定 published context 的 source-specific 接口；
   C431 已说明对所有 source inputs 的统一 accessor 另有 succinct-circuit-value barrier。
4. 本定理是条件性 Gate-III closure，不证明 published RW 已满足接口，也不证明
   \(P\ne NP\) 或一般 dPCP/RLDC impossibility。

## 来源

* Ren--Williams TR26-118 revision 1, Lemma 3.2 and Theorem 3.5；本地抽取：
  `units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md`。
* Harsha, *Robust PCPs of Proximity and Shorter PCPs*, §5.4.1,
  Proposition 5.4.1, equations (5.6)--(5.8)；本地抽取：`[unbundled local reference]`。
* [note 416](416-rw-prefix-first-failure-output-attachment-under-p-equals-np-2026-08-19.md)。
* [note 440](440-harsha-constraint-extension-source-interface-barrier-2026-08-19.md)。
