> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# AM commitment 不是 deterministic JK seed（2026-08-15）

## 结论

Chen--Li--Liang 的 commit-and-evaluate 协议确实能在 HSG 失败分支上，给
Reed--Muller 编码的 computation history 提供短地址的随机访问；但其短 commitment
\(\alpha\) 不能直接当作固定 \(G_q\) 的 deterministic、word-level seed。

原因是一个简单的信息论命题：

\[
\boxed{
\text{若 seed 单独决定整个函数，seed 长度至少是函数族的熵；}
\quad
\text{AM evaluation 则把未压缩信息留在 Merlin 的后续策略中。}
}
\]

## Deterministic accessor 熵下界

令 \(\mathcal F\) 是从索引集 \(I\) 到有限值集 \(A\) 的函数族。若存在一个固定的
deterministic word accessor

\[
  E:\{0,1\}^{\ell}\times I\longrightarrow A
\]

满足

\[
  \forall f\in\mathcal F\ \exists a_f\in\{0,1\}^{\ell}\quad
  \forall i\in I,\ E(a_f,i)=f(i),
\tag{1}
\]

则

\[
  \ell\ge \left\lceil\log_2|\mathcal F|\right\rceil.
\tag{2}
\]

### 证明

若 \(f\ne g\) 却有 \(a_f=a_g\)，则对所有 \(i\) 有
\(f(i)=E(a_f,i)=E(a_g,i)=g(i)\)，矛盾。因此
\(f\mapsto a_f\) 是从 \(\mathcal F\) 到 \(\{0,1\}^{\ell}\) 的单射，(2) 立即成立。

对一个 \(K\)-维的 \(\mathbb F_q\)-线性 Reed--Muller 函数空间，
\(|\mathcal F|=q^K\)，于是

\[
  \ell\ge K\log_2 q.
\tag{3}
\]

这里 \(K\) 只需取相应 RM 空间的实际维数；无需预设是总次数还是逐变量次数约束。
在每个变量的度数界满足 \(d<|\mathbb F_q|\)（或已明确取标准的低度商空间）时，
逐变量次数至多 \(d\) 给出 \(K=(d+1)^r\)，总次数至多 \(d\) 给出
\(K=\binom{r+d}{d}\)。若 \(d\ge|\mathbb F_q|\)，应改用商空间后的实际函数维数，
不能直接套用这两个形式计数。

该结论适用于任意 Boolean/fan-in-2 decoder 实现，不依赖线性、系统性或
lexicographic 选择；它只使用“同一个 seed 在所有地址上决定同一个完整函数”。

## AM 量词与 JK 量词的严格错配

把一个理想化的 exact AM evaluation 写成：对每个 \(f\in\mathcal F\)，存在
commitment \(\alpha_f\) 和 Merlin strategy \(\tau_f\)，使得

\[
\forall i\in I\ \forall r\ \exists m_{i,r},
\qquad
V(\alpha_f,i,r,m_{i,r})=f(i).
\tag{4}
\]

这里 \(r\) 是 Arthur 的随机带；\(m_{i,r}\) 可以依赖当前地址和随机带。JK
需要的 deterministic seed 则是

\[
\exists u_f\in\{0,1\}^{q}\ \forall i\in I,
\qquad E(u_f,i)=f(i).
\tag{5}
\]

式 (4) 不能仅靠重排量词变成式 (5)：后续 Merlin responses 可能在不同地址上
携带不一致的信息。更精确地，若试图令 \(u_f=\phi(\alpha_f)\)，其中 \(\phi\)
是固定确定性编码，则不同 \(f\) 必须使用不同的 \(\alpha_f\)，否则同一个 seed
会在所有地址上给出同一个函数。因此

\[
|\alpha_f|\ge\lceil\log_2|\mathcal F|\rceil,
\qquad
q\ge\lceil\log_2|\mathcal F|\rceil.
\tag{6}
\]

若再把一个长度为 \(d\) 的 canonical evaluation-strategy 摘要 \(\beta_f\) 编入
seed，则只能得到

\[
|\alpha_f|+|\beta_f|
\ge\lceil\log_2|\mathcal F|\rceil;
\tag{7}
\]

未压缩的信息并没有消失。对 \(2^h\) 个可以独立变化的叶函数，若要求一个
global seed 同时确定整棵树，则相同计数进一步要求

\[
q_{\mathrm{global}}
\ge 2^h\lceil\log_2|\mathcal F|\rceil.
\tag{8}
\]

这是一向确定性通信/编码下界，不是 AM 的交互式下界；它只说明“短 commitment
+逐地址 Merlin”不能被直接当作 JK 的整词 seed。固定单一 history、保留 Merlin
交互，或证明一个真正短的 canonical strategy summary，均不被式 (6)--(8) 排除；
后两种情形仍需另证 exact evaluator 与 parent concatenation closure。

## 为什么 CLL 的 AM 协议不违反下界

CLL 的 Theorem 3.7（RMV commit-and-evaluate）有两个阶段：

1. \(\sigma_c\) 输出短 commitment \(\alpha\)；
2. \(\sigma_e\) 在输入地址 \(x\) 上继续与 Merlin 交互，输出承诺多项式在 \(x\)
   的值或 \(\bot\)。

对每个多项式 \(p\)，Conformity 只保证存在一对 Merlin strategies
\((\tau_c,\tau_e)\)，使 \(\sigma_e^{\tau_e}(x,\cdots)\) 正确输出 \(p(x)\)。
因此 \(\alpha\) 并不单独决定 \(p\)：未压缩的多项式信息仍在后续策略
\(\tau_e\) 中。Resiliency 也只保证固定 commitment 后，任意评价策略大概率落在
\(\{g_\alpha(x),\bot\}\) 中；它没有给出一个从 \(\alpha\) 本身计算
\(g_\alpha(x)\) 的 deterministic circuit。

所以 CLL 的协议可以有短 transcript，却不提供满足式 (1) 的
\(E(\alpha,x)\)。若把 \(\sigma_e\) 中的 Merlin 删除，要求同一 \(\alpha\) 单独决定
所有 RM functions，则 (3) 强制 commitment 回到完整系数熵。

## 对 RW/JK 的直接含义

### 1. 不能把 commitment 当作 \(q\)-bit leaf seed

若 JK leaf mode 令

\[
  G_q(u)[\text{block address}]=E(u,\text{address})
\]

并希望覆盖一个 RM family \(\mathcal F\)，则由 (2)--(3)

\[
  q\ge\log_2|\mathcal F|.
\]

当 \(\mathcal F\) 是全局 history polynomial family 时，这正是 note 130 的
coefficient-tensor scale；短 AM commitment 没有绕过它。

### 2. 固定单一 history 仍未被排除

若只需一个固定 \(p_H\)，式 (2) 只给出平凡的 \(\ell\ge0\)。因此本命题不排除
一个 history-specific \(q=\operatorname{poly}(n)\) seed；它只说明必须真正利用
\(p_H\) 的特殊结构，不能把“存在 AM commitment”当成统一 code。

### 3. 需要同时满足 JK 的整词一致性

即使把后续 Merlin 策略固定成某个 canonical strategy，也必须额外证明：

\[
  u_{H,v}=\operatorname{Seed}(H,v)
\]

是一个可由 \((n,H\text{-index},v)\) 统一生成的完整 \(q\)-bit word，并且
\(u_{H,v_0}\Vert u_{H,v_1}\) 正好是父 block 的合法 seed。逐地址的 AM evaluation
只给出不同 query 的交互回答，不自动给出这个 word-level concatenation law。

因此当前真正剩余的接口是：

\[
\boxed{
\text{固定 history 的 deterministic whole-word seed/accessor}
\;+\;
\text{JK parent closure}
}
\]

而不是再次寻找更短的 AM commitment。

## 文献边界

- Lijie Chen, Jiatu Li, Jingxun Liang, *Maximum Circuit Lower Bounds for
  Exponential-Time Arthur Merlin*, ECCC TR24-182 revision 2：
  [official report](https://eccc.weizmann.ac.il/report/2024/182/)。
  其 Theorem 3.7 的 RMV 协议直接区分 commitment 与后续 evaluation strategy。
- [note 130](130-recursive-multivariate-polynomial-labeler-scale-2026-08-15.md)：
  全局多变量标签器的系数熵尺度。
- [note 141](141-canonical-pcp-still-quasipolynomial-at-address-scale-2026-08-15.md)：
  CLL 强 canonical PCP 的地址时间边界。

本 note 是自足的信息下界与协议语义区分；不声称得到 \(P\ne NP\)。

核验日期：2026-08-15。
