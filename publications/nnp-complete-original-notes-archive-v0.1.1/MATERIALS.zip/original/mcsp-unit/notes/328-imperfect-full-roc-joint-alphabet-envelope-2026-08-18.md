> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Imperfect full-ROC joint-alphabet envelope (direct q-ary GGS)

## Contribution

The full-ROC mixture interface does not need a binary inner code in order to
enter the arbitrary-finite-alphabet GGS theorem.  The proof symbols can be kept
as (A_K)-ary symbols and only the message-inline coordinate is tagged.  This
gives a source-safe envelope for imperfect completeness and growing proof
alphabets without charging an assumed inner-code length.

The result is complementary to C326/C327: those notes charge an available
binary inner code and obtain the sharper binary/adaptive or binary/nonadaptive
locality gates.  The present theorem applies when no suitable inner code is
available, and therefore retains the alphabet factor explicitly.

## Theorem

Let

\[
  \Pi_K:\{0,1\}^{K}\longrightarrow\Sigma_K^{P_K},
  \qquad A_K:=|\Sigma_K|\ge2.
\]

Suppose the mutual-information/full-ROC mixture step leaves a family
\(\mathcal F_K\subseteq\{0,1\}^K\) of density at least (1/2) and one
target-independent package law \(\bar\mu_K\) such that, for fixed constants
\(0<s<c\le1\), every \(m\in\mathcal F_K\), coordinate \(i\), claim \(b\),
and \(z\in\Sigma_K^{P_K}\) with
\(d_H(z,\Pi_K(m))\le\rho P_K\),

\[
  \mathbb E_{S\sim\bar\mu_K} C_{m,i,S}\ge c,
  \qquad
  \mathbb E_{S\sim\bar\mu_K} W_{m,i,b,S}(z)\le s
  \quad (m_i\ne b),
\tag{328.1}
\]

where \(C\) and \(W\) are the full-transcript correct- and wrong-claim
probabilities of note 275.  Let \(d_K\) be a shattered coordinate set supplied
by \(\mathcal F_K\), so \(d_K=\Omega(K)\), and let \(r_K\) bound the adaptive
proof-symbol depth of every package branch.  Define

\[
  Q_K:=1+2\sum_{j=0}^{r_K-1}A_K^j,
  \qquad
  H_K:=\log_2\log_2(d_K+2)+\log_2(Q_K+2)
       +\log_2\!\bigl(\log_2(A_K+2)+2\bigr).
\tag{328.2}
\]

For every fixed \(c_0\), on every sufficiently large subsequence satisfying

\[
  N_K:=d_K+P_K\le d_K\bigl(\log_2(d_K+2)\bigr)^{c_0},
\tag{328.3}
\]

there is a constant \(\eta=\eta(\rho,c,s,c_0)>0\) such that

\[
  \log_2(A_K+2)\ge d_K/2
  \qquad\text{or}\qquad
  Q_KH_K\ge\eta\log_2 d_K.
\tag{328.4}
\]

Thus a direct q-ary full-ROC route cannot simultaneously have a
non-message-scale alphabet, near-linear proof length, and
\(Q_KH_K=o(\log K)\).  No binary inner-code hypothesis is present in this
statement.

## Proof

Choose one representative \(m_u\in\mathcal F_K\) for each pattern on a
shattered coordinate set \(J_K\) of size \(d_K\).  If two representatives
whose patterns differ at coordinate \(i\) had proof words at distance at most
\(\rho P_K\), applying (328.1) to the same target-independent law on that
proof would give a correct output with probability at least \(c\) and the
opposite output with probability at most \(s\).  This contradicts \(c>s\).
Hence the restricted proof family has minimum Hamming distance greater than
\(\rho P_K\).

Write \(\ell_K=\log_2 A_K\).  The \(A_K\)-ary Singleton bound gives

\[
  d_K\le ((1-\rho)P_K+1)\ell_K.
\tag{328.5}
\]

If \(\log_2(A_K+2)\ge d_K/2\), the first alternative in (328.4) holds.  Assume
otherwise.  From (328.5), for all sufficiently large \(d_K\),

\[
  \frac{P_K}{N_K}
  \ge \frac{1}{2(1-\rho)\ell_K+1}.
\tag{328.6}
\]

Use the tagged alphabet

\[
  \Gamma_K:=\{(I,0),(I,1)\}\sqcup\{(P,a):a\in\Sigma_K\},
  \qquad |\Gamma_K|=A_K+2,
\]

and the codeword
\(C_K(u)=u\Vert (P,\Pi_K(m_u)_1)\Vert\cdots\Vert(P,\Pi_K(m_u)_{P_K})\).
Set

\[
  \delta_K:=
  \frac{\rho}{2\bigl(2(1-\rho)\ell_K+1\bigr)}.
\tag{328.7}
\]

On a received word within relative distance \(\delta_K\) of \(C_K(u)\),
an invalid inline or proof tag causes immediate \(\bot\).  If all queried proof
tags are valid, stripping them yields a word \(z\) within \(\rho P_K\) of
\(\Pi_K(m_u)\), by (328.6)--(328.7).  The decoder reads the inline tag,
samples one package \(S\sim\bar\mu_K\), and runs the corresponding adaptive
filter.  On the exact codeword, the correct claim is output with probability at
least \(c\).  On a nearby word, a wrong inline claim is output with probability
at most \(s\); invalid tags only produce \(\bot\).  Therefore this is a weak
adaptive \((r_K+1,\delta_K,\sigma)\)-RLDC over \(\Gamma_K\), with

\[
  \sigma:=\min\{c,1-s\}>0.
\tag{328.8}
\]

Fix the random tape.  Each claim branch is an \(A_K\)-ary decision tree with at
most \(\sum_{j<r_K}A_K^j\) internal query nodes.  Query the union of both
trees and the inline coordinate.  After the answers are received, the decoder
selects the branch named by the inline tag and simulates it exactly.  Hence the
adaptive decoder has a nonadaptive realization with at most \(Q_K\) queries,
alphabet \(A_K+2\), and the same output distribution.

The arbitrary-finite-alphabet GGS theorem now gives, whenever
\(\delta_K>N_K^{-\sigma/(2Q_K)}\),

\[
  N_K\ge
  \left(
    \frac{\sigma^2d_K}
    {38Q_K^4\log_2^2(A_K+2)\log_2^2d_K}
  \right)^{1+1/a_K},
  \qquad
  a_K:=\left\lceil Q_K/\sigma\right\rceil.
\tag{328.9}
\]

If the radius condition fails, (328.7) and (N_K\ge d_K) immediately imply

\[
  Q_K\bigl(\log_2(\log_2(A_K+2)+2)+1\bigr)
  =\Omega_{\rho,\sigma}(\log_2d_K),
\tag{328.10}
\]

which is stronger than the second alternative in (328.4).  In the remaining
case, take logarithms in (328.9).  With

\[
  D_K:=38Q_K^4\log_2^2(A_K+2)\log_2^2d_K/\sigma^2,
\]

there is a constant \(C_0=C_0(\sigma)\) such that
\[
  \log_2D_K\le C_0H_K
\tag{328.11}
\]
whenever \(d_K\) is large.  Indeed, the three logarithmic terms in \(D_K\)
are respectively bounded by constant multiples of the three terms in
\(H_K\).  Taking logarithms in (328.9), using (328.3), and writing
\(a_K=\lceil Q_K/\sigma\rceil\), gives
\[
  \frac{\log_2d_K}{a_K}
  \le c_0\log_2\log_2(d_K+2)
      +\left(1+\frac1{a_K}\right)\log_2D_K.
\tag{328.12}
\]
Since \(1/a_K\ge\sigma/(Q_K+\sigma)\), \(1+1/a_K\le2\), and
\(\log\log(d_K+2)\le H_K\), (328.11)--(328.12) imply
\[
  \frac{\sigma\log_2d_K}{Q_K+\sigma}
  \le (c_0+2C_0)H_K.
\tag{328.13}
\]
Now suppose \(Q_KH_K\le\eta\log_2d_K\).  Multiplying (328.13) by
\(Q_K+\sigma\), the terms containing \(Q_KH_K\) are at most
\((c_0+2C_0)\eta\log_2d_K\), while the remaining
\(\sigma(c_0+2C_0)H_K\) term is at most
\(\sigma(c_0+2C_0)\eta\log_2d_K\), since \(Q_K\ge1\).
Choose \(\eta>0\) so small that the sum of these coefficients is below
\(\sigma/2\).  This contradicts (328.13) for all sufficiently large
\(d_K\), and proves (328.4).
\(\square\)

## Scope and relation to the other gates

The full-ROC/common-package quantifier is essential.  Ordinary average or list
soundness does not provide the same target-independent marginal law, and
coordinatewise witnesses do not imply one global proof word.  The theorem is a
coding closure statement, not an unconditional dPCP impossibility or a
\(P\ne NP\) theorem.

For imperfect completeness with a fixed-distance binary inner code, C326 charges
the actual expansion \(\ell_K\) and yields the adaptive threshold
\((1+\ell_Kr_K)\log(3+\ell_Kr_K)=\Omega((\log K)^{1/3})\); C327 sharpens the
nonadaptive case to \(1+\ell_Kr_K=\Omega(\log K/\log\log K)\).  The present
direct q-ary theorem is the source-safe fallback when no such inner code is
available, at the cost of the explicit joint alphabet--locality envelope.

## Sources

* Mutual-information/full-ROC mixture interface: [note 275](275-mutual-information-mixture-to-full-roc-closure-2026-08-20.md).
* Perfect-completeness direct q-ary envelope: [note 300](300-source-safe-joint-alphabet-locality-envelope-2026-08-17.md).
* Quantitative GGS calculation: [note 242](242-growing-query-threshold-for-near-linear-closure-2026-08-17.md).
* Goldberg--Gur--Saraogi, *Nearly Tight Lower Bounds for Relaxed Locally Decodable Codes via Robust Daisies*, Theorem 1: <https://arxiv.org/abs/2511.21659>.
