> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 置换轨道的稀疏 NP 族与 hardness-magnification 接口（2026-08-15）

## 参数族

沿用 [note 098](098-fixed-label-permutation-orbit-decoder-boundary-2026-08-15.md) 的
\(h_m(r)=r_1\)。为避免把输出线的编码成本藏进门数，本文使用完整 gate-list 语法：
每个门记录两个 source addresses 和一个有限 basis opcode，另有 \(m\) 个 output-wire
selectors。令 \(n=2^m\)，并对固定的有理数 \(\beta\in(0,1)\) 定义

\[
t_\beta(m)=\max\!\left\{1,\left\lfloor\frac{n^\beta}{m+1}\right\rfloor\right\}.
\tag{1}
\]

定义一个全长度语言（非二次幂长度一律拒绝）

\[
L_\beta
=\bigcup_{m\ge 1}
\left\{y\in\{0,1\}^{2^m}:y\in\mathsf{Orb}_{m,t_\beta(m)}(h)\right\}.
\tag{2}
\]

这里 \(\beta\) 先取固定有理数；把这族扩展到所有实数 \(\beta\) 不是本 note 的隐含步骤。

## \(L_\beta\in\mathrm{NP}\)

给定 \(y\in\{0,1\}^{n}\)，证书是一个至多 \(t_\beta(m)\) 门的 \(m\)-输入、\(m\)-输出
电路 \(A\)。验证器执行：

1. 对每个 \(r\in\{0,1\}^{m}\) 计算 \(A(r)\)，检查所有 \(n\) 个输出彼此不同；由于域和值域同为
   \(n\) 个点，这等价于 \(A\) 为置换。
2. 对每个 \(r\) 检查
   \[
   y_{A(r)}=h_m(r)=r_1.
   \tag{3}
   \]

两步只需 \(n\) 次电路求值、一个显式的 collision check 和 \(O(nm)\) 次查表，时间为

\[
\operatorname{poly}(n,t_\beta(m),m).
\]

式 (3) 在 \(A\) 为置换时恰好等价于 \(y=h_m\circ A^{-1}\)。因此 \(L_\beta\in\mathrm{NP}\)。
证书长度是 \(O(t_\beta(m)\log(m+t_\beta(m))+m\log(m+t_\beta(m)))=\operatorname{poly}(n)\)。

## 稀疏上界

完整 gate-list 的语法计数给出

\[
\#\mathsf{PermCirc}_{m,t}
\le
2^{O((t+m)\log(m+t+2))}.
\tag{4}
\]

对 \(t=t_\beta(m)\)，有

\[
t\log(m+t+2)=O(n^\beta),
\qquad
m\log(m+t+2)=O(m^2)=o(n^\beta),
\tag{5}
\]

对充分大的 \(m\) 成立。于是

\[
\left|L_\beta\cap\{0,1\}^{n}\right|\le 2^{O(n^\beta)}\qquad(n=2^m),
\tag{6}
\]

而非二次幂长度的截面为空。故 \(L_\beta\) 是 \(2^{O(n^\beta)}\)-sparse 的 NP 语言，且这个
结论没有使用任何 inverse circuit 上界。

## 两个无条件端点

平衡 truth table 的数目满足

\[
\binom{n}{n/2}\ge \frac{2^n}{n+1}.
\tag{7}
\]

因此，若某个 \(t\) 使 \(\mathsf{Orb}_{m,t}(h)\) 已经等于全部平衡表，则 (4) 强制

\[
(t+m)\log(m+t+2)=\Omega(n).
\tag{8}
\]

在 \(m\le t\le n^{O(1)}\) 的区间，这给出

\[
t=\Omega\!\left(\frac{n}{\log n}\right).
\tag{9}
\]

换言之，\(t=o(n/\log n)\) 时一定还有平衡表不在该轨道；这只是计数分离，不是
range-membership lower bound。

反向地，任意平衡表 \(y\) 都能通过一个置换 \(A_y\) 进入轨道：按字典序把
\(h_m^{-1}(0),h_m^{-1}(1)\) 分别双射到 \(y^{-1}(0),y^{-1}(1)\)。先共享计算全部 \(n\)
个 minterm 指示器，再对每个输出 bit 对相应指示器做 fan-in-2 OR，得到

\[
|A_y|=O(nm)=O(n\log n).
\tag{10}
\]

所以 \(t=O(n\log n)\) 时轨道退化为全部平衡表，成员关系只需计数 1 的个数。

## 已知 hardness-magnification 接口

Chen--Jin--Williams 的 *Hardness Magnification for all Sparse NP Languages*（FOCS 2019，
ResearchLibrary 中的 williams2019hardness/williams2019hardness.pdf，Theorem 1.1）给出如下
接口：若存在固定 \(\varepsilon>0\) 的一族 \(L_\beta\)（其 theorem 量词是
\(\beta\in(0,1)\)），每个 \(L_\beta\) 都是 \(2^{n^\beta}\)-sparse 的 NP 语言且没有
\(n^{1+\varepsilon}\)-size circuits，则可推出

\[
\mathrm{NP}\not\subseteq\mathrm{SIZE}[n^k]\quad\text{对所有固定 }k.
\tag{11}
\]

把 (2) 作为候选族时，对每个固定有理数 \(\beta\)，(6) 验证了该定理所需的“稀疏 + NP”两项
局部前提（常数和 \(O(\cdot)\) 可由把 \(\beta\) 换成任意稍大的指数吸收）。但要真正调用
Theorem 1.1，还必须把这些局部语言组织成其要求的、对所有 \(\beta\in(0,1)\) 都统一可定义的 family；
这里不把“有理数 \(\beta\)”偷偷升级成任意实数参数。真正尚未证明的是定理接口的硬部分：

\[
\widetilde L_\gamma:=L_{\gamma/2},
\qquad
\left|\widetilde L_\gamma\cap\{0,1\}^{n}\right|
\le 2^{O(n^{\gamma/2})}\le 2^{n^\gamma}
\quad(\text{充分大 }n),
\tag{12a}
\]

以及

\[
\exists\varepsilon>0\ \forall\gamma\in(0,1):\quad
\widetilde L_\gamma\notin\mathrm{SIZE}[n^{1+\varepsilon}].
\tag{12b}
\]

两式合称为 (12a)--(12b)，共同表达同一条 sufficient target。
还必须额外证明 \(\widetilde L_\gamma\) 对 theorem 要求的所有参数统一可定义；当前 note 只直接
构造了有理数参数。note 098 的 hard member 观察不能升级为 range-membership lower bound；它只把
缺口精确地放到了这个重标记族的弱下界上。若 (12b) 成立，(11) 会给出
\(\mathrm{NP}\not\subseteq\mathrm{P/poly}\)，从而 \(P\ne NP\)；但 (12b) 本身仍是未解决的
一般电路下界问题。

## 一个非空的语义稀疏区间与 Mahaney 边界

完整 output-selector 计数在 \(m\log m\) 项上过粗；对很小的 \(t\)，置换性的结构还能给出
非空的语义稀疏区间。设 \(A\) 是 size-\(t\) 的 fan-in-2 置换电路，并令 \(K\) 为其
非直接 output wires 的坐标集合，\(k=|K|\)。由于置换不能有重复 output functions，直接
selectors 两两不同，故遗漏的输入变量集合 \(J\) 满足 \(|J|=k\le t\)。

每个 gate wire 至多依赖 \(2^t\) 个原始输入变量；令 \(S\) 为 \(K\) 中 gate wires 的支持并集，
则 \(|S|\le k2^t\)。固定所有非 \(J\) 变量后，\(K\) 个 gate outputs 对 \(J\) 的映射必须是
\(k\)-bit 双射，否则整个 \(A\) 不注入。因此 \(f=h_m\circ A^{-1}\)：

- 若 \(r_1\notin J\)，\(f\) 是一个 projection；
- 若 \(r_1\in J\)，由 gate outputs 与直接输出的 \(S\setminus J\) 坐标可恢复 \(r_1\)，所以
  \(f\) 只依赖至多
  \[
  D=t(2^t+1)
  \tag{13}
  \]
  个输入坐标。

于是有自足的函数计数上界

\[
\left|\mathsf{Orb}_{m,t}(h)\right|
\le
\sum_{d\le \min\{D,m\}}\binom md\,2^{2^d}.
\tag{14}
\]

若
\[
t(2^t+1)\le \log_2 m+O(1),
\tag{15}
\]
则 \(\log|\mathsf{Orb}_{m,t}(h)|=O(m)\)，即每个长度
\(n=2^m\) 至多 \(n^{O(1)}\) 个 yes-instances。结合前面的 NP verifier，这给出一个真正非空的
polynomially sparse NP 参数区间。Mahaney 的 sparse-NP-complete theorem（FOCS 1980；JCSS
1982）说明：若该区间得到 polynomial-time many-one 的 NP-hardness，则 \(P=NP\)。

上述 support argument 使用标准 fan-in-2、直接 output selector 语义；它不是一般 \(t\) 的
range-membership lower bound，也不能代替 (12b)。特别是当 \(t\) 增大到
\(\Omega(n/\log n)\) 以后，(14) 不再提供稀疏性，而计数/全平衡端点重新主导。

## 路线裁决

本 note 产生的是一个可复用的参数化接口，而非分离定理：

\[
\boxed{
\text{固定标签置换轨道}\Rightarrow
\text{显式 NP 验证器}+
2^{O(n^\beta)}\text{-稀疏族};\quad
\text{(12b) 仍 unknown}.
}
\]

它排除了“只凭 hard inverse member 就得到 range hardness”的跳步，同时把下一项真正有数学
意义的目标限定为 orbit-MCSP 族的 \(n^{1+\varepsilon}\) 下界；若这条路线不能提供 (12b)，应回到
note 089 的 decoder 设计，而不是继续增加标签或参数格。

## 文献边界

本 note 的 action 作用在 truth-table 的 \(n=2^m\) 个 row addresses 上。Luks 的 dense
truth-table structural-equivalence 算法以及 Cristiano 的 function-isomorphism 分类，作用
的是 \(m\) 个输入变量的重命名/语义等价；它们不能直接给出本文 row-space 上
size-\(t\) permutation 的 membership 算法或下界。Chen--Jiang 的 reversible matching 结果是
black-box、promise、witness-search/query 模型，也不能替代本文的 succinct truth-table
decision problem。针对本文这种 syntax-bounded row-space orbit，当前检索未找到直接的
membership lower bound；因此 (12b) 仍只能标为 unknown。

## 来源与证据边界

- Lijie Chen, Ce Jin, Ryan Williams, *Hardness Magnification for all Sparse NP Languages*,
  FOCS 2019, DOI 10.1109/FOCS.2019.00077；本项目保存的全文与 Theorem 1.1。
- Stephen R. Mahaney, *Sparse Complete Sets for NP: Solution of a Conjecture of Berman and
  Hartmanis*, JCSS 25 (1982)；此处只使用 sparse NP-complete \(\Rightarrow P=NP\) 的经典结论。
- Luks 1999、Cristiano 2026 与 Chen--Jiang 2024 仅用于区分相邻 action/encoding；没有被用作
  本文 (12b) 的证据。

原文核验日期：2026-08-15。
