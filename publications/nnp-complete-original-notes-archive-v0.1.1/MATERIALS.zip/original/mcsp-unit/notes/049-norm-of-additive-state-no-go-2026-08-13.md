> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 范数化 additive 状态的统一平均 no-go（2026-08-13）

## 状态族

令 \(C\) 为 cell 宇宙，\(|C|=m\)。给每个 cell 一个向量 \(v_c\)（可取实向量、Hilbert 向量、Fourier 特征、通信向量等），定义

\[
S(R)=\sum_{c\in R}v_c,\qquad
K(R)=\|S(R)\|-\frac{\|S(C)\|}{m}|R|.
\tag{1}
\]

这里 \(\|\cdot\|\) 是任意范数。该形式包括把若干 cell-additive 统计量先做 \(\ell_1,\ell_2\)、核范数或一般 convex aggregation 的常见“全局状态”。

## QA 递归性

若 \(R=V\dot\cup W\)，则三角不等式给出

\[
\|S(R)\|=\|S(V)+S(W)\|
\le \|S(V)\|+\|S(W)\|.
\]

线性基线在二分下严格可加，故

\[
K(V)+K(W)\ge K(R),\qquad K(C)=0.
\tag{2}
\]

## 平均非负引理

若叶分布 \(\mathscr D\) 对每个 cell 均有包含概率 \(q\)，则

\[
\mathbb E S(R)=\sum_c \Pr[c\in R]v_c=q S(C).
\]

范数的 Jensen 不等式因此给出

\[
\mathbb E\|S(R)\|\ge\|\mathbb E S(R)\|
=q\|S(C)\|.
\]

另一方面，

\[
\mathbb E\!\left[\frac{\|S(C)\|}{m}|R|\right]
=\frac{\|S(C)\|}{m}\,qm
=q\|S(C)\|.
\]

故

\[
\boxed{\mathbb E_{\mathscr D}K(R)\ge0.}
\tag{3}
\]

## 后果

所有非负加权的范数化 additive 状态、Fourier 向量范数、核范数/嵌入范数状态都无法在均匀 cell-inclusion 的 affine 叶分布下提供负平均补偿。将其接入

\[
\sum_{c\in R}\phi_c+K(R)\le1
\]

的 QA-LP，并对叶取平均，仍得到

\[
q\sum_c\phi_c\le1.
\]

因此仅把 additive 统计量“向量化再取凸范数”仍是静态路线；它的平均上界由 Jensen 强制，不依赖 witness 的具体几何。

## 边界

要逃逸，必须至少使用非凸/非范数的联合状态，或让状态依赖叶的语义（例如投影关系的最小公式复杂度、全局协议树的可达状态），使 \(\mathbb E K\ge0\) 的 Jensen 机制不再适用。单纯增加 Fourier 频率、提高张量阶数或把多个秩坐标拼接后取 \(\ell_p\) 范数不会改变结论。

