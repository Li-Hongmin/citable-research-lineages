> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# RW Closure 下的确定性重编译：round 项可消失而 width 项保留（2026-08-18）

## 本轮判定

C363 对 published RW recurrence 的 \(r_i=O(n_i)\) 记账是正确的，但它不能被解释成
\(P=NP\) 下所有 Closure attachment 都必须支付 object-scale round。若假设
\(P=NP\)，可以把固定的 SAT-oracle 机器用一个多项式时间 SAT decider \(A\) 重编译成
确定性机器；其 computation history 没有 NP-query rounds。这个重编译最多消掉
prefix/round 项，不能消掉 Theorem 4.1 的 child width \(k\)、最终 Merlin
gate-list witness 或 stable solver branch。

因此，RW Gate-I 的不可约尺度应写成 **width/solver trichotomy**，而不是
“published \(r_i\) 本身不可压缩”。

## 确定性重编译引理

设 \(f:\{0,1\}^n\to\{0,1\}^{T}\) 是由一个固定的
\(\mathrm{TIME}[\operatorname{poly}(T)]^{\mathrm{NP}}\) 机器 \(M\) 计算的多输出函数。
假设 \(P=NP\)，并固定一个运行时间 \(m^{d_A}\) 的 SAT decider \(A\)。把 \(M\) 中的每个
SAT query 直接交给 \(A\)，得到确定性机器 \(M_A\)。若 \(M_A\) 的运行时间至多
\(T^\kappa\)，令

\[
  \widehat T:=\max\{T^\kappa,2^n\}
\]

并定义 padded function

\[
  \widehat f(x):=f(x)\,0^{\widehat T-T}.
\]

则 \(\widehat f\) 可用 Theorem 4.1 的参数

\[
  \widehat t=\widehat T,\qquad r=0,\qquad s=0
\]

表示；其 encoded history 的 prefix 长度

\[
  r'=O(r\log(\widehat T+1))=0.
\tag{371.1}
\]

若 \(\widehat f(x)\) 的 first \(T\) bits 是被 forcing 的 hard word，则 padding 只增加
\(O(\log\widehat T)\) 的地址固定开销，硬度下界仍转移到 \(\widehat f(x)\)。

### 证明

在 \(P=NP\) 下，\(A\) 对每个 query 给出正确答案；把 \(M\) 的有限控制和 \(A\)
串接即可得到 \(M_A\)，其总时间为 \(T^\kappa\)。Theorem 4.1 的多输出长度参数
要求同时支配机器时间和输出长度，故用 \(\widehat T\) 补零后，\(M_A\) 属于
\(\mathrm{TIME}[\widehat T]^{\mathrm{NP}}[r=0,s=0]\)（把确定性步骤视为零个
NP-query round）。Lemma 3.2 的 history 没有 query-count 或 NP-witness 字段，
所以 Theorem 4.1 的 \(r'\) 为零。一个 \(\widehat f\) 的地址电路限制到前 \(T\) 个
地址即可得到 \(f\) 的地址电路，故 padding 不会消除 forcing 下界。证毕。

## 对 RW failure branch 的精确后果

在这个重编译后的接口上，假设固定格式 smart prMA query 在 \(P=NP\) 下可在总输入
长度 \(L=\operatorname{poly}(k,\log\widehat T)\) 内确定化。若
\(\operatorname{Solve}_{\widehat f}(x,G_k)\) failure，则 Theorem 4.1 给出

\[
  \operatorname{CC}(\widehat f(x))
  \le
  \operatorname{poly}(k,\log\widehat T).
\tag{371.2}
\]

这里没有 \(r\) 项，但最终 Merlin circuit witness 仍满足

\[
  k'=O(k^4\log(\widehat T+2)).
\tag{371.3}
\]

若 forcing threshold 为 \(S\)，则 failure branch 必须支付

\[
  k=\Omega\!\left(S^{\Omega(1)}\right)
\tag{371.4}
\]

（具体指数由 Theorem 4.1 的 query/determinization 多项式决定）。

对 stable RW hard table \(B_i\)，

\[
  T_i=n_{i+1}=n_i^C,\qquad
  \operatorname{CC}(B_i)=\Omega\!\left(\frac{n_i}{\log(n_i+2)}\right).
\]

若 \(k_i=(\log n_i)^{O(1)}\)，(371.2) 与 forcing 下界矛盾，所以 failure branch
不能发生；Solve 必须返回一个新的 AVOID outsider。若把 \(k_i\) 取到
\(n_i^\varepsilon\) 且 \(\varepsilon\) 小于由 (371.2) 决定的阈值，结论仍相同。
只有把 \(k_i\) 提升到 object-scale，failure/reconstruction 才能保留，而此时
Reconf 仍不是 \(\operatorname{poly}(\log n_i)\) 的 address evaluator。

因此在 \(P=NP\) 下，重编译后的 Gate-I 至少分为：

1. **address-scale width：** failure 被 hard-table forcing 排除，只有 solver/AVOID
   outsider 分支；
2. **object-scale width：** failure 可重构，但只得到 object-scale evaluator；
3. **新 semantic consequence：** 必须证明 solver 成功分支本身携带一个
   address-scale、同一对象的闭合机制。

## 与现有结果的关系

* C363 的 published recurrence 仍给出 \(r_i=O(n_i)\) 和 \(k_i=n_i^C\)，所以其
  source-level scale audit 不变；本 note 只说明不能把 \(r_i\) 当作对 \(P=NP\)
  重编译后的 universal lower bound。
* C370 的共同 prefix 在这个重编译中可以退化为零长度；其
  “共同完备 witness 不等于共同 selected response”量词分离仍然存在。
* note 107 已构造了一个具体的 \(r=0\) systematic-prefix history；371 的新点是把
  \(P=NP\) 下对任意 published SAT-oracle computation 的 deterministic recompilation
  和 width/solver trichotomy 接到 Closure 参数上。
* 这不是 \(P\ne NP\) 证明：address-scale width 只迫使 Solve 成功，Theorem 4.1
  没有说明所得 outsider 能反推出原 hard word。

## 证据边界

* Ren--Williams Theorem 4.1 的输入类、\(r'\) 与 query-width 见
  units/thr2-lower-bounds/scratch/extracted-workspace/lib/ren2026near/fulltext.md
  第 14--18 页。
* Theorem 4.3 的 stable recurrence 与 \(r_i=O(n_i)\) 见同一抽取第 16--19 页；
  C363 的 published-scale 证明见
  [note 363](363-rw-reconstruction-width-round-conservation-2026-08-18.md)。
* \(r=0\) systematic-prefix 的 source-specific 实例见
  [note 107](107-rw-systematic-prefix-forces-tree-outsider-2026-08-15.md)。
* 371 是 Closure 参数的重编译/分支修正，不是一般 round lower bound、RLDC
  impossibility 或 \(P\ne NP\) 定理。
