> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Positive-radius completion barrier for high-arity folding (2026-08-19)

## 本轮改变的判断

C475 的 completion 条件不是一个抽象的 family 假设：只要一个 dense raw fold 在
同一个 honest raw vector 周围的正半径邻域上仍要求输出 single-valued 的精确符号，
邻域本身就提供每个坐标的局部 completion。因此高元 folding 不能同时保持
constant-query 与这种正半径、非 bottom 的 raw evaluation 语义。

这把 C475 的 singleton caveat 精确分成两类：

* 固定 singleton 的零查询反例只适用于没有任何可实现的局部 completion；
* 一旦 correctness domain 含有半径至少一格的邻域，singleton 也必须支付全部 dense
  fold arity。若允许 completion 触发 bottom/拒答，或 raw 输入受非局部编码约束，
  则已经离开本定理，分别进入 bottom 或新的 global-relation 分支。

## 设置

令 \(F\) 为有限域，令

\[
  L_\alpha(y)=\sum_{i=1}^{b}\lambda_i(\alpha)y_i,
  \qquad \lambda_i(\alpha)\ne0,
  \tag{476.1}
\]

其中 \(y\in F^b\)。对 \(y^\star\in F^b\) 及整数 \(r\ge0\)，记

\[
  \mathcal B_F(y^\star,r)
  :=\{y\in F^b:\operatorname{wt}(y-y^\star)\le r\}.
  \tag{476.2}
\]

raw-query tree 只能读取输入 \(y\) 的坐标，并输出 \(F\) 中的一个符号；查询次数按
实际读取的 raw coordinates 计价。错误概率是对 tree randomness 的概率，且要求对
correctness domain 中的每个输入逐点成立。

## 定理 476.1（正半径 dense-fold completion barrier）

令 \(\mathcal Y\subseteq F^b\) 包含 \(y^\star\)，并且

\[
  \mathcal B_F(y^\star,1)\subseteq\mathcal Y.
  \tag{476.3}
\]

若 randomized adaptive raw-query tree \(D\) 在每个 \(y\in\mathcal Y\) 上以错误概率至多
\(\varepsilon<1/2\) 输出 \(L_\alpha(y)\)，则在 honest input \(y^\star\) 上

\[
  \Pr[D\text{ queries coordinate }k\mid y^\star]
  \ge 1-2\varepsilon
  \qquad(k\in[b]),
  \tag{476.4}
\]

从而

\[
  \mathbb E[Q_D(y^\star)]\ge b(1-2\varepsilon).
  \tag{476.5}
\]

若 \(D\) deterministic 且 exact，则 \(Q_D(y^\star)\ge b\)。更一般地，若
\(\mathcal Y\) 只在 \(y^\star\) 处提供 \(d\) 个坐标 completion，则右侧的 \(b\) 可替换为
\(d\)。

### 证明

固定 \(k\in[b]\) 及任意 \(\delta\in F\setminus\{0\}\)。由 (476.3)，

\[
  y^{(k)}:=y^\star+\delta e_k\in\mathcal Y.
\]

两次运行使用同一 random tape。若在 \(y^\star\) 的运行中没有查询 \(k\)，则在首次
查询 \(k\) 以前两个 transcript 完全相同；归纳可知第二次运行也不会在此之前查询
\(k\)，并且最终输出相同。另一方面，

\[
  L_\alpha(y^{(k)})-L_\alpha(y^\star)
  =\lambda_k(\alpha)\delta\ne0.
\]

所以在“不查询 \(k\)”事件上至少有一个输入出错。两输入的逐点错误概率都至多
\(\varepsilon\)，故该事件概率至多 \(2\varepsilon\)，得到 (476.4)。对 \(k\) 求和即得
(476.5)；\(\varepsilon=0\) 时得到 deterministic exact 情形。若只有 \(d\) 个可实现
completion，完全相同的耦合只对这 \(d\) 个坐标成立。证毕。

## 推论 476.2（相对正半径已经足够）

若对某个固定 \(\rho>0\)，

\[
  \mathcal B_F(y^\star,\lfloor\rho b\rfloor)\subseteq\mathcal Y
  \qquad\text{且}\qquad b\ge1/\rho,
  \tag{476.6}
\]

则 (476.3) 成立，因而任何逐点错误小于 \(1/2\) 的 raw evaluator 在 \(y^\star\)
上都必须有

\[
  \mathbb E[Q_D(y^\star)]\ge b(1-2\varepsilon).
  \tag{476.7}
\]

因此，正半径本身并不需要覆盖整块 \(F^b\)；一格的局部 completion 已足够触发
全 arity 下界。

## 推论 476.3（多层 arity--round tradeoff）

设 \(R\) 个 raw-fold 子调用的 arity 为 \(b_1,\ldots,b_R\)。若第 \(r\) 个调用的
correctness domain 在 honest raw vector 处包含所有一坐标 completions，逐点错误至多
\(\varepsilon_r<1/2\)，并且各层的 raw queries 分别计价，则

\[
  \mathbb E[Q]
  \ge
  \sum_{r=1}^{R}(1-2\varepsilon_r)b_r.
  \tag{476.8}
\]

在共同错误上界 \(\varepsilon_r\le\varepsilon\) 且
\(\prod_rb_r\ge T\) 时，

\[
  \mathbb E[Q]
  \ge (1-2\varepsilon)R\,T^{1/R}.
  \tag{476.9}
\]

所以常数轮仍支付 \(T^{\Omega(1)}\)；若 \(T=2^{\Theta(m)}\) 而
\(\mathbb E[Q]=m^{O(1)}\)，则 \(R=\Omega(m/\log m)\)。这比 C475 更直接地覆盖了
“只在一个 honest proof 的正半径邻域上工作”的 singleton 语义。

证明是定理 476.1 在每一层的求和与 AM--GM；没有把不同层的 raw coordinates
误算为可免费复用的同一查询。

## 定理 476.4（bottom-aware completion bound）

允许 raw-query tree \(D\) 的输出为 \(F\cup\{\bot\}\)。对 \(y\in\mathcal Y\)，定义

\[
  \operatorname{err}(y)
  :=\Pr[D(y)\in F\setminus\{L_\alpha(y)\}],
  \qquad
  \operatorname{bot}(y):=\Pr[D(y)=\bot].
  \tag{476.10}
\]

设 \(\mathcal B_F(y^\star,1)\subseteq\mathcal Y\)，并且

\[
  \operatorname{err}(y)\le\beta\quad(y\in\mathcal Y),
  \qquad
  1-\operatorname{bot}(y^\star)\ge\nu.
  \tag{476.11}
\]

则对每个 \(k\in[b]\)，在 \(y^\star\) 上

\[
  \Pr[D\text{ queries }k]\ge
  \max\{0,\nu-2\beta\}.
  \tag{476.12}
\]

因而在 \(R\) 个分别计价的 fold layers 中，若第 \(r\) 层满足参数
\((\nu_r,\beta_r)\)，则

\[
  \mathbb E Q
  \ge
  \sum_{r=1}^{R}\max\{0,\nu_r-2\beta_r\}\,b_r.
  \tag{476.13}
\]

特别地，若所有层都有 \(\nu_r-2\beta_r\ge\gamma>0\) 且
\(\prod_rb_r\ge T\)，则

\[
  \mathbb E Q\ge\gamma R\,T^{1/R}.
  \tag{476.14}
\]

### 证明

固定 \(k\)，并将 \(y^\star\) 与 \(y^{(k)}=y^\star+\delta e_k\) 用同一 random tape
耦合。记 \(N_k\) 为在 \(y^\star\) 的运行中不查询 \(k\) 的事件。与定理 476.1
相同，\(N_k\) 上两次输出相同。若共同输出属于 \(F\)，由于
\(L_\alpha(y^\star)\ne L_\alpha(y^{(k)})\)，至少一个输入发生错误符号输出；若共同
输出为 \(\bot\)，则 \(D(y^\star)=\bot\)。因此

\[
  N_k\subseteq
  \{D(y^\star)\in F\setminus\{L_\alpha(y^\star)\}\}
  \cup
  \{D(y^{(k)})\in F\setminus\{L_\alpha(y^{(k)})\}\}
  \cup
  \{D(y^\star)=\bot\}.
\]

由 (476.11)，\(\Pr[N_k]\le2\beta+(1-\nu)\)，即 (476.12)。逐坐标、逐层求和得到
(476.13)，再用 AM--GM 得 (476.14)。证毕。

## 对 RW/ACRR 高元 folding 候选的精确后果

考虑一个声称使用同一 physical proof、在相对半径 \(\rho>0\) 的近 proof 上对每个
目标地址 single-valuedly 输出 dense fold symbol 的 batch-opening 接口。若其 raw
fold 输入具有以下 local realization 性质：对 honest raw vector 的任一坐标改变，
存在一个仍在 correctness domain 内的近 proof 实现该改变，则推论 476.2 立即给出
每个 arity-\(b\) fold 的 \(\Omega(b)\) raw-query payment。高元 folding 因而不能把
object-scale payload 压成 address-scale、非 bottom 的常数查询。

任何候选必须明确落入下列分支之一：

1. **Bottom/拒答：** 某些 local completions 不再要求输出符号；这正是 bottom 逃逸，
   但若 non-bottom mass 至少 \(\nu\)、wrong-symbol error 至多 \(\beta\)，
   定理 476.4 已强制每个 dense coordinate 支付 \(\nu-2\beta\) 的查询质量；
   只有 \(\nu\le2\beta\) 才能保持该 raw-fold 逃逸。
2. **窄 correctness domain：** physical proof 的正半径并不投影为 raw-fold 的局部
   completions；必须证明一个非局部 code constraint 或 cover/selector 机制，而不能
   把 C475 的 full-family 下界静默套入。
3. **非 raw-fold global relation：** 输出由 sum-check、commitment 或其他 joint
   relation 绑定；其 proof、support、binding 和 address evaluator 需按 C464、C473、
   C474 及相应新定理计价。
4. **Object-scale/unpriced oracle：** 直接把 raw table、sheet 或全局 memory 当作
   未计价输入；这不是 RW 的 address-scale Closure。

因此 singleton 量词不再是高元 folding 的免费正向出口：它只能避开 completion
barrier，不能同时保留正半径、single-valued、same-proof 的 raw evaluation 语义。

## 边界

本定理只处理 dense linear raw folds 的 exact/symbol-valued evaluation。它不证明：

* 一般 PCP、FRI/IOPP 或 polynomial-commitment 的下界；
* 仅要求 proximity acceptance、允许大量 bottom，或使用 computational binding 的
  协议不可能；
* raw inputs 由一个非局部编码约束，导致 physical Hamming completion 不可实现；
* \(P\ne NP\)。

最后一类 raw/nonlocal 分离正是尚未完成的 RW-specific global-relation 目标，而不是
本定理可以代替的 Closure Theorem。

## 来源

* [C475：high-arity folding quantifier and singleton batch-opening gate](475-rw-high-arity-folding-quantifier-and-batch-opening-gate-2026-08-19.md)。
* [C473：honest-path support forcing](473-rw-honest-path-support-and-exposed-history-pcpp-gate-2026-08-19.md)。
* [C474：coding-layer/address-scale Closure dichotomy](474-rw-coding-layer-address-scale-closure-dichotomy-2026-08-19.md)。
* [Paper 04 Proposition 1.90](../../rw-jk-succinct-reconstruction/papers/04-from-address-scale-smart-reconstruction-to-p-poly/paper.md)。
