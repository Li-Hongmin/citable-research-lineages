> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Optimal memoryless postprocessing frontier for no-resampling RLDC closure (2026-08-17)

## Contribution

Note 249 uses a rejection-fallback coin to turn a two-branch shared-proof
verifier into an adaptive relaxed LDC. The fallback there is sufficient but
not optimal within the natural memoryless postprocessing model. This note
gives the exact \(2/3\)-versus-\(1/3\) feasibility region, even if a
postprocessor is allowed to output the opposite bit.

The result is a sharp closure theorem for that model: outside the region,
no choice of two postprocessing coins can produce the Dall'Agnol--Gur--Lachish
relaxed-LDC promise; inside it, an explicit pair of coins does. Thus the
remaining no-resampling gap is not a tuning artifact of the particular
fallback in note 249, although stronger postprocessors or a different code
reduction remain outside the theorem.

## Model

Fix a claimed inline bit \(b\). The branch verifier returns an accept bit
\(a\in\{0,1\}\). An arbitrary memoryless postprocessor receives \((b,a)\)
and outputs one of \(0,1,\bot\). It may output either bit, and its rule may
depend on \(b\), but it sees no proof transcript beyond the accept bit.
For a fixed \(b\), write \(s_b\) for the probability of outputting \(b\)
after acceptance and \(t_b\) for the probability of outputting \(b\) after
rejection. The probability of outputting the claimed bit at branch
acceptance rate \(p\) is then

\[
  f_b(p)=p s_b+(1-p)t_b.
\tag{250.0}
\]

Let \(\alpha\) be a lower bound on acceptance for the correct branch and
\(\beta\) an upper bound on acceptance for a wrong inline claim. A feasible
postprocessor must therefore, for each fixed claimed bit \(b\) and with
\(s=s_b,t=t_b\), satisfy

\[
  \alpha s+(1-\alpha)t\ge\frac23,
  \qquad
  \beta s+(1-\beta)t\le\frac13.
\tag{250.1}
\]

Any feasible postprocessor must have \(f_b(p)\ge2/3\) for every
\(p\ge\alpha\) when \(b\) is correct, and \(f_b(p)\le1/3\) for every
\(p\le\beta\) when \(b\) is wrong. These requirements force
\(s_b>t_b\), so the endpoint bounds in (250.1) are valid. Conversely,
setting all opposite-bit output probabilities to zero realizes any feasible
\((s,t)\) in (250.1). Thus allowing opposite-bit outputs cannot enlarge the
frontier: it does not change the necessary claimed-bit channel, and the
extremal claimed-bit channel already has a valid realization with no
opposite-bit output.

## Exact frontier theorem

### Theorem 250.1 (optimal arbitrary memoryless frontier)

Assume \(0\le\beta<\alpha\le1\). There exists an arbitrary memoryless
postprocessor satisfying the \(2/3\)-completeness and \(1/3\)-wrong-output
relaxed-decoding requirements if and only if

\[
  \alpha-\beta\ge\frac13,
  \qquad
  \alpha\ge2\beta,
  \qquad
  2\alpha-\beta\ge1.
\tag{250.2}
\]

When (250.2) holds, an extremal choice is

\[
  s=\frac{\alpha-2\beta+1}{3(\alpha-\beta)},
  \qquad
  t=\frac{\alpha-2\beta}{3(\alpha-\beta)}.
\tag{250.3}
\]

For this choice both inequalities in (250.1) hold with equality.

### Proof

For either claimed bit \(b\), put \(d=s_b-t_b\). Feasibility implies

\[
  \frac13\le f_b(\alpha)-f_b(\beta)
  =(\alpha-\beta)d.
\tag{250.4}
\]

Since \(d\le1\), this gives \(\alpha-\beta\ge1/3\). Also
\(d\ge1/(3(\alpha-\beta))\). The wrong-branch inequality and \(t\ge0\)
give \(\beta d\le1/3\), hence \(\alpha\ge2\beta\). The correct-branch
inequality and \(s=t+d\le1\) give

\[
  \frac23\le t+\alpha d\le1-(1-\alpha)d,
\]

so \((1-\alpha)d\le1/3\), hence \(2\alpha-\beta\ge1\).

Conversely, set \(d=1/(3(\alpha-\beta))\) and choose \(t\) as in (250.3),
with \(s=t+d\), and never output the opposite bit. The three conditions in
(250.2) imply respectively \(d\le1\), \(t\ge0\), and \(s\le1\). Direct
substitution gives

\[
  \alpha s+(1-\alpha)t=\frac23,
  \qquad
  \beta s+(1-\beta)t=\frac13.
\]

This proves the theorem. \(\square\)

## Consequence for shared-proof coordinate robustness

Under the hypotheses of note 249, replace its particular fallback by the
coins (250.3). Binary recoding of proof symbols still gives an adaptive
relaxed LDC with \(1+\lceil\log_2 A\rceil r\) queries and constant radius,
whenever (250.2) holds. Therefore the Dall'Agnol--Gur--Lachish lower bound
still rules out a \(k\,\operatorname{polylog}k\) common proof for every fixed
alphabet \(A\), fixed locality \(r\), and fixed positive target-relative
radius.

This strictly enlarges the sufficient region of note 249. For example,

\[
  (\alpha,\beta)=(4/5,2/5)
\]

is covered by (250.2), with \(s=5/6\) and \(t=0\), although
\(\beta>1/3\). At perfect completeness \(\alpha=1\), the static frontier
reaches \(\beta\le1/2\); the stronger perfect-completeness closure from the
nonadaptive RLDC route remains separate and can cover a larger range.

## Boundary and scope

The theorem is exact for arbitrary memoryless postprocessing of the single
accept/reject bit, including claim-flipping outputs. It does not rule out
postprocessors that use additional verifier transcript information, fresh
resampling, or an outer robust PCP/LDC transformation. Coordinate-dependent
memoryless rules do not help when the same uniform \((\alpha,\beta)\) bounds
are required, since the argument applies separately to every coordinate.
Consequently
the complement of (250.2) is a genuine target for a higher-level theorem, not
an impossibility result for simultaneous coordinate-robust PCPs in general.

The proof is elementary, but the frontier is useful because it removes a
parameter-tuning ambiguity from the no-resampling branch and isolates exactly
which improvement must come from a new coding or PCP mechanism.

## Sources

* M. Dall'Agnol, T. Gur, and O. Lachish, *A Structural Theorem for Local
  Algorithms with Applications to Coding, Testing, and Privacy*, Corollary
  7.9, <https://eccc.weizmann.ac.il/report/2020/154/>.
* [No-resampling high-confidence closure](249-no-resampling-high-confidence-rldc-closure-2026-08-17.md).
