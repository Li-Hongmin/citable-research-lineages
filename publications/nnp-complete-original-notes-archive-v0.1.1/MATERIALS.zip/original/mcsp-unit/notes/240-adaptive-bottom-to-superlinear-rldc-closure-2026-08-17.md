> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Adaptive bottom-to-superlinear RLDC closure for every fixed locality (2026-08-17)

## Contribution

The one-branch message-inline compiler gives a stronger conclusion than the
small-soundness route. If the branch verifier has any fixed locality \(r\),
then its adaptive decision tree can be exposed as a constant-size
non-adaptive query set. The resulting binary weak RLDC has constant success
rate whenever the target-relative wrong-branch error is any fixed
\(\beta<1\), not only when \(\beta\) is exponentially small.

The arbitrary-code, non-adaptive RLDC lower bound of Goldberg--Gur--Saraogi
then rules out a near-linear common proof for every fixed \(r\). For \(r=1\),
the exponential two-query theorem remains stronger when \(\beta<1/2\) (note
239); the present theorem covers the full constant-error interval
\(\beta<1\) at a superlinear scale.

## Theorem

Let

\[
  \Pi:\{0,1\}^{k}\longrightarrow\{0,1\}^{P}
\]

be a binary proof map. Write \(d_H\) for absolute Hamming distance. For every
\(i\in[k]\) and \(b\in\{0,1\}\), let
\(V_{i,b}\) be a randomized, possibly adaptive verifier making at most \(r\)
queries to the proof. Write \(p_{i,b}(z)\) for its acceptance probability.

Assume constants \(0<\rho<1\) and \(0\le\beta<1\), and suppose:

1. **Perfect correct-branch completeness**
   \[
     p_{i,m_i}(\Pi(m))=1
     \qquad(m\in\{0,1\}^{k},\ i\in[k]);
   \tag{240.1}
   \]

2. **Target-relative wrong-branch soundness**
   \[
  d_H(z,\Pi(m))\le\rho P
     \Longrightarrow
     p_{i,1-m_i}(z)\le\beta
   \tag{240.2}
   \]
   for every \(m,i,z\).

Set

\[
  \sigma:=1-\beta,\qquad Q_r:=2^{r+1}-1,\qquad
  a_r:=\left\lceil\frac{Q_r}{\sigma}\right\rceil .
\tag{240.3}
\]

Then, for all sufficiently large \(k\), the inline length \(N:=k+P\)
satisfies

\[
  N\ge
  \left(\frac{k}{C_{\rho,r,\beta}\log^2 k}\right)^{1+1/a_r}
  =\Omega_{\rho,r,\beta}\!\left(
    \frac{k^{1+1/a_r}}{\log^{\,2(1+1/a_r)}k}
  \right).
\tag{240.4}
\]

In particular, for every fixed \(r,\rho,\beta\) with \(\beta<1\), no
\(N=k\,\operatorname{polylog} k\) common-proof construction can satisfy
(240.1)--(240.2).

## Proof

### 1. Distance and a constant inline radius

If \(m\ne m'\) and
\(d_H(\Pi(m),\Pi(m'))\le\rho P\), choose \(i\) with
\(m_i\ne m'_i\). Applying (240.2) to target \(m'\) and
\(z=\Pi(m)\), while using (240.1) for \(m\), gives \(1\le\beta\), a
contradiction. Hence the proof image has relative distance greater than
\(\rho\).

The binary Singleton bound gives

\[
  k\le (1-\rho)P+1.
\]

For \(k\ge2\), this implies

\[
  \frac{P}{N}\ge\frac1{3-2\rho},\qquad N=k+P.
\tag{240.5}
\]

Define

\[
  \delta_0:=\frac{\rho}{2(3-2\rho)}.
\tag{240.6}
\]

If \(y\) is within relative distance \(\delta_0\) of
\(C(m):=m\Vert\Pi(m)\), then its proof suffix \(z\) is within
\(\rho P/2\) of \(\Pi(m)\), and therefore lies in the neighborhood covered by
(240.2).

### 2. Inline decoding with bottom

Given \(y\) and coordinate \(i\), the adaptive decoder first reads the inline
bit \(b=y_i\), runs \(V_{i,b}\) on the proof suffix \(z\), outputs \(b\) if
the branch accepts, and outputs \(\bot\) otherwise.

On \(C(m)\), the inline bit is \(m_i\), so (240.1) gives perfect completeness.
On a \(\delta_0\)-close word, if \(b=m_i\), the output is either the target
bit or \(\bot\). If \(b\ne m_i\), a wrong output is possible only when the
wrong branch accepts, which has probability at most \(\beta\) by (240.2).
Thus this is a binary weak adaptive RLDC with

\[
  (r+1,\delta_0,\sigma)=(r+1,\delta_0,1-\beta)
\tag{240.7}
\]

in the target-or-bottom convention.

### 3. Eliminating adaptivity without changing the decoder

Fix \(i\) and the random tape of the branch verifiers. For each
\(b\in\{0,1\}\), the \(r\)-query adaptive verifier is a binary decision tree
of depth at most \(r\), and hence contains at most \(2^r-1\) proof-query
nodes. A non-adaptive decoder queries the inline position \(i\) and the
union of all proof positions appearing in the two trees. The union has size
at most

\[
  1+2(2^r-1)=Q_r.
\tag{240.8}
\]

After receiving this fixed query set, it reads \(b=y_i\), simulates the
corresponding adaptive tree, and returns exactly the same value as the inline
decoder. Therefore perfect completeness, radius \(\delta_0\), and success
probability \(\sigma\) are unchanged. We have obtained a non-adaptive binary
\((Q_r,\delta_0,\sigma)\)-RLDC.

### 4. Apply the arbitrary non-adaptive RLDC lower bound

Goldberg--Gur--Saraogi prove that a non-adaptive
\((q,\delta,\sigma)\)-RLDC \(D:\{0,1\}^{k}\to\Sigma^n\), with
\(\delta>n^{-\sigma/(2q)}\), obeys

\[
  \frac{k}{\log^2 k}\le
  38q^4\sigma^{-2}\log^2|\Sigma|\;
  n^{\,1-\frac1{\lceil q/\sigma\rceil+1}}.
\tag{240.9}
\]

Here \(\Sigma=\{0,1\}\), \(q=Q_r\), \(n=N\), and \(\delta=\delta_0\). Since
\(\delta_0\) is a positive constant and \(N\ge k\), the radius condition holds
for all sufficiently large \(k\). Rearranging (240.9), with
\(a_r=\lceil Q_r/\sigma\rceil\), gives (240.4).
\(\square\)

## Closure consequence

This gives a single bottom barrier for the full fixed-query binary model:

* \(r=1\), \(\beta<1/2\): note 239 gives the stronger exponential bound;
* every fixed \(r\ge1\), every constant \(\beta<1\): note 240 gives a
  superlinear lower bound, excluding near-linear proof length;
* \(r\ge2\), \(\beta\) below the Cheng--Li--Mao threshold: note 238 gives
  the stronger \(LDC\)-based exponents.

Thus a binary near-linear RW/JK closure cannot preserve all of: a common
family-level proof map, perfect correct-branch completeness, positive
target-relative radius, fixed branch locality, and any constant wrong-branch
error strictly below \(1\). It must instead use a growing query budget,
non-binary symbols, a vanishing radius/gap, imperfect completeness, or a
different global interaction model.

## Scope

This is an application of the non-adaptive RLDC lower bound, not a new coding
lower-bound proof. The new closure step is the explicit adaptive-to-
nonadaptive decision-tree compilation for the two claim branches. The result
is for fixed \(r,\rho,\beta\); if \(r\) grows with \(k\), then
\(Q_r=2^{r+1}-1\) is no longer a constant and (240.4) must be recomputed.

## Source

* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for Relaxed
  Locally Decodable Codes via Robust Daisies*, arXiv:2511.21659, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.

* The stronger binary \(r=1,\beta<1/2\) result is in
  [note 239](239-one-query-bottom-fully-closed-by-weak-rldc-2026-08-17.md).
