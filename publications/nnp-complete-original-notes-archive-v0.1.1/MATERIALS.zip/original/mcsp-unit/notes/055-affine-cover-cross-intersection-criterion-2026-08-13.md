> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# affine 叶覆盖的 cross-intersection 判据（2026-08-13）

这是把全局 cover-number 义务转成可检验组合条件的最小引理。

## 判据

取 \(t\) 片 affine 最大叶

\[
L_j=\{x:r_j\cdot x+b_j=0\}
\times
\{y:r_j\cdot y+b_j=1\},
\qquad j\in[t].
\]

对 \(x\in X\)、\(y\in Y\) 定义两个模式集合

\[
S_x=\{j:r_j\cdot x+b_j=0\},
\qquad
T_y=\{j:r_j\cdot y+b_j=1\}.
\]

则

\[
(x,y)\in \bigcup_{j=1}^tL_j
\iff S_x\cap T_y\ne\varnothing.
\tag{1}
\]

因此

\[
X\times Y\subseteq\bigcup_{j=1}^tL_j
\iff
\bigl(\{S_x:x\in X\},\{T_y:y\in Y\}\bigr)
\text{ 是一对 cross-intersecting 家族}.
\tag{2}
\]

## 直接下界模板

若对每组至多 \(t\) 个 affine forms，都能找到

\[
x\in X,\ y\in Y
\quad\text{使}\quad
S_x\cap T_y=\varnothing,
\tag{3}
\]

则 \(t\) 片 affine 叶不可能覆盖 \(X\times Y\)，故
\(F_\oplus(X\times Y)>t\)。

最简单的证书是同时找到

\[
S_x=\varnothing
\quad\text{和}\quad
T_y=\varnothing,
\]

即某行在全部 \(t\) 个形式上都取 1、某列在全部形式上都取 0；该 cell 不落入任一叶。

更一般地，可用 cross-intersection 的极值定理：若模式族中包含一个小的 transversal-free 子族，则 (3) 自动成立。这个判据把“证明 cover number \(>16\)”转成对 \(t\le16\) 个 affine forms 的有限模式排除，不再需要枚举所有叶树。

## 与 QA 状态的关系

一旦获得 \(F_\oplus(C)>16\)，note054 的 cover-number QA 状态在 \(1/16\)-thinning 下便有平均负补偿；若能把 \(F_\oplus(C)\) 推到 \(N^{1.01}\)，即可直接给出相同量级的 QA 根目标。当前缺口是对具体语义集合 \(E_a,NO_b\) 证明 (3)，而非 QA 递归性本身。

