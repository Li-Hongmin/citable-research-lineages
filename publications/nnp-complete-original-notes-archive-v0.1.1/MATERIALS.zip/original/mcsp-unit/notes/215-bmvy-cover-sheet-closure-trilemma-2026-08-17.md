> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# BMVY cover-sheet closure trilemma (2026-08-17)

## Purpose

The current RW/JK closure problem has a specific source-level form.  In the
BMVY/DDL finite-cover family, the shared-top tester can have large agreement
while its accepting face table is not close to any word on the base complex.
Thus an ordinary list- or distributional-soundness statement does not by
itself supply the single base word needed by a shared-proof reconstruction.

This note records the resulting closure gate.  It is deliberately a
black-box/source-specific theorem: it does not claim that every dPCP must pay
the stated cost.  It says exactly what an attempted BMVY-style upgrade must
add in order to obtain a base-word, rather than a cover lift-word.

## Source hypothesis

Fix a truncated BMVY/DDL complex \(X_i^{\le K}\) and a consecutive finite cover

\[
  X_{i+1}^{\le K}\longrightarrow X_i^{\le K},
  \qquad L_i=[\Gamma_i:\Gamma_{i+1}].
\]

The BMVY filtration and the DDL truncated spectral theorem give the parameter
window used in note 202.  Dikstein--Dinur's finite-cover lemma then supplies a
Boolean face ensemble with shared-top agreement at least \(1/L_i\), but for
every base vertex word \(H\) and every fixed \(\zeta<1/2\),

\[
 \Pr_{A\in X_i(K)}[f_A\text{ is }(1-\zeta)\text{-close to }H|_A]
 \le e^{-\Omega_\zeta(K)}. \tag{1}
\]

The point of (1) is semantic: the accepting object is a cover-sheet/lift-word,
not a word on the base address space.  The notation \(s\in[L_i]\) below refers
to sheets only when a proposed postprocessor actually materializes those sheets
as distinguishable proof targets; the cover lemma alone does not assert an
indexed code family.  It is not a statement about the quality of the BMVY
construction outside this source family.

## Closure theorem (black-box trilemma)

Consider a proposed postprocessor that uses only the shared-top tester and a
single physical proof/address space, and claims to turn the source family into
a base-word, coordinate-robust proof system.  To make the claim meaningful,
assume the postprocessor preserves the sheet entropy: the \(L_i\) sheets remain
distinguishable either as an explicit index or through target-labelled base
claims.  Then at least one of the following three interfaces is necessary.

### (A) Accept the lift-word

The protocol may retain a cover-sheet word \(f_s\) (or an equivalent lift
object).  This is compatible with (1), but it is not base-word closure.  In
particular, the output cannot be fed to a RW/JK reconstruction theorem whose
parent relation is defined on a single base address space.

### (B) Bind the sheet index in the common proof

Suppose a target-independent decoder \(I\), making \(q\) proof queries over
\(\Sigma\), outputs either a sheet index \(s'\in[L_i]\) or \(\bot\).  Assume

* on the proof for sheet \(s\), \(I\) outputs \(s\) with probability at least
  \(\alpha\);
* on every \(\rho\)-near word for sheet \(s\), the probability of outputting a
  wrong non-\(\bot\) index is at most \(\beta<\alpha\).

Then the sheet family is an indexed relaxed local code.  In particular,

\[
  L_i\le \frac{|\Sigma|^q}{\alpha},
  \qquad
  q\ge \frac{\log_2 L_i-\log_2(1/\alpha)}{\log_2|\Sigma|}. \tag{2}
\]

After constant repetition, the locality is

\[
  Q=O\!\left(q(\alpha-\beta)^{-2}\right). \tag{3}
\]

Consequently every applicable positive-radius RLDC lower bound

\[
  N+\log_2 L_i\ge
  \mathsf{LB}_{Q,\Sigma,\rho,\alpha,\beta}(\log_2 L_i) \tag{4}
\]

applies to the common proof length \(N\).  Equation (4) is a parameterized
statement: the function \(\mathsf{LB}\) is whichever RLDC theorem is valid in
the protocol's alphabet, locality, radius, and completeness window.

For the binary perfect-completeness case \(q=1\), \(\alpha=1\), and
\(\beta\le1/3\), message-inline adds one query and gives a binary 2-query RLDC
for the \(\log_2 L_i\)-bit sheet index.  Hence the exponential 2-query RLDC
lower bound of Block et al. yields

\[
  N+\log_2 L_i \ge 2^{\Omega(\log_2 L_i)}=L_i^{\Omega(1)}, \tag{5}
\]

whenever its positive-radius window applies.  The additive index prefix in (5)
is essential; the statement is not an unconditional lower bound on \(N\) in a
zero-radius or non-perfect-completeness regime.

### (C) Add a target-normalized outer check

If the protocol does not expose a sheet index, it must prevent the cover
lift-word from satisfying a wrong base claim.  A sufficient formal interface is
the following.  There is one proof map \(P(m)\in\Sigma^N\) for every target word
\(m\), and for every coordinate \(j\) and claimed bit \(b\), the same address
space has a verifier with

\[
\Pr[V_{j,m_j}(P(m))=1]\ge\alpha,
\qquad
\Pr[V_{j,1-m_j}(z)=1]\le\beta
\quad
\text{for every }z\text{ with }\operatorname{dist}(z,P(m))\le\rho. \tag{6}
\]

The second inequality is an all-policy, target-relative statement: it must hold
for every proof strategy/response that the verifier can observe, not merely for
one selected honest strategy.  Under (6), thresholding the two claim branches
gives a proof-only RLDC with locality

\[
  Q=O\!\left(q(\alpha-\beta)^{-2}\right). \tag{7}
\]

Thus a target-normalized outer check is not a free semantic patch; it enters the
same RLDC/LDC length barrier as explicit sheet binding.  If (6) is weakened to
ordinary list soundness or to independent coordinate proofs, the cover family
in (1) remains a valid phantom-word witness and no base closure follows.

### Adaptive transcript lemma (the information bound in (2))

The first inequality in (2) remains valid for randomized, adaptive \(I\); it does
not assume a fixed query set.  Fix the decoder's random tape \(R=r\).  The resulting
deterministic decision tree has depth at most \(q\).  Its terminal answer strings are
prefix-free; therefore padding every leaf by a fixed dummy symbol gives an injective
representation of all terminal paths as words in \(\Sigma^q\).  Let

\[
  S_r:=\{s\in[L_i]: I_r(P_s)=s\},
\]

where \(P_s\) is the proof for sheet \(s\).  Two distinct indices \(s\ne s'\) in
\(S_r\) cannot follow the same padded answer transcript: a deterministic leaf has a
single output, so it cannot output both \(s\) and \(s'\).  Hence

\[
  |S_r|\le |\Sigma|^q. \tag{2a}
\]

Taking expectation over the random tape and using indexed completeness gives

\[
  \alpha L_i
  \le \sum_{s=1}^{L_i}\Pr_R[I_R(P_s)=s]
  =\mathbb E_R|S_R|
  \le |\Sigma|^q. \tag{2b}
\]

This proves (2), including variable stopping times and adaptive address choices.
The argument only assumes that the decoder is target-independent and has no
sheet-dependent advice after the proof is supplied.  If such advice is allowed, its
entropy must be added to the right-hand side; hiding the sheet in that advice is
precisely the descriptor escape that the trilemma is meant to expose.

More generally, suppose the decoder receives a static descriptor
\(\sigma_s\in\{0,1\}^d\) for sheet \(s\), and the descriptor is the only
sheet-dependent input besides \(P_s\).  The same statement applies if
\(\sigma_s\) selects one strategy from a finite family
\(\mathcal T\) with \(|\mathcal T|\le 2^d\); the strategy may be adaptive in
the proof answers, but it must be selected before the random tape and
interaction.  For fixed \((r,\sigma)\), the same decision-tree argument
bounds the number of correctly labelled sheets by \(|\Sigma|^q\).  Summing
over the at most \(2^d\) descriptors/strategies and averaging over random
tapes gives the descriptor--query tradeoff

\[
  \alpha L_i\le 2^d|\Sigma|^q,
  \qquad
  d+q\log_2|\Sigma|
  \ge \log_2L_i-\log_2(1/\alpha). \tag{2c}
\]

Thus a descriptor does not remove the cover cost; it only moves the same
\(\log L_i\) bits from proof queries into static target information.  Formula
(2c) also covers a descriptor that directly names the sheet.  Therefore a
finite strategy summary cannot evade the cover cost: it only contributes its
description entropy \(d\).  An unrestricted response function is outside this
lemma precisely because its strategy family may have superpolynomial
cardinality; that is the large-support escape, not a free canonical key.

The same counting gives a list-valued variant.  If each terminal transcript
returns a list of at most \(\Lambda\) candidate sheets and sheet \(s\) is
included with probability at least \(\alpha\), then every fixed
\((r,\sigma)\) accounts for at most \(\Lambda|\Sigma|^q\) successful sheets.
Consequently

\[
  \alpha L_i\le \Lambda\,2^d|\Sigma|^q,
  \qquad
  d+q\log_2|\Sigma|+\log_2\Lambda
  \ge \log_2L_i-\log_2(1/\alpha). \tag{2d}
\]

Thus list soundness buys only \(\log\Lambda\) bits of sheet ambiguity; it does
not turn a cover lift into a single base word unless the remaining list entropy
is separately bound.

## BMVY parameter substitution

For the BMVY filtration used in note 202,

\[
  L_i=\ell_0^{\Theta(d^2)},
  \qquad
  \log_2 L_i=\Theta(d^2\log_2\ell_0). \tag{8}
\]

Therefore (2) forces

\[
  q=\Omega\!\left(\frac{d^2\log\ell_0}{\log|\Sigma|}\right) \tag{9}
\]

for any target-independent common-address sheet selector with constant
\(\alpha>0\) (more generally, whenever
\(\log(1/\alpha)=o(d^2\log\ell_0)\)).  In the binary
one-query window, (5) forces a polynomial/exponential-in-\(d^2\log\ell_0\)
proof-length cost, subject to the cited RLDC radius and completeness hypotheses.
If the protocol instead uses (6), the same cost is paid by the target family
whose entropy is preserved; if it pays neither (2) nor (6), it has only a
cover-lift word and has not closed the RW/JK base relation.

If a \(d_{\mathrm{desc}}\)-bit static descriptor is allowed, (2c) gives instead

\[
  d_{\mathrm{desc}}+
  q\log_2|\Sigma|
  \ge c_0d^2\log\ell_0-\log_2(1/\alpha), \tag{9a}
\]

for the positive constant \(c_0\) implicit in (8).  Thus reducing the proof-query
count below the address-scale threshold necessarily
pushes the missing sheet information into a descriptor of the same asymptotic
entropy.

## Proof of the logical gate

Equation (1) rules out the inference “shared-top agreement implies a base
word.”  Hence a black-box postprocessor that does not add a sheet-binding
channel and does not add a target-relative outer check has no premise from which
base closure can be derived: the face family in (1) satisfies its available
shared-top evidence while violating the desired conclusion.

If it adds sheet binding, apply the adaptive transcript lemma (2a)--(2c).
Without external target information this gives (2); with a \(d\)-bit static
descriptor it gives (2c).  Wrong-index soundness and threshold repetition give
(3), and the relevant RLDC lower bound then gives (4).  In the binary
perfect-complete case, message-inline produces the 2-query instance in (5).

If it adds no explicit index but claims base coordinate robustness, its soundness
must exclude every wrong target on every near proof.  That is exactly (6), and
the two-branch thresholding proof gives (7).  Merely recompiling a separate
PCPP for each coordinate does not establish (6), because the resulting proofs
need not share an address space or a common global word.

This proves the stated closure gate.  The theorem is conditional on the
postprocessor being black-box with respect to the source tester and on
preserving sheet entropy; it is not a universal impossibility theorem for all
new PCP constructions.

## What this changes in the RW/JK program

The remaining positive target is now sharply specified.  A successful
near-linear construction must either:

1. change the source so that the finite-cover obstruction (1) is absent;
2. bind the sheet with a common-address index channel while escaping (2)--(5);
3. prove a genuinely new target-normalized/global-consistency theorem of the
   form (6) and then explain how its RLDC consequence avoids the applicable
   lower bound; or
4. change the target to a lift-word and explicitly abandon base-word JK
   closure.

This is a closure theorem for the BMVY/DDL route, not a claim that the general
simultaneous coordinate-robust dPCP problem is solved.

## Sources

* [BMVY, arXiv:2407.12762](https://arxiv.org/html/2407.12762)
* [Dikstein--Dinur, arXiv:2308.09582](https://arxiv.org/html/2308.09582)
* [Dikstein--Dinur--Lubotzky, arXiv:2402.01078](https://arxiv.org/html/2402.01078)
* [Block et al., 3-query RLDCs are strictly stronger than 3-query LDCs / 2-query lower bound](https://arxiv.org/abs/2602.20278)
* [Gur--Minzer--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/html/2512.12960)
