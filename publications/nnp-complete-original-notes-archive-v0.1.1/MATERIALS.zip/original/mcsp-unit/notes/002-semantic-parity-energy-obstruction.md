> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Parity energy 的语义化义务

> 后续结果：[仿射-profile 正规化](003-affine-normalization-and-locality-threshold.md) 已用 \(O(Sr^2)\) 开销解决可达 profile 依赖；本笔记留下的正规化问题只剩满射坐标上的普通公式语义简化。

## 反例：高语法能量不蕴含任何函数复杂性

沿用 [能量二分](001-formula-xor-energy-dichotomy.md) 的记号

\[
\Gamma(F)=\sum_iw_i^2.
\]

令

\[
P(x)=\bigoplus_{j=1}^{N}x_j,
\qquad
T(x)=P(x)\vee\neg P(x).
\]

则

\[
T\equiv1,\qquad
L_\oplus(T)=2,\qquad
\Gamma(T)=2N^2.
\]

因此不存在任何仅依赖 \(\Gamma(F)\) 的函数下界

\[
\Gamma(F)\ge M
\Longrightarrow
\operatorname{Complexity}(F)\ge h(M),
\]

其中 \(h(M)\to\infty\)。

该问题不能靠禁止常数函数修复。对任意 Formula-XOR 公式 \(H\)，

\[
F:=H\wedge(P\vee\neg P)
\]

满足

\[
F\equiv H,\qquad
L_\oplus(F)=L_\oplus(H)+2,\qquad
\Gamma(F)=\Gamma(H)+2N^2.
\]

所以任何函数都存在能量任意接近最大尺度、但新增能量完全无语义作用的表示。

## 对上一结论的精确影响

[能量 lifting](001-formula-xor-energy-dichotomy.md) 仍然成立：

\[
F\text{ 计算 }Q_N
\Longrightarrow
\Gamma(F)\ge N^{1.99}.
\]

但逆向研究义务不能写成

\[
\Gamma(F)\text{ 高}
\Longrightarrow
F\text{ 不能计算 }Q_N.
\]

正确缺失步骤是一个正规化二分：

\[
\boxed{
\begin{array}{c}
\text{从任意小 Formula-XOR 表示 }F\\[2mm]
\Downarrow\\[2mm]
\text{删除／隔离语义无效的高能量}\\
\text{或证明剩余高能量对输出有可测贡献}.
\end{array}}
\]

## 候选语义势函数

把 \(F\) 写成

\[
F(x)=A(P_1(x),\ldots,P_S(x)),
\]

其中 \(A\) 是 De Morgan 公式。定义 counterfactual leaf influence

\[
\operatorname{cInf}_i(F)
:=
\Pr_x[
A(P(x))\ne
A(P_1(x),\ldots,\neg P_i(x),\ldots,P_S(x))
].
\]

相应的 influence-weighted energy 为

\[
\Gamma_{\mathrm{sem}}(F)
:=\sum_i w_i^2\operatorname{cInf}_i(F).
\]

这个自然候选仍然失败。把 \(T=P_1\vee\neg P_2\) 写成两个同值 parity 叶 \(P_1=P_2=P\)。单独反转 \(P_1\) 时，输出在 \(P=1\) 的输入上改变；单独反转 \(P_2\) 时，输出在 \(P=0\) 的输入上改变。因此

\[
\operatorname{cInf}_1(T)
=\operatorname{cInf}_2(T)=\frac12,
\qquad
\Gamma_{\mathrm{sem}}(T)=N^2,
\]

尽管 \(T\equiv1\)。原因是 counterfactual flip 离开了可达 profile

\[
\{(P_1(x),P_2(x)):x\in\{0,1\}^N\}
=\{(0,0),(1,1)\}.
\]

所以势函数还必须尊重 parity profile 的线性依赖与可达集合。一个可靠势函数至少必须满足：

1. **可达性：** 不用离开实际 parity profile 的独立 leaf flip 定义贡献；
2. **语义不变性或正规化稳定性：** 加入 \(P\vee\neg P\) 不增加有效势能；
3. **lifting 下界：** 小有效势能可转为小普通公式；
4. **restriction 可控性：** 限制后的期望势能有严格递推；
5. **MCSP 敏感性：** promise 的 YES/NO 结构强迫有效势能大。

第一项已经排除裸 \(\Gamma\)；后三项均未证明。

## 最小剩余命题

下一步不应直接研究“高 \(\Gamma\) 是否与 MCSP 矛盾”，而应判定：

\[
\boxed{
\begin{aligned}
&\exists\text{ 规范化过程 }\mathcal N,\ \text{使}\\
&F\equiv\mathcal N(F),\quad
L_\oplus(\mathcal N(F))\le\operatorname{poly}(L_\oplus(F)),\\
&\Gamma(\mathcal N(F))
\text{ 的大部分来自在可达 parity profile 上 pivotal 的叶子？}
\end{aligned}}
\]

若该命题为假，需要给出一个无 tautology、局部不可删、但仍具有巨大无效 parity incidence 的公式族。若为真，才有资格把能量 restriction 与 MCSP 的仿射子空间结构连接。

## 能推出什么

- 裸 parity-incidence energy 不是语义复杂度量；
- “高能量对撞 MCSP 敏感性”路线必须先经过正规化；
- tautology removal 不是可忽略的技术清理，而是承重证明义务。

## 不能推出什么

- 未证明上述正规化存在或不存在；
- 已证明上述朴素 \(\Gamma_{\mathrm{sem}}\) 仍不具语义不变性；
- 未削弱 [Formula-XOR 能量 lifting](001-formula-xor-energy-dichotomy.md) 的必要条件。
