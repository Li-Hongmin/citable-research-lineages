> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 仅一条 pair 边的 pair-star：极小性不能降阶（2026-08-13）

## 显式极小族

取
\[
n=4,\quad
X=\{2,13,11,8,4,6\},\quad
Y=\{0,14,3,1,15\},\quad
s=(4,3).
\]

考虑三条 witness
\[
\begin{aligned}
P&=\{(2,0),(2,1)\},\\
A&=\{(2,0),(2,14),(11,3)\},\\
B&=\{(2,1),(2,15),(11,3)\}.
\end{aligned}
\]

直接对 GF(2) 方程作消元可核验：每个 \(T\in\{P,A,B\}\) 自身相容，
\(T\cup\{s\}\) 不相容，而删除 \(T\) 的任一 cell 后便与 \(s\) 相容。
因此三者都是关于固定 spoiler 的 inclusion-minimal collision witnesses。
它们两两相交：
\[
P\cap A=\{(2,0)\},\quad
P\cap B=\{(2,1)\},\quad
A\cap B=\{(11,3)\}.
\]
全族覆盖数为 \(2\)，且唯一的二元 witness 是 \(P\)。故“极小性自动产生第二条 pair”
这一可能的简化是假的。

## 完整 thinning 质量

逐一枚举行参数 \(z=(r,t)\) 和所有行列保留子集，唯一非零条件命中质量为
\[
\begin{array}{c|cccccc}
z&(2,1)&(6,1)&(10,1)&(11,1)&(13,0)&(14,1)\\ \hline
\mu_z&1/8&1/8&1/8&1/32&1/32&1/8
\end{array}
\]
其余 \(z\) 的 \(\mu_z=0\)。因此
\[
\sum_z\mu_z=\frac9{16},\qquad
\Pr[\exists T\subseteq R_z(U,V)]
=\frac1{2^{n+1}}\sum_z\mu_z
=\frac9{512}<\frac1{16}.
\]

该例不是完整 AEKR 的反例；它精确说明最后未决类不能靠 witness 阶数下降或
“pair-star 必有第二条 pair”来关闭。剩余仍是 pair-star 单边与高阶 residual
cross-intersection 的联合质量。
