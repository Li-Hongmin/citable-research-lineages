#!/usr/bin/env python3
"""Small independent certificates for eliminating BF 5-cut cases III, VI, XIII.

The input type sets are copied from the Appendix of
Mácajová--Mazzuoccolo--Tabarelli, Ars Math. Contemp. 26 (2026), P2.03.
This program does not attempt graph generation.  It checks necessary
consequences of the Kempe-chain pairings of a *single* BF-colouring.
"""
from itertools import combinations, permutations, product
import re

COLORS = range(6)

CASE_III = r"""
(12)(35) (13)(35) (15)(35) (23)(35) (24)(35) (25)(35) (34)(35)
(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) (25)(34) [25]
(12)(24) (13)(24) (15)(24) (14)(24) (23)(24) (24)(34)
(12)(14) (13)(14) (14)(15) (14)(23) (14)(34) [14]
(12)(13) (13)(15) (13)(23) (13)(34) [13]
"""
CASE_VI = r"""
(12)(35) (13)(35) (15)(35) (23)(35) (24)(35) (25)(35) (34)(35) [35]
(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) (25)(34) [25]
(12)(24) (13)(24) (14)(24) (15)(24) (23)(24) (24)(34)
(12)(14) (13)(14) (14)(15) (14)(23) (14)(34) [14]
(12)(13) (13)(15) (13)(23) (13)(34) [13]
"""
CASE_XIII_R = r"""
(12)(35) (15)(35) (23)(35) (25)(35) (34)(35)
(12)(45) (15)(45) (23)(45) (25)(45) (34)(45)
(12)(24) (15)(24) (23)(24) (24)(25) (24)(34)
(12)(13) (13)(15) (13)(23) (13)(25) (13)(34)
(12)(14) (14)(15) (14)(23) (14)(25) (14)(34)
(12345)
"""

def parse(text):
    result = set()
    for token in re.findall(r"\(\d\d\)\(\d\d\)|\[\d\d\]|\(12345\)", text):
        if token == "(12345)":
            result.add(("A",))
        elif token[0] == "[":
            q = tuple(map(int, token[1:3]))
            result.add((q, q))
        else:
            a,b,c,d = map(int, re.findall(r"\d", token))
            result.add(tuple(sorted((tuple(sorted((a,b))), tuple(sorted((c,d)))))))
    return result

def name(t):
    if t == ("A",): return "(12345)"
    a,b=t
    return f"[{a[0]}{a[1]}]" if a==b else f"({a[0]}{a[1]})({b[0]}{b[1]})"

def btype(boundary):
    count = [sum(c in label for label in boundary) for c in COLORS]
    if sorted(count) == [1,1,1,1,1,5]: return ("A",)
    assert sorted(count) == [1,1,1,1,3,3]
    triple = [c for c in COLORS if count[c] == 3]
    misses = [tuple(i+1 for i,L in enumerate(boundary) if c not in L) for c in triple]
    return tuple(sorted(misses))

def endpoints(boundary, a, b):
    return tuple(i for i,L in enumerate(boundary) if ((a in L) ^ (b in L)))

def pairings(E):
    assert len(E) in (2,4)
    if len(E)==2: return ((E,),)
    a,b,c,d=E
    return (((a,b),(c,d)), ((a,c),(b,d)), ((a,d),(b,c)))

def switch(boundary, a, b, component):
    out=[set(L) for L in boundary]
    for i in component:
        assert (a in out[i]) ^ (b in out[i])
        if a in out[i]: out[i].remove(a); out[i].add(b)
        else: out[i].remove(b); out[i].add(a)
    return tuple(tuple(sorted(L)) for L in out)

def routing_is_unary_valid(boundary, pair, routing, H):
    return all(btype(switch(boundary,*pair,path)) in H for path in routing)

def combined_types(boundary, q, rq, r, rr):
    out=set()
    for pq,pr in product(rq,rr):
        x=switch(boundary,*q,pq)
        x=switch(x,*r,pr)
        out.add(btype(x))
    return out

def xiii_certificate():
    H=parse(CASE_XIII_R)
    boundary=tuple((0,i) for i in range(1,6))
    assert btype(boundary)==("A",)
    outcomes=[]
    for routing in pairings(endpoints(boundary,0,2)):
        t=btype(switch(boundary,0,2,routing[0]))
        # Both components produce the same boundary type.
        assert {btype(switch(boundary,0,2,p)) for p in routing}=={t}
        outcomes.append((routing,t,t in H))
    assert all(not inside for _,_,inside in outcomes)
    return outcomes

def iii_vi_certificate(H):
    # Triple colours 0 and 1 miss positions 34 and 25 respectively.
    boundary=((0,1),(0,2),(1,3),(1,4),(0,5))
    assert btype(boundary)==((2,5),(3,4))
    qs=((0,3),(1,2),(1,5))
    domains={}
    for q in qs:
        domains[q]=[r for r in pairings(endpoints(boundary,*q))
                    if routing_is_unary_valid(boundary,q,r,H)]
    assert len(domains[(0,3)])==2
    assert len(domains[(1,2)])==1
    assert len(domains[(1,5)])==1

    r12=domains[(1,2)][0]
    r15=domains[(1,5)][0]
    rows=[]
    for tag,r03 in zip(("A","B"),domains[(0,3)]):
        for q,r in (((1,2),r12),((1,5),r15)):
            ts=combined_types(boundary,(0,3),r03,q,r)
            assert len(ts)==1
            rows.append((tag,q,next(iter(ts)),ts.issubset(H)))
    # A is killed by the forced 1--2 routing; B by the forced 1--5 routing.
    assert rows[0][3] is False and rows[3][3] is False
    return boundary,domains,rows

def relabelling_sanity(H):
    """All 48 colour presentations of (25)(34) give the same impossibility."""
    base=[[] for _ in range(5)]
    # colour 0 misses 34; colour 1 misses 25
    for p in range(1,6):
        if p not in (3,4): base[p-1].append(0)
        if p not in (2,5): base[p-1].append(1)
    presentations=[]
    for lonely in permutations(range(2,6)):
        B=[x[:] for x in base]; k=0
        for i in range(5):
            while len(B[i])<2:
                B[i].append(lonely[k]); k+=1
        presentations.append(tuple(tuple(sorted(x)) for x in B))
    presentations += [tuple(tuple(sorted(1-c if c<2 else c for c in L)) for L in B)
                      for B in presentations]

    def coherent(B):
        domains={}
        for q in combinations(COLORS,2):
            E=endpoints(B,*q)
            if not E: continue
            domains[q]=[r for r in pairings(E) if routing_is_unary_valid(B,q,r,H)]
            if not domains[q]: return False
        # Exhaustively assign routings, pruning by every pair of disjoint colour pairs.
        vars_=sorted(domains,key=lambda q:len(domains[q]))
        assignment={}
        def compatible(q,rq,r,rr):
            return combined_types(B,q,rq,r,rr).issubset(H)
        def dfs(k):
            if k==len(vars_): return True
            q=vars_[k]
            for rq in domains[q]:
                if all(set(q)&set(r) or compatible(q,rq,r,rr)
                       for r,rr in assignment.items()):
                    assignment[q]=rq
                    if dfs(k+1): return True
                    del assignment[q]
            return False
        return dfs(0)
    results=[coherent(B) for B in presentations]
    assert results==[False]*len(results)
    return len(results)

if __name__ == "__main__":
    III,VI,XIII = map(parse,(CASE_III,CASE_VI,CASE_XIII_R))
    print("XIII: A-type Kempe outcomes for central colour 0 and lonely colour at e2")
    for routing,t,inside in xiii_certificate():
        R=tuple(tuple(i+1 for i in p) for p in routing)
        print(" ",R,"->",name(t),"present=",inside)

    for label,H in (("III",III),("VI",VI)):
        B,D,rows=iii_vi_certificate(H)
        print(f"\nCase {label}, alpha=(25)(34), boundary={B}")
        for q in ((0,3),(1,2),(1,5)):
            print(" ",q,"valid routings:",
                  [tuple(tuple(i+1 for i in p) for p in r) for r in D[q]])
        for tag,q,t,inside in rows:
            print(f"  03-{tag} plus {q} -> {name(t)}; present={inside}")
        print("  relabelling presentations checked:",relabelling_sanity(H))

    print("\nCERTIFICATE RESULT: cases III, VI, and XIII fail necessary Kempe-routing coherence.")
