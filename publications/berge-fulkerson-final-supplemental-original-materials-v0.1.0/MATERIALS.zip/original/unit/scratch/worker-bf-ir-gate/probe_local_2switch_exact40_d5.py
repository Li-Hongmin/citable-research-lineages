#!/usr/bin/env python3
"""Bounded constructive probe for a real exact-40 Case-XII pole.

Starting from the two frozen order-13 poles (the exact-S C10 pole and the
all-S--T/no-A pole), apply one cubic 2-switch to two proper edges.  This is a
small construction neighbourhood, not a graph census.  Every candidate is
checked using the complete actual perfect-matching incidence routine:

* simple/connected/bridgeless cubic five-pole with five fixed terminals;
* complete BF support, modulo all terminal relabellings, exactly the
  Case-XII 40-type set and no A type;
* if a candidate is found, all five D5 four-cell cylinder joins.

The final result is intentionally one of the four stopping values: a real
exact-40 counterexample, a stricter positive obstruction, or unresolved in
this local neighbourhood.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations, permutations
from pathlib import Path
import sys

import networkx as nx

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
KEMPE = ROOT / "units/berge-fulkerson/scratch/worker-kempe"
sys.path.insert(0, str(KEMPE))
import exact_st_joint_audit as joint  # noqa: E402

REAL = ROOT / "units/berge-fulkerson/scratch/worker-real-exact-s-no-a"
sys.path.insert(0, str(REAL))
import audit_loop_incidence_interface as loop_interface  # noqa: E402

TARGET_SCAN = ROOT / "units/berge-fulkerson/scratch/worker-bf-s-gate/target_case_xii_support_scan.py"
sys.path.insert(0, str(TARGET_SCAN.parent))
import target_case_xii_support_scan as target  # noqa: E402


SEMI = (0, 1, 2, 3, 4)
BASES = {
    "exact_s_c10": tuple(loop_interface.C10_EDGES),
    "all_st_no_a": tuple(loop_interface.ALL_SS_EDGES),
}

S = joint.S
T = joint.T
D5 = tuple(sorted(joint.DISJOINT_ST))


def pole_graph(edges):
    graph = nx.Graph()
    graph.add_nodes_from(range(13))
    graph.add_edges_from(edges)
    return graph


def valid_pole(edges):
    graph = pole_graph(edges)
    if graph.number_of_edges() != 17 or not nx.is_connected(graph):
        return False
    if any(u == v for u, v in edges) or len(set(tuple(sorted(e)) for e in edges)) != 17:
        return False
    degree = Counter()
    for u, v in edges:
        degree[u] += 1
        degree[v] += 1
    for vertex in SEMI:
        degree[vertex] += 1
    if any(degree[v] != 3 for v in range(13)):
        return False
    return not list(nx.bridges(graph))


def two_switches(base):
    """Yield unique one-2-switch edge sets from the base."""
    base = tuple(sorted(tuple(sorted(e)) for e in base))
    original = set(base)
    seen = set()
    for left_index, right_index in combinations(range(len(base)), 2):
        a, b = base[left_index]
        c, d = base[right_index]
        rest = [edge for i, edge in enumerate(base) if i not in (left_index, right_index)]
        for replacement in (((a, c), (b, d)), ((a, d), (b, c))):
            candidate = tuple(sorted(tuple(sorted(e)) for e in rest + list(replacement)))
            if candidate in seen or candidate == base:
                continue
            seen.add(candidate)
            yield (left_index, right_index), replacement, candidate


def cell_projection(data, cell):
    """Actual five-coordinate D5 cylinder, copied from the frozen gate."""
    _, _, _, _, classes, _ = data
    s, t = cell
    singleton_classes = [classes[(i,)] for i in range(1, 6)]
    first_triples = classes[joint.complement(s)]
    second_triples = classes[joint.complement(t)]
    edge_count = len(data[0])
    answer = set()
    # Backtracking over singleton classes with the same load pruning as the
    # project's completion routine keeps this local probe bounded.
    for singleton_tuple in __import__("itertools").product(*singleton_classes):
        base_load = [0] * edge_count
        for position in s + t:
            for edge in singleton_tuple[position - 1]:
                base_load[edge] += 1
        if any(value > 2 for value in base_load):
            continue
        for first in first_triples:
            load = list(base_load)
            for edge in first:
                load[edge] += 1
            if any(value > 2 for value in load):
                continue
            for second in second_triples:
                if all(load[edge] + (edge in second) == 2 for edge in range(edge_count)):
                    answer.add(singleton_tuple)
                    break
            else:
                continue
            break
    return frozenset(answer)


def d5_joins(data):
    projections = {cell: cell_projection(data, cell) for cell in D5}
    joins = []
    for omitted in D5:
        chosen = [cell for cell in D5 if cell != omitted]
        joins.append(len(set.intersection(*(set(projections[c]) for c in chosen))))
    return tuple(len(projections[c]) for c in D5), tuple(joins)


def target_distance(support):
    """Minimum symmetric-difference distance to the 40-type target."""
    best = 10**9
    for image in permutations(range(1, 6)):
        mapping = {position: image[position - 1] for position in range(1, 6)}
        mapped = {
            target.canonical_type(kind, mapping)
            for kind in support
        }
        best = min(best, len(mapped ^ set(target.TARGET)))
    return best


def main():
    total = valid = exact40 = 0
    records = []
    near = []
    for name, base in BASES.items():
        for pair, replacement, edges in two_switches(base):
            total += 1
            if not valid_pole(edges):
                continue
            valid += 1
            pole = joint.base.legacy.Pole(n=13, proper_edges=edges)
            record = joint.pole_record(name, {}, pole)
            if record["has_A"]:
                continue
            near.append({
                "distance_to_target": target_distance(record["support"]),
                "support_size": len(record["support"]),
                "base": name,
                "switched_edge_indices": pair,
                "replacement": replacement,
                "proper_edges": edges,
            })
            if target.canonical_support(record["support"]) != target.TARGET_CANONICAL:
                continue
            exact40 += 1
            data = joint.matching_data(pole)
            projection_sizes, joins = d5_joins(data)
            item = {
                "base": name,
                "switched_edge_indices": pair,
                "replacement": replacement,
                "proper_edges": edges,
                "perfect_matchings": data[-1],
                "support_size": len(record["support"]),
                "d5_projection_sizes": projection_sizes,
                "d5_four_way_join_sizes": joins,
            }
            records.append(item)
            print(item)
    print({
        "two_switches_tested": total,
        "valid_simple_connected_bridgeless": valid,
        "exact40_no_A": exact40,
        "closest_no_A": sorted(
            near,
            key=lambda item: (item["distance_to_target"], item["support_size"], item["base"], item["switched_edge_indices"]),
        )[:10],
        "records": records,
    })
    if records and any(all(value == 0 for value in item["d5_four_way_join_sizes"]) for item in records):
        print("REAL_EXACT40_D5_COUNTEREXAMPLE_FOUND")
    elif records:
        print("REAL_EXACT40_POLES_FOUND_BUT_NO_D5_COUNTEREXAMPLE")
    else:
        print("NO_EXACT40_POLE_IN_LOCAL_2SWITCH_NEIGHBOURHOOD")


if __name__ == "__main__":
    main()
