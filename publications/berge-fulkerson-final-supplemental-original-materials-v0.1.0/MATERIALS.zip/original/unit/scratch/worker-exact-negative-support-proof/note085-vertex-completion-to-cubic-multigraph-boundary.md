# Vertex complements give selected perfect matchings, not a real Case-XII pole

Let \(\mathcal M\) be the 125 frozen Note 085 tokens and let
\(C=T\sqcup P\) be its five terminal and 43 proper coordinate labels.  For
each coordinate signature \(c\in C\), suppose that two binary signatures
\(d_c,e_c\in\{0,1\}^{\mathcal M}\) satisfy

\[
  c(M)+d_c(M)+e_c(M)=1
  \qquad(M\in\mathcal M).                       \tag{1}
\]

For the ten complementary halfedges belonging to the five terminal labels,
suppose moreover that they can be paired so that the two ends of every pair
have identical signatures.

There are two distinct questions.  Equation (1) is enough for a cubic
multigraph realization of the *selected* tokens.  It is not, by itself,
enough to preserve the fifty designated BF rows on the new edges.

## Conditional construction

For every proper label \(c\in P\), create two distinct vertices
\(v_c^0,v_c^1\).  Give each vertex three halfedges with signatures
\(c,d_c,e_c\), and pair corresponding signatures between the two copies.
This produces three parallel proper edges between \(v_c^0\) and \(v_c^1\).

For every terminal label \(c\in T\), create one vertex \(v_c\) with the same
three signatures.  Keep its \(c\)-halfedge as a semiedge and pair the other
ten halfedges by the assumed equal-signature pairing.  The result has

\[
  |V|=2|P|+|T|=2\cdot43+5=91,
  \qquad |E_{\rm proper}|=3\cdot43+5=134,
\]

and five semiedges, so

\[
  3|V|=273=2|E_{\rm proper}|+5.
\]

For a token \(M\), include an edge or semiedge exactly when its common
signature has bit one at \(M\).  Equation (1) says that exactly one incident
halfedge is selected at every vertex.  Equal-signature pairing says that the
two ends of every proper edge are selected simultaneously.  Hence each of
the 125 tokens defines a genuine perfect matching of this multigraph pole.
The five retained terminal signatures also preserve every token's original
singleton or triple boundary class.  Restriction to one distinguished edge
carrying each original coordinate recovers the frozen 48-coordinate vector,
so the 125 perfect matchings remain distinct.

No loop is created by the proper blocks because their endpoints are distinct.
In the fixed Note 085 boundary system, the two complements at one terminal
vertex cannot have the same signature: (1) makes them disjoint, and equality
would force both to be zero and the terminal signature to be all-one, which
it is not.  Thus an equal-signature terminal pairing also joins distinct
vertices.  Parallel edges are nevertheless unavoidable in every proper
block.

## The row-balance gap and its minimal repair

Let \(R\) be one of the fifty six-token rows, counted with multiplicity.
For \(R\) to remain a BF cover of the constructed graph, every signature
\(s\) used on a constructed edge must satisfy

\[
  \sum_{M\in R}s(M)=2.                           \tag{2}
\]

Complementarity alone does not imply (2).  If the old coordinate \(c\) has
row weight two, then (1) gives only

\[
  \sum_{M\in R}d_c(M)+\sum_{M\in R}e_c(M)=4;
\]

the two summands could be \(1+3\), rather than \(2+2\).  A six-token toy
row already witnesses the gap:

\[
  c=110000,\qquad d=001000,\qquad e=000111.
\]

These vectors partition the six tokens pointwise, but their row weights are
\(2,1,3\), so the new \(d\)- and \(e\)-edges are not double covered.

The minimal correction is to require every chosen complement signature to
be balanced as in (2) on all fifty rows.  It suffices, in particular, to
require every \(d_c,e_c\) to equal one of the frozen coordinate signatures,
because all frozen coordinates already have row weight two in every
designated row.  Under this corrected hypothesis, all fifty rows become
literal BF covers of the constructed multigraph, with the same boundary
types and literal token reuse.

## What negative properties survive

The construction contains a distinguished edge or semiedge for each of the
48 old coordinates.  Therefore restriction from the constructed edge set to
these representatives recovers the original binary system.  It follows that,
*within the selected pool of 125 perfect matchings*, every negative statement
witnessed by the old coordinates remains valid:

- no six-token decomposition of an all-terminal or \(T\)--\(T\) forbidden
  type can become a BF cover, because it would already double cover all 48
  old coordinates;
- every endpoint-membership and forced-intermediate nonmembership separation
  from Note 085 remains separated on at least one old representative edge;
- old overload witnesses and other coordinate inequalities remain present.

If all complements are copied from old coordinate signatures, the positive
coordinatewise identities used by Note 085 also persist on every duplicated
edge.  For arbitrary merely row-balanced complements, this last stronger
claim needs to be imposed separately for any positive identity beyond the
fifty row equations.

## Why this is not a connected exact-Case-XII pole

With the prescribed corresponding pairing, each proper coordinate produces
an isolated two-vertex component joined by three parallel edges.  The five
terminal vertices form a loopless 2-regular multigraph, hence either a
5-cycle or a 3-cycle together with a digon.  The construction therefore has
44 or 45 connected components.  It is a cubic multigraph with five
semiedges, but it is neither simple nor connected.  If the term "5-pole" is
defined to include connectedness, the claimed implication is false at this
point.

Allowing a global, rather than blockwise, equal-signature pairing does not
repair the logic automatically.  Connectivity requires the additional
hypothesis that the signature classes admit a loopless pairing whose union
on the 91 vertices is connected; local complement triples and even
multiplicity of signature occurrences do not imply this.

More decisively, the 125 constructed matchings are not the full perfect-
matching family.  Every proper two-vertex component independently offers
three parallel-edge choices.  Choosing all five terminal semiedges and one
of the three edges in every proper component gives at least

\[
  3^{43}
\]

additional all-terminal perfect matchings in the full closure.  This does
not by itself produce an \(A=(12345)\) BF cover: such a cover also needs five
singleton companions with the exact double-cover load.  It does prove that
the selected token pool is far from the full closure.  The new perfect
matchings may fill the separated carrier sections or participate in
forbidden BF types, but either conclusion requires a separate full-support
calculation.

Consequently the strict conclusion, after adding row balance, is only:

> the 125 frozen tokens embed as distinct genuine perfect matchings of a
> loopless cubic multigraph with five semiedges, and the fifty designated
> rows and all selected-pool negative separations are preserved.

It does not yield a simple or connected pole, and it does not preserve
exact-Case-XII support under full perfect-matching closure.  To reach the
real-pole semantics one must additionally produce a suitable global pairing
giving the required graph class and then control *every* perfect matching of
that graph; neither requirement follows from vertex complements.
