#!/usr/bin/env python3
"""Finite exact check of the product-fibre Cauchy inequality and n=0 fibre."""

from __future__ import annotations

from collections import defaultdict
import random


def check(K: int, H: int, seed: int = 20260812) -> None:
    rng = random.Random(seed)
    weights = {
        (k, ell): complex(rng.uniform(-1, 1), rng.uniform(-1, 1))
        for k in range(-K, K + 1)
        for ell in range(-H, H + 1)
        if k and ell
    }
    fibres: dict[int, list[complex]] = defaultdict(list)
    for (k, ell), weight in weights.items():
        fibres[k * ell].append(weight)

    lhs = sum(abs(sum(values)) ** 2 for values in fibres.values())
    rhs_mass = sum(abs(weight) ** 2 for weight in weights.values())
    max_fibre = max(map(len, fibres.values()))
    assert lhs <= max_fibre * rhs_mass + 1e-12 * max(1.0, lhs)

    zero_fibre = [
        (k, ell)
        for k in range(-K, K + 1)
        for ell in range(-H, H + 1)
        if k * ell == 0
    ]
    assert len(zero_fibre) == 2 * K + 2 * H + 1
    print(
        f"K={K} H={H} nonzero_fibres={len(fibres)} "
        f"max_fibre={max_fibre} lhs/rhs_mass={lhs / rhs_mass:.6f} "
        f"zero_fibre={len(zero_fibre)}"
    )


if __name__ == "__main__":
    for size in (8, 32, 128):
        check(size, size // 2)
