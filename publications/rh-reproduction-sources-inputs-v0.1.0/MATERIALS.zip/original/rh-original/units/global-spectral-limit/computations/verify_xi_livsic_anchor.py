#!/usr/bin/env python3
"""Rigorous Arb certificate that xi'(3/2) / xi(3/2) is positive."""

from flint import arb, arb_series, ctx


ctx.prec = 200
s = arb_series([arb(3) / 2, arb(1)], prec=2)
xi = (
    (s * (s - 1) / 2)
    * (-(s / 2) * arb.pi().log()).exp()
    * (s / 2).gamma()
    * s.zeta()
)
kappa = xi.log()[1]

assert kappa.lower() > 0
print("kappa = xi'(3/2) / xi(3/2) =", kappa)
print("PASS: kappa is strictly positive")
