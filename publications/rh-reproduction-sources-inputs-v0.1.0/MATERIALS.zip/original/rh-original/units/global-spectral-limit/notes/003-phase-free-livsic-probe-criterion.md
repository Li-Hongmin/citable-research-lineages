# 无相位 Livšic 探针判据

日期：2026-08-12。

> 后续边界：本文的“探针极限推出 RH”定理仍成立，但
> [note 006](006-zero-shift-circularity-and-screw-norm-pivot.md) 证明 Suzuki 的 zeta
> 目标只在零下移构造中导出，而存在趋零的无条件安全下移本身等价于 RH。因此本文
> 不再被解释为任意 \(\tau_a<\inf\sigma(A_a)\) 的自然极限定理。

本 note 进一步消去 [note 002](002-herglotz-cayley-normal-family-reduction.md) 中扩张相位 \(\theta_a\) 和导数探针 \(W_a'\)。核心对象是局部 symmetric operator 自身的 Livšic 特征函数，而不是某一个自伴扩张的特征整函数。

## 1. 有限尺度的 phase-free Schur 函数

设

\[
T_a=A_a-\tau_a I>0,
\qquad
\tau_a<\inf\sigma(A_a),
\]

并在 \(H(T_a)\) 中考虑 Suzuki 的闭 symmetric operator

\[
D_a=i\frac d{dx},
\qquad D(D_a)=C_c^\infty(-a,a).
\]

其 deficiency indices 为 \((1,1)\)。规范 deficiency vectors 为

\[
v_{a,+}=T_a^{-1}e^x,
\qquad
v_{a,-}=T_a^{-1}e^{-x}.
\]

记

\[
I_{a,+}(z):=\int_{-a}^a v_{a,+}(x)e^{izx}\,dx,
\qquad
I_{a,-}(z):=\int_{-a}^a v_{a,-}(x)e^{izx}\,dx.
\]

Suzuki 的自伴扩张特征方程等价于

\[
e^{i\theta}
=-\frac{z-i}{z+i}\frac{I_{a,+}(z)}{I_{a,-}(z)}.
\]

因此定义

\[
\boxed{
\Theta_a(z):=
-\frac{z-i}{z+i}\frac{I_{a,+}(z)}{I_{a,-}(z)}.
}
\]

这正是 \(D_a\) 的标量 Livšic 特征函数，至多相差一个常模因子。规范给出

\[
\Theta_a(i)=0,
\qquad
|\Theta_a(z)|\le1
\quad(z\in\mathbf H).
\]

后一个结论不是新的算术估计，而是 deficiency-
\((1,1)\) extension theory 的一般定理：Livšic 特征函数是上半平面上的 Schur 函数，且不依赖为写公式而选择的参考自伴扩张，只存在常模因子歧义。Aleman--Martin--Ross 2012, equation (1.5) 给出可计算公式并证明其 contractivity；Silva--Toloza 2011 则给出相同对象的 de Branges functional model 和单参数扩张谱族。

这里的 symmetric operator 是 simple 的。事实上，对任意 defect vector

\[
v_{a,z}=T_a^{-1}e^{-izx},
\qquad z\notin\mathbf R,
\]

若 \(f\in H(T_a)\) 与所有 \(v_{a,z}\) 正交，则

\[
0=\langle f,v_{a,z}\rangle_{T_a}
\]

等价于紧支撑函数 \(f\) 的 Fourier--Laplace 变换恒为零，故 \(f=0\)。因此 defect subspaces 的闭线性张成是整个 \(H(T_a)\)。

## 2. 规范的 zeta 目标

令

\[
X(z)=\xi\!\left(\frac12-iz\right),
\qquad
m_X(z):=-\frac{X'(z)}{X(z)}.
\]

在锚点 \(z=i\)，有

\[
m_X(i)=i\kappa,
\qquad
\kappa:=\frac{\xi'(3/2)}{\xi(3/2)}.
\]

Arb 区间计算严格给出

\[
\boxed{
\kappa\in
[0.0461359280604625753594660065422719932179382973224181973081,
\ 0.0461359280604625753594660065422719932179382973224181973083]
>0.
}
\]

验证器见 [`verify_xi_livsic_anchor.py`](../computations/verify_xi_livsic_anchor.py)。因此可以定义同样在 \(i\) 归零的 zeta 目标

\[
\boxed{
\Theta_X(z):=
\frac{m_X(z)/\kappa-i}{m_X(z)/\kappa+i}
=\frac{-X'(z)-i\kappa X(z)}{-X'(z)+i\kappa X(z)}.
}
\]

它是一个亚纯函数，并满足 \(\Theta_X(i)=0\)。若 RH 成立，则 \(X\) 属于 Laguerre--Pólya 类，\(m_X/\kappa\) 为按锚点规范的 Herglotz 函数，故 \(\Theta_X\) 是 Schur 内函数。C 线不假设这一结论，而把它作为有限尺度 Schur 极限将强制产生的性质。

## 3. 定理：两配对探针极限推出 RH

取任意 \(a_j\to\infty\) 及任意满足 \(\tau_{a_j}<\inf\sigma(A_{a_j})\) 的规范下移。设 \(S\subset\mathbf H\) 在上半平面内有聚点，且不含 \(\Theta_X\) 的极点。若存在常模因子 \(\omega_j\in\mathbf T\) 使

\[
\omega_j\Theta_{a_j}(z)
\longrightarrow
\Theta_X(z)
\qquad(z\in S),
\]

则 RH 成立。

### 证明

每个 \(\omega_j\Theta_{a_j}\) 都是 Schur 函数，所以该族在 \(\mathbf H\) 局部一致有界。Vitali 定理将 \(S\) 上的逐点收敛升级为

\[
\omega_j\Theta_{a_j}\to\Theta
\]

在 \(\mathbf H\) 的每个紧集上局部一致，其中 \(\Theta\) 全纯且 \(|\Theta|\le1\)。亚纯恒等定理给出 \(\Theta=\Theta_X\)；特别地，\(\Theta_X\) 的一切表观极点均被全纯延拓。

反设 \(\rho\in\mathbf H\) 是 \(X\) 的零点，重数为 \(m\ge1\)。则

\[
m_X(z)=-\frac{m}{z-\rho}+O(1),
\]

从而

\[
\Theta_X(\rho)=1
\]

按可去奇点延拓。于是 Schur 函数 \(\Theta\) 在上半平面内部取得单位模，最大模原理迫使 \(\Theta\equiv1\)。但 \(\Theta_X(i)=0\)，矛盾。因此 \(X\) 在上半平面没有零点。由 \(X(\bar z)=\overline{X(z)}\)，下半平面也没有零点，故 RH 成立。证毕。

## 4. 对计算接口的压缩

一个探针 \(z\) 只需要

\[
I_{a,+}(z)
=\left\langle T_a^{-1}e^x,e^{-i\bar z x}\right\rangle,
\qquad
I_{a,-}(z)
=\left\langle T_a^{-1}e^{-x},e^{-i\bar z x}\right\rangle
\]

这两个标量 resolvent 配对。相比 note 002：

- 不再选择扩张相位 \(\theta_a\)；
- 不再计算 \(W_a'\) 或 \(xe^{izx}\) 导数探针；
- 不再证明整个谱或整函数收敛；
- 只需在一个有聚点的非实探针集上识别一个标量比值。

## 证据边界与下一铰链

本 note 已严格消去正规族、扩张相位和导数探针。尚未消去的规范自由度只剩

\[
\tau_a<\inf\sigma(A_a)
\]

及一个常模因子。下一最便宜的决定性问题是：不同下移 \(\tau_a\) 所得 \(\Theta_a\) 是否只相差一个固定圆盘自同构；若否，必须选择一个具有无条件显式下界的 canonical \(\tau_a\)，再测试两个配对的非实探针极限。

## 参考文献

- M. Suzuki, [Weil's quadratic form via the screw function](https://arxiv.org/abs/2606.09096), 2026，Theorem 1.5 与 Section 6。
- A. Aleman, R. T. W. Martin, W. T. Ross, [On a theorem of Livsic](https://arxiv.org/abs/1209.4497), 2012，特别是 equations (1.5)--(1.9)。
- L. O. Silva, J. H. Toloza, [The spectra of selfadjoint extensions of entire operators with deficiency indices (1,1)](https://arxiv.org/abs/1104.4765), 2011，特别是 Propositions 2.4 与 4.2--4.4。
