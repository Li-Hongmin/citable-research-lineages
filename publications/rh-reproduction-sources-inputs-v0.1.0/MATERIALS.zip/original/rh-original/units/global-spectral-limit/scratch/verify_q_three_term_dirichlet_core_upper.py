#!/usr/bin/env python3
"""Rigorous Arb upper bound for the finite core of the note 049 witness.

This deliberately proves only the interval ``|t-tau| <= radius``.  The
unbounded tails are a separate analytic obligation.
"""

from __future__ import annotations

import argparse
from decimal import Decimal, getcontext

from flint import acb, arb, ctx

from verify_q_reverse_poisson_failure import q_value


# Fixed decimal witness from the 65536-node exploratory solve.  Treating the
# displayed decimals as exact rationals avoids any dependence on numerical
# optimization in the certificate.
D_RE = ("0.507783617928", "-0.232016167436", "-0.640303853772")
D_IM = ("-0.017061423220", "-0.077291815102", "-0.085478016496")


def dirichlet_value(s: acb) -> acb:
    total = acb(0)
    for n, (re, im) in enumerate(zip(D_RE, D_IM), start=1):
        coefficient = acb(arb(re), arb(im))
        total += coefficient * (-s * arb(n).log()).exp()
    return total


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a", default="0.0625")
    parser.add_argument("--tau", default="540.375")
    parser.add_argument("--radius", default="5")
    parser.add_argument("--step", default="0.0001")
    parser.add_argument("--digits", type=int, default=35)
    parser.add_argument(
        "--analytic-integral",
        action="store_true",
        help="use Arb's rigorous complex-analytic quadrature instead of boxes",
    )
    args = parser.parse_args()
    ctx.dps = args.digits
    getcontext().prec = args.digits + 20

    a_d, tau_d = Decimal(args.a), Decimal(args.tau)
    radius_d, step_d = Decimal(args.radius), Decimal(args.step)
    count_d = 2 * radius_d / step_d
    count = int(count_d)
    if Decimal(count) != count_d:
        raise ValueError("2*radius must be an integer multiple of step")

    a, tau = arb(args.a), arb(args.tau)
    center_s = acb(arb(str(Decimal("0.5") + a_d)), tau)
    center_product = q_value(center_s) * dirichlet_value(center_s)
    target = (5 * abs(center_product) ** 2).lower()

    if args.analytic_integral:
        def reflected_dirichlet(t: acb) -> acb:
            s = acb(arb("0.5"), 0) - acb(0, 1) * t
            total = acb(0)
            for n, (re, im) in enumerate(zip(D_RE, D_IM), start=1):
                coefficient = acb(arb(re), -arb(im))
                total += coefficient * (-s * arb(n).log()).exp()
            return total

        def integrand(t: acb, analytic: bool) -> acb:
            del analytic  # all factors below are meromorphic
            s_plus = acb(arb("0.5"), 0) + acb(0, 1) * t
            s_minus = acb(arb("0.5"), 0) - acb(0, 1) * t
            product = (
                q_value(s_plus)
                * dirichlet_value(s_plus)
                * q_value(s_minus)
                * reflected_dirichlet(t)
            )
            return a / arb.pi() * product / (a**2 + (t - tau) ** 2)

        # Split at a mesh of length 1/4; this keeps the nearby Poisson poles
        # outside each integration ellipse and makes the certificate stable.
        analytic_core = acb(0)
        analytic_step = Decimal("0.25")
        analytic_count = int(2 * radius_d / analytic_step)
        for j in range(analytic_count):
            lo = acb(arb(str(tau_d - radius_d + j * analytic_step)))
            hi = acb(arb(str(tau_d - radius_d + (j + 1) * analytic_step)))
            analytic_core += acb.integral(
                integrand,
                lo,
                hi,
                rel_tol=arb("1e-25"),
                abs_tol=arb("1e-28"),
                eval_limit=100000,
                depth_limit=30,
            )
        core = analytic_core.real.upper()
        assert analytic_core.imag.contains(0)
        print("analytic integral enclosure =", analytic_core)
    else:
        half = step_d / 2
        left = tau_d - radius_d
        width = arb(args.step)
        core = arb(0)
        for j in range(count):
            segment_left = left + Decimal(j) * step_d
            midpoint = segment_left + half
            t = arb(str(midpoint), str(half))
            s = acb(arb("0.5"), t)
            product_square = (abs(q_value(s) * dirichlet_value(s)) ** 2).upper()
            offset_left = segment_left - tau_d
            offset_right = offset_left + step_d
            if offset_left <= 0 <= offset_right:
                min_offset_square = Decimal(0)
            else:
                min_offset_square = min(abs(offset_left), abs(offset_right)) ** 2
            poisson = (
                a / (arb.pi() * (a**2 + arb(str(min_offset_square))))
            ).upper()
            core += width * poisson * product_square
        core = core.upper()
    print("fixed coefficients =", list(zip(D_RE, D_IM)))
    print("interval = [tau-radius, tau+radius]")
    print("intervals =", count)
    print("|Q(s0)D(s0)|^2 =", abs(center_product) ** 2)
    print("finite-core upper =", core)
    print("factor-five target lower =", target)
    print("remaining rigorous tail budget =", (target - core).lower())
    print("core/center upper =", (core / (abs(center_product) ** 2).lower()).upper())
    assert core < target


if __name__ == "__main__":
    main()
