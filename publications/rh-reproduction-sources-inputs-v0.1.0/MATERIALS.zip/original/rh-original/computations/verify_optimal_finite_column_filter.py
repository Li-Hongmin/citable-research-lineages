#!/usr/bin/env python3
"""Exact finite-column least-squares experiment; run on OMEN only.

For T_N with rows k=1,...,N-1, solve the rational normal equations for
T_N e_1 + sum_{d=2}^D c_d T_N e_d with c_1 fixed to 1.
"""
from fractions import Fraction
from math import gcd
import argparse


def mobius(n: int) -> int:
    x = n
    p = 2
    parity = 0
    while p * p <= x:
        if x % p == 0:
            x //= p
            parity ^= 1
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        parity ^= 1
    return -1 if parity else 1


def row_value(N: int, k: int, d: int) -> Fraction:
    lo = k // d
    hi = N // d
    return sum((Fraction(mobius(j), d * j) for j in range(lo + 1, hi + 1)), Fraction(0))


def columns(N: int, D: int):
    return [[row_value(N, k, d) for k in range(1, N)] for d in range(1, D + 1)]


def solve_fraction(A, b):
    n = len(b)
    M = [list(A[i]) + [b[i]] for i in range(n)]
    for col in range(n):
        piv = next(i for i in range(col, n) if M[i][col])
        M[col], M[piv] = M[piv], M[col]
        z = M[col][col]
        M[col] = [x / z for x in M[col]]
        for i in range(n):
            if i == col or not M[i][col]:
                continue
            z = M[i][col]
            M[i] = [x - z * y for x, y in zip(M[i], M[col])]
    return [M[i][-1] for i in range(n)]


def run(N, D):
    col = columns(N, D)
    # weights (2k+1) are absorbed into the Gram products.
    G = [[sum((2 * (k + 1) + 1) * col[i][k] * col[j][k]
              for k in range(N - 1)) for j in range(1, D)] for i in range(1, D)]
    rhs = [-sum((2 * (k + 1) + 1) * col[i][k] * col[0][k]
                for k in range(N - 1)) for i in range(1, D)]
    c = solve_fraction(G, rhs) if D > 1 else []
    residual = [col[0][k] + sum(c[i - 1] * col[i][k] for i in range(1, D))
                for k in range(N - 1)]
    energy = sum((2 * (k + 1) + 1) * x * x for k, x in enumerate(residual))
    return c, energy


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-n", type=int, default=30)
    ap.add_argument("--ratio", type=float, default=0.5)
    args = ap.parse_args()
    for N in range(8, args.max_n + 1, 2):
        D = max(2, min(N - 1, int(round(args.ratio * N))))
        c, E = run(N, D)
        print(f"N={N} D={D} E={E} c_last={c[-1] if c else None}")


if __name__ == "__main__":
    main()
