#!/usr/bin/env python3
"""Exact OMEN-side check for note 463.

This script is intended to run on OMEN.  It checks the q-layer difference
identity and the Volterra quadratic form using Fraction arithmetic.
"""

from __future__ import annotations

import argparse
from fractions import Fraction


def mobius_table(n_max: int) -> list[int]:
    mu = [1] * (n_max + 1)
    mu[0] = 0
    primes: list[int] = []
    composite = [False] * (n_max + 1)
    for n in range(2, n_max + 1):
        if not composite[n]:
            primes.append(n)
            mu[n] = -1
        for p in primes:
            if n * p > n_max:
                break
            composite[n * p] = True
            if n % p == 0:
                mu[n * p] = 0
                break
            mu[n * p] = -mu[n]
    return mu


def run(max_n: int) -> int:
    mu = mobius_table(max_n)
    harmonic = [Fraction(0)] * (max_n + 1)
    for n in range(1, max_n + 1):
        harmonic[n] = harmonic[n - 1] + Fraction(1, n)

    def eta(n: int, cutoff: int) -> int:
        return sum(
            mu[n // divisor]
            for divisor in range(cutoff + 1, n + 1)
            if n % divisor == 0
        )

    def z_layer(m: int, cutoff: int, q: int) -> Fraction:
        b_max = m // (cutoff + 1)
        return sum(
            (
                Fraction(mu[b], b)
                * (harmonic[m // b] - harmonic[max(cutoff, q // b)])
            )
            for b in range(1, b_max + 1)
        )

    checked = 0
    for n in range(2, max_n + 1):
        for divisor in range(1, n + 1):
            m = n // divisor
            for cutoff in range(1, m + 1):
                layers = [z_layer(m, cutoff, q) for q in range(m + 1)]
                increments = [
                    Fraction(eta(q, cutoff), q) for q in range(1, m)
                ]
                if any(
                    layers[q - 1] - layers[q] != increments[q - 1]
                    for q in range(1, m)
                ):
                    raise AssertionError(("difference", n, divisor, cutoff))

                direct_energy = sum(
                    Fraction(2 * k + 1, divisor * divisor)
                    * layers[k // divisor] ** 2
                    for k in range(1, n)
                )
                u = [None] + increments
                quadratic = (m * m - Fraction(1, divisor * divisor)) * layers[0] ** 2
                quadratic -= 2 * layers[0] * sum(
                    (m * m - j * j) * u[j] for j in range(1, m)
                )
                quadratic += sum(
                    (m * m - max(i, j) ** 2) * u[i] * u[j]
                    for i in range(1, m)
                    for j in range(1, m)
                )
                if direct_energy != quadratic:
                    raise AssertionError(("energy", n, divisor, cutoff))
                checked += 1

    print(f"PASS {checked} exact parameter groups")
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-n", type=int, default=15)
    args = parser.parse_args()
    raise SystemExit(run(args.max_n))
