#!/usr/bin/env python3
"""Exact finite check for note 348's double-shift triangle weight."""

from collections import defaultdict


def check(b: int, y: int, h: int) -> None:
    counts = defaultdict(int)
    for r in range(1, h + 1):
        for s in range(1, h + 1):
            for n in range(1, y + 1):
                m = b + n + r
                q = b + n + h + s
                counts[(m, q)] += 1

    for (m, q), count in counts.items():
        if b + h + 1 <= m <= b + y + 1:
            d = q - m
            expected = h - abs(d - h) if 1 <= d <= 2 * h - 1 else 0
            assert count == expected, ((b, y, h), (m, q), count, expected)


if __name__ == "__main__":
    check(10, 8, 3)
    check(0, 5, 2)
    print("triangle weight identity: OK")
