#!/usr/bin/env python3
"""OMEN-only diagnostic: finite least-squares residual versus the full tail."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_optimal_finite_column_filter import run


def mobius_sieve(n):
    mu = [1] * (n + 1)
    primes, is_prime = [], [True] * (n + 1)
    mu[0] = 0
    for i in range(2, n + 1):
        if is_prime[i]:
            primes.append(i)
            mu[i] = -1
        for p in primes:
            if i * p > n:
                break
            is_prime[i * p] = False
            if i % p == 0:
                mu[i * p] = 0
                break
            mu[i * p] = -mu[i]
    return mu


def one(N):
    D = N - 1
    c, Ein = run(N, D)
    M = 4 * N
    mu = mobius_sieve(M)
    a = [0.0] * (M + 1)
    for d, cc in enumerate([1.0] + c, start=1):
        for j in range(1, M // d + 1):
            a[d * j] += float(cc) * mu[j]
    tail, Eout = 0.0, 0.0
    for k in range(M - 1, N - 1, -1):
        tail += a[k + 1] / (k + 1)
        Eout += (2 * k + 1) * tail * tail
    return float(Ein), Eout


if __name__ == "__main__":
    for N in (16, 32, 48, 64, 80):
        Ein, Eout = one(N)
        print(f"N={N} Ein={Ein:.12g} Eout={Eout:.12g} Eout/N^2={Eout/(N*N):.12g}")
