"""Arb box certificate excluding common zeros of J and J'.

Run on OMEN, not on the local workstation.  With L = log(2), write

    J(s) = 2**s Q(s),
    Q(s) = integral_0^L sin(4*pi*exp(-x)) exp(-s*x) dx.

Then J = J' = 0 iff Q = dQ/ds = 0.  Each parameter rectangle is
excluded as soon as either interval enclosure has a positive modulus
lower bound.  Composite-midpoint errors are enclosed with uniform
second-derivative bounds valid for 1/2 <= Re(s) <= 1, |Im(s)| <= 50.
"""

from __future__ import annotations

import math
import multiprocessing as mp
import os
import time
from typing import Iterable

from flint import acb, arb, ctx


PREC = int(os.environ.get("ARB_PREC", "120"))
NQUAD = int(os.environ.get("ARB_NQUAD", "512"))
SIG_STEP = float(os.environ.get("SIG_STEP", "0.02"))
T_STEP = float(os.environ.get("T_STEP", "0.02"))
T_MAX = float(os.environ.get("T_MAX", "50.0"))
WORKERS = int(os.environ.get("ARB_WORKERS", str(min(28, os.cpu_count() or 1))))

# On the certified box, |s| < 51.  For y=4*pi*exp(-x) in [2*pi,4*pi],
# |q| <= 1, |q'| < 13, |q''| < 172.  Thus
# |(q exp(-sx))''| < 172 + 2*51*13 + 51^2 < 4200.
Q_SECOND_BOUND = 4200

# For g=-x*q*exp(-sx), g''=-2*f'-x*f'', where
# |f'| < 13+51=64 and x <= log(2) < 0.7.  Hence |g''| < 3200.
DQ_SECOND_BOUND = 3200


def enclosure(box: tuple[float, float, float, float]) -> tuple[float, float, str, str]:
    """Return rigorous modulus lower bounds for Q and dQ/ds."""

    sig0, sig1, t0, t1 = box
    ctx.prec = PREC
    pi = arb.pi()
    length = arb(2).log()
    h = length / NQUAD

    sig_mid = arb(str((sig0 + sig1) / 2.0))
    sig_rad = arb(str((sig1 - sig0) / 2.0)) + arb("1e-12")
    t_mid = arb(str((t0 + t1) / 2.0))
    t_rad = arb(str((t1 - t0) / 2.0)) + arb("1e-12")
    s = acb(arb(sig_mid, sig_rad), arb(t_mid, t_rad))

    total = acb(0)
    derivative = acb(0)
    for j in range(NQUAD):
        x = (arb(j) + arb("0.5")) * h
        q = (4 * pi * (-x).exp()).sin()
        term = q * (-s * x).exp()
        total += term
        derivative -= x * term
    total *= h
    derivative *= h

    q_error = length * h * h * arb(Q_SECOND_BOUND) / 24
    dq_error = length * h * h * arb(DQ_SECOND_BOUND) / 24
    total += acb(arb(0, q_error.upper()), arb(0, q_error.upper()))
    derivative += acb(arb(0, dq_error.upper()), arb(0, dq_error.upper()))

    q_lower = abs(total).lower()
    dq_lower = abs(derivative).lower()
    return float(q_lower), float(dq_lower), str(q_lower), str(dq_lower)


def boxes() -> Iterable[tuple[float, float, float, float]]:
    sig = 0.5
    while sig < 1.0 - 1e-12:
        sig_end = min(sig + SIG_STEP, 1.0)
        t = 0.0
        while t < T_MAX - 1e-12:
            t_end = min(t + T_STEP, T_MAX)
            yield (sig, sig_end, t, t_end)
            t = t_end
        sig = sig_end


def main() -> int:
    all_boxes = list(boxes())
    started = time.time()
    failures: list[
        tuple[tuple[float, float, float, float], float, float, str, str]
    ] = []
    minimum = (float("inf"), None, None)

    with mp.Pool(WORKERS) as pool:
        results = pool.imap(enclosure, all_boxes, chunksize=8)
        for box, result in zip(all_boxes, results):
            q_float, dq_float, q_text, dq_text = result
            certificate = max(q_float, dq_float)
            if certificate < minimum[0]:
                minimum = (certificate, box, (q_text, dq_text))
            if q_float <= 0.0 and dq_float <= 0.0:
                failures.append((box, q_float, dq_float, q_text, dq_text))

    elapsed = time.time() - started
    print(
        f"precision={PREC} nquad={NQUAD} workers={WORKERS} "
        f"sig_step={SIG_STEP} t_step={T_STEP} t_max={T_MAX}",
        flush=True,
    )
    print(f"boxes={len(all_boxes)} elapsed_s={elapsed:.3f}", flush=True)
    print(
        f"minimum_joint_certificate={minimum[0]!r} "
        f"box={minimum[1]} arb={minimum[2]}",
        flush=True,
    )
    print(f"unresolved_boxes={len(failures)}", flush=True)
    for item in failures[:100]:
        print("UNRESOLVED", item, flush=True)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
