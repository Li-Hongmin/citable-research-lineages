# (k=1), (a=2) high-divisor Mellin kernel: zero-free certificate

This bundle certifies the strengthened strip

\[
K(s):=\int_{2/3}^{1}\log\frac1t
\left(\frac2{\pi t}+\sin(2\pi t)\right)t^{s-1}\,dt\ne0
\quad\left(0\le\Re s\le1\right).
\]

It supports [note 094](../../../notes/094-k1-a2-high-divisor-cell-has-a-zero-free-mellin-detector.md).
It neither gives the high-divisor mean-square bound nor proves RH by itself.

## Replay

```text
.venv-math/bin/python -B \
  computations/bundles/k1-a2-mellin-zero-free/sources/certify_k1_a2_mellin_arb.py \
  --sigma-left 0
```

Required runtime: Python 3.13 with `python-flint==0.9.0` (Arb/FLINT outward
rounding).  Any unresolved interval, nonzero/undetermined winding, or failed
strict inequality exits nonzero.

The original \([1/2,1]\) replay and the strengthened \([0,1]\) replay are
recorded separately under results/. Across supported Arb builds adaptive
quadrature may alter the final displayed radius, but a
successful replay must print the same Boolean certificates and strictly
stronger-than-zero margins; the recorded lower bounds leave the following
portable thresholds:

```text
TAIL abs_s_cutoff=75
TAIL scaled_margin > 1.8e-4
ARGUMENT winding_integer=0
ARGUMENT minimum_segment_abs_lower > 8.6e-5
```

Source SHA-256:

```text
95766e2e9c59e6c5307d246b172a48464b344c75f932136cb5d2fa54399d86db
```

Strengthened output SHA-256
(\(results/certificate-strip-0-1-192.log\)):

```text
a55bfad2caee91f09449c8e9603457b084fb7c765eb1e927ac5dc6bcbc9390ed
```
