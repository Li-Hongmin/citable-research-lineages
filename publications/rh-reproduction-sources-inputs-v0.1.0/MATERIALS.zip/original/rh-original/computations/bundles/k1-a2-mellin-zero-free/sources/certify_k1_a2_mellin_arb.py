#!/usr/bin/env python3
"""Arb certificate for the Mellin transform of the k=1, a=2 cell.

    K(s) = integral_(2/3)^1 log(1/t) [2/(pi*t)+sin(2*pi*t)] t^(s-1) dt.

The program proves K(s) != 0 on sigma_left <= Re(s) <= 1, with
sigma_left=1/2 by default and sigma_left=0 for the strengthened certificate.
It covers the compact rectangle by the argument principle and the exterior
by repeated integration by parts.  Every failed enclosure fails closed.
"""

from __future__ import annotations

import argparse
import math
import sys
import time
from collections import deque
from dataclasses import dataclass
from fractions import Fraction

try:
    import flint
    from flint import acb, acb_series, arb, ctx
except ImportError as exc:
    raise SystemExit("python-flint is unavailable") from exc


@dataclass(frozen=True)
class Box:
    sigma0: Fraction
    sigma1: Fraction
    tau0: Fraction
    tau1: Fraction
    depth: int = 0


Point = tuple[Fraction, Fraction]


def A(value: int | Fraction) -> arb:
    if isinstance(value, Fraction):
        return arb(value.numerator) / arb(value.denominator)
    return arb(value)


def real_interval(left: Fraction, right: Fraction) -> arb:
    return arb(A((left + right) / 2), A((right - left) / 2))


def complex_box(box: Box) -> acb:
    return acb(
        real_interval(box.sigma0, box.sigma1),
        real_interval(box.tau0, box.tau1),
    )


def strictly_positive(value: arb) -> bool:
    return bool(value > 0)


class Kernel:
    def __init__(
        self,
        bits: int,
        integration_bits: int,
        ibp_order: int,
        derivative_panels: int,
    ) -> None:
        ctx.prec = bits
        self.pi = arb.pi()
        self.alpha = -(arb(3) / arb(2)).log()
        self.tolerance = arb(2) ** (-integration_bits)
        self.ibp_order = ibp_order
        self.derivative_panels = derivative_panels

    def density(self, x: acb) -> acb:
        # t=e^x: K(s)=int_alpha^0 density(x) exp((s-1)x) dx.
        return -x * (
            arb(2) / self.pi
            + x.exp() * (arb(2) * self.pi * x.exp()).sin()
        )

    def value(self, s: acb) -> acb:
        return acb.integral(
            lambda x, _analytic: self.density(x) * ((s - 1) * x).exp(),
            acb(self.alpha),
            acb(0),
            rel_tol=self.tolerance,
            abs_tol=self.tolerance,
            deg_limit=20,
            eval_limit=50000,
            depth_limit=28,
            use_heap=True,
        )

    def density_derivative(self, order: int, point: arb) -> acb:
        variable = acb_series([acb(point), acb(1)], order + 1)
        expression = -variable * (
            arb(2) / self.pi
            + variable.exp() * (arb(2) * self.pi * variable.exp()).sin()
        )
        return expression[order] * math.factorial(order)

    def derivative_l1_bound(self, order: int) -> arb:
        width = -self.alpha / self.derivative_panels
        radius = width / 2
        total = arb(0)
        for panel in range(self.derivative_panels):
            midpoint = self.alpha + width * (2 * panel + 1) / (2 * self.derivative_panels)
            total += self.density_derivative(order, arb(midpoint, radius)).abs_upper() * width
        return total

    def endpoint_bound(self, order: int) -> arb:
        return (
            self.density_derivative(order, self.alpha).abs_upper()
            + self.density_derivative(order, arb(0)).abs_upper()
        )

    def tail_margin(self, radius_floor: int) -> tuple[arb, arb]:
        """Lower leading amplitude and upper remainder after one IBP.

        Put lambda=s-1 and first scale the IBP identity by
        lambda*exp(-lambda*alpha).  Its leading term is -density(alpha).
        For Re(s)<=1, both exp(-lambda*alpha) at the right endpoint and
        exp(lambda*(x-alpha)) in the remainder have modulus <= 1.
        If |s|>=R, all remaining denominators are >= R-1.
        """
        r_minus = arb(radius_floor - 1)
        lower = self.density(acb(self.alpha)).abs_lower()
        upper = arb(0)
        for order in range(1, self.ibp_order):
            upper += self.endpoint_bound(order) / r_minus**order
        upper += self.derivative_l1_bound(self.ibp_order) / r_minus**(self.ibp_order - 1)
        return lower, upper

    def tail_cutoff(self, maximum: int) -> tuple[int, arb, arb]:
        for radius in range(4, maximum + 1):
            lower, upper = self.tail_margin(radius)
            if strictly_positive(lower - upper):
                return radius, lower, upper
        raise RuntimeError(f"tail did not close through {maximum}")


def point_box(point: Point) -> Box:
    return Box(point[0], point[0], point[1], point[1])


def segment_box(left: Point, right: Point, depth: int) -> Box:
    return Box(
        min(left[0], right[0]), max(left[0], right[0]),
        min(left[1], right[1]), max(left[1], right[1]), depth,
    )


def midpoint(left: Point, right: Point) -> Point:
    return ((left[0] + right[0]) / 2, (left[1] + right[1]) / 2)


def contour(
    tau_max: int,
    sigma_left: Fraction,
    sigma_parts: int,
    tau_parts_per_unit: int,
) -> list[tuple[Point, Point]]:
    points: list[tuple[Point, Point]] = []

    def add_line(start: Point, stop: Point, parts: int) -> None:
        for index in range(parts):
            points.append((
                (start[0] + (stop[0] - start[0]) * index / parts,
                 start[1] + (stop[1] - start[1]) * index / parts),
                (start[0] + (stop[0] - start[0]) * (index + 1) / parts,
                 start[1] + (stop[1] - start[1]) * (index + 1) / parts),
            ))

    lower_left = (sigma_left, Fraction(0))
    lower_right = (Fraction(1), Fraction(0))
    upper_right = (Fraction(1), Fraction(tau_max))
    upper_left = (sigma_left, Fraction(tau_max))
    vertical = tau_max * tau_parts_per_unit
    add_line(lower_left, lower_right, sigma_parts)
    add_line(lower_right, upper_right, vertical)
    add_line(upper_right, upper_left, sigma_parts)
    add_line(upper_left, lower_left, vertical)
    return points


def argument_certificate(
    kernel: Kernel,
    tau_max: int,
    sigma_left: Fraction,
    sigma_parts: int,
    tau_parts_per_unit: int,
    max_depth: int,
    max_segments: int,
) -> dict[str, object]:
    pending = [(left, right, 0) for left, right in reversed(
        contour(tau_max, sigma_left, sigma_parts, tau_parts_per_unit)
    )]
    cache: dict[Point, acb] = {}
    increments: list[arb] = []
    unresolved: list[tuple[Point, Point, int, acb]] = []
    minimum: arb | None = None
    evaluated = 0

    def at(point: Point) -> acb:
        if point not in cache:
            cache[point] = kernel.value(complex_box(point_box(point)))
        return cache[point]

    while pending:
        if evaluated >= max_segments:
            unresolved.extend((left, right, depth, acb()) for left, right, depth in reversed(pending))
            break
        left, right, depth = pending.pop()
        image = kernel.value(complex_box(segment_box(left, right, depth)))
        evaluated += 1
        image_lower = image.abs_lower()
        if strictly_positive(image_lower):
            ratio = at(right) / at(left)
            if strictly_positive(ratio.real):
                increments.append(ratio.arg())
                if minimum is None or image_lower < minimum:
                    minimum = image_lower
                continue
        if depth >= max_depth:
            unresolved.append((left, right, depth, image))
            continue
        middle = midpoint(left, right)
        pending.append((middle, right, depth + 1))
        pending.append((left, middle, depth + 1))

    total = sum(increments, arb(0))
    winding = total / (2 * arb.pi())
    certified = False
    winding_integer: int | None = None
    if not unresolved:
        candidate = int(round(float(winding.mid())))
        if winding.contains(candidate) and (winding - candidate).abs_upper() < A(Fraction(1, 4)):
            certified = True
            winding_integer = candidate
    return {
        "certified": certified,
        "winding_integer": winding_integer,
        "winding": winding,
        "argument": total,
        "minimum": minimum,
        "unresolved": unresolved,
        "evaluated": evaluated,
        "vertices": len(cache),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bits", type=int, default=192)
    parser.add_argument("--integration-bits", type=int, default=130)
    parser.add_argument("--ibp-order", type=int, default=12)
    parser.add_argument("--derivative-panels", type=int, default=1024)
    parser.add_argument("--tail-search-max", type=int, default=512)
    parser.add_argument(
        "--sigma-left",
        type=Fraction,
        default=Fraction(1, 2),
        help="left edge of the certified strip (default: 1/2)",
    )
    parser.add_argument("--sigma-parts", type=int, default=8)
    parser.add_argument("--tau-parts-per-unit", type=int, default=4)
    parser.add_argument("--max-depth", type=int, default=18)
    parser.add_argument("--max-segments", type=int, default=250000)
    args = parser.parse_args()
    if args.bits < 80 or not 32 <= args.integration_bits < args.bits:
        parser.error("require bits >= 80 and 32 <= integration-bits < bits")
    if args.ibp_order < 3 or args.derivative_panels < 8:
        parser.error("invalid IBP order or panel count")
    if not 0 <= args.sigma_left < 1:
        parser.error("require 0 <= sigma-left < 1")
    return args


def main() -> int:
    args = parse_args()
    kernel = Kernel(args.bits, args.integration_bits, args.ibp_order, args.derivative_panels)
    at_one = kernel.value(acb(1))
    primitive_ok = at_one.is_finite() and strictly_positive(at_one.abs_lower())
    print(f"PRIMITIVE python-flint={flint.__version__} bits={ctx.prec}")
    print(f"PRIMITIVE K(1)={at_one}")
    print(f"PRIMITIVE certified={primitive_ok}")
    if not primitive_ok:
        return 2
    try:
        cutoff, lower, upper = kernel.tail_cutoff(args.tail_search_max)
    except RuntimeError as error:
        print(f"TAIL certified=False blocker={error}")
        return 3
    print(f"TAIL certified=True abs_s_cutoff={cutoff} ibp_order={args.ibp_order} derivative_panels={args.derivative_panels}")
    print(f"TAIL scaled_leading_lower={lower}")
    print(f"TAIL scaled_remainder_upper={upper}")
    print(f"TAIL scaled_margin={lower-upper}")
    result = argument_certificate(
        kernel,
        cutoff,
        args.sigma_left,
        args.sigma_parts,
        args.tau_parts_per_unit,
        args.max_depth,
        args.max_segments,
    )
    final = result["certified"] and result["winding_integer"] == 0 and not result["unresolved"]
    print(f"ARGUMENT certified={final} sigma=[{args.sigma_left},1] tau=[0,{cutoff}] evaluated={result['evaluated']} vertices={result['vertices']} unresolved={len(result['unresolved'])}")
    print(f"ARGUMENT minimum_segment_abs_lower={result['minimum']}")
    print(f"ARGUMENT argument_sum={result['argument']}")
    print(f"ARGUMENT winding_ball={result['winding']}")
    print(f"ARGUMENT winding_integer={result['winding_integer']}")
    print(f"FULL K_zero_free_strip_certified={final} symmetry=K(conj(s))=conj(K(s))")
    return 0 if final else 5


if __name__ == "__main__":
    sys.exit(main())
