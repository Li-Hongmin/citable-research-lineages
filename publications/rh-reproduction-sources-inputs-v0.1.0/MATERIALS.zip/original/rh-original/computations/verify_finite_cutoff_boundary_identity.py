from fractions import Fraction


def mobius(n: int) -> int:
    if n == 1:
        return 1
    x, parity, p = n, 0, 2
    while p * p <= x:
        if x % p == 0:
            x //= p
            parity ^= 1
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        parity ^= 1
    return -1 if parity else 1


def ceil_fraction(x: Fraction) -> int:
    return (x.numerator + x.denominator - 1) // x.denominator


def b_x(x: int, X: int) -> Fraction:
    return sum((Fraction(mobius(n), n) for n in range(max(1, x), X + 1)), Fraction(0))


def check_filter(X: int, coeffs: tuple[int, ...]) -> None:
    q = 2
    support = q ** (len(coeffs) - 1) * X
    b = [0] * (support + 1)
    for m in range(1, support + 1):
        for j, c in enumerate(coeffs):
            scale = q**j
            if m % scale == 0 and m // scale <= X:
                b[m] += c * mobius(m // scale)

    A = sum((Fraction(mobius(n), n) for n in range(1, X + 1)), Fraction(0))
    for k in range(1, support + 1):
        direct = sum((Fraction(b[m], m) for m in range(k, support + 1)), Fraction(0))
        formula = Fraction(0)
        for j, c in enumerate(coeffs):
            formula += Fraction(c, q**j) * b_x(ceil_fraction(Fraction(k, q**j)), X)
        assert direct == formula

        if k <= X:
            tail_inf = Fraction(0)
            for j, c in enumerate(coeffs):
                y = ceil_fraction(Fraction(k, q**j))
                tail_inf += Fraction(c, q**j) * (b_x(y, X) - A)
            p_qinv = sum((Fraction(c, q**j) for j, c in enumerate(coeffs)), Fraction(0))
            assert formula == tail_inf + p_qinv * A


def main() -> None:
    for X in range(1, 61):
        check_filter(X, (1, -2))
        check_filter(X, (2, -1))
    print("finite-cutoff boundary identity verified for X=1..60")


if __name__ == "__main__":
    main()
