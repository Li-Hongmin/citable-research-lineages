#!/usr/bin/env python3
"""OMEN-only exact check of the N-independent internal row-difference identity."""
from fractions import Fraction
import argparse


def mobius(n):
    x, parity, p = n, 0, 2
    while p * p <= x:
        if x % p == 0:
            x //= p
            parity ^= 1
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        parity ^= 1
    return -1 if parity else 1


def factor_log_vector(n):
    out = {}
    x, p = n, 2
    while p * p <= x:
        while x % p == 0:
            out[p] = out.get(p, 0) + 1
            x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        out[x] = out.get(x, 0) + 1
    return out


def add_vec(dst, src, scale):
    for p, e in src.items():
        dst[p] = dst.get(p, 0) + scale * e
        if not dst[p]:
            del dst[p]


def check(D, N):
    # Verify the formal identity for a_n=(c*mu)(n), 2<=n<=D:
    # constant part vanishes and log-prime vector is -Lambda(n).
    for n in range(2, D + 1):
        const = sum(mobius(n // d) for d in range(1, n + 1) if n % d == 0)
        if const:
            return False, (D, N, n, "constant", const)
        vec = {}
        for d in range(1, n + 1):
            if n % d == 0:
                add_vec(vec, factor_log_vector(d), -mobius(n // d))
        expected = {}
        fac = factor_log_vector(n)
        if len(fac) == 1:
            expected[next(iter(fac))] = -1
        if vec != expected:
            return False, (D, N, n, "log-vector", vec, expected)
    # Row differences R(k)-R(k+1) only see a_{k+1}; they are independent of N.
    return True, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-D", type=int, default=180)
    args = ap.parse_args()
    cases = 0
    for D in range(2, args.max_D + 1):
        for ratio_num in (1, 2, 3, 5):
            N = ratio_num * D
            ok, detail = check(D, N)
            if not ok:
                raise SystemExit(f"FAIL {detail}")
            cases += 1
    print(f"PASSED internal identity: D=2..{args.max_D}, N/D in 1,2,3,5; cases={cases}")


if __name__ == "__main__":
    main()
