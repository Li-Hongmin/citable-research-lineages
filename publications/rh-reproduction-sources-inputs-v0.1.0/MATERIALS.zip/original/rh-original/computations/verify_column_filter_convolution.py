#!/usr/bin/env python3
"""Exact OMEN-side check for note 472."""

from __future__ import annotations

import argparse
from fractions import Fraction


def mobius_table(n_max: int) -> list[int]:
    mu = [1] * (n_max + 1)
    mu[0] = 0
    primes: list[int] = []
    composite = [False] * (n_max + 1)
    for n in range(2, n_max + 1):
        if not composite[n]:
            primes.append(n)
            mu[n] = -1
        for p in primes:
            if n * p > n_max:
                break
            composite[n * p] = True
            if n % p == 0:
                mu[n * p] = 0
                break
            mu[n * p] = -mu[n]
    return mu


def run(max_n: int) -> int:
    mu = mobius_table(max_n)
    checked = 0
    for n_max in range(2, max_n + 1):
        for support in range(1, n_max + 1):
            c = [0] + [1 if d <= support else 0 for d in range(1, n_max + 1)]
            convolution = [0] * (n_max + 1)
            for n in range(1, n_max + 1):
                convolution[n] = sum(c[d] * mu[n // d]
                                      for d in range(1, n + 1) if n % d == 0)
            for k in range(1, n_max):
                lhs = sum(Fraction(c[d], d) *
                          sum(Fraction(mu[j], j)
                              for j in range(k // d + 1, n_max // d + 1))
                          for d in range(1, n_max + 1))
                rhs = sum(Fraction(convolution[n], n)
                          for n in range(k + 1, n_max + 1))
                if lhs != rhs:
                    raise AssertionError(("convolution", n_max, support, k, lhs, rhs))
            if support < n_max:
                for n in range(2, support + 1):
                    if convolution[n] != 0:
                        raise AssertionError(("early-zero", n_max, support, n, convolution[n]))
                if convolution[support + 1] != -1:
                    raise AssertionError(("first-tail", n_max, support, convolution[support + 1]))
            checked += 1

    print(f"PASS {checked} exact column-filter convolution instances")
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-n", type=int, default=42)
    args = parser.parse_args()
    raise SystemExit(run(args.max_n))
