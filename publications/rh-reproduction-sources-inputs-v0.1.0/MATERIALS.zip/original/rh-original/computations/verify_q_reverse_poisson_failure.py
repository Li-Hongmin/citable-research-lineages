"""Rigorous finite-interval lower bound for a reverse-Poisson failure.

The script partitions a finite critical-line interval into Arb balls.  On each
ball it encloses Q, takes a lower bound for |Q|, and combines it with the
minimum Poisson weight on that interval.  Therefore the reported integral is
a rigorous lower bound for the full Poisson second moment.
"""

from __future__ import annotations

import argparse
from decimal import Decimal, getcontext

from flint import acb, acb_series, arb, ctx


def q_value(s: acb) -> acb:
    variable = acb_series([s, acb(1)], 2)
    zeta_series = variable.zeta()
    zeta_value = zeta_series[0]
    zeta_derivative = zeta_series[1]
    c_value = (
        1
        + 1 / s
        + 1 / (s - 1)
        - arb.pi().log() / 2
        + (s / 2).digamma() / 2
    )
    return (s - 1) / s * (zeta_derivative + c_value * zeta_value)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a", type=str, required=True)
    parser.add_argument("--tau", type=str, required=True)
    parser.add_argument("--radius", type=str, default="0.25")
    parser.add_argument("--step", type=str, default="0.0001")
    parser.add_argument("--digits", type=int, default=30)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    ctx.dps = args.digits
    getcontext().prec = args.digits + 20

    a_decimal = Decimal(args.a)
    tau_decimal = Decimal(args.tau)
    radius_decimal = Decimal(args.radius)
    step_decimal = Decimal(args.step)
    if a_decimal <= 0 or radius_decimal <= 0 or step_decimal <= 0:
        raise ValueError("a, radius, and step must be positive")

    interval_count_decimal = 2 * radius_decimal / step_decimal
    interval_count = int(interval_count_decimal)
    if Decimal(interval_count) != interval_count_decimal:
        raise ValueError("2*radius must be an integer multiple of step")

    a_ball = arb(str(a_decimal))
    tau_ball = arb(str(tau_decimal))
    center = acb(arb(str(Decimal("0.5") + a_decimal)), tau_ball)
    center_value = q_value(center)
    center_square_upper = (abs(center_value) ** 2).upper()
    factor_five_upper = 5 * center_square_upper

    width_ball = arb(str(step_decimal))
    half_width = step_decimal / 2
    left_edge = tau_decimal - radius_decimal
    lower_integral = arb(0)
    nonzero_intervals = 0

    for index in range(interval_count):
        segment_left = left_edge + Decimal(index) * step_decimal
        midpoint = segment_left + half_width
        height_ball = arb(str(midpoint), str(half_width))
        boundary_value = q_value(acb(arb("0.5"), height_ball))
        magnitude_lower = abs(boundary_value).lower()
        if magnitude_lower > 0:
            nonzero_intervals += 1

        distance_left = abs(segment_left - tau_decimal)
        distance_right = abs(segment_left + step_decimal - tau_decimal)
        maximum_distance = max(distance_left, distance_right)
        denominator_upper = (
            a_ball**2 + arb(str(maximum_distance)) ** 2
        ).upper()
        weight_lower = (a_ball / (arb.pi() * denominator_upper)).lower()
        lower_integral += width_ball * weight_lower * magnitude_lower**2

    lower_integral = lower_integral.lower()
    proved_failure = lower_integral > factor_five_upper
    error_square_lower = (1 - center_square_upper / lower_integral).lower()

    print("RIGOROUS Arb finite-interval lower bound")
    print("a =", args.a)
    print("tau =", args.tau)
    print("integrated interval = [tau-radius, tau+radius]")
    print("radius =", args.radius)
    print("step =", args.step)
    print("intervals =", interval_count)
    print("intervals with positive |Q| lower bound =", nonzero_intervals)
    print("finite-interval Poisson lower bound =", lower_integral)
    print("5 * |Q(1/2+a+i*tau)|^2 upper bound =", factor_five_upper)
    print("E_0^2 lower bound from the finite interval =", error_square_lower)
    print("proved reverse-Poisson factor-5 failure =", proved_failure)


if __name__ == "__main__":
    main()
