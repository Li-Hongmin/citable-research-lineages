#!/usr/bin/env python3
"""Exact check of the discrete Abel identity used in note 411."""

from fractions import Fraction
import argparse


def mobius(n: int) -> int:
    x, p, sign = n, 2, 1
    while p * p <= x:
        if x % p == 0:
            x //= p
            sign = -sign
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        sign = -sign
    return sign


def check(Y: int) -> None:
    mu = [0] + [mobius(n) for n in range(1, Y + 1)]
    U = [0]
    B = [Fraction(0)]
    for n in range(1, Y + 1):
        U.append(U[-1] + n * mu[n])
        B.append(B[-1] + Fraction(mu[n], n))

    for k in range(2, Y + 1):
        m = k // 2
        rhs = Fraction(U[k], k * k) - Fraction(U[m], m * m)
        rhs += sum(
            (U[j] * (Fraction(1, j * j) - Fraction(1, (j + 1) * (j + 1)))
             for j in range(m, k)),
            Fraction(0),
        )
        assert B[k] - B[m] == rhs, (Y, k, B[k] - B[m], rhs)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("-M", type=int, default=100)
    args = parser.parse_args()
    for Y in range(2, args.M + 1):
        check(Y)
    print(f"discrete Abel reciprocal-tail identity verified for Y=2..{args.M}")


if __name__ == "__main__":
    main()
