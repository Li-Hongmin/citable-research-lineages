#!/usr/bin/env python3
"""Exact finite-matrix check of the q-fold causal identity."""
from fractions import Fraction
import sympy as sp


def v15(u: Fraction) -> Fraction:
    return u**2 * (1-u)**9 * (1024*u**4 + 207*u**3 - 57*u**2 - 27*u - 3)


def matrices(N: int):
    A = sp.zeros(N, N)
    D = sp.zeros(N, N)
    Di = sp.zeros(N, N)
    for a in range(1, N + 1):
        for b in range(1, a + 1):
            x = v15(Fraction(b, a))
            A[a - 1, b - 1] = sp.Rational(x.numerator, x.denominator)
            if a % b == 0:
                D[a - 1, b - 1] = 1
                Di[a - 1, b - 1] = sp.mobius(a // b)
    return A, D, Di


def conv_mu(N: int, q: int) -> sp.Matrix:
    # c_q = mu^{*q}; c_0 is the Dirichlet identity.
    if q == 0:
        return sp.Matrix([1] + [0] * (N - 1))
    mu = [0] + [sp.mobius(n) for n in range(1, N + 1)]
    prev = [0] + [1] + [0] * (N - 1)
    for _ in range(q):
        cur = [0] * (N + 1)
        for n in range(1, N + 1):
            cur[n] = sum(mu[d] * prev[n // d] for d in range(1, n + 1) if n % d == 0)
        prev = cur
    return sp.Matrix(prev[1:])


def main() -> None:
    for N in range(3, 18):
        A, D, Di = matrices(N)
        C = A * D - D * A
        e = conv_mu(N, 0)
        for q in range(1, 5):
            cq = conv_mu(N, q)
            rhs = Di**q * A * e
            for j in range(q):
                rhs -= Di**(q-j) * C * conv_mu(N, j + 1)
            assert A * cq == rhs

    # The signed triangle-collapsed two-layer matrix is not PSD.
    N = 10
    A, D, Di = matrices(N)
    T = sp.zeros(2, 2)
    cs = [conv_mu(N, q) for q in range(3)]
    for i in range(2):
        for j in range(2):
            T[i, j] = (
                (cs[i + 1].T * A * cs[j])[0]
                + (cs[j + 1].T * A * cs[i])[0]
            ) / 2
    assert sp.factor(T.det()) < 0
    print("exact q-fold causal identity passed for N=3..17, q=1..4")


if __name__ == "__main__":
    main()
