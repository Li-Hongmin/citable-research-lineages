#!/usr/bin/env python3
"""Finite Lambda--Gabor outer-matrix shadow (diagnostic only).

This is a deliberately conditional finite model.  It keeps the exact
finite-aperture q_r overlap (including q_0), the complete finite Gabor matrix
products, the von Mangoldt function (including prime powers), all six
balanced +/- orientations, and the exact 15-word raw-minus-continuum
inclusion--exclusion identity.  The outer labels are logarithmic dyadic bins;
they are *not* a physical-Q membership map.

For bins a,b,c,d and a balanced orientation eps, put

    P_i = sum_{n in bin_i} Lambda(n)/sqrt(n) A_y^{eps_i},
    C_i = int_{bin_i} exp(y/2) A_y^{eps_i} dy,

where A_y is the finite Gabor atom.  The outer matrix entry is the sum over
the six balanced eps of tr(P_1 P_2 P_3 P_4) - tr(C_1 C_2 C_3 C_4), divided
by d.  The difference is evaluated also as the 15 nonempty subset words
with P_i-C_i in selected slots and C_i otherwise.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path

import numpy as np


BALANCED = tuple(e for e in itertools.product((1, -1), repeat=4)
                if sum(e) == 0)


def von_mangoldt_table(nmax: int) -> np.ndarray:
    """Exact Lambda(n) for n <= nmax, including all prime powers."""
    nmax = int(nmax)
    prime = np.ones(nmax + 1, dtype=bool)
    if nmax >= 0:
        prime[:2] = False
    for p in range(2, int(math.isqrt(nmax)) + 1):
        if prime[p]:
            prime[p * p : nmax + 1 : p] = False
    out = np.zeros(nmax + 1, dtype=np.float64)
    for p in np.flatnonzero(prime):
        q = int(p)
        lp = math.log(float(p))
        while q <= nmax:
            out[q] = lp
            q *= int(p)
    return out


def q_matrix(L: float, y: float, delta: np.ndarray) -> np.ndarray:
    """Exact finite-aperture q_{j-k}(y), with the r=0 endpoint retained."""
    r = delta.astype(np.int64, copy=False)
    q = np.empty(r.shape, dtype=np.float64)
    zero = r == 0
    q[zero] = L - y
    nz = ~zero
    rr = r[nz].astype(np.float64)
    # Integer parity also works for negative r and gives q_{-r}=q_r.
    parity = np.where((np.abs(r[nz]) % 2) == 0, -1.0, 1.0)
    q[nz] = parity * L / (math.pi * rr) * np.sin(math.pi * rr * y / L)
    return q


def atom(L: float, T: float, h: float, y: float,
         delta: np.ndarray, index_sum: np.ndarray, eps: int) -> np.ndarray:
    """A_y^eps including the common -2/L^2 normalization."""
    q = q_matrix(L, y, delta)
    phase = eps * (T + 0.5 * h * index_sum) * y
    return (-2.0 / L**2) * q * np.exp(1j * phase)


def gauss_legendre_integral(L: float, T: float, h: float,
                            delta: np.ndarray, index_sum: np.ndarray,
                            eps: int, lo: float, hi: float,
                            order: int) -> np.ndarray:
    """Continuum PNT density integral, C_b^eps = int e^{y/2} A_y^eps dy."""
    nodes, weights = np.polynomial.legendre.leggauss(order)
    ys = 0.5 * (hi - lo) * nodes + 0.5 * (hi + lo)
    ws = 0.5 * (hi - lo) * weights
    out = np.zeros(delta.shape, dtype=np.complex128)
    for y, w in zip(ys, ws, strict=True):
        out += float(w) * math.exp(0.5 * float(y)) * atom(
            L, T, h, float(y), delta, index_sum, eps)
    return out


def trace4(a: np.ndarray, b: np.ndarray, c: np.ndarray,
           d: np.ndarray, dim: int) -> complex:
    return complex(np.trace(a @ b @ c @ d) / dim)


def measure(T: float, lam: float, bins: int, quad: int) -> dict:
    ell = math.log(T / (2.0 * math.pi))
    L = lam * ell
    if L <= 0:
        raise ValueError("T must exceed 2*pi")
    h = 2.0 * math.pi / L
    dim = max(2, int(math.floor(T / h)))
    xmax = int(math.floor(math.exp(L)))
    vm = von_mangoldt_table(xmax)
    ns = np.flatnonzero(vm)
    ys = np.log(ns.astype(np.float64))
    delta = np.arange(dim, dtype=np.int64)[None, :] - np.arange(dim, dtype=np.int64)[:, None]
    index_sum = np.arange(dim, dtype=np.float64)[:, None] + np.arange(dim, dtype=np.float64)[None, :]
    edges = np.linspace(0.0, L, bins + 1)

    # Build plus matrices once; minus is exact complex conjugation.
    Pplus = [np.zeros((dim, dim), dtype=np.complex128) for _ in range(bins)]
    counts = [0] * bins
    for n, y in zip(ns, ys, strict=True):
        b = min(bins - 1, int(np.searchsorted(edges, y, side="right") - 1))
        Pplus[b] += (vm[n] / math.sqrt(float(n))) * atom(
            L, T, h, float(y), delta, index_sum, +1)
        counts[b] += 1
    Cplus = [gauss_legendre_integral(L, T, h, delta, index_sum, +1,
                                     float(edges[b]), float(edges[b + 1]), quad)
              for b in range(bins)]

    def P(b: int, eps: int) -> np.ndarray:
        return Pplus[b] if eps == 1 else Pplus[b].conj()

    def C(b: int, eps: int) -> np.ndarray:
        return Cplus[b] if eps == 1 else Cplus[b].conj()

    pair_labels = list(itertools.product(range(bins), repeat=2))
    out = np.zeros((len(pair_labels), len(pair_labels)), dtype=np.float64)
    out_complex = np.zeros((len(pair_labels), len(pair_labels)), dtype=np.complex128)
    out_raw = np.zeros_like(out)
    out_cont = np.zeros_like(out)
    max_15_err = 0.0
    # Retain per-orientation totals for the finite audit.
    orientation_totals: dict[str, float] = {}

    # Pair products reduce the outer trace assembly to Frobenius inner
    # products: tr((P1P2)(P3P4)) = <(P1P2)^T, P3P4>_F.  This is exact and
    # avoids an O(d^3) multiplication for every outer entry.
    pair_cache_P: dict[tuple[int, int], np.ndarray] = {}
    pair_cache_C: dict[tuple[int, int], np.ndarray] = {}
    for eps in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
        pair_cache_P[eps] = np.stack([P(a, eps[0]) @ P(b, eps[1])
                                       for a, b in pair_labels])
        pair_cache_C[eps] = np.stack([C(a, eps[0]) @ C(b, eps[1])
                                       for a, b in pair_labels])

    # Check all six orientation totals and assemble the real outer matrix.
    for eps in BALANCED:
        label = "".join("+" if e == 1 else "-" for e in eps)
        left_p = pair_cache_P[(eps[0], eps[1])]
        right_p = pair_cache_P[(eps[2], eps[3])]
        left_c = pair_cache_C[(eps[0], eps[1])]
        right_c = pair_cache_C[(eps[2], eps[3])]
        raw_mat = (left_p.transpose(0, 2, 1).reshape(len(pair_labels), -1)
                   @ right_p.reshape(len(pair_labels), -1).T) / dim
        cont_mat = (left_c.transpose(0, 2, 1).reshape(len(pair_labels), -1)
                    @ right_c.reshape(len(pair_labels), -1).T) / dim
        diff_mat = raw_mat - cont_mat
        out_raw += raw_mat.real
        out_cont += cont_mat.real
        out_complex += diff_mat
        out += diff_mat.real
        orientation_totals[label] = float(diff_mat.real.sum())

    # Exact 15-word check on a few representative entries.  The matrix above
    # is already the exact raw-minus-continuum value; this loop only certifies
    # the inclusion--exclusion identity without paying O(d^3) everywhere.
    check_entries = [(0, 0), (0, len(pair_labels) - 1),
                     (len(pair_labels) - 1, 0),
                     (len(pair_labels) // 2, len(pair_labels) // 2)]
    for eps in BALANCED:
        for ri, ci in check_entries:
            b1, b2 = pair_labels[ri]
            b3, b4 = pair_labels[ci]
            pp = (P(b1, eps[0]), P(b2, eps[1]),
                  P(b3, eps[2]), P(b4, eps[3]))
            cc = (C(b1, eps[0]), C(b2, eps[1]),
                  C(b3, eps[2]), C(b4, eps[3]))
            diff = trace4(*pp, dim) - trace4(*cc, dim)
            fifteen = 0.0 + 0.0j
            for mask in range(1, 16):
                factors = tuple(pp[i] - cc[i] if (mask >> i) & 1 else cc[i]
                                for i in range(4))
                fifteen += trace4(*factors, dim)
            max_15_err = max(max_15_err, abs(fifteen - diff))

    # Product-diagonal (Parseval) scale for the raw pair features.  This is
    # a model convention, not a physical-Q normalization.
    prod_diag_sq = 0.0
    centered_pair_diag_sq = 0.0
    for eps in BALANCED:
        ppair = pair_cache_P[(eps[0], eps[1])]
        for u in ppair:
            prod_diag_sq += float(np.vdot(u, u).real / dim)
        # Centered pair is only an auxiliary scale; build it directly.
        for b1, b2 in pair_labels:
            ud = (P(b1, eps[0]) - C(b1, eps[0])) @ (P(b2, eps[1]) - C(b2, eps[1]))
            centered_pair_diag_sq += float(np.vdot(ud, ud).real / dim)
    prod_diag = math.sqrt(max(prod_diag_sq, 0.0))
    centered_pair_diag = math.sqrt(max(centered_pair_diag_sq, 0.0))
    sv = np.linalg.svd(out, compute_uv=False)
    trace = float(np.trace(out))
    fro = float(np.linalg.norm(out))
    op = float(sv[0]) if len(sv) else 0.0
    max_imag = float(np.max(np.abs(out_complex.imag)))
    row = {
        "T": float(T), "lambda": float(lam), "L": float(L), "X": float(math.exp(L)),
        "dimension": int(dim), "xmax": int(xmax), "lambda_support": int(len(ns)),
        "bin_count": int(bins), "bin_edges_log": edges.tolist(), "bin_counts": counts,
        "balanced_orientation_count": len(BALANCED),
        "outer_dimension": len(pair_labels),
        "max_15_word_identity_error": float(max_15_err),
        "max_imaginary_entry_before_real_projection": float(max_imag),
        "orientation_totals": orientation_totals,
        "trace": trace, "frobenius": fro, "top_singular": op,
        "trace_over_product_diag": trace / prod_diag if prod_diag else 0.0,
        "frobenius_over_product_diag": fro / prod_diag if prod_diag else 0.0,
        "top_singular_over_product_diag": op / prod_diag if prod_diag else 0.0,
        "product_diag": prod_diag,
        "product_diag_squared": prod_diag_sq,
        "centered_pair_diag": centered_pair_diag,
        "raw_frobenius": float(np.linalg.norm(out_raw)),
        "continuum_frobenius": float(np.linalg.norm(out_cont)),
        "raw_minus_cont_frobenius_check": fro,
        "status": "finite conditional outer-bin model; no physical-Q membership map",
    }
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--T", nargs="+", type=float, default=[80, 120, 200, 320])
    ap.add_argument("--lambda", dest="lam", type=float, default=.999)
    ap.add_argument("--bins", type=int, default=4)
    ap.add_argument("--quad", type=int, default=24)
    ap.add_argument("--output", type=Path, default=Path("scratch/finite_lambda_outer_matrix_model.json"))
    args = ap.parse_args()
    rows = []
    for T in args.T:
        row = measure(T, args.lam, args.bins, args.quad)
        rows.append(row)
        print(json.dumps({k: row[k] for k in (
            "T", "dimension", "lambda_support", "outer_dimension",
            "top_singular", "trace", "frobenius", "product_diag",
            "top_singular_over_product_diag", "frobenius_over_product_diag",
            "max_15_word_identity_error", "max_imaginary_entry_before_real_projection")},
            ensure_ascii=False))
    fits = {}
    if len(rows) >= 2:
        for key in ("top_singular_over_product_diag", "frobenius_over_product_diag"):
            x = np.log(np.asarray([r["T"] for r in rows], dtype=float))
            y = np.log(np.maximum(np.asarray([r[key] for r in rows], dtype=float), 1e-300))
            slope, intercept = np.polyfit(x, y, 1)
            fits[key] = {"T_exponent": float(slope), "prefactor": float(np.exp(intercept))}
    args.output.write_text(json.dumps({
        "model": "finite q_r/q_0 Gabor atoms + real von Mangoldt (prime powers) + six balanced orientations + exact 15-word raw-continuum subtraction; outer labels are log bins",
        "physical_Q": "undefined; this is a conditional bin-labelled shadow only",
        "rows": rows, "fits": fits,
    }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
