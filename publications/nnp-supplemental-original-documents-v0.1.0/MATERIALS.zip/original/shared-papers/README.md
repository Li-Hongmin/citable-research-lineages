# P versus NP 项目论文总表

本表是三个数学单元的统一入口。原则是“一个可独立陈述的重要贡献对应一篇论文”；
条件性闭合和路线边界会明确标注，不把它们写成已经解决 \(P\) versus \(NP\)。

## 独立论文

| 单元 | 论文 | 贡献类型 | 证据边界 |
|---|---|---|---|
| RW/JK | [Shared-Proof Coordinate Robustness Implies Relaxed Local Decoding](../units/rw-jk-succinct-reconstruction/papers/01-shared-proof-coordinate-robustness-implies-relaxed-local-decoding/paper.md) | 共享 proof 坐标鲁棒性到 relaxed-LDC 的统一编译 | 已证明的构造—下界定理 |
| RW/JK | [Distributional Soundness Does Not By Itself Produce a Global Word](../units/rw-jk-succinct-reconstruction/papers/02-distributional-soundness-does-not-produce-a-global-word/paper.md) | 分布式 soundness 与同一 global word 的量词分离 | 已证明的桥接与反例 |
| RW/JK | [Cover Obstructions for Shared-Top Direct-Product Tests](../units/rw-jk-succinct-reconstruction/papers/03-cover-obstructions-for-shared-top-direct-product-tests/paper.md) | BMVY/DDL 源族的 shared-top cover obstruction | 源特定已证明定理 |
| RW/JK | [From Address-Scale Smart Reconstruction to P/poly](../units/rw-jk-succinct-reconstruction/papers/04-from-address-scale-smart-reconstruction-to-p-poly/paper.md) | smart reconstruction 到 \(P/\mathrm{poly}\) 的条件性闭合 | 条件性定理，不是 \(P\ne NP\) 证明 |
| RW/JK | [Target Information versus Proof Length in Shared-Proof Coordinate Verification](../units/rw-jk-succinct-reconstruction/papers/target-information-versus-proof-length/paper.md) | target-selected policy 的互信息、proof length 与 RLDC locality 相图 | 已证明的信息—编码定理；期刊主稿 |
| THR∘THR | [A Single Modular Character Is Complete for SYM∘LTF Counting](../units/thr2-lower-bounds/papers/01-a-single-modular-character-is-complete-for-sym-ltf-counting/paper.md) | 单一无权 modular character 对 SYM∘LTF-CAPP 的完备性 | 精确表示定理 |
| THR∘THR | [Uniform Active-Count Tightness for LTF Restrictions](../units/thr2-lower-bounds/papers/02-uniform-active-count-tightness-for-ltf-restrictions/paper.md) | 近乎正交 LTF 族的 uniform active-count 紧界 | 结构性障碍定理 |
| MCSP | [Exact Gap-MCSP to Approximate-MCSP: A Quantitative Boundary](../units/mcsp-hardness-magnification/papers/01-exact-gap-mcsp-to-approximate-mcsp-boundary/paper.md) | exact-to-approximate promise 的精确距离与指数边界 | 定量边界定理 |
| MCSP | [Truth-Table Quotients Do Not Close One-Tape MCSP Magnification: Small Fibers and Exact Cosets](../units/mcsp-hardness-magnification/papers/02-truth-table-quotients-do-not-close-one-tape-mcsp-magnification/paper.md) | 非单射 fiber-corrected 阈值计数、almost-everywhere XOR dispersion、exact coset additive-doubling 与 average arbitrary-quotient defect/inflation 二分 | 可复用编码障碍定理 |

## 技术档案

[Address-Scale Barriers for Shared-Proof Coordinate-Robustness](../units/rw-jk-succinct-reconstruction/papers/Address-Scale-Barriers-for-Shared-Proof-Coordinate-Robustness/paper.md)
是 RW/JK 的长综合稿，保留完整技术链和交叉引用，但不作为额外贡献计数。

[Shared-Proof Coordinate Robustness: Relaxed Local Decoding, Bottom Escape, and Compiler-Class Barriers](../units/rw-jk-succinct-reconstruction/papers/05-shared-proof-coordinate-robustness-barriers/paper.md)
保留期刊主稿裁切前的扩展 barrier 材料；其 partition、folding、FRI 与 RW 专属结果不再
并入期刊主线。

## 尚未晋级为独立论文的材料

MCSP 的 Formula--XOR/CJW、Atserias--Müller 接口和若干 affine/thinning 结果已在
[MCSP 论文地图](../units/mcsp-hardness-magnification/papers/README.md)中分层；它们要么
是条件性接口，要么只关闭单一路线，尚未形成新的共同正向主定理。
