# Line Gates and Orbit Bounds in Binary Group Algebras

[论文 PDF](line-gates-and-orbit-bounds-in-binary-group-algebras.pdf) ·
[LaTeX 正文](line-gates-and-orbit-bounds-in-binary-group-algebras.tex) ·
[精确计数源码与输出](../../computations/bundles/exposed-column-rank-count/README.md)

本文研究二元群代数中的四点线门、独立 augmentation-one 线单位的精确存活概率，以及
多线性 Boolean phase 沿目标线的完整轨道恒常性。正文包含自足证明，不以旧计算自述
代替证明。q=16、rho=3、E={0,1} 的 224 个归一化斜率与三个非零关系已全部精确计数；
672 项均符合列暴露界，并与独立逐列真值表参照相同。

一般 singleton 方向在固定密度 kappa<1 的轨道上界、重复斜率族的 Poisson 极限、四点门
的随机单位存活律，以及高密度轨道下界属于不同的量词范围。generic kappa=1 窗口仍是
公开问题；rho=2n 仅为本文四点门支持下界的阈值，不宣称真实交叉线相变已被确定。

## 数学依赖

1. [Note 917](../../notes/917-arbitrary-slope-singleton-cross-line-has-average-row-rank-2026-09-02.md)：列暴露及平均行秩；正文明确加入零对角，并保留精确单列概率。
2. [Note 909](../../notes/909-canonical-cross-line-line-sum-has-role-count-threshold-2026-09-02.md)：重复斜率的 active-set 与 Poisson 极限；证明在正文完整重述。
3. [Note 922](../../notes/922-three-coplanar-actual-rs-lines-have-a-sharp-four-point-gate-2026-09-02.md)：四点门与最小支持；正文直接排除两点平移稳定子。
4. [Note 923](../../notes/923-random-augmentation-one-units-interact-with-four-point-gates-2026-09-02.md)、[924](../../notes/924-two-random-line-units-have-exact-quotient-law-and-high-role-orbit-saturation-2026-09-02.md)、[925](../../notes/925-three-secant-line-units-force-a-cartesian-support-collapse-2026-09-02.md)：商化、单/双单位及三定义线任意重复次数律。924 的系数推前纤维已改为 2^(q-q/h_i)，概率式不变；925 末尾未独立核验的 outsider 枚举例未纳入正文。
5. [Note 926](../../notes/926-fkg-sharpens-four-point-orbit-saturation-boundary-2026-09-02.md)：Harris 下界、奇支持平均与同线事件恒等式；正文区分逐 A 的改进与 4q² 粗化，并限定为一个线支持单位的轨道。

## 文献定位与证据边界

检索日期为 2026-09-05。按 paper-lib 的 decision search，在 OpenAlex 检索
normalized units / elementary abelian、random group-algebra units（含 2020–2026
窗口）及 Reed–Solomon/group-algebra 关联，并以 DOI 核对正文四条引用；Semantic Scholar
返回限流。检索到的近期 normalized-unit 工作主要处理非交换群结构，不能替代本文的
加法商空间计数。本文不作绝对首创声明。

Borello–Willems–Zini 的原始预印本 arXiv:2202.12621 已读引言和相关定义；其
Corollary 2.6 给理想的 d(C) dim(C) >= |G|，相关 Schur product 为逐坐标乘积。
它提供群代数支持与理想的背景；本文门的精确卷积存活律不作为该文结论引用。
记录与可用全文保存在 ResearchLibrary；已读预印本位于
`[unmapped-local-locator]`。

Reed–Solomon、Harris、FKG 的 DOI、作者、年份及页码已核对；本轮未取得这三篇的可读
原始全文。FKG 自动获取返回访问页面，浏览器回退无可用实例；Harris 与 Reed–Solomon
在已取得的元数据中未提供开放全文。它们用于经典方法及术语归属，正文所用正关联、
群代数恒等式与计数论证均自足给出。此范围不等于全面优先权核查。

## 构建

在本目录执行：

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error line-gates-and-orbit-bounds-in-binary-group-algebras.tex
```

此目录是可继续修改的独立组合论文工作稿。正式投稿、发送或公开发布保留人工确认；
本地组合稿和计数核验不需要 human gate。
