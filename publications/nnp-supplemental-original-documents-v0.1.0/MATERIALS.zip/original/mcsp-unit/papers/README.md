# 论文地图：MCSP hardness magnification

本单元按数学机制区分可复用定理与局部路线关闭，不把若干 no-go note 拼成没有共同主定理
的综述。论文 02 已把 dummy padding 的参数现象提升为所有常数 log-length 扩张、
YES-preserving truth-table maps 的 fiber-corrected 计数障碍；其余只关闭单个候选
transfer 的材料继续留在 notes。

## 独立组合论文

[Line Gates and Orbit Bounds in Binary Group Algebras](line-gates-and-orbit-bounds-in-binary-group-algebras/README.md)
给出四点线门、随机 augmentation-one 单位的精确存活律、列暴露及轨道密度界；完整包含
q=16、rho=3、E={0,1} 的 672 项精确计数。generic kappa=1 窗口保持开放。

## 当前分层

| 层级 | 材料 | 数学内容 | 处理 |
|---|---|---|---|
| 01 | [Exact Gap-MCSP to Approximate-MCSP: A Quantitative Boundary](01-exact-gap-mcsp-to-approximate-mcsp-boundary/paper.md) | 单点 truth-table 修补给出精确的绝对距离下界，并量化它与 Atserias--Müller 固定距离阈值之间的指数缺口 | 边界定理论文；不宣称 \(P\ne NP\) |
| 02 | [Truth-Table Quotients Do Not Close One-Tape MCSP Magnification: Small Fibers and Exact Cosets](02-truth-table-quotients-do-not-close-one-tape-mcsp-magnification/paper.md) | Lupanov junta 给出 \(\log|\mathcal L_S|=\Theta(\min\{2^n,S\log S\})\)；Harper 增长强制任意最大 YES-fiber 几乎处处 XOR-dispersed，并给出 \(\log(|\mathcal L_S+\mathcal L_S|/|\mathcal L_S|)\ge((1-\mu)/2-o(1))S\)，从而排除 fixed-exponent exact coset／affine quotient；任意剩余 quotient 在无序 fiber-pair 与 occupied-fiber 的平均层面必有 \(2^{\Omega(S)}\) XOR-image defect 或 sumset-fiber inflation；条件 materialization 窗口恰为 \(\max\{b,\kappa a\}<2\mu_H\) | 可复用 semantic-entropy／XOR-dispersion／additive-doubling 编码障碍；剩余 exact 编码必须使用 predicate-specific non-coset fibers，并在计算上实现该结构爆炸，倍增及更大 gap 仍开放 |
| 03 | [Tight Ordered Width for Exponential-Threshold MCSP](03-tight-ordered-width-for-exponential-threshold-mcsp/paper.md) | 对固定 \(0<\mu<1\)、\(S=2^{\mu n}\)，任意全局 truth-table 顺序的严格分层 deterministic/NOBDD/parity OBDD 与 exact field-weighted ordered ABP 都有中层宽度 \(\log W=(1+o(1))S\log S\)；平衡切割上的 Fourier quotient、双侧可恢复 easy family 与 equality graph 给出近最大 identity submatrix | 独立 ordered-model MCSP 定理候选；不覆盖 free/path-dependent BP、one-tape 时间、一般电路或 \(P\ne NP\) |

| 独立主定理候选 | Formula--XOR / sparse NP magnification | CJW 给出“若 Formula--XOR 下界成立则放大”的严格推论；当前缺少目标 Formula--XOR/GapMCSP 下界本身 | 暂不写投稿正文；保留为条件性接口 note |
| 文献/接口地图 | Atserias--Müller uniform magnification | 明确 approximate promise、PFML/Formula 模型和指数的三重失配 | 作为文献矩阵与路线裁决，不单独成稿 |
| 结构性关闭 | affine-disperser、collision potential、thinning 等 | 只关闭各自的候选 transfer，不构成共同主定理 | 留在 notes 与计算 bundle |

Proposition 9 adds a branch-forcing exact quotient whose fresh-output materializer must satisfy
\(\max\{b,k\}\ge2\mu_H\). Proposition 10 adds the conditional joint boundary-state inequality
\(\log W_Q+\log W_D=\widetilde{\Omega}(S)\) for synchronous prefix-consistent handoff.
Corollary 11 turns an \(\ell\)-bit description bound on \(Q(A+A)\) into an occupancy lower
bound; circuit-described target families give \(\ell=O((T+1)\log(n'+T+2))\). These close only
explicitly specified models, not every predicate-specific quotient. Corollary 12 further gives
a delayed-output state--occupancy tradeoff, and Corollary 13 charges an early-output budget
explicitly. Corollary 14 converts it to a one-tape time--space--occupancy inequality.
Corollary 15 records the sub-\(S\) resource dichotomy under low occupancy inflation.
Corollary 16 records the resulting exponent boundary \(b\ge\mu_H\).
Corollary 17 states the conditional closure
\(\max\{b,\kappa c,\kappa a\}\ge2\mu_H\) for evaluable descriptors.
Corollary 18 gives the complementary target-NO range richness on \(Q(A+A)\).
Corollary 19 converts this richness into a descriptor-image lower bound (without an injectivity
assumption), with an \(r\)-bit advice extension; under an explicit exact-enumeration/output-rate
interface it also gives a total output-volume time lower bound. It does not imply a comparable
lower bound for a single descriptor evaluation. Corollary 20 gives the exact
range--occupancy factorization for every pointwise-exact quotient and proves its cardinality
tradeoff is sharp via the two-label predicate map.
Proposition 21 gives the unconditional quadratic-composition boundary
\(\max\{b,\kappa a\}\ge\mu_H\), while the \(2\mu_H\) boundary still requires an explicit
handoff interface.
Corollary 22 gives the short oracle-descriptor boundary
\(\max\{1,b\}+2\delta\ge2\mu_H\); it does not cover arbitrary implicit quotients.
Corollary 23 strengthens this to adaptive oracle transcripts: the exponent uses the maximum
query length, independently of the number of queries (which is charged to the time). Static
random-access evaluators with a fixed membership-sufficient relation are included; source-reading
evaluators and uncharged RAM/oracle access are explicitly outside the model.
Corollary 24 replaces the worst-case \(2^\ell\) query universe by the actually reachable
query-family size \(D_N\), while tracking the logarithmic state mass \(\log q_N\). This is
strictly sharper for structured long queries.
Proposition 25 gives an orthogonal exact barrier for source-dependent random access when source
access is charged as ordinary bit probes: an exact decision tree must inspect \(N-o(N)\) bits.
Proposition 26 extends this to bounded-error randomized probes with the sharp sparsity-only factor
\((1-2\varepsilon)/(1-\varepsilon)\); vanishing error recovers \(N-o(N)\).
Proposition 27 factors any interactive target evaluator through its charged source-bit decision
tree, and Proposition 28 gives the conditional asynchronous handoff/state boundary when the
payload is fully charged.
Proposition 29 extends the latter to arbitrary interleaving during the known-order source scan:
all counted payload content and target control fold into a width-
\((N+1)W_QW_D2^h\) ROBP, yielding the same charged-state boundary. Hidden source-dependent RAM,
pointer payloads, and omitted oracle fields remain explicit model escapes.

Derivation note: [unconditional quadratic composition boundary](../notes/514-unconditional-quadratic-composition-boundary-2026-08-24.md).
The oracle-descriptor derivation is in
[note 515](../notes/515-short-oracle-descriptor-boundary-2026-08-24.md).
The adaptive transcript extension is in
[note 516](../notes/516-adaptive-short-oracle-transcript-boundary-2026-08-24.md).
The query-family refinement is in
[note 517](../notes/517-query-family-state-tradeoff-2026-08-24.md).
The exact source-probe barrier is in
[note 518](../notes/518-exact-random-access-source-probe-barrier-2026-08-24.md).
The bounded-error extension is in
[note 519](../notes/519-bounded-error-source-probe-boundary-2026-08-24.md).
The charged-source and handoff extensions are in
[note 520](../notes/520-charged-source-interface-and-handoff-boundary-2026-08-24.md).
The interleaved handoff extension is in
[note 521](../notes/521-interleaved-handoff-boundary-2026-08-24.md).
Its fixed-alphabet machine consequence is in
[note 522](../notes/522-fixed-alphabet-time-space-payload-boundary-2026-08-24.md).
The hidden-continuation extension is in
[note 523](../notes/523-hidden-continuation-complexity-boundary-2026-08-24.md).

## 论文晋级标准

下一篇 MCSP 论文必须至少满足以下之一：

1. 给出一个对参数族有统一量词的正向 magnification/transfer 定理，并明确保持 promise、模型和输入长度；或
2. 给出一个可独立复用的 impossibility/barrier theorem，直接覆盖一个公认的 magnification 接口，而不是只关闭一个参数猜想；或
3. 把 Formula--XOR、one-tape、approximate-MCSP 中至少两条路线通过同一个新的数学机制统一起来。

在满足条件前，论文地图本身是权威入口；不会把“已证明的路线关闭”写成 \(P\ne NP\)，也不会把
条件性 CJW/Atserias--Müller 推论冒称为项目的新下界。

## 关键来源

- [Formula--XOR 的稀疏放大推论](../notes/065-cjw-sparse-formula-xor-magnification-corollary-2026-08-14.md)
- [Atserias--Müller 接口](../notes/064-atserias-muller-uniform-magnification-interface-2026-08-14.md)
- [Exact Gap-MCSP 到 approximate-MCSP](../notes/066-exact-gap-approximate-perturbation-interface-2026-08-14.md)
- [One-tape 阈值重标定](../notes/068-one-tape-threshold-rescaling-dummy-padding-boundary-2026-08-14.md)
- [Affine-disperser gate-elimination 边界](../notes/072-gapmcsp-affine-disperser-gate-elimination-boundary-2026-08-14.md)
