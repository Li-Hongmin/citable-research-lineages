# RW pulse3 checkpoint — 2026-10-03

**Completed bounded obligation:** exact weighted full-field first separator X sum, after the previous complete Y, two-beacon and spare W sums. The proof is rw-pulse3-complete-x-projection.md. This changes the remaining question from pointwise survival to a precise same-source scalar projection:
\[
\sum_{X\in F}\mathcal B_x(X)
=G_xL_0(y)^2(1+(D\eta)^2)^{U_4}
[(A+c)P_0(1)+\mathfrak bP_5(1)],
\]
\[
\mathfrak b=\eta^{2u^5}[(A+c)D^{2u^5}+cdC^{2u^5}].
\]
The source moments and background must be independent of X with other first coordinates and the same permitted third remainder fixed. G_x is independent of X; the original Gamma_x is G_x L_0(X)^2. Forgetting this public weight would compute a different sum.

For the off-grid-only total add G_x L_0(y)^2(A+c)c_0. Only X=0 contributes on the grid. The extension at grid points is the raw denominator-cleared polynomial, never the rational z expression.

## Evidence and claim grading

| Claim | Status in this bounded round | Boundary |
|---|---|---|
| General moment and seven basis sums | Proved by field power sums and base-u residues; finite check agrees | Degree at most 2u-2 for the three factors, specified powers, full F |
| Weighted complete-X formula | Proved algebraically | Input interface and all fixed coefficients must satisfy the same-source assumptions |
| RW public weight Gamma_x=G_x L_0(X)^2 | Locally checked in 605/610/612/614/616/619/620 | This is not a fresh full certification of their upstream route/checker chain |
| Canonical F4 paired-source cancellation | Explicit exact synthetic example, polynomial moments checked | Boolean grid and endpoint zeros do not imply actual RW reachability |
| This particular toy is excluded from the full actual section | Conditional support proof | Actual two-line identity, nonzero ledger multiplier and at least two ones in hard suffix |
| Actual projected scalar nonzero or zero | Open | Actual moments cannot be selected independently; hard-word complexity alone has not been connected to this projection |
| Earlier pulse2 fixed-X density | Retained conditional result | It does not imply nonzero complete-X sum |
| Remaining outer sums, real defects, other norm orbits, trace, JK response and main conjecture | Open/unreviewed beyond prior local interfaces | No promotion to a formal project theorem |

The synthetic example uses mu even >=4, p=0,q=1, O=L_omega, V_0=0,V_1=L_0, omega^2+omega+1=0. It has
\[
(c_0,c_2,c_\kappa,c_T)=(1,\omega,0,\omega^2),\quad
c_T\ne0,\quad P_0(1)=P_5(1)=0.
\]
Thus the paired canonical constraints and highest coefficient alone are insufficient. At the same time, a full actual section difference has its hard-suffix support equal to that of S_0 when its ledger multiplier is nonzero, so the singleton toy is excluded under the stated support/hardness assumption. The example is not a reachable counterexample or a NOGO witness.

## Review and reproduction

New-context reviewer /root/rw_x_sum_review independently derived the exact public weight and complete-X formula, and checked the toy and its support exclusion. Same-model review is explicitly weaker than independent-model or human certification. It supplied separate C code for the seven raw basis expressions; only existing verified field arithmetic was reused.

A meaningful reviewer error is retained: its initial analytic report used H=s+rv, which drops a factor. I flagged it and the reviewer corrected H to s(1+rv). With degree <=2u-2 the no-carry argument still holds. The final result and the raw enumeration were unaffected. The corrected proof is in the candidate.

Reproduce in task-6:

~~~sh
python3 rw_field_modulus_check.py
cc -O2 -Wall -Wextra rw_xsum_check.c -o [anonymous-historical-runtime-locator]
[anonymous-historical-runtime-locator]
python3 rw_f4_toy_check.py
~~~

The modulus proof from the sealed packet remains unchanged. The new full-X run checks u=8, a_o=14090, k=0,1,73951 and every X in GF(2^18); all seven full sums are respectively 1,0,222249. Their off-grid corrections also pass. The packaged run completed in about 2.27 seconds, compilation exit0 and no warnings. u=8 is an algebra check, not a claimed admissible actual RW parameter. The small F4 coefficient check passes u=16,64,256 without enumerating their full fields. Raw output is retained in rw-pulse3-xsum-check-output.txt and rw-pulse3-f4-toy-output.txt.

## Preservation and authorization boundary

At startup all348 original-unit fingerprints still matched pulse2's final snapshot, and every listed pulse2 packet hash matched. No process inspection was retried after the earlier raw system rejection, zsh:1: operation not permitted: ps. The rejected operation was process listing; no project write rejection or automatic approval rejection occurred. Background writer ownership remains UNKNOWN. Consequently the original project and unit stayed read-only, all new files are in task-6, and no lock was acquired.

The old research Goal remains paused; no original research session, Hermes or cron was resumed. No Git mutation, HPC/SAT/remote/cloud/payment/account/credential/Drive/upload/signing-key/DOI/publication action occurred. Other three lines and prohibited projects were not touched. Sealed pulse2 material was not edited. Final snapshot and pulse2 hash verification are rw-pulse3-final-preservation.json; rw-pulse3-delivery-manifest.json records the new packet versions and exact original dependency hashes.

## Next bounded mathematical obligation

Prove or refute, for the same actual section and permitted remainder,
\[
(A+c)P_0(1)+\mathfrak bP_5(1)\ne0
\]
on a nonempty usable set with D eta!=1. On A=c with c,d,C,eta!=0, the unknown reduces to P_5(1)!=0. Determine whether actual source structure controls that fixed projection before pursuing further coordinate sums. Do not replace this task by another pointwise density/root bound, declare the toy reachable, select source moments independently, or infer hard-word complexity implies a nonzero parity without proof. Address-scale evaluation of these charged moments is itself unproved.

For the unified Commons contribution coordinator, this packet offers the self-contained general moment, seven-basis projection and explicitly synthetic F4 example. It is a private candidate, not a submission. Human authorship/consent, ownership/release permission, AI-role disclosure, content and code licenses, bibliography, novelty and external validation are still missing. The existing CRL public pilot remains under the parent coordinator. This round stops here with a complete reviewable mathematical checkpoint.

## Final verified handoff

The final snapshot has348 files and no changed path, size, mtime or SHA256 relative to pulse3 startup. All11 files listed in the sealed pulse2 manifest still match. A final supported read_thread reports the original thread idle, unchanged updatedAt=1791026156, and the same completed closure turn whose final message reports the Goal paused. This is supported thread evidence, not a newly queried Goal-state JSON. No hidden-writer absence is inferred.

The fresh-context reviewer inspected the final proof artifact and found no new substantive error in the corrected moment, seven pairings, grid extension or toy exclusion. Its correction and final assessment are retained in rw-pulse3-review-record.md.
