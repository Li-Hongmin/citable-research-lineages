# RW pulse4 checkpoint — 2026-10-03

**Changed mathematical judgment:** a conditional sufficient theorem now permits nonzero actual complete-X padding subtable values after complete X,Y,Z_1,Z_2,W sums, at one common independent **first-spare value w**. The third remainder stays fixed. The old fixed diagonal projection remains unknown; the complete first-spare sum remains open.

The proof is rw-pulse4-separated-first-spare.md. Separate w from the fixed two first-beacon values T_b. Actual621 source geometry gives
\[
V_i(w,Z)=L_0(w)\widetilde V_i(Z),\quad
O(w,Z)=L_{a_k}(w)\widetilde O(Z).
\]
Thus the old complete-X projected coefficients obey
\[
P_0(1;w)=L_0(w)^{d_*}Q_0(z),\quad
P_5(1;w)=L_0(w)^{d_*}Q_5(z),\quad z=w/(w+a_k),
\]
where Q_0,Q_5 have the same real-source four/three-term pattern and common q_T!=0 inherited from the old selected point. No source moments were selected freely.

With alpha=A+c and b_0=alpha D^(2u^5)+cd C^(2u^5), the remaining scalar is proportional to
\[
\alpha Q_0(z)+b_0w^{4-\kappa}Q_5(z).
\]
For fixed beacon values and the same permitted third remainder, A,c,D,C are independent of w. Its denominator-cleared polynomial has degree at most8u^5+6 and is nonzero whenever alpha!=0 or b_0!=0. On alpha=0, the previous beacon condition c,d,C!=0 gives b_0!=0.

The exact off-grid D eta=1 classification is: u-1 bad w if D belongs to mu_M minus{1}, and zero otherwise, including D=0 or1. Consequently each eligible edge loses at most8u^5+6+(u-1) off-grid values. A root average selects one common w retaining all but O(1/u) of the inherited eligible edges for sufficiently large legal lengths. This covers that one padding subtable at other coordinates still fixed.

## Precise assumptions and unresolved boundary

Required actual interfaces: the legal single-line beacon/checker support asserted in621; first-spare place k above every non-OUTPUT nonzero source digit; OUTPUT digit a_k!=0; the prior source/route/density and complete-contraction claims; one fixed permitted third remainder; nonzero fixed public factors; q_T!=0 on the inherited edge set; fixed T_b with C!=0 on A=c. The full upstream chain is not newly certified merely by satisfying local formulas.

At an unchanged first tuple the exact same-source compression is
\[
P_0(1)=J^2,\quad P_5(1)=(J+N)^2,\quad
S=(\alpha+\beta)J^2+\beta N^2.
\]
The source moments J,N remain charged and unknown. The new sufficient theorem instead uses the actual Lagrange dependence on w. It does not determine the value at the original diagonal, assert an address-scale source evaluator, or turn the F4 singleton toy into an actual RW counterexample.

Complete first-spare summation, other outer sums, added real defects, norm orbits, trace, auxiliary proof tables, JK response and the main conjecture are open. Next bounded obligation: complete the first-spare sum using the exact public weight and source scaling; fixed-w density is insufficient.

## Independent-context review and reproduction

New-context same-model reviewer /root/rw_projection_source_review independently derived J,N, checked the separation of first-beacon and first-spare values, the real source support, q_T inheritance, scalar clearing and public factors. This is not independent-model or human certification.

~~~sh
cc -O2 -Wall -Wextra rw_spare_projection_check.c -o [anonymous-historical-runtime-locator]
[anonymous-historical-runtime-locator]
~~~

The check uses GF(2^18), u=8 and synthetic canonical grid sections. It recomputes moment coefficients at64 spare values, tests source scaling and highest-coefficient inheritance, then checks the scalar with fixed beacon T_b in A=c and A!=c branches. It separately enumerates D eta=1 roots in four norm cases, returning0,0,7,0. The corrected run passes without warnings in about0.38 seconds. This checks algebra, not actual RW data or admissible asymptotic parameters.

One initial compile failed from nested includes redefining main. The raw failure is retained in rw-pulse4-scaling-check-output.txt. The new source now includes only prior field arithmetic and reconstructs canonical moments locally. Success is retained separately in rw-pulse4-scaling-check-passed-output.txt; no sealed source was changed.

## Preservation and Commons boundary

Startup verified all348 original-unit files unchanged and all files listed in the pulse2 and pulse3 manifests still matching. No process inspection was retried after the earlier system denial; background writer visibility remains UNKNOWN. The original project remained read-only; new files exist only in task-6. No Git mutation, old Goal/Hermes/cron resumption, HPC/SAT/remote/cloud/payment/account/credential or external-publication action occurred.

The source task and old research thread remain the previously recorded ones. Final snapshot and manifest provide preservation/version evidence; no original claims or errors were overwritten. This theorem is a private possible contribution for the parent's unified Commons work, with actual interfaces and outer-sum limits attached. Authorship/consent, ownership/release permission, AI disclosure, content/code licenses, bibliography, novelty and external validation remain missing. No automatic upload, key or DOI was created.

Final preservation confirms348 original files unchanged in path, size, mtime and SHA256. All11 pulse2 deliverables and all9 pulse3 deliverables still match their sealed manifests. The supported final thread read reports the old research thread idle, unchanged updatedAt=1791026156 and the same closure turn reporting Goal paused. Writer process ownership remains UNKNOWN.

The reviewer accepted the final proof as a conditional local nonzero theorem, independently checking the exact norm-image classification, source scaling, public factor and fixed-third Cartesian interface. Its assessment is preserved in rw-pulse4-review-record.md. No complete first-spare or adjacent outer-sum claim was added.
