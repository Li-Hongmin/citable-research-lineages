# RW bounded pulse2 checkpoint — 2026-10-03

Outcome: the complete paired first-last-digit source sum imposes a new exact constraint, stronger than generic local609.7 shape. Under621's stated source/route/density assumptions, it permits a common first tuple for which many actual falling edges survive the complete \(Y,Z_1,Z_2,W\) padding-subtable sum. This remains one subtable at fixed other coordinates, before other sums, defects, norm orbits and trace.

## Exact new result

The self-contained proof is rw-pulse2-paired-source-factorization.md, equations(1)–(2). For any canonical sections with common output \(O(p)=O(q)=0\), complete \(Z\) integration gives
\[
H_x(w)=(1+w)^{U_4}(a_{x,\varnothing}+a_{x,\{5\}}w^{u^5}),
\qquad H_{x,[5]}(w)=a_{x,\{5\}}(1+w)^{U_4}.
\]
This holds as an ordinary polynomial identity of degree below \(Q\). It applies to the actual source split614.17/614.25 because its OUTPUT is \(\lambda L_o\) with \(o\ne p,q\). No honest source coefficients are selected independently.

Thus the previous local abstract root at arbitrary \(\sigma\ne1\) cannot realize cancellation in the actual complete paired source if \(a_{\{5\}}\ne0\). The previous example and its finite check remain intact as a local-shape example; they were never a claimed reachable RW counterexample. The integral still vanishes at \(\sigma=1\), so excluding a pointwise root is insufficient.

## Completing the actual-source gate

Retain the prior exact complete-spare formula and all32 basis checks. With \(\eta=y^{2(u-1)}\), \(t=X^{2(u-1)}\), \(\sigma=(tD_x\eta)^2\), its bracket becomes
\[
s^{d_*}(1+\sigma)^{U_4}
\left[\mathfrak a_xP_0(z)+\mathfrak b_xt^{2u^5}P_5(z)\right],
\quad
\mathfrak a_x=A_x+c,\quad
\mathfrak b_x=\eta^{2u^5}\left[(A_x+c)D_x^{2u^5}+cdC_x^{2u^5}\right].
\]
The normalized \(P_0,P_5\) are exactly the four/three-term polynomials from614.19/621.3, with common highest coefficient \(c_T\ne0\). The degree claim belongs to these normalized polynomials, never to \(s^{d_*}P_j\), and not directly to their substitution at changing \(\sigma(X)\).

If \(A_x=c\), the selected \(C_x\ne0\) makes the second coefficient nonzero. If \(A_x\ne c\), field reduction and clearing a nonzero off-grid denominator yield a polynomial \(R_x(z)\) of degree at most \(8u^5+6\). Its leading coefficient is \((\mathfrak a_x+\mathfrak b_x)c_T\) when the scalars differ. When they coincide, a separate expansion has leading coefficient \(c_\kappa\) at degree \(2\kappa+4\), or \(c_T\) at \(2\kappa+2\); it is also nonzero. Hence the two actual terms cannot vanish identically.

The prefactor's \(\sigma=1\) set costs at most \(u-1\) additional first-coordinate values. Bad fractions are \(O_C(1/u)\). Combined with621's first \(y\) average giving \(c_T\ne0\), a second \(X\) average leaves a constant proportion of the same reached falling edges, for sufficiently large legal lengths.

Essential assumptions: fixed common third remainder and other first coordinates before \(X\) selection; \(A_x,c,D_x,C_x,\eta,c_j\) independent of \(X\); OUTPUT endpoint zeros; truly free coordinate fields; the source split and original checker/route/density claims of621. These are explicit actual-source interfaces, not a fresh full audit of517 and the published paper. No per-edge values or extra advice are introduced.

## Verification and disagreement preserved

- New fresh-context agent /root/rw_actual_gate_review independently derived the mixed moment and kernel factorization and verified the rational clearing/leading terms. Its initial norm-image formula used \(\eta=L_0(W)\), a pointwise-before-spare-sum parameter. I rejected its application to the complete-spare gate; the reviewer acknowledged the correction. Here \(\eta=y^{2(u-1)}\), and the bad root is in \(X\).
- The review is same-model, not independent-model verification. The complete upstream geometric/reached-source chain is still not externally certified.
- New lightweight C code directly evaluates all32 complete-\(Z\) coefficients for two deterministic synthetic canonical source pairs. It verifies the normalized coefficient formulas and every off-grid rational-clear identity, with both equal and unequal scalar choices. Both pairs passed, in3.11 seconds. Synthetic sections are not actual RW inputs; the large-\(u\) bad-root bound is analytic, not inferred from \(u=8\).
- Previous all32 complete-spare basis checks, field-modulus proof, local abstract examples, source files and raw outputs were retained. New raw results are rw-pulse2-kernel-check-output.txt.
- One attempt to create the new Markdown via a JavaScript raw template failed before execution with SyntaxError caused by Markdown backticks. No file was created by that failed call. The corrected task-workspace patch succeeded; no original file was involved.

## Preservation and delivery

Startup read_thread again reported the original research thread idle, with no new turn. Compared with pulse1's final snapshot, all348 original-unit files were unchanged. No process inspection was retried after the previous system rejection; background writer ownership remains unknown. The entire original project remained read-only. No Git mutation, remote/HPC/SAT/cloud/payment/credential/Drive/publication/key/DOI action occurred.

rw-pulse2-startup-preservation.json and rw-pulse2-final-preservation.json retain the complete assigned-unit fingerprints. rw-pulse2-delivery-manifest.json records SHA256 versions of the deliverables and referenced original dependencies. Nothing in the original unit was promoted or edited.

For the unified Commons contribution task, the smallest self-contained result is the mixed edge moment and paired-kernel corollary; the reached RW density consequence must retain its conditional label. Parent was notified of the new constraint and subsequent gate result. Novelty, original-paper bibliography, human authorship/consent, AI-role disclosure, permission, content/code licenses and external review remain for that coordinator. No independent publication was attempted.

Next bounded obligation: evaluate or bound the remaining complete **first separator \(X\) sum**, including its exact public weights, before varying other first coordinates or adding any actual defects. Positive density at fixed \(X\) is again insufficient. The existing source moments remain unknown and their address-scale evaluation cost is unproved. Other outer sums, trace, real defects, norm orbits, full JK response and the main conjecture stay open. Stop this pulse at the completed four-coordinate subtable gate.
