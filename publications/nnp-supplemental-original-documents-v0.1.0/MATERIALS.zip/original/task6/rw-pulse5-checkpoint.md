# RW pulse5 checkpoint — 2026-10-03

**Completed:** the full first-spare w sum, with its actual public L_0(w)^2 weight and source scaling, at fixed beacon values T_b and the same permitted third remainder. There was no new root average or recomputation.

The proof is rw-pulse5-complete-first-spare.md. In the notation of pulse4,
\[
\sum_{w\in F}\mathcal F_x(w)
=\overline G_x(1+D_x^2)^{U_4}
[(\alpha+b_0)J^2+b_0N^2],
\]
where alpha=A_x+c, b_0=alpha D_x^(2u^5)+cd C_x^(2u^5). The two moments J,N must be computed from the **stripped actual sections**. They satisfy
\[
Q_0(1)=J^2,\quad q_\kappa=N^2,\quad Q_5(1)=(J+N)^2.
\]
The raw seven-term ordinary polynomial gives the extension at all grid points. Only w=0 contributes, with Gbar_x alpha q_0. The off-grid-only total is the full total plus that correction.

## Changed judgment and actual boundary

The previous common first-spare selection gives pointwise nonzero values under its hypotheses. It does not determine this full sum. With Gbar_x!=0, the exact nonzero test is
\[
D_x\ne1,\qquad
\sqrt{\alpha+b_0}\,J+\sqrt{b_0}\,N\ne0.
\]
If actual D_x=1, the full sum necessarily vanishes for every source moment. Under the inherited q_T!=0 and nondegenerate scalar hypotheses, at most8u^5+6 off-grid values then vanish, so dense nonzero values and zero total coexist along sufficiently large legal lengths. This is a conditional actual-source implication, not an assertion that the chosen actual background has D_x=1.

At fixed off-grid T_b, actual D_x=1 requires
\[
A_x=U_b^{-2(u-1)}[1+c(U_b+d)^{2(u-1)}].
\]
No actual-source result here establishes that equality, its exclusion, or the corresponding J,N cancellation. Freely defining A_x, using a synthetic toy or changing the permitted remainder would not prove reachability. None was done.

On A_x=c with c,d,C_x!=0, survival still needs D_x!=1 and J!=N. On alpha=b_0!=0 it needs N!=0, equivalently q_kappa!=0, so the old q_T!=0 is insufficient. The retained source/route/checker/density and public-factor interfaces remain explicitly conditional. Remaining beacon/other coordinate sums, other third remainders, real defects, norm orbits, trace and physical JK response stay open. There is no main-conjecture or address-scale evaluator claim.

Next bounded mathematical obligation: prove or refute the exact actual criterion above from the same-source structure, or explicitly authorize a subsequent complete coordinate sum. A further pointwise root average does not answer it.

## Review and evidence

New-context same-model reviewer /root/rw_complete_spare_review independently derived the weighted projection, stripped J/N compression, grid correction and actual reachability condition. It found a missing large-length qualifier in the density illustration; the final proof now states the exact root count and limits the1-O(1/u) fraction to sufficiently large legal lengths. The correction is retained in rw-pulse5-review-record.md.

No new finite check, actual source computation, solver or parameter sweep was run. The proof directly reuses the sealed universal seven-basis theorem in pulse3, with k=D_x^2 and its already retained raw verification. In particular its k=1 check gives zero for all seven full basis sums. This verifies formal algebra and says nothing about whether actual D_x=1.

## Preservation and publication boundary

Startup found all348 original-unit fingerprints unchanged since pulse4 and all pulse2/3/4 manifest deliverables matching. Process ownership remains UNKNOWN after the earlier ps permission denial, which was not retried or bypassed. The original project stayed read-only; all new files are in task-6. No Git mutation, original Goal/Hermes/cron resumption, HPC/SAT/remote/cloud/payment/account/credential action or external publication occurred.

The final snapshot and rw-pulse5-delivery-manifest.json retain versions and preservation evidence. This is a private derived result for the parent's unified Commons candidate, not a published contribution. Human authorship/consent, ownership/release permission, AI disclosure, content/code licenses, bibliography/novelty and external validation remain missing. No key, DOI or upload was created.

Final verification: all348 original files remain unchanged in paths, size, mtime and SHA256; all11 pulse2,9 pulse3 and8 pulse4 manifest deliverables still match. The supported old-thread read again reports idle and unchanged updatedAt=1791026156, with the same closure turn reporting Goal paused. This is thread evidence rather than a fresh Goal-state JSON. Background process ownership remains UNKNOWN.
