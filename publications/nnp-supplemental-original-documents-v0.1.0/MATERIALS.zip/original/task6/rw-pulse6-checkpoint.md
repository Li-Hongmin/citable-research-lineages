# RW pulse6 checkpoint — 2026-10-03

**Bounded outcome:** actual D_x=1 reachability and J,N cancellation remain undecided. The missing information is now expressed as an actual reference-head Boolean certificate and specific same-source moment comparisons. No new strong hypothesis, source calibration, integral, pointwise average or recomputation was inserted.

The proof and exact scope are in rw-pulse6-actual-source-certificate-gates.md.

## Actual background reduced

Let t=ceil(log_Q H) be the retained low digit count, including last. All other third high grid coordinates in the A_x slice are zero. Its grid ranks therefore satisfy
\[
r<u^t<(QH)^{1/6}
=W_1^{1/6}/(u^2g_{\rm gap}^{1/6})<W_1.
\]
The source coefficients come only from the reference first raw block pi_1B_1 0*. The public407.23a permutation fixes this prefix. Later simulation gates, logical NP-witness slots and comparison gates do not enter A_x.

With I_x={r<u^t:r mod u=x,r<rho_1+2n_1} and actual head h_ref,
\[
A_x=\sum_{r\in I_x}h_{\rm ref}(r)\prod_iL_{a_i(r)}(\zeta_i).
\]
This is a slice, not a free-coordinate parity marginal. Reference ledger zeros do not delete the surviving pi_1B_1 head.

Using c=product_i L_0(zeta_i)!=0 and the same off-grid retained tuple, actual D_x=1 is equivalent to
\[
\sum_{r\in I_x}h_{\rm ref}(r)
 \prod_i\frac{\zeta_i}{\zeta_i+a_i(r)}
=U_b^{-2(u-1)}[c^{-1}+(U_b+d)^{2(u-1)}].
\]
This is6mu finite XOR equations on the actual head bits in any F/F2 basis. A verified mismatch excludes D1; verified equality certifies it. No actual weighted-head value or certificate was obtained from the existing local proof chain, and no numerical tuple/head was fabricated. Finite output dimension does not prove address-scale evaluation cost.

## Moment gap reduced

Use only stripped actual sections. Let H_i=h_i^(B/2), deltaH=H_1+H_0, deltag=g_1+g_0. The inherited q_T!=0 ensures deltaH,g_O,t_O!=0. Then
\[
N=t_O^{\kappa/2}[\delta H g_0+H_1\delta g],\qquad
q_\kappa=N^2\ne0\iff g_0\ne H_1\delta g/\delta H.
\]
The exact difference is deltag=lambda_A g(p_B)+lambda_G g(p_G), two recodings of the same published B_0. OUTPUT/beacon terms are common and cancel; gadget endpoint zeros do not imply its whole-line g moment is zero.

On alpha=b_0!=0, D_x!=1, this is the missing full-sum survival condition. The threshold is an actual-source quantity, not independently known advice.

On A_x=c,C_x!=0 define
\[
E=g_Ot_O^{\kappa/2}\delta H,\quad
L=\sum_iH_i[(a_i+a_O)h_i^{\kappa/2}+(g_i+g_O)t_i^{\kappa/2}].
\]
Then J+N=L+E and E^2=q_T!=0. Given D_x!=1, survival is exactly L!=E. Highest-coefficient nonzero only supplies E!=0 and does not exclude L=E.

The head reduction applies to third background A_x. It does not restrict off-grid first-source g_0,L to that same head: those may include other actual reference source regions.

## Remaining decision

No proof here assigns the actual head syndrome, g_0 or L, proves D1 reachable/impossible, or forces universal full-sum survival/cancellation. The next useful source-specific result is the actual weighted-head equality/inequality at the fixed remainder, then the appropriate same-source moment comparison. Generic source values, independent background assumptions or another root average would not discharge it. Further outer sums, defects, norm orbits, trace and JK/main-conjecture conclusions remain open.

## Review and preservation

Fresh-context same-model reviewer /root/rw_actual_background_review independently checked the real raw-head slice and final moment identities. Its initial broad interpretation included later source regions; the rank bound correctly narrowed the A_x slice to pi_1B_1. That refinement and final assessment are retained in rw-pulse6-review-record.md. This is not independent-model/human validation or a fresh external certification of the whole upstream route chain.

Startup verified348 original files unchanged and all pulse2/3/4/5 sealed deliverables matching. Original project remained read-only, background writer visibility UNKNOWN after the earlier denied ps, with no retry/bypass. No original Goal/Hermes/cron resumption, computation, Git mutation, paid/remote/HPC action, credentials or publication occurred. New deliverables are only in task-6. Final snapshot and manifest record exact versions.

This is private source-specific progress for the parent's unified Commons candidate; authorship/consent, ownership/release permission, AI disclosure, content/code licenses, bibliography/novelty and external validation remain missing. No upload, signing key or DOI was created.

Final preservation verifies all348 original paths/content/size/mtime unchanged and all sealed pulse2(11), pulse3(9), pulse4(8), pulse5(5) deliverables matching. The supported final read reports the old research thread idle, unchanged updatedAt=1791026156 and the same closure turn reporting Goal paused. No independent Goal JSON was retrieved and process ownership remains UNKNOWN.
