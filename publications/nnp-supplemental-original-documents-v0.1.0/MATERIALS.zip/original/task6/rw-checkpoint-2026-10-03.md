# N&NP / RW bounded takeover checkpoint

2026-10-03. Authorized source task: `[coordination-identifier-removed]`. Old research thread: `[coordination-identifier-removed]`. Original unit: `original/rw-unit`.

**Outcome:** one bounded substantive pulse completed. The complete zero-source spare (W) sum after Note 621's (Y,Z_1,Z_2) sums has been reduced to an exact evaluation of the same actual kernel, with no independently chosen source scalar. Sparse support and local kernel shape still do not guarantee survival. A structural **abstract** cancellation witness and independently implemented finite enumeration substantiate that boundary. The actual reached-source evaluation remains open. No main-conjecture result is claimed.

## Takeover and preservation

- Read the project `AGENTS.md`, root and unit README, the root 2026-09-09 SPEC and unit 2026-09-23 SPEC, the two required task-3 handovers, Notes 618–621 and decisive sections of 608/609/614/616/617. Followed the relevant mathematical links instead of accepting numbering as proof status. No unit `LOG.md`, `GOAL.md`, `Goal.md` or `SPEC.md` was found; the unit's dated SPEC and paused original thread are the available direction evidence. No Goal-control tool is exposed in this task, and none was fabricated or resumed.
- A current supported `read_thread` reports the old thread `idle`, with its latest safe-closure turn `completed`, ended at Unix `1791026156`. Its final response says the research goal is paused, no derivation/file modification/computation occurred, and Note 621 is the checkpoint. This is a thread response, not this task's independently retrieved Goal-state JSON.
- Baseline file snapshot covered 348 files in the assigned unit. A second snapshot 51.88 seconds later had no changes in paths, size, nanosecond mtime or SHA256. No identifiable visible lock file was found. These observations do not establish absence of a future or hidden writer.
- **Unresolved startup gate:** the read-only process command `ps -axo pid,ppid,lstart,command ...` was rejected by the system with raw output `zsh:1: operation not permitted: ps` (exit 1). No alternative interface, escalation, lock claim, process termination or permission workaround was attempted. This is a system permission failure, not an automatic approval-review rejection.
- Accordingly this task stayed read-only in the original project and wrote all new deliverables in the authorized task-6 workspace. It did not try an external-volume write. The final snapshot below checks original content again. There were no Git mutations, including add/commit/reset/checkout/stash/push/clean, no deletion/overwrite/move, and no Drive sync. Existing untracked/ignored files and errors remain in place.
- Hermes, other original threads and other mathematical units were not started or controlled. No HPC/SAT, remote machine, cloud VM, payment, account switch, credential read, external upload, key generation or DOI action occurred.

The older task-3 post-termination handover's gate was superseded by its later safe-closure result. That permits a bounded allocation, but does not fill the independent process-visibility gap above.

## Evidence grading of the latest mathematical chain

|Claim/interface|This pulse's judgment|Exact limitation|
|---|---|---|
|618 exchange pairing on equal beacon weights|Locally verified characteristic-two identity|Weights/source and all other coordinates fixed; no full JK statement|
|619 even-Frobenius annihilation and full-monomial projection|Locally verified by residue/degree argument|Formal multilinear complement source; cannot substitute a single-grid Lagrange line into the same hypothesis|
|620 D/C coefficient formulas and full 32-branch transfer|Locally verified Lagrange/Lucas/no-carry algebra|Assumes honest degree-(<u) section and complete coordinate fields; values of actual source remain charged|
|621.2 / equation621.3 linking empty and fifth-single branches|Locally verified, fresh-context review agrees|Depends on the same-source four-term identity614.18; original proof wording needs the normalization below|
|621.10 and its 32-exponent support|Locally verified; fresh-context review agrees|Actual kernel and other sections must be independent of the free (W); the second term only fills subsets containing5|
|621.3 pointwise density at one common spare coordinate|Conditional theorem supported by local algebra/counts|Requires reached density, all source/route/serialization hypotheses and nonzero public factors; upstream complete proof chain not fully audited here|
|Complete (W) survival|Open for actual checker; exact criterion derived|Equation(4) in companion candidate, not nonzero local-value density|
|Complete physical JK response, all first/third sums, incidence defects, trace and norm orbits|Unreviewed/open|No inference from the local subtable|
|Address-scale exact surface, NP circuit lower bound, P versus NP|Not established|Neither old621 nor this pulse supplies it|

**Concrete wording correction, not a changed theorem:** Note 621 Lemma621.1 says the two original coefficients are degree-(C_*+2) polynomials in (z) with the same leading coefficient. Strictly this statement applies to the normalized coefficients (s^{-d_*}a_{x,\varnothing}) and (s^{-d_*}a_{x,\{5\}}), because (s=L_0(X)) varies with (z=X/(X+a_o)). The displayed equation and subsequent root averaging already remove the nonzero (s^{d_*}); those steps survive this correction. The original note was not edited or silently relabeled.

No incorrect equation or fatal flaw in the reviewed local algebra was identified. That is a bounded audit, not a certificate that every reachable-source dependency or published-paper mapping is correct. In particular, the valid checker modifications, route geometry, hard-word density and entire weighted first-last-digit construction are not newly certified merely because the local formulas fit.

## Substantive result and reproduction

The complete proof and counterexample boundary are in `rw-spare-contraction-candidate.md`. For 

\[
\eta=y^{2(u-1)},\qquad
D=A y^{4(u-1)}+c(y^2+d)^{2(u-1)},\qquad
C=A y^{3u-4}+c(y^2+d)^{3u/2-2},
\]

the complete (W) sum equals

\[
\Gamma L_0(y)^2\left[(A+c)H_x((tD\eta)^2)
 +cd(tC\eta)^{2u^5}H_{x,[5]}((tD\eta)^2)\right].
\]

This improves the checkpoint from “(W) itself has not been summed” to an exact actual-source scalar test after its complete sum. At the cancelling background (A=c), with all public factors nonzero, the test is (H_{x,[5]}((tD\eta)^2)\ne0). If (D=0), Note621's (H_{x,[5]}(0)\ne0) does suffice for this subtable; the case (D\ne0) is unresolved. At (A\ne c), both bracket terms can cancel.

The abstract cancellation witness can preserve the local kernel shape609.7: choose 
\(\lambda^4=\sigma=(tD\eta)^2\ne0\), local sections (a=1,b=1+\lambda), and (G_5(a,b)\ne0\). Then
\(\mathscr H_{a,b,[5]}(Z)=G_5^2(\sigma+Z)^{u+u^2+u^3+u^4}\).
Its value at zero and the empty branch are nonzero, but its value at \(\sigma\) is zero. Dense pointwise responses coexist with a zero complete sum. This is **not** a reached RW counterexample: realizing these field sections in the paired complete first-last-digit sum614.25 was not shown. It cannot satisfy R1/R2/R3 NOGO by itself.

Commands:

```sh
python3 rw_field_modulus_check.py
cc -O2 -Wall -Wextra -o [anonymous-historical-runtime-locator] rw_spare_check.c
[anonymous-historical-runtime-locator]
```

At (u=8), the exhaustive one-coordinate run checked all 32 basis identities in (F=\mathbb F_{2^{18}}). The field polynomial's irreducibility was independently checked by a short Python Rabin test. Both the simple sparse example and the609.7-shaped example have a zero complete sum despite262134 nonzero weighted values; the simple example has262133 nonzero off-grid values. C compilation was warning-free under `-Wall -Wextra`; the enumeration ran in under one second. This is a light illustration, not an actual RW/PCP/HPC recomputation.

## Independent fresh-context review

Delegated one bounded read-only question to `/root/rw_fresh_review`, using a new context with no parent mathematical conclusions initially supplied. It separately reconstructed621.3, the coefficient support of621.10 and the same complete-(W) formula; it found the normalization wording issue above. At the final verification stage it checked the strengthened local-shape witness and independently reproduced its field scalars 
\((D,C,\eta,\sigma,\lambda,b,G_5,H(0),H_{[5]}(0))=(78677,65553,16384,153607,174978,174979,117291,128322,169943)\).
It did not rerun the exhaustive C counts. Its final assessment was: local algebra holds under the stated geometry/source hypotheses; actual complete survival remains open. The agent had no project write/Git/remote operations.

Both agents use the same model family. This is independent context, not independent model/evidence-source verification. The separately written finite arithmetic code provides evidence for the stated field example and diagonal identity; it does not certify the whole actual-source proof. The candidate remains unpromoted.

## Minimal possible Commons contribution

Possible private submission candidate: **“Diagonal contraction of a complete zero-source coordinate and a local-kernel cancellation boundary.”** Include the self-contained lemma, the exact conditional actual-source reduction, and the standalone finite check. It is small enough to disclose without the hard word, original manuscript, source tables or unrelated project material. The diagonal basis identity already appears in616.9; this candidate must be described as a clarified consequence and a sharper local-shape boundary until novelty is checked. It should not be advertised as a circuit lower bound or a solved orbit gate.

Still missing before any Commons inclusion: designated human authors and their consent/order, explicit AI-role disclosure, project ownership/permission to release the derived material, an explicit selected content and code license, authoritative citations for the relevant source construction, a novelty/prior-art check, and an independent reviewer verifying both the symbolic lemma and exact scope. No names, permission, license or validation status were invented. No upload, signature/key or DOI was produced. CRL pilot decisions remain with the parent.

## Continuation and stop condition

Next pulse should decide the bracket above at the **same actual reached source and first tuple**, or isolate a genuinely reachable cancellation. The cheapest useful mathematical question is whether the honest sections impose a relation forcing or excluding (H_{x,[5]}((tD\eta)^2)=0) on the (A=c,D\ne0) fiber. At (A\ne c), one must control the two-term sum, not each evaluation separately. Treating actual kernel coefficients as free, or varying (y) while keeping the actual (A_x,H_x) fixed, would change the problem.

Stop this bounded pulse here: the complete spare sum is resolved algebraically, the missing actual-source evaluation is explicit, and further outer sums require new source-specific information. This is not a go/no-go verdict on the entire frozen SPEC or main conjecture. Maintain old Goal paused. Original-project writes remain subject to the unresolved process/writer visibility gate; the parent may continue with read-only pulses and task-workspace checkpoints without taking a lock.

## Final preservation evidence

`rw-final-preservation.json` records the final all-unit snapshot: 348 files, no changed paths/content/size/mtime against startup, after 685.06 seconds. A final supported `read_thread` again reports the old thread idle, the same completed safe-closure turn and unchanged `updatedAt=1791026156`; no new research turn was seen. The full startup snapshots remain `rw-startup-snapshot-1.json` and `rw-startup-snapshot-2.json`.

Raw reproducibility results are retained in `rw-modulus-check-output.txt` and `rw-spare-check-output.txt`, both exit0. Runtime: Python3.14.7; Apple clang21.0.0 (`clang-2100.0.123.102`). All new source/report files are in task-6; the temporary compiled binary is `[anonymous-historical-runtime-locator]`. No original project source was written. These facts preserve the local mathematical checkpoint while leaving the denied process inspection explicitly unresolved.
