# 论文单元：二层阈值电路的表示完备性与限制障碍

本目录只收录已经有独立主定理、可以继续发展为连续论文正文的成果。内部 note
仍保留路线探索和证明来源，但不按 note 数量拆论文。

## 论文总表

| 编号 | 论文 | 核心贡献 | 当前地位 |
|---|---|---|---|
| 01 | [A Single Modular Character Is Complete for SYM∘LTF Counting](01-a-single-modular-character-is-complete-for-sym-ltf-counting/paper.md) | 用 \(O(q^2)\) 个 LTF 与 \(O(\log q)\) 个 selector 变量，把任意 \(\mathrm{SYM}_q\circ\mathrm{LTF}_h\) 的接受率精确编码为一次无权 modular-character expectation | 已有自足主定理；首要论文候选 |
| 02 | [Uniform Active-Count Tightness for LTF Restrictions](02-uniform-active-count-tightness-for-ltf-restrictions/paper.md) | 构造正则、两两近乎正交的 LTF 族：所有 restrictions 同时保留 \(\Theta(qh/\sqrt N)\) 个活跃门；当 \(h\le C\sqrt{N-h}\) 且采样更密时，每个 \(h\)-element live partition 的全部 \(2^{N-h}\) 个 columns 具有不同 active sets；\(h=1\) 的 exact-sphere 分离上下界现只差 \(\sqrt{\log N}\)，任意预定异质半径集的一阶模板已达最优，antipodal 与最大偶距离层 covering 数均为 \(\Theta(M)\)，固定中央截断还满足显式常数的任意中心熵下界；精确证明八个四元 Walsh blocks 在零窗口下的任意中心复杂度为 \(6\)，并给出所有偶数 \(d\ge4\) 的 \(d+2\) 行 character-cut 构造 | 已有三个自足主定理、混合分离上界及完整有限 Walsh-star 分类；结构性障碍论文候选 |

## 不单独晋级的材料

- [低分 partition 离域定理](../notes/007-low-score-partition-delocalization.md) 是论文 02
  的辅助路径定理：它说明低分 partition 不能携带固定非空 payload，但单独成稿会缺少足够独立的中心问题。
- [column 类型熵障碍](../notes/013-column-type-entropy-obstruction.md) 给出论文 02 第二主定理的
  前身：只要求 \(qh/\sqrt N\gg N\) 时得到指数码本上的单射；正文在更强的
  \(q/\sqrt N\gg N\) 假设下把单射提升到整个 column cube，并给出近紧门数下界。
- notes 010--018 主要是 canonical profile、advice、\(E^{NP}\to NP\) 下沉和
  evaluator 量词的路线边界。它们继续作为论文 01--02 的范围说明和后续接口，不在当前阶段拼成一篇“障碍综述”。

## 证据边界

- 论文 01 是一个精确表示/归约定理，不等于更快算法，也不直接给出 \(\mathrm{THR}\circ\mathrm{THR}\) 下界。
- 论文 02 是最坏情形限制定理，说明二阶反集中和普通角度聚类不足以降低一阶活跃门数；它不排除利用更高阶联合结构的算法。
- CTW、Hatami--Hoza--Tal--Tell、Tamaki 等文献是外部背景和算法边界，项目自己的贡献只限于正文中明确证明的归约与构造。
