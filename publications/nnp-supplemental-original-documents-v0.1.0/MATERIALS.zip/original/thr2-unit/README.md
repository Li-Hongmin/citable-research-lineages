# 二层阈值电路下界

## 对象与范围

研究 \(n\) 变量二层线性阈值电路 \(\mathrm{THR}\circ\mathrm{THR}\) 的规模下界，以及从计数/接受概率估计算法到下界的转移。重点是确定三类边界：

1. 随机限制后活跃底层门数与可处理表示复杂度之间的尖锐关系；
2. 逼近多项式从构造到批量求值时，单项展开、秩、张量宽度或其他联合结构参数的必要性；
3. 从 \(E^{NP}\) 或随电路指数变化的 \(NP\) 语言族下沉到单一 \(NP\) 语言时的量词与时间开销。

若候选改进为假，目标是证明最坏情形障碍并确定仍可成立的结构化子类，而不是预设必须突破某个指数。

## 权威入口

论文入口：[二层阈值电路论文单元](papers/README.md)。当前已晋级两篇独立主定理论文；其余
notes 仍按数学依赖保留，不按编号机械拆分。

其中论文 02 还证明：对固定 \(h\le C\sqrt{N-h}\)，当 \(q/\sqrt N\gg N\) 时，
固定阈值的正则 sign-normal 门族可使每个 \(h\)-element live partition 的全部 columns
具有互异 active sets；\(h=1\) 时所需门数在 \(\log N\) 因子内紧。对有限的
八块四元 Walsh-star 零窗口问题，正文还给出完整分类并精确证明
\(\nu_{3,0}(4,4,4,4,4,4,4,4)=6\)。该值不按 \(d+3\) 延伸：每个偶数
\(d\ge4\) 都有显式的 \(d+2\) 行 block-constant character-cut 构造；这些有限值
不等同于渐近电路下界。

- [2026-08-12 接入说明](notes/000-cutover-2026-08-12.md)
- [list-approximator 的因子化接口](notes/001-factorized-list-approximator-interface.md)
- [块对称压缩与联合直方图障碍](notes/002-block-symmetric-joint-histogram-barrier.md)
- [CTW profile 的 Fourier 饱和与 character-specific PRG 边界](notes/003-fourier-saturation-and-character-prg-boundary.md)
- [CTW seed 平均与 character PRG 的精确目标](notes/004-seed-average-and-character-prg-target.md)
- [Character sampler 的统一性与 SYM-CAPP 边界](notes/005-uniformity-and-sym-capp-boundary.md)
- [CTW partition forcing 与局部语义完备性](notes/006-partition-forcing-and-semantic-universality.md)
- [LTF restriction score 的低分 partition 离域定理](notes/007-low-score-partition-delocalization.md)
- [二阶 restriction 与锥压缩路线的障碍](notes/008-second-order-restriction-obstructions.md)
- [单一 modular character 对 SYM--LTF CAPP 的完备性](notes/009-single-character-completeness.md)
- [CTW canonical profile 的精度边界](notes/010-canonical-profile-precision-boundary.md)
- [CTW advice 平移的语义边界与零 advice 尺度校准](notes/011-advice-translation-and-zero-advice-boundary.md)
- [零 advice 正则化与全局 PRG 尺度判定](notes/012-regular-zero-advice-and-global-prg-calibration.md)
- [CTW restrictions 的 column 类型熵障碍](notes/013-column-type-entropy-obstruction.md)
- [从 \(E^{NP}\) 到 \(NP\) 的转移缺口与 padding 不变量](notes/014-enp-to-np-descent-and-padding-invariant.md)
- [Easy-witness 转移的指数分解与 fixed-\(k\) 量词反例](notes/015-easy-witness-exponent-factorization.md)
- [Fixed-description evaluator 的统一性二分](notes/016-fixed-description-evaluator-dichotomy.md)
- [Class-preserving proof trace 的两重缺口](notes/017-class-preserving-proof-trace-boundary.md)
- [Uniform dense sampling 与 CTW CAPP 的尺度分离](notes/018-uniform-dense-sampling-and-ctw-scale-separation.md)
