# N&NP 项目代理规则

## Google Drive 增量镜像

- Google Drive 同步流程以
  [unmapped-local-locator] Drive/数学研究 ChatPro 工作区/README.md
  为权威说明；执行同步或处理 ChatGPT Pro 回流前先读取该文件。
- 本地项目
  original/nnp-root-files
  是研究主版本；对应 Drive 镜像为
  [unmapped-local-locator] Drive/数学研究 ChatPro 工作区/N&NP/。
- 同步方向只能是本地项目 → Google Drive。使用
  [unmapped-local-locator] Drive/数学研究 ChatPro 工作区/sync-projects.sh，
  先运行 --dry-run 检查范围，再运行 --push；不要用反向同步或手工覆盖代替该脚本。
- 同步系统的 README、脚本和三个项目镜像全部位于“数学研究 ChatPro 工作区”内；不要在 Google Drive
  根目录重新创建同步脚本或三个项目目录。
- 同步是增量复制，不删除 Drive 中已有文件。若发现冲突，先保留双方文件，再由本地 AI 或人工判断，
  不直接覆盖。
- .git/、缓存、构建目录和权威 README 所列排除项不参与同步；Git 历史仍由本地仓库和远程 Git
  仓库管理。
- 保留项目原目录结构，不建立额外的 mirror、context 或第二项目入口。
- ChatGPT Pro 只允许在
  [unmapped-local-locator] Drive/数学研究 ChatPro 工作区/N&NP/ChatGPT-Pro-Reports/
  中新建分析报告、规划和建议，不修改镜像中的已有项目文件。
- 本地 AI 可读取 ChatGPT-Pro-Reports/，但报告只作为待核验输入；数学结论必须回到本地权威 note、
  paper、原始文献或可复现实验核验后才能采纳。
- 不移动、删除或改名 [unmapped-local-locator] Drive/AI数学工具/。

## ChatGPT Pro 回流吸收规则

- 用户指定的 Downloads、聊天导出或 Drive 回流文件只作候选输入；处理前先读取上面的工作区
  权威 README，不把外部文件直接当作项目定理或同步事实。
- 只把能回到原始文献、现有权威 note 或可复现实验的内容写入研究 note；每条吸收内容注明
  来源和证据边界，并明确区分“已核验结果”“路线筛选规则”和“仍待证明的假设”。
- 对外部报告中的阶段编号、穷举计数、哈希、云端写入声明和未附自足证明的强结论，不得仅凭
  报告晋级；如有用，记录为未核验输入或拒绝理由。
- 吸收报告时优先形成一份合并记录，不复制整份导出文本，不建立第二个项目入口；原始报告
  需要留档时，只放入对应项目的 ChatGPT-Pro-Reports/，并按本地项目→Google Drive 规则同步。
