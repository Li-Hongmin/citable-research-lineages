# P versus NP research workspace

本仓库研究 `P` versus `NP` 及其相邻的电路复杂度、MCSP、Range Avoidance 与
PCP/dPCP 问题。局部路线关闭不按数量计作贡献；权威数学内容以论文和少量末端
综合 note 为准，历史细分 notes 只保留为可追溯依赖。

长期强目标是确定能否证明
\(\mathrm{SAT}\notin P/\mathrm{poly}\)，等价地
\(NP\nsubseteq P/\mathrm{poly}\)；正面结果立即推出 \(P\ne NP\)。中间方向只有在
它产生通向该目标的跨模型转移、固定或定量可控交替的 address surface、或一般电路下界时才升级；
若候选接口为假，则保存其尖锐反例或正确替代边界。

## 数学单元

- [RW/JK succinct reconstruction](units/rw-jk-succinct-reconstruction/README.md)：shared-proof coordinate robustness、地址尺度重构与条件性 Closure。
- [MCSP hardness magnification](units/mcsp-hardness-magnification/README.md)：Formula--XOR、one-tape threshold lowering 与近似 MCSP。
- [二层阈值电路下界](units/thr2-lower-bounds/README.md)：`THR∘THR` 的算法—下界转移、随机限制与复杂度下沉。

统一论文入口见 [项目论文总表](papers/README.md)。

## 当前权威研究接口

RW/JK 主线的权威正文是
[From Address-Scale Smart Reconstruction to P/poly](units/rw-jk-succinct-reconstruction/papers/04-from-address-scale-smart-reconstruction-to-p-poly/paper.md)。
其稳定边界是：在显式计入一位 source advice 后，published singleton 已有
branch-independent、single-valued 的
[exact same-object semantic surface](units/mcsp-hardness-magnification/notes/588-published-rw-singleton-has-exact-same-object-semantics-only-at-object-scale-2026-08-26.md)，
但它仍是 object scale。semantic same-parent 因而不是独立缺口；要触发 published hard word
的 forcing，必须同时把共同描述、全部量词、矩阵和控制压到 `polylog(N)` 地址尺度。固定 PH
是最简充分条件，增长交替的一般黑盒代价为 \(m^{A\Gamma^d}\)，而 RW 可调增长常数
还能吸收对所有充分大 \(C\) 成立、且跨起点参数统一的 \(O(i)\)-depth surface。若同一
published word 获得满足相应定量条件的 exact same-object address surface，非均匀 Closure 已足以推出
\(\mathrm{SAT}\notin P/\mathrm{poly}\)。published RW/JK 尚未给出这种压缩；physical JK
success outsider 既没有绑定完整 systematic hard-output interval，其 \(2n_{i+1}\)-bit payload
在 actual recurrence 中也已是 object scale。

作为 exact surface 的一个候选，[relay-normal strategy 编译](units/mcsp-hardness-magnification/notes/598-relay-normal-pairings-reduce-functional-nullstellensatz-compression-to-succinct-strategies-2026-08-28.md)
只需一个可随机访问、低 weighted-AND depth、低描述复杂度的策略。但
[source-compatible 表示边界](units/mcsp-hardness-magnification/notes/599-source-compatible-layouts-do-not-determine-succinct-weighted-strategies-2026-08-28.md)
表明局部地址简洁并不蕴含这种策略：合法恒等 padding 可分别强制指数 occurrence 地址或指数
multiplier degree。因此 universal-over-serializations 版本已被反例排除。
[heavy--light occurrence 编译](units/mcsp-hardness-magnification/notes/600-heavy-light-occurrence-addresses-reduce-random-access-to-heavy-run-summaries-2026-08-28.md)
现已冻结一个无隐藏 advice 的 code-level ANF compiler 候选，并证明：state-local strategy grammar
若有 exact subtree count、\(m^{O(1)}\) weighted depth 与 circuit-succinct heavy-run
jump/atom summaries，就以 \(O(R^2)\)-bit heavy--light path code 满足 Definition 598.1；
无需先有 global preorder rank/unrank。固定 running-conjunction transducer 的真实 transition
则给出 \(d=N=2^{\Theta(m)}\) 反例，说明 C444/C453 的 local generator 不自动提供这些条件。
正向结论仍需对一个固定 favorable compiler 证明全部条件；任何负向结论也必须固定 compiler，
或先给出表示不变的 normal form。
[finite local semantic rail 边界](units/mcsp-hardness-magnification/notes/609-finite-local-semantic-rails-cannot-compress-a-fibonacci-xor-recurrence-2026-08-28.md)
进一步关闭了有限逐门 substitution 作为这种 universal normal form 的可能性：局部导数恒等式
迫使每个 exact XOR gadget 在任意 valuation corner 都暴露两个 predecessor bundles；带 fresh
innovation 的宽度二 Fibonacci recurrence 因而满足
\(K\ge F_{L+1}\)、\(r=\Omega(L)=2^{\Theta(m)}\)，同时输出真正依赖
\(\Theta(L)\) 个 fresh inputs。该结果不覆盖 nonlocal jump algebra、global reassociation、
proof-DAG sharing 或只在 actual slice 上正确且完整计价的 conditional rails，也不声称 actual
RW family 含不可绕过的 Fibonacci cone。
[Easy Witness 重标度](units/mcsp-hardness-magnification/notes/608-easy-witness-rescaling-requires-a-hypothesis-incompatible-with-p-equals-np-2026-08-28.md)
也不能自动补出 actual perfect-witness accessor：显式 query 上只得到 object-scale 电路；地址尺度
IKW theorem 所需的 \(NEXP\subseteq P/\mathrm{poly}\) 与 \(P=NP\) 反证分支不相容。该关闭只针对
通用 padding/Easy-Witness family，不否定 actual RW-specific witness 或 favorable compiler。

[actual canonical-prefix count identity](units/mcsp-hardness-magnification/notes/610-published-rw-canonical-prefixes-are-batch-count-vectors-without-count-state-closure-2026-08-28.md)
把 reconstruction 的共同 prefix 精确识别为 \(BF_i\) 各轮 SAT YES 数量的定宽编码，并给出
prefix-conditioned NP replay recurrence。它同时证明 published literal update maps 在完整
syntactic answer-vector 域上不经过 Hamming weight 因子化；把任意 succinct batch predicate
作为输入的通用 count primitive 又会计算 \(\#\mathrm{CircuitSAT}\)。这些边界不关闭 actual
fixed unary orbit：仍可能存在 RW-specific、在 composition 下有效闭合的
\(m^{O(1)}\)-size normal form。

逐坐标展开 published Solve/Reconf/JK 也没有隐藏的廉价递减递归：Solve 先进入当前尺度的
proof/range payload，Reconf 指向当前或更大尺度 proof；而任何只用
\(\operatorname{polylog}(N)\) 控制和查询访问较早输出词的递归，硬接全部较早 ROM 后只有
\(N^{1/C}\operatorname{polylog}(N)\) 大小，与同一 hard word 的 forcing 下界矛盾。精确范围见
[literal recurrence coordinate boundary](units/mcsp-hardness-magnification/notes/589-literal-published-rw-recurrence-has-no-cheaper-decreasing-coordinate-interface-2026-08-26.md)。

本入口只保存稳定对象和权威正文链接，不记录滚动状态、下一步或逐轮执行历史。
