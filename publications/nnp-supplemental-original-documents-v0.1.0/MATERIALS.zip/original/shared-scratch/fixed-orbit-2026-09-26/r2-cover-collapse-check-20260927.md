# 冻结 R2：短表覆盖、选择器与非均匀 SAT 塌缩

2026-09-27。仅本轮 scratch 推导。

**裁决。** 在同一个 published truth-table generator、题设冻结的二进制 raw prefix、以及同一固定求值机和有限符号解码下，短 SAT 语义表覆盖 W **蕴含** \(NP\not\subseteq P/\mathrm{poly}\)。这是已证明的**条件不相容性**：\(W\land NP\subseteq P/\mathrm{poly}\) 与原源的实际 \(B_q\) 硬度矛盾。W 本身尚未证明或反驳；这不是无条件 R2 NOGO，也不是从单个 YES 答案推出的复杂度分离。Pro 的正见证覆盖集与普通选择器下界成立，且与 W 允许的隐式 SAT 见证相容。

证据限于 [Pro 最新候选](pro-latest-20260927.txt)、[此前表审查](r2-sat-semantic-table-audit.md)、[冻结 SPEC](../../units/rw-jk-succinct-reconstruction/SPEC-2026-09-23-fixed-orbit.md) 和 [Ren–Williams 原文，本地 ECCC TR26-118 revision 1]([unmapped-local-locator])。Pro 是待核验输入，不作原始证据。未检索远程版本；文献核对日为 2026-09-27。

## 原源、实际长度与前缀

固定原文 Theorem 4.3 使用的充分大常数 \(C>D+1\)，令
\[
 \mathcal A_C=\{q\in\mathbb N:C\nmid q\},\quad
 n=2^q,\quad N=n^C=2^m,\quad m=Cq,\quad T_0=2^{cn},
 \tag{1}
\]
并只取其充分大的实际起点 \(q\in\mathcal A_C\)。原文 1040–1060、1130–1150 行给出这些基点、\(BF_0\) 的穷举输出和 \(r_0=s_0=0\)。令
\[
 B_q=\min_{\rm lex}\bigl(\{0,1\}^{2n}\setminus\operatorname{Range}(G_n)\bigr).
 \tag{2}
\]
原文 1151–1166 行把 \(G_{2^k}\) 指定为“\(2^k\)-bit 电路描述 \(\mapsto\) \(2^{k+1}\)-bit truth table”，并在 Theorem 4.5 使用 \(0.1\cdot2^k/k\) 的电路门数阈值。在这一 published 常规描述约定下，每个不在 \(\operatorname{Range}(G_n)\) 的实际 \(2n\)-bit 词都有
\[
 \operatorname{CC}(B_q)>\frac{n}{10q}=\frac{2^q}{10q}.
 \tag{3}
\]
这是对每个充分大实际基点的 range 外词的语义覆盖推论，不依赖它是不是最终 one-bit-advice 算法选出的 good length。原文未列逐位 gate-code、padding 和无效 seed 规则；(3) 使用其常规渐近生成器语义，不声称已核验某个具体 encoder 的字节串。Theorem 4.3 对任意 P-uniform AVOID 家族本身也不给 (3)；此处一直使用其后指定的同一 truth-table generator。

Lemma 3.2（约 580–616 行）按 \((y_1,\ldots,y_r,\mathrm{out},\mathrm{NP\ witnesses})\) 排列 raw assignment；encoded-history 段（约 785–796 行）说完整 witness 是 systematic proof 的前缀。基点 \(r_0=s_0=0\)，所以原始 out 字段是 \(B_q0^{T_0-2n}\)。因 \(cn\ge m+1\) 最终成立，\(T_0\ge2N\)。在**题设已经冻结的二进制坐标顺序**下，第一个实际 JK membership 块是
\[
 Z_q=B_q0^{2N-2n}.
 \tag{4}
\]
原文抽象的 systematic 断言没有独自冻结全部 field-to-binary 坐标；(4) 保留这个边界。

把 \(B_q\) 的 \(2n\) 位作为 mux 叶常量，检测长度 \(m+1\) 的地址高位为零，可构造 \(Z_q\) 的普通电路，门数 \(O(n+m)\)，门表描述包括这 \(2n\) 位。因为 \(C\ge3\)，其大小及通常 \(O((n+m)\log(n+m))\) 的编码长最终均小于 \(N\)，并落入同一生成器的常数倍 \(N/m\) 覆盖阈值。因此
\[
 \exists q_0\ \forall q\in\mathcal A_C,\ q\ge q_0:\quad
 Z_q\in\operatorname{Range}(G_N).
 \tag{5}
\]
这只是 published 渐近编码意义下的存在性结论；没有得到短 seed 或短计算表，更没有逐位 decoder 证书。Theorem 3.1（约 498–524 行）在逐 chunk inversion 之前先并行询问全部初始 \(2N\)-bit 块，所以首查询实际发生，(5) 与以后是否进入 inversion 无关。

**核对 Pro 的原始输出前缀简化。** 令 \(\Pi_q\) 为 Theorem 4.1 中固定 completeness constructor 给出的同一 PCP 字符串，\(J_q\) 为 Jeřábek–Korten 首阶段把它（按 Theorem 3.1 的规则尾部补零后）分成的 \(2N\)-bit 块数。定义
\[
 Q_q=\left\lfloor\frac{T_0}{2N}\right\rfloor.
 \tag{6}
\]
\(|\Pi_q|\ge T_0\)，故 \(J_q\ge Q_q\)。以零起始编号，前 \(Q_q\) 个块完全处在 (4) 所在的 raw out 字段：\(Z_{q,0}=Z_q\)，而 \(Z_{q,j}=0^{2N}\) 对 \(1\le j<Q_q\)。常零电路也在原生成器的 range 中。因此，令 \(I_{q,j}=[Z_{q,j}\in\operatorname{Range}(G_N)]\)，则
\[
 \forall q\in\mathcal A_C\text{ sufficiently large}\ \forall j<Q_q:\ I_{q,j}=1,
 \tag{7}
\]
\[
 \mathsf{AllFirst}_q\iff\bigwedge_{Q_q\le j<J_q} I_{q,j},\qquad
 \mathsf{CountFirst}_q=Q_q+\sum_{Q_q\le j<J_q}I_{q,j}.
 \tag{8}
\]
这是同一实际首批答案与 count 的恒等化简，不替换 \(\Pi_q\) 或物理序列化。没有证明右侧剩余块全 YES。\(\log_2Q_q=cn-m-1+O(1)=\Theta(n)\)，而首批块编号与 count 也可达 \(\Theta(n)\) 位；因此 (8) 不把完整 canonical-prefix/batch-count orbit 压到 \(m^{O(1)}\)。当 \(T_0\) 按原文取相应整数二次幂时，(6) 的 floor 实际多余；保留 floor 可避免额外舍入假设。

## Pro 的两项下界：精确有效范围

固定已有审查中同一台确定性机器 \(\mathcal M\)，包括 \(G_N\) 的 uniform construction、无效 seed 语义、clock、表布局。令表位地址宽度 \(h=O(m)\)。一个合法代码 \(\sigma\) 描述 fan-in-two、至多 \(s\) 门的普通电路 \(F_\sigma:\{0,1\}^{h}\times\{0,1\}^{r}\to\{0,1\}\)，其 SAT 语义为
\[
 \tau_\sigma(z)=1\iff\exists w\in\{0,1\}^{r}F_\sigma(z,w)=1.
 \tag{9}
\]
称 \(\sigma\) **成功**，若其 SAT 真值在全部有效地址上恰等于 \(\mathcal M(N,u)\) 对某个真实 seed \(u\) 的完整表，且 \(G_N(u)=Z_q\)。这只采用 W 的同一实际目标；下界并未选择方便的特殊原像。

设每个原始输出位由固定常数 \(b\ge1\) 个原有表位读取。对 \(0\le a<2n\)，记读取地址为 \(\rho_{m,j}(a)\)，\(1\le j\le b\)，并令 \(\mathsf{Read}_m\) 为固定符号解码。已审查的普通表布局给出一项共同电路费用 \(p(m)=m^{O(1)}\)，覆盖全部地址映射、读数逻辑和零扩展。于是对每个成功代码，
\[
 B_q[a]=\mathsf{Read}_m\bigl(a,
 \tau_\sigma(\rho_{m,1}(a)),\ldots,
 \tau_\sigma(\rho_{m,b}(a))\bigr).
 \tag{10}
\]
不能把一般多位 \(\mathsf{Read}_m\) 改写成未经证明的单个 NP 正位投影。

一个输出正见证覆盖集 \(A\subseteq\{0,1\}^r\) 满足：每个 \((a,j)\) 若 \(\tau_\sigma(\rho_{m,j}(a))=1\)，则某个 \(w\in A\) 使 \(F_\sigma(\rho_{m,j}(a),w)=1\)。负位置对所有见证都拒绝，因此在这些实际输出地址上
\[
 \tau_\sigma(\rho_{m,j}(a))=
 \bigvee_{w\in A}F_\sigma(\rho_{m,j}(a),w).
 \tag{11}
\]
将 \(A\) 的值硬接为电路常量（它们的全部值也须进入所造电路的描述），每个表位用 \(|A|\) 份 \(F_\sigma\) 和一棵 OR 树，得到
\[
 p(m)+b|A|(s+1)>\frac{n}{10q}.
 \tag{12}
\]
式 (12) 的真值来源是 (3)，与不同 SAT 见证之间是否可统一无关。因 \(p(m)=o(n/q)\)，若 \(s\le m^d\)、\(d\) 跨 \(q\) 固定，则最小覆盖集也满足
\[
 |A|\ge \Omega\!\left(\frac{2^{m/C}}{m^{d+1}}\right)
 =2^{m/C-(d+1)\log_2m-O(1)}.
 \tag{13}
\]
全集 \(A=\{0,1\}^r\) 总可覆盖，故还得到 \(r\ge m/C-(d+1)\log_2m-O(1)\)。原 W 取 \(r=s=m^d\)，与这一下界相容。式 (13) 排除多项式长的**显式**见证清单，不排除 \(\exists w^r\) 隐式定义的大集合。

再令普通多输出电路 \(D\) 从 \((q+1)\)-bit 输出地址 \(a\) 产生 \(b\) 个 \(r\)-bit 字符串 \(w_j(a)\)，并在每个正位置满足 \(F_\sigma(\rho_{m,j}(a),w_j(a))=1\)。负位置对任意串都拒绝。若 \(D\) 有 \(t_D\) 个门，连接一次 \(D\)、\(b\) 份 \(F_\sigma\) 和 (10) 的读取电路，即计算 \(B_q\)，故
\[
 t_D+p(m)+bs>\frac{n}{10q},\qquad
 s=m^{O(1)}\Longrightarrow t_D=\Omega(n/q).
 \tag{14}
\]
输出 \(br\) 个 bit 的布线、常量和电路描述不能被叫作免费 selector；在门数论证中，把它们连同 \(D\) 的固定接线作为所造普通电路的一部分。(14) 只否定普通小选择器；局部 tableau 公式允许正见证依赖被查询地址，并不要求存在这种选择器。Pro 的两项下界按此范围通过，没有给出 W 的实际反例。

## W 与一个固定 universal SAT 语言

对 (9) 采用原审查的定长 gate-list 代码：
\[
 s=r=m^d,\quad
 \lambda=\lceil\log_2(h+r+s+2)\rceil,\quad
 L=s(3+2\lambda)+\lambda=O(m^d\log m).
 \tag{15}
\]
W 的完整渐近量词（用 (5) 去掉非空前件）是
\[
 \exists d\ge1\ \exists q_\star\ \forall q\in\mathcal A_C,\ q\ge q_\star\
 \exists u\in\{0,1\}^{N}\ \exists\sigma_q\in\{0,1\}^{L}:\quad
 G_N(u)=Z_q\ \land\ {\sf Code}(\sigma_q)\ \land
 \forall z\in\mathcal D_m\
 \left[\operatorname{Tab}_{\mathcal M}(N,u)[z]
 =\mathbf1\{\exists w\in\{0,1\}^{r}:F_{\sigma_q}(z,w)=1\}\right].
 \tag{16}
\]
\(d\)、机器、输出读取规则均在所有实际 \(q\) 之前固定；\(\sigma_q\) 可随 \(q\) 改变，却必须同时服务该 \(q\) 的全部地址。式 (16) 中的长 \(u\) 仅用于陈述覆盖，不作为短电路的免费输入或 advice。

定义**一个固定的** universal SAT 语言
\[
 \mathsf U=\{\operatorname{pad}_T\langle h,r,\sigma,z,j,p\rangle:
 {\sf Code}(\sigma),\ 0\le j\le r,\ |p|=r,\
 \exists w\in\{0,1\}^{r}
 [w[1{:}j]=p[1{:}j]\land F_\sigma(z,w)=1]\}.
 \tag{17}
\]
头部标明长度、合法性及固定门表规则；无效格式统一判 NO。对本轮代码，\(r=s\le L\)，故输入长度 \(T=O(L+h+r+\log m)=O(m^d\log m)\)，见证长 \(r\le T\)。普通 universal evaluator 在 \(\operatorname{poly}(T)\) 时间内验证一个见证，因此 \(\mathsf U\in NP\)。这里不存在针对每个 \(q\) 才定义的新 NP 语言。取 \(j=0\) 和 \(p=0^r\)，(17) 就判 \(\tau_\sigma(z)\)。前缀字段留作核对选择器界，主矛盾只需这个空前缀切片。

反设 \(NP\subseteq P/\mathrm{poly}\)。由于 \(\mathsf U\) 是固定 NP 语言，存在与 \(q\) 无关的常数 \(K,k\) 和一族普通电路 \(E_T\)，满足
\[
 \forall T\text{ sufficiently large}\ \exists E_T:\quad
 |E_T|\le K T^k,
 \qquad
 \forall x\in\{0,1\}^{T}\quad E_T(x)=\mathbf1[x\in\mathsf U].
 \tag{18}
\]
先固定 (16) 的 \(d,q_\star\)，再固定 (18) 的 \(K,k\)。对每个足够大的实际 \(q\)，选 (16) 的**一个正确共同** \(\sigma_q\)，把它的全部 \(L\) 位、\(h,r,T\) 的头部及 \(E_{T(q)}\) 的电路门表硬接。对一个输入地址 \(a\in\{0,1\}^{q+1}\)，分别形成 \(\rho_{m,j}(a)\)；每个表位用同一个 \(E_{T(q)}\) 的一份副本求 \(\tau_{\sigma_q}\)，最后用原 \(\mathsf{Read}_m\) 解码。由 (10)、(16)–(18)，所得普通电路 \(C_q\) 满足
\[
 \forall a\in\{0,1\}^{q+1}:\quad C_q(a)=B_q[a].
 \tag{19}
\]
即使输出符号需 \(b>1\) 个表位、\(\mathsf{Read}_m\) 含否定或其他常数位布尔函数，也只须 \(b\) 次 universal SAT 判定和 \(p(m)\) 门读取。没有把多位解码偷写成 NP 正投影。

完整计价为
\[
 |C_q|\le p(m)+bK T(q)^k+\operatorname{poly}(T(q)+m)
           =m^{O_{d,k}(1)},
 \tag{20}
\]
并可交付长度
\[
 L+O\bigl((|C_q|+T(q)+m)\log(|C_q|+T(q)+m+2)\bigr)
 =m^{O_{d,k}(1)}
 \tag{21}
\]
的显式门表／共同 advice 描述。\(\sigma_q\) 的 \(L\) 位和 \(E_T\) 的非均匀电路均已计入；\(\rho\)、输入布局、padding 与 \(\mathsf{Read}\) 计入 \(p(m)\) 和多项式接线项。不存在按输出地址另选 \(\sigma_{q,a}\) 的漏洞。非均匀结论不要求在 \(\operatorname{poly}(m)\) 时间内找到 \(\sigma_q\) 或 \(E_T\)。

但 \(m=Cq\)，(20) 是 \(q\) 的某个**固定次数**多项式，而 (3) 是 \(2^q/(10q)\)。\(\mathcal A_C\) 无界，所以可取足够大的实际 \(q\) 使 (20) 小于 (3)，矛盾。因此，在上列同一源和固定表接口下，
\[
 \boxed{W\Longrightarrow NP\not\subseteq P/\mathrm{poly}.}
 \tag{22}
\]
更精确地，令 \(E_d(q)\) 表示在该 \(q\) 存在满足 (16) 的 \(G_N(u)=Z_q\)、合法代码及整表相等条件，且 \(s=r=m^d\) 的真实 \((u,\sigma)\)。同一个证明逐个固定 \(d\) 后给出
\[
 NP\subseteq P/\mathrm{poly}
 \Longrightarrow
 \forall d\ge1\ \exists q_d\ \forall q\in\mathcal A_C,\ q\ge q_d:
 \neg E_d(q).
 \tag{22a}
\]
这是条件假设下的 eventual failure；没有把它升为无条件失败。这一步真正用到 W 的共同正确 advice 和固定指数 \(d\)。仅有 (5) 的 YES、或者 \(\forall q\,\exists d_q\) 而次数失控，都不给 (20) 的统一多项式界。

同一 universal 语言还能直接核对 (14)。在正位置，对 \(i=1,\ldots,r\) 依次用 (17) 查询“当前前缀后接 0 能否延伸”；能则取 0，否则取 1。所有查询可用同一长度 \(T(q)\) 的 \(E_T\) 电路副本，并共用已硬接的 \(\sigma_q\)。负位置任取输出。因此在 (18) 假设下可构造满足 (14) 前提的选择器，门数至多
\[
 t_D\le p(m)+O\bigl(br(KT(q)^k+\operatorname{poly}(T(q)))\bigr)
 =m^{O_{d,k}(1)},
 \tag{23}
\]
这与 (14) 再次矛盾。该核对说明 Pro 的选择器下界和 (22) 一致；(22) 的直接证明无需预先假设存在选择器。

**停止边界。** (22) 是条件定理，不是 W 的正向构造，也不是 \(NP\not\subseteq P/\mathrm{poly}\) 的无条件证明。不能从尚未确定的复杂度假设或未逐位冻结的 decoder 推出 W 为假。Pro 的 (12)–(14) 只排除小的显式见证清单及普通选择器；原 W 的 \(m^d\)-bit 隐式存在见证仍未被排除。原始输出前缀简化 (7)–(8) 也不决定其余块或全轨道复合。故冻结 R2 的数学状态仍是 **W UNKNOWN、R2 未获 GO 或 NOGO**；本次只确定了 W 若成立所必然带来的非均匀复杂度后果。
