**R2 仍为 UNKNOWN。** Pro 的前驱候选基关系及首个实际 membership 复合语义正确；本轮唯一测试的逐项可解码 seed 重编码不能达到地址尺度，但这不排除其他非字面关系。

核对原文后的结论是：

- Pro (6) 确实唯一确定实际 \(B_0\)；(7) 的不同地址见证都解码为同一 \(B_0\)。基关系量词仍为 \(4n_0+2\) 位。
- Pro (10) 精确表达首个实际 membership 查询，量词仍为 \(n_1+3n_0+1\) 位。全批守卫与 guarded canonical inverse 也正确；首块 YES 不保证整批 YES，后续 inversion 的可达性仍未确定。
- 序列化需保留冻结的 raw-binary systematic prefix 和同一个 constructor。原文没有唯一指定全部二进制坐标或 constructor；不能把证明外推到任意序列化，也不能以另一个可接受 proof 替换实际 proof。
- 一个可补强之处：对充分大基点，\(Z_0=B_00^{2n_1-2n_0}\) 有 \(O(n_0+\log n_1)\)-size 查表电路，低于下一层生成器的覆盖阈值。因此首查询确实恒为 YES；这没有提供短 seed 或 canonical preimage。

唯一测试的压缩要求：由一个共同描述与短 transcript 解码每次使用的完整 seed，并保留 Pro 在真实基点上的逐项原像义务。令

\[
n=n_0=2^q,\quad m=\log_2n_1=Cq,\quad \beta=\operatorname{Val}(B_0).
\]

若 \(L=\lfloor\log_2\beta\rfloor+1\)，则 \(B_0\) 只有最后 \(L\) 位可能非零，可用 \(O(L+q)\) gates 实现。结合原始下界 \(\operatorname{CC}(B_0)>0.1n/q\)，得到

\[
\log_2\beta=\Omega(n/q).
\]

对每个 \(0\le w<\beta\)，Pro 的真实前驱候选系统都有值为 \(w\) 的有效候选；在 \(y=B_0\) 上，矩阵必须提供一个 \(t_w\) 满足 \(G_n(t_w)=w\)。不同 \(w\) 要求不同 seed。因此一个总长 \(R\) 的短 transcript 若要逐项恢复这些 seed，必须满足

\[
2^R\ge\beta,
\qquad R=\Omega(n/q)=\Omega(2^{m/C}/m).
\]

这个结论甚至不需要限制 decoder 的计算能力；实际矩阵、描述和复合仍须另行计价。它否定的是上述逐 seed 重编码引理，**没有证明全局一致性必须采用这种重编码**。

未解决步骤是：能否整体消去大量逐项原像见证，同时以完整计价的短关系维持同一目标与全局一致性，并通过一次实际复合。原文及本轮推导均未给出该引理，也未排除它。因此不宣布 R2 NOGO，不转入 R3。

完整推导与量词、矩阵、描述和复合计价见 [推导文件](original/shared-scratch/fixed-orbit-2026-09-26/r2-pro-formulas-and-global-seed-compression.md)。本答复也保存在 [最终答复文件](original/shared-scratch/fixed-orbit-2026-09-26/r2-final-answer.md)。本轮只写入这两个 scratch 文件；未远程访问、重计算、修改 tracked files 或提交 Git。
