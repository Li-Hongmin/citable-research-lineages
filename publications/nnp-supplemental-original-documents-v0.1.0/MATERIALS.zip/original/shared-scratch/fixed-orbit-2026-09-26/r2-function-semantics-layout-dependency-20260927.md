# 冻结 R2：函数语义到实际 JK 前缀的最小依赖

2026-09-27。本轮只处理冻结的首批 count-bit／lex-first prefix 接口。

**裁决：精确依赖归约成立，地址尺度构造仍为 UNKNOWN。** 完整 bit-to-oracle 索引表不是已经证明不可省的接口。可以省去它的显式表示，但必须另证：同一实际源的函数语义经过短表示后，仍给出原 generator 的 seed 前缀中是否存在原像的正确答案，以及首批 YES 总数的正确位。本文证明这个要求在完整前缀域和实际可达前缀域上的准确区别，并给出一个完全计价、无需枚举全部 seed 的 object-scale 首批 count 关系。没有得到满足 \(m^{O(1)}\) 预算的新构造，也没有得到该固定 orbit 的 NOGO。

证据截止本日的本地材料：已读项目 AGENTS、README、[冻结 SPEC](../../units/rw-jk-succinct-reconstruction/SPEC-2026-09-23-fixed-orbit.md)、[权威 paper 04](../../units/rw-jk-succinct-reconstruction/papers/04-from-address-scale-smart-reconstruction-to-p-poly/paper.md)，以及指定的[实际残余块关系](r2-actual-residual-bulk-one-step-20260927.md)和[代数窗口来源裁决](r2-algebraic-window-source-verdict-20260927.md)。原始依据是 [RW 本地全文]([unmapped-local-locator])：Theorem 3.1 的连续分块、全部候选 prefix 查询和 lex-first 更新（512–550 行），Lemma 3.2 的 count-history（580–657 行），Theorems 3.4–3.5 的函数 oracle 与 completeness（717–847 行），Theorems 4.1、4.3 的同源调用（883–912、1040–1085 行），以及固定 truth-table generator（1151–1166 行）。没有访问 Pro 会话、网络或远程主机；不把 Pro 的同意当作证据。

## 1. 固定对象与本轮观测

保持同一 \(C,K,G\)、raw-binary systematic-prefix 约定及全部实际 tie-break。令
\[
 n=2^q,\qquad N=n^C=2^m,\qquad m=Cq,\qquad T_0=2^{cn},
 \qquad q\in\mathcal A_C.
 \tag{1}
\]
\(\Pi_q\) 始终是实际 \(BF_0\to C_{x_0}\to K\) 输出的那一串。沿用上一份 scratch 的长度和初次 JK 补零：
\[
 \widehat\Pi_q=\Pi_q0^{\widehat P_q-P_q},\qquad
 \widehat P_q=N2^{k_q},\qquad
 J_q=2^{k_q-1}=2^{b_q},\qquad
 X_{q,j}=\widehat\Pi_q[2Nj:2N(j+1)].
 \tag{2}
\]
首批 \(j<J_q\) 都是实际发出的查询。定义原 seed 坐标上的集合
\[
 F_{q,j}=\{u\in\{0,1\}^{N}:G_N(u)=X_{q,j}\},\qquad
 E_{q,j}(p)=\mathbf1[F_{q,j}\cap[p]\ne\varnothing],
 \tag{3}
\]
其中 \([p]=\{u:p\preceq u\}\)。于是
\[
 c_q=\sum_{j<J_q}E_{q,j}(\epsilon),\qquad
 A_q\iff c_q=J_q.
 \tag{4}
\]
\(A_q\) 是原程序进入首阶段 seed-search 的 guard。这里每个 YES 块只计一次，不按其原像数计数。

实际 \(b_q=\Theta(n)\)，但 count 位地址只需 \(O(\log(b_q+1))=O(m)\) 位。本文以 \(a=0\) 表示最低有效位；与原固定宽度、最高有效位在前的 history 编码相接时使用 \(a\mapsto b_q-a\)，若 history 字段更宽则照原长度补前导零。这只是同一整数的位地址转换，不改变其序列化。

本轮不重证已知输出块的覆盖或任何 seed 长度下界。后文所有集合均来自 (2)，不引入另一个 proof、layout 或任意 batch。

## 2. 保留函数值、保留原像、保留实际前缀的区别

### 2.1 完整前缀域上的精确投影条件

设函数级候选用代数变量 \(z\) 定义
\[
 \widetilde F_{q,j}
 =\{u\in\{0,1\}^{N}:\exists z\;\mathcal H_q(j,u,z)\}.
 \tag{5}
\]
暂不赋予 \(\mathcal H\) 任何免费 oracle，也不预设它具有短表示。

**引理 1。** 对每个固定的实际 \(q,j\)，
\[
 \bigl[\forall p\in\{0,1\}^{\le N},\quad
 \mathbf1[\widetilde F_{q,j}\cap[p]\ne\varnothing]=E_{q,j}(p)\bigr]
 \quad\Longleftrightarrow\quad
 \widetilde F_{q,j}=F_{q,j}.
 \tag{6}
\]
**证明。** 集合相等立即给出全部非空性答案。反之，取长度 \(N\) 的前缀 \(p=u\)；其 cylinder 是单点 \(\{u\}\)，故逐个 seed 的成员资格相同。\(\square\)

所以无需代数见证与 seed 一一对应，也无需按代数变量的字典序选择见证；允许多个 \(z\) 表示同一 seed。需要保持的是**投影到原 seed 坐标后的可行集**。只证明“存在一个表示这个函数的电路”只处理 \(p=\epsilon\)，没有处理其他前缀。将该电路编码选作下一 seed，同样没有证明它是原固定 decoder 的 lex-first 编码。

若 \(F_{q,j}\ne\varnothing\)，这个集合在集合论意义上确定 \(X_{q,j}\)：任取其中的 \(u\)，便有 \(X_{q,j}=G_N(u)\)。若它为空，则不确定该 NO 块的内容。这个观察既不产生廉价选取 \(u\) 的算法，也不是实际块的电路下界。

### 2.2 实际查询域比全部前缀域弱

必须保留 RW 原程序的 dummy-variable 约定。令 \(h_q\) 为本次固定运行的 chunk 宽度，\(L_q=h_q\lceil N/h_q\rceil\) 为其 padded seed 长度，\(\rho_q:\{0,1\}^{L_q}\to\{0,1\}^{N}\) 为**同一程序**删除 dummy 坐标的投影。这里不另定 dummy 插入位置或位序。令
\[
 \widehat F_{q,j}=\rho_q^{-1}(F_{q,j}),\qquad
 \widehat E_{q,j}(p)=\mathbf1[\widehat F_{q,j}\cap[p]\ne\varnothing].
 \tag{7}
\]
若不需 padding，\(\rho_q\) 就是恒等映射。由于只是按原顺序删除自由 dummy 位，padded lex-first seed 删除这些位后正是原 \(F_{q,j}\) 的 lex-first seed。

只在 \(A_q\) 真时，令 \(p^*_{q,j,\ell}\) 为原运行在第 \(\ell\) 个 prefix 轮次前已经确定的前缀，并定义实际 YES 候选集
\[
 S^*_{q,j,\ell}
 =\{t\in\{0,1\}^{h_q}:
       \widehat E_{q,j}(p^*_{q,j,\ell}t)=1\}.
 \tag{8}
\]
原文 535–540 行询问全部 \(2^{h_q}\) 个候选，再取 \(\min_{\rm lex}S^*_{q,j,\ell}\)。因此该并行轮的真实 YES 数为
\[
 d_{q,\ell}=\sum_{j<J_q}|S^*_{q,j,\ell}|.
 \tag{9}
\]

**引理 2。** 在同一首批 guard 下，候选语义保持全部实际 \(S^*_{q,j,\ell}\) 的必要充分条件是
\[
 \widetilde E_q(j,p^*_{q,j,\ell}t)
 =\widehat E_{q,j}(p^*_{q,j,\ell}t)
 \quad\text{对每个实际 }j,\ell\text{ 及全部 }t\in\{0,1\}^{h_q}.
 \tag{10}
\]
这里不要求离开真实路径后的其他前缀也满足等式。

**证明。** 第零轮前缀均为空。若前 \(\ell\) 轮更新相同，则两边下一轮查询的前缀相同；(10) 给出相同的全部候选答案，因而给出同一最小候选、同一更新及 (9)。按轮次归纳即可。反向，保持该轮的候选集正是保持每个候选的成员资格。\(\square\)

特别地，只保留每轮赢家能保留最终 seed，却没有规定大于赢家的候选答案，因而不足以据此证明 (9)。只保留一个 count 也没有规定它来自哪些候选。这里陈述的是所需等式之间的逻辑区别，没有声称 actual orbit 已出现两种不同答案。

若 \(A_q\) 假，原程序在首批后返回 hard，(8)–(10) 不构成实际可达要求。不能在这个分支构造反事实的 prefix batch，再把它用作 R2 NOGO。若 \(A_q\) 真，(10) 给出同一最终原 seed \(U_{q,j}\)，故下一 stage 仍是原相邻拼接
\[
 Y_{q,k}=U_{q,2k}U_{q,2k+1}.
 \tag{11}
\]
这证明的是语义保真；没有由此获得 (11) 的地址尺度生成或下一 count 闭合。

## 3. 函数级代数化中，布局究竟出现在哪里

给函数级路线最有利的前提：其 \(\mathcal O_q\) 已经是**同一 K 实际产生的** raw/witness 与代数 oracle 数据，原有限域表示和记录编码也相同。不是任意被 PCP verifier 接受的另一组函数。此前关于逐变量次数的推导可以约束这些函数；本节不需要重新计算那些次数。

令 \(V_q(\omega)\in\{0,1\}\) 表示一个原记录的实际编码位，\(\omega\) 包含记录类型、点、分量及 bit 位置；raw 位和零 padding 也放入该索引域。若某个编码位依赖整个 tuple，就把该原编码作用包括在 \(V_q\) 的定义中。对实际 serialization 的映射 \(\sigma_q\)，块限制算子为
\[
 (\Lambda_{q,j}V_q)(a)
 =V_q\bigl(\sigma_q(2Nj+a)\bigr)=X_{q,j}[a],
 \qquad 0\le a<2N.
 \tag{12}
\]
式 (12) 是对实际映射的命名，不是提供了它的公式、代码或免费调用权。若候选不能先证明其函数记录确实对应同一 K，(12) 之前还缺这项源绑定。

现在只对原 generator 做恒等的 Boolean 代数化。令
\[
 \mathcal B_L=\mathbb F_2[U_1,\ldots,U_{L_q}]/(U_i^2-U_i:i\le L_q),
\]
并令 \(\gamma_{q,a}(U)\) 是同一电路 \(G_N(\rho_q(U))\) 的第 \(a\) 个输出函数。定义
\[
 H_{q,j}(U)=
 \prod_{a<2N}\bigl(1+\gamma_{q,a}(U)+(\Lambda_{q,j}V_q)(a)\bigr)
 \quad\text{于 }\mathcal B_L.
 \tag{13}
\]
每一因子恰为一个输出位的相等性指示，故
\[
 H_{q,j}(u)=1\iff u\in\widehat F_{q,j}.
 \tag{14}
\]
Boolean 商环中每个元素对应唯一的 Boolean 函数。因此，对任一 seed 前缀 \(p\)，
\[
 \widehat E_{q,j}(p)=1
 \iff H_{q,j}(p,\cdot)\ne0
 \quad\text{于剩余变量的 Boolean 商环}.
 \tag{15}
\]
这一步是 exact 的：非零恰好意味着至少一个 Boolean 赋值使该函数为 1，不是随机 polynomial identity test。

**命题 3（代数函数到实际 count／prefix 的精确归约）。** 同一实际首批满足
\[
 c_q=\sum_{j<J_q}\mathbf1[H_{q,j}\ne0],\qquad
 S^*_{q,j,\ell}
 =\{t:H_{q,j}(p^*_{q,j,\ell}t,\cdot)\ne0\}.
 \tag{16}
\]
第一式在整数中求和。若新代数表示 \(\widetilde H\) 在实际候选域保持 (15) 的零／非零状态，就由引理 2 保持 prefix 集合；无需保持某种特定辅助变量、系数表或求值算法。若它保持全部前缀，则由引理 1 保持整个原 seed 原像集合。

证明直接由 (14)–(15) 与 (4)、(8) 得出。\(\square\)

这定位了最小依赖：可以不输出 \(\sigma_q\)，甚至不输出 \(X_{q,j}\)，但须证明新的关系保持 **(12) 所绑定的原 seed-cylinder 非空性**，以及 (16) 第一式的实际聚合。完整 \(\sigma_q\) 是建立源绑定的一条途径；不能把“尚未给出 \(\sigma_q\)”升级为“任何 count 公式都必须恢复完整 \(\sigma_q\)”。不同记录若在实际函数上取相同 bit，(12) 本身也不会区分那些记录。

普通低次数恒等式作用于 \(\mathcal O_q\) 的域变量，(15) 则限制原电路编码的 seed 位。两种变量不能直接互换。沿若干线的 Horner 电路存在性，在其原窗口 routing 已证明时可给 \(H_{q,j}\ne0\)；它没有给每个 \(H_{q,j}(p,\cdot)\) 的零性。类似地，在 \(\mathbb F_2\) 中对 \(H\) 的取值求和得到原像数的奇偶性，在整数中求和得到原像数；两者都不是 (16) 中“非空记一次”的操作。本文不假定 actual fibers 的大小或奇偶性。

RW 原文 741–769 行给出网格双射、函数 oracle 及其构造语义，791–794 行给出 systematic 性质，没有列出本次实际 (12) 的完整索引公式。Paper 04 Proposition 1.27 指明该来源边界；Proposition 1.28 的 oracle-major compiler 是附加选择，不能用于替换本次冻结对象。本文没有从任何其他 serialization 构造反例。

## 4. 一个完全计价的 exact 首批 count 关系

式 (16) 还不是合格矩阵：零性和整数求和不能充当免费代数门。可以给出以下有限基线，明确它们的支付位置，而不枚举全部 \(2^N\) 个 seed。

给定**同一固定 K 和 G 的程序**，展开实际确定性源，得到普通电路 \(\mathcal X_q(j)\)，输出 (2) 的完整块 \(X_{q,j}\)。如指定的残余块 scratch 所述，存在固定指数 \(A_0\) 使
\[
 S_X:=|\mathcal X_q|\le T_0^{A_0},\qquad
 g_N:=|G_N|\le N^4.
 \tag{17}
\]
这是参数化于同一 K 的常规时间到电路展开，不是把 proof、布局或窗口当作 oracle。仅知 K 的存在而没有代码时，也没有凭此生成具体 gate-list。

令 \(y\in\{0,1\}^{J_q}\)，\(U=(u_0,\ldots,u_{J_q-1})\)，每个 \(u_j\in\{0,1\}^N\)。对 \(0\le a\le b_q\)，定义
\[
\begin{aligned}
 \mathsf{CountBit}_q(a,\beta):\quad
 \exists y^{J_q},U^{J_qN}\;\forall j^{b_q},v^N:\quad
 &\operatorname{bit}_a\!\left(\sum_{r<J_q}y_r\right)=\beta\\
 &{}\land
 \bigl[(y_j\land G_N(u_j)=\mathcal X_q(j))\\
 &\hspace{34mm}\lor(\neg y_j\land G_N(v)\ne\mathcal X_q(j))\bigr].
\end{aligned}
 \tag{18}
\]
其中 \(y_j,u_j\) 用普通 mux 读取，求和用普通 Boolean 加法器，位选择也显式实现。

**命题 4。** 对每个实际 \(q\)、有效 \(a\) 及 \(\beta\in\{0,1\}\)，
\[
 \mathsf{CountBit}_q(a,\beta)
 \iff\operatorname{bit}_a(c_q)=\beta.
 \tag{19}
\]
**证明。** 若 \(y_j=1\)，(18) 强制 \(u_j\in F_{q,j}\)。若 \(y_j=0\)，全称 \(v\) 强制 \(F_{q,j}=\varnothing\)。因而每个 \(y_j\) 都被唯一固定为实际 membership 答案。反向取这些真实答案，对 YES 块取任一存在的原像作为证书，对 NO 块任置未使用的 \(u_j\)，即可满足矩阵。整数求和遂给 (19)。\(\square\)

此处“任取原像”仅为证明一个 YES 位的存在证书，**不将它传给原 JK 更新**。后续 lex-first 仍由 (7)–(10) 的原前缀集合确定。因此 (18) 没有改选原程序的 seed。

总量词位数和一个保守矩阵上界分别为
\[
 P_{\rm quant}=J_q(N+1)+b_q+N,
 \tag{20}
\]
\[
 S_R\le S_X+2g_N+
 O\bigl(J_qN+J_q(b_q+1)+N+b_q+\log(b_q+2)\bigr).
 \tag{21}
\]
\(J_qN\) 支付 seed-array mux，\(J_q(b_q+1)\) 支付计数；\(N+b_q\) 支付等式、选择及控制。包括输入位置、量词布局和门表的显式描述长为
\[
 O\bigl((S_R+P_{\rm quant}+b_q+1)
         \log(S_R+P_{\rm quant}+b_q+2)\bigr).
 \tag{22}
\]
由于 \(J_qN=\widehat P_q/2<T_0^{O(1)}\)，给定同一 K/G 代码与公开参数，这一展开及生成可在 \(T_0^{O(1)}\) 内完成。没有长 advice；全部长数组都是 (20) 中已支付的量词位。本文没有实际构造这个大电路。

这给出一个 exact \(\Sigma_2\) count 图，避免将 seed 枚举当作唯一有限化方式；**它仍是 object scale**。配套的原前缀关系直接是
\[
 \widehat E_{q,j}(p)=1
 \iff\exists z\in\{0,1\}^{L_q-|p|}:\quad
 G_N(\rho_q(pz))=\mathcal X_q(j).
 \tag{23}
\]
为将 (23) 写成一个固定宽度模板，可输入一个 \(L_q\)-bit padded prefix 和长度 \(r\le L_q\)，量化 \(u^{L_q}\)，并在矩阵中加入所有 \(i<r\) 的 \(u_i=p_i\) 检查。这样量词位为 \(L_q\)，显式输入长为 \(b_q+L_q+O(\log(L_q+2))\)，矩阵至多
\[
 S_E\le S_X+g_N+O\bigl(L_q\log(L_q+2)+N\bigr).
 \tag{23a}
\]
同一 \(\rho_q\) 的固定删除连线在此逐根列出；完整门表／输入／量词布局长为 \(O((S_E+L_q+b_q)\log(S_E+L_q+b_q+2))\)，生成费用仍为 \(T_0^{O(1)}\)。它与 (18) 共用同一 \(\mathcal X_q\)，所以满足第 2 节的语义保真。类似地，(13) 的直接直线电路可用 \(S_X+g_N+O(N+L_q)\) 门计算其取值，但**对所有 seed 判定零性**没有变成一个免费门，仍由量词或另一个已计价算法处理。这里列的是这些构造的费用，没有获得短表示，也不是其他构造的下界。

## 5. 地址尺度问题剩下的最早接口

首批 count 单独要求的只是
\[
 R_{\delta_q}(a,\beta)
 \iff\operatorname{bit}_a\!\left(\sum_{j<J_q}E_{q,j}(\epsilon)\right)=\beta.
 \tag{24}
\]
它不逻辑要求逐块输出 \(E_{q,j}\)。例如，若另有针对同一实际源的证明表明 \(A_q\) 恒真，则 \(c_q=2^{b_q}\)，(24) 可化成 \(\beta=\mathbf1[a=b_q]\)；\(b_q\) 本身只需 \(O(m)\) 位。这个条件结论没有断言本次 \(A_q\) 为真，并且即使成立也没有给出 (10)。反过来，完整 count 图的最高位给出 \(A_q\)，因为 \(0\le c_q\le2^{b_q}\)。

因此，本问题不能被收紧成“先求全 layout，否则连 count 都不可能”。对**同时保持实际 prefix 集合**的候选，最早必须补的是：

> 将同一 K 的实际函数数据与原 seed 坐标相连，证明其短表示保留 (10)／(15) 在全部真实可达候选上的真假，并证明 (24) 的实际计数恒等式。显式窗口 pullback (12) 是充分的源绑定方式；直接证明这些观察量的短因子化也允许。

这项接口的合格费用必须统一计入：共同 descriptor/advice、全部显式输入和量词位、普通 Boolean matrix、显式 gate-list 与量词／输入布局、prefix／候选控制，以及给定共同 advice 后的生成时间。它们须由跨 admissible \(q\) 的一个固定 \(m^d\) 控制。Advice 可非一致，不额外要求在该时间内发现正确 advice；但其长度、展开和正确的源绑定不能豁免。

长 \(j\) 或长 \(p\) 不能作为“关系参数”免费出现；若用短控制、整体分类或聚合恒等式替代，需证明它代表的是这些实际查询。这里不额外要求每个实际 \(j\) 都有一个可独立查询的短句柄。类似地，\(J_q=2^{b_q}\) 等特殊整数允许用已证的短算术表示，不能仅因其字面位数大就断言所有表示都失败。低次数、多项式系数、域运算、bit 编码以及 Boolean 商环零性测试若参与短构造，也都须落实到同一预算。

固定 \(q,K\) 已在数学上唯一确定 actual string；重跑它的有限基线是 (17)–(23)。故“文献没有写出布局”不是信息论不可能性。反之，函数级次数与 completeness 定理本身没有证明 (10)、(15) 或 (24) 在短表示下成立，未定义的 pullback 也不能作为一个免费代数门。

**停止点：UNKNOWN。** 已证的是原 seed 集合／实际前缀的精确投影条件、Boolean 零性归约 (16)，以及完全计价的 object-scale count 图 (18)。尚缺最早的 address-scale actual-source 观察桥接；没有证明它存在或不存在。完整布局源码若已存在，可用来检验这一桥接；也可用新的同源整体恒等式替代，但本轮现有材料没有给出其中任何一项。不以任意 serialization、不可达 batch、其他可接受 proof、W 或字面 seed 下界补这个缺口；不切换 R3。
