# R2：前驱候选关系的核验与全局 seed 重编码的边界

2026-09-26。本文件只属于本轮 scratch 推导，不晋级为项目 note。

## 范围与结论

本轮只处理冻结 SPEC 的 R2。候选输入为同目录 `pro-full.txt`，事实依据回到本地保存的 Ren–Williams ECCC TR26-118 revision 1。没有网络请求、远程访问或数值搜索，没有改变生成器、PCP constructor、序列化或真实轨道。

Pro 的前驱候选公式、首个 membership 查询的复合、全批执行守卫和有守卫的 canonical-inverse 事件，在下述冻结约定下均语义正确。其量词宽度与矩阵规模确实仍为 object scale。

本轮只尝试一条压缩引理：把 Pro 关系中的长 seed 量词改为短 transcript，并由同一描述下的确定解码恢复每次使用的全局 seed，同时保留原关系在真实基点上逐项的见证义务。该引理失败：总 transcript 位宽至少为

\[
\Omega(n/\log n)=\Omega(2^{m/C}/m).
\]

证明只使用实际 \(B_0\) 及其同一生成器中的真实前驱像，不使用 arbitrary-generator 反例、任意 SAT 输入或不可达答案向量。此结论不排除整体消去这些逐项见证的非字面关系，因此 **R2 结论仍为 UNKNOWN，不是 R2 NOGO**。

## 1. 原始来源与固定对象

原始来源为本地文件：

`[unmapped-local-locator]`。

使用的承重段落为：

- Theorem 3.1 的证明，原文 pp. 8–9，提取文本约 490–548 行：先对所有连续块执行 membership batch；任一 NO 则退出；仅全 YES 时逐 chunk 恢复 lexicographically least seed。
- Lemma 3.2、Claim 3.3、Algorithm 1，pp. 9–11，约 578–714 行：history 顺序为 counts、output、witness arrays；正确 counts 强制正确答案向量；lex maximum 给出 canonical history。
- Theorems 3.4–3.5，pp. 11–13，约 732–850 行：完整 witness 包含输入 assignment 和全部 gate values；固定 completeness 算法从该 witness 生成 proof；输出字段属于 systematic prefix。
- Theorem 4.3，pp. 16–18，约 1040–1149 行：\(BF_0\) 为 lex-first range outsider，\(r_0=s_0=0\)，输出补零至 \(T_0\)，以及 \(n_1=n_0^C\)。
- Theorem 4.5 前后的 truth-table generator 定义及 circuit-size 推论，约 1152–1170 行。

项目约束来自 `AGENTS.md`、工作区同步 README、冻结 `SPEC-2026-09-23-fixed-orbit.md`。Paper 04 的 Proposition 1.3A 与 1.3E 用于核对 semantic surface 与完整计价的区别；Proposition 1.27 用于核对二进制序列化的证据边界。Note 613 的投影重新由原始 truth-table generator 和 systematic prefix 验证，而非仅凭旧记录采纳。

固定

\[
n=n_0=2^q,\quad N=n_1=n^C,\quad m=\log_2 N=Cq,\quad
T_0=2^{cn}.
\]

\(C,c\) 固定，\(q\) 为充分大的实际启用起点。令

\[
B=B_0=\min_{\rm lex}\bigl(\{0,1\}^{2n}\setminus\operatorname{Range}(G_n)\bigr),
\qquad \beta=\operatorname{Val}(B).
\]

\(\operatorname{Val}\) 使用通常的最高有效位在前的二进制顺序，所以数值次序等于字典序。所有地址从零开始。\(B\) 的地址长度为 \(q+1\)，首个 \(2N\)-bit JK block 的地址长度为 \(m+1\)。

对 published truth-table generator，所有大小不超过 \(0.1n/q\) 的相关 Boolean circuits 均可由 \(n\) 位描述覆盖。因此

\[
\operatorname{CC}(B)>0.1n/q. \tag{1}
\]

这是每个充分大的基阶段的无条件结论，不依赖 later good-length advice 或某次 JK 的 success/failure。

### 1.1 序列化边界

本轮使用 SPEC 与 Note 613 已要求的二进制 raw-history-prefix 约定：raw assignment 在 complete witness 前部，完整 witness 在 systematic proof 前部，并保持这些二进制位的顺序。由于 \(r_0=s_0=0\)，raw history 只有 output 字段，其唯一可接受值为

\[
B0^{T_0-2n}.
\]

在 \(T_0\ge2N\) 时，实际第一块因而是

\[
Z_0=B0^{2N-2n}. \tag{2}
\]

条件 \(c2^q\ge Cq+1\) 对充分大的实际起点成立。仅有 \(T_0\ge N\) 不能推出 (2)。

原文给出 systematic-prefix 的抽象性质，但不唯一指定所有 binary field encodings、auxiliary-oracle 顺序、机器到电路的 gate order 或某一个具体 completeness constructor。特别是，仅逐个 field symbol 展开为固定宽度 binary 编码，不能未经核对就认定原始 output bits 连续占据最前面的坐标。

因此，Pro (2) 及其所有涉及 \(Z_0\) 的公式，是在题设冻结的 raw-binary-prefix 约定下成立，不能外推为所有 source-compatible 序列化的不变量。本轮保持该约定，不另选 serializer。以下全批公式还须使用同一固定 constructor \(K\)；“另有一个被 verifier 接受的 proof”不能替代同一实际 proof。原文没有唯一指定 \(K\) 这一事实，不影响以固定 \(K\) 为参数的证明，但不应把它写成原文唯一确定的完整 bitstring。

## 2. 前驱候选基关系：逐式验证

对 \(e=(\tau,u)\in\{0,1\}^{n+1}\)，定义

\[
\begin{array}{c|cc}
&\tau=0&\tau=1\\ \hline
V_n(e)&1&[G_n(u)\ne1^{2n}]\\
c_n(e)&0^{2n}&G_n(u)+1
\end{array}
\]

无效输入上的 \(c_n\) 任意总化；\(\tau=1\) 时溢出由 \(V_n\) 排除。加一是整段 \(2n\)-bit word 的整数加一，不是逐位 XOR。

### 2.1 真实最小缺失值有前驱候选

若 \(B=0^{2n}\)，使用 \(\tau=0\)。否则，\(B-1<B\)，由 \(B\) 的最小性，存在真实 seed \(u_*\) 使

\[
G_n(u_*)=B-1.
\]

此时 \(e_*=(1,u_*)\) 有效且 \(c_n(e_*)=B\)。它是同一个实际生成器的像点后继，不涉及另造的 outsider。

### 2.2 Pro (5)–(6)

定义

\[
M_n(y;s,e,t):=
[G_n(s)\ne y]\land
[\neg V_n(e)\lor c_n(e)\ge_{\rm lex}y\lor G_n(t)=c_n(e)]. \tag{3}
\]

其中 \(|s|=|t|=n\)、\(|e|=n+1\)、\(|y|=2n\)。则

\[
\forall s,e\;\exists t\;M_n(y;s,e,t)\quad\Longleftrightarrow\quad y=B. \tag{4}
\]

证明：左侧第一项使 \(y\) 为 outsider，故 \(y\ge B\)。若 \(y>B\)，使用上一段的 \(e_*\)，第二项强制某个 \(t\) 满足 \(G_n(t)=B\)，矛盾。反向，若 \(y=B\)，所有有效且小于 \(B\) 的候选都在 range，逐候选选择其真实原像即可。其余候选使第二项自动成立，任取 \(t\)。各量词域非空，\(t\) 依赖 \((s,e)\) 不造成问题。

这验证了 Pro 的最小性论证；没有发现漏掉比 \(B\) 小的候选而导致假阳性的情形。

### 2.3 Pro (7)–(9)

令

\[
d_{n,N}(e,a)=
\begin{cases}
c_n(e)[a],&0\le a<2n,\\
0,&2n\le a<2N.
\end{cases}
\]

则

\[
\begin{split}
\mathsf{ZBit}_0(a,b):=\exists e_0\;\forall s,e\;\exists t:\quad
V_n(e_0)\land[d_{n,N}(e_0,a)=b]\land
M_n(c_n(e_0);s,e,t)
\end{split} \tag{5}
\]

在合法地址与 \(b\in\{0,1\}\) 上精确等价于 \(Z_0[a]=b\)。若需 total predicate，可添加合法地址守卫，费用 \(O(m)\)。

由 (4)，所有被接受的 \(e_0\) 都解码为同一个 \(B\)。同一个 \(e_*\) 可用于全部地址；无需要求不同地址的实际量词见证在 seed 编码上完全相同。这里的一致性是 decoded word 的一致性，不能省去 seed 本身的量词成本。

量词块长依次为 \(n+1,2n+1,n\)，合计 \(4n+2\)。矩阵只需四份 \(G_n\)；整词比较、increment、有效性和选择一位的 mux 都可用线性 gate 数实现。若 \(g_n=|G_n|\)，则

\[
S_{\rm ZBit}\le4g_n+O(n+m). \tag{6}
\]

这里“无整词量化变量”成立，“地址尺度”不成立，因为 \(n=2^{m/C}\)。

## 3. 首个 membership 查询的实际复合

对 \(u\in\{0,1\}^{N}\)，令

\[
A(u)=G_N(u)[0:2n],\qquad
\mathsf{Tail}(u)=[G_N(u)[2n:2N]=0^{2N-2n}],
\]

\[
F(u;s,e,t)=\mathsf{Tail}(u)\land M_n(A(u);s,e,t).
\]

Pro (10) 为

\[
\Phi_0:=\exists u\;\forall s,e\;\exists t\;F(u;s,e,t). \tag{7}
\]

由 (4)，任何成功的 \(u\) 都满足 \(A(u)=B\)，加上 Tail 即得到 \(G_N(u)=Z_0\)。反向取 \(Z_0\) 的任一实际原像即可。因此

\[
\Phi_0\Longleftrightarrow Z_0\in\operatorname{Range}(G_N). \tag{8}
\]

原文 Theorem 3.1 先并行发出整批 membership queries，故这次首块查询确实发生，不需要假设整个 batch 为 YES。其语义是同一 \(BF_0\) 最小缺失值接到同一 systematic 第一块，再接到原 \(G_N\)-membership，不是换目标。

量词总宽度为 \(N+3n+1\)，矩阵上界为

\[
S_\Phi\le g_N+3g_n+O(N). \tag{9}
\]

\(A(u)\) 是已计价 \(G_N\) 的内部输出线，未充当外部免费 payload。

### 3.1 完整答案图

写 \(v=(s,e)\)，则 Pro (13) 的正确清晰写法为

\[
\exists u\;\forall(v,\bar u)\;\exists(t,\bar v)\;\forall\bar t:
[(b=1\land F(u;v,t))\lor(b=0\land\neg F(\bar u;\bar v,\bar t))]. \tag{10}
\]

在 \(b=1\) 时去掉 dummy variables 就是 (7)；在 \(b=0\) 时就是其否定。多余全称变量增加的依赖不改变真假：固定任意 dummy 值即可取得逆向蕴含。因而其四个量词块、\(2N+6n+2\) 位总宽度、\(2g_N+6g_n+O(N)\) gates 的计价正确。

### 3.2 对 Pro 一个保留判断的补充：此首查询实际恒为 YES

Pro 没有把 \(Z_0\in\operatorname{Range}(G_N)\) 当作前提，这是正确做法；但它将该命题继续称为“未经证明”，遗漏了一个由同一 published 覆盖性质可直接证明的结论。

任意长度 \(2n\) 的表可用 \(O(n)\) 个 fan-in-two gates 的 mux tree 实现。把 \(B\) 硬接在该电路中，再检查输入的高 \(m-q\) 位全为零，得到 \(Z_0\) 的电路，大小

\[
\operatorname{CC}(Z_0)\le K n+K'(m+1)
<0.1N/m \tag{11}
\]

对充分大基点成立，因为 \(N=n^C\)。published truth-table generator 在长度 \(N\) 覆盖这些大小的 circuits，故 (8) 两侧为真。

这个存在性证明不提供短的具体 \(N\)-bit seed，也不声称其内容可从短描述逐位计算。它与 \(\operatorname{CC}(Z_0)=\Omega(n/q)\) 完全相容：下一层可编码的 circuit budget 远大于 \(n\)。

因此，单独的 \(\Phi_0\) 真值可化成常真；这不是一个保持原 seed 见证或 canonical preimage 的压缩。不能据此推出整个 batch 为 YES，更不能推出下一步 inversion 实际执行。本段是原公式的语义核对，不是本轮另开的压缩方案。

## 4. 全批守卫、canonical inverse 与控制一致性

设 \(C_0\) 为固定 base history circuit。对形式 \(y\in\{0,1\}^{2n}\)，令

\[
w(y)=(y0^{T_0-2n},\;\text{固定 }C_0\text{ 在该输入上的全部 gate values}).
\]

使用同一个固定 constructor \(K\)。在 \(y=B\) 时，\(w(B)\) 是实际完整 witness，故 \(K(C_0,w(B))=\Pi_0\)。对无效输入作固定时钟下的总化不会影响这个身份。

令 \(L_0=|\Pi_0|\)，\(L'_0=N2^k\)，\(k=\lceil\log_2(L_0/N)\rceil\)，\(J=L'_0/(2N)=2^{k-1}\)，\(\ell_J=k-1\)。将生成 \(C_0\)、求 gate values、运行 \(K\)、按原规则补零与 block selection 全部展开为电路 \(\Gamma_n(y,j)\)。则

\[
\Gamma_n(B,j)=Z_j\quad(0\le j<J),\qquad
\gamma_n:=|\Gamma_n|\le2^{O(n)}. \tag{12}
\]

这里将第一块记为 \(Z_0\)，其余依次编号。上界来自 \(\operatorname{poly}(T_0)\) 时间算法的普通电路展开，可使用宽松的平方开销；不是对最优电路的下界。

必须保留实际 proof 长度与 block alignment。若固定布局使长度只依赖公开参数，可直接计算；若具体 \(K\) 的输出长度还依赖 witness，应在这项 \(\operatorname{poly}(T_0)\) 构造费用内求出实际长度。不能用另一个方便的 polynomial bound 重新补齐并宣称得到同一个 JK 过程，也不能把实际 \(L_0\) 的长二进制表示当作免费 advice。两种合法实现均保留 (12) 的上界。

### 4.1 Pro (17)–(18)

\[
\begin{split}
\mathsf{All}_0:=\exists e_0\;\forall(s,e,j)\;\exists(t,u):\quad
&V_n(e_0)\land M_n(c_n(e_0);s,e,t)\\
&\land[G_N(u)=\Gamma_n(c_n(e_0),j)].
\end{split} \tag{13}
\]

\(j\in\{0,1\}^{\ell_J}\) 恰好覆盖实际 \(J\) 个块，无多余地址。公式前部固定 \(c_n(e_0)=B\)，故它精确等价于 \(\forall j<J\,Z_j\in\operatorname{Range}(G_N)\)。各块可使用不同原像；同一块是否还有多个原像不会影响该 guard。这里不要求不同块共享一个 seed，要求的是每个块使用的 seed 是完整一致的对象。

量词总宽度 \(N+4n+\ell_J+2\)，矩阵上界 \(\gamma_n+g_N+4g_n+O(N)\)，均与 Pro 相符。

### 4.2 Pro (19)–(20)

在 (13) 的外层存在变量中加入 \(u_0\in\{0,1\}^{N}\)，在全称层加入 \(v\in\{0,1\}^{N}\)，并加上

\[
\begin{split}
&G_N(u_0)=c_n(e_0)0^{2N-2n},\\
&v\ge_{\rm lex}u_0\ \lor\ G_N(v)\ne G_N(u_0),\\
&u_0[a]=b.
\end{split} \tag{14}
\]

这精确表达：实际程序进入第一层 inversion，且该层对首块恢复的 lex-least seed 的第 \(a\) 位为 \(b\)。原文的 \(\psi_{q,\ell,j}\) 明确对原 generator seed 的前缀作限制，因此逐 chunk 选取最小可延伸前缀正好恢复这个 seed。这里不能把一个未指定变量顺序的 Cook–Levin 辅助 assignment 的 lex minimum 代入；Pro 使用的是原始 seed，故没有犯此错误。原文增加的 dummy variables 位于原 seed 后方，删除后不改变原 seed 的 lex order。

若 \(\mathsf{All}_0\) 不成立，两个 bit 事件都为假。这是未发生的执行事件，不是为未执行查询补一个任意答案。因此正确区分了“首块为 YES”和“整批为 YES”。

量词总宽度 \(3N+4n+\ell_J+2\)，矩阵上界 \(\gamma_n+3g_N+4g_n+O(N)\)，也正确。但没有由此证明 \(\mathsf{All}_0\) 在某一或所有基点成立，故不能把 guarded formula 的存在说成已经观测到 canonical-inverse event 实际到达。

### 4.3 Pro 的 count-prefix 论证

在固定且实际到达的一批 queries 上，给定 witness arrays 后被 history verifier 标成 YES 的集合 \(A\) 是真实 YES 集 \(S\) 的子集，因为 false query 没有可接受 witness。正确 count 要求 \(|A|=|S|\)，因此 \(A=S\)。固定机器只根据 query answers 更新状态，故正确 counts 强制同一真实 next query batch；归纳得到实际后续控制。

正确 count-prefix 不固定各个成功 witness 的字典序最大选择。要恢复同一完整 canonical history 和同一 \(\Pi_i\)，仍须使用原文的 lex maximum 和固定 \(K\)。Pro 已指出这一区别，因此该段没有语义错误。关于“在同一点停止”，严格依赖同一固定 deterministic tie-break；原文若只写选择某个 NO block，必须保持原实现中已有的选择规则，不能任意换成 leftmost。

## 5. 完整计价

\(g_s\) 为实际展开的 \(G_s\) gate 数；\(\gamma_n\) 为 (12) 的已展开电路规模。普通有限基、fan-in-two circuits 允许共享已计算输出线，但不允许 oracle gate 或免费 ROM。

| 关系 | 量词块 | 量词总位宽 | 普通矩阵 gates 上界 |
|---|---:|---:|---|
| \(\mathsf{ZBit}_0\) | 3 | \(4n+2\) | \(4g_n+O(n+m)\) |
| \(\Phi_0\) | 3 | \(N+3n+1\) | \(g_N+3g_n+O(N)\) |
| 首查询答案图 | 4 | \(2N+6n+2\) | \(2g_N+6g_n+O(N)\) |
| \(\mathsf{All}_0\) | 3 | \(N+4n+\ell_J+2\) | \(\gamma_n+g_N+4g_n+O(N)\) |
| guarded inverse bit event | 3 | \(3N+4n+\ell_J+2\) | \(\gamma_n+3g_N+4g_n+O(N)\) |

统一 source/constructor 标识及二进制 \(n,N\) 的程序描述可为 \(O(m)\) 位；这不是展开电路的描述长度。若矩阵大小为 \(S\)、显式输入与量词布局宽度为 \(W\)，其普通 gate-list encoding 要支付 \(O((S+W)\log(S+W))\) 位。前面几个矩阵可在 \(\operatorname{poly}(N)\) 时间生成；包含 \(\Gamma_n\) 的矩阵，本轮只有 \(\operatorname{poly}(T_0)\) 的生成与展开上界。

每次矩阵求值支付其实际 gates，不因 source generator 是 P-uniform 而变成 \(\operatorname{poly}(m)\)。对量化关系的真假没有声称普通确定性 polynomial-time 求值；constant PH depth 是其逻辑结构，不能免除宽度与矩阵费用。

由 \(T_0\le L_0\le\operatorname{poly}(T_0)\)，

\[
\ell_J=\log_2J=\Theta(n),\qquad
JN=L'_0/2\ge T_0/2. \tag{15}
\]

所以，block index 与完整 count field 的宽度已经是 \(\Theta(n)\)，按 query 列出的 seed arrays 则至少 \(T_0/2\) 位。这些字段长度本身不是实际 count 函数的 circuit lower bound；例如 count 等于 \(J\) 时可以有短符号描述。

本轮几个 substitutions 保持三或四个量词块，只是一次局部复合的结论，未证明跨所有层的共同常数、共同指数或构造/复合时间界。Paper 04 允许定量受控的增长交替，因此也不应把“所有后续层必须固定 PH 深度”表述成唯一可能的接口。

## 6. 唯一尝试的压缩引理：从短 transcript 恢复全局 seed

### 6.1 精确候选及其额外要求

最直接的保真压缩候选是把 (5)、(7) 的 seed 变量替换成短 code。所有 code 拼成长度至多 \(R(m)\) 的 transcript \(z\)。用一个共同描述 \(\delta_n\) 和 decoder 给出

\[
D_{\delta_n,z}\in\{0,1\}^{n},\qquad
D_{\delta_n,z}[a]=\mathsf{Dec}(n,\delta_n,z,a). \tag{16}
\]

一个固定 \((\delta_n,z)\) 必须在全部 \(a\) 上定义同一个完整 seed，不能在每个 seed-bit address 重新选取互不一致的对象。允许 decoder 依赖全部已经计价的短 transcript 字段，包括较早全称变量，因而没有错误地禁止 existential witnesses 对 universal challenges 的合法依赖。

本次候选保留原 Pro game 的逐项见证含义，特别要求以下最弱的相关 coverage：在真实 \(y=B\) 上，对每个有效 \(e\) 满足 \(c_n(e)<B\)，原矩阵要求的某个原像 \(t\) 必须能够由 admissible 短 transcript 解码出来，并满足 \(G_n(t)=c_n(e)\)。不要求覆盖所有 \(n\)-bit seeds，不要求处理任何其他 source，不要求保留同值 seed aliases，也不要求 decoder 单射。

该 coverage 是“对原 seed 量词作保真重编码”的明确假设，不是所有 truth-equivalent global relations 的必要条件。若通过一个 aggregate identity 整体证明原全称语句而不再逐项解码原 seeds，就已经离开本次引理。

期望的完整预算是固定常数 \(d\) 下

\[
|\delta_n|+R(m)+\text{矩阵及 decoder 的显式描述长度}
\le m^d, \tag{17}
\]

并有相应的构造与一次复合界。若每个 code 长 \(\ell\)，保留原三块结构时只是把原 seed variables 换成相应 code variables；不得把原来的长 \(e\)、原像、gate-value array 或一个源外索引作为 decoder 的额外免费输入。

若 decoder 的单 bit 电路大小为 \(s_D\)，而仍字面展开全部 decoded inputs 和 \(G\)，则基矩阵只有上界

\[
4g_n+O(n s_D+n+m),
\]

首 membership 复合的矩阵只有上界

\[
g_N+3g_n+O(Ns_D+N).
\]

这些不能被改称为 \(\operatorname{poly}(m)\)。下面的反证更早发生：即使暂不限制 decoder 的计算能力，transcript 的宽度本身也不可能满足 (17)。这是放宽模型后证明的限制，绝不是给正向方案免收 decoder 成本。

### 6.2 实际最小缺失值的数值下界

**引理。** 对上述同一个实际 \(B\)，

\[
\log_2\beta=\Omega(n/q). \tag{18}
\]

**证明。** 充分大的基点上，(1) 排除 \(B=0^{2n}\)，故 \(\beta>0\)。令

\[
L=\lfloor\log_2\beta\rfloor+1.
\]

于是 \(B\) 的前 \(2n-L\) 位全为零。取最小的二次幂 \(K\ge L\)，则 \(K<2L\)（\(L=1\) 时同样可用 \(K\le2L\)），且 \(K\le2n\)。后 \(K\) 位可硬接为一个 \(O(K)\)-gate mux tree；输入的高 \(q+1-\log_2K\) 位全为一时才使用该 lookup，否则输出零。因 \(2n\) 与 \(K\) 都是二次幂，这正好选择最后 \(K\) 个地址。此为普通 fan-in-two circuit，全部表常数和 lookup gates 均计入，未使用 ROM oracle。

因此存在绝对常数 \(a,b>0\) 使

\[
\operatorname{CC}(B)\le aL+b(q+1).
\]

与 (1) 合并，

\[
L>\frac{n}{10a q}-\frac{b}{a}(q+1),
\]

从而 \(\log_2\beta\ge L-1=\Omega(n/q)\)。证毕。

这里没有计算 \(B\)、\(\beta\) 或任何 seed。另由 range 大小至多 \(2^n\)，有 \(\beta\le2^n\)，与 (18) 相容。本轮不追求改善 (18) 的常数或对数因子，因为它已经区分地址尺度与非地址尺度。

### 6.3 真实基点强制的 witness 多样性

**引理。** 当 \(y=B\) 时，Pro 矩阵最后一个 seed 字段 \(t\) 的成功选择，跨其实际语义要求的 universal candidates，必须覆盖至少 \(\beta\) 个不同的 seed 值。

**证明。** 每个整数 \(w\in\{0,\ldots,\beta-1\}\) 都在 \(G_n\) 的 range。对 \(w=0\)，使用 \(\tau=0\) 候选。对 \(w>0\)，\(w-1<\beta\)，故存在真实 \(u_w\) 使 \(G_n(u_w)\) 的值为 \(w-1\)；于是有效候选 \(e_w=(1,u_w)\) 的值恰为 \(w\)。

把这个 \(e_w\) 代入 (3) 并令 \(y=B\)。固定任何一个 \(s\)，例如 \(0^n\)，第一项为真；第二项的前两个 disjunct 都为假，因此必须有

\[
G_n(t_w)=\operatorname{bin}_{2n}(w). \tag{19}
\]

不同 \(w\) 需要不同 \(t_w\)，因为生成器是函数。故至少有 \(\beta\) 个不同 seed。证毕。

这些候选由同一个实际最小缺失值的定义保证，是该实际基关系在真值点上的必要义务。它们不是把任意合成答案向量放进 RW 状态机，也不是断言 RW 曾经把全部这些候选作为一次物理 oracle batch 发出。

### 6.4 压缩候选的裁决

固定 \(n\)、共同 \(\delta_n\)、一个合法 target address 及正确 target bit。长度至多 \(R\) 的定长补齐 transcript 只有至多 \(2^R\) 种；每个 transcript 按 (16) 定义至多一个完整 \(t\)。即使把所有 transcript 都算作可用，而不限于某个 winning strategy 实际采用的 transcript，可解码的不同 \(t\) 也至多 \(2^R\)。

由 (19) 的 coverage 要求，

\[
2^R\ge\beta,
\qquad
R\ge\log_2\beta
=\Omega(n/q)
=\Omega(2^{m/C}/m). \tag{20}
\]

如果允许 \(p(m)\) 个已计价的 seed-output slots，最多扩大到 \(p(m)2^R\)，只将下界改为 \(R+\log_2p(m)\ge\log_2\beta\)，对 polynomial \(p\) 没有尺度影响。

所以，逐项保留原见证并从短 transcript 恢复全局 seed 的压缩引理，在每个充分大的实际基点上失败。结论不依赖 decoder 是否容易计算；共同 descriptor 即使携带更多常数，也不增加固定 \(R\) 下可选择的 decoded words 数目。若增加原始长 \(e\)、\(w\) 或另一个大索引作为 decoder 输入，必须将它纳入 \(R\) 或其他已计价显式输入。将一个依赖长原始 challenge 的见证提升函数只放在正确性证明中，且不再由短 transcript 选择原 seed，则不满足本次 pointwise-decoding 假设，不能用 (20) 排除。

同一阻碍适用于保留 Pro (7) 中 \(M_n(A(u);s,e,t)\) 逐项见证的那种首 membership 复合，因为在任一成功 \(u\) 上仍有 \(A(u)=B\)。因此没有获得一个通过基关系再通过实际复合的地址尺度 seed 重编码。

## 7. 为什么结果仍是 UNKNOWN

全局 seed consistency 本身不蕴含第 6 节的 witness-lifting coverage。一个非字面关系可以整体证明许多原始义务，而不向每个义务暴露一个可从短 transcript 解码的原 seed。第 3.2 节已经给出很小的提醒：首 membership 真值可直接证明为真，但这个常真式没有保留 Pro 的 seed game 或 canonical-inverse 信息。

所以本轮不能从 (20) 宣称所有短 PH relations 不存在，不能把它称为 R2 的 reachable NOGO，也不能据此进入 R3。它仅精确否定了本轮唯一测试的逐 seed 重编码引理。

剩余的单一承重步骤是：对同一 \(G_n\)、同一 \(B\)、同一 \(G_N\) 的实际接口，给出一种整体关系，既不保留 (19) 那样的大量逐项可解码原 seed，又仍能证明所需的同一目标/全局一致性，并明确支付量词总位宽、无 oracle 矩阵及 gate-list、共同 descriptor、生成与一次实际复合成本。如果后续涉及 inversion，必须继续保留同一 \(K\)、同一 binary layout 和 \(\mathsf{All}_0\) 执行守卫。

原始来源没有提供这条整体消去引理；以上推导也没有建立或否定它。在本轮只允许一次压缩尝试的边界内，已无剩余的廉价区分性观测，因此停止为 **UNKNOWN**。没有作任何复杂度类分离声明。

## 8. 本地交付边界

完整数学推导保存在本文件；用户答复保存在同目录 `r2-final-answer.md`。原 `pro-full.txt` 保留不变。未编辑 tracked files，未创建永久研究 note，未运行重计算，未使用 OMEN 或其他远程访问，未 commit、push、同步或发布。来源核对日期为 2026-09-26，范围仅为冻结的本地 RW revision 1 及指定项目接口，没有在线版本或 novelty 判断。
