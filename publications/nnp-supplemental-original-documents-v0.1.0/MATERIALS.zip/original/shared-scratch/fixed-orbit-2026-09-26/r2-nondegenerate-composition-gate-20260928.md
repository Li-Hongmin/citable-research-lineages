# 冻结 R2：排除答案位退化后的真实复合必要接口

2026-09-28。保持同一 \(K\)、decoder、serialization、实际可达 guard 和原 SPEC；不增加高效发现 advice 的要求。

**裁决。** guard-only 的短非一致表示存在性已经无条件成立，不能继续记为 UNKNOWN。可以严格提取一个不再被“把这一位答案放进 advice”自动满足的必要接口：同一共同描述符读取实际失败分支的完整 count 缺额，或实际成功分支的两轮完整 count 超额。下面给出完整量词，并证明它与原三项实际 count 观察量在地址尺度的普通量词关系间相互归约。对同一源的重复零块及前缀像重叠作了一次直接化简，得到精确结构恒等式，但没有获得该接口的 \(m^{O(1)}\) 实现。**该接口的成立与否为 UNKNOWN；不是 R2 NOGO。**

本地依据是 [Pro 最后已完成回复](pro-guard-page-20260928.txt:10456)、[最新 aggregate-composition 推导](r2-aggregate-composition-independent-20260927.md)、冻结 SPEC、项目 AGENTS/README，以及 [RW 原文]([unmapped-local-locator]) Theorem 3.1、Lemma 3.2、Theorems 3.4–3.5、4.3。非一致描述符规则见 [paper 04 Proposition 1.3B](../../units/rw-jk-succinct-reconstruction/papers/04-from-address-scale-smart-reconstruction-to-p-poly/paper.md:408)。已按本会话读过的 Drive 权威 README 将 Pro 文本仅作候选输入；没有同步或远程访问。证据范围截止本日这些本地材料。下面不重证已核验的 guard 位恒等式和两轮聚合公式，也不借助 Pro 的同意。

## 1. guard-only 的存在性命题确实退化

令 \(A_q\in\{0,1\}\) 是同一实际首批全 YES 的真值。考虑字面非一致命题
\[
 \exists d\ge1\ \exists\mathsf V\ \forall q\in\mathcal A_C\ \exists\delta_q\in\{0,1\}^{\le m^d}
 \ \forall\beta\in\{0,1\}:\quad
 \mathsf V(q,\delta_q,\beta)
 \iff \beta=A_q.
 \tag{1}
\]
取 \(\delta_q=A_q\)、\(\mathsf V(q,g,\beta)=[g=\beta]\) 即证明 (1)。advice 长 1，量词位 0，普通矩阵及给定 advice 后的生成费用均为 \(O(1)\)。同一个 \(g\) 用于两种 \(\beta\)，不存在逐地址改 advice。

这也是与实际源绑定的存在性证明：\(A_q\) 在定义中指的就是该固定源的真值。它不提供 \(A_q\) 的具体值，不证明 \(A_q=1\)，也不提供从 \(q\) 发现这位 advice 的算法；原命题没有要求这些额外结果。

因此，Pro 末答提出的排除答案位 advice、再要求独立于预填答案的短源绑定证明，不能作为 (1) 的补充条件。若要求关系自行验证任意 advice 的正确性，或要求无答案 advice 的短证书／均匀算法，那是更强任务，不由现有非一致量词推出，本轮不采用。Pro 关于实际全 YES 尚未证明的结论可以保留；关于 (1) 尚未获得短关系的说法则必须收紧。

同样，固定有限个、乃至 \(m^{O(1)}\) 个指定判断位都可整表放进共同 advice，再用普通 mux 读取。仅把目标换成“某个 count 位”“两轮 count 是否相等”或“某个超额是否为零”，不会消除这种退化。

## 2. 非冗余的两轮 count 观察量

沿用同一源的
\[
 n=2^q,\quad N=n^C=2^m,\quad m=Cq,\quad T_0=2^{cn},\quad
 J_q=2^{\lambda_q},\quad
 h_q=\lceil\log_2(P_q|G_N|)\rceil.
 \tag{2}
\]
其中 \(P_q=|\Pi_q|\)，\(\lambda_q,h_q=\Theta(n)\)。以下省略下标 \(q\)。\(c_0\) 是始终实际发出的首批 membership YES 数。仅当 \(A=1\) 时，\(c_1,c_2\) 才表示原运行前两个 prefix batch 的 YES 数。保持原 dummy 位置，令 \(L=h\lceil N/h\rceil\)、\(\widehat G=G_N\circ\rho\)，其中 \(\rho\) 是原删除映射。

不再把可由一位 advice 表示的 guard 作为承重输出。定义分支内的整数
\[
 d_q=J-c_0\quad(A=0),\qquad
 e_{q,1}=c_1-J,\quad e_{q,2}=c_2-J\quad(A=1).
 \tag{3}
\]
在失败分支，\(1\le d_q\le J\)。在成功分支，每个块每轮至少有一个可延伸候选，故
\[
 0\le e_{q,r}\le J(2^h-1),\qquad r=1,2.
 \tag{4}
\]
这只减去原语义已经保证的基线，没有替换原 history 编码。恢复原 count 的办法在下一节给出。

用标签 \(t=0,1,2\) 表示 \(d,e_1,e_2\)。设
\[
 w_0=\lambda+1,\qquad w_1=w_2=\lambda+h+1,
\]
并令实际活跃域为
\[
 \mathcal D_q=
 \begin{cases}
  \{(0,a):0\le a<w_0\},&A_q=0,\\
  \{(r,a):r=1,2,\ 0\le a<w_r\},&A_q=1.
 \end{cases}
 \tag{5}
\]
\(V_q(t)\) 在该域上依次等于 \(d_q,e_{q,1},e_{q,2}\)。非活跃标签不表示一个 count 为零的真实轮次。

**必要接口 \(\mathcal G_{\mathrm{obs}}\)。** 存在一个固定的普通公式生成器 \(\mathsf{Gen}\)、固定指数 \(D\) 和 \(q_*\)，使
\[
\begin{gathered}
 \forall q\in\mathcal A_C, q\ge q_*\quad
 \exists\delta_q\in\{0,1\}^{\le m^D}\quad
 \forall t\in\{0,1,2\}\ \forall a\in\{0,1\}^{k_q}\ \forall\beta\in\{0,1\}:\\
 \Phi_{q,\delta_q}(t,a,\beta)
 \iff (t,a)\in\mathcal D_q\ \land\
       [\operatorname{bit}_a(V_q(t))=\beta],
 \qquad
 k_q=\lceil\log_2(\lambda+h+2)\rceil.
\end{gathered}
 \tag{6}
\]
这里 \(a=0\) 是最低有效位；(6) 右端按分段定义，域外为假，域内才取 \(V_q(t)\) 的位。\(\Phi\) 在非活跃／越界坐标对两个 \(\beta\) 都为假。同一个 \(\delta_q\) 服务全部活跃字段的全部位。它可包含 \(A_q\)、正确 \(\lambda,h\) 及原字段地址参数，均计入长度。

生成的关系必须实际写成
\[
 \Phi_{q,\delta}(t,a,\beta)
 =Q_1u_1\cdots Q_su_s\;
   M_{q,\delta}(t,a,\beta,u_1,\ldots,u_s),
 \tag{7}
\]
\(M\) 是固定有限基底上的普通有界 fan-in Boolean 电路。必须同时满足
\[
 \begin{aligned}
 |\delta_q|+|\text{显式输入布局}|&\le m^D,\\
 \sum_i|u_i|+s&\le m^D,\\
 |M|+|\text{显式门表、量词及控制描述}|&\le m^D,\\
 \operatorname{Time}(\mathsf{Gen}(q,\delta_q))&\le m^D.
 \end{aligned}
 \tag{8}
\]
不要求在此时间内找到 \(\delta_q\)。不加入计数门、oracle、未计价 ROM、长整数常量或隐式 gate-list。若候选还使用特定的交替深度界，该界也须逐项保留，不能以 (8) 代替；本轮不为 SPEC 新增一种更强的固定 PH 要求。

### 为什么这是必要且不被答案位 advice 自动满足的接口

原 Lemma 3.2 的 count prefix 包含 \(c_0\)，并在实际执行时包含 \(c_1,c_2\)。任何完成冻结 R2 的 exact count-orbit normal form 都必须同时给出这些实际字段的地址图。第 3 节证明它与 (6) 的归约只付多项式地址费用。因此 \(\mathcal G_{\mathrm{obs}}\) 是 R2 的必要投影；无需额外要求逐块随机访问、恢复整份 proof 或先构造完整 seed selector。

这里“最小”限于本轮的三项实际 count 观察量：已去掉可单独 advice 的 guard、成功分支已知的 \(c_0=J\)，以及每个 YES 块每轮必有一个候选的基线。它不宣称是所有数学接口中一个唯一最小者。它也不充分保证完整 R2：频数没有给出原标签上的后继状态，更没有证明所有后续 composition 都保持短表示。

活跃域大小在两个分支均为
\[
 |\mathcal D_q|=\Theta(n)=2^{\Theta(m)},
 \tag{9}
\]
而单个位地址只有 \(O(m)\) 位。整表预填答案要支付 \(\Theta(n)\) 位，超过任何固定 \(m^D\)；换成 \(\forall(t,a)\exists\delta_{q,t,a}\) 则会重新退化，但 (6) 明确禁止这个量词交换。

(9) 不是实际 count 的复杂度下界，也不是构造任意 count 家族的计数论证。实际长 word 仍可能有很短的公式，例如全零；若能对同一源证明那项结构，它应当被接受。这里排除的只是无需任何数学事实便逐位预填整个答案表的办法，不能以“答案相关”之名禁用原本允许的合法非一致描述符。

## 3. 与原 count 字段的地址归约：不展开长整数

这一节只处理 (3) 引入的算术，不重证原聚合语义。设 \(x_a\) 表示一个长整数的第 \(a\) 位，所有地址宽为 \(O(m)\)。

对 \(y=x+2^\lambda\)，在足够输出宽度内，
\[
 y_a=\begin{cases}
 x_a,&a<\lambda,\\
 x_a\oplus\displaystyle\bigwedge_{\lambda\le b<a}x_b,&a\ge\lambda.
 \end{cases}
 \tag{10}
\]
对合法的 \(y=x-2^\lambda\) 则将上式的 carry 改成
\(\bigwedge_{\lambda\le b<a}(1-x_b)\)。空区间的 AND 为 1。这正是向第 \(\lambda\) 位加一或减一的逐位进位／借位规则，因而互相实现 \(c_r\leftrightarrow e_r\)。

对 \(0\le x\le J=2^\lambda\)、\(y=J-x\)，有
\[
 y_a=x_a\oplus\bigvee_{0\le b<a}x_b\quad(a<\lambda),\qquad
 y_\lambda=\mathbf1[x=0].
 \tag{11}
\]
低 \(\lambda\) 位来自二进制补码：在第一个 1 及以下位保持原值，其上位取反；最高位仅在 \(x=0\) 时为 1。这同时实现 \(c_0\leftrightarrow d\)。原 MSB-first 字段的补前导零及位地址换算只增加 \(O(m)\) 控制。

关键是长区间 AND/OR 不被设成免费大门。例如，若 \(R_x(b,\eta)\) 是共同的 exact 位图，则
\[
 \bigwedge_{\lambda\le b<a}x_b
 \iff\forall b^{k_q}:
       [b\notin[\lambda,a)\ \lor\ R_x(b,1)].
 \tag{12}
\]
零性用 \(\forall b\le\lambda\;R_x(b,0)\)，前缀 OR 用对应的存在量词。比较器只处理 \(O(m)\)-bit 地址。展开有限次 \(R_x\)、它的量词对偶以及 Boolean 组合，得到普通 prenex 关系，始终使用同一 \(\delta_q\)。

具体地，若原关系的总量词位、矩阵门数、显式描述长、生成时间、量词块数分别为 \(P,S,D_0,T,s\)，则上述双向三字段变换可取一个绝对常数 \(c_*\)，满足
\[
 \begin{aligned}
 P'&\le c_*(P+m),&S'&\le c_*(S+m),\\
 D_0'&\le c_*D_0+O((P+S+m)\log(P+S+m+2)),\\
 T'&\le c_*T+O(D_0'+m),&s'&\le c_*(s+1).
 \end{aligned}
 \tag{13}
\]
原因是每个 (10)–(11) 的输出图只含常数次原图及至多常数个短地址量词；门表复制、重编号和区间控制按 (13) 支付。\(\lambda,h\) 等公共参数额外占 \(O(m)\) 位，advice 仍不依赖当前位地址。对固定模板仍为固定模板，对增长交替则保留 \(s'\) 的真实费用，本文不据此宣称满足任何额外 forcing window。

于是，给定同一 guard advice，(6) 与完整 \(c_0\)、带 guard 的 \(c_1,c_2\) 地址图在普通地址规模的关系之间等价。没有暗中要求发现 advice，也没有用 \(\Theta(n)\)-bit 的加法器冒充 \(m^{O(1)}\) 矩阵。

## 4. 对实际源的一次直接尝试：超额就是前缀重叠，重复零块可以合并

以下只在 \(A=1\) 时讨论真实 prefix 轮次。保留原 \(\widehat G\) 的 padded seed 坐标，令
\(R_p=\{\widehat G(u):p\preceq u\}\)，\(\mu(E)=\#\{j<J:X_j\in E\}\)。令 \(D_\alpha\) 为已核验的最小首 chunk 单元。由既有两轮公式可以进一步得到
\[
 e_1=\sum_{t\in\{0,1\}^h}
       \mu\left(R_t\cap\bigcup_{s<t}R_s\right),
 \tag{14}
\]
\[
 e_2=\sum_{\alpha,t\in\{0,1\}^h}
       \mu\left(D_\alpha\cap R_{\alpha t}
                         \cap\bigcup_{s<t}R_{\alpha s}\right).
 \tag{15}
\]
**证明。** 对一个实际块，若首轮有 \(k\ge1\) 个可行 chunk，恰有 \(k-1\) 个同时有更小的可行 chunk，故 (14) 对该块贡献 \(k-1\)。第二轮先固定该块唯一的实际首 chunk；在这个首 chunk 下应用同一事实，得到 (15)。对原标签求和即得，不用原像数量替代候选数量。\(\square\)

因此 (14)–(15) 的承重对象是原 decoder 的**不同可行前缀之间的重叠**，不是 guard 本身。可再得一个有用但不能独立充当非退化目标的特例：
\[
 e_1=e_2=0
 \iff
 \forall j<J\ \forall u,v\in\widehat G^{-1}(X_j):
        \pi_{2h}(u)=\pi_{2h}(v).
 \tag{16}
\]
正向，\(e_1=0\) 使每块只有一个首 chunk，\(e_2=0\) 又使其下只有一个次 chunk；反向立即成立。非负性排除了跨标签抵消。这里保留实际 dummy 坐标；若其中有自由 dummy 位，它也计入前缀。仅询问 (16) 的一个真假位仍可由一位 advice 承载，所以本轮接口仍是 (6) 的**全部超额位**。

现在利用真正的 source 特殊性，而不更换源。RW Theorem 4.3 的 \(f_0=B_q0^{T_0-2n}\) 与冻结的 raw-prefix 给出实际零块
\[
 X_j=0^{2N}\quad(1\le j<Q),\qquad Q=\lfloor T_0/(2N)\rfloor.
 \tag{17}
\]
这与[已核验的首批残余关系](r2-actual-residual-bulk-one-step-20260927.md:37)相同。充分大时 \(Q>1\)，这些块是首批真实查询，不是另造的 batch；常零真值表在同一 \(G_N\) 的 range 中。

令 \(z_0=Q-1\)。这些零块拥有同一个原像集合、同一个最小首 chunk，以及相同的两轮候选数。把该真实零块的两轮候选数减 1 后记为 \(\kappa_1,\kappa_2\)。则成功分支有
\[
 e_r=z_0\kappa_r+
      \sum_{j\notin\{1,\ldots,Q-1\}}
         (|S^*_{j,r}|-1),\qquad r=1,2.
 \tag{18}
\]
失败分支的缺额则精确为
\[
 d=\sum_{j\notin\{1,\ldots,Q-1\}}
       \mathbf1[\widehat G^{-1}(X_j)=\varnothing].
 \tag{19}
\]
这消去了重复零块作为独立未知项，但没有删除原查询或修改实际 count。\(\kappa_r\) 是实际零块关联的 generator 不变量；只有在 \(A=1\) 时才把它作为真实 prefix history 的贡献使用。

### 该尝试的费用与停止位置

\(\kappa_1\) 可写成对 \(t\in\{0,1\}^h\) 的 distinct-candidate 计数：存在 \(u,v\) 满足
\[
 \widehat G(u)=\widehat G(v)=0^{2N},\quad
 \pi_h(u)=t,\quad \pi_h(v)<t.
 \tag{20}
\]
同一 \(t\) 无论有多少对 witness 只计一次。\(\kappa_2\) 还须将两者限制到实际最小首 chunk 下。函数恒零给出了零块的某个原像存在性，没有给出 (20) 所定义的不同前缀数。

若直接沿上一份 aggregate-composition 的普通矩阵，对一个已知为零的实际标签作该计数，记 \(H=2^h\)、\(g=|G_N|\)，可用已证明的两轮图（然后减 1）得到保守的完全计价上界
\[
 P_\kappa=O(H(L+1)+h+L),\qquad
 S_\kappa=O(g+H(L+h+1)+L).
 \tag{21}
\]
原 \(\mathcal X_q\) 在此由已知零块替代；仍有候选答案、原像证书、最小首 chunk 证书、全称 NO 挑战和普通 mux／加法器。门表与输入／量词布局长为
\(D_\kappa=O((P_\kappa+S_\kappa)\log(P_\kappa+S_\kappa+2))\)。若 \(T_G(N)\) 与 \(T_\rho(q)\) 分别是同一 decoder 电路及原删除连线的生成时间，则给定实际参数后的公式生成付 \(T_G+T_\rho+O(D_\kappa)\)，不将短程序名当作已经生成了门表。没有为一个合成的单块 JK 运行主张可达性；这里只计算 (17) 中同一原标签的查询属性。

一般残余和仍可用既有同源矩阵表示，其费用为
\[
 P_{\rm res}=O(JL+JH(L+1)+\lambda+h+L),\qquad
 S_{\rm res}=S_X+O(g+JL+JH(L+\lambda+h+1)+L+\lambda+h).
 \tag{22}
\]
残余标签过滤、边界比较及 \(Q\) 的字面描述若使用，也计入 \(O(\lambda)\) 控制；不能把 \(Q\) 的 \(\Theta(n)\)-bit 字面值放进短 advice。令 \(D_{\rm res}\) 为 (22) 对应的显式门表／输入／量词布局长度，则公式生成另付同一块电路的 \(T_X(q)\)、\(T_G\)、\(T_\rho\) 及 \(O(D_{\rm res})\)。若还要从 \(q\) 生成实际参数，再付同一源的 \(T_{\rm par}(q)\)，不由参数表示短而豁免。

对 (18) 的字面乘法和相加，取宽度 \(w=O(\lambda+h)=\Theta(n)\)，普通实现另外支付 \(O(w^2)\) 门及其显式门表和生成费用；没有免费大整数运算。由固定程序的构造上界、\(H\le2P_qg\)、\(P_q\le T_0^{O(1)}\)，这里 \(T_X,T_G,T_\rho,T_{\rm par}\) 与全部直接展开费用均可付 \(T_0^{O(1)}\)，本轮没有实际生成这些大对象。

即使额外免费给予某种短 \(z_0\) 位表示，(21) 的前缀占用计数与 (22) 的实际残余部分也尚未压缩。因此本次尝试最先停在：**从同一 actual source 和原 decoder，给出 (14)–(15)、(19) 所定义的整数的共同地址位关系**。单独的 PCP 低次数、插值与 zero-on-subcube 恒等式没有把原 decoder 的 prefix-overlap 指示变成可聚合的短函数；本轮也没有证明这种转换不可能。

## 5. 最薄弱步骤与最终裁决

已证：guard-only 存在性退化；(6) 是原两轮 count 观察的非冗余必要接口；(10)–(13) 给出完整的地址算术双向归约；(14)–(20) 将超额定位为实际 prefix 重叠，并合并原串中已知重复零块的贡献。

最薄弱且未证明的步骤，是为这些**完整整数 word 的所有位**提供同一个 \(m^{O(1)}\) 描述符与普通关系，同时证明它们来自原 \(X_j\)、原最小前缀和实际 guard。一次只表示某个判断位不会补这一步；改成可高效发现 advice 或独立检查任意 advice，则是在增加要求，本轮没有这样做。

**停止：\(\mathcal G_{\mathrm{obs}}\) 为 UNKNOWN。** 没有压缩 (21)–(22)，没有固定轨道反例，也没有完整 R2 closure。即使将来 (6) 成立，仍需处理带标签的实际后继和所有后续复合。当前没有另一项更便宜、足以改变该判断的直接观测，故不再重写 guard 或聚合定义，不进入邻题，不修改 SPEC，不以字面展开费用作 NOGO。
