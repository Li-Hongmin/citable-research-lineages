裁决：**性质 L 仍为 UNKNOWN；现有冻结材料缺少具体序列化，不能判 R2 NOGO。**

- 逐变量次数保存与系数完整计价的窗口引理成立，但应用到实际 K 仍需证明其构造身份及真实 routing。
- ceiling 不破坏 \(h=\Theta(n)\)、\(Q=\Theta(n^6/q^3)\)。在其余计价前提下，更弱的 \(Q=\Omega(n^3/q^3)\) 已足够；原文未具体指定整数整形。
- 最早缺失数据是固定 K 的 **bit→oracle／点／分量／编码位**索引规则。若已有该程序，可廉价静态检查；当前材料无法继续区分。

未发现两条引理的具体数学错误。完整证明与来源边界已存入 [scratch findings](original/shared-scratch/fixed-orbit-2026-09-26/r2-algebraic-window-source-verdict-20260927.md)。已停止；SPEC 和永久笔记未修改。