# 冻结 R2：代数窗口引理的原始来源核验

2026-09-27。仅为 scratch findings；保留原 SPEC、同一 source、generator、constructor 参数及 raw-binary systematic-prefix 约定。

**裁决：条件性窗口引理成立；实际性质 L 为 UNKNOWN。当前指定的冻结材料没有给出足以判定 L 的具体 bit-to-oracle 序列化。** 没有发现 Pro 的逐变量次数保存、系数计价电路论证或所报参数渐近式的数学错误。需要收紧的是实例化范围：Harsha 展示的插值与逐次除法构造可以证明这些次数界，RW 对它的引用没有把一个完整二进制 constructor/index map 唯一写出来；本轮不能将展示的构造直接等同于题设参数化固定的实际 K。既未证明 L，也未证明其否定；没有实际剩余块的 NOGO，更没有完成 R2 的 count/下一步闭合。

## 1. 本轮证据范围

候选输入只读整页末尾的新回复，起于 [Pro 文本](pro-algebraic-window-page-20260927.txt:13017)，并从配套 HTML 核对其所引 Harsha thesis 地址。前面的 W 讨论不重做。

直接证据为：

- [RW 原文]([unmapped-local-locator])，ECCC TR26-118 revision 1，Theorems 3.4–3.5 及其证明，原文印刷页 11–13；参数和 truth-table generator 另见 1043–1056、1151–1166 行。对参数公式也读了同目录 PDF。
- [Harsha, Robust PCPs of Proximity and Shorter PCPs, 2004](../rw-actual-canonical-bind/harsha-thesis.pdf)，§5.3.2 印刷页 67–70 的逐次除法、§5.4.1 页 73–76 的插值和 constraint polynomial，以及 §5.4.3 页 80–81 的二进制转换。该原始 PDF 实际位于项目既有 scratch；没有将其误报成 ResearchLibrary 中的新全文。ResearchLibrary 中 `elibensasson2006robust` 是相关合著论文的书目项，`fulltext_status: no-open-fulltext`，本轮没有用书目项代替全文证据。
- 已读项目 AGENTS、根与单元 README、[冻结 SPEC](../../units/rw-jk-succinct-reconstruction/SPEC-2026-09-23-fixed-orbit.md)、[本轮指定的上一份 scratch](r2-actual-residual-bulk-one-step-20260927.md)，以及 Drive 工作区权威 README。上一份 scratch 用于恢复待判对象，不作为本轮代数结论的证明。

检索与核验截止本日的以上本地来源；没有网络、远程主机或重计算。没有考察任意不可达 batch，也没有另选 serializer。

## 2. 独立证明：展示的代数构造确实保存逐变量次数

以下先固定 Harsha §5.4.1 实际写出的**代数构造**，尚不声称它的每项实现选择已绑定到实际 K。记 PCP 维数为 ν、h=|H|≥2、r=3ν+3。插值所得赋值多项式 A 与约束索引多项式 Ĉ 的逐变量次数至多 h；标准 Lagrange 插值实际上可取小于 h，但不需要这个加强。

Harsha (5.7) 的多项式正是

\[
 P(z_1,z_2,z_3,y_1,y_2,y_3)
 =\widehat C(z_1,z_2,z_3,y_1,y_2,y_3)
   \prod_{i=1}^3(A(z_i)-y_i),
 \qquad z_i\in\mathbb F^\nu.
 \tag{1}
\]

任一 z_i 的坐标只出现在 Ĉ 与第 i 个乘因子中，故其次数至多 2h；任一 y_i 的次数至多 h+1≤2h。因此 P 的每个变量次数均至多 2h，而非将总次数 O(νh) 错当成逐变量次数。

这里合法赋值导致 P 在 H^r 上为零也能直接核对。Harsha 页 73 的 (5.6) 用的是补位：C′(i_1,i_2,i_3,b_1,b_2,b_3)=1 表示 **w_{i_k}=\bar b_k** 构成非法配置。对合法 Boolean 赋值，若 C′=1，则至少一个 A(i_k)=b_k，故 (1) 的相应因子为零；若某个 b_k 不属 {0,1}，则 C′=0。PDF 文本提取会漏掉这些补位横杠，本轮直接看了页 73–74 的原图；这里没有符号方向反例。

Harsha (5.1) 的逐次首一除法为

\[
 P_{i-1}=g_H(X_i)Q_i+P_i,
 \qquad g_H(X)=\prod_{\alpha\in H}(X-\alpha),
 \quad P_0=P.
 \tag{2}
\]

将 P_{i-1} 看成以其余变量的多项式环为系数环、关于 X_i 的多项式。g_H 首一且其系数为域常数，长除法只对原系数作域标量线性组合，不增加任何其他变量的次数；商的 X_i 次数至多原次数减 h，余式的 X_i 次数小于 h。归纳可得：

\[
 \deg_{X_k}P_i\le2h,\qquad
 \deg_{X_k}Q_i\le2h\quad(\text{所有 }i,k),
 \qquad \deg_{X_k}P_i<h\quad(k\le i).
 \tag{3}
\]

在 H^r 上 (2) 的除式均为零，所以 P_r|_{H^r}=P|_{H^r}=0。P_r 对每个变量的次数均小于 h，逐变量插值唯一性给出 P_r≡0。

这个证明对每个合法完整 witness 成立，既不读取 base outsider，也不需要计算任何系数。它适用于**确实执行 (1)–(2) 的 constructor**。仅说“某个确定性 poly(S)-time completeness constructor K”或“某份 proof 被接受”，没有指定 K 是否选择这些逐次余式，不能直接获得这项代码级身份。RW 的证明草图足以指明一种实现途径，不等于列出了冻结实际 K 的所有选择。

## 3. 独立证明：带完整系数费用的窗口电路

令 Z_j 为同一实际补零 PCP 串中的一个 2N-bit 块，m=log₂N。假设对这个实际块已经给出普通无 oracle 的 routing 电路：输入 a∈{0,1}^{m+1}，返回线号、该线的域参数、记录类型与所取 bit；其与原地址 2Nj+a 完全一致，门数为 T_j。假设至多涉及 K_j 条坐标线，每条至多 v 个分量，每个分量沿该线为次数至多 D 的单变量多项式。

令 Q=|𝔽|、ℓ=⌈log₂Q⌉；这里 Q 是域大小，**不是**上一份 scratch 中 raw-output 完整块的数量 Q_q。一次按实际域表示实现的乘加需 M_𝔽(ℓ) 门，实际记录编码需 E_j 门，最大记录宽度为 b。原表示和编码的实现成本保留，不能换一个有利的域编码后宣称完成本条件。

对每条线及每个分量，硬接其真实限制多项式的 D+1 个系数。共付

\[
 R_j=K_jv(D+1)\ell
 \tag{4}
\]

个系数位。用二叉 mux 选择当前线对应的整组系数，费用 O(R_j)；再用 v 份 Horner 电路求值，费用 vD M_𝔽(ℓ)；最后执行实际编码与 bit selection。由此有普通 bounded-fan-in Boolean 电路满足

\[
\begin{aligned}
 \operatorname{CC}(Z_j)\le S_j:={}&T_j+c_0(K_j+1)v(D+1)\ell
       +vD M_{\mathbb F}(\ell)+E_j\\
       &+O\bigl((b+m+\ell+\log(K_j+1))^2\bigr),
\end{aligned}
\tag{5}
\]

其中 c_0 为统一常数。通常 AND/OR/NOT fan-in-two 基底下，补齐到少于 2K_j 个 mux 叶并给常数、选择控制计费，Pro 的保守常数 12 可容纳该项；覆盖论证只用统一常数，不依赖 12。

这是真实线系数的非均匀电路存在性证明：系数可以很难求，但没有免费 ROM。给定系数及各部件的显式门表，组合门表的长度与生成费用为 O((S_j+m)log(S_j+m))。从 q 计算实际系数没有由此得到 poly(m) 算法；若运行同一源与 constructor，则已有保守费用仍为 poly(T₀)。

冻结的 truth-table generator 的覆盖性质（RW 1151–1166 行）给出

\[
 S_j<\frac{N}{10m}
 \quad\Longrightarrow\quad
 Z_j\in\operatorname{Range}(G_N).
 \tag{6}
\]

这里电路以 m+1 位输入输出一个 bit，其 truth table 才是完整 Z_j；没有把 2N 位显式输出的门数混进 CC 的定义。若需要把门表写成 generator 的 N-bit seed，O(S_jlog(S_j+m)) 的编码费用也满足覆盖预算；渐近小 o 留出了固定编码常数余量。

因此这些假设确实能消去一个 membership 的存在见证。它不提供系数、原像或 lex-first seed 的地址尺度计算，更不自动提供共同的实际窗口分类。

## 4. 参数与取整：两项 Θ 声明没有因 ceiling 失效

保持实际基点 n=2^q、N=n^C、m=Cq，其中 C≥3 固定且 q 限于冻结 SPEC 的 admissible 起点。设完整 witness/circuit 规模 S 满足 T₀≤S≤T₀^A、T₀=2^{cn}，A,c 为固定常数，故

\[
 u=\log_2S=\Theta(n),\qquad
 v_0=\log_2u=q+O(1).
\]

RW 734–742 行明写 ν=⌈u/v₀⌉，并在 778–781 行的实际后续参数中采用 Q=Θ((νS^{1/ν})³)。不能仅从 ν=Θ(n/q) 向指数内代入 Θ；以下直接保留 ceiling：

\[
 \nu=\frac{u}{v_0}+\theta,\quad0\le\theta<1,
 \qquad
 \frac{u}{\nu}
 =v_0-\frac{\theta v_0^2}{u+\theta v_0}.
\]

令 h₀=S^{1/ν}，则

\[
 u\,2^{-v_0^2/u}\le h_0\le u,
 \qquad h_0/u\longrightarrow1.
 \tag{7}
\]

在原文假设 h₀ 为整数的参数上，h=h₀，因此

\[
 \nu=\Theta(n/q),\quad h=\Theta(n),\quad
 Q=\Theta(n^6/q^3),\quad \ell=\Theta(q).
 \tag{8}
\]

**取整的证据边界。** RW 在 741–742 行说“assume, without loss of generality, that n^{1/m} is an integer”，没有指定对一般 S 的精确 grid padding 算法。因而 Pro 的“保持原构造的取整”不能解释成已经核对了实际整数布局。若某个已固定实现采用 h=⌈h₀⌉、保持 ν 并将网格补至 S′=h^ν，则数学上

\[
 0\le\log_2(S'/S)
 \le\nu\log_2(1+1/h_0)=O(1/q),
\]

所以这项常规整形不改变 (8)。这是取整稳定性的条件核算，**本轮没有替实际 K 采用这套 padding**。其他实际整形须回到其代码核对。域大小在后续段已明定 Θ，故任何满足该承诺的 prime-power 选择都给 (8)；不能仅从前文“at least”推出 Θ 上界。

事实上覆盖只需更弱的已计价界。由 (3) 可取 D=O(n)，Harsha 的 bundle 有至多 2r=6ν+6 个分量，故 v=O(n/q)，并有 v(D+1)ℓ=O(n²)。若原 routing/域运算/编码确实使 (5) 满足统一的

\[
 K_j=O(1+N/Q),\qquad
 S_j\le A_0(K_j+1)n^2q^a,
 \tag{9}
\]

其中 A₀,a 与 q,j 无关，则 (8) 给出

\[
 \frac{S_j}{N/m}
 =O\!\left(\frac{q^{a+1}}{n^{C-2}}
          +\frac{q^{a+4}}{n^4}\right)=o(1).
 \tag{10}
\]

即使不用 h=Ω(n) 和 Q 的精确 Θ，只保留 ν=Θ(n/q)、2≤h=O(n)、Q≥α(νh)³、ℓ=O(q) 以及 (9)，较弱的

\[
 Q=\Omega(n^3/q^3)
\]

也已足够：此时 (10) 第二项可放宽为 O(q^{a+4}/n)，仍趋零。一般需要的只是 Q/(n²q^{a+1})→∞。这说明精确 n⁶/q³ 不是承重缺口，实际 routing 和源绑定才是。

## 5. 最弱接口：原文给了函数 oracle，没有给出所需的实际比特窗口

RW 的直接信息与 L 所需信息之间有以下界限：

- RW 742 行：“Fix a bijection between [n] and H^m”。这里规定存在并固定一个双射，没有写出该双射的公式；Harsha 页 73 同样仅说将 [n] 与 H^m 识别。
- RW 762–769 行命名 Ã、P、Π_ZoS 三个函数 oracle 并指向 Harsha 的 completeness 构造。Harsha 页 70 给出**同一点处**的 tuple 顺序 `(P₁(x),…,P_r(x),Q₁(x),…,Q_r(x))`。这指定了点内 bundle 的语义，没有规定跨点的全局 bitstring 顺序。
- RW 791–794 行规定 systematic prefix；题设继续保留 raw-binary-prefix 约定。这个前缀条件不决定其后的域元素排列、剩余位抽取、auxiliary-oracle 的精确串联边界或原编码的 bit 位序。
- Harsha §5.4.3 给出用显式 ECC 添加 oracle Υ(x)=ECC(Γ(x)) 的二进制 robust 化途径。RW 这里直接使用的是 §5.4.1 的三个 oracle；不能擅自断言实际 K 采用了 §5.4.3，也不能将该节当成已指定全局序列化。即使采用它，点序及 systematic-prefix 的实现仍须给出。

因而，本次最早缺少的可观测数据是**题设实际 K 的完整索引规则**，即能够将实际 bit 地址映射为原始数据位、padding，或某个 oracle 的点/分量/编码位的映射

\[
 \sigma_q(s)
 =\bigl(\text{record/oracle tag},\ x\in\mathbb F^{d},\
        \text{component},\ \text{encoded-bit position}\bigr),
 \tag{11}
\]

并明确实际整数长度、prefix extraction 与编码。RW 原文最早暴露这些未给定选择的位置是 741–742 行的整数化假设与双射；(11) 还必须与同一个实际 constructor 的代数输出绑定。SPEC 中“fix the published serialization”及上一份 scratch 对固定 K 的参数化使用，没有增补 (11)。

L 需要检查的是 s=2Nj+a 的真实映射。若某个**已有映射**的一个取值段确实由连续坐标线组成，每线至少保留 Q−h 个点、每点 b 位，则一个完全处于该段中的 2N-bit 窗口至多接触

\[
 2+\left\lceil\frac{2N}{(Q-h)b}\right\rceil
 =O(1+N/Q)
 \tag{12}
\]

条线：至多两条端点不完整的线，其余完整线各占至少 (Q−h)b 位。这个计数正确。可是源文件没有说实际 systematic 抽取后的剩余点按这种顺序连续排放，也没有给出跨 oracle/编码边界的实际 routing。Verifier 沿随机线查询函数，不能推出 JK 连续 bit 窗口沿坐标线排列。

本轮因此不能从原文定义出一个已认证的实际 J_alg(q)，也不能标出“第一个实际不满足 L 的窗口”。这不是说所有这些窗口都坏，也不是对任何窗口给了电路下界。用另选字典序、域基或有利 prefix extraction 补出 (11)，会更换本轮待判对象。

## 6. 精确条件性结论与停止点

以下是本轮证明的完整范围：**对同一个实际 K、同一个 G_N 和同一个未重排的 PCP 串，若能证明所指定窗口确实满足第 2 节代数输出身份与第 3 节真实 routing/编码前提，并以跨 q,j 统一常数满足 (9)，则存在 q_*，对所有 admissible q≥q_* 及这些窗口 j，均有 Z_j∈Range(G_N)。** 电路的系数和门表费用已经计入；无需高效找到系数或原像。原 Pro 的 L 若包含这些完整前提，其推出 YES 的部分成立。

对已认证窗口的承诺域，答案关系可化为 `β=1`。要成为全域的地址尺度关系，仍须付费识别该域、表示其数量和处理未覆盖块。raw gate-value 区只有 H-网格的 h 个点/线，不能自动套用 (Q−h) 的扩张；边界窗口也不能自动归入该域。即使将来首批全为 YES，原 JK 的实际 lex-first inverse 与 prefix-count 仍未由本引理确定。这里没有把电路存在性当成 canonical seed 或一次复合闭合。

**错误/缺口的区分。** 未发现所检查代数论证、mux/Horner 主界或 ceiling 渐近式的具体数学错误。必须纠正的是“展示的代数步骤已核验”到“实际固定 K 的那些输出已核验”的来源跳跃，以及将原文省略的整数化/索引选择视为已经具体冻结。它们留下的是未知的实例化条件，不是 L 为假或 R2 NOGO 的证明。

**便宜的下一观测。** 如果已有实际 K 的源码或等价的 (11) 索引公式，只需静态检查 `a↦σ_q(2Nj+a)` 的线段数、域表示与边界 routing，便可能判定 L；不需要生成 B₀、gate-value 表或整张 PCP。当前指定冻结文件及所引原始构造没有提供这一数据，继续从相同抽象定理无法区分。新增一个方便的实现属于重新实例化，不是观察原对象。本轮到此停止：L UNKNOWN，R2 未获 GO/NOGO；不切 R3、不修改永久 notes/SPEC、不提交或同步。
