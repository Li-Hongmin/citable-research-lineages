# R2：短 SAT 语义表的独立源绑定判定

2026-09-26。冻结 RW fixed-orbit R2；本文件只留在 scratch。

**裁决：精确 UNKNOWN。** W 是一个以原始 \(BF_0\) 输出为目标的、尚未证明的短表覆盖命题。它的定义不循环；若证明 W，则从同一覆盖表投影出正确共同 advice 和短 exact 源图，是有效的非一致推论。可是，先取任意合法短表，再把它自己的输出用作源图，并不能证明该表输出的是 \(BF_0\) 的 lex-first outsider。这个自绑定公式删除了源条件。当前既没有 W 的证明，也没有同一实际求值机器的覆盖反例，因此不能判 R2 NOGO。

这里有两个不同的未决事项：W 的数学覆盖内容，与未逐位冻结的 decoder/求值程序。后者不能充当否定前者的证据。尤其，原文通常电路描述约定下的渐近 generator coverage，足以推出充分大实际基点的首块 membership；没有取得逐位编码证书，不撤销这个数学层面的结论。

## 1. 对象与原文边界

本次判断只使用 [冻结 SPEC](../../units/rw-jk-succinct-reconstruction/SPEC-2026-09-23-fixed-orbit.md)、[已有表审查](r2-sat-semantic-table-audit.md)、[decoder caveat](pro-decoder-caveat.txt)，以及 [Ren–Williams 原文，本地全文]([unmapped-local-locator])。已有审查和 Pro 文本是待核验输入。原始证据限于本地保存的 ECCC TR26-118 revision 1；核对日期为 2026-09-26，未检索远程版本。

原文 Theorem 4.3（全文 1040–1090 行）直接给出：\(BF_0\) 枚举同一 \(G_n\) 的 range，输出其 lex-first outsider，且 \(r_0=s_0=0\)。encoded-history 段和 Theorems 3.4–3.5（732–850 行）给出完整 witness 和 systematic prefix。Theorem 3.1（498–548 行）先发出实际块的 membership 查询，任一 NO 才退出。truth-table generator 的定义及 Theorem 4.5 的证明在 1151–1166 行。

固定原来的常数 \(C\ge3,c\ge1\)，并令
\[
 n=2^q,\qquad N=n^C=2^m,\qquad m=Cq,\qquad T_0=2^{cn}.
\]
\(q\) 遍历 published construction 的实际起点集合
\(\mathcal A_C=\{q\in\mathbb N:C\nmid q\}\)，以下允许增大统一的起点阈值。输出地址有 \(m+1\) 位；caveat 中的 \(m\) 是这里的 \(m+1\)，并非新的尺度。

对每个这样的 \(q\)，定义
\[
 B_q=\min_{\rm lex}\bigl(\{0,1\}^{2n}\setminus\operatorname{Range}(G_n)\bigr).
 \tag{1}
\]
这是独立于短表代码的源定义。沿用题设的同一 raw-binary-history-prefix 序列化，不另选 field encoding 或 PCP constructor。对充分大的 \(q\)，有 \(cn\ge Cq+1\)，所以 \(T_0\ge2N\)，从而实际第一块为
\[
 Z_q=B_q0^{2N-2n}.
 \tag{2}
\]
不能只凭 \(T_0\ge N\) 得到 (2)。完整 witness 的中间门值没有被忽略；在所冻结的前缀约定下，它们不插入 (2) 的输出区间。原文的抽象 systematic 性质也没有唯一规定所有后续二进制坐标。

**渐近覆盖与逐位 decoder。** 将论文通常电路描述约定下使用的覆盖性质写清楚，是
\[
 \exists\kappa>0\ \exists k_0\ \forall k\ge k_0\ \forall D:
 \quad
 \begin{cases}
 D:\{0,1\}^{k+1}\to\{0,1\},\\
 |D|\le\kappa 2^k/k
 \end{cases}
 \Longrightarrow
 \exists u\in\{0,1\}^{2^k}\quad
 G_{2^k}(u)=\operatorname{TT}(D).
 \tag{3}
\]
Theorem 4.5 使用 \(0.1\cdot2^k/k\) 的门数阈值；(3) 是这一标准 truth-table-generator 论证的覆盖内容，常数随其固定门模型解释。Theorem 4.3 对一般 P-uniform AVOID 家族的陈述本身不提供 (3)。这里使用的是原文随后指定的 truth-table-generator 特例。

任意固定 \(B_q\) 的 \(2n\) 位均可硬接进二叉 mux tree，再检查高地址位为零。因此存在
\[
 |D_{B_q}|\le K_1n+K_2(m+1)
 <\kappa N/m
 \tag{4}
\]
的电路计算 (2)，其中常数对 \(q\) 统一。它的普通门表描述长为 \(O((n+m)\log(n+m))\)，包含选择叶子常量所需的全部 \(B_q\) 信息；不是 \(\operatorname{poly}(m)\) 的已知源描述。由 (3)–(4)，
\[
 \exists q_0\ \forall q\in\mathcal A_C,\ q\ge q_0:
 \quad I(q):=[Z_q\in\operatorname{Range}(G_N)]=1.
 \tag{5}
\]
这是 published 语义层面的存在结论。它没有构造 seed，更没有构造短 SAT 表；只知道这一次查询是 YES，也不意味着全批 YES 或 canonical inversion 已实际执行。

原文没有列出门类型字节、padding、无效 seed 语义以及唯一的 uniform-constructor 机器码，所以本次没有验证某个具体字节串满足
\(\operatorname{Decode}_N(\operatorname{pad}_N(\operatorname{Enc}(D_{B_q})))=D_{B_q}\)。这是 bitwise 实例未交付的边界，不是 (3) 或 (5) 的反例。下文保持已有审查的同一求值机器 \(\mathcal M\)、clock、表域与符号解码为固定参数；不把另一种有利 decoder 换进来。关于它们的结论是参数化定理，不冒充已经冻结了原文没有逐位指定的实现。

## 2. W 的完整量词与可证明的源投影

固定 \(\mathcal M\) 后，令其求值时间上界为 \(N^\alpha\)，其中 \(\alpha\) 是固定常数，包含同一 \(G_N\) 的 uniform construction、求值和无效编码处理。使用已有的普通时间—空间表。表位地址宽度与局部检查编号宽度分别为
\[
 h=2\alpha m+O(1),\qquad \ell=2\alpha m+O(1).
\]
令 \(\mathcal D_m\) 为有效表地址域，\(c_E\) 为一次完整局部检查访问的表位数。最终输出位由原有的 \(c_o=O(1)\) 个表位经固定布尔函数 \(D_{\rm out}\) 解码；其地址 \(o_j(a)\) 和解码电路总共用 \(O(m^2)\) 门。所有这些选择均在 \(q\) 变化前固定。

对固定整数 \(d\ge1\)，取 \(s=r=m^d\)。代码 \(\sigma\) 描述一个至多 \(s\) 门的普通 fan-in-two 电路 \(F_\sigma(z,w)\)，其中 \(|z|=h,|w|=r\)。沿用已有门表格式：
\[
 \lambda=\lceil\log_2(h+r+s+2)\rceil,\qquad
 L=s(3+2\lambda)+\lambda,
 \qquad
 \tau_\sigma(z)=1\iff\exists w\in\{0,1\}^{r}\ F_\sigma(z,w)=1.
 \tag{6}
\]
\({\sf Code}(\sigma)\) 检查合法门类型、拓扑编号和输出编号。普通 universal evaluator \(U\) 可满足
\[
 |U|+|{\sf Code}|\le A s(h+r+s),
 \tag{7}
\]
其中 \(A\) 固定；没有 SAT gate 或免费 wiring oracle。

原覆盖命题是
\[
\begin{split}
 W:\quad \exists d\ge1\ \exists q_\star\
 \forall q\in\mathcal A_C,\ q\ge q_\star:\qquad&\\
 [\exists u\in\{0,1\}^{N}\ G_N(u)=Z_q]
 \Longrightarrow
 \exists u\in\{0,1\}^{N}\ \exists\sigma\in\{0,1\}^{L}:\quad&\\
 {\sf Code}(\sigma)\ \land\ G_N(u)=Z_q\ \land\
 \forall z\in\mathcal D_m:\quad
 \bigl[\operatorname{Tab}_{\mathcal M}(N,u)[z]=1
 \iff \exists w\in\{0,1\}^{r}\ F_\sigma(z,w)=1\bigr].&
\end{split}
 \tag{8}
\]
由 (5)，可统一增大 \(q_\star\)，将前件删除。不能因此删除结论里的 \(G_N(u)=Z_q\)。式 (8) 中的长 \(u\) 属于覆盖定理的数学陈述；把它原样放进候选短公式，就必须支付 \(N\) 个量词位。该输出等式也不是免费的源 oracle：直接提交 \(Z_q\) 是 \(2N\) 位，即使利用已知零尾也须提交 \(2n\) 位 \(B_q\)；从原 \(BF_0\) 计算这些位，已知时间界为 \(T_0=2^{cn}\)。下文 (20) 给出不提交这个 payload 的 exact 源关系，但仍支付 object-scale 量词和矩阵。

**命题。** 若 (8) 成立，则存在共同 advice \(\delta_q=\sigma_q\)，使下述同一两块量词模板给出 exact 源图：
\[
\begin{split}
 H^{\rm out}_{\delta_q}(a,b):=
 \exists(\boldsymbol\beta\in\{0,1\}^{c_o},
          \mathbf x\in(\{0,1\}^{r})^{c_o})\
 \forall\mathbf y\in(\{0,1\}^{r})^{c_o}:\qquad&\\
 [D_{\rm out}(\boldsymbol\beta)=b]\ \land
 \bigwedge_{j=1}^{c_o}
 \bigl[(\neg\beta_j\vee U(\delta_q,o_j(a),x_j))
 \land(\beta_j\vee\neg U(\delta_q,o_j(a),y_j))\bigr].&
\end{split}
 \tag{9}
\]
完整的正确性量词为
\[
 \exists d,q_\star\ \forall q\in\mathcal A_C,\ q\ge q_\star\
 \exists\delta_q\in\{0,1\}^{L}\
 \forall a\in\{0,1\}^{m+1}\ \forall b\in\{0,1\}:\quad
 H^{\rm out}_{\delta_q}(a,b)\iff Z_q[a]=b.
 \tag{10}
\]
该命题中的 \(\delta_q\) 还满足 (8) 的覆盖条件；它在所有地址之前选定。

证明：若 \(\beta_j=1\)，存在的 \(x_j\) 迫使 \(\tau_{\delta_q}(o_j(a))=1\)；若 \(\beta_j=0\)，全称 \(y_j\) 迫使该 SAT 真值为零。因此所有成功策略均取相同的真实表位。由 (8) 的输出条件，原有解码恰好给出 \(Z_q[a]\)。反向取真实表位，并为每个 1 位选接受见证即可。不存在逐地址重新选择 advice，也没有把一般符号解码误当作单个 NP 正位投影。证毕。

这里的依赖是 \(W\Rightarrow(10)\)，方向有效且不循环。\(B_q\) 已先由 (1) 定义，(8) 是关于它的受限表示定理。W 若得到证明，正确共同 advice 的非一致存在就已经获得源依据；**无须再把高效寻找 advice 或独立短认证当成这项非一致推论的必要条件**。若另要求从公开参数统一输出 advice，则那个生成算法及其成本是额外义务。本次没有提供它。

但现在 (8) 尚未证明。以“存在正确的 \(\delta_q\)”直接启动短源图，承担的正是 W 中尚未建立的源覆盖内容。普通 \(\operatorname{poly}(N)\)-time 求值或 (3) 的短电路编码都没有在现有推导中提供 \(\operatorname{poly}(m)\)-gate 的 SAT 表覆盖。仅有短输出图也不反推整张求值表的 W。

## 3. 自绑定公式到底表示什么

对固定 \(q,s\)，定义 \({\sf Valid}_{q,s}(\sigma)\) 为：\({\sf Code}(\sigma)\) 成立，且 \(\tau_\sigma\) 是同一 \(\mathcal M(N,u)\) 对某个 seed 的合法完整表。该性质可由
\[
 \forall\xi^{\ell}\
 \exists(\boldsymbol\beta^{c_E},\mathbf x^{c_Er})\
 \forall\mathbf y^{c_Er}:\quad
 {\sf Code}(\sigma)\land {\sf Local}(\xi,\boldsymbol\beta)
 \land {\sf Truth}_\sigma(\xi,\boldsymbol\beta,\mathbf x,\mathbf y)
 \tag{11}
\]
表达，其中 \({\sf Truth}\) 是 (9) 的同种双向 SAT 真值绑定。\({\sf Local}\) 包含有效域、完整初始行、唯一头和状态、seed 格式、边界、确定性转移与最终输出规则。固定的 \(\tau_\sigma\) 使所有局部读取一致；从初始行归纳可得同一个真实 seed 和其唯一运行。这一论证不使用 \(B_q\)。

记合法表的输出为 \(O_\sigma\)，并令
\[
 \mathcal O_{q,s}
 =\{O_\sigma:{\sf Valid}_{q,s}(\sigma)\}
 \subseteq\operatorname{Range}(G_N).
 \tag{12}
\]
在 (5) 的充分大范围，W 精确要求某个固定 \(d\) 对所有实际 \(q\) 满足
\[
 Z_q\in\mathcal O_{q,m^d}.
 \tag{13}
\]
这是源条件，不是 \({\sf Valid}\) 的一部分。

若选一个全局代码 \(\sigma\)，再把 membership 检查的源定义为该代码自己的输出，则
\[
 \exists\sigma\bigl[
 {\sf Valid}_{q,s}(\sigma)\land
 \forall a\ H^{\rm out}_\sigma(a,O_\sigma[a])
 \bigr]
 \quad\iff\quad
 \mathcal O_{q,s}\ne\varnothing.
 \tag{14}
\]
原因是 (9) 对任何合法代码都精确描述其自身输出。等式 (14) 即使使用一个全局代码也成立；问题并非局部见证不能拼接，而是源条件已经消失。

若更进一步定义无 advice 的候选位关系
\[
 H^{\rm free}(a,b):=
 \exists\sigma\,[{\sf Valid}_{q,s}(\sigma)
                 \land H^{\rm out}_\sigma(a,b)],
 \tag{15}
\]
则它的准确语义是
\[
 H^{\rm free}(a,b)\iff
 \exists Y\in\mathcal O_{q,s}\quad Y[a]=b.
 \tag{16}
\]
所以，对每个固定 \(q,s\)，
\[
 [\forall a\ \forall b:\ H^{\rm free}(a,b)\iff Z_q[a]=b]
 \quad\iff\quad
 \mathcal O_{q,s}=\{Z_q\}.
 \tag{17}
\]
右推左直接。左推右时，exact 图的完备性使输出集合非空；任意其中的 \(Y\) 若在某地址异于 \(Z_q\)，就使错误 bit 在 (16) 中被接受，故全部 \(Y\) 必须等于 \(Z_q\)。

W 只要求 (13)，没有提供 (17) 的单元素条件。这里没有声称已发现另一个实际的短覆盖表，也没有用另造的生成器或假想输出当反例。已证明的是 (14)–(17) 对同一实际参数的精确语义：自绑定没有证明所需的源识别。若用“它已输出 \(B_q\)”为这一缺失步骤辩护，就重复使用了待证结论。

## 4. 非循环入口与一次 membership 复合的账目

原始源已有不查询首个 JK block 的 exact 关系；其当前直接表示仍是 object scale。为使这一点可核对，令 \(e=(\varepsilon,u)\in\{0,1\}^{n+1}\)，定义
\[
 V_n(e)=\begin{cases}1&\varepsilon=0,\\
 [G_n(u)\ne1^{2n}]&\varepsilon=1,
 \end{cases}
 \qquad
 c_n(e)=\begin{cases}0^{2n}&\varepsilon=0,\\
 G_n(u)+1&\varepsilon=1.
 \end{cases}
\]
无效输入上任意总化 \(c_n\)；\(+1\) 是整词二进制加一。设
\[
 M_n(y;v,e,t)=
 [G_n(v)\ne y]\land
 [\neg V_n(e)\vee c_n(e)\ge y\vee G_n(t)=c_n(e)].
 \tag{18}
\]
则
\[
 \forall v^n,e^{n+1}\ \exists t^n\ M_n(y;v,e,t)
 \iff y=B_q.
 \tag{19}
\]
证明：左侧首先使 \(y\) 成为 outsider。如果 \(y>B_q\)，则 \(B_q=0\) 或其前驱 \(B_q-1\) 在同一 \(G_n\) 的 range 中；两种情形均有有效 \(e_*\) 使 \(c_n(e_*)=B_q\)。第二项遂要求一个 \(B_q\) 的原像，矛盾。反向在 \(y=B_q\) 时，全部更小的有效候选均在 range 中，故有相应 \(t\)。

令 \(d(e,a)=c_n(e)[a]\) 当 \(a<2n\)，其余为零。于是
\[
 H_0(a,b):=
 \exists e_0^{n+1}\ \forall(v^n,e^{n+1})\ \exists t^n:
 V_n(e_0)\land[d(e_0,a)=b]\land M_n(c_n(e_0);v,e,t)
 \tag{20}
\]
精确等价于 \(Z_q[a]=b\)。它使用三个量词块、\(P_0=4n+2\) 个量词位，普通矩阵大小
\[
 S_0\le4g_n+O(n+m),\qquad g_n=|G_n|\le n^4.
 \tag{21}
\]
所有比较、加一和 bit mux 均已包含；还需支付实际 \(G_n\) 电路及整个矩阵的 gate-list。式 (20) 是源绑定的可核对基准，并未把这些指数于 \(m\) 的位改叫短描述。

给定任意已经 exact 的入口
\(H_\delta=Q_1v_1\cdots Q_kv_kR_H\)，令 \(P_H\) 为其总量词宽度，\(S_H\) 为普通矩阵门数。在 (11) 的最终输出检查中插入 \(H_\delta(a,b_\star)\)，得到同一 membership 编译：
\[
 \exists\sigma^L\ \forall\xi^\ell\
 \exists(\boldsymbol\beta^{c_E},b_\star,\mathbf x^{c_Er})\
 \forall\mathbf y^{c_Er}\ Q_1v_1\cdots Q_kv_k:
 R_{\rm comp}.
 \tag{22}
\]
\(R_{\rm comp}\) 包含普通 Code、Local、Truth 和 output-guarded \(R_H\)。源量词放在最后是合法的：对外层变量固定后，\(R_H\) 不含 \(\mathbf y\)，Local/Truth 不含 \(\mathbf v\)，而各量词域非空。因而 dummy 依赖不改变真假。

准确语义与全部主要成本是
\[
\begin{gathered}
 (22)\iff Z_q\in\mathcal O_{q,s},\\
 P_{\rm comp}=L+\ell+c_E+1+2c_Er+P_H,\qquad
 k_{\rm comp}\le k+4,\\
 S_{\rm comp}\le2c_EA s(h+r+s)+S_H+K m^2.
 \tag{23}
\end{gathered}
\]
这一次实际查询的编译器是 sound 的；其 eventual completeness 正是 W。合法表提取的长 seed 没有免费作为公式变量出现。均匀生成 (22) 的模板只需输出规模的固定多项式时间；该生成步骤没有证明覆盖。

采用 (20) 时，\(P_H=4n+2\)，至多七块量词，故仍为 object scale。采用由 W 保证正确的 (9) 时，另付共同 advice \(|\delta_q|=L\)，并有
\[
 P_H=c_o+2c_or,\qquad k=2,\qquad
 S_H\le2c_oA s(h+r+s)+O(m^2).
 \tag{24}
\]
此时 (22) 至多六块量词，
\[
\begin{split}
 P_{\rm comp}&=L+\ell+c_E+1+2c_Er+c_o+2c_or,\\
 S_{\rm comp}&\le2(c_E+c_o)A s(h+r+s)+O(m^2).
 \tag{25}
\end{split}
\]
共同源代码 \(\delta_q\) 与 (22) 中的量化代码 \(\sigma\) 是两个角色；后者可用同一正确代码作见证，但不能借此免除前者的正确性前提。

**完整显式编码与求值。** 对任一上述公式，设 \(P\) 为全部量词位数，\(S\) 为普通矩阵大小，\(D\) 为共同 advice 长度。除固定机器描述与 \(O(\log m)\) 位公开参数外，可用
\[
 O\bigl((S+P+D+m+1)\log(S+P+D+m+2)\bigr)
 \tag{26}
\]
位显式交付 gate-list、变量布局和 advice。固定 \(s=r=m^d\) 时，(24)–(26) 给出
\(L=O(m^d\log m)\)、\(P=O(m^d\log m)\)、\(S=O(m^{2d})\)，全部编码为 \(m^{O(1)}\)。常数和次数均跨实际 \(q\) 统一；只给一段生成矩阵的短程序不能代替 (26)。

这些是关系的表示成本，不能称为普通确定性求值也只花 \(m^{O(1)}\) 时间。给定正确 advice，可直接枚举每个输出槽的 \(r\)-bit SAT witness，精确求值 (9)，保守时间界为
\[
 O\bigl(L+m^2+c_o2^r A s(h+r+s)\bigr).
 \tag{27}
\]
一般显式 QBF 可按量词树枚举，时间 \(2^{O(P)}(S+D+m+1)\)、工作空间为这些显式规模的多项式。这里既没有调用免费 SAT/PH oracle，也没有证明更小的确定性求值成本。寻找正确 \(\delta_q\) 的时间也未由 W 提供；若要求该项统一生成成本，须另行计价。这些有限上界仅用于账目，本次没有运行枚举。

## 5. 精确停止边界

在 published 渐近语义和已有固定参数下，未决命题就是
\[
 \exists d\ge1\ \exists q_\star\ \forall q\in\mathcal A_C,\ q\ge q_\star:
 \quad Z_q\in\mathcal O_{q,m^d}.
 \tag{28}
\]
要真正否定这项 eventual coverage，需要证明其量词否定
\[
 \forall d\ge1\ \forall q_\star\ \exists q\in\mathcal A_C,\ q\ge q_\star:
 \quad Z_q\notin\mathcal O_{q,m^d},
 \tag{29}
\]
或者针对另一个已经固定预算的机械 gate 提供相应实际失败实例。一次小参数搜索失败、另一个 decoder、任意目标串，均不建立 (29)。本次没有这样的实际反例。

已有普通电路硬度也不直接否定 W。由 (3)，\({\rm CC}(B_q)>\kappa n/q\)。若覆盖代码的输出锥实际读取 \(r_{\rm eff}\) 个 witness 位，将其穷举、OR 后解码，只得到必要条件
\[
 O(m^2)+c_o2^{r_{\rm eff}}(s+1)>\kappa n/q,
 \qquad
 r_{\rm eff}+\log_2(s+1)\ge q-\log_2q-O(1).
 \tag{30}
\]
这与 \(s=r=m^d\) 相容。已有完整矩形 \(BF_0\) 表的时间零头位置下界则针对 \(\Theta(n)\)-bit 空间地址；W 的 \(G_N\) 求值表只有 \(O(m)\)-bit 地址。该字面基表入口的失败也不能替代 (29)。

本次因此停在 **W 的源覆盖 UNKNOWN**：非一致条件推论 (8)→(10) 和一次复合 (22)–(25) 已建立；自绑定公式的准确语义为 (14)–(17)，没有补上 lex-first-outsider 条件。若未来直接证明 W，则其正确 advice 已获得数学源依据；若要把 advice 消为公式内部的自由存在量词，则必须保留独立源条件，不能用自身输出认证自身。

未推进后续 canonical-prefix/batch-count 复合，未进入 R3，也不据此宣布复杂度类分离。只新建本文件；既有文件、未跟踪 SPEC、永久 notes 及异步 Pro 会话均保留。未使用远程、OMEN、重计算或 Git 提交。
