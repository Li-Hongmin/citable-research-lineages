# 冻结 R2：抽象 K 下 count 与实际 prefix 集合的源绑定

2026-09-27。只处理本轮补充问题。没有选取另一 serializer，没有修改既有文件。

**裁决：固定但未展开的二进制函数 K 足以定义 K-relative 的精确 count/prefix 关系；完整 bit-to-oracle routing 不是这种定义或一般非字面 R2 证明的逻辑必要前置。** 但只有 completeness 契约和函数层代数对象时，要消去 K 的实现参数，必须证明所需观测在契约未区分的实现之间一致；当前来源没有这项证明，本轮也未证明一致性或其否定。

本轮新增的具体判断是：**在首批实际全 YES 的执行守卫下，保留该 stage 全部实际 lex-prefix 集合，与保留原有序块串在语义上等价。** 这仅沿原程序实际选中的 prefix 路径证明，不要求任意反事实 prefix。这限定了“函数代数绕开 routing”必须证明的源绑定内容；它不是短电路下界，也不是 R2 NOGO。

## 1. 本轮输入与原始依据

已读 [上一份窗口裁决](r2-algebraic-window-source-verdict-20260927.md) 与 [新 Pro 整页末尾答复](pro-source-layout-confirmation-20260927.txt:11061)。新答复仅确认窗口 L 尚缺具体布局，作为候选输入，不作为以下命题的证据。异步挑战的新答案未在本轮输入中；不假定它已给出函数层闭合。

本轮直接检查 [RW 原文]([unmapped-local-locator]) Theorem 3.1 的 contiguous blocks、prefix rounds、dummy variables 与下一字符串（498–550 行），以及 Lemma 3.2 的真实 query counts（598–625 行）和 Theorem 3.4 的确定性 completeness 接口（749–769 行）。无需重查次数、取整或 W。已读冻结 SPEC、AGENTS 和回流工作区 README；没有网络或远程操作。

## 2. “固定 K”与“仅有 K 的契约”是不同的数学输入

保持冻结的 G_n、G_N 和原 source。对 admissible q，记

\[
 n=2^q,\quad N=n^C=2^m,\quad m=Cq,\quad T_0=2^{cn}.
\]

令 I_q=(C_q,w_q) 表示同一实际 BF₀ 所诱导的完整 constructor 输入；没有另选 assignment、门值或原始 history。K_* 是题设**一次固定、跨 q 不变**的确定性 binary-output constructor。定义

\[
 \Pi_q^{K_*}=K_*(I_q),\qquad P_q^{K_*}=|\Pi_q^{K_*}|.
 \tag{1}
\]

如果 K_* 的类型和含义已经是这个确定性二进制输出函数，那么 (1) 即为单值定义。读者不知道 K_* 的机器码，并不使 (1) 在数学上变成多值；可对它作参数化证明。无需先把它拆成 field-point routing。

另一方面，RW “there exists … such a proof … can be computed in deterministic poly(n) time” 的**契约**，以及 Ã、P、Π_ZoS 的函数级说明，本身没有指定该函数常元的全部二进制含义。从这一契约推出的定理可以对每个符合契约的 K 分别成立，不能省掉 K 后把多个参数化对象叫成原文唯一确定的一个对象。

本轮不从契约中挑选一个实现。合法的参数化结论形如

\[
 \forall K\text{（满足固定契约的确定性 constructor）}\
 \exists a_K\ \forall q\in\mathcal A_C\text{（充分大）}:\quad
 \text{对同一个 }K(I_q)\text{ 给出关系及费用界}.
 \tag{2}
\]

实际研究对象始终是 K_* 的那个实例。不能换成 \(\forall q\exists K_q\)，也不能对不同窗口、不同 prefix 各选一份被接受的 proof。后面出现的“契约的实现”仅用于陈述可定义性条件，没有构造或运行任何另一个 serializer。

## 3. 不展开 routing 的精确语义，以及不能隐藏的 metadata

对下式省略 K_* 上标。按原 JK 规则设

\[
 k_q=\left\lceil\log_2(P_q/N)\right\rceil,\quad
 \widehat P_q=N2^{k_q},\quad J_q=2^{k_q-1},
\]

\[
 Z_{q,j}=(\Pi_q0^{\widehat P_q-P_q})[2Nj:2N(j+1)],
 \qquad 0\le j<J_q.
 \tag{3}
\]

这段定义只用 K 的字符串输出，不用坐标线、域点或系数。令

\[
 E_q(j,u):=[G_N(u)=Z_{q,j}],\quad
 c_{q,0}=\sum_{j<J_q}\mathbf1[\exists u\in\{0,1\}^N:E_q(j,u)],\quad
 A_q:=[c_{q,0}=J_q].
 \tag{4}
\]

这些是精确、源绑定的数学定义。求和、K 调用和长字符串比较在这里尚未成为免费矩阵原语。

原 JK 的 chunk 宽度是 \(\lambda_q=\lceil\log_2(P_q|G_N|)\rceil\)，由该次调用的**原输入长度**确定。原文 532–533 行还把 seed 变量补至

\[
 M_q=\lambda_q\tau_q,\qquad
 \tau_q=\lceil N/\lambda_q\rceil,\qquad N\le M_q<N+\lambda_q.
 \tag{5}
\]

令 \(\delta_q:\{0,1\}^{M_q}\to\{0,1\}^N\) 表示原实现删除 dummy variables、返回原 seed 的既定投影，变量顺序也按原实现。这里没有指定一种新插入方法。若原实现以较短末轮处理，须保留它与原查询集合及计数的已证对应，不能自动把末轮改短。未约束的 dummy 位会影响候选 prefix 的数量；仅保留最终 seed 输出不保证保留每轮 count。

因此以下 \(\Lambda_q\) 作为实际控制 metadata 保留：原长度/补零边界、J_q、chunk 规则、变量次序与 dummy 投影，以及在写入原 history 时使用的 count 字段宽度。这些数据可以用精确的程序或符号规则表示，不要求逐 q 附上一张常数表；其实际生成、求值和描述费用仍须支付。完整 K/JK 程序可隐含这些数据，已知一个长度上界或“poly(S)”不能替代其精确值。

只在 A_q 真时定义实际 prefix 集合。设 p_{j,0}=ε，对 0≤r<τ_q 递归定义

\[
\begin{split}
 F_{q,r,j}=\{t\in\{0,1\}^{\lambda_q}:\ \exists w\in\{0,1\}^{M_q},\
 &G_N(\delta_q(w))=Z_{q,j},\\
 &w_{<r\lambda_q}=p_{j,r},\quad
 w_{[r\lambda_q,(r+1)\lambda_q)}=t\},
\end{split}
 \tag{6}
\]

\[
 t_{j,r}=\min_{\rm lex}F_{q,r,j},\qquad
 p_{j,r+1}=p_{j,r}t_{j,r}.
 \tag{7}
\]

这些集合非空：初始时块均有原像，每步选择的 t 保持 prefix 可延伸。这恰是原文 534–540 行的真实查询批；其正确 YES 数为

\[
 c_{q,r+1}=\sum_{j<J_q}|F_{q,r,j}|.
 \tag{8}
\]

如果 A_q 假，原程序在 membership 批停止，(6)–(8) 的 inversion 批**未发生**；关系应带 inactive/未执行标记，不把这些集合假装成一个实际空批。

## 4. 新的源绑定引理：实际 prefix 路径已足以恢复块串

**命题。** 固定 G_N 和同一 metadata Λ_q。在 A_q=1 条件下，实际带标签的整组集合

\[
 \mathcal F_q=(F_{q,r,j})_{0\le r<\tau_q,\ 0\le j<J_q}
 \tag{9}
\]

唯一确定原有序块串 \((Z_{q,j})_{j<J_q}\)。反过来，有序块串和 Λ_q 唯一确定 (9)。这里只要求原 lex-first 路径上的集合，不要求所有反事实 prefix 的可延伸关系。

证明：给定 (9)，按 (7) 拼接每一轮的 lexicographically first 元素，得到长度 M_q 的 w_j=p_{j,τ_q}。由每轮可延伸性和最终长度，w_j 本身满足

\[
 G_N(\delta_q(w_j))=Z_{q,j}.
 \tag{10}
\]

故 (9) 决定每个有标签的 Z_{q,j}。反方向直接由 (6)–(7) 的确定性递归成立。等价地，任意两次具有相同 G_N、Λ_q 且都进入 all-YES 分支的实际实例，全部带标签的实际 prefix 集合相同，当且仅当其初始有序块串相同。这个陈述不主张本项目存在两个不同实例，也不以另一实例作 NOGO 证据。

块串连接后就是原补零 proof；Λ_q 中的 P_q 再确定原 Π_q。因而完整 prefix-set 保真在该守卫下保留了整个同一 proof 的**语义信息**。逐地址电路复杂度不由此得出：j 的自然宽度为 Θ(n)，单个 t 的宽度为 Θ(n)，从集合求最小值也不是免费操作。若只给各集合的 membership 接口，一种直接恢复每个 w_j 的方法会调用该接口至多 τ_q·2^{λ_q} 次，随后再求值 G_N；本轮没有把这种恢复压至 poly(m)。

范围必须区分：

- 首个 membership count c_{q,0} 只要求 (4) 的一个整数；本命题没有将它等同于块串。
- 只保留第一轮 F_{q,0,j} 不等于保留整组 (9)，不能据本命题宣称已经恢复全部 seed。
- 只保留每轮集合的基数、无标签的集合总汇或某个可用 seed，不是本命题的假设；原相邻配对继续依赖原 j 顺序。
- 在 A_q=0 分支，若只要求 count 与实际 prefix 批，本轮的观测就是 count 加“未执行”。若还要求同一 hard return word、固定 NO tie-break 或下一份完整 canonical history，则必须额外绑定相应对象，不能借本命题省掉。

## 5. 函数层代数能够绕过 routing 的准确条件

令 \(\mathfrak A_q(K)\) 表示拟保留的函数层数据，例如原 oracle 多项式及其参数；明确它实际包含哪些长度/编码信息，不能把缺失 bit order 偷藏进这个名字。令

\[
 \mathcal O_q(K)=
 \bigl(\Lambda_q(K),c_{q,0}(K),
       \text{若 }A_q(K)\text{ 则 }\mathcal F_q(K),\text{否则 inactive}\bigr).
 \tag{11}
\]

对每个 q，一个只依赖 \(\mathfrak A_q\)、对契约所有实现都成立的精确观测函数存在，当且仅当

\[
 \forall K,K'\quad
 \mathfrak A_q(K)=\mathfrak A_q(K')
 \ \Longrightarrow\ 
 \mathcal O_q(K)=\mathcal O_q(K').
 \tag{12}
\]

证明：正向由函数单值性；反向在每个非空纤维上取唯一的共同观测值。这个证明只建立集合论意义的 factorization，不保证该函数可计算、可短描述或可在 poly(m) 内生成。式 (12) 也没有通过设想一份随意重排 proof 来证伪：没有给出两个相容 actual 实例具有不同观测，因此当前 **(12) 为 UNKNOWN**。

对单一 K_*，无须先证明所有实现上的 (12)。一个未来的函数层方案可以直接证明

\[
 \forall q\in\mathcal A_C,\ q\ge q_*:
 \quad \mathcal S_q(\mathfrak A_q(K_*),\eta_q)
       =\mathcal O_q(K_*),
 \tag{13}
\]

其中 η_q 是明确计价、跨该 q 的所有相关观测共同使用的 descriptor。若方案依赖 η_q 来区分缺失实现信息，则它不再是仅由裸 \(\mathfrak A_q\) 决定；这可以合法，但必须指出该信息及长度。K_* 始终固定，不能在证明每个条目时另换 K。

式 (13) 可以由一个真正的全局代数恒等式证明，不必提供逐地址 routing。其必要内容至少为：同一真实 c_{q,0}、同一执行守卫，以及对所有实际到达的 r,j 和所有该批候选 t 的 (6) 等价式。由 (8) 自动保留该 stage 的 prefix counts，由 (7) 保留原 lex-first 选择；原 metadata 再保持原顺序的下一串。若只证明 membership 恒 YES，则没有证明 (6)。

依第 4 节，在 all-YES 分支上，保留整组 (6) 的任何摘要也在语义上固定了同一有序块串。因此“完全忘掉布局后仍保留完整实际 prefix 行为”需要证明该有序字串的观测已经由所保留信息确定。现有 completeness/低次数契约没有这项绑定定理。本轮不把缺少该定理改写成不可能性。

## 6. 最少数据与资源账

对本轮**精确观测目标**，最少额外信息可按观测等价类描述：

\[
 K\sim_q K'\quad\Longleftrightarrow\quad
 \mathcal O_q(K)=\mathcal O_q(K').
 \tag{14}
\]

任何精确保留目标的描述必须区分不同的 (14) 类；区分同一类内的内部求值顺序、未用代码或 field routing 则非必要。在相同 Λ_q 下，NO 分支的本轮类由 c_{q,0} 决定；all-YES 分支由原有序块串决定（第 4 节）。这给出了严格的语义最少量，而不是建议将这个巨大对象作为 payload 存入 descriptor。

可供核对的实现数据有两种等价用途：

1. 给出**原来那个** K_* 在实际 I_q 上的确切二进制输出/长度规则及原 JK metadata。可以是原程序或精确 bit-graph，不要求先分解成 oracle routing，也不要求知道它在非实际输入上的行为。
2. 给出能对照同一 K_* 证明 (13) 的直接 count/prefix 接口。此时接口本身承担缺失绑定；只把它命名成“代数关系”或“前缀关系”不等于已得到它。

从现有契约只有下列保守、已付费的基线。对每个固定 K，其 source/proof 电路生成指数允许依赖 K，但不依赖 q：存在 a_K，使实际 source→Π_q 的完整展开大小、生成费用和输出长度均至多 \(U_q=T_0^{a_K}\)（增大固定指数可吸收标准模拟）。这是已有确定性基阶段和 completeness 构造的直接展开，不运行该巨大构造。

在这一展开中实现 E_q，matrix 至多 \(T_0^{O_K(1)}\) 门；令 g_N=|G_N|≤N⁴，则给定显式 j、长度 d 的 prefix p，精确 prefix 谓词

\[
 \exists w\in\{0,1\}^{M_q}:
 G_N(\delta_q(w))=Z_{q,j}\ \land\ w_{<d}=p
 \tag{15}
\]

量化 M_q=O(N) 位，普通矩阵大小至多 \(T_0^{O_K(1)}+O(g_N+M_q)\)，显式输入 j、p 分别为 log₂J_q 与 d 位。最小 padded seed 的图可用

\[
 \widetilde E_q(j,w)\ \land\
 \forall v\in\{0,1\}^{M_q}
 [v\ge_{\rm lex}w\ \lor\ \neg\widetilde E_q(j,v)],
 \quad \widetilde E_q(j,w):=E_q(j,\delta_q(w)),
 \tag{16}
\]

表示，再付 M_q 个全称位及两份比较矩阵。若 w 也作存在量化，再付 M_q 位。全 YES 守卫为 \(\forall j^{\log_2J_q}\exists u^N E_q(j,u)\)。这些精确式没有隐藏 oracle，但均未达到地址尺度。

count 也不能将 (4)、(8) 的求和当作免费 # gate。一个不带外部表的完全展开上界是先内部计算同一 Π_q，再对每个 j、每个 N-bit seed 作比较、OR 和普通加法；首批 count 电路大小可取

\[
 U_q+O\bigl(J_q2^N(g_N+N)+J_q\log(J_q+1)\bigr).
 \tag{17}
\]

同样，可将全 YES 分支的 τ_q 轮内部展开：每轮对原 J_q2^{λ_q} 个候选和全部 M_q-bit padded seeds 检查 (6)，用普通电路计算该轮 count 与每个 lex-first chunk，作为下一轮内部状态，不引入免费 p_{j,r} 数组。一个充分的总上界是

\[
 U_q+O\!\left(J_q2^N(g_N+N)+
 \tau_qJ_q2^{\lambda_q+M_q}
 (g_N+M_q+\lambda_q+\log(J_q+1))\right)
 \le T_0^{O_K(1)}2^{O(N)}.
 \tag{18}
\]

guard 假时输出 inactive 标记。式 (17)–(18) 只提供费用上界，没有实际构建、运行，也不是所需压缩。所有显式门表另付 \(O((S+W)\log(S+W))\) 位，S 为所用门数、W 为显式输入/量词宽度；按相应展开规模生成。K 的固定短程序名支付描述长度，不能替代这些展开成本。

本尺度下 \(\log J_q=\Theta(n)\)、\(\lambda_q=\Theta(n)\)，首批 count 所需位宽为 log₂J_q+1，prefix-round count 的充分位宽为 log₂J_q+λ_q+1，均为 Θ(n)。count 的**位地址**可只有 O(log n)=O(m) 位，所以这些字段长不能当成 count-bit 电路下界；但逐项保留 j 与候选 t 的输入已经超出 poly(m)，不能省记。

若未来主张地址尺度关系，必须有固定指数 d、一个固定关系/生成模板和足够大 q_*，使对所有 admissible q≥q_* 存在共同 η_q，长度≤m^d，并在同一预算内支付显式标签、所有量化位、普通矩阵、门表、生成和一次实际复合，同时证明 (13)。这里的全体 q/r/j/t 是数学正确性量词，不能未经编译就算作短公式内的免费全称变量。当前未构造这样的模板。

## 7. 停止判断

本轮改变的是下一步的验收条件：**不要求所有函数层 R2 方案先重建完整 routing；要求它直接证明实际观测绑定 (13)，或证明可消去实现参数的 (12)，并计清费用。** 第 4 节说明了完整实际 lex-prefix 保真在 all-YES 分支究竟保留了多少语义信息，且没有加入反事实 prefix 或不可达输入。

现有抽象 K 契约已足够支持参数化的精确语义和对象尺度展开；它未给出一个独立于实现的 actual count/prefix 结果，也未给出地址尺度闭合。当前最早未证项是对固定 K_* 的 (13)，或函数层数据上的 (12)。完整原 K/JK 程序或确切行为规则可作为廉价静态核对的输入；当前材料没有新增它。没有需要运行的廉价数值实验；同一来源重读不会判定这项观测一致性。本轮停在上述精确 UNKNOWN，不切 R3，不作 R2 NOGO 或复杂度分离宣称。
