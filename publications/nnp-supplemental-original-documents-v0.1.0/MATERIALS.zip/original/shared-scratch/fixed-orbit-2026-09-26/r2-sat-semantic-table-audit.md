# R2：SAT 语义表的全局一致性、实际覆盖与基源矩形表边界

2026-09-26。仅为本轮 scratch 推导，不晋级为项目 note。

**结论：R2 仍为 UNKNOWN。** 最新 Pro 的全局一致性编译器在下述明确的普通 tableau 实现下成立；其实际 membership 完备性精确等价于覆盖命题 W。原始 RW 来源还足以证明，这次首查询在充分大的实际基点上总是 YES。本轮没有证明 W，也没有给出否定 W 的实际反例。

本轮得到两个新的、针对实际源的定量边界。第一，W 的任何覆盖表均投影出同一个 \(B_0\) 的短 SAT 语义描述；它至少需要
\[
r_{\rm eff}+\log_2(s+1)\ge q-\log_2q-O(1)
\]
的有效 SAT 见证／电路预算。第二，若把同一种完整矩形 SAT 表直接用于真实 \(BF_0\) 以提供非循环的源入口，则时间零的唯一读写头已强制 \(s_B=\Omega(n)\)，在 Pro 的门表编码下代码长为 \(\Omega(n\log n)\)。这排除了该字面基源表入口，不排除非字面的源关系，也不否定用于 \(G_N\) 求值的 W。

## 1. 本次读取的候选输入与原始依据

继续使用同目录的 [先前推导](r2-pro-formulas-and-global-seed-compression.md)。新的候选输入为 [页面文本](pro-followup-page.txt) 与 [页面 HTML](pro-followup-page.html)。只提取 HTML 中第二个、也是最后一个 assistant 消息：

- DOM 键为 fallback-turn-1:2:assistant；消息 ID 为 [coordination-identifier-removed]。
- 普通段落取正文；公式取 KaTeX 的 application/x-tex annotation，跳过重复的渲染数学内容。文本版相应范围从第二个“ChatGPT 说：”（约第 4467 行）开始。
- 所审查的是其中 A1–A16 及 W。侧栏、先前回复、用户消息与 HTML 中的重复 hydration 数据均不充当数学输入。没有操作浏览器或 pending Pro challenge。

项目边界来自 AGENTS.md、RW README 与 [冻结 SPEC](../../units/rw-jk-succinct-reconstruction/SPEC-2026-09-23-fixed-orbit.md)。处理候选输入前已读取本地 Drive 工作区权威 README；没有同步或外部写入。数学事实回到本地原始来源：

[Ren–Williams，ECCC TR26-118 revision 1，本地全文]([unmapped-local-locator])。

| 原始位置 | 本轮使用的事实 |
|---|---|
| Theorem 3.1，约 490–548 行 | 先对所有连续 \(2N\)-bit 块发出 membership 查询；任一 NO 即退出；只有全 YES 才逐 chunk 恢复最小原像。 |
| Theorems 3.4–3.5，约 779–850 行 | complete witness 和 systematic prefix；完整 witness 包含输入 assignment 及 gate values。 |
| Theorem 4.3，约 1040–1090 行 | \(BF_0\) 枚举同一生成器的全部 range，输出 lex-first outsider；\(r_0=s_0=0\)，\(T_0=2^{cn}\)，下一宽度 \(N=n^C\)。 |
| truth-table generator 与 Theorem 4.5，约 1152–1173 行 | 长度 \(n\) 的 seed 编码小电路；outsider 的普通电路复杂度大于 \(0.1n/\log_2 n\)。 |

[Paper 04](../../units/rw-jk-succinct-reconstruction/papers/04-from-address-scale-smart-reconstruction-to-p-poly/paper.md) 的 1.3A、1.3E、1.27 分别用于核对语义／资源区别、显式量词和矩阵计价、二进制序列化边界。[Note 613](../../units/mcsp-hardness-magnification/notes/613-the-first-actual-jk-block-has-no-address-scale-exact-evaluator-2026-08-28.md) 的投影由上述原文重新核验。旧记录和 Pro 回复不作为独立的原始证据。没有检索远程或更新版本的文献；证据范围限于本地 revision 1 和冻结约定。

### 1.1 固定对象与序列化边界

全篇令
\[
n=2^q,\qquad N=n^C=2^m,\qquad m=Cq,\qquad T_0=2^{cn},
\]
其中 \(C\ge3,c\ge1\) 固定，\(q\) 遍历充分大的实际 admissible 基阶段。令
\[
B_0=\min_{\rm lex}\bigl(\{0,1\}^{2n}\setminus{\rm Range}(G_n)\bigr).
\]
原始覆盖性质给出
\[
{\rm CC}(B_0)>0.1n/q. \tag{1}
\]
这在每个充分大的实际基点成立，不以 later good length 或全批 YES 为条件。

沿用已冻结的 raw-binary-history-prefix 约定，不重新选择 field encoding 或 PCP/JK serializer。基阶段没有 counts 和 oracle witnesses，output 为 \(B_00^{T_0-2n}\)。对充分大的 \(q\)，有 \(T_0\ge2N\)，故实际第一块为
\[
Z_0=B_00^{2N-2n}. \tag{2}
\]
仅 \(T_0\ge N\) 不足以推出全部零尾；这里使用了更强而最终成立的不等式。

原文的 systematic 性质本身不唯一指定全部二进制坐标顺序。式 (2) 是原始 source 加题设已冻结的 binary-prefix 约定的结论，不是对任意 source-compatible 序列化的断言。新 Pro 的辅助计算表只验证同一个 \(G_N\) 的求值，不是替换 PCP proof 或其实际序列化。保持正确的无效 seed 处理也是固定求值机器的义务。

### 1.2 首个实际 membership 的答案已可确定

任何固定的 \(2n\)-bit 表均有 \(O(n)\) 门的查表电路。将 \(B_0\) 硬接其中，并检查高 \(m-q\) 个地址位为零，可计算 (2)，因而
\[
{\rm CC}(Z_0)\le K_0n+K_1m<0.1N/m \tag{3}
\]
对充分大的 \(q\) 成立。长度 \(N\) 的同一 truth-table generator 覆盖该电路，故
\[
I(q):=\mathbf1[Z_0\in{\rm Range}(G_N)]=1. \tag{4}
\]

这是一项存在性证明；查表电路中的 \(B_0\) 没有因此变为可免费读取的 payload。它不提供短 seed 描述，更不提供短求值表。Theorem 3.1 确认这次查询实际发出，且不要求事先证明其余块的答案。因此不能把 (4) 扩大为全批 YES 或 inversion 已实际执行。只把答案化为常真也没有完成所要求的全局见证复合。

## 2. 对 A2–A7 的独立证明：固定 SAT 真值强制同一全局 seed

### 2.1 需固定并计价的辅助对象

固定确定性机器 \(\mathcal M\)，包括原 \(G_N\) 的 uniform constructor、完整求值、无效编码语义及输出放置规则。P-uniformity 和固定的单带模拟给出某个固定整数 \(\alpha\)，使它在
\[
T\le N^\alpha
\]
步内完成。常数倍余量、停机后自环和空间边界均吸收到时钟和下面的常数。输出放入固定可定位的二进制单元。

用常规有限字母表的局部时间—空间表；每个符号用常数位编码。表地址和局部检查编号的宽度为
\[
h=2\alpha m+O(1),\qquad \ell=2\alpha m+O(1). \tag{5}
\]
每个检查 \(\xi\) 访问至多 \(c_E\) 个表位 \(z_i(\xi)\)，其中 \(c_E\) 固定。不足的槽填为固定合法重复地址。公开地址算术和检查电路用 \(O(m^2)\) 门即可实现。

以下细节是“合法 tableau”的组成部分，不能从检查中删除：有效地址／padding 守卫；符号合法性；初始行的固定输入、唯一头和状态；seed 区域仅允许二进制符号；边界单元；唯一的确定性局部转移；最终停机和固定输出单元。固定机器的转移表为常量，数值边界的比较和相邻地址加减为短二进制运算。程序生成 \(G_N\) 的长计算在 tableau 内，未假设可用 polylog 大小的 wiring oracle。

输出的一位是原表中固定常数 \(c_o\) 个符号位的固定布尔解码 \(D_{\rm out}\)；把这些位计入 \(c_E\) 即可。若原编码恰有直接 output-bit 槽，则 \(c_o=1\)，解码为恒等函数；本轮不添加这种槽或重新选择符号编码。后文的源图使用全部 \(c_o\) 个原有表位，因此也适用于一般多位符号。任意布尔解码不能未经证明称为一个 NP 正位投影。

### 2.2 电路代码与普通求值矩阵

令 \(s=m^d,r=s\)，其中 \(d\) 是跨基点固定的整数。代码 \(\sigma\) 描述一个至多 \(s\) 门、fan-in 至多二的普通电路 \(F_\sigma(z,w)\)，\(|z|=h,|w|=r\)。可用 unused gates 补齐定长格式。令
\[
\lambda=\lceil\log_2(h+r+s+2)\rceil,\qquad
L=s(3+2\lambda)+\lambda. \tag{6}
\]
三位 gate type、两个前驱编号和一个最终输出编号足够。代码合法性包括拓扑前驱范围、门类型及输出范围。

用普通 mux 逐门求值，得到总化的电路 \(U(\sigma,z,w)\)。非法代码上的值任意固定；另由 Code 排除。含代码检查的费用可统一吸收到常数 \(A\)，有
\[
|U|+|{\sf Code}|\le A\,s(h+r+s). \tag{7}
\]
理由是每门最多从 \(h+r+s\) 条线选择两个前驱；编号比较的 \(O(s\log(h+r+s))\) 开销被 (7) 吸收。这里没有 SAT gate。SAT 语义仅在
\[
\tau_\sigma(z)=1\iff\exists w^r\,F_\sigma(z,w)=1 \tag{8}
\]
中定义，下一步将见证完整展开。

### 2.3 真值绑定与正确性

对一次局部检查，令 \(\mathbf b=(b_1,\ldots,b_{c_E})\)，每个 \(x_i,y_i\) 长 \(r\)，并写
\[
{\sf Truth}_\sigma=
\bigwedge_{i=1}^{c_E}
\left[(\neg b_i\vee U(\sigma,z_i,x_i))
\wedge(b_i\vee\neg U(\sigma,z_i,y_i))\right]. \tag{9}
\]
Pro A7 是
\[
\exists\sigma^L\ \forall\xi^\ell\
\exists(\mathbf b^{c_E},\mathbf x^{c_Er})\
\forall\mathbf y^{c_Er}:
{\sf Code}(\sigma)\wedge{\sf Local}(\xi,\mathbf b)
\wedge{\sf Truth}_\sigma. \tag{10}
\]

固定外层的合法 \(\sigma\) 和一个 \(\xi\)。若 \(b_i=1\)，存在的 \(x_i\) 必须接受，故 \(\tau_\sigma(z_i)=1\)。若 \(b_i=0\)，所有 \(y_i\) 都必须拒绝，故 \(\tau_\sigma(z_i)=0\)。因此每个成功策略都满足
\[
b_i=\tau_\sigma(z_i). \tag{11}
\]
所有见证域非空；把其他 \(y_j\) 固定即可得到对每个 \(y_i\) 的全称断言。

同一个地址在不同检查出现时，其值由 (8) 唯一确定。不同 SAT 见证不能改变该真值。又因 \(\exists\sigma\) 位于 \(\forall\xi\) 前，所有检查使用同一张表。合法初始行确定一个完整 seed \(u_\sigma\)；从该行按时间归纳，所有后续行均为固定机器的唯一合法后继。所以这确是一张 \(\mathcal M(N,u_\sigma)\) 的完整运行表。提取 \(u_\sigma\) 是证明中的数学定义，未向公式偷加 \(N\) 位的量词。

反向，若 \(\tau_\sigma\) 是一张合法表，每个检查取真实的 \(\mathbf b\)，为所有 1 位选接受见证；0 位对所有挑战都拒绝，故 (10) 成立。由此证明了 A7 的双向等价。关键不是“局部见证自然拼成全局见证”，而是 (8) 和 (11) 已先确定同一全局对象。

## 3. A9 的实际复合、精确语义和完整成本

假设确有 exact 源接口
\[
H_{\delta_m}(a,b)=Q_1v_1\cdots Q_kv_k\,
R_H(\delta_m,a,b,\mathbf v)
\iff Z_0[a]=b, \tag{12}
\]
其中共同 descriptor 为 \(\delta_m\)，量词总宽度 \(P_H\)，普通矩阵大小 \(S_H\)。这是待满足的入口条件，A7 没有证明它。

在 output-check 中令额外的 \(b_\star\) 等于机器输出位，并加入 \(H_{\delta_m}(a,b_\star)\)；其他检查关闭该要求。真正展开 \(R_H\)，得到
\[
\exists\sigma^L\ \forall\xi^\ell\
\exists(\mathbf b^{c_E},b_\star,\mathbf x^{c_Er})\
\forall\mathbf y^{c_Er}\
Q_1v_1\cdots Q_kv_k:\ R_{\rm comp}. \tag{13}
\]
矩阵中包含 (9)、局部检查和带 output guard 的 \(R_H\)，不存在 \(H\) oracle。

把 \(H\) 的前束放在 \(\forall\mathbf y\) 后是合法的。对已固定的外层变量，local/Truth 不含 \(\mathbf v\)；\(H\) 不含 \(\mathbf y\)。非空域允许把前者从每层 \(Q_j\) 提出，并把对 \(H\) 的 dummy \(\mathbf y\) 依赖消去。output guard 为假时整个源子式为真。因而额外允许的见证依赖不会制造错误的源值。

令 \(\mathcal D_m\) 为固定表的有效地址域，并定义
\[
\begin{aligned}
\mathcal T_m(Z_0)
&=\{\operatorname{Tab}_{\mathcal M}(N,u):
u\in\{0,1\}^N,\ G_N(u)=Z_0\},\\
\mathcal S_{m,s}
&=\{\tau_\sigma|_{\mathcal D_m}:
\sigma\text{ 合法},\ |F_\sigma|\le s,\ r=s\}.
\end{aligned}
\]
表的相等只要求在同一 \(\mathcal D_m\) 上成立。由第 2 节和 exact (12)，
\[
(13)\iff\mathcal T_m(Z_0)\cap\mathcal S_{m,s}\ne\varnothing. \tag{14}
\]
正向先提取一个 seed，再由所有 output-check 得到逐位相同的 \(Z_0\)；反向取覆盖表和每个真的源子式的见证策略。因而 (13) 无假 YES，但在没有覆盖时可以漏掉真实 YES。

### 3.1 编译器实际付出的资源

| 项目 | 已展开成本 |
|---|---|
| 表代码与全局检查编号 | \(L+\ell\) 个量词位 |
| 局部值、正见证、负挑战 | \(c_E+1+2c_Er\) 个量词位 |
| 源接口 | \(P_H\) 个量词位、\(S_H\) 个普通 gates、\(|\delta_m|\) 位共同描述 |
| 总宽度与层数 | \(Q=L+\ell+c_E+1+2c_Er+P_H\)，至多 \(k+4\) 块 |
| 总普通矩阵 | \(S_{\rm comp}\le 2c_E A s(h+r+s)+S_H+K m^2\)，扩大固定 \(A,K\) 吸收 Code、guards 和解码 |

展开后的 gate-list 编码和量词变量布局也要支付。令
\[
V=m+|\delta_m|+Q+O(1).
\]
一个保守的完整显式描述界为
\[
O\bigl((S_{\rm comp}+V)\log(S_{\rm comp}+V+2)\bigr). \tag{15}
\]
固定程序、\(C,\alpha,d\) 是常量；公开参数 \(m\) 另用 \(O(\log m)\) 位。若单独保留 descriptor 而不硬接，还须列出 \(\delta_m\) 的全部位。(15) 已允许把这些位和输入布局一起计入。只报告生成矩阵的短程序长度不够。

具体到 \(s=r=m^d,d\ge1\)，有 \(L=O(m^d\log m)\)，\(Q=O(m^d\log m+P_H)\)，\(S_{\rm comp}=O(m^{2d}+S_H)\)。这些界仍须加上 (15) 的显式编码与 \(|\delta_m|\)，且都以 exact 源接口和相应覆盖成立为语义前提。

给定 (12) 的显式矩阵，generic 编译器的构造时间是其输出规模的一个固定多项式。它不会因此构造出正确的 \(\sigma\)，也不检查覆盖是否成立。完整 \(\mathcal M\) tableau 有 \(2^{\Theta(m)}\) 个格子；在关系中用短全称地址检查它是合法的，前提恰是短代码所表示的真实表存在。uniform constructor 的运行位于表内，没有被从正确性条件中删除。

若入口仍取先前已核验的前驱候选关系，则
\[
k=3,\quad P_H=4n+2,\quad
S_H\le4|G_n|+O(n+m).
\]
代入 (13) 得至多七个量词块，
\[
Q=L+\ell+c_E+1+2c_Er+4n+2,\qquad
S_{\rm comp}\le2c_E A s(h+r+s)+4|G_n|+O(n+m^2). \tag{16}
\]
这仍为 object scale。把 \(n=2^{m/C}\) 改叫地址参数不能改变 (16)。

## 4. 覆盖 W 的精确量词及其当前状态

对固定的 \(\mathcal M\)、clock、表布局、有效域和代码格式，令
\[
E_s(q)=\mathbf1[\mathcal T_m(Z_0)\cap\mathcal S_{m,s}\ne\varnothing].
\]
覆盖命题的渐近量词应写为
\[
\begin{split}
W:\quad&\exists d\ge1\ \exists q_\star\
\forall q\ge q_\star\text{（实际 admissible 基点）}:\\
&\mathcal T_m(Z_0)\ne\varnothing
\ \Longrightarrow\
\mathcal T_m(Z_0)\cap\mathcal S_{m,m^d}\ne\varnothing.
\end{split} \tag{17}
\]
所有常数对 \(q\) 统一。一个孤立有限基点不存在有意义的渐近“所有固定次数”预算判断。

由 (4)，可增大 \(q_\star\) 把 (17) 简化为
\[
\exists d,q_\star\ \forall q\ge q_\star\text{ actual}:\
E_{m^d}(q)=1. \tag{18}
\]
所以本轮不需要再计算 \(I(q)\)。在 exact (12) 的条件下，(17) 正好是此编译器对这些实际查询最终完备的必要且充分条件。这不要求所有 seeds、任意 targets 或最小 seed 有短表；只要求每个实际 \(Z_0\) 的至少一个真实原像的整张求值表有短表。

seed 本身有短位关系并不充分。验证同一个 \(G_N\) 的全部 gate values、uniform construction 和输出仍需覆盖。P-uniformity 只给 \(\operatorname{poly}(N)\) 时间算法；把其时钟记作 \(2^{O(m)}\) 没有给出 \(\operatorname{poly}(m)\) 的 SAT 位证书。

前一轮对“逐前驱重编码全部原像”的计数下界不否定 (17)：那里需要保存每个前驱的真实见证，本式只索求一个全局表。反过来，单个有限 \(q\) 的 \(E_{m^d}(q)=1\) 也不能证明 (17)；一个预算 \(d\) 的失败不能否定更大的固定次数。没有执行穷举代码或 SAT 真值表排除。

## 5. 实际族推导一：覆盖表必给出源投影，并支付真实见证宽度

### 5.1 W 对基源关系的条件性贡献

令 \(o_1(a),\ldots,o_{c_o}(a)\) 是解码最终第 \(a\) 个输出位所需的原有表地址，\(D_{\rm out}\) 为原有符号解码。全部公开地址电路与该固定解码的总大小记为
\[
S_o=O(m^2).
\]
若 \(\sigma_q\) 覆盖 \(\mathcal T_m(Z_0)\) 的一张表，则对 \(0\le a<2N\)，
\[
Z_0[a]=D_{\rm out}\bigl(
\tau_{\sigma_q}(o_1(a)),\ldots,\tau_{\sigma_q}(o_{c_o}(a))\bigr). \tag{19}
\]
将 \(a\) 的高位固定为零，(19) 也给出 \(B_0\) 全部 \(2n\) 位。这个推导只用了同一实际表的最终输出，不借用任意生成器或不可达对象。只有当原编码已有直接输出位时，才能把 (19) 简化为 \(Z_0[a]=1\iff\exists w^r F_{\sigma_q}(o_1(a),w)=1\)；一般情形是常数多个 SAT 真值的布尔组合。

同一个 descriptor \(\delta'_m=\sigma_q\) 因而给出 exact 的两块量词图：
\[
\begin{split}
H_{\sigma_q}^{\rm out}(a,b):=
\exists(\boldsymbol\beta^{c_o},\mathbf x^{c_or})\
\forall\mathbf y^{c_or}:\quad&
[D_{\rm out}(\boldsymbol\beta)=b]\\
{}\wedge\bigwedge_{j=1}^{c_o}
\bigl[(\neg\beta_j\vee U(\sigma_q,o_j(a),x_j))
&\wedge(\beta_j\vee\neg U(\sigma_q,o_j(a),y_j))\bigr].
\end{split} \tag{20}
\]
与 (11) 相同的证明强制每个 \(\beta_j=\tau_{\sigma_q}(o_j(a))\)，再由 (19) 得到输出恰为 \(b\)。对所有地址共用同一 \(\sigma_q\)，并非逐地址 advice。直接输出位情形可消去 \(\beta_1\)，得到 \(\exists x\forall y\,[(b\wedge U(\sigma_q,o_1(a),x))\vee(\neg b\wedge\neg U(\sigma_q,o_1(a),y))]\)，但一般证明不依赖此简化。

源图费用为共同代码 \(L\)、量词宽度 \(c_o+2c_or\)、两块量词、矩阵
\[
S_{\rm out}\le2c_oA s(h+r+s)+O(m^2). \tag{21}
\]
其展开 gate-list 另按 (15) 计价。若固定并直接展开 \(F_{\sigma_q}\)，专用矩阵还可降为 \(2c_os+O(m^2)\)，但该矩阵的全部描述也必须交付；不能只计一个代码标签。

将 (20) 接入 (13)，总宽度为
\[
Q_{\rm pair}=L+\ell+c_E+1+2c_Er+c_o+2c_or,
\]
至多六块量词，矩阵
\[
S_{\rm pair}\le2(c_E+c_o)A s(h+r+s)+O(m^2), \tag{22}
\]
另有共同源代码 \(\sigma_q\) 的 \(L\) 位 descriptor。外层的求值表代码是另一个量化变量，可以取同一个正确代码作为见证。

因此，在允许正确共同 advice 的非一致存在意义下，W 已经同时提供源图和这次复合的短表示；“再存在一个短源图”不是独立的存在性要求。这里没有声称构造或定位到了正确的 \(\sigma_q\)。若只存在量化一个通过 (10) 的任意代码，再让 H 等于它自己的输出，最终比较成为同义式，完全没有加入 \(BF_0\) 的 lex-first-outsider 条件。所要求的显式源入口仍需由原 source 独立确定／认证这个共同描述，或者由另一条 exact 源关系完成绑定。

### 5.2 从实际 \(B_0\) 硬度推出见证—电路贸易界

令 \(r_{\rm eff}\le r\) 为固定 \(F_{\sigma_q}\) 的输出锥中实际读取的 SAT witness 输入位数。对每个 \(o_j(a)\) 枚举这 \(r_{\rm eff}\) 位并用 OR tree 求出其 SAT 真值；所有副本共享地址电路，最后应用 \(D_{\rm out}\)。因而得到计算 \(B_0\) 的普通电路：
\[
{\rm CC}(B_0)
\le S_o+c_o\bigl[2^{r_{\rm eff}}s+(2^{r_{\rm eff}}-1)\bigr].
\]
结合 (1)：
\[
S_o+c_o\bigl[2^{r_{\rm eff}}(s+1)-1\bigr]>0.1n/q. \tag{23}
\]
因 \(S_o=O(m^2)=o(n/q)\) 且 \(c_o\) 固定，充分大时有
\[
r_{\rm eff}+\log_2(s+1)
\ge q-\log_2q-O(1). \tag{24}
\]
特别地，若 \(s\le m^d\)，
\[
r_{\rm eff}\ge m/C-O_d(\log m). \tag{25}
\]

这是实际固定 hard word 的必要条件，不是泛化到任意输入的难度断言。它排除了 \(s=\operatorname{poly}(m)\) 而有效见证仅 \(O(\log m)\) 的覆盖，也包含无见证普通 evaluator 的失败。Pro 取 \(r=s=m^d\)，与 (25) 相容。故 (24) 不能被改写为 W 的否定。

式 (20) 对 0 位和 1 位都作真值绑定，故其 exact 性及 (24) 不要求改变输出的符号编码。把 W 直接说成给出了 \(B_0\) 的单个 NP 正位电路则需要额外的直接位投影条件；本轮只无条件使用这里已证明的两块量词 exact 图。

## 6. 唯一联合压缩尝试：用同一种矩形 SAT 表提供非循环基源

本轮不另换 source、serializer 或研究路线。具体尝试如下：将第 2 节的机制也用于实际确定性 \(BF_0\) 运行，以它自己的输出建立 (12)，再接到已审查的 membership 表。

为严格限定下面的否定结论，所检验的辅助表示是**完整矩形的逐位二进制地址表**：
\[
z=(t,p,\eta),\qquad
t,p\in\{0,1\}^{b_B},
\]
其中 \(\eta\) 编码有限 cell symbol 的一个位和常数个轨道标签；时间零这一整行的所有 \(2^{b_B}\) 个空间列均为有效单元，包括 blank cells；符号编码区分“有头／状态”和“无头”。这正是普通 full rectangular tableau 的实现。没有另加人为 marker。若把 Pro 的“有效地址”解释为已删除 blank columns 的稀疏命名空间，下面的下界不适用；A2 的宽度声明本身也不能代替该新域的定义和局部正确性证明。本轮不采用这种重编码。

### 6.1 若基表可覆盖，它确会给出非循环的 exact 源关系

令 \(\mathcal M_B\) 是固定的实际 \(BF_0\)（及需要时的固定输出补零）在普通确定性模型中的实现。输入、初始状态全部固定于公开基参数，不含未知 seed。采用固定单带模拟、常数指数的时钟余量及停机后自环，可令
\[
\widehat T_B=2^{\kappa n+O(\log n)},\qquad
b_B=\lceil\log_2\widehat T_B\rceil+O(1)=\Theta(n), \tag{26}
\]
其中 \(\kappa\) 固定。这只是给 published \(T_0=2^{cn}\) 运行的普通 tableau 留足空间，不改变其输出。

表位地址和检查编号必须有
\[
h_B=2b_B+O(1)=\Theta(n),\qquad
\ell_B=2b_B+O(1)=\Theta(n). \tag{27}
\]
源版 Local 要求这张唯一确定运行表合法，并在一个特定检查中读取最终第 \(a\) 个输出位，与自由输入 \(b\) 比较；\(a\ge2n\) 时检查 \(b=0\)。查询地址、最终时间和输出位置均在已付费的 \(b_B\)-bit 算术中处理。

对表代码预算 \(s_B\)、见证宽度 \(r_B\)，采用 (6) 的同一门表格式：
\[
\begin{aligned}
\lambda_B&=\lceil\log_2(h_B+r_B+s_B+2)\rceil,\\
L_B&=s_B(3+2\lambda_B)+\lambda_B .
\end{aligned}
\]
其源图 \(H_B(a,b)\) 的前束为
\[
\exists\sigma_B^{L_B}\ \forall\xi_B^{\ell_B}\
\exists(\mathbf b_B^{c_B},\mathbf x_B^{c_Br_B})\
\forall\mathbf y_B^{c_Br_B}. \tag{28}
\]
矩阵就是源版 Code、Local、Truth；输出读数占用的额外常数槽吸收到固定 \(c_B\)。

若真实基表被某代码覆盖，则第 2 节的证明保证 (28) 是 exact 源图。不同地址使用的成功代码即使不同，因源运行确定，输出都必为同一 \(B_0\)，不存在 seed 选择造成的源漂移。这个入口不查询第一 JK block。

其全部费用为
\[
\begin{aligned}
P_B&=L_B+\ell_B+c_B+2c_Br_B,\\
S_B&\le2c_BA_Bs_B(h_B+r_B+s_B)+O(b_B^2+m^2),
\end{aligned} \tag{29}
\]
四块量词，外加由 \(P_B,S_B\) 给出的完整 gate-list／输入布局编码。接入 (13) 后至多八块量词，总宽度
\[
L+\ell+c_E+1+2c_Er+P_B,
\]
总矩阵
\[
2c_E A s(h+r+s)+S_B+O(m^2). \tag{30}
\]
这说明真实基表覆盖若成立，确是所需的一次具体源到 membership 复合，而非孤立的检查语言。

### 6.2 实际时间零配置已经否定其地址尺度覆盖

**引理（SAT 语义不能恢复未读取的地址变量）。** 若一个 fan-in-two 电路 \(F(z,w)\) 的输出锥不读取某个地址位 \(z_j\)，则
\[
z\longmapsto\exists w\,F(z,w)
\]
也不依赖 \(z_j\)。一个 \(s\) 门单输出电路至多读取 \(2s+1\) 个不同的地址输入位。

证明：固定其他输入，翻转 \(z_j\) 不改变任何门值，所以每个 \(w\) 的接受值均不变；存在量词不能制造该依赖。每门至多两个输入端口，另允许输出直接引用一个输入，得到 \(2s+1\) 上界。此处只需这个宽松界。

**实际基表的推论。** 时间零只有一个读写头，设其固定位置为 \(p_\star\)。对空间地址每一位 \(j\)，令
\[
p^{(j)}=p_\star\mathbin{\oplus}2^j,\qquad 0\le j<b_B.
\]
这些都是同一完整矩形初始行中的有效单元。\(p_\star\) 的符号包含头／状态，\(p^{(j)}\) 的符号不包含，故两者的固定二进制符号编码至少有一位不同。设该符号位为 \(\eta_j\)。表位地址
\[
(0,p_\star,\eta_j),\qquad(0,p^{(j)},\eta_j)
\]
只相差空间输入位 \(j\)，而真实表值不同。因此覆盖这张表的 \(F_{\sigma_B}\) 必须读取每个空间地址变量 \(p_j\)。

于是无论 witness 宽度多大，
\[
2s_B+1\ge b_B,\qquad
s_B\ge(b_B-1)/2=\Omega(n)=\Omega(2^{m/C}). \tag{31}
\]
这里没有假设存在额外的“头标志位”：若头／状态通过数个 symbol bits 编码，两个完整符号不同就足以找到上面的 \(\eta_j\)。所用配置是该固定源真实可达的时间零配置，不是合成困难输入或假想答案向量。

因此，对任意固定 \(d\)，取 \(s_B=m^d\) 都不可能覆盖充分大实际基点的该基源表。设短代码描述了少数输入位置也不能绕过 (31)：在短代码尝试下 \(\lambda_B=\Theta(\log n)=\Theta(m)\)，\(L_B=O(m^{d+1})\) 的确仍可为多项式，但电路读不到其必须区分的全部 \(b_B\) 个空间位。

一旦真正覆盖，(31) 和门表格式又强制
\[
\lambda_B=\Omega(\log n),\qquad
L_B=\Omega(n\log n),\qquad
P_B\ge L_B+\ell_B=\Omega(n\log n). \tag{32}
\]
在 Pro 的 \(r_B=s_B\) 约定下，SAT witness 宽度本身也至少 \(\Omega(n)\)。局部地址运算的通用上界是 \(O(b_B^2)=O(n^2)\)，不能继续记成 \(O(m^2)\)；普通 universal-evaluation 矩阵必须按 (29) 展开。式 (29) 是上界公式，不能反过来当作 \(\Omega(n^2)\) 的矩阵下界。已证明的超预算下界是 (31)、(32) 及实际 \(\ell_B=\Theta(n)\)。

即使只看量词，(27) 已足以否定这次字面编译的地址尺度账目；(31) 更进一步，说明把检查地址费用暂时搁置也不存在所要求的 \(m^d\)-gate SAT 表代码。没有证明 \(s_B=\Theta(n)\) 就足以覆盖整个运行；后续真实计算还可能要求更大描述。

### 6.3 这个实际反例的严格范围

被否定的是：**用上述完整矩形表同时覆盖真实 \(BF_0\)，以此提供 exact 源入口，再用 Pro 编译器做 membership 复合。** 该入口在实际时间零已经失败，不必计算 \(B_0\) 或运行 brute force。

Pro 的 W 只要求 \(\mathcal M\) 对 \(G_N\) 的 \(\operatorname{poly}(N)\)-time 求值表。那一侧的空间地址只有 \(\Theta(m)\) 位，同一头位置论证只给 \(s=\Omega(m)\)，与某个固定多项式预算相容。因此 (31) 不是 W 的反例。它也没有否定原前驱关系的整体非字面消去、另一种源关系、或不同的已明确计价的辅助表命名方式。published PCP/JK 的 serializer 始终未改动。

## 7. 最强未闭合引理与停止位置

在固定的 \(\mathcal M\)、表域和原输出解码约定下，尚未解决的实际覆盖内容可以直接写为：
\[
\begin{split}
\exists d,q_\star\ \forall q\ge q_\star\text{ actual}\ 
\exists u\in\{0,1\}^{N}\ \exists\sigma\in\{0,1\}^{L(m,m^d)}:\qquad&\\[-2mm]
G_N(u)=B_00^{2N-2n},\quad {\sf Code}(\sigma),\quad
|F_\sigma|\le m^d,\qquad&\\
\forall z\in\mathcal D_m:\ 
\operatorname{Tab}_{\mathcal M}(N,u)[z]=1
\iff\exists w^{m^d}F_\sigma(z,w)=1.&
\end{split} \tag{33}
\]
式 (33) 中长 \(u\) 仅用于陈述数学覆盖命题；它不曾在短编译公式 (13) 中免费出现。若把 (33) 自身当作候选地址尺度公式，则必须支付 \(|u|=N\)，又会退回 object scale。

第 5 节证明 (33) 蕴含短共同源图的非一致存在，给出 (20)–(22) 的明确成本；也证明任何该覆盖都需满足 (24)。第 6 节排除了用真实 \(BF_0\) 的完整矩形表来无条件建立这个源入口。剩余的显式 R2 工作是为同一个实际族证明 (33)，并从原源独立定位／认证正确的共同描述，或提供一条不经被排除基表的 exact、完整计价源关系。任意有效求值表的输出自绑定不能替代这一步。若题设允许不另付生成时间的正确非一致 advice，须明确声明该量词；即使如此，(33) 的存在性本身仍未证明。

对 A7/A9 未发现全局一致性或量词交换造成的假阳性；需要补全的表编码细节已在第 2 节明列。序列化方面仍只使用题设的固定 binary prefix，不把原文的抽象 systematic 断言扩大成唯一 binary serialization。A9 的语义准确表述是 (14)，不能先于 W 宣称它已完整决定实际 membership。

这次停止于已证明的实际矩形基表边界和未闭合的 (33)。没有可廉价执行、又能决定 (33) 的剩余有限检查；枚举全部预算内代码、构造实际长表或穷举 SAT 语义并不属于轻量计算。没有开展这些计算，没有进入 R3，也没有作复杂度类分离断言。仅新增本 scratch 文件；既有文件、tracked files、远程状态和 pending Pro 会话均不改动。
