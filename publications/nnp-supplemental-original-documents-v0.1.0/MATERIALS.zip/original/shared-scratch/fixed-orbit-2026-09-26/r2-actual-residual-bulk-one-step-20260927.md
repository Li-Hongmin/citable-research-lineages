# 冻结 R2：实际首批剩余块的整体关系与一次 JK 复合

2026-09-27。仅为本次有限脉冲的 scratch 推导。

**裁决：严格的源绑定归约成立；地址尺度的 R2 gate 仍为 UNKNOWN。** 对同一实际 \(BF_0\) 及固定 PCP completeness constructor，可以不把 PCP 串、answer vector 或原像列表作为免费 payload，写出首批剩余块的 exact 整体 YES 关系，并与 JK 在全 YES 分支所选的 lex-first 原像做一次真实的、带可达 guard 的复合。该直接关系的首批块编号需 \(\Theta(n)\) 位，下一步仍量化 \(N\)-bit 原像，展开固定构造的矩阵有 \(T_0^{O(1)}\) 门；它没有达到 \(m^{O(1)}\) 的 R2 预算。原文没有给出使这些费用整体消失的结构定理，本次也没有得到实际剩余块的 NOGO 反例。

本地证据：项目 [AGENTS.md](../../AGENTS.md) 与 [README](../../README.md)、[冻结 SPEC](../../units/rw-jk-succinct-reconstruction/SPEC-2026-09-23-fixed-orbit.md)、[上一轮 W 裁决](r2-cover-collapse-check-20260927.md)、[新 Pro 整页候选](pro-independent-collapse-page-20260927.txt)，以及 [Ren–Williams 本地原文，ECCC TR26-118 revision 1]([unmapped-local-locator])。已读本地 Drive 工作区权威 README；没有同步。整页中最新的实质性 Pro 答复独立确认的是 W 与 \(NP\subseteq P/\mathrm{poly}\) 的条件冲突及更弱输出切片的同一冲突；末端另附本轮残余块委托，没有一项关于残余块的已证结构。以下不重复该条件证明，也不把 Pro 文本晋级为原始来源。

## 1. 同一实际串和首批边界

固定原文 Theorem 4.3 的常数 \(C>D+1,c\ge1\)，令
\[
 \mathcal A_C=\{q\in\mathbb N:C\nmid q\},\qquad
 n=2^q,\quad N=n^C=2^m,\quad m=Cq,\quad T_0=2^{cn}.
 \tag{1}
\]
\(q\) 限于充分大的实际起点。\(G_n,G_N\) 始终是原文 1151–1166 行指定的同一 truth-table-generator 家族，不更换 decoder。令 \(B_q\) 为 \(BF_0\) 对 \(G_n\) 输出的 lex-first outsider（Theorem 4.3，1040–1060 行）。按原 Lemma 3.2 的 raw-history 顺序（580–616 行），基阶段 \(r_0=s_0=0\) 使 out 字段恰为
\[
 f_0=B_q0^{T_0-2n}.
 \tag{2}
\]
原文 encoded-history 段（785–796 行）及 Theorems 3.4–3.5（749–847 行）给出 systematic prefix 和确定性 completeness 构造。下面使用题设已冻结的 raw-binary-prefix 坐标，而不从抽象 field-code systematic 性质另造二进制顺序。

固定**同一个**满足原文 completeness 的确定性 constructor \(K\) 与 JK 的固定 tie-break。\(r_0=s_0=0\) 意味着 \(BF_0\) 运行不需 oracle witnesses；给定公开基点，raw assignment 的 out 由 (2) 固定，电路 \(C_{x_0}\) 的 gate values 随之唯一。以这些完整 gate values 输入 \(K\)，得到此轮实际的 PCP 字符串 \(\Pi_q\)。\(K\) 在原文中作为固定算法的存在性接口给出，逐位 gate order 与无效编码并未在本地全文中唯一列成字节程序；下列结论对题设一经固定的同一 \(K\) 参数化成立，不替它选一个有利的新序列化。

令 \(P_q=|\Pi_q|\)。Theorem 3.4–3.5 给出 \(P_q\le T_0^A\) 对某个统一常数 \(A\)。完整 witness 除长度 \(T_0\) 的 out assignment 外还包含 \(C_{x_0}\) 的中间门值；该多输入验证电路必有门，所以 systematic proof 实际满足 \(P_q>T_0\)。在 Theorem 3.1（498–548 行）的首次 stage，把 \(\Pi_q\) 尾部补零至
\[
 \widehat P_q=N2^{k_q},\quad
 k_q=\lceil\log_2(P_q/N)\rceil,\quad
 J_q=\widehat P_q/(2N)=2^{k_q-1}.
 \tag{3}
\]
对充分大 \(q\)，\(k_q\ge1\)；以零起始编号定义首批真实块
\[
 X_{q,j}=\bigl(\Pi_q0^{\widehat P_q-P_q}\bigr)[2Nj:2N(j+1)],
 \qquad 0\le j<J_q.
 \tag{4}
\]
这与原文 JK 初始分块一一对应，不把 proof 的其他部分当作任意 batch。令
\[
 Q_q=\lfloor T_0/(2N)\rfloor,\qquad b_q=\log_2J_q.
 \tag{5}
\]
由 \(N\le T_0\)、\(T_0<P_q\le T_0^A\) 得
\[
 0<Q_q<J_q,\qquad \log_2Q_q=\Theta(n),\qquad b_q=\Theta(n).
 \tag{6}
\]
公开整数 \(Q_q,J_q\) 的二进制表示及其比较器若写进显式关系，各付 \(O(b_q)\) 位／门；\(b_q=\Theta(2^{m/C})\)，不是地址尺度。若实际 \(T_0\) 被选成可被 \(2N\) 整除的二次幂，则 floor 多余；保留它不改变证明。

由 (2) 和冻结前缀，\(X_{q,0}=B_q0^{2N-2n}\)，\(X_{q,j}=0^{2N}\) 对 \(1\le j<Q_q\)。原文 truth-table-generator 的渐近覆盖在充分大实际基点使这些块均在 \(\operatorname{Range}(G_N)\) 中；这个数学层面的结论不是某个逐位 seed 证书。记
\[
 I_{q,j}=\mathbf1[X_{q,j}\in\operatorname{Range}(G_N)].
\]
则 \(I_{q,j}=1\) 对所有 \(j<Q_q\)。首批仍照原程序发出全部查询；可证明的仅是这些实际答案的值，不是其余答案，更不是全 YES。对剩余段，首批 guard 与第一轮 raw-history count 的精确语义为
\[
 A_q:=\bigwedge_{Q_q\le j<J_q}I_{q,j},\qquad
 c_q=Q_q+\sum_{Q_q\le j<J_q}I_{q,j}.
 \tag{7}
\]
\(A_q\) 等价于整个首批全 YES，且 \(c_q\in[0,J_q]\) 的定宽编码长 \(b_q+1=\Theta(n)\)。式 (7) 是数学定义；求和符号尚不是免费 \(\#\) gate 或一份短关系。

## 2. 无免费 payload 的精确首批整体关系

存在一个统一的确定性程序 \(\mathscr P\)：给定公开 \(q\)，按原 \(BF_0\) 枚举同一 \(G_n\) 的 range 得到 \(B_q\)，构造原 \(C_{x_0}\) 和其完整 gate-value witness，运行同一 \(K\) 得 \(\Pi_q\)，最后按 (3) 补零。原文给出的 \(BF_0\) 时间 \(T_0\)、Theorems 3.4–3.5 的 \(\operatorname{poly}(T_0)\) 完整 witness/proof 成本和 Theorem 4.1（约 883–905 行）的调用，合起来给一个跨 \(q\) 固定的 \(A_1\) 使该程序时间、输出及所需空间均 \(\le T_0^{A_1}\)。这不需要在实际机器上运行它。

用常规确定性时间到普通电路的展开，为有效 \(j<J_q\) 和 \(a<2N\) 建立同一 bit 电路 \(D_q(j,a)\)，其值为 \(X_{q,j}[a]\)。无效坐标统一总化。令
\[
 g_N=|G_N|\le N^4,\quad
 S_{\rm bit}(q)=|D_q|\le T_0^{A_2},\quad
 S_{\rm blk}(q)\le2N\bigl(S_{\rm bit}(q)+O(b_q+m)\bigr)
 \le T_0^{A_3}.
 \tag{8}
\]
这里 \(S_{\rm blk}\) 是并列产生 \(X_{q,j}\) 全部 \(2N\) 位的普通门数。\(A_2,A_3\) 均是固定常数。算法／电路展开需要 \(T_0^{O(1)}\) 生成时间；完整门表及输入布局长度为
\[
 O\bigl((S_{\rm blk}+b_q+N)\log(S_{\rm blk}+b_q+N+2)\bigr)
 =T_0^{O(1)}.
 \tag{9}
\]
\(D_q\) 在内部计算 \(B_q\) 和 \(\Pi_q\)，故 (8) 不是把其 \(2n\) 位或整个 PCP proof 免费硬接成 advice。固定短程序名也不能代替 (8)–(9) 的显式门成本。

从 (7) 消去**显式列出的**全部首批原像／答案向量，得到三块量词的 exact 关系
\[
 \mathsf{All}_q:
 \quad \forall j\in\{0,1\}^{b_q}\ \exists u\in\{0,1\}^{N}:
 \bigl[j<Q_q\ \lor\ G_N(u)=X_{q,j}\bigr].
 \tag{10}
\]
\(J_q=2^{b_q}\) 使量词域恰好是全部首批块。前 \(Q_q\) 项由已证 YES 关闭；其他项逐一是同一 \(G_N\) 的真实 range membership。因此
\[
 \mathsf{All}_q\iff A_q\iff \text{原 JK 首阶段所有 membership 查询均为 YES}.
 \tag{11}
\]
式 (10) 不携带 \(\Pi_q\)、\(J_q-Q_q\) 个答案位或一个原像列表的未计价 descriptor。它仍有 \(b_q+N\) 个量词位；\(\forall j\exists u\) **没有在语义上消灭每个 YES 块的原像义务**，只是以一个整体量词关系表示全部义务。普通矩阵上界是
\[
 S_{\rm All}\le S_{\rm blk}+g_N+O(N+b_q),
 \tag{12}
\]
其显式门表按 (9) 同样付费。给定 \(q\) 的均匀公式生成时间 \(T_0^{O(1)}\)，并未达到 \(m^{O(1)}\)。

首批第一个残余块 \(j=Q_q\) 确属原 JK 首阶段的实际查询，不需假设 \(A_q\)。其两个答案的 exact 图可写为
\[
 \mathsf{Ans}_q(j,\beta):=
 \exists u^N\ \forall v^N:
 [\beta=1\land G_N(u)=X_{q,j}]
 \lor[\beta=0\land G_N(v)\ne X_{q,j}].
 \tag{13}
\]
对 \(Q_q\le j<J_q\) 它恰给出实际答案；\(j\) 本身要 \(b_q=\Theta(n)\) 位。如果把 \(j=Q_q\) 固定，则其 \(b_q\) 位常量仍须进入门表。式 (13) 的两个量词块共 \(2N\) 位，矩阵 \(\le S_{\rm blk}+2g_N+O(N+b_q)\) 门，完整描述按 (9) 计。这是实际 source 到第一残余查询的一步精确复合；没有声称可廉价求出答案。

## 3. 同一 PCP 串下与 canonical inverse 的一次复合

若且仅若 \(\mathsf{All}_q\) 真，原 Theorem 3.1 才在首阶段对每个块恢复 lexicographically smallest 的 \(N\)-bit 原像。定义
\[
 U_{q,j}=\min_{\rm lex}\{u\in\{0,1\}^{N}:G_N(u)=X_{q,j}\},
 \qquad 0\le j<J_q,
 \tag{14}
\]
只在全 YES 分支上使用。原文的并行 prefix-search（约 523–545 行）确实选这些**最小 seed**，不是任选满足见证。第一轮后的实际字符串是 \(U_{q,0}\cdots U_{q,J_q-1}\)；因此下一 JK stage 的第 \(k\) 个 \(2N\)-bit 块是
\[
 Y_{q,k}=U_{q,2k}\,U_{q,2k+1},\qquad 0\le k<J_q/2.
 \tag{15}
\]
这一步既不替换 PCP，也不假定其余初始块全 YES；公式会保留实际控制 guard。

对一段 \(X\in\{0,1\}^{2N}\)，写
\[
 \operatorname{Min}(u,X;w):=
 [G_N(u)=X]\land[w\ge_{\rm lex}u\ \lor\ G_N(w)\ne X].
 \tag{16}
\]
\(\forall w^N\operatorname{Min}(u,X;w)\) 当且仅当 \(u\) 是 \(X\) 的最小原像。对有效 \(k\in\{0,1\}^{b_q-1}\)、答案位 \(\beta\)，下面是无外部 proof、无 answer-vector payload 的实际**带 guard 下一查询**关系：
\[
\begin{aligned}
 \mathsf{NextAns}_q(k,\beta):=
 \exists U_0^N,U_1^N\ \forall j^{b_q},w_0^N,w_1^N,v^N\
 \exists u^N,z^N:\quad
 &[j<Q_q\lor G_N(u)=X_{q,j}]\\
 {}\land{}&\operatorname{Min}(U_0,X_{q,2k};w_0)
 \land\operatorname{Min}(U_1,X_{q,2k+1};w_1)\\
 {}\land{}&\bigl[(\beta=1\land G_N(z)=U_0U_1)
 \lor(\beta=0\land G_N(v)\ne U_0U_1)\bigr].
\end{aligned}
 \tag{17}
\]
对每个实际基点及有效 \(k\)：
\[
 \mathsf{NextAns}_q(k,\beta)
 \iff
 A_q\land[\beta=\mathbf1\{Y_{q,k}\in\operatorname{Range}(G_N)\}].
 \tag{18}
\]
证明：第一行按 (10) 强制首批全 YES。两条 \(\operatorname{Min}\) 中的正像条件与分别对所有 \(w_0,w_1\) 的挑战，强制 \(U_0=U_{q,2k}\)、\(U_1=U_{q,2k+1}\)；它们对 \(j\) 的允许依赖实际上由唯一性消去。\(\beta=1\) 时存在 \(z\) 恰是下一块的原像；\(\beta=0\) 时全称 \(v\) 排除全部原像。额外的 dummy 依赖不改变真假，因为其余子式不含这些变量且域非空。反向按真实最小原像和各查询的真值逐个选择量词策略。若 \(A_q\) 假，(17) 对两种 \(\beta\) 都假，准确表示原程序在该阶段没有下一查询；没有把未发生的 stage 当成实际运行。

(17) 的量词块依次为 \(2N\)、\(b_q+3N\)、\(2N\) 位，合计
\[
 P_{\rm Next}=7N+b_q.
 \tag{19}
\]
它的普通矩阵可用 \(X_{q,j},X_{q,2k},X_{q,2k+1}\) 三份块电路、至多七份 \(G_N\) 电路及线性比较／连接电路，因此
\[
 S_{\rm Next}\le3S_{\rm blk}+7g_N+O(N+b_q),
 \tag{20}
\]
完整 gate-list、输入布局、\(Q_q,J_q\) 常量仍需
\[
 O\bigl((S_{\rm Next}+P_{\rm Next}+b_q)
       \log(S_{\rm Next}+P_{\rm Next}+b_q+2)\bigr)
 =T_0^{O(1)}
 \tag{21}
\]
位，统一生成时间 \(T_0^{O(1)}\)。同一个 \(D_q\)、同一组公开长度和同一 \(\Pi_q\) 贯穿 (10)、(13)、(17)；没有给两次查询分别选 proof。\(k\) 的显式输入也要 \(b_q-1=\Theta(n)\) 位。(17) 因而是一项已证明的 actual-source 一步**语义复合**，但不是 address-scale normal form。

## 4. Count 与地址尺度的确切缺口

式 (10) 只给 \(c_q=J_q\) 的判定；它不能产生 \(c_q\) 的全部 \(b_q+1\) 位。若为 (7) 的每个 membership 另存一位或一个 seed，分别需 \(J_q-Q_q\) 位或 \((J_q-Q_q)N\) 位，均是禁用的 payload。若把 \(\#\{j:I_{q,j}=1\}\) 当作矩阵原语，也未完成普通电路计价。

一个完全展开、仍无外部 payload 的保守基线是：对每个剩余 \(j\) 生成 \(X_{q,j}\)，对全部 \(2^N\) 个 seed 显式求 \(G_N(u)=X_{q,j}\) 并 OR，最后用普通加法器累加。它的 count-bit 电路门数最多
\[
 O\bigl(J_q S_{\rm blk}
 +J_q2^N(g_N+N)
 +J_q(b_q+1)\bigr),
 \tag{22}
\]
门表另乘相应 \(O(\log(\text{门数}+2))\) 编码因子；生成时间至少按输出规模支付。本次**没有**构造或运行这个巨大电路。(22) 只是说明 count 可在完全计价后有限化，绝不能由此声称 \(m^{O(1)}\) 闭合。

真正有用的 count 图只以 \(a\) 寻址 \(c_q\) 的位：由于 \(|c_q|=b_q+1=\Theta(n)\)，其位地址宽度 \(\lceil\log_2(b_q+1)\rceil=O(m)\)。本轮最先缺少的源专属引理可以精确写成：一个固定量词模板的普通矩阵、全部量词位、显式 gate-list／输入布局及**给定共同 advice 后**的生成费用均 \(\le m^d\)，并满足
\[
 \exists d\ge1\ \exists q_\star\ \forall q\in\mathcal A_C,\ q\ge q_\star\
 \exists\delta_q\in\{0,1\}^{\le m^d}\
 \forall a< b_q+1\;\forall\beta\in\{0,1\}:\quad
 R_{\delta_q}(a,\beta)
 \iff \operatorname{bit}_a\!\left(
 Q_q+\sum_{Q_q\le j<J_q}
 \mathbf1[\exists u^N:G_N(u)=X_{q,j}]
 \right)=\beta.
 \tag{23}
\]
其中 \(X_{q,j}\) 必须由同一 \(BF_0\to C_{x_0}\to K\) 源确定；\(R\) 不得读取一个未计价的 \(\Pi_q\)、answer vector、\(B_q\) ROM 或 \(\#\) gate。\(Q_q,J_q\) 的字面二进制常量各有 \(\Theta(n)\) 位；若 \(R\) 使用它们，也须在同一预算内给出真正更短的控制，而不能把这些常量当成免费参数。\(\delta_q\) 可为正确的非一致 advice，(23) 不额外要求高效找到它，但其长度和关系展开都必须付费，正确性也须有独立的源依据。式 (23) 是**待证接口的量词与预算**，不是本次证明。即使 (23) 成立，它只控制首批 count；再接到 (15) 的 canonical inverse 和下一 count，还须证明短表示在这一真实更新下保持共同描述，不能仅因 \(A_q\) 的真假已知就宣称 closure。

这里可利用的 actual-source 特殊性确实比任意 batch 多：确定性 \(BF_0\) 固定同一个 lex-first \(B_q\)；零前缀块已证 YES；完整 witness 的 gate values 由该 out 唯一确定；固定 \(K\) 使余下 proof 串同源；全 YES 时 JK 用 lex-first 原像，下一块按 (15) 精确相邻配对。这些事实已用于 (10) 和 (17)。但原始定理对余下 gate-value／辅助 PCP 位只给 \(\operatorname{poly}(T_0)\) 的构造界，未给 \(m^{O(1)}\) 的随机访问或全局 count 关系；而 \(b_q=\Theta(n)\) 的 literal block index 与 \(N\)-bit seed 在所写公式中均超预算。把短 hard-output SAT 表 W 放在源端会再次引入上一轮已知足以推出 \(NP\not\subseteq P/\mathrm{poly}\) 的强假设，不能当作这一步的便宜实现。

**停止边界：UNKNOWN。** 已获得精确的 payload-free 关系 (10)、实际残余查询图 (13)、以及与同一首批全 YES 分支的一步 canonical-inverse 复合 (17)，并支付 (8)–(9)、(12)、(19)–(22) 的全部直接费用。没有证明 (23)，也没有证明其否定；未确定余下首批答案、\(A_q\) 的实际真假或下一 stage 是否在该基点发生。原文没有提供另一项轻量、可直接区分 (23) 的 bitwise 残余结构观察；穷举剩余块、运行 \(BF_0/K\) 或枚举 range 均不属本轮。字面展开超预算只关闭该展开，不是 fixed-orbit R2 的无条件 NOGO。不切 R3，不写永久 note，不修改 SPEC 或已有文件。
