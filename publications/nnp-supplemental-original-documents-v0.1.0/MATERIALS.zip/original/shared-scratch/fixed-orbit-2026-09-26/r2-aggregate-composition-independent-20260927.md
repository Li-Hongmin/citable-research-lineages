# 冻结 R2：聚合公式与带标签前缀复合的独立核验

2026-09-27。保持同一实际 \(K\)、PCP/JK serialization、\(G_N\) 及冻结 SPEC。

**裁决：Pro 的最高位 guard 和两轮 prefix 聚合恒等式成立，按实际 dummy 坐标解释时与 RW 一致；地址尺度 R2 仍为 UNKNOWN。** 本轮另给出一个完全计价的两块量词关系：共用一组带标签的最小首 chunk 证书，精确表示前两个实际 prefix 轮次的答案与 count，无需把 \(2^{2h}\) 个聚合单元或一个先算好的前缀向量当作输入。它仍支付 object-scale 量词数组，没有改变最早的 source-specific 聚合压缩缺口。另须区分：在已允许的共同非一致 advice 模型里，初始 guard 的**单独表示**只需一位；这不证明实际全 YES，也不补出任何分支的 count。

本地依据：项目 AGENTS、README、冻结 SPEC、[上一份本地推导](r2-function-semantics-layout-dependency-20260927.md)、[Pro 候选全文](pro-aggregate-compatibility-20260927.txt)，以及 [RW 原文]([unmapped-local-locator]) 512–550、595–657、883–912、1040–1085 行。处理外部候选前已读 Drive 工作区权威 README，没有同步。Pro 文件最初只有来源行，后补入了全文；本轮核对的是其中 4991–7124 行的已完成答复，不采用末尾尚在进行的 guard 挑战。文献范围截止本日这些本地来源，不访问远程。

## 1. 对 Pro 公式的源核验

沿用 \(n=2^q\)、\(N=n^C=2^m\)、\(T_0=2^{cn}\)。设实际 proof 长度为 \(P\)，补零后的首批块数为 \(J=2^\lambda\)，实际块为 \(X_j\)，\(j<J\)。本文的 \(\lambda\) 对应上一份 scratch 的 \(b_q\)；\(h=\lceil\log_2(P|G_N|)\rceil\) 表示 Pro 的 chunk 宽度 \(b_q\)。令 \(c_0\) 为首批 membership YES 数，\(A\) 为首批全 YES 事件。

原文 516–524 行先查询全部 membership；只有全部 YES 才进入 prefix search。535–540 行对每个块标签 \(j\) 查询全部候选 chunk，然后**在该标签内**选 lex-first；542–543 行最终按原标签顺序连接原像。因此 Pro §3.3 的“一次复合”是第一到第二个 **prefix 轮次**，还不是相邻原像拼接之后的下一 JK stage。

| Pro 公式 | 独立核验与准确范围 |
|---|---|
| (3)，原 count 字段的一位 guard | 正确。若字段宽 \(w\ge\lambda+1\)、MSB 在前且地址从 0 起，则所读位置是 \(a^*=w-1-\lambda\)。由 \(0\le c_0\le2^\lambda\)，该位为 1 当且仅当 \(c_0=J\)。这不是原字段有前导零时的最左一位。 |
| (8)–(10)，前缀像集的聚合 | 正确。一个块可能属于多个前缀像集，这些对应不同的实际查询；membership count 对其只计一次。因此首轮 prefix count 的和允许重叠，空前缀的并集计数必须保留交项。 |
| (11)–(12)，有序差集 \(D_\alpha\) | 正确。\(D_\alpha\) 是可由 \(\alpha\) 延伸、而不能由更小首 chunk 延伸的块集合。对每个原标签 \(j\)，\(X_j\in D_\alpha\) 才是它选中 \(\alpha\) 的判据；\(\mu(D_\alpha)\) 只给选择频数。 |
| (13)–(14)，第二个 prefix 轮次 | 正确。每个实际 YES 块属于唯一一个 \(D_\alpha\)，所以 \(\sum_{\alpha,t}\mu(D_\alpha\cap R_{\alpha t})\) 恰好统计该块在已选 \(\alpha\) 下的全部 \(t\) 查询。它给出 count，不自动产生带标签的选择器。 |
| guard 为假时的解释 | 正确。Pro 没有把上述代数和赋给未执行的 history 轮次。守卫关系此时应对两个候选输出位都为假，不能擅自解释为“实际 count 等于 0”。 |

这些核验只使用同一实际块，不用另一个 batch 来展示不同频数或不同后继。

有两处表示细节需收紧。第一，Pro 用 \(2h\le N\) 排除前两轮接触“末尾 dummy 位”。规模不等式成立：\(h=\Theta(n)\)、\(N=n^C\)，故充分大时 \(2h<N\)。但 RW 532–533 行只说加入 dummy variables，没有明写其坐标位置。若同一实际实现确实在末尾添加，Pro 的未补齐 seed 公式原样成立；本轮不补选这一约定，而在下面保留原删除映射。

第二，\(w,\lambda,h\) 的**数值**为 \(\Theta(n)\)，其二进制表示只有 \(O(m)\) 位；\(P\) 本身的二进制长度却是 \(\Theta(n)\)。Pro 在 guard 成本段将 \(P,k,w\) 一并称为“描述短”不能按字面接受。所需 guard 地址只使用 \(w,\lambda\)，不需要把 \(P\) 作为短常量加入矩阵；从源生成正确参数仍须另行计费。这不影响单比特恒等式。

Lemma 3.2 的 lex-largest **history witness** 与 Theorem 3.1 的逐块 lex-smallest **generator seed** 也不能互换。前者通过 sound witness arrays 与正确 count 迫使真实答案；它没有把频数自动变成后者的带标签输入。已有 [Note 610 §2](../../units/mcsp-hardness-magnification/notes/610-published-rw-canonical-prefixes-are-batch-count-vectors-without-count-state-closure-2026-08-28.md) 的饱和 count replay 正是这个 object-scale 事实，本轮不把它再记作新短归约。

## 2. 新的有限归约：两轮 prefix count 共用一组带标签证书

以下把 Pro 的第二轮有序差集计数落实成一个普通 Boolean 量词关系。它消去的是字面的 \((\alpha,t)\) 双重聚合输入，保留原块标签；不声称已经完成地址压缩。

令 \(L=h\lceil N/h\rceil\le2N\)，\(\rho:\{0,1\}^L\to\{0,1\}^N\) 为同一 JK 实现删除 dummy 坐标的投影，写
\[
 \widehat G(u):=G_N(\rho(u)),\qquad \pi_r(u):=u[0:r].
 \tag{1}
\]
\(\widehat G\) 只是原程序已有 dummy 变量的记号，没有更换 \(G_N\) 或其 range。以下所有前缀均是实际 padded 变量顺序上的前缀，因而不需要推测 dummy 位置。记 \(H=2^h\)，\(g=|G_N|\)。

给定同一固定源和 constructor 的程序，可如上一份 scratch 展开普通块电路 \(\mathcal X_q(j)=X_j\)，门数 \(S_X\le T_0^{A_0}\)。这里没有一个免费 \(X_j\) oracle；该展开及其生成费用在本节末计入。

对一个候选 seed \(U_j\in\{0,1\}^{L}\) 定义
\[
\begin{aligned}
 B(j,U_j,v):={}&[\widehat G(U_j)=\mathcal X_q(j)]\\
 &{}\land[\pi_h(v)\ge_{\rm lex}\pi_h(U_j)
               \ \lor\ \widehat G(v)\ne\mathcal X_q(j)].
\end{aligned}
 \tag{2}
\]
则 \(\forall v^L B(j,U_j,v)\) 当且仅当 \(U_j\) 是一个真实原像，且其首 chunk
\(\alpha_j=\pi_h(U_j)\) 是该标签的最小可延伸首 chunk。

**关键区别。** (2) 不要求 \(U_j\) 的剩余位也最小；它们只作 \(\alpha_j\) 可延伸的证书，不交给原程序作为最终 seed。这恰好满足前两轮的依赖，不改选原 JK 的完整 lex-first seed。

对轮次模式 \(r\in\{1,2\}\)，候选 \(t\in\{0,1\}^h\)，定义普通检查
\[
 M_r(j,U_j,t,z):=[\widehat G(z)=\mathcal X_q(j)]\land
 \begin{cases}
  [\pi_h(z)=t],&r=1,\\
  [\pi_{2h}(z)=\pi_h(U_j)t],&r=2.
 \end{cases}
 \tag{3}
\]
模式选择用 Boolean mux 实现。令 \(U=(U_j)_{j<J}\)，\(e=(e_{j,t})_{j<J,t<H}\)，\(Z=(Z_{j,t})\)，其中 \(e_{j,t}\) 为一位，\(U_j,Z_{j,t}\) 各长 \(L\)。定义
\[
\begin{aligned}
 \mathsf{PC}_q(r,a,\eta):\quad
 \exists U^{JL},e^{JH},Z^{JHL}\;
 \forall j^\lambda,t^h,v^L,z^L:\quad
 & B(j,U_j,v)\\
 {}\land{}&\bigl[(e_{j,t}\land M_r(j,U_j,t,Z_{j,t}))\\
 &\qquad\lor(\neg e_{j,t}\land\neg M_r(j,U_j,t,z))\bigr]\\
 {}\land{}&\left[\operatorname{bit}_a
                  \left(\sum_{j'<J,t'<H}e_{j',t'}\right)=\eta\right].
\end{aligned}
 \tag{4}
\]
位地址使用 LSB 起点；和式以普通加法器实现。有效地址为 \(0\le a\le\lambda+h\)。与原较宽的 MSB-first history 字段相接时，仅使用已经核验的补前导零和位地址转换。

**命题。** 设 \(c_1,c_2\) 为原运行的前两个 prefix batch 的 YES 数，只在 \(A\) 真时定义。则
\[
 \mathsf{PC}_q(r,a,\eta)
 \iff A\land[\operatorname{bit}_a(c_r)=\eta],
 \qquad r=1,2.
 \tag{5}
\]
而 (4) 中的每个 \(e_{j,t}\) 都被强制为该实际标签、实际轮次的真实查询答案。

**证明。** 若 (4) 成立，对每个 \(j\) 的 (2) 都提供一个真实原像，故首批全 YES。全称 \(v\) 排除首 chunk 更小的全部原像，因而 \(\pi_h(U_j)\) 唯一等于原第一轮更新所选的 \(\alpha_j\)。模式 1 的 (3) 是全部首轮候选，模式 2 的 (3) 恰是该 \(\alpha_j\) 下的次轮候选。

若 \(e_{j,t}=1\)，\(Z_{j,t}\) 证明这个查询 YES；若 \(e_{j,t}=0\)，全称 \(z\) 排除该查询的所有 witness。每个带标签答案因此唯一确定，整数加法器输出实际 \(c_r\)。反向，首批全 YES 时，为每个标签取一个以真正 \(\alpha_j\) 开头的原像，再为实际 YES 查询提供 witness，便满足全部条件。若 \(A\) 假，某个标签根本没有原像，(2) 使 (4) 对两种 \(\eta\) 都假。\(\square\)

这个证明同时解释了 Pro 的频数公式为什么可用于 count，又为什么不必假装频数已经产生选择器：带标签的 \(\alpha_j\) 在 (2) 中经原 generator 单独绑定。不同模式中的 \(U_j\) 后缀可以不同，其首 chunk 却被同一实际源唯一确定；没有更换 proof 或实际前缀。

### 全部费用

共同的普通关系模板只有两个量词块。量词位数为
\[
 P_{\rm quant}=JL+JH(1+L)+\lambda+h+2L.
 \tag{6}
\]
一次共享的 \(\mathcal X_q(j)\)、至多四次 \(G_N\) 求值、显式 mux 和加法器给出
\[
 S_{\rm mat}\le S_X+4g+
 O\bigl(JL+JH(L+\lambda+h+1)+L+\lambda+h\bigr).
 \tag{7}
\]
其中 \(JL\) 和 \(JHL\) 分别支付读 \(U_j\)、\(Z_{j,t}\) 的普通 mux；\(JH(\lambda+h+1)\) 支付 \(JH\) 个 bit 的准确整数和，计数宽 \(\lambda+h+1\)；其余项支付 prefix 比较、等式、模式和位选择。\(\rho\) 的原固定连线必须逐根进入输入／门表，不作为未计价 oracle。

令 \(B=S_{\rm mat}+P_{\rm quant}+\lambda+h+1\)。显式 gate-list、全部量词／输入位置及控制描述的总长度为
\[
 O(B\log(B+2)).
 \tag{8}
\]
共同公开程序 \(K,G,\mathrm{JK}\) 固定，\(q,N,\lambda,h,L\) 的紧凑参数表示占 \(O(m)\) 位；这不替代 (6)–(8)。特别地，不输入完整 \(P\) 的字面二进制表示作为一个所谓短参数。

由 \(2^h\le2P g\)、\(P\le T_0^{O(1)}\)、\(JL\le\widehat P\)，(6)–(8) 及给定同一固定程序后的公式生成均为 \(T_0^{O(1)}\)。短程序名、整数指数记号和存在量词没有消除这些费用。本文只证明此上界，没有实际生成数组或运行电路。

因此 (4) 是一个新增的、完全计价的 **object-scale 两轮复合归约**。它避免先枚举 Pro (14) 的 \(H^2\) 个 \(\mu(D_\alpha\cap R_{\alpha t})\) 单元，也无需将中间 count 或选定前缀向量硬接为 advice；费用转入了 \(JL+JHL\) 个显式量词位。它没有达到 \(m^{O(1)}\)，不能用来宣称最早的地址接口已前移。

## 3. 最早缺口的校正：guard 表示与全 YES 结构定理

前述 Pro guard 位代入是正确的还原，但它不能说明初始 guard 本身是一项独立的**非一致表示**障碍。[Paper 04 §1、Proposition 1.3B](../../units/rw-jk-succinct-reconstruction/papers/04-from-address-scale-smart-reconstruction-to-p-poly/paper.md) 允许共同非一致 advice，并已证明有限分支选择可吸收。将这个既有规则具体应用于当前初始事件，取
\[
 g_q:=\mathbf1[A_q]\in\{0,1\}.
 \tag{9}
\]
给定这一共同正确 advice，guard 图就是 \(\eta=g_q\)：描述 1 位、量词 0 位、普通矩阵和生成均 \(O(1)\)。该存在性不要求先知道实际 \(g_q\) 的值；也不声称它有从 \(q\) 出发的短均匀生成算法。这一位在所有地址间相同，不能逐地址另选。

更明确地，若分别有 \(A_q=0\) 时实际首批 count 的短图 \(R^-_q\)，以及 \(A_q=1\) 时所需实际 prefix／后继行为的短图 \(R^+_q\)，则初始 count 可合成为
\[
 R^0_q(a,\eta)=
 [g_q\land\eta=\mathbf1[a=\lambda_q]]
 \ \lor\ [\neg g_q\land R^-_q(a,\eta)],
 \tag{10}
\]
实际执行的后继图是 \(g_q\land R^+_q\)。加上 \(g_q\)、正确 \(\lambda_q\) 和原字段地址参数，共同 descriptor 只增加 \(O(m)\) 位；对齐已有量词模板后，量词位不超过两分支原有总和，矩阵只多 \(O(m)\) 门，门表／控制／给定 advice 后的生成多 \(O(m\log(m+2))\)。这些是条件性组合费用，\(R^-_q,R^+_q\) 尚未构造。

这只移除了“先获得完整 count，才能付得起一个分支标志”的额外要求。它**没有**证明 \(A_q\) 恒真、没有计算首批 count 的其余位，也没有消除任一分支的源绑定。若函数结构能证明所有实际基点都全 YES，当然可以删除 \(R^-\) 分支；这正是 Pro 当前挑战可能改变决策的实质内容。一位 advice 不能替代该结构定理。若另要求从 \(q\) 均匀生成所有 advice，则 (9) 也必须重新付生成费用，本轮没有那项短算法。

## 4. 停止边界

Pro 已完成答复没有把集合和式当作短算法，没有将选择频数当作带标签选择，也没有把未执行轮次晋级为实际 history。其语义公式通过了独立核验；需要保留上述原 dummy 映射及 \(P\) 位长边界。

本轮 (4) 把一次实际 prefix 复合落实到同源、带标签、全部计价的两块量词关系。它没有给出更便宜的实际初始聚合，也没有使 \(JL+JHL\) 的量词数组获得共同短表示。有限分支吸收只说明初始 guard 的孤立表示不是非一致预算瓶颈；真正未消去的内容仍是 NO 分支的完整首批 count，和 YES 分支的同源带标签复合，或一个足以消去相应分支的实际结构证明。

**UNKNOWN。** 没有得到满足预算、并改变最早数学接口的新 exact reduction；上述新有限归约仍停在 object scale。现有源函数次数信息没有直接判定实际 \(A_q\)，Pro 的未完成挑战也不作为证据。此时继续改写 \(\mu\)、前缀像集或长 witness 数组不会改变决策，停止本轮。不使用不可达 batch、其他 serialization、W 或字面 seed 下界作 NOGO，不切换 R3。
