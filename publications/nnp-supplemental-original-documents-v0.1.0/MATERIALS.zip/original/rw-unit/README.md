# RW/JK succinct reconstruction

## 对象与范围

本单元研究 Ren--Williams / Jeřábek--Korten 型重构能否在同一 hard word、同一
全局对象和同一地址空间上达到 address-scale exact evaluation。结果中立的长期目标是
确定这种压缩的尖锐构造边界；若候选接口不成立，则给出可迁移的 coding、information
或 circuit-forcing 障碍。

## 权威正文

- [From Address-Scale Smart Reconstruction to P/poly](papers/04-from-address-scale-smart-reconstruction-to-p-poly/paper.md)：RW/JK source-specific 的条件性 Closure 与当前承重尺度边界。
- [Shared-Proof Coordinate Robustness Implies Relaxed Local Decoding](papers/01-shared-proof-coordinate-robustness-implies-relaxed-local-decoding/paper.md)：shared-proof coordinate robustness 到 relaxed local decoding 的统一编译。
- [Distributional Soundness Does Not By Itself Produce a Global Word](papers/02-distributional-soundness-does-not-produce-a-global-word/paper.md)：distributional/list soundness 与共同 global word 的量词分离。
- [Cover Obstructions for Shared-Top Direct-Product Tests](papers/03-cover-obstructions-for-shared-top-direct-product-tests/paper.md)：BMVY/DDL 源族的 shared-top cover obstruction。
- [Target-Dependent Local Verification: Information--Proof-Length Tradeoffs](papers/target-information-versus-proof-length/target-dependent-local-verification.tex)：target-selected test profile 的互信息、proof length 与 RLDC locality 相图；当前 LaTeX 期刊主稿。
- [Address-Scale Barriers for Shared-Proof Coordinate-Robustness](papers/Address-Scale-Barriers-for-Shared-Proof-Coordinate-Robustness/paper.md)：保留完整技术链的长综合档案。
- [Shared-Proof Coordinate Robustness 扩展档案](papers/05-shared-proof-coordinate-robustness-barriers/paper.md)：保留从期刊主稿裁出的 partition、folding、FRI 与 RW 专属材料。

## 稳定边界

在 published hard lengths 上，C456 的 source alignment 与 Lemma 3.2 的
lexicographically largest raw history 已在显式计入一位 source advice 后合成一个不依赖
branch-specific proof、common prefix、PCP auxiliary proof 或 JK transcript 的
[branch-independent exact same-object surface](../mcsp-hardness-magnification/notes/588-published-rw-singleton-has-exact-same-object-semantics-only-at-object-scale-2026-08-26.md)。
因此 semantic same-parent 已在 object scale 解决；其量词与 matrix 仍为
\(\operatorname{poly}(t)=N^{O(1)}\)，不是 `polylog(N)`。若坚持使用 physical JK
attachment，returned outsider 仍只绑定一个递归 ancestor interval，不自动绑定其中的完整
systematic hard output；而 published width \(k=n_{i+1}\) 使 outsider 本身已有
\(2n_{i+1}\) bits，单独证明 interval containment 也不能补尺度。range-rich family 上的通用
transcript-to-parent 规范化已由指数 parent fiber 反例排除；该排除同样覆盖 total
fixed-PH binder：固定 public transcript 与全部显式 parent-dependent descriptor 后，
谓词语义只定义一个 parent
word，故 range-rich fiber 仍迫使 descriptor 达到 object scale。剩余正攻必须固定
published \(x_0\)、actual singleton 与 source-compatible serialization，并给出
transcript-external global relation。

有限 branch selector 可由一个共同的短非一致描述符
吸收到单个 total surface。尚未成立的是 simultaneous same-object
object-to-address compression，而不是更便宜的独立 parent-normalization 引理：所有显式
输入、量词、矩阵、descriptor 与 control 必须共同降到 `polylog(N)`。若使用 JK success
信息，还必须避免把完整 outsider 当作未计价 payload。逐地址 descriptor、长 seed/tableau
与未计价 ROM 均不满足该接口。[literal published recurrence 的单坐标边界](../mcsp-hardness-magnification/notes/589-literal-published-rw-recurrence-has-no-cheaper-decreasing-coordinate-interface-2026-08-26.md)
进一步排除了现成递减递归：Solve/JK 的第一个真实依赖已是当前尺度 payload，Reconf 指向当前或
更大尺度 proof；只查询较早输出 bits 的地址尺度控制可硬接成
\(N^{1/C}\operatorname{polylog}(N)\) 电路。对漂移 PH 深度，
[定量 growing-alternation 编译](../mcsp-hardness-magnification/notes/586-growing-alternation-has-iterated-polynomial-cost-and-rw-growth-can-absorb-it-2026-08-26.md)
给出的真实上界是 \(m^{A\Gamma^d}\)，不是 \(m^{O(d)}\)：在 published RW
hard-word scale 上，\(d=o(\log m)\) 已足够；若 surface
对任意大的固定 RW 增长常数 \(C\) 成立、资源与 gap 指数跨起点统一，且每层只增加
常数量词块，则可取 \(C>\Gamma^\alpha\)，连
\(d_i=\Theta(i)=\Theta(\log m_i)\) 也仍编译为 \(2^{o(m_i)}\)。
[显式 bounded-checkpoint 递归](../mcsp-hardness-magnification/notes/592-bounded-checkpoint-recursion-misses-the-rw-growing-alternation-window-2026-08-26.md)
不能落入这个窗口：full source run 至少有 \(2^{m-O(1)}\) 步；若每层只显式列出
\(m^{O(1)}\) 个 checkpoints，且 leaf 直接验证至多 \(m^{O(1)}\) 个连续步骤，则
checkpoint arity--depth 计数强制
\(d=\Omega(m/\log m)\)；若把深度降到 \(O(\log m)\)，某层必须显式列出
\(2^{\Omega(m/\log m)}\) 个 checkpoints。一个共同的短 all-cell accessor
会直接成为完整 hard-word evaluator；逐区间独立 descriptor 则失去共同运行。
因此该结果只关闭标准 Savitch-style 显式递归，不排除新的非 checkpoint 全局代数关系。

对这种全局代数关系，逐门 \(\mathbb F_2\)-Nullstellensatz 展开给出了一个更细的稳定边界：
COPY、NOT 与 XOR 可结构化消去，但零值 AND 至少需要选择一个真实零 child；这个 selector
不必读取另一个 child。事实上两个具有不同 sibling 值的最小 AND 实例可以共享完全相同的
degree-two occurrence pairing，因此仅沿 active pairing occurrences 作局部遍历不能读出完整
tableau；这不排除利用整个方程系统的另一条非局部 accessor 定理。
[严格局部反例与 pebbling 边界](../mcsp-hardness-magnification/notes/596-local-nullstellensatz-pairings-expose-short-circuit-selectors-not-tableau-accessors-2026-08-28.md)
进一步说明：标准 pebbling-polynomial 编码的 Nullstellensatz degree 精确等于 reversible
pebbling space，但该定理尚无 degree-preserving transfer 到 actual RW deterministic gate
equations。对 Note 596 当前的 raw duplicate-term 语法，
[relay-normal 编译](../mcsp-hardness-magnification/notes/598-relay-normal-pairings-reduce-functional-nullstellensatz-compression-to-succinct-strategies-2026-08-28.md)
进一步消除了 endpoint routing 作为独立障碍：若先选定一个与 \(n,j,b\) 无关、没有隐藏 advice
的固定 compiler，并且它生成的 wrong-output equations 有一个地址可随机访问、weighted-AND
depth 与 sparse path multiplier 均为 \(\operatorname{polylog}(N)\) 的 short-circuit strategy，
则两份相同的 \(Mh\) 可逐层 relay 常数 occurrence，并直接编译成 C588 所需的 exact
fixed-\(\Sigma_2\) surface。[表示量词边界](../mcsp-hardness-magnification/notes/599-source-compatible-layouts-do-not-determine-succinct-weighted-strategies-2026-08-28.md)
修正了 Note 598 中未冻结的 “actual system”：source-compatible、constant-offset 且局部地址简洁的
恒等 padding 可以分别强制指数地址长度或指数 multiplier degree，所以对所有合法 serialization
的 universal 版本为假。[heavy--light occurrence 编译](../mcsp-hardness-magnification/notes/600-heavy-light-occurrence-addresses-reduce-random-access-to-heavy-run-summaries-2026-08-28.md)
进一步冻结一个 code-level ANF compiler 候选，并把 random-access 充分条件压成 exact subtree
count、低 weighted depth 以及长 heavy run 的 jump/weighted-atom summary：这些接口给出
\(O(R^2)\)-bit path code，global preorder rank/unrank 并非必要。固定 running-conjunction
transducer 的内生 \(d=N=2^{\Theta(m)}\) 反例同时证明 public local compiler 不自动满足该条件。
[value-indexed duplicate-rail 编译](../mcsp-hardness-magnification/notes/601-value-indexed-rails-bypass-the-running-conjunction-depth-obstruction-2026-08-28.md)
进一步确定这个反例不是表示不变的：任意 AND gadget 在某个 stationary corner 必须支付
recursive duplication 或 multiplier weight；对 single-recursive-rail composition 这给出
\(\log K+d\ge L\)。但两条语义相等、按正确输出值选择的 fixed rails 对每个
running-conjunction word 都有 \(K=O(L)\)、\(d\le1\) 且可随机访问的策略。因而 forced-zero
chain 不能用于排除 existential favorable compiler；它只迫使 compiler 把 nonlinear weight
移到终止 side cone。该构造尚不控制 reconvergent XOR occurrence 或 actual RW side-input cones。
[scalar Boolean affine balancing](../mcsp-hardness-magnification/notes/618-scalar-boolean-recurrences-have-balanced-weighted-depth-but-not-automatic-succinct-demand-2026-08-28.md)
现已把这条正向结论扩到全部十六个固定更新 \(x_{t+1}=F(x_t,y_t)\)：当 side word
外生时，每步都是二位 affine transformer，固定 balanced product 与 all-prefix scan 同时给出
\(K=L^{O(1)}\)、\(d=O(\log L)\)、\(r=O(\log L)\)。因此单递归位的串行长度本身已从
weighted-depth 障碍中关闭。完整 \(s_{598}\) 并未随之得到：对 poly-address universal-evaluation
source 的 balanced XOR tree，若 interval demand 也有 poly-address circuit，则严格推出
\(\oplus P\subseteq P/\mathrm{poly}\)。剩余 gate 是 range-product valuation 与 endogenous
multi-state side cones；把另一递归坐标改名为 \(y_t\) 不会使 Note 609 的 width-two 反例外生化。
[Frobenius jump side-cone 编译](../mcsp-hardness-magnification/notes/602-frobenius-jump-rails-compress-a-pascal-reconvergent-side-cone-2026-08-28.md)
进一步表明 linear reconvergence 也不是表示不变的障碍：literal Pascal unrolling 的 occurrence
地址为 \(\Theta(T)\)，而固定 all-time jump block 利用 characteristic-two factorization 与
Lucas demand predicate，把它同 value rails 的复合压到
\(r=O(\log T)\)、\(d\le1\)、\(s_{598}=\operatorname{polylog}(T)\)。
因此下一承重 gate 是 actual \(M\) 的 nonlinear iterated-transition relation 及其 demand-bit
生成，而不是继续从 raw XOR cone 推断 compiler 下界。
[finite local semantic rail 反例](../mcsp-hardness-magnification/notes/609-finite-local-semantic-rails-cannot-compress-a-fibonacci-xor-recurrence-2026-08-28.md)
给出了这条表示边界的互补方向：对任意有限 boundary-local rail bundles 与 bounded
gate gadgets，局部导数恒等式迫使 exact XOR 的每个 strategy 同时进入两个 sensitive
predecessor bundles。带 fresh innovation 的 Fibonacci XOR recurrence 遂强制
\(K\ge F_{L+1}\) 与 \(r=2^{\Theta(m)}\)，且最终函数确实依赖线性多个 fresh inputs。
[nonlinear feedback weighted-depth 反例](../mcsp-hardness-magnification/notes/630-nonlinear-feedback-forces-linear-weighted-depth-in-every-finite-local-semantic-rail-compiler-2026-08-29.md)
进一步用 fresh-input AND--XOR feedback 对同一有限局部 family 强制
\(d\ge L=2^{\Theta(m)}\)，补上独立的 multiplier-degree obstruction。因此有限逐门
semantic rails 不能成为 universal normal form；Note 602 的 nonlocal Frobenius jump、
global reassociation、proof-DAG sharing 与完整计价的 actual-slice conditional rails 均仍在
定理范围外。这两个反例也不证明 actual RW family 含不可绕过的相应 cone。
[weighted-depth 投影与 generic jump 边界](../mcsp-hardness-magnification/notes/603-weighted-depth-projection-is-strahler-complete-and-generic-jumps-are-pspace-level-2026-08-28.md)
进一步把该 gate 的量词冻结：Note 599 的最小 \(d\) 投影在 all-one AND DAG 上精确等于
展开树 Strahler 数，其阈值问题为 P-complete；任意 reversible successor 的 binary long jump
则已是 \(FP^{\mathsf{PSPACE}}\)-complete。因此 local ANF syntax、generic NC DAG projector 与
generic associative binary lifting 都不能仅从已知的 \(P=NP\Rightarrow PH=P\) collapse 得到；
证明这两种 generic 正规化还会分别建立 \(P=NC\) 与 \(P=\mathsf{PSPACE}\)。该结果不排除
C456 existentially fixed 的 \(D_{\rm all}\) 及其 restricted hard-source family，也不声称 \(P=NP\)
在逻辑上不蕴含上述额外 collapse；它只把 generic 论证标记为额外未解边界。下一正向 family
必须直接使用 actual C456 prMA-query computations
的特殊结构，不能把 arbitrary-machine normalizer 改名为 RW normalization。
[actual query 分解](../mcsp-hardness-magnification/notes/604-published-rw-queries-have-a-common-prefix-but-no-closed-reachable-transformer-2026-08-28.md)
进一步确认 reconstruction queries 共享同一 canonical-prefix chain，只有最终 query 依赖输出地址；
但 published PCP wrapper 只给 locality，没有给 actual reachable states 在 composition 下闭合的
transformer algebra，direct branch 也仍是 actual BF/SAT trace。
[canonical-prefix count refinement](../mcsp-hardness-magnification/notes/610-published-rw-canonical-prefixes-are-batch-count-vectors-without-count-state-closure-2026-08-28.md)
进一步证明该 prefix 恰为 \(BF_i\) 每轮 SAT YES-count 的定宽串联，并给出
prefix-conditioned NP replay recurrence。这个 recurrence 的直接实现仍为 object scale；
Algorithm 1 与 JK 的 literal answer-vector update 在完整 syntactic domain 上不经过 scalar
Hamming weight 因子化，而把 arbitrary succinct batch predicate 作为输入的 generic count
closure 会计算 \(\#\mathrm{CircuitSAT}\)。这不排除 actual canonical orbit 上存在更丰富的
小 normal form，所以 favorable frozen-family normalization 仍为 OPEN。
[padded truth-table threshold envelope](../mcsp-hardness-magnification/notes/611-padded-truth-table-thresholds-cannot-carry-first-block-forcing-through-the-rw-transition-2026-08-28.md)
另关闭一个 generator 重参数化出口：若每层只凭已认证的 circuit-hardness 来强制
下一层 systematic first block 出 range，则必须
\(\sigma_{i+1}+O(m_{i+1})\le H_i\) 且 \(H_{i+1}\le H_i\)。当前 generator
阈值可以形式上非单调，但不能突破这个初层包络；初层 seed 容量在 published transition
\(i^\star\) 处只留下 \(o(m_{i^\star})\) 的保证。这不关闭 current-width accidental
success、failure/Reconf、额外 PCP hardness 或 actual weighted-depth normal form。
[首个 actual JK block 的 exact-evaluator 下界](../mcsp-hardness-magnification/notes/613-the-first-actual-jk-block-has-no-address-scale-exact-evaluator-2026-08-28.md)
进一步关闭 literal count-state 出口：基阶段 \(r_0=s_0=0\)，systematic PCP 的开头就是
无条件满足 \(\operatorname{CC}(B_0)=\Omega(n_0/\log n_0)\) 的 brute-force outsider；它完整落在
首个 \(2n_1\)-bit JK block 中。因此任何 exact all-address evaluator 都需
\(2^{m_1/C-O(\log m_1)}\) 大小，count vector 为空也无济于事，且失败发生在任何
composition 之前。这只关闭把 PCP/JK payload 放入短 metadata 或 exact evaluator 的 faithful
literal family；payload-free nonliteral global relation、\(\operatorname{Reconf}_0\) 的 empty-prefix
final query、weighted depth、纯 \(K\) 接口与 heavy-run summary 仍保持 OPEN。
[完美 RW 重构证明携带整个前驱 hard word](notes/436-perfect-rw-reconstruction-witnesses-carry-the-entire-hard-word-2026-09-29.md)
进一步核对 RW 实际采用的 Harsha robust PCP：若基例最终查询的一个 Merlin 电路在所有
Arthur 随机串上被接受，Harsha 的逐点变换检查和 zero-on-subcube 除法检查迫使原始
systematic 位本身组成有效历史，故它们恰为 \(B_0\)；即使只见证一个一值查询，该
Merlin 电路也须有 \(\Omega(n_0/\log n_0)\) 个门。对未完美接受的证明则只得到
原始位电路与错误掩码的完整计价折中。真实 \(BF_1\) 首败时，一值 hard-suffix 查询有
\(\Omega(n_0/\log n_0)\) 个，每个的 literal \(\exists C\forall r\) 完美证明都需 object-scale
gate-list 量词；该下界仍不提供 address-scale decoded evaluator，也不排除另行完整计价的
succinct gate generator。Harsha 的低度测试在零拒绝概率下还迫使原始赋值表为精确码字；
结合满长 canonical-prefix 测试，此同对象结论扩至每个实际 RW 首败重构分支：任一一值
最终查询的完美 Merlin 电路都携带整个前驱 outsider \(B_i\)，门数
\(\Omega(n_i/\log n_i)\)。更一般地，在任一实际成功阶段，只要 PCP 证明以大于
\(1/2\) 的概率通过且 decoded prefix 为 canonical，整个 decoded 输出就是 \(B_i\)；
首败最终查询以大于 \(1/2\) 的概率通过也自动满足此条件。
统一固定 \(O(\log q_i)\) 份自纠错随机带，再用低于 outsider 阈值的
共享半地址电路补齐剩余错误后，得到完整计价的下界
\(|C|+1=\Omega(n_i/[q_i\log(q_i+2)(\log T_i)^{O(1)}])\)。稳定阶段
\(T_i=n_i^C\) 因而要求每个此类证明具有
\(n_i/\operatorname{polylog}n_i\) 个门；早期大 \(T_i\) 阶段该式可能空泛。
同一论证不依赖 PCP 接受事件：在任一真实成功的稳定阶段，诚实 systematic
Reed--Muller 表的任何 \(1/4\)-field-symbol 近似电路也需
\(n_i/\operatorname{polylog}n_i\) 门。这关闭了以小近似 generic-point evaluator
替代诚实证明表的捷径，仍不约束纯 gate generator 或 R3 策略摘要。
[真实稳定 RW 证明表的常数密度 R3 缺口](notes/437-constant-density-r3-gaps-in-the-actual-stable-rw-proof-2026-09-29.md)
把该平均情形下界用于同一实际诚实 proof 的固定局部编译器：在 \(P=NP\) 分支，任一真实
成功且 \(T_i=n_i^C\) 的稳定阶段，对每个固定 R3 资源指数，超过 \(1/4\) 的
Reed--Muller 域点至少有一个 bit 的两种声称都缺少短、有声的完整计价证书；其中
\((1/4-o(1))\) 的域点处于 off-grid proof 段。逐 bit 的有声
\(\Sigma_2\) 证书合成逐符号近似器，与 Note 436 的 \(1/4\)-近似下界矛盾；
在 \(P=NP\) 下还可用地址尺度算法定位一个 off-grid 双侧缺口。
对 hard word 所在的 literal output 区间，两种 bit 值各有
\(\Omega(n_i/q_i)\) 个双侧缺口。该结果限定在真实稳定成功分支，
不宣称这些缺口会改变 JK 查询答案，也未定位失败的 \(K,d,\mathrm{Jump}\) 分量。
[单个真实 off-grid 点的局部 demand 障碍](notes/451-one-actual-off-grid-proof-point-forces-hard-local-demands-in-a-fixed-interpolation-compiler-2026-09-29.md)
固定一个保留诚实 tensor 插值 XOR 树、且从正则源计算规范 witness 的编译器。
在每个真实成功的稳定阶段，一个公开 off-grid 域点的 \(O(\log q_i)\) 个 bit 根
共同打开全部 systematic hard-output 寄存器；若它们都有地址多项式大小的
state-local transition/demand 语法，沿公开树路径读取 demand 就得到同一
实际阶段 outsider \(B_i\) 的地址多项式电路，与 outsider 下界矛盾；若该
稳定阶段由 RW 的最终 \(A_0\) 分支选中，它也正是 published 输出。
所以该固定编译器至少一个真实 proof-bit 根已在局部语法接口失败，无须假设
\(K,d\) 或 heavy-run 的界；这不排除重组插值的其他编译器，亦不保证稳定成功
分支无限出现。
[几乎全部诚实域符号的局部 demand 障碍](notes/452-almost-every-honest-rw-field-symbol-forces-a-hard-local-demand-2026-09-29.md)
把强制 XOR/COPY 路径上的 demand 读出抽象为一般引理，并将上述单点结论扩展到
每个 \(z\in(F_i\setminus H_i)^{m_i}\)：该点的 bit 根至少一个没有固定地址多项式
成本的局部语法。RW 域参数使这类点占实际诚实 Reed--Muller 表的
\(1-o(1)\)。结论仍限于同一显式插值编译器和真实成功稳定阶段，
不能替代真实首败返回门 \(v_j\) 的 R3 三元组。对 Note 438 的另一固定平衡序列化，
这些困难证明位还都位于抗少量翻转的顶层 JK YES 块中。同一插值树的某个 bit 根
有至少 \(2n_i/\lambda_i\) 个与实际 outsider 位对应的 COPY 叶门方程，在任何
普通 Nullstellensatz 反证中都不可省；这个显式方程数下界仍允许简洁的全局配对。
更进一步，同一处至少有一个**无短局部语法**的 bit 根，其树中有
\(\Omega(n_i/(q_i\lambda_i))\) 个实际 outsider 位的 COPY 叶方程不可省；
零值位与一值位分别满足这一结论，但两个根可以不同。
[同一批 hard-word 地址在几乎全部诚实证明点都无法由短局部语法触达](notes/453-a-common-hard-word-address-set-defeats-local-grammars-at-almost-all-honest-proof-points-2026-09-29.md)
进一步交换量词：在每个真实成功稳定阶段，对固定语法成本指数，可分别固定
\(\Omega(n_i/q_i)\) 个零值和一值 outsider 地址，使每个地址只在至多
\(q_i^{O(1)}/n_i\) 比例的全离网格点上被短语法 bit 根触达。因而在
\(1-q_i^{O(1)}/n_i\) 比例的点，这两批固定地址分别迫使某个坏根含有
\(\Omega(n_i/(q_i\lambda_i))\) 个不可省的实际 COPY 叶方程。
这仍是固定插值编译器的局部结论，不给出首败 \(D_{\rm all}\) 返回门的 R3 三元组。
[一个真实 outsider 寄存器在每个离网格证明点都阻断完整 R3](notes/454-one-actual-outsider-register-obstructs-full-r3-at-every-off-grid-proof-point-2026-09-29.md)
对同时计入 exact subtree count、weighted depth 与 heavy-run summary 的完整 R3
策略，可在实际内部寄存器 \(r_{x_i(j)}\) 使用有声固定 \(\Sigma_2\) 证书测试。
在 \(P=NP\) 与真实成功稳定阶段，两种 bit 值各有 \(\Omega(n_i/q_i)\) 个
固定 outsider 地址，其寄存器无短证书；每个此类地址在**每个**全离网格点
的所有 coefficient-one bit 根都无短完整 R3 策略。双侧缺口中至少一个地址
还可用地址多项式成本定位。此结论仍不判定首败返回门 \(v_j\) 的内部三元组，
也不排除非局部代数配对。
[低次数直线插值迫使几乎全部诚实证明点缺少短非局部证书](notes/455-line-interpolation-forces-near-total-nonlocal-certificate-gaps-in-the-honest-rw-proof-2026-09-29.md)
把 Note 596 的完整计价 occurrence-pairing 证书作为逐 bit 有声测试。在
\(P=NP\) 与真实成功稳定阶段，若一条经过 systematic grid 点的直线有超过
\(d=m_i(|H_i|-1)\) 个全 bit 可证的点，地址多项式搜索与插值即可读出该点的
真实 witness 值。outsider 下界迫使零值与一值各有 \(\Omega(n_i/q_i)\)
个实际地址，使**每条**过其网格点的直线至多有 \(d\) 个全可证点；全表可证比例
至多 \(d/(|F_i|-1)=O((m_i|H_i|)^{-2})=o(1)\)。这覆盖非局部配对，
并排除几乎全部点的真实上游奇偶式 (452.9) 具有短、完整计价的端点配对；
仍限于真实成功稳定阶段与各自固定的局部可生成源，不定位首败 \(v_j\)。
[密集 R3 缺口与 JK 稳健 YES 块共存](notes/438-dense-r3-gaps-inside-robust-jk-yes-blocks-2026-09-29.md)
在同一个固定的 Note 407 平衡序列化中，把上述证书论证与 Note 409 的逐块完整计价
插值电路合并：成功稳定阶段至少 \((1/4-o(1))\) 的真实证明表域点有双侧缺口，
其缺口 bit 位于实际顶层 JK 查询输入的 \(V_i\) 块；这些块周围半径
\(\varepsilon n_{i+1}/\log n_{i+1}\) 的 Hamming 球仍全部在下一层生成器 range。
在 \(P=NP\) 下，可用地址多项式时间定位一个这样的域点、bit 和 JK 块。
因此顶层 range 查询的输入包含缺口，查询的 YES/NO 答案却对这些单 bit 翻转
局部不敏感；若有顶层首个 NO，Note 409 把它放在与这些缺口不相交的 raw history。
若顶层全 YES，翻转任一此类 bit 会改变规范原像，必使后续某个已发出的前缀可行性
查询槽改变答案；尚不能以地址多项式成本定位该查询。前缀计数与规范 preimage
仍可能携带该词。
[一个带地址的 alias 段读出全部 JK 块位](notes/439-one-addressed-alias-chunk-exposes-every-jk-range-block-bit-2026-09-29.md)
另选一次固定、P-uniform 的后继生成器和 Note 411 的 checked compiler：在 Note 407
已有 alias 段后加一个 \(O(\log T_i)\)-位选择段，以 \(h\) 命名任意顶层块内 bit。
沿用零 fallback，保持原 truth-table range、\(n_{i+1}\) 种子预算及已有前缀计数。
同一新轨道的全部顶层 range 批次均为 YES；一个实际 SAT 查询答案的补值精确给出
\(Z_{i,j}[h]\)，特别是 \(B_i[a]\) 与 Note 438 论证在新固定
轨道内重新定位的证明缺口位。选取低序号 selector 码并固定块优先的并行查询顺序后，
首块实际查询的轮次与轮内序号在所有阶段均为 \(O(\log n_i)\)-位；基阶段读出的
\(B_0\) 恰为同一普通真值表生成器的原始首个 range 缺口词。完整 SAT 矩阵仍含
\(2n_{i+1}\)-bit 目标块及生成器描述；在已证 range 承诺下，其答案虽可语义化简为
目标位的补值，却仍缺从公开地址对同一诚实证明位作完整计价绑定的构造。
同一固定轨道还有逐块半径 \(\varepsilon n_{i+1}/\log n_{i+1}\) 的全顶层稳健性：
任意同时翻转这些块位，所有顶层 range 答案仍为 YES，而选定的一个
selector 批次答案恰在被翻转的坐标改变。该反事实输入不要求仍是有效 PCP 证明。
在固定的 seed-as-witness Circuit-SAT 编码下，每个顶层证明位还被下一层诚实
Lemma 3.2 历史中的一个确定 witness 位原样记录；该 raw 位本身位于下一层证明的
systematic 前缀。稳定阶段这给出公开、单查询、单射的证明位坐标映射；
首块的 \(B_i\) 更处在下一层证明的一条公开等差坐标子序列上。
若只读 off-grid 部分，也可用至多四个域符号读回。逐层复合至
\(c\log_C n_i\) 层仍可在最终地址长度的固定多项式内计算，因此该新轨道
成功稳定阶段的 hard word 对这些后续诚实证明仍给出
\((0.1-o(1))n_i/\log n_i\) 的地址电路下界；坐标映射并未给出
证明位本身的独立求值器。
把内层码固定为门数优先后，首个下级 JK range 批次也全部为 YES；
该层实际 selector 查询逐位读出首块的规范生成器种子，并把这些位记录进
下一层同一诚实证明。成功前驱的种子含至少
\((0.2C-o(1))n_i\) 位规范门表记录；记录的长度不推出其逐位
地址电路下界，也未提供非循环的求值关系。
若后继 \(BF_{i+1}\) 在稳定阶段成功，首个 JK NO 的一个父块规范种子本身
具有 \(\Omega(n_{i+1}/\log n_{i+1})\) 位函数电路复杂度；父块最后一轮
被选中的 YES 查询只有该种子一个 witness，因此下一层诚实证明的一个
公开 raw 槽保存完整种子。只读其 off-grid systematic 段并用 Note 423
的四符号逆变换，也得到
\(\Omega(n_{i+1}/(\log n_{i+1}\log\log n_{i+1}))\) 的地址电路下界。
这仍是证明访问下界，未给出该段的短求值关系。
[单 bit-plane 的 off-grid 逆变换](notes/440-binary-off-grid-puncturing-recovers-the-actual-jk-outsider-2026-09-29.md)
把这条下界加强：线首 Lagrange 基函数在整个特征二域上的和为零，在 grid 上的和为一；
所以删去 grid 后，固定 \(\beta_0(1)=1\) 的 bit-plane 奇偶和为一，可以公开选一个
非零读取点。稳定阶段每个逻辑 NP-witness 位恰在一条长度 \(u<g\) 的
raw 线首位，其余线位受检为零；同一公开 off-grid 点的固定 \(\beta_0\) bit-plane
中一个证明位便原样等于它。若 \(BF_{i+1}\) 成功，首个 JK NO 前两个父块的末轮
YES 查询在同一诚实证明中分别唯一记录两个规范种子；每个 \(B_{i+1}\) 位遂由该
单 bit-plane、同一个公开 \(x_*\) fiber 的**一个** off-grid 证明位读出，
且两个 \(n_{i+1}\)-位半词各是一条步长 \(g_{i+1}/u_{i+1}\) 的证明位等差子序列；
地址控制及两查询定位符均为
\(\operatorname{polylog}(n_{i+2})\)。同一对象的该单 fiber
全地址求值电路大小 \(s\) 满足
\(s+\operatorname{polylog}(n_{i+2})>0.1n_{i+1}/\log n_{i+1}\)。
单 fiber 嵌入只用到该固定 checked/平衡证明编译器、直接种子见证语法和生成器对小电路
真值表的 range 覆盖；因此也适用于保留普通 RW 真值表生成器的这种合法固定编码，
不依赖 selector 或门数优先码。专门在门数优先 selector 轨道，首个 JK NO 的一个实际
父块还使其末轮 YES 查询的 literal Circuit-SAT 矩阵代码与唯一
\(n_{i+1}\)-位 witness 分别具有
\(\Omega(n_{i+1}/\log n_{i+1})\) 地址电路复杂度；短查询槽定位符无法承担两者的值。
对任意布尔 raw 线，固定 \(\beta_0\) off-grid 平面在删去 grid 后仍满秩：次数
小于 \(u=2^\mu\) 的域多项式给出代数次数至多 \(\mu\) 的非零二进制函数，其重量
至少 \(Q/u>u\)，不可能只支撑在 grid 上。稳定阶段公开选取 \(u=O(\log n_{i+1})\)
个 off-grid 点便可恢复整条 raw 线，包括稠密输出域。因此稳定成功阶段的原始
\(B_i\) 本身也可从同一证明的单一 bit-plane 以 \(O(u)\) 次逐位读取恢复；这条
输出域结论不要求下一阶段成功。
另一个一次固定的合法 checked compiler 在原有 NP-witness 段后附加间隔放置且逐位
受检的 \(2n_i\) 个输出副本输入，保持旧 count/output 域位置和原始历史语义。
新轨道的稳定阶段，\(B_i\) 即使不等待后继，也逐位等于自身诚实证明的同一个
off-grid fiber 上一个公开位；成功时该 fiber 的全地址电路复杂度仍至少
\(0.1n_i/\log n_i-\operatorname{polylog}(n_{i+1})\)。此复制改变后续证明及轨道，
不能追认为旧轨道的已有证明位。若首次失败恰在 RW 时间交叉点，前一阶段虽尚未
稳定，却有 \(\log T_i=O(\log n_{i+1})\)，因此同一单 fiber 关系也适用于该 published
good predecessor；交叉点之前固定步数内的首次失败亦然。更精确地，预稳定阶段
的线隔离阈值为
\(i=(\log_2(n_0/(\log_2n_0)^2))/\log_2(C^2/D)+O(1)\)，
严格早于 RW 时间交叉点，留下 \(\Theta(\log n_0)\) 个预稳定阶段的单 fiber
地址窗口；这个阈值只属于 \(g_i\asymp(\log n_{i+1})^2\) 的特定间隔。
若另选一次固定合法编译，把输入与非输出门间隔取为整个 JK 块宽
\(g_i=W_i=2n_{i+1}\)，所有阶段的副本位都独占 raw 线且顶层 JK 仍全 YES；
该单 bit-plane 物理读取在地址尺度成立**当且仅当**
\(\log T_i=\operatorname{poly}(\log n_{i+1})\)，因为所选证明位索引长度恰为
\(\Theta(\log T_i)\)。因此改变间隔可消去线碰撞，却不能压缩早期阶段的
原始时钟/输出域。
[块宽间隔把真实 JK 全 YES 深度推至地址线性](notes/441-maximal-checked-spacing-delays-actual-jk-failure-linearly-in-address-length-2026-09-29.md)
把该固定编译器与门数优先 selector 生成器合并：raw 检查器每个顶层块只需
\(O(\log N)\) 门，完整 off-grid/auxiliary 块成为主项并统一小于
\(B\sqrt N\)。规范种子的完整门表仍计价；两前缀共享查表使每次 JK 逆层的
逐块上界最多乘固定常数 \(A\)。因此在这个新合法轨道中，至少
\(H=m/(2\log_2A)-O(\log m)=\Omega(m)\) 个**完整且实际到达**的 JK range
批次全 YES（\(m=\log_2(2N)\)）；成功时首个 NO 必在这些批次之后。
更精确地，对任意固定 \(\kappa>1/3\)，先固定相同编译规则再选足够大的常数
\(C=C(\kappa)\)，顶层完整计价界为 \(B_\kappa N^\kappa\)，从而保证
\(H_\kappa=((1-\kappa)/\log_2A_0)m-O_\kappa(\log m)\) 个完整 YES 逆层，
其中 \(A_0\) 可与 \(\kappa\) 无关；单一固定轨道的插值指数仍为
\(1/3+K/C\)，不能写成随 \(N\) 消失的 \(o(1)\)。
每层 selector 查询确已发出，但其答案仍依赖真实证明位，不能由深度保证
推出同对象短求值关系或 \(NP\nsubseteq P/\mathrm{poly}\)。
[固定多项式证明长度下的插值样本下界](notes/442-polynomial-rw-proof-length-forces-polynomial-local-interpolation-samples-2026-09-29.md)
给出这一路径的精确尺度取舍：在稳定阶段，若同一系统证明长至多
\(T^B\)（固定 \(B\)），Note 409 每个受访行的显式张量插值表至少有
\(T^{a/B-o(1)}\) 个样本槽；若仅靠增大域把槽数压至
\(\operatorname{polylog}T\)，证明长度必须达到
\(T^{\Omega(\log T/\log\log T)}\)。这只关闭显式样本表的参数压缩，
不排除这些值存在一个新的短共同求值关系。
[规范原像移位标签](notes/443-shift-tags-preserve-the-actual-rw-word-through-linear-many-jk-inverses-2026-09-29.md)
给出另一条一次固定的新合法轨道：按本阶段公开的 JK 总逆层数预留长度
\(p_i=\rho_i+2n_i\) 的标签放在旧 alias/selector 段后，强制每个标签等于
目标块的公开前缀或前一个标签窗口。新增种子预算
\(O(p_i\log T_i)=O(n_i^3)\)，完整计价后仍小于 \(N^{1/2}\)；
旧 selector 查询语义和 \(\Omega(m)\) 层整批 YES 递推继续成立。在这些实际
到达的每一层，首块的一个公开局部区间原样等于同一阶段的
\(\pi_i B_i\)；同一恒等式进一步延至每个实际到达的逆层，包括首次 NO
所在批次，若全 YES 则延至终端种子。成功时首块始终承载同一个困难词，
但尚无独立短求值器，也不保证最终首个 NO 发生在首块。
[前缀广播证明包装](notes/444-prefix-broadcast-proof-wrapper-binds-every-jk-outsider-to-the-same-rw-word-2026-09-29.md)
以更简单的固定新轨道解决首块选择障碍：每个物理 JK 顶层块复制同一
\(\pi_iB_i\) 前缀，余位顺序存放原 PCP 证明；紧凑包装只增常数倍证明长度。
公开投影对任意物理证明恢复一个原 PCP
证明，保持 RW 3.5 健全性与经 Note 433 修正的 4.1 smart reconstruction。
一个规范原像标签强制 \(\xi_N(z)[0:p)=z[0:p)\)，于是**每个实际到达的 JK 块**
都以同一 \(\pi_iB_i\) 开头；无论首次 NO 的层数和块位，返回的实际后继 outsider
都在固定坐标原样包含 \(B_i\)，无需层数描述。若改成每块只存一个原证明位，
长度乘以 \(W=2n_{i+1}\) 后仍为 \(\operatorname{poly}(T_i)\)，逐块完整计价的顶层界
进一步给出 \(\Omega(\log N)\) 个整批 YES 逆层。该包装也能在已固定的 published
\(B_i\) 后只作用于一次新后继调用，不改变该前驱词；但返回词位值仍无地址尺度
求值器，因此尚未获得一般电路下界。
[加权 JK 查询槽写入后继 count-prefix](notes/445-weighted-jk-query-slots-write-the-same-predecessor-word-into-successor-counts-2026-09-29.md)
把该包装的公共前缀加一位非零哨兵并按 JK 搜索块宽对齐。顶层整批全 YES，
每块在前缀搜索轮只有同一候选 \(q\) 可行；只对首块候选复制
\(2^b-J+1+\operatorname{val}(q)\) 个实际查询槽，其余块每候选保留一槽，
故该轮诚实 YES 总数**精确等于** \(2^b+\operatorname{val}(q)\)。复制后的查询数及
矩阵构造仍为 \(\operatorname{poly}(T_i)\)，轮数与 JK 输出不变。RW Lemma 3.2 的
后继规范 count-prefix 因而按公开的 \(O(\log n_{i+1})\)-位坐标原样包含
\(B_i\) 乃至整个旧 count-prefix；这些坐标映射沿长度链仍可在末端地址尺度
组合，即使中间 hard/easy 分支不同亦然。成功前驱词把
\(\Omega(n_i/\log n_i)\) 电路复杂度传给该 count-prefix。
这是新固定实现或对已固定前驱的一次新后继调用；短地址仍不提供该 count 位的
短求值关系，不能据此推出 \(NP\nsubseteq P/\mathrm{poly}\)。
[单槽 pilot 计数](notes/446-one-slot-pilot-counts-embed-every-predecessor-bit-2026-09-29.md)
进一步把 Note 445 的整块候选加权轮改为逐位搜索：首块的“下一位能否为一”
查询独占 pilot 轮，下一轮对全部块分别询问零扩展并选择规范原像。
实际首块的 tag 唯一，因此 pilot YES 数恰为 \(H_i[u]\)。
每个 tag 位仅用 \(J+1\) 个总查询槽和两轮，仍在 RW 的
\(O(n_{i+1})\) 轮及 \(\operatorname{poly}(T_i)\) 时间内；固定前驱下的 JK
规范原像和 hard/easy 输出与 Note 445 相同。公开计数坐标及跨阶段组合继续成立。
若前驱 \(B_i\) 是 outsider，实际 pilot 答案族和后继 count-prefix 都继承其
\(\Omega(n_i/\log n_i)\) 电路下界；首个恒 YES pilot 的任一直接种子见证
也必须携带完整 \(B_i\)，故无地址尺度的种子见证电路；短描述加逐位
解码（含有界误差随机解码）也受定量下界约束。只保留顶层 JK range、
原像、pilot-count 与选择方程时，所有公共前缀值均可实现，因此这种
局部机制不固定真实源词；下一接口须加入能固定源词的 BF、PCP 或其他
独立条件，并把其成本完整计入。
[编码 pilot 计数的常数误差下界](notes/447-constant-error-coded-pilot-counts-retain-the-published-base-outsider-2026-09-29.md)
保留同一个 published 基例 outsider \(B_0\)，只在一次新后继调用中将其
Reed--Muller--Hadamard 编码写入实际到达的 pilot count-prefix。
对任意固定 \(\eta\in(0,1)\)，编码长 \(M\le n_0^{1+\eta}\)，在充分大的
固定后继增长常数 \(C\) 下完整计价；任一在这些
公开坐标上错误至多 \(\varepsilon M\)（任意固定 \(\varepsilon<1/8\)）的
共同地址电路仍需 \(\Omega(n_0/\operatorname{polylog} n_0)\) 门。因此一个
对实际编码 count 子向量错误至多 \(M/9\)、共同描述和全部量词/矩阵均
为地址尺度的固定 PH
关系，足以推出 \(NP\nsubseteq P/\mathrm{poly}\)。该 PH 关系尚未构造，
条件性转移不构成分离证明。
若只以“不在原生成器像中”代替实际 \(BF_0\) 的字典序选择，则任意同时覆盖
全部 outsider 的共同近似解码器，即使计算无界，也需要至少 \(2n_0\) 位描述；
此边界不排除专用于真实 \(B_0\) 的关系。
同一编码的至少 \((1/3-o(1))M\) 个 off-grid 位是至少 \(n_0/2\) 个
源词位的奇偶；逐位黑盒访问源词再合成编码位需要线性查询数，
但这一界不适用于直接利用真实 \(BF_0\) 定义的关系。
对真实 count 子向量，即使允许任意量词交替，若共同矩阵和描述均为
\(q^{O(1)}\) 门/位且错误至多 \(M/9\)，量词总位数仍须
\(q-O(\log q)\)，其中 \(q=\log_2n_0\)；该下界尚允许地址尺度关系。
若以 Note 428 的模 rank 指示函数对公开首缺词窗口逐候选求和，虽精确得到同一
编码 count 位，字面式仍有 \((0.2+o(1))n_0\) 位求和索引；且至少
\((1/3-o(1))M\) 个编码坐标在该窗口的逐候选求值需 \(\Omega(n_0)\)
个 fan-in-two 门。这只界定先求编码位再逐项求和的实现，不排除先利用
rank 条件化简的全局关系。
[稀疏 range 覆盖的代数分离次数界](notes/448-sparse-range-coverage-forces-high-degree-algebraic-source-separators-2026-09-29.md)
证明原始真值表生成器的像包含全部权重至
\((0.1-o(1))n_0/q\) 的词。任何在整个像上恒零、却在真实 \(B_0\)
非零的多项式，其布尔次数必须超过这一阈值；同一结论传给 Note 447
的线性编码。进一步，任何逐位黑盒区分器在真实 \(B_0\) 上至少读取
\((0.1-o(1))n_0/q\) 个值为一的位；若交替量词总位数为 \(r\)，
固定量词赋值后的矩阵布尔次数至多 \(d\)，则必须
\(2^r d\ge(0.1-o(1))n_0/q\)。另一方面，实际固定编码的 range
至多有 \(2^{(0.2+o(1))n_0}\) 个词，线性代数保证某个分离多项式次数
不超过 \((0.2+o(1))n_0\)，但没有短描述保证。这些边界不排除高次数紧凑算术电路或
直接使用 \(BF_0\) 字典序条件的关系。
[首缺词前缀奇偶轮廓的 Gray 码恒等式](notes/449-first-hole-prefix-parity-profile-is-the-gray-code-of-the-actual-outsider-2026-09-29.md)
把已完全覆盖的整数前缀按 \(\nu_2(x+1)\) 分层，层内个数的奇偶
精确等于同一真实 \(B_0\) 的相邻二进制位异或。层地址只有 \(O(q)\) 位，
但字面定义仍量化 \((0.2+o(1))n_0\) 位整数并检验前缀闭合；
至少 \((1/3-o(1))M\) 个实际编码 pilot 位还分别依赖
\(\Omega(n_0)\) 个层值的奇偶。好的一面是这些组合系数可由公开张量
拉格朗日前缀和在 \(q^{O(1)}\) 门内逐地址求得；尚缺层值求解与全局奇偶。
实际层值向量本身还有至少 \(\Omega(n_0/q^2)\) 个一位，不能靠地址尺度的
显式稀疏列表保存。
这是可逆的同对象表示，不是已计价的
固定 PH 地址关系；黑盒逐层读取下界不排除专用全局关系。
[Gray 层值的强制规模及地址 ANF 下界](notes/450-first-hole-gray-profile-needs-dense-high-degree-address-anf-2026-09-29.md)
通过共享半地址等式与阈值，把 \(k\) 个 Gray 层跳变编译成
\(O(\sqrt{n_0}+k)\) 门的原词电路。因此实际层值至少有
\(\Omega(n_0/q)\) 个一位，较 Note 449 的界强一个 \(q\) 因子。
数值前缀奇偶又把一个地址 ANF 单项式精确送到另一个单项式；
任何在全部实际层地址上正确的 ANF 扩展都有 \(\Omega(n_0/q)\)
个单项式，次数超过 \(q/2-\sqrt{q\ln q}\)。这关闭稀疏或低次数
地址 ANF 压缩，仍允许小电路生成稠密高次数 ANF。同一半地址引理
还证明 published RW 的每个充分大 good-length hard output，
无论最终来自 stable solver 或 reconstruction，都有
\(\Omega(n/\log n)\) 次相邻位跳变；这条全分支结论不定位内部 R3 成本。
对成功阶段的首块，顶层 range 答案和 selector 之前全部旧 alias 查询答案
在后半块的稀疏翻转邻域中保持不变；固定翻转数时，selector 轮的总 YES 数
和选中的 selector 段也不变。若仅凭这些信息与共同描述符恢复后半块
全部 selector 答案，描述符仍需
\(\Omega(n_{i+1}\log\log n_{i+1}/\log n_{i+1})\) 位。此计数只排除
整个反事实邻域上的旧查询答案接口，不排除专用于真实诚实证明的关系。
这是新的固定合法
RW 轨道，不能追认成旧轨道的已发出查询。
[actual top-stage range window](notes/404-rw-top-stage-output-field-blocks-lie-in-the-next-generator-range-2026-09-29.md)
把 Note 622 已用于 wrapped 基阶段的首块 range 事实扩展到未包装的 published
systematic prefix 的每一层：count-prefix/output-field 内所有完整的 top-stage JK blocks
均在下一层 range，首个可能的 top-stage NO block 必须在该区域之后。基阶段首块恰为
\(B_0 0^{2n_1-2n_0}\)，可由 \(O(n_0)\)-gate lookup circuit 编码，但 Note 613 的地址尺度
下界仍成立。range 查询为 YES 不排除 count 通道携带硬信息；Note 622 的固定包装构造
已把 \(B_0\) 编入下一轮 preimage-prefix 数量。这里没有给出未包装证明的地址尺度 evaluator
或 canonical preimage。Note 404 还给出一个保持未包装证明的固定别名生成器：首轮
count 除以公开的二的幂后，精确等于公开项、\(B_0\) 的位值和证明尾部块校验和之和。
由此，未包装 count 路线的承重缺口收缩为尾部校验和的完整计价；RW 原文未给出其消去或
地址尺度访问。在 RW 许可的 JK chunk-width 选择下，一个固定的多轮别名生成器还把每个
\(B_0\) 位对应到下一轮 count 的一位，
仅受同列证明尾部奇偶校验影响，且没有整数进位；该关系需要顶层 range 批次全为 YES，
目前既未证明此守卫必然发生，也未消去尾部奇偶项。精确分岔是：顶层出现 NO 则
某个后缀证明块已有 \(\Omega(n_1/\log n_1)\) 电路下界；全 YES 则 count 位函数与
尾部列奇偶函数的电路大小之和至少为 \(\operatorname{CC}(B_0)-1\)。强制全 YES
所需的充分条件是一个完整计入 \(n_1^4\) 门预算的共同证明块生成电路；逐位三次
界只是该条件的一种实现。现有 C398/C485 逐字段共享估计因基阶段 witness-grid
尺度 \(S_0\ge T_0=2^{cn_0}\)，无法认证这个多项式门数；这不构成实际最优块电路的下界。
[完整辅助多项式表的 JK 列奇偶消去](notes/405-complete-low-degree-records-have-zero-jk-column-parity-2026-09-29.md)
进一步证明：在 C398/C485 的 auxiliary-oracle lex 排序与合法线性 ECC 选择下，
完整 \(P\)、ZoS 及逐符号 ECC 表对每个顶层 JK 列的异或都严格为零，
即使 segment 未对齐块边界。式 (404.21) 的尾项因此只剩 systematic
\(\widetilde w\) 段；普通 lex 域点排序无法同时让 \(H^d\) witness 成为前缀，
所以同一消去论证不能直接覆盖该段。剩余列是原始满足赋值的一个固定公开
\(\mathbb F_2\)-线性像；其行奇偶与赋值访问成本仍须完整计价。顶层全 YES 与剩余 systematic 列
仍未解决。
[systematic RM 列的纤维奇偶因子化](notes/406-systematic-rm-column-parity-factors-through-history-fibers-2026-09-29.md)
固定一个不增加证明位的合法排序：先放全部 \(H^d\) 原始见证位，再放其余网格零位，
最后按 lex 排列 off-grid 域点。补集 rank 的模 \(2n_1\) 递推让所有高位域坐标逐层消去；
在这一实现的顶层全 YES 分支，count 位词精确等于公开线性算子
\(\mathcal L_j\) 作用于高位前缀纤维奇偶表 \(s_j\)，其中 \(j=O(C)\)、
\(|s_j|=n_0^{O(1)}\)，但每项需对 \(2^{\Theta(n_0)}\) 个真实 history 位取奇偶。
这定位了未计价的剩余工作；没有证明这些纤维奇偶易算、顶层全 YES 或地址尺度 Closure。
[公开 systematic 置换的零列定理](notes/407-a-public-systematic-permutation-annihilates-the-jk-column-census-2026-09-29.md)
给出另一个同样合法且保留原始见证前缀的固定排序：按第一域坐标的完整后缀组，把
off-grid 位均衡放入 JK 列。有限域幂和使每列的 grid 与 off-grid 奇偶严格抵消；
结合 Note 405，完整诚实证明的全部 \(2n_1\) 列奇偶为零。于是尾部列奇偶精确等于
\(B_0\)，而 Note 404 的顶层全 YES 条件下那组 count 位恒为零。这严格关闭了该
parity-census count 位作为表示不变的同对象信息通道。进一步的整数权重引理在
Harsha 域参数下使每列 1 的数量被 \(8\) 整除；顶层全 YES 时，全部对应 count 字段
模 \(2^{b+2}\) 的余数相同。对预先固定的任意 \(L\)，合法加大域并重选 RW 增长常数
还能把同余提升到模 \(2^{b+L-1}\)；这不是同一固定证明上的无限阶消去。
再把 witness-grid 参数公开加大一个二的幂，便可在 RW 每个充分大阶段
满足同样的列整除。更强地，取一次 \(W_i^\star=u_i^{d_i-1}\) 的固定排序后，
同一诚实证明对所有二次幂列宽 \(W\mid W_i^\star\) 都有 \(2^L\) 列整除，
无需为 JK 宽度重排。通过加大域来取得增长的 \(L\) 则有明确的长度代价：
系统表本身至少有 \(S_i^L\ge T_i^{aL}\) 位，固定多项式证明长度只容许
固定 \(L\)。JK chunk-width 必须取 \(O(\log T_i)\)，稳定阶段不能沿用
基阶段的 \(O(n_i)\) 宽度，否则会破坏 published 多项式时间界。别名槽需覆盖
公开的 \(\rho_i+2n_i\) 列，才能真正读到后续阶段的 \(B_i\) 输出位置；其种子
开销 \(O(n_i^3)\) 可由充分大的 RW 增长常数吸收。
在输出字段后补不足一个 JK 块的公开零位，还可令每阶段的开头完整块都在下一层
generator range；这只属于该固定合法实现，不改变 Note 404 对未补齐格式的边界。
由于全部非零见证位可放进第一个网格切片，同一排序的一个完整 off-grid 子段
逐块等于早先原始块的公开零倍或原样副本；该段的 NO 必有一个更早的同词 NO，
故 leftmost 顶层首失败不会落在那里。每个非零原始块还有奇数个同词副本，
所以原始切片与该 off-grid 子段对任意 \(\Phi(0)=0\) 的块内布尔统计作异或时
恒为零；这也覆盖非线性但不读块索引的统计。仅凭该回声恒等式，余下的原始块、
其他 off-grid 点和辅助表尚未排除。
[短窗插值定位定理](notes/409-short-window-interpolation-confines-top-jk-failure-to-the-raw-history-2026-09-29.md)
进一步对这个固定实现逐块计入域值硬接：\(W_i\) 个连续非网格后缀点只跨
\(O(Q_i)\) 个短域行，每行用至多 \(W_i^{1/3}\) 个取值插值；完整的逐点 Harsha
辅助表也满足同样的门数界。加大固定 RW 增长常数后，全部 \(V_i\) 段及辅助表
顶层 JK 块都在后继生成器 range。结合前段回声与公开零位，若顶层首个 NO
存在，只能位于第一原始网格切片中已对齐输出窗口之后、\(T_i^a\) 之前。
这仍是逐块各自硬接的成员资格，不能合并成同一证明的地址尺度求值器。
[稀疏门值布局的基阶段全 YES 构造](notes/410-sparse-checked-gate-spacing-forces-a-base-top-jk-all-yes-branch-2026-09-29.md)
在另一套一次性固定的合法 checker 编码中，保持同一 \(BF_0\)、基生成器和历史输入前缀，
用已检查的零门按 \((\log W_0)^2\) 量级的公开间距隔开原 checker 门。
每个基阶段 raw 块因而只需硬接 \(O(W_0/\log^2W_0)\) 个值；结合前述短窗定理，
该实现的整个顶层 range 批次确实全 YES，已发出的指定 count 位恒零，尾列奇偶仍精确为
\(B_0\)。它不判定上一实现尚未指定的 checker 门序，也不提供 \(B_0\) 的地址尺度求值器。
这个基阶段定理未处理其他 count 位或后续阶段的 NP 见证输入，也没有完整计价的地址尺度关系。
[逐输入与逐门稀疏化的全阶段顶层全 YES 定理](notes/411-checked-witness-spacing-forces-all-top-rw-jk-batches-yes-2026-09-29.md)
进一步在一个固定合法 compiler 中，把每个后续 NP 见证输入位也按公开的
\(\Theta(\log^2 W_i)\) 间距隔开，并检查全部插入零位；count/output 的原始前缀和
canonical logical history 不变。每个 raw 块的非零值至多落在两个公开剩余类与两个
例外位置，完整计价电路为 \(O(W_i/\log^2W_i+\log W_i)\) 门。
结合 Note 409 的其余块界，这一固定轨道的每一阶段顶层 JK range 批次全 YES；
已发出的指定 count 位为零，同一证明的尾列奇偶在输出槽精确等于 \(B_i\)。
逐块硬接的值仍无共同地址尺度描述；较低 JK 层、其 canonical preimages 和其他 count 位
尚未判定。该定理不判断另一个已固定或原文未指定的密集 checker 门序。
[短种子层级的下层 JK 全 YES 边界](notes/412-short-seed-hierarchy-delays-jk-range-failure-by-log-log-depth-2026-09-29.md)
先确定别名生成器的精确 preimage 公式：最小 preimage 是全零 alias 前缀接内部生成器的
最小描述。再从一开始另行固定一个保持原 range 的内部编码：顶层块可用短数据模式表示，
后续模式逐层容纳两个短前缀。对任意事先固定的有理数 \(0<\varepsilon<1\)，加大 RW 增长常数后，
这一**新固定轨道**的顶层及其后
\(\lfloor(1-\varepsilon)\log_2\log_2(2n_{i+1})\rfloor\) 层 JK range 批次都全 YES。
全部特殊模式输出仍有小于 \(0.1n_{i+1}/\log n_{i+1}\) 的电路，生成器 range 和基阶段
hard outsider 下界保持；但后续 \(B_i\) 属于新轨道，不能与 Note 411 未固定内部描述顺序的
轨道拼接。短种子逐块携带实际值，仍没有共同的地址尺度 surface。
[普通门数优先编码的实际下层 JK 前缀窗口](notes/413-gate-count-first-coding-gives-an-actual-lower-jk-prefix-window-2026-09-29.md)
另行从开始固定一个不带短种子特殊模式的直接门表编码：先写门数，后写门表，尾位忽略，
零表的最小 seed 恰为全零。基阶段顶层全 YES 后，实际首个下层双块是
\(\xi_N(B_00^{2N-2n_0})0^N\)，其完整计价地址电路为
\(O(n_0^2+n_0\log N+\log^2N)\) 门；初始 \(T_0/(2N)\) 个顶层块除首块外均为零，
在下层继续形成零块，所以首批 \(T_0/(4N)\) 个下层查询全 YES。单用逐位查表时，
同一前缀窗口的条件性范围可维持 \(\Theta(\log n_0/\log\log n_0)\) 层；该估计
未控制后缀。该前缀链可经逐层 \(G_N\) 正向应用精确还原同一 \(B_0\)，但此式
仍按对象尺度计价。两种公开位序交换的合法内部编码还可保持同一 \(B_0\)、同一基证明、
同一顶层 range 与指定 count，却改变实际首个下层双块的两个指定位，说明 RW 原文未选定
唯一的下层 canonical word。
[共享小真值表的整批下层 JK 全 YES 定理](notes/414-shared-small-tables-force-full-lower-jk-range-batches-in-count-first-orbit-2026-09-29.md)
在 **Note 413 的同一门数优先轨道**，用共享全部 \(O(\log\log N)\) 个低地址位上的小函数，
把任意两个长度 \(O(N/\log N)\) 的 canonical seed 前缀合成
\(O(N/\log^2N)\) 门电路。顶层每块已有该量级的完整计价电路，故第一个下层
JK 批次**整批**全 YES；其索引 \(K/2\) 的实际双块正是输出窗口后首两个 raw checker
块的 canonical preimages。固定常数递推又使后续
\(\Omega(\log\log N)\) 层全批 YES，统一适用于充分大的每个 RW 后继阶段。
同一查表引理还把基阶段首块同 \(B_0\) 前缀链的条件性 range 窗口延至
\(\Theta(\log n_0)\) 层；超过已保证的整批深度后，JK 仍可能被后缀 NO 截断。
所有已形成的下层双块均以 \(a_N=p_i b_i\) 个零开头；因此在上述全 YES 层，
每层前 \(p_i\) 个 alias search count 作为完整整数完全相同，只编码该层非零块数，
即顶层 proof 的 dyadic 非零块覆盖数；其随查询坐标的变化不能直接承载 \(B_i\)，
但这个共同整数仍可能携带全局信息。
Note 407 的 raw/off-grid echo 在同一 dyadic 组宽下仍逐组复制，故 raw slice
与奇数份 echo 对这批 count 的奇偶贡献精确抵消；剩余奇偶只来自其他
systematic 与 auxiliary 段，其实际值尚未确定。
Note 405 的低次数逐列抵消不能自动消去该剩余项：一个完整 \(F_4\) 线性多项式表
可逐列奇偶为零、同时有奇数个非零块；实际 \(V_i\) 的块序还会在下层合并相邻
\((x,t)\) bit planes，需要单独分析其零组结构。
每块的布线虽已计价，整份 proof 的共同地址尺度描述仍未得到。
[第一实际 \(V_0\) 窗口的强制非零块](notes/415-first-balanced-v-window-has-a-forced-nonzero-block-2026-09-29.md)
利用基阶段前 \(u_0\) 个 raw 位包含非零 \(B_0\)、域扩展的低布尔次数及 Reed--Muller
最小重量，证明第一个 \(V_0\) 顶层块在公开索引
\(j_V=\lambda_0Q_0W_0^\star/W_0\) 必非零；它所在的首个 \(V_0\) dyadic 组
在 Note 414 保证到达的各下层也必非零、且在 range。第一 \(V_0\) suffix 窗口的
\(Q_0\lambda_0\) 个相隔 \(W_0^\star/W_0\) 的顶层块中至少
\(\lambda_0(Q_0-u_0(u_0-1))\) 个非零；它们在已保证的每一层占据
不同的剩余 dyadic 组。固定 checker 的 final OUTPUT 所在 \(H_i\)-线除它之外全零；
它在相邻至多两个公开的 \(V_0\) 子窗口无条件给出 \(\lambda_0(Q_0-u_0+1)\) 个
互异占用组，合计下界 \(M_\ell^{\rm rem}\ge\lambda_0(2Q_0-u_0^2+1)\)。
这条 final OUTPUT 线的单独下界 \(\lambda_i(Q_i-u_i+1)\) 对同一轨道的
每个充分大后继阶段也成立；若已选网格上界满足 \(Q_i\mid R_i\)，
两窗口合成一个，其抽样 lower 组占用图案逐项公开。
首窗口的紧凑 \((x,t)\) 索引下，零/非零谓词可用
\(O(\lambda_0^2)\) 个内容相关位与地址多项式大小电路精确求值，但
全局 proof 索引仍是对象尺度；该支持信息不能经地址多项式大小的
确定性电路恢复 \(B_0\)。若实际 \(B_0\) 奇偶为 1，抽样顶层块的零图案
精确等于 \(x\in H_0\setminus\{0\}\)；该奇偶条件与全部剩余组的值尚未判定，
共同硬词求值器仍未得到。同一窗口的完整域值可经 \(u_0\) 点插值精确恢复
\(B_0\)，但需 \(u_0\lambda_0=2^{\Omega(\log W_0)}\) 次 proof 位读取及对象尺度的
全局块索引；这是已计价的同对象关系，仍非地址尺度 surface。
[逐阶段插值的真实尺度](notes/416-line-interpolation-is-address-sized-only-after-the-rw-crossover-2026-09-29.md)
把该取值式推广到每个实际 \(B_i\) 地址，并给出其至多两组 \(V_i\) 窗口的公开
proof 位索引。基阶段及第一次实际后继均需 \(u_i=2^{\Omega(\log W_i)}\) 个显式
插值项，且全局块索引有 \(\Theta(n_0)\) 位；因此这种**逐项展开**的固定关系
不通过 R2 的首步组合门。进入 \(T_i=n_{i+1}\) 的稳定区后，插值项数和索引长度
才降至地址多项式量级；实际 proof 值仍缺共同、完整计价的短关系，早期失败分支
也不能跳过。
[允许重选网格参数的基阶段插值下界](notes/594-polynomial-proof-length-prevents-address-sized-base-line-interpolation-2026-10-03.md)
证明：只保留 RW--Harsha 完整系统表、域大小与输出网格容量这三项必要计价，固定
\(T_0^K\) 证明长度仍强制基阶段 \(u=n_0^{\Omega_K(1)}\)；若把 \(u\) 压到继承地址
\(m_1=O(\log n_0)\) 的固定多项式，证明长度至少为
\(T_0^{\Omega(\log n_0/\log\log n_0)}\)。这关闭逐值直线插值的参数缩小法，
不限制非逐项、源专属的共同关系。
[完整域单源矩的奇偶收缩](notes/595-full-field-source-marginals-collapse-to-one-grid-parity-2026-10-03.md)
证明：对 \(F_1/K_1\) 的实际六阶系统表，同一诚实源 \(\bar w_1\) 的任意不加权、
次数至多六的单源布尔矩在完整后缀域上的奇偶和，仅由一个共享网格奇偶位及
公开的地址尺度线性泛函决定。将它用于可达 \(001\) residue 的式 (515.426)，
可精确消去系数中不依赖第一后缀的部分；实际 checker 权重的变化、另外两处源值、
外层和及 \(B_0\) 绑定仍须完整计价。一个一次公共权重已能区分相同网格奇偶的
两词，所以不能由源的低次数直接删除剩余项。仅查询这些不加权单源矩的地址
电路只得到那一个共享奇偶位，不能解码真实 \(B_0\)。相反，一维网格线上
Lagrange 加权的完整域范数和恰为 \(h(h+w(z))\)，其中 \(h\) 是该线的网格
奇偶位；这给出了权重保留被寻址位的精确条件，但尚未嵌入真实 JK count。
[完整域范数的同源网格配对](notes/596-full-field-norm-pairing-exactly-reproduces-boolean-grid-inner-products-2026-10-03.md)
证明：对同一 \(K^D\) 网格的两个布尔词，规范插值乘积的完整域范数和恰等于网格内积；
取单点公开掩码可无奇偶前提地还原诚实源的一位。真实 late checker 的首个后缀因子在
\(\zeta'\) 全为网格位时形式上是相邻两点掩码，但这只是孤立域值求和，既不计入完整
JK 计数，也不给出地址尺度求值器；解码 \(B_0\) 必须使用基阶段 \(w_0\) 的系统位映射。
[可达第三后缀的固定离网格高位](notes/597-reached-rw-suffix-residues-force-an-off-grid-high-digit-2026-10-03.md)
证明：第一次实际后继的每个输出对齐、非平凡 trace-plane 路由 residue 都固定一个离网格的
第三后缀高位，因此上述 late 后缀因子在该路由上从来不是布尔网格掩码。这精确关闭
将该孤立因子直接代入布尔范数配对的办法；其完整域范数和另有精确的
\(2^{D-1}\) 项子集源矩公式。把实际 residue 中完全自由的第三后缀坐标也求和后，
该**孤立配对**收缩到诚实源的 \(O_C(1)\) 维奇偶边缘；边缘源矩仍无地址尺度求值器。
完整 (515.426) 的离网格核、外层和与
\(B_0\) 绑定仍需另找共同且完整计价的地址尺度关系。
[完整域范数卷积的可逆源变换](notes/598-full-field-lagrange-norm-convolution-is-a-self-inverse-source-transform-2026-10-03.md)
证明：\(f(X)=N_{F/K}(\ell_0(X))\) 的所有完整域平移满足
\(\sum_Z f(Z+A)f(Z+B)=\mathbf1_{A=B}\)，故对应加性卷积自逆。
它作用于同一布尔源的范数插值时，在每个网格地址精确还原该源位；加入真实
\(\bar w_1(\zeta)\) 后，孤立三源范数的自由第三后缀和恰成为此可逆卷积，
不再是上一条的一位边缘收缩。两个单点源的响应在每个离网格地址皆为零，
其两点和的响应却处处非零，精确显示离网格非线性。实际 (515.426) 的整数商数、checker union、
第二源及剩余求和仍无共同地址尺度求值器。
[真实首个 late 等式支路的配对商数边界](notes/599-the-first-late-equality-branch-reaches-the-paired-quotient-only-through-prefix-overlap-2026-10-03.md)
证明：固定完整首前缀行后，\(a_uE^{\ne}(U,Z)E(\xi',\zeta')\) 的两支分别为
\(D_1\ell_0(X)\ell_0(X+Z_c)\) 与 \(D_2\ell_0(X)^2\)。第一支在 \(Z_c\ne0\)
时的每个 trace-plane 整数权重被 \(64\) 整除；第二支和 \(Z_c=0\) 的第一支
在等范数相邻平面抵消。因此该真实支路的配对首商数只能由两支的
trace-bit 交集除以 \(16\) 给出；若 \(Z\) 的任一 checked-prefix 位在网格上（包括零），
则该支路无配对贡献。
局部商数关于两支标量的每个布尔 ANF 单项式都同时使用两支，故第一支的
孤立范数卷积不能单独存活。
[真实相邻配对计数的第三源必要性](notes/600-the-reached-adjacent-pair-has-no-two-source-term-2026-10-03.md)
进一步证明：固定可达 \(001\) 后缀三元组后，把第三源积 \(B=A\bar w_1(\zeta)\)
设为零，完整 early--late checker 在一个自由第三前缀坐标上的次数小于 \(u_1\)，
所以等范数相邻平面配对商数逐行抵消。式 (515.426) 的配对系数中，所有仅依赖
两源积 \(A\) 的 ANF 单项式严格为零；实际固定后缀贡献须同时使用三处诚实源值。
首个 late 等式支路虽有局部交集，其完整第二前缀求和使单独配对恒零；第二等式支路
也单独配对恒零。late 配对计数只保留三向项的单独商数与两道支路间整数重叠；
完整 \(001\) 计数再加原有 early--late 重叠。第三源项、三道重叠、外层后缀和及
\(B_0\) 绑定仍须完整计价。
[受限 late 配对的第三源理想](notes/601-the-restricted-late-pair-has-an-exact-third-source-ideal-2026-10-03.md)
把上述两源消失式扩展到实际受限域 \(\mathcal V^\flat\)：排除域上若 \(v\) 在网格，
\(\Lambda(V)\) 迫使 \(V=0\)，第二等式与三向项此时恒零，第一等式在网格 \(Z\) 上逐行配对抵消。
故 late 配对的受限值与完整前缀值对任意形式源积 \(A,B\) 相同；令 \(B=0\) 后完整第三前缀行
使其为零。式 (600.10) 中三向单独项与两道 late 重叠的所有两源部分必须合计抵消，
不能把其中一道交叠单独当作真实同源信号。
[真实配对源矩的 \(\mathbb F_4\) 谱支持](notes/602-f4-spectral-support-of-the-reached-paired-source-moments-2026-10-03.md)
进一步利用实际相邻方向 \(s,\omega s\)：固定后缀的完整 checker 与受限 late 配对映射
在 \((A,B), (\omega A,\omega B), (\omega^2A,\omega^2B)\) 上异或为零。
结合第三源必要性及六阶 ANF，其域幂表示只含 \(B\) 指数非零、总二进制权重至多六、
且两个指数之和不被三整除的 \(m_1^{O(1)}\) 种同源矩；系数从已有公共表和已给定的后缀参数
以地址多项式成本构造。任何对全部形式 \((A,B)\) 正确、只通过齐次相对范数读取两源积的
非零候选式都与此谱条件冲突。实际诚实源的外层矩和及 \(B_0\) 绑定仍未求值。
[非不变源幂的完整域无权矩消失](notes/603-noninvariant-source-powers-have-zero-unweighted-full-field-marginals-2026-10-03.md)
精确分类六阶以内的单坐标无权幂和：对次数低于 \(u_1\) 的源多项式，只有相对范数指数
\((Q_1-1)/(u_1-1)\) 的 Frobenius 轮转可能非零，值由最高系数的相对范数给出。
这些指数都被三整除，而 Note 602 的真实配对矩仅允许不被三整除的第一、第二源指数；
因此若某个矩系数遗漏 \(\xi\) 或 \(\nu\) 的任一完整自由坐标，其外层和严格为零。
在第一个允许的五位源幂指数 \(u_1+\cdots+u_1^5\) 上，只乘一个公开等式核
\(\ell_0(X+Z)\) 的完整域和虽可非零，却仅取源最高系数的五项 Frobenius 乘积，
与地址 \(Z\) 无关。剩余项必须保留更高阶或更复杂的 checker 加权相关；这些条件
不证明剩余项非零或可在地址尺度求值。
[完整自由源坐标只留下六阶支路积](notes/604-complete-free-source-digits-project-the-reached-pair-to-sixth-order-branch-products-2026-10-03.md)
把三个 late 后缀核及七个 early 系数分别乘以前两源积 \(A\) 和第三源积 \(B\)，
形成固定、与后缀无关的完整前缀配对映射。该映射关于这些支路积的布尔次数至多六；
每个支路积沿任一完整 \(\xi\) 或 \(\nu\) 坐标的布尔次数至多 \(\mu_1\)。
因此实际可达 \(001\) 的完整外层异或严格消去支路积次数零至五，
只保留单个公共前缀映射的六阶极化；每个保留单项式还须使用至少一个第三源支路积。
每个公共六阶系数还可写成六副本、单坐标 \(F_1^3\) 局部和；局部和因 Frobenius
置换而严格落在 \(\mathbb F_2\)，故六阶层与完整前缀长度无关。实际外层配对因此
等于使用同一批真实后缀系数的形式一位前缀配对。仅取各单坐标指数的
\(\mu_1+1\) 个满权位置，还能由 \(\theta\) 的有限域幂和在地址多项式时间内
**均匀构造**这些公共六阶系数，无需枚举域或硬接局部表；同源六阶外层矩和与
\(B_0\) 绑定仍未求值。一个由实际 early 标签 \(e_{001}\) 与 \(e_{111}\)
组成的形式六阶非零项，在所选可达 residue 上因 \(e_{001}=0\) 被严格删除；
第一、第二 late 等式支路的六阶层则在满权指数上化为无 \(X^2Y^2Z^2\) 项的
八项范数形式，故两支物理 trace-bit 重叠在整个可达后缀和中严格为零。
三向 late 核的六阶满权部分也精确缩为同一个八项范数立方及三个显式
\((2u_1-3,\,3u_1/2-1,\,3u_1/2-1)\) 指数置换项。
循环位集铺砌进一步排除**所有**含这三项的六副本局部和。因此实际 late 与
完整 early--late \(001\) 配对都有同源外层范数公式 (604.32)：共同第一输入
\(C=(A+B)(c_1+c_2+c_3)\)，第二输入分别为 \(B c_3\) 与
\(B(c_3+e_{111})\)。完整公式已计入 checker union 和整数 trace-bit 重叠，
展开后只剩 42 类 checker 加权同源幂矩，每类第一、第二源指数都恰有六个
二进制位且不被三整除。仍需对真实离网格第三后缀求和、构造同一诚实源值，
并绑定 published \(B_0\)；
它不是地址尺度求值器。
[真实配对的同源双地址对角式](notes/605-the-reached-pair-has-a-two-address-diagonal-and-eight-norm-orbits-2026-10-03.md)
利用 Harsha 检验式对前两个同标签索引的交换对称及两道完整后缀和，把固定 published checker 的
完整 \(001\) 单项计数和实际 late 相邻配对精确压到 \(\xi=\nu\)。在 (604.32) 的
对角线上两道 late 等式核相消，整个完整 early--late 配对只使用
\(p=\bar w_1(\xi)\) 与 \(q=\bar w_1(\zeta)\) 两处同一诚实源值；若对角三向核为零，
完整配对也严格为零。其第二范数输入还精确等于实际 early OR-copy 门关系与理想零链
邻接表之差的规范插值；若该差在选定末位层为空，完整配对对任何源词都为零。
作为任意布尔网格源的函数，完整单项计数及两种相邻配对的源位
次数至多 12。式 (604.33) 的 42 个索引属于 8 个 Frobenius 轨道，其中
\(|I|=1\) 六项合并为一个显式绝对迹双地址矩 (605.6)，在完整 checker 中含五个
门偏离因子；互补的 \(|I|=5\) 轨道只含一个，精确写成实际 early 门关系上的
线性核和 (605.10)。这些真实离网格外层矩仍未证明消失或获得共同的地址尺度
求值器，也未绑定 published \(B_0\)。
[已发表基词的跳变强制可达 ledger 门偏差](notes/606-hard-base-word-transitions-force-reached-ledger-gate-defects-2026-10-03.md)
在 Notes 516--517 固定的合法、同源 stage-one ledger checker 中，连续 ledger 输入位
不是 OR-copy 门的输出，而理想零链在其相邻地址上有边；因此每个内部 ledger 地址
都有明确的 \(h+b=1\) 系数，且该偏差在可达离网格第三后缀上可取非零值。
已发表基词 \(B_0=0^{n_0}S_0\) 的电路下界还迫使
\(S_0\) 至少有 \(\Omega(n_0/\log^2 n_0)\) 处相邻跳变；除至多两个边界地址外，
这些不同末位层都在同一个实际可达期间，且同一离网格高元组上的第三源差
仍读取相应的 \(S_0\) 位。每条 ledger 边的五选择门核还可精确收缩一个完整
\((\xi_j,\zeta_j)\) 后缀坐标对：只余三个同源标量的共享 12 次布尔函数，
其公开非均匀表大小为地址多项式。这关闭了「真实 hard 地址上完全没有 early 门偏差」
这一局部解释；剩余源标量、长外层和及完整路由异或仍可能消失。该 checker 是固定的
合法序列化，不等同于 RW 论文指定了唯一门表。
[ledger separator 的局部非零迹轴](notes/607-the-ledger-separator-has-a-nonzero-local-trace-axis-2026-10-03.md)
进一步证明：五选择门核的共享局部函数在无 OUTPUT 截面 \(B=0\) 上，对第三源标量
\(R\) 的一次项恰为 \(A^{4M-2}\)。当 \(A\ne0\) 时，乘任一非零域系数再取绝对迹仍是
非零、次数至多六的布尔函数，至少在 \(1/64\) 的域值上为一；所以自由 separator
本身不普遍消去该局部门核。对同一个 published \(B_0=0^{n_0}S_0\)，共享前缀的
dyadic 电路还将可达跳变偏差数加强到
\(\Omega(n_0/(\log n_0\log\log n_0))\)。实际三个同源标量的取值与完整路由
外和仍未由这些局部结论确定。
[五选择轨道的第三源线性支路秩一投影](notes/608-the-five-choice-linear-third-source-branch-is-a-rank-one-free-digit-projection-2026-10-03.md)
证明一个与第一后缀值无关的完整域恒等式：任意两个次数低于 \(u_1\) 的第三位多项式
乘上对角三向核的指定五选择幂后求和，只留下两个最高系数的乘积。因此该轨道中
只取一次第三源值的支路，可把所有完全自由的第一、第三后缀位都精确压缩为
同一诚实源的 \(O_C(1)\) 维网格奇偶边缘；该支路的门核不再依赖两个门端点的自由高位。
在实际可达 hard-suffix 位上，配对源的边缘差仍是非零公开系数乘
\(S_0[x-n_0]\)，故该边缘差的完整地址求值仍需
\(\Omega(n_0/\log n_0)\) 电路。理想零链的聚合边奇偶严格为零，剩余真实 early copy 门的聚合
奇偶仍须计价；连续 raw-input 区间的门偏差在该聚合中也成对抵消，所以单个
ledger 跳变偏差不能直接从这条支路读出。保留坐标的域和、其余 31 个第三源支路
及七个范数轨道仍可能抵消。对其余第三源支路逐一求一个自由坐标时，门端点该位
至多一次出现；16 条不含最高 Frobenius 位的支路甚至与该门地址位无关。
只选最高位的支路有显式非零局部斜率，故这个一半消失的边界是尖锐的。
但在实际 separator 的纯零源截面 \(B=0\) 上，完整第一位域和又使该门地址位消失；
最高支路的完整局部斜率精确为
\(a_o^{-1}R^{1+2u^5}A^2B^{4u^5}(A+B)^{4(u+u^2+u^3+u^4)}\)，
要保留这种门地址依赖必须同时用非零的零截面、OUTPUT 截面和第三源截面。
实际 ledger 边的该位固定为零，故斜率不进入其值；最高支路在这些边上的常数项另有
式 (608.22) 的同源三标量闭式，在 \(B=0\) 时可非零。
[ledger separator 的完整第三源支路收缩](notes/609-all-five-choice-third-source-branches-contract-on-the-ledger-separator-2026-10-03.md)
将五选择轨道在该位的全部 32 条第三源 Frobenius 支路一并求和：实际 ledger 门端点
\(c_j=0\) 时，完整第三位域和恰为
\(R(1+RT^{2(u-1)})^{2(M-1)}\)，随后第一位域和也收缩为
\(R[(A+B)H^{M-1}+BH^U(RB^2)^{u^5}]^2\)，其中
\(H=(A+B)^2+RA^2\)、\(U=u+\cdots+u^4\)。任意第三门数字的完整局部斜率是
\(a_o^{-1}R^{1+2u^5}A^2B^{4u^5}H^{2U}\)；实际 ledger 数字为零，所以只使用常数项。
更进一步，这个正式多项式的每个分支系数均在 \(\mathbb F_2\)，故相同稀疏布局的任意多个自由高位对
重复收缩仍给出同一个三标量核；固定 stage-one checker 中每条 aligned-ledger 边的
\(\Omega(D)\) 个自由高位满足此布局。此幂等机制对各高位相同的第三门数字 \(c\)
恰在 \(c=0\) 或 \(c=a_o\) 时成立；其他数字的一个明确单项式系数在两位收缩后
从 \(c/a_o\) 变成 \((c/a_o)^2\)，不能直接套到完整 early 门表。
这个边局部高位块已有计入公开域表示的
\(O((\log Q)^2)\) 门求值器，不再需要
式 (606.7) 的大 ANF 表。只要第一源截面 \((A,B)\ne(0,0)\)，场值核作为 \(R\) 的函数
最多有三个零点（且上界可达）；乘任意非零常数后的局部绝对迹也必非零。若 \(R\) 沿另一自由
坐标是非常数的次数小于 \(u\) 多项式，点态零值至多出现 \(3(u-1)\) 次；但 \(A,B,R\) 的同源取得、
剩余可达后缀和、真实门表、其他七个范数轨道与完整路由异或
仍须计价。未得到完整地址尺度求值器。
[可达 hard-suffix 层的整张门偏差表收缩](notes/610-the-reached-five-choice-defect-contracts-across-the-whole-sparse-high-block-2026-10-03.md)
把上述边局部恒等式扩到固定合法序列化的完整五选择门和：原始门、局部比较器、聚合树与
零复制链在所选末位数字 \(g=\tau_x\)、\(n_0\le x<2n_0\) 上的每个非零真实偏差边，
其 \(\Omega(D)\) 个稀疏高位数字均为零。于是整个门表在这些自由坐标上只需一次
\(\mathscr J_0\) 收缩。两棵聚合树取不同子节点的完整二叉 OR 布局时，post/reference 的
重复输入 OR 边表相同；它们的五选择差分只保留同一个参考门表加权的源差分
(610.8)。在真实可达 ledger 前驱网格中心，\(0\to1\) hard-word 跳变的单个场值项
严格为零，且该第一地址的整条路由第三地址和为零；\(1\to0\) 跳变的同一地址切片
则先由一位完整域和消去非线性因子，再由其他自由位投影成参考源在
\(O_C(1)\) 个保留坐标上的奇偶边缘 (610.12)。这一边缘的取值仍须完整计价；
其余第一地址和、其他七个范数轨道、checker 标签和绝对迹抵消
尚未确定，因而该结果不构成已发表 hard word 的地址尺度 exact surface。
[可达 ledger 相邻双切片的稀疏支撑边界](notes/611-the-reached-ledger-neighbor-slices-vanish-off-sparse-source-residues-2026-10-03.md)
将 Note 540 已算出的部分余数用于 (610.12)：保留的最高域数字是
\(O_C(\mu)\) 个五维 \(K\) 仿射片之并。每个保留网格地址的公开布尔权重可用
\(\operatorname{poly}_C(\mu)\) 成本求值；同一可达 \(Q\)-周期内所有 hard-suffix
末位共用一张权重掩码，前一词位作为外侧系数。四种相邻位取值中来自第三源
增量的公开项都由部分陪集求和消去。
最高保留网格数字为零时，该权重由非零 \(K\)-陪集的缩放对称严格消失。
Note 411 的真实参考源在末位 \(x\) 避开至多两个稀疏输入/门余数类和一个例外门时，
恰只占这个零权重高数字。因此至少
\(\Omega(n_0/(\log n_0\log\log n_0))\) 个真实可达下降跳变，且所有普通
hard-suffix 末位的**完整第三地址和、固定 ledger 前驱与后继两个第一地址切片**
均为零。这两张切片及其和作为全词布尔函数仅可能支持
\(O(n_0/\log^2n_0)\) 个位置，具有 \(o(n_0/\log n_0)\) 门电路，
故不可能直接等于已发表 hard suffix。
其余第一地址、七个范数轨道、checker 标签与稀疏例外末位仍未判定。
[零填充输出输入形成完整非零数字偏差轨道](notes/612-zero-padded-output-inputs-form-a-nonzero-digit-defect-orbit-2026-10-03.md)
进一步界定了这一推广边界：对每个普通 hard-suffix 末位 \(x\)，取部分路由位
\(k=(C^2-19)/6\) 的任一非零 \(K\) 数字 \(d\)，零填充输出字段内相邻的两个
原始输入 \(a=r(d)u^k+x-1,\ c=r(d)u^k+x\) 均有诚实值零，但真实重复输入
OR 边为零、理想邻接边为一。因此完整真实门偏差表在该位并不只支持数字零；
这些 \(u-1\) 条边的和恰是
\(\theta(\xi_k,\xi_k,\zeta_k)+L_0(\xi_k)^2L_0(\zeta_k)\)，在共同
\(K^\times\) 缩放下不变，且在实际可达第三地址上非零。逐条边的支撑反例不能据此晋级成非零 JK 答案；
固定到每条边的第一网格地址时整条第三地址和仍为零，而非网格第一地址、
OUTPUT 截面、其余偏差边和范数轨道尚须完整计价。对这整族零填充边，
若形式上去掉 OUTPUT 截面与第一源中非零 \(k\) 数字，完整第一地址和
在可达部分陪集上也严格为零；其可能存活的响应只能借助这两个实际源通道。
该偏差轨道的对角核另有闭式
\(\theta(T,T,Y)=1+(T^u+Y)(T+Y)^{u-2}\)。结合常数维有界进位
系数提取，OUTPUT 通道在这一位的完整 \(F\times\mathcal A\) 求和
可从五个已供给的同源截面以 \(\operatorname{poly}_C(\mu)\) 成本精确计算；
纯 OUTPUT 局部响应是否作为场函数恒零，又等价于两个公共域系数
\(C_1,C_{1+2u^5}\) 同时为零。这两个系数可在地址尺度求值，但当前没有判定其值，
也没有求出同源截面或其余第一、第三坐标的对象尺度外层和。
[首地址末位对纯 OUTPUT 填充轨道的精确消去](notes/613-a-free-first-last-digit-annihilates-the-output-only-padding-orbit-2026-10-03.md)
进一步证明：对这同一批真实零填充偏差边，若第一源只保留共同 OUTPUT，完整自由
首地址末位求和在任何可达第三路由与绝对迹之前已经为零，且第三参考源可以保留。
证明用三个互异网格标签的场和恒等式；因此上述两个局部公共系数无论取何值，均不能单独
建立这批边的实际响应。普通 hard-suffix 末位若要由这批边产生贡献，必须使用
非零 \(k\) 数字的参考第一源，或 OUTPUT 与参考／扰动第一源的混合项；完整门表和其他范数
轨道仍未由此判定。
更一般地，这个自由末位的完整场和只依赖同一第一源的四个显式线性系数，其中承重
系数恰是相邻网格值之差 \(P(\tau_{x-1})+P(\tau_x)\)；它为零时整项消失。
配对真实源的这个系数差在所有场点等于 ledger 高位 Lagrange 因子乘以
\(B_0[x-1]+B_0[x]\)。这把已发表 hard word 的真实跳变定位到完整首末位收缩后的
必要源量；它并非充分条件，单点源 \(P=L_{\tau_x}\) 即有非零相邻差但收缩为零。
即使限于布尔网格源，仍可固定两个端点和前两个整线矩，同时改变收缩值；
最高半段系数 \(t\) 不能仅由这些量替代。
对布尔网格源，\(t^2=P'(\tau_{x-1})+P'(\tau_x)\)：导数差恰分成局部相邻位差
除以两个标签之差，以及遍及其余源位的 Cauchy 尾和。真实 ledger 线的局部项含
hard-word 跳变，gadget 线虽在两个端点取零，仍可能通过尾和进入该矩。
后续非线性和是否存活仍未判定。
[配对基奇偶性与 hard suffix 的 Cauchy 边矩](notes/614-the-paired-basis-parity-controls-hard-suffix-cauchy-edge-moments-2026-10-03.md)
进一步把同一 ledger 线的环境导数写成陪集插值的 \(r'+\kappa_Hr\)：固定时钟常数
\(L=\lceil\log_2(acD)\rceil\) 为偶数时，已发表 \(S_0\) 的电路下界迫使
\(\Omega(n_0/\operatorname{polylog} n_0)\) 条内部末位边有非零 \(t\)；可在基词生成前合法
选定足够大的 Solve 指数，使这条偶数分支沿一条无限 published 长度序列成立。\(L\) 为奇数时，
布尔值约束仍排除全部边同时为零，但未给密度。对布尔 \(K\)-值 ledger 线，
局部首末位收缩精确等于 \(h(a+(pa+m)t^2)^2\)。存在同尺度高电路复杂度词具有 \(a=m=0\)，所以硬度和
\(t\) 密度单独不能推出该收缩非零，更不能推出完整 JK 响应；实际 \(S_0\) 的这两个
矩及其与参考源、gadget 线在扩域 \(F\) 上的混合仍须确定；式 (614.14) 保留了这条
真实截面的全部 Frobenius 幂。两个公开可达离网格高截面的 ledger／gadget 系数矩阵
可逆，所以偶数分支中至少一个固定截面仍有
\(\Omega(n_0/\operatorname{polylog} n_0)\) 条非零的**配对源差** \(t\)-边。
实际共同 OUTPUT 所在的另一个自由高位还把局部混合响应化为四项稀疏多项式：
它在所有离网格值上为零，当且仅当四个同源系数全零；最高系数的消失有
精确的迹一判据 \((h_0/\delta h)^u+h_0/\delta h=1\)，其坏值只占 \(F_{u^2}\) 中
一个大小为 \(u\) 的陪集。实际参考源的系数及后续整域和仍须计价。
利用 ledger 网格点的非零常数项和两次多项式根数平均，可进一步选取仅用
\(O(\log u)\) 位描述的一组共同首地址高位值，使任意合法奇偶分支中，
上升与下降两种方向**各有**至少
\(\Omega(n_0/(\log n_0\log\log n_0))\) 条实际可达 hard-suffix 跳变边的完整首末位
**局部源因子**非零。下降边在路由末位上的第三源差恒为零，但共同参考第三源仍须计价。
这是稀疏高位整域收缩前的点值陈述；其余公开因子、
首地址求和、路由第三地址、绝对迹与其他范数轨道仍可能消去响应。
还可把 OUTPUT 分隔位选在该稀疏块之外：对同一批实际可达下降边，先完整收缩
稀疏高位块，再收缩首地址末位，所得配对核对共同第三源标量的**形式一次项**仍在
一组 \(O(\log u)\) 位描述的共同高位点上有
\(\Omega(n_0/(\log n_0\log\log n_0))\) 条非零边；保留的分隔位还有一个共同
可达第三坐标使其公开因子非零。此结论未计算实际第三源取值、其余首地址与路由和。
进一步，固定一条这样的下降边及其余路由第三坐标后，第三源在自由分隔位上恰为
\(r_xL_0(Y)\)。收缩核是次数至多 \(2M-1\) 的奇多项式；其一次项非零时，连同该位的
公开权重，在某个实际可达 \(Y\) 处非零**当且仅当** \(r_x\ne0\)。这把该局部存活问题
压到同一参考源的一个剩余截面值，但未证明它在足够多的下降边或同一个路由余量上非零。
[公共全一门线为实际可达下降边提供第三源](notes/615-a-common-one-line-supplies-the-reached-falling-third-source-2026-10-03.md)
给出另一种预先固定的合法 checker 序列化：在两份 checker 的同一空闲零链区域，
用一条取值恒为一的公共 NOT 门线替换 \(u\) 个零门位。它不改变已发表
\(B_0\)、后继 \(B_1\)、JK 已发查询或两线配对源差，且新增 raw block 可在
地址尺度计价。beacon 位必须取共同的离网格第三值：实际参考截面是
\(r_x(Z)=A_xL_0(Z)+cL_b(Z)\)，而非只剩公开的 \(c\)；每个 \(x\)
至多排除一个 \(Z\)，所以一个计价的 \(Z\) 可使所有合格截面非零。
[稀疏第三源谱与共同可达局部见证](notes/616-sparse-third-source-spectrum-gives-a-common-reached-local-witness-2026-10-03.md)
进一步利用完整 \(J\)-收缩核的 32 个第三源幂次：在阶为
\(M=(u^6-1)/(u-1)\) 的范数一群上，其非零响应至少有 \(M/486\)
个支撑点。因而一组新增计价仅 \(O_C(\log u)\) 位的共同第一、第三高位值，
使 \(\Omega(n_0/(\log n_0\log\log n_0))\) 条同一已发表 hard word 的
可达下降边在**完整 padding 边轨道的局部场项**上非零，包含全部留存高位
公开因子。完整自由第三位求和进一步精确化为
\(L_0(X)^2r_xH_x(r_x^2X^{4(u-1)})\)；非零局部项仍可能在这一步消去。
[双高位公共门块与完整自由第三位求和](notes/617-a-two-digit-common-beacon-survives-one-complete-routed-third-sum-2026-10-03.md)
把另一种合法 checker 的公共全一门块置于两个自由高位的非零网格笛卡尔积，
每个 raw \(W_1\)-块仍至多增加一条可显式计价的全一线。实际参考第三源在两个
范数一参数上成为双仿射式；稀疏谱支撑界遂给出一组新增计价 \(O_C(\log u)\)
位的共同坐标，使同一已发表 hard word 的
\(\Omega(n_0/(\log n_0\log\log n_0))\) 条可达下降边在**完整自由
\(Y\)-求和后**仍有非零局部场项。新增门块也产生其他真实门偏差；其余首地址与
路由第三地址之和、绝对迹及全部范数轨道仍未判定。若再完整求和两个 beacon
第三坐标，形式第三源一次项恰乘以实际背景差 \(A_x+c\)；其值及高次项
在真实参考源上尚未确定。
[相同 beacon 对的完整求和](notes/618-identical-beacon-pairs-diagonalize-and-recover-the-reference-cancellation-boundary-2026-10-03.md)
证明两首地址值相同时，交换第三坐标使非对角项抵消，完整 \(Y,Z_1,Z_2\) 和退化为
一个平方后坐标的和，并含有必要因子 \(A_x+c\)。
[完整 beacon 和的全变量系数投影](notes/619-complete-beacon-sums-project-to-the-full-source-monomial-2026-10-03.md)
把这个边界加强为无需交换对称性的恒等式：对任意两个首地址值，32 个第三源
Frobenius 分支的完整和只看实际第三源在两个 beacon 补变量中的乘积系数，
此系数恰为 \(A_x+c\)。因此 \(A_x=c\) 时该 padding 子表严格为零；只改变
首地址权重不能解除消去。实际 \(A_x\) 尚未求出，\(A_x+c\ne0\) 也不足以保证
完整 JK 响应非零。同一 note 还给出尖锐代数绕行：只在一对非零网格数字
放置全一门线时，抽象的非零常数项稀疏核即使在 \(A=c\) 也可有非零完整
双 beacon 和；这个单线布局沿用 Note 617 的合法 checker 构造，但尚未识别
实际边的高次核。其实际同源子表的完整和已精确化为 \((A_x+c)\) 项与仅含
第 5 Frobenius 位置的 16 支高次项之和；后者是下一项需判定的同源量，
其余地址和仍须计入。
[真实 hard word 的早期输出线密度](notes/417-hard-rw-output-lines-are-dense-before-the-crossover-2026-09-29.md)
由 RW 的 outsider 电路下界与共享半地址相等测试，推出每个成功阶段的实际 \(B_i\)
至少有 \(\Omega(n_i/\log n_i)\) 个 0 和同数量的 1。
因此基阶段的单条输出网格线含指数于地址长度的非零 Lagrange 项；若第一次后继
成功，也有一条实际输出线满足同样尺度的下界。这关闭了**显式列举非零网格点**
的固定 R2 候选，未排除非逐项的源专属关系。作尺度对照，固定 checker 的 one-hot
final OUTPUT 线在基阶段与首次后继都有不读 proof 值的地址多项式局部求值式；
它的全局 JK 索引仍为对象尺度，且该线不承载 \(B_i\)。同一门数优先编码中的
基阶段 \(B_0\) 还恰好位于 range 前沿：字典序前驱是实际 range 词，
\(\operatorname{CC}(B_0)\) 高于 \(0.1n_0/\log_2n_0\) 而至多高出
\(O(\log n_0)\) 门；此前驱本身的电路复杂度也在阈值以下
\(O(\log n_0)\) 门之内，故 range 成员资格仍不给出地址尺度求值器。
前驱的 \(n_0\)-bit seed 未获得地址尺度描述。把 \(B_0\) 直接定义为首个缺失词，
可写成不读取 proof payload、唯一确定同一词的固定 \(\Sigma_3\) 关系；
但量词字符串与矩阵均为 \(n_0^{\Omega(1)}\) 尺度，把该关系按字面代入第一次
\(BF_1=\operatorname{Solve}_{f_0}\) 仍需 \(n_0\) 位共同词变量，未通过 R2。
该固定 \(\Sigma_3\) 语义及前半零值已在 Note 615 给出；此处新增的是它在当前
门数优先轨道上的计价与首次后继代入边界。
[基阶段输出线的公开 coset 因子与 hard 残因子](notes/418-base-hard-output-line-factors-through-a-public-coset-selector-2026-09-29.md)
把 Note 615 的 \(B_0=0^{n_0}S_0\) 与当前加性子空间网格合并，得到同一诚实 proof
的形式多项式恒等式 \(p_0(X)=C(L_{H'}(X))r_{S_0}(X-c)\)。公开 coset 选择器
可在地址多项式成本内求值，并在全部 off-grid 点非零；因此 \(p_0\) 与
\(r_{S_0}\) 的 off-grid 域值访问一次查询等价。残因子在网格上的精确求值器仍需
\(\Omega(n_0/\log n_0)\) 布尔门。进一步，任何形式次数低于 \(Q_0-u_0\)、
在全部 off-grid 点正确的普通无除法算术电路，必与 \(p_0\) 形式相同，故其
门数至少 \(\Omega(n_0/(\log n_0\,\lambda_0^3))\)。
[公开子空间掩码的精确次数边界](notes/419-public-subspace-masks-sharpen-the-off-grid-uniqueness-boundary-2026-09-29.md)
进一步证明：\(Q_0-u_0\) 在要求网格值为布尔值后仍是尖锐边界；若同时固定实际输出线
在 hard suffix coset 外的所有零值，边界恰为 \(Q_0-n_0\)。两个等号处都有
\(\operatorname{poly}(\lambda_0)\) 成本的公开掩码，分别翻转全部网格值或仅翻转 hard suffix，
同时保留全部 off-grid 值。此成本只针对紧凑域标签，基阶段 JK 全局索引仍为对象尺度。
掩码不是第二条真实 RW 轨道；这些结果仍未给出第一后继的
闭合关系，也不排除高形式次数的 source-aware 全局关系。
[基阶段范围基数把真实首缺词压入公开四分之一 coset](notes/425-base-count-first-range-cardinality-confines-the-outsider-to-a-quarter-coset-2026-09-29.md)
进一步使用当前固定门数优先编码：基础生成器至多读取
\(d_n=2(q+1)+(2q+6)\lfloor0.1n/q\rfloor=(0.2+o(1))n\) 个种子位，
故范围至多有 \(2^{d_n}\) 个词。字典序首缺的实际 \(B_0\) 必在数值
\(2^{d_n}\) 以内，因而只可能在 \(2n\)-位表的最后 \(n/4\) 位非零。
反向利用已计价的共享小表电路，承载全部非零位的最短任意连续区间
\(t_n\) 满足 \(\delta n\le t_n\le(0.2+o(1))n\)，\(\delta>0\) 为常数；
故任何单个 dyadic coset 若容纳完整实际 support，仍有 \(\Omega(n)\) 个点。
这个公开 coset 上的残词仍有 \(\Omega(n/\log n)\) 电路复杂度；同一诚实
输出线的 coset 因子化维数降至 \(n/4\)，源支持与 off-grid 值共同给出
尖锐形式次数边界 \(Q-n/4\)，等号处仍有公开掩码歧义。残词长度为对象
尺度。第一次真实组合若 \(BF_1\) 成功，其输出一位计数还迫使至少
\(\Omega(n_0^{C-1}/\log n_0)\) 条不同网格线非零，
排除了把基阶段的单线因子原样扩成固定地址多项式数量线的闭合；
随地址选择大量真实线的关系仍未排除，首缺性质也未自动传到 \(BF_1\)。
另一方面，固定 count-first 规范 seed 的短支持给所有成功后继一个分支完整的
公开掩码：\(B_i=U_{i,0}0^{3n_i/4}U_{i,1}0^{3n_i/4}\)，且至少一段
\(n_i/4\)-位的 \(U_{i,t}\) 仍需 \(0.05n_i/\log_2n_i-O(\log n_i)\)
门。RW 真正选中的好词总是某次成功的 \(B_i\)，所以基阶段的末端 quarter
或后继的两个前端 quarters 覆盖全部选择分支；公开掩码不求出其中的值。
[单个 off-grid coset 的重构与全局线访问器下界](notes/426-one-coset-reconstruction-forces-global-off-grid-accessor-cost-2026-09-29.md)
证明任意次数小于网格宽度的诚实线，都能从一个公开网格外 coset 的全部值精确重构。
因此，若实际 \(BF_i\) 成功且 \(i\ge1\)，一个不读取 proof 的共同电路若对所有
输出线求这些值，完整计价后至少需要
\(\Omega(n_i/(\log n_i\,u_i\lambda_i))\) 门或描述位；
由 \(u_i=O(n_i^{1/C})\) 得地址指数下界。固定 PH 关系仍可支付足够量词位。
基阶段另有形式次数—门数边界：若代数候选在 off-grid 及公开零点上正确，
且次数至多 \(Q-n_0/4+r\)，则门数加 \(r\) 至少为
\(\Omega(n_0/(\log n_0\,\lambda_0^3))\)。这两项均不关闭一般 R2。
[数值首缺词关系的基阶段与首次组合计价](notes/427-numeric-first-hole-relation-pays-linear-value-width-through-the-first-rw-composition-2026-09-29.md)
将基生成器未读取的尾种子位删去并按有效门数计数后，可用总长至多
\(3d_n-m+3\)、固定 \(\Sigma_3\) 量词和 \(\operatorname{poly}(n_0)\) 矩阵
唯一指定实际 \(B_0\)，其中 \(m=\log_2(2n_0)\)，不读取 JK 或 PCP proof。
实际首缺整数的二进制位宽仍在 \([\delta n_0,d_n-m+1]\) 内；
即使在真实 \(BF_0\to BF_1\) 中将它作为
单一共享变量，仍需 \(2^{\Omega(m_1)}\) 位，\(m_1=C^2\log_2n_0+1\)。
若删去字典序最小性子句，在公开四分之一 coset 内的一个地址会得到 1，
而实际 \(B_0\) 在那里为 0。
因此这个固定的数值编码候选在基阶段和首次组合均未达到 R2 地址尺度；
非字面的源专属关系仍未排除。
[范围前驱闭合的非数值首缺词关系](notes/428-range-predecessor-closure-binds-the-actual-first-hole-but-pays-a-near-full-seed-2026-09-29.md)
用一个实际 range 前驱 seed 和 \(\forall r\exists s\) 的一步前驱闭合条件，
不用数值词变量即可唯一绑定同一 \(B_0\)，并排除上面的假阳性。
但每个满足条件的固定门数优先 seed 都使用至少
\(d_n-O((\log n_0)^2)=(0.2+o(1))n_0\) 位有效代码；即使在真实
\(BF_0\to BF_1\) 中全局共享这个 seed，仍超出地址尺度。
把全局闭合换成任意至多 \(2^{\rho n_0}\) 个相邻前驱的局部检查，
同一实际生成器在公开地址 \(2n_0-e\) 仍有假阳性，\(\rho>0\) 固定。
即使免费给出精确缺词计数，在 Note 427 的公开首缺词窗口内只保存固定模数余数仍会重复：
总余数位宽 \(s\le e-3=(0.2+o(1))n_0\) 时，该窗口内必有同余的
较晚缺词；允许扩至 \([0,2^e)\) 时，公开地址 \(2n_0-e\) 也出现假阳性。
相反，把模数作为 \(q+1\)-位全称量词、逐一检查 \(1\le p\le n_0\)，
在语义上足以精确识别缺词 rank 为一：这些模数的最小公倍数大于
\(2^e\)。但直接同对象关系仍需 \(e=\Omega(n_0)\) 位候选词，改用真实
range 前驱 seed 也需 \(d-O(q^2)=\Omega(n_0)\) 位；模计数求值尚未计价。
这些结论关闭固定字面 seed、局部前驱与固定模数 rank 指纹候选，
不排除更紧的候选值界、可求值的量化模数、生成式 seed 或其他非数值关系。
[成功后继的近门槛 canonical seed](notes/420-successful-rw-successors-force-a-near-threshold-canonical-range-seed-2026-09-29.md)
给出实际成功分支上的另一项定位：首个 JK NO 块是两个真实 range 父块的
canonical seeds 拼接；至少一个父块需要 \(\Omega(N/\log N)\) gate records，
且同一父块的 seed 作为 \(N\)-bit 词有 \(\Theta(N/\log N)\) 电路复杂度。
去掉零填充和两个短字段后，该 canonical gate-record 区仍有
\(\Omega(N/\log N)\) 电路复杂度。这是完整计价的同轨道下界；记录位仍无
地址尺度公共描述，因而不构成 R2 的正向闭合。在 \(T_i=N\) 的稳定成功阶段，
实际父块的层号、块号及父侧本身只需 \(O(\log N)\) 位，定位成本已可硬编码；
记录位的 \(\Omega(N/\log N)\) 下界仍在。基阶段全局索引较长，但其位宽本身
不能证明所选索引的描述复杂度高。若在无界多的稳定成功阶段为这些实际记录位
建立统一、完整计价的固定 PH 地址关系，则该下界与 \(SAT\in P/\mathrm{poly}\)
矛盾；这样的取值关系及分支覆盖仍未得到。把完整 canonical gate list 原样量化
需 \(\Omega(N)\) 位，已在这条真实成功分支上超出地址预算。
[较早 RW 输出作为 oracle 的量词位下界](notes/421-earlier-rw-words-require-near-full-address-quantifier-volume-for-canonical-records-2026-09-29.md)
进一步把这个实际 hard record 用于完整计价的交替谓词：若矩阵、建议串和较早输出词
查询数均为地址多项式，且仅允许按位查询 \(B_0,\ldots,B_i\)，则任意精确谓词的
量词总位数至少为 \((1-1/C)m-O(\log m)\)；没有这些 oracle 时至少为
\(m-O(\log m)\)。因而仅量化少于 \(C-1\) 个前驱地址大小的变量不能产生
真实成功分支的记录位，不论交替顺序。在稳定阶段，全部与整段 padded
output 区相交的诚实低次数 proof 线值可由 \(B_i\) 位、公开零位和至多两条
边界线的短建议串插值恢复，
因此只读取这些线值的关系服从同一量词位界；只读取预先固定的地址多项式
数量的任意诚实 proof 线时，量词总位数甚至至少为 \(m-O(\log m)\)。
同一展开论证也作用于 RW 首次失败时真正交付的前一轮 hard word，故上述
较早输出词模型的量词位障碍不依赖稳定成功阶段无限多。
更一般地，若关系在全部地址及量化赋值下实际触及 \(K\) 条诚实
\(\widehat w_i\) 线，无较早输出 oracle 时必须有
\(v+\log_2(1+K)\ge m-O(\log m)\)，其中 \(v\) 为量词总位数。
遍历足够多其他 proof 线、当前尺度 range 谓词和使用更多地址尺度量词的
源专属关系仍未排除。
[首个已到达 JK 逆层的规范门表长度](notes/422-first-reached-jk-inverse-has-an-object-scale-canonical-gate-list-2026-09-29.md)
把真实源词 \(B_i\) 留在第一个顶层块中，用地址平移将其电路下界传给该块
的最小门数。只要 \(BF_i\) 成功，顶层全 YES 后实际形成的首个下层块左半
含有至少 \((0.2C-o(1))n_i=2^{\Omega(m)}\) 个 canonical gate-record 位；
基阶段该长度恰为 \((0.2C+o(1))n_0\)。因此在**第一次真实组合**
原样量化整张规范门表已超出地址预算，且不依赖 \(BF_{i+1}\) 后来成功。
门表长度本身并不下界其逐位求值电路；非字面的源专属关系仍未判定。
[稳定阶段原始证明线与历史活位的精确等价](notes/423-stable-rw-raw-lines-reduce-to-constant-many-live-history-bits-2026-09-29.md)
在相同固定 compiler 中，稳定阶段 \(u_i=O(m_i)<g_i=\Theta(m_i^2)\)。
每条 post-output 原始网格线至多有四个公开候选活位；其所有 off-grid 域值
是这些真实历史位的公开线性组合，反向可从至多四个同一诚实 proof 的 off-grid
域值恢复全部活位。两方向均完整计入域运算和全局证明位地址。因此该区域
的代数 proof 访问精确收缩为原始历史活位访问；后者的短同对象关系、早期
组合与首个 JK NO 仍需证明。结合 Note 421，若一个低量词位的关系只查询
较早输出和这些原始线，则 \(v+\log_2(1+L_i+K_{\rm live})\ge m-O(\log m)\)，
其中 \(K_{\rm live}\) 只计实际可达且具有公开候选活位的线。
[真实 alias 查询把前驱词嵌入后继历史活位](notes/424-reached-alias-query-witnesses-embed-the-predecessor-word-2026-09-29.md)
补上一个具体的活位来源：若 \(BF_i\) 成功，顶层已到达的第 \(\rho_i+a\) 个
JK 搜索批次中，固定前缀 \(10^{b_i-1}\) 的查询答案恰为 \(B_i[a]\)；
在文中固定的种子坐标透明 NP 见证约定下，其规范见证的指定前缀位为
\(1-B_i[a]\)。该约定已具体化为恰有 \(N=n_{i+1}\) 个种子输入的
Circuit-SAT 查询，符合 RW 第 3 节的见证长度模型；任意另选的 SAT
变量编码仍须单独提供计价后的种子坐标映射。稳定阶段可在同一诚实
\(\Pi_{i+1}\) 中，以至多四个 off-grid 域符号和地址多项式控制读出该位。
因此即使 \(BF_{i+1}\) 后来失败，该后继 proof 的逐地址电路复杂度仍至少
为 \(2^{m/C^2-O(\log m)}\)，\(m=\log_2(2n_{i+2})\)。更精确地，若
\(\log T_{i+1}\le m^{O(1)}\)，同一读出仍以地址多项式数量的域符号、控制和
物理索引成立；在交叉点前固定距离的阶段，仍只需四个符号。因此首次失败若
落在该窗口，读出绑定 RW 真正选中的同一个 \(B_i\)，但 proof 值本身仍无短
关系。若首败前驱与交叉点相距 \(h=i^\star-i\)，这条字面索引路线有统一地址多项式
计价当且仅当 \(h=O(\log m)\)；当 \(h=\omega(\log m)\)，proof 索引长度已超预算。
同一窗口的旧 Note 416 已能从重构所用 \(\Pi_i\) 的输出线读出 \(B_i\)；此处
新增的是后继规范历史中的强制单活位编码，不能把原有同 proof 附着算成新结论。
对这一编码还有精确的线扩散边界：若 \(v\) 个量词位的短矩阵只读取更早输出
和 \(K_{\rm live}\) 条后继历史活线，则
\(v+\log_2(1+L_i^-+K_{\rm live})\ge\log_2n_i-O(\log m)\)，
其中 \(L_i^-=|B_0\Vert\cdots\Vert B_{i-1}|\)。低量词位时至少需要
\(n_i/m^{O(1)}\) 条线；实际逐地址读出使用至多 \(2n_i\) 条，指数尺度相合。
这仅排除少量固定 proof 线构成的替代接口，仍允许随地址选择大量真实 proof 线。
同一固定 Circuit-SAT 编译下，单条实际已发出的顶层 JK 查询的门表描述
\(D_i\) 也含有 \(B_i\)：公开的 \(O(\log N)\)-位地址映射从比较器常量记录
逐位恢复该词。因此 \(\operatorname{CC}(D_i)\ge
0.1n_i/\log_2n_i-\operatorname{polylog}N\)，基阶段亦然。
把查询本身当成免费短输入会预先隐藏目标词；字面 query-as-relation
候选在首次组合前就已支付不起查询描述、\(N\) 位种子和 \(N^4\) 生成器。
基到首次后继的同一投影需 \(\Theta(n_0)\) 位物理地址，仍未通过 R2 的第一次组合。
更晚阶段若字面 proof 索引已是 \(m^{O(1)}\) 位，基词 \(B_0\) 也只有
\(m^{O(1)}\) 位，单靠传递它不能保留超多项式硬度；需要接近当前尺度的
真实 hard word 或非字面的全局关系。
[已到达 alias 见证位的精确敏感性](notes/429-reached-alias-witness-sensitivity-is-the-predecessor-rw-word-2026-09-29.md)
给出另一种同对象结构投影：在真实后继的规范 Lemma 3.2 history 中，
只翻转上述见证位后，原始 checker 的接受值恰为 \(1-B_i[a]\)；
局部 tableau 替代版需对翻转后的 history 重新量化扩展，不能沿用旧扩展。
因而任何共同、完整计价的逐地址敏感性电路都需
\(\Omega(n_i/\log n_i)\) 门，首次组合仍是地址指数尺度。
在冻结 history 的函数化候选中，YES 查询的该位是每个正确值短路策略的必经
敏感输入；NO 查询的全一填充
只由字典序规范选出，翻转后仍满足原始 checker，故活叶出现与否只给单向信息。
该结果关闭把规范 history 免费冻结为函数电路源常量的 R3 候选；
真正计算 history 的编译器及其完整 subtree/depth/heavy-run 三元组仍开放。
[全真 check 链的精确代价与真实根边界](notes/430-true-check-chain-does-not-supply-the-fixed-source-r3-root-2026-09-29.md)
给出串行 AND 根的 \(K=K_0+L+\sum_s K(c_s)\)、低 weighted-depth 定向及
heavy-run 的前缀比较条件；但该验证器的 `out` 和 tableau 是自由输入，接受门不能
替代从正则源计算 \(B_n[j]\) 的 R3 根。冻结真实 `out` 为共同源常量又须支付
\(\Omega(n/\log n)\) 的 hard-word 电路代价。
[R3 短策略覆盖密度边界](notes/431-hard-rw-word-forces-many-uncovered-r3-output-addresses-2026-09-29.md)
进一步在 \(P=NP\) 反证分支证明：对任一固定 source-compatible 编译器和任一固定
\(m^C\) 完整资源界，在同一 published hard word 的充分大 good lengths 上，
零位和一位各有
\(\Omega(n/\log n)\) 个真实输出地址不能由该界内的 Note 600
策略覆盖。证明把已覆盖地址的 \(\Sigma_2\) 证书判定器与共享半地址补丁
合成，再应用 C455 下界；在同一反证假设下，还可用多项式地址时间定位一个
两种候选位都无短证书的真实输出地址，但仍未判定失败的是哪项 R3 资源。
对四门基且输出门可局部定位的固定编译器，把至多 \(T\) 节点的真值展开树
显式列为 NP 证书后，还得到一个
定量 raw-tree 下界：存在 \(\varepsilon>0\)，零位和一位各有
\(\Omega(n/\log n)\) 个真实地址的最小树超过 \(N^\varepsilon\) 节点。
这不排除指数节点树具有地址多项式的计数或重链摘要。
[最终查询门的因果切口](notes/432-causal-final-query-gate-is-mandatory-in-a-fixed-base-reconstruction-compiler-2026-09-29.md)
把 R3 输出锥继续缩小：对固定输入的无环布尔电路，删除一个门方程后的布尔解恰好是
真实赋值和翻转该门后重算下游的赋值；该门方程在每个代数反证中必需，当且仅当
翻转会改变输出。这个判据不等同于局部展开树是否访问该门。
在首次 \(BF_1\) 失败的真实分支，\(r_0=0\) 使
\(\operatorname{Reconf}_0(j)\) 只有一条最终 prMA 查询；一个固定、完整计价的
模块化编译器可暴露其 \(D_{\rm all}\) 返回门，真实输出根在公开 advice-AND
适配器下满足精确的一步 \(K,d\) 递推。若只用共同控制电路逐位探测该条
局部生成的 query 描述，则控制门数加探测成本须达
\(\Omega(n_0/\log n_0)\)；即使只要求共同取回所有返回门的真实值，
该取值电路也须达同一门数下界。更精确地，输出 AND 门与返回门的最小
展开树计数之差恰为 \(1+B_0[j]\)；共同读取这两类门的**计数奇偶位**也须
\(\Omega(n_0/\log n_0)\) 门；即使只覆盖 Note 615 的后半段 hard suffix，
下界仍成立。此界不排除逐地址另选的策略描述。
对实际基词的公开前半段 \(B_0[1:n_0]=0^{n_0}\)，同一最终查询后接一个 COPY 或
AND-1 门会保持子树计数却使 weighted depth 与第一条 heavy edge 的 atom
数各差一；因此论文的查询语义不能代替对终端门型的固定。本文固定 COPY 接口。
即使门型固定，实际输出 AND-1 的 reflected orientation 仍可把 multiplier
放到 heavy child：前两步 \(\operatorname{WeightCount}\) 便对零位和一位都等于 1，
weighted depth 至多比另一方向增加一。因此只在选定 orientation 下，
\(\operatorname{WeightCount}(o_j,2)=1-B_0[j]\) 才给出共同摘要的 hard-word 下界；
它不是所有合法策略的内在下界。根的 arity/轻子存在位却在每种合法策略中
都等于 \(1+B_0[j]\)/\(B_0[j]\)：对 hard suffix，任何共同预测电路的门数加错误
地址数仍须达到 \(\Omega(n_0/\log n_0)\)。逐地址策略可把该位放进已计价 descriptor。
同一真实首败分支上，对任意固定的 \(D_{\rm all}\)，hard suffix 的零位和一位各有
\(\Omega(n_0/\log n_0)\) 个查询需运行超过某个固定常数倍的
\(\sqrt{n_0/\log n_0}\) 步；这是实际运行时间下界，不给出返回门的 exact R3 三元组。
对多项式资源的存在性问题，可无损固定 reflected orientation；根的前两步完整
heavy-run 摘要因此成为公开常量，后续摘要精确归约到 \(v_j\)。
返回门内部的完整三元组以及
\(BF_1\) 失败是否在无限起点发生仍开放。
[RW 最终查询的满长前缀修正](notes/433-full-prefix-terminal-query-in-rw-reconstruction-2026-09-29.md)
核对原始 PDF 后指出：Theorem 4.1 若在最终查询沿用前缀查询的 \(p\circ1\)
测试，因长度超过完整前缀而恒为 NO。最终查询改检验满长 \(p\) 与输出位，
由同一定理的 completeness/soundness 论证得到承诺查询；在 \(r_0=0\) 基例，
前缀测试为空。Note 432 使用这一明确语义。
[基例 NO 单向无条件性与 hard suffix 的双侧 R3 缺口](notes/434-base-no-side-is-unconditional-and-r3-gaps-lie-in-the-hard-suffix-2026-09-29.md)
利用空前缀及 Theorem 3.5 soundness 证明：任意基长度的最终查询只要对应
\(B_0[j]=0\)，即使 \(BF_1\) 成功也在 prMA NO promise；公开前半段
\(0^{n_0}\) 因而全为这种查询。在真实 \(BF_1\) 首败分支，把 Note 431 的
稀疏补丁论证直接限制到仍有 \(\Omega(n_0/\log n_0)\) 电路复杂度的后半段，
得到对任一固定编译器、任一固定资源指数，零位和一位各有
\(\Omega(n_0/\log n_0)\) 个无短策略地址；两候选位都无
证书的首个地址也可在地址多项式时间定位。对 Note 432 的固定模块化编译器，
相同密度的缺口进一步落在实际 \(D_{\rm all}\) 返回门的子锥中。
该返回门方程对每个基例输出位的代数反证也不可省略。
更强地，在该真实首败分支，后半 hard suffix 的零位和一位各有
\(\Omega(n_0/\log n_0)\) 个地址，其返回门的最小展开树超过
\(n_0^\varepsilon\) 个节点；这仍不决定 succinct \(K\) 电路的成本。
该结论仍条件于首败分支出现，不判定失败的具体 R3 资源。
[显式真值 DAG 的不同门下界](notes/435-hard-rw-outputs-require-large-explicit-truth-dags-2026-09-29.md)
把上述 raw-tree 结论推进到允许共享重复门的证明 DAG：在 \(P=NP\) 下，同一 published
hard word 的充分大 good lengths 上，零位和一位各有 \(\Omega(n/\log n)\) 个输出地址，
任何正确短路真值 DAG 都须包含 \(n^\varepsilon\) 个以上不同物理门；若实际基例
\(BF_1\) 失败，此下界也分别落在 hard suffix 的真实 \(D_{\rm all}\) 返回门上。
因此多次重访少数门不能单独解释此前的巨大展开树；可由小电路描述的巨大 DAG、
exact \(K\) 与 heavy-run 摘要仍未受此界排除。同一证书密度论证还覆盖允许全局消去的
**显式稀疏 Nullstellensatz 恒等式**：两种位值各有相同密度的地址，其逐项列出、
完整计价的反证长度超过 \(n^\varepsilon\)。电路生成的长恒等式及其 cancellation
pairing 仍是另一种待检验的 succinct 接口。在实际 \(BF_1\) 首败基长度，
Note 435 还把长运行、不同门数、显式反证长度与无短 R3 策略四项结论对齐到同一批
零位和一位地址，每种各有 \(\Omega(n/\log n)\) 个；这个交集仍不能定位失败的
具体 R3 资源，也不证明首败基长度有无限多个。对 C455 已保证的无限 good lengths，
同一合并论证以任意固定 published-word 坐标机代替终端 \(D_{\rm all}\)，在整个 hard word
上给出无首败条件的同地址密度结论。
[真实首败返回门的非局部证书缺口](notes/456-actual-first-failure-return-gates-have-large-truth-trees-and-no-short-nonlocal-pairings-2026-09-30.md)
把该交集的第四项直接改为**完整** Note 596 raw occurrence-pairing 关系：在
\(P=NP\) 假设与实际 \(BF_1\) 首败基长度上，对任意固定完整计价预算，hard suffix 的零位和一位各有
\(\Omega(n/\log n)\) 个相同地址，其真实 \(D_{\rm all}\) 返回门同时需
\(n^\varepsilon\) 个以上不同真值 DAG 门、\(n^\varepsilon\) 以上长度的显式
Nullstellensatz 反证、超过 \(\lfloor\eta\sqrt{n/\log n}\rfloor\) 步的实际 decider 运行（固定 \(\eta>0\)），
且两种候选位都无该预算内的非局部配对。任意固定层数的真实物理前驱链上，
也可在向根端逐层放大固定预算后定位两侧证书缺口；这使用 Note 596 允许的
非局部配对与门方程的布尔公理组合，没有改动固定编译器。固定层数的前驱链
仍可能停在原有补齐段，也不继承同地址的真值 DAG 或运行下界；返回门的
exact subtree count、weighted depth 和 heavy-run 摘要仍未确定，首败分支也未证无限出现。
[常宽吸收态的完整配对与首停机缺口](notes/457-bounded-width-absorbing-runs-have-succinct-global-pairings-2026-09-30.md)
证明任意固定宽度、对所有事件闭合的吸收态沿 \(L\) 步传输时，可用中点状态分拆构造
ordinary-polynomial 的 Note 596 全局 occurrence pairing：次数 \(O(\log L)\)，
term/partner/address 电路为 \(\operatorname{poly}(\log L)\)，所有端点与布尔公理完整计价。
把 Note 432 许可的一个模块化编译器明确选成 sticky halt flag 与 return-bit 双寄存器后，
真实首败返回门的上述密集非局部缺口不能只停在停机后补齐段：在同一批 hard-suffix 地址，
首次停机时的 halt 位或返回位至少有一个缺少指定预算的双侧证书。这个选择没有给出
停机时刻的共同地址尺度定位器，也不适用于尚未规定该双寄存器的其他固定编译器；
内部 \(K,d\) 与 heavy-run 三元组仍未确定。相反，所有停机后返回寄存器均为因果必经门，
所以 \(K(v_j)\ge T_n-\tau_j+1\) 可完全由补齐段贡献；全局配对缺口不能仅由这段解释。
局部 ANF 恒等式进一步把同地址缺口定位到最后真实活跃步的 halt-event、return-event
或此前 halt 位三者之一；return-event 方程在每个输出错误反证中因果必需。
[停机前事件缺口的地址尺度定位](notes/458-prehalt-event-gaps-have-address-scale-locators-2026-09-30.md)
把此前 halt 位进一步消去：其普通多项式真值恒等式沿时间直接望远镜相消，
只需停机前各 halt-event 为零的临时方程，基式次数为 2。在 \(P=NP\) 下，
固定预算的完整 Note 596 证书可通过 \(\Sigma_2^P=P\) 的前缀搜索统一选择，
生成器与配对电路仍为地址多项式大小。因此同一批首败 hard-suffix 返回门的
双侧证书缺口，必落在首次停机之前或当步的 halt-event，或者首次停机时
因果必经的 return-event。不预知首停机时刻，也能比较最早的 halt 双侧缺口
与最早可认证的一值 halt 事件，在地址多项式时间定位上述二选一门。
前一种门未必是因果必经门；结论仍条件于实际 \(BF_1\) 首败且不推出一般电路下界。
同一望远镜与定位论证还适用于另一个固定的 published **整词坐标机**编译器：
在 C455 已保证的无限多个 RW good lengths 上，计入原有一位 source advice 后，
每种输出位值各有 \(\Omega(N/\log N)\) 个地址，其真实坐标运行出现上述二选一
活跃事件证书缺口，并可从 \((n,a_n,j)\) 在地址多项式时间定位；可选首个
同对象根缺口地址。此扩展不把整词坐标机的事件门等同于基例首败的最终查询门，
也不提供输出位 accessor 或 exact surface。
同一 published hard word 还给出编译器范围的边界：固定编译器可把输出位
写进首停机时刻、把 return-event 做成公开时间常量；此时两侧根缺口可与
halt-event 缺口同地址稠密出现，而最后 return-event 有短证书。
这不否定上述明确选定的编译器；要把缺口一律压到因果必经返回事件，
必须证明该编译器的真实 halt-event 有短证书。
[真实零返回门的局部 weighted-depth 边界](notes/459-actual-zero-return-padding-forces-linear-weighted-depth-but-has-short-global-pairing-2026-09-30.md)
把双寄存器返回更新固定为两项 AND 与 XOR 的字面 ANF 后，每个停机后零返回步
都强制 Definition 598.1 策略穿过唯一零子 \(r_t\)，并增加一个 \(X_{h_t}\)
multiplier atom。因此 \(d(r_T)\ge T-\tau\)。一次性选取留有已知多项式余量的
公开时钟，在真实首败的零位及 published 无限 good lengths 的整词零位上，
给出 \(2^{\Omega(q)}\) 的实际物理门 weighted-depth 下界，关闭这个固定编译器的
低深度 R3 策略路线。同一吸收后缀仍有 Note 457 的 \(O(q)\)-degree 全局
occurrence pairing；此界不适用于所有编译器，也不排除完整非局部证书。
[平衡首次停机摘要的低深度外层编译](notes/460-balanced-first-halt-summary-removes-return-padding-from-weighted-strategies-2026-09-30.md)
给出同一事件流上的二位区间半群：区间摘要 \((P,R)\) 记录是否出现 halt，
以及从未停机态进入时的最终返回位；左右区间按
\((P_L,R_L)\star(P_R,R_R)=(P_L\lor P_R,\,P_LR_L+(1+P_L)R_R)\)
组合。固定平衡电路与串行寄存器对所有布尔事件赋值语义相同，门地址和局部方程仍为
\(\operatorname{poly}(q)\)。给定真实首停机时刻，其可随机访问的局部外层策略
weighted depth 为 \(O(q)\)，只向停机前/当步 halt-event 和停机当步 return-event
开真值端口；乘子仍可引用未展开的停机后变量地址。若这些真实事件有统一低资源策略，外层可直接合成
完整 Definition 598.1 策略并经 Note 598 进入完整配对；当前缺的是实际事件策略，
而非返回补齐段。把事件端口暂计作单节点时，外层的 exact subtree count 与
heavy-run jump/atom 也有 \(\operatorname{poly}(q)\) 电路；接入真实事件子树后，
单个事件的计数访问不自动提供整段所需的精确成本汇总。进一步把外层开放策略
用 Note 598 编为完整计价的临时方程配对，再用 Note 458 统一选证书逐端口替换：
若所有这些真实事件各有固定预算的完整 Note 596 证书，则同一平衡返回根也有
固定预算证书。因此 published hard word 的根缺口在这个编译器中仍向真实活跃事件
转移；已排除的是补齐段表示障碍，尚未得到事件的正向短证书或输出位 accessor。
[同一活跃事件的显式与 succinct 三重缺口](notes/461-simultaneous-explicit-and-succinct-gaps-at-one-active-rw-event-2026-09-30.md)
把短真值 DAG、短显式 Nullstellensatz 反证与固定预算完整 Note 596 配对先合成
一个可靠的事件测试，再对首次停机时刻取量词。在 \(P=NP\) 下，published 无限 good
lengths 上每种输出位各有 \(\Omega(N/\log N)\) 个同对象地址，使首次停机前或当步的
**同一个**真实事件门同时满足 \(\sigma,\lambda_{\rm NS}>N^\varepsilon\) 和双侧完整配对缺口；
其任一真值展开访问超过 \(N^\varepsilon\) 个不同物理门。该门可在严格次于对象尺度的
\(N^\theta\) 时间定位，但本论证不提供地址多项式的三重缺口定位器，亦不判定
weighted depth 或 exact surface。另一方面，每个预先固定的 \(d\) 都可把大小至多
\(q^d\) 的显式 DAG 或代数反证完整编成某个固定预算的 Note 596 配对；故 Note 458
的 \(q^{O_d(1)}\) 定位器可找到同一活跃事件，其两类显式成本及任意真值展开的
不同物理门数都超过 \(q^d\)。这里的事件和定位器允许随 \(d\) 改变，不能据此
宣称地址尺度地定位 \(N^\varepsilon\) 下界。
[平衡返回的 bad-hit 多项式](notes/462-bad-hit-polynomial-relaxes-prehalt-event-certificates-for-the-balanced-rw-return-2026-09-30.md)
进一步削弱外层所需的停机前证书。令 \(B_I^b=P_I(R_I+b)\)，它表示区间首停机
返回错误；左右摘要满足一个含真实门方程与布尔公理的常数大小普通多项式恒等式。
在 \(P=NP\) 下，若首次停机的 \(p_k=1,z_k=b\) 有固定预算完整配对，且每个
\(t<k\) 至少有 \(p_t=0\) **或** \(z_t=b\) 的固定预算配对，则同一平衡根有
完整计价、地址多项式的配对。published hard word 的强制规模因而要求：首次
停机当步有缺口，或某个停机前时刻两种候选声明同时缺口。对 \(t<k\)，\(p_t\)
方程恰在 \(z_t\ne b\) 时为该平衡根的因果必需方程；这给出比逐个要求
\(p_t=0\) 更贴近输出语义的边界，但尚未压缩实际事件生成器。
同一证明还只需逐时刻为二次多项式 \(p_t(z_t+b)\) 提供完整计价的开放配对端口；
该端口是比两个单门真值证书更弱、但必须回到事件生成器构造的精确接口。
[坏停机端口的切口判据与同词可达边界](notes/463-bad-hit-cut-criterion-and-sharp-same-word-event-split-2026-09-30.md)
给出精确局部判据：切口内的门方程能导出 \(p_t(z_t+b)=0\)，当且仅当每个满足
切口约束的布尔边界赋值都无错误停机；它不保证短配对。两个固定包装器在同一
published hard word 的真实运行上分别实现「坏停机端口全短、首停机声明困难」和
「首停机声明公开、一个坏停机端口困难」；另一固定包装器还使困难的坏停机端口
及两个事件门同时出现，而两个事件门各自都非因果必需。这些是编译器范围的
精确边界。对原有固定事件流，另有同对象定量结论：published good lengths 的每种
输出位都有 \(\Omega(N/\log N)\) 个地址，首次停机声明或同一个真实坏停机叶端口
同时承担 \(N^\varepsilon\) 以上显式证明长度与固定预算完整配对缺口。仍未判定
哪一侧出现，亦未给出输出位的地址尺度 exact surface。
[公开哨兵与首次错误停机端口](notes/464-sentinel-masked-first-wrong-hit-ports-remove-the-first-halt-certificate-2026-09-30.md)
把平衡事件树的最后叶固定为停机哨兵，并令 \(Q_t^b\) 为坏停机叶乘上此前无停机的
左兄弟摘要因子。所有 \(Q_t^b\) 在真实正确输出上都为零；一个普通多项式望远镜
恒等式把它们完整计价地合成根证书，不再单独要求真实首次停机时刻或 \(p_k=1\)
证书。在 \(P=NP\) 下，published good lengths 每种输出位的
\(\Omega(N/\log N)\) 个地址必有至少一个 \(Q_t^b\) 的固定预算端口缺口；
单个公开哨兵时，该缺口可能落在合成末端，不能据此定位真实事件生产器。
[双哨兵同电路把缺口压回真实事件时间窗](notes/465-two-sentinel-returns-force-masked-port-gaps-into-the-actual-event-producer-2026-09-30.md)
在一个完整电路中共用原始事件流，加入末端分别返回零、一的两棵平衡树；候选位
只选择已存在的一棵。两棵树在固定源上均输出同一个 published hard word，且各自的
末端及公开补齐叶都显式有短端口。因此每种输出位的
\(\Omega(N/\log N)\) 个地址，必在原事件生产器的 \(t<U\) 时间窗内出现真实零值
\(Q_t^b\) 的固定预算完整配对缺口。它可在首次停机之后，尚未构造正向短配对或
地址尺度 exact surface。若后续真实事件的 \(p_t=1,z_t=1-b\) 均已有短真值证书，
该时刻的 \(Q_t^b=0\) 端口与「此前已有停机」前缀端口以普通多项式恒等式完整计价地等价。
同词公开两时刻包装器进一步给出定位器下界：在两个候选端口总测试都拒绝的地址上，
任何不输入真实输出位却返回其真位缺口时刻的电路都需 \(\Omega(N/\log N)\) 大小，
因为该时刻恰为 \(H\) 或 \(H+1\)，逐位读出 published hard word。
[同一真实掩码端口的配对与方程支撑共同缺口](notes/466-genuine-rw-masked-ports-have-colocated-succinct-pairing-and-equation-support-gaps-2026-09-30.md)
进一步在 \(P=NP\) 下，对每种输出位的 \(\Omega(N/\log N)\) 个同词地址，
于**同一个**真实 \(Q_t^b=0\) 端口同时得到 \(N^\varepsilon\) 以上的完整 raw 配对预算
及真实门方程支撑数下界。后者排除所有逐条点名方程、描述长度不超过该阈值的
算术电路 Nullstellensatz/ideal proof，即使乘子电路有指数单项式数或高次数；
它仍允许一个短地址生成器触及大量不同方程，故未给出 exact surface 或最终分离。
[双哨兵根等值的完整配对仍不定向真实输出](notes/467-the-two-rw-sentinel-roots-have-a-short-same-object-equality-pairing-without-output-orientation-2026-09-30.md)
在 Note 465 的同一个完整电路中，用左右摘要的普通多项式差分递推，把两根差
\(R^{[0]}+R^{[1]}\) 化为最后哨兵前「从未停机」的因子。其端口有地址多项式的完整
raw 配对，故根等值端口与该前缀因子端口在固定预算多项式变换下等价；同词公开
两时刻包装器的 \(p_{H+1}=1\) 又给该因子一份短的真实源证书。
因此两根相等可在每个地址廉价证明，而 Note 466 的同一包装器仍在每种输出位的
\(\Omega(N/\log N)\) 个地址有真实端口的双重 \(N^\varepsilon\) 缺口。根等值证书
本身不提供返回位的定向证明。
[公开两时刻返回与单事件位的完整定向归约](notes/468-a-public-two-time-rw-return-has-an-address-succinct-single-wire-orientation-reduction-2026-09-30.md)
把这条分界推进到单副本：同一包装器中每棵平衡返回树都满足完整计价的普通多项式
端口 \(R^{[c]}+p_H+1=0\)，raw 配对、地址和次数均为 \(q^{O(1)}\)。因此候选
返回位 \(b\) 的完整证书与真实事件门 \(p_H=1+b\) 的完整证书在固定多项式预算下
双向等价。返回树及双哨兵的定向成本可全部移到这个公开定位、但值非公开的门；
该门本身是 published hard word 的补位，故归约不构造其短证书。
[非均匀 PH literal substitution](../mcsp-hardness-magnification/notes/606-literal-nonuniform-ph-substitution-requires-a-charged-local-code-interface-2026-08-28.md)
则说明把假设弱化为 \(NP\subseteq P/\mathrm{poly}\) 时，逐长度 SAT/PH circuit 的 gate-list
local code 必须完整计价；lex-first、Karp--Lipton 与 ordinary easy witnesses 都不自动产生
地址尺度 accessor。[source-level certificate 边界](../mcsp-hardness-magnification/notes/607-source-level-prma-and-fs2-certificates-retain-object-scale-payloads-2026-08-28.md)
排除了另外两个 black-box 绕行：actual prMA 的 Arthur tape 已是 \(m^{O(1)}\)，但 perfect Merlin
gate list 为 object scale；literal NO zero-pivot 会投影出 rejecting-tape Skolem selector，而一个
half-subset verifier 强制 simultaneous hitting set 与 pointwise selector 支付 \(2^{\Omega(m)}\)。
Li 的 published \(FS_2^P\) history 同样保留 \(\Theta(N)\)-bit challenge 与
\(\Theta(N)\)-层 descent；其 terminal pair 就是 hard outsider，所以可提取 output 的
polylog history accessor 已被同一 hard-word lower bound 排除。两项都只关闭 literal family，
不关闭 RW-specific nonliteral certificate；唯一活跃正向问题仍是 actual fixed
\(D_{\rm all}\)-derived machine 的 weighted depth 与 effectively closed heavy-run summary。
[Easy Witness 重标度边界](../mcsp-hardness-magnification/notes/608-easy-witness-rescaling-requires-a-hypothesis-incompatible-with-p-equals-np-2026-08-28.md)
进一步关闭通用 padding 绕行：在显式 query 长度 \(Q\) 上，\(P=NP\) 的逐位 witness search
只保证 \(Q^{O(1)}=2^{m^{O(1)}}\) 大小；重标度到 \(m^{O(1)}\)-bit NEXP 实例后，IKW 的
Boolean Easy Witness 前提是 \(NEXP\subseteq P/\mathrm{poly}\)，而 IKW 等价定理、
\(MA\subseteq\Sigma_2^P\) 与时间层级共同表明该前提和 \(P=NP\) 分支不相容。这个结论不排除
actual RW family 恰有特殊小 witness accessor，也不提供 weighted depth 或 long-jump summary。
[GKR 与当前 TISP delegation 的地址尺度边界](../mcsp-hardness-magnification/notes/612-gkr-and-current-tisp-delegation-do-not-yield-the-c456-fixed-ph-surface-2026-08-28.md)
进一步关闭标准 direct delegation families：literal compact-source GKR 逐层支付
\(D=\Theta(T)\)，浅 tableau checker 在 terminal input-LDE 留下 object-scale arbitrary
tableau，而 public-coin transcript 若无 \(m^{O(1)}\)-size causal strategy 便不能交换量词成为
exact fixed-PH surface。该结论不是一般 delegation 下界：bounded-space GKR 的
\(|C|=\operatorname{poly}(2^w)\)、\(D=O(w\log T)\) 是真实逃逸，Chen--Hong--Kalai--Xi
2026 的直接协议在 C456 参数上则落在 \(2^{\Theta(\sqrt m)}\) 的严格中间尺度。因此当前
standard direct families 已关闭；actual C456 machine 的 \(O(m)\)-space normal form 加
constant-round/short-strategy compression，或 RW-specific global summary，仍为 OPEN。
[低空间全配置 powering 的 weighted-depth 边界](../mcsp-hardness-magnification/notes/614-low-space-configuration-powering-gives-weighted-depth-while-actual-normalization-remains-open-2026-08-28.md)
现已把其中第一段条件桥闭合：对固定、无 advice、可统一生成的 local/source accessor，若
coordinate machine 有 \(w=O(m)\)、\(T\le2^{O(m)}\)，则全配置表 repeated squaring 给出
\(2^{O(m)}\) size、\(m^{O(1)}\) ordinary depth 的 source-compatible ANF circuit，因而由
Note 599 精确推出 \(d=m^{O(1)}\)。但 \(P=NP\) 只给 full
\(D_{\rm all}\) polynomial time；对 canonical prMA 的所有输入取得 \(O(\log Q)\) space
在该分支等价于额外的 \(P=L\)。这个 full-input 障碍尚不能转移到 actual canonical orbit，
因为没有把 P-complete 实例定位到 reachable prefix/final-coordinate/direct-trace 的 logspace
reduction。因此原 actual normalization 仍为 OPEN，而 generic powering 不再是缺口；下一叶子
只检查 actual restricted orbit 的低空间 coordinate machine 或相应 P-hard locator。
[source-padded actual-query sparsity 与 locator collapse](../mcsp-hardness-magnification/notes/621-source-padded-rw-queries-are-sparse-so-a-total-p-hard-locator-forces-p-equals-l-2026-08-28.md)
进一步修正了后一个选项。固定最终 RW machine 在每个 source length 只产生多项式多个 actual
queries；给每个 query circuit 追加 \(n\) 个 literal identity gates 后，promise 与答案不变，
query 长度落在 \([n,n^{O(1)}]\)，地址长度仍为 \(\Theta(\log n)\)，而跨全部 source lengths 的
actual-query language 严格 polynomially sparse。于是任何 total、uniform、全输入正确的
logspace P-hard locator 进入这个 padded surface，单凭 Cai--Sivakumar sparse-hard-set theorem
就已推出 \(P=L\)，不再需要假设 surface 上有 low-space decider。raw query encoding 因缺少
\(n\le |q|^{O(1)}\) 仍未证明 sparse；在没有 logspace-computable padding selector 时，
infinitely-often good lengths、promise-only 或逐长度 nonuniform locator 也不触发该 uniform
collapse。因此 padded locator 不是更便宜的活跃叶子；
当前直接正向叶子收回到 actual canonical orbit 的 \(O(\log n)\)-space coordinate machine，
而原 weighted-depth normalization 与 non-space global summaries 仍为 OPEN。
[批量低空间 powering 的共同 demand 边界](../mcsp-hardness-magnification/notes/619-generic-succinct-demand-for-batched-low-space-powering-implies-pspace-in-p-poly-2026-08-28.md)
进一步判定了 Note 614 尚未覆盖的 \(s_{598}\)：对一个固定 PSPACE-complete universal machine，
把全部 \(2^n\) 个输入的 powering outputs 接到共同 balanced-XOR root，仍只有
\(2^{O(m)}\) size、\(m^{O(1)}\) depth 与 advice-free poly-address local generator；但若同一个
Definition 598.1 descriptor 在同一 occurrence namespace 中提供 polynomial-size children
navigation 与 demand，则可按输入前缀定位相应 output occurrence，严格推出
\(\mathsf{PSPACE}\subseteq P/\mathrm{poly}\)。literal mux 本身也给出精确投影：true selector
key 为 \(k\) 时，每个策略至少暴露 \(2^{|k|_1}\) 个 powered-leaf demands；all-one key 暴露
整张 slice，而完整 \(\operatorname{Pow}(a,c,b)\) accessor 反过来足以生成全部 strategy 字段。
因此 low space、低 \((\log K,d)\) 或 ordinary depth 不能经由 generic theorem 自动补全完整
descriptor，除非同时跨过该非均匀复杂度边界。这个结果只关闭 universal batch/value-oblivious
upgrade：actual C456/RW orbit 尚未被证明包含同一 shared root 下的可定位 universal batch，
故 favorable frozen compiler 与 RW-specific valuation algebra 仍为 OPEN。
[dual-AND powering 的 marker 边界](../mcsp-hardness-magnification/notes/620-dual-and-powering-exposes-orbit-histories-only-with-a-powered-one-marker-2026-08-28.md)
进一步裁决了 literal mux 的自然替代：
\(\operatorname{smux}(s,u_0,u_1)=((1+s)\wedge u_0)\oplus(s\wedge u_1)\)
存在 selected-data strategy，但当 \(u_0=u_1=0\) 时两只 zero AND 可同时 pivot 到 data，
使任意 control/history forcing 失效；powered 恒零坐标把该逃逸放大成
\(r,d,s_{598}=\operatorname{poly}(A,w)\) 的规则策略。若改为真正参与 powering 和 selector key
的恒一 marker，则每个策略都强制全部内部轨道配置，且在共同 local base interface 下，
marker descriptor 与单一轨道的 random-access history 多项式等价。若再有共享
sequential output run、固定
\(j\mapsto r_j\) gate locator 与强制 marker subtree 的 identity wrapper，则 output counter
二分搜索给出整个 published hard word 的小电路，故这一 marker-plus-wrapper family 已关闭；
[distance-two off-code-one 编码](../mcsp-hardness-magnification/notes/629-distance-two-sink-coding-makes-dual-and-powering-strategies-expose-orbit-histories-2026-08-29.md)
又给出 value-independent forcing：真实 key 的每个 Hamming-distance-one 反事实叶均进入全一
sink，所以零值或一值 powered root 的任意策略都会暴露完整内部轨道。
[zero-coordinate wrapper closure](../mcsp-hardness-magnification/notes/631-zero-coordinate-wrappers-close-distance-two-powering-for-shared-hard-output-2026-08-29.md)
把 systematic leading-zero powered coordinate 以 literal XOR 接入任一共享输出；于是仅一个
target-specific 小策略已能恢复共享历史并计算整个 published hard word，无需跨 \(j\) 的共同
descriptor。这关闭 distance-two encoded、polylog-width、shared-run wrapper family；raw
unencoded zero--zero family、按 \(j\) 分离的 machine orbits、constant-folded wrapper 与
nonlocal global certificates 仍保持 OPEN。
[base outsider 的 logspace--derandomization 边界](../mcsp-hardness-magnification/notes/615-logspace-base-outsider-coordinates-imply-bpl-equals-l-without-closing-actual-rw-normalization-2026-08-28.md)
进一步判定了最便宜的 (i=0) 叶子：此时 canonical prefix 确实为空，但 local query
serializer 只生成输入位，不能把 C456 的 polynomial-time (D_{\rm all}) 变成 logspace
decider。若要求一个 fixed modular accessor 对所有充分大 fresh base (n) 逐位计算
(BF_0(G_n))，则二进制重标度与 Note 613 的
(2^{m-O(\log m)}) circuit lower bound 结合 Klivans--van Melkebeek 定理，严格推出
(BPL=L)。同时 (BF_0(G_n)=0^nS_n)，但
(CC(S_n)=\Omega(n/\log n))，故 literal materialized/exact-evaluable suffix family 已关闭。
这个附加塌缩边界不能转移到 C456：final-query semantics 只在 fresh (BF_1) failure
长度上等于 base word，而 published good set 仅无限、advice 非一致，later failure/direct
branch 的对象也不是 fresh base outsider。因此它约束 all/cofinite modular (BF_0)-accessor
family，不关闭 existential actual hard-length compiler。
[首个 prefix-fiber count 的 branch 对齐](../mcsp-hardness-magnification/notes/617-bf1-failure-prefix-fiber-counts-are-branch-misaligned-with-published-hard-output-normalization-2026-08-28.md)
进一步剪掉一个表面上更便宜、实际量词错位的叶子：在 \(BF_1\) failure 条件下定义的
首个非平凡 JK prefix-fiber count 属于 \(\pi_1\)，但 published good word 此时是由
\(\operatorname{Reconf}_0\) 重构的 \(B_0\)，且 \(\pi_0=\epsilon\)；真正使用
\(\pi_1\) 重构 hard \(B_1\) 的 guard 是 \(BF_1\) success 与 \(BF_2\) failure。两者不交。
此外，未冻结 generator encoding 与 concrete PCP prover 前，该 count 不是 theorem-level
单值对象。故 failure-conditioned \(Y^\psi\) accessor family 已作为当前 normalizer 脉冲关闭，
但 cross-stage reduction、branch-correct 全轨道 accessor 与 nonliteral weighted-depth
compiler 仍为 OPEN。
[range-preserving alias 的 cross-stage count embedding](../mcsp-hardness-magnification/notes/622-range-preserving-aliases-embed-the-base-outsider-in-the-first-bf1-prefix-count-2026-08-28.md)
现已实现其中第一个出口。对一个固定、P-uniform、size-\(n^4\) 的 admissible
truth-table generator，可用 \(b=o(n_1)\) 个 padded description bits 做 many-to-one
同-range recoding，并用保持 systematic output prefix 的固定 PCP wrapper 令首个
\(\psi\)-batch 满足 \(Y^\psi=J+\operatorname{Val}(B_0)\)，其中
\(2^{2n_0}\mid J\)。故该 count field 的低 \(2n_0\) 位逐位就是 \(B_0\)，在
\(F_1\) 上统一决定全部 base final queries。这个结果证明 representation freedom 足以修复
该 cross-stage object mismatch；它依赖 many-to-one recoding，不覆盖 permutation-only
重标号，也不提供 \(\pi_1\) accessor 或 branch-independent weighted-depth compiler。
[cross-stage census alias 的资源中性边界](../mcsp-hardness-magnification/notes/623-cross-stage-census-aliases-and-affine-rails-do-not-lower-weighted-strategy-cost-2026-08-28.md)
进一步判定了只靠该等式继续编译的最小 family。固定 Note 622 的实现后，首个 count
低位映射不只在实际 \(B_0\) 上成立，而在全部 \(x\in\{0,1\}^{2n_0}\) 上都是
\(x\mapsto x\)；它绑定两个表示，却不选择 hard word。若真实 \(\pi_1\) producer 已存在，
直接 COPY 的精确 recurrence 是 \((K,d)\mapsto(K+1,d)\)，完整 strategy descriptor
也只在多项式开销下等价转移；XOR equality check 则同时展开两端。若把 count bit 当作
输入叶，公共 source generator 已是被 hard-word 下界排除的 exact evaluator，而令叶值依赖
候选 \(b\) 会同时认证两个 bit。因此只新增 coordinate equality 与固定无环
COPY/NOT/XOR rails 的 family 已关闭；不经 \(B_0\) side cone 的 count-specific grounding、
joint favorable compiler 与 nonliteral global relation 仍为 OPEN。
[balanced canonical-tableau certificate boundary](../mcsp-hardness-magnification/notes/625-balanced-local-bicertificate-checkers-inherit-producer-strategy-cost-2026-08-28.md)
进一步关闭了把 \(L_{\rm all}\) 与补语言的双侧证书接到 balanced local checker 后直接
宣称 normalization 的 literal family。若 tableau cells 被 ground，公共 equation generator
已经投影出完整 cell accessor；对含共同完整 output track 的 C456 machine tableau，这还会
直接给出整个 published hard word 的 \(m^{O(1)}\)-size evaluator，因而在 hard lengths 上
不可能。若 cells 保持 external existential，量词仍是 object scale，逐地址
local responses 又失去同一 tableau 绑定；若由内部 functional circuit 产生，则 checker 在每个
locally sensitive coordinate 上继承 producer 的最小 weighted depth 与 occurrence count。
对去除冗余 padding 的 canonical deterministic tableau，每一位都 locally sensitive。
因此 balanced checking 的低深度外壳不降低 producer obligation；这不排除没有显式 tableau
boundary 的 joint/nonliteral compiler，也不能从低 \(d\) 反推出低空间或小 \(s_{598}\)。
[actual hard-coordinate logspace 的 infinitely-often derandomization 边界](../mcsp-hardness-magnification/notes/626-actual-hard-coordinate-logspace-machines-imply-infinitely-often-bpl-derandomization-2026-08-28.md)
进一步判定了剩余 low-space 正向叶子。若一个 fixed target-specific coordinate machine 在
全部 published hard lengths 上以 \(O(\log n)\) space、\(n^{O(1)}\) time 计算
\(B_n[j]\)，把正确 advice bit 提升为一个普通输入位并取 \(n=2^{r-2}\)，就得到统一的
\(H\in\operatorname{DSPACE}(O(r))\cap\mathsf E\)，且在无限多个 \(r\) 上满足
\(\operatorname{CC}(H_r)=2^{r-O(\log r)}\)。Klivans--van Melkebeek/PRZ 的 PRG 与
reconstruction 可逐 hard-function length 局部化，故严格推出
\(BPL\subseteq\operatorname{io}\text{-}L\)，但因 good set 可任意稀疏，不能升级为
\(BPL=L\)；缺少 total P-hard locator 也不能推出 \(P=L\)。这与 C455 相容：全配置 powering
只反推 machine space \(w_r\ge r/2-O(\log r)\)，并不排除 \(w_r=O(r)\)。published
reconstruction 仍需 canonical prefix 与终端 \(L_{\rm all}\) membership，direct branch 固定
\(j\) 也不删除 BF/JK/SAT trace；whole-trace Cook formula 只是循环重述。因此该 low-space
family 现为 PAUSE，而无显式 tableau boundary 的 joint compiler、composition-closed
transformer algebra 与其他非空间 global summary 仍为 OPEN。
[global Nullstellensatz pairing 与 bare succinct identity 的边界](../mcsp-hardness-magnification/notes/627-global-nullstellensatz-pairings-escape-weighted-strategies-while-bare-succinct-identities-encounter-parity-2026-08-28.md)
进一步给出严格 model exit。Note 600 forced-zero recurrence 的 isolated functional system
虽然每个 Definition 598.1 strategy 都有 \(d=L\)，却存在 ordinary degree \(2\)、
\(O(\log L)\)-bit 地址并带局部 occurrence involution 的 global telescoping NS refutation；
空 extension set 已足够，所以 weighted strategy 只是充分形而非一般 succinct NS/ENS
normal form。反过来，低 degree 加 circuit-succinct indexed term list 也不自动成为 proof：
对任意 circuit 的 XOR accumulator 做 generic fixed-\(\Sigma_2\) 编译会严格推出
\(\oplus\mathsf P\subseteq\Sigma_2^P\)，在 \(P=NP\) 分支还要求额外的
\(\oplus\mathsf P=P\)。Krajíček ENS 使用 object-scale dense explicit proof；标准 implicit
proof 则另含一份 outer correctness proof。故只凭低 degree/term generation 的 generic family
已关闭，actual C456-specific global pairing、完整计价的 implicit correctness proof 或
poly-size aggregate identity circuit 仍为 OPEN。
[literal-COPY transport 的完整 pairing lift](../mcsp-hardness-magnification/notes/628-literal-copy-transport-lifts-the-global-pairing-while-the-machine-level-claim-remains-unfrozen-2026-08-28.md)
进一步把 Note 627 的 isolated 分离提升到一个显式 full cell--time realization：若 source cells
由 direct initialization 加 literal COPY 网格送到 computation diagonal，则 source、transport、
diagonal AND 与 wrong-output equations 共同具有 degree \(2\)、\(\Theta(L^2)\) 项且
term/pairing circuits 为 \(\operatorname{polylog}(L)\) 的 NS refutation；与此同时每个
Definition 598.1 strategy 仍有 \(d=L\)。这证明 global pairing 的 model exit 可在完整
physical layout 中发生，不依赖把 diagonal values 偷设为独立 axioms。但 Notes 444/453/600
没有冻结 Section 4 transducer 的 machine code、source loader 或 symbol-transport polynomials，
所以不能把该 lift 归因于一个尚未定义的 canonical \(\mathsf{Comp}_{\rm ANF}(M_\wedge)\)。
head-controlled mux 虽语义上仍为 COPY，却会使这条自然 lift 从 degree \(2\) 升到 degree \(3\)；
这不是下界，而是要求先冻结 code-level triple 的精确表示边界。
正向 Closure 所需且仍开放的是：对一个 fixed favorable compiler 直接构造 Note 596 的 global
pairing 或其他 locally checkable identity，或建立 Notes 598--600 的全部 strategy 接口。负向下界
则必须先固定 compiler 并同时控制 occurrence 地址、degree 与 global certificate/strategy
descriptor complexity，或先证明
表示不变的 normal form。public gate layout 本身不给出 active mask、navigation 或低 weighted
depth。squarefree-binomial 片段的
multilinear expanded degree 虽精确等于 contextual monomial-transition bottleneck，但六点
AND/COPY 例已有 transition width \(2\)、literal raw degree \(3\)，而 standard black pebbling
price 为 \(4\)，故普通 black/reversible
pebbling 不能控制这个新接口。若证明语法先合并相同项，relay 会消失，nonlocal routing 问题重新出现。

[read-only source normalization](../mcsp-hardness-magnification/notes/633-read-only-source-normalization-freezes-literal-copy-transport-without-head-trace-advice-2026-08-29.md)
现已把 source 表示歧义从这个问题中删除：固定 normalization 将 regular source 直接初始化到
read-only plane，并用 primitive literal COPY 送入 computation boundary，全部 local record
均为 address-succinct，且不需要 head-trace advice。它不压缩任意内部计算。
[oblivious sweep physical-head normalization](../mcsp-hardness-magnification/notes/638-oblivious-sweep-normalization-exposes-physical-head-tokens-without-virtual-trace-advice-2026-08-29.md)
进一步删除一般 writable track 的 physical head-token 表示缺口：对固定 machine 与一并冻结的
polynomial clock，公开 length-derived padding 上的 \(O(T^2)\) fixed-sweep replacement 保持
source/history projection、hist-first lex maximum 与完整输出；每个 physical head schedule 及
primitive \(H_{\tau,c}+\operatorname{Sched}(\tau,c)\) 方程都有 address-scale locator，且不增加
C456 的一位 advice。公开的只是 simulator physical cursor，不是原机 virtual head、state 或
active replacement；因此 Note 632 的 local degree-three splice 可用于 maximal physical
off-head segments，但 triangular full certificate、active-transition orientation、global pairing
与低 weighted depth 仍全部 OPEN。下一承重对象已缩为 normalized C456 machine 的 active sweep
updates，而不是继续寻找 physical head trace。
[public-sweep last-replacement transport](../mcsp-hardness-magnification/notes/639-public-sweep-tokens-reduce-physical-mux-transport-to-last-replacement-ports-2026-08-29.md)
又用公开 on-head token \(H+1\) 补齐另一半：对任意 outer sparse monomial \(G\) 与 demanded
bit \(a\)，一个 resident-symbol port 可由 degree \(\deg G+2\)、每边三个 system multiples
且带 address-scale raw involution 的 ported zero identity 接到 initialization 或最近的 active
replacement port。Note 638 的具体 fixed-sweep schedule 还给出 address-scale `LastVisit`；一般
small schedule accessor 不自动给这个 locator。该模块没有 distinguished constant，且要求外层
skeleton 提供完全相同的 \((G,a)\) 两端，所以不是 Note 596 的闭合 certificate。physical mux
transport 至此不再承重；唯一下一 gate 是 two-bank finite replacement equations 的
same-\((G,a)\) port normal form 及其 actual C456 event-level composition。
[one-hot replacement owner-token boundary](../mcsp-hardness-magnification/notes/640-one-hot-replacement-needs-virtual-owner-token-for-same-multiplier-port-2026-08-29.md)
进一步把该 gate 分开：selector-weighted replacement identity 已成立，但一般 one-hot mux 的
selector-free 单一 owner port 被两格反例关闭；只有 actual C456 能提供 address-succinct virtual
owner token（或较弱的 \((J+j)(\sigma+w)\) token）时，才可继续做 event-level composition。
[off-head write-token boundary](../mcsp-hardness-magnification/notes/641-off-head-write-token-is-not-redundant-and-direction-owner-remains-open-2026-08-29.md)
进一步关闭了直接加入 \((J+1)(\sigma+w)=0\) 的 shortcut：当前 mux 只保证 off-head 的
resident output，不保证 write field 等于 resident。剩余问题是对 actual C456 的 symbol、marker、
request 和 state tracks 做 projection-preserving split，判断非平凡事件能否获得 virtual owner；
固定方向 COPY 与统一清零不再承重。
[direction-rail split boundary](../mcsp-hardness-magnification/notes/642-direction-rails-close-physical-shift-but-not-virtual-request-creation-2026-08-29.md)
显示三条 left/stay/right request rails 的后续固定偏移搬运可由 literal COPY/XOR 处理，但
request creation 仍是 \(J D^\ell\) 的 data-dependent AND，symbol write 与 state/register
transition 仍未定向。下一脉冲只研究 actual C456 request-creation orientation。
[conditional direction one-hot aggregate](../mcsp-hardness-magnification/notes/643-conditional-one-hot-decoder-aggregates-direction-requests-without-branch-selection-2026-08-29.md)
给出一个候选正面接口：若 decoder 提供 \(h_J=J(D^-+D^0+D^++1)\)，三条 request-creation
AND 可保留为 rail sum，并与旧 marker 做同一 \(G\) 的无分支 pairing；但该 token 的
projection-preserving 来源尚未证明，symbol/state interfaces 仍保持 OPEN。
[fixed decoder one-hot token](../mcsp-hardness-magnification/notes/644-fixed-transition-decoder-gives-projection-preserving-one-hot-token-2026-08-29.md)
现证明：对固定有限 transition table，可加入常数大小、projection-preserving 的 direction
decoder 与 one-hot 方程；三条 request-creation AND 因而已有 address-succinct aggregate pairing。
仍未解决的是 symbol-write、state/register 及全局 distinguished-constant pairing。
[symbol rail factorization boundary](../mcsp-hardness-magnification/notes/645-symbol-rail-factorization-is-projection-preserving-but-does-not-remove-selector-boundary-2026-08-29.md)
进一步确认 idle/write 双轨的线性 merge 只有语法收益；接回真实输入后仍退化为
selector-weighted mux，且 demanded-bit 常数在 \(a=1\) 时需要 selector。该重命名族不再继续，
主线转向真正的 symbol/state invariant 或 nonlocal pairing。
[canonical-write re-encoding](../mcsp-hardness-magnification/notes/681-canonical-write-reencoding-removes-off-head-owner-locally-2026-08-29.md)
随后给出一个更强的局部修正：引入 canonical local write \(w^c\) 后，symbol-write
track 存在对所有事件成立的 same-\((G,a)\) port identity，且
projection-preserving、address-succinct。对 existential source-compatible fixed-sweep
compiler，可把该消费者条件直接纳入构造；这只关闭 symbol-write 的局部 owner
障碍，不提供 virtual state/marker accessor、全局 composition closure 或 C596。
[finite one-hot transition aggregate](../mcsp-hardness-magnification/notes/682-finite-one-hot-transition-aggregate-port-2026-08-29.md)
随后把固定有限 transition 的 state/output decoder 也改写为 projection-preserving 的
all-event aggregate port；但两步 \(F_2(y,u)=yu\) 已关闭 strict same-\(G\)
affine/no-product composition，并显示 mutable record 必须支付 fresh-sibling
degree/provenance。该结果仍不实例化 actual C456 orbit，也不提供 global closure。
[reverse-adjoint functionality](../mcsp-hardness-magnification/notes/635-reverse-adjoints-give-succinct-definitional-extension-functionality-without-output-orientation-2026-08-29.md)
进一步对任意 address-succinct functional circuit 给出 degree-\(3\)、线性 term count 和
局部 occurrence involution 的 two-copy disagreement certificate；其 reverse adjoints 是
PAC-style definitional extensions，不是 Krajíček ENS。该证书只证明两份相同 source 的计算
输出一致，不能决定真实输出位。
[synchronized nonlinear orientation](../mcsp-hardness-magnification/notes/636-synchronized-nonlinear-feedback-has-a-degree-three-oriented-global-pairing-2026-08-29.md)
则首次在 Note 630 的 fresh-input nonlinear feedback 上把 one-copy orientation 与
exponential weighted depth 严格分开：标准 direct ANF system 虽对每个 finite-local
weighted strategy 都有 \(d\ge L\)，仍有 degree \(3\)、\(8L+2\) terms、
\(16L+3\) occurrences 和 \(O(\log L)\)-address involution 的 candidate-bit global
pairing。承重机制是 duplicated identical-RHS rails 给出的
\(p_{t-1}+q_{t-1}=X_t+Y_t\) 不变量；actual C456 尚缺同类 address-succinct invariant
algebra，故这一结果是正面机制而非最终 orientation。
[single-register fresh-input separation](../mcsp-hardness-magnification/notes/637-single-register-fresh-input-feedback-separates-local-strategies-from-quadratic-global-pairings-2026-08-29.md)
进一步证明 duplicated identical-RHS rails 并非必要：令两个 XOR arms 同时读取一个旧状态
\(X_t\)，则每个 finite-local fully expanded strategy 同时满足
\(K\ge2^{L+1}-1\)、\(d\ge L\)，而 direct ANF 仍有 degree \(2\)、\(6L+2\) terms、
\(12L+3\) occurrences 的 address-succinct oriented pairing。承重正机制改为
common-state fanout 与显式 Boolean axiom 形成的局部 coboundary。因而 actual C456 的正向
搜索不应再限定为 duplicate rails，而应寻找任意 source-grounded、可地址化的 local
coboundary 或 nonlocal invariant；一般 machine 仍没有这样的定理。

若同一 published hard word 获得总长度 \(\operatorname{polylog}(N)\) 的 exact
same-object fixed-PH surface，或满足上述定量条件的 growing-depth surface，则非均匀编译已足以推出
\(\mathrm{SAT}\notin P/\mathrm{poly}\)；不需要先证明 RW hard word 本身属于 \(NP\)。

历史 `notes/` 与 `statements/` 保留数学依赖；冻结的 `CLAIMS.md` 只为旧深链接服务，
不再作为权威状态源或新增结果登记表。
