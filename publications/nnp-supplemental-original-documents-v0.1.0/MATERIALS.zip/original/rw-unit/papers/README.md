# 论文单元：共享证明、分布式一致性与地址尺度重构

本目录把已有研究成果按“一个可独立陈述的核心贡献对应一篇论文”固化。这里的
“论文”指可以继续扩展为投稿稿的连续数学文本；它不等于已经证明了 (P\ne NP)，
也不把内部搜索 note 的数量当作成果数量。

## 论文总表

| 编号 | 论文 | 核心贡献 | 当前地位 |
|---|---|---|---|
| 01 | [Shared-Proof Coordinate Robustness Implies Relaxed Local Decoding](01-shared-proof-coordinate-robustness-implies-relaxed-local-decoding/paper.md) | 共享 proof 的 target-relative 坐标鲁棒性统一编译为 relaxed-LDC；binary 两查询且无 bottom 时升级为 cubic LDC 二分；并收录 distributional、cover 与 RW 应用扩展 | 技术档案；不再作为旗舰稿 |
| 02 | [Distributional Soundness Does Not By Itself Produce a Global Word](02-distributional-soundness-does-not-produce-a-global-word/paper.md) | 精确区分逐坐标/随机串理想词与同一个 global word；给出 global-word 到 indexed channel 的正向桥、DHK 量词反例，以及 connected-neighborhood uniformization；Theorem 3.13 将其与 smooth outer decoder 组合为 shared-proof ACRR/RLDC | 独立定理稿；数学桥接已成形，但顶级投稿仍 HOLD，尚缺 GMWZ/RW 的定量 source-level 应用或更一般的不可能性定理 |
| 03 | [Cover Obstructions for Shared-Top Direct-Product Tests](03-cover-obstructions-for-shared-top-direct-product-tests/paper.md) | 在 BMVY/DDL 源族内证明 shared-top DPT 的 cover obstruction；以二簇与多簇 overlap-aware varying-tag gate 控制高阶 incidence 逃逸，并以 bottom--cover--cubic trichotomy 统一 sheet binding、RLDC 与 base-word closure 的代价 | 已证明的源特定旗舰候选 |
| 04 | [From Address-Scale Smart Reconstruction to P/poly](04-from-address-scale-smart-reconstruction-to-p-poly/paper.md) | 将 RW/JK smart reconstruction 到 (P/\mathrm{poly}) 冲突的条件性闭合写成自足定理，并加入 scale-complete audit：区分 stable object-scale solver、address-scale compression、failure descriptor payment 与 conditional family/RLDC closure | 条件性闭合稿，不宣称 (P\ne NP) |
| 05 | [Shared-Proof Coordinate Robustness: Relaxed Local Decoding, Bottom Escape, and Compiler-Class Barriers](05-shared-proof-coordinate-robustness-barriers/paper.md) | 收束共同 proof \(\Rightarrow\) RLDC、bottom-or-cubic、有限字母/finite-view strategy locality、selected-policy entropy-to-RLDC、有限 public randomness 下的 completeness repair、finite-randomness selected-policy phase diagram、信息预算—proof length 相图、partition-and-agreement coordinate-flip barrier、正半径 dense-fold completion/bottom barrier、RW/Harsha physical-to-raw completion 三分，以及 FRI fold-graph completion/recovery gate | 旗舰候选；已证明的 barrier theorem，不宣称一般 dPCP impossibility 或 \(P\ne NP\) |

## 旗舰稿与技术档案

Paper 05 是从 Paper 01 抽取的短旗舰候选，正文只保留可以独立核验的承重链；C476 的
正半径 dense-fold completion/bottom barrier 已作为第 6 节纳入正文。
Paper 01 保留全部扩展证明，作为技术档案；Paper 04 单独承载 address-scale 到
\(P/\mathrm{poly}\) 的条件性闭合。三者共同构成“shared-proof barrier → RW closure
gate”的边界，但没有一篇在当前状态下声称已经证明 \(P\ne NP\)。

## 旧综合稿的处理

[Address-Scale Barriers for Shared-Proof Coordinate-Robust Reconstruction](Address-Scale-Barriers-for-Shared-Proof-Coordinate-Robustness/paper.md)
保留为技术总稿和交叉引用档案。它包含 01--03 的更长证明链以及尚未形成独立论文的
探索性接口；不作为投稿版本的唯一入口。后续每篇论文只从它和原始 statement/note
吸收必要内容，不复制整份历史。

## 证据边界

- **已证明/可自足**：论文 05 的 barrier theorems；论文 01 的扩展编译器与
  bottom-or-cubic 定理；论文 02 的抽样桥和量词反例；论文 03 的 BMVY/DDL 源特定结论。
- **条件性**：论文 04 的最终复杂度闭合；它的假设尚未由 RW/JK 实际 construction
  全部验证。
- **外部输入**：Dall’Agnol--Gur--Lachish、Gur--Minzer--Weissenberg--Zheng、
  Dikstein--Dinur、Dikstein--Dinur--Lubotzky、BMVY 等只作为已核验的外部定理调用，
  不被改写成项目自己的证明。

## 研究范围

这五篇共同服务于一个一级问题：一个 global proof 和一个地址空间，能否同时支持
所有输出坐标的 target-relative robustness，并保持 RW/JK 所需的地址尺度。它们分别
回答“会付出什么编码代价”“distributional soundness 缺什么量词”“具体 HDX 源为何
不能黑箱升级”“若最终接口闭合，(P=NP) 矛盾如何收尾”。
