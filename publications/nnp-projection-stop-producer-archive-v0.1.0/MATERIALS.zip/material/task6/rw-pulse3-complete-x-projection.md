> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# RW pulse3: the weighted complete first-separator projection

Date: 2026-10-03. Task-workspace candidate; original project read-only.

**Result.** Completing the first separator coordinate X takes a fixed linear projection of the same-source coefficient polynomials. It can cancel even when their highest coefficient is nonzero. The exact algebra below is proved; application to the reached RW subtable retains the stated source/route interface. No actual reachable cancellation, survival theorem, JK response or main-conjecture result is asserted.

## 1. Field, source interface and public weight

Let u=2^mu>=8, K=GF(u), F=GF(u^6), Q=u^6, and
\[
M=1+u+\cdots+u^5,\quad U_4=u+u^2+u^3+u^4,\quad
B=4U_4,\quad \kappa=4u^5,\quad d_*=B+\kappa+2=4M-2.
\]
For a in K let L_a(X)=1+(X+a)^(u-1). Fix a_o in K^times and write
\[
s=L_0(X),\quad \ell=L_{a_o}(X),\quad v=X^{u-1},\quad t=v^2.
\]
For X outside K, z=ell/s=X/(X+a_o). The rational notation must not be used to sum grid points; all full-field identities below use cleared ordinary polynomials.

The preceding sealed pulse2 packet proved the paired complete first-last-digit integration and derived, after complete Y, two beacon coordinates and spare W, the following interface:
\[
\mathcal B_x(X)=\Gamma_x(X)L_0(y)^2s^{d_*}
(1+(tD\eta)^2)^{U_4}
[\mathfrak a P_0(z)+\mathfrak b\,t^{2u^5}P_5(z)],                    \tag{1}
\]
\[
\begin{aligned}
P_0(z)&=c_0+c_2z^2+c_\kappa z^\kappa+c_Tz^{\kappa+2},\\
P_5(z)&=c_0+c_2z^2+c_Tz^{\kappa+2},\\
\mathfrak a&=A+c,\\
\mathfrak b&=\eta^{2u^5}[(A+c)D^{2u^5}+cd\,C^{2u^5}].
\end{aligned}                                                       \tag{2}
\]
Here y is the fixed first beacon coordinate, eta=y^(2(u-1)); d is the squared nonzero beacon grid offset. A is the fixed reference third background, and c the charged third-source coefficient. In the notation of the sealed packet, with U=y^2,
\[
D=A U^{2(u-1)}+c(U+d)^{2(u-1)},\qquad
C=A U^{3u/2-2}+c(U+d)^{3u/2-2}.
\]
These are the post-spare parameters, not a value of L_0(W) before W was summed.

All coefficients c_j come from the same two actual canonical source sections and the common OUTPUT section. They are not freely chosen in applying (1) to RW. To traverse X, hold **the same permitted third remainder and all other first coordinates fixed**. A,c,d,C,D,eta,y,c_j must then be independent of X. Changing the third route with X would invalidate the conclusion.

The complete separator public factor contains s^2. Its provenance is:

- 612.3 places both defect endpoints at separator grid digit zero, giving L_0(X)^2 L_0(Y).
- 605.2 and 610.8 supply the separator theta factor theta(X,X,Y)^(2(M-1)); the special last-digit source weight has no X dependence here.
- 614.10 displays the omitted separator weight, and 616's complete Y sum retains L_0(X)^2.
- 619.13 and 620.12 retain this factor explicitly; beacon weights and all other fixed padding factors are independent of X.

Thus
\[
\Gamma_x(X)=G_xs^2,\qquad G_x\text{ independent of }X.                 \tag{3}
\]
The dependency references record what was checked in the local source notes. They do not constitute a fresh certification of every upstream reached-route or checker claim.

## 2. Exact complete-X identity

Put k=(D eta)^2. Substitute (3) in (1) and clear denominators. Apart from G_x L_0(y)^2, the ordinary polynomial is
\[
\begin{aligned}
(1+kv^4)^{U_4}\bigl\{
\mathfrak a[&
c_0s^{4M}+c_2s^{4M-2}\ell^2
+c_\kappa s^{4M-\kappa}\ell^\kappa
+c_Ts^{4M-\kappa-2}\ell^{\kappa+2}]\\
+\mathfrak b\,v^\kappa[&
c_0s^{4M}+c_2s^{4M-2}\ell^2
+c_Ts^{4M-\kappa-2}\ell^{\kappa+2}]
\bigr\}.                                                            \tag{4}
\end{aligned}
\]
Every exponent of s here is positive. Expression (4), rather than a rational evaluation at z, is the correct extension to all X in F.

For arbitrary fixed field coefficients and a_o in K^times,
\[
\boxed{\displaystyle
\sum_{X\in F}\mathcal B_x(X)
=G_xL_0(y)^2(1+k)^{U_4}
[\mathfrak a P_0(1)+\mathfrak b P_5(1)].}                              \tag{5}
\]
In particular, this algebraic theorem needs neither c_T!=0 nor the RW density claim.

At X=0, s=1, ell=0, v=0, so (4) is mathfrak a c_0. At every other grid point s=0 and (4) is zero. Characteristic two therefore gives the separate off-grid identity
\[
\boxed{\displaystyle
\sum_{X\in F\setminus K}\mathcal B_x(X)
=G_xL_0(y)^2
\{(1+k)^{U_4}[\mathfrak a P_0(1)+\mathfrak b P_5(1)]
+\mathfrak a c_0\}.}                                                 \tag{6}
\]
The full-field and off-grid totals must not be conflated.

## 3. Self-contained proof by seven basis moments

Scale X=a_o x. Since a_o^(u-1)=1, this is a bijection of F preserving v, and it sends ell to L_1(x), s to L_0(x). It suffices to prove the identity for a_o=1. In this section only, X denotes this normalized variable.

Take the unique fourth root r of k, and define the **product**
\[
H=s(1+rv)=1+(1+r)v+rv^2.
\]
Then deg H<=2u-2, [X^(u-1)]H=1+r, and
\[
H^B=s^B(1+kv^4)^{U_4}.
\]
The product is essential: replacing H by s+rv drops a factor and is incorrect.

For arbitrary polynomials L,H,R of degree at most 2u-2, define
\[
\lambda=[X^{2u-2}]L,\quad \nu=[X^{2u-3}]L,\quad
h=[X^{u-1}]H,\quad a_R=[X^{u-1}]R,\quad b_R=[X^{3u/2-1}]R.
\]
The following general moment is valid:
\[
\sum_{X\in F} L(X)^2H(X)^B R(X)^\kappa
=h^B(\lambda^2 a_R^\kappa+\nu^2 b_R^\kappa).                           \tag{7}
\]

To prove it, the summand has degree at most
\[
4(u-1)+2B(u-1)+2\kappa(u-1)=8Q-4u-4<8(Q-1).
\]
Every exponent is even. Full-field power summation in characteristic two keeps only positive multiples of Q-1; hence the only possibilities are 2(Q-1), 4(Q-1), 6(Q-1). The constant term sums to Q=0.

All exponents in H^B R^kappa are divisible by 4u, whereas deg L^2<=4u-4. The residue for 2(Q-1) is 4u-2, outside this range. The other two residues are 4u-4 and 4u-6, selecting the coefficients lambda^2 and nu^2 of L^2 respectively.

For the 4(Q-1) case, removing low exponent 4u-4 and dividing by 4u leaves target u^5-1. Write the four H factors as H^(4u), H^(4u^2), H^(4u^3), H^(4u^4), followed by R^(4u^5). The target's five base-u digits are all u-1. At its lowest digit a selected H exponent lies in [0,2u-2]. Congruence to u-1 forces precisely u-1; the alternative 2u-1 is unavailable. There is no carry. Repeat through the lower four positions, and the R exponent is u-1. The product coefficient is h^B a_R^kappa.

For 6(Q-1), removing 4u-6 and dividing by 4u gives (3/2)u^5-1. Its lower four digits are again u-1 and its top digit is 3u/2-1. The same no-carry argument gives h^B b_R^kappa. Adding the two terms proves (7).

For a_o=1,
\[
s=1+X^{u-1},\qquad
\ell=X+X^2+\cdots+X^{u-1}.
\]
The relevant boundary coefficients are:

| L | lambda | nu |
|---|---:|---:|
| s^2 | 1 | 0 |
| s ell | 1 | 1 |

| R | a_R | b_R |
|---|---:|---:|
| s | 1 | 0 |
| ell | 1 | 0 |
| s v | 1 | 0 |
| ell v | 0 | 1 |

Indeed s ell has coefficient one at every power 1 through 2u-2. The seven terms of (4) correspond, in order, to
\[
(L,R)=(s^2,s),(s\ell,s),(s^2,\ell),(s\ell,\ell),
       (s^2,sv),(s\ell,sv),(s\ell,\ell v).
\]
Formula (7) makes every one of their sums equal h^B. Finally
\[
h^B=(1+r)^{4U_4}=(1+k)^{U_4}.
\]
Collecting the same c_j coefficients proves (5). The direct grid evaluation above proves (6). This proof includes the public s^2 weight and does not assume that an unweighted sum has the same value.

## 4. Survival criterion and a canonical cancellation example

When G_x L_0(y)^2 is nonzero, (5) is nonzero exactly when
\[
D\eta\ne1\quad\text{and}\quad
\mathfrak a P_0(1)+\mathfrak b P_5(1)\ne0.                             \tag{8}
\]
When A=c and c,d,C,eta are nonzero, mathfrak a=0 and mathfrak b!=0, so the second condition reduces to P_5(1)!=0. The highest coefficient c_T!=0 does not imply it. Also z=1 is outside the image of finite off-grid X under X/(X+a_o); the earlier root bound on that image does not control this projection value.

A stronger toy than a freely prescribed coefficient list obeys the canonical paired source form. Assume mu is even and at least four, so K contains F4. Choose omega with omega^2+omega+1=0, take endpoint labels p=0,q=1, and let
\[
V_0=0,\qquad V_1=L_0,\qquad O=L_\omega.
\]
All three sections have Boolean grid values and degree below u; O(p)=O(q)=0, and V_1+V_0 has endpoint difference one.

For a section T define its four moments
\[
a_T=[Z^{u-1}]T,\quad
g_T=[Z^{2u-3}]L_0T,\quad
h_T=T(0)+T(1),\quad
t_T=[Z^{3u/2-1}](L_0+L_1)T.
\]
The moments of V_1 are (1,0,1,1), and those of O are (1,omega,0,1). To verify the last entry directly, L_0+L_1 has all coefficients one in degrees 0 through u-2, while [Z^j]L_omega=omega^(u-1-j) for j>0. The relevant convolution is
\[
t_O=\sum_{e=0}^{u/2-2}\omega^e=1:
\]
u=4^m makes the last exponent divisible by three and each full triple has sum zero.

The normalized paired-source coefficients from the proven pulse2 moment identity are
\[
\begin{aligned}
c_0&=\sum_i(a_i^2h_i^{B+\kappa}+g_i^2h_i^Bt_i^\kappa),\\
c_2&=a_O^2\sum_i h_i^{B+\kappa}+g_O^2\sum_i h_i^Bt_i^\kappa,\\
c_\kappa&=t_O^\kappa\sum_i g_i^2h_i^B,\\
c_T&=g_O^2t_O^\kappa(h_1^B+h_0^B).
\end{aligned}
\]
Substitution gives
\[
(c_0,c_2,c_\kappa,c_T)=(1,\omega,0,\omega^2),\qquad
P_0=P_5=1+\omega z^2+\omega^2 z^{\kappa+2}.
\]
Hence c_T!=0 but P_0(1)=P_5(1)=0. The full-X sum is zero for every fixed background satisfying the interface.

This is compatible with many nonzero summands. For example, conditionally take an independent background with A=c, c,d,C,eta!=0 and G_x L_0(y)^2!=0. Then outside K the nonzero scalar bracket is mathfrak b v^kappa P_5(z). The P_5 root set has size at most kappa+2 and the prefactor zero set at most u-1. At least Q-u-(kappa+2)-(u-1) off-grid X values are nonzero, a positive fraction for u>=16, while the full-field total is zero. This is an algebraic conditional example; no actual RW background is certified to realize this selection.

### Actual reachability boundary

The toy is **not** an actual RW counterexample. Under the local two-line identity 517.3 and its retained-coordinate version 610.6, an actual source difference at a fixed selected off-grid high tuple has
\[
\Delta_{\rm actual}(Z)=\alpha_B p_B(Z)+\alpha_G p_G(Z),
\quad \alpha_B\ne0.
\]
At hard ledger suffix grid labels tau_j, n_0<=j<2n_0, p_B(tau_j)=S_0[j-n_0] and p_G(tau_j)=0: K_gad>=2 gives floor(j/K_gad)<n_0, and the first half of B_0 is zero. Therefore the nonzero support of the actual difference on that suffix is the support of S_0. This step relies on the same full canonical section and on the nonzero ledger multiplier; equality of two endpoint values or a few moments is insufficient.

If this hard suffix has at least two ones, it cannot equal the toy difference L_p, which has only one nonzero grid point. The large-length outsider hardness assumption in 517 ensures this support condition: a word with at most one one has an equality-test circuit of size O(log n_0), incompatible with the stated Omega(n_0/log n_0) hardness at sufficiently large n_0. Affine normalization of p,q only permutes grid labels and does not change the one-point support. This is a conditional exclusion of this entire toy section. It does not exclude other actual source sections whose two projected moments vanish.

## 5. Verification, corrections and open boundary

- New-context same-model reviewer [same-model review role] independently recovered the missing public s^2 factor, formula (5), the off-grid correction, the toy coefficients, and the conditional support exclusion.
- The reviewer initially wrote H as s+rv in its proof. That is wrong; I identified it, and the reviewer corrected it to s(1+rv), with the degree/no-carry proof above. The final formula and its finite check did not change. This disagreement is preserved as part of the review record.
- rw_xsum_check.c enumerates every X in GF(2^18), u=8, for a nontrivial grid label and k=0,1,73951. Each of the seven raw-polynomial full sums and its off-grid correction passed. It reuses only the previously verified finite-field arithmetic, not the earlier symbolic formula. The new packaged run took about 2.27 seconds with no compiler warnings. u=8 checks the general algebra; it is not asserted to be an admissible actual RW parameter.
- rw_f4_toy_check.py computes canonical polynomial coefficients in F4 for u=16,64,256 and checks all displayed moments and coefficients. It does not enumerate a large field or read an actual RW word.
- This is independent context, not independent-model or external-human certification. The upstream source/checker/route statements, actual attainable scalar values, address-scale evaluation cost and any novelty claim remain unverified beyond the specified interfaces.

The next bounded actual-source obligation is to prove or refute survival of the scalar in (8), while respecting its same-source constraints and the permitted fixed third remainder. A lower bound on c_T or on pointwise density does not discharge it. Subsequent outer sums, additional real defects, norm-orbit interactions, trace and the full JK response remain open. No result here resolves the main conjecture.

For a minimal Public AI Research Commons candidate, the self-contained seven-basis identity and weighted projection theorem are separable from the reached RW interpretation. The F4 toy may be included only with its explicit synthetic status and conditional nonreachability discussion. Human authorship/consent, AI-role disclosure, content/code licenses, bibliography, novelty review and external validation remain the unified coordinator's work. No upload, signing key, DOI or publication was attempted.
