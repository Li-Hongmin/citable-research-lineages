> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# RW pulse5: the complete weighted first-spare projection

2026-10-03. Private task-workspace result. Original source is read-only.

The first-spare coordinate w is now fully summed. The complete sum is another fixed projection, not the pointwise nonzero statement of pulse4. This round proves the projection and its exact cancellation criterion. Whether its actual source moments or background satisfy that criterion remains unknown; no actual RW cancellation counterexample or survival theorem is claimed.

## 1. Fixed actual-source interface

Let u=2^mu>=8, K=GF(u), F=GF(u^6), Q=u^6 and
\[
M=(Q-1)/(u-1),\quad U_4=u+u^2+u^3+u^4,\quad
B=4U_4,\quad \kappa=4u^5,\quad d_*=B+\kappa+2=4M-2.
\]
Write L_a(w)=1+(w+a)^(u-1). The first OUTPUT separator X, the third separator Y, two third-beacon coordinates Z_1,Z_2, the third spare W, the sparse J-block pairs and the first last digit have already been completely summed as in pulse4.

Hold fixed both first-beacon values T_b, all remaining first coordinates and the **same permitted third remainder**. Each edge retains its original third last label; no route or remainder changes with w. Retain all original actual source/checker/route/density interfaces and nonzero fixed public factors as conditions, not as a new certification of their full upstream construction.

At the first-spare place k, the actual source support gives
\[
V_i(w,Z)=L_0(w)\widetilde V_i(Z),\qquad
O(w,Z)=L_{a_k}(w)\widetilde O(Z),\quad
a_k\in K^\times,\quad \widetilde O=\widetilde\lambda L_o,\quad o\ne p,q.
\]
The stripped sections are fixed actual polynomials of degree below u. Their four/three coefficient pattern is
\[
Q_0(z)=q_0+q_2z^2+q_\kappa z^\kappa+q_Tz^{\kappa+2},\qquad
Q_5(z)=q_0+q_2z^2+q_Tz^{\kappa+2}.
\]
All q_j are from those same sections. A nonzero q_T is useful for pulse4's pointwise density, but is not needed for the present summation identity.

Let c,d be the fixed actual beacon coefficient and squared nonzero grid offset. Put U_b=T_b^2 and
\[
\begin{aligned}
D_x&=A_xU_b^{2(u-1)}+c(U_b+d)^{2(u-1)},\\
C_x&=A_xU_b^{3u/2-2}+c(U_b+d)^{3u/2-2},\\
\alpha&=A_x+c,\qquad
b_0=\alpha D_x^{2u^5}+cd\,C_x^{2u^5}.
\end{aligned}                                                       \tag{1}
\]
A_x is the actual reference third-source background. These values are fixed during the complete w sum; none is independently selected as advice.

For w outside K, let s=L_0(w), z=w/(w+a_k), eta=w^(2(u-1)). The pulse4 completed subtable is
\[
\mathcal F_x(w)=\overline G_xs^{d_*+2}
(1+(D_x\eta)^2)^{U_4}
[\alpha Q_0(z)+b_0 w^{4-\kappa}Q_5(z)],                              \tag{2}
\]
with Gbar_x independent of w. The additional exponent2 in s comes from the **completed spare public weight**. Its presence is essential.

## 2. The ordinary-polynomial extension and exact full sum

Negative exponents and z are valid only at off-grid nonzero points. For the full sum, define v=w^(u-1), ell=L_{a_k}(w), and restore the ordinary polynomial:
\[
\begin{aligned}
\mathcal F_x(w)=\overline G_x(1+D_x^2v^4)^{U_4}\bigl\{
\alpha[&
q_0s^{4M}+q_2s^{4M-2}\ell^2
+q_\kappa s^{4M-\kappa}\ell^\kappa
+q_Ts^{4M-\kappa-2}\ell^{\kappa+2}]\\
+b_0v^\kappa[&
q_0s^{4M}+q_2s^{4M-2}\ell^2
+q_Ts^{4M-\kappa-2}\ell^{\kappa+2}]
\bigr\}.                                                            \tag{3}
\end{aligned}
\]
Here eta^(2u^5)=v^kappa; no negative exponent is needed. The denominator clearing in (3) follows directly from the original section scaling, rather than arbitrary interpolation from off-grid values. Every exponent of s is positive.

The result is
\[
\boxed{\displaystyle
\sum_{w\in F}\mathcal F_x(w)
=\overline G_x(1+D_x^2)^{U_4}
[\alpha Q_0(1)+b_0Q_5(1)].}                                         \tag{4}
\]
The full grid contribution is Gbar_x alpha q_0: at w=0, s=1,ell=v=0; at every other grid point s=0. Therefore
\[
\boxed{\displaystyle
\sum_{w\in F\setminus K}\mathcal F_x(w)
=\overline G_x\{(1+D_x^2)^{U_4}
[\alpha Q_0(1)+b_0Q_5(1)]+\alpha q_0\}.}                             \tag{5}
\]
The relevant first-coordinate domain is the full F. Formula (5) is included to prevent an off-grid-only total from being mistaken for it.

### Proof of (4)

The seven raw terms in (3) are exactly the seven terms of the proven pulse3 projection, with k=D_x^2, mathfrak a=alpha, mathfrak b=b_0 and source coefficients q_j. To make the reuse explicit, scale w=a_k x and set r^4=D_x^2. Then s=L_0(x), ell=L_1(x), v=x^(u-1) and
\[
H=s(1+rv),\quad H^B=s^B(1+D_x^2v^4)^{U_4},\quad
\deg H\le2u-2,\quad [x^{u-1}]H=1+r.
\]
The seven terms are L^2H^BR^kappa with
\[
(L,R)=(s^2,s),(s\ell,s),(s^2,\ell),(s\ell,\ell),
       (s^2,sv),(s\ell,sv),(s\ell,\ell v).
\]
The degree bound is 8Q-4u-4<8(Q-1). All exponents are even. Positive field power sums can keep only 2,4,6 times Q-1. The high factors have exponents divisible by4u. The low factor L^2 cannot supply residue4u-2, excluding the first possibility; the other two select its boundary coefficients in degrees4u-4 and4u-6.

After removing those low exponents, the lower four base-u positions must each select u-1 from H. Its degree at most2u-2 makes the next candidate2u-1 unavailable, so there are no carries. The final R position selects u-1 or3u/2-1. Thus, writing lambda=[x^(2u-2)]L and nu=[x^(2u-3)]L, each moment equals
\[
(1+r)^B
\{\lambda^2([x^{u-1}]R)^\kappa+
  \nu^2([x^{3u/2-1}]R)^\kappa\}.
\]
For the seven listed pairs the bracket is1: s^2 has boundary coefficients(1,0), s ell has(1,1), s,ell,sv have relevant R coefficients(1,0), and ell v has(0,1). Hence all seven full sums equal
\[
(1+r)^B=(1+D_x^2)^{U_4}.
\]
Collect the q_j terms to obtain (4). The direct grid evaluation proves (5). This proof uses the raw extension and exact public weight.

## 3. Two actual source moments determine the projection

For a stripped section T define
\[
a_T=[Z^{u-1}]T,\quad
g_T=[Z^{2u-3}]L_pT,\quad
h_T=T(p)+T(q),\quad
t_T=[Z^{3u/2-1}](L_p+L_q)T.
\]
Use a_i,g_i,h_i,t_i for tilde V_i and a_O,g_O,t_O for tilde O. All are **stripped** moments here, rather than moments at the old diagonal w_0. Let e=kappa/2 and define
\[
\begin{aligned}
J&=\sum_{i=0}^1h_i^{B/2}
 [(a_i+a_O)h_i^e+(g_i+g_O)(t_i+t_O)^e],\\
N&=t_O^e\sum_{i=0}^1g_i h_i^{B/2}.
\end{aligned}
\]
The same-source coefficient formulas give
\[
Q_0(1)=J^2,\qquad q_\kappa=N^2,\qquad
Q_5(1)=(J+N)^2.
\]
For example, expanding Q_0(1) gives
\[
\sum_i h_i^B[(a_i+a_O)^2h_i^\kappa+
             (g_i+g_O)^2(t_i+t_O)^\kappa]=J^2.
\]
The omitted coefficient q_kappa is t_O^kappa sum_i g_i^2 h_i^B=N^2. Therefore
\[
\boxed{\displaystyle
\sum_w\mathcal F_x(w)=
\overline G_x(1+D_x^2)^{U_4}
[(\alpha+b_0)J^2+b_0N^2].}                                         \tag{6}
\]
This compression does not make J,N cheaply evaluable. Their obtaining cost remains charged.

## 4. Cancellation, actual reachability and the limit of pointwise density

Assume Gbar_x!=0. Equation (6) is nonzero exactly when
\[
D_x\ne1,\qquad
\sqrt{\alpha+b_0}\,J+\sqrt{b_0}\,N\ne0.                              \tag{7}
\]
These are necessary and sufficient conditions on the actual source, not freely selected field parameters.

Several exact fibers are useful:

| Fixed actual scalar fiber | Additional condition for nonzero full sum |
|---|---|
| A_x=c, c,d,C_x!=0 | D_x!=1 and J!=N |
| b_0=0, alpha!=0 | D_x!=1 and J!=0 |
| alpha=b_0!=0 | D_x!=1 and N!=0, equivalently q_kappa!=0 |

The old q_T!=0 implies
\[
g_O^2t_O^\kappa(h_1^B+h_0^B)\ne0.
\]
It does not control J,N or q_kappa. Thus the highest-coefficient assumption cannot replace the second condition in (7).

If the **actual** background has D_x=1, the full sum is zero for every actual J,N. Moreover, under pulse4's q_T!=0 and (alpha,b_0)!=(0,0) hypotheses, at most 8u^5+6 off-grid values can vanish: D_x eta(w)=1 has no off-grid roots when D_x=1, and the cleared scalar polynomial has at most that many roots. Thus a \(1-O(1/u)\) fraction is nonzero along sufficiently large legal lengths. This asymptotic claim is not inferred from u=8 or16. Hence conditional actual D_x=1 is an exact certificate of cancellation despite dense pointwise nonzero values. Its possible grid correction in (5) does not change this full-field conclusion.

This is **not** yet a reachable RW counterexample. At fixed off-grid T_b, U_b!=0, actual D_x=1 would require
\[
A_x=U_b^{-2(u-1)}
 [1+c(U_b+d)^{2(u-1)}].                                             \tag{8}
\]
The reference background A_x is an evaluation of the same actual source on the fixed permitted third remainder. Defining a hypothetical scalar by (8), changing the route to arrange it, or calibrating a new beacon coefficient does not establish reachability under this round's assumptions. None of those operations was performed.

Likewise the moment cancellation in (7) is a relation between stripped actual first-source moments and the actual third background. The local interfaces614.17/614.19,621.7/621.9 do not assign their values or force that relation. No proof of actual projected survival, universal disappearance or attainable cancellation was found in this bounded round. This is an explicit unresolved mathematical obligation, not an inference that all these outcomes are equally likely.

The synthetic F4 example remains synthetic. Its singleton section was conditionally excluded as an entire actual section in pulse3; its formal zero projection cannot be relabeled a reachable actual cancellation here. No claim is promoted from an example, a file number or the prior pointwise theorem.

## 5. Review and stopping boundary

Fresh-context same-model reviewer [same-model review role] independently derived (4)--(7), checked grid extension/public s^2 weight, the stripped-source moment compression and the actual background requirement (8). It found no actual interface that implies universal survival or disappearance. This is independent context, not independent-model or human validation.

No new numeric enumeration, source computation, HPC/SAT run or parameter sweep was opened. The proof reuses the already sealed universal seven-basis argument and its existing raw finite check, whose k=1 case has all seven complete sums zero. That supports the exact algebra; it is not evidence that an actual D_x equals1.

This pulse completes the first-spare sum and stops at the actual criterion (7). Fixed beacon values and the same third remainder are preserved throughout. Remaining first-beacon and other first-coordinate sums, other third remainders, real incidence defects, other norm orbits, absolute trace, auxiliary PCP tables and the physical JK response remain outside this result. Pointwise root averaging cannot answer (7), and no main-conjecture conclusion follows.
