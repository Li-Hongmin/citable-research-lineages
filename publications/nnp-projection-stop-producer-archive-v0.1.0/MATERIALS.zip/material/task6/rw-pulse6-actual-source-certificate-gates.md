> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# RW pulse6: actual reference-head and moment certificate gates

2026-10-03. Private task-workspace result; all original source and earlier packets remain read-only.

This bounded round does not certify or exclude an actual cancellation. It removes an ambiguity about the third background: A_x is an explicit weighted slice of the reference first raw block's actual count/output head, rather than a free scalar or an aggregate requiring the later simulation gates. The criterion for D_x=1 becomes a finite Boolean certificate using that head. Two further same-source identities isolate the missing moment tests. No new integral, pointwise selection, computation or source calibration is used.

## 1. The criterion being tested

Retain the field and notation from pulse5:
\[
F=\mathbb F_{u^6},\ K=\mathbb F_u,\ Q=u^6,\quad
U_4=u+u^2+u^3+u^4,\quad B=4U_4,\quad
\kappa=4u^5,\quad e=\kappa/2.
\]
Fix the two first-beacon values T_b, all other remaining first coordinates and **one unchanged permitted third remainder**. Each edge keeps its original third last label. All actual source/checker/route interfaces remain conditions inherited from the preceding results.

The completed first-spare sum is
\[
\Sigma_x=\overline G_x(1+D_x^2)^{U_4}
[(\alpha+b_0)J^2+b_0N^2],
\]
\[
\alpha=A_x+c,\quad
b_0=\alpha D_x^{2u^5}+cd\,C_x^{2u^5},\quad
D_x=A_xU_b^{2(u-1)}+c(U_b+d)^{2(u-1)},\quad U_b=T_b^2.
\]
The source moments J,N are stripped actual first-source moments as in pulse5. For Gbar_x!=0, the remaining exact test is
\[
D_x\ne1,\qquad
\sqrt{\alpha+b_0}\,J+\sqrt{b_0}\,N\ne0.                              \tag{1}
\]
This round determines what actual source data these tests require, rather than replacing them by another coordinate average.

## 2. The actual third background lies in the first raw block

Let H=W_1/(g_{\rm gap}Q^3) be the routed modulus of597, and
\[
t=\lceil\log_QH\rceil.
\]
The t retained suffix digits are the **lowest** t field coordinates, including the last digit. Their last value is the original hard-suffix grid label tau_x. The other completely free third high coordinates were fixed to grid zero in616.2/617.3, outside the explicitly separated beacon, separator and spare coordinates. To define A_x, take the zero-grid slice in those separated coordinates too. The sparse J coordinates in the non-OUTPUT branch are also zero.

Consequently, every Boolean grid point entering this slice has raw **grid** rank r<u^t. Grid rank uses base u, not the base Q indexing of an off-grid field point. Since Q=u^6,
\[
Q^t<QH,\qquad
u^t<(QH)^{1/6}
=\frac{W_1^{1/6}}{u^2g_{\rm gap}^{1/6}}<W_1.                        \tag{2}
\]
The first inequality follows directly from the ceiling definition and holds even when H is an exact power of Q. The last inequality uses the positive legal parameters W_1>1,u>=2,g_gap>=1.

Thus all grid coefficients entering A_x belong to the **first raw W_1 block**. The actual paired source construction516.10 says that the reference first block is the unaugmented pi_1 B_1 0* block.516.12 puts the reference ledger into checked-zero output padding, while517.1 preserves the count/output head and places the changed comparison gates near G_1, far beyond W_1. The public grid permutation407.23a is the identity on this raw prefix, which lies below R_1-1.

In particular, simulation-gate values, later logical NP-witness slots and the comparison-gadget region do not enter this background slice. This is a statement about A_x only. It does not remove those source regions from the separately fixed off-grid **first** source moments J,N.

Define the actual reference Boolean head
\[
h_{\rm ref}(r)=
\begin{cases}
\pi_1[r],&0\le r<\rho_1,\\
B_1[r-\rho_1],&\rho_1\le r<\rho_1+2n_1,\\
0,&\text{otherwise}.
\end{cases}
\]
Here pi_1 and B_1 are the same count vector/output word of the original reference maximal history. No head values have been read as credentials, regenerated or supplied as independent advice.

Let
\[
I_x=\{r:\ 0\le r<u^t,\ r\bmod u=x,\ r<\rho_1+2n_1\}.
\]
For r in I_x write a_i(r) in K for its ith grid digit above the last one, i=1,...,t-1. Let zeta_i denote the corresponding retained third high coordinate. Their order is from the last digit upward; all other grid digits are zero. The actual background is exactly
\[
\boxed{\displaystyle
A_x=\sum_{r\in I_x}h_{\rm ref}(r)
        \prod_{i=1}^{t-1}L_{a_i(r)}(\zeta_i).}                      \tag{3}
\]

**Proof.** Tensor interpolation at a grid-zero coordinate annihilates every coefficient whose corresponding grid digit is nonzero. The last grid evaluation tau_x selects r mod u=x. All surviving points are below u^t; (2) and the actual reference block description then leave precisely the head coefficients in I_x. This is the canonical tensor interpolation of that slice. No parity over free grid digits was taken.

Equation(3) is therefore a **slice**, not the marginal w^(t) in597.10, which XORs over every free grid digit. Substituting that parity marginal for this background would change the source.

## 3. D_x=1 is an actual Boolean-head syndrome

The actual beacon coefficient in617.8/619.12 is
\[
c=\prod_{i=1}^{t-1}L_0(\zeta_i)\ne0.
\]
Set
\[
\Omega_r=\prod_i\frac{L_{a_i(r)}(\zeta_i)}{L_0(\zeta_i)},\qquad
\mathcal H_x=\sum_{r\in I_x}h_{\rm ref}(r)\Omega_r.
\]
Then (3) gives A_x=c Hcal_x. On the visible period's off-grid retained coordinates,
\[
\frac{L_a(\zeta)}{L_0(\zeta)}
=\frac{\zeta}{\zeta+a}\quad(a\in K),                                 \tag{4}
\]
and every denominator is nonzero. Thus all weights are fixed by the same retained tuple.

For the fixed off-grid T_b, U_b!=0. With f=2(u-1), actual D_x=1 is equivalent to
\[
\boxed{\displaystyle
\mathcal H_x=
\Theta_x:=U_b^{-f}[c^{-1}+(U_b+d)^f].}                               \tag{5}
\]
This follows by substituting A_x=c Hcal_x into the definition of D_x, dividing by nonzero c and U_b^f.

For any chosen binary basis of F and coordinate maps beta_j, j=0,...,6mu-1, (5) is precisely
\[
\bigoplus_{r\in I_x}
h_{\rm ref}(r)\,\beta_j(\Omega_r)=\beta_j(\Theta_x)
\quad\text{for each }j.                                             \tag{6}
\]
These are finite XOR equations on the **actual** pi_1,B_1 bits. Checking all equalities certifies D_x=1; one verified mismatch certifies D_x!=1. Their finite form does not prove that their long input sum has an address-scale evaluator.

No such actual-head weighted value or certificate is supplied by the local chain read in this round. The previous common tuple was chosen existentially; this packet does not fabricate its numerical coordinates or a head vector. Therefore (5) has not been proved, refuted or numerically evaluated for an actual chosen remainder.

The reference ledger being all zero is insufficient. It sets the corresponding padded-input coefficients to zero, but leaves pi_1B_1 intact. Off-grid retained interpolation combines the head coefficients in (3), not just the ledger grid line. Hence one cannot infer A_x=0, A_x=c or D_x!=1 merely from the zero-ledger construction.

If the stripe I_x were empty or the **actual** head bits on it were all zero, (3) would give A_x=0; then c^M!=1 would exclude D_x=1, since (U_b+d)^f lies in the norm-one subgroup mu_M. This is a sufficient source-aware certificate, not a claim that the actual eligible stripe is empty, zero or has that norm. No extra genericity or cancellation-avoidance hypothesis is assumed.

## 4. The q_kappa and q_T tests remain different actual moments

Use stripped actual first sections tilde V_i,tilde O from pulse5, with moments a_i,g_i,h_i,t_i and a_O,g_O,t_O. Put
\[
H_i=h_i^{B/2},\quad \delta H=H_1+H_0,\quad
\delta g=g_1+g_0.
\]
The previously selected q_T!=0 gives
\[
q_T=g_O^2t_O^\kappa(\delta H)^2\ne0,
\]
so delta H,g_O,t_O are nonzero. Since
\[
N=t_O^e(g_1H_1+g_0H_0),
\]
substitute g_1=g_0+delta g to obtain
\[
\boxed{N=t_O^e[\delta H\,g_0+H_1\delta g],\qquad
q_\kappa=N^2.}                                                       \tag{7}
\]
Consequently
\[
\boxed{\displaystyle
q_\kappa\ne0\ \Longleftrightarrow\
g_0\ne\frac{H_1\delta g}{\delta H}.}                                  \tag{8}
\]
The right-hand threshold is itself an actual-source expression. It is not known public advice just because the formula is short.

The actual paired difference remains the two-line difference517.3/610.6, after removing the two separator Lagrange factors:
\[
\widetilde V_1+\widetilde V_0
=\alpha_Bp_B+\alpha_Gp_G.
\]
Thus
\[
\delta g=\alpha_B g_{p_B}+\alpha_Gg_{p_G}.
\]
The two coefficients are fixed products of actual high-coordinate Lagrange factors, and p_B,p_G are two recodings of the same published B_0. The common OUTPUT and common beacon introduce no paired difference. At a falling hard-suffix edge the selector difference is alpha_B because the gadget has zero endpoint values, but its whole-line g moment still contributes to delta g.

For a canonical line T(Z)=sum_d v_d L_d(Z), the exact coefficient is
\[
g_T=\sum_{d\in K}(p+d)v_d.
\]
For the reference first section those v_d are evaluations of the full remaining tensor source at the fixed first tuple. Unlike (3), other free first coordinates remain off-grid; its g_0 may include actual non-OUTPUT grid source values outside the first raw head. The fact that A_x used only a reference head slice does not turn g_0 into zero or an independently selectable scalar.

On the coefficient fiber alpha=b_0!=0 and D_x!=1, (8) is exactly the missing survival test. Under delta g=0 it simplifies to g_0!=0, but neither delta g=0 nor g_0!=0 is proved for the actual selected sections here.

For the A_x=c, C_x!=0 fiber, another useful identity identifies the contribution supplied by q_T. Define
\[
E=g_Ot_O^e\delta H,\qquad
L=\sum_{i=0}^1H_i[(a_i+a_O)h_i^e+(g_i+g_O)t_i^e].
\]
Expansion of pulse5's J,N gives
\[
\boxed{J+N=L+E,\qquad E^2=q_T\ne0.}                                 \tag{9}
\]
The cross term g_i t_O^e cancels with N, leaving g_O t_O^e in each summand. Hence, when D_x!=1 and b_0!=0, actual survival on A_x=c is precisely L!=E. A verified L=0 would suffice because E!=0; no such value is assumed or established.

Equations(7)--(9) explain exactly why a nonzero highest coefficient cannot certify the needed lower coefficient or projected value. They keep the same actual source in every term.

## 5. Bounded verdict and smallest missing facts

**Proved in this round:** the actual raw-head formula(3), the fixed-beacon D_x=1 certificate(5)--(6), and the same-source moment tests(7)--(9), under the original local interfaces. Fresh-context review agrees.

**Still unproved:** either satisfaction or exclusion of(5) for the actual reference maximal-history head at the fixed permitted remainder; and, if D_x!=1, the actual projected moment inequality in(1). There is no source constraint found in the bounded dependency chain that assigns these weighted values, forces total cancellation, or forces total survival.

The smallest actual-source gaps are now explicit:

1. Prove or refute the actual pi_1B_1 weighted-head equality(5), with the same retained tuple and fixed T_b.
2. On a surviving background, prove the corresponding actual moment comparison. On alpha=b_0!=0 it is(8); on A_x=c it is L!=E in(9); otherwise use(1) directly.

These are not two freely chosen parameter problems: both must be resolved in the same actual source/history family. No new strong assumption such as a generic head, nonzero reference moment, independent background, altered checker or adjustable remainder has been inserted. The selected tuple and the long source sums are not automatically an efficient certificate just because there are6mu output equations.

No subsequent coordinate was integrated and no pointwise root average was used. Remaining outer sums, real incidence defects, other norm orbits, trace, auxiliary PCP components and physical JK response remain open. The main conjecture is not solved, and this result is not a NOGO certificate for the whole mechanism.

## 6. Review and preservation

New-context same-model reviewer [same-model review role] independently checked the retained-coordinate slice, corrected its initial broad interpretation to the first raw count/output head after the rank bound, and confirmed the normalized Boolean syndrome. This is not independent-model or human validation. It did not compute the actual head or alter any source.

The support/mapping argument uses407.23a,516.10/516.12,517.1,597.4,610.4/610.6,616.2,617.3 and619.12. All original dependencies and packets remain read-only. No code, numeric source evaluation, solver, remote computation, Git operation or publication was performed. The preservation snapshots and new manifest record the delivered versions.
