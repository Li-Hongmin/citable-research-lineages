> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Pulse4 independent-context same-model review

Reviewer: [same-model review role], created with no inherited turns. Scope was the same actual source projection and D eta condition, with a fixed permitted third remainder and no adjacent outer-sum calculation.

The reviewer independently obtained the two source-moment combinations J,N and exact cancellation test before being shown the proposed first-spare separation. It then checked the candidate directly against614,620,621 and the local source geometry. No numerical recomputation or file mutation was performed.

Its final assessment of rw-pulse4-separated-first-spare.md was:

> 未发现实质数学错误，新稿可接受为条件性局部非零定理。
>
> - 同源缩放(5)–(7)正确；每项总源次数为d_*=B+kappa+2，旧off-grid最高系数非零严格继承为q_T!=0。
> - (11)分类正确：w^(2(u-1))的像为mu_M，核为K^times。D在mu_M minus{1}恰有u-1个off-grid坏点；D=0,1或D^M!=1均无。
> - (12)的L_0(w)^(d_*+2)次数正确：源缩放贡献d_*，完整spare公共权重贡献2。605.2的a(xi)仅依赖最后first数字，不新增w依赖。
> - 根平均仅选择自由first-spare w。605.1的Cartesian域允许第三remainder保持固定；各边仅保留原指定last label，没有随w改路由。
> - alpha=b_0!=0的最高项分类和alpha=0时借固定beacon保证b_0!=0均成立。
>
> 完整first-spare求和仍未判定；原实际源支持、路由、密度和固定公共因子非零仍是明确的上游接口。未改稿、未重复计算。

This is independent context using the same model, not an independent-model or human certificate. The lightweight finite implementation provides separate support for source scaling and the norm-image classification, using synthetic canonical sections and reused verified field arithmetic. Neither route reachability nor actual moment evaluation was certified numerically.
