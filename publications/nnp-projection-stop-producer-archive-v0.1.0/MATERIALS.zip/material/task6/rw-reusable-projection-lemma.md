> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# 完整加权有限域投影 lemma（封存证明节录）

这是pulse3/pulse5已证、已复核恒等式的自足节录，不是第七轮新定理。数学陈述不依赖未知的实际RW head或moments；实际源适用性另由既有接口负责。私有候选，未发布；署名、许可、文献/新颖性及异模型/人类验证尚待父统一流程。

设u=2^mu>=8，K=GF(u)，F=GF(u^6)，Q=u^6，并设
\[
M=1+u+u^2+u^3+u^4+u^5,\quad U_4=u+u^2+u^3+u^4,\quad
B=4U_4,\quad\kappa=4u^5 .
\]
任取a∈K非零、D,alpha,b,q0,q2,qk,qT∈F。对w∈F定义普通多项式的值
\[
s=1+w^{u-1},\quad \ell=1+(w+a)^{u-1},\quad v=w^{u-1},
\]
\[
\begin{aligned}
\Phi(w)=(1+D^2v^4)^{U_4}\{\,\alpha[&
q_0s^{4M}+q_2s^{4M-2}\ell^2+
q_ks^{4M-\kappa}\ell^\kappa+
q_Ts^{4M-\kappa-2}\ell^{\kappa+2}]\\
{}+bv^\kappa[&
q_0s^{4M}+q_2s^{4M-2}\ell^2+
q_Ts^{4M-\kappa-2}\ell^{\kappa+2}]\,\}.
\end{aligned}
\]
全部s指数为正，故此定义在grid上同样成立，无需使用负幂或有理插值。则
\[
\boxed{\sum_{w\in F}\Phi(w)
=(1+D^2)^{U_4}
[\alpha(q_0+q_2+q_k+q_T)+b(q_0+q_2+q_T)].}
\]
grid总贡献是alpha q0，所以off-grid总和等于上述右端加alpha q0（特征二）。

**证明。** 缩放w=ax不改v、s，并使ell=1+(x+1)^{u-1}。取唯一r∈F使r^4=D^2，令H=s(1+rv)。则
\[
H^B=s^B(1+D^2v^4)^{U_4},\quad
\deg H\le2u-2,\quad[x^{u-1}]H=1+r.
\]
Phi的七个系数项分别是L^2H^BR^kappa，其(L,R)依序为
\[
(s^2,s),\ (s\ell,s),\ (s^2,\ell),\ (s\ell,\ell),
\ (s^2,sv),\ (s\ell,sv),\ (s\ell,\ell v).
\]
每项次数至多8Q−4u−4<8(Q−1)，每个指数均偶数。有限域幂和在正次数上只保留Q−1的倍数，故仅候选2、4、6倍Q−1；常数项全F相加为Q=0。高因子H^BR^kappa的次数均可被4u整除，而L^2的次数≤4u−4，不可能供给2(Q−1)所需的模4u余数4u−2。其余两倍数要求L^2提供次数4u−4、4u−6，系数分别为lambda^2、nu^2，其中lambda=[x^{2u−2}]L、nu=[x^{2u−3}]L。

除去这些低次数后，H的四个base-u位置都必须选取u−1：由于degH≤2u−2，下一候选2u−1不可取，从最低位起逐位确定且无进位。最高R位置随后分别要求u−1或3u/2−1。因此每项全F和为
\[
(1+r)^B\{
\lambda^2([x^{u-1}]R)^\kappa+
\nu^2([x^{3u/2-1}]R)^\kappa\}.
\]
s^2的(lambda,nu)=(1,0)，sell的为(1,1)；s、ell、sv的相应R系数为(1,0)，ellv为(0,1)。七项括号全部为1，故每项和为
\[
(1+r)^B=(1+D^2)^{U_4}.
\]
按原系数合并即得公式。grid上w=0时s=1、ell=v=0；其他w∈K时s=0，证明grid及off-grid公式。∎

**可解释的精确边界。** 若另有已验证的同源关系
q0+q2+qk+qT=J^2、qk=N^2，则完整和为
\[
(1+D^2)^{U_4}[(\alpha+b)J^2+bN^2].
\]
乘非零固定因子不影响非零判定，完整和非零当且仅当
D!=1 且 sqrt(alpha+b)J+sqrt(b)N!=0。无需qT非零，也不能由qT非零推定这一判据成立。实际RW的D,J,N是同源确定值，其可达性/比较仍未判定；此lemma不提供实际非零密度、outer sums、trace、JK结果或主猜想结论。

**既有验证出处。** 原证明及same-source关系完整存于rw-pulse3-complete-x-projection.md、rw-pulse5-complete-first-spare.md；相关独立新上下文同模型审查为rw-pulse3-review-record.md、rw-pulse5-review-record.md。已有有限核验源码/原始输出为rw_xsum_check.c、rw-pulse3-xsum-check-output.txt，所有版本由原manifest封存。本轮没有重跑或追加数学实验；节录不声称获得新的独立外部认证。
