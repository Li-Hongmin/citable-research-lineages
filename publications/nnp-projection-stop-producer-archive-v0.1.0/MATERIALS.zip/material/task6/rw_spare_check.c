// SPDX-License-Identifier: Apache-2.0
// Archival checker source; not executed in this packaging audit.
// Historical asserts may be disabled under optimization; no fresh mathematical certification.
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* Lightweight exhaustive one-coordinate check only: F=GF(2^18), u=8.
   Polynomial x^18+x^7+1 is independently checked in the companion command.
   No actual RW word, source table, solver or project file is read. */
typedef uint32_t fe;
#define Q (1u<<18)
#define U 8u
#define MOD ((1u<<18)|(1u<<7)|1u)
static fe mul(fe a,fe b){fe r=0;while(b){if(b&1)r^=a;b>>=1;a<<=1;if(a&Q)a^=MOD;}return r;}
static fe powf_(fe a,uint32_t e){fe r=1;while(e){if(e&1)r=mul(r,a);a=mul(a,a);e>>=1;}return r;}
static fe L(fe b,fe x){return 1^powf_(x^b,U-1);}
static void require(int ok,const char *why){if(!ok){fprintf(stderr,"FAIL %s\n",why);exit(1);}}
int main(void){
  fe K[U];unsigned nk=0;
  for(fe x=0;x<Q;x++)if(powf_(x,U)==x)K[nk++]=x;
  require(nk==U,"subfield cardinality");
  unsigned E[32]={0};for(unsigned s=0;s<32;s++)for(unsigned j=0;j<5;j++)if(s&(1u<<j))E[s]+=1u<<(3*(j+1));
  fe y=0,D=0,C=0,z=0,sigma=0;
  for(y=2;y<Q;y++){
    if(powf_(y,U)==y)continue;
    fe yy=mul(y,y);
    D=powf_(yy,14)^powf_(yy^1,14);C=powf_(yy,10)^powf_(yy^1,10);
    if(D&&C){z=powf_(y,14);sigma=mul(mul(D,z),mul(D,z));break;}
  }
  require(y<Q&&sigma,"off-grid nonzero parameters");
  fe lsq=mul(L(0,y),L(0,y)),lb2[U];
  for(unsigned i=0;i<U;i++)lb2[i]=mul(L(K[i],y),L(K[i],y));
  fe moments[32]={0};uint32_t M=(Q-1)/(U-1);
  fe alpha=powf_(sigma,(Q-1)-U);
  fe cf=powf_(C,2*(1u<<15)), full=0;unsigned good=0,off_good=0;
  /* A stricter abstract witness has exactly the local kernel form (609.7),
     rather than prescribing arbitrary 32 coefficients. It still is NOT a
     claimed reachable source section of the published RW checker. */
  fe local_sum=powf_(sigma,Q/4),local_B=1^local_sum;
  fe G5=local_sum^powf_(local_B,1+2*(1u<<15));
  require(G5!=0,"local-form highest constant");
  fe local_H5_constant=mul(mul(G5,G5),powf_(local_sum,4*(E[15])));
  require(local_H5_constant!=0,"local-form highest section nonzero at zero");
  fe local_H0=powf_(local_sum,4*M-2);
  require(local_H0!=0,"local-form empty branch nonzero");
  fe local_full=0;unsigned local_good=0;
  for(fe w=0;w<Q;w++){
    fe v=L(0,w),theta=0;
    for(unsigned i=0;i<U;i++)theta^=mul(lb2[i],L(K[i],w));
    fe weight=mul(lsq,mul(v,powf_(theta,2*(M-1))));
    fe vpow[5];vpow[0]=powf_(v,16);for(unsigned j=1;j<5;j++)vpow[j]=powf_(vpow[j-1],U);
    fe products[32];products[0]=1;
    for(unsigned s=1;s<32;s++){unsigned j=__builtin_ctz(s);products[s]=mul(products[s^(1u<<j)],vpow[j]);}
    for(unsigned s=0;s<32;s++)moments[s]^=mul(weight,mul(v,products[s]));
    /* A=c=d=t=1; H_[5](W)=1+alpha W^u and H(0)=1. */
    fe dv=mul(D,v),arg=mul(dv,dv);
    fe fx=mul(cf,mul(mul(v,vpow[4]),1^mul(alpha,powf_(arg,U))));
    fe term=mul(weight,fx);full^=term;
    if(term){good++;if(powf_(w,U)!=w)off_good++;}
    fe base=powf_(local_sum,4)^arg;
    fe local_section=mul(mul(G5,G5),powf_(base,E[15]));
    fe local_fx=mul(cf,mul(mul(v,vpow[4]),local_section));
    fe local_term=mul(weight,local_fx);local_full^=local_term;if(local_term)local_good++;
  }
  for(unsigned s=0;s<32;s++){
    fe want=mul(lsq,powf_(y,4*(U-1)*E[s]));
    require(moments[s]==want,"one-coordinate transfer for all 32 basis branches");
  }
  require(full==0,"complete spare sum counterexample");
  require(good>Q/1000&&off_good>Q/1000,"many nonzero local values");
  require(local_full==0&&local_good>Q/1000,"local-form complete cancellation with dense values");
  printf("field polynomial=0x%x; u=%u Q=%u M=%u\n",MOD,U,Q,M);
  printf("y=%u D=%u C=%u z=%u sigma=%u alpha=%u\n",y,D,C,z,sigma,alpha);
  printf("PASS all 32 complete-field basis transfers\n");
  printf("PASS abstract cancellation: full_sum=%u nonzero_values=%u off_grid_nonzero_values=%u\n",full,good,off_good);
  printf("PASS local-609.7-form abstract cancellation: A_local=1 B_local=%u G5=%u H0=%u H5(0)=%u full_sum=%u nonzero_values=%u\n",local_B,G5,local_H0,local_H5_constant,local_full,local_good);
  return 0;
}
