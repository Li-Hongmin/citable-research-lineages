// SPDX-License-Identifier: Apache-2.0
// Archival checker source; not executed in this packaging audit.
// Historical asserts may be disabled under optimization; no fresh mathematical certification.
/* Independent complete-Z coefficient check of the paired-source restriction.
   Reuses only the finite-field arithmetic from the earlier one-coordinate
   check. All section tables here are synthetic canonical field sections,
   NOT the published RW word or a claimed reachable counterexample. */
#define main earlier_spare_check_main
#include "rw_spare_check.c"
#undef main

static fe rng_state=0x13751;
static fe next_fe(void){rng_state^=rng_state<<13;rng_state^=rng_state>>17;rng_state^=rng_state<<5;return rng_state&(Q-1);}
static void moments_from_grid(const fe *K,const fe *values,fe *a,fe *g,fe *h,fe *tm){
  fe coeff[U]={0};*a=*g=*tm=0;*h=values[0]^values[1];
  for(unsigned j=0;j<U;j++){
    *a^=values[j];*g^=mul(K[j],values[j]);
    coeff[0]^=mul(values[j],1^powf_(K[j],U-1));
    for(unsigned k=1;k<U;k++)coeff[k]^=mul(values[j],powf_(K[j],U-1-k));
  }
  for(unsigned k=U/2+1;k<U;k++)*tm^=coeff[k]; /* p=0,q=1 */
}
int main(void){
  fe K[U];unsigned nk=0;for(fe x=0;x<Q;x++)if(powf_(x,U)==x)K[nk++]=x;
  require(nk==U&&K[0]==0&&K[1]==1,"subfield grid");
  unsigned Cstar=4*(1u<<15),Bstar=4*(8+64+512+4096),dstar=Bstar+Cstar+2;
  for(unsigned test=0;test<2;test++){
    fe grid[2][U],lambda=next_fe()|1,delta=next_fe()|1;
    for(unsigned j=0;j<U;j++){grid[0][j]=next_fe();grid[1][j]=grid[0][j]^next_fe();}
    grid[1][0]=grid[0][0]^delta;grid[1][1]=grid[0][1];
    fe X=2+test,s=L(0,X),z=mul(X,powf_(X^1,Q-2));
    require(s&&powf_(X,U)!=X,"off-grid X");
    fe a[2],g[2],h[2],tm[2],aO,gO,hO,tO,Ogrid[U]={0};Ogrid[2]=lambda;
    for(unsigned i=0;i<2;i++)moments_from_grid(K,grid[i],a+i,g+i,h+i,tm+i);
    moments_from_grid(K,Ogrid,&aO,&gO,&hO,&tO);
    require(hO==0&&(h[0]^h[1])==delta,"OUTPUT endpoints and falling selector");
    fe c0=0,c2=0,cC=0,cTop=0;
    for(unsigned i=0;i<2;i++){
      fe hb=powf_(h[i],Bstar),hc=powf_(h[i],Cstar),tc=powf_(tm[i],Cstar);
      c0^=mul(hb,mul(mul(a[i],a[i]),hc)^mul(mul(g[i],g[i]),tc));
      c2^=mul(hb,mul(mul(aO,aO),hc)^mul(mul(gO,gO),tc));
      cC^=mul(powf_(tO,Cstar),mul(mul(g[i],g[i]),hb));
      cTop^=mul(mul(gO,gO),mul(powf_(tO,Cstar),hb));
    }
    require(cTop!=0,"selected highest normalized coefficient");
    fe actual[32]={0};
    for(fe Z=0;Z<Q;Z++){
      fe Ls[U];for(unsigned j=0;j<U;j++)Ls[j]=L(K[j],Z);
      fe omega=mul(mul(Ls[0],Ls[0]),powf_(Ls[0]^Ls[1],4*((Q-1)/(U-1)-1)));
      if(!omega)continue;
      fe B=mul(s,mul(z,mul(lambda,Ls[2])));
      for(unsigned i=0;i<2;i++){
        fe V=0;for(unsigned j=0;j<U;j++)V^=mul(grid[i][j],Ls[j]);
        fe A=mul(s,V),sum=A^B,zero=powf_(sum,4),one=powf_(A,4);
        fe lower[16];lower[0]=1;unsigned n=1;
        for(unsigned j=0;j<4;j++){
          zero=powf_(zero,U);one=powf_(one,U);
          for(unsigned r=0;r<n;r++){fe prev=lower[r];lower[r+n]=mul(prev,one);lower[r]=mul(prev,zero);}n*=2;
        }
        fe G5=mul(sum,powf_(A,2*(1u<<15)))^powf_(B,1+2*(1u<<15));
        fe top0=powf_(sum,2+Cstar),top1=mul(G5,G5);
        for(unsigned r=0;r<16;r++){
          fe factor=mul(omega,lower[r]);actual[r]^=mul(factor,top0);actual[r+16]^=mul(factor,top1);
        }
      }
    }
    fe P5=c0^mul(c2,mul(z,z))^mul(cTop,powf_(z,Cstar+2));
    fe P0=P5^mul(cC,powf_(z,Cstar)),scale=powf_(s,dstar);
    require(actual[0]==mul(scale,P0),"empty branch normalized formula");
    require(actual[16]==mul(scale,P5),"highest single branch normalized formula");
    for(unsigned r=0;r<16;r++){
      require(actual[r]==actual[0],"all lower-only coefficients identical");
      require(actual[r+16]==actual[16],"all highest-position coefficients identical");
    }
    /* Check the rational clearing identity on every off-grid X. The
       large-u root bound is analytic; u=8 alone cannot prove that bound. */
    for(fe X2=0;X2<Q;X2++){
      if(powf_(X2,U)==X2)continue;
      fe zz=mul(X2,powf_(X2^1,Q-2)),zz2=mul(zz,zz),zz4=mul(zz2,zz2),zzC=powf_(zz,Cstar);
      fe pp5=c0^mul(c2,zz2)^mul(cTop,mul(zzC,zz2)),pp0=pp5^mul(cC,zzC);
      fe tc=powf_(X2,Cstar*(U-1)),denom=mul(zzC,1^zz4);
      for(unsigned choice=0;choice<2;choice++){
        fe aa=2,bb=choice?2:3;
        fe left=mul(denom,mul(aa,pp0)^mul(bb,mul(tc,pp5)));
        fe right=mul(aa,mul(denom,pp0))^mul(bb,mul(mul(zz4,1^zzC),pp5));
        require(left==right,"rational clearing identity");
      }
    }
    printf("PASS synthetic canonical pair %u: cTop=%u a0=%u a5=%u; complete-Z all 32 coefficients; all off-grid rational-clear tests\n",test,cTop,actual[0],actual[16]);
  }
  puts("No actual RW source, reachable-source certification, or large-u enumeration was performed.");
  return 0;
}
