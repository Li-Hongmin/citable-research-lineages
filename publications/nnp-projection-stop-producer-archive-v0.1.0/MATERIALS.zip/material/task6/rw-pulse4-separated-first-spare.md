> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# RW pulse4: a separate first-spare coordinate can escape the X projection

2026-10-03. Private task-workspace result, with original project read-only.

The complete first-separator X projection from pulse3 need not survive at the old common diagonal parameter. However, separating the **first-spare** value from the two fixed first-beacon values gives a sufficient nonvanishing theorem for the same actual source family. The third remainder is held fixed throughout. This is a local conditional theorem, not a claim about the complete first-spare sum, the physical JK response or the main conjecture.

## 1. Exact test at an unchanged first tuple

Retain u=2^mu>=8, F=GF(u^6), K=GF(u),
\[
U_4=u+u^2+u^3+u^4,\quad B=4U_4,\quad
\kappa=4u^5,\quad d_*=B+\kappa+2,\quad M=(u^6-1)/(u-1).
\]
For the actual sections V_i and common OUTPUT O, let a_i,g_i,h_i,t_i and a_O,g_O,t_O be the four linear moments defined in pulse3. All moments belong to the same source; OUTPUT has zero values at the two edge endpoints.

Define two actual moment combinations, with e=kappa/2:
\[
\begin{aligned}
J&=\sum_{i=0}^1 h_i^{B/2}
 [(a_i+a_O)h_i^e+(g_i+g_O)(t_i+t_O)^e],\\
N&=t_O^e\sum_{i=0}^1g_i h_i^{B/2}.
\end{aligned}
\]
Expanding the four coefficients in 614.19, using the additivity of squaring and the kappa-th power, gives
\[
P_0(1)=J^2,\qquad P_5(1)=P_0(1)+c_\kappa=(J+N)^2.                    \tag{1}
\]
Consequently, with alpha=A+c and beta as in pulse3,
\[
S=\alpha P_0(1)+\beta P_5(1)
 =(\alpha+\beta)J^2+\beta N^2.                                      \tag{2}
\]
The exact cancellation test at that unchanged tuple is
\[
\sqrt{\alpha+\beta}\,J+\sqrt\beta\,N=0.                              \tag{3}
\]
Unique square roots exist in F. This is a compression of the actual charged moments, not an algorithm to obtain them. The original selected diagonal does not specify J,N, so its projected scalar remains unknown. Neither a nonzero highest coefficient nor hard-word complexity alone determines (3).

## 2. Which coordinate is allowed to vary

Let X be the first OUTPUT-separator coordinate already fully summed in pulse3. Let W be the third-spare coordinate also already fully summed. This round varies their companion **first-spare coordinate w** at the place k=ell_2+1 of 621.3. It does not vary X or W, and it does not move the third remainder.

Keep both first-beacon coordinates equal to a fixed value T_b. They remain equal to each other; their equality to w is not required. Fix every other first coordinate and the same permitted third remainder, with the appropriate last label for each reached edge. A_x,c and all third-source values then remain independent of w. Write
\[
U_b=T_b^2,\quad d=b^2\in K^\times,\quad
D_x=A_xU_b^{2(u-1)}+c(U_b+d)^{2(u-1)},\quad
C_x=A_xU_b^{3u/2-2}+c(U_b+d)^{3u/2-2}.                               \tag{4}
\]
In particular, D_x,C_x are now **constant while w varies**. The spare transfer parameter alone is
\[
\eta(w)=w^{2(u-1)}.
\]

The relevant local geometry is explicitly stated in 621.3/621.9: k is above the beacon block and below the OUTPUT separator. Every non-OUTPUT nonzero source rank, including the new single-line beacon, has grid digit zero at k. OUTPUT has a nonzero digit a_k. Tensor Lagrange interpolation of the actual source therefore gives, after the separator factor has been removed,
\[
V_i(w,Z)=L_0(w)\widetilde V_i(Z),\qquad
O(w,Z)=L_{a_k}(w)\widetilde O(Z),\quad
\widetilde O=\widetilde\lambda L_o,\quad o\ne p,q.                    \tag{5}
\]
These are actual restrictions of one fixed systematic source polynomial. Changing w evaluates that polynomial at another allowed field point; it does not choose a new word or prescribe any source coefficients.

The source-support assertion is essential. A non-OUTPUT entry with a nonzero k digit would invalidate (5). Similarly, allowing the third route or background to change with w would invalidate (4). We retain the single-line checker's original local source/route interface, not an arbitrary modified construction.

The complete spare-basis transfer used in pulse1 is valid for any first-spare parameter. The beacon exchange and the degree calculation in 620 require the two beacon values to be equal to T_b, but do not require w=T_b. Thus the previous completed sums remain valid with distinct parameters. All public factors outside the spare place are fixed. Completing W leaves its factor L_0(w)^2, and its other dependence is already included in eta(w). No hidden fixed-coordinate theta factor at k is omitted.

## 3. Real source scaling of the two projected polynomials

For w outside K set
\[
s=L_0(w)\ne0,\qquad z=\frac{L_{a_k}(w)}{L_0(w)}
 =\frac{w}{w+a_k}.
\]
This fractional-linear map is a bijection of F minus K. Each of the four moments in (5) scales by s for V_i and by L_{a_k}(w)=sz for O.

Let q_0,q_2,q_kappa,q_T be exactly the coefficients from 614.19 computed from the stripped actual sections tilde V_i,tilde O. Direct homogeneity gives
\[
\begin{aligned}
c_0(w)&=s^{d_*}q_0,\\
c_2(w)&=s^{d_*}z^2q_2,\\
c_\kappa(w)&=s^{d_*}z^\kappa q_\kappa,\\
c_T(w)&=s^{d_*}z^{\kappa+2}q_T
       =L_0(w)^B L_{a_k}(w)^{\kappa+2}q_T.
\end{aligned}                                                       \tag{6}
\]
It follows that the values at z_X=1 in the **already completed separator X** obey
\[
P_0(1;w)=s^{d_*}Q_0(z),\qquad
P_5(1;w)=s^{d_*}Q_5(z),                                             \tag{7}
\]
\[
Q_0=q_0+q_2z^2+q_\kappa z^\kappa+q_Tz^{\kappa+2},\qquad
Q_5=q_0+q_2z^2+q_Tz^{\kappa+2}.
\]
The new variable z here belongs to w; it is not the old separator variable z_X. The q_j are fixed real-source moments once the other coordinates are fixed.

Suppose the old selected off-grid w_0=T_b has c_T(w_0)!=0 on an edge. Equation (6) implies q_T!=0 because both displayed Lagrange factors are nonzero. This inheritance requires no actual moment evaluation. In particular, the set of edges with nonzero highest coefficient supplied conditionally by the previous root averages remains eligible after stripping the spare factor.

## 4. Nonzero scalar polynomial and exact D eta condition

Fix one eligible edge and put
\[
\alpha=A_x+c,\qquad
b_0=\alpha D_x^{2u^5}+cd\,C_x^{2u^5}.
\]
Only eta varies, so
\[
\beta(w)=b_0\eta(w)^{2u^5}
        =b_0 w^{4-\kappa}\quad(w\ne0).                              \tag{8}
\]
The last equality is a **field-function** identity: the original positive exponent is 4u^5(u-1)=4u^6-kappa, and exponents reduce modulo u^6-1 at nonzero points. It is not an unreduced ordinary-polynomial identity.

Since w=a_k z/(1+z) and a_k^(kappa-4)=1, the projected scalar divided by nonzero s^d is
\[
\alpha Q_0(z)+b_0\left(\frac z{1+z}\right)^{4-\kappa}Q_5(z).
\]
The clearing factor z^kappa(1+z)^4 is nonzero outside K. Therefore the scalar is zero exactly at roots of the ordinary polynomial
\[
\mathcal R_x(z)=\alpha z^\kappa(1+z^4)Q_0(z)
             +b_0 z^4(1+z^\kappa)Q_5(z),\qquad
\deg\mathcal R_x\le2\kappa+6=8u^5+6.                                \tag{9}
\]
If q_T!=0 and (alpha,b_0)!=(0,0), this polynomial is nonzero:

- If alpha!=b_0, its highest coefficient is (alpha+b_0)q_T!=0.
- If alpha=b_0!=0, divide by alpha and use Q_0=Q_5+q_kappa z^kappa:
  \[
  \mathcal R_x/\alpha=(z^\kappa+z^4)Q_5
                     +q_\kappa z^{2\kappa}(1+z^4).
  \]
  When q_kappa!=0 the highest remaining term has degree 2kappa+4; otherwise q_T gives a nonzero term of degree 2kappa+2.

This includes the alpha=0,b_0!=0 case without assigning the actual coefficients. When alpha=0, A_x=c and
\[
b_0=cd\,C_x^{2u^5}\ne0
\]
provided c,d,C_x are nonzero. The beacon choice used in 621.7 supplies C_x!=0 on this fiber: there C_x=c[U_b^m+(U_b+d)^m], m=3u/2-2, a nonzero polynomial with value cd^m at U_b=0. Crucially T_b is chosen and fixed before w varies. On alpha!=0 no nonzero C_x or b_0 assumption is needed.

The remaining complete-X prefactor can vanish only when
\[
D_x\eta(w)=1.                                                       \tag{10}
\]
Its exact off-grid classification is particularly simple. Let mu_M={h in F^times:h^M=1}. The map w -> w^(2(u-1)) is onto mu_M with kernel K^times of size u-1. Thus the number of bad w outside K is
\[
\begin{cases}
u-1,&D_x\in\mu_M\setminus\{1\},\\
0,&D_x=0,\ D_x=1,\ \text{or }D_x^M\ne1.
\end{cases}                                                        \tag{11}
\]
For D_x=1 all nonzero solutions are grid points and already excluded. No actual value of D_x is needed for the uniform bound u-1.

## 5. Conditional actual-source sufficient theorem

Assume the original reached source/route/checker interfaces, a fixed common permitted third remainder, nonzero fixed public factors, and a set E of reached falling edges with the old c_T(w_0)!=0. Fix the two first-beacon values T_b and all other first coordinates as above. Require C_x!=0 on the A_x=c fiber. These are the preceding actual-source hypotheses; their full upstream construction is not newly certified here.

For each edge, the complete X,Y,Z_1,Z_2,W padding-subtable value has the form
\[
\mathcal F_x(w)=\overline G_x
L_0(w)^{d_*+2}
(1+(D_x\eta(w))^2)^{U_4}
[\alpha Q_0(z)+b_0 w^{4-\kappa}Q_5(z)],                              \tag{12}
\]
where Gbar_x!=0 is independent of w. Outside K the Lagrange factor is nonzero. Equations (9)--(11) show that at most
\[
r_u=8u^5+6+(u-1)
\]
choices of w outside K make this value zero. No independent source scalar or per-edge advice has been inserted.

Counting pairs (w,x), one common w has at least
\[
\left(1-\frac{r_u}{u^6-u}\right)|E|
\]
nonzero edge values whenever the displayed lower bound is positive. Along sufficiently large legal lengths the lost fraction is O(1/u). If the inherited E has Omega(n_0/(q log_2 q)) edges, the same order survives at one common first-spare w. The selected field value costs 6mu charged bits and ordinary field-coordinate arithmetic, rather than an edge list. This is existential coordinate selection; no address-scale method to evaluate or locate the actual moments has been proved.

The result is stronger than the pulse3 fixed-diagonal unknown, while consistent with its cancellation example. That example only fixed one collection of sections at one point. Here the permitted w variation forces the actual Lagrange source family (5); the coefficients do not remain fixed as w varies. We do not claim the synthetic singleton is reachable.

## 6. Review, validation and stopping boundary

Fresh-context same-model reviewer [same-model review role] independently derived (1)--(3), checked the separation of the two first parameters, actual support at k, coefficient inheritance, scalar clearing and absence of additional w public factors in the specified subtable. Same-model review is not independent-model or human validation. Original route/density and published-paper mappings remain explicit interfaces.

rw_spare_projection_check.c recomputes canonical moments from scaled synthetic grid sections at64 off-grid first-spare values in GF(2^18), u=8. It checks (6)--(9) in both A=c and A!=c backgrounds with fixed beacon first value. It separately enumerates the D eta bad set for D=0,1, a nontrivial norm-one value and a value outside mu_M, obtaining 0,0,7,0 as predicted. The corrected run passed in about0.38 seconds with no compiler warnings. This supports algebraic implementation only, not actual RW data, reachability or the asymptotic root average.

The first compile attempt failed because nesting the previous kernel-check include caused macro redefinition and two main functions. Its raw output is preserved in rw-pulse4-scaling-check-output.txt. The fix directly includes the arithmetic file and reconstructs the canonical moments locally; no sealed file was edited. The successful output is rw-pulse4-scaling-check-passed-output.txt.

At the original unchanged diagonal, J,N,D_x remain unknown. The sufficient theorem avoids needing their values by selecting one independent first-spare coordinate inside the same real source polynomial. It **does not** prove survival after the complete first-spare sum: nonzero density at fixed w can still cancel when w is summed. Other first and third coordinates, real incidence defects, norm orbits, absolute trace, auxiliary PCP pieces and the physical JK response remain outside this round. No source evaluator, general circuit lower bound or main-conjecture solution follows.

Stop this pulse at the conditional actual complete-X subtable nonvanishing theorem. The next mathematical obligation, if authorized, is the complete first-spare sum with exactly its public weight and the scaling (5); a repeated root average cannot substitute for that total.
