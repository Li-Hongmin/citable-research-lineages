> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Fresh-context same-model review record

Reviewer: [same-model review role]. Scope: complete first separator X sum, exact original public weight, raw polynomial extension, canonical toy and its reachability boundary. Review is same-model, not independent-model/human validation. No original-project writes or new actual RW computation.

The initial report recovered Gamma_x(X)=G_x L_0(X)^2 and the correct full/off-grid projection formulas. Its separately written C check enumerated seven raw basis sums. However, its analytic proof contained this erroneous definition:

> T=s+rv=1+(1+r)X^{u-1}.

Root flagged that the required factor is a product, because s^B is also present. Reviewer explicitly acknowledged the error and replaced it with:

> H=s(1+rv)=1+(1+r)v+rv^2, deg H<=2u-2, [X^(u-1)]H=1+r.

The reviewer rechecked the larger degree bound, low residues and lower four no-carry positions. Its corrected proof still gives
\[
\sum_X L^2H^BR^\kappa
=(1+r)^B(\lambda^2 a_R^\kappa+\nu^2b_R^\kappa).
\]
The finite code had used the correct raw expression throughout, so the error affected the initial exposition, not its numerical computation.

The reviewer separately confirmed toy moments (1,0,1,1) and (1,omega,0,1), coefficients (1,omega,0,omega^2), and P_0(1)=P_5(1)=0. It stressed that the toy exclusion requires equality of the entire same canonical section, a nonzero actual ledger multiplier and at least two ones in the hard suffix; comparing local moments or a single edge is insufficient.

Final check of rw-pulse3-complete-x-projection.md:

> 未发现新的实质错误，指定四处均通过：
>
> - 修正后的 H=s(1+rv)、次数界及 general moment 的无进位证明正确。
> - 七个 (L,R) 配对与边界系数正确。
> - raw polynomial 在 grid 上的取值及 off-grid 修正正确，未混用 rational z。
> - toy 系数与 nonreachability 排除成立；稿件已明确完整 canonical section、非零 ledger multiplier、hard suffix 至少两个一等必要前提。
>
> 无需进一步修改或重跑。原材料与封存 packet 未改。

The later explicit nonzero public-factor condition in the density illustration only makes an already necessary hypothesis visible. No actual projected coefficient, reachable cancellation, all-orbit response, efficient evaluator or main conjecture was certified by this review.
