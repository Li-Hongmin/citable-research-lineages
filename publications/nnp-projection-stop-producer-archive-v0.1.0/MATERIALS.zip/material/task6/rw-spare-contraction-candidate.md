> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Complete zero-source spare contraction: exact actual-source test and a sharp local boundary

2026-10-03. Private working candidate, not a promoted project theorem or a public release.

## Scope and precise assumptions

This calculation continues the local padding-subtable in Note 621, not the full physical JK response. The original project remains read-only. Inputs are the original unit's Notes 608, 609, 614, 616, 617, 619, 620 and 621, under `[unbundled historical source scope]`.

Let (u=2^\mu\ge8), (K=\mathbb F_u\subset F=\mathbb F_Q), (Q=u^6), (M=1+u+\cdots+u^5), and (E_S=\sum_{j\in S}u^j) for (S\subseteq\{1,\dots,5\}). Define

\[
L_b(Z)=1+(Z+b)^{u-1},\qquad
\Theta_T(Z)=\sum_{b\in K}L_b(T)^2L_b(Z),\qquad
\mathcal W_T(Z)=L_0(T)^2L_0(Z)\Theta_T(Z)^{2(M-1)}.
\]

The algebra below assumes a genuinely free spare routed coordinate (W\in F); every non-OUTPUT source grid entry on the selected last-digit layer has spare grid digit zero, and OUTPUT has a different last label. Both endpoint defect digits at the spare place are zero. Fix every first coordinate, every remaining routed coordinate and all already contracted quantities before summing (W). In particular (A,c,t,D,C,H) below do **not** vary with (W).

Under the actual-source formula (621.9), the spare source dependence is precisely (v=L_0(W)). Let

\[
H(Z)=\sum_S a_SZ^{E_S},\qquad
H_{[5]}(Z)=\sum_{R\subseteq\{1,\dots,4\}}a_{R\cup\{5\}}Z^{E_R}.
\]

Here (H=H_x) is the **actual** kernel at the fixed first tuple; no coefficient is separately chosen or supplied as advice. With the first spare value (y), (U=y^2), (d=b^2\in K^\times), and the genuine reference background (A=A_x), set

\[
D=A U^{2(u-1)}+c(U+d)^{2(u-1)},\quad
C=A U^{3u/2-2}+c(U+d)^{3u/2-2},\quad
\eta=y^{2(u-1)}.
\]

Note 621's complete (Y,Z_1,Z_2) sum, apart from its fixed outside factor \(\Gamma\) and the spare weight, is

\[
F_x(v)=v(A+c)H((tDv)^2)
 +cd(tC)^{2u^5}v^{1+2u^5}H_{[5]}((tDv)^2). \tag{1}
\]

For applications to the actual checker, source separation, free-route geometry, valid common checker modification and preceding contractions are upstream assumptions. This bounded pulse does not certify all their dependencies back to the published construction.

## A self-contained one-coordinate contraction

For every (T\in F) and every subset (S),

\[
\sum_{Z\in F}\mathcal W_T(Z)L_0(Z)^{1+2E_S}
 =L_0(T)^2T^{4(u-1)E_S}. \tag{2}
\]

At (E_S=0,T=0), the power on the right is interpreted as 1.

**Proof.** The partition of unity for the grid Lagrange basis makes \(\Theta_T\) monic of degree \(u-1\). Also \(\Theta_T(0)=L_0(T)^2\). Divide out the constant \(L_0(T)^2\) only as notation for the remaining sum, without assuming it is nonzero. Its integrand is

\[
L_0(Z)^2\left(\prod_{j=1}^5
  (\Theta_T(Z)L_0(Z)^{\mathbf1_{j\in S}})^{u^j}\right)^2.
\]

Its degree is at most \(4(Q-1)-2(u-1)<4(Q-1)\), and all powers are even. Full-field power summation therefore retains only the coefficient of \(Z^{2(Q-1)}\); exponent zero sums to (Q=0), and the other positive multiples in range, (Q-1) and (3(Q-1)), are odd. The squared high product has exponents divisible by (2u). Thus (L_0(Z)^2=1+Z^{2(u-1)}) must contribute its top term. In the unsquared high product the target is (Q-u=\sum_{j=1}^5(u-1)u^j).

Each local factor has degree at most (2u-2). At its first base-(u) digit the required exponent is (u-1); the other congruent candidate (2u-1) is unavailable. Inducting over the five positions leaves no carries. An unselected factor contributes 1. A selected factor contributes

\[
[Z^{u-1}]\Theta_T(Z)L_0(Z)
 =1+\Theta_T(0)=T^{2(u-1)}.
\]

The target coefficient before squaring is (T^{2(u-1)E_S}); squaring proves (2). This is the same basis identity as (616.9), proved here without inferring it from pointwise density. \(\square\)

Consequently the linear functional \(G\mapsto\sum_Z\mathcal W_T(Z)G(L_0(Z))\) acts diagonally on the 32 polynomials (v^{1+2E_S}). If (G(v)=v\sum_S b_S(v^2)^{E_S}), its exact value is

\[
L_0(T)^2\sum_S b_S T^{4(u-1)E_S}. \tag{3}
\]

## The complete spare sum

The polynomial (1) still has exactly the allowed 32-exponent support: its second term moves each lower subset (R) to (R\cup\{5\}), without producing a carry or a new exponent. Applying (2) term by term gives

\[
\boxed{\quad
\sum_{W\in F}\Gamma\mathcal W_y(W)F_x(L_0(W))
=\Gamma L_0(y)^2\left[
(A+c)H((tD\eta)^2)
 +cd(tC\eta)^{2u^5}H_{[5]}((tD\eta)^2)
\right].\quad} \tag{4}
\]

This formula includes the complete spare sum after the complete (Y,Z_1,Z_2) sums, sparse (J)-pair contraction and first last-digit sum, at the still-fixed other coordinates. The fixed factors in \(\Gamma\) must exclude the spare public weight. Equation (4) is an identity even when its factors vanish. For the off-grid values with nonzero public factors in Note 621, survival is **equivalent** to the bracket being nonzero.

If (A=c), (c,d,t,C,\eta,\Gamma,L_0(y)\ne0), the exact outstanding condition is

\[
H_{[5]}(\sigma)\ne0,\qquad \sigma=(tD\eta)^2. \tag{5}
\]

If additionally (D=0), (5) is (H_{[5]}(0)\ne0), which is one case covered by the coefficient supplied in Note 621. If (D\ne0), that coefficient alone does not decide (5). At (A\ne c), the two actual-source evaluations in (4) can cancel each other. These values are not made available at address scale by writing this formula.

Additional zero-source spare digits whose source and public factors obey these assumptions give further diagonal maps, replacing (t) by (t\prod_iT_i^{2(u-1)}) and multiplying by \(\prod_i L_0(T_i)^2\), for each fixed first tuple. No claim is made that arbitrarily many such digits exist in the actual route, or that their first-coordinate sums have been evaluated.

## A sharp abstract cancellation boundary, even with local kernel shape

First, a simple abstract sparse example: suppose (A=c) and all the nonzero factors in (5), including (D), are present. Put

\[
\alpha=\sigma^{-u},\qquad
H(Z)=1+Z^{u^5}(1+\alpha Z^u),\qquad
H_{[5]}(Z)=1+\alpha Z^u.
\]

Then (H(0)=H_{[5]}(0)=1), but (H_{[5]}(\sigma)=0). Equation (4) is zero. Before the spare sum, (1) is a nonzero polynomial with many nonzero values: its constant lower-section coefficient is 1. Thus even knowing both coefficient nonvanishing conditions in (621.6) cannot alone promote the pointwise theorem through (W).

One need not allow arbitrary sparse coefficients for this warning. A stricter abstract example has the exact **local** kernel shape (609.7)/(620.15). Given nonzero \(\sigma\), let \(\lambda^4=\sigma\), which uniquely determines \(\lambda\in F^\times\). Choose local first-source sections \(a=1,b=1+\lambda\), distinct from the background symbols (A,c). Put

\[
G_5(a,b)=(a+b)a^{2u^5}+b^{1+2u^5}.
\]

The local highest section is

\[
\mathscr H_{a,b,[5]}(Z)
 =G_5(a,b)^2\prod_{j=1}^4
  ((a+b)^{4u^j}+Z^{u^j}a^{4u^j})
 =G_5(1,1+\lambda)^2(\lambda^4+Z)^{u+u^2+u^3+u^4}.
\]

It vanishes at (Z=\sigma\). If \(G_5(1,1+\lambda)\ne0\), both its value at zero and the empty local branch \((a+b)^{4M-2}\) are nonzero. The full local \(\mathscr H_{a,b}(\sigma)\) also vanishes: in (609.7), take \(R^2=\sigma\); the common factor \((a+b)^2+Ra^2\) is zero, and both terms contain a positive power of that factor.

These are **abstract field sections**, not a counterexample on the actual reached RW orbit. The actual kernel (614.25) is a weighted complete first-last-digit sum of paired local kernels; no realization of the displayed sections in that source or density family is proved. The conclusion is only that sparse support, both nonzero constant sections, and even local (609.7) shape do not by themselves force (4) to survive. It does not close the actual-source route.

## Reproducible finite check

The standalone files `rw_field_modulus_check.py` and `rw_spare_check.c` read no project files. Run in this task directory:

```sh
python3 rw_field_modulus_check.py
cc -O2 -Wall -Wextra -o build/rw_spare_check rw_spare_check.c
build/rw_spare_check
```

The modulus is (x^{18}+x^7+1), checked irreducible by Rabin's test: the gcd tests at indices (18/2=9), (18/3=6) are 1 and (x^{2^{18}}=x) modulo the polynomial. Integers encode polynomial-basis field elements. At (u=8,Q=262144,M=37449), complete enumeration of **one coordinate only** verifies (2) for all 32 basis branches. The symbolic proof establishes all stated parameters; this finite check is supporting evidence at the smallest admitted field, not a substitute for it.

With (y=2,c=d=t=A=1), it computes (D=78677,C=65553,\eta=16384,\sigma=153607,\alpha=84178). The simple abstract example has 262134 nonzero weighted values, 262133 of them off-grid, and full sum zero. The stricter local example has (a=1,b=174979,G_5=117291,\mathscr H(0)=128322,\mathscr H_{[5]}(0)=169943), 262134 nonzero weighted values and full sum zero. The exhaustive C run completed in under one second locally; no SAT, HPC or actual RW recomputation was run.

## Verification and remaining boundary

The proof and scope have been checked in a fresh-context agent using the same model family. This reduces shared conversational anchoring, but is **not** independent-model verification or full-source formal verification. The field computation is independently implemented evidence for the basis identity and the explicit abstract examples. The original Note 621's full dependency chain and the actual-source value in (4) remain unverified by an external reviewer.

No new formal theorem has been inserted into the original project. No claim of novelty has been established. The most useful next obligation is to determine the bracket in (4) for the **same actual reached checker and first tuple** by source structure, or show a reachable cancellation there. Choosing arbitrary coefficients, or varying (y\) while treating the actual (H_x,A_x) as fixed, would not answer that question. Other first/third sums, added real defects, absolute trace, seven other norm orbits and the physical JK response remain open. There is no address-scale exact surface and no proof of (NP\nsubseteq P/\mathrm{poly}\) or (P\ne NP).
