// SPDX-License-Identifier: Apache-2.0
// Archival checker source; not executed in this packaging audit.
// Historical asserts may be disabled under optimization; no fresh mathematical certification.
/* First-spare source-scaling check only. Synthetic canonical data;
   no actual RW word, source table or reachability certification.
   Reuses existing field arithmetic. Canonical moments are reconstructed below. */
#define main previous_kernel_main
#include "rw_spare_check.c"
#undef main

static fe rng_state=0x13751;
static fe next_fe(void){rng_state^=rng_state<<13;rng_state^=rng_state>>17;rng_state^=rng_state<<5;return rng_state&(Q-1);}
static void moments_from_grid(const fe *K,const fe *values,fe *a,fe *g,fe *h,fe *tm){
  fe coeff[U]={0};*a=*g=*tm=0;*h=values[0]^values[1];
  for(unsigned j=0;j<U;j++){
    *a^=values[j];*g^=mul(K[j],values[j]);
    for(unsigned k=1;k<U;k++)coeff[k]^=mul(values[j],powf_(K[j],U-1-k));
  }
  for(unsigned k=U/2+1;k<U;k++)*tm^=coeff[k]; /* p=0,q=1 */
}

static void paired_coefficients(const fe *K,fe grid[2][U],fe Ogrid[U],fe out[4]){
  fe a[2],g[2],h[2],tm[2],aO,gO,hO,tO;
  unsigned kap=4*(1u<<15),B=4*(8+64+512+4096);
  for(unsigned i=0;i<2;i++)moments_from_grid(K,grid[i],a+i,g+i,h+i,tm+i);
  moments_from_grid(K,Ogrid,&aO,&gO,&hO,&tO);require(!hO,"OUTPUT endpoint zeros");
  for(unsigned j=0;j<4;j++)out[j]=0;
  for(unsigned i=0;i<2;i++){
    fe hb=powf_(h[i],B),hk=powf_(h[i],kap),tk=powf_(tm[i],kap);
    out[0]^=mul(hb,mul(powf_(a[i],2),hk)^mul(powf_(g[i],2),tk));
    out[1]^=mul(hb,mul(powf_(aO,2),hk)^mul(powf_(gO,2),tk));
    out[2]^=mul(powf_(tO,kap),mul(powf_(g[i],2),hb));
    out[3]^=mul(powf_(gO,2),mul(powf_(tO,kap),hb));
  }
}
int main(void){
  fe K[U];unsigned nk=0;for(fe x=0;x<Q;x++)if(powf_(x,U)==x)K[nk++]=x;
  require(nk==U&&K[0]==0&&K[1]==1,"K grid");
  const unsigned kap=4*(1u<<15),B=4*(8+64+512+4096),ds=B+kap+2;
  fe grid[2][U],Ogrid[U]={0},q[4];Ogrid[2]=next_fe()|1;
  for(unsigned j=0;j<U;j++){grid[0][j]=next_fe();grid[1][j]=grid[0][j]^next_fe();}
  grid[1][0]=grid[0][0]^17351;grid[1][1]=grid[0][1];
  paired_coefficients(K,grid,Ogrid,q);require(q[3],"nonzero normalized qTop");
  fe T=2,cp=5,db=1,Ube=mul(T,T);
  fe Ccancel=mul(cp,powf_(Ube,3*U/2-2)^powf_(Ube^db,3*U/2-2));
  require(Ccancel,"A=c beacon C");
  unsigned tested=0;
  for(fe w=2;w<Q&&tested<64;w++){
    if(powf_(w,U)==w)continue;tested++;
    fe sw=L(0,w),ew=L(K[3],w),z=mul(w,powf_(w^K[3],Q-2));
    fe gs[2][U],os[U],co[4];
    for(unsigned i=0;i<2;i++)for(unsigned j=0;j<U;j++)gs[i][j]=mul(sw,grid[i][j]);
    for(unsigned j=0;j<U;j++)os[j]=mul(ew,Ogrid[j]);
    paired_coefficients(K,gs,os,co);
    fe z2=powf_(z,2),zk=powf_(z,kap),z4=powf_(z,4),scale=powf_(sw,ds);
    fe q5=q[0]^mul(q[1],z2)^mul(q[3],mul(zk,z2)),q0=q5^mul(q[2],zk);
    fe p0=co[0]^co[1]^co[2]^co[3],p5=co[0]^co[1]^co[3];
    require(p0==mul(scale,q0)&&p5==mul(scale,q5),"actual Lagrange source scaling");
    require(co[3]==mul(powf_(sw,B),mul(powf_(ew,kap+2),q[3])),"qTop inheritance");
    fe eta=powf_(w,2*(U-1)),den=mul(zk,1^z4);
    for(unsigned choice=0;choice<2;choice++){
      fe A=choice?7:cp,alpha=A^cp;
      fe D=mul(A,powf_(Ube,2*(U-1)))^mul(cp,powf_(Ube^db,2*(U-1)));
      fe C=mul(A,powf_(Ube,3*U/2-2))^mul(cp,powf_(Ube^db,3*U/2-2));
      fe b0=mul(alpha,powf_(D,kap/2))^mul(mul(cp,db),powf_(C,kap/2));
      require(alpha||b0,"scalar coefficients not both zero");
      fe beta=mul(b0,powf_(eta,kap/2));
      fe scalar=mul(alpha,p0)^mul(beta,p5);
      fe rr=mul(alpha,mul(den,q0))^mul(b0,mul(mul(z4,1^zk),q5));
      require(mul(den,scalar)==mul(scale,rr),"fixed-beacon scalar clearing");
    }
  }
  printf("PASS %u first-spare samples: canonical moment rescaling, qTop inheritance, fixed-beacon A=c and A!=c scalar clearing\n",tested);
  fe norm=powf_(2,U-1),nonnorm=2;
  while(powf_(nonnorm,(Q-1)/(U-1))==1)nonnorm++;
  fe Ds[4]={0,1,norm,nonnorm};
  for(unsigned j=0;j<4;j++){
    unsigned bad=0;
    for(fe w=0;w<Q;w++)if(powf_(w,U)!=w&&mul(Ds[j],powf_(w,2*(U-1)))==1)bad++;
    unsigned want=(Ds[j]&&Ds[j]!=1&&powf_(Ds[j],(Q-1)/(U-1))==1)?U-1:0;
    require(bad==want,"exact off-grid D eta condition");
    printf("PASS D=%u: off-grid D*eta=1 roots=%u, expected=%u\n",Ds[j],bad,want);
  }
  puts("Formal synthetic-family validation only; actual geometry/density remains an explicit interface.");
  return 0;
}
