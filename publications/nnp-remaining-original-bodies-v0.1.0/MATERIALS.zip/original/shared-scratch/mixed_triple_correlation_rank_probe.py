#!/usr/bin/env python3
"""Explore ranks of mixed flattenings of binary triple correlations."""

from __future__ import annotations

import argparse
import itertools
import random
from collections import Counter, defaultdict


PRIMITIVE = {2: 0b111, 3: 0b1011}


def mul(a: int, b: int, n: int) -> int:
    modulus = PRIMITIVE[n]
    out = 0
    while b:
        if b & 1:
            out ^= a
        b >>= 1
        a <<= 1
        if a & (1 << n):
            a ^= modulus
    return out


def rank_gf2(rows: list[int], q: int) -> int:
    rows = rows[:]
    rank = 0
    for col in range(q):
        pivot = next((r for r in range(rank, q) if (rows[r] >> col) & 1), None)
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for r in range(q):
            if r != rank and ((rows[r] >> col) & 1):
                rows[r] ^= rows[rank]
        rank += 1
    return rank


def dense_gl2(q: int, n: int):
    for a, b, c, d in itertools.product(range(1, q), repeat=4):
        if mul(a, d, n) ^ mul(b, c, n):
            yield a, b, c, d


def triple_table(f: int, g: int, h: int, q: int) -> list[int]:
    table = [0] * (q * q)
    for u in range(q):
        for v in range(q):
            bit = 0
            for t in range(q):
                bit ^= ((f >> t) & 1) & ((g >> (t ^ u)) & 1) & ((h >> (t ^ v)) & 1)
            table[u * q + v] = bit
    return table


def mixed_rank(table: list[int], matrix: tuple[int, int, int, int], q: int, n: int) -> int:
    a, b, c, d = matrix
    rows = []
    for u in range(q):
        row = 0
        for v in range(q):
            x = mul(a, u, n) ^ mul(b, v, n)
            y = mul(c, u, n) ^ mul(d, v, n)
            row |= table[x * q + y] << v
        rows.append(row)
    return rank_gf2(rows, q)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, choices=(2, 3), required=True)
    parser.add_argument("--samples", type=int, default=10000)
    parser.add_argument("--matrix-samples", type=int, default=0)
    parser.add_argument("--seed", type=int, default=856857)
    args = parser.parse_args()
    q = 1 << args.n
    matrices = list(dense_gl2(q, args.n))
    rng = random.Random(args.seed)
    if args.matrix_samples and args.matrix_samples < len(matrices):
        matrices = rng.sample(matrices, args.matrix_samples)
    triples = (
        itertools.product(range(1 << q), repeat=3)
        if args.n == 2
        else ((rng.randrange(1 << q), rng.randrange(1 << q), rng.randrange(1 << q)) for _ in range(args.samples))
    )
    histograms: dict[tuple[int, int, int, int], Counter[int]] = defaultdict(Counter)
    count = 0
    for f, g, h in triples:
        table = triple_table(f, g, h, q)
        for matrix in matrices:
            histograms[matrix][mixed_rank(table, matrix, q, args.n)] += 1
        count += 1
    classes = Counter(tuple(sorted(hist.items())) for hist in histograms.values())
    print({"n": args.n, "q": q, "triples": count, "dense_gl2": len(matrices), "histogram_classes": len(classes)})
    for histogram, multiplicity in classes.most_common():
        print({"matrix_count": multiplicity, "rank_histogram": dict(histogram)})


if __name__ == "__main__":
    main()
