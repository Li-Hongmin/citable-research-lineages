"""Exact small-instance search for affine-biclique AEKR.

The probability is over z=(r,t) uniformly, followed by independent 1/2
row/column thinning of the affine leaf R_z.  Candidate witnesses T have
2 <= |T| <= maxk, T is feasible in some leaf, and T union {s} is a
collision.  The MILP chooses a pairwise-intersecting family and maximizes
the exact union probability.  The OR variables are continuous: for a fixed
choice of T's, their optimum is exactly the Boolean union.
"""
from itertools import combinations
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix


def parity(x):
    return x.bit_count() & 1


def leaf(C, n, z):
    r, t = z >> 1, z & 1
    return sum(1 << i for i, (x, y) in enumerate(C)
               if parity(r & x) == t and parity(r & y) == (1 - t))


def thinned_samples(C, n, L):
    rows = sorted({C[i][0] for i in range(len(C)) if L >> i & 1})
    cols = sorted({C[i][1] for i in range(len(C)) if L >> i & 1})
    weight = 1 / ((1 << (n + 1)) * (1 << len(rows)) * (1 << len(cols)))
    out = []
    for mr in range(1 << len(rows)):
        U = {rows[j] for j in range(len(rows)) if mr >> j & 1}
        for mc in range(1 << len(cols)):
            V = {cols[j] for j in range(len(cols)) if mc >> j & 1}
            R = sum(1 << i for i, (x, y) in enumerate(C)
                    if L >> i & 1 and x in U and y in V)
            out.append((R, weight))
    return out


def exact_aekr(X, Y, n, s, maxk=3, time_limit=120):
    C = [(x, y) for x in X for y in Y]
    si = C.index(s)
    leaves = [leaf(C, n, z) for z in range(1 << (n + 1))]
    candidates = []
    for k in range(2, maxk + 1):
        for tup in combinations([i for i in range(len(C)) if i != si], k):
            T = sum(1 << i for i in tup)
            if not any(T & ~L == 0 for L in leaves):
                continue
            if any((T | (1 << si)) & ~L == 0 for L in leaves):
                continue
            candidates.append(T)

    aggregate = {}
    for L in leaves:
        for R, w in thinned_samples(C, n, L):
            aggregate[R] = aggregate.get(R, 0.0) + w
    samples = [(R, w) for R, w in aggregate.items() if R]
    events = [[i for i, T in enumerate(candidates) if T & ~R == 0]
              for R, _ in samples]
    active = [j for j, E in enumerate(events) if E]
    q, m = len(active), len(candidates)
    if not m or not q:
        return 0.0, []

    rows, lo, hi = [], [], []
    for i in range(m):
        for j in range(i):
            if candidates[i] & candidates[j] == 0:
                rows.append({i: 1, j: 1}); lo.append(-np.inf); hi.append(1)
    for jj, j in enumerate(active):
        row = {m + jj: 1}
        for i in events[j]:
            row[i] = -1
        rows.append(row); lo.append(-np.inf); hi.append(0)

    A = lil_matrix((len(rows), m + q), dtype=float)
    for ri, row in enumerate(rows):
        for ci, value in row.items():
            A[ri, ci] = value
    objective = np.zeros(m + q)
    for jj, j in enumerate(active):
        objective[m + jj] = -samples[j][1]
    # Only witness variables need integrality; OR variables are exact at opt.
    integrality = np.r_[np.ones(m), np.zeros(q)]
    result = milp(objective, integrality=integrality,
                  bounds=Bounds(np.zeros(m + q), np.ones(m + q)),
                  constraints=LinearConstraint(A.tocsr(), np.array(lo),
                                               np.array(hi)),
                  options={"time_limit": time_limit, "mip_rel_gap": 0})
    chosen = [candidates[i] for i in range(m) if result.x[i] > .5]
    return -result.fun, [[C[i] for i in range(len(C)) if T >> i & 1]
                         for T in chosen]


if __name__ == "__main__":
    X = [0, 1, 2, 4]
    Y = [3, 5, 6, 7]
    print(exact_aekr(X, Y, 3, (0, 3), maxk=3))
