# Task

Read-only research. Determine whether, in the exact CHMY gate-count model, every
`h in Stab(L_{n,S})` has every `r`-variable coordinate restriction in
`Stab(L_{r,S})`. First settle the free-constant convention from the source. If exact
descent holds, prove `dim H_{n,S} <= 2^(n-r) dim H_{r,S}` and determine whether it
implies `o(S log S)` at fixed exponent. If constants are not free, give the sharp
additive-slack replacement. Stop once there is a proof, counterexample, or exact
failure point. Do not edit permanent files or Git.
