"""Independent finite checks; no finite table is an asymptotic proof."""
from itertools import product, combinations
from math import comb

def slice_check():
    cases = 0
    for n in range(1, 4):
        for mask in range(1 << (1 << n)):
            A = [x for x in range(1 << n) if mask >> x & 1]
            for live in range(1 << n):
                fixed = ((1 << n) - 1) ^ live
                # Direct enumeration of restrictions and all completions.
                assignments = [a for a in range(1 << n) if a & live == 0]
                hits, mass = 0, 0
                for a in assignments:
                    count = sum((x & fixed) == a for x in A)
                    hits += count > 0
                    mass += count
                projection = {x & fixed for x in A}
                assert hits == len(projection) <= len(A)
                assert mass == len(A)
                cases += 1
    print('pulse1 exhaustive (language, live-set) cases:', cases, 'PASS')
    for N in [16, 20, 32, 64]:
        s = N*N
        D = (s+1)*(N+s+2)*(3*(N+s+2)**2)**s
        B = (D-1).bit_length()
        print('N, m=N, integer ceiling log2 D, exponent:', N, N, B, B+N-2**N)

def conditioning_check():
    cases = 0
    for E in range(1, 16):
        for F in range(16):
            p, delta, joint = E.bit_count(), F.bit_count(), (E & F).bit_count()
            assert joint <= min(p, delta)
            if E == F:
                assert joint == p  # Failure can be certain after conditioning.
            cases += 1
    print('pulse2 exhaustive event pairs on 4 atoms:', cases, 'PASS')

def dnf_check():
    cases = 0
    for N in range(2, 5):
        n = 1 << N
        full = (1 << n)-1
        for q in range(N):
            for support in combinations(range(n), q):
                nodes = [sum(((a >> j) & 1) << a for a in range(n)) for j in range(N)]
                def gate(op, u, v=None):
                    nodes.append((full ^ nodes[u]) if op == 'not' else
                                 (nodes[u] & nodes[v]) if op == 'and' else (nodes[u] | nodes[v]))
                    return len(nodes)-1
                if not support:
                    neg = gate('not', 0)
                    out = gate('and', 0, neg)
                else:
                    negs = [gate('not', j) for j in range(N)]
                    terms = []
                    for a in support:
                        literals = [j if a >> j & 1 else negs[j] for j in range(N)]
                        term = literals[0]
                        for lit in literals[1:]:
                            term = gate('and', term, lit)
                        terms.append(term)
                    out = terms[0]
                    for term in terms[1:]:
                        out = gate('or', out, term)
                assert nodes[out] == sum(1 << a for a in support)
                assert len(nodes)-N <= N*N
                if q:
                    assert len(nodes)-N == N+q*N-1
                cases += 1
    print('pulse3 actual AND/OR/NOT DAGs, all supports weight <= N-1, N=2..4:', cases, 'PASS')

def gf2rank(vectors):
    basis = {}
    for v in vectors:
        while v:
            p = v.bit_length()-1
            if p in basis:
                v ^= basis[p]
            else:
                basis[p] = v
                break
    return len(basis)

def rank_check():
    tested, good = 0, 0
    for n, r, q in [(4, 3, 1), (4, 4, 2)]:
        ball = [x for x in range(1 << n) if x.bit_count() <= q]
        for cols in product(range(1 << r), repeat=n):
            tested += 1
            images = []
            for x in ball:
                h = 0
                for j in range(n):
                    if x >> j & 1:
                        h ^= cols[j]
                images.append(h)
            if len(set(images)) != len(ball):
                continue
            good += 1
            for m in range(n+1):
                for T in combinations(range(n), m):
                    rank = gf2rank([cols[j] for j in T])
                    if m <= 2*q:
                        assert rank == m
                    assert 2**rank >= sum(comb(m, j) for j in range(min(q, m)+1))
    print('pulse4 abstract ball-injective matrices tested:', tested, 'good:', good, 'PASS')

def oracle_check():
    n, instances, gate_checks = 3, 0, 0
    # All eight unit triangular 3x3 maps; none is claimed to be a CJW code.
    for a, b, c in product(range(2), repeat=3):
        cols = [1 | (a << 1) | (b << 2), 2 | (c << 2), 4]
        hashes = []
        for x in range(1 << n):
            h = 0
            for j in range(n):
                if x >> j & 1:
                    h ^= cols[j]
            hashes.append(h)
        assert len(set(hashes)) == 1 << n
        for mask in range(1 << (1 << n)):
            A = [x for x in range(1 << n) if mask >> x & 1]
            for live in range(1 << n):
                cube = [x for x in range(1 << n) if x & live == x]
                if not all(x in A for x in cube):
                    continue
                assert gf2rank([cols[j] for j in range(n) if live >> j & 1]) == live.bit_count()
                for block_length in range(1, n+1):
                    for x in cube:
                        for start in range(0, n, block_length):
                            blockmask = (1 << block_length)-1
                            H = any(hashes[y] == hashes[x] and
                                    (y >> start) & blockmask == (x >> start) & blockmask
                                    for y in A)
                            assert H
                            gate_checks += 1
                    instances += 1
    print('pulse5 exact existential H instances:', instances, 'gate evaluations:', gate_checks, 'PASS')

if __name__ == '__main__':
    import sys
    {'1': slice_check, '2': conditioning_check, '3': dnf_check, '4': rank_check, '5': oracle_check}[sys.argv[1] if len(sys.argv)>1 else '1']()
