# Task

Verify Jukna Remark 1.20 / Chow 2011 exactly. Determine whether
`phi(n,t+cn) >= K phi(n,t)` can be iterated uniformly from `B` to `S` when
`S <= 2^(n-2)/n`, yielding
`log phi(n,S)-log phi(n,B) >= Omega((S-B)/n)`.
Check integer rounding, basis/constants, and the quantifier over threshold functions.
Then derive the strongest correct fiber inequality for an affine quotient whose kernel
has `w(K)<=B`. Return proof or exact failure point. No permanent edits or Git.
