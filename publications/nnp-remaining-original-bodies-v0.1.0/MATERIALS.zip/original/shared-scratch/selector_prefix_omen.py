#!/usr/bin/env python3
"""Omen finite probes for the two current route gates.

This is deliberately a finite-model computation.  It checks (i) the hidden
source family behind the finite-prefix information bound and (ii) the
cell-permutation obstruction for owner-free symmetric rails.  Neither model
instantiates the actual C456 machine.
"""

from __future__ import annotations

import json
from itertools import combinations, permutations, product
from math import ceil, log2


def prefix_probe(max_t: int = 20, k: int = 4):
    """Enumerate H_{T,k}: fixed k-prefix and final zero, hidden middle bits."""
    rows = []
    for t in range(k + 1, max_t + 1):
        histories = [
            bits
            for bits in product((0, 1), repeat=t - k - 1)
        ]
        family = []
        for middle in histories:
            d = (0,) * k + tuple(middle) + (0,)
            family.append(d)
        assert len(family) == 1 << (t - k - 1)

        # The visible data are the common packet/root fields plus the fixed
        # prefix.  The leaf query at i returns the suppressed source bit d_i.
        visible = tuple(["packet4", 0, 0, 3, 5, 5, 9] + [0] * k)
        assert all(
            (visible, d[:k]) == (visible, family[0][:k]) for d in family
        )

        # Distinct histories are separated by a source-leaf query in the
        # hidden coordinates.  Checking uniqueness of the hidden projections
        # is the linear-time form of the same pairwise statement.
        hidden_projections = {d[k : t - 1] for d in family}
        assert len(hidden_projections) == len(family)
        required_bits = ceil(log2(len(family)))
        rows.append(
            {
                "T": t,
                "k": k,
                "family_size": len(family),
                "visible_values": 1,
                "hidden_leaf_queries": t - k - 1,
                "min_extra_bits": required_bits,
                "prefix_packet_same": True,
                "all_pairs_leaf_separated": True,
            }
        )
    assert all(r["min_extra_bits"] == r["hidden_leaf_queries"] for r in rows)
    return rows


def transform_state(state, permutation):
    """Apply a cell permutation to (J, sigma, w)."""
    out = [[0] * len(permutation) for _ in range(3)]
    for field in range(3):
        for c, value in enumerate(state[field]):
            out[field][permutation[c]] = value
    return tuple(tuple(row) for row in out)


def mux_value(state, cell):
    marker, resident, written = state
    return written[cell] if marker[cell] else resident[cell]


def assignment_family(width):
    for owner in range(width):
        for resident in product((0, 1), repeat=width):
            for written in product((0, 1), repeat=width):
                marker = tuple(int(c == owner) for c in range(width))
                yield (marker, resident, written)


def orbit_signature(state, width):
    """Canonical orbit under all cell permutations (all invariant rails)."""
    encodings = []
    for perm in permutations(range(width)):
        encodings.append(tuple(bit for row in transform_state(state, perm) for bit in row))
    return min(encodings)


def invariant_monomial_features(width, max_degree):
    """Orbit-sums of Boolean monomials, a finite symmetric-rail basis."""
    variables = [(field, cell) for field in range(3) for cell in range(width)]
    all_perms = list(permutations(range(width)))
    orbits = {}
    for degree in range(max_degree + 1):
        for subset in combinations(variables, degree):
            subset = tuple(sorted(subset))
            orbit = []
            for perm in all_perms:
                moved = tuple(sorted((field, perm[cell]) for field, cell in subset))
                orbit.append(moved)
            canonical = min(orbit)
            orbits.setdefault((degree, canonical), frozenset(orbit))
    return list(orbits.values())


def eval_monomial(state, monomial):
    marker, resident, written = state
    rows = (marker, resident, written)
    value = 1
    for field, cell in monomial:
        value &= rows[field][cell]
    return value


def eval_feature(state, orbit):
    value = 0
    for monomial in orbit:
        value ^= eval_monomial(state, monomial)
    return value


def symmetric_probe(width, max_degree=4):
    states = list(assignment_family(width))
    perms = list(permutations(range(width)))
    features = invariant_monomial_features(width, max_degree)
    differing_pairs = 0
    checked_pairs = 0
    witness = None
    for state in states:
        for perm in perms:
            transformed = transform_state(state, perm)
            checked_pairs += 1
            assert orbit_signature(state, width) == orbit_signature(transformed, width)
            invariant_values = [eval_feature(state, f) for f in features]
            assert invariant_values == [eval_feature(transformed, f) for f in features]
            if mux_value(state, 0) != mux_value(transformed, 0):
                differing_pairs += 1
                if witness is None:
                    witness = {
                        "state": state,
                        "permutation": perm,
                        "transformed": transformed,
                        "fixed_cell_output": [mux_value(state, 0), mux_value(transformed, 0)],
                    }
    assert differing_pairs > 0
    return {
        "W": width,
        "states": len(states),
        "permutations": len(perms),
        "checked_pairs": checked_pairs,
        "all_invariant_orbits_equal": True,
        "bounded_degree": max_degree,
        "invariant_monomial_features": len(features),
        "fixed_cell_orientation_conflicts": differing_pairs,
        "witness": witness,
    }


def main():
    prefix_rows = prefix_probe()
    symmetric_rows = [symmetric_probe(width) for width in (2, 3)]
    result = {
        "host": "omen",
        "prefix_hidden_source": {
            "rows": prefix_rows,
            "route_decision": "finite-prefix source-blind extension CLOSED",
            "scope": "witnessed kernel H_{T,k}; not actual C456",
        },
        "owner_free_symmetric_rails": {
            "rows": symmetric_rows,
            "route_decision": "owner-free permutation-invariant family CLOSED",
            "scope": "one-hot marker + resident/write mux; not actual C456",
        },
        "failures": 0,
        "actual_C456": "UNKNOWN_PAUSE",
    }
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
