import numpy as np
from scipy.optimize import linprog

def rank(vs,n):
 rows=[v for v in vs if v];r=0
 for b in range(n-1,-1,-1):
  p=next((i for i in range(r,len(rows)) if rows[i]>>b&1),None)
  if p is None:continue
  rows[r],rows[p]=rows[p],rows[r]
  for i in range(len(rows)):
   if i!=r and rows[i]>>b&1:rows[i]^=rows[r]
  r+=1
 return r

def mono(A,B,n):
 a=A[0];b=B[0];ds=[x^a for x in A]+[y^b for y in B]
 for r in range(1,1<<n):
  if any((r&d).bit_count()%2 for d in ds):continue
  if ((r&a).bit_count()^(r&b).bit_count())&1:return True
 return False

def collisions(X,Y,n):
 cells=[(x,y) for x in X for y in Y];hs=[]
 from itertools import combinations
 for ss in combinations(range(len(cells)),4):
  ok=False
  for mask in range(1,16):
   if mask.bit_count()%2==0:continue
   I=[k for k in range(4) if mask>>k&1]
   for mask2 in range(1,16):
    if mask2.bit_count()%2==0:continue
    J=[k for k in range(4) if mask2>>k&1]
    if set(I)&set(J):continue
    xx=yy=0
    for k in I:xx^=cells[ss[k]][0]
    for k in J:yy^=cells[ss[k]][1]
    if xx==yy:ok=True;break
   if ok:break
  if ok:hs.append(ss)
 return cells,hs

def optimize(X,Y,n):
 cells,hs=collisions(X,Y,n);m=len(cells);mono_rect=[]
 for maskx in range(1,1<<len(X)):
  A=[x for i,x in enumerate(sorted(X)) if maskx>>i&1]
  for masky in range(1,1<<len(Y)):
   B=[y for j,y in enumerate(sorted(Y)) if masky>>j&1]
   if mono(A,B,n):mono_rect.append([k for k,(x,y) in enumerate(cells) if x in A and y in B])
 A=np.zeros((len(mono_rect),m+len(hs)))
 for i,R in enumerate(mono_rect):
  A[i,R]=1;S=set(R)
  for j,h in enumerate(hs):
   s=len(S.intersection(h));A[i,m+j]=1 if s==1 else -1 if s==3 else 0
 res=linprog(np.r_[-np.ones(m),np.zeros(len(hs))],A_ub=A,b_ub=np.ones(len(mono_rect)),bounds=[(None,None)]*m+[(0,None)]*len(hs),method='highs')
 print('sizes',len(X),len(Y),'m',m,'H',len(hs),'mono',len(mono_rect),'stat',res.status,'obj',-res.fun if res.status==0 else None)
 if res.status==0:
  print('phi',[(cells[i],round(v,3)) for i,v in enumerate(res.x[:m]) if abs(v)>1e-5]);print('lam',[(hs[j],round(v,3)) for j,v in enumerate(res.x[m:]) if v>1e-5][:30])

for X,Y in [({0,1,5,6},{2,3,4,7}),({3,5,6,7},{0,1,2,4}),({0,2,5,7},{1,3,4,6})]:optimize(X,Y,3)
