#!/usr/bin/env python3
"""Minimal Omen check for the bank-equivariant owner-free rail family.

The experiment is deliberately route-local.  It does not instantiate C456.

Variables per cell c are (J_c, sigma_c, w_c).  The replacement output is

    z_c = sigma_c + J_c sigma_c + J_c w_c  (over GF(2)).

Allowed rails are the union of:

* arbitrary J-free square-free monomials (so address-local data rails are
  allowed); and
* orbit-sums of monomials containing a J variable under the full cell
  permutation group S_W (the only owner dependence is permutation-invariant).

This is a finite-degree basis for the owner-free/bank-equivariant family.  The
two assignments A and B have identical non-owner data and exchange the unique
owner marker between cells 0 and 1.  Therefore every allowed rail, and hence
every deterministic finite uniform composer of those rails, has the same value
on A and B, while z_0 differs.
"""

from __future__ import annotations

import json
import socket
from itertools import combinations, permutations


def monomial_value(mask: int, values: tuple[int, ...]) -> int:
    out = 1
    for i, bit in enumerate(values):
        if (mask >> i) & 1:
            out &= bit
    return out


def permute_mask(mask: int, perm: tuple[int, ...], width: int) -> int:
    """Apply a cell permutation to a (J,sigma,w)-block mask."""
    out = 0
    for c in range(width):
        for kind in range(3):
            src = 3 * c + kind
            if (mask >> src) & 1:
                out |= 1 << (3 * perm[c] + kind)
    return out


def orbit_sum(mask: int, width: int) -> int:
    """Return the GF(2) orbit sum as a tuple encoded by a bitset of monomials.

    The returned integer is not a variable mask; bit k records the monomial
    mask k in the XOR orbit sum.  Duplicate orbit elements cancel in GF(2).
    """
    out = 0
    for perm in permutations(range(width)):
        out ^= 1 << permute_mask(mask, perm, width)
    return out


def evaluate_polynomial(poly_mask: int, values: tuple[int, ...]) -> int:
    out = 0
    monomial_mask = 0
    while poly_mask:
        if poly_mask & 1:
            out ^= monomial_value(monomial_mask, values)
        poly_mask >>= 1
        monomial_mask += 1
    return out


def output_zero(values: tuple[int, ...], width: int, target: int = 0) -> int:
    J = values[0::3]
    sigma = values[1::3]
    write = values[2::3]
    return sigma[target] ^ (J[target] & sigma[target]) ^ (J[target] & write[target])


def one_hot(values: tuple[int, ...], width: int) -> bool:
    J = values[0::3]
    return sum(J) == 1


def allowed_rails(width: int, degree: int) -> list[tuple[str, int]]:
    """Enumerate a finite-degree basis for the stated rail family."""
    rails: list[tuple[str, int]] = []
    variable_count = 3 * width
    for k in range(degree + 1):
        for choice in combinations(range(variable_count), k):
            mask = sum(1 << i for i in choice)
            has_owner_variable = any((mask >> (3 * c)) & 1 for c in range(width))
            if not has_owner_variable:
                # Arbitrary address-local data rails are permitted when they do
                # not read the owner marker at all.
                rails.append(("J-free", 1 << mask))
                continue
            # Owner dependence is permitted only through a full S_W orbit sum.
            orbit = orbit_sum(mask, width)
            if orbit:
                rails.append(("S_W-orbit", orbit))
    return rails


def check(width: int, degree: int) -> dict[str, object]:
    # All non-owner data are equal on cells.  A and B differ only by a marker
    # transposition, so both satisfy the one-hot replacement relation after z
    # is filled by output_zero.
    A = tuple(v for c in range(width) for v in (1 if c == 0 else 0, 0, 1))
    B = tuple(v for c in range(width) for v in (1 if c == 1 else 0, 0, 1))
    assert one_hot(A, width) and one_hot(B, width)
    assert output_zero(A, width) == 1
    assert output_zero(B, width) == 0

    rails = allowed_rails(width, degree)
    discriminators = []
    for kind, poly in rails:
        va = evaluate_polynomial(poly, A)
        vb = evaluate_polynomial(poly, B)
        if va != vb:
            discriminators.append((kind, poly, va, vb))

    # Any Boolean function (in particular any bounded-ports, bounded-degree,
    # uniform composer) of an equal rail vector is equal.  We state the
    # implication explicitly instead of enumerating all 2^(2^r) composers.
    composer_collision = len(discriminators) == 0
    return {
        "host": socket.gethostname(),
        "family": "owner-free J-free-local + marker-symmetric-global",
        "W": width,
        "degree": degree,
        "rail_basis_size": len(rails),
        "A_z0": output_zero(A, width),
        "B_z0": output_zero(B, width),
        "rail_discriminators": len(discriminators),
        "all_finite_uniform_composers_collide": composer_collision,
    }


def main() -> None:
    # W=2 covers the smallest two-bank witness through all square-free degrees;
    # W=3 checks the same symmetry family with a third inactive cell.
    for width, max_degree in ((2, 6), (3, 4)):
        for degree in range(max_degree + 1):
            print(json.dumps(check(width, degree), sort_keys=True))


if __name__ == "__main__":
    main()
