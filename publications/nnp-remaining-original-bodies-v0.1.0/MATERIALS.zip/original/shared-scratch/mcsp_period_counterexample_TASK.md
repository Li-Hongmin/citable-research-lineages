# Task

Read-only research. In the exact CHMY `{AND,OR,NOT}` gate-count model, determine
whether a proper low-complexity threshold set `L_{n,S}` can have a nonzero additive
period. Seek the smallest explicit counterexample or a proved family with trivial
stabilizer. Small-n exhaustive work is allowed only if it enumerates DAG circuits,
not formulas, and returns a checkable certificate. Distinguish free constants from
nonfree constants. Stop at proof, counterexample, rigorous bounded classification,
or a precise reason the experiment cannot decide the asymptotic question. Do not
edit permanent files or Git.
