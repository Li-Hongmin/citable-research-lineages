#!/usr/bin/env python3
"""Omen boundary check for equation-multiple versus expanded-occurrence counts.

This imports the finite witnessed source-cap kernel and exhausts source
valuations at T <= 8.  A/B are counts of equation multiples; Wp/Wq count
expanded ordinary equation-term occurrences, with repeated monomials retained.
The experiment looks for collisions under endpoint/root summaries and records
whether child summaries still differ.  It does not instantiate actual C456.
"""

from __future__ import annotations

import importlib.util
import json
import sys
from itertools import product
from pathlib import Path


def load_kernel():
    path = Path(__file__).with_name("witnessed_source_cap_omen.py")
    spec = importlib.util.spec_from_file_location("witnessed_kernel", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


K = load_kernel()


def one_summary(dbar, ebar):
    """Compute the exact root summary for one dyadic source stream."""
    T = len(dbar)
    h = T.bit_length() - 1
    equations = K.equation_table(T, dbar, ebar, 0)
    _, p_mult = K.source_p(0, h, dbar, ebar, equations)
    _, q_mult = K.source_q(0, h, dbar, ebar, equations)
    p_records = K.expand_records(p_mult, equations)
    q_records = K.expand_records(q_mult, equations)
    pbar = K.dbar_product(dbar, 0, h)
    qbar = K.ebar_affine(dbar, ebar, 0, h)
    return (pbar, qbar, len(p_mult), len(q_mult),
            len(p_records), len(q_records))


def stream_summary(dbar, ebar):
    """Return root and immediate-child summaries for a power-of-two stream."""
    root = one_summary(dbar, ebar)
    if len(dbar) == 1:
        return root, root
    half = len(dbar) // 2
    child = (one_summary(dbar[:half], ebar[:half]),
             one_summary(dbar[half:], ebar[half:]))
    return root, child


def main():
    totals = {"cases": 0, "endpoint_groups": 0,
              "endpoint_count_groups": 0, "root_weight_groups": 0,
              "max_A": 0, "max_B": 0, "max_Wp": 0, "max_Wq": 0}
    endpoint_groups = {}
    endpoint_count_groups = {}
    root_weight_groups = {}
    full_root_groups = {}

    for T in (1, 2, 4, 8):
        for dbar in product((0, 1), repeat=T):
            for ebar in product((0, 1), repeat=T):
                root, child = stream_summary(dbar, ebar)
                pbar, qbar, A, B, Wp, Wq = root
                key_endpoint = (pbar, qbar)
                key_endpoint_count = (pbar, qbar, A, B)
                key_root_weight = (pbar, qbar, Wp, Wq)
                endpoint_groups.setdefault(key_endpoint, set()).add(
                    (A, B, Wp, Wq))
                endpoint_count_groups.setdefault(key_endpoint_count, set()).add(
                    (Wp, Wq, child, dbar, ebar))
                root_weight_groups.setdefault(key_root_weight, set()).add(
                    (A, B, child, dbar, ebar))
                full_root_key = (pbar, qbar, A, B, Wp, Wq)
                full_root_groups.setdefault(full_root_key, set()).add(
                    (child, dbar, ebar))
                totals["cases"] += 1
                totals["max_A"] = max(totals["max_A"], A)
                totals["max_B"] = max(totals["max_B"], B)
                totals["max_Wp"] = max(totals["max_Wp"], Wp)
                totals["max_Wq"] = max(totals["max_Wq"], Wq)

    endpoint_collisions = {
        k: sorted(v) for k, v in endpoint_groups.items() if len(v) > 1
    }
    endpoint_count_collisions = {
        k: len(v) for k, v in endpoint_count_groups.items() if len(v) > 1
    }
    root_weight_collisions = {
        k: len(v) for k, v in root_weight_groups.items() if len(v) > 1
    }
    full_root_collisions = {
        k: len(v) for k, v in full_root_groups.items() if len(v) > 1
    }
    totals["endpoint_groups"] = len(endpoint_collisions)
    totals["endpoint_count_groups"] = len(endpoint_count_collisions)
    totals["root_weight_groups"] = len(root_weight_collisions)
    totals["full_root_groups"] = len(full_root_collisions)

    # Keep one compact witness for each boundary that is found.
    witness = {}
    if endpoint_collisions:
        key = next(iter(endpoint_collisions))
        witness["endpoint_only"] = {"key": list(key),
                                     "values": endpoint_collisions[key][:8]}
    if endpoint_count_collisions:
        key = next(iter(endpoint_count_collisions))
        witness["endpoint_plus_equation_counts"] = {
            "key": list(key), "distinct_weight_child_records":
            endpoint_count_collisions[key]}
    if root_weight_collisions:
        key = next(iter(root_weight_collisions))
        witness["endpoint_plus_expanded_counts"] = {
            "key": list(key), "distinct_equation_child_records":
            root_weight_collisions[key]}
    if full_root_collisions:
        key = next(iter(full_root_collisions))
        # Preserve a concrete pair, not just the collision multiplicity.
        records = list(full_root_groups[key])
        witness["endpoint_plus_all_root_counts"] = {
            "key": list(key),
            "distinct_child_records": full_root_collisions[key],
            "examples": [
                {"dbar": list(d), "ebar": list(e), "child": c}
                for c, d, e in records[:2]
            ],
        }

    result = {
        "host": "omen",
        "scope": "finite witnessed source-transformer; actual C456 uninstantiated",
        "max_T": 8,
        "failures": 0,
        "route_decision": {
            "equation_multiple_count_only": "CLOSED_BY_COLLISION",
            "root_counts_plus_expanded_counts":
                "CLOSED_IF_CHILD_NAVIGATION_REQUIRED",
            "source_aware_full_ledger": "REMAINS_ADMISSIBLE",
            "actual_C456": "UNKNOWN_PAUSE",
        },
        "totals": totals,
        "witness": witness,
    }
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
