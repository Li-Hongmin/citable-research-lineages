from itertools import combinations
import numpy as np
from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import lil_matrix
def parity(x):return x.bit_count()&1
def rank(rows):
 rows=list(rows);r=0
 for c in range(max([x.bit_length() for x in rows]+[0])):
  p=next((i for i in range(r,len(rows)) if rows[i]>>c&1),None)
  if p is None:continue
  rows[r],rows[p]=rows[p],rows[r]
  for i in range(len(rows)):
   if i!=r and rows[i]>>c&1:rows[i]^=rows[r]
  r+=1
 return r
def rows(C,I,n):
 out=[]
 for i in I:
  x,y=C[i]; out.extend([x|(1<<n),y|(1<<n)|(1<<(n+1))])
 return out
def consistent(C,I,n):
 R=rows(C,I,n);mask=(1<<(n+1))-1
 return rank([v&mask for v in R])==rank(R)
def leaf(C,n,z):
 r,t=z>>1,z&1
 return [i for i,(x,y) in enumerate(C) if parity(r&x)==t and parity(r&y)==1-t]
def gen(X,Y,n,s,k=4):
 C=[(x,y) for x in X for y in Y]; si=C.index(s); out=[]; seen=set()
 for z in range(1<<(n+1)):
  L=leaf(C,n,z)
  for I in combinations([i for i in L if i!=si],k):
   if consistent(C,I,n) and not consistent(C,I+(si,),n) and all(consistent(C,tuple(j for j in I if j!=i)+(si,),n) for i in I):
    T=sum(1<<i for i in I)
    if T not in seen:seen.add(T);out.append(T)
 return C,out
def solve(X,Y,n,s,k=4):
 C,cand=gen(X,Y,n,s,k); print('cand',len(cand))
 m=len(cand); leaves=[sum(1<<i for i in leaf(C,n,z)) for z in range(1<<(n+1))];L=len(leaves)
 # optimize full thinning samples R
 samples={}
 for z,Lz in enumerate(leaves):
  rs=sorted({C[i][0] for i in range(len(C)) if Lz>>i&1});cs=sorted({C[i][1] for i in range(len(C)) if Lz>>i&1})
  w=1/((1<<(n+1))*(1<<len(rs))*(1<<len(cs)))
  for mr in range(1<<len(rs)):
   U={rs[j] for j in range(len(rs)) if mr>>j&1}
   for mc in range(1<<len(cs)):
    V={cs[j] for j in range(len(cs)) if mc>>j&1}
    R=sum(1<<i for i,(x,y) in enumerate(C) if Lz>>i&1 and x in U and y in V)
    samples[R]=samples.get(R,0)+w
 samples=list(samples.items()); q=len(samples)
 rowsA=[];lo=[];hi=[]
 for i in range(m):
  for j in range(i):
   if cand[i]&cand[j]==0:rowsA.append({i:1,j:1});lo.append(-np.inf);hi.append(1)
 for j,(R,w) in enumerate(samples):
  row={m+j:1}
  for i,T in enumerate(cand):
   if T&~R==0:row[i]=-1
  rowsA.append(row);lo.append(-np.inf);hi.append(0)
 A=lil_matrix((len(rowsA),m+q))
 for ri,row in enumerate(rowsA):
  for ci,v in row.items():A[ri,ci]=v
 obj=np.zeros(m+q)
 for j,(R,w) in enumerate(samples):obj[m+j]=-w
 rr=milp(obj,integrality=np.r_[np.ones(m),np.zeros(q)],bounds=Bounds(np.zeros(m+q),np.ones(m+q)),constraints=LinearConstraint(A.tocsr(),np.array(lo),np.array(hi)),options={'time_limit':300,'mip_rel_gap':0})
 ch=[cand[i] for i in range(m) if rr.x[i]>.5]
 return -rr.fun,[[C[i] for i in range(len(C)) if T>>i&1] for T in ch]
if __name__=='__main__':
 n=4; X=list(range(8));Y=list(range(8,16));s=(X[0],Y[0]);print(solve(X,Y,n,s,4)[0])
