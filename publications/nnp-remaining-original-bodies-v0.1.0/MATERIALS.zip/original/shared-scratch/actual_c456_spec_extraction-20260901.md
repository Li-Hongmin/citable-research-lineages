# actual C456 规格抽取（2026-09-01）

## 结论

当前仓库和已缓存 Ren--Williams 全文没有一份可直接实例化 Gate 0-R 的
actual-C456 package。`P=NP` 分支只在存在性量词下固定了
`D_all`、派生机器 `M` 和单比特 source；`Comp_ANF`、fixed-sweep wrapper
提供了静态地址 schema，但没有提供实际可达轨道、virtual-owner/derivation
ledger 或完整四步 packet。因此当前结论是：

```
Gate 0-S（参数化静态 wiring）       PASS（条件于选择固定 M、p 和输出 convention）
Gate 0-R（actual reachable records） PAUSE / UNKNOWN
actual C456 RevRange / ODStream      PAUSE / UNKNOWN
```

这里的 `PASS` 不是 C596 证书；它只表示固定 schema 的可推导性。

## 逐字段证据表

| 字段 | 当前权威证据 | 状态 | 不能据此声称 |
|---|---|---|---|
| (D_{\rm all}) | Note 456, lines 72--84：定义 (L_{\rm all}=\{q:\exists w\,\forall r\,V(q,w;r)=1\}\)，在 (P=NP) 下存在一个固定多项式时间 decider | **存在性固定，具体缺失** | 没有 decider 的状态/转移表或可运行描述 |
| (M) | Note 456, lines 47--56, 80--99：读取 (x_n=(1^n,a_n)) 的最后一位，模拟固定 (A'_a(1^n))，以 (D_{\rm all}) 替换 prMA calls；(M(x_n)=B_n) | **语义 schema 固定，低层定义缺失** | 没有实际 finite-state 编码、状态集、带布局和 transition rows |
| (	au_M) | Note 656, lines 40--50：一旦 binary machine encoding 固定，(	au_M) 随之固定 | **可由固定编码推导；当前未冻结** | “任意固定 (M)”占位符不是 actual transition table |
| 运行界 (p)、宏步 (T) | Note 638, lines 24--36：对选择的固定 ((M,p))，(T=p(s)\ge s)；Note 705, lines 90--96 重述 | **公式可推导；具体 (p,T) 缺失** | actual C456 的数值化时间范围或实际轨道长度 |
| 物理宽度 (W)、物理步数 (T_{\rm obl}) | Note 638, lines 42--48, 80--82：(W=2^{\lceil\log_2(s+2T+c_M)\rceil})，(T_{\rm obl}=O(TW)=O(T^2)) | **fixed-sweep 条件 schema** | 这不是 published C456 已采用的实际 layout；(c_M) 也未给数值 |
| track / phase / bank offsets | Note 638, lines 119--181：两 bank (A,B)、记录 (R_c)、固定半扫掠；式 (638.12) 给出 (u,r)、phase、反射 cell；Note 705, lines 100--119 给出四层 output-copy 的符号 (kappa_r,\rho_r) | **wrapper 可推导；actual offsets 缺失** | 没有具体 track 编号、(I,C,\Delta_{\rm fin},\kappa_r,\rho_r) 和 output-copy phase 的冻结实例 |
| transition schema | Note 638, lines 131--160：通用有限状态 (delta(q,\sigma_1,\ldots,\sigma_k)=(q',w_i,d_i)) 及式 (638.11) 的 bank 更新；Note 600, lines 24--54 给出固定 ANF gadget/地址元组 | **通用 schema 可推导；实际 (	au_M) 缺失** | 不能从通用 (delta) 得到 actual reachable values |
| physical predecessor / gate locators | Note 600, lines 24--54；Note 638, lines 94--107：固定编译器地址字段可由 (m^{O(1)}) 电路生成 | **静态 schema 可推导** | 未给出 actual output cone 的 reachable gate records、owner/pivot/demand |
| reachable orbit / virtual configuration | Note 675, lines 43--60：在 retained hist/out 不干扰 transition 的附加条件下，每个 reachable event 有唯一语义 owner；Note 677, lines 36--67：唯一轨道不推出 binary-time accessor | **缺失** | 没有 (operatorname{Conf}_M(n,a,t,\lambda))、virtual-owner map 或 source-aware orbit grammar |
| binary output locator (omega_n(j)) | Note 653, lines 28--54：在选定 track-major compiler 下把 (omega_n(j)) 定义为携带 (B_n[j]) 的 physical output address，并声称由固定 offsets 生成；Note 705, lines 100--119：专用 wrapper 给出 (omega_{M,p}(s,j)=a_{4,j}) | **抽象定义/参数化 wrapper 可推导；actual 数值 locator 未冻结** | wrapper 的 (a_{4,j}) 不是原始 actual C456 reachable output wire |
| target cap | Note 695, lines 11--47：(x_o=x_{\omega_n(j)})，output equality 与 wrong-output equation 给出 exact target cap | **PASS（条件于 (omega_n) layout）** | 不能补出 source cap 或完整 RevRange |
| source cap / InitTel endpoint | Note 695, lines 69--103；Note 697, lines 77--204：需要地址尺度 (P_0^{n,j,b}) 和 power-closed reverse-range normalizer | **缺失** | 没有 actual (P_0)、source ledger 或 endpoint orientation |
| `ODStream` | Note 691, lines 48--69, 172--183；Note 701, lines 22--51：需要 (O(t),C_D(t),\mathrm{DAtom},\mathrm{DProv},\mathrm{DPartner}) 及 cumulative prefix | **缺失** | local count、physical schedule count 或有限 ideal membership 不能替代它 |
| four-step output-reaching packet | Note 717, lines 12--82：列出 packet 所需 boundary state、四个实际方程、完整 records/count/Atom/Prov/Partner、source leaves、terminal locator、InitTel | **缺失；Gate 0-R PAUSE** | 不能把 toy/wrapper Omen 结果升级为 actual packet |

## 量词和证据边界

1. `D_all`、`M` 的“固定”是 (P=NP) 反证分支中的存在性选择；尚未给出一份可运行的机器编码。Note 456 只保证 (M(x_n)=B_n)，且 source 为 (x_n=(1^n,a_n))，其中 (a_n) 是显式逐长度 advice bit。
2. Note 600/638 的地址生成器只说明“给定一个已选定的固定 machine/compiler，静态 gate type、predecessor 和 phase arithmetic 可在 (m^{O(1)}) 生成”。它们不提供 machine 的 orbit 值，也不提供 owner/pivot/demand。
3. (omega_n(j)) 有两种不能混淆的层次：Note 653 的符号化 output-address map，以及 Note 705 的专用 output-copy wrapper。两者均未证明是原始 published C456 output cone 的数值化、可达 locator。
4. Note 714, lines 325--343 明确列出当前仓库没有 concrete (D_{\rm all},M,\tau_M)、(W,T)/offsets、owner map、binary (omega_n) 或完整四步 packet；并把 actual `RevRange/ODStream` 判为 `UNKNOWN/PAUSE`。

## 最小缺失字段（下一次决策只需这些）

要把 Gate 0-R 变成可检验输入，至少需要一份同一固定 schema 下的：

1. 具体 (D_{\rm all}) 选择、(M) 的 finite-state/binary encoding、(	au_M) 和固定 polynomial clock (p)；
2. 明确 (W,T)、track/phase/bank 编号、全部 (I,C,\Delta) 与 predecessor offsets；
3. 对一个真实 reachable output-reaching interval（最终为四步）给出 virtual-owner/event map、demand/pivot、四个实际 equations；
4. 每个 equation 的 repeated-address ordinary records、exact multiple/expanded counts、Atom、Provenance、Partner；
5. 同一 schema 下的 binary (omega_n(j))、terminal bridge 和 candidate-independent source leaves/InitTel。

在这些字段出现前，不再做未实例化 wrapper 的 Omen 扩展；也不切换 MCSP。该文件是抽取报告，不是数学定理或永久 note。

## 来源索引

* [Note 456](../units/mcsp-hardness-magnification/notes/456-published-rw-output-source-alignment-and-direct-scale-boundary-2026-08-19.md)
* [Note 600](../units/mcsp-hardness-magnification/notes/600-heavy-light-occurrence-addresses-reduce-random-access-to-heavy-run-summaries-2026-08-28.md)
* [Note 638](../units/mcsp-hardness-magnification/notes/638-oblivious-sweep-normalization-exposes-physical-head-tokens-without-virtual-trace-advice-2026-08-29.md)
* [Note 653](../units/mcsp-hardness-magnification/notes/653-global-target-independent-val-accessor-violates-c455-2026-08-29.md)
* [Note 656](../units/mcsp-hardness-magnification/notes/656-actual-c456-normalization-gate-remains-unknown-2026-08-29.md)
* [Note 675](../units/mcsp-hardness-magnification/notes/675-actual-zero-round-c456-has-semantic-owner-uniqueness-but-not-address-scale-certificate-2026-08-29.md)
* [Note 677](../units/mcsp-hardness-magnification/notes/677-zero-round-owner-uniqueness-does-not-yield-binary-time-orbit-accessor-2026-08-29.md)
* [Note 691](../units/mcsp-hardness-magnification/notes/691-actual-c456-reduces-to-owner-derivation-stream-2026-08-30.md)
* [Note 695](../units/mcsp-hardness-magnification/notes/695-actual-c456-target-cap-passes-source-cap-remains-2026-08-30.md)
* [Note 697](../units/mcsp-hardness-magnification/notes/697-init-telescoping-reduces-c456-source-cap-to-reverse-range-normalizer-2026-08-30.md)
* [Note 700](../units/mcsp-hardness-magnification/notes/700-binary-address-quantifiers-are-necessary-for-c456-forcing-2026-08-30.md)
* [Note 701](../units/mcsp-hardness-magnification/notes/701-odstream-needs-cumulative-prefix-counts-2026-08-30.md)
* [Note 705](../units/mcsp-hardness-magnification/notes/705-s-level-program-one-active-family-2026-08-30.md)
* [Note 714](../units/mcsp-hardness-magnification/notes/714-power-closed-revrange-requires-transformer-algebra-2026-09-01.md)
* [Note 717](../units/mcsp-hardness-magnification/notes/717-four-step-packet-and-source-ledger-gates-2026-09-01.md)

