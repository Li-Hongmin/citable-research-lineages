#!/usr/bin/env python3
"""Omen check for the source-transformer identities proposed after Note 710.

All arithmetic is in GF(2).  This is a finite sanity check only: it does not
instantiate an actual C456 machine or prove an address-scale compiler.
"""

from __future__ import annotations

import json
import random
import sys
import time
from itertools import product


def xor_prod(a: int, b: int) -> int:
    return a & b


def build_rails(D: list[int], E: list[int]):
    """Return p[k][a], q[k][a] for T=2**h leaves."""
    T = len(D)
    p = [list(D)]
    q = [list(E)]
    while len(p[-1]) > 1:
        pk = []
        qk = []
        prev_p, prev_q = p[-1], q[-1]
        for i in range(0, len(prev_p), 2):
            pk.append(prev_p[i] & prev_p[i + 1])
            qk.append((prev_p[i + 1] & prev_q[i]) ^ prev_q[i + 1])
        p.append(pk)
        q.append(qk)
    return p, q


def build_source_rails(Db: list[int], Eb: list[int]):
    return build_rails(Db, Eb)


def check_case(D, E, Db, Eb, y0, yb, b):
    T = len(D)
    h = T.bit_length() - 1
    p, q = build_rails(D, E)
    pb, qb = build_source_rails(Db, Eb)

    # Boundary values are only needed for local identities.  Choose arbitrary
    # y's; the identities are polynomial identities and must not use a
    # recurrence assumption.
    rng = random.Random((T << 20) ^ (y0 << 9) ^ (yb << 5) ^ b)
    y = [y0] + [rng.randrange(2) for _ in range(T)]

    local_count = 0
    # Leaves: f_a + e_a + y_a u^p_a + u^q_a = 0.
    for a in range(T):
        pa, qa = p[0][a], q[0][a]
        up, uq = pa ^ D[a], qa ^ E[a]
        f = y[a + 1] ^ (pa & y[a]) ^ qa
        e = y[a + 1] ^ (D[a] & y[a]) ^ E[a]
        if f ^ e ^ (y[a] & up) ^ uq:
            return False, "leaf-local", a
        local_count += 3

    # Parents: f_P + f_R + p_R f_L + y_a u^p_P + u^q_P = 0.
    for k in range(1, h + 1):
        span = 1 << k
        half = span >> 1
        for a in range(0, T, span):
            ai = a // span
            li = a // half
            ri = li + 1
            pP, qP = p[k][ai], q[k][ai]
            pL, qL = p[k - 1][li], q[k - 1][li]
            pR, qR = p[k - 1][ri], q[k - 1][ri]
            up, uq = pP ^ (pL & pR), qP ^ (pR & qL) ^ qR

            def f(start, pp, qq, length):
                return y[start + length] ^ (pp & y[start]) ^ qq

            fP = f(a, pP, qP, span)
            fL = f(a, pL, qL, half)
            fR = f(a + half, pR, qR, half)
            if fP ^ fR ^ (pR & fL) ^ (y[a] & up) ^ uq:
                return False, "parent-local", (k, a)
            local_count += 2

    # Source-transformer S^p/S^q at every node.
    Sp = [[p[0][a] ^ Db[a] for a in range(T)]]
    Sq = [[q[0][a] ^ Eb[a] for a in range(T)]]
    for k in range(1, h + 1):
        span = 1 << k
        half = span >> 1
        Spk, Sqk = [], []
        for a in range(0, T, span):
            li = a // half
            ri = li + 1
            pP, qP = p[k][a // span], q[k][a // span]
            pL, qL = p[k - 1][li], q[k - 1][li]
            pR, qR = p[k - 1][ri], q[k - 1][ri]
            up, uq = pP ^ (pL & pR), qP ^ (pR & qL) ^ qR
            spL, spR = Sp[k - 1][li], Sp[k - 1][ri]
            sqL, sqR = Sq[k - 1][li], Sq[k - 1][ri]
            Spk.append(up ^ (pb[k - 1][ri] & spL) ^ (pL & spR))
            Sqk.append(uq ^ (pR & sqL) ^ sqR ^ (qb[k - 1][li] & spR))
        Sp.append(Spk)
        Sq.append(Sqk)

        # Compare with the claimed closed forms p_P+bar p_P and q_P+bar q_P.
        for a in range(0, T, span):
            i = a // span
            if Sp[k][i] != (p[k][i] ^ pb[k][i]):
                return False, "Sp-closed-form", (k, a)
            if Sq[k][i] != (q[k][i] ^ qb[k][i]):
                return False, "Sq-closed-form", (k, a)

    # Leaf closed forms too.
    for a in range(T):
        if Sp[0][a] != (p[0][a] ^ pb[0][a]):
            return False, "Sp-leaf", a
        if Sq[0][a] != (q[0][a] ^ qb[0][a]):
            return False, "Sq-leaf", a

    # Root candidate identity S_0 = P_0 + b.
    pI, qI = p[h][0], q[h][0]
    bpI, bqI = pb[h][0], qb[h][0]
    S0 = (
        (pI & (y0 ^ yb))
        ^ (yb & Sp[h][0])
        ^ Sq[h][0]
        ^ (bpI & yb)
        ^ bqI
        ^ b
    )
    P0 = (pI & y0) ^ qI
    if S0 != (P0 ^ b):
        return False, "root-candidate", None

    return True, local_count, (Sp[h][0], Sq[h][0], pI, qI, bpI, bqI)


def exhaustive(T: int):
    total = 0
    for bits in product((0, 1), repeat=4 * T + 3):
        D = list(bits[0:T])
        E = list(bits[T : 2 * T])
        Db = list(bits[2 * T : 3 * T])
        Eb = list(bits[3 * T : 4 * T])
        y0, yb, b = bits[-3:]
        ok, where, detail = check_case(D, E, Db, Eb, y0, yb, b)
        total += 1
        if not ok:
            return {"ok": False, "kind": "exhaustive", "T": T,
                    "cases": total, "where": where, "detail": detail}
    return {"ok": True, "kind": "exhaustive", "T": T, "cases": total}


def random_batch(T: int, cases: int, seed: int):
    rng = random.Random(seed)
    for i in range(cases):
        D = [rng.randrange(2) for _ in range(T)]
        E = [rng.randrange(2) for _ in range(T)]
        Db = [rng.randrange(2) for _ in range(T)]
        Eb = [rng.randrange(2) for _ in range(T)]
        y0, yb, b = (rng.randrange(2) for _ in range(3))
        ok, where, detail = check_case(D, E, Db, Eb, y0, yb, b)
        if not ok:
            return {"ok": False, "kind": "random", "T": T,
                    "case": i + 1, "where": where, "detail": detail}
    return {"ok": True, "kind": "random", "T": T, "cases": cases, "seed": seed}


def toy_source_endpoint(T: int, cases: int, seed: int):
    """Check the 710.9 toy endpoint under Dbar=1, Ebar=0, y0=ybar=1, b=1.

    This checks the resulting terminal identity numerically for arbitrary actual
    D,E and arbitrary boundary y's with y0 fixed to one.  The source equations
    are evaluated at their satisfying assignment, so y_T=1.
    """
    rng = random.Random(seed)
    for i in range(cases):
        D = [rng.randrange(2) for _ in range(T)]
        E = [rng.randrange(2) for _ in range(T)]
        Db = [1] * T
        Eb = [0] * T
        y0 = yb = b = 1
        ok, where, detail = check_case(D, E, Db, Eb, y0, yb, b)
        if not ok:
            return {"ok": False, "kind": "toy-root", "T": T,
                    "case": i + 1, "where": where, "detail": detail}

        # Under the satisfying source assignment, y_T=1.  With y0=1 the
        # endpoint residual f + p(y0+1) + S0 is therefore y_T+1=0.
        p, q = build_rails(D, E)
        pI, qI = p[-1][0], q[-1][0]
        f = 1 ^ (pI & 1) ^ qI
        S0 = (pI & 1) ^ qI ^ 1  # candidate identity gives S0=P0+1
        if f ^ (pI & (1 ^ 1)) ^ S0:
            return {"ok": False, "kind": "toy-root", "T": T,
                    "case": i + 1, "where": "terminal-residual", "detail": 1}
    return {"ok": True, "kind": "toy-root", "T": T, "cases": cases,
            "seed": seed, "source_endpoint": 1}


def main():
    started = time.time()
    out = {"host": "omen", "gf2": True, "results": []}
    for T in (1, 2, 4):
        out["results"].append(exhaustive(T))
    for T, cases in ((8, 5000), (16, 3000), (32, 1500), (64, 750),
                     (256, 250), (1024, 100)):
        out["results"].append(random_batch(T, cases, 710_000 + T))
        out["results"].append(toy_source_endpoint(T, max(10, cases // 10),
                                                    710_100 + T))
    out["slot_counts"] = {str(1 << h): 5 * (1 << h) - 2 for h in range(0, 11)}
    out["elapsed_seconds"] = round(time.time() - started, 3)
    print(json.dumps(out, sort_keys=True))
    if not all(item["ok"] for item in out["results"]):
        sys.exit(1)


if __name__ == "__main__":
    main()
