#!/usr/bin/env python3
"""Finite Omen check for a candidate-dependent witnessed source cap.

The model is deliberately smaller than, and not identified with, actual C456.
It is an affine dyadic recurrence

    y[t+1] + D[t] y[t] + E[t] = 0

with explicit source leaves D[t]+Dbar[t], E[t]+Ebar[t], and y[0]+ybar[0].
The product rails and their source-transformer derivations are expanded in the
ordinary polynomial ring.  Every expanded equation term keeps an equation
address, multiplier origin, term tag, and repeated-variable monomial record.
For a candidate b, the combined transport + source leaves + wrong-output
equation has exactly one unpaired constant occurrence iff b is the witnessed
source endpoint.  A wrong candidate has no fixed point.

This checks a finite witnessed interface only.  It does not generate an
address-scale source valuation stream for C456.
"""

from __future__ import annotations

import json
import argparse
from dataclasses import dataclass
from itertools import product

Mon = tuple[str, ...]


def canon(mon) -> Mon:
    # Preserve repetitions: this is ordinary-ring bookkeeping, not x^2=x.
    return tuple(sorted(mon))


def add_poly(*polys):
    out = {}
    for poly in polys:
        for mon, bit in poly.items():
            if bit:
                out[mon] = 1 ^ out.get(mon, 0)
                if not out[mon]:
                    del out[mon]
    return out


def mul_poly(left, right):
    out = {}
    for a, ba in left.items():
        if not ba:
            continue
        for b, bb in right.items():
            if not bb:
                continue
            mon = canon(a + b)
            out[mon] = 1 ^ out.get(mon, 0)
            if not out[mon]:
                del out[mon]
    return out


def bit_poly(bit: int):
    return {(): 1} if bit else {}


def var(name: str):
    return {(name,): 1}


def scale(poly, factor):
    return poly if factor else {}


def p_name(kind: str, a: int, k: int):
    return var(f"{kind}{a}_{k}")


@dataclass(frozen=True)
class Equation:
    addr: tuple
    terms: tuple[Mon, ...]


@dataclass(frozen=True)
class Multiple:
    eq: tuple
    multiplier: dict
    origin: tuple
    role: str


@dataclass(frozen=True)
class Occurrence:
    ident: int
    eq: tuple
    origin: tuple
    role: str
    term_tag: int
    monomial: Mon


def equation_table(T: int, dbar, ebar, ybar: int):
    """Build the fixed local equations, including source leaves."""
    eq = {}
    for t in range(T):
        eq[("rec", t)] = Equation(
            ("rec", t),
            ((f"y{t + 1}",), (f"D{t}", f"y{t}"), (f"E{t}",)),
        )
        eq[("up", t, 0)] = Equation(
            ("up", t, 0), ((f"p{t}_0",), (f"D{t}",))
        )
        eq[("uq", t, 0)] = Equation(
            ("uq", t, 0), ((f"q{t}_0",), (f"E{t}",))
        )
        eq[("srcD", t)] = Equation(
            ("srcD", t), ((f"D{t}",), ()) if dbar[t] else ((f"D{t}",),)
        )
        eq[("srcE", t)] = Equation(
            ("srcE", t), ((f"E{t}",), ()) if ebar[t] else ((f"E{t}",),)
        )
    for k in range(1, T.bit_length()):
        span = 1 << k
        half = span >> 1
        for a in range(0, T, span):
            pL, pR = f"p{a}_{k - 1}", f"p{a + half}_{k - 1}"
            qL, qR = f"q{a}_{k - 1}", f"q{a + half}_{k - 1}"
            eq[("up", a, k)] = Equation(
                ("up", a, k), ((f"p{a}_{k}",), (pL, pR))
            )
            eq[("uq", a, k)] = Equation(
                ("uq", a, k), ((f"q{a}_{k}",), (pR, qL), (qR,))
            )
    eq[("srcY0",)] = Equation(("srcY0",), (("y0",), ())
                               if ybar else (("y0",),))
    # Candidate b means that the wrong-output cap is y_T+(1-b)=0.
    for b in (0, 1):
        eq[("target", b)] = Equation(("target", b),
                                      ((f"y{T}",), ()) if (1 ^ b)
                                      else ((f"y{T}",),))
    return eq


def terms_poly(terms):
    out = {}
    for mon in terms:
        mon = canon(mon)
        out[mon] = 1 ^ out.get(mon, 0)
        if not out[mon]:
            del out[mon]
    return out


def multiple_poly(multiple: Multiple, equations):
    return mul_poly(multiple.multiplier,
                    terms_poly(equations[multiple.eq].terms))


def check_identity(boundary, multiples, equations):
    total = dict(boundary)
    for multiple in multiples:
        total = add_poly(total, multiple_poly(multiple, equations))
    return total


def boundary(a, k):
    span = 1 << k
    return add_poly(var(f"y{a + span}"),
                    mul_poly(p_name("p", a, k), var(f"y{a}")),
                    p_name("q", a, k))


def transport(a, k, equations, path=()):
    """Return f_{a,k} + equation multiples = 0."""
    if k == 0:
        t = a
        multiples = [
            Multiple(("rec", t), {(): 1}, path + ("rec",), "transport-rec"),
            Multiple(("up", t, 0), var(f"y{t}"),
                     path + ("up",), "transport-up"),
            Multiple(("uq", t, 0), {(): 1}, path + ("uq",), "transport-uq"),
        ]
        assert not check_identity(boundary(a, 0), multiples, equations)
        return boundary(a, 0), multiples
    half = 1 << (k - 1)
    right_boundary, right = transport(a + half, k - 1, equations,
                                      path + ("R",))
    left_boundary, left = transport(a, k - 1, equations, path + ("L",))
    pR = p_name("p", a + half, k - 1)
    scaled_left = [
        Multiple(m.eq, mul_poly(pR, m.multiplier),
                 path + ("L",) + m.origin, m.role + ":left")
        for m in left
    ]
    multiples = [
        Multiple(("up", a, k), var(f"y{a}"), path + ("up",), "transport-up"),
        Multiple(("uq", a, k), {(): 1}, path + ("uq",), "transport-uq"),
    ] + [
        Multiple(m.eq, m.multiplier, path + ("R",) + m.origin,
                 m.role + ":right") for m in right
    ] + scaled_left
    assert not check_identity(boundary(a, k), multiples, equations), (a, k)
    return boundary(a, k), multiples


def source_p(a, k, dbar, ebar, equations, path=()):
    """Derive p_{a,k}+pbar_{a,k}."""
    if k == 0:
        multiples = [
            Multiple(("up", a, 0), {(): 1}, path + ("up",), "source-p-rail"),
            Multiple(("srcD", a), {(): 1}, path + ("srcD",), "source-D-leaf"),
        ]
        bnd = add_poly(p_name("p", a, 0), bit_poly(dbar[a]))
        assert not check_identity(bnd, multiples, equations)
        return bnd, multiples
    half = 1 << (k - 1)
    _, left = source_p(a, k - 1, dbar, ebar, equations, path + ("L",))
    _, right = source_p(a + half, k - 1, dbar, ebar, equations,
                        path + ("R",))
    # pbar_P = pbar_L pbar_R.  The left correction is scalar pbar_R;
    # the right correction is multiplied by the symbolic p_L rail.
    pbar_R = dbar_product(dbar, a + half, k - 1)
    pL = p_name("p", a, k - 1)
    multiples = [Multiple(("up", a, k), {(): 1}, path + ("up",),
                          "source-p-rail")]
    if pbar_R:
        multiples += [Multiple(m.eq, m.multiplier, path + ("L",) + m.origin,
                               m.role + ":left") for m in left]
    multiples += [Multiple(m.eq, mul_poly(pL, m.multiplier),
                           path + ("R",) + m.origin, m.role + ":right")
                  for m in right]
    bnd = add_poly(p_name("p", a, k),
                   bit_poly(dbar_product(dbar, a, k)))
    assert not check_identity(bnd, multiples, equations), (a, k, "p")
    return bnd, multiples


def dbar_product(dbar, a, k):
    out = 1
    for x in dbar[a:a + (1 << k)]:
        out &= x
    return out


def ebar_affine(dbar, ebar, a, k):
    """qbar for the affine recurrence on interval [a,a+2^k)."""
    if k == 0:
        return ebar[a]
    half = 1 << (k - 1)
    pR = dbar_product(dbar, a + half, k - 1)
    return (pR & ebar_affine(dbar, ebar, a, k - 1)) ^ ebar_affine(
        dbar, ebar, a + half, k - 1)


def source_q(a, k, dbar, ebar, equations, path=()):
    """Derive q_{a,k}+qbar_{a,k}."""
    if k == 0:
        multiples = [
            Multiple(("uq", a, 0), {(): 1}, path + ("uq",), "source-q-rail"),
            Multiple(("srcE", a), {(): 1}, path + ("srcE",), "source-E-leaf"),
        ]
        bnd = add_poly(p_name("q", a, 0), bit_poly(ebar[a]))
        assert not check_identity(bnd, multiples, equations)
        return bnd, multiples
    half = 1 << (k - 1)
    _, left_q = source_q(a, k - 1, dbar, ebar, equations, path + ("L",))
    _, right_q = source_q(a + half, k - 1, dbar, ebar, equations,
                           path + ("R",))
    _, right_p = source_p(a + half, k - 1, dbar, ebar, equations,
                          path + ("RA",))
    pR = p_name("p", a + half, k - 1)
    qbar_L = ebar_affine(dbar, ebar, a, k - 1)
    multiples = [Multiple(("uq", a, k), {(): 1}, path + ("uq",),
                          "source-q-rail")]
    multiples += [Multiple(m.eq, mul_poly(pR, m.multiplier),
                           path + ("L",) + m.origin, m.role + ":left-q")
                  for m in left_q]
    multiples += [Multiple(m.eq, m.multiplier, path + ("R",) + m.origin,
                           m.role + ":right-q") for m in right_q]
    if qbar_L:
        multiples += [Multiple(m.eq, m.multiplier, path + ("RA",) + m.origin,
                               m.role + ":right-p") for m in right_p]
    bnd = add_poly(p_name("q", a, k), bit_poly(ebar_affine(dbar, ebar, a, k)))
    assert not check_identity(bnd, multiples, equations), (a, k, "q")
    return bnd, multiples


def expand_records(multiples, equations, start=0):
    records = []
    ident = start
    for m in multiples:
        eq_terms = equations[m.eq].terms
        # Keep the multiplier's monomial order and all repeated factors.
        for mm in sorted(m.multiplier):
            for tag, tt in enumerate(eq_terms):
                records.append(Occurrence(ident, m.eq, m.origin, m.role, tag,
                                          canon(mm + tt)))
                ident += 1
    return records


def parity_records(records):
    out = {}
    for r in records:
        out[r.monomial] = 1 ^ out.get(r.monomial, 0)
        if not out[r.monomial]:
            del out[r.monomial]
    return out


def partner_map(records):
    buckets = {}
    for i, r in enumerate(records):
        buckets.setdefault(r.monomial, []).append(i)
    partner = {}
    fixed = []
    for mon, ids in buckets.items():
        if len(ids) & 1:
            fixed.append(ids[0])
            ids = ids[1:]
        for a, b in zip(ids[::2], ids[1::2]):
            partner[a] = b
            partner[b] = a
    for i in fixed:
        partner[i] = i
    return partner, fixed


def rank_select(records):
    """Balanced rank/select over the recursively generated record stream."""
    # Building a balanced tree from the generated stream makes the navigation
    # explicit; no polynomial collection is used for record identity.
    n = len(records)

    def select(lo, hi, rank):
        if hi - lo == 1:
            return records[lo]
        mid = (lo + hi) // 2
        if rank < mid - lo:
            return select(lo, mid, rank)
        return select(mid, hi, rank - (mid - lo))

    by_id = {r.ident: i for i, r in enumerate(records)}
    for s in range(n):
        got = select(0, n, s)
        assert by_id[got.ident] == s
    return n


def run_case(dbar, ebar, ybar, b):
    T = len(dbar)
    h = T.bit_length() - 1
    equations = equation_table(T, dbar, ebar, ybar)
    _, transport_mult = transport(0, h, equations)
    _, source_p_mult = source_p(0, h, dbar, ebar, equations)
    _, source_q_mult = source_q(0, h, dbar, ebar, equations)

    # InitTel: p(y0+ybar) + ybar(p+pbar) + (q+qbar) is generated by
    # the three source equation families below.  The target equation is the
    # wrong-output equation y_T+(1-b).
    pI = p_name("p", 0, h)
    source_mult = [Multiple(("srcY0",), pI, ("InitTel", "y0"),
                            "InitTel-y0")]
    if ybar:
        source_mult += [Multiple(m.eq, m.multiplier, ("InitTel", "p") + m.origin,
                                 m.role + ":InitTel-p") for m in source_p_mult]
    source_mult += [Multiple(m.eq, m.multiplier, ("InitTel", "q") + m.origin,
                             m.role + ":InitTel-q") for m in source_q_mult]
    target_const = 1 ^ b
    target = Multiple(("target", b), {(): 1}, ("target",), "wrong-output")
    all_mult = transport_mult + source_mult + [target]
    records = expand_records(all_mult, equations)
    parity = parity_records(records)

    pbar = dbar_product(dbar, 0, h)
    qbar = ebar_affine(dbar, ebar, 0, h)
    endpoint = (pbar & ybar) ^ qbar
    expected_residual = endpoint ^ target_const
    assert parity == ({(): 1} if expected_residual else {}), (
        dbar, ebar, ybar, b, parity, expected_residual
    )
    partner, fixed = partner_map(records)
    for i, j in partner.items():
        assert partner[j] == i
        assert records[i].monomial == records[j].monomial
    assert len(fixed) == (1 if expected_residual else 0)
    if fixed:
        assert records[fixed[0]].monomial == ()
    count = rank_select(records)
    # Explicit endpoint and source-leaf checks.
    assert endpoint == b if expected_residual else endpoint != b
    # A source-p leaf may be deleted by a zero source coefficient in (711.6);
    # q leaves remain explicit.  We only require that every source equation
    # which is used has a tagged record; omitted zero-coefficient leaves are
    # not silently counted.
    assert all(m.eq[0] in {"up", "srcD"} for m in source_p_mult)
    assert all(m.eq[0] in {"uq", "srcE", "up", "srcD"}
               for m in source_q_mult)
    return {
        "T": T,
        "candidate": b,
        "endpoint": endpoint,
        "pbar": pbar,
        "qbar": qbar,
        "count": count,
        "fixed": len(fixed),
        "max_degree": max((len(r.monomial) for r in records), default=0),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--max-t",
        type=int,
        default=4,
        help="largest dyadic T to exhaust (default: 4)",
    )
    args = parser.parse_args()
    if args.max_t < 1 or args.max_t & (args.max_t - 1):
        raise SystemExit("--max-t must be a positive power of two")

    rows = []
    max_count = 0
    max_degree = 0
    sizes = []
    T = 1
    while T <= args.max_t:
        sizes.append(T)
        T <<= 1
    for T in sizes:
        for dbar in product((0, 1), repeat=T):
            for ebar in product((0, 1), repeat=T):
                for ybar in (0, 1):
                    endpoint = (dbar_product(dbar, 0, T.bit_length() - 1)
                                & ybar) ^ ebar_affine(
                                    dbar, ebar, 0, T.bit_length() - 1)
                    for b in (0, 1):
                        row = run_case(dbar, ebar, ybar, b)
                        rows.append(row)
                        max_count = max(max_count, row["count"])
                        max_degree = max(max_degree, row["max_degree"])
    correct = sum(r["fixed"] == 1 for r in rows)
    wrong = sum(r["fixed"] == 0 for r in rows)
    assert correct == wrong == len(rows) // 2
    print(json.dumps({
        "host": "omen",
        "cases": len(rows),
        "failures": 0,
        "correct_candidate_fixed_points": correct,
        "wrong_candidate_no_fixed_point": wrong,
        "max_record_count": max_count,
        "max_record_degree": max_degree,
        "scope": "finite affine dyadic recurrence with witnessed source leaves; not actual C456",
        "max_t": args.max_t,
        "route_decision": {
            "candidate_dependent_witnessed_source_cap": "PASS_CONDITIONAL",
            "extra_over_p_only_product_rail": "full_q_rail+arbitrary_source_values+endpoint_soundness+records",
            "address_scale_without_source_stream_generator": "UNKNOWN_PAUSE",
            "actual_C456": "UNKNOWN_PAUSE",
        },
    }, sort_keys=True))


if __name__ == "__main__":
    main()
