import importlib.util,itertools,sys,time
sp=importlib.util.spec_from_file_location('m','scratch/aekr_minimal_search.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
import numpy as np
from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import lil_matrix
def solve_pair(C,cands,samples,ia,ib,limit=5):
 cands=[T for T in cands if T>>ia&1 or T>>ib&1]
 if not cands:return 0,[]
 ev=[[i for i,T in enumerate(cands) if T&~R==0] for R,w in samples]; act=[j for j,E in enumerate(ev) if E]
 mm=len(cands);q=len(act);rr=[];lo=[];hi=[]
 # force tau cover by requiring each chosen T contains a or b already
 for i in range(mm):
  for j in range(i):
   if cands[i]&cands[j]==0:rr.append({i:1,j:1});lo.append(-np.inf);hi.append(1)
 for jj,j in enumerate(act):
  row={mm+jj:1}
  for i in ev[j]:row[i]=-1
  rr.append(row);lo.append(-np.inf);hi.append(0)
 A=lil_matrix((len(rr),mm+q))
 for ri,row in enumerate(rr):
  for ci,v in row.items():A[ri,ci]=v
 obj=np.zeros(mm+q)
 for jj,j in enumerate(act):obj[mm+jj]=-samples[j][1]
 res=milp(obj,integrality=np.r_[np.ones(mm),np.zeros(q)],bounds=Bounds(np.zeros(mm+q),np.ones(mm+q)),constraints=LinearConstraint(A.tocsr(),np.array(lo),np.array(hi)),options={'time_limit':limit,'mip_rel_gap':0})
 if res.x is None:return 0,[]
 ch=[cands[i] for i in range(mm) if res.x[i]>.5]
 return -res.fun,ch
if __name__=='__main__':
 n=3;vals=range(8);best=(0,None)
 for X in itertools.combinations(vals,4):
  Y=[v for v in vals if v not in X];s=(X[0],Y[0]);C,cands=m.candidates(list(X),Y,n,s,4)
  # only k>=3, and exclude singleton common-cell candidates not relevant
  cands=[T for T in cands if T.bit_count()>=3]; samples=m.event_samples(C,n)
  if not cands:continue
  cells=[i for i,c in enumerate(C) if c!=s]
  for ia,ib in itertools.combinations(cells,2):
   v,ch=solve_pair(C,cands,samples,ia,ib)
   if v>best[0]+1e-9:
    best=(v,(X,Y,s,C,cands,ia,ib,ch));print('best',v,X,Y,C[ia],C[ib],len(ch),flush=True)
 print('FINAL',best[0],best[1][:3] if best[1] else None)
