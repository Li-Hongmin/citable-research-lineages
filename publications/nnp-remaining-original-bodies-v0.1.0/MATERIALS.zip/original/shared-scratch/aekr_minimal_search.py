from itertools import combinations
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix

def parity(x): return x.bit_count() & 1

def gf2_rank(rows):
    rows = list(rows)
    r=0
    for col in range(max([x.bit_length() for x in rows] + [0])):
        piv = next((i for i in range(r,len(rows)) if (rows[i]>>col)&1), None)
        if piv is None: continue
        rows[r],rows[piv]=rows[piv],rows[r]
        for i in range(len(rows)):
            if i!=r and ((rows[i]>>col)&1): rows[i]^=rows[r]
        r+=1
    return r

def system_rows(C, inds, n):
    # return augmented rows over z=(r bits,t), rhs as low bit in mask n+2
    out=[]
    for i in inds:
        x,y=C[i]
        out.append((x | (1<<n)) | (0<<(n+1)))
        out.append((y | (1<<n)) | (1<<(n+1)))
    return out

def consistent(C, inds, n):
    rows=system_rows(C,inds,n)
    # rank coefficient and augmented
    coef=[v & ((1<<(n+1))-1) for v in rows]
    aug=[v for v in rows]
    return gf2_rank(coef)==gf2_rank(aug)

def rankA(C, inds, n):
    return gf2_rank([v & ((1<<(n+1))-1) for v in system_rows(C,inds,n)])

def leaf(C,n,z):
    r,t=z>>1,z&1
    return [i for i,(x,y) in enumerate(C) if parity(r&x)==t and parity(r&y)==(1-t)]

def event_samples(C,n):
    # aggregate exact sample (R surviving after row/col thinning)->prob
    d={}
    for z in range(1<<(n+1)):
        L=leaf(C,n,z)
        rows=sorted({C[i][0] for i in L}); cols=sorted({C[i][1] for i in L})
        w=1/((1<<(n+1))*(1<<len(rows))*(1<<len(cols)))
        for mr in range(1<<len(rows)):
            U={rows[j] for j in range(len(rows)) if mr>>j&1}
            for mc in range(1<<len(cols)):
                V={cols[j] for j in range(len(cols)) if mc>>j&1}
                R=sum(1<<i for i,(x,y) in enumerate(C) if i in L and x in U and y in V)
                d[R]=d.get(R,0)+w
    return [(R,w) for R,w in d.items() if R]

def candidates(X,Y,n,s,maxk=4):
    C=[(x,y) for x in X for y in Y]; si=C.index(s)
    out=[]
    for k in range(3,maxk+1):
      for tup in combinations([i for i in range(len(C)) if i!=si],k):
        if not consistent(C,tup,n): continue
        if consistent(C,tuple(tup)+(si,),n): continue
        # minimal wrt deleting each cell and adding s
        if any(not consistent(C,tuple(j for j in tup if j!=i)+(si,),n) for i in tup): continue
        if rankA(C,tup,n)<k+1: continue
        out.append(sum(1<<i for i in tup))
    return C,out

def solve(X,Y,n,s,maxk=4,limit=30):
 C,cands=candidates(X,Y,n,s,maxk)
 print('CAND',len(C),len(cands))
 if not cands:return 0,[]
 samples=event_samples(C,n)
 events=[[i for i,T in enumerate(cands) if T & ~R ==0] for R,_ in samples]
 active=[j for j,E in enumerate(events) if E]
 m=len(cands); q=len(active)
 rows=[]; lo=[]; hi=[]
 for i in range(m):
  for j in range(i):
   if cands[i]&cands[j]==0:
    rows.append({i:1,j:1}); lo.append(-np.inf); hi.append(1)
 for jj,j in enumerate(active):
  row={m+jj:1}
  for i in events[j]: row[i]=-1
  rows.append(row); lo.append(-np.inf); hi.append(0)
 A=lil_matrix((len(rows),m+q))
 for ri,row in enumerate(rows):
  for ci,v in row.items(): A[ri,ci]=v
 obj=np.zeros(m+q)
 for jj,j in enumerate(active): obj[m+jj]=-samples[j][1]
 res=milp(obj,integrality=np.r_[np.ones(m),np.zeros(q)],bounds=Bounds(np.zeros(m+q),np.ones(m+q)),constraints=LinearConstraint(A.tocsr(),np.array(lo),np.array(hi)),options={'time_limit':limit,'mip_rel_gap':0})
 ch=[cands[i] for i in range(m) if res.x[i]>.5]
 return -res.fun, [[C[i] for i in range(len(C)) if T>>i&1] for T in ch]

if __name__=='__main__':
 import random
 for n in [3,4,5]:
  for trial in range(20):
   X=random.sample(range(1<<n),min(5,1<<n)); Y=random.sample([v for v in range(1<<n) if v not in X],min(5,(1<<n)-len(X)))
   if len(X)<3 or len(Y)<3:continue
   s=(X[0],Y[0])
   val,ch=solve(X,Y,n,s,4,10)
   if val>1/16+1e-8: print('FOUND',n,X,Y,s,val,ch); raise SystemExit
   print('trial',n,trial,val)
