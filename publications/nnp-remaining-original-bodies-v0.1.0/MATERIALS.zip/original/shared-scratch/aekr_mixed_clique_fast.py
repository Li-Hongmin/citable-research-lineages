from itertools import combinations
from fractions import Fraction
import sys, time


def rank(vs, N):
    vs = list(vs)
    rr = 0
    for c in range(N):
        p = next((i for i in range(rr, len(vs)) if (vs[i] >> c) & 1), None)
        if p is None:
            continue
        vs[rr], vs[p] = vs[p], vs[rr]
        for i in range(len(vs)):
            if i != rr and ((vs[i] >> c) & 1):
                vs[i] ^= vs[rr]
        rr += 1
    return rr


def candidates(N, a, b):
    c = a ^ b
    D = [d for d in range(1, 1 << N) if d not in (a, b, c)]
    out = []
    for k in range(2, N + 1):
        for I in combinations(range(len(D)), k):
            ds = [D[i] for i in I]
            x = 0
            for d in ds:
                x ^= d
            typ = x if x in (a, b, c) else None
            if typ is None or (k & 1) != (typ == a) or rank(ds, N) < k:
                continue
            ok = True
            for j in range(1, k):
                for J in combinations(ds, j):
                    y = 0
                    for d in J:
                        y ^= d
                    if y in (a, b, c) and ((j & 1) == (y == a)):
                        ok = False
                        break
                if not ok:
                    break
            if ok:
                out.append((frozenset(I), typ))
    return D, out


def _supermask_bits(q):
    """Bitset of V masks containing each local mask S."""
    allv = 1 << q
    out = [0] * allv
    out[0] = (1 << allv) - 1
    # M[b] has bit v set exactly when the b-th bit of v is 1.  Intersecting
    # these masks gives all V containing S, using O(q 2^q) big-int ops rather
    # than the O(3^q) submask loop.
    half = [0] * q
    for b in range(q):
        period = 1 << (b + 1)
        block = 1 << b
        one = (1 << block) - 1
        mask = 0
        for base in range(0, allv, period):
            mask |= one << (base + block)
        half[b] = mask
    for s in range(1, allv):
        lb = s & -s
        b = lb.bit_length() - 1
        out[s] = out[s ^ lb] & half[b]
    return out


def build_events(N, D, C):
    """Build candidate event bitsets without scanning candidates per sample."""
    m = len(C)
    ev = [0] * m
    offsets = []
    widths = []
    weights = []
    offset = 0
    cache = {}
    for r in range(1 << N):
        B = [i for i, d in enumerate(D) if (r & d).bit_count() & 1]
        q = len(B)
        width = 1 << q
        offsets.append(offset)
        widths.append(width)
        weights.append(Fraction(1, (1 << N) * width))
        sbits = cache.setdefault(q, _supermask_bits(q))
        local = {j: k for k, j in enumerate(B)}
        for i, (S, _) in enumerate(C):
            if not S.issubset(B):
                continue
            sm = 0
            for j in S:
                sm |= 1 << local[j]
            ev[i] |= sbits[sm] << offset
        offset += width
    return ev, offsets, widths, weights


def solve(N, a, b):
    D, C = candidates(N, a, b)
    m = len(C)
    print({"candidates": m, "D": len(D)}, flush=True)
    ev, offsets, widths, weights = build_events(N, D, C)
    print({"sample_bits": sum(widths)}, flush=True)
    block_masks = [(1 << width) - 1 for width in widths]
    adj = [0] * m
    for i, (S, _) in enumerate(C):
        for j, (T, _) in enumerate(C):
            if i != j and S & T:
                adj[i] |= 1 << j

    def val(mask):
        u = 0
        z = mask
        while z:
            l = z & -z
            i = l.bit_length() - 1
            z ^= l
            u |= ev[i]
        ans = Fraction(0)
        for off, width, block_mask, w in zip(offsets, widths, block_masks, weights):
            ans += w * ((u >> off) & block_mask).bit_count()
        return ans

    best = Fraction(0)
    bestcl = []
    nodes = 0
    start = time.time()

    def bk(R, P, X):
        nonlocal best, bestcl, nodes
        nodes += 1
        if nodes % 100000 == 0:
            print({"nodes": nodes, "best": str(best), "elapsed": round(time.time() - start, 1)}, flush=True)
        if P == 0 and X == 0:
            v = val(R)
            if v > best:
                best, bestcl = v, [i for i in range(m) if (R >> i) & 1]
            return
        U = P | X
        if U:
            pbits = U
            pivot = -1
            score = -1
            while pbits:
                l = pbits & -pbits
                u = l.bit_length() - 1
                pbits ^= l
                sc = (adj[u] & P).bit_count()
                if sc > score:
                    score, pivot = sc, u
            candbits = P & ~adj[pivot]
        else:
            candbits = P
        while candbits:
            l = candbits & -candbits
            v = l.bit_length() - 1
            candbits ^= l
            bk(R | l, P & adj[v], X & adj[v])
            P &= ~l
            X |= l

    bk(0, (1 << m) - 1, 0)
    print({"max_probability": str(best), "clique_size": len(bestcl), "nodes": nodes,
           "elapsed": round(time.time() - start, 1), "clique": bestcl}, flush=True)
    return best


if __name__ == "__main__":
    N, a, b = map(int, sys.argv[1:4]) if len(sys.argv) >= 4 else (5, 1, 2)
    best = solve(N, a, b)
    if best > Fraction(1, 4):
        sys.exit(2)
