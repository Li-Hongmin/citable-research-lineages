#!/usr/bin/env python3
"""Finite Gate-1 check for a four-event canonical-write packet.

This is deliberately a bounded algebra test.  It checks the local identity of
Note 681 after four events are glued through the canonical-write port, while
retaining expanded ordinary-ring occurrences and a deterministic Partner.  It
does not instantiate the actual C456 transition table, orbit, or outer
same-(G,a) skeleton.
"""

from __future__ import annotations

import json
from itertools import product


class Poly:
    """GF(2) polynomial; repeated variables are retained in monomials."""

    __slots__ = ("terms",)

    def __init__(self, terms=()):
        out = {}
        for mon in terms:
            mon = tuple(sorted(mon))
            if mon in out:
                del out[mon]
            else:
                out[mon] = 1
        self.terms = out

    @staticmethod
    def const(bit: int) -> "Poly":
        return Poly([()] if bit & 1 else [])

    @staticmethod
    def var(name: str) -> "Poly":
        return Poly([(name,)])

    def __xor__(self, other: "Poly") -> "Poly":
        out = dict(self.terms)
        for mon in other.terms:
            if mon in out:
                del out[mon]
            else:
                out[mon] = 1
        obj = object.__new__(Poly)
        obj.terms = out
        return obj

    def __mul__(self, other: "Poly") -> "Poly":
        out = {}
        for a in self.terms:
            for b in other.terms:
                mon = tuple(sorted(a + b))
                if mon in out:
                    del out[mon]
                else:
                    out[mon] = 1
        obj = object.__new__(Poly)
        obj.terms = out
        return obj

    def eval(self, assignment: dict[str, int]) -> int:
        ans = 0
        for mon in self.terms:
            bit = 1
            for v in mon:
                bit &= assignment[v]
            ans ^= bit
        return ans


ONE = Poly.const(1)


def event(t: int, outer: Poly, a: int):
    """Return endpoint polys, base multiples, and tagged occurrences.

    The canonical write at event t is the next chain variable x[t+1], so the
    four events glue as x0 -> x1 -> ... -> x4.
    """
    x0, x1 = Poly.var(f"x{t}"), Poly.var(f"x{t + 1}")
    sigma = Poly.var(f"s{t}")
    J = Poly.var(f"J{t}")
    what = Poly.var(f"w{t}")
    q = x0 ^ sigma ^ (J * sigma) ^ (J * x1)
    gw = x1 ^ sigma ^ (J * sigma) ^ (J * what)
    bJ = (J * J) ^ J
    # Derived branch-one token from (681.7), retained as base equation
    # multiples rather than introduced as a free equation.
    d1 = ((J ^ ONE) * gw) ^ (sigma * bJ) ^ (what * bJ)
    lhs = (x0 ^ Poly.const(a))
    rhs = (x1 ^ Poly.const(a))
    multiples = [
        ("q", outer * q),
        ("Jgw", outer * J * gw),
        ("gw", outer * gw),
        ("sigbJ", outer * sigma * bJ),
        ("whatbJ", outer * what * bJ),
    ]
    # Expand each multiple without parity cancellation: this is the ordinary
    # repeated-address ledger used by the Partner check.  The explicit lists
    # below intentionally retain duplicates such as J*J*w and J*w.
    gmon = tuple(sorted(outer.terms.keys().__iter__().__next__(),
                        key=str)) if outer.terms else ()
    raw = {
        "q": [(f"x{t}",), (f"s{t}",), (f"J{t}", f"s{t}"),
              (f"J{t}", f"x{t + 1}")],
        "Jgw": [(f"J{t}", f"x{t + 1}"), (f"J{t}", f"s{t}"),
                (f"J{t}", f"J{t}", f"s{t}"),
                (f"J{t}", f"J{t}", f"w{t}")],
        "gw": [(f"x{t + 1}",), (f"s{t}",), (f"J{t}", f"s{t}"),
               (f"J{t}", f"w{t}")],
        "sigbJ": [(f"s{t}", f"J{t}", f"J{t}"),
                  (f"s{t}", f"J{t}")],
        "whatbJ": [(f"w{t}", f"J{t}", f"J{t}"),
                   (f"w{t}", f"J{t}")],
    }
    occ = []
    for eq_name, _poly in multiples:
        for local_idx, mon in enumerate(raw[eq_name]):
            occ.append({
                "record": tuple(sorted(gmon + mon)),
                "provenance": (t, eq_name, local_idx),
            })
    endpoint_occ = []
    for side, xname in (("left", f"x{t}"), ("right", f"x{t + 1}")):
        # (x+a) has one variable term and, when a=1, one constant term.
        endpoint_occ.append({
            "record": tuple(sorted(gmon + (xname,))),
            "provenance": (t, side, 0),
        })
        if a:
            endpoint_occ.append({
                "record": gmon,
                "provenance": (t, side, 1),
            })
    # Check the local ordinary identity symbolically, with endpoint terms.
    identity = (outer * lhs) ^ (outer * rhs)
    for _, poly in multiples:
        identity = identity ^ poly
    return lhs, rhs, identity, occ, endpoint_occ


def check_one(outer_names: tuple[str, ...], a: int):
    outer = ONE
    for name in outer_names:
        outer = outer * Poly.var(name)

    all_occ = []
    total = Poly.const(0)
    endpoints = []
    for t in range(4):
        lhs, rhs, identity, occ, endpoint_occ = event(t, outer, a)
        if identity.terms:
            return False, {"failure": "local_identity", "event": t,
                           "terms": len(identity.terms)}
        total = total ^ (outer * lhs) ^ (outer * rhs)
        all_occ.extend(occ)
        all_occ.extend(endpoint_occ)
        endpoints.extend([(t, "left", outer * lhs),
                          (t, "right", outer * rhs)])

    # The glued endpoint terms telescope to x0 and x4.  Remove the two
    # explicitly permitted boundary records before checking the full ledger.
    x0 = Poly.var("x0") ^ Poly.const(a)
    x4 = Poly.var("x4") ^ Poly.const(a)
    residual = total ^ (outer * x0) ^ (outer * x4)
    if residual.terms:
        return False, {"failure": "chain_residual",
                       "terms": len(residual.terms)}

    # Keep the boundary occurrences in the local packet ledger.  Each event
    # identity is zero in the ordinary ring, so endpoint terms pair with the
    # corresponding base-equation expansion; when the packet is attached to a
    # source/target cap, only the two outer port labels remain exposed.
    buckets = {}
    for idx, item in enumerate(all_occ):
        buckets.setdefault(item["record"], []).append(idx)
    odd = {str(k): len(v) for k, v in buckets.items() if len(v) % 2}
    if odd:
        return False, {"failure": "odd_record", "odd": odd}
    partner = {}
    for indices in buckets.values():
        for i in range(0, len(indices), 2):
            u, v = indices[i], indices[i + 1]
            if u == v:
                return False, {"failure": "fixed_point"}
            partner[u], partner[v] = v, u
    if len(partner) != len(all_occ):
        return False, {"failure": "partial_partner",
                       "partner": len(partner), "occ": len(all_occ)}

    # Evaluate the same symbolic identity on every Boolean assignment.  This
    # catches accidental assumptions from the ordinary polynomial check.
    names = sorted({v for mon in total.terms for v in mon}
                   | {f"s{t}" for t in range(4)}
                   | {f"J{t}" for t in range(4)}
                   | {f"w{t}" for t in range(4)}
                   | {f"x{t}" for t in range(5)}
                   | set(outer_names))
    # The endpoint residual is intentionally not zero; evaluate the telescoped
    # equality after removing the permitted x0/x4 terms.
    checked = 0
    for bits in product((0, 1), repeat=len(names)):
        assignment = dict(zip(names, bits))
        if residual.eval(assignment):
            return False, {"failure": "boolean_residual", "assignment": assignment}
        checked += 1
    return True, {"occurrences": len(all_occ), "records": len(buckets),
                  "max_record_multiplicity": max(map(len, buckets.values()),
                                                 default=0),
                  "boolean_cases": checked}


def main():
    cases = 0
    max_occ = max_records = max_mult = max_bool = 0
    for degree in range(4):
        # Fresh outer variables make the boundary records unambiguous while
        # covering constants, linear, quadratic, and cubic sparse contexts.
        names = tuple(f"g{i}" for i in range(degree))
        for a in (0, 1):
            ok, detail = check_one(names, a)
            if not ok:
                raise AssertionError({"degree": degree, "a": a, **detail})
            cases += 1
            max_occ = max(max_occ, detail["occurrences"])
            max_records = max(max_records, detail["records"])
            max_mult = max(max_mult, detail["max_record_multiplicity"])
            max_bool = max(max_bool, detail["boolean_cases"])
    print(json.dumps({
        "host": "omen",
        "family": "four-event canonical-write packet",
        "cases": cases,
        "max_occurrences": max_occ,
        "max_distinct_records": max_records,
        "max_record_multiplicity": max_mult,
        "max_boolean_cases": max_bool,
        "failures": 0,
        "scope": "finite Gate-1 algebra; actual C456 wiring and outer skeleton absent",
    }, sort_keys=True))


if __name__ == "__main__":
    main()
