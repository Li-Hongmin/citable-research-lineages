#!/usr/bin/env python3
"""Finite check of the source-transformer Count correction in Note 711."""

from itertools import product


def rails(d, e):
    p, q = [list(d)], [list(e)]
    while len(p[-1]) > 1:
        pp, qq = p[-1], q[-1]
        p.append([pp[i] & pp[i + 1] for i in range(0, len(pp), 2)])
        q.append([(pp[i + 1] & qq[i]) ^ qq[i + 1]
                  for i in range(0, len(pp), 2)])
    return p[-1][0], q[-1][0]


def count(dbar, ebar):
    """Counts with one equation-multiple per source leaf derivation."""
    p = list(dbar)
    q = list(ebar)
    a = [2] * len(p)  # one local rail equation plus one source derivation
    b = [2] * len(q)
    while len(p) > 1:
        pn, qn, an, bn = [], [], [], []
        for i in range(0, len(p), 2):
            pn.append(p[i] & p[i + 1])
            qn.append((p[i + 1] & q[i]) ^ q[i + 1])
            an.append(1 + (a[i] if p[i + 1] else 0) + a[i + 1])
            bn.append(1 + b[i] + b[i + 1] + (a[i + 1] if q[i] else 0))
        p, q, a, b = pn, qn, an, bn
    return p[0], q[0], a[0], b[0]


def main():
    rows = []
    for dbar in product((0, 1), repeat=2):
        for ebar in product((0, 1), repeat=2):
            rows.append((dbar, ebar, count(dbar, ebar)))
    wanted = {
        ((0, 0), (0, 0)): (0, 0, 3, 5),
        ((0, 1), (0, 0)): (0, 0, 5, 5),
        ((0, 0), (1, 0)): (0, 0, 3, 7),
    }
    got = {key: value for d, e, value in rows
           for key in [(d, e)] if key in wanted}
    assert got == wanted, (got, wanted)
    endpoint_groups = {}
    for d, e, value in rows:
        endpoint_groups.setdefault(value[:2], set()).add(value[2:])
    witnesses = {k: sorted(v) for k, v in endpoint_groups.items() if len(v) > 1}
    print({"host": "omen", "T": 2, "rows": len(rows),
           "examples": got, "same_endpoint_different_count": witnesses})


if __name__ == "__main__":
    main()
