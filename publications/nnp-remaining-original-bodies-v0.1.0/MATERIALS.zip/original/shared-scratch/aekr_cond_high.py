from itertools import combinations
import importlib.util,random
sp=importlib.util.spec_from_file_location('m','scratch/aekr_k4_partition.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
import numpy as np
from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import lil_matrix
def cond_opt(C,cand,n,z):
 L=sum(1<<i for i in m.leaf(C,n,z)); rows=sorted({C[i][0] for i in range(len(C)) if L>>i&1});cols=sorted({C[i][1] for i in range(len(C)) if L>>i&1})
 samples=[]
 for mr in range(1<<len(rows)):
  U={rows[j] for j in range(len(rows)) if mr>>j&1}
  for mc in range(1<<len(cols)):
   V={cols[j] for j in range(len(cols)) if mc>>j&1}
   R=sum(1<<i for i,(x,y) in enumerate(C) if L>>i&1 and x in U and y in V)
   samples.append((R,1/(1<<len(rows)+len(cols))))
 q=len(samples);mm=len(cand)
 rowsA=[];lo=[];hi=[]
 for i in range(mm):
  for j in range(i):
   if cand[i]&cand[j]==0: rowsA.append({i:1,j:1});lo.append(-np.inf);hi.append(1)
 for j,(R,w) in enumerate(samples):
  row={mm+j:1}
  for i,T in enumerate(cand):
   if T&~R==0:row[i]=-1
  rowsA.append(row);lo.append(-np.inf);hi.append(0)
 A=lil_matrix((len(rowsA),mm+q))
 for ri,row in enumerate(rowsA):
  for ci,v in row.items():A[ri,ci]=v
 obj=np.r_[np.zeros(mm),[-w for R,w in samples]]
 r=milp(obj,integrality=np.r_[np.ones(mm),np.zeros(q)],bounds=Bounds(np.zeros(mm+q),np.ones(mm+q)),constraints=LinearConstraint(A.tocsr(),np.array(lo),np.array(hi)),options={'time_limit':60,'mip_rel_gap':0})
 return -r.fun
if __name__=='__main__':
 n=4;random.seed(3)
 for tr in range(8):
  vals=list(range(16));random.shuffle(vals);X=vals[:8];Y=vals[8:];C,c=m.gen(X,Y,n,(X[0],Y[0]),4)
  if not c:continue
  print('cand',len(c), 'X',X,'Y',Y)
  for z in range(1<<(n+1)):
   if m.leaf(C,n,z):
    v=cond_opt(C,c,n,z)
    if v>0: print('z',z,'v',v)
