"""Parallel exact maximal-clique search for the N=5 mixed row-star slice.

Each maximal intersecting witness family is assigned to its smallest candidate
index.  Forked workers inherit the immutable event bitsets, so the expensive
sample table is built once and shared copy-on-write.
"""
from fractions import Fraction
from multiprocessing import get_context
import sys, time

from aekr_mixed_clique_fast import candidates, build_events

N, A, B = 5, 1, 2
D = C = EV = OFF = WID = WTS = ADJ = BM = M = None


def initialise():
    global D, C, EV, OFF, WID, WTS, ADJ, BM, M
    D, C = candidates(N, A, B)
    M = len(C)
    EV, OFF, WID, WTS = build_events(N, D, C)
    BM = [(1 << w) - 1 for w in WID]
    ADJ = [0] * M
    for i, (S, _) in enumerate(C):
        for j, (T, _) in enumerate(C):
            if i != j and S & T:
                ADJ[i] |= 1 << j


def value(mask):
    u = 0
    while mask:
        bit = mask & -mask
        i = bit.bit_length() - 1
        mask ^= bit
        u |= EV[i]
    ans = Fraction(0)
    for off, bm, wt in zip(OFF, BM, WTS):
        ans += wt * ((u >> off) & bm).bit_count()
    return ans


def worker(root_range):
    start, end = root_range
    best = Fraction(0)
    best_clique = []
    nodes = 0

    def bk(R, P, X):
        nonlocal best, best_clique, nodes
        nodes += 1
        if P == 0 and X == 0:
            v = value(R)
            if v > best:
                best = v
                best_clique = [i for i in range(M) if (R >> i) & 1]
            return
        U = P | X
        if U:
            pivot = -1
            score = -1
            bits = U
            while bits:
                bit = bits & -bits
                u = bit.bit_length() - 1
                bits ^= bit
                sc = (ADJ[u] & P).bit_count()
                if sc > score:
                    score, pivot = sc, u
            candbits = P & ~ADJ[pivot]
        else:
            candbits = P
        while candbits:
            bit = candbits & -candbits
            v = bit.bit_length() - 1
            candbits ^= bit
            bk(R | bit, P & ADJ[v], X & ADJ[v])
            P &= ~bit
            X |= bit

    # A clique is assigned to its least-indexed member.  Smaller candidates
    # are excluded from its branch; standard X bookkeeping removes duplicates.
    for root in range(start, end):
        bit = 1 << root
        bk(bit, ADJ[root] & ~((1 << (root + 1)) - 1), 0)
    return best, best_clique, nodes, start, end


def main():
    t0 = time.time()
    initialise()
    workers = min(16, M)
    ranges = []
    step = (M + workers - 1) // workers
    for start in range(0, M, step):
        ranges.append((start, min(start + step, M)))
    print({"candidates": M, "sample_bits": sum(WID), "ranges": ranges}, flush=True)
    ctx = get_context("fork")
    best = Fraction(0)
    best_clique = []
    total_nodes = 0
    with ctx.Pool(processes=workers) as pool:
        for v, clique, nodes, start, end in pool.imap_unordered(worker, ranges):
            total_nodes += nodes
            print({"range": [start, end], "best": str(v), "nodes": nodes}, flush=True)
            if v > best:
                best, best_clique = v, clique
    print({"max_probability": str(best), "clique_size": len(best_clique),
           "nodes": total_nodes, "elapsed": round(time.time() - t0, 1),
           "clique": best_clique}, flush=True)
    for i in best_clique:
        print(i, C[i], flush=True)


if __name__ == "__main__":
    sys.path.insert(0, __file__.rsplit("/", 1)[0])
    main()
