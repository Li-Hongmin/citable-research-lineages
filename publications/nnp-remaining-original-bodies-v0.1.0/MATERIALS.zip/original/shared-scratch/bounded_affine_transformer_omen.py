#!/usr/bin/env python3
"""Bounded-width affine source-grammar sanity check.

This is deliberately a little more general than a fixed DFAO: for a tested
height H the source state has w=ceil(log2(H+2)) bits, so there are
K=2**w=O(H) states.  The two child transitions are affine maps over F_2^w.

For every state q and dyadic height k, ``sig(q,k)`` is a canonical normal form
containing the source product rails, exact source-transformer multiple counts
(A,B), exact expanded ordinary-term counts (Wp,Wq), and source-leaf counts.
The parent operation is the right-first rail operation from Notes 710--714.
The script checks:

* semantic NF/Compose closure for all q and all k <= H;
* exact expanded-term materialization and recursive prefix/Select on small
  roots, including repeated factors in ordinary-ring monomial records;
* source-leaf generation and candidate-independence (b=0/1).

The materialized partner pairing is only a finite parity oracle.  The intended
address-scale Partner is the fixed local pairing schema inherited from the
product-rail identities; this script does not claim an actual C456 packet.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import defaultdict
from dataclasses import dataclass


def ceil_log2(x: int) -> int:
    return max(1, (x - 1).bit_length())


class AffineGrammar:
    """A width-w affine tree transducer and its source-aware signatures."""

    def __init__(self, max_k: int):
        self.max_k = max_k
        self.w = ceil_log2(max_k + 2)
        self.K = 1 << self.w
        # R is a cyclic rotation.  The 0-child is R(q), while the 1-child is
        # R(q)+e_0.  Both maps are affine and have O(w) circuit descriptions.
        self.mask = self.K - 1
        self.MEMO: dict[tuple[int, int], Sig] = {}

    def rotate(self, q: int) -> int:
        # R(q)_i = q_{i-1 mod w}; bit 0 receives the old top bit.
        return ((q << 1) | (q >> (self.w - 1))) & self.mask

    def inverse_rotate(self, q: int) -> int:
        # Inverse of rotate; this makes Compose recover the parent seam state
        # from the left child rather than receiving it as hidden advice.
        return ((q >> 1) | ((q & 1) << (self.w - 1))) & self.mask

    def delta(self, q: int, bit: int) -> int:
        return self.rotate(q) ^ (1 if bit else 0)

    def output(self, q: int) -> tuple[int, int]:
        # Along the all-zero suffix, d reads successive state bits, so all
        # 2**w states have distinct output continuations (not fixed-DFAO).
        d = q & 1
        e = (q >> (self.w - 1)) & 1
        return d, e

    def sig(self, q: int, k: int) -> "Sig":
        q &= self.mask
        key = (q, k)
        if key in self.MEMO:
            return self.MEMO[key]
        if k == 0:
            d, e = self.output(q)
            z = Sig(
                q=q,
                k=0,
                p=d,
                qrail=e,
                A=2,
                B=2,
                Wp=3 + d,
                Wq=3 + e,
                Dones=d,
                Eones=e,
            )
        else:
            L = self.sig(self.delta(q, 0), k - 1)
            R = self.sig(self.delta(q, 1), k - 1)
            z = Sig(
                q=q,
                k=k,
                p=L.p & R.p,
                qrail=(R.p & L.qrail) ^ R.qrail,
                A=1 + (L.A if R.p else 0) + R.A,
                B=1 + L.B + R.B + (R.A if L.qrail else 0),
                Wp=2 + (L.Wp if R.p else 0) + R.Wp,
                Wq=3 + L.Wq + R.Wq + (R.Wp if L.qrail else 0),
                Dones=L.Dones + R.Dones,
                Eones=L.Eones + R.Eones,
            )
        self.MEMO[key] = z
        return z

    def combine(self, L: "Sig", R: "Sig") -> "Sig":
        """right-first source-rail composition of two child signatures."""
        assert L.k == R.k
        return Sig(
            q=-1,
            k=L.k + 1,
            p=L.p & R.p,
            qrail=(R.p & L.qrail) ^ R.qrail,
            A=1 + (L.A if R.p else 0) + R.A,
            B=1 + L.B + R.B + (R.A if L.qrail else 0),
            Wp=2 + (L.Wp if R.p else 0) + R.Wp,
            Wq=3 + L.Wq + R.Wq + (R.Wp if L.qrail else 0),
            Dones=L.Dones + R.Dones,
            Eones=L.Eones + R.Eones,
        )


@dataclass(frozen=True)
class Sig:
    q: int
    k: int
    p: int
    qrail: int
    A: int
    B: int
    Wp: int
    Wq: int
    Dones: int
    Eones: int

    def semantic_fields(self):
        return (self.p, self.qrail, self.A, self.B, self.Wp, self.Wq,
                self.Dones, self.Eones)


@dataclass(frozen=True)
class Tok:
    kind: str
    role: str
    path: tuple[int, ...]
    state: int
    term: int
    ctx: tuple[tuple, ...]
    monomial: tuple[tuple, ...]

    @property
    def provenance(self):
        return (self.kind, self.role, self.path, self.state, self.term,
                self.ctx)


def factor(kind: str, path: tuple[int, ...], k: int) -> tuple:
    return (kind, path, k)


def add_context(ctx: tuple[tuple, ...], intrinsic: tuple[tuple, ...]) -> tuple[tuple, ...]:
    return tuple(sorted(ctx + intrinsic))


class Ledger:
    """Materialized expanded records for finite parity/prefix checks."""

    def __init__(self, G: AffineGrammar):
        self.G = G

    def _tok(self, kind, role, path, state, term, ctx, intrinsic):
        mon = add_context(ctx, tuple(intrinsic))
        return Tok(kind, role, path, state, term, ctx, mon)

    def p_terms(self, state: int, k: int, path=(), ctx=()):
        G = self.G
        node = factor("p", path, k)
        if k == 0:
            out = [self._tok("p", "up", path, state, 0, ctx, (node,)),
                   self._tok("p", "up", path, state, 1, ctx,
                              (("D", path),))]
            d, _ = G.output(state)
            out.append(self._tok("p", "srcD", path, state, 0, ctx,
                                 (("D", path),)))
            if d:
                out.append(self._tok("p", "srcD", path, state, 1, ctx, ()))
            return out

        Ls, Rs = G.delta(state, 0), G.delta(state, 1)
        L = G.sig(Ls, k - 1)
        R = G.sig(Rs, k - 1)
        half = 1 << (k - 1)
        left_path = path + (0,)
        right_path = path + (1,)
        out = [self._tok("p", "up", path, state, 0, ctx, (node,)),
               self._tok("p", "up", path, state, 1, ctx,
                          (factor("p", left_path, k - 1),
                           factor("p", right_path, k - 1)))]
        if R.p:
            out.extend(self.p_terms(Ls, k - 1, left_path, ctx))
        right_ctx = ctx + (factor("p", left_path, k - 1),)
        out.extend(self.p_terms(Rs, k - 1, right_path, right_ctx))
        assert len(out) == G.sig(state, k).Wp
        return out

    def q_terms(self, state: int, k: int, path=(), ctx=()):
        G = self.G
        node = factor("q", path, k)
        if k == 0:
            out = [self._tok("q", "uq", path, state, 0, ctx, (node,)),
                   self._tok("q", "uq", path, state, 1, ctx,
                              (("E", path),))]
            _, e = G.output(state)
            out.append(self._tok("q", "srcE", path, state, 0, ctx,
                                 (("E", path),)))
            if e:
                out.append(self._tok("q", "srcE", path, state, 1, ctx, ()))
            return out

        Ls, Rs = G.delta(state, 0), G.delta(state, 1)
        L = G.sig(Ls, k - 1)
        R = G.sig(Rs, k - 1)
        left_path = path + (0,)
        right_path = path + (1,)
        out = [self._tok("q", "uq", path, state, 0, ctx, (node,)),
               self._tok("q", "uq", path, state, 1, ctx,
                          (factor("p", right_path, k - 1),
                           factor("q", left_path, k - 1))),
               self._tok("q", "uq", path, state, 2, ctx,
                          (factor("q", right_path, k - 1),))]
        # q's left child is multiplied by p_R; the right child is unscaled.
        left_ctx = ctx + (factor("p", right_path, k - 1),)
        out.extend(self.q_terms(Ls, k - 1, left_path, left_ctx))
        out.extend(self.q_terms(Rs, k - 1, right_path, ctx))
        if L.qrail:
            # qbar_L is a scalar source bit, so no symbolic context is added.
            out.extend(self.p_terms(Rs, k - 1, right_path, ctx))
        assert len(out) == G.sig(state, k).Wq
        return out

    def source_leaves(self, state: int, k: int, path=()):
        G = self.G
        if k == 0:
            d, e = G.output(state)
            return [(path, state, d, e)]
        return (self.source_leaves(G.delta(state, 0), k - 1, path + (0,))
                + self.source_leaves(G.delta(state, 1), k - 1, path + (1,)))

    def parity_partner_check(self, state: int, k: int):
        G = self.G
        p = self.p_terms(state, k)
        q = self.q_terms(state, k)
        # Add the source-rail boundaries p+pbar and q+qbar.  A constant is
        # represented by the empty monomial, preserving ordinary (not Boolean)
        # multiplicity.
        sp = list(p)
        sq = list(q)
        rootp = factor("p", (), k)
        rootq = factor("q", (), k)
        S = G.sig(state, k)
        sp.append(self._tok("p", "boundary", (), state, 0, (), (rootp,)))
        if S.p:
            sp.append(self._tok("p", "boundary", (), state, 1, (), ()))
        sq.append(self._tok("q", "boundary", (), state, 0, (), (rootq,)))
        if S.qrail:
            sq.append(self._tok("q", "boundary", (), state, 1, (), ()))

        stats = {"terms": len(sp) + len(sq), "groups": 0,
                 "max_multiplicity": 0, "partner_checks": 0}
        for stream in (sp, sq):
            groups = defaultdict(list)
            for i, tok in enumerate(stream):
                groups[tok.monomial].append(i)
            for mon, ids in groups.items():
                if len(ids) & 1:
                    raise AssertionError(("odd ordinary record", state, k,
                                          mon, [stream[i].provenance for i in ids]))
                stats["groups"] += 1
                stats["max_multiplicity"] = max(stats["max_multiplicity"],
                                                 len(ids))
                for a, b in zip(ids[::2], ids[1::2]):
                    # Distinct provenance is necessary for a fixed-point-free
                    # pairing.  Pairing itself is a finite oracle here.
                    assert stream[a].provenance != stream[b].provenance
                    stats["partner_checks"] += 2
        return stats


def select_p(G: AffineGrammar, state: int, k: int, rank: int, path=(), ctx=()):
    if rank < 0:
        raise IndexError(rank)
    if k == 0:
        if rank < 2:
            node = factor("p", path, 0)
            intrinsic = (node,) if rank == 0 else (("D", path),)
            return Tok("p", "up", path, state, rank, ctx,
                       add_context(ctx, intrinsic))
        rank -= 2
        d, _ = G.output(state)
        if rank == 0:
            return Tok("p", "srcD", path, state, 0, ctx,
                       add_context(ctx, (("D", path),)))
        if d and rank == 1:
            return Tok("p", "srcD", path, state, 1, ctx,
                       add_context(ctx, ()))
        raise IndexError(rank)
    Ls, Rs = G.delta(state, 0), G.delta(state, 1)
    L, R = G.sig(Ls, k - 1), G.sig(Rs, k - 1)
    if rank < 2:
        node = factor("p", path, k)
        intrinsic = (node,) if rank == 0 else (
            factor("p", path + (0,), k - 1), factor("p", path + (1,), k - 1))
        return Tok("p", "up", path, state, rank, ctx,
                   add_context(ctx, intrinsic))
    rank -= 2
    if R.p:
        if rank < L.Wp:
            return select_p(G, Ls, k - 1, rank, path + (0,), ctx)
        rank -= L.Wp
    return select_p(G, Rs, k - 1, rank, path + (1,),
                    ctx + (factor("p", path + (0,), k - 1),))


def select_q(G: AffineGrammar, state: int, k: int, rank: int, path=(), ctx=()):
    if rank < 0:
        raise IndexError(rank)
    if k == 0:
        if rank < 2:
            node = factor("q", path, 0)
            intrinsic = (node,) if rank == 0 else (("E", path),)
            return Tok("q", "uq", path, state, rank, ctx,
                       add_context(ctx, intrinsic))
        rank -= 2
        _, e = G.output(state)
        if rank == 0:
            return Tok("q", "srcE", path, state, 0, ctx,
                       add_context(ctx, (("E", path),)))
        if e and rank == 1:
            return Tok("q", "srcE", path, state, 1, ctx,
                       add_context(ctx, ()))
        raise IndexError(rank)
    Ls, Rs = G.delta(state, 0), G.delta(state, 1)
    L, R = G.sig(Ls, k - 1), G.sig(Rs, k - 1)
    if rank < 3:
        node = factor("q", path, k)
        if rank == 0:
            intrinsic = (node,)
        elif rank == 1:
            intrinsic = (factor("p", path + (1,), k - 1),
                         factor("q", path + (0,), k - 1))
        else:
            intrinsic = (factor("q", path + (1,), k - 1),)
        return Tok("q", "uq", path, state, rank, ctx,
                   add_context(ctx, intrinsic))
    rank -= 3
    left_ctx = ctx + (factor("p", path + (1,), k - 1),)
    if rank < L.Wq:
        return select_q(G, Ls, k - 1, rank, path + (0,), left_ctx)
    rank -= L.Wq
    if rank < R.Wq:
        return select_q(G, Rs, k - 1, rank, path + (1,), ctx)
    rank -= R.Wq
    if L.qrail:
        return select_p(G, Rs, k - 1, rank, path + (1,), ctx)
    raise IndexError(rank)


def token_key(tok: Tok):
    return (tok.kind, tok.role, tok.path, tok.state, tok.term, tok.ctx,
            tok.monomial)


def run(max_k: int, materialize_k: int):
    G = AffineGrammar(max_k)
    L = Ledger(G)
    compose_checks = 0
    compose_recovery_checks = 0
    nf_checks = 0
    max_count_bits = 0
    max_code_bits = 0
    max_table_entries = 0

    # NF/Compose semantic homomorphism for every state and every tested level.
    for k in range(max_k + 1):
        for state in range(G.K):
            S = G.sig(state, k)
            assert S.q == state and S.k == k
            fields = S.semantic_fields()
            # Canonical code is just (w, state, k, root path); no child is
            # inlined.  A verifier recomputes fields from the fixed table.
            code_bits = G.w + max(1, k.bit_length()) + 2
            max_code_bits = max(max_code_bits, code_bits)
            nf_checks += 1
            max_count_bits = max(max_count_bits, *(x.bit_length() for x in fields))
            if k:
                left_state, right_state = G.delta(state, 0), G.delta(state, 1)
                # Canonical Compose is allowed to see only the two child
                # codes.  Recover q from the invertible left seam and verify
                # the right seam, then apply the right-first rail glue.
                recovered = G.inverse_rotate(left_state)
                assert recovered == state
                assert G.delta(recovered, 1) == right_state
                compose_recovery_checks += 1
                C = G.combine(G.sig(left_state, k - 1),
                              G.sig(right_state, k - 1))
                assert C.semantic_fields() == fields, (state, k, C, S)
                compose_checks += 1
        max_table_entries = max(max_table_entries, G.K * (k + 1))

    # Materialized expanded ledgers, recursive Select, prefix/rank inverse,
    # and ordinary-ring parity for every state at small heights.
    materialized_cases = 0
    total_materialized_terms = 0
    max_multiplicity = 0
    prefix_checks = 0
    for k in range(min(max_k, materialize_k) + 1):
        for state in range(G.K):
            S = G.sig(state, k)
            p = L.p_terms(state, k)
            q = L.q_terms(state, k)
            assert len(p) == S.Wp and len(q) == S.Wq
            for kind, stream, total, selector in (
                ("p", p, S.Wp, select_p), ("q", q, S.Wq, select_q)):
                for r, expected in enumerate(stream):
                    got = selector(G, state, k, r)
                    assert token_key(got) == token_key(expected), (
                        kind, state, k, r, got, expected)
                    # The cumulative expanded prefix before this occurrence
                    # is exactly r; recursion reaches it using child W fields.
                    assert r < total
                    prefix_checks += 1
            partner = L.parity_partner_check(state, k)
            max_multiplicity = max(max_multiplicity,
                                   partner["max_multiplicity"])
            total_materialized_terms += len(p) + len(q)
            materialized_cases += 1

    # Source-leaf generator/ledger is a separate candidate-independent stream.
    source_checks = 0
    max_source_leaves = 0
    for k in range(min(max_k, materialize_k) + 1):
        for state in range(G.K):
            leaves = L.source_leaves(state, k)
            assert len(leaves) == 1 << k
            S = G.sig(state, k)
            assert sum(x[2] for x in leaves) == S.Dones
            assert sum(x[3] for x in leaves) == S.Eones
            # Candidate b is not an input to delta/output/signature.  Explicit
            # b=0 and b=1 projections are equal for every source leaf.
            for path, q, d, e in leaves:
                assert (d, e) == G.output(q)
                source_checks += 1
            max_source_leaves = max(max_source_leaves, len(leaves))

    return {
        "host": "omen",
        "family": "width-w affine tree transducer",
        "max_k": max_k,
        "materialize_k": materialize_k,
        "state_width_w": G.w,
        "state_count_K": G.K,
        "state_count_bound": "K=2^w <= 2(H+2), hence poly(H)=poly(log N)",
        "transition_description": "rotate(q) xor (bit*e_0), affine over F2^w",
        "output": "Dbar=q_0, Ebar=q_{w-1}",
        "nf_checks": nf_checks,
        "compose_checks": compose_checks,
        "compose_recovery_checks": compose_recovery_checks,
        "materialized_cases": materialized_cases,
        "materialized_terms": total_materialized_terms,
        "prefix_select_checks": prefix_checks,
        "source_leaf_checks": source_checks,
        "max_source_leaves": max_source_leaves,
        "max_count_bits": max_count_bits,
        "max_code_bits": max_code_bits,
        "max_table_entries": max_table_entries,
        "max_partner_bucket_multiplicity": max_multiplicity,
        "failures": 0,
        "candidate_independence": "PASS (source generator ignores b; b=0,1 projections equal)",
        "semantic_closure": "PASS on all states/levels tested; parent code does not inline children",
        "ordinary_partner_check": "PASS finite monomial-parity oracle; address-scale local Partner still requires explicit packet schema",
        "scope": "abstract bounded-width affine/source grammar; not actual C456",
        "route_decision": {
            "generalized_algebra": "CONDITIONAL_PASS",
            "actual_C456_Gate_0_R": "UNKNOWN_PAUSE",
            "C596_or_P_ne_NP": "NOT_ESTABLISHED",
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-k", type=int, default=12)
    parser.add_argument("--materialize-k", type=int, default=8)
    args = parser.parse_args()
    if args.max_k < 0 or args.materialize_k < 0:
        raise SystemExit("heights must be nonnegative")
    payload = run(args.max_k, args.materialize_k)
    src = open(__file__, "rb").read()
    payload["source_sha256"] = hashlib.sha256(src).hexdigest()
    print(json.dumps(payload, sort_keys=True))


if __name__ == "__main__":
    main()
