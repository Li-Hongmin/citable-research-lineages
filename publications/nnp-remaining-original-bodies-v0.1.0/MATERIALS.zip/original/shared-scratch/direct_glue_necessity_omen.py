#!/usr/bin/env python3
"""Finite ordinary-ring checks for the direct-glue same-(G,a) boundary.

The test treats every monomial as an ordered/repeated-address record (after
sorting its variable names for a canonical record key), with no Boolean
quotient reduction.  It checks two notions separately:

1. pairwise direct gluing: the two occurrences at each seam must cancel as one
   ordinary-ring polynomial, with no extra seam equation/port;
2. aggregate chain cancellation: only the sum of all internal seam residuals
   is required to vanish.  This weaker notion can cancel demand constants from
   different seams and is not the port-by-port gluing contract.

This is a finite sanity check only; it does not instantiate C456.
"""

from __future__ import annotations

import json
from itertools import combinations_with_replacement, product


Mon = tuple[str, ...]
Poly = frozenset[Mon]  # GF(2), one bit per ordinary monomial record


def canon(mon: tuple[str, ...]) -> Mon:
    return tuple(sorted(mon))


def xor(*polys: Poly) -> Poly:
    out: set[Mon] = set()
    for p in polys:
        out ^= set(p)
    return frozenset(out)


def monomial_pool(names: list[str], max_degree: int) -> list[Mon]:
    out: list[Mon] = [()]
    for d in range(1, max_degree + 1):
        out.extend(canon(x) for x in combinations_with_replacement(names, d))
    # Keep a deterministic order and remove accidental duplicates.
    return list(dict.fromkeys(out))


def seam(left: Mon, right: Mon, z: str, a: int, b: int) -> Poly:
    """left*(z+a)+right*(z+b), in the ordinary polynomial ring."""
    out: set[Mon] = set()
    # Toggle rather than insert into a set literal: equal records represent
    # two GF(2) occurrences and must cancel.
    for mon in (canon(left + (z,)), canon(right + (z,))):
        if mon in out:
            out.remove(mon)
        else:
            out.add(mon)
    for mon, active in ((left, a), (right, b)):
        if active:
            if mon in out:
                out.remove(mon)
            else:
                out.add(mon)
    return frozenset(out)


def eval_poly(p: Poly, assignment: dict[str, int]) -> int:
    value = 0
    for mon in p:
        bit = 1
        for var in mon:
            bit &= assignment[var]
        value ^= bit
    return value


def bool_zero(p: Poly) -> tuple[bool, dict[str, int] | None]:
    names = sorted({v for mon in p for v in mon})
    for bits in product((0, 1), repeat=len(names)):
        assn = dict(zip(names, bits))
        if eval_poly(p, assn):
            return False, assn
    return True, None


def pairwise_check(pool: list[Mon], z: str) -> dict:
    total = zero = zero_mismatch = bool_zero_nonzero = 0
    witness_nonzero: dict | None = None
    witness_boolean: dict | None = None
    for left in pool:
        for right in pool:
            for a, b in product((0, 1), repeat=2):
                total += 1
                p = seam(left, right, z, a, b)
                same = left == right and a == b
                if not p:
                    zero += 1
                    if not same:
                        zero_mismatch += 1
                bz, assn = bool_zero(p)
                if bz and p:
                    bool_zero_nonzero += 1
                    if witness_boolean is None:
                        witness_boolean = {
                            "left": left,
                            "right": right,
                            "a": a,
                            "b": b,
                            "ordinary_terms": sorted(p),
                        }
                if p and witness_nonzero is None and same:
                    witness_nonzero = {
                        "left": left,
                        "right": right,
                        "a": a,
                        "b": b,
                        "ordinary_terms": sorted(p),
                        "boolean_witness": assn,
                    }
    return {
        "pool_size": len(pool),
        "total": total,
        "ordinary_zero": zero,
        "ordinary_zero_mismatch": zero_mismatch,
        "boolean_zero_but_ordinary_nonzero": bool_zero_nonzero,
        "witness_nonzero_same_pair": witness_nonzero,
        "witness_boolean_quotient_only": witness_boolean,
    }


def chain_internal_residual(gs: tuple[Mon, ...], aa: tuple[int, ...]) -> Poly:
    """Sum seam residuals after w_t is identified with z_{t+1}."""
    out: Poly = frozenset()
    for s in range(1, len(gs)):
        out = xor(out, seam(gs[s - 1], gs[s], f"z{s}", aa[s - 1], aa[s]))
    return out


def aggregate_check(pool: list[Mon], r: int) -> dict:
    # Exhaustive for r=2,3,4 with the small external pool; r=4 is only
    # 11^4*16 = 234,256 cases for the pool used below.
    total = zero = mismatch = pairwise_zero_but_global_zero = 0
    witness: dict | None = None
    for gs in product(pool, repeat=r):
        for aa in product((0, 1), repeat=r):
            total += 1
            same = all(gs[t] == gs[0] and aa[t] == aa[0] for t in range(r))
            pairwise = all(
                not seam(gs[s - 1], gs[s], f"z{s}", aa[s - 1], aa[s])
                for s in range(1, r)
            )
            residual = chain_internal_residual(gs, aa)
            if not residual:
                zero += 1
                if not same:
                    mismatch += 1
                    if witness is None:
                        witness = {
                            "G": gs,
                            "a": aa,
                            "pairwise_seams_zero": pairwise,
                            "internal_residual_terms": [],
                        }
            if not pairwise and not residual:
                pairwise_zero_but_global_zero += 1
    return {
        "r": r,
        "pool_size": len(pool),
        "total": total,
        "aggregate_ordinary_zero": zero,
        "aggregate_zero_mismatch": mismatch,
        "aggregate_zero_with_nonzero_seam": pairwise_zero_but_global_zero,
        "witness_aggregate_but_not_pairwise": witness,
    }


def sparse_polynomial_counterexample() -> dict:
    """A boundary witness if G is allowed to be a polynomial containing z."""
    # A=z+1, B=z, a=0, b=1: A*z + B*(z+1) = 0 in the ordinary ring.
    z = "z1"
    A = frozenset({(z,), ()})
    B = frozenset({(z,)})
    p = xor(
        frozenset(canon(m + (z,)) for m in A),
        frozenset(canon(m + (z,)) for m in B) | B,
    )
    assert not p
    return {
        "A": sorted(A),
        "B": sorted(B),
        "a": 0,
        "b": 1,
        "ordinary_residual_terms": [],
        "scope": "outside nonzero-monomial outer-G contract; G may contain seam z and two terms",
    }


def main() -> None:
    # Outer multipliers use external variables only, as in the port contract.
    ext_pool = monomial_pool(["u0", "u1", "u2"], max_degree=2)
    # Pairwise test also allows z in a monomial, strengthening the monomial
    # claim beyond the usual outer-disjoint assumption.
    monomial_with_z = monomial_pool(["u0", "u1", "z1"], max_degree=2)
    pair_ext = pairwise_check(ext_pool, "z1")
    pair_with_z = pairwise_check(monomial_with_z, "z1")

    aggregates = [aggregate_check(ext_pool[:6], r) for r in (2, 3, 4)]
    out = {
        "host": "omen",
        "ordinary_ring": "GF(2)[variables], repeated monomial records retained; no Boolean quotient",
        "pairwise_contract": pair_ext,
        "pairwise_monomials_allowing_seam_variable": pair_with_z,
        "aggregate_chain": aggregates,
        "sparse_polynomial_boundary_witness": sparse_polynomial_counterexample(),
        "scope": {
            "pairwise": "all nonzero monomial G in enumerated pools and all a,b; direct port cancellation at one seam",
            "aggregate": "all G-tuples and demand tuples for r=2,3,4 over six external monomials",
            "not_actual_C456": True,
        },
    }
    print(json.dumps(out, sort_keys=True))


if __name__ == "__main__":
    main()
