#!/usr/bin/env python3
"""Omen finite-kernel check for periodic source valuations.

The experiment tests only the conditional easy subfamily in which the source
bits (Dbar_t,Ebar_t) are periodic.  It does not claim that C456 valuations are
periodic or that a C596 certificate exists.
"""

from itertools import product


def full_summary(d, e):
    """(pbar,qbar,A,B) for a power-of-two interval."""
    p, q = list(d), list(e)
    A = [2] * len(p)
    B = [2] * len(p)
    while len(p) > 1:
        pn, qn, An, Bn = [], [], [], []
        for i in range(0, len(p), 2):
            pn.append(p[i] & p[i + 1])
            qn.append((p[i + 1] & q[i]) ^ q[i + 1])
            An.append(1 + (A[i] if p[i + 1] else 0) + A[i + 1])
            Bn.append(1 + B[i] + B[i + 1] + (A[i + 1] if q[i] else 0))
        p, q, A, B = pn, qn, An, Bn
    return p[0], q[0], A[0], B[0]


def periodic_query(period_d, period_e, a, k, memo):
    """Address-scale summary recurrence keyed only by (a mod r,k)."""
    r = len(period_d)
    key = (a % r, k)
    if key in memo:
        return memo[key]
    if k == 0:
        value = (period_d[a % r], period_e[a % r], 2, 2)
    else:
        h = 1 << (k - 1)
        L = periodic_query(period_d, period_e, a, k - 1, memo)
        R = periodic_query(period_d, period_e, a + h, k - 1, memo)
        pL, qL, AL, BL = L
        pR, qR, AR, BR = R
        value = (pL & pR, (pR & qL) ^ qR,
                 1 + (AL if pR else 0) + AR,
                 1 + BL + BR + (AR if qL else 0))
    memo[key] = value
    return value


def check_pattern(pd, pe, max_h=10):
    r = len(pd)
    memo = {}
    for h in range(max_h + 1):
        T = 1 << h
        d = [pd[t % r] for t in range(T)]
        e = [pe[t % r] for t in range(T)]
        assert full_summary(d, e) == periodic_query(pd, pe, 0, h, memo)
        for k in range(h + 1):
            span = 1 << k
            for a in range(0, T, span):
                got = periodic_query(pd, pe, a, k, memo)
                want = full_summary(d[a:a + span], e[a:a + span])
                assert got == want, (pd, pe, a, k, got, want)
    # The root counts are not determined by (pbar,qbar) alone; retain the
    # summary pair and verify all components are deterministic for this stream.
    return memo


def main():
    patterns = []
    for r in (1, 2, 3, 4):
        # Keep the finite test small but cover every periodic pair for r<=2 and
        # a deterministic sample of longer periods.
        if r <= 2:
            patterns.extend(product(product((0, 1), repeat=r), repeat=2))
        else:
            patterns.extend([
                ((0,) * r, (0,) * r),
                ((1,) * r, (0,) * r),
                (tuple(t & 1 for t in range(r)), tuple((t >> 1) & 1 for t in range(r))),
            ])
    checked = 0
    max_bits = 0
    for pd, pe in patterns:
        memo = check_pattern(pd, pe)
        checked += 1
        for p, q, A, B in memo.values():
            max_bits = max(max_bits, A.bit_length(), B.bit_length())
    print({"host": "omen", "patterns": checked, "max_h": 10,
           "summary_states_checked": sum(len(check_pattern(pd, pe)) for pd, pe in patterns),
           "max_count_bits": max_bits, "failures": 0})


if __name__ == "__main__":
    main()
