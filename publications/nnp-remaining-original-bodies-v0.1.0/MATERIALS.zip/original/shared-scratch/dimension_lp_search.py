from itertools import combinations
from pathlib import Path
import random, subprocess, re, tempfile


def rank(vs, n):
    rows = [v for v in vs if v]
    r = 0
    for b in range(n - 1, -1, -1):
        piv = next((i for i in range(r, len(rows)) if (rows[i] >> b) & 1), None)
        if piv is None:
            continue
        rows[r], rows[piv] = rows[piv], rows[r]
        for i in range(len(rows)):
            if i != r and ((rows[i] >> b) & 1):
                rows[i] ^= rows[r]
        r += 1
    return r


def adim(S, n):
    x0 = next(iter(S))
    return rank([x ^ x0 for x in S], n)


def split_subsets(mask):
    # unordered is enough because both sides are included symmetrically.
    sub = (mask - 1) & mask
    out = []
    while sub:
        other = mask ^ sub
        if other and sub < other:
            out.append((sub, other))
        sub = (sub - 1) & mask
    return out


def parity_mono(A, B, n):
    # Exists affine parity ell with ell=0 on A and ell=1 on B.
    # A linear form r must annihilate differences in A and B; then fix c.
    a0 = next(iter(A)); b0 = next(iter(B))
    diffs = [x ^ a0 for x in A] + [y ^ b0 for y in B]
    for r in range(1, 1 << n):
        if any((r & d).bit_count() % 2 for d in diffs):
            continue
        if ((r & a0).bit_count() ^ (r & b0).bit_count()) & 1:
            return True
    return False


def solve(X, Y, n, tag):
    xs = sorted(X); ys = sorted(Y)
    xm = {x:i for i,x in enumerate(xs)}; ym = {y:i for i,y in enumerate(ys)}
    m = len(xs) * len(ys)
    subsets_x = [s for s in range(1, 1 << len(xs))]
    subsets_y = [s for s in range(1, 1 << len(ys))]
    dims_x = {s: adim({xs[i] for i in range(len(xs)) if (s>>i)&1}, n) for s in subsets_x}
    dims_y = {s: adim({ys[j] for j in range(len(ys)) if (s>>j)&1}, n) for s in subsets_y}
    hs = [(p,q) for p in range(n+1) for q in range(n+1)]
    names = {'a':'alpha'}
    for p,q in hs: names[(p,q)] = f'h_{p}_{q}'
    rows = []
    # each row is dict var->coef, sense rhs, name
    def K(maskx, masky):
        p,q = dims_x[maskx], dims_y[masky]
        return (m - maskx.bit_count()*masky.bit_count(), (p,q))
    # leaf constraints alpha |A||B| + K <= 1 for monochromatic rectangles
    for ax in subsets_x:
        A={xs[i] for i in range(len(xs)) if (ax>>i)&1}
        for by in subsets_y:
            B={ys[j] for j in range(len(ys)) if (by>>j)&1}
            if parity_mono(A,B,n) or parity_mono(B,A,n):
                coef={'a': ax.bit_count()*by.bit_count()}
                k,var=K(ax,by); coef[var]=coef.get(var,0)+k
                rows.append((coef,'<=',1))
    # recursion all row and column splits.
    for ax in subsets_x:
        for by in subsets_y:
            k0,v0=K(ax,by)
            for a1,a2 in split_subsets(ax):
                k1,v1=K(a1,by); k2,v2=K(a2,by)
                # merge duplicate vars
                cc={}
                for v,c in [(v0,-k0),(v1,k1),(v2,k2)]: cc[v]=cc.get(v,0)+c
                rows.append((cc,'>=',0))
            for b1,b2 in split_subsets(by):
                k1,v1=K(ax,b1); k2,v2=K(ax,b2)
                cc={}
                for v,c in [(v0,-k0),(v1,k1),(v2,k2)]: cc[v]=cc.get(v,0)+c
                rows.append((cc,'>=',0))
    with tempfile.TemporaryDirectory() as td:
        lp=Path(td)/'a.lp'; sol=Path(td)/'a.sol'
        lines=['Maximize',' obj: alpha','Subject To']
        for i,(coef,sense,rhs) in enumerate(rows):
            terms=[]
            for v,c in coef.items():
                if not c: continue
                sign='+' if c>0 else '-'; a=abs(c)
                terms.append(f' {sign} {a} {names[v]}')
            expr=''.join(terms).lstrip()
            if expr.startswith('+ '): expr=expr[2:]
            lines.append(f' c{i}: {expr} {sense} {rhs}')
        lines += ['Bounds']
        for v in names.values(): lines.append(f' {v} free')
        lines += ['End','']
        lp.write_text('\n'.join(lines))
        p=subprocess.run(['glpsol','--lp',str(lp),'-o',str(sol)],capture_output=True,text=True)
        txt=p.stdout+p.stderr
        stxt=sol.read_text() if sol.exists() else ''
        mat=re.search(r'Objective:\s+[^=]+\s*=\s*([-+0-9.eE]+)',stxt)
        obj=float(mat.group(1)) if mat else None
        print(tag, 'sizes',len(xs),len(ys),'rows',len(rows),'obj_alpha',obj,'obj_m',None if obj is None else obj*m,'status',p.returncode)
        if obj is None:
            print(txt[-2000:])


if __name__=='__main__':
    solve({0},{1,2,3},2,'N2')
    solve({0,1},{2,3},2,'N2half')
    solve({0,1,2,3},{4,5,6,7},3,'N3half')
    solve({3,5,6,7},{0,1,2,4},3,'Maj3')
    rng=random.Random(0)
    for t in range(4):
        U=list(range(16)); rng.shuffle(U)
        solve(set(U[:6]),set(U[6:12]),4,f'N4r{t}')
