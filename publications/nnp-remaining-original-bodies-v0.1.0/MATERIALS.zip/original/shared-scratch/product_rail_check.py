from itertools import product


def leaf_ok(v):
    y0, y1, p, q, d, e = v
    f = y1 ^ (p & y0) ^ q
    eq = y1 ^ (d & y0) ^ e
    up = p ^ d
    uq = q ^ e
    return f ^ eq ^ (y0 & up) ^ uq == 0


def parent_ok(v):
    ya, ym, ye, p_l, p_r, q_l, q_r, p_p, q_p = v
    f_p = ye ^ (p_p & ya) ^ q_p
    f_r = ye ^ (p_r & ym) ^ q_r
    f_l = ym ^ (p_l & ya) ^ q_l
    up = p_p ^ (p_l & p_r)
    uq = q_p ^ (p_r & q_l) ^ q_r
    return f_p ^ f_r ^ (p_r & f_l) ^ (ya & up) ^ uq == 0


for v in product((0, 1), repeat=6):
    assert leaf_ok(v), v
for v in product((0, 1), repeat=9):
    assert parent_ok(v), v


def leaves(h):
    if h == 0:
        return {0: ()}
    left = leaves(h - 1)
    right = leaves(h - 1)
    out = {i + 2 ** (h - 1): m for i, m in right.items()}
    out.update({i: ("p_R",) + m for i, m in left.items()})
    return out


for h in range(11):
    coeff = leaves(h)
    assert len(coeff) == 2 ** h
    assert max((len(m) for m in coeff.values()), default=0) == h


def source_cap(h):
    # Recursively represent p_{0,h}+1 as a formal sum of rail equations
    # and leaf source equations.  A term is (coefficient degree, label).
    # The recurrence itself is what is being checked; degree is tracked only.
    if h == 0:
        return 1  # p+1 from (p+Y)+(Y+1)
    left = source_cap(h - 1)
    right = source_cap(h - 1)
    # pP+1 = uP + pR*(pL+1) + (pR+1), so degree grows by one on left.
    return max(left + 1, right)


for h in range(11):
    assert source_cap(h) == h + 1


# Random full-tree evaluation of the source-cap recurrence as an ordinary
# polynomial identity.  The leaf/parent checks above are exhaustive; this
# additionally checks the recursively assembled endpoint formula.
import random


def source_cap_value(h, p, d, u):
    if h == 0:
        return u[(0, 0, "p")] ^ (d[0] ^ 1)
    half = 2 ** (h - 1)
    left = source_cap_value(h - 1, p, d, u)
    # right subtree is translated by half; evaluate with a translated view.
    right = source_cap_value_translated(h - 1, half, p, d, u)
    return u[(0, h, "p")] ^ (p[(half, h - 1)] & left) ^ right


def source_cap_value_translated(h, a, p, d, u):
    if h == 0:
        return u[(a, 0, "p")] ^ (d[a] ^ 1)
    half = 2 ** (h - 1)
    left = source_cap_value_translated(h - 1, a, p, d, u)
    right = source_cap_value_translated(h - 1, a + half, p, d, u)
    return u[(a, h, "p")] ^ (p[(a + half, h - 1)] & left) ^ right


for h in range(1, 7):
    T = 2 ** h
    for _ in range(200):
        p = {}
        d = {a: random.randrange(2) for a in range(T)}
        u = {}
        # independent rail variables; define each rail equation value from them
        for a in range(T):
            p[(a, 0)] = random.randrange(2)
            u[(a, 0, "p")] = p[(a, 0)] ^ d[a]
        for k in range(1, h + 1):
            for a in range(0, T, 2 ** k):
                half = 2 ** (k - 1)
                p[(a, k)] = random.randrange(2)
                u[(a, k, "p")] = p[(a, k)] ^ (p[(a, k - 1)] & p[(a + half, k - 1)])
        assert source_cap_value_translated(h, 0, p, d, u) == (p[(0, h)] ^ 1)


print("leaf exhaustive=PASS")
print("parent exhaustive=PASS")
print("dyadic multiplier degree h for h=0..10=PASS")
print("source-cap degree h+1 for h=0..10=PASS")
print("recursive source-cap polynomial checks h=1..6: PASS")
