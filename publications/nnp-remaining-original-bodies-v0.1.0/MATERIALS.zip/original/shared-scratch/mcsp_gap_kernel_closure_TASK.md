# Task

Adversarially test the proposed closure: fixed `S=2^(mu_H n)`, target
`T=2^(mu_1 n')`, `n'=kappa n+O(1)`, `mu_H>kappa mu_1`; affine quotient
`Q` is YES-preserving and its kernel K satisfies `w(K)<=B<=(1-delta)S`.
Using Chow semantic growth, does source residual entropy force a contradiction?
Determine exact delta/gap-ratio range, whether F<=|K|<=|L_B| is sufficient,
and whether the conclusion closes the Proposition 4 junta escape or only a subclass.
Stop at theorem, counterexample, or exact missing hypothesis. No permanent edits/Git.
