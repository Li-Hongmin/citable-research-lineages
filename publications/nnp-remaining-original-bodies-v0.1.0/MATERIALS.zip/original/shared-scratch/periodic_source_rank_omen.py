#!/usr/bin/env python3
"""Finite Rank/Select check for the periodic witnessed source transformer.

This is a deliberately finite positive subcase of Notes 711--712.  It expands
the source-transformer derivation tree (one rail multiple plus one source-leaf
multiple at every leaf) and compares it with the phase/height summary table.
No actual C456 orbit is assumed, and no generic binary lifting is used.
"""

from __future__ import annotations

import json
from itertools import product


def summary(pd, pe, a, k, memo):
    """Return (p, q, A, B) for a dyadic interval at periodic phase a."""
    r = len(pd)
    key = (a % r, k)
    if key in memo:
        return memo[key]
    if k == 0:
        value = (pd[a % r], pe[a % r], 2, 2)
    else:
        half = 1 << (k - 1)
        p_l, q_l, a_l, b_l = summary(pd, pe, a, k - 1, memo)
        p_r, q_r, a_r, b_r = summary(pd, pe, a + half, k - 1, memo)
        value = (
            p_l & p_r,
            (p_r & q_l) ^ q_r,
            1 + (a_l if p_r else 0) + a_r,
            1 + b_l + b_r + (a_r if q_l else 0),
        )
    memo[key] = value
    return value


def flatten(pd, pe, kind, a, k, path=(), memo=None):
    """Explicit tagged occurrence list for one S^p or S^q derivation."""
    if memo is None:
        memo = {}
    if k == 0:
        # The first slot is the local rail equation; the second is the source
        # leaf witness.  A/B leaf counts are both 2.
        return [
            (kind, a, k, "rail", path),
            (kind, a, k, "source", path),
        ]
    half = 1 << (k - 1)
    p_l, q_l, _, _ = summary(pd, pe, a, k - 1, memo)
    p_r, q_r, _, _ = summary(pd, pe, a + half, k - 1, memo)
    out = [(kind, a, k, "rail", path)]
    if kind == "A":
        if p_r:
            out += flatten(pd, pe, "A", a, k - 1, path + (0,), memo)
        out += flatten(pd, pe, "A", a + half, k - 1, path + (1,), memo)
    else:
        out += flatten(pd, pe, "B", a, k - 1, path + (0,), memo)
        out += flatten(pd, pe, "B", a + half, k - 1, path + (1,), memo)
        if q_l:
            out += flatten(pd, pe, "A", a + half, k - 1, path + (2,), memo)
    return out


def unrank(pd, pe, kind, a, k, s, path=(), memo=None):
    """Summary-table Rank/Select decoder for one derivation tree."""
    if memo is None:
        memo = {}
    p_l, q_l, a_l, b_l = summary(pd, pe, a, k - 1, memo) if k else (0, 0, 0, 0)
    if k == 0:
        if s == 0:
            return (kind, a, k, "rail", path)
        if s == 1:
            return (kind, a, k, "source", path)
        raise IndexError(s)

    half = 1 << (k - 1)
    p_r, q_r, a_r, b_r = summary(pd, pe, a + half, k - 1, memo)
    if s == 0:
        return (kind, a, k, "rail", path)
    s -= 1
    if kind == "A":
        if p_r:
            if s < a_l:
                return unrank(pd, pe, "A", a, k - 1, s, path + (0,), memo)
            s -= a_l
        if s < a_r:
            return unrank(pd, pe, "A", a + half, k - 1, s, path + (1,), memo)
    else:
        if s < b_l:
            return unrank(pd, pe, "B", a, k - 1, s, path + (0,), memo)
        s -= b_l
        if s < b_r:
            return unrank(pd, pe, "B", a + half, k - 1, s, path + (1,), memo)
        s -= b_r
        if q_l and s < a_r:
            return unrank(pd, pe, "A", a + half, k - 1, s, path + (2,), memo)
    raise IndexError((kind, a, k, s))


def check_pattern(pd, pe, max_h=8):
    memo = {}
    checks = 0
    max_slots = 0
    for h in range(max_h + 1):
        T = 1 << h
        for k in range(h + 1):
            span = 1 << k
            for a in range(0, T, span):
                p, q, A, B = summary(pd, pe, a, k, memo)
                got_a = flatten(pd, pe, "A", a, k, memo=memo)
                got_b = flatten(pd, pe, "B", a, k, memo=memo)
                assert (p, q, len(got_a), len(got_b)) == (p, q, A, B)
                flat = got_a + got_b
                for s, expected in enumerate(flat):
                    # The full source transformer concatenates S^p then S^q.
                    if s < A:
                        got = unrank(pd, pe, "A", a, k, s, (), memo)
                    else:
                        got = unrank(pd, pe, "B", a, k, s - A, (), memo)
                    assert got == expected, (pd, pe, a, k, s, got, expected)
                    checks += 1
                # Rank/Select are inverse for each stream, not only at root.
                for stream_kind, stream in (("A", got_a), ("B", got_b)):
                    for s, expected in enumerate(stream):
                        assert unrank(pd, pe, stream_kind, a, k, s, (), memo) == expected
                max_slots = max(max_slots, len(flat))
    return checks, len(memo), max_slots


def main():
    patterns = []
    for r in (1, 2, 3, 4):
        if r <= 2:
            patterns.extend(product(product((0, 1), repeat=r), repeat=2))
        else:
            patterns.extend(
                [
                    ((0,) * r, (0,) * r),
                    ((1,) * r, (0,) * r),
                    (tuple(t & 1 for t in range(r)), tuple((t >> 1) & 1 for t in range(r))),
                ]
            )
    total_checks = total_states = 0
    max_slots = 0
    for pd, pe in patterns:
        checks, states, slots = check_pattern(pd, pe)
        total_checks += checks
        total_states += states
        max_slots = max(max_slots, slots)
    print(
        json.dumps(
            {
                "host": "omen",
                "patterns": len(patterns),
                "max_h": 8,
                "rank_select_checks": total_checks,
                "summary_states": total_states,
                "max_flat_slots": max_slots,
                "failures": 0,
                "scope": "periodic witnessed source-transformer; actual C456 uninstantiated",
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
