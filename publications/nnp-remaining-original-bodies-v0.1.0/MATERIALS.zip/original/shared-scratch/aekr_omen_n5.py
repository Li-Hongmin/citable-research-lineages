import sys
sys.path.insert(0, "/tmp")
from exhaustive_mixed_clique import solve

if __name__ == "__main__":
    N, a, b = 5, 1, 2
    best, clique, m, nodes = solve(N, a, b)
    print({"N": N, "a": a, "b": b, "candidates": m,
           "max_probability": str(best), "clique_size": len(clique),
           "nodes": nodes}, flush=True)
    if best > 1/4:
        sys.exit(2)
