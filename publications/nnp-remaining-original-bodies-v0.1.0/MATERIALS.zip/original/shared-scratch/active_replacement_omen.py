#!/usr/bin/env python3
"""Finite GF(2) checks for the physical mux and active replacement leaves.

This is a sanity check for Notes 638/681/709 only.  It does not instantiate
an actual C456 orbit or prove a global C596 certificate.
"""

from itertools import product


def mux_residual(schedule, a, Yp, Y, H, Z):
    # e_H = H + schedule.  Use the schedule-specific endpoint port.
    e = H ^ schedule
    q = Yp ^ Y ^ (H & Y) ^ (H & Z)
    # The target port is always Y'; the incoming port is Y off-head and Z
    # on-head, exactly as in Note 639.4.
    incoming = (Y ^ a) if schedule == 0 else (Z ^ a)
    return (Yp ^ a) ^ incoming ^ q ^ (Y & e) ^ (Z & e)


def replacement_residual(a, z, wc, sigma, J, what, G=1):
    # Note 709.3--709.4, over GF(2), with G a Boolean multiplier bit.
    q = z ^ sigma ^ (J & sigma) ^ (J & wc)
    gw = wc ^ sigma ^ (J & sigma) ^ (J & what)
    bj = J ^ (J & J)
    return G & ((z ^ a) ^ (wc ^ a) ^ q ^ (J & gw) ^ gw
                 ^ (sigma & bj) ^ (what & bj))


def raw_output_residual(a, z, wc, sigma, J, what, G=1):
    # Difference in (709.6): G*(J+1)*(sigma+what).
    return G & ((J ^ 1) & (sigma ^ what))


def main():
    for schedule in (0, 1):
        cases = 0
        for a, Yp, Y, H, Z in product((0, 1), repeat=5):
            assert mux_residual(schedule, a, Yp, Y, H, Z) == 0
            cases += 1
        print({"family": "physical_mux", "schedule": schedule,
               "cases": cases, "failures": 0})

    cases = 0
    for a, z, wc, sigma, J, what in product((0, 1), repeat=6):
        assert replacement_residual(a, z, wc, sigma, J, what) == 0
        cases += 1
    print({"family": "canonical_write_replacement", "cases": cases,
           "failures": 0})

    # The smallest raw-output obstruction from (709.7).
    witness = (1, 0, 0, 0, 0, 1)  # a,z,wc,sigma,J,what
    assert replacement_residual(*witness) == 0
    assert raw_output_residual(*witness) == 1
    print({"family": "raw_transition_output", "witness": witness,
           "residual": 1})


if __name__ == "__main__":
    main()
