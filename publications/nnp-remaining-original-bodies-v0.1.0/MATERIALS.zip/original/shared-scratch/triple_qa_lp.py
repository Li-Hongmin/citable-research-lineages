import numpy as np
from scipy.optimize import linprog
from itertools import combinations

def solve(n):
 X=[0];Y=list(range(1,1<<n));cells=[(0,y) for y in Y];m=len(cells)
 H=[]
 for a,b in combinations(Y,2):
  c=a^b
  if c in Y and a<b<c:H.append({(0,a),(0,b),(0,c)})
 # variables phi[m]+lambda[H], maximize sum phi; lambda>=0
 rows=[]
 for mask in range(1,1<<len(Y)):
  B={Y[j] for j in range(len(Y)) if mask>>j&1}
  # monochromatic if B subset of affine 1-set for some r (for x0)
  good=False
  for r in range(1,1<<n):
   if all((r&y).bit_count()%2==1 for y in B):good=True;break
  if not good:continue
  row=np.zeros(m+len(H)); row[:]=0
  for i,c in enumerate(cells):
   if c[1] in B:row[i]=1
  for j,h in enumerate(H):
   s=len(h & {(0,y) for y in B});row[m+j]=[0,1,-1,0][s]
  rows.append(row)
 A=np.array(rows);b=np.ones(len(rows));c=np.r_[-np.ones(m),np.zeros(len(H))]
 res=linprog(c,A_ub=A,b_ub=b,bounds=[(None,None)]*m+[(0,None)]*len(H),method='highs')
 print('n',n,'m',m,'H',len(H),'rows',len(rows),'status',res.status,'obj',-res.fun if res.status==0 else None)
 if res.status==0:
  print('phi minmax',res.x[:m].min(),res.x[:m].max(),'lambda',[(H[j],round(v,2)) for j,v in enumerate(res.x[m:]) if v>1e-5][:5])
for n in [2,3,4,5]:solve(n)
