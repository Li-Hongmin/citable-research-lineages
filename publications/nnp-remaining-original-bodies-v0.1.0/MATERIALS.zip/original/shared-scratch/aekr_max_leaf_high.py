from itertools import combinations
import numpy as np
from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import lil_matrix

def parity(x):return x.bit_count()&1
def gf2_rank(rows):
 rows=list(rows); r=0
 for col in range(max([x.bit_length() for x in rows]+[0])):
  p=next((i for i in range(r,len(rows)) if rows[i]>>col&1),None)
  if p is None:continue
  rows[r],rows[p]=rows[p],rows[r]
  for i in range(len(rows)):
   if i!=r and rows[i]>>col&1:rows[i]^=rows[r]
  r+=1
 return r
def rows(C,I,n):
 out=[]
 for i in I:
  x,y=C[i];out += [x|(1<<n), y|(1<<n)|(1<<(n+1))]
 return out
def con(C,I,n):
 R=rows(C,I,n); mask=(1<<(n+1))-1
 return gf2_rank([v&mask for v in R])==gf2_rank(R)
def minimal(C,I,s,n):
 return con(C,I,n) and not con(C,I+(s,),n) and all(con(C,tuple(j for j in I if j!=i)+(s,),n) for i in I)
def leaf(C,n,z):
 r,t=z>>1,z&1
 return sum(1<<i for i,(x,y) in enumerate(C) if parity(r&x)==t and parity(r&y)==(1-t))
def solve(X,Y,n,s,kmin=4,kmax=4):
 C=[(x,y) for x in X for y in Y];si=C.index(s); idx=[i for i in range(len(C)) if i!=si]
 leaves=[leaf(C,n,z) for z in range(1<<(n+1))]
 cand=[]
 for k in range(kmin,kmax+1):
  for I in combinations(idx,k):
   if minimal(C,I,si,n):cand.append(sum(1<<i for i in I))
 print('cand',len(cand))
 m=len(cand);L=len(leaves)
 rowsA=[];lo=[];hi=[]
 for i in range(m):
  for j in range(i):
   if cand[i]&cand[j]==0:
    rowsA.append({i:1,j:1});lo.append(-np.inf);hi.append(1)
 for z,Lz in enumerate(leaves):
  # y_z >= each selected witness subset condition? z-active iff y>=x_i for any i in leaf
  for i,T in enumerate(cand):
   if T&~Lz==0:
    rowsA.append({m+z:-1,i:1});lo.append(-np.inf);hi.append(0)
  row={m+z:1}
  for i,T in enumerate(cand):
   if T&~Lz==0: row[i]=-1
  rowsA.append(row);lo.append(-np.inf);hi.append(0)
 A=lil_matrix((len(rowsA),m+L))
 for ri,row in enumerate(rowsA):
  for ci,v in row.items():A[ri,ci]=v
 obj=np.r_[np.zeros(m),-np.ones(L)/(1<< (n+1))]
 res=milp(obj,integrality=np.ones(m+L),bounds=Bounds(np.zeros(m+L),np.ones(m+L)),constraints=LinearConstraint(A.tocsr(),np.array(lo),np.array(hi)),options={'time_limit':300,'mip_rel_gap':0})
 ch=[cand[i] for i in range(m) if res.x[i]>.5]
 return -res.fun,[[C[i] for i in range(len(C)) if T>>i&1] for T in ch],[z for z in range(L) if res.x[m+z]>.5]
if __name__=='__main__':
 import random
 for n in [3,4]:
  for trial in range(30):
   X=random.sample(range(1<<n),min(5,1<<n));Y=random.sample([v for v in range(1<<n) if v not in X],min(5,(1<<n)-len(X)))
   s=(X[0],Y[0]);v,ch,z=solve(X,Y,n,s,4,5)
   print(n,trial,v)
   if v>0.25+1e-6:
    print('FOUND',X,Y,s,v,ch,z);raise SystemExit
