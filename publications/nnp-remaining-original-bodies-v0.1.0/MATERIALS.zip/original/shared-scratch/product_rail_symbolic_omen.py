#!/usr/bin/env python3
"""Ordinary-ring GF(2) check for the product-rail algebra of Note 710.

Polynomials are represented by parity maps from sorted variable-address tuples
to coefficients.  No Boolean quotient is used, so repeated occurrences would
remain visible.  This is a finite algebra check only; it does not instantiate
the actual C456 orbit or prove C596.
"""

from __future__ import annotations

import json
import random
from itertools import product


class Poly:
    __slots__ = ("terms",)

    def __init__(self, terms=()):
        out = {}
        for mon in terms:
            mon = tuple(sorted(mon))
            out[mon] = 1 - out.get(mon, 0)
            if not out[mon]:
                del out[mon]
        self.terms = out

    @staticmethod
    def const(bit):
        return Poly([()] if bit & 1 else [])

    @staticmethod
    def var(name):
        return Poly([(name,)])

    def __xor__(self, other):
        out = dict(self.terms)
        for mon in other.terms:
            if mon in out:
                del out[mon]
            else:
                out[mon] = 1
        obj = object.__new__(Poly)
        obj.terms = out
        return obj

    def __mul__(self, other):
        out = {}
        for a in self.terms:
            for b in other.terms:
                mon = tuple(sorted(a + b))
                if mon in out:
                    del out[mon]
                else:
                    out[mon] = 1
        obj = object.__new__(Poly)
        obj.terms = out
        return obj

    def __bool__(self):
        return bool(self.terms)


ZERO = Poly.const(0)


def c(bit):
    return Poly.const(bit)


def random_local_poly(rng, vars_, max_terms=5):
    choices = [()] + [(v,) for v in vars_]
    choices += [(vars_[i], vars_[j]) for i in range(len(vars_))
                for j in range(i, len(vars_))]
    terms = [term for term in choices if rng.randrange(2)]
    if not terms:
        terms = [choices[rng.randrange(len(choices))]]
    return Poly(terms[:max_terms])


def make_case(T, rng, exhaustive_code=None):
    D, E = [], []
    for a in range(T):
        vars_a = [f"v{a}_{i}" for i in range(3)]
        if exhaustive_code is None:
            D.append(random_local_poly(rng, vars_a))
            E.append(random_local_poly(rng, vars_a))
        else:
            D.append(exhaustive_code[a][0])
            E.append(exhaustive_code[a][1])
    Db = [rng.randrange(2) for _ in range(T)]
    Eb = [rng.randrange(2) for _ in range(T)]
    y0, ybar, b = (rng.randrange(2) for _ in range(3))
    return D, E, Db, Eb, y0, ybar, b


def check_case(D, E, Db, Eb, y0, ybar, b):
    T = len(D)
    h = T.bit_length() - 1
    y = [Poly.var(f"y{a}") for a in range(T + 1)]
    p, q = [list(D)], [list(E)]
    for _ in range(h):
        pp, qq = p[-1], q[-1]
        p.append([pp[i] * pp[i + 1] for i in range(0, len(pp), 2)])
        q.append([(pp[i + 1] * qq[i]) ^ qq[i + 1]
                  for i in range(0, len(pp), 2)])

    def f(start, length, pp, qq):
        return y[start + length] ^ (pp * y[start]) ^ qq

    # One-step and parent identities (710.4)--(710.5).
    for a in range(T):
        up = p[0][a] ^ D[a]
        uq = q[0][a] ^ E[a]
        e = y[a + 1] ^ (D[a] * y[a]) ^ E[a]
        if f(a, 1, p[0][a], q[0][a]) ^ e ^ (y[a] * up) ^ uq:
            return False, ("leaf", a)
    for k in range(1, h + 1):
        span, half = 1 << k, 1 << (k - 1)
        for a in range(0, T, span):
            i, li, ri = a // span, a // half, a // half + 1
            pP, qP = p[k][i], q[k][i]
            pL, qL = p[k - 1][li], q[k - 1][li]
            pR, qR = p[k - 1][ri], q[k - 1][ri]
            up = pP ^ (pL * pR)
            uq = qP ^ (pR * qL) ^ qR
            ident = (f(a, span, pP, qP) ^ f(a + half, half, pR, qR)
                     ^ (pR * f(a, half, pL, qL))
                     ^ (y[a] * up) ^ uq)
            if ident:
                return False, ("parent", k, a)

    # Source-transformer recurrence and closed forms (711.3)--(711.4).
    pb, qb = [list(Db)], [list(Eb)]
    # At a leaf, u^p + (D + Dbar) = p + Dbar, and similarly for q.
    Sp = [[p[0][a] ^ c(Db[a]) for a in range(T)]]
    Sq = [[q[0][a] ^ c(Eb[a]) for a in range(T)]]
    for k in range(1, h + 1):
        pp, qq = pb[-1], qb[-1]
        pb.append([pp[i] & pp[i + 1] for i in range(0, len(pp), 2)])
        qb.append([(pp[i + 1] & qq[i]) ^ qq[i + 1]
                   for i in range(0, len(pp), 2)])
        span, half = 1 << k, 1 << (k - 1)
        Spk, Sqk = [], []
        for a in range(0, T, span):
            li, ri = a // half, a // half + 1
            pP, qP = p[k][a // span], q[k][a // span]
            pL, pR = p[k - 1][li], p[k - 1][ri]
            qL, qR = q[k - 1][li], q[k - 1][ri]
            up = pP ^ (pL * pR)
            uq = qP ^ (pR * qL) ^ qR
            SpL, SpR = Sp[k - 1][li], Sp[k - 1][ri]
            SqL, SqR = Sq[k - 1][li], Sq[k - 1][ri]
            Spk.append(up ^ (c(pb[k - 1][ri]) * SpL) ^ (pL * SpR))
            Sqk.append(uq ^ (pR * SqL) ^ SqR
                       ^ (c(qb[k - 1][li]) * SpR))
        Sp.append(Spk)
        Sq.append(Sqk)
        for a in range(0, span * (T // span), span):
            i = a // span
            if Sp[k][i] ^ p[k][i] ^ c(pb[k][i]):
                return False, ("Sp", k, a)
            if Sq[k][i] ^ q[k][i] ^ c(qb[k][i]):
                return False, ("Sq", k, a)

    pI, qI = p[h][0], q[h][0]
    bpI, bqI = pb[h][0], qb[h][0]
    SpI, SqI = Sp[h][0], Sq[h][0]
    lhs = ((pI * (c(y0) ^ c(ybar))) ^ (c(ybar) * SpI) ^ SqI
           ^ c((bpI & ybar) ^ bqI ^ b))
    rhs = (pI * c(y0)) ^ qI ^ c(b)
    if lhs ^ rhs:
        return False, ("root",)
    return True, {"terms_root_p": len(pI.terms),
                  "terms_root_q": len(qI.terms),
                  "terms_root_sp": len(SpI.terms),
                  "terms_root_sq": len(SqI.terms)}


def main():
    rng = random.Random(710_2026)
    cases = 0
    max_terms = 0
    # Exhaustive over a compact local polynomial alphabet for T=1 and T=2.
    atom = [Poly.const(0), Poly.const(1), Poly.var("u"),
            Poly.var("v"), Poly([("u", "v")])]
    for T in (1,):
        local = [(a, b) for a in atom for b in atom]
        for code in product(local, repeat=T):
            D, E, Db, Eb, y0, ybar, b = make_case(
                T, rng, exhaustive_code=code)
            # For every source assignment, not just the random one.
            for bits in product((0, 1), repeat=2 * T + 3):
                Db, Eb = list(bits[:T]), list(bits[T:2 * T])
                y0, ybar, b = bits[-3:]
                ok, detail = check_case(D, E, Db, Eb, y0, ybar, b)
                if not ok:
                    raise AssertionError(("exhaustive", T, code, bits, detail))
                cases += 1
                max_terms = max(max_terms, detail["terms_root_p"],
                                detail["terms_root_q"], detail["terms_root_sp"],
                                detail["terms_root_sq"])
    # Keep symbolic supports bounded; the purpose is identity validation, not
    # an exponential expansion of the product rail itself.
    for T, n in ((2, 80), (4, 20), (8, 5)):
        for _ in range(n):
            args = make_case(T, rng)
            ok, detail = check_case(*args)
            if not ok:
                raise AssertionError(("random", T, detail))
            cases += 1
            max_terms = max(max_terms, detail["terms_root_p"],
                            detail["terms_root_q"], detail["terms_root_sp"],
                            detail["terms_root_sq"])
    print(json.dumps({"host": "omen", "cases": cases,
                      "max_root_terms": max_terms, "failures": 0,
                      "scope": "ordinary-ring product-rail toy; actual C456 uninstantiated"},
                     sort_keys=True))


if __name__ == "__main__":
    main()
