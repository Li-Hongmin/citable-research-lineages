from itertools import product
def parity(x):return x.bit_count()&1
def prob(X,Y,n,x0):
 total=0.;dist={}
 for r in range(1<<n):
  for t in range(2):
   A=[x for x in X if parity(r&x)==t];B=[y for y in Y if parity(r&y)==1-t]
   if x0 not in A:continue
   # row retained + at least one col retained
   val=.5*(1-2**(-len(B)))
   total += val/(1<<(n+1))
 return total
for n in range(2,6):
 X=list(range(1<<n));Y=list(range(1<<n))
 print(n,prob(X,Y,n,0),prob(X,Y,n,1))
