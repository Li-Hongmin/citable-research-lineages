from itertools import combinations
import importlib.util, random
sp=importlib.util.spec_from_file_location('m','scratch/aekr_minimal_search.py'); m=importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
import numpy as np
from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import lil_matrix

def solve_cover(X,Y,n,s,a,b,kmin=3,kmax=4,limit=60):
 C,cands=m.candidates(X,Y,n,s,kmax)
 si=C.index(s); ia=C.index(a);ib=C.index(b)
 cands=[T for T in cands if T>>ia&1 or T>>ib&1]
 # Keep only T of size >=kmin (m.candidates currently includes 3+)
 cands=[T for T in cands if T.bit_count()>=kmin]
 if not cands:return 0,[]
 samples=m.event_samples(C,n)
 events=[[i for i,T in enumerate(cands) if T&~R==0] for R,_ in samples]
 active=[j for j,E in enumerate(events) if E]
 mm=len(cands); q=len(active); rows=[];lo=[];hi=[]
 for i in range(mm):
  for j in range(i):
   if cands[i]&cands[j]==0:
    rows.append({i:1,j:1});lo.append(-np.inf);hi.append(1)
 for jj,j in enumerate(active):
  row={mm+jj:1}
  for i in events[j]:row[i]=-1
  rows.append(row);lo.append(-np.inf);hi.append(0)
 A=lil_matrix((len(rows),mm+q))
 for ri,row in enumerate(rows):
  for ci,v in row.items():A[ri,ci]=v
 obj=np.zeros(mm+q)
 for jj,j in enumerate(active):obj[mm+jj]=-samples[j][1]
 res=milp(obj,integrality=np.r_[np.ones(mm),np.zeros(q)],bounds=Bounds(np.zeros(mm+q),np.ones(mm+q)),constraints=LinearConstraint(A.tocsr(),np.array(lo),np.array(hi)),options={'time_limit':limit,'mip_rel_gap':0})
 ch=[cands[i] for i in range(mm) if res.x[i]>.5]
 return -res.fun,[[C[i] for i in range(len(C)) if T>>i&1] for T in ch]

if __name__=='__main__':
 for n in [3,4]:
  vals=list(range(1<<n))
  best=(0,None)
  for tri in range(40):
   random.seed(1000*n+tri);random.shuffle(vals)
   nx=min(5,1<<n);X=vals[:nx];Y=vals[nx:nx+min(5,(1<<n)-nx)]
   if not X or not Y:continue
   C=[(x,y) for x in X for y in Y]
   s=(X[0],Y[0]);si=C.index(s)
   for a,b in combinations([c for c in C if c!=s],2):
    v,ch=solve_cover(X,Y,n,s,a,b,3,4,10)
    if v>best[0]+1e-9:
     best=(v,(X[:],Y[:],s,a,b,ch));print('BEST',n,best[0],a,b,'nch',len(ch),flush=True)
  print('FINAL',n,best[0],best[1][:5])
