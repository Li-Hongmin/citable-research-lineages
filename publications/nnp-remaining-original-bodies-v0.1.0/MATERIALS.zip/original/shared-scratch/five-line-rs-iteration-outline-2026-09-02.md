# Five-line RS iteration: proof outline under verification

Let

\[
H(U,V)=\bigoplus_t f(t)g(t+U)h(t+V),
\]

and, for two distinct nonparallel directions \(\lambda_4,\lambda_5\), put

\[
C(x)=\bigoplus_a b(a)H_B(x+a\lambda_4),\qquad
D(y)=\bigoplus_c d(c)C(y+c\lambda_5).
\]

The purpose of this outline is to determine whether the four-line argument
iterates once. It is not yet a permanent result.

Choose

\[
k=\lfloor q^{1/24}/C_0\rfloor,\qquad N=k^2,\qquad M=N^2=k^4.
\]

Let \(\pi_4(u,v)=\lambda_{4,2}u+\lambda_{4,1}v\), so
\(\ker\pi_4=\lambda_4\mathbb F_q\). Since the two directions are
nonparallel, \(\pi_4(\lambda_5)\ne0\). Choose binary subspaces
\(U,W,Z\le\mathbb F_q\) in direct sum, of respective dimensions at least
\(\lceil\log_2 k\rceil,\lceil\log_2 k\rceil,
\lceil\log_2 N\rceil\). Take

\[
R\subseteq\lambda_{4,2}^{-1}U,
\quad S\subseteq\lambda_{4,1}^{-1}W,
\quad A_5\subseteq\pi_4(\lambda_5)^{-1}Z
\]

with sizes \(k,k,N\). Then \(\pi_4\) is injective on

\[
E=(R\times S)+A_5\lambda_5,
\qquad |E|=N^2=M.
\]

Choose any \(M\)-element \(A_4\subseteq\mathbb F_q\). The map

\[
E\times A_4\to\mathbb F_q^2,
\qquad (e,a)\mapsto e+a\lambda_4
\]

is injective. Hence the \(M^2=k^8\) arguments of

\[
V_{e,a}=H_B(e+a\lambda_4)
\]

are distinct. Lemma 860.1 makes \(V\) iid fair outside probability
\(\exp(-\Omega(q^{1/3}))\), provided \(C_0\) is a sufficiently large
absolute constant. Thus \(\operatorname{rank}V\ge M/4\) except with the
same probability scale.

Condition on \(H\) and on \(b(a)\) for \(a\notin A_4\). Then \(C|_E\) is
uniform on an affine subspace of dimension at least \(M/4\). Arrange it as
the \(N\times N\) matrix

\[
W_{y,c}=C(y+c\lambda_5),
\qquad y\in R\times S,\ c\in A_5.
\]

The number of \(N\times N\) binary matrices of rank at most \(N/16\) is at
most \(2^{2N(N/16)}=2^{M/8}\). Therefore

\[
\Pr[\operatorname{rank}W\le N/16]\le 2^{-M/8}.
\]

Finally condition on \(C\) with \(\operatorname{rank}W\ge N/16\), and on
\(d(c)\) for \(c\notin A_5\). The vector \(D|_{R\times S}\), arranged as a
\(k\times k\) matrix, is uniform on an affine subspace of dimension at least
\(N/16\). Since there are at most \(2^{2kr}\) matrices of rank at most
\(r\), taking \(r=\lfloor k/64\rfloor\) gives

\[
\Pr[\operatorname{rank}(D|_{R\times S})\le r]
\le 2^{2kr-N/16}\le 2^{-N/32}
\]

up to harmless floor adjustments. Hence the proposed conclusion is

\[
\operatorname{rank}D=\Omega(q^{1/24})
\]

outside probability \(\exp(-\Omega(q^{1/12}))\). The last \(k\times k\)
low-rank count, not the preceding \(N\times N\) count, dominates the final
failure probability. If every reduction and
conditioning interface survives review, this yields
\(\chi_{5,2,n}\to0\), uniformly over seven distinct RS evaluation points.

Checks still required before promotion:

1. exact constants in applying Lemma 860.1 to \(k^8\) arbitrary points;
2. floor-safe low-rank exponents;
3. exact RS reduction of five line factors to \(H_B\), then the two original
   line directions;
4. uniformity over all evaluation sets.
