#!/usr/bin/env python3
"""Finite boundary check for poly-bit-state/associativity claims.

The one-step state y is one bit and each successor is the constant-size map
    y[t+1] = u[t] * y[t].
Semantic function composition is associative, but the literal ordinary-ring
summary has coefficient product(u[0],...,u[T-1]).  With fresh formal u[t], its
degree and occurrence-record length are T.  This is exactly the missing
representation-closure condition: associativity alone does not charge a
succinct long jump.  Product rails are a different, explicitly charged normal
form and are not tested here.
"""

from __future__ import annotations

import json


def literal_pullback(T: int):
    """Return the final coefficient and equation multipliers for y_T."""
    coeff = ()  # monomial for the current y_t boundary coefficient
    # Keep a multiplier as an ordered list; all u_t are distinct, so no
    # Boolean quotient or accidental cancellation is possible.
    coeff = []
    multipliers = []
    for t in range(T - 1, -1, -1):
        # Current boundary coefficient multiplies e_t and then acquires u_t
        # when the boundary is moved to y_t.
        multipliers.append((t, tuple(coeff)))
        coeff.append(f"u{t}")
    return tuple(coeff), tuple(multipliers)


def check(max_h: int = 8):
    rows = []
    for h in range(max_h + 1):
        T = 1 << h
        coeff, multipliers = literal_pullback(T)
        assert len(coeff) == T
        assert len(set(coeff)) == T
        assert len(multipliers) == T
        max_mult_degree = max((len(mult) for _, mult in multipliers), default=0)
        assert max_mult_degree == T - 1 if T else max_mult_degree == 0
        # The final boundary has two ordinary term occurrences (y_T and the
        # product*y_0); every recurrence multiple has two terms.
        expanded_terms = 2 + 2 * T
        rows.append({
            "h": h,
            "T": T,
            "state_bits": 1,
            "summary_coeff_degree": len(coeff),
            "summary_coeff_occurrences": len(coeff),
            "max_equation_multiplier_degree": max_mult_degree,
            "literal_expanded_term_occurrences": expanded_terms,
        })
    return rows


def main():
    rows = check()
    print(json.dumps({
        "host": "omen",
        "rows": rows,
        "failures": 0,
        "scope": "fresh formal-factor literal reverse pullback; not actual C456",
        "decision": {
            "one_step_poly_bit_state": "PASS",
            "associativity_without_representation_closure": "CLOSED",
            "charged_product_rail_or_other_normal_form": "NOT_TESTED",
            "actual_C456": "UNKNOWN_PAUSE",
        },
    }, sort_keys=True))


if __name__ == "__main__":
    main()
