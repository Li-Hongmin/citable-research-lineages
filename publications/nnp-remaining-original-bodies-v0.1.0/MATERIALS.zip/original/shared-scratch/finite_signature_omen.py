#!/usr/bin/env python3
"""Omen check for the strengthened finite-signature source-transformer.

This is a bounded algebraic/descriptor check only.  It tests the exact
source-transformer count recurrences from Note 711 together with recursive
Rank/Select inverses, and rechecks the GF(2) endpoint identity.  It does not
instantiate the actual C456 machine or provide an ODStream/C596 certificate.
"""

from __future__ import annotations

import json
import random
from itertools import product


class Node:
    __slots__ = ("p", "q", "A", "B", "left", "right", "cp", "cq")

    def __init__(self, p, q, A, B, left=None, right=None, cp=None, cq=None):
        self.p, self.q, self.A, self.B = p, q, A, B
        self.left, self.right = left, right
        self.cp, self.cq = cp, cq


def combine(left: Node, right: Node) -> Node:
    # Source valuation is the finite affine kernel state (pbar,qbar).
    p = left.p & right.p
    q = (right.p & left.q) ^ right.q
    # Exact source-transformer equation-multiple counts, Note 711 (711.6).
    A = 1 + (left.A if right.p else 0) + right.A
    B = 1 + left.B + right.B + (right.A if left.q else 0)
    return Node(p, q, A, B, left, right)


def build_tree(dbar, ebar, cp, cq):
    nodes = [Node(dbar[i], ebar[i], 1 + cp[i], 1 + cq[i], cp=cp[i], cq=cq[i])
             for i in range(len(dbar))]
    while len(nodes) > 1:
        nodes = [combine(nodes[i], nodes[i + 1])
                 for i in range(0, len(nodes), 2)]
    return nodes[0]


def flatten(kind: str, node: Node, path=()):
    """Canonical tagged slot list used only as a finite reference oracle."""
    if node.left is None:
        if kind == "A":
            return [("Aeq", path)] + [
                ("Asrc", path + (f"S{i}",)) for i in range(node.cp)
            ]
        return [("Beq", path)] + [
            ("Bsrc", path + (f"S{i}",)) for i in range(node.cq)
        ]
    if kind == "A":
        out = [("Aeq", path)]
        if node.right.p:
            out.extend(flatten("A", node.left, path + ("L",)))
        out.extend(flatten("A", node.right, path + ("R",)))
        return out
    out = [("Beq", path)]
    out.extend(flatten("B", node.left, path + ("L",)))
    out.extend(flatten("B", node.right, path + ("R",)))
    if node.left.q:
        out.extend(flatten("A", node.right, path + ("RA",)))
    return out


def prefix(token, branch):
    return token[0], (branch,) + token[1]


def select(kind: str, node: Node, rank: int):
    """Recursive Select; order matches the exact count recurrence."""
    if rank < 0:
        raise IndexError(rank)
    if rank == 0:
        return ("Aeq" if kind == "A" else "Beq", ())
    if node.left is None:
        count = node.cp if kind == "A" else node.cq
        if rank <= count:
            return (("Asrc" if kind == "A" else "Bsrc"),
                    (f"S{rank - 1}",))
        raise IndexError(rank)
    rank -= 1
    if kind == "A":
        if node.right.p:
            if rank < node.left.A:
                child = select("A", node.left, rank)
                return prefix(child, "L")
            rank -= node.left.A
        child = select("A", node.right, rank)
        return prefix(child, "R")
    if rank < node.left.B:
        child = select("B", node.left, rank)
        return prefix(child, "L")
    rank -= node.left.B
    if rank < node.right.B:
        child = select("B", node.right, rank)
        return prefix(child, "R")
    rank -= node.right.B
    if node.left.q:
        child = select("A", node.right, rank)
        return prefix(child, "RA")
    raise IndexError(rank)


def rank(kind: str, node: Node, token):
    """Recursive Rank inverse for the tagged path returned by Select."""
    tag, path = token
    if not path:
        expected = "Aeq" if kind == "A" else "Beq"
        if tag != expected:
            raise ValueError((kind, token))
        return 0
    if node.left is None:
        if len(path) == 1 and path[0].startswith("S"):
            idx = int(path[0][1:])
            expected = "Asrc" if kind == "A" else "Bsrc"
            count = node.cp if kind == "A" else node.cq
            if tag == expected and 0 <= idx < count:
                return 1 + idx
        raise ValueError((kind, token))
    branch, rest = path[0], path[1:]
    if kind == "A":
        offset = 1
        if node.right.p:
            if branch == "L":
                return offset + rank("A", node.left, (tag, rest))
            offset += node.left.A
        if branch != "R":
            raise ValueError((kind, token))
        return offset + rank("A", node.right, (tag, rest))
    offset = 1
    if branch == "L":
        return offset + rank("B", node.left, (tag, rest))
    offset += node.left.B
    if branch == "R":
        return offset + rank("B", node.right, (tag, rest))
    offset += node.right.B
    if branch == "RA" and node.left.q:
        return offset + rank("A", node.right, (tag, rest))
    raise ValueError((kind, token))


def check_descriptors(dbar, ebar, cp, cq, exhaustive_ranks=True):
    root = build_tree(dbar, ebar, cp, cq)
    A_ref = flatten("A", root)
    B_ref = flatten("B", root)
    if (root.A, root.B) != (len(A_ref), len(B_ref)):
        return False, {"where": "count", "got": (root.A, root.B),
                       "want": (len(A_ref), len(B_ref))}
    for kind, total, ref in (("A", root.A, A_ref), ("B", root.B, B_ref)):
        ranks = range(total) if exhaustive_ranks else {
            0, total - 1, total // 2,
            *(random.randrange(total) for _ in range(min(32, total)))
        }
        for s in ranks:
            token = select(kind, root, s)
            if rank(kind, root, token) != s or token != ref[s]:
                return False, {"where": "rank-select", "kind": kind,
                               "rank": s, "token": token, "reference": ref[s]}
    return True, {"A": root.A, "B": root.B, "p": root.p, "q": root.q}


def rails(actual_d, actual_e):
    p, q = list(actual_d), list(actual_e)
    while len(p) > 1:
        pn, qn = [], []
        for i in range(0, len(p), 2):
            pn.append(p[i] & p[i + 1])
            qn.append((p[i + 1] & q[i]) ^ q[i + 1])
        p, q = pn, qn
    return p[0], q[0]


def endpoint_identity(actual_d, actual_e, dbar, ebar, y0, ybar, b):
    """Numerically check (710.15)--(710.16) over GF(2)."""
    pI, qI = rails(actual_d, actual_e)
    bpI, bqI = rails(dbar, ebar)
    # Source-transformer closed forms S^p=p+bar p and S^q=q+bar q.
    Sp, Sq = pI ^ bpI, qI ^ bqI
    S0 = ((pI & (y0 ^ ybar)) ^ (ybar & Sp) ^ Sq
          ^ (bpI & ybar) ^ bqI ^ b)
    P0 = (pI & y0) ^ qI
    return S0 == (P0 ^ b)


def collision_witness():
    """Show why (pbar,qbar) alone cannot recover exact Count."""
    dbar = (0, 0)
    ebar = (0, 0)
    one = build_tree(dbar, ebar, (0, 0), (0, 0))
    two = build_tree(dbar, ebar, (1, 1), (1, 1))
    assert (one.p, one.q) == (two.p, two.q) == (0, 0)
    assert (one.A, one.B) != (two.A, two.B)
    return {"source": {"dbar": dbar, "ebar": ebar},
            "same_endpoint": [one.p, one.q],
            "counts_a": [one.A, one.B], "counts_b": [two.A, two.B]}


def main():
    rng = random.Random(711_2026)
    descriptor_cases = 0
    endpoint_cases = 0
    max_count_bits = 0

    # Exhaustive small descriptor kernels, including independent leaf
    # derivation counts.  This validates the recurrence and navigation, not
    # the existence of such a kernel for C456.
    for T in (1, 2):
        for dbar in product((0, 1), repeat=T):
            for ebar in product((0, 1), repeat=T):
                for cp in product((0, 1, 2), repeat=T):
                    for cq in product((0, 1, 2), repeat=T):
                        ok, detail = check_descriptors(dbar, ebar, cp, cq)
                        if not ok:
                            raise AssertionError((T, dbar, ebar, cp, cq, detail))
                        descriptor_cases += 1
                        max_count_bits = max(max_count_bits,
                                              detail["A"].bit_length(),
                                              detail["B"].bit_length())

    for _ in range(3000):
        T = 1 << rng.choice((2, 3, 4, 6, 8))
        dbar = [rng.randrange(2) for _ in range(T)]
        ebar = [rng.randrange(2) for _ in range(T)]
        cp = [rng.randrange(4) for _ in range(T)]
        cq = [rng.randrange(4) for _ in range(T)]
        ok, detail = check_descriptors(dbar, ebar, cp, cq,
                                       exhaustive_ranks=(T <= 16))
        if not ok:
            raise AssertionError((T, detail))
        descriptor_cases += 1
        max_count_bits = max(max_count_bits,
                              detail["A"].bit_length(), detail["B"].bit_length())

    # Stress address-scale navigation on larger streams without materializing
    # every rank.  The tree has O(log T) height and counts remain O(log T)
    # bits for bounded leaf counts.
    for T in (256, 4096, 65536):
        for _ in range(20):
            dbar = [rng.randrange(2) for _ in range(T)]
            ebar = [rng.randrange(2) for _ in range(T)]
            cp = [rng.randrange(3) for _ in range(T)]
            cq = [rng.randrange(3) for _ in range(T)]
            ok, detail = check_descriptors(dbar, ebar, cp, cq,
                                           exhaustive_ranks=False)
            if not ok:
                raise AssertionError((T, detail))
            descriptor_cases += 1
            max_count_bits = max(max_count_bits,
                                  detail["A"].bit_length(), detail["B"].bit_length())

    # Exhaustive endpoint checks at T<=2 and random checks at larger powers.
    for T in (1, 2):
        for bits in product((0, 1), repeat=4 * T + 3):
            actual_d = bits[:T]
            actual_e = bits[T:2 * T]
            dbar = bits[2 * T:3 * T]
            ebar = bits[3 * T:4 * T]
            y0, ybar, b = bits[-3:]
            if not endpoint_identity(actual_d, actual_e, dbar, ebar,
                                     y0, ybar, b):
                raise AssertionError(("endpoint", T, bits))
            endpoint_cases += 1
    for T, cases in ((4, 2000), (16, 1000), (256, 300), (4096, 60)):
        for _ in range(cases):
            vals = [[rng.randrange(2) for _ in range(T)] for _ in range(4)]
            y0, ybar, b = (rng.randrange(2) for _ in range(3))
            if not endpoint_identity(*vals, y0, ybar, b):
                raise AssertionError(("endpoint", T))
            endpoint_cases += 1

    print(json.dumps({
        "host": "omen",
        "descriptor_cases": descriptor_cases,
        "endpoint_cases": endpoint_cases,
        "max_count_bits": max_count_bits,
        "collision_witness": collision_witness(),
        "failures": 0,
        "scope": "finite-signature toy only; actual C456 remains uninstantiated",
    }, sort_keys=True))


if __name__ == "__main__":
    main()
