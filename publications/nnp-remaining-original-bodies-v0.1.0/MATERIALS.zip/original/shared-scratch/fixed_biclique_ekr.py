from itertools import combinations
import numpy as np
from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import lil_matrix

def opt(m,n,min_k=3,max_k=None):
 E=[(i,j) for i in range(m) for j in range(n)]; q=len(E)
 if max_k is None:max_k=q
 cands=[]
 for k in range(min_k,max_k+1):
  for t in combinations(range(q),k):
   a=len({E[e][0] for e in t}); b=len({E[e][1] for e in t})
   if a+b < k+1: continue
   cands.append(sum(1<<e for e in t))
 samples=[]
 for U in range(1<<m):
  for V in range(1<<n):
   R=sum(1<<e for e,(i,j) in enumerate(E) if U>>i&1 and V>>j&1)
   samples.append((R, 1/(1<<(m+n))))
 ev=[[i for i,T in enumerate(cands) if T&~R==0] for R,w in samples]
 active=[j for j,e in enumerate(ev) if e]
 rows=[]; lo=[];hi=[]
 for i in range(len(cands)):
  for j in range(i):
   if cands[i]&cands[j]==0:
    rows.append({i:1,j:1});lo.append(-np.inf);hi.append(1)
 for jj,j in enumerate(active):
  row={len(cands)+jj:1}
  for i in ev[j]: row[i]=-1
  rows.append(row);lo.append(-np.inf);hi.append(0)
 A=lil_matrix((len(rows),len(cands)+len(active)))
 for ri,r in enumerate(rows):
  for ci,v in r.items():A[ri,ci]=v
 obj=np.zeros(A.shape[1]);
 for jj,j in enumerate(active):obj[len(cands)+jj]=-samples[j][1]
 r=milp(obj,integrality=np.r_[np.ones(len(cands)),np.zeros(len(active))],bounds=Bounds(np.zeros(A.shape[1]),np.ones(A.shape[1])),constraints=LinearConstraint(A.tocsr(),np.array(lo),np.array(hi)),options={'time_limit':300,'mip_rel_gap':0})
 ch=[cands[i] for i in range(len(cands)) if r.x[i]>.5]
 return -r.fun,[[E[e] for e in range(q) if T>>e&1] for T in ch]
if __name__=='__main__':
 for m,n in [(2,2),(2,3),(3,3)]:
  v,ch=opt(m,n,3)
  print(m,n,v,ch[:20])
