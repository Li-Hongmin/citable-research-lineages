#!/usr/bin/env python3
"""Omen probe for a route-local coverage trichotomy.

This script combines two exact finite witnesses already isolated in Notes
699 and 676:

* a fresh nonlinear product recurrence forces a multilinear coefficient of
  degree T when no product rail/extension variable is allowed;
* an owner-free ordinary ledger has collisions in endpoint/weight summaries,
  while exact provenance distinguishes all owner words.

The output deliberately treats product rails and owner-random-access circuits
as *exits* from this compiler family.  Nothing here instantiates the actual
C456 transition table or proves a representation-independent lower bound.
"""

from __future__ import annotations

import json
from collections import defaultdict
from itertools import product
from math import ceil, log2


def fresh_product_degree(T: int, local_degree: int = 1) -> int:
    """Exact y_0 coefficient degree for y[t+1]=D_t*y[t].

    Each D_t is a fresh monomial on a disjoint block, with the requested
    multilinear degree.  In the Boolean quotient the product is nonzero and
    has degree T*local_degree.  This is Theorem 699.1 in its minimal witness.
    """
    if T < 1 or local_degree < 1:
        raise ValueError((T, local_degree))
    # The recurrence is multiplicative, so tracking the highest (and here
    # unique) product monomial is exact without materialising object-scale
    # polynomials.
    degree = 0
    for _ in range(T):
        degree += local_degree
    return degree


def fresh_product_probe():
    rows = []
    for m in range(0, 11):
        T = 1 << m
        for local_degree in (1, 2):
            required = fresh_product_degree(T, local_degree)
            # A disjoint degree-one multiplier G raises the left coefficient
            # by one; this is the exact boundary form used in Note 699.
            required_with_G = required + 1
            rows.append({
                "m": m,
                "T": T,
                "local_degree": local_degree,
                "required_y0_degree": required,
                "required_with_G_degree": required_with_G,
                "polylog_cap_fails": required > (m + 1) ** 3,
            })
    # For all nontrivial tested lengths, the degree is linear in T, hence
    # exponential in m.  The m=0 row is retained only as a sanity check.
    assert all(r["required_y0_degree"] == r["T"] * r["local_degree"]
               for r in rows)
    assert all(r["required_y0_degree"] > r["m"] ** 3
               for r in rows if r["m"] >= 10)
    return rows


def boolean_poly_mul(left, right):
    """Multiply supports in the Boolean quotient (x^2=x)."""
    out = set()
    for a in left:
        for b in right:
            mon = frozenset(a | b)
            if mon in out:
                out.remove(mon)
            else:
                out.add(mon)
    return out


def shared_factor_probe():
    """Show why the fresh-block hypothesis cannot be silently applied to C456.

    If every multiplier is the same source bit a, Boolean idempotence gives
    a^T=a.  The product degree is then one, not T.  This is a direct finite
    witness for the noninterference caveat in Note 703.
    """
    rows = []
    factor = {frozenset(("a",))}
    for m in range(0, 11):
        T = 1 << m
        product_support = {frozenset()}
        for _ in range(T):
            product_support = boolean_poly_mul(product_support, factor)
        max_degree = max(map(len, product_support))
        assert product_support == factor
        rows.append({"m": m, "T": T, "support_terms": len(product_support),
                     "required_degree": max_degree})
    assert all(row["required_degree"] == 1 for row in rows)
    return rows


def owner_ledger(word):
    """Tagged ordinary ledger for the fixed-token local identity.

    The exact local occurrence count is 8+2*j.  We retain complete records,
    including step and owner, so different owner words cannot be silently
    collected in the ordinary ring.
    """
    out = []
    for t, j in enumerate(word):
        # The eight base slots are enough to identify the local template; the
        # optional two slots are the owner-one correction of Note 676.
        for u in range(8 + 2 * j):
            out.append((t, j, u, "ordinary-slot"))
    return tuple(out)


def owner_summary(word):
    """Owner-blind summary that even includes the total owner weight."""
    T = len(word)
    return (T, sum(word), "same-endpoint-type", 2)


def owner_coarse_summary(word):
    """Coarser summary before exact multiplicity is requested."""
    return (len(word), "same-endpoint-type", 2)


def owner_probe(max_T: int = 12):
    collision_rows = []
    exact_rows = []
    for T in range(1, max_T + 1):
        groups = defaultdict(list)
        ledgers = set()
        for word in product((0, 1), repeat=T):
            groups[owner_summary(word)].append(word)
            ledgers.add(owner_ledger(word))
        collisions = [g for g in groups.values() if len(g) > 1]
        max_bucket = max(map(len, groups.values()))
        # Every owner word appears in its own complete-provenance ledger.
        assert len(ledgers) == 1 << T
        info_lower_bound = ceil(log2(len(ledgers)))
        collision_rows.append({
            "T": T,
            "owner_words": 1 << T,
            "summary_values": len(groups),
            "collision_buckets": len(collisions),
            "max_collision_bucket": max_bucket,
            "min_provenance_bits_worst_case": info_lower_bound,
        })
        # The two smallest nontrivial examples expose different failure modes:
        # 00/01 differ in exact count; 010/001 have equal count but different
        # step provenance.
        exact_rows.append({"T": T, "distinct_complete_ledgers": len(ledgers)})

    # Explicit witnesses, written without relying on a quotient-ring rewrite.
    assert len(owner_ledger((0, 0))) == 16
    assert len(owner_ledger((0, 1))) == 18
    assert owner_coarse_summary((0, 0)) == owner_coarse_summary((0, 1))
    assert owner_summary((0, 0)) != owner_summary((0, 1))
    assert len(owner_ledger((0, 1, 0))) == len(owner_ledger((0, 0, 1))) == 26
    assert owner_ledger((0, 1, 0)) != owner_ledger((0, 0, 1))
    assert owner_summary((0, 1, 0)) == owner_summary((0, 0, 1))
    return collision_rows, exact_rows


def main():
    fresh_rows = fresh_product_probe()
    shared_rows = shared_factor_probe()
    collision_rows, exact_rows = owner_probe()
    out = {
        "host": "omen",
        "fresh_product": {
            "rows": len(fresh_rows),
            "max_T": max(r["T"] for r in fresh_rows),
            "max_required_degree": max(r["required_y0_degree"]
                                        for r in fresh_rows),
            "all_exact": True,
            "scope": "fresh disjoint blocks; no product rail/extension",
        },
        "shared_source_factor_escape": {
            "rows": len(shared_rows),
            "max_T": max(r["T"] for r in shared_rows),
            "all_exact": True,
            "required_degree": 1,
            "scope": "one shared Boolean source bit; demonstrates why fresh-block tensor independence is needed",
        },
        "owner_provenance": {
            "T_max": max(r["T"] for r in collision_rows),
            "rows": len(collision_rows),
            "all_exact": True,
            "worst_case_bits_at_T_max": collision_rows[-1][
                "min_provenance_bits_worst_case"],
            "scope": "fixed-token ordinary ledger; owner-blind summaries",
            "witness_count_collision": {
                "words": [[0, 0], [0, 1]],
                "coarse_summary_equal": owner_coarse_summary((0, 0))
                == owner_coarse_summary((0, 1)),
                "exact_counts": [len(owner_ledger((0, 0))),
                                 len(owner_ledger((0, 1)))],
            },
            "witness_provenance_collision": {
                "words": [[0, 1, 0], [0, 0, 1]],
                "weight_summary_equal": owner_summary((0, 1, 0))
                == owner_summary((0, 0, 1)),
                "exact_counts": [len(owner_ledger((0, 1, 0))),
                                 len(owner_ledger((0, 0, 1)))],
                "complete_ledgers_equal": owner_ledger((0, 1, 0))
                == owner_ledger((0, 0, 1)),
            },
        },
        "route_decision": {
            "fresh_nonlinear_without_product_rail": "CLOSED",
            "owner_free_without_provenance_or_random_access": "CLOSED",
            "product_rail_or_owner_random_access": "EXIT_NEW_CLASS",
            "actual_C456": "UNKNOWN_PAUSE",
        },
        "failures": 0,
        "warning": (
            "Finite witnesses only; no actual C456 transition table, orbit, "
            "source cap, C596 certificate, or P!=NP conclusion."
        ),
    }
    print(json.dumps(out, sort_keys=True))


if __name__ == "__main__":
    main()
