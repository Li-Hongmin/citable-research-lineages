# A Single Modular Character Is Complete for SYM∘LTF Counting

## Abstract

We give an exact selector-based reduction from counting for depth-two circuits with a symmetric
top gate and linear-threshold bottom gates to one unweighted modular-character expectation.
Let
\[
 C(x)=f\!\left(\sum_{i=1}^{q}T_i(x)\right),\qquad T_i\in\mathrm{LTF}_h,
\]
where \(f:\{0,\ldots,q\}\to\{0,1\}\) is arbitrary. If \(R\) is the least power of two
larger than \(q\), then in polynomial time we construct \(M=O(q^2)\) LTFs on
\(h+2\log_2R+1\) variables such that
\[
 \mathbb E\,\omega^{\sum_{j=1}^{M}U_j}
 =\frac1R\Pr_x[C(x)=1],\qquad \omega=e^{2\pi i/R}.
\]
Every character coefficient is \(1\). Thus one character, with a growing modulus and only
logarithmically many selector variables, already carries arbitrary
\(\mathrm{SYM}_q\circ\mathrm{LTF}_h\)-CAPP. The theorem rules out a generic claim that this
unweighted character primitive is strictly easier. It does not itself give a faster algorithm
or a circuit lower bound.

## 1. The representation theorem

An LTF is written as \(T(x)=1[L(x)\ge\theta]\), with rational weights. Clearing
denominators changes the encoding length only polynomially.

### Theorem 1 (unweighted single-character completeness)

Let \(q\ge1\), let \(T_1,\ldots,T_q\in\mathrm{LTF}_h\), and let
\(f:\{0,\ldots,q\}\to\{0,1\}\). Put \(R=2^\ell>q\), where \(R\) is the least such power
of two, and let \(\omega=e^{2\pi i/R}\). There is a polynomial-time construction of
\[
 U_1,\ldots,U_M\in\mathrm{LTF}_{h+2\ell+1}
\]
with
\[
 M=O(qR+\ell^2R+R^2)=O(q^2)
\]
such that
\[
 \mathbb E_{x,a,s,u}
 \left[\omega^{\sum_{j=1}^{M}U_j(x,a,s,u)}\right]
 =\frac1R\Pr_x\!\left[f\!\left(\sum_{i=1}^{q}T_i(x)\right)=1\right].
 \tag{1}
\]
Here \(a,s\in\{0,1\}^{\ell}\cong\mathbb Z_R\), \(u\in\{0,1\}\), and all variables are
uniform and independent. An estimate of the left-hand side with complex error \(\eta\)
recovers the acceptance probability with error at most
\(R\eta<2(q+1)\eta\).

Consequently, \(\mathrm{SYM}_q\circ\mathrm{LTF}_h\)-CAPP many-one reduces, with polynomial
size blow-up, to one unweighted
\(\mathrm{MOD}_R\circ\mathrm{LTF}_{h+O(\log q)}\) character expectation.

### Proof

Write \(S(x)=\sum_{i=1}^{q}T_i(x)\in\{0,\ldots,q\}\), and extend \(f\) by zero to
\(\mathbb Z_R\). Define
\[
 \Phi(x,a,s,u)
 =a(S(x)-s)+\frac R2u(1-f(s))\pmod R.
 \tag{2}
\]
For fixed \(x,a,s\), averaging over \(u\) gives
\[
 \mathbb E_u\,\omega^{\Phi}
 =
 \begin{cases}
 \omega^{a(S-s)},& f(s)=1,\\
 \frac12(1+\omega^{R/2})\omega^{a(S-s)}=0,& f(s)=0.
 \end{cases}
 \tag{3}
\]
Character orthogonality gives
\[
 \mathbb E_a\,\omega^{a(S-s)}=1[S=s],
 \tag{4}
\]
because \(R>S\). Averaging next over uniform \(s\) proves
\[
 \mathbb E_{a,s,u}\omega^{\Phi(x,a,s,u)}=R^{-1}f(S(x)).
 \tag{5}
\]

It remains to realize \(\Phi\) as a sum of unweighted LTF outputs. Write
\(a=\sum_{b<\ell}2^ba_b\) and \(s=\sum_{c<\ell}2^cs_c\). For each bottom gate choose
an integer \(B_i>|\theta_i|+\sum_j|w_{ij}|\). Then
\[
 a_b\wedge T_i(x)
 =1[L_i(x)+B_i a_b\ge\theta_i+B_i]
 \tag{6}
\]
is an LTF. Replicating it \(2^b\) times realizes
\[
 aS=\sum_{i=1}^{q}\sum_{b<\ell}2^b(a_b\wedge T_i(x)),
 \tag{7}
\]
using \(q(R-1)\) copies.

For the term \(as\), retain only products \(a_bs_c\) with \(b+c<\ell\), since all
other terms are multiples of \(R\). Modulo \(R\),
\[
 -2^{b+c}a_bs_c
 \equiv 2^{b+c}(1-a_bs_c)-2^{b+c},
 \tag{8}
\]
and \(1-a_bs_c=1[a_b+s_c\le1]\) is an LTF. Replication and constant-one LTFs implement
the entire \(-as\) term with \(O(\ell^2R+R)\) gates.

For each \(t\in\mathbb Z_R\), the singleton selector
\[
 V_t(s,u)=1[(s,u)=(t,1)]
 \tag{9}
\]
is an LTF. If \(t_c\) is the \(c\)-th bit of \(t\), set
\[
 d_t(s)=\sum_{c:t_c=1}s_c+\sum_{c:t_c=0}(1-s_c),
 \qquad
 V_t(s,u)=1[d_t(s)+u\ge\ell+1].
 \tag{10}
\]
For each \(t\) with \(f(t)=0\), replicate \(V_t\) \(R/2\) times. This realizes the final
term in (2) using at most \(R^2/2\) copies. Thus the total number of LTFs is
\(O(qR+\ell^2R+R^2)=O(q^2)\), proving (1). \(\square\)

## 2. Reverse direction and exact scope

Given \(U_1,\ldots,U_M\), each residue probability
\[
 \Pr\!\left[\sum_jU_j\equiv t\pmod R\right]
\]
is a symmetric-top CAPP query. The character expectation is their discrete Fourier
linear combination. Hence, when \(R\) and \(M\) are polynomially bounded, the two counting
primitives are polynomially interreducible.

The construction is deliberately selector-based. A single fixed original-variable frequency
\(\mathbb E_x\omega^{kS(x)}\) does not in general determine
\(\mathbb E f(S(x))\) for arbitrary \(f\): arbitrary profiles on \(\{0,\ldots,q\}\) require
\(\Omega(R)\) real Fourier dimensions in the worst case. The selectors \(a,s,u\), rather than
a hidden identity for one original frequency, provide the compression.

The growing modulus is also essential to this construction. Replacing \(R\) by a fixed
modulus can require exponentially many branches in the worst case. This is not a lower bound
for every fixed-modulus model; it identifies the parameter needed here, namely \(R>q\).

## 3. Consequence for depth-two threshold algorithms

Any method that first builds a general algorithm for all unweighted characters of this kind
and then recovers arbitrary symmetric tops by linearity cannot obtain a strictly easier
subproblem: the same primitive already represents arbitrary
\(\mathrm{SYM}\circ\mathrm{LTF}\)-CAPP after polynomial blow-up.

This is narrower than a CAPP lower bound. It leaves open algorithms that exploit a specific
recursive canonical profile, including cancellations invisible frequency by frequency. It also
leaves open models with a fixed modulus, a different query model, or a different gate family.

## 4. Relation to prior work and limitations

The result is a representation theorem and route boundary. It is not a claim that every
modular argument in the literature is subsumed by this construction. The closest materials
in the local literature map include mixed-radix and modular counting, modulus amplification,
and pseudorandom generators for functions of halfspaces; their standard formulations retain
an arbitrary symmetric lookup or use multiple characters.

The theorem does not prove a new lower bound against
\(\mathrm{THR}\circ\mathrm{THR}\), does not imply \(P\ne NP\), and does not show that a
particular CTW canonical profile is hard. Its precise contribution is to remove one proposed
generic shortcut: growing-modulus, unweighted single-character estimation is already complete
for general symmetric-top counting when selector variables are allowed.

## Sources

- Chen, Tal, and Wang, *Super-Quadratic Lower Bounds Against Depth-Two Threshold Circuits*,
  [ECCC TR26-039](https://eccc.weizmann.ac.il/report/2026/039/).
- Hatami, Hoza, Tal, and Tell, *Fooling Constant-Depth Threshold Circuits*,
  [ECCC TR21-002](https://eccc.weizmann.ac.il/report/2021/002/).
- Tamaki, *A Satisfiability Algorithm for Depth Two Circuits with a Sub-Quadratic Number of
  Symmetric and Threshold Gates*, [ECCC TR16-100](https://eccc.weizmann.ac.il/report/2016/100/).
- Williams, *New Algorithms and Lower Bounds for Circuits With Linear Threshold Gates*,
  [arXiv:1401.2444](https://arxiv.org/abs/1401.2444).
- [Project derivation note 009](../../notes/009-single-character-completeness.md).
