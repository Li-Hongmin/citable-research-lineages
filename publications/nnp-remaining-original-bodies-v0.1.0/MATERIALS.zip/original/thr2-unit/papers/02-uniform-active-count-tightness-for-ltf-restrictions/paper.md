# Uniform Active-Count Tightness for LTF Restrictions

## Abstract

We prove a uniform worst-case obstruction for restriction-based algorithms on depth-two
threshold circuits. For \(h=o(\sqrt N)\), and whenever \(qh/\sqrt N\gg N\), there is a
family of \(q\) linear threshold functions on \(N\) variables such that every restriction
leaving any set of \(h\) variables live, under every assignment to the other variables,
retains
\[
 \Theta\!\left(\frac{qh}{\sqrt N}\right)
\]
nonconstant bottom gates. The same family can be chosen with all pairwise normal vectors
nearly orthogonal. Thus pairwise anti-concentration, Gram-matrix regularity, and second-order
small-ball estimates cannot by themselves improve the first-order active-gate scale.

We also record a complementary multiplexing construction: an arbitrarily narrow nonzero cone
of threshold normals can still encode an arbitrary symmetric function of threshold outputs after
adding selector variables. Exact parallelism is therefore a singular tractable case; near
parallelism is not a general compression principle.

At the denser scale \(q/\sqrt N\gg N\), and for
\(h=O(\sqrt{N-h})\), a fixed threshold shift gives a stronger column-entropy obstruction:
for every \(h\)-element live set, the active-gate signature is injective on all \(2^{N-h}\)
assignments to the restricted variables, while every column still has only
\(\Theta(qh/\sqrt N)\) active gates. For one live variable, any sign-normal LTF family with
this full-cube injectivity must have

\[
 q=\Omega\!\left(\frac{N^{3/2}}{\log N}\right).
\]

The hybrid upper bound below is only a factor \(\sqrt{\log N}\) larger than this entropy
lower bound.

At the entropy scale, we also construct \(O(N/\log N)\) sampled-prefix centers whose
complete integer distance vectors are injective. However, a biased-layer entropy bound shows
that truncating any one prefix path to a fixed central window carries only \(O(\sqrt N)\)
entropy. Thus this prefix route needs \(\Omega(\sqrt N)\) paths and cannot close the
logarithmic exact-sphere gap.

A different hybrid construction does improve the separation bound: complete-distance
landmarks handle pairs at small Hamming distance, while wider central windows handle the
remaining pairs. It uses \(O(N^{3/2}/\sqrt{\log N})\) exact-sphere bits, reducing the gap to
the entropy lower bound to a factor \(\sqrt{\log N}\).

This hybrid bound is optimal within a broader pairwise first-moment template. One may prescribe
an arbitrary set of radii for each random center, with different and noncentral sets at
different centers. The antipodal or near-antipodal layer alone still forces
\(\Omega(N^{3/2}/\sqrt{\log N})\) queried spheres. Thus dyadic or multiscale windows do not
close the remaining gap by themselves; a successful improvement needs a different global
certificate, center-dependent radius selection, or other joint structure.

The largest even distance layer is nevertheless not a genuine lower-bound obstruction. In
even dimension, two adjacent centers with suitable congruence classes of radii separate this
antipodal layer using only \(M/2+O(1)\) exact-sphere bits. In odd dimension, three centers
separate the near-antipodal layer using \(M/2+O(1)\) bits: one center carries all positive
levels, while the other two need only levels \(1\) and \(3\). Matching linear lower bounds
follow by reduction to skew hyperplane covers. Thus both the antipodal and largest-even-layer
exact-shell covering numbers are \(\Theta(M)\), and the exponential pair count can collapse
under structured covering.

For arbitrary centers with one fixed central window of width \(A\sqrt M\), we give the exact
two-endpoint separation criterion and a universal center-count lower bound. If
\(q_A=\Pr[|G|\le A]\) for \(G\sim N(0,1)\), injectivity requires

\[
 P\ge\left(\frac{2\ln2}{q_A}+o(1)\right)\frac{M}{\ln M}.
\]

This excludes all smaller constants but leaves the target order open. The biased-layer
near-null argument for prefix paths cannot be extended rowwise to arbitrary centers: balanced
centers retain constant central mass on that layer. The remaining object is therefore a
tail-robust detecting matrix, not an ordinary detecting matrix or a prefix sketch.

The antipodal special case cannot supply a stronger center-count obstruction. With the same
fixed window, the minimum number of centers needed to separate every pair \(x,-x\) is
\(\Theta_A(\sqrt M)\). Thus antipodal collisions are already avoidable far below the
\(M/\ln M\) entropy scale; any stronger lower bound must use intermediate even-distance pairs
jointly. More generally, for every fixed \(r\), the entire distance-\((M-r)\) layer, when
even, has fixed-window center complexity \(\Theta_{A,r}(\sqrt M)\). Hence any
near-antipodal collision witness at the entropy scale must have a growing number of agreement
coordinates. A detecting-matrix modulation compresses the naive \(r+1\) coordinate flips to
\(O(r/\ln(r+2))\) modulations. More strongly, zero disagreement sums propagate along a
sufficiently fine prefix grid, so the detecting family need be attached at only one grid point.
For every fixed \(c<A/3\), the minimum number of centers that simultaneously separate every
pair with at most \(c\sqrt M\) agreement coordinates is \(\Theta_{A,c}(\sqrt M)\). Thus an
entire near-antipodal band is avoidable far below the \(M/\ln M\) entropy scale. At that
entropy scale, the agreement count can be arbitrary: one family separates every pair whose
signed agreement prefix path stays a fixed margin inside the central window. Any remaining
obstruction must therefore have large prefix discrepancy on its agreement coordinates. For the
complete family of prefix centers, collisions admit an exact cone characterization: every
nonzero disagreement partial sum must lie strictly inside an agreement-dominant excursion.
This forces agreement discrepancy greater than \(W+2\), and the threshold is sharp up to the
lattice spacing even for distance-two pairs. More generally, along dimensions divisible by
\(32\), centers in the radius-\(\rho\) neighborhood of the prefix path require
\[
 \Omega\!\left(\frac{M^2}{(W+\rho)\ln(2\rho+1)}\right)
\]
rows for every \(\ell_0=\lfloor W/4\rfloor\le\rho\le M/64\). At
\(\rho=\ell_0\) this is \(\Theta_A(M^{3/2}/\ln M)\), and any entropy-scale
injective family must contain a center at linear distance from the entire prefix path.
Two natural uses of such nonlocal centers still fail. One alternating center has maximal
subset-sum capacity simultaneously on every crossing slice in the prefix-neighborhood lower
bound, so those slice capacities cannot be added. Conversely, any family balanced on one
common even-block partition has an explicit block-indicator ternary kernel and is not
injective, regardless of its size.
Even the joint-kernel condition across all shifted crossing slices remains entropy-scale cheap:
one family of \(O(M/\ln M)\) centers, each at distance greater than \(M/4\) from the prefix
path, simultaneously gives a detecting matrix on every admissible shift. Thus endpoint
centrality, rather than simultaneous slice detection, is the unresolved condition in this
program.
A hybrid lower bound also quantifies how many exceptions are needed: \(K\) arbitrary centers
subtract at most \(K\ln(N+1)\) from every crossing-slice entropy requirement. Consequently,
along the same divisible-by-\(32\) dimensions, every injective family of size
\(O(M/\ln M)\) must contain
\(\Omega(M/\ln M)\) centers at linear Hamming distance from the entire prefix path.
On one crossing slice, however, even endpoint centrality is entropy-scale cheap. Sparse
detecting rows of weight \(O_A(\sqrt M)\), paired with one affine offset per row, give
\(\Theta_A(M/\ln M)\) actual sign centers for which every detected pair has both endpoints
inside the window. The remaining obstruction must therefore couple the affine offsets across
multiple slices.
Along the same divisible-by-\(32\) dimensions, those offsets can also be synchronized at the
entropy scale. A periodic even-coordinate
sequence makes every central crossing window have the same sum, while complementary choices
outside the variable-window union enforce the required affine offset identically. The resulting
\(O_A(M/\ln M)\) actual centers simultaneously separate every pair in every crossing slice
with both witnessed endpoints central. Thus the full crossing-slice witness system, not only
each slice separately, cannot yield a super-entropy obstruction.
More generally, exact constant-baseline synchronization cannot be extended to the whole
prefix-collision cone. Equality of the baselines on adjacent slices forces half-period equality
on the corresponding even coordinates, leaving an explicit distance-two pair in the common
kernel of every such center. The same pair is hidden from every prefix center by an agreement
plateau of height \(M/2-O(1)\). This closes exact constant-baseline synchronization, rather
than the possibility of varying or approximate baselines at the entropy scale.
That boundary is sharp at constant scale. By inserting cancelling adjacent defects into the
even-coordinate sequence, one can keep every shifted baseline within \([-4,4]\) while retaining
entropy-scale sparse detection and endpoint centrality on all crossing slices. Across the same
family, every half-period coordinate pair occurs with both equal and opposite signs, eliminating
both associated two-coordinate common kernels. Thus the exact-baseline obstruction disappears
after only constant baseline motion, although full-cube injectivity remains open.
For the complete Hamming-distance-two layer, arbitrary centers already face a square-root lower
bound. Fixing a coordinate pair and one of its two sign relations reduces the problem to covering
an \((M-2)\)-cube by central affine slabs; the skew-cover theorem forces
\(\Omega_A(\sqrt M)\) rows, while random centers give an \(O_A(M)\) upper bound. The
remaining gap is a simultaneous-sharing problem across all coordinate pairs. Within one fixed
prefix order it cannot be closed at the entropy scale: allowing modulations of radius
\(\Theta_A(\sqrt M)\) has exact distance-two complexity \(\Theta_A(M)\). Thus any
entropy-scale construction for the nearest even layer must use multiple orders or genuinely
global centers.

For the finite Walsh-star problem with eight blocks of size four and exact window zero, we
determine the unrestricted value
\(\nu_{3,0}(4,4,4,4,4,4,4,4)=6\). The lower bound combines the active-set rigidity with
complete proof-bundled classifications of both global branches; the upper bound is the
six-center Walsh construction. This value does not extrapolate as \(d+3\): in every even
Walsh dimension \(d\ge4\), an explicit character cut gives \(d+2\) block-constant centers
for all equal block sizes. These finite and structured results do not extend by themselves to
the full cube.

These are structural barriers for restriction-based CAPP and lower-bound templates. They do not
rule out algorithms using higher-order joint structure or prove a general
\(\mathrm{THR}\circ\mathrm{THR}\) lower bound.

## 1. Setup and main theorem

Represent variables by \(\{-1,1\}\). For \(w_i\in\{-1,1\}^N\), define
\[
 g_i(x)=1[\langle w_i,x\rangle\ge0],
 \qquad i\in[q].
\]
An \(h\)-restriction consists of a live coordinate set \(I\subseteq[N]\), \(|I|=h\),
and an assignment \(z\in\{-1,1\}^{[N]\setminus I}\) to the remaining coordinates. A gate
is active if the resulting function on the live coordinates is nonconstant.

### Theorem 1 (uniform active-count tightness)

Assume \(h=o(\sqrt N)\) and \(qh/\sqrt N\gg N\). Then there are sign vectors
\(w_1,\ldots,w_q\in\{-1,1\}^N\) such that for every \(I\) and \(z\),
\[
 A(I,z):=\#\{i:g_i|_{I,z}\text{ is nonconstant}\}
 =\Theta\!\left(\frac{qh}{\sqrt N}\right).
 \tag{1}
\]
If \(q\) is polynomial in \(N\), the vectors may moreover satisfy
\[
 \max_{i\ne j}\frac{|\langle w_i,w_j\rangle|}{N}
 \le \sqrt{\frac{6\log q}{N}}=o(1).
 \tag{2}
\]

### Proof

Fix \(I,z\). For gate \(g_i\), write
\[
 S_i=\sum_{j\notin I}w_{ij}z_j.
 \tag{3}
\]
The live contribution ranges over \(-h,-h+2,\ldots,h\), so
\[
 g_i|_{I,z}\text{ is nonconstant}
 \iff -h\le S_i<h.
 \tag{4}
\]
For independent random sign rows, \(S_i\) has the same distribution as a sum of \(N-h\)
independent signs. The local central-binomial estimate gives
\[
 p_N:=\Pr[-h\le S_i<h]
 =\left(\sqrt{\frac2\pi}+o(1)\right)\frac h{\sqrt N}.
 \tag{5}
\]
For fixed \(I,z\), \(A(I,z)\) is therefore \(\mathrm{Bin}(q,p_N)\), and Chernoff gives
\[
 \Pr\!\left[|A-qp_N|>\tfrac12qp_N\right]
 \le 2\exp(-qp_N/12).
 \tag{6}
\]
The number of pairs \((I,z)\) is at most
\[
 \binom Nh2^{N-h}\le3^N.
 \tag{7}
\]
The hypothesis \(qh/\sqrt N\gg N\) makes the union bound over all these pairs tend to zero.
Thus one choice of rows satisfies (1) simultaneously for every restriction.

For two independent sign rows, Hoeffding's inequality gives
\[
 \Pr\!\left[|\langle w_i,w_j\rangle|>\sqrt{6N\log q}\right]\le2q^{-3}.
 \tag{8}
\]
A union bound over row pairs shows that (2) holds with positive probability simultaneously
with the active-count event. Finally \(y_j=2x_j-1\) converts the construction into ordinary
\(\{0,1\}\)-LTFs. \(\square\)

## 2. Full column entropy from a fixed threshold shift

The zero-threshold construction above need not distinguish antipodal columns: depending on parity,
its active interval can be invariant under \(S\mapsto-S\). The constant threshold \(2\) removes
this degeneracy uniformly throughout the central-limit scale. Put

\[
 M=N-h
\]

and, for a fixed live set \(I\) and column \(z\in\{-1,1\}^{[N]\setminus I}\), define

\[
 \mathcal A_I(z)=\{i:g_i|_{I,z}\text{ is nonconstant}\}.
 \tag{9}
\]

### Theorem 2 (full-cube active-set separation)

For every fixed \(C>0\), suppose

\[
 1\le h\le C\sqrt M,
 \qquad
 \frac q{\sqrt M}\gg N.
 \tag{10}
\]

Then there are sign vectors \(w_1,\ldots,w_q\in\{-1,1\}^N\) such that the LTFs

\[
 g_i(x)=1[\langle w_i,x\rangle\ge2]
 \tag{11}
\]

satisfy, simultaneously for every \(I\in\binom{[N]}h\):

1. the map
   \[
   z\longmapsto\mathcal A_I(z)
   \tag{12}
   \]
   is injective on all of \(\{-1,1\}^{[N]\setminus I}\);
2. every column satisfies
   \[
   |\mathcal A_I(z)|
   =\Theta_C\!\left(\frac{qh}{\sqrt M}\right).
   \tag{13}
   \]

If \(q=N^{O(1)}\), the same family can satisfy

\[
 \max_{i\ne j}\frac{|\langle w_i,w_j\rangle|}{N}
 \le\sqrt{\frac{6\log q}{N}}=o(1).
 \tag{14}
\]

### Proof

We use the following standard local form of Stirling's estimate. For every fixed \(D>0\),
there are \(c_D>0\) and \(r_D\) such that

\[
 \Pr[R_r=u]\ge\frac{c_D}{\sqrt r}
 \tag{15}
\]

whenever \(r\ge r_D\), \(R_r\) is a sum of \(r\) independent signs,
\(u\in\{-r,-r+2,\ldots,r\}\), and \(|u|\le D\sqrt r\). Indeed, uniformly in this range,

\[
 \Pr[R_r=u]
 =\sqrt{\frac2{\pi r}}
   \exp\!\left(-\frac{u^2}{2r}\right)
   (1+O_D(r^{-1})).
 \tag{16}
\]

Choose the rows \(w_i\) independently and uniformly. Fix \(I,z\), and for one row put

\[
 S=S_z:=\sum_{j\notin I}w_jz_j.
 \tag{17}
\]

The live contribution ranges from \(-h\) to \(h\), so the threshold-\(2\) gate is active
exactly when

\[
 S\in K:=[2-h,2+h)\cap\{-M,-M+2,\ldots,M\}.
 \tag{18}
\]

The set \(K\) consists of \(h\) consecutive points of the parity lattice. If \(s_0\) is its
least point, its arithmetic center is

\[
 \gamma=s_0+h-1\in\{1,2\}.
 \tag{19}
\]

Every point of \(K\) has magnitude at most \(h+2\). Applying (15) pointwise, together with
the central-binomial upper bound, gives the one-gate activation probability

\[
 p:=\Pr[S\in K]
 =\Theta_C\!\left(\frac h{\sqrt M}\right).
 \tag{20}
\]

It remains to show that one random row separates every fixed pair of distinct columns with
probability \(\Omega_C(M^{-1/2})\). Let their Hamming distance be \(t\). Splitting the
restricted coordinates into the agreement and disagreement sets gives

\[
 S_z=A+B,\qquad S_{z'}=A-B,
 \tag{21}
\]

where \(A\sim R_a\), \(B\sim R_b\) are independent, \(a=M-t\), and \(b=t\).

First suppose \(t\le M/2\), so \(a\ge M/2\). The event

\[
 E_B=\{0<|B|\le2\sqrt b\}
\]

has probability at least \(1/4\): Chebyshev bounds the upper tail by \(1/4\), while the
largest atom of a nonempty Rademacher sum is at most \(1/2\). Conditional on \(B=v\in E_B\),
the two active bits differ exactly when

\[
 A\in(K-v)\mathbin\triangle(K+v).
 \tag{22}
\]

The two parity-lattice intervals in (22) have centers \(\gamma-v\) and \(\gamma+v\).
Since \(v\ne0\), their symmetric difference is nonempty. Every point in it has magnitude at
most

\[
 h+|v|+|\gamma|
 \le(C+2)\sqrt M+2.
 \tag{23}
\]

For sufficiently large \(M\), this bound is smaller than \(a\), so all these
parity-compatible points lie in the support of \(R_a\). Because \(a\ge M/2\), one point in
the symmetric difference has probability at least \(c_C/\sqrt M\) under \(R_a\), by (15).
Averaging over \(E_B\) yields a separation probability at least \(c_C/(4\sqrt M)\).

Now suppose \(t>M/2\), so \(b>M/2\). If \(a=0\), put \(E_A=\{A=0\}\); then
\(A\ne\gamma\). If \(a\ge1\), put

\[
 E_A=\{A\ne\gamma,\ |A|\le2\sqrt a\}.
\]

The same tail and maximal-atom bounds give \(\Pr[E_A]\ge1/4\). Conditional on
\(A=u\in E_A\), the two active bits differ exactly when

\[
 B\in(K-u)\mathbin\triangle(u-K).
 \tag{24}
\]

These intervals have centers \(\gamma-u\) and \(u-\gamma\), hence are distinct.
Their symmetric difference contains a parity-compatible point of magnitude at most
\((C+2)\sqrt M+2\). For sufficiently large \(M\), this point belongs to the support of
\(R_b\). Since \(b>M/2\), (15) again gives conditional separation probability at least
\(c_C/\sqrt M\). Thus, uniformly for all \(1\le t\le M\),

\[
 \Pr_w[
   1[S_z\in K]\ne1[S_{z'}\in K]
 ]
 \ge\frac{c_C}{\sqrt M}.
 \tag{25}
\]

For \(q\) independent rows, the active count of a fixed column is
\(\operatorname{Bin}(q,p)\), so Chernoff bounds failure of (13) by

\[
 2\exp\!\left(-\Omega_C\!\left(\frac{qh}{\sqrt M}\right)\right).
 \tag{26}
\]

For a fixed distinct pair, (25) bounds the probability of an active-set collision by

\[
 \exp\!\left(-\Omega_C\!\left(\frac q{\sqrt M}\right)\right).
 \tag{27}
\]

There are at most \(3^N\) pairs \((I,z)\), and the number of triples \((I,z,z')\) is
\(\exp(O(N))\). Assumption (10), together with \(h\ge1\), makes both union bounds tend to
zero. Hence one fixed family satisfies (12)--(13) for every live set and every column.
The Hoeffding argument from Theorem 1 gives (14) simultaneously when \(q\) is polynomial.
Every sign row is exactly \(N^{-1/2}\)-regular. \(\square\)

For the parameterization

\[
 q=N^{2.5-\varepsilon},\qquad
 h=N^{\varepsilon/10},\qquad
 0<\varepsilon<1,
 \tag{28}
\]

Theorem 2 applies and gives

\[
 |\mathcal A_I(z)|
 =N^{2-9\varepsilon/10+o(1)}
 =o(N^{2-\varepsilon/2}).
 \tag{29}
\]

Thus every column remains within the usual good-column active-gate budget, while all
\(2^{N-h}\) columns have different active sets for every choice of the live partition.

### Theorem 3 (near-optimal sign-normal gate count)

Let \(h=1\), fix a live coordinate \(I\), and consider arbitrary thresholds
\(\theta_1,\ldots,\theta_q\) and sign-normal gates

\[
 g_i(x)=1[\langle w_i,x\rangle\ge\theta_i],
 \qquad w_i\in\{-1,1\}^{M+1}.
\]

If \(z\mapsto\mathcal A_I(z)\) is injective on \(\{-1,1\}^M\), then

\[
 q=\Omega\!\left(\frac{M^{3/2}}{\log M}\right).
 \tag{30}
\]

### Proof

Let \(Z\) be uniform on \(\{-1,1\}^M\), and let \(Y_i=1[i\in\mathcal A_I(Z)]\).
For \(h=1\), the active interval

\[
 [\theta_i-1,\theta_i+1)
 \tag{31}
\]

contains at most one attainable value of the outside Rademacher sum. Hence the
central-binomial bound gives

\[
 p_i:=\Pr[Y_i=1]\le C M^{-1/2}.
 \tag{32}
\]

Injectivity makes \(Z\) a function of \(Y=(Y_1,\ldots,Y_q)\). Therefore

\[
 M=H(Z)=H(Y)
 \le\sum_{i=1}^q H_2(p_i)
 \le C' q\frac{\log M}{\sqrt M},
 \tag{33}
\]

which proves (30). \(\square\)

The sign-normal hypothesis is essential to this entropy proof: with arbitrary weights, a
width-\(2|w_{i,I}|\) interval can contain many subset-sum levels. Thus Theorem 3 is a lower
bound for the construction class of Theorems 1--2, not for unrestricted LTF families.

### Proposition 4 (equatorial coverage is cheap)

For every \(M\ge9\), there is a set \(C_M\subseteq\{-1,1\}^M\) of
\((1+o(1))\sqrt M\), and in particular at most \(2\sqrt M+2\), centers such
that every \(z\in\{-1,1\}^M\) satisfies

\[
 \min_{c\in C_M}|\langle c,z\rangle|\le2\sqrt M.
\]

Equivalently, every cube vertex lies within \(\sqrt M\) of the equatorial Hamming
distance \(M/2\) from some center in \(C_M\).

#### Proof

Put

\[
 D=\left\lfloor\sqrt M-\frac12\right\rfloor
\]

and sample the prefix lengths

\[
 R=\{0,D,2D,\ldots,\lfloor M/D\rfloor D\}\cup\{M\}.
\]

For \(r\in R\), let \(c^{(r)}_j=1\) for \(j\le r\) and \(c^{(r)}_j=-1\) for
\(j>r\). Fix \(z\), and extend the definition to every \(0\le r\le M\) by

\[
 F(r)=\langle c^{(r)},z\rangle
 =2\sum_{j\le r}z_j-\sum_{j=1}^M z_j.
\]

The endpoints are opposite,

\[
 F(0)=-\sum_jz_j,\qquad F(M)=\sum_jz_j,
\]

and every step changes \(F\) by exactly \(2\) in absolute value. Hence some
\(r_\ast\in[0,M]\) satisfies \(|F(r_\ast)|\le1\). A sampled \(r\in R\) obeys
\(|r-r_\ast|\le D\), and therefore

\[
 |F(r)|\le1+2D\le2\sqrt M.
\]

Finally, \(D\ge\sqrt M/2\) for \(M\ge9\), so

\[
 |C_M|=|R|\le\left\lceil\frac MD\right\rceil+1\le2\sqrt M+2.
\]

\(\square\)

Thus worst-case access to the central distance window is not the source of the
logarithmic gap in Theorems 2--3. Querying all \(O(\sqrt M)\) central radii around
these \(O(\sqrt M)\) centers uses only \(O(M)\) exact-sphere bits and gives every
vertex a nonzero response. The same family separates every pair \(x,y\) at odd
Hamming distance: for every center \(c\),

\[
 d_H(c,x)+d_H(c,y)\equiv d_H(x,y)\pmod2,
\]

so the two exact distances cannot coincide, and a central response of \(x\) is
either absent for \(y\) or occurs at a different radius. The unresolved
requirement is therefore simultaneous separation of the even-distance pairs,
not equatorial coverage of individual vertices.

A natural attempt to reach the entropy scale is to repeat the sampled-prefix
construction along \(P\) coordinate permutations. This attempt itself has a sharp
information constraint. Each permutation partitions the coordinates into
\(B=\lceil M/D\rceil=(1+o(1))\sqrt M\) consecutive blocks of sizes
\(d_1,\ldots,d_B\le D\). For uniform \(Z\), the complete vector of sampled prefix
inner products is equivalent to the independent block sums, and hence has entropy

\[
 \sum_{b=1}^{B}H(R_{d_b})
 =\left(\frac14+o(1)\right)\sqrt M\log_2M.
\]

Every exact-sphere signature using those centers is a function of the complete
prefix vectors. Consequently, injectivity after \(P\) permutations requires

\[
 P\ge(4-o(1))\frac{\sqrt M}{\log_2M}.
\]

Equivalently, below this constant threshold the block-incidence matrix has two
different \(0/1\) column subsets with the same sum, so collision already occurs
before the central-window truncation. The order, though not the constant, is
attainable by complete prefix sketches.

### Proposition 5 (complete prefix sketches attain the entropy order)

Fix \(K>4\ln 3\), put \(B=\lceil\sqrt M\rceil\), and let

\[
 P=\left\lceil\frac{KB}{\ln M}\right\rceil.
\]

There are \(P\) coordinate permutations, each partitioned into at most \(B\)
consecutive blocks, such that every block has size at most \(2M/B\) and the
combined block-incidence matrix \(A\) satisfies

\[
 \ker(A)\cap\{-1,0,1\}^M=\{0\}.
 \tag{33a}
\]

Consequently, the complete integer-valued inner products at the block-boundary
prefix centers form an injective sketch of \(\{-1,1\}^M\). The construction uses
\(O(M/\ln M)\) centers, with successive boundary gaps \(O(\sqrt M)\).

#### Proof

For each of the \(P\) partitions, independently hash the \(M\) coordinates
uniformly into \(B\) labelled buckets. If a nonzero
\(v\in\{-1,0,1\}^M\) lies in the kernel, summing the bucket equations shows that
\(v\) has equally many \(+1\) and \(-1\) entries; denote this number by \(s\).
There are

\[
 N_s=\frac{M!}{s!^2(M-2s)!}
\]

such vectors. For one random partition, its positive and negative supports have
the same bucket occupancies with probability

\[
 p_s=\sum_{n_1+\cdots+n_B=s}
 \left(\frac{s!}{B^s\prod_b n_b!}\right)^2.
 \tag{33b}
\]

Two elementary bounds control all support sizes. First,

\[
 p_s\le \frac{s!}{B^s}\le\left(\frac{s}{B}\right)^s.
 \tag{33c}
\]

Second, collision probability is at most the largest atom of the multinomial
distribution. Stirling's bounds, with the maximizing occupancy vector balanced,
give uniformly for \(s\ge2B\)

\[
 p_s\le 3\sqrt s\left(\frac{B}{\pi s}\right)^{B/2}.
 \tag{33d}
\]

We apply a union bound to \(\sum_{s\le M/2}N_sp_s^P\). For
\(s\le B/2\), (33c) and \(N_s\le(eM/s)^{2s}\) make the sum \(o(1)\).
For \(B/2<s<2B\), the sharper Stirling form
\(s!/B^s\le3\sqrt s(s/(eB))^s\) gives the same conclusion. For
\(2B\le s\le M/(\ln M)^2\), (33d) contributes

\[
 \log p_s^P\le
 -\left(\frac{K\ln(2\pi)}2+o(1)\right)\frac{M}{\ln M},
\]

whereas \(\log N_s=o(M/\ln M)\). For
\(M/(\ln M)^2\le s\le\delta M\), (33d) instead gives

\[
 \log p_s^P\le-\left(\frac K4-o(1)\right)M;
\]

choosing fixed \(\delta>0\) sufficiently small absorbs
\(\log N_s\le2\delta M\ln(e/\delta)\). Finally, for
\(\delta M\le s\le M/2\), the same probability bound and
\(\sum_sN_s\le3^M\) give

\[
 \sum_{\delta M\le s\le M/2}N_sp_s^P
 \le \exp\left[\left(\ln3-\frac K4+o(1)\right)M\right]=o(1).
\]

Thus (33a) holds with probability \(1-o(1)\). A bucket load is
\(\operatorname{Bin}(M,1/B)\), so Chernoff and a union bound over the
\(PB=O(M/\ln M)\) buckets show simultaneously that every load is at most
\(2M/B\), again with probability \(1-o(1)\).

For each partition, concatenate the buckets in label order and order coordinates
arbitrarily inside each bucket. Differences of consecutive sampled prefix sums are
exactly the bucket sums. Hence equality of all complete prefix sketches for
\(z,z'\) implies \(A(z-z')=0\), and (33a) implies \(z=z'\). \(\square\)

Proposition 5 identifies the remaining obstruction precisely. Querying the
\(O(\sqrt M)\) central radii around all of its \(O(M/\ln M)\) centers has the
target count \(O(M^{3/2}/\ln M)\), but it replaces each complete integer value by
a central-window one-hot value (or by no response). Proposition 5 does not show
that this truncation preserves injectivity. In fact, no choice of the same
number of prefix paths can do so.

### Proposition 6 (prefix truncation has a biased-layer obstruction)

This is a two-sided central-window truncation, not the standard graph metric
\(d_k(u,v)=\min\{d(u,v),k+1\}\), which retains all nearby distances and merges
only the far tail.

Fix \(A>0\), and let \(W=A\sqrt M\). Consider \(P\) coordinate permutations,
with any set of prefix boundaries sampled from each one. At every sampled
boundary retain the exact inner product if it lies in \([-W,W]\), and write
\(\bot\) otherwise. If the combined truncated sketch is injective on
\(\{-1,1\}^M\), then

\[
 P=\Omega_A(\sqrt M).
 \tag{33e}
\]

If, in addition, consecutive boundaries in every path differ by at least
\(c\sqrt M\), then the stronger bound

\[
 P=\Omega_{A,c}\!\left(\frac{M}{\log M}\right)
 \tag{33f}
\]

holds. Consequently, for any fixed \(K\), no family of
\(P=K\sqrt M/\log M\) such paths has an injective central truncation for all
sufficiently large \(M\). This applies to every realization of Proposition 5's
random hash construction, although its complete integer-valued sketch is
injective with probability \(1-o(1)\).

#### Proof

Restrict the input to the biased layer

\[
 \mathcal L=\{z:\#\{j:z_j=-1\}=\lfloor M/4\rfloor\}.
\]

For clarity assume \(4\mid M\); replacing \(M/4\) by \(\lfloor M/4\rfloor\)
changes the following means by only \(O(1)\). Let \(Z\) be uniform on
\(\mathcal L\). For one path and one boundary \(r_b\),
write \(N_b\) for the number of negative coordinates among its first \(r_b\)
positions. The prefix-center inner product is

\[
 F_b=2r_b-4N_b-\frac M2,
 \qquad
 \mathbb E F_b=\frac{2r_b-M}{2}.
 \tag{33g}
\]

Hypergeometric Hoeffding bounds give, for every \(t\ge0\),

\[
 \Pr[|F_b-\mathbb EF_b|\ge t]
 \le2\exp\!\left(-\frac{t^2}{8M}\right).
 \tag{33h}
\]

We first prove a maximal form of (33h). Extend \(N_r\) to every rank and put
\(S_r=N_r-r/4\). Conditional sampling without replacement gives

\[
 \mathbb E[S_{r+1}\mid S_r]
 =\frac{M-r-1}{M-r}S_r.
\]

Hence \(S_r/(M-r)\) is a martingale for \(r\le M/2\), with increments
\(O(1/M)\). The maximal Azuma inequality, followed by the same argument for the
reversed suffix when \(r\ge M/2\), gives an absolute \(c_0>0\) such that

\[
 \Pr\!\left[\max_{0\le r\le M}|S_r|\ge t\right]
 \le4\exp\!\left(-c_0\frac{t^2}{M}\right).
 \tag{33i}
\]

Let \(\ell=\lceil\sqrt M\rceil\) and divide the ranks on either side of \(M/2\)
into slabs of width \(\ell\). In a slab at distance between \(k\ell\) and
\((k+1)\ell\) from \(M/2\), the mean in (33g) has magnitude at least
\(k\ell\). If \(k>A+2\) and some sampled boundary in this slab has
\(|F_b|\le W\), then (33g) and \(F_r-\mathbb EF_r=-4S_r\) imply

\[
 \max_r|S_r|\ge\frac{(k-A)\sqrt M}{4}.
\]

Thus (33i) bounds the probability \(p_k\) that the slab has any non-\(\bot\)
output by

\[
 p_k\le4\exp(-c_1(k-A)^2)
\]

for another absolute \(c_1>0\); for the \(O_A(1)\) central slabs take
\(p_k=1\). All raw prefix values sampled inside one slab are determined by the
first such value, with at most \(2M+1\) possibilities, and by the signs of at
most \(\ell\) intervening coordinates. Hence the non-null slab output has at
most \((2M+1)2^\ell\) possibilities. If \(Y^{(k)}\) is its entire truncated
output vector, then

\[
 H(Y^{(k)})
 \le h_2(p_k)+p_k\ln((2M+1)2^\ell)
 \le h_2(p_k)+O(p_k\sqrt M).
\]

The Gaussian series \(\sum_k p_k\) and \(\sum_k h_2(p_k)\) converge, uniformly
in \(M\). Summing over both sides of \(M/2\) proves that an arbitrary single
truncated path has entropy \(O_A(\sqrt M)\). Subadditivity across paths and
injectivity on \(\mathcal L\) would imply

\[
 \Theta(M)=\ln\binom{M}{M/4}
 \le O_A(P\sqrt M),
 \tag{33j}
\]

which proves (33e).

For the stronger assertion, put \(p_b=\Pr[|F_b|\le W]\) and
\(a_b=(2r_b-M)/\sqrt M\). Equations (33g)--(33h) imply Gaussian decay of
\(p_b\) once \(|a_b|>2A\), while the gap assumption makes consecutive
\(a_b\)'s at least \(2c\) apart. Hence, uniformly over the path,

\[
 \sum_b p_b\le C_{A,c},
 \qquad
 \sum_b h_2(p_b)\le C_{A,c},
\]

where \(h_2\) denotes binary entropy in nats. Indeed, the terms outside the
constant-size central set are bounded by a summable Gaussian sequence, and
\(h_2(p)\le p(1+\ln(1/p))\) when \(p\le1/2\).

Since the central alphabet has at most \(2W+1\) values,

\[
 H((Y_b)_b)
 \le\sum_b\bigl(h_2(p_b)+p_b\ln(2W+2)\bigr)
 =O_{A,c}(\log M).
\]

Another application of subadditivity proves (33f). \(\square\)

Thus the full block-sum problem is settled at the entropy order, but every
prefix path carries only \(O_A(\sqrt M)\) truncated entropy on a biased layer.
Nonuniform or multiscale boundaries do not repair the target path count. The
general exact-sphere upper bound remains open, but this fixed-window prefix-path
route to it is closed.

### Proposition 7 (hybrid exact-sphere separation saves a square root of the logarithm)

Let \(\sigma(M)\) be the minimum number of pairs \((c_i,r_i)\), with
\(c_i\in\{-1,1\}^M\) and \(0\le r_i\le M\), for which

\[
 z\longmapsto\bigl(1[d_H(c_i,z)=r_i]\bigr)_i
\]

is injective on \(\{-1,1\}^M\). Then

\[
 \sigma(M)=O\!\left(\frac{M^{3/2}}{\sqrt{\log M}}\right).
 \tag{33k}
\]

Together with Theorem 3, this gives

\[
 \Omega\!\left(\frac{M^{3/2}}{\log M}\right)
 \le\sigma(M)\le
 O\!\left(\frac{M^{3/2}}{\sqrt{\log M}}\right).
 \tag{33l}
\]

#### Proof

It is enough to consider sufficiently large \(M\). Put

\[
 T=\left\lfloor\frac{\sqrt M}{(\ln M)^{3/2}}\right\rfloor.
\]

The construction has two independent parts. First choose

\[
 q_0=\left\lceil4T\ln(M/T)\right\rceil
\]

uniform random sign centers and query every radius around each one. For a pair
\(x,y\), let \(v=(x-y)/2\in\{-1,0,1\}^M\) and
\(t=|\operatorname{supp}v|=d_H(x,y)\). One center gives equal complete
distances precisely when

\[
 \langle c,v\rangle=0.
\]

For random \(c\), the left side is a sum \(R_t\) of \(t\) independent signs.
Its zero probability is \(0\) for odd \(t\), and at most \(1/2\) for even
\(t\ge2\). The number of nonzero difference vectors supported on at most \(T\)
coordinates is at most

\[
 D_T:=\sum_{t=1}^{T}\binom Mt2^t
 \le T\left(\frac{2eM}{T}\right)^T.
\]

Therefore \(D_T2^{-q_0}=o(1)\), and with probability \(1-o(1)\) the first part
separates every pair with \(d_H(x,y)\le T\). It uses \(q_0(M+1)\) sphere bits.

For the second part, put

\[
 W=2\sqrt{M\ln M},
 \qquad
 q_1=\left\lceil\frac{10M}{\ln M}\right\rceil.
\]

Choose \(q_1\) new independent random sign centers. Around each center query all
radii corresponding to attainable inner products \(u\) with \(|u|\le W\), and
write \(\tau_W(u)=u\) in this window and \(\tau_W(u)=\bot\) outside it. Fix a
pair at distance \(t>T\). After multiplying the random center coordinates by
\(x\), split their sum over the agreement and disagreement coordinates as
\(Q\) and \(R\). Then

\[
 \langle c,x\rangle=Q+R,
 \qquad
 \langle c,y\rangle=Q-R,
 \qquad
 R\sim R_t,\qquad Q+R\sim R_M.
\]

If the two truncated values collide, either both are outside the window, or
they are equal inside it. Hence

\[
 \Pr[\tau_W(Q+R)=\tau_W(Q-R)]
 \le\Pr[R=0]+\Pr[|Q+R|>W]
 \le t^{-1/2}+2e^{-W^2/(2M)}.
 \tag{33m}
\]

For all sufficiently large \(M\), the right side is at most
\(T^{-1/2}+2M^{-2}\le M^{-1/5}\). A union bound over fewer than \(4^M\)
ordered pairs now gives

\[
 4^M(M^{-1/5})^{q_1}
 \le\exp((\ln4-2)M)=o(1).
\]

Thus the second part simultaneously separates all pairs at distance greater
than \(T\) with probability \(1-o(1)\). The two successful families can be
fixed simultaneously. Since one second-part center uses at most \(W+2\)
attainable radii,

\[
 q_0(M+1)+q_1(W+2)
 =O\!\left(\frac{M^{3/2}}{\sqrt{\ln M}}\right).
\]

The finitely many smaller \(M\) are absorbed into the constant. \(\square\)

### Proposition 8 (heterogeneous radius sets do not improve pairwise first moments)

Let

\[
 \Lambda_M=\{-M,-M+2,\ldots,M\}.
\]

Fix arbitrary sets \(S_j\subseteq\Lambda_M\), and then sample the corresponding sign centers
independently and uniformly, querying the \(|S_j|\) spheres specified by \(S_j\). If
injectivity is certified by a pairwise first-moment bound, then

\[
 Q:=\sum_j|S_j|
 =\Omega\!\left(\frac{M^{3/2}}{\sqrt{\ln M}}\right).
 \tag{33n}
\]

Here a pairwise first-moment certificate has one bad event for every unordered point pair,
or uses the usual layerwise compression to oriented-difference bad events, and bounds their
sum below one from the independent per-center collision probabilities. The sets \(S_j\) may
be noncentral, asymmetric, heterogeneous, or multiscale. In view of Proposition 7, the
optimal cost in this template is

\[
 \Theta\!\left(\frac{M^{3/2}}{\sqrt{\ln M}}\right).
 \tag{33o}
\]

#### Proof

Let

\[
 n=2\lfloor M/2\rfloor\in\{M-1,M\}
\]

be the largest even distance, and fix a pair at distance \(n\). For a fresh random center,
write the two inner products as

\[
 U=C+A,\qquad V=C-A,
\]

where \(A\sim R_n\), \(C\sim R_{M-n}\), and \(|C|\le1\). For a set
\(S\subseteq\Lambda_M\), let \(\ell=|S|\), and retain an inner product exactly when it
belongs to \(S\). Conditional on \(C=c\), separation implies

\[
 A\ne0,
 \qquad
 A\in(S-c)\cup(c-S).
 \tag{33p}
\]

The set on the right has at most \(2\ell\) elements. Let
\(\pi_{(1)}\ge\pi_{(2)}\ge\cdots\) be the atom probabilities of \(R_n\) in decreasing
order, and let \(\rho(S)\) be this center's collision probability. Equation (33p), first
conditional on either value of \(C\) and then averaged, gives

\[
 1-\rho(S)\le\sum_{r\le2\ell}\pi_{(r)},
 \qquad
 \rho(S)\ge\Pr[R_n=0]=\Theta(M^{-1/2}).
 \tag{33q}
\]

Put \(b(S)=-\ln\rho(S)\). The atom sequence is symmetric and unimodal. Its largest atom is
\(O(M^{-1/2})\), while Stirling's formula on a block of \(\Theta(\sqrt M)\) consecutive
atoms gives

\[
 \Pr[|R_n|>u]\ge c\exp(-C(1+u^2/n)),
 \qquad \sqrt n\le u\le n/2.
 \tag{33r}
\]

If \(\ell\le\varepsilon\sqrt M\) for a sufficiently small absolute \(\varepsilon\), the
largest-atom bound makes the sum in (33q) at most \(C\ell/\sqrt M\le1/2\), so
\(b(S)\le C\ell/\sqrt M\). If
\(\varepsilon\sqrt M<\ell\le\sqrt M\), the largest \(2\ell\) atoms are central and a
fixed block outside them has constant mass, which gives the same inequality after changing
the constant. For \(\sqrt M<\ell\le\sqrt{M\ln M}\), a block of \(\Theta(\sqrt M)\)
atoms just beyond the largest \(2\ell\), together with (33r), gives
\(b(S)\le C\ell^2/M\). For larger \(\ell\), the central atom in (33q) gives
\(b(S)\le C\ln M\). Thus, uniformly over all \(S\),

\[
 b(S)\le C
 \begin{cases}
 \ell/\sqrt M,&1\le\ell\le\sqrt M,\\
 \min\{\ell^2/M,\ln M\},&\sqrt M<\ell\le M+1.
 \end{cases}
 \tag{33s}
\]

If \(b(S)=0\), the center buys no collision exponent. Otherwise (33s), split at
\(\ell=\sqrt{M\ln M}\), gives

\[
 \frac{\ell}{b(S)}
 \ge c\sqrt{\frac M{\ln M}}.
 \tag{33t}
\]

Return to the sequence \(S_j\). Independence of the centers makes the collision probability
of a fixed pair equal to \(\prod_j\rho(S_j)\). The distance-\(n\) layer contains

\[
 2^{M-1}\binom Mn\ge2^{M-1}
\]

unordered point pairs. If a first-moment proof instead groups this layer by oriented
differences up to reversal, it still has at least \(2^{M-1}\) bad events, and each grouped
event has probability at least that of any representative pair. Therefore a first-moment sum
below one requires

\[
 \sum_j b(S_j)\ge(M-1)\ln2.
\]

Multiplying by (33t) and summing over centers proves (33n). Proposition 7 supplies the
matching upper bound. \(\square\)

The timing of the quantifiers is essential. If \(S_j\) may depend on its own exposed center,
then for a fixed \(x_*\) the one-element choice

\[
 S(c)=\{\langle c,x_*\rangle\}
\]

buys \(\Theta(\ln M)\) collision exponent on \((x_*,-x_*)\) when \(M\) is even, and
separates that pair surely when \(M\) is odd. This does not give a cheap injective family,
but it invalidates the per-center estimate (33t). Proposition 8 is therefore a route closure,
not a stronger lower bound on \(\sigma(M)\): it does not cover center-dependent radius sets,
grouped collision events beyond oriented differences, or certificates exploiting global
dependence among pairs.

### Proposition 9 (antipodal exact-shell covering is linear)

Let \(\alpha(M)\) be the minimum number of exact-sphere bits needed to separate every
antipodal pair:

\[
 \alpha(M)=\min\left\{q:
 \begin{array}{l}
 \exists (c_i,r_i)_{i=1}^q\in
 \bigl(\{-1,1\}^M\times\{0,\ldots,M\}\bigr)^q\text{ such that}\\
 \forall x\in\{-1,1\}^M\ \exists i\le q:\quad
 1[d_H(c_i,x)=r_i]\ne1[d_H(c_i,-x)=r_i]
 \end{array}
 \right\}.
 \tag{33u}
\]

For every \(M\ge2\),

\[
 \max\left\{\frac M4,\frac{2^{M-1}}{B_M}\right\}\le\alpha(M)\le
 \begin{cases}
 (M+1)/2,&M\text{ odd},\\
 2\lceil M/4\rceil,&M\text{ even},
 \end{cases}
 \tag{33v}
\]

where

\[
 B_M=
 \begin{cases}
 \binom M{(M-1)/2},&M\text{ odd},\\
 \binom M{M/2-1},&M\text{ even}.
 \end{cases}
 \tag{33w}
\]

In particular,

\[
 \frac M4\le\alpha(M)\le\frac M2+O(1),
 \qquad\text{and hence}\qquad
 \alpha(M)=\Theta(M).
 \tag{33x}
\]

#### Proof

Write a queried radius as the inner-product level \(s=M-2r\). If \(s=0\), the bit takes
the same value on \(x\) and \(-x\) and separates no antipodal pair. If \(s\ne0\), the bit
separates precisely those pairs for which

\[
 |\langle c,x\rangle|=|s|.
\]

It therefore covers exactly \(\binom Mr\) of the \(2^{M-1}\) antipodal pairs. The largest
available noncentral layer has size \(B_M\), proving the lower bound in (33v); Stirling's
formula shows that this elementary volume argument alone gives
\(\sqrt{\pi M/8}(1-o(1))\).

For the linear lower bound, associate to every queried nonzero level \(s_i\) the two affine
hyperplanes

\[
 H_i^+=\{x:\langle c_i,x\rangle=s_i\},
 \qquad
 H_i^-=\{x:\langle c_i,x\rangle=-s_i\}.
\]

Queries at level zero can be deleted, since they separate no antipodal pair. Condition (33u)
then says exactly that the resulting collection of at most \(2\alpha(M)\) hyperplanes covers
every vertex of \(\{-1,1\}^M\). After the affine change of variables
between \(\{-1,1\}^M\) and \(\{0,1\}^M\), every normal vector still has all coordinates
nonzero because \(c_i\in\{-1,1\}^M\). The collection is therefore a skew cover of the
hypercube. Theorem 1 of Sauermann and Xu, applied to this skew cover, gives at least
\(M/2\) hyperplanes, and hence \(2\alpha(M)\ge M/2\), proving \(\alpha(M)\ge M/4\).

For the odd-dimensional upper bound, fix one center \(c\) and query every positive attainable
level

\[
 s=1,3,\ldots,M.
\]

For every \(x\), the inner product \(a=\langle c,x\rangle\) is a nonzero odd integer.
Exactly one of \(x,-x\) therefore responds to the bit at level \(|a|\). This uses
\((M+1)/2\) bits.

Now let \(M\) be even. Fix a center \(c\), and let \(c'\) be obtained by flipping one of
its coordinates. At each of the two centers query all positive levels

\[
 s\equiv2\pmod4.
\]

For a fixed \(x\), put \(a=\langle c,x\rangle\) and
\(a'=\langle c',x\rangle=a\pm2\). If \(a\equiv2\pmod4\), then \(a\ne0\) and the first
center separates \(x,-x\) at level \(|a|\). If \(a\equiv0\pmod4\), then
\(a'\equiv2\pmod4\) and \(a'\ne0\), so the second center separates the pair at level
\(|a'|\). Each center uses \(\lceil M/4\rceil\) bits, proving the upper bound. \(\square\)

Propositions 8--9 isolate the distinction between two proof regimes. Independent random
centers assessed pair by pair pay an exponential union-bound cost on the largest even layer.
For even \(M\), that layer is antipodal, and two correlated deterministic centers cover it with
only \(O(M)\) queries. In either parity, antipodal coverage alone cannot explain the remaining
exact-sphere gap; simultaneous control of many intermediate distance layers is still needed.

### Proposition 10 (the largest even distance layer has a linear structured cover)

Put \(n_M=2\lfloor M/2\rfloor\), and let \(\beta(M)\) be the minimum number of
exact-sphere bits needed to separate every pair at distance \(n_M\):

\[
 \beta(M)=\min\left\{q:
 \begin{array}{l}
 \exists(c_i,r_i)_{i=1}^q\in
 \bigl(\{-1,1\}^M\times\{0,\ldots,M\}\bigr)^q\text{ such that}\\
 \forall x,y\in\{-1,1\}^M\text{ with }d_H(x,y)=n_M\ \exists i\le q:\quad
 1[d_H(c_i,x)=r_i]\ne1[d_H(c_i,y)=r_i]
 \end{array}
 \right\}.
 \tag{33y}
\]

For every \(M\ge2\),

\[
 \frac{n_M}{4}\le\beta(M)\le
 \begin{cases}
 2\lceil M/4\rceil,&M\text{ even},\\
 (M+1)/2+4,&M\text{ odd}.
 \end{cases}
 \tag{33z}
\]

In particular, \(\beta(M)=\Theta(M)\).

#### Proof

If \(M\) is even, then \(n_M=M\), so \(\beta(M)=\alpha(M)\), and Proposition 9
proves both bounds.

Now let \(M\) be odd and put \(n=M-1\). For the lower bound, fix one coordinate
\(j\) and one sign \(\varepsilon\). The distance-\(n\) pairs agreeing there with value
\(\varepsilon\) are

\[
 (x,y)=((\varepsilon,u),(\varepsilon,-u)),
 \qquad u\in\{-1,1\}^{n},
\]

where the displayed coordinate is understood to be in position \(j\). Restrict a queried
bit with center \(c\) and level \(s=M-2r\) to this slice. Put

\[
 d=c_{-j},\qquad \delta=c_j\varepsilon,\qquad t=s-\delta.
\]

The two endpoints respond precisely when

\[
 \langle d,u\rangle=t
 \qquad\text{and}\qquad
 \langle d,u\rangle=-t,
\]

respectively. If \(t=0\), the bit never separates the pair. If \(t\ne0\), it separates
exactly the antipodal pairs covered by the \(n\)-dimensional exact-sphere bit at level \(t\).
Conversely, every \(n\)-dimensional sphere bit lifts to this slice by taking
\(c_j=\varepsilon\) and the same radius. Hence the minimum covering number on this fixed
slice is exactly \(\alpha(n)\). Any family covering the full distance-\(n\) layer covers the
slice, so Proposition 9 gives

\[
 \beta(M)\ge\alpha(M-1)\ge\frac{M-1}{4}=\frac{n_M}{4}.
\]

For the upper bound, fix a center \(c\), and let \(c^{(1)}\) and \(c^{(2)}\) be obtained
by flipping its first and second coordinates. At \(c\), query all positive attainable levels
\(1,3,\ldots,M\). At each of \(c^{(1)},c^{(2)}\), query only levels \(1\) and \(3\).
This uses \((M+1)/2+4\) bits.

Fix \(x,y\) at distance \(M-1\), and let \(j\) be their unique agreement coordinate. Write

\[
 t=c_jx_j\in\{-1,1\},
 \qquad
 u=\sum_{k\ne j}c_kx_k\in2\mathbb Z.
\]

The two inner products at \(c\) are \(t+u\) and \(t-u\). If \(u\ne0\), then
\(|u|\ge2>|t|\), so these values have opposite signs. The unique positive-level response at
\(c\) separates the pair.

If \(u=0\), choose \(k\in\{1,2\}\setminus\{j\}\). Since \(k\) is a disagreement
coordinate, replacing \(c\) by \(c^{(k)}\) leaves \(t\) unchanged and replaces \(u\) by

\[
 u'=-2c_kx_k\in\{-2,2\}.
\]

The two inner products at \(c^{(k)}\) are therefore \(\{3,-1\}\) if \(t=1\), and
\(\{1,-3\}\) if \(t=-1\). The queried level \(3\) or \(1\), respectively, separates
the pair. This proves the upper bound. \(\square\)

Proposition 10 closes the parity gap left by Proposition 9: in every dimension, the largest
even distance layer has a deterministic \(\Theta(M)\)-bit cover. Proposition 8's
\(\Theta(M^{3/2}/\sqrt{\ln M})\) cost for that layer is therefore a limitation of the
independent-center pairwise first-moment certificate, not an intrinsic covering cost of the
layer.

### Proposition 11 (fixed central truncation has a universal entropy constant)

Fix \(A>0\), put \(W=A\sqrt M\), and define

\[
 \tau_W(u)=
 \begin{cases}
 u,&|u|\le W,\\
 \bot,&|u|>W.
 \end{cases}
 \qquad
 F_C(x)=\bigl(\tau_W(\langle c_j,x\rangle)\bigr)_{j\le P},
 \quad c_j\in\{-1,1\}^M.
 \tag{33aa}
\]

For \(x\in\{-1,1\}^M\) and nonempty \(S\subseteq[M]\), let \(x^S\) be obtained by
flipping the coordinates in \(S\), and put

\[
 T_j=\sum_{k=1}^M c_{j,k}x_k,
 \qquad
 D_j(S)=\sum_{k\in S}c_{j,k}x_k.
\]

Then \(F_C\) is injective if and only if, for every \(x\) and every nonempty \(S\), some
\(j\le P\) satisfies

\[
 D_j(S)\ne0,
 \qquad
 |T_j|\le W\ \text{ or }\ |T_j-2D_j(S)|\le W.
 \tag{33ab}
\]

Let \(G\sim N(0,1)\) and \(q_A=\Pr[|G|\le A]\). If \(F_C\) is injective, then

\[
 P\ge
 \left(\frac{2\ln2}{q_A}+o(1)\right)\frac{M}{\ln M}.
 \tag{33ac}
\]

Consequently, for every fixed \(C<2\ln2/q_A\), no family with
\(P\le CM/\ln M\) is injective for all sufficiently large \(M\).

#### Proof

For \(y=x^S\), direct expansion gives

\[
 \langle c_j,y\rangle=T_j-2D_j(S).
\]

If \(D_j(S)=0\), the two untruncated values coincide. If \(D_j(S)\ne0\), they are
different, and their truncated values differ exactly when at least one lies in \([-W,W]\).
This proves (33ab), including the case where both values lie outside the window and both
truncate to \(\bot\).

Now let \(X\) be uniform on \(\{-1,1\}^M\), and put
\(Y_j=\tau_W(\langle c_j,X\rangle)\). For every fixed sign center,
\(\langle c_j,X\rangle\) has the Rademacher-sum distribution \(R_M\). The local central
limit theorem, uniformly for \(|u|\le A\sqrt M\), gives

\[
 H(Y_j)=\frac{q_A}{2}\ln M+O_A(1).
\]

Indeed, the total probability retained in the window is \(q_A+o(1)\), and every retained
atom has probability \(\Theta_A(M^{-1/2})\); the single tail symbol contributes only
\(O_A(1)\) entropy. If \(F_C\) is injective, then \(X\) is a function of
\(Y=(Y_1,\ldots,Y_P)\), so

\[
 M\ln2=H(X)=H(Y)
 \le\sum_{j=1}^P H(Y_j)
 \le P\left(\frac{q_A}{2}\ln M+O_A(1)\right),
\]

which proves (33ac). \(\square\)

The biased-layer mechanism in Proposition 6 is genuinely path-specific. To see why its
rowwise near-null conclusion cannot hold for arbitrary centers, assume \(4\mid M\), take any
balanced center \(c\) with \(\sum_kc_k=0\), and let \(Z\) be uniform on the layer with
exactly \(M/4\) negative coordinates. A hypergeometric central limit theorem gives

\[
 \frac{\langle c,Z\rangle}{\sqrt M}
 \Longrightarrow N\!\left(0,\frac34\right),
 \qquad
 \Pr[|\langle c,Z\rangle|\le A\sqrt M]
 \longrightarrow2\Phi\!\left(\frac{2A}{\sqrt3}\right)-1>0.
 \tag{33ad}
\]

Thus a balanced arbitrary row has constant, rather than vanishing, central mass on the same
biased layer. This does not construct an injective family or refute a general collision
theorem; it only closes the direct extension of Proposition 6's marginal entropy argument.
For \(C\ge2\ln2/q_A\), the existence of a family with \(P\le CM/\ln M\) satisfying the
two-endpoint condition (33ab) remains open.

### Proposition 12 (fixed-window antipodal separation is square-root tight)

Fix \(A>0\), put \(W=A\sqrt M\), and let \(\gamma_A(M)\) be the minimum number of sign
centers \(c_1,\ldots,c_P\) such that

\[
 \forall x\in\{-1,1\}^M\ \exists j\le P:\qquad
 \tau_W(\langle c_j,x\rangle)
 \ne \tau_W(\langle c_j,-x\rangle).
 \tag{33ae}
\]

Then, for all sufficiently large \(M\),

\[
 \frac{M}{2(A\sqrt M+1)}
 \le \gamma_A(M)
 \le \frac{4}{A}\sqrt M+O_A(1).
 \tag{33af}
\]

In particular,

\[
 \gamma_A(M)=\Theta_A(\sqrt M).
 \tag{33ag}
\]

#### Proof

A center \(c_j\) separates \(x\) from \(-x\) after truncation exactly when

\[
 0<|\langle c_j,x\rangle|\le W.
 \tag{33ah}
\]

Consequently, the affine hyperplanes

\[
 \{x:\langle c_j,x\rangle=s\},
 \qquad
 s\in\Lambda_M,\quad 0<|s|\le W,
\]

cover the whole cube. Each center contributes at most \(W+1\) such hyperplanes. Their normals
have no zero coordinates, so the skew-cover theorem used in Proposition 9 requires at least
\(M/2\) hyperplanes in total. This proves the lower bound in (33af).

For the upper bound, define the prefix centers

\[
 c^{(r)}_k=
 \begin{cases}
 1,&k\le r,\\
 -1,&k>r,
 \end{cases}
 \qquad 0\le r\le M.
\]

For fixed \(x\), put

\[
 F_x(r)=\langle c^{(r)},x\rangle
 =2\sum_{k\le r}x_k-\sum_{k=1}^Mx_k.
\]

The endpoints are opposite and every step has absolute size \(2\). Hence some \(r_*\) satisfies
\(|F_x(r_*)|\le1\). Let

\[
 d=\left\lfloor\frac{W-1}{2}\right\rfloor,
 \qquad
 R=\{0,d,2d,\ldots,\lfloor M/d\rfloor d\}\cup\{M\}.
\]

For sufficiently large \(M\), \(d\ge1\). Choose \(r\in R\) with \(|r-r_*|\le d\). Then

\[
 |F_x(r)|\le1+2d\le W.
\]

For every \(r\in R\), also include the center \(\widetilde c^{(r)}\) obtained from
\(c^{(r)}\) by flipping its first coordinate. If \(F_x(r)\ne0\), the center \(c^{(r)}\)
satisfies (33ah). If \(F_x(r)=0\), then

\[
 |\langle\widetilde c^{(r)},x\rangle|=2\le W,
\]

so the flipped center satisfies (33ah). The resulting family has at most

\[
 2|R|\le2\left(\left\lfloor\frac Md\right\rfloor+2\right)
 =\frac4A\sqrt M+O_A(1)
\]

centers, proving the upper bound. \(\square\)

Because \(\sqrt M=o(M/\ln M)\), Proposition 12 rules out the antipodal choice
\(S=[M]\) as a witness for a universal collision theorem at the entropy scale. Querying every
retained nonzero level around the constructed centers uses \(O_A(M)\) exact-sphere bits, in
agreement with the sharp order in Proposition 9.

### Proposition 13 (the largest even layer has square-root fixed-window complexity)

Let

\[
 n_M=2\lfloor M/2\rfloor,
\]

and let \(\eta_A(M)\) be the minimum number of sign centers whose fixed-window truncations
with \(W=A\sqrt M\) separate every pair \(x,y\) satisfying \(d_H(x,y)=n_M\). Then, for
all sufficiently large \(M\),

\[
 \frac{n_M}{2(A\sqrt M+1)}
 \le \eta_A(M)
 \le \frac6A\sqrt M+O_A(1).
 \tag{33ai}
\]

Consequently,

\[
 \eta_A(M)=\Theta_A(\sqrt M).
 \tag{33aj}
\]

#### Proof

If \(M\) is even, then \(n_M=M\), so Proposition 12 gives both bounds, with the stronger
upper constant \(4/A\).

Suppose that \(M\) is odd. For the lower bound, restrict to the pairs

\[
 x=(1,z),\qquad y=(1,-z),qquad z\in\{-1,1\}^{M-1}.
 \tag{33ak}
\]

Every such pair has distance \(M-1=n_M\). Write a center as \(c=(c_1,c')\) and put
\(s=\langle c',z\rangle\). Its two inner products are

\[
 c_1+s,qquad c_1-s.
\]

The center separates the pair only if

\[
 s\ne0,
 \qquad
 |c_1+s|\le W\ \text{ or }\ |c_1-s|\le W.
 \tag{33al}
\]

Here \(s\) is even, and (33al) restricts it to at most

\[
 2\left\lfloor\frac{W+1}{2}\right\rfloor\le W+1
\]

nonzero levels. Thus a family separating all pairs in (33ak) gives a cover of
\(\{-1,1\}^{M-1}\) by at most \(P(W+1)\) hyperplanes

\[
 \{z:\langle c',z\rangle=s\}.
\]

After the affine change from \(\{-1,1\}^{M-1}\) to \(\{0,1\}^{M-1}\), every normal
\(c'\) still has all coordinates nonzero. The skew-cover lower bound therefore gives

\[
 P(W+1)\ge\frac{M-1}{2},
\]

which is the lower bound in (33ai).

For the upper bound, use the prefix centers \(c^{(r)}\), the spacing

\[
 d=\left\lfloor\frac{W-1}{2}\right\rfloor,
\]

and the grid \(R\) from Proposition 12. Since \(M\) is odd, every value
\(\langle c^{(r)},x\rangle\) is odd. Hence for every \(x\), some \(r\in R\) satisfies

\[
 0<|\langle c^{(r)},x\rangle|\le W.
 \tag{33am}
\]

For each \(r\in R\), include \(c^{(r)}\) and the two centers obtained by flipping its first
or second coordinate. Fix a pair \(x,y\) at distance \(M-1\), and let \(k\) be their unique
common coordinate. Choose \(r\) satisfying (33am), put \(c=c^{(r)}\), and write

\[
 t=c_kx_k\in\{-1,1\},
 \qquad
 u=\sum_{i\ne k}c_ix_i\in2\mathbb Z.
\]

The two inner products at \(c\) are \(t+u\) and \(t-u\). If \(u\ne0\), they are different,
and the \(x\)-value is central by (33am), so this row separates the pair. If \(u=0\), choose
\(j\in\{1,2\}\setminus\{k\}\). Flipping coordinate \(j\) leaves \(t\) unchanged and replaces
\(u\) by

\[
 u'=-2c_jx_j\in\{-2,2\}.
\]

The resulting two values are \(\{3,-1\}\) or \(\{1,-3\}\), so for sufficiently large
\(M\) they are both central and distinct. The construction therefore separates the whole
distance-\((M-1)\) layer and uses

\[
 3|R|\le3\left(\left\lfloor\frac Md\right\rfloor+2\right)
 =\frac6A\sqrt M+O_A(1)
\]

centers. \(\square\)

Proposition 13 is the fixed-window analogue of Proposition 10. It shows that no universal
collision theorem at the \(M/\ln M\) scale can be supported only on the largest even-distance
layer in either parity. The unresolved obstruction must couple genuinely intermediate even
distances.

### Proposition 14 (every fixed-codimension even layer is square-root-cheap)

Fix \(A>0\) and an integer \(r\ge0\). For every \(M>r\) such that \(M-r\) is even, let
\(\eta_{A,r}(M)\) be the minimum number of sign centers whose fixed-window truncations with
\(W=A\sqrt M\) separate every pair at distance \(M-r\). Then, for all sufficiently large
such \(M\),

\[
 \frac{M-r}{2(A\sqrt M+r+1)}
 \le \eta_{A,r}(M)
 \le \frac{2(r+2)}A\sqrt M+O_{A,r}(1).
 \tag{33an}
\]

Consequently,

\[
 \eta_{A,r}(M)=\Theta_{A,r}(\sqrt M).
 \tag{33ao}
\]

#### Proof

For the lower bound, restrict to

\[
 x=(\mathbf1_r,z),
 \qquad
 y=(\mathbf1_r,-z),
 \qquad
 z\in\{-1,1\}^{M-r}.
 \tag{33ap}
\]

Write a center as \(c=(a,c')\), and put

\[
 b=\sum_{i=1}^r a_i,
 \qquad
 s=\langle c',z\rangle.
\]

The two inner products are \(b+s\) and \(b-s\). The center separates them exactly when

\[
 s\ne0,
 \qquad
 |b+s|\le W\ \text{ or }\ |b-s|\le W.
 \tag{33aq}
\]

Since \(|b|\le r\), every effective level satisfies \(|s|\le W+r\). Since \(M-r\) is
even, \(s\) is even, so each center contributes at most

\[
 2\left\lfloor\frac{W+r}{2}\right\rfloor\le W+r+1
\]

nonzero level hyperplanes. These hyperplanes cover \(\{-1,1\}^{M-r}\). After the affine
change to \(\{0,1\}^{M-r}\), their normals still have no zero coordinates. The skew-cover
lower bound therefore gives

\[
 P(W+r+1)\ge\frac{M-r}{2},
\]

which proves the lower bound in (33an), including \(r=0\).

For the upper bound, use the prefix centers \(c^{(q)}\), the spacing

\[
 d=\left\lfloor\frac{W-1}{2}\right\rfloor,
\]

and the grid \(R\) from Proposition 12. Every \(x\) has some \(q\in R\) for which

\[
 |\langle c^{(q)},x\rangle|\le W.
 \tag{33ar}
\]

Fix \(J=\{1,\ldots,r+1\}\). For each \(q\in R\), include \(c^{(q)}\) and the \(r+1\)
centers obtained by flipping one coordinate in \(J\). Consider a pair \(x,y\) at distance
\(M-r\), with agreement set \(K\) and disagreement set \(S\), and choose \(q\) satisfying
(33ar). Put \(c=c^{(q)}\) and write

\[
 b=\sum_{i\in K}c_ix_i,
 \qquad
 u=\sum_{i\in S}c_ix_i.
\]

The two inner products at \(c\) are \(b+u\) and \(b-u\). If \(u\ne0\), they differ, and
the \(x\)-value is central by (33ar), so the base center separates the pair. If \(u=0\),
then \(|J|=r+1>|K|\), so choose \(j\in J\setminus K\subseteq S\). Flipping coordinate
\(j\) leaves \(b\) unchanged and replaces \(u\) by

\[
 u'=-2c_jx_j\in\{-2,2\}.
\]

The two new values \(b+u'\) and \(b-u'\) are distinct and have absolute value at most
\(r+2\). For sufficiently large \(M\), both lie in the window. Thus the family separates
the whole distance-\((M-r)\) layer and uses

\[
 (r+2)|R|
 \le(r+2)\left(\left\lfloor\frac Md\right\rfloor+2\right)
 =\frac{2(r+2)}A\sqrt M+O_{A,r}(1)
\]

centers. \(\square\)

The cases \(r=0\) and \(r=1\) recover the antipodal layer and the odd-dimensional largest
even layer. Thus no fixed-codimension near-antipodal layer can support a universal collision
theorem at the \(M/\ln M\) scale. Any such near-antipodal witness must have \(r\to\infty\);
other distance regimes remain open.

### Proposition 15 (a quantitative near-antipodal exclusion window)

Fix \(A>0\), put \(W=A\sqrt M\), and allow \(r=r(M)\) to vary. For every
\(0\le r<M\) such that \(M-r\) is even,

\[
 \eta_{A,r}(M)
 \ge
 \frac{M-r}
 {2\min\{W+r+1,\,2(W+1)\}}.
 \tag{33as}
\]

For all sufficiently large \(M\), if in addition \(r+2\le W\), then with

\[
 d=\left\lfloor\frac{W-1}{2}\right\rfloor
\]

one has

\[
 \eta_{A,r}(M)
 \le
 (r+2)\left(\left\lfloor\frac Md\right\rfloor+2\right)
 =O_A((r+1)\sqrt M),
 \tag{33at}
\]

where the implicit constant is uniform in \(r\). Consequently, along any such
parity-compatible sequence, whenever

\[
 r=o\!\left(\frac{\sqrt M}{\ln M}\right),
 \tag{33au}
\]

the whole distance-\((M-r)\) layer can be separated using

\[
 \eta_{A,r}(M)=o\!\left(\frac M{\ln M}\right)
 \tag{33av}
\]

fixed-window centers.

#### Proof

Use the slice and notation in (33ap)--(33aq). For a fixed center, the effective values of
\(s\) lie in the union of the two intervals

\[
 [-b-W,-b+W]
 \quad\text{and}\quad
 [b-W,b+W].
\]

Each interval has length \(2W\) and therefore contains at most
\(\lfloor W\rfloor+1\le W+1\) points of the relevant parity lattice. Overlap can only
decrease the union size. Thus each center contributes at most \(2(W+1)\) effective level
hyperplanes. The envelope argument in Proposition 14 independently bounds this number by
\(W+r+1\). Applying the skew-cover lower bound to the smaller of the two estimates proves
(33as).

For the upper bound, the construction in Proposition 14 uses the same grid \(R\) for every
allowed \(r\), and it uses exactly \(r+2\) centers over each grid point. The only
\(r\)-dependent window requirement in its proof is

\[
 |b\pm2|\le r+2\le W.
\]

Hence the construction works uniformly for every \(r\) throughout \(0\le r\le W-2\) and
gives the explicit bound in (33at). Since

\[
 d=\frac A2\sqrt M+O_A(1),
\]

the implied \(O_A\)-constant is uniform in \(r\). Finally, (33au) substituted into (33at)
gives (33av). \(\square\)

More explicitly, for every fixed center budget constant \(C>0\), Proposition 15 supplies a
constant \(c_{A,C}>0\) such that every integer \(0\le r<M\) with \(M-r\) even and

\[
 r\le c_{A,C}\frac{\sqrt M}{\ln M}
\]

has a separating family of at most \(CM/\ln M\) centers for all sufficiently large \(M\).
Therefore a universal collision theorem supported on one near-antipodal layer at that budget
must use \(r=\Omega_{A,C}(\sqrt M/\ln M)\). This is a layerwise exclusion, not a construction
that is simultaneously injective over all distances.

### Proposition 16 (detecting modulations reach the square-root boundary)

There is an absolute constant \(K>0\) with the following property. Fix \(A>0\), put
\(W=A\sqrt M\), and define

\[
 \ell=\left\lfloor\frac W4\right\rfloor,
 \qquad
 d_0=\left\lfloor\frac{W-2\ell-1}{2}\right\rfloor.
 \tag{33aw}
\]

For all sufficiently large \(M\), whenever \(M-r\) is even and \(r+1\le\ell\),

\[
 \eta_{A,r}(M)
 \le
 \left(1+K\frac{r+1}{\ln(r+2)}\right)
 \left(\left\lfloor\frac M{d_0}\right\rfloor+2\right)
 =O_A\!\left(\left(1+\frac r{\ln(r+2)}\right)\sqrt M\right).
 \tag{33ax}
\]

Consequently, along every parity-compatible sequence,

\[
 r=o(\sqrt M)
 \quad\Longrightarrow\quad
 \eta_{A,r}(M)=o\!\left(\frac M{\ln M}\right).
 \tag{33ay}
\]

#### Proof

We first use the standard detecting-matrix estimate in a form that also controls modulation
support. For every integer \(b\ge1\), there are \(q\le Kb/\ln(b+1)\) subsets
\(L_1,\ldots,L_q\subseteq[b]\) such that

\[
 z\in\{-1,0,1\}^b\setminus\{0\}
 \quad\Longrightarrow\quad
 \sum_{k\in L_i}z_k\ne0
 \quad\text{for some }i.
 \tag{33az}
\]

For completeness, choose each incidence row independently and uniformly from
\(\{0,1\}^b\). If \(z\) has support size \(s\), with \(n\) negative entries, then one row
annihilates it with probability

\[
 2^{-s}\binom{s}{n}
 \le \min\left\{\frac12,\frac{C_0}{\sqrt s}\right\}.
 \tag{33ba}
\]

For \(q=\lceil K_0b/\ln(b+1)\rceil\), split a union bound over the at most
\(\binom bs2^s\) vectors of support \(s\) at \(s=b/(\ln b)^2\). Below the split their total
number is \(\exp(o(b/\ln b))\), while every failure probability is at most \(2^{-q}\).
Above the split, the whole contribution is at most

\[
 3^b\left(\frac{C_0\ln b}{\sqrt b}\right)^q=o(1)
\]

once \(K_0\) is a sufficiently large absolute constant. Enlarging the constant once more
absorbs the ceiling and handles bounded \(b\), proving (33az). This is the usual
probabilistic detecting-matrix construction: its columns have no nontrivial
\(\{-1,0,1\}\)-relation.

Fix a coordinate set \(J\subseteq[M]\) of size \(r+1\), and apply (33az) with
\(b=r+1\). Because \(r+1\le\ell\), every \(L_i\subseteq J\) has size at most \(\ell\).
Use the prefix centers from Proposition 12 with the grid

\[
 R_0=\{0,d_0,2d_0,\ldots,\lfloor M/d_0\rfloor d_0\}\cup\{M\}.
\]

The prefix-path argument now gives, for every \(x\), some \(q_0\in R_0\) whose base center
\(c=c^{(q_0)}\) satisfies

\[
 T:=\langle c,x\rangle,
 \qquad |T|\le1+2d_0\le W-2\ell.
 \tag{33bb}
\]

Over each base center include the base itself and the \(q\) centers obtained by flipping all
coordinates in one of the sets \(L_i\). Consider a pair \(x,y\) at distance \(M-r\), with
agreement set \(K_0\) and disagreement set \(S\), and write

\[
 u=\sum_{k\in S}c_kx_k.
\]

If \(u\ne0\), the base center separates the pair, with the \(x\)-endpoint central by (33bb).
If \(u=0\), define

\[
 v_k=c_kx_k\mathbf1_{k\in S}.
\]

This vector has exactly \(r\) zero coordinates. Since \(|J|=r+1\), its restriction to
\(J\) is nonzero, so (33az) supplies an \(L_i\subseteq J\) for which
\(\sum_{k\in L_i}v_k\ne0\). At the center modulated by \(L_i\), the disagreement sum is

\[
 u'=-2\sum_{k\in L_i}v_k\ne0,
\]

whereas the \(x\)-endpoint moves by at most \(2|L_i|\le2\ell\). It therefore remains in
the window by (33bb), and the modulated center separates the pair. There are at most
\((1+q)|R_0|\) centers, which proves (33ax).

If \(r=o(\sqrt M)\), then \(r+1\le\ell\) eventually. To obtain (33ay), split into
\(r\le M^{1/4}\), where the claim follows directly from (33ax), and \(r>M^{1/4}\), where
\(\ln(r+2)\ge(1/4)\ln M\) and the ratio to \(M/\ln M\) is \(O_A(r/\sqrt M)=o(1)\).
\(\square\)

More explicitly, for every fixed center budget constant \(C>0\), Proposition 16 supplies a
constant \(c_{A,C}>0\) such that every integer \(0\le r\le c_{A,C}\sqrt M\) with
\(M-r\) even has a separating family of at most \(CM/\ln M\) centers for all sufficiently
large \(M\). Indeed, first take \(c_{A,C}\le A/8\) to ensure \(r+1\le\ell\), and then
decrease it, if necessary, so that the main term in (33ax) is at most \(CM/\ln M\); the
remaining \(O_A(\sqrt M)\) term is negligible uniformly. Hence a universal collision theorem
supported on one near-antipodal layer at that budget must have

\[
 r=\Omega_{A,C}(\sqrt M).
 \tag{33bc}
\]

This argument by itself is layerwise because its detecting modulations depend on \(r\). The
next proposition makes the same construction uniform over a whole near-antipodal band.

### Proposition 17 (one family separates a near-antipodal band)

Fix \(A>0\). For an integer \(0\le R\le M-1\), let \(\zeta_{A,R}(M)\) be the minimum
number of sign centers whose fixed-window truncations with \(W=A\sqrt M\) separate every
distinct pair \(x,y\in\{-1,1\}^M\) satisfying

\[
 \bigl|\{k:x_k=y_k\}\bigr|\le R.
 \tag{33bd}
\]

With \(\ell,d_0\) as in (33aw), there is an absolute constant \(K_1>0\) such that, for all
sufficiently large \(M\) and every \(0\le R\le M-1\),

\[
 \zeta_{A,R}(M)
 \le
 \left(
  1+K_1\frac{R+1}{\ln(\min\{R+2,\ell+1\})}
 \right)
 \left(\left\lfloor\frac M{d_0}\right\rfloor+2\right).
 \tag{33be}
\]

In particular, for every fixed \(c>0\), uniformly over \(0\le R\le c\sqrt M\),

\[
 \zeta_{A,R}(M)=O_{A,c}\!\left(\frac M{\ln M}\right).
 \tag{33bf}
\]

#### Proof

Put \(B=R+1\) and fix \(J\subseteq[M]\) with \(|J|=B\). If \(B\le\ell\), use \(J\)
as one block. If \(B>\ell\), let \(m=\lceil B/\ell\rceil\) and partition \(J\) into
\(m\) blocks whose sizes differ by at most one. For sufficiently large \(M\), every block
then has size between \(\ell/3\) and \(\ell\). Apply the detecting family (33az) separately
on every block, and let \(\mathcal L\) be the union of all resulting row supports. Each
\(L\in\mathcal L\) has \(|L|\le\ell\), and the balanced block sizes give

\[
 |\mathcal L|
 \le
 K_1\frac{R+1}{\ln(\min\{R+2,\ell+1\})}.
 \tag{33bg}
\]

Indeed, this is (33az) directly when \(B\le\ell\). When \(B>\ell\), every block has
logarithm \(\Theta(\ln(\ell+1))\), the block sizes sum to \(B\), and the number of blocks is
\(O(B/\ell)\); increasing the absolute constant absorbs bounded values and integer roundoff.

Use the same prefix grid \(R_0\) and inner-window guarantee (33bb) as in Proposition 16. Over
each base center include the base itself and its modulations by every \(L\in\mathcal L\).
This family is fixed before the pair and before its agreement count are known.

Consider any distinct \(x,y\) satisfying (33bd). Let \(K_0\) and \(S\) be their agreement
and disagreement sets, put \(r=|K_0|\le R\), and choose a base center \(c\) for which the
\(x\)-endpoint satisfies (33bb). Write

\[
 u=\sum_{k\in S}c_kx_k.
\]

If \(u\ne0\), the base center separates the pair. If \(u=0\), define
\(v_k=c_kx_k\mathbf1_{k\in S}\). Since

\[
 |J|=R+1>|K_0|,
\]

the restriction \(v|_J\) is nonzero. It is nonzero on at least one block, so that block's
detecting family supplies \(L\in\mathcal L\) with \(\sum_{k\in L}v_k\ne0\). Exactly as in
Proposition 16, modulation by \(L\) makes the disagreement sum nonzero while moving the
\(x\)-endpoint by at most \(2\ell\). The endpoint remains central and the pair is separated.
This argument is independent of \(r\), and it also needs no parity assumption: when \(|S|\)
is odd, \(u\) is automatically nonzero. Multiplying (33bg) by the number of base centers
proves (33be), and \(d_0=\Theta_A(\sqrt M)\) gives (33bf). \(\square\)

For every fixed \(A,C>0\), one may first choose \(c_{A,C}>0\) sufficiently small and then
set \(R=\lfloor c_{A,C}\sqrt M\rfloor\). The main term in (33be) is then at most
\(CM/\ln M\), after decreasing \(c_{A,C}\) if necessary, while the base-grid term is only
\(O_A(\sqrt M)\). Hence, for all sufficiently large \(M\), one family of at most
\(CM/\ln M\) centers simultaneously separates every pair with at most
\(c_{A,C}\sqrt M\) agreement coordinates. Any collision that is forced for every family at
this budget must lie outside that band.

### Proposition 18 (small-agreement hard pairs cannot be prefix-isolated)

For sufficiently large \(M\), keep the grid \(R_0\) and the parameters \(\ell,d_0\) from
Proposition 17. Let
\(C\subseteq R_0\setminus\{0,M\}\) be a nonempty interval of consecutive grid points, and
let \(q_-<\min C\) and \(q_+>\max C\) be its two neighboring grid points. Consider a pair
\(x,y\) with agreement set \(K\), disagreement set \(S\), and \(|K|=r\). Put

\[
 F_x(q)=\langle c^{(q)},x\rangle,
 \qquad
 u_q=\sum_{k\in S}c^{(q)}_kx_k.
 \tag{33bh}
\]

If

\[
 |F_x(q)|>W \quad(q\in R_0\setminus C),
 \qquad
 u_q=0 \quad(q\in C),
 \tag{33bi}
\]

then necessarily

\[
 r>W-2d_0\ge2\ell+1.
 \tag{33bj}
\]

#### Proof

Consecutive points of \(R_0\) are at distance at most \(d_0\), and every prefix step changes
\(F_x\) by \(2\). Hence

\[
 |F_x(q')-F_x(q)|\le2d_0
 \tag{33bk}
\]

for consecutive grid points. The two values \(F_x(q_-)\) and \(F_x(q_+)\) must have opposite
signs. Indeed, \(F_x(0)=-F_x(M)\); if the two values had the same sign, one of the two
outside portions of the grid would contain a sign change. Condition (33bi) would force the
two consecutive values across that change to have absolute value greater than \(W\), requiring
a jump greater than \(2W\), contrary to (33bk).

For every \(q\in C\), write

\[
 b_q=\sum_{k\in K}c^{(q)}_kx_k.
\]

Since \(F_x(q)=b_q+u_q=b_q\), one has \(|F_x(q)|\le r\) throughout \(C\). Applying
(33bk) at the two boundary edges of \(C\) therefore gives

\[
 |F_x(q_+)-F_x(q_-)|
 \le4d_0+2r.
 \tag{33bl}
\]

The two boundary values have opposite signs and absolute value greater than \(W\), so the
left-hand side is greater than \(2W\). Thus \(r>W-2d_0\). Finally, the definition of
\(d_0\) in (33aw) gives \(W-2d_0\ge2\ell+1\). \(\square\)

Proposition 18 closes a natural route to proving that the Cartesian product in (33be) is
necessary. One cannot assign an independent hard family to each constant-size prefix cluster,
make every center outside that cluster irrelevant by forcing both endpoints into the tail, and
then sum detecting-matrix lower bounds over clusters: in the small-agreement range where
Proposition 17 operates, even the unmodulated base centers cannot be isolated in this way. The
same zero-return propagation instead leads to a compression of that product.

### Proposition 19 (a near-antipodal band is square-root tight)

Fix \(A>0\). For every sufficiently large \(M\), put \(W=A\sqrt M\), and let
\(R\ge0\) be an integer satisfying

\[
 3R+2\le W.
 \tag{33bm}
\]

\[
 d_R=\left\lfloor\frac{W-R-1}{2}\right\rfloor,
 \qquad
 Q_R=\{0,d_R,2d_R,\ldots,\lfloor M/d_R\rfloor d_R\}\cup\{M\}.
 \tag{33bn}
\]

There is an absolute constant \(K>0\) such that

\[
 \frac{M}{2(W+1)}
 \le \zeta_{A,R}(M)
 \le |Q_R|+K\frac{R+1}{\ln(R+2)}.
 \tag{33bo}
\]

Consequently, for every fixed \(0\le c<A/3\), uniformly over integers
\(0\le R\le c\sqrt M\),

\[
 \zeta_{A,R}(M)=\Theta_{A,c}(\sqrt M).
 \tag{33bp}
\]

#### Proof

For the upper bound, fix \(J\subseteq[M]\) with \(|J|=R+1\), and take the detecting family
\(\mathcal L\subseteq2^J\) from (33az). Thus

\[
 |\mathcal L|\le K\frac{R+1}{\ln(R+2)},
 \tag{33bq}
\]

and every nonzero vector in \(\{-1,0,1\}^J\) has nonzero sum on some
\(L\in\mathcal L\). Use every prefix base center \(c^{(q)}\), \(q\in Q_R\), but attach
the modulations by \(\mathcal L\) only to the single base \(q^*=0\).

Consider a pair \(x,y\) with agreement set \(K_0\), disagreement set \(S\), and
\(r=|K_0|\le R\). Suppose first that none of the unmodulated prefix bases separates the
pair. As in Proposition 12, there is an index \(t\in[0,M]\) with
\(|F_x(t)|\le1\). Choose \(q\in Q_R\) with \(|q-t|\le d_R\). Then

\[
 |F_x(q)|\le1+2d_R\le W-R\le W.
 \tag{33br}
\]

Writing

\[
 b_q=\sum_{k\in K_0}c^{(q)}_kx_k,
 \qquad
 u_q=\sum_{k\in S}c^{(q)}_kx_k,
\]

the two complete values are \(b_q+u_q\) and \(b_q-u_q\). Since the \(x\)-endpoint is
central and the base does not separate, one must have \(u_q=0\). Hence both values equal
\(b_q\), with \(|b_q|\le r\).

Now let \(q'\) be either neighboring grid point of \(q\). The last interval of the grid may
be shorter than \(d_R\), but no interval is longer. Therefore

\[
 |F_x(q')|,\ |F_y(q')|
 \le r+2d_R
 \le R+W-R-1<W.
 \tag{33bs}
\]

Both endpoints are central at \(q'\). If \(u_{q'}\ne0\), their complete values differ and
the base \(q'\) separates them, contrary to the assumption. Thus \(u_{q'}=0\). Propagating
this implication along the connected grid \(Q_R\) gives

\[
 u_q=0 \qquad(q\in Q_R),
 \tag{33bt}
\]

in particular at \(q^*=0\).

Define

\[
 v_k=c^{(0)}_kx_k\mathbf1_{k\in S}.
\]

This vector has exactly \(r\le R\) zero coordinates, so \(v|_J\ne0\). Choose
\(L\in\mathcal L\) with \(\sum_{k\in L}v_k\ne0\). Flipping \(L\) at the base \(q^*=0\)
changes the disagreement sum from zero to

\[
 -2\sum_{k\in L}v_k\ne0.
\]

Moreover, the \(x\)-endpoint remains central because

\[
 |\langle c^{(0),L},x\rangle|
 \le r+2|L|
 \le R+2(R+1)
 =3R+2\le W.
 \tag{33bu}
\]

The modulated center therefore separates the pair. This proves the upper bound in (33bo).

The band in (33bd) contains every antipodal pair, so Proposition 12 gives

\[
 \zeta_{A,R}(M)\ge\gamma_A(M)\ge\frac{M}{2(W+1)},
\]

which is the lower bound. Finally, if \(R\le c\sqrt M\) with \(c<A/3\), then (33bm) holds
for all sufficiently large \(M\), while \(d_R=\Theta_{A,c}(\sqrt M)\). The two bounds in
(33bo) now give (33bp). \(\square\)

The proof identifies the useful joint structure missed by the Cartesian product in
Proposition 17. Under the assumption that all prefix bases collide, one zero disagreement sum
forces zero disagreement sums at every neighboring grid point; the detector can therefore be
placed once at a predetermined endpoint. This does not yet control agreement bands approaching
the full window \(R\approx W\), where the propagation margin in (33bs) vanishes.

### Proposition 20 (entropy-scale separation under low agreement discrepancy)

For a distinct pair \(x,y\), let \(K=\{k:x_k=y_k\}\) and define its signed agreement
prefix discrepancy by

\[
 \Delta(x,y)
 =\max_{0\le q\le M}
 \left|\sum_{k\in K}c^{(q)}_kx_k\right|.
 \tag{33bv}
\]

This is symmetric in \(x,y\), because the two points agree on \(K\). Fix \(A>0\). For
every sufficiently large \(M\), put \(W=A\sqrt M\), let \(0\le B<W-3\), and let
\(\xi_{A,B}(M)\) be the minimum number of sign centers whose fixed-window truncations separate
every distinct pair satisfying \(\Delta(x,y)\le B\). Define

\[
 \ell_B=\left\lfloor\frac{W-B}{2}\right\rfloor,
 \qquad
 d_B=\left\lfloor\frac{W-B-1}{2}\right\rfloor,
 \tag{33bw}
\]

and

\[
 Q_B=\{0,d_B,2d_B,\ldots,\lfloor M/d_B\rfloor d_B\}\cup\{M\}.
 \tag{33bx}
\]

There is an absolute constant \(K_2>0\) such that

\[
 \frac{M}{2(W+1)}
 \le \xi_{A,B}(M)
 \le |Q_B|+K_2\frac{M}{\ln(\ell_B+1)}.
 \tag{33by}
\]

In particular, for every fixed \(0<\delta<A\), uniformly over

\[
 0\le B\le(A-\delta)\sqrt M,
\]

one has

\[
 \xi_{A,B}(M)=O_{A,\delta}\!\left(\frac M{\ln M}\right).
 \tag{33bz}
\]

#### Proof

Partition \([M]\) into blocks \(J_1,\ldots,J_m\) of nearly equal sizes at most \(\ell_B\),
using \(m=\lceil M/\ell_B\rceil\). Apply the detecting family (33az) separately on every
block, and let \(\mathcal L\) be the union of all row supports. The blocks have size
\(\Theta(\ell_B)\), except when \(\ell_B\) is bounded, which can be absorbed into the
constant. Hence

\[
 |\mathcal L|
 \le K_2\frac{M}{\ln(\ell_B+1)}.
 \tag{33ca}
\]

Use every prefix base center \(c^{(q)}\), \(q\in Q_B\), and attach all modulations in
\(\mathcal L\) only at the fixed base \(q^*=0\).

Consider a pair \(x,y\) with \(\Delta(x,y)\le B\), agreement set \(K\), and disagreement
set \(S\). Suppose that none of the unmodulated prefix bases separates the pair. Choose an
integer \(t\) with \(|F_x(t)|\le1\), and then choose \(q\in Q_B\) with
\(|q-t|\le d_B\). Thus

\[
 |F_x(q)|\le1+2d_B\le W-B\le W.
 \tag{33cb}
\]

Write

\[
 b_q=\sum_{k\in K}c^{(q)}_kx_k,
 \qquad
 u_q=\sum_{k\in S}c^{(q)}_kx_k.
\]

Since the \(x\)-endpoint is central and the base does not separate, \(u_q=0\). Therefore
both complete values equal \(b_q\), and \(|b_q|\le B\) by the definition of \(\Delta\).
For either neighboring grid point \(q'\),

\[
 |F_x(q')|,\ |F_y(q')|
 \le B+2d_B
 \le W-1<W.
 \tag{33cc}
\]

Both endpoints are central. If \(u_{q'}\ne0\), the base \(q'\) separates them, contrary to
the assumption. Hence \(u_{q'}=0\), and the implication propagates along the connected grid
to give \(u_0=0\).

At \(q^*=0\), define

\[
 v_k=c^{(0)}_kx_k\mathbf1_{k\in S}.
\]

Because \(x\ne y\), this vector is nonzero. It is nonzero on at least one block \(J_i\),
whose detecting family supplies \(L\subseteq J_i\) with
\(\sum_{k\in L}v_k\ne0\). Flipping \(L\) makes the disagreement sum nonzero. The
\(x\)-endpoint remains central because

\[
 |\langle c^{(0),L},x\rangle|
 \le |b_0|+2|L|
 \le B+2\ell_B\le W.
 \tag{33cd}
\]

Thus the modulated center separates the pair, proving the upper bound in (33by). The pair class
contains every antipodal pair, for which \(K=\varnothing\) and \(\Delta=0\). Proposition 12
therefore gives the lower bound.

If \(B\le(A-\delta)\sqrt M\), then
\(d_B,\ell_B=\Theta_{A,\delta}(\sqrt M)\). Consequently \(|Q_B|=O_{A,\delta}(\sqrt M)\)
and (33ca) is \(O_{A,\delta}(M/\ln M)\), proving (33bz). \(\square\)

Proposition 20 removes the agreement-count restriction but not all pair structure. It gives one
entropy-scale family for every pair whose signed agreement path stays inside a window of width
\((A-\delta)\sqrt M\). Hence any collision that survives this family must satisfy

\[
 \Delta(x,y)>(A-\delta)\sqrt M.
 \tag{33ce}
\]

The remaining problem is no longer merely to handle many agreement coordinates; it is to handle
agreement coordinates whose signed prefix walk makes a large excursion.

### Proposition 21 (prefix collisions are exactly agreement-dominant excursions)

Fix \(W\ge2\), and use every prefix center \(c^{(q)}\), \(0\le q\le M\). For a distinct
pair \(x,y\), let \(K=\{k:x_k=y_k\}\), \(S=[M]\setminus K\), and write

\[
 b_q=\sum_{k\in K}c^{(q)}_kx_k,
 \qquad
 u_q=\sum_{k\in S}c^{(q)}_kx_k.
 \tag{33cf}
\]

Then all prefix centers fail to separate \(x\) and \(y\) under the fixed-window truncation
if and only if

\[
 \forall q\in\{0,\ldots,M\}:\qquad
 u_q=0
 \quad\text{or}\quad
 |b_q|>W+|u_q|.
 \tag{33cg}
\]

In particular, every such collision satisfies

\[
 \Delta(x,y)>W+2.
 \tag{33ch}
\]

This threshold cannot be improved beyond the lattice spacing. More precisely, fix \(A>0\),
put \(W=A\sqrt M\), and let \(M\) run through sufficiently large even integers. There is a
distance-two pair collided by every prefix center for which

\[
 W+2<\Delta(x,y)\le W+4.
 \tag{33ci}
\]

#### Proof

At a fixed prefix \(q\), the two complete values are \(b_q+u_q\) and \(b_q-u_q\). If
\(u_q\ne0\) and the prefix center does not separate the pair, both values must lie outside
the window. The identity

\[
 \min\{|b_q+u_q|,|b_q-u_q|\}
 =\bigl||b_q|-|u_q|\bigr|
 \tag{33cj}
\]

shows that precisely two tail configurations are possible:

\[
 |b_q|>W+|u_q|
 \qquad\text{or}\qquad
 |u_q|>W+|b_q|.
 \tag{33ck}
\]

The second, disagreement-dominant configuration is locally possible but globally impossible
along the complete prefix path. Indeed, put \(f_q=|u_q|-|b_q|\). From one prefix to the
next, exactly one of \(b_q,u_q\) changes, by \(2\) in absolute increment, and therefore

\[
 |f_{q+1}-f_q|\le2.
 \tag{33cl}
\]

If \(f_q>W\ge2\), then every adjacent \(f_{q'}\) is positive. At \(q'\) one has
\(u_{q'}\ne0\), and collision together with (33ck) forces \(f_{q'}>W\) again. Forward
and backward propagation would make every prefix disagreement-dominant. But
\(u_M=-u_0\), and the integer path \(u_q\), whose increments belong to
\(\{0,-2,2\}\), must either visit \(0\) or change sign through \(1,-1\). Hence some
\(q\) has \(|u_q|\le1\), contradicting \(f_q>W\ge2\). Thus the second alternative in
(33ck) never occurs. This proves the forward implication in (33cg); the reverse implication
is immediate because \(u_q=0\) gives equal values, whereas the other alternative puts both
values strictly outside the window.

Now \(b_M=-b_0\), and \(b_q\) also has increments in \(\{0,-2,2\}\). Thus some \(q_0\)
satisfies \(|b_{q_0}|\le1\). Condition (33cg) forces \(u_{q_0}=0\). Since \(x\ne y\),
the disagreement path is not identically zero; moving from \(q_0\) toward a nearest change
therefore gives an index \(q_1\) with \(|u_{q_1}|=2\). Applying (33cg) at \(q_1\) yields

\[
 |b_{q_1}|>W+2,
\]

which proves (33ch).

It remains to show sharpness. Let

\[
 B_M=2\left(\left\lfloor\frac{W+2}{2}\right\rfloor+1\right),
 \qquad
 p=\frac{M-B_M-2}{2}.
 \tag{33cm}
\]

For sufficiently large even \(M\), \(p\) is a nonnegative integer and
\(W+2<B_M\le W+4\). Define

\[
 \begin{aligned}
 x&=(1^{B_M/2},\ 1,-1,\ (-1)^{B_M/2},\ (1,-1)^p),\\
 y&=(1^{B_M/2},\ -1,1,\ (-1)^{B_M/2},\ (1,-1)^p).
 \end{aligned}
 \tag{33cn}
\]

The disagreement set consists of the displayed middle pair. Both the signed agreement total
and the signed disagreement total are zero. Along the first block the agreement path rises
from \(0\) to \(B_M\), while \(u_q=0\). At the first disagreement coordinate one has
\((b_q,u_q)=(B_M,2)\), so both complete values \(B_M-2,B_M+2\) exceed \(W\). At the
second, \(u_q\) returns to zero. The remaining agreement coordinates bring \(b_q\) back to
zero and then alternate it between \(0\) and \(2\), always with \(u_q=0\). Thus every
prefix center collides on the pair, while

\[
 \Delta(x,y)=B_M.
\]

This proves (33ci). \(\square\)

Proposition 21 shows that the high-discrepancy remainder in Proposition 20 is not merely a
loss from using a coarse prefix grid. Even the full linear-size prefix family has collisions
immediately beyond the \(W+2\) boundary. Its exact obstruction is nevertheless rigid: every
nonzero disagreement excursion is hidden inside a strictly larger agreement excursion. Any
entropy-scale improvement must exploit that joint excursion structure through non-prefix
centers or modulations; adding more prefix locations alone cannot suffice.

### Proposition 22 (prefix neighborhoods force linear nonlocality)

Fix \(A>0\), put \(W=A\sqrt M\), and let

\[
 \ell_0=\left\lfloor\frac W4\right\rfloor.
 \tag{33co}
\]

For \(L\subseteq[M]\), write \(c^{(q),L}\) for the center obtained by flipping \(c^{(q)}\)
on \(L\), and define the radius-\(\rho\) neighborhood of the prefix path by

\[
 \mathcal N_\rho
 =
 \left\{
 c^{(q),L}:0\le q\le M,\ L\subseteq[M],\ |L|\le\rho
 \right\}.
 \tag{33cp}
\]

Let \(\theta_{A,\rho}^{\mathrm{pref}}(M)\) be the minimum size of a family
\(\mathcal C\subseteq\mathcal N_\rho\) whose fixed-window truncations are injective on
\(\{-1,1\}^M\). There are constants \(c>0\) and \(C_A<\infty\) such that, for every
sufficiently large \(M\) divisible by \(32\) and every integer
\(\ell_0\le\rho\le M/64\),

\[
 c\frac{M^2}{(W+\rho)\ln(2\rho+1)}
 \le
 \theta_{A,\rho}^{\mathrm{pref}}(M).
 \tag{33cq}
\]

For every sufficiently large \(M\) and every integer \(\rho\ge\ell_0\), one also has

\[
 \theta_{A,\rho}^{\mathrm{pref}}(M)
 \le
 C_A\frac{M^{3/2}}{\ln M}.
\]

In particular,

\[
 \theta_{A,\ell_0}^{\mathrm{pref}}(M)
 =\Theta_A\!\left(\frac{M^{3/2}}{\ln M}\right).
\]

Moreover, for every fixed \(C>0\), there is a constant \(\delta_{A,C}>0\) such that
for every sufficiently large \(M\) divisible by \(32\), any injective family of at most
\(CM/\ln M\) arbitrary sign centers contains a center \(c\) satisfying

\[
 \min_{0\le q\le M}d_H(c,c^{(q)})>\delta_{A,C}M.
\]

#### Proof

The upper bound is Proposition 17 with \(R=M-1\) and \(J=[M]\). Its block detectors
have supports of size at most \(\ell_0\le\rho\), and the number of prefix bases is
\(O_A(\sqrt M)\). Thus all centers used there belong to \(\mathcal N_\rho\), while
(33be) gives the claimed \(O_A(M^{3/2}/\ln M)\) count.

For the lower bound, fix a family
\(\mathcal C=\{c^{(q_j),L_j}:1\le j\le P\}\subseteq\mathcal N_\rho\) that is injective.
Choose one displayed representation for each center and put

\[
 D=\left\lceil\frac{W+2\rho+2}{2}\right\rceil,
 \qquad
 H=\frac M2,
 \qquad
 N=\frac M{16}.
 \tag{33cr}
\]

Select even integers \(t_1,\ldots,t_T\in[0,M/16]\) separated by more than \(2D\).
Because \(\rho\le M/64\), the intervals below lie inside the central run for all
sufficiently large \(M\), and one can take

\[
 T=\Omega\!\left(\frac M{W+\rho}\right).
 \tag{33cs}
\]

Put \(q_i=t_i+M/4\) and \(I_i=\{q:|q-q_i|\le D\}\). The intervals \(I_i\) are
pairwise disjoint.

We construct a family of prefix-colliding pairs for each \(i\). Start with \(t_i/2\)
two-coordinate agreement blocks on which

\[
 x=y=(1,-1).
\]

Follow these by \(M/2\) agreement coordinates on which \(x=y=1\). For each
\(z\in\{-1,0,1\}^N\setminus\{0\}\), next place \(N\) variable blocks of length two,
with block \(s\) defined according to

\[
 \begin{array}{c|c|c}
 z_s & x\text{ on block }s & y\text{ on block }s\\ \hline
 0  &(1,-1)&(1,-1)\\
 1  &(1,-1)&(-1,1)\\
 -1 &(-1,1)&(1,-1).
 \end{array}
 \tag{33ct}
\]

Fill the remaining even number of coordinates with agreement blocks
\(x=y=(1,-1)\). This uses exactly \(M\) coordinates. Let \(b_q,u_q\) be as in
(33cf). The total signed agreement sum is \(H\), whereas every disagreement block has
signed sum zero. Consequently,

\[
 b_0=-H,\qquad b_{q_i}=0,\qquad
 |u_q|\le2.
 \tag{33cu}
\]

Along the central run, \(b_q=2(q-q_i)\). Outside that run, its absolute value is at least
\(H-2\); every nonzero \(u_q\) occurs later, where \(|b_q|\ge H\). Hence, for all
sufficiently large \(M\), every pair in (33ct) is collided by every unmodulated prefix
center.

Consider a center \(c^{(q_j),L_j}\). If \(q_j\notin I_i\), then

\[
 |b_{q_j}|>W+2\rho+2.
\]

Indeed, this follows from the definition of \(D\) on the central run, while off that run
\[
 H-2=\frac M2-2>W+2\rho+2
\]
for all sufficiently large \(M\), since \(\rho\le M/64\).
Both original endpoint values have absolute value greater than \(W+2\rho\), by (33cu).
Flipping at most \(\rho\) coordinates changes either endpoint value by at most \(2\rho\),
so both modulated values remain outside the window. Such a center separates none of the
pairs in the \(i\)-th family.

It remains to analyze the rows with \(q_j\in I_i\). This interval lies inside the central
agreement run, before every variable block, so \(u_{q_j}=0\). For the \(s\)-th variable
block, let

\[
 a_{j,s}
 =
 \mathbf1\{\text{its first coordinate lies in }L_j\}
 -
 \mathbf1\{\text{its second coordinate lies in }L_j\}.
 \tag{33cv}
\]

Up to an irrelevant common sign, the modulated disagreement sum is
\(2\sum_{s=1}^N a_{j,s}z_s\). Therefore, if the matrix
\(A_i=(a_{j,s})_{q_j\in I_i,\ s\le N}\) had a nonzero
\(z\in\{-1,0,1\}^N\) in its kernel, the corresponding pair would collide with every
row inside \(I_i\), and hence with all of \(\mathcal C\). Injectivity forces

\[
 \ker(A_i)\cap\{-1,0,1\}^N=\{0\}.
 \tag{33cw}
\]

In particular, \(A_i\) is injective on \(\{0,1\}^N\). Every row has at most
\(\rho\) nonzero coefficients, so its value on \(\{0,1\}^N\) has at most
\(2\rho+1\) possibilities. If \(r_i=|\{j:q_j\in I_i\}|\), then

\[
 2^N\le(2\rho+1)^{r_i},
 \qquad
 r_i\ge\frac{N\ln2}{\ln(2\rho+1)}.
 \tag{33cx}
\]

The \(I_i\) are disjoint, so the same center is counted for at most one \(i\). Summing
(33cx) and using (33cs) gives

\[
 P\ge\sum_{i=1}^T r_i
 =\Omega\!\left(
 \frac{M^2}{(W+\rho)\ln(2\rho+1)}
 \right).
 \tag{33cy}
\]

This proves (33cq). Taking \(\rho=\ell_0=\Theta_A(\sqrt M)\) proves the displayed
\(\Theta_A(M^{3/2}/\ln M)\) consequence.

Finally, fix \(C>0\). Choose a sufficiently small constant
\[
 0<\delta_{A,C}<\min\{1/64,c/(8C)\},
\]
and suppose that every center in an injective family
\(\mathcal C\) of size at most \(CM/\ln M\) has prefix-path distance at most
\(\delta_{A,C}M\). Apply (33cq) with
\(\rho=\lceil\delta_{A,C}M\rceil\). For sufficiently large \(M\),
\[
 \rho\le2\delta_{A,C}M,\qquad W\le\rho.
\]
Consequently,
\[
 W+\rho\le4\delta_{A,C}M,
 \qquad
 \ln(2\rho+1)\le2\ln M,
\]
so

\[
 |\mathcal C|
 \ge
 \frac{c}{8\delta_{A,C}}\frac M{\ln M}.
\]

This contradicts \(|\mathcal C|\le CM/\ln M\) and proves the linear-distance consequence.
\(\square\)

Along dimensions divisible by \(32\), Proposition 22 closes every prefix neighborhood of
radius \(\rho\le M/64\) at the entropy scale, not merely a particular block partition. At
radius \(\rho=\ell_0=\lfloor W/4\rfloor\), its lower bound matches the Cartesian
construction of Proposition 17. More generally, the linear-distance consequence says that an
entropy-scale solution must be genuinely nonlocal: at least one center has linear Hamming
distance from the entire prefix path.

### Proposition 23 (two naive nonlocal extensions are insufficient)

Let \(B_1,\ldots,B_m\) be a partition of \([M]\) into nonempty even blocks. Suppose that
every center \(c\) in a family \(\mathcal C\subseteq\{-1,1\}^M\) is balanced on every
block:

\[
 \sum_{k\in B_r}c_k=0,
 \qquad c\in\mathcal C,\quad 1\le r\le m.
 \tag{33cz}
\]

Then the fixed-window map \(F_{\mathcal C}\) is not injective for any \(W\ge0\), no matter
how many centers the family contains. In particular, converting binary rows \(a\) into sign
centers \(c=2a-\mathbf1\) does not preserve detecting power if every row has exactly
\(|B_r|/2\) ones in each common block.

The crossing-slice row capacities in Proposition 22 also cannot be summed after arbitrary
centers are admitted. At \(\rho=\ell_0\), choose a maximal valid collection of its slices,
so \(T=\Theta_A(\sqrt M)\), and let

\[
 c^{\mathrm{alt}}_k=(-1)^{k+1}.
\]

This one center has distance \(M/2-1\) from the prefix path and induces the coefficient row
\((1,\ldots,1)\in\{-1,0,1\}^N\) on every one of the \(T\) variable-block slices.
Consequently, its subset-sum image has \(N+1\) values on every slice simultaneously.

#### Proof

Fix a block \(B_r\), take \(x=\mathbf1\), and obtain \(y\) by negating \(x\) on
\(B_r\). For every \(c\in\mathcal C\), (33cz) gives

\[
 \langle c,x\rangle-\langle c,y\rangle
 =2\sum_{k\in B_r}c_k=0.
 \tag{33da}
\]

Thus the two inner products, and hence their truncations, agree at every center, although
\(x\ne y\). If \(c=2a-\mathbf1\), condition (33cz) is exactly
\(2\langle a,\mathbf1_{B_r}\rangle-|B_r|=0\), proving the binary-row consequence.

For the second assertion, retain the notation of Proposition 22. The variable blocks in the
\(i\)-th slice are

\[
 J_{i,s}=\{p_i+2s-1,p_i+2s\},
 \qquad p_i=t_i+M/2,\qquad 1\le s\le N.
 \tag{33db}
\]

Both \(t_i\) and \(M/2\) are even, so \(p_i\) is even. Therefore
\(c^{\mathrm{alt}}\) equals \((1,-1)\) on every \(J_{i,s}\), and the induced
coefficient is

\[
 a^{(i)}_s
 =\frac{c^{\mathrm{alt}}_{p_i+2s-1}-c^{\mathrm{alt}}_{p_i+2s}}2
 =1.
 \tag{33dc}
\]

It follows that

\[
 \bigl\{\langle a^{(i)},z\rangle:z\in\{0,1\}^N\bigr\}
 =\{0,1,\ldots,N\}
\]

for every \(i\), all from the same center. Finally, direct counting gives

\[
 d_H(c^{\mathrm{alt}},c^{(q)})
 =
 \begin{cases}
 M/2,&q\text{ even},\\
 M/2-1,&q\text{ odd},
 \end{cases}
 \tag{33dd}
\]

so the center is linearly nonlocal. This proves that per-slice output capacity cannot be
charged disjointly to arbitrary centers. It does not make one row a detecting matrix:
\(a^{(i)}\cdot(e_1-e_2)=0\). \(\square\)

Proposition 23 closes two direct continuations of Proposition 22. Linear nonlocality does not
make slice entropy additive, while imposing a common block balance to obtain nonlocal sign
centers destroys injectivity outright. A successful construction must break the common
block-indicator kernels; a successful lower bound must instead use joint kernels, endpoint
centrality, or another constraint beyond rowwise output capacity.

### Proposition 24 (simultaneous shifted detection is entropy-scale cheap)

Suppose that \(16\mid M\), and put \(N=M/16\). For every even integer
\(p\in[0,M-2N]\), define the disjoint pairs

\[
 J_{p,s}=\{p+2s-1,p+2s\},
 \qquad 1\le s\le N.
 \tag{33de}
\]

For a sign center \(c\in\{-1,1\}^M\), let

\[
 a^{(p)}(c)_s
 =\frac{c_{p+2s-1}-c_{p+2s}}2
 \in\{-1,0,1\}.
 \tag{33df}
\]

For every sufficiently large \(M\), there is a family
\(\mathcal C=\{c_1,\ldots,c_P\}\) of

\[
 P=\left\lceil\frac{8N}{\ln N}\right\rceil
 =O\!\left(\frac M{\ln M}\right)
 \tag{33dg}
\]

sign centers such that, simultaneously for every admissible \(p\), the matrix
\(A(p)=(a^{(p)}(c_j)_s)_{j\le P,s\le N}\) satisfies

\[
 \ker(A(p))\cap\{-1,0,1\}^N=\{0\}.
 \tag{33dh}
\]

Every center in the family may moreover be required to obey

\[
 \min_{0\le q\le M}d_H(c_j,c^{(q)})>M/4.
 \tag{33di}
\]

Conversely, any family satisfying (33dh) for even one admissible \(p\) has

\[
 P\ge\frac{N\ln2}{\ln(N+1)}.
 \tag{33dj}
\]

Thus simultaneous ternary detection over all shifted pair blocks has complexity
\(\Theta(M/\ln M)\), even when every center is linearly nonlocal.

#### Proof

Choose \(P\) independent uniform sign centers. For a fixed \(p\), the entries in each row of
\(A(p)\) are independent and have distribution

\[
 \Pr[a=0]=\frac12,
 \qquad
 \Pr[a=1]=\Pr[a=-1]=\frac14.
 \tag{33dk}
\]

Fix a nonzero \(z\in\{-1,0,1\}^N\) of support size \(s\). Multiplication by the nonzero
signs of \(z\) preserves (33dk), and the one-row annihilation probability is

\[
 p_s
 =\Pr[\langle a,z\rangle=0]
 =\frac{\binom{2s}{s}}{4^s}.
 \tag{33dl}
\]

Indeed, the step generating function is
\((x+2+x^{-1})/4=x^{-1}(1+x)^2/4\). Hence, for a fixed shift, a union bound gives

\[
 U_N
 :=\Pr\!\left[
 \ker(A(p))\cap\{-1,0,1\}^N\ne\{0\}
 \right]
 \le
 \sum_{s=1}^N\binom Ns2^s p_s^P.
 \tag{33dm}
\]

Put \(L=\lfloor N/(\ln N)^2\rfloor\). The Wallis bound gives \(p_1=1/2\) and
\(p_s\le s^{-1/2}\) for \(s\ge2\). Since

\[
 \ln\!\left(\sum_{s=2}^{L}\binom Ns2^s\right)
 =O\!\left(\frac{N\ln\ln N}{(\ln N)^2}\right)
 =o\!\left(\frac N{\ln N}\right),
\]

the contribution of \(s\le L\) to (33dm) is at most

\[
 2N2^{-P}
 +\exp\!\left[-(4\ln2-o(1))\frac N{\ln N}\right].
 \tag{33dn}
\]

For sufficiently large \(N\), one has \(L\ge\sqrt N\). The remaining contribution is therefore
at most

\[
 3^N L^{-P/2}
 \le
 \exp[-(2-\ln3-o(1))N].
 \tag{33do}
\]

There are at most \(M+1\) admissible shifts, so (33dn)--(33do), without any independence
between different shifts, imply

\[
 \Pr[\text{(33dh) fails for some }p]
 \le(M+1)U_N=o(1).
 \tag{33dp}
\]

For the nonlocality condition, fix \(j,q\). Then
\(d_H(c_j,c^{(q)})\) has distribution \(\operatorname{Bin}(M,1/2)\), and a Chernoff bound gives

\[
 \Pr[d_H(c_j,c^{(q)})\le M/4]\le e^{-M/16}.
 \tag{33dq}
\]

The union bound over \(j\le P\) and \(0\le q\le M\) is \(o(1)\). Thus (33dh) and
(33di) hold together with positive probability.

Finally, (33dh) makes the map \(u\mapsto A(p)u\) injective on \(\{0,1\}^N\). Each row
has at most \(N+1\) subset-sum values, so
\(2^N\le(N+1)^P\), which proves (33dj). \(\square\)

Random detecting matrices with \(O(N/\ln N)\) rows are classical; finite-alphabet versions
also follow from the random-matrix analysis of Sedaghat, Müller, and Marvasti. The additional
point in Proposition 24 is structural: the same sign centers lift all adjacent-pair shifts
simultaneously while remaining linearly far from the entire prefix path. Consequently, neither
prefix locality, rowwise slice capacity, nor the full family of shifted ternary kernels can yield
a super-entropy lower bound. Within this slice framework, any further obstruction must use the
endpoint-centrality clause in Proposition 11.

### Proposition 25 (few arbitrary exceptions do not rescue prefix neighborhoods)

Fix \(A>0\), put \(W=A\sqrt M\), and retain \(\ell_0\), \(\mathcal N_\rho\), and
\(N=M/16\) from Proposition 22. There is an absolute constant \(c>0\) such that the
following holds for every sufficiently large \(M\) divisible by \(32\) and every
\(\ell_0\le\rho\le M/64\).

Suppose that an injective center family has a decomposition

\[
 \mathcal C=\mathcal C_{\mathrm{loc}}\mathbin{\dot\cup} E,
 \qquad
 \mathcal C_{\mathrm{loc}}\subseteq\mathcal N_\rho,
 \qquad
 |E|=K,
 \tag{33dr}
\]

where the centers in \(E\) are arbitrary. Then

\[
 |\mathcal C|
 \ge
 K+
 c\frac M{W+\rho}
 \frac{\bigl(N\ln2-K\ln(N+1)\bigr)_+}
 {\ln(2\rho+1)}.
 \tag{33ds}
\]

Consequently, there is an absolute constant \(\kappa>0\) such that, for every fixed
\(A,C>0\), there is \(\delta_{A,C}>0\) with the following property. For every
sufficiently large \(M\) divisible by \(32\), every injective family \(\mathcal C\)
of at most \(CM/\ln M\) arbitrary sign centers contains at least

\[
 \kappa\frac M{\ln M}
 \tag{33dt}
\]

centers \(c\) satisfying

\[
 \min_{0\le q\le M}d_H(c,c^{(q)})>\delta_{A,C}M.
 \tag{33du}
\]

#### Proof

Use the \(T\) pairwise disjoint crossing intervals \(I_i\) and the corresponding variable-block
pairs from Proposition 22. They may be chosen so that

\[
 T\ge c_0\frac M{W+\rho}
 \tag{33dv}
\]

for an absolute constant \(c_0>0\). Choose one prefix-neighborhood representation for each
center in \(\mathcal C_{\mathrm{loc}}\), and let \(r_i\) be the number whose prefix base
\(q_j\) belongs to \(I_i\). For an exceptional center \(e\in E\), define its row on the
\(i\)-th variable-block slice by

\[
 b^{(i)}_{e,s}
 =
 \frac{e_{p_i+2s-1}-e_{p_i+2s}}2
 \in\{-1,0,1\},
 \qquad 1\le s\le N,
 \tag{33dw}
\]

where \(p_i=t_i+M/2\) as in (33db).

Combine these \(K\) rows with the \(r_i\) local rows from (33cv). The resulting matrix must
have no nonzero kernel vector in \(\{-1,0,1\}^N\). Indeed, if \(v\ne0\) were such a vector,
use \(v\) in the block construction (33ct). Every exceptional center would have zero
disagreement sum by (33dw). Every local center based outside \(I_i\) would leave both endpoints
outside the central window, exactly as in Proposition 22, while every local center based inside
\(I_i\) would also have zero disagreement sum. The resulting distinct cube points would collide
under all of \(\mathcal C\), contradicting injectivity.

The combined matrix is therefore injective on \(\{0,1\}^N\). A local row has at most
\(\rho\) nonzero coefficients and hence at most \(2\rho+1\) subset-sum values. An arbitrary
exceptional row has at most \(N+1\) such values. Consequently,

\[
 2^N
 \le
 (2\rho+1)^{r_i}(N+1)^K,
 \qquad
 r_i
 \ge
 \frac{\bigl(N\ln2-K\ln(N+1)\bigr)_+}
 {\ln(2\rho+1)}.
 \tag{33dx}
\]

The intervals \(I_i\) are disjoint, so
\(\sum_i r_i\le|\mathcal C_{\mathrm{loc}}|\). Summing (33dx) and using (33dv) proves
(33ds), after decreasing the absolute constant.

For the final consequence, fix any

\[
 0<\kappa<\frac{\ln2}{64}.
 \tag{33dy}
\]

Suppose that fewer than \(\kappa M/\ln M\) centers have prefix-path distance greater than
\(\rho=\lceil\delta M\rceil\), where \(0<\delta\le1/128\) will be fixed momentarily.
Use those centers as \(E\) and all remaining centers as \(\mathcal C_{\mathrm{loc}}\).
For sufficiently large \(M\), one has

\[
 \ell_0\le\rho\le M/64,
 \qquad
 W\le\rho,
 \qquad
 N\ln2-K\ln(N+1)\ge\frac12N\ln2.
 \tag{33dz}
\]

Equations (33ds) and (33dz) then give, for another absolute \(c_1>0\),

\[
 |\mathcal C|
 \ge
 \frac{c_1}{\delta}\frac M{\ln M}.
 \tag{33ea}
\]

Choose
\(\delta_{A,C}>0\) smaller than both \(1/128\) and \(c_1/(2C)\).
Then (33ea) contradicts \(|\mathcal C|\le CM/\ln M\). Hence at least the number of
centers in (33dt) satisfy (33du). \(\square\)

Along dimensions divisible by \(32\), Proposition 25 upgrades the one-center consequence of
Proposition 22 to an entropy-scale population. In particular, \(O(1)\), \(O(\sqrt M)\), or more generally
\(o(M/\ln M)\) arbitrary correctors cannot rescue a family that otherwise remains in a
sublinear prefix neighborhood. Together with Proposition 24, this isolates the unresolved
regime sharply: a candidate optimal family needs \(\Theta(M/\ln M)\) genuinely global rows,
and their detecting power must be coupled to endpoint centrality.

### Proposition 26 (one crossing slice is tail-robust at the entropy scale)

Fix \(A>0\), let \(32\mid M\), put \(N=M/16\) and \(W=A\sqrt M\), and fix one
crossing slice from the construction of Proposition 22. Write its variable blocks as

\[
 J_s=\{p+2s-1,p+2s\},
 \qquad 1\le s\le N,
 \tag{33eb}
\]

and let \(x(v),y(v)\) be the pair in (33ct) associated with
\(v\in\{-1,0,1\}^N\setminus\{0\}\).
There is a constant \(C_A<\infty\) and a family \(\mathcal C\) of at most

\[
 C_A\frac N{\ln N}
 \tag{33ec}
\]

actual sign centers such that, for every nonzero \(v\), some \(c\in\mathcal C\) satisfies

\[
 \langle c,x(v)\rangle\ne\langle c,y(v)\rangle,
 \qquad
 |\langle c,x(v)\rangle|\le W,
 \qquad
 |\langle c,y(v)\rangle|\le W.
 \tag{33ed}
\]

Conversely, every center family separating all these pairs under the fixed-window truncation
has size at least

\[
 \frac{N\ln2}{\ln(N+1)}.
 \tag{33ee}
\]

Thus the single-slice tail-robust complexity is \(\Theta_A(N/\ln N)\).

#### Proof

For a center \(c\), define its variable-block row and outside offset by

\[
 a_s(c)=\frac{c_{p+2s-1}-c_{p+2s}}2,
 \qquad
 \beta(c)=
 \sum_{k\notin\bigcup_sJ_s}c_kx(v)_k.
 \tag{33ef}
\]

The coordinates outside the variable blocks are agreements and do not depend on \(v\), so
\(\beta(c)\) is well defined. Directly from (33ct), the two endpoint values are

\[
 H_\pm(a,\beta;v)
 =
 \beta+2\sum_{s:v_s=0}a_s
 \mathbin{\pm}2\langle a,v\rangle.
 \tag{33eg}
\]

We first construct sparse detecting rows. Let

\[
 p_0=\frac{A}{8\sqrt N},
 \tag{33eh}
\]

and independently generate \(P=\lceil K_A N/\ln N\rceil\) rows whose entries satisfy

\[
 \Pr[a_s=0]=1-p_0,
 \qquad
 \Pr[a_s=1]=\Pr[a_s=-1]=p_0/2,
 \tag{33ei}
\]

where \(K_A\) is a sufficiently large constant. For a fixed nonzero ternary vector of
support size \(s\), put \(t=p_0s\). Its one-row annihilation probability is

\[
 q_s
 =
 [z^0]\left(1-p_0+\frac{p_0}{2}(z+z^{-1})\right)^s.
 \tag{33ej}
\]

If \(t\le1\), the event that exactly one support coordinate is selected gives
\[
 q_s\le\exp(-e^{-2}t)
 \tag{33ek}
\]
for all sufficiently large \(N\). If \(t\ge1\), condition on the binomial number \(L\) of
selected support coordinates. The central-binomial and Chernoff bounds give

\[
 q_s
 \le
 e^{-t/8}+\sqrt{\frac2t}
 \tag{33el}
\]

whenever \(t\) exceeds an absolute constant; on the remaining compact interval
\(1\le t\le t_0\), the exactly-one event gives \(q_s\le q_0<1\).

These estimates yield

\[
 \sum_{s=1}^N\binom Ns2^sq_s^P=o(1).
 \tag{33em}
\]

For completeness, split the sum at \(1/p_0\) and \(N/(\ln N)^2\). Below \(1/p_0\),
(33ek) gives an exponent \(-\Omega_A(Pp_0s)\), which dominates
\(s\ln(2eN/s)\). Between the two cutoffs, the number of ternary vectors is
\(\exp(o(N/\ln N))\), while \(q_s^P=\exp(-\Omega_A(N/\ln N))\).
Above \(N/(\ln N)^2\), (33el) gives

\[
 q_s=O_A\!\left(\frac{\ln N}{N^{1/4}}\right),
 \]

so the contribution is at most
\[
 \exp\!\left[-\left(\frac{K_A}{4}-\ln3-o(1)\right)N\right].
 \]
Taking \(K_A>4\ln3\), and enlarging it if necessary, proves (33em). Hence, with
probability \(1-o(1)\),

\[
 \ker(A)\cap\{-1,0,1\}^N=\{0\}.
 \tag{33en}
\]

Each row has expected support \(A\sqrt N/8\). A Chernoff bound and a union bound over the
\(P\) rows show that, simultaneously with (33en), every row satisfies

\[
 \|a\|_0\le\frac W4.
 \tag{33eo}
\]

For each such row, set

\[
 \beta=-2\sum_{s=1}^Na_s.
 \tag{33ep}
\]

This offset is realizable by an actual sign center. On a variable block use
\((1,-1)\), \((-1,1)\), or \((1,1)\) according as \(a_s=1,-1,0\).
There are \(M-2N=14N\) outside coordinates. Their fixed signed contributions can realize every
even integer in \([-14N,14N]\), while (33eo) gives
\(|\beta|\le2\|a\|_0=o(N)\).

Now write \(S_\pm(v)=\{s:v_s=\pm1\}\). Substituting (33ep) into (33eg) gives

\[
 H_+(a,\beta;v)
 =-4\sum_{s\in S_-(v)}a_s,
 \qquad
 H_-(a,\beta;v)
 =-4\sum_{s\in S_+(v)}a_s.
 \tag{33eq}
\]

By (33eo), both absolute values are at most \(W\). By (33en), every nonzero \(v\) has a
row with \(\langle a,v\rangle\ne0\); for its lifted center, the two values in (33eq) are
different and both central. This proves (33ed).

For the lower bound, any separating family must have no nonzero ternary vector in the common
kernel of its induced rows. It is therefore injective on \(\{0,1\}^N\), and each row has at
most \(N+1\) subset-sum values. Thus \(2^N\le(N+1)^P\), proving (33ee).
\(\square\)

Proposition 26 closes the last one-slice obstruction left by Propositions 24--25: neither
ternary detection nor endpoint centrality costs more than the entropy scale on a fixed crossing
slice. The affine offsets in (33ep), however, are chosen relative to that slice's outside
agreement pattern. A single sign center cannot choose them independently for different shifts.
The next construction or lower bound must therefore determine whether one entropy-scale family
can synchronize these offsets across the full crossing-slice collection.

### Proposition 27 (all crossing slices synchronize at the entropy scale)

Fix \(A>0\), let \(32\mid M\), and put

\[
 N=\frac M{16},\qquad
 m=\frac M4=4N,\qquad
 h=\frac M{32}=\frac N2,\qquad
 W=A\sqrt M.
 \tag{33er}
\]

For every \(0\le j\le h\), take \(t=2j\) in the pair construction of Proposition 22,
and denote the resulting family by
\[
 \{(x_j(v),y_j(v)):v\in\{-1,0,1\}^N\setminus\{0\}\}.
\]
There is a constant \(C_A<\infty\) and one family \(\mathcal C\) of at most

\[
 C_A\frac N{\ln N}
 \tag{33es}
\]

actual sign centers such that, simultaneously for every \(j\le h\) and every nonzero \(v\),
some \(c\in\mathcal C\) satisfies

\[
 \langle c,x_j(v)\rangle\ne\langle c,y_j(v)\rangle,
 \qquad
 |\langle c,x_j(v)\rangle|\le W,
 \qquad
 |\langle c,y_j(v)\rangle|\le W.
 \tag{33et}
\]

The matching lower bound (33ee) already holds for any one \(j\). Hence the simultaneous
crossing-slice tail-robust complexity is \(\Theta_A(M/\ln M)\).

#### Proof

Index the \(M\) coordinates by \(2m=M/2\) adjacent pairs. For a sign center \(c\), write

\[
 e_r=c_{2r},
 \qquad
 a_r=\frac{c_{2r-1}-c_{2r}}2,
 \qquad
 1\le r\le2m.
 \tag{33eu}
\]

The variable window for shift \(j\) is

\[
 V_j=\{m+j+1,\ldots,m+j+N\},
 \tag{33ev}
\]

and the union of all such windows is

\[
 U=\{m+1,\ldots,m+N+h\}.
 \tag{33ew}
\]

Let \(\beta_j\) be the outside offset for this slice, as in (33ef), and put
\[
 E_j=\beta_j+2\sum_{r\in V_j}a_r.
\]
The all-agreement vector equals the alternating vector outside coordinates
\((2j,2j+M/2]\) and equals \(1\) inside. Consequently,

\[
 E_j
 =
 2\left(
 \sum_{r=1}^{2m}a_r+\sum_{r=j+1}^{j+m}e_r
 \right).
 \tag{33ex}
\]

We now generate one random center. Choose \(e_1,\ldots,e_m\) independently and uniformly
from \(\{-1,1\}\), and extend them periodically:

\[
 e_{m+r}=e_r,
 \qquad 1\le r\le m.
 \tag{33ey}
\]

Put \(Q=N+h=3N/2\), take independent
\(\eta_1,\ldots,\eta_Q\sim\operatorname{Bernoulli}(p_0)\), with \(p_0\) as in
(33eh), and define

\[
 \begin{aligned}
 a_{m+u}&=-e_u\eta_u,
 &&1\le u\le Q,\\
 a_u&=-e_u(1-\eta_u),
 &&1\le u\le Q,\\
 a_u&=-e_u,\qquad a_{m+u}=0,
 &&Q<u\le m.
 \end{aligned}
 \tag{33ez}
\]

Every \(a_r\) belongs to \(\{0,-e_r\}\), so setting
\(c_{2r-1}=e_r+2a_r\) yields an actual sign center. Moreover, each complementary pair in
(33ez) sums to \(-e_u\), and therefore

\[
 \sum_{r=1}^{2m}a_r=-\sum_{u=1}^me_u.
 \tag{33fa}
\]

By the period-\(m\) identity (33ey), every length-\(m\) window has the same sum:

\[
 \sum_{r=j+1}^{j+m}e_r=\sum_{u=1}^me_u.
 \tag{33fb}
\]

Equations (33ex), (33fa), and (33fb) give

\[
 E_j=0
 \qquad\text{for every }0\le j\le h.
 \tag{33fc}
\]

Take \(P=\lceil K_A N/\ln N\rceil\) independent centers from this distribution.
For a fixed \(j\), the coordinates
\[
 (a_r)_{r\in V_j}
 =
 (-e_u\eta_u)_{u=j+1}^{j+N}
\]
are independent and have exactly the lazy-sign distribution (33ei). Hence the estimates
(33ej)--(33em) imply that the probability that the \(P\times N\) matrix on \(V_j\)
has a nonzero ternary kernel is at most

\[
 \exp\!\left[-\Omega_A\!\left(\frac{\sqrt N}{\ln N}\right)\right].
 \tag{33fd}
\]

There are only \(h+1=O(N)\) shifts, so a union bound makes every shifted matrix detecting
simultaneously with probability \(1-o(1)\). Likewise,
\[
 \bigl|\{r\in V_j:a_r\ne0\}\bigr|
 \sim\operatorname{Bin}(N,p_0),
\]
with mean \(A\sqrt N/8\). Since \(W/4=A\sqrt N\), a Chernoff bound and a union
bound over all \(P(h+1)\) row-window pairs show that, simultaneously,

\[
 \bigl|\{r\in V_j:a_r\ne0\}\bigr|\le W/4
 \qquad\text{for every center and every }j.
 \tag{33fe}
\]

Fix \(j\) and nonzero \(v\), and choose a row detecting it. Equation (33fc) is precisely
\(\beta_j=-2\sum_{r\in V_j}a_r\), so the endpoint identity (33eq), now on \(V_j\),
gives

\[
 H_+
 =-4\sum_{s:v_s=-1}a_{m+j+s},
 \qquad
 H_-
 =-4\sum_{s:v_s=1}a_{m+j+s}.
 \tag{33ff}
\]

The two values are distinct because the row detects \(v\), and (33fe) places both in
\([-W,W]\). This proves (33et). The lower bound follows from Proposition 26. \(\square\)

Along dimensions divisible by \(32\), Proposition 27 removes the affine-offset coupling that
Proposition 26 left open. It covers every crossing slice used in Proposition 22, and even every
even shift in the ambient interval, with one entropy-scale family. Therefore the crossing-window
witnesses underlying the prefix-neighborhood lower bounds cannot themselves obstruct a global
\(O(M/\ln M)\) construction once genuinely nonlocal centers are allowed. Any remaining
collision theorem must use cube pairs outside this entire witness system or exploit compatibility
with the other pair regimes.

### Proposition 28 (exact constant baselines leave a cone collision)

Fix \(A>0\), put \(W=A\sqrt M\), and let \(M\) run through sufficiently large multiples
of \(32\). For a sign center \(c\), let \(E_j(c)\), \(0\le j\le h\), be the shifted
baselines in (33ex), and define

\[
 \mathcal Z_M
 =
 \{c:E_0(c)=E_1(c)=\cdots=E_h(c)\}.
 \tag{33fg}
\]

There is a distance-two pair \(x,y\) such that every prefix center collides on \(x,y\) under
the fixed-window truncation and

\[
 \langle c,x\rangle=\langle c,y\rangle
 \qquad\text{for every }c\in\mathcal Z_M.
 \tag{33fh}
\]

In particular, no family whose centers use one exact baseline across all the shifted slices is
full-cube fixed-window injective, regardless of its size. This includes the center family in
Proposition 27.

#### Proof

Subtracting two consecutive instances of (33ex) gives

\[
 E_j(c)-E_{j-1}(c)
 =2(e_{j+m}-e_j),
 \qquad 1\le j\le h.
 \tag{33fi}
\]

Consequently every \(c\in\mathcal Z_M\) satisfies

\[
 e_{m+r}=e_r,
 \qquad 1\le r\le h.
 \tag{33fj}
\]

We use only the case \(r=1\). Put

\[
 i_-=2,
 \qquad
 i_+=\frac M2+2=2(m+1),
 \tag{33fk}
\]

and set

\[
 (x_{i_-},y_{i_-})=(1,-1),
 \qquad
 (x_{i_+},y_{i_+})=(-1,1).
 \tag{33fl}
\]

On the agreement coordinates set \(x_1=y_1=1\), set

\[
 x_k=y_k=(-1)^{k-3}
 \qquad(3\le k\le M/2+1),
 \tag{33fm}
\]

and set \(x_k=y_k=-1\) for \(k>M/2+2\). The alternating middle block has length
\(M/2-1\) and sum \(1\), so the total signed agreement sum is

\[
 1+1-\left(\frac M2-2\right)=4-\frac M2.
 \tag{33fn}
\]

Use the paths \(b_q,u_q\) from Proposition 21. Directly from (33fl),

\[
 u_q=
 \begin{cases}
  2,&2\le q<M/2+2,\\
  0,&q<2\text{ or }q\ge M/2+2.
 \end{cases}
 \tag{33fo}
\]

During the nonzero plateau, the signed agreement prefix sum alternates between \(1\) and \(2\).
Together with (33fn), the identity

\[
 b_q
 =2\sum_{\substack{k\le q\\k\ne i_-,i_+}}x_k
  -\sum_{\substack{k=1\\k\ne i_-,i_+}}^M x_k
 \in\left\{\frac M2-2,\frac M2\right\}
 \tag{33fp}
\]

holds whenever \(u_q=2\). For sufficiently large \(M\), both values exceed
\(W+2=W+|u_q|\). Thus (33cg) holds at every prefix, and Proposition 21 shows that every
prefix center collides on the pair.

Finally, (33fj) at \(r=1\) gives \(c_{i_+}=e_{m+1}=e_1=c_{i_-}\), and hence

\[
 \langle c,x-y\rangle=2(c_{i_-}-c_{i_+})=0
 \tag{33fq}
\]

for every \(c\in\mathcal Z_M\), proving (33fh). The first disagreement has pair index \(1\),
which lies outside every variable window \(V_j\), so this pair is not one of the synchronized
crossing-slice witnesses. Proposition 27 has \(E_j(c)=0\) for every center and every \(j\),
and is therefore covered by the claim. \(\square\)

Proposition 28 isolates the price of exact constant-baseline synchronization, independently of
how the centers are generated. The obstruction follows from the adjacent-window equations, not
from the full period imposed in Proposition 27. The proposition does not exclude centers whose
baselines vary with the shift while retaining enough endpoint margin. Thus the next construction
or obstruction must quantify how much baseline motion is compatible with simultaneous sparse
detection and centrality.

### Proposition 29 (constant baseline motion removes the half-period kernels)

Fix \(A>0\), let \(32\mid M\), and retain \(N,m,h,W\), the shifted pair families, and
the baselines \(E_j\) from Proposition 27. There is a constant \(C_A<\infty\) and a family
\(\mathcal C\) of at most \(C_A N/\ln N\) actual sign centers such that (33et) holds
simultaneously for every \(0\le j\le h\) and every nonzero
\(v\in\{-1,0,1\}^N\). In addition, every center satisfies

\[
 |E_j(c)|\le4
 \qquad(0\le j\le h),
 \tag{33fr}
\]

and, for every \(1\le r\le h\), the family contains centers \(c^{=},c^{\ne}\) with

\[
 c^{=}_{2(m+r)}=c^{=}_{2r},
 \qquad
 c^{\ne}_{2(m+r)}=-c^{\ne}_{2r}.
 \tag{33fs}
\]

Writing \(\mathbf e_k\) for the \(k\)-th standard basis vector, consequently neither of the
half-period two-coordinate vectors
\(\mathbf e_{2r}-\mathbf e_{2(m+r)}\) nor
\(\mathbf e_{2r}+\mathbf e_{2(m+r)}\) belongs to the common ternary kernel
of \(\mathcal C\).

#### Proof

We generate one row. Choose \(\kappa\in\{0,1\}\) uniformly. If \(\kappa=0\), use the
full adjacent pairs \(\{1,2\},\{3,4\},\ldots\) contained in \([h]\); if \(\kappa=1\), use
\(\{2,3\},\{4,5\},\ldots\). Coordinates not covered by a full pair are left single.
For every adjacent pair, independently choose

\[
 (\delta_r,\delta_{r+1})
 =
 \begin{cases}
  (0,0),&\text{with probability }1/2,\\
  (2\sigma,-2\sigma),&\text{with probability }1/2,
 \end{cases}
 \qquad \Pr[\sigma=1]=\Pr[\sigma=-1]=\frac12,
 \tag{33ft}
\]

and put \(\delta_r=0\) on uncovered coordinates. Realize
\(\delta_r=e_{m+r}-e_r\) by choosing an independent uniform sign and using it in both
positions when \(\delta_r=0\), and by taking

\[
 (e_r,e_{m+r})=(-\delta_r/2,\delta_r/2)
 \tag{33fu}
\]

when \(\delta_r\ne0\). Choose all remaining \(e\)-coordinates independently and uniformly.
Every block in (33ft) has zero total defect, so

\[
 D_j:=\sum_{r=1}^j(e_{m+r}-e_r)
 \qquad\text{satisfies}\qquad
 |D_j|\le2
 \quad(0\le j\le h).
 \tag{33fv}
\]

Put \(Q=N+h\), take independent \(\eta_1,\ldots,\eta_Q\sim\operatorname{Bernoulli}(p)\),
where

\[
 p=\frac{A}{16\sqrt N},
 \qquad
 a_{m+u}=-e_{m+u}\eta_u
 \quad(1\le u\le Q).
 \tag{33fw}
\]

We next choose the coordinates of \(a\) outside \(U\). Let
\(S_0=\sum_{r=1}^m e_r\) and \(R=S_0+\sum_{r\in U}a_r\). The complement
\(O=[2m]\setminus U\) contains the \(6N\) completely independent sign coordinates
\[
 \{h+1,\ldots,m\}\mathbin{\dot\cup}\{m+Q+1,\ldots,2m\},
\]
in addition to the bounded-block coordinates above. Conditioning on \(\kappa\), standard
bounded-difference estimates apply: \(R\) is a sum of independent centered block variables of
absolute value at most \(2\), while the two sign counts dominate binomial counts on those
\(6N\) independent coordinates. Hence

\[
 \Pr\left[
  |R|>\frac M8
  \text{ or }
  \min\bigl(|\{r\in O:e_r=1\}|,|\{r\in O:e_r=-1\}|\bigr)<\frac M8
 \right]
 \le e^{-cM}
 \tag{33fx}
\]

for an absolute \(c>0\). On the complementary event, select a subset \(B\subseteq O\)
with \(\sum_{r\in B}e_r=R\), put \(a_r=-e_r\) on \(B\), and put \(a_r=0\) on
\(O\setminus B\). Then every \(a_r\in\{0,-e_r\}\) and

\[
 \sum_{r=1}^{2m}a_r=-S_0.
 \tag{33fy}
\]

Thus the lift \(c_{2r}=e_r\), \(c_{2r-1}=e_r+2a_r\) is an actual sign center. Moreover,
the shifted-window identity gives

\[
 E_j
 =2\left(-S_0+\sum_{r=j+1}^{j+m}e_r\right)
 =2D_j,
 \tag{33fz}
\]

which proves (33fr).

Take \(P=\lceil K_A N/\ln N\rceil\) independent rows. We verify detection without using
independence among the signs \(e_{m+u}\). Condition on all of them. For a fixed shift and a
nonzero ternary vector of support size \(s\), the row inner product has the form
\(\sum_{i=1}^s\epsilon_i\eta_i\), where each fixed \(\epsilon_i\in\{-1,1\}\). If
\(t=ps\le1\), the event that exactly one coordinate is selected gives annihilation probability
at most \(\exp(-e^{-2}t)\). For large \(t\), Fourier inversion gives the uniform estimate

\[
 \begin{aligned}
 \Pr\left[\sum_{i=1}^s\epsilon_i\eta_i=0\right]
 &\le
 \frac1{2\pi}\int_{-\pi}^{\pi}
 \left|1-p+pe^{i\theta}\right|^s\,d\theta\\
 &\le \frac C{\sqrt t}.
 \end{aligned}
 \tag{33ga}
\]

The constants in these bounds are uniform over every sign pattern
\((\epsilon_1,\ldots,\epsilon_s)\). On every fixed compact interval
\(1\le t\le t_0\), the exactly-one event instead gives a
bound \(q_0<1\). Therefore the same three-range calculation as in (33em), followed by a union
bound over the \(h+1\) shifts, yields

\[
 \Pr\left[
  \exists j\le h:\
  \ker(A_j)\cap\{-1,0,1\}^N\ne\{0\}
 \right]=o(1)
 \tag{33gb}
\]

when \(K_A\) is sufficiently large. Also, for every row and shift, the local support has
distribution \(\operatorname{Bin}(N,p)\), with mean \(A\sqrt N/16\). Chernoff and a union
bound over all \(P(h+1)\) row-window pairs give, with probability \(1-o(1)\),

\[
 \bigl|\{r\in V_j:a_r\ne0\}\bigr|
 \le\frac{W-4}{4}.
 \tag{33gc}
\]

The exceptional probability in (33fx), even after multiplication by \(P\), is also \(o(1)\).
For a row detecting \(v\), the general endpoint identities are

\[
 H_+=E_j-4\sum_{s:v_s=-1}a_{m+j+s},
 \qquad
 H_-=E_j-4\sum_{s:v_s=1}a_{m+j+s}.
 \tag{33gd}
\]

Equations (33fr) and (33gc) put both endpoints in \([-W,W]\), while detection makes them
distinct. This proves (33et).

It remains to prove (33fs). For each fixed \(r\le h\), the random partition and (33ft) give

\[
 \Pr[\delta_r\ne0]\ge\frac14,
 \qquad
 \Pr[\delta_r=0]\ge\frac12.
 \tag{33ge}
\]

Hence the probability that the \(P\) rows do not contain both cases for some \(r\le h\) is
at most

\[
 h\left(\left(\frac34\right)^P+\left(\frac12\right)^P\right)=o(1).
 \tag{33gf}
\]

When \(\delta_r=0\), the relevant even coordinates are equal; when \(\delta_r\ne0\), they
are opposite. Thus (33fs) and the common-kernel conclusion hold simultaneously with (33gb),
(33gc), and the supplement event. \(\square\)

Propositions 28--29 make the exact-synchronization boundary sharp. Requiring a constant baseline
forces a shared distance-two collision, but allowing baseline motion of only four already removes
both forced two-coordinate kernels without increasing the entropy-scale crossing complexity.
Therefore neither exact-baseline rigidity nor its half-period kernels can obstruct a more flexible
global construction. What remains is to control pair geometries outside the structured crossing
slices, or to find a higher-order compatibility obstruction that survives bounded baseline motion.

### Proposition 30 (the complete distance-two layer has a square-root lower bound)

Fix \(A>0\), put \(W=A\sqrt M\), and let \(\zeta_A^{(2)}(M)\) be the minimum number
of sign centers whose fixed-window truncations separate every pair at Hamming distance \(2\).
For all sufficiently large \(M\),

\[
 \frac{M-2}{\lceil W\rceil+3}
 \le
 \zeta_A^{(2)}(M)
 \le
 C_A M
 \tag{33gg}
\]

for a constant \(C_A<\infty\).

The layer also has the following projective central-row characterization. For a center family
\(\mathcal C=(c_r)_{r\le P}\), a point \(x\), and \(B\ge0\), put

\[
 J_B(x)=\{r:|\langle c_r,x\rangle|\le B\},
 \qquad
 v_i^{B}(x)=(c_{r,i}x_i)_{r\in J_B(x)}.
 \tag{33gh}
\]

If no two vectors \(v_i^W(x),v_j^W(x)\) are antipodal for any \(x\), then
\(\mathcal C\) separates the complete distance-two layer. Conversely, every separating family
satisfies

\[
 v_i^{W+4}(x)\ne-v_j^{W+4}(x)
 \qquad
 (x\in\{-1,1\}^M,\ i\ne j).
 \tag{33gi}
\]

#### Proof

Let \(y=x^{\{i,j\}}\), and for one row write

\[
 z_k=c_kx_k,
 \qquad
 T=\sum_{k=1}^M z_k,
 \qquad
 D=z_i+z_j.
 \tag{33gj}
\]

Then \(D\ne0\) exactly when \(z_i=z_j\), and the two complete values are \(T\) and
\(T-2D\). If the columns in (33gh) are not antipodal at width \(W\), some row in
\(J_W(x)\) has \(z_i=z_j\); that row separates the pair and has the \(x\)-endpoint central.
This proves sufficiency. Conversely, a separating row has \(D\in\{-2,2\}\). If its
\(y\)-endpoint rather than its \(x\)-endpoint is central, then

\[
 |T|
 \le |T-2D|+2|D|
 \le W+4.
 \tag{33gk}
\]

Thus every separated pair has a row in \(J_{W+4}(x)\) with \(z_i=z_j\), proving (33gi).

We now prove the lower bound. Fix coordinates \(i<j\) and
\(\varepsilon\in\{-1,1\}\), and let

\[
 R_{ij}^{\varepsilon}
 =\{r:c_{r,i}=\varepsilon c_{r,j}\}.
 \tag{33gl}
\]

Restrict to the half-cube \(x_i=\varepsilon x_j\). Rows outside
\(R_{ij}^{\varepsilon}\) have \(D=0\) and never separate the corresponding distance-two
pair. For a row inside this class, write

\[
 B_r(x)=\sum_{k\notin\{i,j\}}c_{r,k}x_k.
\]

For sufficiently large \(M\), one has \(W\ge2\). The pair contribution is \(D=\pm2\),
so at least one endpoint is central precisely when

\[
 B_r(x)\in[-W-2,W+2]
 \tag{33gm}
\]

on the attainable parity lattice. Hence the rows in \(R_{ij}^{\varepsilon}\), expanded over
the at most \(\lceil W\rceil+3\) levels in (33gm), give affine hyperplanes covering
\(\{-1,1\}^{M-2}\). Every normal has all coordinates nonzero. The skew-cover theorem used in
Proposition 12 therefore gives

\[
 |R_{ij}^{\varepsilon}|(\lceil W\rceil+3)
 \ge\frac{M-2}{2}.
 \tag{33gn}
\]

For fixed \(i,j\), the two classes \(R_{ij}^{1}\) and \(R_{ij}^{-1}\) partition the
\(P\) rows. Summing (33gn) over \(\varepsilon\) proves the lower bound in (33gg). In
particular, if \(d_{ij}\) is the Hamming distance between columns \(i,j\) of the center
matrix and

\[
 g_M=\left\lceil\frac{M-2}{2(\lceil W\rceil+3)}\right\rceil,
\]

then every separating family satisfies

\[
 g_M\le d_{ij}\le P-g_M.
 \tag{33go}
\]

For the upper bound, sample \(P=\lceil K_A M\rceil\) independent uniform sign centers.
For fixed \(x,i,j\), the signs \(z_k=c_kx_k\) are independent. The event \(z_i=z_j\)
has probability \(1/2\), and, conditional on its common sign,

\[
 T=R_{M-2}\pm2.
\]

The central limit theorem therefore gives, uniformly in the fixed pair,

\[
 \Pr[z_i=z_j,\ |T|\le W]
 =\frac{q_A}{2}+o_A(1),
 \tag{33gp}
\]

where \(q_A=\Pr[|G|\le A]\) as in Proposition 11. For sufficiently large \(M\), this
probability is at least \(q_A/4\). A union bound over at most
\(2^M\binom M2\) choices of \((x,\{i,j\})\) succeeds once \(K_A\) is sufficiently
large. This proves the upper bound. \(\square\)

Proposition 30 returns from the structured crossing slices to the nearest even-distance layer
in the full cube. Its lower bound applies to arbitrary centers and is sharp for each fixed
coordinate relation viewed in isolation: that relation requires a square-root-size equatorial
cover of a half-cube. Sharing those covers across all coordinate pairs is the unresolved issue.
The present bounds leave precisely the consequential gap

\[
 \Omega_A(\sqrt M)
 \le\zeta_A^{(2)}(M)
 \le O_A(M).
 \tag{33gq}
\]

Determining whether the upper bound can be reduced to \(O_A(M/\ln M)\), or whether the
simultaneous half-cube covers force \(\Omega(M)\) rows, is already a full-cube subproblem and
cannot be decided by any one crossing-slice kernel.

### Proposition 31 (one prefix order with small modulations is linearly costly)

Fix \(A>0\), let \(32\mid M\), put \(W=A\sqrt M\), and for an integer \(\ell\ge1\)
let \(\zeta_{A,\ell}^{\mathrm{pref},2}(M)\) be the minimum size of a family
\(\mathcal C\subseteq\mathcal N_\ell\) separating every distance-two pair. If

\[
 \Lambda:=W+2\ell+4=o(M),
 \tag{33gr}
\]

then

\[
 \zeta_{A,\ell}^{\mathrm{pref},2}(M)
 \ge
 c\frac{M^2}{\ell\Lambda}
 \tag{33gs}
\]

for an absolute constant \(c>0\). In particular, for

\[
 \ell_0=\left\lfloor\frac W{16}\right\rfloor,
 \tag{33gt}
\]

there are constants \(0<c_A<C_A<\infty\) such that

\[
 c_A M
 \le
 \zeta_{A,\ell_0}^{\mathrm{pref},2}(M)
 \le
 C_A M.
 \tag{33gu}
\]

#### Proof

We first prove (33gs). Choose \(\Omega(M/\Lambda)\) integers \(q_0\) in
\([M/4,M/3]\), separated by more than \(\Lambda+2\ell+2\). For each one define

\[
 x^{(q_0)}_k
 =
 \begin{cases}
  1,&k\le M/2+q_0,\\
  -1,&k>M/2+q_0.
 \end{cases}
 \tag{33gv}
\]

Its complete prefix path is

\[
 F_{q_0}(q):=\langle c^{(q)},x^{(q_0)}\rangle
 =
 \begin{cases}
  2(q-q_0),&q\le M/2+q_0,\\
  2(M+q_0-q),&q\ge M/2+q_0.
 \end{cases}
 \tag{33gw}
\]

Since \(q_0\ge M/4\) and \(\Lambda=o(M)\), every base satisfying
\(|F_{q_0}(q)|\le\Lambda\) lies in the cluster

\[
 Q(q_0)=\{q:|q-q_0|\le\Lambda/2\}.
 \tag{33gx}
\]

If \(c=c^{(q),L}\) with \(|L|\le\ell\) and \(q\notin Q(q_0)\), then

\[
 |\langle c,x^{(q_0)}\rangle|
 >\Lambda-2\ell=W+4.
 \tag{33gy}
\]

Every distance-two neighbor changes this value by at most \(4\), so neither endpoint can be
central. Thus only centers admitting a base representation in \(Q(q_0)\) can separate a
distance-two pair incident to \(x^{(q_0)}\).

Choose intervals \(A(q_0),B(q_0)\), each of size at least \(c_0M\) for an absolute
\(c_0>0\), such that

\[
 A(q_0)\subseteq[1,q_0-\Lambda],
 \qquad
 B(q_0)\subseteq[q_0+\Lambda,q_0+M/4].
 \tag{33gz}
\]

For every \(q\in Q(q_0)\), every \(i\in A(q_0)\), and every \(j\in B(q_0)\),
one has

\[
 c^{(q)}_ix^{(q_0)}_i=1,
 \qquad
 c^{(q)}_jx^{(q_0)}_j=-1.
 \tag{33ha}
\]

Hence the base center has zero disagreement sum on \(\{i,j\}\). Its modulation by \(L\)
has nonzero disagreement sum exactly when

\[
 \mathbf1_L(i)\ne\mathbf1_L(j).
 \tag{33hb}
\]

Consequently, among all centers based in \(Q(q_0)\), the incidence columns of every
\(i\in A(q_0)\) must differ from those of every \(j\in B(q_0)\). If the total number of
incidences on \(A(q_0)\cup B(q_0)\) were smaller than
\(\min(|A(q_0)|,|B(q_0)|)\), both sides would contain a zero column, contradicting
(33hb). Since each row has at most \(\ell\) incidences, the cluster contains at least

\[
 c_0\frac M\ell
 \tag{33hc}
\]

centers. Here a center is assigned to a cluster if it admits a representation
\(c^{(q),L}\) with \(q\in Q(q_0)\). No center can be assigned to two clusters: otherwise
two such prefix bases would be at Hamming distance at most \(2\ell\), contrary to the chosen
separation. A center assigned to no cluster has every base representation outside \(Q(q_0)\)
and is excluded by (33gy). Summing (33hc) over \(\Omega(M/\Lambda)\) choices of \(q_0\)
therefore proves (33gs).

It remains to prove the upper bound in (33gu). Put \(\ell=\ell_0\) and

\[
 W_0=W-2\ell.
\]

Take the sampled prefix grid from Proposition 12 with spacing
\(d=\lfloor(W_0-1)/2\rfloor\). It has \(O_A(\sqrt M)\) bases, and every \(x\) has
one base \(c^{(q)}\) satisfying

\[
 |\langle c^{(q)},x\rangle|\le W_0.
 \tag{33hd}
\]

Choose

\[
 R=\left\lceil
  \max\left\{2\sqrt M,\frac{4M}{\ell}\right\}
 \right\rceil=O_A(\sqrt M).
 \tag{33he}
\]

There is a simple graph on \([R]\) with at least \(M\) edges and maximum degree at most
\(\ell\) for all sufficiently large \(M\): choose an almost-regular \(M\)-edge subgraph
of the complete graph, whose maximum degree is at most \(\lceil2M/R\rceil+1\le\ell\).
Assign a distinct edge \(E_k\) to every coordinate \(k\), and for \(t\in[R]\) put

\[
 L_t=\{k:t\in E_k\}.
 \tag{33hf}
\]

Then \(|L_t|\le\ell\), and the incidence columns of distinct coordinates are distinct.
At every sampled base include the base itself and all its modulations by \(L_t\).
This uses \(O_A(M)\) centers.

Fix \(x\) and a distance-two neighbor on \(\{i,j\}\), and choose a base satisfying
(33hd). If its disagreement sum is nonzero, the base separates the pair. Otherwise the two
signed coordinate contributions are opposite. Since \(E_i\ne E_j\), some \(t\) belongs
to exactly one of them; modulation by \(L_t\) makes the disagreement sum nonzero. Moreover,

\[
 |\langle c^{(q),L_t},x\rangle|
 \le W_0+2|L_t|
 \le W.
 \tag{33hg}
\]

Thus the modulated center separates the pair with the \(x\)-endpoint central. This proves the
upper bound and (33gu). \(\square\)

Proposition 31 closes the most direct continuation of the one-order prefix method on the full
distance-two layer. Small modulations can encode the required pair cuts, but their incidence
capacity must be paid independently in \(\Theta(M/(W+2\ell))\) separated central clusters.
At the natural scale \(\ell=\Theta_A(\sqrt M)\), the resulting linear cost is optimal within
this class and exceeds the entropy scale by a factor \(\Theta(\ln M)\). Multiple coordinate
orders or genuinely non-prefix global centers are not covered by this lower bound.

### Proposition 32 (three prefix orders eliminate every pointwise antipodal obstruction)

Suppose that \(M\ge4\) and \(4\mid M\). For every \(x\in\{-1,1\}^M\) there are three sign centers
\(c_1,c_2,c_3\), each realizable as one prefix center under its own coordinate order, such that

\[
 \langle c_a,x\rangle=0
 \qquad (a=1,2,3)
 \tag{33hh}
\]

and their fixed-window truncations separate \(x\) from every distance-two neighbor of \(x\),
for every window width \(W\ge0\). Three is minimal if all witnessing centers are required to
satisfy (33hh).

#### Proof

Partition the coordinates into four sets of size \(M/4\), and assign to them respectively the
three-bit columns

\[
 (+++),\qquad (+--),\qquad (-+-),\qquad (--+).
 \tag{33hi}
\]

Write the assigned column at coordinate \(i\) as
\(u_i=(u_{1,i},u_{2,i},u_{3,i})\), and put

\[
 c_{a,i}=x_i u_{a,i}.
 \tag{33hj}
\]

Every row of (33hi) contains two positive and two negative types with equal multiplicity, so

\[
 \langle c_a,x\rangle=\sum_{i=1}^M u_{a,i}=0.
 \tag{33hk}
\]

Each \(c_a\) is a sign vector. Ordering its positive coordinates before its negative coordinates
realizes it as the prefix center at rank \(|\{i:c_{a,i}=1\}|\) in that order.

All four columns in (33hi) have coordinate product \(+1\), whereas the negative of any one of
them has coordinate product \(-1\). Thus no two assigned columns are antipodal. For every
\(i<j\), some row \(a\) therefore satisfies

\[
 c_{a,i}x_i=u_{a,i}=u_{a,j}=c_{a,j}x_j.
 \tag{33hl}
\]

If \(y=x^{\{i,j\}}\), then (33hk)--(33hl) give

\[
 \langle c_a,y\rangle
 =-2(u_{a,i}+u_{a,j})\in\{-4,4\}.
 \tag{33hm}
\]

Since \(\tau_W(0)\) differs from both \(\tau_W(4)\) and \(\tau_W(-4)\) for every
\(W\ge0\), this row separates the pair.

It remains to prove minimality under (33hh). For one or two such rows, put
\(v_i=(c_{a,i}x_i)_a\). Separation of every distance-two neighbor forces
\(v_i\ne-v_j\) for all \(i\ne j\), while (33hh) makes every row of the column family
balanced. In dimension one, an antipodal-free family uses only one sign and cannot be balanced.
In dimension two, it uses at most one vector from each of the two antipodal pairs. Hence it uses
at most two distinct column types. One type makes both rows constant, while two non-antipodal
types share one coordinate sign and make that row constant. Neither case is balanced. Therefore
at least three rows are necessary. \(\square\)

Proposition 32 identifies the first genuinely global interface in a sampled-permutation attack.
Concentrating the central ranks of every order into a bounded number of clusters cannot by itself
force a distance-two collision: even three singleton clusters can carry the balanced projective
code (33hi). A lower bound for several orders must couple the selected cuts across different
points \(x\), or impose a compatibility condition stronger than pointwise centrality and column
antipodality. Conversely, the three orders above depend on \(x\), so they do not form one global
separating family and do not improve the upper bound in (33gq).

### Proposition 33 (Walsh stars have logarithmic common prefix complexity)

Let \(d\ge0\), and partition \([M]\) into nonempty blocks

\[
 \mathcal B=(B_\lambda)_{\lambda\in\mathbb F_2^d},
 \qquad 4\mid |B_\lambda|.
 \tag{33hn}
\]

For \(g\in\mathbb F_2^d\), define

\[
 x^g_i=(-1)^{g\cdot\lambda}
 \qquad (i\in B_\lambda).
 \tag{33ho}
\]

The minimum number of sign centers \(c_1,\ldots,c_P\) satisfying both

\[
 \langle c_a,x^g\rangle=0
 \qquad (a\le P,\ g\in\mathbb F_2^d)
 \tag{33hp}
\]

and separation of every pair

\[
 \bigl(x^g,(x^g)^{\{i,j\}}\bigr),
 \qquad g\in\mathbb F_2^d,\quad i<j,
 \tag{33hq}
\]

under fixed-window truncation is exactly

\[
 P=d+3.
 \tag{33hr}
\]

The same centers work for every \(W\ge0\), and each center is realizable as one prefix center
under its own coordinate order. In particular, when \(M=4\cdot2^d\), a fixed family of
\(\log_2M+1\) single-rank prefix centers simultaneously separates all distance-two stars around
\(M/4\) points.

#### Proof

We first prove the lower bound. For a putative family satisfying (33hp), let

\[
 u_i=(c_{1,i},\ldots,c_{P,i})\in\{-1,1\}^P,
 \qquad
 S_{a,\lambda}=\sum_{i\in B_\lambda}c_{a,i}.
 \tag{33hs}
\]

A family satisfying (33hq) is nonempty, so \(P\ge1\).
For every row \(a\), equation (33hp) says that the Walsh transform of
\(\lambda\mapsto S_{a,\lambda}\) vanishes at every \(g\). Fourier inversion on
\(\mathbb F_2^d\) therefore gives

\[
 S_{a,\lambda}=0
 \qquad (a\le P,\ \lambda\in\mathbb F_2^d).
 \tag{33ht}
\]

Thus the column multiset inside every block is balanced in every row. It is also antipodal-free:
otherwise the corresponding coordinate pair is not separated at \(x^0=\mathbf1\). Moreover,
two distinct blocks cannot use the same projective column class. Indeed, if
\(i\in B_\lambda\), \(j\in B_\mu\), \(\lambda\ne\mu\), and
\(u_j=\varepsilon u_i\), choose \(g\) with

\[
 (-1)^{g\cdot(\lambda+\mu)}=-\varepsilon.
 \tag{33hu}
\]

Then the signed columns at \(x^g\) are antipodal, contradicting (33hq).

Any nonempty balanced antipodal-free column multiset uses at least four distinct projective
classes. One class cannot balance. With two classes, balance forces equal multiplicities and
antipodal orientations. For three classes
with positive multiplicities \(n_1,n_2,n_3\), balance in any coordinate makes one multiplicity
equal the sum of the other two. The singled-out index must be the same in every coordinate,
since two different such equalities would force the remaining multiplicity to vanish. The other
two columns are therefore equal and antipodal to the singled-out column, again impossible.
Consequently the \(2^d\) blocks require at least \(4\cdot2^d\) distinct projective classes.
Since \(\{-1,1\}^P/\{\pm1\}\) has \(2^{P-1}\) classes,

\[
 4\cdot2^d\le2^{P-1},
 \tag{33hv}
\]

which proves \(P\ge d+3\).

For the matching construction, put \(P=d+3\). For
\(h=(s,t)\in\mathbb F_2^2\), define the four columns

\[
 b^h=
 \left(
 (-1)^s,(-1)^t,(-1)^{s+t},
 \underbrace{(-1)^s,\ldots,(-1)^s}_{d\text{ entries}}
 \right).
 \tag{33hw}
\]

The final block in (33hw) is absent when \(d=0\).
Every row is balanced over the four choices of \(h\). Their projective classes form a
four-element subgroup \(H\) of the coordinatewise-multiplication group
\(\{-1,1\}^P/\{\pm1\}\): the first three coordinates show that no two are projectively
equal, and \([b^h][b^{h'}]=[b^{h+h'}]\). This projective group has
\(2^{P-1}=4\cdot2^d\) elements, so choose its \(2^d\) cosets of \(H\) and index them by
\(\lambda\in\mathbb F_2^d\). If \(r^\lambda\) represents the coset indexed by
\(\lambda\), assign the four oriented columns

\[
 \{r^\lambda\odot b^h:h\in\mathbb F_2^2\}
 \tag{33hx}
\]

equally often to the coordinates in \(B_\lambda\). This is possible by (33hn). Multiplication
by \(r^\lambda\) preserves row balance, so every block sum is zero and (33hp) follows.

Within one block the assigned columns are never antipodal, including repeated columns, and
different blocks use disjoint projective classes. Multiplication by the scalar
\((-1)^{g\cdot\lambda}\) does not change a projective class. Hence, at every \(x^g\), no two
signed columns are antipodal. For every pair \(i<j\), some row therefore has equal signed
coordinate contributions. Its value at \(x^g\) is zero by (33hp), while its value at the
distance-two neighbor is \(4\) or \(-4\). The two truncations differ for every \(W\ge0\),
proving (33hq).

Finally, every sign center is a prefix center after ordering its positive coordinates before its
negative coordinates and taking the prefix rank equal to its number of positive entries. Thus the
construction has the claimed prefix realization. \(\square\)

Proposition 33 shows that multi-point compatibility alone still does not make the pointwise
obstruction additive. A fixed family of only \(\log_2|X|+3\) rows can reuse exact centrality and
projective separation across the Walsh set \(X=\{x^g\}\). Therefore a lower bound for sampled
permutations cannot sum independent costs over a Walsh-compatible packing of hard points. It must
exploit a point set whose coordinate signatures do not admit this Fourier--coset decomposition,
or a restriction tying several sampled ranks to the same order. Proposition 33 covers only the
stars around \(X\), not the complete distance-two layer.

### Proposition 34 (window-common Walsh stars retain logarithmic complexity)

Keep the block partition and Walsh points from (33hn)--(33ho), and write
\(q=2^d\), \(m_\lambda=|B_\lambda|\). Let

\[
 m_{(1)}\le\cdots\le m_{(q)},
 \qquad
 \ell=\left\lceil\frac q2\right\rceil
 \tag{33hy}
\]

be the ordered block sizes. For \(W\ge0\), let \(\mu_{d,W}(\mathcal B)\) be the minimum
number of sign centers \(c_1,\ldots,c_P\) such that

\[
 |\langle c_a,x^g\rangle|\le W
 \qquad(a\le P,\ g\in\mathbb F_2^d)
 \tag{33hz}
\]

and their fixed-window truncations separate every pair in (33hq). If either

\[
 \min_\lambda m_\lambda>W
 \qquad\text{or}\qquad
 \sum_{j=1}^{\ell}m_{(j)}^2>(d+2)W^2,
 \tag{33ia}
\]

then

\[
 \mu_{d,W}(\mathcal B)=d+3.
 \tag{33ib}
\]

The matching centers can be chosen with zero inner product at every Walsh point and are each
realizable as one prefix center under their own coordinate order.

#### Proof

Proposition 33 gives the upper bound: its coset construction has exact zero inner product at
every \(x^g\) and separates all the required stars for every \(W\ge0\).

For the lower bound, consider a family satisfying (33hz), and put

\[
 u_i=(c_{1,i},\ldots,c_{P,i}),
 \qquad
 S_{a,\lambda}=\sum_{i\in B_\lambda}c_{a,i},
 \qquad
 T_a(g)=\langle c_a,x^g\rangle.
 \tag{33ic}
\]

The family is nonempty. Walsh Parseval and (33hz) give, for every row \(a\),

\[
 \sum_\lambda S_{a,\lambda}^2
 =\frac1q\sum_g T_a(g)^2
 \le W^2.
 \tag{33id}
\]

As in Proposition 33, the projective column classes used by distinct blocks are disjoint.
Indeed, if \(u_j=\varepsilon u_i\) for coordinates in distinct blocks, one can choose \(g\)
so that the signed columns at \(x^g\) are antipodal; then flipping those two coordinates leaves
every inner product unchanged. The same argument with \(g=0\) excludes antipodal columns within
one block.

Suppose for contradiction that \(P\le d+2\). There are at most

\[
 2^{P-1}\le2^{d+1}=2q
 \tag{33ie}
\]

projective classes. A block using at most two such classes has a row on which all its columns
have the same sign. For one class this is immediate. For two classes, choose their unique
orientations occurring in the antipodal-free block; the two representatives are neither equal
nor opposite, and hence agree in some row. Thus this block has

\[
 |S_{a,\lambda}|=m_\lambda
 \tag{33if}
\]

for some row \(a\). If \(\min_\lambda m_\lambda>W\), this contradicts (33id). Every block
would therefore need at least three projective classes, requiring at least \(3q>2q\) classes
and contradicting (33ie).

It remains to use the second condition in (33ia). Let \(h\) be the number of blocks using at
least three projective classes. Since every other nonempty block uses at least one and the
supports are disjoint,

\[
 q+2h\le2q,
 \qquad
 h\le\frac q2.
 \tag{33ig}
\]

Consequently at least \(\ell\) blocks use at most two classes. Applying (33if) to those blocks,
possibly with a different row for each block, and then summing (33id) over all rows gives

\[
 \sum_{a,\lambda}S_{a,\lambda}^2
 \ge\sum_{j=1}^{\ell}m_{(j)}^2
 >(d+2)W^2
 \ge PW^2,
 \tag{33ih}
\]

whereas (33id) gives the reverse inequality. This contradiction proves \(P\ge d+3\), and the
upper construction proves equality. \(\square\)

For equal blocks of size \(m=M/q\) and \(d\ge1\), the Fourier-energy condition in (33ia)
becomes

\[
 \frac q2m^2>(d+2)W^2.
 \tag{33ii}
\]

At the natural window \(W=A\sqrt M\), this is equivalent to

\[
 q<\frac{M}{2A^2(d+2)},
 \qquad\text{or equivalently}\qquad
 m>2A^2(d+2).
 \tag{33ij}
\]

Thus choose \(q=2^d\), \(M=qm\), and a multiple of four
\(m=\Theta_A(d)\) satisfying \(m>2A^2(d+2)\). Along this admissible parameter sequence,
\(q=\Theta_A(M/\log M)\): an entropy-scale family of Walsh hard points still shares only
\(d+3=O(\log M)\) common prefix centers. This is a stability statement for families satisfying
the common-centrality condition (33hz). It neither bounds arbitrary families that separate the
same stars without being central at every base point nor covers the complete distance-two layer.

### Proposition 35 (arbitrary-center Walsh stars have exact low-dimensional phases)

For the Walsh blocks in Proposition 33, let \(\nu_{d,W}(\mathcal B)\) be the minimum number
of arbitrary sign centers whose fixed-window truncations separate every pair in (33hq), without
the common-centrality condition (33hz). If \(d=0\) and the unique block has size \(m\), then

\[
 \nu_{0,W}(m)=
 \begin{cases}
 3,&0\le W<m-4,\\
 1,&W\ge m-4.
 \end{cases}
 \tag{33ik}
\]

If \(d=1\) and both blocks have size \(m\), then

\[
 \nu_{1,W}(m,m)=
 \begin{cases}
 4,&0\le W<m-4,\\
 3,&m-4\le W<2m-4,\\
 2,&W\ge2m-4.
 \end{cases}
 \tag{33il}
\]

If \(d=2\) and all four blocks have size \(m\), then

\[
 \nu_{2,W}(m,m,m,m)=4
 \qquad(0\le W<2m-4).
 \tag{33im}
\]

Here \(4\mid m\), as in Proposition 33. In particular, the enlargement from \(W\) to
\(W+4\) in the necessary condition (33gi) is already sharp on two Walsh stars.

#### Proof

We first isolate a pointwise consequence of (33gi). If a center family separates the complete
distance-two star around \(x\in\{-1,1\}^M\) and

\[
 M>W+4,
 \tag{33in}
\]

then

\[
 |J_{W+4}(x)|\ge3.
 \tag{33io}
\]

Indeed, (33gi) says that the columns projected onto \(J_{W+4}(x)\) are antipodal-free. In
dimension at most two they use at most two projective classes. An empty projection makes every
pair antipodal and is impossible. Otherwise the occurring orientation of each class is unique,
and one projected row has the same sign on the representatives of all occurring classes. That row
is therefore constant on all \(M\) signed coordinate contributions, so its inner product at
\(x\) has absolute value \(M\). This contradicts membership in \(J_{W+4}(x)\) under
(33in).

For \(d=0\) and \(W<m-4\), equations (33in)--(33io) give the lower bound three, while
Proposition 33 gives three exact-central centers. If \(W\ge m-4\), the single center \(c=x^0\)
has value \(m\) at the base point and value \(m-4\) at every distance-two neighbor. Their
truncations differ, proving (33ik).

Now let \(d=1\). Suppose first that \(W<m-4\) and \(P\le3\). Since
\(M=2m>W+4\), equation (33io) forces \(P=3\) and all three rows to belong to both
\(J_{W+4}(x^0)\) and \(J_{W+4}(x^1)\). With

\[
 S_{a,0}=\sum_{i\in B_0}c_{a,i},
 \qquad
 S_{a,1}=\sum_{i\in B_1}c_{a,i},
 \tag{33ip}
\]

the two inner products are \(S_{a,0}+S_{a,1}\) and \(S_{a,0}-S_{a,1}\). Hence

\[
 |S_{a,0}|,|S_{a,1}|\le W+4<m.
 \tag{33iq}
\]

Separation makes the projective column supports of the two blocks disjoint, exactly as in
Proposition 33. A block using at most two projective classes has some row constant throughout the
block, giving \(|S_{a,\lambda}|=m\) and contradicting (33iq). Thus each block needs at least
three classes. Three rows provide only four projective classes in total, so the two disjoint
supports cannot exist. Therefore at least four centers are necessary, and Proposition 33 supplies
four.

For the middle range, split each block into two sets of size \(m/2\), and assign the three center
columns as follows:

\[
\begin{array}{c|cccc}
 &B_{0,0}&B_{0,1}&B_{1,0}&B_{1,1}\\ \hline
 c_1&-&-&-&+\\
 c_2&+&+&-&+\\
 c_3&+&-&+&+
\end{array}
\tag{33ir}
\]

At \(x^0\), the three row values are \(m(-,+,+)\); at \(x^1\), they are
\(m(-,+,-)\). After multiplying each signed coordinate column by the corresponding row-value
sign, the four column types at either point are

\[
 (+++),\qquad(++-),\qquad(+-+),\qquad(-++).
 \tag{33is}
\]

Any two types in (33is), including equal types, share a positive coordinate. The corresponding
row therefore changes from \(\pm m\) to \(\pm(m-4)\) when the pair is flipped. Its two
truncations differ whenever \(W\ge m-4\). Conversely, throughout
\(W<2m-4\), equation (33in) holds with \(M=2m\), and (33io) requires at least three
centers. This proves the middle line of (33il).

Finally, two centers suffice in the last range: take \(c_1=-\mathbf1\), and take \(c_2\)
positive on \(B_0\) and negative on \(B_1\). At \(x^0\), the zero-baseline row \(c_2\)
separates pairs within either block, while \(c_1\) separates cross-block pairs by changing from
\(-2m\) to \(-(2m-4)\). At \(x^1\), the roles reverse: \(c_1\) has zero baseline and
handles within-block pairs, while \(c_2\) changes from \(2m\) to \(2m-4\) on cross-block
pairs. These values separate for \(W\ge2m-4\). One center can never suffice, because the two
nonempty blocks must use disjoint projective column classes. This completes (33il).

For the upper bound in (33im), take the four block-constant Walsh centers

\[
 c^a_i=(-1)^{a\cdot\lambda}
 \qquad(a,\lambda\in\mathbb F_2^2,\ i\in B_\lambda).
 \tag{33it}
\]

At \(x^g\), the row \(a=g\) has value \(4m\), while the other three rows have value zero.
Coordinates in the same block have equal signed contributions in every zero row. For coordinates
in distinct blocks \(B_\lambda,B_\mu\), choose a nonzero
\(h\perp(\lambda+\mu)\) and put \(a=g+h\). This is a zero row, and its two signed
contributions are equal. Flipping the pair therefore changes its value from zero to \(4\) or
\(-4\), proving separation for every \(W\ge0\).

Conversely, suppose that \(P\le3\) and \(W<2m-4\). Since \(4m>W+4\), equation
(33io) forces \(P=3\) and all three rows into \(J_{W+4}(x^g)\) for every \(g\). The
four nonempty blocks use disjoint full projective supports, while three rows provide only four
projective classes. Each block therefore uses exactly one class. Antipodality within a block is
forbidden, so all its columns are equal and

\[
 |S_{a,\lambda}|=m
 \qquad(a\le3,\ \lambda\in\mathbb F_2^2).
 \tag{33iu}
\]

For every row, Walsh Parseval would then give

\[
 4m^2=\sum_\lambda S_{a,\lambda}^2
 =\frac14\sum_gT_a(g)^2
 \le(W+4)^2
 <4m^2,
 \tag{33iv}
\]

because every row belongs to every \(J_{W+4}(x^g)\). This contradiction proves the lower
bound in (33im). \(\square\)

Proposition 35 shows exactly where common centrality carries information. Below \(m-4\), the
two-point arbitrary-center problem has the same complexity as the common-central problem. At the
first endpoint, three rows can instead place every base value just outside the window and every
witnessed neighbor exactly inside it. Thus the formal replacement \(W\mapsto W+4\) in the
projective condition is unavoidable, but it does not by itself provide the rowwise Fourier-energy
bound used in Proposition 34. Whether an analogue of that bound controls \(\nu_{d,W}\) for
growing \(d\) remains open. The \(d=2\) example gives a second escape mechanism: different
Walsh rows are zero at different base points, so no fixed row is central throughout the family.
It also rules out merely replacing \(W\) by \(W+4\) in either condition of (33ia): for
\(m\ge8\) and \(d=2,W=0\), both \(m>W+4\) and
\(2m^2>4(W+4)^2\) hold, but four rows still beat the five-row exact-zero benchmark from
Proposition 33.

### Proposition 36 (a five-row escape requires within-block variation)

Let \(d=3\), let all eight Walsh blocks have the same size \(m\), where \(4\mid m\), and put
\(W=0\). Among sign centers that are constant on every block, the minimum number separating all
pairs in (33hq) is

\[
 \nu^{\mathrm{bc}}_{3,0}(m)=6.
 \tag{33iw}
\]

Consequently, any five-center family for the unrestricted quantity \(\nu_{3,0}\), if one exists,
must use at least two projective column classes inside some block.

#### Proof

A block-constant center is a Boolean function
\(f:\mathbb F_2^3\to\{-1,1\}\), and its value at \(x^g\) is

\[
 T_f(g)=m\sum_{\lambda\in\mathbb F_2^3}
 f(\lambda)(-1)^{g\cdot\lambda}.
 \tag{33ix}
\]

The Walsh sum in (33ix) is even. Thus a nonzero \(T_f(g)\) has absolute value at least
\(2m\ge8\), and changing two coordinates cannot move it to zero. At \(W=0\), a row can
therefore separate a pair at \(x^g\) only when \(T_f(g)=0\). Such a row separates every pair
inside one block. For distinct blocks \(B_\lambda,B_\mu\), it separates their coordinate pairs
exactly when

\[
 f(\lambda)(-1)^{g\cdot\lambda}
 =f(\mu)(-1)^{g\cdot\mu}.
 \tag{33iy}
\]

Hence the problem has \(8\binom82=224\) cross-block requirements and, at each of the eight
base points, one requirement aggregating all within-block pairs. Multiplying \(f\) by \(-1\)
preserves its coverage, so fix \(f(0)=1\). The resulting 128 truth tables split into eight
Walsh characters, 56 functions with four-point Walsh support, and 64 functions with full Walsh
support. The last class has no zero Walsh coefficient and covers nothing.

The finite verification now enumerates every five-row subset of the 64 useful functions. Duplicate
or inert rows can be deleted, and a family of fewer than five useful distinct rows can be padded
to five, so this covers all families of at most five rows. Grouping by the number \(r\) of
four-sparse rows gives

\[
\begin{array}{c|r|r|r}
 r&\text{families}&\text{maximum covered}&\text{uncovered}\\ \hline
 0&56&228&4\\
 1&3{,}920&222&10\\
 2&86{,}240&214&18\\
 3&776{,}160&204&28\\
 4&2{,}938{,}320&194&38\\
 5&3{,}819{,}816&184&48
\end{array}
\tag{33iz}
\]

The verifier constructs every coverage set directly from (33ix)--(33iy); no solver relaxation is
used. Since every entry in the third column of (33iz) is below \(232\), five rows are impossible.

For the upper bound, choose any six distinct Walsh characters as centers. At a base point \(x^g\),
at least five of them have zero value. For fixed \(\lambda\ne\mu\), the character labels whose
signed contributions at the two blocks are opposite form an affine hyperplane of size four.
Therefore one of the at least five zero rows has equal contributions and separates the pair.
Within-block pairs are separated by any zero row. This proves (33iw). \(\square\)

Proposition 36 closes the most direct continuation of the \(d=2\) escape in Proposition 35.
Deleting one or more of the eight block-constant Walsh rows cannot produce a five-row family at
\(d=3\). Indeed, if a block used one projective class in both orientations, those two columns
would be antipodal at \(x^0\); hence one class per block would make the family block-constant.
A genuine escape must therefore introduce internal projective variation inside the blocks. The
proposition does not decide whether that additional freedom suffices. The complete finite
verification and its raw output are retained in the
[verification bundle](../../computations/bundles/d3-block-constant-walsh-stars/).

### Proposition 37 (a three-active five-row Walsh escape is rigid)

Keep \(d=3\), eight blocks of size four, and \(W=0\). Suppose that five arbitrary sign
centers \(c_1,\ldots,c_5\) separate all the Walsh stars in (33hq), and write

\[
 u_i=(c_{1,i},\ldots,c_{5,i})\in\{-1,1\}^5.
 \tag{33ja}
\]

The projective column supports

\[
 \mathcal P_\lambda=\{[u_i]:i\in B_\lambda\}
 \qquad(\lambda\in\mathbb F_2^3)
 \tag{33jb}
\]

are pairwise disjoint, and each class occurring inside one block has a unique orientation.
Consequently the family uses at most sixteen projective classes. More precisely, choose a
representative \(r_p\in\{-1,1\}^5\) for every occurring class. A column type
\(z=(\lambda,p)\) then has a unique orientation \(\varepsilon_z\in\{-1,1\}\), a positive
multiplicity \(n_z\), and signed row values

\[
 v_a(g,z)=(-1)^{g\cdot\lambda}\varepsilon_z r_{p,a},
 \qquad
 T_a(g)=\sum_z n_zv_a(g,z).
 \tag{33jc}
\]

Two distinct types, or two coordinates of one type when \(n_z\ge2\), are separated at
\(x^g\) exactly when some row \(a\) satisfies

\[
 v_a(g,z)=v_a(g,z')=:t,
 \qquad
 T_a(g)\in\{0,4t\}.
 \tag{33jd}
\]

Thus the original \(8\binom{32}{2}=3968\) coordinate-pair conditions are equivalent to at
most

\[
 8\left(\binom{16}{2}+16\right)=1088
 \tag{33je}
\]

type-pair conditions.

For a Walsh base \(g\), call a row active when

\[
 T_a(g)\in\{-4,0,4\},
 \qquad
 A_g=\{a:T_a(g)\in\{-4,0,4\}\}.
 \tag{33jf}
\]

Every base has at least three active rows. If \(|A_g|=3\), then all three active baselines
vanish, their signed three-bit columns form one parity tetrahedron with each of its four
projected column types occurring eight times, and

\[
 T_a(g)=0\quad(a\in A_g),
 \qquad
 \prod_{a\in A_g}c_a=\pm x^g.
 \tag{33jg}
\]

#### Proof

Within one block, two opposite orientations of the same projective class remain antipodal at
every Walsh base, so flipping the corresponding coordinates changes none of the five row values.
They cannot occur in a separating family. If coordinates in distinct blocks \(B_\lambda\) and
\(B_\mu\) use the same projective class, choose \(g\) so that multiplication by the two Walsh
signs makes their signed columns antipodal. This is possible because \(\lambda\ne\mu\). Again
no row changes when the pair is flipped. This proves the disjointness and orientation claims in
(33jb), and the bound of sixteen follows from the number of projective five-bit classes.

For a row \(a\), a type pair at \(x^g\) contributes signed values
\(v_a(g,z),v_a(g,z')\). If these values are opposite, flipping the pair leaves \(T_a(g)\)
unchanged. If both equal \(t\), the flipped value is \(T_a(g)-4t\). Since \(\tau_0\) retains
only zero, the two truncations differ exactly when \(T_a(g)=0\) or \(T_a(g)=4t\). This proves
(33jd). Coordinates with the same type have identical coverage, so retaining one condition for
each unordered pair of types, including a repeated type only when its multiplicity is at least
two, proves (33je).

Only active rows can satisfy (33jd). Their signed column projections are antipodal-free, since
every coordinate pair must agree in a witnessing row. One or two projected rows cannot suffice:
an antipodal-free family in dimensions one or two has a coordinate of constant sign, as in the
proof of Proposition 35, and that row would have absolute baseline \(32\), contrary to (33jf).
Hence \(|A_g|\ge3\).

Suppose now that \(|A_g|=3\). Let the distinct projected signed columns have positive
multiplicities \(n_1,\ldots,n_k\). They occupy at most the four projective classes of
\(\{-1,1\}^3/\{\pm1\}\). If \(k\le3\), their Gram matrix has diagonal entries \(3\),
off-diagonal entries of absolute value \(1\), and least eigenvalue at least \(1\). Therefore

\[
 \sum_{a\in A_g}T_a(g)^2
 \ge \sum_{j=1}^k n_j^2
 \ge \frac{32^2}{3}>48,
 \tag{33jh}
\]

whereas activity gives the reverse bound \(\sum_{a\in A_g}T_a(g)^2\le48\). Thus all four
projective classes occur, each in one orientation.

Fixing one column and inspecting the orientations of the other three antipodal pairs shows that,
up to signed row permutations, an antipodal transversal of the four projective classes with no
constant row has one of two forms. The first is the nonparity transversal

\[
 (+++),\quad(++-),\quad(+-+),\quad(-++).
 \tag{33ji}
\]

The last three types pairwise agree in exactly one row, always with positive sign. Condition
(33jd) therefore forces the corresponding three baselines to lie in \(\{0,4\}\). If the
multiplicities in the displayed order are \(n_0,n_1,n_2,n_3\), those baselines are
\(32-2n_3,32-2n_2,32-2n_1\). Hence each of \(n_1,n_2,n_3\) is \(14\) or \(16\), contradicting
their total being at most \(32\).

The remaining form is a parity tetrahedron, for example

\[
 (+++),\quad(+--),\quad(-+-),\quad(--+).
 \tag{33jj}
\]

For each row, one pair in (33jj) agrees uniquely with positive sign and another agrees uniquely
with negative sign. Separating both pairs in (33jd) forces that row's baseline to be zero. The
three zero-baseline equations together with \(\sum_jn_j=32\) form the order-four Hadamard
system, whose unique solution is \(n_0=n_1=n_2=n_3=8\). The product of the three signed entries
is therefore constant over all coordinates. Since the signed entry in row \(a\) is
\(c_{a,i}x_i^g\), this constant-product identity is exactly
\(\prod_{a\in A_g}c_a=\pm x^g\), proving (33jg). \(\square\)

Proposition 37 removes the coordinate labels from the unrestricted five-row problem and isolates
its first rigid active-set regime. By itself it does not prove that five rows are impossible: a
candidate either has a three-active base satisfying (33jg), or every Walsh base has four or five
active rows. The two global compatibility branches are resolved separately below.

### Proposition 38 (the four/five-active branch has a four-active base with two zero rows)

Under the assumptions of Proposition 37, suppose in addition that \(|A_g|\ge4\) at every
Walsh base. Then some base has exactly four active rows. Moreover, in any five-row separating
family, every base with \(|A_g|=4\) has at least two zero active baselines:

\[
 \min_g|A_g|=4,
 \qquad
 |A_g|=4
 \Longrightarrow
 \bigl|\{a\in A_g:T_a(g)=0\}\bigr|\ge2.
 \tag{33jk}
\]

Consequently, after a common Walsh translation, row permutation, and independent row sign
changes, every family in the four/five-active branch can be normalized so that

\[
 A_0=\{1,2,3,4\},
 \qquad
 T_1(0)=T_2(0)=0,
 \qquad
 T_3(0),T_4(0)\in\{0,4\},
 \tag{33jl}
\]

while row \(5\) is inactive at \(x^0\).

#### Proof

For a block \(B_\lambda\), put

\[
 k_\lambda=|\mathcal P_\lambda|,
 \qquad
 S_{a,\lambda}=\sum_{i\in B_\lambda}c_{a,i},
 \qquad
 e_\lambda=|\{a:|S_{a,\lambda}|=4\}|.
 \tag{33jm}
\]

If \(k_\lambda=1\), every row is constant on the block. If \(k_\lambda=2\), the two
oriented column representatives are neither equal nor opposite, so they agree in some row; that
row is constant on the block. The cases \(k_\lambda\ge3\) need no additional information.
Thus in every case

\[
 e_\lambda\ge3-k_\lambda.
 \tag{33jn}
\]

Proposition 37 gives \(\sum_\lambda k_\lambda\le16\), and hence the total number of extreme
row--block incidences satisfies

\[
 E:=\sum_\lambda e_\lambda
 \ge24-\sum_\lambda k_\lambda
 \ge8.
 \tag{33jo}
\]

Suppose that all five rows were active at all eight bases. Walsh Parseval would give, for each
row \(a\),

\[
 \sum_\lambda S_{a,\lambda}^2
 =\frac18\sum_gT_a(g)^2
 \le16.
 \tag{33jp}
\]

Each extreme block already contributes \(16\) to the left-hand side, so a row can be extreme on
at most one block. This would give \(E\le5\), contradicting (33jo). Under the additional
hypothesis every base has four or five active rows, so at least one must therefore have exactly
four.

Fix now a base \(g\) with four active rows. Negating an active row if necessary, normalize each
nonzero active baseline to \(4\), and let \(z\) be the number of zero baselines among the four.
We prove \(z\ge2\).

First suppose \(z=0\). Associate to each coordinate the subset of the four active rows in which
its signed entry at \(x^g\) is positive. Condition (33jd) says that the subsets belonging to any
two distinct coordinates intersect. Each active row contains exactly eighteen positive signed
entries because its baseline is \(4\).

We use the following elementary weighted fact: in a pairwise-intersecting multiset of \(N\)
nonempty subsets of a four-element set, some element belongs to at least \(3N/5\) members. To
see this, first observe that a singleton, if present, lies in every member and is covered by
weight one. Otherwise consider the two-element members of the underlying intersecting family.
Every pairwise-intersecting edge family on four vertices is contained in a star or a triangle:
after fixing two edges with common endpoint \(v\), any member avoiding \(v\) must join their other
endpoints, and all further members must lie in the resulting triangle. If there are no
two-element members, weight every ground element by \(1/3\). In the star case, weight its center
by \(2/3\) and the other three elements by \(1/3\). In the triangle case, weight its three
vertices by \(1/2\). These cases give a fractional cover of total weight at most \(5/3\). If
\(d_i\) is the multiplicity-degree of element \(i\), then

\[
 N\le\sum_i\alpha_i d_i
 \le\frac53\max_i d_i,
 \tag{33jq}
\]

which proves the fact. Applying it with \(N=32\) forces some active row to contain at least
\(96/5>19\) positive entries, contradicting that all four contain eighteen.

It remains to exclude \(z=1\). The zero row divides the coordinates into two sets \(X,Y\) of
size sixteen according to its signed entry. For each of the other three rows, let \(p_i\) and
\(q_i\) be the fractions of positive entries in \(X\) and \(Y\). A pair with one coordinate in
each side cannot be separated by the zero row, so its positive-row subsets among the remaining
three rows must intersect. Independent uniform choices \(x\in X\), \(y\in Y\) therefore give

\[
 1\le\sum_{i=1}^3p_iq_i.
 \tag{33jr}
\]

Each nonzero row has eighteen positive entries in total, so
\(p_i+q_i=18/16=9/8\). The arithmetic--geometric mean inequality now gives

\[
 \sum_{i=1}^3p_iq_i
 \le3\left(\frac9{16}\right)^2
 =\frac{243}{256}<1,
 \tag{33js}
\]

contradicting (33jr). Hence \(z\ge2\), proving (33jk). A common multiplication of all five
centers by \(x^g\) sends the selected base to \(0\) without changing projective classes or
separation, and row permutations and sign changes then give (33jl). \(\square\)

Proposition 38 supplies a sound symmetry break for the four/five-active finite branch.
Any exact classification or proof certificate for that branch may fix one four-active base and
two zero rows from the outset; no assumption about a block being single-class, and no
simultaneous row/column ordering, is required. A separate branch must retain the three-active
parity identity (33jg).

### Proposition 39 (the three-active branch also reaches a four/five-active base)

Under the assumptions of Proposition 37, suppose that some Walsh base has exactly three active
rows. Translate that base to \(0\), permute and negate rows, and write the resulting normalization
as

\[
 A_0=\{1,2,3\},\qquad
 T_1(0)=T_2(0)=T_3(0)=0,\qquad
 c_1c_2c_3=1.
 \tag{33jt}
\]

Then every nonzero Walsh base has an active tail row, and at least one such base has four or five
active rows:

\[
 g\ne0
 \Longrightarrow
 A_g\cap\{4,5\}\ne\varnothing,
 \qquad
 \max_{g\ne0}|A_g|\ge4.
 \tag{33ju}
\]

Consequently the three-active branch has the additional safe normalization

\[
 |A_{e_1}|\ge4,
 \qquad
 4\in A_{e_1},
 \tag{33jv}
\]

after a linear change of the Walsh block labels and, if necessary, an interchange of rows \(4\)
and \(5\).

#### Proof

By Proposition 37, the signed columns in the first three rows at \(0\) are the four positive-parity
vectors

\[
 H=\{(+++),(+--),(-+-),(--+)\},
 \tag{33jw}
\]

each with total multiplicity eight. Fix \(g\ne0\), and suppose first that neither tail row is
active. If one \(h\in H\) occurred on both sides of the Walsh cut
\((-1)^{g\cdot\lambda}=\pm1\), a coordinate from each side would have signed head columns \(h\)
and \(-h\). The first three rows would disagree on that pair, while the two inactive tail rows
could not witness (33jd), a contradiction. Hence every head type lies wholly on one side of the
cut. Each side contains sixteen coordinates, so exactly two head types lie on each side. The sum
of any two elements of the parity tetrahedron \(H\) is, up to sign, twice a coordinate vector.
The three head baselines at \(g\) are therefore, in some order,

\[
 \{T_1(g),T_2(g),T_3(g)\}=\{0,0,\pm32\}.
 \tag{33jx}
\]

Only two head rows would be active, and the tail rows were assumed inactive. This contradicts
\(|A_g|\ge3\) from Proposition 37 and proves the first assertion in (33ju).

It remains to show that the seven nonzero bases cannot all have exactly three active rows. Work
in the vector space of sign vectors modulo global sign, with pointwise multiplication written
additively, and put \(z_a=[c_a]\). Equation (33jt) gives
\(z_1+z_2+z_3=0\). Let

\[
 E=U\oplus V\cong\mathbb F_2^2\oplus\mathbb F_2^2
 \tag{33jy}
\]

have bases corresponding to \(z_1,z_2\) and \(z_4,z_5\), respectively, and let
\(L:E\to\{-1,1\}^{32}/\{\pm1\}\) be the resulting linear map. The coefficient vectors of the
ten products of three distinct centers form exactly

\[
 K=\{0\}\cup
 \{(u,v):u\in U\setminus\{0\},\ v\in V\setminus\{0\}\}.
 \tag{33jz}
\]

Indeed, the head triple gives \(0\); choosing two head rows and one tail row gives a nonzero
element in each factor, as does choosing one head row and both tail rows.

The eight projective Walsh characters

\[
 W=\{[x^g]:g\in\mathbb F_2^3\}
 \tag{33ka}
\]

form a three-dimensional subspace: every nonzero Walsh character takes both signs on the eight
nonempty blocks. If every base had exactly three active rows, Proposition 37 would identify every
element of \(W\) with the product of its three active centers, and hence would give
\(W\subseteq L(K)\).

This inclusion is impossible. If \(L\) has rank four, it is injective and
\(P=L^{-1}(W)\) is a three-dimensional subspace contained in \(K\). But
\(\dim(P\cap U)\ge1\), whereas every nonzero pure \(U\)-vector is excluded from \(K\). If \(L\)
has rank three, then \(W=\operatorname{im}L\) and the kernel is a line
\(\langle r\rangle\). For \(L(K)\) to equal \(W\), the set \(K\) would have to meet every coset
of that line. When \(r=(u,v)\) has both components nonzero, the coset

\[
 (u,0)+\langle r\rangle=\{(u,0),(0,v)\}
 \tag{33kb}
\]

misses \(K\). When \(r\) is a nonzero pure \(U\)-vector, choose
\(u'\in U\setminus\{0,r\}\); both elements of
\(u'+\langle r\rangle\) are nonzero pure \(U\)-vectors and again miss \(K\). The pure \(V\)
case is symmetric. Finally, rank at most two cannot contain the three-space \(W\). Thus some
nonzero base has at least four active rows. The group
\(\operatorname{GL}(3,2)\) fixes the zero Walsh base and acts transitively on the seven nonzero
bases, so that base may be sent to \(e_1\). The first part of (33ju) then makes at least one tail
row active there, and a tail-row interchange proves (33jv). \(\square\)

Proposition 39 couples the two active-count regimes without conflating them. In the three-active
branch, an exact search may simultaneously fix the parity tetrahedron at \(0\), require at least
four active rows at \(e_1\), and require one specified tail row to be active there. These
necessary normalizations are used only as a cross-check in Proposition 56; its direct
classification does not prune by Proposition 39.

### Proposition 40 (a four-active base has at least three zero rows)

Under the assumptions of Proposition 37, every Walsh base with exactly four active rows has at
least three zero active baselines:

\[
 |A_g|=4
 \Longrightarrow
 \bigl|\{a\in A_g:T_a(g)=0\}\bigr|\ge3.
 \tag{33kc}
\]

#### Proof

Proposition 38 excludes zero or one zero active baseline. Suppose for contradiction that some
four-active base has exactly two. Translate it to \(0\), permute the rows, and negate rows with
nonzero baseline. Since the fifth row is inactive, a further sign change in that row gives the
normalization

\[
 A_0=\{1,2,3,4\},\qquad
 (T_1(0),T_2(0),T_3(0),T_4(0))=(0,0,4,4),\qquad
 T_5(0)>0,\quad T_5(0)\ne4.
 \tag{33kd}
\]

Project the 32 signed columns at \(0\) to their first four entries. Their plus-counts are
\((16,16,18,18)\). Two projected patterns that occur must either agree in one of the first two
rows or both be positive in one of the next two rows; otherwise no active row can separate the
corresponding coordinate pair at \(0\). Moreover, every four-bit pattern has multiplicity at
most eight: it has two five-bit projective lifts, and Proposition 37 places each lift in a unique
block with multiplicity at most four.

These conditions have exactly 30 labelled integer profiles. Under independent sign changes and
interchange of the first two rows, together with interchange of the next two rows, they form five
orbits. In the pattern order

\[
 (4,7,9,10,12,13,14,15),
\]

where the binary expansion records the four positive entries, representatives are

\[
\begin{split}
 &(6,8,6,8,2,2,0,0),\qquad
 (6,8,7,7,3,0,0,1),\\
 &(6,8,7,7,2,1,1,0),\qquad
 (7,7,7,7,0,2,2,0),\\
 &(7,7,7,7,1,1,1,1).
\end{split}
 \tag{33ke}
\]

The classification is an exhaustive integer enumeration: it lists the 36 maximal cliques of the
four-bit compatibility graph and solves the four exact plus-count equations by meet-in-the-middle.
For each orbit representative, retain only the five Walsh bases
\(G_*=\{0,4,5,6,7\}\). Encode every five-bit projective class as either unused or assigned to one
Walsh block with one orientation and multiplicity in \(\{1,2,3,4\}\), impose mass four in every
block, and impose all distinct-type and repeated-type separation conditions on \(G_*\). Deleting
the conditions at bases \(1,2,3\) makes each formula a relaxation of the original branch.

The five resulting CNFs have 19,545 variables and respectively
\(1{,}230{,}269\), \(1{,}230{,}269\), \(1{,}233{,}966\), \(1{,}230{,}269\), and
\(1{,}237{,}663\) clauses. Each is UNSAT by a binary DRAT certificate independently checked by
drat-trim. The deterministic classifier, CNF generator, compressed certificates, hashes, tool
versions, and one-command verifier are contained in the
[five-base proof bundle](../../computations/bundles/d3-z2-five-base-unsat/README.md).
Thus none of the five exhaustive local profiles extends even to the five-base relaxation, a
contradiction. Hence the number of zero active baselines is at least three. \(\square\)

Proposition 40 leaves only the \(z=3,4\) four-active profiles. It does not resolve their global
compatibility with five-active bases, nor the separate three-active parity branch.

### Proposition 41 (the three-zero local branch has two profile families)

Under the assumptions of Proposition 37, fix a Walsh base with exactly four active rows and
exactly three zero active baselines. Normalize the base to \(0\) and the active rows so that

\[
 (T_1(0),T_2(0),T_3(0),T_4(0))=(0,0,0,4).
 \tag{33kf}
\]

For \(h\in\{-1,1\}^3\) and \(\sigma\in\{-1,1\}\), let \(m(h,\sigma)\) be the
multiplicity of the projected four-row pattern \((h,\sigma)\). Put

\[
 H=\{(+++),(+--),(-+-),(--+)\}.
 \tag{33kg}
\]

Then every projected profile belongs to exactly one of the following two families, after
possibly replacing \(H\) by \(-H\).

1. There are integers \(\alpha_h\in\{0,\ldots,8\}\), \(h\in H\), with
   \(\sum_{h\in H}\alpha_h=18\), and
   \[
   m(h,+)=\alpha_h,\qquad m(h,-)=8-\alpha_h
   \quad(h\in H),
   \tag{33kh}
   \]
   while all patterns with head outside \(H\) have multiplicity zero.

2. There is a two-element set \(S\subset H\) such that
   \[
   \begin{cases}
   m(h,+)=8,\quad m(-h,+)=1,&h\in S,\\
   m(h,-)=7,&h\in H\setminus S,
   \end{cases}
   \tag{33ki}
   \]
   and all other multiplicities are zero.

There are \(924\) labelled profiles. Independent sign changes and permutations of the first
three rows form the safe group \((C_2)^3\rtimes S_3\); its action has exactly \(32\) profile
orbits, \(31\) from (33kh) and one from (33ki).

#### Proof

Proposition 37 bounds every four-row pattern multiplicity by eight, since it has two five-row
projective lifts and each lift occurs in one block with multiplicity at most four. Two occurring
patterns must agree in one of the first three coordinates or both be positive in the fourth:
otherwise no active row can separate the corresponding coordinate pair at \(0\).

Use \(H\) to select one representative from each antipodal pair of three-bit heads, and write

\[
 U_h=\sum_\sigma m(h,\sigma),\qquad
 V_h=\sum_\sigma m(-h,\sigma),\qquad
 d_h=U_h-V_h.
\]

The first three zero-baseline equations give

\[
 \sum_{h\in H}d_hh=0.
 \tag{33kj}
\]

The \(3\times4\) matrix with columns \(H\) has kernel spanned by
\((1,1,1,1)\), so \(d_h=t\) is independent of \(h\). Replacing \(H\) by
\(-H\) if necessary gives \(t\ge0\). In fact \(t>0\): if \(t=0\) and a negative
pattern occurred on either side of an antipodal pair, compatibility would make the opposite
side empty; the equality \(U_h=V_h\) would then make both sides empty. But the fourth row has
fourteen negative entries.

If \((h,-)\) occurs, compatibility again forces \(V_h=0\), and hence the total mass of that
antipodal pair is \(t\). A negative fourth entry cannot occur on the lighter side. If the pair
has no negative fourth entry, both of its patterns are positive in the fourth row; write
\(V_h=r_h\) and \(U_h=t+r_h\). The pattern bound gives
\(0\le r_h\le8-t\). If \(J\subseteq H\) indexes the pairs containing a negative fourth entry,
then

\[
 14\le |J|t,\qquad
 32=4t+2\sum_{h\notin J}r_h,\qquad
 0\le r_h\le8-t.
 \tag{33kk}
\]

These three relations leave only \(t=7,8\). Indeed \(t\le3\) cannot hold because
\(|J|\le4\). For \(t=4\), all four pairs belong to \(J\), making the middle expression in
(33kk) equal to \(16\). For \(t=5,6\), at least three pairs belong to \(J\), so there is at
most one remaining \(r_h\); yet the sum of the remaining terms would have to be respectively
\(6\) or \(4\), larger than \(8-t\).

If \(t=7\), the middle equation in (33kk) requires two all-positive pairs with \(r_h=1\);
the other two pairs have mass seven and together contain all fourteen negative entries. This is
(33ki). If \(t=8\), every lighter side is empty and each selected head has total mass eight.
Distributing the eighteen positive fourth entries gives (33kh). Conversely, the vectors in
\(H\) pairwise agree in a coordinate, so every profile in (33kh) is compatible and has first
three plus-counts sixteen. For (33ki), two negative-head patterns agree in a zero row, while
every remaining pair is either witnessed by a zero row or has two positive fourth entries.
Moreover,

\[
 7\sum_{h\in H}h=0
\]

gives the first three zero baselines in the second family. Thus both families are sufficient.

For (33kh), the number of ordered choices of \((\alpha_h)_{h\in H}\) is

\[
 [x^{18}](1+x+\cdots+x^8)^4
 =\binom{21}{3}-4\binom{12}{3}+6
 =456.
 \tag{33kl}
\]

The two choices \(H,-H\) give \(912\) labelled profiles. Family (33ki) contributes
\(2\binom42=12\), proving the total \(924\). The safe group has order \(48\), acts
transitively on \(H,-H\), and the stabilizer of \(H\) induces the full \(S_4\) action on its
vertices. Hence the orbits in (33kh) are the unordered quadruples

\[
 0\le a\le b\le c\le d\le8,\qquad a+b+c+d=18.
 \tag{33km}
\]

The coefficient
\([q^{18}u^4]\prod_{j=0}^8(1-uq^j)^{-1}=31\). The \(S_4\) action is transitive on
two-element subsets, so (33ki) contributes one further orbit. This proves the orbit count.
An independent clique enumeration and exact row-sum computation is provided by the
[local-profile verifier](../../computations/bundles/d3-z3-local-profile-classification/README.md).
\(\square\)

The classification is not a local impossibility. For example, the following five-row block
assignment has ten distinct projective classes, uses each class in one block with multiplicity
at most four, and satisfies all \(496\) coordinate-pair conditions at \(0\):

\[
\begin{array}{c|l}
000 &(+++++)^4\\
001 &(++++-)^1\cup(+++-+)^3\\
010 &(+--++)^4\\
011 &(+--+-)^1\cup(+---+)^3\\
100 &(-+-++)^4\\
101 &(-+--+)^4\\
110 &(--+++)^4\\
111 &(--+-+)^4 .
\end{array}
 \tag{33kn}
\]

Its baselines at \(0\) are \((0,0,0,4,28)\). It is not a global witness: at
\(g=e_1\) the baselines are \((0,0,0,28,4)\), and a \(+++++\) column from block \(000\)
and a \(+++-+\) column from block \(001\) become \(+++++\) and \(---+-\), which no row
separates. Thus Proposition 41 closes every argument based only on the selected-base
compatibility, row margins, and projective multiplicity bound. The remaining \(z=3\) question
is exactly whether any of the \(32\) profiles admits a different lift and block assignment
compatible with the other Walsh bases.

### Proposition 42 (one Walsh cut excludes eight three-zero profiles)

Under the normalization of Proposition 41, write the tetrahedral profiles in the sorted form

\[
 0\le a\le b\le c\le d\le8,
 \qquad a+b+c+d=18.
 \tag{33ko}
\]

No five-row separating family can have the exceptional profile (33ki). The same holds for every
profile (33kh) satisfying

\[
 a\le1,
 \qquad a+b\le4,
 \qquad (a=0\ \hbox{or}\ d=8).
 \tag{33kp}
\]

Equivalently, the excluded tetrahedral orbits are

\[
\begin{gathered}
 (0,2,8,8),\ (1,1,8,8),\ (0,3,7,8),\ (1,2,7,8),\\
 (0,4,6,8),\ (1,3,6,8),\ (0,4,7,7).
\end{gathered}
 \tag{33kq}
\]

Consequently at most twenty-four of the thirty-two local \(z=3\) orbits can extend to a global
five-row family.

#### Proof

Fix a nonzero Walsh base \(g\). By Proposition 37, every occurring five-bit projective class has
a unique state

\[
 (\lambda,\varepsilon,n),
 \qquad \lambda\in\mathbb F_2^3,
 \quad \varepsilon\in\{-1,1\},
 \quad 1\le n\le4,
 \tag{33kr}
\]

where \(\lambda\) is its block, \(\varepsilon\) its orientation, and \(n\) its multiplicity.
Map this state to

\[
 (\chi_g(\lambda),\varepsilon,n),
 \qquad \chi_g(\lambda)=(-1)^{g\cdot\lambda}.
 \tag{33ks}
\]

This quotient retains the side of the Walsh cut but forgets the four individual blocks on each
side. Each side has total mass sixteen. The signed row values at base \(0\) are independent of
\(\lambda\), and those at base \(g\) depend on \(\lambda\) only through
\(\chi_g(\lambda)\). Hence (33ks) preserves all five baselines and every distinct-type and
repeated-type condition (33jd) at the two bases \(0,g\). It also preserves the unique
orientation and the multiplicity bound \(n\le4\). The quotient deletes only the requirement
that the classes on each side can be packed into four specified blocks of mass four. Thus its
two-half feasibility system is a relaxation of every lift across \(\{0,g\}\).

It remains to solve this finite relaxation for the thirty-two orbits of Proposition 41. Encode
each five-bit projective class as unused or assigned a side, an orientation, and a multiplicity
in \(\{1,2,3,4\}\). Impose mass sixteen on each side, the selected four-row profile at base
\(0\), the inactive fifth-row normalization, and all type-pair conditions at bases \(0,1\).
The choice \(g=1\) is without loss of generality because
\(\operatorname{GL}(3,2)\) acts transitively on the nonzero bases while fixing \(0\).

For the exceptional orbit and the seven profiles in (33kq), the resulting formulas have 7,980
variables and between 208,388 and 208,854 clauses. All eight are UNSAT by binary DRAT
certificates independently checked by `drat-trim`. The direct parameterization of the thirty-one
bounded partitions, the exceptional orbit, the deterministic generator, compressed
certificates, hashes, tool versions, and one-command verifier are contained in the
[two-half proof bundle](../../computations/bundles/d3-z3-two-half-unsat/README.md).
Therefore none of these eight profiles can lift across even one nonzero Walsh base. Removing
them from the thirty-two exhaustive orbits leaves twenty-four. \(\square\)

Proposition 42 is only a strict branch reduction. It makes no feasibility claim for the other
twenty-four orbits and does not impose the remaining six nonzero Walsh bases. It therefore
supplies neither a global five-row witness nor a decision of the surviving \(z=3\) branch.

### Proposition 43 (three plane points are feasible but the plane closes)

The tetrahedral \(z=3\) profile

\[
 (a,b,c,d)=(2,2,6,8)
 \tag{33kt}
\]

has an eight-block lift satisfying every separation condition at the three bases
\(\{0,e_1,e_2\}\). It has no lift satisfying the full Walsh plane

\[
 \langle e_1,e_2\rangle=\{0,e_1,e_2,e_1+e_2\}.
 \tag{33ku}
\]

Consequently this orbit cannot occur in a global five-row separating family, and at most
twenty-three of the thirty-two local \(z=3\) orbits remain.

#### Proof

For feasibility at three points, use the following actual eight-block assignment:

\[
\begin{array}{c|l}
000 &(+-+-+)^4\\
001 &(---++)^4\\
010 &(---+-)^4\\
011 &(-++-+)^4\\
100 &(-++--)^2\cup(-++++)^2\\
101 &(++-+-)^3\cup(++---)^1\\
110 &(++--+)^1\cup(++-++)^3\\
111 &(+-+--)^2\cup(+-+++)^2 .
\end{array}
 \tag{33kv}
\]

The twelve displayed projective classes occur in unique blocks and orientations, with
multiplicity at most four. Their four-row projection at \(0\) has nonzero multiplicities

\[
 m_3=2,\quad m_5=m_6=m_{11}=6,\quad
 m_8=8,\quad m_{13}=m_{14}=2,
 \tag{33kw}
\]

which is the orbit (33kt). Direct summation gives

\[
 T(0)=(0,0,0,4,8),\qquad
 T(e_1)=T(e_2)=(0,0,0,0,0).
 \tag{33kx}
\]

Checking (33jd) for the \(3\binom{32}{2}=1488\) coordinate pairs proves the first assertion.

We next retain the full plane while quotienting the blocks. The two characters \(e_1,e_2\)
partition \(\mathbb F_2^3\) into four cells \(q\in\mathbb F_2^2\), each containing two
blocks and hence mass eight. Map every projective-class state by

\[
 (\lambda,\varepsilon,n)\longmapsto
 ((\lambda_1,\lambda_2),\varepsilon,n).
 \tag{33ky}
\]

For every base in (33ku), the signed row value depends on \(\lambda\) only through this cell.
Thus (33ky) preserves the five baselines and every distinct-type and repeated-type condition
(33jd) on the plane. It deletes only the division of each mass-eight cell into two specified
mass-four blocks, so its feasibility system is a relaxation of any global lift.

The fourth plane point contains information absent from the first three. If \(S_a(q)\) denotes
the row-\(a\) sum in cell \(q\), the two equations
\(T_a(e_1)=T_a(e_2)=0\) imply

\[
 S_a(00)=S_a(11)=A_a,\qquad
 S_a(10)=S_a(01)=B_a,
 \tag{33kz}
\]

and hence

\[
 T_a(0)=2(A_a+B_a),\qquad
 T_a(e_1+e_2)=2(A_a-B_a).
 \tag{33la}
\]

In particular the two baselines are congruent modulo eight. This does not by itself give a
contradiction, so we impose the complete type-pair conditions at all four plane bases.

For profile (33kt), the resulting four-cell CNF has \(15{,}400\) variables and \(592{,}792\)
clauses. It is UNSAT by a binary DRAT certificate independently checked by drat-trim. The
deterministic generator, the trimmed compressed certificate, hashes, the direct verifier of
(33kv), tool versions, and one-command verifier are contained in the
[Walsh-plane proof bundle](../../computations/bundles/d3-z3-plane-profile-exclusions/README.md).
Therefore no plane lift, and hence no global lift, of (33kt) exists. Removing this orbit from
the twenty-four survivors of Proposition 42 leaves twenty-three. \(\square\)

Proposition 43 isolates the first genuinely closed Walsh subspace in this branch. Three points
of a two-dimensional plane still admit a real block assignment, while the dependent fourth
point rules out the same local profile. By itself, it does not decide any of the remaining
twenty-three \(z=3\) orbits.

### Proposition 44 (the \(a\le1\) tetrahedral boundary is impossible)

Under the normalization of Proposition 41, every tetrahedral \(z=3\) profile that extends to a
global five-row separating family satisfies

\[
 2\le a\le b\le c\le d\le8.
 \tag{33lb}
\]

Consequently at most fifteen of the thirty-two local \(z=3\) orbits remain.

#### Proof

The sorted partitions in Proposition 41 with \(a=0\) are exactly

\[
\begin{gathered}
 (0,2,8,8),\ (0,3,7,8),\ (0,4,6,8),\ (0,4,7,7),\\
 (0,5,5,8),\ (0,5,6,7),\ (0,6,6,6).
\end{gathered}
 \tag{33lc}
\]

Indeed \(b+c+d=18\), while \(b\le c\le d\le8\), gives \(2\le b\le6\); solving for each
such \(b\) yields (33lc). Proposition 42 excludes the first four profiles there. For the last
three, impose the complete four-cell plane relaxation of Proposition 43. The resulting CNFs
have the following sizes:

\[
\begin{array}{c|c|c}
 (a,b,c,d)&\text{variables}&\text{clauses}\\ \hline
 (0,5,5,8)&15{,}400&591{,}855\\
 (0,5,6,7)&15{,}400&592{,}792\\
 (0,6,6,6)&15{,}400&592{,}792.
\end{array}
 \tag{33ld}
\]

All three formulas are UNSAT by binary DRAT certificates independently checked by drat-trim.
The parameterized generator, trimmed compressed certificates, hashes, tool versions, and
one-command verifier are in the
[Walsh-plane proof bundle](../../computations/bundles/d3-z3-plane-profile-exclusions/README.md).
Since every global lift maps to this relaxation, none of the last three profiles in (33lc) can
be global. Thus all seven \(a=0\) profiles are excluded.

The sorted partitions with \(a=1\) are exactly

\[
\begin{gathered}
 (1,1,8,8),\ (1,2,7,8),\ (1,3,6,8),\ (1,3,7,7),\\
 (1,4,5,8),\ (1,4,6,7),\ (1,5,5,7),\ (1,5,6,6).
\end{gathered}
 \tag{33le}
\]

Indeed \(b+c+d=17\), while \(1\le b\le c\le d\le8\), gives \(1\le b\le5\);
solving for each such \(b\) yields (33le). Proposition 42 excludes the first three profiles.
For the other five, the complete four-cell plane relaxation gives

\[
\begin{array}{c|c|c}
 (a,b,c,d)&\text{variables}&\text{clauses}\\ \hline
 (1,4,5,8)&15{,}400&592{,}624\\
 (1,3,7,7)&15{,}400&593{,}729\\
 (1,4,6,7)&15{,}400&593{,}561\\
 (1,5,5,7)&15{,}400&593{,}665\\
 (1,5,6,6)&15{,}400&593{,}665.
\end{array}
 \tag{33lf}
\]

All five formulas are UNSAT by binary DRAT certificates independently checked by drat-trim
and included in the same Walsh-plane proof bundle. Hence every global tetrahedral profile has
\(a\ge2\), proving (33lb). Proposition 42 excludes eight orbits, including the exceptional
orbit, and the nine disjoint plane certificates exclude profile (33kt), the three remaining
\(a=0\) profiles, and the five remaining \(a=1\) profiles. Thus \(32-8-9=15\) orbits remain.
\(\square\)

Proposition 44 closes the two lowest boundary layers of the tetrahedral parameter space. It
gives no feasibility claim for any profile with \(a\ge2\).

### Proposition 45 (two \(a=2\) profiles are impossible)

No global five-row separating family can have either tetrahedral \(z=3\) profile

\[
 (a,b,c,d)=(2,3,5,8)\quad\hbox{or}\quad(2,2,7,7).
 \tag{33lg}
\]

Consequently at most thirteen of the thirty-two local \(z=3\) orbits remain.

#### Proof

Use the four-cell Walsh-plane relaxation of Proposition 43 and identify its cells with
\(\mathbb F_2^2\). Cell translations and invertible linear maps act by

\[
 q\longmapsto q+t,
 \qquad q\longmapsto Aq,
 \qquad A\in\operatorname{GL}(2,2).
 \tag{33lh}
\]

For a translation,

\[
 \chi_g(q+t)=\chi_g(t)\chi_g(q).
 \tag{33li}
\]

Thus at each plane base \(g\), all class values and every row baseline acquire the same sign
\(\chi_g(t)\). Equality of two class values and the condition that their common value \(v\)
has baseline in \(\{0,4v\}\) are unchanged. Cell masses are merely permuted, and the selected
profile at \(g=0\) is fixed. An invertible linear map similarly permutes the three nonzero
plane bases. Hence the affine group acts on the plane models.

Order the sixteen projective classes by their canonical binary labels. Translate the least
selected class to cell \(0\). Since each cell has mass eight and the total mass is thirty-two,
some selected class lies outside cell \(0\). The stabilizer
\(\operatorname{GL}(2,2)\) is transitive on the three nonzero cells, so map the least selected
class outside cell \(0\) to cell \(1\). We may therefore impose

\[
 \min\{p:p\text{ is selected}\}\in C_0,
 \qquad
 \min\{p:p\text{ is selected outside }C_0\}\in C_1.
 \tag{33lj}
\]

The first condition is encoded by 384 implications and the second by 256, one for each
forbidden state of the candidate least class. Every plane model has a representative satisfying
these 640 clauses, so this is a symmetry normalization rather than a relaxation or an added
mathematical assumption.

For the two profiles in (33lg), the original and symmetry-normalized formula sizes are

\[
\begin{array}{c|c|c|c}
 (a,b,c,d)&\text{variables}&\text{original clauses}&\text{normalized clauses}\\ \hline
 (2,3,5,8)&15{,}400&592{,}728&593{,}368\\
 (2,2,7,7)&15{,}400&593{,}729&594{,}369.
\end{array}
 \tag{33lk}
\]

Both normalized formulas are UNSAT by binary DRAT certificates independently checked by
drat-trim. The parameterized generator,
the optional symmetry normalization, trimmed compressed certificates, hashes, tool versions, and
one-command verifier are in the
[Walsh-plane proof bundle](../../computations/bundles/d3-z3-plane-profile-exclusions/README.md).
Therefore neither profile in (33lg) has a plane lift or a global lift. Removing both from the
fifteen survivors of Proposition 44 leaves thirteen. \(\square\)

Proposition 45 excludes two points of the \(a=2\) layer. It does not exclude the other
\(a=2\) profiles or strengthen Proposition 44 to \(a\ge3\).

### Proposition 46 (two repeated-\(\alpha\) profiles are impossible)

No global five-row separating family can have either tetrahedral \(z=3\) profile

\[
 (a,b,c,d)=(2,4,4,8)\quad\hbox{or}\quad(3,3,4,8).
 \tag{33ll}
\]

Consequently at most eleven of the thirty-two local \(z=3\) orbits remain.

#### Proof

First complete the affine cell normalization of Proposition 45. After the least selected class
has been placed in \(C_0\) and the least selected class outside \(C_0\) in \(C_1\), the residual
stabilizer fixes \(C_0,C_1\) and exchanges \(C_2,C_3\). The mass constraints force a selected
class outside \(C_0\cup C_1\), since those two cells contain only sixteen of the thirty-two
coordinates. We may therefore impose

\[
 \min\{p:p\text{ is selected outside }C_0\cup C_1\}\in C_2.
 \tag{33lm}
\]

For each class \(p\), its eight states in \(C_3\) are forbidden unless an earlier class already
lies in \(C_2\cup C_3\). These \(16\cdot8=128\) implications remove the last factor two, so the
resulting 768 cell clauses select a representative modulo all
\(4\cdot3\cdot2=24\) affine cell labels.

Both profiles in (33ll) have an order-two head stabilizer. For a tetrahedral head \(h\), define
the cell-invariant lift-mass signature

\[
 \rho(h)=
 \bigl(n_{h,+,+},n_{h,+,-},n_{h,-,+},n_{h,-,-}\bigr),
 \tag{33ln}
\]

where the last two signs are the fourth- and fifth-row signs. A signed permutation of the first
three rows exchanges the two equal-\(\alpha\) heads and leaves the fourth and fifth rows fixed.
It preserves the normalized profile and all plane witness conditions. Thus, in increasing
canonical head order \(h_1<h_2\), we may require

\[
 \rho(h_1)\le_{\mathrm{lex}}\rho(h_2).
 \tag{33lo}
\]

This is compatible with (33lm): first use the head transposition to obtain (33lo), and then use
the affine cell action to obtain (33lj) and (33lm). The latter action changes only cell labels,
so it leaves \(\rho\) unchanged. Hence the two normalizations together meet every orbit rather
than imposing a new hypothesis.

The four components of each signature are encoded by forty one-hot variables, and five prefix
variables implement the lexicographic comparison. The original and normalized formula sizes are

\[
\begin{array}{c|c|c|c|c}
 (a,b,c,d)&\text{original variables}&\text{original clauses}
 &\text{normalized variables}&\text{normalized clauses}\\ \hline
 (2,4,4,8)&15{,}400&592{,}456&15{,}445&593{,}721\\
 (3,3,4,8)&15{,}400&592{,}560&15{,}445&593{,}825.
\end{array}
 \tag{33lp}
\]

Both normalized formulas are UNSAT by trimmed binary DRAT certificates independently checked by
drat-trim. The parameterized generator, compressed certificates, hashes, tool versions, and
one-command verifier are in the
[Walsh-plane proof bundle](../../computations/bundles/d3-z3-plane-profile-exclusions/README.md).
Therefore neither profile in (33ll) has a plane lift or a global lift. Removing both from the
thirteen survivors of Proposition 45 leaves eleven. \(\square\)

Proposition 46 gives no feasibility claim for the other eleven profiles and does not close the
\(z=3\) branch.

### Proposition 47 (exact block recovery from the plane quotient)

Let a four-cell Walsh-plane model satisfy the class-uniqueness and cell-mass conditions of
Proposition 43. It refines to eight mass-four Walsh blocks, without changing any plane baseline
or plane pair witness, if and only if no cell has positive class-multiplicity partition

\[
 3+3+2.
 \tag{33lq}
\]

Equivalently, if \(N_j(q)\) is the number of mass-\(j\) projective classes in cell \(q\), then
the refinement exists exactly when

\[
 N_1(q)\ge N_3(q)\qquad(q\in\mathbb F_2^2).
 \tag{33lr}
\]

#### Proof

Fix one mass-eight cell and list its positive class multiplicities as
\(m_1,\ldots,m_r\in\{1,2,3,4\}\). Class uniqueness means that an occurring projective class
must remain intact in one original block. Thus the cell refines into two mass-four blocks if
and only if some subset of the \(m_i\) sums to four.

If some \(m_i=4\), that class is one block. Suppose no part is four. With exactly one part
three, a part one accompanies it because the remaining mass is odd; they form \(3+1\). If no
part is three, parts one and two always contain a submultiset of mass four. With two parts
three, the remaining mass two is either \(1+1\), giving two copies of \(3+1\), or one part
two, giving (33lq), which has no mass-four submultiset. Three parts three already exceed the
cell mass. This proves that (33lq) is the unique obstruction. The same cases give the equivalent
count criterion (33lr).

The four cells refine independently. Every plane character is constant on the two original
blocks inside one cell, so assigning each intact class to either recovered block preserves all
four plane baselines and every witness condition. Conversely, any eight-block refinement
provides the required mass-four subset in each cell.

In the CNF, (33lq) is excluded by one ternary clause for every cell and every triple of distinct
classes, three choices of the mass-two class in that triple, and eight orientation choices. Hence the exact
refinement option adds

\[
 4\binom{16}{3}\cdot3\cdot2^3=53{,}760
\]

clauses and no variables. The generator and an exhaustive check of the fifteen integer
partitions of eight are included in the
[Walsh-plane proof bundle](../../computations/bundles/d3-z3-plane-profile-exclusions/README.md).
\(\square\)

Proposition 47 exactly recovers the block structure forgotten by the plane quotient. It does
not impose pair separation at the four bases outside the plane and therefore does not reduce
the eleven surviving profile orbits by itself.

### Proposition 48 (exact transverse-character factorization and side symmetry)

Let a four-cell Walsh-plane model satisfy the class-uniqueness and cell-mass conditions of
Proposition 43. For every selected projective class \(p\), write its plane state as
\((q_p,\varepsilon_p,n_p)\). Labeled refinements into the eight mass-four blocks are in
bijection with signs \(s_p\in\{-1,1\}\) satisfying

\[
 \sum_{p:q_p=q,\ s_p=1} n_p=4
 \qquad(q\in\mathbb F_2^2).
 \tag{33ls}
\]

More precisely, identify a block label with

\[
 \lambda_p=(q_p,b_p)\in\mathbb F_2^2\times\mathbb F_2,
 \qquad s_p=(-1)^{b_p}.
 \tag{33lt}
\]

If \(r_{p,a}\in\{-1,1\}\) is the canonical row-\(a\) representative and

\[
 v_a(g,p)=\chi_g(q_p)\varepsilon_pr_{p,a}
 \qquad(g\in\mathbb F_2^2)
\]

is its value at a plane base, then its value at the corresponding transverse base is exactly

\[
 v_a(4+g,p)=s_pv_a(g,p).
 \tag{33lu}
\]

After a full-cell anchor, the affine side gauge has two different exact orbit structures.
For one fixed named transverse base, only the common side flip remains and the four canonical
cell-side bits have eight orbits. If all four transverse bases are imposed simultaneously,
the full affine side gauge acts and the same bits have exactly two orbits, distinguished by
their parity.

#### Proof

Given a labeled refinement, all copies of a selected class \(p\) lie in one block by class
uniqueness. Define \(b_p\) and \(s_p\) by (33lt). The two blocks over a fixed cell \(q\) both
have mass four, so (33ls) follows. Conversely, signs satisfying (33ls) assign the entire class
\(p\) to block \((q_p,0)\) when \(s_p=1\) and to \((q_p,1)\) when \(s_p=-1\). The first block
has mass four by (33ls), and the second does as well because the cell has total mass eight.
This gives the claimed inverse maps.

For the character indexed by \((g,1)\), direct evaluation gives

\[
 \begin{aligned}
 \chi_{(g,1)}(q_p,b_p)\varepsilon_pr_{p,a}
 &=(-1)^{b_p}\chi_g(q_p)\varepsilon_pr_{p,a}\\
 &=s_pv_a(g,p),
 \end{aligned}
\]

which proves (33lu) simultaneously for every row, class, and transverse base.

It remains to determine which side choices are genuinely equivalent. The affine block
relabelings preserving the plane-character subspace are exactly

\[
 (q,b)\longmapsto
 \bigl(Bq+a,\ b+c\mathbin{\cdot}q+d\bigr),
 \qquad
 B\in\operatorname{GL}(2,2),\quad a,c\in\mathbb F_2^2,
 \quad d\in\mathbb F_2.
 \tag{33lv}
\]

The full-cell anchor consumes \(B\) and \(a\). Let \(x_q\in\mathbb F_2\) be the side bit of
the least selected class in cell \(q\), and index a transverse base by \(4+u\),
\(u\in\mathbb F_2^2\). The residual parameters \((c,d)\) act by

\[
 x_q\longmapsto x_q+c\mathbin{\cdot}q+d,
 \qquad
 u\longmapsto u+c.
 \tag{33lw}
\]

Thus the joint invariant for a single transverse base is

\[
 y_q=x_q+u\mathbin{\cdot}q
 \pmod{\langle(1,1,1,1)\rangle}.
 \tag{33lx}
\]

It is complete: \(c\) first sends \(u\) to zero, after which \(d\) identifies a vector with
its common complement. Hence there are \(2^4/2=8\) joint orbits. Equivalently, once the named
base is fixed, its stabilizer has \(c=0\), so only the common side flip remains. In particular,
the parity of \(x\) is invariant but does not classify these eight orbits.

When all four transverse bases are imposed, \(c\) merely permutes them and is again available
as a gauge. The functions \(q\mapsto c\cdot q+d\) form the eight-element first-order Reed--Muller
code \(\operatorname{RM}(1,2)\). Its action on \(\mathbb F_2^4\) has two cosets, and every affine
function has even Hamming weight. Therefore the two orbits are

\[
 \bigoplus_{q\in\mathbb F_2^2}x_q=0,
 \qquad
 \bigoplus_{q\in\mathbb F_2^2}x_q=1,
 \tag{33ly}
\]

with representatives \(0000\) and \(0001\). \(\square\)

Proposition 48 gives an exact extension interface rather than a feasibility result. A sound
single-transverse-base encoding may normalize one global side flip, but it may not fix three
cell sides and retain only the parity bit. That stronger normalization is valid only when the
complete transverse coset is imposed. The proposition therefore neither excludes any of the
eleven surviving profiles nor replaces the pair conditions at bases \(4,5,6,7\).

### Proposition 49 (an overfull projected type forces a tail-active affine halfspace)

Under the assumptions of Proposition 37, normalize a four-active \(z=3\) base to \(0\) as in
Proposition 41, so row \(5\) is inactive there. Suppose some signed four-row pattern
\(w\in\{-1,1\}^4\) has multiplicity greater than four at that base. Then there is a nonzero
\(\delta\in\mathbb F_2^3\) such that

\[
 H_\delta:=\{g\in\mathbb F_2^3:g\mathbin{\cdot}\delta=1\}
 \subseteq\{g:5\in A_g\}.
 \tag{33lz}
\]

Thus row \(5\) is active at four nonzero Walsh bases. Moreover, for every row \(a\) and every
two bases \(g,h\),

\[
 T_a(g)\equiv T_a(h)\pmod4.
 \tag{33ma}
\]

Consequently \(T_5(0)\equiv0\pmod4\). Relative to any fixed Walsh plane, at least two of the
four transverse bases have active row \(5\). Alternatively, the plane may be chosen so that

\[
 \bigl|\{g\in\{e_1,e_2,e_1+e_2\}:5\in A_g\}\bigr|\ge2.
 \tag{33mb}
\]

This last symmetric condition is compatible with the full-cell anchor of Propositions 45--48.
It cannot in general be replaced, while retaining that anchor, by activity at a fixed named
nonzero plane base.

#### Proof

Let \(n(w)>4\) be the multiplicity of the projected pattern. Its two five-row lifts have signed
columns \((w,+1)\) and \((w,-1)\). By Proposition 37, each projective five-row class occurs in
one block, and hence either lift has multiplicity at most four. Both lifts therefore occur. If
their blocks \(\lambda_+\) and \(\lambda_-\) were equal, that block would contain all
\(n(w)>4\) copies, contradicting its mass four. Hence

\[
 \delta=\lambda_++\lambda_-\ne0.
 \tag{33mc}
\]

Choose one coordinate of each lift. For every \(g\in H_\delta\), the two Walsh factors
\(\chi_g(\lambda_+)\) and \(\chi_g(\lambda_-)\) are opposite. The first four signed row values
of the selected coordinates are therefore antipodal, whereas their fifth-row values are equal.
None of the first four rows can witness this pair. Condition (33jd) forces row \(5\) to witness
it, so

\[
 T_5(g)\in\{0,4\chi_g(\lambda_+)\}\subseteq\{-4,0,4\}.
 \tag{33md}
\]

This proves (33lz). Since \(\delta\ne0\), the affine hyperplane \(H_\delta\) has four elements
and does not contain \(0\).

For (33ma), let

\[
 S_{a,\lambda}=\sum_{i\in B_\lambda}c_{a,i}.
\]

Every block has four coordinates, so \(S_{a,\lambda}\) is even. Therefore

\[
 T_a(g)-T_a(h)
 =\sum_\lambda
 \bigl(\chi_g(\lambda)-\chi_h(\lambda)\bigr)S_{a,\lambda}
 \in4\mathbb Z,
 \tag{33me}
\]

which proves the congruence. Activity on \(H_\delta\) then gives
\(T_5(0)\equiv0\pmod4\).

The complement of any fixed two-dimensional plane of characters is an affine hyperplane
\(H_\eta\). If \(\eta=\delta\), its intersection with \(H_\delta\) has size four; otherwise
the two independent affine equations have exactly two solutions. Hence every transverse coset
contains at least two bases forced active by (33lz).

Finally choose distinct \(g_1,g_2\in H_\delta\). They are linearly independent, and
\((g_1+g_2)\mathbin{\cdot}\delta=0\). The plane they span therefore has two nonzero bases in
\(H_\delta\); a linear block relabeling sends it to the standard plane and proves (33mb).
Translations of the four plane cells only change baseline signs, while
\(\operatorname{GL}(2,2)\) permutes the three nonzero plane bases. Thus the count in (33mb) is
preserved by the full cell-affine normalization. A condition naming one of those bases is not
preserved by this full permutation action. \(\square\)

Every one of the eleven surviving tetrahedral profiles satisfies the hypothesis: its parameters
obey \(a+b+c+d=18\), so \(d\ge5\), and \(m(h,+)=d\) for one projected pattern. After choosing
the sign of the inactive fifth row so that \(T_5(0)>0\), Proposition 49 gives the additional
necessary restriction

\[
 T_5(0)\in\{8,12,16,20,24,28\}.
 \tag{33mf}
\]

Indeed both fifth-row lifts occur, so \(|T_5(0)|<32\), while inactivity excludes
\(0,\pm4\). These restrictions do not exclude any of the eleven profiles by themselves; they
replace the earlier one-base tail-activity heuristic by a proof-valid four-base condition.

### Proposition 50 (the tail-row halfspace relaxation leaves exactly three profiles)

No global five-row separating family can have any of the tetrahedral \(z=3\) profiles

\[
 \begin{gathered}
 (2,3,6,7),\ (2,4,5,7),\ (3,3,5,7),\ (3,4,4,7),\\
 (2,4,6,6),\ (2,5,5,6),\ (3,3,6,6),\ (3,4,5,6).
 \end{gathered}
 \tag{33mg}
\]

Consequently the eleven survivors of Proposition 46 reduce to at most

\[
 (3,5,5,5),\qquad(4,4,4,6),\qquad(4,4,5,5).
 \tag{33mh}
\]

This reduction is sharp for the row-5 affine-halfspace relaxation: all three profiles in
(33mh) have assignments satisfying its block capacities and every forced condition (33md).

#### Proof

First extract the analytic part of Proposition 49. Let a projected type of multiplicity
\(\alpha>4\) split into a tail-positive lift of mass \(r\) in block \(a\) and a tail-negative
lift of mass \(\alpha-r\) in block \(b=a+\delta\). Summing (33md) over
\(H_\delta\) and using Walsh inversion gives

\[
 S_{5,a}-S_{5,b}
 =\frac14\sum_{g\in H_\delta}\chi_g(a)T_5(g)
 \le4.
 \tag{33mi}
\]

The two block capacities give the reverse estimate

\[
 S_{5,a}\ge2r-4,\qquad
 S_{5,b}\le4-2(\alpha-r),\qquad
 S_{5,a}-S_{5,b}\ge2\alpha-8.
 \tag{33mj}
\]

Hence \(\alpha\le6\), immediately excluding the four profiles in (33mg) containing a
projected type of mass seven.

Two projected types of mass six cannot coexist. Equality must hold throughout (33mi)--(33mj),
so a mass-six pair \((a_i,b_i=a_i+\delta_i)\) satisfies

\[
 S_{5,a_i}-S_{5,b_i}=4,qquad
 T_5(g)=4\chi_g(a_i)\quad(g\in H_{\delta_i}).
 \tag{33mk}
\]

For two such pairs, if \(\delta_1=\delta_2\), equality of the nonzero values in (33mk) on the
common affine hyperplane forces \(a_1=a_2\), and then also \(b_1=b_2\). Their total mass twelve
cannot fit into those two mass-four blocks. If \(\delta_1\ne\delta_2\), equality on
\(H_{\delta_1}\cap H_{\delta_2}\) forces

\[
 a_1+a_2\in\{0,\delta_1+\delta_2\}.
 \tag{33ml}
\]

In the first case the two positive lifts share a block. Each has mass at least two, so both have
mass exactly two and fill that block with positive signs; their negative lifts each have mass
four and fill their respective blocks with negative signs. This gives
\(S_{5,a_i}-S_{5,b_i}=8\), contradicting (33mk). In the second case
\(b_1=b_2\), and the symmetric argument with the two negative lifts gives the same
contradiction. This excludes the three profiles in (33mg) with at least two projected mass-six
types; for \((2,5,5,6)\), one of those two types has mass \(8-2=6\).

Only \((3,4,5,6)\) remains to be excluded. We use the exact finite relaxation. Enumerate every
block-sum vector

\[
 (S_{5,\lambda})_{\lambda\in\mathbb F_2^3}
 \in\{-4,-2,0,2,4\}^8
 \tag{33mm}
\]

with \(T_5(0)\) in (33mf). For each projected mass \(m\), enumerate every split

\[
 \max(0,m-4)\le r\le\min(4,m),
 \tag{33mn}
\]

assign the two nonempty lifts intact to labeled blocks, fill exactly the positive and negative
capacities \((4+S_{5,\lambda})/2\) and \((4-S_{5,\lambda})/2\), and impose (33md) for every
type of mass greater than four. This directly covers all labeled block assignments; no symmetry
quotient is used.

The resulting exhaustive verifier finds the eight profiles in (33mg) infeasible. For the last
three profiles it returns the following explicit row-5 relaxation witnesses, listing the eight
block sums and their Walsh transforms:

\[
\begin{array}{c|c|c}
\text{profile}&(S_{5,0},\ldots,S_{5,7})&(T_5(0),\ldots,T_5(7))\\ \hline
(3,5,5,5)&(-2,-2,0,0,2,4,2,4)&(8,-4,-4,0,-16,4,-4,0)\\
(4,4,4,6)&(-4,-4,-2,2,4,4,4,4)&(8,-4,-8,4,-24,-4,-8,4)\\
(4,4,5,5)&(-4,-4,0,2,2,4,4,4)&(8,-4,-12,0,-20,0,-8,4).
\end{array}
 \tag{33mo}
\]

The complete lift placements, expected output, hashes, and one-command verifier are in the
[tail-row halfspace classification bundle](../../computations/bundles/d3-z3-tail-row-halfspace-classification/README.md).
Thus (33mg) is impossible even in a relaxation of every global lift, while (33mo) proves that
this row-5 relaxation alone cannot exclude any profile in (33mh). \(\square\)

Proposition 50 does not construct a five-row family for the three remaining profiles. Their
first four rows must still satisfy every distinct-type and repeated-type condition at all eight
Walsh bases. The complete conditions already exclude the middle profile.

### Proposition 51 (the mass-six profile has no global lift)

Under the assumptions of Proposition 37, no global five-row separating family can have the
tetrahedral profile

\[
 (4,4,4,6)
 \tag{33mp}
\]

at a normalized four-active \(z=3\) base. Consequently the eleven profiles of Proposition 46
reduce to at most

\[
 (3,5,5,5),\qquad(4,4,5,5).
 \tag{33mq}
\]

#### Proof

In the fixed tetrahedral pattern order, (33mp) gives the eight projected multiplicities

\[
 (4,4,4,4,4,4,6,2).
 \tag{33mr}
\]

We exhaust the finite global-lift space left by Proposition 37. Split each projected pattern
between its tail-positive and tail-negative five-row lifts. Each nonempty lift is one
projective class, has multiplicity at most four, and lies intact in one of the eight mass-four
blocks. After choosing the fifth-row sign, (33mf) gives all possible selected-base baselines.
There are exactly \(14{,}568\) admissible split vectors.

For each split, restricted-growth recursion generates every partition of the nonempty lifts
into eight unlabeled blocks of mass four exactly once. This gives \(2{,}424{,}888\) partitions.
The block labels are then assigned through the

\[
 8!/|\operatorname{AGL}(3,2)|=30
 \tag{33ms}
\]

coset representatives, for \(72{,}746{,}640\) label states in total. This quotient loses no
condition: an affine relabeling permutes the Walsh bases and may reverse simultaneously all
signed columns and baselines at a base, under which (33jd) is invariant.

For every label state, every nonempty lift item \(\tau\) records its signed five-row column,
multiplicity \(n_\tau\), and block label. The verifier computes all five baselines \(T_a(g)\)
and, for every \(g\in\mathbb F_2^3\), checks (33jd) for every pair
\(\tau\ne\tau'\), as well as \(\tau=\tau'\) whenever \(n_\tau\ge2\). No state passes.
The same domain is run twice: once with Proposition 49 as an early rejection and once with that
rejection disabled. In the direct run all \(72{,}746{,}640\) label states enter the complete
pair-condition loop, which again returns \(\texttt{VERIFIED\_INFEASIBLE}\).

The source, both frozen outputs, hashes, and one-command verifier are in the
[final-three full-lift exclusion bundle](../../computations/bundles/d3-z3-final-three-full-lift-exclusion/README.md).
Thus (33mp) has no global lift. Combining this with Proposition 50 proves (33mq).
\(\square\)

Proposition 51 alone makes no feasibility claim for either profile in (33mq); it also does not
constrain the \(z=4\) or three-active branches.

### Proposition 52 (the complete \(z=3\) branch is infeasible)

Under the assumptions of Proposition 37, neither profile in (33mq) has a global five-row lift.
Consequently a four-active Walsh base cannot have exactly three zero active baselines.

#### Proof

Equation (33kh) gives the projected multiplicities in the fixed tetrahedral pattern order:

\[
\begin{array}{c|c}
\text{profile}&(m_0,\ldots,m_7)\\ \hline
(3,5,5,5)&(3,5,5,3,5,3,5,3)\\
(4,4,5,5)&(4,4,4,4,5,3,5,3).
\end{array}
 \tag{33mt}
\]

Run the complete finite enumeration of Proposition 51 for each row of (33mt). The split,
restricted-growth partition, and affine-label counts are

\[
\begin{array}{c|r|r|r}
\text{profile}&\text{splits}&\text{unlabeled partitions}&\text{label states}\\ \hline
(3,5,5,5)&5{,}610&2{,}932{,}380&87{,}971{,}400\\
(4,4,5,5)&16{,}310&4{,}247{,}851&127{,}435{,}530.
\end{array}
 \tag{33mu}
\]

Every label state is checked at all eight Walsh bases against every distinct-type condition in
(33jd) and every repeated-type diagonal whose multiplicity is at least two. The pruned run
first imposes Proposition 49 for every projected type of mass greater than four. The direct run
disables all such pruning; all \(87{,}971{,}400\) and \(127{,}435{,}530\) states,
respectively, enter the complete pair-condition loop. Both runs return
\(\texttt{VERIFIED\_INFEASIBLE}\) for both profiles. The frozen source, outputs, hashes, and
one-command reproduction are in the
[final-three full-lift exclusion bundle](../../computations/bundles/d3-z3-final-three-full-lift-exclusion/README.md).

Proposition 41 exhausts the local \(z=3\) mechanisms. Proposition 42 excludes its exceptional
family; Propositions 42--46 and 50 reduce its tetrahedral family to (33mh); Proposition 51 and
the present classification exclude all three remaining profiles. Hence no \(z=3\) global lift
exists. The row-5 assignments in (33mo) show why the complete pair conditions, rather than only
the affine-halfspace relaxation, are essential. \(\square\)

Proposition 52 does not constrain the \(z=4\) branch or close the separate three-active parity
branch.

### Proposition 53 (the four-zero local branch has exactly twenty-eight profiles)

Under the assumptions of Proposition 37, normalize a four-active Walsh base to \(0\), take its
active rows to be \(1,\ldots,4\), and suppose all four active baselines vanish. Up to signed
permutations of the active rows, exactly twenty-eight projected profiles extend to a
selected-base five-row state with inactive row \(5\) and eight blocks of mass four.

More precisely, let \(m(v)\) be the multiplicity of
\(v\in\{-1,1\}^4\). The projected zero-margin and pair conditions have twenty-nine orbits.
Write

\[
 P(v)=v_1v_2v_3v_4,\qquad
 m_A(v)=\bigl[P(v)(av_1+bv_2+cv_3+dv_4)\bigr]_+.
 \tag{33mv}
\]

Every orbit has a unique representative \(m_A\) whose parameter
\(A=(a,b,c,d)\) is either

\[
\begin{gathered}
 (a,b,c,4),\\
 0\le a\le b\le c,\qquad
 2a,2b,2c\in\mathbb Z,\qquad
 a+b+c\in\mathbb Z,\qquad
 a+b+c\le4,
\end{gathered}
 \tag{33mw}
\]

giving twenty-four orbits, or one of

\[
 (0,1,\tfrac72,\tfrac72),\
 (0,\tfrac32,3,\tfrac72),\
 (0,2,\tfrac52,\tfrac72),\
 (0,2,3,3),\
 (0,\tfrac52,\tfrac52,3).
 \tag{33mx}
\]

Exactly one projected orbit does not extend to an exact four-active five-row state:

\[
 A=(0,0,4,4),
 \tag{33my}
\]

whose four occurring projected types all have multiplicity eight.

#### Proof

At the selected base, (33jd) says that two projected columns must agree in one of the four
zero-baseline active rows. Thus the support is antipodal-free. The four zero baselines,
projective capacity, and total mass give exactly

\[
 \sum_vm(v)v=0,\qquad
 m(v)m(-v)=0,\qquad
 0\le m(v)\le8,\qquad
 \sum_vm(v)=32.
 \tag{33mz}
\]

Conversely, nonantipodal four-bit vectors agree in a coordinate, so (33mz) is sufficient for
all selected-base pair conditions involving the active rows.

Define the odd function

\[
 F(v)=m(v)-m(-v).
\]

Antipodal freeness gives \(m(v)=[F(v)]_+\). The zero-margin equations delete all degree-one
Fourier coefficients of \(F\); oddness leaves only degree three. Hence uniquely

\[
 F(v)=\sum_{i=1}^4a_i\prod_{j\ne i}v_j=P(v)(A\mathbin{\cdot}v),
 \tag{33na}
\]

which proves (33mv). The safe group \((C_2)^4\rtimes S_4\) acts on \(A\) by all signed
permutations, so every orbit has a unique normalization
\(0\le a\le b\le c\le d\). Integer multiplicities are equivalent to

\[
 2a,2b,2c,2d\in\mathbb Z,\qquad a+b+c+d\in\mathbb Z,
 \tag{33nb}
\]

and the capacity bound is \(a+b+c+d\le8\).

The total-mass equation becomes

\[
 \sum_{\varepsilon\in\{-1,1\}^3}
 |d+\varepsilon_1a+\varepsilon_2b+\varepsilon_3c|=32.
 \tag{33nc}
\]

After ordering the parameters, only \(d-a-b-c\) and \(d+a-b-c\) can change the
linear form of this absolute-value sum. Therefore (33nc) is equivalent to

\[
 4d+(a+b+c-d)_+ +(b+c-a-d)_+=16.
 \tag{33nd}
\]

If \(a+b+c\le d\), both positive parts vanish, and (33nd) gives \(d=4\) and
(33mw). After doubling \(a,b,c\), the possible even sums
\(0,2,4,6,8\) contribute respectively \(1,2,4,7,10\) nondecreasing integer
partitions, for \(24\) points. If \(a+b+c>d\) but \(b+c\le a+d\), then (33nd) gives
\(3d+a+b+c=16\). The strict inequality forces \(d<4\), whereas the capacity
\(a+b+c+d\le8\) forces \(d\ge4\), so this region is empty. Finally, if
\(b+c>a+d\), (33nd) gives

\[
 b+c+d=8.
\]

The capacity bound then forces \(a=0\). Thus
\((2b,2c,2d)\) is a nondecreasing positive integer partition of \(16\) whose largest
part is smaller than the sum of the other two. The five possibilities are

\[
 (2,7,7),\ (3,6,7),\ (4,5,7),\ (4,6,6),\ (5,5,6),
\]

which give exactly (33mx). This proves the twenty-nine-orbit projected classification.

It remains to make row \(5\) inactive. If \(p_v\) is the tail-positive lift mass above
projected type \(v\), then

\[
 \max(0,m(v)-4)\le p_v\le\min(4,m(v)).
 \tag{33ne}
\]

Put \(L=\sum_v\max(0,m(v)-4)\). Sums of integer intervals have no gaps, so the attainable
tail-positive totals are exactly

\[
 \sum_vp_v\in[L,32-L],\qquad
 T_5(0)=2\sum_vp_v-32.
 \tag{33nf}
\]

Since \(L\le16\), an inactive fifth row exists exactly when \(L\le15\): choose total \(15\).
The case \(L=16\) forces total \(16\) and \(T_5(0)=0\). Evaluating \(L\) on
(33mw)--(33mx) leaves only (33my) in this case.

For each of the other twenty-eight orbits, the lift items in (33ne) also admit a partition
into eight blocks of mass four. The complete representatives, orbit sizes, one tail split,
and one block packing per orbit are retained in the
[four-zero selected-base classification bundle](../../computations/bundles/d3-z4-selected-base-classification/README.md).
Its independent meet-in-the-middle and Burnside counts are

\[
 4{,}560\longrightarrow29,\qquad
 4{,}536\longrightarrow28,
 \tag{33ng}
\]

before and after the inactive-tail condition, respectively. \(\square\)

Proposition 53 is a selected-base classification. It does not assert that any of its twenty-eight
profiles satisfies the pair conditions at the other seven Walsh bases.

### Proposition 54 (projected multiplicity reduces the four-zero branch to three profiles)

Under the assumptions of Proposition 37, fix any Walsh base and delete any one of the five
rows. If \(m(w)\) is the multiplicity of a signed pattern on the other four rows, then

\[
 m(w)\le6,\qquad
 m(w)=6\Longrightarrow m(w')\le4\quad(w'\ne w).
 \tag{33nh}
\]

Consequently exactly three of the twenty-eight local four-zero profiles in Proposition 53
survive this necessary condition. In the common canonical support order

\[
 \texttt{--+-},\ \texttt{--++},\ \texttt{-+--},\ \texttt{-+-+},\
 \texttt{+---},\ \texttt{+--+},\ \texttt{+++-},\ \texttt{++++},
 \tag{33ni}
\]

their multiplicity vectors are

\[
 \begin{gathered}
 (3,5,3,5,5,3,5,3),\\
 (3,5,4,4,4,4,5,3),\\
 (4,4,4,4,4,4,4,4).
 \end{gathered}
 \tag{33nj}
\]

Thus at most three four-zero local profiles remain globally feasible.

#### Proof

Walsh-translate the chosen base to \(0\), and call the deleted row row \(5\). Replacing the
column in block \(\lambda\) by \(\chi_h(\lambda)\) times that column relabels base \(g+h\) as
base \(g\), so it preserves (33jd). Suppose a projected type has multiplicity \(\alpha>4\).
Its tail-positive and tail-negative lifts have masses \(r\) and \(\alpha-r\). Proposition 37
puts each lift intact in one mass-four block, say \(a\) and \(b=a+\delta\), where
\(\delta\ne0\). For every \(g\in H_\delta\), the first four signed row values of a chosen lift
pair are antipodal, whereas their fifth-row values are both \(\chi_g(a)\). Hence (33jd) forces

\[
 T_5(g)\in\{0,4\chi_g(a)\}\qquad(g\in H_\delta).
 \tag{33nk}
\]

Writing \(S_{5,\lambda}\) for the fifth-row sum in block \(\lambda\), Walsh inversion and the
two block capacities give

\[
 \begin{aligned}
 S_{5,a}-S_{5,b}
   &=\frac14\sum_{g\in H_\delta}\chi_g(a)T_5(g)\le4,\\
 S_{5,a}&\ge2r-4,\qquad
 S_{5,b}\le4-2(\alpha-r).
 \end{aligned}
 \tag{33nl}
\]

Therefore \(2\alpha-8\le4\), proving \(\alpha\le6\).

If \(\alpha=6\), equality holds throughout (33nl). In particular,

\[
 S_{5,a}-S_{5,b}=4,\qquad
 T_5(g)=4\chi_g(a)\quad(g\in H_\delta).
 \tag{33nm}
\]

The positive lift of the mass-six type exhausts the positive-sign capacity of block \(a\), and
its negative lift exhausts the negative-sign capacity of block \(b\). Indeed these capacities
are respectively \(r\) and \(6-r\) by equality in (33nl).

Now let any other overfull type have positive and negative lift blocks \(p\) and
\(q=p+\varepsilon\). Its analogue of (33nk), compared with the nonzero equality in (33nm),
forces

\[
 p=a\quad\text{if }\varepsilon=\delta.
\]

If \(\varepsilon\ne\delta\), equality of the two characters on
\(H_\delta\cap H_\varepsilon\) forces

\[
 a+p\in\{0,\delta+\varepsilon\}.
 \tag{33nn}
\]

Thus either \(p=a\) or \(q=b\). The first alternative places another positive lift in the
already exhausted positive capacity of \(a\); the second places another negative lift in the
already exhausted negative capacity of \(b\). Both are impossible. This proves (33nh).

Finally apply (33nh) to the twenty-eight frozen representatives of Proposition 53. Fourteen
have maximum multiplicity eight and seven have maximum multiplicity seven. Of the seven left,
four contain a mass-six type together with another overfull type. The three remaining
representatives are exactly (33ni)--(33nj). \(\square\)

The argument uses no selected-base activity data and is independent of the \(z=3\) tetrahedral
classification in which its block-capacity core first appeared. It does not decide the three
profiles in (33nj) or the separate three-active parity branch.

### Proposition 55 (the complete \(z=4\) branch is infeasible)

Under the assumptions of Proposition 37, a four-active Walsh base cannot have all four active
baselines equal to zero.

#### Proof

Run the complete finite enumeration of Proposition 51 on each of the three multiplicity vectors
in (33nj). For every projected pattern, enumerate all splits between its two five-row lifts.
For each split, restricted-growth recursion generates every partition of the nonempty lift
items into eight unlabeled blocks of mass four, and the \(30\)
\(S_8/\operatorname{AGL}(3,2)\) representatives assign the block labels. The resulting direct
domains are

\[
\begin{array}{c|r|r|r|r}
\text{multiplicity partition}&\text{splits}&\text{partitions}&\text{label states}
 &\text{pair--base checks}\\ \hline
(5,5,5,5,3,3,3,3)&21{,}994&14{,}090{,}460&422{,}713{,}800
 &2{,}161{,}028{,}047\\
(5,5,4,4,4,4,3,3)&56{,}310&19{,}519{,}527&585{,}585{,}810
 &3{,}195{,}234{,}899\\
(4,4,4,4,4,4,4,4)&142{,}230&27{,}105{,}279&813{,}158{,}370
 &6{,}073{,}560{,}521.
\end{array}
\tag{33no}
\]

Negating row \(5\) covers negative selected-base baselines. The enumeration includes every
reachable positive even baseline other than the active value \(4\), including the all-positive
\(T_5(0)=32\) split of the uniform profile. Every label state in (33no) enters the complete
(33jd) loop: both the Proposition 49 early rejection and the Proposition 54 split rejection
are disabled. For every \(g\in\mathbb F_2^3\), the verifier checks every pair of distinct lift
types and every repeated-type diagonal whose multiplicity is at least two. No state passes.

The frozen source, direct and pruned outputs, hashes, and one-command reproduction are in the
[final-four full-lift exclusion bundle](../../computations/bundles/d3-z4-final-four-full-lift-exclusion/README.md).
The bundle also checks the first vector removed analytically by Proposition 54, giving an
independent direct exclusion of all four profiles that survived its weaker first bound.
Therefore no global \(z=4\) lift exists. \(\square\)

Together, Propositions 40, 52, and 55 close every four-active continuation supplied by
Proposition 38.

### Proposition 56 (the three-active parity branch is infeasible)

Under the assumptions of Proposition 37, no Walsh base has exactly three active rows.

#### Proof

Suppose otherwise and use the normalization (33jt). The four signed head columns at the selected
base are

\[
 H=(+++,+--,-+-,--+),
\]

each of total multiplicity eight. Split each head type by the four signed tail columns
\((++,+-,-+,--)\). The selected-base data are therefore a \(4\times4\) integer matrix:
each row sums to eight, and every entry lies in \(\{0,\ldots,4\}\), because each nonempty
five-bit projective class lies intact in one mass-four block. Both tail baselines avoid
\(\{-4,0,4\}\).

Apply Proposition 54 after deleting row 4 and after deleting row 5. We deliberately do not apply
its three head-row deletions, so the retained set is a relaxation of every global candidate.
Up to the safe group \(S_4(H)\times D_8(\mathrm{tails})\), the exact selected-base counts are

\[
\begin{array}{c|r}
\text{four-row multisets before constraints}&2{,}331{,}890\\
\text{with both tail rows inactive}&1{,}034{,}308\\
\text{after the two tail-deletion constraints}&15{,}868\\
\text{corresponding labeled head states}&315{,}572\\
\text{safe-group orbits}&2{,}214.
\end{array}
\tag{33np}
\]

The group has order \(192\). Burnside's lemma independently gives the last count from the
eight tail-group fixed counts

\[
 (15{,}868,922,0,0,0,0,922,0),
\]

whose sum divided by eight is \(2{,}214\).

For each canonical profile, treat every positive-mass signed five-bit type as an indivisible
item. Restricted-growth recursion generates every partition of these items into eight unlabeled
mass-four blocks. The \(30=8!/|\operatorname{AGL}(3,2)|\) representatives then label the
blocks. For every label state, compute all five baselines at all eight Walsh bases and impose
(33jd) on every pair of distinct items and on the diagonal of every item of mass at least two.
The direct domain is

\[
\begin{array}{c|r}
\text{canonical input profiles}&2{,}214\\
\text{packable profiles}&1{,}580\\
\text{unlabeled block partitions}&2{,}478{,}569\\
\text{label states entering (33jd)}&74{,}357{,}070\\
\text{executed pair--base checks}&224{,}374{,}293.
\end{array}
\tag{33nq}
\]

No label state passes. This direct run uses no Proposition 39 tail-cover rejection. A second run
imposes the simultaneous tail cover and the existence of a nonzero base with at least four active
rows; all of its \(91{,}464\) surviving label states also fail. Signed row permutations preserve
(33jd), and affine block relabeling only permutes Walsh bases while possibly reversing all signed
columns and the corresponding baselines simultaneously. Hence both quotients are lossless.

The frozen classifier, complete verifier, expected outputs, hashes, and one-command reproduction
are in the
[three-active full-lift exclusion bundle](../../computations/bundles/d3-three-active-parity-full-lift-exclusion/README.md).
Thus no global lift in the three-active parity branch exists. \(\square\)

### Proposition 57 (the eight-block Walsh-star value is six)

For eight Walsh blocks of size four,

\[
 \nu_{3,0}(4,4,4,4,4,4,4,4)=6.
\tag{33nr}
\]

#### Proof

Proposition 33 gives six exact-central centers, so the left-hand side is at most six. Suppose a
family of at most five centers existed. Repeating a center if necessary gives a five-center
family, to which Proposition 37 applies. If some base has exactly three active rows,
Proposition 56 excludes it. Otherwise Proposition 38 supplies a four-active base, Proposition 40
gives three or four zero active baselines there, and Propositions 52 and 55 exclude those two
cases. Hence five centers are impossible, proving the reverse inequality. \(\square\)

This is an exact finite Walsh-star separation result. It does not resolve P versus NP or by
itself strengthen the asymptotic circuit lower bounds of Theorems 1--3.

### Proposition 58 (a character-cut criterion saves one center in even dimension)

Let \(d\ge1\), let \(B_\lambda\) for \(\lambda\in\mathbb F_2^d\) be equal nonempty
blocks of size \(m\), and suppose \(m2^d>4\). If
\(H\subseteq\mathbb F_2^d\) satisfies

\[
 2\le w_H(\delta):=
 \bigl|\{h\in H:h\mathbin{\cdot}\delta=1\}\bigr|
 \le |H|-2
 \qquad(0\ne\delta\in\mathbb F_2^d),
\tag{33ns}
\]

then the \(|H|\) block-constant Walsh centers

\[
 c_i^h=(-1)^{h\cdot\lambda}
 \qquad(h\in H,\ i\in B_\lambda)
\tag{33nt}
\]

separate all pairs in (33hq) at window zero. Consequently, for every even \(d\ge4\),

\[
 \nu_{d,0}^{\mathrm{bc}}(
 \underbrace{m,\ldots,m}_{2^d})
 \le d+2.
\tag{33nu}
\]

In particular,

\[
 \nu_{4,0}(\underbrace{4,\ldots,4}_{16})\le6<7=4+3.
\tag{33nv}
\]

#### Proof

At the Walsh base \(x^g\), the baseline of the center indexed by \(h\) is

\[
 T_h(g)
 =m\sum_{\lambda\in\mathbb F_2^d}
 (-1)^{(h+g)\cdot\lambda}
 =
 \begin{cases}
 m2^d,&h=g,\\
 0,&h\ne g.
 \end{cases}
\tag{33nw}
\]

Thus every row in \(H\setminus\{g\}\) is zero-baseline, and when \(g\notin H\) every
row is zero-baseline. Two coordinates in the same block have equal signed contributions in
every such row, so any zero-baseline row separates their distance-two neighbor.

Now take coordinates in distinct blocks \(B_\lambda,B_\mu\), and put
\(\delta=\lambda+\mu\ne0\). Their signed contributions in row \(h\) at \(x^g\)
are equal exactly when

\[
 (h+g)\mathbin{\cdot}\delta=0.
\tag{33nx}
\]

If \(g\notin H\) and no row satisfies (33nx), then \(h\cdot\delta\) is constant on
\(H\), giving \(w_H(\delta)\in\{0,|H|\}\). If \(g\in H\) and no active row
satisfies (33nx), then the value at \(h=g\) is the unique exception to the other
\(|H|-1\) values, giving
\(w_H(\delta)\in\{1,|H|-1\}\). Both conclusions contradict (33ns). Hence some
zero-baseline row has equal contributions on the chosen pair; flipping the pair changes its
baseline from zero to \(4\) or \(-4\), and the zero-window truncations differ.

For even \(d\ge4\), take

\[
 H_d=\{0,e_1,\ldots,e_d,\mathbf1\}.
\tag{33ny}
\]

If \(k=|\delta|\), then

\[
 w_{H_d}(\delta)=k+(k\bmod2).
\tag{33nz}
\]

Since \(1\le k\le d\) and \(d\) is even, this lies between \(2\) and
\(d=|H_d|-2\). Thus (33ns) holds and (33nu) follows. The specialization
\((d,m)=(4,4)\) gives (33nv). \(\square\)

Condition (33ns) says that no affine hyperplane cuts off zero, one, all but one, or all points
of \(H\). The set in (33ny) is the binary affine circuit
\(\{0,e_1,\ldots,e_d,\mathbf1\}\); its existence at size \(d+2\) is the parity
mechanism behind the even-dimensional saving. Proposition 57 is therefore a genuine
low-dimensional phase, not the first case of a universal \(d+3\) arbitrary-center law.
Proposition 58 is an upper-bound construction and does not decide whether the value in (33nv)
can be lowered to five.

## 3. Why second-order information does not lower the first-order scale

The theorem is stronger than an average-case statement over restrictions: one fixed family
survives every choice of live coordinates and every outside assignment at the same order of
magnitude. It can also have all pairwise normal vectors nearly orthogonal. Consequently, a
proof that only establishes
\[
 \Pr[\text{gate }i\text{ active and gate }j\text{ active}]\le O(h^2/N)
\]
cannot by itself imply \(o(qh/\sqrt N)\) active gates. The one-gate mean is already tight,
and the theorem realizes that mean uniformly.

This is a barrier to a particular proof template, not a lower bound against every restriction
algorithm. Higher-order correlations, the top symmetric function, or direct evaluation of a
canonical profile may still provide additional structure.

## 4. A complementary geometric boundary

The exact-parallel case is genuinely one-dimensional: if all bottom gates share a normal
vector, their outputs depend only on one weighted sum. Approximate parallelism has a different
status.

Let
\[
 C(y)=f\!\left(\sum_{i=1}^{q}T_i(y)\right),\qquad
 T_i(y)=1[\ell_i(y)\ge0],
\]
with arbitrary LTFs. Add \(r\) selector bits \(s\), put \(u=|s|\), and let \(B=q+1\).
Choose an integer \(M>\max_{i,y}|\ell_i(y)|\). For \(0\le t\le r\), define
\[
 G_{i,t}(y,s)=1[M(u-t)+\ell_i(y)\ge0],
\]
and for \(0\le t<r\), define \(H_t(s)=1[u\ge t+1]\). Then
\[
 G_{i,t}=
 \begin{cases}
 1,&t<u,\\
 T_i(y),&t=u,\\
 0,&t>u,
 \end{cases}
 \tag{34}
\]
and hence
\[
 \sum_{i,t}G_{i,t}+\sum_tH_t=Bu+\sum_iT_i(y).
 \tag{35}
\]
The residue modulo \(B\) recovers the original top gate exactly. After standard affine
homogenization, the new bottom normals lie in a cone of angular width \(O(r^{-1/2})\)
around the selector direction \((0,\mathbf 1_r)\). Thus a vanishing cone width does not
imply a semantically simpler CAPP instance.

This is a semantic multiplexing statement. It permits polynomial size and selector variables;
it does not say that every small concrete cone family is hard.

## 5. Relation to the restriction and CAPP literature

The active-count theorem addresses the parameter regime used in recent restriction-based lower
bound templates for depth-two threshold circuits, including the parameters appearing in the
Chen--Tal--Wang framework. Multivariate Littlewood--Offord estimates can control pairwise or
low-dimensional joint events under robust-rank hypotheses, but the theorem shows why such
control does not automatically lower the one-gate activity scale.

Theorems 2--3 strengthen the column-type obstruction from a separated exponential codebook to
the entire restricted cube. Proposition 7 narrows the remaining sign-normal separation gap to a
factor \(\sqrt{\log N}\) when \(h=1\). These are separation and representation statements for
active-set signatures, not lower bounds on algorithms that evaluate many columns jointly.

For \(h=1\), each active bit is the indicator of one exact Hamming sphere:

\[
 \langle w,z\rangle=s
 \iff
 d_H(w,z)=\frac{M-s}{2}.
 \tag{36}
\]

This response model is strictly narrower than the classical metric-dimension or nonadaptive
coin-weighing model, where one landmark returns the complete distance in
\(\{0,\ldots,M\}\). In the binary cube, the latter requires
\((2+o(1))M/\log_2M\) landmarks. It also differs from identifying-code models based on
membership in fixed-radius balls or graph neighborhoods. Theorems 2--3 concern one individually
chosen exact-radius bit per gate; the extra \(M^{1/2}\)-scale cost comes from this sparse response,
not from a contradiction with the full-distance bounds.

A black-box expansion of metric landmarks cannot close the logarithmic gap. If only a set
\(R\) of radii is queried around one fixed center, its sphere-bit vector has at most
\(|R|+1\) possible values: one unit vector for each queried distance and the all-zero vector
for every unqueried distance. Distinguishing all \(M+1\) outputs of a complete-distance
landmark therefore requires \(|R|\ge M\). Expanding the
\((2+o(1))M/\log_2M\) metric landmarks separately would consequently use
\(\Theta(M^2/\log M)\) exact-sphere bits, which is worse than the
\(O(M^{3/2}/\sqrt{\log M})\) hybrid construction of Proposition 7. Closing the
remaining square-root logarithmic gap requires more efficient joint structure across centers.
Proposition 8 further shows that neither reoptimizing the cutoff nor replacing the common
window by arbitrary preassigned, heterogeneous radius sets can improve Proposition 7 through
a pairwise first-moment argument: the largest even distance layer already incurs the same
asymptotic cost.
Propositions 9--10 show that this first-moment obstruction cannot be attributed to the
largest even-distance layer itself: correlated deterministic centers cover that layer with
only \(O(M)\) exact-sphere bits in both parities.
Proposition 11 isolates the remaining fixed-window question for arbitrary centers. Marginal
entropy already forces \(P=\Omega_A(M/\ln M)\) centers with an explicit leading constant,
but the stronger prefix-path obstruction does not survive without its ordered-increment
structure. Achieving the matching order requires a detecting matrix for which every point pair
has a row with unequal values and at least one endpoint remaining inside the central window.
Proposition 12 shows that the antipodal subproblem alone needs only
\(\Theta_A(\sqrt M)\) centers, so any larger fixed-window obstruction must couple intermediate
even-distance layers rather than force a collision at \(x,-x\).
Proposition 13 extends this conclusion to the largest even-distance layer in odd dimension.
Proposition 14 extends it further to every fixed-codimension near-antipodal even layer.
Proposition 15 makes the exclusion quantitative: a single near-antipodal layer that could
force collisions at the \(M/\ln M\) center budget must have agreement codimension at least
of order \(\sqrt M/\ln M\). Proposition 16 compresses the singleton modulations by a
classical detecting matrix and sharpens this necessary codimension to order \(\sqrt M\).
Proposition 17 makes the conclusion simultaneous: one center family at the entropy scale
separates the entire band of pairs with at most \(c_{A,C}\sqrt M\) agreements.
Proposition 18 shows that the product form of this family cannot be proved optimal by isolating
constant-size prefix clusters and summing independent detecting lower bounds.
Proposition 19 goes further: zero-return propagation removes that product throughout every
band \(R\le c\sqrt M\), \(c<A/3\), and the resulting \(\Theta_{A,c}(\sqrt M)\) bound is
optimal.
Proposition 20 replaces the agreement count by its signed prefix discrepancy. At the
\(M/\ln M\) center scale it handles arbitrary agreement counts whenever that discrepancy
stays a fixed margin below the central-window width.
Proposition 21 gives the exact collision criterion for the complete prefix family and shows
that its \(W+2\) discrepancy threshold is sharp up to the lattice spacing. It therefore
closes denser prefix sampling, by itself, as a route through the high-discrepancy remainder.
Proposition 22 gives a prefix-neighborhood lower-bound tradeoff up to radius \(M/64\). Its lower
bound is \(M^2/((W+\rho)\ln(\rho+1))\); at radius \(W/4\) it matches the
\(\Theta_A(M^{3/2}/\ln M)\) Cartesian construction of Proposition 17. At the entropy
scale it forces at least one center to have linear distance from the entire prefix path.
Proposition 23 shows why neither rowwise slice-capacity summation nor a common block-balanced
conversion of classical detecting rows resolves the resulting nonlocal regime.
Proposition 24 then shows that even simultaneous ternary detection on every shifted crossing slice
is achievable by \(O(M/\ln M)\) linearly nonlocal centers. The remaining slice-based obstruction
must therefore couple detection to endpoint centrality.
Along the same dimensions divisible by \(32\), Proposition 25 gives the complementary hybrid
lower bound: adding \(K\) arbitrary exceptions subtracts at most \(K\ln(N+1)\) from each
slice's detecting requirement. It follows that every entropy-scale injective family must devote
\(\Omega(M/\ln M)\) centers to the linearly nonlocal regime.
Proposition 26 shows that a single crossing slice nevertheless admits a matching
\(\Theta_A(M/\ln M)\) tail-robust family in which both endpoints of every witnessed pair are
central. Any remaining slice-based obstruction must couple the affine offsets across several
shifts rather than isolate one slice.
Along dimensions divisible by \(32\), Proposition 27 synchronizes those offsets and gives the
same entropy-scale upper bound simultaneously for all crossing slices. Thus the complete
crossing-window witness system from Proposition 22 cannot by itself prove a super-entropy lower
bound against arbitrary centers.
Proposition 28 strengthens this boundary: any center using one exact baseline across all shifted
slices, not only the periodic distribution in Proposition 27, has forced half-period equalities
on the corresponding even coordinates. An explicit distance-two cone pair lies in the common
kernel of the entire class. Baselines that vary within the available centrality margin remain
open.
Proposition 29 shows that this exactness is essential. Baseline motion bounded by the absolute
constant \(4\) suffices to retain entropy-scale simultaneous detection and endpoint centrality
while making every half-period coordinate pair appear with both equal and opposite signs across
the family. Thus neither of the two associated ternary vectors remains in the common kernel.
Proposition 30 then treats the complete distance-two layer without a prefix or crossing-slice
restriction. Every coordinate relation separately forces a square-root-size equatorial cover of
an \((M-2)\)-cube, giving an arbitrary-center \(\Omega_A(\sqrt M)\) lower bound, while
independent random centers give an \(O_A(M)\) upper bound. Whether simultaneous sharing across
all coordinate pairs reaches the entropy scale is open.
Proposition 31 shows that one natural sharing mechanism is exactly linear: centers obtained from
one prefix order by \(O_A(\sqrt M)\)-supported modulations need \(\Theta_A(M)\) rows to
cover the complete distance-two layer. Thus an entropy-scale construction must use multiple
orders or genuinely global centers rather than a denser one-order prefix neighborhood.
Proposition 32 shows why a multi-order lower bound cannot follow merely by isolating a bounded
central cluster in each order. Three point-dependent prefix centers already give balanced central
rows with no antipodal column pair at any prescribed point. The unresolved cost is therefore the
simultaneous reuse of one fixed collection of orders across all points of the cube.
Proposition 33 quantifies such reuse on a structured family: \(2^d\) Walsh points with all
coordinate signatures repeated in multiples of four have exact common star complexity \(d+3\).
Thus even a linearly large family of hard points can share logarithmically many prefix centers;
any additive hard-point lower bound must break this Walsh compatibility.
Proposition 34 shows that this conclusion is stable under a common central window. At width
\(A\sqrt M\), choosing equal blocks with \(m=\Theta_A(d)>2A^2(d+2)\) gives Walsh families
of size \(\Theta_A(M/\log M)\) with exact common-central star complexity
\(d+3=O(\log M)\). The lower bound follows from a Fourier-energy budget across blocks rather
than exact blockwise balance.
Proposition 35 removes common centrality completely in the first two Walsh dimensions and across
an initial window range in the four-point case. For two equal blocks, the arbitrary-center complexity drops from four
to three at \(W=m-4\), and then to two at \(W=2m-4\). The first transition exactly realizes
the neighbor-central \(W+4\) margin from Proposition 30. With four equal blocks, four
block-constant Walsh rows beat the five-row exact-zero/common-balance benchmark from Proposition 33
throughout \(W<2m-4\).
Proposition 36 shows that this low-dimensional saving does not extend to \(d=3\) by merely
selecting block-constant rows. Six such rows are necessary and sufficient at \(W=0\), so any
five-row arbitrary-center construction must introduce genuine projective variation within at
least one block.
Proposition 37 gives the corresponding unrestricted structural reduction. The eight blocks of a
five-row candidate must use pairwise disjoint projective supports, reducing all coordinate-pair
requirements to at most \(1088\) type-pair conditions. Moreover, any Walsh base with exactly
three active rows forces an equally weighted parity tetrahedron and the identity that the product
of those three centers is \(\pm x^g\). Thus a candidate either enters this parity branch or has
four or five active rows at every base.
Proposition 38 sharpens that four/five-active branch. It cannot have five active rows at every
base, and every four-active base contains at least two zero-baseline rows. Hence this branch has
a sound canonical form with one fixed four-active base, two fixed zero rows, and one inactive
row, while the three-active parity branch remains separate.
Proposition 39 constrains the latter branch in turn. Once a parity tetrahedron is fixed at one
three-active base, every other base has an active tail row, and not all eight bases can remain
three-active. Thus a second, nonzero base can be fixed with at least four active rows and a
specified active tail row. The obstruction is linear-algebraic: the ten triple products of five
centers, modulo the forced head relation, cannot cover the three-dimensional Walsh character
space.
Proposition 40 excludes the remaining two-zero-row case at every four-active base. The local
four-row data have only five symmetry types, and proof-certified five-base relaxations rule out
all five. Therefore every four-active base has three or four zero active baselines; the unresolved
finite branches are the corresponding \(z=3,4\) assignments and the globally coupled
three-active parity assignments.
Proposition 41 gives a complete analytic classification of the \(z=3\) local data. There are
two profile mechanisms: an eightfold parity tetrahedron with a bounded four-part split, and one
exceptional \((8,1;7)\) mechanism. The \(924\) labelled profiles reduce to \(32\) safe orbits.
An explicit projective-disjoint block lift satisfies every condition at the selected base, so no
argument using only that base's compatibility and margins can eliminate \(z=3\); the obstruction
must couple at least one further Walsh base.
Proposition 42 performs the first such coupling. Quotienting one nonzero Walsh cut to two
mass-sixteen halves gives a relaxation that is already proof-certified UNSAT for the exceptional
orbit and seven bounded partitions. Hence only \(24\) of the \(32\) local \(z=3\) orbits remain;
their compatibility with the original eight blocks is not decided here.
Proposition 43 distinguishes three selected points from a closed Walsh plane. The
\((2,2,6,8)\) orbit has a genuine eight-block lift across \(0,e_1,e_2\), but the four-cell
quotient on the completed plane \(\langle e_1,e_2\rangle\) is proof-certified UNSAT.
Proposition 44 then closes the whole \(a\le1\) boundary. Proposition 42 excludes four of the
seven \(a=0\) partitions and three of the eight \(a=1\) partitions; the remaining three and
five, respectively, have proof-certified UNSAT four-cell plane quotients. Hence every globally
liftable tetrahedral profile has \(a\ge2\), and only \(15\) local \(z=3\) orbits remain.
Proposition 45 uses the affine symmetry of the complete Walsh-plane quotient to select a
canonical cell assignment without loss, and the resulting proof-certified formulas exclude
\((2,3,5,8)\) and \((2,2,7,7)\). Thus only \(13\) local \(z=3\) orbits remain.
Proposition 46 completes the affine cell normalization and orders the lift-mass signatures of
equal-\(\alpha\) heads. The resulting proof-certified formulas exclude \((2,4,4,8)\) and
\((3,3,4,8)\), leaving only \(11\) local \(z=3\) orbits.
Proposition 47 then characterizes exactly when a four-cell model recovers the two original
mass-four blocks in every cell: the unique obstruction is the local multiplicity partition
\(3+3+2\). This removes all ambiguity in the block-splitting interface, but does not yet impose
the four Walsh bases outside the plane.
Proposition 48 factorizes those four transverse characters through balanced class-side choices
and determines the exact side gauges: eight orbits for one named transverse base, but only the
two parity orbits for the complete transverse coset. Proposition 49 then gives a new analytic
constraint on every surviving \(z=3\) profile. Any projected type of multiplicity greater than
four forces the fifth row active on a four-point affine hyperplane of nonzero Walsh bases; hence
every fixed transverse coset contains at least two such bases, and a plane can be chosen with at
least two active nonzero bases. This is a necessary condition, not a further profile exclusion.
Proposition 50 combines Walsh inversion with block capacity to rule out projected multiplicity
seven and the coexistence of two multiplicity-six types. A direct labeled block-sum
classification handles the remaining mixed \((3,4,5,6)\) case and proves that only the three
profiles in (33mh) survive. Explicit row-5 assignments show that this relaxation is sharp, but
do not give global five-row families. Proposition 51 then imposes every distinct-type and
repeated-type condition at all eight Walsh bases. A complete finite classification excludes
\((4,4,4,6)\), leaving only the two profiles in (33mq). Proposition 52 applies the same complete
classification to those profiles and excludes both. Thus the four-active \(z=3\) branch is
closed; only \(z=4\) remains in the four-active local analysis. Proposition 53 gives its exact
selected-base classification. A four-dimensional Walsh parameterization yields twenty-nine
projected orbits; the inactive fifth-row condition removes exactly the four-type
\((8,8,8,8)\) orbit, and each of the other twenty-eight has a selected-base eight-block lift.
Proposition 54 extracts the general Walsh halfspace block-capacity bound: after deleting any
row, every projected multiplicity is at most six, and a mass-six type cannot coexist with any
other overfull type. This excludes twenty-five of the twenty-eight local four-zero profiles,
leaving the three vectors in (33nj). Proposition 55 checks their complete eight-base lift
spaces and excludes all three. Thus the four-active branch is closed. Proposition 56 treats the
separate three-active parity branch. Its selected-base relaxation has \(2{,}214\) safe orbits;
a complete eight-block, eight-base lift classification sends all \(74{,}357{,}070\) label
states through (33jd) and excludes every one. Proposition 57 combines the two closed branches
with the six-row construction of Proposition 33, proving the exact finite value
\(\nu_{3,0}(4,4,4,4,4,4,4,4)=6\). Proposition 58 then identifies the correct first
growth obstruction to extrapolating this value. A character set whose every nontrivial affine
cut has both sides of size at least two separates all Walsh stars; the even-dimensional affine
circuit in (33ny) gives only \(d+2\) block-constant centers for every even \(d\ge4\).

The project literature map also records the low-score partition delocalization theorem, which
connects any global minimizer of the LTF restriction score to a disjoint partition by a
low-score single-swap path. That result is supporting evidence for the geometric boundary,
not a separate main theorem in this paper.

## 6. Limitations

The theorem requires the explicit high-density regime \(qh/\sqrt N\gg N\) to union-bound
over all restrictions. It does not cover every \(q,h,N\) regime, and it does not assert that
the CTW lower-bound method cannot use information beyond pairwise geometry. The narrow-cone
construction adds selector variables and preserves polynomial size rather than matching every
fixed model parameter.

The full-cube conclusion uses the stronger density condition \(q/\sqrt{N-h}\gg N\) and the
constant threshold \(2\). It is asserted only for \(h=O(\sqrt{N-h})\). This range is real:
at Hamming distance \(t=1\), the proof notation gives the exact separation probability

\[
 \rho(1)
 =\Pr[R_{M-1}=\gamma-h]
  +\Pr[R_{M-1}=\gamma+h].
 \tag{37}
\]

Thus \(h=\Theta(M)\) makes \(\rho(1)=M^{-1/2}e^{-\Omega(M)}\); the same conclusion holds
for every fixed finite set of constant thresholds. Theorem 3 is restricted to sign-normal
LTFs, and the remaining \(\sqrt{\log M}\) gap between (30) and Proposition 7 is open.
Proposition 8 closes the independent-random-center pairwise first-moment template only when
each radius set is fixed before its center is exposed; it does not cover arbitrary exact-sphere
constructions. Propositions 9--10 leave constant-factor gaps in the antipodal and
largest-even-layer covering numbers and do not show how to cover all intermediate
even-distance layers at comparable cost. Proposition 11 rules out fixed-window families only
below the entropy constant \(2\ln2/q_A\); existence at larger constants, equivalently the
construction of tail-robust detecting matrices at order \(M/\ln M\), remains open.
Proposition 12 settles only the antipodal restriction of that problem and does not control any
intermediate even-distance layer. Proposition 13 also settles the largest even-distance layer
in odd dimension. Proposition 14 settles every fixed-codimension near-antipodal layer, but it
likewise leaves growing codimension and other distance regimes open.
Proposition 15 excludes the smaller growing range \(r=o(\sqrt M/\ln M)\) only layerwise; it
does not produce one family separating all such layers simultaneously.
Proposition 16 extends this layerwise exclusion to \(r=o(\sqrt M)\), but its modulations
depend on \(r\). Proposition 17 removes that dependence over a whole near-antipodal band,
but the family still depends on the band cutoff \(R\) and does not control pairs with more
than \(R\) agreement coordinates.
Proposition 18 closes only the cluster-isolation lower-bound argument. It neither compresses
the Cartesian product in Proposition 17 nor proves that the product is necessary by itself.
Proposition 19 does compress the product when \(3R+2\le W\), but the zero-return propagation
argument loses its window margin beyond this range and does not control intermediate or small
Hamming distances.
Proposition 20 recovers the propagation argument for arbitrary agreement counts under the
additional condition \(\Delta(x,y)\le(A-\delta)\sqrt M\). It does not control the
high-discrepancy agreement paths in (33ce), and therefore does not give global fixed-window
injectivity.
Proposition 21 characterizes collisions only for the complete family of prefix centers. Its
linear center count is above the entropy scale, and the proposition supplies neither a global
injective family nor a collision theorem against arbitrary non-prefix centers.
Proposition 22 controls families contained in one radius-\(\rho\) prefix neighborhood only
for \(\rho\le M/64\), and its lower bound is stated along dimensions divisible by \(32\).
It forces only the presence of at least one linearly nonlocal center; it does not quantify how
many such centers are necessary or rule out entropy-scale injective families built from them.
Proposition 23 closes only two specific continuations: summing rowwise output capacities across
the Proposition 22 slices, and using centers balanced on a single common even-block partition.
It neither bounds the joint detecting power of arbitrary nonlocal rows nor excludes adaptive or
overlapping block structures that break the displayed ternary kernels.
Proposition 24 controls only the algebraic detecting condition on shifted adjacent-pair blocks. It
does not guarantee that either endpoint of every detected pair lies in the central window, and
therefore does not construct an injective fixed-window family. Its constant \(8\) is only a
convenient sufficient constant, not the sharp detecting-matrix constant.
Along dimensions divisible by \(32\), Proposition 25 permits arbitrary exceptional centers but
only while all remaining centers lie in one common prefix neighborhood \(\mathcal N_\rho\).
It forces an entropy-scale number of linearly nonlocal centers, but it neither classifies their
geometry nor proves that such a global family cannot satisfy endpoint centrality.
Proposition 26 treats only one crossing slice. Its centers and offsets depend on that slice's
outside agreement pattern, so it neither synchronizes multiple shifts nor separates arbitrary
cube pairs.
Along dimensions divisible by \(32\), Proposition 27 synchronizes all crossing slices but still
separates only the structured pair families in (33ct). It does not provide full-cube fixed-window
injectivity, and it does not address high-discrepancy pairs with a different
agreement/disagreement geometry.
Proposition 28 closes only exact constant-baseline synchronization across the Proposition 27
slices. Its distance-two pair is a common-kernel obstruction forced by adjacent-window
equalities; it is not a lower bound against arbitrary centers and does not rule out varying or
approximate baselines.
Proposition 29 treats only the structured crossing slices and only removes the half-period
two-coordinate kernels isolated by Proposition 28. It does not prove full-cube fixed-window
injectivity and does not exclude a different, higher-support common kernel or a collision outside
the crossing-slice families.
Proposition 30 treats every distance-two pair, but its square-root lower bound is below the
entropy scale and its linear upper bound is above it. It neither proves that the distance-two
layer obstructs \(O(M/\ln M)\) centers nor supplies an entropy-scale construction for that
layer. The projective condition (33gi) is necessary only with the enlarged width \(W+4\) and
sufficient at width \(W\); closing this constant-width sandwich does not by itself close the
asymptotic center-count gap.
Proposition 31 is restricted to one fixed prefix order and Hamming-radius-\(\ell\) modulations.
Its linear lower bound does not apply to several coordinate permutations, overlapping global
block systems, or arbitrary centers. The sampled-permutation analogue of (33hd)--(33hg) remains
unresolved.
Proposition 32 is only pointwise: its three coordinate orders and sampled ranks may depend on
\(x\). It rules out a cluster-count-to-antipodality inference, but it neither constructs one fixed
family for the complete distance-two layer nor lowers the arbitrary-center upper bound.
Proposition 33 uses one fixed family, but only on the union of stars around a specially balanced
Walsh point set and with each center represented in its own order. It does not cover every point
of the cube, constrain several ranks from the same order, or settle the sampled-permutation
analogue of (33hd)--(33hg).
Proposition 34 relaxes exact common balance only for block sizes satisfying (33ia), and still
requires every center to lie in the central window at every Walsh base point. It gives no lower
bound for star-separating families without this common-centrality condition and does not extend
from the union of Walsh stars to the complete distance-two layer.
Proposition 35 classifies arbitrary centers only for \(d=0,1\), with equal blocks in the
two-point case, and the initial equal-block window range at \(d=2\). Its pointwise
three-active-row bound is general, but the exact calculations do not control growing Walsh
dimension: different rows may be near-central at different base points, so the Parseval argument
of Proposition 34 no longer applies rowwise.
Propositions 36--55 are branch reductions rather than standalone decisions of the unrestricted
problem. Their combination is complete only because Proposition 56 separately exhausts the
three-active parity branch. That final enumeration is specific to \(d=3\), \(W=0\), and eight
blocks of size four. It does not classify unequal block sizes, larger blocks, positive windows,
or growing Walsh dimension.

Proposition 57 is therefore an exact finite Walsh-star value, not a full-cube injectivity result
and not an asymptotic threshold-circuit lower bound. In particular it neither closes the
entropy-scale gap in Proposition 30 nor resolves P versus NP. The finite certificates establish
only the explicitly stated combinatorial classification; successful reproduction is not
independent evidence for any stronger complexity-theoretic claim.

Proposition 58 shows that the direct \(d+3\) extrapolation is false, but it is only an upper
bound. It neither proves that \(d+2\) is optimal in even dimensions nor determines the
arbitrary-center value at \(d=4\); five centers may still be possible. The character-cut
criterion also does not classify odd dimensions or unequal block sizes.

## Sources

- Chen, Tal, and Wang, *Super-Quadratic Lower Bounds Against Depth-Two Threshold Circuits*,
  [ECCC TR26-039](https://eccc.weizmann.ac.il/report/2026/039/).
- Ferber, Jain, and Zhao, *On the Number of Hadamard Matrices via Anti-Concentration*,
  [arXiv:1808.07222](https://arxiv.org/abs/1808.07222).
- Raič, *A Multivariate Berry--Esseen Theorem with Explicit Constants*,
  [arXiv:1802.06475](https://arxiv.org/abs/1802.06475).
- Gopalan et al., *An FPTAS for #Knapsack and Related Counting Problems*,
  [FOCS 2011](https://www.microsoft.com/en-us/research/publication/an-fptas-for-knapsack-and-related-counting-problems/).
- Cantor and Mills, *Determination of a Subset from Certain Combinatorial Properties*,
  [Canadian Journal of Mathematics 18 (1966)](https://doi.org/10.4153/CJM-1966-007-2).
- Erdős and Rényi, *On Two Problems of Information Theory*,
  *Magyar Tud. Akad. Mat. Kutató Int. Közl.* 8 (1963), 229--243.
- Lindström, *On a Combinatory Detection Problem I*,
  *Magyar Tud. Akad. Mat. Kutató Int. Közl.* 9 (1964), 195--207.
- Sedaghat, Müller, and Marvasti, *On Optimum Asymptotic Multiuser Efficiency of Randomly
  Spread CDMA*, *IEEE Transactions on Information Theory* 61 (2015), 6635--6642,
  [doi:10.1109/TIT.2015.2482483](https://doi.org/10.1109/TIT.2015.2482483).
- Lu and Ye, *A Bridge Between the Minimal Doubly Resolving Set Problem in (Folded)
  Hypercubes and the Coin Weighing Problem*,
  [Discrete Applied Mathematics 309 (2022)](https://doi.org/10.1016/j.dam.2021.11.016).
- Tillquist, Frongillo, and Lladser, *Truncated Metric Dimension for Finite Graphs*,
  [Discrete Applied Mathematics 310 (2022)](https://doi.org/10.1016/j.dam.2022.04.021).
- Auger, Cohen, and Mesnager, *Sphere Coverings and Identifying Codes*,
  [Designs, Codes and Cryptography 70 (2014)](https://doi.org/10.1007/s10623-012-9638-x).
- Sauermann and Xu, *Nondegenerate Hyperplane Covers of the Hypercube*,
  [Electronic Journal of Combinatorics 33 (2026), #P2.6](https://doi.org/10.37236/14725).
- Project derivation notes
  [007](../../notes/007-low-score-partition-delocalization.md),
  [008](../../notes/008-second-order-restriction-obstructions.md), and
  [013](../../notes/013-column-type-entropy-obstruction.md).
