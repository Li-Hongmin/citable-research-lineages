# P vs NP research workspace

## Scope and search date

- Search date: 2026-08-12.
- Boundary: classical deterministic P versus NP; NP-completeness; relativization, natural-proofs, and algebrization barriers; circuit lower bounds; hardness magnification; meta-complexity; and implications for algorithms, optimization, and complexity-based cryptography.
- Out of scope except for brief caveats: quantum complexity, fine-grained conjectures such as ETH/SETH, and a complete survey of proof complexity or algebraic complexity.

## Current conclusion

P versus NP remains open. The formal question is whether every language with polynomial-size certificates verifiable in deterministic polynomial time is itself decidable in deterministic polynomial time. The common “find versus verify” slogan is essentially correct for polynomially balanced NP search relations: if P=NP, a witness can be recovered bit by bit with polynomially many decision queries.

The strongest evidence mapped here is indirect. There are major lower bounds for restricted circuit classes and for stronger exponential-time classes, together with sharp characterizations in meta-complexity. None supplies a superpolynomial lower bound for an NP language against unrestricted deterministic computation.

## Evidence map

1. Foundations: Cook (1971) and Karp (1972).
2. Methodological barriers: Baker-Gill-Solovay (1975), Razborov-Rudich (1997), Aaronson-Wigderson (2009), and Chen-Hu-Ren (2026).
3. Positive lower-bound programs: Williams (ACC), hardness magnification and locality, geometric complexity theory.
4. Current frontier examples: depth-2 threshold lower bounds, near-maximum circuit lower bounds for an exponential-time class, and nondeterministic Kolmogorov-complexity characterizations.
5. Cryptography caveat: one-way functions are central to complexity-based cryptography, but P≠NP alone does not imply them; the average-case gap remains open and was sharply characterized in the 2026 Pessiland paper.

## Retrieval state

- 15 cached records and abstracts.
- 11 local primary PDFs.
- 10 PDFs extracted to searchable text.
- Cook 1971 is a scan; its PDF is local, but automatic text extraction is empty.
- 4 records are metadata/abstract-only because no lawful open full text was automatically retrieved in this run.
- No missing declared attachments.
