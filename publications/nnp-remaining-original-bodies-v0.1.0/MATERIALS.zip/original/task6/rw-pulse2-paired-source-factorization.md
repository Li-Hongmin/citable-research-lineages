# Paired-source edge moments restrict the complete Frobenius kernel

2026-10-03, bounded pulse2. Private contribution candidate; no project theorem promotion, publication, signature or DOI. The proposition and algebraic corollary are self-contained; their RW application is conditional on the source/route assumptions below.

## Self-contained mixed edge moment

Let \(u=2^\mu\ge8\), \(F=\mathbb F_{u^6}\), \(K=\mathbb F_u\), \(Q=u^6\), and
\[
M=1+u+\cdots+u^5,\quad U_4=u+u^2+u^3+u^4,\quad
B_*=4U_4,\quad \kappa=4u^5,\quad d_*=B_*+\kappa+2=4M-2.
\]
Take distinct \(p,q\in K\), \(L_b(Z)=1+(Z+b)^{u-1}\), \(S=L_p+L_q\), and
\[
\omega(Z)=S(Z)^{4(M-1)}L_p(Z)^2.
\]
For \(T\in F[Z]_{<u}\), define four linear quantities of the same polynomial:
\[
a_T=[Z^{u-1}]T,\quad g_T=[Z^{2u-3}]L_pT,\quad
h_T=T(p)+T(q),\quad t_T=[Z^{3u/2-1}]ST.
\]

**Proposition.** For every \(T,P,R\in F[Z]_{<u}\),
\[
\boxed{\sum_{Z\in F}\omega(Z)T(Z)^2P(Z)^{B_*}R(Z)^\kappa
=h_P^{B_*}\bigl(a_T^2h_R^\kappa+g_T^2t_R^\kappa\bigr).} \tag{1}
\]
No Boolean-grid or independent-advice assumption is used.

**Proof.** The integrand is
\[
(L_pT)^2\prod_{j=1}^4(SP)^{4u^j}(SR)^{4u^5}.
\]
The local degrees are at most \(2u-2\), \(2u-3\), \(2u-3\), respectively. Its total degree is below \(8(Q-1)\). All exponents are even, so full-field power summation can only select \(2(Q-1),4(Q-1),6(Q-1)\); exponent zero sums to zero. The high factor has exponents divisible by \(4u\). The first candidate would require a low exponent \(4u-2\), exceeding its degree \(4u-4\). The other two select low exponents \(4u-4\), \(4u-6\), with coefficients \(a_T^2,g_T^2\).

After removing these exponents and taking the fourth root of the high factor, the targets are \(Q-u\), \(3Q/2-u\). Each lower base-\(u\) position must contribute exponent \(u-1\); the next congruent candidate \(2u-1\) exceeds its local degree. Hence no carries occur in the lower four positions. The coefficient of \(SP\) at \(u-1\) is the grid sum \(\sum_{b\in K}S(b)P(b)=h_P\), because its degree is below \(2(u-1)\). The top position contributes \(h_R\) or \(t_R\), respectively. Raising to the fourth power proves(1). \(\square\)

## A constraint on the complete paired kernel

Define the local kernel shape, independently of an RW construction, by
\[
\mathscr H_{A,B}(w)
=\bigl((A+B)^4+wA^4\bigr)^{U_4}
 \left[(A+B)^{2+\kappa}+w^{u^5}G_5(A,B)^2\right],
\quad
G_5(A,B)=(A+B)A^{2u^5}+B^{1+2u^5}.
\]
This is the complete local shape of609.7/620.15:
\(\mathscr J_0(A,B,r)=r\mathscr H_{A,B}(r^2)\).

**Corollary.** Let \(V_0,V_1,O\in F[Z]_{<u}\), with \(O(p)=O(q)=0\), and fix \(s\ne0,z\in F\). Define
\[
H(w)=\sum_{Z\in F}\omega(Z)\sum_{i=0}^1
\mathscr H_{sV_i(Z),szO(Z)}(w)
=\sum_{S'\subseteq\{1,\ldots,5\}}a_{S'}w^{E_{S'}},
\quad E_{S'}=\sum_{j\in S'}u^j.
\]
Then, as ordinary polynomial identities,
\[
\boxed{H(w)=(1+w)^{U_4}
\bigl(a_\varnothing+a_{\{5\}}w^{u^5}\bigr),\qquad
H_{[5]}(w)=a_{\{5\}}(1+w)^{U_4}.} \tag{2}
\]
Thus all16 coefficients omitting5 equal \(a_\varnothing\), and all16 containing5 equal \(a_{\{5\}}\).

**Proof.** Both sides have degree at most \(M-1<Q\), so equality at every field value \(w\) suffices. Fix \(v^4=w\), and set \(P_i=(1+v)V_i+zO\). After removing source-homogeneity factor \(s^{d_*}\), the lower local factor is \(P_i^{B_*}\). Since \(h_O=0\),
\[
h_{P_i}^{B_*}=(1+w)^{U_4}h_{V_i}^{B_*}.
\]
For the unselected top component apply(1) with \(T=R=V_i+zO,P=P_i\). The remaining expression, after removing the displayed common factor, is its value at \(w=0\), namely \(s^{-d_*}a_\varnothing\). For the selected top component use
\[
G_5(V_i,zO)^2=(V_i+zO)^2V_i^\kappa+(zO)^{2+\kappa}.
\]
Apply(1) to \((T,P,R)=(V_i+zO,P_i,V_i)\) and \((zO,P_i,zO)\). Its remaining value at zero is \(s^{-d_*}a_{\{5\}}\). Sum over \(i\), restore \(s^{d_*}\), and insert \(w^{u^5}\). Since \(U_4<u^5\), the subset supports are disjoint, also proving the highest-section identity. \(\square\)

## Mapping to the actual source, and the previous abstract example

At the fixed first tuple in614.17–614.25,
\[
A_i(Z)=sV_i(Z),\quad B(Z)=szO(Z),\quad
s=L_0(X),\quad z=X/(X+a_o),\quad O(Z)=\lambda L_o(Z),
\]
with \(o\ne p,q\), \(a_o\in K^\times\), \(V_1=V_0+\Delta\). Hence \(h_O=0\), precisely the premise of(2). No actual \(V_i\) or kernel coefficient is freely selected.

The normalized coefficients in614.19/621.3 are
\[
s^{-d_*}a_\varnothing=P_0(z)=c_0+c_2z^2+c_\kappa z^\kappa+c_Tz^{\kappa+2},
\qquad
s^{-d_*}a_{\{5\}}=P_5(z)=c_0+c_2z^2+c_Tz^{\kappa+2}. \tag{3}
\]
Here \(c_T=c_{\kappa+2}\). These \(c_j\) are independent of \(X\) only after the separator factor has been removed. Degree \(\kappa+2\) belongs to these normalized polynomials, not the original coefficients containing the varying \(s^{d_*}\).

On a selected first tuple with \(a_{\{5\}}\ne0\),
\[
H_{[5]}(\sigma)=0\iff\sigma=1. \tag{4}
\]
The previous pulse's constant local sections \(a=1,b=1+\sqrt[4]{\sigma}\) cannot arrange arbitrary zeros at \(\sigma\ne1\) in this complete paired integral. Their realization in the actual source was never proved.

Indeed, imposing the local lower-factor root on both actual sections would require
\((1+\sqrt[4]{\sigma})V_i+zO=0\).
Subtracting gives \((1+\sqrt[4]{\sigma})\Delta=0\).
At a falling edge \(\Delta(p)\ne0\), this forces \(\sigma=1\); the local condition then becomes \(zO=0\), false at off-grid \(Z\) when \(z,\lambda\ne0\). Yet the complete integral really vanishes at \(\sigma=1\). This explicitly separates exclusion of a pointwise realization from the unjustified inference of nonzero total sum. The actual parameter might or might not reach1; no reached cancellation is asserted.

## Completing the actual spare gate

Retain the earlier complete-spare identity and all32 basis transfers:
\[
\mathcal B_x=\Gamma_xL_0(y)^2
\left[(A_x+c)H_x(\sigma_x)
 +cd(tC_x\eta)^{2u^5}H_{x,[5]}(\sigma_x)\right], \tag{5}
\]
\[
\eta=y^{2(u-1)},\quad t=X^{2(u-1)},\quad
\sigma_x=(tD_x\eta)^2,\quad U=y^2,\quad d=b^2\in K^\times,
\]
\[
D_x=A_xU^{2(u-1)}+c(U+d)^{2(u-1)},\qquad
C_x=A_xU^{3u/2-2}+c(U+d)^{3u/2-2}.
\]
\(A_x\) is the actual reference third-source background; \(C_x\) is its moment, not \(\kappa\). The factor \(\Gamma_x\) excludes the spare weight. Fix the other first tuple and permitted third remainder before selecting \(X\), so \(A_x,c,D_x,C_x,\eta,c_j\) are all independent of \(X\). The third route must not be allowed to change with this first separator value.

After substituting(2)–(3), divide out the nonzero public factors and \(s^{d_*}\). The result is
\[
(1+\sigma_x)^{U_4}
\left[\mathfrak a_xP_0(z)+\mathfrak b_x t^{2u^5}P_5(z)\right], \tag{6}
\]
\[
\mathfrak a_x=A_x+c,\qquad
\mathfrak b_x=\eta^{2u^5}
\left[(A_x+c)D_x^{2u^5}+cdC_x^{2u^5}\right]. \tag{7}
\]
These scalars come from the same source; neither is separate advice.

If \(A_x=c\), the chosen \(C_x\ne0\) and nonzero public factors imply \(\mathfrak b_x\ne0\). The bracket in(6) vanishes exactly at roots of \(P_5\), at most \(\kappa+2\) off-grid values when \(c_T\ne0\).

If \(A_x\ne c\), its two terms must be controlled together. For nonzero field values \(X\), field reduction gives
\[
t^{2u^5}=X^{4Q-\kappa}=X^{4-\kappa}
=\left(\frac z{1+z}\right)^{4-\kappa}. \tag{8}
\]
The last equality uses \(X=a_oz/(1+z)\) and \(a_o^{\kappa-4}=1\). This is a field-function equality, not a formal unreduced exponent identity.

For \(z\notin K\), the clearing factor \(z^\kappa(1+z)^4\) is nonzero. The bracket vanishes exactly at roots of the ordinary polynomial
\[
R_x(z)=\mathfrak a_xz^\kappa(1+z^4)P_0(z)
 +\mathfrak b_xz^4(1+z^\kappa)P_5(z),
\quad \deg R_x\le2\kappa+6=8u^5+6. \tag{9}
\]
If \(c_T\ne0,\mathfrak a_x\ne0\), this polynomial is always nonzero:

- When \(\mathfrak b_x\ne\mathfrak a_x\), its coefficient at degree \(2\kappa+6\) is \((\mathfrak a_x+\mathfrak b_x)c_T\ne0\).
- When they are equal,
  \[
  R_x/\mathfrak a_x=(z^\kappa+z^4)P_5
        +c_\kappa z^{2\kappa}(1+z^4).
  \]
  If \(c_\kappa\ne0\), its highest term is \(c_\kappa z^{2\kappa+4}\); otherwise it is \(c_Tz^{2\kappa+2}\).

Thus the varying actual \(\sigma_x(X)\) has a new bad-point bound \(8u^5+6\); it is not controlled by incorrectly applying621's fixed coefficient degree.

The other factor vanishes at \(\sigma_x=1\), equivalently
\[
X^{2(u-1)}=(D_x\eta)^{-1}. \tag{10}
\]
If \(D_x=0\) there are no such roots. Otherwise there are at most \(u-1\), because squaring is injective and the \(X^{u-1}\) fibers have size \(u-1\). Existence requires the corresponding value in the norm-one image subgroup. This is an \(X\) condition after \(W\) has been summed; the before-sum parameter \(L_0(W)\) is different from \(\eta=y^{2(u-1)}\).

## Conditional reached-subtable consequence

Assume621's reached falling density, common checker serialization, zero-source spare geometry, full contractions and first root average. At one common \(y\), fixed permitted third remainder and normalized first sections, suppose a set \(\mathcal E\) of \(\Omega(n_0/(q\log_2q))\) reached falling edges has \(c_T\ne0\). Require nonzero public factors, and choose \(y\) so \(C_x\ne0\) on the \(A_x=c\) fiber as in621.7; that expression is independent of the edge on this fiber since \(c,d\) are common.

For each such edge the bad \(X\) sets in(9)–(10) contain at most \(8u^5+6+(u-1)\) points. Any additional nonzero public factors with \(O_C(u)\) bad points can be included. Their fraction among off-grid choices is
\[
\frac{8u^5+6+(u-1)+O_C(u)}{u^6-u}=O_C(1/u).
\]
Consequently a second root average selects one common off-grid \(X\) for which a constant fraction of these same actual edges has \(\mathcal B_x\ne0\), for all sufficiently large legal lengths. No knowledge of which background case an edge occupies is needed to select the common value existentially. Its one field constant has the same charged address-generator resources as621; no per-edge source values are supplied. The spare third coordinate is now fully summed, rather than fixed as a witness.

This is conditional on the stated source dependencies, not a new certification of every construction step back to the published hard word. It covers only the complete \(Y,Z_1,Z_2,W\) padding-subtable sum after the sparse \(J\)-pair contraction and first last-digit sum, at other coordinates still fixed. Other first/third sums, added real incidence defects, trace, seven other norm orbits, auxiliary tables and the physical JK response remain open. No address-scale source evaluation algorithm, exact same-object surface, or NP circuit lower bound follows.

## Reproduction and independent-context limits

The earlier rw_spare_check.c and rw_field_modulus_check.py, with raw outputs, preserve all32 complete-spare basis checks. The new rw_actual_kernel_check.c reuses only that field arithmetic. It separately enumerates the complete \(Z\) sum for all32 local-kernel coefficients on two deterministic synthetic canonical pairs with one-hot common \(O\), zero OUTPUT endpoints and nonzero paired selector. It checks(3) and the rational clearing identity at every off-grid \(X\), in both scalar cases \(\mathfrak b=\mathfrak a\) and \(\mathfrak b\ne\mathfrak a\). Synthetic pairs test general algebra; they are not actual RW data or reached counterexamples.

~~~sh
python3 rw_field_modulus_check.py
cc -O2 -Wall -Wextra -o [local archival reference] rw_spare_check.c
[local archival reference]
cc -O2 -Wall -Wextra -o [local archival reference] rw_actual_kernel_check.c
[local archival reference]
~~~

At \(u=8,Q=262144\), the new run passed complete-Z all32 coefficient identities and all off-grid clearing checks in both pairs:

~~~text
pair0: cTop=101337 a0=108215 a5=43547
pair1: cTop=227940 a0=46629 a5=94886
~~~

The run took3.11 seconds and compiled without warnings. The large-\(u\) root bound is analytic; this smallest-field check does not prove it.

Fresh-context agent [same-model review role] independently derived(1)–(2) and checked(8)–(10), including the equal-scalar leading-coefficient case. It initially gave a norm-image statement for \(\eta=L_0(W)\), which applies only before the spare sum. After correction it agreed the complete-sum \(\eta=y^{2(u-1)}\) gives bad roots in \(X\). This scope correction is preserved rather than silently accepted. Both agents use the same model family; the review is not independent-model or full-source formal verification.

For the unified Commons contribution task, the minimal self-contained candidate is(1)–(2), with the RW consequence clearly marked conditional. It generalizes613.8 and exposes a restriction missing from the prior abstract example. Novelty is unverified. Original-source citations, human authorship/consent, AI-role disclosure, release permission, selected content/code licenses and external independent review remain for the coordinator. No publication action occurred here.
