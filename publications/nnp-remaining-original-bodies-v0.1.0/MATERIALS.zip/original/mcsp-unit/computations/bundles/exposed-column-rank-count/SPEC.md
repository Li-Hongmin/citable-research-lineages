# Exact exposed-column verification

Frozen before the first bearing computation, 2026-09-05.

## Decision and quantified object

For q=16, rho=3, E=(0,1), verify for **every** ordered normalized slope
v=(d1,d2,1), d1,d2 in GF(16)\{0}, (d1,d2)!=(1,1), and **every**
c in {(1,0),(0,1),(1,1)} that

    Pr[(H_X^T c)|F = 0] <= (3/4)^|F|.

This is 224 slopes and 672 cases. GF(16)=GF(2)[z]/(z^4+z+1), with integer
labels given by polynomial bits; addition is XOR. Multiplication is reduced
polynomial multiplication. Division is multiplication by the field inverse.
Normalizing an arbitrary nonzero-coordinate v by v3 preserves its line;
the omitted pair (1,1) is exactly the parallel direction. No permutation of
roles or field symmetry removes any of these 224 ordered cases.

The independent random arrays A=(X1,u) and B=(X2,u), u in GF(16), are uniform
in GF(2)^16. The output role Y=(X3,u) is NOT sampled: H is its coefficient
matrix. Define the matrix directly from the line sum, with all sums binary:

    H_X(a,x) = sum_{g != 0: a+g=x} A[a+d1*g] B[a+d2*g].

Thus H_X(a,a)=0; for x!=a it also equals
A[(1+d1)*a+d1*x] B[(1+d2)*a+d2*x]. E and F are field-label sets; ranks,
counts and probabilities have no physical units. Probabilities always have
denominator 2^(2q)=2^32 before reduction.

## Fixed exposed set

J={j in {1,2}: dj!=1}, s=|J|, t=2-s. For each j in J set
kappa_j=dj^(-1)*(1+dj). On GF(q) put an edge x--y if, for any DISTINCT
a,b in E and j in J, y=x+kappa_j*(a+b). Delete E. Greedily choose the
smallest remaining integer label, append it to F, and remove it and its
neighbors, until empty. This F is constructed before any role-array value
or relation is examined; it is used for all three c. This fixes one of the
independent sets allowed in note 917, not every possible independent set.
Check F subset GF(q)\E, independent, and
|F| >= floor((q-2)/(2s+1)) mechanically.

## Exact conditional count

For each of all 2^q arrays A, construct an |F|-by-q binary matrix D_A:

    D_A[x,u] = sum_{a in E} c_a * sum_{g!=0: a+g=x}
               A[a+d1*g] * 1[u=a+d2*g].

Compute r_A=rank_GF(2)(D_A) by binary elimination; all equations are
homogeneous. The exact number of B solutions is 2^(q-r_A). Count

    N = sum_{A in GF(2)^q} 2^(q-r_A).

Compare integers N*4^|F| <= 3^|F|*2^(2q), using exact arithmetic with
enough width (128-bit for products). No floating-point tolerance.
Record the complete histogram h_r=#{A:r_A=r}, so sum h_r=2^q and
N=sum h_r*2^(q-r) are independently inspectable.

## Independently constructed reference and decisive checks

The production D_A uses the original nonzero-g line sum above, not (917.15)
or the proposed bound. A separate constructor evaluates the affine formula
and checks all (a,x) indices for every normalized slope, including the zero
diagonal. Equality must be verified, not assumed.

For each exposed column independently, form the distinct role-labelled
variables from the original line sum and enumerate its at most four bits to
count the vanishing assignments. Mechanically check that different exposed
columns use disjoint role-labelled variables. Multiply these independently
obtained single-column fractions to obtain a reference probability. This
reference is not constructed from N, the rank histogram, or (3/4)^|F|.
The full conditional-rank count must equal this reference exactly.

A small q=4 full-input-pair enumeration, under this same parameterized driver
(modulus z^2+z+1), checks the elimination count against direct evaluation
for all 8 normalized slopes and 3 relations; this is verification of the
counting interface, not expansion of the research question.

## Output schema and stopping

Write JSON Lines, one completed case per record. Each case contains:
kind=case, q, modulus, slope, E, relation, s, t, exposed, conditional_arrays,
rank_histogram, zero_pairs, total_pairs, probability={numerator,denominator},
reference_probability={numerator,denominator}, bound={numerator,denominator},
verdict in {VALIDATED,COUNTEREXAMPLE,UNKNOWN}, and failure (null or explicit).

The final summary contains kind=summary, expected_slopes, expected_cases,
completed_slopes, evaluated_cases, validated_cases, counterexample_cases,
unknown_evaluated_cases, unresolved_remaining, missing_cases (explicit
slope/relation pairs), and verdict in {VALIDATED,COUNTEREXAMPLE,UNKNOWN}.
Unknown includes unfinished computation, failed construction checks, or a
disagreement between exact methods that has not been resolved. In a run
without a final summary all cases lacking a VALIDATED record remain UNKNOWN.
Never classify an unresolved case as exceptional or set unresolved_remaining
to zero if any case is uncomputed or has an UNKNOWN verdict.

Stop at the first counterexample or reference/interface discrepancy, preserve
the slope, relation, exact count and histogram, and repair only that interface.
On complete agreement promote the family once and combine the completed
theoretical results into a standalone combinatorial manuscript. The q=16
computation does not prove a theorem for larger fields or general row sets.

**Acceptance:** all 672 uniquely specified cases have exact rank counts,
agree with the independent reference, and satisfy the integer inequality;
otherwise retain a concrete counterexample or explicitly listed UNKNOWN cases.

## Resource bound and branch separation

Stream over arrays and cases on one CPU; no table of input pairs and no dense
2^q-by-2^q object. There are 672*65536=44,040,192 small eliminations, each
with at most 14 rows of 16 bits. Fixed-size arithmetic storage and case output
are well below 16 MiB; a compiled single-process run is expected to take
seconds to tens of seconds locally. If a timing sample instead indicates a
long/resource-intensive job, use the configured remote computation workflow.

why_disjoint: the controller constructs and evaluates these finite matrices;
the sole complementary agent only checks symbolic quotient/group-algebra
identities and existing density arguments for the prospective manuscript.
The agent produces no enumeration data and edits no permanent source.
