# Disposable derivation: subspace orbit envelopes

Let \(K\ne0\) have coordinate support projections \(S_j\subseteq\mathbb F_q\),
and let

\[
 D_\lambda(K)=\bigcup_j\lambda_j^{-1}
 ((S_j+S_j)\setminus\{0\}).
\]

For a uniformly random \(k\)-dimensional \(\mathbb F_2\)-subspace
\(H\le\mathbb F_q\),

\[
 \mathbb E |(H\setminus\{0\})\cap D_\lambda(K)|
 =|D_\lambda(K)|\frac{2^k-1}{q-1}.
\]

Consequently, if the right-hand side is \(<1\), some \(H\) has
\(H\cap D_\lambda(K)=\{0\}\). The translates
\(\tau_{a\lambda}K\), \(a\in H\), then have pairwise disjoint variable
sets in every role.

For every nonempty relation support \(A\subseteq H\), disjointness gives
\(K_A=\sum_{a\in A}\tau_{a\lambda}K\ne0\), while

\[
 \pi_j(\operatorname{supp}K_A)\subseteq S_j+\lambda_jA,
 \qquad
 \Delta\pi_j(\operatorname{supp}K_A)
 \subseteq \Delta S_j+\lambda_jH.
\]

Thus an envelope (W_j\supseteq\Delta S_j), (0\in W_j), updates by

\[
 W_j' = W_j+\lambda_jH,
 \qquad |W_j'|\le |W_j|\,|H|.
\]

This replaces the arbitrary-set estimate \(M^2s^2\) by a factor \(M\) on
the exact difference envelope. It does not make the growth additive. If
\(W_j\) is a subspace and \(H\cap\lambda_j^{-1}W_j=\{0\}\), then

\[
 |W_j+\lambda_jH|=|W_j|\,|H|,
\]

so multiplication is exact. Iterating gives an envelope cost \(M^{t-1}\),
not \(M^{2(t-1)}\). With \(M\gg\log t\), this still costs
\(t\log\log t\) bits and cannot by itself merge \(t=\Theta(n)\) factors at
fixed entropy slack.

The construction is in the actual group algebra and uses actual RS-line
directions; it is not a statement that an alternative non-orbit method
cannot do better.
