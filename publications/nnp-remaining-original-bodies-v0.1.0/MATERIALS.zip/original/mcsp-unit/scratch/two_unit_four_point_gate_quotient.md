# Two augmentation-one line units against a four-point gate

This is a scratch derivation for the parent task. Let \(W=\mathbb F_q^2\)
as an additive group, \(q=2^n\), and let
\[
H=\{0,a,b,a+b\}
\]
where \(a,b\) are \(\mathbb F_q\)-linearly independent. Set
\(K=\Omega_H\). For two (not necessarily distinct) \(\mathbb F_q\)-lines
\(M_i\le W\), sample \(A_i\) independently and uniformly from
\[
\mathcal U(M_i)=\{A\in\mathbb F_2[M_i]:\operatorname{aug}(A)=1\}.
\]

## Quotient reduction

Let \(Q=W/H\), let \(\pi:\mathbb F_2[W]\to\mathbb F_2[Q]\) be the induced
group-algebra map, and write \(S_i=\pi(M_i)\). Since distinct \(H\)-cosets
have disjoint group supports,
\[
K B=K\quad\Longleftrightarrow\quad \pi(B)=1_Q.
\tag{S.1}
\]
For \(e_i=\dim_{\mathbb F_2}(M_i\cap H)\in\{0,1\}\), one has
\[
|S_i|=q/2^{e_i}.
\tag{S.2}
\]
The image of a uniform \(A_i\in\mathcal U(M_i)\) is uniform on
\[
\mathcal U(S_i)=\{x\in\mathbb F_2[S_i]:\operatorname{aug}(x)=1\}.
\tag{S.3}
\]
Indeed, each \(S_i\)-coefficient is the parity of its fiber in \(M_i\);
the parity of all source coefficients equals the augmentation of the image,
and the kernel of the quotient map has augmentation zero. Thus the
restriction is onto and has equal-size fibers.

For any finite elementary-abelian 2-group \(S\), every element of
\(\mathcal U(S)\) is a unit and its inverse remains in \(\mathcal U(S)\).
Consequently, if \(M_1\ne M_2\), then
\[
x_1x_2=1_Q
\Longleftrightarrow
x_1\in \mathcal U(S_1)\cap\mathcal U(S_2)^{-1}
\Longleftrightarrow
x_1\in \mathcal U(S_1\cap S_2).
\tag{S.4}
\]
The last equivalence uses
\(\mathbb F_2[S_1]\cap\mathbb F_2[S_2]=\mathbb F_2[S_1\cap S_2]\).
Since \(M_1+M_2=W\), \(S_1+S_2=Q\), and hence
\[
|S_1\cap S_2|
=\frac{|S_1||S_2|}{|Q|}
=\frac{4}{2^{e_1+e_2}}.
\tag{S.5}
\]
Each \(\mathcal U(T)\) has \(2^{|T|-1}\) elements. Therefore, for distinct
lines,
\[
\boxed{
\Pr[K A_1A_2=K]
=2^{\,1+4/2^{e_1+e_2}-q/2^{e_1}-q/2^{e_2}}.
}
\tag{S.6}
\]
Here \(e_i=1\) exactly when \(M_i\) contains one of the three nonzero points
of \(H\), equivalently \(M_i\) is one of the three \(H\)-secant lines.

If \(M_1=M_2=M\), then \(S_1=S_2=S\), and \(x_1x_2=1\) has exactly
\(|\mathcal U(S)|\) pairs. Thus
\[
\boxed{
\Pr[K A_1A_2=K]=2^{\,1-q/2^{e}},
\qquad e=\dim_{\mathbb F_2}(M\cap H).
}
\tag{S.7}
\]

## Values for distinct lines

For ordered distinct \(M_1,M_2\), the possibilities are:
\[
\begin{array}{c|c|c}
(e_1,e_2)&|S_1\cap S_2|&\Pr[K A_1A_2=K]\\\hline
(0,0)&4&2^{5-2q}\\
(0,1)\text{ or }(1,0)&2&2^{3-3q/2}\\
(1,1)&1&2^{2-q}
\end{array}
\tag{S.8}
\]
The \((1,1)\) case is exactly the independent-event product
\(2^{1-q/2}\cdot2^{1-q/2}=2^{2-q}\); the other two cases are strictly
larger than the product lower bound by factors \(2\) and \(8\), respectively.
Thus independent line-unit survival events do not obey a product law in
general, although the quotient formula is exact.

## Exhaustive check

The companion script verify_two_unit_four_point_gate.py enumerates all
\(2^{q-1}\) source units on every line and all ordered line pairs. It gives:

* \(q=4\): all \(5^2=25\) ordered pairs exact;
* \(q=8\): all \(9^2=81\) ordered pairs exact.

The script uses \(H=\operatorname{span}_{\mathbb F_2}\{(1,0),(0,1)\}\).
The count is invariant under an \(\mathbb F_q\)-linear change of coordinates,
so this represents any \(H=\{0,a,b,a+b\}\) with \(a,b\) linearly independent
over \(\mathbb F_q\).

No orbit anti-concentration claim follows from (S.6); this is only the exact
coefficient fixed-point probability.
