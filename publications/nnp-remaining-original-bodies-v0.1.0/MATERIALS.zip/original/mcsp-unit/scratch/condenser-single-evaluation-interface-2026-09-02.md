# Lossless rank condensers do not directly uniformize Note 836

Search boundary: full-text check on 2026-09-02 of Forbes--Guruswami
arXiv:1411.7455, Guruswami--Xing--Yuan arXiv:1704.05992, Guo
arXiv:2105.02908, and Guo--Raj--Shangguan--Zhang arXiv:2604.13431.  This is
an exploratory interface record, not a numbered result.

## Exact target

Write \(q=2^m\) and identify
\(V=\mathbb F_q[T]_{\le C}\) with \(\mathbb F_2^{m(C+1)}\).  For each
\(x\in\mathbb F_q\), evaluation is the \(\mathbb F_2\)-linear map

\[
e_x:V\longrightarrow\mathbb F_q\cong\mathbb F_2^m,
\qquad f\longmapsto f(x).
\]

The required schedule is a family of exactly these maps such that every
binary subspace \(H\le V\) of dimension at most \(C\) has
\(\operatorname{rank}(e_x|_H)=\dim H\) for some selected \(x\).  Thus it is a
rank disperser with ambient dimension \(k=m(C+1)\), target dimension \(t=m\),
rank bound \(r=C\), *plus the nonstandard restriction that every seed matrix
is a single-point evaluation matrix*.  The desired number of seeds is
\(\Theta(C^2)\), with polylogarithmic-in-\(L\) uniform generation.

## What the cited theorems actually give

1. Forbes--Guruswami, Definition 2.4 and Proposition 6.1 (PDF pp. 5--6),
   define condensers as arbitrary matrices \(E\in F^{t\times n}\) and identify
   their kernels with subspace designs.  This equivalence preserves only
   linear-algebraic incidence, not the evaluation form \(E=e_x\).

2. Their Construction 2.7 and Theorem 2.8 (PDF pp. 7--8) use the folded
   Wronskian
   \[
   f\mapsto(f(\alpha),f(\omega\alpha),\ldots,
   f(\omega^{t-1}\alpha)),
   \]
   over a field containing an element \(\omega\) of multiplicative order at
   least the ambient polynomial dimension.  For rank \(r\), the theorem
   requires \(t\ge r\).  It is therefore a folded multi-point map, not
   \(f\mapsto f(x)\).  Over base field \(\mathbb F_2\), the required large-order
   element does not exist.  Passing to \(\mathbb F_{2^m}\) does not repair the
   interface: Note 836 quantifies over \(\mathbb F_2\)-subspaces, which need
   not be \(\mathbb F_{2^m}\)-linear sources.

3. Guruswami--Xing--Yuan Theorem 1.2 (PDF p. 3) does work over every base
   field, including \(\mathbb F_2\), but constructs high-dimensional kernels.
   In its construction (equation (20), Theorem 3.6, PDF pp. 13--14),
   \(H_P\) is the simultaneous kernel of evaluations at an automorphism orbit
   \(P,P^{\sigma^{-1}},\ldots,P^{\sigma^{-(t-1)}}\).  Again the dual map is
   folded/multi-point evaluation, not a single field-point evaluation.

4. Guo Lemma 2.4 and Corollary 2.5 (PDF p. 11) use the same symbolic
   Wronskian matrix \(W(\alpha)_{ij}=(\omega^{i-1}\alpha)^{j-1}\).  These are
   arbitrary/folded rank-extractor matrices; the construction assumes
   \(\omega\) has order at least the ambient dimension and does not produce
   the family \(\{e_x\}\).

5. Guo--Raj--Shangguan--Zhang Definition 1.1 (PDF p. 2) likewise permits
   arbitrary matrices.  Theorem 4.5 (PDF p. 23) gives small-field extractors
   by evaluating a matrix of function-field functions \(E_{ij}\) at rational
   places.  The definitions of that matrix in Sections 3 and 4 (PDF pp.
   18, 20) show that its rows and columns contain distinct auxiliary
   functions; it is not the coefficient-to-value matrix of one univariate
   polynomial at one \(x\).  Theorem 5.8 (PDF p. 28) reaches every finite
   field, including \(\mathbb F_2\), only as a rank disperser of size
   \[
   O\!\left(\max\{c\log(2r)/\log q,2\}^{r}\,r(k-r)q\right).
   \]
   At \(q=2\), \(k=m(C+1)\), \(r=C\), this is exponential in \(C\), not
   \(\Theta(C^2)\), and the matrices remain unrestricted.  Remark 2.16 states
   polynomial-time construction of the needed function-field operations, but
   that does not imply the required special-form or seed bound.

## Conclusion and reduction boundary

None of the four cited constructions can be instantiated directly as the
Note-836 schedule.  This is not a nonexistence theorem for explicit schedules:
the strict conclusion is that the standard condenser/subspace-design
guarantees forget the decisive algebraic restriction on the seed maps.

Any black-box use of an arbitrary binary condenser would need an additional
structure-preserving reduction proving that every selected matrix
\(E:\mathbb F_2^{m(C+1)}\to\mathbb F_2^m\) can be replaced by one (or a
controlled number) of matrices of the form

\[
[I\; M_x\; M_x^2\;\cdots\;M_x^C],
\]

where \(M_x\) is multiplication by \(x\) in \(\mathbb F_{2^m}\), while
preserving injectivity on every relevant source.  No such reduction appears
in the checked theorems.  The thinnest unresolved interface is therefore not
base-field availability or algorithmic explicitness, but **single-point
Vandermonde evaluation structure**.  Existing results supply only a lead for
the unrestricted-matrix relaxation.
