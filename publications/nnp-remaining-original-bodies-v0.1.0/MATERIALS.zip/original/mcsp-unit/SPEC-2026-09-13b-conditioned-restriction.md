# SPEC-2026-09-13b — 条件化限制下的硬性保持与复合门收缩（run-to-verdict，冻结）

来源：SPEC-candidates/20260913c-conditioned-restriction-hardness.md 及其 probe（GO，2026-09-13）。前一 SPEC（SPEC-2026-09-13-magnification.md）已 BUDGET 终态（note 927）。本 SPEC 为第二次运行，冻结后不改。

## 主陈述
记 n=2^N，L=MCSP[N²]，A 为 YES 集，B=A∖{0}。D：x 均匀于 B；独立地把 n 个坐标分为 m=Θ(N) 个非空块，每块均匀留一位（集合 T），其余固定为 x。
主陈述：在 D 下同时成立
(a) 硬性：Pr[L|_ρ 非常数] ≥ 1/2（已证，probe L1，边等周不等式推论）且非常数的 L|_ρ 以概率 ≥ n^{−O(1)} 需要 ≥ 2^{Ω(m)} 门的（深度 2 阈值 / DNF，取最弱可用）电路；
(b) 收缩：对 CJW 2019 实际 good hash M_v，复合底层门 H(M_v(x),v,i,块_i) 在 ρ~D 下以概率 1−o(1) 化为文字或常数。
若 (a)(b) 同时成立 ⇒ KW 计数论证经 D 移植给出 L∉TC_{r+5}[n^{5/4}] ⇒ ∀k NP⊄TC₂[n^k]。
若不可同时成立 ⇒ 写出「条件化 locality barrier」：任何满足 (a) 的分块条件分布使复合门保持非平凡的定量下界（存活行占比）。

## 路线（≤3）
R1 (a) 后半（硬性）：证明非常数切片的 2^{Ω(m)} 电路下界（弱模型任选，须写明）。第一观测：切片 L|_ρ 是 m 变量函数，其 YES 点集是 A 与子立方体的交；判定它是否以多项式概率含 ≥2^{m/2} 个「相互远离」的 YES/NO 点对（DNF 下界的标准充分条件）。GO：下界成立；NOGO：切片以 1−n^{−ω(1)} 概率为「几乎常数」（≤ poly(m) 个异类点）。
R2 (b)：对实际 M_v（CJW §4.1 编码）在 D 下计算行存活支持分布；第一观测：有限 N（N≤6）精确 + 一般 N 的渐近证明，判定存活支持 ≥2 的行占比是否 → 0。GO：→0 且复合门收缩；NOGO：占比有常数下界且可被 oracle 利用。
R3 若 R1 或 R2 NOGO：写「条件化 locality barrier」精确陈述（分布类、oracle 层位置、扇入、总线数）作为有范围关闭。

## 预算
5 个脉冲或 7 天，先到为准。到达即写终态报告。

## 禁区
不做 serialization/Easy Witness/general compiler；不回 canonical-prefix/batch-count；不自行发明放大定理；不把有限 N 表当渐近证明；不把大扇入 PARITY 当实际哈希；不重复 note 927 与 probe L1 已证结果；不投稿。
