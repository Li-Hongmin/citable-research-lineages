# Truth-Table Quotients Do Not Close One-Tape MCSP Magnification: Small Fibers and Exact Cosets

## Abstract

We ask whether an encoding of Boolean truth tables can transfer the unconditional one-tape
MCSP lower bounds above threshold exponent \(1/2\) to the small threshold at which the
McKay--Murray--Williams magnification theorem would imply \(P\ne NP\). We prove a
fiber-corrected counting barrier. Lupanov's upper bound on fixed-variable juntas, combined with
circuit enumeration, gives the sharp semantic-entropy profile
\(\log_2|\mathcal L_S|=\Theta(\min\{2^n,S\log S\})\). If a map sends \(n\)-variable truth tables to
\(n'=\kappa n+O(1)\) variables and maps every circuit of size at most \(2^{\mu_Hn}\) to one of
size at most \(2^{\mu_1n'}\), then \(\mu_H>\kappa\mu_1\) forces one target value to identify
\(2^{\Theta(n2^{\mu_Hn})}\) low-complexity source functions. Consequently the
Cheraghchi--Hirahara--Myrisiotis--Yoshida time window cannot reach the required
\((2^{n'})^{1.01}\) scale through any injective map or any quotient with
\(\log F=o(n2^{\mu_Hn})\), even if composition with the map is free.

This barrier contains dummy-variable padding, every lossless truth-table encoding with an
advice-free exact decoder, and canonicalization by any \(2^{\operatorname{poly}(n)}\)-size
symmetry family. An affine quotient in the bridging regime must have kernel dimension
\(\Omega(n2^{\mu_Hn})\). More sharply, Harper's vertex-isoperimetric theorem shows that every
fixed center in every source-YES fiber of the required size has all but a
\(2^{-\Omega(nT)}\) fraction of its partners at XOR complexity
\(2^{\mu_Hn}-O(n2^{\kappa\mu_1n})=(1-o(1))2^{\mu_Hn}\); every maximum source-YES fiber
qualifies. Multi-step Harper growth also gives the intrinsic additive expansion
\(\log_2(|\mathcal L_S+\mathcal L_S|/|\mathcal L_S|)
\ge((1-\mu_H)/2-o(1))S\). An exact coset quotient compressed to the target threshold would
instead make this logarithmic doubling at most \(\log_2\Phi(n',T)=O(nT)=o(S)\). Hence no exact
affine, or more generally exact coset-fiber, quotient bridges the fixed exponents. For any
quotient whose YES-image fits inside the target low-complexity set, we prove a complementary
dichotomy: either the unordered-pair average number of target XOR-images is
\(2^{\Omega(S)}\), or the occupied-fiber average on
\(\mathcal L_S+\mathcal L_S\) is \(2^{\Omega(S)}\) larger than the average source-YES fiber;
the half-exponent split between these factors is sharp.
The exact decision-bit map realizes the second alternative, so excluding all remaining maps must
charge their computation rather than fiber cardinality alone. Conditional on an actual CHMY-model
composition, a materializer of exponent \(b\) and target algorithm of exponent \(a\) reach the
source lower bound exactly when \(\max\{b,\kappa a\}<2\mu_H\); MMW and CHMY do not themselves
supply this quotient-composition interface. Proposition 9 gives a concrete branch-forcing exact
quotient for which every fresh-output materializer satisfies
\(\max\{b,k\}\ge2\mu_H\); this is map-specific and does not lower-bound all predicate-specific
quotients. Under an explicit synchronous prefix-state model and local-PRG interface, Proposition
10 gives the joint boundary-state barrier
\(\log W_Q+\log W_D=\widetilde{\Omega}(S)\), without attributing it to the quotient alone. A
Corollary 11 converts any \(\ell\)-bit description bound on \(Q(A+A)\) into an explicit
\(\left((1-\mu_H)/2-o(1)\right)S-\ell\) occupancy lower bound. A junta subspace can still
supply a gap-stable fiber of the required dimension, but under a sub-doubling gap its uniformly
low kernel violates the target-side tail bound. Under delayed output, Corollary 12 upgrades this to a joint
state--occupancy inequality \(\log W_Q+\log\mathsf I_Q^{\mathrm{av}}\ge
((1-\mu_H)/2-o(1))S\), while streaming copiers remain outside its scope.
Corollary 13 charges an early-output budget \(r\) explicitly:
\(\log W_Q+r+1+\log\mathsf I_Q^{\mathrm{av}}\ge((1-\mu_H)/2-o(1))S\).
Corollary 14 converts this into a one-tape time--space--occupancy inequality under a fixed
alphabet, while remaining weaker than the full CHMY exponent.
Corollary 15 isolates the resulting sub-\(S\) resource dichotomy when occupancy inflation is
small.
Corollary 16 identifies its exponent boundary \(b\ge\mu_H\), leaving the
\(\mu_H\le b<2\mu_H\) band explicit.
Corollary 17 shows that an evaluable short descriptor closes that band whenever
\(\max\{b,\kappa c,\kappa a\}<2\mu_H\).
Corollary 18 adds the complementary range obstruction: unless occupancy inflation is already
large, \(Q(A+A)\) contains exponentially many target-NO outputs.
Corollary 19 makes the information content explicit: every deterministic descriptor image
covering those target-NO outputs has length at least the same exponent, while an enumerator that
outputs all of them pays the corresponding output-volume time. A single descriptor evaluation
does not inherit this multiplicity lower bound.
Corollary 20 gives an exact range--occupancy factorization for every pointwise-exact quotient,
sharp at the two-label predicate map. Proposition 21 gives the unconditional quadratic
multi-tape-to-one-tape composition boundary \(\max\{b,\kappa a\}\ge\mu_H\), while the
near-additive \(2\mu_H\) boundary still requires an explicit handoff interface. Corollary 22
shows that a single oracle descriptor of length \(N^{\delta+o(1)}\) obeys
\(\max\{1,b\}+2\delta\ge2\mu_H\).
Corollary 23 removes the single-query restriction: an adaptive oracle transcript with maximum
query length \(N^{\delta+o(1)}\) obeys the same boundary, regardless of the number of queries.
Static random-access evaluators are covered exactly when their descriptor is membership-sufficient
for one fixed oracle relation; Proposition 27 extends the source-probe conclusion to interactive
target queries and charged multi-bit source answers, while evaluators that read the source table or
an uncharged RAM are not. Proposition 28 adds a conditional charged-payload boundary for
asynchronous handoff, and Proposition 29 extends it to arbitrary interleaving of the source scan,
target control, and complete counted payload. Proposition 31 then charges any remaining causally
generated hidden continuation channel through its residual class complexity \(R\). Proposition 32
turns this semantic term into a finite-machine state term, provided all irreversible hidden output
is explicitly charged. Proposition 33 specializes the earlier interface to the unconditional
strong-local PRG of Cheraghchi--Kabanets--Lu--Myrisiotis and gives a weaker logarithmic
residual-width boundary without assuming an \(S\)-scale output-local PRG.
Proposition 34 closes the affine-residual shortcut: affine residuals have too little support on
long suffixes, and large affine YES subspaces do not yield a lower bound for the full MCSP set.
Proposition 38 gives an unconditional middle-cut equality-gadget lower bound
\(W_{N/2}\ge |H|^2/(2|\mathcal L_S|+|H|)\), reducing an \(S\)-scale residual barrier to an
explicit half-table versus full-table entropy comparison.
Propositions 39--40 close a tempting shortcut: a product-fiber language has exponential
XOR expansion but only two middle-cut residuals, so Harper growth cannot by itself produce
cross-NO width.  Such an inference requires an explicit splice-to-XOR circuit reduction,
which is absent for a generic truth-table cut.
Propositions 41--42 sharpen the equality route: a selector-lift replaces the full denominator
by the \((r+1)\)-variable entropy \(|\mathcal L_{r+1,S}|\), while every fixed multiblock
diagonal has only a subexponential pattern factor and an \(S/2\)-circuit core whose mixed tables
are all easy.  Proposition 43 then gives a canonical tree--pin encoding with
\(\log_2|\mathcal L_{m,S}|\le S\log_2S+O(S)\), and Proposition 44 constructs a matching
packed-selector Lupanov family.  Theorem 45 first determines the lexicographic middle-cut width.
A balanced-cut Fourier quotient then shows that every half-set of truth-table coordinates has a
large easy family recoverable from both sides.  Its mixed-pair independent set is in fact an
identity submatrix of order \(2^{S\log S-O(S\log\log S)}\).  Consequently Theorem 47 gives, for
every fixed \(0<\mu<1\) and every global order \(\pi\),
\(\log_2W^\pi_{N/2}(\mathrm{MCSP}_{2^{\mu n}})
=(1+o(1))2^{\mu n}\mu n\) not only for deterministic OBDDs, but also for strictly layered
nondeterministic and parity OBDDs and exact field-weighted ordered algebraic programs.  Boolean
rectangle cover and field rank use the same witness.  This does not extend to path-dependent
1-NBPs, co-nondeterministic, general, bounded-error, or one-tape branching computation.  An
expander matching-selector language makes this failure sharp: it has a linear-size deterministic
FBDD although every balanced coordinate cut contains an identity submatrix of order
\(2^{\Omega(N)}\).  A single self-indexed witness valid at every balanced cut cannot repair the
quantifiers: a Plotkin argument bounds its order by \(N/2+1\), and the current Fourier multi-cut
union bound has no parameter overlap with the useful BRS decomposition regime.  Moreover, the
canonical packed-selector witness itself has an \(O(S\log S)\)-space, \(O(n)\)-update online
encoder, so its state cardinality alone cannot charge MMW update time.
Proposition 54 then removes a separate canonicality artifact: the MMW streaming induction needs
only an arbitrary consistent size-\(S\) circuit and an explicit failure symbol. Code-prefix
extension is a \(\Sigma_2^P\) predicate and adaptive canonical merge lies in
\(FP^{\Sigma_2^P}\); the direct raw-table one-call embedding reaches a near-Shannon search-MCSP
slice. Fixed adjacent blocks are exactly one contiguous-prefix partial-MCSP instance. Decision
hardness only asks whether its extension set is nonempty; binding every returned circuit is a
separate requirement for Levin/search recovery.
Propositions 48--50 make the last separation sharp: a time-\(T\)
one-tape machine gives only \(\log W=O(T)\), and a uniform linear-time storage language already
has \(2^{\Omega(N)}\) canonical width.  The new MCSP OBDD theorem therefore yields no
superlinear one-tape time bound without an MCSP-specific state-compression principle.
For a natural non-dummy tensor family, two-sided promise preservation
forces \(\mu_H=\kappa\mu_1\). Gaps at least two and arbitrary predicate-specific quotients with
non-coset fibers remain open. The result does not prove \(P\ne NP\).

## 1. Setup

Let
\[
 L_{\mu,n}
 =\{f:\{0,1\}^n\to\{0,1\}:\operatorname{CC}(f)\le\lfloor2^{\mu n}\rfloor\},
 \qquad N=2^n.
 \tag{1}
\]
The fixed Cheraghchi--Hirahara--Myrisiotis--Yoshida--McKay--Murray--Williams endpoint
supplies a non-numerically specified constant \(\mu_*>0\) such that
\[
 L_{\mu_*}\notin\operatorname{DTIME}_1[N^{1.01}]
 \quad\Longrightarrow\quad P\ne NP.
 \tag{2}
\]
Here \(\operatorname{DTIME}_1[t]\) is the CHMY model: a deterministic \(O(1)\)-state
Turing machine with one one-way read-only input tape and one initially blank two-way
read/write work tape, running in \(O(t(N))\) steps on the canonical \(N\)-bit truth table.

The constant can be fixed directly from the published argument.  Under \(P=NP\), MMW
Theorem 1.3 and CHMY Lemma 9 give a fixed polynomial \(q\) such that, for every admissible
time-constructible \(s\),
\[
 \operatorname{MCSP}[s]\in\operatorname{DTIME}_1[Nq(s)].
 \tag{2a}
\]
Choose \(C,d\ge1\) with \(q(t)\le Ct^d\), and then fix
\[
 0<\mu_*<\min\{\tfrac14,0.01/d\}.
 \tag{3}
\]
For \(s(n)=\lfloor2^{\mu_*n}\rfloor\), equation (2a) runs in
\(O(N^{1+d\mu_*})=O(N^{1.01})\).  Hard-wiring the finitely many exceptional lengths and
taking the contrapositive gives (2).  Thus \(\mu_*\) is fixed only existentially; no numerical
value is claimed.

In the parameterized structural statements below, \(\mu_1\) denotes a free target-threshold
exponent.  Whenever the magnification endpoint (2) is invoked, it is specialized to
\(\mu_1=\mu_*\).

The Cheraghchi--Hirahara--Myrisiotis--Yoshida lower-bound regime applies above threshold
exponent \(1/2\). We test whether a truth-table encoding can bridge the two regimes.

## 2. Fiber-corrected threshold conservation

We use the CHMY circuit convention on both sides: bounded fan-in, unbounded fan-out, basis
\(\{\mathsf{AND},\mathsf{OR},\mathsf{NOT}\}\), and size equal to the number of gates, including
NOT gates. In particular, output complementation can change the size by one and is not assumed
to preserve an exact threshold. The next counting bound does not assume that the map is
efficient, local, linear, or systematic.

### Theorem 1 (sharp semantic entropy and fiber-corrected barrier)

Let \(S=S(n)\) and \(T=T(n)\), where \(n^2\le S\le2^{n-2}\), and let

\[
 Q_n:\{0,1\}^{2^n}\longrightarrow\{0,1\}^{2^{n'}}
\tag{3a}
\]

be arbitrary. If

\[
 \operatorname{CC}(f)\le S
 \quad\Longrightarrow\quad
 \operatorname{CC}(Q_n(f))\le T
 \qquad\text{for every }f:\{0,1\}^n\to\{0,1\},
\tag{3b}
\]

and

\[
 F=\max_y
 \bigl|\{f:\operatorname{CC}(f)\le S,\ Q_n(f)=y\}\bigr|,
\tag{3c}
\]

then there are constants \(c,C>0\), depending only on the circuit basis, such that for all
sufficiently large \(n\),

\[
 c\min\{2^n,S\log_2S\}
 \le \log_2|\mathcal L_S|
 \le C\min\{2^n,S\log_2S\},
 \qquad
 \mathcal L_S=\{f:\operatorname{CC}(f)\le S\},
\]

and

\[
 \boxed{
 c\min\{2^n,S\log_2S\}-\log_2F
 \le C(T+1)\log_2(n'+T+2).
 }
\tag{3d}
\]

In particular, fix \(0<\mu_1,\mu_H<1\) and \(\kappa>0\). If
\(n'=\kappa n+O(1)\), \(S=\lfloor2^{\mu_Hn}\rfloor\), and
\(T=\lfloor2^{\mu_1n'}\rfloor\), then \(\mu_H>\kappa\mu_1\) forces

\[
 \boxed{
 F=
 2^{\Theta(n2^{\mu_Hn})}.
 }
\tag{3e}
\]

#### Proof

The Lupanov upper bound gives a basis-dependent constant \(A>0\) such that every Boolean
function on \(r\) variables has circuit complexity at most

\[
 A\frac{2^r}{r}
\tag{3f}
\]

for every sufficiently large \(r\). A convention in which constants are not free changes this
bound by only \(O(1)\) gates.

Let \(q=\lfloor\log_2S\rfloor\). The assumptions on \(S\) give \(q\le n-2\), \(q\to\infty\),
and \(A2^q/q\le S\) for all sufficiently large \(n\). Choose the largest
\(r\in\{q,\ldots,n\}\) such that (3f) is at most \(S\). If \(r=n\), every \(n\)-variable
function lies in \(\mathcal L_S\). If \(r<n\), maximality gives

\[
 A\frac{2^{r+1}}{r+1}>S,
 \qquad\text{hence}\qquad
 2^r>\frac{S(r+1)}{2A}
 \ge \frac{S\log_2S}{4A}.
\]

In both cases,

\[
 2^r=\Omega\!\left(\min\{2^n,S\log_2S\}\right).
\]

All \(2^{2^r}\) functions on the first \(r\) variables, extended constantly in the remaining
variables, belong to \(\mathcal L_S\). This proves the semantic-entropy lower bound.

A topologically ordered circuit with at most \(U\) gates on \(m\) inputs has, at each gate, a
constant number of choices for its type and at most \((m+U+2)^2\) choices for its predecessors.
Including the output and all smaller sizes, the number of functions of circuit complexity at
most \(U\) is at most

\[
 2^{O((U+1)\log(m+U+2))}.
\tag{3g}
\]

Applying (3g) with \((m,U)=(n,S)\), and using \(S\ge n^2\) together with the trivial bound
\(\log_2|\mathcal L_S|\le2^n\), proves the matching semantic-entropy upper bound. The image
of \(\mathcal L_S\) contains at least \(|\mathcal L_S|/F\) distinct functions, all lying in the
target class counted by (3g) with \((m,U)=(n',T)\). This proves (3d).

For the fixed-exponent parameters, \(\min\{2^n,S\log S\}=\Theta(n2^{\mu_Hn})\), whereas

\[
 (T+1)\log(n'+T+2)
 =O(n2^{\kappa\mu_1n})
 =o(n2^{\mu_Hn}).
\]

Thus (3d) gives the lower bound in (3e), and
\(F\le|\mathcal L_S|=2^{O(n2^{\mu_Hn})}\) gives the matching upper bound. \(\square\)

The theorem uses only the YES direction of an MCSP promise reduction. For injective maps,
\(F=1\), and (3d) recovers \(\mu_H\le\kappa\mu_1\). More generally, the same conclusion holds
whenever

\[
 \log_2F=o(n2^{\mu_Hn}).
\tag{3h}
\]

This includes every advice-free exact encoding and every quotient whose source-low fibers have
size at most \(2^{\operatorname{poly}(n)}\).

### Corollary 2 (the one-tape window is empty)

Suppose a map with \(n'=\kappa n+O(1)\) preserves the YES side from
\(L_{\mu_H,n}\) to \(L_{\mu_1,n'}\), where \(\mu_H>1/2\), \(0<\mu_1<1/4\), and its
low-complexity fibers satisfy (3h). Even if a target one-tape computation can be composed with
the map at zero additional exponent cost, the CHMY lower bound cannot exclude a target running
time \((2^{n'})^{1.01}\).  For the magnification conclusion, specialize the free target
exponent to \(\mu_1=\mu_*\).

Indeed, such a composition would run on the source table in time
\(2^{(1.01\kappa+o(1))n}\), while CHMY can exclude it only if

\[
 1.01\kappa<2\mu_H.
\tag{3i}
\]

Theorem 1 instead gives

\[
 2\mu_H\le2\kappa\mu_1<\frac\kappa2<1.01\kappa.
\tag{3j}
\]

Thus the required parameter interval is empty before any strict one-tape simulation overhead is
charged. \(\square\)

### Corollary 3 (symmetry and affine quotients)

Canonicalization that identifies only functions in a common orbit of a transformation family
\(\mathcal G_n\) has \(F\le|\mathcal G_n|\). Hence no symmetry family of size
\(2^{\operatorname{poly}(n)}\), including input permutations, input negations, affine changes
of variables, and output complementation when allowed by the circuit convention, can bridge the
threshold exponents.

If \(Q_n(f)=A_nf+b_n\) is affine over \(\mathbb F_2\) and
\(d_n=\dim\ker A_n\), then \(F\le2^{d_n}\). In the regime
\(\mu_H>\kappa\mu_1\), Theorem 1 therefore requires

\[
 \boxed{d_n=\Omega(n2^{\mu_Hn}).}
\tag{3k}
\]

If the two sides of the source MCSP promise are constant on every fiber, and
\(\mathcal L_S=\{f:\operatorname{CC}(f)\le S\}\), then necessarily

\[
 \ker A_n\le
 \operatorname{Stab}(\mathcal L_S)
 :=\{h:\mathcal L_S+h=\mathcal L_S\}.
\tag{3l}
\]

Indeed, the fibers are cosets of \(\ker A_n\), so fiber-monochromaticity is precisely invariance
of \(\mathcal L_S\) under this kernel. Equations (3k)--(3l) are necessary, not sufficient. The
zero fiber alone does not yield a contradiction. The Lupanov junta construction in Theorem 1,
together with its matching entropy upper bound, gives

\[
 \max\{\dim K:K\le\mathbb F_2^{2^n},\ K\subseteq\mathcal L_S\}
 =\Theta\!\left(\min\{2^n,S\log S\}\right).
\]

Because the zero function belongs to \(\mathcal L_S\), its stabilizer is itself contained in
\(\mathcal L_S\). Thus an exact affine bridge in the fixed-exponent regime would require a
stabilizer subspace of the largest possible order \(\Theta(S\log S)\), while its quotient
outputs would still have to remain below the target circuit threshold.

The phrase *in the bridging regime* is essential here. There is no uniform bound
\[
 \dim\operatorname{Stab}(\mathcal L_S)
 =o\!\left(\min\{2^n,S\log S\}\right)
\]
throughout the entire range of Theorem 1.
Indeed, the Lupanov upper bound gives

\[
 \max_f\operatorname{CC}(f)
 \le (1+o(1))\frac{2^n}{n}+O(n).
\tag{3l.1}
\]

Thus, for all sufficiently large \(n\), taking \(S=2^{n-2}\) makes \(\mathcal L_S\) the whole
truth-table space and

\[
 \dim\operatorname{Stab}(\mathcal L_S)=2^n
 =\Theta\!\left(\min\{2^n,S\log S\}\right).
\tag{3l.2}
\]

The open case relevant to (3k) is instead
\(S=\lfloor2^{\mu n}\rfloor\) for a fixed \(0<\mu<1\), far below this saturation threshold.

There is an exact spectral formulation of that open case. For
\(V=\mathbb F_2^{2^n}\), let \(\widehat{1_{\mathcal L_S}}\) denote the unnormalized Fourier
transform on \(V\). Translation invariance gives

\[
 \operatorname{Stab}(\mathcal L_S)
 =\bigl(\operatorname{span}_{\mathbb F_2}
   \operatorname{Supp}\widehat{1_{\mathcal L_S}}\bigr)^\perp.
\tag{3l.3}
\]

Consequently the desired bridging-regime estimate is equivalent to

\[
 \operatorname{rank}_{\mathbb F_2}
 \operatorname{Supp}\widehat{1_{\mathcal L_S}}
 =2^n-o\!\left(\min\{2^n,S\log S\}\right).
\tag{3l.4}
\]

Also, \(\mathcal L_S\) is a union of stabilizer cosets, so

\[
 2^{\dim\operatorname{Stab}(\mathcal L_S)}\mid |\mathcal L_S|,
 \qquad
 \dim\operatorname{Stab}(\mathcal L_S)\le\nu_2(|\mathcal L_S|).
\tag{3l.5}
\]

Ordinary circuit enumeration bounds \(|\mathcal L_S|\), but not its 2-adic valuation or the
rank in (3l.4), and therefore does not determine the stabilizer itself. Proposition 6 below
nevertheless rules out the exact affine bridge by a different invariant: multi-step additive
expansion.

### Proposition 4 (constant-factor gaps admit large stable fibers)

For thresholds \(S_0<S_1\), let \(c_\oplus\) be the constant cost of XOR over the fixed basis
(one may take \(c_\oplus=4\)), and write

\[
 \mathcal L_{S_0}=\{f:\operatorname{CC}(f)\le S_0\},
 \qquad
 \mathcal H_{S_1}=\{f:\operatorname{CC}(f)>S_1\},
 \qquad
 B=\min\{S_0,S_1-S_0-c_\oplus\}.
\tag{3l.6}
\]

If \(n^2\le B\le S_0\le2^{n-2}\), there is a linear \(K\le V\) such that

\[
 K\subseteq\mathcal L_{S_0},
 \qquad
 w(K):=\max_{k\in K}\operatorname{CC}(k)\le B,
 \qquad
 \dim K=\Theta\!\left(\min\{2^n,B\log B\}\right).
\tag{3l.7}
\]

For this \(K\),

\[
 \mathcal L_{S_0}+K\subseteq\mathcal L_{S_1},
 \qquad
 (\mathcal H_{S_1}+K)\cap\mathcal L_{S_0}=\varnothing.
\tag{3l.8}
\]

The dimension scale in (3l.7) is optimal up to constants among all linear spaces with
\(w(K)\le B\). In particular, if \(S_1-S_0\ge\rho S_0\) for a fixed \(\rho>0\), then

\[
 \dim K
 =\Theta_\rho\!\left(\min\{2^n,S_0\log S_0\}\right).
\tag{3l.9}
\]

#### Proof

Let \(K\) be the subspace of all functions depending only on the first \(r\) variables, with
\(r\) chosen by the Lupanov construction in Theorem 1 using budget \(B\). Then
\(K\subseteq\mathcal L_B\subseteq\mathcal L_{S_0}\), \(w(K)\le B\), and
\(\dim K=2^r=\Theta(\min\{2^n,B\log B\})\), proving (3l.7).

For every \(f\) and \(k\), XOR gives

\[
 \operatorname{CC}(f+k)
 \le\operatorname{CC}(f)+\operatorname{CC}(k)+c_\oplus.
\tag{3l.10}
\]

By the definition of \(B\), equations (3l.7) and (3l.10) give the first inclusion in (3l.8).
The second is equivalent to the first: if \(h=f+k\) with \(k\in K\), then also \(f=h+k\).

\[
 2^{\dim K}\le|\mathcal L_B|
 \le2^{O(\min\{2^n,B\log B\})}
\tag{3l.11}
\]

for every linear \(K\) with \(w(K)\le B\), by Theorem 1. This proves optimality. Under the
fixed-factor gap, \(B=\Theta_\rho(S_0)\), which gives (3l.9). \(\square\)

For the quotient by this \(K\), the zero fiber contains exactly \(2^{\dim K}\) low-complexity
functions. Under a fixed-factor gap, its
\(\log_2F=\Theta_\rho(\min\{2^n,S_0\log S_0\})\) term is on the same asymptotic scale as the
sharp source entropy in (3d), invalidating any little-\(o\) fiber hypothesis at the level of
orders. This does not determine the leading constant and does not construct a quotient satisfying
\(Q(\mathcal L_{S_0})\subseteq\mathcal L_T\), nor a one-tape implementation of such a map.
Even if those interfaces were supplied, a solver for the promise separating
\(\mathcal L_{S_0}\) from \(\mathcal H_{S_1}\) need not decide the gray region
\(S_0<\operatorname{CC}(f)\le S_1\); the exact CHMY lower bound therefore does not rule it out.

### Proposition 5 (Harper growth and almost-everywhere XOR-dispersed fibers)

Write

\[
 \Phi(n,t)=|\mathcal L_t|,
 \qquad N=2^n,
 \qquad \ell_n=2n+3.
\tag{3l.12}
\]

Fix \(0<\mu<1\). There is a constant \(C_\mu\) such that, for all sufficiently large \(n\),
uniformly for every integer \(0\le t\le2^{\mu n}\),

\[
 \boxed{
 \log_2\Phi(n,t+\ell_n)-\log_2\Phi(n,t)
 \ge n-\log_2(t+1)-C_\mu
 \ge(1-\mu)n-C_\mu.
 }
\tag{3l.13}
\]

Consequently, if \(B\le S\le2^{\mu n}\), then

\[
 \boxed{
 \log_2\Phi(n,S)-\log_2\Phi(n,B)
 \ge
 \left\lfloor\frac{S-B}{2n+3}\right\rfloor
 \bigl((1-\mu)n-C_\mu\bigr).
 }
\tag{3l.14}
\]

Now let \(Q\) be an arbitrary map from \(n\)-variable to \(n'\)-variable truth tables satisfying

\[
 Q(\mathcal L_S)\subseteq\mathcal L_{n',T}.
\]

For every nonempty source-YES fiber, set

\[
 Y_y=Q^{-1}(y)\cap\mathcal L_S,
 \qquad
 D(y)=\max_{f,g\in Y_y}\operatorname{CC}(f\oplus g).
\tag{3l.15}
\]

Every fiber satisfying

\[
 |Y_y|\ge\frac{\Phi(n,S)}{\Phi(n',T)}
\tag{3l.16}
\]

obeys

\[
 \boxed{
 \left\lfloor\frac{(S-D(y))_+}{2n+3}\right\rfloor
 \bigl((1-\mu)n-C_\mu\bigr)
 \le\log_2\Phi(n',T)
 \le C(T+1)\log_2(n'+T+2).
 }
\tag{3l.17}
\]

In particular, every maximum source-YES fiber obeys (3l.17), and

\[
 \boxed{
 D(y)\ge
 S-O_\mu\!\left(n+(T+1)\log_2(n'+T+2)\right).
}
\tag{3l.18}
\]

Put

\[
 U=\log_2\Phi(n',T),
 \qquad
 a_\mu=(1-\mu)n-C_\mu.
\]

For all sufficiently large \(n\), every fiber satisfying (3l.16) also obeys, for each fixed
\(f\in Y_y\) and every integer \(0\le B\le S\),

\[
 \boxed{
 \Pr_{g\sim\operatorname{Unif}(Y_y)}
 [\operatorname{CC}(f\oplus g)\le B]
 \le
 \min\!\left\{1,\frac{\Phi(n,B)\Phi(n',T)}{\Phi(n,S)}\right\}
 \le
 2^{-\left(
 a_\mu\left\lfloor\frac{S-B}{\ell_n}\right\rfloor-U
 \right)_+}.
 }
\tag{3l.18a}
\]

Equivalently, for \(\lambda\ge0\), set

\[
 q_\lambda=\left\lceil\frac{U+\lambda}{a_\mu}\right\rceil,
 \qquad
 B_\lambda=S-\ell_nq_\lambda.
\]

Whenever \(B_\lambda\ge0\),

\[
 \boxed{
 \Pr_{g\sim\operatorname{Unif}(Y_y)}
 [\operatorname{CC}(f\oplus g)\le B_\lambda]
 \le2^{-\lambda}.
 }
\tag{3l.18b}
\]

For the fixed-exponent bridging parameters of Theorem 1, this becomes

\[
 \boxed{
 D(y)\ge
 S-O_{\mu_H}\!\left(n2^{\kappa\mu_1n}\right)
 =S-o(S).
}
\tag{3l.19}
\]

Moreover, \(U=O(nT)\) and \(a_{\mu_H}=\Theta(n)\). Taking
\(\lambda=cnT\) for any fixed \(c>0\) in (3l.18b) gives, uniformly for every fixed
\(f\in Y_y\),

\[
 \Pr_g[\operatorname{CC}(f\oplus g)>B_\lambda]
 \ge1-2^{-cnT},
 \qquad
 B_\lambda=S-O_{\mu_H,c}(nT)=S-o(S).
\tag{3l.19a}
\]

If \(Q(f)=Af+b\) is affine with kernel \(K\), then the same conclusion gives

\[
 \boxed{
 w(K)\ge
 S-O_{\mu_H}\!\left(n2^{\kappa\mu_1n}\right).
}
\tag{3l.20}
\]

If, in addition, \(\mathcal L_S\) is a union of fibers, as two-sided exact promise preservation
requires, then

\[
 \boxed{
 \frac{|K\cap\mathcal L_B|}{|K|}
 \le
 2^{-\left(
 a_\mu\left\lfloor\frac{S-B}{\ell_n}\right\rfloor-U
 \right)_+}
 \qquad(0\le B\le S).
 }
\tag{3l.20a}
\]

Thus in the fixed-exponent regime all but a \(2^{-\Omega(nT)}\) fraction of the kernel has
circuit complexity at least \(S-O_{\mu_H}(nT)\).

#### Proof

The circuit count (3g) supplies a basis-dependent constant \(C_0\) such that

\[
 \log_2\Phi(n,t)
 \le C_0(t+1)\log_2(n+t+2).
\]

Set \(D_\mu=4C_0/(1-\mu)\) and \(r=\lceil D_\mu(t+1)\rceil\). Since
\(t\le2^{\mu n}\), for all sufficiently large \(n\),

\[
 \log_2\binom Nr
 \ge r\log_2\frac Nr
 \ge2C_0n(t+1)
 \ge\log_2\Phi(n,t).
\tag{3l.21}
\]

Let \(I\) be the simplicial-order initial segment of the \(N\)-cube with
\(|I|=\Phi(n,t)\). Harper's vertex-isoperimetric theorem says that \(I\) minimizes the closed
neighborhood, and hence the external vertex boundary, among sets of this size. Equation (3l.21)
gives \(|I|\le\binom Nr\le|B_r|\), where \(B_r=\{x\in\mathbb F_2^N:|x|\le r\}\), so
\(I\subseteq B_r\). The initial segment is a downset, including when its top layer is only
partially filled. Therefore the number of upward edges from \(I\) to its complement is

\[
 e^\uparrow(I,\mathbb F_2^N\setminus I)
 =N|I|-2\sum_{x\in I}|x|
 \ge(N-2r)|I|.
\tag{3l.22}
\]

Every external-boundary vertex has weight at most \(r+1\), and hence receives at most \(r+1\)
such edges. Thus

\[
 \frac{|\partial\mathcal L_t|}{\Phi(n,t)}
 \ge\frac{|\partial I|}{|I|}
 \ge\frac{N-2r}{r+1}
 \ge\frac{N}{2(D_\mu+2)(t+1)}.
\tag{3l.23}
\]

Changing one truth-table bit at \(a\in\{0,1\}^n\) means replacing \(f\) by
\(f\oplus\delta_a\). In the CHMY convention, \(\delta_a\) uses at most \(n\) input negations
and \(n-1\) AND gates, while

\[
 f\oplus\delta_a=(f\lor\delta_a)\land\neg(f\land\delta_a)
\]

uses four more gates. Hence
\(\mathcal L_t\cup\partial\mathcal L_t\subseteq\mathcal L_{t+2n+3}\). Taking logarithms in
(3l.23) proves (3l.13). Iterating at
\(B,B+\ell_n,\ldots,B+(q-1)\ell_n\), where
\(q=\lfloor(S-B)/\ell_n\rfloor\), proves (3l.14). The floor is essential when
\(S-B<2n+3\).

Fix a fiber satisfying (3l.16) and an \(f_*\in Y_y\). The map

\[
 g\longmapsto g\oplus f_*
\]

is injective from \(Y_y\) into \(\mathcal L_{D(y)}\). Hence

\[
 \Phi(n,D(y))\ge|Y_y|
 \ge\frac{\Phi(n,S)}{\Phi(n',T)}.
\]

If \(D(y)\le S\), apply (3l.14) with \(B=D(y)\); if \(D(y)>S\), the positive-part
formulation is immediate. This proves (3l.17). A maximum source-YES fiber satisfies (3l.16)
because \(|Q(\mathcal L_S)|\le\Phi(n',T)\). Rearranging the floor gives (3l.18), and (3l.19)
follows from \(n'=\kappa n+O(1)\),
\(T=2^{\kappa\mu_1n+O(1)}\), and \(\mu_H>\kappa\mu_1\).

For the pointwise tail, fix \(f\in Y_y\). The same injective translation bounds the number of
partners at XOR complexity at most \(B\):

\[
 |\{g\in Y_y:\operatorname{CC}(f\oplus g)\le B\}|
 \le\Phi(n,B).
\]

Divide by (3l.16), and then apply (3l.14), to obtain (3l.18a). The definitions of
\(q_\lambda\) and \(B_\lambda\) make
\(\lfloor(S-B_\lambda)/\ell_n\rfloor=q_\lambda\) and
\(a_\mu q_\lambda-U\ge\lambda\), proving (3l.18b). The fixed-exponent circuit count gives
\(U=O(nT)\), so (3l.19a) follows.

Finally, suppose \(Q\) is affine. If \(w(K)>S\), (3l.20) is immediate. Otherwise
\(Q^{-1}(b)=K\subseteq\mathcal L_S\), every affine fiber has size at most \(|K|\), and
\(D(b)=w(K)\). Thus \(Y_b=K\) is a maximum source-YES fiber, and (3l.20) follows from
(3l.19). If \(\mathcal L_S\) is a union of fibers, then the zero fiber is wholly contained in
\(\mathcal L_S\), every nonempty source-YES fiber is a coset of size \(|K|\), and
\(|K|\ge\Phi(n,S)/\Phi(n',T)\). Apply (3l.18a) to \(Y_b=K\) with \(f=0\) to obtain
(3l.20a) and its fixed-exponent consequence. \(\square\)

Proposition 5 supplies the missing target-side test for the junta kernels in Proposition 4. Put
\(S_0=S\), \(r_n=S_1/S\), and

\[
 B_*=\min\{S,S_1-S-c_\oplus\}.
\]

Whenever Proposition 4 applies,

\[
 S-B_*=\max\{0,2S+c_\oplus-S_1\}.
\tag{3l.24}
\]

If the quotient by this \(K\) were also YES-preserving to the target threshold, then for fixed
\(1<r<2\), the identity \(S-B_*=(2-r)S+O(1)\) would contradict both (3l.18) and the stronger
pointwise tail (3l.18a) in the bridging regime.
For \(r=2\) the residual is only \(O(1)\), and for \(r>2\) it is zero for all sufficiently large
\(n\), so this argument gives no obstruction. More generally, if \(r_n\uparrow2\), the same
junta kernel is excluded whenever

\[
 \boxed{
 2-r_n
 =\omega\!\left(n2^{-(\mu_H-\kappa\mu_1)n}\right).
 }
\tag{3l.25}
\]

This closes the uniformly subthreshold-width junta escape for sub-doubling gaps; Proposition 4
by itself remains only a gap-stability statement, not a construction of a compressed
YES-preserving image. Maximal-budget kernels at gaps at least two, and kernels with no bound below
the source threshold, are not covered.

The stronger Harper growth still does not by itself control the exact stabilizer. To see the
precise limitation, fix \(S=\lfloor2^{\mu n}\rfloor\), choose a sufficiently large constant
\(C\), set

\[
 r=\left\lfloor\log_2(S\log_2S)\right\rfloor-C,
 \qquad
 H=\{g(x_1,\ldots,x_r)\},
\]

and let \(A=H\). By Lupanov's bound and the choice of \(r\), a sufficiently large fixed \(C\)
ensures, for all sufficiently large \(n\), that

\[
 w(H)\le S/2
\]

and hence \(H\subseteq\mathcal L_S\), while

\[
 \dim H=\Theta(S\log S),
 \qquad
 \operatorname{Stab}(A)=H.
\]

Every nonzero function in \(H\) is constant on truth-table blocks of size
\(2^{n-r}\ge4\). Thus no point indicator \(e_a\), nor any \(e_a+e_b\) with \(a\ne b\), lies in
\(H\). The \(N\) boundary cosets \(H+e_a\) are therefore pairwise disjoint and avoid \(A\), so

\[
 |\partial A|=N|A|.
\tag{3l.26}
\]

Moreover, the same point-flip circuit gives
\(A\cup\partial A\subseteq\mathcal L_{S+2n+3}\). Hence low-circuit containment, maximal
stabilizer dimension, and even maximal standard-coordinate boundary growth are numerically
compatible. This model is not itself a bridge candidate: its uniformly low width violates
(3l.18a) for any fixed-exponent YES-preserving quotient achieving the required compression. Its
role is only to show that entropy and standard-coordinate boundary growth do not by themselves
control the exact stabilizer. Distinguishing the actual set \(\mathcal L_S\) from this model
at the level of the stabilizer itself requires circuit-specific translation information, for
example the zero set of

\[
 \tau_S(h)=|\{f\in\mathcal L_S:f+h\notin\mathcal L_S\}|,
\]

or the Fourier-support and 2-adic interfaces in (3l.3)--(3l.5); further
standard-coordinate isoperimetry cannot settle the exact stabilizer. The bridge question is
stronger than the bare stabilizer question, because target compression also bounds the number of
source-YES cosets. That extra condition is enough for the following conclusion.

### Proposition 6 (Harper doubling rules out exact coset quotients)

Fix \(0<\mu<1\), let \(n^2\le S\le2^{\mu n}\), and put

\[
 A=\mathcal L_S,
 \qquad
 \mathbb B_q=\{h\in\mathbb F_2^N:|h|\le q\},
 \qquad
 q=\left\lfloor\frac{S+4}{2n+3}\right\rfloor.
\]

Choose a basis-dependent constant \(C_0\) such that
\(\log_2\Phi(n,t)\le C_0(t+1)\log_2(n+t+2)\), and set

\[
 D_\mu=\frac{4C_0}{1-\mu},
 \qquad
 R=\lceil D_\mu(S+1)\rceil.
\]

For all sufficiently large \(n\),

\[
 \boxed{
 \log_2\frac{|A+A|}{|A|}
 \ge
 q\log_2\!\left(
 1+\frac{N-2(R+q)}{R+q+1}
 \right)
 \ge q\bigl((1-\mu)n-C'_\mu\bigr).
 }
\tag{3l.27}
\]

In particular, if \(S=\lfloor2^{\mu n}\rfloor\), then

\[
 \boxed{
 \log_2\frac{|\mathcal L_S+\mathcal L_S|}{|\mathcal L_S|}
 \ge\left(\frac{1-\mu}{2}-o(1)\right)S.
 }
\tag{3l.28}
\]

Suppose now that the fibers of \(Q\) are the cosets of a fixed linear subspace \(K\), that
\(A\) is a union of fibers, and that \(Q(A)\subseteq\mathcal L_{n',T}\). Then necessarily

\[
 \boxed{
 q\bigl((1-\mu)n-C'_\mu\bigr)
 \le\log_2|Q(A)|
 \le\log_2\Phi(n',T).
 }
\tag{3l.29}
\]

Consequently, no such exact coset quotient exists for the fixed-exponent bridging parameters of
Theorem 1. In particular, no exact affine quotient exists in that regime. Independently of any
target map, (3l.27) also gives

\[
 \boxed{
 \dim\operatorname{Stab}(\mathcal L_S)
 \le
 \log_2\Phi(n,S)-q\bigl((1-\mu)n-C'_\mu\bigr).
 }
\tag{3l.30}
\]

#### Proof

Every truth table of Hamming weight \(m\ge1\) is the XOR of \(m\) point indicators. The first
indicator costs at most \(2n-1\) gates, and each subsequent indicator together with its XOR costs
at most \(2n+3\) more. Hence

\[
 \operatorname{CC}(h)\le m(2n+3)-4\le S
 \qquad(h\in\mathbb B_q),
\tag{3l.31}
\]

with the zero table included trivially. Thus \(\mathbb B_q\subseteq A\) and

\[
 A+\mathbb B_q\subseteq A+A.
\tag{3l.32}
\]

Let \(I_0\) be the simplicial-order initial segment with \(|I_0|=|A|\). The circuit count and
the choice of \(R\), exactly as in (3l.21), give \(|I_0|\le\binom NR\), so
\(I_0\subseteq\mathbb B_R\). Write \(I_j=I_0+\mathbb B_j\). The upper shadow of the partial
top layer of a simplicial initial segment is again an initial segment; hence every \(I_j\) is a
downset contained in \(\mathbb B_{R+j}\). Iterating Harper's one-step theorem gives

\[
 |A+\mathbb B_j|\ge|I_j|.
\tag{3l.33}
\]

For \(0\le j<q\), the upward-edge count for \(I_j\) is at least
\((N-2(R+j))|I_j|\). Each external-boundary vertex receives at most \(R+j+1\) such edges.
Therefore

\[
 \frac{|I_{j+1}|}{|I_j|}
 \ge
 1+\frac{N-2(R+j)}{R+j+1}
 \ge
 1+\frac{N-2(R+q)}{R+q+1}.
\tag{3l.34}
\]

Multiplying (3l.34), then using (3l.32)--(3l.33), proves the first inequality in (3l.27).
Since \(R+q=O_\mu(S)\), its logarithmic factor is at least
\((1-\mu)n-C'_\mu\), uniformly in \(j\). This proves the second inequality and (3l.28).

For the quotient statement, write \(A\) as the union of \(m=|Q(A)|\) distinct \(K\)-cosets.
Then \(A+A\) is a union of at most \(m^2\) such cosets, so

\[
 \frac{|A+A|}{|A|}\le m=|Q(A)|.
\tag{3l.35}
\]

Equations (3l.27) and (3l.35) prove (3l.29). Under the fixed-exponent parameters,
\(\log_2\Phi(n',T)=O(nT)=o(S)\), whereas the left side of (3l.29) is
\(((1-\mu_H)/2-o(1))S\), a contradiction. Finally take
\(K=\operatorname{Stab}(A)\). Then \(A\) is a union of \(|A|/|K|\) cosets, and the same
argument rearranges to (3l.30). \(\square\)

### Proposition 7 (XOR-defect or fiber-inflation dichotomy)

Let \(Q\) be an arbitrary map on the source truth-table space, not necessarily exact or
efficient. Retain \(A=\mathcal L_S\), and define

\[
 Y=Q(A),
 \qquad
 M=|Y|,
 \qquad
 A_y=A\cap Q^{-1}(y),
 \qquad
 \overline F=\frac{|A|}{M}.
\]

Also put

\[
 M_+=|Q(A+A)|,
 \qquad
 \overline F_+=\frac{|A+A|}{M_+},
 \qquad
 C_M=\binom{M+1}{2}.
\]

Define

\[
 \begin{aligned}
 \mathsf X_Q(A)
 &=\frac{M_+}{M},\\
 \mathsf I_Q^{\mathrm{av}}(A)
 &=\frac{\overline F_+}{\overline F},\\
 \mathsf I_Q(A)
 &=\frac{1}{\overline F}
   \max_w |(A+A)\cap Q^{-1}(w)|,\\
 \mathsf D_Q^{\mathrm{av}}(A)
 &=\frac1{C_M}\left(
   \sum_{y\in Y}|Q(A_y+A_y)|
   +\sum_{\{y,z\}\in\binom{Y}{2}}|Q(A_y+A_z)|
   \right),\\
 \mathsf D_Q(A)
 &=\max_{y,z\in Y}|Q(A_y+A_z)|.
\end{aligned}
\tag{3l.36}
\]

Since \(0\in A\), one has \(A\subseteq A+A\), and therefore
\(\mathsf X_Q(A),\mathsf I_Q(A),\mathsf D_Q(A)\ge1\).
The average occupancy factor \(\mathsf I_Q^{\mathrm{av}}(A)\) is positive but can be below one,
while

\[
 \mathsf I_Q^{\mathrm{av}}(A)\le\mathsf I_Q(A),
 \qquad
 \mathsf D_Q^{\mathrm{av}}(A)\le\mathsf D_Q(A).
\]

Then

\[
 \boxed{
 \mathsf X_Q(A)\mathsf I_Q^{\mathrm{av}}(A)
 =\frac{|A+A|}{|A|},
 \qquad
 \mathsf X_Q(A)\mathsf I_Q(A)
 \ge\frac{|A+A|}{|A|}
 \ge
 2^{q((1-\mu)n-C'_\mu)}.
 }
\tag{3l.37}
\]

Moreover,

\[
 \boxed{
 \frac{|A+A|}{|A|}
 \le
 \mathsf I_Q^{\mathrm{av}}(A)
 \left(
 \frac{\mathsf D_Q^{\mathrm{av}}(A)(M+1)}2-1+\frac1M
 \right)
 \le
 \mathsf I_Q(A)
 \left(
 \frac{\mathsf D_Q(A)(M+1)}2-1+\frac1M
 \right).
 }
\tag{3l.38}
\]

If \(Q(A)\subseteq\mathcal L_{n',T}\), then

\[
 \boxed{
 \log_2\mathsf D_Q(A)+\log_2\mathsf I_Q(A)
 \ge
 \log_2\mathsf D_Q^{\mathrm{av}}(A)
 +\log_2\mathsf I_Q^{\mathrm{av}}(A)
 \ge
 q((1-\mu)n-C'_\mu)
 -\log_2\frac{M+1}{2}
 \ge
 q((1-\mu)n-C'_\mu)-\log_2\Phi(n',T).
 }
\tag{3l.39}
\]

For the fixed-exponent bridging parameters,

\[
 \boxed{
 \log_2\mathsf D_Q(A)+\log_2\mathsf I_Q(A)
 \ge
 \log_2\mathsf D_Q^{\mathrm{av}}(A)
 +\log_2\mathsf I_Q^{\mathrm{av}}(A)
 \ge
 \left(\frac{1-\mu_H}{2}-o(1)\right)S.
 }
\tag{3l.40}
\]

Thus every surviving quotient has either
\(\mathsf D_Q(A)=2^{\Omega(S)}\) or
\(\mathsf I_Q(A)=2^{\Omega(S)}\). More precisely,

\[
 \boxed{
 \max\{\mathsf D_Q^{\mathrm{av}}(A),\mathsf I_Q^{\mathrm{av}}(A)\}
 \ge
 2^{((1-\mu_H)/4-o(1))S},
 \qquad
 \max\{\mathsf D_Q(A),\mathsf I_Q(A)\}
 \ge
 2^{((1-\mu_H)/4-o(1))S}.
 }
\tag{3l.40a}
\]

#### Proof

The occupied fibers of \(Q\) partition \(A+A\), giving the exact factorization

\[
 \frac{|A+A|}{|A|}
 =\frac{M_+\overline F_+}{M\overline F}
 =\mathsf X_Q(A)\mathsf I_Q^{\mathrm{av}}(A)
 \le\mathsf X_Q(A)\mathsf I_Q(A).
\tag{3l.41}
\]

This proves the first part of (3l.37); its lower bound is (3l.27).

For the localized defect, commutativity gives

\[
 Q(A+A)=
 \bigcup_{y\in Y}Q(A_y+A_y)
 \mathbin{\cup}
 \bigcup_{\{y,z\}\in\binom{Y}{2}}Q(A_y+A_z).
\]

Every one of the \(M\) diagonal image sets contains \(Q(0)\). Counting that common value once,
the remaining diagonal values, and then the unordered off-diagonal pairs gives

\[
 M_+
 \le
 1
 +\sum_{y\in Y}\bigl(|Q(A_y+A_y)|-1\bigr)
 +\sum_{\{y,z\}\in\binom{Y}{2}}|Q(A_y+A_z)|
 =C_M\mathsf D_Q^{\mathrm{av}}(A)-M+1.
\tag{3l.42}
\]

Combine (3l.41)--(3l.42), divide by \(M\), and use the two average-to-maximum
inequalities following (3l.36) to prove (3l.38).
Using \(-1+1/M\le0\) in (3l.38), taking logarithms, and applying
\((M+1)/2\le M\le\Phi(n',T)\) proves (3l.39). Finally
\(\log_2\Phi(n',T)=O(nT)=o(S)\), so (3l.40) follows from (3l.28). Exponentiating (3l.40),
the maximum of the two positive average factors is at least the square root of their product;
this proves (3l.40a). \(\square\)

The two factors cannot be separated by cardinality alone. For an exact affine quotient,
all four average and maximum factors equal one, recovering Proposition 6. At the opposite
extreme, the constant map has \(M=M_+=1\),
\(\mathsf D_Q^{\mathrm{av}}(A)=\mathsf D_Q(A)=1\), and
\(\mathsf I_Q^{\mathrm{av}}(A)=\mathsf I_Q(A)=|A+A|/|A|\), so it saturates (3l.38) but
preserves only the YES side. The exact predicate map that sends \(A\) to one label and its
complement to another has \(M=1\); in the regime here, (3l.27) gives \(M_+=2\),
\(\mathsf D_Q^{\mathrm{av}}(A)=\mathsf D_Q(A)=2\), and
\(\mathsf I_Q^{\mathrm{av}}(A)=|A+A|/(2|A|)\), so the average bound in (3l.38) is exact.
It preserves both sides combinatorially, but computing it is exactly the source decision problem.
Therefore pure counting cannot eliminate arbitrary
predicate-specific fibers; a further bridge theorem must constrain XOR defect or fiber inflation
using the actual one-tape computation.

The exponent split in (3l.40a) is also sharp for cardinality arguments. Partition
\((A+A)\setminus A\) into \(L\) nearly equal nonempty blocks, map all of \(A\) to one label, and
assign one further label to each block. Then \(M=1\),
\(M_+=\mathsf D_Q^{\mathrm{av}}(A)=\mathsf D_Q(A)=L+1\), and, writing
\(R=|A+A|/|A|\),

\[
 \mathsf I_Q^{\mathrm{av}}(A)=\frac{R}{L+1},
 \qquad
 \mathsf I_Q(A)
 =\max\left\{1,\frac{R-1}{L}+O(|A|^{-1})\right\}.
\]

Thus
\(\mathsf D_Q^{\mathrm{av}}(A)\mathsf I_Q^{\mathrm{av}}(A)=R\) exactly. Taking
\(L\asymp R^{1/2}\) makes both average factors, and both maximum factors, of order
\(R^{1/2}\). Hence one cannot generally force either named factor to absorb more than half of
the logarithmic doubling exponent.

Raw one-tape time alone cannot provide such a constraint uniformly across predicates. For the
easy predicate \(A_0=\{x\in\{0,1\}^N:x_1=0\}\), the map

\[
 Q_0(x)=
 \begin{cases}
 0^{N+1},&x_1=x_2=0,\\
 0x,&x_1=0,\ x_2=1,\\
 1x,&x_1=1
 \end{cases}
\]

is computable by a linear-time scan and exactly preserves the predicate ``first output bit is
zero.'' Its source-YES fibers consist of one fiber of size \(2^{N-2}\) and \(2^{N-2}\)
singletons, so \(\overline F<2\) while
\(\mathsf I_{Q_0}(A_0)>2^{N-3}\). Thus a runtime-to-geometry theorem must use MCSP-specific
semantics. For the predicate map \(Q_A=1_A\), computing \(Q_A\) is time-equivalent, up to output
materialization, to deciding \(A\); applying such a theorem to \(Q_A\) would itself constitute
the desired MCSP time lower bound.

## 3. A non-dummy tensor test

Theorem 1 is one-sided and general. A natural non-dummy family shows that equality is forced when
both sides of the promise are preserved. Fix an integer \(t\ge2\) and a Boolean function
\(\phi:\{0,1\}^t\to\{0,1\}\) with \(\phi(0^t)=0\) and \(\phi(1^t)=1\), and define

\[
 E_{t,\phi}(f)(x^{(1)},\ldots,x^{(t)})
 =\phi\bigl(f(x^{(1)}),\ldots,f(x^{(t)})\bigr).
\tag{3m}
\]

This encoding has \(n'=tn\) and is exactly decodable on the diagonal:

\[
 E_{t,\phi}(f)(x,\ldots,x)=f(x).
\tag{3n}
\]

Consequently,

\[
 \operatorname{CC}(f)
 \le \operatorname{CC}(E_{t,\phi}(f))
 \le t\operatorname{CC}(f)+O_\phi(1).
\tag{3o}
\]

The left inequality restricts all \(t\) input blocks to the same variables, and the right one uses
\(t\) copies of a circuit for \(f\) followed by a fixed circuit for \(\phi\).

For completeness, circuit complexities are exponentially dense: whenever
\(0<\alpha<\beta<1\), all sufficiently large \(n\) admit an \(n\)-variable function \(f\) with

\[
 2^{\alpha n}<\operatorname{CC}(f)<2^{\beta n}.
\tag{3p}
\]

To see this, choose \(\alpha<\gamma<\beta\) and consider functions on
\(\lfloor\gamma n\rfloor\) variables. Circuit counting puts one above \(2^{\alpha n}\), while
the DNF upper bound puts every such function below \(2^{\beta n}\).

Now require, for every \(f\), both

\[
 \operatorname{CC}(f)\le2^{\mu_Hn}
 \Longrightarrow
 \operatorname{CC}(E_{t,\phi}(f))\le2^{t\mu_1n}
\tag{3q}
\]

and the reverse NO implication with both inequalities negated. If
\(\mu_H>t\mu_1\), (3p) supplies a source YES instance whose encoded complexity exceeds the
target threshold by (3o). If \(\mu_H<t\mu_1\), it supplies a source NO instance of complexity
below \(2^{\gamma n}\), for some \(\mu_H<\gamma<\min\{t\mu_1,1\}\); the upper bound in (3o)
makes its encoding a target YES instance. Therefore

\[
 \boxed{\mu_H=t\mu_1.}
\tag{3r}
\]

Thus direct products and tensors do not improve on the threshold-per-log-length ratio preserved
by dummy padding.

## 4. Exact threshold alignment by dummy variables

To test the fixed endpoint (2) by dummy variables, specialize the free target exponent in
this section and the calculation of Section 5 to \(\mu_1=\mu_*\).  Write \(\mu_1\) in the
formulas only to keep the general source/target threshold notation visible.

Let
\[
 k=\min\{j\in\mathbb N:j\mu_1>\tfrac12\},
 \qquad \mu_H=k\mu_1.
 \tag{4}
\]
Then
\[
 \tfrac12<\mu_H\le\tfrac12+\mu_1<\tfrac34.
 \tag{5}
\]
For \(f:\{0,1\}^n\to\{0,1\}\), define
\[
 E_k(f)(x,z)=f(x),
 \qquad x\in\{0,1\}^n,\quad z\in\{0,1\}^{(k-1)n}.
 \tag{6}
\]
In the bounded-fan-in, unbounded-fan-out De Morgan basis,
\[
 \operatorname{CC}(E_k(f))=\operatorname{CC}(f).
 \tag{7}
\]
The forward inequality ignores the dummy variables. Conversely, replacing every dummy-input
leaf in a circuit for \(E_k(f)\) by an \(x_1\)-leaf yields a circuit for \(f\) without
increasing size. Since \(N'=2^{kn}=N^k\),
\[
 f\in L_{\mu_H,n}
 \quad\Longleftrightarrow\quad
 E_k(f)\in L_{\mu_1,kn}.
 \tag{8}
\]
Thus the threshold alignment itself is exact; it is not the missing interface.

## 5. The unavoidable exponent loss

The oracle-strengthened CHMY theorem implies that for every
\(1/2<\lambda<\mu_H\),
\[
 L_{\mu_H}\notin\operatorname{BPTIME}_1[N^{2(\lambda-o(1))}].
 \tag{9}
\]
Suppose, optimistically, that a low-threshold decider running in time \((N')^a\) could be
composed with (6) without any additional exponent loss. Then the induced high-threshold
decider would run in
\[
 (N')^a=N^{ka}.
 \tag{10}
\]
Combining (9) and (10) rules out only
\[
 a<\frac{2\lambda}{k}-o(1).
 \tag{11}
\]
Letting \(\lambda\uparrow\mu_H=k\mu_1\), the best possible endpoint is
\[
 a<2\mu_1-o(1)<\tfrac12.
 \tag{12}
\]
This is strictly below \(1.01\), the scale required in (2). Equivalently, to rule out
\((N')^{1.01}\) by (9), one would need
\[
 1.01k<2\lambda<2k\mu_1,
 \qquad\text{hence}\qquad \mu_1>0.505,
 \tag{13}
\]
contradicting (3).

An ordinary materialized reduction is weaker still: it must write all \(N'=N^k\) padded
bits. Since \(\mu_1<1/4\), we have \(k\ge3\), and the output-generation cost already lies
above the time scale that (9) could exclude.

## 6. The genuine one-tape composition gap

The idealized calculation above is deliberately generous. In the canonical table of \(E_k(f)\),
each source truth-table bit is repeated
\[
 R=N^{k-1}
 \tag{14}
\]
times. An online one-tape generator must know the final input length before emitting the first
repeated block. Scanning the whole source input and then simulating a target machine requires
storing the source table and a one-tape work simulation. The MMW and CHMY simulation lemmas do
not provide an \(N'^{o(1)}\)-overhead guarantee for this particular composition.

Therefore (12) is an optimistic upper bound for the padding route: even if this additional
composition interface were supplied for free, the exponent would remain too small. Corollary 2
shows that the same conclusion holds for every YES-preserving map satisfying the small-fiber
condition (3h), before this composition issue arises.

### Proposition 8 (the materialization boundary for arbitrary quotients)

Fix constants \(a,b,\kappa>0\), and let \(Q_n\) be a deterministic, pointwise exact threshold
reduction with \(N'=N^{\kappa+o(1)}\). Assume explicitly that a \(Q_n\)-materializer taking
time \(N^{b+o(1)}\) and a target decider taking time \((N')^{a+o(1)}\) compose into a CHMY-model
source machine with total time

\[
 N^{o(1)}\left(N^{b+o(1)}+(N')^{a+o(1)}\right).
\]

Here both truth tables use canonical order; work-tape initialization, target-input delivery, and
head relocation are included in the handoff. If the target machine is randomized, its error must
be preserved; if the oracle-strengthened source lower bound is invoked, every composed oracle
query must still have length \(N^{o(1)}\). Then the composed source computation has exponent

\[
 \beta=\max\{b,\kappa a\}.
 \tag{15}
\]

It enters some CHMY lower-bound window with
\(1/2<\lambda<\mu_H\) if and only if

\[
 \boxed{\beta<2\mu_H.}
 \tag{16}
\]

In a separate fresh-output transducer model with an initially blank sequential output, at most
\(O(1)\) output bits written per step, and all canonical \(N'\) bits explicitly written, one has
\(b\ge\kappa\).
Hence output length alone closes every CHMY window exactly when \(\kappa\ge2\mu_H\). If
materialization is optimal, \(b=\kappa\), and \(a\ge1\), the surviving window is instead

\[
 \boxed{\kappa a<2\mu_H.}
 \tag{17}
\]

Indeed, the CHMY bound (9) contradicts the composed upper bound precisely when
\(\beta<2\lambda\) for some \(1/2<\lambda<\mu_H\), which is equivalent to (16). The remaining
claims follow from the fresh-output lower bound \(N'\) and (15). \(\square\)

This is a conditional exponent boundary, not a composition lemma supplied by MMW or CHMY. MMW's
one-pass algorithm is a RAM-model streaming algorithm on the original canonical input. CHMY's
\(\operatorname{DTIME}_1/\operatorname{BPTIME}_1\) model has a one-way read-only input tape and
one two-way read/write work tape, with no independent materialized-output interface; its streaming
simulation lemma acts on the same given input stream.

### Proposition 9 (an exact switch quotient forces the missing branch bit)

Fix an integer \(k\ge1\), put \(N'=N^k\), \(S=\lfloor N^{\mu_H}\rfloor\), and
\(T=\lfloor N^{k\mu_1}\rfloor\), and suppose \(\mu_H>k\mu_1\). Let \(E_k\) be the dummy lift
from (6), and define
\[
 Q_n^{\mathrm{sw}}(f)=
 \begin{cases}
  0^{N'},&\operatorname{CC}(f)\le S,\\
  E_k(f),&\operatorname{CC}(f)>S.
 \end{cases}
\]
Then, for all sufficiently large \(n\),
\[
 f\in L_{\mu_H,n}
 \quad\Longleftrightarrow\quad
 Q_n^{\mathrm{sw}}(f)\in L_{\mu_1,kn}.
\]
Moreover, if a deterministic CHMY-compatible fresh-output transducer materializes all \(N'\)
output bits in time \(N^{b+o(1)}\), then
\[
 \boxed{\max\{b,k\}\ge 2\mu_H.}
\]

Indeed, \(0^{N'}\) has constant circuit complexity. On the NO branch,
\(\operatorname{CC}(E_k(f))=\operatorname{CC}(f)>S>T\), so the output cannot be \(0^{N'}\).
Running the transducer and accepting exactly when every emitted bit is zero therefore decides
\(L_{\mu_H,n}\) in one-tape time
\(N^{\max\{b,k\}+o(1)}\). If the displayed inequality failed, choose
\(1/2<\lambda<\mu_H\) with \(\max\{b,k\}<2\lambda\) and contradict the CHMY lower bound (9).
This is a lower bound for the deliberately branch-forcing quotient \(Q_n^{\mathrm{sw}}\), not
for arbitrary predicate-specific quotients; it shows why an MMW search output alone cannot supply
the missing exact materialization interface.

### Proposition 10 (a conditional prefix-state barrier)

Assume a deterministic, prefix-consistent materializer \(Q_n\) emits the target table in canonical
order, and a deterministic target decider consumes that output synchronously in the same order.
Let \(W_Q\) and \(W_D\) be the numbers of complete boundary configurations of the materializer
and decider, respectively; these configurations include work tape, heads, output phase, and
buffers. If the composed exact computation is represented by a known-order ROBP of width
\[
 w\le (N'+1)W_QW_D,
\]
and assume the following local-PRG interface: every length-\(N\), width-\(w\) ROBP is fooled
with additive error at most \(\eta_{\mathrm{PRG}}\) by a seed of length
\(r=\widetilde O(\log(Nw))\), with every seed output having circuit complexity at most \(r\).
Then
\[
 \boxed{\log(Nw)=\widetilde{\Omega}(S).}
\]
Consequently,
\[
 \boxed{\log W_Q+\log W_D=\widetilde{\Omega}(S).}
\]

To see this, take a fixed \(\eta_{\mathrm{PRG}}>0\). The local PRG has seed length
\(r=\widetilde O(\log(Nw))\), and every seed output has circuit complexity at most \(r\).
If \(r\le S\), the ROBP accepts every PRG output, whereas circuit enumeration gives
\[
 \Pr_{x\in\{0,1\}^N}[x\in L_{\mu_H,n}]
 \le 2^{-N+O(S\log(N+S))}=o(1)
 \]
for \(S=N^{\mu_H}\) with \(\mu_H<1\). This contradicts fooling. The statement is a joint
boundary-state lower bound: it does not charge \(Q_n\) alone, and it fails for random-access
handoff, suffix-dependent output prefixes, or finite-control state counts that omit the work tape.

### Corollary 11 (short output descriptions force occupancy inflation)

Let \(\ell=\ell(n)\), and suppose there is a family \(\mathcal G_\ell\) of target truth tables
with \(|\mathcal G_\ell|\le2^\ell\) such that
\[
 Q(A+A)\subseteq\mathcal G_\ell.
\]
Then Proposition 7 gives
\[
 \boxed{
 \log_2\mathsf I_Q^{\mathrm{av}}(A)
 \ge
 \left(\frac{1-\mu_H}{2}-o(1)\right)S-\ell.
 }
\]
The same lower bound holds with \(\mathsf I_Q(A)\) in place of
\(\mathsf I_Q^{\mathrm{av}}(A)\). In particular, if \(\ell=o(S)\), both occupancy factors
are at least \(2^{((1-\mu_H)/2-o(1))S}\).

Indeed, \(\mathsf D_Q^{\mathrm{av}}(A)\le M_+\le|\mathcal G_\ell|\le2^\ell\), so subtracting
\(\ell\) from (3l.40) proves the average statement; the maximum statement follows from
\(\mathsf I_Q^{\mathrm{av}}(A)\le\mathsf I_Q(A)\). This is a description--collision tradeoff,
not by itself a lower bound on the time used to produce the descriptions.
In particular, if \(\mathcal G_\ell\) is a circuit-described family on \(n'\) variables with
size at most \(T\), circuit enumeration permits
\(\ell=O((T+1)\log(n'+T+2))\). Hence any such family with
\(T\log(n'+T)=o(S)\) forces
\[
 \log_2\mathsf I_Q^{\mathrm{av}}(A),
 \log_2\mathsf I_Q(A)
 \ge\left(\frac{1-\mu_H}{2}-o(1)\right)S.
\]

### Corollary 12 (delayed-output state--occupancy tradeoff)

Assume in addition that a deterministic materializer emits no target bit before it has read the
source end marker, and let \(W_Q\) be the number of reachable complete boundary configurations
at that marker. Then
\[
 \boxed{
 \log_2 W_Q+\log_2\mathsf I_Q^{\mathrm{av}}(A)
 \ge\left(\frac{1-\mu_H}{2}-o(1)\right)S,
 }
\]
and the same inequality holds with \(\mathsf I_Q(A)\) in place of
\(\mathsf I_Q^{\mathrm{av}}(A)\).

Indeed, two inputs reaching the same complete boundary configuration must emit the same
remaining target suffix. Hence \(W_Q\ge M_+=|Q(A+A)|\). Apply (3l.40) and
\(\mathsf D_Q^{\mathrm{av}}(A)\le M_+\) to obtain the claim. The delayed-output condition is
essential: a streaming copier can have small boundary state while producing many outputs.

### Corollary 13 (early-output--state--occupancy trilemma)

More generally, suppose that at most \(r=r(n)\) target bits have been emitted before the source
end marker. Let \(W_Q\) count complete internal boundary configurations, excluding the already
emitted output prefix. Then
\[
 \boxed{
 \log_2 W_Q+r+1+\log_2\mathsf I_Q^{\mathrm{av}}(A)
 \ge\left(\frac{1-\mu_H}{2}-o(1)\right)S,
 }
\]
and the same inequality holds with \(\mathsf I_Q(A)\) in place of
\(\mathsf I_Q^{\mathrm{av}}(A)\).

Indeed, there are at most \(2^{r+1}\) possible emitted prefixes. Within one fixed prefix,
distinct outputs require distinct internal boundary configurations, so
\(M_+\le2^{r+1}W_Q\). Combine this with (3l.40) and
\(\mathsf D_Q^{\mathrm{av}}(A)\le M_+\). The bound is informative precisely when the early
output budget \(r\) is sublinear in \(S\); a copy-streaming transducer with \(r\asymp N'\)
falls outside that regime.

### Corollary 14 (one-tape time--space--occupancy tradeoff)

Assume the materializer is a deterministic one-tape machine over a fixed finite alphabet, uses
at most \(s=s(n)\) work-tape cells, and halts after \(T_M=T_M(n)\) steps. Then
\[
 \boxed{
 T_M+s+\log_2(N+T_M)+\log_2\mathsf I_Q^{\mathrm{av}}(A)
 \ge\left(\frac{1-\mu_H}{2}-o(1)\right)S,
 }
\]
and the same inequality holds with \(\mathsf I_Q(A)\) in place of
\(\mathsf I_Q^{\mathrm{av}}(A)\).

Indeed, at the source end marker the number of complete configurations is at most
\((N+1)(T_M+1)^{O(1)}|\Gamma|^{O(s)}\), so
\(\log_2W_Q=O(s+\log(N+T_M))\). Also the pre-end output budget in Corollary 13 is
\(r\le T_M\). Substitution proves the claim. Thus, whenever
\(s+\log(N+T_M)+\log\mathsf I_Q^{\mathrm{av}}(A)=o(S)\), the materializer itself requires
\(T_M=\Omega(S)\). This remains a restricted-model statement, not the CHMY
\(2\mu_H\)-exponent lower bound.

### Corollary 15 (sub-\(S\) materializer resource dichotomy)

Suppose \(\log_2\mathsf I_Q(A)\le\eta S\) for some fixed
\(\eta<(1-\mu_H)/2\), and \(\log(N+T_M)=o(S)\). Then every fixed-alphabet one-tape
materializer obeys
\[
 \boxed{
 T_M+s\ge
 \left(\frac{1-\mu_H}{2}-\eta-o(1)\right)S.
 }
\]
The same conclusion holds if the average factor
\(\mathsf I_Q^{\mathrm{av}}(A)\) is used instead.

This is immediate from Corollary 14. Equivalently, a materializer with both
\(T_M=o(S)\) and \(s=o(S)\) must have
\(\log_2\mathsf I_Q(A)\ge((1-\mu_H)/2-o(1))S\). The result excludes a
sub-\(S\), low-inflation implementation, but does not exclude the remaining
\(N^{\mu_H+o(1)}\)-time window.

### Corollary 16 (the exponent phase boundary supplied by Corollary 15)

Assume the materializer is a fixed-alphabet one-tape machine with polynomially bounded running
time \(T_M=N^{b+o(1)}\), so \(s\le T_M\). If
\(\log_2\mathsf I_Q(A)\le\eta S\) for a fixed
\(\eta<(1-\mu_H)/2\), then
\[
 \boxed{b\ge\mu_H.}
\]
Equivalently, the present resource argument closes the region
\[
 b<\mu_H\ \land\ \log_2\mathsf I_Q(A)\le\eta S,
\]
while the band \(\mu_H\le b<2\mu_H\) remains outside its reach. This explicitly separates the
new materializer bound from the stronger CHMY composition threshold.

### Corollary 17 (an evaluable descriptor closes the remaining window)

Suppose a descriptor \(d_n(f)\) for \(Q_n(f)\) is computed in time \(N^{b+o(1)}\), and a
canonical evaluator, given \(d_n(f)\), streams all \(N'=N^{\kappa+o(1)}\) target bits in time
\((N')^{c+o(1)}\) with the required one-tape handoff. If a target decider runs in
\((N')^{a+o(1)}\) time, then
\[
 \boxed{
 \max\{b,\kappa c,\kappa a\}\ge2\mu_H.
 }
\]

Indeed, descriptor generation followed by evaluation is a \(Q_n\)-materializer of source-scale
exponent \(\max\{b,\kappa c\}\). Proposition 8 then applies. Thus a short descriptor can remain
inside the middle band only if its evaluator or handoff fails to meet this explicit interface;
short description length alone is not an escape.

### Corollary 18 (target-NO range richness on the sumset)

Let
\[
 H_Q=Q(A+A)\setminus\mathcal L_{n',T}.
\]
For every fixed \(\eta<(1-\mu_H)/2\), one has
\[
 \boxed{
 \log_2\mathsf I_Q^{\mathrm{av}}(A)\ge\eta S
 \quad\text{or}\quad
 \log_2|H_Q|\ge
 \left(\frac{1-\mu_H}{2}-\eta-o(1)\right)S.
 }
\]
The same disjunction holds with \(\mathsf I_Q(A)\) in place of
\(\mathsf I_Q^{\mathrm{av}}(A)\).

Indeed, if the first alternative fails, (3l.40) gives
\(\log_2\mathsf D_Q^{\mathrm{av}}(A)\ge((1-\mu_H)/2-\eta-o(1))S\).
Since \(\mathsf D_Q^{\mathrm{av}}(A)\le|Q(A+A)|\), the total range has at least that many
elements. Circuit enumeration gives
\(\log_2|\mathcal L_{n',T}|=o(S)\), so removing the low-complexity target tables leaves the
stated number of target-NO outputs. This is the range-side obstruction to an implicit evaluator
that only handles low-complexity descriptors.

### Corollary 19 (target-NO descriptor and enumeration lower bounds)

Retain the notation of Corollary 18 and put

\[
 \alpha_H=\frac{1-\mu_H}{2}.
\]

Assume there is a deterministic evaluator \(V\) whose descriptor image covers \(H_Q\):

\[
 H_Q\subseteq V\bigl(\{0,1\}^{\ell_{\rm NO}}\bigr).
\]

No injectivity of the descriptor assignment is assumed. If descriptors have variable length at
most \(\ell_{\rm NO}\), replace the domain by \(\{0,1\}^{\le\ell_{\rm NO}}\).

Then, for every fixed \(0\le\eta<\alpha_H\),

\[
 \boxed{
 \log_2\mathsf I_Q^{\rm av}(A)<\eta S
 \quad\Longrightarrow\quad
 \ell_{\rm NO}\ge(\alpha_H-\eta-o(1))S .
 }
\]

The same implication holds with \(\mathsf I_Q(A)\) in place of
\(\mathsf I_Q^{\rm av}(A)\). If descriptors have variable length at most
\(\ell_{\rm NO}\), the right side loses only an additive \(1\):

\[
 \ell_{\rm NO}\ge(\alpha_H-\eta-o(1))S-1.
\]

More generally, if at most \(2^r\) advice strings index deterministic evaluators and the union
of their descriptor images covers \(H_Q\), with descriptor length at most \(\ell_{\rm NO}\),
then

\[
 \boxed{
 r+\ell_{\rm NO}\ge(\alpha_H-\eta-o(1))S-1.
 }
\]

More generally, suppose an enumerator emits every member of \(H_Q\) exactly once as a canonical
\(N'=2^{n'}\)-bit target table, and emits at most \(c_{\rm out}\) output bits per step. If
\(T_{\rm enum}\) is its total number of steps, then

\[
 c_{\rm out}T_{\rm enum}\ge |H_Q|N',
 \qquad
 \boxed{
 \log_2T_{\rm enum}
 \ge(\alpha_H-\eta-o(1))S+\log_2N'-\log_2c_{\rm out}.
 }
\]

#### Proof

Corollary 18 gives

\[
 \log_2|H_Q|\ge(\alpha_H-\eta-o(1))S
\]

whenever \(\log_2\mathsf I_Q^{\rm av}(A)<\eta S\), and likewise for
\(\mathsf I_Q(A)\). A deterministic evaluator on fixed-length descriptors has image size at
most \(2^{\ell_{\rm NO}}\), so \(\ell_{\rm NO}\ge\log_2|H_Q|\). For variable-length binary
strings of maximum length \(\ell_{\rm NO}\), there are \(2^{\ell_{\rm NO}+1}-1\) possibilities,
giving the stated additive \(1\). With at most \(2^r\) advice choices, the union of the images
has size at most \(2^r(2^{\ell_{\rm NO}+1}-1)\), proving the advice form. Finally, an exact
enumeration writes \(|H_Q|N'\) target bits; the output-rate assumption gives
\(c_{\rm out}T_{\rm enum}\ge|H_Q|N'\). Taking logarithms proves the claim.

The enumeration hypothesis is essential for the time statement. Range richness alone does not
force a comparable *single-call* evaluator time: one invocation outputs only one \(N'\)-bit
table and therefore has the unconditional rate bound \(t_{\rm eval}\ge N'/c_{\rm out}\), but it
need not visit the other descriptors. For example, whenever \(\ell\le N'\), choose any
injective index set \(D\subseteq\{0,1\}^{\ell}\) and define

\[
 h_d=d\,0^{N'-\ell}\qquad(d\in D).
\]

The evaluator that copies \(d\) and then emits zeros runs in \(O(N')\) steps per descriptor,
even when \(|D|=2^{\ell}\). Thus Corollary 19 gives an information/total-enumeration lower
bound, not a per-descriptor time lower bound; obtaining the latter requires an additional
uniformity, access, or hard-target assumption beyond the present definitions.

### Corollary 20 (exact range--occupancy factorization)

Let \(B=\mathcal L_{n',T}\) be the target-YES set and assume that \(Q\) is pointwise exact:

\[
 f\in A\quad\Longleftrightarrow\quad Q(f)\in B
 \qquad\text{for every source table }f.
\]

Write \(Y=Q(A)\), \(M=|Y|\), \(H_Q=Q(A+A)\setminus B\), and \(h=|H_Q|\). Then exactness and
\(0\in A\) imply the disjoint decomposition

\[
 Q(A+A)=Y\sqcup H_Q.
\]

Consequently, with \(d=|A+A|/|A|\) and the average occupancy factor from (3l.36),

\[
 \boxed{
 \log_2\!\left(1+\frac{h}{M}\right)
 +\log_2\mathsf I_Q^{\rm av}(A)
 =\log_2 d.
 }
\]

In the fixed-exponent regime of Corollary 18,
\(\log_2 d\ge(\alpha_H-o(1))S\), so

\[
 \boxed{
 \frac{|H_Q|}{|Q(A)|}
 \ge 2^{(\alpha_H-\eta-o(1))S}-1
 \quad\text{whenever}\quad
 \log_2\mathsf I_Q^{\rm av}(A)\le\eta S.
 }
\]

The same conclusion holds with \(\mathsf I_Q(A)\) in place of the average factor. The identity
is sharp: the two-label predicate quotient has \(M=h=1\) and
\(\mathsf I_Q^{\rm av}(A)=d/2\), so all additive expansion can be absorbed by occupancy. In the
present MCSP regime \(d>1\), so the YES fiber contains \(0\) but is not a subspace; Proposition 5
still gives its almost-everywhere XOR-dispersion. Thus non-coset structure and dispersion alone
cannot improve the factorization.

#### Proof

Since \(0\in A\), \(A\subseteq A+A\), hence \(Y\subseteq Q(A+A)\). If \(z\in Q(A+A)\cap B\),
choose \(x\in A+A\) with \(Q(x)=z\). Pointwise exactness gives \(x\in A\), so \(z\in Y\).
Thus \(Q(A+A)\cap B=Y\), which is equivalent to the displayed disjoint decomposition. By
(3l.36),

\[
 \mathsf I_Q^{\rm av}(A)
 =\frac{|A+A|/|Q(A+A)|}{|A|/M}
 =d\,\frac{M}{M+h}.
\]

Taking logarithms gives the identity. Insert the Harper lower bound on \(d\), and use
\(\mathsf I_Q^{\rm av}(A)\le\mathsf I_Q(A)\) for the maximum-factor version. \(\square\)

### Proposition 21 (unconditional quadratic composition)

Assume \(Q_n\) is pointwise exact and has a deterministic fixed-alphabet fresh-output
one-tape materializer \(M_Q\): the source table is read one-way, the work tape is
read--write, the target table is written sequentially at \(O(1)\) bits per step, and
\(M_Q\) halts after \(T_M=N^{b+o(1)}\) steps. Let a target CHMY one-tape decider \(D\) run
in \(T_D=(N')^{a+o(1)}\) steps, with exact correctness (or preserved bounded error).
Then the literal handoff is not itself a CHMY one-tape computation: its read-only input tape
still contains \(f\) and cannot become \(Q(f)\) during the run. It nevertheless has an
unconditional compilation into one:

\[
 U=T_M+N'+T_D,\qquad
 T_{\rm comp}=O(U^2).
\]

Consequently, with \(N'=N^{\kappa+o(1)}\),

\[
 \boxed{\max\{b,\kappa,\kappa a\}\ge\mu_H.}
\]

Since the explicit output rate gives \(b\ge\kappa\), this is
\(\max\{b,\kappa a\}\ge\mu_H\). It holds without a low-inflation or prefix-consistency
assumption, but it is weaker than the \(2\mu_H\) boundary under the additional near-additive
CHMY handoff of Proposition 8.

#### Proof

Use three logical tapes: \(W_M\) for the materializer work tape, \(O\) for its sequential
output, and \(W_D\) for the target decider work tape. First simulate \(M_Q\), rewind \(O\),
and then simulate \(D\) with \(O\) as its one-way input. The resulting fixed-alphabet
multitape machine uses \(U=T_M+N'+T_D\) steps up to constant factors. The standard
one-tape simulation of a \(U\)-time multitape computation (CHMY, Section 2.2 and Lemma 9)
takes \(O(U^2)\) steps, so the composed source machine decides \(L_{\mu_H,n}\). If
\(\beta=\max\{b,\kappa,\kappa a\}<\mu_H\), choose
\(\max\{\beta,\tfrac12\}<\lambda<\mu_H\). Then
\(T_{\rm comp}=N^{2\beta+o(1)}\) lies below the CHMY lower-bound window
\(N^{2(\lambda-o(1))}\), a contradiction. The bounded-error
case preserves its error under deterministic tape simulation. \(\square\)

### Corollary 22 (short oracle-descriptor boundary)

Let \(G_n\) be a deterministic fixed-alphabet one-tape source transducer that writes one
query string \(d(f)\) of length \(N^{\delta+o(1)}\) to a sequential query tape in
\(N^{b+o(1)}\) steps, and let a fixed oracle relation \(R\) satisfy

\[
 R(d(f))=1\quad\Longleftrightarrow\quad f\in A
\]

for every source table \(f\). Then

\[
 \boxed{\max\{1,b\}+2\delta\ge2\mu_H.}
\]

In the usual full-scan regime \(b\ge1\), this is \(b+2\delta\ge2\mu_H\); in particular,
a constant-length oracle descriptor (\(\delta=0\)) already requires \(b\ge2\mu_H\).
This is an oracle-query interface result, not a lower bound for arbitrary implicit quotients.

#### Proof

Compose \(G_n\) with one query to \(R\). This is a constant-control oracle RTM of time
\(t=N^{\beta+o(1)}\), query length \(N^{\delta+o(1)}\), where
\(\beta=\max\{1,b\}\). CHMY's oracle local-PRG corollary supplies a local PRG with seed/output circuit
complexity

\[
 \widetilde O\!\left(\sqrt t\,(\,N^{\delta+o(1)}+\log t\,)\right)
 =N^{\beta/2+\delta+o(1)}.
\]

If \(\beta/2+\delta<\mu_H\), every PRG output lies in \(A=\mathcal L_{\mu_H,n}\), whereas
a uniform source table lies in \(A\) with probability \(o(1)\). The oracle RTM therefore
distinguishes the PRG from uniform, contradicting the oracle PRG guarantee. \(\square\)

### Corollary 23 (adaptive short-oracle transcript boundary)

Let \(M_n^O\) be a fixed-alphabet, \(O(1)\)-state oracle RTM with source input length
\(N=2^n\). Suppose it runs for \(t=N^{b+o(1)}\) steps (pad to \(t\ge N\)), may make
adaptively chosen queries to one fixed oracle \(O\), and every query string has length at most
\(\ell=N^{\delta+o(1)}\). Assume that \(M_n^O\) decides
\(A=\mathcal L_{\mu_H,n}\) exactly or with fixed bounded error. Then

\[
 \boxed{\max\{1,b\}+2\delta\ge2\mu_H.}
\]

The number of queries does not appear separately: it is at most \(t\). A finite collection of
fixed relations can be folded into \(O\) by a constant tag; an \(n\)-indexed uniform relation can
be folded in with an \(O(\log n)\)-bit binary prefix. If only the total number of queried bits is
\(N^{\delta_{\rm tot}+o(1)}\), the same argument gives the weaker bound with
\(\delta_{\rm tot}\) in place of \(\delta\).

#### Proof

Put \(\beta=\max\{1,b\}\). The oracle-RTM local-PRG theorem of CHMY (their Lemma 22 and
oracle corollary; published numbering Corollary 23) applies to adaptive queries: for constant
\(\varepsilon\), its seed length is

\[
 \widetilde O\!\left((\sqrt t+O(1))
 \log(q\,2^\ell t)\right)
 =N^{\beta/2+\delta+o(1)}
\]

because the finite control has \(q=O(1)\) states and
\(\log(q2^\ell t)=\ell+O(\log t)\). The locality part of the same theorem, used in the CHMY
MCSP argument, makes every generated \(N\)-bit table computable by a circuit of size
\(N^{\beta/2+\delta+o(1)}\). If \(\beta/2+\delta<\mu_H\), every generator output is therefore
in \(A\), while a uniformly random source table lies in \(A\) with probability \(o(1)\) by
circuit enumeration. This gives a constant distinguishing gap, contradicting the PRG fooling
guarantee. Hence \(\beta/2+\delta\ge\mu_H\). Since \(\delta\le\delta_{\rm tot}\) when total
query length is the only supplied bound, the stated weaker total-transcript form follows.
\(\square\)

The same boundary covers a static random-access descriptor whenever it is
membership-sufficient. If \(G_n(f)\) writes \(d\) of length \(N^{\delta+o(1)}\), and a fixed
uniform evaluator \(E(n,d,i)\) returns the \(i\)-th target bit, define the single fixed relation
\[
 R(\langle n,d\rangle)=1
 \quad\Longleftrightarrow\quad
 \bigl(E(n,d,0),\ldots,E(n,d,N'-1)\bigr)\in\mathcal L_{n',T}.
\]
Then \(R(\langle n,G_n(f)\rangle)=1\) exactly when \(f\in A\), so Corollary 22 applies. This
does not cover an evaluator that reads \(f\), an uncharged RAM, or a relation depending on the
particular source instance; those are hidden-oracle/model-escape interfaces rather than static
descriptors.

### Corollary 24 (query-family/state tradeoff)

Let \(M_n^O\) be as in Corollary 23, but allow \(q_N\) states and nonuniform transition tables.
For the fixed source-independent oracle \(O\), let \(\mathcal Q_N\) be the set of all query
strings that can occur over all source inputs, random tapes, and adaptive answer paths, and put
\(D_N=|\mathcal Q_N|\). Define

\[
 \rho_q=\limsup_{N\to\infty}
 \frac{\log(1+\log_2 q_N)}{\log N},
 \qquad
 \rho_{\mathcal Q}=\limsup_{N\to\infty}
 \frac{\log(1+\log_2 D_N)}{\log N}.
\]

If \(M_n^O\) runs in \(N^{b+o(1)}\) time and decides
\(\mathcal L_{\mu_H,n}\), exactly or with fixed bounded error, then

\[
 \boxed{
 \max\{1,b\}+2\max\{\rho_q,\rho_{\mathcal Q}\}\ge2\mu_H.
 }
\]

If every query has length \(N^{\delta+o(1)}\), then \(D_N\le2^{N^{\delta+o(1)}}\), so
\(\rho_{\mathcal Q}\le\delta\) and Corollary 23 is recovered. The query-family form is stronger
when long query strings come from a small structured family.

#### Proof

For each fixed coin sequence, restrict CHMY Lemma 22's hardwiring to
\(\mathcal Q_N\). The resulting DTM has at most
\[
q_N\,2D_N\,t
\]
states. The oracle local-PRG seed bound is therefore
\[
 \widetilde O\!\left((\sqrt t+O(1))\log(q_ND_Nt)\right)
 =N^{\max\{1,b\}/2+\max\{\rho_q,\rho_{\mathcal Q}\}+o(1)}.
\]
If this exponent is below \(\mu_H\), locality puts every generator output in
\(\mathcal L_{\mu_H,n}\), while a uniform table belongs there with probability \(o(1)\);
the decision gap contradicts the PRG guarantee. \(\square\)

The maximum is forced by
\(\log(q_ND_Nt)=\log q_N+\log D_N+\log t\), and is sharp at this hardwiring interface. A fixed
advice string is not automatically charged; source-dependent oracles, hidden RAM, and free
multi-bit answers remain outside the model.

### Proposition 25 (exact random-access source-probe barrier)

Let \(A_n=\mathcal L_{\mu_H,n}\subseteq\{0,1\}^N\), \(N=2^n\), with \(0<\mu_H<1\). Consider
a deterministic exact procedure whose only source dependence is through probes
\(\operatorname{read}(i)=f_i\); arbitrary deterministic work computation and one fixed
source-independent auxiliary oracle are allowed. If \(u_N\) is the maximum number of source
probes on one run and the procedure decides \(A_n\), then

\[
 \boxed{u_N\ge N-\log_2|A_n|=N-o(N).}
\]

#### Proof

Unroll the procedure into a source-query decision tree and fix any accepting leaf. If its path
queries the distinct coordinate set \(I\), every completion of the observed values on \(I\)
follows the same path, because the auxiliary oracle is fixed and source-independent. Hence an
entire subcube of size \(2^{N-|I|}\) lies in \(A_n\). Circuit enumeration gives
\(\log_2|A_n|=O(N^{\mu_H}\log N)=o(N)\), so
\(N-|I|\le\log_2|A_n|\), and \(|I|\le u_N\) proves the claim. \(\square\)

Thus every exact quotient/evaluator whose source dependence is charged as ordinary bit probes
must inspect \(N-o(N)\) source bits. This is a near-linear probe obstruction, not a
\(2\mu_H\)-time lower bound; source-dependent oracles \(O_f\), hidden RAM, and bounded-error
randomization remain outside the proposition.

### Proposition 26 (bounded-error source-probe boundary)

Let \(A\subseteq\{0,1\}^N\) be nonempty. A randomized procedure may perform arbitrary computation,
query one fixed source-independent auxiliary oracle, and access the source table only through
adaptive bit probes. Suppose its worst-case probe count is \(q\), its completeness is at least
\(1-\varepsilon_Y\) on \(A\), and its soundness is at most \(\varepsilon_N\) outside \(A\), with
\(\varepsilon_N<1-\varepsilon_Y\). Then

\[
 q\ge\left(1-\frac{\varepsilon_N}{1-\varepsilon_Y}\right)
 \log_2\frac{2^N}{|A|}.
\]

For symmetric error \(\varepsilon<1/2\), the coefficient is
\((1-2\varepsilon)/(1-\varepsilon)\). Applying circuit enumeration to
\(A=\mathcal L_{\mu_H,n}\) gives

\[
 q\ge\frac{1-2\varepsilon}{1-\varepsilon}(N-o(N));
\]

if the error is \(o(1)\), this is \(N-o(N)\).

#### Proof

For \(x\in A\), let \(B_x=\{i:x\oplus e_i\notin A\}\) and \(d_x=|B_x|\). Harper's
edge-isoperimetric inequality gives some \(x\in A\) with
\(d_x\ge\log_2(2^N/|A|)\). For each \(i\in B_x\), put \(y_i=x\oplus e_i\). On any random tape
where the computation accepts \(x\) and does not probe \(i\), the computation on \(y_i\) follows
the same adaptive path and also accepts. Summing over \(i\in B_x\) and averaging therefore gives

\[
 \sum_{i\in B_x}\Pr[M(y_i)=1]\ge(1-\varepsilon_Y)(d_x-q).
\]

The left side is at most \(\varepsilon_Nd_x\), since all \(y_i\notin A\). Rearranging proves the
claim; the case \(q\ge d_x\) is immediate. The singleton \(A=\{0^N\}\) with random coordinate
sampling shows the symmetric constant is asymptotically tight.

This closes fixed-error randomization only at a constant-factor probe level; it does not produce
the \(2\mu_H\)-time lower bound and does not cover source-dependent oracles or hidden RAM.

### Proposition 27 (charged-source interface factorization)

Let \(\Pi\) be a randomized interactive evaluator for \(A\subseteq\{0,1\}^N\), with fixed
source-independent advice and auxiliary oracle. It may perform arbitrary computation, query target
bits, exchange messages, and adaptively access the source only through explicit
\(\operatorname{read}(i)=x_i\) operations. If a target operation depends on \(w_j\) explicitly read
source bits, charge \(w_j\), and let
\[
 Q=q_{\mathrm{direct}}+\sum_j w_j
\]
be the total charged source-bit budget. Then
\[
 Q\ge
 \left(1-\frac{\varepsilon_N}{1-\varepsilon_Y}\right)
 \log_2\frac{2^N}{|A|}
\]
whenever completeness is at least \(1-\varepsilon_Y\), soundness is at most
\(\varepsilon_N\), and \(\varepsilon_N<1-\varepsilon_Y\).

For \(A=\mathcal L_{\mu_H,n}\), this gives \(Q\ge
(1-\varepsilon_N/(1-\varepsilon_Y))(N-o(N))\). Target-bit query count, target random access,
and finite communication do not weaken the bound when every source-dependent bit is charged.

#### Proof

Fix all random tapes. Once the charged source answers are fixed, every message, target address,
and target answer is fixed, so the whole interaction is a depth-\(Q\) source-bit decision tree.
Expand a \(w_j\)-bit source-dependent answer into its \(w_j\) underlying probes and apply the
boundary-neighbor proof of Proposition 26. \(\square\)

### Proposition 28 (conditional asynchronous handoff boundary)

Assume a source phase reads the \(N\)-bit table in known order, ends in one of \(W_Q\) complete
configurations, and hands an \(h\)-bit payload to a target phase that no longer reads the source.
Suppose the composition is a length-\(N\) known-order ROBP of width
\[
\mathfrak W\le (N+1)W_Q\,2^h
\]
(or \((N+1)W_QW_D2^h\) when target configurations are retained). Under the local-PRG interface
of Proposition 10, namely seed length
\(r=\widetilde O(\log(N\mathfrak W))\) and circuit complexity at most \(r\) for every generated
table, exact or bounded-error MCSP computation implies
\[
\boxed{h+\log_2W_Q=\widetilde\Omega(S).}
\]
If target configurations are retained explicitly in the width, the corresponding bound is
\[
\boxed{h+\log_2W_Q+\log_2W_D=\widetilde\Omega(S).}
\]

For bounded error, assume completeness \(1-\varepsilon_Y\), soundness \(\varepsilon_N\), and
\(\varepsilon_Y+\varepsilon_N+\eta_{\mathrm{PRG}}<1\), up to the \(o(1)\) uniform-NO
probability.

#### Proof

Fix random tapes before applying the ROBP generator and then average. If
\(r=o(S)\), every generated table lies in \(\mathcal L_{\mu_H,n}\), so completeness makes the
generator acceptance at least \(1-\varepsilon_Y\). Uniform acceptance is at most
\(\varepsilon_N+o(1)\). The gap
\(1-\varepsilon_Y-\varepsilon_N-o(1)\) exceeds the PRG error
\(\eta_{\mathrm{PRG}}\) by assumption, contradicting the fooling guarantee. Hence
\(\log(N\mathfrak W)=\widetilde\Omega(S)\), and the displayed width bound gives the claim.
\(\square\)

The payload must be fully charged as state. An uncharged source-dependent RAM, \(O_f\), or
random-access payload invalidates the ROBP width bound and is outside this proposition.

### Proposition 29 (interleaved charged-handoff boundary)

Consider a source-to-target protocol whose source input is read in known order
\(x_1,\ldots,x_N\). During the scan, the source side has at most \(W_Q\) complete source-dependent
configurations and the target side at most \(W_D\) complete configurations; these include finite
controls, work tapes, head/address positions, and scheduler phase. Every source-dependent object
outside these configurations is contained in a complete payload of at most \(h\) bits. The payload
includes its content, length/stop markers, addresses, timing metadata, and source-dependent query
or answer buffers. Source and target may update these objects in an arbitrary interleaved schedule,
but no source-dependent RAM or oracle is available outside the counted state. After the source scan
the target may continue without reading the source.

Fixing all random tapes, the protocol is a length-\(N\) known-order ROBP of width

\[
\boxed{\mathfrak W\le(N+1)W_QW_D2^h.}
\tag{29.1}
\]

Under the local-PRG interface of Proposition 10, every exact or bounded-error MCSP protocol in
this model satisfies

\[
\boxed{
h+\log_2W_Q+\log_2W_D=\widetilde\Omega(S),
\qquad S=N^{\mu_H}.
}
\tag{29.2}
\]

For bounded error assume completeness \(1-\varepsilon_Y\), soundness \(\varepsilon_N\), and
\(\varepsilon_Y+\varepsilon_N+\eta_{\mathrm{PRG}}<1\), up to the \(o(1)\) uniform-NO
probability.

#### Proof

At a source-prefix boundary \(t\in\{0,\ldots,N\}\), record
\((t,q_t,d_t,m_t)\), comprising the source control, target control, and the entire payload tape.
There are at most \((N+1)W_QW_D2^h\) records. Given a record and the next source bit, the
interleaved transition is fixed; a target-only suffix after the source end is absorbed into the
terminal label. Hence these records form a length-\(N\) known-order ROBP, proving (29.1).

Let \(r=\widetilde O(\log(N\mathfrak W))\) be the local-PRG seed length. If \(r=o(S)\), every
generated truth table lies in \(\mathcal L_{\mu_H,n}\), so completeness gives generator acceptance
at least \(1-\varepsilon_Y\). A uniform table is a NO instance with probability \(1-o(1)\), giving
acceptance at most \(\varepsilon_N+o(1)\). The gap
\(1-\varepsilon_Y-\varepsilon_N-o(1)\) exceeds \(\eta_{\mathrm{PRG}}\), contradicting the
fooling guarantee. Thus \(\log(N\mathfrak W)=\widetilde\Omega(S)\), and
(29.1) yields (29.2) after absorbing \(\log(N+1)\) into soft factors. \(\square\)

If the payload is only a pointer to source-dependent RAM, an oracle answer or a source-dependent
length/address is omitted from the counted state, or a one-bit operation may compute an arbitrary
predicate of unread source bits, the width bound fails. The protocol
\(m(x)=\mathbf1_A(x)\), \(W_Q=W_D=1\), \(h=1\) then decides \(A\) with a source-independent
target; this is a hidden channel rather than a counterexample to (29.1)--(29.2).

### Corollary 30 (fixed-alphabet time--space--payload boundary)

Assume the interleaved model of Proposition 29 is implemented by fixed source and target
machines with standard contiguous work tapes: finite control, alphabet, tracks, and number of heads
are independent of \(N\). Let their work tapes use at most \(s_Q\) and \(s_D\) cells, let total running time be at most
\(T\ge N\), and assume every source-dependent object outside finite controls is in the counted
\(h\)-bit payload. Suppose every target address or head position lies in a range of size at most
\(N'+T+O(1)\), with \(N'=N^{O(1)}\). Under the same local-PRG and error assumptions,

\[
\boxed{
h+s_Q+s_D+\log_2(N'+T)=\widetilde\Omega(S),
\qquad S=N^{\mu_H}.
}
\tag{30.1}
\]

In particular, if \(T=N^{O(1)}\), then

\[
\boxed{h+s_Q+s_D=\widetilde\Omega(S).}
\tag{30.2}
\]

If \(h+s_Q+s_D=o(S)\), then \(T=2^{\widetilde\Omega(S)}\).

#### Proof

For fixed finite alphabets and fixed finite control,

\[
\log_2W_Q=O(s_Q+\log(N+T)),
\qquad
\log_2W_D=O(s_D+\log(N'+T)).
\]

Substituting these configuration counts into Proposition 29 gives

\[
\log(N\mathfrak W)
\le O\bigl(h+s_Q+s_D+\log(N'+T)\bigr).
\]

The lower bound \(\log(N\mathfrak W)=\widetilde\Omega(S)\) proves (30.1). If
\(T,N'=N^{O(1)}\), the logarithmic term is \(O(\log N)=o(S)\), proving (30.2). Rearranging
(30.1) under \(h+s_Q+s_D=o(S)\) gives
\(\log(N'+T)=\widetilde\Omega(S)\), and the polynomial bound on \(N'\) yields
\(T=2^{\widetilde\Omega(S)}\).

A control family growing with \(N\), sparse-RAM address entropy, or an address range, shared RAM,
random seed, or source-dependent pointer omitted from the counted state recreates the hidden-channel
counterexample of Proposition 29. Thus this is a conditional full \(S\)-scale state boundary,
not an unconditional one-tape lower bound or a proof of \(P\ne NP\).

### Proposition 31 (hidden continuation complexity boundary)

Fix a source-independent random tape, target input, oracle, and scheduler, together with a
known-order source scan of length \(N\). The initial
complete state is independent of the unread source, and every source-dependent object is created
causally by transitions from the current state and the next scanned source bit; no source-dependent
advice, preloaded RAM, or \(O_x\) is allowed. At source-prefix time \(t\), let \(v\) be a visible
record consisting of the complete counted source/target configurations and payload. Hidden
source-dependent objects may remain outside \(v\). For every reachable complete history \(C\) with
record \((t,v)\), define its future acceptance residual

\[
F_C:\{0,1\}^{N-t}\longrightarrow\{0,1\},
\qquad
F_C(z)=\text{the final decision on continuation }z.
\]

Let

\[
R=\max_{t,v}\left|\{F_C:C\text{ reaches }(t,v)\}\right|.
\tag{31.1}
\]

Then the protocol has an equivalent length-\(N\) known-order ROBP of width

\[
\boxed{\mathfrak W\le(N+1)W_QW_D2^hR.}
\tag{31.2}
\]

Under the local-PRG interface of Proposition 10, every exact or bounded-error MCSP protocol
satisfies

\[
\boxed{
h+\log_2W_Q+\log_2W_D+\log_2R
=\widetilde\Omega(S),
\qquad S=N^{\mu_H}.
}
\tag{31.3}
\]

For bounded error retain
\(\varepsilon_Y+\varepsilon_N+\eta_{\mathrm{PRG}}<1\), up to the \(o(1)\) uniform-NO
probability, and require the same width bound for every fixed source-independent random tape.

#### Proof

At layer \(t\), each visible record \(v\) contributes at most \(R\) residual functions, so the
total number of distinct residual functions is at most
\((N+1)W_QW_D2^hR\). Use these functions themselves as ROBP states. On input bit \(b\), send
\(F\) to

\[
\delta_t(F,b)(z)=F(bz),
\]

and at \(t=N\) use \(F(\epsilon)\) as the terminal label. The derivative is independent of the
history representing \(F\), so the resulting branching program is well-defined and proves (31.2).

Apply the local-PRG argument of Proposition 10 to this ROBP. If
\(\log(N\mathfrak W)=o_{\widetilde{\ }}(S)\), every generated table is in the MCSP YES class,
whereas a uniform table is NO with probability \(1-o(1)\). The acceptance gap
\(1-\varepsilon_Y-\varepsilon_N-o(1)\) exceeds \(\eta_{\mathrm{PRG}}\), contradicting the
fooling guarantee. Thus \(\log(N\mathfrak W)=\widetilde\Omega(S)\). Absorb the
polynomial \(N\)-factors in (31.2) to obtain (31.3). \(\square\)

If all source-dependent data is already in the visible complete state, \(R=1\) and Proposition 31
reduces to Proposition 29. If a pointer, RAM cell, query string, scheduler, or answer buffer is
omitted, \(R\) measures the number of distinct future acceptance behaviors that the omission can
hide. Any causally generated hidden channel that evades the visible-state barrier must therefore
pay

\[
\log_2R=\widetilde\Omega(S)-h-\log_2W_Q-\log_2W_D.
\]

This is a semantic continuation lower bound, not a time lower bound: an arbitrary preloaded oracle
may compute a difficult predicate and emit one bit while having only two final residual labels.
To turn (31.3) into a machine lower bound, the hidden transition mechanism itself must be charged
through Proposition 30 or an equivalent computational model. If future messages, addresses,
timing, or oracle transcripts are part of the required observable, replace \(F_C\) by full-trace
residuals; the same right-congruence proof applies with a possibly larger \(R\).

### Proposition 32 (finite hidden-state completion)

In Proposition 31, suppose the hidden continuation mechanism is a fixed finite-control machine
with a fixed finite alphabet and a constant number of heads, using at most \(s_H\) contiguous
work-tape cells and at most \(T_H\) transitions. Assume that its initial state is independent of
the unread source and that each transition depends only on the complete current state and the
next source bit. Let all address domains and scheduler phases have at most
\(\operatorname{poly}(N+T_H)\) possibilities. Finally, let \(L_H\) be the total information in
source-dependent irreversible output, write-only buffers, or scheduler traces that can still affect
future acceptance, and assume this information is either included in the hidden state or charged
as part of the model.

Then

\[
R\le 2^{O(s_H+L_H+\log(N+T_H))}.
\tag{32.1}
\]

Consequently, if \(T_H\le T\),

\[
\boxed{
h+\log_2W_Q+\log_2W_D+s_H+L_H+\log_2(N+T)
=\widetilde\Omega(S).
}
\tag{32.2}
\]

For fixed-alphabet contiguous source and target tapes, replacing the two configuration terms by
their tape sizes gives

\[
\boxed{
h+s_Q+s_D+s_H+L_H+\log_2(N+T)
=\widetilde\Omega(S).
}
\tag{32.3}
\]

#### Proof

At a fixed layer, the hidden complete state is determined by its finite control, the symbols in
its \(s_H\) tape cells, its constant number of head positions, its scheduler phase, and the
charged irreversible information. The first two contributions are \(O(s_H)\) bits, while the
polynomial address and phase domains contribute \(O(\log(N+T_H))\) bits. Thus the number of
hidden states compatible with any visible record is at most
\(2^{O(s_H+L_H+\log(N+T_H))}\). Each such state induces at most one acceptance residual, so
(32.1) follows from Proposition 31. Substitution into (31.3), followed by the fixed-alphabet
configuration count of Corollary 30, gives (32.2)--(32.3). \(\square\)

The charge \(L_H\) is necessary. A machine may stream the entire source into an uncharged
append-only output tape using \(O(1)\) work cells and \(O(N)\) time; the output history then carries
\(\Theta(N)\) bits and can yield \(R=2^{\Theta(N)}\), despite
\(s_H+\log(N+T_H)=O(\log N)\). If the output or timing trace never affects future acceptance,
it need not be charged for the acceptance-residual version; full-trace equivalence instead charges
the entire required transcript. Proposition 32 is therefore a conditional machine-resource
boundary, not an unconditional time lower bound or a proof of \(P\ne NP\).

### Proposition 33 (unconditional strong-local residual boundary)

Let \(0<\mu_H<1\), \(S=N^{\mu_H}\), and consider an exact known-order ROBP for
\(\mathrm{MCSP}_{S}\) with width \(\mathfrak W\). Assume \(\mu_H>1/2\). Then

\[
\boxed{
\log_2\mathfrak W
\ge (2\mu_H-1)\log_2N-O\!\left((\log N)^{2/3}\right).
}
\tag{33.1}
\]

Consequently, every exact protocol satisfying the hypotheses of Proposition 31 obeys the
unconditional bound

\[
\boxed{
h+\log_2W_Q+\log_2W_D+\log_2R
\ge (2\mu_H-1)\log_2N-O\!\left((\log N)^{2/3}\right).
}
\tag{33.2}
\]

#### Proof

Cheraghchi--Kabanets--Lu--Myrisiotis construct, for every branching-program size \(s\ge N\), a
local PRG whose output bits have circuit complexity
\[
\lambda(s)\le s^{1/2}2^{O((\log s)^{2/3})}
\]
and which fools every size-\(s\) branching program with constant additive error. Pad a smaller
program to size \(\max\{s,N\}\). If \(\lambda(\max\{s,N\})<S\), every PRG output is an
\(\mathrm{MCSP}_{S}\) YES instance, while a uniform \(N\)-bit table is NO with probability
\(1-o(1)\), by circuit enumeration. The resulting acceptance gap contradicts the constant-error
fooling guarantee. Hence
\[
s^{1/2}2^{O((\log s)^{2/3})}\ge S,
\]
which implies
\[
\log_2s\ge2\mu_H\log_2N-O((\log N)^{2/3}).
\]
Taking \(s\le(N+1)\mathfrak W\) gives (33.1). Substitution of the residual width bound (31.2)
gives (33.2). \(\square\)

For a bounded-error protocol, fix source-independent random tapes and assume the same width bound
for every tape. Let \(\eta_{\mathrm{CKLM}}\) be the additive fooling error
(\(\eta_{\mathrm{CKLM}}=1/3\) in the stated CKLM construction), and let
\(\delta_A=\Pr_{x\sim U_N}[x\in\mathrm{MCSP}_S]=o(1)\). If
\[
\varepsilon_Y+\varepsilon_N+\eta_{\mathrm{CKLM}}+\delta_A<1,
\]
average the CKLM fooling inequality over the random tape: every PRG output is a YES instance, so
the generator acceptance is at least \(1-\varepsilon_Y\), while uniform acceptance is at most
\(\varepsilon_N+\delta_A\). The same contradiction gives (33.2). For arbitrary fixed gap
\(\varepsilon_Y+\varepsilon_N<1\), constant independent repetition and thresholding reduce the
errors to this regime; the resulting bound has the same \(\log N\) order, with a
constant-factor loss depending only on the original errors.

This result is unconditional but only logarithmic in the source-table length. Reaching the
\(\widetilde\Omega(S)\) residual-information barrier still requires the stronger local-PRG
interface of Proposition 10; Proposition 33 does not prove \(P\ne NP\).

### Proposition 34 (affine-residual route boundary)

Let \(A\subseteq\{0,1\}^N\), let \(t\) be a cut, and write \(m=N-t\). For each prefix
\(u\in\{0,1\}^t\), let \(F_u(z)=1_A(uz)\). Suppose every \(F_u\) is affine over
\(\mathbb F_2\), and let \(r_t\) be the number of distinct residuals. Then

\[
\boxed{
r_t\le 1+2|A|\,2^{-m}.
}
\tag{34.1}
\]

In particular, if \(|A|\le2^L\), then
\[
\log_2 r_t\le \max\{0,L-m+1\}+1.
\tag{34.2}
\]
For \(A=\mathrm{MCSP}_S\), circuit enumeration gives
\(L=O(S\log(N+S))\). Hence affine residuals cannot supply
\(2^{\Omega(S)}\) distinct states while the unread suffix has length
\(m\gg S\log N\).

#### Proof

The cylinders \(u\{0,1\}^m\) belonging to distinct prefixes are disjoint, so their fiber
cardinalities sum to at most \(|A|\). Every nonzero affine Boolean function on \(m\) variables
has support of size \(2^{m-1}\) or \(2^m\); at most one residual is zero. Summing the supports of
one representative from each nonzero residual gives
\((r_t-1)2^{m-1}\le|A|\), proving (34.1) and (34.2). \(\square\)

The bound is sharp as a route obstruction. Let \(B=2^{n-k}\) and let \(K_k\) be the tables
constant on each of the \(2^k\) consecutive \(B\)-blocks. Then \(K_k\) is a linear subspace of
dimension \(2^k\), and membership in \(K_k\) has a constant-width known-order ROBP. By the
Lupanov upper bound for arbitrary \(k\)-variable functions, choose \(k\) with
\(c2^k/k\le S\). Then \(2^k=\Theta(S\log S)\), every member of \(K_k\) lies in
\(\mathrm{MCSP}_S\), and
\(\log_2|K_k|=\Theta(S\log S)\), the full MCSP YES-entropy scale, yet the residual width remains
constant. Thus affine YES structure, sparsity, and XOR closure do not by themselves produce the
required NO cross-combinations; an \(S\)-scale residual theorem must use genuinely non-affine
structure or an additional pseudorandomness/complexity interface.

### Proposition 35 (restricted additive energy for cross-combinations)

Let \(\varnothing\ne A=\mathcal L_{n,S}\subseteq\mathbb F_2^N\), and let
\(\varnothing\ne R\subseteq\mathbb F_2^N\) be any finite family of candidate shifts. Define

\[
 E_A(R):=\sum_{r\in R}|A\cap(A\oplus r)|,
 \qquad
 \theta_A(R):=\frac{E_A(R)}{|A|\,|R|}.
\]

Then

\[
 \Pr_{r\in R,\,a\in A}[r\oplus a\notin A]
 =1-\theta_A(R)
 \ge\max\!\left\{0,1-\frac{|A|}{|R|}\right\}.
 \tag{35.1}
\]

If circuit complexity has the usual additive XOR composition
\(\operatorname{CC}(f\oplus g)\le\operatorname{CC}(f)+\operatorname{CC}(g)+C_\oplus\), then

\[
 R\subseteq\mathcal L_{n,2S+C_\oplus}^{\,c}
 \quad\Longrightarrow\quad
 \theta_A(R)=0.
 \tag{35.2}
\]

#### Proof

The map \((r,a)\mapsto(r\oplus a,a)\) injects
\(\{(r,a):r\in R,\,a\in A,\,r\oplus a\in A\}\) into \(A\times A\). Hence
\(E_A(R)\le|A|^2\), proving (35.1). If \(r\oplus a\in A\) with \(r\in R\) in
(35.2), XOR composition would give \(\operatorname{CC}(r)\le2S+C_\oplus\), a contradiction.
\(\square\)

For the low-weight YES family \(\mathbb B_q\subseteq A\) of Proposition 6, put
\(R_q=(A+\mathbb B_q)\setminus A\). Equations (3l.32)--(3l.34) imply
\[
 \log_2\frac{|A+\mathbb B_q|}{|A|}
 \ge\left(\frac{1-\mu_H}{2}-o(1)\right)S,
\]
so (35.1) gives
\[
 \Pr_{r\in R_q,\,a\in A}[r\oplus a\notin A]
 \ge1-2^{-((1-\mu_H)/2-o(1))S+1}.
 \tag{35.3}
\]
Thus the full MCSP YES set admits a canonically defined exponentially oversized family of shifts whose
cross-combinations are overwhelmingly NO. This remains a semantic statement, not a residual-width
lower bound: when \(|R|\le|A|\), (35.1) is vacuous. The exact missing interface is an
MCSP-specific bound on \(E_A(R)\) for such small residual families; non-affinity and YES entropy
alone do not provide it.

### Proposition 36 (random-shift energy baseline)

For a proper nonempty \(A\subsetneq\mathbb F_2^N\), let
\(m_A(r)=|A\cap(A\oplus r)|\). Since
\[
 \sum_{r\in\mathbb F_2^N}m_A(r)=|A|^2,
\]
uniformly random \(r\in A^c\) satisfies
\[
 \mathbb E[m_A(r)]\le\frac{|A|^2}{2^N-|A|}.
 \tag{36.1}
\]
For \(t\) shifts sampled without replacement from \(A^c\), Markov gives
\[
 \Pr\!\left[\frac{E_A(R)}{t|A|}\ge\delta\right]
 \le\frac{|A|}{\delta(2^N-|A|)}.
 \tag{36.2}
\]
Thus random NO shifts have exponentially small energy for sparse MCSP, but this is not a
uniform statement about an adversarial or generated residual family.

### Proposition 37 (stabilizer-free generic obstruction)

The preceding random baseline cannot be upgraded from generic structure alone. Let \(K\ne\{0\}\)
be a subspace, let \(a,b\) be independent in \(\mathbb F_2^2\), and put \(c=a+b\). In
\(G=(\mathbb F_2^2\times K)\times\mathbb F_2\), choose \(p\in\mathbb F_2^2\times K\) and define
\[
 A=\bigl(((\{0,a,b\}\times K)\times\{0\})\bigr)\cup\{(p,1)\},
 \qquad
 R=(\{c\}\times K)\times\{0\}.
\]
Then \(R'=R\setminus\{(c+k_0,0)\}\subseteq A^c\) is non-affine for \(|K|\ge4\), with
\(|R'|=|K|-1\), \(|A|=3|K|+1\), \(\operatorname{Stab}(A)=\{0\}\), and
\[
 \frac{E_A(R')}{|A|\,|R'|}
 =\frac{2|K|}{3|K|+1}\longrightarrow\frac23.
 \tag{37.1}
\]
Here \(R=(\{c\}\times K)\times\{0\}\), and every \(r\in R'\) swaps the \(a+K\) and \(b+K\) slices and misses the \(0+K\) slice;
the singleton marker makes the global stabilizer trivial.

This is not an MCSP counterexample: embedding the three-coset pattern into the full
\(\mathrm{MCSP}_S\) set would require a new circuit lower bound for the fourth coset. It does
show that non-affinity, high entropy, stabilizer-freeness, and \(|R|\le|A|\) do not imply
restricted-energy decay. The remaining bound must use MCSP-specific circuit structure.

### Proposition 38 (middle-cut equality gadget)

Let \(N=2m\), let \(A\subseteq\{0,1\}^{N}\), and let
\(H\subseteq\{0,1\}^{m}\) satisfy \(h\Vert h\in A\) for every \(h\in H\). Join distinct
\(h,g\in H\) if \(h\Vert g\in A\) or \(g\Vert h\in A\). Since concatenation is injective, this
graph has at most \(|A|\) edges. Hence a middle-cut ROBP for \(1_A\) has width
\[
 \boxed{
 W_{N/2}(A)\ge\frac{|H|^2}{2|A|+|H|}.
 }
 \tag{38.1}
\]

Indeed, an independent set \(I\) of prefixes has distinct residuals: \(h\Vert h\) is YES, while
\(h\Vert g\) is NO for every distinct \(h,g\in I\). The greedy independent-set bound gives
\(|I|\ge|H|^2/(2|A|+|H|)\).

For \(A=\mathrm{MCSP}_S\), choose \(H\) from \((n-1)\)-variable tables whose duplicated
functions fit the \(S\)-gate budget. Then
\[
 \log W_{N/2}(\mathrm{MCSP}_S)
 \ge
 2\log|\mathcal L_{n-1,S-O(1)}|
 -\log\!\left(2|\mathcal L_{n,S}|+
 |\mathcal L_{n-1,S-O(1)}|\right).
 \tag{38.2}
\]
Thus an \(S\)-scale middle-cut barrier follows as soon as the half-table YES entropy exceeds one
half of the full-table YES entropy by an \(S\)-scale margin.  Propositions 43--44 below settle
this comparison with matching leading coefficient one in the exponential-threshold regime, and
Theorem 45 obtains the tight lexicographic-order width.  Equation (38.2) is the unconditional
reduction used there, not a proof of \(P\ne NP\).
The half-entropy threshold is sharp for the diagonal method itself: the diagonal-only set
\(\{h\Vert h:h\in H\}\) has width \(|H|\), whereas the product set \(H\Vert H\) has the same
diagonal YES family but width \(1\). Any further improvement must exploit MCSP-specific mixed-pair
structure.

### Proposition 39 (XOR expansion does not control residual width)

Let \(B_t=\{x\in\mathbb F_2^t:|x|\le\lfloor t/4\rfloor\}\) and
\(A=B_t\times\{0^m\}\).  At the cut after the first \(t\) bits, every residual is either
\(1_{\{0^m\}}\) or \(0\), so the residual width is at most \(2\).  Nevertheless
\[
 A+A=(B_t+B_t)\times\{0^m\},
 \qquad
 \log_2\frac{|A+A|}{|A|}
 \ge \bigl(1-H_2(1/4)-o(1)\bigr)t.
 \tag{39.1}
\]
Thus exponential XOR expansion is not a residual-width lower bound.

### Proposition 40 (splice-to-XOR is an additional hypothesis)

To turn Harper's high XOR complexity into cross-NO pairs, one must prove a loss-\(\rho\)
interface
\[
 u_i\Vert z_j\in A
 \quad\Longrightarrow\quad
 \operatorname{CC}(x_i\oplus x_j)\le S+\rho .
 \tag{40.1}
\]
Then \(\operatorname{CC}(x_i\oplus x_j)>S+\rho\) forces \(u_i\Vert z_j\notin A\).  A generic
truth-table splice has no reason to satisfy (40.1): it combines a prefix and suffix from
different tables, whereas XOR combines complete tables.  Proposition 39 therefore closes the
set-theoretic Harper/XOR shortcut; the remaining residual problem must use MCSP-specific
mixed-pair circuit structure or establish a new splice-to-XOR reduction.

### Proposition 41 (selector-lift equality bound)

Let \(H\) be a family of \(r\)-variable tables embedded into the \((n-1)\)-variable halves,
with \(h\Vert h\in\mathrm{MCSP}_S\) for every \(h\in H\).  A mixed pair \(h,g\) accepted at
the middle cut determines an \((r+1)\)-variable selector function, so the number of accepted
ordered pairs is at most \(|\mathcal L_{r+1,S}|\).  Hence
\[
 W_{N/2}(\mathrm{MCSP}_S)
 \ge
 \frac{|H|^2}{2|\mathcal L_{r+1,S}|+|H|}.
 \tag{41.1}
\]
Taking \(H\) to be all \(r\)-variable tables fitting in \(S-O(1)\) is the sharpest
selector-scale form of the equality gadget currently available.

### Proposition 42 (multiblock equality has no exponential gain)

For \(N=km\), take diagonal tables \(h^{\Vert k}\) and join \(h\ne g\) whenever any
nonconstant binary block pattern \(T_p(h,g)\) is in \(A\).  For fixed \(p\), the map
\((h,g)\mapsto T_p(h,g)\) is injective, so
\[
 |E|\le(2^k-2)|A|,
 \qquad
 W_m(A)\ge
 \frac{|H|^2}{2(2^k-2)|A|+|H|}.
 \tag{42.1}
\]
Thus fixed \(k\), or \(k=o(S)\), changes only a subexponential factor.  Moreover, if
\(\operatorname{CC}(h),\operatorname{CC}(g)\le(S-C_k)/2\), then every fixed-pattern splice
has complexity at most \(S\) after a selector of cost \(C_k\); this low-complexity core has a
complete mixed graph and yields no fooling set.

### Proposition 43 (sharp semantic circuit enumeration)

For the standard single-output basis \(\{\mathsf{AND},\mathsf{OR},\mathsf{NOT}\}\), write
\(a_m(s)=\log_2|\mathcal L_{m,s}|\).  Then
\[
 a_m(s)
 \le (s+1)\log_2(m+s+2)+O(s).
 \tag{43.1}
\]
In particular, if \(s\ge m^2\), then
\[
 a_m(s)\le s\log_2s+O(s).
 \tag{43.2}
\]

To prove this, prune every gate that does not reach the unique output.  For each non-output
gate choose one actual consumer-pin occurrence.  Acyclicity and reachability force the chosen
\(q-1\) incidences of a \(q\)-gate circuit to form a rooted plane binary slot-tree directed
toward the output.  There are fewer than \(4^q\) tree shapes.  If the circuit has \(b\) binary
and \(u\) unary gates, then its \(2b+u\) input pins contain the \(q-1\) tree pins and only
\[
 (2b+u)-(q-1)=b+1\le q+1
\]
free pins.  Tree paths canonically name the gates, so after recording the gate types every free
pin has at most \(m+q+2\) sources.  Thus the number of codes is at most
\[
 4^q3^q(m+q+2)^{q+1}
 \le12^q(m+q+2)^{q+1}.
 \tag{43.3}
\]
The code uniquely decodes the pin multigraph; invalid cyclic codes and multiple possible tree
choices only overcount.  Summing (43.3) over \(q\le s\) proves (43.1), and \(s\ge m^2\)
gives (43.2).  This does not rely on the invalid assertion that every circuit has \(q!\)
topological orders: a chain has only one, but its tree already fixes \(q-1\) pins.

### Proposition 44 (packed-selector semantic lower bound)

If
\[
 m\ge\log_2s+\log_2\log_2s+O(1),
 \tag{44.1}
\]
then
\[
 a_m(s)
 \ge s\log_2s-O(s\log_2\log_2s).
 \tag{44.2}
\]
Hence in the range (44.1) and \(s\ge m^2\),
\[
 a_m(s)=(1+o(1))s\log_2s.
 \tag{44.3}
\]

Put \(L=\log_2s\), \(q=\lfloor L-3\log_2L\rfloor\), and let
\[
 U_q=\left(1+O\!\left(\frac{\log q}{q}\right)\right)\frac{2^q}{q}+O(1)
\]
be Lupanov's uniform size bound for \(q\)-variable functions.  Set
\[
 k=\left\lfloor\frac{s}{U_q+7}\right\rfloor,
 \qquad t=\lceil\log_2k\rceil.
\]
For each tuple \((f_1,\ldots,f_k)\) of arbitrary \(q\)-variable functions, a complete binary
multiplexer on \(t\) address bits selects one component.  Reuse \(f_1\) at unused leaves.
After sharing one negation of each address bit, the multiplexer costs at most
\(3(2^t-1)+t\le7k\) gates.  Restricting the address recovers every \(f_i\), so the
tuple-to-function map is injective.  The resulting family \(H\) therefore satisfies
\[
 \log_2|H|=k2^q
 \ge s\log_2s-O(s\log_2\log_2s),
 \tag{44.4}
\]
and it uses only
\[
 q+t=\log_2s+\log_2\log_2s+O(1)
\]
variables.  This proves the proposition.

### Theorem 45 (tight lexicographic-order OBDD width)

Fix \(0<\mu<1\), put \(N=2^n\), and let \(S=\lfloor2^{\mu n}\rfloor\).  For the
lexicographic truth-table order,
\[
 \boxed{
 \log_2W^{\mathrm{lex}}_{N/2}(\mathrm{MCSP}_S)
 =(1+o(1))S\log_2S.
 }
 \tag{45.1}
\]
The minimum lexicographic-order OBDD size has the same logarithmic asymptotic.

Indeed, Proposition 44 supplies a family \(H\) on
\[
 r=\log_2S+\log_2\log_2S+O(1)=\mu n+O(\log n)<n-1
\]
variables with
\[
 \log_2|H|\ge S\log_2S-O(S\log\log S).
\]
Dummy-embed \(H\) into each half-table.  Every diagonal \(h\Vert h\) ignores the leading
variable and lies in \(\mathrm{MCSP}_S\).  Proposition 38 gives
\[
 W^{\mathrm{lex}}_{N/2}(\mathrm{MCSP}_S)
 \ge\frac{|H|^2}{2|\mathcal L_{n,S}|+|H|}.
 \tag{45.2}
\]
Since \(S\ge n^2\), Proposition 43 gives
\(\log_2|\mathcal L_{n,S}|\le S\log_2S+O(S)\), and (45.2) proves the lower bound in
(45.1).  Conversely, the prefix trie of \(\mathcal L_{n,S}\) has at most
\(|\mathcal L_{n,S}|\) live states and one dead state on every layer.  Hence
\[
 W^{\mathrm{lex}}_{N/2}(\mathrm{MCSP}_S)
 \le |\mathcal L_{n,S}|+1
 \le2^{S\log_2S+O(S)},
\]
and its total size is at most \(N(|\mathcal L_{n,S}|+1)\).

Theorem 45 is the deterministic lexicographic-order statement.  The next Fourier quotient
removes the prescribed-order restriction.

### Proposition 46 (balanced-cut linear quotient)

Let \(P\sqcup Q=\mathbb F_2^n\) with \(|P|=|Q|=2^{n-1}\).  For every \(1\le r<n\), there
is a surjective linear map \(L:\mathbb F_2^n\to\mathbb F_2^r\) for which the number \(B_L\)
of labels whose fibers lie wholly in \(P\) or wholly in \(Q\) satisfies
\[
 \boxed{
 |B_L|\le2^r\frac{2^r-1}{2^n-1}.
 }
 \tag{46.1}
\]

Put \(\chi=1_P-1_Q\), and normalize
\(\widehat\chi(\alpha)=\mathbb E_x\chi(x)(-1)^{\alpha\cdot x}\).  For a codimension-\(r\)
subspace \(K\), let \(b_{x+K}=\mathbb E_{k\in K}\chi(x+k)\).  Conditional expectation and
Parseval give
\[
 \mathbb E_{x+K}b_{x+K}^2
 =\sum_{\alpha\in K^\perp}\widehat\chi(\alpha)^2.
 \tag{46.2}
\]
A monochromatic coset contributes one to the left side.  For a uniform \(r\)-dimensional
\(K^\perp\), each nonzero character is included with probability
\((2^r-1)/(2^n-1)\).  Since balance gives \(\widehat\chi(0)=0\), Parseval shows that the
expected right side of (46.2) is exactly this probability.  Some \(K\) attains at most the
expectation, proving (46.1).

### Theorem 47 (tight ordered nondeterministic and algebraic width)

Under the parameters of Theorem 45, fix any permutation \(\pi\) of the \(N\) truth-table
coordinates.  Consider the following strictly layered models:

- a deterministic OBDD reading \(\pi(1),\ldots,\pi(N)\);
- a \(\pi\)-NOBDD has layers \(V_0,\ldots,V_N\), and every edge from \(V_{i-1}\) to \(V_i\)
  reads \(\pi(i)\); it accepts exactly when there is a consistent \(V_0\)-to-\(V_N\) path;
- a parity OBDD uses the same layers and accepts exactly when the number of consistent paths is
  odd;
- an ordered algebraic branching program over a field \(\mathbb F\) uses the same layers and its
  source--sink path-sum equals the characteristic function of \(\mathrm{MCSP}_S\) exactly.

For every one of these models \(\mathsf M\),
\[
 \boxed{
 \log_2W^{\pi,\mathsf M}_{N/2}(\mathrm{MCSP}_S)
 =(1+o(1))S\log_2S.
 }
 \tag{47.1}
\]
Consequently, after optimizing the variable order, the minimum width and minimum total size in
each model have the same logarithmic asymptotic:
\[
\boxed{
 \log_2\operatorname{width}_{\mathsf M}(\mathrm{MCSP}_S)
 =\log_2\operatorname{size}_{\mathsf M}(\mathrm{MCSP}_S)
 =(1+o(1))S\log_2S.
}
\tag{47.2}
\]

Let \(P\) be the first \(N/2\) coordinates under \(\pi\) and \(Q\) the rest.  Reserve
\(O(n^2)\) gates, and apply Proposition 44 at budget \(S_0=S-O(n^2)\).  Its packed-selector
construction has
\[
 r=\log_2S+\log_2\log_2S+O(1)<n
\]
variables and a set \(T\subseteq\mathbb F_2^r\) of freely assignable cells with
\[
 |T|=S\log_2S-O(S\log\log S),
 \qquad
 2^r=O(S\log S).
 \tag{47.3}
\]
Choose \(L\) by Proposition 46.  Its monochromatic labels satisfy
\[
 |B_L|
 =O\!\left(\frac{2^{2r}}N\right)
 =O\!\left(\frac{S^2\log^2S}{N}\right)
 =o(S),
 \tag{47.4}
\]
because \(S=N^\mu\) and \(\mu<1\).  Fix the cells in \(T\cap B_L\) to zero and let every
other cell of \(T\) vary.  Compose each resulting function \(h\) with \(L\).  Computing the
\(r\) linear forms of \(L\) costs \(O(nr)=O(n^2)\) gates over the standard basis, so
\[
 \mathcal H_{P,Q}=\{h\circ L\}\subseteq\mathcal L_{n,S},
 \qquad
 \log_2|\mathcal H_{P,Q}|
 \ge S\log_2S-O(S\log\log S).
 \tag{47.5}
\]
Every remaining free fiber meets both \(P\) and \(Q\).  Hence both restriction maps
\(f\mapsto f|_P\) and \(f\mapsto f|_Q\) are injective on \(\mathcal H_{P,Q}\).

Join distinct \(f,g\in\mathcal H_{P,Q}\) if either cross-table
\(f|_P\cup g|_Q\) or \(g|_P\cup f|_Q\) belongs to \(\mathcal L_{n,S}\).  The ordered
cross-table map is injective by the two restriction injectivities, so the graph has at most
\(|\mathcal L_{n,S}|\) edges.  It has an independent set \(I=I_\pi\) satisfying
\[
 |I|
 \ge
 \frac{|\mathcal H_{P,Q}|^2}
 {2|\mathcal L_{n,S}|+|\mathcal H_{P,Q}|},
 \qquad
 \log_2|I|
 \ge S\log_2S-O(S\log\log S).
 \tag{47.6}
\]
The cut communication matrix restricted to rows \(f|_P\) and columns \(g|_Q\), \(f,g\in I\),
is exactly the identity:
\[
 \mathbf 1_{\mathcal L_{n,S}}(f|_P\cup g|_Q)
 =\mathbf 1[f=g].
 \tag{47.7}
\]

For a \(\pi\)-NOBDD, its middle states factor the accepted pairs in (47.7) into Boolean
rectangles.  Each such rectangle contains at most one diagonal entry, so the middle width is at
least \(|I|\).  Equivalently, two diagonal accepting paths cannot share a middle state: splicing
the prefix of one with the suffix of the other would accept a forbidden off-diagonal table.

For a field-weighted program, let \(U_{f,s}\) be the sum of the weights of all prefix paths from
the source to middle state \(s\) on \(f|_P\), and let \(V_{s,g}\) be the corresponding suffix
path-sum.  Splitting paths at the cut gives
\[
 I_{|I|}=UV,
 \qquad
 |I|=\operatorname{rank}_{\mathbb F}(I_{|I|})\le |V_{N/2}|.
 \tag{47.8}
\]
Parity is the case \(\mathbb F=\mathbb F_2\).  Deterministic residual separation is the special
case already used in Theorem 45.  Equations (43.2) and (47.6)--(47.8) prove the lower bound in
(47.1).  The deterministic trie from Theorem 45 is a valid program in every listed model and
gives the matching width and size upper bounds.

The quantifier order is
\[
 \forall\pi\ \exists L_\pi\ \exists\mathcal H_\pi\ \exists I_\pi\
 \forall\text{ strictly layered }\pi\text{-programs }B.
 \tag{47.9}
\]
The witnesses depend only on the middle cut, not on \(B\), but they are not shared by all orders.
The theorem does not cover free or path-dependent 1-NBPs, co-nondeterministic programs, general
branching programs, bounded-error randomized programs, or one-tape computation.  CHMY's
\(\Omega(N^{1.5}/\log N)\) lower bounds for general nondeterministic and parity branching
programs concern MKTP and MKtP, not MCSP.  For MCSP they prove an exponential
co-nondeterministic read-once lower bound and note an implicit exponential deterministic ROBP
lower bound.  Glinskih--Riazanov prove \(N^{\Omega(\log\log N)}\) for the
stronger path-dependent 1-NBP model, with a tight result at a linear threshold.  The contribution
here is the common identity-submatrix witness and the asymptotically tight \(S\log S\) exponent
for every fixed global order at an exponential threshold.

### Proposition 48 (one-tape time gives only total configuration entropy)

Let a deterministic CHMY-model machine decide a length-\(N\) function in time \(T\).  At any
canonical input cut \(t\),
\[
 \log_2W_t^{\mathrm{lex}}(f)=O(T).
 \tag{48.1}
\]
If every configuration at the first crossing of the cut has visited a work-tape interval of
length at most \(B\), then
\[
 \log_2W_t^{\mathrm{lex}}(f)=O(B+\log T).
 \tag{48.2}
\]

Indeed, record the full configuration immediately before the one-way input head first reads bit
\(t+1\).  Equal configurations have equal suffix continuations.  In \(T\) steps a fixed-alphabet
work tape has at most \(2T+1\) reachable cells, so it has only \(2^{O(T)}\) configurations;
restricting the support to \(B\) cells gives (48.2).

### Proposition 49 (linear-time storage escape)

The uniform language
\[
 L_{\mathrm{hold}}
 =\{1^h0uvz:h\ge2,\ |u|=|v|=h-1,\ u=v,\ z\in\{0,1\}^*\}
 \tag{49.1}
\]
is decidable by a deterministic CHMY-model machine in \(O(N)\) time, yet for \(N=4h\),
\[
 W^{\mathrm{lex}}_{N/2}(L_{\mathrm{hold}})
 \ge2^{h-1}=2^{N/4-1}.
 \tag{49.2}
\]

The machine writes a left marker and \(h-1\) ordinary markers while reading \(1^h\), then a
right marker when it reads the zero.  It returns its work head while holding the input head,
stores the next \(h-1\) bits between the endpoint markers, returns once more, and compares the
following \(h-1\) bits.  The total work-head travel is linear.  At the middle cut the prefixes
\(p_u=1^h0u\) have residuals accepting exactly the suffixes whose first \(h-1\) bits equal
\(u\), proving (49.2).

### Corollary 50 (OBDD width does not enter the one-tape magnification window)

Theorem 45 and Proposition 48 imply only
\[
 T=\Omega(S\log S)=\Omega(N^\mu\log N).
 \tag{50.1}
\]
For fixed \(\mu<1\), this is \(o(N)\) and therefore gives no superlinear one-tape lower bound.
Proposition 49 shows that no universal improvement
\[
 \log W=O((T/N)\operatorname{polylog}T)
\]
or even \(\log W=o(T)\) is possible in the CHMY model.  Equation (48.2) gives the genuine but
space-only consequence \(B+\log T=\Omega(S\log S)\) at the half-input cut, and hence
\(B=\Omega(S\log S)\) for polynomial \(T\).  Reaching the MMW window
would require an additional MCSP-specific semantic-state compression theorem; it does not follow
from an OBDD lower bound or generic crossing-sequence conversion.

### Proposition 51 (every-order identity matrices do not control free read-once programs)

There is an infinite family \(F_L:\{0,1\}^L\to\{0,1\}\) with deterministic FBDD size \(O(L)\)
such that, for every balanced partition \(P\sqcup Q=[L]\), the matrix
\[
 M_{P,Q}(u,v)=F_L(u\cup v)
 \tag{51.1}
\]
contains an identity submatrix of order \(2^{\Omega(L)}\).

Let \(G_m=(V_m,E_m)\) be a \(3\)-regular bipartite edge expander on \(2m\) vertices.  Its edges
split into three perfect matchings \(M_1,M_2,M_3\).  On two selector bits \(s\) and data bits
\((x_v)_{v\in V_m}\), define
\[
 F_L(s,x)=1
 \iff
 s\in\{1,2,3\}
 \text{ and }
 x_u=x_v\quad\forall\{u,v\}\in M_s,
 \qquad
 L=2m+2.
 \tag{51.2}
\]
Read \(s\), then query the selected matching in paired order.  This is a deterministic
syntactic read-once program with \(O(L)\) nodes.

Now fix a balanced \(P\sqcup Q\).  The data coordinates are split \(m+O(1)\) versus \(m+O(1)\),
so expansion gives \(\Omega(m)\) crossing edges.  One matching \(M_{s^\ast}\) contains
\(r=\Omega(m)=\Omega(L)\) of them.  Fix \(s=s^\ast\), fix every noncrossing matched pair to
zero, and index accepted inputs \(a_h\) by assigning a common bit \(h_e\) to the two endpoints
of every crossing edge \(e\).  Then
\[
 F_L(a_h|_P\cup a_g|_Q)=\mathbf 1[h=g],
 \qquad
 h,g\in\{0,1\}^r.
 \tag{51.3}
\]
Thus (51.1) contains \(I_{2^r}\). \(\square\)

Proposition 51 rules out a generic transfer from the quantifier
\(\forall\pi\,\exists I_\pi\) in (47.9) to path-dependent FBDDs or 1-NBPs.  Any such upgrade
for MCSP must use compatibility among the order-dependent witnesses or additional circuit
structure, not only their existence and size.

### Proposition 52 (a universal self-indexed witness is small)

Let \(F:\{0,1\}^N\to\{0,1\}\), where \(N\) is even.  Suppose \(I\subseteq F^{-1}(1)\)
satisfies, for every balanced \(P\sqcup Q=[N]\),
\[
 F(f|_P\cup g|_Q)=\mathbf 1[f=g]
 \qquad
 \text{for all }f,g\in I.
 \tag{52.1}
\]
Then
\[
 \boxed{|I|\le N/2+1.}
 \tag{52.2}
\]

Indeed, if distinct \(f,g\in I\) had Hamming distance at most \(N/2\), a balanced \(P\)
could contain \(\operatorname{supp}(f\oplus g)\), making
\(f|_P\cup g|_Q=f\in F^{-1}(1)\) and contradicting (52.1).  Thus \(I\) is a binary code of
minimum distance at least \(N/2+1\).  If \(M=|I|\) and coordinate \(j\) contains \(a_j\)
ones, the Plotkin count gives
\[
 \binom M2\left(\frac N2+1\right)
 \le
 \sum_{j=1}^{N}a_j(M-a_j)
 \le
 \frac{NM^2}{4},
 \tag{52.3}
\]
which rearranges to (52.2). \(\square\)

The distinction between all cuts and the component cuts of one decomposition is essential.
CHMY's BRS lemma writes the accepting set of a size-\(w\) syntactic 1-NBP, for every \(k\), as
an OR of at most \(C(2w)^{2k}\) product rectangles with block size
\(m=\lceil N/k\rceil\).  If one set \(I\) of logarithmic size \(X-o(X)\),
\(X=S\log_2S\), were an identity witness for all their block orders, then each rectangle would
contain at most \(2^m+1\) diagonal members of \(I\), and hence
\[
 X-o(X)
 \le
 2k\log_2(2w)+N/k+O(1).
 \tag{52.4}
\]
Taking \(k=(2+o(1))N/X\) would yield
\[
 \log_2w
 \ge
 \left(\frac18-o(1)\right)\frac{X^2}{N}-1.
 \tag{52.5}
\]
Thus alignment would be powerful, but Proposition 52 forbids the stronger all-cut version.
For \(D\) prescribed cuts, the current Fourier construction loses
\(O(DS^2\log^2S/N)\) labels, so this estimate guarantees \(X-o(X)\) only under
\(D=o(N/(S\log S))\).  Requiring the worst-case BRS bound
\(D\le C(2w)^{2k}\) itself to satisfy this condition forces \(k=O(\log N)\), whereas making
\(N/k<X\) requires
\[
 k>N/X=\Theta(N^{1-\mu}/\log N)\gg\log N.
 \tag{52.6}
\]
There is no parameter overlap for this union-bound repair.  Finally, the three selector branches
in Proposition 51 themselves form three disjoint product rectangles in three different paired
orders.  Every large identity set at a fixed cut has at least one third of its diagonal inputs in
one branch, so product structure alone cannot make all component intersections thin at one cut.

### Proposition 53 (the canonical identity witness is online-cheap)

Choose the packed-selector family in Proposition 44, indexed by tuples
\(\mathbf f=(f_1,\ldots,f_k)\) of \(q\)-variable functions, and put
\[
 D=k2^q
 =S\log_2S-O(S\log\log S)
 =o(N).
 \tag{53.1}
\]
In the canonical half-table embedding, place the \(t\) address variables before the \(q\) data
variables and make all of them vary faster than the dummy variables.  Assign the first \(k\)
lexicographic addresses to \(f_1,\ldots,f_k\).  The first \(D\) stream bits are then exactly
\[
 \operatorname{tt}(f_1)\Vert\cdots\Vert\operatorname{tt}(f_k).
 \tag{53.2}
\]

A one-pass RAM transducer can blindly store these bits and ignore the rest of the first half.
Its middle state is injective on the entire packed family, and hence on the independent identity
set used in Theorem 45.  It uses
\[
 D+O(n)=O(S\log S)
 \tag{53.3}
\]
bits and has worst-case update time \(O(n)\), including a bit-level saturated counter and RAM
address handling.

This limitation is exact at the level of the submatrix pattern.  The total language that compares
the first \(D\) bits of the two input halves and ignores all other positions has the same identity
matrix on the packed rows and columns, while using \(O(S\log S)\) space and \(O(n)\) update.
Therefore the witness and its state cardinality do not by themselves imply an MMW update-time
lower bound.  This transducer is not an MCSP decider: an update-time attack may still exploit
correctness on off-witness inputs, full transition trajectories, or the task of maintaining a
size-\(S\) circuit consistent with an arbitrary prefix. \(\square\)

### Proposition 54 (arbitrary-witness Stream-Merge is sufficient)

Chen--Jin--Santhanam--Williams' one-sided-error adaptation of MMW already omits minimum-size
while retaining a lexicographically first circuit.  We isolate the still weaker relation in which
the solver may return any legal circuit.

Let \(\tau=100S\log_2S\), let \(x_1<\cdots<x_N\) be the canonical truth-table order, and define
\[
 \mathcal E(C,i,y)
 =\{D:|D|\le S,\ D(x)=C(x)\ (x<x_i),\
 D(x_{i+j})=y_{j+1}\ (0\le j<\tau)\}.
 \tag{54.1}
\]
Any solver which returns an arbitrary member of \(\mathcal E(C,i,y)\), or an explicit failure
symbol exactly when this set is empty, suffices in the MMW streaming construction for both
decision and search MCSP. Neither minimum circuit size nor lexicographic canonicalization is
needed.

Indeed, after block \(i\) the only invariant is that the maintained circuit \(C_i\) agrees with
the streamed table \(T\) on its first \(i\tau\) positions. If a full size-\(S\) circuit
\(C^\star\) for \(T\) exists, then \(C^\star\in\mathcal E(C_{i-1},(i-1)\tau+1,y)\) at every
step. Thus every arbitrary legal output preserves the invariant and cannot enter a false dead
end. If no full circuit exists, the first infeasible prefix produces the failure symbol.

For a fixed padded gate-list encoding and a code prefix \(p\), the predicate
\[
 \exists d\succeq p\quad C_d\in\mathcal E(C,i,y)
 \tag{54.2}
\]
is in \(\Sigma_2^P\): guess \(d\), check the explicit new block, and universally quantify the
\(n\)-bit input \(x<x_i\) for old-prefix agreement. Adaptive prefix queries recover a canonical
witness in \(FP^{\Sigma_2^P}\). Finding the least feasible gate bound first shows that this also
recovers the lexicographically first minimum-size witness. MMW's \(\Sigma_3\) formulation makes
separate output bits independently queryable for their parallel construction; it is not an
adaptive lower bound. A bare existence bit without the code-prefix interface does not return the
next circuit state and therefore does not by itself instantiate the induction.

One call already contains an exact but limited synthesis problem. If
\(2^q\le\tau\le2^n\), periodically repeat a \(q\)-variable truth table \(z\) in the new block and
call merge at \(x_1=0^n\). Restricting a returned circuit's first \(n-q\) variables to zero gives
a size-\(S\) circuit for \(z\), and a circuit for \(z\) extends by dummy variables in the other
direction. This uses the standard restriction convention with constant input sources; a
constant-free syntax changes the threshold by only \(O(1)\) gates. Hence
\[
 \mathrm{search\mbox{-}MCSP}_{q,S}
 \le_m \mathrm{OneMerge}_{n,S},
 \qquad
 q=\log_2S+\log_2\log_2S+O(1)
 \tag{54.3}
\]
at the largest block, where \(S=\Theta(2^q/q)\). This is the near-Shannon threshold, not a SAT
embedding. In particular the packed-selector family supplies a legal small extension for every
one of its \(S\log S-O(S\log\log S)\)-bit indices. Since \(\tau=o(N)\), reserving \(O(1)\)
gates and a high dummy variable \(w\) that is zero on the constrained prefix makes both \(h\) and
\(h\oplus w\) legal extensions with different suffixes. Thus packed-selector entropy neither
distinguishes SAT YES from NO on this family nor binds an arbitrary returned circuit to a
satisfying assignment.

The last binding requirement is specific to Levin/search recovery. A decision reduction needs
only \(\varphi\in\mathrm{SAT}\) if and only if the legal extension set is nonempty. Moreover, two
fixed adjacent calls add no syntax channel: a legal two-step chain exists exactly when one
size-\(S\) circuit agrees with the concatenated old prefix and both new blocks, since the final
circuit witnesses the forward direction and the same circuit can be returned twice in the reverse
direction. Thus the decision gate is hardness of contiguous-prefix partial MCSP at the required
threshold. This is an ordinary explicit partial table for initial calls; a nonempty old prefix is
instead represented succinctly by the input circuit. Ilango's ETH-hard partial-MCSP construction
obtains arbitrary-witness rigidity through a saturated read-once formula but uses several
dispersed full subcubes; Hirahara's randomized many-one NP-hardness theorem uses an arbitrary
enumerable support. Neither published result
preserves a single contiguous prefix or the near-Shannon Stream-Merge threshold. With gate slack,
the unconstrained suffix contains a packed family of distinct legal extensions, which obstructs
non-invariant search decoders but does not rule out decision hardness. The precise quantifiers and
parameter boundary are recorded in Note 541. \(\square\)

Thus the output-length argument for dummy padding cannot be promoted to arbitrary giant-fiber
quotients. For example,

\[
 \mu_T=0.2,
 \qquad \kappa=1,
 \qquad \mu_H=0.6,
 \qquad a=1.01
\]

satisfies \(\mu_H>\kappa\mu_T\) and (17).  The notation \(\mu_T\) is deliberate: this is only
a structural target-exponent example and does not claim that \(0.2\) is the fixed witness
\(\mu_*\). Exact preservation itself imposes no contrary lower
bound on \(\kappa\): the predicate map using one fixed target-YES value and one fixed target-NO
value is exact for every positive \(\kappa\), although computing it already decides source MCSP.
Dummy padding is closed for the separate reason \(\mu_H=\kappa\mu_T\), which turns (17) into
\(a<2\mu_T\), impossible for \(a=1.01\) and \(\mu_T<1/4\).

Variable permutation does not alter \(n\), while restriction only gives
\(\operatorname{CC}(f\upharpoonright\rho)\le\operatorname{CC}(f)\) and can turn NO instances
into YES instances. Neither replaces the two-sided equality (8).

## 7. Scope and limitations

For constant log-length expansion \(n'=\kappa n+O(1)\), this paper closes every truth-table map
whose fibers on the source low-complexity class have logarithmic size
\(o(n2^{\mu_Hn})\). This includes dummy padding, exact-decodable error-correcting encodings,
systematic indexing, direct-product or tensor lifts, and quotients by all
\(2^{\operatorname{poly}(n)}\)-size symmetry families. More elaborate streaming structure cannot
change the counting inequality (3d).

Separately, Propositions 43--47 exhibit, at every global-order middle cut, an identity submatrix
of order \(2^{S\log S-O(S\log\log S)}\).  They therefore determine the complexity of
\(\mathrm{MCSP}_{2^{\mu n}}\) up to a \(1+o(1)\) exponent for deterministic, strictly layered
nondeterministic and parity OBDDs, and exact field-weighted ordered algebraic programs, uniformly
over all global variable orders.  This is a genuine restricted-model lower bound rather than a
quotient barrier.
Propositions 48--50 also delimit its relevance to magnification: an unrestricted CHMY work tape
can store \(\Theta(N)\) prefix bits in linear time, so high fixed-cut residual entropy does not
by itself imply superlinear one-tape time.  Proposition 51 gives the complementary model boundary:
even an exponential identity submatrix at every balanced cut is compatible with a linear-size
path-dependent FBDD.  Proposition 52 further shows that replacing the order-dependent witnesses
by one all-cut self-indexed witness is information-theoretically impossible, while the current
multi-cut Fourier repair cannot meet the BRS parameters.  Proposition 53 shows independently that
the canonical witness index is online-cheap, so its cardinality cannot supply the missing MMW
update-time lower bound. Proposition 54 identifies the exact weaker update primitive: arbitrary
consistent circuit extension is sufficient, adaptive code-prefix extension is already at the
second PH level, and the direct raw-table one-block embedding reaches a near-Shannon MCSP slice.
One or two adjacent blocks reduce exactly to contiguous-prefix partial MCSP. General partial-MCSP
hardness is known, but the contiguous geometry and required threshold remain open; robust
arbitrary-output decoding is an additional search, not decision, requirement.

The remaining encoding possibility must collapse at least
\(2^{\Omega(n2^{\mu_Hn})}\) low-complexity functions to one target value. To preserve both sides
of the promise, every such fiber must lie wholly inside either \(L_{\mu_H,n}\) or its complement;
Proposition 5 further forces every maximum source-YES fiber to be pointwise almost-everywhere
XOR-dispersed: from each fixed member, all but a \(2^{-\Omega(nT)}\) fraction of partners have
XOR complexity at least \(S-O(nT)\). Constructing this enormous, dispersed predicate-specific
quotient within the required one-tape time, without first deciding the source MCSP instance, is
not addressed here. Proposition 6 closes every exact coset-fiber quotient, including every exact
affine map, because the source low-complexity set has logarithmic doubling \(\Omega(S)\) while the
target permits only \(O(nT)=o(S)\) YES cosets. The exact size and structure of the bare stabilizer
remain open, with translation-overflow, Fourier-rank, and 2-adic valuation as possible interfaces,
but they are no longer needed to rule out the bridge. Thus the surviving exact possibility must
use non-coset, predicate-specific fibers. Proposition 7 quantifies the cost of that escape: every
such map has exponential target XOR-defect or exponential inflation of a fiber on
\(\mathcal L_S+\mathcal L_S\). In fact, Proposition 7 forces the same dichotomy for the
unordered fiber-pair average and the occupied-fiber average, so it is not an exceptional-pair
artifact. Constant, exact decision, and layered maps show that neither alternative nor the
half-exponent split can be improved by cardinality alone, while the easy predicate example
following Proposition 7 rules out a predicate-independent runtime bound. The remaining gate is
MCSP-specific and computational: it must charge the cost of producing this defect or inflation
without already deciding source MCSP. Proposition 8 separately locates the exact conditional time
window: if a materializer of exponent \(b\) and a target algorithm of exponent \(a\) genuinely
compose in the CHMY model, the route reaches the source lower bound exactly when
\(\max\{b,\kappa a\}<2\mu_H\). Explicit output length alone closes only
\(\kappa\ge2\mu_H\), so it does not eliminate the remaining giant-fiber route.
Proposition 10 gives a weaker but explicit joint prefix-state obstruction under synchronous
handoff; it does not convert the remaining gate into a \(Q\)-only lower bound.

Proposition 4 shows that replacing exact MCSP by a constant-factor gap removes the exact-stabilizer
requirement at the set level, while Proposition 5 rules out its uniformly low-width junta kernel
as a YES-preserving affine quotient for every fixed sub-doubling gap. The boundary case
\(S_1=2S\), larger gaps, and kernels that already contain source-threshold functions remain open;
none of these statements supplies an exact MCSP decision procedure. A transfer may also leave the
encoding framework or use a different magnification theorem. The present result does not prove
\(P\ne NP\).

## Sources

- Cheraghchi, Kabanets, Lu, and Myrisiotis, *Circuit Lower Bounds for MCSP from Local
  Pseudorandom Generators*, ICALP 2019, [LIPIcs 132:39](https://doi.org/10.4230/LIPIcs.ICALP.2019.39).
- McKay, Murray, and Williams, *Weak Lower Bounds on Resource-Bounded Compression Imply Strong
  Separations of Complexity Classes*, [STOC 2019](https://doi.org/10.1145/3313276.3316396).
- Chen, Jin, Santhanam, and Williams, *Constructive Separations and Their Consequences*,
  [TheoretiCS 2024](https://doi.org/10.46298/theoretics.24.3), Section 3.1.
- Ilango, *Constant Depth Formula and Partial Function Versions of MCSP are Hard*,
  [FOCS 2020](https://doi.org/10.1109/FOCS46700.2020.00047), Theorem 11 and Lemma 12.
- Hirahara, *NP-Hardness of Learning Programs and Partial MCSP*,
  [FOCS 2022](https://doi.org/10.1109/FOCS54457.2022.00095), Theorem 8.5.
- Cheraghchi, Hirahara, Myrisiotis, and Yoshida, *One-Tape Turing Machine and Branching Program
  Lower Bounds for MCSP*, [STACS 2021](https://doi.org/10.4230/LIPIcs.STACS.2021.23).
- Glinskih and Riazanov, *MCSP is Hard for Read-Once Nondeterministic Branching Programs*,
  [LATIN 2022](https://doi.org/10.1007/978-3-031-20624-5_38); see also Glinskih,
  *Circuits and Branching Programs in Meta-Complexity*, Boston University dissertation, 2024,
  Chapter 3.
- Harper, *Optimal Numberings and Isoperimetric Problems on Graphs*, *Journal of Combinatorial
  Theory* 1 (1966), 385--393,
  [doi:10.1016/S0021-9800(66)80059-5](https://doi.org/10.1016/S0021-9800(66)80059-5).
- Chow, *Almost-Natural Proofs*, *Journal of Computer and System Sciences* 77 (2011), 728--737,
  [doi:10.1016/j.jcss.2010.06.017](https://doi.org/10.1016/j.jcss.2010.06.017), Proposition 2
  and its hypercube-isoperimetric proof.
- Jukna, *Boolean Function Complexity: Advances and Frontiers*, Springer, 2012, Lemma 1.12
  (circuit enumeration), Theorem 1.15 (Lupanov's circuit upper bound), and Remark 1.20
  (single-bit boundary growth).
- [Project derivation note 068](../../notes/068-one-tape-threshold-rescaling-dummy-padding-boundary-2026-08-14.md).
