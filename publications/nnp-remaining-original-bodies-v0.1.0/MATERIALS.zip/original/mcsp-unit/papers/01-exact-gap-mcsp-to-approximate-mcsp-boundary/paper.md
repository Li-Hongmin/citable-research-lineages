# Exact Gap-MCSP to Approximate-MCSP: A Quantitative Boundary

## Abstract

We quantify the direct relationship between exact Gap-MCSP and approximate-MCSP under a
fixed fan-in-two De Morgan circuit basis. If truth tables of \(m\)-variable functions differ
in \(d\) positions, their minimum circuit sizes differ by at most \(O(md)\). Consequently,
\[
 \operatorname{GapMCSP}[s,t]^{\mathrm{NO}}
 \subseteq
 \{x:d_H(x,E_s)\ge \lfloor(t-s)/(cm)\rfloor+1\},
\]
where \(E_s\) is the set of truth tables of circuit size at most \(s\). This gives a genuine
exact-to-approximate promise restriction and transfers any lower bound for the resulting
approximate problem back to exact Gap-MCSP.

We then substitute the best direct formula lower-bound scale available in the project. The
induced approximate distance is \(N^{\alpha/2-o(1)}\), while the general magnification theorem
of Atserias--Müller requires a formula exponent larger by one full power of \(N\), or a
probabilistic-formula interface that loses the same factor under the generic conversion.
Thus exact Gap-MCSP is not unrelated to approximate-MCSP, but this elementary interface does
not close the current magnification route and does not imply \(P\ne NP\).

## 1. Definitions

Let \(N=2^m\) and fix a fan-in-two De Morgan circuit basis. Define
\[
 E_s=\{x\in\{0,1\}^N:\operatorname{Size}(x)\le s\}
\]
and let \(G_{s,t}=\operatorname{GapMCSP}[s,t]\) have YES set \(E_s\) and NO set
\(\{x:\operatorname{Size}(x)>t\}\). For an integer \(D\), define the promise problem
\[
 \operatorname{ApproxMCSP}[s,D]
 :=\bigl(E_s,\{x:d_H(x,E_s)\ge D\}\bigr).
\]
The distance in this definition is absolute Hamming distance, not relative distance.

## 2. The perturbation theorem

### Theorem 1

There is an absolute constant \(c>0\), depending only on the fixed circuit basis, such that
for all \(t>s\), with
\[
 D_{s,t,m}=\left\lfloor\frac{t-s}{cm}\right\rfloor+1,
 \tag{1}
\]
we have
\[
 G_{s,t}^{\mathrm{NO}}
 \subseteq
 \{x:d_H(x,E_s)\ge D_{s,t,m}\}.
 \tag{2}
\]
Therefore, for every complexity class \(\mathcal C\),
\[
 G_{s,t}\notin\mathcal C
 \quad\Longrightarrow\quad
 \operatorname{ApproxMCSP}[s,D_{s,t,m}]\notin\mathcal C.
 \tag{3}
\]

### Proof

If two \(m\)-variable truth tables differ in one position \(a\), an equality detector
\[
 e_a(z)=\bigwedge_{j=1}^{m}(z_j=a_j)
\]
has \(O(m)\) gates. Combining it with a circuit for one truth table flips that single
output bit with only \(O(m)\) additional gates. Applying this repair along a Hamming path
of length \(d\) gives
\[
 |\operatorname{Size}(f)-\operatorname{Size}(g)|
 \le cm\,d_H(f,g).
 \tag{4}
\]

Now let \(x\in G_{s,t}^{\mathrm{NO}}\) and suppose that some \(y\in E_s\) satisfies
\(d_H(x,y)<D_{s,t,m}\). Equation (4) gives
\[
 \operatorname{Size}(x)
 \le s+cm(D_{s,t,m}-1)
 \le t,
\]
contradicting that \(x\) is a NO instance. This proves (2), and the solver implication
(3) is immediate from promise restriction. \(\square\)

## 3. The scale obtained from known formula lower bounds

The exact-to-approximate theorem becomes quantitative when combined with the
Oliveira--Pich--Santhanam formula lower bound. For fixed \(0<\alpha<2\), their parameter
regime gives, for a suitable \(d>1\),
\[
 \operatorname{GapMCSP}
 \left[m^d,2^{(\alpha/2-o(1))m}\right]
 \notin U_2\text{-}\operatorname{Formula}[N^{2-\alpha}].
 \tag{5}
\]
Setting \(s=m^d\) and \(t=2^{(\alpha/2-o(1))m}\) in (1) yields
\[
 D_{s,t,m}
 =\frac{2^{(\alpha/2-o(1))m}}{\operatorname{poly}(m)}
 =N^{\alpha/2-o(1)}.
 \tag{6}
\]
Hence the induced approximate problem satisfies
\[
 \operatorname{ApproxMCSP}
 \left[m^d,N^{\alpha/2-o(1)}\right]
 \notin U_2\text{-}\operatorname{Formula}[N^{2-\alpha}].
 \tag{7}
\]
The YES language remains sparse NP: the number of size-\(m^d\) circuit descriptions is
\[
 2^{O(m^d\log m)}=2^{N^{o(1)}}.
 \tag{8}
\]

## 4. Why this does not trigger the current magnification theorem

Fix \(0<\alpha<1\). To compare (7) with the \(N^{-\varepsilon}\)-MCSP premise of
Atserias--Müller, choose any fixed \(0<\eta<\alpha/2\) and set
\[
 \varepsilon=1-\alpha/2+\eta.
 \tag{9}
\]
Then \(N^{1-\varepsilon}=N^{\alpha/2-\eta}\) is below the distance in (6) for large \(N\).
The approximate lower bound needed by their formula branch is at scale
\[
 \operatorname{FML}
 \left[N^{1+2\varepsilon+o(1)}\right]
 =
 \operatorname{FML}\left[N^{3-\alpha+2\eta+o(1)}\right],
 \tag{10}
\]
whereas (7) supplies only \(N^{2-\alpha}\). A full \(N\)-factor is missing.

Their probabilistic-formula branch asks for a lower bound at
\[
 \operatorname{PFML}
 \left[N^{2\varepsilon+o(1)}\right]
 =
 \operatorname{PFML}\left[N^{2-\alpha+2\eta+o(1)}\right].
 \tag{11}
\]
The known conversion
\[
 \operatorname{PFML}[S]\subseteq\operatorname{FML}[O(NS)]
 \tag{12}
\]
loses one additional factor of \(N\) when used in the available direction. The \(o(1)\)
loss in (6) also prevents silently taking the endpoint \(\varepsilon=1-\alpha/2\).

Thus the direct interface proves a real approximate-MCSP consequence but leaves the two
quantitative gates
\[
 \text{fixed-}\varepsilon\text{ endpoint}
 \qquad\text{and}\qquad
 \operatorname{PFML}\to\operatorname{Formula}\text{ derandomization loss}.
\]

## 5. Scope and limitations

The theorem is a promise-transfer and parameter-boundary result. It does not prove that
future exact-to-approximate reductions cannot be stronger, and it does not show that the
Atserias--Müller thresholds are impossible to reach by a different construction. It also
does not imply \(P\ne NP\). Its contribution is to replace the vague statement “exact Gap-MCSP
does not match approximate-MCSP” by the sharp direct distance scale \(D_{s,t,m}\) and the
remaining exponent losses.

## Sources

- Oliveira, Pich, and Santhanam, *Hardness Magnification near State-Of-The-Art Lower Bounds*,
  [CCC 2019](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.CCC.2019.27).
- Atserias and Müller, *Simple General Magnification of Circuit Lower Bounds*,
  [arXiv:2503.24061](https://arxiv.org/abs/2503.24061).
- Krinkin, *A Simple Constructive Bound on Circuit Size Change Under Truth Table Perturbation*,
  [arXiv:2603.09379](https://arxiv.org/abs/2603.09379).
- [Project derivation note 066](../../notes/066-exact-gap-approximate-perturbation-interface-2026-08-14.md).
