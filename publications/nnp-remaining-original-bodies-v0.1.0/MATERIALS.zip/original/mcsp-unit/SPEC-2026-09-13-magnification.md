# SPEC-2026-09-13 — sparse-MCSP 放大阈值下界（run-to-verdict，冻结）

来源：SPEC-candidates/20260913b-magnification-parameter-table-forced.md 及其 probe（GO，2026-09-13）。冻结后不改。

## 主陈述
固定 s(N)=N²，L=MCSP[s]（输入为 N 变量函数字典序真值表，n=2^N；非 2 幂长度拒绝），电路基为扇入二 AND/OR/NOT，按门计。
r 为 probe 表中固定的编码深度常数。
主陈述：L ∉ TC_{r+5}[n^{5/4}]（深度 r+5、线数 n^{5/4} 的阈值电路）。
若成立：经 Chen–Jin–Williams 2019 定理 1.1(7)/2.6/3.4，对所有 k 有 NP ⊄ TC₂[n^k]（决定性推进）。
若为假或不可达：写明 locality barrier 相对该构造在何精确模型上成立。

## 路线（≤3）
R1 复合门收缩：对 CJW 构造实际选中的哈希线性映射 M_v，取 Kane–Williams 分块随机限制（k=Θ(log n) 块各留一位），判定复合底层门 H(M_v(x), v, i, 块_i) 是否以高概率整体收缩为文字/常数。
 - 第一观测：计算限制后 M_v 矩阵的秩与各行存活支持分布（有限 n 精确计算 + 渐近证明）。
 - GO：存在 KW 式计数论证使收缩后剩余电路无法计算 L 的限制；NOGO：复合门在正测度事件下保持非平凡（≥2 个存活变量的行占比不趋 0），且该非平凡性可被 oracle 电路利用（即 locality 化成立）。
R2 若 R1 NOGO 且原因是 M_v 的行支持过大：用 CJW 允许的其他哈希族（更稀疏的线性映射）替代，重做 R1 的观测一次。GO/NOGO 同 R1。
R3 若 R1、R2 均 NOGO：写出精确的「相对 CJW 构造的 locality barrier 陈述」（oracle 层位置、扇入、总线数），作为有范围关闭。

## 预算
5 个脉冲或 7 天，先到为准。到达即写终态报告（改变了什么判断、最薄弱一步、剩余边界、下一批候选）。

## 禁区
不做 serialization/Easy Witness/general compiler；不回到 canonical-prefix/batch-count；不自行发明放大定理；不把有限 n 的表格当渐近证明；不把大扇入 PARITY 反例当作实际哈希的失效证据。
