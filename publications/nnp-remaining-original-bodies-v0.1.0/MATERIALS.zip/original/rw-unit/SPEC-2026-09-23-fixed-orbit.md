# Frozen SPEC — actual RW fixed unary orbit (2026-09-23)

## Main quantified statement
Fix the published RW Theorem 4.3 source, truth-table generator, and systematic PCP/JK serialization, with all descriptor/advice and exact evaluation costs charged. Determine whether its actual canonical-prefix/batch-count orbit admits an explicit address-scale (m^{O(1)}) exact same-object normal form closed under every required composition; if not within the frozen family, exhibit a genuinely reachable obstruction and the sharp boundary. No P versus NP claim follows merely from a prefix normal form.

## Routes and mechanical gates
R1: Freeze the literal count-prefix plus evaluable first-JK-block representation. First observation: at i=0 project the actual first block to the base outsider as in Note 613. GO requires an exact base evaluator and one-step composition within m^{O(1)} charged cost; NOGO is a reachable base projection forcing superpolynomial evaluator size.
R2 (only if R1 NOGO): Fix one payload-free global relation for the same published source/serialization. First observation: write a complete charged base relation without querying the first JK block, then one nontrivial actual composition. GO requires a common address-scale exact relation and uniform composition bound; NOGO requires a reachable structural counterexample for that fixed relation, not an arbitrary input.
R3 (only if R2 NOGO): Test a fixed compiler's succinct structural projection without exact payload access. First observation: obtain one actual-run subtree count/weighted-depth/heavy-run demand triple. GO requires bounded charged costs at base and under composition; NOGO requires a reachable counterexample to that fixed compiler.

## Budget and exclusions
No fixed pulse budget; each pulse stops on a decisive gate, obstruction or unknown when no cheap discriminating observation remains. Mac only lightweight reading/reasoning; heavy computation only in authorized TSUBAME queue. Exclude arbitrary serializations, generic #CircuitSAT and synthetic unreachable answer vectors as negative evidence; exclude adjacent MCSP and THR directions. No automatic publication. Previous 2026-09-09 SPEC remains untouched.
