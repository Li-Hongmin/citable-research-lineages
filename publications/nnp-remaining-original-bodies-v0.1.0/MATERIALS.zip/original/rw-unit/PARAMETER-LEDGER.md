# 参数账本

以下记号在本单元固定使用，旧 note 中的局部记号不覆盖本表。

| 符号 | 含义 |
|---|---|
| `n` | stitched language / 原始实例输入长度 |
| `q` | AVOID seed 或 JK block 的半长 |
| `T` | computation history 或递归对象总长度 |
| `P` | PCP/dPCP global proof 长度 |
| `s` | shared key 或 compressed proof-circuit 描述长度 |
| `i` | 要恢复的 output coordinate |
| `k` | 编码 message 长度；在 ACRR 目标中与输出词长度区分记账 |
| `N` | codeword/proof 的物理长度 |
| `n'` | PCPP+RLDC 变换中显式承载的编码隐式输入长度；已知变换通信为 `n'+cc(n)` |
| `δ` | decoding radius / strong-LTC 检测半径 |
| `ρ_*` | strong-LTC 在 `d>δ` 上的固定拒绝下界 |
| `η` | RLDC 在近 codeword 上的错误输出概率 |
| `β_B` | target-binding 对非法 message 的接受上界 |
| `q_T,q_D,q_B,q_M,q_P` | LTC tester、RLDC decoder、target-binding test、message-PCPP 对消息 oracle/auxiliary proof 的查询数 |
| `gamma` | message-PCPP 的 proximity-soundness 半径；错误输出位必须落在 `gamma` 外，才能由该接口绑定 |
| `Q` | message-inline 或双分支编译后的 RLDC 查询数；C69 中可取 `Q=2q+1` |
| `σ` | RLDC 在近 codeword 上输出正确位或 `bottom` 的成功下界；C69 中 `σ=1-β` |
| `L` | branch-support 编译中，对每个坐标、声明和有限 response 的所有 adaptive query trees 的 union support 大小；proof-only relaxed-LDC locality 直接为 `L` |

## 编码层组合的可核验预算

若 `ρ_*>0`，取

\[
 R=\left\lceil\frac{\log(1/6)}{\log(1-\rho_*)}\right\rceil,
 \qquad q_{total}=Rq_T+q_B+q_D .
\]

在 `dist(y,C)>δ` 时，strong-LTC 的 `R` 次重复给出至多 `1/6` 的同时通过概率；在
`dist(y,C(m))≤δ` 时，RLDC 控制坐标错误，`Bind_x` 控制 `m\notin H_x`。因此组合
定理的真正未决参数只在 `q_B`、proof 长度 `N`、统一生成时间和地址空间，而不是
coordinate decoder 本身。

暴露-history 基线（旧 note 183）还需记录 `M`（输出 RLDC 长度）、`R=ceil(T/M)`
（copy 数）和 `w_C`（codeword 区在总 oracle 距离中的权重）。其错误声明界为

\[
  \max\!\left\{\beta_P,\;\beta_D+\frac{\delta_P}{w_C\delta_D}\right\},
  \qquad q_{total}=q_P+q_D.
\]

该式只证明暴露-history baseline；把 `T+RM+N_x polylog N_x` 压到
`poly(n,log T)` 才是 ACRR 的未解决部分。

已知 pair-language PCPP+RLDC 变换的通信是

\[
  n' + cc(n),
  \qquad q=q_{PCPP}+q_{RLDC}\,O(1/\alpha).
\]

对二进制 injective history encoding，`n'\ge T`；因此只优化 query 或 decoder 的
polylog 因子，不能自动把通信降到 ACRR 所需的 `poly(n,log T)`。通信压缩本身必须
作为独立定理目标。

## RW/JK 接入预算

必须同时满足：

\[
  q,\;P,\;s,\;q_{total},\;|Q_{x,i,b}| = poly(n,\log(T+2)),
\]

并且同一个 `K_x` 服务所有 `i,b`。若 line packing 方案要求
`P=\omega(q\,polylog q)`，则按旧 note 167 的容量计算停止该方案；若 shared-key
方案需要把完整 history 或 `q`-scale preimage 塞进 `s`，则违反 ACRR 定义。

## 晋级判据

新结果只有在以下至少一项成立时才从探索进入主线：

1. 完整构造 shared target-binding relation-PCP，并给出 near-linear/address-scale
   参数；
2. 一般地把 ACRR 归约到 RLDC/LDC 或证明超线性代价；
3. 给出与 RW/JK、Range Avoidance 或电路下界的非条件性新联系。
