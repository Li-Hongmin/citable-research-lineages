# From Address-Scale Smart Reconstruction to (P/\mathrm{poly})

## Abstract

We formulate the exact conditional closure needed to turn an address-scale Ren--Williams /
Jeřábek--Korten smart-reconstruction interface into a separation of (P) and (NP). The
statement is deliberately conditional: it does not claim that the actual RW/JK construction
already satisfies its hypotheses. Instead, it isolates a uniform address-level evaluator for
the same canonical history, proves that (P=NP) would put that history in (P/\mathrm{poly}),
and contradicts a matching circuit lower bound. The theorem separates three logically
independent gates: attaching the actual RW history to one proof interface, classifying bottom
and cover escapes without hidden advice, and aligning the final collapse on the same infinite
length set.

When the branch-local evaluators are total fixed-level PH surfaces, the payoff is
stronger than the \(P=NP\) contradiction. Assuming
\(\mathrm{SAT}\in P/\mathrm{poly}\) puts every fixed PH level in
\(P/\mathrm{poly}\); a branch-complete address-scale surface would then give
polylogarithmic-size circuits for the same RW hard word. Thus this strengthened
interface would prove the explicit NP circuit lower bound
\(\mathrm{SAT}\notin P/\mathrm{poly}\).
Fixed depth is not essential: a \(d\)-block address-scale surface compiles to
\(m^{A\Gamma^d}\), and the adjustable RW recurrence absorbs
\(d_i=O(i)\) whenever the surface theorem holds for all sufficiently large growth
constants \(C\) with address-scale resource and gap exponents uniform over the RW
starting sequences.  This relaxation changes the admissible interface, not the
still-missing object-to-address compression.

This organization turns the \(P\) versus \(NP\) route into a falsifiable theorem program. A
failed gate must become a genuine barrier or parameter separation; it cannot be silently replaced
by a list-soundness slogan, a per-coordinate proof, or an evaluator whose running time is
polynomial only in the full RW address scale.

We also record the scale-complete audit for the actual RW hard-table theorem: its
near-maximum \(N/\operatorname{polylog}N\) lower bound does not by itself exclude the
stable \(N^{O(1)}\)-time solver branch.  The audit therefore separates the remaining
address-scale compression problem from the conditional family-level RLDC and
failure-branch descriptor costs.

## 1. Conditional closure theorem

Let (H_{A,n}\in\{0,1\}^{N_n}) be the canonical history object associated with input (A).
Assume that on an infinite length set \(\mathcal N\),

\[
 \operatorname{CC}(H_{A,n})>n^{\omega(1)}.
\tag{1.1}
\]

Suppose further that the RW/JK interface has the following properties.

1. **One global history.** Every accepted reconstruction query addresses this same
   (H_{A,n}), not a coordinate-dependent history or a padded substitute.
2. **Address-level evaluator.** A uniform polynomial-time selector and verifier turn an address
   (a\in[N_n]) into the symbol (H_{A,n}[a]), using one common proof, one common address
   space, and only (n^{O(1)}) work state.
3. **Smartness and bottom/cover safety.** Every actual query lies in the promise, and every
   bottom or cover branch either returns the same history symbol or has been ruled out on the
   actual instance.
4. **Bounded advice, not history encoding.** Descriptor, sheet index, canonical key, and
   strategy summary have total length (n^{O(1)}) and do not encode \(\Theta(N_n)\) history
   bits under another name. For the stated \(P/\mathrm{poly}\) conclusion these strings may
   be nonuniform advice hardwired into the length-n circuit; P-uniform generation is an extra
   hypothesis only if one wants a uniform \(P\) evaluator.
5. **(P=NP) determinization.** Under (P=NP), all actual promise queries and selector
   decisions can be determined by a fixed polynomial-time procedure, still with (n^{O(1)})
   time per address.
6. **Length alignment.** The reconstruction interface and (1.1) hold on a common infinite
   subset of lengths.

### Theorem 1.1

Under assumptions 1--6,

\[
 P=NP\quad\Longrightarrow\quad
 \{H_{A,n}\}_{n\in\mathcal N}\in P/\mathrm{poly},
\]

contradicting (1.1). Therefore (P\ne NP).

### Proof

Assume (P=NP). By assumption 5, the query procedure determines the value of every address
in polynomial time, and assumptions 1--4 ensure that it is the same (H_{A,n}) and uses only
polynomially many non-history advice bits. Hard-wire (n), the fixed description of (A), the
length-n selector/advice, and the address procedure into a circuit. The resulting circuit has size
\(n^{O(1)}\) and computes (H_{A,n}[a]) from the address (a). This gives
\(\operatorname{CC}(H_{A,n})\le n^{O(1)}\), contradicting (1.1) on the common infinite
length set. \(\square\)

### Theorem 1.2 (scale-complete RW closure audit)

The forcing scale in the actual Ren--Williams construction must be compared with
the representation scale of the branch being simulated.  Let \(B_i\in\{0,1\}^{N_i}\)
be a hard output at a stable RW stage, put
\[
  \ell_i=\lceil\log_2(N_i+1)\rceil,\qquad
  \operatorname{CC}(B_i)>S_i,
\tag{1.8}
\]
and suppose \(S_i=\Omega(N_i/\operatorname{polylog}N_i)\) on the hard-length
subsequence.  Assume that under \(P=NP\) a solver branch has a deterministic
\(N_i^{d_{\rm sol}}\)-time evaluator, while a failure/reconstruction branch uses
one common proof/address space, a \(1\) versus \(1/2\) public-coin gap, and a
straight-line ROM response with control size \(p_i\), descriptor length \(d_i\),
and at most \(b_i\) descriptor reads.

Every proposed RW-to-\(P/\mathrm{poly}\) closure then falls into at least one of
the following five cases:

* **(S) Stable object scale.** The solver branch gives an
  \(N_i^{d_{\rm sol}}\)-size evaluator. The lower bound in (1.8) does not
  exclude this branch whenever \(S_i\le N_i^{d_{\rm sol}}\); in particular,
  the RW near-maximum scale is compatible with (S).
* **(A) Address-scale solver compression.** If the same branch additionally
  supplies a single-valued Boolean or fixed-level PH acceptance surface of
  size \(\ell_i^{O(1)}\), with all surface inputs at
  \(\ell_i^{O(1)}\) length and gap at least a fixed \(\gamma_0>0\), then
  Proposition 1.3 and Hoeffding sampling give
  \[
    \operatorname{CC}(B_i)\le\ell_i^{O(1)}.
\tag{1.9}
\]
  Thus (A) contradicts any \(S_i=2^{\Omega(\ell_i)}/\operatorname{poly}(\ell_i)\).
* **(R) Reconstruction descriptor payment.** On a hard length known to use
  the failure branch,
  \[
    \operatorname{CC}(B_i)
      \le O\!\left(\ell_i(p_i+b_i d_i+\ell_i)\right).
\tag{1.10}
\]
  Hence, whenever the control term is below \(S_i/\ell_i\),
  \[
    p_i+b_i d_i=\Omega(S_i/\ell_i).
\tag{1.11}
\]
  In the near-maximum regime, \(p_i,b_i\le\ell_i^{O(1)}\) force
  \(d_i=\Omega(N_i/\operatorname{polylog}N_i)\).
* **(F) Conditional family-level coding payment.** If the same attachment is
  upgraded to a target-relative family with a common proof, positive radius,
  fixed alphabet/locality window, and the required all-policy semantics, then
  Theorem 6.4 applies: history supply, global-package defect/information,
  or RLDC locality/alphabet cost must be paid. This case is conditional on
  the family lift and is not created by a single-target evaluator.
* **(E) Model exit.** If none of (S), (A), (R), or (F) is available, at least
  one advertised hypothesis has changed: the proof/address space is not common,
  the gap or radius degenerates, the descriptor is not finite, the family
  semantics are absent, or a new non-transcript global coupling is being used.

#### Proof

On (S), \(P=NP\) determinizes the smart promise queries, and the standard
time-to-circuit simulation yields size \(N_i^{d_{\rm sol}+O(1)}\).  This is
not smaller than the forcing scale in (1.8).  On (A), sample
\(O((\ell_i+\log(1/\delta))/\gamma_0^2)\) public tapes.  The address-scale
surface and a threshold counter then compute all \(N_i\) bits, giving (1.9).
On (R), the same sampling argument followed by ROM-read expansion gives
(1.10), and (1.11) follows from (1.8).  On (F), the stated family hypotheses
are exactly those required by the family--strategy Closure Gate.  Any remaining
construction has changed one of the hypotheses listed in (E). \(\square\)

The theorem is a scale audit, not an unconditional \(P\ne NP\) proof.  Its
important correction is that \(P=NP\) turns the stable RW solver into an
object-scale \(N^{O(1)}\) generator, not an address-scale
\(\operatorname{poly}(\log N)\) accessor.  Therefore the remaining top-level
attack is either a genuinely RW-specific address compression theorem or a
general impossibility theorem forcing every failure/family branch to pay the
listed descriptor, promise, cover, bottom, or locality cost.  A full statement
with the RW source parameters is recorded in
[the scale-complete Closure Audit](../../../mcsp-hardness-magnification/notes/358-rw-scale-complete-closure-audit-2026-08-18.md).

### Proposition 1.2 (a measurable Gate-I subcase)

The global-word part of Gate I has a concrete sufficient interface. For each \(n\), let
\(\mathcal Z_n\subseteq\Sigma^{N_n}\) be a Hamming-connected target-relative near-proof
family. Assume that all coordinate queries use one marginal \(\lambda_n\), that the valid
word family \(\mathcal Y_n\) has weighted separation \(\Delta_n\), and that for every
\(z\in\mathcal Z_n\) there is a random \(Y_{n,z}\in\mathcal Y_n\) with

\[
  \Pr[X_{n,z}\ne (Y_{n,z})_{J}]
  \le\varepsilon_n,
  \qquad
  I_2(Y_{n,z};T_{n,z})\le\iota_n.
\tag{1.2}
\]

Suppose further that the common adaptive decoder has depth at most \(r_n\), and,
conditioned on every proof state and transcript prefix, each proof position is queried
at most \(\chi_n/N_n\) at each step. If

\[
  2\left(\varepsilon_n+
  \sqrt{\frac{\ln2}{2}\,\iota_n}\right)
  +\frac{r_n\chi_n}{N_n}
  < \Delta_n,
\tag{1.3}
\]

then all states in \(\mathcal Z_n\) admit one common valid word with error at most
\(\varepsilon_n+\sqrt{(\ln2/2)\iota_n}\). If the forcing-side target-binding condition
identifies every such common word with \(H_{A,n}\), this supplies the same-proof
quantifier in Assumption 1 and leaves only the address-scale, smartness, advice, and
length-alignment clauses of Theorem 1.1.

The proof is the coupling in the connected-neighborhood transcript theorem: adjacent
proofs can differ only after the first query to their changed position, so their visible
transcript laws have total variation at most \(r_n\chi_n/N_n\). The theorem then
propagates one pointwise word across the Hamming-connected family. This proposition is
not an assertion that the current RW/JK construction supplies (1.2)--(1.3); it is a
source-checkable Gate-I target.

The same interface has an exact failure branch: if no common word exists on the
Hamming-connected family, some proof position must be queried with probability at least
\(\Delta_n-2\alpha_n\), where
\(\alpha_n=\varepsilon_n+\sqrt{(\ln2/2)\iota_n}\). Thus the RW attachment cannot hide
the uniformity failure: it must expose a query peak, a large transcript-information term,
or a loss of the fixed-coordinate/separated-word hypotheses.
If, in addition, a source-specific first-hit patchability condition says that the
changed-position query forces a target-wrong non-\(\bot\) output with conditional
probability at least \(\gamma_n\), then the same branch gives the quantitative lower
bound \(\beta_n\ge\gamma_n(\Delta_n-2\alpha_n)\) on target error. This is the precise
extra ingredient needed to turn the Gate-I structural dichotomy into a contradiction;
it is not supplied by ordinary dPCP/list soundness.

### Proposition 1.3 (address-scale PH surface closure)

The address-scale requirement can be stated without requiring a common response strategy.
Let \(H_n\in\{0,1\}^{N_n}\), let
\(\ell_n=\lceil\log_2(N_n+1)\rceil\), and allow an arbitrary finite strategy
\(\mathcal S_{n,a}\) for each address \(a\in[N_n]\). Suppose that the selected
acceptance bit is represented by one uniform Boolean surface
\[
W(1^n,a,R),
\]
which lies in a fixed level of \(\mathrm{PH}\) with a fixed number of quantifier
blocks. Assume that the address, random tape, quantified strings, and matrix
computation all have length and running time polynomial in \(n\), and that this
single-valued surface is the verifier acceptance bit for the selected strategy.
If constants \(\alpha>\beta\) satisfy
\[
H_n[a]=1\Longrightarrow \Pr_R[W(1^n,a,R)=1]\ge\alpha,
\qquad
H_n[a]=0\Longrightarrow \Pr_R[W(1^n,a,R)=1]\le\beta,
\tag{1.4}
\]
then
\[
P=NP\quad\Longrightarrow\quad \operatorname{CC}(H_n)=n^{O(1)}.
\tag{1.5}
\]
Consequently, a forcing family with \(\operatorname{CC}(H_n)>n^c\) for every
fixed \(c\) on a common infinite length set implies \(P\ne NP\).

#### Proof

Under \(P=NP\), the fixed-level predicate \(W\) collapses to a deterministic
polynomial-time evaluator. Take
\[
t_n=O\!\left(\frac{\ell_n+\log(1/\delta+2)}{(\alpha-\beta)^2}\right)
\]
independent public tapes. Hoeffding's inequality and a union bound over the
at most \(2^{\ell_n}\) valid addresses give a fixed multiset of tapes for
which every empirical acceptance rate is within \((\alpha-\beta)/3\) of its
expectation. Hardwiring this multiset and thresholding at
\((\alpha+\beta)/2\) computes every bit of \(H_n\). The resulting circuit has
size \(n^{O(1)}\), because the entire PH input is at address scale and
\(\ell_n\le n^{O(1)}\). This proves (1.5). \(\square\)

The quantifier is essential: \(\forall a\,\exists\mathcal S_{n,a}\) alone does not
define a word-consistent surface, since the witnesses may be incompatible across
addresses. Conversely, once a single-valued surface exists, different strategies
do not provide a further escape; their remaining cost is the size of the surface.
More quantitatively, if the total length of the address, descriptor, random tape,
quantified strings, and matrix is at most \(L_n\), and the deterministic evaluator
under \(P=NP\) runs in time \(L_n^{c_*}\), then
\[
\operatorname{CC}(H_n)
 =O\!\left(t_n\bigl(L_n^{c_*}+\log(t_n+2)\bigr)\right).
\tag{1.6}
\]
Thus a forcing threshold \(S_n\) yields the explicit alternative
\[
P\ne NP\quad\text{or}\quad
L_n=\Omega\!\left((S_n/t_n)^{1/c_*}\right),
\tag{1.7}
\]
up to comparator overhead. In the RW regime where the address length is
\(\Theta(\log n_i)\) but the published `Reconf` witness has size
\(O(n_{i+1}^4\log(t_i+2))\), (1.6) is object-scale rather than address-scale.
Therefore Proposition 1.3 closes the per-address-strategy loophole only after a
new RW-specific compression theorem supplies the single-valued surface; it does
not claim that the published `Reconf` construction already supplies that interface.

### Proposition 1.3A (published RW failure branch already has a semantic surface)

The preceding address-scale proposition should be separated from the physical
same-proof requirement used by the family-level coding arguments.  Fix a failure
call of Theorem 4.1, let (\tau_x) be the common canonical prefix identified in
Proposition 6.32, and let (A_{x,\tau,i}(C,\rho)) be the deterministic verifier
inside the final `prMA` query.  Define

\[
  W_{x,\tau}(i):=\exists C\;\forall\rho\;
  A_{x,\tau,i}(C,\rho)=1 .
\tag{1.7A}
\]

This is a fixed \(\Sigma_2^P\) predicate.  Since every actual final query is smart,
`prMA` completeness and soundness give

\[
  W_{x,\tau_x}(i)=f(x)_i\qquad(i\in[t]).
\tag{1.8A}
\]

Thus published `Reconf` already supplies a semantic, single-valued output surface on
its failure inputs, even though different coordinates may have different accepting
Merlin circuits.  Under \(P=NP\), this surface is evaluated deterministically; with
(x,\tau_x) hardwired, its circuit cost is polynomial in the complete query input
length.  No public-tape sampling is needed here: probability-one completeness is
exactly the universal quantifier over the finite random tape.

At object scale, even the common prefix is unnecessary.  Let \(C_x\) be the
raw-history circuit from Ren--Williams Lemma 3.2, let
\(\alpha_x^\star\) be its lexicographically largest satisfying assignment, and
let \(\operatorname{out}_i(\alpha)\) denote coordinate \(i\) of the output field
in that history.  The fixed two-alternation relation
\[
\begin{aligned}
 W_{\rm lex}(x,i):={}&\exists\alpha\;\forall\beta:\quad
 C_x(\alpha)=1
 \;\wedge\;\operatorname{out}_i(\alpha)=1\\
 &{}\wedge
 \bigl(C_x(\beta)=0\;\vee\;\beta\le_{\rm lex}\alpha\bigr)
\end{aligned}
\tag{1.8A-a}
\]
satisfies
\[
 W_{\rm lex}(x,i)=f(x)_i.
\tag{1.8A-b}
\]
Indeed, a witness to (1.8A-a) must be the unique lexicographically largest
satisfier \(\alpha_x^\star\), whose output field is the actual output of the
source machine.  This surface uses no PCP proof, auxiliary proof, AVOID
generator, JK transcript, failure promise, or \(\tau_x\).  Its histories and
matrix still have length \(\operatorname{poly}(t)\), so it removes a semantic
pseudo-obstacle without improving the load-bearing scale.

This is a source-specific refinement, not a new common-proof theorem.  In the stable
RW parameters, the query input and quantified witness are still
  \(\operatorname{poly}(n_{i+1})\), while the forced table \(B_i\) has address length
  \(\Theta(\log n_i)\).  Hence the proposition removes “different Merlin witnesses”
as a separate Gate-III obstruction, but leaves the object-to-address compression
problem untouched.  The surface is also a singleton semantic statement and therefore
does not trigger the family-level RLDC implications of Theorem 6.4.

The formal source notes are
[C508](../../../mcsp-hardness-magnification/notes/508-rw-failure-branch-semantic-ph-surface-2026-08-19.md)
and the \(\tau\)-free refinement
[C584](../../../mcsp-hardness-magnification/notes/584-rw-tau-free-lexmax-raw-history-surface-2026-08-26.md).

### Proposition 1.3B (published RW branch-complete gate)

The failure and solver branches can be aligned on the same published hard output,
rather than forced into one physical protocol.  Let
\[
B_n=A'(1^n),\qquad N_n=2n,\qquad
\operatorname{CC}(B_n)=\Omega\!\left(\frac{N_n}{\log(N_n+2)}\right)
\]
on the infinitely-often hard lengths of Theorem 4.3--4.5.  If the correct advice selects
the failure/reconstruction branch, Proposition 1.3A gives an exact single-valued
\(\Sigma_2^P\) surface.  If its complete input, quantified strings, and matrix have total
length \(L_n\), then under \(P=NP\)
\[
\operatorname{CC}(B_n)=O(L_n^{c_*}+L_n),
\qquad
L_n=\Omega\!\left(
\left(\frac{N_n}{\log(N_n+2)}\right)^{1/c_*}
\right).
\tag{1.8B}
\]
Thus different Merlin circuits do not create a further failure-branch escape; only
object-to-address compression could help, and address-scale compression contradicts the
same forcing word.  If the correct advice selects the solver-success branch, the published
statement gives only a child outsider \(Y_n\notin\operatorname{Range}(G_n)\).  Any
same-object, single-valued, charged parent-binding evaluator is covered by the
support-payment bound
\[
\operatorname{CC}(B_n)
\le O\!\left(g_n+q_nL_n^{\rm pkg}(\ell_n+a_n)+\ell_n\right),
\tag{1.8C}
\]
and hence must pay the forcing scale.

Consequently, if a branch-local theorem supplies the address-scale interface for whichever
advice branch occurs at every hard length, the infinite pigeonhole principle yields
\(P\ne NP\): one of the two branches occurs on infinitely many hard lengths, and its
address-scale interface contradicts the same \(B_n\) lower bound.  This is a conditional
branch-complete criterion, not a claim that either interface is currently available.  The
formal source statement is [C509](../../../mcsp-hardness-magnification/notes/509-rw-published-branch-complete-closure-2026-08-19.md).

The branch choice itself creates no further nonuniform obstruction.  More precisely,
suppose there are finitely many fixed PH predicates \(W_1,\ldots,W_r\), of uniformly
bounded alternation depth, such that for every hard length \(n\) there are a branch
\(b_n\in[r]\) and a common descriptor \(\sigma_n\) satisfying
\[
 |\sigma_n|=(\log N_n)^{O(1)},\qquad
 \forall a<N_n:\quad
 W_{b_n}(1^n,\sigma_n,a)=B_n[a],
\tag{1.8C-a}
\]
and every explicit input, quantified string, and matrix description of every \(W_b\)
has length \((\log N_n)^{O(1)}\).  Pad the predicates with dummy quantifiers to a common
alternation depth and place the finite branch bit inside the quantifier-free matrix.  This
gives one fixed PH predicate \(W\) with
\[
 W(1^n,b_n,\sigma_n,a)=B_n[a]
 \qquad(a<N_n).
\tag{1.8C-b}
\]
Under \(P=NP\), hardwiring \((b_n,\sigma_n)\) therefore yields a
\((\log N_n)^{O(1)}\)-size evaluator for \(B_n\), contradicting the same forcing bound.
No uniform algorithm for choosing \(b_n\) is needed, since circuit complexity is
nonuniform.

The common-descriptor quantifier order is essential.  The weaker statement
\(\forall a\,\exists(b_{n,a},\sigma_{n,a})\) has the trivial realization
\(\sigma_{n,a}=B_n[a]\) and yields no common evaluator.  Likewise, an \(n\)-dependent
number of branches, uncontrolled PH depth, or object-scale quantified strings cannot be
hidden behind short length labels.  Proposition 1.3E below gives the precise exception:
a quantitatively bounded drifting depth can still compile below the hard-word scale.
Thus branch absorption removes only the selector issue; it does not supply the missing
failure-side quantifier compression or success-side parent binding.

### Proposition 1.3C (range-rich JK success-fingerprint barrier)

Let \(G:\{0,1\}^{n}\to\{0,1\}^{2n}\) have range size
\(r=|\operatorname{Range}(G)|\), and let \(T=n2^K\).  For any outsider \(y\), the
top-stage JK input family
\[
F_{\mathbf z}=z_1\Vert\cdots\Vert z_{2^{K-1}-1}\Vert y,
\qquad z_j\in\operatorname{Range}(G),
\]
has \(r^{2^{K-1}-1}\) parents with the same hard/stage/position/outsider transcript.
Consequently a transcript-only parent descriptor has length at least
\[
(2^{K-1}-1)\log_2 r.
\tag{1.8D}
\]
If \(r\ge2^{\gamma n}\), this is \(\Omega(T)\), and counting gives a parent in the
fiber of complexity \(\Omega(T/\log T)\).  Thus a success-output binder uniform over
range-rich AVOID families cannot supply the missing address-scale attachment.  It must
use source-specific information about the canonical PCP image, or explicitly leave the
transcript-only model.  This is the formal source statement [C510](../../../mcsp-hardness-magnification/notes/510-range-rich-jk-parent-fiber-barrier-2026-08-19.md);
it remains family-level and does not prove the published singleton impossible.

The same obstruction applies verbatim to a total fixed-PH binder.  More generally, fix
public data \((G,\tau)\), let \(\varnothing\ne\mathcal F(\tau)\subseteq\{0,1\}^T\)
be a finite fiber of parents sharing that success transcript, and let \(W\) be any fixed
total predicate.  Count every
parent-dependent branch, predicate, and context description inside
\(\sigma_P\in\{0,1\}^d\).  If
\[
 \forall P\in\mathcal F(\tau)\;\exists\sigma_P\;\forall a<T:\qquad
 W(G,\tau,\sigma_P,a)=P[a],
 \tag{1.8D-a}
\]
then
\[
 d\ge\log_2|\mathcal F(\tau)|.
 \tag{1.8D-b}
\]
Indeed, for fixed \((G,\tau,\sigma)\), total semantics defines one word as a function of
\(a\).  Two distinct parents therefore cannot use the same descriptor.  The argument is
semantic and is unaffected by PH alternations or by different quantified witnesses at
different addresses.  Proposition 1.3C consequently gives \(d=\Omega(T)\) for its
range-rich fibers even when \(W\) lies in a fixed level of PH.

Thus fixed-PH legality of two branch-local relations does not itself glue them to one
parent.  The failure branch is not simultaneously available as free side information on
a success execution; if its parent-dependent data are supplied there, they are part of
\(\sigma_P\) and are charged by (1.8D-b).  Conversely, this argument does not rule out
the published fixed-\(x_0\) singleton: its fiber may contain only the actual canonical
proof.  That remaining case requires a source-specific, transcript-external global
relation, not a generic PH normalization.

### Proposition 1.3D (fixed-PH branch closure yields \(\mathrm{SAT}\notin P/\mathrm{poly}\))

Let \(B_n\in\{0,1\}^{N_n}\) be a word family on an infinite length set
\(\mathcal I\), put
\[
 m_n:=\left\lceil\log_2(N_n+1)\right\rceil,
\]
and suppose that, on a common infinite subsequence,
\[
 \operatorname{CC}(B_n)>m_n^c
 \quad\text{for every fixed }c.
\tag{1.8E}
\]
Let \(W_1,\ldots,W_r\) be finitely many total predicates in fixed levels of
\(\mathrm{PH}\), with a uniform bound on their alternation depth. Suppose that
for every \(n\in\mathcal I\) there are a branch \(b_n\in[r]\), a binary
length/context string \(\eta_n\), and one descriptor \(\sigma_n\), shared by
all addresses, such that
\[
 |\eta_n|+|\sigma_n|=m_n^{O(1)}.
\tag{1.8F}
\]
All explicit inputs, random tapes, quantified strings, and matrix descriptions
of \(W_{b_n}\) have length \(m_n^{O(1)}\). Assume either the exact identity
\[
 W_{b_n}(\eta_n,\sigma_n,a)=B_n[a]
 \qquad(a<N_n),
\tag{1.8G}
\]
or the gap form
\[
 \begin{aligned}
 B_n[a]=1&\Longrightarrow
   \Pr_R[W_{b_n}(\eta_n,\sigma_n,a,R)=1]\ge\alpha_n,\\
 B_n[a]=0&\Longrightarrow
   \Pr_R[W_{b_n}(\eta_n,\sigma_n,a,R)=1]\le\beta_n,
 \end{aligned}
\tag{1.8H}
\]
where
\[
 \alpha_n-\beta_n\ge m_n^{-O(1)}.
\tag{1.8I}
\]
Then
\[
 \boxed{\mathrm{SAT}\notin P/\mathrm{poly}.}
\tag{1.8J}
\]
Equivalently, \(NP\nsubseteq P/\mathrm{poly}\), and hence \(P\ne NP\).

#### Proof

Assume for contradiction that
\(\mathrm{SAT}\in P/\mathrm{poly}\). Since SAT is NP-complete under
polynomial-time many-one reductions,
\[
 NP\subseteq P/\mathrm{poly}.
\tag{1.8K}
\]
We first record the resulting nonuniform closure
\[
 PH\subseteq P/\mathrm{poly}.
\tag{1.8L}
\]
Indeed, (1.8K) also gives
\(NP/\mathrm{poly}\subseteq P/\mathrm{poly}\): for a language represented
by an NP verifier with advice \(a_n\), apply (1.8K) to the NP language on
paired inputs \((x,a)\), then hardwire \(a_n\). Induct on the PH level.
If an oracle language at the preceding fixed level has polynomial-size
circuits, package the circuits for all polynomially bounded query lengths
as polynomial advice and replace every oracle query by its circuit. The
next existential level lies in \(NP/\mathrm{poly}\), hence in
\(P/\mathrm{poly}\); complement closure gives the universal level. This
proves (1.8L).

Apply (1.8L) to the finitely many fixed predicates \(W_b\). On inputs of
length \(m_n^{O(1)}\), each has circuits of size \(m_n^{O(1)}\). In the
exact case, hardwire \(b_n,\eta_n,\sigma_n\) into the appropriate circuit,
leaving only the address \(a\) free. This computes the complete word
\(B_n\) with size \(m_n^{O(1)}\).

In the gap case, take
\[
 t_n=O\!\left(
   \frac{m_n+1}{(\alpha_n-\beta_n)^2}
 \right)
 =m_n^{O(1)}
\tag{1.8M}
\]
independent tapes. Hoeffding's inequality and a union bound over the
\(N_n\le2^{m_n}\) addresses give one fixed tape multiset whose empirical
acceptance probabilities separate every one-address from every zero-address.
Hardwire these tapes, evaluate the \(t_n\) PH circuits, and threshold between
\(\alpha_n\) and \(\beta_n\). The resulting circuit for \(B_n\) again has
size \(m_n^{O(1)}\). In both cases this contradicts (1.8E) on the common
infinite subsequence. Therefore
\(\mathrm{SAT}\notin P/\mathrm{poly}\). \(\square\)

The common-descriptor, totality, and address-scale hypotheses are load-bearing.
Fixed PH is a convenient sufficient condition, not a necessary one: Proposition 1.3E
allows controlled growing depth. A promise predicate without a total extension,
uncontrolled PH depth, object-scale quantified strings, or the order
\(\forall a\,\exists\sigma_{n,a}\) is not covered. Conversely, no uniform
algorithm for finding \(b_n\), \(\eta_n\), \(\sigma_n\), or the good tape
multiset is needed: all are legitimate nonuniform constants in the circuit
lower-bound contradiction.

For the published RW hard outputs of Proposition 1.3B, the near-maximum
\(\Omega(N_n/\log N_n)\) forcing bound implies (1.8E). Hence a
branch-complete same-object fixed-PH compression, or the controlled growing-depth
compression of Proposition 1.3E, would prove the stronger
conclusion (1.8J), not merely the \(P\ne NP\) conclusion obtained from
\(P=NP\) determinization. The proposition supplies this final nonuniform
arrow; it does not construct the missing success-side parent binding or
compress the failure-side quantified strings.

### Proposition 1.3E (quantitative growing-alternation branch closure)

At the published RW hard-word scale, the fixed-depth hypothesis in Proposition
1.3D can be relaxed quantitatively.  After hardwiring the branch, common context,
and common descriptor, suppose an exact address surface has the form
\[
 W_m(a)=Q_1u_1\cdots Q_du_d\,
 R_m(a,u_1,\ldots,u_d),
\tag{1.8N}
\]
where every quantifier block has length at most \(m^b\), and the matrix itself is
an ordinary fan-in-two Boolean circuit over a fixed finite basis, with actual gate
count and explicit gate-list/input layout at most \(m^b\).  It contains no oracle
or succinct gates; any expansion cost is charged in this bound.  The total quantified
layout and explicit surface description are bounded by one fixed polynomial in \(m\),
and \(b\) is fixed across the levels of the surface.  If
\(\mathrm{CircuitSAT}\in\mathrm{SIZE}[L^\kappa]\), then there are constants
\(\Gamma>1\) and \(A>0\) such that
\[
 \operatorname{CC}(W_m)\le m^{A\Gamma^d}.
\tag{1.8O}
\]
Here \(\Gamma\) depends only on \(\kappa\) and the fixed circuit-encoding
convention, while \(A\) may also depend on \(b\).  Against a hard-word family
with address-circuit lower bound \(2^{m-o(m)}\), including the published RW
family with lower bound \(\Omega(2^m/m)\), this compilation contradicts hardness
whenever
\[
 \Gamma^{d(m)}\log m=o(m).
\tag{1.8P}
\]
In particular, \(d=o(\log m)\) is sufficient at the RW hard-word scale.  For a
general family satisfying only the superpolynomial condition (1.8E), the
compiled upper bound must instead be compared with that family's actual lower
bound; subexponential size alone need not contradict (1.8E).  A bare assertion
\(d=\Theta(\log m)\) is not sufficient even at the RW scale: the implicit
constant must be compared with \(\Gamma\).

For the RW recurrence there is a second, source-specific sufficient condition.
Theorem 4.3 permits every sufficiently large fixed integer \(C>D+1\).  Along a
permitted sequence \(n_0=2^q\), with \(q\) not divisible by \(C\), let
\(n_{i+1}=n_i^C\) and write
\(B^{(C)}_{q,i}=A'_C(1^{n_i})\).  Here \(A'_C\) is project notation for the
published one-bit-advice algorithm instantiated with \(C\), with its correct
advice bit suppressed.  The address length is
\[
 m_i=\left\lceil\log_2(2n_i+1)\right\rceil
     =qC^i+O(1).
\tag{1.8Q}
\]
For each sufficiently large admissible \(C\), the RW proof selects at least one
good level \(i=i(q)\) from every sufficiently large permitted starting sequence;
these selected lengths are distinct.  Suppose a branch-complete surface theorem
applies to the same published word \(B^{(C)}_{q,i(q)}\) at every such selected
level.  For each fixed \(C\), suppose there are constants \(b_C,g_C\), independent
of \(q\) and \(i\), such that every block, actual matrix circuit, query encoding,
common descriptor, and random tape has size at most \(m_i^{b_C}\), and any
randomized surface is in the common-threshold gap form (1.8H), with gap at least
\(m_i^{-g_C}\).  Finally suppose
\[
 d_i\le\alpha i+\beta
\tag{1.8R}
\]
for constants \(\alpha,\beta\) independent of \(C,q\).  Then that theorem implies
\[
 \mathrm{SAT}\notin P/\mathrm{poly},
\tag{1.8S}
\]
even though \(d_i=\Theta(\log m_i)\) may hold.

#### Proof

Eliminate the quantifier blocks in (1.8N) from the inside out.  If the current
suffix evaluator has size \(S_j\), the next existential block is a CircuitSAT
instance whose explicit gate-list encoding has length
\[
 L_j=O((S_j+m^b)\log(S_j+m^b)).
\tag{1.8T}
\]
Feed this encoding to the \(L_j^\kappa\)-size CircuitSAT circuit; handle a
universal block by complementing before and after the same construction.  For
a fixed \(\Gamma>1\) absorbing \(\kappa\) and the encoding overhead,
\[
 S_{j+1}\le(S_j+m^b)^\Gamma.
\tag{1.8U}
\]
Starting from \(S_0\le m^b\), induction gives (1.8O).  Its binary logarithm is
at most \(A\Gamma^d\log_2m\), so condition (1.8P) makes the compiled
size \(2^{o(m)}\), below the stated near-maximum forcing scale.  This is
iterated-polynomial cost, not the generally unjustified estimate \(m^{O(d)}\).

For (1.8S), assume instead that
\(\mathrm{SAT}\in P/\mathrm{poly}\), fix the resulting \(\kappa\) and
\(\Gamma\), and then choose an admissible
\[
 C>\max\{D+1,\Gamma^\alpha\}.
\tag{1.8V}
\]
This order of choices is legal only because the proposed surface theorem is
universal over all sufficiently large fixed \(C\), with its resource and gap
exponents uniform over \(q,i\).  With
\(\theta=\alpha\log_C\Gamma<1\), (1.8Q)--(1.8R) imply
\[
 \log_2\operatorname{CC}(W_{m_i})
   \le O_C(m_i^\theta\log m_i)
   =o(m_i).
\tag{1.8W}
\]
Apply (1.8W) at the selected level \(i=i(q)\) from every sufficiently large
permitted starting sequence.  Uniformity of the resource and gap exponents in
\(q\) makes the estimate hold along these distinct lengths.  Hence the published
RW hard words \(B^{(C)}_{q,i(q)}\) would have \(2^{o(m_i)}\)-size address
circuits, contradicting their \(\Omega(2^{m_i}/m_i)\) lower bound.  The
inverse-polynomial-gap case of
Proposition 1.3D is identical after hardwiring polynomially many tapes: the
sampling and threshold overhead does not change (1.8W).  This proves (1.8S).
\(\square\)

This relaxation is conditional on a new surface, not a construction of one.
The raw-history surface (1.8A-a) already has fixed depth two but uses
\(\operatorname{poly}(n_{i+1})=2^{\Theta(m_i)}\)-size quantified objects and
matrix.  It therefore fails the address-scale premise before depth matters.
If the block count or the compilation base depends on \(C\), the general
replacement for (1.8V) is the existence of a \(C\) satisfying
\(\Gamma(C)^{\alpha(C)}<C\).  A result for one preselected \(C_0\), a
polynomial or gap exponent that depends on \(q\) or the level, or a SAT query
hiding a lower oracle circuit does not meet the proposition.  The full model
separation and recurrence are recorded in [C586](../../../mcsp-hardness-magnification/notes/586-growing-alternation-has-iterated-polynomial-cost-and-rw-growth-can-absorb-it-2026-08-26.md).

### Proposition 1.4 (representation-to-address black-box barrier)

The object-scale stable branch cannot be converted to the address scale by a black-box
invocation of its full-table generator. More precisely, if a generator exposes only a
sequential stream of the \(N_n\) output bits, exact random access has a worst-case

\[
  \Omega(N_n)
\tag{1.12}
\]

symbol-observation cost. Independently, for \(N=2^m\), there are \(N\)-bit tables with
linear-size full-table representations but with no \(2^{m/3}\)-size address circuit,
even after \(2^{m/3}\) advice bits are supplied. Hence an \(N^{O(1)}\) object-scale
evaluator alone does not imply a \((\log N)^{O(1)}\) address evaluator.

#### Proof

The streaming assertion follows by answering all observed stream symbols with zero. On
the query for the final address, if fewer than \(N\) symbols were observed, two tables
that agree on the transcript and differ at an unobserved position force the same
algorithmic output but require different answers. For the counting assertion, the number
of fan-in-two circuits of size \(s=2^{m/3}\) on \(m\) inputs, together with an arbitrary
\(s\)-bit advice string, is at most

\[
  2^{O(s\log(s+m))}=2^{2^{m/3}O(m)},
\]

whereas the number of \(m\)-input tables is \(2^{2^m}\). A table outside the former set
has an \(O(N)\)-size hardwired full-table representation but no such address evaluator.
The detailed black-box formulations are recorded in [note 359](../../../mcsp-hardness-magnification/notes/359-representation-to-address-black-box-barrier-2026-08-18.md).
\(\square\)

This is a representation barrier, not a lower bound for the actual uniform RW solver:
the selected counting family is nonuniform. Its role is narrower and decisive: any
actual closure must use a structural random-access theorem (for example the
single-valued PH surface of Proposition 1.3), not just \(P=NP\) determinization of
`Solve`/`Reconf`.

### Proposition 1.5 (choice-robust JK easy branch)

The easy-branch circuit argument does not require lexicographically smallest preimages.
Let \(G:\{0,1\}^{q}\to\{0,1\}^{2q}\), let \(f'\in\{0,1\}^{q2^h}\), and recursively
split \(f'\) into \(2q\)-bit blocks. Whenever a block \(z\) is in
\(\operatorname{Range}(G)\), choose any *single word*
\(u_z\in G^{-1}(z)\) for that occurrence; if a block is outside the range, output it as
the Range-Avoidance witness. If every encountered block remains in the range, the
concatenated root \(y_0\) satisfies the same iterated relation as the original
Jeřábek--Korten recursion, and hardwiring \(y_0\) gives

\[
  \operatorname{CC}(f')=O\!\left(h(|G|+q)\right).
\tag{1.13}
\]

#### Proof

At each recursion level, \(G(u_z)=z\) holds blockwise, so induction gives
\(y_i=G^{\otimes 2^{i-1}}(y_{i-1})\). Following the address bits through the appropriate
\(G_0/G_1\) branch at each of the \(h\) levels computes the requested output block, and
a fixed coordinate selector reads its requested bit. Duplicating \(G\) at each level gives
(1.13). The argument never uses minimality or equality of choices on repeated blocks. If
some block is not in the range, its first occurrence is already an explicit outsider.
\(\square\)

Consequently, a replacement for the published lex-first selector needs only to output a
word-consistent legal preimage on each actual range occurrence; bitwise
\(\forall\ell\,\exists u_\ell\) choices are insufficient. The locally uniform tableau
selector known for the systematic output blocks can therefore be used without matching
the lex-first history. This removes lexicographic canonicalization as a separate Gate-I
obstruction. It does not supply selectors for the non-systematic Reed--Muller,
auxiliary-PCP, or recursive-JK blocks, and changing choices may change the first
non-range level. The remaining positive target is a selector for those blocks, or a JK
variant that verifies such selectors locally. The full statement and source boundary
are recorded in [note 360](../../../mcsp-hardness-magnification/notes/360-choice-robust-jk-easy-branch-2026-08-18.md).

### Proposition 1.6 (succinct universal-gate barrier)

There is a further obstruction to a generic address-scale Local-JK physicalization.
Let \(q=2^m\), and let \(G_q\) be the universal truth-table generator whose seed
\(u\in\{0,1\}^q\) describes a circuit \(C_u\) on \(m+1\) inputs, so that
\(G_q(u)[r]=C_u(r)\). If \(U\) is a size-\(\operatorname{poly}(m)\) circuit generating
the seed bits \(u[\ell]\) on demand, then the problem of computing \(G_q(u)[r]\) for
all such \(U,r\) is EXP-hard. Hence a uniform \(\operatorname{poly}(m)\)-time generic
evaluator would imply \(\mathrm{EXP}=\mathrm P\).

#### Proof

Reduce the succinct circuit value problem. A succinct description \(U_C\) of a circuit
\(C\) with \(q/(cm)\) gates can be used, with fixed padding, as the seed generator for
the gate-list description \(u_C\). Then
\[
G_q(u_C)[r]=C(r).
\]
Succinct circuit value remains EXP-complete at this padded gate scale, so a polynomial
address-scale evaluator would put EXP in P, contradicting deterministic time hierarchy.
\(\square\)

Therefore a successful selector must restrict seeds to a syntactically evaluable subclass,
or replace exact universal-gate evaluation by a new relation-PCP predicate. The proposition
does not rule out such a structured RW-specific selector; it rules out treating an
arbitrary succinct preimage as a generic address-scale word. The full reduction and its
source boundary are recorded in [note 361](../../../mcsp-hardness-magnification/notes/361-succinct-universal-gate-barrier-2026-08-18.md).

The same gate has a nonuniform boundary. If \(D_m\) is a size-\(m^{O(1)}\) circuit
family that evaluates \(G_q(u)[r]\) for every succinct seed generator \(U\) of
description length \(m^{O(1)}\), then the succinct circuit-value reduction gives
\(\mathrm{EXP}\subseteq\mathrm{P/poly}\). This is not an unconditional contradiction;
it is why a \(P/\mathrm{poly}\) closure must be proved for the actual RW seed subclass
rather than for generic succinct seeds. The fixed canonical seed used by one published
singleton is outside the quantifier of this generic statement.
Under the contradiction hypothesis \(P=NP\), however, the generic nonuniform route is
also impossible: \(\mathrm{PH}=P\), while the Karp--Lipton/Meyer exponential version
would turn \(\mathrm{EXP}\subseteq\mathrm{P/poly}\) into
\(\mathrm{EXP}=\Sigma_2^P=P\), contradicting deterministic time hierarchy.
The precise nonuniform reduction and its open-boundary status are recorded in
[note 430](../../../mcsp-hardness-magnification/notes/430-nonuniform-succinct-universal-gate-boundary-2026-08-19.md).

### Proposition 1.7 (succinct PCP/PCA import boundary)

A standard succinct PCP for SAT has all-proof soundness but proof length polynomial
only in the number of variables. Fortnow--Santhanam show that such an object would
imply \(\mathrm{NP}\subseteq\mathrm{coNP/poly}\) and a collapse of PH. This is a
standard-complexity boundary, not the final \(P\ne NP\) contradiction: under the
temporary assumption \(P=NP\), the implication \(\mathrm{NP}\subseteq\mathrm{coNP/poly}\)
is already consistent.

Succinct publicly verifiable PCAs avoid that boundary only by changing the
quantifier. Bronfman--Rothblum assume sub-exponential LWE and a common reference
string, and reject efficiently generated false proofs; an accepting false proof
may exist. Hence their PCA does not supply the RW hypotheses of all-proof
target-relative smartness, one common proof/address space, and determinization
under \(P=NP\).

The automatic inference “a succinct proof exists, therefore the RW history is in
\(P/\mathrm{poly}\)” is consequently invalid. A successful attachment must either
prove a new RW-specific all-proof relation-PCP theorem, add an unconditional bridge
from PCA soundness to the actual all-proof semantics, or leave the black-box
succinct-PCP/PCA model. The source-audited boundary is recorded in
[note 362](../../../mcsp-hardness-magnification/notes/362-succinct-pcp-pca-closure-boundary-2026-08-18.md).

### Proposition 1.8 (RW reconstruction-width/round conservation)

Suppose a failed RW Solve call at child width \(k\) invokes Reconf on the same
target \(f(x)\), with work and query descriptions bounded by
\((k+r+\log T)^{O(1)}\). By C387, the perfect-completeness prMA queries in the
published RW encoding have a promise-preserving deterministic simulator under
\(P=NP\), obtained from the \(\Sigma_2^P\) predicate
\(\exists w\,\forall r\,V(q,w;r)=1\). Thus a failed call yields an address evaluator
for \(f(x)\) of size
\[
  (k+r+\log T)^{O(1)}.
\]

If \(\operatorname{CC}(f(x))>S\), every failed call must consequently satisfy
\[
  k+r+\log T=\Omega(S^{\Omega(1)}).
\]

In particular, choosing a small child width does not by itself produce an
address-scale evaluator: if the round parameter remains object-scale, it already
pays the full cost; if both width and rounds are address-scale, the failed branch
is impossible on a hard target and Solve must return an AVOID outsider. The
published RW recurrence has \(k=n_{i+1}=n_i^C\) and \(r_i=O(n_i)\), so its natural
Reconf branch remains object-scale. This source-level width/round barrier and its
padded-table corollary are recorded in
[note 363](../../../mcsp-hardness-magnification/notes/363-rw-reconstruction-width-round-conservation-2026-08-18.md).

### Proposition 1.9 (static-package Closure Theorem)

The bottom, cover-sheet, descriptor, and address-scale questions admit one
quantitative normal form. Let \(H_n\in\{0,1\}^{N_n}\), put
\(m_n=\lceil\log_2(N_n+1)\rceil\), and suppose a proposed attachment supplies one
target-dependent package \(\sigma_n\in\{0,1\}^{d_n}\) shared by all addresses. The
package may contain the common proof, cover sheet, descriptor, canonical key, and
strategy summary. Assume that after \(P=NP\) determinization, a single evaluator
\(E_n(a;\sigma_n,R)\), with \(R\in\{0,1\}^{u_n}\), has finite control \(p_n\),
uses at most \(b_n\le p_n\) read-only accesses to \(\sigma_n\). Let \(L_n\)
bound the description length of every collapsed oracle/PH query generated by the
evaluator, and let \(\tau_n\) be its deterministic running time excluding ROM
expansion. For a fixed collapse-simulator exponent \(c_\star\), a control making
at most \(p_n\) such calls has \(\tau_n=O(p_nL_n^{c_\star}+p_n^2)\). Assume also
a single-valued gap \(\gamma_n=\alpha_n-\beta_n>0\):

\[
 H_n[a]=1\Longrightarrow\Pr_R[E_n(a;\sigma_n,R)=1]\ge\alpha_n,\qquad
 H_n[a]=0\Longrightarrow\Pr_R[E_n(a;\sigma_n,R)=1]\le\beta_n.
\tag{1.14}
\]

If \(\sigma_n\) and the sampled tapes have polynomial advice length, then with
\(t_n=O((m_n+\log(1/\delta_n+2))/\gamma_n^2)\),

\[
 \operatorname{CC}(H_n)\le
 O\!\left(t_n\bigl(\tau_n+b_nd_n+m_n+\log(t_n+2)\bigr)\right)
\tag{1.15}
\]

under \(P=NP\). Consequently, a forcing lower bound \(S_n\) implies

\[
 \tau_n+b_nd_n+m_n+\log(t_n+2)=\Omega(S_n/t_n),
\tag{1.16}
\]

unless \(P\ne NP\). In the address-scale regime, a near-maximum forcing scale
\(S_n=2^{\Omega(m_n)}/\operatorname{poly}(m_n)\) therefore forces an
object-scale package or control term, or a vanishing gap that makes \(t_n\)
superpolynomial.

#### Proof

Choose \(t_n\) public tapes by Hoeffding sampling and a union bound over the
\(2^{m_n}\) addresses. Thresholding the empirical acceptance rates recovers all
bits of \(H_n\). For each tape, the collapsed query simulator contributes
\(\tau_n\); each ROM read expands to a fan-in-two multiplexer of size \(O(d_n)\),
and address/threshold bookkeeping contributes \(O(m_n+\log(t_n+2))\).
Duplicating over \(t_n\) tapes gives (1.15), and (1.16) follows by rearrangement.
The same package serves every
address, so a bottom or cover branch that remains within the interface is already
accounted for; if different addresses require different packages, the normal form
fails rather than yielding a closure. Full details and the advice-length boundary
are in [note 364](../../../mcsp-hardness-magnification/notes/364-rw-static-package-closure-theorem-2026-08-18.md).

### Proposition 1.10 (common-witness payment and the Reconf quantifier gap)

The published Reconf theorem does not force the Merlin circuits used for two
different addresses to agree. A valid common-witness strengthening would have one
circuit \(C^\star\) whose decoded proof word is the entire target \(f(x)\). If
\(S=\operatorname{CC}(f(x))\), \(Q\) is the description length of a YES query
using \(C^\star\), and the fixed prMA witness bound is \(Q^{d_{\rm MA}}\), then
\[
 Q\ge
 \Omega\!\left(
 \left(S/\operatorname{polylog}T\right)^{\Omega(1/d_{\rm MA})}
 \right).
\tag{1.17}
\]
Thus a near-maximum \(S=2^{\Omega(\log T)}/\operatorname{poly}(\log T)\)
forces an object-scale query. This is a conditional payment lemma: the source
proof only exhibits the canonical \(\Pi_x\) as one valid witness and permits a
different accepted circuit \(C_j\) for each coordinate. Therefore the complexity
of \(\Pi_x\) cannot be charged to the published per-address queries without a
new same-witness/whole-word theorem. The exact quantifier audit is in
[note 365](../../../mcsp-hardness-magnification/notes/365-rw-reconf-common-witness-quantifier-gap-2026-08-18.md).

### Proposition 1.11 (simultaneous common-witness payment)

The one-sided payment in Proposition 1.10 has a two-branch form that removes the
all-zero target loophole. Let \(f\in\{0,1\}^{T}\), \(S=\operatorname{CC}(f)\), and let
\(\mathsf{Dec}_T\) satisfy
\[
\operatorname{CC}\!\left(\mathsf{Dec}_T(\Pi_C)\right)
\le A(s+\log(T+2))^{c_D}\log(T+2)^{v_D}
\tag{1.18}
\]
for every proof circuit \(C\) of size \(s\). Suppose a simultaneous interface has
two queries \(q_{i,0},q_{i,1}\) per coordinate, every query of description length
\(Q_i\) has Merlin witness length at most \(Q_i^{d_M}\), and one circuit \(C^\star\)
is a witness for every correct query \(q_{i,f_i}\). If
\(\mathsf{Dec}_T(\Pi_{C^\star})=f\), then
\[
Q_i\ge
\left[
\left(\frac{S}{A\log(T+2)^{v_D}}\right)^{1/c_D}
-\log(T+2)
\right]_+^{1/d_M}
\tag{1.19}
\]
for every \(i\in[T]\). Hence a near-maximum target
\(S=2^{\Omega(\log T)}/\operatorname{poly}(\log T)\) forces every correct
coordinate query to have object-scale description length.

The proof is direct: the common witness bound gives
\(|C^\star|\le Q_i^{d_M}\), while (1.18) and whole-word decoding give
\(S\le A(|C^\star|+\log(T+2))^{c_D}\log(T+2)^{v_D}\).
The same conclusion holds if Merlin sends a seed \(u^\star\), provided a fixed
expansion produces \(C^\star\) of size at most \(B(Q_i+1)^{d_M e}\): replace
\(|C^\star|\) by this bound, so the exponent in (1.19) becomes \(1/(d_Me)\).
Therefore a polynomial-size seeded expansion is not a new escape.
This is a conditional succinct-prMA/decoder barrier, not a claim about published
Reconf. If witnesses vary by coordinate or the shared witness does not decode to
the whole target, the theorem does not apply; those are precisely the descriptor or
phantom-word exits recorded in Propositions 1.9--1.10. Full details are in
[note 366](../../../mcsp-hardness-magnification/notes/366-address-scale-common-witness-payment-for-simultaneous-robustness-2026-08-18.md).

### Proposition 1.12 (short-fingerprint target-binding closure)

Whole-word common-witness payment is stronger than necessary for a family-level
closure. Let \(\mathcal M\) be a message family of size \(L\ge2\), with
fingerprint alphabet \(|\Lambda|\ge2\) and injective target
words \(Y(m)\in\{0,1\}^{K}\) and one common-address proof \(\Pi(m)\in\Sigma^P\).
Suppose a public fingerprint
\(\phi:\mathcal M\to\Lambda^R\) has relative distance \(\Delta_\phi>0\), and
for every fingerprint coordinate \(j\) a \(q\)-query decoder \(D_j\) satisfies
\[
\Pr[D_j^{\Pi(m)}=\phi(m)_j]=1,\qquad
\frac1R\sum_j\Pr[D_j^z\ne\phi(m)_j]\le\varepsilon
\tag{1.20}
\]
for every \(z\) within relative radius \(\rho\) of \(\Pi(m)\), where
\(\varepsilon<\Delta_\phi/2\). If \(\phi(m)_j\) and \(Y(m)_i\) are publicly
evaluable (or admit address-scale list recovery), then sampling
\[
s=O\!\left(\frac{\log(L/\eta)}
 {(\Delta_\phi-2\varepsilon)^2}\right)
\tag{1.21}
\]
fingerprint coordinates identifies \(m\) with failure probability at most \(\eta\).
Consequently the proof map is a \(\Sigma\)-ary locally decodable code for every
target coordinate, with adaptive locality
\[
Q=O\!\left(q\,\frac{\log(L/\eta)}
 {(\Delta_\phi-2\varepsilon)^2}\right).
\tag{1.22}
\]
Moreover, distinct proof words have relative distance \(>\rho\).

The proof is a direct agreement-score argument. The true fingerprint agrees with a
sampled decoder output with expectation at least \(1-\varepsilon\); every other
fingerprint agrees with expectation at most \(1-\Delta_\phi+\varepsilon\).
Hoeffding separates these scores. If two proof words were within radius \(\rho\),
the soundness inequality applied to one proof and the perfect decoder on the other
would contradict fingerprint distance. Full details are in
[note 367](../../../mcsp-hardness-magnification/notes/367-short-fingerprint-target-binding-closure-2026-08-18.md).

This is strictly weaker than Proposition 1.11: the common proof exposes only a
short injective fingerprint, not the complete target/history. Nevertheless, for a
payload family of size \(2^h\), injectivity forces
\(R\ge h/\log_2|\Lambda|\), and any applicable RLDC/LDC lower bound now applies.
Thus a non-history target-binding construction must make the fingerprint
non-injective/unseparated, make candidate evaluation non-address-scale, lose the
common target-relative soundness, or leave the common-proof/fixed-radius model.
For a single hardwired RW instance with no payload family, this proposition makes
no family-level inference and does not claim \(P\ne NP\).

### Proposition 1.13 (multi-outsider JK parent-binding communication barrier)

The one-outsider semantic exit in Proposition 1.12 has a quantitative
multi-query form. Let \(\mathcal B\subseteq\{0,1\}^{b}\) be a parent family.
Fix public JK/AVOID instances and an adaptive procedure that makes \(q\) calls,
where call \(t\) returns one \(2k_t\)-bit success outsider \(Y_t(B)\). The
procedure may choose later public instances as a function of earlier outsiders,
but it does not read \(B\) directly. If a \(d\)-bit target-dependent descriptor
\(\sigma_B\) and one decoder recover every parent exactly, then

\[
  \sum_{t=1}^{q} 2k_t+d\ \ge\ \log_2|\mathcal B|.
\tag{1.23}
\]

For a complete \(2^b\)-element family and a common width \(k\),

\[
  q\ \ge\ \frac{b-d}{2k}.
\tag{1.24}
\]

Thus \(k,q,d=\operatorname{poly}(\log b)\) cannot give family-level exact
parent binding. In the padded \(b\le2k\) regime, C377's signal/off-signal
decomposition further strengthens this: repeated off-signal outsiders on a
fixed fiber contribute no target information, so only signal outsiders and
the descriptor count toward (1.23).

#### Proof

The map
\[
  B\longmapsto
  (Y_1(B),\ldots,Y_q(B),\sigma_B)
\]
must be injective. Otherwise two different parents give the same input to the
decoder. The outsider transcript has at most
\(2^{\sum_t2k_t}\) values and the descriptor has at most \(2^d\) values,
which proves (1.23). Adaptivity does not change the count because public
instance choices are functions of the already counted transcript. The
off-signal refinement is exactly the fixed-fiber injectivity argument in C377.
\(\square\)

For the RW stage-\(i\) parent \(B_i\in\{0,1\}^{2n_i}\), an address-scale
proposal with \(k_i,q_i,d_i=\operatorname{poly}(\log n_i)\) would therefore
need \(q_i=\Omega(n_i/\operatorname{polylog}n_i)\) calls on a full parent
family, far beyond address-scale time. This is a genuine family-level
communication barrier, not a proof against the published Theorem 4.3 call:
that call fixes \(x_0\) and has a singleton target. A direct \(P\ne NP\)
conclusion still requires either a family lift or a separate argument ruling
out message-scale hidden advice for the singleton.

The source-specific statement and its scope boundary are recorded in
[note 378](../../../mcsp-hardness-magnification/notes/378-jk-parent-binding-multi-outsider-communication-barrier-2026-08-18.md).

### Proposition 1.14 (stable-stage PCP proof-length gate)

The equality \(T_i=k_i=n_{i+1}\) in the stable part of Ren--Williams Theorem 4.3 does
not by itself put the JK call in the trivial easy branch. In Theorem 4.1, `Solve` feeds
JK the canonical PCP proof \(\Pi_{x_0}\), not the output word \(f_i(x_0)\). If

\[
L_i:=|\Pi_{x_0}|,
\]

then Theorem 3.1 compares \(L_i\) with \(k_i\), whereas Theorem 3.5 supplies only

\[
L_i\le \operatorname{poly}(T_i).
\tag{1.25}
\]

Thus \(T_i=k_i\) does not imply \(L_i\le k_i\). The stable call has three source-level
cases: \(L_i\le k_i\), which is the trivial easy/failure branch; \(L_i>k_i\) with a
non-range block, which is a success outsider; and \(L_i>k_i\) with all recursive blocks
in range, which is still a nontrivial easy/failure branch. Length alone does not exclude
the last case; one needs a circuit-complexity bound for the actual PCP proof or a direct
parent-binding theorem. This is a correction to the branch inference, not a new
(P\ne NP) result. The source audit is recorded in [note 379](../../../mcsp-hardness-magnification/notes/379-rw-stable-stage-pcp-proof-length-gate-2026-08-18.md).


### Proposition 1.15 (systematic-prefix hard-exit gate)

Fix the binary serialization used by the RW PCP verifier and suppose its
systematic prefix satisfies

\[
\Pi_{x_0}[r'_i+j]=f_i(x_0)_j,\qquad 1\le j\le T_i.
\tag{1.26}
\]

If JK on \(G_k\) returns its easy branch, Theorem 3.1 supplies a circuit for
the whole proof \(\Pi_{x_0}\) of size
\(O(|G_k|\log(|\Pi_{x_0}|+2))\). Evaluating this circuit at the fixed prefix
address \(r'_i+j\) gives

\[
\operatorname{CC}(B_i)
\le O\!\left((|G_k|+1)\log(|\Pi_{x_0}|+2)\right).
\tag{1.27}
\]

Consequently, on a length where the parent has forcing complexity exceeding
the right-hand side, neither the trivial nor recursive easy branch is possible:
JK must return a success outsider. With \(|G_k|\le k^4\), stable
\(T_i=n_i^C\), and \(\operatorname{CC}(B_i)=\Omega(n_i/\log n_i)\), this
excludes \(k=(\log n_i)^{O(1)}\). The proposition is conditional only on the
fixed output-projection/serialization invariant (1.26); it does not provide
parent binding for the success outsider. See [note 380](../../../mcsp-hardness-magnification/notes/380-rw-systematic-prefix-hard-exit-gate-2026-08-18.md).

### Proposition 1.16 (easy-branch self-corrector composition)

The raw-prefix premise in Proposition 1.15 can be replaced by the fixed
Low-Degree Self-Corrector already used in the RW final query. Let \(t'\) be the
compiled CIRCUIT-SAT circuit size from Theorem 3.5, with
\(t'\le\operatorname{poly}(T_i)\), and let \(q_{\mathrm{LD}}(t')\) and
\(p_{\mathrm{LD}}(t')\) denote the resulting honest-proof query count and
control size. On an easy branch, JK supplies a circuit for
\(\Pi_{x_0}\) of size \(O(|G_k|\log(L+2))\), so ordinary circuit composition
gives

\[
\operatorname{CC}(B_i)
\le
(|G_k|+1)\log(T_i+2)^{O(1)}.
\tag{1.28}
\]

Theorem 2.3 makes the self-corrector exact on the honest polynomial on every
random tape, so one fixed tape suffices for this composition. With
\(m=\lceil\log t'/\log\log t'\rceil\), \(|H|=t'^{1/m}\), and
\(\Delta=m|H|\), its query and control costs are fixed polynomials in
\(\log(t'+2)\), hence in \(\log(T_i+2)\). Substituting these bounds into
(1.28) gives the stated \(\log(T_i+2)^{O(1)}\) bound. Consequently, when
\(|G_k|\le k^4\), \(L_i\le\operatorname{poly}(T_i)\), and the same length
has \(\operatorname{CC}(B_i)=\Omega(n_i/\log n_i)\), every
\(k=\operatorname{polylog}(n_i)\) call must return a JK success outsider,
including the \(L_i>k\) recursive-easy case. The result still does not bind
that outsider to \(B_i\); see [note 381](../../../mcsp-hardness-magnification/notes/381-rw-easy-branch-self-corrector-composition-2026-08-18.md).

### Proposition 1.17 (correct JK block lift and proof-level attachment)

There is a dimensional correction to the padded signal argument used by C377. If
\(G:\{0,1\}^{k}\to\{0,1\}^{2k}\), and a JK layer has blocks
\(Z_{i,u}=X_{i,2u-1}\Vert X_{i,2u}\), then the parent blocks satisfy

\[
  G(\operatorname{left}_k(Z_{i,u}))=Z_{i+1,2u-1},\qquad
  G(\operatorname{right}_k(Z_{i,u}))=Z_{i+1,2u}.
\tag{1.29}
\]

Applying \(G\) to both halves and concatenating has length \(4k\), so it is not a lift to
one \(2k\)-bit block. Consequently, a success block \(y=Z_{j,u}\) and a specified
left/right path recover one top block \(Z_{h,a}\) after \(h-j\) half-lifts; they do not
recover the complete parent word. For the padded target \(B0^{T-b}\) with \(b\le2k\),
the all-left path from \(Z_{j,1}\) still recovers the parent prefix \(B\). For \(b>2k\),
it recovers at most one \(2k\)-bit block.

For the actual RW call, JK receives the canonical proof \(\Pi_{x_0}\), not the padded output
\(f_i(x_0)\). Theorem 3.5 fixes only the systematic witness/output prefix; it does not
show that the first non-range block has an ancestry inside that prefix, nor that auxiliary
blocks are independent of \(B_i\). Thus the valid source-level interface is only:

\[
  (y,j,u,a)\longmapsto \Pi_{x_0}[\text{top block }a],
\]

conditional on a no-earlier-failure path and a proved output-interval attachment. A
whole-parent evaluator still requires multiple attached blocks or a new global binding
theorem. This correction preserves the \(b\le2k\) padded special case but removes any
claim that a generic RW success outsider automatically binds the parent. See
[note 382](../../../mcsp-hardness-magnification/notes/382-jk-signal-lift-dimension-correction-2026-08-18.md).

### Proposition 1.18 (auxiliary-pad black-box barrier)

Theorem 3.5's source-level bullets do not, by themselves, bind an auxiliary PCP block to
the systematic output or to the parent history. More precisely, consider a source-level
interface that constrains verifier behavior, completeness/soundness, and the systematic
witness/output fields, and that allows a fixed polynomial slack in the proof-length bound.
For a valid proof

\[
  \Pi=(\widetilde w,\Pi_{\rm aux}),
\]

append a verifier-ignored pad \(U\in\{0,1\}^{M}\) within that slack and set

\[
  \widehat\Pi=(\widetilde w,\Pi_{\rm aux},U),\qquad
  \widehat V(x,z)=V(x,z).
\tag{1.30}
\]

All those bullets are preserved. Two targets with different systematic parents can have the
same observed auxiliary block and the same public block/path metadata, simply by choosing the
same pad value on the observed block. For a \(d\)-bit descriptor and a \(2^b\)-element parent
family, two parents share the descriptor whenever \(d<b\); the decoder then receives the same
input but must output different parents. Thus exact binding requires \(d\ge b\) bits (and the
multi-outsider version reduces to the bound in Proposition 1.13).

This is a source-bullet preservation theorem, not a claim that the published RW auxiliary
proof actually contains an ignored pad. If an interface imposes an exact proof length, the
statement applies only to the corresponding re-labelling of existing auxiliary coordinates.
Thus the result closes the black-box inference “Theorem 3.5 alone gives an auxiliary parent
map”; it does not prove a general dPCP/RLDC impossibility or \(P\ne NP\).

### Proposition 1.19 (Harsha factorization without a local inverse)

The actual Harsha instantiation used in RW is more structured than the
auxiliary-pad countermodel. Let \(\widetilde A_x\) be the Reed--Muller encoding of the
selected satisfying witness for \(C_x\). Harsha's Proposition 5.4.1 defines a polynomial
transformation \(p\), and the honest proof has the factorization

\[
  \Pi_x
  =
  \operatorname{Bin}\!\left(
    \widetilde A_x,\,
    p(\widetilde A_x),\,
    \operatorname{ZOS}(p(\widetilde A_x)),\,
    \operatorname{ECC}(\Gamma_x)
  \right),
\tag{1.31}
\]

where \(\operatorname{ZOS}\) denotes the zero-on-subcube division-chain proof and
\(\Gamma_x\) is the large-alphabet proof tuple. Thus the actual auxiliary proof is not a
verifier-ignored pad. However, RW Theorems 3.4--3.5 quantify soundness over arbitrary
auxiliary oracles and only force the systematic polynomial \(\widetilde A\) to be close to a
valid witness. They do not imply an address-scale function

\[
  \operatorname{out}(\alpha_x)
  =
  D\!\left(\Pi_x[v],v,\sigma_x\right)
\tag{1.32}
\]

for an arbitrary auxiliary coordinate \(v\). Equation (1.31) is a forward generation
factorization, not a local inverse or whole-parent evaluator; the zero-on-subcube component
may depend on the full division chain of \(p(\widetilde A_x)\).

If a sufficiently large parent family is separately constructed under one serialization,
one exposed \(2k\)-bit block and a \(d\)-bit descriptor still obey
\(2k+d\ge\log_2|\mathcal B|\). The published Theorem 4.3 call fixes \(x_0\) and uses a
singleton target, so this family bound is not automatic. The precise remaining Gate-I
alternatives are therefore an actual local inverse for Harsha's map or a source-specific
family/capacity theorem. This proposition is a source-factorization and quantifier
separation, not a proof that the Harsha map is non-invertible, a general dPCP/RLDC lower
bound, or \(P\ne NP\).

### Proposition 1.20 (actual Harsha family-lift payload barrier)

Consider the valid identity machine \(M_{\mathrm{id}}(x)=x\) on \(b\)-bit inputs, with no
NP queries. Theorem 3.5 then supplies \(2^b\) distinct systematic output parents, and C389
fixes the honest Harsha proof selector. For one fixed proof block of length \(s\), public
metadata of length \(h\), and a \(d\)-bit descriptor, exact parent recovery requires

\[
  s+h+d\ge b.
\tag{1.33}
\]

This is the pigeonhole bound on the labels
\((\text{block},\text{metadata},\text{descriptor})\). A JK outsider contributes
\(s=2k\) bits, and \(q\) outsiders give

\[
  2\sum_{t=1}^{q} k_t+h+d\ge b.
\tag{1.34}
\]

Consequently, a **target-oblivious** family-level common-proof lift with
\(k,q,d,h=\operatorname{poly}(\log b)\) cannot exact-bind the whole parent. If the decoder
is allowed to read the public input \(x\), then \(h\ge b\) is an explicit object-scale
payment rather than an impossibility. The result is genuinely source-realizable because the
family is the actual identity-machine specialization of RW/Harsha, rather than an ignored
auxiliary pad. It still does not apply to the published Theorem 4.3 singleton call, and
does not rule out an x-aware family compiler or a singleton-specific local inverse for the
hard parent.

### Proposition 1.21 (simultaneous-coordinate barrier for the actual Harsha identity family)

Let \(M_{\mathrm{id}}(x)=x\) on \(b\)-bit inputs and let \(\Pi_b(x)\in\Sigma^{P_b}\) be the
fixed honest Harsha selector from C389. Suppose that, for every \(i\in[b]\) and
\(c\in\{0,1\}\), one common proof interface has finite alphabet \(A=|\Sigma|\), fixed
radius \(\rho>0\), perfect completeness, wrong-claim soundness \(\beta<1\), and at most
\(q\) proof-symbol queries. Any target-dependent metadata is counted in \(P_b\). Thus, for
every \(z\) with \(d_H(z,\Pi_b(x))\le\rho P_b\),

\[
 \Pr[V_{i,x_i}^{\Pi_b(x)}=1]=1,
 \qquad
 \Pr[V_{i,1-x_i}^{z}=1]\le\beta .
\tag{1.35}
\]

Then the code obtained by inlining the message, \(C_b(x)=x\Vert\Pi_b(x)\), is a
perfect-complete RLDC. After fixing the random tape and exposing both claim decision trees,
its nonadaptive query complexity is at most

\[
 Q=1+2\sum_{j=0}^{q-1}A^j .
\tag{1.36}
\]

For \(N_b=b+P_b\), if its positive decoding radius lies in the GGS window

\[
 \delta_0>N_b^{-(1-\beta)/(2Q)},
\tag{1.37}
\]

then, for all sufficiently large \(b\),

\[
 N_b\ge
 \left(
 \frac{(1-\beta)^2b}
 {38Q^4\log^2(A+2)\log^2b}
 \right)^{1+1/\lceil Q/(1-\beta)\rceil}.
\tag{1.38}
\]

In particular, fixed \(A,q,\rho,\beta\) rule out \(P_b=b\operatorname{polylog}b\). For
\(A=2,q=1,\beta<1/2\), use the same binary alphabet for inline and proof positions; the
binary two-query Hamming-RLDC bound is then exponential. For \(A=2,q=2\) and
\(\beta<1/8\), low-soundness RLDC-to-LDC conversion followed by the three-query LDC lower
bound gives \(N_b=\widetilde\Omega(b^3)\). The disjoint alphabet tags used in the general
finite-alphabet compiler are unnecessary in these binary sharpened cases.

Indeed, two distinct proof words must be farther than \(\rho P_b\): otherwise the proof for
one target is a near proof for the other, contradicting completeness on one claim and
wrong-claim soundness on the other. The \(b\) inlined symbols then give a positive-radius
RLDC (take \(\delta_0\le\rho P_b/(2N_b)\)); a corrupted inline bit runs the corresponding
claim branch, and only the wrong branch can output an incorrect bit. Expanding the two
adaptive \(A\)-ary trees gives (1.36), after which (1.38) is GGS Theorem 1. The sharpened
cases use the cited binary two-query and low-soundness three-query reductions.

This is a source-realizable family barrier for the actual RW/Harsha selector. It is not a
general dPCP/RLDC impossibility theorem, does not apply to the published singleton \(x_0\),
does not exclude an x-aware compiler, and does not by itself prove \(P\ne NP\). The full
quantifier statement and references are recorded in [note 391](../mcsp-hardness-magnification/notes/391-actual-harsha-identity-family-coordinate-barrier-2026-08-18.md).

### Proposition 1.22 (normalized JK signal/easy dichotomy)

Let \(G_k:\{0,1\}^k\to\{0,1\}^{2k}\) satisfy \(G_k(0^k)=0^{2k}\), and run the
Jeřábek--Korten reduction with lexicographically first range preimages and the
leftmost non-range block as its hard-output tie-break. For a padded target
\(F_B=B0^{T-b}\) with \(b\le2k\), the reduction has the following dichotomy:

1. it returns the first (signal) block at its first failing stage; the stage index and the
   block, together with the known half-lift path, recover \(B\); or
2. it reaches the easy branch and returns a circuit of size
   \(O(|G_k|\log(T+2))\) for \(F_B\), hence also for \(B\).

The proof is an induction on the stages. At the top level all non-signal blocks are
\(0^{2k}\), hence are in the range. Since the first preimage of \(0^{2k}\) is \(0^k\),
all tail blocks remain zero at every subsequent stage. Therefore a leftmost non-range
block can only be the signal block. Applying \(G_k\) separately to the two halves of a
failed signal block reconstructs its ancestors and hence the first \(b\) bits of \(F_B\).
If no signal block fails, the easy conclusion is exactly the one in Ren--Williams
Theorem 3.1.

Thus a hardness condition
\[
\operatorname{CC}(B)>O(|G_k|\log(T+2))
\tag{1.39}
\]
forces a signal outsider under this normalized interface. The statement removes the
off-signal ambiguity in C383 but is not yet an address-scale RW closure: in the published
recurrence \(k=n_{i+1}=n_i^C\), the easy bound is object-scale, while taking
\(k=\operatorname{polylog}(b)\) violates \(b\le2k\). The normalization is compatible with
the truth-table-generator instance used in RW Theorem 4.5. If \(e_k\) is an input description
of the constant-zero circuit, let \(\tau_k\) swap \(0^k\) and \(e_k\), and set
\(\widetilde G_k=G_k\circ\tau_k\). Then
\(\operatorname{Range}(\widetilde G_k)=\operatorname{Range}(G_k)\) and
\(\widetilde G_k(0^k)=0^{2k}\). The swap is \(P\)-uniform and costs \(O(k)\) gates, which is
absorbed by the polynomial size bound in Theorem 4.3. Since Korten's reduction only uses the
range of the generator, its correctness and parameter conditions are unchanged. Thus the
fixed-point normalization is a harmless domain relabeling, while the signal-to-parent
attachment remains the substantive open gate. See
[note 392](../mcsp-hardness-magnification/notes/392-normalized-jk-first-failure-signal-dichotomy-2026-08-18.md).

### Proposition 1.23 (adaptive transcript capacity for parent binding)

Let \(\mathcal B\) be a parent family of size \(M\). Suppose an interactive attachment
uses a target-dependent descriptor of \(d\) bits and at most \(q\) rounds, where each
response has at most \(2^{\ell_t}\) possible values and each next challenge is determined
by public data, the descriptor, and the previous transcript. If a single-valued decoder
exactly recovers the same parent from the descriptor and response transcript, then

\[
d+\sum_{t=1}^{q}\ell_t\ge\log_2 M.
\tag{1.40}
\]

This remains true for adaptive choice of the AVOID generator, first-failure block,
stage/path, or auxiliary-proof query. If a response consists of a \(2k_t\)-bit outsider
and an independently returned index/path from a set \(\mathcal I_t\), then one may take
\(\ell_t\le2k_t+\lceil\log_2|\mathcal I_t|\rceil\). The proof is transcript injectivity:
two parents with the same descriptor and response transcript induce the same challenges
and the same decoder input, so exact recovery is impossible.

For the identity family of \(b\)-bit parents, \(q,k_t,\log|\mathcal I_t|,d=
\operatorname{polylog}(b)\) is therefore insufficient. This closes an interactive
transcript as a free parent channel, but it does not apply to the published RW singleton
\(x_0\); a singleton-specific closure must instead exhibit an address-scale evaluator or
pay for its target descriptor. See
[note 393](../mcsp-hardness-magnification/notes/393-interactive-parent-binding-transcript-capacity-2026-08-18.md).

### Proposition 1.24 (algebraic block coverage versus ECC projection)

Let \(F\) have an explicit \(\lambda\)-bit representation and let \(P:F^d\to F\) have
total degree at most \(\Delta\). If the proof serialization partitions affine-line
restrictions into \(2k\)-bit blocks, then
\[
k\ge(\Delta+1+2d+2)\lambda+O(\log k)
\tag{1.41}
\]
is sufficient for a \(P\)-uniform polynomial-size generator whose range contains every
such block: its input stores the univariate coefficients, line, segment start, and a
component tag, and its circuit evaluates the polynomial by Horner's rule. Thus the
low-degree \(\widetilde A,P,\mathrm{ZOS}\) portion of the Harsha proof has a concrete
short-description route after a public coordinate permutation.

For an injective linear binary code \(E:\mathbb F_2^L\to\mathbb F_2^P\), partitioned
into \(2k\)-bit blocks with projection ranks \(r_j\), any \(G_k\) has range at most
\(2^k\). If \(r_j>k\), at least \(1-2^{k-r_j}\) of uniform messages have a top-level
block outside \(\operatorname{Range}(G_k)\). If every \(r_j\le k\), rank subadditivity
gives \(L\le\sum_jr_j\le mk\), and any exact parent decoder using \(q\) such blocks
and \(d\) descriptor bits obeys \(d+2kq\ge L\) by Proposition 1.23. The source-level
RW statement names a binary ECC but does not by itself supply its linearity or projection
profile, so this is a conditional ECC gate rather than an unconditional RW theorem. See
[note 394](../mcsp-hardness-magnification/notes/394-algebraic-block-coverage-ecc-projection-gate-2026-08-18.md).

### Proposition 1.25 (a source-realizable linear-ECC branch)

The conditional qualifier in Proposition 1.24 is not needed for at least one legal
Harsha/RW instantiation. Harsha's Lemma 2.4.5 and Section 5.4.3 require a binary ECC of
constant relative distance, output length \(b=O(a)\) on \(a\)-bit messages, and an explicit
encoding circuit of size \(O(a)\); Section 5.4.3 explicitly cites Spielman [Spi96]. Spielman's
construction supplies asymptotically good linear codes with linear-size logarithmic-depth
encoding circuits. After fixing a constant-rate family (and hardwiring finitely many small
lengths), this meets Harsha's source requirements without changing the stated robustness or
length asymptotics. Hence the injective-linear branch of Proposition 1.24 is source-realizable.

This proposition does not identify the projection-rank profile of that code, quantify over every
ECC allowed by the RW statement, or imply that the published singleton target \(x_0\) has a
high-rank payload block. The remaining source-level question is therefore the joint payload
image/rank and parent-binding statement: can the actual \(\Gamma_x\) family place enough entropy
in the top-level projections, or must its first-stage outsider, path, and descriptor pay the
transcript capacity of Proposition 1.23? See
[note 395](../mcsp-hardness-magnification/notes/395-harsha-spielman-linear-ecc-source-instantiation-2026-08-18.md).

### Proposition 1.26 (product-code rate gate for high-rank blocks)

Harsha's alphabet reduction applies the binary code independently to each
\(a\)-bit symbol of the large-alphabet proof. Let
\(E_0:\mathbb F_2^a\to\mathbb F_2^b\) be injective linear with rate
\(R=a/b>1/2\), and serialize the resulting \(\Upsilon\) oracle as consecutive
\(b\)-bit codewords. For every length-\(2k\) interval \(I\) lying inside this segment,
\[
 r(I)\ge a\left\lfloor\frac{2k-2b+2}{b}\right\rfloor
 \ge 2Rk-3a .
\tag{1.42}
\]
Consequently \(r(I)>k\) whenever \(k>3a/(2R-1)\). For a uniform full message
\(u\in\mathbb F_2^{aN}\), the corresponding projection lies in the range of any
\(G_k:\{0,1\}^k\to\{0,1\}^{2k}\) with probability at most \(2^{k-r(I)}\).

This is a conditional source-level branch. It removes the need to inspect a particular
Spielman generator matrix only if the legal Harsha/RW code family includes a fixed rate
\(R>1/2\) and the \(\Upsilon\) segment (or a public coordinate permutation) is compatible
with the fixed proof serialization and address-scale query map. It still says nothing by
itself about the image entropy of the actual \(\Gamma_x\) family or about the published
singleton \(x_0\). See
[note 396](../mcsp-hardness-magnification/notes/396-product-linear-ecc-rate-greater-half-block-rank-2026-08-18.md).

### Proposition 1.27 (the binary-serialization boundary)

The source text fixes the object decomposition
\(\Pi=(\widetilde w,\Pi')\), with \(\widetilde w\) the systematic
Reed--Muller witness prefix and \(\Pi'=(P,\Pi_{\mathrm{ZoS}})\) auxiliary oracles.
Harsha's binary conversion realizes the auxiliary large-alphabet oracle as
\(\Gamma\circ\Upsilon\), where \(\Upsilon(i)=\operatorname{ECC}(\Gamma(i))\).
Neither Theorem 3.5 nor Theorem 4.1 fixes a global binary coordinate order for these
oracles, a public coordinate permutation, or the alignment of the first JK outsider
with a chosen ECC segment.

Thus Proposition 1.26 is a legitimate source branch only after choosing a fixed
serialization that keeps \(\widetilde w\) as the systematic prefix and places
\(\Upsilon\) contiguously (or supplies an address-scale computable public permutation).
The Hamming and ECC checks are invariant under this fixed reordering, but the inverse
coordinate map and first-failure path must still be charged at address scale. See
[note 397](../mcsp-hardness-magnification/notes/397-rw-theorem-35-binary-serialization-source-boundary-2026-08-18.md).

### Proposition 1.28 (oracle-major serialization is address-scale computable)

Keep the systematic \(\widetilde w\) prefix and serialize the auxiliary
\(\Gamma\) and \(\Upsilon(i)=E_0(\Gamma(i))\) oracles as consecutive segments,
with lexicographic domain order inside each segment. If field points use an explicit
\(\lambda\)-bit representation and segment lengths are computable from the input
length, a global binary address can be decoded into its segment, field-point
index, and bit offset by polylogarithmic-size arithmetic in the RW parameter range.
The original verifier can therefore query the same \(\Gamma(i)\) and \(\Upsilon(i)\)
symbols and perform the same ECC equality check. This is a fixed coordinate
reordering, so Hamming distance, completeness, and robustness are unchanged; the
\(\widetilde w\) prefix remains systematic.

If the \(\Upsilon\) segment is longer than \(4k\), all but its two boundary
\(2k\)-blocks are eligible for Proposition 1.26. This is a valid source
serialization compiler, not a property supplied by the published Theorem 4.1:
the segment endpoints, canonical encoding, and JK block alignment must be added
to the source statement, and the first failure may still occur earlier. See
[note 398](../mcsp-hardness-magnification/notes/398-oracle-major-binary-serialization-compiler-rw-harsha-2026-08-18.md).

### Proposition 1.28A (Harsha full-table proof-length gate)

Consider the explicit Harsha source instantiation used in Ren--Williams Theorem 3.4,
with circuit size \(N\),
\[
 m=\left\lceil\frac{\log N}{\log\log N}\right\rceil,
 \qquad |F|=\Theta\!\left((mN^{1/m})^3\right),
\]
and with the three proof oracles stored by their complete tables
\(\widetilde A:F^m\to F\), \(P:F^{3m+3}\to F\), and
\(\Pi_{\mathrm{ZoS}}:F^{3m+3}\to F^{6m+6}\).  The resulting field-symbol count is
\[
 S(N)=\Theta\!\left(m|F|^{3m+3}\right)=N^{18+o(1)}.
\tag{1.43a}
\]
If each field symbol is binary-encoded with a fixed-rate \(\Theta(\log|F|)\)-bit
error-correcting block, the binary proof length remains \(N^{18+o(1)}\).

Consequently, in a Ren--Williams Theorem 3.5 call whose circuit \(C_x\) has size
\(N_x\le\operatorname{poly}(t(n))\), this particular source serialization gives
\[
 |\Pi_x|\le N_x^{18+o(1)},
 \qquad
 \#\{\text{top }2k\text{-blocks}\}
 =\Theta\!\left(\frac{N_x^{18+o(1)}}{k}\right)
\tag{1.43b}
\]
up to the fixed binary-serialization factors.  The stable identity \(k=T\) therefore
does not make the JK proof length comparable to \(T\); it only fixes the generator width.

This is a source-parameter theorem, not a lower bound for every PCP serialization: it
assumes the complete oracle-table representation and the stated field-size choice.  Its
role is to keep the recursive block count explicit.  A proof-length upper bound alone
does not supply an address-scale block evaluator or rule out algebraic compression; those
remain separate Gate-I obligations.  See [note 408](../mcsp-hardness-magnification/notes/408-rw-harsha-proof-length-exponent-audit-2026-08-19.md).

### Proposition 1.29 (nonlinear proof-family support dichotomy)

Let \(\Pi:\mathcal B\hookrightarrow\{0,1\}^{P}\) be any injective canonical
proof family, partitioned into \(m\) blocks of length \(2k\), and let
\(S_j\) be the set of values appearing in block \(j\). For every
\(G_k:\{0,1\}^{k}\to\{0,1\}^{2k}\), either some \(S_j\) has size greater than
\(2^k\), in which case at least one family target has an outsider block for
that \(G_k\), or
\[
 |\mathcal B|\le\prod_{j=1}^{m}|S_j|\le2^{km}.
\tag{1.43}
\]
In the latter case, an exact parent decoder using \(q\) block responses and a
\(d\)-bit target-dependent descriptor must satisfy
\[
 d+2kq\ge\log_2|\mathcal B|.
\tag{1.44}
\]
This argument is nonlinear and independent of the particular ECC. Its first branch
still needs an RW-specific first-failure/output-attachment theorem and gives no
uniform target fraction; the second branch is the C393 transcript-capacity payment.
Neither branch applies automatically to the published singleton \(x_0\). See
[note 399](../mcsp-hardness-magnification/notes/399-actual-proof-family-block-support-dichotomy-2026-08-18.md).

### Proposition 1.30 (low-rate product-ECC universal cover)

Let \(E_0:\mathbb F_2^a\to\mathbb F_2^b\) be an explicit injective linear
encoder of rate \(R=a/b<1/2\), and put \(Q_k=\lceil2k/b\rceil+1\). If
\[
 Q_ka+\lceil\log_2 b\rceil+1\le k,
\tag{1.45}
\]
there is a polynomial-size uniform generator \(G_k:\{0,1\}^k\to\{0,1\}^{2k}\)
whose range contains every internal \(2k\)-bit interval in the consecutive
product-ECC stream. Thus a low-rate Harsha code can make the auxiliary
\(\Upsilon\) segment universally range-coverable at address scale.

The statement does not cover segment boundaries and does not separate
systematic-output block values from auxiliary values. A new target-separated
output block, or an equivalent first-failure attachment theorem, is still needed
for RW Closure. See
[note 400](../mcsp-hardness-magnification/notes/400-low-rate-product-ecc-universal-block-cover-2026-08-18.md).

### Proposition 1.31 (tagged non-output cover forces output attachment)

Fix a binary RW proof \(\Pi\), a JK width \(k\), and a generator
\[
G_k:\{0,1\}^{k}\to\{0,1\}^{2k}
\]
normalized so that \(G_k(0^k)=0^{2k}\). For a recursive JK block \(Z\), call
it non-output if every top-block ancestry of \(Z\) is disjoint from the
systematic output interval \(I_{\mathrm{out}}\); otherwise call it
output-attached. Suppose:

1. JK returns the leftmost non-range block at every level;
2. every non-output recursive block encountered on the canonical proof lies in
   \(\operatorname{Range}(G_k)\);
3. the easy-branch self-corrector composition gives
   \[
   (|G_k|+1)\log(T+2)^{O(1)}<S
   \tag{1.46}
   \]
   on a stage with \(\operatorname{CC}(B)>S\); and
4. an address-scale descriptor identifies an untruncated top ancestor
   intersecting \(I_{\mathrm{out}}\).

Then JK must return a success outsider whose ancestry is output-attached.
Given the selected left/right path, its top \(2k\)-bit ancestor is computed by
\[
L_{G,0}(z)=G(\operatorname{left}_k z),\qquad
L_{G,1}(z)=G(\operatorname{right}_k z)
\]
in \(O((h-j)|G_k|+hk)\) gates. The proof is a direct combination of the
easy-branch hard-exit (Proposition 1.16) and the fact that a non-output block
is, by assumption, in the generator range.

A tagged union of finitely many branch generators
\(H^{(a)}:\{0,1\}^{s_a}\to\{0,1\}^{2k}\) supplies the range hypothesis whenever
\[
\max_a s_a+\lceil\log_2 r\rceil\le k.
\tag{1.47}
\]
In particular, the line-cover and product-ECC branches of Propositions 1.24
and 1.30 can be combined this way. This does not cover the raw non-output
systematic witness bits, and it does not imply that the range hypothesis is
closed under the recursive half-preimage operation. See
[note 401](../mcsp-hardness-magnification/notes/401-systematic-output-from-nonoutput-cover-gate-2026-08-18.md).

### Proposition 1.32 (recursive range-closure product capacity)

Let \(R=\operatorname{Range}(G_k)\), and let \(p:R\to\{0,1\}^{k}\) be the
canonical preimage map, so \(G_k(p(z))=z\). The map \(p\) is injective and
\(|R|\le2^k\). If \(\mathcal A,\mathcal B\subseteq R\) are non-output block
families with the property that every pair \((a,b)\in\mathcal A\times\mathcal B\)
occurs as adjacent blocks in a canonical source proof and
\[
p(a)\Vert p(b)
\]
is itself a non-output block required to lie in \(R\), then
\[
|\mathcal A|\,|\mathcal B|\le |R|\le2^k,
\qquad
\log_2|\mathcal A|+\log_2|\mathcal B|\le k.
\tag{1.48}
\]
More generally, a depth-\(d\) product-rich subtree with leaf families
\(\mathcal A_1,\ldots,\mathcal A_{2^d}\) satisfies
\[
\sum_{\ell=1}^{2^d}\log_2|\mathcal A_\ell|\le k.
\tag{1.49}
\]
The proof is injectivity of the map from leaf tuples to the recursively
preimage-concatenated root block.

This gives a source-realizable RW stress test. Let \(M_{\mathrm{pair}}\) take
\(x=(u,v)\), ask two same-round NP queries with unique witnesses
\(u,v\in\{0,1\}^{2k}\), and output a fixed zero bit. Under a source-compatible
serialization preserving the history order
\[
(y_1=2,\mathrm{out}=0,z_{1,1}=u,z_{1,2}=v),
\tag{1.50}
\]
the two non-output families each have size \(2^{2k}\), so (1.48) is violated by
\(4k>k\). Hence no target-independent \(G_k\) can keep this entire family
recursively in range. This is a genuine family-level RW/Harsha barrier, but it
does not apply to the published singleton \(x_0\); a singleton theorem would
need a direct support bound on the actual history. See
[note 402](../mcsp-hardness-magnification/notes/402-jk-recursive-range-closure-capacity-2026-08-18.md).

### Proposition 1.32a (product-ECC recursive-closure rate gate)

Let \(E_0:\mathbb F_2^a\to\mathbb F_2^b\) be an injective linear encoder of
rate \(R=a/b\), and consider a consecutive product-ECC segment with an aligned
JK width \(b\mid 2k\). Each \(2k\)-bit block then contains
\(q=2k/b\) independent source symbols and has a value family of size
\(2^{qa}=2^{2Rk}\). If two adjacent such non-output blocks can be chosen
independently in a source family, and every block together with its canonical
half-preimage parent is required to lie in the same
\(G_k:\{0,1\}^k\to\{0,1\}^{2k}\) range, Proposition 1.32 gives
\[
 2^{2qa}\le 2^k,
 \qquad\text{hence}\qquad
 4Rk\le k.
\tag{1.50a}
\]
Thus, on the aligned product-rich source branch, a fixed-rate
\(R>1/4\) code may admit C400's one-level universal block cover (for
sufficiently large \(k\), when the offset overhead is lower order), but it
cannot satisfy the two-level target-oblivious recursive range-closure.

This is a family-level rate gate, not a theorem about the published
fixed-\(x_0\) call. For \(R\le1/4\), it supplies no closure construction; for
an unaligned or interleaved serialization, independent projection families
must be proved afresh. Full statement and proof are in
[note 424](../mcsp-hardness-magnification/notes/424-product-ecc-recursive-closure-rate-gate-2026-08-19.md).

### Proposition 1.32b (product-ECC recursive depth--rate law)

The two-block rate gate iterates. In a consecutive product-ECC segment with
an aligned width \(b\mid 2k\), let a depth-\(d\) JK subtree have
\(2^d\) leaves, each depending on \(q=2k/b\) disjoint source symbols.
If every leaf tuple is realized by the source family, all leaves and
recursive internal blocks are non-output, and one common \(G_k\)-range contains
the entire recursive subtree, then Proposition 1.32 gives
\[
 2^dqa\le k,
 \qquad\text{hence}\qquad
 R=a/b\le 2^{-(d+1)}.
\tag{1.50b}
\]
Thus a fixed positive-rate product-ECC can support only constant recursive
depth in a product-rich source family. If \(2^d\) grows on the
\(L/k\) scale of a long auxiliary segment, the required rate is
\(R=O(k/L)\), incompatible with the Harsha parameter \(b=O(a)\) unless the
actual proof image has substantial leaf-entropy collapse, some blocks are
output-attached, or the proposed relation leaves common target-independent
range closure. This remains a family-level source theorem and does not apply
to the published fixed-\(x_0\) singleton. See
[note 425](../mcsp-hardness-magnification/notes/425-product-ecc-recursive-depth-rate-law-2026-08-19.md).

### Proposition 1.32c (source-context double-capacity)

The recursive product bound and the public-input entropy bound combine
without any independence assumption beyond the product-rich source quantifier.
Let \(\Theta\in\{0,1\}^{\nu}\) be the complete public context determining a
canonical proof, and let a depth-\(d\) subtree have leaf families
\(\mathcal A_1,\ldots,\mathcal A_{2^d}\). If every leaf tuple is realized by
some context, then context counting gives
\[
 \log_2\!\prod_{\ell=1}^{2^d}|\mathcal A_\ell|\le\nu.
\]
If all leaves and recursive internal blocks are non-output and lie in one
common \(G_k\)-range, Proposition 1.32 gives the second inequality
\[
 \log_2\!\prod_{\ell=1}^{2^d}|\mathcal A_\ell|\le k.
\]
Hence the total leaf entropy is at most \(\min\{\nu,k\}\). For aligned
product-ECC leaves of rate \(R=a/b\), this becomes
\[
 2^{d+1}Rk\le\min\{\nu,k\}.
\tag{1.50c}
\]
Thus a deep address-scale product-rich attachment must either spend
message-scale public context, lose recursive range closure, or leave the
common-proof/target-independent model. The theorem does not apply to the
published fixed-\(x_0\) singleton; it is the unified form of the
public-input and recursive-capacity gates. See
[note 426](../mcsp-hardness-magnification/notes/426-rw-source-context-double-capacity-theorem-2026-08-19.md).
The source-level audit of Ren--Williams Theorems 3.4--4.1 further shows that
existential choice among honest proofs cannot supply hidden leaf entropy for
free: after fixing a deterministic selector, the proof image is a function of
the public context, while the published fixed-\(x_0\) call is a point mass. This
closes only the proof-choice black box; it does not prove recursive leaf
collapse or output attachment. See the source-audit addition to
[note 406](../../../mcsp-hardness-magnification/notes/406-rw-public-input-family-route-closure-2026-08-18.md).

### Proposition 1.33 (singleton recursive-support ceiling)

The C402 support test has a strict fixed-proof window. Let \(\Pi\) be a binary proof of
length \(L\), pad it to \(k2^h\) bits with

\[
 h=\left\lceil\log_2(L/k)\right\rceil,
\]

and run the JK recursion with \(G_k:\{0,1\}^{k}\to\{0,1\}^{2k}\). Across all levels there
are at most

\[
 \sum_{j=1}^{h}2^{j-1}=2^h-1<2L/k
\]

block occurrences and fewer than \(2^h\) adjacent-pair occurrences. Hence for the fixed
singleton proof,

\[
 |\mathcal Z_{\rm no}|<2^h,\qquad
 |\mathcal P_{\rm no}^{(2)}|<2^h.
\tag{1.51}
\]

In particular, if \(2^k\ge2L/k\), then both supports are automatically at most \(2^k\),
so C402 cannot yield a singleton contradiction by cardinality. Equivalently, a necessary
window for the C402 support test is

\[
 k<\log_2(L/k)+1.
\tag{1.52}
\]

For the published RW proof bound \(L_i\le T_i^{O(1)}\), this excludes the singleton
support route once \(k_i\gtrsim\log T_i\). In the remaining \(k_i=O(\log b_i)\) window,
where \(b_i=2n_i\) is the parent output length, one success outsider still exposes only
\(2k_i=o(b_i)\) bits; C377/C383 therefore leave whole-parent binding unresolved. Thus C402
must be combined with a family/product-rich lift or a new global relation theorem to affect
Gate I. The proof is the occurrence count above; full parameter boundaries are recorded in
[note 404](../../../mcsp-hardness-magnification/notes/404-singleton-recursive-support-ceiling-2026-08-18.md).

### Proposition 1.34 (recursive-closure--parent-binding trichotomy)

The C402 product bound has a quantitative family form. Let a depth-\(d\) non-output
subtree have leaf families \(\mathcal A_1,\ldots,\mathcal A_{2^d}\), with every leaf
tuple source-realizable, and put
\[
 S=\sum_{\ell=1}^{2^d}\log_2|\mathcal A_\ell|,
 \qquad N_d=2^d-1.
\]
For a common \(G_k\), the fraction \(\rho\) of tuples whose recursive subtree contains
a non-range node satisfies
\[
 \rho\ge 1-2^{k-S}.
\tag{1.53}
\]
If every recursive-bad tuple exposes only a first-failure node index, one \(2k\)-bit
outsider, and a \(D\)-bit target descriptor, while good tuples use a fixed null flag,
then exact recovery of the leaf tuple implies
\[
 D+h_2(\rho)+\rho(2k+\log_2 N_d)\ge S.
\tag{1.54}
\]
In particular, if the good branch is excluded by a uniform circuit lower bound, then
\(\rho=1\) and
\[
 D+2k+\log_2N_d\ge S.
\tag{1.55}
\]
Thus a product-rich, hard-target family cannot simultaneously have target-independent
recursive range closure, a single address-scale outsider, and a short whole-parent
descriptor. This combines C402's recursive capacity with C378's transcript payment;
the source-family and singleton boundaries are recorded in
[note 405](../../../mcsp-hardness-magnification/notes/405-recursive-closure-parent-binding-trichotomy-2026-08-18.md).
If the family is indexed by a public \(n\)-bit input and the canonical history is a
deterministic function of that input, the public input itself must be counted: the bound
becomes \(n+D+h_2(\rho)+\rho(2k+\log_2N_d)\ge S\), while \(S\le n\). Thus the theorem
does not turn a public-input stress test into a singleton RW impossibility; a useful
application needs hidden family entropy or a target-oblivious lift.

### Proposition 1.35 (singleton JK-lift parent-binding cost)

The family entropy in Proposition 1.34 is not needed for the subclass of closures that
reconstruct a parent by the canonical JK half-lift. Fix a generator
`G_k:{0,1}^k -> {0,1}^{2k}` of circuit size `s_G`, and a fixed proof recursion of depth
`h`. Suppose a singleton transcript exposes `q` outsider blocks, each with a known
untruncated left/right path of length at most `ell`, and that the resulting top blocks
cover a `b`-bit parent `B`. Let `d` be the descriptor length and `s_ctrl` the size of the
explicit address/selector circuit, including adaptive control and address arithmetic.
Then

`CC(B) <= O(s_ctrl + d + q(2k + ell(s_G+k+log b))).`

Compose `G_k` along each recorded path to obtain the corresponding top block, then apply
the selector to the input address. The outsider values and descriptor can be hardwired;
charging `2kq+d` only makes the upper bound more conservative. This is a singleton circuit
upper bound, not a family counting argument.

For the published RW stable stage, `b_i=2n_i`, `h_i=O(log n_i)`, and `|G_{k_i}|<=k_i^4`.
On lengths with `CC(B_i)=Omega(n_i/log n_i)`, every closure in this JK-lift subclass must
satisfy

`s_ctrl+d + q_i O(k_i^4 log(n_i+2)+k_i log(n_i+2)+2k_i)
 >= Omega(n_i/log(n_i+2)).`

Consequently, if `s_ctrl+d=o(n_i/log n_i)` and `k_i=polylog(n_i)`, then

`q_i = Omega(n_i/(k_i^4 log^2(n_i+2))).`

Thus polylogarithmically many outsiders cannot be combined by independent JK half-lifts
into the hard parent. An escape must use a genuinely joint global relation that cannot be
compiled into this pathwise construction, or must pay object-scale control cost. The
proposition does not rule out such a new relation and is not itself a proof of P != NP.
See [note 410](../../../mcsp-hardness-magnification/notes/410-rw-singleton-jk-lift-parent-binding-circuit-cost-2026-08-19.md).

### Proposition 1.36 (global-relation residual-correlation trichotomy)

Let \(X\) be uniform on \(\{0,1\}^{b}\), let
\(\Pi_b:\{0,1\}^{b}\hookrightarrow\Gamma^{M_b}\) be a canonical proof selector with
minimum distance greater than \(2t_b\), and let \(Z\) be a same-proof global word with
policy \(S\). If

\[
p_b=\Pr[d_H(Z,\Pi_b(X))\le t_b],
\]

then, with

\[
\mathsf{TI}_b=I_2(X;S)+\sum_j I_2(X;Z_j\mid S),
\qquad
\mathsf{RC}_b=\mathbb E[\operatorname{TC}_2(Z\mid X,S)],
\]

one has

\[
\mathsf{TI}_b+\mathsf{RC}_b\ge p_b b-1.
\tag{1.48}
\]

Indeed, nearest-word decoding and Fano give
\(I_2(X;S,Z)\ge p_b b-1\), while

\[
I_2(X;S,Z)
=I_2(X;S)+\sum_j I_2(X;Z_j\mid S)
-\operatorname{TC}_2(Z\mid S)
+\operatorname{TC}_2(Z\mid X,S).
\]

Thus a constant-success family-level relation with \(o(b)\) policy and coordinate target
information must carry \(\Omega(b)\) conditional joint correlation. Conversely, if that
residual correlation is \(o(b)\), the policy/coordinate channel must carry \(\Omega(b)\)
target bits. For the actual Harsha identity family, this separates the only genuinely
joint global-relation escape from the target-oblivious descriptor/transcript branches
already charged by Propositions 1.20 and 1.23. If the residual relation is still a finite
canonical JK half-lift, Proposition 1.35 charges its circuit cost; otherwise it is a new
source-specific global coupling and must separately prove same-proof, address-scale,
smartness, cover, and bottom safety. This is a Gate-II classification, not a seed-length
lower bound or an unconditional \(P\ne NP\) theorem. See
[note 411](../../../mcsp-hardness-magnification/notes/411-rw-harsha-global-relation-residual-correlation-trichotomy-2026-08-19.md).

### Proposition 1.37 (recursive-cover tree-correlation payment)

Fix \(G:\{0,1\}^{k}\to\{0,1\}^{2k}\), its range \(R\), and the canonical inverse
\(p:R\to\{0,1\}^{k}\). Consider a depth-\(d\) JK preimage tree with \(m=2^d\)
leaves \(L_v\), and define every internal block by
\(W_v=p(W_{v0})\Vert p(W_{v1})\). If every internal block remains in \(R\), then
the leaf tuple injectively determines the root block. Consequently, for every policy
variable \(S\),

\[
\mathbb E[\operatorname{TC}_2(L\mid S)]
\ge
\sum_{v}H_2(L_v\mid S)-k.
\tag{1.49}
\]

In particular, conditionally independent leaves must satisfy
\(\sum_vH_2(L_v\mid S)\le k\); leaves with total conditional entropy larger than \(k\)
force the excess amount of joint correlation. The proof is induction on the tree using
injectivity of \(p\), followed by
\(H_2(L\mid S=s)=H_2(W_{\mathrm{root}}\mid S=s)\le\log_2|R|\le k\).

If the non-output leaf tuple determines the canonical RW witness \(\alpha_X\), then
\[
\operatorname{TC}_2(L\mid S=s)\ge H_2(\alpha_X\mid S=s)-k.
\]
Thus a systematic-witness family with more than \(k\) bits of conditional entropy cannot
have a conditionally independent recursive cover. This is a target-oblivious family test:
public input/context entropy must still be charged separately.
For the two-query stress machine \(M_{\mathrm{pair}}\) from Proposition 1.32, uniform
independent witnesses \(u,v\in\{0,1\}^{2k}\) give
\(H_2(\alpha_X)=4k\), so any exact recursive cover would require at least \(3k\) bits of
leaf correlation. This strengthens the earlier support contradiction quantitatively, while
retaining its family-level (not published-singleton) boundary.

This strengthens the product-capacity barrier in Proposition 1.34: direct algebraic/ECC
block covers are not enough, because the cover must also be closed under every canonical
preimage concatenation. Thus a proposed RW witness-range cover has only three options:
pay the tree-correlation budget, leave the JK half-lift model and provide a new global
coupling, or trigger the singleton circuit payment of Proposition 1.35. An approximate
closure with failure probability \(\delta\) has the conservative correction
\(h_2(\delta)+(1-\delta)k+2km\delta\) in place of \(k\). This is a
source-specific recursive-cover theorem, not a claim that the published singleton has
already been shown to possess high leaf entropy. See
[note 412](../../../mcsp-hardness-magnification/notes/412-jk-recursive-cover-correlation-inequality-2026-08-19.md).

### Proposition 1.38 (latent-seed budget for recursive cover)

In the setting of Proposition 1.37, suppose all leaf blocks are mutually independent
conditioned on a policy \(S\) and a latent seed \(U\). Then

\[
\sum_v H_2(L_v\mid S)-k
\le
\operatorname{TC}_2(L\mid S)
\le
(m-1)H_2(U\mid S).
\tag{1.50}
\]

The right inequality follows from
\[
\operatorname{TC}_2(L\mid S)
=\sum_v I_2(U;L_v\mid S)-I_2(U;L\mid S)
\]
and data processing. Hence a \(d\)-bit seed and conditional leaf entropies \(h_v\)
must satisfy
\[
 \sum_v h_v\le k+(m-1)d.
\tag{1.51}
\]
This closes the conditional-product short-seed architecture: any remaining construction
must retain higher-order joint coupling after conditioning on the seed, or leave the
recursive JK model. It is an architecture-level theorem, not a general seed-length
lower bound and not a claim about the published RW singleton. See
[note 413](../../../mcsp-hardness-magnification/notes/413-jk-recursive-cover-latent-seed-budget-2026-08-19.md).

### Proposition 1.39 (systematic-witness universal-cover barrier)

Fix \(q,s\ge1\), and consider the one-round RW/Harsha source family whose input is
\(X=(U_1,\ldots,U_q)\in(\{0,1\}^{s})^q\), with the \(j\)-th NP query having the
unique accepting witness \(U_j\) and with fixed output \(0\). The history in
Ren--Williams Lemma 3.2 therefore has canonical witness entropy
\[
H_2(\alpha_X\mid S)=H_2(X\mid S)=qs-I_2(X;S).
\]
Suppose its non-output leaf tuple \(L\) determines this same canonical witness, the
leaves are conditionally independent given a policy \(S\) and latent seed \(\sigma\),
and an exact depth-\(d_{\rm tree}\) JK recursive cover uses one common \(G_k\) with
\(m=2^{d_{\rm tree}}\) leaves. Then
\[
qs-I_2(X;S)-k
\le \operatorname{TC}_2(L\mid S)
\le (m-1)H_2(\sigma\mid S).
\tag{1.52}
\]
Consequently, a target-oblivious policy and a \(d\)-bit seed require
\[
qs\le k+(m-1)d,
\tag{1.53}
\]
and a \(b\)-bit target-dependent descriptor only changes this to
\(qs\le k+b+(m-1)d\).

The lower bound is Proposition 1.37 applied after
\(H_2(L\mid S)\ge H_2(\alpha_X\mid S)\); the upper bound is Proposition 1.38.
The source family is a stress family, not the published fixed-\(x_0\) Theorem 4.3
singleton. If the public input \(X\) is placed in the policy, then
\(I_2(X;S)=qs\) and the bound correctly becomes vacuous. To apply (1.53) to an
actual RW/Harsha proof one must still prove that all witness bits lie in non-output
leaves, that those leaves determine one same-proof canonical assignment, and that
every recursive preimage is in range. There is also a query-visibility boundary:
for a fixed NP relation, the unique or lexicographically canonical witness is a
function of the public query string. Thus any policy that recovers the query
transcript or that witness pays its entropy in \(I_2(X;S)\); the \(M_{q,s}\) family
is not a hidden source when its public queries are visible. See
[note 406](../../../mcsp-hardness-magnification/notes/406-rw-public-input-family-route-closure-2026-08-18.md)
and
[note 414](../../../mcsp-hardness-magnification/notes/414-rw-systematic-witness-universal-cover-barrier-2026-08-19.md).

### Theorem 1.40 (RW source-specific Closure-Gate trichotomy)

Fix a stable RW stage with parent target \(B_i\) of length \(b_i\), and consider a
proposed same-parent, common-address attachment using one generator \(G_{k_i}\). The
following is a source-specific classification of the two concrete mechanisms currently
available for binding that attachment.

1. **Singleton JK half-lift.** If the attachment is the canonical pathwise half-lift
   of Proposition 1.35, exposing \(q_i\) outsider blocks with path length at most
   \(\ell_i\), descriptor length \(d_i^{\rm desc}\), and explicit address-control size
   \(s_{\rm ctrl,i}\), whose lifted top blocks cover \(B_i\), then
   \[
   \operatorname{CC}(B_i)
   \le O\!\left(s_{\rm ctrl,i}+d_i^{\rm desc}+
   q_i\bigl(2k_i+\ell_i(|G_{k_i}|+k_i+\log b_i)\bigr)\right).
   \tag{1.57}
   \]
   Thus a hard parent forces an object-scale control/descriptor term or a number of
   outsiders too large for an address-scale attachment.

2. **Systematic-witness recursive cover.** If instead the attachment is a source-family
   cover for \(X_i=(U_1,\ldots,U_{q_i})\), each \(U_j\in\{0,1\}^{s_i}\) being the unique
   witness of one NP query, and the non-output leaf tuple \(L_i\) determines the same
   canonical RW history, assume an exact depth-\(d_{{\rm tree},i}\) cover with
   \(m_i=2^{d_{{\rm tree},i}}\) leaves. If the leaves are conditionally independent
   given policy \(S_i\) and latent seed \(\sigma_i\), then
   \[
   q_i s_i-I_2(X_i;S_i)-k_i
   \le \operatorname{TC}_2(L_i\mid S_i)
   \le (m_i-1)H_2(\sigma_i\mid S_i).
   \tag{1.58}
   \]
   In particular, a target-oblivious \(d_i^{\rm seed}\)-bit seed must satisfy
   \[
   q_i s_i\le k_i+(m_i-1)d_i^{\rm seed}.
   \tag{1.59}
   \]
   If the package can recover the public query transcript or its canonical witnesses,
   that information is part of \(I_2(X_i;S_i)\); it is not a hidden-source escape.

3. **New-coupling/model-exit branch.** If neither of the preceding interfaces is
   supplied, the attachment has not yet established the advertised RW closure. It must
   explicitly provide a non-product global relation surviving conditioning on the stated
   seed, or else identify which hypothesis is abandoned: exact recursive range closure,
   non-output same-witness binding, common proof/address space, query invisibility, or
   address-scale control. Ordinary per-coordinate witnesses do not discharge this branch.

This trichotomy is a conditional source theorem, not an assertion that the published
fixed-\(x_0\) call satisfies the family hypotheses in item 2. If both item 1 and item 2
are claimed, either payment applies. The theorem's content is that C410 and C414 are not
independent local obstacles: every proposed RW attachment using one of these two concrete
binding mechanisms inherits the corresponding circuit or entropy payment, while any
remaining route must be exhibited as a genuinely new global coupling and re-prove
same-proof, smartness, cover, bottom, and length-alignment properties.

#### Proof

Item 1 is Proposition 1.35 applied to the selected singleton stage; hardwiring the
outsider values and descriptor and composing \(G_{k_i}\) along the known paths gives the
displayed circuit. For item 2, Proposition 1.39 gives the witness-entropy lower bound
and Proposition 1.38 gives the latent-seed upper bound on conditional total correlation;
combining them yields (1.58), and target-obliviousness gives (1.59). The visibility
sentence follows from \(H_2(W\mid Q)=0\) for a unique or canonical witness \(W\) of a
fixed public query transcript \(Q\), followed by data processing. If neither set of
hypotheses holds, the asserted attachment is precisely outside both source-specific
interfaces, which is item 3. \(\square\)

### Proposition 1.41 (corrected leftmost-normalized first-failure interval trichotomy)

The one-seed prefix bound previously associated with this proposition requires an
additional single-good-subtree hypothesis. Write
\(G:\{0,1\}^{n}\to\{0,1\}^{2n}\) for the generator and \(h\) for the JK height. In the
C392 leftmost-normalized recursion, let the first non-range block occur at stage
\(i\), block index \(j^\star\), with top ancestor interval \(A^\star\).  Published
Theorem 3.1 permits returning any block whose parallel SAT answer is NO and does not
itself specify this tie-break.  Selecting the least such index after the parallel
answers are available preserves its output guarantee and adds no query round,
witness length, or asymptotic time.  For a contiguous physical target interval \(I\),
let \(Q_i(I)\) be the stage-\(i\) blocks whose top ancestor intervals meet \(I\).

If \(I\) lies strictly to the left of \(A^\star\), all blocks in \(Q_i(I)\) have passed
the range test, and canonical preimages give
\[
\operatorname{CC}(\Pi^+[I])
\le
O\!\left(
n\lvert Q_i(I)\rvert
\,+\,(h-i+1)(|G|+n)
\,+\,\log(|\Pi^+|+2)
\right).
\tag{1.60}
\]
The \(n|Q_i(I)|\) term is necessary in general: JK stops at stage \(i\), so several
good blocks before \(j^\star\) need not form one range-closed block at stage \(i-1\).
Only when \(|Q_i(I)|=O(1)\), for example when \(I\) lies in one good subtree, does
the earlier \(O((|G|+n)H)\) form follow.

If \(I\cap A^\star\ne\varnothing\), the returned outsider attaches only the portion of
the target lying in \(A^\star\), via the forward half-lift; it does not bind target bits
in disjoint ancestor intervals. If \(I\) lies strictly to the right of \(A^\star\), the
published JK semantics gives no free binding for \(I\). A direct stage-\(i\) payload
upper bound is
\[
\operatorname{CC}(\Pi^+[I])
\le
O\!\left(
2n\lvert Q_i(I)\rvert
\,+\,(h-i)(|G|+n)
\,+\,\log(|\Pi^+|+2)
\right),
\tag{1.61}
\]
and any lower-cost same-proof attachment must provide a separately charged non-half-lift
global relation.

Under \(P=NP\), deterministic recompilation can make \(r=s=0\), and a fixed systematic
serialization may identify the output interval with the recompiled parent. The corrected
conclusion is therefore an ordered trichotomy—left-side canonical-preimage support,
single-block attachment, or right-side support/global relation—not automatic output
attachment from a disjoint ancestry condition. The complete correction and the
counterexample to the one-seed inference, including the normalization boundary, are in
[note 512](../../../mcsp-hardness-magnification/notes/512-corrected-jk-first-failure-interval-trichotomy-2026-08-19.md).

### Proposition 1.42 (shared half-lift DAG payment)

The pathwise payment in Theorem 1.40 is unchanged if several
output-attached outsiders share intermediate JK computations. More precisely, let a
closure expose \(q\) terminal \(2k\)-bit outsiders and let all subsequent canonical
half-lifts be represented by a directed acyclic graph with \(v\) distinct internal
half-lift nodes. If an explicit address-control circuit of size \(s_{\rm ctrl}\) and a
descriptor of cost \(d\) select, for every parent address, one DAG node and one bit and
thereby compute \(B\in\{0,1\}^{b}\), then

\[
 \operatorname{CC}(B)
 \le O\!\left(s_{\rm ctrl}+d+2kq+
 v\bigl(|G_k|+k+\lceil\log_2(b+2)\rceil\bigr)\right).
\tag{1.62}
\]

The proof is a topological expansion of the DAG: each distinct internal node invokes
one of the two half-lifts \(z\mapsto G_k(\operatorname{left}_k z)\) or
\(z\mapsto G_k(\operatorname{right}_k z)\) exactly once, while the terminal payload and
the final address selector are wired once. Thus a shared node is paid once, but sharing
does not remove the \(2kq\) terminal payload cost. For \(q\) independent paths of
lengths \(\ell_t\), \(v\le\sum_t\ell_t\), so (1.62) recovers the earlier pathwise bound;
the DAG statement also covers memoization and cross-coordinate reuse.

Consequently, at an address-scale \(k,q,v,d,s_{\rm ctrl}\le(\log(b+2))^{O(1)}\)
and \(|G_k|\le k^4\), a parent with
\(\operatorname{CC}(B)=\Omega(b/\log(b+2))\) cannot be bound by any such shared
half-lift DAG. A surviving closure must either pay message-scale terminal/control
information or exhibit a genuinely non-half-lift global relation. Combined with
Proposition 1.41, this removes “cached/shared JK paths” as an additional Gate-I escape;
it does not rule out a new global relation or prove \(P\ne NP\). Full hypotheses and
the proof are in [note 417](../../../mcsp-hardness-magnification/notes/417-rw-shared-half-lift-dag-parent-binding-2026-08-19.md).

### Proposition 1.43 (bounded-fanout seed barrier for non-half-lift relations)

The residual-correlation branch left by Proposition 1.36 can also be quantified for a
natural class of genuinely joint relations. Let \(U=(U_1,\ldots,U_d)\) be a seed whose
coordinates are conditionally independent given the target \(X\) and policy \(S\).
Suppose that, after conditioning on \((X,S,U)\), the coordinate-local random tapes are
independent, and that output \(Z_j\) reads only \(U_{N(j)}\). Write
\[
 D_\ell=|\{j:\ell\in N(j)\}|,\qquad D=\max_\ell D_\ell .
\]
After deleting unused seed coordinates, conditional KL data processing gives
\[
 \operatorname{TC}_2(Z\mid X,S)
 \le \sum_{\ell}(D_\ell-1)H_2(U_\ell\mid X,S)
 \le (D-1)\sum_\ell H_2(U_\ell\mid X,S).
\tag{1.63}
\]
Combining (1.63) with the Fano/residual-correlation inequality of Proposition 1.36
shows that a \(p_b\)-successful, distance-separated global relation must satisfy
\[
 I_2(X;S)+\sum_j I_2(X;Z_j\mid S)
 +(D-1)\sum_\ell H_2(U_\ell\mid X,S)
 \ge p_b b-1 .
\tag{1.64}
\]
Thus a polylogarithmic seed with polylogarithmic fanout cannot be the missing
non-half-lift closure: it leaves \(\Omega(b)\) bits in the policy/coordinate channel,
which enters the transcript-capacity or shared-DAG payment. A surviving relation must
use message-scale fanout, seed-after-conditioning dependence, or direct post-seed
global coupling. This is a conditional-product barrier, not a general dPCP
impossibility or a \(P\ne NP\) proof; the full statement and entropy proof are in
[note 418](../../../mcsp-hardness-magnification/notes/418-bounded-fanout-seed-global-relation-barrier-2026-08-19.md).

### Proposition 1.44 (seed-correlation/fanout trichotomy)

Proposition 1.43 leaves one explicit escape: the seed coordinates may remain
dependent after conditioning on the target \(X\) and policy \(S\). This dependence can
also be charged without assuming conditional independence of the seed coordinates.
Let \(Q=(X,S)\), let \(U=(U_1,\ldots,U_d)\) be an arbitrary finite-alphabet seed, and
let \(R_1,\ldots,R_M\) be mutually independent of one another and of \(U\) conditional
on \(Q\). If
\[
 Z_j=\phi_j(Q,U_{N(j)},R_j),\qquad
 D_\ell=|\{j:\ell\in N(j)\}|,\qquad D=\max_\ell D_\ell,
\]
then, after deleting unused seed coordinates,
\[
 \operatorname{TC}_2(Z\mid X,S)
 \le
 \sum_{\ell}(D_\ell-1)H_2(U_\ell\mid X,S)
 +\operatorname{TC}_2(U\mid X,S)
 \le
 (D-1)\sum_\ell H_2(U_\ell\mid X,S)
 +\operatorname{TC}_2(U\mid X,S).
\tag{1.65}
\]
Indeed, with \(W_j=(U_{N(j)},R_j)\), coordinatewise data processing gives
\(\operatorname{TC}_2(Z\mid Q)\le\operatorname{TC}_2(W\mid Q)\). The conditional
independence of the \(R_j\)'s cancels their entropies, leaving
\(\sum_jH_2(U_{N(j)}\mid Q)-H_2(U\mid Q)\); subset-entropy subadditivity and
\(\operatorname{TC}_2(U\mid Q)=\sum_\ell H_2(U_\ell\mid Q)-H_2(U\mid Q)\)
give (1.65).

Combining (1.65) with the nearest-word/Fano inequality of Proposition 1.36 yields
the following closure ledger for any distance-separated canonical family with
success probability \(p_b\):
\[
 I_2(X;S)+\sum_j I_2(X;Z_j\mid S)
 +(D-1)\sum_\ell H_2(U_\ell\mid X,S)
 +\operatorname{TC}_2(U\mid X,S)
 \ge p_b b-1.
\tag{1.66}
\]
Consequently, if the target/policy channel and the fanout term are \(o(b)\) while
\(p_b=\Omega(1)\), then seed-after-conditioning dependence itself must contribute
\(\Omega(b)\) conditional total correlation. A relation that avoids this payment must
use direct post-seed joint coupling, joint proof-state access, or leave the
coordinate-factorized model. This extends Proposition 1.43 to correlated seeds but
is still a seed-factorized barrier, not a general dPCP/RLDC impossibility or a
\(P\ne NP\) theorem. The full statement and sharpness examples are in
[note 419](../../../mcsp-hardness-magnification/notes/419-seed-correlation-fanout-global-relation-barrier-2026-08-19.md).

### Proposition 1.45 (full recursive-frontier parent-binding barrier)

There is a stronger obstruction than the first-failure attachment of Proposition 1.41.
Split a padded binary proof into \(2k_i\)-bit top blocks and form the complete binary
JK recursion tree using the canonical selector
\(p:\operatorname{Range}(G_{k_i})\to\{0,1\}^{k_i}\) satisfying only
\(G_{k_i}(p(z))=z\) for \(z\in\operatorname{Range}(G_{k_i})\); no injectivity of
\(G_{k_i}\) is assumed. A leaf outside the range, or a defined internal candidate outside the
range, is a failure node; an undefined internal node is recursively split. If
\(\mathcal F_i\) is the set of all such failure nodes and \(\mathcal T_i\) is the resulting
set of good-seed or bad-leaf terminals, then

\[
|\mathcal T_i|\le 1+2H_i|\mathcal F_i|,
\tag{1.67}
\]

and the parent prefix \(B_i\) has a Boolean address evaluator of size

\[
\operatorname{CC}(B_i)
\le O\!\left(H_i C_{G_i}(1+H_i|\mathcal F_i|)\right),
\qquad
C_{G_i}:=|G_{k_i}|+k_i+\lceil\log_2(L_i+2)\rceil.
\tag{1.68}
\]

Thus, whenever the forcing lower bound is above the one-terminal cost,

\[
|\mathcal F_i|
 =\Omega\!\left(
\frac{\operatorname{CC}(B_i)}{H_i^2C_{G_i}}
\right).
\tag{1.69}
\]

In the RW stable window \(H_i=O(\log n_i)\), \(b_i\asymp n_i\),
\(|G_{k_i}|\le k_i^4\), and \(\operatorname{CC}(B_i)=\Omega(n_i/\log n_i)\), this is

\[
|\mathcal F_i|=\Omega\!\left(
\frac{n_i}{(k_i^4+k_i+\log(n_i+2))\log^3(n_i+2)}
\right),
\tag{1.70}
\]

up to the stated one-terminal domination condition. In particular, a polylogarithmic
full recursive frontier cannot bind a forcing parent through canonical JK half-lifts.
The full recursive failure frontier is a counterfactual object and is not the number of
queries exposed by the actual first-failure JK execution. A route below this frontier
bound must exhibit a non-half-lift global relation; the proposition is source-specific and
does not prove (P\ne NP). See [note 420](../../../mcsp-hardness-magnification/notes/420-rw-full-jk-frontier-parent-binding-2026-08-19.md)
and the canonical-selector correction [note 493](../../../mcsp-hardness-magnification/notes/493-jk-frontier-canonical-selector-correction-2026-08-19.md)
for the definitions, induction, terminal-count proof, and circuit construction.

### Theorem 1.46 (singleton Closure-Gate trichotomy)

Propositions 1.35, 1.42, and 1.45 can be read as one singleton gate. Let \(B_i\) be a
forcing parent with address length \(m_i=\lceil\log_2(2n_i+2)\rceil\), and suppose a
proposed attachment uses either:

1. one finite common proof/response descriptor of length \(d_i\), an explicit control
   circuit of size \(p_i\), and at most \(r_i^{\rm read}\) descriptor reads per address,
   with the RW \(1\) versus \(1/2\) final-query gap; or
2. the full canonical JK recursive frontier of Proposition 1.45, with frontier
   \(\mathcal F_i\), height \(H_i\), and
   \(C_{G_i}=|G_{k_i}|+k_i+\lceil\log_2(L_i+2)\rceil\).

Then the first interface forces

\[
p_i+r_i^{\rm read}d_i
\ge \Omega\!\left(\frac{\operatorname{CC}(B_i)}{m_i}\right)
\tag{1.71}
\]

up to the \(O(m_i)\) additive control term, while the second forces

\[
|\mathcal F_i|
\ge
\Omega\!\left(
\frac{\operatorname{CC}(B_i)}{H_i^2C_{G_i}}
\right)
\tag{1.72}
\]

whenever \(\operatorname{CC}(B_i)/(H_iC_{G_i})\to\infty\). If a proposed singleton
closure lies in the finite-response interface, or lies in the canonical-frontier
interface with this domination condition, the corresponding payment is mandatory.
Avoiding both payments then requires leaving one of those interfaces: the construction
must explicitly exhibit a non-half-lift global coupling, a non-succinct/unbounded
interaction, or a changed promise/common-address semantics. Proposition 1.46A below
shows that finite-horizon interaction with one short common strategy is already a
finite-response payment, regardless of public-randomness length. If the domination condition fails, the
canonical frontier may still be an object-scale representation, but this proposition
does not turn it into a forcing contradiction. The alternatives are not an
unconditional \(P\ne NP\) theorem.

For the published RW stable parameters,
\(m_i=\Theta(\log n_i)\) and
\(\operatorname{CC}(B_i)=\Omega(n_i/\log n_i)\), so the finite-response branch
requires

\[
p_i+r_i^{\rm read}d_i
\ge \Omega\!\left(\frac{n_i}{\log^2(n_i+2)}\right).
\tag{1.73}
\]

By contrast, \(k_i=n_{i+1}=n_i^C\) makes
\(H_iC_{G_i}\gg\operatorname{CC}(B_i)\) under the known
\(|G_{k_i}|\le k_i^4\) bound, so the domination condition for (1.72) fails on the
published object-scale width. Proposition 1.45 therefore closes only the
address-scale canonical-frontier subcase; it must not be presented as a
nontrivial lower bound for the actual stable-width singleton call. The full proof and
the exact model-exit boundary are in [note 421](../../../mcsp-hardness-magnification/notes/421-rw-singleton-closure-gate-trichotomy-2026-08-19.md).

### Proposition 1.46A (finite-horizon common-strategy sampling closure)

The finite-response branch can be enlarged from a static ROM strategy to a finite,
address-parametrized interactive strategy without charging the length of its public
randomness.  Let \(H\in\{0,1\}^{N}\), let
\(m=\lceil\log_2(N+1)\rceil\), and suppose that, after the relevant
\(P=NP\) determinization, one common strategy \(\mathcal S(a,R)\) is used for every
address \(a\).  Assume a descriptor \(\sigma\) of length \(d\), arbitrary public coins
\(R\), and a finite transcript/evaluator implementation of size \(u\) (including the
complete response transcript on each \((a,R)\)).  Write

\[
 p_a=\Pr_R[V(a,\sigma,R,\mathcal S(a,R))=1].
\]

If, for some fixed gap \(\gamma=\alpha-\beta>0\),

\[
 H[a]=1\Longrightarrow p_a\ge\alpha,
 \qquad
 H[a]=0\Longrightarrow p_a\le\beta,
\tag{1.74A}
\]

then for every \(\delta\in(0,1)\) there is a multiset of

\[
 t=O\!\left(\frac{m+\log(1/\delta)}{\gamma^2}\right)
\tag{1.75A}
\]

public tapes for which a deterministic threshold circuit computes every bit of \(H\),
with

\[
 \operatorname{CC}(H)\le
 O\!\left(t\,\operatorname{poly}(u,d,m,\log(1/\gamma))\right).
\tag{1.76A}
\]

The sample tapes are nonuniform advice; no uniform procedure for finding them is
claimed.  In the static transcript-table special case, \(u\) may be replaced by the
verifier/control size and the transcript length, with the usual ROM-read expansion.

#### Proof

For a fixed address \(a\), let \(Y_j(a)\) be the acceptance bit obtained from an
independent public tape \(R_j\) and the common strategy.  Hoeffding's inequality gives

\[
 \Pr\!\left[\left|t^{-1}\sum_{j=1}^{t}Y_j(a)-p_a\right|>\gamma/3\right]
 \le 2\exp(-2t\gamma^2/9).
\]

Taking the constant in (1.75A) large enough makes this probability at most
\(\delta/N\).  A union bound over all \(N\) addresses gives one sample multiset that
simultaneously separates the two cases in (1.74A) by the threshold
\((\alpha+\beta)/2\).  Hardwire those tapes and unroll the \(t\) finite evaluations;
address arithmetic, thresholding, and the descriptor/strategy circuits contribute the
cost in (1.76A).  \(\square\)

Consequently, at the RW address scale, a finite-horizon common strategy with
\(u,d,\gamma^{-1}=m^{O(1)}\) already gives an \(m^{O(1)}\)-size circuit for a forcing
parent of complexity \(2^{\Omega(m)}/\operatorname{poly}(m)\), regardless of the
number of public random bits.  Thus the E branch of Theorem 1.46 narrows as follows:
the surviving interaction must use different strategies per address, a non-succinct or
object-scale response evaluator/transcript, a vanishing gap, or a genuinely new
post-transcript global relation.  The result does not apply to the published RW
singleton merely because each address has some existential Merlin witness; the common
strategy quantifier is essential.  See [note 230](../../../mcsp-hardness-magnification/notes/230-common-strategy-sampling-eliminates-public-randomness-2026-08-17.md).

### Proposition 1.47 (arbitrary joint-coupling latent-state barrier)

The non-half-lift branch can be tested without assuming a seed factorization. Let
\(X\) be uniform on \(2^b\) targets with canonical words
\(\{\Pi_x:x\in\{0,1\}^b\}\subseteq\Gamma^M\) of pairwise distance greater than
\(2t\). Let \(S\) be the complete policy/descriptor/cover package and let \(W\) be
an arbitrary latent global state. If the produced word \(Z\) satisfies

\[
 X\longrightarrow(S,W)\longrightarrow Z
\tag{1.74}
\]

and \(\Pr[d_H(Z,\Pi_X)\le t]=p_b\), then

\[
 I_2(X;S)+I_2(X;W\mid S)\ge p_b b-1.
\tag{1.75}
\]

In particular, if \(H_2(W\mid S)\le h_b\), then

\[
 I_2(X;S)+h_b\ge p_b b-1.
\tag{1.76}
\]

Thus an arbitrary post-seed joint coupling with a sublinear target-independent state
cannot bind a constant-success, distance-separated \(b\)-bit family. The proof is
nearest-word decoding followed by Fano and conditional data processing:
\(I_2(X;Z\mid S)\le I_2(X;W\mid S)\). This proposition strictly relaxes the
conditional-independence, fanout, and coordinate-factorization hypotheses of
Propositions 1.43--1.44, but it remains a family-level statement. It does not apply
to the published fixed-\(x_0\) RW singleton and does not prove \(P\ne NP\).

The resulting Gate-II boundary is quantitative: a surviving non-half-lift relation
must expose \(p_b b-O(1)\) bits through the policy-plus-latent channel, use a
message-scale latent state, or abandon the target-independent-kernel semantics. Full
statement and proof are in [note 422](../../../mcsp-hardness-magnification/notes/422-rw-arbitrary-joint-coupling-latent-state-information-barrier-2026-08-19.md).

### Proposition 1.48 (RW systematic-prefix instantiation)

The latent-state barrier has a source-level distance instantiation. Apply the RW
construction to the identity machine \(M_{\mathrm{id}}(x)=x\), \(x\in\{0,1\}^b\),
with no NP queries. If \(\widetilde w_x:F^m\to F\) is the systematic
Reed--Muller witness field in Theorem 3.4, then for
\(D=m|H|\), \(Q=|F|^m\),

\[
 d_H(\widetilde w_x,\widetilde w_{x'})
 \ge (1-D/|F|)Q
\qquad(x\ne x').
\tag{1.77}
\]

Indeed, the identity outputs make the raw satisfying assignments distinct, so the
difference of their degree-\(D\) extensions is nonzero; Schwartz--Zippel gives (1.77).
Consequently, if a common witness-prefix relation \(Z\) obeys
\(X\to(S,W)\to Z\) and reaches \(\widetilde w_X\) within
\(t<(1-D/|F|)Q/2\) with probability \(p_b\), then

\[
 I_2(X;S)+I_2(X;W\mid S)\ge p_b b-1.
\tag{1.78}
\]

This closes arbitrary post-seed coupling with sublinear target-independent state on
the actual systematic prefix, without seed-independence or fanout assumptions. It
does not apply to the published fixed-\(x_0\) singleton, nor to an arbitrary
auxiliary/ECC suffix unless a separate projection-to-prefix argument is supplied.
See [note 423](../../../mcsp-hardness-magnification/notes/423-rw-systematic-rm-prefix-joint-coupling-barrier-2026-08-19.md).

### Theorem 1.49 (quantifier-aligned RW Closure-Gate)

The preceding singleton and family barriers can be used as one closure gate only
after the quantifiers of the proposed attachment are fixed. Let \(B\in\{0,1\}^b\)
be a forcing parent with address length \(m=\lceil\log_2(b+2)\rceil\) and
\(\operatorname{CC}(B)>S\). The following three normal forms have the stated
payments:

1. **Singleton normal form.** For a fixed canonical proof, a finite common-response
   interface with control size \(p\), descriptor length \(d\), and at most \(r\)
   descriptor reads per address satisfies
   \[
   \operatorname{CC}(B)\le O\!\left(m(p+rd+m)\right),
   \tag{1.79}
   \]
   while a shared canonical JK half-lift DAG with \(q\) terminal \(2k\)-bit outsiders
   and \(v\) internal lift nodes satisfies
   \[
   \operatorname{CC}(B)\le O\!\left(s_{\rm ctrl}+d+2kq+
   v(|G_k|+k+\log(b+2))\right).
   \tag{1.80}
   \]
   Thus a hard parent forces the corresponding control/descriptor or terminal
   payment within these interfaces.

2. **Product-rich source-family normal form.** If a deterministic selector has
   \(\nu\) public-context bits, a depth-\(d\) subtree has leaf families
   \(\mathcal A_1,\ldots,\mathcal A_{2^d}\), every product tuple is realized by
   one source-compatible canonical proof, and all non-output recursive blocks lie in
   the same \(R_G=\operatorname{Range}(G_k)\) with injective canonical preimage, then
   \[
   \log_2\!\prod_{\ell=1}^{2^d}|\mathcal A_\ell|
   \le \min\{\nu,k\}.
   \tag{1.81}
   \]
   For aligned product-ECC leaves of rate \(R\), this is
   \(2^{d+1}Rk\le\min\{\nu,k\}\).

3. **Distance-separated latent-coupling normal form.** If \(X\) is uniform on
   \(2^b\) targets with canonical words of pairwise distance \(>2t\), and
   \(X\to(S,W)\to Z\) with
   \(\Pr[d_H(Z,\Pi_X)\le t]=p_b\), then
   \[
   I_2(X;S)+I_2(X;W\mid S)\ge p_b b-1.
   \tag{1.82}
   \]

This is a scope-aligned union gate, not a theorem that every reconstruction belongs
to one of the three forms. The first form applies to the published fixed-\(x_0\)
singleton; the second and third require an actual target family and cannot be
obtained by varying \(x\), the machine, \(G\), or the stage while calling the result
one hidden singleton. If a proposed same-proof, same-address, address-scale closure
claims none of these normal forms, it must exhibit a new non-product global relation
or explicitly leave one of common proof, target-independent range closure,
word consistency, address-scale control, or promise-preserving semantics. In
particular, (1.81) and (1.82) cannot be applied to the published singleton merely
because the construction has many existential honest proofs.

The proof is the combination of Proposition 1.42, Theorem 1.46, Proposition 1.47,
and Proposition 1.32c; the deterministic-selector boundary is the source audit in
[note 406](../../../mcsp-hardness-magnification/notes/406-rw-public-input-family-route-closure-2026-08-18.md).
The full statement and proof ledger are in
[note 427](../../../mcsp-hardness-magnification/notes/427-rw-quantifier-aligned-closure-gate-2026-08-19.md).

### Theorem 1.50 (logical-scale collapse boundary for the published RW recursion)

The published recursion has a further scale boundary that must be kept separate from
Theorem 1.1. Let \(B_m\) be the truth-table-generator output used in Theorem 4.5, with
\(|B_m|=2^{\Theta(m)}\), and let the \(m\)-bit language query one coordinate of \(B_m\).
Assume that under \(P=NP\) the fixed-format smart-prMA queries of Theorem 4.1 are
determinized in time polynomial in their explicit encoding length. Then the original
one-bit-advice \(A_0/A_1\) construction gives only

\[
  \mathcal L\in\mathrm{EXP}/1,
  \qquad \operatorname{CC}(B_m)\le 2^{O(m)}.
\tag{1.83}
\]

Indeed, on the stable tail the source parameters are \(n_i=2^{\Theta(m)}\),
\(T_i=n_{i+1}=n_i^C\), and \(r_i=O(n_i)\); both the SAT-based solver and the
smart reconstruction therefore run in \(n_i^{O(1)}=2^{O(m)}\) time after
determinization. The one advice bit selects the branch only on the lengths where the
corresponding promise guarantee is available. The forcing lower bound
\(\operatorname{CC}(B_m)>2^m/\operatorname{poly}(m)\) is compatible with (1.83).

Consequently, \(P=NP\) determinization at the explicit RW object scale does not instantiate
Theorem 1.1. A \(P/\mathrm{poly}\) contradiction requires a new same-proof evaluator whose
entire address, descriptor, query, and control scale is \(m^{O(1)}\), i.e. polynomial in
\(\log |B_m|\). The detailed source calculation is recorded in
[note 431](../../../mcsp-hardness-magnification/notes/431-rw-logical-scale-collapse-boundary-2026-08-19.md).

### Proposition 1.51 (source-uniform actual-RW accessor barrier)

There is no free source-uniform version of the address-scale interface. Fix a deterministic
RW machine \(M_{\mathrm{SCV}}\) that, on a succinct description of a
\(2^{O(n)}\)-gate circuit and an input address, outputs the circuit value in
\(2^{O(n)}\) time. Its deterministic computational history has no NP-query prefix, and
the output bit occurs at a fixed systematic-proof address \(a_{\mathrm{out}}(n)\).

If, under \(P=NP\), one uniform \(n^{O(1)}\)-time evaluator returned the canonical
Theorem 3.5 proof bit \(\Pi_x[a]\) for every input \(x\) to this fixed machine, then
\[
  \Pi_x[a_{\mathrm{out}}(n)]=C_x(r)
\]
would decide succinct circuit value in polynomial time. This contradicts the deterministic
time hierarchy theorem. Hence a source-uniform address-scale proof accessor is itself
already a \(P\ne NP\) theorem; it cannot be imported as a generic Gate-I lemma.

This barrier leaves the published fixed-\(x_0\) singleton untouched, because its quantifier
does not range over the succinct circuit instance \(x\). The remaining positive target is
therefore genuinely source-specific: a fixed-context selector for the non-systematic
Harsha/JK blocks, or a new global relation that does not expose the output prefix as a
random-access witness. See [note 432](../../../mcsp-hardness-magnification/notes/432-source-uniform-actual-rw-accessor-barrier-2026-08-19.md).

### Proposition 1.52 (small-width AVOID block-exposure Closure Gate)

Fix a \(P=NP\) deterministic recompilation with zero query prefix and fixed binary
serialization. Let \(f\in\{0,1\}^{T}\), \(B=f[1,b]\), and
\(\ell=\lceil\log_2(T+1)\rceil\), with \(\operatorname{CC}(B)>S\). Suppose the
fixed canonical binary proof is \(\Pi\), the retained source-round parameter is \(r\),
and the construction makes \(q\) AVOID calls
\[
G_t:\{0,1\}^{n_t}\to\{0,1\}^{2n_t},
\qquad |G_t|\le n_t^4,
\qquad L_t=n_t+r+\ell.
\]
The easy branches are excluded by
\[
S>C_0\max_t L_t^{c_0}.
\tag{1.84a}
\]
For any call \(t\) that takes the hard branch, let \(i_t\) and \(j_t^\star\) be its
first failure stage and block index, let \(A_t^\star\) be the corresponding top
ancestor interval, and let \(Q_t(B)\) be the stage-\(i_t\) blocks whose top ancestor
intervals meet \(B\). If the first outsider is disjoint from \(B\), it lies to the right
of \(B\), and C512 gives the left-side support cost
\[
\Lambda_t
:=
n_t\lvert Q_t(B)\rvert
\,+\,(h_t-i_t+1)(|G_t|+n_t)
\,+\,\log(|\Pi|+2),
\tag{1.84b}
\]
where \(h_t\) is the JK height. Thus, under the explicit per-call hypothesis
\[
S>C_1\max_{t:\,\mathrm{hard}}\Lambda_t,
\tag{1.84c}
\]
every hard call has canonical outsider ancestry intersecting \(B\). If (1.84c) is not
available, C512 leaves a quantified left-support payment rather than an attachment
conclusion; the old one-seed \(O((|G_t|+n_t)h_t)\) threshold is valid only when
\(|Q_t(B)|=O(1)\).

If the attached outsiders are further connected by a
generator-labelled shared half-lift DAG that exactly covers \(B\), then
\[
\operatorname{CC}(B)
\le O\!\left(
s_{\rm ctrl}+d+2\sum_{t=1}^{q}n_t
+\sum_{u\in V_{\rm int}}
\bigl(|G_{\tau(u)}|+n_{\tau(u)}+\log(b+2)\bigr)\right).
\tag{1.85}
\]
In particular, if all width, recursion, address, terminal, DAG, descriptor, and
control parameters are polylogarithmic in \(b\), the right-hand side is
\(\operatorname{polylog}(b)\), contradicting a forcing bound
\(\operatorname{CC}(B)=\Omega(b/\log(b+2))\).

The first two conclusions follow respectively from C363 and the corrected C512
first-failure trichotomy. For (1.85), expand
the shared DAG once in topological order: terminal payloads cost
\(O(2\sum_t k_t)\), each internal half-lift labelled by \(t\) costs
\(O(|G_t|+k_t+\log(b+2))\), and the explicit selector and descriptor cost
\(O(s_{\rm ctrl}+d)\). The ancestry conclusion is not whole-parent recovery; exact
coverage is an additional hypothesis. A relation that cannot be expanded as this
half-lift DAG remains an open non-half-lift global-relation branch.

This proposition is a new RW-specific Closure Gate, not an unconditional \(P\ne NP\)
proof. See [note 433](../../../mcsp-hardness-magnification/notes/433-rw-small-width-avoid-block-coverage-closure-gate-2026-08-19.md).

### Proposition 1.53 (recursive self-describing range closure)

The half-lift barriers do not cover every correlated auxiliary stream. Let
\(\Theta\) be a finite shared-parameter set, let \(M=2^{D-1}\), and let
\(e(\theta,u,j)\in\{0,1\}^{k}\) be injective descriptors for
\(\theta\in\Theta\), \(u<M\), and \(0\le j<D\). Suppose tagged raw blocks
\(R(\theta,u)\in\{0,1\}^{2k}\) and, for
\(0\le j\le D-2\) and \(u\equiv0\pmod {2^{j+1}}\), recursive pair blocks
\[
P_j(\theta,u)=e(\theta,u,j)\,\Vert\,e(\theta,u+2^j,j)
\]
are mutually separated and injective, including separation from a fixed filler word.
Then one polynomial-size generator \(G:\{0,1\}^{k}\to\{0,1\}^{2k}\) can map
\[
e(\theta,u,0)\mapsto R(\theta,u),
\qquad
e(\theta,u,j+1)\mapsto P_j(\theta,u).
\]
For every fixed \(\theta\), the \(k2^D\)-bit stream
\[
R(\theta,0)\Vert\cdots\Vert R(\theta,M-1)
\]
is in range at every JK level, so JK returns the easy branch. The required seed
budget is
\[
\log|\Theta|+\lceil\log M\rceil+\lceil\log(D+1)\rceil+O(1)\le k.
\]
For \(D=1\), \(M=1\) and the recursive pair family is empty, so the statement
reduces to the single raw block case.

The proof is an induction on the JK levels: canonical inversion of a raw block
recovers \(e(\theta,u,0)\), and the concatenation of two adjacent descriptors is
exactly the next recursive pair block. Thus recursive depth itself is cheap when one
shared parameter is reused; the cost is the parameter and address description.

There is a matching family limitation. If a depth-\(d\) subtree has a shared
\(s\)-bit parameter and \(2^d\) independent local leaf labels of \(h\) bits, and
different tuples give different ordered leaf values while every leaf and internal
block remains in one common range \(R_G\), then
\[
s+2^d h\le k.
\]
This is the shared-parameter refinement of the product-capacity barrier. It permits
the single-parameter algebraic branch, but rules out unbounded-depth closure with
independent line or ECC payload.

For a tagged univariate degree-\(\Delta\) polynomial over a \(\lambda\)-bit field,
using at least \(q\ge\Delta+1\) distinct evaluation points per raw block, the
positive branch has the sufficient budget
\[
(\Delta+1)\lambda+\lceil\log M\rceil+\lceil\log(D+1)\rceil+O(1)\le k,
\]
with an additional \(2d\lambda\) term for an affine-line restriction. This extends
the one-level algebraic block cover only under the explicitly added tagged
serialization and injective-descriptor hypotheses. The published RW/Harsha theorem
does not supply those hypotheses globally for all multivariate auxiliary oracles,
and this mechanism still does not bind the systematic output parent.

This proposition is a positive RW-specific mechanism, not a \(P\ne NP\) proof. See
[note 434](../../../mcsp-hardness-magnification/notes/434-rw-recursive-self-describing-range-closure-2026-08-19.md).

### Proposition 1.54 (systematic-output support gate)

Consider the legal identity specialization \(M_{\mathrm{id}}(x)=x\) on
\(\{0,1\}^{b}\), and fix a binary serialization in which a known interval of the
systematic witness contains the \(b\) output bits.  Let \(Z(x)\) be an output block
whose free output projection has \(h\) bits.  If one target-oblivious generator
\(G_k:\{0,1\}^{k}\to\{0,1\}^{\ell}\) has to contain \(Z(x)\) in its range for every
\(x\), then
\[
h\le k.
\]
If a \(d\)-bit target-dependent descriptor selects one of \(2^d\) such generators,
the necessary condition becomes
\[
h\le k+d.
\]
The same statement holds recursively: if disjoint leaves have free entropies
\(h_1,\ldots,h_m\), all leaf tuples are realizable by the identity family, and every
leaf and canonical-preimage internal block is in the common range, then
\[
\sum_{\ell=1}^{m}h_\ell\le k
\quad\text{(or \(k+d\) with one \(d\)-bit selector).}
\]
The proof is support counting followed by canonical-preimage injectivity.  In
particular, a \(2k\)-bit output block with fewer than \(k\) fixed tags has
\(h>k\), so C433's shared low-degree positive mechanism cannot silently cover it
for the full identity family.  It must leave the block output-attached, pay target
information in a descriptor, or exit common recursive range closure.

This is a family-level source gate, not a singleton impossibility or a \(P\ne NP\)
proof.  See [note 435](../../../mcsp-hardness-magnification/notes/435-rw-systematic-output-recursive-range-support-gate-2026-08-19.md).

### Proposition 1.55 (Harsha algebraic leaf cover versus recursive depth)

Under a fixed, reversible line-major serialization of the Harsha algebraic oracles
\(\widetilde A,P,\Pi_{\mathrm{ZoS}}\), let \(s_{\rm alg}\) be the coefficient/line
descriptor length for one bundled line block.  With
\[
m=\left\lceil\frac{\log N}{\log\log N}\right\rceil,\quad
|H|=N^{1/m},\quad |F|=\Theta((m|H|)^3),
\]
the Harsha degree bounds give
\[
s_{\rm alg}=O(m^2|H|\log|F|).
\]
If
\[
\max\{s_{\rm alg},Q_ka+\lceil\log b\rceil+1\}
\,+\,O(\log(m+2))\le k,
\]
where \(Q_k=\lceil2k/b\rceil+1\) is the product-ECC symbol count, a tagged
polynomial-size generator covers every algebraic line block and internal product-ECC
block satisfying the serialization assumptions.  For a bundled line output of
\(2k=\Theta(m|F|\log|F|)\), one has
\[
\frac{k}{s_{\rm alg}}=\Omega(m^2|H|^2).
\]

This is only a leaf-layer result.  If a depth-\(d\) subtree has
\(2^d\) product-rich independent line families, each with descriptor entropy
\(s_{\rm alg}\), and every leaf and canonical-preimage internal block must remain in
the same range, then
\[
2^d s_{\rm alg}\le k.
\]
Thus the independent-line universal branch supports at most
\(O(\log(m|H|))=O(\log\log N)\) recursive levels, whereas the complete-table
Harsha proof has JK height \(\Theta(\log N)\).  A full recursive closure therefore
requires a shared global line parameter with a canonical tagged inverse, a collapse
of actual line entropy, or a new non-product global relation.  The proposition is
conditional on the stated serialization and degree interface and does not apply
automatically to the published fixed-\(x_0\) singleton.  See
[note 436](../../../mcsp-hardness-magnification/notes/436-harsha-algebraic-leaf-cover-recursive-depth-gate-2026-08-19.md).

### Proposition 1.56 (shared-global parameter Closure trichotomy)

Consider the Harsha line-major/product-ECC interface above, with a shared parameter
\(\theta\) of at most \(s\) bits, a \(d\)-bit target-dependent descriptor, and \(r\)
further target-dependent label bits.  If the same fixed evaluator exactly generates a
systematic output family with \(h\) free bits, then

\[
s+d+r\ge h.
\]

In particular, if the recursive seed budget is \(s+\ell_{\rm addr}+\tau\le k\),
then full common closure implies \(h\le k+d+r\).  Thus a family-level identity
source cannot hide a message-scale systematic parent in an address-scale shared
Harsha parameter.  If the shared interface covers only auxiliary/non-output blocks,
it remains an auxiliary recursive closure and needs a separate first-failure/output-
attachment theorem.  Any construction outside this parameterized evaluator is a new
non-product global relation and must separately establish same-proof consistency,
address-scale generation, cover handling, bottom safety, and output attachment.

This is a source-family trichotomy, not a singleton impossibility and not a \(P\ne NP\)
proof.  See [note 437](../../../mcsp-hardness-magnification/notes/437-harsha-shared-global-parameter-closure-trichotomy-2026-08-19.md).

### Proposition 1.57 (native-width Harsha recursive-capacity gate)

The line-cover argument must be checked at the native width used by RW, not only at
the width of one algebraic micro-block. Fix a reversible, address-scale line-major
serialization. Let a complete bundled line segment have length \(2\kappa\), and
suppose each such segment has at least \(2^{s_*}\) source-realizable values. Assume
that a native \(2K\)-bit block contains \(r\) complete segments whose values can be
chosen independently, up to two boundary fragments, and let
\[
  G_K:\{0,1\}^{K}\to\{0,1\}^{2K},
  \qquad R_K=\operatorname{Range}(G_K).
\]
Consider a depth-\(d\) non-output JK subtree with \(2^d\) such leaves. If every leaf
and every canonical-preimage internal block lies in the same \(R_K\), then
\[
  2^d r s_*\le K.
\tag{1.86}
\]
Indeed, distinct leaf tuples give distinct root blocks, while
\(|R_K|\le2^K\). If \(K\ge6\kappa\), boundary loss still leaves
\(r\ge K/(2\kappa)\), hence
\[
  2^d s_*\le2\kappa,
  \qquad
  d\le\log_2(2\kappa/s_*).
\tag{1.87}
\]
The upper bound is independent of the native width \(K\).

For the source-compatible Harsha line interface,
\[
  \kappa=\Theta(m|F|\lambda),
  \qquad
  s_*=\Omega(m^2|H|\lambda)
\tag{1.88}
\]
on a genuinely product-rich line family. Since
\(|F|=\Theta((m|H|)^3)\), (1.87) gives
\(d=O(\log(m|H|))=O(\log\log N)\). Thus, if
\[
  D_{\rm native}:=\left\lceil\log_2(L/K)\right\rceil
  >\log_2(2\kappa/s_*),
\tag{1.89}
\]
an independent-line universal range cover cannot cross the complete native JK tree.
For the Harsha length \(L=N^{18+o(1)}\), this applies whenever
\(\log(L/K)=\Omega(\log N)\); the published stable identity \(K=T_i\) alone does not
establish that inequality and must be checked against the actual \(N_i=|C_{x_0}|\).

Consequently, the native-width Gate-I alternatives are: \(K<6\kappa\), where the
micro-block analysis still needs output attachment; \(K\ge6\kappa\) with independent
line entropy, where (1.86) limits recursive depth; or a shared global parameter,
actual line-entropy collapse, or a new non-product relation. Merely concatenating a
micro-block generator into a native \(G_K\) without proving its canonical inverse and
seed capacity is not a RW/JK closure. The product-rich hypothesis is a family
hypothesis and does not apply to the published fixed-\(x_0\) singleton by itself.
This proposition does not prove \(P\ne NP\). See [note 438](../../../mcsp-hardness-magnification/notes/438-rw-native-width-harsha-block-capacity-gate-2026-08-19.md).

### Proposition 1.58 (Harsha auxiliary-to-systematic inversion gate)

Harsha's actual auxiliary polynomial has a stronger source-level property than a
forward factorization. Write
\[
 p(q)(u,v,w,y_1,y_2,y_3)
 =
 \widehat C(u,v,w,y_1,y_2,y_3)
 \prod_{j=1}^{3}(q(u_j)-y_j),
\]
where \(u_1=u,u_2=v,u_3=w\), and let
\(D_C\le(3m+3)|H|\) be the degree of \(\widehat C\). Assume
\(|F|>D_C+2\). If every target coordinate \(u\) has an address-scale computable
pair \((v_u,w_u)\) for which
\(\widehat C(u,v_u,w_u,\cdot,\cdot,\cdot)\) is nonzero, and the same proof
serialization supplies address-scale field-symbol evaluators for both \(P=p(q)\)
and \(\widehat C\), then \(q(u)\) is computable with \(O(|F|^3)\) such evaluations.

For completeness, enumerate \(a,b,y\in F\). Schwartz--Zippel gives a point outside
the two planes \(Y_2=q(v_u)\), \(Y_3=q(w_u)\) where the constraint polynomial is
nonzero; for the resulting \((a,b)\), at least two \(y\)'s have nonzero
\(\widehat C\)-value. For these points,
\[
 R(y):=\frac{P(u,v_u,w_u,y,a,b)}
             {\widehat C(u,v_u,w_u,y,a,b)}
   =(q(v_u)-a)(q(w_u)-b)(q(u)-y).
\tag{1.90}
\]
Two distinct \(R(y)\)'s recover the multiplicative constant and then \(q(u)\).
The search does not need to know \(q(v_u)\) or \(q(w_u)\): pairs on either bad plane
give identically zero normalized values and are discarded.

Since RW's systematic witness prefix contains the history/output coordinates, this
is an actual auxiliary-to-systematic attachment theorem whenever its three evaluator
conditions hold. It does not assert that published RW supplies them. The remaining
model exits are precisely an object-scale \(\widehat C\) or incidence map, a
serialization that exposes only \(\Pi_{\mathrm{ZOS}}\)/ECC rather than \(P\), or a
non-product relation outside the factorized \(P=p(q)\) interface. See
[note 439](../../../mcsp-hardness-magnification/notes/439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md).

### Proposition 1.59 (Harsha constraint-extension source-interface barrier)

The address-scale evaluator required by Proposition 1.58 is not supplied by the
published RW source interface. Harsha's construction first defines a gate relation
\(C':H^{3m+3}\to\{0,1\}\) and then takes its coordinatewise low-degree extension
\(\widehat C\). Writing \(\ell_h\) for the Lagrange basis of \(H\), every generic
\(\xi\in F^{3m+3}\) satisfies

\[
 \widehat C(\xi)=\sum_{a\in H^{3m+3}}C'(a)
       \prod_{j=1}^{3m+3}\ell_{a_j}(\xi_j).
\tag{1.91}
\]

At a point \(\xi\) outside \(H\) in every coordinate, all weights are nonzero. Hence in
the gate-list black-box model an exact evaluation must inspect every active gate tuple:
changing one unseen tuple changes (1.91) while preserving all queried answers. A
size-\(|C|\) gate list therefore has an \(\Omega(|C|)\) probe lower bound. RW Lemma 3.2
only gives deterministic poly\((t)\)-time construction of \(C_x\), and Theorem 3.5
only fixes the systematic/auxiliary proof decomposition; neither theorem gives a
poly\((\log t)\) weighted gate-sum evaluator for \(\widehat C\).

The output semantics also do not by themselves fix the incidence map required in
Proposition 1.58. Lemma 3.2 says that \(C_x\) checks the `out` field, but the source
does not specify a canonical gate enumeration, the variable-to-\(H^m\) address map, or
a reserved output-gate slot from which an address-scale pair
\(\operatorname{Inc}(u)=(v_u,w_u)\) can be generated. Even if a new layout makes this
pair trivial for the output coordinates, that layout is a new source lemma.

Consequently, Proposition 1.58 can be upgraded to an actual RW closure only after
proving a weighted-sum evaluator and the required output/history layout (together
with \(P\)-segment field-symbol random access). If the construction only scans the
object-scale gate list, it remains an object-scale reconstruction and cannot yield the
\(P/\mathrm{poly}\) final collapse. This is a source-interface barrier, not a general
dPCP/RLDC impossibility theorem and not an unconditional \(P\ne NP\) proof. See
[note 440](../../../mcsp-hardness-magnification/notes/440-harsha-constraint-extension-source-interface-barrier-2026-08-19.md).

### Proposition 1.60 (RW zero-round output-gate closure)

There is a sharper form of the previous interface in the \(P=NP\) deterministic-
recompilation branch. Let \(M\) be the resulting fixed-context machine with \(r=s=0\),
let \(B=M(x_0)\in\{0,1\}^{\ell}\), and let \(C_{x_0}\) be the circuit from Lemma 3.2.
Then \(C_{x_0}\) has only the `out` history variables and accepts exactly when

\[
  \mathrm{out}_j=B_j\qquad (j\in[\ell]).
\tag{1.92}
\]

Suppose a fixed serialization gives, from \(j\) in \(\operatorname{poly}(m)\) time, an
output-gate index tuple \(g_j\in H^{3m}\) and two Boolean patterns
\(\boldsymbol\beta_j^{(0)},\boldsymbol\beta_j^{(1)}\in H^3\) satisfying

\[
 C'(g_j,\boldsymbol\beta_j^{(b)})=1
 \quad\Longleftrightarrow\quad b\ne B_j,
\tag{1.93}
\]

where \(C'\) is Harsha's gate relation. If \(\widehat C\) can be evaluated at these
coordinates in \(\operatorname{poly}(m)\) time, with all evaluator description and
nonuniform parameters included in that size (no message-scale \(B\) advice), then
\(B\in P/\mathrm{poly}\): query
\(\widehat C(g_j,\boldsymbol\beta_j^{(0)})\) and
\(\widehat C(g_j,\boldsymbol\beta_j^{(1)})\), and output the unique Boolean value whose
pattern is not marked invalid.

Indeed, Harsha's extension agrees with \(C'\) on \(H^{3m+3}\), so the two evaluations
are precisely the two values in (1.93). The address circuit for \(g_j\) and the two
field evaluations have polynomial size in \(m\), giving a circuit for every bit of \(B\).
Thus, once \(r=s=0\), the weighted-sum/layout interface of Proposition 1.59 is already
the final Gate-III parent evaluator; it is not an auxiliary preprocessing lemma. If the
gate list can only be scanned at object scale, the \(P/\mathrm{poly}\) collapse remains
unproved. This is a conditional source-specific closure, not a claim that published RW
supplies the layout or an unconditional \(P\ne NP\) theorem. See
[note 441](../../../mcsp-hardness-magnification/notes/441-zero-round-output-gate-closure-2026-08-19.md).

### Proposition 1.61 (RW regular output-gate compiler)

The nonzero output-incidence part required by Proposition 1.58 can be supplied by a
source-compatible representation lemma. In the \(P=NP\) deterministic-recompilation
branch, fix a standard fan-in basis and unroll the resulting \(r=s=0\) machine \(M\) on
the fixed context \(x_0\). Keep the `out` variables as the first \(\ell\) input variables,
append a contiguous block of equality gates \(e_j\) comparing `out_j` with the simulated
output wire \(v_j\), and feed that block into a balanced-AND reduction. The resulting
\(C^{\mathrm{reg}}_{x_0}\) has exactly the same satisfying assignments on the history
prefix as the Lemma 3.2 circuit.

The gate count and all offsets in this compiler are computable from the fixed machine,
the time bound \(t\), and \(j\) in \(\operatorname{poly}(\log t,\ell)\) time. Hence the
three variable indices of \(e_j\), the two Harsha Boolean patterns, and their
\(H^m\simeq[N]\) field coordinates have an address-scale map. The compiler variables are
placed after the history prefix, so lexicographic maximization still selects the same
output \(M(x_0)\). The equality block must be connected to the final AND reduction;
unconnected check gates would not preserve the Lemma 3.2 semantics.

This is a new source-representation/compiler lemma, not a serialization fixed by the
published RW theorem. It supplies the nonzero output-incidence tuple required by
Proposition 1.58 under the stated compiler, but it does **not** make the local equality
pattern reveal \(B_j\): the simulated wire \(v_j\) is itself an unknown witness value.
Thus the remaining actual RW positive target is a same-serialization, non-hidden-advice
evaluator for both \(\widehat C\) and the auxiliary \(P=p(q)\) oracle. A generic
\(\widehat C\)-evaluator alone does not trigger Proposition 1.60 unless the output gate
has \(B_j\) hardwired into its local relation. See
[note 442](../../../mcsp-hardness-magnification/notes/442-rw-regular-output-gate-compiler-2026-08-19.md).

### Proposition 1.62 (offset-regular Harsha generic-point evaluator)

The remaining \(\widehat C\) evaluator has a concrete sufficient source condition. Let
\(H=\{0,\ldots,h-1\}\), \(N=h^m\), and encode variable indices by little-endian
base-\(h\) digits. Suppose the support of the Harsha gate relation \(C'\) is a disjoint
union of \(R\) families

\[
\bigl(\operatorname{enc}_m(z+\delta_1),
      \operatorname{enc}_m(z+\delta_2),
      \operatorname{enc}_m(z+\delta_3),\beta\bigr),
\qquad z\in I,
\]

where the signed offsets, interval boundaries, and family description are
address-succinct, and a deterministic \(s\)-state digit automaton recognizes each
boundary (or the deduplicated union). Then the low-degree extension satisfies, at every
generic \(\xi\in F^{3m+3}\),

\[
\widehat C(\xi)
=\sum_{\tau=1}^{R}
\left(\prod_{q=1}^{3}\ell_{\beta_{\tau,q}}(\eta_q)\right)
e_{\mathrm{start}}^{\mathsf T}
M_{\tau,0}M_{\tau,1}\cdots M_{\tau,m-1}e_{\mathrm{acc}},
\]

where the matrices \(M_{\tau,r}\) are the carry/borrow digit transitions weighted by
the three index-block Lagrange factors. Their construction and multiplication cost
\(O(Rms^2|H|)\) field operations, apart from the \(O(m|H|)\) univariate Lagrange values.
Thus \(R,s,|H|=\operatorname{poly}(m)\) yields an exact
\(\operatorname{poly}(m)=\operatorname{poly}(\log N)\) generic-point evaluator.

The proposition is a finite-state weighted-sum theorem, not a consequence of the
published RW source interface. A cell-time unrolling with local wire offsets would
meet its hypothesis only after a new serialization lemma proves: (i) a
\(\operatorname{poly}(m)\)-family decomposition for every simulation gate, (ii)
address-succinct offset generation and (iii) a finite boundary automaton. C442 supplies
the regular output/equality block, but a heap-numbered balanced-AND tree may instead
require a separate affine-digit transducer lemma. The auxiliary \(P=p(q)\) field-symbol
evaluator and the same-proof serialization are still separate Gate-I/III obligations. See
[note 443](../../../mcsp-hardness-magnification/notes/443-offset-regular-harsha-generic-evaluator-2026-08-19.md).

### Proposition 1.63 (fixed-machine cell-time representation)

The offset-regular hypothesis of Proposition 1.62 is realized by a deliberate
cell-time representation of a fixed finite-state machine. Let \(M\) have constant
alphabet, state set, and local transition gadget. With \(W=O(T+|x|)\) padded cells and
\(L=(T+1)W\), assign every track variable the index

\[
I_\rho(\tau,c)=\rho L+\tau W+c.
\]

For each local gate type, use \(z=\tau W+c\) as the base address. Every variable in
that gate has an index

\[
I_{\rho_j}(\tau+\Delta_{\tau,j},c+\Delta_{c,j})
=z+\bigl(\rho_jL+\Delta_{\tau,j}W+\Delta_{c,j}\bigr),
\]

so the gate support is a constant-size union of offset families with interval boundaries.
Regular initialization, padding, and output-copy constraints preserve this property.
Placing the out variables and simulated output wires on contiguous tracks, then checking
them with contiguous equality gates and a serial AND chain, also gives fixed offsets.
Consequently Proposition 1.62 yields an exact \(\operatorname{poly}(\log N)\)
generic-point evaluator for \(\widehat C\).

This is a new source representation, not a serialization supplied by RW Lemma 3.2.
It applies in the zero-round \(P=NP\) branch only when the fixed machine, source data, and
output reduction are explicitly chosen to satisfy these regularity conditions. Arbitrary
input strings, uncompressed circuit descriptions, heap-numbered balanced trees, and the
auxiliary \(P=p(q)\) field-symbol evaluator remain outside the proposition. See
[note 444](../../../mcsp-hardness-magnification/notes/444-cell-time-offset-regular-rw-unrolling-2026-08-19.md).

### Proposition 1.70 (lex-prefix-preserving local-tableau compiler)

The semantic compatibility of the cell-time representation can also be made explicit.
Let \(C_x\) be the circuit from RW Lemma 3.2, with input ordered as
\(\mathrm{hist}=(y_1,\ldots,y_r,\mathrm{out},z_{1,1},\ldots,z_{r,t})\), and let
\(\alpha_x\) be its lexicographically largest satisfying assignment.  Use the direct
history predicate from the proof of Lemma 3.2: on \((x,\mathrm{hist})\), it simulates
the NP-query computation, checks the accepted-query counts and checks the final
`out` field.  This is not an evaluator that scans an arbitrary gate list for \(C_x\).
There is then a polynomial-size circuit \(D_x(\mathrm{hist},\zeta)\), with hist as its
first input segment, such that

\[
C_x(\mathrm{hist})=1
\quad\Longleftrightarrow\quad
\exists\zeta\;D_x(\mathrm{hist},\zeta)=1,
\tag{1.70}
\]

and the hist projection of the lexicographically largest satisfying assignment of
\(D_x\) is exactly \(\alpha_x\).  The circuit \(D_x\) is obtained by checking a
deterministic computation tableau for the direct hist simulation in Lemma 3.2; it
does not materialize an arbitrary gate list for \(C_x\).  Its local transition,
initialization, boundary, output-copy, and serial-AND checks admit the cell-time
offset-regular serialization of Proposition 1.63 whenever \(x\) is a
regular/address-succinct source.

Consequently, RW Theorem 3.5 can be rerun with \(D_x\): the completeness, soundness
prefix condition, and output block are unchanged up to polynomial circuit-size
overhead.  Under the \(R,s,|H|=\operatorname{poly}(m)\) hypotheses of Proposition
1.62, the resulting constraint extension \(\widehat D\) has an exact
\(\operatorname{poly}(\log N)\) generic-point evaluator.

#### Proof

The auxiliary input \(\zeta\) is a tableau for that deterministic direct-history
predicate.  Fixed local transition gadgets and a serial conjunction accept exactly the
valid accepting tableaux, proving (1.70).  Thus the set of hist strings appearing in
satisfying assignments of \(D_x\) is exactly the set of satisfying assignments of
\(C_x\).  Since hist is the first segment, lexicographic maximization first maximizes
this projection, so it equals \(\alpha_x\); in particular the
\(r'=r\lceil\log(t+1)\rceil\) prefix and the output block are preserved.
The cell-time indexing and offset-regularity are those of Proposition 1.63, and the
Harsha evaluator then follows from Proposition 1.62. \(\square\)

This proposition removes the semantic part of the C444 representation gap, but not
the published-format question or the auxiliary \(P=p(q)\) random-access problem.
The full boundary and parameter accounting are in
[note 453](../../../mcsp-hardness-magnification/notes/453-rw-lex-prefix-preserving-local-tableau-compiler-2026-08-19.md).

### Proposition 1.71 (source-compatible incidence and auxiliary barrier)

The remaining incidence condition in Proposition 1.58 is not an additional
semantic obstacle for the C453 representation.  Append a fresh-variable
output-check block to the hist-first tableau circuit, comparing each out_j with
the deterministic tableau output wire \(\mathrm{sim}_j\), and connect all checks
by a serial AND chain.  For every output coordinate \(j\), choose one local gate
of this fixed nontrivial equality gadget and reorder its three variable indices
as
\[
g_j=(u_j,v_j,w_j),\qquad u_j=\operatorname{index}(\mathrm{out}_j).
\]
There is a fixed Boolean pattern \(\beta^\star\in\{0,1\}^3\subseteq H^3\) that
is invalid for the chosen gate.  Hence
\[
C'_{\mathrm{inc}}(g_j,\beta^\star)=1,
\]
so the corresponding three-variable slice of
\(\widehat D_{\mathrm{inc}}\) is nonzero.  The cell-time layout and fresh
variables make \(j\mapsto(g_j,\beta^\star)\) address-succinct.

Consequently, if the same serialization supplies a generic-point evaluator of
\(\widehat D_{\mathrm{inc}}\) of size \(s_D\) and a field-symbol evaluator of
\(P=p(q)\) of size \(s_P\), with descriptions and nonuniform parameters
independent of \(q\) and containing no message-scale advice, Proposition 1.58
and the C446 expansion give
\[
\operatorname{CC}(B)
\le K(m,|F|)\bigl(s_P+s_D+s_{\mathrm{Inc}}+s_{\mathrm{out}}+1\bigr),
\]
for the zero-round parent \(B=M(x_0)\), with
\(K(m,|F|)=\operatorname{poly}(m,|F|)\).  In particular, when
\(|F|=\operatorname{poly}(m)\) and the C453 layout evaluators are
\(\operatorname{poly}(m)\), a \(\operatorname{poly}(m)\)-size \(P\)-evaluator
would place the forcing-hard parent in \(P/\mathrm{poly}\).

#### Proof

The selected local gate has a fixed invalid Boolean pattern, so Harsha's
definition gives \(C'_{\mathrm{inc}}(g_j,\beta^\star)=1\).  Since the
low-degree extension agrees with \(C'_{\mathrm{inc}}\) on
\(H^{3m+3}\), the slice obtained by fixing \(g_j\) is nonzero.  C453's
cell-time layout and fresh variables make \(g_j\) address-succinct, while the
output-check block forces the systematic coordinate \(u_j\) to equal \(B_j\).
Proposition 1.58 then applies the finite \(O(|F|^3)\) inversion, and circuitizing
the address generation and field arithmetic gives the displayed bound.

This is a source-compatible compiler theorem, not a claim that published RW
fixes this serialization.  It closes the incidence/layout side of the
factorized branch; the remaining positive interface is the \(P\)-segment
random-access evaluator itself.  Full proof and boundary accounting are in
[note 454](../../../mcsp-hardness-magnification/notes/454-rw-source-compatible-incidence-auxiliary-barrier-2026-08-19.md).

### Proposition 1.72 (published RW hard-output forcing scale)

The forcing premise used above can be instantiated on the actual
Ren--Williams AVOID outputs. Let \(A'\) be the smart-\(\mathrm{FP}^{\mathrm{prMA}}/1\)
algorithm from Theorem 4.3 for the truth-table-generator family
\(G_n:\{0,1\}^{n}\to\{0,1\}^{2n}\). There is an infinite set
\(\mathcal I\subseteq\{2^k:k\ge1\}\) such that, for
\[
  B_n=A'(1^n),\qquad N_n=|B_n|=2n,\qquad n=2^k\in\mathcal I,
\]
we have
\[
  B_n\notin\operatorname{Range}(G_n)
  \quad\text{and}\quad
  \operatorname{CC}(B_n)>0.1\,\frac{2^k}{k}
  =\Omega\!\left(\frac{N_n}{\log_2(N_n+2)}\right).
  \tag{1.72P}
\]

#### Proof

Theorem 4.3 supplies \(A'\) and infinitely many good powers of two. In the
proof of Theorem 4.5, Ren--Williams explicitly select infinitely many such \(k\)
for which \(A'(1^{2^k})\) is a truth table of length \(2^{k+1}\) that cannot be
computed by circuits of size \(0.1\cdot2^k/k\). Substituting \(N_n=2^{k+1}=2n\)
gives (1.72P), up to the constant-factor change between \(k\) and
\(\log_2(N_n+2)\). \(\square\)

This is a source-specific parameter instantiation, not an address-scale closure.
It rules out an \(\ell_n^{O(1)}\)-size single-object evaluator on the same
infinite hard-length set, where
\(\ell_n=\lceil\log_2(N_n+1)\rceil\). More generally, if a common-ROM
reconstruction has control size \(p_n\), descriptor length \(d_n\), and at most
\(p_n\) descriptor reads, the ROM expansion gives
\[
  p_n^2+p_nd_n+p_n\ell_n
  =\Omega\!\left(\frac{N_n}{\log N_n}\right).
\]
The \(N_n^{O(1)}\) evaluator supplied by the stable RW solver branch remains
compatible with (1.72P); excluding that branch still requires a genuine
address-scale accessor or a stronger forcing lower bound.  The forcing extraction
alone does not identify the published \(A'\)-output with the source-compatible
zero-round parent used in Proposition 1.71.  Proposition 1.73 supplies that
identification after \(P=NP\) determinization.  The original
paper still does not fix the replacement serialization or supply its auxiliary
random-access evaluator.  The full source and scope statement for the forcing scale is
[note 455](../../../mcsp-hardness-magnification/notes/455-published-rw-hard-output-forcing-scale-2026-08-19.md).

### Proposition 1.73 (published-output source alignment and direct-scale boundary)

Assume \(P=NP\).  For the prMA verifier \(V(q,w;r)\), put

\[
  L_{\rm all}=\{q:\exists w\ \forall r\ V(q,w;r)=1\}.
\]

Then \(L_{\rm all}\in\Sigma_2^P=P\).  On every promised prMA query its
characteristic function equals the oracle answer: perfect completeness gives equality
to one on YES instances, while soundness excludes an all-randomness accepting witness
on NO instances.  Since the Theorem 4.3 algorithm is smart under its correct advice
bit, replacing every oracle call by this fixed P decider preserves every control branch
and output.

Consequently there is one deterministic polynomial-time machine \(M\) such that, on
the regular source

\[
  x_n=(1^n,a_n),
\]

where \(a_n\) is the correct advice bit, the same hard lengths of Proposition 1.72
satisfy

\[
  M(x_n)=A'(1^n,a_n)=B_n.
\tag{1.73P}
\]

Apply Proposition 1.70 to \(M\), using the hist-first cell-time serialization, and
then add the fresh output-check block of Proposition 1.71.  The machine and layout rule
are fixed across lengths, while the unary block plus one advice bit is an
address-succinct source.  Every satisfying history has output block \(B_n\), so its
systematic Harsha polynomial obeys

\[
  q(u_j)=B_n[j]\qquad(j\in[2n]).
\tag{1.74P}
\]

This closes the object and hard-length alignment left open after Proposition 1.72.
It does not produce address-scale random access.  The direct algorithms of Theorem 4.3
run in \(\operatorname{poly}(n)=N_n^{O(1)}\) time, and their induction has
\(s_i=n_i\) and \(r_i=O(n_i)\).  Faithfully expanding their query, witness, and matrix
computations therefore yields only an object-scale surface, which is compatible with
the \(\Omega(N_n/\log N_n)\) forcing bound.  The remaining factorized interface is the
generic-point evaluator for Harsha's auxiliary \(P=p(q)\) on this same serialization.
See [note 456](../../../mcsp-hardness-magnification/notes/456-published-rw-output-source-alignment-and-direct-scale-boundary-2026-08-19.md).

### Proposition 1.74 (generic \(q\)--\(p(q)\) access equivalence)

The remaining auxiliary interface is equivalent to generic access to the assignment
polynomial itself.  Harsha's defining identity is

\[
 P_q(u,v,w,y_1,y_2,y_3)
 =
 \widehat D(u,v,w,y_1,y_2,y_3)
 (q(u)-y_1)(q(v)-y_2)(q(w)-y_3).
\tag{1.75P}
\]

Hence evaluators of sizes \(s_q,s_D\) for generic \(q\)-values and \(\widehat D\)
give

\[
  s_P\le 3s_q+s_D+\operatorname{poly}(m,\log|F|).
\tag{1.76P}
\]

Conversely, under the nonzero-slice incidence of Proposition 1.71 and the field-size
hypothesis of Proposition 1.58, the finite interpolation there gives

\[
  s_q\le O(|F|^3)(s_P+s_D)+\operatorname{poly}(m,|F|).
\tag{1.77P}
\]

Thus, for the standard \(|F|=\operatorname{poly}(m)\) parameters with an
address-scale \(\widehat D\)-evaluator, generic \(P_q\)-access is polynomially
equivalent to generic \(q\)-access.  This does not
construct either accessor from the explicit proof table.  It relocates the remaining
factorized gap: a serialization that exposes only \(H^m\)-systematic symbols, an ECC
image, or an object-scale oracle has not supplied the generic \(q\)-evaluator required
by (1.76P).  Together with (1.74P), either polynomial-size generic accessor would
compute the published \(B_n\) and contradict Proposition 1.72.  See
[note 457](../../../mcsp-hardness-magnification/notes/457-harsha-q-p-generic-access-equivalence-2026-08-19.md).

### Proposition 1.75 (sharp grid-to-generic exact-query lower bound)

Let \(H\subset F\), \(h=|H|\), and let \(q\) range over the full individual-degree
space
\[
  \deg_{X_i}q<h\qquad(i\in[m]).
\]
When an algorithm accesses \(q\) only through the table \(q|_{H^m}\), exact evaluation
at \(x\in F^m\) has deterministic and zero-error randomized query complexity
\[
  h^{k(x)},\qquad k(x)=|\{i:x_i\notin H\}|.
\tag{1.78P}
\]
In particular, \(x\in(F\setminus H)^m\) requires all \(h^m\) grid entries.

Indeed, with the tensor Lagrange basis
\[
  L_u(X)=\prod_{i=1}^m\ell_{u_i}(X_i),
\]
the expansion \(q(x)=\sum_{u\in H^m}q(u)L_u(x)\) has exactly \(h^{k(x)}\)
nonzero coefficients.  This gives the upper bound.  For the lower bound, answer zero
to every query.  If a point \(z\) with \(L_z(x)\ne0\) remains unqueried, the zero
polynomial and \(L_z\) agree on the entire transcript but differ at \(x\).  Every
positive-probability branch of a zero-error algorithm is subject to the same
indistinguishability argument.

Thus the systematic \(H^m\)-symbols in the honest proof do not black-box supply the
generic \(q\)-access required by Proposition 1.74.  Any sub-grid evaluator must use
additional tableau-specific structure; the individual-degree promise alone is
insufficient.  The theorem does not cover total-degree subspaces, bounded-error
approximation, or a structured small circuit for the actual tableau.  See
[note 458](../../../mcsp-hardness-magnification/notes/458-grid-to-generic-exact-query-lower-bound-2026-08-19.md).


### Proposition 1.75A (Harsha assignment specialization of the grid barrier)

Harsha's circuit-algebra source explicitly permits an extension of every assignment
\(A:H^m\to\{0,1\}\subseteq H\) whose degree is at most \(|H|\) in each variable and whose
total degree is at most \(m|H|\) (Section 5.4.1, pp.72--73). Choose instead the standard
tensor-Lagrange representative, whose degree is \(<|H|\) in each variable. It is therefore a
legal subfamily of the Harsha promise, and Proposition 1.75 applies without changing the
Boolean grid values.

Consequently, any exact deterministic or zero-error evaluator that receives only the
systematic table \(q|_{H^m}\) must make \(|H|^{k(x)}\) grid queries to evaluate this
subfamily at \(x\in F^m\), where
\[
 k(x)=|\{i:x_i\notin H\}|.
\tag{1.79P}
\]
At \(x\in(F\setminus H)^m\), this is the entire \(|H|^m\) table. Thus a proposed
address-scale generic evaluator cannot be obtained from the degree promise and systematic
table alone; it must charge an additional tableau-specific representation, descriptor, or
global relation. This source specialization does not apply to a fixed structured tableau
evaluator supplied by other means, and it does not upgrade the statement to a bounded-error
or approximate query lower bound.

### Proposition 1.76 (published RW generic \(q\)-access forcing lower bound)

Under the \(P=NP\) source alignment of Proposition 1.73, keep the
source-compatible output-check serialization and output map of Proposition 1.71.
Let \(E_q\) be a single-valued generic-point evaluator for the honest assignment
polynomial \(q_n\), with all evaluator description and nonuniform parameters charged
to its Boolean size \(s_{q,n}\), and let \(s_{\mathrm{out},n}\) denote the output-address
map size.  Then the systematic-coordinate identity in Proposition 1.73 gives

\[
 \operatorname{CC}(B_n)
 \le
 s_{q,n}+s_{\mathrm{out},n}+\operatorname{poly}(m_n,\log|F_n|),
\tag{1.81P}
\]

Hence C455 implies

\[
 s_{q,n}
 \ge
 \Omega(N_n/\log N_n)-s_{\mathrm{out},n}
 -\operatorname{poly}(m_n,\log|F_n|).
\tag{1.82P}
\]

When the Harsha field parameters and the output map are polylogarithmic in \(N_n\),
every such value evaluator has

\[
 s_{q,n}=\Omega\!\left(\frac{N_n}{\log N_n}\right).
\tag{1.83P}
\]

Thus a Reed--Muller self-corrector with a long proof table as an oracle is not an
address-scale Boolean evaluator.  If the table is supplied as an uncharged ROM, the
interface has entered the common-ROM/model-exit branch of Proposition 1.2 rather than
the claimed \(P/\mathrm{poly}\) closure.  The proposition is conditional on the
source-compatible representation and \(P=NP\) branch; it is not an unconditional
\(P\ne NP\) theorem.

See [note 459](../../../mcsp-hardness-magnification/notes/459-published-rw-generic-q-access-forcing-scale-2026-08-19.md).

### Proposition 1.77 (local constraints do not force an automatic solution)

Offset-regular local constraints and a unique deterministic tableau do not in general
give a small weighted-automaton representation of the satisfying assignment.  There is
a fixed deterministic machine which, on the regular source \(1^{2^{2k}}\), writes the
truth table
\[
  B_k(x,y)=\mathbf 1[x=y],
  \qquad x,y\in\{0,1\}^k,
\tag{1.84P}
\]
in a continuous output block.  Its cell-time tableau has fixed local transitions,
regular boundaries, and a unique accepting assignment.

Write \(m_{\rm addr}\) for the tableau address length (to distinguish it from the
Harsha grid dimension \(m\) used below). Suppose the complete assignment table had an
\(s\)-state weighted representation. Composing it with the regular output-address
transducer costs only \(\operatorname{poly}(m_{\rm addr})\) states. At the cut between
\(x\) and \(y\), the Hankel
matrix of (1.84P) is \(I_{2^k}\).  A weighted automaton with \(s'\) states has Hankel
rank at most \(s'\), while \(\operatorname{rank}_F I_{2^k}=2^k\) over every field.
Since the tableau address length is \(m_{\rm addr}=\Theta(k)\), this forces
\[
  s=2^{\Omega(m_{\rm addr})}.
\tag{1.85P}
\]

Conversely, with \(m\) now denoting the Harsha grid dimension, if \(q|_{H^m}\) has an \(s\)-state representation
\[
q(a_1,\ldots,a_m)=\alpha^\top A_{a_1}\cdots A_{a_m}\beta,
\]
then its low-degree extension satisfies
\[
  q(z)=
  \alpha^\top
  \prod_{i=1}^m
  \left(\sum_{a\in H}\ell_a(z_i)A_a\right)\beta,
\tag{1.86P}
\]
and is generically evaluable in \(\operatorname{poly}(m,|H|,s,\log|F|)\) time.
Thus a polynomial-state representation for the actual Proposition 1.73 assignment
would already be the missing parallelization theorem and would contradict Proposition
1.76.  The small automaton for the constraint extension \(\widehat D\) does not imply
one for its unique solution.  See
[note 460](../../../mcsp-hardness-magnification/notes/460-local-constraint-regularity-does-not-force-solution-automaticity-2026-08-19.md).

### Proposition 1.78 (position-dependent factorized solutions still have exponential cut width)

The conclusion of Proposition 1.77 does not rely on using the same transition matrix at
every address digit. Let an inhomogeneous algebraic branching program for a length-\(r\)
table use matrices
\[
A_{i,a}\in F^{w_{i-1}\times w_i},\qquad
f(z_1,\ldots,z_r)=\alpha^\top A_{1,z_1}\cdots A_{r,z_r}\beta,
\tag{1.87P}
\]
with every \(w_i\le s\). At every cut its prefix--suffix matrix has rank at most \(s\).
For the equality-tableau of Proposition 1.77, suppose the logical output address
\(x\Vert y\) is mapped to the physical address by a \(u\)-state, synchronous,
cut-respecting regular transducer. The product of the transducer and the branching program has middle width at
most \(us\), whereas the middle-cut matrix is \(I_{2^k}\). Hence
\[
us\ge 2^k.
\tag{1.88P}
\]
Since \(m_{\rm addr}=\Theta(k)\), \(u=\operatorname{poly}(m_{\rm addr})\) still forces
\[
s=2^{\Omega(m_{\rm addr})}.
\tag{1.89P}
\]

The same position-dependent representation would nevertheless give a generic evaluator
provided the matrix entries have an address-scale description (under
\(|H|,|F|=\operatorname{poly}(m)\), explicitly listing them costs only
\(\operatorname{poly}(m,s,\log|F|)\) bits):
if \(q|_{H^m}\) has the form (1.87P), then
\[
q(z)=
\alpha^\top
\prod_{i=1}^{m}
\left(\sum_{a\in H}\ell_a(z_i)A_{i,a}\right)
\beta.
\tag{1.90P}
\]
Thus a \(\operatorname{poly}(m)\)-width inhomogeneous ROABP/tensor-train solution is
still the missing generic \(q\)-evaluator and is excluded on the C459 forcing lengths
under the same field/address hypotheses. For an asynchronous address map with only
\(\operatorname{poly}(m_{\rm addr})\) possible physical layers at the logical cut, the
same argument incurs only that polynomial factor. If the matrices are supplied as an uncharged
large ROM, the interface instead enters the common-ROM/model-exit branch of Proposition
1.69. This closes the position-dependent matrix escape but does not cover arbitrary
nonlinear Boolean circuits or irregular, unaccounted address permutations. See
[note 461](../../../mcsp-hardness-magnification/notes/461-inhomogeneous-cut-rank-solution-representations-2026-08-19.md).

### Proposition 1.80 (all-order ROABP barrier from an expander-CNF tableau)

The variable-order escape in Proposition 1.78 can also be removed for read-once
representations. Fix a polynomial-time uniform constant-degree expander family \(G_k\)
with edge expansion \(h>0\), and let
\[
f_k(z)=\bigwedge_{\{u,v\}\in E(G_k)}(z_u\lor z_v).
\tag{1.93P}
\]
A fixed deterministic machine can write the complete truth table of \(f_k\) on input
\(1^{2^k}\) in time \(2^k\operatorname{poly}(k)\), with the same fixed-offset
cell-time tableau interface as Proposition 1.77. For every variable order \(\pi\), a
width-\(s\) inhomogeneous ROABP computing \(f_k\) satisfies
\[
s\ge 2^{\Omega(k)}=2^{\Omega(m_{\rm addr})}.
\tag{1.94P}
\]

Indeed, the balanced prefix cut of any order has \(\Omega(k)\) crossing edges. Bounded
degree permits an induced matching of \(t=\Omega(k)\) such edges. Fixing all other
variables to \(1\) restricts the cut communication matrix to
\[
\left(\begin{smallmatrix}0&1\\1&1\end{smallmatrix}\right)^{\otimes t},
\]
whose rank is \(2^t\) over every field. Prefix--suffix factorization at the ROABP cut
has rank at most \(s\), proving (1.94P). The function \(f_k\) has a small ordinary
Boolean circuit; the proposition is specifically an all-order ROABP/OBDD/tensor-train
barrier, not a general circuit lower bound. With charged matrix descriptions, the
position-dependent tensor-Lagrange formula (1.90P) still gives a generic evaluator, so
C459 excludes polynomial-width solutions in this representation class. See
[note 463](../../../mcsp-hardness-magnification/notes/463-all-order-roabp-expander-tableau-barrier-2026-08-19.md).

### Proposition 1.81 (classical Lagrange sum-check pays proof or transcript scale)

Let \(H\subsetneq F\), \(|H|=h\ge2\), and let \(q\) have individual degree less than \(h\).
For \(u\in F^m\), define
\[
 \lambda_u(T)=\sum_{a\in H}\ell_a(u)\ell_a(T),
 \qquad
 G_{q,u}(X)=q(X)\prod_{i=1}^m\lambda_{u_i}(X_i).
\tag{1.95P}
\]
Then
\[
 q(u)=\sum_{z\in H^m}G_{q,u}(z),
 \qquad \deg_{X_i}G_{q,u}\le d:=2(h-1).
\tag{1.96P}
\]
The standard \(m\)-round sum-check against the common target-independent proof
\(\Pi(q)=q|_{F^m}\) has perfect completeness and, on every word within relative distance
\(\rho\) of \(\Pi(q)\), wrong-claim acceptance at most
\[
 \rho+\frac{md}{|F|}.
\tag{1.97P}
\]
Its per-run verifier makes one final proof query, but its all-challenge reachable address
support is exactly \(F^m\), of size \(P=|F|^m\). The explicit round-polynomial transcript
uses \(m(d+1)\log_2|F|\) bits.

This protocol has a scale obstruction independent of the sufficient bound (1.97P).
Fix all-policy soundness \(\beta<1\) and an off-grid target. If \(d\ge |F|-1\), adding a
multiple of the full-field delta polynomial at one \(a\in H\) to the honest first-round
polynomial changes the claimed sum but is detected only when the first challenge equals
\(a\). Thus wrong-claim acceptance is at least \(1-1/|F|\). It follows that either
\(|F|\le(1-\beta)^{-1}\) or \(|F|\ge d+2=2h\), and in both cases
\(|F|/h\ge c_\beta>1\). Therefore, with \(k=h^m\),
\[
 \frac Pk\ge c_\beta^m.
\tag{1.98P}
\]
For every fixed \(C,D\), the conditions \(P\le k(\log k)^C\) and
\(m(d+1)\log_2|F|\le(\log k)^D\) are consequently incompatible for large \(k\).

In the Harsha regime \(m=\lceil\log N/\log\log N\rceil\), \(h^m=N\), and
\(|F|=\Theta((mh)^3)\), the online transcript is \((12+o(1))(\log_2N)^2\) bits, while
the common proof and all-policy address support have length \(N^{6+o(1)}\). Hence
classical sum-check supplies succinct verification, not the small generic-\(q\) evaluator
required by Proposition 1.76. A new query-succinct information-theoretic polynomial
opening would be a different interface whose proof length, target binding, and soundness
must be charged separately. See
[note 464](../../../mcsp-hardness-magnification/notes/464-classical-lagrange-sumcheck-source-exit-tradeoff-2026-08-19.md).


### Proposition 1.82 (repeated-read nonlinear-memory closure gate)

Let \(H\in\{0,1\}^N\), \(m=\lceil\log_2(N+1)\rceil\), and suppose one common static
descriptor \(\sigma\in\{0,1\}^d\) is used for every address. Consider an address evaluator
with \(T\) explicit transitions, at most \(q\) adaptive reads of bits of \(\sigma\) (repeated
reads allowed), \(s\) arbitrary nonlinear work bits, and a fan-in-two transition circuit of
size at most \(g\) per step. Charging a standard \(d\)-input multiplexer for each ROM read,
and charging any hardwired transition constants to \(g\), unrolling the transitions gives

\[
 \operatorname{CC}(H)\le O(Tg+qd+m+1).
\tag{1.99P}
\]

Consequently, on a forcing length with \(\operatorname{CC}(H)>S\), every such evaluator
must satisfy \(Tg+qd+m+1=\Omega(S)\). Repeated reads and nonlinear state therefore do
not provide a new address-scale escape. The proposition is a singleton, explicit-transition
statement; it does not cover unit-cost uncharged ROM, object-scale transitions, address-
dependent proofs, or arbitrary nonlinear circuits with an uncharged truth table. See
[note 465](../../../mcsp-hardness-magnification/notes/465-repeated-read-nonlinear-memory-closure-gate-2026-08-19.md).

### Proposition 1.83 (bounded writable-RAM closure gate)

Let \(H\in\{0,1\}^N\), \(m=\lceil\log_2(N+1)\rceil\), and let every address use the
same \(w\)-bit target-dependent RAM. The evaluator may perform \(T\) arbitrary nonlinear
transitions and at most \(q\) adaptive single-cell reads/writes, with repeated accesses
allowed. If the fan-in-two control circuit for one transition has size at most \(g\), then
charging a \(w\)-input multiplexer for a read and a \(w\)-cell conditional update for a
write gives

\[
\operatorname{CC}(H)\le O(Tg+q(w+s+m)+m+1).
\tag{1.100P}
\]

Thus a forcing-hard \(H\) requires \(Tg+q(w+s+m)+m+1=\Omega(S)\). In particular, a
same-RAM evaluator with all parameters polynomial in \(m\) cannot exist on the forcing
lengths. This extends Proposition 1.82 from static ROM to mutable memory; it remains a
standard explicit-RAM statement and does not cover unit-cost uncharged memory,
object-scale resources, address-dependent proofs, or arbitrary nonlinear circuits with
an uncharged truth table. See
[note 466](../../../mcsp-hardness-magnification/notes/466-bounded-writable-ram-closure-gate-2026-08-19.md).

### Proposition 1.64 (Harsha auxiliary-oracle entropy transfer)

The \(P=p(q)\) segment cannot be treated as target-independent short advice on a
high-entropy witness family. Fix \(C'\), its low-degree extension \(\widehat C\), an
address-scale incidence map, and a target-independent \(\widehat C\)-evaluator. Let
\(\mathcal Q_N\) be a family of \(K=\log_2|\mathcal Q_N|\) assignment functions on
\(H^m\). Suppose a fixed evaluator architecture of size \(s\), together with a
\(d\)-bit target descriptor \(\sigma_q\), exactly evaluates

\[
P_q=p(\widetilde q)
\]

at all field points used by Proposition 1.58. Under its nondegeneracy and field-size
hypotheses, Proposition 1.58 compiles this into a \(q\)-evaluator of size

\[
S=R(m,|F|)s+\operatorname{poly}(m,|F|).
\]

There are at most
\(2^{d+O(S\log(S+m))}\) such assignment functions: \(2^d\) descriptor choices
times the number of fan-in-two circuits of size \(S\). Hence

\[
K\le d+O\!\left(R(m,|F|)s\log(R(m,|F|)s+m+|F|)\right).
\]

In the standard Harsha regime \(|F|=\operatorname{poly}(m)\), a family with
\(K=\Omega(N)\) cannot have both \(s\) and \(d\) polynomial in \(m\). This is a
Harsha-specific hidden-advice barrier, not a claim about the published RW singleton.
For the singleton \(x_0=0^{n_0}\), the entropy inequality is vacuous; the unresolved
target is then the actual source-specific \(P\)-segment evaluator. See
[note 445](../../../mcsp-hardness-magnification/notes/445-harsha-auxiliary-oracle-entropy-transfer-barrier-2026-08-19.md).

### Proposition 1.65 (Harsha auxiliary-to-systematic circuit-hardness transfer)

The singleton case has a quantitative consequence even without family entropy. Under
the fixed \(\widehat C\)-evaluator, incidence, and nondegeneracy hypotheses of
Proposition 1.58, a generic-point evaluator for \(P=p(q)\) of size \(s_P\) can be
expanded over all \(O(|F|^3)\) field triples to obtain a \(q\)-evaluator of size

\[
K(m,|F|)\bigl(s_P+s_C+s_{\mathrm{Inc}}+1\bigr),
\]

where \(s_C\) and \(s_{\mathrm{Inc}}\) are the sizes of the fixed constraint and
incidence circuits. If the RW parent is a fixed projection \(B_j=q(u_j)\) with
address-map size \(s_{\mathrm{out}}\), then

\[
\operatorname{CC}(B)
\le
K(m,|F|)\bigl(s_P+s_C+s_{\mathrm{Inc}}+s_{\mathrm{out}}+1\bigr).
\]

In the standard Harsha field regime \(|F|=\operatorname{poly}(m)\), a forcing-hard
parent therefore rules out an address-scale \(P\)-evaluator whenever the other three
source circuits are address-scale. The factorized auxiliary branch has a sharp
singleton dichotomy: either \(P\) is short and the parent enters \(P/\mathrm{poly}\), or
the \(P\)-evaluator pays forcing/object scale, or the proposed construction exits the
same-serialization \(P=p(q)\) interface. See
[note 446](../../../mcsp-hardness-magnification/notes/446-harsha-auxiliary-circuit-hardness-transfer-2026-08-19.md).

### Proposition 1.66 (published Harsha/RW source-level closure trichotomy)

The preceding results close the published Harsha source chain into three quantified
branches. With \(m=\lceil\log N/\log\log N\rceil\) and
\(|F|=\Theta((mN^{1/m})^3)\), an explicit \(P\) or
\(\Pi_{\mathrm{ZoS}}\) oracle table has

\[
|F|^{3m+3}=N^{18+o(1)}
\]

field symbols. A factorized \(P=p(q)\) evaluator is subject to Proposition 1.65 and
therefore inherits the forcing hardness of the systematic parent. A compressed oracle
description is subject to Proposition 1.64 for a high-entropy family and to the
finite-ROM forcing bound for the published singleton. Any remaining construction must
leave this published Harsha interface and introduce a genuinely non-product global
relation, with new proofs of same-proof consistency, smartness, cover/bottom safety, and
address-scale generation. See
[note 447](../../../mcsp-hardness-magnification/notes/447-harsha-rw-source-closure-trichotomy-2026-08-19.md).

### Proposition 1.67 (finite-view source-exit bridge)

The source-exit left by Proposition 1.66 is still constrained if it retains a
common proof/address space and a finite visible view. Suppose a non-product global
verifier uses at most \(r\) public random bits, \(t\) observed response bits, \(q\)
proof-symbol queries over a finite alphabet \(\Sigma\), and has target-relative
all-policy soundness with constant gap. Enumerating all visible views gives a
finite-alphabet RLDC with locality

\[
Q_{\mathrm{view}}=1+2q\,2^{r+t}|\Sigma|^q.
\]

Consequently, in any near-linear proof regime where the applicable finite-alphabet RLDC
lower bound holds,

\[
r+t+q\log_2|\Sigma|+\log_2(q+2)
\ge \log_2\log_2 k-\log_2\log_2\log_2 k-O(1).
\]

Thus a source-exit that keeps common-proof semantics must expose growing visible
transcript entropy or pay the corresponding proof/locality/radius cost. A purported
global coupling with neither such payment nor a new soundness quantifier is only a
renaming of the finite-view model. The theorem is the source-specific application of
C268; it does not cover the published singleton or genuinely unbounded interactions.
See [note 448](../../../mcsp-hardness-magnification/notes/448-harsha-source-exit-finite-view-rldc-bridge-2026-08-19.md).

### Proposition 1.68 (finite-state non-product normal form)

The response-bit presentation of Proposition 1.67 is not essential. Suppose that a
non-product verifier keeps the same common proof/address space and target-relative
all-policy soundness, uses \(r\) public random bits and \(q\) proof-symbol queries, and
that, after fixing the public tape, all global-state transcripts visible over all policies
form a set of size at most \(B\). Enumerating these views gives a finite-alphabet RLDC with
locality

\[
  Q_{\mathcal V}=1+2q\,2^r B|\Sigma|^q.
\]

Consequently, in the same near-linear GGS window,

\[
  r+\log_2 B+q\log_2|\Sigma|+\log_2(q+2)
  \ge
  \log_2\log_2 k-
  \log_2\log_2\log_2 k-O(1).
\]

Thus a finite-state global coupling is only a repackaging of the finite-view model. A
genuine source-exit must make the visible state space unbounded, change the physical proof
or address space with the target, or introduce a new soundness quantifier. This is a
finite-state normal form, not an impossibility theorem for arbitrary global relations;
the singleton forcing branch remains governed by C207/C446. See [note 449](../../../mcsp-hardness-magnification/notes/449-finite-state-global-relation-normal-form-2026-08-19.md).

### Proposition 1.69 (scale-complete RW Closure normal form)

Let \(H_N\) be the same forcing-side canonical object, let
\(m_N=\lceil\log_2(N+1)\rceil\), and suppose
\(\operatorname{CC}(H_N)>S_N\) on an infinite set of lengths, with \(S_N\) eventually
larger than every fixed polynomial in \(m_N\). Any proposed \(P=NP\) closure whose
selectors, descriptors, proof/address data, and collapsed queries are charged to the
stated interface falls into the following scale-complete alternatives:

1. A stable solver remains at object scale \(N^{O(1)}\); this is compatible with a
   near-maximum lower bound \(S_N\le N/\operatorname{polylog}N\) and gives no
   contradiction.
2. A single-valued address-scale evaluator uses one fixed advice string and runs in
   \(m_N^{O(1)}\) time; hardwiring that advice gives
   \(\operatorname{CC}(H_N)=m_N^{O(1)}\), contradicting the forcing bound.
3. A common-ROM reconstruction evaluator has control size \(p_N\), descriptor length
   \(d_N\), and at most \(p_N\) descriptor reads. ROM expansion gives
   \[
     \operatorname{CC}(H_N)
     \le O(p_N^2+p_Nd_N+p_Nm_N).
   \]
   Thus a near-maximum hard object forces object-scale descriptor/control payment.
4. A non-product construction still has common proof/address space,
   target-relative all-policy soundness, and at most \(B\) visible global-state
   transcripts after \(r\) public bits and \(q\) proof queries. Then the finite-state
   RLDC compilation of Proposition 1.68 applies, with locality
   \(1+2q2^rB|\Sigma|^q\) and the corresponding transcript-entropy lower bound.

If none of these alternatives applies, the construction has changed a defining resource
or quantifier (common address space, finite visible state, all-policy soundness, gap,
length alignment, or same-object semantics). That is a new model exit, not a free
RW closure. This proposition is a conditional classification and does not prove
\(P\ne NP\).

The proof is the direct combination of the address-scale circuit compilation, the
finite-ROM expansion, and Proposition 1.68. The full statement and cost accounting are
given in [note 450](../../../mcsp-hardness-magnification/notes/450-scale-complete-rw-closure-normal-form-2026-08-19.md).

### Proposition 1.84 (RW singleton common-package Closure trichotomy)

On the infinitely many C455 hard lengths, let \(B_n\) be the same published RW output,
with \(N_n=|B_n|=2n\) and
\(\operatorname{CC}(B_n)=\Omega(N_n/\log N_n)\).  In the \(P=NP\) branch, C456 and
C370 provide a common canonical prefix \(\tau_n\) and a final address-parametrized
Reconf query

\[
B_n[j]=\mathcal Q_n(x_n,\tau_n,j).
\tag{1.101P}
\]

Suppose this semantic factorization is physicalized by one static package
\(\sigma_n\in\{0,1\}^{d_n}\), one evaluator \(E_n(j;\sigma_n,R)\) shared by all
addresses, and a gap \(\gamma_n=\alpha_n-\beta_n>0\) as in (469.3).  If the
post-collapse finite control takes time \(\kappa_n\), makes at most \(b_n\) package
reads, and the standard finite-tape sampling count is

\[
t_n=O\!\left(\frac{m_n+\log(1/\delta_n+2)}{\gamma_n^2}\right),
\qquad m_n=\lceil\log_2(N_n+1)\rceil,
\tag{1.102P}
\]

then

\[
\operatorname{CC}(B_n)
\le
O\!\left(t_n\bigl(\kappa_n+b_nd_n+m_n+\log(t_n+2)\bigr)\right).
\tag{1.103P}
\]

Consequently, an address-scale package with
\(p_n,b_n,d_n,L_n,m_n,\log(1/\gamma_n+2)=m_n^{O(1)}\) and
\(\kappa_n=O(p_nL_n^{c_\star}+p_n^2)\) cannot exist on these lengths.  Any proposed
published-RW Closure must therefore either pay forcing/object scale in its package or
control, lose the common-object/package/address quantifier, let the gap or randomness
leave the finite-tape regime, or introduce a genuinely non-product global relation.
The common canonical witness in (1.101P) does not by itself supply the common selected
response required here: \(\forall j\,\exists C_j\) is outside the proposition.

This is the source-specific instantiation of the static-package closure theorem, not an
unconditional \(P\ne NP\) proof and not a claim that published Reconf already supplies
the package.  See [note 469](../../../mcsp-hardness-magnification/notes/469-rw-singleton-closure-trichotomy-2026-08-19.md).

### Proposition 1.85 (RW singleton short-fingerprint Closure gate)

The family-level short-fingerprint theorem does not automatically close the published RW
singleton. Let \(F_n\) be any target-dependent fingerprint or seed for the same hard output
\(B_n\). If the proposed interface supplies no public target-evaluation map from
\((j,F_n)\) to \(B_n[j]\), then recovering \(F_n\) is only a transcript statistic and does
not produce the address evaluator required by Gate III. If an exact map \(G_n(j,F_n)\) is
supplied, with \(g_n\) gates when \(F\) is treated as an input, hardwiring the true fingerprint
gives

\[
  \operatorname{CC}(B_n)\le g_n+O(\log |B_n|).
\tag{1.104P}
\]

If the map is randomized with a common proof/address space and a fixed gap, then the
finite-tape argument gives the same bound as Proposition 1.84,

\[
  \operatorname{CC}(B_n)
  \le O\!\left(t_n(\kappa_n+b_nd_n+\log |B_n|+\log(t_n+2))\right).
\tag{1.105P}
\]

Hence on C455 hard lengths a fingerprint route either has not supplied Gate III, or its
target-evaluation/control/gap/package resources pay forcing scale, or it changes the
common-proof/target-evaluation quantifier. This is a singleton-specific gate; it does not
invoke the C367 family-level RLDC conclusion. See [note 470](../../../mcsp-hardness-magnification/notes/470-rw-singleton-fingerprint-closure-gate-2026-08-19.md).

### Proposition 1.86 (RW singleton common-proof support forcing gate)

The preceding fingerprint gate does not require a static package if the proposed
attachment has already become a single-valued evaluator on one fixed physical proof.
Let \(z_n\in\Sigma_n^{P_n}\) be that proof, let \(D_n(j;z_n)\) make at most \(q_n\)
adaptive proof queries, and let \(L_n\) be the union of all proof positions reachable over
all addresses and all possible proof-answer paths. If \(g_n\) is the fan-in-two size of
the control/address/output circuit with proof answers treated as abstract inputs, put
\(\ell_n=\lceil\log_2(P_n+1)\rceil\) and \(a_n=\lceil\log_2|\Sigma_n|\rceil\). Then
\[
  \operatorname{CC}(B_n)
  \le O\!\left(g_n+q_nL_n(\ell_n+a_n)+\log(N_n+2)\right).
\tag{1.106P}
\]
Consequently the C455 hard lengths force the right-hand side to be
\(\Omega(N_n/\log N_n)\). Thus an address-scale single-proof evaluator cannot hide its
global state in a small union of proof cells, regardless of whether its internal relation
is finite-state, seed-factorized, or non-product. The randomized fixed-gap version follows
by applying the C470 finite-tape sampler and paying the corresponding tape factor.

The proof hardwires the finitely many true proof symbols in the union support and replaces
each adaptive proof read by an \(L_n\)-way address mux, of size
\(O(L_n(\ell_n+a_n))\). This proposition is a singleton forcing/support gate, not a claim
that published Reconf already supplies \(D_n\): C370/C469 still leave the
\(\forall j\,\exists C_j\) quantifier gap. See [note 471](../../../mcsp-hardness-magnification/notes/471-rw-singleton-proof-support-forcing-gate-2026-08-19.md).

### Proposition 1.87 (RRR16 delegation does not cross the RW logical-scale gate)

Let \(m\) be the logical address length and instantiate the published RRR16
bounded-space delegation construction with a declared, if necessary clock-padded,
object-scale running-time bound

\[
  T_m=2^{\Theta(m)},
  \qquad \log T_m\le S_m=m^{O(1)}.
\tag{1.107P}
\]

Take \(\delta\in(0,1/2)\) in the admissible range of RRR16 and first restrict to
\(1/\delta\in\mathbb N\); rounding changes only constants.

The construction takes \(k=T_m^\delta\). Figure 7, Step 1, sends the low-degree encoding
of \(k-1\) intermediate configurations. For an explicitly padded
\(\Theta(S_m)\)-bit configuration representation, injectivity of the encoding makes this
prover message, and hence total bit communication, at least
\(\Omega(T_m^\delta S_m)\). At the final
level \(i=1/\delta\), Proposition 8.5 of RRR16 gives the construction-level round budget

\[
  \ell_\delta=(c/\delta^2)^{1/\delta}.
\tag{1.108P}
\]

Consequently, \(\ell_\delta=O(1)\) forces \(\delta\ge\delta_0>0\) and an
\(2^{\Omega(m)}\)-bit header. Conversely, a polynomial-in-\(m\) header forces
\(\delta=O(\log m/m)\). If this parameter remains in the admissible range of the
published theorem, then

\[
  \log\ell_\delta
  =\frac1\delta\left(\log c+2\log\frac1\delta\right)
  =\Omega(m),
  \qquad \ell_\delta=2^{\Omega(m)};
\tag{1.109P}
\]

otherwise the theorem is simply unavailable. Thus the RRR16 construction cannot directly
supply both a constant-round and polynomial-message address-scale PH surface for the RW
object-scale computation. The 2025 batching improvement applies only for
\(T(n)\le n^{O(\sqrt{\log n/\log\log n})}=2^{o(n)}\), so it still does not cover
\(T_m=2^{\Theta(m)}\).

Here \(T_m\) is a chosen valid upper bound, not a claimed optimal time lower bound. The
proposition is restricted to direct instantiation of the published RRR16 construction; it
is not a lower bound for all information-theoretic interactive proofs and does not exclude
a new unconditional laconic constant-round protocol. See
[note 472](../../../mcsp-hardness-magnification/notes/472-rrr-constant-round-delegation-logical-scale-gate-2026-08-19.md).

### Proposition 1.88 (honest-path support forcing closes exposed-history PCPP copies)

Let \(z_n\in\Sigma_n^{P_n}\) be one fixed physical proof for the C455 hard output
\(B_n\), and let a deterministic adaptive evaluator \(D_n(j;z_n)\) make at most
\(q_n\) reads. Define \(L_n^{\mathrm{act}}\) as the union, over all output addresses
\(j\), of only the proof positions encountered on the actual executions against \(z_n\);
positions reachable solely under false answer branches are excluded. If \(g_n\) is the
control/address/output circuit size, \(\ell_n=\lceil\log_2(P_n+1)\rceil\), and
\(a_n=\lceil\log_2|\Sigma_n|\rceil\), then

\[
  \operatorname{CC}(B_n)
  \le
  O\!\left(
    g_n+q_n|L_n^{\mathrm{act}}|(\ell_n+a_n)+\log(N_n+2)
  \right).
\tag{1.110P}
\]

Indeed, hardwire the true symbols on \(L_n^{\mathrm{act}}\) and replace each proof read
by a mux over this set. Induction on the query number shows that the simulated address
and answer remain equal to the actual execution, so no false branch is ever needed.
Consequently C455 forces

\[
  |L_n^{\mathrm{act}}|
  =
  \Omega\!\left(
    \frac{N_n/\log N_n-g_n}{q_n(\ell_n+a_n)}
  \right)
\tag{1.111P}
\]

whenever the numerator is positive.

In the exposed-history PCPP+RLDC baseline of note 183, the physical proof contains
\(R_n=\lceil T_n/M_n\rceil\) disjoint copies of an output codeword. Clean-codeword
completeness is exact, so one finite decoder tape can be fixed and (1.111P) applied
separately to every copy. More precisely, fix one decoder tape \(\rho_0\) in its finite
uniform support and one positive-probability honest PCPP tape. For each copy \(s\), use a
full verifier tape with these two components and copy selector \(s\), and define
\(U_n^{\mathrm{act}}\) as the union of the resulting honest executions over all \(s\) and
output addresses. The three randomness components are independently combined in the
note-183 construction, and perfect completeness makes every such execution reach the
selected decoder. Thus the actual decoder support of every copy is contained in
\(U_n^{\mathrm{act}}\). If decoder control, query count, proof-address length, and
alphabet bits are all \(\operatorname{poly}(m_n)\), where
\(m_n=\lceil\log_2(N_n+1)\rceil\), the whole-proof actual support satisfies

\[
  |U_n^{\mathrm{act}}|
  \ge
  \frac{R_nN_n}{\operatorname{poly}(m_n)}
  =
  \frac{R_n\,2^{\Omega(m_n)}}{\operatorname{poly}(m_n)}.
\tag{1.112P}
\]

The common object here is the decoder tape \(\rho_0\), not one whole-verifier tape selecting
all copies; the full tapes differ in their copy selectors.
Thus ordinary exposed-history robust-PCPP composition cannot become an address-scale
support mechanism merely because each execution makes constantly many queries. For a
full code family, the independent injectivity bound
\(|S|\log_2|\Gamma|\ge N_n\) holds for all-branch support; it must not be substituted
for the singleton argument above. The proposition does not cover a new protocol without
explicit coordinate-code copies. See
[note 473](../../../mcsp-hardness-magnification/notes/473-rw-honest-path-support-and-exposed-history-pcpp-gate-2026-08-19.md).

### Proposition 1.89 (coding-layer/address-scale Closure dichotomy)

Let \(B\in\{0,1\}^{N}\), \(m=\lceil\log_2(N+1)\rceil\), and let
\(C:\{0,1\}^{K}\to\Gamma^{P}\) be an injective code. Fix a message \(h\), put
\(z=C(h)\), and let \(\iota:[N]\to[K]\) satisfy

\[
  h_{\iota(j)}=B[j]\qquad(j\in[N]).
\tag{1.113P}
\]

Suppose a clean-codeword decoder, after fixing a finite random tape on which it is exact,
recovers \(h_{\iota(j)}\) using at most \(q\) adaptive reads of \(z\). Let \(g_{\rm dec}\)
include its target map, query-address control, finite-state transitions, output bookkeeping,
and the description and read bits of the fixed tape. If the same fixed codeword has a charged
single-valued address evaluator

\[
  E_z:\{0,1\}^{\lceil\log_2(P+1)\rceil}\to\Gamma
\tag{1.114P}
\]

of circuit size \(s_z\), with all nonuniform advice and alphabet encoding charged to \(s_z\),
then

\[
  \operatorname{CC}(B)
  \le
  O\!\left(
    g_{\rm dec}+q s_z
    +q\bigl(\log(P+2)+\log|\Gamma|\bigr)+\log(N+2)
  \right).
\tag{1.115P}
\]

Consequently, on the C455 published RW hard lengths,

\[
  q_ns_{z,n}+g_{{\rm dec},n}
  +q_n\bigl(\log(P_n+2)+\log|\Gamma_n|\bigr)
  =\Omega\!\left(\frac{N_n}{\log N_n}\right).
\tag{1.116P}
\]

In particular, if \(q_n,g_{{\rm dec},n},\log P_n,\log|\Gamma_n|\) are all
\(\operatorname{polylog}N_n\), then

\[
  s_{z,n}=\Omega\!\left(\frac{N_n}{\operatorname{polylog}N_n}\right).
\tag{1.117P}
\]

#### Proof

Given the \(m\)-bit output address \(j\), run the decoder control to obtain the first
query. Replace every read of a proof symbol by one call to \(E_z\). Inductively, the
simulated answers equal the answers on the fixed clean codeword, so the adaptive query
addresses and the final output agree with the real decoder execution. The resulting circuit
computes \(B[j]\). Each of the at most \(q\) calls costs \(s_z\), and the address/alphabet
bookkeeping costs \(O(\log(P+2)+\log|\Gamma|)\) per call, which proves (1.115P). Combining
it with C455 gives (1.116P)--(1.117P). \(\square\)

This proposition separates three cases that are often conflated. A polylogarithmic
address evaluator for \(z\) is ruled out by (1.117P). Hardwiring all \(P\) symbols, or
supplying them as a charged ROM, pays codeword/object scale. Supplying an uncharged global
ROM or a new joint relation changes the evaluator model and is not a \(P/\mathrm{poly}\)
Closure. Thus the polylogarithmic locality of the near-linear RLCC constructions of
Cohen--Yankovitz and Kumar--Mon is a coding-layer fact, not an RW Gate-I attachment.
The result is a black-box clean-decoder theorem; it is not a general RLCC lower bound or an
unconditional \(P\ne NP\) proof. See [note 474](../../../mcsp-hardness-magnification/notes/474-rw-coding-layer-address-scale-closure-dichotomy-2026-08-19.md).

### Proposition 1.90 (completion-sensitive folding and singleton batch-opening gate)

Let \(F\) be finite and

\[
  L_\alpha(y)=\sum_{i=1}^{b}\lambda_i(\alpha)y_i,
  \qquad \lambda_i(\alpha)\ne0.
\tag{1.118P}
\]

Suppose a deterministic adaptive raw-query tree is exact on a domain
\(\mathcal Y\subseteq F^b\). On an input \(y\in\mathcal Y\), it must query every coordinate
\(k\) for which \(y+\delta e_k\in\mathcal Y\) for some \(\delta\ne0\). Indeed, otherwise
the two executions have identical transcripts and outputs, whereas their correct values differ
by \(\lambda_k(\alpha)\delta\). For a randomized tree with pointwise error at most
\(\varepsilon<1/2\), the same coupling gives query probability at least
\(1-2\varepsilon\) for each such coordinate.

In particular, it suffices that the correctness domain contain the radius-one raw Hamming
ball around the honest vector: then every coordinate has a completion and
\(\mathbb E Q(y^\star)\ge b(1-2\varepsilon)\). A positive-radius ball in the physical proof
implies this premise only if every one-coordinate raw completion is realizable by a proof still
inside the correctness domain; a nonlocal encoding constraint may prevent that projection.
The sharpened singleton statement is recorded in
[note 476](../../../mcsp-hardness-magnification/notes/476-positive-radius-completion-barrier-for-high-arity-folding-2026-08-19.md).

The same coupling quantifies a bottom escape. If the evaluator may output \(\bot\), its
wrong-symbol probability on every completion is at most \(\beta\), and its non-bottom
probability on \(y^\star\) is at least \(\nu\), then every coordinate is queried with
probability at least \(\max\{0,\nu-2\beta\}\). Thus a positive-radius dense fold avoids a
linear raw-query payment only when its bottom mass is large enough to satisfy
\(\nu\le2\beta\), or when the physical radius does not realize raw completions. See
Theorem 476.4 in the linked note.

Consequently, if \(R\) deterministic exact (or zero-error) raw-fold layers have arities
\(b_1,\ldots,b_R\), each layer has this coordinate-completion property, queries at different
layers are charged, and

\[
  \prod_{r=1}^{R}b_r\ge T,
\tag{1.119P}
\]

then

\[
  Q\ge\sum_{r=1}^{R}b_r\ge R\,T^{1/R}.
\tag{1.120P}
\]

For randomized layers with pointwise error at most \(\varepsilon<1/2\), the corresponding
bound is

\[
  \mathbb E Q\ge(1-2\varepsilon)R\,T^{1/R}.
\tag{1.120Pa}
\]

Thus, in the exact/zero-error case, constant \(R\) costs \(T^{\Omega(1)}\); if
\(T=2^{\Theta(m)}\) and
\(Q=m^{O(1)}\), then \(R=\Omega(m/\log m)\). The completion hypothesis is essential:
for the singleton domain \(\mathcal Y=\{0^b\}\), every fold value is zero and no raw query is
needed. Ordinary verifier soundness does not by itself restore the missing local completions.

There is nevertheless a separate singleton gate. If a classical unconditional batch-opening
or folding interface uses one physical proof \(z_n\in\Sigma_n^{P_n}\) and single-valuedly
recovers every address of the C455 hard output \(B_n\), Proposition 1.88 and
\(L_n^{\mathrm{act}}\le P_n\) imply

\[
  g_n+q_nP_n(\ell_n+a_n)+m_n
  =\Omega(N_n/\log N_n).
\tag{1.121P}
\]

If the same proof instead has a charged address evaluator of size \(s_{z,n}\), Proposition 1.89
implies

\[
  g_n+q_ns_{z,n}+q_n(\ell_n+a_n)+m_n
  =\Omega(N_n/\log N_n).
\tag{1.122P}
\]

Hence high arity does not supply a free singleton Closure mechanism: the candidate must pay
forcing-scale physical support/control/alphabet, pay a forcing-scale charged evaluator, retain an
object-scale unpriced oracle, use computational binding, or cease to be same-proof single-valued
all-address recovery. FRI is an interactive oracle proof of proximity and computational polynomial
commitments are different interfaces; this proposition is not a general lower bound for either.
See [note 475](../../../mcsp-hardness-magnification/notes/475-rw-high-arity-folding-quantifier-and-batch-opening-gate-2026-08-19.md).

The formal FRI specialization sharpens this boundary. For a \(2^\eta\)-point fiber, all Lagrange
coefficients are nonzero only when the round challenge lies outside that fiber; a challenge inside
the fiber makes the fold one-hot. More importantly, exact layered-graph completion is a projection
condition on the graph code, not a consequence of physical distance or terminal-code distance.
To invoke the positive-radius barrier, the corresponding graph increment must also lie inside
the physical proof-radius ball and be support-isolated for the target raw transcript.
For disjoint nonzero-coefficient fibers of size at least two, with at least two rounds below the target, sibling
cancellation gives a terminal-zero increment of stored-layer weight at most \(2(i+2)\);
thus a radius \(\rho P\ge2(i+2)\) is already enough for the raw-fiber query lower bound.
Ordinary FRI soundness bounds random-query acceptance and does not supply a target-wise
non-bottom decoder for corrupted committed layers. Recomputing a target fold from its raw fiber
pays the arity bound above; reading a materialized parent requires a separate near-proof
correctness theorem and a charged address mechanism. See
[note 478](../../../mcsp-hardness-magnification/notes/478-fri-fold-graph-local-completion-and-recovery-gate-2026-08-19.md).
More sharply, a materialized-parent read is not a free third branch. If the same proof
single-valuedly produces the published hard word at every address, the raw and parent
cells read on the honest executions obey the C473 ROM bound; if parent cells have a
charged fixed-proof address evaluator, the composition bound of C474 applies instead.
Without that same-proof correctness statement, ordinary FRI acceptance does not provide
the Gate-I attachment. This raw/parent/unbound trichotomy is formalized in
[note 481](../../../mcsp-hardness-magnification/notes/481-rw-materialized-parent-raw-recomputation-trichotomy-2026-08-19.md).
The preceding logical gap is independent: ordinary FRI itself does not publish a
challenge-independent extractor for an external RW target across all addresses. That
common-target extraction interface must be supplied separately, as recorded in
[note 480](../../../mcsp-hardness-magnification/notes/480-ordinary-fri-common-target-extraction-separation-2026-08-19.md).

### Proposition 1.91 (FRI challenge-tree staticization trichotomy)

Let \(N=|L^{(0)}|\), \(M=|F|\), \(b=2^\eta\), and take the standard dyadic FRI
regime \(\rho=2^{-R_\rho}\), \(R_\rho\in\mathbb Z_{\ge0}\),
\(\log_2N\ge R_\rho+\eta\), with
\(r=\lfloor(\log_2N-R_\rho)/\eta\rfloor\). If every challenge-prefix oracle is
materialized verbatim, including the received oracle, then the exact field-symbol cost is

\[
 P_{\rm enum}
 =N+\sum_{i=1}^{r-1}M^i\frac{N}{b^i}+M^r(d+1)
 =N\left[\sum_{i=0}^{r-1}\left(\frac Mb\right)^i
          +\rho\left(\frac Mb\right)^r\right],
 \qquad d+1=\frac{\rho N}{b^r}.
\tag{1.123P}
\]

This is a cost for that representation, not a representation lower bound. For fixed depth
\(i\), retaining the challenges as variables instead gives the linear isomorphism

\[
 F^{L^{(0)}}\cong
 \bigoplus_{y\in L^{(i)}}
 F[X_0,\ldots,X_{i-1}]_{\deg_{X_j}<b},
\tag{1.124P}
\]

so the full-family coefficient table has exactly \(N\) field symbols. A fixed singleton is
not subject to this lower bound: the zero oracle has a constant evaluator for the entire
challenge tree.

For one target at depth \(i\), each of the \(b^i\) base coefficients is nonzero with
probability

\[
 p_{\rm leaf}(i)=\left(1-\frac{b-1}{M}\right)^i,
\tag{1.125P}
\]

whereas all coefficients are simultaneously nonzero with probability

\[
 p_{\rm dense}(i)=\prod_{h=1}^{i}\left(1-\frac{b^h}{M}\right).
\tag{1.126P}
\]

On a completion-rich base family, pointwise error at most \(\varepsilon\) for every fixed
challenge vector implies

\[
 \mathbb E Q\ge(1-2\varepsilon)b^i p_{\rm leaf}(i).
\tag{1.127P}
\]

If instead every base input has joint challenge-and-algorithm error at most \(\varepsilon\),
the lower bound is \(b^i[p_{\rm leaf}(i)-2\varepsilon]_+\). Consequently an FRI-derived
Closure candidate must enumerate the branch tree, retain object-scale symbolic/raw
information, or supply a charged fixed-singleton target evaluator. The final branch reaches
Gate I only after it is composed with a decoder for every address of the same published hard
word.

To prove the proposition, count the nodes at each challenge depth for (1.123P). For
(1.124P), induct on the layers: the \(b\) Lagrange basis polynomials identify the direct sum
of the \(b\) child spaces with the next variable's degree-\(<b\) polynomial space. Along one
root-to-leaf path, a coefficient is a product of \(i\) Lagrange coefficients, which gives
(1.125P); avoiding the full ancestor set at each layer gives (1.126P). Finally, couple the
center input with each one-coordinate completion on the same random tape and sum the query
events. Full details and the parameter boundary are in
[note 479](../../../mcsp-hardness-magnification/notes/479-fri-challenge-tree-staticization-trichotomy-2026-08-19.md).

### Proposition 1.92 (ordinary FRI does not supply common-target extraction)

Fix an ordinary FRI instance \(\mathcal I=(f^{(0)},V,P)\), including its
challenge-dependent prover strategy, and let a challenge-independent package and evaluator
\((S,E)\) be derived only from \(\mathcal I\). Ordinary FRI completeness and proximity
soundness do not imply that \((S,E)\) recovers an external RW target at every address.

Indeed, adjoin to the same \(\mathcal I\) two targets \(A,A'\in\{0,1\}^N\) with
\(A[j_0]\ne A'[j_0]\). The FRI data and all transcript distributions are identical in the two
expanded structures, hence the derived \((S,E)\) is identical; \(E(S,j_0)\) cannot equal both
target bits. Thus the missing Gate-I assumption is not an FRI soundness parameter but a
common-target extraction interface:

\[
 \exists S_n,E_n,\qquad
 |S_n|+\operatorname{size}(E_n)=n^{O(1)},\qquad
 \forall j\in[N_n]\quad E_n(S_n,j)=A_n[j].
\tag{1.128P}
\]

Here \(S_n\) must be published once, be challenge-independent, and arise from the same
FRI/RW attachment; a randomized extractor must admit one tape fixed simultaneously for all
addresses. The weaker quantifier \(\forall j\exists S_{n,j}\), or a common prover strategy
without the target map in (1.128P), does not suffice. Hence the ordinary-FRI black-box route
closes at Gate I; a new construction must either realize (1.128P) or prove that every such
interface pays the forcing scale. See
[note 480](../../../mcsp-hardness-magnification/notes/480-ordinary-fri-common-target-extraction-separation-2026-08-19.md).

### Proposition 1.93 (common-target extractor forcing and static-access normal form)

Let \(B\in\{0,1\}^N\), let \(S\in\{0,1\}^d\) be published once, and let

\[
 E:\{0,1\}^d\times\{0,1\}^{\lceil\log_2(N+1)\rceil}\to\{0,1\}
\tag{1.129P}
\]

be a charged fan-in-two Boolean circuit satisfying

\[
 E(S,j)=B[j]\qquad(\forall j\in[N]).
\tag{1.130P}
\]

After fixing the package inputs to \(S\), the residual circuit \(E|_S\) computes the truth
table \(B\). Consequently

\[
 \operatorname{CC}(B)\le |E|_S\le |E|.
\tag{1.131P}
\]

On the C455 hard lengths this forces

\[
 |E_n|=\Omega(N_n/\log N_n).
\tag{1.132P}
\]

The bound is sharp: take \(S\) empty and \(E\) to be a minimum circuit for \(B\). Thus
(1.130P) alone implies no separate lower bound on \(|S|\); the invariant is the complete
fixed-package address circuit. An explicit finite ROM/RAM implementation compiles through
the honest-path support bound of C473, a charged cell evaluator compiles through C474, and a
mixed raw/materialized implementation compiles through C481. More generally, any
bounded-word finite-time machine with a charged fan-in-two simulation has compilation cost
at least \(\operatorname{CC}(B)\).

The only remaining exits are an unpriced global oracle, cell-probe computation, unbounded or
continuous state that is not compiled into the Boolean model, or a failure of the Gate-I
quantifiers through target-dependent packages, bottom, or non-single-valued output. Hence a
generic RAM/ROM representation cannot be a new Closure mechanism; the next positive target
must be a specific RW-dependent global relation with its Boolean compilation cost exposed.
Published RW/FRI still does not provide the address-scale common extractor in (1.130P), as
localized by Proposition 1.92 and C204/C370. See
[note 482](../../../mcsp-hardness-magnification/notes/482-common-target-extractor-circuit-forcing-normal-form-2026-08-19.md).

### Proposition 1.94 (Harsha ZoS first-division local inverse)

Let \(D=3m+3\) and \(P_0=P=p(q):F^D\to F\). Harsha's canonical
zero-on-subcube proof bundles

\[
 \Pi_{\rm ZoS}(x)
 =
 (P_1(x),\ldots,P_D(x),Q_1(x),\ldots,Q_D(x))
 \in F^{2D},
\tag{1.133P}
\]

where

\[
 P_{i-1}(x)=g_H(x_i)Q_i(x)+P_i(x),
 \qquad
 g_H(T)=\prod_{h\in H}(T-h).
\tag{1.134P}
\]

The first division identity therefore gives the exact pointwise inverse

\[
 P(x)=g_H(x_1)\Pi_{\rm ZoS}(x)[D+1]
      +\Pi_{\rm ZoS}(x)[1].
\tag{1.135P}
\]

Thus one full \(F^{2D}\)-block read, or two flattened component reads, converts exact
arbitrary-point access to the same canonical \(\Pi_{\rm ZoS}\) into exact arbitrary-point
access to \(P\). Apart from the reads, the conversion costs \(O(|H|)\) field operations and
requires no interpolation, division, or additional field-size assumption. In particular,
two exact division-valid bundles that agree as functions have the same \(P\); there is no
honest same-ZoS/different-\(P\) kernel.

Under the incidence, \(\widehat C\)-access, and field-size assumptions of Propositions 1.58
and 1.74, substitute (1.135P) for every \(P\)-query in their \(O(|F|^3)\)-point
enumeration. This yields

\[
 s_q
 \le
 O(|F|^3)
 \left(
   s_{\rm ZoS}+s_{\widehat C}
   +\operatorname{poly}(D,|H|,\log|F|)
 \right),
\tag{1.136P}
\]

and hence exact recovery of each aligned systematic target \(q(u)\). Consequently the
ZoS branch obeys

\[
 \boxed{
 \text{exact canonical point access}\Rightarrow P\text{-access}\Rightarrow q\text{-access};
 \quad
 \text{full table}\Rightarrow\text{object scale};
 \quad
 \text{otherwise access/binding exits}.
 }
\tag{1.137P}
\]

This result is an honest-source identity, not an arbitrary-proof recovery theorem. Harsha
soundness only tests division identities on random lines and does not force an arbitrary
nearby auxiliary oracle to satisfy (1.135P) at every prescribed point. Random-line access
does not give arbitrary-point access; source-compatible raw-binary access is treated by
Proposition 1.95, while an independently defined ECC-only partial view still needs an exact
decoder. Subject to these boundaries, the formerly separate
"expose only \(\Pi_{\rm ZoS}\)" branch of Propositions 1.58--1.59 reduces to the charged
\(P\)-access branch. See
[note 483](../../../mcsp-hardness-magnification/notes/483-harsha-zos-first-division-local-inverse-2026-08-19.md).

**Proof.**  Evaluate (1.134P) at \(i=1\). Since \(P_0=P\), its two right-hand
components are exactly \(\Pi_{\rm ZoS}(x)[D+1]=Q_1(x)\) and
\(\Pi_{\rm ZoS}(x)[1]=P_1(x)\), proving (1.135P). The polynomial \(g_H(x_1)\) is
computed by \(|H|\) subtractions and \(|H|-1\) multiplications, followed by one
multiplication and one addition. If two exact division-valid bundles agree pointwise, the
same identity forces their \(P\)-values to agree pointwise as well.

For the second implication, replace each \(P\)-evaluation in Proposition 1.58 or 1.74 by
(1.135P). One \(\Pi_{\rm ZoS}\) block read costs one full block access (or two component
accesses), and the extra field arithmetic is \(\operatorname{poly}(D,|H|,\log|F|)\).
The \(O(|F|^3)\) finite enumeration and the nondegenerate-incidence/field-size hypotheses
of Proposition 1.58 then give (1.136P). The final three alternatives in (1.137P) are
semantic boundaries: exact canonical point access satisfies the displayed identity,
whereas a full table is object-scale and random-line, unbound ECC-only, or arbitrary
near-proof access does not supply the required exact components. \(\square\)

### Proposition 1.95 (Harsha binary raw-segment local inverse)

Harsha's binary alphabet reduction retains the raw large-alphabet oracle \(\Gamma\) and
augments it with

\[
 \Gamma\circ\Upsilon,
 \qquad
 \Upsilon(i)=\operatorname{ECC}(\Gamma(i));
\tag{1.138P}
\]

it does not replace \(\Gamma\) by its ECC image. On the ZoS oracle type write
\(\Gamma(x)=\Pi_{\rm ZoS}(x)\in F^{2D}\); the \(\widetilde A\) and \(P\) oracles are
separate types and are not used below. Fix the source-compatible serialization of C398 and,
inside the raw ZoS segment, a public component-major flattening of each \(F^{2D}\) symbol.
Let \(D=3m+3\), and set

\[
 \lambda=\lceil\log_2|F|\rceil.
\tag{1.139P}
\]

Suppose the same canonical physical proof has an exact arbitrary-address bit evaluator for
the raw ZoS-\(\Gamma\) segment. At any prescribed \(x\in F^D\), query the public addresses

\[
 (\operatorname{ZoS},x,1,r),
 \quad
 (\operatorname{ZoS},x,D+1,r),
 \qquad r\in[\lambda].
\tag{1.140P}
\]

The resulting \(2\lambda\) bits recover \(P_1(x)\) and \(Q_1(x)\) under the fixed field
encoding. Proposition 1.94 then gives

\[
 P(x)=g_H(x_1)Q_1(x)+P_1(x).
\tag{1.141P}
\]

If the bit evaluator has Boolean circuit size \(s_{\rm bit}\), this construction satisfies

\[
 s_P
 \le
 2\lambda s_{\rm bit}
 +\operatorname{poly}(D,\lambda)
 +O(|H|\mu_F).
\tag{1.142P}
\]

Under the incidence, \(\widehat C\)-access, and field-size hypotheses of Propositions 1.58
and 1.74, it follows that

\[
 s_q
 \le
 O(|F|^3)
 \left(
   2\lambda s_{\rm bit}+s_{\widehat C}
   +\operatorname{poly}(D,|H|,\lambda,\log|F|)
 \right),
\tag{1.143P}
\]

using \(O(|F|^3\lambda)\) physical proof-bit reads. Thus, for the actual Harsha
\(\Gamma\circ\Upsilon\) representation, binary/ECC encoding is not a separate
component-extraction escape. The remaining source interface is exact arbitrary-bit access
to one canonical proof. Random verifier queries do not provide that quantifier.

If one instead deletes raw \(\Gamma\) and retains only a partial view of \(\Upsilon\), ECC
injectivity alone is insufficient. For a same-instance materialization difference space
\(V\), observation map \(O\), and target component \(t\), exact recovery requires
\(\ker(O|_V)\subseteq\ker(t|_V)\). A charged exact decoder or a full efficiently decodable
ECC symbol restores the reduction, whereas an unbound partial view remains an access-model
exit. See
[note 485](../../../mcsp-hardness-magnification/notes/485-harsha-binary-raw-segment-local-inverse-2026-08-19.md).

**Proof.**  The fixed C398/component-major coordinate map locates every bit in (1.140P) using
\(\operatorname{poly}(D,\lambda)\) Boolean control. Exact deserialization gives the two
field components, and (1.141P) is Proposition 1.94. Circuit composition proves (1.142P);
substitution into the \(O(|F|^3)\)-point inversion proves (1.143P). The kernel condition is
necessary because any two allowed materializations with the same observation and different
target values defeat every observation-only decoder. \(\square\)

### Proposition 1.96 (Harsha binary address-scale forcing transfer)

Combine Proposition 1.95 with the circuit-hardness transfer of Proposition 1.65 and the
published-output alignment of Proposition 1.73. On the same \(P=NP\) branch and the same
infinitely-often hard lengths, let
\[
 Q_n=|F_n|,\qquad
 \lambda_n=\lceil\log_2 Q_n\rceil,\qquad
 D_n=3m_n+3.
\tag{1.144P}
\]
Assume that one canonical honest completion \(\Gamma(q_n)\) has a C398/component-major raw
ZoS bit evaluator of size \(s_{{\rm bit},n}\), and that the exact \(\widehat C\)-evaluator,
incidence map, and fully charged output-address map are all bound to the same \(q_n\), where
\(q_n(u_{n,j})=B_n[j]\). Define
\[
 A_n^{\rm dec}
 :=\operatorname{poly}(D_n,\lambda_n)+O(|H_n|\mu_{F_n}),
 \qquad
 R_n:=s_{\widehat C,n}+s_{{\rm Inc},n}+s_{{\rm out},n}+1.
\tag{1.145P}
\]
If \(K(m,Q)\) is the explicit composition polynomial of Proposition 1.65, then
\[
 \operatorname{CC}(B_n)
 \le
 K(m_n,Q_n)
 \left(
   2\lambda_n s_{{\rm bit},n}+A_n^{\rm dec}+R_n
 \right),
\tag{1.146P}
\]
and hence
\[
 s_{{\rm bit},n}
 \ge
 \frac{1}{2\lambda_n}
 \left[
   \frac{\operatorname{CC}(B_n)}{K(m_n,Q_n)}
   -A_n^{\rm dec}-R_n
 \right]_+ .
\tag{1.147P}
\]

If \(\lambda_nK(m_n,Q_n)=\operatorname{polylog}N_n\) and
\(A_n^{\rm dec}+R_n=\operatorname{polylog}N_n\), the C455 forcing term dominates, and
\[
 s_{{\rm bit},n}
 =\Omega\!\left(\frac{N_n}{\operatorname{polylog}N_n}\right).
\tag{1.148P}
\]
Thus an exact arbitrary-bit evaluator for the source-aligned raw ZoS segment cannot itself
be address-scale polylogarithmic. The lower bound is a source-aligned conditional barrier,
not an unconditional \(P\ne NP\) proof. It does not apply to an arbitrary accepted proof:
the bit evaluator must address the same \(\Gamma(q_n)\) whose systematic coordinates equal
the published hard word. ECC-only partial views, arbitrary near proofs, and non-product
global relations remain outside this proposition. See
[note 486](../../../mcsp-hardness-magnification/notes/486-harsha-binary-address-scale-forcing-transfer-2026-08-19.md).

### Proposition 1.97 (JK first-failure frontier-support bound)

Run Ren--Williams Theorem 3.1 on

\[
 G:\{0,1\}^n\to\{0,1\}^{2n},
 \qquad f\in\{0,1\}^{T},
 \qquad k=\left\lceil\log_2(T/n)\right\rceil,
\]

with \(y_k=f0^{n2^k-T}\). If the first non-range block is returned at stage
\(i\in[k]\), then

\[
 \operatorname{CC}(f)
 \le
 O\!\left(
 n2^i+(k-i)(|G|+n)+\log(T+2)
 \right).
\tag{1.149P}
\]

Indeed, every stage \(j>i\) passed all range tests. If \(y_{j-1}\) is the
concatenation of the selected \(n\)-bit preimages, then

\[
 y_j=G^{\oplus 2^{j-1}}(y_{j-1}).
\tag{1.150P}
\]

Given a top address, an \(O(n2^i)\)-size hardwired multiplexer selects its ancestor
\(n\)-bit seed in \(y_i\). The remaining \(k-i\) address bits specify one forward
half-chain; each level uses one copy of \(G\) and an \(n\)-bit half selector. This proves
(1.149P). Lexicographic minimality makes \(y_i\) canonical but is not needed for the
forward recovery.

If the top input is a canonical proof \(\Pi\) containing a hard word \(B\) through a
fixed address map of size \(s_{\rm out}\), the same construction gives

\[
 \operatorname{CC}(B)
 \le
 O\!\left(
 n2^i+(k-i)(|G|+n)+s_{\rm out}+\log(T+2)
 \right).
\tag{1.151P}
\]

Consequently, when the non-frontier terms are smaller than a forcing bound \(S\), a
successful run must expose

\[
 |y_i|=n2^i=\Omega(S),
 \qquad
 i\ge\log_2(S/n)-O(1).
\tag{1.152P}
\]

This separates the two actual JK success interfaces. A returned outsider with its
canonical ancestry is covered by Proposition 1.42's shared half-lift DAG payment. The
complete failure frontier does determine the top proof, but it pays the finite-ROM support
in (1.149P). The published recursion returns one outsider per successful call and supplies
no coupling equation between outsiders from different generators or calls, even when the
calls share the same canonical proof. Thus the actual lex-first recursion does not itself
provide a third, address-scale non-half-lift joint relation.

The forcing specialization (1.151P) requires a separately proved alignment with the same
hard object and length set; an arbitrary Solve parent cannot be identified with the C455
word. The proposition does not exclude a newly proved and fully charged non-product global
relation. See
[note 488](../../../mcsp-hardness-magnification/notes/488-jk-first-failure-frontier-support-bound-2026-08-19.md).

### Proposition 1.98 (JK success-output non-injection)

For \(n\ge 1\), \(k\ge 2\), let

\[
 G_n(u)=0^n u,\qquad u\in\{0,1\}^n,\qquad T=n2^k,\qquad y=1^n0^n.
\]

Partition a length-\(T\) parent string into \(2^{k-1}\) consecutive \(2n\)-bit blocks and
consider the family

\[
 \mathcal F_{n,k}
 =
 \left\{
 y\Vert 0^n v_2\Vert\cdots\Vert 0^n v_{2^{k-1}}
 : v_j\in\{0,1\}^n
 \right\}.
\tag{1.153P}
\]

For every \(f\in\mathcal F_{n,k}\), the Jeřábek--Korten procedure of Ren--Williams
Theorem 3.1 returns the same first-stage outsider \(y\). Indeed, the first block is not
in \(\operatorname{Range}(G_n)=\{0^n v:v\in\{0,1\}^n\}\), while every remaining block
is in that range. Consequently

\[
 |\mathcal F_{n,k}|=2^{n(2^{k-1}-1)}=2^{T/2-n},
\tag{1.154P}
\]

and any common evaluator \(D(j;y,\sigma_f)=f[j]\) for all \(f\in\mathcal F_{n,k}\)
requires an injective descriptor map \(f\mapsto\sigma_f\). A binary descriptor therefore
has length at least \(T/2-n\), and an alphabet-\(\Sigma\) descriptor satisfies

\[
 |\sigma_f|\log_2|\Sigma|\ge T/2-n.
\tag{1.155P}
\]

This is an actual JK family-level non-injection theorem, not merely an abstraction of the
success interface. It rules out treating a generic JK outsider as a parent fingerprint.
It does not transfer automatically to the one fixed parent used at each length in published
RW Theorem 4.3; a singleton closure still needs a parent-specific binding or forcing theorem.
See
[note 489](../../../mcsp-hardness-magnification/notes/489-jk-success-output-noninjection-parent-entropy-barrier-2026-08-19.md).

### Proposition 1.99 (All-stage JK success-fiber entropy boundary)

The non-injection persists at every first-success stage. Fix \(i\in\{1,\ldots,k\}\),
\(T=n2^k\), and \(G_n(u)=0^n u\). At stage \(i\), take a frontier whose first
\(2n\)-bit block is \(y=1^n0^n\) and whose remaining blocks are \(0^nv_j\).
Lift this frontier to the top using the unique range-preimage chain of \(G_n\). The
resulting parent family has size

\[
  2^{n(2^{i-1}-1)}.
\tag{1.156P}
\]

Every member makes the JK procedure pass all range tests above stage \(i\), encounter
the same unique outsider \(y\) at stage \(i\), and return \(y\). Consequently any common
evaluator \(D(j;y,\sigma_f)=f[j]\) over this family requires

\[
  |\sigma_f|\ge n(2^{i-1}-1)
\tag{1.157P}
\]

bits of binary descriptor. At \(i=k\) this recovers Proposition 1.98; at \(i=1\) the
entropy term vanishes and the remaining parent-recovery cost is precisely the forward
frontier support in Proposition 1.97. When \(i=k\) and \(T\) is a power of two, standard
circuit counting further gives a member of the fiber with
\(\operatorname{CC}(f)=\Omega(T/\log T)\).

Thus the actual JK recursion has no free intermediate success interface: exposing the
frontier pays support, while retaining only the outsider pays family entropy. This remains
a family-level statement and does not identify the hard member with the published RW
singleton \(B_n\). See
[note 490](../../../mcsp-hardness-magnification/notes/490-jk-all-stage-success-fiber-entropy-boundary-2026-08-19.md).

### Proposition 1.100 (address-selective prefix-range compiler gate)

Let

\[
 B=B_1\Vert\cdots\Vert B_m,
 \qquad B_j\in\{0,1\}^{2k},
\]

and let \(G_r:\{0,1\}^k\to\{0,1\}^{2k}\), \(r\in[m]\), be computed by one
fully charged circuit

\[
 C_G(r,u)=G_r(u).
\]

Suppose that a second common circuit \(U\) supplies successor seeds satisfying

\[
 G_{j+1}\bigl(U(j+1,j)\bigr)=B_j
 \qquad(j<m).
\tag{1.158P}
\]

Then

\[
 \operatorname{CC}(B)
 \le
 O\!\left(
 |C_G|+|U|+\operatorname{poly}(k,\log(m+2))
 \right).
\tag{1.159P}
\]

To evaluate a global bit address, compute its block index \(j\) and offset \(t\).
For \(j<m\), call \(U(j+1,j)\), evaluate \(C_G\) once, and select output bit \(t\).
For \(j=m\), select the required bit from one hardwired \(2k\)-bit block. Thus the
construction calls \(U\) and \(C_G\) only once per address; its cost does not acquire
an \(m\) factor.

This applies to an address-selective JK scheme that tries to make \(B_r\) the first
non-range block by programming every earlier block into \(\operatorname{Range}(G_r)\):

\[
 \forall j<r\ \exists u_{r,j}:
 \quad G_r(u_{r,j})=B_j,
 \qquad
 B_r\notin\operatorname{Range}(G_r).
\tag{1.160P}
\]

If the scheme uniformly computes these preimages, the diagonal \(r=j+1\) is (1.158P),
so the prefix-range compiler is already a parent evaluator. On a forcing-hard singleton,

\[
 |C_G|+|U|+\operatorname{poly}(k,\log(m+2))
 =\Omega(\operatorname{CC}(B)).
\tag{1.161P}
\]

The uniform seed quantifier is essential. If the seeds only exist pointwise, hardwiring
the diagonal seed table gives only

\[
 \operatorname{CC}(B)
 \le
 O\!\left(
 |C_G|+k(m-1)+\operatorname{poly}(k,\log(m+2))
 \right),
\tag{1.162P}
\]

and the \(k(m-1)\) bits may carry message-scale information. Ren--Williams Theorem 3.1
returns immediately on a non-range block and does not output such a common seed selector.
Per-call generator descriptors, adaptive seed procedures, and fixed ROM access must likewise
be charged through their common address circuits or support.

This is a cross-generator source gate rather than Proposition 1.42's single-generator
half-lift DAG. Its forcing principle is consistent with Propositions 1.86 and 1.93, but
(1.159P) is sharper for this proposed interface because it exposes a one-\(U\), one-\(C_G\)
parent evaluator. Pure range containment, low-complexity parents, and newly proved
non-half-lift relations remain outside the proposition. See
[note 491](../../../mcsp-hardness-magnification/notes/491-jk-address-selective-prefix-range-compiler-gate-2026-08-19.md).

### Proposition 1.101 (uniform JK range-cover selector gate)

Let

\[
 B=B_1\Vert\cdots\Vert B_m,\qquad B_j\in\{0,1\}^{2k},
\]

and let \(G_r:\{0,1\}^{k}\to\{0,1\}^{2k}\), \(r\in[R]\), be computed by one
fully charged circuit \(C_G(r,u)=G_r(u)\). Suppose common circuits
\(\mathsf R(j)\in[R]\) and \(\mathsf U(r,j)\in\{0,1\}^{k}\) satisfy

\[
 G_{\mathsf R(j)}
 \bigl(\mathsf U(\mathsf R(j),j)\bigr)=B_j
 \qquad(j<m).
\tag{1.163P}
\]

Then

\[
 \operatorname{CC}(B)
 \le
 O\!\left(
 |C_G|+|\mathsf R|+|\mathsf U|
 +\operatorname{poly}(k,\log(m+R+2))
 \right).
\tag{1.164P}
\]

Indeed, on a bit address compute its block index \(j\) and offset \(t\). For \(j<m\),
evaluate \(r=\mathsf R(j)\), \(u=\mathsf U(r,j)\), and \(C_G(r,u)\), then select bit
\(t\); for \(j=m\), hardwire the final \(2k\)-bit block. Thus each address uses one
row selector, one seed selector, and one generator evaluation, with no factor \(m\).
If only the pointwise statement

\[
 \forall j<m\ \exists r_j,u_j:
 \quad G_{r_j}(u_j)=B_j
\tag{1.165P}
\]

is available, hardwiring the pair table gives only

\[
 \operatorname{CC}(B)
 \le
 O\!\left(
 |C_G|+(m-1)\bigl(k+\lceil\log_2(R+1)\rceil\bigr)
 +\operatorname{poly}(k,\log(m+R+2))
 \right).
\tag{1.166P}
\]

Consequently, a forcing-hard parent rules out a uniform address-scale row/seed compiler,
but not mere range membership. This strictly contains Proposition 1.100: its diagonal
choice is \(\mathsf R(j)=j+1\). It also covers non-monotone, address-dependent, and set-cover
assignments of JK calls. Ren--Williams Theorem 3.1 fixes one \(G\) per call and returns
on the first outsider; it supplies neither a cross-call \(\mathsf R\) nor a common
\(\mathsf U\). Therefore Proposition 1.101 remains a conditional source gate, not a
published-singleton Closure theorem. See
[note 492](../../../mcsp-hardness-magnification/notes/492-jk-uniform-range-cover-selector-gate-2026-08-19.md).

### Proposition 1.102 (prefix-local JK frontier forcing barrier)

Proposition 1.45 counts the full canonical JK failure frontier. For a published
singleton, suffix failures should not hide the cost of binding the output prefix. Let
\(B=\Pi[1,b]\) be a proof prefix, let \(J_B\) be the contiguous set of \(2k\)-bit
leaves meeting \(B\), and let \(\mathcal F_B\) be the bad leaves and bad-defined
internal nodes whose leaf intervals meet \(J_B\). Use the canonical right inverse
\(p:\operatorname{Range}(G_k)\to\{0,1\}^{k}\), satisfying only
\(G_k(p(z))=z\) on the range. If \(\mathcal T_B\) is obtained by stopping at good
nodes, at leaves, and otherwise recursing only into children meeting \(J_B\), then

\[
|\mathcal T_B|\le 1+(H+1)(|\mathcal F_B|+1),
\tag{1.165Q}
\]

and

\[
\operatorname{CC}(B)
\le
O\!\left(
H C_G\bigl(1+H(|\mathcal F_B|+1)\bigr)
\right),
\qquad
C_G=|G_k|+k+\lceil\log_2(L+2)\rceil .
\tag{1.166Q}
\]

The proof is the same terminal-seed evaluator as Proposition 1.45. Every expanded
undefined node either has an ancestor failure whose interval meets \(J_B\), or crosses
the single prefix boundary; at each depth there is at most one such boundary node.
This gives (1.165Q). A good terminal supplies a \(k\)-bit seed and at most \(H\)
applications of \(z\mapsto G_k(\operatorname{half}_\epsilon z)\); a bad leaf supplies
its \(2k\)-bit payload. Interval comparison and multiplexing give (1.166Q).

Consequently, on a forcing-hard output prefix, a sparse prefix-local frontier is
impossible in the canonical half-lift model. Unlike Proposition 1.41, this statement
does not require a leftmost or contiguous first-failure tie-break. It is still a
fixed-proof counterfactual frontier bound, not a lower bound on the number of queries
exposed by the actual JK execution. A surviving route must either pay the prefix-local
frontier or exhibit a fully charged non-half-lift global relation. See
[note 494](../../../mcsp-hardness-magnification/notes/494-jk-prefix-local-frontier-forcing-barrier-2026-08-19.md).

### Proposition 1.103 (all-stage JK prefix-fiber entropy)

The previous proposition bounds a counterfactual prefix frontier but does not quantify
how much parent information can remain hidden before the actual first failure. The following
explicit family gives the sharp source-level obstruction. Let

\[
 G_n(u)=u\Vert u,\qquad y_n=1^n0^n\notin\operatorname{Range}(G_n),
\]

and fix integers \(k\ge i\ge2\). Set \(m_i=2^{i-1}-1\). For
\(\mathbf u=(u_1,\ldots,u_{m_i})\in(\{0,1\}^n)^{m_i}\), form the stage-\(i\) string

\[
 Y_i(\mathbf u)
 =
 (u_1\Vert u_1)\Vert\cdots\Vert(u_{m_i}\Vert u_{m_i})\Vert y_n.
\tag{1.167P}
\]

Apply \(G_n\) independently to every \(n\)-bit chunk \(k-i\) times, obtaining a
truth table \(F_{\mathbf u}\) of length \(T=n2^k\). JK passes every stage above \(i\),
then has a unique non-range block at stage \(i\), namely the last block \(y_n\).
Consequently the complete first-failure transcript
\[
(\mathrm{hard},i,2^{i-1},y_n)
\tag{1.168P}
\]
is independent of \(\mathbf u\). Nevertheless, the contiguous prefix of \(F_{\mathbf u}\)
ending immediately before the ancestor interval of that last block has length
\[
2n\,m_i\,2^{k-i}
\]
and takes \(2^{nm_i}=2^{n(2^{i-1}-1)}\) distinct values.

Hence any single-valued parent decoder using this fixed transcript and a binary
side-information string of maximum length \(d\) must satisfy
\[
d\ge n(2^{i-1}-1).
\tag{1.169P}
\]
Position, stage, and binary ancestry directions do not contribute to this payment; exposing
the successful canonical preimages does. The construction is tie-break independent because
the outsider is unique.

Proposition 1.103 is a family-level source barrier, not a claim that the family belongs to
the Ren--Williams canonical PCP image. In the \(P=NP\) zero-round systematic serialization,
any proposed RW-specific attachment must therefore either prove that the canonical proof image
avoids this prefix-fiber, or provide a selector/global relation whose information and circuit
cost are explicitly charged. The proposition does not by itself imply \(P\ne NP\). See
[note 496](../../../mcsp-hardness-magnification/notes/496-jk-all-stage-prefix-fiber-entropy-barrier-2026-08-19.md).

### Proposition 1.104 (canonical-liftable range projection)

Proposition 1.103 does not rely on the literal duplication map except for its
canonical-liftability. We state the corresponding generator-specific form. Let
\(G:\{0,1\}^n\to\{0,1\}^{2n}\), \(R=\operatorname{Range}(G)\), and fix a canonical
right inverse \(p:R\to\{0,1\}^n\). Define

\[
\Gamma_0=\{u:p(G(u))=u\},\qquad
\Gamma_{d+1}=
\{u\in\Gamma_0:\operatorname{left}(G(u)),
\operatorname{right}(G(u))\in\Gamma_d\}.
\tag{1.170P}
\]

Let
\[
\mathcal Z_d=\{z\in R:
\operatorname{left}(z),\operatorname{right}(z)\in\Gamma_d\},
\qquad
\widehat{\mathcal Z}_d=\{\mathsf L_G^d(z):z\in\mathcal Z_d\},
\qquad
M_d=|\widehat{\mathcal Z}_d|,
\tag{1.171P}
\]
where \(\mathsf L_G\) applies \(G\) to each \(n\)-bit chunk. If there exists an outsider
\(y\notin R\) whose two halves also lie in \(\Gamma_d\), then for every \(k\ge i\ge2\)
the first-failure construction with \(m_i=2^{i-1}-1\) preceding blocks has a fixed
transcript but at least \(M_{k-i}^{m_i}\) distinct contiguous prefix values. Consequently,
any exact binary descriptor for that family has length
\[
d\ge(2^{i-1}-1)\log_2 M_{k-i}.
\tag{1.172P}
\]

The proof is a direct canonical-lift induction: membership in \(\Gamma_d\) guarantees
that every higher range test returns the intended chunk, while the fixed outsider is the
unique failure at stage \(i\). The \(m_i\) lifted preceding blocks occur in order in the
top prefix, so their product fiber has size \(M_{k-i}^{m_i}\).

For \(G(u)=u\Vert u\), \(M_d=2^n\), recovering Proposition 1.103. For the published truth-table generator, C499 proves the sharper identity
\(M_d=|\Gamma_{d+1}|\). Thus the remaining source-specific gate is a lower bound on the
canonical-liftable seed set \(\Gamma_{d+1}\) for the same generator and proof
serialization; a small \(M_d\) is not a lift-collision escape and must be supplemented
by a separately charged global relation. This proposition remains a family-level
descriptor barrier and does not by itself imply \(P\ne NP\). See
[note 497](../../../mcsp-hardness-magnification/notes/497-jk-canonical-liftable-range-projection-barrier-2026-08-19.md).
The identity \(M_d=|\Gamma_{d+1}|\) is proved in
[note 499](../../../mcsp-hardness-magnification/notes/499-jk-canonical-lift-injectivity-eliminates-collision-branch-2026-08-19.md).

### Proposition 1.105 (canonical-lift phase diagram)

The quantities in Proposition 1.104 satisfy an exact recurrence. C499 sharpens the
lift-image estimate: the canonical lift is injective on every \(\mathcal Z_d\). Write
\[
s_d=|\Gamma_d|,\quad z_d=|\mathcal Z_d|,\quad
o_d=|\mathcal O_d|,\quad m_d=|\widehat{\mathcal Z}_d|.
\]
Then
\[
z_d=s_{d+1},\qquad o_d=s_d^2-s_{d+1},\qquad m_d=s_{d+1}.
\tag{1.173P}
\]
Indeed, \(u\mapsto G(u)\) is a bijection from \(\Gamma_{d+1}\) to \(\mathcal Z_d\)
because \(p(G(u))=u\). The strings whose two halves lie in \(\Gamma_d\) split
disjointly into \(\mathcal Z_d\) and \(\mathcal O_d\), giving the second identity.

For a stage pair \(k\ge i\ge2\), put \(d=k-i\), \(m_i=2^{i-1}-1\), and let \(Q_{k,i}\) be the charged binary descriptor budget. The relevant C497 payment is

\[
\Delta_{k,i}:=m_i\log_2 s_{d+1}.
\tag{1.174P}
\]

Thus the quantitative regimes are: if \(o_d=0\), then \(s_d^2=s_{d+1}\le2^n\), so \(s_d\le2^{n/2}\). If \(o_d>0\) and \(\Delta_{k,i}>Q_{k,i}\), Proposition 1.104 exceeds the descriptor budget. If \(o_d>0\) but \(\Delta_{k,i}\le Q_{k,i}\), the case remains open at this budget; C499 rules out lift-collision, so any remaining route must use a separately charged global relation or leave the canonical half-lift model. In particular,
\[
\kappa_d:=\log_2(s_{d+1}/m_d)=0
\tag{1.175P}
\]
whenever \(\mathcal Z_d\ne\varnothing\). The phase diagram is a source-specific family theorem and does not
by itself imply \(P\ne NP\). See
[note 498](../../../mcsp-hardness-magnification/notes/498-jk-canonical-lift-phase-diagram-2026-08-19.md).
The injectivity correction and its proof are given in
[note 499](../../../mcsp-hardness-magnification/notes/499-jk-canonical-lift-injectivity-eliminates-collision-branch-2026-08-19.md).

### Proposition 1.106 (sentinel-padded universal canonical phase)

The encoding gate in Proposition 1.105 can be removed for a deliberately chosen
Ren--Williams AVOID family. Let \(n=2^k\), let
\(r_n=2\lceil\log_2(n+2)\rceil\), and fix a standard gate-list universal evaluator
\(U_n:\{0,1\}^{n-r_n}\to\{0,1\}^{2n}\) for \((k+1)\)-input circuits. Define
\[
\mathcal U_n=\{1^{r_n}v:v\in\{0,1\}^{n-r_n}\},\qquad
\mathcal S_n=\{0,1\}^{n}\setminus\mathcal U_n
\]
and
\[
G_n^\star(u)=
\begin{cases}
u\Vert u,&u\in\mathcal S_n,\\
U_n(v),&u=1^{r_n}v\in\mathcal U_n.
\end{cases}
\tag{1.176P}
\]
Invalid universal descriptions are mapped to \(0^{2n}\). The evaluator and the
prefix test are P-uniform and have size \(O(n^4)\), so \(G_n^\star\) is an admissible
Theorem 4.3 AVOID family.

There is a constant \(\eta>0\) such that every \(2n\)-bit truth table of circuit
complexity at most \(\lfloor\eta n/k\rfloor\) lies in
\(\operatorname{Range}(G_n^\star)\). Hence every outsider has complexity
\(\Omega(n/\log n)\). Moreover, for the lexicographically smallest right inverse,
\[
\mathcal S_n\subseteq\Gamma_d^\star
\quad(d\ge0),\qquad
|\Gamma_d^\star|\ge 2^n-2^{n-r_n}.
\tag{1.177P}
\]
Consequently \(\mathcal O_d^\star\ne\varnothing\) at every depth and
\[
\Delta_{k,i}\ge
(2^{i-1}-1)\log_2(2^n-2^{n-r_n})
\ge (2^{i-1}-1)(n-1).
\tag{1.178P}
\]

The range statement follows by padding the description of a circuit of size
\(O(n/k)\) into the \(n-r_n\)-bit universal branch. For \(u\in\mathcal S_n\),
the output \(u\Vert u\) has no other structured preimage and every universal
preimage is lexicographically larger, so \(p(G_n^\star(u))=u\). Induction on
\(d\) gives (1.177P); Proposition 1.105 and the injectivity correction then give
(1.178P). This family removes the encoding ambiguity of C500, but it is a chosen
source family rather than the underspecified raw published encoding. See
[note 501](../../../mcsp-hardness-magnification/notes/501-sentinel-padded-truth-table-generator-canonical-gamma-closure-2026-08-19.md).

### Proposition 1.107 (hard-child / parent-binding separation)

For the family \(G_n^\star\) of Proposition 1.106, every depth \(d\) contains an
outsider \(y_{n,d}\in\mathcal O_d^\star\) with
\[
\operatorname{CC}(y_{n,d})=\Omega(n/\log n).
\tag{1.179P}
\]
Fix this same outsider, and let \(m_i=2^{i-1}-1\). For every tuple
\(\mathbf u\in\mathcal S_n^{m_i}\), place the structured blocks
\(u_j\Vert u_j\) before \(y_{n,d}\) at stage \(i\), and lift \(d=k-i\) levels.
All resulting parents have the identical transcript
\[
(\mathrm{hard},i,2^{i-1},y_{n,d}),
\tag{1.180P}
\]
but their prefix fiber has size
\[
|\mathcal S_n|^{m_i},
\]
so any exact family-level parent-binding descriptor has length at least
\[
(2^{i-1}-1)(n-1).
\tag{1.181P}
\]
At \(i=k\), the parent length is \(T=n2^k\), the fiber has size
\(2^{(1-o(1))T/2}\), and a counting argument gives a member of complexity
\(\Omega(T/\log T)\).

Thus a hard success outsider is not a parent fingerprint, even when the canonical
\(\Gamma_d\) reservoir is \(1-o(1)\) of the entire seed space. This is a family-level
semantic separation: it does not assert that the actual Ren--Williams singleton PCP
proof lies in this fiber. A singleton closure must still supply a uniform parent-binding
relation or pay the forcing-scale descriptor cost. See
[note 502](../../../mcsp-hardness-magnification/notes/502-sentinel-hard-outsider-parent-binding-separation-2026-08-19.md).

### Proposition 1.108 (black-box JK transcript-binding impossibility)

The C502 separation can be stated as a compiler-level impossibility. Let
\(n=2^k\), \(m=2^{k-1}-1\), \(T=n2^k\), and use the sentinel-padded generator
\(G_n^\star\) of Proposition 1.106. Since
\(|\mathcal S_n|^2>2^n\), choose
\[
y_n=a\Vert b\notin\operatorname{Range}(G_n^\star),
\qquad a,b\in\mathcal S_n.
\tag{1.182P}
\]
For each \(\mathbf u\in\mathcal S_n^m\), set
\[
F_{\mathbf u}:=(u_1\Vert u_1)\Vert\cdots\Vert
(u_m\Vert u_m)\Vert y_n.
\tag{1.183P}
\]
At the top JK stage, every \(F_{\mathbf u}\) has the identical transcript
\[
\tau_n^\star=(\mathrm{hard},k,2^{k-1},y_n),
\tag{1.184P}
\]
and
\[
|\{F_{\mathbf u}:\mathbf u\in\mathcal S_n^m\}|
=|\mathcal S_n|^m
\ge 2^{(2^{k-1}-1)(n-1)}
=2^{(1-o(1))T/2}.
\tag{1.185P}
\]
The fiber contains a parent of complexity
\(\Omega(T/\log T)\).

More generally, let \(E_n\) be any fixed binder whose only
parent-dependent input is a \(d\)-bit descriptor \(s\), so that
\[
E_n(G_n^\star,\tau_n^\star,s_{\mathbf u},j)=F_{\mathbf u}[j]
\qquad(j\in[T]).
\tag{1.186P}
\]
Then
\[
d\ge\log_2|\mathcal S_n|^m
\ge(2^{k-1}-1)(n-1)
= (1-o(1))T/2.
\tag{1.187P}
\]
If the descriptor is shared across the fiber, exact binding is impossible.

The proof is injectivity: with \(G_n^\star\) and \(\tau_n^\star\) fixed, one
descriptor induces one complete address word, so two distinct parents cannot share it.
The hard-parent assertion is the standard circuit-counting argument on a fiber of
size \(2^{(1-o(1))T/2}\). This is a black-box theorem for the JK transcript interface,
not a statement that the particular single table \(f_i(x_0)\) in Theorem 4.3 ranges
over this fiber. Consequently an actual RW closure must add a source-specific
restriction on \(f_i(x_0)\), a new global relation, or an explicitly object-scale
descriptor. See [note 503](../../../mcsp-hardness-magnification/notes/503-jk-black-box-transcript-binding-impossibility-2026-08-19.md).

### Proposition 1.109 (RW Closure quantifier-pinning trilemma)

The preceding barriers pin down the quantifiers of any remaining positive Closure.
Let \(B_m\) be the same Ren--Williams hard table of length
\(N_m=2^{\Theta(m)}\), and suppose a proposed interface claims an
\(m^{O(1)}\)-size, single-valued, same-object address evaluator under \(P=NP\).
Three natural extensions are separately unavailable:

1. If the evaluator works for every succinct seed generator, Proposition 1.6
   (C429) yields \(\mathrm{EXP}\subseteq\mathrm{P/poly}\), which is incompatible
   with \(P=NP\) by the Karp--Lipton/Meyer collapse and the time hierarchy theorem.
2. If it works for every input \(x\) of the fixed source machine, Proposition 1.51
   (C431) gives \(P=NP\Rightarrow E=P\), again impossible.
3. If it fixes \(G\) but works for every parent consistent with one hard
   JK transcript, Proposition 1.108 (C503) forces a
   \((1-o(1))T/2\)-bit parent descriptor, or makes exact binding impossible when
   the descriptor is shared.

Consequently any surviving RW Closure must simultaneously fix a source input
\(x_0\), a source-compatible canonical seed subclass, and the actual parent
\(f_i(x_0)\), while adding a new transcript-external global relation whose
parent-dependent state is explicitly charged at address scale. This is a
quantifier classification, not an impossibility theorem for that remaining
singleton-specific relation and not a proof of \(P\ne NP\). See
[note 504](../../../mcsp-hardness-magnification/notes/504-rw-closure-quantifier-pinning-trilemma-2026-08-19.md).

### Proposition 1.110 (fixed-\(x_0\) Harsha \(P\)-segment closure trichotomy)

The remaining Harsha auxiliary segment does not provide a fourth address-scale
escape. Work on the same \(P=NP\) branch, source-compatible serialization, hard
output \(B_n\), and infinite hard-length set as in Propositions 1.73 and 1.95--1.96.
Let \(q_n\) be the systematic low-degree assignment with
\[
q_n(u_{n,j})=B_n[j],\qquad j\in[N_n].
\tag{1.188P}
\]
Let \(P_{q_n}=p(q_n)\) be Harsha's polynomial from (5.7). Suppose the common
serialization has the nondegenerate incidence and \(\widehat C\)-evaluation of
Proposition 1.71. If an exact generic field-symbol evaluator for \(P_{q_n}\) has
size \(s_{P,n}\), and its target-dependent descriptor has length \(d_n\), then
\[
\operatorname{CC}(B_n)
\le K(m_n,|F_n|)
\bigl(s_{P,n}+d_n+s_{C,n}+s_{\mathrm{Inc},n}
      +s_{\mathrm{out},n}+1\bigr),
\tag{1.189P}
\]
where \(K\) is polynomial in \(m_n\) and \(|F_n|\). Consequently, in the Harsha
parameter window \(m_n,|F_n|=\operatorname{polylog}N_n\), C455 forces
\[
s_{P,n}+d_n
=\Omega\!\left(\frac{N_n}{\operatorname{polylog}N_n}\right)
\tag{1.190P}
\]
whenever the constraint, incidence, and output maps are address-scale.

Indeed, Harsha's identity
\[
p(q)(u,v,w,y_1,y_2,y_3)
=\widehat C(u,v,w,y_1,y_2,y_3)
  \prod_{r=1}^{3}(q(u_r)-y_r)
\tag{1.191P}
\]
and the two-point normalization of Proposition 1.58 recover \(q_n(u)\) from
\(O(|F_n|^3)\) calls to the \(P\)- and \(\widehat C\)-evaluators. Hardwiring the
descriptor costs \(d_n\); composing with the output map in (1.188P) gives (1.189P).

There are therefore only three source-level cases. A short generic \(P\)-evaluator
would contradict the same \(B_n\) lower bound; a systematic-grid-only representation
is object-scale by Proposition 1.75A; and a representation that changes the
factorization, proof quantifier, or exact off-grid semantics has exited the Harsha
interface and must supply a new non-product global relation. Local offset-regularity
of the constraint tableau alone does not create the missing generic assignment
evaluator (Proposition 1.77). This proposition closes the fixed-\(x_0\) Harsha
\(P\)-segment attack; it is not an unconditional proof of \(P\ne NP\). See
[note 505](../../../mcsp-hardness-magnification/notes/505-fixed-x0-harsha-p-segment-closure-trichotomy-2026-08-19.md).

### Proposition 1.111 (arbitrary-interval JK frontier forcing)

Proposition 1.102 is stated for a proof prefix, whereas the output bits in
Ren--Williams Theorem 3.5 occupy the middle interval
\((r'+1,\ldots,r'+\ell)\) of the canonical witness. The same argument works for any
contiguous physical interval. Let \(\Pi^+\) be a fixed binary proof padded and partitioned
into \(2^H\) consecutive \(2k\)-bit leaves, let \(I=[a,b]\) be a nonempty bit interval,
and let \(J_I\) be the leaf interval meeting \(I\). With the canonical right inverse
\(p:\operatorname{Range}(G)\to\{0,1\}^k\), define \(\mathcal F_I\) to be the bad leaves
and bad-defined internal nodes whose leaf intervals meet \(J_I\). The local decomposition
that stops at good nodes and leaves and recurses only into children meeting \(J_I\) has
\[
|\mathcal T_I|\le 1+(H+1)(|\mathcal F_I|+2).
\tag{1.192P}
\]
Consequently, with
\[
C_G=|G|+k+\lceil\log_2(|\Pi^+|+2)\rceil,
\]
there is an address circuit for the same physical substring satisfying
\[
\operatorname{CC}(\Pi^+[a..b])
\le
O\!\left(HC_G\bigl(1+H(|\mathcal F_I|+2)\bigr)\right).
\tag{1.193P}
\]

The proof is the C494 terminal-seed evaluator. A fixed failure can have at most \(H+1\)
ancestors, while a failure outside \(J_I\) can be charged only to a node crossing the
left or right boundary; there are at most two such nodes per depth. A good terminal is
expanded by at most \(H\) canonical half-lifts, and a leaf terminal is hardwired. Therefore
an output interval with circuit complexity at least \(S\) forces
\[
|\mathcal F_I|=\Omega\!\left(\frac{S}{H^2C_G}\right)-O(1).
\tag{1.194P}
\]

If the published RW proof uses a fully charged source-compatible binary/systematic
serialization in which the honest witness assignment and the
\((r'+1,\ldots,r'+\ell)\) output segment are physical contiguous bits, Proposition 1.111
applies to that output segment. This is still a fixed-proof counterfactual frontier bound:
Theorem 3.5 decoded low-degree coordinates on arbitrary near proofs do not automatically
constitute physical raw neighbors. A decoded-domain-only or nonlocal construction must
provide a separate raw-to-decoded binding and is outside (1.193P). See
[note 511](../../../mcsp-hardness-magnification/notes/511-jk-arbitrary-interval-frontier-forcing-2026-08-19.md).

## 2. The three independent gates

### Gate I: RW attachment

The actual RW-dependent canonical history must be connected to one address-scale query
procedure. Uniform generation is not needed for the final \(P/\mathrm{poly}\) contradiction,
but is needed if the stronger target is a uniform \(P\) evaluator.
Recompiling a PCP for each coordinate, choosing a different Merlin strategy per address, or
searching a full (q_n\)-scale table does not satisfy the theorem.

### Gate II: escape classification

The construction must either rule out bottom, bind a cover sheet, or prove that any descriptor,
private patch, and large support incurs a cost already captured by a relaxed-LDC/LDC or entropy
barrier. Ordinary list soundness and the quantifier
\(\forall a\,\exists w_a\) are insufficient because they allow phantom witnesses that vary
with the address.

The ordinary succinct-PCP/PCA literature does not discharge this gate: the former
triggers the Fortnow--Santhanam compression boundary, while the latter weakens
soundness to efficiently generated false proofs and introduces CRS-dependent
semantics. Thus the remaining Gate-I target is explicitly RW-specific rather than
an import of a generic short-proof theorem.

### Gate III: final collapse

The circuit lower bound, the (P=NP) determinization, the canonical history, and the length
set must refer to the same object. An (E^{NP}) outsider or a procedure polynomial in the
full history length does not by itself imply a (P/\mathrm{poly}) contradiction.

## 3. Relation to the other papers

Paper 01 explains why a family-level positive-radius shared proof faces relaxed-LDC and
bottom-or-cubic barriers. Paper 02 identifies the global-word quantifier needed before
distributional soundness can enter that route. Paper 03 closes a concrete cover-based escape
for the BMVY/DDL source. The present theorem is the final conditional interface: it states what
would remain once the RW-specific attachment and escape gates are actually proved.

## 4. Status and non-claims

The theorem is a conditional closure theorem, not a proof that the RW/JK construction satisfies
assumptions 1--6. The current project has not proved (P\ne NP). The contribution is to make
the final implication self-contained and to prevent three distinct unresolved problems from
being conflated into one informal “smart reconstruction” claim.

## References

- Ren and Williams, *Near-Maximum Circuit Lower Bounds for Exponential Time with Merlin-Arthur
  Queries*, ECCC TR26-118: <https://eccc.weizmann.ac.il/report/2026/118/>.
- Karp and Lipton, *Some connections between nonuniform and uniform complexity classes*,
  STOC 1980: <https://doi.org/10.1145/800141.804678>.
- Chandra, Kozen, and Stockmeyer, *Alternation*, JACM 1981,
  <https://doi.org/10.1145/322234.322243>.
- Chen, McKay, Murray, and Williams, *Relations and Equivalences Between Circuit Lower
  Bounds and Karp-Lipton Theorems*, CCC 2019,
  <https://doi.org/10.4230/LIPIcs.CCC.2019.30>.
- Cohen and Yankovitz, *Asymptotically-Good RLCCs with (log n)^{2+o(1)} Queries*,
  ECCC TR23-110: <https://eccc.weizmann.ac.il/report/2023/110/>.
- Kumar and Mon, *Relaxed Local Correctability from Local Testing*,
  arXiv:2306.17035: <https://arxiv.org/abs/2306.17035>.
- Project closure note: [RW succinct smart reconstruction closure theorem](../../../mcsp-hardness-magnification/notes/204-rw-succinct-smart-reconstruction-closure-theorem-2026-08-17.md).
- Growing-depth compilation and adjustable-RW-scale refinement:
  [note 586](../../../mcsp-hardness-magnification/notes/586-growing-alternation-has-iterated-polynomial-cost-and-rw-growth-can-absorb-it-2026-08-26.md).
- Address-scale PH surface refinement: [note 354](../../../mcsp-hardness-magnification/notes/354-address-scale-ph-surface-closure-2026-08-18.md).
- Auxiliary-pad black-box parent-binding barrier: [note 388](../../../mcsp-hardness-magnification/notes/388-auxiliary-pad-black-box-parent-binding-barrier-2026-08-18.md).
- Harsha auxiliary factorization/no-local-inverse gate: [note 389](../../../mcsp-hardness-magnification/notes/389-harsha-auxiliary-factorization-no-local-inverse-2026-08-18.md).
- Harsha full-table proof-length exponent audit: [note 408](../../../mcsp-hardness-magnification/notes/408-rw-harsha-proof-length-exponent-audit-2026-08-19.md).
- Actual Harsha family-lift payload barrier: [note 390](../../../mcsp-hardness-magnification/notes/390-harsha-family-lift-payload-barrier-2026-08-18.md).
- Singleton JK-lift parent-binding circuit cost: [note 410](../../../mcsp-hardness-magnification/notes/410-rw-singleton-jk-lift-parent-binding-circuit-cost-2026-08-19.md).
- RW/Harsha global-relation residual-correlation trichotomy: [note 411](../../../mcsp-hardness-magnification/notes/411-rw-harsha-global-relation-residual-correlation-trichotomy-2026-08-19.md).
- JK recursive-cover tree-correlation inequality: [note 412](../../../mcsp-hardness-magnification/notes/412-jk-recursive-cover-correlation-inequality-2026-08-19.md).
- JK recursive-cover latent-seed budget: [note 413](../../../mcsp-hardness-magnification/notes/413-jk-recursive-cover-latent-seed-budget-2026-08-19.md).
- RW systematic-witness universal-cover barrier: [note 414](../../../mcsp-hardness-magnification/notes/414-rw-systematic-witness-universal-cover-barrier-2026-08-19.md).
- RW object/address scale correction: [note 357](../../../mcsp-hardness-magnification/notes/357-rw-hard-table-object-scale-correction-2026-08-18.md).
- Scale-complete RW Closure Audit: [note 358](../../../mcsp-hardness-magnification/notes/358-rw-scale-complete-closure-audit-2026-08-18.md).
- Representation-to-address black-box barrier: [note 359](../../../mcsp-hardness-magnification/notes/359-representation-to-address-black-box-barrier-2026-08-18.md).
- Small-width AVOID block-exposure Closure Gate: [note 433](../../../mcsp-hardness-magnification/notes/433-rw-small-width-avoid-block-coverage-closure-gate-2026-08-19.md).
- Choice-robust JK easy branch: [note 360](../../../mcsp-hardness-magnification/notes/360-choice-robust-jk-easy-branch-2026-08-18.md).
- Succinct universal-gate barrier: [note 361](../../../mcsp-hardness-magnification/notes/361-succinct-universal-gate-barrier-2026-08-18.md).
- Succinct PCP/PCA closure boundary: [note 362](../../../mcsp-hardness-magnification/notes/362-succinct-pcp-pca-closure-boundary-2026-08-18.md).
- RW reconstruction-width/round conservation: [note 363](../../../mcsp-hardness-magnification/notes/363-rw-reconstruction-width-round-conservation-2026-08-18.md).
- RW logical-scale collapse boundary: [note 431](../../../mcsp-hardness-magnification/notes/431-rw-logical-scale-collapse-boundary-2026-08-19.md).
- Finite-horizon common-strategy sampling closure: [note 230](../../../mcsp-hardness-magnification/notes/230-common-strategy-sampling-eliminates-public-randomness-2026-08-17.md).
- Native-width Harsha recursive-capacity gate: [note 438](../../../mcsp-hardness-magnification/notes/438-rw-native-width-harsha-block-capacity-gate-2026-08-19.md).
- Harsha auxiliary-to-systematic inversion gate: [note 439](../../../mcsp-hardness-magnification/notes/439-harsha-auxiliary-to-systematic-inversion-gate-2026-08-19.md).
- Fortnow--Santhanam, *Infeasibility of Instance Compression and Succinct PCPs for NP*:
  <https://eccc.weizmann.ac.il/report/2007/096/>.
- Bronfman--Rothblum, *PCPs and Instance Compression from a Cryptographic Lens*:
  <https://eccc.weizmann.ac.il/report/2021/084/>.
- Reingold--Rothblum--Rothblum, *Constant-Round Interactive Proofs for Delegating
  Computation*, ECCC TR16-061 rev. 2 / STOC 2016:
  <https://eccc.weizmann.ac.il/report/2016/061/>.
- Berger--Goyal--Hong--Kalai, *Efficiently Batching Unambiguous Interactive Proofs*,
  arXiv:2510.19075 (2025): <https://arxiv.org/abs/2510.19075>.
- Gur--Minzer--Weissenberg--Zheng, *3-Query RLDCs are Strictly Stronger than
  3-Query LDCs*, arXiv:2512.12960 (2025): <https://arxiv.org/abs/2512.12960>.
- Exposed-history PCPP+RLDC baseline:
  [note 183](../../../mcsp-hardness-magnification/notes/183-exposed-history-pcpp-rldc-baseline-2026-08-16.md).
- Project barriers: [bottom-or-cubic dichotomy](../../statements/acrr-bottom-or-cubic-dichotomy.md)
  and [radius-to-relaxed-LDC barrier](../../statements/radius-to-relaxed-ldc-barrier.md).
