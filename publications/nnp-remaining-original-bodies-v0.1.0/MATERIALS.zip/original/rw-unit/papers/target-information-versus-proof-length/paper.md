---
title: Target Information versus Proof Length in Shared-Proof Coordinate Verification
author: Hongmin Li
bibliography: references.bib
link-citations: true
---

## Abstract {-}

We study a common proof that supports local verification of every coordinate of a target
word, while allowing the verifier's local policy to depend on the target. Such dependence
can make ordinary coding lower bounds appear inapplicable: two targets may use different
local tests even when they disagree at the same coordinate. We show that this escape has
an information cost.

Let a uniform target contain \(K\) bits and let \(S\) denote the vector of selected local
policies. If \(I(M;S)\le\gamma K\), where \(\gamma<1\), then some conditional policy fiber
shatters a linear number of target coordinates. On that fiber the same policies serve all
representatives. Perfect completeness on the honest proofs and target-relative soundness
throughout a fixed Hamming neighborhood then compile the common proof into a relaxed
locally decodable code. Combining this reduction with the lower bound of
Goldberg--Gur--Saraogi gives a quantitative information--proof-length tradeoff. For fixed
alphabet and fixed compiled locality \(Q\), every unpaid constant fraction of target
information forces

\[
 P=\Omega\!\left(
   \frac{K^{1+1/\lceil Q/\sigma\rceil}}
        {(\log K)^{2+2/\lceil Q/\sigma\rceil}}
 \right).
\]

Equivalently, a near-linear proof with fixed alphabet, fixed locality, and fixed positive
radius must reveal \(K-o(K)\) bits through its selected-policy vector.

When a policy uses \(r\) random bits and \(q\) adaptive proof queries, exact exposure
of its finite decision trees gives a perfect-complete nonadaptive decoder of locality
\(Q=1+2^{r+1}\sum_{j<q}A^j\), even if the original correct branch has only a constant acceptance
gap. Consequently a near-linear common proof requires
\(Q=\Omega(\log K/\log\log K)\). In the binary one-query endpoint, the 2026 exponential
two-query RLDC lower bound rules out near-linear proofs altogether.

As an application, we isolate the missing quantifier in the list-sound dPCP underlying the
recent three-query RLDC construction of Gur--Minzer--Weissenberg--Zheng. Replacing its
coordinatewise explaining list element by one low-information target-bound selector would
enter our lower bound. Thus a near-linear shared-proof strengthening must retain a
coordinate-varying selector carrying essentially target-scale information, increase visible
locality, or abandon target-relative robustness. This is a barrier for a strengthening of
the dPCP interface, not a lower bound on their construction itself.

## 1. Introduction and model

### 1.1 Motivation

A common proof can support many local claims in two fundamentally different ways. The
proof itself may contain enough information to answer all claims, or the verifier may select
target-specific local tests that reveal which proof locations and predicates matter. Lower
bounds that charge only proof length overlook the second resource. At the opposite extreme,
if the selected policy is allowed to reveal the entire target, it can prescribe a different test
for every target and no common coding structure need remain.

The natural question is therefore quantitative: how much target dependence is necessary to
evade a coding lower bound? We measure that dependence by the mutual information between a
uniform target \(M\) and the complete vector \(S\) of selected coordinate policies. This choice
handles deterministic selectors, randomized selectors, and correlations among coordinate
policies in one parameter. A bound \(I(M;S)\le\gamma K\) says that, after observing the local
strategy, at least \((1-\gamma)K\) bits of uncertainty about the target remain on average.

Our main theorem converts this residual uncertainty into an actual code. The conversion has
three steps. First, a conditional policy fiber with exponentially many targets must shatter a
linear set of coordinates. Second, choosing one target representative for every assignment on
the shattered set produces \(2^d\) honest proofs that share the same local policies. Third, an
inline copy of the shattered submessage turns wrong-claim soundness into relaxed local
decoding: the inline bit selects a claim, acceptance returns that bit, and rejection returns
\(\bot\). The resulting code is weak in the standard RLDC sense, which is exactly the model
covered by the lower bounds used here.

This argument exposes a phase diagram rather than an absolute impossibility. A system may
pay target-scale policy information, allow its visible locality to grow, use a nonconstant
alphabet, lose a positive robustness radius, or abandon a common physical proof space. The
theorem says that these are genuine resources: a constant fraction of unpaid target
information cannot coexist with all the other parameters remaining small.

### 1.2 Relation to prior work

Relaxed locally decodable codes were introduced by Ben-Sasson, Goldreich, Harsha,
Sudan, and Vadhan as part of their study of robust PCPs of proximity [@BGHSV2006]. Subsequent lower
bounds analyzed both nonadaptive and adaptive local algorithms; in particular, the
structural theorem of Dall'Agnol, Gur, and Lachish extends earlier methods to adaptive
RLDCs [@DallAgnolGurLachish2023]. We use instead the sharper recent nonadaptive inequality of
Goldberg--Gur--Saraogi [@GoldbergGurSaraogi2026]. Our contribution is not another intrinsic RLDC lower bound. It is a
reduction showing that a shared-proof verification system enters the RLDC regime whenever
its target-dependent policy leaves a linear amount of target information unpaid. This
separates two resources that are usually conflated: proof length and information carried by
the choice of local tests.

Two neighboring lines of work also charge auxiliary information in local verification.
Applebaum and Nir's advisor--verifier--prover games charge function-dependent advice together
with verifier communication and use the resulting model as a common yardstick for several
information-theoretic primitives [@ApplebaumNir2023]. Boyle, Komargodski, and Vafa prove a
local-space/query tradeoff for dynamic memory checking through an information-compression
argument inspired by RLDC lower bounds [@BoyleKomargodskiVafa2024]. These models clarify that
local state or advice can be a genuine resource, but neither supplies the conditional-fiber
shattering step or the static shared-proof-to-RLDC reduction proved here.

Goldberg--Gur--Saraogi give the quantitative lower bound that drives our general
finite-alphabet consequence. Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu prove an
exponential lower bound in the binary two-query endpoint, including adaptive weak decoders
[@BlockEtAl2026].
Cheng--Li--Mao show, in a complementary low-soundness regime, that a \(q\)-query RLDC
with wrong-output probability below a \(q\)-dependent threshold yields an LDC with
comparable parameters [@ChengLiMao2026]. That transformation can strengthen consequences when \(\beta\) is
extremely small; it neither charges target-dependent policy information nor subsumes the
constant-gap tradeoff proved here.
These results are external inputs. The new statement here is the information-to-fiber-to-RLDC
reduction and its interpretation for shared-proof verification. The application in Section 5
uses the list-sound dPCP of Gur--Minzer--Weissenberg--Zheng [@GurMinzerWeissenbergZheng2026]
to show that its coordinatewise
list quantifier cannot be replaced, at no information cost, by one robust target-bound global
choice.

The literature boundary was checked on 21 August 2026 against the works cited above and the
contemporaneous RLDC results discussed in Section 6. We make no absolute priority claim
beyond that search boundary. In particular, none of the cited RLDC lower bounds accounts for
a target-policy mutual-information channel, and none of the cited dPCP constructions states
the target-relative common-proof interface assumed below.

### 1.3 Formal model

All logarithms and entropies are base two. Hamming distance is unnormalized unless a
relative distance is stated explicitly.

Let \(\Sigma\) be an alphabet of size \(A\ge2\), and let

\[
  \Pi:\{0,1\}^K\longrightarrow\Sigma^P
\tag{1.1}
\]

be a proof map. For each coordinate \(i\in[K]\), claim \(b\in\{0,1\}\), and policy
\(\tau\), let \(V_{i,b}^{\tau}\) be a randomized verifier with oracle access to a proof
word. A selected-policy vector is a discrete random variable

\[
  S=(\tau_1,\ldots,\tau_K).
\tag{1.2}
\]

We allow \(S\) to be randomized conditional on the target \(M\). For every pair
\((m,s)\) in the support of \((M,S)\), every coordinate \(i\), and fixed constants
\(0<\rho<1\) and \(\beta<1\), assume

\[
 \Pr[V_{i,m_i}^{s_i}(\Pi(m))=1]=1,
\tag{1.3}
\]

and

\[
 d_H(z,\Pi(m))\le\rho P
 \quad\Longrightarrow\quad
 \Pr[V_{i,1-m_i}^{s_i}(z)=1]\le\beta.
\tag{1.4}
\]

The soundness condition is target-relative. It constrains the wrong claim near the
target proof; requiring the same claim to be wrong near every target would conflict with
perfect completeness for another target. Notice that (1.3)--(1.4) do not require the
correct branch to keep accepting corrupted proofs. Rejection is interpreted as the
relaxed-decoding symbol \(\bot\).

For an integer \(Q\), alphabet size \(\widehat A\), and \(0<\sigma\le1\), define

\[
 \mathcal L_{Q,\widehat A,\sigma}(d)=
 \left(
 \frac{\sigma^2d}
 {38Q^4\log_2^2(\widehat A)\log_2^2d}
 \right)^{1+1/\lceil Q/\sigma\rceil}.
\tag{1.5}
\]

This is the explicit lower-bound function supplied by the nonadaptive RLDC theorem of
Goldberg--Gur--Saraogi in its radius window.

We use their weak RLDC convention. A code
\(C:\{0,1\}^k\to\Gamma^n\) has a nonadaptive
\((Q,\delta,\sigma)\)-relaxed decoder if, on input \(j\in[k]\), the decoder makes at
most \(Q\) oracle queries chosen independently of the received word, has
\(D^{C(x)}(j)=x_j\) with probability one, and satisfies

\[
 d_H(w,C(x))\le\delta n
 \quad\Longrightarrow\quad
 \Pr[D^w(j)\in\{x_j,\bot\}]\ge\sigma.
\tag{1.5a}
\]

The external lower bound we use is the following [@GoldbergGurSaraogi2026, Theorem 1].
If such a code has \(k\) message bits,
block length \(n\), alphabet \(\Gamma\), and
\(\delta>n^{-\sigma/(2Q)}\), then Goldberg--Gur--Saraogi prove

\[
 \frac{k}{\log_2^2 k}
 \le
 38Q^4\sigma^{-2}\log_2^2|\Gamma|\,
 n^{1-1/(\lceil Q/\sigma\rceil+1)}.
\tag{1.5b}
\]

Equivalently, for \(k\ge2\), \(n\ge\mathcal L_{Q,|\Gamma|,\sigma}(k)\). We state the
inequality explicitly because both the soundness parameter and the radius window affect the
exponent used below.

### Theorem 1.1 (target information versus proof length)

Let \(M\) be uniform on \(\{0,1\}^K\), and suppose (1.3)--(1.4) hold. Assume that, for
both claims \(b\in\{0,1\}\), every selected branch \(V_{i,b}^{s_i}\) is nonadaptive and
makes at most \(q\) proof queries, and set

\[
 Q=1+2q,
 \qquad \sigma=1-\beta.
\tag{1.5c}
\]

Assume

\[
 I(M;S)\le\gamma K
\tag{1.6}
\]

for a constant \(0\le\gamma<1\). Let \(\vartheta_\gamma\in(0,1/2]\) satisfy
\(h_2(\vartheta_\gamma)=1-\gamma\), and fix
\(0<\varepsilon<\vartheta_\gamma\). Put

\[
 d=\lfloor(\vartheta_\gamma-\varepsilon)K\rfloor.
\tag{1.7}
\]

Then the selected branches compile to a nonadaptive \(Q\)-query relaxed decoder with
success parameter \(\sigma\) and a constant decoding radius
\(\delta_0=\delta_0(A,\rho)>0\). Whenever

\[
 \delta_0>(d+P)^{-\sigma/(2Q)},
\tag{1.8a}
\]

the radius hypothesis of the Goldberg--Gur--Saraogi theorem holds and

\[
 d+P\ge \mathcal L_{Q,A+2,\sigma}(d).
\tag{1.8}
\]

Consequently, for fixed \(A,Q,\gamma,\varepsilon,\sigma\),

\[
 P=\Omega\!\left(
 \frac{K^{1+1/\lceil Q/\sigma\rceil}}
 {(\log K)^{2+2/\lceil Q/\sigma\rceil}}
 \right).
\tag{1.9}
\]

If instead each branch uses at most \(r\) random bits in total and at most \(q\ge1\)
adaptive proof queries, define

\[
 T_q(A)=\sum_{j=0}^{q-1}A^j,
 \qquad Q_{\rm fin}=1+2^{r+1}T_q(A).
\tag{1.10}
\]

Then (1.8) holds with \(Q=Q_{\rm fin}\) and \(\sigma=1\), even if (1.3) is replaced by
an honest-proof acceptance probability \(\alpha>\beta\). In particular, consider an
asymptotic family in which \(A,\rho,\gamma,\varepsilon\), and \(c\) are fixed. If
\(P\le K(\log K)^c\) along an infinite sequence, then

\[
 Q_{\rm fin}=\Omega\!\left(\frac{\log K}{\log\log K}\right),
\tag{1.11}
\]

and hence

\[
 r+\log_2 T_q(A)
 \ge \log_2\log K-\log_2\log\log K-O(1).
\tag{1.12}
\]

The constants in (1.9)--(1.12) may depend on the fixed parameters displayed above.
The proof occupies Sections 2--4.

## 2. A low-information policy has a large shattered fiber

For a policy value \(s\), let

\[
 F_s=\{m:\Pr[M=m,S=s]>0\}.
\tag{2.1}
\]

The following elementary lemma is the information-theoretic source of the linear
submessage in Theorem 1.1.

### Lemma 2.1 (conditional-fiber shattering)

Under (1.6), for every fixed \(0<\varepsilon<\vartheta_\gamma\) and all sufficiently
large \(K\), some \(F_s\) has VC dimension at least

\[
 d=\lfloor(\vartheta_\gamma-\varepsilon)K\rfloor.
\tag{2.2}
\]

#### Proof

Since \(M\) is uniform,

\[
 H(M\mid S)=K-I(M;S)\ge(1-\gamma)K.
\tag{2.3}
\]

Hence some conditional law \(M\mid S=s\) has entropy at least
\((1-\gamma)K\), and therefore

\[
 |F_s|\ge2^{(1-\gamma)K}.
\tag{2.4}
\]

If \(\operatorname{VCdim}(F_s)<d\), Sauer--Shelah gives

\[
 |F_s|\le\sum_{j<d}\binom Kj
 \le2^{(h_2(\vartheta_\gamma-\varepsilon)+o(1))K}
 <2^{(1-\gamma)K},
\tag{2.5}
\]

for all sufficiently large \(K\), contradicting (2.4). \(\square\)

The conclusion is sharp at the information scale. If \(S=M\), every conditional fiber
is a singleton and no common-policy submessage remains.

## 3. A shattered policy fiber contains an RLDC

Fix \(s\) and a set \(I=\{i_1,\ldots,i_d\}\) shattered by \(F_s\). For every
\(x\in\{0,1\}^d\), choose a representative \(m_x\in F_s\) satisfying
\(m_x|_I=x\), and write

\[
 C_s(x)=\Pi(m_x).
\tag{3.1}
\]

### Lemma 3.1 (common-policy proof compiler)

Under (1.3)--(1.4), distinct words in the image of \(C_s\) have relative Hamming
distance greater than \(\rho\). Moreover, the tagged inline map

\[
 \widehat C_s(x)=x\Vert C_s(x)
 \in(\Sigma\sqcup\{0,1\})^{d+P}
\tag{3.2}
\]

is a perfect-complete weak relaxed locally decodable code. Its decoder uses one inline
query and the queries of one selected branch. It is therefore adaptive in general: the inline
answer chooses which claim branch is executed. If both selected claim branches are
nonadaptive and make at most \(q\) proof queries, sample a random tape for each claim,
query the union of the resulting two query sets before reading any answers, and use only the
answers belonging to the branch selected by the inline symbol. This gives a nonadaptive
decoder making at most \(1+2q\) queries. Throughout
a fixed positive-radius neighborhood it outputs the requested bit or
\(\bot\) with probability at least \(1-\beta\). For all sufficiently large \(d\), one may take

\[
 \delta_0=
 \frac{\rho}{4\bigl(1+(1-\rho)\log_2 A\bigr)}.
\tag{3.2a}
\]

#### Proof

Suppose \(x_j\ne x'_j\) and
\(d_H(C_s(x),C_s(x'))\le\rho P\). The same policy \(s_{i_j}\) is selected throughout
the fiber. Perfect completeness for \(m_{x'}\) makes the branch claiming \(x'_j\)
accept \(C_s(x')\) with probability one, whereas target-relative soundness for \(m_x\)
bounds the same branch by \(\beta<1\), a contradiction. Thus the proof suffixes have
distance greater than \(\rho P\).

To decode \(x_j\), read the inline coordinate \(j\), obtaining a claim \(b\), and run
\(V_{i_j,b}^{s_{i_j}}\) on the proof suffix. Output \(b\) on acceptance and \(\bot\)
on rejection. On an uncorrupted codeword the inline claim is correct and (1.3) gives
perfect completeness. On a nearby word, an uncorrupted inline bit can only yield the
correct output or \(\bot\); a corrupted inline bit selects the wrong claim, whose
acceptance probability is at most \(\beta\) by (1.4).

It remains to obtain a constant relative decoding radius for the full word. Let \(D\) be
the minimum distance among the \(2^d\) proof suffixes. The \(A\)-ary Singleton bound and
\(D>\rho P\) give

\[
 d\le(P-D+1)\log_2 A
 <\bigl((1-\rho)P+1\bigr)\log_2 A.
\tag{3.2b}
\]

For all sufficiently large \(d\), this implies
\(P\ge d/[2(1-\rho)\log_2 A]\). Consequently the value in (3.2a) satisfies
\(\delta_0(d+P)<\rho P\). Any received inline word within relative distance
\(\delta_0\) therefore has a proof suffix within the target-relative promise ball, which
completes the decoding argument. \(\square\)

Combining Lemmas 2.1 and 3.1 with the nonadaptive RLDC lower bound immediately yields
(1.8). For completeness, write

\[
 a=\left\lceil Q/\sigma\right\rceil,
 \qquad
 c_0=\left(
 \frac{\sigma^2}{38Q^4\log_2^2(A+2)}
 \right)^{1+1/a}.
\tag{3.2c}
\]

The lower bound then reads

\[
 d+P\ge
 c_0\frac{d^{1+1/a}}{(\log_2d)^{2+2/a}}.
\tag{3.2d}
\]

For fixed \(A,Q,\sigma\), the right-hand side is superlinear in \(d\). Hence subtracting
\(d\) changes only the implicit constant for all sufficiently large \(d\). Lemma 2.1 gives
\(d=\Theta_{\gamma,\varepsilon}(K)\), proving (1.9). Since \(\delta_0\) is fixed and
\(d+P\to\infty\), condition (1.8a) also holds automatically for all sufficiently large
\(K\) whenever \(Q\) and \(\sigma\) are fixed.

### Corollary 3.2 (binary one-query endpoint)

Suppose \(A=2\), \(\beta<1/2\), every selected branch makes one possibly adaptive proof
query, and the policy vector satisfies (1.6). Then the inline code on the shattered fiber
is a binary two-query weak adaptive RLDC. The theorem of Block--Blocki--Cheng--
Grigorescu--Li--Zheng--Zhu [@BlockEtAl2026, Theorem 1] gives

\[
 P=2^{\Omega_{\rho,\beta,\gamma}(K)}.
\tag{3.3}
\]

Here the inline and proof alphabets are both binary, so no tagged-alphabet conversion is
needed. Its relaxed-decoding success is \(1-\beta>1/2\), and its radius is the fixed
constant in (3.2a). Thus the advantage parameter in the notation of the external theorem is
\(\varepsilon_{\rm B}=1/2-\beta>0\). This endpoint therefore uses that theorem's
perfect-completeness and weak adaptive RLDC convention exactly.

### Corollary 3.3 (near-linear proofs require target-scale policy information)

Fix \(A,q,\rho,\beta\), with \(\beta<1\), and consider a family satisfying
(1.3)--(1.4) whose two claim branches are nonadaptive and use at most \(q\) proof
queries. If

\[
 P\le K(\log K)^c,
\tag{3.4}
\]

then

\[
 I(M;S)=K-o(K).
\tag{3.5}
\]

Consequently the support of \(S\) has size at least \(2^{K-o(K)}\). If \(S\) is a
deterministic function of \(M\), the same lower bound holds for the number of distinct
policy vectors used by the family.

#### Proof

If (3.5) failed, some fixed \(\eta>0\) and an infinite subsequence would satisfy
\(I(M;S)\le(1-\eta)K\). Apply Theorem 1.1 with \(\gamma=1-\eta\). Since
\(Q=1+2q\) and \(\sigma=1-\beta\) are fixed, (1.9) is polynomially superlinear and
contradicts (3.4). Hence (3.5) holds. Finally,
\(I(M;S)\le H(S)\le\log_2|\operatorname{supp}(S)|\). \(\square\)

## 4. Finite randomness repairs imperfect completeness

We now replace perfect completeness in (1.3) by the fixed honest-proof gap

\[
 \Pr[V_{i,m_i}^{s_i}(\Pi(m))=1]\ge\alpha>\beta.
\tag{4.1}
\]

Assume a branch uses at most \(r\) random bits in total and at most \(q\) adaptive proof
queries.

### Lemma 4.1 (finite-tree exposure)

On every shattered policy fiber, the inline code (3.2) has a perfect-complete
nonadaptive relaxed decoder with zero wrong-output probability in the promise ball and
query complexity at most

\[
 Q_{\rm fin}=1+2^{r+1}\sum_{j=0}^{q-1}A^j.
\tag{4.2}
\]

#### Proof

The distance argument of Lemma 3.1 remains valid with (4.1): if two suffixes encoding
different requested bits were within distance \(\rho P\), the same claim branch would have
acceptance probability at least \(\alpha\) by (4.1) and at most \(\beta\) by (1.4). Thus
the constant inline radius \(\delta_0\) from (3.2a) is still available.

For each possible inline claim \(b\in\{0,1\}\) and every public random tape, expose all
internal nodes of the corresponding depth-\(q\), \(A\)-ary proof-answer decision tree.
There are at most \(\sum_{j<q}A^j\) queried nodes per tape and per claim. Query the inline
coordinate and the union of all these proof positions nonadaptively. After the answers are
known, use the inline symbol to choose the relevant claim and simulate all of that claim's
random tapes offline, thereby computing its exact acceptance probability.

Use the threshold \(t=(\alpha+\beta)/2\). Output \(b\) if the exact acceptance
probability exceeds \(t\), and output \(\bot\) otherwise. On an honest codeword the
inline bit is correct and (4.1) puts the acceptance probability above \(t\), giving
perfect completeness. In the promise ball, a flipped inline bit selects the wrong
claim, whose acceptance probability is at most \(\beta<t\); it therefore produces
\(\bot\), never a wrong bit. An unflipped inline bit produces the correct bit or
\(\bot\). \(\square\)

Lemma 4.1 and the Goldberg--Gur--Saraogi inequality prove the second part of
Theorem 1.1. We include the growing-locality calculation. Put \(N=d+P\) and suppose
\(P\le K(\log K)^c\). Since \(d=\Theta(K)\), this gives

\[
 N\le C_1d(\log d)^c.
\tag{4.3}
\]

Here \(C_1=C_1(\gamma,\varepsilon,c)\) is independent of \(K\).

In the GGS radius window, Lemma 4.1 has \(\sigma=1\), so (1.5) gives

\[
 N\ge
 \left(
 \frac{d}{38Q_{\rm fin}^4\log_2^2(A+2)\log_2^2d}
 \right)^{1+1/Q_{\rm fin}}.
\tag{4.4}
\]

Taking logarithms after division by \(d\), the positive term is
\((\log d)/Q_{\rm fin}\), whereas the loss is
\(O(\log Q_{\rm fin}+\log\log d)\). If
\(Q_{\rm fin}\le\eta\log d/\log\log d\) for a sufficiently small constant
\(\eta=\eta(A,c)>0\), the former exceeds both this loss and the logarithm of the
right-hand side of (4.3). Thus (4.3) and (4.4) are incompatible. If the GGS radius
condition fails instead, then

\[
 \delta_0\le N^{-1/(2Q_{\rm fin})}
 \quad\Longrightarrow\quad
 Q_{\rm fin}\ge
 \frac{\log N}{2\log(1/\delta_0)}
 =\Omega_{A,\rho}(\log K).
\tag{4.5}
\]

Both cases imply (1.11). Finally,
\(Q_{\rm fin}=1+2^{r+1}T_q(A)\) and taking base-two logarithms give (1.12),
with the extra factor two absorbed by the constant term.

## 5. Application to list-sound decodable PCPs

Gur--Minzer--Weissenberg--Zheng construct, for every \(\epsilon>0\), a two-query
decodable PCP of length \(O(N\log^C N)\), alphabet size
\(O_{\epsilon,|\Sigma_0|}(1)\), perfect completeness, and
\((L,\epsilon)\)-list-decoding soundness, where
\(L=\operatorname{poly}(1/\epsilon)\)
[@GurMinzerWeissenbergZheng2026, Theorem 3.12]. In the
notation of their Definition 3.3, its soundness quantifiers have the form

\[
 \forall T_A\;\exists W(T_A),\ |W(T_A)|\le L\;\forall T_B,
\tag{5.1}
\]

More precisely, if \(W(T_A)=\{w_1,\ldots,w_L\}\), their guarantee bounds

\[
 \Pr_{t,(a,b)\sim P_t}\!\left[
 \Phi_{(a,b)}(T_A[a],T_B[b])=1
 \ \wedge\
 D_t(a,T_A[a])\notin\{(w_1)_t,\ldots,(w_L)_t\}
 \right]
 \le\epsilon.
\tag{5.1a}
\]

Thus a decoded symbol need only lie in the coordinate projection of the list. Different
coordinates may be explained by different list members; (5.1a) does not choose one
target-bound word that simultaneously explains every coordinate.

The following consequence of Theorem 1.1 quantifies why that distinction is necessary
for a shared-proof strengthening.

### Corollary 5.1 (global list selection enters the coding barrier)

Consider any strengthening of (5.1) that, for every \(K\)-bit target, chooses a vector
of explaining-list policies \(S\), uses one common proof of length \(P\), and satisfies
the target-relative neighborhood conditions (1.3)--(1.4). If
\(I(M;S)\le\gamma K\) for some fixed \(\gamma<1\), then the proof length and visible
locality obey Theorem 1.1.

In particular, suppose the entire policy vector is determined by a single global list index
\(J(M)\in[L]\). By data processing,

\[
 I(M;S)\le I(M;J(M))\le\log_2L=o(K)
\tag{5.2}
\]

whenever \(L=2^{o(K)}\). Hence a constant-query, constant-alphabet, near-linear common
proof cannot obtain the required robust target binding merely by selecting one global
member of the dPCP list. Any such strengthening must instead use a coordinate-varying
selector with essentially target-scale information, increase the compiled locality as
in (1.11), or fail one of the common-proof/positive-radius/target-relative hypotheses.

#### Proof

The selected list element at each coordinate is precisely a policy vector \(S\) in the
model of Section 1. Apply Theorem 1.1. Equation (5.2) follows from data processing and
the entropy bound for a single \(L\)-valued selector. \(\square\)

Corollary 5.1 is not a lower bound on the GMWZ construction. Their theorem keeps the
coordinatewise list-decoding quantifier and therefore does not assert (1.3)--(1.4) for
one target-bound shared word. The corollary instead rules out a natural black-box
upgrade of that theorem. This is the promised application: the policy-information
tradeoff identifies exactly which quantifier a future global-word strengthening must
pay for.

## 6. Parameter comparison and scope

The three relevant regimes are summarized below. In every row the policy-information
hypothesis is \(I(M;S)\le\gamma K\) for a fixed \(\gamma<1\), and the decoding radius is
the fixed constant \(\delta_0(A,\rho)\) from (3.2a).

| Selected branches | Compiled decoder | External input | Consequence |
|:--|:--|:--|:--|
| Nonadaptive, at most \(q\) queries per claim | Nonadaptive, \(Q=1+2q\), success \(1-\beta\) | Goldberg--Gur--Saraogi | Polynomially superlinear bound (1.9) |
| At most \(r\) random bits and \(q\) adaptive queries per claim | Perfect-complete nonadaptive, \(Q_{\rm fin}=1+2^{r+1}T_q(A)\) | Goldberg--Gur--Saraogi | \(P\le K(\log K)^c\) forces \(Q_{\rm fin}=\Omega(\log K/\log\log K)\) |
| Binary alphabet, one proof query per claim | Weak adaptive two-query, success \(1-\beta>1/2\) | Block et al. | \(P=2^{\Omega(K)}\) |

The first row is the direct constant-locality information--proof-length tradeoff. The
second shows that imperfect completeness cannot hide inside a bounded random tape: exposing
both claim trees makes the total visible locality explicit. The last row uses the sharper
binary two-query endpoint and therefore requires \(\beta<1/2\).

The result does not constrain a policy channel with \(I(M;S)=K-o(K)\), a different
physical proof or address space for each coordinate, an unbounded visible state that is
not charged in \(S\), or soundness that holds only on average over coordinates. It also
does not convert ordinary dPCP list soundness into target-relative robustness. These are
boundaries of the theorem, not claimed impossibilities.

## Declarations {-}

### Funding {-}

This work was supported by the 2025 Google Research Grant from Google Asia Pacific
Pte. Ltd.

### Competing interests {-}

The author has no relevant financial or non-financial interests to disclose.

### Author contributions {-}

Hongmin Li conceived the study, developed and verified the mathematical arguments,
conducted the literature analysis, and wrote the manuscript.

### Acknowledgements {-}

This research used the UTokyo Azure service
(<https://utelecon.adm.u-tokyo.ac.jp/en/research_computing/utokyo_azure/>).

### Data and code availability {-}

No datasets were generated or analysed in this study. The results are mathematical and
all arguments needed to verify them are contained in the article; no custom code is
required to reproduce the results.

### Use of artificial intelligence {-}

Generative-AI tools were used to assist with language editing, structural suggestions,
literature-search support, and adversarial checking of arguments. All mathematical claims,
proofs, and citations were independently checked by the author, who takes full
responsibility for the content of the article.

## References {-}

::: {#refs}
:::
