# Cover Obstructions for Shared-Top Direct-Product Tests

## Abstract

We give a source-specific obstruction to upgrading shared-top direct-product soundness into
one global base word. The source is the affine-building family of Bafna--Minzer--Vyas (BMVY),
combined with the truncated spectral estimates of Dikstein--Dinur--Lubotzky and the cover
obstruction of Dikstein--Dinur. After matching the shared-top sampling law, adjacent finite
quotients form a connected finite cover. The cover lemma then supplies a Boolean face table
with nontrivial shared-top agreement but exponentially small agreement with every base-level
global word.

The cover degree is retained explicitly: the obstruction has agreement at least \(1/L_i\),
where \(L_i\) is the adjacent quotient index, not an unqualified constant. We further use the
BMVY containment spectrum to close a stronger escape: a face-separable two-cluster patch cannot
survive unique decoding even when its right labels are arbitrary. An overlap-aware extension
also handles arbitrary vertex-varying tags, and its multicluster form charges the residual
escape to a sharp mass-weighted high-order incidence-overlap parameter rather than to a
binary-tag assumption.
The result is not a general
dPCP or RLDC impossibility theorem. It is a precise theorem about why this HDX source cannot
be used as a black box for global-word consistency without binding the cover sheet or adding
a target-normalized outer check. We package the quantitative conclusions as a
bottom--cover--cubic closure trichotomy: the base-global escape exposes a bottom witness or
incurs a cubic coding cost, while the cover escape must pay its sheet entropy or leave the
base-word model.

## 1. The source and the shared-top law

Fix a target face dimension \(K\), an ambient dimension \(d\ge3K\), and a sufficiently large
prime \(p\). Let

\[
 X_i=\Gamma_i\backslash\widetilde C_d(\mathbb Q_p)
\]

be consecutive finite quotients in the BMVY group filtration, with
\(\Gamma_{i+1}<\Gamma_i\) and cover degree

\[
 L_i=[\Gamma_i:\Gamma_{i+1}]>1.
\tag{1.1}
\]

The BMVY direct-product tester first samples a top face and then a common lower face before
sampling two conditional subfaces. After the usual integer rounding of the square-root face
dimension, this is the same shared-top law used by the Dikstein--Dinur (V)-test.

## 2. Main cover-obstruction theorem

### Theorem 2.1

For the above parameters, choose \(p\) so that the DDL truncated-skeleton estimate gives

\[
 \lambda_K\le
 \max\left\{\frac{C}{\sqrt p},\frac1{d-K+1}\right\}<\frac{0.99}{K}.
\tag{2.1}
\]

Assume the BMVY filtration’s nontrivial elements move every vertex by at least four. Then
the quotient map \(X_{i+1}^{\le K}\to X_i^{\le K}\) is a connected finite \(L_i\)-cover.
Consequently there exists a Boolean face table \(\{f_A:A\in X_i(K)\}\) such that

\[
 \operatorname{Agree}_{V}(\mathcal F)\ge\frac1{L_i},
\tag{2.2}
\]

while, for every base word \(H:X_i(0)\to\{0,1\}\) and every fixed \(\zeta<1/2\),

\[
 \Pr_{A\in X_i(K)}
 \bigl[f_A\overset{1-\zeta}{\approx}H|_A\bigr]
 \le \exp(-\Omega_\zeta(K)).
\tag{2.3}
\]

### Proof

The DDL theorem supplies the required two-sided local spectral bound on the truncated
affine-building skeleton. The BMVY displacement condition ensures that the consecutive
quotient map is locally an isomorphism on faces; finite index gives a finite connected cover.
Applying the Dikstein--Dinur cover-obstruction lemma to this cover yields the face table and
(2.2)--(2.3). The agreement lower bound is \(1/L_i\) because the cover sheet is sampled
uniformly. No claim that \(L_i=O(1)\) is needed or made. \(\square\)

The BMVY filtration gives, in its standard normalization. More explicitly, Appendix E.3
computes the successive principal-congruence quotients, and the proof of the BMVY
construction uses the resulting identity
\([H(i):H(i+1)]=\ell_0^{\Theta(d^2)}\) for every \(i\ge1\); the associated lattice
quotient has the same index. Thus

\[
 \log L_i=\Theta(d^2\log\ell_0),
\]

for its pro-(\ell_0) parameter. This dependence is part of the theorem’s usable parameter
boundary.

### Theorem 2.2 (cover degree versus a fixed soundness window)

Assume the consecutive BMVY filtration quotients satisfy the explicit degree bounds

\[
 \ell_0^{c_-d^2}\le L_i\le \ell_0^{c_+d^2}
\tag{2.4}
\]

for fixed positive constants \(c_-,c_+\). If \(d=\Theta(K)\), then

\[
 \log_2 L_i=\Theta(K^2\log_2\ell_0),
 \qquad
 L_i^{-1}=\exp\!\bigl[-\Theta(K^2\log\ell_0)\bigr].
\tag{2.5}
\]

Consequently, the cover agreement in (2.2) is eventually smaller than every fixed
inverse-polynomial window \(K^{-a}\). More generally, it cannot meet a target window
\(\varepsilon_K\) whenever

\[
 \log(1/\varepsilon_K)=o(K^2\log\ell_0).
\tag{2.6}
\]

There is also a direct sheet-binding cost. Suppose a target-independent selector uses a
\(d_{\rm desc}\)-bit static descriptor and \(q\) common-address queries whose answers lie in a
fixed finite alphabet \(\Sigma\). If it succeeds on an \(\alpha\)-fraction of the \(L_i\) sheets,
then

\[
 d_{\rm desc}+q\log_2|\Sigma|
 \ \ge\ \log_2 L_i-\log_2(1/\alpha)
 \ =\ \Theta(K^2\log_2\ell_0)-\log_2(1/\alpha).
\tag{2.7}
\]

In particular, a \(K\operatorname{polylog}K\)-length proof with a same-scale descriptor cannot
bind all cover sheets over a fixed alphabet. This is a source-specific quantitative obstruction,
not a general impossibility theorem for near-linear dPCPs.

#### Proof

Taking logarithms in (2.4) and using \(d=\Theta(K)\) gives the first statement in (2.5);
exponentiating its negation gives the second. The comparison with \(K^{-a}\) and (2.6) is
immediate. For (2.7), a fixed descriptor together with \(q\) alphabet symbols has at most
\(2^{d_{\rm desc}}|\Sigma|^q\) possible transcripts. To succeed on an \(\alpha\)-fraction of
the \(L_i\) sheets, these transcripts must cover at least \(\alpha L_i\) sheets. Taking
base-two logarithms proves (2.7). \(\square\)

### Theorem 2.3 (perfect-complete sheet binding enters the RLDC barrier)

The entropy bound in Theorem 2.2 has a coding-theoretic strengthening. Let
\(\kappa=\lfloor\log_2 L_i\rfloor\), retain \(2^\kappa\) sheets, and suppose a single
target-independent adaptive selector \(\mathsf{Sel}\) makes at most \(q\) queries to a
proof word in \(\Sigma^P\). Set
\[
  A:=|\Sigma|\ge 2,\qquad Q:=\sum_{j=0}^{q-1}A^j.
\]
Assume that it returns the correct \(\kappa\)-bit sheet label with probability one on every
honest proof, and that on every proof within relative distance \(\rho\) of the target proof
it returns a wrong non-\(\bot\) sheet with probability at most \(\beta<1\). Writing
\(\sigma=1-\beta\), if
\[
  \rho>P^{-\sigma/(2Q)},
\tag{2.8}
\]
then, for all sufficiently large \(\kappa\),
\[
 P\ge
 \left(
 \frac{\sigma^2\kappa}
 {38Q^4\log^2A\,\log^2\kappa}
 \right)^{1+1/\lceil Q/\sigma\rceil}.
\tag{2.9}
\]

Indeed, running the selector and returning any fixed bit of its sheet label gives a
weak adaptive \((q,\rho,\sigma)\)-RLDC. Exposing the complete \(A\)-ary decision tree
of the selector gives a non-adaptive decoder with at most
\(Q=\sum_{j<q}A^j\) proof queries. Perfect completeness and the wrong-sheet condition
force the proof image to have relative distance greater than \(\rho\), so the arbitrary
alphabet non-adaptive RLDC lower bound gives (2.9).

For the BMVY/DDL filtration, \(\kappa=\Theta(d^2\log\ell_0)\). Thus fixed
\(A,q,\rho,\beta\) already rule out a \(\kappa\operatorname{polylog}\kappa\) common proof for the
sheet family, subject to the stated positive-radius window. This remains a source-specific
theorem; it does not assert that ordinary dPCP/list soundness supplies the selector.

### Theorem 2.4 (Bottom--cover--cubic closure trichotomy)

Consider a proposed shared-proof closure on infinitely many message scales \(M\), with proof
length \(N\le M(\log M)^c\). Assume the object is presented in the following source-relative
normal form: either (i) it is a single base-address proof map satisfying the target-relative
binary two-query hypotheses of the bottom--cubic theorem, or (ii) it retains the \(L_i\)
distinguishable sheets of the connected BMVY/DDL cover and any common-address sheet selector
has a target-independent \(d_{\rm desc}\)-bit descriptor, \(q\) proof queries over \(\Sigma\),
and list size at most \(\Lambda\). Write \(\kappa_i:=\lfloor\log_2 L_i\rfloor\) for the
sheet-message length. If neither description applies, the construction has left
this theorem's base-global/finite-descriptor model.

Then, in case (i), either a half-radius near-proof witnesses simultaneous rejection
\(\tau_{\rho/2}<2/3+\beta\), or

\[
  N=\Omega_{\rho,\beta}\!\left(\frac{M^3}{\log^6 M}\right).
\tag{2.10}
\]

If the base-global branch has fixed finite alphabet, a fixed positive radius, a fixed
target-relative gap, and growing adaptive depth, the same near-linear window instead forces
\(Q_{r,A}=\Omega(\log M/\log\log M)\) under perfect completeness (or under the explicitly
stated independent-resampling amplification hypothesis). In case (ii), preserving an
\(\alpha_s\)-fraction of the sheets requires

\[
 d_{\rm desc}+q\log_2|\Sigma|+\log_2\Lambda
 \ge \log_2 L_i-\log_2(1/\alpha_s).
\tag{2.11}
\]

For the BMVY/DDL parameters, if the target face dimension is \(K_{\rm face}\) with
\(d=\Theta(K_{\rm face})\), then
\(\log L_i=\Theta(K_{\rm face}^2\log\ell_0)\). Hence whenever this sheet entropy dominates
\(M\operatorname{polylog}M\), a near-linear, fixed-alphabet construction must either expose
the bottom witness, pay the sheet-binding/RLDC cost, add a target-normalized outer check, or
leave the stated model. This is a classification under the displayed normal-form hypotheses,
not a universal dPCP impossibility theorem.

#### Proof

The base-global alternatives are the binary bottom--cubic dichotomy and its finite-alphabet
decision-tree extension. The cover inequality is Theorem 2.2, with list ambiguity
contributing the additional \(\log_2\Lambda\) term. The BMVY substitution is (2.5). If no
base proof, sheet selector, or target-normalized replacement is supplied, the cover object
remains a lift-word, so it is a model exit rather than a hidden base-word closure. \(\square\)

The qualifier “normal form” is essential: this theorem does not claim that every future
dPCP must be base-global or cover-indexed. It identifies the exact obligations for escaping
the present source-relative closure gate.

## 3. Incidence-profile closure of a patch escape

The cover obstruction alone leaves two possible escapes: bind the sheet, or use a genuinely
global assignment rather than a face-separable patch. The BMVY containment operators provide
a second theorem. Let \(U_0,U_1\subseteq X_i(K)\) be disjoint clusters of mass at least
\(\mu_0>0\). Suppose their left labels differ on a vertex set of mass \(\delta>0\), while
the right labels are arbitrary. Under the BMVY marginal and
\(\operatorname{poly}(K)\gamma=o(K^{-1/4})\), the collision/profile estimate gives

\[
 \operatorname{Viol}_{\mathrm{patch}}
 \ge
 \frac{\mu_0}{2}
 \left[
 1-O\!\left(\frac1{K\delta}\right)
  -O\!\left(\frac1{\mu_0\sqrt K}\right)
 \right]_+ .
\tag{3.1}
\]

Hence for fixed \(\mu_0,\delta>0\) and large \(K\), the violation is at least
\(\mu_0/4\). Any unique-decoding radius below this threshold rules out the patch, even though
the right labels need not be restrictions of a vertex word.

The proof uses BMVY’s \(K\to s\) containment spectrum with \(s=\lceil\sqrt K\rceil\),
and BMVY Theorem 2.2 at the \(s\to1\) endpoint. This is a source-specific profile argument;
it is not obtained by treating the shared-top sampler as the BMVY down-up walk without checking
the marginal law.

### Proposition 3.1 (overlap-aware varying-tag gate)

The preceding patch argument remains valid when the output tag is allowed to vary
arbitrarily with the vertex. Let \(U_0,U_1\subseteq X_i(K)\) be disjoint clusters of
masses \(\mu_0,\mu_1\), and let \(\nu_0,\nu_1\) be the vertex distributions obtained by
sampling a face from \(U_i\) and then a uniformly random vertex of that face. Put
\[
 \chi:=1-\operatorname{TV}(\nu_0,\nu_1).
\tag{3.2}
\]
For a vertex word \(F\), let \(\tau_F(v)\in\{0,1,\bot\}\) be its tag projection, and let
\(\lambda_i(F)\) be the probability that \(F\) agrees with the tagged cluster table on a
random face from \(U_i\), up to relative symbol error \(\zeta\). If a tag disagreement
always contributes at least one symbol error, then
\[
 (1-\zeta)\bigl(\lambda_0(F)+\lambda_1(F)\bigr)\le 2-\chi,
\qquad
 \mu_0\lambda_0(F)+\mu_1\lambda_1(F)
 \le \frac{\mu_{\max}(2-\chi)}{1-\zeta},
\tag{3.3}
\]
where \(\mu_{\max}=\max\{\mu_0,\mu_1\}\).

If the complement of the two clusters contributes at most \(\varepsilon_\star\) to
the agreement mass of every vertex word, then any global-word guarantee of mass
\(\kappa(\delta)\) must satisfy
\[
 \kappa(\delta)-\varepsilon_\star
 \le \frac{\mu_{\max}(2-\chi)}{1-\zeta}.
\tag{3.4}
\]
Moreover, if \(\lambda_{K,1}\) is the second singular value of the weighted
\(X(1)\)--\(X(K)\) inclusion graph, expander mixing gives
\[
 \chi\ge
 \left[1-\lambda_{K,1}
 \bigl(\mu_0^{-1/2}+\mu_1^{-1/2}\bigr)\right]_+,
\tag{3.5}
\]
and hence
\[
 \kappa(\delta)-\varepsilon_\star
 \le \frac{\mu_{\max}}{1-\zeta}
 \left(1+\lambda_{K,1}
 \bigl(\mu_0^{-1/2}+\mu_1^{-1/2}\bigr)\right).
\tag{3.6}
\]
For \(\mu_0,\mu_1\ge\mu_\star\), the final factor can be replaced by
\(1+2\lambda_{K,1}/\sqrt{\mu_\star}\).

#### Proof

Write
\[
 g_i(A):=\frac1K\bigl|\{v\in A:\tau_F(v)=i\}\bigr|.
\]
On a face counted by \(\lambda_i(F)\), \(g_i(A)\ge1-\zeta\), so
\[
 \mathbb E_{\nu_i}[\mathbf 1_{\{\tau_F=i\}}]\ge(1-\zeta)\lambda_i(F).
\]
The two tags are mutually exclusive at every vertex, hence the sum of the two
expectations is at most
\(\sum_v\max\{\nu_0(v),\nu_1(v)\}=2-\chi\). This proves (3.3), and the
complement gives (3.4). Finally, expander mixing gives
\(\operatorname{TV}(\nu_i,\mu_1)\le\lambda_{K,1}/\sqrt{\mu_i}\); the triangle
inequality gives (3.5), and substituting it into (3.4) gives (3.6). \(\square\)

For the GMWZ HDX, the cited inclusion estimate has
\(\lambda_{K,1}=1/K+K^{O(1)}/d\). Thus, for heavy clusters of mass at least
\(\mu_\star\), choosing \(d\) so that
\(K^{O(1)}/d=o(\sqrt{\mu_\star})\) makes the correction factor in (3.6)
\(1+o(1)\). The proposition therefore closes the separated-tag/vertex-support
escape whenever the proposed DPT mass exceeds the resulting mass bound. It does
not remove the independent mass-gap, payload-synchronization, or cover-sheet
binding obligations.

### Proposition 3.2 (multicluster overlap gate)

The same incidence argument extends from two clusters to an arbitrary finite tag
alphabet. Let \(U_1,\ldots,U_s\subseteq X_i(K)\) be pairwise disjoint clusters of
masses \(\mu_1,\ldots,\mu_s\), and let \(\nu_a\) be the vertex law obtained by
sampling a face from \(U_a\) and then a uniformly random vertex of that face. Define

\[
 \mathsf{Ov}(\nu_1,\ldots,\nu_s)
 :=\sum_{v\in X_i(1)}\max_{1\le a\le s}\nu_a(v).
\tag{3.7}
\]

For nonuniform cluster masses, define the sharper mass-weighted overlap
\[
 \mathsf{Ov}_{\mu}(\nu_1,\ldots,\nu_s)
 :=\sum_{v\in X_i(1)}\max_{1\le a\le s}\{\mu_a\nu_a(v)\}.
\tag{3.7w}
\]

For a vertex word \(F\), allow an arbitrary tag
\(\tau_F(v)\in\{1,\ldots,s,\bot\}\), and let \(\lambda_a(F)\) be the fraction of
faces from \(U_a\) on which \(F\) agrees with the prescribed cluster-\(a\) table up
to relative symbol error \(\zeta\). If a tag mismatch costs at least one symbol
error, then

\[
 (1-\zeta)\sum_{a=1}^s\lambda_a(F)
 \le \mathsf{Ov}(\nu_1,\ldots,\nu_s),
\qquad
 \sum_{a=1}^s\mu_a\lambda_a(F)
 \le \frac{\mu_{\max}}{1-\zeta}\mathsf{Ov}(\nu_1,\ldots,\nu_s).
\tag{3.7a}
\]

More sharply,
\[
 \sum_{a=1}^s\mu_a\lambda_a(F)
 \le \frac{\mathsf{Ov}_{\mu}(\nu_1,\ldots,\nu_s)}{1-\zeta}.
\tag{3.7aw}
\]

If the complement of \(\bigcup_aU_a\) contributes at most \(\varepsilon_\star\) to
the agreement mass of every candidate vertex word, then

\[
 \kappa(\delta)-\varepsilon_\star
 \le \frac{\mu_{\max}}{1-\zeta}\mathsf{Ov}(\nu_1,\ldots,\nu_s).
\tag{3.7b}
\]

The right-hand side in (3.7b) may equivalently be replaced by
\(\mathsf{Ov}_{\mu}/(1-\zeta)\).

Moreover, if the weighted \(X(1)\leftrightarrow X(K)\) inclusion operator has
nontrivial singular value at most \(\lambda_{K,1}\), then

\[
 \mathsf{Ov}(\nu_1,\ldots,\nu_s)
 \le 1+\lambda_{K,1}\sum_{a=1}^s\mu_a^{-1/2}.
\tag{3.7c}
\]

Consequently, if \(\mu_a\ge\mu_\star\) for every \(a\),

\[
 \kappa(\delta)-\varepsilon_\star
 \le \frac{\mu_{\max}}{1-\zeta}
 \left(1+\frac{s\lambda_{K,1}}{\sqrt{\mu_\star}}\right).
\tag{3.7d}
\]

The weighted overlap has the stronger estimate
\[
 \mathsf{Ov}_{\mu}
 \le \mu_{\max}
 +\lambda_{K,1}\sum_{a=1}^s\sqrt{\mu_a}
 \le \mu_{\max}+\lambda_{K,1}\sqrt{s\mu_U},
\qquad \mu_U:=\sum_{a=1}^s\mu_a,
\tag{3.7dw}
\]
because
\[
\max_a\{\mu_a\nu_a(v)\}\le
\mu_{\max}\mu_1(v)+\sum_a\mu_a(\nu_a(v)-\mu_1(v))_+.
\]
Thus (3.7b) also admits the bound
\[
 \kappa(\delta)-\varepsilon_\star
 \le
 \frac{\mu_{\max}+\lambda_{K,1}\sum_a\sqrt{\mu_a}}{1-\zeta}.
\tag{3.7ew}
\]

For the GMWZ estimate \(\lambda_{K,1}=1/K+K^{O(1)}/d\), the entire
vertex-varying \(s\)-tag escape is therefore closed whenever

\[
 s\left(\frac1K+\frac{K^{O(1)}}d\right)=o(\sqrt{\mu_\star}),
\tag{3.7e}
\]

and the proposed global-word mass exceeds the right side of (3.7d).
For nonuniform clusters, a sharper sufficient window is
\(\lambda_{K,1}\sqrt{s\mu_U}=o(\mu_{\max})\), with the residual
\(\mu_{\max}/(1-\zeta)\) term absorbed into the mass gap.  Equal-mass
clusters recover the same order as (3.7e).

#### Proof

On a face counted by \(\lambda_a(F)\), at least a \(1-\zeta\) fraction of its
vertices carry tag \(a\). Hence
\[
 \mathbb E_{v\sim\nu_a}{\bf1}[\tau_F(v)=a]
 \ge (1-\zeta)\lambda_a(F).
\]
The tags are mutually exclusive at each vertex, so summing over \(a\) is bounded by
\(\sum_v\max_a\nu_a(v)\), which proves (3.7a). The complement gives (3.7b).
Expander mixing gives
\(\operatorname{TV}(\nu_a,\mu_1)\le\lambda_{K,1}/\sqrt{\mu_a}\). Since
\[
 \sum_v\max_a\nu_a(v)
 \le 1+\sum_a\operatorname{TV}(\nu_a,\mu_1),
\]
we obtain (3.7c), and (3.7d) follows from the heavy-mass assumption. For the
weighted form, multiplying the per-cluster inequality by \(\mu_a\) before
summing gives
\[
 \sum_a\mu_a\nu_a(v){\bf1}[\tau_F(v)=a]
 \le \max_a\{\mu_a\nu_a(v)\}.
\]
Summing over vertices proves (3.7aw). The pointwise inequality displayed in
(3.7dw), followed by the same total-variation estimate, proves (3.7dw) and
(3.7ew). \(\square\)

This is the high-order incidence form of Proposition 3.1. It is a source-specific
closure gate: it does not rule out a non-patchable global assignment, a cover-lift
word, or a construction whose cluster count violates (3.7e). The remaining mass gap
and payload/cover binding obligations are therefore explicit rather than hidden in a
binary-tag assumption.

## 4. What the theorem closes

The theorem rules out the following black-box inference on this source:

> ordinary shared-top DPT, distributional soundness, or list soundness automatically yields a
> single base-address global word.

Any successful use of this source must instead do at least one of the following: bind the cover
sheet at the target address scale, add a coordinate-normalized outer check, use a cover-free
source, or explicitly change the object from a base word to a cover-lift word.

## 5. Scope and non-claims

This is a source-specific theorem. It does not prove that all HDX sources have covers of this
kind, that all dPCPs fail, or that RLDC/LDC lower bounds follow automatically. It also does not
close a non-patchable global assignment or the actual RW history attachment. Those are separate
mathematical problems and are tracked in the fourth paper of this directory.

## References

- Bafna, Minzer, Vyas, and Yuen, arXiv:2407.12762:
  <https://arxiv.org/html/2407.12762>.
- Dikstein and Dinur, arXiv:2308.09582:
  <https://arxiv.org/html/2308.09582>.
- Dikstein, Dinur, and Lubotzky, arXiv:2402.01078:
  <https://arxiv.org/html/2402.01078>.
- Gur, Minzer, Weissenberg, and Zheng, arXiv:2512.12960:
  <https://arxiv.org/html/2512.12960>.
- Goldberg, Gur, and Saraogi, arXiv:2511.21659:
  <https://arxiv.org/abs/2511.21659>.
- Project sources: [cover closure note](../../../mcsp-hardness-magnification/notes/202-bmvy-ddl-parameter-closure-for-cover-obstruction-2026-08-16.md)
  and [incidence-profile closure note](../../../mcsp-hardness-magnification/notes/203-bmvy-incidence-profile-closes-arbitrary-right-label-patch-2026-08-16.md).
