# Distributional Soundness Does Not By Itself Produce a Global Word

## Abstract

Distributional and list-decoding soundness are often treated as if they supplied one global
object explaining every local answer. We isolate the missing quantifier. A theorem of the form

\[
 \forall z\ \exists s(z)\quad
 \Pr_J[D_J(z)\ne y^{(s(z))}_J]\le\varepsilon
\]

already yields an indexed channel when the candidate words are separated: sampling
\(O(\log L/(\Delta-2\varepsilon)^2)\) coordinates identifies the global word. By contrast,
coordinatewise or random-tape-dependent ideal words do not imply such a channel. We give an
explicit sharp separation using the valid language \(\{0,1\}^n\setminus\{1^n\}\), where the
error is (1/n) but no single valid word explains the rejected candidate across all coordinates.

We also record a positive singleton-output bridge: if every valid assignment has the same
target projection, then distributional soundness can imply coordinate soundness without
requiring the ideal witness to be globally unique. This identifies the precise construction
target for a shared-proof dPCP: target-output concentration and a local projection in one
address space. Under an additional no-bottom condition, the same bridge has a sharp coding
consequence: the inline interface is a three-query adaptive LDC (and in general only an
RLDC), so cubic LDC lower bounds apply. Neither ordinary list soundness nor the
existence of a near-linear RLDC supplies these two properties automatically.

We further give a quantitative decoupling test. If the random ideal word carries only
small mutual information with the full local transcript (including the sampled coordinate
and decoded symbol), Pinsker's inequality replaces it by one fixed valid word. Thus a
distributional construction must either pay transcript information or enter the indexed
channel/RLDC regime; controlling the coordinate marginal alone is insufficient.

Our strongest uniformity result is a connected-neighborhood theorem. If the transcript laws
of Hamming-adjacent near proofs differ by at most τ in total variation, then
\(2(\varepsilon+\sqrt{(\ln2/2)\iota})+\tau<\Delta\) forces one separated global word
to explain every proof in the entire neighborhood. If no such word exists, some adjacent
proofs have a transcript jump at least \(\Delta-2\alpha\), yielding an explicit
query-peak/descriptor obstruction rather than an informal witness-switching argument.

Finally, for an injective code-image proof map, we combine this uniformization test with a
pathwise Lorenz bound. In the coding-scale regime where the proof alphabet is subexponential
in the message length, a constant query peak is already large enough to pay the Lorenz
alternative. The remaining escape is therefore transcript/separation failure or growing
adaptive locality, rather than an unaccounted-for peak branch.

We also give a direct positive composition: a singleton/global-word theorem with transcript
continuity, combined with a \(\lambda\)-smooth outer decoder, yields one shared-proof ACRR with wrong
claim probability at most \(q_D\chi\alpha\). Thus the distributional route either closes
to the RLDC barrier or exposes a quantitative query peak; it cannot remain at the level of
an untracked proof-dependent word choice.

## 1. Global-word hypothesis

Let (Y=\{y^{(1)},\ldots,y^{(L)}\}\subseteq\Gamma^M) have pairwise relative distance at
least \(\Delta>0\). A common proof oracle (z) supports coordinate decoders (D_j), each
using at most (q) queries. The strong distributional hypothesis is

\[
 \forall z\ \exists s(z)\in[L]:
 \Pr_{J\sim[M]}[D_J(z)\ne y^{(s(z))}_J]\le\varepsilon,
 \qquad \varepsilon<\Delta/2.
\tag{1.1}
\]

The index (s(z)) is selected before the coordinate (J), and is shared by all sampled
coordinates.

## 2. Global word implies an indexed channel

### Theorem 2.1

Under (1.1), if \(L=1\) the unique word is returned without sampling. For \(L\ge2\) and
every \(\eta\in(0,1)\), \(r\) independent coordinate samples identify the selected index
with failure probability at most \(\eta\), where

\[
 r=\left\lceil\frac{2\log((L-1)/\eta)}{(\Delta-2\varepsilon)^2}\right\rceil,
 \qquad
 rq=O\!\left(q\frac{\log(L/\eta)}{(\Delta-2\varepsilon)^2}\right).
\tag{2.1}
\]

The decoder samples \((J_1,\ldots,J_r)\), records \(D_{J_\ell}(z)\), and returns the unique
word with maximum agreement.

### Proof

Let \(s=s(z)\). For each competitor \(t\ne s\), the words differ on at least a
\(\Delta\)-fraction of coordinates. Hence the expected agreement score of \(s\) exceeds the
score of \(t\) by at least \(\Delta-2\varepsilon\). Hoeffding's inequality followed by a
union bound over \(L-1\) competitors gives (2.1). \(\square\)

If a common proof map \(\Pi(s)\) satisfies the same hypothesis throughout a radius-\(\rho\)
neighborhood of the target proof, then this sampler is a bounded-error relaxed index decoder,
and distinct proof words are separated by more than \(\rho\). This is exactly the entry point
to the indexed-label and RLDC barriers.

## 3. The quantifier separation

The global-word condition is stronger than the following two statements:

- for each coordinate (j), some valid word explains the local answer;
- for each random tape (R), some valid word (y(R)) explains all coordinates on that tape.

For (n\ge2), let

\[
 H_n=\{0,1\}^n\setminus\{1^n\}.
\]

Use the identity proof and a decoder that reads coordinate (j). For the illegal candidate
\(1^n\), choose a random coordinate (I\leftarrow[n]) and let the ideal valid word be
\(1^n-e_I\). For every fixed (j), the local view disagrees only when (I=j), so the
distributional error is (1/n). Nevertheless, there is no single word in (H_n) equal to
the illegal candidate on all coordinates, and the ideal word changes with the random tape.

Thus arbitrarily small distributional error does not create target concentration. The failure
is not a weakness of an average-over-coordinates slogan; it satisfies the fixed-coordinate
quantifier and isolates the missing \(\exists y\,\forall j\) structure.

### Theorem 3.1 (rectangularity criterion for global words)

The preceding example is the smallest instance of an exact black-box criterion. Let
\(\mathcal Y\subseteq\Gamma^M\) be the valid-word family and define
\[
 \operatorname{Rect}(\mathcal Y)=\prod_{j=1}^M\{y_j:y\in\mathcal Y\}.
\]
For \(\varepsilon\in[0,1]\), let
\[
 \mathcal Y_{\le\varepsilon}=
 \left\{z:\min_{y\in\mathcal Y}d_H(z,y)/M\le\varepsilon\right\}.
\]
Then the following are equivalent:

1. every word whose \(j\)-th coordinate is explained by some (possibly
   coordinate-dependent) member of \(\mathcal Y\) is \(\varepsilon\)-close to one
   member of \(\mathcal Y\);
2. \(\operatorname{Rect}(\mathcal Y)\subseteq\mathcal Y_{\le\varepsilon}\).

Indeed, the coordinatewise premise is exactly membership in the rectangular hull.
If the inclusion fails, choose \(z^\star\) in the hull but outside the neighborhood,
and for each coordinate choose a valid word agreeing with \(z^\star\) there. This
gives perfect coordinatewise realizability with no globally close valid word.
For \(\mathcal Y=\{0^M,1^M\}\), the hull is all of \(\{0,1\}^M\), so the
implication fails for every \(\varepsilon<1/2\).

This criterion identifies the exact missing condition in distributional/list
composition. A same-seed ideal word \(Y(S)\), a singleton target projection, or an
independent proof of rectangular-hull containment can close the gap. Ordinary
\(\forall j\,\exists y^{(j)}\) and random-tape-dependent \(\exists y(R)\) do not.
The result is a black-box separation theorem, not an impossibility theorem for a
concrete dPCP: a successful construction must prove the cross-coordinate coupling
at the RW/JK address scale.

### Theorem 3.2 (rectangularity--covering tradeoff)

The rectangularity criterion also has a quantitative coding consequence. Let
\(p_j=|\{y_j:y\in\mathcal Y\}|\), let \(d\) be the minimum Hamming distance
between distinct words in \(\mathcal Y\), and suppose
\[
 \operatorname{Rect}(\mathcal Y)\subseteq
 \bigcup_{y\in\mathcal Y}B_H(y,t).
 \tag{3.1}
\]
If \(V_\Gamma(M,t)=\sum_{\ell\le t}\binom M\ell(|\Gamma|-1)^\ell\), then
\[
 \sum_{j=1}^M\log_{|\Gamma|}p_j
 \le M-d+1+\log_{|\Gamma|}V_\Gamma(M,t).
 \tag{3.2}
\]
Indeed, the left side counts the rectangular hull, (3.1) covers it by
\(|\mathcal Y|\) Hamming balls, and the Singleton bound gives
\(|\mathcal Y|\le |\Gamma|^{M-d+1}\). Consequently, for relative distance
\(\Delta=d/M\) and radius \(t=\varepsilon M\),
\[
 \frac1M\sum_j\log_{|\Gamma|}p_j
 \le 1-\Delta+H_{|\Gamma|}(\varepsilon)+o(1).
 \tag{3.3}
\]
If every coordinate has the full alphabet projection \(p_j=|\Gamma|\), then
\(\Delta\le H_{|\Gamma|}(\varepsilon)+o(1)\). Thus a separated, symbol-rich
valid-word family cannot have small-radius black-box coordinatewise closure. The
general theorem exposes the precise tradeoff: a construction must lower projection
entropy, lower word distance, increase correction radius, or prove a joint coupling
that escapes the rectangular-hull model. This is a coding theorem for the interface,
not an unconditional impossibility result for all dPCPs.

### Theorem 3.3 (product-rectangular anti-concentration)

There is also a probabilistic form of the barrier. Let
\(\mathcal P_j=\pi_j(\mathcal Y)\), let \(p_j=|\mathcal P_j|\), and sample
\(Z_j\) independently and uniformly from \(\mathcal P_j\). For every radius \(t\),
\[
 \Pr\left[\min_{y\in\mathcal Y}d_H(Z,y)\le t\right]
 \le \min\left\{1,
 \frac{|\mathcal Y|V_{|\Gamma|}(M,t)}{\prod_jp_j}\right\}.
 \tag{3.4}
\]
If the minimum distance is \(d\), Singleton gives the stronger numerator
\(|\Gamma|^{M-d+1}V_{|\Gamma|}(M,t)\). In the full-projection case
\(p_j=|\Gamma|\), with \(t=\varepsilon M\), this is
\[
 \Pr[Z\text{ is }\varepsilon\text{-close to }\mathcal Y]
 \le |\Gamma|^{1-M(\Delta-H_{|\Gamma|}(\varepsilon))+o(M)}.
 \tag{3.5}
\]
Thus if \(\Delta>H_{|\Gamma|}(\varepsilon)\), independent coordinatewise
explanations are exponentially unlikely to form one global word. The proof is a
union bound: every supported word has probability \((\prod_jp_j)^{-1}\), and each
valid word covers at most \(V_{|\Gamma|}(M,t)\) supported words.

This is the probabilistic counterpart of Theorem 3.2. It cleanly separates
coordinate/product mixing from a genuine same-seed distribution: if one seed first
selects a complete word and all coordinates reuse it, the product calculation does
not apply. Therefore any distributional route that survives (3.4) must exhibit a
joint seed/strategy, lower projection entropy, lower word distance, enlarge the
correction radius, or pay an explicit correlation channel.

### Theorem 3.4 (correlation cost of distributional closure)

The product bound interpolates quantitatively to correlated coordinate answers. Let
\(U\) be the product of the uniform coordinate projections \(\pi_j(\mathcal Y)\),
and let \(\mu\) be any joint distribution with those same marginals. For
\(A_t=\{z:\min_{y\in\mathcal Y}d_H(z,y)\le t\}\), data processing gives
\[
 D_2(\mu\|U)\ge d_2\bigl(\mu(A_t)\,\|\,U(A_t)\bigr).
 \tag{3.6}
\]
In particular, if \(\mu(A_t)\ge p_0>0\), then
\[
 D_2(\mu\|U)\ge p_0\log_2\frac1{U(A_t)}-1.
 \tag{3.7}
\]
Combining with (3.5), full projections and
\(\Delta>H_{|\Gamma|}(\varepsilon)\) force
\[
 D_2(\mu\|U)\ge
 p_0M\bigl(\Delta-H_{|\Gamma|}(\varepsilon)\bigr)\log_2|\Gamma|-o(M).
 \tag{3.8}
\]
For equal uniform marginals, \(D_2(\mu\|U)\) is exactly the total correlation
\(\sum_jH_2(Z_j)-H_2(Z)\). Hence non-negligible global-word probability requires
linear cross-coordinate dependence in the high-distance regime. A one-bit seed can
still generate a highly correlated distribution such as
\(\tfrac12\delta_{0^M}+\tfrac12\delta_{1^M}\), so this theorem measures joint
statistical correlation rather than automatically lower-bounding seed length.
It rules out the claim that same-word concentration can arise for free from
independent coordinate witnesses or random-tape choices without a common coupling.

### Theorem 3.5 (conditional-independence entropy barrier)

The correlation-cost statement has a conditional-product form that directly models
a common policy with independent coordinate responses. Let \(S\) be any policy or
randomness variable and suppose that, conditioned on \(S=s\), the coordinates
\(Z_1,\ldots,Z_M\) are independent. Write
\[
 h_j(s)=H_\infty(Z_j\mid S=s),
 \qquad h(s)=\sum_jh_j(s).
\]
If \(h(s)\ge H\) outside a policy set of mass \(\delta\), then
\[
 \Pr[Z\text{ is }t\text{-close to }\mathcal Y]
 \le
 \delta+(1-\delta)|\mathcal Y|V_{|\Gamma|}(M,t)2^{-H}.
 \tag{3.9}
\]
Singleton replaces \(|\mathcal Y|\) by
\(|\Gamma|^{M-d+1}\). In the full-projection/high-distance regime, (3.9) has
the following precise consequence: if \(p-\delta\) is bounded below by a positive
constant and \(\Delta-H_{|\Gamma|}(\varepsilon)\) is positive, then the policy-good
mass must contain a non-negligible set on which the coordinate min-entropy deficit is
linear. The hypothesis \(p>\delta\) is essential;
without it, the exceptional policy set alone can account for all successes. The
quantitative conditional-correlation version with this explicit success margin is
stated in Theorem 3.5A.
The proof is a conditional version of the union-bound argument: every vector has
conditional probability at most \(2^{-h(s)}\), while the target neighborhood has
at most \(|\mathcal Y|V\) vectors. This theorem does not apply to residual
post-policy joint correlation; that residual correlation is precisely the extra
global coupling a successful construction would need. It also does not claim that
the deficit lower-bounds the seed length, since a short seed can deterministically
generate a long correlated word.

### Theorem 3.5A (conditional-correlation barrier)

The residual-correlation escape can be quantified without assuming conditional
independence. Let \(\mu_s\) be the conditional law of \(Z\) given a policy value
\(S=s\), and let \(\nu_s=\bigotimes_j\mu_{s,j}\) be the product of its conditional
coordinate marginals. Define
\[
  \operatorname{TC}_2(s):=D_2(\mu_s\Vert\nu_s)
  =\sum_jH_2(Z_j\mid S=s)-H_2(Z\mid S=s).
\tag{3.10A}
\]
Suppose a policy-good event \(G\) has mass at least \(1-\delta\), every \(s\in G\)
satisfies \(h(s)\ge H\), and
\[
  B:=|\mathcal Y|V_{|\Gamma|}(M,t)2^{-H}\le1.
\]
If \(p=\Pr[Z\text{ is }t\text{-close to }\mathcal Y]>\delta\), then
\[
 \mathbb E[\operatorname{TC}_2(S)\mid G]
 \ge
 \frac{p-\delta}{1-\delta}\log_2\frac1B-1.
\tag{3.10B}
\]
In the full-projection regime with relative distance \(\Delta=d/M\),
\(t=\lfloor\varepsilon M\rfloor\), and
\(H\ge M(\log_2|\Gamma|-\zeta)\), Singleton and the Hamming-ball volume bound give
\[
 \log_2\frac1B\ge
 M\bigl((\Delta-H_{|\Gamma|}(\varepsilon))\log_2|\Gamma|-\zeta\bigr)
 -O_{|\Gamma|}(\log M).
\tag{3.10C}
\]
Therefore, if the bracket is positive, constant global-word success forces
\(\Omega(M)\) conditional total correlation on the good policy mass, unless that
mass is itself bounded away from one.

#### Proof

For \(s\in G\), every atom of \(\nu_s\) has probability at most \(2^{-H}\), so
\(\nu_s(\mathcal A_t)\le B\), where \(\mathcal A_t\) is the \(t\)-neighborhood of
\(\mathcal Y\). Applying data processing to the indicator of \(\mathcal A_t\) and
writing \(p_s=\mu_s(\mathcal A_t)\) gives
\[
 \operatorname{TC}_2(s)\ge
 p_s\log_2(1/B)-h_2(p_s)\ge p_s\log_2(1/B)-1.
\]
Averaging over \(G\), and using
\(p\le\delta+(1-\delta)\mathbb E[p_S\mid G]\), proves (3.10B). Equation
(3.10C) is the Singleton plus volume estimate. \(\square\)

This theorem interpolates Theorem 3.4 and Theorem 3.5: zero conditional total
correlation recovers the conditional-product endpoint, while a trivial policy with
uniform marginals recovers the fixed-marginal correlation cost. It charges
statistical dependence, not the description length of a short latent seed; the latter
remains covered by the information gate in Theorem 3.6.

### Corollary 3.5B (target-channel trichotomy)

Let \(M\) be uniform on \(\mathcal M\), let
\(Y:\mathcal M\hookrightarrow\Gamma^M\) be injective with minimum distance greater
than \(2t\), and let \(Z\)
be any output jointly distributed with a policy \(S\).  If
\[
 p=\Pr[d_H(Z,Y(M))\le t],
\]
then
\[
\begin{aligned}
 I_2(M;S)
 &+\sum_{j=1}^{M} I_2(M;Z_j\mid S)
 +\mathbb E[\operatorname{TC}_2(Z\mid M,S)]\\
 &\ge p\log_2|\mathcal M|-1.
\end{aligned}
\tag{3.10D}
\]
Indeed,
\[
 I_2(M;S,Z)=I_2(M;S)+\sum_j I_2(M;Z_j\mid S)
 -\operatorname{TC}_2(Z\mid S)+\operatorname{TC}_2(Z\mid M,S),
\]
while nearest-word decoding and Fano give
\(I_2(M;S,Z)\ge I_2(M;Z)\ge p\log_2|\mathcal M|-1\).  Nonnegativity of
\(\operatorname{TC}_2(Z\mid S)\) proves the claim.  Thus a short policy and
low-information coordinate marginals are compatible with global decoding only if
the responses retain large target-conditioned joint correlation.  With independent
private randomness conditioned on \((M,S)\), the last term is zero.

### Theorem 3.6 (Fano--entropy policy closure gate)

There is a direct target-information companion. Let
\(Y:\mathcal M\to\Gamma^N\) have minimum distance \(d>2t\), let \(M\) be uniform,
and suppose a full-word output \(Z\) is generated from a policy \(S\) and fresh
randomness so that \(M\to S\to Z\). If
\[
 p=\Pr[d_H(Z,Y(M))\le t],
\]
then
\[
 I_2(M;S)\ge
 \log_2|\mathcal M|-h_2(1-p)-(1-p)\log_2(|\mathcal M|-1)
 \ge p\log_2|\mathcal M|-1.
 \tag{3.11}
\]
This is Fano plus data processing through the nearest-codeword decoder. Combined
with Theorems 3.5 and 3.5A, any policy-generated global word with constant success
must pay one of three costs: linear target information in \(S\), a linear conditional
min-entropy collapse on a non-negligible policy mass, or linear residual joint
correlation after conditioning on \(S\). The Markov condition is explicit: if the target is
still supplied as a separate input to the word generator, it has not been compressed
into the policy and this theorem does not apply automatically.

### Theorem 3.7 (transcript-information decoupling)

Let \(J\in[M]\) be the sampled coordinate, let \(X\in\Gamma\cup\{\bot\}\) be the local
decoder output, and let \(T=(J,X,U)\) be any finite transcript containing \(J\) and \(X\).
The auxiliary variable \(U\) may contain verifier randomness, proof answers, or any public
local view. Let \(Y\in\mathcal Y\subseteq\Gamma^M\) be a random ideal word, with no
independence assumption from \(T\). Count \(X=\bot\) as an error. If

\[
  \Pr[X\ne Y_J]\le\varepsilon,
  \qquad I_2(Y;T)\le\iota,
\tag{3.12}
\]

where mutual information is measured in bits, then there is a fixed
\(y^\star\in\mathcal Y\) such that

\[
  \Pr_T[X\ne y^\star_J]
  \le
  \varepsilon+\sqrt{\frac{\ln 2}{2}\,\iota}.
\tag{3.13}
\]

#### Proof

Let \(P\) be the joint law of \((Y,T)\) and \(Q=P_Y\otimes P_T\). Pinsker's inequality
with bits gives

\[
  \lVert P-Q\rVert_{\mathrm{TV}}
  \le
  \sqrt{\frac{\ln 2}{2}I_2(Y;T)}
  \le
  \sqrt{\frac{\ln 2}{2}\,\iota}.
\tag{3.14}
\]

For \(E=\{(y,t):X(t)\ne y_{J(t)}\}\), (3.12) and (3.14) imply

\[
  Q(E)\le
  \varepsilon+\sqrt{\frac{\ln 2}{2}\,\iota}.
\tag{3.15}
\]

Under \(Q\), \(Y\) is independent of \(T\), so \(Q(E)\) is the average, over
\(y\sim P_Y\), of \(\Pr_{T\sim P_T}[X(t)\ne y_{J(t)}]\). One \(y^\star\) in the
support of \(P_Y\) attains at most this average, proving (3.13). \(\square\)

The contrapositive is quantitative. If every fixed \(y\in\mathcal Y\) has transcript
error at least \(\varepsilon+\gamma\), then

\[
  I_2(Y;T)\ge\frac{2\gamma^2}{\ln 2}.
\tag{3.16}
\]

If \(\mathcal Y\) has relative distance at least \(\Delta\) and

\[
  \varepsilon_\star:=
  \varepsilon+\sqrt{\frac{\ln 2}{2}\,\iota}<\frac{\Delta}{2},
\tag{3.17}
\]

then (3.13) enters Theorem 2.1: \(O(\log L/(\Delta-2\varepsilon_\star)^2)\)
independent coordinate samples identify the fixed candidate word. This becomes an RLDC
consequence only when the same \(y^\star\) can be selected for every proof in the relevant
positive-radius neighborhood (for example, because one common seed/coupling is fixed
before the proof is chosen). Pointwise application of (3.13) may produce \(y^\star_z\)
depending on the nearby proof \(z\), which is not a codeword map and does not suffice for
RLDC soundness.

The transcript, rather than \(J\) alone, is essential. If \(Y\) is a uniformly random
codeword, \(J\) is independent uniform, and \(X=Y_J\), then \(I_2(Y;J)=0\), but
\(I_2(Y;(J,X))>0\). A bound on \(I(Y;S)\) for a policy descriptor \(S\) likewise does
not imply (3.12) when the local output carries additional target information. Conversely,
(3.12) applies even without a finite policy descriptor.

Thus ordinary distributional soundness does not automatically trigger this theorem: it
does not assert a small \(I_2(Y;T)\), nor does it choose one \(Y\) before the coordinate,
local randomness, and nearby-proof choice. Even pointwise decoupling does not provide the
uniform near-proof word needed for an RLDC. A proposed simultaneous coordinate-robust dPCP must either prove
the small-information hypothesis and obtain a fixed global word, or prove the lower bound
(3.16) and charge the resulting target information to its alphabet, query, descriptor, or
proof length. This is a quantitative bridge, not a general dPCP impossibility theorem.

### Theorem 3.8 (connected-neighborhood transcript uniformization)

The pointwise word in Theorem 3.7 becomes a single word on a whole proof neighborhood
under an explicit continuity hypothesis. Let \(\mathcal Z\) be a finite connected graph of
near-proof states. For each \(z\), let \(P_z\) be the law of a transcript
\(T_z=(J,X_z,U_z)\), with the same coordinate marginal \(\lambda\), and let
\(\mathcal Y\subseteq\Gamma^M\) have weighted separation below. If
\(|\mathcal Y|=1\), the conclusion is immediate; assume otherwise.

\[
  \Delta_\lambda=\min_{y\ne y'}\Pr_{J\sim\lambda}[y_J\ne y'_J].
\tag{3.18}
\]

Suppose that for every \(z\) there is a random \(Y_z\in\mathcal Y\) satisfying the
hypotheses of Theorem 3.7 with parameters \((\varepsilon,\iota)\), and that every edge
\(zz'\) has

\[
  \lVert P_z-P_{z'}\rVert_{\rm TV}\le\tau.
\tag{3.19}
\]

Put \(\alpha=\varepsilon+\sqrt{(\ln2/2)\iota}\). If

\[
  2\alpha+\tau<\Delta_\lambda,
\tag{3.20}
\]

then one word \(y^\star\in\mathcal Y\) satisfies

\[
  \Pr_{T_z}[X_z\ne y^\star_J]\le\alpha
  \qquad\text{for every }z\in\mathcal Z.
\tag{3.21}
\]

Indeed, Theorem 3.7 supplies a word \(y_z\) with error at most \(\alpha\) for each
\(P_z\). If \(y_z\ne y_{z'}\) on an edge, total variation gives
\(e_{z'}(y_z)\le\alpha+\tau\), while \(e_{z'}(y_{z'})\le\alpha\). The two error events
must together have probability at least \(\Delta_\lambda\), contradicting (3.20).
Connectivity propagates equality of the \(y_z\)'s.

The contrapositive is a concrete closure barrier: if no single word works on the connected
neighborhood, every connecting path contains an edge with transcript jump at least
\(\Delta_\lambda-2\alpha\). If the neighborhood has several transcript-connected
components, the theorem gives one word per component; the component index is then an
explicit cover-sheet or descriptor variable. This is the missing uniformity interface for
the RW/RLDC route. It remains a condition: ordinary dPCP or list soundness does not by
itself imply (3.19), and the theorem does not claim a \(P\ne NP\) consequence.

### Corollary 3.9 (smoothness-to-connectivity closure)

The TV hypothesis in Theorem 3.8 follows from a direct adaptive-query smoothness
condition. Let \(\mathcal Z\subseteq\Sigma^N\) be Hamming-connected, with edges joining
proofs that differ at one position. Couple executions on adjacent proofs with the same
random tape, and include queried addresses and returned symbols in the visible transcript.
If the differing position \(p\) is queried with probability at most \(\chi/N\) on every
proof in \(\mathcal Z\), then

\[
  \lVert P_z-P_{z'}\rVert_{\rm TV}\le\frac{\chi}{N}.
\tag{3.22}
\]

The executions are identical until the first query to \(p\); if that query never occurs,
their transcripts coincide. Thus the coupling disagreement probability is at most the
hit probability of \(p\). If only a per-step bound \(\chi/N\) is known for an adaptive
decoder of depth at most \(r\), a union bound gives \(\tau\le r\chi/N\).

Therefore Theorem 3.8 yields one common word whenever

\[
  2\alpha+\frac{\chi}{N}<\Delta_\lambda
  \quad\text{(or }\
  2\alpha+\frac{r\chi}{N}<\Delta_\lambda
  \text{ under per-step smoothness).}
\tag{3.23}
\]

This is a direct address-scale closure test. It does not construct a canonical selector
or recompile a proof. Its limitation is equally explicit: if the pointwise
information bound holds but (3.23) fails, the decoder must pay a query peak, transcript
information, or insufficient weighted word separation.

### Corollary 3.10 (information--query-peak dichotomy)

The smoothness assumption can be removed by exposing its exact failure mode. Under the
hypotheses of Theorem 3.8, let

\[
  h^\star=
  \max_{z\in\mathcal Z}\max_{p\in[N]}
  \Pr_{T_z}[\text{the decoder queries proof position }p].
\tag{3.24}
\]

Then either one \(y^\star\in\mathcal Y\) satisfies
\(\Pr_{T_z}[X_z\ne y^\star_J]\le\alpha\) for every \(z\), or

\[
  h^\star\ge\Delta_\lambda-2\alpha.
\tag{3.25}
\]

Indeed, if no common word exists, connectedness gives an edge whose pointwise words
differ. The two adjacent proofs differ at one position \(p\), and the same-random-tape
coupling gives transcript TV at most the probability of querying \(p\). Theorem 3.8's
contrapositive then yields (3.25). Under per-step \(\chi/N\)-smoothness and decoder depth
\(r\), the second branch reads \(r\chi/N\ge\Delta_\lambda-2\alpha\).

This is a structural closure gate, not by itself an RLDC lower bound. A source-specific
patchability theorem is still needed to turn the query peak into wrong-output probability.

### Corollary 3.11 (first-hit patchability closes the query-peak branch)

Fix a forcing target word \(y^{\mathrm{tar}}\), and assume every near-proof state has
target error at most \(\beta\). For every adjacent pair whose pointwise words from
Theorem 3.8 differ, let \(p\) be the changed proof position. Suppose the same-random-tape
coupling has a first-hit event \(H_{z,p}\) with

\[
  \Pr[H_{z,p}]=\Pr_{T_z}[\text{the decoder queries }p],
  \qquad
  \Pr[X_z\ne y^{\mathrm{tar}}_J\mid H_{z,p}]\ge\gamma.
\tag{3.26}
\]

The second condition is a source-specific one-position patchability assumption: the
first query to the changed position forces a non-\(\bot\) wrong output with respect to
the target. Then

\[
  \text{no common word}
  \quad\Longrightarrow\quad
  \beta\ge\gamma(\Delta_\lambda-2\alpha).
\tag{3.27}
\]

Indeed, Corollary 3.10 supplies an edge with query probability at least
\(\Delta_\lambda-2\alpha\), and (3.26) converts that probability into target error.
Consequently \(\beta<\gamma(\Delta_\lambda-2\alpha)\), together with target binding,
closes the same-proof Gate-I branch. The assumption is not a consequence of ordinary
average/list or distributional soundness; establishing it for the RW/JK history is the
remaining source-specific theorem problem.

### Corollary 3.12 (coding-scale uniformization--Lorenz closure)

Let

\[
  \Pi_k:\{0,1\}^k\longrightarrow\Sigma_k^{N_k}
\]

be injective, with \(A_k:=|\Sigma_k|\ge2\) and
\(N_k\le k(\log(k+2))^c\). Let \(\mathcal Z_k\) be a connected near-proof
neighborhood satisfying the hypotheses of Theorem 3.8, and take the valid-word family to
be the code image

\[
  \mathcal Y_k=\operatorname{Im}(\Pi_k).
\]

Write \(\delta_k=\Delta_{\lambda_k}(\mathcal Y_k)-2\alpha_k>0\), and let \(h_k\) be
the maximum single-position query probability over both \(\mathcal Z_k\) and honest proof
states. Assume the common-word branch has honest error \(\epsilon_k\), and that the
source-audited variable-query Lorenz implication

\[
  \epsilon_k+\Lambda_{\rho,k}\le\frac1{12}
  \quad\Longrightarrow\quad
  r_k\log(r_k+2)\ge\eta(\rho,c)(\log(k+2))^{1/3}
\tag{3.28}
\]

holds. If, for all sufficiently large \(k\),

\[
  \frac{\rho\,\delta_k\,k}{\log_2 A_k}>\frac1{12},
\tag{3.29}
\]

then at least one of the following holds:

\[
  \epsilon_k+\rho N_k r_k h_k>\frac1{12},
  \qquad
  r_k\log(r_k+2)\ge\eta(\rho,c)(\log(k+2))^{1/3},
\tag{3.30}
\]

or the transcript-information, separation, or connected-neighborhood hypotheses of
Theorem 3.8 fail. In particular, if \(\delta_k\ge\delta_0>0\) and
\(\log A_k=o(k)\), condition (3.29) is automatic; no first-hit patchability hypothesis
is needed for this coding-scale length/locality conclusion.

### Proof

If \(h_k<\delta_k\), Corollary 3.10 gives one common valid word on \(\mathcal Z_k\).
Because the valid family is \(\operatorname{Im}(\Pi_k)\), this word is \(\Pi_k(m)\) for
some message \(m\), so no separate target-binding assumption is needed. Each proof position
has expected honest transcript multiplicity at most \(r_kh_k\), and hence

\[
  \Lambda_{\rho,k}\le \rho N_k r_k h_k.
\]

If the first inequality in (3.30) fails, (3.28) gives the second one. On the other hand,
if \(h_k\ge\delta_k\), injectivity implies

\[
  A_k^{N_k}\ge2^k,
  \qquad N_k\ge k/\log_2 A_k.
\]

Together with \(r_k\ge1\) and (3.29), this yields
\(\rho N_k r_k h_k>1/12\), the first alternative in (3.30). \(\square\)

### Theorem 3.13 (smooth global-word closure to a shared-proof ACRR)

The preceding uniformization becomes a direct positive composition once the outer message
decoder is smooth. Let

\[
 C:\{0,1\}^{k}\hookrightarrow\Gamma^{M}
\]

be an outer code whose image has weighted relative distance at least
\(\Delta_\lambda>0\) under a fixed coordinate distribution \(\lambda\) on \([M]\).
Let \(\Pi:\{0,1\}^{k}\to\Sigma^{P}\) be a common proof map. For every codeword position
\(j\), let \(L_j\) be an adaptive local proof call using at most \(q_P\) proof queries and
returning a symbol in \(\Gamma\cup\{\bot\}\). Assume perfect local completeness:

\[
 L_j(\Pi(m))=C(m)_j
 \quad\text{with probability one for every }m,j.
\tag{3.13.1}
\]

For each message coordinate \(i\), let \(D_i\) be an adaptive decoder for \(C\) using at
most \(q_D\) codeword-symbol queries and satisfying
\(D_i^{C(m)}=m_i\) with probability one. Assume \(\lambda\)-smoothness on every honest
path: conditioned on the answers seen so far being the honest symbols, the next query
position obeys

\[
 \Pr[J_t=j]\le\chi\lambda_j
 \qquad(j\in[M]).
\tag{3.13.2}
\]

For each target \(m\), let \(\mathcal Z_m\) be the Hamming ball of radius \(\rho_P P\)
around \(\Pi(m)\), connected by one-position edges. For every \(z\in\mathcal Z_m\), let
\(T_z=(J,X_z,U_z)\) be the transcript of a local call with \(J\sim\lambda\), where
\(X_z=L_J(z)\). Suppose:

\[
 \Pr[X_z\ne (Y_z)_J]\le\varepsilon,
 \qquad I_2(Y_z;T_z)\le\iota
\tag{3.13.3}
\]

for some random \(Y_z\in\operatorname{Im}(C)\), and every adjacent \(z,z'\) satisfies

\[
 \lVert P_z-P_{z'}\rVert_{\mathrm{TV}}\le\tau.
\tag{3.13.4}
\]

Put \(\alpha=\varepsilon+\sqrt{(\ln2/2)\iota}\). If

\[
 2\alpha+\tau<\Delta_\lambda,
\tag{3.13.5}
\]

then the following hold:

1. For every target \(m\) and every \(z\in\mathcal Z_m\),
   \[
   \Pr_{J,L_J}[L_J(z)\ne C(m)_J]\le\alpha.
   \tag{3.13.6}
   \]
2. For every \(i\) and declaration \(b\), there is a verifier \(V_{i,b}\) using the same
   proof address space and at most \(q_Dq_P\) proof queries, such that
   \[
   V_{i,m_i}(\Pi(m))=1\quad\text{with probability one},
   \qquad
   \Pr[V_{i,1-m_i}(z)=1]\le q_D\chi\alpha
   \tag{3.13.7}
   \]
   for every \(z\in\mathcal Z_m\).

Consequently, if \(q_D\chi\alpha<1\), the proof map \(\Pi\) is a target-relative
coordinate-robust shared-proof interface. Here ACRR means that both claims use the same
proof address space, the honest branch is perfect on the target proof, and every
target-relative near proof has wrong-claim probability at most \(q_D\chi\alpha\); a bottom
output is allowed when neither threshold is reached. Thresholding both claim branches gives
an adaptive RLDC with locality

\[
 O\!\left(q_Dq_P(1-q_D\chi\alpha)^{-2}\right).
\tag{3.13.8}
\]

If the common-word conclusion fails, Corollary 3.10 instead exposes a
\(\Delta_\lambda-2\alpha\) query peak; the failure cannot be hidden solely in a
proof-dependent choice of global word.

#### Proof

Theorem 3.8 applied to the connected ball \(\mathcal Z_m\) gives one word
\(y_m^\star\in\operatorname{Im}(C)\) with error at most \(\alpha\) for every \(z\) in
the ball. At the honest proof, (3.13.1) gives zero error for \(C(m)\). If
\(y_m^\star\ne C(m)\), weighted separation would force
\(\Delta_\lambda\le\alpha\), contradicting (3.13.5). Hence
\(y_m^\star=C(m)\), proving (3.13.6).

To define \(V_{i,b}\), simulate \(D_i\). Whenever it asks for position \(j\), run
\(L_j(z)\) with fresh randomness; abort with rejection on \(\bot\), and feed a returned
symbol to the outer decoder. Accept exactly when the final decoder output is \(b\).
On the honest proof, all local calls return the correct symbols and perfect completeness
gives the first part of (3.13.7).

For the wrong declaration, couple the execution to the honest outer random tape. Until the
first local call returning a symbol different from \(C(m)_j\), the outer transcript is the
honest one. At an honest step, (3.13.2) and (3.13.6) give
\[
 \sum_j\Pr[J_t=j]\Pr[L_j(z)\ne C(m)_j]
 \le \chi\sum_j\lambda_j\Pr[L_j(z)\ne C(m)_j]
 \le\chi\alpha.
\]
There are at most \(q_D\) steps. If no first wrong local symbol occurs, the outer decoder
outputs \(m_i\), so it cannot accept \(1-m_i\). A union bound proves (3.13.7).
Finally, put \(\beta=q_D\chi\alpha\), repeat each branch
\(O((1-\beta)^{-2})\) times, and use the threshold
\(\theta=(1+\beta)/2\); output the unique branch above threshold and output \(\bot\)
otherwise. The wrong branch has mean at most \(\beta\) on every near proof, while the
correct branch has mean one on the target proof; Chernoff therefore gives the stated
relaxed-decoder guarantee and locality (3.13.8). \(\square\)

This is a composition interface, not a claim that existing GMWZ or RW constructions
already satisfy (3.13.3)--(3.13.4). Its value is to make the positive target exact: a
singleton/global-word theorem plus transcript continuity and a smooth outer decoder is
enough; if continuity fails, the failure is a quantitative query peak rather than an
untracked phantom-word choice.

## 4. Singleton-output bridge

Suppose a dPCP has one global proof address space and every valid proof assignment decodes to
the same output word (f_x\). If, for every candidate assignment and every target coordinate,
the distributional soundness exception is at most \(\delta), then the verifier

\[
 Q_{x,i,b}=1
 \quad\Longleftrightarrow\quad
 \text{local test accepts and the local output is }b
\]

has completeness one for (b=f_x[i]) and soundness at most \(\delta) for the opposite bit.
The proof is immediate: an accepted local view with the wrong output cannot agree with any
valid assignment, because all valid assignments have the same output projection.

This bridge does not require a unique valid witness. It does require three things that ordinary
list soundness does not provide for free:

1. a singleton target projection;
2. a fixed-coordinate soundness statement;
3. a local projection in the same global proof/address space.

### Corollary 4.1 (singleton coupling: RLDC and cubic LDC under no-bottom)

The singleton bridge has a useful second branch. Assume that the binary local verifier makes
at most two adaptive proof queries. For a target radius \(\rho\), write

\[
 \tau_{\rho/2}:=
 \inf_{x,i}\inf_{\operatorname{dist}(z,\Pi_x)\le\rho/2}
 \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr),
\tag{4.1}
\]

where \(p_{i,b}(z)\) is the acceptance probability of the local test together with the
claimed output bit \(b\). Suppose the singleton-output coupling holds, the wrong-bit branch
has error at most \(\delta\), and

\[
 \delta\le\frac13,
 \qquad
 \tau_{\rho/2}\ge\frac23+\delta .
\tag{4.2}
\]

Then the shared-proof interface yields the bounded-error relaxed decoder of
Theorem 2.1. Moreover, for the usual message-inline code
\(C(m)=m\,\|\,\Pi(m)\), the no-bottom condition gives a binary three-query
\emph{adaptive} locally decodable code. If the message length is \(k\) and the proof
length is \(P\), the three-query LDC lower bound gives

\[
 k+P=\Omega_{\rho,\delta}\!\left(\frac{k^3}{\log^6 k}\right).
\tag{4.3}
\]

Indeed, the singleton condition makes the correct output bit the only possible target bit.
It also forces the proof images to have relative distance greater than \(\rho\); the
binary Singleton bound then makes the inline code have a positive relative distance
depending only on \(\rho\). On reading the inline bit \(b\), run the corresponding
at-most-two-query verifier and
output \(b\) on acceptance and \(1-b\) on rejection. If \(b=m_i\), (4.2) and the
wrong-branch bound give error at most \(1/3\); if \(b\ne m_i\), the error is at most
\(\delta\le1/3\). This is a three-query adaptive LDC (one inline query plus two proof
queries). A nonadaptive expansion would instead use up to
\(1+2(2^2-1)=7\) queries, not three. The standard three-query LDC lower bound then
gives (4.3).

The no-bottom inequality (4.2) is essential. Without it, the singleton bridge still gives the
relaxed-decoding/RLDC branch, but a correct proof may be accepted only through a bottom symbol;
there is then no fixed-coordinate LDC decoder to which (4.3) can be applied. Thus the exact
remaining escape is semantic, not a missing union-bound constant: one must either tolerate
bottom, or prove a coordinate-robust no-bottom statement.

## 5. Consequences for the dPCP/RW program

Unique-decoding PCPs already contain the global-word quantifier; a composition that preserves
unique decoding, keeps candidate words separated, and permits efficient index selection enters
Theorem 2.1. A final list-decoding theorem does not automatically inherit this property. In
particular, replacing a separate ((i,b))-PCPP family by one short shared relation-PCPP is a
new theorem, not a notational simplification.

The near-linear RLDC construction of Gur--Minzer--Weissenberg--Zheng is therefore a strong
positive baseline but not a black-box solution to the RW/JK interface: its coordinate-specific
PCPP blocks are concatenated, while the present target requires a common relation proof and
address-scale target binding. Corollary 4.1 shows what a successful common relation proof would
buy under singleton concentration: it must either remain in the RLDC regime, or cross into a
three-query LDC regime subject to the cubic lower bound. This is a concrete coding-theoretic
barrier, rather than a claim that ordinary dPCP definitions are impossible.

Corollary 3.12 adds a complementary closure at the coding scale. Once the valid words are
literally the image of an injective proof map and the alphabet is subexponential in the
message length, a constant transcript-uniformization peak cannot remain a third independent
escape: it is already counted by the Lorenz mass. This is still conditional on the
transcript/separation hypotheses and the source-audited variable-query Lorenz implication;
it is not a general lower bound for dPCPs.

## 6. Scope and non-claims

This paper does not claim that every dPCP fails to have a global word, nor that singleton-output
systems are impossible. It identifies the exact additional condition a successful construction
must establish and gives the smallest counterexample to silently replacing it with distributional
soundness.

## References

- Dinur, Harsha, and Kopparty, distributional dPCP framework:
  <https://eccc.weizmann.ac.il/report/2015/085/>.
- Gur, Minzer, Weissenberg, and Zheng, arXiv:2512.12960:
  <https://arxiv.org/html/2512.12960>.
- Project modules: [global-word to indexed-list bridge](../../statements/global-distribution-to-indexed-list-bridge.md)
  and [unique decoding to global-word index](../../statements/udpcp-unique-decoding-to-global-word-index.md).
- The transcript uniformization--Lorenz trichotomy used in Corollary 3.12:
  [note 334](../../../mcsp-hardness-magnification/notes/334-uniformization-lorenz-query-peak-trichotomy-2026-08-18.md)
  and the [variable-query Lorenz envelope](../../statements/variable-query-imperfect-lorenz-envelope.md).
