# Shared-Proof Coordinate Robustness: Relaxed Local Decoding, Bottom Escape, and Compiler-Class Barriers

## Abstract

We isolate the coding-theoretic content of a single proof that is required to support
target-relative robustness for every message coordinate.  The central compiler is
quantifier-preserving: a common proof map with a constant correct-versus-wrong branch
gap, together with correct-branch completeness throughout the target-radius
neighborhood, gives a relaxed locally decodable code (RLDC), without assuming
linearity, projection structure, or nonadaptivity.  Perfect completeness yields a
sharper inline compiler.

Two consequences identify the first structural escape routes.  In the binary two-query
case, if simultaneous rejection (``bottom'') is absent on a half-radius neighborhood,
the inline compiler becomes a three-query ordinary LDC and incurs the near-cubic length
lower bound of Alrabiah--Guruswami--Kothari--Manohar.  For a fixed finite proof alphabet,
fixing the random tape and exposing the two adaptive decision trees gives a nonadaptive
RLDC; the lower bound of Goldberg--Gur--Saraogi then forces

\[
  Q=\Omega\!\left(\frac{\log k}{\log\log k}\right)
\]

for any near-linear proof.  Finally, a coordinate-flip argument applies to the whole
partition-and-agreement compiler class.  It gives an exact defect/error tradeoff and
shows that degree regularization or edge repetition cannot remove the obstruction.

The finite-view extension allows Merlin's strategy to be computationally unbounded: only
the public bits, observed response bits, and proof symbols visible to the verifier are
charged.  A near-linear common proof must expose a growing visible transcript or leave
the finite-view/all-policy model.

We also isolate a sharper binary gate: if each coordinate/claim has one fixed policy that is
perfectly complete for every target carrying that claim, then a one-query proof verifier
inline-compiles to a binary two-query RLDC. The 2026 exponential two-query lower bound then
rules out near-linear length outright. Thus bottom is an escape from the cubic ordinary-LDC
sharpening, not from this stronger uniform-policy subcase.

The same exponential gate survives target-dependent policies whenever their policy package
has sub-message mutual information. A high-entropy conditional fiber fixes one complete
claim-pair package on a linear-dimensional shattered submessage, reducing again to the
binary two-query theorem. Hence low-information target dependence is not a further
near-linear escape in this one-query window.

Even the selected-policy-only semantics admit a quantitative lift: a policy-vector
channel of sublinear entropy leaves a large common-policy fiber, and Sauer--Shelah turns
that fiber back into an RLDC.  Hence a remaining selected-policy escape must carry
essentially the full target entropy.  Under supportwise perfect completeness, the
quantitative version gives a continuous information--proof-length phase diagram: a fixed
fraction of unpaid target information forces a polynomially superlinear proof, with the
exponent inherited from the RLDC lower bound.  With only an \(\alpha\)-versus-\(\beta\) gap, the same
construction yields an imperfect-complete semantic RLDC; the cited GGS and binary
two-query lower bounds do not apply without an additional completeness-preserving lemma.
When all verifier randomness is a finite public tape, we give such a repair by enumerating
the finite proof-answer trees exactly; the price is an explicit \(2^r\) locality factor.
Combining that repair with the selected-policy entropy bound yields a finite-randomness
phase diagram: under a sublinear policy-information budget, near-linear proof length forces
the visible resource \(1+2^r\sum_{j<q}A^j\) to grow at least on the
\(\log k/\log\log k\) scale.

We also prove a completion-sensitive barrier for a different proposed escape: a dense
high-arity linear fold that is required to return a single-valued symbol throughout a
positive-radius raw neighborhood must query every raw coordinate with probability
\(1-2\varepsilon\). If the evaluator may output \(\bot\), the bound becomes
\(\max\{0,\nu-2\beta\}\), where \(\nu\) is the honest non-bottom mass and \(\beta\) is the
wrong-symbol error on completions. Thus high-arity folding avoids a linear payment only by
using substantial bottom mass, a nonlocal raw constraint, or a genuinely new global relation.

The main result is an information--proof-length theorem.  If the selected policy channel
reveals at most a \(\gamma<1\) fraction of a uniform \(K\)-bit target, then a linear-size
conditional fiber has a linearly large shattered coordinate set.  The common proof on that
fiber becomes an RLDC.  Current RLDC lower bounds consequently force either polynomially
superlinear proof length or growing visible locality.  Thus target-dependent strategies do
not evade the common-proof coding barrier for free: the missing target information must be
paid by the policy channel, the proof, or the visible verifier transcript.

The proof has three components: a quantifier-preserving proof-to-RLDC compiler, a
Sauer--Shelah conditional-fiber lemma, and a finite-randomness completeness repair.  The
bottom/LDC and one-query exponential statements are sharp corollaries, not separate paper
themes.  These results do not prove a general dPCP impossibility theorem or \(P\ne NP\).

## Main theorem

Let \(M\) be uniform on \(\{0,1\}^K\), let
\(\Pi:\{0,1\}^K\to\Sigma^P\), \(|\Sigma|=A\), be a common proof map, and let
\(S\) be the vector of target-selected coordinate policies.  Suppose every policy in the
conditional support of \(S\) has the target-relative correct-versus-wrong branch gap
\(\alpha>\beta\) on a fixed positive-radius neighborhood of \(\Pi(M)\).

### Theorem A (target-information/proof-length tradeoff)

Assume \(I(M;S)\le\gamma K\) for a fixed \(\gamma<1\), and let
\(h_2(\vartheta_\gamma)=1-\gamma\).  For every fixed
\(0<\varepsilon<\vartheta_\gamma\), put
\[
 d=\lfloor(\vartheta_\gamma-\varepsilon)K\rfloor .
\tag{A.1}
\]
There is a conditional policy fiber whose common proof, after inlining the \(d\) shattered
message coordinates, is a positive-radius RLDC of length \(d+P\).

If the selected branches are perfectly complete and compile to a nonadaptive
\(Q\)-query decoder with relaxed success parameter \(\sigma_0>0\), then, in the radius
window of Goldberg--Gur--Saraogi,
\[
 P\ge
 \left(
 \frac{\sigma_0^2d}
 {38Q^4\log_2^2(A+2)\log_2^2(d+2)}
 \right)^{1+1/\lceil Q/\sigma_0\rceil}-d.
\tag{A.2}
\]
In particular, fixed \(A,Q,\gamma,\sigma_0\) force
\[
 P=\Omega\!\left(
 \frac{K^{1+1/\lceil Q/\sigma_0\rceil}}
 {(\log K)^{2+2/\lceil Q/\sigma_0\rceil}}
 \right).
\tag{A.3}
\]

More generally, if each branch uses \(r\) public random bits and at most \(q\) adaptive
proof queries, exact exposure of its finite decision trees gives
\[
 Q=1+2^r\sum_{j<q}A^j.
\tag{A.4}
\]
For every near-linear proof \(P\le K(\log K)^c\),
\[
 Q=\Omega\!\left(\frac{\log K}{\log\log K}\right),
\qquad
 r+\log_2\sum_{j<q}A^j
 \ge \log_2\log K-\log_2\log\log K-O(1).
\tag{A.5}
\]

The proof is Theorems 4.3--4.7 below.  Its three reusable inputs are Theorem 2.2
(proof-to-RLDC compiler), the shattered-fiber argument in Theorem 4.3, and Theorem 4.6
(finite-randomness completeness repair).  The theorem is silent when the policy channel
carries essentially all \(K\) target bits; this boundary is necessary, since a constant
proof can be paired with a fully target-dependent policy.

### Relation to the 2025--2026 RLDC frontier

The coding lower bounds used here are external inputs, not contributions of this paper.
Goldberg--Gur--Saraogi prove the nonadaptive RLDC length inequality underlying (A.2).
Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu prove an exponential bound for binary
weak adaptive two-query RLDCs.  Gur--Minzer--Weissenberg--Zheng construct near-quadratic
three-query RLDCs, showing that bottom is a genuine escape from ordinary-LDC lower bounds.
Cheng--Li--Mao show that sufficiently small RLDC soundness instead yields an LDC.  The new
step here is the target-policy information reduction that turns a shared-proof verifier
into an RLDC on a large conditional fiber while preserving the relevant quantifiers.

## 1. The shared-proof interface

Let

\[
  \Pi:\{0,1\}^{k}\to\Sigma^{P}
\]

be a proof map, where \(\Sigma\) is a finite alphabet.  For every coordinate
\(i\in[k]\) and claimed bit \(b\in\{0,1\}\), let \(V_{i,b}\) be a randomized,
possibly adaptive verifier making at most \(q\) proof-symbol queries.  Write
\(p_{i,b}(z)\) for its acceptance probability on proof \(z\), and use relative Hamming
distance on \(\Sigma^{P}\).  The target-relative common-proof hypothesis is that there
are constants \(\rho>0\) and \(\alpha>\beta\) such that, for every message \(m\),

\[
 p_{i,m_i}(\Pi(m))\ge\alpha,
 \qquad
 \operatorname{dist}(z,\Pi(m))\le\rho
 \Longrightarrow
 \bigl(p_{i,m_i}(z)\ge\alpha
       \ \text{and}\ \ p_{i,1-m_i}(z)\le\beta\bigr) .
 \tag{1.1}
\]

The second line contains an explicit near-proof robust-completeness clause.  If only the
exact-proof completeness statement is available, the cross-message distance argument and
near-proof wrong-output control below still make sense, but RLDC completeness does not
follow.  The soundness is target-relative: it constrains the wrong branch near the target
proof, not every branch on every proof.  That quantifier is necessary for consistency when
two messages have different bits at the same coordinate.

## 2. A common proof already contains an RLDC

### Theorem 2.1 (common-proof robust-completeness compiler)

Under (1.1), distinct proof words have relative distance greater than \(\rho\).  Moreover,
for every fixed \(0<\eta<1/2\) and every \(\delta<\rho\), the map \(\Pi\) has a weak
adaptive relaxed local decoder of locality

\[
  Q=O\!\left(q(\alpha-\beta)^{-2}\log(1/\eta)\right),
  \tag{2.1}
\]

with completeness at least \(1-\eta\), wrong-output probability at most \(\eta\) on
every word within relative distance \(\delta\) of the target proof, and arbitrary output
\(\bot\) otherwise.

#### Proof

If \(m\ne m'\) and \(\operatorname{dist}(\Pi(m),\Pi(m'))\le\rho\), choose a
coordinate \(i\) with \(m_i\ne m'_i\).  Completeness for \(m'\) makes the branch
\(m'_i\) accept \(\Pi(m')\) with probability at least \(\alpha\), while (1.1) for
target \(m\) bounds the same branch by \(\beta\), a contradiction.

For decoding, repeat both claim verifiers independently
\(R=\Theta((\alpha-\beta)^{-2}\log(1/\eta))\) times and threshold each empirical
acceptance rate at \((\alpha+\beta)/2\).  Output the unique surviving claim and output
\(\bot\) if neither or both survive.  Hoeffding's inequality gives the stated
completeness and wrong-output bounds; the query count is \(2Rq\).  \(\square\)

The argument is deliberately agnostic about linearity and adaptivity.  An invocation of
an external RLDC lower bound still requires matching its alphabet, completeness,
radius, and adaptivity conventions.

### Theorem 2.2 (one-sided inline compiler)

Assume the binary interface has perfect correct-branch completeness and constant wrong
branch error:

\[
 p_{i,m_i}(\Pi(m))=1,
 \qquad
 \operatorname{dist}(z,\Pi(m))\le\rho
 \Longrightarrow p_{i,1-m_i}(z)\le\beta<1 .
 \tag{2.2}
\]

Then, for all sufficiently large \(k\),

\[
 C(m):=(m_1,\ldots,m_k)\Vert\Pi(m)\in\{0,1\}^{k+P}
 \tag{2.3}
\]

is a weak adaptive \((q+1,\delta_\rho,1-\beta)\)-RLDC with perfect completeness,
for a constant \(\delta_\rho>0\) depending only on \(\rho\).  The decoder reads the
inline bit \(m_i\), runs \(V_{i,m_i}\), outputs that claim on acceptance, and outputs
\(\bot\) otherwise.

#### Proof

The cross-message argument in the proof of Theorem 2.1, using the exact completeness and
near-proof wrong-claim clauses in (2.2), gives pairwise proof distance greater than
\(\rho\).  The binary Singleton bound therefore gives \(P/(k+P)\ge c_\rho>0\) for large
\(k\).  Choose
\(\delta_\rho\) so that a corruption of at most \(\delta_\rho(k+P)\) symbols leaves the
proof suffix within distance \(\rho P\) of \(\Pi(m)\).  If the inline bit is correct,
the decoder outputs \(m_i\) or \(\bot\); if it is wrong, (2.2) bounds the probability of
that wrong output by \(\beta\).  \(\square\)

The extra inline query is the precise cost of turning a target-relative two-branch test
into a decoder that does not know the target bit.

## 3. Bottom versus a cubic LDC

For the binary interface define the half-radius simultaneous-acceptance mass

\[
 \tau_{\rho/2}:=
 \inf_{m,i,z:\,\operatorname{dist}(z,\Pi(m))\le\rho/2}
       \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr).
 \tag{3.1}
\]

### Theorem 3.1 (bottom-or-cubic dichotomy)

Assume \(q=2\) and \(\beta\le 1/3\).  Either

\[
  \tau_{\rho/2}<\frac23+\beta,
  \tag{3.2}
\]

or the inline code from Theorem 2.2 is a constant-radius, three-query binary LDC.  In
the latter case, whenever the binary three-query lower bound of
Alrabiah--Guruswami--Kothari--Manohar applies to the resulting (possibly adaptive)
decoder,

\[
  k+P=\Omega_{\rho,\beta}\!\left(\frac{k^3}{\log^6 k}\right).
  \tag{3.3}
\]

#### Proof

Read the inline bit \(b\), run the verifier for claim \(b\), and output \(b\) on
acceptance and \(1-b\) on rejection.  If (3.2) fails, the two claim probabilities have
enough total mass on every half-radius near-proof to make the correct output occur with a
constant probability.  The target-relative wrong-branch bound controls the opposite
inline bit.  The distance and Singleton argument in Theorem 2.2 turns half-radius proof
closeness into a constant-radius inline-code promise.  The decoder uses the inline query
plus the two proof queries, hence three queries.  Equation (3.3) is the cited
three-query LDC lower bound.  \(\square\)

Thus bottom is a genuine structural escape in this parameter window: the proof is not
merely rejecting both claims on the same near-proof.

### Theorem 3.2 (uniform-policy two-query exponential gate)

The bottom branch is not a near-linear escape when the verifier has a fixed policy pair.
Let \(0<\rho<1\) and let \(\Pi:\{0,1\}^{k}\to\{0,1\}^{P}\) be binary. For each coordinate \(i\) and claim
\(b\), fix a one-query policy \(\tau_{i,b}\). For a constant \(\beta<1/2\), assume that
every target \(m\) satisfies

\[
 \Pr[V_{i,m_i}^{\tau_{i,m_i}}(\Pi(m))=1]=1
\]

and, whenever \(\operatorname{dist}(z,\Pi(m))\le\rho P\),

\[
 \Pr[V_{i,1-m_i}^{\tau_{i,1-m_i}}(z)=1]\le\beta .
\]

Then the binary inline map \(C(m)=m\Vert\Pi(m)\) is a weak adaptive
\((2,\delta,1-\beta)\)-RLDC for a constant \(\delta=\delta(\rho)>0\). By
Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu, Theorem 1
(arXiv:2602.20278),

\[
 k+P\ge 2^{\Omega_{\rho,\beta}(k)}.
\]

#### Proof

The two displayed hypotheses imply that distinct proof words have relative distance
greater than \(\rho\): otherwise choose a differing coordinate and use the policy that is
complete for the second target as the wrong policy for the first. If \(d\) is the minimum
absolute proof distance, the binary Singleton bound gives
\(k\le P-d+1<(1-\rho)P+1\). Thus, for \(k\ge2\),
\(P\ge k/[2(1-\rho)]\), and hence
\[
  \frac{P}{k+P}\ge\frac1{3-2\rho}.
\]
Fix, for example, \(\delta(\rho):=\rho/[4(3-2\rho)]\). A corruption of at most
\(\delta(\rho)(k+P)\) symbols changes fewer than \(\rho P\) proof symbols, and two
distinct inline codewords have distance greater than \(2\delta(\rho)(k+P)\), so the
RLDC promise has a unique target.

The decoder reads the inline bit \(b\), runs \(\tau_{i,b}\), and makes one proof query. It
outputs \(b\) on acceptance and \(\bot\) otherwise. Perfect completeness holds on every
codeword. In a constant-radius neighborhood, a correct inline bit can only yield the correct
bit or \(\bot\); a flipped inline bit yields the wrong bit with probability at most \(\beta\).
Thus relaxed success is at least \(1-\beta>1/2\), and the decoder is adaptive 2-query.
The cited exponential lower bound gives the conclusion. \(\square\)

This theorem is deliberately narrower than the finite-view compiler: it requires one fixed
policy pair per coordinate/claim, binary proof symbols, perfect completeness, and one proof
query. It does not apply to the general target-dependent policy semantics. In that general
setting, bottom can still escape the three-query ordinary-LDC upgrade, while
Theorems 4.1--4.2 give the appropriate finite-view RLDC barrier.

### Theorem 3.3 (low-information target-dependent exponential gate)

Let \(M\) be uniform on \(\{0,1\}^{K}\), let
\(\Pi:\{0,1\}^{K}\to\{0,1\}^{P}\) be a common proof map, and let \(S\) be a
target-dependent policy package.  For every package value \(s\), coordinate \(i\), and
claim \(b\), suppose \(V_{i,b}^{s}\) is a possibly randomized one-proof-query verifier.
Assume \(0<\rho<1\), \(\beta<1/2\), and, for almost every \(s\), every
\(m\) in the posterior support \(F_s=\{m:\Pr[M=m\mid S=s]>0\}\) satisfies

\[
 \Pr[V_{i,m_i}^{s}(\Pi(m))=1]=1,
\qquad
 \operatorname{dist}(z,\Pi(m))\le\rho P
 \Longrightarrow
 \Pr[V_{i,1-m_i}^{s}(z)=1]\le\beta .
\]

If \(I(M;S)\le\gamma K\) for a fixed \(\gamma<1\), then for every
\(\theta\) with \(H_2(\theta)<1-\gamma\), the restricted message family contains a
\(\theta K-o(K)\) dimensional shattered submessage \(J\), and

\[
 |J|+P\ge 2^{\Omega_{\rho,\beta}(|J|)}
       =2^{\Omega_{\rho,\beta,\gamma,\theta}(K)}.
\]

#### Proof

Since \(H(M\mid S)=K-I(M;S)\), a supportwise-good value \(s_\star\) has
\(H(M\mid S=s_\star)\ge(1-\gamma-o(1))K\).  Thus
\(|F_{s_\star}|\ge2^{(1-\gamma-o(1))K}\).  Sauer--Shelah gives a shattered
coordinate set \(J\) of size \(\theta K-o(K)\).  Choose one representative
\(m_u\in F_{s_\star}\) for every pattern \(u\in\{0,1\}^{J}\).

The policy package \(s_\star\) is common to all representatives.  If two proof
words were within \(\rho P\), a coordinate on which their patterns differ would
make the policy for the second claim both perfectly accepting on its own target
and accepting with probability at most \(\beta\) by the first target's soundness,
a contradiction.  Hence the restricted proof words have relative distance
greater than \(\rho\).  Singleton gives \(P/(|J|+P)\ge1/(3-2\rho)\) for large
\(|J|\), so \(\delta(\rho)=\rho/[4(3-2\rho)]\) is a valid constant inline radius.

The inline decoder reads the claimed bit, runs the corresponding fixed
\(V_{i,b}^{s_\star}\), and outputs \(b\) on acceptance and \(\bot\) otherwise.
It is a binary weak adaptive \((2,\delta(\rho),1-\beta)\)-RLDC.  Theorem 1 of
Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu gives the displayed exponential
bound. \(\square\)

The full conditional-support statement and its standard-Borel boundary are recorded in
[note 452](../../../mcsp-hardness-magnification/notes/452-low-information-target-dependent-policy-exponential-gate-2026-08-19.md).
The claim-pair package, rather than a policy for only the correct claim, is essential:
the inline decoder must know which verifier to run after a corrupted claim bit.  This
theorem does not apply to the published RW/JK singleton without a genuine target-family
lift, nor to ordinary average/list soundness.

## 4. Adaptive locality cannot be hidden in decision trees

### Lemma 4.0 (fixed-tape exposure)

Let a randomized adaptive decoder over an alphabet \(\Sigma\), \(|\Sigma|=A\), make at
most \(r\) proof-symbol queries on every random tape.  For a fixed tape, expose the full
\(A\)-ary decision tree and query the union of all internal nodes nonadaptively.  The
output distribution and every radius/completeness/soundness guarantee are unchanged, and
the query count is at most

\[
 T_r(A):=\sum_{j=0}^{r-1}A^j .
 \tag{4.1}
\]

If one inline symbol selects one of two branch verifiers, the union of both trees uses at
most \(1+2T_r(A)\) queries.

#### Proof

Querying every internal node reveals all symbols needed to simulate the path selected by
the received word.  The selected path and output are therefore identical to the adaptive
execution on that random tape.  Averaging over the original random tapes preserves all
probabilities.  \(\square\)

### Theorem 4.1 (finite-alphabet adaptive closure)

Fix \(A\ge2\), \(0<\rho<1\), and \(0<\sigma_0\le1\).  Let
\(\Pi:\{0,1\}^k\to\Sigma^P\), and suppose each coordinate/claim verifier makes at most
\(r=r(k)\) adaptive proof queries and satisfies

\[
 p_{i,m_i}(\Pi(m))=1,
 \qquad
 \operatorname{dist}(z,\Pi(m))\le\rho
 \Longrightarrow p_{i,1-m_i}(z)\le1-\sigma_0 .
 \tag{4.2}
\]

Put

\[
 Q:=1+2\sum_{j=0}^{r-1}A^j,
 \qquad a:=\left\lceil Q/\sigma_0\right\rceil .
 \tag{4.3}
\]

There is a constant \(\delta_0=\delta_0(\rho,A)>0\) such that, whenever

\[
  \delta_0>N^{-\sigma_0/(2Q)},
  \qquad N:=k+P,
  \tag{4.4}
\]

the inline length satisfies

\[
 N\ge
 \left(
 \frac{\sigma_0^2 k}
 {38Q^4\log^2(A+2)\log^2 k}
 \right)^{1+1/a}.
 \tag{4.5}
\]

If (4.4) fails, then

\[
 Q\ge \frac{\sigma_0\log N}{2\log(1/\delta_0)}.
 \tag{4.6}
\]

Consequently, if \(N\le k(\log k)^c\) for infinitely many \(k\), then

\[
 Q=\Omega_{A,\rho,\sigma_0,c}\!\left(\frac{\log k}{\log\log k}\right).
 \tag{4.7}
\]

#### Proof

Tag the first \(k\) inline coordinates by \((I,b)\) and proof symbols by \((P,a)\).  The
target-relative hypothesis and perfect completeness imply pairwise proof distance greater
than \(\rho\).  The \(A\)-ary Singleton bound therefore leaves a constant fraction of
the inline corruption budget for the proof suffix, giving \(\delta_0(\rho,A)\).

The inline decoder rejects malformed tags with \(\bot\) and simulates the selected
branch.  It is a weak adaptive RLDC with radius \(\delta_0\), perfect completeness, and
success at least \(\sigma_0\).  Lemma 4.0 turns it into a nonadaptive RLDC with exactly
the query bound \(Q\).  In the regime (4.4), the arbitrary-alphabet nonadaptive RLDC
lower bound of Goldberg--Gur--Saraogi gives (4.5).  If (4.4) fails, taking logarithms
gives (4.6).

For the near-linear consequence, suppose for contradiction that
\(Q\le\eta\log k/\log\log k\).  Then \(a\le 2\eta\log k/(\sigma_0\log\log k)\) and
\(\log k/a\ge \sigma_0\log\log k/(2\eta)\), while the logarithm of the denominator
in (4.5) is at most \(6\log\log k+O_{A,\sigma_0,\eta}(1)\).  Choosing \(\eta\) small
enough (depending on \(c,A,\rho,\sigma_0\)) contradicts (4.5).  \(\square\)

For binary proofs, \(Q=2^{r+1}-1\).  Hence a near-linear construction with fixed alphabet,
positive radius, perfect completeness, and a fixed target-relative gap must pay growing
adaptive locality, or leave this interface.  The exponential decision-tree factor is an
explicit compilation cost, not a hidden appeal to an adaptive RLDC lower bound.

### Theorem 4.2 (finite-view strategy entropy barrier)

The same conclusion survives an arbitrarily powerful Merlin strategy, provided the
verifier exposes only a finite visible view.  Suppose that in one execution a
coordinate/claim verifier uses at most \(r\) public-random bits, observes at most \(m\)
response bits, and queries at most \(q\) symbols from the fixed alphabet \(\Sigma\),
\(|\Sigma|=A\).  The strategy may be an arbitrary function of all public history,
previous response bits, and previous proof answers.  Assume perfect completeness for the
correct claim and the target-relative wrong-claim bound in (4.2) for **every** such
visible policy.

Put

\[
 Q_{\mathrm{view}}:=1+2q\,2^{r+m}A^q .
\tag{4.9}
\]

There is a constant \(\delta_1=\delta_1(\rho,A)>0\) such that message inlining and
tagging give a nonadaptive relaxed local decoder of locality at most
\(Q_{\mathrm{view}}\), radius \(\delta_1\), perfect completeness, and constant success
gap depending only on \(\sigma_0\).  Consequently, in the GGS lower-bound window, if

\[
 \delta_1>N^{-\sigma_0/(2Q_{\mathrm{view}})},
\tag{4.10a}
\]

\[
N:=k+P\le k(\log k)^c
\tag{4.10}
\]

for infinitely many \(k\), then every sufficiently large such length satisfies

\[
 Q_{\mathrm{view}}
 =\Omega_{A,\rho,\sigma_0,c}\!\left(\frac{\log k}{\log\log k}\right).
\tag{4.11}
\]

If (4.10a) fails, the radius alternative already gives

\[
 Q_{\mathrm{view}}
 \ge \frac{\sigma_0\log N}{2\log(1/\delta_1)}.
\tag{4.10b}
\]

Equivalently, a finite-view construction must pay

\[
 r+m+q\log_2 A+\log_2(q+2)
 \ge
 \log_2\log k-\log_2\log_2\log k-O_{A,\rho,\sigma_0,c}(1).
\tag{4.12}
\]

Thus an arbitrarily long but invisible Merlin string is not a separate escape: only the
finite visible transcript contributes to the support seen by the decoder.

#### Proof

Fix a public random tape.  A complete visible execution is determined, for future proof
addresses, by the public tape, the at most \(m\) observed response bits, and the at most
\(q\) proof symbols already read.  Across all policies there are at most

\[
 2^r\,2^m A^q
\tag{4.13}
\]

such view paths, and each path contains at most \(q\) query positions.  Hence the union
\(L_{i,b}\) of all proof positions reachable for a fixed coordinate and claim obeys

\[
 |L_{i,b}|\le q\,2^{r+m}A^q .
\tag{4.14}
\]

This counts addresses rather than policies, so no computational bound on the policy is
needed.  Inline the message bits and use disjoint tags for inline and proof symbols.  The
pairwise proof-distance and Singleton argument from the exact-completeness/wrong-claim
hypotheses in Theorems 2.1--2.2 leaves a constant
radius \(\delta_1\).  On a received word in that radius, read the inline bit \(i\), query
the two supports \(L_{i,0}\) and \(L_{i,1}\), and enumerate all finite visible policies
offline.  The correct policy accepts with probability one, while every policy for the
wrong claim has acceptance at most \(1-\sigma_0\).  Thresholding the exact acceptance
values therefore outputs the correct bit with a constant gap and never outputs a wrong
bit on the promised neighborhood.  The query count is (4.9).

The arbitrary finite-alphabet nonadaptive RLDC lower bound of Goldberg--Gur--Saraogi
applies in its stated radius window.  Substituting \(Q_{\mathrm{view}}\) gives (4.11);
taking logarithms of (4.9) yields (4.12).  The full parameter calculation, including the
small-radius alternative, is recorded in [note 268](../../../mcsp-hardness-magnification/notes/268-finite-view-strategy-entropy-barrier-2026-08-17.md).
\(\square\)

The quantifier is essential.  If soundness is required only for one target-selected
policy, a constant proof can be paired with a policy that simply reveals the target bit;
the support compiler then has no contradiction.  Likewise, a continuous/unbounded view
or a target-dependent physical proof address is outside Theorem 4.2 and must be named as
a model change rather than hidden inside “long Merlin strategy.”

The response-bit notation is only one presentation of the same closure. More generally,
after fixing the public tape let \(\mathcal V_{i,b}\) be the set of all global-state
transcripts visible over all policies, with \(|\mathcal V_{i,b}|\le B\). Then the identical
support argument gives

\[
  Q_{\mathcal V}=1+2q\,2^r B A^q .
\tag{4.12a}
\]

Hence the finite-view resource in (4.12) is really
\(r+\log_2B+q\log_2A+\log_2(q+2)\). A non-product verifier with a finite global state
space therefore remains inside the RLDC barrier; only an unbounded visible state, a
target-dependent physical proof/address space, or a changed soundness quantifier is a
genuine source-exit. The formal finite-state normal form and its evidence boundary are
recorded in [note 449](../../../mcsp-hardness-magnification/notes/449-finite-state-global-relation-normal-form-2026-08-19.md).

### Theorem 4.3 (selected-policy entropy-to-RLDC lift)

The all-policy hypothesis in Theorem 4.2 is not the only route to a coding barrier.
Suppose instead that every target \(m\) and coordinate \(i\) chooses one policy
\(\tau_{m,i}\).  Define the selected-policy vector

\[
 S(m):=(\tau_{m,1},\ldots,\tau_{m,k}),
 \qquad B:=|\operatorname{supp}S|.
 \tag{4.15}
\]

Assume that the fixed policy/claim branches are nonadaptive and use at most \(q\) proof
symbols.  Each \(\tau_{m,i}\) is one public-claim strategy whose behavior for both
claims is included in the vector \(S(m)\).  For constants \(\alpha>\beta\) and
\(\rho>0\), require

\[
 \Pr[V_{i,m_i}^{\tau_{m,i}}(\Pi(m))=1]\ge\alpha
\tag{4.16}
\]

and, for every \(z\) with
\(\operatorname{dist}(z,\Pi(m))\le\rho\),

\[
 \Pr[V_{i,1-m_i}^{\tau_{m,i}}(z)=1]\le\beta .
\tag{4.17}
\]

Let \(d\) be the maximum VC dimension of a fiber
\(F_s:=\{m:S(m)=s\}\).  Then a fiber contains a shattered coordinate set of size \(d\);
restricting to representatives on that set and inlining the \(d\) message bits gives a
positive-radius RLDC with locality

\[
 Q=O\!\left(q(\alpha-\beta)^{-2}\right)
\tag{4.18}
\]

and constant success gap, in every corresponding arbitrary-alphabet RLDC lower-bound
window.  When \(\alpha<1\) this is an imperfect-complete semantic RLDC; a length lower bound may
be invoked only from a theorem whose completeness convention matches that decoder.  When
\(\alpha=1\), the inline compiler is perfect-complete (the inline bit selects one claim
branch), but the resulting code length is \(d+P\) and its alphabet is \(A+2\).  The GGS
and Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu bounds used below apply to this
inline code, not directly to the proof suffix.  Moreover,

\[
 B\sum_{j=0}^{d}\binom{k}{j}\ge 2^k .
\tag{4.19}
\]

Consequently, if \(B\le2^{\gamma k}\) for a fixed \(\gamma<1\), then
\(d\ge(\theta_\gamma-o(1))k\), where
\(H_2(\theta_\gamma)=1-\gamma\).  If \(d=o(k)\), necessarily

\[
 \log_2 B\ge k-o(k).
\tag{4.20}
\]

Thus selected-policy-only soundness has a quantitative dichotomy: either a large fiber
inherits the shared-proof RLDC barrier, or the policy vector itself carries essentially
the full target entropy.  The latter is a charged target channel, not a free
common-proof reconstruction.

#### Proof

Choose a fiber \(F_s\) of maximum VC dimension and a shattered set
\(I=\{i_1,\ldots,i_d\}\).  For each \(x\in\{0,1\}^d\), choose a representative
\(m_x\in F_s\) whose restriction to \(I\) equals \(x\), and set
\(C_s(x):=\Pi(m_x)\).  For each \(i_j\), all representatives use the same policy
\(s_{i_j}\).  If two representatives with different \(i_j\)-bits had proof words
within distance \(\rho\), (4.16) for one target and (4.17) for the other, using this
same policy, would contradict \(\alpha>\beta\).  Hence \(C_s\) is a separated code.

Inline \(x_j\) with a disjoint tag and query the selected common policy \(s_{i_j}\) at
\(i_j\).  At each fixed length the finite visible behavior of this policy can be
hardwired into the query-only decoder; no decoder running-time claim is being made.  The
inline bit supplies the claimed value; constant independent repetition and thresholding
between \(\alpha\) and \(\beta\) give (4.18).  On a \(\rho\)-near word the wrong inline
claim is accepted with probability at most \(\beta\), so the decoder is relaxed and has
positive radius after the usual Singleton/tagging calculation.

Every fiber has size at most \(\sum_{j\le d}\binom{k}{j}\) by Sauer--Shelah.  Summing over
the \(B\) fibers gives (4.19), and the entropy estimate for the binomial sum gives the
linear lower bound on \(d\) and (4.20).  \(\square\)

The theorem does not upgrade the weak counterexample
\(\forall m,i\,\exists\tau_{m,i}\) when the policy vector has full entropy: a constant
proof can still be paired with a target-dependent policy.  It says instead that this
semantic escape must expose \(k-o(k)\) bits in its policy channel, or leave the common
proof/address and fixed-branch model.  The full randomized and adaptive extensions are
recorded in [note 271](../../../mcsp-hardness-magnification/notes/271-selected-policy-vc-lift-to-rldc-2026-08-17.md).

### Theorem 4.4 (quantitative proof--policy information tradeoff)

The preceding entropy statement has an exact proof-length form.  Fix a finite proof
alphabet \(\Sigma\) of size \(A\ge2\), a radius \(\rho>0\), and a common proof map
\(\Pi:\{0,1\}^{K}\to\Sigma^P\).  For each target and coordinate let a selected
nonadaptive policy satisfy the supportwise hypotheses (4.16)--(4.17), with gap
\(\Delta=\alpha-\beta>0\).  For the GGS conclusion below, additionally assume \(\alpha=1\)
(supportwise perfect completeness) and use the inline compiler from Theorem 4.3.  After
optional constant amplification, write \(Q\) for the resulting inline query count and
\(\sigma_0>0\) for its relaxed success parameter.  Let
\(M\) be uniform and let \(S\) be the selected-policy vector, allowing randomized
selection when every policy in the conditional support obeys the same hypotheses.

Define

\[
 \widehat A:=A+2,\qquad
 \mathcal L_{Q,\widehat A,\sigma_0}(d):=
 \left(
 \frac{\sigma_0^2d}
 {38Q^4\log_2^2(\widehat A)\log_2^2(d+2)}
 \right)^{1+1/\lceil Q/\sigma_0\rceil}
\tag{4.21}
\]

and

\[
 d^\star(P):=\max\!\left(\{1\}\cup
 \{2\le d\le K:d+P\ge\mathcal L_{Q,\widehat A,\sigma_0}(d)\}\right).
\tag{4.22}
\]

Whenever the GGS radius condition \(\delta_0>P^{-\sigma_0/(2Q)}\) holds for a fixed
\(\delta_0<\rho\),

\[
 I(M;S)\ \ge\ K-
 \log_2\!\left(\sum_{j=0}^{d^\star(P)}\binom Kj\right).
\tag{4.23}
\]

In particular, for fixed \(A,Q,\rho,\Delta\), if
\(P\le K(\log(K+2))^c\) along an infinite sequence, then

\[
 d^\star(P)\le K^{1/\theta}(\log(K+2))^{O(1)}=o(K),
 \qquad
 \theta=1+1/\lceil Q/\sigma_0\rceil,
\tag{4.24}
\]

and hence \(I(M;S)=K-o(K)\).

#### Proof

For a policy value \(s\), let \(F_s\) be the conditional support of \(M\) given
\(S=s\), and let \(d_s=\operatorname{VCdim}(F_s)\).  A shattered set of size \(d_s\)
gives representatives whose proof images are pairwise farther than \(\rho P\): if two
images differed at a requested coordinate but were within that radius, the same selected
policy would accept one target's correct claim with probability at least \(\alpha\) and
the other target's wrong claim with probability at most \(\beta\).  The inline decoder
from Theorem 4.3 therefore gives, after inlining the \(d_s\) message bits, a \(Q\)-query
nonadaptive RLDC of length \(d_s+P\), alphabet \(\widehat A\), and perfect completeness
under the added \(\alpha=1\) hypothesis.  The GGS lower bound then implies
\(d_s+P\ge\mathcal L_{Q,\widehat A,\sigma_0}(d_s)\), so \(d_s\le d^\star(P)\) in the
stated radius window.  Without \(\alpha=1\) this step is not licensed by the cited GGS
theorem.
Sauer--Shelah yields

\[
 H(M\mid S=s)\le\log_2|F_s|
 \le\log_2\!\left(\sum_{j=0}^{d^\star(P)}\binom Kj\right).
\]

Average over \(s\) and use \(I(M;S)=K-H(M\mid S)\).  The standard-Borel version uses
regular conditional laws and the same almost-everywhere argument; it is recorded in
[note 350](../../../mcsp-hardness-magnification/notes/350-quantitative-proof-policy-information-tradeoff-2026-08-18.md).
\(\square\)

### Theorem 4.5 (information-budget proof-length phase diagram)

Under the hypotheses of Theorem 4.4, suppose \(I(M;S)\le\gamma K\) for a fixed
\(0\le\gamma<1\).  Let \(\vartheta_\gamma\in(0,1/2]\) satisfy
\(h_2(\vartheta_\gamma)=1-\gamma\).  For every fixed
\(0<\varepsilon<\vartheta_\gamma\), all sufficiently large \(K\) in the same GGS
radius window obey

\[
 P\ge
 \left(
 \frac{\sigma_0^2d}
 {38Q^4\log_2^2(\widehat A)\log_2^2(d+2)}
 \right)^{1+1/\lceil Q/\sigma_0\rceil}-d,
 \qquad d:=\left\lfloor(\vartheta_\gamma-\varepsilon)K\right\rfloor.
\tag{4.25}
\]

Equivalently, with \(\theta_Q=1+1/\lceil Q/\sigma_0\rceil\), there is a constant
\(c_{\gamma,A,Q,\sigma_0}>0\) such that

\[
 P\ge c_{\gamma,\widehat A,Q,\sigma_0}
 \frac{K^{\theta_Q}}{(\log(K+2))^{2\theta_Q}}.
\tag{4.26}
\]

Thus any fixed positive fraction of unpaid target information forces a genuinely
superlinear proof exponent, rather than merely violating a near-linear endpoint.

#### Proof

The information budget gives \(H(M\mid S)\ge(1-\gamma)K\), so some conditional
fiber has support at least \(2^{(1-\gamma)K}\).  If its VC dimension were below
\((\vartheta_\gamma-\varepsilon)K\), Sauer--Shelah and the binomial entropy estimate
would make its support smaller than this for all large \(K\).  The fiber therefore
contains a shattered set of size
\(d=\lfloor(\vartheta_\gamma-\varepsilon)K\rfloor\).  The inline RLDC construction in
Theorem 4.4 and the GGS inequality give \(d+P\ge\mathcal L_{Q,\widehat A,\sigma_0}(d)\),
which is (4.25).  Since the right-hand side is polynomially superlinear in \(d\), the
subtracted \(d\) is absorbed for all sufficiently large \(K\), yielding (4.26).  \(\square\)

For adaptive selected branches, the source-audited variable-query transfer of note 255
applies to the same linear-size fiber.  In a near-linear regime it yields the additional
necessary window \(r\log(r+2)=\Omega_\gamma((\log K)^{1/3})\), provided the transfer
condition \(Q_K^3=o(\log P)\) is the branch under test.  The quantitative phase diagram
is therefore a necessary condition, not an achievability claim and not a proof of
\(P\ne NP\).  The full derivation is in [note 351](../../../mcsp-hardness-magnification/notes/351-information-budget-proof-length-phase-diagram-2026-08-18.md).

### Theorem 4.6 (finite-randomness completeness repair)

The \(\alpha=1\) hypothesis in Theorems 4.4--4.5 is not needed when all verifier
randomness is a finite public tape.  In the setting of Theorem 4.3, assume that each
selected policy/claim branch uses at most \(r\) public-random bits and at most \(q\)
adaptive proof queries over the alphabet \(\Sigma\), \(|\Sigma|=A\).  For a fiber
with shattered set of size \(d\), define

\[
  T_q(A):=\sum_{j=0}^{q-1}A^j,
  \qquad Q_{\rm fin}:=2^rT_q(A).
  \tag{4.27}
\]

Then the inline code of length \(d+P\) over the tagged alphabet \(A+2\) has a
perfect-complete nonadaptive relaxed decoder of proof-symbol locality at most
\(Q_{\rm fin}\), plus one inline query, and zero wrong-output probability throughout
the fixed positive-radius promise ball.  In the radius window of a perfect-complete
arbitrary-alphabet RLDC lower bound, one may therefore apply that lower bound with
query parameter \(1+Q_{\rm fin}\), even when \(\alpha<1\).  In the nonadaptive branch
case, \(T_q(A)\) in (4.27) is replaced by \(q\).

Because wrong-output probability is zero throughout the promise ball, this decoder has
the GGS Definition 3.3 soundness parameter \(\sigma=1\) (or any smaller fixed parameter
under a stricter matching convention), despite the original \(\alpha<1\) branch gap.

#### Proof

Choose representatives on a shattered fiber exactly as in Theorem 4.3.  The selected
policy is common on the shattered coordinates, and the \(\alpha>\beta\) hypotheses
imply that their proof words are pairwise farther than \(\rho P\).  The \(A\)-ary
Singleton bound therefore leaves a constant fraction of the inline corruption budget
for the proof suffix, giving a radius \(\delta=\delta(\rho,A)>0\).

Read the inline bit \(b\).  For each of the \(2^r\) public tapes, expose every node
of the selected branch's depth-\(q\) proof-answer decision tree.  At most
\(T_q(A)\) symbols are needed per tape, so all acceptance probabilities can be computed
exactly from the queried suffix.  Threshold the selected branch at
\(t=(\alpha+\beta)/2\), outputting \(b\) above the threshold and \(\bot\) otherwise.
On the uncorrupted codeword the inline bit is correct and the acceptance is at least
\(\alpha\), so completeness is perfect.  In the promise ball, a flipped inline bit
selects the wrong branch, whose exact acceptance is at most \(\beta\); it therefore
outputs \(\bot\), never the wrong bit.  An unflipped inline bit can only produce the
correct bit or \(\bot\).  The decoder is nonadaptive because all tree nodes were queried
before the offline simulation.  \(\square\)

This is a finite-randomness repair, not a removal of the general completeness boundary:
if the public tape or visible response alphabet is unbounded, the exact enumeration may
have object-scale locality and Theorems 4.4--4.5 retain their explicit \(\alpha=1\)
condition.  The quantitative proof--policy tradeoff with \(\alpha<1\) is therefore
available precisely when the \(2^rT_q(A)\) compilation cost itself lies in the cited
RLDC lower-bound window.  The complete parameter statement is recorded in
[note 467](../../../mcsp-hardness-magnification/notes/467-finite-randomness-completeness-repair-selected-policy-rldc-2026-08-19.md).

### Theorem 4.7 (finite-randomness selected-policy phase diagram)

Assume the selected-policy hypotheses of Theorem 4.3, but allow a fixed gap
\(\alpha>\beta\). Suppose all branch randomness is a public tape of \(r\) bits,
the proof alphabet has size \(A\), and each branch makes at most \(q\ge1\) adaptive
proof queries. Let \(M\) be uniform on \(\{0,1\}^K\), let \(S\) be the selected-policy
vector, and assume \(I(M;S)\le\gamma K\) for some \(\gamma<1\). Put

\[
  d=\lfloor(\vartheta_\gamma-\varepsilon)K\rfloor,\quad
  T_q(A)=\sum_{j<q}A^j,\quad
  Q=1+2^rT_q(A),\quad
  \widehat A=A+2,
\]

where \(h_2(\vartheta_\gamma)=1-\gamma\) and
\(0<\varepsilon<\vartheta_\gamma\). In the GGS radius window
\(\delta_\rho>(d+P)^{-1/(2Q)}\), the inline code obeys

\[
 d+P\ge
 \left(\frac{d}{38Q^4\log_2^2(\widehat A)\log_2^2(d+2)}\right)^{1+1/Q}.
 \tag{4.28}
\]

Consequently, if \(P\le K(\log(K+2))^c\) infinitely often, then

\[
  Q=\Omega_{A,\rho,\gamma,\varepsilon,c}\!\left(\frac{\log K}{\log\log K}\right),
  \qquad
  r+\log_2T_q(A)\ge\log_2\log K-\log_2\log\log K-O(1).
 \tag{4.29}
\]

For nonadaptive branches, replace \(T_q(A)\) by \(q\). The point that permits the GGS
invocation despite \(\alpha<1\) is not ordinary completeness amplification: the finite
tree enumeration of Theorem 4.6 gives perfect completeness and zero wrong-output
probability on the promise ball, hence soundness parameter \(\sigma=1\) in the GGS
RLDC definition.

#### Proof

The mutual-information budget and Sauer--Shelah yield a fiber with a shattered set of
size at least \(d\), as in Theorems 4.4--4.5. Theorem 4.6 turns that fiber into a
nonadaptive RLDC of length \(d+P\), alphabet \(\widehat A\), and query count \(Q\), with
perfect completeness and zero wrong output. Thus the GGS lower bound is (4.28) with
\(\sigma=1\). If its radius condition fails, taking logarithms gives
\(Q\ge\log(d+P)/(2\log(1/\delta_\rho))\). Otherwise the same exponent calculation as
in Theorem 4.1 shows that \(Q=o(\log K/\log\log K)\) is incompatible with
\(P\le K(\log K)^c\). Substituting the definition of \(Q\) gives (4.29).
\(\square\)

The full parameter statement and the information-budget proof are recorded in
[note 468](../../../mcsp-hardness-magnification/notes/468-finite-randomness-selected-policy-phase-diagram-2026-08-19.md).

### Low-soundness external sharpening

There is a complementary 2026 theorem that must be kept separate from (4.7).  Cheng--Li--Mao
prove that a \(Q\)-query RLDC over an alphabet of size \(\widehat A\), with perfect
completeness and soundness error \(s<\widehat A^{-Q}\), is itself a \(Q\)-query LDC at
every radius

\[
 r<\frac{\delta_0(\widehat A-1)}{Q\widehat A(1-s\widehat A^Q)}.
 \tag{4.8}
\]

Their theorem also has a nonadaptive imperfect-completeness version.  After the inline
tagging in Theorem 4.1 one may take \(\widehat A=A+2\) and \(s=1-\sigma_0\), so this
sharpening applies whenever the displayed low-soundness inequality is actually verified.
The fixed-gap hypothesis of Theorem 4.1 alone does not imply
\(1-\sigma_0<(A+2)^{-Q}\); therefore (4.8) is recorded as an external low-soundness
branch, not silently used to strengthen the general \(\Omega(\log k/\log\log k)\) claim.

## 5. A compiler-class coordinate-flip barrier

The preceding results apply to any common-proof interface satisfying their semantic
quantifiers.  The next theorem targets a different, frequently proposed positive route:
partitioning constraints by the decoded coordinate and adding a free agreement slot.

### Theorem 5.1 (partition-and-agreement coordinate-flip barrier)

Let \(I=[n]\), let \(E\) be a multiset of ordered \(k\)-tuples over a right vertex set
\(V\supseteq I\), and partition \(E=\bigsqcup_t E_t\).  For each \((e,s)\), a left
symbol contains the original constraint on \(e\) and an extra \(s\)-entry when
\(s\notin e\); if \(s\in e\), the corresponding repeated agreement slot remains but
there is no independent second \(s\)-value.  All \(k+1\) slots are checked by agreement,
and the decoder for coordinate \(t\) samples \(e\) from \(\nu_t\) on \(E_t\).

Assume the zero word is perfectly decoded and that, for a fixed \(t\), the right alphabet
has a symbol \(1_t\) different from the zero symbol.  Assume also that whenever
\(t\notin e\), the extra slot at \((e,t)\) permits changing only its \(t\)-entry to
\(1_t\), while retaining the base restriction.  Define

\[
 b_t(e):=\#\{j:v_j=t\},\quad
 \lambda_t:=\mathbb E_{(e,s)}b_t(e),\quad
 \gamma_t:=\Pr_{(e,s)}[s=t\land b_t(e)\ge1],
 \]

\[
 a_t:=\Pr_{e\sim\nu_t}[b_t(e)\ge1],
 \qquad
 \omega_t:=\Pr[\text{the global decoder selects }t].
 \]

Then there is an assignment \(\widetilde A_t\) with exact constraint defect and decoding
error

\[
 \operatorname{def}(\widetilde A_t)=\frac{\lambda_t+\gamma_t}{k+1},
 \qquad
 \operatorname{err}_{0^n}(\widetilde A_t)=\omega_t(1-a_t).
 \tag{5.1}
\]

Consequently every \((\eta,\varepsilon)\)-unique-decoding guarantee for the singleton
language \(\{0^n\}\) must satisfy, for every \(t\),

\[
 \varepsilon\ge\frac{\lambda_t+\gamma_t}{k+1}
 \Longrightarrow
 \eta\ge\omega_t(1-a_t).
 \tag{5.2}
\]

In the normalization \(\varepsilon=\rho\eta/(2(k+1))\),

\[
 \eta\ge
 \min\left\{\frac{2(\lambda_t+\gamma_t)}{\rho},\,\omega_t(1-a_t)\right\}.
 \tag{5.3}
\]

#### Proof

Start from the satisfying right assignment and change only its label at \(t\) to
\(1_t\).  Keep every base entry on \(e\) unchanged.  If \(t\notin e\), use the
changed value only in the extra slot when \(s=t\); all other extra slots retain the
zero value.  The failed base slots are exactly the \(b_t(e)\) occurrences.  If
\(s=t\in e\), the repeated extra slot also fails, giving the additional \(\gamma_t\)
term.  Since every left vertex has \(k+1\) equally weighted slots, the defect is the
first expression in (5.1).

Under \(\nu_t\), the decoder sees the flipped value exactly when \(t\notin e\), so its
error contribution is \(\omega_t(1-a_t)\); all other coordinates remain correct.  If
the defect is within the claimed rejection threshold while this error exceeds \(\eta\),
unique-decoding soundness is violated.  This proves (5.2), and substitution of the
normalization gives (5.3).  \(\square\)

The theorem is independent of the underlying PCPP or HDX source.  Repetition and degree
regularization do not remove it: a successful construction must make \(a_t\) close to one,
change the decoding distribution, or abandon the free-extra-slot/target-independent
agreement architecture.

## 6. Positive-radius completion barrier for dense folding

The preceding compiler barriers treat the verifier as a black-box proof interface. A
different proposed escape is to compress many raw symbols into a high-arity linear fold
and open that fold locally. The following theorem shows that positive-radius
single-valuedness already charges the full arity.

### Theorem 6.1 (completion-sensitive dense-fold barrier)

Let \(F\) be a finite field and

\[
  L_\alpha(y)=\sum_{j=1}^{b}\lambda_j(\alpha)y_j,
  \qquad \lambda_j(\alpha)\ne0 .
\tag{6.1}
\]

Let \(\mathcal Y\subseteq F^b\) contain the radius-one Hamming ball around
\(y^\star\). If a randomized adaptive tree reads raw coordinates and outputs
\(L_\alpha(y)\) with pointwise error at most \(\varepsilon<1/2\) on \(\mathcal Y\), then

\[
  \Pr[\text{the tree queries coordinate }j\mid y^\star]\ge1-2\varepsilon
  \quad(j\in[b]),
  \qquad
  \mathbb E Q(y^\star)\ge b(1-2\varepsilon).
\tag{6.2}
\]

If the tree may output \(\bot\), write

\[
  \operatorname{err}(y)=
  \Pr[D(y)\in F\setminus\{L_\alpha(y)\}],
  \qquad
  \operatorname{bot}(y)=\Pr[D(y)=\bot].
\tag{6.3}
\]

When \(\operatorname{err}(y)\le\beta\) throughout \(\mathcal Y\) and
\(1-\operatorname{bot}(y^\star)\ge\nu\), the first bound in (6.2) becomes

\[
  \Pr[\text{query }j\mid y^\star]\ge\max\{0,\nu-2\beta\}.
\tag{6.4}
\]

Consequently, \(R\) separately charged fold layers with arities \(b_1,\ldots,b_R\) and
\(\prod_rb_r\ge T\) require

\[
  \mathbb E Q\ge\gamma R\,T^{1/R}
\tag{6.5}
\]

whenever every layer has \(\nu_r-2\beta_r\ge\gamma>0\).

#### Proof

For coordinate \(j\), choose any \(\delta\ne0\) and couple \(y^\star\) with
\(y^\star+\delta e_j\) on the same random tape. On the event that the first execution
does not query \(j\), the transcripts and outputs agree. The two correct fold values
differ by \(\lambda_j(\alpha)\delta\), so at least one execution has a wrong symbol.
The non-bottom version gives probability at most \(2\varepsilon\) to this event. In the
bottom version, a common non-bottom output is wrong for one of the two inputs, while a
common \(\bot\) output is counted by \(\operatorname{bot}(y^\star)\). Hence the
non-query event has probability at most \(2\beta+1-\nu\), proving (6.4). Sum over
coordinates and layers, then apply AM--GM. \(\square\)

The theorem applies to a physical proof only when every one-coordinate raw completion
has a realization inside the claimed correctness domain. A physical Hamming ball does
not imply this for an ECC image or another nonlocal encoding. Thus every high-arity
candidate must make one of the following choices explicit: accept substantial bottom
mass (\(\nu\le2\beta\)); impose a nonlocal raw-domain constraint; or leave the raw-fold
model for a new global relation. This is a folding-specific barrier, not a general
PCP/FRI/PCS lower bound. The full RW/Harsha formulation and its source boundary are in
[C476](../../../mcsp-hardness-magnification/notes/476-positive-radius-completion-barrier-2026-08-19.md).

For the published RW/Harsha interface, the needed physical-to-raw completion is a separate
source-level quantifier: the Reed--Muller/systematic proof structure does not by itself
realize raw one-coordinate completions. The resulting direct-systematic versus
codeword/decoded-domain trichotomy is recorded in [C477](../../../mcsp-hardness-magnification/notes/477-rw-harsha-physical-to-raw-completion-trichotomy-2026-08-19.md).

The same distinction is sharper for FRI-style folds. For a layered linear fold graph, let
\(S_i\) denote the map from the base layer to layer \(i\), \(A_i\) the map from layer \(i\)
to the terminal layer, \(C_R\) the terminal linear code, and \(\pi_y\) restriction to a
fiber \(S_y\). A fiber-local one-coordinate completion at \(k\in S_y\) exists exactly when
\[
  e_k\in\pi_y\!\left(\operatorname{Im}S_i\cap A_i^{-1}(C_R)\right).
\tag{6.6}
\]
This graph-family condition becomes a C476 physical completion only when the corresponding
graph increment lies inside the proof-radius ball and the target raw transcript is
fiber-isolated (or insensitive to the increment outside \(S_y\)). Thus terminal distance and
a whole-layer unit-vector test are not valid substitutes for the completion quantifier. In formal FRI, the fold is dense when the round challenge lies
outside the target fiber and degenerates to a one-hot evaluation when it lies inside; ordinary
proximity soundness controls random-query acceptance, not a target-wise non-bottom recovery
map for corrupted committed layers. Recomputing a folded symbol pays the raw-fiber arity
from Theorem 6.1, while reading a materialized parent requires a separate near-proof
correctness and address-support theorem. Moreover, when at least two fold rounds remain below
the target and fibers have size at least two with nonzero coefficients, sibling cancellation supplies a terminal-zero
completion with stored-layer weight at most \(2(i+2)\); the raw-fiber lower bound therefore
applies whenever \(2(i+2)\le\rho P\). See [C478](../../../mcsp-hardness-magnification/notes/478-fri-fold-graph-local-completion-and-recovery-gate-2026-08-19.md).
The remaining materialized-parent branch is also charged: if one common proof
single-valuedly outputs the hard word, C473 forces the union of raw and parent cells
read on honest executions, while a charged fixed-proof parent evaluator falls under
C474. If neither same-proof correctness nor a charged evaluator is supplied, ordinary
random-query acceptance has not established the Closure interface. See
[C481](../../../mcsp-hardness-magnification/notes/481-rw-materialized-parent-raw-recomputation-trichotomy-2026-08-19.md).
Independently, ordinary FRI does not supply the challenge-independent, all-address
extractor tying its symbolic singleton to an external RW target; that missing quantifier
is isolated in [C480](../../../mcsp-hardness-magnification/notes/480-ordinary-fri-common-target-extraction-separation-2026-08-19.md).

## 7. Consequences for the RW/JK closure problem

### Theorem 7.1 (non-product global-state source-exit normal form)

The phrase “new non-product global relation” has two standard resource
interpretations, and both are already chargeable.  First, if a common-proof
family has \(r\) public bits, \(q\) proof-symbol queries, alphabet \(A\), and at
most \(B\) visible global-state transcripts per proof-answer transcript, then
the finite-view compiler gives a weak RLDC of locality
\[
Q_{\mathrm{view}}=1+2q\,2^r B A^q.
\tag{7.1}
\]
Under the near-linear proof regime and the finite-alphabet RLDC lower bound,
\[
r+\log B+q\log A+\log(q+2)
\ge \log\log k-\log\log\log k-O(1).
\tag{7.2}
\]
Second, for a fixed singleton target \(H\in\{0,1\}^N\), if the same global
relation is implemented by a common \(w\)-bit static/writable memory, \(T\)
fan-in-2 transitions of size \(g\), \(q\) adaptive accesses, and \(s\) bits
of nonlinear control state, then
\[
\operatorname{CC}(H)\le O\!\left(Tg+q(w+s+m)+m+1\right),
\qquad m=\lceil\log_2(N+1)\rceil.
\tag{7.3}
\]
Thus on a forcing-hard length \(S_N<\operatorname{CC}(H_N)\), the singleton
implementation must satisfy
\[
Tg+q(w+s+m_N)+m_N+1=\Omega(S_N).
\tag{7.4}
\]

The proof is the finite-view inline compiler for the family statement and the
standard RAM-to-circuit expansion for the singleton statement.  Consequently,
a common-proof relation that pays neither (7.2) nor (7.4) must explicitly leave
at least one original resource quantifier: it needs unbounded or non-enumerable
visible state, object-scale memory/preprocessing, target-dependent physical
proofs, a unit-cost global oracle, or a changed all-policy/radius semantics.
“Non-product” alone is not a third free address-scale model.  This is a
source-exit classification, not a general impossibility theorem or a proof of
\(P\ne NP\).  See
[note 506](../../../mcsp-hardness-magnification/notes/506-non-product-global-state-closure-normal-form-2026-08-19.md).

### 7.2 Current frontier mechanisms do not close Gate I

We checked the three most relevant recent mechanisms at theorem level. The GMWZ dPCP
Theorem 3.12 has list-decoding soundness of the form

\[
  \forall T_A\;\exists W(T_A)\subseteq L\;\forall T_B,
\]

and therefore does not by itself give a wrong-claim bound relative to a fixed RW target.
If one adds singleton binding $W(T_A)\subseteq\{f_x\}$, conditioning on a uniform
output coordinate costs a factor $k$: a constant coordinate gap requires
\(\varepsilon=O(1/k)\), after which the message-inline compiler enters the RLDC
length barrier. Their actual Theorem 11.3 instead uses independent $(i,b)$-indexed
PCPP blocks and has length $4Kk=\widetilde O(k^2)$; it is not a black-box near-linear
shared relation-PCP replacement.

The BMVY/HDX construction supplies finite-round routing and ordinary (or unique-decoding)
assignment soundness. Its routing transcript is therefore a finite-view object when
embedded into a common proof, and a bounded transition object when specialized to one
singleton. It does not supply the singleton, all-policy, target-relative address map
required by Gate I; the two corresponding resource ledgers are exactly Theorem 7.1.

Finally, Cheng--Li--Mao show that a perfect-complete $q$-query RLDC with soundness
\(s<|\widehat\Sigma|^{-q}\) is a $q$-query LDC (with a nonadaptive qualification in
the imperfect-completeness theorem). Thus using very small soundness to remove bottom
does not create a new closure escape. Their 3-query PCPP lower bound has additional
uniform-marginal and low-soundness hypotheses and is not a general dPCP lower bound.

There is a separate singleton refinement for the published RW failure branch. The
common canonical prefix and the address-dependent final `prMA` query define the exact
surface

\[
  W_{x,\tau}(i)=\exists C\,\forall\rho\,A_{x,\tau,i}(C,\rho),
\tag{7.5}
\]

which is a fixed \(\Sigma_2^P\) predicate. Smartness makes
\(W_{x,\tau_x}(i)=f(x)_i\) on every actual failure query, even if different addresses
use different Merlin circuits. Thus a common physical witness is not needed for the
*singleton* \(P/\mathrm{poly}\) implication; what is missing there is compression of
the surface from its \(\operatorname{poly}(k,r,\log t)\) object scale to the address
scale. This semantic surface does not yield an RLDC, because it has no family-level
common-proof, positive-radius, or all-policy soundness quantifier. See [C508](../../../mcsp-hardness-magnification/notes/508-rw-failure-branch-semantic-ph-surface-2026-08-19.md).

The two published RW execution branches can nevertheless be aligned on the same hard
truth table.  C509 shows that, on the C455 hard-length set, a failure/reconstruction
branch with an exact surface pays
\[
L_n=\Omega\!\left(
\left(\frac{N_n}{\log(N_n+2)}\right)^{1/c_*}
\right)
\]
for its complete input/quantifier/matrix representation under \(P=NP\), while a
solver-success branch still needs a same-parent charged binding and pays the C487
support bound.  Hence a family-level common-proof theorem is not necessary merely to
state the final singleton gate, but at least one of these two branch-local
address-scale interfaces must hold on every hard length; the infinite pigeonhole
principle then gives a conditional \(P\ne NP\) contradiction.  This branch-complete
criterion is recorded in [C509](../../../mcsp-hardness-magnification/notes/509-rw-published-branch-complete-closure-2026-08-19.md).

This three-way classification closes only these black-box routes. A positive RW result
therefore has two distinct options: for the final singleton contradiction it may supply
either an address-scale single-valued PH surface or a stronger one-proof relation-PCP;
for the negative coding route it must still introduce one proof, one word, positive radius,
and all-policy soundness, then charge that relation's proof, descriptor, or locality. See
[note 507](../../../mcsp-hardness-magnification/notes/507-frontier-dpcp-mechanism-closure-2026-08-19.md).

The results above impose a precise boundary on the proposed RW/JK attachment.
If a construction supplies one common proof, positive-radius target-relative robustness,
and fixed finite-alphabet locality, Theorems 2.1 and 4.1 force an RLDC cost.  In the
binary two-query window, Theorem 3.1 says that the only structural escape before the
cubic LDC lower bound is bottom.  Theorems 3.2--3.3 show that bottom is not a near-linear
escape when either one fixed policy pair is available, or target dependence has
sub-message mutual information.  If the
construction instead uses the standard
partition-and-agreement compilation, Theorem 5.1 supplies an explicit near assignment
that must be handled by a different global relation or by target-normalized agreement.

Under their supportwise perfect-completeness hypothesis, Theorems 4.4 and 4.5 sharpen the
Gate-II interpretation: a selected policy or cover descriptor cannot remain a small
address-scale side channel while preserving a near-linear common proof.  A putative RW
closure must therefore exhibit either message-scale target
information, a new non-product global relation, or an explicit exit from the common-proof
interface.  This is a quantitative boundary for the missing closure bridge, not the bridge
itself.

This is a barrier theorem, not the missing RW Succinct Smart Reconstruction Theorem.
It does not establish that the published RW/JK canonical history satisfies the common-proof
hypotheses, nor does it show that bottom, cover sheets, or target descriptors are impossible
for every source.  The address-scale evaluator and the same-object quantifier remain the
essential gates for the relevant route: the final singleton route needs a single-valued
same-object surface, while the RLDC route additionally needs a common physical proof and
word consistency. Paper 04 records the conditional implication from the singleton surface
to \(P/\mathrm{poly}\).

## References

- Alrabiah, Guruswami, Kothari, and Manohar, “A Near-Cubic Lower Bound for 3-Query
  Locally Decodable Codes from Semirandom CSP Refutation,”
  [arXiv:2308.15403](https://arxiv.org/abs/2308.15403).
- Goldberg, Gur, and Saraogi, “Nearly Tight Lower Bounds for Relaxed Locally Decodable
  Codes via Robust Daisies,” [arXiv:2511.21659](https://arxiv.org/abs/2511.21659).
- Block, Blocki, Cheng, Grigorescu, Li, Zheng, and Zhu, “Exponential Lower Bounds for
  2-query Relaxed Locally Decodable Codes,” [arXiv:2602.20278](https://arxiv.org/abs/2602.20278),
  Theorem 1.
- Cheng, Li, and Mao, “When Relaxation Doesn’t Help: RLDCs with Small Soundness Yield
  LDCs,” [arXiv:2603.03717](https://arxiv.org/abs/2603.03717), Theorems 3.1 and 5.1.
- Dall’Agnol, Gur, and Lachish, “Every Set in \(\mathcal P\) Is Strongly Testable under
  a Suitable Encoding,” ECCC TR18-050 (the relaxed-LDC lower-bound framework used in
  the source-audited extensions of the technical archive).
- Gur, Minzer, Weissenberg, and Zheng, “3-Query RLDCs are Strictly Stronger than 3-Query
  LDCs,” [arXiv:2512.12960](https://arxiv.org/abs/2512.12960).
- Ben-Sasson, Bentov, Horesh, and Riabzev, “Fast Reed--Solomon Interactive Oracle Proofs of
  Proximity,” ECCC TR17-134 revision 2, [ECCC](https://eccc.weizmann.ac.il/report/2017/134/).
- Finite-view strategy entropy expansion: [note 268](../../../mcsp-hardness-magnification/notes/268-finite-view-strategy-entropy-barrier-2026-08-17.md).
- Selected-policy VC/entropy lift: [note 271](../../../mcsp-hardness-magnification/notes/271-selected-policy-vc-lift-to-rldc-2026-08-17.md).
- Finite-randomness completeness repair: [note 467](../../../mcsp-hardness-magnification/notes/467-finite-randomness-completeness-repair-selected-policy-rldc-2026-08-19.md).
- Finite-randomness selected-policy phase diagram: [note 468](../../../mcsp-hardness-magnification/notes/468-finite-randomness-selected-policy-phase-diagram-2026-08-19.md).
- Quantitative proof--policy information tradeoff: [note 350](../../../mcsp-hardness-magnification/notes/350-quantitative-proof-policy-information-tradeoff-2026-08-18.md).
- Information-budget proof-length phase diagram: [note 351](../../../mcsp-hardness-magnification/notes/351-information-budget-proof-length-phase-diagram-2026-08-18.md).
- Uniform-policy two-query exponential gate: [note 451](../../../mcsp-hardness-magnification/notes/451-uniform-policy-two-query-exponential-rldc-gate-2026-08-19.md).
- Low-information target-dependent exponential gate: [note 452](../../../mcsp-hardness-magnification/notes/452-low-information-target-dependent-policy-exponential-gate-2026-08-19.md).
- Ren and Williams, “A Near-Optimal Lower Bound for the Circuit Complexity of
  \(\mathrm{MCSP}\),” ECCC TR26-118,
  [ECCC](https://eccc.weizmann.ac.il/report/2026/118/).

The expanded proofs and additional distributional, cover, and RW-specific interfaces are
retained in [Paper 01](../01-shared-proof-coordinate-robustness-implies-relaxed-local-decoding/paper.md)
as a technical archive.  The source-specific coordinate-flip calculation is also recorded
in [note 322](../../../mcsp-hardness-magnification/notes/322-gmwz-lemma42-partition-incidence-coordinate-flip-2026-08-18.md).
