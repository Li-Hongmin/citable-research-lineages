# Shared-Proof Coordinate Robustness Implies Relaxed Local Decoding

## Abstract

We study target-relative coordinate robustness for a single proof shared by all message
coordinates. A verifier for coordinate \(i\) receives a claimed symbol, accepts the
correct claim, and rejects the opposite claim on every proof in a fixed-radius
neighborhood of the target proof. Our first theorem shows that this interface already
contains a relaxed locally decodable code: the proof map has positive relative distance,
and thresholding the two claim verifiers gives an adaptive decoder with locality
\(O(q(\alpha-\beta)^{-2})\). The argument is quantifier-preserving and does not assume
linearity, projection, or nonadaptivity.

Using a parameter-tracked extension of the relaxed-DGL proof, we also handle
imperfect completeness with a fixed branch gap and growing adaptive locality:
in the source-audited \(Q^3=o(\log P)\) window, a near-linear proof forces
\(Q=\Omega((\log k)^{1/3})\), hence
\(r\log(r+2)=\Omega((\log k)^{1/3})\). This extension is derived from the
source proof and is explicitly not attributed to DGL as a stated theorem.

We then give two closure theorems for the mechanisms that can evade this compiler. The
adaptive-to-nonadaptive reduction exposes the two claim decision trees on each random tape.
For a fixed finite proof alphabet it yields the near-linear threshold
\(\Omega(\log k/\log\log k)\); a common-support quantile replaces the worst-case tree cost by
\(1+O(T/\gamma^2)\). In the binary two-query regime, the absence of simultaneous rejection
on a half-radius neighborhood upgrades the relaxed decoder to a three-query LDC. Any
near-linear construction below the cubic threshold must therefore exhibit a genuine
bottom phenomenon or leave the target-relative interface.

The second closure theorem addresses the global-word problem in distributional and dPCP
compositions. Coordinatewise valid-word explanations form the rectangular hull
\(\operatorname{Rect}(\mathcal Y)\). Either this hull is covered by correction balls around
valid words, which imposes projection-entropy, distance, and radius inequalities, or it
contains an explicit phantom word. If a policy is used, the corresponding information
accounting charges target information, conditional entropy deficit, and conditional
joint correlation. In the high-distance regime the last quantity is linear in the word
length; a short policy can avoid this only by supplying a genuinely joint global relation.

At the finite-view level these two mechanisms combine into a quantitative Closure Theorem.
For a common proof over an alphabet \(\Sigma_k\), with \(q_k\) proof queries, \(r_k\) public
bits and \(m_k\) visible response bits per claim, all-policy target-relative soundness and
near-linear length force
\[
\log|\Sigma_k|\ge k/2
\quad\text{or}\quad
Q_k\bigl(\log\log(k+2)+\log(Q_k+2)+
\log(\log(|\Sigma_k|+2)+2)\bigr)=\Omega(\log k),
\]
where \(Q_k=1+2q_k2^{r_k+m_k}|\Sigma_k|^{q_k}\). Thus a near-linear simultaneous
coordinate-robust construction must either expose a growing visible view or carry
message-scale alphabet information. This is a necessary condition, not an achievability
claim; it isolates the remaining top-level problem as a global relation/word construction
or a general cost theorem for escaping this envelope.

This distinction is substantive for current dPCP constructions: the published GMWZ
list-soundness quantifier permits the explaining list element to vary with the decoded
coordinate, whereas their uniquely-decodable variant supplies one global word but only an
average coordinate error guarantee. Neither statement by itself supplies the same
target-bound word with a constant error bound at every coordinate; that is exactly the new
global relation needed by the RW/JK interface.

We also prove a compiler-class barrier for partition-and-agreement constructions.  A
single-coordinate flip creates an explicit near-satisfying assignment, yielding the
tradeoff \(\eta\ge\min\{2\lambda_t/\rho,\omega_t(1-a_t)\}\) between base incidence,
decoding mass, and coordinate coverage.  This is independent of the particular PCPP or
HDX source and identifies the exact structural escape: target-normalized agreement or a
different global relation.

Finally, we apply these results to the Ren--Williams/Jeřábek--Korten attachment problem.
Selected canonical histories do not supply enough aligned tuples at the next JK width.
Any replacement common package must therefore pay target information or robust defect,
finite-alphabet locality, support-tail mass, or cover-sheet entropy. We also give an
anchored-udPCP plus smooth-outer-decoder composition whose wrong-claim error is at most
\(q_D\lambda(\varepsilon+\kappa)\). Proposition 5.0L strengthens this bridge: transcript
uniformization plus \(\lambda\)-smooth outer decoding gives a shared-proof ACRR with
wrong-claim error \(q_D\chi\alpha\), and otherwise exposes a quantitative query peak.
This identifies a concrete positive construction target.
The resulting Closure-Gate theorem is conditional on the stated common-proof,
target-relative, and coding hypotheses. It does not prove \(P\ne NP\), but it reduces the
remaining question to a precise global relation-PCPP construction or a general cost theorem
for such constructions.

## 1. The common-proof interface

Let

\[
  \Pi:\{0,1\}^{k}\to\{0,1\}^{P}
\]

be a proof map. For each coordinate \(i\in[k]\) and claim \(b\in\{0,1\}\), let
\(V_{i,b}\) be a randomized, possibly adaptive verifier making at most \(q\) proof queries.
Write \(p_{i,b}(z)\) for its acceptance probability on proof \(z\). Assume constants
\(\rho>0\) and \(\alpha>\beta\) such that, for every message \(m\),

\[
 p_{i,m_i}(\Pi(m))\ge\alpha,
 \qquad
 \operatorname{dist}(z,\Pi(m))\le\rho
 \Longrightarrow
 p_{i,1-m_i}(z)\le\beta .
\tag{1.1}
\]

Here \(\operatorname{dist}(u,v):=d_H(u,v)/P\) denotes relative Hamming distance on proof
words of length \(P\). The soundness quantifier is target-relative. Requiring the wrong branch to reject every proof
would conflict with the completeness proof of another message.

## 2. Main theorem: the proof map is a relaxed code

### Theorem 2.1

Under (1.1), distinct proof words have relative distance greater than \(\rho\). Moreover,
for every fixed target error \(0<\eta<1/2\) and every \(\delta<\rho\), the map \(\Pi\) has a
weak adaptive relaxed local decoder of locality

\[
 Q=O\!\left(q(\alpha-\beta)^{-2}\log(1/\eta)\right),
\tag{2.1}
\]

with completeness at least \(1-\eta\), wrong-output probability at most \(\eta\) on every
received word within relative distance \(\delta\) of the target proof, and arbitrary output
\(\bot\) otherwise. In particular, for constant \(\eta\), this is the stated
constant-locality/constant-error relaxed decoder.

### Proof

If \(m\ne m'\) and \(\operatorname{dist}(\Pi(m),\Pi(m'))\le\rho\), choose \(i\) with
different message bits. Completeness for \(m'\) makes the branch \(m'_i\) accept
\(\Pi(m')\) with probability at least \(\alpha\), while target-relative soundness for \(m\)
makes the same branch accept with probability at most \(\beta\), a contradiction.

For decoding, repeat both claim verifiers independently
\(R=\Theta((\alpha-\beta)^{-2}\log(1/\eta))\) times. Threshold their empirical
acceptance rates at \((\alpha+\beta)/2\), output the unique surviving claim, and output
\(\bot\) otherwise. On a target codeword, Hoeffding gives completeness at least
\(1-2\exp(-\Omega(R(\alpha-\beta)^2))\). On a \(\delta\)-near word, the wrong branch
has mean at most \(\beta\), so the probability that it crosses the threshold—and hence
the probability of a wrong output—is at most
\(\exp(-\Omega(R(\alpha-\beta)^2))\). Choosing the hidden constant in \(R\) gives
the stated \(\eta\) bounds. The query count is \(2Rq\). \(\square\)

The same argument over an alphabet \(\Gamma\) of fixed size \(A\) yields locality

\[
 O\!\left(Aq\frac{\log(A/\eta)}{(\alpha-\beta)^2}\right)
\]

at failure probability \(\eta\). This is a compiler into the corresponding relaxed-LDC
model; a length lower bound may be invoked only after matching the external theorem's
completeness, alphabet, and adaptivity conventions. In particular, the published
Goldberg--Gur--Saraogi theorem assumes perfect completeness (the perfect-complete route is
handled below by Theorem 2.2 and Theorem 4.1), while an imperfect-complete use requires a
separate source-compatible theorem or the derived transfer stated later. The contribution
here is the quantifier-preserving compiler, not an automatic arbitrary-alphabet,
imperfect-completeness lower bound.

### Theorem 2.2 (one-sided inline compiler)

There is a sharper compiler when the correct branch is perfectly complete. Assume the binary
interface satisfies, for constants \(\rho>0\) and \(\beta<1\),

\[
 p_{i,m_i}(\Pi(m))=1,
 \qquad
 d_H(z,\Pi(m))\le \rho P
 \Longrightarrow p_{i,1-m_i}(z)\le\beta,
\tag{2.2}
\]

and each claim verifier makes at most \(q\) proof-symbol queries. Then, for all sufficiently
large \(k\), the inline code

\[
C(m):=(m_i)_{i\in[k]}\Vert\Pi(m)\in\{0,1\}^{k+P}
\tag{2.3}
\]

is a weak adaptive \((q+1,\delta_\rho,1-\beta)\)-RLDC with perfect completeness, for a
constant \(\delta_\rho>0\) depending only on \(\rho\). The decoder makes one inline query,
then runs the verifier for the claimed bit read from that inline position, and outputs the
claim on acceptance and \(\bot\) otherwise.

#### Proof

Theorem 2.1 gives pairwise proof distance greater than \(\rho P\). The binary Singleton bound
therefore implies \(P/(k+P)\ge c_\rho>0\) for all sufficiently large \(k\). Fix
\(\delta_\rho>0\) so that \(\delta_\rho(k+P)\le\rho P\). For an oracle \(y\) within
\(\delta_\rho(k+P)\) of \(C(m)\), the proof suffix is within \(\rho P\) of \(\Pi(m)\).
If the inline bit is correct, the decoder outputs either \(m_i\) or \(\bot\). If it is
incorrect, the target-relative hypothesis bounds the probability of outputting that wrong bit
by \(\beta\). Thus the probability of outputting \(m_i\) or \(\bot\) is at least
\(1-\beta\), while on an uncorrupted codeword perfect completeness gives \(m_i\) with
probability one. The query count is \(q+1\). \(\square\)

The extra inline query is not a proof artifact: it is the exact price of turning a
target-relative two-branch verifier into a decoder that does not know the target bit. This
accounting is what separates the exponential total-two-query closure in Theorem 4.3 from the
three-query regime for two-query proof verifiers.

### Proposition 2.3 (rectangular proof-map covering tradeoff)

Let \(\Pi:\{0,1\}^k\to\Gamma^P\) be a proof map, let
\(\mathcal Y=\operatorname{Im}(\Pi)\), and write
\[
 p_j=|\{y_j:y\in\mathcal Y\}|,
 \qquad
 d=\min_{y\ne y'}d_H(y,y').
\]
Suppose the proof interface has the following additional black-box closure property:
every \(z\in\operatorname{Rect}(\mathcal Y)\) is within Hamming distance
\(t=\lfloor\varepsilon P\rfloor\) of some word in \(\mathcal Y\). Then
\[
 \sum_{j=1}^P\log_{|\Gamma|}p_j
 \le P-d+1+\log_{|\Gamma|}V_{|\Gamma|}(P,t),
 \tag{2.4}
\]
where \(V_Q(P,t)=\sum_{\ell\le t}\binom P\ell(Q-1)^\ell\).
Consequently, for relative distance \(\Delta=d/P\) and fixed alphabet,
\[
 \frac1P\sum_j\log_{|\Gamma|}p_j
 \le 1-\Delta+H_{|\Gamma|}(\varepsilon)+o(1).
 \tag{2.5}
\]
If every proof coordinate has the full alphabet projection \(p_j=|\Gamma|\), then
\(\Delta\le H_{|\Gamma|}(\varepsilon)+o(1)\).

The proof is the rectangular-hull covering count followed by the Singleton bound:
\(\prod_jp_j\le|\mathcal Y|V_{|\Gamma|}(P,t)\) and
\(|\mathcal Y|\le|\Gamma|^{P-d+1}\). Thus Proposition 2.3 is an independent
coding obstruction for a symbol-rich rectangular ACRR interface. It does not apply
to ordinary target-relative coordinate verifiers unless they also supply this
rectangular closure property; same-seed/global-word coupling is precisely a way to
leave the black-box hypothesis.

### Theorem 2.4 (global-word target-channel trichotomy)

Let \(\mathcal M\) be a finite message set, let
\(Y:\mathcal M\hookrightarrow\Gamma^L\) be injective with minimum Hamming distance
greater than \(2t\), and let \(M\) be uniform on \(\mathcal M\).  Let \(S\) be any
policy object and \(Z=(Z_1,\ldots,Z_L)\) any jointly distributed output.  If
\[
 p:=\Pr\!\left[d_H(Z,Y(M))\le t\right],
\]
then, with all information quantities in bits,
\[
 I(M;S)+\sum_{j=1}^{L}I(M;Z_j\mid S)
 +\mathbb E\!\left[\operatorname{TC}_2(Z\mid M,S)\right]
 \ge p\log_2|\mathcal M|-1.
\tag{2.6}
\]
Here
\[
 \operatorname{TC}_2(Z\mid M,S)
 :=\sum_{j=1}^{L}H_2(Z_j\mid M,S)-H_2(Z\mid M,S).
\]
Thus a global-word construction with constant success must pay in at least one of
three channels: target information in the policy, coordinatewise target information
in the outputs, or target-conditioned joint correlation.  If the output randomness is
conditionally independent across coordinates given \((M,S)\), the last term vanishes.
This theorem is purely information-theoretic; it does not assume linearity, a finite
policy description, or a PCP-specific verifier.

The proof is given as Corollary 6.7C.  Its role in the present paper is to make the
remaining global-relation interface explicit: a short policy and low-information
coordinate marginals cannot be upgraded to a successful common word without a
genuinely joint relation.

### Theorem 2.5 (descriptor--transcript index-entropy gate)

Let \(S\) be uniform on \([L]\), let \(D\) be a target-dependent descriptor, and let
\[
 W=((J_t,\widehat Y_t))_{t\le R},
 \qquad \widehat Y_t\in\Gamma\cup\{\bot\}.
\]
Suppose a target-independent procedure, using only \((D,W)\), outputs a list
\(B\subseteq[L]\) of size at most \(\lambda\) and satisfies
\(\Pr[S\notin B]\le\eta<1\).  Then
\[
 I(S;D)+I(S;J_1,\ldots,J_R\mid D)+R\log_2(A+1)
 \ge (1-\eta)\log_2(L/\lambda)-h_2(\eta),
\tag{2.7}
\]
where \(A=|\Gamma|\).  In particular, if the sampled coordinates are independent of
\((S,D)\) and \(D\) has \(d\) bits, then
\[
 d+R\log_2(A+1)
 \ge (1-\eta)\log_2(L/\lambda)-h_2(\eta).
\tag{2.8}
\]
Thus a non-singleton list cannot hide its target index simultaneously in a short
descriptor, a target-dependent address schedule, and a short common-proof transcript.
The proof is the list-Fano argument in Theorem 6.27.

### Theorem 2.6 (partition-and-agreement coordinate-flip barrier)

Consider a compiler with input coordinates \(I=[n]\), a multiset \(E\) of ordered
\(k\)-tuples, and a partition \(E=\bigsqcup_t E_t\).  For each \((e,s)\), its left
symbol contains the original \(k\)-tuple constraint together with an extra \(s\)-entry
when \(s\notin e\); if \(s\in e\), the graph retains the corresponding repeated
agreement slot but there is no independent second \(s\)-value. All \(k+1\) entries
are checked by agreement with the right assignment, and the decoder for coordinate
\(t\) reads the extra entry under distribution \(\nu_t\) on \(E_t\).  Assume the zero
word is perfectly decoded and that the extra-slot alphabet allows a single coordinate
\(t\) to be flipped without changing the base restriction.
Define
\[
 \lambda_t:=\mathbb E_{(e,s)}
   \bigl[\#\{j:v_j=t\}\bigr],\qquad
 \gamma_t:=\Pr_{(e,s)}[s=t\land t\in e],\qquad
 a_t:=\Pr_{e\sim\nu_t}[t\in e],
\]
and let \(\omega_t\) be the global probability of decoding coordinate \(t\).  Then
the single-coordinate flip gives a near assignment with exact constraint defect
\((\lambda_t+\gamma_t)/(k+1)\) and decoding error \(\omega_t(1-a_t)\).  Consequently every
\((\eta,\varepsilon)\)-unique-decoding guarantee for the singleton language
\(\{0^n\}\) must satisfy
\[
 \varepsilon\ge\frac{\lambda_t+\gamma_t}{k+1}
 \Longrightarrow
 \eta\ge\omega_t(1-a_t).
\tag{2.9}
\]
In the normalization \(\varepsilon=\rho\eta/(2(k+1))\),
\[
 \eta\ge\min\left\{\frac{2(\lambda_t+\gamma_t)}{\rho},\,
 \omega_t(1-a_t)\right\}.
\tag{2.10}
\]
Thus repetition, degree regularization, and changing the underlying PCPP cannot by
themselves create coordinate robustness: the compiler must make \(a_t\) close to one,
change the decoding distribution, or abandon the free-extra-slot/agreement architecture.
The proof is the explicit flip construction in Theorem 6.30.

## 3. The bottom-or-cubic dichotomy

Define the global half-radius two-branch mass (the infimum ranges jointly over the
target message, coordinate, and received proof)

\[
 \tau_{\rho/2}:=
 \inf_{m\in\{0,1\}^k,\ i\in[k],\ z:\,\operatorname{dist}(z,\Pi(m))\le\rho/2}
       \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr).
\]

### Theorem 3.1

Assume the binary interface, (q=2), and \(\beta\le1/3\). Either

\[
 \tau_{\rho/2}<\frac23+\beta,
\tag{3.1}
\]

or message-inline decoding produces a constant-radius, three-query binary LDC. Consequently,
whenever the binary three-query LDC lower bound of
Alrabiah--Guruswami--Kothari--Manohar applies to this (possibly adaptive) decoder,

\[
 k+P=\Omega_{\rho,\beta}\!\left(\frac{k^3}{\log^6 k}\right).
\tag{3.2}
\]

### Proof idea

If (3.1) fails, read the inline message bit (b), run the verifier for claim (b), and
output (b) on acceptance and (1-b) on rejection. The half-radius mass lower bound makes
the correct branch sufficiently likely on every near-proof; the wrong-branch bound controls
the opposite inline bit. The proof-distance conclusion and the binary Singleton inequality
ensure that a constant-radius corruption of the inline code leaves the proof suffix inside
the half-radius neighborhood. This gives a three-query ordinary LDC, and (3.2) follows from
the external lower bound. \(\square\)

Thus `bottom` is not a cosmetic implementation detail. In this parameter window it is the
only remaining structural escape from the cubic LDC barrier.

## 4. Fixed-alphabet closure and the growing-locality threshold

### Lemma 4.0 (fixed-tape exposure of adaptive local decoders)

Let a randomized adaptive decoder over a proof alphabet \(\Sigma\), \(|\Sigma|=A\), make at
most \(r\) proof-symbol queries on each random tape. For a fixed random tape, expose the
full \(A\)-ary decision tree of possible query transcripts and query the union of all its
internal nodes nonadaptively. The resulting decoder has exactly the same output distribution,
radius, completeness, and relaxed-decoding error, and uses at most
\[
T_r(A):=\sum_{j=0}^{r-1}A^j
\tag{4.0}
\]
proof queries. The nonadaptive query set depends on the coordinate and random tape, but not
on the received proof word.

If the decoder first reads one inline symbol that selects one of two depth-\(r\) branch
verifiers, querying the inline symbol together with the union of both branch trees gives
the same guarantee with at most \(1+2T_r(A)\) queries.

#### Proof

For a fixed random tape, every possible answer string determines one path in the adaptive
decision tree. Querying every internal node in advance reveals all symbols needed to simulate
the path selected by the received answers, so the simulation is identical to the adaptive
one. A depth-\(r\) tree has at most \(T_r(A)\) internal query nodes. The union operation is
performed separately for each random tape, hence the random-tape distribution and every
promise or radius condition are unchanged. For two branches, take the union of the two
trees and include the inline query. \(\square\)

### Lemma 4.0A (quantile branch-support exposure)

The worst-case \(A\)-ary tree in Lemma 4.0 can be replaced by a quantile of the
actual common support of the two branches.  For fixed coordinate \(i\) and random
tape \(\omega\), let \(U_{i,b}(\omega)\) be the union of all proof positions that
can be queried on any answer path of branch \(b\), and put
\[
  U_i(\omega):=U_{i,0}(\omega)\cup U_{i,1}(\omega),
  \qquad s_i(\omega):=|U_i(\omega)|,
\tag{4.0A}
\]
\[
  \tau(T):=\max_i\Pr_\omega[s_i(\omega)>T].
\tag{4.0B}
\]
Assume these finite supports are uniformly exposable from \((i,\omega)\).  If
\(\tau(T)\le\sigma_0-\gamma\) for some fixed \(\gamma>0\), then independent
resampling and thresholding give a non-adaptive finite-alphabet RLDC for the
inline code with constant radius, completeness at least \(2/3\), wrong-output
probability at most \(1/3\), and
\[
  Q_T\le 1+R_\gamma T,
  \qquad R_\gamma=O(\gamma^{-2}).
\tag{4.0C}
\]
Thus every subsequent RLDC lower bound may use \(Q_T\), rather than the worst-case
bound \(1+2\sum_{j<r}A^j\).  In particular, for the GGS radius window,
\[
 N\ge
\left(
 \frac{(2/3)^2 k}
 {38Q_T^4\log^2(A+2)\log^2 k}
\right)^{1+1/\lceil 3Q_T/2\rceil}.
\tag{4.0D}
\]

Indeed, truncate a fixed-tape exposure whenever \(s_i(\omega)>T\), returning
\(\bot\) without querying the proof.  Correct-branch completeness is then at
least \(1-\tau(T)\), while target-relative wrong-branch acceptance remains at
most \(1-\sigma_0\).  The gap is at least \(\gamma\); \(R_\gamma\) fresh tapes
and a midpoint threshold give the stated \(2/3\)--\(1/3\) guarantees by
Hoeffding.  The inline symbol is read once and each repetition queries at most
\(T\) proof positions.  The proof-distance and radius argument is unchanged.
This is a support-quantile statement, not an average-query assertion: an
expectation bound enters only after a separate tail estimate, for example
\(\tau(T)\le\mathbb E[s_i]/T\) by Markov.

In particular, define
\[
  T_\gamma(k):=\inf\{T:\tau(T)\le\sigma_0-\gamma\}.
\tag{4.0E}
\]
The near-linear consequence of Theorem 4.1 applied to Lemma 4.0A implies
\[
  T_\gamma(k)
  =\Omega_{\rho,\gamma,A,c}\!\left(
    \gamma^2\frac{\log k}{\log\log k}
  \right)
\tag{4.0F}
\]
whenever \(N_k\le k(\log k)^c\) infinitely often.  Hence a surviving
coordinate-robust construction must expose \(\Omega(\gamma^2\log k/\log\log k)\)
common proof positions with probability at least \(\sigma_0-\gamma\) at some
message coordinate; rare large decision trees cannot be the only source of
locality.

The preceding compiler can be combined with the arbitrary-alphabet lower bound for
non-adaptive relaxed locally decodable codes. This gives a quantitative statement that is
stronger than the fixed-query corollary: it identifies the first possible locality scale for
any near-linear common proof.

### Theorem 4.1 (finite-alphabet adaptive closure)

Fix a proof alphabet \(\Sigma\) of size \(A\ge2\), constants \(0<\rho<1\) and
\(0<\sigma_0\le1\), and let \(\Pi:\{0,1\}^k\to\Sigma^P\). For each message coordinate
\(i\) and claim \(b\in\{0,1\}\), suppose a randomized adaptive verifier makes at most
\(r=r(k)\) proof-symbol queries and satisfies

\[
 p_{i,m_i}(\Pi(m))=1,
 \qquad
 d_H(z,\Pi(m))\le\rho P\Longrightarrow
 p_{i,1-m_i}(z)\le1-\sigma_0 .
\tag{4.1}
\]

Put

\[
 Q:=1+2\sum_{j=0}^{r-1}A^j,
 \qquad a:=\left\lceil Q/\sigma_0\right\rceil .
\tag{4.2}
\]

Let \(0<\delta_0=\delta_0(\rho,A)<1\) be the constant inline radius obtained in the
proof below.  If the GGS radius-window condition
\[
 \delta_0>N^{-\sigma_0/(2Q)}
\tag{4.3a}
\]
holds, then, for all sufficiently large \(k\), the inline length \(N=k+P\) obeys

\[
 N\ge
 \left(
 \frac{\sigma_0^2 k}
 {38Q^4\log^2(A+2)\log^2 k}
 \right)^{1+1/a}.
\tag{4.3}
\]

If (4.3a) fails, then
\[
 Q\ge
 \frac{\sigma_0\log N}{2\log(1/\delta_0)}
 =\Omega_{\rho,A,\sigma_0}(\log k),
\tag{4.3b}
\]
so radius-window failure is itself a stronger locality lower bound.  Consequently,
if \(N\le k(\log k)^c\) for infinitely many \(k\), then

\[
 Q=\Omega_{A,\rho,\sigma_0,c}\!\left(\frac{\log k}{\log\log k}\right).
\tag{4.4}
\]

#### Proof

Tag the first \(k\) inline coordinates by \((I,b)\) and every proof symbol by
\((P,a)\), where \(a\in\Sigma\). The target word is
\(C(m)=((I,m_i))_{i\le k}\Vert((P,\Pi(m)_j))_{j\le P}\). The target-relative
soundness in (4.1), together with perfect correct-branch completeness, gives relative proof
distance greater than \(\rho\). The \(A\)-ary Singleton bound therefore gives
\(P/(k+P)\ge c_{\rho,A}>0\) for all large \(k\). Hence a constant fraction of the inline
distance budget leaves the proof suffix within distance \(\rho P\), giving the constant
radius \(\delta_0(\rho,A)\) used above.

On a close word the decoder reads the inline tag, rejects malformed tags with \(\bot\), and
simulates the corresponding branch; malformed proof tags also produce \(\bot\). It is thus a
weak adaptive RLDC with radius \(\delta_0=\delta_0(\rho,A)>0\) and success at least
\(\sigma_0\). Lemma 4.0 exposes both branch trees and the inline query, giving exactly the
nonadaptive query bound \(Q\) in (4.2) without changing the output distribution. If (4.3a)
holds, Goldberg--Gur--Saraogi's arbitrary-alphabet non-adaptive
RLDC lower bound gives (4.3). If (4.3a) fails, taking logarithms gives (4.3b).
For the near-linear consequence it is enough to consider the complementary regime
\(Q\le\eta\log k/\log\log k\), where \(N\le k(\log k)^c\) and \(N\ge k\) imply
\[
 N^{-\sigma_0/(2Q)}
 \le(\log k)^{-\sigma_0/(2\eta)}
 <\delta_0
\]
for all sufficiently large \(k\), so (4.3a) is valid on precisely the branch where
the GGS inequality is used.

For completeness, put \(g=\log k/\log\log k\) and suppose \(Q\le\eta g\). Since
\(a=\lceil Q/\sigma_0\rceil\), for large \(k\) we have

\[
 a\le \frac{2\eta}{\sigma_0}g,
 \qquad
 \frac{\log k}{a}\ge \frac{\sigma_0}{2\eta}\log\log k.
\tag{4.4a}
\]

Writing

\[
 D:=\frac{38Q^4\log^2(A+2)\log^2 k}{\sigma_0^2},
\]

the same assumption gives

\[
 \log D\le 6\log\log k+O_{A,\sigma_0,\eta}(1).
\tag{4.4b}
\]

Taking logarithms in (4.3) and using \(N\le k(\log k)^c\) yields

\[
 \frac{\log k}{a}
 \le c\log\log k+(1+1/a)\log D
 \le (c+12)\log\log k+O_{A,\sigma_0,\eta}(1).
\tag{4.4c}
\]

Choose \(\eta<\sigma_0/[4(c+12)]\). Equations (4.4a) and (4.4c) then contradict
each other for all sufficiently large \(k\). Hence \(Q\ge\eta g\), proving (4.4).
\(\square\)

For binary proofs, \(Q=2^{r+1}-1\), so there is a constant
\(C=C(\rho,\sigma_0,c)\) such that every
\(r\le\log_2\log k-\log_2\log\log k-C\) is ruled out. The theorem does not assert
existence at the threshold; it says that any surviving near-linear construction must pay this
locality, or leave the fixed-alphabet/positive-radius/target-relative model.

The source theorem of Goldberg--Gur--Saraogi is stated for non-adaptive RLDCs and explicitly
leaves general adaptive RLDC lower bounds as an open direction. The adaptive statement above
is therefore a derived extension: after fixing the random tape, the two claim branches are finite
decision trees, and querying their union removes adaptivity without changing the radius or the
target-or-bottom guarantee. The exponential factor \(Q=1+2\sum_{j<r}A^j\) is the exact price of
this compilation; it is not being hidden inside the cited non-adaptive theorem.

### Corollary 4.1C (source-safe joint alphabet--locality envelope)

The fixed-alphabet assumption in Theorem 4.1 can be relaxed without invoking the
parameterized DGL transfer. Let \(A_k=|\Sigma_k|\) vary with \(k\), and retain the
common proof, positive-radius, perfect-completeness and target-relative gap hypotheses.
Put
\[
 Q_k:=1+2\sum_{j<r_k}A_k^j,\qquad
 H_k:=\log\log(k+2)+\log(Q_k+2)
       +\log\!\bigl(\log(A_k+2)+2\bigr).
\]
If \(N_k=k+P_k\le k(\log(k+2))^c\) infinitely often, then for all sufficiently large
such \(k\),
\[
 \log A_k\ge k/2
 \quad\text{or}\quad
 Q_kH_k=\Omega_{\rho,\sigma_0,c}(\log k).
\tag{4.4C}
\]
Thus a growing alphabet is not a free escape: unless one symbol itself carries
message-scale information, it must pay the joint GGS query--alphabet envelope.

#### Proof

The two claim branches force proof-image distance \(>\rho\). If
\(\log A_k<k/2\), the \(A_k\)-ary Singleton bound gives
\[
 \frac{P_k}{N_k}\ge\frac{1}{2(1-\rho)\log A_k+1}.
\]
Consequently the inline radius can be taken as
\(\delta_{*,k}=\Omega_\rho(1/(\log A_k+1))\). If
\(\delta_{*,k}\le N_k^{-\sigma_0/(2Q_k)}\), then
\[
 Q_k\bigl(\log(\log A_k+2)+1\bigr)=\Omega_{\rho,\sigma_0}(\log k),
\]
which implies (4.4C). Otherwise the decision-tree union gives a non-adaptive
\((Q_k,\delta_{*,k},\sigma_0)\)-RLDC over alphabet \(A_k+2\), and GGS gives
\[
 N_k\ge
 \left(
 \frac{\sigma_0^2 k}
 {38Q_k^4\log^2(A_k+2)\log^2 k}
 \right)^{1+1/a_k},
 \qquad a_k=\left\lceil Q_k/\sigma_0\right\rceil .
\]
For the contradiction branch \(Q_kH_k\le\eta\log k\), the base in this
display is greater than one for all sufficiently large \(k\). Taking logarithms
there, using \(N_k\le k(\log(k+2))^c\), and weakening
\(1/a_k\ge\sigma_0/(Q_k+\sigma_0)\), yields
\[
 \frac{\sigma_0\log k}{Q_k+\sigma_0}
 \le O_{\rho,\sigma_0,c}(H_k),
\]
and hence \(Q_kH_k=\Omega(\log k)\), since \(Q_k\ge1\).
\(\square\)

The complete source-safe parameter calculation is in
[note 300](../../../mcsp-hardness-magnification/notes/300-source-safe-joint-alphabet-locality-envelope-2026-08-17.md).
Unlike Proposition 4.2C, this corollary does not rely on a uniform growing-parameter
extension of DGL.

### Proposition 4.1A (branch-gap--locality phase boundary)

The same closure remains quantitative when honest completeness and wrong-claim soundness vary
with the message length. Let the binary branch verifiers have locality \(r=r(k)\), and suppose
there are \(0\le\beta_k<\alpha_k\le1\) such that, uniformly over messages and coordinates,

\[
 p_{i,m_i}(\Pi_k(m))\ge\alpha_k,
 \qquad
 d_H(z,\Pi_k(m))\le\rho P_k
 \Longrightarrow
 p_{i,1-m_i}(z)\le\beta_k .
\tag{4.4d}
\]

Write \(\gamma_k:=\alpha_k-\beta_k\), and assume that each branch can be independently
re-sampled. If \(N_k:=k+P_k\le k(\log k)^c\) for infinitely many sufficiently large \(k\),
then

\[
 \frac{r(k)}{\gamma_k^2}
 =\Omega_{\rho,c}\!\left(\log\log k\right).
\tag{4.4e}
\]

In particular, fixed locality forces \(\gamma_k=O(1/\sqrt{\log\log k})\) before this barrier
can cease to apply; a fixed positive branch gap still requires
\(r(k)=\Omega(\log\log k)\).

#### Proof

By a Chernoff threshold, \(t_k=O(\gamma_k^{-2})\) independent repetitions turn each branch
into a verifier with correct acceptance at least 2/3 and wrong acceptance at most 1/3.
Because \(\alpha_k>\beta_k\), the same cross-message argument as in Theorem 2.1 forces proof
distance greater than \(\rho P_k\), and the Singleton bound supplies the same constant inline
radius \(\delta_0(\rho)\). The amplified inline decoder is therefore a binary RLDC of branch depth

\[
 r'_k:=t_k r(k)=O\!\left(\frac{r(k)}{\gamma_k^2}\right).
\tag{4.4f}
\]

After fixing randomness, the inline bit and the two binary decision trees give

\[
 Q_k=1+2(2^{r'_k}-1)
\tag{4.4g}
\]

non-adaptive queries. If \(Q_k>N_k\), then \(r'_k=\Omega(\log k)\), which is already stronger
than (4.4e). Otherwise apply the arbitrary-alphabet GGS bound with alphabet 2 and success
gap 2/3. Its radius condition holds whenever
\(Q_k\le\eta\log k/\log\log k\), for a sufficiently small constant
\(\eta=\eta(\rho,c)\), because \(N_k\ge k\) and

\[
 N_k^{-(2/3)/(2Q_k)}
 \le (\log k)^{-1/(3\eta)}<\delta_0
\]

for all large k. Taking logarithms of the GGS length bound and using
\(N_k\le k(\log k)^c\) gives \(Q_k=\Omega(\log k/\log\log k)\); the explicit constant
contradiction is the same as in (4.4a)--(4.4c) with \(\sigma_0=2/3\). Combining this with
(4.4f) proves (4.4e). \(\square\)

The independent-resampling hypothesis is substantive: without it, a gap in marginal branch
acceptance need not amplify to a common proof-local verifier. Thus (4.4e) is a quantitative
closure for the resamplable branch model, not a claim about arbitrary interactive or
correlated-prover semantics.

### Corollary 4.1A (fixed-gap imperfect-completeness exponent)

The same resampling argument gives more than the near-linear phase boundary.  In the
fixed-parameter regime, a constant branch gap forces a polynomially superlinear proof
length even when the correct branch is not perfectly complete.  Under the hypotheses of
Proposition 4.1A, assume in addition that \(r,\rho\), and
\(\gamma:=\alpha-\beta>0\) are fixed constants.  Then there is a constant
\(\eta=\eta(r,\rho,\gamma)>0\) such that, for all sufficiently large \(k\),

\[
  k+P_k \ge k^{1+\eta}.
\tag{4.4e'}
\]

More quantitatively, if \(t=O(\gamma^{-2})\) independent repetitions are used in the
threshold amplification and \(q'=tr\) is the resulting adaptive proof locality, the
Dall'Agnol--Gur--Lachish relaxed-LDC lower bound gives

\[
  k+P_k \ge k^{\,1+1/O_{\rho,\gamma}(q'^2\log^2(q'+2))}.
\tag{4.4f'}
\]

The constants in the \(O(\cdot)\) depend only on the fixed radius and the amplified
completeness/soundness margins, not on \(k\).

#### Proof

Repeat each branch \(t=O(\gamma^{-2})\) times with fresh independent randomness and accept
iff at least a threshold fraction of the repetitions accept.  Chernoff bounds, with the
threshold strictly between \(\beta\) and \(\alpha\), give completeness at least \(2/3\) on
the exact target proof and wrong-branch acceptance at most \(1/3\) on every
\(\rho P_k\)-near proof.  The cross-message argument still forces the proof image
to have relative distance greater than \(\rho\), so the Singleton bound supplies the same
constant inline radius \(\delta_0(\rho)>0\).  Reading the inline message bit and running the
amplified branch yields a binary adaptive relaxed locally decodable code with locality
\(q'=tr\), constant radius, completeness at least \(2/3\), and wrong-output probability at
most \(1/3\).

Dall'Agnol--Gur--Lachish's adaptive relaxed-LDC lower bound (Corollary 7.9 of
TR20-154) applies to this imperfect-completeness convention and gives the exponent in
(4.4f').  Since \(r\), \(\rho\), and \(\gamma\) are fixed, \(q'\) is fixed, yielding
(4.4e').  \(\square\)

This is strictly stronger than the \(r/\gamma^2=\Omega(\log\log k)\) near-linear
criterion: a fixed positive gap cannot merely force a slowly growing locality; with
independent resampling it already forces a fixed polynomial length exponent.  The result
does not apply to correlated one-shot transcripts, vanishing gaps, or growing locality.

### Proposition 4.1B (length--locality exponent tradeoff)

The near-linear threshold is the endpoint of a continuous length--locality tradeoff. Keep the
binary, perfect-completeness, target-relative model of Theorem 4.1, with fixed radius
\(\rho>0\) and fixed wrong-claim gap \(\sigma_0>0\). Let \(r_k\ge1\) be the adaptive branch depth,
let

\[
 Q_k:=2^{r_k+1}-1,\qquad
 a_k:=\left\lceil Q_k/\sigma_0\right\rceil,\qquad
 D_k:=\frac{38Q_k^4\log^2 4\,\log^2 k}{\sigma_0^2}.
\tag{4.4h}
\]

Write \(N_k=k+P_k\), assume the GGS radius condition
\(\delta_0(\rho)>N_k^{-\sigma_0/(2Q_k)}\), and suppose \(D_k<k\). If

\[
 N_k\le k^{1+\varepsilon_k}
\tag{4.4i}
\]

for infinitely many sufficiently large \(k\), then on those lengths

\[
 \frac1{a_k}\le
 \varepsilon_k+\left(1+\frac1{a_k}\right)\frac{\log D_k}{\log k}.
\tag{4.4j}
\]

Consequently, whenever \(Q_k=k^{o(1)}\) and
\(\varepsilon_k+(\log Q_k+\log\log k)/\log k=o(1)\),

\[
 Q_k=\Omega_{\rho,\sigma_0}\!\left(
 \frac{1}{\varepsilon_k+(\log Q_k+\log\log k)/\log k}\right).
\tag{4.4k}
\]

Thus \(N_k\le k(\log k)^c\) recovers \(Q_k=\Omega(\log k/\log\log k)\), while the
intermediate regime \(N_k\le k^{1+\varepsilon_k}\) with
\(\varepsilon_k\gg\log\log k/\log k\) forces \(Q_k=\Omega(1/\varepsilon_k)\) up to the
displayed logarithmic correction. A fixed \(Q_k\) therefore incurs a polynomially superlinear
length exponent; the proposition is a necessary-condition phase diagram, not an existence
claim at the boundary.

#### Proof

The tagged inline compiler and decision-tree expansion from Theorem 4.1 give a binary
non-adaptive RLDC with \(Q_k\) queries, radius \(\delta_0(\rho)\), and success gap
\(\sigma_0\). Under the displayed radius hypothesis, the arbitrary non-adaptive GGS bound gives

\[
 N_k\ge\left(\frac{k}{D_k}\right)^{1+1/a_k}.
\tag{4.4l}
\]

Taking logarithms and using (4.4i),

\[
 (1+\varepsilon_k)\log k
 \ge\left(1+\frac1{a_k}\right)(\log k-\log D_k),
\]

which rearranges to (4.4j). Moreover,

\[
 \frac1{a_k}\ge\frac{\sigma_0}{Q_k+\sigma_0},\qquad
 \log D_k=4\log Q_k+2\log\log k+O_{\sigma_0}(1).
\]

Substitution into (4.4j) gives (4.4k) whenever the denominator there tends to zero; if it
does not, the displayed lower bound is only a constant-scale statement. \(\square\)

The \(Q_k\)-dependent radius assumption is explicit: this proposition does not silently extend
the GGS theorem beyond its radius window. It also does not cover growing proof alphabets; the
finite-alphabet replacement is Proposition 4.2C.

### Theorem 4.2 (finite-time response strategies)

The conclusion is unchanged if each branch has an arbitrary response strategy rather than a
short, explicitly enumerated Merlin string. Let
\(C:\{0,1\}^k\to\Sigma^P\) be injective. For each \((i,b)\), let \(\mathcal T_{i,b}\) be
the set of all deterministic response policies visible to a finite-time verifier, and let
\(V_{i,b,\tau}\) be the resulting randomized adaptive verifier. Assume that for every message
\(m\), some \(\tau\in\mathcal T_{i,m_i}\) accepts \(C(m)\) with probability at least
\(\alpha\), while every \(\tau\in\mathcal T_{i,1-m_i}\) accepts every
\(z\) with \(d_H(z,C(m))\le\rho P\) with probability at most \(\beta<\alpha\).

Assume that the all-policy support below is finite for every coordinate, and define the
all-policy support

\[
 S_i:=\bigcup_{b\in\{0,1\}}\bigcup_{\tau\in\mathcal T_{i,b}}
       \operatorname{Supp}(V_{i,b,\tau}),
 \qquad L:=\max_i|S_i|.
\tag{4.5}
\]

Then \(C\) is a weak relaxed locally decodable code at every radius \(\delta<\rho\), with
locality at most \(L\). If the verifier uses at most \(r_0\) random bits, observes at most
\(m_0\) bits of response transcript, and asks at most \(q_0\) proof-symbol queries, then

\[
 L\le q_0\,2^{r_0+m_0}A^{q_0}.
\tag{4.6}
\]

#### Proof

For a requested coordinate \(i\), query every position in \(S_i\) once. The resulting
restriction determines every finite view tree, so the induced decoder can take the supremum
over all visible policies without making further proof queries. If the policies are
effectively enumerable, this supremum is an implementation; the coding statement itself
only uses the finite support \(S_i\). Let

\[
 a_{i,b}(z):=\sup_{\tau\in\mathcal T_{i,b}}p_{i,b,\tau}(z).
\]

Output \(b\) when exactly one of \(a_{i,0}(z),a_{i,1}(z)\) exceeds
\((\alpha+\beta)/2\), and output \(\bot\) otherwise. On \(C(m)\), completeness gives the
correct output. On a \(\delta\)-near oracle, all policies for the wrong declaration remain
below the threshold, so a wrong output is impossible. The distance argument is the same as in
Theorem 2.1. Finally, an all-policy execution is determined, for the purpose of future query
addresses, by its random tape, observed response transcript, and at most \(q_0\) proof answers.
There are at most \(2^{r_0+m_0}A^{q_0}\) such views, each contributing at most \(q_0\) addresses,
which proves (4.6). \(\square\)

Combining Theorem 4.2 with the non-adaptive RLDC lower bound gives the same
\(L=\Omega(\log k/\log\log k)\) threshold for every fixed \(A\), whenever the remaining
radius and target-relative quantifiers of Theorem 4.1 hold. Thus an arbitrarily long Merlin
string is not a semantic escape: it must expose enough transcript or branch support to cross
the coding threshold, or else leave the finite-time/common-address model.

### Corollary 4.2B (finite-transcript phase boundary)

Fix \(A\ge2\) and a proof-query budget \(q_0\).  Suppose a finite-time response interface
uses at most \(r_0\) random bits and exposes at most \(m_0\) response bits before each
\(q_0\)-query proof execution.  If the common-proof construction has fixed positive radius,
fixed target-relative gap, and
\[
  N\le k(\log k)^c
\tag{4.6H}
\]
for infinitely many \(k\), then
\[
  q_0\,2^{r_0+m_0}A^{q_0}
  =\Omega_{A,c}\!\left(\frac{\log k}{\log\log k}\right).
\tag{4.6I}
\]
In particular, for fixed \(A,q_0\),
\[
  r_0+m_0
  \ge
  \log_2\log k-\log_2\log\log k-O_{A,q_0,c}(1).
\tag{4.6J}
\]

#### Proof

The view-tree bound (4.6) gives an all-policy proof support of size at most
\(L\le q_0\,2^{r_0+m_0}A^{q_0}\).  The finite-alphabet RLDC lower bound applied to
Theorem 4.2 forces \(L=\Omega_{A,c}(\log k/\log\log k)\).  Rearranging yields
(4.6I), and taking logarithms gives (4.6J). \(\square\)

Thus a finite Merlin strategy can evade the fixed-support closure only by exposing a
growing transcript, not merely by increasing the number of syntactically distinct policies.

### Theorem 4.2A (exact transcript-support frontier)

The all-policy support statement has an exact analogue that allows arbitrary postprocessing of
the full visible transcript, not only the accept/reject bit. For fixed \(i,b\), let
\(\mu_{m,i,b,z}\) be the transcript distribution of \(V_{i,b}\) on proof \(z\), and define

\[
  H_{i,b}:=\bigcup_{m:m_i=b}\operatorname{supp}\bigl(\mu_{m,i,b,\Pi(m)}\bigr).
\tag{4.7A}
\]

Let \(\omega_{i,b}(\rho)\) be the maximum, over \(m_i\ne b\) and
\(d_H(z,\Pi(m))\le\rho P\), of \(\mu_{m,i,b,z}(H_{i,b})\). Among all randomized
postprocessors that see only this transcript and are perfectly complete for every exact
message with \(m_i=b\), the smallest possible worst-case probability of outputting the wrong
claim \(b\) is exactly \(\omega_{i,b}(\rho)\). The optimum is the support filter: output \(b\)
on \(H_{i,b}\) and \(\bot\) elsewhere.

Indeed, perfect completeness forces every transcript in \(H_{i,b}\) to be mapped to \(b\) with
probability one, giving the lower bound. The support filter attains equality. Applying these
filters after reading the inline claim yields the same proof-query locality, perfect completeness,
and wrong-branch error \(\max_{i,b}\omega_{i,b}(\rho)\). Thus the RLDC lower bounds below apply to
arbitrary transcript postprocessing whenever this overlap is bounded away from one; no richer
transcript statistic or correlated postprocessing can improve it. The exact formulation and the
boundary for imperfect completeness are recorded in
[the transcript-support frontier note](../../../mcsp-hardness-magnification/notes/252-perfect-complete-transcript-support-frontier-2026-08-17.md).

### Theorem 4.2A' (exact transcript ROC frontier)

The perfect-completeness support filter has an exact imperfect-completeness analogue.  Fix
\((i,b)\), let \(\mathcal T_{i,b}\) be the full visible transcript space of \(V_{i,b}\), and
write
\[
 \mathcal H_{i,b}:=
 \{\mu_{m,i,b,\Pi(m)}:m_i=b\},
 \qquad
 \mathcal W_{i,b}(\rho):=
 \{\mu_{m,i,b,z}:m_i\ne b,\ d_H(z,\Pi(m))\le\rho P\}.
\tag{4.7B}
\]
For \(0\le\alpha\le1\), define
\[
 \operatorname{ROC}_{i,b}(\alpha,\rho):=
 \inf_{0\le f\le1}
 \left\{
 \sup_{W\in\mathcal W_{i,b}(\rho)}\mathbb E_W f:
 \inf_{H\in\mathcal H_{i,b}}\mathbb E_H f\ge\alpha
 \right\}.
\tag{4.7C}
\]
Among all randomized postprocessors that see only this transcript, output \(b\) with
probability at least \(\alpha\) on every honest target, and otherwise output either \(b\) or
\(\bot\), the minimum possible worst-case probability of outputting the wrong claim \(b\) is
exactly \(\operatorname{ROC}_{i,b}(\alpha,\rho)\).  The statement remains true for arbitrary
postprocessors: replacing every output different from \(b\) by \(\bot\) cannot decrease honest
\(b\)-completeness and cannot increase wrong-\(b\) output.

#### Proof

A randomized postprocessor is exactly a measurable function
\(f:\mathcal T_{i,b}\to[0,1]\), where \(f(\tau)\) is its probability of outputting \(b\).
The honest completeness constraints and the worst-case wrong-output objective are precisely
(4.7C), and every feasible \(f\) realizes the corresponding postprocessor.  Taking the
infimum proves the equality. \(\square\)

At \(\alpha=1\), (4.7C) reduces to the support-overlap value
\(\omega_{i,b}(\rho)\) in Theorem 4.2A.  In a finite transcript space, finite von Neumann
minimax gives a
single mixture of target-relative wrong transcript laws that certifies
\(\operatorname{ROC}_{i,b}(\alpha,\rho)>\beta\) against every \(\alpha\)-complete filter.
Consequently, if \(\operatorname{ROC}_{i,b}(2/3,\rho)\le1/3\) uniformly over \((i,b)\), the
inline claim bit plus these transcript filters yields the corresponding variable-query
\((2/3,1/3)\)-RLDC without fresh branch resampling, and the relaxed-LDC lower bounds apply.
If the ROC inequality fails, no transcript-only postprocessor can enter that RLDC closure at
the stated parameters; the construction must change the proof space, radius, completeness
target, or interaction model.

### Corollary 4.2A'' (finite-transcript closure dichotomy)

Assume that, for every \((i,b)\), the visible transcript space \(\mathcal T_{i,b}\) is finite and
records the verifier's random coins, response bits, proof-query addresses, and returned proof
symbols.  Let \(U_i\) be the union of all proof positions occurring in transcripts in either
\(\mathcal T_{i,0}\) or \(\mathcal T_{i,1}\), and put \(L:=\max_i|U_i|\).  Fix
\(0\le\beta<\alpha\le1\).  For every \((i,b)\), one of the following alternatives holds:

1. \(\operatorname{ROC}_{i,b}(\alpha,\rho)\le\beta\).  Querying \(U_i\) and the inline claim bit
   gives a common-proof relaxed decoder with locality at most \(L+1\), honest completeness
   \(\alpha\), and wrong-output probability at most \(\beta\) on the target-relative
   \(\rho\)-ball.
2. \(\operatorname{ROC}_{i,b}(\alpha,\rho)>\beta\).  Finite minimax and Carathéodory yield a
   distribution supported on at most \(|\mathcal T_{i,b}|+1\) target-relative wrong near-proof
   transcript laws such that every transcript-only filter with honest completeness \(\alpha\)
   outputs \(b\) with probability greater than \(\beta\) against that mixture.

Consequently, if the first alternative holds uniformly over all coordinates and claims, the
finite-transcript interface enters the variable-query RLDC closure.  If it fails anywhere, the
second alternative is an explicit finite adversarial certificate for the failure of every
transcript-only postprocessor at the stated parameters.

#### Proof

Theorem 4.2A' identifies the optimum transcript-only wrong-output probability with
\(\operatorname{ROC}_{i,b}(\alpha,\rho)\). In the first case, querying \(U_i\) exposes every
transcript that can be produced, so the feasible ROC filter can be evaluated without fresh proof
queries; the inline claim bit supplies the \(+1\) query. In the second case, the finite-dimensional
minimax dual gives one mixture of wrong transcript laws defeating every feasible filter, and
Carathéodory reduces its support to at most \(|\mathcal T_{i,b}|+1\). \(\square\)

### Proposition 4.2B (source-audited derived uniform relaxed-DGL extension)

The relaxed-LDC part of Dall'Agnol--Gur--Lachish is stated in their paper for
constant query complexity. Tracking their Claims 5.8--5.9 and the two-output
construction in Theorem 7.7 gives the following parameterized extension. We have
rechecked the (Q)-dependent kernel, sampling, and two-branch estimates against
the source proof; it remains a derived theorem, not a result we attribute to DGL
as stated.

Let a binary relaxed local algorithm have locality \(\ell=\ell(N)\), a fixed
positive robustness radius on both output values, and error at most \(1/3\). Put

\[
  2\le Q\le C_0\ell\log(\ell+2).
\tag{4.6A}
\]

If the raw normalized count is \(0\), the fixed explicit-input problem is
constant and is handled separately. If it is \(1\), pad to \(Q=2\); this only
changes the constant-query case.

If \(Q^3=o(\log N)\), the same valid-input set admits a sample-based relaxed
algorithm using at most

\[
  C_1\,2^Q Q\,N^{\,1-1/(2Q^2)}
\tag{4.6B}
\]

binary samples. The proof is the DGL sample theorem with the two output
branches constructed separately and their sampling stage shared; every
parameter-dependent step is uniform in \(Q\). The source-audited parameter
calculation is recorded in
[note 255](../../../mcsp-hardness-magnification/notes/255-variable-query-relaxed-dgl-theorem-2026-08-17.md);
note 254 is the earlier exploratory version. The same argument is now written as
a standalone theorem candidate, including the variable-\(Q\) proof and the RW/JK
corollary, in note 255.

Consequently, a binary relaxed LDC \(C:\{0,1\}^k\to\{0,1\}^N\) in this regime
satisfies

\[
  N\ge
  \left(
    \frac{k-1}{C_2\,2^Q Q\log(k+2)}
  \right)^{\!1/(1-1/(2Q^2))}.
\tag{4.6C}
\]

Indeed, repeat the sample decoder \(O(\log k)\) times, reuse one sample set for
all message coordinates, and apply the global-decoder information argument.
For \(Q^3=o(\log k)\) and \(N\le k^{O(1)}\), (4.6C) is

\[
  N\ge k^{\,1+\Omega(1/Q^2)}
   = k^{\,1+\Omega(1/(\ell^2\log^2(\ell+2)))}.
\tag{4.6D}
\]

This is potentially stronger for growing adaptive locality than the explicit
decision-tree expansion used below. The theorem must not be read outside the
displayed growth window: without the parameterized relaxed proof, the safe
source-level statement is the fixed-query DGL corollary, while arbitrary
growing query parameters are handled by the non-adaptive GGS route.

### Proposition 4.2D (imperfect-completeness adaptive DGL barrier)

The source-audited transfer also closes the fixed-gap imperfect-completeness
interface. Let
\(\Pi_k:\{0,1\}^k\to\{0,1\}^{P_k}\) be a common proof map. For every coordinate
\(i\) and claim \(b\), let \(V_{i,b}\) be an adaptive verifier making at most
\(r_k\) proof queries. Suppose that for constants \(\rho>0\) and
\(\Delta>0\), with \(\alpha-\beta\ge\Delta\),
\[
 \Pr[V_{i,m_i}^{\Pi_k(m)}\text{ accepts}]\ge\alpha,
\qquad
 d_H(z,\Pi_k(m))\le\rho P_k
 \Longrightarrow
 \Pr[V_{i,1-m_i}^{z}\text{ accepts}]\le\beta .
\tag{4.6K}
\]
Let \(R=O(\Delta^{-2})\), \(\ell_k=2Rr_k\), and let
\(2\le Q_k\le C_0\ell_k\log(\ell_k+2)\) be the normalized parameter in
Proposition 4.2B. In the derived-transfer window \(Q_k^3=o(\log P_k)\),
\[
 P_k\ge
 \left(
  \frac{k-1}{C_2\,2^{Q_k}Q_k\log(k+2)}
 \right)^{1/(1-1/(2Q_k^2))}.
\tag{4.6L}
\]
The distance argument below in particular gives injectivity, hence \(P_k\ge k\).
Consequently, if \(P_k\le k(\log k)^c\) infinitely often, then along that
subsequence
\[
 Q_k=\Omega_{\rho,\Delta,c}((\log k)^{1/3}),
\qquad
 r_k\log(r_k+2)=\Omega_{\rho,\Delta,c}((\log k)^{1/3}).
\tag{4.6M}
\]

Indeed, repeat both claim branches \(R\) times and threshold at
\((\alpha+\beta)/2\). Chernoff bounds give a constant-error relaxed local
decoder of radius \(\delta<\rho\) and locality \(\ell_k\); the same
completeness-versus-soundness argument forces proof-image distance \(>\rho P_k\).
Proposition 4.2B then supplies the shared-sample bound and the global information
argument gives (4.6L). If \(Q_k^3\) is below a sufficiently small constant
multiple of \(\log P_k\), the logarithmic surplus in (4.6L) contradicts
\(P_k\le k(\log k)^c\); otherwise \(Q_k^3=\Omega(\log k)\), proving (4.6M).
This is a derived growing-query theorem from the parameter-tracked DGL proof,
not a claim that DGL state this imperfect-completeness extension.

### Proposition 4.2C (joint alphabet--adaptive phase boundary)

The same parameterized transfer retains a nontrivial alphabet dependence. Let the proof
alphabet have size \(A_k\ge2\), put \(L_k=\log_2 A_k\), and let \(Q_k\) be the normalized
query count after the DGL error/randomness reduction. In the growth window
\[
 Q_k^3L_k+
 Q_k^2\!\left(\log(Q_k+2)+\log(L_k+2)\right)
 \le \eta\log P_k
\tag{4.6E}
\]
the shared-sample decoder uses at most
\[
 C A_k^{Q_k}Q_k(L_k+1)P_k^{1-1/(2Q_k^2)}
\tag{4.6F}
\]
proof symbols, for a fixed \(\eta>0\) depending only on the radius and soundness
constants. Consequently, for a common proof map
\(\Pi_k:\{0,1\}^k\to\Sigma_k^{P_k}\) with perfect correct-claim completeness,
fixed target-relative radius and fixed wrong-claim gap, the near-linear condition
\[
 P_k\le k(\log(k+2))^c
\]
infinitely often forces
\[
 Q_k^3\log_2 A_k+
 Q_k^2\!\left(\log(Q_k+2)+\log\log(A_k+2)\right)
 =\Omega(\log k).
\tag{4.6G}
\]
For fixed \(A\), this gives \(Q_k=\Omega((\log k)^{1/3})\), and hence
\(r_k\log(r_k+2)=\Omega((\log k)^{1/3})\) whenever
\(Q_k=O(r_k\log(r_k+2))\).

The proof is the finite-alphabet information argument
\((2/3)2^k\le A_k^{S_k}\) combined with (4.6F): injectivity gives
\(A_k^{P_k}\ge2^k\), and taking logarithms yields
\[
 \frac{\log k}{4Q_k^2}
 \le Q_k\log_2 A_k+
 O\!\left(\log\log k+\log(Q_k+2)+\log(\log_2 A_k+2)\right).
\]
This proposition is a derived growth-window consequence of the DGL proof, not a theorem
stated in the source paper. Its full parameter audit and boundaries are in
[note 256](../../../mcsp-hardness-magnification/notes/256-adaptive-alphabet-variable-query-phase-boundary-2026-08-17.md).

### Theorem 4.3 (the total-two-query phase transition)

The recent exponential lower bound for two-query Hamming RLDCs gives a sharp closure at the
next smaller interface. Assume a binary proof map
\(\Pi:\{0,1\}^k\to\{0,1\}^{P}\), constants \(\rho>0\) and \(\beta<1/2\), and, for every
\((i,b)\), an adaptive verifier making at most **one** proof-symbol query such that

\[
 p_{i,m_i}(\Pi(m))=1,
 \qquad
 d_H(z,\Pi(m))\le \rho P
 \Longrightarrow p_{i,1-m_i}(z)\le\beta .
\tag{4.7}
\]

Then the total proof-plus-inline length \(N:=k+P\) satisfies

\[
 N\ge 2^{\Omega_{\rho,\beta}(k)} .
\tag{4.8}
\]

In particular, a near-linear common proof with positive target-relative radius and a
one-query claim verifier is impossible. This statement is a total-query theorem: reading the
inline message tag costs one query, so a two-query verifier for the proof would produce a
three-query RLDC and is not covered by (4.8).

#### Proof

The proof-distance argument from Theorem 2.1 gives pairwise distance \(>\rho P\) for the
proof words. The binary Singleton bound therefore gives \(P/(k+P)\ge c_\rho>0\) for all
sufficiently large \(k\). Choose a constant \(\delta_0>0\) so that
\(\delta_0(k+P)\le\rho P\) in this range, and define the binary code

\[
 C(m):=((m_i))_{i\in[k]}\Vert\Pi(m)\in\{0,1\}^{N}.
\]

On input \(i\), a relaxed decoder first queries the inline bit \(y_i\), then runs the
one-query verifier for claim \(b=y_i\) on the proof suffix. It outputs \(b\) if that verifier
accepts and \(\bot\) otherwise. Thus it makes at most two adaptive queries. On an uncorrupted
codeword, \(b=m_i\) and perfect completeness gives output \(m_i\) with probability one. If
\(d_H(y,C(m))\le\delta_0N\), the proof suffix is within \(\rho P\) of \(\Pi(m)\). When
\(y_i=m_i\), the decoder outputs either \(m_i\) or \(\bot\); when \(y_i\ne m_i\), the
target-relative bound in (4.7) says that it outputs the wrong bit with probability at most
\(\beta\). Hence it outputs \(m_i\) or \(\bot\) with probability at least \(1-\beta>1/2\).
It is a weak adaptive \((2,\delta_0,1/2+\varepsilon)\)-RLDC with
\(\varepsilon=1/2-\beta\). Theorem 1 of Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu
then gives (4.8). \(\square\)

The query accounting is the point of the theorem. For a two-query proof verifier, the same
inline construction has three queries, so the exponential two-query RLDC theorem cannot be
used as a black box; the surviving case is exactly the three-query/near-cubic window studied
in Theorem 3.1 and Corollary 5.4.

### Corollary 4.4 (the next query is only superlinear)

For comparison, suppose the proof verifier in Theorem 2.2 makes two queries. Put
\(\sigma:=1-\beta\) and \(a:=\lceil 7/\sigma\rceil\). Then the inline length
\(N=k+P\) satisfies

\[
 N\ge
 \left(
 \frac{\sigma^2 k}{38\cdot 7^4\log^2 4\,\log^2 k}
 \right)^{1+1/a}.
\tag{4.9}
\]

Indeed, the inline decoder has total locality three, and fixing a random tape expands the two
binary proof-query trees into at most
\(1+2(1+2)=7\) nonadaptive query positions. Theorem 4.1 with \(A=2\) then gives (4.9).
Thus the present coding theorems exhibit an explicit phase transition: total locality two is
exponential, while total locality three is currently ruled out only at a fixed superlinear
scale (unless the bottom-or-cubic branch of Theorem 3.1 applies).

### Corollary 4.5 (linearity removes the three-query relaxation escape)

The remaining three-query escape disappears for linear proof maps. Assume the hypotheses of
Theorem 2.2, and additionally that \(\Pi\) is linear over \(\mathbb F_2\). Let
\(Q:=q+1\) be the total inline locality and put

\[
 \tau_Q:=2^{-\lfloor Q/2\rfloor}.
\tag{4.10}
\]

If \(\beta<\tau_Q\), then the inline code \(C\) is a linear \(Q\)-query LDC at a constant
radius (with constants depending on \(\rho,\beta,Q\)). In particular, for a two-query proof
verifier \((Q=3)\) and \(\beta<1/2\),

\[
 N=\widetilde\Omega(k^3).
\tag{4.11}
\]

#### Proof

By Theorem 2.2, \(C\) is a linear \(Q\)-query RLDC with perfect completeness, radius
\(\delta_\rho\), and soundness error \(\beta\). Choose \(\alpha>0\) so that
\(\beta\le(1-\alpha)\tau_Q\). The soundness-threshold theorem of
Grigorescu--Kumar--Manohar--Mon converts this RLDC into a linear \(Q\)-query LDC with
constant radius and decoding advantage. For \(Q=3\), the near-cubic lower bound for
three-query LDCs gives (4.11). \(\square\)

Thus, in the two-query proof-verifier window, a near-linear construction must be genuinely
nonlinear (or have soundness at least \(1/2\)); the bottom escape is not available as a
substitute for linearity.

### Corollary 4.6 (nonlinear low-soundness closure)

Linearity is not needed below the newer universal soundness threshold. Under Theorem 2.2, let
\(Q=q+1\) and suppose

\[
 \beta<2^{-Q}.
\tag{4.12}
\]

Then the inline code is a (possibly nonadaptive) \(Q\)-query LDC at a constant radius, and
every lower bound for \(Q\)-query LDCs transfers to the shared proof. For \(q=2\), the
condition is \(\beta<1/8\), so

\[
 N=\widetilde\Omega(k^3).
\tag{4.13}
\]

Indeed, Theorem 2.2 supplies a perfect-complete \(Q\)-query RLDC with soundness error
\(\beta\). Cheng--Li--Mao's low-soundness theorem applies whenever (4.12) holds and preserves
constant query complexity and radius. The near-cubic three-query LDC bound then gives (4.13).
Consequently, the only currently open three-query region for a nonlinear shared proof lies
between the universal threshold \(\beta=1/8\) and the linear threshold \(\beta=1/2\).

## 5. The smoothness cost of the positive field-lift route

The obstruction above is compatible with a positive semantic compiler, but that compiler makes
the remaining cost explicit. Let
\(C:\{0,1\}^k\to\Gamma^M\) be an outer code. For coordinate \(i\), let \(Q_i\) be the
honest-path query set of an adaptive decoder using at most \(q_D\) outer queries, and define

\[
 \lambda:=M\max_{i,t}\Pr[t\in Q_i].
\tag{5.1}
\]

### Proposition 5.0 (singleton distributional conditioning bridge)

Let \(f_m=m\in\{0,1\}^k\) be the target word and let a single global proof address space
support coordinate distributions \(P_i\) and local decoded bits \(D_i\).  Assume perfect
completeness on one honest proof \(\Pi(m)\).  Suppose that, for every candidate proof
\(z\) in a target-relative radius-\(\rho\) neighborhood, there is a singleton list
\(Y(z)\in\{\varnothing,\{f_m\}\}\).  Write \(V_{i,b}(z)\) for the probability that
the sampled local test accepts and its decoded bit is \(b\) (the right-hand local view is
suppressed in the notation).  The singleton condition is
\[
  \frac1k\sum_{i=1}^k
  \Pr_{(a,b)\sim P_i}\!\left[
    \text{the local test accepts and }
    D_i(a,z[a])\notin\{y_i:y\in Y(z)\}
  \right]
  \le\varepsilon .
\tag{5.0.1}
\]
Then the same proof/address space gives, for every coordinate \(i\),
\[
  \Pr[V_{i,1-m_i}(z)=1]\le k\varepsilon .
\tag{5.0.2}
\]
In particular, if \(\varepsilon\le\beta/k\), this is exactly the target-relative
wrong-claim condition with error \(\beta\); Theorem 2.2 then yields a message-inline
RLDC, and Theorem 4.1 supplies the corresponding finite-alphabet locality/length barrier.

#### Proof

If \(Y(z)=\{f_m\}\), every accepted local view decoding the wrong bit at coordinate \(i\)
is counted by the \(i\)-th summand in (5.0.1).  If \(Y(z)=\varnothing\), every accepted
view is counted.  Choose an arbitrary wrong declaration at every coordinate, with the
specified wrong declaration at coordinate \(i\).  The average in (5.0.1) is at most
\(\varepsilon\), so the \(i\)-th summand is at most \(k\varepsilon\). \(\square\)

The factor \(k\) is not a proof artifact: it is the cost of conditioning a uniform
coordinate distribution on one fixed address.  Removing it requires a nonuniform
coordinate mass bound, a stronger globally coupled predicate, or a different target
quantifier.  The quantifier separation and its explicit counterexample are recorded in
[Paper 02](../02-distributional-soundness-does-not-produce-a-global-word/paper.md).

### Proposition 5.0B (shared-seed distributional bridge)

The random-tape objection disappears under a precise extra coupling condition.  Let
\[
  Y=\{y^{(1)},\ldots,y^{(L)}\}\subseteq\Gamma^M
\]
have pairwise relative distance at least \(\Delta>0\).  Suppose that a common proof \(z\)
has local decoders
\[
  D_{j,u,\omega}(z)\in\Gamma\cup\{\bot\},
\]
where \(u\) is a global seed reused across all sampled coordinates, \(j\in[M]\) is a
fresh coordinate, and \(\omega\) is fresh local randomness.  For every target message
\(m\), every \(z\) in a target-relative radius-\(\rho\) neighborhood, and every
\(u\) in a good-seed set \(\mathcal G_z\), assume there is an index \(s_z(u)\) such that
\[
  s_{\Pi(m)}(u)=m,
  \qquad
  \Pr_{j,\omega}[D_{j,u,\omega}(z)\notin
     \{\bot,y^{(s_z(u))}_j\}]\le\varepsilon,
  \qquad
  \Pr_{j,\omega}[D_{j,u,\omega}(z)=\bot]\le\theta,
\tag{5.0B.1}
\]
and \(\Pr_u[u\notin\mathcal G_z]\le\eta\).  If
\[
  g:=\Delta-\theta-2\varepsilon>0,
\tag{5.0B.2}
\]
then \(r\) fresh coordinates, all queried with the same \(u\), identify \(s_z(u)\) with
failure probability at most \(\eta'\) on every good seed, provided
\[
  r\ge \frac{8\log((L-1)/\eta')}{g^2}.
\tag{5.0B.3}
\]
The decoder scores \(s\) by the number of sampled non-bottom outputs equal to
\(y^{(s)}_j\), and outputs a maximizer (breaking an unresolved tie by \(\bot\)).
Consequently the shared proof gives a bounded-error relaxed index decoder with proof
locality \(O(qr)\) and total failure probability at most \(\eta+\eta'\), assuming that
the candidate words \(y^{(s)}\) can be scored by an address-efficient public evaluator.

#### Proof

Fix a good \(u\) and write \(s=s_z(u)\).  For a competitor \(t\ne s\), let
\(J_{s,t}=\{j:y^{(s)}_j\ne y^{(t)}_j\}\), so
\(|J_{s,t}|/M\ge\Delta\).  On \(J_{s,t}\), a non-bottom correct output contributes
\(+1\) to the score difference between \(s\) and \(t\), a wrong output contributes at
most \(-1\), and a bottom output contributes \(0\).  The global bounds in (5.0B.1)
therefore give expected score gap at least
\(\Delta-\theta-2\varepsilon=g\).  Hoeffding's inequality for the \(r\) independent
coordinates and a union bound over \(t\ne s\) prove (5.0B.3).  Bad seeds contribute at
most \(\eta\) to the total failure probability. \(\square\)

The shared seed is essential: allowing a different ideal word for each coordinate
replaces \(s_z(u)\) by \(s_z(u,j)\), and the score-gap argument no longer applies.
Thus Proposition 5.0B is a positive bridge for a stronger, same-seed distributional
interface; ordinary DHK distributional soundness does not by itself assert this
same-seed word consistency.

### Proposition 5.0C (common-strategy public-randomness elimination)

Let \(H_n\in\{0,1\}^{N_n}\), let \(\ell_n=\lceil\log_2N_n\rceil\), and let \(R\) be an
arbitrary public random tape. Suppose one and the same response strategy
\(\mathcal S_n\) is used for every address \(a\in[N_n]\), and a deterministic verifier has

\[
 p_a:=\Pr_R\bigl[V_n(a,\sigma_n,R,\mathcal S_n(a,R))=1\bigr].
\]

Assume the fixed gap

\[
 H_n[a]=1\Rightarrow p_a\ge\alpha,\qquad
 H_n[a]=0\Rightarrow p_a\le\beta,\qquad
 \alpha-\beta\ge\gamma>0.
\tag{5.0C.1}
\]

Assume one evaluation of the verifier and strategy on \((a,R)\), including its finite
transcript and the descriptor \(\sigma_n\), has fan-in-two size at most \(u_n\). The
random-tape positions actually read by this evaluator are included in that size bound; after
fixing a sampled \(R_j\), they are ordinary hardwired constants. Then for every
\(0<\delta<1\) there is a
multiset of

\[
 t_n=O\!\left(\frac{\ell_n+\log(1/\delta)}{\gamma^2}\right)
\tag{5.0C.2}
\]

public tapes \(R_1,\ldots,R_{t_n}\) such that the nonuniform circuit

\[
 C_n(a)=\mathbf 1\!\left[
 \frac1{t_n}\sum_{j=1}^{t_n}
 V_n(a,\sigma_n,R_j,\mathcal S_n(a,R_j))>
 \frac{\alpha+\beta}{2}\right]
\tag{5.0C.3}
\]

computes \(H_n\) on every address. Its size is

\[
 \operatorname{CC}(H_n)
 \le
 O\!\left(t_n\,\operatorname{poly}(u_n,\ell_n,\log(1/\gamma))\right).
\tag{5.0C.4}
\]

In particular, the bound is independent of the public-randomness length. If
\(u_n,\gamma^{-1},\ell_n=n^{O(1)}\) and a forcing family has
\(\operatorname{CC}(H_n)>n^{\omega(1)}\), no finite public-coin strategy with one common
address-parametrized evaluator can be the missing closure mechanism.

#### Proof

For each address \(a\), let \(Y_j(a)\) be the acceptance bit obtained from an independent
sampled tape \(R_j\). Hoeffding's inequality gives

\[
 \Pr\!\left[\left|t_n^{-1}\sum_jY_j(a)-p_a\right|>\gamma/3\right]
 \le 2e^{-2t_n\gamma^2/9}.
\]

Choosing the constant in (5.0C.2) makes this probability at most \(\delta/N_n\). A union
bound over all addresses therefore gives a single sample multiset for which every empirical
mean is within \(\gamma/3\) of \(p_a\). The threshold in (5.0C.3) then separates the two
cases in (5.0C.1), and hardwiring the sample tapes yields (5.0C.4). The sampled tapes,
descriptor, and finite strategy constants are nonuniform advice; no uniform procedure for
finding them is claimed. \(\square\)

The proposition is deliberately stronger than a full transcript enumeration: public randomness
can be exponentially long, but a *common* finite strategy cannot use that length as an escape
from an address-scale \(P/\mathrm{poly}\) evaluator. If the strategy changes with \(a\), or if
the gap vanishes faster than every inverse polynomial, the conclusion no longer applies.

### Proposition 5.0D (mutual-information mixture closure)

The preceding results charge a single finite strategy.  A more general target-dependent
policy law can still be collapsed when its target information and its worst-case defect are
both small.  Fix \(0<\rho\) and \(\alpha>\beta\), and let
\[
 \Pi:\{0,1\}^k\to\Sigma^P,\qquad M\sim\mathrm{Unif}(\{0,1\}^k),
\]
where \(|\Sigma|\ge2\).  For each message \(m\), let \(S\mid M=m\) have law
\(\mu_m\) on a standard-Borel policy space, and let
\(\bar\mu=\mathcal L(S)\) be the target-independent marginal.  For a policy view \(s\),
write \(\operatorname{Comp}_{m,i,s}\) for correct-claim acceptance on \(\Pi(m)\), and
\(\operatorname{WrongAcc}_{m,i,s}(z)\) for wrong-claim acceptance on a proof \(z\).
Define
\[
\mathcal D(m,s):=
\max\!\left\{
\max_i(\alpha-\operatorname{Comp}_{m,i,s})_+,\,
\max_{\substack{i,z:\\d_H(z,\Pi(m))\le\rho P}}
(\operatorname{WrongAcc}_{m,i,s}(z)-\beta)_+
\right\}.
\tag{5.0D.1}
\]
Assume \(\mathcal D\) is measurable on the policy space (or interpret the expectations
below as outer expectations).
Set
\[
\bar\delta=\mathbb E_{M,S\sim\mu_M}\mathcal D(M,S),\qquad
I=I(M;S)\ \text{(in bits)},\qquad
\tau=\bar\delta+\sqrt{\frac{\ln2}{2}I}.
\tag{5.0D.2}
\]
For every
\[
 \tau<\Delta<\frac{\alpha-\beta}{2},
\tag{5.0D.3}
\]
there is a message subfamily \(\mathcal F_\Delta\) with
\[
 |\mathcal F_\Delta|\ge(1-\tau/\Delta)2^k
\tag{5.0D.4}
\]
such that the single marginal policy law \(\bar\mu\) satisfies, for every
\(m\in\mathcal F_\Delta\), coordinate \(i\), and
\(d_H(z,\Pi(m))\le\rho P\),
\[
\mathbb E_{\bar\mu}\operatorname{Comp}_{m,i,S}\ge\alpha-\Delta,\qquad
\mathbb E_{\bar\mu}\operatorname{WrongAcc}_{m,i,S}(z)\le\beta+\Delta.
\tag{5.0D.5}
\]
Consequently, if \(\tau/\Delta\le1/2\), a shattered coordinate set
\(J\subseteq[k]\) of size \(|J|=(1/2-o(1))k\) exists in \(\mathcal F_\Delta\).
If the policy branches have a common nonadaptive proof-query bound \(q_0\), then after
constant-gap amplification the restricted proof map
\[
 u\longmapsto \Pi(m_u),\qquad u\in\{0,1\}^{J},
\]
has a target-independent two-branch decoder with constant radius and
\[
Q_\Delta=O\!\left(q_0(\alpha-\beta-2\Delta)^{-2}\right)
\tag{5.0D.6}
\]
queries and positive gap.  If, in addition, the restricted proof map is linear (so that the
imperfect-completeness variant of the RLDC lower bound applies), or a separate
perfect-completeness compiler preserves the displayed parameters, then, with
\(\sigma_\Delta=\Theta(\alpha-\beta-2\Delta)>0\) and whenever
\(\rho/2>P^{-\sigma_\Delta/(2Q_\Delta)}\), Goldberg--Gur--Saraogi give
\[
 P\ge
\left(
\frac{\sigma_\Delta^2 |J|}
 {38Q_\Delta^4\log^2|\Sigma|\,\log^2|J|}
\right)^{\!1+\frac1{\lceil Q_\Delta/\sigma_\Delta\rceil}} .
\tag{5.0D.7}
\]
For adaptive depth-\(r\) branches, \(q_0\) in (5.0D.6) may be replaced by the
nonadaptive union bound \(2\sum_{j<r}|\Sigma|^j\).

#### Proof

Let
\(\bar D_m=\mathbb E_{S\sim\bar\mu}\mathcal D(m,S)\).  Pinsker's inequality,
Jensen's inequality, and the mutual-information identity give
\[
\mathbb E_M\bar D_M
\le \bar\delta+\mathbb E_M\operatorname{TV}(\mu_M,\bar\mu)
\le \bar\delta+\sqrt{\frac{\ln2}{2}I}
=\tau.
\tag{5.0D.8}
\]
Markov's inequality yields (5.0D.4) and \(\bar D_m\le\Delta\) on
\(\mathcal F_\Delta\), which is exactly (5.0D.5).  The family
\(\mathcal F_\Delta\) has density at least \(1/2\), so Sauer--Shelah gives a
\((1/2-o(1))k\)-coordinate shattered set \(J\).  Choose one representative
\(m_u\in\mathcal F_\Delta\) for every \(u\in\{0,1\}^{J}\).  The same marginal
\(\bar\mu\) is now a target-independent randomized verifier for every representative.
The two branch gap is at least \(\alpha-\beta-2\Delta>0\), so the standard two-branch
threshold decoder gives (5.0D.6).  If two representatives had proof distance at most
\(\rho P\), completeness for the one and wrong-claim soundness for the other, both under
\(\bar\mu\), would contradict this positive gap.  Thus the restricted proof map has
positive relative distance.  The GGS nonadaptive RLDC bound gives (5.0D.7) only under the
additional linearity or perfect-completeness/compiler condition stated above.  For a
nonlinear imperfectly complete map, (5.0D.7) is not asserted.
\(\square\)

If a public uniform sampler \(\operatorname{Sam}(m;r)\) generates \(\mu_m\), then an
independent dummy \(U\leftarrow\{0,1\}^k\) and \(\operatorname{Sam}(U;r)\) generate
\(\bar\mu\) exactly.  Hence the theorem is algorithmic under a uniform policy sampler;
without one, it remains a semantic mixture closure.  The max over coordinates and nearby
proofs in (5.0D.1) is essential: coordinate-wise or proof-wise average acceptance does
not imply (5.0D.5), so ordinary list/distributional soundness alone does not trigger this
proposition.  This strengthens the shared-seed bridge by charging target dependence through
mutual information rather than raw policy support.

The full standard-Borel statement and the Pinsker/Markov proof are recorded in
[the mutual-information mixture-closure note](../../../mcsp-hardness-magnification/notes/273-mutual-information-mixture-closure-to-rldc-2026-08-17.md).

### Proposition 5.0F (mutual-information mixture, no-resampling high-confidence closure)

The semantic mixture closure above has a fully coding-theoretic consequence in a
high-confidence region.  Use the notation of Proposition 5.0D and write

\[
  \alpha_\Delta=\alpha-\Delta,
  \qquad \beta_\Delta=\beta+\Delta.
\]

Assume, in addition to (5.0D.3), that

\[
  \beta_\Delta\le\frac13,
  \qquad 2\alpha_\Delta-\beta_\Delta\ge1.
\tag{5.0F.1}
\]

If \(\tau/\Delta\le1/2\), then the shattered submessage from Proposition 5.0D has a
binary adaptive relaxed-LDC representation with

\[
  q_{\mathrm{bin}}=1+\lceil\log_2|\Sigma|\rceil r
\tag{5.0F.2}
\]

queries, constant positive radius, completeness at least \(2/3\), and wrong-output
probability at most \(1/3\), where \(r\) bounds the adaptive proof-symbol locality of a
policy branch.  For fixed \(r,\rho,\alpha_\Delta,\beta_\Delta\), the Dall'Agnol--Gur--Lachish
lower bound gives

\[
  |J|+\lceil\log_2|\Sigma|\rceil P
  \ge |J|^{\,1+1/O_{|\Sigma|,r,\rho}(1)}.
\tag{5.0F.3}
\]

In particular, for fixed alphabet and locality, \(P\le k\,\operatorname{polylog}k\) is
impossible on infinitely many lengths.  This conclusion requires no independent branch
resampling and no linearity or perfect-completeness repair.

#### Proof

Proposition 5.0D supplies a target-independent mixture with correct and wrong branch
means at least \(\alpha_\Delta\) and at most \(\beta_\Delta\), respectively, on a subfamily
of density at least \(1/2\).  Sauer--Shelah supplies a shattered set \(J\) of size
\((1/2-o(1))k\).  Two representatives that differ on a coordinate cannot have proof
distance at most \(\rho P\), since the same mixture would then have both acceptance at
least \(\alpha_\Delta\) and at most \(\beta_\Delta\) on the same proof.  The \(A\)-ary Singleton
bound, \(A=|\Sigma|\), makes the inline proof suffix a constant fraction of the tagged
length.

Encode each proof symbol with \(\ell=\lceil\log_2A\rceil\) bits and read the inline bit
\(b\).  Sample one policy from the common mixture, run the \(b\)-branch once, output \(b\)
on acceptance, and after rejection output \(b\) with probability

\[
  q_0=\frac{1/3-\beta_\Delta}{1-\beta_\Delta}
\]

and \(\bot\) otherwise.  On a codeword the correct output probability is at least
\(\alpha_\Delta+(1-\alpha_\Delta)q_0\ge2/3\), by (5.0F.1).  If the inline bit is wrong,
the wrong output probability is at most
\(\beta_\Delta+(1-\beta_\Delta)q_0=1/3\).  A proof-symbol query costs \(\ell\) binary
queries, giving (5.0F.2); the DGL adaptive relaxed-LDC lower bound gives (5.0F.3).
\(\square\)

The full standard-Borel statement and the parameter conditions are recorded in
[the no-resampling mixture note](../../../mcsp-hardness-magnification/notes/274-mutual-information-mixture-high-confidence-dgl-closure-2026-08-20.md).

### Proposition 5.0G (mutual-information mixture to full transcript-ROC closure)

Proposition 5.0F starts from an accept/reject branch and therefore has a numerical
high-confidence condition.  The same mixture argument works after a target-dependent
policy has already supplied an arbitrary transcript filter.  This gives the sharper
interface needed for the general no-resampling regime.

Let a global policy package \(s\) contain, for every \((i,b)\), an adaptive verifier
\(V^s_{i,b}\) and a measurable filter \(f^s_{i,b}(\tau)\in[0,1]\) that outputs \(b\)
with that probability and otherwise outputs \(\bot\).  Let \(S\mid M=m\sim\mu_m\),
\(\bar\mu=\mathcal L(S)\), and define \(C_{m,i,s}\) and \(W_{m,i,b,s}(z)\) as the
correct- and wrong-claim output probabilities of the package.  For thresholds
\(\alpha>\beta\), set

\[
\mathcal D(m,s)=\max\left\{
  \max_i(\alpha-C_{m,i,s})_+,\,
  \max_{\substack{i,b,z:\,m_i\ne b\\d_H(z,\Pi(m))\le\rho P}}
  (W_{m,i,b,s}(z)-\beta)_+\right\},
\tag{5.0G.1}
\]

and let \(\bar\delta,I,\tau\) be as in (5.0D.2).  If, for some \(\Delta>0\),

\[
  \tau<\Delta,\qquad \alpha-\Delta\ge c,\qquad \beta+\Delta\le s,\qquad
  \tau/\Delta\le\tfrac12,\qquad c>s,
\tag{5.0G.2}
\]

then a density-\(\ge1/2\) subfamily has one target-independent package law
\(\bar\mu\) whose filters satisfy completeness at least \(c\) and wrong-output at most
\(s\) for every coordinate and every target-relative \(\rho P\)-near proof.  After
Sauer--Shelah restriction and binary recoding, this is an adaptive relaxed LDC with

\[
 q_{\rm bin}=1+\lceil\log_2|\Sigma|\rceil r.
\tag{5.0G.3}
\]

For \((c,s)=(2/3,1/3)\), the Dall'Agnol--Gur--Lachish lower bound therefore applies
without fresh branch resampling, accept/reject-only fallback inequalities, linearity,
or a perfect-completeness repair.

#### Proof

For \(\bar D_m=\mathbb E_{S\sim\bar\mu}\mathcal D(m,S)\), Pinsker and the
mutual-information identity give \(\mathbb E_M\bar D_M\le\tau\).  Markov and
\(\tau/\Delta\le1/2\) leave a density-\(\ge1/2\) family with \(\bar D_m\le\Delta\),
so (5.0G.2) gives the two displayed decoder inequalities under \(\bar\mu\).  Sauer--Shelah
produces \(J\subseteq[k]\) with \(|J|=(1/2-o(1))k\) and representatives indexed by
\(\{0,1\}^{J}\).  Read the inline claim bit, sample one package from \(\bar\mu\), run its
corresponding verifier once, and apply its filter.  The first inequality gives \(c\)
completeness and the second gives \(s\) wrong output on every nearby proof.  If two
representatives differing at \(i\) had proof distance at most \(\rho P\), the same
target-independent package law would give both bounds on the same proof, contradicting
\(c>s\).  Thus the restricted proof map has symbol distance \(>\rho P\); the
\(|\Sigma|\)-ary Singleton bound and binary recoding give (5.0G.3). \(\square\)

The full standard-Borel formulation and its scope are recorded in
[the full-ROC mixture closure note](../../../mcsp-hardness-magnification/notes/275-mutual-information-mixture-to-full-roc-closure-2026-08-20.md).

### Corollary 5.0H (full-ROC defect-or-information lower bound)

Assume the fixed-alphabet, fixed-locality relaxed-LDC lower bound rules out
\(P\le k\,\operatorname{polylog}k\).  If a global package has
\[
\gamma:=\min\{\alpha-c,\ s-\beta\}>0,
\]
then every near-linear common-proof construction carrying that package must obey
\[
\bar\delta+\sqrt{\tfrac{\ln2}{2}I(M;S)}\ge\gamma/2
\tag{5.0H.1}
\]
for all sufficiently large lengths on which the package exists.  Otherwise Proposition
5.0G applies with \(\Delta=2\tau\) and yields the forbidden relaxed decoder.  Thus the
remaining Gate-II escape is quantitative: it must either expose a constant robust defect,
carry a constant amount of target information, or leave the global-package model.

### Proposition 5.0I (average-defect common-fiber closure)

The information threshold can be weakened from \(I=O(1)\) to \(I=o(k)\) if we return a
single fixed package rather than a marginal mixture.  Let \(\mathcal D(m,s)\) be the
full package defect in (5.0G.1), let \(\bar\delta=\mathbb E\mathcal D\), and choose
fixed \(0<\eta<1/2\), \(0<\Delta<(\alpha-\beta)/2\) with
\(\alpha-\Delta\ge c>s\ge\beta+\Delta\).  Put
\[
p=1-\frac{\bar\delta}{\eta\Delta}.
\tag{5.0I.1}
\]
If \(p>0\), there is a fixed package \(s_\star\) and a target fiber \(F\) of size
\[
|F|\ge2^{\,k+\log_2p-\frac{I/p+h_2(\eta)}{1-\eta}}
\tag{5.0I.2}
\]
on which \(s_\star\) has completeness \(c\) and wrong output \(s\) simultaneously for
all coordinates and target-relative nearby proofs.  Hence Sauer--Shelah and the inline
construction give the same adaptive RLDC as Proposition 5.0G.  In particular,
\(\bar\delta=o(1)\) and \(I=o(k)\) imply a \((1/2-o(1))k\)-coordinate shattered
submessage, and the \((2/3,1/3)\) DGL lower bound applies.

#### Proof

Let \(d_m=\mathbb E_{S\sim\mu_m}\mathcal D(m,S)\).  Markov leaves a target set
\(T=\{m:d_m\le\eta\Delta\}\) of size at least \(p2^k\).  Conditioning on \(T\)
increases mutual information by at most \(1/p\), while every target in \(T\) has
policy-good mass at least \(1-\eta\) after thresholding \(\mathcal D\) at \(\Delta\).
The entropy chain for the good event then gives (5.0I.2) for one fixed package.
That package is robust with thresholds \(\alpha-\Delta,\beta+\Delta\), so the proof
distance, inline decoder, and DGL conclusion follow as before. \(\square\)

The full conditional-fiber proof is recorded in
[the average-defect common-fiber note](../../../mcsp-hardness-magnification/notes/277-global-average-defect-to-common-roc-fiber-2026-08-20.md).

### Proposition 5.0J (transcript-information decoupling)

The preceding policy-level gates do not cover the case in which the ideal valid word
itself is selected after the local coordinate and transcript are exposed.  Let
\(J\in[M]\), \(X\in\Sigma\cup\{\bot\}\), and let \(T=(J,X,U)\) contain the coordinate,
output, and any public local view.  If a random \(Y\in\mathcal Y\subseteq\Sigma^M\)
satisfies
\[
 \Pr[X\ne Y_J]\le\varepsilon,\qquad I_2(Y;T)\le\iota,
\tag{5.0J.1}
\]
then some fixed \(y^\star\in\mathcal Y\) satisfies
\[
 \Pr_T[X\ne y^\star_J]
 \le \varepsilon+\sqrt{\frac{\ln2}{2}\,\iota}.
\tag{5.0J.2}
\]
If every fixed valid word has error at least \(\varepsilon+\gamma\), then necessarily
\[
 I_2(Y;T)\ge\frac{2\gamma^2}{\ln2}.
\tag{5.0J.3}
\]
When the valid words have relative distance \(\Delta\) and the right side of (5.0J.2)
is below \(\Delta/2\), Theorem 2.1 identifies a candidate word. This yields the
indexed-channel/RLDC interface only if the same \(y^\star\) can be selected throughout
the relevant radius neighborhood (for example, from one common seed/coupling fixed before
the proof is chosen); pointwise minimizers \(y^\star_z\) depending on the nearby proof do
not define a codeword map.

The proof is a direct Pinsker comparison between the joint law \(P_{Y,T}\) and
\(P_Y\otimes P_T\).  The transcript, not merely the coordinate, is essential: \(I(Y;J)=0\)
can coexist with \(X=Y_J\) for a random codeword, while \(I(Y;(J,X))\) records the
information exposed by the local output.  This is complementary to the policy-level
\(I(M;S)\) in Proposition 5.0D and to the same-seed hypothesis in Proposition 5.0B.
See [the transcript-information note](../../../mcsp-hardness-magnification/notes/332-mutual-information-decoupling-for-distributional-global-words-2026-08-18.md)
for the proof and the dPCP/RW boundary.

### Proposition 5.0K (connected-neighborhood global-word uniformization)

The pointwise word in Proposition 5.0J becomes a single word under a quantitative
continuity condition on the proof neighborhood.  Let \(\mathcal Z\) be a finite set of
proof states connected by a graph \(\mathcal G\).  For every \(z\in\mathcal Z\), let
\(T_z=(J,X_z,U_z)\) have law \(P_z\), where \(J\sim\lambda\) is a fixed coordinate
distribution, \(X_z\in\Gamma\cup\{\bot\}\), and \(U_z\) is arbitrary public transcript
data.  Let \(\mathcal Y\subseteq\Gamma^M\) satisfy

\[
 \Delta_\lambda:=\min_{y\ne y'\in\mathcal Y}
   \Pr_{J\sim\lambda}[y_J\ne y'_J]>0.
\tag{5.0K.1}
\]

Suppose that, for each \(z\), there is a random \(Y_z\in\mathcal Y\) with

\[
 \Pr[X_z\ne (Y_z)_J]\le\varepsilon,
 \qquad I_2(Y_z;T_z)\le\iota,
\tag{5.0K.2}
\]

and that every edge \(zz'\) of \(\mathcal G\) satisfies

\[
 \lVert P_z-P_{z'}\rVert_{\mathrm{TV}}\le\tau.
\tag{5.0K.3}
\]

Writing \(\alpha=\varepsilon+\sqrt{(\ln2/2)\iota}\), if

\[
 2\alpha+\tau<\Delta_\lambda,
\tag{5.0K.4}
\]

then there is one \(y^\star\in\mathcal Y\) such that

\[
 \Pr_{T_z}[X_z\ne y^\star_J]\le\alpha
 \qquad\text{for every }z\in\mathcal Z.
\tag{5.0K.5}
\]

If in addition \(\mathcal Z\subseteq\Sigma^N\) is Hamming-connected by edges changing one
proof position and the same adaptive transcript generator is used at every state, define

\[
 h^\star:=\max_{z\in\mathcal Z,\,p\in[N]}
   \Pr_{T_z}[\text{the generator queries position }p].
\tag{5.0K.6}
\]

Then either (5.0K.5) holds with \(\tau=h^\star\), or

\[
 h^\star\ge\Delta_\lambda-2\alpha.
\tag{5.0K.7}
\]

Thus a distributional construction can avoid a common word only by creating a constant
query peak, or by leaving the fixed-coordinate/separated-word model.

#### Proof

Proposition 5.0J applied to each \(P_z\) gives a word \(y_z\in\mathcal Y\) with
\(e_z(y_z):=\Pr[X_z\ne(y_z)_J]\le\alpha\).  Along an edge, total variation gives
\(e_{z'}(y_z)\le\alpha+\tau\).  If \(y_z\ne y_{z'}\), then at least one of the two
comparisons with \(X_{z'}\) is wrong on the coordinate event
\(y_z(J)\ne y_{z'}(J)\), so

\[
 e_{z'}(y_z)+e_{z'}(y_{z'})\ge\Delta_\lambda,
\]

contradicting (5.0K.4).  Connectivity makes all \(y_z\) equal, proving (5.0K.5).

For the final assertion, adjacent states differ at one position \(p\).  Coupling the
same random tape shows that their visible transcript laws differ only if \(p\) is queried,
so their total variation is at most the corresponding query probability and hence at most
\(h^\star\).  If no common word exists, a path between two states with different pointwise
words contains an edge with different endpoint words; the preceding inequality then forces
\(h^\star\ge\Delta_\lambda-2\alpha\).  \(\square\)

This proposition is a bridge for the distributional route: it replaces an unquantified
“the selected valid word may change with the proof” by either a common-word closure condition
or a measurable address-scale peak.  The TV/connectivity hypothesis is not supplied by
ordinary average/list soundness; proving it, or proving a source-specific first-hit
patchability statement from the peak, remains the actual RW attachment target.  Full
source boundaries and the smoothness-to-connectivity derivation are recorded in
[note 333](../../../mcsp-hardness-magnification/notes/333-connected-neighborhood-transcript-uniformization-2026-08-18.md).

### Proposition 5.0L (smooth outer-code composition)

Proposition 5.0K closes directly to a shared-proof coordinate-robust interface when its
common word is the image of a smoothly decodable outer code. Let
\(C:\{0,1\}^{k}\hookrightarrow\Gamma^{M}\) have weighted relative distance
\(\Delta_\lambda>0\), and let \(\Pi(m)\in\Sigma^{P}\) be a common proof map. For every
outer position \(j\), suppose a local call \(L_j\) uses at most \(q_P\) proof queries,
returns a symbol in \(\Gamma\cup\{\bot\}\), and satisfies

\[
 L_j(\Pi(m))=C(m)_j
 \quad\text{with probability one.}
\tag{5.0L.1}
\]

For every message coordinate \(i\), let \(D_i\) be an adaptive decoder for \(C\) using
at most \(q_D\) symbol queries and satisfying \(D_i^{C(m)}=m_i\) with probability one.
Assume that, conditional on an honest answer prefix, its next query obeys

\[
 \Pr[J_t=j]\le\chi\lambda_j.
\tag{5.0L.2}
\]

Assume further that the proof neighborhood and transcript laws, with transcript output
\(X_z=L_J(z)\), satisfy the hypotheses of Proposition 5.0K with
\(\mathcal Y=\operatorname{Im}(C)\), parameters
\((\varepsilon,\iota,\tau)\), and

\[
 \alpha:=\varepsilon+\sqrt{(\ln 2/2)\iota},
 \qquad 2\alpha+\tau<\Delta_\lambda.
\tag{5.0L.3}
\]

Then every target-relative near proof \(z\) obeys

\[
 \Pr_{j\sim\lambda,\ L_j}[L_j(z)\ne C(m)_j]\le\alpha.
\tag{5.0L.4}
\]

Moreover, using the same proof address space, the verifier that simulates \(D_i\), answers
each outer query \(j\) by a fresh independent call to \(L_j\), rejects on \(\bot\), and accepts iff the
outer output equals \(b\), uses at most \(q_Dq_P\) proof queries and satisfies

\[
 \Pr[V_{i,m_i}(\Pi(m))=1]=1,
 \qquad
 \Pr[V_{i,1-m_i}(z)=1]\le\beta:=q_D\chi\alpha.
\tag{5.0L.5}
\]

If \(\beta<1\), thresholding the two claim branches gives an adaptive relaxed local decoder
with locality

\[
 O\!\left(q_Dq_P(1-\beta)^{-2}\right).
\tag{5.0L.6}
\]

#### Proof

Proposition 5.0K supplies one word \(y^\star\in\operatorname{Im}(C)\) explaining every
near proof with error at most \(\alpha\). At the honest proof, (5.0L.1) gives zero error
for \(C(m)\). Since distinct outer codewords have weighted distance at least
\(\Delta_\lambda\) and \(\alpha<\Delta_\lambda\), necessarily \(y^\star=C(m)\), proving
(5.0L.4).

Couple the outer execution to its honest random tape. Until the first local call whose
returned symbol differs from \(C(m)_j\), the outer transcript is honest. At an honest
step, (5.0L.2) and (5.0L.4) give
\[
 \sum_j\Pr[J_t=j]\Pr[L_j(z)\ne C(m)_j]
 \le\chi\sum_j\lambda_j\Pr[L_j(z)\ne C(m)_j]
 \le\chi\alpha.
\]
There are at most \(q_D\) steps. If no first wrong call occurs, the outer decoder outputs
\(m_i\), so it cannot accept the opposite claim. A union bound proves (5.0L.5).
Finally, repeat each branch \(O((1-\beta)^{-2})\) times and use threshold
\((1+\beta)/2\); output the unique branch above threshold and \(\bot\) otherwise. Chernoff
gives (5.0L.6). \(\square\)

This is a genuine positive composition theorem, but not yet an RW theorem: the missing
attachment is precisely the common address space, transcript continuity, and honest-path
smoothness needed by Proposition 5.0K and (5.0L.2). If continuity fails, Proposition 5.0K
already charges a query peak of at least \(\Delta_\lambda-2\alpha\), rather than allowing an
untracked proof-dependent target word.

### Proposition 5.0E (selected-policy entropy barrier)

The preceding proposition handles a target-dependent *distribution* of policies by
averaging a single worst-case defect.  A complementary statement applies when every
selected policy is individually robust, even if the selected policy depends on both the
target and the coordinate.  Let

\[
  \Pi:\{0,1\}^{k}\longrightarrow\Sigma^{P}
\]

be one common proof map.  For every target \(m\) and coordinate \(i\), choose a policy
\(\tau_{m,i}\), and write
\[
  S(m):=(\tau_{m,1},\ldots,\tau_{m,k}),\qquad
  B:=|\operatorname{supp}S|.
\tag{5.0E.1}
\]
The policy space may be arbitrary; \(B\) is finite because the message cube is finite.
Assume that each fixed policy uses at most \(q\) nonadaptive proof queries and, for a
constant \(\beta<1\) and \(\rho>0\), has perfect completeness
\[
 V_{i,m_i}^{\tau_{m,i}}(\Pi(m))=1
\tag{5.0E.2}
\]
while every \(z\) with \(d_H(z,\Pi(m))\le\rho P\) satisfies
\[
 \Pr[V_{i,1-m_i}^{\tau_{m,i}}(z)=1]\le\beta .
\tag{5.0E.3}
\]
Let \(d\) be the largest VC dimension of a fiber
\[
  F_s:=\{m:S(m)=s\}.
\]
Then a fiber with a shattered coordinate set of size \(d\) yields, after message inlining, a
binary-indexed proof map of length \(N=d+P\) over an alphabet of size \(|\Sigma|+2\), with a
positive-radius, perfectly complete relaxed decoder using
\[
  Q=1+2q
\tag{5.0E.4}
\]
queries and soundness \(\sigma=1-\beta\). Hence, whenever the GGS RLDC bound is in
its radius window,
\[
 N\ge
\left(
 \frac{(1-\beta)^2 d}
 {38Q^4\log^2(|\Sigma|+2)\,\log^2 d}
 \right)^{\!1+\frac1{\lceil Q/\sigma\rceil}},
\tag{5.0E.5}
\]
where \(\sigma=1-\beta\). Moreover,
\[
  B\sum_{j=0}^{d}\binom{k}{j}\ge 2^k .
\tag{5.0E.6}
\]
Consequently, if \(B\le2^{\gamma k}\) for a fixed \(\gamma<1\), then
\[
  d\ge(\theta_\gamma-o(1))k,
  \qquad H_2(\theta_\gamma)=1-\gamma,
\tag{5.0E.7}
\]
and \(B=2^{o(k)}\) forces \(d\ge(1/2-o(1))k\). Conversely, any route whose selected-policy
fibers all have \(o(k)\) VC dimension must carry
\[
  \log_2 B\ge k-o(k)
\tag{5.0E.8}
\]
bits of target information in its policy channel.

#### Proof

Choose a fiber \(F_s\) of maximum VC dimension \(d\), and let
\(J=\{i_1,\ldots,i_d\}\) be shattered by \(F_s\). For each \(u\in\{0,1\}^{d}\), fix a
representative \(m_u\in F_s\) whose restriction to \(J\) is \(u\), and define
\[
  C_s(u):=\Pi(m_u).
\]
If two representatives differ at \(i_j\) and their proof words were within distance
\(\rho P\), then the common policy component \(s_{i_j}\) would accept the correct claim for one
with probability one, while (5.0E.3) would bound the opposite claim on the other proof by
\(\beta\), a contradiction. Thus \(C_s\) is a positive-distance code.

The \(d\)-bit inline code is
\[
  \widehat C_s(u):=
  \bigl((I,u_j)\bigr)_{j\in[d]}
  \,\Vert\,
  \bigl((P,\Pi(m_u)_\ell)\bigr)_{\ell\in[P]},
\]
where the tags use a disjoint alphabet of size \(|\Sigma|+2\).  The proof words in the
fiber have pairwise distance greater than \(\rho P\).  The \(q\)-ary Singleton bound therefore
gives \(P\ge c_{\rho,\Sigma}d\) for all sufficiently large \(d\), so a constant fraction of
the distance budget of a \(\delta_0N\)-near word lies in the proof suffix, for a constant
\(\delta_0=\delta_0(\rho,\Sigma)>0\).  To decode \(u_j\), read the inline tag and
nonadaptively query the union of the two \(q\)-query branch trees; a malformed inline tag
outputs \(\bot\), and on a valid tag \(b\),
retain the answers for \(V_{i_j,b}^{s_{i_j}}\), output \(b\) if that branch accepts, and
otherwise output \(\bot\).  On an uncorrupted codeword the inline tag is correct and the
correct branch accepts with probability one.  On a \(\delta_0N\)-near word, a correct inline
tag can only output the correct bit or \(\bot\), while an incorrect inline tag invokes the
wrong branch, which accepts with probability at most \(\beta\).  Thus \(\widehat C_s\) is a
perfectly complete \((1+2q,\delta_0,1-\beta)\)-RLDC, and the GGS lower bound gives (5.0E.5).
Finally, Sauer--Shelah bounds every fiber by
\(\sum_{j\le d}\binom{k}{j}\); summing over the \(B\) fibers proves (5.0E.6), and the
binary-entropy estimate gives (5.0E.7)--(5.0E.8). \(\square\)

This proposition is the supportwise counterpart of Proposition 5.0D.  Message inlining is
essential: it supplies the decoder with the claimed bit while preserving perfect completeness.
It does not claim that ordinary dPCP or list soundness supplies
(5.0E.2)--(5.0E.3): those notions may choose
different witnesses at different coordinates.  The theorem instead gives a sharp accounting
rule for any proposed simultaneous coordinate-robust construction: if its common proof remains
near-linear and its induced fibers do not already contain a large RLDC, the policy channel
must itself expose essentially the full target entropy.
The entropy and randomized-policy variants are recorded in
[the selected-policy VC lift](../../../mcsp-hardness-magnification/notes/271-selected-policy-vc-lift-to-rldc-2026-08-17.md).

### Corollary 5.0E' (independent resampling removes the perfect-completeness caveat)

The perfect-completeness assumption (5.0E.2) is not needed if the selected policy can be
independently resampled. Suppose instead that every correct branch accepts its exact proof
with probability at least \(\alpha\), every wrong branch accepts every
\(\rho P\)-near proof with probability at most \(\beta\), and
\(\alpha-\beta\ge\gamma>0\). On the shattered fiber from Proposition 5.0E, repeat each
branch independently \(R=O(\gamma^{-2})\) times and threshold at
\((\alpha+\beta)/2\). After inlining the claim bit, the resulting common decoder has
constant radius, completeness at least \(2/3\), wrong-output probability at most \(1/3\),
and nonadaptive query count
\[
 Q_R=1+2qR.
\tag{5.0E.9}
\]
Thus Proposition 4.1A applies. In particular, for fixed \(q,\rho,\gamma\), a
near-linear inline proof \(N=d+P\le d(\log d)^{O(1)}\) is impossible on a linear-size
shattered fiber. The only remaining caveat in Proposition 5.0E is therefore the
no-resampling/one-shot transcript regime, not imperfect completeness by itself.

### Corollary 5.0A (singleton distributional--RLDC dichotomy)

Consider a family with fixed finite proof alphabet, fixed local query budget, fixed
\(\rho>0\), common message-oblivious proof/address space, and
\[
  P_k\le k(\log k)^c
\tag{5.0.3}
\]
infinitely often.  If its singleton distributional error is \(\varepsilon_k\), then
\[
  \limsup_{k\to\infty} k\varepsilon_k\ge 1.
\tag{5.0.4}
\]
More explicitly, for every fixed \(\beta<1\), the regime
\(\varepsilon_k\le\beta/k\) eventually is impossible.

#### Proof

Under \(\varepsilon_k\le\beta/k\), Proposition 5.0 gives wrong-claim error at most
\(\beta<1\) on the target-relative radius-\(\rho\) neighborhood.  Perfect completeness
and Theorem 4.1 then give a fixed-parameter RLDC lower bound
\(k+P_k\ge k^{1+\eta}\) for some \(\eta>0\), contradicting (5.0.3).  If (5.0.4) failed,
choose \(\beta\) strictly between the limsup and \(1\); the forbidden eventual regime would
follow. \(\square\)

Thus the \(1/k\) distributional scale is a sharp boundary for this common-proof model:
improving the constant below \(1\) is not enough to retain near-linear length.  A successful
construction must change the coordinate distribution, the singleton/global-word quantifier,
the target-relative radius, or the fixed-parameter address model.

### Proposition 5.1 (smoothness penalty)

Assume the inner dPCP has a uniform complete-decoding distribution over the \(M\) outer
positions and average locally accepted wrong-projection probability at most \(\varepsilon\).
The field-lifted one-proof verifier has wrong-claim acceptance at most

\[
 q_D\lambda\varepsilon .
\tag{5.2}
\]

If every coordinate decoder is supported on a coordinate-private block of size at most \(K\),
then \(\lambda\ge M/K\), so a constant wrong-claim gap requires

\[
 \varepsilon=O\!\left(\frac{K}{q_D M}\right).
\tag{5.3}
\]

#### Proof

Couple the execution to the honest outer-code path. Until the first locally accepted
projection different from the unique honest codeword, the path is honest. At each of at most
\(q_D\) steps, the probability of visiting \(t\) is at most \(\lambda/M\), while the
uniform dPCP error budget gives average wrong-projection mass at most \(\varepsilon\). A union
bound yields (5.2). If a coordinate has all its honest query mass in a block of size \(K\), one
position in that block has mass at least \(1/K\), proving \(\lambda\ge M/K\) and (5.3). \(\square\)

### Theorem 5.1A (pathwise Lorenz closure for adaptive common proofs)

The global incidence profile in Proposition 5.1 is not needed for an arbitrary adaptive
decoder. Let
\[
  \Pi:\{0,1\}^k\longrightarrow\Sigma^N
\]
be a common proof map, and let \(D_i\) be a randomized adaptive decoder making at most
\(Q\) symbol reads and returning \(m_i\) or \(\bot\). Assume exact honest-path correctness
\[
  D_i^{\Pi(m)}=m_i
  \qquad\text{with probability one}
\tag{5.4}
\]
for every message and coordinate. For fixed \(m,i\), let \(\nu_{m,i}(v)\) be the expected
number of reads of position \(v\) on the honest proof, counting repeated reads. If
\(\nu_{m,i,(1)}\ge\cdots\ge\nu_{m,i,(N)}\) are these values in decreasing order, define
\[
  \Lambda_\rho:=
  \max_{m,i}
  \sum_{j=1}^{\lfloor\rho N\rfloor}\nu_{m,i,(j)}.
\tag{5.5}
\]
Then \(\Pi\) is a weak adaptive relaxed LDC with query count \(Q\), radius \(\rho\),
perfect completeness, and wrong-output probability at most
\(\min\{1,\Lambda_\rho\}\). In particular, if
\(\Lambda_\rho<1\), distinct proof words have relative distance greater than \(\rho\).

#### Proof

Let \(z\) differ from \(\Pi(m)\) on \(B\), with \(|B|\le\rho N\), and couple the
executions using the same random tape. Until the first read from \(B\), the adaptive
transcripts are identical. Hence the probability of a first hit is at most
\[
 \mathbb E[\#\{\text{honest reads in }B\}]
 =\sum_{v\in B}\nu_{m,i}(v)
 \le\Lambda_\rho .
\tag{5.6}
\]
If no first hit occurs, exact honest-path correctness forces output \(m_i\); therefore a
wrong output has probability at most \(\Lambda_\rho\). Perfect completeness is (5.4).
If two distinct proof words within radius \(\rho\) encoded messages differing at \(i\), the
decoder on the second proof would output the wrong bit with probability one, contradicting
\(\Lambda_\rho<1\). \(\square\)

The quantity \(\Lambda_\rho\) is exact using only the honest path: a one-bit code
\(\Pi(0)=0^N,\Pi(1)=1^N\) whose decoder samples position \(v\) with probability \(p_v\)
and outputs the read symbol has \(\Lambda_\rho=\max_{|B|\le\rho N}\sum_{v\in B}p_v\),
and this value is attained by flipping precisely \(B\). Thus no stronger
incidence-only soundness bound is possible without additional semantic structure.
The coding consequences are immediate: the GGS nonadaptive lower bound applies when the
decoder is nonadaptive and \(\Lambda_\rho\le1-\eta\), while the Cheng--Li--Mao
RLDC-to-LDC conversion applies in the adaptive case when \(\Lambda_\rho<2^{-Q}\).
The full pathwise statement and its dPCP specialization are recorded in
[note 226](../../../mcsp-hardness-magnification/notes/226-pathwise-lorenz-profile-adaptive-shared-proof-closure-2026-08-17.md).

### Corollary 5.1A' (imperfect-completeness pathwise Lorenz closure)

The same coupling survives a nonzero honest-path completeness deficit. In the
alphabet-general form, take \(\Pi:\Sigma^k\to\Sigma^N\); the preceding binary-message
notation is recovered by setting \(\Sigma=\{0,1\}\). Define
\[
 \varepsilon:=\max_{m,i}\Pr[D_i^{\Pi(m)}\ne m_i],
 \qquad s:=\varepsilon+\Lambda_\rho .
\tag{5.10}
\]
Then every \(\rho N\)-near word has wrong-output probability at most \(s\), while
the honest codeword has correct-output probability at least \(1-\varepsilon\).
Consequently, if
\[
 2\varepsilon+\Lambda_\rho<1,
\tag{5.11}
\]
the common proof map is an injective \((Q,\rho,1-\varepsilon,s)\)-RLDC, for
adaptive as well as nonadaptive decoders. The proof is the same first-hit coupling:
on paths avoiding the corruption set the received-word execution is the honest
execution, so only the honest deficit \(\varepsilon\) is lost in addition to the
Lorenz hit mass.

For nonadaptive decoders, the imperfect-completeness RLDC-to-LDC theorem of
Cheng--Li--Mao applies whenever
\[
 s<|\Sigma|^{-Q},
 \qquad
 \varepsilon\frac{|\Sigma|}{|\Sigma|-1}+s|\Sigma|^Q<1.
\tag{5.12}
\]
It gives a $Q$-query LDC at every
\[
 r<\frac{\rho(|\Sigma|-1)}{Q|\Sigma|}
 \left(1-\varepsilon\frac{|\Sigma|}{|\Sigma|-1}-s|\Sigma|^Q\right),
\tag{5.13}
\]
with error at most
\[
 \varepsilon+s|\Sigma|^Q\left(1-\frac1{|\Sigma|}\right)+\frac{rQ}{\rho}.
\tag{5.14}
\]
For binary proofs this is $r<\rho(1-2\varepsilon-s2^Q)/(2Q)$ and error
at most \(\varepsilon+s2^Q/2+rQ/\rho\). Thus imperfect completeness is not an
independent escape in the low-Lorenz, nonadaptive regime; the adaptive
imperfect-completeness upgrade remains a separate open interface.

See the [formal statement](../../statements/imperfect-pathwise-lorenz-rldc-closure.md)
for the full quantifiers and proof.

### Corollary 5.1B (near-linear imperfect-completeness Lorenz gate)

The preceding closure gives a direct near-linear dichotomy. Fix binary query count
\(Q\), positive radius \(\rho\), and a constant \(c\). If
\(N_k\le k(\log k)^c\) along infinitely many lengths, then for all sufficiently
large such lengths one cannot have simultaneously
\[
 \varepsilon_k\le\frac1{12},
 \qquad
 (\varepsilon_k+\Lambda_{\rho,k})2^Q\le\frac1{12}.
\tag{5.15}
\]
Indeed, Corollary 5.1A' and Cheng--Li--Mao give a \(Q\)-query LDC of radius
\(r=\rho/(8Q)\) and error at most \(1/4\). Treating this LDC as a nonadaptive
RLDC with success parameter \(\sigma=3/4\), the Goldberg--Gur--Saraogi lower
bound gives
\[
 N_k\ge
 \left(\frac{\sigma^2 k}{38Q^4\log^2 2\,\log^2 k}\right)^{1+1/\lceil Q/\sigma\rceil},
\tag{5.16}
\]
which contradicts the near-linear hypothesis. Thus every surviving family must
pay either a constant honest-codeword error or Lorenz mass at least on the
\(2^{-Q}\) scale. This closes the low-Lorenz nonadaptive imperfect-completeness
escape without independent branch resampling; the adaptive imperfect-completeness
case remains separate.

See the [formal statement](../../statements/near-linear-imperfect-lorenz-gate.md).

### Corollary 5.1B' (variable-query imperfect-completeness Lorenz envelope)

The fixed-\(Q\) gate has a variable-query form. Fix a positive radius \(\rho\) and a
constant \(c\). For a binary near-linear family \(N_k\le k(\log k)^c\) with
nonadaptive query count \(Q_k\), honest deficit \(\varepsilon_k\), and pathwise
profile \(\Lambda_{\rho,k}\), there is a constant \(\eta=\eta(\rho,c)>0\) such
that
\[
 \varepsilon_k\le\frac1{12},
 \qquad
 (\varepsilon_k+\Lambda_{\rho,k})2^{Q_k}\le\frac1{12}
 \quad\Longrightarrow\quad
 Q_k\ge\eta\frac{\log k}{\log\log k}
\tag{5.17}
\]
for all sufficiently large lengths. Otherwise, C317 gives a \(Q_k\)-query LDC
of radius \(\rho/(8Q_k)\) and error at most \(1/4\). If
\(Q_k\le\eta\log k/\log\log k\), the GGS radius condition holds and its length
inequality yields
\[
 \log N_k\ge\log k+\left(\frac{\sigma}{4\eta}-8\right)\log\log k,
 \qquad \sigma=3/4,
\tag{5.18}
\]
which contradicts \(N_k\le k(\log k)^c\) for sufficiently small \(\eta\). Thus
the low-Lorenz imperfect-completeness escape has the same
\((\log k/\log\log k)\) locality threshold as the perfect-completeness gate, while
adaptive imperfect completeness remains outside this particular upgrade.

See the [formal statement](../../statements/variable-query-imperfect-lorenz-envelope.md).

### Corollary 5.1C (adaptive imperfect-completeness Lorenz envelope)

The same pathwise profile gives an adaptive counterpart that does not pass through
the Cheng--Li--Mao nonadaptive conversion. Fix \(0<\rho<1\) and \(c\ge0\). For a
binary near-linear common-proof family with adaptive query count \(r_k\ge1\), if
\[
 \varepsilon_k\le\frac1{12},
 \qquad
 \varepsilon_k+\Lambda_{\rho,k}\le\frac1{12},
\tag{5.19}
\]
then
\[
 r_k\log(r_k+2)
   \ge \eta(\rho,c)(\log k)^{1/3}
\tag{5.20}
\]
at all sufficiently large near-linear lengths \(N_k\le k(\log k)^c\). Indeed,
C317 already supplies an adaptive relaxed local decoder of constant error and radius
\(\rho\); the variable-query DGL transfer of note 255 has normalized query count
\(Q_k\le C_0r_k\log(r_k+2)\). Its quantitative sample-counting contradiction forces
\(Q_k^3>\eta_0\log N_k\ge\eta_0\log k\), which yields (5.20). This is an adaptive
low-Lorenz barrier, not a nonadaptive LDC theorem or a \(P\ne NP\) result.

See the [formal statement](../../statements/adaptive-imperfect-lorenz-envelope.md).

### Corollary 5.1D (adaptive smoothness-to-Lorenz gate)

The Lorenz hypothesis in Corollary 5.1C can be checked directly from an
honest-path smoothness condition.  Suppose that, conditioned on every honest
transcript prefix, each proof position is queried at each step with probability
at most \(\chi_k/N_k\).  If the adaptive decoder has depth \(r_k\), then its
pathwise query-count profile satisfies
\[
  \Lambda_{\rho,k}\le r_k\chi_k\rho.
\tag{5.21}
\]
Consequently, for a binary near-linear common-proof family,
\[
  \varepsilon_k+r_k\chi_k\rho\le\frac1{12}
  \quad\Longrightarrow\quad
  r_k\log(r_k+2)=\Omega_{\rho,c}\bigl((\log k)^{1/3}\bigr).
\tag{5.22}
\]
Thus the adaptive escape cannot simultaneously retain small honest error, fixed
positive radius, \(o((\log k)^{1/3})\) effective locality, and a constant
\(O(1/N_k)\) honest-path point-mass bound.  The proof is the one-line estimate
\(\nu_{m,i}(v)\le r_k\chi_k/N_k\), followed by Corollary 5.1C.  This is a
general smoothness/locality tradeoff, not a claim that current dPCP constructions
supply the required common proof or conditional smoothness.

See the [formal statement](../../mcsp-hardness-magnification/notes/321-adaptive-smoothness-to-lorenz-near-linear-gate-2026-08-18.md).

### Proposition 5.1B (exact hitting duality under realizable patching)

The Lorenz quantity is a summary of a more exact adaptive object. For honest randomness
\(\omega\), let \(S_{m,i}(\omega)\) be the set of distinct proof positions read by \(D_i\)
on \(\Pi(m)\). For a family \(\mathcal B_{m,i}\) of candidate corruption sets, define
\[
  \operatorname{Hit}_{m,i}(\mathcal B_{m,i})
  :=\max_{B\in\mathcal B_{m,i}}
    \Pr_\omega[S_{m,i}(\omega)\cap B\ne\varnothing].
\tag{5.7}
\]
The first-hit coupling gives soundness at most this value for every received word whose
error set lies in \(\mathcal B_{m,i}\). Conversely, suppose that each \(B\in\mathcal B_{m,i}\)
has a realizable patched proof \(z_{m,i,B}\), differing from \(\Pi(m)\) only on \(B\), and
that on every honest random tape whose first hit is in \(B\), the patched execution outputs
the wrong bit. Then every target-relative soundness guarantee is at least
\[
  \operatorname{Hit}_{m,i}(\mathcal B_{m,i}).
\tag{5.8}
\]
If this forcing condition holds for every \(m,i\) and every
\(|B|\le\rho N\), the decoder's worst-case soundness is exactly
\[
  \max_{m,i}\operatorname{Hit}_{m,i}
   \bigl(\{B\subseteq[N]:|B|\le\rho N\}\bigr).
\tag{5.9}
\]

#### Proof

Until the first query in the corruption set, the honest and patched executions have the
same transcript. This proves the upper bound. Under the forcing hypothesis, the patched
word has wrong-output probability at least its first-hit probability, proving (5.8);
maximizing over \(m,i,B\) gives (5.9). \(\square\)

For a one-query decoder, the hitting value equals the Lorenz mass in Theorem 5.1A; for
multi-query adaptive decoders it can be strictly smaller because query events overlap.
Thus a general impossibility proof must establish semantic realizability and first-hit
forcing for a rich patch family, while a positive construction must break one of those two
conditions. Ordinary list or average soundness does not supply either condition. The exact
duality and its fractional version are recorded in
[note 227](../../../mcsp-hardness-magnification/notes/227-exact-hitting-duality-for-shared-proof-robustness-2026-08-17.md).

### Corollary 5.1C (universal-patch utilization bound)

Let \(t=\lfloor\rho N\rfloor\) and

\[
  \bar q_{m,i}:=\mathbb E_\omega\lvert S_{m,i}(\omega)\rvert,
\tag{5.12}
\]

where \(S_{m,i}\) is the honest distinct-read set.  If every corruption set
\(B\subseteq[N]\) with \(\lvert B\rvert\le t\) is realizable and first-hit forcing
holds, then the worst-case soundness obeys

\[
  s^\star\ge
  \max_{m,i}\frac{t}{N}\frac{\bar q_{m,i}}{Q}.
\tag{5.13}
\]

To see this, choose \(B\) as the \(t\) positions with largest inclusion probabilities.
Its expected intersection with \(S_{m,i}\) is at least
\((t/N)\bar q_{m,i}\), while
\(\Pr[S_{m,i}\cap B\ne\varnothing]\ge
\mathbb E\lvert S_{m,i}\cap B\rvert/Q\).  Proposition 5.1B then gives (5.13).
In particular, full-use paths satisfy \(s^\star\ge t/N=\rho-o(1)\): a target error
strictly below the radius is impossible under universal first-hit patchability.  The
factor \(\bar q_{m,i}/Q\) is the exact correction when a decoder does not use its nominal
query budget on every honest path.

The current GMWZ RLDC stores an \(i\)-specific PCPP block of size \(K\) for each of the
\(k\) message coordinates, so \(M=\Theta(kK)\) and \(\lambda=\Omega(k)\). The field-lift
therefore needs \(\varepsilon=O(1/k)\) for a constant coordinate gap. GMWZ's dPCP theorem
states \(L=\operatorname{poly}(1/\varepsilon)\), while its alphabet and logarithmic length
exponent are allowed to depend on \(\varepsilon\). Substituting \(\varepsilon=1/k\) therefore
does not yield a uniform fixed-alphabet, fixed-exponent near-linear construction. This is a
parameter obstruction to the black-box route, not an impossibility theorem for globally smooth
outer codes.

The quantifier on smoothness is essential. Goldreich--Gur--Komargodski construct near-linear
constant-query RLDCs with **average** smoothness: after averaging over the message coordinate,
query number, and randomness, every codeword position has near-uniform query mass. This only
controls

\[
 \frac1k\sum_i\Pr[t\in Q_i],
\]

whereas (5.1) uses \(\max_i\Pr[t\in Q_i]\), because the RW interface must support every
coordinate with the same wrong-claim gap. Thus the existing average-smooth RLDC construction is
not a counterexample to Proposition 5.1, and Proposition 5.1 is not a general lower bound for
average-smooth RLDCs. The unresolved coding target is precisely a worst-case, globally smooth
shared proof together with target-relative coordinate robustness.

### Proposition 5.1D (heavy-core / punctured-RLDC dichotomy)

Let \(C:\{0,1\}^{k}\longrightarrow\Gamma^{M}\) be a code of relative distance at least
\(\Delta>0\). A common proof space \(V\) with alphabet \(\Sigma\) carries one
perfect-completeness assignment \(A_m\in\Sigma^V\) for each message \(m\). For every output
coordinate \(t\), let \(\mathcal P_t\) be a local-edge distribution and let \(D_t\) read at
most \(q_P\) proof symbols and satisfy
\[
 D_t(A_m|_e)=C(m)_t
 \qquad(e\sim\mathcal P_t)\text{ almost surely}.
\tag{5.14}
\]
Let \(\mathcal Q\) choose \(t\) uniformly and then \(e\sim\mathcal P_t\), and write
\[
 \mu_v:=\Pr_{(t,e)\sim\mathcal Q}[v\in e].
\tag{5.15}
\]
Assume an outer coordinate decoder makes at most \(q_D\) adaptive local calls, is exactly
safe when all local answers are honest, and satisfies
\[
 \Pr[v\in e\mid\text{preceding answers honest}]\le\lambda\mu_v
 \qquad(v\in V)
\tag{5.16}
\]
at every call. For a core \(K\subseteq V\), put
\[
 \kappa_K:=\mu(K),\qquad
 \tau_K:=\max_{v\in V\setminus K}\mu_v,
\]
and
\[
 \delta_K:=\min_{m\ne m'}
 \mu\!\left(\{v:A_m(v)\ne A_{m'}(v)\}\cap(V\setminus K)\right).
\tag{5.17}
\]
Then:

1. Every pair \(m\ne m'\) satisfies
   \[
   \mu(\{v:A_m(v)\ne A_{m'}(v)\})\ge\Delta.
   \tag{5.18}
   \]
2. If \(\mu(V\setminus K)<\Delta\), then \(m\mapsto A_m|_K\) is injective and
   \[
   |K|\ge k/\log_2|\Sigma|.
   \tag{5.19}
   \]
3. If \(\delta_K,\tau_K>0\), then the punctured proof map
   \(\bar A_m:=A_m|_{V\setminus K}\) has relative distance at least
   \[
   \Delta_K:=\frac{\delta_K}{\tau_K|V\setminus K|}.
   \tag{5.20}
   \]
   The decoder that aborts before using any local edge meeting \(K\) is a weak adaptive
   \((q_Pq_D,\varrho,c_K,s_K)\)-RLDC for \(C\) at every
   \[
   0<\varrho<\frac{\delta_K}{2\tau_K|V\setminus K|},
   \tag{5.21}
   \]
   with
   \[
   c_K\ge\max\{0,1-q_D\lambda\kappa_K\},
   \qquad
   s_K\le\min\{1,q_D\lambda\tau_K\varrho|V\setminus K|\}.
   \tag{5.22}
   \]

Thus a nonuniform incidence profile has only two quantitative exits: a message-scale heavy
core, or a punctured proof that still enters the RLDC barrier. Uniform marginals are the
special case \(K=\varnothing\).

#### Proof

Fix \(m\ne m'\), and let \(S=\{t:C(m)_t\ne C(m')_t\}\). Since \(|S|\ge\Delta M\),
every edge sampled for \(t\in S\) must meet
\(D_{m,m'}:=\{v:A_m(v)\ne A_{m'}(v)\}\); otherwise its local view would decode the same
symbol under both assignments. Hence
\[
 \Delta\le\Pr_{\mathcal Q}[e\cap D_{m,m'}\ne\varnothing]
 \le\mu(D_{m,m'}),
\]
which proves (5.18). If \(A_m|_K=A_{m'}|_K\), then
\(D_{m,m'}\subseteq V\setminus K\), contradicting
\(\mu(V\setminus K)<\Delta\). The restriction map is therefore injective, and
\(|\Sigma|^{|K|}\ge2^k\) gives (5.19).

For the punctured map, (5.17) and the definition of \(\tau_K\) imply
\[
 \delta_K\le\tau_K\,|D_{m,m'}\cap(V\setminus K)|,
\]
which proves (5.20). Let a received punctured proof differ from \(\bar A_m\) on a set
\(B\) of size at most \(\varrho|V\setminus K|\). The decoder aborts whenever the next
prescribed edge meets \(K\), and otherwise follows the outer decoder. By (5.16), the
probability of an abort on the honest proof is at most \(q_D\lambda\kappa_K\). Until the
first hit of \(B\), the corrupted and honest transcripts coincide; another use of (5.16)
gives
\[
 \Pr[\text{wrong output}]
 \le q_D\lambda\mu(B)
 \le q_D\lambda\tau_K\varrho|V\setminus K|.
\]
The radius condition (5.21) is half the punctured code distance, and the stated
completeness and soundness bounds follow. \(\square\)

The proposition is deliberately family-level: it does not turn a single RW history into
an RLDC. It does, however, remove “nonuniform marginals” as a free escape from the
shared-proof barrier. A proposed dPCP must either identify the message-scale core,
preserve enough outside distance and honest-path domination for the punctured branch, or
leave the common-proof/family model.
The profile-level derivation and its \(K_\theta=\{v:\mu_v>\theta\}\) specialization are
recorded in [note 223](../../../mcsp-hardness-magnification/notes/223-heavy-core-incidence-dichotomy-for-shared-proof-robustness-2026-08-17.md).

### Proposition 5.1G (descriptor--core entropy barrier)

Let \(C:\mathcal M\hookrightarrow\Sigma^N\) be a finite common proof map and let
\(\kappa:\mathcal M\to\mathcal D\) be a descriptor.  For every descriptor \(\sigma\),
coordinate \(i\), declaration \(b\), and finite-time policy \(\pi\), let
\(V_{\sigma,i,b,\pi}\) use the same physical proof address space \([N]\).  For every target
\(m\) and coordinate \(i\), choose one policy \(\pi_{m,i}\) for the correct declaration and
define its complete-policy core
\[
 K_m:=\bigcup_i\operatorname{Supp}
 \bigl(V_{\kappa(m),i,m_i,\pi_{m,i}}\bigr),
 \qquad R_m:=|K_m|.
\tag{5.1G.1}
\]
Assume that the selected policy accepts \(C(m)\) with probability at least \(\alpha\), while
every policy for a wrong declaration under the same descriptor accepts every
\(z\) with \(d_H(z,C(m))\le\rho N\) with probability at most \(\beta<\alpha\).  Then
\[
 m\longmapsto\bigl(\kappa(m),K_m,C(m)|_{K_m}\bigr)
\tag{5.1G.2}
\]
is injective.  Consequently, for a random target \(M\), \(D=\kappa(M)\), and
\(R=R_M\),
\[
 H(M)\le H(D)
 +N h_2\!\left(\frac{\mathbb E R}{N}\right)
 +\mathbb E R\log_2|\Sigma|.
\tag{5.1G.3}
\]
For a uniform \(2^k\)-target family and a descriptor with at most \(2^s\) values,
\[
 k-s\le
 N h_2\!\left(\frac{\mathbb E R}{N}\right)
 +\mathbb E R\log_2|\Sigma|.
\tag{5.1G.4}
\]
In particular, for fixed \(\Sigma\), \(N=k^{O(1)}\), and \(k-s=\Omega(k)\),
\[
 \mathbb E R=\Omega\!\left(\frac{k}{\log(k+2)}\right).
\tag{5.1G.5}
\]
If the descriptor \(D\) is randomized conditional on \(M\), with the selected cores and
policies written \(K_{m,d}\) and \(\pi_{m,i,d}\), the same argument replaces \(H(D)\) in
(5.1G.3) by \(I(M;D)\), provided the completeness and all-policy soundness hypotheses
hold on every positive-probability conditional support.

#### Proof

Suppose \(m\ne m'\) have the same descriptor and the same pair
\((K_m,C(m)|_{K_m})=(K_{m'},C(m')|_{K_{m'}})\).  Choose \(i\) with \(m_i\ne m'_i\).
The selected policy \(\pi_{m,i}\) only reads positions in \(K_m\), so its entire adaptive
transcript distribution is identical on \(C(m)\) and \(C(m')\).  It therefore accepts
\(C(m')\) with probability at least \(\alpha\).  Viewed under target \(m'\), the same policy
declares the wrong bit, while \(C(m')\) lies in its own target neighborhood; the
all-policy soundness hypothesis bounds this probability by \(\beta\), a contradiction.
This proves (5.1G.2).

The injective encoding gives
\[
 H(M)\le H(D)+H(K_M)+H(C(M)|_{K_M}\mid D,K_M).
\]
The last term is at most \(\mathbb E R\log_2|\Sigma|\).  A random subset of \([N]\) with
mean size \(\mathbb E R\) has entropy at most
\(N h_2(\mathbb E R/N)\), proving (5.1G.3); the randomized-descriptor version follows by
writing \(H(M)=I(M;D)+H(M|D)\) and applying the same injection on each conditional support.
Equation (5.1G.4) is immediate.  If \(\mathbb E R>N/2\), (5.1G.5) is trivial; otherwise
\(h_2(u/N)\le (u/N)\log_2(eN/u)\) and fixed-alphabet polynomial length give (5.1G.5).
\(\square\)

This is an information/descriptor theorem, not an RLDC theorem.  It closes a distinct
escape from Proposition 5.0E: a target-dependent policy channel may have large entropy without
forming a common target family, but then its complete-policy supports must collectively expose
message-scale information.  The theorem requires all-policy wrong-claim soundness within a
descriptor bucket; ordinary list soundness or \(\forall i\,\exists\pi_i\) semantics do not
supply that quantifier.

### Proposition 5.1E (fanout--RLDC tradeoff)

The preceding dichotomy has a sharper consequence for an address-preserving compiler.
Suppose that every message coordinate has \(S\) logical proof-symbol slots and that a
compiler uses a map

\[
  \phi:[k]\times[S]\longrightarrow V,
\tag{5.23}
\]

which is injective on the \(S\) slots for each fixed coordinate. Sample a coordinate and
one of its \(S\) slots uniformly, and write

\[
  d:=\max_{v\in V}|\phi^{-1}(v)|,
  \qquad \mu_v=\frac{|\phi^{-1}(v)|}{kS}.
\tag{5.24}
\]

Thus \(d\le k\), and the aggregate incidence profile satisfies
\(\tau:=\max_v\mu_v\le d/(kS)\). Assume the common-proof hypotheses of
Proposition 5.1D with \(K=\varnothing\), outer code distance \(\Delta>0\), and honest-path
domination parameter \(\lambda\), where the slot-uniform experiment above is the actual
complete-decoding distribution \(\mathcal Q\) in Proposition 5.1D. More generally, the
same proof uses the weighted fanout \(d_\mu:=kS\max_v\mu_v\) in place of \(d\). Put

\[
  \eta_0:=\frac14\min\!\left\{\Delta,\frac1{q_D\lambda}\right\},
  \qquad
  \rho_{\mathrm{fan}}:=\eta_0\frac{kS}{dP},
\tag{5.25}
\]

with the convention \(1/(q_D\lambda)=+\infty\) when \(q_D\lambda=0\). Then the
map \(m\mapsto A_m\) is a weak adaptive \(q_Pq_D\)-query RLDC of completeness one,
radius \(\rho_{\mathrm{fan}}\), and soundness at most \(1/4\). In particular,

\[
  P\ge \frac{kS}{d},
  \qquad
  \rho_{\mathrm{fan}}\ge \eta_0\frac{S}{P}.
\tag{5.26}
\]

For binary proof alphabets and fixed outer depth, the standard decision-tree flattening gives
a nonadaptive decoder with
\[
  Q_{\mathrm{fan}}=q_P\bigl(2^{q_D+1}-1\bigr)
\tag{5.27}
\]
queries (or \(q_Pq_D\) when the outer decoder is already nonadaptive).

#### Proof

Because every physical position has fanout at most \(d\), (5.24) gives
\(\tau\le d/(kS)\). Proposition 5.1D with \(K=\varnothing\) gives pairwise
disagreement mass at least \(\Delta\), hence proof relative distance at least
\(\Delta/(\tau P)\). The choice (5.25) satisfies
\(\rho_{\mathrm{fan}}<\Delta/(2\tau P)\), while its soundness bound is
\[
  q_D\lambda\tau\rho_{\mathrm{fan}}P
  \le q_D\lambda\eta_0\le\tfrac14.
\]
The empty core has no honest abort, so completeness is one. Finally
(1=\sum_v\mu_v\le P d/(kS)) proves the first inequality in (5.26), and
\(d\le k\) proves the second. The binary flattening is the usual finite decision-tree
union of all proof positions queried on the two-answer branches. \(\square\)

### Corollary 5.1F (GMWZ slot-preserving near-linear exclusion)

Consider a binary, slot-preserving GMWZ black-box compiler with
\[
  S_k=2k(\log k)^{C'},\qquad P_k\le k(\log k)^c,
\tag{5.28}
\]
for fixed constants \(C',c\), fixed positive outer distance \(\Delta\), and bounded
\(q_P,q_D,\lambda\). Assume that each coordinate keeps its \(S_k\) source slots
injective, while arbitrary sharing across coordinates is allowed. Then no such family can
exist for all sufficiently large \(k\) under the GMWZ black-box address semantics.

Indeed, if \(c<C'\), the counting inequality \(P_k\ge kS_k/d_k\ge S_k\) already
contradicts (5.28). Otherwise (5.26) gives
\[
  \rho_{\mathrm{fan}}
  \ge \frac{\eta_0}{(\log k)^{c-C'}},
\tag{5.29}
\]
up to the harmless factor \(2\). After (5.27), the query count \(Q_{\mathrm{fan}}\) is
constant, and (5.29) is larger than
\(P_k^{-\sigma/(2Q_{\mathrm{fan}})}\) for every fixed \(\sigma>0\) and all large \(k\). The
nonadaptive finite-alphabet GGS lower bound therefore yields
\[
  P_k\ge
  \left(\frac{\sigma^2 k}
  {38Q_{\mathrm{fan}}^4\log^2 4\,\log^2 k}\right)^{
  1+1/\lceil Q_{\mathrm{fan}}/\sigma\rceil},
\tag{5.30}
\]
which is polynomially superlinear and contradicts (5.28).

This is stronger than the raw private-slot count: high fanout is not by itself a viable
near-linear escape in the slot-uniform black-box interface. The corollary is deliberately
source-specific. It does not apply to
an algebraic aggregation that changes the logical slot semantics, to target-dependent
address maps, to growing alphabets, or to a construction that abandons the common-proof
family model. Its role is to close the remaining “share the private slots more
aggressively” branch before one invokes a genuinely new simultaneous synthesis theorem.

### Proposition 5.2 (global worst-case smoothness collapses zero-error relaxation)

The preceding unresolved target becomes a genuine barrier if ``smooth'' is required on every
oracle, rather than only on an uncorrupted codeword. Let

\[
  D^y(i)\in\{0,1,\bot\}
\]

be a (possibly adaptive) \(q\)-query decoder for a binary code
\(C:\{0,1\}^k\to\{0,1\}^M\). Assume that, for some constants \(c>0\) and \(\eta>0\),

1. on every codeword, \(\Pr[D^{C(x)}(i)=x_i]\ge c\);
2. on every codeword, \(\Pr[D^{C(x)}(i)\notin\{x_i,\bot\}]=0\); and
3. for every oracle \(y\), coordinate \(i\), and proof position \(t\),
   \[
     \Pr[t\in Q_i(y)]\le \frac{1}{\eta M}.
   \tag{5.4}
   \]

Then \(C\) is an ordinary LDC with \(O_c(q)\) queries and decoding radius
\[
  \delta' = \eta/(12Rq)>0,
\]
where \(R=O_c(1)\). In particular, a common-proof interface with
zero-error valid-codeword behavior cannot remain an RLDC-only construction once it also has
oracle-uniform worst-case smoothness.

#### Proof

Run \(R=O_c(1)\) independent copies of \(D^y(i)\). Output the common non-\(\bot\) bit when
all such bits agree, and output a fixed bit otherwise. On a codeword, no non-\(\bot\) output is
wrong, so the only failure event is that all \(R\) copies abort; this has probability at most
\((1-c)^R\). Let \(E=\{t:y_t\ne C(x)_t\}\). If a copy makes no query in \(E\), its complete adaptive
transcript is identical to its transcript on \(C(x)\), and hence it outputs either \(x_i\) or
\(\bot\). By (5.4) and a union bound, the probability that any of the \(R\) copies hits \(E\) is at
most
\[
  Rq\,|E|/(\eta M)\le Rq\delta'/\eta.
\]
Consequently the new decoder's error is at most
\((1-c)^R+Rq\delta'/\eta\). Choose \(R\) so that the first term is below (1/12), and restrict
to \(\delta'\le\eta/(12Rq)\). The resulting error is below (1/3\). \(\square\)

The oracle-uniform quantifier in (5.4) is deliberate. Smoothness stated only on valid codewords
does not control an adaptive query distribution after a corrupted answer changes the branch. For
non-adaptive decoders, codeword smoothness already implies (5.4), and the proposition reduces to
the standard smooth-decoder-to-LDC observation. Thus the genuinely stronger RW target is not
``smoothness'' by itself, but a globally smooth, adaptive, shared proof with enough robustness to
survive the corrupted-oracle quantifier.

There is a second, independent collapse route at the opposite end of the soundness scale. Cheng,
Li, and Mao prove that an arbitrary (possibly nonlinear) \(q\)-query RLDC with perfect
completeness and soundness \(s<2^{-q}\) already yields a comparable \(q\)-query LDC, and they
also give the imperfect-completeness non-adaptive analogue. Hence a proposed RW proof cannot evade
the LDC regime simultaneously by making soundness exponentially small and by relying on
relaxation; it must remain in the constant-soundness, non-globally-smooth window. This isolates
the only parameter window in which a new shared-proof construction could improve on known RLDC/LDC
separations.

### Proposition 5.3 (permutation products do not flatten private query peaks)

There is also a simple black-box obstruction to converting average smoothness into worst-case
smoothness by taking coordinate-permuted copies. Let a base decoder for a code of length \(M\) have,
on every valid codeword, query marginals \(p_{j,t}\) for message coordinate \(j\) and proof
position \(t\). Suppose there are distinct positions \(t_1,\ldots,t_k\) and a number \(h>0\) such
that
\[
  p_{j,t_j}\ge h \qquad (j\in[k]).
\tag{5.5}
\]
Form any \(B\)-block product code
\[
  C^{\mathcal P}(x)=C(\pi_1x)\Vert\cdots\Vert C(\pi_Bx)
\]
using arbitrary permutations \(\pi_1,\ldots,\pi_B\), and let its decoder choose a block
uniformly and decode coordinate \(\pi_b(i)\) in block \(b\). Then its worst-case query mass satisfies
\[
  \max_{i,(b,t)}\Pr[(b,t)\text{ is queried}\mid i]\ge \frac{h}{B},
  \qquad
  (BM)\max_{i,(b,t)}\Pr[(b,t)\text{ is queried}\mid i]\ge Mh .
\tag{5.6}
\]

#### Proof

Fix a block \(b\) and choose \(i=\pi_b^{-1}(j)\) for any \(j\). The product decoder chooses
that block with probability \(1/B\), and conditional on doing so its local marginal at
\(t_j\) is at least \(h\). This gives the first inequality; multiplying by the product length
\(BM\) gives the second. \(\square\)

The base decoder can nevertheless be average-smooth at the natural scale: if each private peak is
the only exceptional mass at its position, then
\(k^{-1}\sum_j p_{j,t_j}=h/k\). For a coordinate-private construction with \(M=\Theta(kK)\) and
\(h=\Theta(1/K)\), the average parameter is \(\Theta(1/M)\), while (5.6) leaves a worst-case
factor \(Mh=\Theta(k)\), independent of \(B\). Thus block replication and random coordinate
permutations cannot turn the GMWZ-style private PCPP layout into the globally smooth shared proof
required by RW. The proposition is deliberately a black-box statement: it does not rule out an
outer code whose query supports have no private peaks, which remains the substantive construction
target.

### Corollary 5.4 (three-query smoothness--length tradeoff)

The smoothness collapse has a quantitative consequence. Assume the decoder in Proposition 5.2 is
perfectly complete, makes three queries, and write
\[
  \lambda:=M\max_{i,t,y}\Pr[t\in Q_i(y)].
\tag{5.7}
\]
Then the same code is a three-query LDC at radius
\(\delta'=\Theta(1/\lambda)\) with constant decoding advantage. The near-cubic lower bound for
three-query LDCs therefore gives
\[
  M\;\ge\;\Omega\!\left(\frac{k^3}{\lambda^{16}\log^6 M}\right).
\tag{5.8}
\]

#### Proof

Perfect completeness makes the single-copy decoder sufficient in Proposition 5.2. On a word at
relative distance \(\delta'\), the probability that one of the three queries hits a corrupted
position is at most \(3\lambda\delta'\). Mapping \(\bot\) to a fixed bit gives an ordinary decoder
with error at most this quantity. Taking \(\delta'=1/(12\lambda)\) gives constant advantage.
Theorem 1 of Alrabiah--Guruswami--Kothari--Manohar states that a three-query LDC with decoding
advantage \(\varepsilon\) and radius \(\delta'\) satisfies
\(k^3\le M\,O(\log^6 M/(\varepsilon^{32}\delta'^{16}))\). Since \(\varepsilon\) is constant here,
(5.8) follows. \(\square\)

Thus a globally smooth shared proof with \(\lambda=\operatorname{polylog} k\) cannot have
near-linear length. The exponent 16 is inherited from the current three-query LDC theorem, not
claimed to be intrinsic. Improving (5.8), or proving an analogous tradeoff for larger query
complexity, is a concrete lower-bound target for the coordinate-robust PCP program.
Equivalently, any family with \(M\le k^{1+\varepsilon}\) must satisfy
\[
  \lambda\ge k^{(2-\varepsilon)/16-o(1)}.
\tag{5.9}
\]
In particular, genuinely near-linear length forces \(\lambda\ge k^{1/8-o(1)}\); a constant or
polylogarithmic worst-case smoothness parameter is impossible in this three-query window.

### Corollary 5.5 (two-query global smoothness is exponentially expensive)

The two-query case is sharper under the same oracle-uniform smoothness hypothesis. Let
\(C:\{0,1\}^k\to\{0,1\}^M\) have a perfectly complete, adaptive two-query relaxed decoder
with no wrong output on a valid codeword, and let \(\lambda\) be as in (5.7), with the maximum
taken over every oracle. Then

\[
 M\ge 2^{\Omega(k/\bar\lambda)},
 \qquad \bar\lambda:=\max\{1,\lambda\}.
\tag{5.10}
\]

In particular, \(\lambda=\operatorname{polylog} k\) is incompatible with near-linear length.

#### Proof

Perfect completeness makes the single-copy decoder in Proposition 5.2 an ordinary two-query
decoder. If \(y\) is at relative distance at most
\(\delta':=1/(16\bar\lambda)\) from \(C(x)\), the probability that either query hits an error is
at most \(2\lambda\delta'\le1/8\). The decoder therefore recovers each message bit with
probability at least \(7/8\), so it is a two-query LDC with constant advantage and radius
\(\Theta(1/\bar\lambda)\). The Kerenidis--de Wolf two-query lower bound, including its standard
adaptive-to-nonadaptive loss in the advantage, has exponent
\(\Omega(\delta'k)\) for this fixed advantage. Hence \(M\ge2^{\Omega(k/\bar\lambda)}\). \(\square\)

The quantifier is essential: (5.10) uses oracle-uniform smoothness to control an adaptive
decoder after corruption. Smoothness stated only on valid codewords gives this conclusion
directly only for nonadaptive decoders.

### Proposition 5.1H (policy-inclusive descriptor--core entropy barrier)

The descriptor--core argument can be strengthened so that it does not require soundness for
every policy in a descriptor bucket. Let
\[
 C:\mathcal M\hookrightarrow\Sigma^N
\]
be a common proof map. For each target \(m\) and coordinate \(i\), choose a policy
\(\pi_{m,i}\), write \(D_m=\kappa(m)\), \(S(m)=(\pi_{m,1},\ldots,\pi_{m,k})\), and let
\[
 K_m:=\bigcup_i\operatorname{Supp}
 \bigl(V_{D_m,i,m_i,\pi_{m,i}}\bigr).
\tag{5.1H.1}
\]
Assume the selected policy accepts \(C(m)\) with probability at least \(\alpha\), while
for every \(z\) with \(d_H(z,C(m))\le\rho N\),
\[
 \Pr[V_{D_m,i,1-m_i,\pi_{m,i}}(z)=1]\le\beta<\alpha .
\tag{5.1H.2}
\]
Then
\[
 m\longmapsto\bigl(D_m,S(m),K_m,C(m)|_{K_m}\bigr)
\tag{5.1H.3}
\]
is injective. Consequently, for a random target \(M\), with \(D=D_M\), \(S=S(M)\), and
\(R=|K_M|\),
\[
 H(M)\le H(D,S)
 +N h_2\!\left(\frac{\mathbb E R}{N}\right)
 +\mathbb E R\log_2|\Sigma|.
\tag{5.1H.4}
\]
For a uniform \(2^k\)-target family, \(H(D,S)\le s\), fixed \(\Sigma\), and
\(N=k^{O(1)}\), the condition \(k-s=\Omega(k)\) therefore implies
\[
 \mathbb E R=\Omega\!\left(\frac{k}{\log(k+2)}\right).
\tag{5.1H.5}
\]
Thus a policy vector, even when it is target-dependent and unbounded as an object, cannot
simultaneously carry little information and expose a sublinear complete-policy core.

#### Proof

If two distinct targets \(m,m'\) have the same \(D,S,K\), and the same restriction of their
proofs to \(K\), choose \(i\) with \(m_i\ne m'_i\). The policy
\(V_{D_m,i,m_i,\pi_{m,i}}\) reads only \(K_m\), so its full transcript distribution on
\(C(m')\) is identical to that on \(C(m)\); it therefore accepts \(C(m')\) with probability
at least \(\alpha\). Since \(S(m)=S(m')\), this is exactly the selected wrong policy for
target \(m'\), whose acceptance on its own proof is bounded by \(\beta\) by (5.12), a
contradiction. The entropy inequality follows from the injective encoding and the same
subset/content entropy bounds as in Proposition 5.1G. \(\square\)

This proposition is the no-resampling counterpart of the RLDC lift: it permits selected-policy
soundness only, but charges the entire policy vector through \(H(D,S)\). In particular, the
all-policy quantifier in Proposition 5.1G is needed only when one refuses to charge policy
identity as part of the target descriptor.

### Theorem 5.1I (uniformization--Lorenz query-peak trichotomy)

The connected-neighborhood bridge and the pathwise Lorenz closure combine into one
source-independent trichotomy.  Fix \(0<\rho<1\) and \(c\ge0\), and let

\[
  \Pi_k:\{0,1\}^k\longrightarrow\Sigma_k^{N_k},
  \qquad N_k\le k(\log(k+2))^c,
\tag{5.1I.1}
\]

be a common proof map with adaptive decoders of depth at most \(r_k\).  Let
\(\mathcal Z_k\) be a Hamming-connected family of target-relative near proofs on which
Proposition 5.0K's transcript setup holds.  Write

\[
  \alpha_k:=\varepsilon_k+\sqrt{\frac{\ln2}{2}\,\iota_k},
  \qquad
  \delta_k:=\Delta_{\lambda_k}(\mathcal Y_k)-2\alpha_k>0.
\tag{5.1I.2}
\]

For \(z\in\mathcal Z_k\) and proof position \(p\), let \(h_k^{\mathrm{nbhd}}\) be the
largest probability that the common decoder queries \(p\) on \(z\), and let
\(h_k^{\mathrm{hon}}\) be the corresponding maximum over honest states
\(\Pi_k(m)\).  Put \(h_k=\max\{h_k^{\mathrm{nbhd}},h_k^{\mathrm{hon}}\}\).  Assume that
the common word produced by Proposition 5.0K, when it exists, is target-bound to the
same proof map, and that the honest-path error is at most \(\epsilon_k\).  Finally assume
the source-audited variable-query closure

\[
  \epsilon_k+\Lambda_{\rho,k}\le\frac1{12}
  \quad\Longrightarrow\quad
  r_k\log(r_k+2)\ge\eta(\rho,c)(\log(k+2))^{1/3}.
\tag{5.1I.3}
\]

Then, for all sufficiently large \(k\), at least one of the following holds, unless a
transcript, separation, or target-binding hypothesis above fails:

\[
\begin{array}{ll}
\mathrm{(P)} & h_k\ge\delta_k,\\[1mm]
\mathrm{(L)} & \epsilon_k+\rho N_k r_k h_k>\dfrac1{12},\\[1mm]
\mathrm{(Q)} & r_k\log(r_k+2)\ge\eta(\rho,c)(\log(k+2))^{1/3}.
\end{array}
\tag{5.1I.4}
\]

#### Proof

If (P) fails, Proposition 5.0K gives one common valid word on \(\mathcal Z_k\), and
the target-binding hypothesis identifies it with the common proof map.  For an honest
message and coordinate, let \(\nu(v)\) be the expected number of reads of proof position
\(v\).  By the definition of \(h_k\) and the depth bound,

\[
  \nu(v)\le r_kh_k,
  \qquad
  \Lambda_{\rho,k}\le\rho N_kr_kh_k.
\tag{5.1I.5}
\]

If (L) also fails, (5.1I.5) gives
\(\epsilon_k+\Lambda_{\rho,k}\le1/12\), so (5.1I.3) yields (Q).  Thus if both (P)
and (Q) fail, (L) must hold. \(\square\)

Two useful specializations are immediate.  If \(\mathcal Y_k=\operatorname{Im}(\Pi_k)\),
target binding is automatic; injectivity is not needed for the trichotomy.  If the
first-hit patchability condition holds with forcing constant \(\gamma_k\) and target-error
bound \(\beta_k<\gamma_k\delta_k\), the no-common-word branch (P) is impossible.  Moreover,
if \(\Pi_k\) is injective and

\[
  \frac{\rho\delta_k k}{\log_2|\Sigma_k|}>\frac1{12},
\tag{5.1I.6}
\]

then (P) itself implies (L), by \(N_k\ge k/\log_2|\Sigma_k|\).  In this coding-scale
regime, no first-hit assumption is needed for the length/locality conclusion: the only
remaining alternatives are failure of the transcript/separation hypotheses, (L), or (Q).

The theorem is conditional on the common-address, target-relative transcript interface;
ordinary average/list soundness does not provide its mutual-information, connectivity, or
target-binding hypotheses.  Its role is to turn the remaining distributional escape into a
single quantitative experiment rather than another unstructured model exit.  The full
source boundaries and the smoothness-to-connectivity derivation are recorded in
[the uniformization--Lorenz note](../../../mcsp-hardness-magnification/notes/334-uniformization-lorenz-query-peak-trichotomy-2026-08-18.md).

## 6. Implications for hidden-witness relation-PCPPs

The theorem applies even when the proof map is nonlinear and the verifier hides a witness.
If a relation-PCPP has one proof map, one physical address space, fixed locality, a fixed
positive target-relative radius, and a fixed completeness/soundness gap for a high-entropy
payload, then its proof itself is a relaxed code. A near-linear construction must therefore
change at least one of: radius, gap, alphabet/query uniformity, common address space, bounded
strategy support, or target-relative family quantifiers.

This does not rule out a new relation-PCPP. It identifies the exact semantic feature such a
construction must exploit and gives a direct test for proposed RW/JK interfaces.

### Theorem 6.1 (RW hard-table scale trichotomy)

Consider a Ren--Williams stage with output table \(B_i\in\{0,1\}^{N_i}\),
\(N_i=2n_i\), address length \(m_i=\lceil\log_2N_i\rceil\), and forcing scale
\(\operatorname{CC}(B_i)>S_i\). Assume the failure branch has one common PCP proof and,
for every output address \(j\), a final public-coin query with perfect-completeness versus
soundness gap \(1\) versus \(1/2\). Suppose a finite common-response implementation uses a
fan-in-two control circuit of size \(p_i\), a shared descriptor of length \(d_i\), and at most
\(b_i\) descriptor reads per execution. In the straight-line ROM model,

\[
 \operatorname{CC}(B_i)
 \le O\!\left(m_i(p_i+b_i d_i+m_i)\right).
\tag{6.1}
\]

Consequently, whenever \(p_i+m_i=o(S_i/m_i)\),

\[
 d_i=\Omega\!\left(\frac{S_i}{m_i b_i}\right).
\tag{6.2}
\]

The RW hard-table theorem supplies infinitely many hard output lengths, but it does not
need to be supplemented by an assumption that infinitely many of them are stable. On a
length \(n_i\) in the truth-table-generator family, if the advice selects the solver branch
at an early index \(i<i^\star\), the definition of \(A_0\) outputs the all-zero table
\(0^{N_i}\). This table is in \(\operatorname{Range}(G_{n_i})\), so such a length cannot
be one of the hard AVOID lengths. Hence every hard solver-branch length is automatically
in the stable tail. Under \(P=NP\), that stable solver branch becomes an object-scale
polynomial-time generator, but this is compatible with the near-maximum lower bound
 \(\Omega(N_i/\operatorname{polylog}N_i)\): a polynomial in \(N_i\) need not be smaller
than a linear lower bound. Thus the theorem gives a trichotomy:

* a stable solver branch with an \(N_i^{O(1)}\) evaluator;
* a failure/reconstruction branch that pays
\[
 p_i+b_i d_i=\Omega\!\left(\frac{N_i}{\operatorname{polylog}N_i}\right),
\tag{6.3}
\]
in the straight-line ROM model; or
* an escape from the finite common-response/common-address model altogether.

Only an additional \(m_i^{O(1)}\) address-scale evaluator for the stable branch (or a
forcing lower bound superpolynomial in \(N_i\)) would turn the first item into a
\(P/\mathrm{poly}\) contradiction. The corrected scale statement is recorded in
[note 357](../../../mcsp-hardness-magnification/notes/357-rw-hard-table-object-scale-correction-2026-08-18.md).

#### Proof

Apply Proposition 5.0C with \(\alpha=1\), \(\beta=1/2\), and \(\delta=1/3\). A single
multiset of \(O(m_i)\) public tapes simultaneously separates all \(N_i\) final-query
acceptance rates. Hardwire those tapes and the shared descriptor. Expanding each descriptor
read by a standard multiplexer gives (6.1), and combining it with
\(\operatorname{CC}(B_i)>S_i\) yields (6.2). For the RW hard lengths, an early solver
branch is excluded because it outputs the all-zero table, which is in the
truth-table-generator range; every remaining solver-branch length is stable. Under
\(P=NP\), the stable solver branch is polynomial in \(N_i\), which does **not** contradict
the \(\Omega(N_i/\operatorname{polylog}N_i)\) bound. If a hard length is known to use the
reconstruction branch, the ROM calculation yields (6.3); otherwise the stable object-scale
branch remains a genuine alternative.
\(\square\)

This is a source-specific closure theorem, not an unconditional \(P\ne NP\) proof. It
reduces the remaining top-level target to a general theorem against the non-finite,
address-dependent, or new-global-coupling escape; it does not treat that residual class as
already impossible.

### Proposition 6.2 (the mixture closure has a family-entropy gate in RW)

Proposition 5.0D is a family theorem. It cannot be instantiated at a Ren--Williams stage
merely by replacing the constant function \(f_i\) by a function of its input. Let

\[
  k_i=n_{i+1}=n_i^C,
  \qquad
  T_i=\max\{2^{cD^i n_0},n_{i+1}\},
\]

and suppose that each input \(x\in\{0,1\}^{\nu_i}\) contributes one selected
canonical/actual history \(\Pi_{i,x}\) of length at most \(T_i^a\), for a fixed constant
\(a\). Even granting all \(2^{\nu_i}\) inputs distinct policy laws, the available target
entropy is at most \(\nu_i\) bits. To obtain the \(\Theta(k_i)\)-bit shattered submessage
required by Proposition 5.0D, one needs a family of size \(2^{\Omega(k_i)}\) (or an
equivalent new source of target entropy). In the current RW recurrence, taking even the
generous \(\nu_i=n_i\) gives

\[
  \nu_i+a\log_2 T_i
  \le O\!\left(n_i+D^i n_0+C^{i+1}\log n_0\right)
  =o\!\left(k_i\right).
\tag{6.4}
\]

Thus all selected histories supplied by input variation form only a
\(2^{o(k_i)}\)-sized family. The original construction is strictly weaker: it evaluates a
single fixed \(x_0\), so its family size is one and its mixture closure is vacuous.

The same deficit appears in the JK capacity count. Here an ``aligned depth-\(h\) window''
means one of the disjoint dyadic groups in the canonical JK partition: its first
\(2q_i\)-bit block is at a depth-\(h\) group boundary, and distinct groups do not
overlap. If \(\mathcal T_{i,h}\) denotes these actual JK groups across all selected
histories, then

\[
  |\mathcal T_{i,h}|
  \le \frac{2^{\nu_i}T_i^a}{2k_i2^h}
  =2^{o(k_i)}.
\tag{6.5}
\]

Allowing every sliding block window can only remove the factor \(2^h\); the weaker
bound \(|\mathcal T_{i,h}|\le 2^{\nu_i}T_i^a/(2k_i)\) is still \(2^{o(k_i)}\) and
gives the same asymptotic obstruction. The dyadic convention is the one used when
counting the groups that feed the JK capacity forcing.

Consequently it cannot reach the \(>2^{k_i}\) tuples needed for a root-range capacity
forcing. Reaching that threshold by length alone would require
\(T_i\ge 2^{(k_i-\nu_i)/a}\) up to polynomial factors, which makes the
\(\operatorname{Solve}_{f_i}\) call exponential in the child width. Therefore the mutual-
information closure and the JK tree-capacity closure meet only after one supplies a new
high-entropy common-proof family, a succinct tuple oracle, or an address-scale global
policy sampler. None is supplied by the present RW Theorem 4.1/4.3 quantifiers.

This is a parameter boundary, not an impossibility theorem: a future construction may add
the missing family or compressed sampler. It does show that “use all RW inputs” is not a
closure theorem, and that Proposition 5.0D cannot by itself turn the existing single-target
RW history into an RLDC contradiction.

### Theorem 6.3 (RW family--strategy trilemma)

The two remaining ways to manufacture the high-entropy family needed by a JK/RLDC
closure can be separated quantitatively. Write

\[
 q_i=n_{i+1}=n_i^C,\qquad
 T_i=\max\{2^{cD^i n_0},n_{i+1}\},\qquad C>D+1.
\tag{6.7}
\]

Suppose one selected history per input has length at most \(T_i^a\), with input
length \(\nu_i\le n_i\). Assume a proposed common-proof closure has payload dimension
\(K_i=\Theta(q_i)\), fixed finite proof alphabet/locality/radius parameters, and an
RLDC lower-bound window excluding

\[
 P_i\le K_i(\log(K_i+2))^b.
\tag{6.8}
\]

Then every sufficiently large stable-stage attempt pays one of three costs:

1. If JK forcing uses only actual disjoint dyadic aligned depth-\(h\) groups from the
   selected histories,
   then
   \[
   \nu_i+a\log_2T_i\ge q_i+\log_2(2q_i)+h
   \tag{6.9}
   \]
   is necessary for the \(>2^{q_i}\) tree-capacity threshold. The RW recurrence has
   \(\nu_i+a\log T_i=o(q_i)\), so the existing input/history channel cannot reach this
   threshold. Making it reach the threshold by length alone requires
   \(T_i\ge2^{(q_i-\nu_i-O(\log q_i+h))/a}\), outside the polynomial-time Solve
   regime.

2. If instead the attempt supplies one common proof map and a target-dependent global
   package \(S_i\) over all coordinates and claims, let \(\bar\delta_i\) be its
   max-before-average robust defect and \(I_i=I(M_i;S_i)\). For fixed
   \(0<\eta<1/2\) and a fixed margin \(0<\Delta<(\alpha-\beta)/2\), there are constants
   \(\varepsilon_\delta=\eta\Delta/2>0\) and \(\varepsilon_I>0\) (one may take any
   \(\varepsilon_I<(1-\eta)/8\), after increasing the stage) such that
   \[
   \bar\delta_i\ge\varepsilon_\delta
   \qquad\text{or}\qquad
   I_i\ge\varepsilon_I K_i.
   \tag{6.10}
   \]
   Otherwise Proposition 5.0I gives a fixed package on a fiber of exponent
   \[
   K_i+\log_2p_i-
   \frac{I_i/p_i+h_2(\eta)}{1-\eta}
   \ge \frac34K_i-O_\eta(1),
   \qquad p_i\ge\frac12,
   \tag{6.11}
   \]
   and Sauer--Shelah plus inline decoding gives the forbidden RLDC in (6.8).

3. If neither payment is made, the construction must leave at least one hypothesis:
   common proof/address space, fixed alphabet/locality coding window, the global
   max-before-average package quantifier, or near-linear proof length.

This is a source-specific RW attachment theorem. It does not assert that the original
RW theorem supplies the global package in item 2, and it does not claim an unconditional
dPCP or \(P\ne NP\) result. Its value is that “use all RW inputs” and “hide the missing
family in target-dependent policies” are no longer independent escape routes: the first
is subcapacity by (6.9), while the second pays a constant robust defect or linear target
information.

The proof is the combination of the actual-window estimate in Proposition 6.2 with the
explicit entropy calculation in Proposition 5.0I; a self-contained derivation is recorded
in [note 278](../../../mcsp-hardness-magnification/notes/278-rw-family-strategy-trilemma-2026-08-20.md).

### Theorem 6.4 (RW Closure-Gate master trichotomy)

The preceding modules can be stated as one closure theorem. At a stable RW stage,
write \(q_i=n_{i+1}=n_i^C\), \(T_i=\max\{2^{cD^i n_0},n_{i+1}\}\), and let one selected
history per input have length at most \(T_i^a\), with input length \(\nu_i\le n_i\).
Consider an attachment with payload dimension \(K_i=\Theta(q_i)\), proof length \(P_i\),
and \(N_i=K_i+P_i\le K_i(\log(K_i+2))^c\) on infinitely many stages. Assume the
applicable family-level RLDC lower-bound window excludes this near-linear length.
Then every sufficiently large such stage falls into at least one of the following four cases.

1. **JK supply:** if the construction uses actual disjoint dyadic aligned depth-\(h\)
   history groups to cross the JK tree-capacity threshold, then
   \[
   \nu_i+a\log_2T_i\ge q_i+\log_2(2q_i)+h .
   \tag{6.12}
   \]
   Since \(\nu_i+a\log T_i=o(q_i)\), the existing RW input/history channel cannot pay
   this cost. Paying it by history length alone requires
   \(T_i\ge2^{(q_i-\nu_i-O(\log q_i+h))/a}\), outside the polynomial-in-\(T_i\)
   Solve regime.

2. **Global package or response channel:** if the construction instead supplies one
   common proof/address space and a target-dependent package \(S_i\) containing all
   coordinate/claim policies,
   with the max-before-average robust defect \(\bar\delta_i\), target mutual information
   \(I_i=I(M_i;S_i)\), and a fixed positive correctness gap, then the package must pay
   \[
   \bar\delta_i\ge\varepsilon_\delta
   \quad\text{or}\quad
   I_i\ge\varepsilon_IK_i
   \tag{6.13}
   \]
   for fixed constants \(\varepsilon_\delta,\varepsilon_I>0\).
   If the package instead keeps an explicit jointly distributed response word
   \(Z_i=(Z_{i,1},\ldots,Z_{i,L_i})\) for a target family
   \(Y_i:\mathcal M_i\hookrightarrow\Gamma^{L_i}\) of minimum distance greater than
   \(2t_i\), and succeeds with probability
   \[
     p_i=\Pr[d_H(Z_i,Y_i(M_i))\le t_i],
   \]
   then Theorem 2.4 gives the sharper residual accounting
   \[
   I(M_i;S_i)+\sum_{j=1}^{L_i}I(M_i;Z_{i,j}\mid S_i)
   +\mathbb E\!\left[\operatorname{TC}_2(Z_i\mid M_i,S_i)\right]
   \ge p_i\log_2|\mathcal M_i|-1.
   \tag{6.13a}
   \]
   Thus a package with sublinear policy information and sublinear coordinatewise
   target information must pay linear target-conditioned joint correlation.  Under
   conditional independence of the response coordinates given \((M_i,S_i)\), this
   residual term is zero, so the joint-relation escape is unavailable.
   If no such explicit joint response word is retained, Proposition 5.0I gives a
   linear-exponent fixed-package fiber and the forbidden near-linear RLDC.

3. **Finite-alphabet branch:** if the family-level common proof has positive target-relative
   radius, independently resamplable branches, alphabet size \(A_i\), locality \(r_i\), and
   gap \(\gamma_i=\alpha_i-\beta_i>0\), put
   \[
   R_i=\Theta(r_i/\gamma_i^2),\qquad
   Q_i=1+2\sum_{j<R_i}A_i^j,\qquad
   \Lambda_i=1+\log\log(K_i+2)+\log\log(A_i+2).
   \]
   If \(\log A_i\ge K_i/2\), the alphabet itself is a message-scale channel. Otherwise,
   the source-safe joint alphabet--locality envelope forces
   \[
   Q_i\Lambda_i=\Omega(\log K_i).
   \tag{6.14}
   \]
   For binary fixed-gap branches, this is the \(\log\log K_i\) locality threshold.
   If correct-claim completeness is imperfect but the stronger full-ROC package is
   available, Corollary 6.8C' gives the corresponding replacement: for any fixed-distance
   binary inner code, either the expanded length
   \(\widehat N_i=d_i+\ell_iP_i\) leaves the near-linear window, or
   \[
     (1+\ell_ir_i)\log(3+\ell_ir_i)
       =\Omega((\log K_i)^{1/3}).
   \tag{6.14a}
   \]
   This is an additional conditional branch, not an upgrade of ordinary average/list
   soundness.
   If the package verifiers are nonadaptive in their proof-symbol queries,
   Corollary 6.8C'' sharpens this to
   \[
     1+\ell_i r_i=\Omega(\log K_i/\log\log K_i).
   \]
   Without any fixed-distance binary inner-code hypothesis, Corollary 6.8E
   gives a direct q-ary replacement: for imperfect full-ROC completeness
   \(c_i>s_i\), either \(\log(A_i+2)\ge d_i/2\), or
   \[
     Q_i\!\left(\log\log(d_i+2)+\log(Q_i+2)
       +\log(\log(A_i+2)+2)\right)=\Omega(\log d_i).
   \]
   Corollary 6.8G combines this with the distributional package defect/information
   term, so target-dependent laws must pay robust defect/information, alphabet,
   or q-ary locality.

   There is also a tail-sensitive subcase that does not require paying for the largest
   possible decision tree.  In the perfect-completeness branch, let
   \(U_{i,j}(\omega)\) be the union of proof positions exposed by both claim branches
   for coordinate \(j\) on random tape \(\omega\), and put
   \[
     \tau_i(T):=\max_j\Pr_\omega\!\left[\,|U_{i,j}(\omega)|>T\,\right],
     \qquad \sigma_i:=1-\beta_i.
   \]
   If the supports are uniformly exposable and independently resamplable, then for
   every \(0<\gamma<\sigma_i\) with
   \(\tau_i(T)\le\sigma_i-\gamma\), Lemma 4.0A supplies the replacement
   \[
     Q_i^{\rm tail}\le 1+O(T/\gamma^2).
   \]
   Consequently, on any near-linear family for which the GGS radius window is valid,
   the quantile
   \[
     T_{\gamma,i}:=\inf\{T:\tau_i(T)\le\sigma_i-\gamma\}
   \]
   must satisfy
   \[
     T_{\gamma,i}=\Omega_{\rho,\gamma,A,c}\!\left(
       \gamma^2\frac{\log K_i}{\log\log K_i}\right).
   \]
   This is a tail-support payment, not an average-query statement; ordinary
   average/list soundness does not supply the common-support hypothesis.

4. **Model exit:** if none of (1)--(3) is paid, then a stated hypothesis has been
   abandoned: common proof/address space, word-consistent global package, positive
   radius or gap, finite alphabet/locality window, message-scale alphabet, or target-relative all-policy
   semantics. This is a model change, not a fourth free escape.

The proof is a case split over Proposition 6.2, Proposition 5.0I, Theorem 2.4 for
the residual joint-response accounting, Theorem 4.1 (including its joint
alphabet--gap--locality form), and Lemma 4.0A for the tail-sensitive subcase.
Thus Theorem 6.4 is a closure gate,
not an unconditional \(P\ne NP\) theorem: the remaining top-level problem is to build a
new global coupling outside these three quantitative payments, or prove that such a model
exit is itself impossible.

The self-contained parameter statement and all hypothesis boundaries are recorded in
[note 279](../../../mcsp-hardness-magnification/notes/279-rw-closure-gate-master-trichotomy-2026-08-17.md).

### Theorem 6.4A (semantic-first RW Closure Gate)

The quantitative trichotomy has a logically prior semantic gate. Let a proposed
physicalization \(\Phi\) map a physical proof word to the visible transcript space used by
the RW smart-prMA queries, and fix a target-relative radius \(\rho\) and parameters
\(\alpha>\beta\).

1. If \(\Phi\) is not promise-preserving on every \(\rho\)-near physical proof, then the RW
   theorem cannot imply target-relative ACRR/RLDC soundness. An off-promise completion can
   agree with every canonical-history query while accepting a wrong near branch. This is a
   semantic model change, not a free instance of Theorem 6.4.
2. Suppose \(\Phi\) is promise-preserving and induces one fixed finite visible transcript law
   at each parameter value. For
   every coordinate/claim \((i,b)\), let \(\operatorname{ROC}_{i,b}(\alpha,\rho)\) be the
   transcript-only robust wrong-claim optimum in (4.7C). If
   \(\operatorname{ROC}_{i,b}(\alpha,\rho)>\beta\) for some \((i,b)\), finite minimax gives
   one mixture of target-relative near proofs defeating every transcript-only postprocessor
   with honest completeness \(\alpha\). If it is at most \(\beta\) for all \((i,b)\), and
   the attachment additionally has a common target family, positive radius, and all-policy
   semantics, then the same proof/address space is a relaxed-LDC interface and Theorem 6.4
   applies. Without those family hypotheses, the low-ROC branch is only a transcript filter,
   not an RLDC.

Consequently, any RW-to-ACRR closure must first supply promise-preserving physicalization and
then either pay the high-ROC minimax obstruction or enter one of the quantitative payments in
Theorem 6.4. This theorem is conditional on the advertised interface; it is neither a general
dPCP impossibility theorem nor a \(P\ne NP\) theorem.

#### Proof

For item 1, keep all canonical-history transcript answers fixed and modify only the completion
on an admissible near proof outside the RW promise. The smart-prMA hypotheses are unchanged,
but the physical wrong-claim event changes, so no target-relative corruption statement follows.
For item 2, Theorem 4.2A' identifies the optimal transcript-only error with
\(\operatorname{ROC}_{i,b}(\alpha,\rho)\); in the high branch its finite-dimensional minimax
dual supplies the stated mixture. In the low branch, querying the common transcript support
and the inline claim gives a common-proof relaxed decoder. Theorem 6.4 then charges its
history, package, alphabet, locality, gap, or model-exit cost. \(\square\)

### Theorem 6.5 (selected-policy information is the only finite-policy escape)

There is a quantitative version of the model-exit clause for target-dependent
coordinate policies. Let
\(\Pi:\{0,1\}^{K}\to\Sigma^{P}\) be a common proof map. For every target \(m\) and
coordinate \(j\), choose one policy \(\tau_{m,j}\), and let
\[
S(m):=(\tau_{m,1},\ldots,\tau_{m,K}),\qquad h_S:=H_2(S(M)),
\]
where \(M\) is uniform. Suppose each selected policy has correct-branch acceptance
at least \(\alpha\) on \(\Pi(m)\), and its opposite-claim branch has acceptance at most
\(\beta<\alpha\) on every \(\rho P\)-near word. If \(h_S\le\gamma K\) for a fixed
\(\gamma<1\), then a fiber of the policy vector has VC dimension
\(d\ge\theta_\gamma K-o(K)\), where \(H_2(\theta_\gamma)=1-\gamma\). On that
fiber the selected policy at each shattered coordinate is common, so message inlining
gives an RLDC on \(d\) message bits with locality
\[
O\!\left(q(\alpha-\beta)^{-2}\right)
\]
for nonadaptive \(q\)-query branches (and the corresponding decision-tree or
variable-query parameter for adaptive branches).

Consequently, in any RLDC lower-bound window that excludes near-linear proof length,
every selected-policy construction preserving the displayed radius and gap must satisfy
\[
H_2(S(M))\ge K-o(K).
\tag{6.15}
\]
The same conclusion holds with \(H_2(S(M))\) replaced by \(I(M;S)\) for a finite
supportwise-randomized policy view.

This closes the finite selected-policy interpretation of the model exit. The
constant-proof hardcoding example is not a counterexample: its policy vector carries
the entire target, so it satisfies (6.15). What remains outside the theorem is
precisely a policy view whose supportwise robustness or common proof/address semantics
fails; ordinary average/list soundness does not supply the missing hypothesis.

The proof is the fiber/VC argument of Proposition 5.0E: a policy fiber of entropy
at most \(\gamma K\) has size at least \(2^{K-\gamma K}\), Sauer--Shelah yields the
shattered set, and the common policy on that fiber gives the RLDC. The adaptive
extension uses the same amplification as Theorem 4.1.

### Theorem 6.6 (standard-Borel policy closure)

The finite-support qualification in Theorem 6.5 is not essential. Let the policy
object \(S\) take values in an arbitrary standard Borel space, possibly encoding
an unbounded strategy or a target-dependent address schedule. Assume that for almost
every policy value \(s\), every target in the posterior support
\[
\{m:\Pr[M=m\mid S=s]>0\}
\]
has the same common proof map and satisfies the selected-policy robustness inequalities
of Theorem 6.5 for the policy vector \(\tau_s\). Then, for every
\(\varepsilon>0\), some such \(s\) has posterior support size
\[
\left|\{m:\Pr[M=m\mid S=s]>0\}\right|
\ge 2^{K-I(M;S)-\varepsilon}.
\tag{6.16}
\]
Consequently \(I(M;S)\le\gamma K\) gives a
\((\theta_\gamma-o(1))K\)-coordinate shattered fiber and the same RLDC lower bound.
Thus any near-linear construction in the applicable coding window must pay
\[
I(M;S)\ge K-o(K),
\tag{6.17}
\]
unless supportwise robustness or the common proof/address semantics fails.

The proof is the conditional-entropy identity
\(H(M\mid S)=K-I(M;S)\), followed by choosing a policy value whose posterior
entropy is within \(\varepsilon\) of the essential supremum and using
\(H(M\mid S=s)\le\log|\operatorname{supp}(M\mid S=s)|\). No finite description
or computability of the selected policy is needed for the existential coding
lower bound. A complete statement and the measure-theoretic boundary are in
[note 281](../../../mcsp-hardness-magnification/notes/281-standard-borel-selected-policy-information-closure-2026-08-17.md).

### Theorem 6.7 (distributional global-word Closure Gate)

The distributional escape can now be stated as one policy-level trichotomy. Let
\(Y:\mathcal M\to\Gamma^P\) have minimum distance \(d>2t\), write
\(\mathcal Y=Y(\mathcal M)\), let \(M\) be uniform, and let a proposed full-word
package generate \(Z\) from a standard-Borel policy
\(S\) and fresh randomness with \(M\to S\to Z\). If
\[
 p=\Pr[d_H(Z,Y(M))\le t],
\]
then
\[
 I_2(M;S)\ge
 \log_2|\mathcal M|-h_2(1-p)-(1-p)\log_2(|\mathcal M|-1)
 \ge p\log_2|\mathcal M|-1.
\tag{6.18}
\]
If, in addition, the coordinates of \(Z\) are independent conditioned on \(S=s\)
outside a policy mass \(\delta\), and their conditional min-entropy sum is at least
\(H\), then
\[
 p\le\delta+(1-\delta)|\mathcal Y|
 V_{|\Gamma|}(P,t)\,2^{-H}.
\tag{6.19}
\]
Thus any constant-success distributional package must pay at least one of:

1. target information \(I(M;S)=\Omega(\log|\mathcal M|)\);
2. a linear conditional min-entropy deficit on a non-negligible policy mass; or
3. residual joint correlation after conditioning on \(S\).

In the full-projection/high-distance regime, (6.19) makes item 2 quantitative through
\(H_{|\Gamma|}(\varepsilon)\). The Markov and conditional-independence hypotheses are
explicit: Theorem 6.7 is a Closure Gate for policy-generated global words, not an
unconditional impossibility theorem for protocols that still receive the target as a
separate input. The information and entropy proofs are Theorem 3.5--3.6 of the
distributional-soundness paper; see [note 287](../../../mcsp-hardness-magnification/notes/287-fano-entropy-policy-closure-gate-2026-08-17.md).

### Corollary 6.7A (heavy-coordinate tail Closure Gate)

The \(w_{\min}\) reduction is not sharp for a nonuniform coordinate distribution.  Under
the weighted branch hypotheses (WD1)--(WD2), with coordinate weights \(w_i\),
completeness \(\alpha\), and weighted error \(\varepsilon\), let
\[
 H_\tau:=\{i:w_i\ge\tau\},\qquad h_\tau:=|H_\tau|,\qquad
 \beta_\tau:=\min\{1,\varepsilon/\tau\}.
\tag{6.18A}
\]
For every \(\tau\) with \(\varepsilon/\tau<\alpha\), restrict the message family to
the coordinates in \(H_\tau\), fixing all other coordinates to zero.  The restricted
proof map has length \(P\), message length \(h_\tau\), target-relative radius \(\rho\),
and pointwise wrong-claim probability at most \(\beta_\tau\).  Hence threshold
amplification and message inlining give a weak adaptive RLDC of length
\[
 N_\tau=h_\tau+P
\]
and locality
\[
 Q_\tau=O\!\left(q(\alpha-\beta_\tau)^{-2}\right).
\tag{6.18B}
\]
Consequently, any applicable relaxed-LDC lower-bound function
\(\operatorname{LB}_{A,\rho,Q_\tau}\) satisfies
\[
 h_\tau+P\ge
 \operatorname{LB}_{A,\rho,Q_\tau}(h_\tau)
\tag{6.18C}
\]
for every such threshold.  In particular, in a fixed applicable RLDC lower-bound window
(GGS for nonadaptive or DGL for adaptive decoders),
\(P\le h_\tau(\log h_\tau)^c\) infinitely often forces
\[
 Q_\tau=\Omega\!\left(\frac{\log h_\tau}{\log\log h_\tau}\right).
\tag{6.18D}
\]
Thus a heavy prefix of \(h\) coordinates with weights \(\Omega(1/h)\) triggers the
RLDC barrier at scale \(h\), even if \(w_{\min}\) is exponentially smaller.
Equivalently, for a fixed \(0<\gamma<\alpha\), if
\[
 h_\gamma(w,\varepsilon):=
 \left|\left\{i:w_i\ge\frac{\varepsilon}{\alpha-\gamma}\right\}\right|,
\]
then
\[
 h_\gamma(w,\varepsilon)+P
 \ge
 \operatorname{LB}_{A,\rho,O(q\gamma^{-2})}
 \bigl(h_\gamma(w,\varepsilon)\bigr).
\tag{6.18E}
\]
Hence every constant-gap tail must itself stay below the applicable coding scale; the
obstruction is a Lorenz-tail constraint, not just a \(w_{\min}\) constraint.

Indeed, (WD2) implies
\(p_{i,1-m_i}(z)\le\varepsilon/w_i\le\beta_\tau\) for every \(i\in H_\tau\).
Restricting to those coordinates preserves completeness and the target-relative
wrong-claim bound.  Two restricted proof words that were within radius \(\rho\)
would disagree on a heavy coordinate and contradict the gap
\(\beta_\tau<\alpha\); the thresholded two-branch inline decoder then gives
(6.18B).  This is a tail-sensitive strengthening of the \(w_{\min}\) bound, not
an unconditional theorem for ordinary average/list soundness.

### Proposition 6.7B (conditional-correlation residual gate)

The residual-correlation escape can also be quantified without assuming conditional
independence.  Let \(\mathcal Y\subseteq\Gamma^M\) be a valid-word family and let
\(\mathcal A_t=\{z:d_H(z,\mathcal Y)\le t\}\).  For a policy \(S\), write
\(\mu_s=\mathsf{Law}(Z\mid S=s)\) and let
\(\nu_s=\bigotimes_j\mu_{s,j}\) be the product of its conditional coordinate
marginals.  Define the conditional total correlation

\[
  \operatorname{TC}_2(s)=D_2(\mu_s\Vert
  \nu_s)=\sum_j H_2(Z_j\mid S=s)-H_2(Z\mid S=s).
\tag{6.19A}
\]

Suppose a set of policy values \(G\) has mass at least \(1-\delta\), every \(s\in G\)
satisfies \(\sum_jH_\infty(Z_j\mid S=s)\ge H\), and
\(B=|\mathcal Y|V_{|\Gamma|}(M,t)2^{-H}\le1\).  If

\[
  p=\Pr[Z\in\mathcal A_t],
\]

then

\[
  \mathbb E[\operatorname{TC}_2(S)\mid S\in G]
  \ge
  \frac{p-\delta}{1-\delta}\log_2\frac1B-1
  \qquad(p>\delta).
\tag{6.19B}
\]

In particular, in the full-projection regime with relative distance \(\Delta\),
\(t=\lfloor\varepsilon M\rfloor\), and
\(H\ge M(\log_2|\Gamma|-\zeta)\),

\[
  \log_2\frac1B
  \ge M\bigl((\Delta-H_{|\Gamma|}(\varepsilon))\log_2|\Gamma|-\zeta\bigr)
  -O_{|\Gamma|}(\log M).
\tag{6.19C}
\]

Thus, whenever the bracket in (6.19C) is positive, constant global-word success
forces \(\Omega(M)\) conditional total correlation on the policy-good mass, unless
that mass is itself bounded away from one.  This closes the statistical residual-
correlation branch left by Theorem 6.7; it does not lower-bound the length of a short
latent seed, which must still be charged by the policy-information gates.

#### Proof

For \(s\in G\), every atom of \(\nu_s\) has mass at most \(2^{-H}\), so
\(\nu_s(\mathcal A_t)\le B\).  Data processing under the indicator of
\(\mathcal A_t\) gives

\[
  \operatorname{TC}_2(s)\ge
  p_s\log_2(1/B)-h_2(p_s)
  \ge p_s\log_2(1/B)-1,
\]

where \(p_s=\mu_s(\mathcal A_t)\).  Averaging over \(G\) and using
\(p\le\delta+(1-\delta)\mathbb E[p_S\mid S\in G]\) proves (6.19B).  Singleton and the
\(A\)-ary Hamming-ball volume estimate give (6.19C). \(\square\)

This proposition strictly interpolates the two earlier endpoints: zero conditional
total correlation recovers the conditional-product barrier, while a trivial policy with
uniform marginals recovers the fixed-marginal correlation cost.  Its content is a
linear statistical dependence requirement, not a generic dPCP impossibility theorem.

### Corollary 6.7C (target-channel trichotomy)

Let \(M\) be uniform on \(\mathcal M\), let
\(Y:\mathcal M\hookrightarrow\Gamma^M\) be injective with minimum distance greater
than \(2t\), and let \(Z\)
be any output jointly distributed with a policy \(S\).  If
\[
 p=\Pr[d_H(Z,Y(M))\le t],
\]
then
\[
\begin{aligned}
 I_2(M;S)
 &+\sum_{j=1}^{M} I_2(M;Z_j\mid S)
 +\mathbb E[\operatorname{TC}_2(Z\mid M,S)]\\
 &\ge p\log_2|\mathcal M|-1.
\end{aligned}
\tag{6.19D}
\]
The proof is the identity
\[
 I_2(M;S,Z)=I_2(M;S)+\sum_j I_2(M;Z_j\mid S)
 -\operatorname{TC}_2(Z\mid S)+\operatorname{TC}_2(Z\mid M,S),
\]
combined with nearest-word decoding, Fano, and
\(\operatorname{TC}_2(Z\mid S)\ge0\).  Consequently, a short policy and
low-information coordinate marginals can coexist with global decoding only if the
responses retain large target-conditioned joint correlation.  Under independent
private randomness conditioned on \((M,S)\), the final term vanishes.  This is an
information-accounting corollary, not a proof-length lower bound by itself; it
pinpoints the joint-relation interface still required by a positive construction.

### Theorem 6.8 (standard-Borel policy--locality Closure Gate)

The policy escape and the finite-alphabet RLDC barrier also combine quantitatively. Let
\(\Pi:\{0,1\}^{K}\to\Sigma^P\) be one common proof map, with fixed
\(|\Sigma|=A\ge2\), positive target-relative radius \(\rho\), and branch gap
\(1-\beta>0\). Let a standard-Borel policy object \(S\) select, for every coordinate
and both claims, adaptive verifiers making at most \(r\) proof-symbol queries. Assume
that for almost every policy value \(s\), every target in the posterior support of
\(M\mid S=s\) uses the same policy family, with perfect correct-branch completeness
and wrong-claim acceptance at most \(\beta\) on every \(\rho P\)-near proof. If
\(I_2(M;S)\le\gamma K\) for a fixed \(\gamma<1\), then a shattered fiber and inline
decoding give a finite-alphabet nonadaptive RLDC on
\(d=(\theta_\gamma-o(1))K\) message bits, where
\(H_2(\theta_\gamma)=1-\gamma\), with alphabet \(A+2\) and query count
\[
 Q_{r,A}=1+2\sum_{j=0}^{r-1}A^j.
\tag{6.20}
\]
Consequently, writing \(N=d+P\),
\[
 N\ge
 \left(
 \frac{(1-\beta)^2d}
 {38Q_{r,A}^{4}\log^2(A+2)\log^2d}
 \right)^{1+1/\lceil Q_{r,A}/(1-\beta)\rceil}
\tag{6.21}
\]
whenever the GGS radius condition
\(\delta_0>N^{-(1-\beta)/(2Q_{r,A})}\) holds, where
\(\delta_0=\delta_0(\rho,A)>0\) is the constant inline radius. In particular, under fixed
\(A,\rho,\beta,\gamma\),
the near-linear regime \(N\le K(\log K)^c\) forces
\[
 Q_{r,A}=\Omega\!\left(\frac{\log K}{\log\log K}\right),
\qquad
 r\ge\log_A\log K-\log_A\log\log K-O_{A,\rho,\beta,\gamma,c}(1).
\tag{6.22}
\]

The proof is the standard-Borel fiber/VC argument of Theorem 6.6 followed by the
tagged inline, adaptive-to-nonadaptive compilation and the arbitrary-finite-alphabet
RLDC lower bound. A complete statement, including the Singleton radius calculation and
all supportwise quantifiers, is in [note 288](../../../mcsp-hardness-magnification/notes/288-standard-borel-policy-locality-closure-gate-2026-08-17.md).
Thus a near-linear construction with
\(Q_{r,A}=o(\log K/\log\log K)\) must have \(I(M;S)=K-o(K)\), or else leave the
common-proof, supportwise-robust interface. This is a coding-level barrier, not an
unconditional dPCP impossibility theorem or a proof of \(P\ne NP\).
If the policy is generated from a target-dependent descriptor \(D\) and
target-independent randomness, \(M\to D\to S\) gives
\(I(M;S)\le H(D)\). Hence the same low-locality regime forces
\(|D|\ge K-o(K)\); polynomial-in-\(\log K\) keys, sheet selectors, and finite
strategy summaries cannot be the missing address-scale closure mechanism.

### Corollary 6.8A (growing-alphabet coordinate-normalization Closure Gate)

The preceding policy gate remains quantitative when the proof alphabet grows with
the payload.  Let \(A_K=|\Sigma_K|\), let \(S\) be standard-Borel and
supportwise robust as in Theorem 6.8, and assume \(I(M;S)\le\gamma K\) for a fixed
\(\gamma<1\).  If \(N=K+P\le K(\log(K+2))^c\) infinitely often, put

\[
 H_{K,A}:=\log\log(K+2)+\log(Q_{r,A}+2)
       +\log(\log(A_K+2)+2).
\]

For every fixed \(\vartheta>0\) below the smaller solution of
\(H_2(\vartheta)=1-\gamma\), all sufficiently large such \(K\) satisfy

\[
 \log A_K\ge \frac{\vartheta K}{4}
 \qquad\text{or}\qquad
 Q_{r,A}H_{K,A}=\Omega_{\rho,\beta,\gamma,c}(\log K).
\tag{6.20A}
\]

Indeed, the policy fiber/VC argument gives a shattered submessage of dimension
\(d\ge(\vartheta-o(1))K\).  Inline decoding and the adaptive-to-nonadaptive
decision-tree union produce an \((A_K+2)\)-ary RLDC on \(d\) bits.  Applying the
source-safe joint alphabet--locality envelope to this RLDC gives either
\(\log(A_K+2)\ge d/2\), which is the first alternative, or the second alternative
in (6.20A).  Thus a target-normalized address schedule with
\(\log A_K=o(K)\) and
\(Q_{r,A}H_{K,A}=o(\log K)\) must carry
\(I(M;S)=K-o(K)\).  If \(M\to D\to S\), data processing strengthens this to
\(H(D)=K-o(K)\).

Unlike Theorem 6.8 for fixed alphabets, the inline radius here is allowed to
shrink as \(1/(\log A_K+1)\).  The source-safe envelope is used precisely
because it closes both this radius-failure branch and the GGS branch.

This is the growing-alphabet version of the policy/locality closure, not an
unconditional impossibility theorem: ordinary distributional/list soundness,
zero radius, and a message-scale alphabet remain outside its hypotheses.  The
self-contained envelope calculation is recorded in
[note 303](../../../mcsp-hardness-magnification/notes/303-growing-alphabet-coordinate-normalization-closure-gate-2026-08-17.md).

### Corollary 6.8B (distributional policy to growing-alphabet Closure Gate)

The same envelope also closes a nontrivial target-dependent distributional
subclass.  Let \(\mu_m\) be a policy law for target \(m\), and define the
worst-coordinate, worst-\(\rho P\)-near-proof wrong-claim defect
\(\mathcal D_{\rm w}(m,s)\) as in [note 304](../../../mcsp-hardness-magnification/notes/304-distributional-policy-growing-alphabet-closure-gate-2026-08-17.md). Assume that every policy in every \(\mu_m\) has perfect correct-claim completeness, and put
\[
\bar\delta=\mathbb E_{m,s\sim\mu_m}\mathcal D_{\rm w}(m,s),\qquad
\tau=\bar\delta+\sqrt{(\ln 2)I(M;S)/2}.
\]
If \(\tau\le\Delta/2\) for a fixed \(\Delta<(1-\beta)/2\) on infinitely many \(K\), and \(N\le K(\log(K+2))^c\), then for all sufficiently large such \(K\),
\[
\log A_K\ge K/8
\qquad\text{or}\qquad
Q_{r,A}H_{K,A}=\Omega_{\rho,\beta,\Delta,c}(\log K).
\]

The proof first replaces the target-dependent laws by the marginal law
\(\bar\mu=\mathcal L(S)\).  Pinsker controls the average change in
\(\mathcal D_{\rm w}\) by \(\sqrt{(\ln2)I(M;S)/2}\); Markov then leaves a
\(2^{K-1}\)-sized target subfamily on which the same marginal policy has
supportwise wrong-claim error at most \(\beta+\Delta\).  Sauer--Shelah supplies a
\(\Theta(K)\)-dimensional shattered submessage.  Inline decoding, the adaptive
decision-tree union, and the \(A_K\)-ary Singleton radius calculation reduce it
to the source-safe envelope above.  Thus this is a genuine distributional-policy
closure result, but not a theorem for ordinary average/list soundness: the
maximal coordinate-and-near-proof defect and perfect correct completeness are
explicit hypotheses.

### Corollary 6.8C (full-ROC growing-alphabet adaptive-RLDC Closure Gate)

The perfect-completeness hypothesis in Corollary 6.8B can be removed for a
stronger, explicitly global interface.  Suppose each target-dependent policy
is a single package containing, for every coordinate and both claims, an
adaptive verifier and a transcript filter.  Let its robust full-ROC defect be
\(\mathcal D_{\rm ROC}\) as in [note 305](../../../mcsp-hardness-magnification/notes/305-full-ROC-growing-alphabet-adaptive-rldc-gate-2026-08-17.md), and assume
\[
2/3\le\alpha\le1,\qquad 0\le\beta\le1/3,\qquad
\bar\delta=\mathbb E\mathcal D_{\rm ROC},\qquad
\tau=\bar\delta+\sqrt{(\ln2)I(M;S)/2}\le\Delta/2,
\]
where \(\Delta<(\alpha-\beta)/2\).  If \(L_K=O(\log A_K)\) is the length of a
constant-rate binary inner code for \(\Sigma_K\), \(L_K\le\operatorname{polylog}K\),
and \(N\le K\operatorname{polylog}K\), then
\[
(1+L_Kr_K)\log(3+L_Kr_K)
\;=\;\Omega((\log K)^{1/3})
\]
on infinitely many sufficiently large lengths, provided
\(\alpha-\Delta\ge2/3\) and \(\beta+\Delta\le1/3\).

Indeed, the mutual-information mixture argument yields a density-\(1/2\)
target subfamily and one marginal package law with completeness at least
\(2/3\) and wrong output at most \(1/3\) on every target-relative nearby proof.
Sauer--Shelah supplies a linear shattered submessage.  Encoding each proof
symbol with the inner binary code preserves a constant relative radius (the
\(A_K\)-ary Singleton bound supplies the needed proof-to-message length ratio)
and gives a binary adaptive relaxed LDC of raw locality \(O(1+L_Kr_K)\).
The variable-query DGL calculation of note 255 normalizes this to
\(O((1+L_Kr_K)\log(3+L_Kr_K))\), forcing the displayed threshold in the
near-linear regime.  This is an imperfect-completeness extension of the
distributional closure, but it still requires a single global ROC package;
ordinary average/list soundness does not provide that package.

### Corollary 6.8C' (inner-code cost or adaptive-locality Closure Gate)

The polylogarithmic-alphabet restriction in Corollary 6.8C can be replaced by
an explicit cost dichotomy. Let \(E_K:\Sigma_K\to\{0,1\}^{\ell_K}\) be any
binary inner code of fixed positive relative distance and unique decoding below
half its distance; do not assume \(\ell_K=O(\log A_K)\). Let \(d_K=\Omega(K)\)
be the shattered submessage produced by the full-ROC mixture argument and put
\[
\widehat N_K=d_K+\ell_KP_K.
\]
For every fixed \(c_0\), on every infinite subsequence satisfying
\[
\widehat N_K\le d_K(\log(d_K+2))^{c_0},
\tag{6.26}
\]
one necessarily has
\[
(1+\ell_Kr_K)\log(3+\ell_Kr_K)
 =\Omega((\log K)^{1/3}).
\tag{6.27}
\]
If (6.26) eventually fails, the binary expansion itself has left the
near-linear proof-length regime. Indeed, the common marginal package gives
pairwise \(\rho P_K\)-separated proof words on the shattered representatives.
The \(A_K\)-ary Singleton bound and \(\ell_K\ge\log_2A_K\) make
\(\ell_KP_K/\widehat N_K=\Omega(1)\), while the inner code gives the binary
expanded family a fixed positive distance. Inline decoding plus the package
filter is a binary adaptive relaxed decoder with locality at most
\(1+\ell_Kr_K\). Applying the source-audited variable-query DGL theorem
([note 255](../../../mcsp-hardness-magnification/notes/255-variable-query-relaxed-dgl-theorem-2026-08-17.md))
to (6.26) yields (6.27). Thus a large proof alphabet cannot be treated as a
free escape: it must pay either its actual inner-code expansion or the
adaptive locality threshold.

### Corollary 6.8C'' (nonadaptive inner-code sharpening)

Under the hypotheses of Corollary 6.8C', suppose additionally that every
package verifier is nonadaptive in its proof-symbol queries.  After binary
inner decoding, the query set is then nonadaptive with
\[
R_K=1+\ell_Kr_K
\]
queries; no decision-tree expansion or variable-query DGL normalization is
needed.  On the same subsequence (6.26),
\[
R_K=\Omega\!\left(\frac{\log K}{\log\log K}\right).
\tag{6.27a}
\]

To see this, the proof of Corollary 6.8C' already gives a binary RLDC of
constant relative radius and message length \(d_K=\Theta(K)\), now with
nonadaptive query count \(R_K\).  The GGS inequality applies with binary
alphabet.  In the contradiction regime
\(R_K\le\eta\log d_K/\log\log d_K\), the radius condition holds because
\[
\widehat N_K^{-\sigma/(2R_K)}
\le d_K^{-\sigma/(2R_K)}
\le(\log d_K)^{-\sigma/(2\eta)}
\]
is eventually below the constant expanded radius.  The quantitative
calculation of [note 242](../../../mcsp-hardness-magnification/notes/242-growing-query-threshold-for-near-linear-closure-2026-08-17.md), with \(k=d_K\), rules out this regime and proves
(6.27a).  Thus the adaptive C326 threshold is not the right boundary for
nonadaptive coordinate-robust packages: the latter must pay the sharper
\(\log K/\log\log K\) locality cost, or leave the inner-code near-linear
window.

### Corollary 6.8E (imperfect full-ROC direct q-ary Closure Gate)

The inner-code assumption in Corollaries 6.8C' and 6.8C'' is not needed for a
direct growing-alphabet envelope.  Suppose the mutual-information/full-ROC
mixture has produced a density-\(1/2\) target subfamily and one
target-independent package law on a common proof address space.  Assume that
for fixed constants \(0<s<c\le1\), every coordinate and both claims have
correct-claim probability at least \(c\) on the target proof and wrong-output
probability at most \(s\) on every \(\rho P_K\)-near target proof.  Let
\(d_K=\Omega(K)\) be a shattered coordinate set, \(A_K=|\Sigma_K|\), and
\[
  Q_K=1+2\sum_{j<r_K}A_K^j,\qquad
  H_K=\log\log(d_K+2)+\log(Q_K+2)
       +\log(\log(A_K+2)+2).
\]
On every sufficiently large subsequence with
\(N_K=d_K+P_K\le d_K(\log(d_K+2))^{c_0}\), either
\[
  \log(A_K+2)\ge d_K/2
  \qquad\text{or}\qquad
  Q_KH_K=\Omega_{\rho,c,s,c_0}(\log d_K).
\tag{6.27b}
\]

The proof keeps the proof alphabet q-ary.  The density subfamily and
Sauer--Shelah give \(d_K\) representatives; the common full-ROC law and
\(c>s\) force their proof words to have distance \(>\rho P_K\).  The
\(A_K\)-ary Singleton bound supplies a radius
\(\delta_K=\rho/[2(2(1-\rho)\log A_K+1)]\) after tagging inline coordinates
with two symbols disjoint from proof symbols.  Invalid tags output \(\bot\).
The two \(A_K\)-ary adaptive claim trees have a nonadaptive union of at most
\(Q_K\) proof/inline queries.  Applying the arbitrary-finite-alphabet GGS
bound with alphabet \(A_K+2\) either fails its radius condition, which already
gives \(Q_KH_K=\Omega(\log d_K)\), or yields the same logarithmic
contradiction calculation as [note 328](../../../mcsp-hardness-magnification/notes/328-imperfect-full-roc-joint-alphabet-envelope-2026-08-18.md).

This is a direct source-safe q-ary coding barrier, not an upgrade from ordinary
average/list soundness and not an unconditional dPCP impossibility or
\(P\ne NP\) theorem.  It complements the stronger binary gates above: C326 and
C327 charge an available inner code, while Corollary 6.8E remains valid when no
such code is assumed.

### Corollary 6.8F (short-key imperfect full-ROC q-ary Closure Gate)

Corollary 6.8E continues to hold when the package is selected by a short
target key.  Let \(\kappa_K:\{0,1\}^K\to\{0,1\}^{t_K}\), and suppose one
package law is shared by all targets having the same key.  If
\(t_K\le\gamma K\) for a fixed \(\gamma<1\), choose
\(\delta_\gamma<1/2\) with \(H_2(\delta_\gamma)<1-\gamma\).  The largest key
bucket then contains a shattered coordinate set of size
\(d_K\ge\delta_\gamma K\) by Sauer--Shelah.  Consequently, on every near-linear
subsequence \(K+P_K\le K\operatorname{polylog}K\), imperfect full-ROC semantics
with correct probability \(c\) and wrong probability \(\beta<c\) force
\[
  \log(A_K+2)\ge\frac{\delta_\gamma K}{2}
  \qquad\text{or}\qquad
  Q_KH_K=\Omega_{\rho,c,\beta,\gamma}(\log K),
\tag{6.27c}
\]
where \(Q_K\) and \(H_K\) are as in Corollary 6.8E.  This closes a short
discrete key, but not arbitrary target-specific packages whose verifier can
change inside a bucket or after the coordinate is revealed.  The reduction is
the bucket restriction followed by Corollary 6.8E; details are in
[note 329](../../../mcsp-hardness-magnification/notes/329-short-key-imperfect-full-roc-qary-closure-2026-08-18.md).

### Corollary 6.8G (imperfect distributional full-ROC q-ary Closure Trichotomy)

The two preceding gates compose into a single target-dependent statement.
Let \(\mu_m\) be a global package law for target \(m\), and define
\(\bar\delta_K\), \(I_K\), and
\[
  \tau_K=\bar\delta_K+\sqrt{\frac{\ln2}{2}I_K}
\]
from the worst-coordinate, worst-\(\rho P_K\)-near-proof full-ROC defect as
in note 275.  Fix \(0<\Delta<(\alpha-\beta)/2\).  On every near-linear
subsequence \(K+P_K\le K\operatorname{polylog}K\), at least one of
\[
  \tau_K\ge\frac{\Delta}{2},\qquad
  \log(A_K+2)=\Omega_{\Delta}(K),\qquad
  Q_KH_K=\Omega_{\rho,\alpha,\beta,\Delta}(\log K)
\tag{6.27d}
\]
holds, with \(Q_K,H_K\) as in Corollary 6.8E.

Indeed, if \(\tau_K<\Delta/2\), Pinsker and Markov yield a density-\(1/2\)
subfamily and one target-independent package law with correct probability
\(\alpha-\Delta\) and wrong probability \(\beta+\Delta\).  Corollary 6.8E
then gives the second or third alternative.  Hence a target-dependent
distributional package with imperfect completeness has a unified
defect/information--alphabet--locality trichotomy, without any binary
inner-code assumption.  The max-before-average full-ROC quantifier remains
essential; ordinary average/list soundness is not covered.  See
[note 330](../../../mcsp-hardness-magnification/notes/330-imperfect-distributional-full-roc-qary-trichotomy-2026-08-18.md)
for the quantitative fiber argument.

### Corollary 6.8H (polynomial-alphabet locality threshold)

Corollary 6.8G has an explicit locality consequence whenever the proof alphabet is
polynomially bounded.  Assume its full-ROC/common-package hypotheses on an infinite
near-linear subsequence, and suppose

\[
  \log(A_K+2)\le B\log(K+2)
\tag{6.27e}
\]

for a fixed \(B\).  If the defect/information branch is below the fixed margin, then

\[
  Q_K=\Omega\!\left(\frac{\log K}{\log\log K}\right).
\tag{6.27f}
\]

More explicitly, let \(\eta_0>0\) be the constant in the third alternative of
Corollary 6.8G, so that (after the message-scale alphabet alternative has been
excluded) \(Q_KH_K\ge\eta_0\log K\).  Under (6.27e), if
\(Q_K\le\eta'\log K/\log\log(K+2)\), then
\[
 H_K\le 3\log\log(K+2)+O_{B,\eta'}(1).
\]
Hence every fixed \(\eta'<\eta_0/8\) is impossible for all sufficiently large
\(K\), and one may take the implicit constant in (6.27f) to be any
\(c_*<\eta_0/8\).  The threshold \(K_0\) may depend on \(B\) and the fixed
interface parameters, but the leading constant does not require a hidden
subsequence choice.

For a fixed alphabet \(A_K=A\), this is equivalent to

\[
  r_K\ge \log_A\log K-\log_A\log\log K
       +\log_A\!\left(\frac{(A-1)c_*}{2}\right)
       -o_A(1).
\tag{6.27g}
\]

To see this, Corollary 6.8G first rules out its message-scale alphabet alternative.
If \(Q_K\le\eta'\log K/\log\log K\), then (6.27e) and the definition of \(H_K\)
give \(H_K\le3\log\log K+O_{B,\eta'}(1)\).  Choosing \(\eta'\) below one quarter
of the constant in \(Q_KH_K=\Omega(\log K)\) contradicts the third alternative.
Thus a polynomial-alphabet, target-dependent imperfect package cannot preserve
near-linear proof length with \(o(\log K/\log\log K)\) direct query support.  The
conclusion still requires the max-before-average full-ROC and common-address quantifiers;
it is not an ordinary average/list-soundness theorem.
See [note 331](../../../mcsp-hardness-magnification/notes/331-imperfect-full-roc-polynomial-alphabet-locality-threshold-2026-08-18.md).

### Corollary 6.8D (sample-only candidate-index entropy gate)

There is also an information-theoretic obstruction before the C305 decoder
can even be formed.  Let
\(\mathcal Y_K=\{y^{(s)}:s\in[L_K]\}\subseteq\Gamma_K^{M_K}\) be a
candidate global-word family, with \(S\) uniform on \([L_K]\).  Suppose a
target-independent procedure sees \(R_{0,K}\) independently sampled
coordinate--symbol pairs (the sampled coordinates are public and independent
 of \(S\)), each symbol belonging to \(\Gamma_K\), and returns a list \(B\) of
 size at most \(\lambda_K\) containing \(S\) with probability at least
 \(1-\eta\).  Then
\[
R_{0,K}\log_2|\Gamma_K|
\ge (1-\eta)\log_2(L_K/\lambda_K)-h_2(\eta).
\tag{6.24}
\]
This is the list-Fano bound and does not assume a particular PCP construction.
Consequently, for any fixed \(\eta<1\), if \(L_K=2^{\Theta(K)}\) and
\(\lambda_K=2^{o(K)}\), then
\[
R_{0,K}\log|\Gamma_K|=\Omega(K).
\tag{6.25}
\]
If each sampled symbol itself costs \(q_K\) common-proof queries, any
sample-only candidate-index route has proof locality
\(q_KR_{0,K}\); for polylogarithmic \(|\Gamma_K|\) this is already
\(\Omega(K/\operatorname{polylog}K)\), before the C305 full-ROC/RLDC gate is
applied.  Thus public candidate evaluation is not enough: a list-recovery
module with a sub-message-scale transcript, or a genuinely robust outer
decoder that avoids index recovery, is necessary for an address-scale
construction.

### Theorem 6.9 (cover-sheet binding Closure Gate)

Let \(\rho:Y\to X\) be a finite connected \(\ell\)-sheet cover. A shared-top
tester can therefore have an accepting lift-word on \(Y\) without having a
comparable word on the base address space \(X\). Any postprocessor that preserves
the \(\ell\) sheets while claiming base-word closure through one common proof space
\(\Sigma^P\) has the following trilemma.

First, it may keep the lift-word; this is not base-word closure and cannot be used
as a JK parent object on \(X\). Second, if a target-independent adaptive selector
uses a \(d\)-bit sheet descriptor and at most \(q\) proof-symbol queries, and
correctly identifies sheet \(s\) with probability at least \(\alpha\), then

\[
 d+q\log_2|\Sigma|
 \ge \log_2\ell-\log_2(1/\alpha).
\tag{6.23}
\]

A list-valued selector of list size \(\Lambda\) pays an additional
\(\log_2\Lambda\) on the left. Third, suppose the sheets contain a full
\(K\)-bit target subfamily (\(\ell=2^K\)) with one common proof/address space,
positive target-relative radius, perfect correct-branch completeness, and
supportwise wrong-claim soundness over a fixed alphabet \(A\). If the resulting
standard-Borel policy object is \(S\), then in the near-linear regime
\(N=K(\log K)^c\), under the GGS radius condition, either

\[
 Q_{r,A}=\Omega\!\left(\frac{\log K}{\log\log K}\right),
 \qquad\text{or}\qquad
 I(M;S)=K-o(K).
\tag{6.24}
\]

When \(M\to D\to S\) for a target-dependent descriptor and target-independent
randomness, the second branch implies \(H(D)\ge K-o(K)\).

The first inequality is a direct decision-tree counting argument: after fixing the
random tape, pad every terminal transcript to length \(q\). A transcript has one
terminal output and therefore certifies at most one sheet, so averaging over tapes
and at most \(2^d\) descriptors gives
\(\alpha\ell\le2^d|\Sigma|^q\). The list variant multiplies the right side by
\(\Lambda\). The second inequality is Theorem 6.8 applied to the full sheet
subfamily. For the BMVY/DDL consecutive covers,
\(\log_2\ell=\Theta(d_{\rm HDX}^2\log_2\ell_0)\); hence explicit base binding
must carry that many sheet bits in the descriptor/transcript, while a low-locality
robust code must carry the same entropy in its policy or pay the locality branch.

This theorem is source-specific and conditional on preserving sheet entropy and a
common proof/address space. It is not a general dPCP impossibility theorem or a
proof of \(P\ne NP\); a cover-free source, a target-normalized outer object, or an
intentionally retained lift-word lies outside its hypotheses.

### Proposition 6.10 (index-decodable PCPs do not flatten to ACRR at no cost)

There is a useful literature boundary between an index-decodable PCP and the
common-proof interface studied here.  In the index-decodable PCP of
Arnon--Chiesa--Yogev, an honest proof consists of \(k\) separately encoded indexer
proofs \(\pi_1,\ldots,\pi_k\) and one prover proof \(\Pi\).  The verifier has oracle
access to all \(k+1\) oracles, and the decodability condition is stated for the
decoded tuple

\[
  (iDPCP(\widetilde\pi_1),\ldots,iDPCP(\widetilde\pi_k),x,
  wDPCP(\widetilde\Pi)).
\]

Consequently, the published \(O(1)\) query bound is per oracle, not a total
constant-query bound for one binary common proof.  If the \(k\) indexer oracles are
flattened by disjoint concatenation and all consistency tests are retained, a
straight-line simulation has total proof-query budget

\[
  q_{\mathrm{flat}}\;\ge\;\sum_{j=1}^{k}q_{I,j},
\tag{6.10.1}
\]

which is \(\Omega(k)\) when each index is tested with a constant number of
queries.  Directly bundling the \(k\) answers into one symbol replaces this by an
alphabet containing \(\Sigma^k\); over a fixed binary alphabet, reading an
arbitrary bundled symbol costs \(\Omega(k)\) bit queries unless a further
compression theorem is supplied.  Retaining only the indexer oracle for a single
coordinate avoids (6.10.1), but the original decodability theorem no longer applies:
the omitted consistency tests can change the decoded global tuple.  Supplying a
shared membership proof together with only one coordinate's consistency block could
be a valid new construction, but its target-relative soundness is not a consequence
of the index-decodable PCP theorem.  Establishing that implication is exactly a
shared-index/channel compiler, rather than a flattening of the published system.

Thus index-decodable PCPs provide a strong positive baseline—one prover proof and
short \(O(|i|)\) indexer proofs—but they do not by themselves provide an
address-scale ACRR.  Any flattening that preserves the original multi-index
decodability must add a genuinely new shared-index/channel compiler, or must pay
one of the three costs above: total locality, alphabet, or a target-dependent
address/descriptor.  This proposition is a source-aware accounting statement, not
an impossibility theorem for all future index-decodable PCP transformations.

### Proposition 6.11 (strong-canonical closure is an unambiguity route)

Suppose a proposed RW attachment can be upgraded to a single strong-canonical PCP
for a language \(L\): there is one canonical proof \(\Pi(x)\) for every
\(x\in L\), perfect acceptance on \(\Pi(x)\), and every proof \(\pi\) is rejected
with probability at least
\(\rho(\delta(\pi,\Pi(x)))\), with the usual convention
\(\Pi(x)=\lambda\) for \(x\notin L\).  If the verifier uses \(O(\log |x|)\)
randomness, then the characterization of Dinur--Goldreich--Gur gives
\[
  L\in\mathsf{UP}.
\tag{6.11.1}
\]
If the proof length is polynomial and the detection function is polynomially
lower bounded at inverse proof length (in particular, if
\(\rho(\alpha)=\Omega(\alpha)\)), their polynomial-strength characterization gives
\[
  L\in\mathsf{UMA}.
\tag{6.11.2}
\]

Therefore a strong-canonical construction for an NP-hard target would imply
\(\mathsf{NP}\subseteq\mathsf{UP}\) in the logarithmic-randomness regime, or
\(\mathsf{NP}\subseteq\mathsf{UMA}\) under the polynomial-strength regime.  This
is a genuine unambiguity consequence, not a proof of \(P\ne NP\).  It also
explains why the canonical route cannot be treated as a routine replacement for
the target-binding relation-PCP: a generic NP computation has many accepting
histories, while strong canonicality selects one proof with distance-sensitive
soundness.  The same source records an almost-linear strong-canonical PCPP for
USAT as an open problem, so obtaining this property at the RW address scale is
already beyond a routine PCP composition.

The implication does not apply to the weaker ACRR interface in this paper.  ACRR
only compares a claimed coordinate with the target on target-relative nearby
proofs and may output \(\bot\); it does not require global rejection proportional
to distance from one canonical proof.  Thus a successful construction must either
pay the unambiguity consequence above, or remain in the weaker target-relative
common-proof/RLDC regime and meet its coding barriers.

### Proposition 6.12 (LexMax closure gate)

Let \(K_{\mathrm{LexMax}}\) denote a standard bit language for the
lexicographically maximal satisfying assignment of a Boolean formula (with a
fixed no-satisfying-assignment convention).  Reith--Vollmer place the associated
bit-decision problem among the \(\mathsf P^{\mathsf{NP}}\)-complete optimal-assignment
problems.  Suppose a proposed canonical-history compiler has the following
polynomial-scale specialization: on input \((\varphi,i)\), it produces one
polynomial-length proof system, with logarithmic verifier randomness, whose unique
strong-canonical proof encodes the bit of the lexicographically maximal satisfying
assignment, and with the no-instance convention encoded by \(\Pi=\lambda\).  Then
\[
  K_{\mathrm{LexMax}}\in\mathsf{UP},
  \qquad\text{hence}\qquad
  \Delta_2^P=\mathsf P^{\mathsf{NP}}\subseteq\mathsf{UP}\subseteq\mathsf{NP}.
\tag{6.12.1}
\]
Consequently \(\Delta_2^P=\mathsf{NP}\) (and hence
\(\mathsf{NP}=\mathsf{coNP}\)), so the polynomial hierarchy collapses to
\(\mathsf{NP}\).  If logarithmic randomness is relaxed but polynomial proof
length and polynomial-strength rejection are retained, the source theorem gives
the weaker inclusion
\[
  \Delta_2^P\subseteq\mathsf{UMA};
\tag{6.12.2}
\]
without an additional collapse theorem, this UMA statement should not be
upgraded to \(\mathsf{PH}=\mathsf{NP}\).

This is a sharper test than the NP-hard-target version of Proposition 6.11:
LexMax is itself the canonical \(\mathsf{FP}^{\mathsf{NP}}\)-style selection
mechanism that RW histories emulate.  Therefore a successful simultaneous
coordinate-robust compiler for this benchmark would already be a major
complexity-class collapse, even before it is coupled to JK or Range Avoidance.
The statement is deliberately polynomial-scale.  An RW history of length
\(t(n)=2^{\Theta(n)}\) cannot be reparameterized as a \(\mathsf{P}^{\mathsf{NP}}\)
input without a separate succinct compiler; a full-table \(\mathsf{FP}^{\mathsf{NP}}\)
search at that scale only yields an \(\mathsf E^{\mathsf{NP}}\)-scale object.

Thus the positive target is not merely “make all coordinate proofs share one
address space.”  It must either avoid the LexMax gate by proving a genuinely
target-relative (non-strong-canonical) relation-PCP, or explain why its shared
proof does not encode an unambiguous lexicographic selector.  Otherwise the
construction is implicitly solving a known \(\Delta_2^P\) selection problem inside
\(\mathsf{UP}\), which is a qualitatively stronger claim than \(P\ne NP\).

### Proposition 6.13 (GMWZ three-query upgrade is not a free simultaneous compiler)

Consider the following concrete upgrade of the 3-query PCPP supplied by
Gur--Minzer--Weissenberg--Zheng (GMWZ): for every \(k\)-bit message there is one common
proof \(\Pi(m)\) of length
\[
  P_k\le k(\log(k+2))^{c},
\tag{6.13.1}
\]
over a fixed finite alphabet \(\Sigma\), and for every coordinate \(i\) and claim \(b\)
there is a target-relative verifier using at most three proof queries such that
\[
  p_{i,m_i}(\Pi(m))=1,\qquad
  d_H(z,\Pi(m))\le\rho P_k
  \Longrightarrow
  p_{i,1-m_i}(z)\le\beta<1.
\tag{6.13.2}
\]
Assume the verifier address space and proof map are the same for all \((i,b)\).
Then the inline compiler of Theorem 2.2 gives a finite-alphabet, perfect-complete
4-query RLDC of length \(N_k=k+P_k\), constant radius, and gap
\(\sigma=1-\beta\).  Consequently the arbitrary finite-alphabet GGS lower bound implies
\[
  N_k\ge
  \left(
    \frac{\sigma^2 k}
    {38\cdot 4^4\log^2(|\Sigma|+2)\,\log^2 k}
  \right)^{1+1/\lceil4/\sigma\rceil}
\tag{6.13.3}
\]
for all sufficiently large \(k\).  This contradicts (6.13.1).

#### Proof

Theorem 2.2 reads the inline claim bit and then runs the three-query verifier for that
claim, so its total locality is \(Q=4\).  Tagging proof symbols and inline claim symbols
by disjoint types gives an RLDC alphabet of size \(|\Sigma|+2\).  The Singleton argument
in that theorem supplies a constant inline radius \(\delta_\rho>0\); hence
\(\delta_\rho>N_k^{-\sigma/(2Q)}\) for all sufficiently large \(k\).  Apply the finite-alphabet
GGS theorem with \(Q=4\), alphabet \(|\Sigma|+2\), and message dimension \(k\), obtaining
(6.13.3).  Its exponent is strictly larger than one for fixed \(\sigma>0\), fixed
\(|\Sigma|\), so a \(k\,\mathrm{polylog}(k)\) length is impossible. \(\square\)

The proposition is deliberately conditional.  The GMWZ theorem itself supplies a
quasi-linear 3-query PCPP with constant alphabet and perfect completeness, but it does not
assert the simultaneous target-relative coordinate quantifier in (6.13.2).  Therefore the
remaining positive problem is now sharply stated: either construct that common coordinate
binding while paying one of the parameters excluded by (6.13.3) (growing alphabet, shrinking
radius or gap, or superlinear length), or prove a new composition theorem that genuinely
evades the inline/RLDC bridge.  Ordinary distributional or list soundness does not meet
(6.13.2), because it permits different local explanations for different coordinates.

### Proposition 6.14 (the GMWZ list has a phantom-word gap)

The list-decoding soundness in Definition 1.3 of GMWZ does not by itself imply the
target-relative coordinate condition (6.13.2).  In their notation, for an arbitrary
assignment \(A\) one obtains a list
\[
  Y_A=\{y^{(1)},\ldots,y^{(L)}\}\subseteq\mathcal L
\]
such that a satisfied local test at coordinate \(t\) may decode to any symbol in
\(\{y^{(1)}_t,\ldots,y^{(L)}_t\}\).  This allows the selected list element to depend on \(t\).

At the level of the soundness conclusion, take two words \(y^{(0)},y^{(1)}\) and a hybrid
word \(z\) which equals
\(y^{(0)}\) on \(S_0\) and \(y^{(1)}\) on \(S_1\), where
\(S_0\sqcup S_1=[M]\).  An assignment whose decoded output is \(z\) is perfectly
compatible with the list \(Y_A=\{y^{(0)},y^{(1)}\}\): at every coordinate,
\[
  z_t\in\{y^{(0)}_t,y^{(1)}_t\}.
\tag{6.14.1}
\]
Nevertheless, unless the hybrid happens to be one of the two words, there is no
single \(y\in Y_A\) whose coordinates explain the whole output.  Thus list soundness
does not yield a common target word, a common seed, or the wrong-claim bound for a
fixed target \(y^{(0)}\).  This is a quantifier-level countermodel to the implication; it
does not assert that the hybrid is realized by a satisfying assignment in the particular
GMWZ construction.  A source-specific separation would require an explicit dPCP instance
and assignment witnessing that behavior.

Even after forcing \(L=1\), GMWZ's probability is averaged over the decoded coordinate
and the sampled edge.  An average error \(\varepsilon\) only gives a fixed-coordinate
bound of order \(M\varepsilon\); it does not give a uniform constant \(\beta\) for every
coordinate.  The singleton conditioning calculation in Proposition 5.0 is exactly this
factor-\(M\) loss.  Therefore a black-box GMWZ-to-RW upgrade needs two additional
properties not present in Definition 1.3: (i) one common list element/strategy for all
coordinates, and (ii) coordinate-wise (or \(O(1/M)\)-scaled) soundness.  These are
precisely the new simultaneous-binding theorem that Proposition 6.13 leaves open.

### Proposition 6.15 (the published GMWZ RLDC transformation is coordinate-private)

The missing shared-proof compiler is not hidden inside the published GMWZ construction.
Their Theorem 11.3 explicitly invokes a separate PCPP
\(\Psi_{i,b}\) for every coordinate \(i\in[k]\) and claim \(b\in\{0,1\}\), for the
languages
\[
  \mathcal L_{i,b}
  =\{w:\exists x\in\{0,1\}^{k},\ \mathcal C_0(x)=w,\ x_i=b\}.
\tag{6.15.1}
\]
After equalizing the PCPP lengths to \(K=k(\log k)^{C'}\), the codeword contains the
concatenation of the \(k\) selected coordinate-specific proofs
\(\pi'_{1,m_1},\ldots,\pi'_{k,m_k}\), each of length \(2K\) over a tagged alphabet.
Consequently its proof block already has length
\[
  2kK=\widetilde\Theta(k^2).
\tag{6.15.2}
\]

This is a source-level explanation of the GMWZ quadratic RLDC length: it is not a
single near-linear proof with all coordinate claims locally bound.  Replacing the family
\(\{\Psi_{i,b}\}_{i,b}\) by one common address space would require a new theorem that
simultaneously verifies the relation \(\mathcal C_0(x)=w\), binds the selected bit \(x_i\),
and preserves the PCPP soundness under every coordinate/claim query.  The published
composition does not provide such a shared assignment or a compression of the
\(k\) coordinate-private proof blocks.

Thus Proposition 6.13 should be read as a genuine upgrade target, not as a direct
corollary of GMWZ: the known 3-query PCPP parameters are compatible with
\(\widetilde O(k^2)\) RLDCs precisely because the construction pays for coordinate-private
proofs.  A successful RW/JK construction must either prove a new shared-index relation-PCPP
with near-linear length, or explain why coordinate privacy can be compressed without
reintroducing the phantom-word gap of Proposition 6.14.

### Proposition 6.16 (GMWZ completeness does not supply a canonical proof map)

There is a second, independent gap before the GMWZ proof can be used as an RW/JK
word.  In the proof of their Theorem 11.3, after fixing \(i,b\) and an input word
\(w\), the notation \(\pi_{i,b}(w)\) denotes **an arbitrary** satisfying assignment to
the corresponding PCPP; perfect completeness only proves that at least one such
assignment exists.  The theorem supplies neither
\[
  (i,b,w)\longmapsto \pi_{i,b}(w)
\quad\text{as a uniform single-valued map,}
\tag{6.16.1}
\]
nor identities relating the assignments for different coordinates and claims.

Consequently, replacing the separate blocks by a purported common proof requires two
new choices at once: a canonical assignment selector and a cross-coordinate consistency
map.  Choosing the lexicographically first/last assignment is an
\(\mathsf{FP}^{\mathsf{NP}}\)-scale operation in general and enters the LexMax closure gate
of Proposition 6.12; choosing arbitrary assignments independently recreates the
phantom-word problem of Proposition 6.14.  This is why “perfect completeness plus
near-linear PCPP” is not yet a deterministic, word-consistent RW history.

The proposition is a statement about what the published theorem provides, not an
impossibility result for a future canonical composition.  A new construction could
add a succinct selector, but then that selector and its consistency proof are part of
the main theorem rather than inherited PCPP infrastructure.

### Proposition 6.17 (udPCP removes phantom words but leaves a \(1/n\) coordinate tax)

The uniquely-decodable PCP branch of GMWZ improves the situation in Proposition 6.14:
for every sufficiently satisfying assignment \(T\), Definition 3.10 supplies one word
\(w\in\mathcal L\) such that
\[
  \Pr_{t\in[n],\,a\sim\mathcal P_t}
  [D_t(a,T_A[a])\ne w_t]\le\eta .
\tag{6.17.1}
\]
The selected \(w\) is global, so the phantom-word obstruction is gone.  However,
(6.17.1) is an average over \(t\).  It permits all the error mass to lie on one
coordinate.  Therefore the uniform target-relative condition needed by (6.13.2),
\[
  \sup_{t\in[n]}
  \Pr_{a\sim\mathcal P_t}[D_t(a,T_A[a])\ne w_t]\le\beta,
\tag{6.17.2}
\]
does not follow unless one pays at least
\[
  \eta\le\frac{\beta}{n}.
\tag{6.17.3}
\]
The factor \(n\) is tight: an assignment may decode every coordinate correctly except
one, giving average error \(1/n\) and fixed-coordinate error \(1\).

Hence GMWZ's udPCP is a genuine positive escape from the phantom-word gap, but not yet
an RW coordinate-robust verifier.  Using it for RW requires a parameterized
udPCP whose length, alphabet, decoding complexity, and proof-generation uniformity
remain acceptable when \(\eta=O(1/n)\).  GMWZ's construction states its size and
complexity with constants depending on the soundness parameters, so this substitution
is a new quantitative theorem to prove, not a free invocation of the published
constant-parameter result.

### Proposition 6.18 (GMWZ's shrinking-\(\eta\) window is not a fixed-parameter theorem)

The generic conversion in Proposition 6.17 asks for \(\eta\leq\beta/n\).  This is
not merely a change of notation in the published GMWZ udPCP bounds.  In the proof of
their Lemma 4.5, the auxiliary degree is chosen as
\[
  d'=\Theta(\eta^{-2}),
\tag{6.18.1}
\]
and the displayed size bound is
\[
  s(N)=O_{|\Sigma_0|,\eta}\!\left(N\,\operatorname{polylog}N\right).
\tag{6.18.2}
\]
Thus the black-box substitution \(\eta=\beta/n\) forces
\(d'=\Theta(n^2)\); it does not preserve a constant hidden parameter.  The
stronger construction in their Theorem 5.1 has the same issue in a different form:
its alphabet and decoding-complexity bounds are parameterized by \(\eta\) (and by
\(\delta\)), with the alphabet written as
\[
  O_{|\Sigma_0|}\!\left(2^{\operatorname{poly}_{\eta,\delta}(\log N)}\right).
\tag{6.18.3}
\]

Consequently, the cited theorems establish near-linear length and constant-alphabet
complexity for each fixed positive \(\eta\), but they do **not** establish a
uniform fixed-alphabet, constant-query, near-linear common proof after setting
\(\eta=O(1/n)\).  This is a parameter barrier, not an impossibility theorem: a new
analysis could control the \(\eta\)-dependence, or a different coordinate-normalized
udPCP could avoid the generic \(1/n\) conversion.  Until such a theorem is supplied,
udPCP remains the most promising positive escape from the phantom-word obstruction,
but it is not yet a closed RW/JK interface.

### Proposition 6.19 (the explicit GMWZ regularization pays a quadratic coordinate tax)

There is a stronger, source-specific consequence for the construction in Lemma 4.5.
In its proof, after the degree-regularization steps, the displayed length is

\[
  C\,s(N),
  \qquad
  s(N)=2d'(k+1)|A|,
\tag{6.19.1}
\]

where \(d'=\Theta(\eta^{-2})\), \(k\geq 0\), and the left side \(A\) of the
constraint graph is nonempty.  Hence, even before accounting for any hidden dependence
of \(k\) or \(|A|\), this particular construction has

\[
  C\,s(N)\geq 2d'=\Omega(\eta^{-2}).
\tag{6.19.2}
\]

Combining the generic coordinate conversion \(\eta\leq\beta/n\) with (6.19.2)
gives a proof-length tax \(\Omega(n^2/\beta^2)\) for this explicit regularization.
Consequently, whenever the circuit-size parameter satisfies
\(N\operatorname{polylog}N=o(n^2)\) (for example, \(N=O(n\operatorname{polylog}n)\)),
the Lemma 4.5 construction itself cannot be a near-linear-in-\(N\) realization of
the RW coordinate interface.

This is deliberately a construction-level statement.  It is not a lower bound for
all udPCPs: a future coordinate-normalized construction could avoid this particular
degree-regularization or pay the \(1/n\) error directly in a different channel.  The
result nevertheless turns the shrinking-\(\eta\) issue from an unspecified constant
dependence into a concrete quantitative gate for the currently cited positive route.

### Proposition 6.20 (RW full-history composition gives a quadratic GMWZ barrier)

Consider the full-history black-box composition analyzed in the RW-specific dilution
statement (the history contains an ``out'' field of length \(T_i\), and the dPCP
samples ordinary history coordinates).  Let \(L_i\) be the total decoded-word length,
so \(L_i\geq T_i\).  Under singleton target projection and uniform raw-history sampling,
fixed-coordinate smartness requires

\[
  \eta_i\leq\frac{\beta}{L_i}.
\tag{6.20.1}
\]

Applying the explicit GMWZ Lemma 4.5 regularization to this relation and using
Proposition 6.19 yields

\[
  \operatorname{len}(\mathcal D_i)
    =\Omega\!\left(\frac{L_i^2}{\beta^2}\right)
    \geq\Omega\!\left(\frac{T_i^2}{\beta^2}\right).
\tag{6.20.2}
\]

In the RW stable region \(T_i=n_i^C\), the lower bound is
\(\Omega(n_i^{2C}/\beta^2)\).  Thus the published GMWZ regularization cannot be a
near-linear-in-\(T_i\) full-history RW attachment in this model; if the relation circuit
size is \(N_i=O(T_i\operatorname{polylog}T_i)\), it is also not near-linear in \(N_i\).

The hypotheses are essential.  This proposition does not cover target-normalized
sampling, an outer code that spreads each output bit over a constant fraction of the
proof, or a new relation-PCP whose wrong-claim predicate is coordinate-normalized from
the outset.  Those are precisely the mechanisms that a successful RW Closure-Gate-I
construction would have to add.

### Corollary 6.21 (the standard RW/GMWZ target-binding trilemma)

At a stable RW stage, consider a proposed GMWZ-derived common-proof attachment with
payload \(K_i=2n_i\), history length \(L_i\ge T_i\), and proof length \(P_i\).  Within
the two standard interfaces analyzed above, the following alternatives are exhaustive:

1. **Raw-history scalar binding.**  If ordinary history coordinates are sampled
   without target normalization and a singleton output is extracted from scalar
   average soundness, Proposition 6.20 gives
   \[
     P_i=\Omega(L_i^2/\beta^2).
   \tag{6.21.1}
   \]

2. **Field-lift / target-spreading binding.**  If the output is spread through a
   constant-distance outer code and the resulting common proof has fixed finite
   alphabet, positive radius, perfect completeness, incidence parameter
   \(\chi=O(1)\), and honest-path smoothness \(\lambda=O(1)\), then
   Theorem 5.1D turns the proof map into a constant-query RLDC.  In the binary
   two-query window this invokes the exponential RLDC lower bound; with any fixed
   finite query/alphabet parameters it invokes the corresponding superlinear RLDC
   lower bound.  Hence a near-linear \(P_i\) is incompatible with this interface.

3. **New coordinate-normalized relation.**  Any construction that remains
   near-linear must leave at least one hypothesis of (1) or (2): it must use a
   genuinely coordinate-normalized wrong-claim predicate, non-smooth or
   target-dependent addressing, a growing alphabet/query/radius parameter, a
   bottom/cover strategy, or a new global coupling not represented by the
   field-lift.

This corollary is a source-specific closure theorem, not a general impossibility
result.  Its role is to make the remaining top-tier target precise: a successful
RW attachment must be a new coordinate-normalized relation-PCP, rather than a
parameter optimization of the published GMWZ scalar or field-lift interfaces.

### Proposition 6.22 (anchored udPCP plus a smooth outer decoder)

The \(1/n\) coordinate tax in Proposition 6.17 is not the only possible way to use
unique decoding.  A weaker, quantitative target-binding condition is enough.  Let
\[
  C:\{0,1\}^{k}\longrightarrow\Gamma^{M}
\]
be an injective outer code.  For each message coordinate \(i\), let \(D_i\) be an
adaptive decoder for \(C\) making at most \(q_D\) codeword-symbol queries, with
perfect completeness.  Assume that on the honest word \(C(m)\), at every query
step and every position \(j\), the conditional probability of querying \(j\),
given the preceding honest answers, is at most \(\lambda/M\).

Let \(\Pi:\{0,1\}^{k}\to\Sigma^{N}\) be one common proof map, and let \(L_j\) be a
common-address local proof decoder that makes at most \(q_P\) proof-symbol queries
and returns either a symbol of \(\Gamma\) or \(\bot\).  Assume
\[
  L_j(\Pi(m))=C(m)_j
  \qquad\text{with probability one}
\tag{6.22.1}
\]
for every \(m,j\).  Suppose that for every \(m\) and every
\(z\) with \(\operatorname{dist}(z,\Pi(m))\le\rho\), there is a word
\(C(u)=C(u(z,m))\) such that
\[
 \frac1M\sum_{j=1}^{M}
   \Pr[L_j(z)\notin\{C(u)_j\}]
 \le\varepsilon,
 \qquad
 \operatorname{dist}(C(u),C(m))\le\kappa .
\tag{6.22.2}
\]
Here \(\bot\) is counted as a failure in the first inequality.  Then, for every
coordinate \(i\) and claim \(b\), there is a verifier \(Q_{i,b}\) on the same proof
address space, using at most \(q_Pq_D\) proof-symbol queries, such that
\[
 Q_{i,m_i}(\Pi(m))=1
 \quad\text{with probability one},
\tag{6.22.3}
\]
and, for every \(b\ne m_i\) and every \(z\) in the \(\rho\)-ball of \(\Pi(m)\),
\[
 \Pr[Q_{i,b}(z)=1]
 \le q_D\lambda(\varepsilon+\kappa).
\tag{6.22.4}
\]
Consequently, \(q_D\lambda(\varepsilon+\kappa)<1/2\) gives a simultaneous
coordinate-robust common-proof interface.  If \(C\) has relative distance
\(\Delta\) and \(\kappa<\Delta\), then (6.22.2) forces \(u=m\), so the error term
reduces to \(q_D\lambda\varepsilon\).

#### Proof

The verifier simulates \(D_i\).  Whenever \(D_i\) asks position \(j\), it runs
\(L_j\) with fresh randomness; a \(\bot\) answer aborts, and otherwise the returned
symbol is supplied to \(D_i\).  It accepts claim \(b\) exactly when \(D_i\) outputs
\(b\).  Equation (6.22.3) follows from (6.22.1) and perfect completeness of
\(D_i\).

Fix \(m,i,z\) and a wrong claim \(b\ne m_i\).  Couple the execution to the honest
execution of \(D_i\) on \(C(m)\).  Until the first local answer different from
\(C(m)_j\), the transcript and the next queried position are the honest ones.
For a queried position \(j\), the probability of such a bad answer is at most
\[
 \Pr[L_j(z)\notin\{C(u)_j\}]
 +\mathbf 1[C(u)_j\ne C(m)_j].
\]
Using the smoothness bound, a union bound over the at most \(q_D\) query steps gives
\[
 \Pr[\text{first bad answer}]
 \le q_D\sum_{j=1}^{M}\frac{\lambda}{M}
 \left(\Pr[L_j(z)\notin\{C(u)_j\}]
       +\mathbf 1[C(u)_j\ne C(m)_j]\right)
 \le q_D\lambda(\varepsilon+\kappa).
\]
If no bad answer occurs, \(D_i\) sees exactly the honest word and outputs \(m_i\), so
it cannot accept \(b\).  This proves (6.22.4).  Finally, if \(\kappa<\Delta\), the
distance condition in (6.22.2) and the code distance imply \(u=m\).
\(\square\)

The proposition is a composition theorem, not a claim that the published GMWZ
udPCP already supplies (6.22.2).  Their unique-decoding statement supplies one
global decoded word for a sufficiently satisfying assignment, but a target-relative
\(\kappa\)-anchor for every proof in a fixed \(\rho\)-ball is an additional
relation-PCP property.  The proposition therefore gives a sharper positive target:
prove this anchor with \(\kappa<\Delta\), or quantify the residual \(\kappa\) well enough
that \(q_D\lambda(\varepsilon+\kappa)\) remains below the robust gap.  In particular,
it replaces the crude \(1/M\) coordinate conversion by a smoothness-weighted error
budget; it does not remove the need for a common proof address space.

We finally prove a simultaneous coordinate-robustness Closure Theorem: coordinatewise
valid-word witnesses close globally exactly when the rectangular hull of the valid-word
family is covered by Hamming balls.  The covered case pays an explicit projection-
entropy/distance cost, while failure gives a phantom word; only a genuinely joint
same-seed coupling can pass to the common-proof RLDC barrier.

### Theorem 6.23 (simultaneous coordinate-robustness Closure Theorem)

Let \(\Gamma\) be an alphabet of size \(A\ge2\), let
\(\mathcal Y\subseteq\Gamma^M\) be the valid global-word family of a proposed
relation-PCPP/dPCP, and write
\[
 \pi_j(\mathcal Y)=\{y_j:y\in\mathcal Y\},\qquad
 \operatorname{Rect}(\mathcal Y)=\prod_{j=1}^M\pi_j(\mathcal Y).
\]
Assume \(|\mathcal Y|\ge2\) (the singleton case is vacuous), let \(d\) be the minimum
Hamming distance between distinct words in \(\mathcal Y\), and let \(t\) be the correction
radius claimed by a composition.  Suppose the composition's
only cross-coordinate soundness premise is the following coordinatewise rule:

> whenever a candidate word has, at every coordinate \(j\), some (possibly
> coordinate-dependent) valid-word witness for its symbol, the composition produces one
> valid word within distance \(t\).

Then exactly one of the following two situations occurs.

1. **Rectangular closure.** The rule is valid if and only if
   \[
     \operatorname{Rect}(\mathcal Y)
       \subseteq \bigcup_{y\in\mathcal Y}B_H(y,t).
   \tag{6.23.1}
   \]
   In this case
   \[
     \sum_{j=1}^M\log_A|\pi_j(\mathcal Y)|
       \le M-d+1+\log_A V_A(M,t),
   \tag{6.23.2}
   \]
   where \(V_A(M,t)=\sum_{u\le t}\binom Mu(A-1)^u\).  In particular, if every
   coordinate has full projection \(|\pi_j(\mathcal Y)|=A\), then, for fixed \(A\) and
   \(t/M<1-1/A\),
   \[
     d/M\le H_A(t/M)+o_M(1).
   \tag{6.23.3}
   \]
   Moreover, in the full-projection case \(\operatorname{Rect}(\mathcal Y)=\Gamma^M\), let
   \(r_d=\lfloor(d-1)/2\rfloor\). Hamming packing and the covering premise give
   \[
      |\mathcal Y|V_A(M,r_d)
      \le A^M
      \le |\mathcal Y|V_A(M,t),
      \qquad
      V_A(M,r_d)\le V_A(M,t),
   \tag{6.23.4}
   \]
   and hence
   \[
      \left\lfloor\frac{d-1}{2}\right\rfloor\le t,
      \qquad d\le 2t+2.
   \tag{6.23.5}
   \]
   This packing strengthening dominates (6.23.3) in the small-radius regime.
   More generally, without full projections, the same two inequalities eliminate
   \(|\mathcal Y|\) and give
   \[
      \sum_{j=1}^M\log_A|\pi_j(\mathcal Y)|
      \le M+\log_A V_A(M,t)-\log_A V_A(M,r_d).
   \tag{6.23.6}
   \]
   Thus projection entropy, minimum distance, and correction radius are coupled directly,
   rather than only through the Singleton estimate (6.23.2).
   The same packing argument handles nonuniform coordinate incidence.  For weights
   \(\lambda_j\ge0\) with \(\sum_j\lambda_j=1\), set
   \[
     d_\lambda(x,y):=\sum_j\lambda_j\mathbf 1[x_j\ne y_j],
     \qquad
     V_{A,\lambda}(u):=
       \sum_{\substack{S\subseteq[M]\\\sum_{j\in S}\lambda_j\le u}}
       (A-1)^{|S|}.
   \]
   If the rectangular hull is covered by weighted radius-\(t\) balls and
   \(d_\lambda=\min_{y\ne y'}d_\lambda(y,y')\), then every \(r<d_\lambda/2\)
   satisfies
   \[
      \sum_{j=1}^M\log_A|\pi_j(\mathcal Y)|
      \le M+\log_A V_{A,\lambda}(t)-\log_A V_{A,\lambda}(r).
   \tag{6.23.7}
   \]
   This is the nonuniform-sampling form: it remains valid when the verifier gives
   different coordinates different masses, including zero-mass coordinates.
   There is also a weighted probabilistic form.  If \(Z_j\) are independently
   uniform on \(\pi_j(\mathcal Y)\), define
   \[
      V_{\mathbf p,\lambda}(t):=
      \sum_{\substack{S\subseteq[M]\\\sum_{j\in S}\lambda_j\le t}}
      \prod_{j\in S}\bigl(|\pi_j(\mathcal Y)|-1\bigr).
   \]
   Then
   \[
      \Pr[d_\lambda(Z,\mathcal Y)\le t]
      \le
      \frac{|\mathcal Y|\,V_{\mathbf p,\lambda}(t)}
           {\prod_j|\pi_j(\mathcal Y)|}
      \le
      \frac{A^{M-d+1}\,V_{\mathbf p,\lambda}(t)}
           {\prod_j|\pi_j(\mathcal Y)|}.
   \tag{6.23.8}
   \]
   Thus independent coordinate explanations can have constant global success only if
   their weighted product entropy is paid by the valid-word family or by the weighted
   ball volume.

2. **Phantom-word failure.** If (6.23.1) fails, there is a word
   \(w^\star\in\operatorname{Rect}(\mathcal Y)\) and witnesses
   \(y^{(j)}\in\mathcal Y\) with \(y^{(j)}_j=w^\star_j\) for every \(j\), while
   \(d_H(w^\star,y)>t\) for every \(y\in\mathcal Y\).  Thus no black-box theorem whose
   only global premise is coordinatewise realizability can produce the claimed global
   word.

If a proposed construction escapes item 2 by adding a genuine same-seed/global-word
coupling and this coupling yields a common proof map
\(\Pi:\{0,1\}^K\to\Gamma^P\) satisfying the target-relative ACRR gap of Theorem 2.1,
then it enters the RLDC lower-bound regime of Theorems 2.1 and 4.1.  Hence a near-linear
simultaneous coordinate-robust construction in the full-projection/high-distance regime
must explicitly pay at least one of three costs: a joint coupling not implied by
coordinatewise soundness, reduced projection entropy/distance, or the corresponding
RLDC proof-length/locality cost.

#### Proof

The coordinatewise premise is exactly membership in
\(\operatorname{Rect}(\mathcal Y)\), so the asserted global conclusion is equivalent to
(6.23.1).  Under (6.23.1), the rectangular hull has size
\(\prod_j|\pi_j(\mathcal Y)|\) and is covered by \(|\mathcal Y|\) Hamming balls of
radius \(t\).  The \(A\)-ary Singleton bound gives
\(|\mathcal Y|\le A^{M-d+1}\), proving (6.23.2); the entropy estimate for
\(V_A(M,t)\) gives (6.23.3).  In the full-projection case, the Hamming packing balls of
radius \(r_d=\lfloor(d-1)/2\rfloor\) are disjoint, while (6.23.1) covers all \(A^M\)
words by radius-\(t\) balls.  Hence
\[
 |\mathcal Y|V_A(M,r_d)\le A^M\le|\mathcal Y|V_A(M,t),
\]
which proves (6.23.4)--(6.23.5) by monotonicity of Hamming-ball volume.  For arbitrary
projections, combine \(\prod_j|\pi_j(\mathcal Y)|\le|\mathcal Y|V_A(M,t)\) with
\(|\mathcal Y|V_A(M,r_d)\le A^M\) to obtain (6.23.6).  For the weighted statement,
the same proof uses the center-independent weighted-ball
volume \(V_{A,\lambda}(u)\).  Since \(2r<d_\lambda\), the radius-\(r\) balls around
distinct valid words are disjoint, while weighted closure covers the rectangular hull
by radius-\(t\) balls.  Thus
\(\prod_j|\pi_j(\mathcal Y)|\le|\mathcal Y|V_{A,\lambda}(t)\) and
\(|\mathcal Y|V_{A,\lambda}(r)\le A^M\), which gives (6.23.7).
For (6.23.8), fix a valid word \(y\).  The independent projection sampler has
probability \(V_{\mathbf p,\lambda}(t)/\prod_j|\pi_j(\mathcal Y)|\) of landing in its
weighted ball, by summing over the error set \(S\); a union bound over \(y\), followed
by Singleton, gives (6.23.8).
If (6.23.1) fails, choose \(w^\star\) in the set difference.  By definition of the rectangular hull, each
coordinate has a valid witness, while the distance condition rules out every global
word, proving item 2.  The final sentence is a direct application of Theorems 2.1 and
4.1 once the added coupling has actually supplied their target-relative common-proof
hypotheses; it is not an assertion that ordinary dPCP/list soundness supplies that
coupling. \(\square\)

This theorem is the precise bidirectional attack point for simultaneous coordinate
robustness.  A positive construction must exhibit the extra joint relation (for example a
same-seed anchor), not merely repeat a coordinate verifier.  A negative result can instead
prove that the proposed construction remains coordinatewise, then invoke (6.23.2) or the
phantom certificate.  The theorem is therefore a coding/PCP closure result, not an
unconditional dPCP impossibility or a proof of \(P\ne NP\).

### Proposition 6.24 (satisfied-list collapse yields a shared indexed channel)

Let
\[
 \mathcal Y=\{y^{(s)}=C(m^{(s)}):s\in[L]\}\subseteq\Gamma^M
\]
have pairwise relative distance at least \(\Delta>0\), and let
\(\Pi:[L]\to\Sigma^P\) be an injective common-address proof map.  For every coordinate
\(j\), let \(D_j\) be a randomized adaptive decoder using at most \(q\) proof-symbol
queries, and let \(S_j\) be its local satisfaction predicate.  Assume perfect completeness:
\[
 S_j(\Pi(s))=1,\qquad D_j(\Pi(s))=y^{(s)}_j
\quad\text{with probability one}.
\tag{6.24.1}
\]
The index procedure is given public access to the candidate symbols
\(y^{(s)}_j\); address-scale access to these symbols is required only for the efficient
RLDC conclusion in item 2.

For every target \(s\) and every \(z\) with
\(d_H(z,\Pi(s))\le\rho P\), suppose there is a (target-independent) list
\(\mathcal Y_z\subseteq\mathcal Y\) such that
\[
\begin{aligned}
 \Pr_{J,D_J}\!\left[
   S_J(z)=1\ \land\
   D_J(z)\notin\{y_J:y\in\mathcal Y_z\}
 \right]&\le\varepsilon_{\rm list},\\
 \Pr_J[S_J(z)=0]&\le\sigma,\\
 \Pr_J\!\left[
   \exists y\in\mathcal Y_z:\ y_J\ne y^{(s)}_J
 \right]&\le\kappa.
\end{aligned}
\tag{6.24.2}
\]
Put \(\varepsilon_*=\varepsilon_{\rm list}+\sigma+\kappa\).  If
\(\varepsilon_*<\Delta/2\), then:

1. independently sampled coordinates and local decoder outputs identify the target index
   \(s\) with failure probability at most \(\eta\) using
   \[
   R=\left\lceil
      \frac{2\log((L-1)/\eta)}{(\Delta-2\varepsilon_*)^2}
   \right\rceil
\tag{6.24.3}
\]
   samples;
2. if \(C\) has a \(q_D\)-query decoder for every message coordinate and the candidate
   words are publicly addressable with an address-scale index/scoring routine, the common
   proof supports a bounded-error relaxed decoder of locality at most \(Rq+q_D\) on radius
   \(\rho\).  Without this algorithmic assumption, item 1 is only a semantic/indexing
   channel and does not claim an efficient RLDC;
3. distinct proof words satisfy
   \(d_H(\Pi(s),\Pi(t))>\rho P\).

Thus a near-linear simultaneous coordinate-robust dPCP need not expose an index explicitly,
but it must supply a quantitative list-collapse condition of the form (6.24.2).  Ordinary
list soundness supplies only the first line; it does not supply the satisfaction defect
\(\sigma\) or the cross-coordinate collapse \(\kappa\).

#### Proof

Fix \(s\) and \(z\), and sample \(J\) uniformly.  If
\(D_J(z)\ne y^{(s)}_J\), then either the local test is unsatisfied, the satisfied output
lies outside the list symbols, or a list word producing the output symbol differs from
\(y^{(s)}\) at \(J\).  The three lines of (6.24.2) therefore give
\[
 \Pr[D_J(z)\ne y^{(s)}_J]\le\varepsilon_*.
\tag{6.24.4}
\]
For \(R\) independent samples, the true candidate has expected agreement at least
\(1-\varepsilon_*\).  Any other \(y^{(t)}\) has expected agreement at most
\(1-\Delta+\varepsilon_*\), since its word differs from \(y^{(s)}\) on at least a
\(\Delta\)-fraction of coordinates.  Hoeffding's inequality and a union bound over
the \(L-1\) wrong candidates prove (6.24.3).  After the index is recovered, run the
 \(q_D\)-query outer decoder for the desired message coordinate; this proves item 2 under
the stated address-scale scoring assumption.

For item 3, suppose \(s\ne t\) and
\(d_H(\Pi(s),\Pi(t))\le\rho P\).  Apply (6.24.4) to target \(s\) and
\(z=\Pi(t)\).  Perfect completeness for \(t\) makes the left side equal to
\(d_H(y^{(t)},y^{(s)})/M\ge\Delta>\varepsilon_*\), a contradiction.
\(\square\)

The proposition is a positive construction target rather than a black-box consequence of
current dPCP theorems.  Its role is to identify the exact upgrade needed after Theorem 6.23:
the same global proof may retain a list, but the list must have a stable target center and
small cross-coordinate disagreement.  Once that upgrade is present, the candidate-index
problem is a standard noisy-word identification problem and the common-proof RLDC barrier
applies.

### Theorem 6.25 (separated-list rigidity)

In the setting of Proposition 6.24, assume the candidate words have relative distance
\(\Delta>0\).  Fix a target \(s\), a near proof \(z\), and a list
\(\mathcal Y_z\subseteq\mathcal Y\) satisfying the last line of (6.24.2).  If
\[
 \kappa<\Delta
\tag{6.25.1}
\]
and \(\mathcal Y_z\neq\varnothing\), then
\[
 \mathcal Y_z=\{y^{(s)}\}.
\tag{6.25.2}
\]
Moreover, under the full hypotheses of Proposition 6.24, the condition
\(\varepsilon_{\rm list}+\sigma+\kappa<\Delta/2\) itself forces
\(\mathcal Y_z\neq\varnothing\).  Hence the list-collapse route of Proposition 6.24 is
not a genuine multiword-list escape: below the separation threshold it is exactly a
singleton target-binding theorem.

#### Proof

If \(y\in\mathcal Y_z\) differs from \(y^{(s)}\), the set
\(\{j:y_j\ne y^{(s)}_j\}\) has relative size at least \(\Delta\).  It is contained in
\[
 \{j:\exists y'\in\mathcal Y_z,\ y'_j\ne y^{(s)}_j\},
\]
contradicting (6.25.1).  Therefore every word in a nonempty list equals \(y^{(s)}\),
which proves (6.25.2).

If \(\mathcal Y_z=\varnothing\), the first line of (6.24.2) becomes
\(\Pr[S_J(z)=1]\le\varepsilon_{\rm list}\), while the second line gives
\(\Pr[S_J(z)=0]\le\sigma\).  Their sum is at least one, so
\(1\le\varepsilon_{\rm list}+\sigma\).  This contradicts
\(\varepsilon_{\rm list}+\sigma+\kappa<\Delta/2\le1/2\).  Thus the list is nonempty,
and the first part applies. \(\square\)

The theorem identifies the exact missing positive mechanism in the standard dPCP route:
one must prove target inclusion and singleton stability on every relevant near proof, or
work above the \(\Delta\)-scale and accept the corresponding RLDC/list-index cost.  A
common unlabelled list, even when it is shared across all coordinates, is not enough.

### Theorem 6.26 (singleton-or-index-entropy Closure Gate)

Retaining a non-singleton candidate list does not make target binding free.  In the setting
of Proposition 6.24, let \(S\) be uniform on \([L]\), let the sampled coordinates
\(J_1,\ldots,J_R\) be independent of \(S\), and let the local outputs
\(\widehat Y_t\in\Gamma\cup\{\bot\}\) be obtained from the common proof at those
coordinates.  Suppose a target-independent procedure whose only target-dependent input is
the sampled transcript \(W=((J_t,\widehat Y_t))_{t\le R}\) outputs a list
\(B\subseteq[L]\) of size at most \(\lambda\) and
\[
 \Pr[S\notin B]\le\eta<1.
\tag{6.26.1}
\]
Then
\[
 R\log_2(A+1)
 \ge
 (1-\eta)\log_2(L/\lambda)-h_2(\eta).
\tag{6.26.2}
\]
If each sampled output costs \(q\) proof queries, the sample-only index channel therefore
costs
\[
 Rq\ge
 \frac{q\bigl((1-\eta)\log_2(L/\lambda)-h_2(\eta)\bigr)}
      {\log_2(A+1)}.
\tag{6.26.3}
\]

Together with Theorem 6.25 this gives a sharp two-way gate.  If
\(\kappa<\Delta\), every nonempty list is the target singleton.  If a construction keeps a
genuinely multiword list and resolves its target index only from sampled common-proof
symbols, it must pay (6.26.2).  For \(L=2^{\Theta(K)}\), bounded \(\lambda\), and
polylogarithmic \(A\), this is \(\Omega(K/\log A)\) samples.  Avoiding both costs requires
a robust outer decoder or a joint target-binding relation that is not sample-only.

#### Proof

Let \(W=((J_t,\widehat Y_t))_{t\le R}\).  Since the coordinates are public and independent
of \(S\), and each \(\widehat Y_t\) has at most \(A+1\) values,
\[
 I(S;W)\le R\log_2(A+1).
\]
The output list \(B\) is a function of \(W\), so \(I(S;B)\le I(S;W)\).  The list form of
Fano's inequality under (6.26.1) gives
\[
 I(S;B)\ge (1-\eta)\log_2(L/\lambda)-h_2(\eta),
\]
which proves (6.26.2) and hence (6.26.3). \(\square\)

This gate is deliberately limited to target-independent sample-only recovery.  It does not
rule out an interactive global relation, a target-normalized outer decoder, or a compact
joint seed; those mechanisms must be analyzed separately rather than counted as ordinary
list soundness.

### Theorem 6.27 (descriptor--transcript index-entropy Closure Gate)

The compact-seed escape can be charged together with the sampled transcript.  In the
setting of Theorem 6.26, let \(S\) be uniform on \([L]\), let \(D\) be any
target-dependent descriptor, and let
\[
  W=((J_t,\widehat Y_t))_{t\le R},
  \qquad \widehat Y_t\in\Gamma\cup\{\bot\}.
\]
The procedure may use independent target-free randomness, and may output a list
\(B\subseteq[L]\) of size at most \(\lambda\) from \((D,W)\).  Assume
\[
  \Pr[S\notin B]\le\eta<1.
\tag{6.27.1}
\]
Then the following general information bound holds:
\[
  I_2(S;D)+I_2(S;J_1,\ldots,J_R\mid D)
  +R\log_2(A+1)
  \ge
  (1-\eta)\log_2(L/\lambda)-h_2(\eta).
\tag{6.27.2}
\]
In particular, if the sampled coordinates are independent of \((S,D)\), and \(D\) is a
\(d\)-bit descriptor, then
\[
  d+R\log_2(A+1)
  \ge
  (1-\eta)\log_2(L/\lambda)-h_2(\eta).
\tag{6.27.3}
\]

Thus a multiword list cannot hide its target index simultaneously in a descriptor carrying
little mutual information,
an address schedule, and a short common-proof transcript.  For
\(L=2^{\Theta(K)}\), bounded \(\lambda\), and polylogarithmic \(A\), any route with
\(I_2(S;D)=o(K)\), \(I_2(S;J_1,\ldots,J_R\mid D)=o(K)\), and \(R=o(K/\log A)\) is
impossible.  Combined with Theorem 6.25, the remaining positive mechanisms are restricted
to singleton target binding or a genuinely joint relation that is not representable by a
finite descriptor plus sampled local symbols.

#### Proof

Let \(J=(J_1,\ldots,J_R)\) and \(Y=(\widehat Y_1,\ldots,\widehat Y_R)\).  Independent
target-free randomness can be included in the decoder without changing mutual information.
Since \(B\) is computed from \((D,J,Y)\),
\[
  I_2(S;B)\le I_2(S;D,J,Y).
\]
The chain rule and the alphabet bound on \(Y\) give
\[
\begin{aligned}
 I_2(S;D,J,Y)
 &= I_2(S;D)+I_2(S;J\mid D)+I_2(S;Y\mid D,J)\\
 &\le I_2(S;D)+I_2(S;J\mid D)+R\log_2(A+1).
\end{aligned}
\]
On the other hand, list-Fano under (6.27.1) yields
\[
  I_2(S;B)\ge
  (1-\eta)\log_2(L/\lambda)-h_2(\eta).
\]
Combining the two inequalities proves (6.27.2); (6.27.3) follows from the independence
assumption and \(I_2(S;D)\le H_2(D)\le d\) for a \(d\)-bit descriptor. \(\square\)

This theorem is deliberately an information/quantifier closure, not an impossibility
statement for arbitrary interactive protocols.  A target-normalized outer decoder or a
joint global proof relation can evade (6.27.2) only by supplying information outside the
finite descriptor--address--sample interface explicitly charged here.

### Proposition 6.28 (GMWZ Lemma 4.2 has a partition-incidence flip gate)

There is a source-specific refinement of Proposition 6.17 for the PCPP-to-udPCP
construction in GMWZ Lemma 4.2. Let \(E_0\) be the original \(k\)-uniform PCPP
hypergraph, let \(E_{0,t}\) be its equal partition into \(n\) parts, and define
\[
  \lambda_t=\Pr_{e\sim E_0}[t\in e],
  \qquad
  a_t=\Pr_{e\sim E_{0,t}}[t\in e].
\]
Apply the construction to the binary singleton language \(\{0^n\}\). If the
resulting udPCP is claimed to have
\[
  \left(\eta,\frac{\rho\eta}{2(k+1)}\right)
\]
unique-decoding soundness, then every coordinate satisfies
\[
  \eta\ge
  \min\left\{\frac{2(\lambda_t+a_t/n)}{\rho},\frac{1-a_t}{n}\right\}.
\tag{6.28.1}
\]

Indeed, change only the right label at \(t\) in a satisfying assignment. Keep each
left label equal to the satisfying assignment on its original hyperedge, and use
the changed value only on the extra \(s\)-component when \(s\notin e\). When
\(s=t\in e\), the map has no independent second \(t\)-value, but the repeated
extra agreement slot still fails. Thus the base slots contribute \(\lambda_t\) and
the repeated self-incidence slot contributes \(a_t/n\), giving exact defect
\((\lambda_t+a_t/n)/(k+1)\). The decoder for coordinate
\(t\) outputs the wrong bit on exactly the fraction \(1-a_t\) of its partition
\(E_{0,t}\), while all other coordinates remain correct; the global decoding error
against the unique legal word is \((1-a_t)/n\). If \(\eta\) is smaller than both
terms in (6.28.1), this assignment lies within the soundness promise but violates
the conclusion.

Thus a shrinking-\(\eta=o(1/n)\) version of this exact GMWZ route must satisfy the
structural orientation condition \(1-a_t\le n\eta\) on every coordinate with
\(\lambda_t+a_t/n>\rho\eta/2\). A balanced partition with
\(\lambda_t=\Theta(k/n)\) and \(a_t=O(k/n)\) recovers the \(\Omega(1/n)\) tax by an
explicit near-satisfying assignment, rather than only by an average-to-worst-case
conversion. The statement is conditional on the incidence pair
\((\lambda_t,a_t)\); it is not an impossibility theorem for arbitrary udPCPs, since
the published partition can in principle have \(a_t=1\).

A useful deterministic corollary is obtained when a fraction
\[
  \mu=\Pr_{e\sim E_0}[e\cap[n]=\varnothing]
\]
of the original PCPP hyperedges are proof-only. Since every edge is assigned to
exactly one \(E_{0,t}\),
\[
  \frac1n\sum_t(1-a_t)\ge\mu.
\]
Thus, if every input coordinate has \(\lambda_t\ge\lambda_0/n\), some coordinate
satisfies
\[
  \eta\ge\frac1n\min\left\{\frac{2\lambda_0}{\rho},\mu\right\}.
\tag{6.28.2}
\]
This removes any random-partition assumption, while keeping the explicit
proof-only-edge condition.

See [the source-specific proof](../../mcsp-hardness-magnification/notes/322-gmwz-lemma42-partition-incidence-coordinate-flip-2026-08-18.md)
for the exact assignment and the scope boundary.

### Proposition 6.29 (the GMWZ regularization layer preserves the flip attack)

The incidence attack in Proposition 6.28 is not removed by the edge-repetition,
left-copying, right-expander, and final matching operations in the proof of GMWZ
Lemma 4.5 (before the separate Section 5 HDX routing).  Transporting the flipped
assignment through those operations gives a near assignment with
\[
  \varepsilon_t^{\mathrm{reg}}
  \le
  \frac{2\lambda_t+(1+a_t)/n}{2(k+1)},
  \qquad
  \varepsilon_t^{\mathrm{dec}}=\frac{1-a_t}{n}.
\tag{6.29.1}
\]
The first term is the base-graph defect; the second possible contribution comes
from matching edges whose right endpoint carries the flipped \(t\)-label. Counting
the repeated slot, that right-degree fraction is at most
\((\lambda_t+1/n)/(k+1)\). The
matching \(\Sigma_0\)-symbols are set equal to the matched left decoder outputs, so
the added equality checks themselves pass.

Hence every claimed final soundness pair \((\eta,\varepsilon)\) must satisfy
\[
  \eta<\frac{1-a_t}{n}
  \quad\Longrightarrow\quad
  \varepsilon<
  \frac{2\lambda_t+(1+a_t)/n}{2(k+1)}.
\tag{6.29.2}
\]
The stated GMWZ Lemma 4.5 bound \(\varepsilon=\Theta(\eta^5)\) can satisfy this by
shrinking the rejection threshold; therefore Proposition 6.29 is a persistence and
parameter-accounting theorem, not an impossibility result for the full GMWZ family.
It establishes that regularization does not create coordinate robustness for free:
it preserves the same incidence attack and pays for it through a vanishing soundness
parameter.

The detailed degree count and assignment are in [note 322](../../mcsp-hardness-magnification/notes/322-gmwz-lemma42-partition-incidence-coordinate-flip-2026-08-18.md).

### Theorem 6.30 (partition-and-agreement coordinate-flip barrier)

The preceding attack is not tied to the particular PCPP supplied by GMWZ. It is a
generic obstruction for the whole partition-and-agreement compiler class. Let \(I=[n]\)
be the input coordinates and let \(E\) be a multiset of ordered \(k\)-tuples over a right
vertex set \(V\supseteq I\). For every \(t\in I\), let \(E_t\) be a part of a partition of
\(E\), and let \(\nu_t\) be the decoding distribution on \(E_t\). A compiled verifier has
one left symbol \(F_{e,s}\) for each \((e,s)\), whose entries on \(e\) satisfy the original
constraint on \(e\), together with an extra \(s\)-entry when \(s\notin e\). If \(s\in e\),
there is no independent second \(s\)-value, but the graph still contains the corresponding
repeated agreement slot. Every one of the \(k+1\) ordered slots is checked with multiplicity,
and the decoder for coordinate \(s\) reads \(F_{e,s}(s)\).

Assume that the zero word is a perfectly decoded word, that its right assignment is \(A_0\),
and that for a fixed coordinate \(t\) the right alphabet contains a symbol \(1_t\ne A_0(t)\).
Assume also the following free-extra-slot property: whenever \(t\) does not occur in \(e\),
the left alphabet for the particular vertex \((e,t)\) permits changing only its extra
\(t\)-entry to \(1_t\), while retaining the restriction \(A_0|_e\). Let

\[
  b_t(e):=\#\{j:v_j=t\},\qquad
  \lambda_t:=\mathbb E_{(e,s)}[b_t(e)],
  \qquad
  \gamma_t:=\Pr_{(e,s)}[s=t\land b_t(e)\ge1],
  \qquad
  a_t:=\Pr_{e\sim\nu_t}[b_t(e)\ge1],
\]

where the expectation is over the compiled left-vertex distribution and
\(e=(v_1,\ldots,v_k)\). Let \(\omega_t\) be the probability with which the global
decoding distribution selects coordinate \(t\) (uniform decoding means \(\omega_t=1/n\)).
Then the compiler admits an assignment \(\widetilde A_t\) with exact constraint defect

\[
  \operatorname{def}(\widetilde A_t)=\frac{\lambda_t+\gamma_t}{k+1},
  \qquad
  \operatorname{err}_{0^n}(\widetilde A_t)=\omega_t(1-a_t).
  \tag{6.30.1}
\]

Consequently every \((\eta,\varepsilon)\)-unique-decoding guarantee for the singleton
language \(\{0^n\}\) must obey, for every \(t\),

\[
  \varepsilon\ge\frac{\lambda_t+\gamma_t}{k+1}
  \quad\Longrightarrow\quad
  \eta\ge\omega_t(1-a_t).
  \tag{6.30.2}
\]

Equivalently, if \(\eta<\omega_t(1-a_t)\), then the rejection threshold must satisfy
\(\varepsilon<(\lambda_t+\gamma_t)/(k+1)\). In the GMWZ normalization
\(\varepsilon=\rho\eta/(2(k+1))\), this gives

\[
  \eta\ge\min\!\left\{\frac{2(\lambda_t+\gamma_t)}{\rho},\ \omega_t(1-a_t)\right\}.
  \tag{6.30.3}
\]

#### Proof

Start from the satisfying right assignment \(A_0\). Change only the right label at \(t\)
to \(1_t\). For every left vertex \((e,s)\), keep all entries on \(e\) equal to
\(A_0|_e\). If \(t\notin e\), use the changed value only in the extra slot when \(s=t\),
and use \(A_0(s)\) in every other extra slot. If \(t\in e\), the repeated slot uses
the same available value \(A_0(s)\). The free-extra-slot hypothesis keeps every left
symbol in its alphabet.

The failed base slots are exactly the occurrences of \(t\) in the ordered tuple. In
addition, when \(s=t\in e\), the repeated extra slot fails because its only available
value is the unchanged \(A_0(t)\). Since there are \(k+1\) equally weighted slots per
left vertex, the defect is the first quantity in (6.30.1). Under
\(\nu_t\), the decoder reads \(1_t\) precisely when \(t\notin e\); every other decoded
coordinate remains the zero symbol. The second quantity in (6.30.1) follows. If the
defect is within the claimed rejection threshold but the decoding error exceeds \(\eta\),
unique-decoding soundness is violated, proving (6.30.2). Substituting the GMWZ threshold
gives (6.30.3). \(\square\)

The theorem isolates the exact escape for this entire compiler class. A near-linear
coordinate-robust upgrade with \(\omega_t=\Theta(1/n)\) must either make \(a_t=1-o(n\eta)\)
on every coordinate whose \(\lambda_t+\gamma_t\) is above the rejection scale, or abandon the
free-extra-slot/target-independent agreement architecture. Thus changing the PCPP,
regularizing degrees, or repeating agreement edges cannot remove the barrier by itself;
one needs a target-normalized relation, a different decoding distribution, or a genuinely
joint proof constraint. Proposition 6.28 is the GMWZ instantiation of this theorem, while
Theorem 6.30 applies before any source-specific PCPP or HDX calculation.

### Proposition 6.31 (ACRR does not black-box to the C--L--M structured PCPP)

The Cheng--Li--Mao Theorem 7.1 lower bound has a stronger soundness quantifier than the
common-proof ACRR interface.  Its 3-query PCPP requires an explicit language
\(L=\operatorname{SAT}(\varphi)\), exact uniform marginals on three query classes
\(X,A,B\), and, for every input \(w\) at distance at least \(\eta\) from \(L\),

\[
 \forall T:X\cup A\cup B\to\Sigma,qquad
 \Pr_{(t,a,b)}[\Phi_{t,a,b}(T(t),T(a),T(b))=1]
 \le |\Sigma|^{-3}/16 .
\tag{6.31.1}
\]

By contrast, the standard ACRR hypothesis only states, for a target \(m\),

\[
 p_{i,m_i}(\Pi(m))=1,qquad
 \forall z\in B_\rho(\Pi(m)):
 p_{i,1-m_i}(z)\le\beta .
\tag{6.31.2}
\]

Equation (6.31.2) leaves all off-promise assignments unconstrained and therefore does
not imply the far-input/all-proof statement (6.31.1).  It also does not supply the
three uniform marginals, the \(|\Sigma|^{-3}/16\) soundness scale, or a uniform
hidden-witness projection
\(\widehat\varphi_x(y)\leftrightarrow\exists w\,R(x,y,w)\).

Consequently, a common-proof ACRR can invoke Theorem 7.1 only after a separate
**CLM-lift theorem** proves these four properties (and preserves 3 queries).  Under
that additional lift the source lower bound gives
\(\ell\ge N^2/\operatorname{polylog}N\); without it, “ACRR \(\Rightarrow\) structured
PCPP” is a quantifier substitution, not a theorem.  This is a route boundary, not an
impossibility result for future relation-PCPP constructions or a \(P\ne NP\) theorem.

The full quantifier audit and conditional bridge are recorded in [note 369](../../../mcsp-hardness-magnification/notes/369-acrr-to-clm-structured-pcpp-quantifier-separation-2026-08-18.md).

### Proposition 6.32 (RW Reconf prefix-advice and selected-response quantifier gate)

Published RW Theorem 4.1 has a sharper failure-branch normal form than an arbitrary
per-coordinate reconstruction. Let
\[
  r'=O(r\log(t+1)),\qquad k'=O(k^4\log(t+2)),
\]
and let \(\tau_x\) be the length-\(r'\) prefix of the canonical PCP proof \(\Pi_x\).
The prefix rounds of \(\operatorname{Reconf}(x,i)\) are independent of \(i\), and on
the failure branch they all recover the same \(\tau_x\). The address enters only the
last query, so
\[
 f(x)_i=1
 \quad\Longleftrightarrow\quad
 q_{x,\tau_x,i}\text{ is a smart prMA YES instance}.
\tag{6.32.1}
\]
The query generator and verifier still have description size
\(\operatorname{poly}(k,r,\log(t+2))\), and the Merlin circuit witness may have size
\(k'\).

Consequently, under any fixed-format \(P=NP\) (or fixed PH-collapse) determinizer for
these smart queries at total input length
\(L=\operatorname{poly}(k,r,\log(t+2))\), the whole word has the conditional
prefix-advice evaluator
\[
  f(x)_i=\mathcal D(\operatorname{enc}(x,\tau_x,i)),
  \qquad
  \operatorname{CC}(f(x))=O(L^{O(1)}).
\tag{6.32.2}
\]
This is a common-prefix statement, not a common-witness theorem: the accepted Merlin
circuit in the final query may still depend on \(i\).
More precisely, the source supplies a common canonical circuit as one completeness
witness for every YES coordinate, but the query semantics are only
\[
 f(x)_i=1\Rightarrow\exists C\;[\Pr_R V_{x,\tau_x,i}(C;R)=1],
 \qquad
 f(x)_i=0\Rightarrow\forall C\;[\Pr_R V_{x,\tau_x,i}(C;R)\le\tfrac12].
\]
Thus “common canonical completeness witness” does not imply a common selected response
strategy. The finite common-response/ROM payment in Proposition 1.10 and
[note 231](../../../mcsp-hardness-magnification/notes/231-rw-final-query-common-strategy-lower-bound-2026-08-17.md)
requires this extra binding; the quantifier gap is analyzed in
[note 365](../../../mcsp-hardness-magnification/notes/365-rw-reconf-common-witness-quantifier-gap-2026-08-18.md).

At the stable RW stage \(T_i=k=n_i^C\), \(r_i=O(n_i)\), and the forced table has
address length \(\ell_i=\Theta(\log n_i)\). Hence
\[
  |\tau_i|=O(n_i\log n_i),\qquad
  k'_i=O(n_i^{4C}\log n_i),
\]
so (6.32.2) remains object-scale rather than address-scale. A successful Closure
attachment must therefore either give a succinct prefix/last-query accessor, produce
a single-valued address-scale PH surface without materializing \(\tau_i\), or prove an
object-scale payment for this state. The source-level factorization alone does not
prove \(P\ne NP\).

The exact source audit and the scale calculation are recorded in
[note 370](../../../mcsp-hardness-magnification/notes/370-rw-reconf-prefix-transcript-address-factorization-2026-08-18.md).

### Proposition 6.33 (\(P=NP\) recompilation leaves a width/solver trichotomy)

The round parameter in the published RW recurrence is not itself an invariant of a
Closure attachment under the temporary assumption \(P=NP\). Let \(M\) be the
SAT-oracle machine used for a multi-output function \(f\), and fix a polynomial-time
SAT decider \(A\) supplied by \(P=NP\). Replacing every oracle call of \(M\) by \(A\)
gives a deterministic machine \(M_A\). After padding the output length to dominate its
polynomial running time, Theorem 4.1 may be instantiated with \(r=s=0\), so its
encoded-history prefix has length \(r'=0\).

This does not remove the child-width cost: the final Merlin circuit still has size
\[
  k'=O(k^4\log(T+2)),
\]
and a failed call yields only
\(\operatorname{CC}(f)=\operatorname{poly}(k,\log T)\). Hence for a forced table with
superpolynomial circuit complexity in \(\log T\), an address-scale choice
\(k=\operatorname{poly}(\log T)\) cannot enter the failure branch; it forces the
solver to return an AVOID outsider. An object-scale \(k\) preserves reconstruction but
does not give an address-scale evaluator. The remaining positive target is therefore a
semantic consequence of the solver-success branch, or a new width compression theorem,
not merely a reduction in the number of history rounds.

This conditional correction is recorded in
[note 371](../../../mcsp-hardness-magnification/notes/371-rw-deterministic-recompile-width-trichotomy-2026-08-18.md).

### Proposition 6.34 (the Solve-success branch has no parent--child binding)

The success clause of Ren--Williams Theorem 4.1 is semantically one-sided.  For

\[
 f:\{0,1\}^n\to\{0,1\}^T,
 \qquad G:\{0,1\}^k\to\{0,1\}^{2k},
\]

it certifies only that the output \(y\) of a successful
\(\operatorname{Solve}_f(x,G)\) call is outside \(\operatorname{Range}(G)\).  The theorem's
bitwise recovery of \(f(x)\) is conditional on the opposite event, namely that the call
does not output a range outsider.  No statement in the success clause supplies

\[
 f(x)_i=D(x,G,y,i),
 \qquad f(x)=\Phi_{x,G}(y),
 \quad\text{or}\quad
 \operatorname{CC}(f(x))\le \operatorname{poly}(|y|,\log T).
\tag{6.34.1}
\]

Indeed, fixing an outsider \(y_G\notin\operatorname{Range}(G)\), the success conclusion
remains true for two parent functions with different values at \(x\).  Thus the source
semantics alone cannot imply a parent evaluator or \(P/\mathrm{poly}\) membership.  This
is a logical insufficiency of the stated interface, not a claim that the concrete
implementation of \(\operatorname{Solve}_f\) is independent of \(f\).

In the RW recurrence, a successful call gives only
\[
 B_{i+1}\notin\operatorname{Range}(G_{n_{i+1}}),
\]
whereas the parent hard table is \(B_i=f_i(x_0)\) up to padding.  Even if \(P=NP\) and
an address-scale procedure generates \(B_{i+1}\), the theorem supplies no random-access
map from \(B_{i+1}\) to \(B_i\).  A Closure proof must therefore add a source-specific
parent--child binding (address map, whole-word map, or separated fingerprint) and then
pay its descriptor, cover, bottom, and scale costs.  This proposition is recorded in
[note 372](../../../mcsp-hardness-magnification/notes/372-rw-solver-success-semantic-exit-2026-08-18.md).

### Proposition 6.35 (JK success fibers impose a parent-binding cost)

The previous proposition is not merely a quantifier observation.  The actual
Jeřábek--Korten procedure has a large success fiber.  Fix
\(G:\{0,1\}^{k}\to\{0,1\}^{2k}\), write \(R=|\operatorname{Range}(G)|\), and choose a block
\[
 z\notin\operatorname{Range}(G).
\]
For every aligned table whose first block is \(z\) and whose remaining blocks lie in
\(\operatorname{Range}(G)\),
\[
 F_{\mathbf r}=z\Vert r_2\Vert\cdots\Vert r_m,\qquad
 \mathbf r\in\operatorname{Range}(G)^{m-1},\quad T=2km,
\tag{6.35.1}
\]
the first JK block is the unique block outside the range, so the procedure returns the same
pair \((\mathrm{hard},z)\) regardless of its tie-breaking rule.  Hence one success output
has a fiber of size at least \(R^{m-1}\).

If an exact parent decoder uses this output and a target-dependent descriptor
\(\sigma(\mathbf r)\),
\[
 E(G,z,\sigma(\mathbf r),a)=F_{\mathbf r}[a]\qquad
 \text{for every }\mathbf r,a,
\tag{6.35.2}
\]
then \(\mathbf r\mapsto\sigma(\mathbf r)\) is injective and
\[
 |\sigma|\ge (m-1)\log_2R.
\tag{6.35.3}
\]
For the full-rank embedding \(G(x)=x\Vert0^k\), this is \(T/2-k\) bits.  Moreover, the standard circuit-counting bound
\(N_{\le s}(T)\le 2^{C s\log(T+s)}\) shows that whenever
\(C s\log(T+s)<(m-1)\log_2R\), the same fiber contains a parent table of circuit complexity
greater than \(s\).  Thus a short JK outsider cannot generically be treated as a
near-linear-hard parent accessor.

This is a black-box boundary, not an impossibility theorem for the actual RW canonical
proof family: Theorem 4.1 feeds JK a structured PCP proof \(\Pi_x\), and that family might
exclude the first-block fiber.  Any successful Closure attachment must prove that
additional exclusion or supply a parent-binding trace/key; the latter costs
object-scale information on the generic fiber.  The result is recorded in
[note 373](../../../mcsp-hardness-magnification/notes/373-jk-success-fiber-parent-binding-cost-2026-08-18.md).

Theorem 3.5 does not itself provide that exclusion.  Its completeness statement constrains
the systematic Reed--Muller witness part \(\widetilde w\), while the auxiliary proof
\(\Pi'\) has no range-coverage condition.  Thus even an \(r=0\) output prefix does not
control the later JK blocks.  A RW-specific Closure attachment must add first-block
coverage, a uniformly executable structured-suffix descriptor, or an explicit
target-binding tie-break; none follows from systematicity alone.

### Proposition 6.36 (first-block entropy is a coverage gate)

Let \(M\) index a family of canonical proofs \(\Pi_M\), and write
\(Z=\operatorname{pref}_{2k}(\Pi_M)\).  For a fixed
\(G:\{0,1\}^{k}\to\{0,1\}^{2k}\), its range has size at most \(2^k\).  If
\(H_\infty(Z)\ge h\), then
\[
 \Pr[Z\in\operatorname{Range}(G)]\le 2^{k-h}.
\tag{6.36.1}
\]
Thus a high-entropy proof family cannot be put entirely into one \(k\)-bit decoder range.
On the uncovered targets, JK enters its success branch at the first non-range block, so
the failure/Reconf whole-word guarantee is unavailable.

If \(M\) is uniform on \(2^H\) injective targets and a descriptor \(S\), together with
the observed first block \(Z\), exactly recovers \(M\), then
\[
 H(S)\ge H(M\mid Z)\ge H-2k.
\tag{6.36.2}
\]
If all targets are covered, \(Z\) takes values in a set of size at most \(2^k\), improving
the last term to \(H-k\).  Consequently an address-scale simultaneous attachment must
either compress the canonical first-block entropy to \(k\) bits or pay a
message-scale descriptor; published RW's \(k_i=n_{i+1}\gg n_i\) does not trigger this
gate, whereas \(k_i=\operatorname{poly}(\log T_i)\) does whenever the first-block family
has entropy larger than \(k_i\).

This is a family-level information gate, not an impossibility theorem for a single
hardwired target or a proof of \(P\ne NP\).  It is recorded in
[note 374](../../../mcsp-hardness-magnification/notes/374-rw-first-block-entropy-coverage-gate-2026-08-18.md).

### Published RW specialization (C375)

The gate is not automatically instantiated by the published RW recurrence.  In Theorem 4.3,
stage \(i\) fixes \(x_0=0^{n_0}\), defines \(f_i(x)=B_i0^{T_i-2n_i}\) independently of \(x\),
and calls only
\(\mathrm{Solve}_{f_i}(x_0,G_{n_{i+1}})\).  Thus the actual call has one target and one
canonical proof; for its induced target distribution,
\[
H_\infty\!\left(\operatorname{pref}_{2n_{i+1}}(\Pi_{x_0})\right)=0.
\]
If one artificially varies \(x\), Theorem 3.5 still constrains only the systematic witness
part \(\widetilde w_x\); it gives no cross-\(x\) coverage or canonical selector for the auxiliary
proof \(\Pi'_x\).  Hence “\(f_i\) ignores its input” proves neither that the full proof family is
identical nor that (6.36.1) has a nontrivial \(h_i\) on the published source.  The exact source
boundary is recorded in [C375](../../../mcsp-hardness-magnification/notes/375-published-rw-recurrence-singleton-target-zero-entropy-2026-08-18.md).

## 7. Scope and non-claims

Theorem 6.5 does not apply automatically to a single target, zero-radius robustness, ordinary
average/list soundness, unbounded response policies, or a construction whose proof space changes
with the coordinate. Theorem 6.6 handles unbounded policy objects only under its stronger
supportwise posterior quantifier. Theorem 6.7 additionally requires the explicit Markov and
conditional-independence hypotheses stated above, while Theorem 6.8 requires the supportwise
common-policy hypothesis and perfect correct-branch completeness. None of these theorems proves a
general dPCP impossibility theorem or proves \(P\ne NP\). Those distinctions are part of the
result: they state exactly where the coding obstruction stops.

## References

- Ren and Williams, “A Near-Optimal Lower Bound for the Circuit Complexity of
  \(\mathrm{MCSP}\),” ECCC TR26-118, Theorems 4.1, 4.3, and 4.5:
  <https://eccc.weizmann.ac.il/report/2026/118/>.
- Dinur, Harsha, and Kindler, “Distributional Soundness is Deterministic,” ECCC
  TR15-085:
  <https://eccc.weizmann.ac.il/report/2015/085/>.
- Dall’Agnol, Gur, and Lachish, TR20-154, relaxed-LDC lower bounds:
  <https://eccc.weizmann.ac.il/report/2020/154/>.
- Gur, Minzer, Weissenberg, and Zheng, 3-query RLDC/LDC constructions and lower bounds:
  <https://arxiv.org/html/2512.12960>.
- Goldberg, Gur, and Saraogi, “Nearly Tight Lower Bounds for Relaxed Locally Decodable Codes
  via Robust Daisies,” arXiv:2511.21659, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.
- Goldreich, Gur, and Komargodski, “Strong Locally Testable Codes with Relaxed Local Decoders”:
  <https://www.wisdom.weizmann.ac.il/~oded/R2/rLDCsLTC.pdf>.
- Cheng, Li, and Mao, “When Relaxation Doesn’t Help: RLDCs with Small Soundness Yield LDCs”:
  <https://arxiv.org/html/2603.03717>.
- Block, Blocki, Cheng, Grigorescu, Li, Zheng, and Zhu, “Exponential Lower Bounds for 2-query
  Relaxed Locally Decodable Codes”:
  <https://arxiv.org/html/2602.20278>.
- Arnon, Chiesa, and Yogev, “A PCP Theorem for Interactive Proofs and Applications,”
  EUROCRYPT 2022, Definition 1 and Theorem 6.1:
  <https://eprint.iacr.org/2021/915.pdf>.
- Dinur, Goldreich, and Gur, “Every Set in \(\mathcal P\) Is Strongly Testable under
  a Suitable Encoding,” ECCC TR18-050, Revision 2 (2026), Theorems 3.1--3.3:
  <https://eccc.weizmann.ac.il/report/2018/050/>.
- Reith and Vollmer, “The Complexity of Computing Optimal Assignments of Generalized
  Propositional Formulae,” arXiv:cs/9809116 (LexMax/optimal-assignment
  \(\mathsf P^{\mathsf{NP}}\) boundary):
  <https://arxiv.org/abs/cs/9809116>.
- Alrabiah, Guruswami, Kothari, and Manohar, “A Near-Cubic Lower Bound for 3-Query Locally
  Decodable Codes from Semirandom CSP Refutation”:
  <https://arxiv.org/abs/2308.15403>.
- Kerenidis and de Wolf, “Exponential Lower Bound for 2-Query Locally Decodable Codes via a
  Quantum Argument”:
  <https://eccc.weizmann.ac.il/report/2002/059/>.
- Grigorescu, Kumar, Manohar, and Mon, “Relaxed vs. Full Local Decodability with Few Queries”:
  <https://eccc.weizmann.ac.il/report/2025/208/download/>.
- Project statement: [finite-time response strategy support barrier](../../statements/strategy-support-acrr-rldc-barrier.md).
- Project theorem modules: [radius-to-relaxed-LDC barrier](../../statements/radius-to-relaxed-ldc-barrier.md)
  and [bottom-or-cubic dichotomy](../../statements/acrr-bottom-or-cubic-dichotomy.md).
