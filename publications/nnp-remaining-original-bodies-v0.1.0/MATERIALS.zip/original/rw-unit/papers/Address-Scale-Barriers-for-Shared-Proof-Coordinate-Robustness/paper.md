# Address-Scale Barriers for Shared-Proof Coordinate-Robust Reconstruction

## Abstract

We study a proof-system interface motivated by the Ren--Williams and
Jeřábek--Korten reconstruction frameworks. A single global proof is required to support
every output coordinate and both claimed values in one common address space. The verifier
must be complete for the correct claim and must reject a wrong claim on every proof lying in
a fixed-radius neighborhood of the target proof. We call this interface target-relative
coordinate-robust reconstruction.

Our main theorem is a compiler from this interface to a relaxed locally decodable code. The
compiler is elementary, but its quantifiers are decisive: completeness and soundness are
combined across different messages to force distance in the proof map, and the proof map
itself is already a relaxed code: the decoder can threshold the two claim branches directly
without exposing the payload. The resulting relaxed decoder is adaptive, nonlinear, and does
not require projection verifiers. Consequently,
for fixed finite proof alphabet, constant locality, a constant target-relative radius, and a
constant completeness/soundness gap, every family-level construction inherits the known
polynomially superlinear relaxed-LDC length lower bound. In the binary one-query case it
also inherits the known exponential lower bound for two-query relaxed LDCs when completeness
is perfect.
The same compiler is q-ary: for a finite output alphabet, checking all claims gives an
explicit \(|\Gamma|\)-dependent locality bound, while finite adaptive policy families can be
charged by their common union support rather than by their cardinality.

The compiler also has a support-sensitive extension: a finite but arbitrarily large family of
post-coordinate response objects is harmless whenever all of its adaptive query trees lie in
a small common branch support. The resulting relaxed-code locality is the size of that union,
not the number of response objects. An unbounded-response escape must therefore either expose
a wide portion of the proof or leave the finite-response/target-relative model.

The central finite-view Closure Theorem packages this reduction at the level of a prospective
simultaneous dPCP. If one common proof over an alphabet \(\Sigma_k\) supports \(q_k\) proof
queries, \(r_k\) public bits and \(m_k\) visible response bits per claim, with target-relative
soundness for every response policy, then a near-linear proof \(N_k\le k(\log k)^c\) must
satisfy the joint envelope

\[
\log |\Sigma_k|\ge k/2
\quad\text{or}\quad
Q_k\bigl(\log\log(k+2)+\log(Q_k+2)+\log(\log(|\Sigma_k|+2)+2)\bigr)
 =\Omega(\log k),
\]

where \(Q_k=1+2q_k2^{r_k+m_k}|\Sigma_k|^{q_k}\). Thus a genuinely near-linear,
finite-view, one-proof coordinate-robust construction must either expose a growing visible
view or carry message-scale alphabet information. This is a barrier theorem, not an
achievability claim: it leaves open precisely the high-value question of whether a
distributionally sound, globally word-consistent construction can evade the envelope through
an unbounded or address-dependent coupling.

In the low-soundness nonadaptive regime, the relaxation disappears altogether. A two-branch
decoder first gives a relaxed code with imperfect completeness; the recent
Cheng--Li--Mao low-soundness theorem then converts it to an ordinary LDC. Thus the
bottom escape is only a genuine parameter window at ordinary (constant) soundness, not at
the exponentially small error threshold required by that theorem.

For a sharp restricted benchmark, we also isolate a linear two-query barrier. In the binary
linear proof-map model, the message-inline reduction leaves only three adaptive queries, so
the recent equivalence between linear three-query RLDCs and LDCs forces a cubic (up to
polylogarithmic factors) proof length. This is not a general ACRR impossibility, but it gives
an explicit top-tier escape test for the most algebraically structured two-query route.
More generally, if the same two-query interface has a constant lower bound on the total
acceptance mass of both claims throughout a half-radius neighborhood, a one-shot decoder
removes relaxation and reaches the general three-query LDC lower bound even for nonlinear proof
maps. Thus any nonlinear near-linear escape must make simultaneous rejection of both claims a
genuine structural feature.
We further show that distance-proportional target-relative soundness automatically enters this
low-soundness window at a fixed smaller radius, even for adaptive verifiers with perfect
completeness.

For the current GMWZ coordinate-private architecture, we prove a complementary
fanout--locality closure theorem. If a physical proof symbol is used by at most \(d\)
source slots, the padded private blocks force \(P\ge 2Kk/d\). Thus a near-linear
replacement must use \(k/\operatorname{polylog}k\)-scale cross-coordinate fanout; if
it also retains a finite-alphabet, positive-radius shared proof, the preceding
\(\Omega(\log k/\log\log k)\) locality barrier applies. This turns the remaining
GMWZ escape into a precise global-synthesis problem rather than a padding optimization.

For the published GMWZ Section 6 gap-amplification clauses, we also prove a
source-specific spectral closure: every face-separable patch whose right label is a
common vertex word has decoder-weighted separation at most
\(\sqrt{2}\lambda_{k,1}=O(1/k)\) in the stated parameter regime. Thus this entire
vertex-word patch class cannot yield constant-error unique decoding; the remaining
GMWZ upgrade must control arbitrary right labels or a genuinely cross-coordinate
global assignment.

The fixed-locality barrier has a quantitative growing-locality boundary.  For a fixed proof
alphabet, exposing the two adaptive claim trees gives a nonadaptive query count
\(Q=1+2\sum_{j<r}A^j\).  Combining this with the arbitrary-alphabet relaxed-LDC lower bound
shows that a \(k\,\operatorname{polylog}k\)-length family cannot keep \(Q\) below the
\(\log k/\log\log k\) scale.  In the binary case, any surviving near-linear construction
must therefore enter a narrow \(\log\log k\)-locality window.
Retaining adaptivity instead of expanding the two trees gives a complementary, stronger
conditional boundary: the variable-query relaxed-DGL transfer implies that a near-linear
family must have branch depth satisfying
\(r\log(r+2)=\Omega((\log k)^{1/3})\), unless it leaves the
target-relative relaxed model or the finite-alphabet regime.

For the proposed distributional/list route, we prove a full-family dichotomy.  If a
coordinatewise list mechanism is converted to the all-policy shared-proof interface with
fewer than \(2^{k-1}\) global exceptions, the list collapses to a singleton at every
coordinate.  Inverse-linear average error then enters the relaxed-LDC barrier, so any
near-linear escape must introduce a genuinely cross-coordinate target-binding mechanism
rather than merely improve the list size or constant soundness.

We sharpen this route filter at the local-information level.  Any binder that sees only
the unlabelled multiset of candidate symbols at each coordinate, yet is complete for every
target-containing list and sound on every disjoint list, must satisfy the anti-mixing
hypothesis above.  The resulting alphabet/list-size bound is therefore a general
coordinatewise black-box impossibility, not a limitation of one chosen outer-code predicate.

As a positive counterpart, we give an indexed-list selector compiler: if one base proof
decoder returns a candidate index together with its symbol, and one globally indexed list
explains every coordinate, a selector-consistency layer converts this into simultaneous
coordinate robustness with selector-symbol proof length at most \(2P_0+k\), independent of
the list size (binary labels incur only the expected \(O(\log L)\) factor).
This identifies a sharper construction target than an explicit bank of candidate proofs.

We then isolate a positive fixed-coordinate bridge. A singleton-output distributional dPCP
with a fixed-coordinate coupling gives coordinate robustness at error \(\delta\) directly,
without the inverse-linear loss from conditioning an average bound; the ideal valid
assignment may still vary with the local random view. We also give a sharp
\(1/k\)-error phantom-word counterexample showing that ordinary average/list soundness does
not provide this coupling. The recent GMWZ dPCP parameters do not provide the coupling
uniformly, and their PCPP-to-RLDC construction uses a separate PCPP for each coordinate and
claimed bit. It therefore does not directly supply a shared relation-PCPP for a hidden
computation witness. The unresolved object is a target-output projection compiler for a relation

\[
  L_x=\{y:\exists w\ R(x,y,w)\},
\]

with one proof, one address space, and address-scale generation. A construction of this
object would be a new PCP/coding theorem. A general lower bound for it would be an independent
barrier theorem. We also quantify the remaining single-target escape: a short target descriptor
can avoid the family reduction only by carrying nearly all payload entropy, or by increasing
response complexity or abandoning the positive-radius regime.

At the full-transcript level, we identify the exact robust-ROC linear program for all
postprocessors and prove a hit--preservation complementarity: a wrong-proof mixture that
reproduces an \(\eta\)-submeasure of an honest transcript law forces
\(\operatorname{ROC}(\alpha)\ge\eta\alpha\), while simultaneous first-hit probability
\(\theta\) obeys \(\eta+\theta\le1\). A DHK-style distributional-soundness family with error
\(1/k\) can nevertheless have \(\operatorname{ROC}=1\) at a fixed coordinate. Thus the
missing construction ingredient is not transcript filtering but singleton target
concentration in one common address space.
For the GMWZ gap-amplification route, we additionally prove a black-box barrier: the heavy,
disjoint clusters and the outside-union agreement clause from Lemma 6.2 are compatible with
arbitrary cluster incidence, so they cannot by themselves yield the decoder-marginal transfer
needed for unique decoding. Any successful upgrade must use extra semantic structure of the
left assignment or change the amplification.
We make this escape quantitative without selecting a largest descriptor bucket: the descriptor,
the union of all complete-policy query supports, and the proof symbols read on that support
must jointly encode the target entropy.  This global entropy--core inequality is the
paper's general target-dependent barrier.
We also prove a randomized-descriptor strengthening: the descriptor cost is its mutual
information \(I(M;D)\), not its raw entropy \(H(D)\).  Thus public randomness independent of
the target cannot serve as a hidden target channel, even when it selects the verifier mode.
We further include the finite-strategy version: a common summary \(S\) of complete Merlin
policies is charged by \(I(M;D,S)\), so a strategy cannot hide target information for free
while keeping the honest proof support short.
Combining this with the finite view-tree bound gives a key-indexed dichotomy: a
near-linear family with high residual target entropy must either spend nearly linear
descriptor information or expose \(\Omega(\log\log k)\) finite transcript bits in the
fixed-query, fixed-alphabet DGL window.
We also close the finite selected-policy branch without assuming all-policy soundness.
Partitioning the full Boolean message cube by selected-policy vectors and applying
Sauer--Shelah produces a shattered coordinate fiber on which the policy is common.
That fiber is a genuine RLDC, so subexponentially many policy vectors inherit the
same near-linear length barrier; a finite selected-policy escape must therefore carry
linear target information.  The quantitative form is a proof-length exponent
\(N\ge k^{1+1/\lceil Q/\sigma\rceil}/\operatorname{polylog}(k)\) for every fixed
entropy deficit in the selected-policy support.  More sharply, if the selected-policy fiber is to have
sublinear VC dimension, its selected-policy vector must have Shannon entropy
\(k-o(k)\) under the uniform message distribution, even if its ambient policy
space is infinite.
We strengthen this to an explicit proof--policy tradeoff: if \(d^\star(P)\) is the
largest shattered dimension allowed by the GGS length lower bound at proof length
\(P\), then every supportwise-robust policy view satisfies
\[
 I(M;S)\ge k-\log_2\sum_{j\le d^\star(P)}\binom{k}{j}.
\]
For fixed alphabet and locality, \(P\le k\,\operatorname{polylog}k\) implies
\(d^\star(P)\le k^{1-\Omega(1)}\operatorname{polylog}k=o(k)\), hence
\(I(M;S)=k-o(k)\). This is a quantitative coding theorem, not merely an
entropy slogan. Its inverse phase diagram is also explicit: an information
budget \(I(M;S)\le\gamma k\), for any fixed \(\gamma<1\), forces

\[
 P\ge k^{1+1/\lceil Q/\sigma_0\rceil}/\operatorname{polylog}(k)
\]

with a \(\gamma\)-dependent constant. Thus policy information, proof length,
and adaptive locality form one quantitative closure surface.
For adaptive branches the same fiber argument, followed by constant-gap
amplification, yields the variable-query threshold
\(r\log(r+2)=\Omega((\log d)^{1/3})\) without expanding the decision tree.
The same fiber argument also charges randomized policy selection by the
mutual information \(I(M;S)\) whenever every policy in the selected support
is robust.
We sharpen the remaining average-policy gap as well: if, for each target, all
but an \(\varepsilon\)-fraction of the selected-policy mass is already a
policy-level simultaneous robust policy, then a mutual-information bound still
forces one large common robust fiber.  This is the exact average-to-supportwise
interface; ordinary averaged acceptance inequalities do not satisfy its
policy-level hypothesis.
We then remove even that supportwise condition at the semantic level: a small
average of the single worst-case robust defect, together with low mutual
information, is enough to replace all target-dependent policy laws by one
target-independent marginal mixture on a near-full message subfamily.  This
mixture is an RLDC whenever its law is address-scale samplable.
Finally, we give a profile-hitting and fractional-minimax certificate: any proof architecture
that realizes a sufficiently rich family of local forcing profiles must pay the corresponding
honest-query hitting mass, while average/list soundness alone does not supply those profiles.
We also identify the exact decoder-intrinsic quantity behind this phenomenon.  The pathwise
Lorenz profile of the honest query transcript is precisely the worst corruption mass that can
force an adaptive decoder off its honest path.  Consequently every common-proof decoder with
small Lorenz mass is already a relaxed locally decodable code, while a near-linear escape must
concentrate a constant fraction of its honest queries on a small heavy core.  The bound is sharp
for the profile-only information: a one-bit sampler realizes equality for every probability
profile.
In the fixed-alphabet, fixed-locality nonadaptive regime this has a sharp near-linear
consequence: if the total length is \(k\,\operatorname{polylog}k\), the same top-\(\rho N\)
positions must carry \(1-O(\log\log k/\log k)\) of all honest query mass.  Thus the remaining
escape is not a moderate heavy core but an almost-total concentration phenomenon.
For the positive field-lift route, we identify the matching outer-side quantity: the exact
wrong-projection cost is the Lorenz mass of the honest outer-query profile at the dPCP error
budget.  This refines pointwise smoothness and yields a two-profile closure test, with one
Lorenz profile on output positions and one on proof positions.
As a separate universal route filter, we prove a finite-transcript public-coin
randomness--time hierarchy barrier.  Even if the post-coordinate Merlin interaction has
arbitrarily many finite rounds, a polynomial-length transcript on each random tape can be
enumerated.  A uniform compiler for an entire \(\mathsf{NTIME}(t)\) class therefore cannot
simultaneously have short keys, polynomial evaluators, polynomial transcripts, and
\(2^{r(n)}\operatorname{poly}(n)\log\)-time below the ambient \(t(n)\) scale.

## 1. The interface

Let \(k\) be the message length, \(P\) the proof length, and

\[
  \Pi:\{0,1\}^{k}\to\{0,1\}^{P}
\]

an arbitrary global-proof map. For every coordinate \(i\in[k]\) and claim
\(b\in\{0,1\}\), let \(V_{i,b}\) be a randomized, possibly adaptive verifier that makes
at most \(q\) queries to a proof oracle. For a proof string \(z\), write

\[
  p_{i,b}(z)=\Pr[V_{i,b}^{z}\text{ accepts}].
\]

The family is \((\rho,\alpha,\beta,q)\)-coordinate robust if the following hold for
every message \(m\):

1. **Completeness.** \(p_{i,m_i}(\Pi(m))\ge\alpha\) for every \(i\).
2. **Target-relative soundness.** If
   \(\operatorname{dist}(z,\Pi(m))\le\rho P\), then
   \(p_{i,1-m_i}(z)\le\beta\) for every \(i\).

The soundness promise is deliberately target-relative. Requiring it for every proof would
make the family inconsistent: the proof \(\Pi(m')\) is a perfect-completeness witness for
one message and a wrong-bit candidate for any message that differs from \(m'\) in a chosen
coordinate.

The common proof map and the target-relative neighborhood are the two features that permit a
coding-theoretic consequence. No linearity, projection property, or nonadaptivity is assumed.

## 2. Main theorem: shared-proof reconstruction implies relaxed local decoding

### Theorem 2.1

Assume a binary family is \((\rho,\alpha,\beta,q)\)-coordinate robust, with
\(\rho>0\) and \(\alpha>\beta\). Then the proof map \(\Pi\) itself is an injective
weak adaptive relaxed locally decodable code of block length \(P\):

1. distinct proof words have relative distance strictly larger than \(\rho\);
2. for every \(\delta<\rho\), there is a decoder with
   \(O(q(\alpha-\beta)^{-2})\) queries, completeness at least \(2/3\), radius \(\delta\),
   and wrong-output probability at most \(1/3\).

#### Proof

Take distinct messages \(m\neq m'\), and choose \(i\) with \(m_i\neq m'_i\). Suppose
that \(\operatorname{dist}(\Pi(m),\Pi(m'))\le\rho P\). Apply target-relative soundness
with target \(m\) and candidate \(z=\Pi(m')\). Since \(m'_i=1-m_i\),

\[
  p_{i,m'_i}(\Pi(m'))\le\beta.
\]

Completeness for the target message \(m'\) gives

\[
  p_{i,m'_i}(\Pi(m'))\ge\alpha,
\]

which contradicts \(\alpha>\beta\). Hence distinct proof strings have distance greater
than \(\rho P\), proving the first claim.

For the decoder, on requested coordinate \(i\), independently run both
\(V_{i,0}\) and \(V_{i,1}\) for \(R=\Theta((\alpha-\beta)^{-2})\) trials. Let
\(\widehat p_{i,b}\) be the empirical acceptance rate. Output \(b\) if exactly one empirical
rate is above \((\alpha+\beta)/2\); otherwise output \(\bot\).

On \(\Pi(m)\), the correct branch has mean at least \(\alpha\), while the wrong branch has
mean at most \(\beta\), because \(\Pi(m)\) lies in its own target neighborhood. Hoeffding's
inequality gives correct output with probability at least \(2/3\) for a suitable constant
in \(R\). If \(z\) is within relative distance \(\delta<\rho\) of \(\Pi(m)\), the wrong
branch still has mean at most \(\beta\). With probability at least \(2/3\) its empirical
rate remains below the threshold, so the decoder either outputs the correct bit or
\(\bot\), never the wrong bit. The decoder makes \(2Rq\) proof queries. \(\square\)

### Theorem 2.1A (finite-alphabet coordinate robustness is q-ary relaxed decoding)

The binary theorem is not tied to binary output symbols. Let \(\Gamma\) be a message alphabet
of size \(A\ge2\), let \(\Sigma\) be a finite proof alphabet, and let
\(C:\Gamma^k\hookrightarrow\Sigma^N\) be a common proof map. For each coordinate \(i\) and
claim \(a\in\Gamma\), let \(V_{i,a}\) be a randomized adaptive verifier making at most \(q\)
proof-symbol queries. Assume correct-claim completeness at least \(\alpha\), and assume that
every wrong claim has acceptance at most \(\beta\) on every proof within relative distance
\(\rho>0\) of the target proof, with \(\alpha>\beta\). Then \(C\) is a q-ary weak relaxed
locally decodable code at every radius \(\delta<\rho\), with completeness \(1-\eta\), error
\(\eta\), and locality
\[
  Q=O\!\left(Aq\frac{\log(A/\eta)}{(\alpha-\beta)^2}\right).
\tag{2.1a}
\]
Distinct proof words have distance strictly larger than \(\rho N\).

#### Proof

Set \(\tau=(\alpha+\beta)/2\), and repeat every one of the \(A\) claim branches
\(R=\Theta((\alpha-\beta)^{-2}\log(A/\eta))\) times. Output the unique branch whose
empirical acceptance rate exceeds \(\tau\), or \(\bot\) if there is no unique such branch.
Hoeffding's inequality and a union bound show that on the target proof the correct branch is
selected with probability at least \(1-\eta\). On a proof within radius \(\delta<\rho\), every
wrong branch remains below \(\tau\) except with probability at most \(\eta\); hence the
decoder never outputs a wrong symbol except on that failure event. The query count is \(ARq\).

For distance, if \(C(m)\) and \(C(m')\) were within \(\rho N\) while \(m_i\ne m'_i\), then
soundness for target \(m\) applied to \(C(m')\) and claim \(m'_i\) would contradict
completeness for \(m'\). \(\square\)

For fixed \(A\), this is the same \(O(q)\)-locality barrier as in the binary case.  If \(A\)
grows, (2.1a) records the exact alphabet cost instead of treating a large dPCP output
alphabet as free.  The full q-ary statement, its binary recoding, and its scope boundaries
are in [Finite-alphabet coordinate robustness is q-ary relaxed local decoding](../../statements/qary-coordinate-robustness-rldc-compiler.md).

The same argument has a support-sensitive finite-policy form. For each \((i,a)\), let
\(\mathcal P_{i,a}\) be a finite policy family and define
\[
  L=\max_i\left|
    \bigcup_{a\in\Gamma}\bigcup_{\pi\in\mathcal P_{i,a}}
    \operatorname{Supp}(V_{i,a,\pi})
  \right|,
  \qquad B=\max_{i,a}|\mathcal P_{i,a}|.
\]
If one policy in the correct family is complete and every policy in every wrong family is
sound throughout the target neighborhood, reading the common support once per repetition
gives q-ary relaxed decoding with locality
\[
  O\!\left(L\frac{\log(AB/\eta)}{(\alpha-\beta)^2}\right).
\tag{2.1b}
\]
Thus finite adaptive response families are charged by their union support \(L\), not by their
cardinality, provided the all-policy target-relative quantifier is retained. The exact
finite-policy statement is included in the q-ary compiler module linked above.

### Corollary 2.2 (near-linear family barrier)

Fix a finite proof alphabet, constant \(q\), constants \(\rho>0\) and
\(\alpha-\beta>0\). Any infinite binary family satisfying the theorem has proof length

\[
  P\ge k^{1+\eta_q}
\]

for some constant \(\eta_q>0\) supplied by the constant-radius relaxed-LDC lower bound.
In particular, \(P=k\,\operatorname{polylog} k\) is impossible.

For a finite alphabet \(\Sigma\), encode each proof symbol with
\(\ell=\lceil\log_2|\Sigma|\rceil\) bits. The decoder reads all \(\ell\) bits of each
queried symbol, so its locality is

\[
  Q=O\bigl(q\ell(\alpha-\beta)^{-2}\bigr).
\]

The encoded proof has length \(N=\ell P\) and positive binary radius at least \(\rho/\ell\).
For fixed \(\Sigma\), this remains a fixed-query positive-radius relaxed-LDC family, and the
same superlinear barrier applies. In the parameterization of the current adaptive
relaxed-LDC lower bound, this gives the explicit estimate

\[
  \ell P\ge k^{1+1/O\!\left(Q^2\log^2(Q+2)\right)}.
\]

The estimate is an invocation of the external coding lower bound; the contribution here is
the proof-only, quantifier-preserving compiler from shared-proof coordinate robustness to
relaxed local decoding. Message-inline encoding is optional and only weakens the radius
accounting.

### Corollary 2.3 (hidden-witness relation-PCPP barrier)

Let \(R(u,m,w)\) be a relation with a fixed context \(u\) and an \(h\)-bit output
payload \(m\in\{0,1\}^h\). Suppose a purported relation-PCPP compiler assigns one proof
codeword \(C_u(m)\in\Sigma^N\) to every realizable payload, keeps one physical address
space for all payloads, and supplies coordinate verifiers with fixed locality, fixed
completeness/soundness gap, and a fixed positive target-relative radius. The verifier may
use arbitrary hidden witnesses \(w\), and the proof map may be nonlinear and nonprojection.
If the verifier family is payload-oblivious (or has only a bounded response that can be
enumerated), then the compiler inherits the relaxed-LDC lower bound of Corollary 2.2.

In particular, a near-linear \(N=h\,\operatorname{polylog}h\) compiler cannot simultaneously
hide an arbitrary witness while supporting a high-entropy output payload and providing this
shared-proof coordinate robustness under those fixed parameters. The obstruction is not
witness recovery: the proof-only code exposes no payload prefix, while the hidden \(w\)
remains entirely inside the proof map. A successful
near-linear construction must therefore use a payload-sized descriptor, an unbounded
coordinate-dependent strategy, a vanishing radius/gap, separate proof spaces, or a genuinely
new semantic model outside this reduction.

### Theorem 2.4 (branch-support refinement)

The finite-response escape can be sharpened without charging the number of response objects.
For each \((i,b)\), let \(\mathcal T_{i,b}\) be any finite response family, and let
\(\operatorname{Supp}(V_{i,b,\tau})\) be the union of all proof positions that the adaptive
verifier can query over all random tapes and all possible answer transcripts. Define

\[
  L=\max_i\left|
    \bigcup_{b,\tau}\operatorname{Supp}(V_{i,b,\tau})
  \right|.
\]

If one response gives completeness at least \(\alpha\) for the correct claim and every
response gives at most \(\beta\) on the wrong claim throughout the target-relative
\(\rho\)-neighborhood, then the proof map itself is a relaxed LDC of radius every
\(\delta<\rho\) and locality at most \(L\). The decoder queries the union support once,
simulates all response objects offline, and thresholds the two maxima. It also forces proof
distance \(>\rho\).

This strictly refines response enumeration: for nonadaptive branches it recovers the usual
\(O(Rq)\) bound, while for adaptive branches it charges the exact union of reachable
addresses. Hence a finite-response RW/JK candidate can evade the coding barrier only by making
its branch support large, changing the target-relative quantifier, or changing the proof
address space. The full statement and proof are in [Branch-support barrier](../../statements/strategy-support-acrr-rldc-barrier.md).

For the standard finite-round, finite-alphabet interactive Merlin interface, the same statement
applies to the set of **all** response policies. The alphabet may grow with the block length:
for each fixed length, the policy view tree is still finite, so exhaustive policy enumeration is
free in the query-locality model. Private verifier randomness is omitted from the policy view
without changing the finiteness argument. Thus an unbounded strategy description is not itself
an escape; only large all-policy branch support, target-dependent semantics, or genuinely
unbounded/continuous interaction remains outside the theorem. This is a locality statement,
not a polynomial-time or succinct-decoder claim.

Whenever the cited relaxed-LDC lower-bound window applies, a near-linear proof therefore
forces the all-policy support itself to grow. With the displayed bound
`Phi_N(L)=C|Sigma|^L log|Sigma| N^(1-theta(L)) log(k+2)` and
`theta(L)=c/(L^2 log^2(L+2))`, fixed `|Sigma|>=2` and
`N<=k polylog(k)` give the conservative threshold
`L_all^3 log^2(L_all+2)=Omega(log k)` up to the external theorem's constants, hence
`L_all=Omega((log k)^(1/3)/(log log(k+2))^(2/3))`.
The `|Sigma|^L` factor in the displayed DGL bound is essential; dropping it would
incorrectly produce a square-root threshold. The cost is geometric support, not merely a
long Merlin transcript.

Finite rounds need not be stipulated separately for the standard bit model. A verifier running
for `T_N` steps can observe only finitely many message bits, so arbitrary finite Merlin strings
and unbounded Merlin computation collapse to the same finite view-tree policy space. Only
unbounded verifier time, an infinite/continuous alphabet, or a nonstandard operation that
reveals unbounded information in one step lies outside this closure.

There is a direct transcript-entropy refinement. If, for a fixed \((i,b)\), the verifier uses
at most \(r\) random bits, asks at most \(q\) proof-symbol queries, and observes at most \(m\)
bits of Merlin's response transcript, then the union of all policy branch supports obeys

\[
  L_{i,b}^{\mathrm{all}}\le q\,2^{r+m}|\Sigma|^q.
\tag{2.4a}
\]

An all-policy execution is determined, for future addresses, by its random tape, observed
response view, and proof-symbol transcript; there are at most
\(2^r\cdot2^m\cdot|\Sigma|^q\) such transcripts, each with at most \(q\) addresses. Hence a
long response string is not an escape unless the verifier actually exposes enough transcript
entropy to widen the support. Combined with Theorem 2.4, this turns the remaining interactive
escape into an explicit entropy budget rather than an unbounded-description slogan.

More explicitly, if the same DGL window forces
\[
  L_{\mathrm{all}}\ge
  c_0\frac{(\log_2 k)^{1/3}}
  {(\log_2\log_2(k+2))^{2/3}},
\tag{2.4b}
\]
then (2.4a) implies
\[
  r+m+\log_2 q+q\log_2|\Sigma|
  \ge \frac13\log_2\log_2 k
  -\frac23\log_2\log_2\log_2(k+2)-O(1).
\tag{2.4c}
\]
For fixed \(q\) and fixed alphabet, a finite-horizon protocol therefore exposes
\(\Omega(\log\log k)\) bits of random/response transcript information before it can leave
the support barrier. This is a conditional communication lower bound, not a claim about
unrestricted dPCPs.

The same support parameter can be used inside a short-descriptor bucket: after fixing the
largest key bucket, replace the finite response count by the union support of all finite-horizon
policies in that bucket. The resulting key--support--length inequality is recorded in [Payload
lifting family barrier](../../statements/payload-lifting-family-barrier.md).

There is also a radius-free consequence for short target-specific cores. If, inside one
descriptor bucket, each target coordinate has a complete policy and wrong-declaration soundness
holds for every policy, the full branch support of those complete policies is automatically a
specifying set for the target codeword. Thus a core of size `r` pays
`h-s <= log(r+1)+r log(e N |Sigma|/r)`, even before invoking a relaxed-LDC lower bound; see
[Finite-time policy specifying-core barrier](../../statements/finite-time-policy-specifying-core-barrier.md).
Its tail bound is distributional: in a high-entropy near-linear descriptor bucket, all but an
exponentially small fraction of targets must have large complete-policy support. Combined with
the all-policy support lower bound, this yields a support--core dichotomy rather than a
single-target obstruction.
The same counting gives an average complete-policy core cost of
`Omega(k/log k)` in the high-entropy polynomial-length regime.

### Theorem 2.5 (global entropy--core barrier)

Let
\[
  C:\mathcal M\hookrightarrow\Sigma^N
\]
be a finite proof map, and let \(\kappa:\mathcal M\to\mathcal D\) be a target descriptor.
For every descriptor \(\sigma\), coordinate \(i\), and declaration \(b\), let
\(V_{\sigma,i,b,\pi}\) denote a finite-time policy using the same physical proof address
space \([N]\), and let \(\operatorname{Supp}(V_{\sigma,i,b,\pi})\) be its union of queried
positions over all random tapes and answer transcripts.
For each target \(m\) and coordinate \(i\), choose one complete policy \(\pi_{m,i}\) for
the correct declaration, and let
\[
  K_m=\bigcup_i \operatorname{Supp}(V_{\kappa(m),i,m_i,\pi_{m,i}}).
\]
Assume that the chosen policy accepts \(C(m)\) with probability at least \(\alpha\), while
every policy for a wrong declaration under the same descriptor accepts every
\(z\) with \(\operatorname{dist}(z,C(m))\le\rho\) with probability at most \(\beta<\alpha\).
Then
\[
  m\longmapsto\bigl(\kappa(m),K_m,C(m)|_{K_m}\bigr)
\]
is injective.  If \(M\) is any random target, \(D=\kappa(M)\), and \(R=|K_M|\), then
\[
  H(M)\le H(D)+N h_2(\mathbb E R/N)+\mathbb E R\log_2|\Sigma|.
  \tag{2.5}
\]

For a uniform \(2^h\)-message family and an \(s\)-bit descriptor, this gives
\[
  h-s\le N h_2(\mathbb E R/N)+\mathbb E R\log_2|\Sigma|.
  \tag{2.6}
\]
Thus fixed alphabet, \(N=k^{O(1)}\), and \(h-s=\Omega(k)\) force
\(\mathbb E|K_M|=\Omega(k/\log k)\).

#### Proof

Suppose two distinct targets \(m,m'\) have the same descriptor and the same pair
\((K_m,C(m)|_{K_m})=(K_{m'},C(m')|_{K_{m'}})\).  Choose \(i\) with
\(m_i\ne m'_i\).  The policy \(\pi_{m,i}\) only sees positions in \(K_m\), so it has the
same transcript distribution on \(C(m)\) and \(C(m')\), and therefore accepts the latter
with probability at least \(\alpha\).  Viewed under target \(m'\), this is a wrong
declaration, and \(C(m')\) lies in its own \(\rho\)-neighborhood; all-policy soundness
gives probability at most \(\beta\), a contradiction.  This proves injectivity.

The injective encoding of \(M\) by \((D,K_M,C(M)|_{K_M})\), the chain rule, and the entropy
bound for a random subset of \([N]\) give
\[
\begin{aligned}
H(M)
&\le H(D)+H(K_M)+H(C(M)|_{K_M}\mid D,K_M)\\
&\le H(D)+N h_2(\mathbb E R/N)+\mathbb E R\log_2|\Sigma|,
\end{aligned}
\]
which is (2.5).  Taking \(H(M)=h\) and \(H(D)\le s\) gives (2.6).  If
\(\mathbb E R\le N/2\), use \(h_2(u)\le u\log_2(e/u)\); if it is larger, the claimed
lower bound is immediate.  For fixed alphabet and \(N=k^{O(1)}\), the denominator is
\(O(\log k)\). \(\square\)

### Theorem 2.5A (randomized descriptors pay only for target information)

The descriptor in Theorem 2.5 may be randomized.  Let \(D\) be a discrete descriptor
sampled conditionally on the target \(M\).  For every \((m,d)\) with
\(\Pr[M=m,D=d]>0\), choose complete policies \(\pi_{m,d,i}\) under the common verifier family
\(V_{d,i,b}\), and define

\[
K_{m,d}=\bigcup_i
\operatorname{Supp}\!\left(V_{d,i,m_i,\pi_{m,d,i}}\right).
\]

Assume the same completeness and all-policy target-relative soundness as in Theorem 2.5 for
every positive-probability \((m,d)\).  If \(R=|K_{M,D}|\), then

\[
H(M)\le I(M;D)
 +N h_2\!\left(\frac{\mathbb E R}{N}\right)
 +\mathbb E R\log_2|\Sigma|.
\tag{2.5a}
\]

When \(\mathbb E R\le N/2\),

\[
H(M)-I(M;D)
\le \mathbb E R\log_2\!\left(\frac{eN|\Sigma|}{\mathbb E R}\right).
\tag{2.5b}
\]

Thus for a uniform \(k\)-bit family, fixed alphabet, \(N=k^{O(1)}\), and
\(I(M;D)\le\gamma k\) with fixed \(\gamma<1\), one has

\[
\mathbb E|K_{M,D}|=\Omega\!\left(\frac{(1-\gamma)k}{\log k}\right).
\tag{2.5c}
\]

#### Proof

For a fixed descriptor value \(d\), the map
\[
m\longmapsto\bigl(K_{m,d},C(m)|_{K_{m,d}}\bigr)
\]
is injective on the conditional support \(\{m:\Pr[M=m,D=d]>0\}\).  Otherwise the
complete policy of one target becomes a wrong-declaration policy for the other while seeing
the same proof symbols, contradicting \(\alpha>\beta\).  Hence
\[
H(M\mid D,K_{M,D},C(M)|_{K_{M,D}})=0.
\]
The chain rule gives
\[
\begin{aligned}
H(M)
&=I(M;D)+H(M\mid D)\\
&\le I(M;D)+H(K_{M,D}\mid D)
 +\mathbb E R\log_2|\Sigma|.
\end{aligned}
\]
Conditioned on \(D=d\), the core is a random subset of \([N]\), so subadditivity and the
concavity of \(h_2\) give
\[
H(K_{M,D}\mid D)
\le N h_2\!\left(\frac{\mathbb E R}{N}\right).
\]
This proves (2.5a), and (2.5b)--(2.5c) follow as in Theorem 2.5. \(\square\)

The replacement of \(H(D)\) by \(I(M;D)\) is essential: target-independent public randomness
may have arbitrarily large raw entropy, but it carries no target information and cannot
reduce the complete-policy core.  The full randomized-descriptor statement, including its
conditional-support boundary, is recorded in
[Randomized descriptors pay only for target information](../../statements/randomized-descriptor-mutual-information-core-barrier.md).

### Corollary 2.6 (short-instance relation-PCPP obstruction)

Consider a relation family \(R(x,m,w)\) with \(k\)-bit output \(m\).  Let
\(\mathcal M_n\) be a set of realizable outputs, and for each \(m\in\mathcal M_n\) choose
an instance \(x_m\) of length at most \(n\).  Suppose a relation-PCPP compiler assigns a
proof \(C(m)\in\Sigma^N\) and generates every coordinate verifier from \(x_m\), the
coordinate \(i\), and the declared bit \(b\), using one physical address space \([N]\).
Assume the hypotheses of Theorem 2.5, with the instance description as descriptor; in
particular, wrong-bit soundness holds for every policy generated from the same \(x_m\).
Then, for \(M\) uniform on \(\mathcal M_n\),
\[
  \log_2|\mathcal M_n|-n-O(\log n)
  \le
  N h_2(\mathbb E|K_M|/N)
  +\mathbb E|K_M|\log_2|\Sigma|.
  \tag{2.7}
\]
Consequently, if \(\log_2|\mathcal M_n|-n=\Omega(k)\), \(N=k^{O(1)}\), and
\(\Sigma\) is fixed, then
\[
  \mathbb E|K_M|=\Omega(k/\log k).
  \tag{2.8}
\]

This is a direct relation-PCPP barrier, not a claim about arbitrary single-target
instances.  If the verifier is also given the full target \(m\), that target information
belongs to the descriptor and the entropy difference in (2.7) correctly disappears.
Thus a high-entropy hidden-output relation cannot be compressed into a shared proof with
only a short instance descriptor and a small complete-policy core; combining (2.8) with
the branch-support/RLDC bound gives the corresponding proof-length or locality trilemma.

### Theorem 2.7 (support--core--descriptor trilemma)

In the setting of Theorem 2.5, write \(D=\kappa(M)\), \(R=|K_M|\), and let
\(L_D\) be the union of the full branch supports of all finite-time policies in the
descriptor bucket \(D\).  Suppose a valid branch-support/RLDC theorem supplies, for every
descriptor value \(\sigma\), an entropy upper bound

\[
  H(M\mid D=\sigma)\le \Phi_N(L_\sigma).
\tag{2.9}
\]

Then

\[
  H(M\mid D)
  \le
  \min\left\{
    N h_2\!\left(\frac{\mathbb E R}{N}\right)
      +\mathbb E R\log_2|\Sigma|,
    \mathbb E_{\sigma\sim D}[\Phi_N(L_\sigma)]
  \right\}.
\tag{2.10}
\]

Consequently, a family with \(H(M\mid D)\ge\eta k\) must simultaneously satisfy

\[
  \mathbb E R=\Omega(k/\log k),
  \qquad
  \mathbb E_{\sigma\sim D}[\Phi_N(L_\sigma)]\ge \eta k,
\tag{2.11}
\]

in the fixed-alphabet, \(N=k^{O(1)}\) regime.  Thus a short descriptor cannot be traded
against both a small complete-policy core and a low all-policy branch support.

#### Proof

Because \(D\) is a deterministic descriptor of \(M\),
\(H(M\mid D)=H(M)-H(D)\).  Theorem 2.5 gives the first term in (2.10) by conditioning on
\(D\) and applying Jensen's inequality to \(G_N(r)=Nh_2(r/N)+r\log_2|\Sigma|\).
The assumed branch-support theorem gives the second term after averaging
the inequality \(H(M\mid D=\sigma)\le\Phi_N(L_\sigma)\) over \(\sigma\).  Taking the minimum proves
(2.10).  If the left side is at least \(\eta k\), both terms are at least \(\eta k\); the
first yields the core estimate exactly as in Theorem 2.5, and the second is (2.11).
\(\square\)

### Theorem 2.7A (randomized support--core--descriptor trilemma)

The support--core--descriptor trilemma survives randomized descriptors with the
deterministic descriptor entropy replaced by mutual information. Let \(D\) be sampled
conditionally on \(M\), let \(R=|K_{M,D}|\), and let \(L_D\) denote the all-policy
branch-support union in the descriptor bucket. Under the common-address, conditional-support
completeness, and all-policy target-relative soundness hypotheses of Theorem 2.5A, suppose
that a valid branch-support/RLDC theorem gives
\[
  H(M\mid D=d)\le \Phi_N(L_d)
\]
for every positive-probability \(d\). Then
\[
 H(M)
 \le I(M;D)+
 \min\left\{
   G_N(\mathbb E R),
   \mathbb E_{d\sim D}[\Phi_N(L_d)]
 \right\},
 \qquad
 G_N(u)=Nh_2(u/N)+u\log_2|\Sigma|.
\tag{2.10a}
\]
Equivalently, the same minimum bounds \(H(M\mid D)\). Consequently, if
\(H(M)-I(M;D)\ge\eta k\), \(N=k^{O(1)}\), and \(\Sigma\) is fixed, then
\[
  \mathbb E R=\Omega(\eta k/\log k),
  \qquad
  \mathbb E_{d\sim D}[\Phi_N(L_d)]\ge\eta k.
\tag{2.10b}
\]

#### Proof

For each fixed \(d\), Theorem 2.5A applied to the conditional target distribution gives
\(H(M\mid D=d)\le G_N(\mathbb E[R\mid D=d])\). Averaging and using concavity of
\(G_N\) yields
\[
  H(M\mid D)\le
  \mathbb E_dG_N(\mathbb E[R\mid D=d])
  \le G_N(\mathbb E R).
\]
The assumed branch-support/RLDC inequality gives the second upper bound after averaging over
\(d\). Taking the minimum and adding \(I(M;D)\) via
\(H(M)=I(M;D)+H(M\mid D)\) proves (2.10a). The two terms on the right must each be at
least \(\eta k\); inverting \(G_N\) gives (2.10b). \(\square\)

This is the randomized-key version of the earlier trilemma. Public randomness independent of
the target may have arbitrarily large \(H(D)\), but it contributes zero to \(I(M;D)\) and
cannot remove either the complete-policy core or the all-policy support cost. The full
statement and its conditional-support boundaries are recorded in
[Randomized support--core--descriptor trilemma](../../statements/randomized-support-core-descriptor-trilemma.md).

### Theorem 2.5B (strategy-inclusive entropy--core barrier)

The descriptor can be augmented by a finite summary \(S\) of the complete Merlin policies.
Conditioned on \((D,S)=(d,s)\), require the policy for coordinate \(i\) and declaration \(b\)
to be a fixed \(\pi_{d,s,i,b}\), independent of the hidden target. Define \(K_{m,d,s}\) as
the union of the proof positions queried by the selected complete policies over all
coordinates. If every selected policy is complete with probability at least \(\alpha\), and
every policy for a wrong declaration is at most \(\beta<\alpha\) on the target's
\(\rho\)-neighborhood, then
\[
 H(M)\le I(M;D,S)
   +N h_2\!\left(\frac{\mathbb E|K_{M,D,S}|}{N}\right)
   +\mathbb E|K_{M,D,S}|\log_2|\Sigma|.
\tag{2.5d}
\]
For a uniform \(k\)-bit family with fixed alphabet and \(N=k^{O(1)}\), any
\(I(M;D,S)\le\gamma k\), \(\gamma<1\), forces
\[
 \mathbb E|K_{M,D,S}|=\Omega((1-\gamma)k/\log k).
\tag{2.5e}
\]

#### Proof

Fix \((d,s)\). If two targets in its conditional support have the same core and the same
proof restriction on that core, choose a coordinate on which they differ. The complete
policy for the first target is the same fixed policy \(\pi_{d,s,i,m_i}\) on both proofs,
because the core contains its full support. Completeness makes it accept the second proof
with probability at least \(\alpha\), while all-policy soundness for the second target makes
the same wrong declaration accept with probability at most \(\beta\), a contradiction.
Thus the target is determined by \((D,S,K,C(M)|_K)\). The chain rule, the entropy bound for a
random subset of \([N]\), and the \(|K|\)-symbol restriction bound give (2.5d); inversion
under \(N=k^{O(1)}\) gives (2.5e). \(\square\)

This is the finite-strategy extension of Theorem 2.5A. It directly closes the common
strategy-summary hidden-advice escape, but it does not cover a genuinely unbounded
strategy with no finite summary. The self-contained statement and all quantifier boundaries
are recorded in [strategy-inclusive entropy--core barrier](../../statements/strategy-inclusive-entropy-core-barrier.md).

### Transcript-entropy refinement of Theorem 2.7

For descriptor bucket \(\sigma\), suppose the finite-time verifier uses at most
\(r_\sigma\) random bits, observes at most \(m_\sigma\) Merlin transcript bits, and makes
at most \(q_\sigma\) proof-symbol queries. Define

\[
  T_\sigma=q_\sigma\,2^{r_\sigma+m_\sigma}|\Sigma|^{q_\sigma}.
\tag{2.11a}
\]

Write \(G_N(u)=Nh_2(u/N)+u\log_2|\Sigma|\).
The all-policy support bound gives \(L_\sigma\le T_\sigma\). Whenever \(\Phi_N\) is monotone
on the relevant window, Theorem 2.7 therefore strengthens to

\[
  H(M\mid D)\le
  \min\left\{
    G_N(\mathbb E R),
    \mathbb E_{\sigma\sim D}[\Phi_N(T_\sigma)]
  \right\}.
\tag{2.11b}
\]

If \(H(M\mid D=\sigma)\ge\eta k/2\) and the DGL threshold from Corollary 2.8 applies, then

\[
  q_\sigma2^{r_\sigma+m_\sigma}|\Sigma|^{q_\sigma}
  \ge
  c_\eta\frac{(\log_2 k)^{1/3}}
  {(\log_2\log_2(k+2))^{2/3}}.
\tag{2.11c}
\]

Consequently, for fixed \(q_\sigma\) and fixed alphabet, every constant-mass
high-conditional-entropy bucket must expose
\(\Omega(\log\log k)\) random/response transcript bits. Thus the descriptor--core--support
trilemma has a fourth, explicit coordinate: short core, low branch support, and low exposed
transcript entropy cannot coexist.

The same conclusion survives randomized descriptors. If \(D\) is sampled conditionally on
\(M\), define

\[
  T_d=\nu_d\,2^{\rho_d+\mu_d}|\Sigma|^{\nu_d},
\tag{2.11d}
\]

for the finite view-tree of descriptor bucket \(d\). Since \(L_d\le T_d\), Theorem 2.7A gives

\[
 H(M)
 \le I(M;D)+
 \min\left\{
   G_N(\mathbb E R),
   \mathbb E_{d\sim D}[\Phi_N(T_d)]
 \right\}.
\tag{2.11e}
\]

Hence \(I(M;D)\), rather than the raw entropy \(H(D)\), is the only descriptor term that can
carry target information. If \(H(M)-I(M;D)=\Omega(k)\), every bucket with
\(H(M\mid D=d)=\Omega(k)\) must simultaneously pay the
\(\Omega(k/\log k)\) complete-policy core and satisfy the same
\(T_d^3\log^2(T_d+2)=\Omega(\log k)\) transcript threshold. Public coins independent of
the target therefore do not create a new finite-response escape.

### Corollary 2.8 (near-linear hidden-output obstruction)

Assume the hypotheses of Corollary 2.6 and Theorem 2.7, and suppose that
\(H(M\mid D)\ge\eta k\) for a fixed \(\eta>0\).  In the DGL window, take
\[
  \Phi_N(L)
  =C|\Sigma|^L\log_2|\Sigma|\,
    N^{1-\theta(L)}\log_2(k+2),
  \qquad
  \theta(L)=\frac{c}{L^2\log^2(L+2)},
\]
with constants uniform in \(k\).  If \(|\Sigma|\ge2\) is fixed,
\(N\le k(\log k)^d\), and every nonempty descriptor bucket satisfies
\[
  L_\sigma=o\!\left(
    \frac{(\log k)^{1/3}}{(\log\log(k+2))^{2/3}}
  \right),
\]
then no such shared relation-PCPP exists for all sufficiently large \(k\).

Thus a near-linear simultaneous coordinate-robust compiler for a high-entropy hidden
output must pay at least one of three costs: average complete-policy core
\(\Omega(k/\log k)\), a non-negligible descriptor mass with branch support at least
\(\Omega((\log k)^{1/3}/(\log\log k)^{2/3})\), or enough descriptor entropy to make
\(H(M\mid D)=o(k)\).

#### Proof

For the displayed \(\Phi_N\), the logarithm of \(\Phi_N(L)/k\) is bounded by
\[
  O(L+\log\log k)
  -\Omega\!\left(\frac{\log k}{L^2\log^2(L+2)}\right).
\]
The stated bound on \(L\) makes this tend to \(-\infty\), uniformly over the descriptor
buckets.  Hence \(\mathbb E_\sigma[\Phi_N(L_\sigma)]=o(k)\), contradicting the second
 inequality in Theorem 2.7.  The core alternative is the first inequality there.
\(\square\)

### Theorem 2.9 (list-exception entropy--core extension)

The all-policy soundness in Theorem 2.5 can be relaxed in a controlled way.  Fix
\(\Lambda\ge0\).  For every descriptor \(\sigma\) and target \(m\) with
\(\kappa(m)=\sigma\), allow an exception set
\(E_{\sigma,m}\subseteq\{m'\in\mathcal M:\kappa(m')=\sigma,\ m'\ne m\}\) of size at most
\(\Lambda\).  Assume that whenever \(m'\notin E_{\sigma,m}\), \(m'_i\ne m_i\), and
\(\pi\) is any policy for declaration \(m'_i\), then
\[
  \Pr[V_{\sigma,i,m'_i,\pi}^{C(m')} \text{ accepts}]\le\beta.
\tag{2.12}
\]
Keep the same complete-policy and common-address hypotheses as in Theorem 2.5.  Then
\[
  H(M)
  \le H(D)+\log_2(\Lambda+1)
     +N h_2\!\left(\frac{\mathbb E R}{N}\right)
     +\mathbb E R\log_2|\Sigma|.
\tag{2.13}
\]

In particular, whenever the conditional target entropy satisfies
\(H(M\mid D)=\Omega(k)\), a list mechanism with \(\log\Lambda=o(k)\) does not remove the
\(\Omega(k/\log k)\) average-core barrier.  It only provides
\(\log(\Lambda+1)\) bits of entropy slack.

#### Proof

Let
\[
  X=(D,K_M,C(M)|_{K_M}).
\]
If two distinct messages \(m,m'\) have the same value of \(X\), choose a coordinate
\(i\) with \(m_i\ne m'_i\).  The complete policy chosen for \(m\) at coordinate \(i\)
has identical transcript distribution on \(C(m)\) and \(C(m')\), so it accepts
\(C(m')\) with probability at least \(\alpha\).  Viewed under target \(m'\), it is a
wrong declaration; condition (2.12) therefore forces \(m\in E_{\sigma,m'}\).  Hence every
fiber of \(M\mapsto X\) has size at most \(\Lambda+1\), and
\(H(M\mid X)\le\log_2(\Lambda+1)\).  The entropy bound for \(X\) is the same subset-and-symbol
calculation as in Theorem 2.5, proving (2.13). \(\square\)

This extension is the precise global-list interface needed for a distributional route.
Ordinary average or per-coordinate list soundness does not automatically imply (2.12):
different coordinates may select incompatible global list words.  A positive construction
must therefore either prove a common exception set/word, or pay the corresponding
\(\log\Lambda\) entropy term.

This theorem does not require a largest bucket or a common core size.  It converts a
target-dependent shared-proof proposal into a global entropy accounting: a short descriptor
forces a large average complete-policy core, while the branch-support theorem separately
charges the union of all wrong-claim policies.  The two bounds form the
support--core--descriptor trilemma.  The target-dependent statement and its finite-time
policy boundary are recorded in [Target-dependent ACRR entropy--core inequality](../../statements/entropy-core-inequality-for-target-dependent-acrr.md).

### Lemma 2.10 (coordinatewise list mixing is not a global list)

For a list \(Y=\{y^{(1)},\ldots,y^{(L)}\}\subseteq\Sigma^k\), define its coordinatewise
mixing hull by

\[
  \operatorname{Mix}(Y)
  =\left\{z\in\Sigma^k:
    z_i\in\{y_i^{(1)},\ldots,y_i^{(L)}\}\ \text{for every }i\in[k]\right\}.
\]
Then
\[
  |\operatorname{Mix}(Y)|
  =\prod_{i=1}^k\left|\{y_i^{(1)},\ldots,y_i^{(L)}\}\right|
  \le \min\{|\Sigma|^k,L^k\}.
\tag{2.14}
\]
Define the mixing entropy of the list by
\[
  \mu(Y):=\log_2|\operatorname{Mix}(Y)|
  =\sum_{i=1}^k\log_2\left|\{y_i^{(1)},\ldots,y_i^{(L)}\}\right|.
\tag{2.15}
\]
Thus \(\mu(Y)\), rather than \(\log L\), is the exact number of bits left unconstrained by
coordinatewise list membership.
The bound is attained at the exponential scale already for binary lists of size two:
for \(Y=\{0^k,1^k\}\), one has
\(|\operatorname{Mix}(Y)|=2^k\).

Thus ordinary dPCP list soundness, which only requires each decoded symbol to be
consistent with the list at its own coordinate, cannot by itself imply a global exception
set of size \(o(2^k)\), even with zero list-decoding error.  A toy witness is the
always-satisfied one-query system whose decoder returns the queried proof symbol.  On the
binary target family \(\mathcal M=\{0,1\}^k\), the fixed list
\(Y=\{0^k,1^k\}\) certifies every assignment with list size two and error zero, while the
coordinatewise mixtures range over all \(2^k\) target words.  If the target family is
restricted to \(\{0^k,1^k\}\), the same construction also exhibits a decoded mixed word
that is not any single listed global word.
If the full binary family is used as the codeword family in the corresponding trivial
common-proof system, every wrong claim may accept, so one target can have
\(2^k-1\) exceptional targets despite the list size being two.

#### Proof

The choices at different coordinates are independent, so the first equality is a direct
Cartesian-product count.  Each factor is at most \(|\Sigma|\) and at most \(L\), proving
(2.14).  For the two constant binary words, both symbols are available at every coordinate,
so every binary word lies in the mixing hull. \(\square\)

Consequently, the global exception hypothesis in Theorem 2.9 is strictly stronger than
ordinary list soundness: a positive distributional construction must control coordinate
mixing (for example through a common global word, target concentration, or an outer
consistency test), not merely provide a short list at each assignment.

### Lemma 2.11 (coordinate ambiguity dominates global mixing)

Let \(Y\subseteq\{0,1\}^k\) be a list containing a target \(m\), and set
\[
  J(m,Y)=\{i\in[k]:\exists y\in Y,\ y_i\ne m_i\}.
\]
The coordinatewise list information leaves the following ambiguity envelope:
\[
  \operatorname{Amb}(m,Y)
  =\{m'\in\{0,1\}^k:\exists i\in J(m,Y),\ m'_i\ne m_i\}.
\tag{2.16}
\]
Consequently,
\[
  |\operatorname{Amb}(m,Y)|
  =2^k-2^{k-|J(m,Y)|},
\tag{2.17}
\]
with the value \(0\) when \(J(m,Y)=\varnothing\), and at least \(2^{k-1}\) whenever
\(J(m,Y)\ne\varnothing\).

#### Proof

If \(i\in J(m,Y)\), the opposite bit \(1-m_i\) is a symbol appearing in the list at
coordinate \(i\).  Every word \(m'\) that differs from \(m\) at some such coordinate is
therefore compatible with the coordinatewise list at a wrong coordinate.  The only words
not counted are those agreeing with \(m\) on all coordinates in \(J(m,Y)\), giving
(2.17). \(\square\)

This is the relevant envelope for a black-box attempt to derive Theorem 2.9: unlike the
mixing entropy \(\mu(Y)\), which counts words compatible at every coordinate, the
all-policy hypothesis is violated as soon as a candidate is compatible at one wrong
coordinate.  Thus even \(\mu(Y)=1\) can leave \(2^{k-1}\) potential exception targets.
For the two constant binary words \(Y=\{0^k,1^k\}\), \(J(m,Y)=[k]\) and the envelope has
size \(2^k-1\).  A useful distributional-to-ACRR conversion must therefore impose
coordinate singleton concentration (\(J(m,Y)=\varnothing\) in the full binary family),
restrict the target family, or add a stronger cross-coordinate consistency theorem.

### Corollary 2.12 (full-family list collapse below the half-exponential budget)

Let the target family be the full binary cube \(\mathcal M=\{0,1\}^k\), and suppose a
black-box conversion from coordinatewise list membership to Theorem 2.9 uses an exception
budget \(\Lambda<2^{k-1}\) for every target.  If every target list contains its target,
then every list must be coordinatewise singleton: \(Y_m=\{m\}\).

#### Proof

If \(Y_m\) differed from \(m\) at any coordinate, then \(J(m,Y_m)\ne\varnothing\), and
Lemma 2.11 would force an ambiguity envelope of size at least \(2^{k-1}\), contradicting
the budget.  Hence all list words agree with \(m\) at every coordinate. \(\square\)

This is a black-box semantic barrier, not an unconditional lower bound for dPCPs: a new
construction could escape by proving cross-coordinate correlations that are invisible to
coordinatewise list membership.

The two costs can be combined without selecting a largest bucket.  For a descriptor
\(\sigma\), let \(L_\sigma\) be the union support of all finite-time policies in that bucket,
and let \(\Phi_N(L_\sigma)\) denote any valid relaxed-LDC upper bound on the logarithm of the
bucket size.  The conditional entropy satisfies

\[
  H(M\mid D)
  \le \min\left\{
    N h_2(\mathbb E|K_M|/N)+\mathbb E|K_M|\log_2|\Sigma|,
    \mathbb E_{\sigma\sim D}[\Phi_N(L_\sigma)]
  \right\}.
\]

Thus if \(H(M\mid D)=\Omega(k)\), a constant fraction of the high-entropy descriptor
buckets must simultaneously have large complete-policy cores and leave the low-locality
relaxed-LDC window.  This conditional-entropy form is the
support--core--descriptor trilemma; it strengthens the largest-bucket argument while
preserving its explicit escape classes.  The formal statement and proof are in
[Conditional entropy support--core trilemma](../../statements/conditional-entropy-support-core-trilemma.md).

## 3. Distributional soundness and the inverse-linear threshold

Suppose a dPCP has a singleton target word \(f_x\in\{0,1\}^k\), a common proof address
space, and uniform coordinate marginal. Assume its coordinate-averaged distributional
error is at most \(\varepsilon\), and every locally valid word projects to the same target
word. Conditioning on a fixed coordinate gives

\[
  \Pr[V_{i,1-f_x[i]}(z)=1]\le k\varepsilon.
\]

This is the only place where the average-to-coordinate conversion is used. Therefore a
constant coordinate gap requires

\[
  \varepsilon=O(1/k).
\]

Combining this conversion with Theorem 2.1 yields the following parameter test.

### Corollary 3.1

In a fixed finite alphabet, fixed-query, positive-radius family, singleton distributional
error \(\varepsilon_k\le\beta/k\) with any fixed \(\beta<1/2\) is incompatible with
near-linear proof length. More precisely, the resulting inline code enters the fixed-query
relaxed-LDC lower bound.

The corollary is not a lower bound against all dPCPs. It applies only after the target
projection is singleton, the common proof is message-oblivious at the family level, and the
target-relative neighborhood is available.

### Theorem 3.2A (singleton-output distributional bridge)

The inverse-linear loss in Corollary 3.1 is not intrinsic to distributional soundness. It
comes from first averaging over coordinates and then conditioning on one coordinate. A
stronger, fixed-coordinate distributional coupling avoids that loss even when the ideal
valid assignment is not unique.

Fix an input \(x\), an output word \(f_x\in\{0,1\}^k\), and one common proof/assignment
address space. For each coordinate \(i\), let \(e\sim\mu_i\) denote a local random view,
let \(V_i(A;e)\) be its acceptance predicate, and let \(D_i(A;e)\in\{0,1,\bot\}\) be its
decoded symbol. Let \(\mathcal V_x\) be the set of globally valid assignments. Assume:

1. There is one honest assignment \(A_x\) such that every local view is accepted and
   \(D_i(A_x;e)=f_x[i]\) for every \(i,e\).
2. **Singleton target projection.** Every \(A^\star\in\mathcal V_x\) has
   \(V_i(A^\star;e)=1\) and \(D_i(A^\star;e)=f_x[i]\) for every \(i,e\).
3. For every candidate assignment \(A\) in the target-relative neighborhood used by the
   soundness definition and every \(i\), there is a coupling of \(e\sim\mu_i\) with a
   valid assignment \(A^\star\in\mathcal V_x\) for which
   \[
     \Pr\!\left[V_i(A;e)=1\ \land\ D_i(A;e)\ne D_i(A^\star;e)\right]\le\delta .
   \]

For a claimed bit \(b\), define the common-address verifier

\[
  Q_{x,i,b}(A;e)=1
  \quad\Longleftrightarrow\quad
  V_i(A;e)=1\ \text{ and }\ D_i(A;e)=b .
\]

Then \(Q_{x,i,f_x[i]}\) has perfect completeness, while every wrong claim satisfies

\[
  \Pr_e[Q_{x,i,1-f_x[i]}(A;e)=1]\le\delta
\]

uniformly over the target-relative neighborhood. Consequently, whenever
\(\delta<\alpha\) (or after any fixed amplification that preserves a positive gap), the
same proof address space is an \(\mathrm{ACRR}\)/relaxed-local-decoding interface with
locality inherited from \(V_i,D_i\), and Theorem 2.1 applies.

#### Proof

On an accepted view of a coupled valid assignment \(A^\star\), the singleton projection
assumption gives \(D_i(A^\star;e)=f_x[i]\). Hence the event that \(A\) is accepted and
decodes to \(1-f_x[i]\) is contained in the exceptional disagreement event in (3), and
has probability at most \(\delta\). The honest assignment gives completeness one. No
single globally unique \(A^\star\) is required: the valid assignment may depend on the
local random view, because all valid assignments have the same target projection.

This is a conditional bridge, not a construction theorem. It still requires a uniform
common address space, a target-relative neighborhood, and an address-scale generator for
the local views. Ordinary average/list soundness does not imply (2)--(3).

### Corollary 3.2A' (DHK ideal-distribution specialization)

The preceding bridge applies directly to the original distributional-soundness semantics.
Assume that, for every target-relative candidate proof \(z\), the actual local verifier
on randomness \(R\) can be coupled to a DHK idealized verifier that samples a valid proof
\(\widetilde\Pi_{z,R}\) or \(\bot\), and that
\[
 \Pr\!\left[
   \text{the actual verifier accepts and its decoded symbol in }
   \{0,1\}\text{ differs from the ideal symbol in }\{0,1,\bot\}
 \right]\le\delta .
\tag{3.2A'.1}
\]
If every non-\(\bot\) ideal proof in the support has decoded coordinate \(i\) equal to the
same target bit \(f_x[i]\), then the wrong branch \(1-f_x[i]\) accepts with probability
at most \(\delta\).  When \(\delta\le1/3\), the inline bit together with this one-shot
branch is a variable-query \((2/3,1/3)\)-RLDC on the same common proof map; hence the
near-linear locality barrier of Theorem 3.4D'' applies.

This is exactly the extra quantifier that ordinary DHK distributional soundness lacks:
the ideal proof may depend on \(R\), but all ideal proofs must agree on the target
projection.  Proposition 3.2D shows that removing this singleton condition can make the
ROC equal to one even when \(\delta=1/n\).

### Corollary 3.2F (singleton DHK bridge: RLDC or cubic LDC)

Assume in addition that the common binary verifier uses at most two adaptive proof
queries and define its half-radius non-bottom mass by
\[
  \tau_{\rho/2}:=
  \inf_{x,i}\inf_{\operatorname{dist}(z,\Pi_x)\le\rho/2}
  \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr).
\]
Under the singleton DHK coupling above, if
\[
  \delta\le\frac13,
  \qquad
  \tau_{\rho/2}\ge\frac23+\delta,
\tag{3.2F.1}
\]
then the same proof map enters the one-shot non-bottom regime of Corollary 3.4B:
\[
  k+P=\Omega_{\rho,\delta}\!\left(\frac{k^3}{\log^6 k}\right).
\tag{3.2F.2}
\]
Indeed, singleton coupling bounds the wrong branch by \(\beta=\delta\), while
(3.2F.1) gives
\[
  \max\{\beta,1-\tau_{\rho/2}+\beta\}\le\frac13.
\]
Corollary 3.4B then applies. Without (3.2F.1), Corollary 3.2A' still gives the
variable-query RLDC barrier, but not the cubic LDC conclusion: a bottom/simultaneous
rejection escape remains logically open.

#### Why the singleton projection is necessary

The failure is sharp even when the distributional error is \(1/n\). Let
\(\mathcal V=\{0,1\}^n\setminus\{1^n\}\), let every local constraint accept, and let the
decoder at coordinate \(j\) return the \(j\)-th proof bit. For the invalid candidate
\(\Pi=1^n\), choose a uniform \(I\in[n]\) and couple it to the valid word
\(A^\star_I=1^n-e_I\). For each fixed \(j\), the local view disagrees with \(A^\star_I\)
only when \(I=j\), so the fixed-coordinate distributional error is \(1/n\). Nevertheless,
there is no single valid word explaining all coordinates of \(\Pi\), and the valid target
\(0^n\) would accept the wrong declaration \(1\) with probability one under the identity
decoder. Thus distributional soundness without singleton target concentration cannot be
promoted to simultaneous coordinate robustness.

### Proposition 3.2B (agnostic singleton dPCP still allows a bad coordinate)

The preceding separation persists under a non-degenerate regular projection interface.
For every \(n\ge2\) and \(M\ge2\), let the language be \(\mathcal L_n=\{0^n\}\). Take
left and right vertex sets \(A=B=[M]\), the complete bipartite edge set, and for every
output coordinate \(t\) let \(\mathcal P_t\) be uniform on the edges. Use
\(\Sigma_A=\Sigma_B=\{0,1\}\), and put the equality projection constraint
\(\Phi_{(a,b)}(s,t)=1\) iff \(s=t\). Define

\[
  D_t(a,s)=
  \begin{cases}
    1,&t=1\text{ and }s=1,\\
    0,&\text{otherwise}.
  \end{cases}
\]

This system has perfect completeness, agnostic complete decoding distribution, uniform
left and right marginals, and \((1,1/n)\)-list-decoding soundness. Indeed, for every
left assignment \(T_A\), use the list word \(0^n\). For every right assignment \(T_B\),
an accepted edge can decode outside this list only when \(t=1\) and \(T_A(a)=1\), so
the total probability is at most \(1/n\). On the all-one assignment
\(T_A\equiv T_B\equiv1\), every projection constraint accepts but the decoded word is
\(10^{n-1}\); hence the wrong declaration at coordinate \(1\) is accepted with
probability one.

Thus singleton output, agnosticity, and average/list error \(1/n\) do not imply a
fixed-coordinate gap, even with a regular complete-bipartite projection graph. It is a
logical separation for the source interface, not an impossibility theorem for all
nontrivial dPCP constructions. Any positive construction must add fixed-coordinate
coupling, coordinate normalization, or a global target-binding check beyond agnosticity.

### Proposition 3.2C (pure coordinate reweighting cannot create robustness)

The copying escape has a general counting form. Suppose a base singleton-output system has
target coordinates \(i\in[n]\), and for each \(i\) there is a candidate assignment whose
only wrong decoded coordinate is \(i\). Consider any transformation that replaces coordinate
\(i\) by \(r_i\ge1\) copies, adds only equality constraints between copies, and tries to
obtain fixed-coordinate soundness solely by sampling the
\(N=\sum_i r_i\) copies with some weights. The normalized mass of coordinate \(i\) is
\[
  \omega_i=\frac{r_i}{N},\qquad \sum_{i=1}^n\omega_i=1.
\]
Consequently,
\[
  \min_i\omega_i\le\frac1n.
\]
No such reweighting can give every coordinate a constant error mass. Moreover, when the
candidate assignment sets all copies of the bad coordinate consistently to the wrong
symbol, the equality constraints are still satisfied; any decoder that reads only those
copies therefore retains the original wrong-claim event with probability one. Thus
coordinate duplication can help only after adding a new semantic check, an outer code, or
a genuinely global target-binding condition. Equality constraints and public resampling
alone cannot replace the fixed-coordinate coupling in Theorem 3.2A.

#### Proof

The first assertion is the pigeonhole inequality applied to the copy weights. For the
second, duplicate the witness assignment coordinatewise. Since every copy receives the
same wrong symbol, all equality constraints accept, and every local test whose input is
confined to those copies sees exactly the same wrong symbol as the original test. \(\square\)

### Proposition 3.2D (distributional soundness can coexist with ROC \(=1\))

For every \(n\ge2\), let the valid output family be
\(\mathcal H_n=\{0,1\}^n\setminus\{1^n\}\), let the common proof map be the identity
\(\Pi(m)=m\), and let the local constraint system accept every queried symbol.  The
standard distributional-soundness condition with uniform coordinate sampling holds with
error \(1/n\): for the only invalid proof \(z=1^n\), after the sampled coordinate
\(J\leftarrow[n]\) is revealed choose the valid word \(m^{(J)}=1^n-e_J\); the local view
agrees except when the sampled coordinate is \(J\), which has probability \(1/n\).
Every valid proof is explained by itself with error zero.

Nevertheless, fix a coordinate \(i\) and the claim \(b=1\).  Let \(V_{i,1}\) query only
position \(i\) and accept exactly when the answer is \(1\).  Every honest target with
\(m_i=1\) has the same visible transcript \(\tau=(i,1)\).  Let
\(m'=1^n-e_i\), whose \(i\)-th bit is \(0\), and take the \(1/n\)-near proof
\(z=1^n\).  The wrong branch on \(z\) has the same transcript \(\tau\).  Therefore
\[
 \operatorname{ROC}_{i,1}(1,\rho)=1
 \qquad\text{for every fixed }\rho>0\text{ and }n\ge1/\rho.
\tag{3.2D.1}
\]
Indeed, any transcript test with honest completeness one must output the claim on
\(\tau\), and hence also outputs it with probability one on the wrong proof.

Thus even arbitrarily small DHK-style distributional error does not imply a
transcript-level coordinate filter.  This is a finite source-interface separation, not an
impossibility theorem for nontrivial dPCPs; any positive route must add target concentration,
fixed-coordinate coupling, or another semantic condition beyond the distributional
quantifiers.

### Corollary 3.2E (singleton target concentration is the exact ROC gate)

Under the hypotheses of Theorem 3.2A, the transcript test
\[
 f_{i,b}(\tau)
   :=\mathbf 1\{\text{the local view accepts and decodes to }b\},
 \qquad b=f_x[i],
\]
has honest completeness one and worst-case wrong-claim probability at most \(\delta\).
Consequently, with the ROC definition of Theorem 3.4L,
\[
 \operatorname{ROC}_{i,f_x[i]}(1,\rho)\le\delta .
\tag{3.2E.1}
\]
Proposition 3.2D shows the converse boundary is sharp as a black-box statement: once the
singleton target-projection hypothesis is removed, no function tending to zero with the
distributional error can upper-bound the ROC, even in the identity-proof interface.
Thus the missing positive ingredient is target concentration in one common address space,
not a more sophisticated transcript postprocessor.

### Theorem 3.2 (weighted distributional soundness enters the RLDC barrier)

The uniform-coordinate factor \(k\) is not an artifact of conditioning. Let \(w\) be any
positive distribution on the \(k\) output coordinates, with
\(w_{\min}=\min_i w_i\). Suppose that the same proof map \(\Pi\) has completeness
\(\alpha\) and, for every target \(m\) and every proof \(z\) in a fixed
\(\rho\)-neighborhood of \(\Pi(m)\),

\[
  \sum_i w_i\,p_{i,1-m_i}(z)\le\varepsilon .
\]

Then every wrong coordinate branch has acceptance at most
\(\beta=\min\{1,\varepsilon/w_{\min}\}\). If \(\beta<\alpha\), the proof map is already a
positive-radius relaxed-LDC code after thresholding the two claim branches, with locality
\(O(q(\alpha-\beta)^{-2})\). Consequently, every fixed-parameter relaxed-LDC lower bound
applies to the proof length. In particular, a near-linear common-proof family with fixed
alphabet, locality, gap and positive radius must satisfy

\[
  \varepsilon\le(\alpha-\gamma)w_{\min}
\]

for any fixed desired gap \(\gamma>0\). Since \(w_{\min}\le1/k\), no non-uniform coordinate
sampling can improve the worst-coordinate asymptotic beyond the uniform
\(\varepsilon=O(1/k)\) threshold.

This theorem is the weighted synthesis of the sharp average-to-coordinate bound and the
proof-only relaxed-LDC compiler. It makes the positive route's remaining obligation explicit:
one must add coordinate-normalized or globally coupled information not contained in the scalar
weighted average. The full statement and proof are in
[Weighted distributional-to-RLDC barrier](../../statements/weighted-distributional-to-rldc-barrier.md).

### Theorem 3.3 (non-bottom robustness upgrades RLDC to LDC)

The relaxation symbol \(\bot\) is not merely a presentation choice. For a fixed
\(0<\delta<\rho\), define the minimum two-branch mass on the \(\delta\)-neighborhood of
the proof image by

\[
  \tau_\delta=\inf_{m,i,\,\operatorname{dist}(z,C(m))\le\delta}
  \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr).
\]

If \(\gamma=\min\{\alpha-\beta,\tau_\delta-2\beta\}>0\), thresholding both claim branches
gives an ordinary \(Q=O(q\gamma^{-2})\)-query LDC at radius \(\delta\). The proof-image
distance condition follows from the same completeness/soundness contradiction used in
Theorem 3.2; the extra branch-mass condition lower-bounds the correct branch by
\(\tau_\delta-\beta\), so no \(\bot\) output is needed.

This creates a sharp escape test for the positive route. A family below the applicable
ordinary-LDC length bound must have a target, coordinate, and near-proof for which
\(\tau_\delta\le2\beta+o(1)\); otherwise the candidate is an ordinary LDC in disguise. The
three-query \(\widetilde\Omega(k^3)\) bound can be invoked only when the thresholded decoder
itself remains three-query; generic probability amplification changes the query count to a
fixed \(Q>3\) and must use the corresponding \(Q\)-query lower bound. The self-contained
statement is [Non-bottom coordinate-robustness LDC barrier](../../statements/nonbottom-coordinate-robustness-ldc-barrier.md).

For projection-based candidates, the theorem has a concrete witness search. If a
\(\delta\)-small change set \(S\) hits a coordinate's local-edge distribution with mass
\(h_i(S)\), and every hit edge rejects both claim branches while unhit edges have total branch
mass at most \(u\), then
\[
  p_{i,0}(z_S)+p_{i,1}(z_S)\le u(1-h_i(S)).
\]
Thus \(u=1\) and \(h_i(S)>1-2\beta\) explicitly certify the bottom escape. This criterion is
recorded in [Projection-rigidity patchability boundary](../../statements/projection-rigidity-patchability-boundary.md).
Left-canonicality alone gives only one bad incident edge per changed left vertex and does not
certify the required high hit mass.

### Theorem 3.4 (low-soundness ACRR collapses to LDC)

Assume the binary proof map \(C:\{0,1\}^{k}\to\{0,1\}^{N}\) has nonadaptive branch
verifiers \(V_{i,b}\), each making at most \(q\) queries. Suppose that on every codeword the
correct branch accepts with probability at least \(\alpha\), while on every proof within
relative distance \(\rho>0\) of the target codeword the wrong branch accepts with probability
at most \(\beta\). Let

\[
  Q=2q,\qquad c=\alpha(1-\beta),\qquad \varepsilon=1-c.
\]

Running the two branches once and outputting \(b\) only when exactly branch \(b\) accepts
gives a nonadaptive \((Q,\rho,c,\beta)\)-RLDC. If

\[
  \beta<2^{-Q}
  \quad\text{and}\quad
  1-2\varepsilon-\beta 2^Q>0,
\]

then Cheng--Li--Mao's low-soundness RLDC-to-LDC theorem yields, for every

\[
  0<r<\frac{\rho}{2Q}\bigl(1-2\varepsilon-\beta 2^Q\bigr),
\]

an ordinary \(Q\)-query LDC on the same code map, with decoding error at most

\[
  \varepsilon+\frac{\beta 2^Q}{2}+\frac{rQ}{\rho}.
\]

For perfect correct-branch completeness \(\alpha=1\), the simple sufficient condition is
\(\beta<1/(2^Q+2)\). Hence, in the nonadaptive family-level model, exponentially small
wrong-branch soundness closes the bottom escape without any extra non-bottom hypothesis.
The result is a direct composition of the two-branch compiler and the external
low-soundness theorem; it does not claim that ordinary constant soundness can be amplified
without paying in locality.

The exact statement and the finite-alphabet/adaptive boundary are recorded in
[Low-soundness ACRR implies LDC](../../statements/low-soundness-acrr-implies-ldc.md).

### Corollary 3.4A (linear two-query ACRR meets the cubic LDC barrier)

Assume in addition that the binary proof map is linear,
\(\Pi:\mathbb F_2^k\to\mathbb F_2^P\), and that each claim verifier is randomized and
adaptive but makes at most two proof queries. If the target-relative radius is a fixed
\(\rho>0\), the correct branch has completeness at least \(\alpha\), and every wrong branch
has acceptance at most \(\beta\) throughout the target \(\rho\)-ball, then

\[
  \beta+3(1-\alpha)<\frac12
  \quad\Longrightarrow\quad
  k+P=\Omega_{\rho,\alpha,\beta}\!\left(\frac{k^3}{\log^3 k}\right).
\tag{3.4A}
\]

Indeed, Theorem 2.1 first forces the image of \(\Pi\) to have relative distance greater than
\(\rho\). The Singleton bound then gives
\(P/(k+P)\ge 1/(3-2\rho)\) (for \(k\ge2\)). Inline the message,
\(C(m)=m\,\|\,\Pi(m)\), and decode coordinate \(i\) by querying the inline bit \(y_i\), then
running \(V_{i,y_i}\) on the proof suffix. This is a three-query adaptive linear RLDC at a
constant radius. The linear completeness-amplification theorem and cubic lower bound of
Grigorescu--Kumar--Manohar--Mon convert it to a perfect-complete three-query linear LDC with
soundness \(\beta+3(1-\alpha)<1/2\), and hence length
\(\Omega((k/\log k)^3)\).

Corollary 3.4A is deliberately scoped: it does not cover nonlinear proof maps, three or more
proof queries, nonbinary alphabets, vanishing radius, or a single target without a message
family. It is therefore a restricted barrier, not a proof that simultaneous coordinate
robustness is impossible in general. The full standalone statement is
[Linear binary two-query Sim-CR cubic barrier](../../statements/linear-q2-simcr-cubic-ldc-barrier.md).

### Corollary 3.4B (one-shot non-bottom two-query ACRR is a cubic LDC barrier)

The linearity assumption in Corollary 3.4A is unnecessary if the verifier has a stronger
near-proof non-bottom guarantee.  Define

\[
  \tau_{\rho/2}:=\inf_{m,i}\ \inf_{\operatorname{dist}(z,\Pi(m))\le\rho/2}
     \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr).
\]

If the binary family has positive radius \(\rho\), at most two adaptive proof queries, and

\[
  \varepsilon_0:=\max\{\beta,1-\tau_{\rho/2}+\beta\}\le\frac13,
\tag{3.4B}
\]

then the message-inline code \(C(m)=m\,\|\,\Pi(m)\) is a three-query ordinary LDC with constant
radius, constant distance, and error at most \(\varepsilon_0\).  Indeed, query the inline bit
\(b\), run \(V_{i,b}\), and output \(b\) on acceptance and \(1-b\) on rejection.  When \(b\)
is correct, the total-mass condition and wrong-branch soundness give correct-branch acceptance
at least \(\tau_{\rho/2}-\beta\); when \(b\) is wrong, the error probability is at most
\(\beta\).  The Singleton bound supplies a constant inline decoding radius.

Therefore the general (not necessarily linear) three-query LDC lower bound gives

\[
  k+P=\Omega_{\rho,\varepsilon_0}\!\left(\frac{k^3}{\log^6 k}\right).
\tag{3.4B'}
\]

This is a sharper nonlinear barrier than the generic threshold-amplification theorem, but it
requires the explicit one-shot non-bottom condition (3.4B).  It does not rule out a near-linear
construction whose essential escape is simultaneous rejection of both claims on some near-proof.
The self-contained statement is
[Three-query one-shot non-bottom ACRR barrier](../../statements/three-query-nonbottom-acrr-cubic-ldc-barrier.md),
and the external lower bound is GMWZ Theorem 1.10.

### Theorem 3.4C (bottom-or-cubic dichotomy)

Corollaries 3.4A--B can be combined into a sharper route filter. For an arbitrary binary
proof map and adaptive two-query claim verifiers, the target-relative assumptions already give
the relaxed-LDC lower bound of Theorem 2.1. If, in addition, the half-radius two-branch mass
\[
  \tau_{\rho/2}:=\inf_{m,i,\,\operatorname{dist}(z,\Pi(m))\le\rho/2}
  \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr)
\]
satisfies \(\tau_{\rho/2}\ge2/3+\beta\) (and \(\beta\le1/3\)), Corollary 3.4B gives
\[
  k+P=\Omega_{\rho,\beta}\!\left(\frac{k^3}{\log^6 k}\right).
\tag{3.4C}
\]
Equivalently, any family below the three-query cubic threshold must have a target, coordinate,
and half-radius near-proof with total two-branch acceptance mass (<2/3+\beta). This is a
genuine dichotomy, not a claim that ordinary list or average soundness supplies the missing
mass bound: the remaining escape is a concrete simultaneous-rejection/bottom witness.

The self-contained statement and proof are in [Binary family-level ACRR: relaxed-LDC baseline
or bottom-or-cubic dichotomy](../../statements/acrr-bottom-or-cubic-dichotomy.md).

### Theorem 3.4D (growing-locality threshold)

Fix a proof alphabet \(\Sigma\) of size \(A\ge2\), constants \(0<\rho<1\),
\(\sigma_0>0\), and \(c>0\).  Consider a family satisfying the finite-alphabet
coordinate-robust interface of Theorem 2.1A with perfect correct-branch completeness,
wrong-branch acceptance at most \(1-\sigma_0\) on the target \(\rho\)-ball, and at most
\(r=r(k)\) adaptive proof-symbol queries per claim branch.  Let

\[
  Q:=1+2\sum_{j=0}^{r-1}A^j.
\]

If the inline length \(N=k+P\) obeys \(N\le k(\log k)^c\) for infinitely many sufficiently
large \(k\), then, for some constant \(\eta=\eta(A,\rho,\sigma_0,c)>0\),

\[
  Q\ge \eta\,\frac{\log k}{\log\log k}
\tag{3.4D}
\]

on all sufficiently large lengths in that infinite set.  Consequently,

\[
  r\ge \log_A\log k-\log_A\log\log k-O_{A,\rho,\sigma_0,c}(1).
\]

For binary proofs, there is a constant
\(C=C(\rho,\sigma_0,c)\) such that every branch depth

\[
  r\le \log_2\log k-\log_2\log\log k-C
\]

is therefore incompatible with near-linear length.  This is a pointwise constant-gap
exclusion, not merely the weaker assertion that a surviving query count cannot be
\(o(\log k/\log\log k)\).

#### Proof

The finite-alphabet compiler and the decision-tree expansion give a nonadaptive relaxed
decoder with query count \(Q\), constant radius \(\delta_0=\delta_0(A,\rho)>0\), and
success gap \(\sigma=1-\beta\ge\sigma_0\).  The arbitrary-alphabet relaxed-LDC bound of
Goldberg--Gur--Saraogi gives, whenever
\(\delta_0>N^{-\sigma/(2Q)}\),

\[
  N\ge
  \left(
    \frac{\sigma^2 k}
    {38Q^4\log^2(A+2)\log^2 k}
  \right)^{1+1/a},
  \qquad a=\left\lceil\frac{Q}{\sigma}\right\rceil .
\tag{3.4D.1}
\]

It remains to check the growing-\(Q\) regime rather than silently treating \(Q\) as a
constant.  Put \(g=\log k/\log\log k\) and suppose, for contradiction, that
\(Q\le\eta g\).  For large \(k\),

\[
  a\le \frac{2\eta}{\sigma_0}g,
  \qquad
  \frac{\log k}{a}\ge \frac{\sigma_0}{2\eta}\log\log k.
\tag{3.4D.2}
\]

Since \(N\ge k\), the radius condition in (3.4D.1) is then automatic: its right-hand side is
at most \((\log k)^{-\sigma_0/(2\eta)}\), which is eventually below the fixed
\(\delta_0\).  Let

\[
  D=38Q^4\log^2(A+2)\log^2 k/\sigma^2.
\]

Under \(Q\le\eta g\), \(\log D\le6\log\log k+O_{A,\sigma_0,\eta}(1)\).  Taking logarithms in
(3.4D.1) and using \(N\le k(\log k)^c\) yields

\[
  \frac{\log k}{a}
  \le c\log\log k+(1+1/a)\log D
  \le (c+12)\log\log k+O(1).
\tag{3.4D.3}
\]

Choosing \(\eta<\sigma_0/[4(c+12)]\) contradicts (3.4D.2).  Hence
\(Q\ge\eta g\) at every sufficiently large length satisfying the near-linear bound.
Finally \(Q=\Theta_A(A^r)\) gives the displayed lower bound on \(r\).  In the binary
case this means that, for some constant \(C=C(\rho,\sigma_0,c)\), every
\(r\le\log_2\log k-\log_2\log\log k-C\) is excluded; the statement is not merely a
global \(Q\not=o(g)\) assertion.
The theorem is a necessary condition only: it does not assert that the threshold-scale
construction exists.  \(\square\)

This is the first quantitative boundary for the remaining growing-locality escape.  It is
not a general dPCP impossibility theorem: the proof uses the common proof map, the
target-relative radius, and the finite-alphabet shared-address compiler.  Its standalone
parameter audit is [note 242](../../../mcsp-hardness-magnification/notes/242-growing-query-threshold-for-near-linear-closure-2026-08-17.md).

### Theorem 3.4N (finite-view strategy entropy barrier)

The growing-locality theorem also applies when Merlin's strategy is not drawn from a small
explicitly listed family.  Fix a finite proof alphabet \(\Sigma\), \(|\Sigma|=A\ge2\).  For
each coordinate \(i\) and claim \(b\), suppose the adaptive verifier makes at most \(q\)
proof-symbol queries, sees at most \(r\) public random bits and at most \(m\) response bits
in one execution.  The response policy may be an arbitrary function of the complete visible
history.  All verifier randomness visible to the decoder is included in the \(r\) public bits;
hidden coins are outside this finite-view statement.  The response interface is the standard
bit model: each observed response symbol contributes one binary branch; an oracle/hash
operation on an unbounded response string is outside the model.  Assume perfect completeness for the
correct claim and target-relative soundness \(\beta\le1-\sigma_0\) for every response policy
on a fixed radius \(\rho>0\).  If

\[
  N=k+P\le k(\log k)^c
\tag{3.4N.1}
\]

for infinitely many \(k\), then

\[
  Q_{\mathrm{view}}:=1+2q\,2^{r+m}A^q
  =\Omega_{A,\rho,\sigma_0,c}\!\left(\frac{\log k}{\log\log k}\right).
\tag{3.4N.2}
\]

Equivalently,

\[
 r+m+q\log_2 A+\log_2(q+2)
 \ge \log_2\log k-\log_2\log\log k-O_{A,\rho,\sigma_0,c}(1).
\tag{3.4N.3}
\]

With fixed \(q\) and \(A\), a near-linear shared proof must therefore expose
\(\Omega(\log\log k)\) public/response bits per execution.  An arbitrarily long but invisible
Merlin string is not a finite-view escape.

#### Proof

For fixed \((i,b)\), a visible execution path is determined by the public random tape, the
observed response transcript and the proof answers.  There are at most
\[
  2^r\,2^m\,A^q
\tag{3.4N.4}
\]
such paths, and each path contains at most \(q\) proof-query positions.  Hence the union of
all proof positions reachable over all policies has size at most
\[
  q\,2^{r+m}A^q.
\tag{3.4N.5}
\]

Query both claim supports and the inline coordinate.  The decoder enumerates the finite
visible policies offline and computes their exact acceptance probabilities over the \(r\)
public bits; it outputs \(b\) only when the maximum acceptance of branch \(b\) exceeds
\((1+\beta)/2\), and outputs \(\bot\) otherwise.  The common proof map and all-policy
quantifier give perfect completeness and prevent a wrong output on every proof in the
\(\rho\)-neighborhood.  The standard tagged-inline distance argument gives a fixed positive
radius depending only on \((A,\rho)\), and the resulting nonadaptive RLDC has query count at
most \(Q_{\mathrm{view}}\).

Apply the arbitrary-alphabet GGS lower bound with
\(a=\lceil Q_{\mathrm{view}}/(1-\beta)\rceil\).  In the contradiction regime
\(Q_{\mathrm{view}}\le\eta\log k/\log\log k\), the radius condition is automatic and the
bound forces
\[
 \frac{\log k}{a}\le(c+12)\log\log k+O(1),
\]
whereas \(a\le(2\eta/\sigma_0)\log k/\log\log k\) gives
\(\log k/a\ge(\sigma_0/(2\eta))\log\log k\).  Choosing
\(\eta<\sigma_0/[4(c+12)]\) is a contradiction.  This proves (3.4N.2), and taking
logarithms of its definition gives (3.4N.3). \(\square\)

This is deliberately a finite-view statement.  It does not cover an unbounded-time or
continuous response channel, soundness quantified only for one selected policy, or a
target-dependent proof/address space.  Its role is to convert the remaining strategy escape
into a measurable transcript-entropy cost before invoking any new PCP construction.

### Theorem 3.4N' (finite-view alphabet--transcript envelope)

The finite-view argument remains source-safe when the proof alphabet grows, provided the
alphabet itself is charged as a possible message-scale channel.  Let
\(\Pi_k:\{0,1\}^k\to\Sigma_k^{P_k}\), \(A_k:=|\Sigma_k|\ge2\), be a common proof map
with the hypotheses of Theorem 3.4N, except that \(A_k\) may depend on \(k\).  Put

\[
  Q_k:=1+2q_k\,2^{r_k+m_k}A_k^{q_k},
  \qquad
  H_k:=\log_2\log_2(k+2)+\log_2(Q_k+2)
       +\log_2\bigl(\log_2(A_k+2)+2\bigr).
\tag{3.4N'.1}
\]

For fixed \(0<\rho<1\), \(\sigma_0>0\), and \(c>0\), if
\(N_k:=k+P_k\le k(\log_2(k+2))^c\) for infinitely many sufficiently large \(k\), then
there is a constant \(\eta_* = \eta_*(\rho,\sigma_0,c)>0\) such that, at every such
length,

\[
  \log_2 A_k\ge \frac{k}{2}
  \qquad\text{or}\qquad
  Q_kH_k\ge \eta_*\log_2 k .
\tag{3.4N'.2}
\]

Thus an arbitrarily long but finite-view strategy cannot hide both a sub-message-scale
alphabet and a sub-threshold visible transcript.  This is a joint envelope, not an
achievability statement.

#### Proof

Write \(\ell_k=\log_2 A_k\) and \(\sigma=1-\beta\ge\sigma_0\).  If
\(\ell_k\ge k/2\), the first alternative holds.  Otherwise the all-policy soundness
and perfect completeness imply that distinct proof words have Hamming distance greater
than \(\rho P_k\): use a policy complete for one message as a wrong-claim policy for the
other.  The \(A_k\)-ary Singleton bound therefore gives

\[
  k\le ((1-\rho)P_k+1)\ell_k,
  \qquad
  \frac{P_k}{N_k}\ge
  \frac{1}{2(1-\rho)\ell_k+1}.
\tag{3.4N'.3}
\]

Tagging the inline symbols with the two disjoint tags gives alphabet size \(A_k+2\).  Set

\[
  \delta_k:=
  \frac{\rho}{2(2(1-\rho)\ell_k+1)}.
\tag{3.4N'.4}
\]

A word within relative distance \(\delta_k\) of the tagged codeword has proof suffix within
the \(\rho\)-ball.  If the radius condition of the arbitrary-finite-alphabet GGS theorem
fails, then

\[
  \delta_k\le N_k^{-\sigma_0/(2Q_k)}
  \quad\Longrightarrow\quad
  Q_k\bigl(\log_2(\ell_k+2)+1\bigr)=\Omega_{\rho,\sigma_0}(\log_2 k),
\tag{3.4N'.5}
\]

which already implies (3.4N'.2), since the left side is bounded by a constant multiple
of \(Q_kH_k\).

It remains to consider the case
\(\delta_k>N_k^{-\sigma_0/(2Q_k)}\).  The finite-view union-support construction from
Theorem 3.4N yields a nonadaptive RLDC over the tagged alphabet with \(Q_k\) queries.
GGS Theorem 1 gives, with \(a_k=\lceil Q_k/\sigma_0\rceil\),

\[
  N_k\ge
  \left(
    \frac{\sigma_0^2 k}
    {38Q_k^4\log_2^2(A_k+2)\log_2^2 k}
  \right)^{1+1/a_k}.
\tag{3.4N'.6}
\]

Let \(D_k\) denote the denominator factor in (3.4N'.6).  The definition of \(H_k\) gives
\(\log_2 D_k=O_{\rho,\sigma_0}(H_k)\).  If
\(Q_kH_k\le\eta\log_2 k\), then \(Q_k\ge1\) and
\[
  \frac{\log_2 k}{a_k}
  \ge \frac{\sigma_0\log_2 k}{2Q_k}
  \ge \frac{\sigma_0}{2\eta}H_k,
\]
whereas taking logarithms in (3.4N'.6) and using
\(N_k\le k(\log_2(k+2))^c\) gives
\[
  \frac{\log_2 k}{a_k}
  \le C_{\rho,\sigma_0,c}H_k.
\]
Choosing \(\eta_*<\sigma_0/(4C_{\rho,\sigma_0,c})\) is a contradiction.  This proves
(3.4N'.2). \(\square\)

The theorem is deliberately source-safe: it uses only the arbitrary finite-alphabet GGS
bound and the explicit finite-view union-support compilation.  It does not use the derived
growing-query DGL transfer.  Its remaining escape classes are therefore exactly a
message-scale alphabet, an unbounded/continuous visible view, selected-policy-only soundness,
target-dependent addressing, or a genuinely new global coupling.

### Proposition 3.4O (selected-policy quantifier gap)

The selected-policy-only quantifier cannot by itself produce a common-proof
RLDC.  More precisely, fix any proof length \(P\), radius \(\rho\ge0\), and
\(\beta<1\).  Let

\[
  \Pi(m)=0^P\qquad(m\in\{0,1\}^k).
\]

Consider a verifier that makes no proof queries, exposes the claimed bit
\(b\), asks for one response bit \(a\), and accepts iff \(a=1\).  For every
target \(m\) and coordinate \(i\), choose the single target-dependent policy

\[
  \tau_{m,i}(b)=\mathbf 1[b=m_i].
\]

The policy is selected before execution but may read the public claim, as a
standard Merlin strategy does.  It accepts the correct claim with probability
one and rejects the wrong claim with probability one on every proof in the
\(\rho\)-ball.  Thus the weak condition

\[
  \forall m,i\;\exists\tau_{m,i}\quad
  [\text{correct completeness and wrong-claim soundness}]
\tag{3.4O.1}
\]

holds with perfect parameters, while the proof map is constant and carries no
message information.  Any target-independent proof/address decoder therefore
has error at least \(1/2\) on a uniform message family and cannot be an RLDC
decoder.

The proposition is a quantifier separation, not an impossibility theorem for
ordinary PCPs: the policy has been allowed to hide the target bit.  To obtain a
meaningful Closure Gate one must add a common selector
\(\exists\tau_m\,\forall i\), target-independent all-policy soundness, a charged
finite pre-coordinate strategy summary, or an equivalent transcript-level ROC
condition.  In particular, replacing C199's global selector by
\(\forall i\exists\tau_{m,i}\) is invalid even when every selected policy is
perfectly coordinate-robust.

The self-contained construction and its relation to the phantom-word example
are recorded in [selected-policy quantifier gap](../../../mcsp-hardness-magnification/notes/269-selected-policy-quantifier-gap-2026-08-17.md).

### Proposition 3.4P (selected-policy entropy--distance barrier)

The target-dependent policy escape has a quantitative cost even without
all-policy soundness.  Let \(C:\mathcal M\to\Sigma^N\) be a common proof map.
For each target \(m\) and coordinate \(i\), choose one policy
\(\tau_{m,i}\), and write \(S(m)=(\tau_{m,1},\ldots,\tau_{m,k})\).  Suppose
that for constants \(\alpha>\beta\) and \(\rho\ge0\), the selected policy
accepts the correct claim on \(C(m)\) with probability at least \(\alpha\), and
accepts the wrong claim with probability at most \(\beta\) on every
\(\rho N\)-near proof.  Then every fiber of \(S\) has minimum proof distance
strictly larger than \(\rho N\).  Hence, with

\[
  t=\left\lfloor\frac{\rho N}{2}\right\rfloor,\qquad
  \operatorname{Vol}_{|\Sigma|}(N,t)
  =\sum_{j\le t}\binom Nj(|\Sigma|-1)^j,
\]

\[
  |\mathcal M|
  \le |\operatorname{supp}S|\,
  \frac{|\Sigma|^N}{\operatorname{Vol}_{|\Sigma|}(N,t)}.
\tag{3.4P.1}
\]

Equivalently, for a uniform message \(M\),

\[
  H(M)\le H(S)+N\log_2|\Sigma|
       -\log_2\operatorname{Vol}_{|\Sigma|}(N,t).
\tag{3.4P.2}
\]

Indeed, two messages in one \(S\)-fiber that differ at coordinate \(i\) would
use the same policy there.  If their proof words were within radius \(\rho N\),
completeness for the second message and wrong-claim soundness for the first
would give the same acceptance probability simultaneously at least
\(\alpha\) and at most \(\beta\).  Sphere packing then gives (3.4P.1).
For binary proofs and \(N=(1+o(1))k\), a constant positive radius forces
\[
  \log_2|\operatorname{supp}S|
  \ge H_2(\rho/2)k-o(k).
\tag{3.4P.3}
\]

This is deliberately weaker than the RLDC closures above: different policy
vectors may serve different targets, so message inlining is unavailable.
It is nevertheless a strict strengthening of Proposition 3.4O.  The latter
uses a policy vector carrying the entire target; Proposition 3.4P proves that
this target information cannot be hidden for free.  The self-contained
statement and proof are in [selected-policy entropy--distance barrier](../../../mcsp-hardness-magnification/notes/270-selected-policy-entropy-distance-barrier-2026-08-17.md).

### Proposition 3.4Q (selected-policy VC lift)

The selected-policy escape can be pushed further when the message family is
the full Boolean cube.  Let \(S(m)=(\tau_{m,1},\ldots,\tau_{m,k})\) be the
selected-policy vector and let \(B=|\operatorname{supp}S|\).  Under the
hypotheses of Proposition 3.4P, assume each fixed policy/claim branch is
nonadaptive and makes at most \(q\) proof queries.  If \(d\) is the maximum
VC dimension of a fiber \(F_s=\{m:S(m)=s\}\), then a shattered coordinate set
in \(F_s\) yields a \(d\)-bit positive-radius RLDC with
\[
  Q=O\!\left(q(\alpha-\beta)^{-2}\right)
\tag{3.4Q.1}
\]
queries.  Indeed, choose one representative in the fiber for every assignment
on the shattered coordinates; the policy at each selected coordinate is then
common to all representatives, so the two claim branches can be thresholded
into an RLDC decoder.

Sauer--Shelah gives
\[
  B\sum_{j=0}^{d}\binom{k}{j}\ge2^k.
\tag{3.4Q.2}
\]
Hence \(B=2^{o(k)}\) forces \(d=\Omega(k)\), and \(B\le2^{\gamma k}\) for
fixed \(\gamma<1\) still forces \(d\ge\delta_\gamma k-o(k)\).  Any applicable
arbitrary-alphabet RLDC lower bound therefore rules out near-linear proof
length for fixed \(q,\rho,\alpha-\beta\) whenever the selected-policy support
is subexponential.  The full proof and the explicit GGS substitution are in
[selected-policy VC lift to an RLDC](../../../mcsp-hardness-magnification/notes/271-selected-policy-vc-lift-to-rldc-2026-08-17.md).
For an adaptive binary branch of depth \(r\), query the union of both decision
trees and replace \(q\) by \(2(2^r-1)\); the same fiber argument is unchanged.

This is a genuine strengthening of Proposition 3.4P: a large policy fiber
does not merely give a distance-separated subfamily; it gives a full
shattered submessage on which the common policy is an RLDC decoder.  The only
remaining finite-policy escape has linear strategy entropy, while an
unbounded or target-dependent address space remains outside the theorem.

### Corollary 3.4Q' (quantitative finite-policy length barrier)

The VC lift gives an explicit exponent. For \(0\le\gamma<1\), let
\(\theta_\gamma\in(0,1/2]\) satisfy
\(H_2(\theta_\gamma)=1-\gamma\), with \(\theta_0=1/2\). If the selected-policy
support obeys \(B\le2^{\gamma k}\), Sauer--Shelah gives
\(d\ge(\theta_\gamma-o(1))k\). Writing
\(a=\lceil Q/\sigma\rceil\), the arbitrary-alphabet GGS lower bound therefore
implies, whenever its radius condition holds,
\[
  N\ge
  \left(
    \frac{c_\gamma\,\sigma^2 k}
    {38 Q^4\log_2^2|\Sigma|\,\log_2^2 k}
  \right)^{1+1/a}
\tag{3.4Q'.1}
\]
for every fixed \(c_\gamma<\theta_\gamma\) and all sufficiently large \(k\).
Thus fixed \(Q,\Sigma,\sigma\) rules out every near-linear bound
\(N\le k\log^C k\), not merely the qualitative statement that \(d\) is
linear. In particular, \(B=2^{o(k)}\) gives the same conclusion with any
fixed \(c_0<1/2\); a sublinear-VC escape must have
\(\log_2B\ge k-o(k)\). This corollary remains conditional on the VC-lift
hypotheses and the GGS radius window, and makes no claim about ordinary dPCPs
outside that model.

### Proposition 3.4R (Shannon-entropy selected-policy lift)

The finite-support assumption can be removed in the low-information regime.
Let \(M\) be uniform on \(\{0,1\}^k\), let \(S=S(M)\) be the selected-policy
vector, and write \(h_S=H_2(S)\). Since the message cube is finite, the image
of \(S\) is finite even when the ambient policy space is not. If
\(p_*=\max_s\Pr[S=s]\), then
\[
  h_S\ge\log_2(1/p_*),
\]
so a fiber \(F_{s_*}\) has \(|F_{s_*}|\ge2^{k-h_S}\). Sauer--Shelah therefore
gives
\[
  \sum_{j=0}^{d_*}\binom{k}{j}\ge2^{k-h_S},
\tag{3.4R.1}
\]
where \(d_*\) is the VC dimension of that fiber. The VC/RLDC construction of
Proposition 3.4Q applies verbatim on \(F_{s_*}\). Hence \(h_S\le\gamma k\)
implies \(d_*\ge(\theta_\gamma-o(1))k\) and the quantitative lower bound
of Corollary 3.4Q' applies; \(h_S=o(k)\) gives
\(d_*\ge(1/2-o(1))k\). Conversely, \(d_*=o(k)\) forces
\[
  h_S\ge k-o(k).
\tag{3.4R.2}
\]
Thus an infinite or continuously indexed policy universe does not evade the
barrier merely by having large support: in the common-address, fixed-branch
model it must carry essentially linear target entropy under the uniform
message distribution. This proposition remains conditional on the explicit
selected-policy robustness hypotheses and does not claim that ordinary dPCPs
satisfy them.

### Proposition 3.4X (quantitative proof--policy information tradeoff)

The preceding entropy statement has an exact proof-length form. Fix a finite proof
alphabet \(\Sigma\) of size \(A\ge2\), a fixed radius \(0<\rho<1\), and a common proof map
\(\Pi:\{0,1\}^{K}\to\Sigma^P\), and supportwise-robust selected policy vectors
\(S=(\tau_{M,1},\ldots,\tau_{M,K})\), with fixed gap.
Assume the amplified branches are nonadaptive with \(Q\) queries and relaxed success
\(\sigma_0\). Define
\[
 \mathcal L_Q(d):=
 \left(
 \frac{\sigma_0^2d}
 {38Q^4\log_2^2(A)\log_2^2(d+2)}
 \right)^{1+1/\lceil Q/\sigma_0\rceil},
\qquad
 d^\star(P):=\max\bigl(\{1\}\cup\{2\le d\le K:P\ge\mathcal L_Q(d)\}\bigr),
\tag{3.4X.1}
\]
for \(K\ge1\). Whenever the fixed-radius hypothesis of
the GGS theorem holds,
\[
 I(M;S)\ge
 K-\log_2\!\left(\sum_{j=0}^{d^\star(P)}\binom Kj\right).
\tag{3.4X.2}
\]
In particular, for fixed \(A,Q,\rho,\alpha-\beta\), if
\(P\le K(\log(K+2))^c\) infinitely often, then
\[
 d^\star(P)\le K^{1/(1+1/\lceil Q/\sigma_0\rceil)}
 (\log K)^{O(1)}=o(K),
\qquad I(M;S)=K-o(K).
\tag{3.4X.3}
\]

To prove this, fix a policy value \(s\) and a fiber
\(F_s=\{m:\Pr[M=m\mid S=s]>0\}\). If \(F_s\) shatters \(d\) coordinates,
choose one representative for each pattern. The common policy on the shattered
coordinates gives a \(Q\)-query relaxed decoder for the resulting \(d\)-bit
proof map. Completeness versus wrong-claim soundness forces its proof image to
have relative distance \(>\rho\), so the GGS lower bound gives \(P\ge\mathcal L_Q(d)\).
Thus every fiber has VC dimension at most \(d^\star(P)\). Sauer--Shelah and
\(H(M\mid S=s)\le\log|F_s|\) give (3.4X.2) after averaging. The asymptotic estimate
in (3.4X.3) follows by substituting
\(d=K^{1/\theta}(\log K)^{O(1)}\), \(\theta=1+1/\lceil Q/\sigma_0\rceil\),
into \(\mathcal L_Q(d)\).

This is a quantitative strengthening of the selected-policy VC lift, not a claim
that GGS state a policy-information theorem. It remains conditional on supportwise
robustness and a common proof/address space; ordinary average/list soundness is not
enough.

### Proposition 3.4Y (information-budget phase diagram)

Proposition 3.4X has an inverse form that makes the proof-length cost of a policy
budget explicit.  Fix \(0\le\gamma<1\), let \(h_2(\vartheta_\gamma)=1-\gamma\) with
\(\vartheta_\gamma\in(0,1/2]\), and suppose \(I(M;S)\le\gamma K\).  Then, for every
fixed \(\varepsilon\in(0,\vartheta_\gamma)\) and all sufficiently large \(K\),
the same supportwise-robust common-proof interface satisfies
\[
 P\ge
 \left(
 \frac{\sigma_0^2(\vartheta_\gamma-\varepsilon)K}
 {38Q^4\log_2^2(A)\log_2^2((\vartheta_\gamma-\varepsilon)K+2)}
 \right)^{1+1/\lceil Q/\sigma_0\rceil}.
\tag{3.4Y.1}
\]
Equivalently, for fixed \(A,Q,\rho,\Delta,\gamma\),
\[
 P\ge c_{\gamma,A,Q,\sigma_0}
       \frac{K^{1+1/\lceil Q/\sigma_0\rceil}}
       {(\log(K+2))^{2+2/\lceil Q/\sigma_0\rceil}}.
\tag{3.4Y.2}
\]
Indeed, \(H(M\mid S)\ge(1-\gamma)K\) gives a fiber of support at least
\(2^{(1-\gamma)K}\).  The binomial entropy form of Sauer--Shelah forces that
fiber to shatter \((\vartheta_\gamma-o(1))K\) coordinates, after which the
GGS RLDC lower bound applies exactly as in Proposition 3.4X.  Thus the theorem
is a continuous information--length phase diagram: a fixed positive fraction of
unpaid target information is incompatible with a near-linear proof.

### Proposition 3.4Z (address-scale descriptor obstruction)

The phase diagram has a direct Gate-II consequence.  Suppose all target-dependent
policy information is carried by a descriptor \(D_n\) with
\(H(D_n)\le b_n\), and, conditional on \(D_n\), the selected policy view \(S_n\)
is generated by a Markov kernel independent of the target.  Then data processing gives
\[
 I(M;S_n)\le b_n.
\tag{3.4Z.1}
\]
Consequently, if \(b_n\le\gamma K_n\) for fixed \(\gamma<1\), Proposition 3.4Y
forces
\[
 P_n\ge
 \left(
 \frac{\sigma_0^2(\vartheta_\gamma-\varepsilon)K_n}
 {38Q^4\log_2^2(A)\log_2^2((\vartheta_\gamma-\varepsilon)K_n+2)}
 \right)^{1+1/\lceil Q/\sigma_0\rceil}.
\tag{3.4Z.2}
\]
Thus if \(b_n=o(K_n)\), a fixed-alphabet, fixed-locality common-proof interface
cannot have \(P_n\le K_n\operatorname{polylog}K_n\) on an infinite sequence.  In
particular, a \(\operatorname{poly}(n)\)-bit descriptor, cover index, canonical
key, or finite strategy summary cannot close an address-scale attachment whose
payload \(K_n\) dominates every fixed polynomial in the final input scale \(n\).
The only remaining Gate-II options are message-scale descriptor information,
address-dependent/unbounded state, or exit from the common-proof/supportwise model.

### Proposition 3.4ZA (address-surface closure for per-address strategies)

The address-dependent option can be charged without assuming that one strategy is shared
by all addresses. Let \(H_n\in\{0,1\}^{N_n}\), let
\(\ell_n=\lceil\log_2N_n\rceil\), and, for each address \(a\), let
\(\mathcal S_{n,a}\) be an arbitrary finite response strategy. Write
\(W_n(a,R)\) for the verifier's acceptance bit on the fixed target proof when
\(\mathcal S_{n,a}\) is used with public randomness \(R\). Assume that the joint Boolean
surface \((a,R)\mapsto W_n(a,R)\) has fan-in-two circuit complexity \(U_n\), and that
\(\gamma=\alpha-\beta>0\) satisfies
\[
H_n[a]=1\Longrightarrow\Pr_R[W_n(a,R)=1]\ge\alpha,\qquad
H_n[a]=0\Longrightarrow\Pr_R[W_n(a,R)=1]\le\beta.
\tag{3.4ZA.1}
\]

For every \(0<\delta<1\), choose
\[
t_n=O\!\left(\frac{\ell_n+\log(1/\delta+2)}{\gamma^2}\right).
\tag{3.4ZA.2}
\]
A Hoeffding bound and a union bound over the \(N_n\) valid addresses give a multiset
of \(t_n\) public tapes for which all empirical acceptance rates are within
\(\gamma/3\) of their expectations. Hardwiring those tapes and thresholding at
\((\alpha+\beta)/2\) yields a circuit for \(H_n\) of size
\[
\operatorname{CC}(H_n)
 \le O\!\left(t_n\bigl(U_n+\log(t_n+2)\bigr)\right).
\tag{3.4ZA.3}
\]
The counter and comparator contribute \(O(t_n\log(t_n+2))\) gates.

Consequently, if \(\operatorname{CC}(H_n)>S_n\), then
\[
U_n\ge \frac{S_n}{O(t_n)}-\log(t_n+2).
\tag{3.4ZA.4}
\]
At a stable RW stage, \(\ell_n=\Theta(\log n_i)\). Thus a near-maximum forcing scale
\(S_i=2^{\Theta(\ell_n)}/\operatorname{poly}(\ell_n)\) forces
\(U_i=2^{\Theta(\ell_n)}/\operatorname{poly}(\ell_n)\). This permits unrelated
\(\mathcal S_{n,a}\) for different addresses; the only charged object is their joint
acceptance surface. A polynomial-size address/randomness generator is consequently
excluded, while an arbitrary address-indexed strategy survives only by carrying
object-scale Boolean complexity or by leaving the finite Boolean model.

This is an extension of Proposition 5.0C beyond a common strategy, but it remains a
single-table forcing theorem, not a family-level RLDC or an unconditional \(P\ne NP\)
result. It uses only the fixed-target acceptance gap; it does not claim that the
published RW Reconf object has a low-complexity acceptance surface.

### Proposition 3.4ZB (address-scale PH-surface closure)

The Boolean-surface hypothesis can be weakened to a fixed-depth
polynomial-hierarchy description, provided the description is single-valued and
still lives at the base/address scale. Let \(H_n\in\{0,1\}^{N_n}\), let
\(\ell_n=\lceil\log_2(N_n+1)\rceil\), and allow an unrelated finite response
strategy for each address. Suppose the selected acceptance bit
\[
W(1^n,a,R)\in\{0,1\}
\]
is one uniform predicate in a fixed level of \(\mathrm{PH}\), with address,
random tape, quantified strings, and matrix computation all of size
\(n^{O(1)}\). Assume a fixed gap \(\gamma=\alpha-\beta>0\) such that
\[
H_n[a]=1\Longrightarrow\Pr_R[W(1^n,a,R)=1]\ge\alpha,\qquad
H_n[a]=0\Longrightarrow\Pr_R[W(1^n,a,R)=1]\le\beta.
\tag{3.4ZB.1}
\]

Under \(P=NP\), \(\mathrm{PH}=P\), so \(W\) has a uniform
\(n^{O(1)}\)-time evaluator. Sampling
\[
t_n=O\!\left(\frac{\ell_n+\log(1/\delta+2)}{\gamma^2}\right)
\tag{3.4ZB.2}
\]
public tapes and applying Hoeffding plus a union bound gives
\[
\operatorname{CC}(H_n)
\le O\!\left(t_n\bigl(n^{O(1)}+\log(t_n+2)\bigr)\right)
=n^{O(1)}.
\tag{3.4ZB.3}
\]
Consequently, any forcing family with
\(\operatorname{CC}(H_n)>n^c\) for every fixed \(c\) on infinitely many lengths
would imply \(P\ne NP\).  A near-maximum threshold
\(N_n/\operatorname{polylog}N_n\) has this property whenever
\(N_n=2^{\Omega(n^\eta)}\) for some fixed \(\eta>0\).

This allows different strategies at different addresses, but it requires one
single-valued PH surface.  The weaker quantifier
\(\forall a\,\exists\mathcal S_a\) does not define such a surface: incompatible
addresswise witnesses may create a phantom word.  The proposition therefore
does not claim that published RW Reconf has an address-scale PH surface, nor
does it assert a general dPCP/RLDC impossibility.  Its scope and exact
quantifier boundary are recorded in [note 354](../../../mcsp-hardness-magnification/notes/354-address-scale-ph-surface-closure-2026-08-18.md).

The scale qualification is essential.  Ren--Williams Theorem 4.1 permits a
Merlin circuit witness of size \(k'=O(k^4\log(t+2))\) in the final query.  At a
stable stage of the recurrence, the forced \(2n_i\)-bit table has address
length \(\ell_i=\Theta(\log n_i)\), while the next decoder width is
\(k=n_{i+1}=n_i^C=2^{\Theta(\ell_i)}\).  A direct use of the published Reconf
therefore yields an object-scale quantified predicate, not the
\(\ell_i^{O(1)}\)-scale PH surface assumed above.  PH collapse simplifies a
predicate at its representation scale; it does not compress a \(k'\)-bit
witness into an address-scale evaluator.  Establishing that compression, or
proving an object-scale lower bound for it, is a separate closure theorem and
is not supplied by Proposition 3.4ZB.

The same argument gives a quantitative version.  Let a fixed-depth PH surface use a
length-\(d_n\) descriptor \(\sigma_n\), and let \(L_n\) bound the combined length of the
address, random tape, descriptor, quantified strings, and matrix description.  If the
deterministic evaluator supplied by \(P=NP\) has time \(L^{c_*}\) for a fixed exponent
\(c_*\), then
\[
\operatorname{CC}(H_n)
\le O\!\left(t_n\bigl(L_n^{c_*}+\log(t_n+2)\bigr)\right),
\qquad
t_n=O\!\left(\frac{\ell_n+\log(1/\delta+2)}{\gamma^2}\right).
\tag{3.4ZB.4}
\]
Hence a forcing bound \(\operatorname{CC}(H_n)>S_n\) implies
\[
P\ne NP
\quad\text{or}\quad
L_n=\Omega\!\left((S_n/t_n)^{1/c_*}\right)
\tag{3.4ZB.5}
\]
up to the counter/comparator overhead.  In particular, if
\(S_n=2^{\Omega(\ell_n)}\) and \(t_n=\operatorname{poly}(\ell_n)\), a surviving
surface must have \(2^{\Omega(\ell_n)}\)-scale quantified input or matrix data.  This
quantitative trichotomy is why an object-scale witness cannot be treated as an
address-scale PH surface merely because the quantifier depth is fixed.


### Proposition 3.4ZC (vanishing-gap address-surface tradeoff)

The sampling argument in Proposition 3.4ZA also gives a quantitative boundary when
the acceptance gap is allowed to depend on the table length.  Let
\(\gamma_n=\alpha_n-\beta_n>0\) and let \(U_n\) be the fan-in-two complexity
of the joint address--randomness surface.  For every fixed \(0<\delta<1\),
Hoeffding plus a union bound gives
\[
\operatorname{CC}(H_n)
\le
C\,\frac{\ell_n+\log(1/\delta+2)}{\gamma_n^2}
\left(
U_n+
\log\!\left(
\frac{\ell_n+\log(1/\delta+2)}{\gamma_n^2}+2
\right)
\right),
\tag{3.4ZC.1}
\]
where \(\ell_n=\lceil\log_2(N_n+1)\rceil\).  This statement allows an
unrelated finite response strategy at every address; only the joint surface is
charged.

In particular, suppose that on the hard-length subsequence
\[
\operatorname{CC}(H_n)\ge N_n/\ell_n^c,
\qquad
U_n\le\ell_n^d
\tag{3.4ZC.2}
\]
for fixed constants \(c,d\).  Then every fixed inverse-polynomial address
gap \(\gamma_n\ge\ell_n^{-q}\) is impossible for all sufficiently large
lengths.  More sharply, for every fixed \(\varepsilon>0\),
\[
\gamma_n\ge N_n^{-1/2+\varepsilon}
\]
is also impossible; hence any surviving address-scale surface satisfies
\(\gamma_n\le N_n^{-1/2+o(1)}\) along the hard subsequence.

The proof is direct: the required sample size is
\(O((\ell_n+\log(1/\delta+2))/\gamma_n^2)\).  Under an inverse-polynomial
address gap the resulting circuit has size \(\ell_n^{O(1)}\), while under
\(\gamma_n\ge N_n^{-1/2+\varepsilon}\) it has size
\(N_n^{1-2\varepsilon}\ell_n^{O(1)}=o(N_n/\ell_n^c)\).  Thus vanishing gap is
not a free address-scale escape: it must cross the square-root sampling
boundary, or the surface itself must pay object-scale complexity.  This is a
single-table parameter theorem, not a general dPCP impossibility or an
unconditional \(P\ne NP\) proof.  The full statement and RW specialization are
recorded in [note 355](../../../mcsp-hardness-magnification/notes/355-vanishing-gap-address-surface-trichotomy-2026-08-18.md).

### Proposition 3.4S (adaptive selected-policy barrier)

The selected-policy VC lift does not require an exponential decision-tree
expansion when the variable-query adaptive barrier is used. Suppose the fixed
policy/claim branches have adaptive depth \(r\) and gap
\(\Delta=\alpha-\beta>0\). On the shattered fiber, repeat each branch
\(O(\Delta^{-2})\) times and threshold its empirical acceptance at
\((\alpha+\beta)/2\). This gives correct acceptance at least \(2/3\), wrong
acceptance at most \(1/3\) on the same positive-radius neighborhood, with
adaptive depth
\[
  \ell=O(r\Delta^{-2}).
\tag{3.4S.1}
\]
The resulting message-inline decoder is therefore covered by Theorem 3.4D''.
If \(N\le d(\log d)^C\) infinitely often for fixed finite alphabet and radius,
\[
  \ell\log(\ell+2)=\Omega\!\left((\log d)^{1/3}\right).
\tag{3.4S.2}
\]
For fixed \(\Delta\), this is \(r\log(r+2)=\Omega((\log d)^{1/3})\).
Thus whenever the entropy/VC argument gives \(d=\Omega(k)\) and
\(N\le k(\log k)^C\), adaptive selected-policy locality
\(r=o((\log k)^{1/3}/\log\log k)\) is impossible. Unlike the elementary
adaptive extension above, this conclusion does not replace \(r\) by
\(2(2^r-1)\). It remains conditional on the selected-policy robustness
hypotheses and Theorem 3.4D''. In particular, Proposition 3.4Y's budget
\(I(M;S)\le\gamma k<k\) supplies \(d=\Omega_\gamma(k)\), so the same adaptive
locality conclusion holds with constants depending on \(\gamma\).

### Proposition 3.4T (randomized selected-policy mutual-information lift)

The entropy lift extends to randomized target-dependent policy selection when
the observable policy view is finite. Let \(\mathcal S\) be a finite set of
policy vectors, let \(M\) be uniform on \(\{0,1\}^k\), and for each \(m\) draw
\(S\sim\mu_m\) on \(\mathcal S\). Assume every pair \((m,s)\) with
\(\mu_m(s)>0\) satisfies the same selected-policy completeness and
target-relative wrong-claim soundness hypotheses, with gap
\(\alpha-\beta>0\). Write \(I_S=I(M;S)\). Since
\[
  H(M\mid S)=k-I_S,
\]
some \(s_*\) has \(H(M\mid S=s_*)\ge k-I_S\). Its conditional support
\(F_{s_*}=\{m:\mu_m(s_*)>0\}\) therefore obeys
\[
  |F_{s_*}|\ge2^{k-I_S}.
\tag{3.4T.1}
\]
Sauer--Shelah and Proposition 3.4Q now give the same VC/RLDC lift with
\(\log B\) replaced by \(I_S\). In particular, \(I_S\le\gamma k\) yields
\(d\ge(\theta_\gamma-o(1))k\) and Corollary 3.4Q' applies; \(I_S=o(k)\)
gives \(d\ge(1/2-o(1))k\); and sublinear VC dimension forces
\(I_S\ge k-o(k)\). Hence target-independent randomization cannot be an
additional escape once every policy in the selected support is robust.
An average-over-policies guarantee is weaker and does not imply this
supportwise hypothesis; that distinction is exactly the quantifier gap in
Proposition 3.4O.

### Proposition 3.4U (average policy-goodness to a common robust fiber)

The supportwise hypothesis in Proposition 3.4T can be weakened, but only at
the level of a policy-good event.  Let \(M\) be uniform on
\(\{0,1\}^k\), let \(S\) be a standard-Borel observable policy view, and for
each \(m\) draw \(S\sim\mu_m\).  Assume the robustness event
\(\mathsf{Rob}(m,s)\) is measurable and regular conditional distributions
exist.  The event denotes the full
simultaneous coordinate-robust statement for policy vector \(s\): the common
proof map is used for every coordinate, correct acceptance is at least
\(\alpha\), and wrong-claim acceptance is at most \(\beta<\alpha\) on the
target-relative \(\rho N\)-ball.  Suppose

\[
  \Pr_{S\sim\mu_m}[\mathsf{Rob}(m,S)]\ge1-\varepsilon
  \qquad\text{for every }m,
  \tag{3.4U.1}
\]

with \(0\le\varepsilon<1/2\).  Put \(I=I(M;S)\).  Then some policy value
\(s_*\) has a good fiber

\[
  F_{s_*}:=\{m:\mu_m(s_*)>0\text{ and }\mathsf{Rob}(m,s_*)\}
\]

of size

\[
  |F_{s_*}|\ge
  2^{\,k-(I+h_2(\varepsilon))/(1-\varepsilon)}.
  \tag{3.4U.2}
\]

Indeed, let \(G=\mathbf 1[\mathsf{Rob}(M,S)]\) and \(p=\Pr[G=1]\).  Then
\(p\ge1-\varepsilon\), \(H(M\mid S)=k-I\), and

\[
  H(M\mid S,G)\ge k-I-H(G)\ge k-I-h_2(\varepsilon).
\]

Writing \(H_1=H(M\mid S,G=1)\) and \(H_0=H(M\mid S,G=0)\), the bound
\(H_0\le k\) yields

\[
  pH_1+(1-p)H_0\le pH_1+(1-p)k,
  \qquad
  H_1\ge k-\frac{I+h_2(\varepsilon)}p
       \ge k-\frac{I+h_2(\varepsilon)}{1-\varepsilon}.
\]

Some \(s_*\) has \(H(M\mid S=s_*,G=1)\ge H_1\), and conditional entropy is at
most the logarithm of the conditional support \(F_{s_*}\), proving (3.4U.2).

If \(d_*\) is the VC dimension of \(F_{s_*}\), Sauer--Shelah gives

\[
  \sum_{j\le d_*}\binom{k}{j}\ge
  2^{\,k-(I+h_2(\varepsilon))/(1-\varepsilon)}.
  \tag{3.4U.3}
\]

Consequently the VC/RLDC lift and the GGS length bound of Proposition 3.4Q
apply on this one common robust fiber.  In particular, \(I=o(k)\) and
\(\varepsilon=o(1)\) give \(d_*\ge(1/2-o(1))k\), while
\(I\le\gamma(1-\varepsilon)k\) gives the same linear-VC conclusion as an
entropy deficit \(\gamma\), up to the negligible \(h_2(\varepsilon)\) term.

There is an operational defect formulation.  Define

\[
\mathcal D(m,s):=
\max\!\left\{
\max_i(\alpha-\operatorname{Comp}_{m,i,s})_+,\,
\max_{\substack{i,z:\\d(z,\Pi(m))\le\rho N}}
(\operatorname{WrongAcc}_{m,i,s}(z)-\beta)_+
\right\}\in[0,1].
\tag{3.4U.4}
\]

If \(\mathbb E_{S\sim\mu_m}\mathcal D(m,S)\le\eta\Delta\) for every \(m\), and
\(0<\Delta<(\alpha-\beta)/2\), Markov's inequality gives a policy-good mass
at least \(1-\eta\).  Proposition 3.4U then applies with
\(\alpha'=\alpha-\Delta\), \(\beta'=\beta+\Delta\), and gap
\(\alpha'-\beta'=\alpha-\beta-2\Delta>0\).  This is the safe
average-to-supportwise conversion: the worst coordinate and worst nearby
proof must be taken inside the defect before averaging over policies.
Coordinate-wise or proof-wise averages do not imply (3.4U.4), and the
phantom-witness quantifier gap remains.

This proposition is deliberately narrower than an average acceptance theorem.
Bounds on \(\mathbb E_S[\operatorname{Acc}(m,S)]\) for the correct and wrong
claims do not imply (3.4U.1): policies may trade coordinates or use different
target-dependent witnesses.  Thus Proposition 3.4U closes precisely the
average-to-supportwise gap, but it does not upgrade ordinary list or
distributional soundness to a global word.  Finiteness of the policy view is
not needed; the standard-Borel assumption supplies the regular conditional
law.  Nonmeasurable or non-standard interactive strategy objects remain
outside this theorem.

### Proposition 3.4V (mutual-information mixture closure)

The previous proposition can be strengthened without requiring any policy in
the target-dependent support to be individually robust.  Let \(M\) be uniform
on \(\{0,1\}^k\), let \(S\mid M=m\sim\mu_m\) on a standard-Borel policy space,
and let \(\bar\mu=\mathcal L(S)\).  Use the defect functional
\[
\mathcal D(m,s):=
\max\!\left\{
\max_i(\alpha-\operatorname{Comp}_{m,i,s})_+,\,
\max_{\substack{i,z:\\d(z,\Pi(m))\le\rho N}}
(\operatorname{WrongAcc}_{m,i,s}(z)-\beta)_+
\right\}.
\tag{3.4V.1}
\]
Set
\[
\bar\delta=\mathbb E_M\mathbb E_{S\sim\mu_M}\mathcal D(M,S),
\qquad
I=I(M;S),
\qquad
\tau=\bar\delta+\sqrt{\frac{\ln2}{2}I}.
\tag{3.4V.2}
\]
For every \(0<\Delta<(\alpha-\beta)/2\) with \(\tau<\Delta\), there is a
subfamily \(\mathcal M_\Delta\) of size
\[
|\mathcal M_\Delta|\ge(1-\tau/\Delta)2^k
\tag{3.4V.3}
\]
such that the single target-independent mixture \(S\sim\bar\mu\) has
\[
\mathbb E_{\bar\mu}\operatorname{Comp}_{m,i,S}\ge\alpha-\Delta,
\qquad
\mathbb E_{\bar\mu}\operatorname{WrongAcc}_{m,i,S}(z)\le\beta+\Delta
\tag{3.4V.4}
\]
for every \(m\in\mathcal M_\Delta\), coordinate \(i\), and
\(\rho N\)-near proof \(z\).  The resulting mixture gap is
\(g_\Delta=\alpha-\beta-2\Delta>0\).

To prove this, write
\(\bar D_m=\mathbb E_{S\sim\bar\mu}\mathcal D(m,S)\).  Pinsker, Jensen, and
the mutual-information identity give
\[
\mathbb E_M\bar D_M
\le\bar\delta+\mathbb E_M\operatorname{TV}(\mu_M,\bar\mu)
\le\bar\delta+\sqrt{\frac{\ln2}{2}I}
=\tau.
\tag{3.4V.5}
\]
Markov leaves the subfamily (3.4V.3) on which \(\bar D_m\le\Delta\), and the
definition of \(\mathcal D\) gives (3.4V.4).

The mixture is a target-independent randomized branch.  After the usual
constant-gap amplification, message inlining gives a randomized RLDC with
\[
Q=O(qg_\Delta^{-2})
\tag{3.4V.6}
\]
proof queries on \(\mathcal M_\Delta\).  If \(\tau/\Delta\le1/2\), Sauer--Shelah
gives a shattered coordinate set of size \(d\ge(1/2-o(1))k\), so the GGS
length lower bound applies to the restricted subcode.  This is stronger than
Proposition 3.4U: it uses an average worst-case defect, not a policy-good
support event.  It is information-theoretic unless the marginal law
\(\bar\mu\) has a uniform sampler or an address-scale representation; without
that algorithmic condition it is a semantic mixture closure rather than an
explicit decoder.  Coordinate-wise or proof-wise averages do not control the
maximal defect in (3.4V.1), so ordinary list/distributional soundness still does
not imply this proposition.

If a public uniform sampler \(\operatorname{Sam}(m;r)\) returns an executable
policy view with law \(\mu_m\), then sampling an independent dummy
\(U\leftarrow\{0,1\}^k\) and returning \(\operatorname{Sam}(U;r)\) samples
\(\bar\mu\) exactly.  Hence the usual uniformity of the target-dependent
policy selector is already sufficient for the algorithmic RLDC conclusion;
the dummy message is internal randomness and is not compared with the encoded
message.

### Theorem 3.4W (uniformization--Lorenz query-peak trichotomy)

Fix \(0<\rho<1\), \(c\ge0\), and a common proof map
\(\Pi_k:\{0,1\}^k\to\Sigma^{N_k}\) with
\[
  N_k\le k(\log(k+2))^c.
\tag{3.4W.1}
\]
Let \(\mathcal Z_k\) be a Hamming-connected target-relative near-proof family
to which the connected-neighborhood transcript theorem applies.  Write
\[
  \alpha_k=\varepsilon_k+
  \sqrt{\frac{\ln2}{2}\,\iota_k},
  \qquad
  \delta_k=\Delta_{\lambda_k}(\mathcal Y_k)-2\alpha_k>0,
\tag{3.4W.2}
\]
for its information/separation margin.  Let \(h_k\) be the maximum, over the
near-proof family and all honest proof states \(\Pi_k(m)\), of the probability
that a decoder queries one fixed proof position.

Assume that a common word supplied by the connected-neighborhood theorem is
target-bound to \(\Pi_k\), with honest decoder error at most \(\epsilon_k\),
and that the pathwise Lorenz/DGL implication
\[
  \epsilon_k+\Lambda_{\rho,k}\le\frac1{12}
  \quad\Longrightarrow\quad
  r_k\log(r_k+2)\ge
  \eta(\rho,c)(\log(k+2))^{1/3}
\tag{3.4W.3}
\]
holds for this common-proof family.  Then every sufficiently large \(k\) satisfies
at least one of
\[
\begin{array}{ll}
\mathrm{(P)} & h_k\ge\delta_k,\\
\mathrm{(L)} & \epsilon_k+\rho N_k r_k h_k>\dfrac1{12},\\
\mathrm{(Q)} & r_k\log(r_k+2)\ge
       \eta(\rho,c)(\log(k+2))^{1/3},
\end{array}
\tag{3.4W.4}
\]
or else one of the connected-neighborhood, separation, or target-binding
hypotheses fails.

Indeed, if (P) fails, connected-neighborhood uniformization gives one common
word.  For an honest transcript, the expected number of occurrences of any
position is at most \(r_kh_k\), so the top-\(\rho N_k\) Lorenz mass obeys
\[
  \Lambda_{\rho,k}\le\rho N_k r_k h_k.
\tag{3.4W.5}
\]
If (L) also fails, (3.4W.3) forces (Q), proving the trichotomy.  The definition
of \(h_k\) includes honest proof states because the connected neighborhood need
not contain every exact codeword.

If, in addition, first-hit patchability has forcing constant \(\gamma_k\) and
target error \(\beta_k<\gamma_k\delta_k\), then the no-common-word branch is
impossible.  Under this extra source-specific condition, a low-locality
near-linear construction must pay (L), pay (Q), or leave the common-word
interface.  This is a synthesis of the transcript-uniformization and
pathwise-Lorenz gates, not an unconditional dPCP impossibility theorem.

In the canonical code-image specialization
\(\mathcal Y_k=\operatorname{Im}(\Pi_k)\), target-binding is automatic:
the common valid word supplied by the transcript theorem is by definition
\(\Pi_k(m^\star)\) for some \(m^\star\). Hence the only non-coding hypotheses
left in Theorem 3.4W are the connected-neighborhood transcript/separation
conditions; first-hit patchability then removes the no-common-word branch
without requiring a separate target-binding lemma. This specialization is
important because it distinguishes a genuine proof-code image from an
auxiliary dPCP valid-word family that may contain words not realized by
\(\Pi_k\).

There is also a coding-scale collapse of the peak branch.  If \(\Pi_k\) is
injective, \(A_k:=|\Sigma_k|\ge2\), and \(r_k\ge1\), then
\[
  A_k^{N_k}\ge2^k,\qquad N_k\ge k/\log_2 A_k.
\tag{3.4W.6}
\]
Therefore, whenever
\(\rho\delta_k k/\log_2 A_k>1/12\), the peak alternative
\(h_k\ge\delta_k\) already implies
\(\epsilon_k+\rho N_kr_kh_k>1/12\).  In particular, for constant
\(\delta_k\) and \(\log A_k=o(k)\), first-hit patchability is not needed for
the length/locality conclusion: the only remaining exits are transcript or
separation failure, Lorenz mass, or growing locality.  Patchability is still
needed only if the peak itself is to be converted into a semantic
wrong-output lower bound.

### Theorem 3.4D'
Fix a finite proof alphabet \(\Sigma\), constants \(0<\rho<1\) and
\(\sigma_0>0\), and \(c>0\).  Let
\(\Pi:\{0,1\}^k\to\Sigma^P\) be a common proof map.  For each message
coordinate \(i\) and claim \(b\), suppose the verifier is adaptive, makes at
most \(r=r(k)\) proof-symbol queries, accepts the correct claim with perfect
completeness, and accepts every wrong claim with probability at most
\(1-\sigma_0\) on the target-relative \(\rho\)-ball.  Assume that both bit
values occur in every nonconstant coordinate.  If
\(\Pi(m)=\Pi(m')\) for two messages differing in a nonconstant coordinate,
completeness for one message would contradict wrong-claim soundness for the
other at distance zero; hence \(\Pi\) is injective and
\(P\ge k/\log_2|\Sigma|\).  If

\[
  P\le k(\log k)^c
\tag{3.4D'.1}
\]

on infinitely many sufficiently large lengths, then

\[
  r\log(r+2)=\Omega_{\rho,\sigma_0,\Sigma,c}
       \bigl((\log k)^{1/3}\bigr).
\tag{3.4D'.2}
\]

In particular, \(r=\Omega((\log k)^{1/3}/\log\log k)\).  This bound is
strictly stronger than the decision-tree threshold in Theorem 3.4D for
large \(k\), because it preserves adaptivity instead of replacing a depth-\(r\)
branch by \(2^{\Theta(r)}\) nonadaptive query sets.

#### Proof

Repeat each claim branch a fixed number \(t=t(\sigma_0)\) of times and accept
only when all repetitions accept.  Then the wrong-claim probability is at
most \(1/3\), while perfect completeness is preserved.  Running both claim
branches gives a binary-output relaxed local decoder over \(\Sigma\)-valued
proof symbols, with locality

\[
  \ell\le 2tr.
\tag{3.4D'.3}
\]

On each random tape it outputs \(b\) exactly when the \(b\)-branch accepts
and the \(1-b\)-branch rejects, and otherwise outputs \(\bot\).  Thus the
correct branch is complete on the codeword, while on every proof in the
\(\rho\)-ball the wrong output can occur only when the wrong branch accepts.

On a proof within distance \(\rho P\) of \(\Pi(m)\), the wrong branch remains
bounded by \(1/3\); hence the decoder outputs the wrong bit only with the
constant amplification error.  This is exactly the target-relative relaxed
LDC interface, with the same valid codeword set and positive robustness
radii.  The variable-query relaxed-DGL transfer in
[note 255](../../../mcsp-hardness-magnification/notes/255-variable-query-relaxed-dgl-theorem-2026-08-17.md)
normalizes this decoder to

\[
  Q\le C_{\Sigma}\ell\log(\ell+2)
\tag{3.4D'.4}
\]

queries and, whenever \(Q^3\le\eta\log P\) for the fixed constant
\(\eta=\eta(\rho,\Sigma)>0\), gives a sample decoder.  For a fixed finite
\(\Sigma\), its shared-sample information bound is
\((2/3)2^k\le|\Sigma|^S\), so the finite-alphabet form of note 255 rules
out (3.4D'.1).  Since \(P\ge k/\log_2|\Sigma|\) for an injective proof map,
(3.4D'.1) implies \(\log P\le2\log k\) for large \(k\).  Therefore any
family satisfying (3.4D'.1) must have

\[
  Q^3>\eta\log P\ge\eta\log k.
\tag{3.4D'.5}
\]

Combining (3.4D'.4)--(3.4D'.5) with (3.4D'.3) yields
\(\ell\log(\ell+2)=\Omega((\log k)^{1/3})\), and hence (3.4D'.2).
\(\square\)

This theorem is a derived variable-query consequence of the DGL proof
ingredients, not a claim that the DGL source states the growing-\(Q\) theorem.
It is a direct adaptive barrier: no decision-tree expansion, nonadaptive
compiler, or fixed-query assumption is used.  Its scope is correspondingly
precise—finite \(\Sigma\), positive target-relative radius, common proof map,
and a fixed soundness gap.

### Theorem 3.4D'' (high-confidence imperfect completeness needs no resampling)

The variable-query barrier also survives imperfect completeness in the high-confidence
region, without running a branch more than once.  Fix a finite proof alphabet
\(\Sigma\) of size \(A\ge2\), constants \(0<\rho<1\), \(c>0\), and

\[
  \alpha\ge\frac23,
  \qquad
  \beta\le\frac13.
\]

Let \(\Pi:\{0,1\}^k\to\Sigma^P\) be a common proof map.  For every message
coordinate \(i\) and claim \(b\), let \(V_{i,b}\) be an adaptive verifier making at most
\(r=r(k)\) proof-symbol queries, and assume

\[
  p_{i,m_i}(\Pi(m))\ge\alpha,
  \qquad
  d_H(z,\Pi(m))\le\rho P
    \Longrightarrow p_{i,1-m_i}(z)\le\beta .
\tag{3.4D''.1}
\]

Assume both message values occur in every nonconstant coordinate.  If the tagged inline
length \(N=k+P\) satisfies \(N\le k(\log k)^c\) on infinitely many sufficiently large
lengths, then

\[
  r(k)\log(r(k)+3)
    =\Omega_{A,\rho,c}\bigl((\log k)^{1/3}\bigr).
\tag{3.4D''.2}
\]

This conclusion is genuinely no-resampling: one random tape and one execution of the
selected branch suffice.

#### Proof

Because \(\alpha>\beta\), two distinct messages cannot have proof words at distance at
most \(\rho P\): choose a differing coordinate and apply (3.4D''.1) in the two opposite
directions.  The Singleton bound therefore gives \(P/(k+P)\ge c_\rho>0\) for all large
\(k\).  Hence there is a fixed \(\delta_0=\delta_0(\rho)>0\) such that a word within
relative distance \(\delta_0\) of \(C(m):=m\Vert\Pi(m)\) has proof suffix within the
\(\rho\)-ball around \(\Pi(m)\).

Define a relaxed local decoder over the disjoint alphabet
\(\Gamma:=\Sigma\sqcup\{0,1\}\) as follows.  On coordinate \(i\), read the inline symbol
\(b=y_i\), run \(V_{i,b}\) once on the proof suffix, output \(b\) if the branch accepts,
and output \(\bot\) otherwise.  On \(C(m)\), the inline bit is correct and the decoder
outputs it with probability at least \(\alpha\ge2/3\).  On a word in the
\(\delta_0\)-ball, a wrong inline bit can produce a wrong output only when the wrong
branch accepts, which is at most \(\beta\le1/3\); a correct inline bit never produces a
wrong output.  Thus this is a variable-query relaxed local algorithm with locality
\(\ell\le r+1\), fixed positive radius, and error at most \(1/3\), with no fresh branch
resampling.

Apply the derived variable-query relaxed-DGL theorem from [note 255](../../../mcsp-hardness-magnification/notes/255-variable-query-relaxed-dgl-theorem-2026-08-17.md)
over the fixed alphabet \(|\Gamma|=A+2\).  Its normalized parameter satisfies
\[
  Q\le C_A(r+1)\log(r+3).
\]
In the window \(Q^3=o(\log N)\), the shared-sample argument gives
\(N\ge k^{1+\Omega_{A,\rho}(1/Q^2)}\), contradicting
\(N\le k(\log k)^c\).  The quantitative form of the same theorem therefore forces
\(Q=\Omega_{A,\rho,c}((\log k)^{1/3})\), which implies (3.4D''.2).
\(\square\)

The theorem closes the high-confidence no-resampling part of the imperfect-completeness
region.  It does not cover \(\alpha<2/3\) or \(\beta>1/3\); those require either a
static postprocessing condition such as Theorem 3.4J or an additional amplification/
outer-coding mechanism.

#### Source-status audit for the parameterized transfer

The source split matters here. Dall'Agnol--Gur--Lachish's Theorem 6.1 is a
variable-query theorem for their general robust-local model: after the source
error/randomness reduction, its normalized query parameter is
\(q=O(\ell\log\ell)\) and the displayed sample factor is
\(O(|\Sigma|^q\log|\Sigma|)N^{1-1/(2q^2)}\). Their relaxed-local application,
Theorem 7.7 (and the relaxed-LDC Corollary 7.8), is stated with
\(\ell=O(1)\). Proposition 3.4D' therefore does not merely cite the relaxed
application with a growing query count: it supplies the missing parameter audit
for the two-output relaxed construction. The audit is exactly the finite-
alphabet growth window \(Q^3=o(\log P)\) and the uniform kernel/Chernoff checks
recorded in [note 255](../../../mcsp-hardness-magnification/notes/255-variable-query-relaxed-dgl-theorem-2026-08-17.md).
Accordingly, the proposition should be cited as a derived parameterized
relaxed-DGL theorem, not as a theorem already stated in the source paper.

### Theorem 3.4E (smooth finite-alphabet one-query exponential closure)

There is a sharper route split at the one-proof-symbol level.  Fix a finite proof alphabet
\(\Sigma\) of size \(A\ge2\), constants \(0<\rho<1\), \(\beta<1/2\), and
\(\lambda\ge1\).  Let \(\Pi:\{0,1\}^k\to\Sigma^P\) be a common proof map.  For every
coordinate \(i\) and claim \(b\), suppose \(V_{i,b}\) makes at most one proof-symbol query.
On a random tape that queries position \(j\), write \(S\subseteq\Sigma\) for the set of
symbols on which that tape accepts, so the tape has typed query \(t=(j,S)\).  Assume

\[
 p_{i,m_i}(\Pi(m))=1,
 \qquad
 d_H(z,\Pi(m))\le \rho P
   \Longrightarrow p_{i,1-m_i}(z)\le\beta,
 \tag{3.4E.1}
\]

and the typed-query smoothness condition

\[
 \Pr_R[t=(j,S)]\le\lambda/P
 \quad\text{for every }i,b,j,S.
 \tag{3.4E.2}
\]

Then the binary expansion which stores, at every proof position, all subset-membership
bits \(\mathbf 1[\Pi(m)_j\in S]\), together with the inline message, is a perfect-complete
weak adaptive two-query Hamming RLDC of some constant positive radius and success
\(\alpha>1/2\).  Consequently

\[
 k+2^A P\ge 2^{\Omega_{A,\rho,\beta,\lambda}(k)},
 \qquad
 P\ge 2^{\Omega_{A,\rho,\beta,\lambda}(k)}.
 \tag{3.4E.3}
\]

#### Proof sketch

Condition (3.4E.1) first forces distinct proof words to have symbol distance \(>\rho P\).
The \(A\)-ary Singleton bound then gives \(P\ge c_0k\) for a constant \(c_0>0\).  Encode
\(a\in\Sigma\) by \(E(a)_S=\mathbf 1[a\in S]\) for all \(S\subseteq\Sigma\).  Distinct symbols
have expansion distance \(2^{A-1}\), so the expanded binary code has a fixed positive relative
distance.  Its decoder reads the inline bit \(b\), samples the original \(V_{i,b}\), and,
for typed query \((j,S)\), reads the single expansion bit \((j,S)\); it outputs \(b\) iff
that bit is one, and otherwise outputs \(\bot\).

If the inline bit is correct, the decoder cannot output a wrong bit.  If it is wrong, an
uncorrupted typed bit has wrong-branch acceptance at most \(\beta\), while corrupted typed
bits are charged using (3.4E.2): for a relative proof corruption rate \(\delta\), their hit
probability is at most

\[
 \lambda\delta\,\frac{k+2^AP}{P}
 \le \lambda\delta(2^A+c_0^{-1}).
 \tag{3.4E.4}
\]

Choosing \(\delta>0\) sufficiently small gives success \(>1/2\).  The binary two-query
exponential lower bound of
[Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu](https://arxiv.org/html/2602.20278)
then yields
(3.4E.3).  This is not an unrestricted finite-alphabet two-query theorem: without
(3.4E.2), one proof position may carry constant query mass, and corrupting all its
expansion bits costs only \(O(1/P)\) relative distance.  Thus any near-linear one-symbol
construction must either be nonsmooth, abandon the target-relative/perfect-completeness
interface, or leave the fixed finite-alphabet regime.  The full proof and the exact
constants are in [note 243](../../../mcsp-hardness-magnification/notes/243-finite-alphabet-one-query-smooth-exponential-closure-2026-08-17.md).

### Theorem 3.4F (typed-query concentration phase boundary)

The smoothness condition in Theorem 3.4E has a quantitative converse.  In the same
finite-alphabet, one-proof-symbol-query interface, define

\[
 \mu_k:=\max_{i,b,j,S}\Pr_R[t=(j,S)].
\]

Fix any \(\theta\in(0,1-\beta)\).  If \(N_k=k+P_k\le k(\log k)^c\) for infinitely many
large \(k\), then

\[
 \mu_k\ge
 \frac{1-\beta-\theta}{2}\,
 (k+2^A P_k)^{-1+\theta/6}.
 \tag{3.4F.1}
\]

Thus a near-linear construction cannot be merely “almost smooth”: it must contain a
typed-query peak of essentially \(N^{-1+\Theta(1)}\).  The proof expands every proof
symbol as in Theorem 3.4E, but now uses a non-adaptive three-query decoder which queries
the inline bit and the two candidate typed bits before seeing any answer.  On a
\(\delta\)-near word, the probability that the selected typed bit is corrupted is at most
\(\mu_k\delta(k+2^AP_k)\), so the decoder is a non-adaptive
\((3,\delta,\theta)\)-RLDC for

\[
 \delta=
 \min\left\{\frac{\Delta_0}{2},
 \frac{1-\beta-\theta}{2\mu_k(k+2^AP_k)}\right\},
\]
where \(\Delta_0>0\) is the fixed distance of the expanded code.  Goldberg--Gur--Saraogi's
Theorem 1 says that if \(\delta>(k+2^AP_k)^{-\theta/6}\), the length is
\(k^{1+\Omega_\theta(1)}\) up to polylogarithmic factors, contradicting the near-linear
assumption.  Rearranging the remaining case gives (3.4F.1).  The exact proof and
scope boundaries are in [note 246](../../../mcsp-hardness-magnification/notes/246-typed-query-concentration-phase-boundary-2026-08-17.md).

### Theorem 3.4G (growing-alphabet/locality phase boundary)

The fixed-alphabet hypothesis can be relaxed quantitatively.  Let the proof alphabet have
size \(A_k\ge2\), let the branch locality be \(r_k\), and put

\[
 T_k:=\sum_{j=0}^{r_k-1}A_k^j,\qquad Q_k:=1+2T_k,\qquad
 \Lambda_k:=1+\log\log(k+2)+\log\log(A_k+2).
\]

For a fixed positive target-relative gap \(\sigma_k\ge\sigma_0>0\), any family satisfying the
same perfect-completeness and target-relative soundness assumptions as Theorem 3.4D,
with \(N_k=k+P_k\le k(\log k)^c\) on infinitely many lengths, must obey

\[
 Q_k\Lambda_k=\Omega_{\rho,\sigma_0,c}(\log k).
 \tag{3.4G.1}
\]

Thus a one-query near-linear escape needs an alphabet of size at least
\(2^{k^{\Omega(1)}}\); polynomial, quasipolynomial, and
\(2^{k^{o(1)}}\)-size alphabets are not enough.  For fixed alphabet size \(A_k=A\), (3.4G.1)
reduces to Theorem 3.4D.

The proof is the tagged inline compiler followed by the arbitrary-alphabet GGS bound, but
with the Singleton radius loss retained: the tagged radius is

\[
 \delta_{0,k}=\frac{\rho}{2\bigl(1+2(1-\rho)\log A_k\bigr)}.
\]

Assuming \(Q_k\Lambda_k\le\eta\log k\), this radius still exceeds
\(N_k^{-\sigma_k/(2Q_k)}\) for sufficiently small \(\eta\), while the logarithm of the GGS
denominator is \(O(\Lambda_k)\).  The lower bound then forces
\(\log k/\lceil Q_k/\sigma_k\rceil=O(\Lambda_k)\), contradicting
\(Q_k\Lambda_k\le\eta\log k\) for small enough \(\eta\).  The complete parameter proof and
the large-alphabet boundary are in [note 247](../../../mcsp-hardness-magnification/notes/247-growing-alphabet-locality-phase-boundary-2026-08-17.md).

### Theorem 3.4H (joint alphabet--gap--locality phase boundary)

The alphabet and branch-gap escapes are not independent.  Let
\(\gamma_k=\alpha_k-\beta_k>0\) be the correct-versus-wrong branch gap, let
\(t_k=\lceil C_0\gamma_k^{-2}\rceil\) be the standard threshold-amplification
count, and define

\[
 R_k:=t_k r_k,\qquad
 Q_k:=1+2\sum_{j=0}^{R_k-1}A_k^j,\qquad
 \Lambda_k:=1+\log\log(k+2)+\log\log(A_k+2).
\]

Under the same target-relative radius and independent-resampling hypotheses as
Theorem 3.4G, every near-linear family \(N_k\le k(\log k)^c\) on infinitely
many lengths satisfies

\[
 Q_k\Lambda_k=\Omega_{\rho,c}(\log k).
\tag{3.4H.1}
\]

For \(A_k=2\), this becomes

\[
 \frac{r_k}{\gamma_k^2}
 \ge \log_2\log k-\log_2\log\log k-O_{\rho,c}(1).
\tag{3.4H.2}
\]

Thus a fixed-locality binary interface can evade this closure only with a gap
of order at most \(1/\sqrt{\log\log k}\); the previously stated
\(\log k/\log\log k\) factor is not implied by the decision-tree reduction.
The full proof and the corrected specialization are in
[note 248](../../../mcsp-hardness-magnification/notes/248-joint-alphabet-gap-locality-phase-boundary-2026-08-17.md).

### Theorem 3.4I (no-resampling high-confidence closure)

The independent-resampling hypothesis can be removed in a high-confidence
region.  For fixed alphabet size \(A\), fixed branch locality \(r\), and
\[
 \beta\le\frac13,\qquad 2\alpha-\beta\ge1,
\]
binary recoding of each proof symbol and a rejection-fallback coin produce an
adaptive relaxed LDC with \(1+\lceil\log_2A\rceil r\) queries, constant radius,
and \(2/3\)-level completeness and relaxed soundness.  Therefore
Dall'Agnol--Gur--Lachish's adaptive relaxed-LDC lower bound forces

\[
 N_{\rm bin}\ge
 k^{\,1+1/O_{A,\rho,r}(1)},
\tag{3.4I.1}
\]

so a fixed-\(A\), fixed-\(r\), near-linear common proof is impossible in this
region even when branch randomness cannot be independently resampled.  The
fallback chooses \(q_0=(1/3-\beta)/(1-\beta)\); the exact inequality
\(\alpha+(1-\alpha)q_0\ge2/3\) is equivalent to \(2\alpha-\beta\ge1\).
The self-contained reduction is in
[note 249](../../../mcsp-hardness-magnification/notes/249-no-resampling-high-confidence-rldc-closure-2026-08-17.md).

### Theorem 3.4I' (a constant branch gap absorbs imperfect completeness)

Perfect completeness is not an independent escape when fresh branch randomness may be
resampled. Let

\[
  \Pi:\{0,1\}^{k}\to\{0,1\}^{P}
\]

be a common proof map. For each coordinate \(i\) and claim \(b\), let \(V_{i,b}\) be an
adaptive verifier making at most \(r\) proof queries. Assume constants

\[
  0<\rho<1,\qquad 0\le\beta<\alpha\le1,
  \qquad \gamma:=\alpha-\beta>0,
\]

such that

\[
 p_{i,m_i}(\Pi(m))\ge\alpha,
 \qquad
 d_H(z,\Pi(m))\le\rho P
   \Longrightarrow p_{i,1-m_i}(z)\le\beta .
\tag{3.4I'.1}
\]

Then, for fixed \((\rho,\alpha,\beta,r)\), the message-inline map
\(C(m)=m\Vert\Pi(m)\) is a constant-query binary relaxed LDC with a fixed positive
radius and fixed two-sided error after a constant number \(t=t(\gamma)\) of independent
repetitions. Consequently Dall'Agnol--Gur--Lachish's adaptive relaxed-LDC lower bound
forces

\[
  k+P\ge k^{\,1+1/O_{\rho,\alpha,\beta,r}(1)}.
\tag{3.4I'.2}
\]

In particular, \(P=k\operatorname{polylog}k\) is impossible throughout the entire
constant-gap region \(\alpha-\beta>0\), even when the honest branch is not perfectly
complete.

#### Proof

First, the proof image has relative distance greater than \(\rho\). Indeed, if
\(m\ne m'\) and \(d_H(\Pi(m),\Pi(m'))\le\rho P\), choose \(i\) with
\(m_i\ne m'_i\). The branch \(m_i\) is correct for \(m\) and wrong for \(m'\), so
(3.4I'.1) gives \(\alpha\le\beta\), a contradiction. The binary Singleton bound
therefore gives \(P=\Omega_\rho(k)\), and a fixed constant \(\delta>0\) exists such that
every word within relative distance \(\delta\) of \(C(m)\) has its proof suffix within
the \(\rho\)-ball around \(\Pi(m)\).

Choose a constant repetition count \(t=t(\gamma)\) and an integer threshold \(\tau\) with
\(\beta<\tau/t<\alpha\), with a fixed margin on both sides. Repeat each branch on
independent random tapes and accept the amplified branch iff at least \(\tau\) repetitions
accept. Chernoff bounds make the amplified correct branch accept with probability at
least \(2/3\) on \(\Pi(m)\), while the amplified wrong branch accepts with probability at
most \(1/3\) throughout the target-relative \(\rho\)-ball. The inline decoder reads
\(b=y_i\), runs the amplified \(b\)-branch, outputs \(b\) on acceptance, and outputs
\(\bot\) otherwise. Its locality is at most \(1+tr\). If the inline bit is correct,
it never outputs a wrong bit; if it is wrong, a wrong output requires the amplified wrong
branch to accept. Hence it is a constant-radius, \(2/3\)-complete relaxed LDC with
constant locality. The DGL lower bound gives (3.4I'.2). \(\square\)

The independent-resampling hypothesis is essential to this short proof: without it, the
static postprocessing frontier in Theorem 3.4J applies instead. The theorem closes only
the completeness-gap escape; it does not supply the common proof or address-scale
construction needed by the positive RW/JK route. The parameter audit is in
[note 243](../../../mcsp-hardness-magnification/notes/243-imperfect-completeness-gap-closure-by-amplified-rldc-2026-08-17.md).

### Theorem 3.4J (optimal memoryless no-resampling frontier)

The fallback in Theorem 3.4I is optimal within the following precise
memoryless postprocessing model, even if the postprocessor is allowed to
output the opposite bit.  On a branch claim \(b\), it sees only \(b\) and the
accept/reject bit.  If the correct branch accepts with probability at least
\(\alpha\), while a wrong inline claim accepts with probability at most
\(\beta<\alpha\), then a \(2/3\)-complete, \(1/3\)-sound relaxed-LDC reduction
exists in this model if and only if

\[
  \alpha-\beta\ge\frac13,\qquad
  \alpha\ge2\beta,\qquad
  2\alpha-\beta\ge1.
\tag{3.4J.1}
\]

When these inequalities hold one may take

\[
  s=\frac{\alpha-2\beta+1}{3(\alpha-\beta)},qquad
  t=\frac{\alpha-2\beta}{3(\alpha-\beta)}.
\tag{3.4J.2}
\]

The probability of outputting the claimed bit is an affine function
\(f_b(p)=p s_b+(1-p)t_b\) of the branch acceptance rate \(p\).  The two
threshold requirements force the same inequalities for every \(b\);
opposite-bit outputs do not change this necessary claimed-bit channel, and
setting them to zero realizes (3.4J.2).  Thus the Dall'Agnol--Gur--Lachish adaptive relaxed-LDC lower bound rules out
fixed-alphabet, fixed-locality near-linear shared proofs throughout this
exact static region, with no independent branch resampling.  The derivation
and the scope boundary (transcript-dependent postprocessing, fresh
resampling, and outer robust PCP transformations are excluded) are given in
[note 250](../../../mcsp-hardness-magnification/notes/250-optimal-static-postprocessing-frontier-for-no-resampling-rldc-closure-2026-08-17.md).

### Theorem 3.4L (exact robust-ROC frontier for transcript postprocessing)

The remaining transcript-dependent no-resampling escape has an exact semantic frontier.
Fix \((i,b)\), and let \(\mathcal H_{i,b}\) be the family of visible-transcript
distributions of \(V_{i,b}\) on honest proofs \(\Pi(m)\) with \(m_i=b\).  Let
\(\mathcal W_{i,b}(\rho)\) be the family of transcript distributions of the same branch
on every \(\rho P\)-near proof of every target with \(m_i\ne b\).  Define

\[
 \operatorname{ROC}_{i,b}(\alpha,\rho):=
 \inf_{0\le f\le1}
 \left\{
   \sup_{W\in\mathcal W_{i,b}(\rho)}\mathbb E_W[f]
   :
   \inf_{H\in\mathcal H_{i,b}}\mathbb E_H[f]\ge\alpha
 \right\}.
\tag{3.4L.1}
\]

Here \(f(\tau)\) is the probability that a randomized transcript postprocessor outputs
the claim \(b\).  Then \(\operatorname{ROC}_{i,b}(\alpha,\rho)\) is exactly the minimum
worst-case wrong-claim probability among all transcript-only postprocessors with
completeness at least \(\alpha\).  In particular,

\[
 \text{a transcript-only }(\alpha,\beta)\text{ postprocessor exists}
 \quad\Longleftrightarrow\quad
 \operatorname{ROC}_{i,b}(\alpha,\rho)\le\beta .
\tag{3.4L.2}
\]

The statement allows arbitrary visible randomness and unbounded computation, but no new
proof query or fresh branch execution.  Its proof is a one-line minimax reduction: mapping
any output of \(1-b\) to \(\bot\) cannot decrease honest output of \(b\) or increase wrong
output of \(b\), and the resulting randomized rule is exactly a fractional test \(f\).

At \(\alpha=1\), (3.4L.1) collapses to the honest-transcript support-overlap parameter of
note 252.  If the transcript is compressed to the accept/reject bit, \(f\) has two values
and (3.4L.1) becomes the three inequalities of Theorem 3.4J.  Thus support overlap and
the memoryless frontier are the two exact boundary projections of the same theorem.

If the common proof image already supplies the positive inline radius and, for every
\((i,b)\), the value \(\operatorname{ROC}_{i,b}(2/3,\rho)\le1/3\) is attained (automatic
for finite transcript spaces), the tests in
(3.4L.1) give a variable-query RLDC with the original proof-query locality and no fresh
resampling.  The variable-query transfer of note 255 then implies Theorem 3.4D'' and its
near-linear locality threshold.  Conversely, if (3.4L.2) fails, no transcript-only
postprocessor can enter that RLDC closure; a successful construction must change the proof
space, radius, completeness target, or use a genuinely global/interactive mechanism.
The full LP and proof are in [note 266](../../../mcsp-hardness-magnification/notes/266-robust-roc-frontier-for-imperfect-transcript-postprocessing-2026-08-19.md).

The finite model also has a useful dual form: if (3.4L.1) exceeds \(\beta\), one
distribution over target-relative wrong transcript laws simultaneously defeats every
\(\alpha\)-complete transcript test.  This minimax certificate is stronger than producing
a different bad proof for each postprocessor and is the natural interface to patchability
or distributional-soundness arguments; details are in note 266, equations (266.8)--(266.10).
In a finite transcript space, Carathéodory further compresses this to at most
\(|\mathcal T|+1\) wrong proofs (note 266, Corollary 266.2), giving a finite certificate
that can in principle be searched or ruled out by a proof-graph argument.

### Theorem 3.4M (transcript-preservation versus first-hit patchability)

Fix \(i,b\), an honest target \(m^0\) with \(m^0_i=b\), and a distribution \(\lambda\) over
\(\rho P\)-near proofs \(z\) for targets with \(i\)-th bit \(1-b\).  Let
\(T_0(\omega)\) and \(T_z(\omega)\) be the complete visible transcripts on
\(\Pi(m^0)\) and \(z\), using the same verifier randomness, and let \(Q_0(\omega)\) be the
honest query set.  Suppose the wrong-law mixture has an \(\eta\)-transcript-preserving
submeasure:

\[
 \Pr_{z\sim\lambda,\omega}
 \!\left[T_z(\omega)\in A\ \wedge\ T_z(\omega)=T_0(\omega)\right]
 =\eta\,H_0(A)
 \quad\text{for every transcript event }A.
\tag{3.4M.1}
\]

Then every transcript-only postprocessor with honest completeness \(\alpha\) and
wrong-claim probability at most \(\beta\) must satisfy

\[
 \eta\alpha\le\beta .
\tag{3.4M.2}
\]
Moreover, if the same patch distribution hits the honest path with probability

\[
 \theta:=\Pr_{z\sim\lambda,\omega}
       [Q_0(\omega)\cap\{v:z_v\ne\Pi(m^0)_v\}\ne\varnothing],
\tag{3.4M.3}
\]
then

\[
 \eta+\theta\le1.
\tag{3.4M.4}
\]

Thus a \(2/3\)-complete, \(1/3\)-sound transcript postprocessor requires
\(\eta\le1/2\), while any patch family with \(\theta>1/2\) cannot simultaneously furnish
the \(\eta>1/2\) transcript-preserving certificate needed to rule it out.  The two
certificates attack opposite sides of the same transcript: first-hit forcing alone does not
imply a ROC barrier.

The proof is the combination of Proposition 7.3B and the elementary fact that complete
transcript equality implies that the honest query path avoids every changed proof position;
the detailed measure argument is given immediately below in Proposition 7.3C.

### Theorem 3.4K (adaptive-query--alphabet phase boundary)

The variable-query DGL transfer gives a second phase boundary that does not expose the
full adaptive decision tree. Let \(\Sigma_k\) have size \(A_k\ge2\), write
\(L_k=\log_2 A_k\), and let \(Q_k\) be the normalized query count after the DGL
error/randomness reduction. Under the common-proof, perfect-completeness, fixed
target-relative radius \(\rho>0\), and fixed wrong-claim gap \(\sigma_0>0\) hypotheses,
if
\[
  P_k\le k(\log(k+2))^c
\tag{3.4K.1}
\]
infinitely often, then
\[
  Q_k^3L_k+
  Q_k^2\!\left(\log(Q_k+2)+\log\log(A_k+2)\right)
  =\Omega_{\rho,\sigma_0,c}(\log k).
\tag{3.4K.2}
\]
In particular, for fixed \(A\), \(Q_k=\Omega((\log k)^{1/3})\); if
\(Q_k=O(r_k\log(r_k+2))\), then
\[
  r_k\log(r_k+2)=\Omega((\log k)^{1/3}).
\tag{3.4K.3}
\]

This is a derived theorem from the parameterized DGL proof, not a claim that DGL's
source paper states a growing-\(Q\), growing-alphabet corollary. Its exact transfer
window is
\[
  Q_k^3L_k+
  Q_k^2\!\left(\log(Q_k+2)+\log(L_k+2)\right)
  \le\eta\log P_k
\tag{3.4K.4}
\]
for a sufficiently small fixed \(\eta\); outside this window the theorem makes no
claim. The proof-only relaxed decoder has shared-sample complexity
\[
  S_k\le C A_k^{Q_k}Q_k(L_k+1)
  P_k^{1-1/(2Q_k^2)}.
\tag{3.4K.5}
\]
Injectivity gives \(A_k^{P_k}\ge2^k\), hence \(S_k\ge(k-1)/L_k\). Taking logarithms
in (3.4K.5), using (3.4K.1), and absorbing the \(O(\log\log k)\) difference between
\(\log P_k\) and \(\log k\), yields
\[
  \frac{\log k}{4Q_k^2}
  \le Q_kL_k+
  O_{\rho,\sigma_0,c}\!\left(
    \log\log k+\log(Q_k+2)+\log(L_k+2)\right),
\]
which is incompatible with the negation of (3.4K.2) once (3.4K.4) is available.
The proof and all alphabet-growth conditions are recorded in
[note 256](../../../mcsp-hardness-magnification/notes/256-adaptive-alphabet-variable-query-phase-boundary-2026-08-17.md).

### Theorem 3.5 (strong target-relative soundness is an LDC barrier)

Suppose the binary family has perfect completeness for the correct branch and satisfies the
distance-proportional wrong-branch bound

\[
  p_{i,1-m_i}(z)\le\lambda\,\operatorname{dist}(z,C(m))
\]

for every target \(m\), coordinate \(i\), and proof \(z\), with fixed \(\lambda\). Let
\(Q=2q\). For any

\[
  0<\delta<2^{-Q}/\lambda,
\]

the exactly-one-accepts decoder is a perfect-complete \(Q\)-query RLDC with soundness
\(s=\lambda\delta<2^{-Q}\). Cheng--Li--Mao's adaptive perfect-completeness theorem then
gives an ordinary \(Q\)-query LDC at every radius

\[
  0<r<\frac{\delta}{2Q}\bigl(1-\lambda\delta\,2^Q\bigr).
\]

Consequently, for fixed \(q\) and fixed \(\lambda\), strong target-relative soundness cannot
coexist with a near-linear proof family: a fixed positive choice of \(\delta\) already enters
the ordinary LDC lower-bound regime. The remaining ACRR escape is therefore not
distance-proportional soundness, but fixed-radius constant soundness (or a degeneration of
\(\lambda\), the alphabet, the query count, or the family-level quantifiers).

### Theorem 3.6 (full-family list-to-ACRR dichotomy)

Consider the full binary target family \(\mathcal M=\{0,1\}^k\) with one common proof
address space and a fixed positive target-relative radius.  Suppose a proposed conversion
from a dPCP list mechanism to Theorem 2.9 uses only coordinatewise list membership and
has a global exception budget \(\Lambda<2^{k-1}\), with every target-relative list
containing the target word.  Then every target list is singleton, by Corollary 2.12.  If,
in addition, the singleton interface has perfect completeness and its list error is at most
\(\varepsilon_k\) under a uniform coordinate marginal, the induced wrong-claim probability
is at most
\[
  \beta_k\le k\varepsilon_k.
\tag{3.6}
\]
Hence, whenever \(k\varepsilon_k\le\beta_0<1/2\) eventually and the query count, alphabet,
radius, and completeness gap stay fixed, the common proof map is a fixed-parameter RLDC.
It therefore cannot have near-linear proof length in any regime covered by the applicable
relaxed-LDC lower bound.

Equivalently, a near-linear construction in this full-family model must satisfy at least
one of the following:
\[
  \Lambda\ge2^{k-1},\qquad
  \limsup_{k\to\infty} k\varepsilon_k\ge\tfrac12,\qquad
  \text{or it must add a non-list, cross-coordinate target-binding mechanism.}
\tag{3.7}
\]

#### Proof

The exception budget and coordinatewise-only hypothesis invoke Corollary 2.12, so every
list agrees with its target at every coordinate.  The singleton conditioning argument
then bounds each wrong branch by \(k\varepsilon_k\), giving (3.6).  Theorem 2.1 (or its
weighted form, Theorem 3.2) converts the common proof map into a fixed-parameter RLDC
whenever this bound is below the completeness threshold.  The relaxed-LDC lower bound
rules out near-linear length, proving the dichotomy. \(\square\)

This is a black-box list-to-ACRR barrier, not an unconditional lower bound against new
dPCP constructions: the only surviving positive route is precisely a global
cross-coordinate target-binding mechanism that is not expressible as coordinatewise list
membership.

### Proposition 3.6A (anti-mixing list-size barrier)

The coordinatewise-list escape has an independent alphabet/list-size obstruction. Let
\(E:[M]\to\Sigma^N\) be injective, \(q=|\Sigma|\ge2\), and let
\(\boldsymbol w=(w_1,\ldots,w_N)\) be any probability distribution on \([N]\).
For a target \(x\) and an \(L\)-element list \(S\subseteq[M]\setminus\{x\}\), define
\[
  u_E(x,S)=
  \sum_{\substack{j\in[N]:\\
    E(x)_j\notin\{E(s)_j:s\in S\}}}w_j.
\]
If \(0<\gamma\le1\), \(1\le L\le M-1\), \(M\ge 8q/(3\gamma)\), and
\[
  u_E(x,S)\ge\gamma
  \qquad\text{for all }x\in[M],\ S\subseteq[M]\setminus\{x\},\ |S|=L,
\tag{3.6a}
\]
then
\[
  L\le \frac{8q}{3\gamma}\log\frac4\gamma .
\tag{3.6b}
\]

#### Proof

For fixed \(x,j\), let
\[
  d_j(x)=|\{s\ne x:E(s)_j=E(x)_j\}|.
\]
For a uniformly random \(L\)-subset \(S\) of the other messages,
\[
 \Pr[E(x)_j\notin E(S)_j]
 =
 \frac{\binom{M-1-d_j(x)}{L}}{\binom{M-1}{L}}
 \le
 \left(1-\frac{d_j(x)}{M-1}\right)^L .
\tag{3.6c}
\]
Put \(a=\log(4/\gamma)\), and call \(j\) low for \(x\) when
\(d_j(x)<a(M-1)/L\). Non-low coordinates contribute at most
\(e^{-a}=\gamma/4\) to the expectation in (3.6a). Hence the
\(\boldsymbol w\)-mass \(\theta_x\) of low coordinates satisfies
\[
  \theta_x+(1-\theta_x)\frac{\gamma}{4}\ge\gamma,
  \qquad
  \theta_x\ge\frac{3\gamma}{4}.
\tag{3.6d}
\]
At any fixed coordinate, the \(M\) messages occupy at most \(q\) symbol classes.
A low target in a class of size \(c\) requires
\(c\le1+a(M-1)/L\). Thus that coordinate has at most
\(q(1+a(M-1)/L)\) low targets. Summing over targets and coordinates gives
\[
  \frac{3\gamma}{4}M
  \le q\left(1+\frac{a(M-1)}L\right).
\tag{3.6e}
\]
The assumption \(M\ge8q/(3\gamma)\) rearranges (3.6e) to (3.6b). If
\(L<2a\), (3.6b) is immediate, so the argument covers all \(L\).
\(\square\)

The proposition applies to a proposed list-to-target conversion whose only binding
information is the coordinatewise projection
\(\{E(s)_j:s\in S\}\). Such a conversion needs (3.6a): otherwise a target word can
be coordinatewise covered by an unlabelled list while no single list word equals it,
leaving a phantom word invisible to every coordinatewise test. Therefore fixed
alphabet and fixed \(\gamma\) cannot support \(L=k^{\Omega(1)}\) through an outer-code
choice alone, regardless of the outer code length or the coordinate distribution. The remaining options are an
indexed/global consistency channel, a growing alphabet, a restricted list family, or
vanishing binding quality.

This is a lower bound for the coordinatewise-list black-box model, not for all dPCPs:
a verifier with genuine cross-coordinate constraints may escape the hypothesis. It
strengthens Theorem 3.6 by quantifying an alphabet/list-size obstruction even when proof
length is unconstrained; it does not replace the indexed-list construction target in
Theorem 3.8.

### Proposition 3.6B (coordinatewise unlabelled binding forces anti-mixing)

Proposition 3.6A's anti-mixing hypothesis is forced by a broad local binding model. Let
\(E:[M]\to\Sigma^N\), let \(q=|\Sigma|\), let
\(\boldsymbol w=(w_1,\ldots,w_N)\) be a probability distribution on \([N]\), and fix
\(1\le L\le M-1\). For an
\(L\)-list \(S\), write
\[
  \mu_j(S)=\{\!\{E(s)_j:s\in S\}\!\}
\]
for its unlabelled multiset projection. Let \(B_{x,j}\) be arbitrary randomized predicates
whose only list input is \(\mu_j(S)\), and write
\[
  a_{x,j}(S)=\Pr[B_{x,j}(\mu_j(S))=1].
\]
Suppose \(0<\beta<\alpha\le1\), and assume
\[
  a_{x,j}(T)\ge\alpha
  \quad\text{whenever }x\in T,\ |T|=L,
\tag{3.6f}
\]
while
\[
  \sum_{j=1}^{N}w_j a_{x,j}(S)\le\beta
  \quad\text{whenever }x\notin S,\ |S|=L.
\tag{3.6g}
\]
Then, with \(\gamma=1-\beta/\alpha\), every \(x\notin S\) satisfies
\[
  \sum_{\substack{j\in[N]:\\
    E(x)_j\notin\{E(s)_j:s\in S\}}}w_j
  \ge\gamma.
\tag{3.6h}
\]
Consequently, if \(M\ge8q/(3\gamma)\), then
\[
  L\le\frac{8q}{3\gamma}\log\frac4\gamma.
\tag{3.6i}
\]

#### Proof

Fix \(x\notin S\). If coordinate \(j\) is covered, choose \(s_j\in S\) with
\(E(s_j)_j=E(x)_j\), and set \(T_j=(S\setminus\{s_j\})\cup\{x\}\). Then
\(\mu_j(T_j)=\mu_j(S)\), although \(T_j\) contains \(x\). By (3.6f),
\(a_{x,j}(S)=a_{x,j}(T_j)\ge\alpha\) on every covered coordinate. If \(u_E(x,S)\)
is the uncovered \(\boldsymbol w\)-mass, (3.6g) therefore gives
\[
  \beta\ge\sum_j w_j a_{x,j}(S)
  \ge\alpha(1-u_E(x,S)),
\]
which is (3.6h). Proposition 3.6A now yields (3.6i). \(\square\)

The same replacement argument quantifies the escape when completeness is weakened. For a
covered coordinate \(j\), let \(T_j=(S\setminus\{s_j\})\cup\{x\}\) as above and define,
for a benchmark \(\alpha>0\),
\[
  \Delta_{x,j}(T_j)=\bigl(\alpha-a_{x,j}(T_j)\bigr)_+.
\]
Then every \(x\notin S\) obeys
\[
  \sum_{\substack{j\in[N]:\\E(x)_j\in\{E(s)_j:s\in S\}}}
    w_j\Delta_{x,j}(T_j)
  \ge
  \bigl(\alpha(1-u_E(x,S))-\beta\bigr)_+.
\tag{3.6j}
\]
Indeed, on covered coordinates \(a_{x,j}(S)=a_{x,j}(T_j)\), so the left side is at least
\(\alpha(1-u_E(x,S))-\sum_jw_ja_{x,j}(S)\), and (3.6g) applies. In particular, if all
replacement lists satisfy \(a_{x,j}(T_j)\ge\alpha-\delta\) for some \(\delta<\alpha\),
then
\[
  u_E(x,S)\ge1-\frac{\beta}{\alpha-\delta}.
\tag{3.6k}
\]
Whenever this right side is positive, Proposition 3.6A gives the same list-size bound with
\(\gamma=1-\beta/(\alpha-\delta)\). Thus a large-list construction must pay a positive
weighted replacement-completeness deficit, introduce an indexed/cross-coordinate channel,
or leave the coordinatewise multiset model.

This proposition is a genuine black-box impossibility theorem for coordinatewise
unlabelled binding: it allows arbitrary randomized predicates and dependence on \(x,j\),
and even the full multiset of list symbols. It does not apply when completeness is required
only for one selected list, or when the verifier receives indices, a common strategy, or
cross-coordinate information. Those are exactly the global target-binding mechanisms left
to the positive construction route.

### Theorem 3.7 (selector-consistency compiler)

The list barrier above does not rule out every cross-coordinate mechanism.  The following
explicit compiler shows one such mechanism, at a transparent proof-length cost.  Let
\(m^{(1)},\ldots,m^{(L)}\in\{0,1\}^k\) be candidate target words and let
\(\Pi^{(1)},\ldots,\Pi^{(L)}\in\Sigma^{P_0}\) be fixed base proofs.  For every \(a\in[L]\),
coordinate \(i\), and claim \(b\), suppose that \(U_{i,b,a}\) is a base verifier that
reads at most \(q\) symbols from the \(a\)-th block and whose acceptance probability on a
block \(z_a\) is denoted \(u_{i,b,a}(z_a)\).  Assume that, whenever
\(\operatorname{dist}(z_a,\Pi^{(a)})\le\rho_0P_0\),
\[
  u_{i,m^{(a)}_i,a}(z_a)\ge\alpha,\qquad
  u_{i,1-m^{(a)}_i,a}(z_a)\le\beta,\qquad
  0\le\beta<\alpha.
\tag{3.8}
\]

Set \(R=\lceil LP_0/k\rceil\), \(N=LP_0+Rk\), and form the compiled proof for target
\(s\) by concatenating all candidate blocks and an \(R\times k\) selector matrix:
\[
  \widehat\Pi^{(s)}=\Pi^{(1)}\|\cdots\|\Pi^{(L)}\|S^{(s)},\qquad
  S^{(s)}_{j,r}=s.
\tag{3.9}
\]
(The selector alphabet is \([L]\); binary labels of length \(\lceil\log_2L\rceil\) may be used at
the corresponding multiplicative query cost.)  Define \(V_{i,b}\) by choosing
\(r\in[R]\) and \(j\in[k]\) uniformly, reading \(a=S_{i,r}\) and \(a'=S_{j,r}\), rejecting if
\(a\ne a'\), and otherwise running \(U_{i,b,a}\) on block \(z_a\).  Then \(V\) has query
complexity \(q+2\) in the selector-symbol model, perfect (or \(\alpha\)-) completeness for
every \(\widehat\Pi^{(s)}\), and for every proof \(z\) satisfying
\(\operatorname{dist}(z,\widehat\Pi^{(s)})\le\rho_\star N\),
\[
  p_{i,1-m^{(s)}_i}(z)\le\beta+2\rho_\star,\qquad
  \rho_\star\le \rho_0/A_N,\qquad
  A_N:=N/P_0=L+\frac{Rk}{P_0}.
\tag{3.10}
\]
In particular, choosing \(\rho_\star\) so that \(\beta+2\rho_\star<\alpha\) gives a genuine
constant target-relative gap.  If \(\beta+2\rho_\star<1/2\), the usual exactly-one-branch
compiler applies as well.

#### Proof

For completeness, all selector entries equal \(s\), so the equality test always passes and
\(U_{i,m^{(s)}_i,s}\) is applied to \(\Pi^{(s)}\).  Now let \(z\) be within
\(\rho_\star N\) of \(\widehat\Pi^{(s)}\).  Its \(s\)-th base block obeys
\[
  \operatorname{dist}(z_s,\Pi^{(s)})\le\rho_\star N=\rho_\star A_NP_0\le\rho_0P_0,
\tag{3.11}
\]
so (3.8) applies to that block.  Let \(B\) be the set of corrupted selector cells and write
\(c_r=|\{j:S_{j,r}\ne s\}|\).  Since \(Rk\ge LP_0\),
\[
  \frac{|B|}{Rk}\le\frac{\rho_\star N}{Rk}\le2\rho_\star.
\tag{3.12}
\]
For the wrong claim \(b=1-m^{(s)}_i\), condition on the chosen repetition \(r\).  If
\(S_{i,r}=s\), an acceptance can occur only when \(S_{j,r}=s\), and its base contribution is
at most \(\beta\).  If \(S_{i,r}\ne s\), the equality test can pass only for the
\(j\)'s carrying that same wrong label; their number is at most \(c_r\).  Therefore
\[
  p_{i,1-m^{(s)}_i}(z)\le\beta+\frac1R\sum_{r=1}^R\frac{c_r}{k}
  =\beta+\frac{|B|}{Rk}\le\beta+2\rho_\star.
\tag{3.13}
\]
This is the promised target binding: a locally corrupted selector must agree with an
independently sampled selector cell before its target-dependent base verifier is used.
\(\square\)

The compiler is intentionally conditional.  It requires an explicitly indexed bank of
candidate proofs and verifiers; ordinary dPCP list soundness does not supply that bank or a
common physical address space.  For constant \(L\), \(N\le2LP_0+k\), so \(P_0=O(k\operatorname{polylog}k)\)
remains near-linear up to constants.  For \(L=k^{\Theta(1)}\), the same construction has
polynomial rather than near-linear overhead.  Thus the theorem supplies a concrete
cross-coordinate target-binding primitive, while leaving open the central question of
constructing the required indexed bank from a hidden-output relation (in particular from the
current GMWZ/RW interfaces).

### Theorem 3.8 (indexed-list selector compiler)

The explicit proof bank in Theorem 3.7 is stronger than necessary.  It suffices to have a
single base proof whose local decoder returns a candidate index together with the decoded
symbol, provided that the index has a globally consistent meaning.  Fix \(L\) candidate
words \(m^{(1)},\ldots,m^{(L)}\in\{0,1\}^k\), a common base proof address space, and for each
target \(s\in[L]\) a base proof \(\Pi^{(s)}\in\Sigma^{P_0}\).  Let \(D_i\) be a common
\(q\)-query decoder which, on a proof \(z\), outputs either \(\bot\) or a pair
\((a,c)\in[L]\times\{0,1\}\).

Assume indexed perfect completeness:
\[
  D_i^{\Pi^{(s)}}=(s,m^{(s)}_i)
  \qquad\text{with probability one for every \(s,i\)}.
\]

Assume **indexed distributional soundness**: for every target \(s\) and every
\(z\) with \(\operatorname{dist}(z,\Pi^{(s)})\le\rho_0P_0\), there is one indexed list
\[
  Y^{s,z}=(y^{s,z}_1,\ldots,y^{s,z}_L)\in(\{0,1\}^k)^L,
  \qquad y^{s,z}_s=m^{(s)},
\]
which is independent of the coordinate \(i\), such that for every fixed \(i\),
\[
  \Pr\!\left[
    D_i^z\notin
    \{\bot\}\cup\{(a,y^{s,z}_a[i]):a\in[L]\}
  \right]\le\varepsilon .
\tag{3.14}
\]
The probability includes the decoder's internal randomness, and an invalid index is counted
as an error.  This is strictly stronger than ordinary list soundness: the same indexed list
must explain every coordinate.

Set \(R=\lceil P_0/k\rceil\), \(N=P_0+Rk\), and define
\(\widehat\Pi^{(s)}:=\Pi^{(s)}\|S^{(s)}\), where \(S^{(s)}\) is an \(R\times k\)
selector matrix with \(S^{(s)}_{j,r}=s\).  On input \((i,b)\), the compiled
verifier samples \(r\in[R]\) and \(j\in[k]\), reads \(a_0=S_{i,r}\) and \(a_1=S_{j,r}\), and
accepts iff \(a_0=a_1=a\) and \(D_i^z=(a,b)\).  Then the compiled proof has length
\[
  N\le2P_0+k,
\tag{3.15}
\]
query complexity \(q+2\) in the selector-symbol model, perfect completeness, and for every
\(z'\) satisfying
\(\operatorname{dist}(z',\widehat\Pi^{(s)})\le\rho_\star N\),
\[
  p_{i,1-m^{(s)}_i}(z')\le\varepsilon+2\rho_\star,
  \qquad
  \rho_\star\le\rho_0\,\frac{P_0}{N}.
\tag{3.16}
\]
Consequently, if \(\varepsilon+2\rho_\star<1/2\), the compiled system is simultaneous
coordinate-robust at a constant gap.  If \(\ell_L=\lceil\log_2L\rceil\) and selector
symbols are binary-encoded, the corresponding bounds are
\[
  N_{\mathrm{bin}}\le P_0+\ell_L(P_0+k),
  \qquad
  Q_{\mathrm{bin}}=q+O(\ell_L).
\tag{3.17}
\]
Thus the symbol-model length is independent of \(L\), while binary encoding pays only the
expected \(O(\log L)\) multiplicative factor.

#### Proof

The honest target-\(s\) proof has \(a_0=a_1=s\), while \(D_i\) outputs
\((s,m^{(s)}_i)\), so completeness is immediate.  For a nearby proof \(z'\), the base
part \(z\) is within \(\rho_\star N\le\rho_0P_0\) of \(\Pi^{(s)}\), by the radius condition.
Let \(B\) be the corrupted selector cells and let \(c_r\) be the number of cells in repetition
\(r\) whose label differs from \(s\).  Since \(Rk\ge P_0\),
\[
  \frac{|B|}{Rk}\le\frac{\rho_\star N}{Rk}\le2\rho_\star .
\tag{3.18}
\]

If the decoder outputs \((s,1-m^{(s)}_i)\), this is an indexed-list error in (3.14), because
\(y^{s,z}_s=m^{(s)}\); its probability is at most \(\varepsilon\).  If it outputs an index
\(a\ne s\), the equality test can pass only when the random selector cell carries the same
wrong label.  For each repetition there are at most \(c_r\) such cells, so this contribution
is at most
\[
  \frac1R\sum_{r=1}^R\frac{c_r}{k}
  =\frac{|B|}{Rk}\le2\rho_\star .
\tag{3.19}
\]
Adding the two disjoint cases proves (3.16). \(\square\)

This compiler is the sharper positive target for a list-based construction.  Its proof
length is independent of \(L\) in the selector-symbol model; with binary labels it grows by
\(O(\log L)\), so even \(L=k^{O(1)}\) is compatible with near-linear length up to polylogarithmic
factors.  The missing ingredient is not another list-size estimate: it is an
**indexable, globally labelled list** whose \(a\)-th word is fixed across all coordinates and
whose target index \(s\) remains present throughout the target-relative neighborhood.

There is an important source-level distinction here.  [GMWZ Definition 3.3](https://arxiv.org/html/2512.12960#S3.SS1)
does give one common, unlabelled list for all decoded coordinates of a fixed left assignment
(and uniformly over the right assignment); it is therefore stronger than a merely
coordinatewise list statement.  The target word can in fact be retained under an explicit
edge-proximity hypothesis, as Proposition 3.8A below shows.  What the theorem still does not
provide is an index-valued decoder or a binding rule that keeps one list position fixed across
the target-relative neighborhood.  Theorem 3.8 asks precisely for those remaining semantic
fields, so it is not a black-box corollary of the current dPCP theorem.

### Proposition 3.8A (target retention from global list soundness)

Fix a target word \(m^{(s)}\) and a perfectly complete proof assignment
\(T^{(s)}=(T_A^{(s)},T_B^{(s)})\).  Let \(T=(T_A,T_B)\) be another assignment, and let
\(\theta\) be the probability, under the complete decoding distribution, that at least one
endpoint of the sampled edge is changed:
\[
\theta=\Pr\!\left[
  T_A[a]\ne T_A^{(s)}[a]\ \lor\
  T_B[b]\ne T_B^{(s)}[b]
\right].
\tag{3.19A}
\]
Assume GMWZ-style \((L,\varepsilon)\)-list soundness for the fixed left assignment \(T_A\),
with one list \(W\subseteq\mathcal L\) used for every decoded coordinate and every right
assignment.  If
\[
\varepsilon+\theta<1,
\tag{3.19B}
\]
then \(m^{(s)}\in W\).

#### Proof

Suppose \(m^{(s)}\notin W\).  On every sampled edge outside the event in (3.19A), the
assignment \(T\) agrees with the perfectly complete assignment \(T^{(s)}\) at both
endpoints.  The edge is therefore accepted and the decoder outputs
\(m^{(s)}_t\notin W_t\).  The list-soundness error is at least \(1-\theta\), contradicting
\(1-\theta>\varepsilon\). \(\square\)

If proof distance is measured in unweighted vertex Hamming distance and the two endpoint
marginals have incidence factors \(\chi_A,\chi_B\), then
\(\theta\le(\chi_A+\chi_B)\rho\) for a \(\rho\)-relative perturbation.  In particular, the
uniform balanced regime only loses a constant factor.  Thus target retention is not the
remaining black-box obstacle for such a source; the remaining issue is to turn a common
unlabelled list containing the target into a stable index or an equivalent
same-candidate-across-coordinates test.

### Proposition 3.8B (global-word index recovery closes to shared ACRR)

The stable-index requirement can be isolated without asking the base decoder to expose an
index. Let \(L\ge2\) and let
\[
Y=\{y^{(1)},\ldots,y^{(L)}\}\subseteq\Gamma^M
\]
be a public family with pairwise relative distance at least \(\Delta>0\). Suppose
\(y^{(s)}=C(m^{(s)})\), where \(C:\{0,1\}^k\to\Gamma^M\) has a deterministic \(q_D\)-query
decoder for every message coordinate, and the symbol \(y^{(s)}_j\) is address-scale
computable from \((s,j)\) without proof queries.

Let \(\Pi(s)\in\Sigma^N\) be a common-address proof map. For every \(j\in[M]\), let
\(D_j\) be a randomized adaptive \(q\)-query proof decoder with perfect completeness
\(D_j(\Pi(s))=y^{(s)}_j\). Assume that for some \(\rho>0\) and
\(\varepsilon<\Delta/2\),
\[
\operatorname{dist}(z,\Pi(s))\le\rho
\quad\Longrightarrow\quad
\Pr_{J,D_J}\!\left[D_J(z)\ne y^{(s)}_J\right]\le\varepsilon,
\tag{3.19C}
\]
where \(J\) is uniform and \(\bot\) counts as an error. Then independent sampling of
coordinates, for every \(\eta\in(0,1/2)\), with
\[
R=\left\lceil
\frac{2\log((L-1)/\eta)}{(\Delta-2\varepsilon)^2}
\right\rceil
\tag{3.19D}
\]
coordinates recovers the target index with failure probability at most \(\eta\), using at most
\[
Rq=O\!\left(q\,\frac{\log(L/\eta)}{(\Delta-2\varepsilon)^2}\right)
\tag{3.19E}
\]
adaptive proof queries. For a nonadaptive RLDC theorem, define
\[
T_q(A):=\sum_{t=0}^{q-1}A^t,\qquad A:=|\Sigma|.
\tag{3.19F}
\]
Exposing the \(A\)-ary decision tree of each sampled adaptive call gives nonadaptive
locality at most \(RT_q(A)\); if every \(D_j\) is already nonadaptive, this becomes \(Rq\).
Evaluating \(y^{(\widehat s)}\) at the \(q_D\) positions requested by the
outer decoder then gives a shared-proof adaptive ACRR decoder for \(m^{(s)}_i\), and,
after decision-tree exposure, the corresponding nonadaptive RLDC decoder, with the same
radius and error at most \(\eta\). The candidate-score scan costs \(O(LR)\) public
candidate evaluations; therefore address-scale running time additionally requires that
the indexed family \(Y\) be efficiently enumerable (or admit an equivalent succinct
argmax procedure).

#### Proof

For each sampled coordinate, record the output of \(D_J\). The true candidate has expected
agreement at least \(1-\varepsilon\); every other candidate has expected agreement at most
\(1-\Delta+\varepsilon\). Hoeffding's inequality and a union bound over \(L-1\) candidates
give target-index recovery with probability \(1-\eta\) for (3.19D). The outer decoder is
then run on the publicly evaluable word \(y^{(\widehat s)}\), so it returns
\(m^{(s)}_i\) whenever \(\widehat s=s\). The adaptive proof-query count is (3.19E).
For a fixed random tape, each \(D_j\) has an \(A\)-ary adaptive decision tree with at most
\(T_q(A)\) internal query nodes. Taking the union of these nodes over the \(R\) sampled
coordinates gives the nonadaptive bound \(RT_q(A)\) in (3.19F); when the base decoders are
already nonadaptive, the union has only \(Rq\) queries.

The same hypotheses imply proof-image separation. If
\(\operatorname{dist}(\Pi(s),\Pi(t))\le\rho\) for \(s\ne t\), applying (3.19C) to
\(z=\Pi(t)\) for target \(s\), while using perfect completeness for \(t\), would make one
symbol distribution \(\varepsilon\)-close to two words at distance \(\Delta>2\varepsilon\),
a contradiction.

This proposition is the precise closure interface between global-word distributional
soundness and the RLDC barrier. It is stronger than an index-valued output requirement:
the base dPCP need only produce symbols from one globally coherent candidate word. It is
not a black-box consequence of GMWZ ordinary list soundness. Proposition 3.8A retains the
target in the common list under endpoint proximity, but a separate global-word collapse
(for example the satisfaction-defect and list-collapse hypotheses of C152) and a public
candidate evaluator are still required. The full standalone statement is
[global-word index recovery closes to shared ACRR](../../statements/global-word-index-to-acrr-closure.md).

### Corollary 3.8C (perfect completeness closes the global-word gate)

The global-word hypothesis in Proposition 3.8B is automatic at the proof-perturbation
level for any perfectly complete common-address dPCP.  Let \(e=(a,b)\) be sampled from
\(\mu\), let \(D_e\) output a symbol in \(\Gamma\cup\{\bot\}\), and suppose
\[
D_e(\Pi(s))=y^{(s)}_{\tau(e)}
\quad\text{with probability one}
\tag{3.19F}
\]
for every target \(s\), sampled edge, and decoded coordinate \(\tau(e)\).  For another
assignment \(z\), write
\[
\theta_s(z)=\Pr_{e=(a,b)\sim\mu}\!\left[
z_A(a)\ne\Pi_A(s)(a)\ \lor\
z_B(b)\ne\Pi_B(s)(b)\right].
\tag{3.19G}
\]
Then
\[
\Pr_{e\sim\mu,D_e}\!\left[D_e(z)\ne y^{(s)}_{\tau(e)}\right]\le\theta_s(z).
\tag{3.19H}
\]
Assume here that the decoded-coordinate marginal \(\tau(e)\) is uniform on \([M]\), or
measure candidate-word distance in that same marginal.  Thus if every \(\rho\)-near proof
has \(\theta_s(z)\le\kappa\rho\), and the target words
are pairwise \(\Delta\)-separated with \(\kappa\rho<\Delta/2\), Proposition 3.8B applies
with \(\varepsilon=\kappa\rho\).
Indeed, outside the endpoint-disagreement event the local view is identical to the
perfectly complete proof, so a wrong symbol (including \(\bot\)) is impossible.  The
resulting proof locality is
\[
O\!\left(q\,\frac{\log(L/\eta)}
 {(\Delta-2\kappa\rho)^2}\right),
\tag{3.19I}
\]
apart from public candidate-word evaluation.  Uniform vertex Hamming distance gives
\(\kappa=\chi_A+\chi_B\) under endpoint incidence factors; in the balanced uniform
bipartite case \(\kappa=2\).

This is stronger than target retention: it uses only perfect completeness and endpoint
proximity, not list soundness.  It does not claim that the current GMWZ output words form
a public, efficiently enumerable, pairwise-separated family.  That candidate-evaluation
condition is the remaining address-scale gate.  The standalone statement is
[perfect completeness closes the global-word gate](../../statements/perfect-complete-dpcp-global-word-closure.md).

### Proposition 3.8D (list recovery closes the candidate-index gate)

The public evaluator condition in Proposition 3.8B has a precise algorithmic replacement
when the candidate family is large.  Let
\[
Y=\{y^{(s)}=C(m^{(s)}):s\in\mathcal S\}\subseteq\Gamma^M,
\qquad |\mathcal S|=L,
\]
with pairwise relative distance at least \(\Delta>0\), public address evaluation
of \(y^{(s)}_j\), and an outer \(q_D\)-query decoder.  Assume the common proof decoders
of Proposition 3.8B satisfy (3.19C), with \(\varepsilon<\Delta/2\).

Suppose a public sampled-symbol list-recovery algorithm receives \(R_0\) independent
pairs \((J_t,\widehat y_t)\), where \(J_t\) is uniform and
\(\Pr[\widehat y_t\ne y^{(s)}_{J_t}]\le\varepsilon\), and returns in address-scale
time a list \(B\subseteq\mathcal S\) of size at most \(\ell\) containing \(s\) with
probability at least \(1-\eta_0\).  Then for every \(\eta>\eta_0\), the same proof
space supports a bounded-error RLDC with proof locality
\[
q\left(R_0+
\left\lceil\frac{2\log(\ell/(\eta-\eta_0))}
 {(\Delta-2\varepsilon)^2}\right\rceil\right)+q_D,
\tag{3.19J}
\]
apart from the outer decoder's standard constant-success amplification.  Its running
time is the list-recovery time plus address evaluation of the at most \(\ell\) candidates
on the fresh scoring samples and the \(q_D\) outer queries.

Indeed, run the common-proof decoder on the \(R_0\) sampled coordinates and feed its
symbols to the list-recovery algorithm.  Conditioned on the event that the true index is
in \(B\), take fresh samples and score only \(B\).  The true candidate has expected
agreement at least \(1-\varepsilon\), whereas every other candidate has expected
agreement at most \(1-\Delta+\varepsilon\); Hoeffding and a union bound over \(\ell-1\)
wrong candidates give the second term in (3.19J).  Evaluating the selected candidate at
the outer decoder's positions completes the message decoding.  Conversely, any
target-independent index-recovery procedure whose only input is the sampled symbol
transcript is itself a sampled-symbol list-recovery algorithm (with list size one if it
outputs a single index).

There is an unconditional information check on this interface.  If the target index is
uniform, a sample-only procedure outputs a list of size at most \(\ell\) containing it
with probability \(1-\eta\), and each observed symbol lies in \(\Gamma\), then
\[
R_0\log_2|\Gamma|
\ge (1-\eta)\log_2(L/\ell)-h_2(\eta).
\tag{3.19K}
\]
This is the list form of Fano's inequality: each independent sampled symbol contributes
at most \(\log_2|\Gamma|\) bits of index information.  Thus the list-recovery condition
removes the brute-force \(L\)-scan, but not the \(\Omega(\log L)\) information scale.

This sharpens the remaining Gate after Proposition 3.8C: a public candidate evaluator
alone is not enough when \(L\) is large.  One must either provide a robust outer decoder
that consumes noisy symbols directly, or provide a public address-scale list-recovery
algorithm.  Brute-force scanning all \(L\) candidates is not address-scale.  The result is
an interface theorem only; it does not claim that the current GMWZ dPCP supplies this
list-recovery mechanism.  The standalone statement is [list recovery closes the
candidate-index gate](../../statements/list-recovery-closes-candidate-index-gate.md).

### Theorem 3.8E (output-homogeneous dPCP compiler)

Let \(\mathcal D\) be a \(q\)-query dPCP for
\(\mathcal L\subseteq\Sigma_0^n\), with perfect completeness and
\((L,\varepsilon)\)-list-decoding soundness. Fix a finite output alphabet \(\Gamma\), a
target symbol \(m\in\Gamma\), and public maps
\[
\pi_t:\Sigma_0\longrightarrow\Gamma\qquad(t\in[n])
\]
such that every valid word has the same projected symbol at every decoded position:
\[
\pi_t(w_t)=m
\qquad\text{for every }w\in\mathcal L\text{ and every }t.
\tag{3.19L}
\]
Then the same proof and address space support, for every claim \(b\in\Gamma\), a verifier
that checks the original dPCP edge and accepts exactly when the decoded symbol projects to
\(b\). The correct claim \(b=m\) is perfectly complete, while every wrong claim
\(b\ne m\) is accepted with probability at most \(\varepsilon\), for every assignment.
The query complexity and proof length are unchanged.

Indeed, list soundness supplies one coordinate-independent list
\(w^{(1)},\ldots,w^{(L)}\). If a satisfied edge decodes to a symbol whose projection is
\(b\ne m\), that symbol differs from every \(w^{(j)}_t\) by (3.19L), so the event is
contained in the list-soundness error event. Perfect completeness follows from (3.19L)
and a satisfying assignment. The theorem therefore removes the phantom-witness/index
problem for a one-symbol output channel without requiring a singleton list.

This is a genuine positive compiler, but its quantifier is deliberately narrow. It gives
one shared target symbol (or a constant-size output channel), not a hidden \(k\)-bit
computation history. Spreading a \(k\)-bit target through an outer code \(C(m)\) requires
an additional smooth decoder; the corresponding first-error argument incurs the explicit
factor \(q_D\lambda\varepsilon\). A deterministic-output relation can instantiate
(3.19L) by adding a locally checked output field whose value is the same on every satisfying
history. The current GMWZ theorem does not provide this homogeneity for an arbitrary SAT
language; it must be proved by the relation construction before the compiler applies.

### Theorem 3.8F (simultaneous coordinate-projection compiler)

The preceding compiler has a coordinate-wise form that isolates the exact semantic
requirement for a shared proof. Let \(I\) be a finite set of target coordinates and let
\(\mathcal D\) be the same \(q\)-query dPCP as above. For each \(i\in I\) and decoded
position \(t\in[n]\), give a public map
\[
\pi_{i,t}:\Sigma_0\longrightarrow\Gamma_i,
\]
and a target symbol \(m_i\in\Gamma_i\), and assume the simultaneous homogeneity condition
\[
\pi_{i,t}(w_t)=m_i
\qquad\text{for every }w\in\mathcal L,\ i\in I,\ t\in[n].
\tag{3.19M}
\]
Assume moreover that the maps are uniformly evaluable in the intended verifier model:
given \((i,t,\gamma)\), the value \(\pi_{i,t}(\gamma)\) is computable within time
\(s_\pi\) (or by a circuit of size \(s_\pi\)).  This cost is paid in verifier description and
running time, even though it does not add proof queries.
Then, for every \(i\) and every claim \(b\in\Gamma_i\), the verifier that runs the original
dPCP edge test and accepts exactly when the decoded symbol \(\gamma\) satisfies
\(\pi_{i,t}(\gamma)=b\) has perfect completeness for \(b=m_i\), and accepts every wrong
claim \(b\ne m_i\) with probability at most \(\varepsilon\), on every assignment. All
coordinates use the same proof and address space; query complexity and proof length are
unchanged, and the bound is per-coordinate rather than a union bound over \(I\).

For the proof, fix an assignment and let \(w^{(1)},\ldots,w^{(L)}\) be the single list
provided by dPCP list soundness. If a decoded symbol at position \(t\) projects to a
wrong \(b\ne m_i\), it differs from every \(w^{(j)}_t\) by (3.19M). Thus every wrong-claim
accepting edge is already a list-soundness error, giving probability at most \(\varepsilon\).
For \(b=m_i\), a satisfying assignment and any honest valid word make every projection
test pass. No consistency or singleton-list argument is needed beyond (3.19M).

This is a genuine shared-proof coordinate-robust compiler. The index set \(I\) may grow,
but for one fixed relation the symbols \(m_i\) are fixed; a growing target family requires
a uniformly parameterized family of relations and projections satisfying (3.19M). Its
cost has therefore moved to the relation layer, which must supply all public maps and prove
that condition. The theorem gives separate coordinate guarantees; requiring one execution
to certify all \(i\) simultaneously can incur a union bound or needs an additional joint
soundness statement. In particular, ordinary GMWZ list soundness does not itself imply
(3.19M), and the theorem does not provide the missing RW address-scale construction.

### Theorem 3.9 (indexed-list compiler with a smooth outer decoder)

The fixed-coordinate hypothesis in Theorem 3.8 can be weakened when the output is first
encoded by a smooth locally decodable code.  Let
\[
  C:\{0,1\}^k\longrightarrow\Gamma^M
\]
have an adaptive \(q_D\)-query decoder \(\mathsf{Dec}_i\) for each message coordinate \(i\),
with perfect completeness.  Assume that, conditioned on an honest transcript, every query
step of \(\mathsf{Dec}_i\) samples a codeword position \(t\) with probability at most
\(\lambda/M\).  Let a common base dPCP proof have a \(q\)-query decoder \(D_t\) returning
either \(\bot\) or a tagged symbol \((a,\gamma)\in[L]\times\Gamma\).

For every target \(s\), let the base honest proof be \(\Pi^{(s)}\), with target codeword
\(C(m^{(s)})\).  Assume indexed list soundness in the averaged codeword-coordinate form:
for every \(z\) within \(\rho_0P_0\) of \(\Pi^{(s)}\), there is an indexed list
\(Y^{s,z}=(y^{s,z}_1,\ldots,y^{s,z}_L)\in(\Gamma^M)^L\), with
\(y^{s,z}_s=C(m^{(s)})\), such that
\[
  \frac1M\sum_{t=1}^M
  \Pr\!\left[
    D_t^z\notin\{\bot\}\cup\{(a,y^{s,z}_a[t]):a\in[L]\}
  \right]\le\varepsilon .
\tag{3.20}
\]
Assume also \(D_t^{\Pi^{(s)}}=(s,C(m^{(s)})[t])\) with probability one.  Append the
same \(R=\lceil P_0/k\rceil\) selector matrix as in Theorem 3.8.  To verify claim \(b\) at
message coordinate \(i\), sample selector cells \(S_{i,r},S_{j,r}\), run
\(\mathsf{Dec}_i\), and for every base query \(t\) run \(D_t\).  Accept iff the outer
decoder outputs \(b\), every base call returns a non-\(\bot\) pair with the same index
\(a=S_{i,r}=S_{j,r}\), and the selector equality passes.

Then the compiled proof has selector-symbol length \(N\le2P_0+k\), query complexity at
most \(q_Dq+2\), perfect completeness, and for every
\(\operatorname{dist}(z',\widehat\Pi^{(s)})\le\rho_\star N\),
\[
  p_{i,1-m^{(s)}_i}(z')
  \le q_D\lambda\varepsilon+2\rho_\star,
  \qquad
  \rho_\star\le\rho_0\,\frac{P_0}{N}.
\tag{3.21}
\]
Thus \(q_D\lambda\varepsilon+2\rho_\star<1/2\) is a sufficient simultaneous
coordinate-robustness condition.

#### Proof

The honest proof makes every selector comparison pass, every base call output
\((s,C(m^{(s)})[t])\), and the outer decoder returns \(m^{(s)}_i\).  For a nearby proof,
the base part remains within \(\rho_0P_0\) of \(\Pi^{(s)}\), and the selector corruption
fraction is at most \(2\rho_\star\), exactly as in (3.17).

Consider an accepting execution for the wrong bit.  If some decoded tag differs from \(s\),
the selector equality can hold only on a corrupted selector sample, contributing at most
\(2\rho_\star\).  Otherwise all decoded tags equal \(s\).  If no base call returns a
symbol outside the \(s\)-th indexed codeword \(y^{s,z}_s=C(m^{(s)})\), the outer decoder
sees the honest codeword on its entire adaptive transcript and cannot output the wrong bit.
Hence there is a first bad base call.  Before it, all answers are honest, so smoothness
applies to the queried position.  At every step,
\[
  \Pr[\text{bad call}]
  \le\sum_{t=1}^M\frac{\lambda}{M}
     \Pr[D_t^z\notin\{\bot\}\cup\{(a,y^{s,z}_a[t]):a\in[L]\}]
  \le\lambda\varepsilon .
\]
The union bound over at most \(q_D\) outer queries gives \(q_D\lambda\varepsilon\).
Combining the two disjoint failure modes proves (3.21). \(\square\)

Theorem 3.9 separates the remaining construction costs cleanly.  The outer code pays
\(q_D\lambda\), while the selector pays only the target-relative corruption term.  A
constant-smoothness, constant-query outer code would therefore permit constant base list
error; the coordinate-specific PCPP architecture in current RLDC constructions has
\(\lambda=\Theta(k)\), recovering the familiar inverse-linear threshold.  The theorem still
requires the indexed global list in (3.20): unlabelled ordinary list soundness permits a
different candidate word at each coordinate and cannot be inserted into the first-bad-call
argument.

### Theorem 3.9A (approximate indexed-list compiler)

The exact condition \(y^{s,z}_s=C(m^{(s)})\) in Theorem 3.9 can be relaxed, but only if the
outer decoder remains correct and smooth throughout a prescribed near-codeword ball.  Fix
\(\delta\in[0,1]\) and parameters \(\alpha_C>\beta_C\).  Assume that for every
\(y\) with
\[
  \operatorname{dist}(y,C(m^{(s)}))\le\delta M
\]
the adaptive decoder \(\mathsf{Dec}_i\) satisfies
\[
  \Pr[\mathsf{Dec}_i^y=m_i^{(s)}]\ge\alpha_C,\qquad
  \Pr[\mathsf{Dec}_i^y=1-m_i^{(s)}]\le\beta_C,
\tag{3.39}
\]
and that every query step on every honest transcript generated by such a \(y\) is
\(\lambda\)-smooth.  Replace (3.20) by the existence, for every nearby base proof \(z\), of
an \(i\)-independent indexed list \(Y^{s,z}\) for which
\[
  \operatorname{dist}(y^{s,z}_s,C(m^{(s)}))\le\delta M
\tag{3.40}
\]
and (3.20) still holds.  Then the same selector construction has length
\(N\le2P_0+k\), query complexity at most \(q_Dq+2\), honest completeness at least
\(\alpha_C\), and
\[
  p_{i,1-m_i^{(s)}}(z')
  \le \beta_C+q_D\lambda\varepsilon+2\rho_\star,
  \qquad
  \rho_\star\le\rho_0P_0/N .
\tag{3.41}
\]
Hence
\(\alpha_C>\beta_C+q_D\lambda\varepsilon+2\rho_\star\) gives a simultaneous
target-relative coordinate gap.

#### Proof

The honest selector is constant \(s\), and the base decoder supplies the word
\(y^{s,\Pi^{(s)}}_s\), so (3.39) gives completeness at least \(\alpha_C\).  For a nearby
compiled proof, selector corruption contributes at most \(2\rho_\star\), as in (3.18).
If all accepted base tags are \(s\) and no base answer leaves the \(s\)-th indexed word,
the outer decoder sees \(y^{s,z}_s\), whose distance and wrong-bit probability are controlled
by (3.39)--(3.40).  Otherwise consider the first bad base answer.  Before it, the outer
transcript is an honest transcript for \(y^{s,z}_s\), so robust smoothness applies.  At each
outer step the probability of this event is at most
\[
  \sum_{t=1}^{M}\frac{\lambda}{M}
  \Pr\!\left[
    D_t^z\notin\{\bot\}\cup\{(a,y^{s,z}_a[t]):a\in[L]\}
  \right]
  \le\lambda\varepsilon .
\]
Union-bounding over the at most \(q_D\) outer queries and adding the two selector terms gives
(3.41).  \(\square\)

The new term \(\beta_C\) is not cosmetic: approximate indexed soundness by itself does not
control an adaptive outer decoder, because a near-codeword word can concentrate its errors on
the decoder's exceptional positions.  Thus Theorem 3.9A leaves the global indexed-word
requirement intact and isolates the additional target as near-codeword smoothness.  If
\(\lambda=\Theta(k)\), it still requires \(\varepsilon=O(1/k)\); an actual near-linear escape
would need an indexed global list together with \(\lambda=o(k)\) (or a different
coordinate-robust mechanism).

### Proposition 3.9B (projection right-alphabet reduction preserves unique decoding)

The right-alphabet reduction used in [1] is not itself forced to destroy unique decoding.
Consider a projection dPCP with edge distribution \(\mu\), left-based decoding, and the
following \((\varepsilon_0,\eta)\) unique-decoding property: every assignment satisfying at
least \(1-\varepsilon_0\) of the \(\mu\)-mass of constraints is explained by one word with
average decoding error at most \(\eta\). Let
\(C:\Sigma_B\to\Omega^m\) have relative distance \(\delta_C\), and replace each right
vertex \(b\) by \((b,i)\), checking the \(i\)-th code symbol of the unique projection of
the left label. Then the reduced projection dPCP has unique-decoding parameters

\[
   \varepsilon'_0=\frac{\delta_C\varepsilon_0}{2},
   \qquad \eta' = \eta .
\tag{3.42}
\]

Indeed, for a reduced assignment, condition on a right vertex \(b\), let \(p_b\) be the
distribution of projected right symbols from its incident edges, and let \(y_b\) be the
reduced right word. If
\(d_b=\mathbb E_{\sigma\sim p_b}[\operatorname{dist}(y_b,C(\sigma))]\), the reduced
violation rate is \(\varepsilon'=\mathbb E_b d_b\). Pairwise code distance gives

\[
  1-\max_\sigma p_b(\sigma)
  \le \frac{2d_b}{\delta_C}.
\tag{3.43}
\]

Choosing the maximum-mass symbol at each \(b\) therefore recovers a base right assignment
whose violation rate is at most \(2\varepsilon'/\delta_C\). If
\(\varepsilon'\le\delta_C\varepsilon_0/2\), the assumed unique-decoding property supplies
one global word, and the left decoding distribution is unchanged. Perfect completeness is
preserved by encoding each honest right label with \(C\).

This proposition refines the composition diagnosis: if unique decoding is lost in the GMWZ
pipeline, the loss must occur before this projection alphabet-reduction step, or in a step
that fails to preserve a single near-satisfying right assignment. It does not turn the final
list-decoding theorem into a unique-decoding theorem; it isolates a concrete preservation
lemma to be checked through the earlier routing, amplification, and composition stages.

### Proposition 3.9C (right-degree reduction preserves unique decoding)

The same conclusion, already stated as Lemma 4.4 of [1], holds for the right-degree
regularization. Suppose each original
right neighborhood is replaced by a biregular sampler \(H_b\) with second singular value at
most \(\lambda\), whose left marginal is the original conditional edge distribution and which
preserves the original global left marginal. Given any assignment to the new
right copies, choose a copy uniformly for each \(b\); this defines a randomized assignment to
the old right vertices. Expander mixing shows that its expected old constraint violation is
at most the new violation plus \(\lambda\). Hence, if the old system has
\((\varepsilon_0,\eta)\) unique decoding, the regularized system has

\[
  \varepsilon'_0=\max\{0,\varepsilon_0-\lambda\},
  \qquad \eta'=\eta .
\tag{3.44}
\]

Indeed, for each right vertex \(b\) and symbol \(\sigma\), let \(F_{b,\sigma}\) indicate the
projected symbol on the left sampler and \(G_{b,\sigma}\) indicate the assigned symbol on the
right sampler. Summing the expander-mixing inequality over the partition indexed by
\(\sigma\) gives an additive error at most \(\lambda\). A deterministic fixing of the
randomized old assignment then meets the old unique-decoding threshold, while the left
decoding distribution is unchanged. For the standard \(d'\)-regular samplers,
\(\lambda=O(d'^{-1/2})\).

Thus both right-side regularization steps preserve unique decoding under their natural
projection and marginal hypotheses. The first possible loss in the GMWZ chain must be sought
in gap amplification, HDX routing, or the subsequent composition, rather than in the two
right-side alphabet/degree reductions.

### Lemma 3.9D (the cluster-synchronization criterion)

The direct-product gap-amplification proof in [1, Section 6] starts from a udPCP but partitions a
near-satisfying left table into disjoint heavy clusters \(\mathcal U_i\). For each cluster it obtains
a global function \(f_i\) and, by applying base unique decoding, a word \(w_i\). The following
elementary criterion identifies exactly what would be needed to recover one word.

Let

\[
Y_i(t,u)=D^{\rm hdx}_t(u,f_i(u)),\qquad
\rho_{ij}=\Pr_{(t,u)\sim\mathcal Q_{\rm hdx}}[Y_i(t,u)\ne Y_j(t,u)].
\]

If \(\Pr[Y_i(t,u)\ne (w_i)_t]\le\eta\) for every \(i\), then

\[
\operatorname{dist}(w_i,w_j)\le \rho_{ij}+2\eta.
\tag{3.45}
\]

Indeed, a coordinate on which \(w_i\) and \(w_j\) differ must be charged either to a disagreement
between \(Y_i\) and \(Y_j\), or to one of the two decoding-error events. Consequently, if the
candidate word family is \(\Delta\)-separated and

\[
\rho_{ij}<\Delta-2\eta\qquad\text{for every }i,j,
\tag{3.46}
\]

then all \(w_i\) are equal. GMWZ Lemma 6.2 gives disjointness and local closeness of the
\(\mathcal U_i\), but no estimate of \(\rho_{ij}\); its Theorem 6.1 therefore correctly concludes
list-decoding soundness rather than unique decoding. Equation (3.46) is the first concrete
source-specific synchronization target: proving it would yield a UD-preserving gap-amplification
theorem, while a realizable assignment violating it would isolate a genuine obstruction for this
proof skeleton. This conditional lemma is not a claim that the current GMWZ construction already
preserves unique decoding.

### Lemma 3.9E (quantitative cross-cluster transfer)

The synchronization criterion can be written directly in the sampling parameters of the
direct-product test. Let \(\gamma_{ij}\) be the probability that the two sampled left vertices
fall in \(U_i\) and \(U_j\), and condition on this event. Let \(\nu_{ij}\) be the induced
distribution on the base decoder pair \((t,u)\), and suppose

\[
\operatorname{TV}(\nu_{ij},\mathcal Q_{\rm hdx})\le\xi_{ij}.
\tag{3.47}
\]

Assume that the two restrictions disagree with their cluster functions with conditional
probabilities at most \(\zeta_i\) and \(\zeta_j\), respectively. If the global direct-product
constraint violation is \(\varepsilon_{\rm dp}\), then

\[
\rho_{ij}\le
\xi_{ij}+\zeta_i+\zeta_j+\frac{\varepsilon_{\rm dp}}{\gamma_{ij}}.
\tag{3.48}
\]

Combining (3.48) with Lemma 3.9D, a \(\Delta\)-separated word family is synchronized whenever

\[
\varepsilon_{\rm dp}
<
\gamma_{ij}\bigl(\Delta-2\eta-\xi_{ij}-\zeta_i-\zeta_j\bigr).
\tag{3.49}
\]

The proof is a conditioning argument: when both projections agree with the same right label
and neither restriction error occurs, the two cluster functions agree at the sampled base
vertex, hence their decoded symbols agree. The only remaining losses are the two restriction
errors, the conditional projection violation (bounded by
\(\varepsilon_{\rm dp}/\gamma_{ij}\)), and the total-variation transfer. This gives a concrete
parameter target for an HDX proof. GMWZ Section 6 does not state (3.47) or a lower bound on
\(\gamma_{ij}\), so Lemma 3.9E is a bridge to be verified, not a claim about the current theorem.

There is a standard spectral reduction for the mass parameter. If \(M_{k,s}\) is the normalized
incidence operator from \(X(k)\) to the shared \(s\)-faces and its second singular value is
\(\lambda_{k,s}\), then the two-step shared-face sampler gives

\[
\gamma_{ij}\ge
\mu_k(U_i)\mu_k(U_j)
-\lambda_{k,s}^{\,2}\sqrt{\mu_k(U_i)\mu_k(U_j)}.
\tag{3.50}
\]

This follows by decomposing the two cluster indicators into their means and orthogonal parts.
Consequently, the remaining GMWZ-specific calculation is to verify the relevant
\(X(k)\)--\(X(\sqrt{k})\) spectral estimate and the marginal-transfer bound (3.47) under the
exact sampling normalization used in Section 6.

The same inequality gives a uniform heavy-cluster threshold. If
\(\mu_k(U_i),\mu_k(U_j)\ge\mu_0\) and \(\lambda_{k,s}^2\le\mu_0/2\), then

\[
\gamma_{ij}\ge\frac{\mu_0^2}{2}.
\tag{3.51}
\]

Thus uniform transfer and label bounds \(\xi_{ij}\le\xi_0\) and
\(\zeta_i,\zeta_j\le\zeta_0\) force synchronization whenever

\[
\varepsilon_{\rm dp}<
\frac{\mu_0^2}{2}
\bigl(\Delta-2\eta-\xi_0-2\zeta_0\bigr).
\tag{3.52}
\]

Substituting the GMWZ heavy-cluster guarantee \(\mu_0=\delta^C\) yields the concrete
condition \(\lambda_{k,s}^2\le\delta^C/2\) and cross-mass lower bound
\(\gamma_{ij}\ge\delta^{2C}/2\). Equations (3.51)--(3.52) remain conditional: the source's
displayed HDX theorem states an \(X(1)\)--\(X(i)\) spectral estimate, whereas this route
needs the exact \(X(k)\)--\(X(\sqrt{k})\) two-step normalization and the transfer bound
in (3.47).

#### Sampler-normalization boundary

There is a second, more basic issue before importing a published down-up estimate.
The direct-product tester in both the GMWZ and BMVY formulations first samples a
top-dimensional face \(D\), then a shared \(s\)-face \(B\subset D\), and finally two
independent \(k\)-faces inside that same \(D\) and containing \(B\). The down-up operator
\(U_s^kD_s^k\) controlled by BMVY Lemma 2.8 instead samples \(B\) and then two
independent \(k\)-faces from the conditional \(\mu_k\)-law given \(B\). These pair laws
need not agree: on the complete complex on four vertices with \(d=3,k=2,s=1\),
\(\Pr[A=A']\) is \(1/2\) for the shared-\(D\) law and \(1/3\) for the down-up law.
Thus Lemma 2.8 cannot be cited as a bound for the actual GMWZ pair operator without
an explicit coupling/comparison lemma. Even after such a spectral comparison, the
conditional base-decoder marginal transfer \(\xi_{ij}\) remains a separate hypothesis.
This is a source-specific normalization boundary, not an impossibility theorem.

#### Flag-conditioned transfer

The normalization gap can nevertheless be bypassed at the operator level. Let
\(T f(D,B)=\mathbb{E}[f(A)\mid D,B]\) on the flag space
\(\{(D,B):B\subset D\}\). The shared-\(D\) pair operator is \(T^\ast T\).
Writing \(m(B)=\mathbb{E}[f(A)\mid B]\) and
\(m(D,B)=\mathbb{E}[f(A)\mid D,B]\), the conditional-variance identity gives

\[
\sigma_2(\mathsf K_{\rm top})
\leq\lambda_0^2+\lambda_1^2,
\tag{3.53}
\]

where \(\lambda_0\) is the nonconstant \(X(k)\to X(s)\) conditional-expectation
norm and \(\lambda_1\) is the worst nonconstant conditional-expectation norm from
\(X_B(k-s)\) to \(X_B(d-s)\) over all \(s\)-links \(B\). Applying the local
singular-value estimate in BMVY Lemma 2.8 globally and in each link yields

\[
\sigma_2(\mathsf K_{\rm top})
\leq
\left(\sqrt{\frac{s}{k}}+P(k)\Gamma_{\varnothing}\right)^2
\;+\;
\left(\sqrt{\frac{k-s}{d-s}}+P(d-s)\Gamma_+\right)^2,
\tag{3.54}
\]
where \(\Gamma_{\varnothing}\) is the empty-link local parameter and
\(\Gamma_+\) is the corresponding parameter for nonempty links.  This
distinction matters for the BMVY source.

For \(s=\sqrt{k}\), the geometric terms are \(1/\sqrt{k}\) and approximately
\(k/d\). Thus choosing \(k\) large, \(d\gg k\), and the local-expansion error
sufficiently small can close the spectral half of the C158 gate. This is a
derived flag-transfer lemma, not an identification of the two pair laws and not
a unique-decoding theorem. At the factorized heavy-cluster level, however, the
remaining decoder-marginal term is no longer an independent mystery: Proposition 3.9S below
instantiates the latent covariance estimate and gives an explicit \(\xi_{ij}\) bound.
Label errors, non-factorized events, and common-word consistency remain separate.

The source parameters now let us instantiate this spectral statement. BMVY
Theorem 2.13, which is the complex input used by GMWZ, gives
\[
\Gamma_+(d,q)=\operatorname{poly}(d)q^{-1/2}
\]
for nonempty links, while item 6 gives the global empty-link estimate
\[
\Gamma_{\varnothing}(d,q)\le\frac1{d-1}+\frac2{\sqrt q}.
\]
Thus the empty-link parameter is not uniformly \(O(q^{-1/2})\) at fixed \(d\).
For the fixed heavy-cluster mass \(\mu_0=\delta^{C_0}\) from GMWZ Lemma 6.2,
choose first the constant parameters \(k,d\) with

\[
\frac2{\sqrt{k}}+\frac{2k}{d}<\frac{\mu_0}{4},
\tag{3.54a}
\]

and so that \(P(k)/(d-1)\) fits the remaining \(\mu_0\)-budget. Then take \(q\)
large enough to absorb the \(q^{-1/2}\) terms in (3.54). With
\(k=r^2\) a perfect square and \(s=r=\sqrt{k}\), as in the GMWZ
tester, this gives

\[
\sigma_2(\mathsf K_{\rm top})<\frac{\mu_0}{2},
\qquad
\gamma_{ij}\ge\frac{\mu_0^2}{2}
\tag{3.54b}
\]

for every pair of heavy clusters. Thus the shared-top spectral/mass half of the
GMWZ synchronization route is source-specifically closed; it is no longer a
normalization assumption. Proposition 3.9S below also closes the decoder-marginal term for
factorized heavy-cluster events under the corresponding BMVY link profiles.
The common global word, label errors, and non-factorized events remain open, so
this does not upgrade the published list-decoding theorem to unique decoding.

### Lemma 3.9F (the Lemma 6.2 clauses carry no incidence regularity)

The missing marginal estimate cannot be recovered from the stated cluster conclusion
itself. Abstract the low-agreement table used in the proof of GMWZ Lemma 6.2 as follows:
there is a table \(T^*:X(k)\to\Sigma^k\) such that, whenever a right assignment has
shared-\(s\)-face agreement with \(T^*\) above the source threshold, the
direct-product soundness argument produces a function \(F:X(1)\to\Sigma\) that agrees
with \(T^*\) on more \(k\)-faces than permitted by the low-agreement property of \(T^*\).
Let \(U_1,\ldots,U_J\subseteq X(k)\) be arbitrary pairwise disjoint sets with
\(J\le\delta^{-C}\) and \(\mu_k(U_i)\ge\delta^C\), and let
\(f_i:X(1)\to\Sigma\) be arbitrary. Define

\[
T_1[A]=
\begin{cases}
f_i|_A,& A\in U_i,\\
T^*[A],& A\notin\bigcup_i U_i.
\end{cases}
\tag{3.55}
\]

Then the two explicit conclusions of Lemma 6.2 hold for this \(T_1\): the
within-\(U_i\) distance is zero, and every right assignment has at most the source
threshold of shared-face agreement outside \(\bigcup_iU_i\). Indeed, the first claim is
immediate. For the second, outside the union \(T_1=T^*\), so any violation would trigger
the same direct-product soundness step and contradict the defining low-agreement property
of \(T^*\).

Consequently, no incidence-smoothness or decoder-marginal estimate
\(\xi_{ij}=o(1)\) can be deduced from Lemma 6.2's density, disjointness, and
outside-union clauses alone. This is a black-box limitation, not an impossibility theorem
for the particular computation-generated left assignment used by GMWZ: a successful
unique-decoding upgrade must exploit additional semantic structure of that assignment or
modify the gap-amplification construction itself.

### Corollary 3.9G (cluster-only arguments cannot preserve a singleton word)

Suppose the base udPCP admits two near-satisfying assignments \(f_0,f_1\) whose decoded
words \(w_0,w_1\) are distinct and separated by more than the base decoding error.
Any purported unique-decoding proof for the gap-amplified system that uses only the two
explicit clauses of Lemma 6.2 together with the separate statement
“\(f_i\) decodes to \(w_i\)” cannot conclude \(w_0=w_1\). Lemma 3.9F realizes the
same clauses with arbitrary disjoint heavy clusters assigned to \(f_0\) and \(f_1\).
Therefore singleton global-word preservation requires an additional cross-cluster
invariant—such as a bound on \(\rho_{ij}\), a decoder-marginal transfer theorem, or an
explicit shared-word consistency test. This is a black-box impossibility for the
cluster-only proof interface, not a claim that every modification of the GMWZ construction
must fail.

### Theorem 3.9J (source-level quantifier ledger for GMWZ Section 6)

The published Section 6 gap-amplification proof has an exact, list-only quantifier
interface. For every left assignment \(T_1\), Lemma 6.2 first produces functions
\(f_1,\ldots,f_L\) and pairwise disjoint heavy sets \(\mathcal U_1,\ldots,\mathcal U_L\).
Its clauses impose only (i) local closeness of \(f_i\) to \(T_1\) on \(\mathcal U_i\), and
(ii) a bound on agreement outside the union \(\mathcal U^\star\). Lemma 6.4 then proves
that each \(f_i\) is a nearly satisfying base assignment. Base unique decoding consequently
supplies one word \(w_i\) per cluster, with the source's error bound \(5\sqrt\delta\).

The proof of GMWZ Theorem 6.1 uses these words only through the list
\(\{w_i:i\in[L]\}\): it splits the decoding error into the union and its complement, uses
the outside-union clause on the latter, and applies a union bound over the disjoint clusters
on the former. No step compares \(w_i\) and \(w_j\), introduces a common reference word, or
proves a cross-cluster decoder-marginal estimate. Therefore the strongest singleton-independent
conclusion obtainable from the published Section 6 clauses together with base unique decoding
is list-decoding soundness. A singleton unique-decoding conclusion requires an additional
invariant such as (3.46), the quantitative transfer condition (3.49), or an equivalent
common-reference/target-binding statement.

This is a source-level localization theorem, not an impossibility theorem for modified
gap amplification. Lemma 3.9F supplies the corresponding black-box witness: the stated
Lemma 6.2 clauses remain valid for arbitrary disjoint heavy clusters and arbitrary cluster
functions, so no proof that uses only those clauses can derive \(w_i=w_j\). Any successful
upgrade must therefore use semantic structure of the computation-generated assignment or
add a genuinely cross-cluster consistency mechanism.

### Corollary 3.9H (black-box cluster selection has an index cost)

Assume in addition that the base system has \(J\) admissible cluster functions whose
decoded words are pairwise distinct, and that the proposed repair exposes these choices
as \(J\) target-labelled proof views \(\Pi^{(s)}\in\Sigma^N\) in one common address space.
Suppose it must identify the selected cluster by a target-independent local decoder in that
address space.
If the decoder makes \(q_{\mathrm{sel}}\) queries over an alphabet \(\Sigma\) and identifies
the correct cluster with probability at least \(\alpha\), then

\[
\alpha J\le |\Sigma|^{q_{\mathrm{sel}}}.
\tag{3.56}
\]

Indeed, this is the prefix-free decision-tree counting bound applied to the \(J\) proof
views. Lemma 3.9F shows why a black-box proof cannot silently assume \(J=O(1)\): under
the same source hypotheses it is compatible with every \(J\le\delta^{-C}\) disjoint
heavy-cluster family. Thus any repair that exposes the full admissible family as common-
address target views pays

\[
q_{\mathrm{sel}}\log_2|\Sigma|
\ge \log_2\alpha+C\log_2(1/\delta).
\tag{3.57}
\]

For \(\delta=\Theta(1/k)\), fixed alphabet and constant indexed completeness force
\(q_{\mathrm{sel}}=\Omega(\log k)\). This is a black-box selector lower bound; it is not a
lower bound on the actual list size produced by GMWZ for every assignment, and it can be
evaded only by exploiting additional semantic structure or abandoning target-independent
local index selection.
The standalone statement and its black-box quantifiers are recorded in
[Cluster-only common-address selector barrier](../../statements/cluster-only-common-address-selector-barrier.md).

### Proposition 3.9J (face-separable patchability obstruction)

The preceding black-box warning can be made an explicit assignment-level test for the
actual projection graph.  Let \(F_0,F_1:X(1)\to\Sigma\) be two perfect assignments of
the base udPCP, decoding to words \(w_0,w_1\).  Suppose there are disjoint left-face
families \(U_0,U_1\subseteq X(k)\) and a vertex labeling \(H:X(1)\to\Sigma\) such that

\[
H|_A=F_i|_A\qquad(A\in U_i,\ i\in\{0,1\}).
\tag{3.57a}
\]

Set the amplified right label to \(T_2[B]=H|_B\), the left label to
\(F_i|_A\) on \(U_i\), and use arbitrary valid left labels elsewhere.  Then every
projection edge whose left endpoint lies in \(U_0\cup U_1\) is satisfied; the total
violation is at most \(1-\mu(U_0)-\mu(U_1)\).  If

\[
\Gamma_{01}:=\frac1{|I|}\sum_{t\in I}
\mathbf 1[w_{0,t}\ne w_{1,t}]
\min\{\Pr[A\in U_0\mid t],\Pr[A\in U_1\mid t]\},
\tag{3.57b}
\]

then the decoded output of this assignment has Hamming distance at least
\(\Gamma_{01}\) from every single word.  Consequently the exact projection amplifier
cannot have unique-decoding error \(\eta_{\rm out}\) whenever

\[
1-\mu(U_0)-\mu(U_1)\le\varepsilon_{\rm out}
\quad\text{and}\quad
\Gamma_{01}>\eta_{\rm out}.
\tag{3.57c}
\]

The proof is direct: (3.57a) makes all edges in the two face families agree with
the common right labeling, while a decoded coordinate on \(U_i\) is exactly the
base decoded symbol \(w_{i,t}\).  On every coordinate where \(w_0\) and \(w_1\)
differ, any single proposed bit is wrong on at least the smaller of the two
conditional cluster masses.  This is a source-specific obstruction, not a
consequence of Lemma 6.2 alone.  A practical search is to split the disagreement
set \(D=\{u:F_0(u)\ne F_1(u)\}\) into \(R\sqcup S\), take \(H=F_0\) on
\(R\cup D^c\) and \(H=F_1\) on \(S\), and use
\[
U_0=\{A:A\cap S=\varnothing\},\qquad
U_1=\{A:A\cap R=\varnothing,\ A\cap S\ne\varnothing\}.
\tag{3.57d}
\]
Then (3.57a) holds identically.  The remaining source calculation is sharp and
measurable: determine whether the actual HDX face profile makes the outside mass
small while keeping the decoder-weighted separation \(\Gamma_{01}\) positive.
If it does, the published projection amplifier has a concrete UD counterexample;
if every such split loses one of these two quantities, that loss is the precise
cross-cluster invariant a UD-preserving construction must prove.

### Proposition 3.9K (face-avoidance gate)

The face-separable obstruction has a quantitative positive counterpart.  Suppose the
\(X(1)\to X(k)\) sampler satisfies, for every disjoint \(R,S\), with
\(r=\mu_1(R)\) and \(s=\mu_1(S)\),

\[
\Pr[A\cap S=\varnothing]\le e^{-ks}+\varepsilon_{\rm fa},
\qquad
\Pr[A\cap R=\varnothing,\ A\cap S\ne\varnothing]
\le ks\,e^{-(k-1)r}+\varepsilon_{\rm fa}.
\tag{3.57e}
\]

For the random disagreement split in (3.57d), and a decoder marginal independent of
the left-face event, the resulting word separation satisfies

\[
\Gamma_{01}\le
\operatorname{dist}(w_0,w_1)
\left(\frac4k+\varepsilon_{\rm fa}\right).
\tag{3.57f}
\]

To see this, set \(x=kr,y=ks\).  The two face-avoidance bounds imply
\[
\min\{\mu(U_0),\mu(U_1)\}
\le \min\{e^{-y},ye^{-(1-1/k)x}\}+\varepsilon_{\rm fa}
\le \sqrt y\,e^{-(x+y)/4}+\varepsilon_{\rm fa}.
\]
Multiplying by \(r+s=(x+y)/k\) and using
\(\sup_{z\ge0}z^{3/2}e^{-z/4}<4\) gives
\((r+s)\min\{\mu(U_0),\mu(U_1)\}\le4/k+\varepsilon_{\rm fa}\).
For the split, every base decoding vertex for a coordinate on which the two
words differ lies in \(D=R\sqcup S\), so
\(\operatorname{dist}(w_0,w_1)\le r+s\). Under the stated
coordinate-independent marginal, \(\Gamma_{01}=\operatorname{dist}(w_0,w_1)
\min\{\mu(U_0),\mu(U_1)\}\), proving (3.57f).

Thus proving (3.57e) with sufficiently small \(\varepsilon_{\rm fa}\) for the
actual GMWZ HDX would rule out this entire face-separable patch family as a
constant-error UD obstruction.  Conversely, a set pair \(R,S\) violating
(3.57e) is a concrete candidate for a source-specific patching counterexample.
The currently stated GMWZ HDX theorem gives inclusion-graph singular values and
direct-product soundness, but not (3.57e); this is therefore a genuine next
source calculation, not a hidden consequence of Theorem 6.1.

### Proposition 3.9L (spectral gate for the random split)

The random split can nevertheless be controlled directly by the published
inclusion spectrum. Let `lambda_k` be the second singular value of
`X(1) <-> X(k)`. Assume the complete decoding distribution has uniform
coordinate marginal and uniform `X(k)`-marginal on left faces, and that the
base decoding vertex marginal is the stationary `X(1)` marginal, as in the GMWZ
Section 6 construction. Then the split (3.57d) satisfies

```
Gamma_01 <= sqrt(2) lambda_k.                                      (3.57g)
```

Indeed, `U_0` avoids `S`, so expander mixing gives
`mu(U_0) mu_1(S) <= lambda_k sqrt(mu(U_0) mu_1(S))`, hence
`mu(U_0) <= lambda_k^2/s`. Likewise `mu(U_1) <= lambda_k^2/r`, because
`U_1` avoids `R`. Writing `a=max{r,s}`, uniform marginals give

```
Gamma_01 <= min{dist(w_0,w_1), (r+s) lambda_k^2/a}
          <= min{dist(w_0,w_1), 2 lambda_k^2}.                      (3.57h)
```

For every coordinate on which `w_0,w_1` differ, all base decoding vertices in
its support must lie in `D={u:F_0(u) != F_1(u)}`; therefore
`dist(w_0,w_1) <= mu_1(D)=r+s <= 2a`. Optimizing the right-hand side of
(3.57h) yields (3.57g). The zero-mass cases are immediate.

Theorem 2.9 of GMWZ gives `lambda_k=1/k+k^{O(1)}/d`, and the Section 6 choice
of `d` makes `lambda_k=O(1/k)`. Thus this entire random face-splitting family
is already excluded as a constant-error unique-decoding obstruction by the
published second-singular-value estimate; no unproved exponential
face-avoidance tail is needed. The stronger (3.57e) profile remains relevant
only for distance-weighted quantitative bounds or for patch families whose
decoder-conditioned face events cannot be reduced to the uniform left-face
marginal.

### Proposition 3.9M (smooth-decoder spectral refinement)

The remaining source question can be isolated as a conditional-density parameter.
If, for some κ≥1,

```
theta_i(t) <= kappa mu_i,   i in {0,1}, all t,                    (3.57i)
```

then the same argument gives

```
Gamma_01 <= 2 kappa lambda_k^2.                                   (3.57j)
```

Indeed, (3.57i) gives Γ₀₁ ≤ dist(w₀,w₁) κ min{μ(U₀),μ(U₁)}, while
(3.57h) and dist(w₀,w₁) ≤ r+s ≤ 2 max{r,s} finish the bound. GMWZ's
agnostic-decoding condition is conditioned on a right face and does not imply
(3.57i). Hence a bounded κ is the exact distributional-soundness gate left by
the random-split analysis: either prove it for the actual decoder, or construct
a coordinate-concentrated face event that forces κ to be large.

### Proposition 3.9N (full face-separable spectral closure)

The spectral argument does not actually require the random split. Return to any
face-separable patch satisfying (3.57a), and define

    E_i = {u : H(u) != F_i(u)},   i in {0,1}.                       (3.57k)

Every face in U_i avoids E_i, so expander mixing yields
mu(U_i) <= lambda_k^2 / mu_1(E_i) whenever mu_1(E_i)>0. Moreover,
E_0 union E_1 contains D={u:F_0(u) != F_1(u)}. If
delta=dist(w_0,w_1), deterministic perfect base decoding gives
delta <= mu_1(D) <= mu_1(E_0)+mu_1(E_1). Therefore, with
a=max_i mu_1(E_i), a>=delta/2, and the uniform coordinate/left-face
marginals imply

    Gamma_01 <= min{delta, delta lambda_k^2/a}
             <= min{delta, 2 lambda_k^2} <= sqrt(2) lambda_k.       (3.57l)

Thus the published X(1)<->X(k) spectrum closes the entire face-separable
patchability class at constant error for the GMWZ parameter regime, not merely
the random split. Any remaining source-specific unique-decoding obstruction
must use a right labeling that is not a common vertex word, or a genuinely
cross-coordinate/global assignment not captured by (3.57a).

### Proposition 3.9O (collision gate for arbitrary right labels)

The same disagreement mechanism does not require the right label to be a
restriction of a vertex word. Let nu be the right-face marginal and put

    p_i(B) = Pr[A in U_i | B],   mu_i = Pr[A in U_i].                (3.57m)

Assume the left label on U_i is F_i|_A, while the right label T_2[B] is
arbitrary. Let D={u:F_0(u) != F_1(u)}, rho=Pr[B cap D=empty], and suppose

    E_nu[(p_i-mu_i)^2] <= eta^2 mu_i,   i in {0,1}.                 (3.57n)

Then the projection violation contributed by the two clusters is at least

    (min{mu_0,mu_1}/2) [1-rho-4 eta^2(1/mu_0+1/mu_1)]_+.           (3.57o)

On every B meeting D, the restrictions F_0|_B and F_1|_B differ, so a
single right label can agree with at most one branch. The exceptional set where
p_i(B)<mu_i/2 has mass at most 4 eta^2/mu_i; removing these sets and
the rho-mass of faces avoiding D proves (3.57o).

If delta=dist(w_0,w_1), perfect base decoding gives mu_1(D)>=delta. The
published X(1)<->X(s) spectrum then gives rho<=lambda_s^2/delta. Hence a
small X(k)<->X(s) incidence parameter eta would rule out arbitrary-right-label
two-cluster patches, not merely the common-vertex-word subclass. Theorem 2.9
does not state this X(k)<->X(s) L2-profile, so (3.57n) is a precise new
distributional-soundness/HDX target rather than an automatic source consequence.

This source boundary is substantive. Theorem 2.9 explicitly supplies the
\(X(1)\leftrightarrow X(i)\) inclusion spectrum, local link expansion, and the
\((k,\sqrt{k})\) direct-product test, but these are different quantified objects from the
\(X(k)\leftrightarrow X(\sqrt{k})\) \(L_2\) profile in (3.57n). The low-soundness
direct-product characterization of Bafna--Minzer likewise warns that spectral expansion
alone is insufficient and that an additional Unique-Games coboundary property is needed.
Consequently Proposition 3.9O is a genuine source-specific theorem gate: proving this profile
would close the arbitrary-right-label two-cluster class, while a counterexample under the same
source hypotheses would yield a unique-decoding separation. Neither direction is claimed here.

### Lemma 3.9P (DPT variance identity)

There is a sharper way to target the missing profile. For a face family
\(U\subseteq X(k)\), define the constant table \(T_U[A]={\bf 1}_{A\in U}{\bf 1}^k\), and set
(p(B)=\Pr[A\in U\mid B]), (mu=\Pr[A\in U]). The shared-(s)-face direct-product test
accepts precisely when the two sampled (k)-faces have the same cluster bit, hence

\[
 \operatorname{Acc}(T_U)=\mathbb E_B[p(B)^2+(1-p(B))^2]
 =1-2\mu(1-\mu)+2\operatorname{Var}(p(B)).
\tag{3.57p}
\]

Thus the L2 incidence deviation in Proposition 3.9O is exactly the consistency excess of a
two-symbol direct-product table. The resulting open dichotomy is: small variance feeds the
collision gate directly; large variance should, if a quantitative DPT-to-patch theorem can be
proved, yield approximate vertex words on heavy subfamilies and feed Proposition 3.9N instead.
The DPT definition alone only promises a global word on a polynomial fraction of faces, so it
does not yet supply the two-cluster heavy-mass or common-label conclusion.

### Proposition 3.9P' (quantitative double-cluster visibility threshold)

The missing conclusion can be stated as an exact mass threshold. Let \(U_0,U_1\) be
disjoint clusters of masses \(\mu_0,\mu_1\), and tag the two cluster tables by \(0,1\),
while the complement uses a disjoint tag \(\bot\) and a table \(T^\star\). Suppose a
proposed DPT-to-global-word theorem, on any table with shared-top agreement at least
\(\delta\), returns a single base vertex word whose tag is constant and which is within
\(\zeta<1/2\) on a face fraction at least \(\kappa(\delta)\). If
\[
  \sup_H \Pr_A[T^\star[A]\text{ is }\zeta\text{-close to }H|_A]
  \le \varepsilon_\star.
\]
Then necessarily
\[
  \kappa(\delta)\le \max\{\mu_0,\mu_1,\varepsilon_\star\}.
\tag{3.57p'}
\]
Indeed, a constant tag \(0\) word cannot be close to any tag-\(1\) face and cannot match
the disjoint \(\bot\) tag, so it explains at most \(\mu_0\) faces. The same argument
applies to tag \(1\). A constant \(\bot\) word can explain only the low-agreement
complement. Thus a theorem guaranteeing
\(\kappa(\delta)>\max\{\mu_0,\mu_1\}+\varepsilon_\star\) would force genuine mass from
both clusters and could feed the cross-cluster synchronization inequalities. A guarantee
of only \(\kappa(\delta)\le\max\{\mu_0,\mu_1\}\) can be witnessed by one cluster alone and
gives no double-cluster extraction. This is the precise quantitative gap left by the DPT
definition; ordinary total-mass soundness does not supply it.

### Proposition 3.9T (overlap-aware obstruction for vertex-varying tags)

The constant-tag assumption in Proposition 3.9P' is not necessary if the two clusters have
overlapping vertex-incidence laws. Let \(\nu_i\) be the distribution obtained by sampling a
face uniformly from \(U_i\) and then a uniformly random vertex of that face, and define

\[
  \chi:=\sum_{v\in X(1)}\min\{\nu_0(v),\nu_1(v)\}
      =1-\operatorname{TV}(\nu_0,\nu_1).
\tag{3.57t-a}
\]

Let \(F:X(1)\to\Sigma\) be any vertex word, with arbitrary vertex-varying tag
\(\tau_F(v)\in\{0,1,\bot\}\). If tag disagreement costs at least one symbol error and
\[
 \lambda_i(F):=\Pr_{A\sim U_i}
 [\operatorname{dist}(T[A],F|_A)\le\zeta],
 \qquad 0\le\zeta<1,
\]
then

\[
 (1-\zeta)\bigl(\lambda_0(F)+\lambda_1(F)\bigr)\le 2-\chi.
\tag{3.57t-b}
\]

Consequently, with \(\mu_{\max}=\max\{\mu_0,\mu_1\}\),

\[
 \mu_0\lambda_0(F)+\mu_1\lambda_1(F)
 \le \frac{\mu_{\max}(2-\chi)}{1-\zeta}.
\tag{3.57t-c}
\]

If the complement table \(T^\star\) has \(\zeta\)-agreement at most
\(\varepsilon_\star\) with every vertex word, then every DPT-to-global-word guarantee of
mass \(\kappa(\delta)\) must obey

\[
 \kappa(\delta)-\varepsilon_\star
 \le \frac{\mu_{\max}(2-\chi)}{1-\zeta}.
\tag{3.57u}
\]

To prove (3.57t-b), let
\(g_i(A)=k^{-1}|\{v\in A:\tau_F(v)=i\}|\). A face counted by \(\lambda_i(F)\) has
\(g_i(A)\ge1-\zeta\), so
\[
 \mathbb E_{\nu_i}[\mathbf 1_{\tau_F=i}]
 \ge (1-\zeta)\lambda_i(F).
\]
Since the tags \(0\) and \(1\) are mutually exclusive at each vertex,
\[
 \mathbb E_{\nu_0}[\mathbf 1_{\tau_F=0}]
 +\mathbb E_{\nu_1}[\mathbf 1_{\tau_F=1}]
 \le \sum_v\max\{\nu_0(v),\nu_1(v)\}=2-\chi,
\]
which proves (3.57t-b), and (3.57t-c) follows by multiplying by \(\mu_{\max}\). The complement
can account for at most \(\varepsilon_\star\), proving (3.57u).

This is the correct extension of the constant-tag gate to the actual DPT quantifier:
Definition 2.8 permits an arbitrary \(F:X(1)\to\Sigma\), not a globally constant tag.
When \(\chi=0\), the two clusters can be separated on vertex support and the bound gives no
new obstruction; when \(\chi\) is large, a mass beyond the heavier-cluster threshold is
impossible even for vertex-varying tags. Thus the remaining source-specific positive target is
an incidence-overlap lower bound for the computation-generated clusters, while a small-\(\chi\)
assignment is a concrete cover/sheet obstruction. This proposition is derived here and does
not upgrade the published GMWZ list-decoding theorem to unique decoding.


### Proposition 3.9U (GMWZ vertex-incidence overlap closes the varying-tag escape)

Let \(U_i\subseteq X(k)\) have \(\mu_k\)-mass \(\mu_i>0\), and let \(\nu_i\) be the
vertex distribution obtained by sampling \(A\in U_i\) and then a uniformly random vertex of
\(A\). If \(\lambda_{k,1}\) is the second singular value of the weighted
\(X(1)\)--\(X(k)\) inclusion graph, then

\[
  \operatorname{TV}(\nu_i,\mu_1)
  \le \frac{\lambda_{k,1}}{\sqrt{\mu_i}},
\tag{3.57t-d}
\]
where \(\mu_1\) is the stationary vertex measure. Hence for two clusters

\[
  \chi:=1-\operatorname{TV}(\nu_0,\nu_1)
  \ge
  \left[
    1-\lambda_{k,1}
      \left(\mu_0^{-1/2}+\mu_1^{-1/2}\right)
  \right]_+.
\tag{3.57t-e}
\]

In particular, if both masses are at least \(\mu_\star\),
\[
  \chi\ge\left[1-\frac{2\lambda_{k,1}}{\sqrt{\mu_\star}}\right]_+.
\tag{3.57t-f}
\]
The explicit inclusion-spectrum clause in GMWZ Theorem 2.9 gives
\[
  \lambda_{k,1}=\frac1k+\frac{k^{O(1)}}d.
\tag{3.57t-g}
\]
Thus, when \(k^{O(1)}/d=o(\sqrt{\mu_\star})\), the overlap-aware obstruction
Proposition 3.9T applies with \(\chi=1-o(1)\), and every proposed DPT mass must obey

\[
  \kappa(\delta)-\varepsilon_\star
  \le
  \frac{\mu_{\max}}{1-\zeta}
  \left(1+\frac{2\lambda_{k,1}}{\sqrt{\mu_\star}}\right).
\tag{3.57t-h}
\]

For (3.57t-d), the expander-mixing inequality gives, for every vertex set \(V\),
\[
 \left|
 \Pr_{A\sim X(k),\,v\in A}[A\in U_i,\ v\in V]
 -\mu_i\mu_1(V)
 \right|
 \le \lambda_{k,1}\sqrt{\mu_i\mu_1(V)}.
\]
After conditioning on \(A\in U_i\), this yields
\(|\nu_i(V)-\mu_1(V)|\le\lambda_{k,1}/\sqrt{\mu_i}\). Taking the supremum over \(V\)
and applying the triangle inequality proves (3.57t-d)--(3.57t-f); (3.57t-h) is
Proposition 3.9T with \(2-\chi\le1+2\lambda_{k,1}/\sqrt{\mu_\star}\).

This closes the vertex-support/separated-tag escape for the GMWZ HDX in the displayed
parameter window, but it does not synchronize the payload words: cross-face decoder-marginal
transfer, cover-sheet binding, and the RW address-scale attachment remain separate gates.
The input from GMWZ is only the \(X(1)\)--\(X(k)\) spectrum, not the missing
\(X(k)\)--\(X(\sqrt{k})\) profile.

### Proposition 3.9Q (BMVY/DDL source-specific cover obstruction for the shared-top DPT)

The shared-top sampler creates a source-specific obstruction to interpreting distributional
agreement as one base global word. Let \(K\) be the target face dimension, let the affine
building have ambient dimension \(d\ge 3K\), and let
\(X_i=\Gamma_i\backslash\widetilde C_d(\mathbb Q_p)\) be two consecutive BMVY finite
quotients with \(\Gamma_{i+1}<\Gamma_i\), finite index
\(\ell=[\Gamma_i:\Gamma_{i+1}]>1\), and the BMVY displacement condition
\(\operatorname{dist}(v,\gamma v)\ge4\) for every nonidentity group element. Then
\(X_{i+1}^{\le K}\to X_i^{\le K}\) is a finite connected \(\ell\)-cover.

DDL Theorem 3.15 gives, for sufficiently large \(p\),

\[
\lambda_K\le\max\left\{\frac{C}{\sqrt p},\frac1{d-K+1}\right\}<\frac{.99}{K}.
\]

Thus the \(K\)-skeleton \(X_i^{\le K}\) satisfies the hypotheses of the
Dikstein--Dinur cover-obstruction lemma. There is a Boolean face table
\(\mathcal F=\{f_A:A\in X_i(K)\}\) such that, for the shared-top \(V\)-test (equivalently
the GMWZ/BMVY sampler after the integer rounding of \(\sqrt{K}\)),

\[
\operatorname{Agree}_{V}(\mathcal F)\ge 1/\ell,
\qquad
\forall H:X_i(0)\to\{0,1\},\quad
\Pr_A[f_A\overset{1-\zeta}{\approx}H|_A]
\le \exp(-\Omega_\zeta(K)).
\tag{3.57q}
\]

Consequently, ordinary DPT consistency or distributional/list soundness cannot, on this
source, be used as a black-box proof that all accepted local views arise from a single
base-address global word. A simultaneous coordinate-robust construction must either use
a cover-free source, expose and bind the sheet index, add a coordinate-normalized outer
check, or change the target to a cover lift-word. The negative lemma uses only two-sided HDX
and the finite connected cover; swap-cocycle expansion belongs to the separate cover-aware
positive theorem. This is source-specific, not a general dPCP impossibility theorem and does
not by itself imply an RLDC/LDC length lower bound. The parameter closure is recorded in
[note 202](../../../mcsp-hardness-magnification/notes/202-bmvy-ddl-parameter-closure-for-cover-obstruction-2026-08-16.md).

The cover degree also fixes the relevant soundness scale. In the BMVY filtration used
here, the quantified index estimate is
\(\ell=\ell_0^{\Theta(d^2)}\); with \(d=\Theta(K)\), this gives
\[
  \log \ell=\Theta(K^2\log\ell_0),
  \qquad
  1/\ell=\exp[-\Theta(K^2\log\ell_0)].
\tag{3.57q-a}
\]
Thus the cover lemma's agreement witness is below every fixed inverse-polynomial
window. Conversely, any target-independent sheet selector with completeness
\(\alpha>0\), using a \(d_{\rm desc}\)-bit descriptor and \(q\) common-address queries,
must satisfy
\[
  d_{\rm desc}+q\log_2|\Sigma|
  \ge \log_2\ell-\log_2(1/\alpha)
  =\Theta(K^2\log\ell_0),
\tag{3.57q-b}
\]
by the adaptive transcript counting argument. Therefore a \(K\operatorname{polylog}K\)
proof and same-scale descriptor cannot bind all sheets over a fixed alphabet. This
parameter conclusion is source-specific and is stated formally in
[note 267](../../../mcsp-hardness-magnification/notes/267-bmvy-cover-degree-soundness-window-alignment-2026-08-20.md);
it does not identify the exact GMWZ acceptance window or rule out a cover-free,
target-normalized, or exponentially-small-soundness construction.

### Proposition 3.9R (BMVY incidence profile closes the arbitrary-right-label patch)

The preceding cover obstruction does not by itself close the two-cluster patch class.
For the BMVY-induced \(\mu_K\to\mu_s\) marginal, however, let
\[
\theta_{K,s}\le \sqrt{\frac{s+1}{K+1}}+\operatorname{poly}(K)\gamma
\]
be the nontrivial singular-value bound from BMVY Lemma 2.8, with
\(s=\lceil\sqrt K\rceil\), and use BMVY Theorem 2.2 at the endpoint:
\[
\theta_{s,1}\le \frac{2}{s+1}+O(s\gamma).
\]
If \(\operatorname{poly}(K)\gamma=o(K^{-1/4})\), \(s\gamma=o(s^{-1})\), and two
face families \(U_0,U_1\) have masses at least \(\mu_0>0\) while their left words
disagree on a vertex set of mass \(\delta>0\), then the arbitrary-right-label collision
inequality of Proposition 3.9O gives
\[
\operatorname{Viol}_{\mathrm{patch}}
\ge
\frac{\mu_0}{2}
\left[
1-O\!\left(\frac1{K\delta}\right)
-O\!\left(\frac1{\mu_0\sqrt K}\right)
\right]_+.
\tag{3.57r}
\]
In particular, for fixed \(\mu_0,\delta>0\) and sufficiently large \(K\), the violation is
at least \(\mu_0/4\), even when the right label is not a restriction of a vertex word.
The statement is source-specific: it uses the BMVY containment marginal and does not
assert that GMWZ Theorem 2.9 supplies this profile for every shared-top sampler. It
closes one patch class, not cover-sheet binding or a genuinely cross-coordinate global
assignment. See [note 203](../../../mcsp-hardness-magnification/notes/203-bmvy-incidence-profile-closes-arbitrary-right-label-patch-2026-08-16.md).

### Proposition 3.9S (GMWZ heavy-cluster marginal closure)

The latent-top covariance gate can be closed for the factorized heavy-cluster events
that occur in the GMWZ direct-product cross-law. Take \(k=r^2\) to be a perfect
square and put \(s=r=\sqrt{k}\), as in the source tester, and let
\(U_i,U_j\subseteq X(k)\) be disjoint heavy clusters with
\(\mu_0=\min\{\mu_i,\mu_j\}\), and sample a shared top face \(U\), a shared
\(s\)-face \(B\subseteq U\), and \(A,A'\) independently conditioned on \((U,B)\).
After conditioning on \(B\), attach the independent decoder view \((t,u)\) from the
base law. Assume the global \(X(k)\to X(s)\) centered-incidence profile is
\(\theta_0\), every \(s\)-link \(X_B(k-s)\to X_B(d-s)\) has profile \(\theta_1\), and
\[
\theta_0^2\le\frac{\mu_0}{4},\qquad
\theta_1^2\le\frac{\mu_0}{4}.
\tag{3.57s}
\]
Then for \(C_{ij}=\{A\in U_i,A'\in U_j\}\),
\[
\gamma_{ij}:=\Pr[C_{ij}]\ge\frac{\mu_0^2}{2},
\qquad
\xi_{ij}\le
\frac{4\theta_0}{\sqrt{\mu_0}}
+\frac{2\theta_0^2+4\theta_1^2}{\mu_0}.
\tag{3.57t}
\]

The global profile controls the fluctuation of
\(r_\ell(B)=\Pr[A_\ell\in U_\ell\mid B]\), while the link profile controls the
conditional covariance of the two incidences after \(U,B\) are fixed. Applying
the latent-top identity of C190 and the covariance contraction of C191 gives
(3.57t). BMVY Lemma 2.8 supplies
\[
\theta_0\le\sqrt{s/k}+\operatorname{poly}(k)\Gamma_{\varnothing},\qquad
\theta_1\le\sqrt{(k-s)/(d-s)}+\operatorname{poly}(d-s)\Gamma_+.
\]
Here \(\Gamma_+=\operatorname{poly}(d)/\sqrt q\) on nonempty links and
\(\Gamma_{\varnothing}\le1/(d-1)+2/\sqrt q\) for the empty link in the BMVY
source. Thus choose \(d\) after \(k\) to absorb the empty-link loss, and then
choose \(q\) to absorb the \(q^{-1/2}\) terms.
Thus the factorized heavy-cluster \(\xi\)-gate is source-specifically closed once
these profiles and the displayed mass inequalities are met. This is not a
unique-decoding theorem: common-word/label consistency, non-factorized events,
cover-sheet binding, and the RW address-scale gate remain separate. The full
calculation is in [note 207](../../../mcsp-hardness-magnification/notes/207-gmwz-heavy-cluster-marginal-closure-from-bmvy-link-spectrum-2026-08-17.md).

### Proposition 3.9V (factorized cross-cluster synchronization gate)

The preceding source-specific marginal closure and the global-reference transfer
combine into one explicit test for upgrading the factorized GMWZ cross-cluster event
to a singleton decoded word. Under the hypotheses of Proposition 3.9S, let there be
a common vertex word \(g\), with cluster errors \(\varepsilon_i,\varepsilon_j\),
left-incidence smoothness factors \(\Lambda_i,\Lambda_j\), and base decoder word
errors at most \(\eta\). Then

\[
\operatorname{dist}(w_i,w_j)
\le
\frac{4\theta_0}{\sqrt{\mu_0}}
+\frac{2\theta_0^2+4\theta_1^2}{\mu_0}
+\frac{2(\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j)}{\mu_0^2}
+2\eta .
\tag{3.57v}
\]

Hence a \(\Delta\)-separated valid-word family synchronizes whenever the right-hand
side is \(<\Delta\). Indeed, Proposition 3.9S gives
\(\gamma_{ij}\ge\mu_0^2/2\) and the displayed \(\xi_{ij}\) bound; Lemma 3.9I
then bounds the base-distribution decoder disagreement by that \(\xi_{ij}\) plus
\(2(\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j)/\mu_0^2\), and the
usual two decoder-error charging argument adds \(2\eta\). The full statement and
source-scale consequence are recorded in [note 356](../../../mcsp-hardness-magnification/notes/356-gmwz-factorized-synchronization-gate-2026-08-18.md).

In particular, if \(\Lambda_i,\Lambda_j\le\Lambda\), \(\varepsilon_i,\varepsilon_j\le
\varepsilon\), and the GMWZ base error is \(\eta=5\sqrt\delta\), then the
right-hand side is at most

\[
\frac{4\theta_0}{\sqrt{\mu_0}}
+\frac{2\theta_0^2+4\theta_1^2}{\mu_0}
+\frac{4\Lambda\varepsilon}{\mu_0^2}+10\sqrt\delta .
\tag{3.57w}
\]

Thus the native estimate \(\varepsilon\le\delta+\kappa\) requires
\(\delta+\kappa=O(\mu_0^2)\) for this route even to remain nonvacuous. With
\(\mu_0=\delta^{C_*}\), the native \(\delta\)-term is
\(4\Lambda\delta^{1-2C_*}\); for \(C_*>1/2\) it diverges as \(\delta\to0\).
This is a source-specific synchronization barrier, not a claim that the published
GMWZ theorem is impossible to modify: Lemma 6.2 does not provide the common word or
the stronger coherence estimate.

### Lemma 3.9I (global-reference transfer across clusters)

The black-box selector obstruction leaves one concrete positive escape route: the
computation-generated left table might be close to one global vertex word, rather than to
independent cluster functions. Let the shared-top sampler produce
\((A,A',B,u)\), with \(A,A'\in X(k)\), \(B\in X(s)\), \(u\in B\), and put
\[
\mu_i=\Pr[A\in U_i],\qquad
\gamma_{ij}=\Pr[A\in U_i,A'\in U_j].
\]
Assume a \(\Lambda\)-smooth left-incidence marginal: for \(\ell\in\{i,j\}\), every
realized face \(A\in U_\ell\) and every \(v\in A\) satisfy
\(\Pr[u=v\mid A]\le\Lambda_\ell/k\); uniform incidence is \(\Lambda_i=\Lambda_j=1\).
For the \(j\)-term, \(A\) denotes the corresponding right face \(A'\).
Suppose there is a single
\(g:X(1)\to\Sigma\) and functions \(f_i,f_j\) such that, pointwise for
\(A\in U_i\) and \(A'\in U_j\),
\[
\operatorname{dist}(f_i|_A,g|_A)\le\varepsilon_i,\qquad
\operatorname{dist}(f_j|_{A'},g|_{A'})\le\varepsilon_j.
\tag{3.58}
\]
Couple the same decoder randomness and define
\[
\rho^{\mathrm{cross}}_{ij}:=
\Pr[D_t(u,f_i(u))\ne D_t(u,f_j(u))
\mid A\in U_i,A'\in U_j].
\]
Then
\[
\rho^{\mathrm{cross}}_{ij}\le
\frac{\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j}{\gamma_{ij}}.
\tag{3.59}
\]
Indeed, if \(E_i=\{u:f_i(u)\ne g(u)\}\), the left-incidence assumption gives
\[
\Pr[A\in U_i,u\in E_i]
\le\mathbb E\!\left[
\mathbf 1_{A\in U_i}\frac{\Lambda_i|A\cap E_i|}{k}
\right]\le\Lambda_i\mu_i\varepsilon_i,
\]
and conditioning on the cross event divides this bound by \(\gamma_{ij}\); the \(j\)-term is
identical and a union bound proves (3.59).

The synchronization conclusion must use errors under this same conditioned distribution.
If
\[
e_\ell^{ij}:=
\Pr[D_t(u,f_\ell(u))\ne(w_\ell)_t
\mid A\in U_i,A'\in U_j]\le\eta
\quad(\ell=i,j),
\]
and the valid-word family is \(\Delta\)-separated, then
\[
\frac{\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j}{\gamma_{ij}}
<\Delta-2\eta
\tag{3.60}
\]
forces \(w_i=w_j\). A base-distribution error estimate may replace \(e_\ell^{ij}\) only
after a separate total-variation transfer to the conditioned cross distribution. If the
induced \((t,u)\) marginal under the cross event is at total-variation distance at most
\(\xi_{ij}\) from the base decoder distribution, the corresponding base-distribution
condition is
\[
\xi_{ij}+
\frac{\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j}{\gamma_{ij}}
<\Delta-2\eta.
\tag{3.60'}
\]

In particular, if \(\mu_i,\mu_j\ge\mu_0\), \(\gamma_{ij}\ge\mu_0^2/2\),
\(\Lambda_i,\Lambda_j\le\Lambda\), and \(\varepsilon_i,\varepsilon_j\le\varepsilon\), then
\(\rho^{\mathrm{cross}}_{ij}\le4\Lambda\varepsilon/\mu_0^2\). If \(T_1[A]\) is
\(\kappa_i\)-close to \(g|_A\) while \(f_i|_A\) is \(\delta\)-close to \(T_1[A]\), then
\(\varepsilon_i\le\delta+\kappa_i\). Thus the GMWZ heavy-cluster scale
\(\mu_0=\delta^C\) would require
\[
\Lambda(\delta+\max_i\kappa_i)+\xi_0=o(\delta^{2C})
\tag{3.61}
\]
for an \(o(1)\) base-distribution disagreement. Lemma 6.2 supplies neither the global reference
word \(g\) nor the smooth left-incidence marginal, so Lemma 3.9I is a semantic positive interface and
parameter test, not an upgrade of the published list-decoding theorem.
Even granting the optimistic source-scale error \(\varepsilon_i=\Theta(\delta)\), the
idealized \(\Lambda=1,\kappa_i=\xi_0=0\) specialization gives the vacuous upper bound
\(\Theta(\delta^{1-2C})\) for the heavy-cluster constants \(C>1/2\). Thus improving only
\(\gamma_{ij}\) cannot close this route; the computation-generated left table would need
substantially stronger global coherence.

There is an additional source-parameter gate. [Section 6 of the GMWZ construction](https://arxiv.org/html/2512.12960#S6.2) bounds the
base decoder error for each extracted word by \(5\sqrt{\delta}\). If \(\eta_{\rm base}\) denotes
the corresponding error under the base decoder distribution, then the strongest version of
this bridge would still require
\[
\xi_0+\frac{4\Lambda(\delta+\max_i\kappa_i)}{\delta^{2C}}
       +10\sqrt{\delta}<\Delta .
\tag{3.62}
\]
Here the \(\xi_0\) term transfers the disagreement estimate to the base distribution, while
the two decoder-word errors contribute \(2\eta_{\rm base}=10\sqrt{\delta}\). This is a
parameter obstruction for the published source bounds, not a claim that a new robust outer
decoder could not improve the \(5\sqrt{\delta}\) term.

The conditioning loss is sharp at this level of abstraction. For uniform incidence, take
disjoint faces with uniform \(u\mid A\), mark the prescribed error fraction of vertices in
each face, and correlate the other face with \(u\) so that all allowed marginal error mass
\(a_i=\mu_i\varepsilon_i\) and \(a_j=\mu_j\varepsilon_j\) lies inside a cross event of mass
\(\gamma_{ij}\). With disjoint error incidences and a constant reference word, a decoder
that reveals the sampled symbol attains
\((a_i+a_j)/\gamma_{ij}\). Thus eliminating the \(\gamma_{ij}^{-1}\) factor requires a
separate anti-concentration or incidence-mixing theorem; it cannot follow from the global-word
and marginal error statements alone. This sharpness construction is a probability-space
boundary, not an HDX counterexample.

### Proposition 3.10 (indexed-label locality barrier)

The indexed-list hypothesis has a separate information cost that is independent of soundness.
Let \(\Pi^{(s)}\in\Sigma^N\), \(s\in[L]\), be proofs in one common address space.  Fix a
coordinate \(i\), and let \(D_i\) be a target-independent adaptive decoder that makes at most
\(q\) proof queries and then outputs an index in \([L]\) (it may also output a symbol).  Put

\[
  S_q(\Sigma):=|\Sigma|^q.
\]

If indexed completeness holds with probability at least \(\alpha\),

\[
  \Pr_\omega\!\left[D_i^{\Pi^{(s)}}(\omega)\text{ outputs }s\right]
  \ge \alpha \qquad(s\in[L]),
  \tag{3.22}
\]

then

\[
  \alpha L\le S_q(\Sigma),
  \qquad\text{and hence}\qquad
  q\ge \log_{|\Sigma|}(\alpha L).
  \tag{3.23}
\]

For perfect indexed completeness, \(L\le S_q(\Sigma)\).  In particular, fixed alphabet and fixed
query count permit only constant \(L\); with binary proof symbols and \(L=k^d\), one needs

\[
  q\ge d\log_2 k-O(1).
  \tag{3.24}
\]

#### Proof

Fix the random tape \(\omega\).  The decoder is now a deterministic \(|\Sigma|\)-ary decision
tree of depth at most \(q\).  Its stopping transcripts are prefix-free: if one transcript
were a prefix of another, the decoder would make the same stop/continue decision after the
common prefix, which is impossible.  For every target \(s\) on which the decoder outputs \(s\),
record its leaf transcript \(T_s(\omega)\).  Two distinct correctly indexed targets cannot
share a leaf transcript, because the decoder would have the same output.  The corresponding
prefix-free leaf set has size at most \(|\Sigma|^q\) (extend each leaf to depth \(q\) and use
disjoint descendant sets).  Averaging over \(\omega\) gives

\[
  \sum_{s=1}^{L}
  \Pr_\omega\!\left[D_i^{\Pi^{(s)}}(\omega)\text{ outputs }s\right]
  \le S_q(\Sigma),
  \tag{3.25}
\]

which proves (3.23); (3.24) is the binary specialization. \(\square\)

The bound is tight at the information level: when \(L\le|\Sigma|^q\), put an injective
length-\(q\) \(\Sigma\)-ary encoding of the target index in \(q\) fixed proof cells and read
those cells. Thus the selector-symbol version of Theorem 3.8 can keep its proof length
independent of \(L\) only by paying for the index in the local answer alphabet, increasing
locality by \(\Omega(\log L)\), or adding a target-dependent/global label channel.  Binary
labels necessarily incur the \(\lceil\log_2L\rceil\) cost already visible in (3.17)--(3.19).
For instance, a fixed-alphabet 2-query dPCP cannot be black-box converted to a
target-independent indexed decoder with growing \(L\) and perfect indexed completeness.
This does not contradict ordinary list soundness: an ordinary list decoder outputs an
unlabelled symbol and never identifies which global word produced it.  Proposition 3.10 is
therefore a sharp locality--alphabet barrier for the missing label channel, not a proof-length
lower bound or a general impossibility theorem for new indexed dPCPs.

### Corollary 3.10A (inverse-linear indexed-channel tradeoff)

Suppose the intended distributional-to-coordinate route requires
\(\varepsilon_k\le c/k\), and suppose its indexed candidate list has
\[
  L_k\ge\varepsilon_k^{-d}
\]
for fixed \(c,d>0\).  Any target-independent \(q\)-query indexed decoder over
\(\Sigma\) with completeness \(\alpha>0\) must satisfy
\[
  q\log_2|\Sigma|
  \ge \log_2L_k+\log_2\alpha
  \ge d\log_2k-d\log_2c+\log_2\alpha .
\tag{3.42}
\]
Consequently a fixed alphabet forces \(q=\Omega(\log k)\), while constant locality forces
\(|\Sigma|=k^{\Omega(1)}\).  This cost is paid before the selector matrix or the outer decoder
is analyzed.

#### Proof

Apply Proposition 3.10 to \(L=L_k\) and substitute
\(L_k\ge(c/k)^{-d}\).  \(\square\)

This is a conditional parameter tradeoff, not a lower bound on every dPCP list size.  A
statement such as \(L=\operatorname{poly}(1/\varepsilon)\) is only an upper bound and does
not imply the premise \(L_k\ge\varepsilon_k^{-d}\).  The corollary says that any proposed
black-box list-to-index upgrade that actually exposes such a growing list must pay either
locality or alphabet size.  Combined with Theorem 3.9A, it isolates a three-way choice:
prove a smaller/singleton indexed list, pay \(q\log|\Sigma|=\Omega(\log k)\), or abandon a
target-independent local index channel.

### Corollary 3.11 (robust indexed labels enter the RLDC barrier)

The locality bound above has a robust counterpart. Let \(L=2^\ell\), let
\(\Pi^{(s)}\in\Sigma^N\) be proofs in one common address space indexed by
\(s\in\{0,1\}^{\ell}\), and fix one output coordinate \(i_0\). Suppose a target-independent
decoder \(I\) makes at most \(q\) proof queries and outputs an index \(s'\) or \(\bot\). Assume
that, for fixed \(\alpha>\beta\) and \(\rho>0\), it outputs \(s\) on \(\Pi^{(s)}\) with
probability at least \(\alpha\), while every \(z\) within relative distance \(\rho\) of
\(\Pi^{(s)}\) produces an index \(s'\notin\{s,\bot\}\) with probability at most \(\beta\).
Then \(s\mapsto\Pi^{(s)}\) is a positive-radius \(q\)-query relaxed local decoder for the
\(\ell\)-bit index message, with the same \((\alpha,\beta,\rho)\) parameters. Consequently,
every applicable fixed-parameter relaxed-LDC lower bound applies directly to \(N\). Under the
weak constant-success convention, independent repetition and thresholding give locality
\[
  Q=O\!\left(q(\alpha-\beta)^{-2}\right)
\]
with the same positive radius, so the external bound should be indexed by \(Q\), not the raw
query count \(q\); the external theorem must match this completeness convention, or one must
impose \(\alpha=1\). There is
also a message-inline upgrade in the binary case: define

\[
  \widehat C(s):=s\,\|\,\Pi^{(s)}\in\{0,1\}^{\ell+N}.
\]

On a requested bit, query the inline bit, run \(I\) on the proof suffix, and output that bit
only when the reported index has the same bit; otherwise output \(\bot\). This gives a raw
\((q+1)\)-query relaxed decoder; after threshold amplification its locality is \(Q+1\), with
any radius

\[
  \delta<\frac{\rho N}{\ell+N}.
\]

because a \(\delta\)-near inline word has a proof suffix within \(\rho\) of the target proof.
Thus a query-specific lower bound for the inline code applies to \(\ell+N\), not
automatically to \(N\) alone. In particular, if
that window gives

\[
  N\ge \ell^{\,1+\eta(Q,\Sigma,\alpha-\beta,\rho)}
  \tag{3.26}
\]

for some \(\eta>0\), robust indexed labels with \(L=2^\ell\) cannot have shorter proof
length in that window. For binary \(q=1\), perfect indexed completeness, and
\(\beta\le1/3\), the raw message-inline code is a 2-query RLDC, so an applicable exponential
2-query theorem yields

\[
  \ell+N\ge2^{\Omega(\ell)}=L^{\Omega(1)},
\]

not an unconditional lower bound on \(N\) without the inline step.

#### Proof

To decode index bit \(j\), run \(I\), output the \(j\)-th bit of \(s'\) when
\(s'\ne\bot\), and otherwise output \(\bot\). Honest indexed completeness gives probability
at least \(\alpha\) of the correct bit. A wrong bit on a \(\rho\)-near proof implies that
\(I\) output a non-\(\bot\) index differing from \(s\) in that bit, which is contained in
the wrong-index event and has probability at most \(\beta\). This is a \(q\)-query relaxed
local decoder. Moreover, two distinct proof words cannot be within distance \(\rho\):
completeness for one target would contradict robust soundness for the other because
\(\alpha>\beta\). The relaxed-LDC lower bound therefore applies. In addition, for
\(|\Sigma|\ge2\), the q-ary Singleton bound gives

\[
  2^\ell\le|\Sigma|^{N-d+1},
  \qquad
  N>\frac{\ell/\log_2|\Sigma|-1}{1-\rho},
  \tag{3.27}
\]

where \(d>\rho N\) is the integer minimum distance. This linear information bound is
independent of the external relaxed-LDC theorem. \(\square\)

For the standard constant-success convention, repeat \(I\)
\(R=\Theta((\alpha-\beta)^{-2})\) times and threshold the empirical frequency of each
index bit at \((\alpha+\beta)/2\), outputting \(\bot\) unless exactly one bit crosses the
threshold. Hoeffding gives locality \(Q=O(q(\alpha-\beta)^{-2})\); the same amplification
applies after the binary message-inline query.

This corollary is distinct from the ordinary indexed-list compiler. Theorem 3.8 allows a
nearby proof to be explained by another list word \(y_a\); selector consistency alone does
not force \(a=s\). The RLDC consequence applies only to a genuinely robust target-index
channel. For \(L=k^d\), \(\ell=\Theta(\log k)\), so this length barrier may be weaker than
Proposition 3.10; for \(\ell=\Omega(k)\), the binary \(q=1\) inline window gives
\(N\ge2^{\Omega(k)}\) up to the additive \(\ell\)-bit prefix. It therefore becomes a direct
near-linear proof-length obstruction. The standalone statement is [Robust indexed labels enter
the RLDC barrier](../../statements/robust-indexed-label-rldc-barrier.md).

### Proposition 3.12 (exchangeable approximate-index bridge)

The exact-index hypothesis can be relaxed, but only with a genuine cross-coordinate
condition. Let \(I\) be as in Corollary 3.11, and for a target \(s\) and a
\(\rho\)-near word \(z\) define the error object to be \(\bot\) when \(I^z=\bot\), and
\(I^z\oplus s\) otherwise. Suppose its distribution is invariant under every permutation of
the \(\ell\) index coordinates and

\[
  \mathbb E\!\left[\mathbf 1_{I^z\ne\bot}
  \frac{\operatorname{wt}(I^z\oplus s)}{\ell}\right]\le\eta,
  \qquad \alpha>\eta .
\]

Then reading one requested index bit gives a raw \(q\)-query relaxed decoder with honest
success at least \(\alpha\) and wrong-bit probability at most \(\eta\); the latter also
holds on the honest proof because the near-proof condition includes distance zero. Repeating
\(R=\Theta((\alpha-\eta)^{-2})\) times and accepting a bit only when it is the unique bit
whose empirical frequency crosses \((\alpha+\eta)R/2\) gives a weak constant-success RLDC of locality
\(Q=O(q(\alpha-\eta)^{-2})\). The same argument as in Corollary 3.11 shows that distinct
proofs have relative distance greater than \(\rho\).

The point is the exchangeability assumption: it makes every coordinate's wrong probability
equal to the average index error. Without it, an error vector can concentrate on one fixed
coordinate even when its normalized Hamming weight is \(1/\ell\). Thus ordinary dPCP list or
distributional soundness is not a black-box instantiation of this proposition; a successful
construction must prove a public symmetrization/relabelling lemma or pay for its failure.
The standalone statement is [Exchangeable approximate indices enter the RLDC barrier](../../statements/exchangeable-approximate-index-rldc-bridge.md).

### Proposition 3.13 (equivariant error profiles are invariant under public symmetrization)

Address symmetry alone does not imply the exchangeability hypothesis of Proposition 3.12.
Let a finite group \(G\) act by coordinate permutations on \(\{0,1\}^{\ell}\) and by
Hamming isometries on the proof space. For a target \(s\), proof word \(z\), and coordinate
\(i\), write

\[
  p_{s,z}(i)=
  \Pr[I(z)\ne\bot\ \land\ I(z)_i\ne s_i].
\]

If the target-independent decoder has an equivariant error profile

\[
  p_{g s,g z}(g i)=p_{s,z}(i),
\tag{3.28}
\]

then every public wrapper

\[
  J_{\mathcal D}(z)=g^{-1}\!\cdot I(g\cdot z),\qquad g\leftarrow\mathcal D,
\]

has exactly the same profile:

\[
  p^{J_{\mathcal D}}_{s,z}(i)
  =\mathbb E_{g\sim\mathcal D}p_{g s,g z}(g i)
  =p_{s,z}(i).
\tag{3.29}
\]

If (3.28) holds up to additive error \(\xi\), the two profiles differ by at most \(\xi\).
Consequently, public address randomization cannot repair a non-exchangeable profile that is
already equivariant. A successful symmetrization theorem must break this equivariance or
establish a target-independent error law before averaging.

There is also a distribution-free minimax certificate. For a finite set \(\mathcal Q\) of
target/proof pairs and nonnegative weights \(\lambda_{s,z,i}\), let
\(\Lambda=\sum\lambda_{s,z,i}>0\) and

\[
  A_g(\lambda)=
  \sum_{s,z,i}\lambda_{s,z,i}\,p_{g s,g z}(g i).
\tag{3.30}
\]

If \(\min_g A_g(\lambda)\ge(\beta+\xi)\Lambda\), then no public distribution on \(G\) can
make every supported coordinate error at most \(\beta\): linearity gives

\[
  \sum_{s,z,i}\lambda_{s,z,i}p^{J_{\mathcal D}}_{s,z}(i)
  =\mathbb E_{g\sim\mathcal D}A_g(\lambda)
  \ge(\beta+\xi)\Lambda.
\tag{3.31}
\]

Thus a nonnegative weighted certificate is enough to rule out an entire class of public
symmetrizers, even when the profile is only approximately equivariant. Exact equivariance
is the special case in which \(A_g(\lambda)\) is independent of \(g\).

The earlier selector obstruction is an immediate corollary. Let \(c(s)\) be a covariant
exceptional-coordinate selector, \(c(gs)=g c(s)\). If the decoder outputs \(s\) with
probability \(\alpha\) and \(s\oplus e_{c(s)}\) with probability \(1-\alpha\), then the
wrapper has average index error \((1-\alpha)/\ell\), but error \(1-\alpha\) on coordinate
\(c(s)\) for every target in the image of \(c\). When
\(\alpha>(1-\alpha)/\ell\), this violates simultaneous coordinate robustness. The identity
behind the corollary is

\[
  g^{-1}\!\cdot\bigl((gs)\oplus e_{c(gs)}\bigr)
  =s\oplus e_{g^{-1}c(gs)}
  =s\oplus e_{c(s)}.
\]

The following Hadamard family realizes this obstruction explicitly, so the general statement
is not merely a selector-model artifact.

For \(\ell\ge2\), take the binary Hadamard family
\(\Pi^{(s)}(x)=\langle s,x\rangle\) on \(x\in\{0,1\}^{\ell}\). It is fully equivariant under
coordinate permutations and has relative distance \(1/2\). For any
\(0<\rho<1/4\), a decoder can nearest-decode the target index and, with probability
\(1-\alpha\), flip the coordinate of its unique \(1\) (using a fixed default otherwise).
Its normalized average index error is only \((1-\alpha)/\ell\), while it is correct with
probability \(\alpha\) on every proof.

If one tries to symmetrize by sampling any public distribution of permutations \(\pi\),
running the decoder on \(\pi\cdot z\), and applying \(\pi^{-1}\) to the reported index,
then on the target
\(s=e_j\) the bad branch always flips coordinate \(j\). The resulting error probability is
\(1-\alpha\), not \((1-\alpha)/\ell\). Hence a random address permutation is not a
black-box route from distributional/average index soundness to simultaneous coordinate
robustness. A successful construction must prove a target-independent error law (or an
equivalent orbit-averaged condition), rather than merely exhibit an equivariant proof
family. The full proof is [Equivariant address actions do not imply exchangeable index
errors](../../statements/equivariant-symmetrization-does-not-imply-exchangeability.md).

### Proposition 3.14 (equivariant orbit lifting)

Proposition 3.13 concerns a public wrapper applied to one target-independent decoder; it
does not by itself create a message family. The converse structural fact is useful here:
under exact covariance of the *verifier semantics*, a single target already carries its
whole target orbit.

Let a finite group \(G\) act on message coordinates by \(\pi_g\), on message bits by

\[
  (g m)_{\pi_g(i)}=m_i\oplus\chi_g(i),
\tag{3.32}
\]

and on \(\Sigma^N\) by Hamming isometries \(\rho_g\). Let \(m^0\) be a base target and
define \(C(gm^0)=\rho_g C^0\), assuming that the stabilizer of \(m^0\) fixes \(C^0\).
Suppose one target-independent verifier family \(V_{i,b}\), with at most \(q\) adaptive
queries, satisfies

\[
  p_{\pi_g(i),\,b\oplus\chi_g(i)}(\rho_g z)=p_{i,b}(z).
\tag{3.33}
\]

If, for every \(i\),

\[
  p_{i,m^0_i}(C^0)\ge\alpha,\qquad
  \operatorname{dist}(z,C^0)\le\rho
  \Longrightarrow
  p_{i,1-m^0_i}(z)\le\beta,
\tag{3.34}
\]

with \(\rho>0\) and \(\alpha>\beta\), then for every \(m=gm^0\), \(j=\pi_g(i)\), and
\(\operatorname{dist}(z,C(m))\le\rho\),

\[
  p_{j,m_j}(C(m))\ge\alpha,\qquad
  p_{j,1-m_j}(z)\le\beta.
\tag{3.35}
\]

Thus the orbit is a family-level target-relative ACRR in one common proof space. The proof
map has pairwise distance \(>\rho\) (and hence is injective), and threshold amplification gives a weak positive-radius relaxed decoder
with locality

\[
  Q=O\!\left(q(\alpha-\beta)^{-2}\right).
\tag{3.36}
\]

Indeed \(m_{\pi_g(i)}=m^0_i\oplus\chi_g(i)\), and (3.33) transports completeness from
\(C^0\) to \(\rho_g C^0\). If \(z\) is \(\rho\)-close to \(\rho_g C^0\), then
\(\rho_{g^{-1}}z\) is \(\rho\)-close to \(C^0\), so (3.34) transports the wrong-bit
soundness. If two distinct orbit targets had proof words at distance at most \(\rho\),
choose a coordinate on which they differ; completeness for one and wrong-bit soundness for
the other would contradict \(\alpha>\beta\). Repeating both branches and thresholding
proves (3.36).

For the full bit-flip orbit \(\mathcal M=\{0,1\}^k\), this places the construction directly
in the family-level RLDC barrier. Consequently a fixed finite alphabet, fixed \(q\), fixed
positive radius and fixed gap cannot coexist with \(N=k\operatorname{polylog}k\) whenever
the applicable relaxed-LDC lower-bound window holds. A successful single-target construction
must therefore make an escape explicit: its reachable orbit is small, its verifier or proof
address space depends on the target, acceptance covariance fails, the radius/gap degenerates,
or the proof leaves the family-level length regime. This is stronger than the public
symmetrization setting of Proposition 3.13, and is not an unconditional lower bound for
target-dependent verifiers.

The conclusion is quantitatively stable. If (3.33) holds only up to a uniform additive
semantic defect \(\xi\), then the orbit has completeness at least \(\alpha-\xi\) and
wrong-bit soundness at most \(\beta+\xi\). Therefore, when

\[
  \alpha-\beta-2\xi>0,
\tag{3.37}
\]

thresholding still gives locality
\[
  Q=O\!\left(q(\alpha-\beta-2\xi)^{-2}\right).
\tag{3.38}
\]

Consequently, a full-orbit near-linear construction cannot escape the family barrier through
a small implementation or compilation defect: its semantic covariance defect must reach at
least half of the original gap, or it must pay another explicit escape cost.

### Proposition 3.15 (strong-canonical PCP is not shared ACRR)

There is a separate class-complexity boundary on the tempting canonicalization route.  The
strong-canonical PCP theorem of Dinur--Goldreich--Gur shows that logarithmic-randomness
strong-canonical PCPs characterize \(\mathrm{UP}\), while polynomial-proof, polynomially
strong versions characterize \(\mathrm{UMA}\).  Hence applying such a system directly to an
NP-complete computation relation would imply \(\mathrm{NP}=\mathrm{UP}\) in the first regime,
or place \(\mathrm{NP}\) in \(\mathrm{UMA}\) in the second; it is not an unconditional
canonicalization of an arbitrary NP history.

Applying the system separately to the claims \((i,b)\) does not avoid this boundary: it
produces canonical proofs \(\Pi_{x,i,b}\) in separate proof/address spaces, whereas ACRR
requires one \(\Pi_x\) for every coordinate.  To obtain a shared proof one must add a local
synthesis map

\[
  S_{x,i,b,j}(D_x)=\Pi_{x,i,b}[j],
\]

where \(D_x\) is independent of \((i,b)\) and all maps use one physical address space.  If
the target classes have positive separation and the synthesis uses \(r\) shared-object
queries per proof symbol, message-inlining gives a relaxed local decoder with locality
\(1+q_C+q_P r\).  Thus this synthesis is itself an RLDC/coding object and inherits the
length barrier of the [shared half-space canonical synthesis barrier](../../statements/shared-halfspace-canonical-synthesis-barrier.md).
Canonicality supplies a single proof for one claim; it does not supply the missing
cross-coordinate synthesis.

This proposition does not separate \(\mathrm{UP}\), \(\mathrm{UMA}\), and \(\mathrm{NP}\), nor
does it prove a general ACRR impossibility.  It closes only the black-box inference
“strong-canonical” \(\Rightarrow\) “shared coordinate-robust” and leaves the genuine target
as a new shared-synthesis theorem or a general coding lower bound.  The formal route trilemma
and its assumptions are recorded in
[Strong-canonical PCP class barrier](../../statements/strong-canonical-pcp-class-barrier.md).

### Proposition 3.15A (shared-canonical synthesis has a log-log locality barrier)

The preceding trilemma has a quantitative consequence that applies to any successful
cross-coordinate synthesis, independently of the internal construction of the individual
canonical proofs.  Let \(A\ge2\) be fixed and suppose a shared synthesis produces a proof map

\[
  \Pi_k:\{0,1\}^k\to A^{P_k}
\]

and, for every \((i,b)\), an adaptive branch verifier of depth at most \(r=r(k)\) on this
same proof/address space.  Assume perfect correct-branch completeness, target-relative
wrong-branch error at most \(\beta\le1-\sigma_0\) on a fixed relative-radius \(\rho>0\),
and \(N_k=k+P_k\le k(\log k)^c\) for infinitely many \(k\).  Then

\[
  Q_{r,A}:=1+2\sum_{j<r}A^j
  =\Omega_{A,\rho,\sigma_0,c}
       \!\left(\frac{\log k}{\log\log k}\right),
\]

and hence, for fixed \(A\),

\[
  r\ge \log_A\log k-\log_A\log\log k-O_{A,\rho,\sigma_0,c}(1).
\tag{3.39}
\]

Indeed, inline the message bit and expose the two \(A\)-ary decision trees.  Their union,
together with the inline coordinate, gives a nonadaptive \(Q_{r,A}\)-query RLDC over an
alphabet of size \(A+2\), with constant radius and success gap \(1-\beta\).  The
arbitrary-alphabet RLDC lower bound then
gives the claimed inequality.  The full statement, including the constant contradiction
argument, is in [Strong-canonical shared synthesis locality barrier](../../../mcsp-hardness-magnification/notes/264-strong-canonical-shared-synthesis-loglog-locality-barrier-2026-08-18.md).

This is a derived coding barrier, not an impossibility theorem for all PCPs.  Its role is to
make the positive target precise: a strong-canonical route that keeps finite alphabet,
positive radius and near-linear length must either pay the log-log locality threshold or
leave the shared target-relative RLDC model.  Separate canonical proofs for \((i,b)\) do not
enter the proposition because they fail the common-address-space hypothesis.

### Proposition 3.15B (GMWZ fanout--locality closure dichotomy)

The source-specific direct-sum obstruction has a useful form that also covers
attempts to share symbols across coordinates. In the GMWZ Theorem 11.3
black-box interface, let \(S=2K\) be the \(2K\) logical slots of one selected
coordinate block, with \(K=k\log^{C'}k\). Let

\[
\phi:[k]\times[S]\longrightarrow[P]
\]

map source slots to physical proof positions, assume \(\phi(i,\cdot)\) is
injective for each \(i\), and let
\[
d=\max_{v\in[P]}|\phi^{-1}(v)|
\]
be the maximum cross-coordinate fanout. Then
\[
P\ge\frac{2Kk}{d}.
\tag{3.15B-1}
\]
Consequently, if \(P\le k(\log k)^c\), then
\[
d\ge2k(\log k)^{C'-c}.
\tag{3.15B-2}
\]

If, in addition, the same physical proof map is a family-level
target-relative shared proof with fixed finite alphabet, fixed positive radius,
perfect correct-branch completeness, and constant wrong-branch gap, then
Proposition 3.15A applies. Hence a near-linear compiler must simultaneously
have high fanout as in (3.15B-2) and branch-union locality
\[
Q_{r,A}=\Omega\!\left(\frac{\log k}{\log\log k}\right).
\tag{3.15B-3}
\]
In particular, a GMWZ black-box replacement with fanout
\(d\le k^\theta\) for a fixed \(\theta<1\), fixed branch depth, and fixed
finite alphabet cannot have proof length \(k\operatorname{polylog}k\).

The proof of (3.15B-1) is the slot-incidence count \(kS\le dP\). Under the
additional shared-proof hypotheses, (3.15B-3) is exactly Proposition 3.15A.
The proposition is therefore a closure theorem for this source architecture,
not a claim that every shared dPCP has either the GMWZ slot map or the stated
target-relative semantics. Leaving the black-box interface by algebraically
compressing several slots, using target-dependent addresses, or abandoning the
common proof is a new synthesis problem rather than a counterexample to the
dichotomy.

### Proposition 3.15C (claim-language non-invariance blocks free symmetry fanout)

There is no free permutation-based escape from Proposition 3.15B. Let a group
\(G\) act transitively on the \(k\) message coordinates, let \(\tau_g\) be the
induced action on codeword inputs, and fix a claim bit \(b\). Consider the claim
language
\[
L_{1,b}=\{C_0(m):m_1=b\}.
\]
Suppose a single PCPP/PCP block for \(L_{1,b}\) has an equivariant proof action
\(\rho_g\): completeness and acceptance are preserved under
\((w,\pi)\mapsto(\tau_gw,\rho_g\pi)\), while no-instances have a nonzero
soundness gap whenever they are at least \(\eta\)-far from \(L_{1,b}\). If
\(C_0\) has relative distance at least \(\Delta\) between codewords with
different first message bits and \(\eta\le\Delta\), then \(L_{1,b}\) must be
\(G\)-invariant.

Indeed, if \(w\in L_{1,b}\) but \(\tau_gw\notin L_{1,b}\), choose \(w\) so that
\(\tau_gw\) is a codeword whose first message bit is \(1-b\). The distance
assumption makes \(\tau_gw\) \(\Delta\)-far from \(L_{1,b}\). A perfectly
accepted proof for \(w\) transports under equivariance to a perfectly accepted
proof for this no-instance, contradicting soundness. A transitive coordinate
action does not preserve \(L_{1,b}\): choose \(m_1=b\) and set the coordinate
that \(g\) moves into position \(1\) to \(1-b\). Hence a GMWZ claim block cannot
be shared across a transitive coordinate orbit by address permutation alone.

High fanout must therefore either use a target-dependent verifier/address action,
retain multiple claim-specific semantics, or replace \(L_{1,b}\) by a genuinely
target-output relation with a new global soundness proof. Simple equivariant
relabelling is not that relation-PCP. This obstruction is semantic and
independent of the fanout count; it explains why the \(d\)-fanout escape in
Proposition 3.15B cannot be dismissed as a symmetry trick.

#### Corollary 3.15D (equivariant claim-private slots remain a direct sum)

Consider the claim-private slots in the GMWZ black-box interface, with \(2K\) logical
slots for each message coordinate. Suppose that every cross-coordinate reuse of a
claim-private physical position is implemented by a transitive coordinate action and an
equivariant transport of the corresponding proof symbols and verifier semantics. Under the
hypotheses of Proposition 3.15C, no such reuse is possible: a reused position would place
two distinct claim languages in the same nontrivial coordinate orbit, contradicting the
non-invariance conclusion there. Hence the private-slot fanout is \(d_{\rm priv}=1\), and

\[
  P_{\rm priv}\ge 2Kk.
\tag{3.15D-1}
\]

Thus a symmetry-only compression of the GMWZ private direct sum cannot produce a
\(k\operatorname{polylog}k\)-length proof. Any near-linear replacement must use a genuinely
target-output relation, target-dependent addressing, or a non-equivariant global synthesis;
it cannot obtain the needed fanout by permutation/relabelling alone. This is a
source-specific corollary, not a lower bound for arbitrary shared dPCPs.

## 4. What current near-linear dPCP constructions do and do not provide

The recent GMWZ construction gives, for every fixed \(\varepsilon>0\), a 2-query dPCP with
list size \(L=\varepsilon^{-O(1)}\), proof size \(N\log^{C(\varepsilon)}N\), and constants
that depend on \(\varepsilon\). Substituting the inverse-linear requirement
\(\varepsilon=\Theta(1/k)\) gives only

\[
  L=k^{O(1)},
  \qquad \text{alphabet and logarithmic exponent depending on }k.
\]

This does not give singleton target concentration or a uniform finite-alphabet/address
parameterization. The missing result is therefore not “another dPCP with fixed constant
error.” It is an inverse-linear-error target-concentration theorem with a common proof.

There is a second, independent obstruction in the GMWZ PCPP-to-RLDC transformation. For
each coordinate \(i\) and bit \(b\), it defines a separate circuit \(\varphi_{i,b}\) that
checks code membership and the value of the \(i\)-th message bit. It then takes a separate
PCPP \(\Psi_{i,b}\) for each language \(\mathrm{SAT}(\varphi_{i,b})\), and concatenates
the resulting coordinate-specific proof blocks into the final codeword. The decoder first
reads a declaration bit and only then selects the corresponding \(\Psi_{i,b}\) block.

This construction is a valid RLDC compiler. It is not, by itself, a relation-PCPP for

\[
  L_x=\{y:\exists w\ R(x,y,w)\}
\]

with a hidden witness and one proof reused for every output coordinate. A direct application
of a PCPP to the full assignment \((y,w)\) exposes the witness coordinates. A pair-language
PCPP hides \(w\), but its proof generally depends on \((x,y)\), so different claimed outputs
need not share one proof. The missing compiler must bind a target-output codeword to the
relation while keeping the witness hidden, the proof address space fixed, and the generation
time at the RW address scale.

The source architecture also has an exact black-box direct-sum cost.  After padding, each
selected coordinate proof \(\pi'_{i,m_i}\) has length \(2K\), with
\(K=k\log^{C'}k\), and the \(k\) selected blocks are disjoint.  Hence any
address-preserving compiler that keeps coordinate-private access and does not share symbols
across coordinates has proof suffix length at least
\(2Kk=\Omega(k^2\log^{C'}k)\).  This is not a general lower bound for shared proofs: it is
the source-specific reason that the GMWZ construction cannot be made near-linear by padding
removal or address relabelling alone.  A genuine improvement must supply a cross-coordinate
synthesis map in one physical address space, precisely the missing object in (259.4).  The
formal restricted proposition is recorded in
[the GMWZ private-block direct-sum barrier](../../../mcsp-hardness-magnification/notes/259-gmwz-private-block-direct-sum-barrier-2026-08-17.md).

The direct-sum count has a useful fanout refinement. Let \(S=2K\) be the
logical slots in one selected coordinate block, and let
\(\phi:[k]\times[S]\to[P]\) map logical source slots to physical proof positions.
Assume only that \(\phi(i,\cdot)\) is injective for each fixed \(i\), so the
compiler does not identify two distinct addresses of one source PCPP. If a
physical position is used by at most \(d\) logical slots across all coordinates,
then double counting gives

\[
P\ge \frac{kS}{d}=\frac{2Kk}{d}.
\tag{4.20a}
\]

Since \(K=k\log^{C'}k\), a proof of length \(k\log^c k\) requires
\(d\ge 2k\log^{C'-c}k\). Thus a near-linear escape cannot come from ordinary
permutations or padding removal: it must make each physical symbol serve
\(k/\operatorname{polylog}k\) source slots (and \(\Omega(k)\) slots when
\(C'\ge c\)). More generally, fanout \(d\le k^\theta\) leaves the lower bound
\(P=\Omega(k^{2-\theta}\log^{C'}k)\). This is the precise fanout dichotomy
behind the phrase “cross-coordinate synthesis”; it is still source-specific and
does not lower-bound arbitrary shared dPCPs. A self-contained statement and
scope boundary are given in [the GMWZ private-slot fanout dichotomy](../../../mcsp-hardness-magnification/notes/265-gmwz-private-slot-fanout-dichotomy-2026-08-18.md).

There is a second, semantic source-specific cap. A patch confined to the \(i\)-th private
block leaves the repeated common codeword block unchanged. For the wrong declaration
\(b=1-m_i\), the common input is at relative distance at least \(1-\mu\) from
\(\mathcal L_{i,b}\), by the outer code distance. Hence the PCPP soundness of
\(\Psi_{i,b}\) bounds every such patch's wrong-output probability by
\[
\varepsilon_{\rm pcpp}+O(\log^{-10}k),
\tag{4.21}
\]
where \(\varepsilon_{\rm pcpp}\) is the far-input acceptance bound. Thus, whenever this
quantity is at most the target error budget \(\beta\), private-only patches cannot supply
the \(\eta>\beta\) forcing hypothesis needed by the product-patch direct-sum theorem.
In GMWZ's theorem-level parameterization, \(\varepsilon_{\rm pcpp}=2\delta\) once the
distance threshold \(1-\mu\ge1-\delta^C\) is met. The GMWZ private blocks therefore
provide product realizability for arbitrary local strings, but their own wrong-claim PCPP
soundness blocks the constant-quality forcing event. Any stronger patchability route must
change the common block or use a semantic event outside this PCPP test.

More generally, partition the proof for target \(i\) into a common core \(C\) and a
private region \(R_i\). If private-only patches have wrong probability at most
\(\varepsilon_{\rm priv}\), then any patch \(B\) with wrong probability at least
\(\eta>\varepsilon_{\rm priv}\) must satisfy
\[
\Pr[S_i\cap(B\cap C)\ne\varnothing]\ge\eta-\varepsilon_{\rm priv}.
\tag{4.22}
\]
If \(|C|=M\), each honest query step hits a core position with probability at most
\(\lambda/M\), and the decoder makes at most \(Q\) queries, then
\[
|B\cap C|\ge\frac{(\eta-\varepsilon_{\rm priv})M}{Q\lambda}.
\tag{4.23}
\]
Thus semantic forcing that escapes the private PCPP cap must pay a smooth shared-core
support cost; without the smoothness hypothesis, (4.22) is the exact source-specific
statement.

For the literal GMWZ parameterization this cost can be evaluated. The common block is
r = 2ρK repetitions of a length-k/ρ codeword, hence has M_core = 2Kk positions. The
first decoder step samples one repetition and one
coordinate uniformly, so its core smoothness is exactly one. Therefore any mixed patch
whose wrong-output probability exceeds the private cap by
η − ε_priv must obey

\[
|B ∩ C| ≥ (η − ε_priv) · 2Kk.
\tag{4.24}
\]

The core plus the k selected private blocks has length 4Kk, giving the normalized
bound

\[
|B ∩ C|/(4Kk) ≥ (η − ε_priv)/2.
\tag{4.25}
\]

Thus a constant-quality semantic escape is not a small cross-coordinate patch: it must
corrupt a constant fraction of the shared repetition block (or leave the stated radius
window). Extra auxiliary padding weakens only the normalized fraction, not the absolute
support lower bound. This is a GMWZ-specific radius/support tradeoff, not a general
impossibility theorem for shared proofs.

The preceding distinction can be made quantitative. Suppose one tries to replace the
coordinate-specific blocks by a single proof map \(C:\{0,1\}^k\to\Sigma^N\). For each fixed
coordinate \(i\), use descriptor \(D_i=(i,M_i)\); each descriptor bucket then has entropy
\(k-1\). (An independent random \(I\) is equivalent after conditioning on \(I=i\).) Under
the common-address, all-policy, target-relative finite-time semantics, the
entropy--core inequality gives

\[
  k-1\le N h_2(R_D/N)+R_D\log_2|\Sigma|.
\]

Consequently, for \(N=k\operatorname{polylog}k\), a black-box shared-proof replacement with
\(R_D=o(k/\log k)\) is impossible. The relaxed-LDC version gives the corresponding
support--core alternative: average complete-policy core or all-policy branch support must
leave the low-cost window. This is a source-specific barrier against compressing the GMWZ
direct-sum architecture; it does not lower-bound GMWZ's separate PCPP blocks and does not
claim a general shared-proof impossibility theorem.

### Field-lifted one-proof output relation

There is a clean positive construction once the history-scale relation is allowed to carry
an explicit output-code field. Let \(R_x(h)\) be a satisfiable circuit relation whose
satisfying histories all have the same output \(m_x=F_x(h)\), and let
\(C:\{0,1\}^k\to\Gamma^M\) be an explicit outer code with a target-independent decoder.
Assume \(M\) is at least the history length. Replace each input symbol \(h_t\) by
\((h_t,\gamma_t)\), and define

\[
  \widehat R_{x,C}(h,\gamma)=1
  \quad\Longleftrightarrow\quad
  R_x(h)=1,\qquad \gamma=C(F_x(h)).
  \tag{4.1}
\]

The public projection \((h_t,\gamma_t)\mapsto\gamma_t\) is now defined at every dPCP
position. Hence every valid lifted word projects to the same codeword \(C(m_x)\), even
when its hidden histories differ. Applying the GMWZ 2-query dPCP theorem to
\(\widehat R_{x,C}\), and composing its local decoder with the outer decoder, gives one
global proof and at most \(2q_D\) proof queries per output coordinate. If the outer decoder
is exact-codeword safe and has honest-path smoothness \(\lambda\), the wrong-claim
probability is

\[
  \Pr[V_{x,i,1-m_{x,i}}(z)=1]\le q_D\lambda\varepsilon,
  \tag{4.2}
\]

for every candidate proof \(z\), where \(\varepsilon\) is the dPCP list error. The proof is
the first-bad-projection argument: all listed valid words project to the same \(C(m_x)\),
so a wrong outer output requires a first locally accepted projected-symbol error; smoothness
and the averaged dPCP error then give (4.2). The lifted circuit size is

\[
  O\!\bigl(\operatorname{size}(R_x)+\operatorname{size}(F_x)
  +\operatorname{size}(C)+M\bigr),
\]

so the resulting proof has GMWZ history/output-code scale
\(\widetilde O(\operatorname{size}(\widehat R_{x,C}))\), with the exponent and alphabet
dependence inherited from \(\varepsilon\). This is a genuine simultaneous one-proof
construction, not a concatenation of coordinate-specific proofs.

The construction also makes the remaining obstruction exact. An identity or repetition
output channel with \(M=\Theta(k)\) has \(\lambda=\Theta(k)\), forcing
\(\varepsilon=O(1/k)\) for a constant branch gap. A globally mixed outer code can keep
\(\lambda=O(1)\), but then its own LDC/RLDC length and locality become the cost. If \(h\)
is a full computation history, the lifted circuit and proof are still
\(h\operatorname{polylog}h\)-scale; this construction solves semantic shared-proof
consistency but not the address-scale evaluator required by the RW/JK closure theorem.
The full statement and proof are in [field-lifted one-proof compiler](../../../mcsp-hardness-magnification/notes/217-field-lifted-one-proof-output-relation-dpcp-compiler-2026-08-17.md).

### Proposition 4.2B (outer-query Lorenz field-lift bound)

The smoothness factor in (4.2) has an exact profile form. For the honest outer execution
of coordinate \(i\) on \(C(m)\), let \(p_{m,i}(t)\) be the expected number of queries to
outer position \(t\), counting repeated queries. For \(0\le\varepsilon\le1\), define

\[
\operatorname{Lor}_{\varepsilon}(p)
 :=\max\left\{\sum_t p(t)e(t):
 0\le e(t)\le1,\ \sum_t e(t)\le\varepsilon M\right\},
\qquad
\Lambda^{\mathrm{out}}_\varepsilon
 :=\max_{m,i}\operatorname{Lor}_{\varepsilon}(p_{m,i}).
\tag{4.2b}
\]

If dPCP list soundness gives per-position wrong-projection probabilities
\(e_t(z)\in[0,1]\) with \(M^{-1}\sum_t e_t(z)\le\varepsilon\), then the lifted compiled
verifier satisfies

\[
\Pr[V_{i,1-m_i}(z)=1]
 \le \operatorname{Lor}_{\varepsilon}(p_{m,i})
 \le \Lambda^{\mathrm{out}}_\varepsilon .
\tag{4.2c}
\]

The proof is a first-wrong-projection coupling: until the first locally accepted wrong
projection, the outer decoder follows its honest path, so the bad probability is at most
\(\sum_t p_{m,i}(t)e_t(z)\); the displayed Lorenz quantity is exactly the linear-program
maximum under the dPCP error budget. Thus a correct branch of probability \(\alpha\)
has a simultaneous gap whenever
\(\Lambda^{\mathrm{out}}_\varepsilon<\alpha\).
The usual pointwise smoothness estimate is only the corollary

\[
\max_t p_{m,i}(t)\le q_D\lambda/M
\quad\Longrightarrow\quad
\Lambda^{\mathrm{out}}_\varepsilon\le q_D\lambda\varepsilon .
\tag{4.2d}
\]

For a decoder uniformly spread over a private block of \(K\) positions,
\(\operatorname{Lor}_{\varepsilon}(p)=q_D\min\{1,\varepsilon M/K\}\).
Therefore the field lift has two independent profile tests: the outer output-query
profile (4.2b) and the proof-position pathwise Lorenz profile in Proposition 7.3.
The full statement and tightness example are in
[the outer-query Lorenz field-lift note](../../../mcsp-hardness-magnification/notes/257-outer-query-lorenz-field-lift-compiler-2026-08-17.md).

The matching lower-side condition is profile realization.  Let \(H_{m,i}(r)\) be the
maximum probability that the honest outer transcript hits an \(r\)-set of positions.  If
every such set has a global dPCP patch whose first wrong projection forces the wrong
claim, robust soundness \(\delta\) requires
\[
H_{m,i}(r)\le\delta .
\tag{4.2e}
\]
For a one-query decoder this is exactly the outer Lorenz mass at \(r/M\); for multiple
queries it is the set-hitting functional, which can be strictly smaller than the union
bound.  Thus the field-lift route has a sharp dual: list soundness gives the Lorenz upper
bound, while patchability gives the hitting lower bound.  A near-linear construction can
survive only by proving that its global relation suppresses the top-set error profiles, or
by turning that failure of patchability into a short global descriptor/evaluator.  Ordinary
list soundness alone does not decide this quantifier.  The formal dual theorem is in
[dual profile closure for field-lifted dPCPs](../../../mcsp-hardness-magnification/notes/258-dual-profile-closure-for-field-lifted-dpcp-2026-08-17.md).

### Incidence-stable field lift forces an RLDC

The field lift has a stronger family-level converse when the complete decoding
distribution is regular on proof positions. Let \(C:\{0,1\}^k\to\Gamma^M\) have relative
distance \(\Delta_C\), and let a single dPCP address space \(V\) decode the language
\(C(\{0,1\}^k)\). Choose one perfect-completeness proof \(A_m\) for each message \(m\).
If, under the complete decoding distribution, every proof position is incident with
probability at most \(\chi/|V|\), then

\[
  \operatorname{dist}(A_m,A_{m'})\ge\Delta_C/\chi .
\]

Indeed, on every output coordinate where \(C(m)\) and \(C(m')\) differ, the two honest
proofs must differ on the sampled local edge; incidence smoothness turns this into the
displayed proof-distance lower bound. Now compose each outer decoder query with the local
dPCP test. For a received proof at relative distance \(\rho\) from \(A_m\), a first-hit
argument and the outer honest-path \(\lambda\)-smoothness give

\[
  \Pr[\text{wrong output}]\le q_D\lambda\chi\rho,\qquad
  \Pr[\text{correct output}]\ge1-q_D\lambda\chi\rho .
\]

Thus, whenever \(0<\rho<\Delta_C/(2\chi)\) and \(q_D\lambda\chi\rho<1/2\), the selected dPCP proofs themselves form a
weak \(q_Pq_D\)-query RLDC, with no separate near-proof soundness assumption. In
particular, a binary 2-query dPCP combined with a one-query smooth outer decoder would
force the exponential 2-query RLDC length lower bound; fixed finite alphabets and constant
query count already enter the general superlinear RLDC barrier. The full statement and
proof are in [incidence-stable field lift](../../mcsp-hardness-magnification/notes/218-incidence-stable-field-lift-dpcp-forces-rldc-2026-08-17.md).

For the bipartite dPCPs used by GMWZ, the incidence parameter can be read directly
from the published complete-decoding marginals. If the left and right vertex sets
are \(A\) and \(B\), and both marginals are uniform, then

\[
 \chi_{\mathrm{reg}}
 =\frac{|A|+|B|}{\min\{|A|,|B|\}}.
\tag{4.2a}
\]

Thus comparable side sizes give constant \(\chi_{\mathrm{reg}}\); in the balanced
case C204 gives proof distance at least \(\Delta_C/2\) and a constant admissible
radius below \(\Delta_C/4\). This removes incidence irregularity as an independent
escape for a balanced GMWZ instantiation. It does not supply the missing output
family, field lift, or address-scale outer decoder.

### Family--descriptor--RLDC closure trichotomy

The two remaining-looking strategies—reconstructing one target with a short
descriptor and retaining a large family in one common proof—are not independent.
Let \(d\) be a static descriptor of length \(s\), let an address evaluator have
control size \(p\), and let it make at most \(p\) reads from \(d\). The ROM
expansion gives

\[
  \operatorname{CC}(H)\le O(p^2+ps).
\tag{4.3}
\]

Consequently, a forced target with
\(\operatorname{CC}(H)>S\) must pay \(p^2+ps=\Omega(S)\); a
word-consistent evaluator with \(p,s,\log N=n^{O(1)}\) is already a
\(P/\mathrm{poly}\) evaluator for that target. If instead the same interface
supports the full distance-separated outer-code family and satisfies the
incidence/smoothness conditions above, the selected proof map is an RLDC and
inherits the corresponding proof-length lower bound. Thus a proposed
RW-specific construction can avoid both conclusions only by exposing an
explicit escape parameter: superpolynomial descriptor/address cost, absence of
a full common-proof family, loss of incidence/smoothness/radius, or
address-dependent sheets/strategies.

This is the precise closure trichotomy used below: a single hard target cannot
hide a history in a short descriptor, while a genuinely rich common-proof
family cannot keep constant locality and incidence-stable coordinate
robustness without becoming a locally decodable code. The complete
quantifiers and proof are in [Family--descriptor--RLDC trichotomy](../../../mcsp-hardness-magnification/notes/219-family-descriptor-rldc-closure-trichotomy-2026-08-17.md).

## 5. The exposed-history baseline and the compression problem

There is a straightforward positive construction when the complete computation history is
allowed in the proof. Encode a valid history with a constant-distance outer code, run a
relation-PCPP for the encoded history, and use a relaxed local decoder to recover the output
coordinate. If all valid histories have the same output, code distance separates the wrong
output classes and gives simultaneous coordinate robustness.

This baseline is not an address-scale construction. An injective encoding of a history of
length \(T\) contains at least \(T\) bits of information. Known PCPP-to-RLDC compositions
therefore carry a communication term of the form

\[
  T+\operatorname{cc}(T),
\]

up to the alphabet conversion. Compressing this history channel to
\(\operatorname{poly}(n,\log T)\), while preserving target binding and one global proof,
is the central open problem.

The outer code is not the missing ingredient. Good strong-LTC and relaxed-LDC layers already
provide constant distance and local recovery. The unresolved part is a short relation-PCPP
or shared-key compiler for the hidden computation witness.

## 6. Descriptor entropy is the remaining single-target budget

The family theorem does not by itself rule out a verifier that depends on a short target
descriptor. A quantitative version of the payload-lifting argument shows how much such a
dependence can buy. Fix a context \(u\), and suppose that for every payload
\(m\in\{0,1\}^h\) there is an instance \(x_{u,m}\) whose output contains the payload in
fixed coordinates. Assume that all payloads use one physical proof address space and that
the coordinate verifiers are generated from an \(s\)-bit descriptor \(\kappa(m)\). Allow a
post-coordinate response of at most \(r\) bits, but require wrong-bit soundness for every
response on the same target-relative proof neighborhood.

Write \(C(m)\in\Sigma^N\) for the payload-inclusive codeword obtained from the fixed
payload coordinates and the common proof representation. The descriptor only chooses the
verifier family; it does not change this physical codeword address space.

Messages in the same descriptor bucket use one verifier family. The largest bucket contains
at least \(2^{h-s}\) payloads. Enumerating the at most \(2^r\) responses and applying the
inline construction therefore gives a relaxed decoder with locality

\[
  Q_r=O\!\left(2^r q_0(\alpha-\beta)^{-2}\right).
\]

### Proposition 6.1 (descriptor-entropy barrier)

Let \(N\) be the length of this codeword. Assume the positive-radius relaxed-LDC sample
theorem is valid at locality \(Q_r\) for the
valid-input sets

\[
  \mathcal V_\sigma=\{C(m):\kappa(m)=\sigma\}.
\]
Then the largest descriptor bucket satisfies

\[
  \log_2|\mathcal V_\sigma|\le
  C_{\Sigma,Q_r}N^{1-\theta_r}\log_2(h+2),
  \qquad
  \theta_r=\frac{c}{Q_r^2\log^2(Q_r+2)}.
\]
Consequently \(h-s\) obeys the same upper bound. The statement does not assume that a
descriptor bucket is a subcube, is closed under coordinate changes, or has any algebraic
structure; it uses only the DGL formulation with an arbitrary finite valid-input set and a
decoder that recovers every message in that set.

#### Proof sketch

Fix a largest bucket \(\sigma\). For each response \(\tau\in\{0,1\}^r\), threshold the two
claim verifiers after independent repetition. Correctness supplies at least one response
whose correct branch crosses the threshold, while the all-response soundness assumption
keeps every wrong branch below it throughout the target-relative neighborhood. Taking the
maximum over the \(2^r\) responses gives a \(Q_r\)-query relaxed decoder on the arbitrary
valid set \(\mathcal V_\sigma\). The DGL sample reduction uses a sample independent of the
decoded message and reuses it for all \(h\) coordinates; repeating the sample stage
\(O(\log(h+2))\) times gives a global decoder with constant success probability. Fano's
inequality bounds the logarithm of the bucket size by the transcript entropy, yielding the
displayed inequality. Since \(|\mathcal V_\sigma|\ge 2^{h-s}\), the claimed descriptor bound
follows.

The proof is deliberately a valid-set argument. If a bucket happens to have constant
coordinates, the bound only becomes weaker; no hidden “free variation” assumption is being
used.

Since \(|\mathcal V_\sigma|\ge 2^{h-s}\), Proposition 6.1 gives the same inequality with
the left-hand side replaced by \(h-s\), whenever the corresponding positive-radius
relaxed-LDC lower-bound window applies.

Thus a near-linear proof with fixed alphabet, fixed base locality, and bounded response
length forces \(s=h-o(h)\) for a full \(h\)-bit payload family. A short target descriptor is
not a free single-target escape: it must either reveal almost all payload entropy, make the
finite response long enough to destroy constant locality, or leave the positive-radius
target-relative regime. This conclusion still permits genuinely unbounded interactive
strategies and separate proof spaces. Those are the remaining interfaces, not silently
covered by the family theorem.

The argument is a direct extension of Theorem 2.1. It is useful because it identifies the
precise quantity that a successful RW-specific construction must hide: not merely one target
word, but the payload entropy of every same-context subfamily that remains address-oblivious.
The full finite-mode and descriptor formulation is recorded in the project statement
[Payload lifting family barrier](../../statements/payload-lifting-family-barrier.md).

There is a sharper threshold for the finite post-coordinate response itself. If the response
has \(r\) bits, the enumeration step replaces the base locality by
\(Q_r=O(2^r)\). Under a uniform DGL bound of the form

\[
  h-s\le A|\Sigma|^{Q_r}N^{1-\theta_r}\log(k+2),
  \qquad
  \theta_r\ge
  \frac{a}{Q_r^2\log^2(Q_r+2)},
\]

fixing \(N\le k\operatorname{polylog}k\) and \(s\le(1-\varepsilon)k\) rules out
\(r\le c\log\log k\) for every fixed \(c<1/3\). Indeed, with
\(\ell=\log k\), such an \(r\) gives \(Q_r=O(\ell^c)\), while
\(\theta_r\log N=\Omega(\ell^{1-2c}/(\log\ell)^2)\). The negative exponent dominates both
the alphabet factor \(e^{O(\ell^c)}\) and the polylogarithmic length factor precisely when
\(c<1/3\). Thus a finite-response escape must pay
\(\Omega(\log\log k)\) bits (within this uniform parameter window), or leave the positive-radius,
fixed-gap, common-address family regime. The detailed statement records the external-window
assumption and does not claim an unconditional lower bound for arbitrary interactive PCPs.

### Corollary 6.1A (key-indexed finite-transcript dichotomy)

The randomized-descriptor theorem gives a single quantitative statement for the two most
natural escapes: a short key may select the verifier family, and a finite post-coordinate
transcript may select a branch. Let \(M\) be a target random variable with \(H(M)\ge k\),
let \(D\) be its descriptor, and assume the common-address, conditional-support,
completeness, and all-policy target-relative soundness hypotheses of Theorem 2.7A. Suppose
that descriptor bucket \(d\) uses at most \(\rho_d\) random bits, \(\mu_d\) response bits,
and \(\nu_d\) proof-symbol queries on each branch. Define

\[
  T_d=\nu_d\,2^{\rho_d+\mu_d}|\Sigma|^{\nu_d}.
\tag{6.17}
\]

If \(I(M;D)\le s\), then, whenever the external branch-support function
\(\Phi_N\) is monotone on this window,

\[
  k-s
  \le H(M)-I(M;D)
  \le \min\left\{
       G_N(\mathbb E R),
       \mathbb E_{d\sim D}[\Phi_N(T_d)]
     \right\}.
\tag{6.18}
\]

Consequently, if \(s\le(1-\eta)k\), then

\[
  \mathbb E R=\Omega_\eta\!\left(\frac{k}{\log k}\right),
  \qquad
  \mathbb E_{d\sim D}[\Phi_N(T_d)]\ge\eta k.
\tag{6.19}
\]

In the DGL window \(N\le k(\log k)^a\), with fixed \(|\Sigma|\), there is a constant
\(c_0>0\) such that

\[
  T_d\le c_0\frac{(\log k)^{1/3}}
                  {(\log\log(k+2))^{2/3}}
  \quad\text{for every }d
\tag{6.20}
\]

forces \(\mathbb E_d[\Phi_N(T_d)]=o(k)\). Thus a family with \(s\le(1-\eta)k\)
cannot simultaneously have a uniformly short finite transcript and a near-linear proof:
it must either expose \(\Omega(k)\) target information through the descriptor, or push some
descriptor bucket outside the transcript threshold (or leave the DGL/radius window).
For fixed \(\nu_d\) and fixed alphabet, (6.20) requires

\[
  \rho_d+\mu_d=\Omega(\log\log k)
\]

up to the explicit \(1/3\) threshold and lower-order \(\log\log\log k\) term.

#### Proof

The finite view-tree has at most \(T_d\) address occurrences, so Theorem 2.7A and
(2.11d)--(2.11e) give (6.18), since \(H(M)-I(M;D)\ge k-s\). Inverting \(G_N\) in
the fixed-alphabet, polynomial-length regime gives the first bound in (6.19), while the
second follows directly from (6.18). Finally, substituting (6.20) into the DGL expression
yields

\[
  \log\frac{\Phi_N(T_d)}{k}
  \le O(T_d+\log\log k)
       -\Omega\!\left(
          \frac{\log k}{T_d^2\log^2(T_d+2)}
        \right)
  =-\omega(1),
\]

for sufficiently small \(c_0\), uniformly in \(d\). This contradicts (6.19).

### Theorem 6.2 (finite-transcript public-coin time barrier)

The preceding response enumeration extends to arbitrary finite-round public-coin interaction.
Suppose a single uniform compiler applies to every
\(L\in\mathsf{NTIME}(t)\), with a common polynomial bound \(p(n)\), a key of length at most
\(p(n)\), a deterministic random-access evaluator of time \(p(n)\), and a public-coin verifier
using \(r(n)\) random bits.  On each fixed random tape, allow an adaptive Merlin strategy with
an arbitrary number of rounds, but require that its total transcript length is at most
\(\ell(n)\).  Merlin sees only the public history already sent by the verifier, not future
random bits (if the full random tape is revealed initially, this restriction is vacuous).
Assume

\[
\begin{aligned}
x\in L &\Longrightarrow \exists s,\mathcal S\
  \Pr_R[V_L(x,s;R,\mathcal S(R))=1]\ge 2/3,\\
x\notin L &\Longrightarrow \forall s,\mathcal S\
  \Pr_R[V_L(x,s;R,\mathcal S(R))=1]\le 1/3.
\end{aligned}
\tag{6.15}
\]

Put

\[
u(n)=2^{r(n)}\bigl(p(n)+\ell(n)+r(n)\bigr)^{O(1)}.
\tag{6.16}
\]

If \(u\) is replaced by a common time-constructible upper bound and
\(u(n)\log u(n)=o(t(n))\), then such a compiler cannot exist.

#### Proof

Fix \(L\in\mathsf{NTIME}(t)\).  A nondeterministic machine guesses the key and, for every
random tape \(R\), a complete transcript \(\tau_R\) of length at most \(\ell(n)\).  It checks
the legality of the transcript, simulates the verifier, and answers every proof-address query
using the evaluator.  During the simulations it records each Merlin response together with
the public verifier history visible when that response is sent.  After all tapes are simulated,
it sorts these history--response records (or inserts them into a trie) and rejects if one
public history has two different responses.  It accepts exactly when at least two thirds of
the random tapes accept.

On yes instances, the table of transcripts induced by the completing strategy makes the
machine accept.  On no instances, any table surviving the consistency check defines one
deterministic strategy on public histories (unseen histories are filled with an arbitrary
legal response); it does not read future random bits.  Thus the second line of (6.15) prevents
acceptance.  The sorting/checking overhead is still
\(2^{r(n)}(p(n)+\ell(n)+r(n))^{O(1)}\), so the simulation takes time at most \(u(n)\).  Hence
\(\mathsf{NTIME}(t)\subseteq\mathsf{NTIME}(u)\), contradicting the nondeterministic time
hierarchy theorem under the displayed asymptotic condition. \(\square\)

This is strictly stronger than the one-response barrier: the response table is indexed only
by the public random tape, while all adaptive rounds on that tape are included in one
\(\tau_R\).  In particular, replacing a short post-coordinate response by a
finite-horizon interactive strategy does not create a universal address-scale compiler.
The theorem is intentionally universal; it does not rule out a compiler for one fixed RW
relation, an environment-scale transcript, or a genuinely non-finite information model.  The
full statement and corollary are recorded in
[Finite-transcript public-coin compilers pay the ambient nondeterministic time scale](../../statements/finite-transcript-randomness-time-hierarchy-barrier.md).

### RW-specific multi-input tuple-supply barrier

The preceding coding barriers do not by themselves close the natural proposal to replace
RW's constant output function by a multi-input family. There is, however, a separate
parameter obstruction to using that proposal merely to manufacture JK capacity. Suppose
that an input \(x\in\{0,1\}^n\) contributes one selected canonical history of length at most
\(L(t)\le t^a\), and that a depth-\(h\) JK group occupies \(2^h\) aligned blocks of width
\(2k\). Even granting distinctness across all \(2^n\) inputs, the number of actual groups is

\[
  |\mathcal T_h|\le \frac{2^n t^a}{2k2^h}.
\]

Hence a forcing argument requiring more than \(2^k\) tuples needs
\(n+a\log t>k+\log(2k)+h\). In the RW recurrence
\(k=n_i^C\), \(t=T_i=\max\{2^{cD^i n_0},n_{i+1}\}\), \(C>D+1\), the left side is
\(o(k)\), even if every input takes the failure branch. The existing induction is weaker still:
it invokes one fixed \(x_0\), not all inputs. Replacing \(f_i\) by a group-action family
therefore does not supply the missing tuple richness at the original polynomial/smart-prMA
scale. This is a route-specific occurrence-counting theorem, not a general impossibility for
shared proofs or PCPs; its precise statement and proof are in
[RW/JK multi-input tuple-supply barrier](../../statements/rw-multiinput-tuple-supply-barrier.md).

## 7. Profile realizability is the missing generality

The average-to-coordinate barrier is sharp only for the information exposed by a scalar
average. To obtain a genuine lower bound for a proof architecture, one must additionally
understand which local error profiles can be realized by a *single* global proof. The
following profile-hitting lemma isolates exactly that missing hypothesis.

### Proposition 7.1 (forcing profiles hit by the honest query path)

Fix an output coordinate \(i\) and an adaptive decoder \(D_i\). For honest randomness
\(\omega\), let \(V_i(\omega)\) be the set of positions queried along the honest transcript.
Let \(\mathcal S_i\) be a family of error sets. Suppose that, for every
\(S\in\mathcal S_i\), there is a candidate proof \(z_S\) such that all answers outside \(S\)
are honest, the transcript remains honest until the first query in \(S\), and the first
query in \(S\) forces acceptance of the wrong declaration. If target-relative soundness
bounds wrong acceptance by \(\delta\) for every candidate proof, then

\[
  \max_{S\in\mathcal S_i}
  \Pr_\omega[V_i(\omega)\cap S\ne\varnothing]
  \le \delta.
\tag{7.1}
\]

#### Proof

For \(z_S\), the decoder follows the honest transcript until it first queries \(S\). By the
forcing assumption, that event implies wrong acceptance. Hence wrong acceptance on \(z_S\)
is at least the hitting probability in (7.1). Taking the maximum over \(S\) proves the claim.

The bound becomes quantitative when the profile family is rich. If every \(r\)-subset of a
support \(U\) of size \(s\) is realizable and every honest path makes \(q_D\) distinct queries
inside \(U\), averaging over a uniformly random \(r\)-subset gives

\[
  \max_{|S|=r}\Pr[V_i\cap S\ne\varnothing]
  \ge 1-\frac{\binom{s-q_D}{r}}{\binom{s}{r}}.
\tag{7.2}
\]

Thus a constant soundness budget requires the support or the global coupling to grow. This
is a theorem about profile realization, not about average/list soundness: an average bound
alone does not provide the candidate proofs \(z_S\).

### Proposition 7.2 (fractional profile certificate)

Let \(\mathcal Q_i\) be the finite family of honest query sets for coordinate \(i\), and
let \(\mathcal S_i\) be the realizable forcing profiles from Proposition 7.1. If there is a
distribution \(\lambda\) on \(\mathcal S_i\) and a number \(\eta>0\) such that

\[
  \Pr_{S\sim\lambda}[Q\cap S\ne\varnothing]\ge\eta
  \qquad\text{for every }Q\in\mathcal Q_i,
\tag{7.3}
\]

then every verifier with target-relative wrong-declaration soundness \(\delta\) satisfies
\(\delta\ge\eta\).

For each fixed \(S\), Proposition 7.1's first-error argument gives wrong acceptance on
\(z_S\) at least \(\Pr_\omega[V_i(\omega)\cap S\ne\varnothing]\). Averaging this pointwise
lower bound over \(S\sim\lambda\) gives at least \(\eta\), while target-relative soundness
upper-bounds every term in that average by \(\delta\). Equivalently, finite minimax
identifies the best possible honest query distribution with the dual problem of finding
such a hitting distribution \(\lambda\). This is strictly weaker than requiring every small
error set to be realizable, and it is the preferred interface for a general proof-graph
lower bound.

For the coordinate-specific PCPP-block architecture analyzed by
Gur--Minzer--Weissenberg--Zheng, \(s\le K\), \(q_D=3\), and the full codeword has length
\(M=4Kk\). If all error sets of size \(r=\lfloor\varepsilon M\rfloor\) inside the private
block were realizable, (7.2) would give

\[
  1-\left(1-4\varepsilon k+o(\varepsilon k)\right)^3\le\delta,
\]

and hence \(\varepsilon=O(1/k)\) for constant \(\delta\). The actual construction avoids this
private-patch conclusion by binding the coordinate block to a repeated global base word; a
wrong output then requires corruption of a constant fraction of that base channel. This is
an architecture-level explanation of the inverse-linear threshold, not a general dPCP lower
bound. The proof-graph condition needed to upgrade Proposition 7.1 to a general theorem is
precisely a profile-realization or patchability theorem.

### Proposition 7.3 (exact pathwise Lorenz closure)

The profile-hitting statements above can be made decoder-intrinsic, without assuming a dPCP
incidence law.  Let

\[
  \Pi:\{0,1\}^{k}\longrightarrow\Sigma^{N}
\]

be a common proof map.  For every message coordinate \(i\), let \(D_i\) be a randomized,
possibly adaptive oracle decoder making at most \(Q\) symbol reads and satisfying exact
honest-path correctness

\[
  D_i^{\Pi(m)}=m_i
  \qquad\text{with probability one}.
\tag{7.4}
\]

For fixed \(m,i\) and random tape \(\omega\), let \(T_{m,i}(\omega)\) be the ordered multiset
of proof positions read on the honest oracle \(\Pi(m)\), counting repeated reads.  Define

\[
  \nu_{m,i}(v):=\mathbb E_\omega\!\left[\#\{\text{occurrences of }v\text{ in }T_{m,i}(\omega)\}\right]
\]

and, writing the values in decreasing order,

\[
  \Lambda_\rho:=\max_{m,i}\sum_{j=1}^{\lfloor\rho N\rfloor}\nu_{m,i,(j)}.
\tag{7.5}
\]

Then \(\Pi\) is a perfect-complete weak adaptive
\((Q,\rho,1,\min\{1,\Lambda_\rho\})\)-RLDC.  In particular, if
\(\Lambda_\rho<1\), distinct proof words have relative distance strictly larger than \(\rho\).

#### Proof

Fix \(m,i\), a received word \(z\) with
\(\operatorname{dist}(z,\Pi(m))\le\rho\), and let
\(B=\{v:z_v\ne\Pi(m)_v\}\).  Couple the executions on \(z\) and on the honest proof
\(\Pi(m)\) using the same random tape.  Until the first read from \(B\), their transcripts
are identical, so the next query is the corresponding honest-path query.  Therefore

\[
  \Pr[\text{the first read from }B\text{ occurs}]
  \le \sum_{v\in B}\nu_{m,i}(v)
  \le \sum_{j=1}^{\lfloor\rho N\rfloor}\nu_{m,i,(j)}
  \le \Lambda_\rho.
\tag{7.6}
\]

If no such read occurs, exact correctness (7.4) forces output \(m_i\); hence a wrong output
can occur only after the first hit, proving the relaxed-decoding guarantee.  Exact correctness
also gives perfect completeness.  Finally, if two distinct proof words were within radius
\(\rho\), apply the guarantee for one target to the other proof at a coordinate where their
messages differ.  Perfect completeness for the second target would force a wrong output with
probability one, contradicting \(\Lambda_\rho<1\).  \(\square\)

This proposition is tight if one uses only the honest query profile.  For any probability
vector \(p\) on \([N]\), take the one-bit map \(\Pi(0)=0^N,\Pi(1)=1^N\) and let the decoder
sample \(v\sim p\), read \(z_v\), and output that symbol.  Its profile is \(p\), and a
corruption set \(B\) causes error exactly \(p(B)\); maximizing over \(|B|\le\rho N\) gives
the Lorenz sum in (7.5).  Thus any improvement must use semantic coupling beyond honest-path
incidence.  If the decoder is nonadaptive and \(\Lambda_\rho\le1-\eta\), the arbitrary-
distribution relaxed-LDC bound applies; for adaptive decoders, the fixed-parameter RLDC bound
applies whenever \(\Lambda_\rho<1\), and the low-soundness RLDC-to-LDC upgrade applies when
\(\Lambda_\rho<2^{-Q}\).  The full profile formulation and these parameterized consequences
are recorded in [the pathwise Lorenz profile note](../../../mcsp-hardness-magnification/notes/226-pathwise-lorenz-profile-adaptive-shared-proof-closure-2026-08-17.md).

### Proposition 7.3A (minimax patchability certificate)

For a fixed \(m,i\), let \(\mathscr S\) be the possible honest query sets and let
\(\mathscr B\) be a family of realizable corruption sets. Suppose the patch indexed by
\(B\) forces a wrong output with conditional probability \(\gamma_B\) after the first honest
path hit. Then every query policy supported on \(\mathscr S\) has wrong-output probability
at least
\[
 v=\min_{\mu\in\Delta(\mathscr S)}\max_{B\in\mathscr B}
 \gamma_B\Pr_{S\sim\mu}[S\cap B\ne\varnothing]
 =\max_{\lambda\in\Delta(\mathscr B)}\min_{S\in\mathscr S}
 \sum_{B\in\mathscr B}\lambda_B\gamma_B\mathbf 1[S\cap B\ne\varnothing].
\tag{7.6}
\]
The first-hit coupling gives the lower bound for the actual honest query distribution, and
the equality is finite von Neumann minimax. If every \(t\)-subset is realizable with
\(\gamma_B=1\), and every honest query set has at least \(q_0\) distinct positions, the
uniform patch distribution yields
\[
 v\ge1-\frac{\binom{N-q_0}{t}}{\binom Nt}.
\tag{7.7}
\]
Thus a proof-graph patchability lemma can be supplied as a single dual distribution rather
than checked separately against each adaptive decoder. For \(q_0=o(\sqrt N)\), the
binomial ratio is \(1-(1-\rho)^{q_0}+o(1)\); outside that range, (7.7) is the exact
statement. The full finite-game result is in [the minimax patchability note](../../../mcsp-hardness-magnification/notes/262-minimax-patchability-certificate-for-adaptive-shared-proofs-2026-08-17.md).

There is also a direct-sum form. Suppose the target set is \([k]\), the honest queries
for target \(i\) are confined to a disjoint region \(R_i\), and a distribution
\(\lambda_i\) of local patches in \(R_i\) hits every honest query set with conditional
forcing probability at least \(\eta\). If arbitrary choices of patches on a subset
\(T\subseteq[k]\) can be combined into one global proof, and every local patch has size
at most \(\tau\), set
\[
t=\min\!\left\{k,\left\lfloor\frac{\rho N}{\tau}\right\rfloor\right\}\ge1.
\tag{7.8}
\]
The uniform choice of \(T\) and independent local patches gives one \(\rho N\)-near
proof distribution for which every fixed target has wrong-output probability at least
\[
\eta\,\frac{t}{k}.
\tag{7.9}
\]
Consequently target-relative error at most \(\beta\) forces
\[
\frac{\eta}{k}\min\!\left\{k,\left\lfloor\frac{\rho N}{\tau}\right\rfloor\right\}
\le\beta.
\tag{7.10}
\]
If \(\eta>\beta\), set \(t_\star=\lfloor\beta k/\eta\rfloor+1\). Then
\(\lfloor\rho N/\tau\rfloor<t_\star\), so
\(\tau=\Omega_{\rho,\eta,\beta}(N/k)\). In particular, for \(N=\Theta(kK)\),
independently composable forcing patches of size \(o(K)\) are impossible. If
\(\eta\le\beta\), (7.10) remains valid but gives no contradiction by itself.
This is conditional on product realizability and region-locality; private blocks alone
do not supply those hypotheses.

### Proposition 7.3B (transcript-preserving patchability forces a ROC barrier)

Fix a coordinate \(i\), a claim \(b\), and an honest target \(m^0\) with \(m^0_i=b\).
Let \(H_0\) be the visible-transcript law of \(V_{i,b}\) on the honest proof
\(\Pi(m^0)\). Let \(\lambda\) be a distribution, independent of the verifier's public
randomness \(\omega\), over \(\rho P\)-near proofs \(z\) for targets whose \(i\)-th bit is
\(1-b\). Write \(T(z;\omega)\) for the complete visible transcript, including all query
addresses and answers. Suppose that there is an \(\eta>0\) such that, for every transcript
event \(A\),

\[
 \Pr_{z\sim\lambda,\,\omega}\!\left[
   T(z;\omega)\in A\ \wedge\ T(z;\omega)=T(\Pi(m^0);\omega)
 \right]
 = \eta\,H_0(A).
\tag{7.3B.1}
\]

Then the averaged wrong transcript law \(\overline W_\lambda\) dominates
\(\eta H_0\), and consequently

\[
 \mathsf{ROC}_{i,b}(\alpha,\rho)\ge \eta\alpha
 \qquad(0\le\alpha\le1).
\tag{7.3B.2}
\]
In particular, no transcript-only postprocessor can simultaneously have honest completeness
at least \(\alpha\) and wrong-claim probability below \(\eta\alpha\).

#### Proof

The left-hand side of (7.3B.1) is the mass that the wrong-law mixture assigns to \(A\) on
the event that its entire transcript agrees with the honest transcript generated with the
same \(\omega\). This event is a subevent of \(T(z;\omega)\in A\), so
\(\overline W_\lambda(A)\ge\eta H_0(A)\) for every \(A\). Hence
\(\overline W_\lambda\ge\eta H_0\) as measures. Any feasible ROC test \(f\) satisfies
\(\mathbb E_{H_0}f\ge\alpha\), and therefore
\[
 \mathbb E_{W\sim\lambda}\mathbb E_W f
 =\mathbb E_{\overline W_\lambda}f
 \ge\eta\,\mathbb E_{H_0}f
 \ge\eta\alpha.
\]
The dual characterization (266.8) of the robust ROC frontier now gives (7.3B.2). \(\square\)

This hypothesis is strictly stronger than first-hit patchability. A hitting distribution
only says that a wrong proof reaches a verifier predicate after the honest path is hit; its
patched transcript may still lie outside the honest transcript support, allowing a
transcript-aware postprocessor to output \(\bot\) on precisely those transcripts. Thus a general
barrier from Proposition 7.3A must prove transcript preservation (or the equivalent mixture
domination), not merely path hitting. The finite-game formulation and its small-support
certificates are given by the robust ROC frontier in [note 266](../../../mcsp-hardness-magnification/notes/266-robust-roc-frontier-for-imperfect-transcript-postprocessing-2026-08-19.md).

### Proposition 7.3C (the hit--preservation complementarity)

In the setting of Proposition 7.3B, let
\[
\Delta(z):=\{v:z_v\ne\Pi(m^0)_v\}
\]
and let \(\theta\) be the probability in (3.4M.3).  If
\(T(z;\omega)=T(\Pi(m^0);\omega)\), then the honest execution never queries
\(\Delta(z)\): before the first changed position the two executions have identical
transcripts, and equality of the complete transcripts rules out such a first position.
Consequently,
\[
 \Pr_{z\sim\lambda,\omega}
 \bigl[T(z;\omega)=T(\Pi(m^0);\omega)\bigr]
 \le 1-\theta .
\tag{7.3C.1}
\]
Under the transcript-preserving hypothesis (7.3B.1), the left-hand side equals \(\eta\),
which proves (3.4M.4).  Combining Proposition 7.3B with the ROC feasibility condition
\(\operatorname{ROC}_{i,b}(\alpha,\rho)\le\beta\) proves (3.4M.2).
\(\square\)

The complementarity is sharp even in a two-transcript toy model.  Let the honest law be
\(H_0=\delta_{\tau_H}\), let every wrong patch produce
\(W=\delta_{\tau_W}\) with \(\tau_H\ne\tau_W\), and suppose the changed position is always
queried, so \(\theta=1\).  Then transcript equality has mass \(\eta=0\), while the test
\(f(\tau_H)=1\), \(f(\tau_W)=0\) has perfect honest completeness and zero wrong output.
Thus maximal first-hit forcing can coexist with \(\operatorname{ROC}(1,\rho)=0\); it is
transcript preservation, not acceptance after a hit, that creates the universal barrier.

### Corollary 7.4 (near-linear Lorenz concentration)

Fix \(A\ge2\), \(Q\ge2\), \(0<\rho<1\), and \(c>0\).  In the nonadaptive setting of
Proposition 7.3, suppose \(|\Sigma|=A\) and \(N_k\le k(\log k)^c\) on infinitely many
lengths.  Then, on all sufficiently large such lengths,

\[
  1-\Lambda_{\rho,k}
  =
  O_{A,Q,\rho,c}\!\left(\frac{\log\log(k+2)}{\log(k+2)}\right).
\tag{7.7}
\]

Indeed, when \(\sigma_k:=1-\Lambda_{\rho,k}>0\), Proposition 7.3 gives a nonadaptive
\((Q,\rho,\sigma_k)\)-RLDC.  If
\(\rho\le N_k^{-\sigma_k/(2Q)}\), then
\(\sigma_k=O_{A,Q,\rho}(1/\log k)\) by injectivity and the alphabet bound.  Otherwise the
Goldberg--Gur--Saraogi inequality gives
\[
  \frac{k}{\log^2 k}
  \le
  38Q^4\sigma_k^{-2}\log^2 A\,
  N_k^{\,1-\frac1{\lceil Q/\sigma_k\rceil+1}}.
\]
Taking logarithms under \(N_k\le k(\log k)^c\) forces
\(\lceil Q/\sigma_k\rceil=\Omega_{A,Q,\rho,c}(\log k/\log\log k)\); hence (7.7).
The full two-case proof and the one-bit tightness discussion are in
[the Lorenz concentration note](../../../mcsp-hardness-magnification/notes/251-near-linear-lorenz-concentration-2026-08-17.md).

The same calculation gives a continuous length--locality phase diagram.  If the inline
length is \(N_k\le k^{1+\varepsilon_k}\), the effective nonadaptive locality \(Q_k\) obeys
\[
\frac{1}{\lceil Q_k/\sigma_k\rceil}
\le \varepsilon_k+
\left(1+\frac{1}{\lceil Q_k/\sigma_k\rceil}\right)
\frac{\log(38Q_k^4\log^2 A\,\log^2 k/\sigma_k^2)}{\log k}.
\]
Thus, for subpolynomial \(Q_k\), \(Q_k\) is
\(\Omega(1/(\varepsilon_k+\log Q_k/\log k+\log\log k/\log k))\).
The near-linear \(\Omega(\log k/\log\log k)\) threshold is therefore the endpoint of a
general proof-length--locality tradeoff, not an isolated case.  The exact statement is in
[the length--locality exponent tradeoff note](../../../mcsp-hardness-magnification/notes/260-length-locality-exponent-tradeoff-2026-08-17.md).

### Corollary 7.5 (growing-locality threshold for the bottom branch)

The preceding concentration bound has a direct interpretation for simultaneous
coordinate-robust shared proofs. Fix a finite proof alphabet of size \(A\ge2\), a constant
positive radius, and a correct-branch gap at least \(\sigma_0>0\). Suppose that each
coordinate has two target-tagged adaptive branches of depth \(r=r(k)\), with perfect
correct-branch completeness and wrong-branch error at most \(1-\sigma_0\) throughout the
radius neighborhood. If the tagged inline length satisfies

\[
N_k\le k(\log k)^c
\]

for infinitely many \(k\), then

\[
Q_{r,A}:=1+2\sum_{j=0}^{r-1}A^j
 =\Omega_{A,\rho,\sigma_0,c}
   \left(\frac{\log k}{\log\log k}\right).
\tag{7.11}
\]

Equivalently, for fixed \(A\),

\[
r\ge \log_A\log k-\log_A\log\log k-O_{A,\rho,\sigma_0,c}(1).
\tag{7.12}
\]

To see this with the required uniform quantifiers, expose the two \(A\)-ary decision trees
and tag the inline coordinate, giving a nonadaptive \(Q_{r,A}\)-query weak RLDC over an
alphabet of size \(A+2\). Write

\[
  a:=\left\lceil Q_{r,A}/\sigma\right\rceil,
  \qquad g:=\frac{\log k}{\log\log k}.
\]
The arbitrary-alphabet RLDC lower bound gives
\[
  N_k\ge
  \left(
    \frac{\sigma^2 k}
    {38Q_{r,A}^4\log^2(A+2)\log^2 k}
  \right)^{1+1/a}.
\]
Suppose, for a constant \(\eta>0\), that \(Q_{r,A}\le\eta g\). Since
\(\sigma\ge\sigma_0\), for all sufficiently large \(k\),
\[
  a\le \frac{2\eta}{\sigma_0}g,
  \qquad
  \frac{\log k}{a}\ge \frac{\sigma_0}{2\eta}\log\log k.
\]
Moreover \(N_k\ge k\) and \(N_k\le k(\log k)^c\) imply the fixed-radius hypothesis
of the RLDC bound on this branch, because
\[
  N_k^{-\sigma/(2Q_{r,A})}
  \le
  \exp\!\left(-\frac{\sigma_0\log k}{2\eta g}\right)
  = (\log k)^{-\sigma_0/(2\eta)}
  < \delta_0
\]
for large \(k\), where \(\delta_0>0\) is the radius supplied by the inline compiler.
Taking logarithms and using \(N_k\le k(\log k)^c\), while
\[
  \log\!\left(38Q_{r,A}^4\log^2(A+2)\log^2 k/\sigma^2\right)
  \le 6\log\log k+O_{A,\sigma_0,\eta}(1),
\]
gives
\[
  \frac{\log k}{a}
  \le (c+12)\log\log k+O_{A,\sigma_0,\eta}(1).
\]
Choosing \(\eta<\sigma_0/[4(c+12)]\) contradicts the preceding lower bound for all
sufficiently large \(k\). Hence \(Q_{r,A}\ge\eta g\), proving (7.11) with a uniform
constant. This is a parameter barrier, not an existence theorem at the threshold scale; a
surviving construction must either pay this growing locality or leave the finite-alphabet,
positive-radius, target-relative model.

## 8. The theorem program

The results above leave two theorem-level outcomes.

### Conjecture 8.A (core-versus-family/RLDC dichotomy)

Fix a finite proof alphabet, constant per-claim query complexity, a positive
target-relative radius, and a constant completeness/soundness gap.  Consider a
hidden-output family \(\mathcal M_k\) of entropy \(\Omega(k)\), with a
single-target/codeword-only soundness guarantee but no family lift yet, and proof length
\(N_k\le k\operatorname{polylog}k\).  Then one of the following two mechanisms must be
present:

1. the same address mechanism admits a target-relative family lift whose common proof
   and honest query distribution have enough distance/hitting mass to produce a
   relaxed local decoder after uniformization; or
2. a target-dependent concentrated core carries a superlinear cost in its size,
   replication, or address/descriptor description.

The first branch is realized under the common-proof and family-level hypotheses of
Theorems 3.4D--3.4N'.  The conjectural content is the second branch before the family
lift is available: it would turn the heavy-core escape from a toy counterexample into a
general barrier theorem.  Any proof must quantify target-dependent cores and cannot
assume a common query set or silently replace a hidden-output family by one selected
target.

### Conjecture 8.B (structured distributional soundness is not an ACRR compiler)

The black-box quantifier separation itself is already proved by Proposition 3.2D:
average-coordinate or list-style distributional soundness can give every coordinate
an acceptable local explanation while no single global word/strategy realizes all
coordinates simultaneously.  The open, nontrivial version is the following.  After
requiring a genuine constant-query dPCP/PCPP with nontrivial local constraints,
perfect completeness, and a fixed common address space, ordinary distributional/list
soundness still does not suffice for simultaneous target-relative coordinate
robustness.  Any successful upgrade must add singleton target binding, global-word
consistency, or a coordinate-robust outer check.

This is now a structured separation conjecture, not a claim that the elementary
black-box separation remains open.  It is also not a claim that every distributionally
sound PCP fails after adding such structure.

Conjecture 8.A and this structured version of 8.B are the falsifiable positive/negative
program behind the two outcomes below; neither is used as an assumption in the proved
theorems.

* **Positive outcome.** Construct a target-output projection relation-PCPP with one global
proof, inverse-linear target error, finite uniform alphabet, and address-scale generation.
  Composed with the existing singleton bridge, this would give a new simultaneous
  coordinate-robust PCP theorem and would instantiate the RW/JK route.
* **Negative outcome.** Prove that every such shared relation-PCPP either exposes a history-scale
  channel, pays superlinear proof length, increases locality, or reduces to a relaxed-LDC/LDC
  family that violates a known coding lower bound.

The distinction matters. A per-coordinate recompiled PCPP, a list-soundness statement without
target concentration, or an exposed-history construction is a valid baseline but not a
solution to the address-scale problem.

The same distinction is the project-level closure criterion. A successful RW/JK theorem must
either provide one global proof with simultaneous target binding at address scale, or prove a
general cost theorem showing that one of the four remaining escapes—bottom, cover sheet,
target descriptor, or address scale—necessarily pays an RLDC/LDC, proof-length, support, or
communication price. The conditional closure theorem below is therefore an endpoint
specification, not a claim that the present manuscript has already proved (P\ne NP).

### 8.1 Conditional closure theorem for the RW/JK route

The final \(P\ne NP\) implication has a precise conditional form. Let \(A\) be a correct
polynomial-time SAT decider and let \(H_{A,n}\) be the single canonical object produced by
the RW/JK construction on an infinite set of lengths. Assume
\(\operatorname{CC}(H_{A,n})>s_n\) with \(s_n>n^c\) eventually for every constant \(c\).
If, for every address, an address-scale procedure generates a query for that same proof and
history in \(n^{O(1)}\) time, all coordinates use one word-consistent proof/strategy, bottom
and cover-sheet branches are either handled by the same evaluator or excluded on the actual
instance, and all descriptors and sheet indices have total length \(n^{O(1)}\) (so they may be
hardwired as \(P/\mathrm{poly}\) advice), then
\[
P=NP\quad\Longrightarrow\quad H_A\in P/\mathrm{poly}.
\tag{8.1}
\]
The proof is a direct address-by-address simulation after the relevant promise/PH queries
collapse under \(P=NP\); hardwiring the length-\(n\) descriptor/selector/advice yields an
\(n^{O(1)}\)-size circuit for \(H_{A,n}\), contradicting the forcing lower bound on the same
infinite length set. Uniform generation of that advice is only needed for the stronger claim
\(H_A\in P\), not for the stated \(P/\mathrm{poly}\) contradiction.

This is a closure theorem, not a completed \(P\ne NP\) proof: current work has not shown
that the actual RW canonical history has the required address-scale evaluator. The unresolved
conditions are exactly (i) RW attachment, (ii) bottom/cover/descriptor escape
classification, and (iii) quantifier and length alignment between reconstruction and forcing.
Full hypotheses and the formal proof are recorded in
[the Closure Theorem note](../../../mcsp-hardness-magnification/notes/204-rw-succinct-smart-reconstruction-closure-theorem-2026-08-17.md).

### 8.2 The direct RW reconstruction is not yet address-scale

The preceding qualification is a theorem-level parameter statement, not merely a missing
implementation detail. In Ren--Williams Theorem 4.1, `Reconf` reconstructs one bit in
\(\operatorname{poly}(k,r,\log t)\) time, and the Merlin gate-list supplied to its promise
queries has size \(O(k^4\log t)\). The same PCP witness \(\Pi_x\) can witness all coordinate
queries on a fixed failure branch, so the obstruction is not a hidden per-coordinate proof
choice. It is the scale of the interface.

In the Theorem 4.3 recurrence \(n_{i+1}=n_i^C\), \(T_i=\max\{2^{cD^i n_0},n_{i+1}\}\),
the stage-\(i\) function pads the previous \(2n_i\)-bit AVOID output to \(T_i\) bits and
invokes Theorem 4.1 with \(k=n_{i+1}\). On the stable tail \(T_i=n_{i+1}=n_i^C\),
the natural deterministic evaluator obtained after collapsing the smart queries under
\(P=NP\) has size at most \(n_i^{O(C)}\). The recovered table, however, has address length
\(\lceil\log_2(2n_i)\rceil\). Thus direct `Reconf` gives at most a \(2^{O(m_i)}\)-scale
evaluator for an \(m_i\)-address table, not an \(m_i^{O(1)}\)-size circuit required by
the Closure Theorem. The full parameter audit is in [Closure note §1A](../../../mcsp-hardness-magnification/notes/204-rw-succinct-smart-reconstruction-closure-theorem-2026-08-17.md).

This closes one possible misreading of the route: the original RW theorem supplies a
same-proof, smart, **q-scale** reconstruction, but it does not supply the additional
address-scale compression theorem needed by Gate I. Proving that compression, or proving
that every such compression incurs an RLDC/LDC-type cost, remains the top-level theorem
program.

### Proposition 8.2A (promise-to-corruption non-transfer)

There is a second, logically independent gap between RW `Reconf` and a shared-proof
ACRR. Let \(\mathcal R\) be a reconstruction procedure whose only semantic oracle is a
promise problem \(\mathcal P\). On the canonical RW branch for a target \(x\), suppose every
query made by \(\mathcal R\) lies in the stated promise of \(\mathcal P\), and the resulting
answers recover the claimed output bits. A **physicalization** is any rule that turns a
physical proof word \(z\), a coordinate \(i\), and a claim \(b\) into the oracle instance
seen by \(\mathcal R\). The RW promise theorem specifies this rule on the canonical proof
\(\Pi_x\), but does not specify it on corrupted words.

From these hypotheses alone one cannot deduce target-relative soundness of the form
\[
  \Pr[\mathcal R(z,i,1-m_i)=1]\le\beta
  \qquad\text{whenever}\qquad
  \operatorname{dist}(z,\Pi_x)\le\rho|\Pi_x|.
\tag{8.2A.1}
\]
More precisely, for every black-box transfer that leaves the off-promise semantics
unspecified, there is an admissible completion of those semantics which agrees with the
canonical RW execution on every promised query, but maps one chosen \(\rho\)-near word on
the wrong branch to an off-promise query accepted with probability one. The RW conclusion
and all its smart-query guarantees are unchanged, while (8.2A.1) fails.

#### Proof

The hypotheses constrain only the oracle instances actually generated on the canonical
branch and the promise behavior on those instances. Fix any nontrivial word \(z\) in the
\(\rho|\Pi_x|\)-ball and the wrong claim \(1-m_i\). Keep the physicalization and verifier
unchanged on \(\Pi_x\) and on every promised query. On the single missing input
\((z,i,1-m_i)\), send an instance \(q^\star\) outside the promise and complete the
verifier's off-promise behavior so that some response is accepted with probability one.
Promise-problem semantics impose no restriction on \(q^\star\). Hence the modified
completion is indistinguishable from the original one to the RW theorem, but its wrong
branch accepts on \(z\), contradicting (8.2A.1). \(\square\)

The proposition is a black-box non-transfer statement, not a claim that the concrete RW
verifier has a bad near proof. It identifies an additional axiom needed for any positive
attachment: a promise-preserving physicalization for every target-relative near proof, or
an equivalent transcript-domination/robust-ROC theorem. Without that axiom, the fact that
the same canonical \(\Pi_x\) witnesses all coordinate queries does not produce a physical
common-proof RLDC. This is precisely the Gate-II boundary between smart promise queries
and coordinate-robust corruption semantics.

### Corollary 8.2B (the exact transcript bridge after physicalization)

Assume, in addition to Proposition 8.2A, that a proposed physicalization \(\Phi\) gives a
fixed visible transcript space for every \((i,b)\), and that every physical word \(z\)
induces a transcript law \(\mu_{m,i,b,z}\). Define the honest and target-relative wrong
families exactly as in (266.1), and let \(\mathsf{ROC}_{i,b}(\alpha,\rho)\) be the robust
transcript frontier (266.2). Then, for each fixed coordinate and claim \((i,b)\), the
following are equivalent for the transcript-only version of the proposed RW attachment:

1. there is a postprocessor with honest completeness at least \(\alpha\) for every
   \(m_i=b\) and wrong-claim probability at most \(\beta\) on every
   \(\rho\)-near proof;
2. \(\mathsf{ROC}_{i,b}(\alpha,\rho)\le\beta\).

The global attachment has the stated parameters exactly when this condition holds for
all \((i,b)\).

Thus the missing Gate-II bridge is not an unspecified “promise robustness” condition once
\(\Phi\) is supplied: it is exactly the robust ROC inequality. If it holds at
\((\alpha,\beta)=(2/3,1/3)\), the physical proof becomes the common-proof relaxed-LDC
interface of the transcript-only closure in Section 7 and inherits the variable-query DGL/GGS locality-length
barrier. If it fails for some \((i,b)\), Theorem 266.1 and its minimax dual give a single
mixture of target-relative near proofs that defeats every transcript-only postprocessor
with the required honest completeness. In particular, improving the RW promise query
itself cannot repair the failure; one must change the physicalization, proof space, radius,
or use genuinely non-transcript global interaction.

### 8.3 A closure trichotomy for the two top-level attacks

The single-target forcing argument and the family-level coding argument can be tested in
one statement. Suppose an address evaluator for the same canonical object uses a static
descriptor of length \(d_n\), finite control of size \(p_n\), and at most \(p_n\) random
accesses to that descriptor. If the evaluator survives the \(P=NP\) collapse, ROM expansion
gives
\[
  p_n^2+p_nd_n+p_n\log N_n
  =\Omega(\operatorname{CC}(H_{A,n})).
\tag{8.2}
\]
Thus a polynomial-control, polynomial-descriptor evaluator is already a
\(P/\mathrm{poly}\) closure and cannot coexist with the forcing lower bound. If, instead,
the same proof/address space extends to a target-relative family of (k_n)-bit messages,
the common proof map is a relaxed locally decodable code. For binary adaptive depth (r_n),
\(Q_n=2^{r_n+1}-1\); under the GGS radius condition and
\(N_n\le k_n^{1+\varepsilon_n}\),
\[
  \frac1{\lceil Q_n/\sigma_n\rceil}\le
  \varepsilon_n+\left(1+\frac1{\lceil Q_n/\sigma_n\rceil}\right)
  \frac{\log(38Q_n^4\log^2 2\,\log^2 k_n/\sigma_n^2)}{\log k_n}.
\tag{8.3}
\]
Consequently, a proposed route that is neither a short single-target evaluator nor a
certified family lift has not yet closed the proof: it must name the missing common-proof,
target-relative, radius/gap, or incidence/smoothness hypothesis. This is a derived closure
trichotomy, not a claim that the present RW history satisfies either positive branch; full
hypotheses and proof are recorded in [the trichotomy note](../../../mcsp-hardness-magnification/notes/261-rw-closure-trichotomy-forcing-and-rldc-2026-08-17.md).

### Theorem 8.3A (RW Gate-II semantic closure)

The preceding trichotomy has a logically prior semantic gate. Let a proposed
attachment map a physical proof word \(z\) to the visible transcript space used
by the RW smart-prMA queries. If this map is not promise-preserving on every
target-relative \(\rho\)-near proof, then the RW theorem cannot imply
target-relative ACRR/RLDC soundness: an admissible off-promise completion can
agree on every canonical-history query and accept a wrong near branch. This is
the black-box non-transfer in Proposition 8.2A.

Assume instead that the map is promise-preserving and induces a fixed transcript
law. For each coordinate and claim \((i,b)\), let
\(\mathsf{ROC}_{i,b}(\alpha,\rho)\) be the minimum worst-case wrong-claim
probability among transcript-only postprocessors with honest completeness
\(\alpha\). Then exactly one of the following interface-level alternatives
holds:

1. \(\mathsf{ROC}_{i,b}(\alpha,\rho)>\beta\) for some \((i,b)\). The minimax
   dual supplies one mixture of target-relative near proofs defeating every
   transcript-only postprocessor with completeness \(\alpha\).
2. \(\mathsf{ROC}_{i,b}(\alpha,\rho)\le\beta\) for every \((i,b)\). If the
   attachment also has a common target family, positive radius, and all-policy
   semantics, the physical object is a common-proof relaxed-LDC interface, so
   the package and locality gates in Theorem 8.3 and the master trichotomy apply.
   Without those family hypotheses this branch is only a low-ROC transcript
   filter, not yet an RLDC.

Moreover, if the second branch also uses a finite common-response ROM for a
forced hard block \(B_i\), then the shared strategy lower bound gives

\[
 \operatorname{CC}(B_i)\le O\!\left(m_i(p_i+b_i d_i+m_i)\right),
\tag{8.3A.1}
\]

and hence \(d_i=\Omega(2^{m_i}/(m_i^2b_i))\) whenever
\(\operatorname{CC}(B_i)=\Omega(2^{m_i}/m_i)\). Thus low ROC does not make an
address-scale finite strategy free; it only moves the construction into the
quantitative RLDC/locality/descriptor branches.

This theorem is conditional on the stated physicalization and transcript-only
interface. It is not a claim that the current RW/GMWZ construction already
provides the map, nor a general dPCP impossibility theorem. Its role is to make
the remaining positive target exact: one must construct a promise-preserving,
low-ROC, globally word-consistent package, or prove that every such package pays
the resulting RLDC/locality/descriptor cost. The combined quantitative statement
is recorded in the RW Closure-Gate master trichotomy.

## References

1. T. Gur, D. Minzer, G. Weissenberg, and K. Z. Zheng, “3-Query RLDCs are Strictly Stronger
   than 3-Query LDCs,” ECCC TR25-217, 2025.
   <https://eccc.weizmann.ac.il/report/2025/217/>
2. D. Dall'Agnol, O. Gur, and O. Lachish, “Relaxed Locally Decodable Codes,” ECCC TR20-154,
   2020.
   <https://eccc.weizmann.ac.il/report/2020/154/>
3. O. Paradise, “Smooth and Strong PCPs,” ECCC TR19-023, revision 4, 2021.
   <https://eccc.weizmann.ac.il/eccc-reports/2019/TR19-023/>
4. D. Dinur, T. Harsha, and M. Klartag, “Distributional Soundness,” ECCC TR15-085, 2015.
   <https://eccc.weizmann.ac.il/report/2015/085/>
5. K. Cheng, X. Li, and S. Mao, “When Relaxation Does Not Help: RLDCs with Small Soundness
   Yield LDCs,” arXiv:2603.03717, 2026.
   <https://arxiv.org/abs/2603.03717>
6. I. Dinur, O. Goldreich, and T. Gur, “Every set in P is strongly testable under a suitable
   encoding,” ECCC TR18-050, revision 2, 2026.
   <https://eccc.weizmann.ac.il/report/2018/050/>
7. E. Grigorescu, V. M. Kumar, P. Manohar, and G. Mon, “Relaxed vs. Full Local Decodability
   with Few Queries: Equivalence and Separations for Linear Codes,” arXiv:2511.02633, 2025/2026.
   <https://arxiv.org/abs/2511.02633>
8. M. Bafna and D. Minzer, “Characterizing Direct Product Testing via Coboundary Expansion,”
   STOC 2024, arXiv:2308.09668.
   <https://arxiv.org/abs/2308.09668>
9. T. Dikstein and I. Dinur, “Agreement Theorems for High Dimensional Expanders in the Low
   Acceptance Regime: The Role of Covers,” arXiv:2308.09582, 2024.
   <https://arxiv.org/html/2308.09582>
10. M. Bafna, D. Minzer, and N. Vyas, “Quasi-Linear Size PCPs with Small Soundness from HDX,”
    arXiv:2407.12762, 2024/2025.
    <https://arxiv.org/html/2407.12762>
11. T. Gur, D. Minzer, G. Weissenberg, and K. Z. Zheng, “3-Query RLDCs are Strictly Stronger
   than 3-Query LDCs,” arXiv:2512.12960, 2025/2026.
   <https://arxiv.org/html/2512.12960>
