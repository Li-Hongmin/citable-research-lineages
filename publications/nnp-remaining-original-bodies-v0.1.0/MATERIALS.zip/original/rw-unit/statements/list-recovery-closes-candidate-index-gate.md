# List recovery closes the public-candidate index gate

## Proposition

Let
\[
  Y=\{y^{(s)}=C(m^{(s)}):s\in\mathcal S\}\subseteq\Gamma^M,
  \qquad |\mathcal S|=L,
\]
where the words are pairwise at relative distance at least \(\Delta>0\).  Assume
that symbols \(y^{(s)}_j\) are publicly computable from \((s,j)\), and that the
outer code \(C\) has a deterministic \(q_D\)-query decoder for every message
coordinate.

Let \(\Pi(s)\in\Sigma^N\) be a common-address proof map.  For a uniformly sampled
coordinate \(J\in[M]\), let \(D_J\) be an adaptive \(q\)-query proof decoder with
perfect completeness
\[
  D_J(\Pi(s))=y^{(s)}_J
  \quad\text{with probability one}.
\]
Suppose that every proof \(z\) in the radius-\(\rho\) neighborhood of \(\Pi(s)\)
satisfies
\[
  \Pr_{J,D_J}[D_J(z)\ne y^{(s)}_J]\le\varepsilon,
  \qquad \varepsilon<\Delta/2.
\tag{LR1}
\]

Assume there is a public randomized sampled-symbol list-recovery algorithm
\(\mathsf{LR}\) with the following guarantee.  Given \(R_0\) independent pairs
\[
  (J_t,\widehat y_t),\qquad
  \Pr[\widehat y_t\ne y^{(s)}_{J_t}]\le\varepsilon,
\]
where \(J_t\) is uniform and the samples are independent, \(\mathsf{LR}\) runs in
address-scale time, returns a list \(B\subseteq\mathcal S\) of size at most \(\ell\),
and
\[
  \Pr[s\notin B]\le\eta_0.
\tag{LR2}
\]
Then, for every \(\eta>\eta_0\), the common proof supports a bounded-error
address-scale RLDC for the messages \(m^{(s)}\).  Its proof-query locality is
\[
  q\left(R_0+
  \left\lceil\frac{2\log(\ell/(\eta-\eta_0))}
  {(\Delta-2\varepsilon)^2}\right\rceil\right)+q_D,
\tag{LR3}
\]
up to the decoder's own constant-success amplification convention.  Its running time
is the running time of \(\mathsf{LR}\), plus address-scale evaluation of at most
\(\ell R_1+q_D\) candidate symbols, where \(R_1\) is the second term in (LR3).

Conversely, any index-recovery procedure that receives only the sampled pairs
\((J_t,\widehat y_t)_{t\le R_0}\), is target-independent, and succeeds with probability
at least \(1-\eta_0\) under (LR1), is itself an \((R_0,\ell,\eta_0)\) sampled-symbol
list-recovery algorithm (take \(\ell=1\) when it outputs one index).

## Proof

Run \(D_{J_t}\) on the common proof to obtain \(\widehat y_t\).  By (LR1), these are
independent noisy samples of the target word with per-sample error at most
\(\varepsilon\).  With probability at least \(1-\eta_0\), \(\mathsf{LR}\) returns a
list \(B\) containing the true index \(s\).

Use \(R_1\) fresh samples and score only the candidates in \(B\).  The true candidate
has expected agreement at least \(1-\varepsilon\), while every other candidate has
expected agreement at most \(1-\Delta+\varepsilon\).  Hoeffding's inequality and a
union bound over at most \(\ell-1\) wrong candidates give probability at most
\(\eta-\eta_0\) of selecting the wrong member of \(B\).  Once \(s\) is selected,
evaluate the \(q_D\) positions requested by the outer decoder and decode the desired
message coordinate.  The proof-query count is (LR3), and the two failure events sum to
at most \(\eta\).

The converse is definitional: an index-recovery algorithm's output is already a list of
size one satisfying (LR2).  No property of the underlying dPCP beyond (LR1) is used.
\(\square\)

## Information lower bound for sample-only recovery

There is also an unconditional transcript bound.  Let the target index \(S\) be uniform
on \(\mathcal S\), let the sampled coordinates be independent of \(S\), and suppose a
sample-only procedure outputs a list \(B\) of size at most \(\ell\) with
\(\Pr[S\notin B]\le\eta<1\).  Since each observed symbol has alphabet size
\(|\Gamma|\),
\[
  R_0\log_2|\Gamma|
  \ \ge\ I(S;B)
  \ \ge\ (1-\eta)\log_2(L/\ell)-h_2(\eta).
\tag{LR4}
\]
The first inequality uses \(I(S;J_t,\widehat y_t)\le\log_2|\Gamma|\) per sample; the
second is the list version of Fano's inequality.  Thus any sample-only recovery of an
exponential candidate family requires \(\Omega(\log L)\) noisy-symbol samples, up to the
output-list and alphabet factors.  The logarithmic sample count in Proposition 3.8B is
therefore the right information scale; the new list-recovery condition addresses its
running-time bottleneck, not an information-theoretic shortcut.

## Consequence for the closure program

This separates the remaining public-candidate gate into two genuinely different
possibilities:

1. a robust outer decoder can consume noisy symbols directly, in which case no global
   index recovery is needed; or
2. the outer code is not robust in that sense, and a target-independent sampled-symbol
   list-recovery/index-recovery mechanism is necessary.

Thus “public candidate evaluator” alone is insufficient when \(L\) is large.  A brute-force
scan over all \(L\) candidates is not address-scale; the exact replacement is list recovery
with small output list and address-scale running time.  For a full \(k\)-bit candidate
family, \(L=2^k\), any sample-only exact index recovery must in particular convey
\(\Omega(k)\) bits of index information; the proposition does not claim that this can be
done with constant locality.  The theorem is a closure interface, not an assertion that
current GMWZ constructions supply the list-recovery algorithm.

## Relation to current dPCP constructions

GMWZ-style list soundness supplies a common list of output words for a fixed assignment,
but does not by itself provide the public sampled-symbol list-recovery algorithm in (LR2).
The proposition therefore identifies a sharper positive target than “find a global list”:
construct a public, address-scale list-recoverable output family, or prove a direct robust
outer decoder.  Without one of these, the global-word-to-RLDC closure remains incomplete.
