# Succinct target-binding compilers pay the ambient nondeterministic time scale

## 定理

令 \(t:\mathbb N\to\mathbb N\) 是时间可构造函数，令
\(\mathsf{NTIME}(t)\) 表示在 \(t(n)\) 时间内可由非确定性机器判定的语言类。
考虑一个**统一短 key 编译器**，它对 \(\mathsf{NTIME}(t)\) 中的每个语言 \(L\)
（使用同一组上界 \(p(n)=n^{O(1)}\) 和 \(r(n)\)）以及每个输入 \(x\in\{0,1\}^n\)
产生如下对象：

* 一个长度至多 \(p(n)\) 的 key \(s\)；
* 一个确定性的、时间至多 \(p(n)\) 的随机访问 evaluator
  \(E_L(x,s,a)\)，用于回答所有 proof-address 查询；
* 一个时间至多 \(p(n)\) 的 verifier
  \(V_L(x,s;r,\tau)\)，其中 \(r\in\{0,1\}^{r(n)}\)，而每条 Merlin response
  \(\tau\) 的长度至多 \(p(n)\)。

假设其语义为固定 gap：

\[
\begin{aligned}
x\in L &\Longrightarrow
  \exists s\ \Pr_{r}\bigl[\exists\tau:
  V_L(x,s;r,\tau)=1\bigr]\ge 2/3,\\
x\notin L &\Longrightarrow
  \forall s\ \Pr_{r}\bigl[\forall\tau:
  V_L(x,s;r,\tau)=0\bigr]\ge 2/3.
\end{aligned}
\tag{RT1}
\]

令
\[
  u(n):=2^{r(n)}p(n)^{O(1)}.
\]
若
\[
  u(n)\log u(n)=o(t(n)),
\tag{RT2}
\]
这里把 `u` 理解为上述枚举算法的一个统一、时间可构造的上界；若原始
`2^{r(n)}p(n)^{O(1)}` 不是时间可构造函数，只需取一个多项式因子内的
时间可构造上界，(RT2) 不变。
则不存在这样的统一编译器。

换言之，若它覆盖整个 \(\mathsf{NTIME}(t)\)，随机性不能被压到低于环境时间尺度；
短 key、完整随机访问和每条随机带一个多项式长度 response 不能共同把
\(\mathsf{NTIME}(t)\) 压进严格更低的非确定性时间类。

## 证明

固定任意 \(L\in\mathsf{NTIME}(t)\)。给定输入 \(x\)，一个非确定性机器猜测 key \(s\)，
以及对每一条随机带 \(r\in\{0,1\}^{r(n)}\) 的一条 response \(\tau_r\)。随后枚举全部
\(2^{r(n)}\) 条随机带，用确定性的 evaluator 回答 proof 查询，并运行
\(V_L(x,s;r,\tau_r)\)。机器接受当且仅当至少 \(2/3\) 的随机带通过。

若 \(x\in L\)，由 (RT1) 可为至少 \(2/3\) 的随机带选择接受 response，因此该机器接受。
若 \(x\notin L\)，对每个 key 至少 \(2/3\) 的随机带对所有 response 都拒绝，因而任何
猜测的 response 表都不能达到 \(2/3\) 的通过率，机器拒绝。

猜测和验证整张 response 表所需的时间至多
\(2^{r(n)}p(n)^{O(1)}=u(n)\)。所以 \(L\in\mathsf{NTIME}(u)\)。由于编译器对
\(\mathsf{NTIME}(t)\) 中每个语言都适用，这给出
\[
  \mathsf{NTIME}(t)\subseteq\mathsf{NTIME}(u).
\]
在 (RT2) 下，非确定性时间层次定理给出
\(\mathsf{NTIME}(t)\not\subseteq\mathsf{NTIME}(u)\)，矛盾。
\(\square\)

## 指数时间 corollary

取 \(t_c(n)=2^{n^c}\)，并设 \(p(n)=n^d\)。若
\[
  n^c-r(n)>(d+c+2)\log_2 n
\tag{RT3}
\]
对充分大的 \(n\) 成立，则
\[
  2^{r(n)}n^d\log\!\bigl(2^{r(n)}n^d\bigr)=o(2^{n^c}),
\]
故不存在覆盖整个 \(\mathsf{NTIME}(2^{n^c})\) 的该类编译器。

特别地：

1. 若 \(r(n)=o(n^c)\)，则必违反 (RT3)；
2. 若一个统一编译器声称以某个固定多项式随机性
   \(r(n)=O(n^a)\) 覆盖全部 NEXP，则选取 \(c>a\)，立刻得到矛盾；
3. \(r(n)=O(\log n)\) 的情形是本项目已有的
   \(\mathrm{NEXP}\subseteq\mathrm{NP}\) barrier 的特例，但 (RT2) 给出更一般的时间尺度
   版本。

这里的“统一”很重要：若每个语言可以使用不同的多项式次数，必须先在一个具有共同
\(p,r\) 上界的语言子类上应用定理。

## 与 ACRR/RW 的关系

该定理甚至没有使用同时坐标鲁棒性；它只使用短 key、完整随机访问 evaluator 和
短 response 的量词。因此它是 ACRR 正向构造前的先验过滤器：

* 一个只针对单个 RW 关系的构造不受此定理直接排除；
* 一个覆盖 NEXP-hard 单语言、但随机位超过对数的构造也不受此定理直接排除；
* 一个对所有 NEXP 关系统一给出固定多项式随机性的短-key compiler 不可能存在；
* 已知 NEXP PCP 的 proof 通常是指数长度，正好不满足这里的完整短 evaluator 假设，
  因而不存在与已知 PCP 定理的矛盾。

因此，若要把 ACRR 推广成普适 NEXP 编译器，随机位、proof evaluator 或 response
表中至少一项必须重新回到环境时间尺度；若只研究固定 RW 实例，则仍需单独证明
地址尺度、整词一致和 coordinate robustness 的核心接口。

## 证据边界

这是非确定性时间层次定理与 response-table 枚举的直接推导。它不声称
\(\mathrm{NEXP}\not\subseteq\Sigma_2^P\)、\(\mathrm{NEXP}\not\subseteq\mathrm{NP}^{\mathrm{PP}}\)，
也不把普适编译器的结论外推到单一 RW history。它新增的是“随机性必须跟随所覆盖的
NEXP 时间指数”的定量边界。
