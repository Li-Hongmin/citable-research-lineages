# Strong-canonical PCP 与 ACRR 的类复杂度—共享证明三分

## 定理地位

这是一个**文献约束下的路线定理**，不是对一般 ACRR 的无条件不可能性证明。
它精确说明：strong-canonical PCP 的唯一 proof 性质不能直接替代 RW/JK 的
shared-proof coordinate binding。一个黑箱方案必须落入以下三种情形之一：

1. 对 NP-hard 的 computation relation 直接要求 logarithmic-randomness
   strong-canonical PCP，从而触发 `UP` 类复杂度条件；
2. 对每个 `(i,b)` 分别调用 canonical PCP，因而得到不同 proof/address space，
   不满足 simultaneous ACRR；
3. 额外提供一个统一的 shared-object synthesis，使所有 canonical proofs 在同一
   地址空间中可局部生成；在有正半径 target separation 时，这个 synthesis 已进入
   RLDC barrier。

这条三分把近期 strong-canonical PCP 结果的真正作用边界接到本项目的 ACRR 量词，
而不把“唯一 proof”本身冒称为 coordinate robustness。

## 文献输入的精确定义

令 `S` 是一个语言，`V` 是其 strong-canonical PCP。对每个 yes-instance `x`，
存在唯一的 proof `Pi(x)` 使 `V` 完美接受；任意 alleged proof `pi` 的拒绝概率按
`pi` 到 `Pi(x')` 的距离（以及输入到某个 yes-instance `x'` 的距离）增长。

Dinur--Goldreich--Gur 的修订版 TR18-050 给出两个与本项目直接相关的刻画：

* **Theorem 3.1：** `S` 有 logarithmic-randomness strong-canonical PCP，当且仅当
  `S in UP`；其 canonical proof 可由原始 UP witness 多项式时间转换得到。
* **Theorem 3.2：** polynomial proof complexity 且 polynomially strong 的
  strong-canonical PCP 对应 `S in UMA`。

这些是本文使用的外部定理；ACRR 的其余结论均由下面的量词推导得到。

## 定理 1：直接 canonicalization 的类复杂度门槛

设 `S` 是 NP-hard（例如 SAT）。若一个 RW 替代方案为 `S` 提供
logarithmic-randomness strong-canonical PCP，则

\[
  S\in \mathrm{UP},
  \qquad\text{从而（对 NP-complete 的 }S\text{）}\qquad
  \mathrm{NP}=\mathrm{UP}.
\]

若只要求 polynomial proof complexity 与 polynomial strongness，则得到

\[
  S\in\mathrm{UMA};
\]

对 NP-complete 的 `S`，这至少把整个 `NP` 放入 `UMA`。因此“先把任意 NP
computation history canonicalize，再接 RW”不是一个无条件的 PCP 预处理步骤；它
本身已经承担了一个非平凡的类复杂度假设。

### 证明

第一式直接是 TR18-050 Theorem 3.1。若 `S` 是 NP-complete，任意
`L in NP` 可多项式时间归约到 `S`，把 `S` 的唯一 valid proof 作为 `L` 的唯一
witness，即得 `L in UP`，所以 `NP=UP`。第二式同理由 TR18-050 Theorem 3.2
及标准的多项式归约闭包得到。

注意这不是声称 `NP != UP` 或 `NP not-subseteq UMA`；它是一个路线门槛：若构造
成功，必须同时解释这个类复杂度后果。

## 定理 2：target-wise canonical calls 不能产生 shared ACRR

令 `R(x,m,w)` 是 RW computation relation，`m in {0,1}^k` 是确定性输出词。
若对每个坐标 `i` 和声明 `b`，把

\[
  (x,i,b)\longmapsto \text{a separate strong-canonical PCP}
\]

作为输入，则文献定理只产生一族 canonical proofs
`Pi_{x,i,b}`。它没有给出一个 `Pi_x` 使所有坐标 verifier 共用同一 proof/address
space。即使 `m` 在所有 satisfying histories 中唯一，proof/history 仍可能有多个
witness；“唯一 decoded output”不等于“唯一 canonical proof”。

因此，逐坐标 canonical call 只有在另加一个 synthesis map

\[
  S_{x,i,b,j}(D_x)=\Pi_{x,i,b}[j]
\]

时才可能变成 ACRR。这里 `D_x` 必须是一个不随 `(i,b)` 切换的 shared object，
且所有 `S` 使用同一 physical address space；否则直接违反 ACRR 的整词一致性量词。

## 定理 3：若 synthesis 具有鲁棒共享语义，则进入 RLDC

进一步假设输出词由一个常率、常距离 code `C:{0,1}^k -> Sigma^n` 表示。对每个
`(i,b)`，设 canonical PCP/PCPP 对错误半空间（或目标集合）具有正目标距离
`rho_H` 和错误接受率 `beta_H<1/2`：当输入 oracle 位于 `C(m)` 的
`rho_H` 邻域且 `b != m_i` 时，任意 proof 都以至多 `beta_H` 被接受。

若 shared synthesis 每生成一个 proof symbol 只查询 `r` 个 `D_x` symbols，
则 message-inline 词

\[
  D(m)=m\,\|\,C(m)\,\|\,D_x(m)
\]

给出 locality 至多

\[
  Q\le 1+q_C+q_P r,
\]

半径 `rho_H n / |D(m)|` 的 relaxed local decoder。其 proof/address synthesis
不再是 PCP 逃逸，而是一个 RLDC 编码；在固定 alphabet、固定 locality、正半径和
近线性长度窗口内，它受到现有 relaxed-LDC 长度下界约束。

### 证明

在精确的 `D(m)` 上，读取 inline message bit 得到 `m_i`；若声明为正确位，
shared synthesis 产生相应 canonical proof，完备性给出正确输出。若收到的词距
`D(m)` 小于 `rho_H n`，其 code 区段仍在 `C(m)` 的目标邻域内。声明错误位时，
无论 synthesis 产生哪一个 proof 字符串，half-space soundness 都把接受率限制为
`beta_H`。每个输入查询耗一次 codeword query，每个 proof query 通过 synthesis
耗至多 `r` 次 shared-object query，故得到上述 `Q` 和 RLDC 语义。

## 对 RW/JK 路线的裁决

strong-canonical PCP 的正向价值仍然真实：它能提供单一 proof、距离相关拒绝和
canonical evaluation 的研究模板。但对 RW/JK，必须明确选择以下出口：

* 接受 `UP`/`UMA` 级别的 unambiguousization，并证明它仍能处理原始 NP relation；
* 给出新的 shared-object synthesis，并承担定理 3 的 RLDC/长度代价；或
* 改变 ACRR 的 target-binding 量词，而不能只引用“canonical”一词。

因此 TR18-050 关闭的是“canonicality 本身已经解决 shared ACRR”这一误读；它没有
关闭真正的新构造，也没有推出一般 ACRR 不可能性。剩余正向目标仍是
`poly(n,log T)` 地址尺度的 shared target-binding/coordinate-robust verifier。

## 来源与边界

* [Dinur--Goldreich--Gur, TR18-050 revision 2](https://eccc.weizmann.ac.il/report/2018/050/)
  的 Theorem 3.1/3.2 给出上述 `UP`/`UMA` 刻画。
* [共享 half-space canonical synthesis barrier](shared-halfspace-canonical-synthesis-barrier.md)
  给出定理 3 的一般编译形式。

本文不把 `UP != NP`、`UMA` 分离或 shared synthesis 的 RLDC barrier 当作已解决的
未条件问题；它只把 strong-canonical PCP 线路从“未知的自由正向接口”提升为一个
可核验的 class-complexity / shared-proof 三分。
