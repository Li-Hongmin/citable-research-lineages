# Non-bottom coordinate robustness upgrades RLDC to LDC

## 定理

令

\[
C:\{0,1\}^{k}\hookrightarrow\Sigma^{N}
\]

是一个有限字母表上的 proof map。对每个消息坐标 \(i\in[k]\) 和声明
\(b\in\{0,1\}\)，令 \(V_{i,b}\) 是至多查询 \(q\) 个 proof symbols 的自适应随机验证器，
并写

\[
p_{i,b}(z)=\Pr[V_{i,b}^{z}=1].
\]

假设存在常数 \(\rho>0\)、完备率 \(\alpha\) 和错误分支上界 \(\beta<\alpha\)，使得：

1. 对每个 \(m,i\)，\(p_{i,m_i}(C(m))\ge\alpha\)；
2. 对每个 \(m,i\) 以及满足
   \(\operatorname{dist}(z,C(m))\le\rho\) 的 \(z\)，有
   \(p_{i,1-m_i}(z)\le\beta\)。

固定 \(0<\delta<\rho\)，定义近邻 proof 上的双分支质量

\[
\tau_\delta=\inf_{m,i}\ \inf_{\operatorname{dist}(z,C(m))\le\delta}
       \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr).
\tag{NB1}
\]

若

\[
\gamma=\min\{\alpha-\beta,\ \tau_\delta-2\beta\}>0,
\tag{NB2}
\]

则 \(C\) 是一个半径 \(\delta\)、locality

\[
Q=O\!\left(q\gamma^{-2}\right)
\tag{NB3}
\]

的普通（非 relaxed）LDC。特别地，任何适用于该 \(Q\)、字母表、距离和半径参数的
外部 LDC 长度下界，都直接适用于该 proof map。

## 证明

先由完备性和错误分支界得到 proof image 的相对距离大于 \(\rho\)：若
\(\operatorname{dist}(C(m),C(m'))\le\rho\)，选取 \(m_i\ne m'_i\)，以 \(m'\) 为目标时，
同一个分支 \(V_{i,m_i'}\) 在 \(C(m')\) 上既至少接受 \(\alpha\)，又至多接受
\(\beta\)，矛盾。

请求坐标 \(i\) 后，独立运行两个分支，并各重复
\(R=\Theta(\gamma^{-2})\) 次。令
\[
\theta=\beta+\gamma/2.
\]
若某一分支的经验接受率超过 \(\theta\)，输出其声明；若没有恰有一个分支超过
阈值，则输出任意固定 bit。

在精确 codeword \(C(m)\) 上，正确分支的期望至少为 \(\alpha\)，错误分支至多为
\(\beta\)。在任意满足
\(\operatorname{dist}(z,C(m))\le\delta\) 的 oracle 上，错误分支仍至多为
\(\beta\)，而由 (NB1) 正确分支至少为
\[
\tau_\delta-\beta\ge\beta+\gamma.
\]
Hoeffding 界说明，取足够大的隐含常数后，正确分支超过阈值且错误分支低于阈值的
概率至少为 \(2/3\)。因此解码器在半径 \(\delta\) 内输出正确 bit 的概率至少为
\(2/3\)，没有 \(\bot\) 逃逸；总查询数为 (NB3)。

## 三查询特例与 GMWZ 参数窗口

本定理本身只把查询数变为固定的 \(Q\)，不自动保持原 verifier 的查询数 \(q\)：
阈值放大通常会把 \(q\) 乘上 \(\Theta(\gamma^{-2})\)。因此，GMWZ/AGK 的三查询 LDC
下界只能在额外保证阈值解码器确实仍为三查询时调用；不能把“原 dPCP 是三查询”
直接误写成“升级后的 LDC 也是三查询”。在该精确三查询、固定字母表、常数距离和
常数半径窗口内，外部定理给出

\[
N=\Omega\!\left(\frac{k^3}{\log^6 k}\right).
\tag{NB4}
\]

若只得到固定 \(Q>3\)，则应改用相应 \(Q\)-query LDC 下界，不使用 (NB4)。

## 反命题：近线性候选必须暴露 bottom

设 \(q\) 固定、\(\alpha-\beta\ge\gamma_0>0\)。对任意固定
\(0<\gamma_*<\gamma_0\)，若 \(\tau_\delta\ge2\beta+\gamma_*\)，则上面的构造给出
固定查询数 \(Q_*=O(q\gamma_*^{-2})\) 的普通 LDC。因此，只要某个 family 的长度
低于适用于 \(Q_*\) 的外部 LDC 下界，就必有

\[
\tau_\delta<2\beta+\gamma_*.
\]

若该长度缺口对每个固定 \(\gamma_*>0\) 都持续，令 \(\gamma_*\downarrow0\) 即得
\(\limsup\tau_\delta\le2\beta\)。换言之，任何低于普通 LDC 长度下界的
simultaneous coordinate-robust family，都必须存在某个目标、坐标和近邻 proof，使两个
claim branches 的总接受质量接近错误分支上界；它不能仅靠改进抽样或重复标签来消除
\(\bot\)。

## 逃逸边界

本定理不适用于：

* 只有 codeword 点 soundness、没有正半径近邻量词；
* 允许不同坐标使用不同 proof/address space；
* \(\tau_\delta\le2\beta\)，即 verifier 可以在近邻 proof 上同时拒绝两个声明；
* 查询数、字母表或半径随 \(k\) 离开外部 LDC 下界的固定参数窗口。

因此它不是对一般 dPCP 的无条件不可能性，而是一个精确的 **relaxation dichotomy**：
若不允许 bottom，进入普通 LDC；若想保留 near-linear RLDC 型长度，必须证明 bottom
质量是结构性必要的，并且仍能维持同一 global proof 与 target-relative soundness。

## 证据边界

定理 (NB1)--(NB3) 是阈值化和 Hoeffding 界的自足推导；(NB4) 仅调用外部三查询
LDC 长度下界，见 [GMWZ/AGK Theorem 1.10](https://eccc.weizmann.ac.il/report/2025/217/)。
它与 [Weighted distributional-to-RLDC barrier](weighted-distributional-to-rldc-barrier.md)
互补：后者说明加权平均界进入 RLDC，本文说明只要近邻上存在双分支总质量，就进一步
进入普通 LDC。
