# RW 固定 history 的 JK 容量预算定理

## 定理地位

这是一个 RW-specific 的、无条件的路线边界：它只约束把**同一条实际 canonical
history** 的连续 blocks 当作 JK tree 的 leaf tuples 的 forcing。它不声称所有
ACRR、所有 PCP，或带有额外压缩 oracle 的 JK 变体都不可能。

## 固定 history 的窗口上界

令 `Pi` 是一个固定的二进制 proof，长度为 `L`；令 JK 的 block 宽度为 `2q`，并令
`h>=0`。一个 aligned depth-`h` tuple 是由 `2^h` 个连续、按 `2q` 对齐的 blocks
组成的窗口。其起点完全决定该 tuple，因此窗口数满足

```text
|T_h(Pi)| <= max(0, floor(L/(2q)) - 2^h + 1) <= L/(2q).
```

这个上界已经包含 proof 中的所有部分（systematic witness、computation trace 和
auxiliary PCP bits）；只取其中一个区段只会减少窗口数。于是任何要求同一条实际
history 提供超过 `2^q` 个 distinct depth-`h` tuples 的 JK-capacity forcing，都必须满足

```text
L > 2q * 2^q.
```

证明只有位置计数：连续窗口由起始位置注入，重叠窗口也不会增加上界。它不依赖
preimage selector、lexicographic choice、RM degree 或 proof 内容。

## RW 参数推论

在第 `i` 阶段写

```text
q_i = n_{i+1},
T_i = max(2^(c D^i n_0), q_i),
L_i <= T_i^a,
```

其中 `a,c` 为固定常数，且 `q_i=n_0^(C^(i+1))`、`C>D+1`。在稳定区 `T_i=q_i` 时，
`log L_i=O(log q_i)=o(q_i)`。在早期区，
`log T_i=O(D^i n_0)` 而 `q_i=n_0^(C^(i+1))`，所以同样有
`log L_i=O(log T_i)=o(q_i)`。因此

```text
L_i <= 2^(o(q_i)) << 2 q_i 2^(q_i).
```

故 RW Theorem 3.5 给出的单条 canonical history，在这些参数下不可能仅凭实际
aligned windows 供应 JK tree-capacity 所需的 `>2^(q_i)` 个 distinct tuples。

## 内容与复杂度的边界

该定理只排除“位置/tuple 数量”足以触发容量反证的路线。它不排除：

* 一个额外的 succinct whole-tree labeler 或 compressed tuple oracle；
* 不把所有 tuples 展开为实际 history windows 的新 JK theorem；
* 某个具体 canonical history 的独立 circuit lower bound。

相反，systematic RM 表示、局部 self-correction、auxiliary proof bits 或“存在很多
候选 accepted histories”都不能替代实际窗口数。候选 proof 家族不是 RW 归纳中同一条
canonical history；把它们合并需要新的统一选择和 parent-closure 定理。

## 与下一阶段 hard threshold 的附加预算

若固定 proof 的 truth-table circuit complexity 只是硬编码上界
`O(L log(L+2))`，而下一 JK hard threshold 为
`S=Theta(|G_q| log(T+2))`，则

```text
L log(L+2) < S
```

时该 proof 连长度上都不可能进入 hard 分支；反向不等式也只是必要条件，不保证
canonical proof 真正 hard。这个 threshold 预算与 tuple-capacity 预算是两条独立的
必要条件，不能把 proof 长度足够误读成 circuit lower bound。

## 证据边界

RW Theorems 3.4--3.5 的具体编码、auxiliary proof 长度和上述 `L_i<=T_i^a` 记账见
[note 166](../../mcsp-hardness-magnification/notes/166-computation-witness-does-not-transfer-hardness-across-rw-scales-2026-08-15.md)。
本文件把其中位置计数抽成独立定理，明确区分 actual-history 结论与 whole-family
capacity/no-go，避免把后者误报为前者。
