# Face-separable patchability obstructs unique decoding

This statement gives a source-facing obstruction for the projection
direct-product amplifier used in [GMWZ Section 6](https://arxiv.org/html/2512.12960#S6). It is stronger than the
black-box observation that heavy clusters may be arbitrary: it supplies an
explicit near-satisfying assignment whenever two complete base assignments can
be glued through a common right-face labeling. The statement is conditional; it
does not claim that the published HDX parameters force the hypotheses.

## Setup

Let \(X(k)\) and \(X(s)\) be the left and right levels of a projection
direct-product system, with edges \(B\subseteq A\). A left label on \(A\) is a
map \(A\to\Sigma\), and a right label on \(B\) is a map \(B\to\Sigma\). The
direct-product constraint on an edge is restriction:

\[
  T_1[A]|_B=T_2[B].
\tag{FP1}
\]

Let \(F_0,F_1:X(1)\to\Sigma\) be two perfect assignments of the base udPCP,
decoding (with the source's complete decoding distribution) to words
\(w_0,w_1\). Let \(U_0,U_1\subseteq X(k)\) be disjoint left-face families and
let \(H:X(1)\to\Sigma\) be a vertex labeling such that

\[
  H|_A=F_i|_A\qquad(A\in U_i,\ i\in\{0,1\}).
\tag{FP2}
\]

The condition is deliberately face-local: \(H\) need not be a satisfying base
assignment. Let \(\mu_i\) be the left-face mass of \(U_i\), and write
\(\mu_*:=1-\mu_0-\mu_1\).

For the output distribution of the direct-product decoder, define

\[
  \theta_i(t):=
  \Pr[ A\in U_i\mid \text{the decoded coordinate is }t ],
\qquad
  \Gamma_{01}:=\frac1{|I|}\sum_{t\in I}
     \mathbf 1[w_{0,t}\ne w_{1,t}]\min\{\theta_0(t),\theta_1(t)\}.
\tag{FP3}
\]

Here \(I\) is the output-coordinate set. In the common case where the left-face
event is independent of the base decoding coordinate, \(\Gamma_{01}=
\min\{\mu_0,\mu_1\}\operatorname{dist}(w_0,w_1)\).

## Proposition (face-separable patching)

Assume every left label used below is a valid symbol of the direct-product
alphabet. Set

\[
  T_1[A]=
  \begin{cases}
    F_0|_A,&A\in U_0,\\
    F_1|_A,&A\in U_1,\\
    L_A,&A\notin U_0\cup U_1,
  \end{cases}
  \qquad
  T_2[B]=H|_B,
\tag{FP4}
\]

where \(L_A\) is any valid left label. Then:

1. every edge with \(A\in U_0\cup U_1\) satisfies (FP1) exactly;
2. the global direct-product violation is at most \(\mu_*\);
3. the decoded output of the patched assignment has distance at least
   \(\Gamma_{01}\) from every single word \(w\in\{0,1\}^{I}\).

Consequently, if the amplified system claims unique-decoding soundness error
\(\eta_{\rm out}\) below a satisfaction threshold \(\varepsilon_{\rm out}\) and

\[
  \mu_*\le \varepsilon_{\rm out}
  \qquad\text{and}\qquad
  \Gamma_{01}>\eta_{\rm out},
\tag{FP5}
\]

then the exact projection amplifier cannot have that unique-decoding guarantee.

## Proof

For \(A\in U_i\) and \(B\subseteq A\), (FP2) gives
\(T_1[A]|_B=F_i|_B=H|_B=T_2[B]\). Thus only left faces outside
\(U_0\cup U_1\) can contribute a violated sampled edge, proving the first two
claims.

On a decoder sample whose left face lies in \(U_i\), the local symbol is exactly
\(F_i|_A\). Base perfect completeness therefore makes the decoded bit equal to
\(w_{i,t}\) with probability one. Fix a coordinate \(t\) with
\(w_{0,t}\ne w_{1,t}\). For any proposed bit \(w_t\), one of the two clusters is
wrong, and its conditional mass is at least
\(\min\{\theta_0(t),\theta_1(t)\}\). Averaging over \(t\) gives the lower bound
\(\Gamma_{01}\); samples outside the two clusters can only add error. Condition
(FP5) contradicts unique-decoding soundness. \(\square\)

## Random face-splitting test

Let \(D=\{u:F_0(u)\ne F_1(u)\}\). A useful way to search for (FP2) is to
randomly split \(D=R\sqcup S\), set \(H=F_0\) on \(R\cup D^c\) and \(H=F_1\) on
\(S\), and take

\[
  U_0=\{A:A\cap S=\varnothing\},
  \qquad
  U_1=\{A:A\cap R=\varnothing,\ A\cap S\ne\varnothing\}.
\tag{FP6}
\]

Then (FP2) holds identically. If a random \(k\)-face contains \(d\) points of
\(D\), a fair random split contributes expected masses

\[
  \mathbb E[\mu_0]=\mathbb E[2^{-d}],
  \qquad
  \mathbb E[\mu_1]=\mathbb E[2^{-d}\mathbf 1_{d>0}],
  \qquad
  \mathbb E[\mu_*]=\mathbb E[(1-2^{1-d})\mathbf 1_{d>0}].
\tag{FP7}
\]

These identities do not by themselves prove a GMWZ obstruction: for large
\(k\) and a dense disagreement set \(D\), both one-color face masses can be tiny.
They give a concrete source-specific experiment. The remaining measurable gate is
whether the actual HDX/direct-product sampler simultaneously has
\(\mu_*\le\varepsilon_{\rm out}\) and \(\Gamma_{01}>\eta_{\rm out}\).

## A positive gate: face-avoidance sampling

The complete-complex calculation suggests a converse route. Say that the
\(X(1)\to X(k)\) sampler has \((\varepsilon_{\rm fa},k)\)-face-avoidance if,
for every disjoint vertex sets \(R,S\), with
\(r=\mu_1(R)\) and \(s=\mu_1(S)\),

\[
\begin{aligned}
\Pr[A\cap S=\varnothing]&\le e^{-ks}+\varepsilon_{\rm fa},\\
\Pr[A\cap R=\varnothing,\ A\cap S\ne\varnothing]
&\le ks\,e^{-(k-1)r}+\varepsilon_{\rm fa}.
\end{aligned}
\tag{FP8}
\]

The complete uniform \(k\)-subset sampler has \(\varepsilon_{\rm fa}=0\) (up to
the usual finite-population improvement). Under (FP8), the random-split patch
(FP6), with a coordinate-independent decoder marginal, obeys

\[
\Gamma_{01}
\le \operatorname{dist}(w_0,w_1)
\left(\frac{4}{k}+\varepsilon_{\rm fa}\right).
\tag{FP9}
\]

Indeed, put \(x=kr\) and \(y=ks\). The two inequalities in (FP8) give
\[
\min\{\mu_0,\mu_1\}
\le \min\{e^{-y},\,y e^{-(1-1/k)x}\}+\varepsilon_{\rm fa}
\le \sqrt y\,e^{-(x+y)/4}+\varepsilon_{\rm fa}.
\]
Since \(r+s=(x+y)/k\) and
\(\sup_{z\ge0}z^{3/2}e^{-z/4}<4\), multiplying by
\(\operatorname{dist}(w_0,w_1)\le r+s\) proves (FP9). The latter inequality
holds because every base decoding vertex for a coordinate on which the two
words differ must lie in the disagreement set \(D=R\sqcup S\). Thus a proof of
(FP8) with
\(\varepsilon_{\rm fa}=o(1)\) and \(k\) larger than the target UD-error scale
would rule out this entire face-separable patch family as a source of constant
unique-decoding failure.

The published GMWZ HDX theorem states inclusion-graph singular values and a
direct-product-test guarantee, but does not state (FP8). Therefore (FP8) is a
precise new source-level target, not an automatic consequence of the current
theorem.

## A source-level spectral gate for the random split

The random split admits a weaker but unconditional gate from the published
inclusion spectrum. Let `lambda_k` be the second singular value of the weighted
inclusion graph `X(1) <-> X(k)`. Assume the complete decoding distribution has
uniform `t`-marginal and uniform `X(k)`-marginal on the left faces, and that the
base decoding vertex marginal is the stationary `X(1)` marginal, as in the
Section 6 construction. Also assume that the two base perfect assignments are
decoded through the same deterministic base maps. Then the random split (FP6)
obeys

```
Gamma_01 <= sqrt(2) lambda_k.                                      (FP10)
```

To prove this, write `mu_i = mu(U_i)`. Since `U_0` avoids `S`, the inclusion
edge measure between `U_0` and `S` is zero. The expander-mixing inequality
therefore gives `mu_0 s <= lambda_k sqrt(mu_0 s)`, hence
`mu_0 <= lambda_k^2/s` when `s>0`. Likewise `U_1` is contained in the family
of faces avoiding `R`, so `mu_1 <= lambda_k^2/r`. Put
`a = max{r,s}`. Uniformity of the two marginals implies

```
Gamma_01 <= min{dist(w_0,w_1), (r+s) lambda_k^2/a}
          <= min{dist(w_0,w_1), 2 lambda_k^2}.                       (FP11)
```

If the two base words differ at coordinate `t`, every base decoding vertex in
the support for `t` must lie in `D={u:F_0(u) != F_1(u)}`; otherwise the
deterministic decoder would output the same symbol for both assignments. Thus
`dist(w_0,w_1) <= mu_1(D) = r+s <= 2a`. Optimizing
`min{dist(w_0,w_1),2 lambda_k^2}` proves (FP10). This uses only the published
second-singular-value statement, not (FP8).

For the GMWZ family, Theorem 2.9 gives lambda_k = 1/k + k^{O(1)}/d, and the
Section 6 parameter choice makes this O(1/k). Consequently the random
face-splitting patch cannot create a constant unique-decoding error once k is
larger than the target constant-error scale, even if its outside-face mass is
small. The remaining open obstruction is therefore not this random split but a
patch whose face events are not controlled by the global inclusion marginal (or
a genuinely cross-coordinate assignment).

## A smooth-decoder refinement

The residual source question can be isolated as a conditional-density parameter.
Suppose, for some \(\kappa\ge1\), that the decoder-conditioned face masses obey
\(\theta_i(t)\le\kappa\mu_i\) for \(i\in\{0,1\}\) and all \(t\). Then the
same spectral argument gives \(\Gamma_{01}\le2\kappa\lambda_k^2\). Indeed,
\(\Gamma_{01}\le\operatorname{dist}(w_0,w_1)\kappa\min\{\mu_0,\mu_1\}\),
while (FP11) gives \(\min\{\mu_0,\mu_1\}\le\lambda_k^2/\max\{r,s\}\) and
base perfect decoding gives \(\operatorname{dist}(w_0,w_1)\le r+s\le2\max\{r,s\}\).

The agnostic-decoding condition in the GMWZ source is a statement about the
left-face distribution after conditioning on a right face and does not by itself
imply this smoothness condition. Thus bounded kappa is the exact remaining
distributional-soundness gate: either prove it for the actual decoder, or
construct a coordinate-concentrated face event forcing kappa to be large.

## Full face-separable spectral closure

The same argument in fact does not require the random split. Return to any
face-separable patch satisfying (FP2), and define

\[
  E_i:=\{u\in X(1):H(u)\ne F_i(u)\},\qquad i\in\{0,1\}.
\tag{FP15}
\]

Every face in \(U_i\) avoids \(E_i\). Hence the inclusion-mixing inequality gives

\[
  \mu(U_i)\le \lambda_k^2/\mu_1(E_i)
\tag{FP16}
\]

whenever \(\mu_1(E_i)>0\). Moreover \(E_0\cup E_1\) contains the base
disagreement set \(D=\{u:F_0(u)\ne F_1(u)\}\). If
\(\delta=\operatorname{dist}(w_0,w_1)\), deterministic perfect base decoding
implies \(\delta\le\mu_1(D)\le\mu_1(E_0)+\mu_1(E_1)\). With
\(a=\max_i\mu_1(E_i)\), this gives \(a\ge\delta/2\). Uniform \(t\)- and
left-face marginals imply

\[
  \Gamma_{01}
  \le \min\{\delta,\mu(U_0),\mu(U_1)\}
  \le \min\{\delta,2\lambda_k^2\}
  \le \sqrt2\,\lambda_k .
\tag{FP17}
\]

Thus the published \(X(1)\leftrightarrow X(k)\) spectrum closes the entire
face-separable patchability class at constant error for the GMWZ parameter
regime, not merely the random split. Any remaining source-specific
unique-decoding obstruction must therefore use a right labeling that is not a
common vertex word, or a genuinely cross-coordinate/global assignment that is
not captured by (FP2).

## Collision gate for arbitrary right labels

The same disagreement mechanism yields a broader conditional obstruction that
does not assume the right label is a restriction of any vertex word. Let
\(\nu\) be the marginal distribution of right faces \(B\), let
\[
  p_i(B):=\Pr[A\in U_i\mid B],\qquad \mu_i:=\Pr[A\in U_i],
\tag{FP18}
\]
and let \(D=\{u:F_0(u)\ne F_1(u)\}\). Assume that on \(U_i\) the left label is
\(F_i|_A\), while the right label \(T_2[B]\) is arbitrary. Write
\[
  \rho:=\Pr_{B\sim\nu}[B\cap D=\varnothing].
\]
Suppose the two incidence profiles satisfy
\[
  \mathbb E_\nu[(p_i-\mu_i)^2]\le\eta^2\mu_i
  \qquad(i=0,1).
\tag{FP19}
\]
Then the projection violation contributed by the two clusters is at least
\[
  \frac{\min\{\mu_0,\mu_1\}}2
  \left[1-\rho-4\eta^2
  \left(\frac1{\mu_0}+\frac1{\mu_1}\right)\right]_+ .
\tag{FP20}
\]

Indeed, on every \(B\) meeting \(D\), the restrictions \(F_0|_B\) and
\(F_1|_B\) differ, so an arbitrary single right label can agree with at most
one of the two cluster restrictions. The set where \(p_i(B)<\mu_i/2\) has
\(\nu\)-mass at most \(4\eta^2/\mu_i\) by (FP19). Outside those two exceptional
sets and the \(\rho\)-mass of faces avoiding \(D\), the conflict probability is
at least \(\min\{\mu_0,\mu_1\}/2\), proving (FP20).

This reduces the non-vertex-word route to a concrete HDX calculation. If
\(\delta=\operatorname{dist}(w_0,w_1)\), perfect base decoding gives
\(\mu_1(D)\ge\delta\), and the published \(X(1)\leftrightarrow X(s)\) spectrum
further gives
\[
  \rho\le\lambda_s^2/\delta
\tag{FP21}
\]
for right faces of size \(s\). Thus a small \(X(k)\leftrightarrow X(s)\)
incidence parameter \(\eta\) would rule out arbitrary-right-label
two-cluster patches, not only the common-vertex-word subclass. GMWZ Theorem 2.9
does not state this \(X(k)\leftrightarrow X(s)\) \(L_2\)-profile, so (FP19) is a
precise new distributional-soundness/HDX target rather than an automatic source
consequence.

## Scope

The proposition is an exact obstruction for the projection amplifier under its
face-separable patchability hypothesis. It is not a consequence of Lemma 6.2's
heavy-cluster density and outside-union clauses alone, and it does not assert that
GMWZ's computation-generated assignment satisfies (FP2). Proving (FP5) for a
natural family of base instances would give a source-specific unique-decoding
separation; proving that every such split has either large \(\mu_*\) or small
\(\Gamma_{01}\) is a concrete route toward a UD-preserving theorem.

The source facts used here are only that the amplified constraint graph is the
inclusion graph with projection constraints, its left labels are maps on the
left face, and perfect base assignments decode pointwise to their complete words;
these are stated in Theorem 6.1 and the construction immediately following it.
