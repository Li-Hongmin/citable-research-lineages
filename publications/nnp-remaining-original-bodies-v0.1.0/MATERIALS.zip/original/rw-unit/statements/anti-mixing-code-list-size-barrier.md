# Anti-mixing codes cannot hide a growing unlabelled list

## Theorem

Let

\[
  E:[M]\longrightarrow \Sigma^N,\qquad q:=|\Sigma|\ge 2,
\]

be an injective \(q\)-ary code, and let
\(\boldsymbol w=(w_1,\ldots,w_N)\) be any probability distribution on
\([N]\). For a target \(x\in[M]\) and an
\(L\)-element list \(S\subseteq[M]\setminus\{x\}\), define

\[
  u_E(x,S)
  :=
  \sum_{\substack{j\in[N]:\\
      E(x)_j\notin\{E(s)_j:s\in S\}}} w_j .
\]

Assume that \(0<\gamma\le 1\), \(1\le L\le M-1\),
\(M\ge 8q/(3\gamma)\), and

\[
  u_E(x,S)\ge\gamma
  \qquad
  \text{for every }x\in[M]\text{ and every }S\subseteq[M]\setminus\{x\},
  \ |S|=L.
\tag{AM1}
\]

Then

\[
  L
  \le
  \frac{8q}{3\gamma}\log\frac4\gamma .
\tag{AM2}
\]

Consequently, for fixed alphabet and fixed \(\gamma>0\), no code of
any length and no coordinate distribution can be anti-mixing against
lists whose size grows beyond a constant multiple of
\(q\log(1/\gamma)/\gamma\). The uniform-coordinate statement is the
special case \(w_j=1/N\).

## Proof

Fix a target \(x\) and a coordinate \(j\), and write

\[
  d_j(x)
  :=
  \left|
    \{s\in[M]\setminus\{x\}:E(s)_j=E(x)_j\}
  \right|.
\]

Choose \(S\) uniformly among the \(L\)-subsets of
\([M]\setminus\{x\}\). The probability that coordinate \(j\) is
uncovered is

\[
 \frac{\binom{M-1-d_j(x)}{L}}{\binom{M-1}{L}}
 \le
 \left(1-\frac{d_j(x)}{M-1}\right)^L .
\tag{AM3}
\]

Put \(a:=\log(4/\gamma)\). If \(L<2a\), the claimed bound is
immediate. Hence assume \(L\ge2a\). Call \(j\) low for \(x\) if
\[
  d_j(x)<\frac{a(M-1)}L.
\]
If \(j\) is not low, (AM3) is at most \(e^{-a}=\gamma/4\).
By (AM1), the expectation over the random list \(S\) of
\(u_E(x,S)\) is at least \(\gamma\). If \(\theta_x\) is the fraction
of the weight \(\boldsymbol w\) on low coordinates for \(x\), then

\[
  \gamma
  \le \theta_x+(1-\theta_x)\frac{\gamma}{4},
\]
so
\[
  \theta_x\ge \frac{3\gamma}{4-\gamma}\ge\frac{3\gamma}{4}.
\tag{AM4}
\]

Now fix a coordinate \(j\). Its \(M\) code symbols form at most \(q\)
symbol classes. A target \(x\) in a class of size \(c\) is low only if
\[
  c-1<\frac{a(M-1)}L,
\]
and hence the number of low targets at coordinate \(j\) is at most

\[
  q\left(1+\frac{a(M-1)}L\right).
\tag{AM5}
\]

Summing (AM4) over all targets and taking the \(\boldsymbol w\)-weighted
sum over coordinates gives

\[
  \frac{3\gamma}{4}M
  \le
  q\left(1+\frac{a(M-1)}L\right).
\]
Since \(M\ge 8q/(3\gamma)\), rearranging yields

\[
  L
  \le
  \frac{8qa}{3\gamma}
  \le
  \frac{8q}{3\gamma}\log\frac4\gamma .
\]

\square

## Interpretation for list-based dPCP composition

Suppose a proposed conversion sees only the coordinatewise projection

\[
  \{E(s)_j:s\in S\}
\]

of an unlabelled list and has no cross-coordinate index, common
strategy, or global consistency test. To force a target \(E(x)\) from
every list \(S\) not containing \(x\), the conversion must have an
anti-mixing property of the form (AM1): on a positive fraction of
the coordinate distribution, no list word may provide the target
symbol. Otherwise a coordinatewise phantom word can agree with the
target on every tested symbol while remaining fully compatible with the
list projection.

The theorem therefore gives a black-box-level combinatorial filter:

* fixed \(q\), constant \(\gamma\), and \(L=k^{\Omega(1)}\) cannot be
  repaired by choosing a longer outer code;
* a successful unlabelled-list route must let \(\gamma\) decay, grow the
  alphabet, restrict the admissible target/list family, or add an
  indexed/global consistency channel;
* the last option is exactly the indexed-list target of Theorem 3.8
  and the robust-index barrier of Corollary 3.11, rather than a
  consequence of ordinary list soundness.

This is a lower bound for the **coordinatewise-list black-box model**.
It does not claim that every dPCP with list soundness admits a phantom
assignment realizing every coordinatewise mixing word. A verifier with
genuine cross-coordinate constraints may escape the model; proving such
a mechanism is precisely the remaining positive target.

## Relation to the project

For GMWZ-style \((L,\varepsilon)\)-list soundness, the list is
unlabelled and the soundness event is defined through coordinatewise
projections. The theorem shows that an outer-code-only repair cannot
turn \(L=k^{\Omega(1)}\) into a constant-quality singleton target over a
fixed alphabet. Thus the positive route must construct an indexed,
globally consistent list (or an essentially different target-binding
predicate), while the negative route can target this entire
coordinatewise-list black-box class.

The result is elementary and independent of the relaxed-LDC lower
bound. It is complementary to the existing list-to-ACRR dichotomy:
that dichotomy controls the global exception budget, whereas (AM2)
quantifies the alphabet/list-size obstruction even when the proof
length is allowed to grow.
