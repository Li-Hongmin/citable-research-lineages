# Indexed-label locality barrier

## Theorem

Let \(\Pi^{(s)}\in\Sigma^N\), \(s\in[L]\), be proofs in one common address space. Fix an
output coordinate \(i\). Let \(D_i\) be a target-independent adaptive decoder that uses at
most \(q\) proof queries and, after seeing its random tape and the answer transcript, outputs
an index in \([L]\) (it may also output a symbol in a separate alphabet). Suppose that indexed
completeness holds with probability at least \(\alpha\):

\[
  \Pr_\omega\bigl[D_i^{\Pi^{(s)}}(\omega)\text{ outputs index }s\bigr]
  \ge \alpha
  \qquad(s\in[L]).
  \tag{IL1}
\]

Then

\[
  \alpha L\le |\Sigma|^q,
  \qquad\text{hence}\qquad
  q\ge \log_{|\Sigma|}(\alpha L).
  \tag{IL2}
\]

For perfect indexed completeness, \(L\le|\Sigma|^q\). In particular, a fixed-alphabet,
fixed-query indexed decoder can support only \(O(1)\) target indices. With a binary proof
alphabet and \(L=k^d\), it needs

\[
  q\ge d\log_2 k-O(1).
  \tag{IL3}
\]

## Proof

Fix a random tape \(\omega\). The decoder is now a deterministic \(|\Sigma|\)-ary decision
tree of depth at most \(q\). Its stopping transcripts are prefix-free: if one transcript
were a prefix of another, the decoder would make the same stop/continue decision after the
common prefix, which is impossible. For every target \(s\) on which the decoder outputs \(s\),
record its leaf transcript \(T_s(\omega)\). Two distinct correctly indexed targets cannot
share a leaf transcript, because the decoder would have the same output. The corresponding
prefix-free leaf set has size at most \(|\Sigma|^q\) (extend each leaf to depth \(q\) and use
disjoint descendant sets). Averaging over \(\omega\) gives

\[
  \sum_{s=1}^L
  \Pr_\omega[D_i^{\Pi^{(s)}}(\omega)\text{ outputs }s]
  \le |\Sigma|^q.
\]

Using (IL1) proves (IL2), and (IL3) is the binary specialization. \(\square\)

## Consequences for indexed-list compilation

The bound is independent of soundness and applies before the selector matrix is appended.
It is tight at the information level: when \(L\le|\Sigma|^q\), assign each target a distinct
length-\(q\) word over \(\Sigma\) in \(q\) fixed proof cells, and let the decoder read those
cells and output the corresponding index.
Therefore the selector-symbol version of an indexed-list compiler can keep its proof length
independent of \(L\) only by paying for the index in the local answer alphabet (an alphabet
of size at least \(L^{1/q}\)), by increasing locality to \(\Omega(\log L)\), or by giving the
decoder an additional target-dependent channel. Binary labels necessarily incur the
\(\lceil\log_2 L\rceil\) query/answer information recorded in the main paper's binary bound.

For example, a 2-query dPCP over a fixed alphabet can be converted to a target-independent
indexed decoder only for constant \(L\) under perfect indexed completeness. This does not
contradict ordinary list soundness: an ordinary list decoder outputs an unlabelled symbol and
never has to identify which global word produced that symbol. The conversion from ordinary
lists to the indexed-list hypothesis of Theorem 3.8 therefore requires a genuine label
channel, not merely a reordering of the list.

## Boundary

The theorem does not apply if the target index is supplied as an input to the decoder, if each
target receives an independent proof address space, or if indexed completeness is replaced by
a post-query strategy that can carry unbounded information. It is an information/locality
lower bound for a single target-independent local transcript. It does not by itself give a
proof-length lower bound, and it does not rule out a new indexed dPCP with growing alphabet,
growing query count, or a compressed global label channel.

The ordinary GMWZ list-soundness definition is deliberately weaker: it permits an unlabelled
coordinatewise projection of a global list, rather than an indexed output. See
[their dPCP definition](https://arxiv.org/html/2512.12960#L231-L247).
