# Linear binary two-query Sim-CR has a cubic LDC-length barrier

## Theorem

Let

\[
  \Pi:\mathbb F_2^k\longrightarrow\mathbb F_2^P
\]

be a linear global-proof map.  For every message coordinate `i` and claimed bit
`b`, let `V_{i,b}` be a randomized, possibly adaptive verifier making at most two
queries to a proof oracle.  Assume there are constants `0<rho<1`, `0<=alpha<=1`, and
`beta>=0` with

\[
  \beta+3(1-\alpha)<\frac12,
\tag{A}
\]

such that, for every message `m`; here `dist` denotes relative Hamming distance on
the `P` proof coordinates:

1. **Same-proof completeness:**
   \[
     \Pr[V_{i,m_i}^{\Pi(m)}=1]\ge\alpha
   \]
   for every `i`;
2. **Target-relative wrong-bit soundness:** for every proof `z` satisfying
   `dist(z,Pi(m))\le rho`,
   \[
     \Pr[V_{i,1-m_i}^{z}=1]\le beta
   \]
   for every `i`.

Then, for all sufficiently large `k`,

\[
  k+P \;\ge\; \Omega_{\rho,\,\alpha,\,\beta}\!\left(\frac{k^3}{\log^3 k}\right).
\tag{LQ2}
\]

Consequently, a binary linear Sim-CR family with two proof queries, constant positive
radius, `P=O(k\,polylog k)`, and parameters satisfying (A) cannot exist.

## Proof

First, the assumptions already force the proof map to have linear-code distance.
If `m != m'` and `dist(Pi(m),Pi(m')) <= rho`, choose `i` with `m_i != m'_i`.
Using `m` as target and `Pi(m')` as the candidate proof, wrong-bit soundness gives
acceptance at most `beta`, while completeness for `m'` gives acceptance one.  This
contradiction proves that `Pi` is injective and that its image has relative distance
strictly larger than `rho`.  Since the image is a binary linear `[P,k,d]` code,
the Singleton bound gives

\[
  k\le P-d+1 < (1-rho)P+1.
\]

For `k>=2`, therefore `P/k >= 1/(2(1-rho))`, and hence

\[
  \frac{P}{k+P}\ge \frac{1}{3-2rho}.
\tag{1}
\]

Inline the message into the proof and define

\[
  C(m)=m\,\|\,\Pi(m)\in\mathbb F_2^{N},\qquad N=k+P.
\]

Because `Pi` is linear, `C` is a binary linear code (and it is injective because
its first `k` coordinates equal `m`).

For a requested message coordinate `i`, a relaxed local decoder first queries the
single inline coordinate `y_i`.  Let the answer be `b`, and run `V_{i,b}` on the
proof suffix of `y`; output `b` if the verifier accepts and output `bottom`
otherwise.  This makes at most three adaptive queries.

On the uncorrupted codeword `C(m)`, the queried bit is `m_i` and completeness gives
output `m_i` with probability at least `alpha`.  Now suppose
`dist(y,C(m))\le delta`, where

\[
  0<delta<\frac{rho P}{k+P}.
\]

The proof suffix of `y` differs from `Pi(m)` in fewer than `rho P` positions.  If
`y_i=m_i`, the decoder can output only the correct bit or `bottom`.  If
`y_i=1-m_i`, the verifier is the wrong-bit branch, and target-relative soundness
bounds the probability of an incorrect output by `beta`.  Hence `C` is a binary
linear `(3,delta,alpha,beta)`-RLDC.

By (1), fix the positive constant
`delta_0 = rho/(2(3-2rho))`, which is strictly smaller than
`rho P/(k+P)` for all `k>=2`.  Thus the decoder is a constant-radius binary linear
`(3,delta_0,alpha,beta)`-RLDC.  Put `epsilon=1-alpha`.  Theorem 3 of
Grigorescu--Kumar--Manohar--Mon converts this into a linear
`(3,delta_0,1,beta+3epsilon)`-RLDC.  By (A), its soundness is below `1/2`; writing
`eta=1/2-beta-3epsilon>0`, Theorem 1 and Corollary 1.6 of
Grigorescu--Kumar--Manohar--Mon--[the linear RLDC/LDC paper](https://arxiv.org/abs/2511.02633)
state that every binary linear `(3,delta,1,1/2-eta)`-RLDC is a 3-query LDC and has
length

\[
  N\ge \Omega_{\delta,\eta}\!\left(\frac{k^3}{\log^3 k}\right).
\]

Substituting the decoder above proves (LQ2).

## What this closes

This is a family-level, target-relative barrier that is stronger than the generic
relaxed-LDC transfer for the linear binary two-query branch.  It does **not** use
projection constraints: adaptivity and arbitrary local predicates in `V_{i,b}` are
allowed.  The proof map only needs to be linear; the inline message prefix supplies
the extra query.

Thus the following proposed route is closed at near-linear length:

```text
binary linear proof map
+ two adaptive proof queries
+ completeness/soundness satisfying beta+3(1-alpha)<1/2
+ constant target-relative radius/soundness
--> three-query linear RLDC
--> three-query LDC
--> N = Omega(k^3/log^3 k).
```

## Scope and escape conditions

The theorem does not rule out:

* nonlinear proof maps;
* three or more proof queries (the inline decoder then has four or more queries);
* nonbinary proof alphabets;
* zero or vanishing target-relative radius;
* imperfect completeness outside condition (A);
* a single target-specific verifier without a message-family interpretation.

The external cubic lower bound is the only imported ingredient.  The
message-inline reduction and its radius accounting are proved here; no claim is
made that the result yields `P != NP` by itself.

## Sources

* [Grigorescu--Kumar--Manohar--Mon, *Relaxed vs. Full Local Decodability with Few Queries*](https://arxiv.org/abs/2511.02633), Theorems 1 and 3 and Corollary 1.6.
* [Message-inline RLDC compiler](message-inline-rldc-compiler.md).
* [Binary projection Sim-CR two-query exponential barrier](../../mcsp-hardness-magnification/notes/198-binary-projection-simcr-two-query-exponential-barrier-2026-08-16.md), for the separate nonlinear/projection `q=1` branch.
