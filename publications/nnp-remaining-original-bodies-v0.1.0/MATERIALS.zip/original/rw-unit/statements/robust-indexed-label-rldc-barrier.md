# Robust indexed labels enter the RLDC barrier

## Theorem

Let \(L=2^\ell\), and let \(\Pi^{(s)}\in\Sigma^N\) be proofs in one common address space,
indexed by \(s\in\{0,1\}^{\ell}\). Fix one output coordinate \(i_0\). Suppose a
target-independent randomized decoder \(I\) makes at most \(q\) proof queries and outputs
either an index \(s'\in\{0,1\}^{\ell}\) or \(\bot\). Assume that for fixed constants
\(\alpha>\beta\) and \(\rho>0\):

1. **Indexed completeness:** on \(\Pi^{(s)}\), \(I\) outputs \(s\) with probability at
   least \(\alpha\);
2. **Target-relative robust label soundness:** for every \(z\) with
   \(\operatorname{dist}(z,\Pi^{(s)})\le\rho\), the probability that \(I^z\) outputs an
   index \(s'\notin\{s,\bot\}\) is at most \(\beta\).

Then \(C(s):=\Pi^{(s)}\) has a raw positive-radius \(q\)-query relaxed decoder for the
\(\ell\)-bit message \(s\): the honest-bit probability is at least \(\alpha\), while a
wrong bit on a \(\rho\)-near word has probability at most \(\beta\). If the weak
constant-success RLDC convention is required, independent repetition and thresholding give
locality
\[
  Q=O\!\left(q(\alpha-\beta)^{-2}\right)
\]
with the same positive radius and fixed constant completeness/soundness. Thus every applicable
fixed-parameter relaxed-LDC lower bound for locality \(Q\), alphabet \(\Sigma\), and radius
\(\rho\) applies to \(N\), provided its completeness convention matches this weak decoder
(or \(\alpha=1\) is imposed when perfect completeness is required).

There is also a message-inline upgrade. In the binary case define

\[
  \widehat C(s):=s\,\|\,\Pi^{(s)}\in\{0,1\}^{\ell+N}.
\]

The raw inline decoder first reads the requested inline bit, then runs \(I\) on the proof
suffix, and returns that bit only when the reported index has the same bit; otherwise it
returns \(\bot\). This uses \(q+1\) queries. After the same threshold amplification, it has
locality \(Q+1\). Its radius is any \(\delta<\rho N/(\ell+N)\), since a \(\delta\)-near inline
word has a proof suffix within \(\rho\) of \(\Pi^{(s)}\). Thus a lower bound for the
\((Q+1)\)-query binary RLDC applies to \(\ell+N\), not automatically to \(N\) alone.

If the lower-bound window gives

\[
  N\ge \ell^{\,1+\eta(Q,\Sigma,\alpha-\beta,\rho)}
\]

for some \(\eta>0\), then a robust indexed label channel with \(L=2^\ell\) cannot have
shorter proof length in that window. If the proof alphabet is binary, \(q=1\), perfect
indexed completeness holds, and \(\beta\le1/3\), the raw message-inline decoder is a binary
2-query RLDC; an applicable exponential 2-query theorem then gives

\[
  \ell+N\ge 2^{\Omega(\ell)}=L^{\Omega(1)},
\]

not an unconditional lower bound on \(N\) without the inline construction.

## Proof

Define a decoder for message bit \(j\in[\ell]\) by running \(I\). If \(I\) outputs an index
\(s'\), return its \(j\)-th bit; if it outputs \(\bot\), return \(\bot\). The decoder makes
the same \(q\) proof queries. On the honest proof \(\Pi^{(s)}\), it returns the correct bit
whenever \(I\) outputs \(s\), so completeness is at least \(\alpha\). For a word \(z\) in
the \(\rho\)-neighborhood of \(\Pi^{(s)}\), a wrong bit can be returned only if \(I\) outputs
some non-\(\bot\) index \(s'\) whose \(j\)-th bit differs from \(s\); this event is contained
in the wrong-index event from assumption 2 and has probability at most \(\beta\). Thus the
bit decoder is a relaxed local decoder with the stated parameters.

To put this in the usual constant-success format, repeat \(I\) independently
\(R=\Theta((\alpha-\beta)^{-2})\) times. For a requested bit, count the outputs carrying
bit \(0\) and bit \(1\), ignore \(\bot\), and output \(b\) only when its empirical frequency
is the unique one exceeding \(\theta=(\alpha+\beta)/2\); otherwise output \(\bot\). On the honest proof the
correct-bit mean is at least \(\alpha\), while on every \(\rho\)-near proof the wrong-bit
mean is at most \(\beta\). Hoeffding's inequality gives the claimed constant
completeness/soundness with \(Q=O(q(\alpha-\beta)^{-2})\) proof queries.

The proof map also has distance \(>\rho\). If
\(\operatorname{dist}(\Pi^{(s)},\Pi^{(t)})\le\rho\) for \(s\ne t\), use \(\Pi^{(t)}\) as a
candidate word under target \(s\). Indexed completeness for \(t\) accepts index \(t\) with
probability at least \(\alpha\), while robust soundness for \(s\) allows only \(s\) or
\(\bot\) except with probability \(\beta\), contradicting \(\alpha>\beta\). Hence the
resulting code has the positive radius required by the relaxed-LDC theorem. Moreover, for
\(|\Sigma|\ge2\), if \(d\) is its integer minimum distance, the q-ary Singleton bound gives
\[
  2^\ell\le|\Sigma|^{N-d+1},
  \qquad
  N>\frac{\ell/\log_2|\Sigma|-1}{1-\rho}.
\]
This linear information bound is independent of the external relaxed-LDC theorem. \(\square\)

For completeness, consider the inline code in the binary case. On
\(\widehat C(s)=s\|\Pi^{(s)}\), the inline bit and the reported index agree whenever \(I\)
outputs \(s\), so the decoder succeeds with probability at least \(\alpha\). On a
\(\delta\)-near word, if it outputs a wrong bit then the inline bit differs from \(s_j\) and
the reported index differs from \(s\); the latter event has probability at most \(\beta\).
The proof suffix is within relative distance \(\rho\) whenever
\(\delta<\rho N/(\ell+N)\). Distinct inline codewords inherit proof distance
>\(\rho N\), so their relative distance is \(>\rho N/(\ell+N)\), consistent with the same
radius. For non-perfect \(\alpha\) or a smaller gap, apply the same independent repetitions
and thresholding to the index-bit outputs; this changes the raw \(q+1\) locality to \(Q+1\).

## Interpretation and boundary

This is a label-channel reduction, not a new lower bound for ordinary list soundness. It
applies only when the same target-independent decoder must robustly identify the target index
inside one common proof space. Theorem 3.8 does not automatically satisfy this hypothesis:
its indexed list may permit another list word \(y_a\) to explain a nearby proof, and selector
consistency alone does not force the output index to remain the honest target \(s\).

For \(L=k^d\), the message length is only \(\ell=\Theta(\log k)\), so this RLDC consequence
may be weaker than the locality bound \(\ell\le q\log_2|\Sigma|\). It becomes a substantial
proof-length obstruction when the indexed family has \(\ell=\Omega(k)\) bits of target
entropy: in the binary \(q=1\) inline window, the exponential 2-query lower bound then gives
\(N\ge 2^{\Omega(k)}\) up to the additive \(\ell\)-bit prefix. The two bounds form a clean
trilemma: fixed local transcripts limit \(L\), robust labels enter the RLDC/LDC barrier, and a successful construction must either weaken robust
index binding or add a new global channel.

The statement is a direct specialization of the proof-only/message-inline RLDC compiler; it
is recorded separately because the indexed candidate label is the specific missing interface
in the current dPCP route. The distinction between the direct \(q\)-query statement and the
message-inline \(q+1\)-query statement is essential when invoking a query-specific lower bound.

## Sources

* [Dall'Agnol--Gur--Lachish, TR20-154](https://eccc.weizmann.ac.il/report/2020/154/)
* [Block et al., Exponential Lower Bounds for 2-query RLDCs](https://arxiv.org/abs/2602.20278)
