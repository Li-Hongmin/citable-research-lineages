# Short-key ACRR with logarithmic randomness cannot cover an NEXP-hard language

## Theorem

It is enough to consider one language `L` that is `NEXP`-hard under polynomial-time
many-one reductions. For every input `x` of length `n`, suppose a uniform compiler
supplies:

* a key `s` of length `poly(n)`;
* a deterministic polynomial-time random-access evaluator
  `E_L(x,s,a)` for every proof address `a` of length `poly(n)`;
* a verifier `V_L(x,s;r,tau)` running in `poly(n)` time, where `r` has `O(log n)` random
  bits, `tau` is an optional response of length `poly(n)`, and every proof query is
  answered through `E_L`.

Assume the usual fixed-gap semantics

```text
x in L     => exists s  Pr_r[exists tau: V_L(x,s;r,tau)=1] >= 2/3,
x not in L => for every s  Pr_r[for all tau: V_L(x,s;r,tau)=0] >= 2/3.
```

Then this compiler cannot exist. In fact, it would imply `NEXP subseteq NP`, which
contradicts the nondeterministic time hierarchy theorem.

## Proof

Because `r` has `O(log n)` bits, all random strings can be enumerated in polynomial
time. Given `x`, an NP machine guesses `s` and, for every random string `r`, one
polynomial-length response `tau_r`. It evaluates `V_L(x,s;r,tau_r)` for every `r` and
accepts exactly when at least two thirds of the trials accept. The whole response table
has polynomial length, and the evaluator `E_L` is deterministic polynomial time, so
this is an NP computation with no hidden oracle.

The completeness and soundness inequalities therefore decide `L` in NP. Since `L` is
`NEXP`-hard, this gives `NEXP subseteq NP`.

For the contradiction, nondeterministic time hierarchy supplies a language in
`NTIME(2^n)` that is not in `NTIME(n^c)` for any fixed `c`. That language lies in
`NEXP` but not in `NP`, so `NEXP` is not a subset of `NP`.

## What this closes

This is a genuine barrier for the **low-randomness** branch of the ACRR program. A
proposed near-linear dPCP/PCPP with a polynomial-length key, a complete address
evaluator, and only `O(log n)` verifier randomness cannot even handle one
`NEXP`-hard language, regardless of whether its proof is described as a PCP, dPCP,
PCPP, or shared-key reconstruction. Allowing one polynomial-size Merlin response for
each random string does not help.

The theorem does **not** rule out:

* a compiler for one fixed RW relation or one fixed language that is not `NEXP`-hard;
* polynomially many random bits (the direct enumeration becomes exponential);
* hidden advice or an unaccounted Merlin/proof oracle of superpolynomial length;
* nonuniform evaluators;
* relaxed semantics whose soundness cannot be tested by enumerating the random tape.

Thus the surviving high-value positive target must either keep more than logarithmic
randomness, or prove an additional uniformity/quantifier collapse strong enough to
replace the missing enumeration. The result is a route filter, not a full
coordinate-robust dPCP impossibility theorem.

## Relation to the current ACRR program

The short-key model in note 194 permits `poly(n)` random bits and consequently only
gives `NEXP subseteq Sigma_2^P` (perfect semantics) or `NEXP subseteq NP^PP`
(bounded-error semantics). The present theorem identifies the exact point at which
the random tape becomes enumerable; even a polynomial-size response table can then be
guessed, and the consequence strengthens to the unconditionally false containment
`NEXP subseteq NP`.

This boundary should be applied before attempting a construction: a candidate that
claims coverage of even one `NEXP`-hard language with `O(log n)` randomness is already
ruled out, while a candidate with polynomial randomness remains an open compression
problem.

## Evidence boundary

The proof is an elementary quantifier reduction plus the nondeterministic time
hierarchy theorem. It makes no claim about the unresolved separations
`NEXP` versus `Sigma_2^P` or `NP^PP`, and it does not transfer from a universal
compiler to a single RW/JK history.
