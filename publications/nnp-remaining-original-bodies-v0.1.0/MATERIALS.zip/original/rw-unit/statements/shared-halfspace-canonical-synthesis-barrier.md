# 共享半空间 canonical proof 合成的 RLDC barrier

## 定理地位

这是一个**条件性、架构级但可直接验证的 barrier theorem**。它不声称所有
dPCP 都不可能同时坐标鲁棒；它针对一个很具体而重要的正向路线：先对每个
半空间

\[
  C_{i,b}=\{C(m):m_i=b\}
\]

使用 strong canonical PCPP，再把这些逐坐标 canonical proofs 从一个共同的短
对象局部合成。如果这种合成同时具有正半径稳定性，则必然给出 relaxed LDC，因而
不能在近线性长度下避开现有编码下界。

这条记录的研究价值在于把“共享 proof 合成”从构造直觉改成一个可证伪接口：
若要继续正向攻击，必须明确指出下面定理的哪个假设被破坏，或证明一个超出该
barrier 的新机制。

## 外部半空间基线

Goldreich--Gur--Komargodski 的 Theorem 3.2 对任意具有常率、常相对距离的二元
线性码

\[
  C:\{0,1\}^k\to\{0,1\}^n
\]

给出每个位置 `i` 和目标位 `b` 的 strong canonical PCPP，验证集合正是
`C_{i,b}`。其 canonical proof 长度为 `poly(n)`，查询近似均匀，且 canonical
proof map 在线性空间 `GF(2)` 上线性；`b=1` 的情形由一个固定 codeword shift
化为 `b=0`。这说明**分别**构造半空间 proof 并不困难，但没有给出一个共享
地址空间中的短合成器。

来源：[GKK, CCC 2015, Theorem 3.2](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.CCC.2015.1)，
原文的 Theorem 3.1--3.2 还明确给出 canonical proof 的线性与 near-uniform
查询性质。这里使用的下界不是 GKK 的新下界，而是把其 half-space 结构接到
本项目已有的 message-inline RLDC 编译。

一个更强的逐 affine-subspace 正向基线来自 Gur--Ramnarayan--Rothblum：其
Theorem 4.26 给出 self-correctable、strongly canonical、\(\Omega(1)\)-robust
的 affine-subspace PCPP，查询为 \(O(1)\) 但 proof 长度为指数级；Theorem 4.27
把 proof 长度降到 \(\operatorname{poly}(n)\)，代价是
\(\operatorname{polylog}(n)\) 查询，并保留 robust、strongly canonical、
self-correctable 与 GF(2)-linear canonical proof。来源：[Gur--Ramnarayan--Rothblum,
*Relaxed Locally Correctable Codes*, Theory of Computing 16 (2020),
Theorems 4.26--4.27](https://theoryofcomputing.org/articles/v016a018/v016a018.pdf)。
这比 GKK 基线更接近 ACRR 所需的鲁棒性和自校正性，但其量词仍是对每个
\((A,b)\) 单独给出一个 canonical proof map；定理没有提供一个跨所有坐标/半空间
共享 proof 地址空间的合成器。因此把 GRR 的 proof 线性、自校正或鲁棒性直接称为
simultaneous ACRR，仍然是量词错误；若存在本文第 2--4 条意义下的共享局部合成，
同样立即落入下面的 RLDC barrier。

## 共享合成模型

记 `Delta_L(a,b)` 为长度 `L` 字符串的相对 Hamming 距离，记 `Delta_H(a,b)`
为绝对 Hamming 距离；对集合取相应距离的最小值；下标 `n,N` 分别表示相应的
长度。

固定一族 `C`，并令 `P_{i,b}(m)` 表示在 `m_i=b` 时 `C(m)` 的 half-space
canonical proof（错误分支没有预设 canonical proof）。
为使消息坐标与 half-space 坐标严格一致，以下先假设 `C` 是 systematic good
linear code；若使用非 systematic code，则必须另外给出一个固定的线性消息坐标
嵌入，并把它的查询/距离代价计入参数，不能直接把 codeword 下标记作 `m_i`。
我们假设存在一个共享对象

\[
  R:\{0,1\}^k\to\{0,1\}^M,
  \qquad
  D(m)=m\,\|\,C(m)\,\|\,R(m),
\]

以及对任意 `(i,b)` 和 proof 地址 `j` 的局部合成器 `S_{i,b,j}`，满足：

1. **同一对象：** 所有 `(i,b)` 都只访问同一个 `D(m)`，不切换到独立的
   `R_{i,b}(m)`；
2. **精确合成：** 在精确的 `D(m)` 上，若 `b=m_i`，则 `S_{i,b,j}` 输出
   `P_{i,b}(m)[j]`。对错误分支 `b\ne m_i` 不要求存在 canonical proof；
   该分支由第 4 条的“任意 proof” soundness 处理；
3. **局部性：** 每次合成至多访问 `r` 个 `D(m)` 符号；
4. **half-space robust soundness：** 存在常数 `rho_H>0`、`beta_H<1/2`，使得
   对任意 `m,i,b` 且 `m_i\ne b`，任意输入 oracle `u` 满足
   相对距离 `Delta_n(u,C(m))\le rho_H`，以及任意 proof oracle `p`，原 half-space
   verifier `V_{i,b}(u,p)` 的接受率至多 `beta_H`。

### GKK soundness 直接推出第 4 条

这里的第 4 条不是额外假设性的“平均 soundness”。GKK Definition 2.7 的
strong-canonical soundness 给出一个固定的正函数 `g`，使拒绝率至少为

\[
 g\!\left(\min_{w\in C_{i,b}}
   \max\left\{
      \frac{\Delta_H(u,w)}{n},
      \frac{\Delta_H(p,P_{i,b}(w))}{|P_{i,b}|}
   \right\}\right).
\]

若 `C` 的相对距离为 `delta_C`，而 `m_i\ne b`，则任意 `w\in C_{i,b}` 与
`C(m)` 的相对距离至少为 `delta_C`。因此当
`Delta_n(u,C(m))\le rho_H:=delta_C/4` 时，

\[
  \Delta_H(u,w)/n\ge 3delta_C/4
  \quad\text{for every }w\in C_{i,b},
\]

从而无论 proof `p` 是什么，原 verifier 的拒绝率至少为
`gamma_H:=g(3delta_C/4)>0`。独立重复 `R_H=O(gamma_H^{-1})` 次后，接受率
可压到任意固定的 `beta_H<1/2`；这只把 `q_C,q_P` 同时乘一个与 `C` 的常数
参数有关的因子。故对 GKK half-space PCPP，真正需要核验的是 `g` 在该码族上
统一为正的常数函数窗口；普通 average/list soundness 不能替代这一推导。

这一步使用的是 GKK 的 formal strong-canonical 定义，而不是把 Theorem 3.2
误读成 simultaneous proof。Theorem 3.2 仍然只分别提供各个 `(i,b)` 的
canonical proof；共享合成器 `S` 依旧是本定理的核心未知对象。

令原 verifier 对输入 oracle 至多查询 `q_C` 个位置、对 proof oracle 至多查询
`q_P` 个位置。对一个收到的字符串

\[
  y=(y^{\mathrm{msg}},y^{\mathrm{code}},y^{\mathrm{sh}})
\]

定义 decoder `Dec_i`：读取 `b=y^{\mathrm{msg}}_i`；将 `V_{i,b}` 的每个输入查询
直接转成 `y^{\mathrm{code}}` 查询；将每个 proof 查询交给 `S_{i,b,j}`；若模拟
verifier 接受则输出 `b`，否则输出 `\bot`。

## 定理（共享半空间合成 ⇒ relaxed LDC）

在上述假设下，令

\[
  N=k+n+M,
  \qquad
  \rho_* = \rho_H\frac{n}{N},
  \qquad
  Q \le 1+q_C+q_P r.
\]

则 `D` 是一个二元、目标相对的弱 relaxed local decoder：对每个 `m,i`，在
`D(m)` 上以完美概率输出 `m_i`；若

\[
  \Delta_N(y,D(m))<\rho_*,
\]

则 `Dec_i(y)` 输出 `1-m_i` 的概率至多 `beta_H`，因而以至少
`1-beta_H>1/2` 的概率输出 `m_i` 或 `\bot`。

若 `q_C,q_P,r` 为常数、`rho_H` 为常数，且 `n=Theta(k)`、`M=O(k\,polylog k)`，
则 `D` 是固定 locality、正常数半径的 binary RLDC。于是调用现有自适应 relaxed-LDC
下界，得到某个 `epsilon_Q>0` 使

\[
  N\ge k^{1+\epsilon_Q}.
\]

因此在该模型中，`M=O(k\,polylog k)` 的共享 half-space proof synthesizer
不可能存在。若 `M=O(k)`，结论更直接地排除 near-linear shared proof。

### 证明

在精确 `D(m)` 上，读取的 message bit 是 `m_i`；当声明位为 `b=m_i` 时，精确
合成器产生 `P_{i,b}(m)`，故 half-space PCPP 完备性给出正确输出（若原完备性为
`alpha>1/2`，则得到相应 `alpha`-success，下面只写完美情形）。

现在设 `\Delta_H(y,D(m))<rho_*N=rho_H n`。因此 codeword 区段满足

\[
  \Delta_n(y^{\mathrm{code}},C(m))<rho_H.
\]

若 `y^{\mathrm{msg}}_i=m_i`，decoder 只可能输出正确位或 `\bot`。若
`y^{\mathrm{msg}}_i=1-m_i`，它调用错误的 half-space verifier；不论合成器在
proof 区段上产生什么字符串，假设 4 都给出接受率至多 `beta_H`。所以错误输出
概率至多 `beta_H`。每个 verifier 输入查询花费一次 codeword 访问，每个 proof
查询花费至多 `r` 次共享对象访问，再加一次 message 查询，故 `Q` 上界成立。
\(\square\)

## 这条 barrier 真正关闭什么

它关闭的是如下常见乐观路线：

> “GKK 已经为每个 `(i,b)` 提供 canonical proof；只要把这些 proof 的线性
> 表示从一个短 shared object 局部算出来，就得到 simultaneous coordinate robustness。”

在第 2--4 条接口成立时，这条路线已经是 RLDC，不再是一个独立的 PCP 逃逸。
GKK 的 proof 线性性本身没有绕过 barrier；它只使“合成器是否存在”成为一个
明确的局部编码问题。

## 正向构造必须支付的逃逸

若要超出该定理，至少有一项必须发生，并且必须被单独证明：

1. **失去 robust half-space soundness：** 只有 exact-codeword 或平均/list
   soundness，无法对任意 proof 在 `rho_H` 邻域内给出 `beta_H<1/2`；
2. **局部性失效：** 合成一个 proof symbol 需要 `r` 随 `k` 增长的查询，令
   `Q=1+q_C+q_P r` 脱离固定-query RLDC 窗口；
3. **proof 地址空间分裂：** 不同 `(i,b)` 使用不同的 shared object/地址空间，
   失去 simultaneous global-proof 量词；
4. **半径或长度退化：** `rho_H=o(1)`、`M` 超过超线性门槛，或 `n/N` 太小；
5. **只保留交互策略：** exact synthesis 仅在坐标揭示后由一个未压缩策略完成，
   此时必须另证 JK parent closure 与同一 word consistency，不能把 `forall i
   exists strategy_i` 当成共享 proof。

这些不是写作上的免责声明，而是下一轮构造/不可能性证明的分叉测试。尤其第 1 项
正好对应用户提出的 distributional-soundness 路线：平均错误率若不能升级到这里的
half-space robust soundness，不能直接进入 shared synthesis theorem。

## 与 RW/JK 的连接

RW 的目标并不是简单的线性码 half-space，但任何试图把 computation history 的输出
位先编码成一个 good linear code、再对每个位套 canonical half-space PCPP 的方案，
都会先遇到本定理。要进入 RW 地址尺度，它需要同时证明：

* `R(m)` 的长度和合成 locality 足以使 `N` 保持目标尺度；
* half-space PCPP 的错误输入半径仍是常数，并且错误 proof 任意 sound；
* 合成器在所有 `(i,b)` 间共用同一 `D(m)`，而不是重新选择 proof；
* 这些条件与 JK 的 parent/word consistency 不冲突。

若这些条件成立，RLDC 下界就是现成的硬障碍；若它们不成立，失败位置已经被
精确定位为 target-binding、局部合成、地址分裂、或交互一致性，而不是“还需要
再试一个 PCPP 组合”。

## 对 GM--Minzer--Weissenberg--Zheng 的具体检验

GM--W--Z 的 Theorem 1.7 由其 2-query dPCP 加一次候选输入坐标查询得到 3-query
PCPP：随机选一个输入位置 `t`，查询 `w_t`，再查询 dPCP 的一条边并比较解码值。
因此若有人尝试把该构造改成 RW 所需的“proof-only”坐标声明，最小新增接口必然是

\[
  B_t(D(m))=C(m)_t
\]

的统一局部合成器，并且在 `rho_H` 邻域内对错误 half-space 仍有固定 soundness。
若 `B_t` 每次只需 `r_B` 次访问，且 dPCP 的两次边查询也能由同一 `D(m)` 合成，
则可把 Theorem 1.7 的输入查询消除，得到一个 `Q=O(r_B+r_E)` 的 proof-only
verifier；随后直接落入本文件的 RLDC barrier。这里的鲁棒误差必须满足例如

\[
  \beta_{\mathrm{dPCP}}+\eta_B<1/2,
\]

其中 `eta_B` 是合成输入坐标在腐蚀下出错的概率。

但 Theorem 1.6 的 `(L,epsilon)` list-decoding soundness 只控制随机
`(t,e)` 局部视图与一个短列表的一致性；note 174 的单坐标反例说明它不能黑箱推出
上述 `B_t` 的固定坐标错误界。因此 GM--W--Z 路线现在有两个可独立检验的升级点：

1. 将平均/list soundness 升级为同一 global proof 下的 half-space robust soundness；
2. 在该升级后，再证明候选输入坐标可由同一 proof 地址空间局部合成。

只完成第 2 点而没有第 1 点，不能形成 ACRR；只完成第 1 点而继续保留显式输入
查询，则仍是 3-query PCPP 基线，而不是 proof-only Sim-CR。这个分叉把顶级正向
攻击压缩到一个明确的“coordinate binding + input-query elimination”联合定理。

## 证据边界

* GKK Theorem 3.2 只给**分别**的 half-space canonical PCPP，并不声称 shared
  synthesis；本定理的组合与 RLDC 推导是本项目的条件性推导。
* `rho_H`、`beta_H` 是从具体 strong-soundness 参数中抽出的接口；若不能从给定
  PCPP 定理得到常数窗口，只能保留形式定理，不能宣称已完成 RW 构造。
* RLDC 下界沿用仓库中的 `radius-to-relaxed-ldc-barrier.md`；本文件不把外部编码
  下界计作新的无条件 coding theorem。
