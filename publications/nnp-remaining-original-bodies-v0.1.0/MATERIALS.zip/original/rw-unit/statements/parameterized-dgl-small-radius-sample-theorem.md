# 参数化 DGL 小半径 sample theorem

## 地位与来源

这是对 Dall’Agnol--Gur--Lachish（DGL）Theorem 6.1 证明的参数化重写：把原文
主定理中写成 `Omega(1)` 的 robustness radius 保留下来，并逐项保留其对
`Claim 6.2`、`Claim 6.4`、`Claim 6.5` 的数值依赖。它不是 DGL 论文中以此形式陈述的
定理；本文的贡献是给出一个可独立检查的充分条件窗口。所有未重新展开的增长条件，
仍必须满足 DGL Theorem 6.1 的原始假设（尤其是其 `q,N,|Sigma|` 的 admissible
regime、error/randomness reduction 和 sampling cap 条件）。

原始来源：DGL, *A Structural Theorem for Local Algorithms with Applications to Coding,
Testing, and Privacy*, [ECCC TR20-154](https://eccc.weizmann.ac.il/report/2020/154/)，
Theorem 6.1 and Claims 6.2--6.5。

## 定理（参数化、单边版本）

令 `M` 是 DGL 意义下的、错误率至多 `1/3`、locality 为 `ell` 的一侧
`rho`-robust local algorithm，`rho in (0,1]`。设 `|Sigma|>=2`，并运行 DGL
Lemma 5.8--5.10 的 error/randomness reduction，得到

```text
q = O(ell log ell),       sigma = 1/(8q),
gamma = 48 |Sigma|^q ln |Sigma|,
p = gamma N^(-1/(2q^2)).
```

令

```text
K+    = ceil(gamma q^2 N^(1-1/q)),
alpha = ceil(12 ln|Sigma|/(rho sigma)).
```

在 DGL 原始增长条件之外，再假设

```text
p <= 1/2,
K+ < rho N/2,
rho N p/(56q) >= ln|Sigma| K+ + ln(10q).
```

这里将 DGL 的非平凡参数域显式写出：`q=o(sqrt(log N))`、`|Sigma|^q=N^{o(1)}`，
以及 error/randomness reduction 后的 `sigma=1/(8q)` 与其 decision-tree 描述长度
预算。若这些条件不满足，sample bound 可能退化为线性，下面的渐近窗口不能被引用。

则 DGL Section 6.1 的同一个 sample-based algorithm `N` 在原承诺域上以常数错误率
计算 `M`，并且抽样数为

```text
O(gamma N^(1-1/(2q^2))).
```

这里的“保留 `rho`”是指 robust-input 分支仍可使用原半径 `rho`；并不声称输出算法
本身成为一个新的 robust local algorithm。

## Relaxed-LDC 两分支扩展

同一个半径窗口也可带入 DGL Section 7.2 的 relaxed-local-algorithm 变换。为避免
把 DGL 的常数半径定理偷换成无条件小半径定理，以下把适用条件完整写出：令 `M` 是
一个 error rate `1/3` 的 \((\rho_0,\rho_1)\)-robust relaxed local algorithm，合法输入集
为 `V`；并要求 `V` 中的合法输入按 DGL Definition 7.6 都是相应半径的 robust
points。令两侧共同下界为

```text
rho := min{rho_0,rho_1} > 0.
```

在上面的同一组 `p,K+,alpha` 和两个 rounded window 条件下，DGL Section 7.2 的
`N_0,N_1` 两个 sample constructions 可分别使用 `T_0,T_1`（输出为对应 bit 或
`bottom`）。用同一份样本先运行两者：仅当恰有一个分支输出其声明位 `b` 且另一个
分支输出 `bottom` 时输出 `b`；出现冲突或两边都为 `bottom` 时输出 `bottom`。则：

1. 在合法输入上，正确分支的 `N_{f(x)}` 以至少 `9/10` 的概率输出 `f(x)`；
2. 在 `rho`-robust 的相反分支上，`N_{1-f(x)}` 以至少 `9/10` 的概率输出
   `bottom`；
3. 合并算法的抽样规模仍为
   `O(gamma N^(1-1/(2q^2)))`，且错误/随机性 reduction、alphabet 和原始 DGL
   增长条件不变。

这里的证明只是把 Section 7.2 的两份计数逐项复用：`N_b` 的正确分支用 Claim 6.4，
相反的 robust 分支用 Claim 6.5；Claim 6.5 只需 `|K_1|/N<rho`，由第一条 rounded
window 保证。两个分支各自的失败概率至多 `1/10`，故合法输入上的合并成功概率至少
`4/5`（再按常数重复可恢复 `2/3`）。`j=1` 的 kernel-assignment union bound 由
第二条 window 保证，故不会因为同时运行两个分支而引入新的半径幂。这个扩展仍是“在 DGL relaxed 定义及其合法
增长域内”的参数化推导，不是 DGL 原文已陈述的小半径定理。

特别地，若一个 family-level target-relative ACRR 已先编译成满足上述 relaxed
定义的 code family，并且其 decoding radius 落在该 `rho` 窗口内，则可把现有
relaxed-LDC sample lower bound 直接应用到这个参数化 sample construction；单目标
RW/JK 仍不能跳过 family-level 与 injectivity 这两个前提。

## 证明

先注意 `A=12 ln|Sigma|/(rho sigma)` 足够大（`|Sigma|>=2`、`q>=1`、`rho<=1`
时 `A>6`），故 `alpha<=A+1<=14 ln|Sigma|/(rho sigma)`。

### 1. Kernel 条件

DGL Claim 6.2 的逐层计数不使用 `rho`，给出

```text
|K_j| <= gamma q^2 N^(1-max{1,j}/q) <= K+.
```

因此 `K_0,K_1` 都严格小于 `rho N/2`。这同时保证：对一个 robust point 改写其
kernel 坐标后，仍处于其 `rho`-邻域；并保证 DGL volume lemma 可用于 `D_0` 与被
`alpha` cap 的 `D_1` 部分。

### 2. 非 robust 分支

DGL Claim 6.4 的 `D_0` 并集包含在 `K_0`，所以其体积严格小于 `rho N/2`。
对被 cap 删除的 `D_1` 子集 `C`，原文的计数给出

```text
|K_1| + |C|/alpha
  < rho N/2 + |mu_x|/alpha
  <= rho N/2 + rho N/2
  = rho N,
```

其中 `|mu_x|=6N ln|Sigma|/sigma`，以及 `alpha>=12 ln|Sigma|/(rho sigma)`。
故 volume lemma 的两个 `2 sigma` 体积损失仍成立；DGL 后续的 vote/Chernoff 估计
不再引入新的 `rho` 条件。

### 3. Robust 分支的 `j>1`

DGL Claim 6.5 对 `j>1` 的 daisy partition、petal sampling 和 kernel-assignment
union bound 只使用 `|K_j|` 的上界及原始 `q,N,|Sigma|` 增长条件；这些条件在本定理
中不变，因此该部分逐字沿用。

### 4. Robust 分支的 `j=1`

对固定 kernel assignment，DGL 的 Chernoff 推导给出指数项

```text
exp(-rho N p/(48q))
```

在 `alpha` 取整后，把常数 `48` 保守替换为 `56` 仍成立。第二条窗口条件于是给出

```text
exp(-rho N p/(56q))
  <= |Sigma|^(-K+)/(10q)
  <= |Sigma|^(-|K_1|)/(10q).
```

对 `|Sigma|^{|K_1|}` 个 assignments 和 `j=1` 的一次 union bound 后，误报概率至多
`1/(10q)`；与 `j>1` 的原 union bound 合并，DGL robust 分支仍以原常数概率正确。

sampling step 的失败概率和非 robust 分支的 `9/10` 成功率保持不变，故总错误率仍
可压到 `1/3`。抽样规模由 `pN` 给出，即 `O(gamma N^(1-1/(2q^2)))`。

## 固定参数的半径窗口

当 `q` 与有限 alphabet `Sigma` 固定时，`gamma` 为常数，第一条窗口给出
`rho >= C_1(q,Sigma) N^(-1/q)`，而第二条给出主导条件

```text
rho >= C(q,Sigma) N^(-1/q + 1/(2q^2)).
```

后者渐近更强；同时 `p<=1/2` 和 DGL 的其余增长条件对充分大的 `N` 自动满足。因此
该重参数化的安全摘要是：在 DGL admissible regime 内，半径达到
`N^(-1/q+1/(2q^2))` 的常数倍即可复用其 sample-based 变换。它不覆盖
`rho=o(N^(-1/q+1/(2q^2)))` 的情形，也不把小半径自动升级为常数距离 barrier。

## 对 ACRR/RLDC 的接口

若 ACRR 阈值化后得到 locality `q` 的 relaxed decoder，并且 robust-near-oracle 半径
`delta_0` 满足上述窗口、code distance 仍有 `delta_C>delta_0`，则可在 radius
`delta_0/2` 上调用该参数化 sample theorem。结合 DGL 的 relaxed-LDC 信息论收尾，
得到与其 sample exponent 相匹配的长度障碍。这里仍有两个独立前提：

1. ACRR 的 family-level、target-relative 量词必须先完成，不能把单目标 RW verifier
   直接当作 DGL 的 code family；
2. DGL 的原始增长条件、alphabet/query regime 和 relaxed-LDC 的取整接口必须逐项满足。

因此本模块是一个真正的 radius-sensitive barrier theorem；它不是对所有 ACRR 的无条件
不可能性，也不替代 simultaneous coordinate-robust PCP 的主攻路线。

## 证据边界

直接来自 DGL 原文的事实是 Theorem 6.1、Claims 6.2--6.5 的 proof skeleton、kernel
计数、`alpha` 截断和 assignment union bound。上面的两条 `rho` 窗口及其渐近形式是
本项目对这些行的参数化重证；在正式投稿前仍应把 DGL 的全部 admissible-growth
假设、取整常数和 relaxed-LDC interface 放入同一份完整 proof，而不能引用 DGL 原文
声称他们已经陈述了本定理。
