# Fractional target-binding direct-sum barrier

## 结论地位

这是 target-binding-patch-boundary 的多坐标推广。它不是一般 dPCP
不可能性定理：关键前提是，实际 proof family 能同时 forcing 一组坐标，并且每个
坐标的 wrong-class verifier 都通过同一个 shared base channel 工作。新内容是把
不同坐标的 base-sampling overlap 写成一个显式 fractional packing 数；因此可以区分
“同一核心被重复读取”和“坐标各有近乎独立的 target-binding 通道”。

## 定理

令 U 为 shared base 的位置集，I 为目标坐标集。对每个 i∈I，令 ν_i∈Δ(U) 是
verifier 抽取 base 位置的分布。固定 honest base C(m)，对候选 proof W 写

    e_W(u) = 1[W_u != C(m)_u],
    γ_i(W) = Σ_{u∈U} ν_i(u)e_W(u).

假设每个坐标均满足单坐标 target-binding 条件：存在 τ_i>0、b_i<1，使得对任意候选
proof

    Pr[Dec(W,i)=1-m_i] <= b_i + γ_i(W)/τ_i.                 (FTB1)

例如，target-binding-patch-boundary 给出 b_i=β_i+ζ_i，且可取任意
τ_i<Δ_i-η_i。

令 S⊆I，并假设存在一个联合 forcing proof W_S，使得对每个 i∈S，错误声明的接受率
至少为 δ_i>b_i。定义 t_i := τ_i(δ_i-b_i)>0。

给定任意位置成本 c:U→R_{>0}，定义 fractional packing

    Pack_c(S) =
      max { Σ_{i∈S} λ_i t_i :
            λ_i>=0 and Σ_{i∈S} λ_i ν_i(u) <= c(u) for every u∈U }.  (FTB2)

则每个联合 forcing proof 都必须满足

    Σ_{u∈U} c(u)e_{W_S}(u) >= Pack_c(S).                       (FTB3)

特别地，若所有允许的 W_S 的 shared-base 修改预算至多 B，则

    Pack_c(S) <= B                                              (FTB4)

是联合 forcing 的必要条件。若某个实际 proof graph 能实现的 forcing family 含有一个
S 违反 (FTB4)，则该 graph 不可能满足相应的同时坐标鲁棒 soundness。

## 证明

由 (FTB1) 和 W_S 在坐标 i 上至少以 δ_i forcing，得到

    γ_i(W_S) >= t_i,  for every i∈S.                           (FTB5)

任取 (FTB2) 的可行向量 λ，乘以 (FTB5) 后求和：

    Σ_i λ_i t_i
      <= Σ_u e_{W_S}(u) Σ_i λ_i ν_i(u)
      <= Σ_u c(u)e_{W_S}(u).

对所有可行 λ 取最大值即得 (FTB3)。

这个证明只使用单坐标 target-binding 不等式和同一个候选 proof W_S 同时作用于所有
i∈S；不把逐坐标分别存在的 proof 拼成联合 proof。

## 三个可计算特例

### 不相交 target-binding 通道

若 ν_i 均匀分布在互不相交的 U_i⊆U，取 c≡1，则可取 λ_i=|U_i|，从而

    Pack_1(S) >= Σ_{i∈S} t_i |U_i|.                            (FTB6)

也就是说，联合 forcing 必须支付每个坐标通道的腐蚀成本之和。

### 完全共享通道

若所有 ν_i=ν，且 t_i=t，则

    Pack_1(S) = t / max_{u∈U} ν(u).                            (FTB7)

对 U 上的均匀分布，这等于 t|U|，与 |S| 无关。这说明仅仅增加坐标数不会自动产生
线性 direct-sum；若所有坐标看见同一个 base，腐蚀一次即可同时影响它们。

### 一般重叠矩阵

令 N_{i,u}=ν_i(u)。则 (FTB2) 是矩阵 N 的加权 fractional packing。其值由各坐标
采样分布的最大可分离程度决定，而不是由坐标个数单独决定。一个 proof graph 若能
给出 forcing family 和 N，就可通过线性规划直接得到 shared-core 的必要腐蚀量；
不需要先假设 disjoint patches 或均匀 smoothness。

## 与已有模块的关系

* 对单个 S={i}，(FTB3) 退化为单坐标
  [target-binding-patch-boundary theorem](target-binding-patch-boundary.md)。
* 它不是
  [fractional-profile minimax barrier](fractional-profile-minimax-barrier.md) 的重述：
  后者作用在 honest query-set 与 forcing-profile 的命中博弈；本定理先把每个坐标的
  target-class 距离转成 shared-base 腐蚀约束，再对坐标之间的采样重叠作 packing。
* 若 forcing family 还能证明所有消息的 disagreement hitting，则可把 (FTB4) 与
  [patch-to-common-core information barrier](patch-to-common-core-information-barrier.md)
  叠加；这给出从“共享通道腐蚀预算”到“共享通道必须编码消息”的两阶段下界。

## 研究接口与边界

该定理的可证伪 M1 接口是：从一个实际 near-linear dPCP/RLDC proof graph 提取 W_S
（联合 forcing family）、ν_i（base-sampling matrix）和 shared-base budget B。若
Pack_c(S)>B，即可得到参数化 barrier。

平均/list/distributional soundness 本身不提供联合 forcing family；逐坐标分别存在
W_i 也不能代入 (FTB3)。因此本定理既不把 C45 的平均—坐标分离误写成一般不可
能性，也不声称已经达到 ACRR 的完整下界。真正的下一步是证明一个具体 proof graph
的联合 forcing 或证明其 forcing family 的 packing 值很小。
