# Imperfect-completeness pathwise Lorenz closure

## Theorem

Let
\[
  \Pi:\Sigma^k\longrightarrow\Sigma^N
\]
be a common proof map. For each message coordinate $i$, let $D_i$ be a
randomized decoder which reads at most $Q$ symbols (adaptively or
nonadaptively) and outputs a symbol in \(\Sigma\) or \(\bot\). Assume the
honest-path completeness deficit is at most \(\varepsilon\):
\[
  \Pr[D_i^{\Pi(m)}\neq m_i]\le\varepsilon
  \qquad(m\in\Sigma^k, i\in[k]).
\tag{1}
\]

For fixed $(m,i)$, let $\nu_{m,i}(v)$ be the expected number of reads of
position $v$ on the honest proof $\Pi(m)$, counting repeated reads. Write
\(\nu_{m,i,(1)}\ge\cdots\ge\nu_{m,i,(N)}\) for the decreasing rearrangement and
define
\[
  \Lambda_\rho:=
  \max_{m,i}\sum_{j=1}^{\lfloor\rho N\rfloor}\nu_{m,i,(j)}.
\tag{2}
\]
Put $s:=\varepsilon+\Lambda_\rho$. Then, for every received word $z$
with $d_H(z,\Pi(m))\le\rho N$,
\[
  \Pr[D_i^z\notin\{m_i,\bot\}]\le s.
\tag{3}
\]
Consequently, if
\[
  2\varepsilon+\Lambda_\rho<1,
\tag{4}
\]
then \(\Pi\) is an injective \((Q,\rho,1-\varepsilon,s)\)-RLDC map (with
adaptive or nonadaptive decoder, respectively), and distinct proof words have
relative Hamming distance greater than \(\rho\).

If the decoders are nonadaptive and, in addition,
\[
  s<|\Sigma|^{-Q},
  \qquad
  \varepsilon\frac{|\Sigma|}{|\Sigma|-1}+s|\Sigma|^Q<1,
\tag{5}
\]
then the same map is a $Q$-query LDC at every radius
\[
  r<\frac{\rho(|\Sigma|-1)}{Q|\Sigma|}
  \left(1-\varepsilon\frac{|\Sigma|}{|\Sigma|-1}-s|\Sigma|^Q\right),
\tag{6}
\]
with decoding error at most
\[
  \varepsilon+s|\Sigma|^Q\left(1-\frac1{|\Sigma|}\right)+\frac{rQ}{\rho}.
\tag{7}
\]
For \(\Sigma=\{0,1\}\), (6)--(7) become
\[
  r<\frac{\rho}{2Q}(1-2\varepsilon-s2^Q),
  \qquad
  \operatorname{err}\le\varepsilon+\frac{s2^Q}{2}+\frac{rQ}{\rho}.
\tag{8}
\]

## Proof

Let $B=\{v:z_v\neq\Pi(m)_v\}$. Couple the execution on $z$ with the
execution on $\Pi(m)$ using the same random tape. Until the first read in
$B$, the adaptive transcripts, and hence the next queried positions, agree.
Therefore the first-hit probability is at most
\[
  \mathbb E\bigl[\#\{\text{honest reads in }B\}\bigr]
  =\sum_{v\in B}\nu_{m,i}(v)
  \le\Lambda_\rho.
\]
On the complementary event the received-word execution has the honest output;
its probability of being wrong is at most \(\varepsilon\). This proves (3).

If two different messages had proof words at distance at most \(\rho\), choose a
coordinate on which they differ and run its decoder on the second proof. Relative
to the first message, (3) bounds the probability of the wrong symbol by $s$,
whereas honest completeness for the second message gives probability at least
\(1-\varepsilon\) of that wrong symbol. Condition (4) makes these inequalities
incompatible. Thus the map is injective and has distance greater than \(\rho\).

The nonadaptive LDC conclusion is exactly the imperfect-completeness
RLDC-to-LDC theorem of Cheng--Li--Mao, applied with completeness
$1-\varepsilon$, soundness $s$, query count $Q$, and robustness radius
\(\rho\). The binary specialization is immediate.

## Scope and source boundary

The first implication is a new pathwise coupling statement and does not require
nonadaptivity. The LDC upgrade uses the nonadaptive hypothesis: the cited
RLDC-to-LDC theorem explicitly treats imperfect completeness only for
nonadaptive decoders. No claim is made here that an arbitrary adaptive
imperfect-completeness RLDC automatically upgrades to an LDC. The result is a
general barrier for simultaneous coordinate-robust common proofs; it is not a
proof of \(P\neq NP\) and does not assert that ordinary dPCP/list soundness
supplies the pathwise profile (2).

## Source

J. Cheng, Z. Li, and P. Mao, *When Relaxation Doesn't Help: RLDCs with Small
Soundness Yield LDCs*, arXiv:2603.03717, Theorem
`thm:rldc-to-ldc-imperfect-general`:
<https://arxiv.org/abs/2603.03717>.
