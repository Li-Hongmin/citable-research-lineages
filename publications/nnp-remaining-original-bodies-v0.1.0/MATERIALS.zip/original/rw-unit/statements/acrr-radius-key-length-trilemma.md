# ACRR 的半径—共享 key—长度三难边界

## 定理地位

这是把 shared-key ACRR/RLDC 二分与 DGL 的 sample lower bound 组合成的参数化总
检验。它不是新的 RLDC 下界：外部输入仍是 Dall'Agnol--Gur--Lachish 的结构定理。
本模块的作用是把一个 simultaneous coordinate-robust 构造的三个逃逸方向写成同一条
可代入不等式，并明确哪些参数必须被证明为新机制。

## 模型与 DGL 窗口

令 `M subseteq {0,1}^k`，`C:M -> Sigma^N`，其中 `Sigma` 是有限 alphabet。每个
消息 `m` 携带一个 `s` 比特 descriptor/key `kappa(m)`. 对每个 key `sigma`、坐标
`i` 和声明 `b`，统一 verifier `V_{sigma,i,b}` 至多查询 `q_0` 个 proof symbols。
设其接受概率为 `p_{sigma,i,b}(z)`，并假设存在 `rho>0` 与 `alpha>beta`：

1. 若 `kappa(m)=sigma`，则 `p_{sigma,i,m_i}(C(m)) >= alpha`；
2. 若 `dist(z,C(m)) <= rho`，则 `p_{sigma,i,1-m_i}(z) <= beta`。

令

```text
Delta = alpha-beta,
Q = ceil(c0 q_0 Delta^(-2)),
h = log_2 |M|.
```

假设 DGL 的 sample theorem 在半径 `rho/2`、查询数 `Q`、alphabet `Sigma` 和长度
`N` 的参数域中成立，并给出某个 `theta in (0,1)` 与常数 `B`，使固定 key 桶内
的 `k` 个消息坐标可由共同 sample transcript 恢复，所需样本数至多

```text
S_DGL <= B |Sigma|^Q log_2|Sigma| N^(1-theta).
```

对原始 DGL 固定参数 regime，可取

```text
theta = c1/(Q^2 log^2(Q+2)).
```

若使用参数化小半径版本，则 `rho/2` 必须显式满足其 rounded window；本定理不把该
窗口冒称为 DGL 原文的常数半径定理。

## 总结论

存在绝对常数 `B'`，使

```text
h - s <= B' |Sigma|^Q log_2|Sigma| N^(1-theta) log_2(k+2).
\tag{RKL-1}
```

因此，若某个目标族有 `h-s >= mu k`，其中 `mu>0`，则

```text
N >= [ mu k /
       (B' |Sigma|^Q log_2|Sigma| log_2(k+2)) ]^(1/(1-theta)).
\tag{RKL-2}
```

固定 `Q` 和固定 `Sigma` 时，这就是

```text
N >= k^(1+theta/(1-theta)) / polylog(k).
```

特别地，在 `N = k polylog(k)` 的近线性 regime、`h >= gamma k` 且固定 `Q,Sigma`
时，(RKL-1) 强制

```text
s >= gamma k - o(k).
\tag{RKL-3}
```

所以同时坐标鲁棒的近线性构造必须至少选择以下一个逃逸：

* 共享 key/descriptor 携带 `Omega(k)` 位目标信息；
* 半径、completeness/soundness gap 或 DGL 窗口退化；
* proof length 离开近线性，满足 (RKL-2)；
* 坐标后策略不是有限长度响应，因而不再属于该 RLDC 模型。

这是一条“逃逸三难”而非无条件的所有 ACRR 不可能性定理：单一 RW 目标、独立
proof address space、无界 Merlin strategy 和 codeword-only soundness 均不满足本
模块的量词。

## 证明

把消息按 `kappa` 分桶。由于 descriptor 只有 `s` 位，存在一个桶 `sigma` 满足

```text
log_2 |{m in M : kappa(m)=sigma}| >= h-s.
```

固定该桶。对每个坐标的两个声明分支分别重复并阈值化，阈值取
`(alpha+beta)/2`。在 codeword 上正确分支以常数概率输出该坐标；在 `rho/2` 邻域内
错误分支不能越过阈值，因此得到一个查询数 `Q` 的 relaxed local decoder。由于
同桶不同消息在某个坐标上不同，若其 codewords 距离不超过 `rho`，就会同时违反一个
消息的错误 soundness 与另一个消息的 completeness；故该桶 codewords 两两分离。

DGL sample theorem 对该桶给出共同的坐标样本。坐标抽样与消息独立，先把每个坐标
的错误率降到 `1/(3k)`，只需 `O(log(k+2))` 个独立 sample stages。于是同一份
sample transcript 以常数概率恢复整个桶内消息。其 transcript 熵至多

```text
O(S_DGL log_2|Sigma| log_2(k+2)).
```

对桶内均匀消息应用 Fano 不等式，得到

```text
log_2 |{m : kappa(m)=sigma}|
  <= B' |Sigma|^Q log_2|Sigma| N^(1-theta) log_2(k+2),
```

再代入桶熵下界 `h-s`，即得 (RKL-1)；(RKL-2) 与 (RKL-3) 是代数整理。

## 可执行审查规则

对一个拟议的 near-linear Sim-CR/ACRR 构造，先填写

```text
(h, s, rho, alpha-beta, q_0, |Sigma|, N).
```

若 `rho/2` 落入 DGL 窗口、`Q` 与 `|Sigma|` 固定、`h-s=Omega(k)` 而 `N=k polylog(k)`，
则构造立即违反 (RKL-1)。因此“非二元 alphabet”“有限 bank”或“短 descriptor”
只有在它们同时改变 `Q`、半径窗口或 key 熵时才是真正的逃逸；单纯更换符号表并不能
绕开该总检验。

若坐标揭示后允许一个 `r` 比特响应，且错误声明对所有响应都 sound，把每个响应枚举
后只需将 `Q` 替换为

```text
Q_r = O(2^r q_0 Delta^(-2)).
```

当 `r=O(1)` 时三难边界不变；当 `r=Theta(log k)` 时 locality 和 `theta` 必须重新
计账；无界响应不属于本定理。

## 证据边界

* shared-key 到 (RKL-1) 的桶熵与 RLDC 推导见
  [key-indexed ACRR/RLDC dichotomy](key-indexed-acrr-rldc-dichotomy.md)。
* DGL 的结构定理与 sample exponent 见
  [TR20-154](https://eccc.weizmann.ac.il/report/2020/154/)。
* 半径依赖的窗口若要使用，必须另行满足
  [parameterized DGL small-radius theorem](parameterized-dgl-small-radius-sample-theorem.md)。

本模块没有把上述外部结果包装成新的 unconditional `P != NP` 结论；它的贡献是把
ACRR 主线的剩余参数逃逸压缩成一条可复核的总不等式。
