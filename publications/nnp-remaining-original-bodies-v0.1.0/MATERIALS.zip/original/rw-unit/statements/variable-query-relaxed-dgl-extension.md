# Variable-query relaxed-DGL extension

## Theorem (source-audited derived form)

Let \(M_N\) be a binary relaxed local algorithm on oracle strings of length \(N\),
with a fixed positive robustness radius on both output values, error at most
\(1/3\), and locality \(\ell=\ell(N)\). Let \(Q\) be the normalized query count after the Dall'Agnol--Gur--Lachish
error and randomness reductions, so that

\[
  2\le Q\le C_0\ell\log(\ell+2).
\]

If the raw normalized count is \(0\), the fixed explicit-input problem is
constant and is handled separately. If it is \(1\), pad to \(Q=2\); this only
changes the constant-query case.

Assume \(Q^3=o(\log N)\). Then the same valid-input set admits a sample-based
relaxed algorithm with binary sample complexity

\[
  S(N)\le C_1\,2^Q Q\,N^{1-1/(2Q^2)},
\tag{1}
\]

where the constants depend only on the fixed error and robustness parameters.

Consequently, if \(C:\{0,1\}^k\to\{0,1\}^N\) is a binary relaxed LDC in this
window, then

\[
  N\ge
  \left(\frac{k-1}{C_2\,2^Q Q\log(k+2)}\right)^{1/(1-1/(2Q^2))}.
\tag{2}
\]

In particular, along any subsequence with \(N\le k(\log k)^c\), the quantitative
version of the same estimates gives \(Q=\Omega((\log k)^{1/3})\); the statement
is along that subsequence, not a claim about lengths outside the near-linear
regime.

## Proof status and source boundary

This is a derived theorem, not a theorem stated in the relaxed-LDC corollary of
Dall'Agnol--Gur--Lachish. The source's general structural theorem already retains
the query parameter, while its relaxed Theorem 7.7 is presented for constant query.
The derivation re-runs the relaxed two-output construction with \(Q\) explicit:

1. Claims 5.8--5.9 reduce error to \(1/(8Q)\), reduce randomness, and produce a
   uniform multi-collection of \(Q\)-query trees of size \(O(NQ)\).
2. The source daisy partition and kernel bounds (Claims 6.2, 6.4, and 6.5) are
   retained with \(\gamma=O(2^Q)\) and \(p=\gamma N^{-1/(2Q^2)}\). The condition
   \(Q^3=o(\log N)\) makes \(p=o(1)\), \(pN\to\infty\), all kernels \(o(N)\),
   and every Chernoff comparison uniform over the \(Q\) layers.
3. The two output branches use the same Bernoulli sample. Their combination
   preserves the relaxed bottom semantics and changes only the absolute error
   constant, as in source Theorem 7.7.
4. Repeating the sample decoder \(O(\log k)\) times and reusing each sample set
   across all message coordinates gives (2) by the standard sampled-word counting
   argument.

The complete parameter calculation and the \(Q\)-dependent threshold checks are in
[note 255](../../mcsp-hardness-magnification/notes/255-variable-query-relaxed-dgl-theorem-2026-08-17.md).
The result is not attributed to the source as stated, and it does not by itself prove
\(P\ne NP\) or a general dPCP impossibility theorem.

## Source

* M. Dall'Agnol, T. Gur, and O. Lachish, *A Structural Theorem for Local Algorithms
  with Applications to Coding, Testing, and Privacy*, ECCC TR20-154, Theorem 6.1,
  Claims 5.8--5.9, Claims 6.2, 6.4--6.5, and Theorem 7.7:
  <https://eccc.weizmann.ac.il/report/2020/154/>.
