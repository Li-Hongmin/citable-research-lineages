# Global-consistency cross-cluster transfer

## Theorem

Consider the shared-top-face direct-product sampler producing
\((A,A',B,u)\), where \(A,A'\in X(k)\), \(B\in X(s)\) is their shared face, and
\(u\in B\) is the base-decoder vertex. Let
\[
\mu_i=\Pr[A\in U_i],\qquad
\gamma_{ij}=\Pr[A\in U_i,\ A'\in U_j].
\]
Assume a \(\Lambda\)-smooth left-incidence marginal: for \(\ell\in\{i,j\}\), every
realized face \(A\in U_\ell\) and every \(v\in A\) satisfy
\(\Pr[u=v\mid A]\le\Lambda_\ell/k\). Exact uniform incidence is the special case
\(\Lambda_i=\Lambda_j=1\). For the \(j\)-term, \(A\) denotes the corresponding right
face \(A'\). Let
\(g:X(1)\to\Sigma\) be a single global reference word, and suppose that for
\(i,j\) there are functions \(f_i,f_j:X(1)\to\Sigma\) with

\[
\Pr_{A\sim U_i}\!\left[
\operatorname{dist}(f_i|_A,g|_A)\le\varepsilon_i
\right]=1,
\qquad
\Pr_{A'\sim U_j}\!\left[
\operatorname{dist}(f_j|_{A'},g|_{A'})\le\varepsilon_j
\right]=1.
\tag{GC1}
\]

Define the decoder-disagreement under the cross-cluster event by

\[
\rho^{\mathrm{cross}}_{ij}
=\Pr\!\left[
D_t(u,f_i(u))\ne D_t(u,f_j(u))
\mid A\in U_i,\ A'\in U_j
\right],
\tag{GC2}
\]
where the same \((t,u)\) and decoder randomness are coupled on both sides. Then

\[
\rho^{\mathrm{cross}}_{ij}
\le
\frac{\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j}{\gamma_{ij}}.
\tag{GC3}
\]

In particular, if \(\mu_i,\mu_j\ge\mu_0\), \(\gamma_{ij}\ge\mu_0^2/2\), and
\(\Lambda_i,\Lambda_j\le\Lambda\) and \(\varepsilon_i,\varepsilon_j\le\varepsilon\), then

\[
\rho^{\mathrm{cross}}_{ij}\le \frac{4\Lambda\varepsilon}{\mu_0^2}.
\tag{GC4}
\]

If the induced \((t,u)\) marginal \(\nu_{ij}\) under the cross event satisfies
\(\operatorname{TV}(\nu_{ij},\mathcal Q_{\mathrm{base}})\le\xi_{ij}\), then the
disagreement under the base distribution obeys
\[
\rho^{\mathrm{base}}_{ij}
\le \xi_{ij}
+\frac{\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j}{\gamma_{ij}}.
\tag{GC4'}
\]

For the same conditioned cross-cluster distribution, write
\[
e_i^{ij}=\Pr[D_t(u,f_i(u))\ne (w_i)_t\mid A\in U_i,A'\in U_j],
\quad
e_j^{ij}=\Pr[D_t(u,f_j(u))\ne (w_j)_t\mid A\in U_i,A'\in U_j].
\tag{GC5}
\]
If the two decoded cluster words have relative distance at least \(\Delta\) and
\(e_i^{ij},e_j^{ij}\le\eta\), then
\[
\frac{\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j}{\gamma_{ij}}
<\Delta-2\eta
\tag{GC6}
\]
forces the two words to be equal. Base-distribution error bounds may be substituted only
after an explicit total-variation transfer estimate to this same conditioned distribution; in
that base-distribution formulation the sufficient condition is
\[
\xi_{ij}+
\frac{\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j}{\gamma_{ij}}
<\Delta-2\eta.
\tag{GC6'}
\]

## Proof

Let
\[
E_i=\{u:f_i(u)\ne g(u)\},
\qquad
E_j=\{u:f_j(u)\ne g(u)\}.
\]
By (GC1), every \(A\in U_i\) contains at most \(\varepsilon_i k\) vertices from
\(E_i\). The left-incidence marginal therefore gives

\[
\Pr[A\in U_i,\ u\in E_i]
\le\mathbb E\!\left[
\mathbf 1_{A\in U_i}\frac{\Lambda_i|A\cap E_i|}{k}
\right]
\le \Lambda_i\mu_i\varepsilon_i.
\tag{GC7}
\]

The cross event is contained in \(A\in U_i\), so
\[
\Pr[u\in E_i\mid A\in U_i,A'\in U_j]
\le\frac{\Lambda_i\mu_i\varepsilon_i}{\gamma_{ij}}.
\tag{GC8}
\]
The same argument for \(j\), followed by a union bound, shows that with probability at
least \(1-(\Lambda_i\mu_i\varepsilon_i+\Lambda_j\mu_j\varepsilon_j)/\gamma_{ij}\), both
\(f_i(u)\) and \(f_j(u)\) equal \(g(u)\). On this event the two decoder outputs agree
under the coupling, proving (GC3). Equation (GC4) is immediate, and the TV bound gives
(GC4').

Finally, under the cross-cluster conditioned distribution, if each decoder is within \(\eta\)
of its corresponding word, the elementary synchronization inequality
\(\operatorname{dist}(w_i,w_j)\le\rho^{\mathrm{cross}}_{ij}+2\eta\) applies. Under the
base distribution use \(\rho^{\mathrm{base}}_{ij}\) and base-distribution errors instead.
Condition (GC6) and
\(\Delta\)-separation force equality.

### Sharpness of the conditioning loss

The factor \(1/\gamma_{ij}\) is not a proof artifact under the displayed marginal
assumptions. For \(\Lambda_i=\Lambda_j=1\), let
\[
a_i=\mu_i\varepsilon_i,\qquad a_j=\mu_j\varepsilon_j,
\qquad a_i+a_j\le\gamma_{ij}\le\min\{\mu_i,\mu_j\}.
\]
A finite blow-up realizes this explicitly: take disjoint \(k\)-vertex faces, choose each
cluster face uniformly within its cluster, and choose the vertex uniformly only after the
face has been selected. Mark exactly \(\varepsilon_i k\) (respectively
\(\varepsilon_j k\)) vertices in every cluster face as errors against one constant reference
word, so every face has exactly the prescribed error fraction. Correlate the choice of the
other face with the sampled vertex so that the cross event \(C\) contains all marked error
incidences, of unconditional masses \(a_i,a_j\), and add neutral incidences to make
\(\Pr[C]=\gamma_{ij}\); this is possible because \(a_i+a_j\le\gamma_{ij}\). Rational
parameters are made integral by a further blow-up. The conditional law \(u\mid A\) is still
exactly uniform (hence satisfies \(\Lambda=1\)), while the cross conditioning concentrates
on the marked vertices.
Choosing a decoder that reveals the sampled symbol makes
\[
\rho^{\mathrm{cross}}_{ij}=\frac{a_i+a_j}{\gamma_{ij}},
\]
so (GC3) is attained. This is a probability-space sharpness statement, not a claim
that the blow-up is an HDX instance. Any improvement from
\(\varepsilon/\gamma_{ij}\) to \(O(\varepsilon)\) therefore requires a separate
anti-concentration, independence, or incidence-mixing hypothesis.

## Relation to GMWZ

The theorem gives a concrete positive route only when a single \(g\) explains the
computation-generated left table on every heavy cluster, and when the actual
shared-top sampler has the stated smooth left-incidence marginal. An arbitrary left assignment
to GMWZ's direct-product system has neither property: Lemma 6.2 permits independent
cluster functions, which is exactly why the black-box barrier applies.

If \(T_1[A]\) is itself \(\kappa_i\)-close to \(g|_A\) on \(U_i\), while
\(f_i|_A\) is \(\delta\)-close to \(T_1[A]\), then (GC1) holds with
\(\varepsilon_i\le\delta+\kappa_i\). Combining with the heavy-cluster spectral estimate
\(\gamma_{ij}\ge\mu_0^2/2\) and \(\Lambda_i,\Lambda_j\le\Lambda\) requires
\[
\delta+\max_i\kappa_i=o(\mu_0^2)
\]
to obtain \(o(1)\) cross-distribution disagreement. For the source parameter
\(\mu_0=\delta^C\), the base-distribution version becomes the stringent requirement
\[
\Lambda(\delta+\max_i\kappa_i)+\xi_0=o(\delta^{2C}),
\]
which is not a consequence of current Lemma 6.2.
In particular, even with \(\Lambda=1\), \(\kappa_i=\xi_0=0\), and the source-scale
\(\varepsilon_i=\Theta(\delta)\), the resulting upper bound is
\(\Theta(\delta^{1-2C})\), hence vacuous for the absolute constants \(C>1/2\) used in
the heavy-cluster extraction. Improving the spectral \(\gamma_{ij}\) estimate alone
therefore cannot close this bridge; the computation-generated table would need much
stronger global coherence.

The source's Section 6 analysis gives the extracted words a base-distribution decoder error
at most \(5\sqrt{\delta}\). Thus, even granting the global-word and smoothness hypotheses,
the strongest corresponding base-distribution synchronization gate is
\[
\xi_0+\frac{4\Lambda(\delta+\max_i\kappa_i)}{\delta^{2C}}
       +10\sqrt{\delta}<\Delta.
\tag{GC9}
\]
The last term is the two word-decoder errors; this records the source parameter cost and does
not assert that a future robust outer decoder cannot improve it.

This is therefore a semantic positive interface and a parameter test, not an upgrade of
the published GMWZ theorem.

## Source boundary

The cluster decomposition and heavy-cluster notation come from
[Gur--Minzer--Weissenberg--Zheng, Section 6](https://arxiv.org/html/2512.12960#S6.2).
The transfer inequality above is derived here from the explicitly stated
left-incidence and global-reference assumptions; those assumptions are not claimed to
follow from Lemma 6.2.
