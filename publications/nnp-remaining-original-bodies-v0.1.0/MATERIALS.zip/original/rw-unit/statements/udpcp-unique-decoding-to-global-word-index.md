# Unique-decoding PCPs already provide the global-word index interface

This statement isolates the exact consequence of unique-decoding soundness for the
simultaneous coordinate-robustness program.

## Theorem

Let `D` be a uniquely-decodable PCP for a language `L subseteq Gamma^M`. Assume its
complete decoding distribution samples a uniform coordinate `J in [M]` together with a
local proof view using at most `q` proof queries, and let `D_J(T)` be the decoded symbol from
an assignment `T`.

Assume `(eta_u, epsilon_sat)` unique-decoding soundness: every assignment `T` satisfying
at least a `1-epsilon_sat` fraction of constraints has some word `w(T) in L` with

`Pr[D_J(T) != w(T)_J] <= eta_u`.

Let `Y subseteq L` be a finite candidate family with pairwise relative Hamming distance
at least `Delta > 0`, and suppose every word selected by the soundness condition lies in
`Y`. If `eta_u < Delta/2`, then the assignment-to-word relation is exactly the
global-word hypothesis (GDI2) with error `eta_u`. Therefore the sampling decoder from
[global-word distributional soundness yields an indexed list channel](global-distribution-to-indexed-list-bridge.md)
recovers the selected index using

`r = ceil(2 log((|Y|-1)/eta)/(Delta-2 eta_u)^2)`

independent coordinates and at most `r q` local proof queries, with failure probability
at most `eta`.

### Target-relative corollary

Suppose `Pi:[|Y|] -> Sigma^N` is a common-address proof map, and every proof `z` in a
radius-`rho` neighborhood of `Pi(s)` induces an assignment satisfying at least
`1-epsilon_sat` of the udPCP constraints, with the unique-decoding word constrained to
be `y^(s)`. Then the same sampler is a radius-`rho` bounded-error index decoder with
locality `r q`, and distinct proof words have relative distance greater than `rho`.

## Proof

The unique-decoding hypothesis is already a single global-word statement: it chooses one
word `w(T)` before the coordinate `J` is sampled, and the same word explains the average
decoded symbol. Restricting `w(T)` to `Y` and using its pairwise distance gives (GDI2) with
`epsilon=eta_u`. The conclusion is therefore the global-word sampling theorem.
The target-relative statement follows by applying the same implication to every proof in
the target's radius-`rho` ball; the proof-distance conclusion is the usual separated-word
argument.

## What this identifies in current dPCP constructions

The distinction is between an intermediate udPCP and a final list-decoding dPCP:

* unique-decoding soundness has the quantifier `exists w forall sampled coordinates`,
  which is exactly the global-word input needed here;
* list-decoding soundness only supplies a bounded list whose coordinate projections may
  be mixed, so it does not by itself provide a fixed `w`.

Thus a composition that preserves unique decoding and keeps the valid-word family
`Delta`-separated would immediately enter the indexed/RLDC route. If a composition replaces
unique decoding by ordinary list soundness, it must separately prove the two losses in
[satisfying-list collapse yields a global-word indexed channel](satisfying-list-collapse-to-global-word-bridge.md),
or it has not yet reached the ACRR interface.

This is a source-specific interface theorem, not a claim that every final dPCP construction
has unique-decoding soundness. The GMWZ final theorem states list-decoding soundness, while
their intermediate construction has a separate unique-decoding theorem; preserving this
property through the full composition is the concrete research target.

## Efficiency boundary

The theorem is an information/locality statement. To obtain a conventional efficient index
decoder, the family `Y` must also admit efficient candidate evaluation and index selection.
When `|Y|` is exponential, the sampler still proves an indexed channel information-theoretically
but scanning all candidates is not an efficient decoding algorithm. This is precisely the
remaining bridge to a family-level RLDC for a high-entropy message space.

## Source

The unique-decoding definition and the final list-decoding theorem are stated in
[Gur--Minzer--Weissenberg--Zheng](https://arxiv.org/html/2512.12960), Definitions 3.9--3.10
and Theorem 3.12. The present implication is the direct composition with the global-word
sampling theorem above; it does not claim that their final list-decoding composition preserves
the intermediate unique-decoding guarantee.
