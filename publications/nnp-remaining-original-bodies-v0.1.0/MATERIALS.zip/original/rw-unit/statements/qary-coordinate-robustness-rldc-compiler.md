# Finite-alphabet coordinate robustness is q-ary relaxed local decoding

## Theorem

Let \(\Gamma\) be a finite message alphabet of size \(A\ge2\), let
\(\Sigma\) be a finite proof alphabet, and let

\[
  C:\Gamma^k\hookrightarrow\Sigma^N
\]

be a proof map.  For every coordinate \(i\in[k]\) and claim \(a\in\Gamma\), let
\(V_{i,a}\) be a randomized adaptive verifier making at most \(q\) proof-symbol queries.
Write \(p_{i,a}(z)\) for its acceptance probability on proof \(z\).

Assume that for fixed \(\rho>0\) and \(\alpha>\beta\):

1. for every \(m\in\Gamma^k\), \(p_{i,m_i}(C(m))\ge\alpha\);
2. for every \(m\), every \(z\) with
   \(\operatorname{dist}(z,C(m))\le\rho N\), and every \(a\ne m_i\),
   \(p_{i,a}(z)\le\beta\).

Then \(C\) is a \(q\)-ary weak relaxed locally decodable code of radius every
\(\delta<\rho\), with completeness at least \(1-\eta\), wrong-symbol probability at most
\(\eta\), and locality

\[
  Q
  =O\!\left(
      A q\,\frac{\log(A/\eta)}{(\alpha-\beta)^2}
    \right).
\tag{QCR1}
\]

In particular, for fixed \(A,\alpha-\beta,\eta\), the locality is \(O(q)\).  Distinct
messages have proof distance strictly larger than \(\rho N\).

## Proof

Fix a requested coordinate \(i\).  Set
\(\tau=(\alpha+\beta)/2\), and independently repeat every branch \(V_{i,a}\)
\(R\) times, where

\[
  R=\Theta\!\left((\alpha-\beta)^{-2}\log(A/\eta)\right).
\]

Let \(\widehat p_{i,a}\) be the empirical acceptance rate.  Output the unique symbol
\(a\) with \(\widehat p_{i,a}>\tau\), and output \(\bot\) if there is no unique such symbol.
The decoder makes \(A R q\) proof-symbol queries.

On \(C(m)\), the correct branch has mean at least \(\alpha\), while every wrong branch has
mean at most \(\beta\), since \(C(m)\) lies in its own target neighborhood.  Hoeffding's
inequality and a union bound over the \(A\) branches give correct output with probability
at least \(1-\eta\).

If \(z\) is within relative distance \(\delta<\rho\) of \(C(m)\), every wrong branch still
has mean at most \(\beta\).  Therefore the probability that any wrong branch crosses
\(\tau\) is at most \(\eta\).  The decoder either outputs \(m_i\) or \(\bot\), and never
outputs a wrong symbol except on this failure event.  This proves (QCR1).

For distance, take \(m\ne m'\) and choose \(i\) with \(m_i\ne m'_i\).  If
\(\operatorname{dist}(C(m),C(m'))\le\rho N\), target-relative soundness for \(m\), with
\(z=C(m')\) and wrong claim \(a=m'_i\), gives
\(p_{i,m'_i}(C(m'))\le\beta\), while completeness for \(m'\) gives the opposite inequality
\(p_{i,m'_i}(C(m'))\ge\alpha\).  This contradiction proves the distance claim and injectivity.
\(\square\)

## Binary recoding

If proof symbols are encoded with \(\ell_\Sigma=\lceil\log_2|\Sigma|\rceil\) bits and
message symbols with \(\ell_\Gamma=\lceil\log_2 A\rceil\) bits, the same decoder yields a
binary relaxed local decoder for each message bit.  Its block length is
\(\ell_\Sigma N\), its locality is \(O(Q\ell_\Sigma)\), and a binary relative radius
\(\delta_{\mathrm{bin}}\) implies a symbol radius at most
\(\ell_\Sigma\delta_{\mathrm{bin}}\).  Thus fixed alphabets preserve a fixed positive
radius and fixed locality, so any applicable binary relaxed-LDC length lower bound transfers.

## Scope and interpretation

The theorem is family-level and target-relative. It requires one common proof address space
and soundness for every wrong claim in the target neighborhood. It does not apply to a single
target, independent proof spaces, selected-policy-only soundness, or ordinary unlabelled list
decoding. The factor \(A\) is the explicit price of checking all claims; if \(A\) grows, the
compiler records that growth rather than silently treating a large output alphabet as free.

## Finite-policy branch-support refinement

For each \((i,a)\), replace the single verifier by a finite policy family
\(\mathcal P_{i,a}\). Let

\[
  L=\max_i\left|
    \bigcup_{a\in\Gamma}\ \bigcup_{\pi\in\mathcal P_{i,a}}
    \operatorname{Supp}(V_{i,a,\pi})
  \right|,
  \qquad
  B=\max_{i,a}|\mathcal P_{i,a}|.
\]

Assume that for every target \(m\) and coordinate \(i\), some policy in
\(\mathcal P_{i,m_i}\) is complete with probability at least \(\alpha\), while every policy
in every wrong family \(\mathcal P_{i,a}\), \(a\ne m_i\), has probability at most \(\beta\)
throughout the target-relative \(\rho\)-neighborhood. Then the same q-ary relaxed decoder
exists with locality

\[
  O\!\left(
    L\,\frac{\log(AB/\eta)}{(\alpha-\beta)^2}
  \right),
\tag{QCR2}
\]

independent of the number of policies except through the logarithm needed for simultaneous
concentration. The decoder reads the common support once per repetition, simulates every
policy offline, and thresholds the maximum empirical acceptance in each claim family.

Indeed, choose \(R=\Theta((\alpha-\beta)^{-2}\log(AB/\eta))\) repetitions and threshold
at \((\alpha+\beta)/2\). Reading the \(L\) positions permits every adaptive policy in the
finite family to be simulated on each repetition. A union bound over at most \(AB\) policies
gives completeness and wrong-symbol error at most \(\eta\); the same close-codeword argument
as above gives proof distance strictly larger than \(\rho N\).

This is the exact finite-policy closure: a large response family is harmless when its
all-policy union support is small. Conversely, any family-level construction below the
relevant relaxed-LDC length lower bound must enlarge \(L\), weaken target-relative
all-policy soundness, or leave the common proof address space. A single target or
selected-policy-only soundness is not covered.
