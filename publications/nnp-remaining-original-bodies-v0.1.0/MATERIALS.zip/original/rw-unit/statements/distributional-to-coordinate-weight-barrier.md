# Weighted distributional soundness cannot black-box yield coordinate robustness

## Theorem

Let the output coordinates be `J=[k]`. For a candidate global proof or assignment `pi`, let

```text
e_j(pi) in [0,1]
```

denote the conditional probability that the local decoder/verifier produces a wrong
declaration at coordinate `j`. Suppose a distributional or robust soundness theorem exposes
only the weighted average guarantee

```text
sum_j w_j e_j(pi) <= delta,
```

for every candidate `pi`, where `w` is a fixed distribution on `[k]`. Then the strongest
coordinate-wise conclusion obtainable from this inequality alone is

```text
sup { max_j e_j : e in [0,1]^k, sum_j w_j e_j <= delta }
    = min(1, delta / w_min),
```

where `w_min=min_j w_j`.
If `w_min=0`, interpret `delta/w_min` as `+infinity`, so the displayed value is `1`.

Consequently, a black-box derivation of `e_j(pi)<=beta<1` for every coordinate and every
candidate proof requires

```text
delta <= beta * w_min.
```

For uniform coordinate sampling, `w_min=1/k`, so constant average error cannot imply any
fixed-coordinate constant soundness as `k` grows; the average error must already be `O(1/k)`.
The bound is sharp: choose a minimum-weight coordinate `j_*` and put all error mass there, with
`e_{j_*}=min(1,delta/w_min)` and all other `e_j=0`.

## Proof

For every coordinate `j`, the average inequality gives `w_j e_j<=delta`, hence
`e_j<=min(1,delta/w_j)`. Taking the maximum yields the upper bound
`min(1,delta/w_min)`. If `j_*` minimizes `w_j`, the vector described above satisfies the
average inequality and attains this value, proving equality.

## dPCP interpretation

In a distributional dPCP, let `w_j` be the probability of selecting output coordinate `j`
and let `e_j(pi)` be the conditional bad-agreement mass given that coordinate. The usual
robust/distributional guarantee is exactly an inequality of the displayed form after the law
of total expectation. Therefore neither agnosticity of the local decoding distribution nor a
singleton target changes the black-box conclusion: with near-uniform output sampling, constant
distributional error leaves room for one coordinate to be completely wrong.

## Sharpness is realizable by a global dPCP

The extremal vector above is not merely an abstract point in an error polytope. For every
coordinate distribution `w` and every `k\ge2`, it is realized by a one-edge dPCP with a
single global assignment. Choose `j_*\in[k]` with `w_{j_*}=w_{\min}`, let the output
language be `L=\{0^k\}`, and use one free left symbol `a`, one dummy right symbol `b`,
and a single always-accepting edge `(a,b)`. For every output coordinate `j`, let the
local decoding distribution be concentrated on this same edge, with decoder

\[
  D_{j_*}(a)=a,\qquad D_j(a)=0\quad(j\ne j_*).
\]

The honest assignment `(a=0,b=0)` has perfect completeness. For the candidate assignment
`(a=1,b=0)`, the singleton target list `({0^k\})` is violated only at `j_*`, so the
distributional bad mass is exactly `w_{\min}`; the decoding distribution is fully agnostic
because it is the same edge for every `j`. Nevertheless the fixed-coordinate wrong claim
at `j_*` is accepted with probability one. Dummy vertices, repeated edges, or harmless query
padding can raise the graph and query complexity to any prescribed constant without changing
the argument.

Moreover, this is a full `(1,w_{\min})` list-decoding dPCP in the usual quantifier order:
for the left assignment `a=0` the list `\{0^k\}` has error `0`, while for `a=1` the same
list has error exactly `w_{\min}`, independently of the right assignment `b`.

Thus the factor (delta/w_{\min}) in the theorem is sharp even inside a single-address,
singleton-output, agnostic dPCP model. Any proposed black-box upgrade must use information not
present in the scalar average—such as a coordinate-normalized predicate, a semantic outer
check, or a global consistency condition that rules out this same assignment.

### Consequence for the current near-linear 2-query dPCP theorem

For a singleton language `L={y}`, every soundness list consists only of `y`, so the
list-decoding error in a dPCP is a scalar weighted average of the form above. With uniform
output-coordinate sampling, a black-box conversion to fixed-coordinate error at most `beta`
therefore requires `epsilon<=beta/k`.

The current 2-query dPCP theorem of Gur--Minzer--Weissenberg--Zheng (TR25-217, Theorem 1.6)
states that for every **fixed** `epsilon>0` there are constants `L` and `C(epsilon)` giving
size `N log^{C(epsilon)} N`; the corresponding 3-query PCPP theorem has the same fixed-
parameter form. It does not provide a uniform `epsilon=Theta(1/k)` construction with a
constant or controlled exponent `C`. Thus the theorem supplies a near-linear dPCP building
block, but not a black-box simultaneous coordinate-robust ACRR at output length `k`.
This is a parameter gap, not a lower bound against a future coordinate-normalized construction.

This is a theorem about the information supplied by the average guarantee, not a claim that
every dPCP with the same parameters admits the extremal witness. A positive construction must
add a condition not expressible by that scalar average, for example:

* coordinate-normalized soundness (`e_j<=beta` directly);
* a target-binding outer code that makes a wrong coordinate occupy constant sampling mass;
* a global consistency condition ruling out the same bad assignment at one coordinate and
  forcing a rejection event elsewhere.

Simply copying a decoded label changes `w_j` but does not add semantic constraints. If the new
output distribution has weights `w'_j=R_j/\sum_t R_t`, the same theorem applies. To make every
coordinate have weight at least `delta/beta`, one needs

```text
1 = sum_j w'_j >= k * delta/beta,
```

which is impossible for constant `delta` and `beta` once `k>beta/delta`. Thus repetition is
only a reweighting device; it cannot convert constant average soundness into simultaneous
constant coordinate robustness. Semantic checking or an outer code must be repeated as well,
and its cost must be charged separately.

## Scope

The theorem applies to any black-box use of a scalar weighted-average soundness statement. It
does not rule out a stronger distributional theorem whose conclusion already contains a
coordinate-wise or globally coupled predicate. It also does not give a proof-length lower bound
by itself. Its role in ACRR is to identify the exact extra interface a distributional soundness
construction must supply before it can become a simultaneous coordinate-robust PCP.

## Sources and relation to the main program

The distributional-soundness notion was introduced to enable modular PCP composition; see
[Dinur--Harsha--Kindler, TR15-085](https://eccc.weizmann.ac.il/report/2015/085/). The theorem
above is the sharp coordinate projection of its weighted-average error semantics. It strictly
generalizes the singleton/agnostic counterexample in
[agnostic average-to-coordinate separation](agnostic-average-coordinate-separation.md) and
is the minimum quantitative condition that any proposed distributional bridge must beat. The
fixed-parameter dPCP statements used in the parameter application are [TR25-217, Theorem 1.6
and Theorem 1.7](https://eccc.weizmann.ac.il/report/2025/217/download).
