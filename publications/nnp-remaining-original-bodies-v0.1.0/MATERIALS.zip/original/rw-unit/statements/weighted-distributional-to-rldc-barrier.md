# 加权 distributional soundness 到 RLDC 的总障碍

## 定理

令

\[
\Pi:\{0,1\}^{k}\hookrightarrow \Sigma^{P}
\]

是一个统一的 global-proof map，\(\Sigma\) 为有限字母表。对每个坐标
\(i\in[k]\) 和声明 \(b\in\{0,1\}\)，给定一个与消息无关的随机验证器
\(V_{i,b}\)，它至多自适应查询 proof \(q\) 次。写

\[
p_{i,b}(z)=\Pr[V_{i,b}^{z}=1].
\]

令 \(w=(w_1,\ldots,w_k)\) 是坐标分布，\(w_i>0\)，
\(w_{\min}=\min_i w_i\)。假设存在 \(\rho>0\)、完备率
\(\alpha\) 和加权 distributional 错误 \(\varepsilon\)，满足：

1. **同一 proof 完备性：** 对所有 \(m\in\{0,1\}^k\) 和 \(i\in[k]\)，
   \[
   p_{i,m_i}(\Pi(m))\ge\alpha.
   \tag{WD1}
   \]
2. **目标相对加权 soundness：** 对所有 \(m\) 和所有
   \(z\in\Sigma^P\) 满足
   \(\operatorname{dist}(z,\Pi(m))\le\rho\)，
   \[
   \sum_{i=1}^{k}w_i\,p_{i,1-m_i}(z)\le\varepsilon.
   \tag{WD2}
   \]

令

\[
\beta=\min\{1,\varepsilon/w_{\min}\}.
\tag{WD3}
\]

若 \(\beta<\alpha\)，则：

* \(\Pi\) 的 proof codewords 两两相对距离严格大于 \(\rho\)；
* 对每个 \(0<\delta<\rho\)，\(\Pi\) 本身给出一个
  \(O(q(\alpha-\beta)^{-2})\)-query 的 adaptive weak RLDC，半径为 \(\delta\)；
* 因而在固定有限字母表、固定 \(q\)、固定正半径和固定
  \(\alpha-\beta>0\) 的参数区间内，任何该类 family 都满足外部 relaxed-LDC
  长度下界。特别地，若该下界写成
  \[
  P\ge k^{1+\eta_Q}
  \tag{WD4}
  \]
  （\(\eta_Q>0\) 只依赖固定参数），则不存在
  \(P\le k(\log k)^c\) 的无限族。

## 证明

先由 (WD2) 得到每个坐标的点态界：

\[
w_i\,p_{i,1-m_i}(z)\le\varepsilon,
\qquad
p_{i,1-m_i}(z)\le\frac{\varepsilon}{w_i}\le\beta.
\tag{WD5}
\]

### Proof distance

若 \(m\ne m'\) 且
\(\operatorname{dist}(\Pi(m),\Pi(m'))\le\rho\)，取坐标 \(i\) 使
\(m_i\ne m'_i\)。以 \(m\) 为目标、\(z=\Pi(m')\) 代入 (WD2)，则
\(V_{i,m'_i}=V_{i,1-m_i}\) 的接受率由 (WD5) 至多为 \(\beta\)。另一方面，
\((WD1)\) 对目标 \(m'\) 给出

\[
p_{i,m'_i}(\Pi(m'))\ge\alpha,
\]

矛盾于 \(\beta<\alpha\)。故 proof codewords 的距离严格大于 \(\rho\)。

### RLDC 编译

固定 \(\delta<\rho\)，请求消息坐标 \(i\) 后分别独立运行
\(V_{i,0}\) 和 \(V_{i,1}\)，每个分支重复
\(R=\Theta((\alpha-\beta)^{-2})\) 次。令
\(\theta=(\alpha+\beta)/2\)，以经验接受率越过 \(\theta\) 的分支作为候选；
若恰有一个分支越过阈值就输出对应 bit，否则输出 \(\bot\)。

在精确 codeword \(\Pi(m)\) 上，正确分支均值至少为 \(\alpha\)，错误分支均值至多
\(\beta\)（因为 codeword 位于自身的 \(\rho\)-邻域）。Hoeffding 界给出至少
\(2/3\) 的正确输出概率。

若 \(\operatorname{dist}(z,\Pi(m))\le\delta\)，错误分支仍由 (WD5) 至多为
\(\beta\)；
因此它以常数概率不会越过 \(\theta\)。无论正确分支是否越过阈值，解码器都不会以
超过 \(1/3\) 的概率输出错误 bit。每次验证至多查询 \(q\) 个 proof symbols，
总 locality 为

\[
Q=O\!\left(q(\alpha-\beta)^{-2}\right).
\tag{WD6}
\]

这正是 adaptive weak RLDC；DGL 等外部下界随后给出 (WD4)。

## 近线性参数推论

若 \(\alpha\) 与 \(\gamma>0\) 为常数，并要求
\(\beta\le\alpha-\gamma\)，则必须有

\[
\varepsilon\le(\alpha-\gamma)w_{\min}.
\tag{WD7}
\]

由于任何坐标分布都满足 \(w_{\min}\le1/k\)，均匀分布只是达到最大
\(w_{\min}=1/k\) 的情形。故固定坐标 gap 的加权平均错误至少必须满足
\(\varepsilon=O(1/k)\)；非均匀采样不能以总质量同时给予所有坐标常数权重。

在均匀采样 \(w_i=1/k\) 时，(WD7) 变为

\[
\varepsilon\le\frac{\alpha-\gamma}{k}.
\tag{WD8}
\]

这把“平均到坐标”的信息论阈值与 relaxed-LDC 的 proof-length 障碍放进同一个
定理：一旦错误降到 \(1/k\) 级并保留共同 proof、正半径和固定 locality，方案不再
是近线性 dPCP，而进入 RLDC 下界区。

## 与 dPCP singleton bridge 的关系

若 dPCP 的 singleton list soundness 在目标相对 \(\rho\)-邻域内给出

\[
\sum_i w_i\,p_{i,1-m_i}(z)\le\varepsilon,
\]

则本定理直接适用；不需要另行先写出逐坐标 soundness。对于 uniform \(w\)，这正好
恢复 singleton conditioning bridge 的 \(k\varepsilon\) 因子，并进一步把它接到
proof-only RLDC，而不仅是 coordinate verifier。

因此，固定 \(\varepsilon\) 的近线性 dPCP 不能黑箱升级为 simultaneous coordinate
robustness；要进入本定理的常数 gap 窗口，必须把 \(\varepsilon\) 降到
\(O(w_{\min})\)，并同时保持统一 proof/address space 与 target-relative 半径。

## Heavy-coordinate tail strengthening

The \(w_{\min}\) corollary is not the sharp statement for a nonuniform distribution.
For \(\tau>0\), define
\[
 H_\tau:=\{i\in[k]:w_i\ge\tau\},
 \qquad h_\tau:=|H_\tau|,
 \qquad \beta_\tau:=\min\{1,\varepsilon/\tau\}.
\tag{WD9}
\]
Let \(\iota_\tau:\{0,1\}^{h_\tau}\to\{0,1\}^k\) fill the coordinates in
\(H_\tau\) with its input and all other coordinates with zero, and set
\[
 \Pi_\tau(x):=\Pi(\iota_\tau(x)).
\tag{WD10}
\]
Whenever \(\beta_\tau<\alpha\), the restricted proof map \(\Pi_\tau\) is itself a
common-proof code for \(h_\tau\) message bits with the same target-relative radius,
completeness \(\alpha\), and wrong-claim bound \(\beta_\tau\). Consequently, after
the same threshold amplification as above, it yields a weak adaptive RLDC of length
\[
 N_\tau=h_\tau+P
\]
and locality
\[
 Q_\tau=O\!\left(q(\alpha-\beta_\tau)^{-2}\right).
\tag{WD11}
\]
Thus every applicable relaxed-LDC lower bound \(\mathsf{LB}_{A,\rho,Q_\tau}\) gives
the tail inequality
\[
 h_\tau+P\ge \mathsf{LB}_{A,\rho,Q_\tau}(h_\tau)
\qquad
\text{for every }\tau\text{ with }\varepsilon/\tau<\alpha.
\tag{WD12}
\]
In particular, if \(Q_\tau\), \(A\), and the radius/gap parameters lie in a fixed
applicable RLDC lower-bound window (GGS for nonadaptive or DGL for adaptive decoders)
and \(P\le h_\tau(\log h_\tau)^c\) infinitely often, then
\[
 Q_\tau=\Omega\!\left(\frac{\log h_\tau}{\log\log h_\tau}\right).
\tag{WD13}
\]
For a distribution with a heavy prefix of size \(h\) and weights
\(\Omega(1/h)\) on that prefix, (WD12) applies with \(\tau=\Theta(1/h)\) even when
\(w_{\min}\) is exponentially smaller.  This is strictly stronger than the
single-coordinate \(w_{\min}\) reduction.

Equivalently, for a fixed gap parameter \(0<\gamma<\alpha\), define the
constant-gap tail
\[
 h_{\gamma}(w,\varepsilon):=
 \left|\left\{i:w_i\ge\frac{\varepsilon}{\alpha-\gamma}\right\}\right|.
\tag{WD13A}
\]
Then
\[
 h_{\gamma}(w,\varepsilon)+P
 \ge
 \mathsf{LB}_{A,\rho,O(q\gamma^{-2})}
       \bigl(h_{\gamma}(w,\varepsilon)\bigr).
\tag{WD13B}
\]
Thus a nonuniform distribution escapes a fixed-gap RLDC lower bound only if every
constant-gap tail \(h_\gamma(w,\varepsilon)\) is below the corresponding coding
scale.  This is a Lorenz-tail statement, not merely a worst-coordinate estimate.

### Proof

For every \(i\in H_\tau\), (WD2) gives
\[
 p_{i,1-m_i}(z)\le\varepsilon/w_i\le\varepsilon/\tau=\beta_\tau
\]
throughout the target-relative neighborhood.  Restricting the full message to
\(\iota_\tau(x)\) preserves completeness and this pointwise wrong-claim bound.
If two restricted proof words were within the target radius, a heavy coordinate on
which their messages differ would simultaneously have acceptance at least \(\alpha\)
by completeness and at most \(\beta_\tau\) by soundness, a contradiction.  Hence the
restricted proof words are separated.  The thresholded two-branch decoder from the
proof of (WD6), with the inline \(h_\tau\)-bit message, is therefore a weak RLDC with
(WD11), and (WD12)--(WD13) follow from the external lower bound. \(\square\)

## 量词与逃逸边界

本定理要求：

* \(\Pi\) 是 message-family 的同一 proof map，而非单一 hardwired target；
* \(V_{i,b}\) 与消息无关，消息只通过目标相对 soundness 进入；
* (WD2) 对每个目标 proof 的 \(\rho\)-邻域成立；
* proof alphabet、locality 和 gap 处于外部 RLDC 下界的固定参数窗口。

若验证器可读取完整消息、每个目标使用独立 proof address space、半径退化为零，
或 soundness 只有 codeword 点而没有目标相对邻域，则不能调用本定理。若分布式
结论含有超出加权平均式 (WD2) 的 coordinate-normalized/global consistency 信息，
它也可能绕过此黑箱障碍；那将是新构造，而非 (WD2) 的直接推论。

## 证据边界

本定理是两个已独立证明模块的合并：

* 加权平均到逐坐标的 sharp bound，见
  [Weighted distributional-to-coordinate barrier](distributional-to-coordinate-weight-barrier.md)；
* target-relative coordinate robustness 到 proof-only RLDC 的编译，见
  [Radius-to-relaxed-LDC barrier](radius-to-relaxed-ldc-barrier.md)。

新的内容是把二者的参数和量词合并为 (WD1)--(WD13) 的单一接口；重坐标限制是
额外的 tail-sensitive strengthening。外部 relaxed-LDC 长度下界仍是外部输入，
不在本项目中重新证明。
