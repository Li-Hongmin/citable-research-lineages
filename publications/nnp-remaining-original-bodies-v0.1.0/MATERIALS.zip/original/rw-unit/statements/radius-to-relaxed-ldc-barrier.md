# Radius-to-relaxed-LDC barrier for target-relative coordinate robustness

## Theorem

Let

\[
  C:\{0,1\}^{k}\longrightarrow \Sigma^{N}
\]

be an injective code, where `\Sigma` is finite. For every message coordinate
`i\in[k]` and declaration `b\in\{0,1\}`, let `V_{i,b}` be a randomized oracle
verifier making at most `q` adaptive queries. For an oracle `z`, write

\[
  p_{i,b}(z)=\Pr[V_{i,b}^{z}=1].
\]

Assume there are constants `\rho>0` and `\alpha>\beta` such that:

1. **Codeword completeness.** For every message `m` and coordinate `i`,
   `p_{i,m_i}(C(m))\ge\alpha`.
2. **Target-relative near-oracle soundness.** For every message `m`, coordinate `i`,
   and oracle `z` with `dist(z,C(m))\le\rho`,
   `p_{i,1-m_i}(z)\le\beta`.

Then:

* every two distinct codewords have relative distance strictly larger than `\rho`;
* for every `0<\delta<\rho`, the same code gives a `\delta`-relaxed local decoder
  with query complexity
  `O(q(\alpha-\beta)^{-2})`;
* on a codeword `C(m)`, the decoder outputs `m_i` with probability at least `2/3`, and on
  every oracle within relative distance `\delta` of `C(m)` it outputs an element of
  `\{m_i,\bot\}` with probability at least `2/3` (equivalently, it outputs `1-m_i`
  with probability at most `1/3`).

Consequently, in any parameter regime where the external relaxed-LDC lower bound for
constant alphabet, constant query complexity and constant radius applies, a family with
constant `\rho`, constant `\alpha-\beta`, and constant `q` inherits that lower bound.
More quantitatively, writing

```text
Q = O(q (alpha-beta)^(-2)),
```

the adaptive relaxed-LDC lower bound of Dall'Agnol--Gur--Lachish gives, for constant
alphabet and constant positive radius,

```text
N >= k^(1 + 1/O(Q^2 log^2(Q+2))).
```

Thus every family-level target-relative ACRR with constant `q`, constant `rho`, and a
constant completeness/soundness gap has a polynomially superlinear proof-length barrier,
even when the original claim verifiers are adaptive and the proof map is nonlinear. This
bound is an invocation of the external coding theorem, not a new proof of its coding lower
bound.

## Near-linear impossibility corollary

Fix a finite alphabet, constants `q`, `rho>0`, and `alpha-beta>0`. There is no infinite
family of the above kind with proof length

```text
N(k) <= k (log(k+2))^c
```

for any fixed constant `c`. Indeed, the displayed DGL exponent is a fixed `eta>0`, so the
lower bound `N(k)>=k^(1+eta)` eventually dominates `k(log(k+2))^c`. The corollary applies
to arbitrary (not necessarily linear or projection) proof maps and adaptive claim
verifiers; its essential quantifier is the target-relative near-oracle promise for every
message and every proof within the fixed positive radius.

## Proof

Take distinct messages `m\ne m'` and choose a coordinate `i` with `m_i\ne m'_i`.
Suppose, for contradiction, that
`dist(C(m),C(m'))\le\rho`. Use `m` as the target in the soundness assumption and
put `z=C(m')`. Since `m'_i=1-m_i`,

\[
  p_{i,m'_i}(C(m'))\le\beta.
\]

Applying completeness to the target message `m'` gives

\[
  p_{i,m'_i}(C(m'))\ge\alpha,
\]

contradicting `\alpha>\beta`. Thus the code distance is greater than `\rho`.

Fix `\delta<\rho` and set

\[
  \theta=\frac{\alpha+\beta}{2},\qquad
  \varepsilon=\frac{\alpha-\beta}{8}.
\]

For a requested coordinate `i`, independently run `V_{i,0}` and `V_{i,1}`
`R=\Theta(\varepsilon^{-2})` times. Let `\widehat p_{i,b}` be the corresponding
empirical acceptance rates. Output `b` if exactly one of the two empirical rates is at
least `\theta`; otherwise output `\bot`.

On `C(m)`, the correct branch has mean at least `\alpha` and the wrong branch has mean
at most `\beta` (the codeword is itself within the `\rho`-ball). Hoeffding's inequality,
with the constant in `R` chosen sufficiently large, makes both empirical rates lie on
their correct sides of `\theta` with probability at least `2/3`. Hence the decoder outputs
`m_i` with probability at least `2/3`.

Now let `dist(z,C(m))\le\delta`. Since `\delta<\rho`, the wrong branch still has mean at
most `\beta`, so with probability at least `2/3` its empirical rate is below `\theta`.
On that event the decoder either outputs the correct bit (if the correct branch crosses
the threshold) or outputs `\bot`; it cannot output `1-m_i`. The decoder makes `2R`
verifier invocations, each using at most `q` oracle queries, giving the claimed
`O(q(\alpha-\beta)^{-2})` complexity.

## Scope and non-implications

This is a family-level theorem with target-relative soundness. It does not apply to a
single RW/JK instance whose verifier is allowed to depend on the target instance, and it
does not claim that ordinary average list/unique-decoding soundness supplies the
target-relative hypothesis. The theorem also does not prove a general impossibility for
all ACRR variants: a candidate can escape by shrinking the robust radius, abandoning a
uniform code family, changing the alphabet/query regime, or failing to provide the
target-relative near-oracle promise.

## Sources

* [Dall'Agnol--Gur--Lachish, TR20-154](https://eccc.weizmann.ac.il/report/2020/154/)
* [Gur--Minzer--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/abs/2512.12960)
* Exploratory derivation: [note 193](../../mcsp-hardness-magnification/notes/193-robust-near-oracle-implies-distance-and-relaxed-ldc-2026-08-16.md)
