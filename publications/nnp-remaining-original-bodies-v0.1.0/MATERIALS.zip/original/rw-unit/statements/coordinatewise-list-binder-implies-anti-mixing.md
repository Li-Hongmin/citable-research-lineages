# Coordinatewise unlabelled binding forces anti-mixing

## Theorem

Let

\[
  E:[M]\longrightarrow\Sigma^N,\qquad q:=|\Sigma|\ge 2,
\]

be a code, let \(\boldsymbol w=(w_1,\ldots,w_N)\) be any probability
distribution on \([N]\), and fix a list size \(1\le L\le M-1\). For a list
\(S\subseteq[M]\) of size \(L\), let

\[
  \mu_j(S):=\bigl\{\!\bigl\{E(s)_j:s\in S\bigr\}\!\bigr\}
\]

be the **unlabelled multiset projection** at coordinate \(j\). A
coordinatewise unlabelled binder is any family of randomized predicates
\(B_{x,j}\) whose input is only \(x\), \(j\), and \(\mu_j(S)\). Write

\[
  a_{x,j}(S)
  :=
  \Pr[B_{x,j}(\mu_j(S))=1].
\]

Assume that there are \(0<\beta<\alpha\le 1\) such that:

1. **Target-containing completeness.** For every \(x\in[M]\), every
   \(j\in[N]\), and every \(L\)-list \(T\) with \(x\in T\),
   \[
     a_{x,j}(T)\ge\alpha .
   \tag{CL1}
   \]
2. **Disjoint-list soundness.** For every \(x\in[M]\) and every
   \(L\)-list \(S\) with \(x\notin S\),
   \[
     \sum_{j=1}^N w_j a_{x,j}(S)\le\beta .
   \tag{CL2}
   \]

Put

\[
  \gamma:=1-\frac{\beta}{\alpha}>0.
\]

Then every \(x\notin S\) satisfies

\[
  \sum_{\substack{j\in[N]:\\
      E(x)_j\notin\{E(s)_j:s\in S\}}} w_j
  \ge\gamma .
 \tag{CL3}
\]
Write \(u_E(x,S)\) for the left-hand side of (CL3).

Consequently, if \(M\ge 8q/(3\gamma)\), then the anti-mixing theorem gives

\[
  L
  \le
  \frac{8q}{3\gamma}\log\frac4\gamma .
 \tag{CL4}
\]

Thus no code length can support a growing unlabelled list under a fixed
alphabet, fixed target-containing completeness, and fixed disjoint-list
gap in this coordinatewise model.

## Proof

Fix \(x\notin S\), and call a coordinate \(j\) covered when
\(E(x)_j\in\{E(s)_j:s\in S\}\). If \(j\) is covered, choose
\(s_j\in S\) with \(E(s_j)_j=E(x)_j\), and replace it by the target:

\[
  T_j:=(S\setminus\{s_j\})\cup\{x\}.
\]

Then \(x\in T_j\), \(|T_j|=L\), and the unlabelled multiset at coordinate
\(j\) is unchanged:

\[
  \mu_j(T_j)=\mu_j(S).
\]

The binder therefore sees exactly the same input, while (CL1) gives
\(a_{x,j}(S)=a_{x,j}(T_j)\ge\alpha\). If \(u_E(x,S)\) denotes the
uncovered \(\boldsymbol w\)-mass, then

\[
  \sum_{j=1}^N w_j a_{x,j}(S)
  \ge \alpha(1-u_E(x,S)).
\]

Combining this with (CL2) yields

\[
  \alpha(1-u_E(x,S))\le\beta,
  \qquad
  u_E(x,S)\ge1-\frac{\beta}{\alpha}=\gamma,
\]

which is (CL3). The bound (CL4) is exactly the previously proved
anti-mixing code/list-size theorem. \(\square\)

## Quantitative replacement-deficit trilemma

The same replacement argument remains informative when completeness is not
perfect on every target-containing list. Fix a completeness benchmark
\(\alpha>0\). For a covered coordinate \(j\), choose \(s_j\) as above and
write

\[
  \Delta_{x,j}(T_j):=
  \bigl(\alpha-a_{x,j}(T_j)\bigr)_+ .
\]

For every \(x\notin S\), disjoint-list soundness implies

\[
  \sum_{\substack{j\in[N]:\\
      E(x)_j\in\{E(s)_j:s\in S\}}}
      w_j\Delta_{x,j}(T_j)
  \ \ge\
  \Bigl(\alpha(1-u_E(x,S))-\beta\Bigr)_+ .
 \tag{CL5}
\]

Indeed, on covered coordinates
\(a_{x,j}(S)=a_{x,j}(T_j)\), so the left side is at least
\(\alpha(1-u_E(x,S))-\sum_jw_ja_{x,j}(S)\), and (CL2) finishes the
inequality.

In particular, suppose every replacement list \(T_j\) is only
\(\delta\)-deficient,
\[
  a_{x,j}(T_j)\ge\alpha-\delta
  \qquad(\delta<\alpha).
 \tag{CL6}
\]
Then (CL5) gives
\[
  u_E(x,S)\ge 1-\frac{\beta}{\alpha-\delta}.
 \tag{CL7}
\]
Whenever the right side is positive and \(M\ge
8q/(3(1-\beta/(\alpha-\delta)))\), the anti-mixing theorem again bounds
\(L\) by (CL4) with
\(\gamma=1-\beta/(\alpha-\delta)\).

Thus a large-list construction has an explicit trilemma: it must introduce
an indexed/cross-coordinate channel, let a positive weighted mass of
target-containing replacement lists lose at least the deficit in (CL5), or
leave the coordinatewise multiset model.

## What this rules out

The theorem and (CL5) allow arbitrary randomized local predicates, arbitrary
dependence on the target \(x\) and coordinate \(j\), and even access to the
full unlabelled multiset of \(L\) symbols at that coordinate. It therefore
rules out more than a particular outer-code test: under (CL1)--(CL2), the
replacement argument forces the anti-mixing hypothesis before any code-length
or decoder analysis begins.

For fixed \(q\) and fixed \(\beta/\alpha<1\), a list size
\(L=k^{\Omega(1)}\) is impossible whenever \(M\ge8q/(3\gamma)\). The
remaining escapes are structural:

* completeness may hold only for one selected list, rather than every
  target-containing list;
* the verifier may see indices, a common strategy, or cross-coordinate data;
* the alphabet or the binding gap may grow or decay with \(k\);
* the soundness statement may use a target/list relation not expressible by
  the coordinatewise multiset projection.

These are precisely the indexed/global target-binding mechanisms that the
ordinary list-to-ACRR route must add. The theorem does not claim an
impossibility for dPCPs with genuine cross-coordinate constraints, nor does it
show that every dPCP assignment realizes an arbitrary phantom word.

## Relation to the project

The earlier anti-mixing theorem was a conditional code lemma: it bounded \(L\)
assuming (CL3). This theorem supplies the missing quantifier bridge. It shows
that (CL3) is not an optional design choice for any coordinatewise unlabelled
binder satisfying target-containing completeness and disjoint-list soundness;
it is forced by the indistinguishability of a same-symbol replacement.
Because \(\boldsymbol w\) is arbitrary, the bridge applies directly to
non-uniform distributional-soundness sampling as well.

Hence the negative route now targets an entire black-box class, while the
positive route must explicitly provide an indexed/global proof channel or
weaken the all-target-containing-list completeness quantifier.
