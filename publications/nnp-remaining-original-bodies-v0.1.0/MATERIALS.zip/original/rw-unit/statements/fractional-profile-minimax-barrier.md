# Fractional forcing profiles and the exact hitting minimax

## Theorem

Fix a target coordinate \(i\). Let \(\mathcal Q\) be a finite family of possible sets of
proof positions queried on an honest transcript; a randomized adaptive verifier induces a
distribution \(\mu\in\Delta(\mathcal Q)\) on these sets. Let \(\mathcal S\) be a finite
family of forcing profiles. For every \(S\in\mathcal S\), assume there is a candidate proof
\(\Pi_S\) that agrees with the honest local answers outside \(S\), follows the honest
transcript until the first query in \(S\), and forces the wrong declaration when that first
query occurs.

Define

\[
  h_\mu(S)=\Pr_{Q\sim\mu}[Q\cap S\ne\varnothing],
  \qquad
  \eta(\mathcal Q,\mathcal S)
  =
  \min_{\mu\in\Delta(\mathcal Q)}
  \max_{S\in\mathcal S}h_\mu(S).
\tag{FP1}
\]

If every candidate proof has wrong-declaration acceptance at most \(\delta\), then

\[
  \delta\ge \eta(\mathcal Q,\mathcal S).
\tag{FP2}
\]

Moreover, finite minimax gives the exact dual form

\[
  \eta(\mathcal Q,\mathcal S)
  =
  \max_{\lambda\in\Delta(\mathcal S)}
  \min_{Q\in\mathcal Q}
  \Pr_{S\sim\lambda}[Q\cap S\ne\varnothing].
\tag{FP3}
\]

Consequently, any distribution \(\lambda\) on actual forcing profiles satisfying

\[
  \Pr_{S\sim\lambda}[Q\cap S\ne\varnothing]\ge\eta
  \qquad\text{for every }Q\in\mathcal Q
\tag{FP4}
\]

is a certificate that no verifier with honest query sets in \(\mathcal Q\) can have
wrong-declaration soundness below \(\eta\).

## Proof

For a fixed \(S\), the first-error assumption implies

\[
  \Pr[\text{wrong declaration accepts on }\Pi_S]
  \ge h_\mu(S).
\]

Soundness for every \(\Pi_S\) therefore gives
\(\max_{S\in\mathcal S}h_\mu(S)\le\delta\) for the distribution \(\mu\) induced by the
verifier. Since (FP1) minimizes this maximum over all possible query-set distributions,
(FP2) follows.

The payoff
\[
  u(Q,S)=\mathbf 1[Q\cap S\ne\varnothing]
\]
is a finite bilinear zero-sum game. von Neumann's minimax theorem gives (FP3). Equation
(FP4) then makes the inner minimum in (FP3) at least \(\eta\), so
\(\eta(\mathcal Q,\mathcal S)\ge\eta\), and (FP2) applies.

The theorem uses only the honest query-set distribution and first-error forcing; query
ordering and adaptivity disappear into the induced family \(\mathcal Q\).

## Corollaries

### Uniform profile certificate

Suppose every honest query set contains at least \(v\) distinct positions in a universe
\(U\) of size \(M\), and every \(r\)-subset of \(U\) is an actual forcing profile. Let
\(\lambda\) be uniform on those \(r\)-subsets. Then every \(Q\) satisfies

\[
  \Pr_{S\sim\lambda}[Q\cap S\ne\varnothing]
  \ge
  1-\frac{\binom{M-v}{r}}{\binom{M}{r}}.
\tag{FP5}
\]

Hence

\[
  \delta\ge
  1-\frac{\binom{M-v}{r}}{\binom{M}{r}}.
\tag{FP6}
\]

The usual support-restricted profile bound is therefore a special case of the dual
certificate, rather than a separate smoothness calculation.

### Patch-index certificate

Let the forcing profiles be unions of patch boundaries. If every honest query set meets at
least \(v\) distinct patch boundaries, and every subset of patches is jointly realizable,
choose each patch independently with probability \(\theta\). Then

\[
  \delta\ge 1-(1-\theta)^v .
\tag{FP7}
\]

This gives a quantitative obstruction even when the patch boundaries have unequal sizes or
overlap in proof positions; the relevant parameter is the number of patch indices touched
by a query set, not merely the total proof support.

### Relation to the global-coupling mass theorem

Taking the all-patches profile \(S=P\) gives the global-coupling mass bound: if the union of
all fully realizable patch boundaries is \(P\), then \(\Pr[Q\cap P\ne\varnothing]\le\delta\).
The fractional theorem is stronger when only a structured subfamily of patches is known:
one can search for a distribution \(\lambda\) that hits every allowed query set without
requiring all subsets or a common patchable complement.

## Scope

The forcing-profile family is an explicit hypothesis. Average list-decoding or
distributional soundness alone does not supply \(\mathcal S\), and the minimax theorem
does not assert that every small error set is globally realizable. A candidate construction
can evade the barrier by correlating its realizable profiles, by making the first-error
condition fail, or by changing the proof semantics. Conversely, proving a nontrivial
fractional certificate \(\lambda\) from the actual dPCP proof graph would give a direct,
parameterized coordinate-soundness lower bound without assuming full profile richness.
