# 编码 history 消除 target-separation 假设的 ACRR 编译器

## 结论地位

这是一个已证明的、参数化的 exposed-history 编译引理。它不是
`poly(n,log T)` 的 succinct ACRR，也不声称得到 `P != NP`。它的作用是精确区分两件
容易混淆的事：

1. raw history 的 systematic output slot 确实会使常数 proximity target-separation
   失败；
2. 这个失败并不意味着 target-binding 在 exposed-history 模型中不可实现。只要把整条
   history 放入一个有正距离、可 relaxed-local-decode 的编码，错误输出的近 codeword
   会自动离开所有合法 encoded histories。

因此该引理把旧的 target-separation 条件替换成一个更结构化的
`code-distance + relation-PCPP` 条件，但没有压缩 history 通道。

## 设置

固定实例 `x`。设

\[
  H_x\subseteq\{0,1\}^{T}
\]

是非空合法 computation histories，并假设所有 `h in H_x` 在指定坐标
`j(i)` 上给出同一目标位 `f_x[i]`。这里 `j(i)` 可以是 history 中输出槽位的固定
地址。取一个编码

\[
  E:\{0,1\}^{T}\longrightarrow\Sigma^{M}
\]

并令 `d_E` 为其相对距离。假设存在常数

\[
  0<\delta<\min\{\delta_D,d_E/2\}
\]

使得：

* `E` 是单射，任意两个不同 message 的 codewords 距离至少 `d_E`；
* strong-LTC tester `T_E` 在 codeword 上完美接受；若
  `dist(m,E({0,1}^T))>\delta`，则一次测试拒绝概率至少 `\rho_T>0`；
* relaxed local decoder `D_j` 在 `dist(m,E(h'))\le\delta` 时以概率至少
  `1-\eta_D` 输出 `h'_j` 或 `\bot`，并在精确 codeword 上完美输出 `h'_j`。

定义 encoded-history 关系

\[
  \mathcal M_x:=E(H_x)\subseteq\Sigma^M.
\]

再给一个对 message oracle `m` 的 relation-PCPP `B_x`，它访问 `m` 和辅助 proof
`\pi`，满足：

* 若 `m in \mathcal M_x`，存在 `\pi_m` 使 `B_x^{m,\pi_m}` 完美接受；
* 若 `dist(m,\mathcal M_x)>\gamma`，则对任意 `\pi`，
  `Pr[B_x^{m,\pi}=1]\le\beta_B`。

取参数满足

\[
  \gamma<d_E-\delta,
  \qquad
  \max\{\beta_B,\eta_D\}<1/2.
\]

`B_x` 可以由一个电路关系实现：输入为 `m`，隐 witness 为 `h`，电路检查
`h in H_x` 且 `m=E(h)`。因此该定理只要求一个标准的 proximity-PCPP；不要求它知道
坐标 `i` 或声明位 `b`。

## 编译器

全局 proof 为

\[
  \Pi=(m,\pi)\in\Sigma^M\times\{\text{PCPP proof positions}\}.
\]

对任意坐标 `i` 和声明位 `b`，定义 `V_{x,i,b}`：

1. 独立运行 `T_E` 共 `R` 次；一次拒绝则拒绝，其中
   \[
      R=\left\lceil\frac{\log\varepsilon_{\rm far}}
      {\log(1-\rho_T)}\right\rceil,
      \qquad \varepsilon_{\rm far}<1/2.
   \]
2. 在同一个 `m,pi` 上运行一次 `B_x`；若拒绝则拒绝。
3. 运行 `D_{j(i)}(m)`；只有输出恰为 `b` 时接受（输出 `\bot` 也拒绝）。

### 定理

上述 verifier 对所有坐标共用同一个 proof `\Pi` 和同一个地址空间，且：

* 正确声明 `b=f_x[i]` 在某个 honest `\Pi_x=(E(h),\pi_{E(h)})` 上完美接受；
* 对任意候选 `\Pi=(m,\pi)`，错误声明 `b=1-f_x[i]` 的接受率至多
  \[
     \beta_{\rm ACRR}
       \le \max\{\varepsilon_{\rm far},\beta_B,\eta_D\}<1/2.
  \]

查询数为

\[
  Rq_T+q_B+q_D,
\]

其中 `q_B` 计入一次 `B_x` 对 `m` 与 `pi` 的全部查询，`q_D` 是一轮 relaxed local
decoder 的查询数。所有 `(i,b)` 只改变 decoder 的目标地址与最终 bit comparison，
不改变 proof 或 PCPP address space。

## 证明

取任意候选 `m,pi`。

### 情形一：`m` 远离整个编码范围

若 `dist(m,E({0,1}^T))>\delta`，`R` 次独立 tester 全部通过的概率至多
`(1-\rho_T)^R\le\varepsilon_far`。verifier 只有在全部通过时才可能接受。

### 情形二：`m` 接近某个 codeword

否则存在 `h'` 使 `dist(m,E(h'))\le\delta`。由于 `2\delta<d_E`，该 `h'` 唯一。

若 `h'_{j(i)}=f_x[i]`，错误声明只能在 `D_{j(i)}` 输出错误 bit 时接受，概率至多
`\eta_D`；PCPP 是否接受不增加这个上界。

若 `h'_{j(i)}\ne f_x[i]`，则 `h'` 不属于 `H_x`。对任意 `h in H_x`，由码距

\[
  \operatorname{dist}(E(h'),E(h))\ge d_E
\]

和三角不等式，得到

\[
  \operatorname{dist}(m,\mathcal M_x)
     \ge d_E-\delta>\gamma.
\]

因此 `B_x` 对任意 `pi` 的接受率至多 `\beta_B`；错误声明 verifier 的接受事件是
`B_x` 接受事件的子事件，故其概率也至多 `\beta_B`。两种情形合并即得结论。

完美完备性来自任取 `h in H_x`、`m=E(h)` 及其 PCPP proof：strong-LTC 在 codeword
上完美接受，`B_x` 完美接受，`D_{j(i)}` 完美返回共同目标位 `f_x[i]`。

## 参数实例与外部结果边界

Goldreich--Gur--Komargodski 的 strong-LTC/relaxed-LDC 构造给出固定常数查询、正距离
和长度 `M=T^{1+alpha}`（任意固定 `alpha>0`）的编码层；其公开摘要明确说明该类码
同时具有 strong-LTC 与 constant-query relaxed-LDC。Gur--Minzer--Weissenberg--Zheng
的 Theorem 1.7 给出对大小为 `S` 的 circuit-SAT 关系的 3-query、近线性长度、完美
完备 PCPP。将 `B_x` 的关系电路大小记为 `S_x`，则该编译器的 proof 长度满足

\[
  |\Pi_x|=M+\widetilde O(S_x),
  \qquad
  q_{\rm total}=Rq_T+q_B+q_D.
\]

若编码器电路和 history 检查满足 `S_x=\widetilde O(M+T)`，则总长度为
`\widetilde O(M+T)`；若只知道 `S_x=poly(T)`，定理仍成立，但不能把长度写成近线性。
这一区分必须保留，不能从“PCPP 近线性”单独推出 RW 地址尺度。

## 对 RW/JK 的真正含义

该编译器严格解决了 `raw systematic slot -> constant target-separation` 这一局部
障碍，但它的全局 proof 明确包含 `E(h)`，因此仍然暴露了完整 history 的编码通道。
它不能直接满足 ACRR 的 `poly(n,log T)` key/no-hidden-history 要求；把 `E(h)` 再压缩
成短 key，正是原来的 target-binding relation-PCP 主问题。

所以本结果不应写成“已构造 succinct simultaneous dPCP”。它改变的是正向路线的精确
分叉：

* 在 exposed-history 模型中，target-separation 可由 code distance 自动获得；
* 在 address-scale 模型中，剩余问题不再是输出位是否需要外码，而是能否压缩
  `E(h)` 与 `B_x` 的共同 message channel；
* 任何声称已解决 RW ACRR 的方案，都必须同时给出短 key、同一 proof address space、
  relation-PCPP soundness 和上述 near-code decoding 量词，不能只引用 raw-history
  的 PCPP 或普通平均 list soundness。

## 证据边界

这是从编码的码距/strong-LTC/RLDC 量词和 relation-PCPP 量词直接推出的组合定理。其
结构属于已知的 PCPP-to-RLDC 变换范式；[Athamnah--Ron-Zewi--Rothblum, Appendix A,
Lemma A.3](https://eccc.weizmann.ac.il/report/2025/090/revision/1/download/) 已给出
相近的 pair-language 变换。因此本 note 不主张该编译器本身是新的 PCPP 定理；本项目
新增的只是把它按 RW 的“同一 encoded history、所有输出坐标共用 proof”量词展开，并
把 target-separation 如何由整条 history 的码距替代写成显式三情形证明。相关外部参数来源：

* [Goldreich--Gur--Komargodski, *Strong Locally Testable Codes with Relaxed Local Decoders*](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.CCC.2015.1)
  的摘要给出近线性长度、strong-LTC 与 constant-query relaxed-LDC；
* [Gur--Minzer--Weissenberg--Zheng, Theorem 1.7](https://arxiv.org/html/2512.12960#theorem-1-7)
  给出 circuit-SAT 的 3-query 近线性 PCPP；
* 这些外部定理不提供 `poly(n,log T)` 的短 history key，也不因此推出
  `P != NP`。
