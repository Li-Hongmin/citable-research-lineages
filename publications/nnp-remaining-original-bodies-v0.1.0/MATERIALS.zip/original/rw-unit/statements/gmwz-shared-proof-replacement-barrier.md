# GMWZ 独立坐标 PCPP 的 shared-proof replacement barrier

## 命题

Gur--Minzer--Weissenberg--Zheng（以下简称 GMWZ）的 Theorem 11.3 采用如下结构：对每个
坐标 \(i\) 和声明值 \(b\)，分别构造关系电路 \(\varphi_{i,b}\)，再为每个
\(\mathrm{SAT}(\varphi_{i,b})\) 取一个独立的 PCPP \(\Psi_{i,b}\)，最后把实际消息位
\(m_i\) 对应的 proof blocks 拼接起来。该结构是坐标专属 proof block 的 direct-sum，
不是一个对隐藏关系

\[
  L_x=\{y:\exists w\ R(x,y,w)\}
\]

使用同一 proof/address space 的 relation-PCPP。

考虑试图把这些独立 blocks 黑箱压成下述更强的接口：

* 消息 \(M\) 均匀取自 \(\{0,1\}^k\)，只有一个 proof map
  \(C:\{0,1\}^k\to\Sigma^N\)，其中 \(\Sigma\) 为固定有限字母表；
* 对每个固定坐标 \(i\in[k]\)，descriptor 为
  \(D_i=(i,M_i)\)，其中 \(i\) 是公开固定的坐标。因此每个 \(i\) 给出两个
  descriptor buckets，且 \(H(M\mid D_i)=k-1\)；若把 \(I\) 作为独立随机坐标加入，
  结论理解为先条件于 \(I=i\)；
* descriptor 固定后，所有 verifier policies 都读取同一物理 proof 地址空间，错误声明
  对所有 finite-time policies 都按同一个 target-relative 正半径语义 sound；每个真实
  目标/坐标都有一个 complete policy；
* 对每个 descriptor bucket，完整策略的平均 support 为 \(R_D\)，并且该接口声称
  \(R_D=o(k/\log k)\)（更一般地，声称 support 仍落在某个 relaxed-LDC 的低局部性窗口）。

则在 C109/C110 的量词下，这种 replacement 不可能同时成立。更精确地，令

\[
  G_N(r)=N h_2(r/N)+r\log_2|\Sigma|.
\]

对每个固定 \(i\) 和 \(d=(i,b)\)，其 bucket 为

\[
  B_d=\{m\in\{0,1\}^k:m_i=b\},
  \qquad \log_2|B_d|=k-1.
\]

若每个 bucket 的 complete-policy core 满足

\[
  R_d=o(k/\log k),
  \qquad N=k\,\operatorname{polylog} k,
\]

则

\[
  G_N(R_d)=o(k),
\]

与 C109 在该 bucket 上给出的

\[
  k-1\le G_N(R_d)
\]

矛盾。若不使用 core 版本，而使用 C110 的 relaxed-LDC/support 版本，则结论改写为：
每个高条件熵 bucket 必须支付

\[
  \Omega(k/\log k)
\]

级 complete-policy core，或者其 all-policy branch-support 必须离开相应的低局部性
relaxed-LDC 窗口。因每个 \(D_i\) 都有条件熵 \(k-1\)，这不是少数异常坐标的结论；
对全部 \(i\in[k]\) 和 \(b\in\{0,1\}\) 的 buckets 逐一成立。

## 证明

固定 \(i\) 和 \(d=(i,b)\)。所有满足 \(m_i=b\) 的消息形成大小 \(2^{k-1}\) 的 bucket。共同
physical proof address space、descriptor-fixed verifier 和 all-policy target-relative
soundness 使 C106 的 full branch-support union 成为 specifying core；因此 C109 的单桶
熵界适用：

\[
  \log_2|B_d|\le G_N(R_d).
\]

在 \(N=k\operatorname{polylog}k\)、固定 \(|\Sigma|\) 下，若
\(R_d=o(k/\log k)\)，二项熵项和字母表项均为 \(o(k)\)，故右端为 \(o(k)\)，而左端
为 \(k-1\)，矛盾。

若仅假设 relaxed-LDC theorem 给出
\(\log|B_d|\le\Phi_N(L_d)\)，则 C110 的条件熵三难直接给出

\[
  k-1
  \le \min\{G_N(\mathbb E R_D),\mathbb E\Phi_N(L_D)\}.
\]

于是平均 core 或平均 all-policy support 至少有一项不能保持在其低成本窗口内。

## 与 GMWZ Theorem 11.3 的边界

该命题不否定 GMWZ 的 RLDC 结果，也不声称其 proof string 在字面上不能拼接成一个
长串。它只排除一种更强的 **black-box replacement**：去掉按 \((i,b)\) 分离的
relation/PCPP 结构后，仍要求一个短 shared proof、共同地址语义、目标相对的
all-policy robustness，以及低 support/core 成本。

GMWZ 的实际构造恰好保留了坐标专属的 \(\varphi_{i,b}\) 与 \(\Psi_{i,b}\) blocks；
这改变了 descriptor 后的 proof family，而不是实现上述 shared relation-PCPP。因此
不能把 GMWZ Theorem 11.3 直接当作 RW 所需 simultaneous coordinate-robust dPCP 的
正向构造；反过来，本命题也不能把独立 blocks 的长度下界冒充为一般 shared-proof
不可能性定理。

## 证据边界与可升级方向

* GMWZ 的逐坐标 PCPP/block 结构是来源事实，见
  [TR25-217, Theorem 11.3](https://eccc.weizmann.ac.il/report/2025/217/)。
* 熵矛盾只使用 C109/C110 的共同地址、all-policy、正半径和有限时间量词；它不是新的
  PCP 构造，也不直接推出 \(P\ne NP\)。
* 真正的顶级目标变成一个可证伪的二选一：
  1. 构造满足上述 shared-proof 接口且能避开 C109/C110 的新 target-concentration
     /distributional mechanism；或
  2. 证明任何近线性 shared replacement 都必须支付
     \(\Omega(k/\log k)\) 的 core、超线性 proof，或坐标专属 address spaces。
