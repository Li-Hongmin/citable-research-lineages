# Near-linear imperfect-completeness Lorenz gate

## Theorem

Fix constants Q >= 1, rho > 0, and c >= 0. Consider infinitely many
binary common-proof maps
\[
  \Pi_k:\{0,1\}^k\longrightarrow\{0,1\}^{N_k},
  \qquad N_k\le k(\log k)^c,
\]
with nonadaptive decoders making at most Q proof reads. Let
\(\varepsilon_k\) be the maximum honest-codeword error probability and let
\(\Lambda_{\rho,k}\) be the honest-path Lorenz mass of the top
\(\lfloor\rho N_k\rfloor\) positions, as in the pathwise Lorenz closure theorem.
Put
\[
  s_k:=\varepsilon_k+\Lambda_{\rho,k}.
\]
Then, for all sufficiently large lengths in the family, it is impossible to have
simultaneously
\[
  \varepsilon_k\le\frac1{12},
  \qquad
  s_k\,2^Q\le\frac1{12}.
\tag{1}
\]
Equivalently, every such near-linear family must satisfy, at all sufficiently
large lengths,
\[
  \varepsilon_k>\frac1{12}
  \quad\text{or}\quad
  \varepsilon_k+\Lambda_{\rho,k}>\frac{2^{-Q}}{12}.
\tag{2}
\]

The constants 1/12 are inessential; they give a convenient explicit gate.
The conclusion is a coding barrier for a simultaneous common proof, not a
complexity-theoretic proof of P != NP.

## Proof

Assume (1). The imperfect-completeness pathwise Lorenz closure gives a
\((Q,\rho,1-\varepsilon_k,s_k)\)-RLDC. In the binary case, the
Cheng--Li--Mao imperfect-completeness conversion applies because
$s_k2^Q<1$ and
\[
  1-2\varepsilon_k-s_k2^Q
  \ge 1-\frac16-\frac1{12}=\frac34.
\]
Choose the LDC radius
\[
  r_k:=\frac{\rho}{8Q}.
\]
It lies strictly inside the conversion window. The resulting Q-query LDC
has error at most
\[
  \varepsilon_k+\frac{s_k2^Q}{2}+\frac{r_kQ}{\rho}
  \le \frac1{12}+\frac1{24}+\frac18
  =\frac14.
\tag{3}
\]
Hence it is also a nonadaptive RLDC with correct-or-bottom success parameter
\(\sigma=3/4\), radius $r_k$, and the same query count Q.

Goldberg--Gur--Saraogi's arbitrary nonadaptive RLDC lower bound applies once
$r_k>N_k^{-\sigma/(2Q)}$, which holds for all sufficiently large $k$ because
$r_k$ is a fixed positive constant. Therefore
\[
  N_k\ge
  \left(
    \frac{\sigma^2 k}{38Q^4\log^2 2\,\log^2 k}
  \right)^{1+1/\lceil Q/\sigma\rceil}
  =k^{1+\Omega_Q(1)}\,/(\log k)^{O_Q(1)},
\tag{4}
\]
contradicting N_k <= k(log k)^c for sufficiently large k.
This proves (2).

## Significance and boundary

The new content is the direct composition of the pathwise Lorenz profile with
the imperfect-completeness RLDC-to-LDC theorem and the arbitrary-code RLDC lower
bound. It does not assume independent branch resampling, linearity, or a
perfect-completeness repair. It does require a fixed nonadaptive query count and a
fixed positive radius. Adaptive decoders remain covered by the first-hit RLDC
closure, but this particular near-linear gate does not upgrade their imperfect
completeness to an LDC; that is a separate open interface.

## Sources

* J. Cheng, Z. Li, and P. Mao, *When Relaxation Doesn't Help: RLDCs with Small
  Soundness Yield LDCs*, arXiv:2603.03717, Theorem
  `thm:rldc-to-ldc-imperfect-general`:
  <https://arxiv.org/abs/2603.03717>.
* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for Relaxed
  Locally Decodable Codes via Robust Daisies*, arXiv:2511.21659, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.
