# Payload lifting: when a single-target ACRR becomes a family-level RLDC

## Purpose

This module isolates a precise test for the remaining ``single target versus message
family'' escape.  It does not assume that an arbitrary RW/JK instance already gives a
family.  Instead, it asks whether a fixed context can carry a freely varying payload while
leaving the verifier, proof address space, and target-relative soundness unchanged.

## Theorem (payload-oblivious lifting)

Fix a context `u` and a payload length `h`.  For every payload
`m in {0,1}^h`, let `x_{u,m}` be an instance with a binary global proof
`Pi_{u,m} in {0,1}^P`.  Let `J:[h] -> [k]` be an injection into the output coordinates,
and suppose

\[
  f(x_{u,m})_{J(j)}=m_j \qquad (j\in[h]).
\]

For every `j` and claimed bit `b`, let `V_{u,j,b}` be a randomized verifier that makes at
most `q` adaptive queries to the **same proof address space**, and whose circuit is
independent of `m`.  Write

\[
  p_{u,j,b}(z)=\Pr[V_{u,j,b}^{z}=1].
\]

Assume there are `rho>0` and `alpha>beta` such that, for every `m`:

1. **Same-proof completeness:**
   `p_{u,j,m_j}(Pi_{u,m}) >= alpha` for every `j`.
2. **Target-relative wrong-bit soundness:** whenever
   `dist(z,Pi_{u,m}) <= rho`,
   `p_{u,j,1-m_j}(z) <= beta` for every `j`.

Then the payload family has a genuine message-inline RLDC.  Define

\[
  C_u(m)=m\,\|\,\Pi_{u,m}\in\{0,1\}^{h+P}.
\]

For every `delta < rho P/(h+P)`, the following decoder is a weak adaptive
`(q+1)`-query relaxed local decoder for `C_u` at radius `delta`:

* on request `j`, read the inline payload bit `y_j`;
* set `b=y_j`, run `V_{u,j,b}` on the proof suffix of `y`;
* output `b` iff that simulation accepts, and otherwise output `bottom`.

Moreover, distinct payloads have proof distance strictly larger than `rho P`, and hence
`C_u` has relative distance strictly larger than `rho P/(h+P)`.

### Finite alphabets

If the proof alphabet is a fixed finite `Sigma`, encode each symbol by a fixed injective
block `e:Sigma -> {0,1}^ell`.  The same construction gives a binary relaxed decoder using
`q*ell+1` queries and radius

\[
  \delta < \frac{\rho P}{h+\ell P}.
\]

The statement is useful only when the encoded proof remains in the intended address scale;
the block encoding is not a free way to invoke a binary 2-query lower bound when
`q*ell>2`.

## Proof

Take two payloads `m != m'` and choose `j` with `m_j != m'_j`.  If
`dist(Pi_{u,m},Pi_{u,m'}) <= rho`, apply wrong-bit soundness for target `m` to
`z=Pi_{u,m'}`.  Since `m'_j=1-m_j`, it gives
`p_{u,j,m'_j}(Pi_{u,m'}) <= beta`, while completeness for target `m'` gives the same
quantity at least `alpha`, a contradiction.  Thus the proof suffixes differ in more than
`rho P` positions.

Now let `y` be within relative distance `delta` of `C_u(m)`.  Its proof suffix differs from
`Pi_{u,m}` in fewer than `rho P` positions.  If `y_j=1-m_j`, the invoked verifier is the
wrong-bit verifier and accepts with probability at most `beta`; if `y_j=m_j`, an accepted
answer is correct and the decoder can only return the correct bit or `bottom`.  On the
uncorrupted codeword, completeness gives a correct answer with probability at least
`alpha`.  The decoder makes one payload query and at most `q` proof queries.

## Exact escape classification

This lemma is conditional, but its hypotheses are a sharp diagnostic for RW/JK:

* If a fixed context admits `h` freely varying output bits while all coordinate verifiers
  are payload-oblivious and share one proof address space, the single-target interface has
  already lifted to a family-level RLDC and must pay the corresponding RLDC lower bound.
* Therefore a construction that evades this barrier must make at least one escape explicit:
  the verifier/address space depends on the payload, the family has too little entropy, the
  positive radius or completeness gap degenerates, the coordinates use different proofs, or
  parent/closure semantics are supplied by an interactive strategy rather than one fixed
  proof word.
* In particular, merely saying that RW supplies one target instance does not establish an
  escape.  The relevant question is whether a payload-oblivious subfamily can be embedded
  at the same address scale.

This is not an unconditional impossibility theorem for all ACRR.  It is a reduction that
turns the single-target/family-level quantifier gap into a finite, checkable list of
structural failures.

## Descriptor-dependent verifiers: the quantitative escape budget

Payload dependence is not by itself an escape.  Suppose the family has a descriptor map

\[
  \kappa:\mathcal M\to\{0,1\}^{s}
\]

and a uniform generator `Gen` such that every coordinate verifier is
`V_{kappa(m),j,b}=Gen(kappa(m),j,b)`.  Thus messages with the same descriptor use the same
verifier family and the same proof address space, although their proof strings may differ.
Allow the verifier, after seeing `j`, an additional response `tau in {0,1}^r`.  Assume that a
correct declaration has some response with completeness at least `alpha`, while every
response for an incorrect declaration has soundness at most `beta`, on the same
`rho`-neighborhood as above.

Let `h=log_2|M|`, and let `Q_r` denote the finite-response locality after threshold
amplification:

\[
  Q_r=O\!\left(2^r q_0(\alpha-\beta)^{-2}\right).
\]

Under the DGL sample regime (including its radius window), the key-indexed RLDC argument
gives

\[
  h-s
  \;\le\;
  C_D |\Sigma|^{Q_r}\log_2|\Sigma|\,
       N^{1-\theta_r}\log_2(k+2),
  \qquad
  \theta_r=\frac{c_D}{Q_r^2\log^2(Q_r+2)}.
\]

The proof is only a reduction: bucket messages by `kappa`, choose the largest bucket
(`log`-size at least `h-s`), enumerate the at most `2^r` responses, and apply the
[key-indexed ACRR/RLDC dichotomy](key-indexed-acrr-rldc-dichotomy.md) with `Q=Q_r`.

In particular, for fixed alphabet, fixed base query count and `r=O(1)`, a near-linear proof
`N=k polylog(k)` forces

\[
  s\ge k-o(k)
\]

for the full message family `M={0,1}^k`.  A payload-dependent verifier with only
`poly(log k)` or `poly(n)` descriptor bits therefore does not evade the family barrier when
`k=2^{Omega(n)}`.  It must either expose almost all message entropy in its descriptor, let
the response length grow enough to destroy constant locality, or leave the DGL radius/proof
regime.  This is the precise boundary between a succinct target-specific verifier and an
uncompressed target hardwire.

The statement still has the same scope limitations as the lifting theorem: descriptors that
are arbitrary functions of the full message, separate proof address spaces for every message,
or unrestricted post-coordinate strategies are not covered.  Those are not silently counted
as a successful construction; they are the explicit remaining escape classes.

## Finite-mode universal-address strengthening

The descriptor theorem above keeps only one verifier family inside the largest descriptor
bucket. A stronger, directly testable interface can be handled without bucketing: allow finitely
many address/strategy modes, but require wrong-bit soundness for **every** mode on the same
physical proof oracle.

Let `M subseteq {0,1}^k`, `C:M -> Sigma^N`, and let `T` be a finite mode set of size `R`.
For every output coordinate `i`, declaration `b`, and mode `tau in T`, let
`V_{i,b,tau}` be a randomized oracle verifier making at most `q` queries to one universal
address space `[N]`. A mode may encode a target descriptor, an address permutation, or a bank
selector, provided its query map is a uniform map into this same oracle. Write

```text
p_{i,b,tau}(z) = Pr[V_{i,b,tau}^z accepts].
```

Assume `rho>0` and `alpha>beta` and the following quantifiers:

1. **Finite-mode completeness:** for every `m in M` and every `i`, there exists a mode
   `tau(m,i)` with
   `p_{i,m_i,tau(m,i)}(C(m)) >= alpha`.
2. **All-mode wrong-bit soundness:** for every `m`, `i`, every `tau in T`, and every
   `z` with `dist(z,C(m)) <= rho`,
   `p_{i,1-m_i,tau}(z) <= beta`.

Then `C` is a relaxed locally decodable code at radius `rho` with locality

```text
Q = O(R q (alpha-beta)^(-2) log(R+2)).
```

On a request for coordinate `i`, estimate the acceptance probability of all `2R` pairs
`(b,tau)` to additive error at most `(alpha-beta)/4`, and output the unique bit whose best
mode exceeds `(alpha+beta)/2`; if no bit is certified, output `bottom`. On `C(m)`, the
complete mode certifies `m_i`; on every `rho`-near oracle, all modes for `1-m_i` remain below
the threshold. A union bound over the `2R` estimates gives the displayed locality and constant
success probability.

The same hypotheses force code distance. If `m_i != m'_i` and
`dist(C(m),C(m')) <= rho`, choose the complete mode for `m'` at coordinate `i`. Completeness
for `m'` says that this mode accepts declaration `m'_i` on `C(m')`, while all-mode soundness
for target `m` says that the same probability is at most `beta`, a contradiction. Hence

```text
dist(C(m),C(m')) > rho   whenever m != m'.
```

Consequently any finite-mode universal-address construction in the DGL radius window inherits
the ordinary relaxed-LDC sample lower bound with `Q` above. For `R=O(1)` this is the same
constant-locality barrier as the key-indexed theorem. For `R=2^r`, the cost is the explicit
`2^r` response/address-mode tradeoff; once `r` grows enough to make `Q` nonconstant, the
construction has paid for the escape rather than obtained a free target-binding mechanism.

This closes a concrete address-space loophole: changing the address permutation or selecting a
finite bank is not an escape if all modes remain sound on the same physical oracle. It does
not cover the genuinely different interface in which only the target's mode is sound, each
message has a separate oracle, or the post-coordinate strategy is an unbounded function. Those
cases are precisely where the all-mode enumeration proof fails and where a new theorem is still
required.

## Finite-horizon policies: replacing response length by support

### Proposition (key--support--length barrier)

The finite-mode strengthening can be made independent of the response-string length.  For each
descriptor `sigma`, coordinate `i`, and declaration `b`, let
`mathfrak P_{sigma,i,b}` be all deterministic policies in a finite-round protocol with finite
per-instance response alphabets.  Let

```text
S_{sigma,i} = union_{b,pi in mathfrak P_{sigma,i,b}} Supp(V_{sigma,i,b,pi}),
L_sigma = max_i |S_{sigma,i}|,
L_* = max_sigma L_sigma.
```

Assume the same descriptor-bucket completeness and all-policy wrong-bit soundness as above:
the correct declaration has one complete policy, while every policy for the wrong declaration
is sound on the target-relative `rho`-neighborhood.  Fix a largest descriptor bucket.  The
branch-support theorem applied inside that bucket gives a relaxed local decoder of locality at
most `L_sigma`, without enumerating the policies in the query count.  Consequently, whenever
the DGL sample window applies,

```text
h - s <= C_D |Sigma|^L_* log_2|Sigma| N^(1-theta_*) log_2(k+2),
theta_* = c_D/(L_*^2 log^2(L_*+2)).
```

This is a strict strengthening of the finite-mode estimate: an exponentially long response
string or a doubly-exponential policy table does not appear in the locality parameter.  The
only geometric cost is the union of all addresses that some policy can reach.  Thus, in a
near-linear fixed-alphabet regime with `h-s=Omega(k)`, a candidate must either make `L_*`
large enough to leave the DGL window, abandon all-policy soundness, use target-dependent proof
addresses, or move to a genuinely unbounded/continuous interaction.  The statement remains a
query-locality reduction and makes no polynomial-time claim about policy enumeration.

## Relation to the main program

The module is the family-lifting test for T2/T3 in
[the top-tier ACRR theorem program](../../mcsp-hardness-magnification/notes/189-top-tier-acrr-theorem-program-2026-08-16.md).
It complements the general message-inline compiler, which corresponds to the special case
where the whole message family is already available.  A successful RW-specific theorem would
either verify the payload-oblivious hypotheses with a new address-scale construction, or prove
that every attempted construction must pay one of the listed escape costs.

## Scope

The theorem does not claim that a fixed RW proof can be varied arbitrarily.  It requires an
actual family `x_{u,m}`, a common proof address space, and target-relative soundness for the
same proofs `Pi_{u,m}`.  Coordinate-wise existential Merlin responses, separately recompiled
PCPs, average/list soundness, or a single hardwired target do not satisfy these hypotheses.

## Sources

* [Message-inline RLDC compiler](message-inline-rldc-compiler.md)
* [Family quantifier audit](../../mcsp-hardness-magnification/notes/192-family-quantifier-audit-for-acrr-barriers-2026-08-16.md)
* [Top-tier ACRR theorem program](../../mcsp-hardness-magnification/notes/189-top-tier-acrr-theorem-program-2026-08-16.md)
