# 共同自校正 canonical PCPP 到 proof-only ACRR

## 定理地位

这是一个条件性组合定理。它把“消除 PCPP 的 input query”所需的最小结构写成
可检验的四个参数：共同 canonical proof map、正距离 target separation、消息位的
局部恢复，以及原 PCPP 的 strong-canonical soundness。它不是近线性构造；它说明
若 GRR 型 PCPP 能在同一 proof 中暴露消息位，则 input-query elimination 本身不再
是未知障碍，剩余瓶颈转为 proof 长度和 computation-relation binding。

## 共同编码假设

令 `P:{0,1}^n -> {0,1}^N` 是对所有 affine constraint
`S_{A,b}={x:Ax=b}` 都共用的 canonical proof map。假设：

1. **正距离：** 存在 `delta>0`，使得对任意 `x` 和 `Ax!=b`，
   `Delta_H(P(x),P(S_{A,b})) >= delta`；
2. **消息可恢复：** 对每个消息坐标 `j`，有统一局部算法 `D_j`，在精确
   `P(x)` 上输出 `x_j`，并且当 oracle `pi` 满足
   `Delta_H(pi,P(x))<=rho_D` 时，
   `Pr[D_j^pi != x_j] <= eta_D`；
3. **共同地址空间：** `D_j` 与下述 PCPP verifier 的 proof queries 都直接访问
   同一个 `pi`，不切换 proof、strategy 或地址编码；
4. 对每个 `(A,b)`，原 PCPP `V_{A,b}` 对 input oracle 至多查询 `q_I` 位、对
   proof oracle 至多查询 `q_P` 位，且有 strong-canonical rejection bound `g`：
   对任意 input `x` 和 proof `pi`，其拒绝率至少为
   \[
     g\!\left(\min_{x'\in S_{A,b}}
       \max\{\Delta_H(x,x'),\Delta_H(pi,P(x'))\}\right).
   \]

## 构造与结论

定义 proof-only verifier `W_{A,b}`：每次模拟 `V_{A,b}`，但把它的每一个 input
query `x_j` 替换为一次独立运行的 `D_j^pi`；proof queries 仍直接读 `pi`。

则：

* 在 `P(x)` 上，若 `Ax=b`，`W_{A,b}` 完美接受；
* 若 `Ax!=b` 且 `Delta_H(pi,P(x))<=rho`，其中
  `rho<=rho_D` 且 `rho<delta`，则
  \[
    \Pr[W_{A,b}(pi)=1]
      \le 1-g(delta-rho)+q_I\,eta_D.
  \]
* 查询数满足
  \[
    Q_W\le q_P+q_I q_D,
  \]
  其中 `q_D` 是一次消息位恢复的查询数。

特别地，若
`g(delta-rho)-q_I eta_D>1/2`，则同一个 `P(x)` 给出所有坐标/半空间的
proof-only target-relative ACRR，错误接受率严格小于 `1/2`。

### 证明

先在真实 input oracle `x` 上运行原 verifier `V_{A,b}`。当 `Ax!=b` 时，对每个
`x' in S_{A,b}`，正距离与 `Delta_H(pi,P(x))<=rho` 给出

\[
  \Delta_H(pi,P(x'))
  \ge \Delta_H(P(x),P(x'))-\Delta_H(pi,P(x))
  \ge delta-rho.
\]

因此 strong-canonical bound 中的 `max` 至少为 `delta-rho`，原 verifier 的
接受率至多 `1-g(delta-rho)`。

在 `W` 中，若所有至多 `q_I` 个消息恢复调用都返回正确位，则它的局部 view
与 `V` 完全相同。union bound 给出任一恢复错误的概率至多 `q_I eta_D`，故

\[
  Pr[W\text{ accepts}]
  \le Pr[V\text{ accepts}]+q_I eta_D
  \le 1-g(delta-rho)+q_I eta_D.
\]

当 `Ax=b` 且 `pi=P(x)` 时，所有 `D_j` 精确返回 `x_j`，原 PCPP 完备性直接给出
`W` 完美接受。查询数是原来的 proof queries 加上每个 input query 的一次局部
恢复。\(\square\)

## GRR 对接与边界

GRR Theorem 4.26 满足该接口的明确指数长度实例：`P(x)` 是 Hadamard encoding，
消息位就是固定 proof 位置，且任意两个不同消息的 proof 距离为 `1/2`。在这一
实例中，前面的 Hadamard proof-only statement 给出直接的两点差分 verifier。

GRR Theorem 4.27 给出 polynomial-length、polylog-query、robust、strongly canonical、
self-correctable 的 affine-subspace PCPP，并把输入 wire 放入 canonical low-degree
proof 的 `X` 部分。可是其完整 proof bundle 还包含由关系特定的
`\phi_{A,b}` 生成的 `P_0,\ldots,P_\ell`；这些辅助多项式随 `(A,b)` 改变。因此
Theorem 4.27 按原构造并不满足共同 proof map 假设。若另有新机制把这些
relation-dependent 辅助部分压成同一个地址空间，且 self-corrector 能在该共同 proof
上恢复 input wires，则本定理才给出
`Q_W=q_P+q_I q_D` 的 polynomial-length proof-only ACRR。这个“若”正是 shared
relation binding 的待证明接口，而不是 GRR 4.27 已有的结论。

本定理仍不解决三件事：

1. `P` 是否能降到近线性长度；
2. proof-only verifier 是否同时检查 RW 的 computation relation，而不是只检查
   affine output constraint；
3. 若把 soundness 改成对所有 arbitrary proof 而非 target-relative 邻域，跨消息
   完备性会引入量词冲突，必须另加 target commitment 或放弃 family-level 语义。

因此它不是 ACRR 的无条件构造，而是一个正向组合接口：一旦 GRR 型共同 proof
真的满足四项假设，GM--W--Z 的“额外 input query”即可被严格消除；若不能满足，
失败点是 shared map、message recovery、距离、或 relation binding，而不是
平均/list soundness 的术语问题。

## 来源

Gur--Ramnarayan--Rothblum, *Relaxed Locally Correctable Codes*, Theory of Computing
16 (2020), Theorems 4.26--4.27：
[官方 PDF](https://theoryofcomputing.org/articles/v016a018/v016a018.pdf)。
