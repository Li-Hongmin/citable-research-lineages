# Repeated-base patch boundary in the GM--W--Z RLDC wrapper

## Statement

This is the GM--W--Z instantiation of the more general
[target-binding patch-boundary theorem](target-binding-patch-boundary.md).

This module isolates a structural feature of the \(3\)-query RLDC wrapper in
Gur--Minzer--Weissenberg--Zheng (GM--W--Z), Theorem 1.9.  It is an
architecture-level result, not a lower bound for arbitrary dPCPs.

Let \(C_0:\{0,1\}^k\to\Sigma_0^{k/\rho}\) be the base code used in the
construction, with relative distance at least \(1-\mu\).  For every message
coordinate \(i\) and bit \(b\), let

\[
  \mathcal L_{i,b}
  =\{C_0(m'):m'_i=b\}.
\]

The RLDC codeword has a first block

\[
  I_1=C_0(m)^r,
  \qquad r=2\rho K,
  \qquad |I_1|=2Kk,
\]

followed by coordinate-specific PCPP blocks

\[
  \pi'_{1,m_1}(C_0(m)),\ldots,\pi'_{k,m_k}(C_0(m)).
\]

Fix \(i\), and consider an arbitrary candidate word \(w\).  Let

\[
  \gamma_i(w)
  := \frac{1}{|I_1|}
     \operatorname{Ham}\bigl(w|_{I_1},C_0(m)^r\bigr).
\]

Let \(\xi>0\) be the PCPP soundness parameter and let \(C_{\rm pcpp}\) be the
constant in GM--W--Z Theorem 11.1, so that a word at distance at least
\(1-\xi^{C_{\rm pcpp}+1}\) from the relevant language is rejected with
probability at least \(1-2\xi\).  For any \(\tau>0\) satisfying

\[
  \mu+\tau\leq \xi^{C_{\rm pcpp}+1},
\tag{1}
\]

the prescribed decoder obeys

\[
 \Pr[\operatorname{Dec}(w,i)=1-m_i]
 \leq 2\xi+\zeta_K+\frac{\gamma_i(w)}{\tau},
 \qquad
 \zeta_K:=\frac{1}{\log^{10}k}.
\tag{2}
\]

Consequently, if a candidate word forces the wrong output with probability at
least \(\delta>2\xi+\zeta_K\), then

\[
  \gamma_i(w)\geq
  \tau\bigl(\delta-2\xi-\zeta_K\bigr),
\tag{3}
\]

and hence it must change

\[
  \Omega_{\mu,\xi,\delta}(Kk)
\]

symbols in the repeated global base block.  In particular, changing only the
coordinate-\(i\) PCPP block cannot be a constant-probability forcing profile.

## Proof

The decoder first samples a uniformly random repetition \(w_0\) from the first
block.  If the appended bit read from the \(B\)-side of the \(i\)-th PCPP block
is \(m_i\), the decoder can output \(m_i\) or \(\bot\), but not \(1-m_i\).
Thus a wrong output can only occur on the branch whose appended bit is
\(b=1-m_i\), where the decoder invokes the PCPP for \(\mathcal L_{i,b}\).

By Markov's inequality, with probability at least \(1-\gamma_i(w)/\tau\) over
the sampled repetition,

\[
  \operatorname{dist}(w_0,C_0(m))\leq\tau.
\]

For any \(m'\) with \(m'_i=b\), the distance of \(C_0(m')\) from \(C_0(m)\) is
at least \(1-\mu\).  Therefore on this event

\[
  \operatorname{dist}(w_0,\mathcal L_{i,b})
  \geq 1-\mu-\tau
  \geq 1-\xi^{C_{\rm pcpp}+1}
\]

by (1).  Theorem 11.1 of GM--W--Z bounds the acceptance probability of the
invoked PCPP by \(2\xi\).  The \(B\)-side distribution used by the RLDC decoder
is only \(\zeta_K\)-close to the ideal uniform distribution, contributing the
additive term \(\zeta_K\).  On the exceptional repetitions, we use the trivial
upper bound \(1\).  This proves (2), and rearranging gives (3).

## What this proves for the ACRR program

The result gives a concrete failure of the private-variable patchability
mechanism in this wrapper.  The coordinate-specific proof blocks are private
storage locations, but their claimed bit is target-bound to the common base
word \(C_0(m)\).  A local modification of one such block cannot force the
opposite coordinate: the PCPP sees a base word far from
\(\mathcal L_{i,1-m_i}\).  A forcing patch must cross the repeated base block and
pay \(\Omega(Kk)\) edits, which is a constant fraction of the entire first
block \(I_1\) of length \(2Kk\).

This is exactly the global-coupling branch of the profile-hitting dichotomy:
the construction does not realize arbitrary low-density coordinate error
profiles by disjoint private patches.  It does **not** show that every
near-linear dPCP has this property, nor does it by itself imply an LDC lower
bound.  A general theorem would have to prove that every candidate
coordinate-robust construction either exposes analogous target binding or
incurs a comparable global coupling cost.

## Source boundary

The block layout and decoder are taken from the proof of Theorem 1.9 in
[Gur--Minzer--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/abs/2512.12960),
Section 11.3: the first block is \(C_0(m)^r\), the \(i\)-th proof block is
\(\pi'_{i,m_i}(C_0(m))\), and the decoder samples one base repetition and then
the \(B\)- and \(A\)-parts of that PCPP.  The proximity-to-rejection estimate is
Theorem 11.1 of the same paper.  The argument above is a derived lemma for
that explicit wrapper; it is not attributed to the paper as a stated theorem.
