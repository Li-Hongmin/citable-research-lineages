# ACRR 的条件熵—support—core 三难

## 定理

在 [熵—完整策略核心不等式](entropy-core-inequality-for-target-dependent-acrr.md) 的
假设下，令 \(D=\kappa(M)\)，令
\[
  B_\sigma=\{m\in\mathcal M:\kappa(m)=\sigma\},
  \qquad
  p_\sigma=\Pr[D=\sigma].
\]
对每个非空 descriptor bucket 定义
\[
  h_\sigma=\log_2|B_\sigma|,
  \qquad
  R_\sigma=\mathbb E[\,|K_M|\,\mid D=\sigma].
\]
令 \(L_\sigma\) 为该 bucket 中所有 finite-time policy 的 full branch-support union。

定义
\[
  G_N(r)=N h_2(r/N)+r\log_2|\Sigma|.
\]
若某个适用的 relaxed-LDC lower-bound theorem 给出函数
\(\Phi_N(L)\)，使得每个 descriptor bucket 的 branch-support compiler 满足
\[
  h_\sigma\le \Phi_N(L_\sigma),
\tag{TSC1}
\]
则对任意消息分布 \(\mu\)，有
\[
  H(M\mid D)
  \le
  \min\left\{
    G_N\!\left(\mathbb E|K_M|\right),
    \mathbb E_{\sigma\sim D}\bigl[\Phi_N(L_\sigma)\bigr]
  \right\}.
\tag{TSC2}
\]

在固定 alphabet、正半径、固定 completeness/soundness gap 的 DGL 窗口中，可以取
\[
  \Phi_N(L)
  =
  C_{\Sigma}\,|\Sigma|^L\log_2|\Sigma|\,
  N^{1-\theta(L)}\log_2(k+2),
  \qquad
  \theta(L)=
  \frac{c}{L^2\log^2(L+2)}.
\tag{TSC3}
\]
这里 (TSC3) 只在外部 relaxed-LDC theorem 的适用窗口内使用，不把该参数式外推到
窗口之外。

## 支持—核心三难的直接形式

设 \(H(M\mid D)\ge\eta k\)，其中 \(0<\eta\le1\)。则：

1. 全局平均 complete-policy core 满足
   \[
     \mathbb E|K_M|=\Omega\!\left(\frac{k}{\log k}\right)
   \]
   （当 \(N=k^{O(1)}\)、\(|\Sigma|\) 固定且 \(\eta\) 为常数）；
2. 还必须有
   \[
     \mathbb E_{\sigma\sim D}[\Phi_N(L_\sigma)]\ge\eta k.
   \tag{TSC4}
   \]

更具体地，令
\[
  A_\sigma=H(M\mid D=\sigma).
\]
因为 \(0\le A_\sigma\le k\)，至少有
\[
  \Pr_{\sigma\sim D}\!\left[A_\sigma\ge\frac{\eta k}{2}\right]
  \ge \frac{\eta}{2-\eta}.
\tag{TSC5}
\]
对每个满足 \(A_\sigma\ge\eta k/2\) 的 bucket，都同时有
\[
  G_N(R_\sigma)\ge\frac{\eta k}{2},
  \qquad
  \Phi_N(L_\sigma)\ge\frac{\eta k}{2}.
\tag{TSC6}
\]
因此常数比例的 descriptor buckets 必须同时支付大的 complete-policy core 和离开
低局部性 relaxed-LDC 窗口的 all-policy support；不能只把高熵目标藏在少数 descriptor
桶中。

## Transcript-entropy refinement

For each descriptor bucket \(\sigma\), suppose the finite-time verifier uses at most
\(r_\sigma\) random bits, observes at most \(m_\sigma\) Merlin transcript bits, and makes at
most \(q_\sigma\) proof-symbol queries. Put

\[
  T_\sigma
  =q_\sigma\,2^{r_\sigma+m_\sigma}|\Sigma|^{q_\sigma}.
\tag{TSC9}
\]

The transcript-support bound gives \(L_\sigma\le T_\sigma\). Whenever
\(\Phi_N\) is monotone on the relevant window, (TSC2) therefore strengthens to

\[
  H(M\mid D)
  \le
  \min\left\{
    G_N(\mathbb E|K_M|),
    \mathbb E_{\sigma\sim D}[\Phi_N(T_\sigma)]
  \right\}.
\tag{TSC10}
\]

In particular, for every bucket with \(A_\sigma\ge\eta k/2\), the DGL threshold forces

\[
  q_\sigma\,2^{r_\sigma+m_\sigma}|\Sigma|^{q_\sigma}
  \ge
  c_\eta\,
  \frac{(\log_2 k)^{1/3}}
       {(\log_2\log_2(k+2))^{2/3}},
\tag{TSC11}
\]

and hence

\[
  r_\sigma+m_\sigma+\log_2q_\sigma+q_\sigma\log_2|\Sigma|
  \ge
  \frac13\log_2\log_2 k
  -\frac23\log_2\log_2\log_2(k+2)
  -O_\eta(1).
\tag{TSC12}
\]

Thus a high-conditional-entropy descriptor bucket cannot simultaneously have a small
complete-policy core, a low all-policy support, and a low-exposure finite-horizon strategy.
For fixed \(q_\sigma\) and fixed alphabet, it must expose
\(\Omega(\log\log k)\) random/response transcript bits.

## 证明

由 descriptor 的定义，
\[
  H(M\mid D)=\sum_\sigma p_\sigma H(M\mid D=\sigma)
  \le\sum_\sigma p_\sigma\log_2|B_\sigma|.
\]
由 (TSC1)，右侧至多
\[
  \sum_\sigma p_\sigma\Phi_N(L_\sigma)
  =\mathbb E_{\sigma\sim D}[\Phi_N(L_\sigma)].
\tag{TSC7}
\]

另一方面，熵—核心定理在每个 bucket 内给出
\[
  H(M\mid D=\sigma)\le G_N(R_\sigma).
\]
函数 \(G_N\) 在 \([0,N]\) 上凹；Jensen 不等式遂给出
\[
  H(M\mid D)
  \le\sum_\sigma p_\sigma G_N(R_\sigma)
  \le G_N\!\left(\sum_\sigma p_\sigma R_\sigma\right)
  =G_N(\mathbb E|K_M|).
\tag{TSC8}
\]
合并 (TSC7) 和 (TSC8) 即得 (TSC2)。

若 \(H(M\mid D)\ge\eta k\)，(TSC2) 的两个右侧都至少为 \(\eta k\)，于是得到
(TSC4) 和平均 core 结论。最后，若
\(q=\Pr[A_\sigma\ge\eta k/2]\)，则
\[
  \eta k\le\mathbb E[A_\sigma]
  \le qk+(1-q)\frac{\eta k}{2},
\]
解得 \(q\ge\eta/(2-\eta)\)，即 (TSC5)。对于这些 bucket，
\[
  A_\sigma\le G_N(R_\sigma),\qquad
  A_\sigma\le\Phi_N(L_\sigma),
\]
从而得到 (TSC6)。

## DGL 窗口的参数含义

若 \(L_\sigma\) 处于低局部性窗口，使得 \(\Phi_N(L_\sigma)=o(k)\)，则
(TSC6) 排除该 bucket 的高条件熵。因而在 \(H(M\mid D)=\Omega(k)\) 时，至少常数
比例的 descriptor buckets 必须有
\[
  L_\sigma^3\log^2(L_\sigma+2)=\Omega(\log k)
\]
（固定 \(|\Sigma|\ge2\)，忽略外部 theorem 的常数），或者必须离开 (TSC3) 的
半径/长度窗口。这里的三次方来自 (TSC3) 中不可忽略的
\(|\Sigma|^{L_\sigma}\) 因子；若只保留 locality exponent 而丢掉该 alphabet 因子，
会错误地得到平方根级阈值。
这比只检查最大 descriptor bucket 更强：它要求高条件熵的整个分布质量支付 support
成本，而不是允许所有信息集中在一个特殊桶。

## 量词边界

本定理需要：

* 同一 descriptor bucket 内使用同一物理 proof 地址空间；
* descriptor 固定后 verifier 不再读取隐藏 target；
* 错误声明对所有 finite-time policies 均 target-relative sound；
* 每个目标每个坐标存在一个 complete policy；
* branch-support compiler 所调用的 relaxed-LDC theorem 对每个 bucket 的任意 valid
  codeword 子集成立。

独立 proof oracle、selected-policy-only soundness、zero-radius/codeword-only 语义以及
真正无界或连续的信息模型不在结论内。单一固定目标满足 \(H(M\mid D)=0\)，因此本定理
不会把 RW 的单目标问题伪装成 family-level lower bound。

## 与已有结果的关系

* 熵—核心定理给出 (TSC8) 的第一项；
* branch-support barrier 和 descriptor-payload lifting 给出 (TSC7) 的第二项；
* 本定理的新增内容是把二者按 descriptor 的条件熵统一起来，并得到 (TSC5)--(TSC6)
  的分布级三难，而不是最大桶或单一目标的结论。

## 证据边界

(TSC1)--(TSC8) 的组合证明是自足的；只有选择具体 \(\Phi_N\) 时才依赖外部
relaxed-LDC 下界。它是一个 derived support--core theorem，不声称已经证明所有
near-linear ACRR 不可能，也不直接解决 \(P\ne NP\)。
