# Binary family-level ACRR: relaxed-LDC baseline or bottom-or-cubic dichotomy

## Theorem

Let

\[
  \Pi:\{0,1\}^{k}\longrightarrow\{0,1\}^{P}
\]

be an arbitrary injective proof map. For every message coordinate (i) and claim
(b\in\{0,1\}), let (V_{i,b}) be a randomized, possibly adaptive verifier making at most
(q) proof queries, and write

\[
  p_{i,b}(z)=\Pr[V_{i,b}^{z}=1].
\]

Assume fixed (\rho>0) and (\alpha>\beta\) such that

\[
  p_{i,m_i}(\Pi(m))\ge\alpha,
  \qquad
  \operatorname{dist}(z,\Pi(m))\le\rho
  \Longrightarrow
  p_{i,1-m_i}(z)\le\beta
\]

for every (m,i,z). Define the half-radius two-branch mass

\[
  \tau_{\rho/2}
  =\inf_{m,i}\ \inf_{\operatorname{dist}(z,\Pi(m))\le\rho/2}
     \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr).
\]

Then:

1. **Unconditional relaxed-LDC baseline.** For every (0<\delta<\rho), the proof map is a
   relaxed locally decodable code with locality
   \[
     Q=O\!\left(q(\alpha-\beta)^{-2}\right).
   \]
   Consequently, whenever the fixed-parameter Dall’Agnol--Gur--Lachish lower bound applies,
   \[
     P\ge k^{1+1/O(Q^2\log^2(Q+2))}.
   \tag{B1}
   \]

2. **Two-query bottom-or-cubic dichotomy.** Suppose (q=2) and (\beta\le1/3). Then
   either
   \[
     \tau_{\rho/2}<\frac23+\beta,
   \tag{B2}
   \]
   or
   \[
     k+P=\Omega_{\rho,\beta}\!\left(\frac{k^3}{\log^6 k}\right).
   \tag{B3}
   \]

Thus every binary, two-query, positive-radius, constant-gap family below the three-query
LDC threshold must exhibit an explicit **bottom witness**: a target, coordinate, and
half-radius near-proof on which the two claim branches have total acceptance mass below
(2/3+\beta). The result does not assume linearity, projection constraints, or nonadaptive
queries.

## Proof

For (1), the wrong branch is at most (\beta) on every (\rho)-near proof, while the
correct branch is at least (\alpha) on the exact codeword. Thresholding the two branches
with independent repetition gives a relaxed local decoder with
(Q=O(q(\alpha-\beta)^{-2})) queries. The same completeness/soundness contradiction shows
that distinct proof words have distance greater than (\rho). This is exactly the
target-relative relaxed-LDC compiler, so (B1) is the external DGL lower bound.

For (2), assume (B2) fails. Then

\[
  \tau_{\rho/2}\ge\frac23+\beta,
  \qquad
  \varepsilon_0:=\max\{\beta,1-\tau_{\rho/2}+\beta\}\le\frac13.
\]

Inline the message bit and define

\[
  C(m)=m\,\|\,\Pi(m).
\]

The proof-image distance (>\rho) and the binary Singleton bound imply, for (k\ge2),

\[
  \frac{P}{k+P}\ge \frac{1}{3-2\rho}.
\]

Indeed, the Singleton inequality is \(k\le P(1-\rho)+1\), and the weaker displayed
bound is sufficient below. Thus the inline code has relative distance at least
\(\rho P/(k+P)\ge \rho/(3-2\rho)\). Set

\[
  \delta_0:=\frac{\rho}{2(3-2\rho)}.
\]

A received word in relative distance \(\delta_0\) from (C(m)) has its proof suffix within
(\rho/2) of (\Pi(m)). To decode coordinate (i),
read the inline bit (b), run (V_{i,b}) on the suffix, and output (b) on acceptance and
(1-b) on rejection. This uses three queries. If (b=m_i), the total-mass condition and
wrong-branch bound give correct-branch acceptance at least
\(\tau_{\rho/2}-\beta\), so the error is at most
\(1-\tau_{\rho/2}+\beta\). If (b\ne m_i), an error can occur only when the wrong branch
accepts, which has probability at most \(\beta\). Thus (C) is a constant-radius,
constant-distance three-query binary LDC with error at most (1/3). The GMWZ three-query
LDC lower bound gives (B3).

## Interpretation and scope

Part (1) is the general family-level barrier: allowing (\bot\) still incurs the relaxed-LDC
length lower bound. Part (2) identifies the only remaining escape inside the binary two-query
window: simultaneous rejection on a half-radius near-proof. The theorem is not an
impossibility result for a single target, for vanishing radius, for growing alphabet/query
parameters, or for ordinary average/list soundness without target-relative near-oracle
quantifiers.

## Sources

* [Radius-to-relaxed-LDC barrier](radius-to-relaxed-ldc-barrier.md)
* [Three-query one-shot non-bottom ACRR barrier](three-query-nonbottom-acrr-cubic-ldc-barrier.md)
* [Dall’Agnol--Gur--Lachish, TR20-154](https://eccc.weizmann.ac.il/report/2020/154/)
* [Gur--Minzer--Weissenberg--Zheng, Theorem 1.10](https://arxiv.org/html/2512.12960#S1.2.2)
