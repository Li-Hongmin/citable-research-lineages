# Target-relative singleton distributional dPCP enters the RLDC barrier

## Theorem

Let the target words be indexed by \(m\in\{0,1\}^k\), with target word equal to \(m\),
and let

\[
  \Pi:\{0,1\}^k\longrightarrow\{0,1\}^{P}
\]

be a global proof map. Assume one dPCP address space is used for every target coordinate
and every message. For every coordinate \(i\in[k]\) and declaration \(b\in\{0,1\}\), let
\(V_{i,b}\) be one fixed, message-oblivious verifier making at most \(q\) adaptive proof
queries. Assume the dPCP's output-coordinate marginal is uniform on \([k]\).

Assume there is a target-relative radius \(\rho_P>0\) and an average soundness parameter
\(\varepsilon\) with the following properties:

1. **Perfect completeness.** For every \(m\) and \(i\),
   \(V_{i,m_i}(\Pi(m))\) accepts with probability one.
2. **Near-oracle singleton distributional soundness.** For every target \(m\) and every
   candidate proof \(z\) satisfying
   \[
     \operatorname{dist}(z,\Pi(m))\le\rho_P,
   \]
   the dPCP's coordinate-averaged singleton list guarantee is at most
   \(\varepsilon\). Equivalently, after conditioning on coordinate \(i\), the wrong
   declaration obeys
   \[
     \Pr[V_{i,1-m_i}(z)=1]\le\beta,
     \qquad \beta:=k\varepsilon .
   \tag{1}
   \]
   The equivalence is exactly the singleton conditioning bridge; the list may be
   \(\{m\}\) or empty, but the quantifier is restricted to the
   \(\rho_P\)-neighborhood of \(\Pi(m)\).

Define the message-inline code

\[
  C(m)=m\,\|\,\Pi(m)\in\{0,1\}^{N},\qquad N=k+P.
\tag{2}
\]

If \(\beta<1\), then:

* the proof map automatically has pairwise distance
  \[
    \operatorname{dist}(\Pi(m),\Pi(m'))>\rho_P
    \qquad(m\ne m'),
  \tag{3}
  \]
  and hence \(C\) has relative distance strictly larger than
  \[
    \Delta_C:=\frac{\rho_P P}{k+P};
  \tag{4}
  \]
* for every \(\rho<\Delta_C\), reading \(y_i\), setting \(b=y_i\), and running
  \(V_{i,b}\) on the proof suffix of \(y\) gives a weak adaptive \((q+1,\rho)\)-RLDC:
  on \(C(m)\) it outputs \(m_i\) with probability one, and on every
  \(\rho\)-near oracle it outputs only \(m_i\) or \(\bot\), with wrong-output probability
  at most \(\beta\).

If the RLDC convention requires success probability \(2/3\), repeat the verifier
\(R=O((1-\beta)^{-2})\) times and output \(b\) only when the empirical acceptance rate
exceeds a threshold strictly between \(\beta\) and \(1\). The resulting standard weak
RLDC has

\[
  Q=O\!\left((q+1)(1-\beta)^{-2}\right)
\tag{5}
\]

queries and the same positive radius.

### Near-linear obstruction

Fix a finite proof alphabet (binary in the statement above), constant \(q\), a constant
\(\rho_P>0\), and a constant \(\beta<1\). If \(P=\Omega(k)\), then the external
constant-radius relaxed-LDC lower bound gives

\[
  k+P\ge k^{1+\eta_Q}
\tag{6}
\]

for some \(\eta_Q>0\) depending only on the fixed locality and alphabet parameters.
Therefore a target-relative singleton distributional dPCP satisfying all assumptions
cannot have \(P=O(k\,\operatorname{polylog} k)\).

Equivalently, a near-linear construction must sacrifice at least one of:

* average soundness \(\varepsilon=O(1/k)\);
* a target-relative radius \(\rho_P=\Omega(1)\);
* fixed locality or alphabet;
* a message-oblivious common proof/address family.

### Distributional--RLDC dichotomy

The preceding statements can be packaged as a direct asymptotic test for a proposed
near-linear construction. Suppose that `q`, `rho_P>0`, the proof alphabet, and the
completeness/soundness threshold are fixed, and that the common proof family has

```text
P(k) <= k (log(k+2))^c
```

for a fixed `c`. If the target-relative singleton average error obeys

```text
epsilon_k <= beta/k
```

eventually for any fixed `beta<1`, the conditioning bridge gives the constant
coordinate gap `beta`, and the theorem above forces `k+P(k) >= k^(1+eta_Q)`,
contradicting near-linearity. Hence every such family must satisfy

```text
limsup_{k -> infinity} k epsilon_k >= 1,
```

or else leave at least one of the fixed-parameter, target-relative, common-address-space
assumptions. In particular, simply combining a fixed-`epsilon` near-linear dPCP with
singleton conditioning cannot reach simultaneous coordinate robustness: the required
`1/k`-scale error is exactly the regime in which the RLDC length barrier activates.

This is a theorem-level parameter dichotomy, not a claim about all dPCPs.  It leaves two
genuine top-level possibilities: construct a new coordinate-normalized/target-binding
mechanism that escapes the hypotheses, or prove that every such escape pays a comparable
coding, proof-length, or locality cost.

This is a conditional barrier for the target-relative family model, not a lower bound against
all dPCPs or all single-target constructions.

## Proof

Take distinct \(m\ne m'\), and choose \(i\) with \(m_i\ne m'_i\). If
\(\operatorname{dist}(\Pi(m),\Pi(m'))\le\rho_P\), apply (1) with target \(m\) and
candidate proof \(z=\Pi(m')\). Since \(m'_i=1-m_i\), it gives

\[
  \Pr[V_{i,m'_i}(\Pi(m'))=1]\le\beta.
\]

Perfect completeness for target \(m'\) gives the same probability equal to one, a
contradiction. This proves (3). The message prefixes can only add distance, so (4) follows.

Now let \(y\) be within relative distance \(\rho<\Delta_C\) of \(C(m)\). Its proof suffix
\(z\) differs from \(\Pi(m)\) in fewer than \(\rho_P P\) positions. If \(y_i=m_i\), the
decoder can output only \(m_i\) or \(\bot\), never a wrong bit. If \(y_i\ne m_i\), it
invokes \(V_{i,1-m_i}\) on \(z\), which is covered by (1), so its acceptance probability
is at most \(\beta\). This proves the one-shot RLDC guarantee. Repetition and thresholding
give (5) by a Chernoff bound; on the exact codeword the correct branch has acceptance
probability one.

## Why the near-oracle restriction is necessary

The restriction to \(z\) near \(\Pi(m)\) is not cosmetic. If (1) were required for every
proof \(z\) while \(V_{i,b}\) remained message-oblivious, any two distinct targets would
make the assumptions inconsistent: choose \(i\) with \(m_i\ne m'_i\), use
\(z=\Pi(m')\), and compare perfect completeness for \(m'\) with wrong-claim soundness for
\(m\). Thus the all-proof singleton bridge is a valid single-target theorem, but it cannot
be promoted to a nontrivial message-oblivious family without becoming vacuous. The
target-relative neighborhood is exactly the standard escape that makes the family model
nonempty and simultaneously enables the RLDC reduction.

## Relation to singleton distributional soundness

The result composes two separate statements:

1. singleton list soundness, restricted to a target-relative neighborhood, gives the
   coordinate bound \(k\varepsilon\);
2. a message-oblivious global proof map with that near-oracle coordinate bound is
   message-inlinable into a relaxed LDC.

The first statement alone gives no proof-map distance. Here distance is forced by the
combination of near-oracle soundness and perfect completeness, as shown in (3). Conversely,
proof-map distance without the \(k\varepsilon\) coordinate guarantee does not give an RLDC.

## Finite proof alphabets

If proof symbols lie in a fixed finite alphabet \(\Sigma\), encode each symbol by a fixed
binary block of length \(\ell=\lceil\log_2|\Sigma|\rceil\). If distinct symbols have binary
block distance at least \(d_\Sigma\ge1\), replace \(\rho_P P\) in (3)--(4) by
\(d_\Sigma\rho_P P\), replace \(N\) by \(k+\ell P\), and replace the locality by
\(q\ell+1\). For fixed \(\Sigma\), this preserves the constant-parameter RLDC barrier.

## Scope and source boundary

The theorem does not assert that current Gur--Minzer--Weissenberg--Zheng dPCPs have a
singleton target family, a target-relative \(\rho_P\)-soundness theorem, or a uniform
\(\varepsilon=\Theta(1/k)\) parameterization. It gives a precise obstruction to obtaining
all three simultaneously at near-linear length. The coding lower-bound input is external;
the project contribution here is the explicit target-relative distributional-to-RLDC
composition and its exact \(k\varepsilon\) accounting.

Related modules:

* [Singleton distributional dPCP conditioning bridge](singleton-distributional-dpcp-coordinate-conditioning-bridge.md)
* [Message-inline RLDC compiler](message-inline-rldc-compiler.md)
* [Radius-to-relaxed-LDC barrier](radius-to-relaxed-ldc-barrier.md)

Primary dPCP source:
[Gur--Minzer--Weissenberg--Zheng, *3-Query RLDCs are Strictly Stronger than 3-Query LDCs*](https://arxiv.org/html/2512.12960).
