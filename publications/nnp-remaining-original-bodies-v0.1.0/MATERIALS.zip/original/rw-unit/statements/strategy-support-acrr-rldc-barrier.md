# Branch-support barrier for finite-response and finite-time interactive ACRR

## Theorem

Let

\[
  C:\mathcal M\longrightarrow \Sigma^N,
  \qquad \mathcal M\subseteq\{0,1\}^k,
\]

be an injective proof/codeword map, with `\Sigma` finite.  For each message coordinate
`i\in[k]` and declaration `b\in\{0,1\}`, let `\mathcal T_{i,b}` be a finite family of
response objects.  For `\tau\in\mathcal T_{i,b}`, let `V_{i,b,\tau}` be a randomized,
possibly adaptive oracle verifier making at most `q` proof-symbol queries.  The response
family and all verifier circuits are independent of the target message.

For an adaptive verifier, define its **full branch support**
`Supp(V_{i,b,\tau})` to be the set of proof positions that can be queried on some random
tape and some sequence of previously returned symbols.  Thus the support includes branches
that are not reached on a particular honest codeword.  Put

\[
  S_i=\bigcup_{b\in\{0,1\}}
      \bigcup_{\tau\in\mathcal T_{i,b}}\operatorname{Supp}(V_{i,b,\tau}),
  \qquad L=\max_i |S_i|.
\]

Write

\[
  p_{i,b,\tau}(z)=\Pr[V_{i,b,\tau}^{z}\text{ accepts}].
\]

Assume constants `\rho>0` and `\alpha>\beta` such that, for every `m\in\mathcal M`:

1. **Finite-response completeness:** for every `i`, some
   `\tau\in\mathcal T_{i,m_i}` satisfies
   `p_{i,m_i,\tau}(C(m))\ge\alpha`;
2. **All-response target-relative soundness:** for every `i`, every
   `\tau\in\mathcal T_{i,1-m_i}`, and every `z` with
   `dist(z,C(m))\le\rho`,
   `p_{i,1-m_i,\tau}(z)\le\beta`.

Then, for every `0<\delta<\rho`, `C` is a weak adaptive relaxed locally decodable code at
radius `\delta` with locality at most `L`.  In fact, under the usual finite-random-tape
model, the decoder can be deterministic and has perfect codeword completeness and zero
wrong-output probability on every `\delta`-near oracle.  If acceptance probabilities are
only estimated rather than exhaustively evaluated, the same locality `L` is retained; only
unbounded local computation is replaced by internal sampling.

The proof image also has relative distance strictly larger than `\rho`.

The important parameter is the **union of all possible queried positions**, not the number of
response objects.  An arbitrarily large finite response family is harmless when all branches
reuse a small common support; conversely, an unbounded-response escape must expose a large
branch support or leave the theorem's finite-response semantics.

### Finite-horizon all-policy extension

The finite-family wording is not a serious escape in the usual interactive-verifier model.
Suppose the response interface has a fixed finite number of rounds, uses a finite random tape,
each response symbol lies in a finite alphabet `\Gamma_N` (which may grow with `N`), and a
response policy may depend on the information exposed by the verifier (for example, public
randomness, previous messages, and previously returned proof symbols).  For fixed `N`, `q`,
and finite alphabets, the view tree has finitely many nodes, so the set
`\mathfrak P_{i,b}` of all deterministic response policies is finite, even though its size
may be doubly exponential.  More explicitly, if the view tree has `W_N` admissible policy
nodes, then `|\mathfrak P_{i,b}|\le |\Gamma_N|^{W_N}`.  Define

\[
  S_i^{\mathrm{all}}=\bigcup_{b\in\{0,1\}}
      \bigcup_{\pi\in\mathfrak P_{i,b}}\operatorname{Supp}(V_{i,b,\pi}),
      \qquad L_{\mathrm{all}}=\max_i|S_i^{\mathrm{all}}|.
\]

If completeness is witnessed by one policy in `\mathfrak P_{i,m_i}` and wrong-declaration
soundness holds for every policy in `\mathfrak P_{i,1-m_i}`, the theorem applies verbatim with
`L=L_{\mathrm{all}}`.  Randomized response policies add no larger extremum: their acceptance
probability is a convex combination of deterministic view-tree policies.  The relaxed decoder
may enumerate all policies offline; this has no effect on query locality.  Thus, under a standard
finite-horizon finite-alphabet Merlin
interface, an arbitrarily long **description** of a strategy is not by itself a semantic
escape.  The remaining escape must be a large all-policy branch support, target-dependent
proof/strategy semantics, an unbounded/continuous interaction model, or a failure of the
all-policy soundness quantifier.

Thus the finite-family theorem has the following standard interactive corollary: for every
fixed `N`, finite-round finite-alphabet Merlin protocols satisfy the same conclusion with
`L=L_{\mathrm{all}}`, even when response strings are exponentially long and the policy table is
doubly exponential in `N`.  If the verifier's randomness is private, it is simply omitted from the policy's
view; the finiteness argument and the support union are unchanged.  This corollary makes no
polynomial-time or succinctness claim about enumerating the policy table.

### Finite-time bit-model closure

The finite-round assumption can be derived from the verifier's own time bound.  Let a standard
bit-model verifier on block length `N` use at most `T_N<infinity` steps, random bits, and
message/proof-symbol observations.  Even if Merlin is allowed to send an arbitrary finite string
and compute an arbitrary (not necessarily computable within `T_N`) strategy, only the portion of
that string observed during the `T_N` steps can affect the verifier's view.  Quotienting strategies
by this observed view gives a finite policy tree (its size may be enormous, but finiteness is
the only property used); all remaining message bits are semantically irrelevant.  Therefore the
all-policy branch-support conclusion applies to every finite-time bit-model verifier, not merely
to protocols whose message length was fixed in advance.  A purported escape must instead use
unbounded verifier time, an infinite/continuous message alphabet, or a nonstandard operation that
reveals unbounded information in one step.

### Transcript-entropy support bound

The all-policy support can itself be bounded by the amount of transcript information that the
verifier exposes. Fix \(i,b\). Suppose the verifier uses at most \(r\) random bits, makes at
most \(q\) proof-symbol queries, and observes at most \(m\) bits of Merlin's response
transcript in total. Then, for a finite proof alphabet \(\Sigma\),

\[
  \bigl|\operatorname{Supp}_{\mathrm{all}}(V_{i,b})\bigr|
  \le q\,2^{r+m}|\Sigma|^q.
\tag{TS1}
\]

Here a response alphabet \(\Gamma\) with several symbols is counted by
\(m=\lceil\log_2|\Gamma_{\mathrm{view}}|\rceil\), where
\(\Gamma_{\mathrm{view}}\) is the set of complete response views that the verifier can
observe. The bound remains valid for adaptive query and response policies.

Indeed, an all-policy execution is determined, as far as future addresses are concerned, by
the verifier's random tape, the observed response view, and the at most \(q\) proof-symbol
answers. There are at most \(2^r\), \(2^m\), and \(|\Sigma|^q\) choices respectively, and
each transcript contains at most \(q\) query addresses. Taking their union gives (TS1).
Consequently, whenever the branch-support theorem applies, a finite-response construction
with small exposed transcript entropy automatically yields an RLDC with locality bounded by
the right-hand side of (TS1), regardless of the number or description length of the response
policies.

Combining (TS1) with the displayed DGL-window threshold gives a concrete escape budget:
in a fixed-alphabet near-linear family, the exposed entropy
\(r+m+q\log_2|\Sigma|\) must be large enough that
\(q2^{r+m}|\Sigma|^q\) leaves the applicable relaxed-LDC window. This is a quantitative
version of the statement that a long Merlin string is not an escape unless the verifier
actually exposes enough of it to widen its address support.

### Corollary (transcript-entropy lower bound)

Assume the external relaxed-LDC theorem is used in the same fixed-alphabet, positive-radius
near-linear window and yields the support threshold

\[
  L\ge c_0\,
  \frac{(\log_2 k)^{1/3}}
       {(\log_2\log_2(k+2))^{2/3}}
\tag{TS2}
\]

for all sufficiently large \(k\). Then every finite-horizon ACRR protocol as above must
satisfy

\[
  q\,2^{r+m}|\Sigma|^q
  \ge c_0\,
  \frac{(\log_2 k)^{1/3}}
       {(\log_2\log_2(k+2))^{2/3}}.
\tag{TS3}
\]

Equivalently,

\[
  r+m+\log_2 q+q\log_2|\Sigma|
  \ge
  \frac13\log_2\log_2 k
  -\frac23\log_2\log_2\log_2(k+2)
  -O(1).
\tag{TS4}
\]

In particular, for fixed \(q\) and fixed \(|\Sigma|\ge2\), the verifier must expose
\(\Omega(\log\log k)\) bits of random/response transcript information. This is conditional on
the external DGL window; it is a communication lower bound for the finite-horizon escape
class, not an unconditional lower bound for arbitrary dPCPs.

## Proof

Fix a requested coordinate `i`.  The decoder queries every position in `S_i` once and caches
the resulting symbols.  Given the cached restriction of an oracle `z`, it can simulate every
`V_{i,b,\tau}` on every random tape: every address that any adaptive execution can request is
in `S_i`, by definition of full branch support.  Let

\[
  a_{i,b}(z)=\max_{\tau\in\mathcal T_{i,b}}p_{i,b,\tau}(z).
\]

Set `\theta=(\alpha+\beta)/2`.  Output `b` if exactly one of
`a_{i,0}(z),a_{i,1}(z)` is at least `\theta`; otherwise output `\bot`.

On `C(m)`, finite-response completeness gives
`a_{i,m_i}(C(m))\ge\alpha`.  Since `C(m)` lies in its own `\rho`-neighborhood,
all-response soundness gives `a_{i,1-m_i}(C(m))\le\beta`.  Hence the decoder outputs `m_i`.

If `dist(z,C(m))\le\delta<\rho`, all wrong-declaration responses still satisfy
`a_{i,1-m_i}(z)\le\beta<\theta`.  Therefore the decoder cannot output `1-m_i`; it outputs
`m_i` or `\bot`.  Only the positions in `S_i` were queried, so the locality is at most `L`.

For distance, take distinct messages `m,m'` and a coordinate `i` with `m_i\ne m'_i`.
Suppose `dist(C(m),C(m'))\le\rho`.  By completeness for `m'`, choose
`\tau\in\mathcal T_{i,m'_i}` with
`p_{i,m'_i,\tau}(C(m'))\ge\alpha`.  Relative to target `m`, this is a wrong declaration,
and `C(m')` is in the target neighborhood, so all-response soundness gives the same quantity
at most `\beta`, a contradiction.  Thus every pair of distinct codewords has distance
strictly larger than `\rho`.

## Consequences

### Support, not response count, is the locality budget

If every verifier branch is nonadaptive and each response uses at most `q` positions, then
`L\le 2q\max_{i,b}|\mathcal T_{i,b}|`, recovering the usual finite-mode enumeration bound.
For adaptive verifiers this crude product can be very loose: the exact union support `L`
accounts for shared addresses across responses and transcripts, while charging every address
that an adaptive branch can reach.

Thus a finite-response ACRR candidate can avoid a response-count barrier only by making its
response-dependent query trees collectively wide.  If the trees all remain inside an
`L=poly(n,\log(T+2))` address-scale support, the proof map itself is an `L`-query relaxed
LDC and inherits the applicable coding lower bound.

### Near-linear parameter test

Assume the adaptive relaxed-LDC lower bound is available at locality `L`, with fixed alphabet,
positive radius and fixed completeness threshold.  In the common parameterization

\[
  N\ge k^{\,1+1/O(L^2\log^2(L+2))},
\]

a purported near-linear family `N\le k(\log(k+2))^c` must satisfy

\[
  L^2\log^2(L+2)
  =\Omega\!\left(\frac{\log k}{\log\log(k+2)}\right),
\]

up to the constant in the external lower bound.  Consequently, constant-support and
polylogarithmic-support finite-response constructions are ruled out in the corresponding
fixed-parameter window.  This is a support-sensitive strengthening of response enumeration;
it does not assume that the response family has bounded cardinality.

For the finite-horizon all-policy extension, the same inequality holds with
`L=L_{\mathrm{all}}`, regardless of the size of the response alphabet or of the number of
view-tree policies.  In particular, in this lower-bound window a near-linear proof forces
the conservative threshold
`L_{\mathrm{all}}^3\log^2(L_{\mathrm{all}}+2)=\Omega(\log k)` up to the external theorem's
constants, hence
`L_{\mathrm{all}}=\Omega((\log k)^{1/3}/(\log\log(k+2))^{2/3})` when `|\Sigma|>=2` is fixed.
The `|\Sigma|^{L}` factor in the displayed DGL bound is essential; dropping it would
incorrectly produce a square-root threshold.

Indeed, after dividing the DGL upper bound by `k` and taking logarithms, the near-linear
assumption gives

```text
c log k / (L^2 log^2(L+2)) <= O(L + log log(k+2)).
```

Whenever `L` dominates `log log k`, this implies
`L^3 log^2(L+2)=Omega(log k)`; the remaining regime is weaker than the displayed bound.

### Relation to RW/JK address scale

For a RW/JK candidate whose response objects are finite but whose possible query addresses all
fit in `poly(n,\log T)` positions, the theorem supplies a direct route from the same global proof
to a low-locality relaxed code.  To remain outside the relaxed-LDC barrier, a candidate must
make at least one of the following explicit:

* the union branch support is large (often exposing a global portion of the proof);
* the response object is genuinely non-finite or cannot be enumerated in the verifier model;
* the wrong-response soundness is not uniform over responses;
* the family is target-specific, the proof address space changes, or the radius/gap degenerates.

The theorem therefore sharpens the residual ``unbounded strategy'' class in the strategy
compression trilemma: unbounded response length alone is not an escape if all responses still
use a small common address support.

## Scope and non-implications

The result is family-level and target-relative.  It does not apply to a single fixed RW/JK
target, to codeword-only soundness with no positive-radius promise, or to a verifier whose
response family is target-dependent.  It does not cover genuinely infinite/continuous
interactions or verifiers with unbounded time; finite-time bit-model protocols with arbitrary
finite Merlin strings are covered by the preceding closure.  These nonstandard models are not
silently covered by this theorem.

The statement is a query-locality theorem: exhaustive simulation over responses and random
tapes is free in the locality measure.  If a construction additionally requires polynomial
running time or a succinct decoder description, those are separate costs and can only make the
escape narrower.

## Relation to existing modules

* [Radius-to-relaxed-LDC barrier](radius-to-relaxed-ldc-barrier.md) is the special case with
  one verifier per claim and direct thresholding of the two branches.
* [Payload lifting family barrier](payload-lifting-family-barrier.md) bounds descriptor entropy
  when a fixed context carries a high-entropy payload.
* [Sim-CR strategy-compression trilemma](strategy-compression-trilemma-for-simcr.md) leaves
  unbounded post-coordinate strategies as the remaining class; the present theorem closes the
  finite-response/small-support portion of that class.
* [Profile-hitting necessity](profile-hitting-necessity-for-coordinate-robustness.md) studies
  the complementary route in which a construction deliberately concentrates its query support.

The all-policy extension is deliberately a query-locality statement.  It does not claim that
the offline policy enumeration is polynomial-time or succinct; adding such a uniformity
requirement only strengthens the resulting barrier.

## Evidence boundary

The compiler proof above is elementary and self-contained.  The displayed near-linear
consequence invokes the external relaxed-LDC lower bound with locality `L`; it is not a new
proof of that coding lower bound.  The genuinely open question is whether a RW/JK-compatible
global proof can use a large, target-relative, word-consistent branch support without paying an
independent address-scale or parent-closure cost.

## Sources

* [Dall'Agnol--Gur--Lachish, TR20-154](https://eccc.weizmann.ac.il/report/2020/154/)
* [Radius-to-relaxed-LDC barrier](radius-to-relaxed-ldc-barrier.md)
