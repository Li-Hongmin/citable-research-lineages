# RW/JK 多输入 tuple-supply 参数障碍

## 定理地位

本定理把固定 history 的窗口计数推广到一个自然的“多输入修复”模型：同一个
AVOID decoder \(G\) 接收一个输入族 \(f(x)\)，而不同 \(x\) 可能各自产生一条
failure/easy-JK history。结论是，在 RW 当前的时间递推下，即使把所有输入、所有
选定 history 和所有互不重复的 aligned groups 都乐观地合并，仍不足以触发
JK tree-capacity forcing。

这是一条 **RW-specific 的参数性路线关闭**，不是一般 PCP、dPCP 或 ACRR 的
不可能性定理。它只处理实际被构造并可放进一次显式 history 的 tuples；compressed
tuple oracle、内部结构性 richness、全新的 JK 定理和独立 hard-history lower bound
仍不在本定理范围内。

## 形式化模型

固定

* \(G:\{0,1\}^{k}\to\{0,1\}^{2k}\)；
* 输入域 \(X\subseteq\{0,1\}^{n}\)；
* 对每个 \(x\in X\)，一条被实际选定的 canonical/actual history
  \(\Pi_x\)，满足
  \[
  |\Pi_x|\le L(t)\le t^{a},
  \tag{1}
  \]
  其中 \(t\) 是多输出长度，\(a\) 是所用 PCP 编码的固定常数；
* JK block 宽度 \(2k\)，以及深度 \(h\) 的 aligned group：连续的
  \(2^{h}\) 个、按 \(2k\) 对齐的 blocks。

只把 \(\Pi_x\) 中实际出现的这些 groups 计入 tuple family
\(\mathcal T_h\)。不同 history 的 groups 可以相同；为了得到上界，我们甚至假设
它们全部不同。重要的是，每个 \(x\) 只贡献一条选定 history。若把所有可能的
Merlin/PCP histories 都计入，前因子必须改成实际的 history-pair 数量，本定理
不作这种未证扩张。

## Tuple-supply theorem

在上述模型中，

\[
|\mathcal T_h|
\le
\sum_{x\in X}
\left\lfloor\frac{L(t)}{2k\,2^h}\right\rfloor
\le
\frac{|X|L(t)}{2k\,2^h}
\le
\frac{2^n t^a}{2k\,2^h}.
\tag{2}
\]

因此，任何要求

\[
|\mathcal T_h|>2^k
\tag{3}
\]

才能触发的 root-range 容量反证，都必须满足

\[
n+a\log_2 t
>
k+\log_2(2k)+h.
\tag{4}
\]

### 证明

一个 aligned depth-\(h\) group 占用 \(2^h\cdot 2k\) 个连续 history bits；不重叠
地切分一条长度 \(L(t)\) 的 history，至多得到

\[
\left\lfloor L(t)/(2k2^h)\right\rfloor
\]

个 groups。允许不同 \(x\) 的 groups 全部互异，只会把这些 occurrence 数相加，
得到 (2)。若 (3) 成立，则由 (2)、\(|X|\le2^n\)、\(L(t)\le t^a\) 取
对数即得 (4)。证毕。

若把 group 改成允许重叠的 sliding window，则每条 history 至多有
\(O(L(t)/(2k))\) 个窗口；这只去掉 (2) 中的 \(2^h\) 因子，仍保留后文的指数
时间阻断。这里采用不重叠 aligned groups，是为了精确对应 JK 的 dyadic 对齐。

## 代入 RW Theorem 4.3

沿用 RW 的阶段参数

\[
n_{i+1}=n_i^C,
\qquad
T_i=\max\{2^{cD^i n_0},n_{i+1}\},
\qquad
k=n_{i+1},
\qquad
t=T_i,
\tag{5}
\]

其中 \(C>D+1\)，而输入域即使扩大到上一阶段的全部
\(\{0,1\}^{n_i}\)，也只有 \(n=n_i\) 的输入熵。于是

\[
n_i+a\log_2 T_i
\le
O\!\left(n_i+D^i n_0+C^{i+1}\log n_0\right)
=o\!\left(n_i^C\right)
=o(k).
\tag{6}
\]

这给出：即使所有 \(2^{n_i}\) 个输入都对同一个 \(G\) 走 failure/easy-JK
分支，且每条选定 history 的所有 aligned groups 都互不重复，也只有
\(2^{o(k)}\) 个实际 tuples，远小于 \(2^k\)。原始 RW 归纳实际只调用一个固定
\(x_0\)，此时前因子进一步降为 1。

在稳定区 \(T_i=k\) 时，(2) 具体化为

\[
|\mathcal T_h|
\le
\frac{2^{n_i}k^{a}}{2k2^h}
=2^{n_i+O(\log k)-h},
\tag{7}
\]

仍为 \(2^{o(k)}\)。因此，把 \(f_i\) 从常值改为多输入函数，或把输入域从单点
扩大到 \(2^{n_i}\) 个点，在现有 RW 的尺度跳跃
\(n_i\mapsto n_i^C\) 下都不能供应 tree-capacity 所需的 \(>2^k\) 个 actual tuples。

## 反向时间预算

由 (2)，若只靠输入和 history 数量达到 (3)，忽略 \(2k2^h\) 这一多项式因子，
必须有

\[
t\ge 2^{(k-n)/a}.
\tag{8}
\]

在 RW 的 \(n=o(k)\) 参数区，这意味着 \(t=2^{\Omega(k)}\)。但 Theorem 4.1
的 \(\operatorname{Solve}_{f}\) 运行时间是 \(t^{O(1)}\)，于是该修复把 AVOID
求解推到相对于 child width \(k\) 的指数时间，已不再是原 Theorem 4.3 的
polynomial/smart-prMA 规模。

## 多输入 group action 的边界

形式上可写

\[
f_i(x)=\pi_x(B_i).
\tag{9}
\]

其中 \(B_i\) 是固定 AVOID 输出，\(\pi_x\) 是可计算的 shift 或 group action。
这满足 Theorem 4.1 的多输入接口，但每个 \(x\) 仍对应独立的一次
\(\operatorname{Solve}_{f_i}(x,G)\)，不能把不同运行中的 history 拼成同一条 JK
word。若 range 对 \(\pi_x\) 不变，则一个 outsider 的整个 orbit 仍是 outsider，
无法提供 range 内的 child tuples；若 range 不具不变性，则从一个 outsider 推出
orbit 中存在 range 成员没有一般保证。

更强的 group action、compressed tuple oracle 或共享 whole-tree labeler 可能改变
模型，但那已经是新接口，不是由 Theorem 4.1 的逐实例蕴含自动得到的结果。

## 明确不推出的结论

本定理不证明：

1. 所有 PCP history 都缺少结构性 tuple-richness；
2. 任意 shared-key/whole-tree accessor 都不可能存在；
3. 一般 dPCP、RLDC/LDC 或 ACRR 必须超线性；
4. \(P\ne NP\)。

它只证明：在 RW 现有 \(n_i\to n_i^C\)、\(t=T_i\) 的参数和“实际 history
窗口计数”机制内，多输入 \(f_i\) 不是补足 JK capacity 的充分修复。

## 证据边界

RW Theorems 3.5、4.1、4.3 提供 history 长度、逐实例 failure/easy-JK 蕴含和阶段
递推；(2)--(8) 是本项目的 occurrence-counting 推导。固定 history 的单输入特例
见 [RW fixed-history capacity budget](rw-fixed-history-capacity-budget.md)。
相关的 history 长度与 computation-witness 限制见
[note 166](../../mcsp-hardness-magnification/notes/166-computation-witness-does-not-transfer-hardness-across-rw-scales-2026-08-15.md)。
本文件不把“存在许多候选 accepted proofs”升级为同一 canonical history 的实际
tuple family。
