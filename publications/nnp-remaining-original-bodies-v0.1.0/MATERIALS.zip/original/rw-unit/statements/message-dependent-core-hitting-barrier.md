# Message-dependent core hitting barrier

## 结论地位

这是对 patch-to-common-core information barrier 的严格扩展，专门处理最大的剩余
逃逸：不可 patch 的核心允许同时依赖消息 m 和目标坐标 i。结论不假设存在一个
统一的 K，也不要求补集的所有 private patches 都能任意组合；它只要求针对每个
候选核心存在一个 one-shot K-compatible forcing candidate。由此每个 K_{m,i}
必须命中对应消息 disagreement hypergraph，并得到 fractional transversal 下界。
它仍是条件性 family-level barrier，不宣称一般 dPCP 已自动提供该 candidate 或
disagreement hitting。

## 定理

令 C:{0,1}^k -> Σ^N 为 injective code map。对每个消息 m 和坐标 i，设
K_{m,i}⊆[N] 是 non-patchable core，P_{m,i}=[N]∖K_{m,i} 是 private region。
对目标 (m,i)，假设：

1. 存在一个 one-shot K-compatible forcing candidate W_{m,i}^{K}：它在
   K_{m,i} 上保持 C(m)，在 P_{m,i}=[N]∖K_{m,i} 上沿 honest transcript 直到
   first hit，并在第一次命中 P_{m,i} 时强制错误声明。这里不要求 P_{m,i} 的
   不同 patch 能独立组合；只要求这一个 candidate 对整个 P_{m,i} 同时有效；
2. 对所有候选 proof，错误声明接受率至多 δ；
3. 对每个 m' 满足 m'_i != m_i，honest path 的 disagreement hitting 满足

       Pr[ Q_{i,m_i}^{C(m)} ∩ D(m,m') != ∅ ] >= 1-β,

   其中 D(m,m')={j:C(m)_j != C(m')_j}；
4. 1-δ>β。

则对所有 m' 满足 m'_i != m_i，都有

       K_{m,i} ∩ D(m,m') != ∅.                         (MCH1)

也就是说，K_{m,i} 是 hypergraph

       D_{m,i} = { D(m,m') : m'_i != m_i }

的 transversal。

## 证明

由 one-shot K-compatible candidate、first-hit forcing 和 soundness，global-coupling
mass argument 给出

       Pr[ Q_{i,m_i}^{C(m)} ⊆ K_{m,i} ] >= 1-δ.             (MCH2)

若某个 m' 使 K_{m,i}∩D(m,m')=∅，则事件
Q_{i,m_i}^{C(m)}∩D(m,m') != ∅ 只能发生在 Q 不完全落入 K_{m,i} 的事件上。
因此该事件概率至多 δ，与 disagreement hitting 的下界 1-β 矛盾，因为
δ<1-β。故 (MCH1) 成立。

## Fractional transversal 下界

给定位置成本 c_j>0，定义

       τ_c^*(m,i) =
         min { Σ_j c_j x_j :
               x_j>=0 and
               Σ_{j∈D(m,m')} x_j >= 1
               for every m' with m'_i != m_i }.             (MCH3)

由于 1_{K_{m,i}} 是 (MCH3) 的可行解，必有

       Σ_{j∈K_{m,i}} c_j >= τ_c^*(m,i).                    (MCH4)

线性规划对偶给出等价的 fractional packing 形式：

       τ_c^*(m,i) =
         max { Σ_{m'} λ_{m'} :
               λ_{m'}>=0 and
               Σ_{m': j∈D(m,m')} λ_{m'} <= c_j for every j }. (MCH5)

因此，若能选择一批 opposite-bit 消息，使每个 proof position 只能承载有限的
disagreement weight，就得到一个无需统一 common core 的定量下界。

## 两个直接推论

### 低影响分布推论

若存在 opposite-bit 消息分布 ρ_{m,i}，使

       Pr_{m'~ρ_{m,i}}[j∈D(m,m')] <= r_j  for every j,

则任何 transversal K_{m,i} 都满足

       Σ_{j∈K_{m,i}} r_j >= 1.                              (MCH6)

特别地，若所有 r_j<=r，则 |K_{m,i}|>=1/r。该结论只使用
K_{m,i} 命中每个 disagreement set，不要求 disagreement sets 两两不交。

### 核心重叠容量推论

若每个 proof position j 至多属于 d_j 个 cores K_{m,i}，取 c_j=1 并对所有
(m,i) 求和，则

       Σ_{m,i} τ_1^*(m,i)
          <= Σ_{m,i}|K_{m,i}|
          <= Σ_{j=1}^N d_j.                                (MCH7)

若 d_j<=d，则

       N >= (1/d) Σ_{m,i} τ_1^*(m,i).                       (MCH8)

这是把坐标/消息依赖核心的“重叠容量”显式转成 proof-length 下界的最小接口。
它不把不同目标的 cores 错误地当作一个 common K。

## Specifying-set 计数：无需统一 common core

对每个消息 m 定义

       K_m := ⋃_{i=1}^k K_{m,i}.

由 (MCH1)，若 m'!=m，取任意满足 m'_i!=m_i 的坐标 i，则
K_{m,i} 与 D(m,m') 相交。因此

       C(m)|_{K_m} != C(m')|_{K_m}  for every m'!=m.       (MCH9)

所以 K_m 是 C(m) 的 specifying set：它只需识别 m 自己，不要求同一个 K_m
同时服务其他消息。

若对所有 m 都有 |K_m|<=r，则映射

       m  ↦  (K_m, C(m)|_{K_m})

是单射，从而得到精确计数界

       2^k <= Σ_{s=0}^r binom(N,s)|Σ|^s.                    (MCH10)

因此

       k <= log_2(r+1)
           + r log_2(eN|Σ|/r)                               (MCH11)

（取 1<=r<=N 的标准二项式和上界）。特别地，当 |Σ| 为常数且
N=k^{O(1)} 时，至少有一个消息满足

       |K_m| = Ω(k/log k).                                  (MCH12)

更一般地，若希望所有消息的 target-specific cores 并集都只有 r 个位置，则
(MCH10) 给出 N 与 r 的直接 tradeoff；当 r=polylog(k) 时，N 必须达到
2^{Ω(k/r)} 的量级（忽略多项式因子）。

这条计数不要求 K_{m,i} 在不同消息之间相同，也不要求各坐标核心相交；它只使用
每个 K_m 对自身 codeword 的 specifying-set 性质。因此它正好攻击 common-core
定理留下的 message-dependent escape。

### 对地址尺度的直接后果

若字母表大小固定、N=k^{O(1)}，并且一个候选 ACRR 只允许每个消息使用
s(n) 个 target-specific core positions 的并集，则 (MCH11) 给出

       k <= O( s(n) log(kN/s(n)) ).                          (MCH13)

因此，当输出维度 k=2^{Ω(n)} 而 s(n)=poly(n) 时，(MCH13) 不可能成立。这个推论
不要求存在一个跨消息的 common core；它只要求所有 K_{m,i} 的并集都能由
address-scale 的短 key/短 patch description 约束在 s(n) 个位置以内。

### 线性 code 的加强：核心并集必须是信息集

若 C:F_2^k -> F_2^N 是线性 code，则对固定 m 和任意 v∈F_2^k，取
m'=m+v。对每个 i 满足 v_i=1，有

       D(m,m') = supp(C(v))

并且由 (MCH1)，K_{m,i} 必须命中 supp(C(v))。令
K_m=union_i K_{m,i}。若 C(v)|_{K_m}=0 且 v!=0，选择一个 v_i=1，则
K_{m,i}⊆K_m 与 supp(C(v)) 不相交，矛盾。因此

       C(v)|_{K_m}=0  implies  v=0,

即线性映射 C restricted to K_m 是 injective。于是

       |K_m| >= k.                                           (MCH14)

这个结论不要求 K_{m,i} 在不同消息或坐标之间相同；它只利用线性差分把所有
opposite-bit disagreement sets 统一成 supp(C(v))。因此，对二元线性 RLDC/PCP，
message-dependent core 不能把信息核心降到 o(k)。

## 边界与反例

该定理本身不保证 τ_c^* 很大。系统编码 C(m)=m 的固定坐标 i 对所有 opposite
messages 都在坐标 i 处 disagreement；此时 τ_1^*(m,i)=1，K_{m,i}={i} 完全符合
(MCH1)。因此要得到超线性结果，必须从具体 code/proof family 证明：

* disagreement hypergraphs 没有小的公共 transversal，或
* 每个 proof position 的 core-incidence d_j 很小，或
* 两者的 fractional 组合足够大。

同样，平均/list/distributional soundness 不提供 one-shot K-compatible candidate；
逐坐标分别存在 candidate proof 也不能自动构造一个对整个 P_{m,i} 同时有效的
candidate。若
disagreement hitting 仅对某个消息分布而非所有 m' 成立，应将 (MCH3) 改为相应的
受限 hypergraph，不能直接使用全 family 结论。

## 与已有模块的关系

* 当所有 K_{m,i}=K 时，MCH1 退化为 common-core information barrier 的 hitting
  关键步，但这里保留了坐标/消息依赖性。
* C46 约束的是一个联合 forcing proof 的 shared-base 腐蚀成本；本定理约束的是
  每个 target-specific non-patchable core 必须覆盖哪些 message disagreements。
  两者可叠加：先用 C46 估计核心预算，再用 (MCH4)--(MCH8) 估计核心的总容量。
* (MCH10)--(MCH12) 是纯组合的新增障碍：只要 MCH1 已由 proof-graph 条件得到，
  就能在不构造统一 core 的情况下关闭“每个消息都有短 target-specific core”这一
  逃逸。剩余任务是从一个 near-linear coordinate-robust proof graph 中证明 one-shot
  K-compatible candidate 与 disagreement-hitting，或进一步加强其 specifying-set
  计数。

## Descriptor-restricted specifying-set barrier

前面的 MCH10 把所有消息放在同一个 specifying-set 计数中。若 verifier、address
permutation 或 target-binding 机制由一个短 descriptor 选择，则更准确的量词是：只有
同一 descriptor 桶内的消息必须由同一个物理 proof 地址空间区分。这个放宽仍有一个
严格的熵—核心不等式。

令 `M` 为消息族，`|M|=2^h`，令

```text
κ : M -> {0,1}^s
Y : M -> Sigma^N
```

其中 `Y(m)` 是共享物理地址空间上的目标词；不要求不同 descriptor 桶之间共享
verifier 语义。对每个 `m` 给定一个集合 `K_m⊆[N]`，并假设

```text
Y(m)|_{K_m} != Y(m')|_{K_m}
for every m' != m with κ(m') = κ(m).                 (DCS1)
```

若 `|K_m|<=r` 对所有 `m` 成立，则

```text
2^h <= 2^s * sum_{t=0}^r binom(N,t)|Sigma|^t.          (DCS2)
```

等价地，在 `1<=r<=N` 时，

```text
h-s <= log_2(r+1) + r log_2(eN|Sigma|/r).              (DCS3)
```

### 证明

把每个消息编码为三元组

```text
(κ(m), K_m, Y(m)|_{K_m}).
```

若两个消息的三元组相同，则它们属于同一 descriptor 桶、使用同一个 `K_m`，且在
该集合上的目标词限制相同；这与 (DCS1)（取其中任一消息作为 `m`）矛盾。因此该映射
是单射。descriptor 有至多 `2^s` 种，大小不超过 `r` 的位置集合及其符号限制总数为
右端的和，得到 (DCS2)。对二项式和使用
`sum_{t<=r} binom(N,t)|Sigma|^t <= (r+1)(eN|Sigma|/r)^r`
即得 (DCS3)。

### 从 coordinate cores 得到 (DCS1)

对每个 `(m,i)` 仍可给出 target-specific core `K_{m,i}`，但只要求它命中同桶的
disagreement sets：对所有 `m'` 满足 `κ(m')=κ(m)` 且 `m'_i != m_i`，有

```text
K_{m,i} ∩ {j : Y(m)_j != Y(m')_j} != emptyset.       (DCS4)
```

令 `K_m=union_i K_{m,i}`。任取同桶的 `m' != m`，选择一个 `i` 使 `m'_i != m_i`；
由 (DCS4)，`Y(m)` 与 `Y(m')` 在 `K_m` 上必有不同限制，故 (DCS1) 成立。这里不
要求不同 descriptor 桶使用同一 verifier、同一 core 或同一 target-binding strategy。

### 参数后果与边界

若 `h=k`、`s=o(k)`、`|Sigma|=O(1)` 且 `N=k^{O(1)}`，则 (DCS3) 排除
`r=o(k/log k)` 的同桶 target-specific core。更一般地，若 `k=2^{Omega(n)}`、
`s=poly(n)`、`N=poly(k)`，则每个目标只允许 `r=poly(n)` 个核心位置的方案不可能
覆盖一个完整 `k`-bit payload family；这不需要 DGL 的半径窗口，也不需要把同桶消息
提升为 RLDC。

该结论只适用于**共同物理地址空间**和 (DCS1)/(DCS4) 的 specifying-set 量词。若
每个消息有独立 oracle、descriptor 直接携带近乎全部消息熵、或不同坐标在 prefix 后
切换到无界交互策略，则不能套用 (DCS2)；这些是明确的剩余逃逸，而不是被本定理
默认为已关闭的情形。

这个 descriptor 版本把 C48 的 message-dependent core 计数与 C55/C64 的短 key
分桶边界接在同一条不等式上：即使不具备 DGL 所需的 target-relative radius，只要
proof graph 能证明同桶的 one-shot core hitting，就已经得到 (DCS3)。
