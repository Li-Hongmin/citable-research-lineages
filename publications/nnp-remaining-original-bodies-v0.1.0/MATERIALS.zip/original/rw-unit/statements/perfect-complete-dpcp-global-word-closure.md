# Perfect completeness closes the global-word gate

## Corollary

Let a dPCP sample local edges \(e=(a,b)\) from a fixed distribution \(\mu\), and let
\(D_e\) output a symbol in \(\Gamma\cup\{\bot\}\). For every target \(s\in[L]\), suppose
there is one common-address proof assignment
\(\Pi(s)=(\Pi_A(s),\Pi_B(s))\) and a target word \(y^{(s)}\in\Gamma^M\) such that

\[
  D_e(\Pi(s))=y^{(s)}_{\tau(e)}
  \qquad\text{with probability }1
\tag{PCGW1}
\]

for every sampled edge and its decoded coordinate \(\tau(e)\). For another assignment
\(z=(z_A,z_B)\), define its endpoint disagreement mass

\[
  \theta_s(z)=
  \Pr_{e=(a,b)\sim\mu}
  [z_A(a)\ne\Pi_A(s)(a)\ \lor\ z_B(b)\ne\Pi_B(s)(b)].
\tag{PCGW2}
\]

Assume moreover that the decoded-coordinate marginal \(\tau(e)\) is uniform on \([M]\)
(or that the candidate-word distance is measured in this same marginal). Then

\[
  \Pr_{e\sim\mu,\;D_e}
  [D_e(z)\ne y^{(s)}_{\tau(e)}]\le\theta_s(z).
\tag{PCGW3}
\]

Consequently, if every \(\rho\)-near proof satisfies
\(\theta_s(z)\le\kappa\rho\), and the target words are pairwise \(\Delta\)-separated with
\(\kappa\rho<\Delta/2\), the hypotheses of Proposition 3.8B hold with
\(\varepsilon=\kappa\rho\). The resulting shared-proof ACRR/RLDC uses

\[
  O\!\left(
    q\,\frac{\log(L/\eta)}{(\Delta-2\kappa\rho)^2}
  \right)
\tag{PCGW4}
\]

proof queries, in addition to public candidate-word evaluation.

## Proof

On an edge outside the disagreement event in (PCGW2), the local view of \(z\) is identical
to the perfectly complete view \(\Pi(s)\). By (PCGW1), the decoder outputs the target
symbol with probability one. Hence a wrong symbol, or \(\bot\), can occur only on the
disagreement event, proving (PCGW3). Proposition 3.8B then gives (PCGW4).
\(\square\)

If proof distance is measured by uniform vertex Hamming distance and the edge marginals
have incidence amplification at most \(\chi_A,\chi_B\), one may take
\(\kappa=\chi_A+\chi_B\). In a balanced uniform bipartite sampler, \(\kappa=2\).

This corollary is deliberately stronger than target retention: it uses only perfect
completeness and endpoint proximity, not list soundness. It does **not** claim that current
GMWZ output words form a public, efficiently enumerable, pairwise-separated family. That
candidate-evaluation condition is the remaining address-scale gate; once it is supplied,
the RLDC lower bound applies immediately through Proposition 3.8B.
