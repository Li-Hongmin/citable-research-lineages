# Adaptive imperfect-completeness Lorenz envelope

## Theorem

Fix \(0<\rho<1\) and \(c\ge0\). Consider infinitely many binary common-proof
maps

\[
  \Pi_k:\{0,1\}^k\longrightarrow\{0,1\}^{N_k},
  \qquad N_k\le k(\log k)^c,
\]

with the common-proof and pathwise first-hit hypotheses of the imperfect-completeness
Lorenz closure theorem. Assume that each coordinate decoder is adaptive and makes at
most \(r_k\ge1\) proof-symbol queries. Let \(\varepsilon_k\) be the honest-codeword
error probability and let \(\Lambda_{\rho,k}\) be the honest-path Lorenz mass of the
top \(\lfloor\rho N_k\rfloor\) proof positions. Put

\[
  s_k:=\varepsilon_k+\Lambda_{\rho,k}.
\]

There is a constant \(\eta=\eta(\rho,c)>0\) such that, for all sufficiently large
lengths in the family,

\[
  \varepsilon_k\le\frac1{12},\qquad s_k\le\frac1{12}
  \quad\Longrightarrow\quad
  r_k\log(r_k+2)\ge
  \eta(\log k)^{1/3}.
\tag{1}
\]

Thus a near-linear adaptive common-proof family with
\(r_k\log(r_k+2)=o((\log k)^{1/3})\) must pay either a constant honest-completeness
deficit or violate the low-Lorenz condition \(s_k\le1/12\).

## Proof

Under the two hypotheses, the pathwise Lorenz closure gives an adaptive relaxed local
decoder for the message coordinates with radius \(\rho\), completeness at least
\(1-\varepsilon_k\), and wrong-output probability at most \(s_k\) on every
\(\rho\)-near proof. In particular its error rate is at most \(1/12\). Because
the message domain is the full Boolean cube, both output values occur at every
coordinate, so the two-value robust-point hypothesis in the DGL transfer is met. Also,

\[
  2\varepsilon_k+\Lambda_{\rho,k}
  =\varepsilon_k+s_k\le\frac14<1,
\]

so the same closure theorem makes \(\Pi_k\) injective and gives \(N_k\ge k\).

Apply the variable-query relaxed-DGL transfer to this relaxed local decoder. Its
normalized query parameter \(Q_k\) satisfies

\[
  Q_k\le C_0 r_k\log(r_k+2),
\tag{2}
\]

for a constant \(C_0\) depending only on the fixed alphabet and error/radius
parameters. In the quantitative window \(Q_k^3\le\eta_0\log N_k\), the transfer's
shared-sample counting bound contradicts \(N_k\le k(\log k)^c\), for a constant
\(\eta_0=\eta_0(\rho)>0\). Hence, on all sufficiently large lengths,

\[
  Q_k^3>\eta_0\log N_k\ge\eta_0\log k.
\]

Combining this with (2) proves (1), after decreasing \(\eta\) by the fixed factor
\(C_0^{-1}\eta_0^{1/3}\). \(\square\)

## Boundary

This is an adaptive, low-Lorenz barrier. It does not use decision-tree expansion,
nonadaptive RLDC-to-LDC conversion, or independent branch resampling. The result uses
the variable-query relaxed-DGL theorem derived from Dall'Agnol--Gur--Lachish's
source proof ingredients; the source states the relaxed application for constant
query complexity, so the growing-\(r_k\) transfer is explicitly a derived extension.
The theorem is a coding barrier, not a proof of \(P\ne NP\) or a general dPCP
impossibility theorem.

## Sources

* [Imperfect-completeness pathwise Lorenz closure](imperfect-pathwise-lorenz-rldc-closure.md).
* [Variable-query relaxed-DGL theorem](../../mcsp-hardness-magnification/notes/255-variable-query-relaxed-dgl-theorem-2026-08-17.md).
* Dall'Agnol, Gur, and Lachish, *A Structural Theorem for Local Algorithms with
  Applications to Coding, Testing, and Privacy*, ECCC TR20-154:
  <https://eccc.weizmann.ac.il/report/2020/154/>.
