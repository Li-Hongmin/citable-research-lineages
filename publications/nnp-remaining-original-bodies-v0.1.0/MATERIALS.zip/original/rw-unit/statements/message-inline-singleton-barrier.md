# 任意有限 alphabet proof map 的 message-inline Singleton barrier

## 定理

令

\[
  \Pi:\{0,1\}^{k}\longrightarrow\{0,1\}^{P}
\]

是任意的 binary global-proof map，不假设线性、systematic 或 projection。对每个
消息坐标 \(i\in[k]\) 与声明位 \(b\in\{0,1\}\)，给定一个至多 \(q\) 次、可以自适应
查询 proof oracle 的 randomized verifier \(V_{i,b}\)。假设存在常数

\[
  0<\rho<1,\qquad \alpha>\beta,
\]

使得：

1. **完备性：** 对所有 \(m,i\)，
   \[
     \Pr[V_{i,m_i}^{\Pi(m)}=1]\ge\alpha;
   \]
2. **target-relative soundness：** 若
   \(\operatorname{dist}(z,\Pi(m))\le\rho P\)，则
   \[
     \Pr[V_{i,1-m_i}^{z}=1]\le\beta.
   \]

则对所有 \(k\ge2\)，令 \(N=k+P\)，有：

\[
  P\ge\frac{k-1}{1-\rho},
\qquad
  \frac{P}{k+P}\ge\frac1{3-2\rho}.
\tag{S1}
\]

进一步，message-inline code

\[
  C(m)=m\,\|\,\Pi(m)\in\{0,1\}^{N}
\]

在半径

\[
  \delta_0=\frac{\rho}{2(3-2\rho)}
\tag{S2}
\]

上给出 locality

\[
  Q=O\!\left(q(\alpha-\beta)^{-2}\right)
\tag{S3}
\]

的 binary relaxed local decoder。因此，若 \(q,\rho,\alpha-\beta\) 为固定常数，
则 Dall'Agnol--Gur--Lachish 的 relaxed-LDC 下界直接给出

\[
  N\ge k^{\,1+1/O(Q^2\log^2(Q+2))}.
\tag{S4}
\]

特别地，固定正 proof-radius、固定 query 和固定 gap 的 family-level Sim-CR，
即使 proof map 非线性、verifier 自适应，也不能有近线性总长度。

## 证明

取不同消息 \(m\ne m'\)，选一个坐标 \(i\) 使 \(m_i\ne m'_i\)。如果

\[
  \operatorname{dist}(\Pi(m),\Pi(m'))\le\rho P,
\]

则以 \(m\) 为 target、取 \(z=\Pi(m')\)，soundness 给出

\[
  \Pr[V_{i,m'_i}^{\Pi(m')}=1]\le\beta.
\]

但以 \(m'\) 为 target 的完备性给出同一概率至少为 \(\alpha\)，矛盾。因此 proof
map 的 image 是一个 binary code，最小距离严格大于 \(\rho P\)。

设其整数最小距离为 \(d\)。一般 q-ary Singleton 界（这里只取 binary）给出

\[
  2^k\le 2^{P-d+1},
\]

从而

\[
  k\le P-d+1 < (1-\rho)P+1,
\]

得到 (S1) 的第一式。对 \(k\ge2\)，有
\(P\ge k/[2(1-\rho)]\)，于是

\[
  \frac{P}{k+P}
  \ge
  \frac{1/[2(1-\rho)]}{1+1/[2(1-\rho)]}
  =\frac1{3-2\rho}.
\]

再把消息位内嵌到 \(C(m)\)。前面的距离证明说明
\[
  \operatorname{dist}(C(m),C(m'))>\frac{\rho P}{k+P}
  \ge\frac{\rho}{3-2\rho}.
\]
因此 \(\delta_0\) 严格小于码距的一半。给定 oracle \(y\) 和目标坐标 \(i\)，先查询
inline bit \(y_i\)，令 \(b=y_i\)，再运行 \(V_{i,b}\) 的 proof 查询；接受时输出
\(b\)，否则输出 \(\bot\)。若 \(y_i\) 正确，输出不可能错误；若 \(y_i\) 错误，proof
suffix 仍在 \(\rho P\) 半径内，错误分支接受率至多 \(\beta\)。对 verifier 分支做
常数重复与阈值化，得到 (S3) 的 RLDC。

最后应用固定 finite-query、finite-alphabet、positive-radius RLDC 下界，得到 (S4)。
\(\square\)

## 这一步修正了什么

旧的 message-inline 叙述常把 \(P=\Omega(k)\) 作为额外假设。对本定理的
family-level、target-relative、固定正 proof-radius 量词，这个假设是多余的：
pairwise proof distance 加一般 Singleton 界已经自动给出它。因而“短 proof”不是该
模型的独立逃逸；真正的逃逸必须让 \(\rho=\rho_k\to0\)、放弃 family-level 量词、
改用 codeword-only soundness，或让不同消息使用不可统一的 verifier/proof 地址空间。

## 有限 alphabet extension

上面的 binary 假设不是实质性的。设 \(\Sigma\) 是任意固定有限 alphabet，令
\[
  s=\log_2|\Sigma|,\qquad \ell=\lceil s\rceil ,
\]
并把 proof map 改为
\[
  \Pi:\{0,1\}^{k}\longrightarrow\Sigma^{P}.
\]
距离改用 \(\Sigma\)-符号 Hamming 距离，完备性和 target-relative soundness 的量词
保持不变。相同的 pairwise argument 说明 \(\operatorname{Im}(\Pi)\) 的最小距离
严格大于 \(\rho P\)。q-ary Singleton 界于是给出
\[
  2^k\le |\Sigma|^{P-d+1},
  \qquad
  P>\frac{k-s}{s(1-\rho)}.
\tag{S5}
\]
特别地，对 \(k\ge 2\ell\)，
\[
  \frac{\ell P}{k+\ell P}
  \ge
  \frac{\ell}{2s(1-\rho)+\ell}
  \ge \frac1{3-2\rho}.
\tag{S6}
\]

取任意固定 injective block encoding
\(e:\Sigma\hookrightarrow\{0,1\}^{\ell}\)，定义
\[
  C_e(m)=m\,\|\,e(\Pi(m))\in\{0,1\}^{k+\ell P}.
\]
给定 binary oracle，decoder 先读取 message bit，再读取 verifier 所访问的至多
\(q\) 个 \(\ell\)-bit symbol blocks；非法 block 直接输出 \(\bot\)。因此 locality 为
\[
  Q=O\!\left(q\ell(\alpha-\beta)^{-2}\right),
\tag{S7}
\]
而 binary decoding radius 可取任意
\(\delta<\rho P/(k+\ell P)\)：每个不同的 \(\Sigma\)-符号至少贡献一个不同的
binary bit，但不应把一个符号误计为 \(\ell\) 个必错 bit。由 (S5)，当
\(k\ge 2\ell\) 时
\[
  \frac{P}{k+\ell P}
  \ge
  \frac{1}{2s(1-\rho)+\ell}.
\]
因此固定 \(\Sigma,\rho,q,\alpha-\beta\) 时仍得到固定正半径，例如可取
\[
  \delta_0=\frac{\rho}{2\bigl(2s(1-\rho)+\ell\bigr)}.
\tag{S8}
\]
在 binary 情形 \(s=\ell=1\)，(S8) 恰化为前面的
\(\rho/[2(3-2\rho)]\)。对 growing alphabet，(S8) 的字母表因子必须纳入
后续 DGL-window；不能直接沿用 binary 半径常数。
于是 Dall'Agnol--Gur--Lachish 的 finite-query relaxed-LDC 下界再次给出
\[
  k+\ell P\ge
  k^{\,1+1/O(Q^2\log^2(Q+2))}.
\tag{S9}
\]
所以在 family-level、target-relative、固定正半径语义下，有限 alphabet 也不能通过
把 \(P=o(k)\) 当作独立逃逸；Singleton 界会先强制 \(P=\Omega(k)\)（常数依赖
\(\Sigma,\rho\)），然后再进入 RLDC barrier。

### Growing alphabet 的精确逃逸账本

若 \(\Sigma=\Sigma_k\) 随 \(k\) 增长，令
\[
  s_k=\log_2|\Sigma_k|,\qquad \ell_k=\lceil s_k\rceil,\qquad
  Q_k=O\!\left(q\ell_k(\alpha-\beta)^{-2}\right).
\]
只要 \(k\ge 2\ell_k\) 且参数化 DGL-window 对二值化后的 code 适用，上述证明仍给出；
这里 DGL-window 的有效半径必须使用
\(\delta_k=\rho P_k/(k+\ell_kP_k)\)，不能把 \(\ell_kP_k\) 误当作二进制距离。
\[
  N_k=k+\ell_kP_k\ge
  \left(\frac{k}{B_{Q_k}\log(k+2)}\right)^{1/(1-\theta_{Q_k})},
\qquad
  \theta_{Q_k}=\frac{c_{Q_k}}{Q_k^2\log^2(Q_k+2)}.
\tag{S10}
\]
因此若候选声称 \(N_k\le kL_k\)，则必满足精确的参数兼容式
\[
  \theta_{Q_k}\log k
  \le
  (1-\theta_{Q_k})\log L_k+
  \log B_{Q_k}+\log\log(k+2).
\tag{S11}
\]
这把“增大 alphabet”从笼统逃逸改成可检查的三项账本：必须支付更大的
\(Q_k\)、让 DGL-window 失效，或让参数化常数 \(B_{Q_k},c_{Q_k}\) 进入非统一增长区。
例如，在额外的 uniform-window 假设
\(c_{Q_k}=\Omega(1)\)、\(\log B_{Q_k}=O(\log\log k)\) 和
\(L_k=\operatorname{polylog}(k)\) 下，(S11) 强制
\[
  Q_k^2\log^2(Q_k+2)
  =\Omega\!\left(\frac{\log k}{\log\log k}\right).
\tag{S12}
\]
固定 \(q\) 与 gap 时，这意味着 \(\ell_k\) 不能让
\(Q_k^2\log^2(Q_k+2)=o(\log k/\log\log k)\)；在该精确参数区内，任何未支付
locality 代价的近线性 growing-alphabet 构造都会被排除。没有这些 uniform-window 假设时，只能使用
(S10)--(S11)，不能把 DGL 固定 \(Q\) 的渐近自动外推到变动 \(Q_k\)。

## 范围

本定理不适用于单一 target-specific RW 实例，也不把普通平均/list soundness 自动
提升为 target-relative soundness。它是一个 family-level 编码障碍，不是独立的
\(P\ne NP\) 证明；其价值在于把 ACRR 的 proof-length 逃逸从“可能短 proof”收窄为
“必须牺牲正半径、消息族量词，或固定有限 alphabet/统一地址空间”。

## 来源与关系

* [Message-inline RLDC compiler](message-inline-rldc-compiler.md)
* [Radius-to-relaxed-LDC barrier](radius-to-relaxed-ldc-barrier.md)
* [Dall'Agnol--Gur--Lachish, TR20-154, Corollary 7.9](https://eccc.weizmann.ac.il/report/2020/154/)
