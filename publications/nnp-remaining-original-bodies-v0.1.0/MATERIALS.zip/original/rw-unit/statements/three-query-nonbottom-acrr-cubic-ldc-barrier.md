# Three-query one-shot non-bottom ACRR has a cubic LDC barrier

## Theorem

Let

\[
\Pi:\{0,1\}^{k}\to\{0,1\}^{P}
\]

be a binary family-level proof map. For every message coordinate \(i\) and claim
\(b\in\{0,1\}\), let \(V_{i,b}\) be a randomized, possibly adaptive verifier making at most
two queries to the proof. Write

\[
  p_{i,b}(z)=\Pr[V_{i,b}^{z}=1].
\]

Assume constants \(0<\rho<1\), \(\alpha>\beta\ge0\) such that:

1. \(p_{i,m_i}(\Pi(m))\ge\alpha\) for every \(m,i\);
2. if \(\operatorname{dist}(z,\Pi(m))\le\rho\), then
   \(p_{i,1-m_i}(z)\le\beta\) for every \(m,i\).

Define the two-branch mass on the half-radius neighborhood by

\[
  \tau_{\rho/2}
  :=\inf_{m,i}\ \inf_{\operatorname{dist}(z,\Pi(m))\le\rho/2}
       \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr),
\]

and suppose

\[
  \varepsilon_0:=\max\{\beta,\,1-\tau_{\rho/2}+\beta\}\le\frac13.
\tag{TNB1}
\]

Then, for all sufficiently large \(k\),

\[
  k+P=\Omega_{\rho,\varepsilon_0}\!\left(\frac{k^3}{\log^6 k}\right).
\tag{TNB2}
\]

Thus a nonlinear binary two-proof-query ACRR can have near-linear length only if it has a
structural bottom on some constant-radius near-proof: it must allow
\(\tau_{\rho/2}\le 2/3+\beta\) (for the standard \(1/3\)-error LDC window), or else it pays
the three-query LDC lower bound.

## Proof

First, the proof image has relative distance strictly larger than \(\rho\). If two distinct
messages \(m,m'\) had proof words within relative distance \(\rho\), choose \(i\) with
\(m_i\ne m'_i\). Completeness for \(m'\) gives
\(p_{i,m'_i}(\Pi(m'))\ge\alpha\), while target-relative soundness for target \(m\) gives the
same probability at most \(\beta\), a contradiction.

Let \(N=k+P\) and inline the message:

\[
  C(m)=m\,\|\,\Pi(m)\in\{0,1\}^{N}.
\]

The binary Singleton bound applied to the \(2^k\) proof words gives, for \(k\ge2\),

\[
  \frac{P}{k+P}\ge\frac1{3-2\rho}.
\tag{TNB3}
\]

The inline code \(C\) consequently has relative distance at least
\(\rho P/(k+P)\ge\rho/(3-2\rho)\), so it lies in the constant-distance regime of the external
three-query LDC bound.

Set

\[
  \delta_0=\frac{\rho}{2(3-2\rho)}.
\]

If \(y\) is within relative distance \(\delta_0\) of \(C(m)\), its proof suffix \(z\) is within

\[
  \delta_0N\le\frac{\rho P}{2}
\]

of \(\Pi(m)\), by (TNB3). A decoder for coordinate \(i\) first queries the inline bit
\(b=y_i\), then runs \(V_{i,b}\) on \(z\), and outputs \(b\) if that verifier accepts and
\(1-b\) otherwise. It makes exactly one inline query and at most two proof queries.

If \(b=m_i\), the wrong branch is at most \(\beta\) on \(z\), while the definition of
\(\tau_{\rho/2}\) gives

\[
  p_{i,m_i}(z)\ge\tau_{\rho/2}-p_{i,1-m_i}(z)
  \ge\tau_{\rho/2}-\beta.
\]

The decoder therefore errs with probability at most
\(1-\tau_{\rho/2}+\beta\). If \(b\ne m_i\), it errs only when the wrong branch accepts,
which has probability at most \(\beta\). Hence \(C\) is a three-query binary LDC with
constant radius \(\delta_0\), constant distance, and error at most \(\varepsilon_0\le1/3\).

The three-query LDC lower bound of Gur--Minzer--Weissenberg--Zheng, Theorem 1.10, then gives
\(N=\Omega(k^3/\log^6 k)\) for constant alphabet, radius, distance, and error. This is
(TNB2).

## Scope

The theorem is stronger than the linear two-query barrier in that \(\Pi\) may be nonlinear, but
its one-shot non-bottom hypothesis is stronger than ordinary ACRR. It does not apply when:

* the two branches may both reject on a near-proof with total mass below the threshold in
  (TNB1);
* only codeword-point completeness is known and no near-proof branch-mass lower bound is
  available;
* the proof alphabet, radius, or query count leaves the fixed-parameter LDC window; or
* different coordinates use different proof/address spaces.

Consequently, (TNB2) is a structural barrier for the proposed simultaneous coordinate-robust
route, not an unconditional impossibility theorem for all dPCPs.

## Evidence boundary

The reduction from (TNB1) to a three-query ordinary LDC is self-contained. The only external
input is the three-query LDC lower bound
[GMWZ Theorem 1.10](https://arxiv.org/html/2512.12960#S1.2.2), which states that constant
alphabet, constant-radius, constant-distance three-query LDCs have length
\(\Omega(k^3/\log^6 k)\). The result complements the general threshold-amplification theorem
[Non-bottom coordinate robustness upgrades RLDC to LDC](nonbottom-coordinate-robustness-ldc-barrier.md):
here the stronger branch-mass assumption preserves exactly three queries and therefore reaches
the cubic lower-bound window.
