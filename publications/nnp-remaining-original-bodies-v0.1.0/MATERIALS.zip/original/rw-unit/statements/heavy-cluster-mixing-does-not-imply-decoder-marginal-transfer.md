# Heavy-cluster mixing does not imply decoder-marginal transfer

The flag-conditioned spectral lemma controls the mass of a cross-cluster pair,
but it does not by itself control the base-decoder marginal
\(\xi_{ij}\). This is an independent quantifier: cluster density and pair
mixing concern the left faces \(A,A'\), whereas \(\xi_{ij}\) concerns the
vertex/decoder view selected inside their common \(s\)-face.

## Explicit uniform-complex example

Take a complete complex on an even vertex set \(V=S\sqcup T\), with
\(|S|=|T|\), and use \(k=2,s=1\) and any \(d\ge 3\). Define disjoint clusters

\[
U_0=\{A\in X(2):A\subseteq T\},
\qquad
U_1=\{A\in X(2):|A\cap S|=1\}.
\]

As the number of vertices tends to infinity,
\[
\mu_2(U_0)\to\frac14,\qquad
\mu_2(U_1)\to\frac12.
\]

The shared-top-face pair event \(A\in U_0,\ A'\in U_1\) has positive probability.
On this event, the common one-face \(B=A\cap A'\) must lie in \(T\). Thus, if the
base decoder chooses \(u\) uniformly from \(B\), then

\[
\Pr[u\in T\mid A\in U_0,\ A'\in U_1]=1.
\]

Under the unconditioned single-left-face decoder distribution on the complete
complex, \(u\) is uniform on \(V\), so \(\Pr[u\in T]=1/2\). Therefore the
total-variation distance of the conditioned and base \((t,u)\)-marginals is at
least \(1/2\), regardless of how \(t\) is sampled conditionally on \(u\):

\[
\xi_{01}\ge
\left|\Pr_{\nu_{01}}[u\in T]-\Pr_{\mathcal Q_{\rm base}}[u\in T]\right|
=\frac12.
\tag{DM1}
\]

The complete complex has no local spectral-expansion defect, and its shared-top
pair operator is exactly the kind of operator covered by the flag factorization.
Hence this is not a failure of pair mixing; it is a failure of marginal transfer.

## Consequence

No theorem whose hypotheses are only

* constant lower bounds on \(\mu_k(U_i)\) and \(\mu_k(U_j)\), and
* a small second singular value for the shared-top pair operator

can imply \(\xi_{ij}=o(1)\) for arbitrary clusters. To close the GMWZ
unique-decoding route one must additionally prove a decoder-smoothness statement,
for example a bounded Radon--Nikodym derivative for the \((t,u)\)-view after
conditioning on every heavy cluster pair, or a source-specific incidence theorem
for the particular clusters produced by Lemma 6.2.

This does not rule out such a theorem for the GMWZ clusters. It identifies the
missing hypothesis precisely: Lemma 6.2's density and within-cluster closeness
alone do not provide it.

## The same gap survives the explicit Lemma 6.2 quantifiers

The obstruction is not merely an artifact of replacing the source lemma by a weaker
informal summary. Let \(T^{*}:X(k)\to\Sigma^{k}\) be the low-agreement table used in
the proof of GMWZ Lemma 6.2: for every \(F:X(1)\to\Sigma\), the fraction of \(k\)-faces
on which \(T^{*}[A]\) is close to \(F|_A\) is below the direct-product-test threshold.
Take any pairwise disjoint sets \(U_1,\ldots,U_J\subseteq X(k)\), with
\(J\le\delta^{-C}\) and \(\mu_k(U_i)\ge\delta^C\), and arbitrary functions
\(f_i:X(1)\to\Sigma\). Define a left assignment by

\[
T_1[A]=
\begin{cases}
f_i|_A,&A\in U_i,\\
T^{*}[A],&A\notin U_1\cup\cdots\cup U_J.
\end{cases}
\]

The first conclusion of Lemma 6.2 holds with zero local error on every \(U_i\). For
the second conclusion, outside the union \(T_1\) is exactly \(T^{*}\). If some right
assignment \(T_2\) matched \(T_1\) on the shared \(s\)-face with probability above the
lemma's threshold outside the union, the same direct-product soundness step used in the
source proof would produce a global \(F\) agreeing with \(T^{*}\) on too many \(k\)-faces,
contradicting the defining property of \(T^{*}\). Thus the explicit two-clause conclusion
of Lemma 6.2 is compatible with arbitrary disjoint heavy-set geometry; it does not imply
any incidence regularity for \(U_i\) or for the shared \(s\)-face distribution.

This is a black-box limitation only: it does not say that the particular \(T_1\) arising
from a computation has this form, nor does it preclude a new theorem using additional
semantic structure of that \(T_1\). It does show that such additional structure must be
used explicitly; it cannot be recovered from Lemma 6.2's density, disjointness, and
outside-union clauses alone.

## Source boundary

The cluster guarantee used in the GMWZ construction gives heavy disjoint subsets
of \(X(k)\) and local closeness, while the decoder distribution chooses \(u\) from
the shared face; see [GMWZ Lemma 6.2 and Section 6](https://arxiv.org/html/2512.12960#S6.2).
The partition calculation above is elementary and only establishes a general
independence barrier. It is not a counterexample to the particular GMWZ HDX
construction or to a future cluster-incidence theorem.
