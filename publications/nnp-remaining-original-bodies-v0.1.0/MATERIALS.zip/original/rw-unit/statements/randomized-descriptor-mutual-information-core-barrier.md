# Randomized descriptors pay only for target information

## 定理

令
\[
  C:\mathcal M\hookrightarrow\Sigma^N
\]
是有限消息族的单射 proof map，令 \(M\) 按任意分布取值。与目标相关的
descriptor 不再是确定函数，而是离散随机变量 \(D\)，其条件分布为
\(\Pr[D=d\mid M=m]\)。对每个 descriptor \(d\)、坐标 \(i\) 和声明 \(b\)，验证器
\(V_{d,i,b}\) 使用同一个物理 proof 地址空间 \([N]\)，并允许自适应查询。

对每个 \((m,d)\) 满足 \(\Pr[M=m,D=d]>0\) 和每个坐标 \(i\)，选取一个正确声明的
完整策略 \(\pi_{m,d,i}\)，令
\[
  K_{m,d}
  =
  \bigcup_i
  \operatorname{Supp}\!\left(
    V_{d,i,m_i,\pi_{m,d,i}}
  \right).
\]
假设存在 \(\alpha>\beta\) 与 \(\rho\ge0\)，使：

1. \(\pi_{m,d,i}\) 在 \(C(m)\) 上以概率至少 \(\alpha\) 接受；
2. 对每个 \((m,d)\) 的正概率支撑、每个错误声明策略 \(\pi\)，以及每个
   \(\operatorname{dist}(z,C(m))\le\rho\)，都有
   \[
     \Pr[V_{d,i,1-m_i,\pi}(z)=1]\le\beta.
   \]

令 \(R=|K_{M,D}|\)。则
\[
  H(M)
  \le
  I(M;D)
  +N h_2\!\left(\frac{\mathbb E R}{N}\right)
  +\mathbb E R\log_2|\Sigma|.
\tag{RMI1}
\]

当 \(\mathbb E R\le N/2\) 时，
\[
  H(M)-I(M;D)
  \le
  \mathbb E R\log_2\!\left(
    \frac{eN|\Sigma|}{\mathbb E R}
  \right).
\tag{RMI2}
\]

因此，若 \(M\) 是均匀的 \(k\)-bit 消息、\(|\Sigma|\) 固定、\(N=k^{O(1)}\)，且
\(I(M;D)\le\gamma k\)（固定 \(\gamma<1\)），则
\[
  \mathbb E|K_{M,D}|=\Omega\!\left(\frac{(1-\gamma)k}{\log k}\right).
\tag{RMI3}
\]
特别地，完全独立于目标的 public random descriptor 满足 \(I(M;D)=0\)，不能为
target-dependent ACRR 携带任何目标熵。

## 证明

固定一个 descriptor 值 \(d\)。若两个不同消息 \(m\ne m'\) 都满足
\(\Pr[M=m,D=d]>0\)，并且
\[
  K_{m,d}=K_{m',d},
  \qquad
  C(m)|_{K_{m,d}}=C(m')|_{K_{m,d}},
\]
取坐标 \(i\) 使 \(m_i\ne m'_i\)。策略 \(\pi_{m,d,i}\) 只访问这个共同的
\(K_{m,d}\)，所以它在 \(C(m')\) 上的 transcript 分布与在 \(C(m)\) 上相同，接受率
至少为 \(\alpha\)。但对目标 \(m'\)，这正是 descriptor \(d\) 下的错误声明，而
\(C(m')\) 位于自身的 \(\rho\)-邻域内，故 all-policy soundness 给出接受率至多
\(\beta\)，矛盾。

所以在每个 \(d\) 的条件支撑上，
\[
  m\longmapsto\bigl(K_{m,d},C(m)|_{K_{m,d}}\bigr)
\]
是单射。因而
\[
  H(M\mid D,K_{M,D},C(M)|_{K_{M,D}})=0.
\]
链式法则给出
\[
\begin{aligned}
H(M)
 &= I(M;D)+H(M\mid D)\\
 &\le I(M;D)+H(K_{M,D}\mid D)
    +H(C(M)|_{K_{M,D}}\mid D,K_{M,D})\\
 &\le I(M;D)+H(K_{M,D}\mid D)
    +\mathbb E R\log_2|\Sigma|.
\end{aligned}
\]
把 \(K_{M,D}\) 看成 \([N]\) 的随机子集。若
\(p_{d,j}=\Pr[j\in K_{M,D}\mid D=d]\)，则
\[
\begin{aligned}
H(K_{M,D}\mid D)
&\le \sum_d\Pr[D=d]\sum_{j=1}^N h_2(p_{d,j})\\
&\le \sum_d\Pr[D=d]\,
  N h_2\!\left(\frac{\mathbb E[R\mid D=d]}{N}\right)\\
&\le N h_2\!\left(\frac{\mathbb E R}{N}\right),
\end{aligned}
\]
其中最后一步是二元熵的凹性。代入即得 (RMI1)，再使用
\(h_2(u)\le u\log_2(e/u)\) 得 (RMI2)。若 \(H(M)=k\) 且
\(I(M;D)\le\gamma k\)，则 (RMI2) 给出 (RMI3)。\(\square\)

## 解释与边界

这是确定性 descriptor 熵界的严格强化。若 \(D=\kappa(M)\) 是确定函数，则
\(I(M;D)=H(D)\)，恢复原有 entropy--core inequality；若 \(D\) 含有与目标无关的
独立随机性，则 \(H(D)\) 可能很大，但 \(I(M;D)=0\)，这些随机 bits 不会被错误地
计作 target channel。

定理仍要求：

* 同一 descriptor 值使用同一物理 proof 地址空间；
* 对每个正概率的 \((m,d)\)，存在完整正确策略；
* 错误声明对同一 descriptor 下的所有策略 sound；
* 不同目标不能使用独立 proof oracle。

若 descriptor 的随机选择本身依赖完整目标、或 verifier 在 descriptor 外直接读取
目标，相关信息会正确地计入 \(I(M;D)\)。若只有 selected-policy soundness、zero-radius
codeword-only 语义或逐目标独立地址空间，单射步骤不成立。单一固定目标的
\(H(M)=0\) 仍然不产生虚假的 family-level lower bound。

## 对 ACRR 的含义

随机 public key、随机 hash seed、随机 verifier mode 或有限随机 preconditioner，只有
在其分布携带目标信息时才能减少 complete-policy core；纯公共随机化不增加可承载的
target entropy。因而 randomized-key 的正向路线必须明确支付 \(I(M;D)\)，或者打破
common-address/all-policy target-relative 量词。该结论与 finite-transcript
randomness--time barrier 互补：前者限制随机 descriptor 能携带多少目标信息，后者限制
统一 finite-horizon 交互能否压低环境时间。

## 关系

* 它把 [Target-dependent ACRR 的熵—完整策略核心不等式](entropy-core-inequality-for-target-dependent-acrr.md)
  中的 \(H(D)\) 精确替换为 \(I(M;D)\)；
* 它比固定 descriptor / 最大桶计数更强，允许随机 key 和目标无关公共随机性；
* 它不声称所有 dPCP 或单一 RW 实例都满足 common-address/all-policy 假设。

## 证据边界

证明只使用条件支撑上的有限 transcript indistinguishability、条件熵链式法则与二元
熵凹性，是自足的 derived theorem。它不是无条件的 \(P\ne NP\) 证明；要进入 RW/JK
主线，仍需逐项验证其 descriptor、proof map 与 target-relative soundness 量词。
