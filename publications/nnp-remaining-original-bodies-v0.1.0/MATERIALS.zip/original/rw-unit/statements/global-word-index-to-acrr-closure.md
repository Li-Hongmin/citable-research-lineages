# Global-word index recovery closes to a shared ACRR

## Proposition

Let \(L\ge2\) and let \(Y=\{y^{(1)},\ldots,y^{(L)}\}\subseteq\Gamma^M\) be a public candidate family with
pairwise relative distance at least \(\Delta>0\). Suppose each candidate is an encoded
message \(y^{(s)}=C(m^{(s)})\), where \(C:\{0,1\}^k\to\Gamma^M\) has a deterministic
decoder \(\mathsf{Dec}_i\) for every message coordinate \(i\), using at most \(q_D\) queries
to \(y^{(s)}\). The candidate evaluator \(E(s,j)=y^{(s)}_j\) is assumed public and
address-scale computable; no proof queries are needed to evaluate \(E\).

Let \(\Pi(s)\in\Sigma^N\) be a common-address proof map. For every codeword coordinate
\(j\), let \(D_j\) be a randomized adaptive decoder making at most \(q\) proof queries,
with perfect completeness
\[
  D_j(\Pi(s))=y^{(s)}_j\quad\text{with probability }1.
\]
Assume that, for some \(\rho>0\) and \(\varepsilon<\Delta/2\),

\[
  \operatorname{dist}(z,\Pi(s))\le\rho
  \quad\Longrightarrow\quad
  \Pr_{J,\;D_J}\!\left[D_J(z)\ne y^{(s)}_J\right]\le\varepsilon,
\tag{GIA1}
\]

where \(J\) is uniform on \([M]\) and \(\bot\) counts as an error. Then for every
\(\eta\in(0,1/2)\) there is a target-independent shared-proof decoder which, on a
\(\rho\)-near proof, outputs \(m^{(s)}_i\) with error at most \(\eta\), using

\[
  R=\left\lceil
    \frac{2\log((L-1)/\eta)}{(\Delta-2\varepsilon)^2}
  \right\rceil
\tag{GIA2}
\]

independent calls to the \(q\)-query decoder and hence at most

\[
  Rq=O\!\left(q\,\frac{\log(L/\eta)}{(\Delta-2\varepsilon)^2}\right)
\tag{GIA3}
\]

proof queries, followed by \(q_D\) evaluations of the public candidate word. For the
adaptive decoder, this is the adaptive proof-query count. If a nonadaptive RLDC
theorem is applied, set
\[
  T_q(A):=\sum_{t=0}^{q-1}A^t,\qquad A:=|\Sigma|.
\tag{GIA3a}
\]
Exposing each \(A\)-ary decision tree gives nonadaptive locality at most \(RT_q(A)\).
When the \(D_j\) are already nonadaptive, \(T_q(A)\) is replaced by \(q\). Thus a
global-word distributional theorem plus a public candidate evaluator is already a
bounded-error ACRR/RLDC interface; no local index output is required from the original
dPCP decoder. The score scan uses \(O(LR)\) candidate evaluations, so address-scale
running time additionally requires efficient enumeration of \(Y\) or a succinct
argmax procedure.

## Proof

Sample \(R\) independent coordinates and run the corresponding \(D_J\) calls. For each
candidate \(t\), compute its empirical agreement with the observed symbols and output an
index \(\widehat s\) maximizing this score. Under (GIA1), the true candidate has expected
agreement at least \(1-\varepsilon\). If \(t\ne s\), pairwise distance gives expected
agreement at most \(1-\Delta+\varepsilon\). Hoeffding's inequality and a union bound over
the \(L-1\) wrong candidates imply

\[
  \Pr[\widehat s\ne s]\le\eta
\]

for the value of \(R\) in (GIA2). The final decoder evaluates the \(q_D\) requested
positions of \(y^{(\widehat s)}\) and applies \(\mathsf{Dec}_i\). When
\(\widehat s=s\), this equals \(m^{(s)}_i\) by correctness of \(C\)'s decoder, so the total
error is at most \(\eta\). The adaptive proof-query bound is (GIA3). For a fixed random
tape, each adaptive \(D_j\) has at most \(T_q(A)\) internal query nodes; taking the union
over the \(R\) sampled coordinates gives nonadaptive locality at most \(RT_q(A)\). If the
base decoders are already nonadaptive, this reduces to \(Rq\). Candidate evaluation is
address-scale computation and does not enlarge the proof oracle locality.

If \(s\ne t\) and \(\operatorname{dist}(\Pi(s),\Pi(t))\le\rho\), applying (GIA1) to
\(z=\Pi(t)\) for target \(s\), while using perfect completeness for target \(t\), would
make one symbol distribution \(\varepsilon\)-close to both \(y^{(s)}\) and \(y^{(t)}\),
contradicting \(\Delta>2\varepsilon\). Hence the proof map is itself \(\rho\)-separated,
as required by the relaxed-code interpretation. \(\square\)

## Scope

The proposition is a closure theorem, not a claim that the current GMWZ dPCP supplies
(GIA1) with a public efficiently evaluable candidate family. Ordinary list soundness
does not imply (GIA1): different coordinates may choose different list words. Proposition
3.8A only retains the target in the common list under endpoint proximity; a separate
global-word collapse, such as the hypotheses of C152, is still required. Once that collapse
and the candidate evaluator are available, the target-output relation enters the RLDC barrier
directly, even if the base decoder never exposes an index.
