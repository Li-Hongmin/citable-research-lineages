# Sim-CR 的策略压缩三难：共同摘要、有限响应与全局词一致性

## 定理地位

这是把两个已经独立核验的下界接口合并成一个论文级的路线定理：

* 共同、有限的 target-channel 摘要受 one-way random-access 熵下界约束；
* 若坐标揭示后的策略只有有限响应，且同一响应桶仍保持 target-relative soundness，
  则该策略可枚举为 relaxed local decoder，并进入 RLDC 长度下界；
* 因而一个近线性 simultaneous coordinate-robust 构造若要同时避免这两项下界，必须
  使用无界的坐标后策略，或放弃同一全局 proof/word-consistent parent closure。

这不是新的外部编码下界，也不是无条件的 `P != NP` 证明。它的价值是把正向构造的
剩余空间压成一个明确的第三类，而不是把“交互”笼统当成免费逃逸。

## 统一模型

令

\[
  F\subseteq\{0,1\}^k,\qquad C:F\to\Sigma^N
\]

是一个 proof/codeword family，`\Sigma` 为固定有限字母表。对每个目标 `f\in F`，
所有坐标必须使用同一 `C(f)`、同一 proof 地址空间和同一 word semantics。以下三种
机制分别对应三种可核验的接口。

### A. 坐标揭示前的共同摘要

存在长度为 `L` 的摘要 `\omega_f`，以及一个统一随机 evaluator

\[
  E(\omega;R)\in\{0,1\}^k,
\]

使对每个 `f\in F`

\[
  \mathbb E_R[\operatorname{dist}_H(E(\omega_f;R),f)]\le\eta k,
  \qquad 0\le\eta<1/2.
\tag{A}
\]

摘要可以包含 static key、坐标揭示前的 Merlin strategy summary 或其它有限共同
commitment；关键是同一个 `\omega_f` 服务全部坐标。

### B. 有限坐标后响应

目标由 `s` 比特 key `\kappa(f)` 分桶。固定 key `\sigma`、坐标 `i`、声明 `b` 后，
verifier 还可枚举一个响应 `\tau\in\{0,1\}^r`，每个分支至多查询 `q_0` 个 proof
symbols。存在 `\alpha>\beta` 和 `\rho>0`，使在同一 key 桶内：

1. 正确声明在 `C(f)` 上对某个 `\tau` 以概率至少 `\alpha` 接受；
2. 错误声明在任意 `z` 满足 `\operatorname{dist}(z,C(f))\le\rho` 时，对所有
   `\tau` 的接受率至多 `\beta`。

这里的“对所有 `\tau`”是必要的；若错误分支只对某个响应 sound，枚举响应不能形成
一个 RLDC decoder。

### C. 剩余的全局策略类

在仍保持共同 proof、target-relative soundness，以及“不把完整目标消息直接交给
verifier”这些语义的候选中，若既没有 A 的有限共同摘要/evaluator，也没有 B 的有限
响应编码，则策略只能落入一个无界的坐标后对象。若它仍要服务 JK/RW，则必须另外给出：
同一个全局 proof 上的 exact word consistency、父节点串接闭合，以及对所有坐标共享的
strategy/seed 选择规则。A、B 的下界不自动适用于这一类，但它也不再是一个已证明的
ACRR 接口。若候选改用 target-specific verifier、独立 proof 地址空间或放弃
target-relative soundness，则它是在本三难之外改变了模型，而不是 C 的正向实例。

这里还要排除一个表面上的“无界响应”逃逸。在标准有限轮次的交互接口中，即使响应
字母表随码长增长，只要每个实例仍有限，固定码长和查询深度后，所有 response
view-tree policies 的数量本身仍是有限的。对它们取全 branch-support 并应用
[branch-support barrier](strategy-support-acrr-rldc-barrier.md)，可得到 locality 等于
全策略地址并集的 proof-only relaxed LDC。因此策略描述长度本身不构成 C；真正留在
C 中的，是 branch support 接近全局、target-dependent proof/semantics，或超出有限轮次
有限字母表模型的连续/无界交互。若验证器本身是有限时间 bit-model，则任意有限 Merlin
字符串只产生有限可观察 view tree，因而也被该闭合覆盖。

## 三难定理

设 `h=\log_2|F|`。

**(i) 共同摘要分支。** 若满足 A，则

\[
  L\ \ge\ h-kH_2(\eta).
\tag{1}
\]

特别地，`F=\{0,1\}^k` 时

\[
  L\ge (1-H_2(\eta))k.
\tag{2}
\]

**(ii) 有限响应分支。** 若满足 B，并且 Dall’Agnol--Gur--Lachish 的 sample
theorem 在半径 `\rho/2`、字母表 `\Sigma` 和查询数

\[
  Q_r=O\!\left(2^r q_0(\alpha-\beta)^{-2}\right)
\tag{3}
\]

的参数窗口内适用，则存在常数 `c,C>0`（依赖 `Q_r,\Sigma`）使

\[
  h-s\ \le\ C\,|\Sigma|^{Q_r}\log_2|\Sigma|\,
  N^{1-\theta}\log_2(k+2),
  \qquad
  \theta=\frac{c}{Q_r^2\log^2(Q_r+2)}.
\tag{4}
\]

因此在 `h=\Omega(k)`、`N=k\operatorname{polylog}k`、固定 `\Sigma,q_0,r` 和 DGL
窗口成立时，必须有

\[
  s\ge h-o(k).
\tag{5}
\]

**(iii) 残余分支。** 在上述共同-proof/target-relative 语义和 key/response 分区仍然
成立的前提下，若一个候选方案同时声称 `L=o(k)`、`s=o(k)`、固定 `r`、近线性 `N`、
正半径 soundness，那么 (1)--(5) 排除 A/B；它必须落入 C。若它改变 verifier 量词、
proof 地址空间或消息泄漏模型，则属于额外的模型逃逸，不应被宣传为三难定理已覆盖。
因此，剩余正向问题不是“再找一个短坐标响应”，而是构造一种无界策略仍能产生
deterministic、word-consistent 的 JK parent seed，或证明该要求本身具有新的编码下界。

## 证明

### 共同摘要

固定摘要 `\omega`，令 `F_\omega` 是被它以平均误差至多 `\eta` 生成的目标词集合。
用均匀随机 `f\in F_\omega` 与 `Y=E(\omega;R)`，对每个坐标写出错误概率 `e_i`。
二元熵的标准上界给出

\[
  \log_2|F_\omega|\le\sum_{i=1}^k H_2(e_i)
  \le kH_2(\eta).
\]

最多 `2^L` 个摘要覆盖整个 `F`，故

\[
  |F|\le 2^L2^{kH_2(\eta)},
\]

即得 (1)。这一步不使用 verifier 的查询复杂度，只使用“一个摘要服务所有
coordinates”的量词。

### 有限响应

固定最大 key 桶 `\sigma`。其消息数至少为 `2^{h-s}`。对两个声明分支及所有
`2^r` 个响应分别做接受率估计，并以阈值 `(\alpha+\beta)/2` 输出正确位，否则输出
`\bot`。这得到 locality (3) 的 relaxed local decoder；在 `\rho/2` 邻域内，错误
声明仍不能越过阈值。

同一桶内不同目标在某个坐标上不同；若两 codewords 距离不超过 `\rho`，将一个作为
另一个的近 oracle 会同时违反完备性和错误 soundness。因此该桶内 codewords 具有
正距离，DGL sample theorem 可应用。共同 sample transcript 以
`O(|\Sigma|^{Q_r}\log|\Sigma|N^{1-\theta}\log(k+2))` 个符号恢复桶内全部消息；
Fano 不等式给出 (4)，再由最大桶熵 `h-s` 得到结果。

### 剩余类

若 A 不成立，任何坐标揭示前的有限共同摘要都不能达到所需平均目标重构；若 B 不成立，
在 B 的共同 key/target-relative 语义内，坐标揭示后的策略不能由有限长度响应枚举为
RLDC 分支。于是仍留在该语义的所有未被 (1)--(5) 覆盖的候选，必须显式说明一个无界
交互对象如何定义同一 global word、同一父节点 seed 和跨坐标的 exact consistency。
这里没有把“存在策略”误写成“存在一个确定 seed”；改变量词的候选则明确属于定理之外。

### 残余类的 JK 闭合检验

无界响应并不能在真正的 JK parent closure 下隐藏全局 seed。固定
`G:{0,1}^q\to\{0,1\}^{2q}`，定义

\[
  \operatorname{Exp}_{G,0}(u)=u,
  \qquad
  \operatorname{Exp}_{G,H+1}(u)=
  \operatorname{Exp}_{G,H}(G(u)_L)\,\|\,
  \operatorname{Exp}_{G,H}(G(u)_R).
\]

若一个深度 `H` 的全局 JK 树对每个目标 `f` 都有根 seed `u_f`，且每个内部节点
的输出确实等于两个 child seeds 的串接，那么该树的完整词必为
`\operatorname{Exp}_{G,H}(u_f)`。因此任何由此产生的**不同**完整词族
`\mathcal W` 都满足

\[
  |\mathcal W|\le 2^q.
\tag{6}
\]

证明只是根 seed 的计数：定义域只有 `2^q` 个 seed，展开是确定函数；不需要 lex-first、
有限响应、线性或可计算性假设。若目标到完整 JK 词的映射保持 `|F|` 个不同目标，
则必有 `q\ge\log_2|F|`。所以无界策略只有两种选择：

* 真的产生一个跨坐标、跨层共享的 root seed，此时受 (6) 的全局容量约束；或
* 不产生这种 seed/串接闭合，此时它尚未实现 JK 所需的 word-consistent parent closure。

这条检验对单一 RW 目标 (`|F|=1`) 是空的；它不能把单目标量词偷偷升级成高熵
family-level lower bound。它的作用是精确关闭“无界 Merlin 响应既保持整词闭合、又
完全绕过全局 seed 容量”的语义混用。

## 对 RW/JK 与 distributional soundness 的直接含义

1. **分布式 soundness 的正向路线。** singleton target projection 只有在能被同一个
   `\omega_f` 或同一个 global strategy 逐坐标解释时，才进入 A 或 C。若每个坐标各自
   选择理想 proof，则属于 `\forall i\,\exists\tau_i`，不满足 A，也没有 C 所需的
   parent closure。
2. **RW 地址尺度。** 若 `k` 为指数于底层输入长度的输出，任何 `o(k)` 的 pre-index
   summary 由 (2) 排除；有限 `r` 的 post-index response 由 (4)--(5) 排除（在 DGL
   窗口内）。因此现有地址尺度候选必须证明无界 strategy 的压缩/闭合，而不能把
   `poly(n,\log T)` 的逐坐标查询误当成共同 target channel。
3. **近线性 dPCP 的构造/下界分叉。** 若构造是固定有限 alphabet、固定 query、正半径
   且 family-level target-relative，则它必须在 proof length、key entropy、strategy
   boundedness 三者中至少支付一项；若它还采用 binary projection 2-query，则已有的
   RLDC 指数障碍更强。

## 关系、边界与晋级条件

* (1) 是共同摘要的通信/熵定理；(4) 是 key-indexed ACRR/RLDC 定理的统一记号。两者
  都需要共同 proof/address space，不能套到逐坐标独立 proof。
* `C` 不是“不可能性定理”：它是精确的未覆盖模型。要把它升级为顶级 barrier，必须
  证明 C 中的 word-consistent parent closure 会产生 RLDC/LDC，或给出一个新的
  interactive coding theorem。
* 若 `F` 只有一个目标，`h=0`，两个信息/家族下界都可能为空；这正是 RW 单目标
  量词与 family-level coding lower bound 之间的真实边界。
* `rho` 低于 DGL 半径窗口时，(4) 只保留阈值化/距离部分，不能冒称超线性样本下界。
* 式 (6) 只适用于真正的全树 root-to-leaf expansion；若候选只提供逐坐标回答而没有
  内部节点 seed 与串接方程，则应归入定理之外的 interactive strategy 模型。

## 证据来源

* [Approximate target-channel entropy barrier](../../mcsp-hardness-magnification/notes/195-approximate-target-channel-entropy-barrier-2026-08-16.md)
* [Key-indexed ACRR/RLDC dichotomy](key-indexed-acrr-rldc-dichotomy.md)
* [Message-inline RLDC compiler](message-inline-rldc-compiler.md)
* [Dall’Agnol--Gur--Lachish, TR20-154](https://eccc.weizmann.ac.il/report/2020/154/)
* [Gur--Minzer--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/abs/2512.12960)
