# Fully patchable private regions force a common information core

## Theorem

Let

\[
  C:\{0,1\}^{k}\longrightarrow\Sigma^{N}
\]

be an injective proof/codeword map with \(|\Sigma|\ge2\). For each coordinate
\(i\in[k]\) and declaration \(b\in\{0,1\}\), let \(V_{i,b}\) be a possibly adaptive
randomized **message-oblivious** verifier (it receives \(i,b\), not \(m\)) whose honest query path on \(C(m)\) is denoted
\(Q_{i,m_i}^{C(m)}(R)\).

Assume the following family-level conditions.

1. **Codeword completeness.** For every message \(m\) and coordinate \(i\),
   \(V_{i,m_i}\) accepts \(C(m)\) with probability one.
2. **Uniform complement patchability.** There is a set \(K\subseteq[N]\) such that, for
   every \(m,i\), all positions in \(P:=[N]\setminus K\) are the union of a jointly
   realizable family of private patch boundaries for the target \((m,i)\). Applying all
   patches produces a candidate proof that agrees with \(C(m)\) outside \(P\), follows the
   honest transcript until the first query in \(P\), and forces the wrong declaration at
   that first query.
3. **Coordinate soundness.** Every candidate proof has wrong-declaration acceptance at
   most \(\delta\) for \(V_{i,1-m_i}\).
4. **Disagreement hitting.** For every \(m,m'\) and every \(i\) with \(m_i\ne m'_i\), writing
   \[
     D(m,m')=\{j:C(m)_j\ne C(m')_j\},
   \]
   the honest path satisfies
   \[
     \Pr_R\!\left[
       Q_{i,m_i}^{C(m)}(R)\cap D(m,m')\ne\varnothing
     \right]\ge1-\beta .
   \tag{PC1}
   \]

If

\[
  1-\delta>\beta ,
\tag{PC2}
\]

then the restriction \(C_K(m):=C(m)|_K\) is injective. Consequently,

\[
  |K|\ge \frac{k}{\log_2|\Sigma|}.
\tag{PC3}
\]

In particular, a family-level ACRR whose entire complement of a purported common core is
fully patchable cannot have a sublinear common core. If the intended shared key/core has
length \(s<k/\log_2|\Sigma|\), at least one of the four assumptions must fail.

## Proof

Fix \(m,i\). Apply the global-coupling mass barrier to the jointly applied family of patches
from assumption 2. Since the patchable region is exactly \(P=[N]\setminus K\), assumptions
2 and 3 imply

\[
  \Pr_R\!\left[
    Q_{i,m_i}^{C(m)}(R)\subseteq K
  \right]\ge1-\delta .
\tag{PC4}
\]

Suppose, toward a contradiction, that \(C_K(m)=C_K(m')\) for distinct messages \(m,m'\).
Then \(D(m,m')\cap K=\varnothing\). On every path counted by (PC4), all queried positions lie
in \(K\), so the path cannot hit \(D(m,m')\). Therefore

\[
  \Pr_R\!\left[
    Q_{i,m_i}^{C(m)}(R)\cap D(m,m')\ne\varnothing
  \right]\le\delta .
\]

By (PC2), \(\delta<1-\beta\), contradicting the disagreement-hitting lower bound (PC1).
Thus \(C_K\) is injective. There are \(2^k\) messages and at most
\(|\Sigma|^{|K|}\) restrictions, so \(|\Sigma|^{|K|}\ge2^k\), proving (PC3).

## Interpretation

This theorem turns the two conditional mechanisms into one family-level barrier:

* full private patchability forces at least \(1-\delta\) of every honest path through the
  non-patchable core \(K\);
* disagreement hitting then forces the projection on that same \(K\) to encode every
  message.

The result is stronger than assuming a common core carries query mass: that mass is derived
from the patchability hypothesis. It is still not a general ACRR impossibility theorem. The
remaining escape classes are precisely:

* patchability fails because private regions are globally coupled;
* no common \(K\) exists because the core depends on the message or coordinate;
* disagreement hitting fails; or
* the target-relative family semantics needed for (PC1) is unavailable.

The theorem does not imply a superlinear lower bound by itself: a linear-size core is
compatible with \(N=\Theta(k)\). Its RW/JK consequence is instead a scale obstruction when
the proposed common key is restricted to \(\operatorname{poly}(n)\) while the encoded output
dimension \(k\) is much larger.

## Relation to existing modules

The proof is the composition of the
[global-coupling mass barrier](global-coupling-mass-barrier.md) with the common-core
information argument previously recorded in note 191. The disagreement-hitting condition is
explicit and is not inferred from ordinary target-relative soundness; the family quantifier
is essential.
