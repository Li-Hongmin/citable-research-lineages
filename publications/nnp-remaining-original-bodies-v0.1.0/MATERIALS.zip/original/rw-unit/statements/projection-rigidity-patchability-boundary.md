# Projection-rigidity boundary for one-shot patchability

## 结论地位

这是把 one-shot K-compatible forcing candidate 连接到 dPCP 局部约束图的图论模块。
它只覆盖 projection/局部关系 verifier，不声称一般 dPCP 都是 projection。核心结论是：
双向刚性边上的局部约束会把一个候选 assignment 的变化集限制为低边界割；因此
coordinate-robust forcing 若要存在，必须使用柔性边、低边界分量，或放弃“局部关系
通过才可输出 wrong bit”的语义。

## 模型

令 G=(V,E) 为 dPCP 的约束图。每条边 e=(u,v) 有局部接受关系
R_e⊆Σ_u×Σ_v。固定 honest assignment a*。取一组边 E_rig⊆E，称 e=(u,v)
在 a* 处 bi-rigid，如果

       (a*_u,b)∈R_e  implies b=a*_v,
       (c,a*_v)∈R_e  implies c=a*_u.                    (PR1)

也就是说，在该边上固定任一端的 honest label，另一端没有不同的可接受 label。

令 μ_i 是坐标 i 的 verifier 在 E 上抽取局部约束的固定分布；本定理要求边在读取
assignment 之前抽取，或至少其分布不依赖已读 label。假设 wrong-declaration
acceptance 只能发生在抽到的局部关系被满足时；这是标准“局部检查通过后才输出
wrong bit”的 non-adaptive projection verifier 语义。

## 定理：刚性边界上界

对任意候选 assignment a，定义变化集

       P(a)={v∈V:a_v!=a*_v}

以及 bi-rigid cut

       ∂_rig P = { e=(u,v)∈E_rig :
                   exactly one of u,v lies in P }.

则 a 在 ∂_rig P 上的每条局部约束都被违反。因此

       Pr[wrong declaration accepts on a]
          <= 1 - μ_i(∂_rig P).                             (PR2)

特别地，若一个 one-shot forcing candidate has wrong-declaration acceptance at least
α_i, then necessarily

       μ_i(∂_rig P) <= 1-α_i.                              (PR3)

## 证明

设 e=(u,v)∈∂_rig P。若 u∉P、v∈P，则 a_u=a*_u 且 a_v!=a*_v；由 (PR1)，
(a_u,a_v)不属于 R_e。u∈P、v∉P 的情形同理。因此每次抽到 ∂_rig P 都会被局部
检查拒绝；wrong acceptance 只能发生在其补集上，得到 (PR2)，再重排得到 (PR3)。

## 图扩张推论

定义 rigidity expansion profile

       Φ_i(s)=min { μ_i(∂_rig P) :
                    ∅!=P!=V and min(|P|,|V∖P|)>=s }.      (PR4)

若 Φ_i(s)>1-α_i，则不存在一个变化集两侧大小都至少为 s、且能以 α_i 概率
forcing wrong declaration 的 one-shot candidate。更一般地，任何 one-shot
K-compatible candidate with P=V∖K and wrong acceptance α_i 必须满足

μ_i(∂_rig(V∖K)) <= 1-α_i.                            (PR5)

因此，若一个 proof graph 对所有小 K 都有
μ_i(∂_rig(V∖K))>1-α_i，则 C47 的 K-compatible candidate 不存在，或者其
forcing 语义并非局部关系通过型。

## 只有单向 projection 时能得到什么

C50 的双向刚性不能由“projection”一词自动推出。设图是二部图
`A∪B`，每条边 `e=(a,b)` 的关系是从左到右的 projection
`b=π_e(a)`，而 `y*` 是 honest labeling。若候选 assignment 为 `y` 且只修改右侧，令
`P_B={b:y_b!=y*_b}` 且保持 `y_a=y*_a` 对所有左点成立，则每条与 `P_B`
相 incident 的边都被违反：因为 honest 左标签唯一指定 `b*`。于是对任意固定
边分布 `μ_i`，

       Pr[wrong declaration accepts]
          <= 1 - μ_i(E(A,P_B)).                         (PR10)

这给出一个真正可用、但只有一侧的核心界。若右度为 `d_B` 且边均匀，则
`μ_i(E(A,P_B))=|P_B|/|B|`；因此接受率至少 `α_i` 的右侧-only forcing
candidate 必须保留 `|B|·α_i` 个未修改右点。它不能直接给出 C50 的低边界割，
但能排除“只改很小右侧私有区就得到常数错误接受率”的解释。

反方向若保持右侧 honest 而修改左侧，单向 projection 本身不够；若额外有
left-canonical，则每个 `P_A={a:y_a!=y*_a}` 中的左点至少有一条 incident edge 被违反，故

       Pr[wrong declaration accepts]
          <= 1 - |P_A|/|E|,                              (PR11)

在均匀 `d_A`-左正则图上为 `1-|P_A|/(d_A|A|)`。这是 star-rigidity，而不是
逐边 bi-rigidity；当 `d_A` 很大时，(PR11) 可能远弱于 (PR2)。若候选同时修改
左右两侧，单向 projection 与 left-canonical 都不能阻止边上的变化相互补偿，
必须另证 bi-rigidity、低边界条件或 target-binding。

这个缺口不是技术性措辞，而有最小反例。取一个左点 `a` 和两个右点 `b_0,b_1`，
左字母表为 `{0,1}`、右字母表为 `{0,1}`。令

       π_{(a,b_0)}(0)=π_{(a,b_0)}(1)=0,
       π_{(a,b_1)}(0)=0,
       π_{(a,b_1)}(1)=1.

诚实 assignment 是 `(a,b_0,b_1)=(0,0,0)`。给定任意右邻域标签，第二条边的
projection 已经唯一决定 `a`，所以该图满足 left-canonical；但候选
`(1,0,1)` 仍满足两条边。其变化集是 `{a,b_1}`，核心只保留 `b_0`，且唯一跨越
核心的边 `(a,b_0)` 也不拒绝，因为第一条 projection 对左标签不 injective。
因此“projection + left-canonical ⇒ C50”是假的；必须显式加入逐边反向 injectivity、
bi-rigidity，或一个能阻止这种双侧补偿的 target-binding 条件。

### 对 GM--Minzer--Weissenberg--Zheng 的精确审计

该工作的公开构造链明确保留 projection constraints；其中间的 udPCP 还使用
left-canonical，且复制变换显式证明 projection 与 left-canonical 的保持，但最终
组合定理本身只给出 projection 约束。因而可以直接套用 (PR10) 到“左标签固定、只
改右侧”的候选，却没有文献依据把 C50 的双向刚性或 (PR11) 的定量星形刚性升级到
最终 dPCP。这个差异是路线决策点：

1. 若能证明最终组合仍有可计算的 bi-rigidity/星形扩张，并把错误声明限定为局部
   关系通过型，则 C50--C51 才可能成为该构造的长度下界；
2. 若不能，则 projection-rigidity 路线在 GM 构造上到此为止，下一候选必须是
   shared target-binding 或直接的 RLDC/LDC 归约，而不是把 left-canonical 误读成
   global proof uniqueness。

这也解释了为什么 left-canonical 不是 simultaneous coordinate robustness：它只说给定
一个左点的右邻域标签时，满足全部 incident constraints 的左标签至多一个；它不提供
一个全局唯一 assignment，也不控制双侧同时修改。

## Bottom witness from a dead-set

刚性分析还可以给出一个直接的 bottom 证书。令坐标 \(i\) 的局部 verifier 从边
\(e\in E\) 按分布 \(\mu_i\) 取样；在给定局部标签 \(\ell_e\) 时，两个声明分支的
条件接受概率记为 \(a_{i,0}(e,\ell_e)\) 和 \(a_{i,1}(e,\ell_e)\)。假设

1. **branch exclusivity：**
   \(a_{i,0}(e,\ell)+a_{i,1}(e,\ell)\le u\) 对所有局部视图成立；
2. 存在 honest assignment \(a^\ast\)、变化集 \(S\) 和候选 assignment \(a^S\)，
   使 \(a^S\) 在 \(S\) 外等于 \(a^\ast\)，且
   \(\operatorname{dist}(a^S,a^\ast)\le\delta\)；
3. **dead-set：** 每条满足 \(e\cap S\ne\varnothing\) 的边在候选局部视图上同时杀死
   两个分支，即
   \(a_{i,0}(e,a^S_e)=a_{i,1}(e,a^S_e)=0\)。

令

\[
h_i(S)=\mu_i\{e:e\cap S\ne\varnothing\}.
\]

则该候选 proof 满足

\[
p_{i,0}(a^S)+p_{i,1}(a^S)\le u\,(1-h_i(S)).
\tag{PR12}
\]

证明只是按命中与未命中的边分解期望：命中边贡献为零，未命中边的两个分支总和
至多为 \(u\)。因此若 \(u=1\) 且 \(h_i(S)>1-2\beta\)，便有
\(\tau_\delta<2\beta\)，直接触发 [non-bottom coordinate-robustness LDC barrier](nonbottom-coordinate-robustness-ldc-barrier.md)
的逃逸条件。

对 projection 约束，一个可核验的 dead-set 充分条件是：保持右侧 honest，只改变
左侧 \(S\)，并要求每条 incident edge 的 projection 将新左标签映到不同于 honest
右标签的值。注意 left-canonical 只保证每个改变的左点至少有一条坏边，并不保证
所有 incident edges 都坏；所以它不能单独推出 (PR12) 中的高 \(h_i(S)\)。这正是
检查 GMWZ 最终 projection 图时必须区分的两个量词。

## 直接和长度推论

对每个坐标 i 和整数 s≥1，定义小核心边界参数

       Ψ_i(s)=min { μ_i(∂_rig(V∖K)) :
                    1<=|K|<=s and K!=V }.                (PR6)

考虑一个显式 core model：对每个消息 m 和坐标 i，它指定一个非空
K_{m,i}，并提供 C47 所需的 one-shot candidate，错误接受率至少为 α_i。若

       Ψ_i(s)>1-α_i,

则必有 |K_{m,i}|>s。若进一步对固定消息 m 假设每个 proof vertex 至多属于 d 个
坐标 cores，即

       Σ_{i=1}^k 1[v∈K_{m,i}] <= d  for every v∈V,       (PR7)

则

       N=|V| >= (1/d) Σ_{i=1}^k |K_{m,i}|
         > (1/d) Σ_{i=1}^k s_i,                            (PR8)

其中 s_i 是满足 Ψ_i(s_i)>1-α_i 的核心阈值。若所有 s_i>=s，则

       N > ks/d.                                          (PR9)

这是一个可直接检验的 projection-dPCP proof-length barrier：刚性扩张给出每个
坐标 core 的最小大小，core-incidence 给出不同坐标之间不能无限复用这些位置。
它不要求 cores 在不同消息之间相同。

## 典型边界例子

### 连通 equality/projection 图

若所有边都要求两个端点 label 相等，则每条边都是 bi-rigid。若 E_rig 的图连通，
任何全局满足 assignment 只要在一个位置与 a* 相同，就必须在整个连通分量上相同。
因此一个保留非空 K 的 one-shot accepted patch 不存在；任何 forcing 必须改变整个
连通分量或让刚性边被拒绝。

### 完全柔性关系

若 R_e=Σ_u×Σ_v，则 E_rig为空，(PR2) 没有约束。此时局部 patchability 可能很强，
但局部约束本身不提供 soundness；必须依靠另一个 global target-binding mechanism。

这两个例子说明：刚性与 patchability 是一条真实的结构分叉，而不是把“所有小错误
都可 forcing”当作 dPCP 的默认性质。

## 与 C47/C48 的组合

C47 只需 one-shot K-compatible candidate。由 (PR3)，在 projection 图中这等价于
要求 complement P=V∖K 是一个低 rigidity-boundary 变化集。于是可以把 proof-graph
分析拆成两个可检验步骤：

1. 用 rigidity expansion 证明所有小核心 K 的补集边界质量太大，因而 one-shot
   candidate 不存在；或
2. 找到低边界/柔性组件，验证它们确实支持 one-shot forcing，再将其 cores 送入
   C47 的 disagreement transversal 与 C48 的 specifying-set 计数。

若采用显式 core model，还可将 (PR8)--(PR9) 与 C48/C49 叠加，区分“每个坐标
必须支付的局部核心长度”和“所有坐标合起来必须承载的消息信息”。

这避免把“dPCP 有局部错误”直接等同于“存在一个对整个 private region 有效的
forcing proof”。局部错误只有在跨越刚性边界后仍保持可接受时，才能成为 C47 的
candidate。

## 边界

本模块要求 wrong acceptance 以局部关系通过为必要条件；若 verifier 允许通过额外
global state 在局部关系失败时仍输出 wrong bit，则必须把该 state 纳入约束图。它也
不处理非 projection 的多元关系、随机 proof oracle 或带隐藏 Merlin strategy 的
语义。因而本结果是一个 proof-graph diagnostic/theorem interface，而不是一般
coordinate-robust dPCP impossibility。GM--W--Z 的 projection、left-canonical 保持与
最终组合的 projection 约束见其公开稿 [arXiv:2512.12960](https://arxiv.org/abs/2512.12960)
的 Sections 4、9；本模块只从这些结构抽取 (PR10)--(PR11)，不把文献结果升级为
coordinate-robust theorem。
