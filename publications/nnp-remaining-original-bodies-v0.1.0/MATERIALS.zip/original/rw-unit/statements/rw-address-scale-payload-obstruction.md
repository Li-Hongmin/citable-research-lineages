# RW 地址尺度 payload 暴露障碍

## 定理地位

这是对 compressed tuple oracle 的一个直接、可证伪的必要条件。它不排除所有
compressed history；它只排除那些在低复杂度、随机访问意义下把上一阶段 AVOID outsider
作为固定 payload 暴露出来的 accessor。

## 命题

令 `G_n:{0,1}^n -> {0,1}^{2n}` 是固定 AVOID decoder，且存在覆盖窗口

```text
{ truth tables of Boolean circuits of size <= s(n) } subseteq Range(G_n).
```

设某个 RW 阶段产生 `B_i in {0,1}^{2n_i}`，并且
`B_i notin Range(G_{n_i})`。令下一阶段 block width 为 `2q_i`，其中
`q_i >= n_i`。假设存在一个统一的 one-bit random-access accessor

```text
A_i(sigma, j, u) in {0,1},
```

其中 `sigma` 是长度 `d_i` 的共享 key，`j` 是 block address，`u` 是 block 内地址，
并满足：

1. `A_i` 的 Boolean circuit size 为 `a_i`；
2. 某个固定 key/address/offset `(sigma_i,j_i,o_i)` 满足
   `A_i(sigma_i,j_i,o_i+u)=B_i[u]` 对所有 `u in [2n_i]` 成立；
3. `o_i+u` 的地址算术在 `O(log q_i)` 大小内可实现。

这里 `CC(B_i)` 指以 `ceil(log_2(2n_i))` 个地址位为输入、真值表恰为 `B_i` 的最小
Boolean circuit size；`u` 采用同样的二进制地址编码。

则

```text
CC(B_i) <= a_i + d_i + O(log L_i + log q_i).
```

因此，只要

```text
a_i + d_i + O(log L_i + log q_i) <= s(n_i),
```

就与 `B_i notin Range(G_{n_i})` 矛盾。换言之，在 coverage 窗口内，任何能够以
base-address 复杂度随机访问旧 outsider payload 的 compressed tuple oracle 都不能存在。

## 证明

构造一个计算 `B_i` 真值表的电路：输入为 `u`，把固定常数 `sigma_i`、`j_i` 和
`o_i` 硬接到 `A_i`，用一个 `O(log q_i)` 大小的加法器把 `o_i+u` 送入地址端，
输出 `A_i(sigma_i,j_i,o_i+u)`。硬接 `sigma_i` 和 `j_i` 需要在电路描述中保留
`d_i+O(log L_i)` 个常数/地址位；由假设该输出等于 `B_i[u]`，所以电路大小至多
`a_i+d_i+O(log L_i+log q_i)`。coverage 假设随后强制 `B_i in Range(G_{n_i})`，矛盾。

## 对多输出 block accessor 的精确边界

若 accessor 只一次输出完整 `2q_i`-bit block，而没有 one-bit random-access 端口，
从其多输出电路得到 `B_i` 的真值表还需要一个 output multiplexer；其成本必须显式
计入 `a_i`。因此本命题使用的是“multi-output accessor + 低成本 random-access
selector”，不能把裸的 `2q_i`-bit 输出电路自动误报为 base-address accessor。

同样，若 `B_i` 只作为一个不可随机访问的整体字符串藏在 history block 中，或 accessor
输出的是经过不可逆/高复杂度编码的 payload，本命题不适用；那正是 compressed tuple
oracle 仍待研究的真实剩余接口。

## RW 解释

在 RW 迭代中，`B_i` 是前一阶段 AVOID 的 outsider，coverage 给出
`CC(B_i)>s(n_i)`。因此，一个声称把 history 压到 `poly(n_0,log T_i)` 的
address-scale accessor，若还能用固定 block/address 逐位恢复 `B_i`，会立即违反上式
（对 near-linear `s(n_i)`，`s(n_i)` 最终超过任何固定的
`poly(n_0)+O(log L_i+log q_i)`）。

所以 compressed construction 若要继续，必须明确选择以下至少一项：

* 不提供旧 `B_i` 的低复杂度 random-access projection；
* 改变 payload 语义，使暴露的词不再是 AVOID outsider；
* 让 accessor/selector 成本达到 coverage threshold；或
* 证明一个新的、不是逐位暴露 payload 的 JK/target-binding mechanism。

这把“compressed tuple oracle”从笼统希望收窄为一个可检验的 semantic hiding 问题，
而不是声称所有压缩器都已被排除。

## 证据边界

本命题只用 coverage 的逆否和随机访问电路合成；不使用 RM 低度性、PCP soundness 或
RLDC 下界。它与 [RW fixed-history capacity budget](rw-fixed-history-capacity-budget.md)
互补：C66 排除实际 history 的窗口数量不足，本文排除低复杂度 accessor 直接暴露旧
outsider 的语义捷径。
