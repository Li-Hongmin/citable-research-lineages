# Satisfying-list collapse yields a global-word indexed channel

This file states the bridge from standard satisfied-edge list soundness to the global-word
distributional hypothesis used by the indexed-list compiler.

## Theorem

Let `Gamma` be a finite alphabet, let `M` be positive, and let
`Y = {y^(1), ..., y^(L)} subseteq Gamma^M` be a candidate family with pairwise relative
Hamming distance at least `Delta > 0`.
For every coordinate `j in [M]`, let `D_j` be a randomized adaptive decoder making at most
`q` queries to one common proof oracle `z in Sigma^N`. Let `S_j(z) in {0,1}` be the local
satisfaction predicate used by the underlying dPCP, evaluated on the same local view as
`D_j`. Write `J` for a uniform random coordinate.

Fix a proof domain `Z`. Assume that for every `z in Z` there are a list
`Y_z subseteq Y`, a center word `c(z) in Y_z`, and parameters
`epsilon_list, sigma, kappa >= 0` such that:

1. **List soundness on satisfied views.**
   `Pr[S_J(z)=1 and D_J(z) notin {y_J : y in Y_z}] <= epsilon_list`.
2. **Satisfaction defect.** `Pr[S_J(z)=0] <= sigma`.
3. **List collapse around one word.**
   `Pr_J[exists y in Y_z with y_J != c(z)_J] <= kappa`.
Then every `z in Z` satisfies

`Pr[D_J(z) != c(z)_J] <= epsilon_list + sigma + kappa`.

Consequently, if `epsilon_tot := epsilon_list + sigma + kappa < Delta/2`, the
global-word distribution-to-index theorem applies: for every `eta in (0,1)`, a
target-independent index decoder recovers the center index using

`r = ceil(2 log((L-1)/eta)/(Delta-2 epsilon_tot)^2)`

independent coordinate samples and at most `r q` proof queries, with failure probability
at most `eta`.

### Target-relative corollary

Suppose `Pi:[L] -> Sigma^N` is an injective common-address proof map and, for every target
`s` and every proof `z` with `dist(z,Pi(s)) <= rho`, the three assumptions above hold with
the same parameters and with center `c(z)=y^(s)`. Then the resulting index decoder is a
bounded-error relaxed local decoder for `s` on radius `rho`, with locality `r q` and
completeness at least `1-eta`. If `epsilon_tot < Delta/2`, distinct proof words satisfy
`dist(Pi(s), Pi(t)) > rho`.

## Proof

Fix `z` and abbreviate `c=c(z)`, `Y_z=Y'`, and
`A_J = {y_J : y in Y'}`. If `D_J(z) != c_J`, then one of the following holds:

* `S_J(z)=0`;
* `S_J(z)=1` and `D_J(z) notin A_J`;
* `S_J(z)=1`, `D_J(z) in A_J`, but every list word producing that symbol differs
  from `c` at coordinate `J`.

The first event has probability at most `sigma`, and the second has probability at most
`epsilon_list`. The third event is contained in
`{exists y in Y' : y_J != c_J}`, whose probability is at most `kappa`. A union bound proves
the displayed global-word bound.

The index-decoder conclusion is exactly the sampling argument of the global-word bridge
with error parameter `epsilon_tot`. For the target-relative distance claim, if
`dist(Pi(s),Pi(t)) <= rho` for distinct `s,t`, apply the target-relative assumptions for
target `s` to `z=Pi(t)`. Honest completeness for `Pi(t)` makes the decoder output
`y^(t)` with probability one, while the global-word bound for target `s` is below
`Delta/2`; this contradicts the pairwise distance at least `Delta` between `y^(s)` and
`y^(t)`.

## Why the two correction terms are real

The term `sigma` is not cosmetic. Standard dPCP list soundness controls only the event that
a **satisfied** local view decodes outside the list. If an assignment violates a large
fraction of checks, that fraction is invisible to the list-soundness event and must be paid
as `sigma` before one can claim a global-word error bound.

The term `kappa` is also necessary. A list such as `{0^M,1^M}` can support coordinatewise
mixtures: every coordinate may choose a symbol from the list while no single list word
explains the resulting word. Here the list has large coordinate union radius, exactly the
phantom-word obstruction. Thus ordinary list soundness becomes a global-word hypothesis only
after a quantitative list-collapse statement.

## Scope and relation to the indexed bridge

This theorem is a parameterized bridge, not a claim that current dPCP constructions satisfy
the collapse condition. It isolates the minimum extra statement needed to turn a standard
satisfied-edge/list guarantee into the hypothesis of
[global-word distributional soundness yields an indexed list channel](global-distribution-to-indexed-list-bridge.md).
The candidate family may be information-theoretically known without being efficiently
enumerable. Target binding, history compression, and RW/JK parent closure remain separate
requirements.

The proof is a direct event decomposition; the substantive research question is whether a
near-linear dPCP/PCPP can force `sigma + kappa` below the separation gap while preserving one
global proof and the required address scale.
