# DHK dPCP 输出元组的 batching barrier

## 结论地位

这是一个针对 Dinur--Harsha--Kindler（DHK）dPCP 构造接口的参数化 barrier，
不是对所有 distributional-sound dPCP 的一般不可能性。它说明：把 DHK 的
`ALG-CKT SAT_F` 输出函数元组直接当作 RW 的 `k` 个同时坐标，不能同时保留
“同一 proof、固定小 answer/query 参数”这两个要求。

原始依据是 DHK Definition 3.5--3.6、Lemma 6.8 与 Theorem 5.2：decoder 的输入是
一个函数元组 `F`（论文在 Definition 3.5 的 `l-1` 记号与 Theorem 5.2 的 `l`
记号之间有索引偏移；下文的 `ell` 统一表示输出函数的个数），初始完备
assignment 显式分成 `pi=a◦b◦s`，其中 `b_i=F_i(a)`；Theorem 5.2 的
answer-size 上界为 `O(m(m+ell))`，且其 distributional-soundness 量词是对每个
输入 pair `(Phi,F)` 存在理想 proof。

## 命题：两种批处理方式的二分

令 `Phi` 是一个 computation relation，所有满足 assignment `a` 的目标输出都相同，
即 `f(a)=y in Sigma_0^k`。尝试直接使用 DHK Theorem 5.2 为每个坐标构造
coordinate verifier，有两种黑箱方式：

### A. 一次调用、批量输出

若同一个 DHK invocation 要让 proof 同时暴露全部 `k` 个目标坐标，并且每个输出函数
占一个 field-valued component，则必须取 `ell>=k`。若把所有 bits 打包成一个 field
element，则需要 `|F|>=2^k` 才能无损编码任意 `k`-bit output；这同样破坏固定有限域/常数
alphabet 语义。

在逐 component 方案下，Theorem 5.2 的参数至少变为

```text
answer size = O(m(m+k)),
```

而不是固定 `O(poly(m))` 的 answer。初始完备 proof 的 `b` 区也显式承载整个目标词。
因此这条路线没有给出 RW 所需的固定小 query/answer、同一地址空间的 ACRR。

### B. 每坐标一次调用

若对每个 `i` 单独取 `F=(F_i)`，则每次调用只有 `ell=1`，但 DHK 定义只保证

```text
for every (Phi,F_i), there exists a proof Pi_i.
```

它没有保证存在一个 proof `Pi` 同时适用于所有 `F_i`。在 Lemma 6.8 的完备 witness
布局中，`b=F_i(a)` 是 proof assignment 的显式字段；换坐标会改变这个字段，除非另
加一个 proof-independence/共享 commitment 定理，不能把 `Pi_i` 识别为同一个 global
proof。

## 证明

对 A，DHK Lemma 6.8 的完备性要求 `b_i=F_i(a)`，故一次调用要输出 `k` 个独立
field-valued coordinates，就需要至少 `ell=k` 个函数；Theorem 5.2 直接给出
`O(m(m+ell))=O(m(m+k))` 的 answer-size 依赖。若改为单 field 元素打包，有限域元素
只能承载 `log_2|F|` bits，任意 `k`-bit 输出要求 `log_2|F|>=k`。

对 B，Definition 3.6 的完备性量词是逐个输入 pair `(Phi,F)` 存在一组 provers，且
distributional soundness 也逐 pair 给出理想 proof；量词中没有
`exists Pi forall i`。因此不能从这些定理推出同一 `Pi` 对所有 `F_i` 成立。DHK
初始 verifier 的 `pi=a◦b◦s` 进一步显示，坐标函数值进入 proof 的完备 assignment，
所以“把不同坐标调用的 proof 视为同一 proof”不是纯记号重命名。

## 对 ACRR 的精确含义

该 barrier 不否定 DHK 的 distributional soundness，也不否定存在其他 shared-proof
构造；它关闭的是一个具体的黑箱替换：

```text
DHK(F_i) for each i  ->  one simultaneous ACRR
```

要越过它，至少需要一个新的 **output-independent shared commitment** 接口，满足：

1. 完备 proof 的核心不随 `F_i` 改变；
2. 目标坐标只作为 verifier 的局部 predicate 进入，而不是写入 proof 的独立 `b` 区；
3. 所有 `i` 共用同一 address space 与 distributional idealization；
4. commitment/evaluator 的长度和 answer/query 仍在 `poly(n,log T)` 地址尺度。

这正是 ACRR 的新构造问题，而不是从 DHK 定义自动得到的推论。特别地，本命题
只关闭“把 DHK 作为黑箱逐坐标调用”的替换；它不排除一个重新设计、且能证明
共享 commitment 与共同地址空间的新 dPCP 定理。

## 边界

若某个具体 DHK 实现能够证明 provers 的核心只编码 `a,s`、并能把所有 `F_i(a)` 作为
外部局部 predicate 读取，那么它可能绕过本命题的 B 分支；但这需要逐行证明一个比
DHK theorem statement 更强的 proof-independence 和 common-address property。若把所有
`F_i` 批量塞入同一个 invocation，则 A 分支的 `ell`/field-size 代价不可省略。

因此本命题是一个可复用的路线筛选器：在没有 output-independent shared commitment
之前，DHK distributional soundness 只能提供 singleton-output bridge 的条件性语义，
不能直接提供 RW 的 simultaneous coordinate-robust proof。

## 来源

- [Dinur--Harsha--Kindler, TR15-085](https://eccc.weizmann.ac.il/report/2015/085/download)
- [DHK paper, Definition 3.5--3.6, Lemma 6.8, Theorem 5.2](https://eccc.weizmann.ac.il/report/2015/085/download)
