# Approximate indexed lists still compile through a robust smooth outer decoder

## Theorem

Fix \(L\) target indices \(s\in[L]\), message words
\(m^{(s)}\in\{0,1\}^k\), and a common base proof address space. Let

\[
  C:\{0,1\}^k\longrightarrow\Gamma^M
\]

be an adaptive \(q_D\)-query decoder \(\mathsf{Dec}_i\) for each message coordinate
\(i\), whose output is a bit (or \(\bot\)). Fix an outer radius \(\delta\in[0,1]\),
parameters \(\alpha_C>\beta_C\), and a smoothness parameter \(\lambda\). Assume:

1. **Near-codeword outer correctness.** For every \(s,i\) and every
   \(y\in\Gamma^M\) with
   \(\operatorname{dist}(y,C(m^{(s)}))\le\delta M\),
   \[
     \Pr[\mathsf{Dec}_i^y=m_i^{(s)}]\ge\alpha_C,
     \qquad
     \Pr[\mathsf{Dec}_i^y=1-m_i^{(s)}]\le\beta_C.
   \tag{A1}
   \]
   Perfect near-codeword completeness is the special case \(\alpha_C=1\).

2. **Robust smoothness.** For every such \(y\), every adaptive query step \(u\), every
   transcript consisting of the first \(u-1\) honest answers from \(y\), and every
   \(t\in[M]\),
   \[
     \Pr[\text{the next query of }\mathsf{Dec}_i\text{ is }t\mid\text{that transcript}]
     \le\frac{\lambda}{M}.
   \tag{A2}
   \]

3. **Approximate indexed list soundness.** For every target \(s\) and every base proof
   \(z\) with \(\operatorname{dist}(z,\Pi^{(s)})\le\rho_0P_0\), there is one list
   \[
      Y^{s,z}=(y^{s,z}_1,\ldots,y^{s,z}_L)\in(\Gamma^M)^L
   \]
   independent of \(i\), such that
   \[
      \operatorname{dist}\bigl(y^{s,z}_s,C(m^{(s)})\bigr)\le\delta M,
   \tag{A3}
   \]
   and
   \[
     \frac1M\sum_{t=1}^M
       \Pr\!\left[
       D_t^z\notin\{\bot\}\cup\{(a,y^{s,z}_a[t]):a\in[L]\}\right]\le\varepsilon .
   \tag{A4}
   \]
   The base decoder \(D_t\) makes at most \(q\) proof queries and returns either
   \(\bot\) or \((a,\gamma)\in[L]\times\Gamma\).

For \(R=\lceil P_0/k\rceil\), append the selector matrix from Theorem 3.9 and use the
same selector-equality verifier. Then the compiled proof has selector-symbol length

\[
  N\le 2P_0+k,
\]

query complexity at most \(q_Dq+2\), honest correct-claim acceptance at least
\(\alpha_C\), and, for every compiled proof \(z'\) with
\(\operatorname{dist}(z',\widehat\Pi^{(s)})\le\rho_\star N\) and
\(\rho_\star\le\rho_0P_0/N\),

\[
  p_{i,1-m_i^{(s)}}(z')\le
  \beta_C+q_D\lambda\varepsilon+2\rho_\star .
\tag{A5}
\]

Consequently, if

\[
  \alpha_C>\beta_C+q_D\lambda\varepsilon+2\rho_\star,
\tag{A6}
\]

the compiled system has a simultaneous target-relative coordinate gap. The exact-word
Theorem 3.9 is the special case \(\delta=0\), \(\alpha_C=1\), and \(\beta_C=0\).

## Proof

The honest compiled proof has every selector cell equal to \(s\), and every base call
returns \((s,y^{s,\Pi^{(s)}}_s[t])\). By (A1), the outer decoder accepts the correct
message bit with probability at least \(\alpha_C\). The selector-symbol length and query
count are unchanged from Theorem 3.9.

Now take a proof \(z'\) in the stated radius and write \(z\) for its base portion. The base
radius condition gives \(\operatorname{dist}(z,\Pi^{(s)})\le\rho_0P_0\). Let \(B\) be the
corrupted selector cells and \(c_r\) the number of corrupted cells in repetition \(r\).
As in Theorem 3.9,

\[
  \frac{|B|}{Rk}=\frac1R\sum_{r=1}^R\frac{c_r}{k}\le 2\rho_\star .
\tag{A7}
\]

If the selector equality passes with a decoded tag \(a\ne s\), the sampled selector cell
must be corrupted, contributing at most \(2\rho_\star\).

Consider the remaining executions, where all accepted base tags equal \(s\). If no base
call returns a symbol outside \(y_s^{s,z}[t]\), the outer decoder sees the single word
\(y_s^{s,z}\). By (A3) and (A1), its wrong-bit probability is at most \(\beta_C\).
Otherwise let the first base call outside the \(s\)-th indexed word occur at step \(u\),
at position \(t\). Before that call, the outer transcript is the honest transcript of
\(y_s^{s,z}\), so robust smoothness (A2) applies. The event that the call is outside the
indexed list is bounded by the summand in (A4). Therefore

\[
\begin{aligned}
  \Pr[\text{first bad base call at step }u]
  &\le \sum_{t=1}^M \frac{\lambda}{M}
      \Pr\!\left[D_t^z\notin\{\bot\}\cup
        \{(a,y_a^{s,z}[t]):a\in[L]\}\right].
\end{aligned}
\tag{A8}
\]

Summing the \(q_D\) possible outer steps and using (A4) gives at most
\(q_D\lambda\varepsilon\). The three failure modes—selector corruption, a first bad base
call, and a wrong outer decision on the uncorrupted \(y_s^{s,z}\)—are combined by a union
bound, proving (A5). Condition (A6) is exactly the positive completeness/soundness gap.
\(\square\)

## Scope and the actual new requirement

The theorem is a conditional compiler, not a claim about current dPCP constructions.
Approximate indexed soundness alone is insufficient: without (A2), a near-codeword list word
can steer an adaptive outer decoder toward a concentrated exceptional coordinate. Without the
single \(i\)-independent list in (A4), different outer queries can still use phantom words.
Thus the relaxed target does not remove the global-word requirement; it isolates the additional
outer-code obligation as **near-codeword smoothness** and adds only the explicit term
\(\beta_C\).

For the RW/JK route, the useful parameter window is
\(\alpha_C-\beta_C-q_D\lambda\varepsilon=\Omega(1)\),
\(\rho_\star=o(1)\), and \(P_0=O(k\,\operatorname{polylog}k)\). If the outer decoder has
\(\lambda=\Theta(k)\), the theorem still requires \(\varepsilon=O(1/k)\), exactly as in
Theorem 3.9. A genuine escape therefore needs both an indexed global list and a
near-codeword outer decoder with \(\lambda=o(k)\), or a different proof of coordinate
robustness.

## Sources and relation to existing modules

* [Theorem 3.9 in the main paper](../papers/Address-Scale-Barriers-for-Shared-Proof-Coordinate-Robustness/paper.md)
  is the exact-word special case.
* [Exchangeable approximate indices](exchangeable-approximate-index-rldc-bridge.md)
  shows that a different symmetry assumption can turn average index error into coordinate
  error; it does not provide (A2).
* [Weighted distributional-to-coordinate barrier](weighted-distributional-to-coordinate-barrier.md)
  explains why average error alone cannot replace (A1)--(A2).
* The theorem is a new conditional composition lemma for this project; it does not claim that
  Gur--Minzer--Weissenberg--Zheng's current dPCP/PCPP construction supplies (A3)--(A4) at RW
  address scale.
