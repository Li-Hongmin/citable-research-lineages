# Variable-query imperfect-completeness Lorenz envelope

## Theorem

Fix a positive radius rho and a constant c >= 0. Let infinitely many binary
common-proof maps
\[
  \Pi_k:\{0,1\}^k\to\{0,1\}^{N_k},
  \qquad N_k\le k(\log k)^c,
\]
have the common-proof and pathwise first-hit hypotheses of the imperfect-completeness
Lorenz closure theorem, and have nonadaptive coordinate decoders with query count
Q_k\ge1. Let epsilon_k be the
maximum honest-codeword error probability and let Lambda_{rho,k} be the
honest-path Lorenz mass of the top floor(rho N_k) positions. Put
\[
  s_k:=\varepsilon_k+\Lambda_{\rho,k}.
\]

There is a constant eta = eta(rho,c) > 0 such that, for all sufficiently large
lengths in the family,
\[
  \varepsilon_k\le\frac1{12}
  \quad\text{and}\quad
  s_k2^{Q_k}\le\frac1{12}
\]
imply
\[
  Q_k\ge \eta\frac{\log k}{\log\log k}.
\tag{1}
\]
Thus a near-linear family with Q_k = o(log k / log log k) must pay either a
constant honest-completeness deficit or Lorenz mass larger than the
2^{-Q_k} scale.

## Proof

Under the two hypotheses, the imperfect-completeness pathwise Lorenz closure and
the Cheng--Li--Mao conversion give a Q_k-query LDC of radius
\[
  r_k:=\frac{\rho}{8Q_k}
\]
and error at most 1/4. Treat this LDC as a nonadaptive RLDC with success parameter
sigma = 3/4. It remains to verify the GGS radius window when Q_k is small.

Let g_k := log k / log log k and suppose, for contradiction, that
\[
  Q_k\le\eta g_k.
\tag{2}
\]
For eta < sigma/4 and all sufficiently large k,
\[
  N_k^{-\sigma/(2Q_k)}
  \le k^{-\sigma/(2Q_k)}
  \le (\log k)^{-\sigma/(2\eta)}
  < \frac{\rho}{8Q_k}=r_k.
\tag{3}
\]
Hence Goldberg--Gur--Saraogi's nonadaptive RLDC lower bound applies. Put
\[
  a_k:=\left\lceil\frac{Q_k}{\sigma}\right\rceil,
  \qquad
  D_k:=\frac{38Q_k^4\log^2 2\,\log^2 k}{\sigma^2}.
\]
It gives
\[
  \log N_k\ge
  \left(1+\frac1{a_k}\right)(\log k-\log D_k).
\tag{4}
\]
Under (2), for large k we have
\[
  \log D_k\le 8\log\log k,
  \qquad
  \frac1{a_k}\ge\frac{\sigma}{2Q_k}
  \ge\frac{\sigma}{2\eta}\frac{\log\log k}{\log k}.
\tag{5}
\]
Consequently,
\[
  \log N_k
  \ge \log k+\left(\frac{\sigma}{4\eta}-8\right)\log\log k
\tag{6}
\]
for all sufficiently large k: the omitted term
\((\log D_k)/a_k=O((\log\log k)^2/\log k)=o(\log\log k)\) is absorbed by
replacing \(\sigma/(2\eta)\) with \(\sigma/(4\eta)\). Choosing
\(\eta<\min\{\sigma/4,\sigma/[4(c+9)]\}\) makes (6) contradict
\(\log N_k\le\log k+c\log\log k\). This proves (1).

## Boundary

The pathwise coupling is adaptive, but the variable-query LDC upgrade here uses
the nonadaptive imperfect-completeness theorem of Cheng--Li--Mao. The result is
therefore a variable-query nonadaptive barrier; it does not claim an adaptive
imperfect-completeness RLDC lower bound. The constants 1/12 and 8 are convenient
choices, not optimized thresholds. No claim of P != NP or of a general dPCP
impossibility is made.

## Sources

* J. Cheng, Z. Li, and P. Mao, *When Relaxation Doesn't Help: RLDCs with Small
  Soundness Yield LDCs*, arXiv:2603.03717, Theorem
  `thm:rldc-to-ldc-imperfect-general`:
  <https://arxiv.org/abs/2603.03717>.
* G. Goldberg, T. Gur, and S. Saraogi, *Nearly Tight Lower Bounds for Relaxed
  Locally Decodable Codes via Robust Daisies*, arXiv:2511.21659, Theorem 1:
  <https://arxiv.org/abs/2511.21659>.
