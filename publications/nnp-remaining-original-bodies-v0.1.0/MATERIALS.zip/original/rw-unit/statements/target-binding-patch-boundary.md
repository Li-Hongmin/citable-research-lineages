# Target-binding patch-boundary theorem

## The abstract wrapper

Fix a message \(m\), a target coordinate \(i\), and a base encoding
\(C:\mathcal M\to\Sigma^N\).  Write

\[
  \mathcal M_{i,b}=\{m'\in\mathcal M:m'_i=b\},
  \qquad
  \mathcal L_{i,b}=C(\mathcal M_{i,b}).
\]

Assume the target-separation condition

\[
  \operatorname{dist}(C(m),\mathcal L_{i,1-m_i})\ge \Delta_i.
\tag{TB1}
\]

The candidate global word contains \(R\) base copies and a coordinate-specific
certificate block.  An honest word has base part \(C(m)^R\).  The decoder
samples one uniformly random base copy \(Y\), reads a claimed bit \(b\) from the certificate
block, and has the following two properties:

1. if \(b=m_i\), the decoder never outputs \(1-m_i\);
2. if \(b=1-m_i\), the remaining verifier has wrong-output acceptance at most
   \(\beta_i\), for every certificate, whenever
   \[
     \operatorname{dist}(Y,\mathcal L_{i,1-m_i})\ge \eta_i.
   \tag{TB2}
   \]

Allow a total-variation error \(\zeta_i\) between the sampled certificate
distribution and the ideal verifier distribution.  For a candidate word \(W\),
let

\[
  \gamma(W)=\frac{1}{R N}
  \operatorname{Ham}\bigl(W|_{\mathrm{base}},C(m)^R\bigr).
\]

Then for every \(\tau>0\) with

\[
  \Delta_i-\tau\ge \eta_i,
\tag{TB3}
\]

the wrong-output probability satisfies

\[
  \Pr[\operatorname{Dec}(W,i)=1-m_i]
  \le
  \beta_i+\zeta_i+\frac{\gamma(W)}{\tau}.
\tag{TB4}
\]

Consequently, if a candidate forces the wrong output with probability at least
\(\delta>\beta_i+\zeta_i\), then

\[
  \gamma(W)\ge
  \tau\bigl(\delta-\beta_i-\zeta_i\bigr).
\tag{TB5}
\]

Thus every constant-gap forcing patch must corrupt a constant fraction of the
shared target-binding base channel whenever \(\Delta_i-\eta_i\) is constant.
Changing only the coordinate-specific certificate block cannot be a
constant-probability forcing profile.

## Proof

Let \(Y\) be the sampled base copy.  Markov's inequality gives

\[
  \Pr\bigl[\operatorname{dist}(Y,C(m))>\tau\bigr]
  \le \frac{\gamma(W)}{\tau}.
\]

On the complementary event, the triangle inequality and (TB1) imply

\[
  \operatorname{dist}(Y,\mathcal L_{i,1-m_i})
  \ge \Delta_i-\tau
  \ge \eta_i.
\]

If the certificate declares \(m_i\), property 1 excludes a wrong output.  If
it declares \(1-m_i\), property 2 bounds the ideal-verifier acceptance by
\(\beta_i\), and the distributional perturbation contributes at most
\(\zeta_i\).  On the exceptional base-copy event we use the trivial bound one.
This proves (TB4); rearrangement gives (TB5).

## Interpretation for simultaneous coordinate robustness

The theorem isolates a general mechanism behind the GM--W--Z instance:
target-binding is not merely a semantic label on a coordinate-specific proof.
If it is enforced by testing the same separated base object for every
coordinate, then private certificate patches cannot realize the forcing
profiles needed by the profile-hitting lower bound.  They must cross the
shared base channel and pay its full relative-distance scale.

This is not a general impossibility theorem for dPCPs.  It applies only when
the construction has all three ingredients: a shared base object, positive
separation between opposite target classes, and a verifier with a
near-object soundness region.  A construction can evade it by abandoning
shared target binding, using a different global consistency mechanism, or
making the target separation/soundness window vanish.  Those escapes are
precisely the parameters that a general ACRR lower bound must track.

## GM--W--Z corollary

In the GM--W--Z RLDC wrapper, take

\[
  C=C_0,\quad
  \Delta_i=1-\mu,\quad
  \eta_i=1-\xi^{C_{\rm pcpp}+1},\quad
  \beta_i=2\xi,\quad
  \zeta_i=(\log k)^{-10}.
\]

The first block has \(R=2\rho K\) repetitions and total length \(2Kk\).
Choosing \(\tau=\xi^{C_{\rm pcpp}+1}-\mu\) gives exactly the
[repeated-base patch-boundary corollary](repeated-base-patch-boundary-for-gmwz-rldc.md).

## Source boundary

The abstract theorem is an elementary Markov-plus-triangle consequence.  Its
GM--W--Z instantiation uses the base-code and PCPP parameters in
[Gur--Minzer--Weissenberg--Zheng, arXiv:2512.12960](https://arxiv.org/abs/2512.12960),
Theorem 1.9 and Theorem 11.1.  It does not claim that the paper states the
abstract theorem.
