# Message-inline 的退化半径--proof 长度禁区

## 地位

这是把 message-inline RLDC 编译与项目的参数化 DGL 小半径窗口组合起来的
**条件性参数定理**。它不把 DGL 的参数化重写冒称为 DGL 原文定理；一旦
[参数化 DGL 小半径定理](parameterized-dgl-small-radius-sample-theorem.md) 的完整
admissible-growth 与 relaxed-LDC 接口核验完成，本命题给出一个直接可用的
proof-length/radius tradeoff。

## 参数化 DGL 输入

固定一个已经完成阈值放大的 RLDC locality \(Q\)。假设存在常数
\(C_Q,B_Q>0\)，并令

\[
  a_Q=\frac1Q-\frac1{2Q^2},
  \qquad
  \theta_Q=\frac{c_Q}{Q^2\log^2(Q+2)}>0,
\]

使以下 DGL-window implication 成立：任意满足 C25/C55 所需 one-sided robust
sample-based 接口、且 decoding radius 为 \(\delta/2\) 的 binary message family of
dimension \(k\)、length \(N\) 的 \(Q\)-query relaxed local decoder，只要

\[
  \delta\ge C_Q N^{-a_Q},
\]

并满足 DGL 的其余 admissible-growth 条件，就能运行 DGL 的
relaxed-LDC/sample reduction，并得到

\[
  N\ge
  \left(\frac{k}{B_Q\log(k+2)}\right)^{1/(1-\theta_Q)}.
\tag{DGL-length}
\]

对固定 \(Q\)，这些增长条件包括 \(Q=o(\sqrt{\log N})\) 等；本命题只在这些条件
实际成立的长度上使用该 implication。这里不是把任意 relaxed decoder 自动视为
DGL 算法，而是显式假设 C25/C55 的完整接口已成立。

## 定理（禁区二分）

设

\[
  \Pi_k:\{0,1\}^k\to\{0,1\}^{P_k}
\]

是一族 binary global proofs。对每个消息坐标 \(i\) 和声明位 \(b\)，有同一地址空间
中的至多 \(q\) 次查询 verifier。假设存在常数

\[
  \alpha>\beta,\qquad 0<\rho_{P,k}<1,
\]

使正确分支在 \(\Pi_k(m)\) 上接受率至少 \(\alpha\)，而在距离
\(\rho_{P,k} P_k\) 内的 target-relative wrong branch 接受率至多 \(\beta\)。令

\[
  N_k=k+P_k,
  \qquad
  Q=O\!\left(q(\alpha-\beta)^{-2}\right)
\]

为 message-inline 阈值放大后的 locality。若上述 DGL-window implication 适用于
\((Q,N_k)\)，则对每个充分大的 \(k\)，至少有一项成立：

\[
  \frac{\rho_{P,k} P_k}{2N_k}<C_QN_k^{-a_Q},
\tag{G1}
\]

或

\[
  N_k\ge
  \left(\frac{k}{B_Q\log(k+2)}\right)^{1/(1-\theta_Q)}.
\tag{G2}
\]

换言之，若 proof 进入 DGL 窗口，则总长度必须跳到

\[
  N_k\ge k^{1+\theta_Q/(1-\theta_Q)}/\operatorname{polylog}(k).
\]

在 \(P_k\le k\) 的次线性至线性长度区间，(G1) 进一步给出

\[
  P_k=O_{Q,C_Q}\!\left(\rho_{P,k}^{-1}k^{1-a_Q}\right).
\tag{G3}
\]

更一般地，任何满足

\[
  N_k<
  \left(\frac{k}{B_Q\log(k+2)}\right)^{1/(1-\theta_Q)}
\]

的候选都必须停留在小半径逃逸 (G1) 中，而不能同时声称自己已经进入 DGL 的固定
参数窗口。这里保留了 polylog 因子；不能把它弱化成没有该因子的
\(o(k^{1+\theta_Q/(1-\theta_Q)})\) 表述。

## 证明

把消息位直接内嵌，定义

\[
  C_k(m)=m\,\|\,\Pi_k(m)\in\{0,1\}^{N_k}.
\]

message-inline RLDC 编译给出：对任意

\[
  \delta<\frac{\rho_{P,k} P_k}{N_k},
\]

存在 locality \(Q\) 的 relaxed local decoder；阈值放大只改变 \(Q\)，不改变这个
半径上界。该编译同时强制 message-inline code 的码距严格大于
\(\rho_{P,k} P_k/N_k\)，所以取下面的输入 radius 时满足 DGL relaxed-LDC 定义所需的
“小于码距一半”条件。取其输入 decoding radius 为

\[
  r_k=\frac{\rho_{P,k} P_k}{4N_k},
\]

并令 DGL relaxed-LDC reduction 的输出半径为

\[
  \delta_k=2r_k=\frac{\rho_{P,k} P_k}{2N_k}.
\]

若 (G1) 不成立，则 \(\delta_k\ge C_QN_k^{-a_Q}\)，从而可以应用
(DGL-length)，得到 (G2)。若 (G1) 成立，便得到小半径逃逸。

若 \(P_k\le k\)，则 \(N_k\le2k\)。由 (G1) 的反面
\(\delta_k\ge C_QN_k^{-a_Q}\) 可得

\[
  P_k\ge \frac{2C_Q}{\rho_{P,k}}N_k^{1-a_Q}
  \ge \frac{2C_Q}{\rho_{P,k}}k^{1-a_Q},
\]

同时 (G2) 给出
\(N_k=k+P_k\ge k^{1+\theta_Q/(1-\theta_Q)}/\operatorname{polylog}(k)\)，
这与 \(N_k\le2k\) 矛盾。故在 \(P_k\le k\) 的区间只能有 (G1)，即得 (G3)。

## 有限字母表扩展

同一禁区二分可直接保留 growing finite alphabet 的代价。令

\[
  \Pi_k:\{0,1\}^k\to\Sigma_k^{P_k},\qquad
  \ell_k=\lceil\log_2|\Sigma_k|\rceil,
  \qquad N_k=k+\ell_kP_k,
\]

并用一个统一可生成、固定长度 \(\ell_k\) 的注入编码来表示每个 proof symbol。不同符号只能保证编码块至少有
一个不同 bit；因此从二进制距离反推符号距离时，只能按“每个不同符号贡献至少一个
bit”计数，得到有效的二进制 message-inline 半径上界

\[
  \Delta_k=\frac{\rho_{P,k}P_k}{N_k},
  \qquad
  \delta_k=\frac{\Delta_k}{2}
  =\frac{\rho_{P,k}P_k}{2(k+\ell_kP_k)}.
\tag{G4}
\]

阈值放大后的 locality 变为

\[
  Q_k=O\!\left(q\ell_k(\alpha-\beta)^{-2}\right).
\tag{G5}
\]

因此，在同一个参数化 DGL-window 对 \((Q_k,N_k,\delta_k)\) 适用时，(G1)--(G3)
逐字成立：把总长度 \(N\) 换成 \(N_k\)、locality \(Q\) 换成 \(Q_k\)，但半径
分子仍是符号 proof 的 \(\rho_{P,k}P_k\)，不能替换成 \(\rho_{P,k}\ell_kP_k\)。特别是，字母表增长
不能被记成“只增加 \(\ell_k\) 个查询”而不同时把 (G4) 的半径稀释计入窗口；若
\(\ell_k\) 进入非统一区，当前结论只保留为该显式参数条件下的 conditional theorem。

## 解释与边界

1. 该定理只讨论 \(\rho_{P,k}\) 可能随 \(k\) 退化的情形。若
   \(\rho_{P,k}\ge\rho_*>0\) 最终成立，则 [message-inline Singleton barrier](message-inline-singleton-barrier.md)
   已由 proof-map 距离和一般 Singleton 界强制 \(P_k=\Omega(k)\)，从而 (G1) 对充分大
   \(k\) 自动失败；固定正半径的长度下界应直接使用该更强模块。
2. 当 \(\rho_{P,k}\to0\) 时，(G1) 才是有内容的逃逸：proof 可以保持较短，但必须把
   有效 message-inline 半径降到 DGL 窗口以下。不能把这种候选描述成固定正半径的
   近线性 ACRR。
3. 定理只适用于 family-level、同一 global proof、target-relative near-oracle
   量词。单一 RW 目标、逐坐标独立 proof、codeword-only soundness 或无界
   coordinate-after strategy 不在模型内。
4. \(C_Q,B_Q,a_Q,\theta_Q\) 的具体常数来自 DGL 参数化封装；在其完整增长条件尚未
   逐项写完前，本文件的地位是 derived conditional theorem，而不是已完成的一般
   ACRR impossibility theorem。

## 关系

* [Message-inline RLDC compiler](message-inline-rldc-compiler.md) 提供第一步编译。
* [Message-inline Singleton barrier](message-inline-singleton-barrier.md) 关闭固定
  proof-radius 下的“短 proof”误读。
* [参数化 DGL 小半径定理](parameterized-dgl-small-radius-sample-theorem.md) 提供
  DGL-window 与 DGL-length 的外部接口候选。
* [ACRR 半径--共享 key--长度三难](acrr-radius-key-length-trilemma.md) 是带 descriptor
  的更一般版本；本定理取 \(s=0\)，并把 proof suffix 半径显式换算成 message-inline
  code 半径。

## 证据边界

DGL 原文直接支持其 structural/sample theorem 的固定-query 背景与
\(N^{1-1/O(Q^2\log^2 Q)}\) 级 sample exponent；本文件使用的可变半径窗口及
(DGL-length) 仍须以项目的参数化重证完成后才能晋级为无条件 derived theorem。

来源：[Dall'Agnol--Gur--Lachish, TR20-154](https://eccc.weizmann.ac.il/report/2020/154/)。
