# Singleton distributional dPCP gives simultaneous coordinate soundness by conditioning

## Theorem

Fix an instance \(x\) with a binary target word

\[
  f_x\in\{0,1\}^k.
\]

Consider a dPCP with one global proof address space. For each output coordinate
\(i\in[k]\), let \(P_i\) be its distribution on local edges \((a,b)\), let
\(\Phi(T_A[a],T_B[b])\) be the edge predicate, and let \(D_i(a,T_A[a])\in\{0,1\}\) be the
decoded symbol from the left assignment. Assume:

1. **Perfect completeness.** There is one honest pair of assignments
   \((T_A^*,T_B^*)\) such that every sampled edge satisfies \(\Phi\), and
   \(D_i(a,T_A^*[a])=f_x[i]\) for every \(i\) and every left view.
2. **Singleton distributional list soundness.** For every candidate left assignment
   \(T_A\), there is a list \(Y(T_A)\subseteq\{f_x\}\) such that, for every candidate
   right assignment \(T_B\),
   \[
   \Pr_{i\sim U([k]),\,(a,b)\sim P_i}
   \left[\Phi(T_A[a],T_B[b])=1\ \wedge\
   D_i(a,T_A[a])\notin\{y[i]:y\in Y(T_A)\}\right]
   \le \varepsilon .
   \tag{1}
   \]

For a declaration \(c\in\{0,1\}\), define the coordinate verifier
\(V_{x,i,c}\) by sampling \((a,b)\sim P_i\) and accepting exactly when

\[
  \Phi(T_A[a],T_B[b])=1\quad\text{and}\quad D_i(a,T_A[a])=c.
\]

Then all \(V_{x,i,c}\) use the same proof assignments and the same address space, and:

* \(V_{x,i,f_x[i]}\) accepts the honest proof with probability one;
* for every candidate proof \((T_A,T_B)\) and every wrong declaration
  \(c\ne f_x[i]\),
  \[
    \Pr[V_{x,i,c}(T_A,T_B)=1]\le k\varepsilon .
    \tag{2}
  \]

Consequently, singleton distributional soundness with
\(\varepsilon\le\beta/k\) is sufficient for simultaneous coordinate robustness with
wrong-claim error at most \(\beta\). More generally, if the coordinate distribution
has weights \(w_i>0\) instead of the uniform distribution, the same proof gives

\[
  \Pr[V_{x,i,c}=1]\le \varepsilon/w_i.
  \tag{3}
\]

The statement is a conditioning lemma, not a new near-linear dPCP construction.

## Proof

Fix a candidate pair \((T_A,T_B)\). Write

\[
  p_i(c)=\Pr_{(a,b)\sim P_i}
  [\Phi(T_A[a],T_B[b])=1\ \wedge\ D_i(a,T_A[a])=c].
\]

If \(c\ne f_x[i]\), then \(c\notin\{f_x[i]\}\). There are two cases for the
singleton list in (1):

* If \(Y(T_A)=\{f_x\}\), its coordinate projection is \(\{f_x[i]\}\), so every event
  counted by \(p_i(c)\) is an event in (1).
* If \(Y(T_A)=\varnothing\), every satisfied edge whose decoder outputs \(c\) is
  again an event in (1).

Thus, in either case, the average of the wrong-claim probabilities obeys

\[
  \frac1k\sum_{i=1}^k p_i(c_i)\le\varepsilon
\]

for any choice of wrong bits \(c_i\ne f_x[i]\). Taking a choice with a single
coordinate \(i\) equal to the queried wrong bit and all other coordinates assigned an
arbitrary wrong bit gives \(p_i(c)\le k\varepsilon\). Under weights \(w_i\), the same
argument gives \(w_i p_i(c)\le\varepsilon\), proving (3). Perfect completeness is
exactly assumption 1, because the verifier uses the same local edge and decoder as the
dPCP.

## Why the singleton hypothesis matters

If the soundness list can contain two or more words, a wrong bit relative to the chosen
target may still agree with a different list word. The event \(D_i=c\) is then not
necessarily included in the list-soundness bad event. The proof therefore uses a genuine
singleton target, not merely a small list or an agnostic decoding distribution.

The theorem also keeps the quantifiers in the required order:

\[
  \forall T_A\ \exists Y(T_A)\subseteq\{f_x\}\ \forall T_B.
\]

The same candidate pair \((T_A,T_B)\) is used for every coordinate; no coordinate-specific
proof, preimage, or Merlin strategy is introduced. This is precisely the global-word
consistency that ordinary coordinate-by-coordinate recompilation fails to provide.

## Parameter consequence for current near-linear dPCP theorems

The 2-query dPCP theorem of Gur--Minzer--Weissenberg--Zheng gives, for each fixed
\(\varepsilon>0\), near-linear length \(N\log^{C(\varepsilon)}N\), a constant alphabet
depending on \(\varepsilon\), and distributional list soundness. Applying the theorem above
to a singleton target of length \(k\) would require

\[
  \varepsilon=O(1/k).
\]

The published parameter statement does not provide a uniform bound on
\(C(\varepsilon)\) or on the alphabet size as \(\varepsilon\to0\). Therefore this bridge
does not yet produce a RW/JK address-scale, near-linear simultaneous ACRR. It isolates the
remaining construction problem sharply: obtain singleton/coordinate-normalized soundness at
\(\varepsilon=\Theta(1/k)\) while retaining a uniform near-linear proof and a uniformly
generated common address space.

This conclusion is compatible with the sharp weighted average barrier: when \(w_i=1/k\),
the factor \(k\) in (2) is information-theoretically unavoidable from (1) alone. Any
improvement must add semantic target binding, a non-uniform coordinate distribution with a
controlled \(w_{\min}\), or a stronger globally coupled predicate.

## Scope and source boundary

This is a new derived conditioning lemma for the project. It does not claim that the
Gur--Minzer--Weissenberg--Zheng construction already has a singleton target, a uniform
\(\varepsilon=1/k\) parameterization, or the RW/JK hidden-history address scale. It also
does not prove a lower bound against future coordinate-normalized dPCP constructions.

Primary source for the dPCP/list-soundness definitions and the fixed-\(\varepsilon\) theorem:
[Gur--Minzer--Weissenberg--Zheng, *3-Query RLDCs are Strictly Stronger than 3-Query LDCs*](https://arxiv.org/html/2512.12960), Definitions 3.1--3.5 and Theorem 3.12.

Related project modules:

* [Weighted distributional-to-coordinate barrier](distributional-to-coordinate-weight-barrier.md)
* [Singleton robust dPCP plus smooth outer decoder](singleton-robust-dpcp-smooth-decoder-bridge.md)
* [Agnostic average-to-coordinate separation](agnostic-average-to-coordinate-separation.md)
