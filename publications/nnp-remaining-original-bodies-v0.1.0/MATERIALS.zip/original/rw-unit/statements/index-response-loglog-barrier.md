# 近线性 shared-key ACRR 的 post-index 响应阈值

## 定理（条件于统一 DGL 参数窗口）

令 \(M=\{0,1\}^k\)，令 \(C:M\to\Sigma^N\) 为共同 proof/codeword map，其中
\(\Sigma\) 是固定有限字母表且 \(|\Sigma|\ge2\)。每个消息有 \(s\)-bit key
\(\kappa(m)\in\{0,1\}^s\)。坐标 \(i\) 揭示后，verifier 允许收到一个
\(r=r(k)\)-bit response \(\tau\in\{0,1\}^r\)，并满足：

* 同 key、同一 physical proof address space、固定 query locality \(q_0\)；
* 正半径 \(\rho>0\) 与固定 gap \(\alpha-\beta>0\)；
* 正确声明对每个目标至少有一个 \(\tau\) 完备；
* 错误声明对所有 \(\tau\) 在目标相对 \(\rho\)-邻域内 sound；
* DGL 的 key-indexed relaxed-LDC/sample bound 对随 \(r\) 变化的 locality
  在所用参数窗口内具有统一常数：
  \[
    h-s\le
    A\,|\Sigma|^{Q_r}\log_2|\Sigma|\,
    N^{1-\theta_r}\log_2(k+2),
    \qquad
    Q_r=A_0\,2^r,\quad
    \theta_r\ge
    \frac{a_0}{Q_r^2\log^2(Q_r+2)}.
  \tag{IR1}
  \]
  其中 \(A,A_0,a_0>0\) 与 \(k,r\) 无关。

固定 \(\varepsilon>0,d>0\)，若

\[
  s\le(1-\varepsilon)k,
  \qquad
  N\le k(\log_2(k+2))^d,
\]

则对每个固定 \(c<1/3\)，不存在无限多 \(k\) 满足

\[
  r(k)\le c\log_2\log_2(k+2).
\tag{IR2}
\]

等价地，在上述统一窗口内，任何近线性、高熵 shared-key ACRR 都必须满足

\[
  r(k)\ge \left(\frac13-o(1)\right)\log_2\log_2 k.
\tag{IR3}
\]

该 \(1/3\) 是对 (IR1) 中 \(|\Sigma|^{Q_r}\) 因子的保守阈值；若外部 sample theorem
能把该因子改进为 \(e^{o(Q_r)}\)，阈值可相应提高。

## 证明

由 key-indexed ACRR/RLDC 二分，坐标揭示后的 \(r\)-bit response 可枚举，得到

\[
  Q_r\le A_0 2^r
\]

的 relaxed decoder，并满足 (IR1)。同一 key bucket 内的距离/注入性还给出
\(N=\Omega(k)\)，故 \(\log N=\Theta(\ell)\)。由于 \(M=\{0,1\}^k\) 且
\(s\le(1-\varepsilon)k\)，不等式左端至少为 \(\varepsilon k\)。

假设 (IR2) 成立。记 \(\ell=\log_2(k+2)\)。则

\[
  Q_r\le A_0\ell^c,
  \qquad
  \log(Q_r+2)=O(\log\ell),
\]

从而

\[
  \theta_r\log N
  \ge
  \Omega\!\left(
    \frac{\ell^{\,1-2c}}{(\log\ell)^2}
  \right).
\tag{IR4}
\]

另一方面，取 (IR1) 右端的对数，并使用
\(N\le k\ell^d\)，得到

\[
\begin{aligned}
\log_2\!\bigl(
A|\Sigma|^{Q_r}\log_2|\Sigma|\,
N^{1-\theta_r}\log_2(k+2)
\bigr)
&\le
\ell+d\log_2\ell
+O(\ell^c)\\
&\quad-\Omega\!\left(
\frac{\ell^{\,1-2c}}{(\log\ell)^2}
\right).
\end{aligned}
\tag{IR5}
\]

当 \(c<1/3\) 时，\(1-2c>c\)，负项最终同时支配
\(O(\ell^c)\) 和 \(O(\log\ell)\)。因此 (IR5) 的右侧严格小于
\(\log_2(\varepsilon k)=\ell+O(1)\)，与 (IR1) 左端至少为 \(\varepsilon k\) 矛盾。
故 (IR2) 不可能无限发生，得到 (IR3)。

## 解释与边界

这不是把 post-index interaction 本身判为不可能，而是给出其最小信息/局部性代价：

* \(r=O(1)\) 的响应仍直接落入固定-locality RLDC barrier；
* \(r\le(1/3-o(1))\log\log k\) 仍不足以在统一 DGL 窗口中支持
  \(N=k\operatorname{polylog}k\) 与 \(s\le(1-\varepsilon)k\)；
* 响应达到更大规模后，(IR1) 的 locality/alphabet 因子可能使该外部窗口失效，
  但这只说明必须支付可量化的 query 代价，不是一个正向构造；
* 若 verifier 看到完整目标、每个目标拥有独立 proof address space、soundness 不是
  对所有 response 成立、半径/gap 退化，或 DGL 参数常数不随 \(Q_r\) 统一，则本定理
  不适用。

因此它把 C196 的“有限 response 是剩余逃逸”进一步收窄为一个明确的
response-length threshold；真正未覆盖的只剩无界 strategy、独立 proof space 或
退出正半径/family-level 语义的路线。

## 证据边界

(IR1) 的 DGL/sample bound 是外部输入；本项目新增的是把
\(Q_r=O(2^r)\) 与近线性长度的指数项显式比较，得到 \(\frac13\log\log k\) 阈值。
不声称由此解决 \(P\ne NP\)，也不把该条件性参数界宣称为所有 interactive PCP 的
一般 lower bound。

相关模块：

* [Key-indexed ACRR / RLDC dichotomy](key-indexed-acrr-rldc-dichotomy.md)
* [Sim-CR strategy-compression trilemma](strategy-compression-trilemma-for-simcr.md)
* [Dall'Agnol--Gur--Lachish](https://eccc.weizmann.ac.il/report/2020/154/)
