# Agnostic robust dPCP 仍不推出固定坐标鲁棒性

## 结论地位

这是对当前 distributional-soundness 正向路线的一个 source-independent black-box
separation。反例满足：singleton 输出语言、完美完备性、list size `1`、GM--W--Z
定义中的 robust dPCP soundness，且 complete decoding distribution 完全 agnostic；
但某个固定坐标的错误声明仍以概率 `1` 被接受。因而“加入 agnostic decoding
distribution”仍不足以把平均/分布式 soundness 提升为 simultaneous coordinate robustness。

## 命题

对任意 `n>=2`，令输出语言

\[
  L_n=\{0^n\}.
\]

构造一个二查询（事实上只需一条边）的 dPCP：左侧有一个自由符号顶点 `a`，右侧有
一个 dummy 顶点 `b`，唯一边 `(a,b)` 的约束恒真。对每个输出坐标 `t in [n]`，
解码分布 `P_t` 都集中在这条边，解码器为

\[
  D_1(a)=a,\qquad D_t(a)=0\quad(2\le t\le n).
\]

则该系统具有：

1. 完美完备性；
2. list size `1` 的 robust soundness error `1/n`；
3. 完全 agnostic 的 complete decoding distribution；
4. 但对真实词 `0^n` 的第一个坐标，错误声明 `1` 在候选 assignment `a=1` 上接受
   概率 `1`。

因此不存在一个只使用上述四类参数的黑箱变换，能保证每个指定坐标都有固定常数的
错误拒绝率。

## 证明

取 honest assignment `a=0`、`b=0`。唯一边恒真，且每个 `D_t` 都输出 `0`，所以
完美完备性成立。

对任意候选 assignment，取合法列表为 `{0^n}`。当 `a=0` 时没有 bad output；当
`a=1` 时只有坐标 `t=1` 的解码值偏离列表。因此在 GM--W--Z Appendix A 的 robust
dPCP 定义中，

\[
  \mathbb E_{t\leftarrow[n],\,(I,f)\sim P_t}
  [\operatorname{agr}(\pi_I,\operatorname{BAD}(f))]
  \le \frac1n.
\]

这里 `P_t` 对所有 `t` 完全相同，唯一边使 complete decoding distribution `Q` 满足
Definition 3.5 的 agnostic 条件：固定右顶点 `b` 后，`Q(t,\cdot,b)` 与
`Q(\circ,\cdot,b)` 相同。于是该反例并非只利用非均匀的坐标采样。

另一方面，在候选 assignment `a=1` 上，`D_1(a)=1` 且约束仍接受，所以固定坐标
`t=1` 的错误声明 verifier 以概率 `1` 接受。取 `n` 任意大，平均 robust error
趋于 `0`，而固定坐标 soundness 仍为 `1`。命题得证。\(\square\)

## 精确含义

该反例关闭的是以下黑箱推理：

```text
singleton target + robust/agnostic average dPCP
    => fixed-coordinate robust dPCP.
```

它不否定加入下列任一额外机制后的正向定理：

* coordinate-wise robust soundness 或 target-normalized local predicate；
* 一个把错误坐标复制到常数质量、同时复制语义检查的 outer code；
* global proof consistency，使单坐标错误不能只影响一个平均采样位置；
* singleton-output bridge 所需的“每个局部有效解释在该坐标都投影到同一目标位”。

特别地，aggressive coordinate replication 不能只复制标签和 equality edge；同一
`a=1` assignment 可在所有副本上一致取错，复制后的平均错误质量仍是
`R/(n+R-1)`。因此真正需要的是语义放大或 coordinate-robust outer check，而不是
重加权采样。

## 与项目主线的关系

该模块比一般“平均到坐标”的 toy separation 更锋利，因为它同时满足 GM--W--Z 所需的
agnostic decoding distribution 与 robust dPCP soundness 形式。它把正向目标精确收窄为：

\[
  \text{agnostic distribution}
  +\text{coordinate-normalized target binding}
  +\text{same global proof}
  \Longrightarrow\text{ACRR}.
\]

它仍不是一般 dPCP/LDC 的长度下界；要得到 FOCS/STOC 级别的负向定理，下一步必须证明
任意近线性构造若没有 coordinate-normalized target binding，就会暴露可联合 patch 的
profile family，或落入 relaxed-LDC barrier。

## 来源

- [Gur--Minzer--Weissenberg--Zheng, TR25-217, Definitions 3.1--3.5 and Appendix A](https://eccc.weizmann.ac.il/report/2025/217/download)
- [average-to-coordinate separation](../../mcsp-hardness-magnification/notes/174-average-to-coordinate-separation-and-rldc-interface-2026-08-16.md)
- [singleton robust dPCP bridge](singleton-robust-dpcp-smooth-decoder-bridge.md)
