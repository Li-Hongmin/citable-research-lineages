# All-affine shared-proof 的决策树维数下界

## 定理地位

这是一个自足的、all-affine 强化模型下的长度下界。它不直接覆盖 RW 只要求的
坐标半空间族，也不声称是新的最优 LDC 下界；它说明若一个共同 proof 要同时支持
**所有**线性函数 `a·x` 的 proof-only 声明，即使只在精确 proof 上要求常数完备/错误
间隔，也必须付出指数级长度（固定查询时）。这为 GRR 4.26 的 Hadamard 长度提供
机制性解释，并精确标出从 all-affine 到 RW-coordinate 的强度落差。

## 模型

令任意编码

\[
  E:\{0,1\}^n\to\{0,1\}^N.
\]

对每个 `a in {0,1}^n` 和声明位 `b in {0,1}`，给定一个随机、自适应、至多
`q` 次查询 `E(x)` 的 verifier `V_{a,b}`。假设存在常数
`alpha>beta`，使对所有 `x`：

* 若 `b=<a,x>`，则 `Pr[V_{a,b}^{E(x)}=1]>=alpha`；
* 若 `b!=<a,x>`，则 `Pr[V_{a,b}^{E(x)}=1]<=beta`。

这里没有假设 `E` 线性、系统、可计算，也没有加入 corruption radius；只使用同一个
proof `E(x)` 支持所有 affine queries。

## 结论

令 `Delta=alpha-beta`，取

\[
  R=\left\lceil\frac{2\ln 3}{\Delta^2}\right\rceil,
  \qquad q_*=qR.
\]

则当 `n>2^{q_*}+O(1)` 时，必有

\[
  N\;\ge\;
  2^{\frac{n-2^{q_*}-O(1)}{2^{q_*}-1}}.
\]

特别地，对固定 `q` 和固定 gap `Delta`，

\[
  N\ge 2^{\Omega_{q,\Delta}(n)}.
\]

## 证明

先把 verifier 变成一个有界错误的 inner-product decoder。对给定 `a`，重复运行
`V_{a,0}` 共 `R` 次；若接受频率超过 `(alpha+beta)/2`，输出 `0`，否则输出 `1`。
Hoeffding 界保证错误率至多 `1/3`，因为正确分支的均值至少 `alpha`，错误分支的
均值至多 `beta`。得到一个至多 `q_*` 次自适应查询、对每个 `a` 都以概率至少
`2/3` 输出 `<a,x>` 的 decoder。

令 `chi_a(x)=(-1)^{<a,x>}`。所有确定性的深度至多 `q_*` 二叉查询树，在输入
`E(x)` 上诱导函数 `f:E(x)\mapsto\{\pm1\}`。这样的树数至多

\[
  T_q\le N^{2^{q_*}-1}\,2^{2^{q_*}},
\]

因为至多有 `2^{q_*}-1` 个内部节点，每个节点选择一个地址，每个叶子选择一个
输出符号。令 `U` 为这些树函数在 `x`-域上的线性张成，故
`dim(U)<=T_q`。

对每个 `a`，将随机 decoder 的 `+1/-1` 输出取期望，得到 `g_a in U`，且
`||g_a||_2<=1`、

\[
  \langle g_a,\chi_a\rangle
  =1-2\Pr[g_a\ne\chi_a]
  \ge 1/3.
\]

`{chi_a:a in {0,1}^n}` 是均匀 `x`-域上的正交归一基。对 `U` 的正交投影 `P_U`，

\[
  \sum_a\|P_U\chi_a\|_2^2=\dim(U).
\]

而 Cauchy--Schwarz 给出每个 `||P_U chi_a||_2>=1/3`，故
`dim(U)>=2^n/9`。于是 `T_q>=2^n/9`，取二进制对数即得所示长度下界。
\(\square\)

## 与 ACRR 的关系

1. **GRR 4.26：** Hadamard proof `E(x)=H_x`、常数查询，正好落在该机制的指数
   长度一侧；本定理不替代 GRR，而解释其共享 all-affine proof 的长度代价。
2. **GRR 4.27：** 其 polynomial-length proof 通过关系相关的
   `P_0,\ldots,P_\ell` 辅助 bundle，并非一个对所有 `(A,b)` 共用的 proof map；因此
   不与本下界冲突。
3. **RW-coordinate ACRR：** 只要求 `a=e_i` 的 `n` 个坐标字符时，上述正交投影
   计数只给 `dim(U)>=Omega(n)`，不能推出指数长度。这正是 all-affine barrier
   不能直接冒充 RW 一般不可能性的原因。
4. **近线性目标：** 若未来构造声称同时支持一个指数多的 affine/query family，且
   verifier gap 与 locality 固定，本定理立即关闭该候选；若只支持 RW 的坐标族，仍需
   C60/C75 型 family-level RLDC 归约或新的 target-binding 下界。

## 证据边界

该证明是决策树函数空间的 elementary dimension argument，与经典 LDC/PIR 指数下界
属于同一机制族；本文只把它按 ACRR 的 all-affine proof-only 量词重新参数化，不主张
优于现有最优 LDC 下界。它不处理 corruption radius、非精确完备性或仅坐标族，也不
证明一般 near-linear dPCP 不可能。

