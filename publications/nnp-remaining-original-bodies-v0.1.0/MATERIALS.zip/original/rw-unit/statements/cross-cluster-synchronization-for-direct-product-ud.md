# Cross-cluster synchronization for direct-product amplification

This statement isolates a quantitative condition under which the disjoint-cluster
decomposition in a direct-product dPCP can be upgraded from a list of base words to one
global word. It is a derived theorem with explicit sampler hypotheses; it does not claim
that the current GMWZ construction already satisfies those hypotheses.

## Setup

Let \(\mathcal Q_{\rm base}\) be a base decoding distribution on pairs \((t,u)\), and let
\(D_t(u,\cdot)\) be deterministic base decoders. A direct-product assignment consists of
left labels \(T_1[a]\), right labels \(T_2[b]\), and a sampling distribution
\(\mathcal P\) over tuples

\[
(a,a',b,u,t),
\]

where \(a,a'\) are left vertices, \(b\) is their common right view, \(u\in b\), and \(t\)
is sampled from the base decoder distribution conditional on \(u\). Let
\(\mathsf{Pass}\) be the event that both projections agree with the same right label:

\[
\mathsf{Pass}:=
\{T_1[a]|_b=T_2[b]\ \land\ T_1[a']|_b=T_2[b]\}.
\]

Let \(U_i,U_j\) be disjoint clusters of left vertices. Write

\[
\gamma_{ij}:=\Pr_{\mathcal P}[a\in U_i,\ a'\in U_j].
\]

Condition on this cross-cluster event and denote the resulting distribution on \((t,u)\) by
\(\nu_{ij}\). For functions \(f_i,f_j\colon X(1)\to\Sigma\), define

\[
Y_i(t,u):=D_t(u,f_i(u)),
\qquad
\rho_{ij}:=\Pr_{(t,u)\sim\mathcal Q_{\rm base}}[Y_i(t,u)\ne Y_j(t,u)].
\]

Assume the following three explicit bounds:

1. **Marginal transfer.**
   \[
   \operatorname{TV}(\nu_{ij},\mathcal Q_{\rm base})\le \xi_{ij}.
   \]
2. **Cross-cluster label errors.**
   \[
   \Pr_{\mathcal P(\cdot\mid a\in U_i,a'\in U_j)}
   [T_1[a](u)\ne f_i(u)]\le \zeta_i,
   \]
   and the analogous bound for \(T_1[a']\) and \(f_j\) is at most \(\zeta_j\).
3. **Base unique decoding.** There are words \(w_i,w_j\) such that
   \[
   \Pr_{\mathcal Q_{\rm base}}[Y_i(t,u)\ne (w_i)_t]\le\eta,
   \qquad
   \Pr_{\mathcal Q_{\rm base}}[Y_j(t,u)\ne (w_j)_t]\le\eta.
   \]

Let \(\varepsilon_{\rm dp}:=\Pr_{\mathcal P}[\neg\mathsf{Pass}]\).

## Theorem

Under the setup above,

\[
\rho_{ij}
\le
\xi_{ij}+\zeta_i+\zeta_j+\frac{\varepsilon_{\rm dp}}{\gamma_{ij}}
\tag{CC1}
\]

whenever \(\gamma_{ij}>0\). Consequently,

\[
\operatorname{dist}(w_i,w_j)
\le
\rho_{ij}+2\eta
\le
\xi_{ij}+\zeta_i+\zeta_j+2\eta+
\frac{\varepsilon_{\rm dp}}{\gamma_{ij}}.
\tag{CC2}
\]

In particular, if the valid-word family is \(\Delta\)-separated and

\[
\varepsilon_{\rm dp}
<
\gamma_{ij}\bigl(
\Delta-2\eta-\xi_{ij}-\zeta_i-\zeta_j
\bigr),
\tag{CC3}
\]

then \(w_i=w_j\). Thus a quantitative route to unique decoding is to prove lower bounds on
\(\gamma_{ij}\) and upper bounds on \(\xi_{ij},\zeta_i,\zeta_j\) for every pair of heavy
clusters.

### Heavy-cluster spectral corollary

Suppose \(\mu_k(U_i),\mu_k(U_j)\ge \mu_0>0\) and
\(\lambda_{k,s}^{\,2}\le \mu_0/2\). Then (CC4) gives the uniform lower bound

\[
\gamma_{ij}\ge \frac{\mu_0^2}{2}.
\tag{CC5}
\]

Indeed, the error term in (CC4) is at most half of
\(\mu_k(U_i)\mu_k(U_j)\), since
\(\lambda_{k,s}^2/\sqrt{\mu_k(U_i)\mu_k(U_j)}\le 1/2\).
Consequently, if \(\xi_{ij}\le\xi_0\) and
\(\zeta_i,\zeta_j\le\zeta_0\), then all such heavy-cluster words synchronize whenever

\[
\varepsilon_{\rm dp}
<\frac{\mu_0^2}{2}
\bigl(\Delta-2\eta-\xi_0-2\zeta_0\bigr).
\tag{CC6}
\]

For the GMWZ notation in Lemma 6.2 one may set \(\mu_0=\delta^C\). This yields the
explicit gate \(\lambda_{k,s}^2\le\delta^C/2\) and
\(\gamma_{ij}\ge\delta^{2C}/2\). The displayed GMWZ theorem statement, however, gives an
\(X(1)\)--\(X(i)\) estimate rather than the required \(X(k)\)--\(X(\sqrt{k})\) value,
and does not state the transfer bound \(\xi_0\). Thus (CC5)--(CC6) are a conditional
source-specific gate, not an upgrade of Theorem 6.1.

### Spectral lower bound for the cross-cluster mass

There is a standard sufficient condition for the first of these bounds. Let \(M_{k,s}\) be the
normalized incidence operator from \(X(k)\) to the shared \(s\)-faces used by the direct-product
sampler, and let \(\lambda_{k,s}\) be its second singular value. If the sampler is the two-step
walk through a uniformly sampled shared \(s\)-face, then

\[
\gamma_{ij}\ge
\mu_k(U_i)\mu_k(U_j)
-\lambda_{k,s}^{\,2}
\sqrt{\mu_k(U_i)\mu_k(U_j)}.
\tag{CC4}
\]

Indeed, after writing each cluster indicator as its mean plus an orthogonal component, the
two-step operator is \(M_{k,s}M_{k,s}^{\!*}\), whose nonconstant operator norm is at most
\(\lambda_{k,s}^{2}\). Thus (CC4) reduces the cross-cluster part of the UD question to a
concrete inclusion-graph spectral estimate. It is not asserted here that the GMWZ parameter
statement already supplies the required \(X(k)\)--\(X(\sqrt{k})\) value; that transfer must be
checked against the exact HDX theorem and sampling normalization.

### Proof

Under the cross-cluster conditional distribution, let \(E_i\) and \(E_j\) be the two label
errors in item 2. If \(\mathsf{Pass}\) occurs and neither \(E_i\) nor \(E_j\) occurs, then
\(T_1[a](u)=T_1[a'](u)=T_2[b](u)\), hence
\(f_i(u)=f_j(u)\), and therefore \(Y_i(t,u)=Y_j(t,u)\). It follows that

\[
\Pr_{\nu_{ij}}[Y_i\ne Y_j]
\le
\zeta_i+\zeta_j+
\Pr_{\mathcal P}[\neg\mathsf{Pass}\mid a\in U_i,a'\in U_j].
\]

The last conditional probability is at most
\(\varepsilon_{\rm dp}/\gamma_{ij}\). Marginal transfer gives
\(\Pr_{\mathcal Q_{\rm base}}[Y_i\ne Y_j]\le
\Pr_{\nu_{ij}}[Y_i\ne Y_j]+\xi_{ij}\), proving (CC1).

If \(w_i\) and \(w_j\) differ at a sampled coordinate, then at least one of the events
\(Y_i\ne Y_j\), \(Y_i\ne(w_i)_t\), or \(Y_j\ne(w_j)_t\) occurs. This gives
\(\operatorname{dist}(w_i,w_j)\le\rho_{ij}+2\eta\), proving (CC2) and then (CC3).
\(\square\)

## What remains to verify for GMWZ

GMWZ Lemma 6.2 supplies disjoint heavy clusters \(U_i\), functions \(f_i\), and the
within-cluster closeness used to control the \(\zeta\)-terms. The source does not, by itself,
state the cross-cluster lower bound \(\gamma_{ij}\) or the marginal-transfer estimate
\(\xi_{ij}\) in the form above. Establishing these bounds from the HDX inclusion sampler would
yield a genuine UD-preserving direct-product theorem. Conversely, an HDX assignment with
\(\gamma_{ij}\) small or with large \(\xi_{ij}\) would explain why the existing proof naturally
stops at list decoding.

The theorem is therefore a parameterized bridge, not a claim that ordinary list soundness
already implies unique decoding. It also leaves the later alphabet reductions and dPCP
composition untouched.

## Source

The cluster decomposition and the per-cluster words are from Section 6 of
[Gur--Minzer--Weissenberg--Zheng](https://arxiv.org/html/2512.12960), especially Lemma 6.2,
Lemma 6.4, and the proof of Theorem 6.1. The inequality above is the elementary
cross-cluster conditioning argument written with the exact missing sampler parameters.
