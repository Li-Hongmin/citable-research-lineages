# 低 soundness ACRR 直接升级为 LDC

## 定理地位

这是一个 family-level、target-relative 的参数化障碍。它把任意非 projection 的
ACRR 先编译为 relaxed LDC，再调用 Cheng--Li--Mao 的“低 soundness RLDC 退化为
LDC”定理。它不声称普通常数 soundness ACRR 都能升级为 LDC；关键窗口是错误分支
概率必须低于约 `2^{-2q}`，并且原 verifier 非自适应。

## ACRR 假设

令

```text
C : {0,1}^k -> Sigma^N
```

为 injective code map。对每个消息 `m`、坐标 `i` 和声明 `b`，给定一个至多 `q` 次
**非自适应**查询的随机 oracle verifier `V_{i,b}`。存在 `rho>0`、
`alpha>beta`，使：

1. 在 `C(m)` 上，正确分支满足
   `Pr[V_{i,m_i}^{C(m)}=1] >= alpha`；
2. 对任意 `z` 满足 `dist(z,C(m))<=rho`，错误分支满足
   `Pr[V_{i,1-m_i}^{z}=1] <= beta`。

查询位置可依赖 `(i,b)` 和随机币，但不依赖已读答案。两个分支的调用使用独立随机币。

## 第一步：ACRR 到 relaxed LDC

定义 `Dec(z,i)`：独立运行 `V_{i,0}` 与 `V_{i,1}`；若恰有一个分支接受，就输出
其声明位，否则输出 `bottom`。这是一个至多 `Q=2q` 次查询的非自适应 decoder。

在 `C(m)` 上，正确输出概率至少为

```text
c >= alpha (1-beta).
```

在 `rho`-近的 `z` 上，错误输出事件包含于错误声明分支的接受事件，故错误概率至多
`s=beta`。因此 `C` 是一个 `(Q,rho,c,s)` relaxed LDC；这里可用保守完备性参数
`c=alpha(1-beta)`。

## 第二步：低 soundness 窗口

Cheng--Li--Mao（arXiv:2603.03717，Theorem 1.5）的非自适应版本说明：若一个
`Q`-query RLDC 的 soundness 为 `s<2^{-Q}`，完备性为至少 `1-epsilon`，且

```text
1 - 2 epsilon - s 2^Q > 0,
```

则在任意半径

```text
delta < rho/(2Q) * (1 - 2 epsilon - s 2^Q)
```

上，同一 code map 给出 `Q`-query 普通 LDC。

代入 `Q=2q`、`epsilon=1-alpha(1-beta)`、`s=beta`，若

```text
beta < 2^(-2q)
and
2 alpha (1-beta) - 1 - beta 2^(2q) > 0,
```

则得到 `2q`-query LDC，半径可取任何

```text
delta < rho/(4q) * (2 alpha (1-beta) - 1 - beta 2^(2q)).
```

完美正确分支 `alpha=1` 时，一个简洁的充分条件是

```text
beta < 1/(2^(2q)+2).
```

### 自适应 verifier 的完美分支特例

若进一步有

```text
Pr[V_{i,m_i}^{C(m)}=1] = 1
and
Pr[V_{i,1-m_i}^{C(m)}=1] = 0,
```

则上面的两分支 decoder 在未腐蚀 codeword 上完美输出，且不需要非自适应。此时可用
Cheng--Li--Mao 的 perfect-completeness 版本（其 Theorem 1.4）：对可自适应的原
verifier，只要 `beta<2^(-2q)`，便得到 `2q`-query LDC，半径可取

```text
delta < rho/(4q) * (1 - beta 2^(2q)).
```

因此“原 verifier 自适应”并非低 soundness 窗口的绝对逃逸；真正需要的是非零
codeword 错误接受与不完美完备性同时存在，才必须回到非自适应的 Theorem 1.5。

### 强 target-relative soundness 的一般推论

上述自适应特例可进一步写成一个与固定常数 soundness 无关的 barrier。假设 binary
family-level ACRR 满足

```text
Pr[V_{i,m_i}^{C(m)}=1] = 1
and
Pr[V_{i,1-m_i}^{z}=1] <= lambda * dist(z,C(m))
```

对所有 \(m,i,z\)，其中距离按 proof 长度归一化、\(\lambda\) 为固定常数。令
`Q=2q`，并取任意

```text
0 < delta < 2^(-Q)/lambda.
```

在半径 `delta` 内，恰一分支接受的 decoder 是完美完备的 `Q`-query RLDC，soundness
至多 `s=lambda*delta<2^(-Q)`。因此 Cheng--Li--Mao 的 Theorem 1.4（允许原 verifier
自适应）给出普通 `Q`-query LDC；任意

```text
0 < r < delta/(2Q) * (1 - lambda*delta*2^Q)
```

均可作为其错误半径。特别地，对固定 `q` 和固定 \(\lambda\)，可以选取固定正的
`delta` 与 `r`，所以 near-linear proof length 直接受到普通 LDC 下界约束。

这个推论的关键不是把常数 `beta` 人为放大，而是 strong soundness 在足够小的固定
半径内自动进入低 soundness 窗口。若 `lambda` 随 `k` 增长、半径被要求固定大于
`2^(-Q)/lambda`，或 soundness 只在 codeword 点成立，则该推论不适用。

### 有限字母表下的 adaptive 展开

还可以把一般 adaptive verifier 先非自适应化。令

```text
U(q,Sigma) = 1 + |Sigma| + ... + |Sigma|^(q-1).
```

固定随机带后，一个深度 `q` 的决策树在每一层至多按 `|Sigma|` 个答案分叉；把该
随机带下所有可能路径出现的位置全部查询，再离线模拟原路径，接受概率完全不变，
每个 claim 分支至多查询 `U(q,Sigma)` 个位置。两分支编译因此给出
`Q=2U(q,Sigma)` 的非自适应 RLDC。于是上面的 Theorem 1.5 适用于

```text
beta < 1/(2^Q+2)       (alpha=1),
```

更一般地适用于 `beta<2^(-Q)` 且
`2 alpha(1-beta)-1-beta 2^Q>0`。所以 adaptive 仍可被排除，但代价由查询树
规模 `U(q,Sigma)` 而不是原始 `q` 控制；若字母表或 `q` 增长，这个展开可能失去
实用的地址尺度。

## 推论与边界

* 对 `q=1`，binary、常数半径且 `beta<1/6` 的非 projection ACRR 已进入 2-query
  LDC，而不只是 2-query RLDC；因此承受经典的指数级 2-query LDC 障碍。
* 对一般固定 `q`，该定理把低 soundness ACRR 送入对应 `2q`-query LDC 下界；具体
  长度指数取决于该查询数的外部 LDC 定理。
* 一般情况下非自适应是当前不完美完备性升级所需的技术条件；有限字母表可用上面的
  决策树展开，但会把查询数替换为 `U(q,Sigma)`。若满足零错误 codeword 特例，则
  自适应版本可直接使用 perfect-completeness 定理。
* `beta` 为普通常数时，本定理不适用；这保留了高 soundness、relaxed rejection、
  自适应查询和 claim-specific address space 等真正开放的逃逸。
* 这是 family-level 结论。单一 RW/JK 目标没有消息族和 injective code map，不能
  直接套用 LDC 下界。

## 证明边界

第一步是本项目的两分支阈值构造；第二步是外部 RLDC-to-LDC 定理。本文不把
Cheng--Li--Mao 的 LDC 下界冒称为本项目原创，也不把低 soundness 窗口外推到一般
Sim-CR。

## 来源

* [Cheng--Li--Mao, When Relaxation Does Not Help](https://arxiv.org/abs/2603.03717)
* [Radius-to-relaxed-LDC barrier](radius-to-relaxed-ldc-barrier.md)
* [Binary projection Sim-CR(2) barrier](../../mcsp-hardness-magnification/notes/198-binary-projection-simcr-two-query-exponential-barrier-2026-08-16.md)
