# Inverse-linear soundness forces an indexed-label channel cost

## Theorem

Let a \(q\)-query, target-independent local decoder over proof alphabet \(\Sigma\) be
required to identify one of \(L_k\) globally indexed candidate words in a common proof
address space. Suppose indexed completeness is at least a fixed \(\alpha>0\) for every
candidate index. Then

\[
  \alpha L_k\le |\Sigma|^q,
\qquad\text{equivalently}\qquad
  q\log_2|\Sigma|\ge \log_2 L_k+\log_2\alpha .
\tag{IC1}
\]

Assume in addition that the intended distributional-to-coordinate route requires
\(\varepsilon_k\le c/k\) and that its candidate list obeys

\[
  L_k\ge \varepsilon_k^{-d}
\tag{IC2}
\]

for fixed \(c,d>0\). Then

\[
  q\log_2|\Sigma|
  \ge d\log_2 k-d\log_2 c+\log_2\alpha
  =\Omega(\log k).
\tag{IC3}
\]

Thus a black-box upgrade from an unlabelled list to a target-independent indexed channel
cannot simultaneously keep constant \(q\) and subpolynomial alphabet when the list grows as
\(\varepsilon_k^{-d}\). With a fixed alphabet it requires \(q=\Omega(\log k)\); with constant
query complexity it requires \(|\Sigma|=k^{\Omega(1)}\).

## Proof

Fix the random tape of the decoder. Its adaptive interaction with a proof is a
\(|\Sigma|\)-ary decision tree of depth at most \(q\). For every candidate \(s\) on which
the decoder outputs \(s\), record the stopping transcript. Two distinct correctly indexed
targets cannot share a transcript, since the decoder would have the same output on the
same transcript. The stopping transcripts are prefix-free, so their number is at most
\(|\Sigma|^q\). Averaging over the random tape gives

\[
  \sum_{s=1}^{L_k}
  \Pr[\text{decoder outputs }s\text{ on }\Pi^{(s)}]
  \le|\Sigma|^q.
\]

Indexed completeness lower-bounds every summand by \(\alpha\), proving (IC1). Substituting
\(L_k\ge(c/k)^{-d}\) gives (IC3).
\(\square\)

## Consequence for the ACRR route

Theorem 3.9A shows that an indexed global list plus a smooth outer decoder can tolerate a
base average error \(\varepsilon_k\) only after paying the term
\(q_D\lambda\varepsilon_k\); in the usual uniform-coordinate regime with
\(\lambda=\Theta(k)\), this requires \(\varepsilon_k=O(1/k)\). If the list-to-index
compiler then has \(L_k\ge\varepsilon_k^{-d}\), (IC3) is an independent cost before any
selector matrix or outer-code analysis. The route must therefore do at least one of the
following:

1. increase locality to \(\Omega(\log k)\) over a fixed alphabet;
2. increase the answer alphabet to \(k^{\Omega(1)}\) at constant locality;
3. prove that the relevant candidate list is smaller than every
   \(\varepsilon_k^{-d}\) in the target window; or
4. abandon a target-independent local index channel and supply a different global
   consistency mechanism.

This is an information/locality tradeoff, not a proof-length lower bound. It does not
assert that every dPCP has a large list: a genuinely singleton or otherwise small-list
construction can evade (IC2). In particular, a theorem stating only
\(L=\operatorname{poly}(1/\varepsilon)\) supplies an upper bound, not the lower bound in
(IC2); its alphabet dependence must be made explicit before this tradeoff can be applied.

## Relation to existing results

* [Indexed-label locality barrier](indexed-label-locality-barrier.md) is the underlying
  decision-tree inequality.
* [Theorem 3.9A](../papers/Address-Scale-Barriers-for-Shared-Proof-Coordinate-Robustness/paper.md)
  supplies the inverse-linear error interface and the near-codeword smoothness term.
* [Weighted distributional-to-coordinate barrier](weighted-distributional-to-coordinate-barrier.md)
  explains why the inverse-linear requirement cannot be replaced by a constant average error
  under uniform coordinate sampling.
* The GMWZ dPCP theorem states a polynomial upper bound on list size as a function of
  \(1/\varepsilon\), but does not by itself provide (IC2) or the indexed channel required
  here; this file records only the conditional parameter consequence.
