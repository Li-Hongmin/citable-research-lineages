# The shared-top-face sampler is not automatically the BMVY down-up walk

This statement records a source-specific normalization gap in the proposed
cross-cluster synchronization route. It is not a lower bound for HDX samplers;
it says only that the spectral estimate for a different walk cannot be imported
without an explicit coupling or comparison lemma.

## Two pair distributions

Let \(X\) be a \(d\)-dimensional complex with its standard consistent face
measures \(\mu_j\). For \(s<k<d\), define the **shared-top-face** pair law
\(\mathsf K^{\mathrm{top}}_{d;k,s}\) by

1. sample \(D\sim\mu_d\);
2. sample \(B\subset D\), \(|B|=s\), uniformly;
3. sample \(A,A'\subset D\), \(|A|=|A'|=k\), independently and uniformly
   subject to \(B\subset A,A'\).

This is exactly the order in the direct-product tester stated in
[Gur--Minzer--Weissenberg--Zheng, Definition 2.7](https://arxiv.org/html/2512.12960#S2.3.3)
and in [Bafna--Minzer--Vyas--Yun, Definition 2.12](https://arxiv.org/html/2407.12762#S2.5).

By contrast, the down-up walk controlled by BMVY Lemma 2.8 is the pair law
\(\mathsf K^{\mathrm{du}}_{k;s}\): sample \(B\sim\mu_s\), and then sample
\(A,A'\) independently from the conditional \(\mu_k\)-distribution given
\(B\subset A,A'\). Its nonconstant singular value is bounded by the stated
\(\alpha+\operatorname{poly}(k)\gamma\) when \(s=\alpha k\), under their local
spectral-expansion hypothesis:
[BMVY Lemma 2.8](https://arxiv.org/html/2407.12762#S2.3).

The shared \(D\) in \(\mathsf K^{\mathrm{top}}_{d;k,s}\) is not removable by the
consistency of the one-face marginals. Conditional on \(B\), integrating out a
common \(D\) leaves a correlation between \(A\) and \(A'\); independent sampling
from \(\mu_k(\cdot\mid B)\) removes that correlation.

## Minimal counterexample

Take the complete complex on four vertices, with \(d=3\), \(k=2\), and \(s=1\).
All local link graphs are complete, so this example has no local spectral defect.
For the shared-top-face law, after \(D\) and \(B\) are fixed there are exactly two
admissible edges through \(B\), hence

\[
  \Pr_{\mathsf K^{\mathrm{top}}_{3;2,1}}[A=A']=\frac12.
\]

For the down-up law, a fixed vertex \(B\) lies in three global edges and \(A,A'\)
are independent among them, so

\[
  \Pr_{\mathsf K^{\mathrm{du}}_{2;1}}[A=A']=\frac13.
\]

Thus the two pair laws differ even on a maximally expanding toy complex. In
particular, the BMVY Lemma 2.8 estimate for \(U_s^kD_s^k\) does not, from its
statement alone, give a bound for the GMWZ shared-\(D\) pair operator.

## Consequence for the synchronization gate

The heavy-cluster condition in the cross-cluster synchronization statement is
valid if the *actual* pair operator has second singular value

\[
  \sigma_2(\mathsf K^{\mathrm{top}}_{d;k,s})\leq\lambda,
\]

because then the usual indicator decomposition gives

\[
  \gamma_{ij}\geq \mu_k(U_i)\mu_k(U_j)
  -\lambda\sqrt{\mu_k(U_i)\mu_k(U_j)}.
\]

The currently available BMVY estimate instead concerns the different
\(\mathsf K^{\mathrm{du}}_{k;s}\) operator. Therefore a source-level UD upgrade
still needs one of the following genuinely new ingredients:

* an exact identification of the GMWZ shared-\(D\) law with a down-up operator in
  the particular HDX (with all normalizations written out);
* a comparison theorem transferring the BMVY singular bound to
  \(\mathsf K^{\mathrm{top}}_{d;k,s}\); or
* a direct cross-cluster mixing estimate for the shared-\(D\) law.

Even after this spectral issue is solved, the conditional base-decoder transfer
\(\xi_{ij}\) in the synchronization criterion remains a separate obligation;
the spectral estimate alone does not control the \((t,u)\)-marginal after
conditioning on two clusters.

## Status and boundary

This is a normalization/coupling barrier, not an impossibility theorem for
simultaneous coordinate robustness. It narrows the positive attack to a precise
next lemma: prove a bound for the actual shared-top-face operator, then separately
prove the decoder-marginal transfer. Until both are supplied, the heavy-cluster
corollary is conditional and should not be advertised as a GMWZ theorem.

## Source boundary

The sampling order and the direct-product definition are source facts from the
two linked papers. The \(n=4,d=3,k=2,s=1\) computation is an elementary derived
counterexample to identifying the two pair laws. No claim is made that the
specific HDX family used by GMWZ violates the required shared-top-face spectral
bound; only that the cited down-up lemma does not establish it automatically.
