# 强 canonical commitment--evaluation 到 simultaneous coordinate robustness

## 定理地位

这是一个条件性组合定理，目标是把“强 canonical PCP + 单一 commitment/evaluation
策略”与用户提出的 simultaneous coordinate-robust dPCP 精确接起来。它不是声称
现有强 canonical PCP 已经满足 RW/JK 地址尺度；它把缺口分成可独立检验的
`canonicality`、`target code` 和 `short address-scale compilation` 三项。

## 接口

固定实例 `x`，目标词为 `f_x in {0,1}^k`。令 `p_x in Sigma^N` 是唯一指定的
canonical proof word，且其中一段固定地址区 `J` 编码外层码字
`C(f_x) in Sigma^M`。要求 `C` 有相对距离 `delta_C>0`，并有一个目标位局部解码器
`D_i`：若 `y` 与 `C(f_x)` 的距离至多 `delta_C/4`，则

```text
Pr[D_i(y) notin {f_x[i], bottom}] <= eta_D.
```

所有坐标共享同一 commitment `alpha`、同一 proof 地址空间和同一 Merlin strategy。
假设存在以下强 canonical commitment--evaluation 接口：

1. **完美完备性。** 存在 `alpha_x` 和一个固定 honest strategy `tau_x`，使
   `K_x(alpha_x; tau_x)` 以概率 1 接受；对任意地址 `j`，
   `Eval(alpha_x,tau_x,j)` 精确输出 `p_x[j]`。
2. **单值化。** 对每个 commitment `alpha`，存在一个唯一词
   `g_alpha in Sigma^N`，使任意 strategy 的 evaluation 在每个地址只输出
   `g_alpha[j]` 或 `bottom`；每次 evaluation 偏离该二值集合的概率至多 `eta_E`。
   这里的 `g_alpha` 只由同一个 `alpha` 决定，不能随坐标切换。
3. **canonicality soundness。** 对任意 `alpha` 和 strategy，若
   `dist(g_alpha,p_x)>delta_P`，则 `K_x` 接受率至多 `beta_K`。
4. **目标区稳定性。** 若 `dist(g_alpha,p_x)<=delta_P`，则
   `dist(g_alpha|J,C(f_x))<=delta_C/4`。若全词距离按长度 `N` 归一化、目标区
   `|J|=M`，一个足够的显式条件是
   `delta_P <= (M/(4N)) delta_C`；也可以由专门的 target-binding test 直接提供。
5. **目标区可访问。** `D_i` 只调用 `q_D` 次同一 `Eval` 接口，读取 `J` 中的
   地址；地址生成、`K_x`、`Eval` 和 `D_i` 的描述在 `poly(|x|,log N)` 时间内统一生成。

这里的 `K_x` 可以是强 canonical PCP/PCPP 的约束测试，也可以是其
commitment/evaluation 编译版本。第 3 条是必须显式保留的量词：仅有“每个坐标存在
一个可验证 proof”不够，因为不同坐标可能使用不同 commitment。

## 构造

对坐标 `i` 和声明位 `b`，定义同一个全局 commitment 上的 verifier
`V_{x,i,b}`：

1. 运行 `K_x`；
2. 用 `D_i` 从同一 `alpha` 的 `J` 区域恢复目标位；
3. 仅当 `K_x` 接受且解码结果恰为 `b` 时接受；`bottom` 一律拒绝。

所有 `(i,b)` 使用同一个 `alpha`、同一个地址空间和同一个 strategy，因此不会发生
逐坐标换 proof 或 phantom word。

## 结论

若 `b=f_x[i]`，则在 `(alpha_x,tau_x)` 上完美接受。若 `b!=f_x[i]`，则对任意
`alpha,tau`，错误接受率至多

```text
beta_ACRR <= max{ beta_K, eta_D + q_D eta_E }.
```

证明分两种情形。若 `g_alpha` 离 `p_x` 超过 `delta_P`，由第 3 条得到
`Pr[K_x accepts] <= beta_K`。否则，由第 4 条 `g_alpha` 在目标区落在
`delta_C/4` 邻域内，目标解码器错误概率至多 `eta_D`；`q_D` 次 evaluation 的
单值化失败用 union bound 增加至多 `q_D eta_E`。两种情形取最大值即得结论。

该结论是同时坐标鲁棒的：错误声明不依赖坐标专属的 proof、preimage 或 Merlin
strategy。它也保留 `bottom` 语义，故不把交互式评估误当成 deterministic JK seed。

## 与 RW/JK 的精确缺口

这个桥接不会自动解决项目主问题，原因是三项条件各自对应不同的未知：

* **外码不是瓶颈本身。** 常率、常距离、局部可测试/可解码的编码已经存在；困难是
  把 `C(f_x)` 与同一个 computation relation 绑定到 `p_x`。
* **强 canonical PCP 仍可能是地址尺度过大的。** 已知的强 canonical
  Reed--Muller PCP/AM reconstruction 可以给出 commitment 后的单值评估，但其重构
  时间和 advice/commitment 参数仍按 proof 长度或准多项式地址尺度记账；这不等于
  `poly(n,log T)` 的统一 `Eval`。
* **唯一 canonical proof 不能从局部 left-canonical 自动得到。** 若合法 history
  有多个全局 assignment，必须额外规定唯一 `p_x`，或证明 commitment test 对所有
  非 canonical assignment 都满足第 3 条。否则 `alpha` 可以承诺另一合法 history，
  而每个坐标仍各自通过。

因此，真正能晋级为新的 PCP/coding theorem 的目标是同时实现：

```text
N+M = k polylog(k),
q_K,q_D = O(1),
poly(n,log T) address generation,
and canonicality/target binding under one alpha.
```

若这些条件只能在 `N >= k^{1+Omega(1)}` 或 `q`-scale history 通道下实现，则应把结果
转入 RLDC/LDC 下界路线，而不是把交互式 commitment 当作 RW/JK 成功。

## 证据边界与来源

本定理是由上述四项量词直接推导的项目内组合结果。Chen--Li--Liang 的强 canonical
Reed--Muller PCP 与 AM commitment/evaluation 提供了第 1--2 项的文献先例，但其参数
并未给出本文件要求的 RW 地址尺度或 computation-relation target binding，见
[TR24-182](https://eccc.weizmann.ac.il/report/2024/182/)。

已知 PCPP/RLDC 组合说明：若完整 history 已显式放入 proof，便可得到类似的
coordinate robustness；但这正是本项目要压缩掉的 `N`-尺度通道，见
[TR20-113](https://eccc.weizmann.ac.il/report/2020/113/)。

所以本文件的地位是一个可证伪的 top-tier interface：证明其地址尺度实例化，或证明
第 2--4 项必然支付超线性编码代价，都会超出“再增加一个局部 decoder note”的层级。
