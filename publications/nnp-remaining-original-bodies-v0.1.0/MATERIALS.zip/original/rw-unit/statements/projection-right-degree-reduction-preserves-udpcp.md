# Projection right-degree reduction preserves unique decoding

This is a self-contained restatement of the unique-decoding part of
[Gur--Minzer--Weissenberg--Zheng, Lemma 4.4](https://arxiv.org/html/2512.12960), with the
expander-mixing calculation exposed because it locates the first possible loss in the later
composition chain. It is not claimed as a new theorem of this project.

## Theorem

Let \(\mathcal D\) be a projection dPCP with edge distribution \(\mu\), left-based
decoding distribution \(\mathcal Q\), and \((\epsilon_0,\eta_u)\) unique-decoding soundness:
every assignment satisfying at least \(1-\epsilon_0\) of the \(\mu\)-mass of constraints is
explained by one word with average decoding error at most \(\eta_u\).

For every original right vertex \(b\), replace its incident weighted multiset of left
vertices by a biregular bipartite sampler \(H_b=(A_b,B_b,E_b)\) of right degree \(d'\). The
left copies in \(A_b\) are identified with the original left vertices, with multiplicity,
so the uniform measure on \(A_b\) is the conditional edge distribution \(\mu(\cdot\mid b)\),
and each edge of \(H_b\) carries the original projection constraint. Assume the sampler has
second singular value at most \(\lambda\), and that the resulting complete decoding
distribution preserves the original marginal on the left vertices (as in the standard
right-degree reduction). Let \(\mathcal D'\) be the resulting projection dPCP.

Then \(\mathcal D'\) has unique-decoding soundness

```text
epsilon'_0 = max{0, epsilon_0 - lambda},
eta'_u = eta_u.
```

In particular, with the expanders used in the standard construction,
\(\lambda=O(d'^{-1/2})\), so the reduction loses only an additive
\(O(d'^{-1/2})\) amount in the satisfiability threshold and does not change the global
decoding word. Perfect completeness and left-decoder complexity are preserved.

## Proof

Fix a reduced assignment \((T_A,T'_B)\). For every original right vertex \(b\), choose a
right copy \(b'\in B_b\) uniformly and define a randomized base right label

```text
T^*_B[b] = T'_B[b'].
```

For a fixed \(b\) and symbol \(\sigma\), let

```text
F_{b,sigma}(a) = 1[ sigma_{a->b}(T_A[a]) = sigma ],
G_{b,sigma}(b') = 1[ T'_B[b'] = sigma ].
```

Because the constraints are projections, the reduced constraint on an edge \((a,b')\) is
satisfied exactly when the two indicators agree for the corresponding \(\sigma\). Hence the
reduced satisfaction on the gadget \(H_b\) is

```text
sum_sigma E_{(a,b')~H_b}[F_{b,sigma}(a) G_{b,sigma}(b')].
```

The expander-mixing hypothesis gives, for each \(\sigma\),

```text
E_H[F_{b,sigma} G_{b,sigma}]
 <= E_{A_b}[F_{b,sigma}] E_{B_b}[G_{b,sigma}]
    + lambda * sqrt(E_{A_b}[F_{b,sigma}] E_{B_b}[G_{b,sigma}]).
```

Summing over \(\sigma\) and applying Cauchy--Schwarz, the error terms sum to at most
\(\lambda\), because both families of indicators form partitions. The product terms are
exactly the expected satisfaction of the original constraint when the randomized label
\(T^*_B[b]\) is sampled. Averaging over \(b\) therefore yields

```text
Pr_{(a,b)~mu}[ base constraint(T_A[a], T^*_B[b]) is violated ]
 <= epsilon' + lambda,                              (1)
```

where \(\epsilon'\) is the violation rate of the reduced assignment. If
\(\epsilon'\le\epsilon_0-\lambda\), the expected base violation in (1) is at most
\(\epsilon_0\). Consequently some deterministic fixing of all the independently sampled
right labels \(T^*_B[b]\) has violation at most \(\epsilon_0\). The unique-decoding
hypothesis for \(\mathcal D\) supplies one word \(w\in\mathcal L\) with error at most
\(\eta_u\). Since the reduction leaves the left assignment and its decoding distribution
unchanged, \(\mathcal D'\) has the same decoded word and error.

For perfect completeness, copy the honest base right label to every right copy in \(B_b\).
Every lifted edge is then satisfied, and the left decoder still outputs the same word.

## Consequence for the composition program

The standard right-degree reduction is therefore not an inherent source of the
unique-decoding-to-list-decoding loss either. Its only loss is the explicit sampler error
\(O(d'^{-1/2})\). Together with the projection right-alphabet theorem, this leaves the
earlier gap-amplification, HDX routing, and dPCP composition stages as the remaining places
where a single near-satisfying global word might be lost.

This is a source-localized preservation statement, not a claim that the GMWZ final dPCP has
unique decoding:
their right-degree reduction is stated for list soundness because the incoming guarantee at
that stage is list soundness. The theorem says that if one can carry unique decoding into the
stage, the degree regularization itself does not destroy it.

## Scope and boundary

The sampler must preserve the original left marginal and must be biregular with the stated
mixing bound. If the reduction changes the decoding distribution on left vertices, the final
step comparing decoding error to the base system requires an additional total-variation term.
The theorem also relies on projection constraints; with general binary constraints, the
partition identity by \(\sigma\) is unavailable. Finally, \(\epsilon_0>\lambda\) is needed for
a nontrivial threshold.

## Source and status

The graph transformation is the standard right-degree reduction. The cited paper already
states the corresponding unique-decoding result as Lemma 4.4, with parameters
((\eta,\varepsilon-O(d'^{-1/2}))). Its later Lemma 7.2 analyzes a related list-decoding
version. The present file records the proof in the notation used by the ACRR program and
uses it to mark right-degree reduction as a surviving step, not as a new standalone result.
