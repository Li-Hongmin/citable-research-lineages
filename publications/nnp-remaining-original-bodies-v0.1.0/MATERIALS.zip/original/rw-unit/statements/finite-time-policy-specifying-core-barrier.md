# Finite-time policy support forces descriptor-restricted specifying cores

## Theorem

Let

```text
M subseteq {0,1}^k,       C : M -> Sigma^N,
```

where `Sigma` is finite.  Each message `m` has an `s`-bit descriptor
`kappa(m)`.  For every descriptor `sigma`, coordinate `i`, and declaration `b`, let
`V_{sigma,i,b}` be a finite-time adaptive verifier on one proof address space `[N]`.  Its
response policies may be arbitrary, but the verifier's wrong-declaration soundness is quantified
over **all** deterministic policies in the finite observed view tree.  Write
`mathfrak P_{sigma,i,b}` for that policy family and `Supp(V_{sigma,i,b,pi})` for full branch
support.
Write `p_{sigma,i,b,pi}(z)` for the corresponding acceptance probability.

Assume constants `rho >= 0` and `alpha > beta` with:

1. **Completeness.**  For every `m` and `i`, there is a policy
   `pi_{m,i} in mathfrak P_{kappa(m),i,m_i}` such that
   `p_{kappa(m),i,m_i,pi_{m,i}}(C(m)) >= alpha`.
2. **All-policy target-relative soundness.**  For every `m`, `i`, every
   `pi in mathfrak P_{kappa(m),i,1-m_i}`, and every `z` with
   `dist(z,C(m)) <= rho`,
   `p_{kappa(m),i,1-m_i,pi}(z) <= beta`.

For each message choose one complete policy per coordinate and define its complete-policy core

```text
K_m = union_{i in [k]} Supp(V_{kappa(m),i,m_i,pi_{m,i}}).
```

Then for every distinct `m,m'` in the same descriptor bucket,

```text
C(m)|_{K_m} != C(m')|_{K_m}.                         (SPC1)
```

Consequently, if `|K_m| <= r` for every `m`, then

```text
2^h <= 2^s * sum_{t=0}^r binom(N,t) |Sigma|^t,       (SPC2)
```

where `h=log_2|M|`.  For `1 <= r <= N`,

```text
h-s <= log_2(r+1) + r log_2(e N |Sigma| / r).        (SPC3)
```

In particular, for a full `k`-bit family, constant `|Sigma|`, `N=k^{O(1)}`, and
`s=o(k)`, no finite-time all-policy construction can have complete-policy cores of size
`r=o(k/log k)`.

## Core-tail corollary and the support--core dichotomy

Let `B_sigma={m in M:kappa(m)=sigma}` and
`B_sigma(r)={m in B_sigma:|K_m|<=r}`.  The same injective triple argument gives the sharper
tail bound

```text
|B_sigma(r)| <= sum_{t=0}^r binom(N,t)|Sigma|^t.       (SPC5)
```

Consequently, for a largest descriptor bucket, whose size is at least `2^(h-s)`,

```text
Pr_{m uniform in B_sigma}[ |K_m|>r ]
  >= 1 - 2^{-(h-s)} sum_{t=0}^r binom(N,t)|Sigma|^t.   (SPC6)
```

This is a target-distributional statement, not merely an existential one.  For constant
`|Sigma|`, `N=k^{O(1)}`, `h-s=Omega(k)`, and `r=o(k/log k)`, the right side is
`1-2^{-Omega(k)}`.

Equivalently, define

```text
r_H = max { r <= N : log_2(r+1) + r log_2(e N |Sigma|/r) <= (h-s)/2 },
```

whenever this set is nonempty.  On a largest descriptor bucket,

```text
E_m[ |K_m| ] >= r_H (1 - 2^{-(h-s)/2}).             (SPC6a)
```

Here the expectation is over the uniform message in that largest bucket.

Thus the barrier is an average address-cost lower bound, not only a worst-target statement.
For `h-s=Omega(k)`, constant `|Sigma|`, and `N=k^{O(1)}`, it gives
`E_m[|K_m|]=Omega(k/log k)`.

Combine this with the all-policy branch-support barrier inside the same bucket.  If
`L_sigma` is the union support of every finite-time policy in that descriptor bucket and the
DGL relaxed-LDC window applies, then

```text
h-s <= C |Sigma|^{L_sigma} log_2|Sigma| N^(1-theta(L_sigma)) log_2(k+2).  (SPC7)
```

Here `theta(L)=c/(L^2 log^2(L+2))` is the locality exponent from the cited DGL window.

Thus a high-entropy near-linear construction must pay both costs: `L_sigma` must leave the
relaxed-LDC window, and (SPC6) says that almost every target in a largest bucket must have a
large complete-policy core.  It cannot hide all target information in a small honest support
while reserving a large support only for strategies that are never complete.

## Proof

Fix distinct `m,m'` with `kappa(m)=kappa(m')`, and choose a coordinate `i` with
`m_i != m'_i`.  Suppose, toward a contradiction, that
`C(m)|_{K_m}=C(m')|_{K_m}`.  The complete policy `pi_{m,i}` has full branch support contained
in `K_m`.  Therefore, on every random tape and every adaptive branch, the verifier sees exactly
the same proof symbols under `C(m)` and `C(m')`; the two acceptance probabilities are equal:

```text
p_{kappa(m),i,m_i,pi_{m,i}}(C(m'))
 = p_{kappa(m),i,m_i,pi_{m,i}}(C(m)) >= alpha.         (SPC4)
```

Since `m_i != m'_i`, the same policy is a wrong-declaration policy for target `m'` in the
same descriptor bucket.  Applying all-policy soundness for target `m'` to `z=C(m')` gives
the left side of (SPC4) at most `beta`, a contradiction.  Hence (SPC1) holds.

Encode each message by the triple

```text
( kappa(m), K_m, C(m)|_{K_m} ).
```

By (SPC1), two messages with the same descriptor cannot have the same second and third
components: if they did, the restriction of one codeword to the other's `K` would agree,
contradicting (SPC1).  Thus the triple map is injective.  There are at most `2^s` descriptors,
at most `sum_{t<=r} binom(N,t)` possible cores, and at most `|Sigma|^r` restrictions for each
core, which proves (SPC2).  The standard bound

```text
sum_{t=0}^r binom(N,t)|Sigma|^t
    <= (r+1) (e N |Sigma| / r)^r
```

gives (SPC3).

## Why this is stronger than an assumed specifying-set condition

The previous descriptor-core counting barrier required a separate hypothesis that the chosen
core hits every same-descriptor disagreement.  Here that property is derived from the verifier
semantics: a complete policy's full adaptive support is already a specifying core, because the
same policy becomes a wrong declaration for any same-descriptor target that differs in that
coordinate.  No DGL radius window is needed; `rho=0` suffices.  The proof also tolerates
unbounded Merlin computation, since only the finite-time verifier's observed policy tree enters
the argument.

## Scope and escape classes

The theorem requires all of the following:

* a common physical proof address space within each descriptor bucket;
* verifier circuits independent of the hidden message once the descriptor is fixed;
* all-policy wrong-declaration soundness, not merely soundness for one selected strategy;
* full branch support, not only the honest-path support;
* a finite-time bit-model, so complete policies induce finite observable trees.

It does not apply when each target has an independent proof oracle, when the verifier may use
the full target beyond the descriptor, when only target-selected policies are sound, or when the
candidate uses a genuinely unbounded/continuous information model.  These are explicit model
escapes rather than hidden failures of (SPC1).

## Relation to existing modules

* [Message-dependent core-hitting barrier](message-dependent-core-hitting-barrier.md) assumed
  the specifying-set condition; this theorem derives it from complete-policy support.
* [Branch-support barrier](strategy-support-acrr-rldc-barrier.md) uses the union support of all
  policies to produce a relaxed LDC.  The present theorem is complementary: it uses only one
  complete policy per coordinate and obtains a descriptor-entropy bound without a DGL window.
* [Payload lifting family barrier](payload-lifting-family-barrier.md) supplies the corresponding
  key--support--length inequality when the complete-policy cores are not individually short.

## Evidence boundary

The proof is a finite-support indistinguishability argument and is self-contained.  It is not
an unconditional lower bound against all dPCPs or all single-target RW/JK instances; the core
size and all-policy quantifiers must be verified for the proposed proof graph.
