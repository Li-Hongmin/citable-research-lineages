# Simultaneous coordinate-robustness Closure Theorem

## Statement

Let \(\Gamma\) have size \(A\ge2\), let \(\mathcal Y\subseteq\Gamma^M\) be a valid
global-word family, and define
\[
 \operatorname{Rect}(\mathcal Y)=\prod_{j=1}^M\pi_j(\mathcal Y),
 \qquad
 \mathcal Y_{\le t}=\bigcup_{y\in\mathcal Y}B_H(y,t).
\]
If a relation-PCP/dPCP composition uses only the premise
\(w_j\in\pi_j(\mathcal Y)\) independently for every coordinate, then it can conclude
that \(w\) is within distance \(t\) of one valid word exactly when
\[
 \operatorname{Rect}(\mathcal Y)\subseteq\mathcal Y_{\le t}.
\tag{1}
\]

Let \(d\) be the minimum distance of \(\mathcal Y\).  Under (1),
\[
 \sum_{j=1}^M\log_A|\pi_j(\mathcal Y)|
 \le M-d+1+\log_A V_A(M,t),
 \qquad
 V_A(M,t)=\sum_{u\le t}\binom Mu(A-1)^u.
\tag{2}
\]
Thus full coordinate projections and constant relative distance force
\(d/M\le H_A(t/M)+o(1)\).  If (1) fails, a phantom word in the rectangular hull is an
explicit certificate that coordinatewise witnesses do not define a global word.

The same closure theorem has a nonuniform-sampling form.  For weights
\(\lambda_j\ge0\) with \(\sum_j\lambda_j=1\), define
\[
 d_\lambda(x,y)=\sum_j\lambda_j\mathbf 1[x_j\ne y_j],
 \qquad
 V_{A,\lambda}(u)=
 \sum_{\substack{S\subseteq[M]\\\sum_{j\in S}\lambda_j\le u}}
 (A-1)^{|S|}.
\]
If the rectangular hull is covered by weighted radius-\(t\) balls and
\(d_\lambda=\min_{y\ne y'}d_\lambda(y,y')\), then for every \(r<d_\lambda/2\),
\[
 \sum_{j=1}^M\log_A|\pi_j(\mathcal Y)|
 \le M+\log_A V_{A,\lambda}(t)-\log_A V_{A,\lambda}(r).
\tag{3}
\]
This covers nonuniform dPCP coordinate sampling and coordinate replication; it is
still a coding-level statement, not an unconditional dPCP impossibility theorem.

There is also a probabilistic product form. Let (Z_j) be independent and uniform on
(pi_j(mathcal Y)), put (p_j=|pi_j(mathcal Y)|), and define
\[
 V_{p,\lambda}(t)=
 \sum_{\substack{S\subseteq[M]\\\sum_{j\in S}\lambda_j\le t}}
 \prod_{j\in S}(p_j-1).
\]
Then
\[
 \Pr[d_\lambda(Z,\mathcal Y)\le t]
 \le \frac{|\mathcal Y|V_{p,\lambda}(t)}{\prod_jp_j}
 \le \frac{A^{M-d+1}V_{p,\lambda}(t)}{\prod_jp_j}.
\tag{4}
\]
This is a product-distribution anti-concentration statement; a same-seed or otherwise
jointly correlated distribution is outside its hypotheses.

## Consequence for the RW/dPCP attack

This is the exact fork for a simultaneous coordinate-robust construction:

* If the construction remains coordinatewise, (1) and (2) impose the projection-
  entropy/distance cost, and failure gives a phantom-word separation.
* If it adds a same-seed or other joint coupling that yields the target-relative common-proof
  hypotheses of Theorem 2.1, the proof map becomes a relaxed locally decodable code and must
  pay the RLDC length/locality lower bounds.

Ordinary list, average, or existential dPCP soundness does not provide (1) or the joint
coupling automatically.  The theorem is a general closure criterion; it is not an
unconditional impossibility theorem for all dPCPs.

## Proof

The first equivalence is the definition of the rectangular hull.  Under (1), its size is
\(\prod_j|\pi_j(\mathcal Y)|\), while it is covered by \(|\mathcal Y|\) balls of radius
\(t\).  Singleton gives \(|\mathcal Y|\le A^{M-d+1}\), yielding (2).  If (1) fails,
choose a word in the set difference; its coordinate witnesses exist by rectangularity,
but no global valid word is close.  The RLDC consequence is Theorem 2.1 applied only after
the extra joint coupling has supplied its common-proof, target-relative hypotheses.
For (3), weighted balls have center-independent volume \(V_{A,\lambda}\); balls of
radius \(r<d_\lambda/2\) around valid words are disjoint, while weighted closure covers
the rectangular hull.  Hence
\(\prod_j|\pi_j(\mathcal Y)|\le|\mathcal Y|V_{A,\lambda}(t)\) and
\(|\mathcal Y|V_{A,\lambda}(r)\le A^M\); eliminating \(|\mathcal Y|\) gives (3).
For (4), fix (y\in\mathcal Y). The error set
\(S=\{j:Z_j\ne y_j\}\) has probability
\(\prod_{j\in S}(p_j-1)/\prod_jp_j\), and summing over weighted sets gives
\(V_{p,\lambda}(t)/\prod_jp_j\). A union bound over (y), followed by
\(|\mathcal Y|\le A^{M-d+1}\), proves (4).
