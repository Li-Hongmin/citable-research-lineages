# Key-indexed ACRR 的 shared-key / RLDC 二分（2026-08-16）

## 定理地位

这是把 singleton target-channel 熵界与 Dall'Agnol--Gur--Lachish（DGL）的
relaxed-LDC sample lower bound 接起来的 family-level 定理。它允许 verifier 依赖一个
短的 target key，但不允许 verifier 为同一 key 下的不同 message 重新换 proof 语义。
它不是对单一 RW 实例的无条件 lower bound；关键量词和鲁棒半径在定理中显式给出。

## 模型

令 `M subseteq {0,1}^k` 为消息族，`C:M -> Sigma^N` 为 proof/codeword map，且
`Sigma` 是有限 alphabet。每个消息 `m` 有一个 `s` 比特 key
`kappa(m) in {0,1}^s`。对每个 key `sigma`、坐标 `i in [k]` 和 declaration
`b in {0,1}`，有一个统一的 randomized verifier `V_{sigma,i,b}`，最多查询
`q_0` 个 proof symbols。写

```text
p_{sigma,i,b}(z) = Pr[V_{sigma,i,b}^z accepts].
```

假设存在 `rho>0` 与 `alpha>beta`，使：

1. **同 key 完备性：** 若 `kappa(m)=sigma`，则
   `p_{sigma,i,m_i}(C(m)) >= alpha`；
2. **target-relative near-oracle soundness：** 若 `kappa(m)=sigma` 且
   `dist(z,C(m)) <= rho`，则
   `p_{sigma,i,1-m_i}(z) <= beta`。

这些条件只要求同一 key 桶内的 verifier 语义一致；不同 key 可以有不同 verifier。

令

```text
h      = log_2 |M|,
h_star = max_sigma log_2 |{m in M : kappa(m)=sigma}|.
```

显然 `h_star >= h-s`。

## 结论

取 `delta<rho/2`，并令

```text
Q = O(q_0 (alpha-beta)^(-2))
```

为阈值化后的 local-decoder locality。假设 DGL 的参数域成立；若 `rho` 随 `N` 变化，
还要求参数化 DGL sample theorem 的窗口条件成立（见同目录的
`parameterized-dgl-small-radius-sample-theorem.md`）。则存在绝对常数 `c_D,C_D>0`
和

```text
theta = c_D / (Q^2 log^2(Q+2))
```

使

```text
h-s <= C_D |Sigma|^Q log_2|Sigma| · N^(1-theta) · log_2(k+2).
```

等价地，只要 `h>s`，就有

```text
N >= [ (h-s) /
       (C_D |Sigma|^Q log_2|Sigma| log_2(k+2)) ]^(1/(1-theta)).
```

对全消息族 `M={0,1}^k`，`h=k`。因此：

* 若 `s=o(k)`、`Q` 与 `|Sigma|` 固定，
  `N >= k^(1+Omega(theta)) / polylog(k)`；
* 若 `N=k·polylog(k)`，则必须有
  `s >= k-O(k^(1-theta)polylog(k))`。

换言之，在这个明确的 shared-key ACRR 模型中，近线性 proof 与 `o(k)` shared key
不能同时成立。

## 证明

### 1. 同 key codewords 的距离

固定 key `sigma`，取同桶中不同消息 `m,m'`，并选坐标 `i` 使 `m_i != m'_i`。若
`dist(C(m),C(m')) <= rho`，以 `m` 为 target、`z=C(m')` 代入 soundness，得到

```text
p_{sigma,i,m'_i}(C(m')) <= beta.
```

而以 `m'` 的 completeness 得到同一概率至少为 `alpha`，矛盾。故每个 key 桶内的
codewords 两两距离严格大于 `rho`，特别是 `C` 在每个桶内 injective。

### 2. 阈值化得到 relaxed local decoders

令 `theta_0=(alpha+beta)/2`。对 `V_{sigma,i,0}` 和 `V_{sigma,i,1}` 各独立重复
`O((alpha-beta)^(-2))` 次，比较经验接受率；恰有一个超过 `theta_0` 时输出其 bit，
否则输出 `bottom`。

在 `C(m)` 上，正确分支均值至少为 `alpha`，错误分支因 `dist(C(m),C(m))=0` 至多为
`beta`，故以常数概率输出 `m_i`。若 `dist(z,C(m))<=delta<rho`，错误分支仍至多为
`beta`；无论正确分支如何，阈值 decoder 都不会输出错误 bit。因此，对每个固定 key
`sigma`，它是 valid input set

```text
V_sigma = {C(m): kappa(m)=sigma}
```

上的 `Q`-query relaxed local decoder，解码原消息的每个坐标。

### 2a. 坐标揭示后的有限响应 tradeoff

同一结论还覆盖一个坐标揭示后才发送的有限响应模型。假设 verifier 另外接收
`tau in {0,1}^r`，并把 completeness/soundness 改为：正确声明存在某个 `tau` 使
接受率至少为 `alpha`，错误声明对**所有** `tau` 的接受率至多为 `beta`。对每个
`tau` 分别估计两种声明的接受率，并对 `2^r` 个响应取最大值，就得到同样的 relaxed
decoder；其 proof-oracle query complexity 变为

```text
Q_r = O(2^r q_0 (alpha-beta)^(-2)).
```

因此上述主不等式仍成立，只需把 `Q` 换成 `Q_r`。这给出一个明确的交互逃逸账本：
`r=O(1)` 时仍继承固定-query RLDC barrier；`r=O(log k)` 时 locality 已变成
`poly(k)`，DGL 指数相应退化；若响应是未压缩的任意函数，则不存在有限 `r`，该模型
不再提供任何 ACRR/RLDC 结论，必须另证 JK parent closure。

### 3. DGL sample reduction 与共同样本

对固定 `sigma` 和每个坐标 `i`，把上一步的 decoder 看作 DGL 的 relaxed local
algorithm，函数值为 `m_i`，valid inputs 为 `V_sigma`。DGL Theorem 7.7 / Corollary
7.8（或参数化小半径版本）给出 sample-based decoder，单坐标样本数为

```text
S_0 = O(|Sigma|^Q log|Sigma| · N^(1-theta)).
```

DGL 的 sampling stage 只按 proof 坐标独立采样，和被解码的坐标 `i` 及函数标签无关；
因此同一份样本可以复用于桶内全部 `k` 个坐标的 enumeration stage。把每个坐标的
错误率降到 `1/(3k)` 只增加 `O(log(k+2))` 次独立 sample stages。于是存在一个
共同样本全局 decoder，在 `O(S_0 log(k+2))` 个 sampled symbols 上，以至少 `2/3`
概率恢复整个 `m`（对每个 `m` 同时恢复全部坐标）。

### 4. 信息论收尾

在最大桶 `M_sigma` 上均匀取 `m`。样本坐标集合与 `m` 独立，故它本身不携带消息
信息；给定这些坐标，样本 symbol transcript 的熵至多

```text
O(S_0 log_2|Sigma| log(k+2)).
```

全局 decoder 以至少 `2/3` 概率恢复 `m`，由 Fano 不等式

```text
log_2 |M_sigma| <= O(S_0 log_2|Sigma| log(k+2)).
```

代入 `S_0` 得

```text
h_star <= C_D |Sigma|^Q log_2|Sigma| · N^(1-theta) · log_2(k+2).
```

再用 `h_star>=h-s` 即得主不等式。

## 量词边界

* 若 verifier 可以看见完整 `m`，或每个 `(m,i)` 都有独立 verifier，则不能把消息按
  key 分桶；此时定理不适用，且这正是 target-specific hardwiring 逃逸。
* 若 Merlin 在看到 `i` 后才发送任意新响应，响应不属于 key；模型退化为
  `forall i exists tau_i`，不能直接得到同一 global word/parent seed。要把它纳入本
  定理，必须把响应压成坐标揭示前的共同摘要。
* 若 `rho` 小于参数化 DGL 窗口，定理只保留距离/阈值化部分，不能自动给出
  `N^(1-theta)` sample exponent。
* 本定理是 family-level、target-relative 的 barrier；单一 RW/JK 实例没有足够的
  message family 量词时，不能直接调用 `h=k` 的结论。

## 与现有结果的关系

这是 C31 的 key-indexed strengthening：C31 要求同一 verifier 作用于整个消息族，
本定理允许一个短 key 选择 verifier family，然后用最大桶恢复有效消息熵。C54 是本
定理的纯 target-channel 信息端；本定理进一步把每个 key 桶的剩余熵送入 relaxed-LDC
sample lower bound。它不声称一般 near-linear dPCP 必然满足模型，也不把 DGL 的外部
sample theorem 当作本项目原创 lower bound。

## 来源

* [Dall'Agnol--Gur--Lachish, Theorem 7.7 and Corollary 7.9](https://eccc.weizmann.ac.il/report/2020/154/)
* [Gur--Minzer--Weissenberg--Zheng, dPCP/RLDC baseline](https://arxiv.org/abs/2512.12960)
* [C31 radius-to-relaxed-LDC barrier](radius-to-relaxed-ldc-barrier.md)
* [C54 approximate target-channel entropy barrier](../../mcsp-hardness-magnification/notes/195-approximate-target-channel-entropy-barrier-2026-08-16.md)
