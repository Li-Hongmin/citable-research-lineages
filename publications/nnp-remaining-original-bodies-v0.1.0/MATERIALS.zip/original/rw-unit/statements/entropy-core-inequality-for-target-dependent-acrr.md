# Target-dependent ACRR 的熵—完整策略核心不等式

## 定理

令

\[
  C:\mathcal M\hookrightarrow\Sigma^N
\]

是有限消息族的单射 proof map；消息 \(M\) 按任意分布 \(\mu\) 取值。每个目标有一个
descriptor
\[
  \kappa:\mathcal M\to\mathcal D .
\]

以下熵和对数均以 2 为底，并约定 (0log(1/0)=0)。

固定 descriptor \(\sigma\)、坐标 \(i\in[k]\) 和声明 \(b\in\{0,1\}\) 后，验证器
\(V_{\sigma,i,b}\) 使用同一个物理 proof 地址空间 \([N]\)。验证器可以自适应查询
proof；其策略族可以任意大，但对固定 \(N\) 必须由有限时间 bit-model 诱导出有限的
可观察 policy tree。

对每个消息 \(m\) 和坐标 \(i\)，选取一个正确声明的完整策略
\(\pi_{m,i}\)，并令

\[
  K_m=\bigcup_{i\in[k]}
  \operatorname{Supp}\!\left(
    V_{\kappa(m),i,m_i,\pi_{m,i}}
  \right).
\]

约定 \(C(m)|_{K_m}\) 按 \(K_m\) 的递增地址顺序记录。

假设：

1. 对每个 \((m,i)\)，所选策略在 \(C(m)\) 上以概率至少 \(\alpha\) 接受；
2. 对每个 \((m,i)\)，descriptor 相同的错误声明策略（包括任意 policy）在所有
   \(z\) 满足 \(\operatorname{dist}(z,C(m))\le\rho\) 时以概率至多
   \(\beta<\alpha\) 接受。

则映射

\[
  m\longmapsto
  \bigl(\kappa(m),K_m,C(m)|_{K_m}\bigr)
\tag{ECK1}
\]

是单射。特别地，令
\[
  D=\kappa(M),\qquad R=|K_M|,
\]
并令 \(h_2\) 为二元熵函数，则
\[
  H(M)
  \le H(D)+N h_2\!\left(\frac{\mathbb E R}{N}\right)
       +\mathbb E R\,\log_2|\Sigma|.
\tag{ECK2}
\]

当 \(\mathbb E R\le N/2\) 时，
\[
  H(M)-H(D)
  \le \mathbb E R\log_2\!\left(
      \frac{eN|\Sigma|}{\mathbb E R}
    \right).
\tag{ECK3}
\]

对均匀消息族 \(|\mathcal M|=2^h\)，若 descriptor 是固定的 \(s\)-bit 字符串，则
\[
  h-s
  \le N h_2\!\left(\frac{\mathbb E R}{N}\right)
       +\mathbb E R\,\log_2|\Sigma|.
\tag{ECK4}
\]

因此，当 \(|\Sigma|\) 固定、\(N=k^{O(1)}\)、且 \(h-s=\Omega(k)\) 时，
\[
  \mathbb E|K_M|=\Omega\!\left(\frac{k}{\log k}\right).
\tag{ECK5}
\]

这是全局平均结论：不需要先选择最大的 descriptor bucket，也不要求所有消息拥有
相同的 core 大小。

## 证明

先证 (ECK1)。若 \(m\ne m'\) 且 \(\kappa(m)=\kappa(m')\)，取坐标 \(i\) 使
\(m_i\ne m'_i\)。假设
\[
  C(m)|_{K_m}=C(m')|_{K_m}.
\]
所选完整策略 \(\pi_{m,i}\) 的每一条自适应分支都只访问 \(K_m\)，所以在两个 proof
上看到完全相同的 transcript；于是
\[
  p_{\kappa(m),i,m_i,\pi_{m,i}}(C(m'))
  =
  p_{\kappa(m),i,m_i,\pi_{m,i}}(C(m))
  \ge\alpha .
\]
但在目标 \(m'\) 下，\(m_i\) 是错误声明，且 \(C(m')\) 位于其自身的 \(\rho\)-邻域内。
all-policy soundness 给出同一概率至多 \(\beta\)，矛盾。因此同 descriptor 的两个消息
不可能有相同的 core restriction；descriptor 本身又区分不同 descriptor 的消息，
故 (ECK1) 成立。

令
\[
  X=\bigl(D,K_M,C(M)|_{K_M}\bigr).
\]
由 (ECK1)，\(M\mapsto X\) 是单射，因此 \(H(M)=H(X)\)。链式法则和条件熵上界给出
\[
\begin{aligned}
H(M)
 &=H(D)+H(K_M,C(M)|_{K_M}\mid D)\\
 &\le H(D)+H(K_M)
      +H(C(M)|_{K_M}\mid D,K_M)\\
 &\le H(D)+H(K_M)+\mathbb E|K_M|\log_2|\Sigma|.
\end{aligned}
\]

把 \(K_M\) 看成 \([N]\) 的随机子集，令
\(p_j=\Pr[j\in K_M]\)。由子集指示变量的次可加性和二元熵的凹性，
\[
  H(K_M)\le\sum_{j=1}^N h_2(p_j)
  \le N h_2\!\left(\frac{\sum_jp_j}{N}\right)
  =N h_2\!\left(\frac{\mathbb E|K_M|}{N}\right).
\]
这证明 (ECK2)。当 \(r=\mathbb E|K_M|/N\le1/2\) 时，
\(h_2(r)\le r\log_2(e/r)\)，代入即得 (ECK3)。
均匀分布时 \(H(M)=h\)，固定 \(s\)-bit descriptor 时 \(H(D)\le s\)，故得 (ECK4)。

最后，令 \(R=\mathbb E|K_M|\)。若 \(R>N/2\)，结论更强；否则
\[
  h-s\le R\log_2(eN|\Sigma|/R)
  \le R\log_2(eN|\Sigma|).
\]
所以 \(R\ge(h-s)/\log_2(eN|\Sigma|)\)。在
\(h-s=\Omega(k)\)、固定 alphabet、\(N=k^{O(1)}\) 时，这就是 (ECK5)。

## 为什么它比最大桶计数更强

已有的 specifying-core 计数先取一个最大的 descriptor bucket，再对该桶内的 core
大小作尾界。这里直接对目标分布取熵：

* descriptor 不必是固定长度，代价由 \(H(D)\) 计量；
* core 大小可以随目标变化，代价由 \(\mathbb E|K_M|\) 计量；
* 不需要把质量集中到一个最大桶，也不需要假设每个目标的 core 都小。

因此 (ECK2) 是 target-dependent verifier 的全局信息论约束，而 (SPC2)--(SPC6a)
是它在固定 descriptor/尾概率版本中的组合计数特例。

## 与 branch-support / RLDC 二分的合并

对每个 descriptor \(\sigma\)，记所有 finite-time policies 的联合 branch support 为
\(L_\sigma\)。若该 descriptor 桶上的 target-relative soundness 还处于 relaxed-LDC
下界的适用窗口，则 \(L_\sigma\) 受到 branch-support barrier 的限制；若尝试让
descriptor 熵 \(H(D)\) 很小来逃避该限制，(ECK2) 又强制平均 complete-policy core
达到 \(\Omega(k/\log k)\)（在固定 alphabet、近线性 proof 的参数区）。因此一个
高熵、近线性的 target-dependent ACRR 至少必须支付以下三项之一：

1. descriptor 本身携带近乎全部目标熵；
2. 完整策略在平均意义上暴露 \(\Omega(k/\log k)\) 个物理地址；
3. 所有策略的联合 branch support 离开 RLDC/DGL 的低局部性窗口，或改变
   target-relative/all-policy 量词。

这是一条支持—核心—descriptor 三难；它不声称覆盖独立 proof oracle、只对选定策略
成立的 soundness、zero-radius/codeword-only 语义，或真正无界/连续的信息模型。

## 边界与反例

* 若每个目标使用独立 proof 地址空间，则不同目标之间没有共同 restriction，(ECK1)
  不成立；这正是必须显式标记的 escape。
* 若错误 soundness 只对目标自己的 selected policy 成立，完整策略不能被搬到另一个
  同 descriptor 目标，核心论证失效。
* 若 verifier 可以读取 descriptor 之外的完整 target，目标信息已被放进 \(D\)，此时
  (ECK2) 只会把相应熵计入 \(H(D)\)，不能把它误称为短 shared key。
* 单一固定目标 \(|\mathcal M|=1\) 时 \(H(M)=0\)，定理不会虚构 family-level
  lower bound；这正是 RW 单目标路线仍需额外 family lifting 的原因。

## 与现有模块的关系

* [Finite-time policy specifying-core barrier](finite-time-policy-specifying-core-barrier.md)
  给出同一现象的最大桶与尾界版本；本定理把它提升为全局熵不等式。
* [Branch-support barrier](strategy-support-acrr-rldc-barrier.md) 处理联合所有策略
  的查询局部性；本定理只使用每个目标的完整策略，因而是互补而非替代。
* [Sim-CR strategy-compression trilemma](strategy-compression-trilemma-for-simcr.md)
  的 descriptor 熵项可直接用 \(H(D)\) 替换固定 \(s\)-bit key。

## 证据边界

证明只使用有限时间自适应 transcript 的 indistinguishability、熵链式法则和二元熵
凹性，因而是自足的 derived theorem。它不是对所有 dPCP、所有单目标 RW/JK 实例或
所有 target-dependent verifier 的无条件不可能性定理；要进入 ACRR 主线，仍需把
descriptor/branch-support 的量词与具体 RW/JK 或 PCP 构造逐项对齐。
