# Global-word distributional soundness yields an indexed list channel

## Theorem

Let \(\Gamma\) be a finite alphabet and let \(L\ge2\). Let

\[
  Y=\{y^{(1)},\ldots,y^{(L)}\}\subseteq\Gamma^M
\]

be a known family of candidate words whose pairwise relative Hamming distance is at least
\(\Delta>0\):

\[
  \operatorname{dist}(y^{(s)},y^{(t)})\ge\Delta
  \qquad(s\ne t).
\tag{GDI1}
\]

For every coordinate \(j\in[M]\), let \(D_j\) be a randomized adaptive decoder making at
most \(q\) queries to one common proof oracle \(z\in\Sigma^N\). Its output lies in
\(\Gamma\cup\{\bot\}\), where \(\bot\) counts as an error against every symbol in \(\Gamma\).
For a fixed proof \(z\), write \(D_J(z)\) for the experiment that samples \(J\) uniformly
from \([M]\), then runs \(D_J\) with fresh private randomness.

Assume the following **global-word distributional soundness**:

\[
  \forall z\quad \exists s(z)\in[L]\quad
  \Pr[D_J(z)\ne y^{(s(z))}_J]\le\varepsilon,
\tag{GDI2}
\]

where \(0\le\varepsilon<\Delta/2\). Then, for every failure probability
\(\eta\in(0,1)\), there is a target-independent adaptive index decoder \(\mathsf{Idx}\) using

\[
  r=\left\lceil
      \frac{2\log((L-1)/\eta)}{(\Delta-2\varepsilon)^2}
    \right\rceil
\tag{GDI3}
\]

independent coordinate samples and at most

\[
  rq
  =O\!\left(
      q\,\frac{\log(L/\eta)}{(\Delta-2\varepsilon)^2}
    \right)
\tag{GDI4}
\]

proof queries, such that

\[
  \Pr[\mathsf{Idx}^{z}=s(z)]\ge1-\eta.
\tag{GDI5}
\]

This is the adaptive query count. If a nonadaptive RLDC theorem is to be applied, let
\[
  T_q(A):=\sum_{t=0}^{q-1}A^t,\qquad A:=|\Sigma|.
\tag{GDI5a}
\]
Exposing the \(A\)-ary decision tree of each sampled call gives a nonadaptive decoder with
at most \(rT_q(A)\) proof queries. When the \(D_j\) are already nonadaptive, \(T_q(A)\) is
replaced by \(q\).

The decoder is uniform given the finite family \(Y\): it samples
\((J_1,\ldots,J_r)\) independently, records \(a_\ell=D_{J_\ell}(z)\), and returns the unique
index maximizing

\[
  \operatorname{score}_t
  =\frac1r\sum_{\ell=1}^r
       \mathbf 1[a_\ell=y^{(t)}_{J_\ell}],
\tag{GDI6}
\]

returning \(\bot\) on a tie.

### Target-relative code corollary

Suppose in addition that \(\Pi:[L]\hookrightarrow\Sigma^N\) is a common-address proof map,
the honest proof \(\Pi(s)\) satisfies

\[
  D_j(\Pi(s))=y^{(s)}_j
  \quad\text{with probability }1
  \qquad(j\in[M]),
\tag{GDI7}
\]

and the stronger target-relative version of (GDI2) holds:

\[
  \operatorname{dist}(z,\Pi(s))\le\rho
  \quad\Longrightarrow\quad
  \Pr[D_J(z)\ne y^{(s)}_J]\le\varepsilon.
\tag{GDI8}
\]

Then \(\mathsf{Idx}\) is a weak relaxed local decoder for the index \(s\), with radius
\(\rho\), completeness at least \(1-\eta\), wrong-index probability at most \(\eta\), and
adaptive locality (GDI4). After decision-tree exposure it has nonadaptive locality
\(rT_q(|\Sigma|)\). If perfect completeness is required, an exhaustive scan of all \(M\)
coordinates gives it at locality \(Mq\); the logarithmic sampler is the bounded-error version.
Moreover, if \(\varepsilon<\Delta/2\), distinct proof words satisfy

\[
  \operatorname{dist}(\Pi(s),\Pi(t))>\rho
  \qquad(s\ne t).
\tag{GDI9}
\]

Thus a global-word distributional theorem plus separated candidate words already enters the
indexed-label/RLDC barrier. It does not require the original local decoder to output an index;
the relevant nonadaptive barrier must use \(rT_q(|\Sigma|)\) when the base decoder is adaptive.

## Proof

Fix a proof \(z\) and let \(s=s(z)\) be supplied by (GDI2). For one independent sample
\((J,a)=(J,D_J(z))\), define, for \(t\ne s\),

\[
  X=\mathbf 1[a=y^{(s)}_J],
  \qquad
  X_t=\mathbf 1[a=y^{(t)}_J].
\]

The global error hypothesis gives

\[
  \mathbb E[X]\ge1-\varepsilon.
\tag{GDI10}
\]

Let \(B_{s,t}=\{j:y^{(s)}_j\ne y^{(t)}_j\}\). By (GDI1),
\(|B_{s,t}|/M\ge\Delta\). On \(J\in B_{s,t}\), the event \(X_t=1\) implies
\(X=0\); outside \(B_{s,t}\), \(X_t\le1\). Hence

\[
  \mathbb E[X_t]
  \le 1-\Delta+\varepsilon,
  \qquad
  \mathbb E[X-X_t]\ge\Delta-2\varepsilon.
\tag{GDI11}
\]

For the \(r\) independent samples, set \(Z_\ell=X_\ell-X_{t,\ell}\in[-1,1]\). Hoeffding's
inequality gives

\[
  \Pr[\operatorname{score}_t\ge\operatorname{score}_s]
  =\Pr\left[\frac1r\sum_{\ell=1}^r Z_\ell\le0\right]
  \le \exp\!\left(-\frac{r(\Delta-2\varepsilon)^2}{2}\right).
\tag{GDI12}
\]

The choice (GDI3) makes the union bound over \(t\ne s\) at most \(\eta\), proving (GDI5).
Every sample invokes one \(q\)-query decoder, so the adaptive bound (GDI4) follows.
For a fixed random tape, the adaptive execution is an \(A\)-ary tree with at most
\(T_q(A)\) internal query nodes. Taking the union of these nodes over the \(r\) sampled
coordinates gives the nonadaptive bound in (GDI5a); the query-set distribution may still
depend on the random tape, as allowed for a nonadaptive relaxed local decoder.

Under (GDI7)--(GDI8), the distinguished word in (GDI2) is the target word \(y^{(s)}\) for
every \(\rho\)-near proof of \(\Pi(s)\). Therefore the same index decoder outputs \(s\) with
probability at least \(1-\eta\) throughout that ball. For (GDI9), suppose instead that
\(\operatorname{dist}(\Pi(s),\Pi(t))\le\rho\) for \(s\ne t\). Applying (GDI8) to target \(s\)
and \(z=\Pi(t)\), while using (GDI7) for \(t\), yields a contradiction because the decoded
word \(y^{(t)}\) differs from \(y^{(s)}\) on at least a \(\Delta\)-fraction of coordinates,
whereas the two corresponding distributional errors would be at most \(\varepsilon\).
\(\square\)

## What this adds to the distributional-soundness route

The theorem separates two notions that are often conflated:

* ordinary dPCP list soundness says that, at each sampled coordinate, the decoded symbol is
  compatible with **some** word in a list;
* (GDI2) says that one fixed global word explains almost all sampled coordinates of the same
  proof.

The first condition does not imply the second: coordinatewise choices can form a phantom word.
The second condition, together with (GDI1), is enough to synthesize a common index channel by
random coordinate sampling. This is a positive bridge toward the indexed-list compiler, but it
is not yet ACRR: a separate target-binding predicate is still needed to force the distinguished
index to be the intended target rather than merely the word closest to the candidate proof.

For a known valid-word family of size \(L\), the cost is logarithmic in \(L\) and quadratic in
the inverse separation gap. If \(L=k^{\Theta(1)}\), \(\Delta-2\varepsilon=\Theta(1)\), and
\(q=O(1)\), the bridge uses \(O(\log k)\) local queries, after which the robust indexed-label
and q-ary RLDC barriers apply. Conversely, a claimed constant-query construction must either
keep \(L=O(1)\), make the global word unknown/non-enumerable, let \(\varepsilon\uparrow\Delta/2\),
or abandon the common proof address space.

## Scope and non-implications

This is a conditional distribution-to-index theorem, not a claim about the current GMWZ
dPCP. Their ordinary list-decoding guarantee is coordinatewise and does not provide (GDI2),
nor does it give a separated, known candidate family for a general computation relation.
“Known” is an information/locality assumption here; the finite family may be too large to
enumerate efficiently, and no efficient candidate-family table is claimed.
The theorem also does not solve target binding, history compression, or the RW/JK parent-closure
condition. Its value is to turn a successful global-word distributional construction into an
explicit indexed channel whose locality can be charged immediately.

## Relation to existing modules

* [Weighted distributional-to-coordinate barrier](distributional-to-coordinate-weight-barrier.md)
  shows why a scalar average bound is insufficient; (GDI2) is the stronger global-word input.
* [Indexed-label locality barrier](indexed-label-locality-barrier.md) charges a direct indexed
  label channel; this theorem constructs one from global-word proximity and separation.
* [Indexed-list selector compiler](../../mcsp-hardness-magnification/papers/Address-Scale-Barriers-for-Shared-Proof-Coordinate-Robustness/paper.md)
  supplies the remaining target-binding composition once an indexed list is available.
* [Exchangeable approximate-index bridge](exchangeable-approximate-index-rldc-bridge.md)
  gives a different route from approximate index errors; (GDI2) avoids assuming exchangeability
  by sampling a globally separated word.

The proof is elementary and self-contained; all novelty lies in isolating the exact global-word
condition that a distributional-soundness construction must supply before index/ACRR machinery
can begin.
