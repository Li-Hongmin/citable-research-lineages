# Message-inline RLDC compiler for Sim-CR

## Theorem

Let

\[
  \Pi:\{0,1\}^{k}\longrightarrow\{0,1\}^{P}
\]

be a binary global-proof map. For every message coordinate `i` and claimed bit `b`, let
`V_{i,b}` be a randomized verifier that makes at most `q` adaptive queries to a proof oracle.
Write

\[
  p_{i,b}(z)=\Pr[V_{i,b}^{z}=1].
\]

Assume that there are `rho>0` and `alpha>beta` such that, for every message `m`:

1. **Same-proof completeness:**
   `p_{i,m_i}(Pi(m)) >= alpha` for every `i`.
2. **Target-relative wrong-bit soundness:** whenever
   `dist(z,Pi(m)) <= rho`,
   `p_{i,1-m_i}(z) <= beta` for every `i`.

Define the message-inline code

\[
  C(m)=m\,\|\,\Pi(m)\in\{0,1\}^{N},
  \qquad N=k+P.
\]

Then:

* `C` has relative distance strictly larger than `rho P/(k+P)`;
* for every `delta < rho P/(k+P)`, `C` has a weak adaptive
  `(q+1,delta,alpha,beta)` relaxed local decoder;
* the decoder on oracle `y` and requested coordinate `i` reads `y_i`, sets `b=y_i`,
  simulates `V_{i,b}` on the proof suffix of `y`, and outputs `b` exactly when that
  simulation accepts, otherwise `bottom`.

Consequently, if `alpha` is a fixed completeness constant above `1/2`, `beta<1/2`,
`rho=Omega(1)`, and `P=Omega(k)`, then any binary Sim-CR family with constant `q` inherits
the corresponding constant-radius RLDC lower bound. In the special case `q=1`, perfect
completeness, and binary proof alphabet, the result is a binary weak adaptive 2-query RLDC;
the exponential lower bound of Block--Blocki--Cheng--Grigorescu--Li--Zheng--Zhu therefore
forces

\[
  k+P \ge 2^{\Omega_{\rho,\beta}(k)}.
\]

No projection assumption is used.

**Relation to the proof-only compiler.** Under the same target-relative soundness
quantifiers, one may run both claim branches and decode directly from \(\Pi(m)\), without
the inline message prefix; see [Radius-to-relaxed-LDC barrier](radius-to-relaxed-ldc-barrier.md).
The present statement keeps the inline form because it is useful for query-elimination and
nonadaptive parameter bridges, not because the prefix is needed for the basic RLDC reduction.

In the binary family-level, target-relative model, the separate \(P=\Omega(k)\) hypothesis
for a fixed positive proof radius is automatic: pairwise proof distance follows from the
same-proof quantifiers, and the general Singleton bound supplies the linear proof-length
lower bound. See [Message-inline Singleton barrier](message-inline-singleton-barrier.md).

### Near-linear corollary for every fixed finite alphabet

For a fixed finite proof alphabet `Sigma`, the block encoding below changes the locality to

```text
Q = q * ceil(log_2 |Sigma|) + 1
```

and preserves a positive constant radius when `rho=Omega(1)` and `P=Omega(k)`. Hence, for
fixed `|Sigma|`, fixed `q`, and a fixed completeness/soundness gap, the adaptive
relaxed-LDC lower bound gives a constant `epsilon_Q>0` with

```text
N = k + ceil(log_2 |Sigma|) P >= k^(1+epsilon_Q).
```

Thus `q>=2` and nonbinary alphabets are not escapes from the **near-linear** family-level
ACRR barrier; they only escape the sharper binary 2-query exponential theorem. Any claimed
near-linear construction in this regime must therefore abandon at least one of the following:
family-level target-relative soundness, positive radius, fixed finite alphabet, or constant
query complexity. The remaining open question is whether additional structure can strengthen
the generic superlinear bound to an exponential or otherwise new coding lower bound.

## Proof

First compare two distinct messages `m != m'`. Choose `i` with `m_i != m'_i`. If
`dist(Pi(m),Pi(m')) <= rho`, use `m` as the target and `z=Pi(m')` in wrong-bit soundness:

\[
  p_{i,m'_i}(\Pi(m'))\le\beta.
\]

Completeness for target `m'` gives the same quantity at least `alpha`, a contradiction.
Thus every pair of distinct proof strings differs in more than `rho P` positions. Since
the message prefixes can only add distance, the inline code has relative distance strictly
larger than `rho P/(k+P)`.

Now let `y` be within relative distance `delta<rho P/(k+P)` of `C(m)`. The proof suffix of
`y` differs from `Pi(m)` in at most `delta(k+P)<rho P` positions. If `y_i=1-m_i`, the
decoder invokes the wrong verifier and its acceptance probability is at most `beta`; an
acceptance therefore produces a wrong output only with probability at most `beta`. If
`y_i=m_i`, the decoder can output only the correct bit or `bottom`. On the uncorrupted
codeword, `y_i=m_i` and completeness gives correct output probability at least `alpha`.
The decoder makes one query to the inline message bit and at most `q` proof queries, so its
query complexity is `q+1`.

## Scope and consequences

This theorem is a compiler from a **family-level, target-relative** Sim-CR interface. It does
not apply to a single target instance whose verifier is allowed to hardwire the target in a
way that cannot be organized into a message family. It also does not turn ordinary average or
list-decoding soundness into target-relative soundness.

The theorem closes a specific escape that is narrower than the full ACRR problem but broader
than the binary-projection argument: binary, non-projection, one-proof, one-query Sim-CR is
already subject to the binary 2-query RLDC exponential barrier. For `q>=2`, the compiler gives
`q+1`-query RLDC and hence the general finite-query relaxed-LDC lower-bound entry point; it
does not claim an exponential bound in that regime.

### Fixed finite alphabets

The same construction has an explicit alphabet conversion. Let `Sigma` be finite and let
`e:Sigma -> {0,1}^ell` be an injective fixed encoding. Replace the proof suffix by the
concatenation of the `ell`-bit symbol blocks. The inline decoder reads one message bit and all
`ell` bits for each of the at most `q` proof symbols requested by `V_{i,b}`. An invalid block
causes `bottom`; otherwise the parsed symbol oracle is within relative distance `rho` whenever
the binary inline word is within `rho P/(k+ell P)` of its codeword. Hence the resulting binary
RLDC has `q*ell+1` queries and radius `rho P/(k+ell P)`. For fixed `|Sigma|`, constant `q`,
positive `rho`, and `P=Omega(k)`, this still gives a constant-query, positive-radius binary
RLDC and therefore the general relaxed-LDC lower-bound entry point. For fixed `Sigma`, the
q-ary Singleton bound in [Message-inline Singleton barrier](message-inline-singleton-barrier.md)
supplies `P=Omega(k)` automatically under the family-level target-relative quantifiers.
Only the special
`ell=1,q=1` case invokes the known exponential 2-query theorem directly.

## Sources

* [Block et al., Exponential Lower Bounds for 2-query RLDCs](https://arxiv.org/html/2602.20278)
* [Radius-to-relaxed-LDC barrier](radius-to-relaxed-ldc-barrier.md)
* [Sim-CR to singleton PCPP query boundary](../../mcsp-hardness-magnification/notes/197-simcr-to-singleton-pcpp-query-elimination-boundary-2026-08-16.md)
