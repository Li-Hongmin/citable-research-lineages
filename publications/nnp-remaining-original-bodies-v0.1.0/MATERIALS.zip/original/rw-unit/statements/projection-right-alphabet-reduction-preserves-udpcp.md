# Projection right-alphabet reduction preserves unique decoding

## Theorem

Let \(\mathcal D\) be a projection dPCP with left vertices \(A\), right vertices \(B\),
edge distribution \(\mu\), and decoding distribution \(\mathcal Q\). For every edge
\((a,b)\), write

```text
sigma_{a->b}(alpha) in Sigma_B
```

for the unique right symbol that satisfies the projection constraint with the left label
`alpha`. We assume the projection is total on the allowed left alphabet; an invalid left
label is treated as an automatic violation (the same bookkeeping only strengthens the bound
below). Assume that \(\mathcal D\) has unique-decoding soundness with parameters
\((\epsilon_{\rm sat},\eta_u)\): every assignment satisfying at least
`1-epsilon_sat` of the \(\mu\)-mass of constraints has a word \(w\in\mathcal L\) such that

```text
Pr_{(t,a,b)~Q}[D_t(a,T_A[a]) != w_t] <= eta_u.
```

Let \(C:\Sigma_B\to\Omega^m\) have relative Hamming distance at least
\(\delta_C>0\). Form the usual right-alphabet reduction: replace each \(b\) by
\((b,i)\), \(i\in[m]\), and replace the edge constraint by

```text
T'_B[b,i] = C(sigma_{a->b}(T_A[a]))_i.
```

The new satisfaction distribution samples \((a,b)\sim\mu\) and then \(i\) uniformly.
The decoding maps and their marginal distribution on \((t,a,b)\) are unchanged.

Then the reduced dPCP has unique-decoding soundness

```text
epsilon'_sat = delta_C * epsilon_sat / 2,
eta'_u = eta_u.
```

In particular, a near-satisfying reduced assignment is explained by one global word; the
alphabet reduction does not create a coordinatewise phantom word. Perfect completeness is
preserved, and the proof/constraint overhead is the usual factor \(m=O(\log|\Sigma_B|)\).

## Proof

Fix an arbitrary reduced assignment \((T_A,T'_B)\). For each right vertex \(b\) with
positive \(\mu\)-mass, let \(p_b\) be the distribution of the projected symbols
\(\sigma_{a\to b}(T_A[a])\) when the incident edge is sampled from \(\mu\) conditioned on
\(b\). Let \(y_b=(T'_B[b,1],\ldots,T'_B[b,m])\), and define

```text
d_b = E_{sigma~p_b}[ dist(y_b, C(sigma)) ].
```

The reduced constraint-violation rate is exactly

```text
epsilon' = E_b[d_b].
```

We use the following elementary concentration lemma. For any distribution \(p\) on
\(\Sigma_B\), any \(y\in\Omega^m\), and any code of relative distance \(\delta_C\),

```text
1 - max_sigma p(sigma)
    <= (2/delta_C) E_{sigma~p}[dist(y,C(sigma))].       (1)
```

To prove (1), let \(\sigma_\star\) maximize \(p\). If \(p(\sigma_\star)\ge1/2\), the
triangle inequality gives

```text
dist(y,C(sigma)) >= delta_C - dist(y,C(sigma_star))
```

for every \(\sigma\ne\sigma_\star\), and hence the average distance is at least
\(\delta_C(1-p(\sigma_\star))\). If \(p(\sigma_\star)<1/2\), at most one codeword can be
at distance less than \(\delta_C/2\) from \(y\). Therefore the average distance is at least
\(\delta_C(1-p(\sigma_\star))/2\), proving (1).

Define a base right assignment \(\widehat T_B[b]\) to be a maximizer of \(p_b\). By (1),
the base constraint-violation rate is at most

```text
Pr_{(a,b)~mu}[sigma_{a->b}(T_A[a]) != widehat T_B[b]]
    <= (2/delta_C) E_b[d_b]
    =  (2/delta_C) epsilon'.                         (2)
```

If \(\epsilon'\le\delta_C\epsilon_{\rm sat}/2\), (2) is at most
\(\epsilon_{\rm sat}\). The unique-decoding hypothesis for \(\mathcal D\) therefore supplies
one word \(w\in\mathcal L\) with decoding error at most \(\eta_u\). Since the reduced decoder
uses the same left assignment and the same marginal decoding distribution, it has exactly
the same decoded word and error. This proves the claimed parameters.

For perfect completeness, start from a satisfying base assignment \((T_A,T_B)\) and set
\(T'_B[b,i]=C(T_B[b])_i\). Every lifted constraint is then satisfied, and the decoder is
unchanged.

## Consequence for the current composition program

This theorem changes the location of the suspected loss. The right-alphabet reduction
itself is not an inherent obstruction to unique decoding: it preserves the property whenever
the incoming projection dPCP already has unique decoding. The loss in a list-only final
theorem must therefore occur earlier, at a stage that supplies only list soundness, or at a
composition that fails to preserve a single near-satisfying right assignment.

The statement is stronger than the list-only analysis needed for the usual reduction, but it
does not claim that the GMWZ full pipeline has unique decoding. Their right-alphabet reduction
is stated for list soundness because that is the property available at that point. The new
research target is consequently precise: track unique decoding through the preceding
gap-amplification, routing, and composition steps; if it survives to this projection stage,
the alphabet reduction need not be the barrier.

## Scope and boundary

Projection is essential. If an edge admits several right symbols, the distribution \(p_b\) no
longer records a canonical projected symbol and the proof does not apply. Invalid left labels
can be included by adding their edge mass to both violation rates; the displayed bound remains
valid because \(\delta_C\le1\). The theorem also
does not turn an arbitrary list guarantee into unique decoding: it assumes the stronger base
unique-decoding statement before the reduction. Finally, the factor \(2/\delta_C\) is a
genuine threshold loss; it must be absorbed in the base soundness gap.

## Source and status

The construction is the standard right-alphabet reduction used in
[Gur--Minzer--Weissenberg--Zheng, Lemma 7.1](https://arxiv.org/html/2512.12960), where the
published argument tracks list-decoding soundness. The unique-decoding preservation above is
a separate consequence proved here from projection and code distance; it is not attributed to
that lemma or claimed as a theorem of the cited paper.
