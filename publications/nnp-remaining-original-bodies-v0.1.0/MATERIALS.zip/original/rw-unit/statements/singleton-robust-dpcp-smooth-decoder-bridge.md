# Singleton robust dPCP plus a smooth outer decoder gives ACRR

## Theorem

Fix an instance `x` and a deterministic output word `f_x\in\{0,1\}^k`. Let

\[
  C:\{0,1\}^{k}\longrightarrow\Gamma^{M},
  \qquad y_x=C(f_x).
\]

Assume a single global dPCP proof address space with the following local interface. For
each codeword coordinate `j\in[M]`, a local call `L_j` uses at most `q_P` proof queries and
returns either `\mathsf{reject}`, `\bot`, or a symbol in `\Gamma`.

### Singleton robust soundness profile

There is an honest proof `\Pi_x` such that, for every `j`, `L_j(\Pi_x)` returns `y_x[j]`
with probability one. For every candidate proof `\Pi`, define

\[
 e_j(\Pi)=\Pr[L_j(\Pi)\text{ returns a symbol different from }y_x[j]],
\]

where `\mathsf{reject}` and `\bot` are not counted as errors. Assume the average robust
bound

\[
  \frac1M\sum_{j=1}^{M}e_j(\Pi)\le\varepsilon
  \qquad\text{for every candidate }\Pi.
\tag{1}
\]

This is a singleton-output version of robust distributional soundness: the same target
codeword `y_x` is used for every coordinate and every candidate proof.

### Smooth outer decoder

For each message coordinate `i`, let `D_i` be an adaptive randomized decoder for `C` that
makes at most `q_D` codeword queries and outputs a bit. It has perfect completeness,

\[
  D_i^{y_x}=f_x[i] \quad\text{with probability one},
\tag{2}
\]

and its honest-answer query path is `\lambda`-smooth: at every query step `t` and every
codeword position `j`, conditioned on all previous answers being the honest symbols,

\[
  \Pr[\text{the }t\text{-th query is }j]\le\frac{\lambda}{M}.
\tag{3}
\]

Then for every declaration `b\in\{0,1\}` there is a verifier `Q_{x,i,b}` using the same
global proof `\Pi` and the same address space, with total proof-query complexity at most
`q_Pq_D`, such that:

* `Q_{x,i,f_x[i]}` accepts `\Pi_x` with probability one;
* for every candidate proof `\Pi` and every wrong declaration `b\ne f_x[i]`,
  \[
    \Pr[Q_{x,i,b}(\Pi)=1]\le q_D\lambda\varepsilon.
  \tag{4}
  \]

In particular, if `q_D\lambda\varepsilon<1/2`, the family of verifiers is
simultaneous coordinate-robust in the same proof address space. The construction is
uniform whenever the local dPCP calls and the outer decoder are uniformly generable.

## Construction and proof

To answer a query of `D_i`, run the corresponding local call `L_j` with fresh randomness.
If it rejects or returns `\bot`, abort and output `\bot`; otherwise feed the returned symbol
to `D_i`. At the end accept the declaration `b` exactly when the decoder output is `b`.

Completeness follows immediately from (2) and the perfect local behavior of `\Pi_x`.

For soundness, fix a candidate proof `\Pi` and a wrong bit `b\ne f_x[i]`. If no local call
returns a wrong symbol, every answer supplied to `D_i` is the honest codeword symbol, so
(2) forces the decoder output to be `f_x[i]`, and the verifier cannot accept `b`. Hence an
accepting execution must contain a first local wrong-symbol event.

Before that first event, all answers seen by `D_i` are honest. Therefore (3) applies to the
position queried at that step. For any step `t`, the probability that the honest path asks
position `j` is at most `\lambda/M`; conditioned on that position, the fresh local call is
wrong with probability `e_j(\Pi)`. A union bound over the at most `q_D` steps gives

\[
\begin{aligned}
 \Pr[Q_{x,i,b}(\Pi)=1]
 &\le \sum_{t=1}^{q_D}\sum_{j=1}^{M}\frac{\lambda}{M}e_j(\Pi)\\
 &\le q_D\lambda\varepsilon,
\end{aligned}
\]

which proves (4). Adaptivity causes no extra term because the first bad event is preceded by
an honest transcript.

## What this does and does not prove

This theorem gives a precise positive answer to a restricted version of the
“distributional soundness to coordinate robustness” question. Average robust soundness is
enough once three additional facts are present: a singleton target word, a common proof
address space, and a smooth outer decoder. It does not claim that ordinary list-decoding
soundness supplies (1), nor that a standard dPCP for a relation with many valid outputs has
a singleton target word.

The theorem also leaves the main RW bottleneck intact. The global proof may still expose the
full computation history, and the code `C` may have superlinear length or a decoder whose
smoothness parameter is too large. Thus the result is a bridge theorem, not yet a succinct
ACRR construction. Its value is that it isolates the remaining targets quantitatively:

\[
  q_D\lambda\varepsilon<1/2,
  \qquad
  \text{short common proof/address description},
  \qquad
  \text{singleton target binding}.
\]

If the first inequality cannot be achieved with a near-linear code, the obstruction is now
an explicit smoothness/error tradeoff rather than an informal appeal to “average versus
coordinate” soundness.

## Parameter audit for the current 3-query RLDC construction

The construction of Gur--Minzer--Weissenberg--Zheng is an instructive stress test for the
bridge. In their displayed code construction, the global codeword is split into blocks of
sizes

\[
  |I_1|=2Kk,\qquad |I_2|=Kk,\qquad |I_3|=Kk,
\]

so the total length is `M=4Kk`. For a fixed message coordinate `i`, the decoder samples
from the `i`-th PCPP block, whose relevant `B`-part has length `K` (up to the paper's
negligible alignment/discretization slack). Consequently, the global smoothness parameter
of this per-coordinate decoder cannot be smaller than

\[
  \lambda \ge (1-o(1))\frac{M}{K}=(4-o(1))k.
\tag{5}
\]

This is simply the pigeonhole principle: a distribution supported on `K` positions has a
position of probability at least `1/K`, whereas global `\lambda`-smoothness allows at most
`\lambda/M` per position. Thus the bridge's sufficient condition for this architecture
requires

\[
  \varepsilon=O(1/k)
\tag{6}
\]

when `q_D=3`. The published 3-query RLDC theorem fixes constant soundness/radius parameters;
its dPCP theorem explicitly hides the dependence of the alphabet and logarithmic exponent on
the chosen soundness parameter. Therefore the theorem does not certify that setting
`\varepsilon=1/k` preserves the near-quadratic, constant-parameter regime. This is a
black-box parameter obstruction, not a lower bound against the RLDC construction itself:
escaping it requires a globally mixing outer decoder, a stronger-than-average source error
profile, or a different composition.

## Sources and relation to existing modules

* The robust dPCP notion and its average agreement formulation are in
  [Gur--Minzer--Weissenberg--Zheng, TR25-217](https://eccc.weizmann.ac.il/report/2025/217/),
  Appendix A, Definition A.3.
* The singleton-output requirement and its distinction from ordinary distributional
  soundness are discussed in [note 175](../../mcsp-hardness-magnification/notes/175-singleton-output-distributional-soundness-bridge-2026-08-16.md).
* The exposed-history strong-LTC/RLDC baseline is in
  [note 183](../../mcsp-hardness-magnification/notes/183-exposed-history-pcpp-rldc-baseline-2026-08-16.md).
* The theorem is a new composition lemma for this project; it does not claim that the
  cited dPCP construction already supplies the singleton target or the RW address scale.
