# Equivariant address actions do not imply exchangeable index errors

## Theorem (equivariant error-profile invariance)

Let a finite group \(G\) act on a message family \(M\subseteq\{0,1\}^{\ell}\) by
coordinate permutations and on a proof space \(Z\) by Hamming isometries. Let \(I\) be a
target-independent randomized decoder with output in
\(\{0,1\}^{\ell}\cup\{\bot\}\). For target \(s\in M\), proof word \(z\in Z\), and coordinate
\(i\), define its wrong-bit profile

\[
  p_{s,z}(i)=
  \Pr\bigl[I(z)\neq\bot\ \land\ I(z)_i\neq s_i\bigr].
\]

Assume the profile is equivariant:

\[
  p_{g\cdot s,\,g\cdot z}(g i)=p_{s,z}(i)
  \qquad(g\in G).
\]

For any public distribution \(\mathcal D\) on \(G\), form

\[
  J_{\mathcal D}(z)=g^{-1}\!\cdot I(g\!\cdot z),
  \qquad g\leftarrow\mathcal D.
\]

Then the wrapper has exactly the same wrong-bit profile:

\[
  p^{J_{\mathcal D}}_{s,z}(i)=p_{s,z}(i)
  \qquad(s,z,i).
\]

More generally, if the equivariance identity holds up to additive error \(\xi\) uniformly
over \(s,z,i,g\), then

\[
  \bigl|p^{J_{\mathcal D}}_{s,z}(i)-p_{s,z}(i)\bigr|\le\xi.
\]

Thus public address randomization cannot repair a non-exchangeable error profile when that
profile is itself equivariant. Any successful symmetrization theorem must break this
equivariance, or prove a stronger target-independent error law before averaging.

### Proof

Under the coordinate-permutation action, the event
\((g^{-1}\!\cdot I(g\!\cdot z))_i\neq s_i\) is exactly the event
\(I(g\!\cdot z)_{g i}\neq(g\!\cdot s)_{g i}\), with the same non-\(\bot\) condition. Therefore

\[
  p^{J_{\mathcal D}}_{s,z}(i)
  =\mathbb E_{g\sim\mathcal D}
    \bigl[p_{g\cdot s,\,g\cdot z}(g i)\bigr].
\]

The exact and approximate conclusions follow immediately.

The one-coordinate selector lemma below is the special case in which the equivariant
profile is concentrated on the graph of a covariant selector \(c(s)\).

## Weighted minimax obstruction for public symmetrization

The preceding theorem has a useful converse-free certificate that does not assume exact
equivariance. Let \(\mathcal Q\) be any finite set of target/proof pairs and let
\(\lambda_{s,z,i}\ge 0\) be weights on \((s,z,i)\in\mathcal Q\times[\ell]\). Put
\(\Lambda=\sum_{s,z,i}\lambda_{s,z,i}>0\), and define

\[
  A_g(\lambda)=
  \sum_{s,z,i}\lambda_{s,z,i}\,
  p_{g\cdot s,\,g\cdot z}(g i).
\]

If, for some \(\beta\) and \(\xi>0\),

\[
  \min_{g\in G}A_g(\lambda)\ge(\beta+\xi)\Lambda,
\]

then no public distribution \(\mathcal D\) on \(G\) can make
\(p^{J_{\mathcal D}}_{s,z}(i)\le\beta\) for every \((s,z,i)\) in the support of
\(\lambda\). In fact,

\[
  \sum_{s,z,i}\lambda_{s,z,i}
  p^{J_{\mathcal D}}_{s,z}(i)
  =\mathbb E_{g\sim\mathcal D}A_g(\lambda)
  \ge(\beta+\xi)\Lambda,
\]

so at least one weighted coordinate remains above \(\beta\). The exact-profile theorem is
the case in which \(A_g(\lambda)\) is independent of \(g\). This certificate is a finite
linear/minimax test for whether a proposed public address randomization can possibly
produce coordinate robustness.

## Lemma (covariant one-coordinate errors survive public symmetrization)

Let a finite group G act on the message family M by coordinate permutations of
{0,1}^ell, and by Hamming isometries on the proof space. Suppose the proof family is
equivariant:

\[
  g\cdot \Pi^{(s)}=\Pi^{(g\cdot s)}.
\]

Let c : M -> [ell] be a covariant exceptional-coordinate selector,
selector c(g · s)=g(c(s)). Assume that, on every rho-near word for Pi(s), a
target-independent decoder I outputs s with probability alpha, and s XOR e_c(s) with
probability 1-alpha. For any public distribution D on G, form the wrapper

\[
  J(z)=g^{-1}\!\cdot I(g\cdot z),\qquad g\leftarrow\mathcal D.
\]

Then on every rho-near word for Pi(s), the wrapper's bad branch still flips the fixed
coordinate c(s), independently of D. Consequently its normalized expected index error is
(1-alpha)/ell, but the error probability at coordinate j=c(s) is 1-alpha. In particular,
whenever alpha > (1-alpha)/ell, the wrapper does not satisfy simultaneous coordinate
robustness.

### Proof

Equivariance and covariance give, on the bad branch,

\[
  g^{-1}\!\cdot\bigl((g\cdot s)\oplus e_{c(g\cdot s)}\bigr)
  =s\oplus e_{g^{-1}c(g\cdot s)}
  =s\oplus e_{c(s)}.
\]

Thus the public group element only relabels the same exceptional coordinate; it cannot
spread the error over the orbit. The two claimed error probabilities follow immediately.
QED.

The Hadamard construction below realizes this lemma with a fully explicit proof family and
decoder, so the obstruction is not an artifact of an abstract selector assumption.

## Theorem (black-box symmetrization failure: Hadamard realization)

Fix \(\ell\ge2\). Let messages be \(s\in\{0,1\}^{\ell}\), let proof addresses be
\(x\in\{0,1\}^{\ell}\), and define the binary Hadamard proof family
\[
  \Pi^{(s)}(x)=\langle s,x\rangle \pmod 2,
  \qquad N=2^\ell .
\]
The symmetric group \(S_\ell\) acts on messages and addresses by coordinate permutation,
and hence
\[
  (\pi\cdot \Pi^{(s)})(x)
  :=\Pi^{(s)}(\pi^{-1}x)
  =\Pi^{(\pi s)}(x).
\]
Fix \(0<\rho<1/4\), choose
\(\alpha\in(1/(\ell+1),1)\), and put \(\eta=(1-\alpha)/\ell\).

There is a target-independent randomized decoder \(I\), with unrestricted query budget
\(q=N\), such that:

1. on \(\Pi^{(s)}\), it outputs \(s\) with probability \(\alpha\);
2. on every \(z\) with \(\operatorname{dist}(z,\Pi^{(s)})\le\rho\), its normalized
   expected index error is at most \(\eta\);
3. nevertheless, the natural address-symmetrized wrapper
   \[
     J_j(z):=\bigl(\pi^{-1} I(\pi\cdot z)\bigr)_j,
     \qquad \pi\leftarrow\mathcal D,
   \]
   has wrong-bit probability \(1-\alpha>\eta\) on target \(\Pi^{(e_j)}\) when asked for
   coordinate \(j\), for every distribution \(\mathcal D\) on \(S_\ell\).

Thus proof-family equivariance and a positive robust radius do not, by themselves,
turn approximate average index soundness into the exchangeability hypothesis of C132.

## Proof

Distinct Hadamard words have relative distance \(1/2\). Hence for \(\rho<1/4\), every
\(\rho\)-near word has a unique nearest proof word; call its index \(\widehat s(z)\).
Let \(c(t)\) be the position of the unique \(1\) when \(t\) has Hamming weight one, and
let \(c(t)=1\) for all other \(t\). Define \(I(z)\) to output
\(\widehat s(z)\) with probability \(\alpha\), and
\(\widehat s(z)\oplus e_{c(\widehat s(z))}\) with probability \(1-\alpha\).
On a \(\rho\)-near word for \(\Pi^{(s)}\), the only nonzero error event changes one
index coordinate, so its expected normalized error is exactly
\((1-\alpha)/\ell=\eta\). Exact indexed completeness is immediate.

Now take \(s=e_j\). Equivariance gives
\(\pi\cdot\Pi^{(e_j)}=\Pi^{(e_{\pi(j)})}\), and
\(c(e_{\pi(j)})=\pi(j)\). On the bad branch, \(I\) outputs
\(e_{\pi(j)}\oplus e_{\pi(j)}=0^\ell\); after applying \(\pi^{-1}\), the wrapper
\(J_j\) outputs \(0^\ell\), whose \(j\)-th bit is wrong. The bad branch therefore makes
\(J_j\) wrong with probability \(1-\alpha\), independently of \(\mathcal D\), which is strictly larger than
\(\eta=(1-\alpha)/\ell\).
\(\square\)

## Consequence for the theorem program

The failure is not caused by a lack of address symmetry: the proof family is fully
\(S_\ell\)-equivariant, the action is an explicit Hamming-isometry, and the robust radius
is positive. The obstruction is that the decoder's exceptional coordinate can be a
covariant function of the target. Therefore a positive construction cannot cite
"randomly permute the proof addresses" as a black-box route from average/distributional
soundness to C132.

To make symmetrization work one must add a genuinely stronger condition, such as an
orbit-averaged coordinate bound
\[
 \mathbb E_{\pi,I}\!\left[
   \mathbf 1_{I(\pi\cdot z)\ne\bot}
   \mathbf 1\!\left((\pi^{-1}I(\pi\cdot z))_j\ne s_j\right)
 \right]\le\eta
\]
for every \(s,z,j\), or a proof that the decoder's error law is target-independent inside
each orbit. The former is essentially C132 itself; the latter is the substantive new
symmetrization theorem that a near-linear dPCP construction would have to establish.

This is a black-box separation for the proposed wrapper, not an impossibility theorem for
all simultaneous coordinate-robust PCPs. It closes only the tempting "equivariance alone"
escape and isolates the remaining top-level question: can a global proof enforce a
target-independent error law without paying an RLDC/LDC-scale cost?

## Sources

* [Exchangeable approximate indices enter the RLDC barrier](exchangeable-approximate-index-rldc-bridge.md)
* [Robust indexed labels enter the RLDC barrier](robust-indexed-label-rldc-barrier.md)
