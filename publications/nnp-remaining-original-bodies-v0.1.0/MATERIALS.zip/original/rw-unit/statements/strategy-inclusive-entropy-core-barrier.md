# Strategy-inclusive entropy--core barrier for shared-proof reconstruction

## Theorem

Let

\[
  C:\mathcal M\hookrightarrow\Sigma^N
\]

be a finite proof map. A target \(M\in\mathcal M\) may induce a randomized descriptor
and a randomized **strategy summary** \((D,S)\). The summary is required to be complete in
the following precise sense: conditioned on a value \((d,s)\), the policy used for coordinate
\(i\) and declaration \(b\) is a fixed policy

\[
  \pi_{d,s,i,b},
\]

independent of the hidden target \(m\). Thus \(S\) is allowed to encode an entire finite
vector of Merlin policies, but it cannot be a name for an \(m\)-dependent policy family whose
contents are not counted in \(S\).

For every \((d,i,b,\pi)\), let \(V_{d,i,b,\pi}\) use one common proof address space
\([N]\), and let \(\operatorname{Supp}(V_{d,i,b,\pi})\) be the set of proof positions queried
over all random tapes and all answer transcripts visible within the verifier's finite running
time. For every positive-probability triple \((m,d,s)\), choose a complete policy for the
correct declaration and define

\[
  K_{m,d,s}
  =\bigcup_{i\in[k]}
    \operatorname{Supp}(V_{d,i,m_i,\pi_{d,s,i,m_i}}).
\]

Assume constants \(\alpha>\beta\) and \(\rho\ge0\) such that:

1. the selected policy accepts \(C(m)\) with probability at least \(\alpha\);
2. every policy for a wrong declaration under the same descriptor accepts every
   \(z\) with \(\operatorname{dist}(z,C(m))\le\rho\) with probability at most \(\beta\).

Let \(R=|K_{M,D,S}|\). Then

\[
  H(M)
  \le I(M;D,S)
      +N h_2\!\left(\frac{\mathbb E R}{N}\right)
      +\mathbb E R\log_2|\Sigma|.
\tag{SIEC1}
\]

In particular, if \(M\) is uniform on a \(k\)-bit family, \(|\Sigma|\) is fixed,
\(N=k^{O(1)}\), and \(I(M;D,S)\le\gamma k\) for a fixed \(\gamma<1\), then

\[
  \mathbb E R=\Omega\!\left(\frac{(1-\gamma)k}{\log k}\right).
\tag{SIEC2}
\]

If \(D\) and \(S\) are deterministic summaries of lengths \(s\) and \(\ell\), respectively,
then \(I(M;D,S)\le s+\ell\), so the same conclusion holds whenever
\(s+\ell\le\gamma k\).

## Proof

Fix a pair \((d,s)\) with positive probability. Suppose two distinct targets \(m,m'\) in
the conditional support of \((M\mid D=d,S=s)\) have the same set \(K\) and the same proof
restriction \(C(m)|_K=C(m')|_K\). Choose \(i\) with \(m_i\ne m'_i\). The policy
\(\pi_{d,s,i,m_i}\) has full support contained in \(K\), so its complete transcript
distribution is identical on \(C(m)\) and \(C(m')\). Completeness for \(m\) therefore gives

\[
  \Pr[V_{d,i,m_i,\pi_{d,s,i,m_i}}^{C(m')}=1]\ge\alpha.
\]

For target \(m'\), the same declaration \(m_i\) is wrong. Since \(C(m')\) is in its own
\(\rho\)-neighborhood, all-policy soundness gives the same probability at most \(\beta\), a
contradiction. Hence, conditioned on \((D,S)\), the target is determined by

\[
  \bigl(K_{M,D,S},C(M)|_{K_{M,D,S}}\bigr).
\]

Consequently,

\[
\begin{aligned}
H(M)
 &= I(M;D,S)+H(M\mid D,S)\\
 &\le I(M;D,S)+H(K\mid D,S)
    +H(C(M)|_K\mid D,S,K).
\end{aligned}
\]

For each address \(j\in[N]\), let \(p_j=\Pr[j\in K]\). Subadditivity and concavity of the
binary entropy function give

\[
  H(K\mid D,S)
  \le \sum_{j=1}^N h_2(p_j)
  \le N h_2\!\left(\frac{\sum_jp_j}{N}\right)
  =N h_2\!\left(\frac{\mathbb E R}{N}\right).
\]

The restriction contains \(R\) symbols of \(\Sigma\), so its conditional entropy is at most
\(\mathbb E R\log_2|\Sigma|\). This proves (SIEC1). If \(\mathbb E R\le N/2\), use
\(h_2(u)\le u\log_2(e/u)\); if it is larger, the lower bound is immediate. Since
\(N=k^{O(1)}\) and \(|\Sigma|\) is fixed, (SIEC2) follows.

## Strategy-compression trilemma

For a high-entropy family, a finite common-proof reconstruction interface must pay at least
one of three costs:

1. \(I(M;D,S)=\Omega(k)\): the descriptor or strategy summary carries the target;
2. \(\mathbb E|K|=\Omega(k/\log k)\): the honest complete policies expose a large physical
   proof core;
3. the all-policy branch-support union leaves the low-locality regime, or the common-address
   and target-relative quantifiers are abandoned.

The third item is the separate relaxed-LDC/support barrier. The present theorem is the missing
information-theoretic link that charges the **honest** strategy itself; it does not assume a
positive radius and therefore remains applicable when the ordinary RLDC theorem is silent.

## Scope and evidence boundary

The result requires a common physical proof address space and all-policy wrong-declaration
soundness. It does not apply to independent proof oracles, selected-policy-only soundness,
or an unbounded strategy whose complete policy has no finite summary. The theorem is
self-contained; it uses only finite-support indistinguishability, mutual information, and the
entropy bound for random subsets. It is a strengthening of the descriptor--core inequality,
not an unconditional impossibility theorem for all dPCPs or a proof of \(P\ne NP\).
