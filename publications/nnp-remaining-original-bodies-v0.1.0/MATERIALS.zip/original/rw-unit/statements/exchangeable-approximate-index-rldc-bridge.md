# Exchangeable approximate indices enter the RLDC barrier

## Theorem

Let \(L=2^\ell\), let \(\Pi^{(s)}\in\Sigma^N\) be a common-address proof family indexed
by \(s\in\{0,1\}^{\ell}\), and let \(I\) be a target-independent randomized decoder making
at most \(q\) proof queries and outputting either an index \(s'\in\{0,1\}^{\ell}\) or
\(\bot\). Fix \(\rho>0\) and constants \(\alpha>\eta\). Assume:

1. **Exact indexed completeness:** on \(\Pi^{(s)}\), \(I\) outputs \(s\) with probability
   at least \(\alpha\);
2. **Exchangeable approximate-index soundness:** for every \(z\) with
   \(\operatorname{dist}(z,\Pi^{(s)})\le\rho\), the random error object
   \[
     E_{s,z}=
     \begin{cases}
       \bot,&I^z=\bot,\\
       I^z\oplus s,&I^z\ne\bot
     \end{cases}
   \]
   is invariant under every permutation of the \(\ell\) index coordinates, and
   \[
     \mathbb E\!\left[
       \mathbf 1_{I^z\ne\bot}\,
       \frac{\operatorname{wt}(I^z\oplus s)}{\ell}
     \right]\le\eta .
   \]

Then the proof map \(s\mapsto\Pi^{(s)}\) has a raw \(q\)-query relaxed bit decoder whose
honest correct-bit probability is at least \(\alpha\) and whose wrong-bit probability on
every \(\rho\)-near word is at most \(\eta\). To amplify, repeat the raw decoder \(R\) times;
for a requested bit, output \(b\in\{0,1\}\) only if it is the unique bit for which at least
\(\tau R\) repetitions return \(b\), where \(\tau=(\alpha+\eta)/2\) (otherwise output \(\bot\)).
Thresholding \(R=\Theta((\alpha-\eta)^{-2})\)
independent repetitions gives the usual weak constant-success RLDC with
\[
  Q=O\!\left(q(\alpha-\eta)^{-2}\right)
\]
queries and the same positive radius. Consequently, every applicable relaxed-LDC lower
bound in this \(Q\)-query parameter window applies to \(N\).

## Proof

For a requested bit \(j\), run \(I\) and return the \(j\)-th bit of \(I^z\) when it is not
\(\bot\); otherwise return \(\bot\). Let
\[
  p_j(s,z)=
  \Pr[I^z\ne\bot\ \wedge\ (I^z)_j\ne s_j].
\]
Exchangeability makes all \(p_j(s,z)\) equal. Summing over \(j\) gives
\[
  p_j(s,z)
  =\frac1\ell\,
    \mathbb E\!\left[
      \mathbf 1_{I^z\ne\bot}\operatorname{wt}(I^z\oplus s)
    \right]
  \le\eta .
\]
On the honest proof, exact indexed completeness implies the requested bit is correct with
probability at least \(\alpha\), while the same soundness hypothesis (applied at distance
zero) bounds the opposite-bit probability by \(\eta\). Thus the raw decoder has gap
\(\alpha-\eta\). The amplified decoder is a thresholded-presence decoder, not a majority
decoder: it retains \(\bot\) if neither (or both) bit counts certify. Hoeffding gives the
stated \(Q\).

The proof map also has relative distance \(>\rho\). Otherwise, for \(s\ne t\) with
\(\operatorname{dist}(\Pi^{(s)},\Pi^{(t)})\le\rho\), choose a coordinate \(j\) with
\(s_j\ne t_j\) and use \(\Pi^{(t)}\) as the near word for target \(s\). Exact completeness
for \(t\) makes \(p_j(s,\Pi^{(t)})\ge\alpha\), contradicting \(p_j\le\eta<\alpha\).
\(\square\)

## Why exchangeability is the real boundary

An average index-error bound without exchangeability does not imply a coordinate decoder.
For example, let \(I\) output \(s\oplus e_1\) deterministically. Its normalized index
error is \(1/\ell\), but coordinate \(1\) is wrong with probability \(1\), so no
simultaneous coordinate-robustness follows. Thus distributional soundness must either provide
exchangeability (or an equivalent public symmetrization) or separately control every coordinate.

The exact-index theorem is the special case in which the wrong-index event has probability
at most \(\eta\); no symmetry assumption is then needed. Conversely, ordinary dPCP list
soundness generally gives neither a common index nor exchangeable error vectors, so this
theorem is a conditional bridge rather than a black-box upgrade.

## Consequences and scope

If \(\alpha=1\), \(\eta\le1/3\), and the binary proof alphabet is used, a message-inline
version has raw \(q+1\) queries and enters any applicable \((q+1)\)-query binary RLDC
lower bound. For \(q=1\), this is the 2-query window; the resulting bound applies to the
inline length \(\ell+N\). For general \(\alpha\), use the amplified \(Q+1\) locality.

The theorem does not claim that GMWZ/dPCP constructions supply exchangeable index errors.
It isolates a precise positive target: prove a uniform relabeling/symmetrization lemma for
the same global proof, or prove that any such lemma incurs an alphabet, query, or proof-length
cost.

## Sources

* [Robust indexed labels enter the RLDC barrier](robust-indexed-label-rldc-barrier.md)
* [Dall'Agnol--Gur--Lachish, TR20-154](https://eccc.weizmann.ac.il/report/2020/154/)
* [Gur--Minzer--Weissenberg--Zheng, 3-query RLDCs are strictly stronger than 3-query LDCs](https://arxiv.org/abs/2512.12960)
* [Block et al., Exponential Lower Bounds for 2-query RLDCs](https://arxiv.org/abs/2602.20278)
