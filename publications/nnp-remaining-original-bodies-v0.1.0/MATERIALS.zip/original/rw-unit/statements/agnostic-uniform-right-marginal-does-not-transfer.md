# Agnosticity and a uniform right marginal do not imply cross-cluster transfer

## Theorem (source-independent black-box separation)

Fix any \(0<\varepsilon<1/2\). There is a finite decoder-side probability model with

1. a uniform coordinate \(t\in\{0,1\}\);
2. a uniform right vertex \(b\);
3. an agnostic complete decoding distribution in the sense of GMWZ Definition 3.5,
   \[
   Q(a\mid t,b)=Q(a\mid b)\qquad\text{for every }t,b;
   \]
4. a constant-mass cross event \(C\) whose conditioning leaves the right-vertex
   marginal completely unchanged;

such that

\[
 \operatorname{TV}\!\left(Q_{(t,b)\mid C},Q_{(t,b)}\right)\ge \frac12-\varepsilon.
 \tag{AMT1}
\]

Consequently, no black-box implication from

* heavy-cluster mass and any condition depending only on the shared-top left-face pair operator,
* a uniform marginal on the right vertices, and
* GMWZ agnosticity

can prove \(\xi_{ij}=o(1)\) for arbitrary clusters. Here \(\xi_{ij}\) is the total-variation
distance between the cross-cluster \((t,u)\) marginal and the base decoder marginal, with
\(u=b\) in the construction below. In fact, the construction keeps \(u\mid C\) exactly equal
to the base \(u\)-marginal, so the failure is not caused by a visible \(u\)-bias.

This is a separation of hypotheses, not a counterexample to the particular
computation-generated assignment in GMWZ.

The hidden sheet is deliberate: it models any pair-side/cluster state not represented in
the published \((t,a,b)\) marginal. If a proposed positive theorem requires \(C\) to be a
measurable function of the exposed simplicial faces, that is an additional hypothesis and
the earlier visible-\(u\) complete-complex example remains the relevant lower-strength
test.

## Construction

Start with any shared-top pair sampler on a complete complex (the balanced
\(S\sqcup T\) example from C161 is enough) and append an independent sheet bit
\(h\in\{0,1\}\). The sheet is part of the underlying pair state but is not exposed in the
complete decoding marginal \((t,a,b)\). Let the cross event be \(C=\{h=1\}\). Since \(h\)
is independent of the projected pair sample, the left-face pair operator is unchanged and
\[
 Q(b\mid C)=Q(b),\qquad Q(u\mid C)=Q(u).
 \tag{AMT2}
\]
The event \(C\) has constant probability \(1/2\); it can be viewed as a two-sheet
cross-cluster lift of the same complete-complex sampler. The product lift is used only to
test a black-box implication: it leaves every statistic of the projected left-face pair
sampler unchanged.

Define the complete-decoding law over \((t,a,b)\) by first choosing \(b\) according to the
uniform right marginal, then sampling \(a\) from an arbitrary distribution \(\alpha_b\),
and finally sampling \(t\) according to

\[
\Pr[t=0\mid h]=
 \begin{cases}
 1-\varepsilon,&h=1,\\
  \varepsilon,&h=0,
 \end{cases}
\qquad
\Pr[t=1\mid h]=1-\Pr[t=0\mid h].
 \tag{AMT3}
\]

The law has a uniform \(b\)-marginal by construction, and \(b\mid C\) remains uniform by
(AMT2). Since \(h\) is balanced, it also has a uniform \(t\)-marginal:

\[
\Pr[t=0]=\tfrac12(1-\varepsilon)+\tfrac12\varepsilon=\tfrac12.
\tag{AMT4}
\]

Moreover \(a\) is sampled independently of \((t,h)\) after conditioning on \(b\), so

\[
 Q(a\mid t,b)=\alpha_b(a)=Q(a\mid b).
\tag{AMT5}
\]

Thus the complete decoding distribution is exactly agnostic, not merely approximately so.

## Proof of the transfer failure

By (AMT3), conditioning on \(C=\{h=1\}\) gives

\[
 \Pr[t=0\mid C]=1-\varepsilon.
\tag{AMT6}
\]

The base law has \(\Pr[t=0]=1/2\) by (AMT4). Testing the event \(\{t=0\}\) in the
definition of total variation gives

\[
 \operatorname{TV}\!\left(Q_{(t,b)\mid C},Q_{(t,b)}\right)
 \ge \left|(1-\varepsilon)-\tfrac12\right|
 =\tfrac12-\varepsilon.
\]

Taking \(u=b\) yields (AMT1) for the decoder view used in the cross-cluster transfer
criterion, while (AMT2) says that the \(u\)-marginal itself has not moved. The complete
complex has no local HDX defect, and adding the hidden sheet and coordinate variable does
not change the left-cluster pair operator. More generally, the same product lift can be
applied to any left-face sampler with a desired pair-operator spectral bound. Hence any
hypothesis that only inspects that operator, \(u\)-marginal, or the agnostic marginal
\(a\mid t,b\) is orthogonal to this decoder-side marginal failure.
\(\square\)

## Exact conditioning criterion

Let \(Y=(t,u)\) be the exposed decoder view with base law \(\nu\), and let \(C\) be an
admissible cross event of mass \(\gamma>0\). Define
\[
w(y)=\Pr[C\mid Y=y].
\]
Then
\[
\nu_C(y)=\frac{w(y)}{\gamma}\nu(y),\qquad
\operatorname{TV}(\nu_C,\nu)
=\frac{1}{2\gamma}\mathbb E_{Y\sim\nu}|w(Y)-\gamma|.
\tag{AMT8}
\]
Thus \(\xi_{ij}=o(1)\) is equivalent to an \(L_1(\nu)\) smoothness statement for the
actual cross-event indicator. In particular,
\[
\|w-\gamma\|_\infty\le\eta\gamma\Longrightarrow \xi_{ij}\le\eta/2,
\tag{AMT9}
\]
and
\[
\operatorname{Var}_{\nu}(w)\le\eta^2\gamma^2\Longrightarrow \xi_{ij}\le\eta/2.
\tag{AMT10}
\]
The hidden-sheet construction has \(\gamma=1/2\) and
\(w(t=0,b)=1-\varepsilon\), \(w(t=1,b)=\varepsilon\), so (AMT8) gives exactly
\(\xi_{ij}=1/2-\varepsilon\). This is the positive theorem target: prove (AMT9) or
(AMT10) for the computation-generated cross event. Agnosticity concerns the conditional
\(a\)-law and does not control \(w\).

There is also a sharp exposed-event positive direction. Suppose \(Q(t\mid b)=1/n\), and
the cross event is generated only from the exposed pair \((a,b)\), so that
\(\mathbf 1_C=c(a,b)\) for some function \(c\). By agnosticity,
\[
\Pr[C\mid t,b]
=\sum_a c(a,b)Q(a\mid t,b)
=\sum_a c(a,b)Q(a\mid b)
=\Pr[C\mid b].
\tag{AMT11}
\]
Consequently \(t\mid b,C\) remains uniform and
\[
\operatorname{TV}(Q_{(t,b)\mid C},Q_{(t,b)})
=\operatorname{TV}(Q_{b\mid C},Q_b).
\tag{AMT12}
\]
Thus a source-specific proof that the actual cross event is exposed through \((a,b)\),
that \(t\mid b\) is flat, and that \(b\mid C\) is smooth would close the \(\xi\)-gate.
The hidden-sheet example shows why all three clauses are necessary in a black-box theorem.

The same conclusion fails even when there is no hidden sheet and the cross event is
fully exposed, as soon as it uses two left samples. Consider the following finite
two-edge law. Let \(t,b\) be independent uniform bits. Conditional on \((t,b)\), draw
\(a_0\) uniformly and set

\[
a_1=a_0\oplus t.
\tag{AMT13}
\]

For each \(r\in\{0,1\}\), \(a_r\mid(t,b)\) is uniform and hence equal to
\(a_r\mid b\); therefore every one-edge marginal satisfies the exact GMWZ-style
agnosticity condition. Nevertheless the completely exposed event

\[
C=\{a_0=a_1\}
\tag{AMT14}
\]

has mass \(1/2\), and conditioning on \(C\) forces \(t=0\). Thus

\[
\operatorname{TV}(Q_{(t,b)\mid C},Q_{(t,b)})=1/2,
\tag{AMT15}
\]

while the \(b\)-marginal remains uniform. This is a purely exposed second-order
counterexample: no latent sheet or unobserved variable is used. It shows that
AMT11 cannot be applied to a shared-top event merely because each of its two edge
marginals is agnostic.

The exact positive replacement is pair agnosticity. If the joint law satisfies

\[
Q(a_0,a_1\mid t,b)=Q(a_0,a_1\mid b)
\quad\text{for every }t,b,
\tag{AMT16}
\]

and \(C\) is any exposed event \(c(a_0,a_1,b)\), then the proof of AMT11 applies
with \((a_0,a_1)\) in place of \(a\): \(t\mid b,C\) stays flat, and the only
remaining transfer task is smoothness of \(b\mid C\). Therefore a source-specific
Closure Theorem for shared-top/JK composition must either prove (AMT16), or prove
a quantitative substitute controlling the conditional pair law; Definitions 3.4--3.5
of GMWZ alone provide only the one-edge statement and do not supply this second-order
interface.

For the actual GMWZ direct-product sampler, however, (AMT16) is available under its
stated sampling order. Fix \(b\), sample \(U\supseteq b\), then sample
\(a_0,a_1\supseteq b\) independently conditional on \((U,b)\); independently sample
\(u\in b\), and finally sample \(t\) from the base decoder law conditional on \(u\).
For any \(t,a_0,a_1,b\),
the joint law factors as

\[
\Pr[t,a_0,a_1\mid b]
=\underbrace{\Pr[t\mid b]}_{\text{the }u\text{-mixture}}
  \underbrace{\Pr[a_0,a_1\mid b]}_{\text{the }U\text{-mixture}},
\tag{AMT17}
\]

because \(u\) is sampled inside \(b\) and is independent of \((U,a_0,a_1)\) after \(b\)
is fixed. Hence the pair agnosticity identity (AMT16) holds exactly for this sampler.
In fact, the factorization extends this conclusion to any cross event measurable from
\((U,a_0,a_1,b)\) but not from the sampled \((u,t)\): \(t,u\mid b,C\) is unchanged and
only the \(b\)-profile of \(C\) remains to be bounded. Thus latent \(U\) is not itself a
direct \(t,u\)-transfer obstruction; it enters through the latent pair-incidence weight
\(w(b)=\mathbb E_{U\mid b}[p_0(U,b)p_1(U,b)]\). The exact full-view identity and the
resulting covariance profile are recorded in [note 205](../mcsp-hardness-magnification/notes/205-latent-top-pair-incidence-closes-shared-top-transfer-2026-08-17.md).
This is a positive source-specific closure interface, not a property of arbitrary
agnostic dPCPs. The relevant GMWZ construction samples \((a,b,u,t)\) in this order in
Section 6.1 and uses independent \((a,a')\) conditional on \((U,b)\) in the proof of
Lemma 6.3; see the [GMWZ source](https://arxiv.org/html/2512.12960#S6.1).

The remaining \(b\)-smoothness clause is also independent. Let \(t,b\) be independent
uniform bits, let \(a_0\) be uniform, and define \(a_1=a_0\) when \(b=0\) and
\(a_1=1-a_0\) when \(b=1\). Then the full pair law is independent of \(t\), so (AMT16)
holds exactly and \(t\mid b\) is flat. But for the exposed event

\[
C=\{a_0=a_1\},
\tag{AMT18}
\]

we have \(C=\{b=0\}\), hence

\[
\operatorname{TV}(Q_{(t,b)\mid C},Q_{(t,b)})=1/2.
\tag{AMT19}
\]

Thus pair agnosticity closes the \(t\)-transfer only; it cannot replace an
event-wise right-face anti-concentration bound such as (AMT9)--(AMT10).

There is a quantitative positive instance for the natural two-cluster event. Let
\(p_i(b)=\Pr[a_i\in U_i\mid b]\), \(\mu_i=\mathbb E_b p_i(b)\), and suppose the two
left faces are conditionally independent given \(b\). For
\(C=\{a_0\in U_0,\ a_1\in U_1\}\),

\[
w(b)=\Pr[C\mid b]=p_0(b)p_1(b),
\qquad \gamma=\mathbb E_b w(b).
\tag{AMT20}
\]

Writing \(\sigma_i^2=\operatorname{Var}_b(p_i(b))\), the centered-product decomposition

\[
\mathbb E_b|w-\gamma|
\le \mu_1\sigma_0+\mu_0\sigma_1+\sigma_0\sigma_1
\tag{AMT21}
\]

follows from \(0\le p_i\le1\), Cauchy--Schwarz, and
\(|\gamma-\mu_0\mu_1|\le\sigma_0\sigma_1\). If
\(\sigma_0\sigma_1<\mu_0\mu_1/2\), then
\(\gamma\ge\mu_0\mu_1/2\), and (AMT8) gives

\[
\xi_{ij}
\le
\frac{\sigma_0+\mu_0\sigma_1+\sigma_0\sigma_1}{\mu_0\mu_1}.
\tag{AMT22}
\]

Hence a BMVY-type profile \(\sigma_i^2\le\theta^2\mu_i\), together with
\(\gamma\ge c_\gamma\mu_0\mu_1\), gives the explicit scale
\[
\xi_{ij}\le \frac1{c_\gamma}\left(
\frac{\theta}{\sqrt{\mu_0}}+\frac{\theta}{\sqrt{\mu_1}}
\frac{\theta^2}{\sqrt{\mu_0\mu_1}}\right)
\]
after the latent-free factorization. In a constant-mass window this is
\(O(\theta+\theta^2)\); the older \(O(\theta/\mu_0)\) shorthand requires the
stronger relative profile \(\sigma_i\le\theta\mu_i\). This is the sharp
source-specific positive target: it handles factorized cluster events, while C187
shows why no conclusion follows without an incidence profile.

The qualification “independent given \(b\)” is essential. In the actual GMWZ
shared-top sampler, \(a_0,a_1\) are independent given \((U,b)\), not necessarily
given \(b\) alone. The correct quantity is then

\[
w(b)=\mathbb E_{U\mid b}\!\left[p_0(U,b)p_1(U,b)\right],
\tag{AMT23}
\]

and a marginal profile for \(p_i(b)=\mathbb E_{U\mid b}p_i(U,b)\) does not control the
conditional covariance over \(U\). This is a genuine latent-top obstruction, not merely
the sampler-normalization issue.

For a sharp finite witness, let \(t,b,U\) be independent uniform bits. Conditional on
\((U,b)\), sample \(a_0,a_1\) independently, with
\[
\Pr[a_0\in U_0\mid U,b]=\mathbf 1_{\{U=0\}},
\qquad
\Pr[a_1\in U_1\mid U,b]=
\begin{cases}
\mathbf 1_{\{U=0\}},&b=0,\\
\mathbf 1_{\{U=1\}},&b=1.
\end{cases}
\tag{AMT24}
\]
Then both marginal incidences satisfy \(p_i(b)=1/2\) for every \(b\), so their
single-face variance is zero and pair agnosticity with respect to \(t\) is exact.
However \(w(0)=1/2\), \(w(1)=0\), and the event
\(C=\{a_0\in U_0,\ a_1\in U_1\}\) forces \(b=0\). Thus
\(\operatorname{TV}(Q_{(t,b)\mid C},Q_{(t,b)})=1/2\) despite perfect marginal
smoothness. A shared-top Closure Theorem therefore needs a latent-\(U\) pair-incidence
profile controlling (AMT23), not only the BMVY one-face profile.

## What agnosticity does and does not say

GMWZ Definition 3.5 says that after fixing \(b\), revealing \(t\) does not change the
conditional distribution of \(a\). It does **not** say that \(t\) is uniform after fixing
\(b\), nor that the joint \((t,u)\) law remains unchanged after conditioning on a hidden
pair-side event. The construction makes exactly this distinction visible:

\[
 a\mid(t,b)=a\mid b,\qquad\text{but}\qquad t\mid C\text{ is strongly biased while }u\mid C=u.
\]

Notice that the model even has \(Q(t\mid b)=1/2\) in the unconditioned decoder law. The
missing hypothesis is therefore a decoder-side anti-concentration statement controlling
the hidden pair state after cluster conditioning, for example

\[
 Q(t,\circ,b\mid C)=Q(\circ,\circ,b\mid C)/n
 \quad\text{for every admissible cross event }C\text{ and }b,
\tag{AMT7}
\]

or a direct bound on the total variation of \(Q(t,u\mid C)\) for the specific clusters
produced by the computation. The unconditioned identity \(Q(t,\circ,b)=Q(\circ,\circ,b)/n\)
alone is insufficient; a full transfer theorem also needs the corresponding
\(u\)-incidence smoothness after conditioning.

## Relation to the RW/GMWZ closure program

This theorem upgrades the earlier complete-complex marginal example: the obstruction
survives the two additional source properties that are most tempting to use in the
positive route, namely agnosticity and uniform right marginal, and it survives even after
the visible \(u\)-marginal is fixed. It therefore closes the
following black-box route:

GMWZ agnostic decoding + uniform right marginal + heavy-cluster spectral mixing
\(\Longrightarrow \xi_{ij}=o(1)\).

The surviving positive target is narrower and source-specific: prove (AMT7), or an
equivalent hidden-state conditional-coordinate/incidence bound, for the actual
computation-generated clusters. Such a result would be genuinely additional to Lemma 6.2, Definition 3.5, and
the uniform-right-marginal clause; it cannot be obtained by rearranging those hypotheses.

## Source boundary

GMWZ defines the complete decoding distribution by choosing \(t\) uniformly and then
sampling \((a,b)\) from \(\mathcal P_t\), and defines agnosticity by
\(Q(t,\cdot,b)=Q(\circ,\cdot,b)\) [Definition 3.4--3.5](https://arxiv.org/html/2512.12960#S3.1).
The final construction also explicitly guarantees a uniform marginal over right vertices
[Theorem 8.4](https://arxiv.org/html/2512.12960#S8.2). The separation above is a finite
probability construction built against exactly those stated marginals; it does not claim
that GMWZ's particular canonical computation assignment realizes (AMT3).
