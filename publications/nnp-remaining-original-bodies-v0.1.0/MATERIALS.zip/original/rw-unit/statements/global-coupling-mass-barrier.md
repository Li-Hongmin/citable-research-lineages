# Global-coupling mass forced by fully patchable proof regions

## Theorem

Fix one target coordinate \(i\), an honest proof \(\Pi_\star\), and an adaptive outer
verifier whose honest transcript on randomness \(\omega\) queries a set

\[
  Q_i(\omega)\subseteq W
\]

of proof positions. Let \(A\) be a family of private patches. For each \(a\in A\), let
\(U_a\) be the proof variables changed by that patch and let
\(\partial a\subseteq W\) contain every queried position whose local view can inspect
\(U_a\). Put

\[
  P=\bigcup_{a\in A}\partial a .
\]

Assume the following **full patchability** conditions.

1. The \(U_a\)'s are pairwise disjoint, and every subset \(S\subseteq A\) has a well-defined
   candidate proof \(\Pi_S\) obtained from \(\Pi_\star\) by applying exactly the patches in
   \(S\).
2. On \(\Pi_S\), every queried local answer outside
   \(\partial S:=\bigcup_{a\in S}\partial a\) is the honest answer. Until the first
   query in \(\partial S\), the outer verifier therefore follows the honest transcript.
3. Whenever the honest path first queries a position in \(\partial S\), the corresponding
   patched local answer forces acceptance of the wrong declaration at coordinate \(i\).

If every candidate proof has wrong-declaration acceptance at most \(\delta\), then

\[
  \Pr_\omega[Q_i(\omega)\cap P\ne\varnothing]\le\delta .
  \tag{GC1}
\]

Equivalently, at least \(1-\delta\) of the honest-path probability mass lies on query
positions outside the fully patchable region \(P\):

\[
  \Pr_\omega[Q_i(\omega)\subseteq W\setminus P]\ge 1-\delta .
  \tag{GC2}
\]

Thus a simultaneous coordinate-robust verifier cannot obtain more than its soundness
budget of honest query mass from a proof region that can be independently patched all the
way to a first-error forcing assignment.

## Proof

Apply the profile-hitting condition to the single subset \(S=A\). By full patchability,
\(\Pi_A\) agrees with \(\Pi_\star\) away from \(P=\partial A\). Until the honest path first
hits \(P\), the adaptive verifier sees the same answers as on \(\Pi_\star\). If it hits
\(P\), condition 3 forces the wrong declaration to accept. Hence

\[
  \Pr[\text{wrong declaration accepts on }\Pi_A]
  \ge \Pr_\omega[Q_i(\omega)\cap P\ne\varnothing].
\]

Soundness of \(\Pi_A\) gives (GC1), and (GC2) is its complement.

No independence between patches is needed after the full-patchability assumption has
constructed \(\Pi_A\). Pairwise disjointness of the variable sets is a concrete sufficient
condition for that construction, not a consequence of the theorem.

## Consequences

### No fully patchable proof

If \(P=W\) and every honest path makes at least one query, then (GC2) rules out every
\(\delta<1\) simultaneous coordinate-robust verifier. More generally, every robust
construction must leave a non-patchable region carrying at least \(1-\delta\) of the honest
query mass. This is a global-coupling requirement, not merely a statement about the number
of queried positions.

### Relation to finite patch families

If only subsets \(S\subseteq A\) of size at most \(r\) are patchable, the same proof gives

\[
  \max_{|S|\le r}
  \Pr_\omega[Q_i(\omega)\cap\partial S\ne\varnothing]\le\delta .
  \tag{GC3}
\]

The full-patch theorem is the \(r=|A|\) endpoint. Equation (GC3) is the appropriate
finite-patch form when the construction can compose only a bounded number of local changes;
it is exactly the profile-hitting functional restricted to the boundary family
\(\{\partial S:|S|\le r\}\).

### Target-binding interpretation

In a shared-base construction, coordinate-specific certificate locations may be private
patches, while the base positions are outside \(P\) unless one can alter them consistently
with the target class. The theorem therefore forces honest queries to spend at least
\(1-\delta\) mass on that shared target-binding channel. The quantitative
[target-binding patch-boundary theorem](target-binding-patch-boundary.md) strengthens this
qualitative conclusion when the shared channel has a positive relative-distance window: a
constant wrong-output forcing then requires proportional corruption of the channel.

### Why this is not a general dPCP impossibility theorem

Ordinary average or list-decoding soundness does not imply full patchability. A proof system
may have few globally realizable error profiles, or its target-binding mechanism may couple
private variables so that \(\Pi_A\) does not exist. The theorem therefore leaves exactly two
escape classes:

* deny the patchability/richness premise; or
* retain a large non-patchable global channel and account for its proof, query, or address
  complexity.

Turning the second alternative into a superlinear lower bound requires an additional coding
or information argument, such as the family-level relaxed-LDC modules in this unit.

## Relation to existing modules

This is the all-patches corollary of the profile-hitting theorem, written as a standalone
global-coupling statement. The private-variable patchability lemma supplies a concrete proof
graph condition for its hypotheses. The result is intentionally stronger in interpretation,
not in quantifier scope: it remains conditional on an actual family of jointly realizable
first-error forcing patches.
