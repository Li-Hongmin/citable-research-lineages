# Randomized support--core--descriptor trilemma

## Theorem

Let \(M\) be a finite target random variable, \(D\) a descriptor sampled conditionally on
\(M\), and \(C(M)\in\Sigma^N\) a proof map. For every \((m,d)\) with
\(\Pr[M=m,D=d]>0\), assume that all coordinates use the same physical address space
\([N]\), and that the complete policies for target \(m\) and descriptor \(d\) have union
support

\[
  K_{m,d}=\bigcup_i
  \operatorname{Supp}\!\left(V_{d,i,m_i,\pi_{m,d,i}}\right),
  \qquad R_{m,d}=|K_{m,d}|.
\]

Assume the completeness and all-policy target-relative soundness hypotheses of the
randomized descriptor core theorem hold for every such \((m,d)\). Write

\[
  R=R_{M,D},
  \qquad r_d=\mathbb E[R\mid D=d].
\]

Finally, let \(L_d\) be the union of the full branch supports of all finite-time policies in
descriptor bucket \(d\). If a valid branch-support/RLDC theorem gives

\[
  H(M\mid D=d)\le \Phi_N(L_d)
\tag{RSCD1}
\]

for every positive-probability descriptor value \(d\), then

\[
 H(M)
 \le I(M;D)+
 \min\left\{
   G_N(\mathbb E R),
   \mathbb E_{d\sim D}[\Phi_N(L_d)]
 \right\},
\tag{RSCD2}
\]

where

\[
  G_N(u)=N h_2(u/N)+u\log_2|\Sigma|.
\]

Equivalently, the conditional entropy satisfies

\[
 H(M\mid D)
 \le \min\left\{G_N(\mathbb E R),
                  \mathbb E_{d\sim D}[\Phi_N(L_d)]\right\}.
\tag{RSCD3}
\]

## Consequences

If \(H(M)-I(M;D)\ge \eta k\), \(N=k^{O(1)}\), and \(|\Sigma|\) is fixed, then

\[
  \mathbb E R=\Omega\!\left(\frac{\eta k}{\log k}\right),
  \qquad
  \mathbb E_d[\Phi_N(L_d)]\ge \eta k.
\tag{RSCD4}
\]

Thus target-independent public randomness is charged only through the information term
\(I(M;D)\), while the remaining conditional entropy must pay both a complete-policy core
and the all-policy branch-support/RLDC cost. A descriptor can move entropy between these
two costs, but cannot remove both.

If \(D\) is independent of \(M\), then \(I(M;D)=0\), so the full family entropy remains in
the two-way tradeoff. If \(I(M;D)\le\gamma k\) and \(H(M)\ge k\), (RSCD4) gives

\[
  \mathbb E R=\Omega\!\left(\frac{(1-\gamma)k}{\log k}\right)
\]

for fixed alphabet and polynomial proof length.

## Finite-transcript refinement

Suppose that, after fixing a descriptor \(d\), a finite-horizon verifier uses at most
\(\rho_d\) random bits, receives at most \(\mu_d\) Merlin-response bits, and makes at most
\(\nu_d\) proof-symbol queries on each branch. Put

\[
  T_d=\nu_d\,2^{\rho_d+\mu_d}|\Sigma|^{\nu_d}.
\tag{RSCD5}
\]

The view-tree support bound gives \(L_d\le T_d\). Therefore, whenever the branch-support
bound \(\Phi_N\) is monotone on the relevant window,

\[
 H(M)
 \le I(M;D)+
 \min\left\{
   G_N(\mathbb E R),
   \mathbb E_{d\sim D}[\Phi_N(T_d)]
 \right\}.
\tag{RSCD6}
\]

In particular, if \(H(M)-I(M;D)\ge\eta k\), every bucket with
\(H(M\mid D=d)\ge\eta k/2\) must satisfy both
\(G_N(\mathbb E[R\mid D=d])\ge\eta k/2\) and
\(\Phi_N(T_d)\ge\eta k/2\). In the fixed-alphabet, near-linear DGL window, where

\[
 \Phi_N(T)=C|\Sigma|^T\log_2|\Sigma|\,
 N^{1-c/(T^2\log^2(T+2))}\log_2(k+2),
\tag{RSCD7}
\]

this forces

\[
 T_d^3\log^2(T_d+2)=\Omega_\eta(\log k)
\tag{RSCD8}
\]

for every such bucket that remains inside the theorem's radius/length window. Thus a
target-independent public descriptor, a short complete-policy core, and a low-exposure
finite transcript cannot all coexist: fixed \(\nu_d\) and fixed alphabet require
\(\rho_d+\mu_d=\Omega(\log\log k)\) on every bucket in this high-conditional-entropy
class (and hence on a constant mass whenever that class has constant probability).

## Proof

For each fixed descriptor value \(d\), the conditional-support injection from the randomized
descriptor core theorem gives

\[
 H(M\mid D=d)\le G_N(r_d).
\tag{RSCD9}
\]

Indeed, two targets in the same conditional support with the same
\((K_{m,d},C(m)|_{K_{m,d}})\) would make a complete policy for one target a wrong policy for
the other while exposing identical proof symbols. Averaging (RSCD9) and using concavity
of \(G_N\) yields

\[
 H(M\mid D)\le \mathbb E_d G_N(r_d)
 \le G_N(\mathbb E_d r_d)=G_N(\mathbb E R).
\]

The branch-support hypothesis (RSCD1), averaged over \(d\), gives the second upper bound in
(RSCD3). Taking the minimum proves (RSCD3), and adding
\(I(M;D)\) via \(H(M)=I(M;D)+H(M\mid D)\) proves (RSCD2). Finally, if the left side of
(RSCD3) is at least \(\eta k\), both terms on the right are at least \(\eta k\); the
standard inverse estimate for \(G_N\) gives (RSCD4).

## Scope

The theorem requires a common physical proof address space, conditional-support
completeness, and all-policy target-relative soundness. It does not apply to independent
proof oracles, selected-policy-only soundness, single-target instances with zero conditional
entropy, or genuinely unbounded/continuous information channels. The function \(\Phi_N\)
remains an external relaxed-LDC input; (RSCD2) is a self-contained composition theorem, not
an unconditional impossibility result for all dPCPs.

## Relation to the deterministic trilemma

For deterministic \(D\), \(I(M;D)=H(D)\), and (RSCD2) reduces to the earlier
support--core--descriptor inequality. The new point is that arbitrary target-independent
public coins or verifier modes may have large \(H(D)\) but contribute no target information;
they cannot be used to evade the core/support tradeoff.
