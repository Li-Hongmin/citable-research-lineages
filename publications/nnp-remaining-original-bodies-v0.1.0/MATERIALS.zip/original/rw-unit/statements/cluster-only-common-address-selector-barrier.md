# Cluster-only common-address selector barrier

## Theorem

Consider a direct-product test with left faces \(X(k)\), shared faces \(X(s)\), and the
same low-agreement table \(T^*:X(k)\to\Sigma^k\) used in the GMWZ Lemma 6.2 proof.
Assume the source direct-product soundness implication:

\[
\Pr[T^*[A]|_B=T_2[B]]>\tau
\quad\Longrightarrow\quad
\exists F:X(1)\to\Sigma\ \text{with forbidden agreement with }T^* .
\tag{CS1}
\]

Let \(U_1,\ldots,U_J\subseteq X(k)\) be pairwise disjoint, with
\[
J\le\delta^{-C},
\qquad
\mu_k(U_i)\ge\delta^C,
\]
and let \(f_i:X(1)\to\Sigma\) be arbitrary. Define

\[
T_1[A]=
\begin{cases}
f_i|_A,&A\in U_i,\\
T^*[A],&A\notin\bigcup_iU_i.
\end{cases}
\tag{CS2}
\]

Then:

1. \(\operatorname{dist}(T_1[A],f_i|_A)=0\) for every \(A\in U_i\);
2. for every right assignment \(T_2\),
   \[
   \Pr[T_1[A]|_B=T_2[B]\ \wedge\ A\notin\bigcup_iU_i]\le\tau .
   \tag{CS3}
   \]

Consequently, the explicit density, disjointness, and outside-union clauses of
Lemma 6.2 do not imply any incidence regularity of the \(U_i\).

Now suppose a proposed repair exposes \(J\) pairwise distinct decoded cluster words as
target-labelled proof views
\[
\Pi^{(1)},\ldots,\Pi^{(J)}\in\Sigma_0^N
\]
in one common proof address space. If a target-independent randomized decoder makes at
most \(q\) adaptive queries and outputs the correct cluster index with probability at
least \(\alpha\) on every \(\Pi^{(s)}\), then

\[
\alpha J\le|\Sigma_0|^q.
\tag{CS4}
\]

In particular, a repair that exposes the full black-box family \(J=\delta^{-C}\) must pay

\[
q\log_2|\Sigma_0|
\ge \log_2\alpha+C\log_2(1/\delta).
\tag{CS5}
\]

For \(\delta=\Theta(1/k)\), fixed \(\Sigma_0\), and constant \(\alpha\), this is
\(q=\Omega(\log k)\).

## Proof

The first item of (CS2) is immediate. Outside the union of the \(U_i\), the table \(T_1\)
equals \(T^*\). If (CS3) failed for some \(T_2\), the implication (CS1) would produce
the forbidden global function \(F\) for \(T^*\), a contradiction. Thus arbitrary disjoint
heavy-set geometry is compatible with the two explicit cluster clauses.

For (CS4), fix the decoder's random tape. Its adaptive query strategy is a
\(|\Sigma_0|\)-ary decision tree of depth at most \(q\). The stopping transcripts on which
the decoder outputs the correct index for different \(s\) are disjoint: the same transcript
cannot have two different outputs. A prefix-free family of depth-\(q\) transcripts has at
most \(|\Sigma_0|^q\) leaves. Summing the success probabilities over the \(J\) proof views
and then averaging over the random tape gives
\[
\sum_{s=1}^J
\Pr[\operatorname{Dec}^{\Pi^{(s)}}=s]
\le|\Sigma_0|^q,
\]
which yields (CS4).

## Scope

This is a black-box barrier. It does not prove that the actual GMWZ list for every
assignment has size \(\delta^{-C}\), nor that the computation-generated assignment has
the adversarial form (CS2). It says that no proof using only the explicit Lemma 6.2
clauses can infer incidence smoothness or silently assume a constant-size index channel.
To evade (CS5), a construction must use additional semantic structure, avoid exposing all
admissible clusters as common-address target views, or abandon target-independent local
selection.

The source boundary is GMWZ Lemma 6.2 and its proof in [Section 6](https://arxiv.org/html/2512.12960#S6.2).
The decision-tree inequality (CS4) is the same prefix-free counting principle as the
indexed-label locality barrier, here instantiated on the cluster family.
