# Bottom--cover--cubic trichotomy for shared-proof closure

## Status and scope

This statement is a source-relative synthesis of three proved mechanisms. It is not a
universal impossibility theorem for dPCPs, and it does not claim that the present RW
construction satisfies its hypotheses. It gives a falsifiable normal form for a proposed
near-linear closure: a base-global proof must expose bottom or pay the cubic coding cost,
while a nontrivial BMVY/DDL cover must either remain a lift-word or pay for binding its
sheet information.

## Common base-global interface

Let

\[
  \Pi:\{0,1\}^k\longrightarrow\{0,1\}^P
\]

be an injective proof map. For each message coordinate \(i\) and claim
\(b\in\{0,1\}\), let \(V_{i,b}\) be a randomized adaptive verifier, and write
\(p_{i,b}(z)\) for its acceptance probability on proof word \(z\). Assume constants
\(\rho>0\) and \(0\le\beta<\alpha\le1\) such that

\[
 p_{i,m_i}(\Pi(m))\ge\alpha,\qquad
 \operatorname{dist}(z,\Pi(m))\le\rho
 \Longrightarrow p_{i,1-m_i}(z)\le\beta .
\tag{BCC.1}
\]

For the binary two-query case define

\[
 \tau_{\rho/2}:=
 \inf_{m,i}\inf_{\operatorname{dist}(z,\Pi(m))\le\rho/2}
       \bigl(p_{i,0}(z)+p_{i,1}(z)\bigr).
\tag{BCC.2}
\]

This is a half-radius, simultaneous two-branch quantity, not an average-over-coordinates
soundness parameter.

## Theorem (Bottom--cover--cubic trichotomy)

Consider a proposed closure with proof length

\[
  N=k+P\le k(\log k)^c
\tag{BCC.3}
\]

on infinitely many lengths.

### Base-global branch

If the proposed object is a single base-address proof map satisfying (BCC.1), then one of
the following holds.

1. **Bottom.** In the binary two-query case with \(\beta\le1/3\),

\[
  \tau_{\rho/2}<\frac23+\beta .
\tag{BCC.4}
\]

Thus a half-radius near-proof simultaneously rejects too much mass for the two claim
branches. If the correct branch is perfect-complete and the branch depth is allowed to
grow over a fixed alphabet \(\Sigma\) of size \(A\), the finite-alphabet RLDC bound instead
forces

\[
 Q_{r,A}:=1+2\sum_{j<r}A^j
   =\Omega_{A,\rho,\beta,c}\!\left(\frac{\log k}{\log\log k}\right),
\tag{BCC.5}
\]

whenever the near-linear regime survives. With imperfect completeness, the same statement
requires the independent-resampling gap-amplification hypothesis; then \(r\) in
\(Q_{r,A}\) is replaced by the amplified branch depth
\(O(r(\alpha-\beta)^{-2})\). Hence bottom cannot be combined with fixed finite locality.

2. **Cubic cost.** If the binary two-query condition
\(\tau_{\rho/2}\ge2/3+\beta\) holds, then message inlining gives a binary three-query LDC and

\[
  k+P=\Omega_{\rho,\beta}\!\left(\frac{k^3}{\log^6 k}\right).
\tag{BCC.6}
\]

The first alternative is therefore the only semantic escape from the cubic barrier in the
binary two-query base-global model.

### Cover branch

Suppose instead that the source object is a connected finite \(L\)-cover lift and the
postprocessor preserves the \(L\) distinguishable sheets. In the source-black-box model,
assume the sheet identity can enter a common-address decoder only through a target-independent
selector with a finite static descriptor, a bounded output list, or through the
target-normalized outer check in (BCC.1). A selector that makes \(q\) proof queries over a
fixed alphabet \(\Sigma\), has a \(d\)-bit static descriptor, and returns a list of at most
\(\Lambda\) sheet indices must satisfy

\[
  d+q\log_2|\Sigma|+\log_2\Lambda
  \ge \log_2 L-\log_2(1/\alpha_s),
\tag{BCC.7}
\]

where \(\alpha_s\) is the success probability on the correct sheet. If no selector or
target-normalized outer check is present in this model, the protocol has only a lift-word and
has not produced a base-address proof for RW/JK. If it adds an all-policy, target-relative
outer check instead, it returns to the base-global branch and is subject to
(BCC.4)--(BCC.6). An unbounded, address-dependent strategy is an explicit escape from this
finite-descriptor theorem, not a proof of base closure.

For the BMVY/DDL consecutive quotient source,

\[
  L=\ell_0^{\Theta(d_0^2)},\qquad d_0=\Theta(K),
\]

so (BCC.7) becomes

\[
  d+q\log_2|\Sigma|+\log_2\Lambda
     \ge \Theta(K^2\log\ell_0)-O(\log(1/\alpha_s)).
\tag{BCC.8}
\]

The cover agreement is only
\(1/L=\exp[-\Theta(K^2\log\ell_0)]\); consequently this source does not directly hit a
fixed inverse-polynomial soundness window. The binding inequality, rather than raw
agreement, is the usable obstruction in a near-linear address-scale argument.

## Proof

For the base-global branch, (BCC.1) gives positive proof distance by comparing two messages
that differ at one coordinate. In the binary two-query case, if (BCC.4) fails, the inline
bit and the two claim trees yield a three-query LDC; the cubic lower bound gives (BCC.6).
If (BCC.4) holds, it is exactly the bottom witness. For a growing finite-alphabet branch,
expose both adaptive \(A\)-ary decision trees. Their union has
\(Q_{r,A}\) proof and inline query positions, and the arbitrary-alphabet RLDC lower bound
gives (BCC.5) in the near-linear window. The imperfect-completeness version is the
independent-resampling amplification theorem, not a free consequence of (BCC.1).

For the cover branch, fix the selector's random tape. An adaptive depth-\(q\) transcript can
be padded to a word in \(\Sigma^q\), and each terminal transcript has only one output list.
Thus a fixed descriptor accounts for at most \(\Lambda|\Sigma|^q\) successful sheets.
Summing over at most \(2^d\) descriptors and averaging over the random tape gives

\[
  \alpha_s L\le 2^d\Lambda|\Sigma|^q,
\]

which is (BCC.7). Substitution of the BMVY/DDL quotient degree gives (BCC.8). If the
selector is absent, the cover lemma supplies no base global word: accepting the lift is a
different object, not a hidden proof of base closure. \(\square\)

## RW attachment boundary: family entropy cannot supply the next JK tree

The trichotomy applies to a family-level construction only after a common proof map has
actually been attached to the RW computation relation. The original RW Theorem 4.1/4.3 does
not obtain that attachment from the number of input strings alone. Let \(\nu_i\) be the
input length used to generate the stage-\(i\) histories, let
\(q_i=n_{i+1}=n_i^C\) be the next AVOID/JK seed length, and let a selected canonical history
have length at most

\[
  P_i\le T_i^a
\tag{BCC.9}
\]

for a fixed proof exponent \(a\). Even if one optimistically uses one selected history for
every \(x\in\{0,1\}^{\nu_i}\), the number of distinct aligned windows of any fixed JK depth
is at most

\[
  |\mathcal T_i|
     \le 2^{\nu_i}\frac{P_i}{2q_i}
     \le 2^{\nu_i} \frac{T_i^a}{2q_i}.
\tag{BCC.10}
\]

The first inequality is deliberately conservative: it allows overlapping windows and counts
all selected one-history-per-input objects. It does not count unrelated Merlin candidates,
which are not a single word-consistent RW history.

In the RW recurrence \(T_i=\max\{2^{cD^i n_0},n_{i+1}\}\) with \(C>D+1\), even the generous
choice \(\nu_i\le n_i\) gives

\[
  \nu_i+a\log_2(T_i+2)=o(q_i).
\tag{BCC.11}
\]

Consequently \(|\mathcal T_i|=2^{o(q_i)}\), and in particular it cannot exceed the
\(2^{q_i}\) tree-capacity threshold needed for a universal JK tuple-forcing argument. To
reach that threshold one must either supply \(\nu_i=\Omega(q_i)\) bits of independent input
entropy, concatenate \(2^{\Omega(q_i)}\) histories, or provide a compressed whole-tree
labeler that is not present in Theorem 4.1. The first two changes alter the RW recurrence or
make Solve exponential in \(q_i\); the last is a new Gate-I theorem, not a consequence of
per-coordinate smartness.

This is a parameter obstruction to one particular RW attachment strategy, not a proof that
the actual canonical history has no hard block. A single history may still contain an
outsider for semantic reasons; (BCC.10)--(BCC.11) only show that ambient family entropy
cannot force it by itself.

## What is and is not closed

The theorem closes a precise black-box program:

* fixed-locality binary base-global closure must expose bottom or pay cubic length;
* growing finite-alphabet bottom must pay at least the
  \(\log k/\log\log k\) query scale;
* a BMVY/DDL cover cannot be silently converted into a base word: sheet information must be
  queried, described, or replaced by a target-normalized outer check.

It does not prove that every future PCP is base-global, cover-indexed, or subject to the
listed finite-descriptor model. A genuinely new construction may leave these hypotheses by
changing the object, address space, soundness quantifier, or proof alphabet. Such an escape
is a new theorem obligation, not a notational variant of the existing closure.

## Sources

* [Binary bottom-or-cubic dichotomy](acrr-bottom-or-cubic-dichotomy.md).
* [Growing-locality threshold](../../mcsp-hardness-magnification/notes/242-growing-query-threshold-for-near-linear-closure-2026-08-17.md).
* [BMVY cover-sheet closure trilemma](../../mcsp-hardness-magnification/notes/215-bmvy-cover-sheet-closure-trilemma-2026-08-17.md).
* [BMVY/DDL parameter closure](../../mcsp-hardness-magnification/notes/202-bmvy-ddl-parameter-closure-for-cover-obstruction-2026-08-16.md).
