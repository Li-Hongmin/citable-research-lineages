# Profile-hitting necessity for average-to-coordinate composition

## Theorem

Fix a codeword coordinate `i` and an outer adaptive decoder `D_i` making at most `q_D`
queries to positions in `[M]`. On the honest codeword, let

\[
  V_i(\omega)=\{J_1(\omega),\ldots,J_{\ell(\omega)}(\omega)\}\subseteq[M]
\]

be the set of positions queried along the honest transcript for randomness `omega`, with
`ell(omega)\le q_D`. For a set `S\subseteq[M]`, define its honest-path hitting probability

\[
  h_i(S)=\Pr_\omega[V_i(\omega)\cap S\ne\varnothing],
  \qquad
  H_i(r)=\max_{S\subseteq[M],\ |S|\le r}h_i(S).
\]

Assume a **forcing-profile property** at coordinate `i`: for every set
`S\subseteq[M]` with `|S|\le r`, there is a candidate global proof `Pi_S` such that

1. all local answers outside `S` are the honest codeword symbols;
2. until the first query in `S`, the composed verifier sees exactly the honest transcript;
3. whenever the honest path first queries a position in `S`, the local answer at that
   position forces the composed verifier for the wrong declaration to accept.

Then any simultaneous coordinate-robust verifier whose wrong-declaration acceptance is at
most `delta` on every candidate proof must satisfy

\[
  H_i(r)\le \delta.
\tag{1}
\]

This is the exact black-box necessity: a decoder cannot hide a profile-rich family of local
errors on a set that it hits with probability larger than its soundness budget.

## Proof

Fix `S` and use the candidate proof `Pi_S`. Until the first honest-path query in `S`, every
local answer is honest by condition (1), so the adaptive decoder follows the same transcript
as on the honest codeword. By condition (3), the first query in `S` forces acceptance of the
wrong declaration. Therefore

\[
  \Pr[\text{wrong declaration accepts on }\Pi_S]
  \;\ge\; h_i(S).
\]

Robust soundness bounds the left-hand side by `delta`. Taking the maximum over `S` proves
(1). No sum of per-step query probabilities is used, so repeated positions and adaptive
queries are allowed.

## Consequences

### General profile-polytope form

The set-valued theorem has a more general profile formulation. For a candidate proof `Pi`,
let `e(Pi)=(e_j(Pi))_{j=1}^M` be the local wrong-symbol probabilities, using the same
convention as the singleton bridge: rejects and `bot` are not counted as wrong symbols. Let
`E_i` be the set of profiles realizable by candidate proofs. Assume fresh local randomness
and the following first-error forcing condition: whenever a wrong symbol is returned on the
honest query path, that first wrong symbol forces acceptance of the wrong declaration. Define

\[
  \Phi_i(e)=\mathbb E_\omega\left[
    1-\prod_{t=1}^{\ell(\omega)}(1-e_{J_t(\omega)})
  \right].
\tag{P1}
\]

Then simultaneous coordinate soundness with budget `delta` implies

\[
  \sup_{e\in E_i}\Phi_i(e)\le\delta.
\tag{P2}
\]

Indeed, conditioned on an honest path `omega`, the product is the probability that no local
call returns a wrong symbol before the decoder has a chance to leave that path. Fresh
randomness makes the factors independent. The complement is a first-error event, and the
forcing assumption maps it to wrong-declaration acceptance. The indicator profile
`e=1_S` gives `Phi_i(1_S)=h_i(S)`, so (P2) strictly contains the set-valued theorem. The
elementary inequality `1-prod_t(1-u_t)<=sum_t u_t` recovers the smoothness upper bound as a
relaxation of the exact profile functional.

### Smoothness gives the matching sufficient upper bound

If the honest path is `lambda`-smooth, then for every `S`

\[
  h_i(S)
  \le \sum_{t=1}^{q_D}\Pr[J_t\in S\mid\text{honest prefix at }t]
  \le q_D\lambda\frac{|S|}{M}.
\tag{2}
\]

Taking `|S|\le r` gives

\[
  H_i(r)\le q_D\lambda\frac{r}{M}.
\tag{3}
\]

For `r=floor(epsilon M)`, this recovers the `q_D lambda epsilon` scale in the singleton
robust dPCP bridge. The profile-hitting theorem shows what that sufficient estimate is
protecting against: all local error sets of the specified size must be harmless on the
honest path.

If the decoder never repeats a position, define
`w_i(j)=Pr[j\in V_i]`. Then `h_i(S)=sum_{j\in S}w_i(j)`, and (1) becomes the usual top-`r`
mass condition. For general adaptive decoders, `h_i` rather than a linear weight vector is
the correct invariant.

### Support-size lower bound

Let `U_i` be the union of all positions that can occur on an honest path and let
`s_i=|U_i|`. Suppose every honest path queries at least `v_i` distinct positions. If
`1\le r\le s_i`, choose `S` uniformly among the `r`-subsets of `U_i`. For a fixed path with
at least `v_i` distinct queried positions, the probability that `S` misses that path is at
most

\[
  \frac{\binom{s_i-v_i}{r}}{\binom{s_i}{r}}.
\]

Consequently,

\[
  H_i(r)\ge
  1-\frac{\binom{s_i-v_i}{r}}{\binom{s_i}{r}}.
\tag{4}
\]

Combining (1) and (4), a profile-rich construction with wrong-declaration budget `delta`
must satisfy

\[
  1-\frac{\binom{s_i-v_i}{r}}{\binom{s_i}{r}}\le\delta.
\tag{5}
\]

Using `\binom{s-v}{r}/\binom{s}{r}\le(1-v/s)^r\le e^{-vr/s}` gives the simpler necessary
condition

\[
  s_i\ge \frac{v_i r}{-\log(1-\delta)}.
\tag{6}
\]

This is sharp up to constants in the sparse regime `v_i r\ll s_i`; it does not assume that
the query distribution is uniform.

### Sharp minimax value under a support restriction

There is an exact form when every honest path makes exactly `q` distinct queries inside a
fixed support `U` of size `s`, and every `r`-subset of `U` is realizable as a forcing profile.
For any such decoder, averaging over a uniformly random `r`-subset `S\subseteq U` gives

\[
  \mathbb E_S\Pr_\omega[V(\omega)\cap S\ne\varnothing]
  =1-\frac{\binom{s-q}{r}}{\binom{s}{r}}.
\tag{9}
\]

Hence some forcing set has hit probability at least the right-hand side. This lower bound is
tight: sampling a uniformly random `q`-subset of `U` makes the hit probability equal to
(9) for every fixed `S`, so adaptivity cannot improve the minimax value. Therefore the
black-box optimum under these assumptions is exactly

\[
  \eta(s,q,r)=1-\frac{\binom{s-q}{r}}{\binom{s}{r}}.
\tag{10}
\]

For the current PCPP-block architecture, take `s=K`, `q=3`, and
`r=floor(epsilon M)=floor(4 epsilon K k)`. Equation (10) gives
`eta=1-(1-4 epsilon k+o(epsilon k))^3`, recovering (11) as a sharp minimax value rather
than only a lower bound. Thus, within this support-restricted black-box model, an escape must
expand the effective support (for example by a globally mixing decoder) or weaken the
profile/forcing assumptions; merely changing the adaptive strategy inside the same
`K`-position block cannot improve the tradeoff.

### The current 3-query PCPP-block architecture

In the displayed Gur--Minzer--Weissenberg--Zheng construction, a fixed coordinate samples
from a PCPP `B`-part of length `K`, while the global codeword has length `M=4Kk`. Thus
`s_i\le K`; with three distinct honest queries, `v_i=3`. For profile sets of density
`epsilon`, put `r=floor(epsilon M)`. Equation (5) implies the exact asymptotic condition

\[
  1-\left(1-4\epsilon k+o(\epsilon k)\right)^3\le\delta
\tag{11}
\]

whenever `4 epsilon k<1`. At wrong-declaration budget `delta=1/2`, this gives

\[
  \epsilon\le\frac{1-2^{-1/3}+o(1)}{4k}=O(1/k).
\tag{12}
\]

The singleton bridge's smoothness estimate gives the sufficient condition
`epsilon<1/(24k)` for `q_D=3` and `lambda\ge(4-o(1))k`. Thus the profile-rich necessary
condition and the smoothness sufficient condition agree to a constant factor for this
architecture. The agreement identifies a genuine support/error tradeoff rather than an
artifact of the `infty`-norm smoothness estimate.

## Why profile realization is an extra hypothesis

The forcing-profile property cannot be inferred from an average error bound alone. Consider
the following abstract local interface. The honest target is `y=0^M`. Fix a set
`S_0\subseteq[M]` of size `floor(epsilon M)`. There are only two candidate proofs:

* `Pi_0` returns `0` at every local position;
* `Pi_1` returns `1` on `S_0` and `0` outside `S_0`.

Every candidate proof satisfies

\[
  \frac1M\sum_{j=1}^{M}e_j(\Pi)\le\varepsilon,
\]

but the realizable error-set family is just `\{\varnothing,S_0\}`. An outer decoder whose
honest path avoids `S_0` has perfect coordinate soundness for this interface, regardless of
how concentrated its queries are elsewhere. In particular, the average bound does not imply
that any prescribed set `S` has a corresponding global proof `Pi_S`. This toy interface is
not claimed to be a full dPCP construction; it is a quantifier counterexample showing why a
general impossibility theorem must prove profile realization (or an equivalent richness
property) from the actual proof system.

## A checkable sufficient condition: private-variable patchability

The abstract forcing-profile hypothesis can be obtained from a concrete proof-graph
condition. Let `Pi_*` be an honest assignment to proof variables. For each patch label
`a\in A`, choose a set `U_a` of proof variables and an alternate local assignment on `U_a`.
Assume:

1. the sets `U_a` are pairwise disjoint;
2. `\partial a\subseteq[M]` contains every local position whose call can inspect a variable
   in `U_a`;
3. for every `S\subseteq A`, the assignment `Pi_S` obtained by applying the alternate values
   on `U_a` for `a\in S` is well-defined, all local calls outside
   `\partial S=\bigcup_{a\in S}\partial a` return the honest symbols, and a first call inside
   `\partial S` can force the wrong declaration.

Then the actual proof family contains forcing profiles supported on `\partial S`. If each
boundary has size at most `d`, then

\[
  \frac1M\bigl|\partial S\bigr|\le \frac{d|S|}{M},
\tag{13}
\]

and the profile-hitting theorem applies to the structured family
`{\partial S:S\subseteq A}`. If the boundaries are pairwise disjoint, the bound in (13) is
exact. Thus any attempt to evade the profile barrier must fail one of these patchability
conditions: output variables must be globally coupled, their constraint boundaries must
overlap heavily, or changing a boundary variable must not produce a forcing symbol. This is
the concrete proof-graph dichotomy that a general dPCP lower bound would need to analyze.

### A concrete global-coupling obstruction in the GM--W--Z wrapper

The repeated-base RLDC wrapper of Gur--Minzer--Weissenberg--Zheng realizes the
last alternative in a quantitative form. Its coordinate-specific PCPP blocks are
private storage locations, but the decoder first samples a repetition of the same
base word C_0(m), and the opposite-bit PCPP language consists of codewords whose
i-th message bit is flipped. The derived [repeated-base patch-boundary lemma](repeated-base-patch-boundary-for-gmwz-rldc.md)
shows that a candidate which changes only the i-th PCPP block has wrong-output
probability at most 2 xi + zeta_K. To reach a constant wrong-output probability,
it must corrupt an Omega(1) fraction of the repeated base block, namely Omega(K k)
positions.

This is an architecture-level realization of the global-coupling branch, not a
general dPCP lower bound. It turns the private-patch test into a concrete
measurement target for future constructions: a near-linear construction that
claims simultaneous coordinate robustness must either expose a genuinely local
forcing patch, or prove a replacement for this shared-base distance argument.

## Scope and non-implications

The forcing-profile property is an explicit hypothesis. Ordinary average dPCP, list-decoding,
or unique-decoding soundness does **not** imply that every small error set can be realized by
a single global proof. Therefore the displayed bounds are not a general impossibility theorem for all
dPCP/RLDC constructions. A general lower bound would need a profile-realization theorem, or
another mechanism proving that every candidate construction exposes enough adversarial local
profiles. Conversely, a construction can evade this barrier by making realizable profiles
highly correlated, using a globally mixing decoder, or changing the proof/query semantics.

## Relation to existing modules

* The singleton robust dPCP bridge supplies the smoothness upper bound in (3):
  [formal bridge](singleton-robust-dpcp-smooth-decoder-bridge.md).
* The family-level radius-to-relaxed-LDC theorem gives a separate code-level barrier once
  target-relative near-oracle soundness is available:
  [radius-to-relaxed-LDC barrier](radius-to-relaxed-ldc-barrier.md).
* The present theorem isolates the missing intermediate statement: whether a near-linear
  dPCP/PCPP with one global proof necessarily realizes enough local error profiles to force
  the hitting constraint (1).

## Source boundary

The block sizes used in the architecture corollary are from [Gur--Minzer--Weissenberg--Zheng,
TR25-217](https://eccc.weizmann.ac.il/report/2025/217/). The profile-hitting argument itself
is elementary and new to this project; it is conditional on the explicitly stated
forcing-profile property.
