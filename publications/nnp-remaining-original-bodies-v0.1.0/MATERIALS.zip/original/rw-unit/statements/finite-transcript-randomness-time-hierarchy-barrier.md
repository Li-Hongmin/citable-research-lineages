# Finite-transcript public-coin compilers pay the ambient nondeterministic time scale

## 定理

令 \(t:\mathbb N\to\mathbb N\) 是时间可构造函数。考虑一个**统一短-key、有限 transcript
public-coin 编译器**，它对 \(\mathsf{NTIME}(t)\) 中的每个语言 \(L\)（使用同一组上界
\(p(n)=n^{O(1)}\)、随机位数 \(r(n)\) 与 Merlin transcript 长度 \(\ell(n)\)）以及每个
输入 \(x\in\{0,1\}^n\) 提供：

* 一个长度至多 \(p(n)\) 的 key \(s\)；
* 一个确定性的、时间至多 \(p(n)\) 的 random-access evaluator \(E_L(x,s,a)\)；
* 一个 public-coin、可有任意有限轮次的 verifier。其公共随机带为
  \(R\in\{0,1\}^{r(n)}\)，每条固定随机带上 Merlin 的**全部** response transcript
  总长度至多 \(\ell(n)\)；verifier（包括 evaluator 调用）的确定性时间至多 \(p(n)\)。
  Merlin 只能看到已经发送的 public history，不能读取尚未公开的未来随机位；若模型在
  交互开始前公开完整 \(R\)，下面的一致性检查自动成立。非法 transcript 被 verifier
  拒绝。

其语义为：

\[
\begin{aligned}
x\in L &\Longrightarrow \exists s\ \exists\mathcal S\
  \Pr_R[V_L(x,s;R,\mathcal S(R))=1]\ge 2/3,\\
x\notin L &\Longrightarrow \forall s\ \forall\mathcal S\
  \Pr_R[V_L(x,s;R,\mathcal S(R))=1]\le 1/3.
\end{aligned}
\tag{FT1}
\]

其中 \(\mathcal S\) 可以根据 verifier 已发送的 public transcript 自适应地产生多轮
response；把它限制在每条随机带总长度 \(\ell(n)\) 即可。

令
\[
  u(n):=2^{r(n)}\bigl(p(n)+\ell(n)+r(n)\bigr)^{O(1)}.
\tag{FT2}
\]
若 \(u\) 取统一时间可构造上界且
\[
  u(n)\log u(n)=o(t(n)),
\tag{FT3}
\]
则不存在这样的统一编译器。

## 证明

固定任意 \(L\in\mathsf{NTIME}(t)\)。在输入 \(x\) 上，构造一个非确定性机器：先猜
key \(s\)；然后对每条 \(R\in\{0,1\}^{r(n)}\)，猜一条长度至多 \(\ell(n)\) 的完整
Merlin transcript \(\tau_R\)。机器逐一模拟 verifier，检查 transcript 的轮次和
长度是否合法，按需用 \(E_L(x,s,a)\) 回答 proof-address 查询，并把每个响应连同它
发生时的**已公开 verifier history**记录下来。全部随机带模拟完后，机器按 history
对这些记录排序（或插入一棵 trie）；若同一公开 history 出现两个不同响应则拒绝。
这一步强制表格来自一个不读取未来随机位的单一 Merlin strategy，且耗时仍为
\(2^{r(n)}(p(n)+\ell(n)+r(n))^{O(1)}\)。最后统计接受的随机带数量；当至少 \(2/3\)
的随机带接受时，机器接受。

若 \(x\in L\)，取 (FT1) 中的 key 与策略 \(\mathcal S\)，对每条随机带猜其合法的
真实 transcript。至少 \(2/3\) 的带接受，故机器接受。

若 \(x\notin L\)，任意未被一致性检查拒绝的 transcript table 都定义了一个合法的
deterministic 策略 \(\mathcal S_\tau\)：在 verifier 已发送的公开 history 下，按照
history-table 回答；未出现的 history 可用任意固定合法响应补全。该策略不读取未来
随机位。由 (FT1)，任何这样的策略至多在 \(1/3\) 的随机带上接受。因此非确定性机器
不会接受。

一致性检查不是形式装饰。若 verifier 先公开 \(R_1\)，再要求 Merlin 回答，随后公开
未来位 \(R_2\) 并接受当且仅当回答等于 \(R_2\)，逐条按完整 \(R=(R_1,R_2)\) 猜 transcript
会在所有随机带上接受，但不存在只看 history \(R_1\) 的合法策略达到超过 \(1/2\)。
history-table 检查恰好拒绝这张利用未来随机位的表。

枚举 \(2^{r(n)}\) 条随机带、猜测和验证每条长度至多 \(\ell(n)\) 的 transcript，以及
执行 evaluator，所需时间至多
\[
2^{r(n)}(p(n)+\ell(n)+r(n))^{O(1)}=u(n).
\]
因此 \(L\in\mathsf{NTIME}(u)\)。编译器对整个
\(\mathsf{NTIME}(t)\) 统一适用，遂有
\[
\mathsf{NTIME}(t)\subseteq\mathsf{NTIME}(u).
\]
但 (FT3) 下非确定性时间层次定理给出相反的严格分离，矛盾。 \(\square\)

## 指数时间推论

若 \(t_c(n)=2^{n^c}\)，并把共同的多项式上界写成
\[
p(n)+\ell(n)\le n^d
\]
（增大固定 \(d\) 不影响结论），则只要 \(r(n)=o(n^c)\)，(FT3) 成立。更精确地，若
\[
n^c-r(n)>(d+c+2)\log_2 n,
\]
便不能覆盖整个 \(\mathsf{NTIME}(2^{n^c})\)。

因此：

1. 任意固定多项式的随机位数与多项式总 transcript，不能统一覆盖全部 NEXP；
2. 允许多轮 Merlin 交互并不会改变这一结论，只要每条随机带的总 transcript 仍为
   多项式长度；
3. 若 \(r(n)=O(\log n)\)，则所有有限轮、多项式 transcript 的统一编译器都被排除，
   这严格包含单轮 \(O(\log n)\)-randomness barrier；
4. 要逃逸，必须让随机位数、每带 transcript、verifier/evaluator 时间中的至少一项
   回到所覆盖的环境时间尺度，或放弃统一覆盖整个时间类。

## 与 ACRR/RW 的关系

该定理直接覆盖 finite-horizon 的 post-coordinate Merlin 策略：将坐标揭示后的所有
多轮回答合并为每条随机带的 transcript table 即可。因此，“把单轮 response 改成
有限轮交互”不是普适短-key 编译器的复杂度逃逸。

它仍然不是单一 RW history 的不可能性定理：

* 一个只针对固定关系或固定输入的策略不触发对整个 \(\mathsf{NTIME}(t)\) 的统一量词；
* 若策略 transcript 长度接近 \(t(n)\)，(FT3) 可能不成立；
* 若 verifier 使用隐藏随机性、连续对象或非有限 transcript，需先将其编码进新的
  复杂度模型，不能直接套用本定理；
* 已知 NEXP PCP 的证明通常是环境尺度长度，因而不满足短 transcript/evaluator 前提。

所以该结果把现有 ACRR 的 residual class 精确分成两类：有限 transcript 策略被
时间层次 barrier 关闭；剩下的必须是真正环境尺度交互、非有限信息模型，或只针对单一
RW 实例的 target-specific 构造。

## 与 C145 的关系和证据边界

C145 是本定理的单轮、每条随机带一个 response 的特例。这里的新内容是允许任意有限
轮次和 adaptive Merlin transcript，同时只按每条随机带的总 transcript 长度计费。
证明只使用 response-table 枚举与非确定性时间层次定理；不声称
\(\mathsf{NEXP}\not\subseteq\mathsf{NP}\) 之外的未知类分离，也不把 universal
compiler 的 barrier 外推到单一 RW history。
