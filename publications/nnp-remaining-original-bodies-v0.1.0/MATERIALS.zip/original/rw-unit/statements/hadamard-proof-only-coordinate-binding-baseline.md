# Hadamard proof-only coordinate binding：指数长度正向基线

## 地位

这是一个显式的、target-relative 的正向基线，不是近线性 ACRR 定理，也不验证
RW computation relation。它隔离出一个容易被混淆的事实：**同一 global proof 上的
逐坐标鲁棒绑定本身并不矛盾；困难在于把 proof 压到近线性地址尺度，并同时绑定
计算历史。**

该构造正是 Gur--Ramnarayan--Rothblum Theorem 4.26 中 Hadamard canonical proof
的 proof-only 版本。原文的 PCPP 还带 input-proximity test；这里把消息 `x` 视为
被 global proof 编码的目标，并只保留 affine constraint test。

## 构造

令消息为 `x in {0,1}^n`，共同 proof 地址空间为
`{0,1}^n`，canonical proof 为 Hadamard 词

\[
  H_x(z)=\langle z,x\rangle \pmod 2.
\]

它与 affine subspace `S_{A,b}={x:Ax=b}` 无关，因此同一个 `H_x` 可供所有
`(A,b)` 使用。给定 proof oracle `pi`，一次 affine constraint test 随机取
`z in {0,1}^n` 和 `v in {0,1}^r`，查询 `pi(z)`、`pi(z+A^T v)`，接受当且仅当

\[
  \pi(z)\oplus\pi(z+A^Tv)=\langle v,b\rangle.
\]

对 `t` 个独立随机的 `(z,v)` 重复该 test，并要求全部通过。查询数为 `2t`，
proof 长度为 `N=2^n`，且 verifier、地址生成和随机性均为统一的 `poly(n)` 时间。

## 定理

若 `Ax=b`，则在 `H_x` 上 verifier 完美接受。若 `Ax != b`，且

\[
  \Delta_H(\pi,H_x)\le \rho N,
\]

则接受概率满足

\[
  \Pr[V_{A,b}^{(t)}(\pi)=1]
  \le 2^{-t}+2t\rho.
\]

特别地，对坐标半空间 `A=e_i^T`、错误声明 `b\ne x_i`，固定 `v=1` 的单次
test 已给出 `2` 次 proof 查询、完美正确性，以及错误接受率至多 `2\rho`。
取例如 `rho<1/16` 和 `t=2`，得到严格的 `beta<1/2`。

### 证明

在 canonical proof `H_x` 上，

\[
 H_x(z)\oplus H_x(z+A^Tv)
 =\langle A^Tv,x\rangle
 =\langle v,Ax\rangle.
\]

当 `Ax=b` 时每个 test 都通过。若 `d=Ax\oplus b\ne0`，对均匀 `v` 有
`Pr_v[\langle v,d\rangle=0]=1/2`，故在没有 corruption 的情况下，`t` 个
独立 tests 全部通过的概率为 `2^{-t}`。对任意一个 test，两个查询位置落在
`pi` 与 `H_x` 的差异集合中的概率至多 `2rho`；对 `t` 个 tests 用 union bound
至多增加 `2t rho`。合并即得结论。坐标半空间的 `v=1` 情形中，canonical
equation 在错误声明下恒失败，故只剩同样的两点 corruption 概率。
\(\square\)

## 对 ACRR 主线的含义

该基线满足：同一 proof、同一地址空间、proof-only 坐标查询、完美完备性，以及
正半径的 **target-relative** 坐标 soundness。它明确关闭了“消除 input query
在逻辑上必然不可能”的说法。

但它不满足三项更强要求：

1. `N=2^n` 是指数长度，不是 near-linear proof；
2. 它只绑定 affine output constraints，不检查 RW 的 computation relation；
3. soundness 只针对 `pi` 位于目标 `H_x` 的半径邻域。若要求对所有 arbitrary
   proof 都 sound，则另一个消息 `x'` 的 `H_{x'}` 可能是错误 half-space 的
   完整 proof，必须改用 family-level 量词或额外 target commitment。

因此，下一步真正有内容的正向问题是：能否把 Hadamard/LDE 的共同编码替换成
近线性、可局部纠错的 proof，同时让同一 proof 还验证 `h in H_x` 的 computation
relation。若一个候选 shared synthesis 具备 C79 的 robust half-space 条件，它会
立即进入 RLDC barrier；若只改进坐标层而不绑定 relation，则仍停留在本基线的
“指数长度 coordinate channel”。

## 来源与边界

GRR Theorem 4.26 明确使用 `H_x(z)=<z,x>` 作为 affine-subspace 的线性 canonical
proof，并给出 self-correctable、strongly canonical、robust PCPP。这里的 proof-only
verifier 与上述概率界是对其 Hadamard test 的直接推导，不把 GRR 原文改写成
near-linear ACRR。来源：[Gur--Ramnarayan--Rothblum, *Relaxed Locally Correctable
Codes*, Theorem 4.26](https://theoryofcomputing.org/articles/v016a018/v016a018.pdf)。
