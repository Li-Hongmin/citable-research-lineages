# Cover-sheet binding Closure Gate

## Statement

Let \(\rho:Y\to X\) be a finite connected \(\ell\)-sheet cover. A shared-top
tester may therefore have an accepting lift-word on \(Y\) while no comparable
word exists on the base address space \(X\). Consider any postprocessor that
claims to preserve the \(\ell\) sheets while returning a base-address object from
one common proof space \(\Sigma^P\).

The postprocessor must pay one of the following costs.

### 1. Keep the lift-word

The output may remain a word on \(Y\), or an equivalent cover object. This is
compatible with the cover obstruction, but it is not a base-word closure and
cannot be inserted into a JK parent relation defined on \(X\)'s addresses.

### 2. Bind the sheet explicitly

Suppose a target-independent adaptive selector receives a \(d\)-bit static
descriptor \(\sigma_s\) for sheet \(s\), makes at most \(q\) proof-symbol queries,
and outputs \(s\) with probability at least \(\alpha\) on the proof for sheet
\(s\). Then

\[
  d+q\log_2|\Sigma|
  \,\ge\,
  \log_2\ell-\log_2(1/\alpha).
\tag{CS1}
\]

The bound is valid for variable stopping times, adaptive addresses, and arbitrary
randomness. A list-valued selector with list size at most \(\Lambda\) obeys the
same inequality with the additional term \(+\log_2\Lambda\) on the left.

### 3. Bind the sheet through a coordinate-robust base code

Assume instead that the sheet labels are embedded as a full \(K\)-bit target
family, \(\ell=2^K\) (or that the preserved sheet family contains such a
subfamily), and that the postprocessor supplies one common proof/address space,
positive target-relative radius, perfect correct-branch completeness, and
supportwise wrong-claim soundness over a fixed alphabet \(A=|\Sigma|\). Let \(S\)
be its possibly unbounded standard-Borel policy object. In the near-linear regime
\(N=K(\log K)^c\), with the GGS radius condition in force, either

\[
  Q_{r,A}=\Omega\!\left(\frac{\log K}{\log\log K}\right),
\tag{CS2}
\]

or the policy carries essentially the whole sheet index,

\[
  I(M;S)=K-o(K).
\tag{CS3}
\]

If the policy is generated from a target-dependent descriptor \(D\) and
target-independent randomness, then (CS3) implies

\[
  H(D)\ge K-o(K).
\tag{CS4}
\]

Thus a polylogarithmic canonical key or finite sheet summary cannot be the
missing base-binding mechanism in the low-locality window.

## Proof

For (CS1), fix the decoder randomness. Its adaptive computation is a depth-\(q\)
decision tree. Pad every terminal transcript to length \(q\) with a dummy symbol.
For a fixed \((r,\sigma)\), one padded transcript has one terminal output, so it
can certify at most one sheet. Hence at most \(|\Sigma|^q\) sheets are correctly
identified for each descriptor and random tape. Averaging and summing over the
at most \(2^d\) descriptors gives

\[
  \alpha\ell\le 2^d|\Sigma|^q.
\]

If a terminal output is a list of size \(\Lambda\), the right side becomes
\(\Lambda2^d|\Sigma|^q\), proving the list variant.

For (CS2)--(CS4), apply the standard-Borel policy fiber theorem to the full
\(K\)-bit sheet family. If \(I(M;S)\le\gamma K\), a fiber of size
\(2^{(1-\gamma-o(1))K}\) contains a linearly shattered message set. Inline the
common proof into a finite-alphabet relaxed local decoder with

\[
  Q_{r,A}=1+2\sum_{j<r}A^j.
\]

The GGS lower bound then gives (CS2) in the stated radius window. Therefore every
route with \(Q_{r,A}=o(\log K/\log\log K)\) must have
\(I(M;S)=K-o(K)\), which is (CS3). If \(M\to D\to S\), data processing gives
\(I(M;S)\le H(D)\), proving (CS4).

## BMVY/DDL substitution

For the consecutive finite covers used in the BMVY/DDL source family,

\[
  \log_2\ell=\Theta(d_{\mathrm{HDX}}^2\log_2\ell_0).
\tag{CS5}
\]

Consequently every target-independent base selector pays

\[
  d+q\log_2|\Sigma|
  =\Omega(d_{\mathrm{HDX}}^2\log\ell_0)
\]

up to the completeness term. If the same sheets are encoded as a full robust
target family, the low-locality alternative additionally pays

\[
  I(M;S)=\Theta(d_{\mathrm{HDX}}^2\log\ell_0)-o(d_{\mathrm{HDX}}^2\log\ell_0)
\]

or the locality in (CS2). This is a source-specific binding theorem; it does not
assert that all dPCPs have covers, nor that every cover admits a full binary sheet
subfamily.

### 4. Perfect-complete sheet binding has an explicit RLDC cost

The transcript inequality is not the only cost when the selector is required to be
perfectly complete and to remain correct on a positive-radius neighborhood. Let
\(K=\lfloor\log_2\ell\rfloor\), choose \(2^K\) sheets, and encode their labels as
\(K\)-bit messages. Suppose a single target-independent adaptive selector
\(\mathsf{Sel}\) makes at most \(q\) queries to a proof word in \(\Sigma^P\), and set
\[
  A:=|\Sigma|\ge 2,\qquad Q:=\sum_{j=0}^{q-1}A^j.
\]
Assume it satisfies
\[
  \mathsf{Sel}(\Pi(m))=m
  \quad\text{with probability one},
\tag{CS6.1}
\]
and, for every \(m\) and every \(z\) with \(d_H(z,\Pi(m))\le\rho P\), outputs a
wrong non-\(\bot\) sheet with probability at most \(\beta<1\). If
\(\sigma:=1-\beta\) and
\[
  \rho>P^{-\sigma/(2Q)},
\tag{CS6.2}
\]
then, for all sufficiently large \(K\),
\[
 P\ \ge\
 \left(
 \frac{\sigma^2 K}
 {38Q^4\log^2 A\,\log^2 K}
 \right)^{1+1/\lceil Q/\sigma\rceil}.
\tag{CS6.3}
\]

Thus fixed \(A,q,\rho,\beta\) rule out \(P=K\operatorname{polylog}K\), even if the
cover degree itself is only \(2^K\). In the BMVY/DDL regime
\(K=\Theta(d_{\mathrm{HDX}}^2\log\ell_0)\), this is an explicit
length--sheet-entropy lower bound, stronger than the raw selector entropy inequality
whenever the positive-radius and perfect-completeness hypotheses hold.

#### Proof

For each message coordinate \(j\), run \(\mathsf{Sel}\) and output the \(j\)-th bit of
its returned index, or \(\bot\) if the selector aborts. On \(\Pi(m)\) this is perfectly
complete by (CS6.1). On a \(\rho P\)-near word, a wrong output bit implies that the
selector returned a wrong non-\(\bot\) sheet, so its error probability is at most
\(\beta\). Exposing the complete \(A\)-ary decision tree of \(\mathsf{Sel}\) gives a
non-adaptive decoder with at most \(Q=\sum_{j<q}A^j\) proof queries. Hence the proof map
is a non-adaptive \((Q,\rho,\sigma)\)-RLDC for the \(K\)-bit sheet messages.

If two distinct proof words were within \(\rho P\), perfect completeness on one word and
the wrong-sheet bound for the other would give \(1\le\beta\). The proof image therefore
has relative distance \(>\rho\). Goldberg--Gur--Saraogi's arbitrary-alphabet RLDC lower
bound then gives
\[
 \frac{K}{\log^2 K}
 \le 38Q^4\sigma^{-2}\log^2 A\;
 P^{1-1/(\lceil Q/\sigma\rceil+1)}.
\]
The radius condition is exactly (CS6.2); rearranging yields (CS6.3). The argument uses
no finite-support assumption on the selector's internal strategy, only its common proof
query bound and the target-independent output rule.

This is still source-relative: a cover-free source, a lift-word target, a selector with
nonconstant locality, or a target-normalized protocol outside the stated perfect-complete
sheet-index model is not covered. The coding theorem is an additional consequence of
explicit sheet binding; it does not claim that ordinary dPCP/list soundness supplies a
selector.

## Scope

The theorem is a closure gate, not a \(P\ne NP\) proof. It applies only when the
postprocessor preserves sheet entropy and uses a common proof/address space. A
cover-free construction, a target-normalized outer check with a different coding
object, or an intentionally accepted lift-word lies outside the stated branches
and must be analyzed separately rather than silently counted as base closure.

## Source alignment

The cover premise and the parameter estimate (CS5) are the source-specific facts
recorded in notes 202 and 267. The standard-Borel branch is Theorem 6.8 and note
288. The explicit RLDC inequality (CS6.3) is Goldberg--Gur--Saraogi, Theorem 1
([arXiv:2511.21659](https://arxiv.org/abs/2511.21659)), after the decision-tree
expansion above. The theorem is their explicit cover-sheet synthesis; it introduces
no claim that ordinary list or distributional soundness supplies the common base word.
