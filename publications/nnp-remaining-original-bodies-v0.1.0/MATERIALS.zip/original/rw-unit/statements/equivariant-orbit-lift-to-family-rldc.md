# Equivariant orbit lifting: when one target already contains a family

## Theorem

This module isolates a precise symmetry condition under which a single-target ACRR
interface is not genuinely single-target. The condition is stronger than public address
randomization: the verifier itself must be target-independent and covariant, and the proof
map must carry the whole target orbit.

Let a finite group \(G\) act on coordinates \([k]\) by permutations \(\pi_g\), and on message
bits by

\[
  (g m)_{\pi_g(i)}=m_i\oplus\chi_g(i),
  \qquad \chi_g(i)\in\{0,1\}.
\tag{EOL1}
\]

Let \(G\) also act on the proof space \(\Sigma^N\) by Hamming isometries \(\rho_g\). Assume
the actions and their address relabellings are uniformly computable, and let \(m^0\) be a
base target. Write

\[
  \mathcal M=Gm^0,
  \qquad C(gm^0)=\rho_g C^0,
\tag{EOL2}
\]

where \(C^0\in\Sigma^N\), and assume this definition is well-defined: every element of the
stabilizer of \(m^0\) fixes \(C^0\).

For every coordinate \(i\) and declaration \(b\), let \(V_{i,b}\) be one
target-independent randomized verifier making at most \(q\) adaptive proof queries. Let

\[
  p_{i,b}(z)=\Pr[V_{i,b}^{z}=1].
\]

Assume covariance of the *acceptance semantics*, not merely covariance of query addresses:

\[
  p_{\pi_g(i),\,b\oplus\chi_g(i)}(\rho_g z)=p_{i,b}(z)
  \qquad(g\in G).
\tag{EOL3}
\]

Suppose the base target satisfies, for constants \(\rho>0\) and
\(\alpha>\beta\),

\[
  p_{i,m^0_i}(C^0)\ge\alpha,
  \qquad
  \operatorname{dist}(z,C^0)\le\rho
  \Longrightarrow
  p_{i,1-m^0_i}(z)\le\beta
\tag{EOL4}
\]

for every \(i\). Then the orbit code \(C:\mathcal M\to\Sigma^N\) satisfies, for every
\(m=gm^0\), coordinate \(j=\pi_g(i)\), and word \(z\) with
\(\operatorname{dist}(z,C(m))\le\rho\),

\[
  p_{j,m_j}(C(m))\ge\alpha,
  \qquad
  p_{j,1-m_j}(z)\le\beta.
\tag{EOL5}
\]

In particular, one target plus exact target/proof covariance yields a family-level,
target-relative ACRR on the entire orbit, using one proof address space and one verifier
family. The proof map is pairwise at distance \(>\rho\) on \(\mathcal M\), and hence
injective.

After the standard acceptance-frequency thresholding, the same proof map is a weak
positive-radius relaxed local decoder for the message coordinates with locality

\[
  Q=O\!\left(q(\alpha-\beta)^{-2}\right).
\tag{EOL6}
\]

If \(\mathcal M=\{0,1\}^k\) (for example, the full bit-flip orbit) and the DGL/RLDC
parameter window applies, any near-linear \(N=k\operatorname{polylog}k\) construction with
fixed finite \(\Sigma,q,\rho,\alpha-\beta>0\) is ruled out by the family-level relaxed-LDC
length barrier.

### Approximate covariance

The same proof is stable under a uniform semantic defect. Replace (EOL3) by

\[
  \left|
    p_{\pi_g(i),\,b\oplus\chi_g(i)}(\rho_g z)-p_{i,b}(z)
  \right|\le\xi
  \qquad\text{for all }g,i,b,z.
\tag{EOL7}
\]

Then (EOL5) holds with completeness \(\alpha-\xi\) and wrong-bit soundness
\(\beta+\xi\). Hence, whenever

\[
  \alpha-\beta-2\xi>0,
\tag{EOL8}
\]

the orbit still yields a family-level relaxed decoder with

\[
  Q=O\!\left(q(\alpha-\beta-2\xi)^{-2}\right).
\tag{EOL9}
\]

Thus a full-orbit near-linear construction cannot evade the family barrier by a small
implementation or compilation error: it must break covariance by at least half the original
acceptance gap on some orbit relation, or pay one of the other escape costs above.

## Proof

Fix \(m=gm^0\) and \(j=\pi_g(i)\). By (EOL1),

\[
  m_j=m^0_i\oplus\chi_g(i).
\]

Using (EOL2)--(EOL3),

\[
  p_{j,m_j}(C(m))
  =p_{\pi_g(i),m^0_i\oplus\chi_g(i)}(\rho_g C^0)
  =p_{i,m^0_i}(C^0)\ge\alpha.
\]

If \(\operatorname{dist}(z,C(m))\le\rho\), Hamming-isometry of \(\rho_g\) gives
\(\operatorname{dist}(\rho_{g^{-1}}z,C^0)\le\rho\). Applying (EOL3)--(EOL4) to the
wrong declaration gives

\[
  p_{j,1-m_j}(z)
  =p_{i,1-m^0_i}(\rho_{g^{-1}}z)\le\beta.
\]

This proves (EOL5). If \(m\ne m'\) but
\(\operatorname{dist}(C(m),C(m'))\le\rho\), choose \(j\) with \(m_j\ne m'_j\).
Completeness for \(m'\) and wrong-bit soundness for \(m\), both using the same
target-independent verifier \(V_{j,\cdot}\), would imply \(\alpha\le\beta\), a
contradiction. Thus \(C\) has pairwise distance \(>\rho\), and in particular is injective.

For each requested \(j\), estimate the acceptance probabilities of \(V_{j,0}\) and
\(V_{j,1}\) to additive error less than \((\alpha-\beta)/4\), and output a bit only when
exactly one branch crosses the midpoint threshold; otherwise output \(\bot\). On \(C(m)\) the
correct branch has mean at least \(\alpha\), and on every \(\rho\)-near word the wrong branch
has mean at most \(\beta\). Independent repetition and Hoeffding's inequality give (EOL6).
The orbit construction is therefore a family-level target-relative relaxed decoder, so any
applicable family-level RLDC/LDC lower bound applies. \(\square\)

## Exact escape classification

The theorem does **not** say that every symmetric proof family yields an RLDC. It requires
all three of the following:

1. the orbit is large enough to carry the message entropy;
2. the verifier is target-independent, rather than selected by a hidden target descriptor;
3. covariance holds for acceptance semantics, not only for proof-address permutations.

Therefore a putative near-linear single-target construction can avoid this lift only by
making at least one escape explicit: its reachable target set is small, its verifier or
address space depends on the target, its proof action is not covariant, its radius/gap
degenerates, or its proof length leaves the family-level lower-bound window. Publicly
randomizing addresses alone is not enough; C133 shows that such a wrapper can preserve an
equivariant non-exchangeable error profile.

The stabilizer condition in (EOL2) is essential for a well-defined orbit code. If two group
elements map \(m^0\) to the same target but produce different proof words, one must either
refine the message to a coset-labelled target or pay an explicit descriptor; it is not a
single-valued family code.

## Scope boundary

This is a symmetry-to-family reduction, not an unconditional impossibility theorem for all
single-target RW/JK interfaces. It is useful precisely because its assumptions are directly
checkable in a proposed construction. In the full bit-flip orbit, however, it removes the
single-target quantifier escape completely: exact target-independent covariance would already
place the construction in the family-level RLDC barrier.

## Relation to existing modules

* [Radius-to-relaxed-LDC barrier](radius-to-relaxed-ldc-barrier.md) supplies the final
  family-level length obstruction.
* [Equivariant address actions do not imply exchangeable index errors](equivariant-symmetrization-does-not-imply-exchangeability.md)
  is weaker in a different direction: it rules out free public symmetrization, whereas the
  present theorem shows when exact covariance is strong enough to create a whole message
  family.
* [Payload lifting family barrier](payload-lifting-family-barrier.md) handles a freely varying
  payload with payload-oblivious verifiers; the orbit theorem handles a full target orbit and
  makes the required covariance explicit.

## Evidence boundary

The proof is self-contained and uses only group covariance, Hamming isometry, threshold
amplification, and the external family-level relaxed-LDC theorem. It does not assert that
current dPCP constructions satisfy (EOL1)--(EOL4), nor that the resulting family-level
barrier is unconditional for arbitrary target-specific verifiers.
