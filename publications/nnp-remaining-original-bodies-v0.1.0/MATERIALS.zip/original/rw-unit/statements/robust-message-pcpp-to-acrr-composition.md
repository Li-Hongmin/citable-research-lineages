# Robust message-PCPP 到 shared-proof ACRR 的组合定理

## 定理地位

这是一个条件性、参数化的组合定理。它把 `Bind_x` 拆成一个更具体的接口：
一个直接访问消息 oracle 的 relation-PCPP，和一个 strong-LTC/RLDC 外层。它不声称
现有 relation-PCPP 已满足这些条件；尤其保留了 ordinary PCPP 只对远离关系集合的
输入给 soundness 这一边界。

## 设置

固定实例 `x`。令 `H_x subseteq {0,1}^k` 是非空的合法消息集合，并假设所有合法消息
在坐标 `i` 上给出同一个目标位 `f_x[i]`。取二元编码

```text
C : {0,1}^k -> Sigma^N
```

满足以下外层接口：

1. `C` 的相对距离大于 `2 delta`；
2. 有一个 strong-LTC tester `T`，其中 `0<rho_T<1`，在 codeword 上完美接受；若
   `dist(y, C({0,1}^k)) > delta`，则 `Pr[T(y)=1] <= 1-rho_T`；
3. 有一个 relaxed local decoder `D_j`。在精确 codeword `C(m)` 上它输出 `m_j`
   （完美完备）；若 `dist(y,C(m)) <= delta`，则
   `Pr[D_j(y) notin {m_j, bottom}] <= eta_D`。

这里 `T`、`D` 的随机性相互独立。

再给一个对消息 oracle 的 relation-PCPP `B_x`。它同时访问消息 `m` 和 auxiliary
proof `pi`，最多查询 `q_M` 个消息位置及 `q_P` 个 proof 位置，并满足：

* 若 `m in H_x`，存在 `pi_m` 使 `B_x^{m,pi_m}` 完美接受；
* 若 `dist(m,H_x) > gamma`，则对任意 `pi`，
  `Pr[B_x^{m,pi}=1] <= beta_B`。

最后要求一个 target-separation 条件：对每个坐标 `i`，

```text
m_i != f_x[i]  =>  dist(m,H_x) > gamma.
```

这一步是必要的接口假设：普通 PCPP 的 proximity soundness 并不自动排除距离
`gamma` 以内但输出位错误的消息。

## 结论

令

```text
R = ceil(log(epsilon_far) / log(1-rho_T))
```

其中 `epsilon_far < 1/2`。在 proof address space

```text
Y = C(m) || pi
```

上，对坐标 `i` 和声明位 `b` 定义 verifier `V_{x,i,b}`：

1. 独立运行 `T` 共 `R` 次；有一次拒绝就拒绝；
2. 用 `D` 模拟 `B_x` 对消息 oracle 的 `q_M` 次查询，直接读取 `pi` 的 `q_P`
   个位置；若模拟的 `B_x` 拒绝就拒绝；
3. 再用 `D_i` 解码坐标，只有输出恰为 `b` 时接受。

则所有坐标和声明位共用同一个 `Y` 地址空间，并且：

* 正确声明 `b=f_x[i]` 在 honest proof `C(m_x)||pi_{m_x}` 上完美接受；
* 错误声明的接受率至多

```text
beta_ACRR <= max{ epsilon_far, beta_B + (q_M+1) eta_D }.
```

因此只要 `beta_B < 1/2`、`eta_D <= (1/2-beta_B)/(2(q_M+1))`，并取
`epsilon_far < 1/2`，便得到固定目标的 coordinate-robust verifier。查询数为

```text
R q_T + q_P + (q_M+1) q_D.
```

如果所有组件由 `x`、地址和 `log N` 在 `poly(|x|,log N)` 时间统一生成，则组合也
保持该地址生成尺度；proof 长度是 `N+|pi|`，其中 `|pi|` 是 relation-PCPP 的
auxiliary proof 长度。

## 证明

取任意候选 proof `Y=y||pi`。

### 远离外层 code

若 `dist(y,C({0,1}^k)) > delta`，`R` 次独立 tester 全部通过的概率至多
`(1-rho_T)^R <= epsilon_far`。verifier 只有在全部通过时才可能接受，所以错误声明
的接受率也至多 `epsilon_far`。

### 接近一个 codeword

否则存在 `m'` 使 `dist(y,C(m')) <= delta`；由于 `C` 的距离大于 `2 delta`，该
`m'` 唯一。把每一次消息解码和最后的坐标解码都称为一次 decoder call。由 RLDC
条件，所有 `q_M+1` 次 call 同时返回正确消息位的概率至少

```text
1 - (q_M+1) eta_D.
```

在这个 good 事件上，模拟的 `B_x` 与直接运行 `B_x^{m',pi}` 完全相同，且最后解码
位为 `m'_i`。

若 `m'_i != f_x[i]`，target-separation 给出
`dist(m',H_x)>gamma`，所以 `B_x` 在任意 `pi` 上的接受率至多 `beta_B`。若
`m'_i=f_x[i]`，则错误声明 `b=1-f_x[i]` 在 good 事件上已经因最后的坐标检查而
拒绝。将 decoder call 失败的概率用 union bound 加回，错误声明的接受率至多
`beta_B+(q_M+1)eta_D`。两种情况合并即得结论。

完美完备性来自：选择任意 `m_x in H_x`、其 PCPP proof `pi_{m_x}`，所有 `T` 测试
通过，所有 `D` 在精确 codeword 上返回正确位，且 `B_x` 完美接受。

## 这条定理真正改变的接口

它把旧的 `Bind_x(C(m))` 黑箱拆为三项可独立检查的条件：

1. message-PCPP 对非法消息的 soundness 半径 `gamma`；
2. 合法消息与错误输出位之间的 target-separation；
3. 外层 RLDC 在 `delta` 半径内的逐位错误率 `eta_D`。

因此普通 pair-language PCPP 仍不够：其 soundness 通常只在
`dist(m,H_x)>=gamma` 时生效，而 RW 的 computation histories 未自动满足
“错误输出位的消息都离 `H_x` 超过 `gamma`”。若这一 separation 失败，就必须把
relation-PCPP 本身升级为对所有错误目标消息的 exact/robust target-binding test，
而不能只套外层 code。

最小边界例子是 `H_x={0^k}`、`f_x=0^k`：消息 `e_i` 只距合法集合 `1/k`，却在第
`i` 位声明错误。若 `gamma>=1/k`，普通 proximity soundness 对该消息不作任何
保证；这说明 target-separation 是组合定理的真实假设，而不是证明中的记号冗余。

### 对 raw RW history 的直接诊断

若一个 computation history `h in H_x` 把输出位 `f_x[i]` 以单独的 systematic bit
slot `j_i` 存放，令 `h'` 只翻转该 slot。则 `h' notin H_x`，但

```text
dist(h',H_x) <= 1/T.
```

所以任何常数 `gamma` 的 target-separation 都被 raw history 立即否定。要让本组合
定理适用于 RW，必须先把输出/关系编码成相反目标类之间有常数距离的 message
representation；这正是 shared target-binding code/PCPP 的新内容，而不是普通
coordinate decoder 可以补上的小修正。

## 对 RW/JK 的判定

若能为 RW 的 `H_x` 构造一个 `poly(n,log T)` 地址生成的 message-PCPP，并同时证明
上述 target-separation，则本定理直接给出 shared-proof ACRR；这是一个明确的正向
晋级接口。若 `H_x` 存在只改少数 history bits 就翻转输出位的消息，或 PCPP 只能对
远离 `H_x` 的消息 sound，则该候选不能宣称完成 ACRR，缺口精确落在 relation
target-binding，而不是 coordinate decoder。

## 证据边界

这是从 tester、RLDC 和 PCPP 三组量词直接推导的组合结果，不把它归因于任何单篇
外部论文。ordinary PCPP 的“输入 oracle + proof oracle、soundness 只针对远离关系
集合”接口可参照 [pair-language PCPP, Definition 3.3 and Theorem 3.4](https://eprint.iacr.org/2024/599.pdf)。
Good-LTC/strong-LTC 只提供外层编码层；它们不自动提供本定理的 `B_x` 或
target-separation。
