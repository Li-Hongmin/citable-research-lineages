# 非自适应 message-inline ACRR 的 RLDC 长度下界

## 定理地位

这是对线性 projection-robust barrier 的严格扩展：局部 verifier 不再需要是
projection，proof map 也不再需要线性；代价是保留 message-inline、分支内非自适应
查询、完美正确分支和 target-relative 半径 soundness。结论仍不是一般自适应或
codeword-only ACRR 的不可能性。

## 假设

令

\[
  \Pi:\{0,1\}^{k}\longrightarrow\{0,1\}^{P}
\]

是一个任意的 binary proof map。对每个坐标
\(i\in[k]\) 和声明位 \(b\in\{0,1\}\)，给定一个至多 \(q\) 次**分支内非自适应**查询的
随机 verifier \(V_{i,b}\)。查询位置可以依赖 \((i,b)\) 与随机带，但不依赖先前读到
的 proof symbols。存在 \(\rho>0\) 和 \(0\le\beta<1\)，使：

1. **完美正确分支：**
   \[
   \Pr[V_{i,m_i}^{\Pi(m)}=1]=1
   \quad\text{for every }m,i.
   \]
2. **target-relative 半径 soundness：** 对每个 \(z\) 满足
   \(\operatorname{dist}(z,\Pi(m))\le \rho P\)，
   \[
   \Pr[V_{i,1-m_i}^{z}=1]\le\beta.
   \]

不假设 \(V_{i,b}\) 是 projection，也不要求 verifier 的 predicate 对 proof symbols
线性。

## 结论

定义 message-inline code

\[
  C(m)=m\,\|\,\Pi(m)\in\{0,1\}^{N},
  \qquad N=k+P.
\]

则 \(C\) 是 injective 的 binary code（不要求线性）。对任意

\[
  \delta<\frac{\rho P}{k+P},
\]

存在一个非自适应 \((Q,\delta,\sigma)\)-RLDC，其中

\[
  Q\le 2q+1,
  \qquad \sigma=1-\beta.
\]

下界中可将空余查询补成 dummy queries，以下统一取 (Q=2q+1)。

因此，只要

\[
  \delta>N^{-\sigma/(2Q)},
\]

Goldberg--Gur--Saraogi Theorem 1 的非自适应 RLDC 下界给出

\[
  N\ge
  \left(
    \frac{\sigma^2 k}
    {38Q^4\log^2(2)\,\log^2 k}
  \right)^{1+1/\lceil Q/\sigma\rceil}.
  \tag{LMI-1}
\]

特别地，若 \(q\)、\(\rho\)、\(\beta\) 为常数且 \(P=\Omega(k)\)，则

\[
  N=k^{1+\Omega(1/q)}.
  \tag{LMI-2}
\]

所以 binary、任意 proof map、固定非自适应 query、正 target-relative 半径的
near-linear ACRR，不能同时保留上述完美正确语义；这条结论不需要
projection 或 proof-map 线性假设。

## 证明

给定 oracle \(y\) 和待解码坐标 \(i\)，在随机带上分别生成两个分支的非自适应
查询位置，并预先读取 inline message bit 与两个分支查询位置的并集；并集大小至多
\(2q+1\)。随后根据读取到的 \(b=y_i\) 离线模拟 \(V_{i,b}\)。若选中 verifier
接受，输出 \(b\)，否则输出 \(\bot\)。因此最终 decoder 真正是非自适应的。

在未腐蚀 codeword \(C(m)\) 上，读取到 \(b=m_i\)，正确分支以概率一接受，因此
满足 RLDC 的 exact completeness。令
\(\operatorname{dist}(y,C(m))\le\delta N<\rho P\)。若读取到的 inline bit 正确，
decoder 只能输出正确位或 \(\bot\)；若读取到的 bit 错误，则 proof suffix 仍在
\(\rho P\) 半径内，错误分支接受概率至多 \(\beta\)。故

\[
  \Pr[D^y(i)\in\{m_i,\bot\}]\ge1-\beta=\sigma.
\]

由于前缀包含 \(m\)，\(C\) injective；不论 \(\Pi\) 是否线性，以上解码器都满足
Goldberg--Gur--Saraogi Theorem 1 所需的非自适应 RLDC 条件，代入
\(Q=2q+1\)、\(\sigma=1-\beta\) 即得 (LMI-1)。当 \(P=\Omega(k)\) 且 \(\rho>0\) 固定时，
可选固定 \(\delta>0\)，对充分大的 \(N\) 自动满足
\(\delta>N^{-\sigma/(2Q)}\)，从而得到 (LMI-2)。\(\square\)

## 精确逃逸边界

该定理关闭的不是所有 ACRR，而是一个可检验的非自适应/完美语义子类。一个正向构造若要
避开 (LMI-1)，至少必须明确支付以下一项：

* verifier 自适应（仅分支并集消除的是分支内非自适应性），或其查询数不再固定；
* soundness 不是对 target-relative 半径成立；或
* proof 不再是同一个可复用的 global codeword，或完美正确分支失效。

因此“非 projection”与“proof map 非线性”本身都不再是 barrier 的逃逸；真正剩余的是
上述量词、半径或完备性变化。这也把 C3 的 projection 限制与最新 robust-daisy 下界
之间的关系写成了可复核的参数桥，而没有把结果外推为一般 dPCP 下界。

## 与现有结果的关系

* C3/note 178 对 projection-robust 线性 proof code 直接给 RLDC；本定理通过
  message-inline 编译同时去掉 projection 与 proof-map 线性假设。
* C60/message-inline RLDC compiler 给出一般 binary Sim-CR 的 relaxed-LDC 接口；本定理
  额外利用完美完备性与 target-relative 半径语义，把它送入非自适应 RLDC 的显式长度
  下界。
* 该结果不覆盖自适应 verifier、普通 codeword-only soundness、零半径 ACRR，也不替代
  simultaneous coordinate-robust PCP 的主构造问题。

## 来源

* [Goldberg--Gur--Saraogi, Theorem 1 and Corollaries 2--3](https://arxiv.org/html/2511.21659)
* [Message-inline RLDC compiler](message-inline-rldc-compiler.md)
* [Linear projection-robust ACRR barrier](../../mcsp-hardness-magnification/notes/178-linear-projection-acrr-implies-rldc-barrier-2026-08-16.md)
