# DRAFT SPEC candidate (nnp) — 2026-09-13c — conditioned-restriction-hardness
状态：DRAFT，未冻结。前一 SPEC（specs/nnp-2026-09-13-magnification.md）已按预算终态 BUDGET 收口（note 927）：无条件均匀限制下 MCSP[N²] 切片几乎恒零，KW 原样移植的“随机硬子函数”步骤不存在。本候选是新机制（条件化限制分布），不是旧 SPEC 的续跑；是否冻结为第二次运行由用户裁决。

## 主陈述（新）
存在一个 KW 型分块随机限制分布 D（保留 m=Θ(log n) 位，其余赋值按“落入 MCSP[N²] 的 YES 集之非零切片”条件化，而非全零锚定），同时满足：
(a) 硬性保持：Pr_ρ~D[ L|_ρ 非常数 ] ≥ n^{−O(1)}，且非常数时 L|_ρ 需要 ≥ 2^{Ω(m)} 大小的（某固定弱模型）电路；
(b) 收缩：对 CJW 构造实际选定的 good hash M_v，复合底层门 H(M_v(x),v,i,块_i) 在 ρ~D 下以概率 1−o(1) 收缩为文字或常数。
若 (a)(b) 同时成立，则 KW 计数论证经 D 移植可给出 L∉TC_{r+5}[n^{5/4}]，经 CJW 得 ∀k NP⊄TC₂[n^k]。
若 (a)(b) 不可同时成立，则给出精确的“条件化 locality barrier”：任何保持硬性的条件分布必使复合门保持非平凡（量化：存活行占比下界）。

## 第一个承重引理（本轮生死检验）
L1：仅判定 (a) 的第一半——取 D 为“条件于 x∈YES 且 x 非零”的 YES-锚定分布：证明 Pr[L|_ρ 非常数] ≥ n^{−O(1)}，或证明它 ≤ 2^{−n^{Ω(1)}}。
- 工具：YES 集计数（|YES|≤2^{O(N² log N)}）+ 条件概率的直接联合分析，不用无条件并集界；允许小 N（N≤5）穷举验证公式。
- 非常数概率多项式下界成立 → GO，写下一决定性观测（(b) 在同一 D 下对实际 M_v 的行存活支持计算）。
- 指数小 → NOGO（不可绕：任何以 YES 为锚的条件化都无法给 KW 足够的硬子函数），并写出该 barrier 的精确陈述。
- 脚本留 scratch/probe-conditioned-restriction-hardness/。

## 禁区
同旧 SPEC：不做 serialization/Easy Witness/general compiler；不回 canonical-prefix/batch-count；不自行发明放大定理；不把有限 N 表当渐近证明；不把大扇入 PARITY 当实际哈希。不重复 note 927 已证的无条件切片界。
