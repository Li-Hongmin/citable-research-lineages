# DRAFT SPEC candidate (nnp) — 2026-09-13b — magnification-parameter-table-forced
状态：DRAFT。这是 thr2-nonlocal-magnification 候选（UNDETERMINED）的强制裁决轮，本轮后必须 GO/NOGO。

## 本轮唯一任务
上一轮已证：若 oracle 只在底层直接读输入，且 W·b·(log n)² = o(n²)，则 Kane–Williams 的 THR∘THR 论证可局部化（→ 该技术不能证放大阈值下界）。
本轮从具体放大定理原文抽取参数表，裁决实际模型是否落入该区间。

固定放大定理（按优先次序，取第一条能核到原文的）：
1. Chen–Jin–Williams, "Hardness Magnification for all Sparse NP Languages" (FOCS 2019, ECCC TR19-118)：稀疏 NP 语言的 n^{1+ε} 线数 THR∘THR（或其给出的最接近电路类）版本。
2. Chen–Hirahara–Oliveira–Pich–Rajgopal–Santhanam (CCC 2020) 中对 THR∘THR 或 formula 的 locality 定理所指的原放大定理。
3. Oliveira–Pich–Santhanam (CCC 2019) 的 MCSP 放大定理（若前两条无 THR∘THR 版本，则写明并以其电路类为准）。

参数表字段：输入长度 n（相对原实例 N 与参数 s 的关系）；总线数/门数上限 W；oracle 门数、最大扇入 b、所在层（底层读输入 / 中层读门输出）、是否适应；结论电路类。

## 强制裁决判据
- 若 oracle 全部在底层读输入且 W·b·(log n)² = o(n²) → 上一轮的局部化定理直接适用 → 「随机限制型 THR∘THR 下界 + 放大」路线 NOGO（写明不可绕：locality barrier 相对该定理成立）。
- 若 oracle 读中间门输出，或 b 使 W·b ≥ n^{2-o(1)} → 写出精确的未被障碍覆盖的模型，并给出对 sparse-MCSP 的候选下界陈述（固定编码、s、ε）→ GO（附下一决定性观测：在该模型中 KW 的哪一步失效）。
- 三条定理原文均无法核到 → NOGO（路线依赖的前提不成立）。

## 禁区
不做 serialization/Easy Witness/general compiler；不回到 canonical-prefix/batch-count；不自行发明放大定理。
