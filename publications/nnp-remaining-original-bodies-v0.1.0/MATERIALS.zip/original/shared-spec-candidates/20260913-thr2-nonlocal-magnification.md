# DRAFT SPEC candidate (nnp) — 2026-09-13 — thr2-nonlocal-magnification
状态：DRAFT，未冻结。上限：S（NP ⊄ P/poly 的放大路线），换工具：不再做 Γ 表示体系/固定轨道。

## 主陈述
设 sparse-MCSP[s]（或 Gap-MKtP）为已知具备 hardness magnification 定理的问题：对某 ε>0，
若它没有 n^{1+ε} 线数的 THR∘THR 电路，则 NP ⊄ P/poly（或同类结论）。
主陈述：Kane–Williams (2016) 对 THR∘THR 的 n^{1.5} 门数/随机限制论证可被改造为**非局部**的（避开 Chen–Hirahara–Oliveira–Pich–Rajgopal–Santhanam 的 locality barrier），
并对 sparse-MCSP 给出 n^{1+ε} 线数下界。
若为真：越过放大阈值（S 级）；若 KW 论证本质上 local：关闭“随机限制型 THR∘THR 下界 + 放大”路线并给出精确障碍陈述。

## 第一个承重引理（生死检验）
L1（障碍检验）：形式化 KW 的 THR∘THR 下界证明是否可在 locality barrier 的 oracle/local-circuit 模型中原样成立
（即该证明是否同样适用于带 n^{1+ε} 线数的 oracle gates 的 THR∘THR）。若成立 → 该技术不能证放大阈值下界 → NOGO。
若不成立，指出哪一步使用了非局部性质，并写出对 sparse-MCSP 的候选下界陈述。

## 禁区
不做 serialization/Easy Witness/general compiler；不回到 canonical-prefix/batch-count 表示。
