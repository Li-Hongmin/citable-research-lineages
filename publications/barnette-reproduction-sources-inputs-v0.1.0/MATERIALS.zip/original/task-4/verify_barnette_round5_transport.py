#!/usr/bin/env python3
"""One exact split-terminal construction; no parameter or Hamilton search.

Run: python3 verify_barnette_round5_transport.py > <new-output-file.json>
"""
import itertools
import json
import platform

N = 36
FACE = [(0, 5), (26, 29), (30, 35), (14, 19), (20, 23),
        (6, 11), (12, 25), (13, 24)]
TRAPS = [(1, 34), (18, 33), (21, 32), (28, 31)]
ORDINARY = [(2, 17), (3, 8), (4, 7), (9, 16), (10, 15), (22, 27)]


def edge(a, b):
    return tuple(sorted((a, b)))


def walk_edges(walk):
    return {edge(a, b) for a, b in zip(walk, walk[1:])}


def crossing(e, f):
    a, b = sorted(e)
    c, d = sorted(f)
    return a < c < b < d or c < a < d < b


def connected(adj, omitted=frozenset()):
    vertices = set(adj) - set(omitted)
    if not vertices:
        return True
    seen, todo = set(), [min(vertices)]
    while todo:
        v = todo.pop()
        if v not in seen:
            seen.add(v)
            todo.extend(set(adj[v]) - seen - set(omitted))
    return seen == vertices


def cyclic_same(a, b):
    return len(a) == len(b) and any(a == b[i:] + b[:i] for i in range(len(b)))


def check_walk(walk, graph, closed=False):
    vertices = walk[:-1] if closed else walk
    assert len(vertices) == len(set(vertices))
    assert not closed or walk[0] == walk[-1]
    assert walk_edges(walk) <= graph
    return set(vertices)


def main():
    matching = FACE + TRAPS + ORDINARY
    assert sorted(v for e in matching for v in e) == list(range(N))
    assert all((a - b) % 2 for a, b in matching)
    assert all((a - b) % N not in {0, 1, N - 1} for a, b in matching)
    assert not any(crossing(e, f) for page in (FACE, TRAPS + ORDINARY)
                   for e, f in itertools.combinations(page, 2))
    graph = {edge(i, (i + 1) % N) for i in range(N)}
    graph |= {edge(a, b) for a, b in matching}
    assert len(graph) == 54
    adj = {i: set() for i in range(N)}
    for a, b in graph:
        adj[a].add(b); adj[b].add(a)
    assert all(len(x) == 3 for x in adj.values())
    mate = {}
    for a, b in matching:
        mate[a] = b; mate[b] = a
    face_endpoints = {v for e in FACE for v in e}
    rotation = {}
    for i in range(N):
        before, after = (i - 1) % N, (i + 1) % N
        rotation[i] = [before, mate[i], after] if i in face_endpoints else [before, after, mate[i]]
    faces, used = [], set()
    for a in range(N):
        for b in rotation[a]:
            if (a, b) in used:
                continue
            dart, path = (a, b), []
            while dart not in used:
                used.add(dart)
                x, y = dart; path.append(x)
                j = rotation[y].index(x)
                dart = (y, rotation[y][(j + 1) % 3])
            assert dart == (a, b)
            faces.append(path)
    assert N - len(graph) + len(faces) == 2
    shared = [0, 5, 6, 11, 12, 25, 26, 29, 30, 35]
    assert any(cyclic_same(f, shared) or cyclic_same(f, list(reversed(shared))) for f in faces)
    assert all(mate[v] not in range(31, 35) for v in range(31, 35))

    # Assigned words and consecutiveness, not only direct counts.
    forest = []
    for a, b in ORDINARY:
        containers = [(c, d) for c, d in ORDINARY if c < a < b < d]
        parent = min(containers, key=lambda p: p[1] - p[0]) if containers else None
        children = [(c, d) for c, d in ORDINARY if a < c < d < b and
                    not any(a < e < c < d < f < b for e, f in ORDINARY)]
        direct = [v for v in range(a + 1, b) if v in face_endpoints and
                  not any(c < v < d for c, d in children)]
        forest.append({"chord": [a, b], "parent": parent, "direct_specials": direct})
    assert [x["chord"] for x in forest if x["parent"] is None] == [[2, 17], [22, 27]]
    assert {tuple(x["chord"]): x["direct_specials"] for x in forest if x["direct_specials"]} == {
        (4, 7): [5, 6], (10, 15): [11, 12, 13, 14], (22, 27): [23, 24, 25, 26]}
    assert not (set(range(8, 10)) & face_endpoints)
    assert {(6, 11), (12, 25), (13, 24)} <= {edge(a, b) for a, b in FACE}

    interlace = {i: set() for i in range(len(matching))}
    for i, j in itertools.combinations(interlace, 2):
        if crossing(matching[i], matching[j]):
            interlace[i].add(j); interlace[j].add(i)
    assert connected(interlace)
    seen, todo, tree = {0}, [0], []
    while todo:
        i = todo.pop(0)
        for j in sorted(interlace[i]):
            if j not in seen:
                seen.add(j); todo.append(j); tree.append([matching[i], matching[j]])
    assert len(tree) == len(matching) - 1
    deleted = [()] + [(v,) for v in range(N)] + list(itertools.combinations(range(N), 2))
    assert all(connected(adj, frozenset(s)) for s in deleted)

    d1 = list(range(2, 18)) + [18, 33, 34, 1, 2]
    d2 = [22, 23, 24, 25, 26, 27, 22]
    a = [5, 4, 3, 2, 1, 34, 33, 18, 17, 16, 15, 14]
    y = [6, 7, 8, 9, 10, 11, 6]
    z = [12, 13, 24, 25, 12]
    p1 = [5, 6, 11, 10, 9, 8, 7, 4, 3, 2, 1, 34, 33, 18, 17, 16, 15, 14]
    p2 = [23, 22, 27, 26]
    s1 = [5, 6, 11, 12, 25, 24, 13, 14]
    z1 = [10, 9, 8, 7, 4, 3, 2, 1, 34, 33, 18, 17, 16, 15, 10]
    q1 = [1, 2, 3, 4, 7, 8, 9, 10, 15, 16, 17, 18]
    a0 = [5, 0, 35, 30, 31, 28, 29, 26]
    a1 = [14, 19, 18, 17, 16, 15, 10, 9, 8, 7, 4, 3, 2, 1, 34, 33, 32, 21, 20, 23]
    for w in (d1, d2, y, z, z1):
        check_walk(w, graph, closed=True)
    for w in (a, p1, p2, s1, q1, a0, a1):
        check_walk(w, graph)
    cuts = {edge(5, 6), edge(11, 12), edge(13, 14), edge(23, 24), edge(25, 26)}
    opened = (walk_edges(d1) | walk_edges(d2)) - cuts
    opened |= {edge(6, 11), edge(12, 25), edge(13, 24)}
    assert opened == walk_edges(a) | walk_edges(y) | walk_edges(z) | walk_edges(p2)
    transport_removed = {edge(4, 5), edge(6, 7)}
    transport_added = {edge(4, 7), edge(5, 6)}
    assert transport_removed <= opened and not transport_added & opened
    transported = (opened - transport_removed) | transport_added
    assert transported == walk_edges(p1) | walk_edges(z) | walk_edges(p2)
    assert p1[:4] == [5, 6, 11, 10]
    fat_removed = {edge(10, 11), edge(12, 13), edge(14, 15)}
    fat_added = {edge(10, 15), edge(11, 12), edge(13, 14)}
    assert fat_removed <= transported and not fat_added & transported
    exchanged = (transported - fat_removed) | fat_added
    assert exchanged == walk_edges(s1) | walk_edges(z1) | walk_edges(p2)
    partition = [set(s1), set(z1[:-1]), set(p2)]
    assert all(not partition[i] & partition[j] for i in range(3) for j in range(i))
    assert set.union(*partition) == set(d1[:-1]) | set(d2[:-1])
    assert {edge(18, 33), edge(33, 34), edge(34, 1)} <= walk_edges(z1)
    assert walk_edges(z1) - {edge(18, 33), edge(34, 1)} == walk_edges(q1) | {edge(33, 34)}
    assert not set(a0) & set(a1)
    assert set(a0[1:-1]) | set(a1[1:-1]) == set(range(N)) - set(s1) - set(p2)
    final = s1 + a1[1:] + p2[1:] + list(reversed(a0))[1:]
    assert check_walk(final, graph, closed=True) == set(range(N))
    assert {edge(0, 5), edge(26, 29), edge(30, 35)} <= walk_edges(final)
    print(json.dumps({
        "python": platform.python_version(), "vertices": N, "edges": len(graph),
        "scope": "one exact36-parent; no parameter census, Hamilton search, SAT, or child-legality check",
        "face_matching": FACE, "opposite_matching": TRAPS + ORDINARY,
        "simple_cubic_bipartite": True, "same_page_crossings": 0,
        "rotation_system": rotation, "facial_cycles": faces, "euler_characteristic": 2,
        "site_common_face": shared, "selected_three_edge_face_arc": [29, 30, 35, 0],
        "chord_free_hexagon": [30, 31, 32, 33, 34, 35], "ordinary_forest": forest,
        "marked_leaves_consecutive": True, "marked_leaf_depths": [2, 2, 0],
        "matching_interlacement_spanning_tree": tree,
        "connected_after_vertex_deletions_up_to_two": True, "deletion_checks": len(deleted),
        "initial_root_path_A": a, "isolated_middle_cycle_Y": y,
        "central_cycle_Z": z, "transported_path_P1": p1, "root2_path_P2": p2,
        "transport_removed": sorted(transport_removed), "transport_added": sorted(transport_added),
        "fat_removed": sorted(fat_removed), "fat_added": sorted(fat_added),
        "terminal_stem_path_S1": s1, "anchored_cycle_Z1": z1,
        "exterior_paths": [a0, a1], "exact_exchange_edge_equalities": True,
        "vertex_partition_and_exterior_coverage_exact": True, "marked_parent_cycle": final,
        "parent_vertices_covered_once": N, "both_marked_sites_and_alpha_beta_retained": True,
        "general_proof_boundary": "analytic if-realized consecutive-leaf terminal transport; one witness is not an enumeration proof"
    }, indent=2))


if __name__ == "__main__":
    main()
