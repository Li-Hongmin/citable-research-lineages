#!/usr/bin/env python3
"""Check one specified third-round construction; no Hamilton-cycle search.

Reproduce: python3 verify_barnette_round3_marked_cycle.py > barnette-round3-marked-cycle-check.json
"""
import json
import platform


def edge(a, b):
    return tuple(sorted((a, b)))


def walk_edges(walk):
    return {edge(a, b) for a, b in zip(walk, walk[1:])}


def check_walk(walk, graph_edges, closed=False):
    vertices = walk[:-1] if closed else walk
    assert len(vertices) == len(set(vertices)), ("repeated vertex", walk)
    assert not closed or walk[0] == walk[-1]
    assert walk_edges(walk) <= graph_edges, ("absent edge", walk)
    return set(vertices)


def main():
    face = [(0, 3), (16, 19), (20, 25), (6, 9), (10, 13), (4, 15), (5, 14)]
    opposite = [(1, 24), (8, 23), (11, 22), (18, 21), (2, 7), (12, 17)]
    graph = {edge(i, (i + 1) % 26) for i in range(26)}
    graph |= {edge(a, b) for a, b in face + opposite}
    assert len(graph) == 39
    sites = {edge(0, 3), edge(16, 19)}
    d1 = [2, 3, 4, 5, 6, 7, 8, 23, 24, 1, 2]
    d2 = [12, 13, 14, 15, 16, 17, 12]
    p1 = [3, 2, 1, 24, 23, 8, 7, 6]
    p2 = [13, 12, 17, 16]
    z = [4, 5, 14, 15, 4]
    s = [3, 4, 15, 14, 5, 6]
    z1 = [2, 1, 24, 23, 8, 7, 2]
    q1 = [1, 2, 7, 8]
    a0 = [3, 0, 25, 20, 21, 18, 19, 16]
    a1 = [6, 9, 8, 7, 2, 1, 24, 23, 22, 11, 10, 13]
    cycles = {"D1": d1, "D2": d2, "central_Z": z, "anchored_Z1": z1}
    paths = {"P1": p1, "P2": p2, "S": s, "Q1": q1, "A0": a0, "A1": a1}
    for walk in cycles.values():
        check_walk(walk, graph, closed=True)
    for walk in paths.values():
        check_walk(walk, graph)

    # Opening the two exceptional leaves gives the claimed outer paths.
    deleted_fat_edges = {edge(3, 4), edge(5, 6), edge(13, 14), edge(15, 16)}
    opened = (walk_edges(d1) | walk_edges(d2)) - deleted_fat_edges
    assert opened == walk_edges(p1) | walk_edges(p2) | {edge(4, 5), edge(14, 15)}
    assert edge(2, 7) not in walk_edges(p1)
    assert {edge(8, 23), edge(23, 24), edge(24, 1)} <= walk_edges(p1)

    # Check the six-edge exchange as equality of subgraph edge sets.
    removed = {edge(3, 2), edge(4, 5), edge(7, 6)}
    added = {edge(2, 7), edge(3, 4), edge(5, 6)}
    before = walk_edges(p1) | walk_edges(z) | walk_edges(p2)
    assert removed <= before and not (added & before)
    after = (before - removed) | added
    assert after == walk_edges(s) | walk_edges(z1) | walk_edges(p2)
    sets = [set(s), set(z1[:-1]), set(p2)]
    assert all(not sets[i] & sets[j] for i in range(3) for j in range(i))
    assert set.union(*sets) == set(d1[:-1]) | set(d2[:-1])
    assert walk_edges(z1) - {edge(8, 23), edge(24, 1)} == walk_edges(q1) | {edge(23, 24)}

    # The exterior interiors have exactly the complementary vertices.
    assert not set(a0) & set(a1)
    exterior_interior = set(a0[1:-1]) | set(a1[1:-1])
    assert exterior_interior == set(range(26)) - set(s) - set(p2)
    assert a1[2:6] == list(reversed(q1))
    final = s + a1[1:] + p2[1:] + list(reversed(a0))[1:]
    assert final == [3, 4, 15, 14, 5, 6, 9, 8, 7, 2, 1, 24, 23, 22,
                     11, 10, 13, 12, 17, 16, 19, 18, 21, 20, 25, 0, 3]
    assert check_walk(final, graph, closed=True) == set(range(26))
    assert sites <= walk_edges(final)

    # Lift only to the already specified C4 child, without testing new graphs.
    gadget = [(0, 26), (26, 27), (27, 3), (16, 28), (28, 29), (29, 19),
              (26, 29), (27, 28)]
    child_graph = (graph - sites) | {edge(a, b) for a, b in gadget}
    replacements = {edge(0, 3): [0, 26, 27, 3], edge(16, 19): [16, 28, 29, 19]}
    lifted = [final[0]]
    for a, b in zip(final, final[1:]):
        replacement = replacements.get(edge(a, b), [a, b])
        if replacement[0] != a:
            replacement = list(reversed(replacement))
        lifted.extend(replacement[1:])
    assert len(child_graph) == 45
    assert check_walk(lifted, child_graph, closed=True) == set(range(30))
    print(json.dumps({
        "python": platform.python_version(),
        "scope": "one exact 26-parent and specified 30-child; no graph search; no proof of arbitrary-depth theorem by enumeration",
        "base_cycles": cycles, "construction_paths": paths,
        "fat_exchange_removed": sorted(removed), "fat_exchange_added": sorted(added),
        "edge_exchange_exact": True, "vertex_partition_exact": True,
        "exterior_coverage_exact": True, "marked_parent_cycle": final,
        "parent_vertices_covered_once": 26, "both_marked_sites_retained": True,
        "specified_child_cycle": lifted, "child_vertices_covered_once": 30,
        "all_walks_use_actual_edges": True,
        "graph_validity_provenance": "sealed second-round countermodel packet; not recomputed here"
    }, indent=2))


if __name__ == "__main__":
    main()
