#!/usr/bin/env python3
"""One exact adjacent-terminal Barnette realization; no parameter/search run.

Run: python3 verify_barnette_round4_adjacent_profile.py > <new-output-file.json>
"""
import itertools
import json
import platform

N = 46
FACE = [(0, 5), (6, 19), (20, 25), (26, 39), (40, 45),
        (7, 14), (8, 13), (27, 34), (28, 33)]
TRAPS = [(1, 44), (18, 43), (21, 42), (38, 41)]
ORDINARY = [(2, 17), (3, 10), (4, 9), (11, 16), (12, 15),
            (22, 37), (23, 30), (24, 29), (31, 36), (32, 35)]


def edge(a, b):
    return tuple(sorted((a, b)))


def walk_edges(walk):
    return {edge(a, b) for a, b in zip(walk, walk[1:])}


def crossing(e, f):
    a, b = sorted(e)
    c, d = sorted(f)
    return a < c < b < d or c < a < d < b


def connected(adj, omitted=frozenset()):
    vertices = set(adj) - set(omitted)
    if not vertices:
        return True
    seen = set()
    todo = [min(vertices)]
    while todo:
        v = todo.pop()
        if v not in seen:
            seen.add(v)
            todo.extend(set(adj[v]) - seen - set(omitted))
    return seen == vertices


def cyclic_same(a, b):
    return len(a) == len(b) and any(a == b[i:] + b[:i] for i in range(len(b)))


def check_walk(walk, graph, closed=False):
    vertices = walk[:-1] if closed else walk
    assert len(vertices) == len(set(vertices))
    assert not closed or walk[0] == walk[-1]
    assert walk_edges(walk) <= graph
    return set(vertices)


def main():
    matching = FACE + TRAPS + ORDINARY
    assert sorted(v for pair in matching for v in pair) == list(range(N))
    assert all((a - b) % 2 for a, b in matching)
    assert all((a - b) % N not in {0, 1, N - 1} for a, b in matching)
    assert not any(crossing(e, f) for page in (FACE, TRAPS + ORDINARY)
                   for e, f in itertools.combinations(page, 2))
    graph = {edge(i, (i + 1) % N) for i in range(N)}
    graph |= {edge(a, b) for a, b in matching}
    assert len(graph) == 69
    adj = {i: set() for i in range(N)}
    mate = {}
    for a, b in graph:
        adj[a].add(b)
        adj[b].add(a)
    for a, b in matching:
        mate[a] = b
        mate[b] = a
    assert all(len(v) == 3 for v in adj.values())

    # One rotation system, with face cycles traced exactly.
    face_endpoints = {v for pair in FACE for v in pair}
    rotation = {}
    for i in range(N):
        before, after = (i - 1) % N, (i + 1) % N
        rotation[i] = [before, mate[i], after] if i in face_endpoints else [before, after, mate[i]]
    used = set()
    faces = []
    for a in range(N):
        for b in rotation[a]:
            if (a, b) in used:
                continue
            dart, path = (a, b), []
            while dart not in used:
                used.add(dart)
                x, y = dart
                path.append(x)
                j = rotation[y].index(x)
                dart = (y, rotation[y][(j + 1) % 3])
            assert dart == (a, b)
            faces.append(path)
    assert N - len(graph) + len(faces) == 2
    shared = [0, 5, 6, 19, 20, 25, 26, 39, 40, 45]
    assert any(cyclic_same(f, shared) or cyclic_same(f, list(reversed(shared))) for f in faces)

    # Ordinary forest/depth and assigned special words, rather than a filename assertion.
    forest = []
    for a, b in ORDINARY:
        containers = [(c, d) for c, d in ORDINARY if c < a < b < d]
        parent = min(containers, key=lambda p: p[1] - p[0]) if containers else None
        children = [(c, d) for c, d in ORDINARY if a < c < d < b and
                    not any(a < e < c < d < f < b for e, f in ORDINARY)]
        direct = [v for v in range(a + 1, b) if v in face_endpoints and
                  not any(c < v < d for c, d in children)]
        forest.append({"chord": [a, b], "parent": parent, "direct_specials": direct})
    assert [x["chord"] for x in forest if x["parent"] is None] == [[2, 17], [22, 37]]
    assert {tuple(x["chord"]): x["direct_specials"] for x in forest if x["direct_specials"]} == {
        (4, 9): [5, 6, 7, 8], (12, 15): [13, 14],
        (24, 29): [25, 26, 27, 28], (32, 35): [33, 34]}
    assert all(mate[v] not in range(41, 45) for v in range(41, 45))

    # A spanning tree of matching interlacements certifies connectedness analytically.
    interlace = {i: set() for i in range(len(matching))}
    for i, j in itertools.combinations(interlace, 2):
        if crossing(matching[i], matching[j]):
            interlace[i].add(j)
            interlace[j].add(i)
    assert connected(interlace)
    seen, todo, tree = {0}, [0], []
    while todo:
        i = todo.pop(0)
        for j in sorted(interlace[i]):
            if j not in seen:
                seen.add(j)
                todo.append(j)
                tree.append([matching[i], matching[j]])
    assert len(tree) == len(matching) - 1
    deleted = [()] + [(v,) for v in range(N)] + list(itertools.combinations(range(N), 2))
    assert all(connected(adj, frozenset(s)) for s in deleted)

    # The single explicitly prescribed complete-leaf square in each root.
    d1 = list(range(2, 18)) + [18, 43, 44, 1, 2]
    d2 = list(range(22, 38)) + [38, 41, 42, 21, 22]
    p1 = [5, 4, 3, 2, 1, 44, 43, 18, 17, 16, 15, 12, 11, 10, 9, 8, 13, 14, 7, 6]
    p2 = [25, 24, 23, 22, 21, 42, 41, 38, 37, 36, 35, 32, 31, 30, 29, 28, 33, 34, 27, 26]
    for d, p, terminal_edge, nonterminal_edge, leaf_edge, added_matching, support in [
        (d1, p1, (5, 6), (7, 8), (13, 14), [(7, 14), (8, 13)], (12, 13, 14, 15)),
        (d2, p2, (25, 26), (27, 28), (33, 34), [(27, 34), (28, 33)], (32, 33, 34, 35)),
    ]:
        check_walk(d, graph, closed=True)
        h, s, t, j = support
        f = walk_edges(d) - {edge(*terminal_edge), edge(*nonterminal_edge), edge(*leaf_edge)}
        f |= {edge(a, b) for a, b in added_matching}
        assert {edge(h, s), edge(t, j)} <= f
        restored_adj = {v: set() for v in d[:-1]}
        for a, b in f | {edge(*leaf_edge)}:
            restored_adj[a].add(b)
            restored_adj[b].add(a)
        assert connected(restored_adj)
        switched = (f - {edge(h, s), edge(t, j)}) | {edge(h, j), edge(s, t)}
        assert switched == walk_edges(p)
        assert check_walk(p, graph) == set(d[:-1])
    assert not set(p1) & set(p2)
    e0 = [5, 0, 45, 40, 39, 26]
    e1 = [6, 19, 20, 25]
    final = p1 + e1[1:] + p2[1:] + list(reversed(e0))[1:]
    assert check_walk(final, graph, closed=True) == set(range(N))
    assert {edge(0, 5), edge(26, 39)} <= walk_edges(final)
    print(json.dumps({
        "python": platform.python_version(), "vertices": N, "edges": len(graph),
        "scope": "one exact P/P realization, one prescribed square per root; no parameter census, SAT or Hamilton search; no child-legality check in this round",
        "face_matching": FACE, "opposite_matching": TRAPS + ORDINARY,
        "simple_cubic_bipartite": True, "same_page_crossings": 0,
        "rotation_system": rotation, "facial_cycles": faces, "euler_characteristic": 2,
        "site_common_face": shared, "selected_three_edge_face_arc": [39, 40, 45, 0],
        "chord_free_hexagon": [40, 41, 42, 43, 44, 45],
        "ordinary_forest": forest, "exceptional_leaf_depths": [2, 2],
        "terminals": {"u": 5, "r1": 6, "r2": 25, "v": 26},
        "matching_interlacement_spanning_tree": tree,
        "connected_after_vertex_deletions_up_to_two": True, "deletion_checks": len(deleted),
        "root_paths": [p1, p2], "exterior_paths": [e0, e1],
        "exact_square_edge_equalities": True, "marked_parent_cycle": final,
        "parent_vertices_covered_once": N, "both_marked_sites_retained": True,
        "general_proof_boundary": "all four adjacent position combinations if realized under exact model; the one witness does not prove arbitrary-depth theorem"
    }, indent=2))


if __name__ == "__main__":
    main()
