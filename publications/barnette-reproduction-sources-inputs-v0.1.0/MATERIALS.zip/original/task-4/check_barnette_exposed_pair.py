#!/usr/bin/env python3
"""Small boundary-matching check; no graph census or SAT/HPC dependency.

Run: python3 check_barnette_exposed_pair.py > barnette-matching-check.json
This checks a necessary geometric matching condition, not graph realization.
"""
from functools import lru_cache
from itertools import product
import json
import platform


def count_noncrossing(labels, root_members, fixed):
    index = {x: i for i, x in enumerate(labels)}
    forced = {}
    for a, b in fixed:
        forced[index[a]] = index[b]
        forced[index[b]] = index[a]

    def allowed(i, j):
        if i in forced or j in forced:
            return forced.get(i) == j and forced.get(j) == i
        a, b = labels[i], labels[j]
        if a in {"w0", "w*"}:
            return b in root_members
        if b in {"w0", "w*"}:
            return a in root_members
        return a in root_members and b in root_members

    @lru_cache(None)
    def rec(lo, hi):
        if lo == hi:
            return 1
        if (hi - lo) % 2:
            return 0
        return sum(rec(lo + 1, j) * rec(j + 1, hi)
                   for j in range(lo + 1, hi, 2) if allowed(lo, j))

    return rec(0, len(labels))


def make_case(root, ordering, gaps, other_leaves):
    tokens = {"D": ["r2", "r1"], "s": ["s"], "t": ["t"]}
    word = []
    for i, g in enumerate(gaps):
        word.extend(f"W_leaf_{i}_{j}_{k}" for j in range(g) for k in range(2))
        if i < 3:
            word.extend(tokens[ordering[i]])
    other = [f"O_leaf_{j}_{k}" for j in range(other_leaves) for k in range(2)]
    w1, w2 = (word, other) if root == 1 else (other, word)
    labels = ["w0", *w1, "z1", "z2", *w2, "w*"]
    return labels, set(word + other)


def crosses(e, f, order):
    a, b = sorted(order.index(x) for x in e)
    c, d = sorted(order.index(x) for x in f)
    return (a < c < b < d) or (c < a < d < b)


def main():
    gaps_list = [g for g in product(range(4), repeat=4) if sum(g) <= 3]
    summary = {}
    examples = {}
    case_count = 0
    for root in (1, 2):
        for ordering in (("D", "s", "t"), ("s", "D", "t"), ("s", "t", "D")):
            key = f"W{root}:" + "-".join(ordering)
            row = {"cases": 0, "positive_cases": 0, "matching_total": 0}
            for g in gaps_list:
                for m in range(4):
                    labels, roots = make_case(root, ordering, g, m)
                    count = count_noncrossing(labels, roots, [("z1", "r1"), ("z2", "r2")])
                    row["cases"] += 1
                    row["positive_cases"] += bool(count)
                    row["matching_total"] += count
                    case_count += 1
                    if ordering == ("s", "D", "t"):
                        assert count == 0, (labels, count)
                    elif count and key not in examples:
                        examples[key] = {"gaps": g, "other_leaves": m, "count": count}
            summary[key] = row
    assert all(summary[f"W{r}:s-D-t"]["positive_cases"] == 0 for r in (1, 2))
    assert all(summary[k]["positive_cases"] > 0 for k in summary if "s-D-t" not in k)

    labels, _ = make_case(1, ("s", "D", "t"), (0, 0, 0, 0), 1)
    crossing_control = [("z1", "r1"), ("z2", "r2"), ("w0", "s"),
                        ("t", "O_leaf_0_0"), ("O_leaf_0_1", "w*")]
    ends = [v for e in crossing_control for v in e]
    assert len(set(ends)) == len(labels) and set(ends) == set(labels)
    crossings = [(e, f) for i, e in enumerate(crossing_control)
                 for f in crossing_control[i+1:] if crosses(e, f, labels)]
    assert crossings
    print(json.dumps({
        "python": platform.python_version(),
        "scope": "noncrossing boundary perfect matchings with prescribed exposed attachments; not Barnette graphs",
        "total_cases": case_count,
        "max_root_leaf_pairs": 3,
        "max_other_root_leaf_pairs": 3,
        "max_boundary_slots": 20,
        "summary": summary,
        "outside_positive_controls": examples,
        "crossing_control_for_impossible_inner_order": {
            "boundary": labels, "matching": crossing_control, "crossings": crossings
        },
        "verdict": "inner order excluded in all 280 checked cases; analytic proof carries the unbounded claim"
    }, indent=2))


if __name__ == "__main__":
    main()
