#!/usr/bin/env python3
"""Validate one explicit 26-vertex profile countermodel, not a graph census.
Run: python3 verify_barnette_profile_countermodel.py > barnette-profile-countermodel-check.json
"""
import itertools
import json
import platform

N = 26
FACE = [(0,3), (16,19), (20,25), (6,9), (10,13), (4,15), (5,14)]
OPPOSITE = [(1,24), (8,23), (11,22), (18,21), (2,7), (12,17)]


def crossing(e, f):
    a,b = sorted(e)
    c,d = sorted(f)
    return a < c < b < d or c < a < d < b


def connected(adj, omitted=frozenset()):
    vertices = set(adj) - set(omitted)
    if not vertices:
        return True
    seen = set()
    todo = [min(vertices)]
    while todo:
        v = todo.pop()
        if v not in seen:
            seen.add(v)
            todo.extend(set(adj[v]) - seen - set(omitted))
    return seen == vertices


def cyclic_same(a, b):
    return len(a) == len(b) and any(a == b[i:]+b[:i] for i in range(len(b)))


def main():
    matching = FACE + OPPOSITE
    endpoints = [x for e in matching for x in e]
    assert sorted(endpoints) == list(range(N))
    assert all((a-b)%2 == 1 for a,b in matching)
    assert all((a-b)%N not in {0,1,N-1} for a,b in matching)
    assert not any(crossing(e,f) for page in (FACE,OPPOSITE)
                   for e,f in itertools.combinations(page,2))
    adj = {i: {(i-1)%N,(i+1)%N} for i in range(N)}
    mate = {}
    for a,b in matching:
        adj[a].add(b); adj[b].add(a)
        mate[a]=b; mate[b]=a
    assert all(len(x)==3 for x in adj.values())
    deleted_sets = [()] + [(i,) for i in range(N)] + list(itertools.combinations(range(N),2))
    assert all(connected(adj, frozenset(s)) for s in deleted_sets)
    interlace = {i: set() for i in range(len(matching))}
    for i,j in itertools.combinations(interlace,2):
        if crossing(matching[i],matching[j]):
            interlace[i].add(j); interlace[j].add(i)
    assert connected(interlace)

    face_endpoints = {x for e in FACE for x in e}
    rotation = {}
    for i in range(N):
        before,after = (i-1)%N,(i+1)%N
        rotation[i] = [before,mate[i],after] if i in face_endpoints else [before,after,mate[i]]
    used = set()
    faces = []
    for a in range(N):
        for b in rotation[a]:
            if (a,b) in used:
                continue
            dart = (a,b)
            path = []
            while dart not in used:
                used.add(dart)
                x,y = dart
                path.append(x)
                j=rotation[y].index(x)
                dart=(y,rotation[y][(j+1)%3])
            assert dart == (a,b)
            faces.append(path)
    assert N - 3*N//2 + len(faces) == 2
    shared = [0,3,4,15,16,19,20,25]
    assert any(cyclic_same(f,shared) or cyclic_same(f,list(reversed(shared))) for f in faces)
    assert (21,24) not in matching and (24,21) not in matching
    main = set(range(20))
    ordinary = [e for e in OPPOSITE if set(e) <= main]
    assert ordinary == [(2,7),(12,17)]
    direct = [[x for x in range(a+1,b) if x in face_endpoints] for a,b in ordinary]
    assert [len(x) for x in direct] == [4,4]
    child = {i: set(v) for i,v in adj.items()}
    for a,b in [(0,3),(16,19)]:
        child[a].remove(b); child[b].remove(a)
    child.update({i:set() for i in range(26,30)})
    for a,b in [(0,26),(26,27),(27,3),(16,28),(28,29),(29,19),(26,29),(27,28)]:
        child[a].add(b); child[b].add(a)
    colours = {i:i%2 for i in range(N)} | {26:1,27:0,28:1,29:0}
    assert all(len(v)==3 for v in child.values())
    assert all(colours[a]!=colours[b] for a in child for b in child[a])
    child_deleted = [()] + [(i,) for i in child] + list(itertools.combinations(child,2))
    assert all(connected(child,frozenset(s)) for s in child_deleted)
    print(json.dumps({
        "python": platform.python_version(), "vertices": N, "edges": 39,
        "hamilton_cycle": list(range(N)), "face_page_matching": FACE,
        "opposite_page_matching": OPPOSITE,
        "simple_cubic_bipartite": True, "page_crossings": 0,
        "rotation_system": rotation, "facial_cycles": faces,
        "euler_characteristic": 2, "site_common_face": shared,
        "selected_three_edge_face_arc": [19,20,25,0],
        "trapped_hexagon": list(range(20,26)),
        "ordinary_roots": ordinary, "direct_special_positions": direct,
        "connected_after_vertex_deletions_up_to_two": True,
        "vertex_deletion_checks": len(deleted_sets),
        "matching_interlacement_graph_connected": True,
        "selected_site_expansion": {
            "ports": [0,3,16,19], "new_vertices": [26,27,28,29],
            "embedding": "new square in the common face, ports in its cyclic boundary order",
            "simple_cubic_bipartite": True,
            "connected_after_vertex_deletions_up_to_two": True,
            "vertex_deletion_checks": len(child_deleted)
        },
        "scope": "one explicit Barnette realization refuting root2+B => two-special-leaf profile; not a counterexample to Note 914 or Barnette"
    }, indent=2))


if __name__ == "__main__":
    main()
