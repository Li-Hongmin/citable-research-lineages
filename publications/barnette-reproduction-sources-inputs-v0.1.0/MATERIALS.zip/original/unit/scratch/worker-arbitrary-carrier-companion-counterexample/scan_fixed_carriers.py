#!/usr/bin/env python3
"""Test the carrier companion statement on frozen actual carriers only.

The initial scope is the three literal legal-wide root-square carriers used
in Notes 151, 153, and 154.  Every facial square disjoint from the root
square is tested in every cyclic orientation; no graph is generated.
"""

from __future__ import annotations

from functools import lru_cache
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[1]
BUNDLES = BARNETTE / "computations" / "bundles"


def load_module(path: Path, name: str):
    spec = spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def edge(left, right):
    return tuple(sorted((left, right), key=repr))


def plane_faces(graph: nx.Graph) -> tuple[tuple, ...]:
    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    visited = set()
    faces = []
    for left, right in embedding.edges():
        if (left, right) in visited:
            continue
        faces.append(tuple(embedding.traverse_face(left, right, visited)))
    return tuple(faces)


def enumerate_required_matchings(
    graph: nx.Graph,
    removed_vertices: frozenset,
    required_edges: frozenset[tuple],
) -> tuple[frozenset[tuple], ...]:
    if any(set(item) & set(removed_vertices) for item in required_edges):
        return ()
    if any(not graph.has_edge(*item) for item in required_edges):
        return ()
    used = {vertex for item in required_edges for vertex in item}
    if len(used) != 2 * len(required_edges):
        return ()
    vertices = tuple(sorted(set(graph) - set(removed_vertices) - used, key=repr))
    position = {vertex: index for index, vertex in enumerate(vertices)}
    neighbours = [0] * len(vertices)
    for left, right in graph.edges():
        if left not in position or right not in position:
            continue
        neighbours[position[left]] |= 1 << position[right]
        neighbours[position[right]] |= 1 << position[left]

    @lru_cache(maxsize=None)
    def solve(mask: int):
        if not mask:
            return ((),)
        candidates = [index for index in range(len(vertices)) if mask >> index & 1]
        first = min(
            candidates,
            key=lambda index: ((neighbours[index] & mask).bit_count(), index),
        )
        choices = neighbours[first] & mask
        remainder = mask ^ (1 << first)
        rows = []
        while choices:
            bit = choices & -choices
            choices ^= bit
            second = bit.bit_length() - 1
            for suffix in solve(remainder ^ bit):
                rows.append(((first, second),) + suffix)
        return tuple(rows)

    return tuple(
        frozenset(required_edges)
        | frozenset(edge(vertices[left], vertices[right]) for left, right in encoded)
        for encoded in solve((1 << len(vertices)) - 1)
    )


def root_attachments(graph: nx.Graph, root_square: tuple) -> tuple:
    square = set(root_square)
    attachments = []
    for vertex in root_square:
        outside = [neighbour for neighbour in graph[vertex] if neighbour not in square]
        assert len(outside) == 1
        attachments.append(outside[0])
    assert len(set(attachments)) == 4
    return tuple(attachments)


def complement_components(
    cut: nx.Graph,
    root_square: tuple,
    attachments: tuple,
    ports: tuple,
    matching: frozenset[tuple],
):
    residual = cut.subgraph(set(cut) - set(root_square)).copy()
    residual.remove_edges_from(matching)
    components = []
    for vertices in nx.connected_components(residual):
        subgraph = residual.subgraph(vertices)
        degrees = tuple(dict(subgraph.degree()).values())
        port_marks = frozenset(index for index, vertex in enumerate(ports) if vertex in vertices)
        root_marks = frozenset(
            index for index, vertex in enumerate(attachments) if vertex in vertices
        )
        if degrees and all(value == 2 for value in degrees):
            kind = "cycle"
        else:
            if not all(value in {1, 2} for value in degrees):
                return None
            kind = "path"
        components.append((kind, port_marks, root_marks))
    return tuple(sorted(components, key=lambda item: (item[0], tuple(item[1]), tuple(item[2]))))


REQUIRED_ROOT_PAIRS = {
    frozenset((0, 3)),
    frozenset((1, 2)),
}


def factor_join_passes(components, state: frozenset[int], factor_pairs: tuple[frozenset[int], ...]):
    if components is None or any(kind == "cycle" for kind, _ports, _roots in components):
        return False
    auxiliary = nx.Graph()
    marks = {}
    for index, (_kind, ports, roots) in enumerate(components):
        name = ("carrier", index)
        auxiliary.add_node(name)
        marks[name] = set(roots)
    for index, pair in enumerate(factor_pairs):
        name = ("factor", index)
        auxiliary.add_node(name)
        marks[name] = set()
        for port in pair:
            owners = [
                ("carrier", ordinal)
                for ordinal, (_kind, ports, _roots) in enumerate(components)
                if port in ports
            ]
            if len(owners) != 1:
                return False
            auxiliary.add_edge(name, owners[0])
    if set().union(*map(set, factor_pairs)) != set(range(4)) - set(state):
        return False
    root_pairs = set()
    for vertices in nx.connected_components(auxiliary):
        roots = frozenset().union(*(marks[vertex] for vertex in vertices))
        if len(roots) != 2:
            return False
        root_pairs.add(roots)
    return root_pairs == REQUIRED_ROOT_PAIRS


def bond_atom(cut: nx.Graph, ports: tuple, first, second):
    state_first, matching_first = first
    state_second, matching_second = second
    difference = matching_first ^ matching_second
    if not difference:
        return (), 0
    difference_graph = nx.edge_subgraph(cut, difference).copy()
    paths = []
    cycles = 0
    for vertices in nx.connected_components(difference_graph):
        component = difference_graph.subgraph(vertices)
        ends = [vertex for vertex, degree in component.degree() if degree == 1]
        if not ends:
            if set(dict(component.degree()).values()) != {2}:
                return None
            cycles += 1
        else:
            if len(ends) != 2:
                return None
            marks = frozenset(index for index, vertex in enumerate(ports) if vertex in ends)
            if len(marks) != 2:
                return None
            paths.append(marks)
    expected = set(state_first ^ state_second)
    actual = set().union(*map(set, paths)) if paths else set()
    if actual != expected:
        return None
    return tuple(sorted(paths, key=tuple)), cycles


STATES = (
    frozenset(),
    frozenset((0, 1, 2, 3)),
    frozenset((0, 1)),
    frozenset((1, 2)),
    frozenset((2, 3)),
    frozenset((0, 3)),
)


def carrier_rows(graph, root_square, root, forced, ports):
    cut = graph.copy()
    cut.remove_edges_from((edge(ports[0], ports[1]), edge(ports[2], ports[3])))
    required = frozenset((edge(*root), edge(*forced)))
    attachments = root_attachments(graph, root_square)
    rows = []
    for state in STATES:
        removed = frozenset(ports[index] for index in state)
        for matching in enumerate_required_matchings(cut, removed, required):
            profile = complement_components(
                cut, root_square, attachments, ports, matching
            )
            if profile is not None:
                rows.append((state, matching, profile))
    return cut, tuple(rows)


def cyclic_orientations(face: tuple) -> tuple[tuple, ...]:
    values = []
    for candidate in (face, tuple(reversed(face))):
        for offset in range(4):
            values.append(candidate[offset:] + candidate[:offset])
    return tuple(dict.fromkeys(values))


def analyze_cut(record, face: tuple, ports: tuple):
    graph = record["graph"]
    cut, rows = carrier_rows(
        graph, record["root_square"], record["root"], record["forced"], ports
    )
    surviving = edge(*record["surviving"])
    empty = frozenset()
    a0 = frozenset((0, 1))
    a1 = frozenset((1, 2))
    a3 = frozenset((0, 3))
    z_pairs = (frozenset((0, 1)), frozenset((2, 3)))
    a0_pairs = (frozenset((2, 3)),)
    a1_pairs = (frozenset((0, 3)),)
    a3_pairs = (frozenset((1, 2)),)

    z = [
        index for index, (state, matching, profile) in enumerate(rows)
        if state == empty and factor_join_passes(profile, empty, z_pairs)
    ]
    zero = [
        index for index, (state, matching, profile) in enumerate(rows)
        if state == a0 and factor_join_passes(profile, a0, a0_pairs)
    ]
    one = [
        index for index, (state, matching, profile) in enumerate(rows)
        if state == a1 and factor_join_passes(profile, a1, a1_pairs)
    ]
    three = [
        index for index, (state, matching, profile) in enumerate(rows)
        if state == a3 and factor_join_passes(profile, a3, a3_pairs)
    ]
    sectors = {
        index: int(surviving in rows[index][1])
        for index in z + zero + one + three
    }
    antecedents = []
    for left in z:
        if sectors[left] != 0:
            continue
        for right in zero:
            if sectors[right] != 1:
                continue
            if bond_atom(cut, ports, rows[left][:2], rows[right][:2]) == (
                (frozenset((0, 1)),), 0
            ):
                antecedents.append((left, right))
    companions_a1 = []
    for left in z:
        if sectors[left] != 1:
            continue
        for right in one:
            if sectors[right] != 0:
                continue
            if bond_atom(cut, ports, rows[left][:2], rows[right][:2]) == (
                (frozenset((1, 2)),), 0
            ):
                companions_a1.append((left, right))
    companions_a3 = []
    for left in z:
        if sectors[left] != 1:
            continue
        for right in three:
            if sectors[right] != 0:
                continue
            if bond_atom(cut, ports, rows[left][:2], rows[right][:2]) == (
                (frozenset((0, 3)),), 0
            ):
                companions_a3.append((left, right))

    if not antecedents:
        return None
    return {
        "name": record["name"],
        "face": face,
        "ports": ports,
        "cut_edges": (edge(ports[0], ports[1]), edge(ports[2], ports[3])),
        "row_count": len(rows),
        "compatible_counts": {
            "Z": len(z), "A0": len(zero), "A1": len(one), "A3": len(three)
        },
        "antecedents": antecedents,
        "companions_a1": companions_a1,
        "companions_a3": companions_a3,
        "counterexample": not companions_a1 and not companions_a3,
        "antecedent_rows": [
            {
                "indices": pair,
                "matchings": [sorted(rows[index][1], key=repr) for index in pair],
            }
            for pair in antecedents
        ],
        "companion_rows_a1": [
            {
                "indices": pair,
                "matchings": [sorted(rows[index][1], key=repr) for index in pair],
            }
            for pair in companions_a1
        ],
        "companion_rows_a3": [
            {
                "indices": pair,
                "matchings": [sorted(rows[index][1], key=repr) for index in pair],
            }
            for pair in companions_a3
        ],
    }


def fixed_records():
    note151 = load_module(
        BUNDLES / "legal-wide-plane-brace-xor-cube" / "verify_legal_wide_plane_brace_xor_cube.py",
        "carrier_note151_base",
    )
    note153 = load_module(
        BUNDLES / "fixed-common-b-no-rooted-triangle" / "verify_fixed_common_b_no_rooted_triangle.py",
        "carrier_note153_base",
    )
    note154 = load_module(
        BUNDLES / "crossing-bridge-star-counterexample" / "verify_order22_crossing_bridge_star_counterexample.py",
        "carrier_note154_base",
    )
    return (
        {
            "name": "Note151-order32",
            "graph": note151.EXTENSION_GRAPH,
            "root_square": note151.SQUARE,
            "root": tuple(note151.ROOT),
            "forced": tuple(note151.FORCED_GATE),
            "surviving": tuple(note151.SURVIVING_GATE),
        },
        {
            "name": "Note153-order24",
            "graph": nx.from_graph6_bytes(note153.GRAPH6.encode()),
            "root_square": note153.ROOT_SQUARE,
            "root": note153.ROOT,
            "forced": note153.FORCED_GATE,
            "surviving": note153.SURVIVING_GATE,
        },
        {
            "name": "Note154-order22",
            "graph": nx.from_graph6_bytes(note154.GRAPH6.encode()),
            "root_square": note154.ROOT_SQUARE,
            "root": note154.ROOT,
            "forced": note154.FORCED_GATE,
            "surviving": note154.SURVIVING_GATE,
        },
    )


def main():
    results = []
    counts = {
        "graphs": 0,
        "facial_squares": 0,
        "root_disjoint_facial_squares": 0,
        "oriented_cuts": 0,
        "antecedent_cuts": 0,
        "antecedent_pairs": 0,
        "a1_companion_cuts": 0,
        "a3_companion_cuts": 0,
        "both_companion_types_cuts": 0,
        "a1_companion_pairs": 0,
        "a3_companion_pairs": 0,
        "counterexamples": 0,
    }
    for record in fixed_records():
        counts["graphs"] += 1
        faces = plane_faces(record["graph"])
        squares = tuple(face for face in faces if len(face) == 4)
        counts["facial_squares"] += len(squares)
        for face in squares:
            if set(face) & set(record["root_square"]):
                continue
            counts["root_disjoint_facial_squares"] += 1
            for ports in cyclic_orientations(face):
                counts["oriented_cuts"] += 1
                result = analyze_cut(record, face, ports)
                if result is None:
                    continue
                counts["antecedent_cuts"] += 1
                counts["antecedent_pairs"] += len(result["antecedents"])
                has_a1 = bool(result["companions_a1"])
                has_a3 = bool(result["companions_a3"])
                counts["a1_companion_cuts"] += int(has_a1)
                counts["a3_companion_cuts"] += int(has_a3)
                counts["both_companion_types_cuts"] += int(has_a1 and has_a3)
                counts["a1_companion_pairs"] += len(result["companions_a1"])
                counts["a3_companion_pairs"] += len(result["companions_a3"])
                counts["counterexamples"] += int(result["counterexample"])
                results.append(result)
    payload = {"scope": counts, "results": results}
    print(json.dumps(payload, indent=2, sort_keys=True, default=list))
    if counts["counterexamples"]:
        print("ORIENTATION_FREE_ACTUAL_CARRIER_COUNTEREXAMPLE_FOUND")
    else:
        print("ORIENTATION_FREE_P_PASSES_NOTES_151_153_154_FIXED_DECORATIONS")


if __name__ == "__main__":
    main()
