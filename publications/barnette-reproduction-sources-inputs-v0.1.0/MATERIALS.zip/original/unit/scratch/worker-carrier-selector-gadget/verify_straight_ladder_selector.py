#!/usr/bin/env python3
"""Local certificate for the Note 160 defect-directed ladder replacement.

This is not a graph census.  It checks the two-row transfer on the single
four-terminal patch F=(4,12,6,14), replaced by the straight ladder L_n.
The mathematical proof for arbitrary even n is in the adjacent markdown
file; the bounded loop below is only an independent state check.
"""

from __future__ import annotations

from collections import Counter
from functools import lru_cache


Vertex = tuple[int, int]
Edge = frozenset[Vertex]


def edge(left: Vertex, right: Vertex) -> Edge:
    return frozenset((left, right))


def ladder(n: int) -> tuple[tuple[Vertex, ...], frozenset[Edge]]:
    vertices = tuple((row, column) for row in range(2) for column in range(n))
    edges = {
        edge((row, column), (row, column + 1))
        for row in range(2)
        for column in range(n - 1)
    }
    edges |= {edge((0, column), (1, column)) for column in range(n)}
    return vertices, frozenset(edges)


def perfect_matchings(
    vertices: tuple[Vertex, ...], edges: frozenset[Edge], removed=frozenset()
) -> tuple[frozenset[Edge], ...]:
    remaining = tuple(vertex for vertex in vertices if vertex not in removed)
    position = {vertex: index for index, vertex in enumerate(remaining)}
    neighbours = [0] * len(remaining)
    for item in edges:
        left, right = tuple(item)
        if left in position and right in position:
            neighbours[position[left]] |= 1 << position[right]
            neighbours[position[right]] |= 1 << position[left]

    @lru_cache(maxsize=None)
    def solve(mask: int):
        if not mask:
            return ((),)
        candidates = [index for index in range(len(remaining)) if mask >> index & 1]
        first = min(
            candidates,
            key=lambda index: ((neighbours[index] & mask).bit_count(), index),
        )
        rows = []
        choices = neighbours[first] & mask
        rest = mask ^ (1 << first)
        while choices:
            bit = choices & -choices
            choices ^= bit
            second = bit.bit_length() - 1
            for suffix in solve(rest ^ bit):
                rows.append(((first, second),) + suffix)
        return tuple(rows)

    return tuple(
        frozenset(edge(remaining[left], remaining[right]) for left, right in row)
        for row in solve((1 << len(remaining)) - 1)
    )


def complement_profile(
    vertices: tuple[Vertex, ...], edges: frozenset[Edge], matching: frozenset[Edge]
):
    ports = ((0, 0), (0, len(vertices) // 2 - 1), (1, len(vertices) // 2 - 1), (1, 0))
    adjacency = {vertex: set() for vertex in vertices}
    for item in edges - matching:
        left, right = tuple(item)
        adjacency[left].add(right)
        adjacency[right].add(left)
    unseen = set(vertices)
    pairs = []
    cycles = 0
    while unseen:
        start = next(iter(unseen))
        component = {start}
        frontier = [start]
        while frontier:
            current = frontier.pop()
            for neighbour in adjacency[current]:
                if neighbour not in component:
                    component.add(neighbour)
                    frontier.append(neighbour)
        unseen -= component
        marks = frozenset(index for index, port in enumerate(ports) if port in component)
        if not marks:
            cycles += 1
        else:
            assert len(marks) == 2
            pairs.append(marks)
    return frozenset(pairs), cycles


def canonical_n1_matching(n: int) -> frozenset[Edge]:
    top = {
        edge((0, column), (0, column + 1))
        for column in range(0, n - 1, 2)
    }
    bottom = {
        edge((1, column), (1, column + 1))
        for column in range(1, n - 2, 2)
    }
    return frozenset(top | bottom)


def connected_difference(
    vertices: tuple[Vertex, ...], difference: frozenset[Edge], ends: frozenset[Vertex]
) -> bool:
    used = {vertex for item in difference for vertex in item}
    adjacency = {vertex: set() for vertex in used}
    for item in difference:
        left, right = tuple(item)
        adjacency[left].add(right)
        adjacency[right].add(left)
    if not used:
        return False
    seen = set()
    frontier = [next(iter(used))]
    while frontier:
        current = frontier.pop()
        if current in seen:
            continue
        seen.add(current)
        frontier.extend(adjacency[current] - seen)
    return seen == used and {vertex for vertex in used if len(adjacency[vertex]) == 1} == ends


def main() -> None:
    straight = frozenset((frozenset((0, 1)), frozenset((2, 3))))
    switched = frozenset((frozenset((0, 3)), frozenset((1, 2))))

    # Keep the executable cross-check deliberately tiny.  The adjacent
    # domino-word proof, not this bounded loop, carries the universal
    # quantifier.
    for n in range(2, 20, 2):
        vertices, edges = ladder(n)
        rows = perfect_matchings(vertices, edges)
        profiles = Counter(complement_profile(vertices, edges, row) for row in rows)

        # All rungs are the unique clean straight (K20-type) row.
        assert profiles[(straight, 0)] == 1
        # Exactly one horizontal domino-pair gives each clean switched row.
        assert profiles[(switched, 0)] == n - 1
        assert sum(profiles.values()) == len(rows)

        all_rungs = frozenset(edge((0, column), (1, column)) for column in range(n))
        assert complement_profile(vertices, edges, all_rungs) == (straight, 0)

        # Removing the two bottom corner ports models K10's two exterior
        # matching edges.  The clean p0--p1 row is unique.
        bottom_ends = frozenset(((1, 0), (1, n - 1)))
        near_rows = perfect_matchings(vertices, edges, bottom_ends)
        canonical = canonical_n1_matching(n)
        assert canonical in near_rows
        clean_near = []
        for row in near_rows:
            # Add the two formal exterior stubs only for the symmetric-
            # difference connectivity test.
            if connected_difference(
                vertices,
                all_rungs ^ row,
                frozenset(((1, 0), (1, n - 1))),
            ):
                clean_near.append(row)
        assert clean_near == [canonical]

    print("STRAIGHT_LADDER_SELECTOR_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
