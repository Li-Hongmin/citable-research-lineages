# Defect-directed four-terminal replacement stops at a connectivity-refined signature

## Scope and decision

Work only at the sharp order-16 carrier of Note 160.  Write its facial
square as

\[
F=(p_0,p_1,p_2,p_3)=(4,12,6,14).
\]

This is the unique local place where the three load-bearing rows separate
in the required way:

\[
\begin{array}{c|c}
K_2 & p_0p_1,\ p_2p_3\\
K_{10} & p_0p_1\quad (p_2,p_3\text{ matched outside }F)\\
K_{20} & p_0p_3,\ p_1p_2.
\end{array}
\]

No single edge is unique to \(K_{20}\).  Thus edge deletion is not a
selector.  The smallest honest selector must distinguish the two
zero-boundary perfect matchings of the same four-terminal patch by the
connectivity of their complements.

The defect-directed replacement family tested here is the whole straight
ladder family

\[
L_n=P_n\square K_2,\qquad n\ge2\text{ even},
\]

inserted in place of \(F=L_2\), with the four corners identified with
\(p_0,p_1,p_2,p_3\) in cyclic order.  It contains the maximally directed
one-step replacement on the opposite edges \(4\!-\!12,6\!-\!14\), but the
argument below treats every ladder length at once.

**Decision.**  No member of this family can realize the one-row defect.
Whenever the designated \(K_2-K_{10}\) crossing is retained, the canonical
all-rung lift of \(K_{20}\) remains rooted-compatible and its join with the
canonical \(K_{10}\) lift still has atom \(13+0\).  Hence \(M\ge2\).

## Exact local transfer

Let the top corners of \(L_n\) be \(p_0,p_1\), and the bottom corners be
\(p_3,p_2\).  Every perfect matching of a \(2\times n\) ladder is a domino
tiling encoded by a word in

\[
V\quad\text{(one rung)},\qquad H\quad\text{(two horizontal dominoes)},
\]

whose weights are respectively one and two columns.

Delete a matching and inspect the remaining degree-two graph.

1.  The word \(V^n\) is the unique clean row whose complement is the two
    rails.  Its boundary pairing is
    
    \[
    01\mid23.
    \]

2.  A word with exactly one \(H\) is clean and switches the rails once.  Its
    pairing is
    
    \[
    03\mid12.
    \]

    The \(H\)-block can start in any of the \(n-1\) gaps.

3.  A word with at least two \(H\)-blocks leaves a closed complement cycle
    between two consecutive switches and is not rooted-compatible.

Therefore the connectivity-refined zero-boundary signature is exactly

\[
f_{\varnothing}^{01\mid23}=1,
\qquad
f_{\varnothing}^{03\mid12}=n-1.
\tag{1}
\]

The second coordinate gives the \(n-1\) clean \(K_2\)-type lifts.  The first
coordinate is the obstruction: it is the all-rung \(K_{20}\)-type lift and
can never be removed by lengthening the ladder.

For \(K_{10}\), its two exterior matching edges cover the bottom corner
ports \(p_3,p_2\).  The remaining patch has the unique matching

\[
J_0=
\{t_{2i}t_{2i+1}\}
\mathbin\cup
\{b_{2i+1}b_{2i+2}\}.
\tag{2}
\]

Its complement is a Hamilton path from \(p_0\) to \(p_1\), so the original
\(N_1\) rooted profile is unchanged.  The symmetric difference of \(J_0\)
with the all-rung matching is one path from \(p_3\) to \(p_2\).  After the
unchanged exterior edges are restored, this path is

\[
13-7-p_3\;L_n\;p_2-15,
\]

with no closed component.  Thus the child rows have exactly the same
mandatory atom

\[
d(K_{10}^{(n)},K_{20}^{(n)})=13+0.
\tag{3}
\]

This is independent of whether the resulting ambient graph is a brace; in
particular it applies to every member that passes all legal-wide and brace
filters.

## Why the ordinary matchgate identity is not yet the general theorem

For cyclic alternating terminals, the ordinary four-terminal bipartite
matchgate signature satisfies the Kuo/Grassmann--Pluecker identity

\[
f_{\varnothing}f_{0123}
=f_{01}f_{23}+f_{03}f_{12}.
\tag{4}
\]

But \(K_2\) and \(K_{20}\) lie in the **same** aggregate coordinate
\(f_{\varnothing}\).  Equation (4) counts perfect matchings and forgets
whether their complements pair the terminals as \(03\mid12\), as
\(01\mid23\), or contain a closed cycle.  Consequently ordinary matchgate
support, and even its integer version, does not by itself answer the rooted
selector question when the other signature coordinates are allowed to
change with the replacement.

This failure is already visible inside (4): the nonnegative integral
assignment

\[
(f_{\varnothing},f_{0123},f_{01},f_{23},f_{03},f_{12})
=(1,1,1,1,0,0)
\]

satisfies (4).  Thus the aggregate identity permits one zero-boundary
matching together with the required adjacent two-port state.  This is only
an identity-level countermodel, not a cubic-pole realization, but it proves
that Kuo/Grassmann--Pluecker alone cannot supply the missing rooted row.

The smallest missing refinement is precisely

\[
f_{\varnothing}
=f_{\varnothing}^{03\mid12}
 +f_{\varnothing}^{01\mid23}
 +f_{\varnothing}^{\mathrm{closed}}.
\tag{5}
\]

For the straight ladder, (1) computes the two clean summands and closes the
family.  A genuinely new selector must be a planar cubic four-pole with

\[
f_{\varnothing}^{03\mid12}>0,
\qquad
f_{\varnothing}^{01\mid23}=0,
\tag{6}

while also supplying the clean near-perfect \(K_{10}\) row (2) and passing
the ambient brace test.  This connectivity-refined condition, not the
ordinary matchgate identity, is the exact next interface.

## Reproduction

Run from the AIMath root:

```sh
python3 units/barnette/scratch/worker-carrier-selector-gadget/verify_straight_ladder_selector.py
```

The terminal marker is

```text
STRAIGHT_LADDER_SELECTOR_BOUNDARY_VERIFIED
```

The verifier enumerates only local domino states for even
\(2\le n\le18\); the arbitrary-\(n\) conclusion is the word classification
above, not bounded extrapolation.  No permanent note is modified.
