# Mandatory count one is absent from the frozen through-26 carrier corpus

## Decision

No actual counterexample to the carrier prefilter occurs in the already
frozen through-order-26 corpus.  Among every reconstructed actual
legal-wide root-square decoration, every root-disjoint facial square cut,
every cyclic port orientation, and both surviving-gate sector directions,
the sharp observed bound is

\[
M\ge 2.
\]

The value two is attained 592 times.  Thus this frozen corpus supports the
proposed general statement (M\ne1), and also shows that any general lower
bound stronger than two is false.

This is a strict finite boundary, not a proof for arbitrary carriers.  No
graph was generated and no order was extended.

## Exact frozen scope

The only graph inputs are the 50 distinct graph6 representatives already
stored in permanent computation bundles and exposed by
`existing_wide_corpus.frozen_graphs()`:

\[
1,1,2,1,5,3,18,19
\]

graphs at orders (8,12,16,18,20,22,24,26), respectively.  Reconstructing
their existing plane embeddings and legal-wide inverse splits gives

\[
\begin{array}{c|r}
\text{object}&\text{count}\\ \hline
\text{frozen braces}&50\\
\text{legal-wide sites}&376\\
\text{facial squares}&386\\
\text{distinct legal-wide root-square decorations}&541\\
\text{root-disjoint facial-square cuts, before port orientation}&3656\\
\text{oriented cuts}&29248.
\end{array}
\]

The antecedent was tested in both literal sector directions.  There are
4592 orientations with a (Z^0-A_0^1) antecedent and 5782 with a
(Z^1-A_0^0) antecedent; their union has 9980 orientations because some
orientations support both directions.  The corresponding directed
antecedent-pair counts are 15996 and 15266.  A global exchange of the
sector names preserves every summand of (M), so the second direction is
mathematically the same prefilter orientation and must not be discarded.

The complete mandatory-count distribution on the 9980 antecedent
orientations is

\[
\begin{array}{c|rrrrrrrrrrrrrrrr}
M&2&3&4&5&6&7&8&9&10&11&12&13&14&15&16&17\\
\#&592&762&682&408&510&456&576&532&530&484&554&544&598&460&388&344\\
M&18&19&20&21&22&23&24&25&26&27&28&29&30&31&32&33\\
\#&238&248&214&126&154&134&112&60&88&32&54&16&8&24&16&2\\
M&35&36&37&39&40&41&42&44&47\\
\#&2&8&2&4&2&2&8&4&2.
\end{array}
\]

## Complete support profiles at the sharp minimum

All 592 orientations with (M=2) have one of exactly six nonzero
factor-pair support profiles:

\[
\begin{array}{c|r}
\text{nonzero summands}&\text{multiplicity}\\ \hline
p_{Z0}=1,\ s_Z=1&4\\
p_{Z0}=1,\ p_{Z1}=1&2\\
p_{Z0}=1,\ p_{Z3}=1&2\\
p_{Z0}=1,\ p_{01}=1&290\\
p_{Z0}=1,\ p_{03}=1&290\\
p_{Z0}=2&4.
\end{array}
\]

Here the script labels these rows, respectively, as

```text
N0-N0:1 | N0-N1:1
N0-N1:1 | N0-R1:1
N0-N1:1 | N0-R3:1
N0-N1:1 | N1-R1:1
N0-N1:1 | N1-R3:1
N0-N1:2
```

Consequently 588 of the 592 minimizers are exactly “one designated
antecedent plus one other mandatory compensation.”  The remaining four
are not of that form in the strict factor-pair sense: the same designated
(Z-A_0) factor bond has two distinct carrier copies.  Nevertheless every
minimum orientation has exactly two copies/compensations in total; no
minimum is supported by an unrelated pair that omits (Z-A_0).

## An actual order-16 minimizer

The first sharp example has

```text
graph6          O????B_sDOI_I_DO@W?M?
root square     (8,2,10,0)
root            2-8
forced gate     0-10
surviving gate  7-13
wide arc sizes  5,5
cut face        (5,13,7,15)
ports           (5,13,7,15)
```

The graph is a simple plane cubic bipartite brace.  Its complete compatible
carrier sets and literal surviving-gate sectors are

\[
\begin{array}{c|c|c}
\text{factor row}&\text{carrier rows}&\text{sectors}\\ \hline
N_0&K_2&1\\
N_1&K_{10}&0\\
R_1&K_{11},K_{14}&0,0\\
R_3&K_{17},K_{20}&1,1.
\end{array}
\]

There are exactly two mandatory crossings:

\[
(K_2,N_0)\sim(K_{10},N_1),\qquad
(K_{10},N_1)\sim(K_{20},R_3).
\]

Their carrier atoms are (01+0) closed and (13+0) closed,
respectively.  Globally exchanging sector names puts the first one in the
requested (Z^0-A_0^1) direction without changing (M=2).

## One-defect near-actual (M=1) countermodel

The same order-16 carrier gives a strict abstract boundary that preserves
more actual structure than a freely assigned atom table.  Retain the
literal graph, embedding, brace property, legal-wide root-square geometry,
facial cut, all five other compatible rows, their actual boundary-matching
incidences, complement pairings, sectors, and every pair atom.  Omit only
the actual row

\[
K_{20}=\{0\!-!10,1\!-!9,2\!-!8,3\!-!11,
4\!-!14,6\!-!12,7\!-!13\}.
\]

The restricted row system has exactly one mandatory crossing, namely the
designated (N_0-N_1) copy.  Hence it is an (M=1) abstract countermodel
with a single defect.  Zero row deletions give the actual (M=2) system,
so the defect count is minimal.

This construction pinpoints the first loss precisely.  It does **not**
lose planarity, cubicity, bipartiteness, the brace axiom, a common graph, or
the fact that each retained row is an actual boundary matching of that
graph.  It first ceases to model an actual carrier only at the universal
perfect-matching-family quantifier: (K_{20}) is itself an actual
compatible (A_3) row and therefore cannot be omitted from the complete
carrier row family.  Thus pairwise port atoms plus actual geometry do not
prove (M\ne1); a proof must use completeness/closure of the common cubic
perfect-matching incidence family.  The frozen corpus does not yet reveal
which general closure mechanism forces that missing row or an alternative
second slot.

## Reproduction

From the AIMath root:

```bash
uv run --python 3.14 --with 'networkx==3.6.1' \
  units/barnette/scratch/worker-carrier-prefilter-counterexample/scan_existing_carrier_corpus.py

uv run --python 3.14 --with 'networkx==3.6.1' \
  units/barnette/scratch/worker-carrier-prefilter-counterexample/verify_near_actual_m1_countermodel.py

uv run --python 3.14 --with 'networkx==3.6.1' \
  units/barnette/scratch/worker-carrier-prefilter-counterexample/verify_order16_carrier_m2_and_near_m1.py
```

The terminal markers are

```text
NO_MANDATORY_COUNT_ONE_IN_FROZEN_THROUGH26_CARRIERS
NEAR_ACTUAL_M1_COUNTERMODEL_VERIFIED
ORDER16_CARRIER_M2_AND_NEAR_M1_STANDALONE_VERIFIED
```

The last verifier is the delivery certificate for the sharp example.  It
uses only the Python standard library and NetworkX, imports no scratch
module, and independently reconstructs the literal graph, all 49 perfect
matchings, all 228 independent-edge extension tests, the legal-wide C4
expansion, all 21 carrier boundary rows, the complete six compatible rows,
the two mandatory slots, and the one-row-deletion boundary.

The scan was run twice after introducing row/atom caching; the complete
scope, (M)-distribution, minimum and frozen minimizers agreed.  Its 592
support profiles partition all (M=2) orientations exactly.  The cached
bidirectional analyzer was also compared against the original literal
analyzer on every oriented root-disjoint facial cut of the Note 153
carrier; matching-level antecedents and mandatory counts agree.
