#!/usr/bin/env python3
"""Verify the minimal pure-perfect-matching-cube countermodel.

The graph and every matching vector are literal.  Only the rooted
join-compatibility predicate is abstractly assigned; the verifier exposes
both a calibration with a unique two-cycle-away compensation and an M=1
assignment with no productive compatible repair.
"""

from __future__ import annotations

from collections import Counter

import networkx as nx


def edge(left: int, right: int) -> tuple[int, int]:
    return tuple(sorted((left, right)))


def matching(*items) -> frozenset[tuple[int, int]]:
    return frozenset(edge(*item) for item in items)


VERTICES = tuple(range(12))
PORTS = (10, 11, 0, 9)
Q1 = edge(PORTS[1], PORTS[2])
SURVIVING = edge(9, 10)

A = matching((0, 1), (2, 3), (4, 5), (6, 7), (8, 9))
D = matching((1, 2), (3, 4), (5, 6), (7, 8), (9, 10))
I1 = matching((1, 6), (2, 5), (3, 4), (7, 8), (9, 10))
I2 = matching((1, 2), (5, 6), (3, 8), (4, 7), (9, 10))
K = matching((1, 6), (2, 5), (3, 8), (4, 7), (9, 10))
Z = D | frozenset((Q1,))

C1 = matching((1, 2), (5, 6), (1, 6), (2, 5))
C2 = matching((3, 4), (7, 8), (3, 8), (4, 7))

ROWS = {"Z": Z, "A": A, "D": D, "I1": I1, "I2": I2, "K": K}


def symmetric_difference_atom(first, second):
    difference = first ^ second
    graph = nx.Graph()
    graph.add_edges_from(difference)
    paths = []
    cycles = 0
    for vertices in nx.connected_components(graph):
        component = graph.subgraph(vertices)
        ends = [vertex for vertex, degree in component.degree() if degree == 1]
        if not ends:
            assert set(dict(component.degree()).values()) == {2}
            cycles += 1
        else:
            assert len(ends) == 2
            marks = frozenset(
                index for index, vertex in enumerate(PORTS) if vertex in ends
            )
            assert len(marks) == 2
            paths.append(marks)
    return tuple(sorted(paths, key=tuple)), cycles


def state(item):
    return frozenset(
        index
        for index, vertex in enumerate(PORTS)
        if all(vertex not in value for value in item)
    )


def sector(item) -> int:
    return int(SURVIVING in item)


def productive_count(compatible_z, compatible_a0, compatible_a1):
    counts = Counter()
    for left in compatible_z:
        for right in compatible_a0:
            if sector(left) != sector(right) and symmetric_difference_atom(
                left, right
            ) == ((frozenset((0, 1)),), 0):
                counts["p_Z0"] += 1
    for left in compatible_a0:
        for right in compatible_a1:
            if sector(left) != sector(right) and symmetric_difference_atom(
                left, right
            ) == ((frozenset((0, 2)),), 0):
                counts["p_01"] += 1
    return counts


def main() -> None:
    graph = nx.Graph()
    graph.add_nodes_from(VERTICES)
    graph.add_edges_from((edge(index, index + 1) for index in range(10)))
    graph.add_edges_from(((1, 6), (2, 5), (3, 8), (4, 7), Q1))

    assert len(graph) == 12 and graph.number_of_edges() == 15
    assert nx.number_of_selfloops(graph) == 0 and nx.is_connected(graph)
    assert nx.is_bipartite(graph) and nx.check_planarity(graph)[0]
    assert max(dict(graph.degree()).values()) == 3
    assert set().union(*map(set, ROWS.values())) <= {
        edge(*item) for item in graph.edges()
    }
    for name, item in ROWS.items():
        used = [vertex for value in item for vertex in value]
        assert len(used) == len(set(used)), name

    assert state(Z) == frozenset()
    assert state(A) == frozenset((0, 1))
    assert all(state(item) == frozenset((1, 2)) for item in (D, I1, I2, K))
    assert sector(A) == 0
    assert all(sector(item) == 1 for item in (Z, D, I1, I2, K))
    assert Q1 in Z and Z - frozenset((Q1,)) == D

    assert D ^ I1 == C1 and D ^ I2 == C2
    assert D ^ K == C1 | C2
    assert I1 ^ K == C2 and I2 ^ K == C1
    assert symmetric_difference_atom(D, I1) == ((), 1)
    assert symmetric_difference_atom(D, I2) == ((), 1)
    assert symmetric_difference_atom(D, K) == ((), 2)

    assert symmetric_difference_atom(Z, A) == ((frozenset((0, 1)),), 0)
    assert symmetric_difference_atom(A, D) == ((frozenset((0, 2)),), 0)
    assert symmetric_difference_atom(A, K) == ((frozenset((0, 2)),), 0)
    assert symmetric_difference_atom(A, I1) == ((frozenset((0, 2)),), 1)
    assert symmetric_difference_atom(A, I2) == ((frozenset((0, 2)),), 1)

    # Calibration assignment: the two single-flip intermediates and K are
    # declared rooted-join compatible, while the literal deletion D is not.
    # Only K is productive, and it is two independent flips away from D.
    calibration = productive_count((Z,), (A,), (I1, I2, K))
    assert calibration == Counter({"p_Z0": 1, "p_01": 1})
    assert all(
        symmetric_difference_atom(D, item) == ((), 1)
        for item in (I1, I2)
    )
    assert all(
        symmetric_difference_atom(A, item)[1] == 1 for item in (I1, I2)
    )

    # M=1 assignment: retain the same graph and complete matching cube, but
    # make K rooted-incompatible as well.  The pure PM axioms cannot
    # distinguish this assignment from the calibration.
    m1_assignment = productive_count((Z,), (A,), (I1, I2))
    assert m1_assignment == Counter({"p_Z0": 1})

    # Minimality under an actual sector edge: two independent alternating
    # cycles use at least eight covered vertices; a common matching edge
    # realizing the shared sector uses two further vertices outside them;
    # the A1 state leaves two ports unmatched.  Hence order >= 8+2+2=12.
    cycle_vertices = set().union(*(set(item) for item in C1 | C2))
    assert len(cycle_vertices) == 8
    assert set(SURVIVING).isdisjoint(cycle_vertices)
    assert len(set(PORTS[index] for index in (1, 2))) == 2
    assert len(VERTICES) == 8 + 2 + 2

    print("PURE_PM_CUBE_REMOTE_REPAIR_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()
