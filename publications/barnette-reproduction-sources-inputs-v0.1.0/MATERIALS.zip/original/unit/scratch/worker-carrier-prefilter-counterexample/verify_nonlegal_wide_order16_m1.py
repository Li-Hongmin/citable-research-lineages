#!/usr/bin/env python3
"""A complete-PM M=1 carrier after dropping legal-wide geometry.

This is a deliberately narrow boundary certificate.  The graph is a
simple plane cubic bipartite brace and every carrier row is obtained from
the complete perfect-matching family of that graph.  The root/cut faces and
all ten mandatory terms are checked independently.  The only hypothesis
removed from the legal-wide carrier statement is that the forced and
surviving gate edges lie on one common face with the prescribed wide arcs.

The certificate is therefore *not* a counterexample to the legal-wide
carrier assertion.  It is a counterexample to the version in which that
geometric hypothesis is omitted.
"""

from __future__ import annotations

from collections import Counter
from functools import lru_cache
from itertools import combinations, combinations_with_replacement, product

import networkx as nx


Edge = tuple[int, int]
Matching = frozenset[Edge]
State = frozenset[int]


def edge(u: int, v: int) -> Edge:
    return tuple(sorted((u, v)))


EDGES: tuple[Edge, ...] = tuple(
    edge(*item)
    for item in (
        (0, 8), (0, 9), (0, 10),
        (1, 8), (1, 9), (1, 11),
        (2, 8), (2, 10), (2, 12),
        (3, 9), (3, 11), (3, 13),
        (4, 10), (4, 12), (4, 14),
        (5, 11), (5, 13), (5, 15),
        (6, 12), (6, 14), (6, 15),
        (7, 13), (7, 14), (7, 15),
    )
)

# A full combinatorial plane embedding, listed by facial boundary cycles.
FACE_SYSTEM: tuple[tuple[int, ...], ...] = (
    (0, 9, 1, 8),
    (0, 10, 4, 14, 7, 13, 3, 9),
    (0, 8, 2, 10),
    (1, 9, 3, 11),
    (1, 11, 5, 15, 6, 12, 2, 8),
    (2, 12, 4, 10),
    (3, 13, 5, 11),
    (4, 12, 6, 14),
    (5, 13, 7, 15),
    (6, 15, 7, 14),
)

ROOT_FACE = (0, 9, 1, 8)
CUT_FACE = (6, 14, 4, 12)
PORTS = CUT_FACE
ROOT = edge(0, 9)
FORCED = edge(1, 8)
SURVIVING = edge(2, 10)
CUT_EDGES = (edge(PORTS[0], PORTS[1]), edge(PORTS[2], PORTS[3]))
ROOT_ATTACHMENTS = (10, 3, 11, 2)

EMPTY = frozenset()
OMEGA = frozenset((0, 1, 2, 3))
A0 = frozenset((0, 1))
A1 = frozenset((1, 2))
A2 = frozenset((2, 3))
A3 = frozenset((0, 3))
STATES = (EMPTY, OMEGA, A0, A1, A2, A3)

FACTOR_ROWS = {
    "N0": (EMPTY, (frozenset((0, 1)), frozenset((2, 3)))),
    "N1": (A0, (frozenset((2, 3)),)),
    "R1": (A1, (frozenset((0, 3)),)),
    "R3": (A3, (frozenset((1, 2)),)),
}
ONE_PATH_ATOMS = {
    frozenset(("N0", "N1")): frozenset((0, 1)),
    frozenset(("N0", "R1")): frozenset((1, 2)),
    frozenset(("N0", "R3")): frozenset((0, 3)),
    frozenset(("N1", "R1")): frozenset((0, 2)),
    frozenset(("N1", "R3")): frozenset((1, 3)),
}
R1_R3_PAIRING = frozenset(
    (frozenset((1, 2)), frozenset((0, 3)))
)
REQUIRED_ROOT_PAIRS = frozenset(
    (frozenset((0, 3)), frozenset((1, 2)))
)


def enumerate_matchings(
    graph: nx.Graph,
    removed_vertices: frozenset[int] = frozenset(),
    required: Matching = frozenset(),
) -> tuple[Matching, ...]:
    """Enumerate all perfect matchings of the specified vertex set."""

    assert all(graph.has_edge(*item) for item in required)
    used = {vertex for item in required for vertex in item}
    assert len(used) == 2 * len(required)
    vertices = tuple(sorted(set(graph) - set(removed_vertices) - used))
    position = {vertex: index for index, vertex in enumerate(vertices)}
    neighbours = [0] * len(vertices)
    for left, right in graph.edges():
        if left in position and right in position:
            neighbours[position[left]] |= 1 << position[right]
            neighbours[position[right]] |= 1 << position[left]

    @lru_cache(maxsize=None)
    def solve(mask: int):
        if not mask:
            return ((),)
        choices_vertices = [
            index for index in range(len(vertices)) if mask >> index & 1
        ]
        first = min(
            choices_vertices,
            key=lambda index: ((neighbours[index] & mask).bit_count(), index),
        )
        choices = neighbours[first] & mask
        remainder = mask ^ (1 << first)
        rows = []
        while choices:
            bit = choices & -choices
            choices ^= bit
            second = bit.bit_length() - 1
            for suffix in solve(remainder ^ bit):
                rows.append(((first, second),) + suffix)
        return tuple(rows)

    return tuple(
        required
        | frozenset(edge(vertices[left], vertices[right]) for left, right in row)
        for row in solve((1 << len(vertices)) - 1)
    )


def profile(
    cut: nx.Graph, matching: Matching
) -> tuple[tuple[str, frozenset[int], frozenset[int]], ...] | None:
    """Marked complement components after deleting the root-square vertices."""

    residual = cut.subgraph(set(cut) - set(ROOT_FACE)).copy()
    residual.remove_edges_from(matching)
    components = []
    for vertices in nx.connected_components(residual):
        component = residual.subgraph(vertices)
        degrees = tuple(dict(component.degree()).values())
        marks = frozenset(
            i for i, vertex in enumerate(PORTS) if vertex in vertices
        )
        roots = frozenset(
            i for i, vertex in enumerate(ROOT_ATTACHMENTS) if vertex in vertices
        )
        if degrees and all(value == 2 for value in degrees):
            kind = "cycle"
        elif degrees and all(value in {1, 2} for value in degrees):
            kind = "path"
        else:
            return None
        components.append((kind, marks, roots))
    return tuple(
        sorted(components, key=lambda item: (item[0], tuple(item[1]), tuple(item[2])))
    )


def factor_join_passes(
    components: tuple[tuple[str, frozenset[int], frozenset[int]], ...] | None,
    state: State,
    factor_pairs: tuple[frozenset[int], ...],
) -> bool:
    if components is None or any(kind == "cycle" for kind, _p, _r in components):
        return False
    auxiliary = nx.Graph()
    marks = {}
    for index, (_kind, ports, roots) in enumerate(components):
        name = ("carrier", index)
        auxiliary.add_node(name)
        marks[name] = set(roots)
    for index, pair in enumerate(factor_pairs):
        name = ("factor", index)
        auxiliary.add_node(name)
        marks[name] = set()
        for port in pair:
            owners = [
                ("carrier", ordinal)
                for ordinal, (_k, ports, _r) in enumerate(components)
                if port in ports
            ]
            if len(owners) != 1:
                return False
            auxiliary.add_edge(name, owners[0])
    if set().union(*(set(pair) for pair in factor_pairs)) != set(range(4)) - set(state):
        return False
    root_pairs = set()
    for vertices in nx.connected_components(auxiliary):
        roots = frozenset().union(*(marks[vertex] for vertex in vertices))
        if len(roots) != 2:
            return False
        root_pairs.add(roots)
    return root_pairs == REQUIRED_ROOT_PAIRS


def bond_atom(
    cut: nx.Graph, first_state: State, first: Matching,
    second_state: State, second: Matching,
) -> tuple[tuple[frozenset[int], ...], int] | None:
    difference = first ^ second
    if not difference:
        return (), 0
    difference_graph = nx.edge_subgraph(cut, difference).copy()
    paths = []
    cycles = 0
    for vertices in nx.connected_components(difference_graph):
        component = difference_graph.subgraph(vertices)
        ends = [vertex for vertex, degree in component.degree() if degree == 1]
        if not ends:
            if set(dict(component.degree()).values()) != {2}:
                return None
            cycles += 1
        else:
            if len(ends) != 2:
                return None
            marks = frozenset(
                i for i, vertex in enumerate(PORTS) if vertex in ends
            )
            if len(marks) != 2:
                return None
            paths.append(marks)
    expected = set(first_state ^ second_state)
    actual = set().union(*(set(path) for path in paths)) if paths else set()
    if actual != expected:
        return None
    return tuple(sorted(paths, key=tuple)), cycles


def joined_is_one_cycle(left: str, right: str, atom) -> bool:
    if atom is None:
        return False
    paths, closed = atom
    if left == right:
        return paths == () and closed == 1
    if closed:
        return False
    labels = frozenset((left, right))
    if labels in ONE_PATH_ATOMS:
        return len(paths) == 1 and paths[0] == ONE_PATH_ATOMS[labels]
    assert labels == frozenset(("R1", "R3")), labels
    return len(paths) == 2 and frozenset(paths) != R1_R3_PAIRING


def face_edges(face: tuple[int, ...]) -> frozenset[Edge]:
    return frozenset(edge(face[i], face[(i + 1) % len(face)]) for i in range(len(face)))


def main() -> None:
    graph = nx.Graph()
    graph.add_nodes_from(range(16))
    graph.add_edges_from(EDGES)

    # The underlying graph is an actual brace, not an abstract matching table.
    assert graph.number_of_edges() == 24
    assert nx.number_of_selfloops(graph) == 0
    assert nx.is_connected(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.is_bipartite(graph)
    assert nx.check_planarity(graph)[0]
    perfect_matchings = enumerate_matchings(graph)
    assert len(perfect_matchings) == 49
    independent_pairs = tuple(
        (edge(*left), edge(*right))
        for left, right in combinations(graph.edges(), 2)
        if set(left).isdisjoint(right)
    )
    assert len(independent_pairs) == 228
    assert all(
        any(left in matching and right in matching for matching in perfect_matchings)
        for left, right in independent_pairs
    )
    assert nx.node_connectivity(graph) >= 3

    # Check the supplied embedding combinatorially (each edge occurs twice,
    # Euler characteristic is two, and the two marked faces are present).
    face_edge_counts = Counter(
        item
        for face in FACE_SYSTEM
        for item in face_edges(face)
    )
    assert set(face_edge_counts) == set(EDGES)
    assert set(face_edge_counts.values()) == {2}
    assert len(set().union(*(set(face) for face in FACE_SYSTEM))) == 16
    assert 16 - 24 + len(FACE_SYSTEM) == 2
    assert face_edges(ROOT_FACE) in {face_edges(face) for face in FACE_SYSTEM}
    assert face_edges(CUT_FACE) in {face_edges(face) for face in FACE_SYSTEM}
    assert set(ROOT_FACE).isdisjoint(CUT_FACE)

    # This is exactly where the legal-wide hypothesis is absent: the two
    # gate edges have no common face in the displayed embedding.
    assert not any(
        {FORCED, SURVIVING} <= face_edges(face) for face in FACE_SYSTEM
    )

    cut = graph.copy()
    cut.remove_edges_from(CUT_EDGES)
    required = frozenset((ROOT, FORCED))
    rows = []
    for state in STATES:
        removed = frozenset(PORTS[index] for index in state)
        for matching in enumerate_matchings(cut, removed, required):
            rows.append((state, matching, profile(cut, matching)))
    assert len(rows) == 19
    assert Counter(state for state, _m, _p in rows) == Counter(
        {EMPTY: 5, OMEGA: 3, A0: 3, A1: 3, A2: 2, A3: 3}
    )

    # Every row is the restriction of a member of the *complete* PM family.
    # This checks that no row-family deletion is being used in this model.
    square_edges = {
        EMPTY: (),
        OMEGA: CUT_EDGES,
        A0: (CUT_EDGES[0],),
        A1: (edge(PORTS[1], PORTS[2]),),
        A2: (CUT_EDGES[1],),
        A3: (edge(PORTS[3], PORTS[0]),),
    }
    complete_set = set(perfect_matchings)
    for state, matching, _p in rows:
        completed = matching | frozenset(square_edges[state])
        assert completed in complete_set

    compatible = {}
    for label, (state, pairs) in FACTOR_ROWS.items():
        compatible[label] = tuple(
            index for index, (row_state, _m, marked) in enumerate(rows)
            if row_state == state and factor_join_passes(marked, state, pairs)
        )
    assert {label: len(indices) for label, indices in compatible.items()} == {
        "N0": 1, "N1": 1, "R1": 2, "R3": 2
    }

    sectors = {
        index: int(SURVIVING in rows[index][1])
        for indices in compatible.values()
        for index in indices
    }
    assert {
        label: tuple(sectors[index] for index in indices)
        for label, indices in compatible.items()
    } == {
        "N0": (1,), "N1": (0,), "R1": (1, 1), "R3": (1, 1)
    }

    counts = Counter()
    slots = []
    labels = tuple(FACTOR_ROWS)
    for left_label, right_label in combinations_with_replacement(labels, 2):
        left_rows = compatible[left_label]
        right_rows = compatible[right_label]
        candidates = (
            combinations(left_rows, 2)
            if left_label == right_label
            else product(left_rows, right_rows)
        )
        for left, right in candidates:
            if sectors[left] == sectors[right]:
                continue
            left_state, left_matching, _ = rows[left]
            right_state, right_matching, _ = rows[right]
            atom = bond_atom(
                cut, left_state, left_matching, right_state, right_matching
            )
            if joined_is_one_cycle(left_label, right_label, atom):
                counts[f"{left_label}-{right_label}"] += 1
                slots.append((left_label, right_label, left, right, atom))

    expected_labels = {
        f"{left}-{right}": 0
        for left, right in combinations_with_replacement(labels, 2)
    }
    expected_labels["N0-N1"] = 1
    assert dict(counts) == {"N0-N1": 1}
    assert {**expected_labels, **counts} == expected_labels
    assert len(slots) == 1
    left_label, right_label, left, right, atom = slots[0]
    assert (left_label, right_label) == ("N0", "N1")
    assert atom == ((frozenset((0, 1)),), 0)
    assert sectors[left] != sectors[right]

    # Explicitly report the complete PM and carrier counts used in the claim.
    print("graph_vertices=16")
    print("graph_edges=24")
    print("complete_perfect_matchings=49")
    print("brace_independent_pairs=228")
    print("carrier_rows=19")
    print("compatible_rows=N0:1,N1:1,R1:2,R3:2")
    print("mandatory_terms=N0-N1:1; all_other_terms:0")
    print("M=1")
    print("forced_surviving_gate_common_face=false")
    print("NONLEGAL_WIDE_ORDER16_M1_COMPLETE_PM_VERIFIED")


if __name__ == "__main__":
    main()
