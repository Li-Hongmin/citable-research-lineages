#!/usr/bin/env python3
"""Verify a one-row-deletion M=1 countermodel inside an actual carrier.

The graph, legal-wide root-square decoration, cut, and every retained row
are literal.  The sole abstraction is that one actual compatible carrier
row is omitted from the purported *complete* carrier-row family.
"""

from __future__ import annotations

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def load_module(path: Path, name: str):
    spec = spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


scan = load_module(HERE / "scan_existing_carrier_corpus.py", "near_actual_m1_base")
edge = scan.edge

GRAPH6 = "O????B_sDOI_I_DO@W?M?"
ROOT_SQUARE = (8, 2, 10, 0)
ROOT = edge(2, 8)
FORCED = edge(0, 10)
SURVIVING = edge(7, 13)
CUT_FACE = (5, 13, 7, 15)
PORTS = CUT_FACE
OMITTED_MATCHING = frozenset(
    edge(*item)
    for item in (
        (0, 10),
        (1, 9),
        (3, 11),
        (4, 14),
        (6, 12),
        (7, 13),
        (2, 8),
    )
)


def face_edge_set(face):
    return frozenset(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert len(graph) == 16 and graph.number_of_edges() == 24
    assert nx.number_of_selfloops(graph) == 0
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    assert nx.node_connectivity(graph) >= 3
    assert scan.corpus.lift.verify_brace(graph)

    faces = scan.corpus.source.plane_faces(graph, embedding)
    facial_sets = {face_edge_set(face) for face in faces}
    assert face_edge_set(ROOT_SQUARE) in facial_sets
    assert face_edge_set(CUT_FACE) in facial_sets
    assert set(ROOT_SQUARE).isdisjoint(CUT_FACE)
    root_edges = scan.square_edges(ROOT_SQUARE)
    assert root_edges[0] == ROOT and root_edges[2] == FORCED

    reduced, rotations = scan.corpus.lift.dual_from_primal_faces(graph, faces)
    scan.corpus.lift.verify_reduced_triangulation(reduced)
    splits = scan.corpus.wide.legal_wide_splits(
        reduced, rotations, scan.Counter()
    )
    dual_to_primal = scan.corpus.wide.primal_edge_by_dual_edge(graph, faces)
    matching_sites = []
    for split in splits:
        z = int(split["z"])
        gates = frozenset(
            edge(
                *dual_to_primal[
                    scan.corpus.edge(z, int(split[label]))
                ]
            )
            for label in ("first_gate", "second_gate")
        )
        if gates == frozenset((FORCED, SURVIVING)):
            matching_sites.append(split)
    assert matching_sites
    assert any(
        sorted((int(item["left_size"]), int(item["right_size"]))) == [5, 5]
        for item in matching_sites
    )

    record = {
        "name": "order16-near-actual-m1",
        "graph": graph,
        "root_square": ROOT_SQUARE,
        "root": ROOT,
        "forced": FORCED,
        "surviving": SURVIVING,
    }
    result = scan.analyze_orientation_both_sectors(record, CUT_FACE, PORTS)
    assert result is not None
    assert result["antecedents_01"] == []
    assert len(result["antecedents_10"]) == 1
    assert result["mandatory_count"] == 2
    assert result["counts_by_factor_pair"] == {
        "N0-N0": 0,
        "N0-N1": 1,
        "N0-R1": 0,
        "N0-R3": 0,
        "N1-N1": 0,
        "N1-R1": 0,
        "N1-R3": 1,
        "R1-R1": 0,
        "R1-R3": 0,
        "R3-R3": 0,
    }
    compatible_total = sum(map(len, result["compatible_rows"].values()))
    assert compatible_total == 6

    omitted_indices = [
        int(index)
        for index, matching in result["row_matchings"].items()
        if frozenset(edge(*item) for item in matching) == OMITTED_MATCHING
    ]
    assert len(omitted_indices) == 1
    omitted = omitted_indices[0]
    assert omitted in result["compatible_rows"]["R3"]
    assert result["compatible_sectors"]["R3"][
        result["compatible_rows"]["R3"].index(omitted)
    ] == 1

    retained_slots = [
        slot
        for slot in result["slots"]
        if omitted not in slot["carrier_rows"]
    ]
    assert len(retained_slots) == 1
    assert retained_slots[0]["factor_pair"] == "N0-N1"
    assert retained_slots[0]["carrier_atom"] == {
        "paths": [[0, 1]], "closed": 0
    }
    # The literal direction is Z^1--A0^0.  Globally renaming sectors by
    # b -> 1-b gives the requested Z^0--A0^1 direction and preserves M.
    assert retained_slots[0]["carrier_sectors"] == [1, 0]

    print("actual_carrier_order=16")
    print("actual_complete_mandatory_count=2")
    print("omitted_actual_compatible_row=R3")
    print("abstract_retained_mandatory_count=1")
    print("NEAR_ACTUAL_M1_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()
