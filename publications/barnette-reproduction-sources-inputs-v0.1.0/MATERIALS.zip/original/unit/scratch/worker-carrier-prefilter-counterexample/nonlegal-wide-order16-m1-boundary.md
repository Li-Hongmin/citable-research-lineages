# Complete-PM (M=1) boundary after removing legal-wide geometry

## Decision

The complete perfect-matching incidence of a simple plane cubic bipartite
brace does not by itself imply the Note 160 carrier prefilter

\[
p_{Z0}>0\quad\Longrightarrow\quad M\ge 2.
\]

There is an explicit order-16 brace for which the full perfect-matching
family is used (no compatible row is deleted), but a non-legal-wide root/cut
decoration has

\[
p_{Z0}=1,\qquad
s_Z=s_0=s_1=s_3=p_{Z1}=p_{Z3}=p_{01}=p_{03}=t_{13}=0.
\]

Thus (M=1).  This is **not** a counterexample to the legal-wide carrier
statement: the forced and surviving gate edges in this decoration have no
common face, so the legal-wide gate hypothesis fails exactly there.

## Literal graph and embedding

The graph has vertex set (0,\ldots,15) and edge set

\[
\begin{aligned}
E=\{&(0,8),(0,9),(0,10),
(1,8),(1,9),(1,11),
(2,8),(2,10),(2,12),\\
&(3,9),(3,11),(3,13),
(4,10),(4,12),(4,14),
(5,11),(5,13),(5,15),\\
&(6,12),(6,14),(6,15),
(7,13),(7,14),(7,15)\}.
\end{aligned}
\]

It is simple, connected, cubic, bipartite, planar, 3-connected, and a
brace: direct enumeration gives 49 perfect matchings, and all 228 pairs of
independent edges occur together in at least one of them.

The displayed plane embedding has facial boundary cycles

\[
\begin{gathered}
(0,9,1,8),\quad (0,10,4,14,7,13,3,9),\quad (0,8,2,10),\\
(1,9,3,11),\quad (1,11,5,15,6,12,2,8),\quad (2,12,4,10),\\
(3,13,5,11),\quad (4,12,6,14),\quad (5,13,7,15),\quad (6,15,7,14).
\end{gathered}
\]

Every edge occurs in exactly two listed faces and (16-24+10=2).  The
root face and cut face are respectively

\[
R=(0,9,1,8),\qquad Q=(6,14,4,12).
\]

The opposite cut edges deleted for the carrier are (6\!-!14) and
(4\!-!12), with cyclic port order

\[
(p_0,p_1,p_2,p_3)=(6,14,4,12).
\]

The required root and forced edges are (0\!-!9) and (1\!-!8); the
surviving gate is (2\!-!10).  No listed face contains both (1\!-!8)
and (2\!-!10), which certifies failure of the legal-wide common-gate
face condition.  (The root and forced edges are still opposite edges of the
root square, and the root/cut squares are disjoint.)

## Complete carrier-row calculation

Delete the two cut edges and enumerate, for each state

\[
\varnothing,\ \Omega=0123,\ A_0=01,\ A_1=12,\ A_2=23,\ A_3=30,
\]

all matchings containing both required edges and covering every non-port
vertex.  There are 19 rows, with state counts

\[
(5,3,3,3,2,3)
\]

in the order ((\varnothing,\Omega,A_0,A_1,A_2,A_3)).  Completing a row by
the corresponding cut edge(s) gives a member of the same complete set of
49 perfect matchings; this checks that the carrier family is not a row-
deletion model.

The rows that pass the four rooted factor-join tests are exactly

\[
\begin{array}{c|c|c}
\text{factor row}&\text{state}&\text{surviving-gate bit}\\ \hline
N_0&\varnothing&1\\
N_1&A_0&0\\
R_1&A_1&1,1\\
R_3&A_3&1,1.
\end{array}
\]

Their matching edge sets (in the order above, with the two rows in each
last entry) are

\[
\begin{aligned}
N_0={}&\{09,18,2\!\,10,3\!\,11,6\!\,12,5\!\,13,4\!\,14,7\!\,15\},\\
N_1={}&\{09,18,4\!\,10,3\!\,11,2\!\,12,5\!\,13,7\!\,15\},\\
R_1^{(1)}={}&\{09,18,2\!\,10,3\!\,11,6\!\,12,7\!\,13,5\!\,15\},\\
R_1^{(2)}={}&\{09,18,2\!\,10,5\!\,11,6\!\,12,3\!\,13,7\!\,15\},\\
R_3^{(1)}={}&\{09,18,2\!\,10,3\!\,11,7\!\,13,4\!\,14,5\!\,15\},\\
R_3^{(2)}={}&\{09,18,2\!\,10,5\!\,11,3\!\,13,4\!\,14,7\!\,15\}.
\end{aligned}
\]

Here (09) abbreviates the edge (0\!-!9), etc.  The root attachment
marks are (10,3,11,2), in that order.  All six rows above are actual
rows extracted from the complete PM family.

## Ten mandatory terms

For two rows, decompose their symmetric difference into port-ended paths
and closed alternating cycles.  Combining this bond atom with the ten fixed
factor atoms gives the exact Note 160 terms.  The sectors are

\[
N_0:1,\qquad N_1:0,\qquad R_1:1,1,\qquad R_3:1,1.
\]

The only productive opposite-sector pair is

\[
N_0\text{--}N_1,
\qquad d_C(N_0,N_1)=01+0\text{ closed cycles}.
\]

Every other one of the ten terms is zero, including all same-row closed
cycle terms and the (N_0R_1,N_0R_3,N_1R_1,N_1R_3,R_1R_3) path/pairing terms.
Consequently

\[
\boxed{(p_{Z0},s_Z,s_0,s_1,s_3,p_{Z1},p_{Z3},p_{01},p_{03},t_{13})
=(1,0,0,0,0,0,0,0,0,0),\quad M=1.}
\]

The certificate is intentionally limited: it shows that cubicity,
planarity, bipartiteness, 3-connectivity, the brace property, and complete
perfect-matching incidence do not replace the legal-wide gate-face
hypothesis.  It does not test or refute (M\ne1) when that hypothesis is
retained.

## Reproduction

From the AIMath root run:

```bash
python3 units/barnette/scratch/worker-carrier-prefilter-counterexample/verify_nonlegal_wide_order16_m1.py
```

The terminal marker is

```text
NONLEGAL_WIDE_ORDER16_M1_COMPLETE_PM_VERIFIED
```
