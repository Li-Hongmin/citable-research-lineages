#!/usr/bin/env python3
"""Search the frozen through-26 carrier corpus for mandatory count one.

No graph is generated.  The only graph inputs are the 50 graph6 strings
already frozen in permanent computation bundles and exposed by
``existing_wide_corpus.frozen_graphs``.  On each graph we reconstruct the
already-used legal-wide sites, retain those gate orientations for which the
forced gate is opposite a root edge on a facial square, and test every
root-disjoint facial square cut in every cyclic orientation.

The scan stops at the first directed Z^0--A0^1 antecedent with mandatory
four-row count M=1.  If there is no such carrier, it reports the exact finite
minimum and distribution in this frozen corpus.
"""

from __future__ import annotations

from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, combinations_with_replacement, product
from pathlib import Path
import json
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[1]
BUNDLES = BARNETTE / "computations" / "bundles"


def load_module(path: Path, name: str):
    spec = spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


prefilter = load_module(
    BARNETTE
    / "scratch"
    / "worker-frozen-carrier-mandatory-prefilter"
    / "mandatory_four_row_prefilter.py",
    "existing_carrier_prefilter_base",
)
corpus = load_module(
    BUNDLES
    / "paired-restricted-gate-coloop-boundary"
    / "existing_wide_corpus.py",
    "existing_carrier_corpus_base",
)

base = prefilter.base
edge = base.edge


_matching_cache = {}
_row_cache = {}
_atom_cache = {}


def carrier_rows_cached(graph, root_square, root, forced, ports):
    """The literal base routine with matching enumeration cached by cut/state."""

    cut_edges = frozenset((edge(ports[0], ports[1]), edge(ports[2], ports[3])))
    cut = graph.copy()
    cut.remove_edges_from(cut_edges)
    required = frozenset((edge(*root), edge(*forced)))
    row_key = (id(graph), tuple(root_square), cut_edges, required)
    cached = _row_cache.get(row_key)
    if cached is not None:
        canonical_ports, canonical_rows = cached
        if canonical_ports == tuple(ports):
            return cut, canonical_rows
        new_index = {vertex: index for index, vertex in enumerate(ports)}
        relabel = {
            index: new_index[vertex]
            for index, vertex in enumerate(canonical_ports)
        }
        transformed = []
        for state, matching, profile in canonical_rows:
            new_state = frozenset(relabel[index] for index in state)
            new_profile = tuple(
                (
                    kind,
                    frozenset(relabel[index] for index in port_marks),
                    root_marks,
                )
                for kind, port_marks, root_marks in profile
            )
            transformed.append((new_state, matching, new_profile))
        return cut, tuple(transformed)

    attachments = base.root_attachments(graph, root_square)
    rows = []
    for state in base.STATES:
        removed = frozenset(ports[index] for index in state)
        key = (id(graph), cut_edges, removed, required)
        matchings = _matching_cache.get(key)
        if matchings is None:
            matchings = base.enumerate_required_matchings(cut, removed, required)
            _matching_cache[key] = matchings
        for matching in matchings:
            profile = base.complement_components(
                cut, root_square, attachments, ports, matching
            )
            if profile is not None:
                rows.append((state, matching, profile))
    result = tuple(rows)
    _row_cache[row_key] = (tuple(ports), result)
    return cut, result


def bond_atom_cached(graph, cut, ports, first, second):
    """Return the carrier atom, caching the underlying actual endpoints."""

    state_first, matching_first = first
    state_second, matching_second = second
    cut_edges = frozenset((edge(ports[0], ports[1]), edge(ports[2], ports[3])))
    key = (
        id(graph),
        cut_edges,
        frozenset((matching_first, matching_second)),
    )
    raw = _atom_cache.get(key, "missing")
    if raw == "missing":
        difference = matching_first ^ matching_second
        if not difference:
            raw = ((), 0)
        else:
            difference_graph = nx.edge_subgraph(cut, difference).copy()
            actual_paths = []
            cycles = 0
            raw = None
            for vertices in nx.connected_components(difference_graph):
                component = difference_graph.subgraph(vertices)
                ends = [
                    vertex for vertex, degree in component.degree() if degree == 1
                ]
                if not ends:
                    if set(dict(component.degree()).values()) != {2}:
                        raw = None
                        break
                    cycles += 1
                else:
                    if len(ends) != 2:
                        raw = None
                        break
                    actual_paths.append(frozenset(ends))
            else:
                raw = (tuple(actual_paths), cycles)
        _atom_cache[key] = raw
    if raw is None:
        return None
    actual_paths, cycles = raw
    port_index = {vertex: index for index, vertex in enumerate(ports)}
    try:
        paths = tuple(
            sorted(
                (
                    frozenset(port_index[vertex] for vertex in endpoints)
                    for endpoints in actual_paths
                ),
                key=tuple,
            )
        )
    except KeyError:
        return None
    if any(len(path) != 2 for path in paths):
        return None
    expected = set(state_first ^ state_second)
    actual = set().union(*map(set, paths)) if paths else set()
    if actual != expected:
        return None
    return paths, cycles


def analyze_orientation_both_sectors(record, face, ports):
    """Compute M and admit both Z0--A0^1 and Z1--A0^0 antecedents."""

    graph = record["graph"]
    cut, rows = carrier_rows_cached(
        graph, record["root_square"], record["root"], record["forced"], ports
    )
    surviving = edge(*record["surviving"])
    compatible = {}
    for label, (state, factor_pairs) in prefilter.FACTOR_ROWS.items():
        compatible[label] = tuple(
            index
            for index, (row_state, _matching, profile) in enumerate(rows)
            if row_state == state
            and base.factor_join_passes(profile, state, factor_pairs)
        )
    sector = {
        index: int(surviving in rows[index][1])
        for indices in compatible.values()
        for index in indices
    }
    antecedents_01 = tuple(
        (left, right)
        for left in compatible["N0"]
        for right in compatible["N1"]
        if sector[left] == 0
        and sector[right] == 1
        and bond_atom_cached(
            graph, cut, ports, rows[left][:2], rows[right][:2]
        )
        == ((frozenset((0, 1)),), 0)
    )
    antecedents_10 = tuple(
        (left, right)
        for left in compatible["N0"]
        for right in compatible["N1"]
        if sector[left] == 1
        and sector[right] == 0
        and bond_atom_cached(
            graph, cut, ports, rows[left][:2], rows[right][:2]
        )
        == ((frozenset((0, 1)),), 0)
    )
    if not antecedents_01 and not antecedents_10:
        return None

    slots = []
    slot_counts = Counter()
    labels = tuple(prefilter.FACTOR_ROWS)
    for left_label, right_label in combinations_with_replacement(labels, 2):
        left_rows = compatible[left_label]
        right_rows = compatible[right_label]
        candidates = (
            combinations(left_rows, 2)
            if left_label == right_label
            else product(left_rows, right_rows)
        )
        for left, right in candidates:
            if sector[left] == sector[right]:
                continue
            carrier_atom = bond_atom_cached(
                graph, cut, ports, rows[left][:2], rows[right][:2]
            )
            if not prefilter.joined_is_one_cycle(
                left_label, right_label, carrier_atom
            ):
                continue
            label = prefilter.pair_label(left_label, right_label)
            slot_counts[label] += 1
            slots.append(
                {
                    "factor_pair": label,
                    "carrier_rows": [left, right],
                    "carrier_sectors": [sector[left], sector[right]],
                    "carrier_atom": {
                        "paths": [sorted(path) for path in carrier_atom[0]],
                        "closed": carrier_atom[1],
                    },
                }
            )

    return {
        "name": record["name"],
        "face": list(face),
        "ports": list(ports),
        "cut_edges": [
            list(edge(ports[0], ports[1])), list(edge(ports[2], ports[3]))
        ],
        "compatible_rows": {
            label: list(indices) for label, indices in compatible.items()
        },
        "compatible_sectors": {
            label: [sector[index] for index in indices]
            for label, indices in compatible.items()
        },
        "antecedents_01": [list(pair) for pair in antecedents_01],
        "antecedents_10": [list(pair) for pair in antecedents_10],
        "mandatory_count": len(slots),
        "counts_by_factor_pair": {
            label: slot_counts[label] for label in prefilter.FACTOR_PAIR_LABELS
        },
        "slots": slots,
        "row_matchings": {
            str(index): [
                list(item) for item in sorted(rows[index][1], key=repr)
            ]
            for index in sorted(
                set(index for values in compatible.values() for index in values)
            )
        },
    }


def square_edges(square: tuple[int, ...]) -> tuple[tuple[int, int], ...]:
    assert len(square) == 4
    return tuple(edge(square[i], square[(i + 1) % 4]) for i in range(4))


def oriented_root_square(
    square: tuple[int, ...], root: tuple[int, int], forced: tuple[int, int]
) -> tuple[int, ...]:
    """Orient Q=(u,v,x,y) so root=uv and forced=xy."""

    for candidate in base.cyclic_orientations(square):
        edges = square_edges(candidate)
        if edges[0] == root and edges[2] == forced:
            return candidate
    raise AssertionError((square, root, forced))


def root_square_decorations(
    graph: nx.Graph,
    faces: tuple[tuple[int, ...], ...],
    splits: tuple[dict[str, object], ...],
    dual_to_primal: dict[tuple[int, int], tuple[int, int]],
):
    """Yield distinct (Q,e,g0,g1,site) actual legal-wide decorations."""

    squares = tuple(tuple(face) for face in faces if len(face) == 4)
    seen = set()
    for split_index, split in enumerate(splits):
        z = int(split["z"])
        first = edge(
            *dual_to_primal[
                corpus.edge(z, int(split["first_gate"]))
            ]
        )
        second = edge(
            *dual_to_primal[
                corpus.edge(z, int(split["second_gate"]))
            ]
        )
        for forced, surviving in ((first, second), (second, first)):
            for square in squares:
                edges = square_edges(square)
                if forced not in edges:
                    continue
                root = edges[(edges.index(forced) + 2) % 4]
                oriented = oriented_root_square(square, root, forced)
                key = (
                    frozenset(edges),
                    root,
                    forced,
                    surviving,
                    z,
                    frozenset((first, second)),
                )
                if key in seen:
                    continue
                seen.add(key)
                yield {
                    "root_square": oriented,
                    "root": root,
                    "forced": forced,
                    "surviving": surviving,
                    "site": {
                        "split_index": split_index,
                        "dual_vertex": z,
                        "dual_gate_pair": [
                            int(split["first_gate"]), int(split["second_gate"])
                        ],
                        "closed_arc_cardinalities": [
                            int(split["left_size"]), int(split["right_size"])
                        ],
                    },
                }


def compact_result(
    order: int,
    graph6: str,
    decoration: dict[str, object],
    result: dict[str, object],
) -> dict[str, object]:
    return {
        "order": order,
        "graph6": graph6,
        "root_square": list(decoration["root_square"]),
        "root": list(decoration["root"]),
        "forced_gate": list(decoration["forced"]),
        "surviving_gate": list(decoration["surviving"]),
        "site": decoration["site"],
        "cut_face": result["face"],
        "ports": result["ports"],
        "cut_edges": result["cut_edges"],
        "antecedent_count_01": len(result["antecedents_01"]),
        "antecedent_count_10": len(result["antecedents_10"]),
        "mandatory_count": result["mandatory_count"],
        "counts_by_factor_pair": result["counts_by_factor_pair"],
        "compatible_rows": result["compatible_rows"],
        "compatible_sectors": result["compatible_sectors"],
        "antecedents_01": result["antecedents_01"],
        "antecedents_10": result["antecedents_10"],
        "slots": result["slots"],
        "row_matchings": result["row_matchings"],
    }


def scan() -> dict[str, object]:
    counts = Counter()
    mandatory_distribution = Counter()
    m2_profile_distribution = Counter()
    minimum = None
    minimizers = []
    first_m1 = None

    frozen = corpus.frozen_graphs()
    for order, graph6_values in frozen.items():
        for graph_index, graph6 in enumerate(graph6_values):
            _matching_cache.clear()
            _row_cache.clear()
            _atom_cache.clear()
            counts["frozen_graphs"] += 1
            graph = nx.from_graph6_bytes(graph6.encode())
            planar, embedding = nx.check_planarity(graph, counterexample=True)
            assert planar and isinstance(embedding, nx.PlanarEmbedding)
            faces = corpus.source.plane_faces(graph, embedding)
            assert corpus.lift.verify_brace(graph)
            reduced, rotations = corpus.lift.dual_from_primal_faces(graph, faces)
            corpus.lift.verify_reduced_triangulation(reduced)
            split_counts = Counter()
            splits = corpus.wide.legal_wide_splits(reduced, rotations, split_counts)
            counts["legal_wide_sites"] += len(splits)
            dual_to_primal = corpus.wide.primal_edge_by_dual_edge(graph, faces)
            squares = tuple(tuple(face) for face in faces if len(face) == 4)
            counts["facial_squares"] += len(squares)

            decorations = tuple(
                root_square_decorations(graph, faces, splits, dual_to_primal)
            )
            counts["legal_wide_root_square_decorations"] += len(decorations)
            for decoration_index, decoration in enumerate(decorations):
                record = {
                    "name": f"frozen-{order}-{graph_index}-{decoration_index}",
                    "graph": graph,
                    "root_square": decoration["root_square"],
                    "root": decoration["root"],
                    "forced": decoration["forced"],
                    "surviving": decoration["surviving"],
                }
                for face in squares:
                    if set(face) & set(decoration["root_square"]):
                        continue
                    counts["root_disjoint_facial_square_cuts"] += 1
                    for ports in base.cyclic_orientations(face):
                        counts["oriented_cuts"] += 1
                        result = analyze_orientation_both_sectors(
                            record, face, ports
                        )
                        if result is None:
                            continue
                        counts["directed_antecedent_orientations"] += 1
                        counts["antecedent_orientations_01"] += int(
                            bool(result["antecedents_01"])
                        )
                        counts["antecedent_orientations_10"] += int(
                            bool(result["antecedents_10"])
                        )
                        counts["directed_antecedent_pairs_01"] += len(
                            result["antecedents_01"]
                        )
                        counts["directed_antecedent_pairs_10"] += len(
                            result["antecedents_10"]
                        )
                        mandatory = int(result["mandatory_count"])
                        mandatory_distribution[mandatory] += 1
                        if mandatory == 2:
                            profile = tuple(
                                (label, value)
                                for label, value in result[
                                    "counts_by_factor_pair"
                                ].items()
                                if value
                            )
                            m2_profile_distribution[profile] += 1
                        compact = compact_result(
                            order, graph6, decoration, result
                        )
                        if minimum is None or mandatory < minimum:
                            minimum = mandatory
                            minimizers = [compact]
                        elif mandatory == minimum and len(minimizers) < 8:
                            minimizers.append(compact)
                        if mandatory == 1:
                            first_m1 = compact
                            return {
                                "status": "actual_carrier_mandatory_count_one_found",
                                "scope": dict(sorted(counts.items())),
                                "mandatory_distribution_before_stop": dict(
                                    sorted(mandatory_distribution.items())
                                ),
                                "m2_profile_distribution_before_stop": {
                                    "|".join(
                                        f"{label}:{value}"
                                        for label, value in profile
                                    ): count
                                    for profile, count in sorted(
                                        m2_profile_distribution.items()
                                    )
                                },
                                "first_m1": first_m1,
                            }

    return {
        "status": "no_mandatory_count_one_in_frozen_through26_carriers",
        "scope": dict(sorted(counts.items())),
        "mandatory_distribution": dict(sorted(mandatory_distribution.items())),
        "m2_profile_distribution": {
            "|".join(f"{label}:{value}" for label, value in profile): count
            for profile, count in sorted(m2_profile_distribution.items())
        },
        "minimum": minimum,
        "minimizers": minimizers,
        "first_m1": None,
    }


def main() -> None:
    result = scan()
    print(json.dumps(result, indent=2, sort_keys=True))
    if result["first_m1"] is not None:
        print("ACTUAL_CARRIER_MANDATORY_COUNT_ONE_FOUND")
    else:
        print("NO_MANDATORY_COUNT_ONE_IN_FROZEN_THROUGH26_CARRIERS")


if __name__ == "__main__":
    main()
