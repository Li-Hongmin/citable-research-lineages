#!/usr/bin/env python3
"""Mandatory four-row joined-crossing prefilter on three frozen carriers.

Scope: the literal graphs of Notes 151, 153, and 154 and every cyclic
orientation of every already present root-disjoint facial square.  No graph
is generated.

The four abstract factor rows are

    N0 : state empty, clean complement 01|23,
    N1 : state A0,    clean complement 23,
    R1 = N0 - q1 : state A1, clean complement 03,
    R3 = N0 - q3 : state A3, clean complement 12.

Their bond atoms follow from N0--N1 = 01 and q1,q3 being the two terminal
edges of that path:

    N0--N1 = 01,  N0--R1 = 12,  N0--R3 = 03,
    N1--R1 = 02,  N1--R3 = 13,
    R1--R3 = 12|03.

For the last atom, equal carrier and factor pairings close as two cycles;
the joined difference is one cycle exactly when the carrier pairing is one
of the other two pairings of the four ports.
"""

from __future__ import annotations

from collections import Counter
from contextlib import redirect_stdout
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, combinations_with_replacement, product
from pathlib import Path
import io
import json
import sys


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[1]
BASE_PATH = (
    BARNETTE
    / "scratch"
    / "worker-arbitrary-carrier-companion-counterexample"
    / "scan_fixed_carriers.py"
)


def load_module(path: Path, name: str):
    spec = spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


base = load_module(BASE_PATH, "frozen_carrier_scan_base")


EMPTY = frozenset()
A0 = frozenset((0, 1))
A1 = frozenset((1, 2))
A3 = frozenset((0, 3))

FACTOR_ROWS = {
    "N0": (EMPTY, (frozenset((0, 1)), frozenset((2, 3)))),
    "N1": (A0, (frozenset((2, 3)),)),
    "R1": (A1, (frozenset((0, 3)),)),
    "R3": (A3, (frozenset((1, 2)),)),
}
FACTOR_PAIR_LABELS = tuple(
    f"{left}-{right}"
    for left, right in combinations_with_replacement(tuple(FACTOR_ROWS), 2)
)

ONE_PATH_FACTOR_ATOMS = {
    frozenset(("N0", "N1")): frozenset((0, 1)),
    frozenset(("N0", "R1")): frozenset((1, 2)),
    frozenset(("N0", "R3")): frozenset((0, 3)),
    frozenset(("N1", "R1")): frozenset((0, 2)),
    frozenset(("N1", "R3")): frozenset((1, 3)),
}
R1_R3_FACTOR_PAIRING = frozenset(
    (frozenset((1, 2)), frozenset((0, 3)))
)


def pair_label(left: str, right: str) -> str:
    order = tuple(FACTOR_ROWS)
    if order.index(left) <= order.index(right):
        return f"{left}-{right}"
    return f"{right}-{left}"


def joined_is_one_cycle(left_label: str, right_label: str, carrier_atom) -> bool:
    """Convolve the fixed factor atom with one carrier bond atom."""
    if carrier_atom is None:
        return False
    paths, closed = carrier_atom

    if left_label == right_label:
        # Same factor row: the whole difference is the carrier difference.
        return paths == () and closed == 1

    if closed:
        return False

    labels = frozenset((left_label, right_label))
    if labels in ONE_PATH_FACTOR_ATOMS:
        return (
            len(paths) == 1
            and frozenset(paths[0]) == ONE_PATH_FACTOR_ATOMS[labels]
        )

    assert labels == frozenset(("R1", "R3")), labels
    carrier_pairing = frozenset(frozenset(path) for path in paths)
    return (
        len(paths) == 2
        and carrier_pairing != R1_R3_FACTOR_PAIRING
    )


def analyze_orientation(record, face, ports):
    graph = record["graph"]
    cut, rows = base.carrier_rows(
        graph, record["root_square"], record["root"], record["forced"], ports
    )
    surviving = base.edge(*record["surviving"])

    compatible = {}
    for label, (state, factor_pairs) in FACTOR_ROWS.items():
        compatible[label] = tuple(
            index
            for index, (row_state, _matching, profile) in enumerate(rows)
            if row_state == state
            and base.factor_join_passes(profile, state, factor_pairs)
        )

    sector = {
        index: int(surviving in rows[index][1])
        for indices in compatible.values()
        for index in indices
    }

    slots = []
    slot_counts = Counter()
    labels = tuple(FACTOR_ROWS)
    for left_label, right_label in combinations_with_replacement(labels, 2):
        left_rows = compatible[left_label]
        right_rows = compatible[right_label]
        candidates = (
            combinations(left_rows, 2)
            if left_label == right_label
            else product(left_rows, right_rows)
        )
        for left, right in candidates:
            if sector[left] == sector[right]:
                continue
            carrier_atom = base.bond_atom(
                cut, ports, rows[left][:2], rows[right][:2]
            )
            if not joined_is_one_cycle(left_label, right_label, carrier_atom):
                continue
            label = pair_label(left_label, right_label)
            slot_counts[label] += 1
            slots.append(
                {
                    "factor_pair": label,
                    "carrier_rows": [left, right],
                    "carrier_sectors": [sector[left], sector[right]],
                    "carrier_atom": {
                        "paths": [sorted(path) for path in carrier_atom[0]],
                        "closed": carrier_atom[1],
                    },
                }
            )

    r1_r3_atoms = Counter()
    for left in compatible["R1"]:
        for right in compatible["R3"]:
            if sector[left] == sector[right]:
                continue
            paths, closed = base.bond_atom(
                cut, ports, rows[left][:2], rows[right][:2]
            )
            pairing = "|".join(
                "".join(map(str, sorted(path)))
                for path in sorted(paths, key=lambda path: tuple(sorted(path)))
            )
            r1_r3_atoms[f"{pairing}+{closed}closed"] += 1

    # A crossing antecedent only requires opposite sectors.  Globally
    # exchanging the names 0 and 1 does not change any mandatory count, so
    # both literal membership directions must be admitted here.
    antecedents = tuple(
        (left, right)
        for left in compatible["N0"]
        for right in compatible["N1"]
        if sector[left] != sector[right]
        and base.bond_atom(cut, ports, rows[left][:2], rows[right][:2])
        == ((frozenset((0, 1)),), 0)
    )
    if not antecedents:
        return None

    # Every directed antecedent must appear among the N0--N1 slots.
    assert all(
        any(
            slot["factor_pair"] == "N0-N1"
            and slot["carrier_rows"] == [left, right]
            for slot in slots
        )
        for left, right in antecedents
    )

    return {
        "name": record["name"],
        "order": len(graph),
        "face": list(face),
        "ports": list(ports),
        "cut_edges": [
            list(base.edge(ports[0], ports[1])),
            list(base.edge(ports[2], ports[3])),
        ],
        "carrier_row_count": len(rows),
        "compatible_rows": {
            label: list(indices) for label, indices in compatible.items()
        },
        "compatible_sectors": {
            label: [sector[index] for index in indices]
            for label, indices in compatible.items()
        },
        "antecedents": [list(pair) for pair in antecedents],
        "mandatory_count": len(slots),
        "counts_by_factor_pair": {
            label: slot_counts[label] for label in FACTOR_PAIR_LABELS
        },
        "r1_r3_opposite_sector_carrier_atoms": dict(sorted(r1_r3_atoms.items())),
        "slots": slots,
        "row_matchings": {
            str(index): [list(item) for item in sorted(rows[index][1], key=repr)]
            for index in sorted(set(index for values in compatible.values() for index in values))
        },
    }


def main() -> None:
    results = []
    scope = Counter()
    per_carrier = {}

    # One legacy Note 151 verifier prints its own fixed-certificate summary
    # at import time.  Suppress that unrelated output so this program emits
    # one machine-readable JSON object followed by one terminal marker.
    with redirect_stdout(io.StringIO()):
        records = base.fixed_records()

    for record in records:
        local = Counter()
        scope["graphs"] += 1
        faces = base.plane_faces(record["graph"])
        squares = tuple(face for face in faces if len(face) == 4)
        scope["facial_squares"] += len(squares)
        local["facial_squares"] += len(squares)
        for face in squares:
            if set(face) & set(record["root_square"]):
                continue
            scope["root_disjoint_facial_squares"] += 1
            local["root_disjoint_facial_squares"] += 1
            for ports in base.cyclic_orientations(face):
                scope["oriented_cuts"] += 1
                local["oriented_cuts"] += 1
                result = analyze_orientation(record, face, ports)
                if result is None:
                    continue
                results.append(result)
                scope["antecedent_orientations"] += 1
                scope["antecedent_pairs"] += len(result["antecedents"])
                local["antecedent_orientations"] += 1
                local["antecedent_pairs"] += len(result["antecedents"])
                local[f"mandatory_count_{result['mandatory_count']}"] += 1
                if result["mandatory_count"] == 1:
                    scope["one_crossing_candidates"] += 1
                    local["one_crossing_candidates"] += 1
        per_carrier[record["name"]] = dict(sorted(local.items()))

    counts = Counter(result["mandatory_count"] for result in results)
    pair_slot_totals = Counter({label: 0 for label in FACTOR_PAIR_LABELS})
    pair_orientation_counts = Counter({label: 0 for label in FACTOR_PAIR_LABELS})
    r1_r3_atom_totals = Counter()
    for result in results:
        for label, count in result["counts_by_factor_pair"].items():
            pair_slot_totals[label] += count
            pair_orientation_counts[label] += int(count > 0)
        r1_r3_atom_totals.update(result["r1_r3_opposite_sector_carrier_atoms"])
    minimum = min(counts) if counts else None
    minimizers = [result for result in results if result["mandatory_count"] == minimum]
    candidates = [result for result in results if result["mandatory_count"] == 1]

    # Cross-check the exact scope of the already frozen carrier scan.
    assert scope["graphs"] == 3
    assert scope["facial_squares"] == 27
    assert scope["root_disjoint_facial_squares"] == 19
    assert scope["oriented_cuts"] == 152
    assert scope["antecedent_orientations"] == 74
    assert scope["antecedent_pairs"] == 562

    summary = {
        "scope": dict(sorted(scope.items())),
        "per_carrier": per_carrier,
        "mandatory_count_distribution": {
            str(key): value for key, value in sorted(counts.items())
        },
        "factor_pair_slot_totals": dict(sorted(pair_slot_totals.items())),
        "factor_pair_orientation_counts": dict(
            sorted(pair_orientation_counts.items())
        ),
        "r1_r3_opposite_sector_carrier_atom_totals": dict(
            sorted(r1_r3_atom_totals.items())
        ),
        "minimum_mandatory_count": minimum,
        "minimum_orientations": [
            {
                "name": result["name"],
                "ports": result["ports"],
                "cut_edges": result["cut_edges"],
                "count": result["mandatory_count"],
                "counts_by_factor_pair": result["counts_by_factor_pair"],
                "compatible_rows": result["compatible_rows"],
                "compatible_sectors": result["compatible_sectors"],
                "antecedents": result["antecedents"],
                "slots": result["slots"],
            }
            for result in minimizers
        ],
        "orientation_counts": [
            {
                "name": result["name"],
                "ports": result["ports"],
                "count": result["mandatory_count"],
                "counts_by_factor_pair": result["counts_by_factor_pair"],
            }
            for result in results
        ],
        "one_crossing_candidates": candidates,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))
    if candidates:
        print("MANDATORY_FOUR_ROW_ONE_CROSSING_CANDIDATE_FOUND")
    else:
        print("MANDATORY_FOUR_ROW_PREFILTER_EXCLUDES_ALL_FROZEN_CUTS")


if __name__ == "__main__":
    main()
