#!/usr/bin/env python3
"""Verify the six-trace parity escape at the Note 160 carrier.

This is an exploratory certificate.  It performs no graph search.  The
only graph is the fixed order-16 carrier from Note 160; after smoothing its
root square, all Hamilton cycles of the resulting order-12 cubic graph are
enumerated exactly.
"""

from __future__ import annotations

from collections import Counter
from functools import lru_cache
from itertools import combinations, product

import networkx as nx


GRAPH6 = "O????B_sDOI_I_DO@W?M?"
ROOT_SQUARE = (8, 2, 10, 0)
CUT_SQUARE = (5, 13, 7, 15)


def edge(left: int, right: int) -> tuple[int, int]:
    return tuple(sorted((left, right)))


ROOT = edge(2, 8)
FORCED = edge(0, 10)
SURVIVING = edge(7, 13)


def perfect_matchings(graph: nx.Graph):
    vertices = tuple(sorted(graph))
    position = {vertex: index for index, vertex in enumerate(vertices)}
    neighbours = [0] * len(vertices)
    for left, right in graph.edges():
        neighbours[position[left]] |= 1 << position[right]
        neighbours[position[right]] |= 1 << position[left]

    @lru_cache(maxsize=None)
    def solve(mask: int):
        if not mask:
            return ((),)
        candidates = [index for index in range(len(vertices)) if mask >> index & 1]
        first = min(
            candidates,
            key=lambda index: ((neighbours[index] & mask).bit_count(), index),
        )
        rows = []
        choices = neighbours[first] & mask
        remainder = mask ^ (1 << first)
        while choices:
            bit = choices & -choices
            choices ^= bit
            second = bit.bit_length() - 1
            for suffix in solve(remainder ^ bit):
                rows.append(((first, second),) + suffix)
        return tuple(rows)

    return tuple(
        frozenset(edge(vertices[left], vertices[right]) for left, right in row)
        for row in solve((1 << len(vertices)) - 1)
    )


def trace_name(cycle: frozenset[tuple[int, int]], square_edges):
    trace = frozenset(index for index, item in enumerate(square_edges) if item in cycle)
    names = {
        frozenset((1, 2, 3)): "U0",
        frozenset((0, 2, 3)): "U1",
        frozenset((0, 1, 3)): "U2",
        frozenset((0, 1, 2)): "U3",
        frozenset((0, 2)): "O02",
        frozenset((1, 3)): "O13",
    }
    assert trace in names
    return names[trace]


def is_hamilton_cycle(graph: nx.Graph, edges) -> bool:
    cycle = nx.edge_subgraph(graph, edges)
    return (
        len(edges) == len(graph)
        and len(cycle) == len(graph)
        and nx.is_connected(cycle)
        and set(dict(cycle.degree()).values()) == {2}
    )


def mod2_dot(left, right):
    return sum(a * b for a, b in zip(left, right)) % 2


def main() -> None:
    # First determine the complete local Smith--Thomason trace kernel.
    classes = ("U0", "U1", "U2", "U3", "O02", "O13")
    local_incidence = {
        "q0": (0, 1, 1, 1, 1, 0),
        "q1": (1, 0, 1, 1, 0, 1),
        "q2": (1, 1, 0, 1, 1, 0),
        "q3": (1, 1, 1, 0, 0, 1),
        "r0": (1, 0, 0, 1, 1, 1),
        "r1": (1, 1, 0, 0, 1, 1),
        "r2": (0, 1, 1, 0, 1, 1),
        "r3": (0, 0, 1, 1, 1, 1),
    }
    kernel = {
        vector
        for vector in product((0, 1), repeat=6)
        if all(mod2_dot(row, vector) == 0 for row in local_incidence.values())
    }
    first = (1, 0, 1, 0, 1, 0)
    second = (0, 1, 0, 1, 0, 1)
    assert kernel == {
        (0, 0, 0, 0, 0, 0),
        first,
        second,
        tuple(a ^ b for a, b in zip(first, second)),
    }
    # If the designated U0 and O02 traces are both odd, U2 is forced odd;
    # the unique minimum completion is the omitted A2 trace, not U1 or U3.
    assert [classes[index] for index, bit in enumerate(first) if bit] == [
        "U0",
        "U2",
        "O02",
    ]
    mandatory = {
        "s_Z": 0,
        "s_0": 0,
        "s_1": 0,
        "s_3": 0,
        "p_Z0": 1,
        "p_Z1": 0,
        "p_Z3": 0,
        "p_01": 0,
        "p_03": 0,
        "t_13": 0,
    }
    # The trace equations contain no mandatory pair coordinate.  Hence the
    # minimum parity vector and the exact hypothetical M=1 assignment are a
    # consistent abstract cap-state system.
    assert sum(mandatory.values()) == 1 and mandatory["p_Z0"] == 1

    # Refine the six traces by the two root-cap incidences a,d.  Requiring
    # even incidence also at a and d still does not help: the unique
    # minimum boundary-state completion of rooted U0 and rooted O02 is a
    # U2 cycle which misses both cap edges.
    states = tuple(
        (trace, cap_a, cap_d)
        for trace in classes
        for cap_a in (0, 1)
        for cap_d in (0, 1)
    )
    designated_states = (("U0", 1, 1), ("O02", 1, 1))

    def cap_state_even(selected):
        for incidence in local_incidence.values():
            if sum(incidence[classes.index(trace)] for trace, _a, _d in selected) % 2:
                return False
        return (
            sum(cap_a for _trace, cap_a, _cap_d in selected) % 2 == 0
            and sum(cap_d for _trace, _cap_a, cap_d in selected) % 2 == 0
        )

    remaining_states = tuple(item for item in states if item not in designated_states)
    minimum_completions = []
    for size in range(5):
        minimum_completions = [
            completion
            for completion in combinations(remaining_states, size)
            if cap_state_even(designated_states + completion)
        ]
        if minimum_completions:
            break
    assert size == 1
    assert minimum_completions == [(('U2', 0, 0),)]

    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert len(graph) == 16 and graph.number_of_edges() == 24
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.check_planarity(graph)[0]

    root_vertices = set(ROOT_SQUARE)
    attachments = []
    for vertex in ROOT_SQUARE:
        outside = [neighbour for neighbour in graph[vertex] if neighbour not in root_vertices]
        assert len(outside) == 1
        attachments.append(outside[0])
    assert tuple(attachments) == (1, 12, 4, 9)

    # Double-smooth the two opposite matching edges of the root square.
    # A Hamilton cycle is root-admitted exactly when it contains both new
    # smoothing edges.
    smooth_a = edge(attachments[0], attachments[1])
    smooth_d = edge(attachments[2], attachments[3])
    smoothed = graph.copy()
    smoothed.remove_nodes_from(ROOT_SQUARE)
    smoothed.add_edges_from((smooth_a, smooth_d))
    assert len(smoothed) == 12 and set(dict(smoothed.degree()).values()) == {3}

    all_edges = frozenset(edge(*item) for item in smoothed.edges())
    square_edges = tuple(
        edge(CUT_SQUARE[index], CUT_SQUARE[(index + 1) % 4])
        for index in range(4)
    )
    cycles = []
    for matching in perfect_matchings(smoothed):
        cycle = all_edges - matching
        if is_hamilton_cycle(smoothed, cycle):
            cycles.append(
                (
                    trace_name(cycle, square_edges),
                    smooth_a in cycle,
                    smooth_d in cycle,
                    SURVIVING not in cycle,
                    cycle,
                )
            )

    assert len(cycles) == 8
    assert Counter(item[0] for item in cycles) == Counter(
        {"U0": 1, "U1": 1, "U2": 1, "U3": 1, "O02": 1, "O13": 3}
    )
    assert Counter((item[1], item[2]) for item in cycles) == Counter(
        {(True, True): 5, (True, False): 1, (False, True): 1, (False, False): 1}
    )

    admitted = [item for item in cycles if item[1] and item[2]]
    assert Counter(item[0] for item in admitted) == Counter(
        {"U0": 1, "O02": 1, "U2": 1, "O13": 2}
    )
    rejected = [item for item in cycles if not (item[1] and item[2])]
    assert Counter(item[0] for item in rejected) == Counter(
        {"U1": 1, "U3": 1, "O13": 1}
    )

    # Inverting the five admitted cycles gives the carrier boundary states
    # A0, Z, A2, Omega, Omega.  Thus every admitted companion outside the
    # designated U0/O02 pair lies in a state omitted by the ten slots.
    state_from_trace = {
        "U0": "A0",
        "U2": "A2",
        "O02": "Z",
        "O13": "Omega",
    }
    assert Counter(state_from_trace[item[0]] for item in admitted) == Counter(
        {"A0": 1, "Z": 1, "A2": 1, "Omega": 2}
    )

    def smoothed_cycle_from_original_matching(full_matching):
        original_complement = (
            frozenset(edge(*item) for item in graph.edges()) - full_matching
        )
        return frozenset(
            item for item in original_complement if not (set(item) & root_vertices)
        ) | {smooth_a, smooth_d}

    k2 = frozenset(
        edge(*item)
        for item in (
            (0, 10), (1, 9), (3, 11), (4, 12),
            (7, 13), (6, 14), (5, 15), (2, 8),
        )
    )
    k10_boundary = frozenset(
        edge(*item)
        for item in (
            (0, 10), (1, 9), (3, 11), (4, 12),
            (7, 14), (6, 15), (2, 8),
        )
    )
    q0 = square_edges[0]
    designated = {
        "O02": smoothed_cycle_from_original_matching(k2),
        "U0": smoothed_cycle_from_original_matching(k10_boundary | {q0}),
    }
    for name, cycle in designated.items():
        records = [item for item in cycles if item[4] == cycle]
        assert len(records) == 1
        record = records[0]
        assert record[0] == name and record[1] and record[2]
    assert next(item for item in cycles if item[4] == designated["O02"])[3] == 1
    assert next(item for item in cycles if item[4] == designated["U0"])[3] == 0

    # The actual second mandatory row K20 is an A3 repair, but its natural
    # square closure is not Hamiltonian after root smoothing.  Hence this
    # parity closure literally does not see the repair that makes M=2.
    k20 = frozenset(
        edge(*item)
        for item in (
            (0, 10), (1, 9), (3, 11), (6, 12),
            (7, 13), (4, 14), (2, 8),
        )
    )
    q3 = square_edges[3]
    full_matching = k20 | {q3}
    assert len(full_matching) == 8
    smoothed_complement = smoothed_cycle_from_original_matching(full_matching)
    components = sorted(
        len(vertices)
        for vertices in nx.connected_components(
            nx.edge_subgraph(smoothed, smoothed_complement)
        )
    )
    assert components == [4, 8]

    print("six_trace_kernel=span(U0+U2+O02,U1+U3+O13)")
    print("minimum_designated_completion=U0+U2+O02")
    print("minimum_full_boundary_cap_completion=(U0,11)+(O02,11)+(U2,00)")
    print("abstract_mandatory_profile=p_Z0:1,other_nine:0")
    print("order12_all_hamilton_trace_counts=U0:1,U1:1,U2:1,U3:1,O02:1,O13:3")
    print("root_admitted_states=A0:1,Z:1,A2:1,Omega:2")
    print("nonrooted_escape_traces=U1:1,U3:1,O13:1")
    print("actual_A3_compensation_K20_smoothed_components=4+8")
    print("SIX_TRACE_CAP_ESCAPE_VERIFIED")


if __name__ == "__main__":
    main()
