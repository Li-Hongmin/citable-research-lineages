#!/usr/bin/env python3
"""Verify the two literal one-cycle repair profiles.

Only two already frozen carrier orientations are reconstructed:

* the order-16 sharp M=2 carrier;
* the Note 154 order-22 M=3 orientation.

No graph is generated and no corpus is scanned.
"""

from __future__ import annotations

from contextlib import redirect_stdout
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import io
import sys

import networkx as nx


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[1]


def load_module(path: Path, name: str):
    spec = spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    sys.modules[name] = module
    with redirect_stdout(io.StringIO()):
        spec.loader.exec_module(module)
    return module


near = load_module(
    BARNETTE
    / "scratch"
    / "worker-carrier-prefilter-counterexample"
    / "verify_near_actual_m1_countermodel.py",
    "one_cycle_repair_order16_base",
)
scan = near.scan
prefilter = scan.prefilter
edge = scan.edge


def orientation_data(record, ports):
    graph = record["graph"]
    cut, rows = scan.carrier_rows_cached(
        graph,
        record["root_square"],
        record["root"],
        record["forced"],
        ports,
    )
    result = scan.analyze_orientation_both_sectors(record, ports, ports)
    assert result is not None
    compatible = {
        label: set(indices)
        for label, indices in result["compatible_rows"].items()
    }
    surviving = edge(*record["surviving"])
    sector = lambda index: int(surviving in rows[index][1])
    lookup = {
        (state, matching): index
        for index, (state, matching, _profile) in enumerate(rows)
    }
    atom = lambda left, right: scan.bond_atom_cached(
        graph, cut, ports, rows[left][:2], rows[right][:2]
    )
    return rows, result, compatible, sector, lookup, atom


def verify_order16():
    graph = nx.from_graph6_bytes(near.GRAPH6.encode())
    record = {
        "name": "order16-one-cycle-repair",
        "graph": graph,
        "root_square": near.ROOT_SQUARE,
        "root": near.ROOT,
        "forced": near.FORCED,
        "surviving": near.SURVIVING,
    }
    ports = near.PORTS
    rows, result, compatible, sector, lookup, atom = orientation_data(
        record, ports
    )
    assert result["mandatory_count"] == 2

    designated_z, designated_a0 = 2, 10
    q3 = edge(ports[3], ports[0])
    deletion = lookup[
        (prefilter.A3, rows[designated_z][1] - frozenset((q3,)))
    ]
    repair = 20

    assert deletion == 19
    assert deletion not in compatible["R3"]
    assert repair in compatible["R3"]
    assert sector(deletion) == sector(repair) == 1
    assert atom(deletion, repair) == ((), 1)
    assert rows[deletion][1] ^ rows[repair][1] == frozenset(
        (
            edge(4, 12),
            edge(12, 6),
            edge(6, 14),
            edge(14, 4),
        )
    )

    required = ((frozenset((1, 3)),), 0)
    assert atom(designated_a0, deletion) == required
    assert atom(designated_a0, repair) == required
    return {
        "deletion": deletion,
        "repair": repair,
        "anchor": designated_a0,
        "mode": "zero-closed atom preserved",
    }


def verify_note154():
    with redirect_stdout(io.StringIO()):
        records = prefilter.base.fixed_records()
    record = next(
        item for item in records if item["name"] == "Note154-order22"
    )
    ports = (19, 10, 21, 9)
    rows, result, compatible, sector, lookup, atom = orientation_data(
        record, ports
    )
    assert result["mandatory_count"] == 3

    designated_z = 14
    q1 = edge(ports[1], ports[2])
    deletion = lookup[
        (prefilter.A1, rows[designated_z][1] - frozenset((q1,)))
    ]
    assert deletion == 37
    assert deletion not in compatible["R1"]

    cases = (
        (
            31,
            0,
            frozenset(
                (
                    edge(0, 11),
                    edge(11, 1),
                    edge(1, 12),
                    edge(12, 0),
                )
            ),
        ),
        (
            41,
            18,
            frozenset(
                (
                    edge(1, 11),
                    edge(11, 2),
                    edge(2, 14),
                    edge(14, 1),
                )
            ),
        ),
    )
    before = ((frozenset((1, 2)),), 1)
    after = ((frozenset((1, 2)),), 0)
    for repair, anchor, cycle in cases:
        assert repair in compatible["R1"]
        assert sector(deletion) == sector(repair) == 0
        assert atom(deletion, repair) == ((), 1)
        assert rows[deletion][1] ^ rows[repair][1] == cycle
        assert atom(anchor, deletion) == before
        assert atom(anchor, repair) == after
        assert cycle <= (rows[anchor][1] ^ rows[deletion][1])

    return {
        "deletion": deletion,
        "repairs": [31, 41],
        "anchors": [0, 18],
        "mode": "path pairing preserved, unique closed component cancelled",
    }


def main() -> None:
    print("order16", verify_order16())
    print("note154", verify_note154())
    print("ONE_CYCLE_REPAIR_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
