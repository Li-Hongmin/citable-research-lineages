#!/usr/bin/env python3
"""Decide forced-two-gate target-component saturation at reduced order 22.

This is a single-order, streaming continuation of the accepted through-20
target-component census.  For each nonempty reduced rooted target family, the
target-state graph joins two targets exactly when their perfect matchings
differ on one alternating cycle.  Only components on which both chosen gate
edges occur in every target are sent to the lift test.  Within such a
component, targets and the eight local assignments are tried in deterministic
order until the first target lift is found.

The generator stream is stopped immediately if a forced-gate component has no
liftable target.  In that event the returned JSON contains the explicit
reduced and expanded graphs, split site, component, every target in the
component, and all eight assignment profiles for each target.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations, product
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
from typing import Iterable, Iterator

import networkx as nx


ORDER = 22
EXPECTED_RAW_COUNT = 4132

Edge = tuple[int, int]
Matching = frozenset[Edge]

sys.dont_write_bytecode = True
UNIT_DIR = Path(__file__).resolve().parents[3]
SOURCE_BUNDLE = (
    UNIT_DIR
    / "computations"
    / "bundles"
    / "planar-two-path-through18"
    / "census_planar_brace_two_paths_through18.py"
)
LIFT_BUNDLE = (
    UNIT_DIR
    / "computations"
    / "bundles"
    / "locked-boundary-escape-through18"
    / "census_locked_escape_through18.py"
)


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


source_bundle = load_module(SOURCE_BUNDLE, "order22_target_component_source")
lift_bundle = load_module(LIFT_BUNDLE, "order22_target_component_lift")


def edge(first: int, second: int) -> Edge:
    return (first, second) if first < second else (second, first)


def graph6(graph: nx.Graph) -> str:
    return nx.to_graph6_bytes(graph, header=False).decode().strip()


def generated_graphs() -> Iterator[tuple[str, nx.Graph]]:
    process = subprocess.Popen(
        ("geng", "-cqb", "-d3", "-D3", str(ORDER)),
        stdout=subprocess.PIPE,
        text=True,
    )
    assert process.stdout is not None
    completed = False
    try:
        for line in process.stdout:
            source_graph6 = line.strip()
            if source_graph6:
                yield source_graph6, nx.from_graph6_bytes(source_graph6.encode())
        assert process.wait() == 0
        completed = True
    finally:
        if not completed and process.poll() is None:
            process.terminate()
            process.wait()


def primal_edge_by_dual_edge(
    primal: nx.Graph, primal_faces: Iterable[Iterable[int]]
) -> dict[Edge, Edge]:
    incident: dict[Edge, list[int]] = defaultdict(list)
    for face_index, face_raw in enumerate(primal_faces):
        face = tuple(face_raw)
        for index, first in enumerate(face):
            second = face[(index + 1) % len(face)]
            incident[edge(first, second)].append(face_index)
    assert set(incident) == {edge(*item) for item in primal.edges()}
    assert all(len(pair) == 2 for pair in incident.values())
    result = {edge(*pair): primal_edge for primal_edge, pair in incident.items()}
    assert len(result) == primal.number_of_edges()
    return result


def matching_from_colour(
    primal: nx.Graph,
    reduced: nx.Graph,
    dual_to_primal: dict[Edge, Edge],
    colour: dict[int, int],
) -> Matching:
    matching = frozenset(
        dual_to_primal[edge(first, second)]
        for first, second in reduced.edges()
        if colour[first] == colour[second]
    )
    assert len(matching) * 2 == primal.number_of_nodes()
    degrees = Counter(vertex for item in matching for vertex in item)
    assert set(degrees) == set(primal) and set(degrees.values()) == {1}
    return matching


def matching_diff_component_count(first: Matching, second: Matching) -> int:
    difference = first ^ second
    if not difference:
        return 0
    graph = nx.Graph()
    graph.add_edges_from(difference)
    assert set(dict(graph.degree()).values()) == {2}
    return nx.number_connected_components(graph)


def target_graph(matchings: tuple[Matching, ...]) -> nx.Graph:
    graph = nx.Graph()
    graph.add_nodes_from(range(len(matchings)))
    for first, second in combinations(range(len(matchings)), 2):
        if matching_diff_component_count(matchings[first], matchings[second]) == 1:
            graph.add_edge(first, second)
    return graph


def profile_record(
    bits: tuple[int, int, int],
    normalized_bits: tuple[int, int, int],
    profile: tuple[bool, int | None, int | None, bool],
) -> dict[str, object]:
    return {
        "bits_left_right_centre": bits,
        "normalized_bits": normalized_bits,
        "nae": profile[0],
        "components": profile[1],
        "cycle_rank": profile[2],
        "root_on_cycle": profile[3],
        "target": lift_bundle.is_target_profile(profile),
    }


def freeze_failure(
    source_graph6: str,
    primal: nx.Graph,
    primal_faces: tuple[tuple[int, ...], ...],
    reduced: nx.Graph,
    reduced_faces: tuple[tuple[int, ...], ...],
    expanded: nx.Graph,
    expanded_faces: tuple[tuple[int, ...], ...],
    z: int,
    rotation: tuple[int, ...],
    gate_indices: tuple[int, int],
    gate_vertices: tuple[int, int],
    gate_edges: tuple[Edge, Edge],
    arcs: tuple[tuple[int, ...], tuple[int, ...]],
    locals_: tuple[int, int, int],
    root: Edge,
    primal_root: Edge,
    colours: tuple[dict[int, int], ...],
    matchings: tuple[Matching, ...],
    adjacency: nx.Graph,
    component: set[int],
) -> dict[str, object]:
    """Freeze and recheck every finite datum needed for a true failure."""

    expanded_dual = lift_bundle.dual_from_plane_graph(expanded, expanded_faces)
    reduced_brace_check = lift_bundle.verify_brace(primal)
    expanded_brace_check = lift_bundle.verify_brace(expanded_dual)
    targets: list[dict[str, object]] = []

    for index in sorted(component):
        colour = colours[index]
        matching = matchings[index]
        assert set(gate_edges) <= set(matching)
        fixed = {vertex: value for vertex, value in colour.items() if vertex != z}
        assignments = []
        for bits in product((0, 1), repeat=3):
            lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
            profile = lift_bundle.rooted_profile(
                expanded, expanded_faces, lifted, root
            )
            normalized = tuple(bit ^ colour[z] for bit in bits)
            assignments.append(profile_record(bits, normalized, profile))
        assert not any(record["target"] for record in assignments)
        reduced_profile = lift_bundle.rooted_profile(
            reduced, reduced_faces, colour, root
        )
        assert lift_bundle.is_target_profile(reduced_profile)
        targets.append(
            {
                "family_index": index,
                "zero_vertices": sorted(
                    vertex for vertex, value in colour.items() if value == 0
                ),
                "one_vertices": sorted(
                    vertex for vertex, value in colour.items() if value == 1
                ),
                "reduced_rooted_profile": {
                    "nae": reduced_profile[0],
                    "components": reduced_profile[1],
                    "cycle_rank": reduced_profile[2],
                    "root_on_cycle": reduced_profile[3],
                },
                "matching": sorted(matching),
                "gate_count": sum(gate in matching for gate in gate_edges),
                "target_graph_neighbours": sorted(adjacency[index]),
                "all_eight_assignments": assignments,
            }
        )

    assert nx.is_connected(adjacency.subgraph(component))
    assert not any(
        neighbour not in component
        for index in component
        for neighbour in adjacency[index]
    )

    return {
        "failure_kind": "forced_two_gate_target_component_without_liftable_target",
        "source_order": ORDER,
        "source_graph6": source_graph6,
        "source_primal_edges": sorted(edge(*item) for item in primal.edges()),
        "source_primal_faces": primal_faces,
        "reduced_triangulation_graph6": graph6(reduced),
        "reduced_triangulation_edges": sorted(
            edge(*item) for item in reduced.edges()
        ),
        "expanded_triangulation_graph6": graph6(expanded),
        "expanded_triangulation_edges": sorted(
            edge(*item) for item in expanded.edges()
        ),
        "expanded_triangulation_faces": expanded_faces,
        "expanded_dual_graph6": graph6(expanded_dual),
        "expanded_dual_edges": sorted(edge(*item) for item in expanded_dual.edges()),
        "reduced_dual_brace_check": reduced_brace_check,
        "expanded_dual_brace_check": expanded_brace_check,
        "site": {
            "split_vertex": z,
            "rotation": rotation,
            "gate_indices": gate_indices,
            "gate_vertices": gate_vertices,
            "primal_gate_edges": gate_edges,
            "left_arc": arcs[0],
            "right_arc": arcs[1],
            "left_right_centre": locals_,
        },
        "dual_root": root,
        "primal_root": primal_root,
        "complete_target_family_size_mod_complement": len(matchings),
        "failed_component_family_indices": sorted(component),
        "failed_component_size": len(component),
        "failed_component_targets": targets,
        "standalone_verifier": "verify_order22_component_failure.py",
    }


def analyse_brace(
    source_graph6: str,
    primal: nx.Graph,
    primal_faces: tuple[tuple[int, ...], ...],
) -> tuple[dict[str, object], dict[str, object] | None]:
    reduced, rotations = lift_bundle.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift_bundle.verify_reduced_triangulation(reduced)
    families, nae_count, target_shape_count = lift_bundle.target_families(
        reduced, reduced_faces
    )
    reduced_vertices = tuple(sorted(reduced))
    dual_to_primal = primal_edge_by_dual_edge(primal, primal_faces)

    family_cache: dict[
        Edge,
        tuple[
            tuple[dict[int, int], ...],
            tuple[Matching, ...],
            nx.Graph,
        ],
    ] = {}
    for root, encoded_family in families.items():
        colours = tuple(
            lift_bundle.decode_colouring(reduced_vertices, encoded)
            for encoded in encoded_family
        )
        matchings = tuple(
            matching_from_colour(primal, reduced, dual_to_primal, colour)
            for colour in colours
        )
        assert len(matchings) == len(set(matchings))
        primal_root = dual_to_primal[root]
        assert all(primal_root in matching for matching in matchings)
        family_cache[root] = colours, matchings, target_graph(matchings)

    counts: Counter = Counter(
        {
            "colour_classes_mod_complement": 1 << (len(reduced_vertices) - 1),
            "nae_colourings_mod_complement": nae_count,
            "target_shape_colourings_mod_complement": target_shape_count,
            "root_target_pairs_mod_complement": sum(map(len, families.values())),
            "forced_two_gate_component_failures": 0,
        }
    )

    for z in sorted(reduced):
        rotation = rotations[z]
        for first_index, second_index, first_gate, second_gate in lift_bundle.gate_pairs(
            rotation
        ):
            counts["nonconsecutive_gate_pairs"] += 1
            left_size = second_index - first_index + 1
            right_size = len(rotation) - (second_index - first_index) + 1
            if left_size % 2 == 0 or right_size % 2 == 0:
                continue
            counts["odd_arc_gate_pairs"] += 1

            expanded, locals_, left_arc, right_arc = lift_bundle.split_vertex(
                reduced, z, rotation, first_index, second_index
            )
            if nx.number_of_selfloops(expanded):
                continue
            if any(degree % 2 for _, degree in expanded.degree()):
                continue
            planar, _embedding = nx.check_planarity(expanded)
            if not planar:
                continue
            pre_faces = lift_bundle.plane_faces(expanded)
            if any(len(face) != 3 for face in pre_faces):
                continue
            counts["simple_eulerian_plane_triangulation_splits"] += 1

            expanded_faces = lift_bundle.expanded_triangulation_faces(expanded)
            if expanded_faces is None:
                continue
            counts["admissible_4connected_splits"] += 1

            gate_edges = (
                dual_to_primal[edge(z, first_gate)],
                dual_to_primal[edge(z, second_gate)],
            )
            assert gate_edges[0] != gate_edges[1]

            surviving_roots = tuple(
                root for root in sorted(families) if z not in root
            )
            counts["target_interfaces"] += len(surviving_roots)

            for root in surviving_roots:
                colours, matchings, adjacency = family_cache[root]
                primal_root = dual_to_primal[root]
                gate_counts = tuple(
                    sum(gate in matching for gate in gate_edges)
                    for matching in matchings
                )
                components = tuple(
                    set(component) for component in nx.connected_components(adjacency)
                )
                counts["target_instances"] += len(matchings)
                counts["assignment_slots_all_target_instances"] += 8 * len(matchings)
                counts["target_state_components"] += len(components)

                for component in components:
                    if not all(gate_counts[index] == 2 for index in component):
                        counts["components_not_forcing_both_gates"] += 1
                        continue

                    counts["forced_two_gate_components"] += 1
                    counts["forced_two_gate_component_targets"] += len(component)
                    counts["assignment_slots_forced_component_targets"] += (
                        8 * len(component)
                    )
                    found_lift = False
                    for index in sorted(component):
                        counts["targets_examined_for_forced_component_witness"] += 1
                        colour = colours[index]
                        fixed = {
                            vertex: value
                            for vertex, value in colour.items()
                            if vertex != z
                        }
                        for bits in product((0, 1), repeat=3):
                            counts["assignments_evaluated_for_forced_components"] += 1
                            lifted = {
                                **fixed,
                                **dict(zip(locals_, bits, strict=True)),
                            }
                            profile = lift_bundle.rooted_profile(
                                expanded, expanded_faces, lifted, root
                            )
                            if lift_bundle.is_target_profile(profile):
                                found_lift = True
                                break
                        if found_lift:
                            break

                    if found_lift:
                        counts["forced_two_gate_components_with_lift"] += 1
                        continue

                    counts["forced_two_gate_component_failures"] += 1
                    failure = freeze_failure(
                        source_graph6,
                        primal,
                        primal_faces,
                        reduced,
                        reduced_faces,
                        expanded,
                        expanded_faces,
                        z,
                        rotation,
                        (first_index, second_index),
                        (first_gate, second_gate),
                        gate_edges,
                        (left_arc, right_arc),
                        locals_,
                        root,
                        primal_root,
                        colours,
                        matchings,
                        adjacency,
                        component,
                    )
                    return {
                        "source_order": ORDER,
                        "source_graph6": source_graph6,
                        "dual_vertices": reduced.number_of_nodes(),
                        **dict(sorted(counts.items())),
                    }, failure

    assert counts["forced_two_gate_components"] == counts[
        "forced_two_gate_components_with_lift"
    ]
    return {
        "source_order": ORDER,
        "source_graph6": source_graph6,
        "dual_vertices": reduced.number_of_nodes(),
        **dict(sorted(counts.items())),
    }, None


def add_counts(totals: Counter, record: dict[str, object]) -> None:
    excluded = {"source_order", "source_graph6", "dual_vertices"}
    for key, value in record.items():
        if key in excluded:
            continue
        assert isinstance(value, int)
        totals[key] += value


def census() -> dict[str, object]:
    source_counts: Counter = Counter()
    totals: Counter = Counter()
    brace_records: list[dict[str, object]] = []
    first_failure = None

    stream = generated_graphs()
    try:
        for source_graph6, primal in stream:
            source_counts["generated_connected_simple_cubic_bipartite"] += 1
            assert primal.number_of_nodes() == ORDER
            assert nx.number_of_selfloops(primal) == 0
            assert nx.is_connected(primal) and nx.is_bipartite(primal)
            assert set(dict(primal.degree()).values()) == {3}

            planar, embedding = nx.check_planarity(primal, counterexample=True)
            if not planar:
                continue
            source_counts["planar"] += 1
            assert isinstance(embedding, nx.PlanarEmbedding)
            primal_faces = source_bundle.plane_faces(primal, embedding)
            if nx.node_connectivity(primal) >= 3:
                source_counts["planar_three_connected"] += 1

            direct = source_bundle.is_two_extendable_direct(primal)
            strict_hall = source_bundle.strict_hall_two_extendable(primal)
            assert direct == strict_hall
            if not direct:
                continue
            source_counts["plane_braces"] += 1

            record, failure = analyse_brace(
                source_graph6, primal, primal_faces
            )
            brace_records.append(record)
            add_counts(totals, record)
            print(json.dumps(record, sort_keys=True), flush=True)
            if failure is not None:
                first_failure = failure
                break
    finally:
        stream.close()

    complete_source_coverage = first_failure is None
    if complete_source_coverage:
        assert source_counts[
            "generated_connected_simple_cubic_bipartite"
        ] == EXPECTED_RAW_COUNT
        assert totals["forced_two_gate_components"] == totals[
            "forced_two_gate_components_with_lift"
        ]
        status = "exact_finite_theorem_at_reduced_order_22"
        statement = (
            "For every order-22 simple plane cubic bipartite brace F', every "
            "legal two-gate C4 expansion, every unchanged root e outside the "
            "split face with nonempty target family, and every connected "
            "component Gamma of the exact target-state graph: if both gate "
            "edges belong to every target in Gamma, then Gamma contains a "
            "target that lifts through the fixed expansion."
        )
        unresolved = "Reduced brace order 24 and above; no arbitrary-order proof."
    else:
        status = "counterexample_at_reduced_order_22"
        statement = (
            "The explicit first_failure is an order-22 forced-two-gate "
            "target-state component with no liftable target."
        )
        unresolved = (
            "The universal component-saturation statement is false; later "
            "order-22 inputs and larger orders were not searched after the "
            "mandated first failure."
        )

    return {
        "status": status,
        "statement": statement,
        "trusted_coverage_boundary": {
            "order": ORDER,
            "generator_command": "geng -cqb -d3 -D3 22",
            "expected_isomorphism_representatives": EXPECTED_RAW_COUNT,
            "geng_path": shutil.which("geng"),
            "networkx_version": nx.__version__,
            "external_interfaces": [
                "nauty geng isomorph-free completeness",
                "NetworkX exact planarity decisions",
            ],
            "direct_checks_after_planarity": [
                "independent-two-edge extension",
                "strict-Hall brace criterion",
                "complete reduced target-family enumeration modulo global colour complement",
                "exact one-alternating-cycle target-state adjacency",
                "all local rows needed to find a lift in each forced-two-gate component",
            ],
            "complete_source_coverage": complete_source_coverage,
        },
        "source_counts": dict(sorted(source_counts.items())),
        "coverage": dict(sorted(totals.items())),
        "brace_graph6": [record["source_graph6"] for record in brace_records],
        "by_brace": brace_records,
        "first_failure": first_failure,
        "unresolved_boundary": unresolved,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    payload = census()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
        print("certificate", arguments.output)
    print(json.dumps(payload["source_counts"], sort_keys=True))
    print(json.dumps(payload["coverage"], sort_keys=True))
    if payload["first_failure"] is None:
        print("FORCED_TARGET_COMPONENT_SATURATION_VERIFIED_AT_REDUCED_ORDER_22")
    else:
        print("FORCED_TARGET_COMPONENT_COUNTEREXAMPLE_VERIFIED_AT_REDUCED_ORDER_22")


if __name__ == "__main__":
    main()
