#!/usr/bin/env python3
"""Classify individual-gate escape in existing frozen Barnette brace corpora.

No graph generator is invoked.  Orders through 26 are reconstructed only from
the graph6 representatives already frozen in permanent computation bundles.
The scan stops at the first complete rooted-target family at a legal wide split
that forces either one of its two gates.
"""

from __future__ import annotations

from collections import Counter
import argparse
import importlib.util
import json
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BARNETTE = HERE.parents[2]
BUNDLES = BARNETTE / "computations" / "bundles"
ORDER26_SCRIPT = (
    BUNDLES
    / "wide-gate-escape-order26"
    / "search_wide_forced_family_order26.py"
)

sys.dont_write_bytecode = True


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


wide = load_module(ORDER26_SCRIPT, "single_gate_existing_wide_base")
lift = wide.lift_bundle
source = wide.source_bundle
edge = wide.edge


def read_json(relative: str) -> dict[str, object]:
    with (BUNDLES / relative).open() as handle:
        value = json.load(handle)
    assert isinstance(value, dict)
    return value


def frozen_graphs() -> dict[int, tuple[str, ...]]:
    through18 = read_json(
        "locked-boundary-escape-through18/locked_escape_census.json"
    )
    order20 = read_json(
        "locked-boundary-escape-order20/c4_lifting_order20_census.json"
    )
    order22 = read_json(
        "target-component-saturation-order22/forced_target_components_order22.json"
    )
    order24 = read_json(
        "existence-lifting-order24/complete_family_existence_order24.json"
    )
    order26 = read_json(
        "wide-gate-escape-order26/wide_forced_family_order26.json"
    )

    result: dict[int, list[str]] = {}
    records18 = through18["by_source_graph"]
    assert isinstance(records18, list)
    for record in records18:
        assert isinstance(record, dict)
        order = int(record["source_order"])
        result.setdefault(order, []).append(str(record["source_graph6"]))
    for order, payload, key in (
        (20, order20, "brace_graph6"),
        (22, order22, "brace_graph6"),
        (24, order24, "brace_graph6"),
        (26, order26, "brace_graph6_before_stop"),
    ):
        values = payload[key]
        assert isinstance(values, list)
        result[order] = [str(value) for value in values]
    return {order: tuple(values) for order, values in sorted(result.items())}


def graph6(graph: nx.Graph) -> str:
    return nx.to_graph6_bytes(graph, header=False).decode().strip()


def freeze_witness(
    order: int,
    source_graph6: str,
    primal: nx.Graph,
    primal_faces: tuple[tuple[int, ...], ...],
    reduced: nx.Graph,
    reduced_faces: tuple[tuple[int, ...], ...],
    split: dict[str, object],
    root: tuple[int, int],
    primal_root: tuple[int, int],
    gate_edges: tuple[tuple[int, int], tuple[int, int]],
    matchings: tuple[frozenset[tuple[int, int]], ...],
) -> dict[str, object]:
    patterns = Counter(
        "".join("1" if gate in matching else "0" for gate in gate_edges)
        for matching in matchings
    )
    first_forced = all(gate_edges[0] in matching for matching in matchings)
    second_forced = all(gate_edges[1] in matching for matching in matchings)
    assert first_forced or second_forced

    expanded = split["expanded"]
    expanded_faces = split["expanded_faces"]
    assert isinstance(expanded, nx.Graph)
    assert isinstance(expanded_faces, tuple)
    expanded_dual = lift.dual_from_plane_graph(expanded, expanded_faces)

    family = []
    for index, matching in enumerate(matchings):
        family.append(
            {
                "family_index": index,
                "matching": sorted(matching),
                "gate_pattern_first_second": "".join(
                    "1" if gate in matching else "0" for gate in gate_edges
                ),
            }
        )

    return {
        "witness_kind": "individual_gate_escape_counterexample",
        "source_order": order,
        "source_graph6": source_graph6,
        "source_primal_edges": sorted(edge(*item) for item in primal.edges()),
        "source_primal_faces": primal_faces,
        "source_is_plane_brace": lift.verify_brace(primal),
        "reduced_triangulation_graph6": graph6(reduced),
        "reduced_triangulation_edges": sorted(
            edge(*item) for item in reduced.edges()
        ),
        "expanded_triangulation_graph6": graph6(expanded),
        "expanded_triangulation_edges": sorted(
            edge(*item) for item in expanded.edges()
        ),
        "expanded_dual_graph6": graph6(expanded_dual),
        "expanded_dual_is_plane_brace": lift.verify_brace(expanded_dual),
        "site": {
            "split_vertex": split["z"],
            "rotation": split["rotation"],
            "gate_indices": (split["first_index"], split["second_index"]),
            "gate_vertices": (split["first_gate"], split["second_gate"]),
            "primal_gate_edges_first_second": gate_edges,
            "closed_arc_cardinalities": (
                split["left_size"],
                split["right_size"],
            ),
            "left_arc": split["left_arc"],
            "right_arc": split["right_arc"],
        },
        "dual_root": root,
        "primal_root": primal_root,
        "complete_target_family_size_mod_complement": len(matchings),
        "gate_pattern_histogram": dict(sorted(patterns.items())),
        "first_gate_forced": first_forced,
        "second_gate_forced": second_forced,
        "weaker_some_target_omits_at_least_one_gate": any(
            any(gate not in matching for gate in gate_edges)
            for matching in matchings
        ),
        "complete_target_family": family,
    }


def analyse_graph(
    order: int,
    source_graph6: str,
) -> tuple[Counter[str], dict[str, object] | None]:
    primal = nx.from_graph6_bytes(source_graph6.encode())
    assert primal.number_of_nodes() == order
    planar, embedding = nx.check_planarity(primal, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    primal_faces = source.plane_faces(primal, embedding)
    assert lift.verify_brace(primal)

    reduced, rotations = lift.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift.verify_reduced_triangulation(reduced)
    split_counts: Counter[str] = Counter()
    splits = wide.legal_wide_splits(reduced, rotations, split_counts)
    counts: Counter[str] = Counter(split_counts)
    counts["plane_braces"] = 1
    counts["legal_wide_splits"] = len(splits)
    if not splits:
        return counts, None

    families, _, _ = lift.target_families(reduced, reduced_faces)
    reduced_vertices = tuple(sorted(reduced))
    dual_to_primal = wide.primal_edge_by_dual_edge(primal, primal_faces)
    family_matchings: dict[
        tuple[int, int], tuple[frozenset[tuple[int, int]], ...]
    ] = {}
    for root, encoded_family in families.items():
        colours = tuple(
            lift.decode_colouring(reduced_vertices, encoded)
            for encoded in encoded_family
        )
        matchings = tuple(
            wide.matching_from_colour(
                primal, reduced, dual_to_primal, colour
            )
            for colour in colours
        )
        assert len(matchings) == len(set(matchings))
        family_matchings[root] = matchings

    for split in splits:
        z = int(split["z"])
        gate_edges = (
            dual_to_primal[edge(z, int(split["first_gate"]))],
            dual_to_primal[edge(z, int(split["second_gate"]))],
        )
        assert gate_edges[0] != gate_edges[1]
        for root in sorted(families):
            if z in root:
                continue
            matchings = family_matchings[root]
            counts["nonempty_wide_rooted_target_families"] += 1
            counts["targets"] += len(matchings)
            first_escape = any(gate_edges[0] not in item for item in matchings)
            second_escape = any(gate_edges[1] not in item for item in matchings)
            weaker_escape = any(
                gate_edges[0] not in item or gate_edges[1] not in item
                for item in matchings
            )
            counts["families_satisfying_weaker_escape"] += int(weaker_escape)
            counts["families_satisfying_both_individual_escapes"] += int(
                first_escape and second_escape
            )
            if first_escape and second_escape:
                continue
            counts["individual_gate_escape_failures"] += 1
            return counts, freeze_witness(
                order,
                source_graph6,
                primal,
                primal_faces,
                reduced,
                reduced_faces,
                split,
                root,
                dual_to_primal[root],
                gate_edges,
                matchings,
            )
    return counts, None


def classify() -> dict[str, object]:
    corpora = frozen_graphs()
    totals: Counter[str] = Counter()
    by_order: dict[str, dict[str, int]] = {}
    witness = None
    for order, graph6_values in corpora.items():
        order_counts: Counter[str] = Counter()
        for source_graph6 in graph6_values:
            counts, witness = analyse_graph(order, source_graph6)
            order_counts.update(counts)
            totals.update(counts)
            if witness is not None:
                break
        by_order[str(order)] = dict(sorted(order_counts.items()))
        if witness is not None:
            break

    return {
        "status": (
            "individual_gate_escape_counterexample_found"
            if witness is not None
            else "individual_gate_escape_supported_in_existing_through26_corpora"
        ),
        "scope": {
            "inputs": "only graph6 representatives frozen in permanent bundles",
            "orders_available": list(corpora),
            "quantifier": (
                "every legal wide split and every nonempty complete rooted-target family"
            ),
            "no_graph_generation": True,
            "stop_at_first_counterexample": True,
        },
        "by_order_before_stop": by_order,
        "counts_before_stop": dict(sorted(totals.items())),
        "first_witness": witness,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    result = classify()
    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
    print(json.dumps(result["counts_before_stop"], sort_keys=True))
    if result["first_witness"] is not None:
        witness = result["first_witness"]
        assert isinstance(witness, dict)
        print(
            "FIRST_INDIVIDUAL_GATE_ESCAPE_COUNTEREXAMPLE",
            witness["source_order"],
            witness["source_graph6"],
            witness["gate_pattern_histogram"],
        )
    else:
        print("INDIVIDUAL_GATE_ESCAPE_SUPPORTED_IN_EXISTING_CORPORA")


if __name__ == "__main__":
    main()
