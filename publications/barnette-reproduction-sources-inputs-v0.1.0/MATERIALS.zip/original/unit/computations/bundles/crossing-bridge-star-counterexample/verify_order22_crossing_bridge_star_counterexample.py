#!/usr/bin/env python3
"""Fixed verification of the minimum frozen crossing-bridge-star failure.

The graph and rooted decoration are literal constants.  The verifier
independently enumerates every perfect matching, reconstructs the complete
rooted two-linkage family, and builds its full single-cycle exchange graph.
It also checks the brace, facial root square, and legal-wide site conditions.
"""

from __future__ import annotations

from hashlib import sha256
from itertools import combinations
import json

import networkx as nx


GRAPH6 = "U?????????[?s?b?KO@Q?BO?Co?F??@o?QG?CE??"
ROOT_SQUARE = (4, 16, 5, 13)
ROOT = (4, 16)
FORCED_GATE = (5, 13)
SURVIVING_GATE = (3, 21)
GATE_FACE = (0, 13, 5, 17, 9, 21, 3, 12)


def edge(first: int, second: int) -> tuple[int, int]:
    return (first, second) if first < second else (second, first)


def edge_set(cycle: tuple[int, ...]) -> frozenset[tuple[int, int]]:
    return frozenset(
        edge(cycle[index], cycle[(index + 1) % len(cycle)])
        for index in range(len(cycle))
    )


def plane_faces(embedding: nx.PlanarEmbedding) -> tuple[tuple[int, ...], ...]:
    visited: set[tuple[int, int]] = set()
    faces = []
    for first, second in embedding.edges():
        if (first, second) in visited:
            continue
        faces.append(tuple(embedding.traverse_face(first, second, visited)))
    return tuple(faces)


def enumerate_perfect_matchings(
    graph: nx.Graph,
) -> tuple[frozenset[tuple[int, int]], ...]:
    def recurse(remaining: frozenset[int]):
        if not remaining:
            yield frozenset()
            return
        first = min(remaining)
        for second in sorted(graph[first]):
            if second not in remaining:
                continue
            item = edge(first, second)
            for suffix in recurse(remaining - {first, second}):
                yield suffix | {item}

    return tuple(recurse(frozenset(graph)))


def verify_brace(
    graph: nx.Graph,
    matchings: tuple[frozenset[tuple[int, int]], ...],
) -> int:
    assert nx.number_of_selfloops(graph) == 0
    assert len(graph) == 22 and graph.number_of_edges() == 33
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    planar, _embedding = nx.check_planarity(graph)
    assert planar
    assert nx.node_connectivity(graph) == 3

    independent_pairs = tuple(
        frozenset((first, second))
        for first, second in combinations(
            (edge(*item) for item in graph.edges()), 2
        )
        if set(first).isdisjoint(second)
    )
    assert len(independent_pairs) == 462
    for pair in independent_pairs:
        assert any(pair <= matching for matching in matchings)
    return len(independent_pairs)


def verify_legal_wide(graph: nx.Graph) -> tuple[int, int]:
    planar, embedding = nx.check_planarity(graph)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    faces = plane_faces(embedding)
    face_edge_sets = {edge_set(face) for face in faces}
    assert edge_set(ROOT_SQUARE) in face_edge_sets
    assert edge_set(GATE_FACE) in face_edge_sets
    assert edge_set(ROOT_SQUARE) == {
        edge(4, 16), edge(16, 5), edge(5, 13), edge(13, 4)
    }
    assert ROOT in edge_set(ROOT_SQUARE)
    assert FORCED_GATE in edge_set(ROOT_SQUARE)
    assert set(ROOT).isdisjoint(FORCED_GATE)

    # Build the plane dual directly from the certified embedding.
    primal_edge_faces: dict[tuple[int, int], list[int]] = {}
    for face_index, face in enumerate(faces):
        for item in edge_set(face):
            primal_edge_faces.setdefault(item, []).append(face_index)
    assert all(len(indices) == 2 for indices in primal_edge_faces.values())
    dual = nx.Graph()
    dual.add_nodes_from(range(len(faces)))
    dual.add_edges_from(tuple(indices) for indices in primal_edge_faces.values())
    assert dual.number_of_edges() == 3 * dual.number_of_nodes() - 6
    assert set(degree % 2 for _, degree in dual.degree()) == {0}
    assert nx.node_connectivity(dual) >= 4

    gate_face_index = next(
        index for index, face in enumerate(faces)
        if edge_set(face) == edge_set(GATE_FACE)
    )
    gate_face = faces[gate_face_index]
    boundary_edges = tuple(
        edge(gate_face[index], gate_face[(index + 1) % len(gate_face)])
        for index in range(len(gate_face))
    )
    first_index = boundary_edges.index(FORCED_GATE)
    second_index = boundary_edges.index(SURVIVING_GATE)
    if first_index > second_index:
        first_index, second_index = second_index, first_index
    left_size = second_index - first_index + 1
    right_size = len(gate_face) - (second_index - first_index) + 1
    assert (left_size, right_size) == (5, 5)

    # The cyclic neighbours of the dual gate-face vertex are the faces
    # across its primal boundary edges.  Split at the two gate positions,
    # exactly as in the legal-wide inverse degree-four reduction.
    rotation = []
    for item in boundary_edges:
        indices = primal_edge_faces[item]
        rotation.append(indices[0] if indices[1] == gate_face_index else indices[1])
    assert len(rotation) == len(set(rotation)) == 8
    left_arc = rotation[first_index : second_index + 1]
    right_arc = rotation[second_index:] + rotation[: first_index + 1]
    expanded = dual.copy()
    expanded.remove_node(gate_face_index)
    next_vertex = max(dual) + 1
    left, right, centre = next_vertex, next_vertex + 1, next_vertex + 2
    expanded.add_nodes_from((left, right, centre))
    expanded.add_edges_from((left, neighbour) for neighbour in left_arc)
    expanded.add_edges_from((right, neighbour) for neighbour in right_arc)
    expanded.add_edges_from(
        (
            (centre, left),
            (centre, left_arc[0]),
            (centre, right),
            (centre, left_arc[-1]),
        )
    )
    assert nx.number_of_selfloops(expanded) == 0
    assert expanded.number_of_edges() == 3 * expanded.number_of_nodes() - 6
    assert set(degree % 2 for _, degree in expanded.degree()) == {0}
    expanded_planar, expanded_embedding = nx.check_planarity(expanded)
    assert expanded_planar and isinstance(expanded_embedding, nx.PlanarEmbedding)
    assert all(len(face) == 3 for face in plane_faces(expanded_embedding))
    assert nx.node_connectivity(expanded) >= 4
    return left_size, right_size


def is_rooted_target(graph: nx.Graph, matching: frozenset[tuple[int, int]]) -> bool:
    if not {ROOT, FORCED_GATE} <= matching:
        return False
    square_vertices = set(ROOT_SQUARE)
    attachments = {
        vertex: next(
            neighbour
            for neighbour in graph[vertex]
            if neighbour not in square_vertices
        )
        for vertex in ROOT_SQUARE
    }
    assert len(set(attachments.values())) == 4
    required_pairs = {
        frozenset((attachments[ROOT_SQUARE[0]], attachments[ROOT_SQUARE[3]])),
        frozenset((attachments[ROOT_SQUARE[1]], attachments[ROOT_SQUARE[2]])),
    }

    residual = graph.subgraph(set(graph) - square_vertices).copy()
    residual.remove_edges_from(matching - {ROOT, FORCED_GATE})
    components = tuple(nx.connected_components(residual))
    if len(components) != 2:
        return False
    endpoint_pairs = set()
    for vertices in components:
        path = residual.subgraph(vertices)
        if path.number_of_edges() != len(vertices) - 1:
            return False
        if any(degree not in {1, 2} for _, degree in path.degree()):
            return False
        endpoints = frozenset(
            vertex for vertex, degree in path.degree() if degree == 1
        )
        if len(endpoints) != 2:
            return False
        endpoint_pairs.add(endpoints)
    return endpoint_pairs == required_pairs


def matching_key(matching: frozenset[tuple[int, int]]):
    return tuple(sorted(matching))


def verify_exchange_graph(
    graph: nx.Graph,
    family: tuple[frozenset[tuple[int, int]], ...],
) -> tuple[nx.Graph, set[int], set[tuple[int, int]], set[tuple[int, int]]]:
    exchange = nx.Graph()
    exchange.add_nodes_from(range(len(family)))
    for first in range(len(family)):
        for second in range(first + 1, len(family)):
            difference = family[first] ^ family[second]
            assert difference
            difference_graph = nx.edge_subgraph(graph, difference)
            assert set(dict(difference_graph.degree()).values()) == {2}
            if nx.is_connected(difference_graph):
                exchange.add_edge(first, second, cycle_length=len(difference))

    expected_edges = {
        (0, 1): 6,
        (0, 2): 6,
        (0, 5): 6,
        (1, 6): 6,
        (2, 7): 6,
        (3, 4): 10,
        (5, 6): 6,
        (5, 7): 6,
    }
    assert {
        tuple(sorted((first, second))): int(data["cycle_length"])
        for first, second, data in exchange.edges(data=True)
    } == expected_edges
    sectors = {
        index for index, matching in enumerate(family)
        if SURVIVING_GATE in matching
    }
    assert sectors == {2, 4, 7}
    crossings = {
        tuple(sorted((first, second)))
        for first, second in exchange.edges()
        if (first in sectors) != (second in sectors)
    }
    assert crossings == {(0, 2), (3, 4), (5, 7)}
    bridges = {tuple(sorted(item)) for item in nx.bridges(exchange)}
    assert bridges == {(3, 4)}
    cross_degree = {
        vertex: sum(vertex in crossing for crossing in crossings)
        for vertex in exchange
    }
    assert (cross_degree[3], cross_degree[4]) == (1, 1)
    assert (exchange.degree(3), exchange.degree(4)) == (1, 1)
    assert {
        frozenset(component) for component in nx.connected_components(exchange)
    } == {frozenset((3, 4)), frozenset((0, 1, 2, 5, 6, 7))}
    assert family[3] ^ family[4] == {
        (3, 20), (3, 21), (6, 18), (6, 20), (8, 17),
        (8, 18), (9, 17), (9, 19), (10, 19), (10, 21),
    }
    return exchange, sectors, crossings, bridges


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    all_matchings = enumerate_perfect_matchings(graph)
    assert len(all_matchings) == len(set(all_matchings)) == 119
    independent_pair_count = verify_brace(graph, all_matchings)
    arc_sizes = verify_legal_wide(graph)
    family = tuple(sorted(
        (matching for matching in all_matchings if is_rooted_target(graph, matching)),
        key=matching_key,
    ))
    assert len(family) == 8
    exchange, sectors, crossings, bridges = verify_exchange_graph(graph, family)

    family_encoding = json.dumps(
        [[list(item) for item in sorted(matching)] for matching in family],
        separators=(",", ":"),
    ).encode()
    print(f"graph6_sha256={sha256(GRAPH6.encode()).hexdigest()}")
    print(f"family_sha256={sha256(family_encoding).hexdigest()}")
    print(
        "order=22 edges=33 perfect_matchings=119 "
        f"independent_edge_pairs={independent_pair_count}"
    )
    print(f"legal_wide_closed_arc_cardinalities={arc_sizes}")
    print(
        f"rooted_family={len(family)} sectors={len(family)-len(sectors)}+{len(sectors)} "
        f"exchange_edges={exchange.number_of_edges()} crossings={len(crossings)}"
    )
    print(f"crossing_bridges={sorted(bridges)} endpoint_cross_degrees=(1,1)")
    print("ORDER22_CROSSING_BRIDGE_STAR_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
