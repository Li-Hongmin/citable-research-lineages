# Order-\(24\) carrier six-crossing compensation

This bundle verifies the finite carrier facts in
[Note 159](../../../notes/159-order24-carrier-forces-six-crossings-after-every-actual-factor-join.md).
The factor-side deletion argument is analytic and appears in the note.

From the AIMath root, run

    uv run --python 3.14 --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/order24-carrier-six-crossing-compensation/verify_order24_carrier_six_crossing_compensation.py

The verified environment on 2026-08-29 was Python 3.14.6 with NetworkX
3.6.1. The terminal marker is

    ORDER24_CARRIER_SIX_CROSSINGS_VERIFIED

The verifier reconstructs the graph and all boundary rows directly from
the graph6 string. It checks simplicity, planarity, cubicity,
bipartiteness, \(3\)-connectivity, the facial root, gate and cut cycles,
legal-wide arc sizes, all \(244\) perfect matchings, extension of all
\(558\) independent edge pairs, all \(104\) carrier boundary rows, the
complete compatible clean-atom table, every carrier atom used in the
proof, and the distinctness of the six forced joined crossings.
