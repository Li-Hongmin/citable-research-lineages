#!/usr/bin/env python3
"""Verify the order-24 carrier and the six-crossing theorem of Note 159."""

from __future__ import annotations

from collections import defaultdict
from functools import lru_cache
from itertools import combinations

import networkx as nx


GRAPH6 = "W???????????w?s?P_BC?Go?B_?B_?@o?GW?B@??_W?A__?"
ROOT_SQUARE = (6, 15, 2, 16)
ROOT = (6, 15)
FORCED_GATE = (2, 16)
SURVIVING_GATE = (4, 14)
GATE_FACE = (0, 12, 2, 16, 7, 18, 9, 20, 4, 14)
CUT_SQUARE = (5, 21, 11, 23)
PORTS = (5, 21, 11, 23)
STATES = (
    frozenset(),
    frozenset((0, 1, 2, 3)),
    frozenset((0, 1)),
    frozenset((1, 2)),
    frozenset((2, 3)),
    frozenset((0, 3)),
)
REQUIRED_ROOT_PAIRS = {frozenset((0, 3)), frozenset((1, 2))}


def edge(left: int, right: int) -> tuple[int, int]:
    return (left, right) if left < right else (right, left)


def face_edges(face: tuple[int, ...]) -> tuple[tuple[int, int], ...]:
    return tuple(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def plane_faces(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    visited: set[tuple[int, int]] = set()
    faces = []
    for left, right in embedding.edges():
        if (left, right) not in visited:
            faces.append(tuple(embedding.traverse_face(left, right, visited)))
    return tuple(faces)


def enumerate_required_matchings(
    graph: nx.Graph,
    removed_vertices: frozenset[int],
    required_edges: frozenset[tuple[int, int]],
) -> tuple[frozenset[tuple[int, int]], ...]:
    if any(set(item) & set(removed_vertices) for item in required_edges):
        return ()
    if any(not graph.has_edge(*item) for item in required_edges):
        return ()
    used = {vertex for item in required_edges for vertex in item}
    if len(used) != 2 * len(required_edges):
        return ()

    vertices = tuple(sorted(set(graph) - set(removed_vertices) - used, key=repr))
    position = {vertex: index for index, vertex in enumerate(vertices)}
    neighbours = [0] * len(vertices)
    for left, right in graph.edges():
        if left in position and right in position:
            neighbours[position[left]] |= 1 << position[right]
            neighbours[position[right]] |= 1 << position[left]

    @lru_cache(maxsize=None)
    def solve(mask: int) -> tuple[tuple[tuple[int, int], ...], ...]:
        if not mask:
            return ((),)
        candidates = [index for index in range(len(vertices)) if mask >> index & 1]
        first = min(
            candidates,
            key=lambda index: ((neighbours[index] & mask).bit_count(), index),
        )
        choices = neighbours[first] & mask
        remainder = mask ^ (1 << first)
        rows = []
        while choices:
            bit = choices & -choices
            choices ^= bit
            second = bit.bit_length() - 1
            for suffix in solve(remainder ^ bit):
                rows.append(((first, second),) + suffix)
        return tuple(rows)

    return tuple(
        frozenset(required_edges)
        | frozenset(edge(vertices[left], vertices[right]) for left, right in encoded)
        for encoded in solve((1 << len(vertices)) - 1)
    )


def root_attachments(graph: nx.Graph) -> tuple[int, ...]:
    square = set(ROOT_SQUARE)
    attachments = []
    for vertex in ROOT_SQUARE:
        outside = [neighbour for neighbour in graph[vertex] if neighbour not in square]
        assert len(outside) == 1
        attachments.append(outside[0])
    assert len(set(attachments)) == 4
    return tuple(attachments)


def complement_components(
    cut: nx.Graph,
    attachments: tuple[int, ...],
    matching: frozenset[tuple[int, int]],
):
    residual = cut.subgraph(set(cut) - set(ROOT_SQUARE)).copy()
    residual.remove_edges_from(matching)
    components = []
    for vertices in nx.connected_components(residual):
        component = residual.subgraph(vertices)
        degrees = tuple(dict(component.degree()).values())
        ports = frozenset(index for index, vertex in enumerate(PORTS) if vertex in vertices)
        roots = frozenset(
            index for index, vertex in enumerate(attachments) if vertex in vertices
        )
        if degrees and all(value == 2 for value in degrees):
            kind = "cycle"
        else:
            if not all(value in {1, 2} for value in degrees):
                return None
            kind = "path"
        components.append((kind, ports, roots))
    return tuple(
        sorted(components, key=lambda item: (item[0], tuple(item[1]), tuple(item[2])))
    )


def factor_join_passes(
    components,
    state: frozenset[int],
    factor_pairs: tuple[frozenset[int], ...],
) -> bool:
    if components is None or any(kind == "cycle" for kind, _ports, _roots in components):
        return False
    auxiliary = nx.Graph()
    marks = {}
    for index, (_kind, ports, roots) in enumerate(components):
        name = ("carrier", index)
        auxiliary.add_node(name)
        marks[name] = set(roots)
    for index, pair in enumerate(factor_pairs):
        name = ("factor", index)
        auxiliary.add_node(name)
        marks[name] = set()
        for port in pair:
            owners = [
                ("carrier", ordinal)
                for ordinal, (_kind, ports, _roots) in enumerate(components)
                if port in ports
            ]
            if len(owners) != 1:
                return False
            auxiliary.add_edge(name, owners[0])
    if set().union(*map(set, factor_pairs)) != set(range(4)) - set(state):
        return False
    root_pairs = set()
    for vertices in nx.connected_components(auxiliary):
        roots = frozenset().union(*(marks[vertex] for vertex in vertices))
        if len(roots) != 2:
            return False
        root_pairs.add(roots)
    return root_pairs == REQUIRED_ROOT_PAIRS


def bond_atom(cut: nx.Graph, first, second):
    state_first, matching_first = first
    state_second, matching_second = second
    difference = matching_first ^ matching_second
    if not difference:
        return (), 0
    difference_graph = nx.edge_subgraph(cut, difference).copy()
    paths = []
    cycles = 0
    for vertices in nx.connected_components(difference_graph):
        component = difference_graph.subgraph(vertices)
        ends = [vertex for vertex, degree in component.degree() if degree == 1]
        if not ends:
            assert set(dict(component.degree()).values()) == {2}
            cycles += 1
        else:
            assert len(ends) == 2
            marks = frozenset(index for index, vertex in enumerate(PORTS) if vertex in ends)
            assert len(marks) == 2
            paths.append(marks)
    actual = set().union(*map(set, paths)) if paths else set()
    assert actual == set(state_first ^ state_second)
    return tuple(sorted(paths, key=tuple)), cycles


def carrier_rows(graph: nx.Graph):
    cut = graph.copy()
    cut.remove_edges_from((edge(PORTS[0], PORTS[1]), edge(PORTS[2], PORTS[3])))
    required = frozenset((edge(*ROOT), edge(*FORCED_GATE)))
    attachments = root_attachments(graph)
    rows = []
    for state in STATES:
        removed = frozenset(PORTS[index] for index in state)
        for matching in enumerate_required_matchings(cut, removed, required):
            profile = complement_components(cut, attachments, matching)
            if profile is not None:
                rows.append((state, matching, profile))
    return cut, tuple(rows)


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert len(graph) == 24 and graph.number_of_edges() == 36
    assert nx.number_of_selfloops(graph) == 0
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.is_connected(graph) and nx.is_bipartite(graph)
    assert nx.node_connectivity(graph) == 3

    faces = plane_faces(graph)
    facial_edge_sets = {frozenset(face_edges(face)) for face in faces}
    assert frozenset(face_edges(ROOT_SQUARE)) in facial_edge_sets
    assert frozenset(face_edges(GATE_FACE)) in facial_edge_sets
    assert frozenset(face_edges(CUT_SQUARE)) in facial_edge_sets
    assert set(ROOT_SQUARE).isdisjoint(CUT_SQUARE)

    gate_boundary = face_edges(GATE_FACE)
    first = gate_boundary.index(edge(*FORCED_GATE))
    second = gate_boundary.index(edge(*SURVIVING_GATE))
    distance = (second - first) % len(gate_boundary)
    assert sorted((distance + 1, len(gate_boundary) - distance + 1)) == [5, 7]

    perfect_matchings = enumerate_required_matchings(graph, frozenset(), frozenset())
    assert len(perfect_matchings) == 244
    graph_edges = tuple(edge(*item) for item in graph.edges())
    independent_pairs = tuple(
        frozenset((left, right))
        for left, right in combinations(graph_edges, 2)
        if set(left).isdisjoint(right)
    )
    assert len(independent_pairs) == 558
    assert all(any(pair <= matching for matching in perfect_matchings) for pair in independent_pairs)

    cut, rows = carrier_rows(graph)
    state_counts = {
        state: sum(row_state == state for row_state, _matching, _profile in rows)
        for state in STATES
    }
    assert len(rows) == 104
    assert state_counts == {
        frozenset(): 34,
        frozenset((0, 1, 2, 3)): 13,
        frozenset((0, 1)): 10,
        frozenset((1, 2)): 19,
        frozenset((2, 3)): 10,
        frozenset((0, 3)): 18,
    }
    required = frozenset((edge(*ROOT), edge(*FORCED_GATE)))
    assert state_counts == {
        state: len(
            enumerate_required_matchings(
                cut,
                frozenset(PORTS[index] for index in state),
                required,
            )
        )
        for state in STATES
    }

    atoms = {
        "Z": (frozenset(), (frozenset((0, 1)), frozenset((2, 3)))),
        "O": (frozenset(), (frozenset((0, 3)), frozenset((1, 2)))),
        "A0": (frozenset((0, 1)), (frozenset((2, 3)),)),
        "A1": (frozenset((1, 2)), (frozenset((0, 3)),)),
        "A2": (frozenset((2, 3)), (frozenset((0, 1)),)),
        "A3": (frozenset((0, 3)), (frozenset((1, 2)),)),
    }
    compatible = {
        label: tuple(
            index
            for index, (row_state, _matching, profile) in enumerate(rows)
            if row_state == state and factor_join_passes(profile, state, pairing)
        )
        for label, (state, pairing) in atoms.items()
    }
    assert compatible == {
        "Z": (0, 3, 4, 5, 18, 23),
        "O": (2,),
        "A0": (47, 50, 51, 54),
        "A1": (59,),
        "A2": (78, 81, 84, 85),
        "A3": (88,),
    }

    surviving = edge(*SURVIVING_GATE)
    def sector(index: int) -> int:
        return int(surviving in rows[index][1])

    assert {
        label: tuple(sector(index) for index in indices)
        for label, indices in compatible.items()
    } == {
        "Z": (1, 1, 1, 0, 0, 1),
        "O": (1,),
        "A0": (1, 1, 1, 1),
        "A1": (1,),
        "A2": (0, 0, 0, 0),
        "A3": (1,),
    }

    danger_table = defaultdict(list)
    labels = tuple(atoms)
    for left_position, left_label in enumerate(labels):
        for right_label in labels[left_position:]:
            for left in compatible[left_label]:
                for right in compatible[right_label]:
                    if left_label == right_label and left >= right:
                        continue
                    if sector(left) == sector(right):
                        continue
                    atom = bond_atom(cut, rows[left][:2], rows[right][:2])
                    danger_table[(left_label, right_label, atom)].append((left, right))

    one_cycle = ((), 1)
    path01 = ((frozenset((0, 1)),), 0)
    path12 = ((frozenset((1, 2)),), 0)
    path23 = ((frozenset((2, 3)),), 0)
    path03 = ((frozenset((0, 3)),), 0)
    two_paths = ((frozenset((0, 1)), frozenset((2, 3))), 0)
    assert danger_table[("Z", "Z", one_cycle)] == [(0, 5), (18, 23)]
    assert danger_table[("Z", "A0", path01)] == [(5, 47), (18, 54)]
    assert danger_table[("Z", "A1", path12)] == [(18, 59)]
    assert danger_table[("Z", "A2", path23)] == [
        (0, 81),
        (3, 84),
        (4, 85),
        (23, 78),
    ]
    assert danger_table[("Z", "A3", path03)] == [(5, 88)]
    assert danger_table[("A0", "A2", two_paths)] == [
        (47, 81),
        (50, 84),
        (51, 85),
        (54, 78),
    ]

    def joined_edge(
        first: tuple[int, str], second: tuple[int, str]
    ) -> frozenset[tuple[int, str]]:
        return frozenset((first, second))

    forced_crossings = {
        joined_edge((5, "N0"), (47, "N1")),
        joined_edge((18, "N0"), (54, "N1")),
        joined_edge((0, "N0"), (5, "N0")),
        joined_edge((18, "N0"), (23, "N0")),
        joined_edge((18, "N0"), (59, "R1")),
        joined_edge((5, "N0"), (88, "R3")),
    }
    assert len(forced_crossings) == 6

    print("graph_order=24 perfect_matchings=244 independent_edge_pairs=558")
    print("legal_wide_gate_arcs=5,7")
    print("ports=(5,21,11,23) cut_edges=5-21,11-23 carrier_rows=104")
    print("designated_Z_A0_slots=K5-K47,K18-K54")
    print("same_N0_slots=K0-K5,K18-K23")
    print("deletion_slots=K18-K59,K5-K88")
    print("forced_distinct_crossings=6")
    print("ORDER24_CARRIER_SIX_CROSSINGS_VERIFIED")


if __name__ == "__main__":
    main()
