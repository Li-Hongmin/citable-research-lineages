#!/usr/bin/env python3
"""Verify a legal-wide root-square crossing with no rooted triangle.

The graph is fixed by graph6.  The verifier independently enumerates all
perfect matchings, checks the brace condition, reconstructs the complete
rooted fixed-pairing fibre, and builds its single-cycle exchange graph.
"""

from __future__ import annotations

from itertools import combinations

import networkx as nx


GRAPH6 = "W???????????w?s?P_BC?Go?B_?B_?@o?GW?B@??_W?A__?"
ROOT_SQUARE = (6, 15, 2, 16)
ROOT = (6, 15)
FORCED_GATE = (2, 16)
SURVIVING_GATE = (4, 14)
FIXED_EDGE = (9, 18)
GATE_FACE = (0, 12, 2, 16, 7, 18, 9, 20, 4, 14)

FIRST = frozenset(
    {
        (0, 13),
        (1, 12),
        (2, 16),
        (3, 22),
        (4, 14),
        (5, 23),
        (6, 15),
        (7, 17),
        (8, 19),
        (9, 18),
        (10, 20),
        (11, 21),
    }
)
SECOND = frozenset(
    {
        (0, 13),
        (1, 12),
        (2, 16),
        (3, 22),
        (4, 21),
        (5, 14),
        (6, 15),
        (7, 17),
        (8, 19),
        (9, 18),
        (10, 20),
        (11, 23),
    }
)


def edge(first: int, second: int) -> tuple[int, int]:
    return (first, second) if first < second else (second, first)


def face_edges(face: tuple[int, ...]) -> tuple[tuple[int, int], ...]:
    return tuple(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def plane_faces(embedding: nx.PlanarEmbedding) -> tuple[tuple[int, ...], ...]:
    visited: set[tuple[int, int]] = set()
    result = []
    for first, second in embedding.edges():
        if (first, second) in visited:
            continue
        result.append(tuple(embedding.traverse_face(first, second, visited)))
    return tuple(result)


def enumerate_perfect_matchings(
    graph: nx.Graph,
) -> tuple[frozenset[tuple[int, int]], ...]:
    adjacency = {
        vertex: tuple(sorted(graph[vertex])) for vertex in sorted(graph)
    }

    def recurse(
        remaining: frozenset[int],
    ):
        if not remaining:
            yield frozenset()
            return
        first = min(remaining)
        for second in adjacency[first]:
            if second not in remaining:
                continue
            for suffix in recurse(remaining - {first, second}):
                yield suffix | {edge(first, second)}

    return tuple(recurse(frozenset(graph)))


def is_single_cycle_exchange(
    graph: nx.Graph,
    first: frozenset[tuple[int, int]],
    second: frozenset[tuple[int, int]],
) -> bool:
    difference = first ^ second
    if not difference:
        return False
    subgraph = nx.edge_subgraph(graph, difference)
    return nx.is_connected(subgraph) and set(dict(subgraph.degree()).values()) == {2}


def is_rooted_target(
    graph: nx.Graph,
    matching: frozenset[tuple[int, int]],
) -> bool:
    square_vertices = set(ROOT_SQUARE)
    required = {edge(*ROOT), edge(*FORCED_GATE)}
    if not required <= matching:
        return False

    attachments = {}
    for vertex in ROOT_SQUARE:
        outside = [
            neighbour
            for neighbour in graph[vertex]
            if neighbour not in square_vertices
        ]
        assert len(outside) == 1
        attachments[vertex] = outside[0]

    required_pairs = {
        frozenset((attachments[ROOT_SQUARE[0]], attachments[ROOT_SQUARE[3]])),
        frozenset((attachments[ROOT_SQUARE[1]], attachments[ROOT_SQUARE[2]])),
    }
    residual = graph.subgraph(set(graph) - square_vertices).copy()
    residual.remove_edges_from(matching - required)
    components = tuple(nx.connected_components(residual))
    if len(components) != 2:
        return False

    endpoint_pairs = set()
    for vertices in components:
        component = residual.subgraph(vertices)
        if any(degree not in {1, 2} for _, degree in component.degree()):
            return False
        endpoints = frozenset(
            vertex for vertex, degree in component.degree() if degree == 1
        )
        if len(endpoints) != 2:
            return False
        endpoint_pairs.add(endpoints)
    return endpoint_pairs == required_pairs


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert len(graph) == 24
    assert nx.number_of_edges(graph) == 36
    assert not nx.number_of_selfloops(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.is_connected(graph)
    assert nx.is_bipartite(graph)
    assert nx.node_connectivity(graph) == 3

    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    faces = plane_faces(embedding)
    facial_edge_sets = {frozenset(face_edges(face)) for face in faces}
    assert frozenset(face_edges(ROOT_SQUARE)) in facial_edge_sets
    assert frozenset(face_edges(GATE_FACE)) in facial_edge_sets

    boundary = face_edges(GATE_FACE)
    forced_index = boundary.index(edge(*FORCED_GATE))
    surviving_index = boundary.index(edge(*SURVIVING_GATE))
    clockwise = (surviving_index - forced_index) % len(boundary)
    counterclockwise = len(boundary) - clockwise
    assert sorted((clockwise + 1, counterclockwise + 1)) == [5, 7]

    perfect_matchings = enumerate_perfect_matchings(graph)
    assert len(perfect_matchings) == len(set(perfect_matchings)) == 244
    graph_edges = tuple(sorted(edge(*item) for item in graph.edges()))
    independent_pairs = tuple(
        frozenset((first, second))
        for first, second in combinations(graph_edges, 2)
        if set(first).isdisjoint(second)
    )
    assert len(independent_pairs) == 558
    assert all(
        any(pair <= matching for matching in perfect_matchings)
        for pair in independent_pairs
    )

    targets = tuple(
        matching
        for matching in perfect_matchings
        if is_rooted_target(graph, matching)
    )
    assert len(targets) == 15
    surviving = edge(*SURVIVING_GATE)
    assert sum(surviving in matching for matching in targets) == 9
    assert FIRST in targets and SECOND in targets
    assert surviving in FIRST and surviving not in SECOND

    exchange_edges = tuple(
        (first, second)
        for first, second in combinations(range(len(targets)), 2)
        if is_single_cycle_exchange(graph, targets[first], targets[second])
    )
    assert len(exchange_edges) == 22
    crossing_edges = tuple(
        (first, second)
        for first, second in exchange_edges
        if (surviving in targets[first]) != (surviving in targets[second])
    )
    assert len(crossing_edges) == 10

    fixed = edge(*FIXED_EDGE)
    fixed_indices = {
        index for index, matching in enumerate(targets) if fixed in matching
    }
    assert len(fixed_indices) == 3
    fixed_crossings = tuple(
        (first, second)
        for first, second in crossing_edges
        if {first, second} <= fixed_indices
    )
    first_index = targets.index(FIRST)
    second_index = targets.index(SECOND)
    assert fixed_crossings == ((first_index, second_index),)

    difference = FIRST ^ SECOND
    assert len(difference) == 6
    assert is_single_cycle_exchange(graph, FIRST, SECOND)
    assert difference & frozenset(boundary) == {surviving}
    assert fixed in FIRST & SECOND

    rotated = boundary[forced_index:] + boundary[:forced_index]
    symbols = {
        (False, False): "0",
        (True, False): "M",
        (False, True): "N",
        (True, True): "B",
    }
    word = "".join(
        symbols[(item in FIRST, item in SECOND)] for item in rotated
    )
    assert word == "B00B00M000"

    adjacency = {index: set() for index in range(len(targets))}
    for left, right in exchange_edges:
        adjacency[left].add(right)
        adjacency[right].add(left)
    assert not (adjacency[first_index] & adjacency[second_index])

    print("order=24 perfect_matchings=244 independent_edge_pairs=558")
    print("rooted_targets=15 exchange_edges=22 crossings=10")
    print("fixed_subfibre=3 fixed_crossings=1 word=B00B00M000")
    print("distinguished_common_exchange_neighbours=0")
    print("FIXED_COMMON_B_NO_ROOTED_TRIANGLE_VERIFIED")


if __name__ == "__main__":
    main()
