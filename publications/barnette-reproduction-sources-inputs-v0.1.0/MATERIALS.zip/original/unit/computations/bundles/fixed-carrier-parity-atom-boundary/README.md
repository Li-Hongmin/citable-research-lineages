# Fixed-carrier parity atom boundary

This bundle verifies the finite carrier calculation and the symbolic parity
model in
[Note 157](../../../notes/157-hamilton-parity-does-not-force-rooted-crossing-compensation.md).
It does not search for a larger annular factor.

From the AIMath root, run

    uv run --python 3.14 --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/fixed-carrier-parity-atom-boundary/audit_fixed_carrier_atoms.py

    python3 \
      units/barnette/computations/bundles/fixed-carrier-parity-atom-boundary/verify_four_square_parity_atoms.py

The verified environment on 2026-08-29 was Python 3.14.6 with NetworkX
3.6.1.  The terminal markers are

    FIXED_CARRIER_ATOMS_AUDITED
    FOUR_SQUARE_PARITY_ATOMS_VERIFIED

The first verifier reconstructs all 54 boundary rows of the fixed order-22
carrier, their states, gate sectors, marked complement joins and every
relevant bond atom.  The second verifier computes the complete mod-two
kernel of the six Hamilton traces at a square and checks the minimal
parity-compatible atom system with exactly one mixed joined bond.
