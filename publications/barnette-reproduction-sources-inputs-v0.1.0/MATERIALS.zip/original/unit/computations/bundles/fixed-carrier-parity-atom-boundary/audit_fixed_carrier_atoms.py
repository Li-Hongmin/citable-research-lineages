#!/usr/bin/env python3
"""Enumerate the fixed Note 154 carrier-side boundary atoms.

This is deliberately factor-free.  It enumerates carrier rows at the cut
(19,10,21,9), computes the marked complement components, and tests the three
clean factor complement atoms forced by T0, T1, and Smith--Thomason's H2.
"""

from __future__ import annotations

from collections import defaultdict
from itertools import combinations

import networkx as nx


GRAPH6 = "U?????????[?s?b?KO@Q?BO?Co?F??@o?QG?CE??"
ROOT_SQUARE = (4, 16, 5, 13)
ROOT = (4, 16)
FORCED_GATE = (5, 13)
SURVIVING_GATE = (3, 21)
CUT_EDGES = ((10, 19), (9, 21))
PORTS = (19, 10, 21, 9)
ATTACHMENTS = (15, 7, 17, 0)
REQUIRED = {frozenset((0, 3)), frozenset((1, 2))}
STATES = (frozenset(), frozenset(range(4))) + tuple(
    frozenset((i, (i + 1) % 4)) for i in range(4)
)


def edge(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


def enumerate_perfect_matchings(graph: nx.Graph):
    def rec(remaining: frozenset[int]):
        if not remaining:
            yield frozenset()
            return
        u = min(remaining)
        for v in sorted(graph[u]):
            if v not in remaining:
                continue
            for tail in rec(remaining - {u, v}):
                yield tail | {edge(u, v)}

    yield from rec(frozenset(graph))


def carrier_rows(graph: nx.Graph):
    cut = graph.copy()
    cut.remove_edges_from(CUT_EDGES)
    rows = []
    for state in STATES:
        removed = {PORTS[i] for i in state}
        shore = cut.subgraph(set(cut) - removed).copy()
        for matching in enumerate_perfect_matchings(shore):
            if {edge(*ROOT), edge(*FORCED_GATE)} <= matching:
                rows.append((state, matching))
    return cut, tuple(rows)


def complement_components(cut: nx.Graph, state, matching):
    residual = cut.subgraph(set(cut) - set(ROOT_SQUARE)).copy()
    residual.remove_edges_from(matching)
    components = []
    for vertices in nx.connected_components(residual):
        sub = residual.subgraph(vertices)
        port_marks = frozenset(i for i, v in enumerate(PORTS) if v in vertices)
        root_marks = frozenset(i for i, v in enumerate(ATTACHMENTS) if v in vertices)
        degrees = tuple(dict(sub.degree()).values())
        if all(d == 2 for d in degrees):
            kind = "cycle"
        else:
            assert all(d in {1, 2} for d in degrees)
            kind = "path"
        components.append((kind, port_marks, root_marks, frozenset(sub.edges())))
    return tuple(sorted(components, key=lambda x: (x[0], tuple(x[1]), tuple(x[2]))))


def factor_join_passes(components, state, factor_pairs):
    """Join carrier components and clean factor paths via unused connectors."""
    nodes = []
    for j, (kind, ports, roots, _edges) in enumerate(components):
        if kind == "cycle":
            return False
        nodes.append((f"g{j}", ports, roots))

    aux = nx.Graph()
    marks = {}
    for name, ports, roots in nodes:
        aux.add_node(name)
        marks[name] = set(roots)
    for j, pair in enumerate(factor_pairs):
        name = f"b{j}"
        aux.add_node(name)
        marks[name] = set()
        for port in pair:
            owners = [n for n, ports, _roots in nodes if port in ports]
            assert len(owners) == 1, (port, owners, components)
            aux.add_edge(name, owners[0])

    # State ports do not use complement connectors and hence do not occur in
    # factor_pairs.  Every non-state port occurs exactly once.
    assert set().union(*map(set, factor_pairs)) == set(range(4)) - set(state)
    root_pairs = set()
    for vertices in nx.connected_components(aux):
        roots = frozenset().union(*(marks[v] for v in vertices))
        if len(roots) != 2:
            return False
        root_pairs.add(roots)
    return root_pairs == REQUIRED


def bond_atom(cut: nx.Graph, first, second):
    state1, matching1 = first
    state2, matching2 = second
    diff = matching1 ^ matching2
    if not diff:
        return ((), 0)
    graph = nx.edge_subgraph(cut, diff).copy()
    paths = []
    cycles = 0
    for vertices in nx.connected_components(graph):
        sub = graph.subgraph(vertices)
        ends = [v for v, degree in sub.degree() if degree == 1]
        if not ends:
            assert all(degree == 2 for _, degree in sub.degree())
            cycles += 1
        else:
            assert len(ends) == 2
            marks = frozenset(i for i, v in enumerate(PORTS) if v in ends)
            assert len(marks) == 2
            paths.append(marks)
    path_ports = set().union(*map(set, paths)) if paths else set()
    assert path_ports == set(state1 ^ state2)
    return (tuple(sorted(paths, key=tuple)), cycles)


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    cut, rows = carrier_rows(graph)
    atoms = [complement_components(cut, state, matching) for state, matching in rows]

    factor_atoms = {
        "N0_01|23": (frozenset(), (frozenset((0, 1)), frozenset((2, 3)))),
        "N1_23": (frozenset((0, 1)), (frozenset((2, 3)),)),
        "N2_empty_03|12": (frozenset(), (frozenset((0, 3)), frozenset((1, 2)))),
        "N2_A0_23": (frozenset((0, 1)), (frozenset((2, 3)),)),
    }

    compatible = defaultdict(list)
    for label, (state, pairs) in factor_atoms.items():
        for index, ((row_state, matching), atom) in enumerate(zip(rows, atoms)):
            if row_state == state and factor_join_passes(atom, state, pairs):
                compatible[label].append(index)

    state_counts = {
        tuple(sorted(state)): sum(row_state == state for row_state, _ in rows)
        for state in STATES
    }
    assert len(rows) == 54
    assert state_counts == {
        (): 22,
        (0, 1, 2, 3): 6,
        (0, 1): 3,
        (1, 2): 12,
        (2, 3): 0,
        (0, 3): 11,
    }
    assert dict(compatible) == {
        "N0_01|23": [1, 2, 10, 19, 20],
        "N1_23": [29],
        "N2_empty_03|12": [0, 18],
        "N2_A0_23": [29],
    }
    gate_bits = {
        index: int(edge(*SURVIVING_GATE) in rows[index][1])
        for index in (0, 1, 2, 10, 18, 19, 20, 29)
    }
    assert gate_bits == {
        0: 0, 1: 0, 2: 1, 10: 0,
        18: 0, 19: 0, 20: 1, 29: 1,
    }

    path01 = (frozenset((0, 1)),)
    assert bond_atom(cut, rows[10], rows[29]) == (path01, 0)
    for index in (1, 19, 0, 18):
        assert bond_atom(cut, rows[index], rows[29]) == (path01, 1)
    for extra in (0, 18):
        for target in (1, 2, 10, 19, 20):
            paths, closed = bond_atom(cut, rows[extra], rows[target])
            assert not paths and closed >= 1

    print(f"carrier_rows={len(rows)}")
    print("state_counts=" + repr(state_counts))
    for label, indices in compatible.items():
        print(f"{label}: count={len(indices)} rows={indices}")
        for index in indices:
            state, matching = rows[index]
            gate = edge(*SURVIVING_GATE) in matching
            comp = tuple((kind, tuple(sorted(ports)), tuple(sorted(roots))) for kind, ports, roots, _ in atoms[index])
            print(f"  K{index} gate={int(gate)} comp={comp} matching={sorted(matching)}")

    assert dict(compatible) == {
        "N0_01|23": [1, 2, 10, 19, 20],
        "N1_23": [29],
        "N2_empty_03|12": [0, 18],
        "N2_A0_23": [29],
    }
    assert {
        index: int(edge(*SURVIVING_GATE) in rows[index][1])
        for index in (0, 1, 2, 10, 18, 19, 20, 29)
    } == {0: 0, 1: 0, 2: 1, 10: 0, 18: 0, 19: 0, 20: 1, 29: 1}

    # In the old rooted-family numbering:
    # K1=M1, K2=M2, K10=M3, K29=M4, K19=M6, K20=M7.
    # The alternative empty-state complement atom admits K0,K18, which were
    # not old rooted targets because their original complement pairing fails.

    # Exact carrier bond table among every row that can pair with one of the
    # four factor atoms above.
    relevant = sorted(set().union(*compatible.values()))
    print(f"relevant_carrier_rows={relevant}")
    for i, j in combinations(relevant, 2):
        print(f"bond K{i}-K{j}={bond_atom(cut, rows[i], rows[j])}")

    # Exact mixed-bond boundary for a parity row of state A0.  Against K29
    # only K10 has a clean carrier 01 path; the other gate-0 rows already
    # carry a closed alternating component.
    assert bond_atom(cut, rows[1], rows[29]) == ((frozenset((0, 1)),), 1)
    assert bond_atom(cut, rows[10], rows[29]) == ((frozenset((0, 1)),), 0)
    assert bond_atom(cut, rows[19], rows[29]) == ((frozenset((0, 1)),), 1)

    # A parity row of empty state and pairing 03|12 can only use K0 or K18.
    # Each has a closed carrier bond component against the sole A0 row K29,
    # so that parity row itself can never create a mixed one-cycle bond.
    assert bond_atom(cut, rows[0], rows[29]) == ((frozenset((0, 1)),), 1)
    assert bond_atom(cut, rows[18], rows[29]) == ((frozenset((0, 1)),), 1)

    print("FIXED_CARRIER_ATOMS_AUDITED")


if __name__ == "__main__":
    main()
