#!/usr/bin/env python3
"""Verify the six-class parity kernel and the minimal splice atom model."""

from __future__ import annotations

from itertools import product


CLASSES = ("U0", "U1", "U2", "U3", "O02", "O13")

# Incidence of each local edge in the six Hamilton square traces.
INCIDENCE = {
    "q0": (0, 1, 1, 1, 1, 0),
    "q1": (1, 0, 1, 1, 0, 1),
    "q2": (1, 1, 0, 1, 1, 0),
    "q3": (1, 1, 1, 0, 0, 1),
    "r0": (1, 0, 0, 1, 1, 1),
    "r1": (1, 1, 0, 0, 1, 1),
    "r2": (0, 1, 1, 0, 1, 1),
    "r3": (0, 0, 1, 1, 1, 1),
}


def dot_mod2(first, second):
    return sum(left * right for left, right in zip(first, second)) % 2


def rank_mod2(rows):
    vectors = [sum(bit << index for index, bit in enumerate(row)) for row in rows]
    rank = 0
    bit = 0
    while bit < len(CLASSES):
        pivot = next((index for index in range(rank, len(vectors)) if vectors[index] & (1 << bit)), None)
        if pivot is None:
            bit += 1
            continue
        vectors[rank], vectors[pivot] = vectors[pivot], vectors[rank]
        for index in range(len(vectors)):
            if index != rank and vectors[index] & (1 << bit):
                vectors[index] ^= vectors[rank]
        rank += 1
        bit += 1
    return rank


def main() -> None:
    square_rows = [INCIDENCE[f"q{index}"] for index in range(4)]
    all_rows = list(INCIDENCE.values())
    assert rank_mod2(square_rows) == 4
    assert rank_mod2(all_rows) == 4

    kernel = {
        vector
        for vector in product((0, 1), repeat=len(CLASSES))
        if all(dot_mod2(row, vector) == 0 for row in all_rows)
    }
    first_generator = (1, 0, 1, 0, 1, 0)
    second_generator = (0, 1, 0, 1, 0, 1)
    assert kernel == {
        (0, 0, 0, 0, 0, 0),
        first_generator,
        second_generator,
        tuple(left ^ right for left, right in zip(first_generator, second_generator)),
    }

    # O13 is nonclean; Z is the non-Hamilton two-cycle clean class.  After
    # eliminating O13, the six clean coordinates are (Z,U0,U1,U2,U3,O02).
    clean_projection = {
        (z, vector[0], vector[1], vector[2], vector[3], vector[4])
        for z in (0, 1)
        for vector in kernel
    }
    assert clean_projection == {
        (z, x, y, x, y, x)
        for z in (0, 1)
        for x in (0, 1)
        for y in (0, 1)
    }

    # The minimum odd-U0 atom uses U0, U2, O02.  Every local edge has
    # even incidence in these three symbolic Hamilton cycles.
    selected = first_generator
    assert sum(selected) == 3
    assert all(dot_mod2(row, selected) == 0 for row in all_rows)

    # Four clean factor rows: T0 plus the three Hamilton rows.  Use the
    # literal fixed-carrier join and closed-component atoms.
    rows = ("N0", "N1", "R2", "R02")
    compatible = {
        "N0": (1, 2, 10, 19, 20),
        "N1": (29,),
        "R2": (),
        "R02": (0, 18),
    }
    carrier_sector = {
        0: 0, 1: 0, 2: 1, 10: 0,
        18: 0, 19: 0, 20: 1, 29: 1,
    }
    closed_cycles = {
        frozenset((0, 2)): 1,
        frozenset((0, 20)): 2,
        frozenset((18, 2)): 2,
        frozenset((18, 20)): 1,
        frozenset((0, 29)): 1,
        frozenset((18, 29)): 1,
        frozenset((1, 2)): 2,
        frozenset((1, 20)): 3,
        frozenset((10, 2)): 2,
        frozenset((10, 20)): 2,
        frozenset((19, 2)): 3,
        frozenset((19, 20)): 2,
        frozenset((1, 29)): 1,
        frozenset((10, 29)): 0,
        frozenset((19, 29)): 1,
    }
    factor_bond = {frozenset(("N0", "N1")): 1}
    targets = [
        (carrier, row)
        for row in rows
        for carrier in compatible[row]
    ]
    mixed_bonds = set()
    for first_index, first in enumerate(targets):
        for second in targets[first_index + 1:]:
            first_carrier, first_row = first
            second_carrier, second_row = second
            if carrier_sector[first_carrier] == carrier_sector[second_carrier]:
                continue
            if closed_cycles.get(frozenset((first_carrier, second_carrier)), 1):
                continue
            if not factor_bond.get(frozenset((first_row, second_row)), 0):
                continue
            mixed_bonds.add(frozenset((first, second)))
    assert mixed_bonds == {
        frozenset(((10, "N0"), (29, "N1")))
    }

    print("six_hamilton_traces_rank=4 kernel_dimension=2")
    print("six_clean_classes_relation_rank=3")
    print("kernel_generators=U0+U2+O02,U1+U3+O13")
    print("minimal_odd_U0_hamilton_rows=3")
    print("fixed_carrier_parity_atom_spliced_mixed_bonds=1")
    print("FOUR_SQUARE_PARITY_ATOMS_VERIFIED")


if __name__ == "__main__":
    main()
