#!/usr/bin/env python3
"""Find the first wide complete-family two-gate forcing at order 26.

A site is wide when both closed gate arcs have cardinality at least five.
Only simple plane cubic bipartite braces and legal C4 expansions are tested.
The stream stops at the first nonempty unchanged-root target family in which
both primal gate edges occur in every target.  All eight local rows of every
target in that family are then evaluated, distinguishing a counterexample to
wide gate escape from a failure of ordinary existence-level lifting.
"""

from __future__ import annotations

from collections import Counter
from itertools import product
import argparse
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
from typing import Iterator

import networkx as nx


ORDER = 26
BIPARTITION_SIZE = ORDER // 2
Edge = tuple[int, int]
Matching = frozenset[Edge]
sys.dont_write_bytecode = True

ORDER24_SCRIPT = (
    Path(__file__).resolve().parents[1]
    / "existence-lifting-order24"
    / "census_complete_family_existence_order24.py"
)


def load_module(path: Path, name: str):
    specification = importlib.util.spec_from_file_location(name, path)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


order24 = load_module(ORDER24_SCRIPT, "order26_wide_family_base")
source_bundle = order24.source_bundle
lift_bundle = order24.lift_bundle
edge = order24.edge
graph6 = order24.graph6
matching_from_colour = order24.matching_from_colour
primal_edge_by_dual_edge = order24.primal_edge_by_dual_edge
profile_record = order24.profile_record
GENERATOR_STATS: dict[str, object] = {}


def generated_graphs() -> Iterator[tuple[str, nx.Graph]]:
    generator = subprocess.Popen(
        (
            "genbg",
            "-cq",
            "-d3:3",
            "-D3:3",
            str(BIPARTITION_SIZE),
            str(BIPARTITION_SIZE),
        ),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    assert generator.stdout is not None and generator.stderr is not None
    planar_filter = subprocess.Popen(
        ("stdbuf", "-oL", "planarg"),
        stdin=generator.stdout,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    generator.stdout.close()
    assert planar_filter.stdout is not None and planar_filter.stderr is not None
    completed = False
    try:
        for line in planar_filter.stdout:
            source_graph6 = line.strip()
            if source_graph6:
                yield source_graph6, nx.from_graph6_bytes(source_graph6.encode())
        planar_filter_stderr = planar_filter.stderr.read()
        assert planar_filter.wait() == 0, planar_filter_stderr
        generator_stderr = generator.stderr.read()
        assert generator.wait() == 0, generator_stderr
        match = re.search(
            r">Z\s+(\d+) graphs read from stdin,\s+(\d+) written to stdout",
            planar_filter_stderr,
        )
        assert match is not None, planar_filter_stderr
        GENERATOR_STATS["generated_connected_cubic_bicoloured"] = int(
            match.group(1)
        )
        GENERATOR_STATS["planar"] = int(match.group(2))
        GENERATOR_STATS["planarg_stderr"] = planar_filter_stderr.strip()
        GENERATOR_STATS["geng_stderr"] = generator_stderr.strip()
        completed = True
    finally:
        planar_filter.stdout.close()
        if not completed:
            if planar_filter.poll() is None:
                planar_filter.terminate()
                planar_filter.wait()
            if generator.poll() is None:
                generator.terminate()
                generator.wait()


def legal_wide_splits(
    reduced: nx.Graph,
    rotations: dict[int, tuple[int, ...]],
    counts: Counter,
) -> tuple[dict[str, object], ...]:
    result = []
    for z in sorted(reduced):
        rotation = rotations[z]
        for first_index, second_index, first_gate, second_gate in lift_bundle.gate_pairs(
            rotation
        ):
            left_size = second_index - first_index + 1
            right_size = len(rotation) - (second_index - first_index) + 1
            if min(left_size, right_size) < 5:
                continue
            counts["wide_nonconsecutive_gate_pairs"] += 1
            if left_size % 2 == 0 or right_size % 2 == 0:
                continue
            counts["wide_odd_arc_gate_pairs"] += 1

            expanded, locals_, left_arc, right_arc = lift_bundle.split_vertex(
                reduced, z, rotation, first_index, second_index
            )
            if nx.number_of_selfloops(expanded):
                continue
            if any(degree % 2 for _, degree in expanded.degree()):
                continue
            planar, _embedding = nx.check_planarity(expanded)
            if not planar:
                continue
            pre_faces = lift_bundle.plane_faces(expanded)
            if any(len(face) != 3 for face in pre_faces):
                continue
            counts["wide_simple_eulerian_plane_triangulation_splits"] += 1

            expanded_faces = lift_bundle.expanded_triangulation_faces(expanded)
            if expanded_faces is None:
                continue
            counts["legal_wide_4connected_splits"] += 1
            result.append(
                {
                    "z": z,
                    "rotation": rotation,
                    "first_index": first_index,
                    "second_index": second_index,
                    "first_gate": first_gate,
                    "second_gate": second_gate,
                    "left_size": left_size,
                    "right_size": right_size,
                    "expanded": expanded,
                    "expanded_faces": expanded_faces,
                    "locals": locals_,
                    "left_arc": left_arc,
                    "right_arc": right_arc,
                }
            )
    return tuple(result)


def freeze_witness(
    source_graph6: str,
    primal: nx.Graph,
    primal_faces: tuple[tuple[int, ...], ...],
    reduced: nx.Graph,
    reduced_faces: tuple[tuple[int, ...], ...],
    split: dict[str, object],
    gate_edges: tuple[Edge, Edge],
    root: Edge,
    primal_root: Edge,
    colours: tuple[dict[int, int], ...],
    matchings: tuple[Matching, ...],
) -> dict[str, object]:
    z = int(split["z"])
    expanded = split["expanded"]
    expanded_faces = split["expanded_faces"]
    locals_ = split["locals"]
    assert isinstance(expanded, nx.Graph)
    assert isinstance(expanded_faces, tuple)
    assert isinstance(locals_, tuple)
    expanded_dual = lift_bundle.dual_from_plane_graph(expanded, expanded_faces)

    targets = []
    family_contains_lift = False
    for index, (colour, matching) in enumerate(
        zip(colours, matchings, strict=True)
    ):
        assert set(gate_edges) <= set(matching)
        fixed = {vertex: value for vertex, value in colour.items() if vertex != z}
        assignments = []
        lift_rows = []
        for bits in product((0, 1), repeat=3):
            lifted = {**fixed, **dict(zip(locals_, bits, strict=True))}
            profile = lift_bundle.rooted_profile(
                expanded, expanded_faces, lifted, root
            )
            normalized = tuple(bit ^ colour[z] for bit in bits)
            record = profile_record(bits, normalized, profile)
            assignments.append(record)
            if record["target"]:
                lift_rows.append("".join(map(str, normalized)))
        family_contains_lift |= bool(lift_rows)
        reduced_profile = lift_bundle.rooted_profile(
            reduced, reduced_faces, colour, root
        )
        assert lift_bundle.is_target_profile(reduced_profile)
        targets.append(
            {
                "family_index": index,
                "zero_vertices": sorted(
                    vertex for vertex, value in colour.items() if value == 0
                ),
                "one_vertices": sorted(
                    vertex for vertex, value in colour.items() if value == 1
                ),
                "matching": sorted(matching),
                "gate_count": sum(gate in matching for gate in gate_edges),
                "reduced_rooted_profile": {
                    "nae": reduced_profile[0],
                    "components": reduced_profile[1],
                    "cycle_rank": reduced_profile[2],
                    "root_on_cycle": reduced_profile[3],
                },
                "lift_rows_normalized": lift_rows,
                "all_eight_assignments": assignments,
            }
        )

    witness_kind = (
        "wide_gate_escape_counterexample_but_ordinary_lifting_survives"
        if family_contains_lift
        else "wide_gate_escape_and_ordinary_lifting_counterexample"
    )
    return {
        "witness_kind": witness_kind,
        "source_order": ORDER,
        "source_graph6": source_graph6,
        "source_primal_edges": sorted(edge(*item) for item in primal.edges()),
        "source_primal_faces": primal_faces,
        "reduced_triangulation_graph6": graph6(reduced),
        "reduced_triangulation_edges": sorted(
            edge(*item) for item in reduced.edges()
        ),
        "expanded_triangulation_graph6": graph6(expanded),
        "expanded_triangulation_edges": sorted(
            edge(*item) for item in expanded.edges()
        ),
        "expanded_triangulation_faces": expanded_faces,
        "expanded_dual_graph6": graph6(expanded_dual),
        "expanded_dual_edges": sorted(
            edge(*item) for item in expanded_dual.edges()
        ),
        "reduced_dual_brace_check": lift_bundle.verify_brace(primal),
        "expanded_dual_brace_check": lift_bundle.verify_brace(expanded_dual),
        "site": {
            "split_vertex": z,
            "rotation": split["rotation"],
            "gate_indices": (split["first_index"], split["second_index"]),
            "gate_vertices": (split["first_gate"], split["second_gate"]),
            "primal_gate_edges": gate_edges,
            "closed_arc_cardinalities": (
                split["left_size"],
                split["right_size"],
            ),
            "left_arc": split["left_arc"],
            "right_arc": split["right_arc"],
            "left_right_centre": locals_,
        },
        "dual_root": root,
        "primal_root": primal_root,
        "complete_target_family_size_mod_complement": len(matchings),
        "complete_target_family_forces_both_gates": True,
        "complete_target_family_contains_liftable_target": family_contains_lift,
        "complete_target_family": targets,
    }


def analyse_brace(
    source_graph6: str,
    primal: nx.Graph,
    primal_faces: tuple[tuple[int, ...], ...],
) -> tuple[dict[str, object], dict[str, object] | None]:
    reduced, rotations = lift_bundle.dual_from_primal_faces(primal, primal_faces)
    reduced_faces = lift_bundle.verify_reduced_triangulation(reduced)
    counts: Counter = Counter({"wide_forced_complete_families": 0})
    splits = legal_wide_splits(reduced, rotations, counts)
    if not splits:
        return {
            "source_order": ORDER,
            "source_graph6": source_graph6,
            "dual_vertices": reduced.number_of_nodes(),
            **dict(sorted(counts.items())),
        }, None

    counts["braces_with_legal_wide_split"] = 1
    families, nae_count, target_shape_count = lift_bundle.target_families(
        reduced, reduced_faces
    )
    reduced_vertices = tuple(sorted(reduced))
    dual_to_primal = primal_edge_by_dual_edge(primal, primal_faces)
    counts.update(
        {
            "braces_with_target_family_enumeration": 1,
            "colour_classes_mod_complement": 1 << (len(reduced_vertices) - 1),
            "nae_colourings_mod_complement": nae_count,
            "target_shape_colourings_mod_complement": target_shape_count,
            "root_target_pairs_mod_complement": sum(map(len, families.values())),
        }
    )

    family_cache: dict[
        Edge, tuple[tuple[dict[int, int], ...], tuple[Matching, ...]]
    ] = {}
    for root, encoded_family in families.items():
        colours = tuple(
            lift_bundle.decode_colouring(reduced_vertices, encoded)
            for encoded in encoded_family
        )
        matchings = tuple(
            matching_from_colour(primal, reduced, dual_to_primal, colour)
            for colour in colours
        )
        assert len(matchings) == len(set(matchings))
        assert all(dual_to_primal[root] in matching for matching in matchings)
        family_cache[root] = colours, matchings

    for split in splits:
        z = int(split["z"])
        first_gate = int(split["first_gate"])
        second_gate = int(split["second_gate"])
        gate_edges = (
            dual_to_primal[edge(z, first_gate)],
            dual_to_primal[edge(z, second_gate)],
        )
        assert gate_edges[0] != gate_edges[1]
        surviving_roots = tuple(root for root in sorted(families) if z not in root)
        counts["wide_target_interfaces"] += len(surviving_roots)

        for root in surviving_roots:
            colours, matchings = family_cache[root]
            gate_counts = tuple(
                sum(gate in matching for gate in gate_edges)
                for matching in matchings
            )
            counts["wide_target_instances"] += len(matchings)
            if any(gate_count <= 1 for gate_count in gate_counts):
                counts["wide_complete_families_with_gate_escape"] += 1
                continue

            assert all(gate_count == 2 for gate_count in gate_counts)
            counts["wide_forced_complete_families"] += 1
            counts["targets_in_first_wide_forced_family"] = len(matchings)
            witness = freeze_witness(
                source_graph6,
                primal,
                primal_faces,
                reduced,
                reduced_faces,
                split,
                gate_edges,
                root,
                dual_to_primal[root],
                colours,
                matchings,
            )
            return {
                "source_order": ORDER,
                "source_graph6": source_graph6,
                "dual_vertices": reduced.number_of_nodes(),
                **dict(sorted(counts.items())),
            }, witness

    assert counts["wide_forced_complete_families"] == 0
    return {
        "source_order": ORDER,
        "source_graph6": source_graph6,
        "dual_vertices": reduced.number_of_nodes(),
        **dict(sorted(counts.items())),
    }, None


def add_counts(totals: Counter, record: dict[str, object]) -> None:
    for key, value in record.items():
        if key in {"source_order", "source_graph6", "dual_vertices"}:
            continue
        assert isinstance(value, int)
        totals[key] += value


def search() -> dict[str, object]:
    source_counts: Counter = Counter()
    totals: Counter = Counter()
    brace_records = []
    first_witness = None
    seen_uncoloured_planar: list[nx.Graph] = []
    seen_uncoloured_multiplicities: list[int] = []

    stream = generated_graphs()
    try:
        for source_graph6, primal in stream:
            assert primal.number_of_nodes() == ORDER
            assert nx.number_of_selfloops(primal) == 0
            assert nx.is_connected(primal) and nx.is_bipartite(primal)
            assert set(dict(primal.degree()).values()) == {3}

            planar, embedding = nx.check_planarity(primal)
            assert planar
            source_counts["planar_bicoloured_representatives"] += 1
            duplicate_index = next(
                (
                    index
                    for index, previous in enumerate(seen_uncoloured_planar)
                    if nx.is_isomorphic(primal, previous)
                ),
                None,
            )
            if duplicate_index is not None:
                seen_uncoloured_multiplicities[duplicate_index] += 1
                assert seen_uncoloured_multiplicities[duplicate_index] <= 2
                source_counts["side_swap_duplicate_planar_representatives"] += 1
                continue
            seen_uncoloured_planar.append(primal.copy())
            seen_uncoloured_multiplicities.append(1)
            source_counts["planar_uncoloured_representatives"] += 1
            assert isinstance(embedding, nx.PlanarEmbedding)
            primal_faces = source_bundle.plane_faces(primal, embedding)
            if nx.node_connectivity(primal) >= 3:
                source_counts["planar_three_connected"] += 1

            direct = source_bundle.is_two_extendable_direct(primal)
            strict_hall = source_bundle.strict_hall_two_extendable(primal)
            assert direct == strict_hall
            if not direct:
                continue
            source_counts["plane_braces"] += 1
            record, witness = analyse_brace(source_graph6, primal, primal_faces)
            brace_records.append(record)
            add_counts(totals, record)
            print(json.dumps(record, sort_keys=True), flush=True)
            if witness is not None:
                first_witness = witness
                break
    finally:
        stream.close()

    complete_source_coverage = first_witness is None
    if complete_source_coverage:
        assert GENERATOR_STATS["generated_connected_cubic_bicoloured"] > 0
        source_counts["generated_connected_cubic_bicoloured"] = int(
            GENERATOR_STATS["generated_connected_cubic_bicoloured"]
        )
        assert (
            source_counts["planar_bicoloured_representatives"]
            == GENERATOR_STATS["planar"]
        )
    if first_witness is None:
        status = "wide_gate_escape_verified_at_reduced_order_26"
        statement = (
            "For every order-26 simple plane cubic bipartite brace, every "
            "legal two-gate site whose two closed arcs both have cardinality "
            "at least five, and every nonempty unchanged-root complete target "
            "family, some target uses at most one gate."
        )
        unresolved = "Reduced order 28 and above; no arbitrary-order proof."
    elif first_witness[
        "complete_target_family_contains_liftable_target"
    ]:
        status = "first_wide_forced_family_found_but_ordinary_lifting_survives"
        statement = (
            "The first frozen order-26 witness refutes wide gate escape: its "
            "nonempty complete target family forces both gates.  At least one "
            "target nevertheless lifts through a nonneutral local row."
        )
        unresolved = (
            "Whether ordinary wide-site family lifting always holds; later "
            "order-26 generator inputs were not searched after the first WGE witness."
        )
    else:
        status = "ordinary_wide_site_lifting_counterexample_at_reduced_order_26"
        statement = (
            "The first frozen order-26 wide complete target family forces both "
            "gates and none of its targets lifts."
        )
        unresolved = (
            "Later order-26 generator inputs and larger orders were not searched "
            "after the first ordinary lifting failure."
        )

    return {
        "status": status,
        "statement": statement,
        "trusted_coverage_boundary": {
            "order": ORDER,
            "generator_command": "genbg -cq -d3:3 -D3:3 13 13",
            "planarity_prefilter_command": "stdbuf -oL planarg",
            "genbg_path": shutil.which("genbg"),
            "networkx_version": nx.__version__,
            "external_interfaces": [
                "nauty genbg colour-preserving isomorph-free generation",
                "nauty planarg exact planarity prefilter",
                "NetworkX exact planarity decisions",
                "NetworkX exact uncoloured-isomorphism removal on planar outputs",
            ],
            "uncoloured_coverage_argument": (
                "Every connected bipartite graph has a unique bipartition up "
                "to exchanging its two sides; hence the 13+13 bicoloured "
                "representatives cover every uncoloured order-26 cubic "
                "bipartite graph, with multiplicity at most two."
            ),
            "direct_checks_after_planarity": [
                "independent-two-edge extension",
                "strict-Hall brace criterion",
                "legal wide split reconstruction and expanded 4-connectivity",
                "complete reduced target-family enumeration modulo global colour complement",
                "complete two-gate load test in every wide target family",
                "all eight local rows of every target if a first forced family is found",
            ],
            "complete_source_coverage": complete_source_coverage,
        },
        "source_counts": dict(sorted(source_counts.items())),
        "coverage_before_stop": dict(sorted(totals.items())),
        "brace_graph6_before_stop": [
            record["source_graph6"] for record in brace_records
        ],
        "by_brace_before_stop": brace_records,
        "first_witness": first_witness,
        "unresolved_boundary": unresolved,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    payload = search()
    rendered = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.write_text(rendered)
        print("certificate", arguments.output)
    print(json.dumps(payload["source_counts"], sort_keys=True))
    print(json.dumps(payload["coverage_before_stop"], sort_keys=True))
    print(payload["status"].upper())


if __name__ == "__main__":
    main()
