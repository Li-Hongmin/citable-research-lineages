#!/usr/bin/env python3
"""Standalone certificate for the sharp order-16 carrier and M=1 boundary.

Dependencies: Python standard library and NetworkX only.  In particular,
this file imports no AIMath scratch module.  It independently enumerates
perfect matchings, carrier boundary rows, compatible clean joins, and all
mandatory four-row crossing slots.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations, combinations_with_replacement, product

import networkx as nx


Edge = tuple[int, int]
Matching = frozenset[Edge]
State = frozenset[int]

GRAPH6 = "O????B_sDOI_I_DO@W?M?"
ROOT_SQUARE = (8, 2, 10, 0)
ROOT = (2, 8)
FORCED = (0, 10)
SURVIVING = (7, 13)
CUT_FACE = (5, 13, 7, 15)
PORTS = CUT_FACE

EMPTY = frozenset()
OMEGA = frozenset((0, 1, 2, 3))
A0 = frozenset((0, 1))
A1 = frozenset((1, 2))
A2 = frozenset((2, 3))
A3 = frozenset((0, 3))
STATES = (EMPTY, OMEGA, A0, A1, A2, A3)

FACTOR_ROWS = {
    "N0": (EMPTY, (frozenset((0, 1)), frozenset((2, 3)))),
    "N1": (A0, (frozenset((2, 3)),)),
    "R1": (A1, (frozenset((0, 3)),)),
    "R3": (A3, (frozenset((1, 2)),)),
}
ONE_PATH_FACTOR_ATOMS = {
    frozenset(("N0", "N1")): frozenset((0, 1)),
    frozenset(("N0", "R1")): frozenset((1, 2)),
    frozenset(("N0", "R3")): frozenset((0, 3)),
    frozenset(("N1", "R1")): frozenset((0, 2)),
    frozenset(("N1", "R3")): frozenset((1, 3)),
}
R1_R3_FACTOR_PAIRING = frozenset(
    (frozenset((1, 2)), frozenset((0, 3)))
)
REQUIRED_ROOT_PAIRS = frozenset(
    (frozenset((0, 3)), frozenset((1, 2)))
)


def edge(left: int, right: int) -> Edge:
    return tuple(sorted((left, right)))


ROOT = edge(*ROOT)
FORCED = edge(*FORCED)
SURVIVING = edge(*SURVIVING)


def matching(items: tuple[tuple[int, int], ...]) -> Matching:
    return frozenset(edge(*item) for item in items)


NAMED_ROWS = {
    "K2": matching(
        ((0, 10), (1, 9), (3, 11), (4, 12), (7, 13), (6, 14), (5, 15), (2, 8))
    ),
    "K10": matching(
        ((0, 10), (1, 9), (3, 11), (4, 12), (7, 14), (6, 15), (2, 8))
    ),
    "K11": matching(
        ((0, 10), (1, 11), (4, 12), (6, 14), (5, 15), (2, 8), (3, 9))
    ),
    "K14": matching(
        ((0, 10), (1, 9), (3, 11), (6, 12), (4, 14), (5, 15), (2, 8))
    ),
    "K17": matching(
        ((0, 10), (1, 11), (4, 12), (7, 13), (6, 14), (2, 8), (3, 9))
    ),
    "K20": matching(
        ((0, 10), (1, 9), (3, 11), (6, 12), (7, 13), (4, 14), (2, 8))
    ),
}
ROW_NAME = {value: key for key, value in NAMED_ROWS.items()}
assert len(ROW_NAME) == len(NAMED_ROWS)


def plane_faces(graph: nx.Graph) -> tuple[tuple[int, ...], ...]:
    planar, embedding = nx.check_planarity(graph, counterexample=True)
    assert planar and isinstance(embedding, nx.PlanarEmbedding)
    visited = set()
    result = []
    for left, right in embedding.edges():
        if (left, right) not in visited:
            result.append(tuple(embedding.traverse_face(left, right, visited)))
    return tuple(result)


def face_edges(face: tuple[int, ...]) -> frozenset[Edge]:
    return frozenset(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def enumerate_matchings(
    graph: nx.Graph,
    removed: frozenset[int] = frozenset(),
    required: Matching = frozenset(),
) -> tuple[Matching, ...]:
    assert all(graph.has_edge(*item) for item in required)
    assert not any(set(item) & set(removed) for item in required)
    used = {vertex for item in required for vertex in item}
    assert len(used) == 2 * len(required)
    vertices = tuple(sorted(set(graph) - set(removed) - used))
    position = {vertex: index for index, vertex in enumerate(vertices)}
    neighbours = [0] * len(vertices)
    for left, right in graph.edges():
        if left in position and right in position:
            neighbours[position[left]] |= 1 << position[right]
            neighbours[position[right]] |= 1 << position[left]

    @lru_cache(maxsize=None)
    def solve(mask: int):
        if not mask:
            return ((),)
        candidates = [index for index in range(len(vertices)) if mask >> index & 1]
        first = min(
            candidates,
            key=lambda index: ((neighbours[index] & mask).bit_count(), index),
        )
        choices = neighbours[first] & mask
        remainder = mask ^ (1 << first)
        rows = []
        while choices:
            bit = choices & -choices
            choices ^= bit
            second = bit.bit_length() - 1
            for suffix in solve(remainder ^ bit):
                rows.append(((first, second),) + suffix)
        return tuple(rows)

    encoded = solve((1 << len(vertices)) - 1)
    return tuple(
        required
        | frozenset(edge(vertices[left], vertices[right]) for left, right in row)
        for row in encoded
    )


def verify_brace(graph: nx.Graph) -> tuple[Matching, ...]:
    perfect_matchings = enumerate_matchings(graph)
    independent_pairs = tuple(
        (edge(*first), edge(*second))
        for first, second in combinations(graph.edges(), 2)
        if set(first).isdisjoint(second)
    )
    assert all(
        any(first in item and second in item for item in perfect_matchings)
        for first, second in independent_pairs
    )
    assert nx.node_connectivity(graph) >= 3
    return perfect_matchings


def c4_expand(
    graph: nx.Graph, u: int, v: int, x: int, y: int
) -> nx.Graph:
    assert graph.has_edge(u, v) and graph.has_edge(x, y)
    assert len({u, v, x, y}) == 4
    result = graph.copy()
    result.remove_edges_from((edge(u, v), edge(x, y)))
    a, b, c, d = range(max(result) + 1, max(result) + 5)
    result.add_edges_from(
        ((u, a), (a, b), (b, v), (x, c), (c, d), (d, y), (a, d), (b, c))
    )
    return result


def root_attachments(graph: nx.Graph) -> tuple[int, ...]:
    square = set(ROOT_SQUARE)
    result = []
    for vertex in ROOT_SQUARE:
        outside = [neighbour for neighbour in graph[vertex] if neighbour not in square]
        assert len(outside) == 1
        result.append(outside[0])
    assert len(set(result)) == 4
    return tuple(result)


def complement_profile(
    cut: nx.Graph, attachments: tuple[int, ...], row_matching: Matching
):
    residual = cut.subgraph(set(cut) - set(ROOT_SQUARE)).copy()
    residual.remove_edges_from(row_matching)
    components = []
    for vertices in nx.connected_components(residual):
        component = residual.subgraph(vertices)
        degrees = tuple(dict(component.degree()).values())
        ports = frozenset(
            index for index, vertex in enumerate(PORTS) if vertex in vertices
        )
        roots = frozenset(
            index for index, vertex in enumerate(attachments) if vertex in vertices
        )
        if degrees and all(value == 2 for value in degrees):
            kind = "cycle"
        elif degrees and all(value in {1, 2} for value in degrees):
            kind = "path"
        else:
            return None
        components.append((kind, ports, roots))
    return tuple(
        sorted(components, key=lambda item: (item[0], tuple(item[1]), tuple(item[2])))
    )


def factor_join_passes(profile, state: State, factor_pairs) -> bool:
    if profile is None or any(kind == "cycle" for kind, _ports, _roots in profile):
        return False
    auxiliary = nx.Graph()
    marks = {}
    for index, (_kind, _ports, roots) in enumerate(profile):
        name = ("carrier", index)
        auxiliary.add_node(name)
        marks[name] = set(roots)
    for index, pair in enumerate(factor_pairs):
        name = ("factor", index)
        auxiliary.add_node(name)
        marks[name] = set()
        for port in pair:
            owners = [
                ("carrier", ordinal)
                for ordinal, (_kind, ports, _roots) in enumerate(profile)
                if port in ports
            ]
            if len(owners) != 1:
                return False
            auxiliary.add_edge(name, owners[0])
    covered = set().union(*(set(pair) for pair in factor_pairs))
    if covered != set(range(4)) - set(state):
        return False
    root_pairs = frozenset(
        frozenset().union(*(marks[vertex] for vertex in vertices))
        for vertices in nx.connected_components(auxiliary)
    )
    return root_pairs == REQUIRED_ROOT_PAIRS


@dataclass(frozen=True)
class Row:
    state: State
    matching: Matching
    profile: tuple


def carrier_rows(graph: nx.Graph) -> tuple[nx.Graph, tuple[Row, ...]]:
    cut = graph.copy()
    cut.remove_edges_from((edge(PORTS[0], PORTS[1]), edge(PORTS[2], PORTS[3])))
    required = frozenset((ROOT, FORCED))
    attachments = root_attachments(graph)
    rows = []
    for state in STATES:
        removed = frozenset(PORTS[index] for index in state)
        for item in enumerate_matchings(cut, removed, required):
            profile = complement_profile(cut, attachments, item)
            if profile is not None:
                rows.append(Row(state, item, profile))
    return cut, tuple(rows)


def bond_atom(cut: nx.Graph, first: Row, second: Row):
    difference = first.matching ^ second.matching
    if not difference:
        return (), 0
    difference_graph = nx.edge_subgraph(cut, difference).copy()
    paths = []
    cycles = 0
    for vertices in nx.connected_components(difference_graph):
        component = difference_graph.subgraph(vertices)
        ends = [vertex for vertex, degree in component.degree() if degree == 1]
        if not ends:
            if set(dict(component.degree()).values()) != {2}:
                return None
            cycles += 1
        else:
            if len(ends) != 2:
                return None
            marks = frozenset(
                index for index, vertex in enumerate(PORTS) if vertex in ends
            )
            if len(marks) != 2:
                return None
            paths.append(marks)
    expected = set(first.state ^ second.state)
    actual = set().union(*(set(path) for path in paths)) if paths else set()
    if actual != expected:
        return None
    return tuple(sorted(paths, key=tuple)), cycles


def joined_is_one_cycle(left: str, right: str, atom) -> bool:
    if atom is None:
        return False
    paths, closed = atom
    if left == right:
        return paths == () and closed == 1
    if closed:
        return False
    labels = frozenset((left, right))
    if labels in ONE_PATH_FACTOR_ATOMS:
        return len(paths) == 1 and paths[0] == ONE_PATH_FACTOR_ATOMS[labels]
    assert labels == frozenset(("R1", "R3"))
    pairing = frozenset(paths)
    return len(paths) == 2 and pairing != R1_R3_FACTOR_PAIRING


def mandatory_slots(cut: nx.Graph, compatible, sectors):
    labels = tuple(FACTOR_ROWS)
    slots = []
    for left_label, right_label in combinations_with_replacement(labels, 2):
        candidates = (
            combinations(compatible[left_label], 2)
            if left_label == right_label
            else product(compatible[left_label], compatible[right_label])
        )
        for left, right in candidates:
            if sectors[left.matching] == sectors[right.matching]:
                continue
            atom = bond_atom(cut, left, right)
            if joined_is_one_cycle(left_label, right_label, atom):
                slots.append(
                    (
                        f"{left_label}-{right_label}",
                        ROW_NAME[left.matching],
                        ROW_NAME[right.matching],
                        (sectors[left.matching], sectors[right.matching]),
                        atom,
                    )
                )
    return tuple(slots)


def main() -> None:
    graph = nx.from_graph6_bytes(GRAPH6.encode())
    assert len(graph) == 16 and graph.number_of_edges() == 24
    assert nx.number_of_selfloops(graph) == 0 and nx.is_connected(graph)
    assert set(dict(graph.degree()).values()) == {3}
    assert nx.is_bipartite(graph)
    faces = plane_faces(graph)
    assert face_edges(ROOT_SQUARE) in {face_edges(face) for face in faces}
    assert face_edges(CUT_FACE) in {face_edges(face) for face in faces}
    assert set(ROOT_SQUARE).isdisjoint(CUT_FACE)
    assert ROOT in face_edges(ROOT_SQUARE) and FORCED in face_edges(ROOT_SQUARE)
    assert set(ROOT).isdisjoint(FORCED)

    perfect_matchings = verify_brace(graph)
    assert len(perfect_matchings) == 49
    independent_pairs = sum(
        set(first).isdisjoint(second)
        for first, second in combinations(graph.edges(), 2)
    )
    assert independent_pairs == 228

    gate_faces = [
        face for face in faces if {FORCED, SURVIVING} <= face_edges(face)
    ]
    assert len(gate_faces) == 1
    gate_face = gate_faces[0]
    boundary = tuple(
        edge(gate_face[index], gate_face[(index + 1) % len(gate_face)])
        for index in range(len(gate_face))
    )
    first = boundary.index(FORCED)
    second = boundary.index(SURVIVING)
    delta = (second - first) % len(boundary)
    assert sorted((delta + 1, len(boundary) - delta + 1)) == [5, 5]

    # The common-face order is 0,10,...,7,13,... .  Its standard C4
    # expansion is again a simple 3-connected cubic bipartite plane graph.
    child = c4_expand(graph, 0, 10, 7, 13)
    assert len(child) == 20 and child.number_of_edges() == 30
    assert nx.number_of_selfloops(child) == 0 and nx.is_connected(child)
    assert set(dict(child.degree()).values()) == {3}
    assert nx.is_bipartite(child) and nx.check_planarity(child)[0]
    assert nx.node_connectivity(child) >= 3
    # For a plane cubic bipartite graph this brace check is the primal
    # counterpart of the inverse dual split remaining 4-connected.
    assert len(verify_brace(child)) == 89

    cut, rows = carrier_rows(graph)
    assert len(rows) == 21
    assert Counter(row.state for row in rows) == Counter(
        {EMPTY: 5, OMEGA: 4, A0: 2, A1: 4, A2: 2, A3: 4}
    )
    compatible = {}
    for label, (state, factor_pairs) in FACTOR_ROWS.items():
        compatible[label] = tuple(
            row
            for row in rows
            if row.state == state
            and factor_join_passes(row.profile, state, factor_pairs)
        )
    assert {
        label: frozenset(ROW_NAME[row.matching] for row in values)
        for label, values in compatible.items()
    } == {
        "N0": frozenset(("K2",)),
        "N1": frozenset(("K10",)),
        "R1": frozenset(("K11", "K14")),
        "R3": frozenset(("K17", "K20")),
    }
    sectors = {
        row.matching: int(SURVIVING in row.matching)
        for values in compatible.values()
        for row in values
    }
    assert {name: sectors[item] for name, item in NAMED_ROWS.items()} == {
        "K2": 1,
        "K10": 0,
        "K11": 0,
        "K14": 0,
        "K17": 1,
        "K20": 1,
    }

    slots = mandatory_slots(cut, compatible, sectors)
    assert slots == (
        ("N0-N1", "K2", "K10", (1, 0), ((frozenset((0, 1)),), 0)),
        ("N1-R3", "K10", "K20", (0, 1), ((frozenset((1, 3)),), 0)),
    )

    restricted = {
        label: tuple(row for row in values if row.matching != NAMED_ROWS["K20"])
        for label, values in compatible.items()
    }
    restricted_slots = mandatory_slots(cut, restricted, sectors)
    assert restricted_slots == (slots[0],)
    assert NAMED_ROWS["K20"] in {row.matching for row in compatible["R3"]}
    assert all(
        mandatory_slots(
            cut,
            {
                label: tuple(
                    row for row in values if row.matching != NAMED_ROWS[other]
                )
                for label, values in compatible.items()
            },
            sectors,
        )
        == slots
        for other in ("K11", "K14", "K17")
    )

    print("ORDER16_CARRIER_M2_AND_NEAR_M1_STANDALONE_VERIFIED")


if __name__ == "__main__":
    main()

