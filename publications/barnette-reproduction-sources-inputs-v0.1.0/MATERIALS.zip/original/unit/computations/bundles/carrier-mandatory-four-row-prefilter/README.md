# Carrier mandatory four-row prefilter

This bundle verifies the finite sharpness and boundary claims in
[Note 160](../../../notes/160-four-mandatory-boundary-rows-give-an-exact-carrier-prefilter.md).
The ten-term prefilter formula is analytic and appears in the note.

From the AIMath root, run

    uv run --python 3.14 --with 'networkx==3.6.1' \
      units/barnette/computations/bundles/carrier-mandatory-four-row-prefilter/verify_order16_carrier_m2_and_near_m1.py

The verified environment on 2026-08-29 was Python 3.14.6 with NetworkX
3.6.1. The terminal marker is

    ORDER16_CARRIER_M2_AND_NEAR_M1_STANDALONE_VERIFIED

The standalone verifier reconstructs the order-16 graph from its graph6
string and imports no AIMath module. It checks simplicity, planarity,
cubicity, bipartiteness, the facial root and cut squares, legal-wide gate
arc sizes, all 49 perfect matchings, extension of all 228 independent edge
pairs, and the standard C4-expanded child's brace property via all 89 child
perfect matchings. It then reconstructs all 21 carrier boundary rows and
their rooted-compatible clean joins with the four factor rows. The complete
family has exactly the two mandatory crossings stated in the note; deleting
the single actual compatible row K20 leaves exactly the designated crossing,
whereas deleting any of K11, K14, or K17 does not.

The final deletion is an abstract restriction of an actual perfect-matching
family. The verifier does not claim that the restricted row family is a
complete carrier or that a true mandatory-count-one carrier exists.
