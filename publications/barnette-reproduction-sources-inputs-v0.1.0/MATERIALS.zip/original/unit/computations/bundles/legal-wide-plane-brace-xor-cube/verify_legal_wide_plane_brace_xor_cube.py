#!/usr/bin/env python3
"""Verify the legal-wide plane-brace lift and its complete residual fibre."""

from __future__ import annotations

from collections import Counter, deque
from itertools import combinations, product

import networkx as nx


Vertex = str
Edge = frozenset[Vertex]
Matching = frozenset[Edge]


def edge(left: Vertex, right: Vertex) -> Edge:
    assert left != right
    return frozenset((left, right))


def cycle_edges(vertices: tuple[Vertex, ...]) -> frozenset[Edge]:
    return frozenset(
        edge(vertices[index], vertices[(index + 1) % len(vertices)])
        for index in range(len(vertices))
    )


def path_edges(vertices: tuple[Vertex, ...]) -> frozenset[Edge]:
    return frozenset(
        edge(vertices[index], vertices[index + 1])
        for index in range(len(vertices) - 1)
    )


def smoothing(vertices: tuple[Vertex, ...], state: int) -> frozenset[Edge]:
    return frozenset(
        edge(
            vertices[(2 * index + state) % len(vertices)],
            vertices[(2 * index + 1 + state) % len(vertices)],
        )
        for index in range(len(vertices) // 2)
    )


def graph_from(vertices: frozenset[Vertex], edges: frozenset[Edge]) -> nx.Graph:
    graph = nx.Graph()
    graph.add_nodes_from(vertices)
    graph.add_edges_from(tuple(item) for item in edges)
    return graph


def enumerate_perfect_matchings(
    vertices: frozenset[Vertex], edges: frozenset[Edge]
) -> tuple[Matching, ...]:
    adjacency = {vertex: set() for vertex in vertices}
    for item in edges:
        left, right = tuple(item)
        adjacency[left].add(right)
        adjacency[right].add(left)

    result: list[Matching] = []

    def recurse(unmatched: frozenset[Vertex], chosen: tuple[Edge, ...]) -> None:
        if not unmatched:
            result.append(frozenset(chosen))
            return
        vertex = min(
            unmatched,
            key=lambda item: (
                sum(neighbour in unmatched for neighbour in adjacency[item]),
                item,
            ),
        )
        for neighbour in sorted(adjacency[vertex] & unmatched):
            recurse(
                unmatched - {vertex, neighbour},
                chosen + (edge(vertex, neighbour),),
            )

    recurse(vertices, ())
    assert len(result) == len(set(result))
    return tuple(result)


def perfect(
    vertices: frozenset[Vertex], edges: frozenset[Edge], matching: Matching
) -> bool:
    used = Counter(vertex for item in matching for vertex in item)
    return (
        matching <= edges
        and set(used) == set(vertices)
        and set(used.values()) == {1}
    )


def complement_profile(
    matching: Matching,
) -> tuple[frozenset[frozenset[Vertex]], int] | None:
    complement = RESIDUAL_EDGES - matching
    adjacency = {vertex: set() for vertex in RESIDUAL_VERTICES}
    for item in complement:
        left, right = tuple(item)
        adjacency[left].add(right)
        adjacency[right].add(left)
    if any(len(adjacency[vertex]) not in (1, 2) for vertex in RESIDUAL_VERTICES):
        return None

    unseen = set(RESIDUAL_VERTICES)
    pairs: set[frozenset[Vertex]] = set()
    closed = 0
    while unseen:
        root = min(unseen)
        component = {root}
        queue = deque((root,))
        while queue:
            vertex = queue.popleft()
            for neighbour in adjacency[vertex] - component:
                component.add(neighbour)
                queue.append(neighbour)
        unseen -= component
        endpoints = {vertex for vertex in component if len(adjacency[vertex]) == 1}
        if not endpoints:
            closed += 1
        elif len(endpoints) == 2 and endpoints <= set(TERMINALS):
            pairs.add(frozenset(endpoints))
        else:
            return None
    return frozenset(pairs), closed


def delta_component_count(first: Matching, second: Matching) -> int:
    difference = first ^ second
    graph = nx.Graph()
    graph.add_edges_from(tuple(item) for item in difference)
    assert difference and all(degree == 2 for _, degree in graph.degree())
    return nx.number_connected_components(graph)


def plane_faces(embedding: nx.PlanarEmbedding) -> tuple[tuple[Vertex, ...], ...]:
    seen: set[tuple[Vertex, Vertex]] = set()
    faces = []
    for left, right in embedding.edges():
        if (left, right) not in seen:
            faces.append(tuple(embedding.traverse_face(left, right, seen)))
    return tuple(faces)


def face_edges(face: tuple[Vertex, ...]) -> tuple[Edge, ...]:
    return tuple(
        edge(face[index], face[(index + 1) % len(face)])
        for index in range(len(face))
    )


def cyclic_equal(first: tuple[Vertex, ...], second: tuple[Vertex, ...]) -> bool:
    if len(first) != len(second):
        return False
    reverse = tuple(reversed(first))
    return any(
        second == (candidate + candidate)[index:index + len(first)]
        for candidate in (first, reverse)
        for index in range(len(first))
    )


A = tuple(f"a{index}" for index in range(4))
B = tuple(f"b{index}" for index in range(12))
TERMINALS = ("t0", "t1", "t2", "t3")
X = ("x0", "x1", "x2", "x3", "x5", "x7", "x8", "x9")
RESIDUAL_VERTICES = frozenset(A + B + TERMINALS + X)

COMMON_PATHS = (
    ("t0", "x0", "b1"),
    ("b0", "x1", "b10"),
    ("b11", "x2", "a0"),
    ("a1", "x3", "b2"),
    ("b3", "t1"),
    ("t2", "x5", "b5"),
    ("b4", "a2"),
    ("a3", "x7", "b6"),
    ("b7", "x8", "b9"),
    ("b8", "x9", "t3"),
)
K = frozenset(
    edge(*item)
    for item in (
        ("x0", "x1"),
        ("x2", "x3"),
        ("x7", "x8"),
        ("x5", "x9"),
        ("t0", "t1"),
        ("t2", "t3"),
    )
)
residual_edges = set(cycle_edges(A) | cycle_edges(B) | K)
for path in COMMON_PATHS:
    residual_edges.update(path_edges(path))
RESIDUAL_EDGES = frozenset(residual_edges)

assert len(RESIDUAL_VERTICES) == 28 and len(RESIDUAL_EDGES) == 40
RESIDUAL_GRAPH = graph_from(RESIDUAL_VERTICES, RESIDUAL_EDGES)
assert nx.is_connected(RESIDUAL_GRAPH) and nx.is_bipartite(RESIDUAL_GRAPH)
assert {vertex for vertex, degree in RESIDUAL_GRAPH.degree() if degree == 2} == set(
    TERMINALS
)

I = frozenset(
    (frozenset(("t0", "t1")), frozenset(("t2", "t3")))
)
E = frozenset(
    (frozenset(("t0", "t3")), frozenset(("t1", "t2")))
)
CUBE = {
    (i, j): K | smoothing(A, 1 - i) | smoothing(B, 1 - j)
    for i, j in product((0, 1), repeat=2)
}
assert all(
    perfect(RESIDUAL_VERTICES, RESIDUAL_EDGES, matching)
    for matching in CUBE.values()
)
assert {
    state: complement_profile(matching) for state, matching in CUBE.items()
} == {
    (0, 0): (I, 0),
    (1, 0): (E, 0),
    (0, 1): (E, 0),
    (1, 1): (I, 0),
}
assert CUBE[(0, 0)] ^ CUBE[(1, 1)] == cycle_edges(A) | cycle_edges(B)

# A target-preserving inverse-square attachment.
SQUARE = ("u", "v", "x", "y")
ATTACHMENT = {"u": "t0", "v": "t3", "x": "t2", "y": "t1"}
SQUARE_EDGES = cycle_edges(SQUARE)
ATTACHMENT_EDGES = frozenset(
    edge(square, terminal) for square, terminal in ATTACHMENT.items()
)
EXTENSION_VERTICES = RESIDUAL_VERTICES | set(SQUARE)
EXTENSION_EDGES = RESIDUAL_EDGES | SQUARE_EDGES | ATTACHMENT_EDGES
EXTENSION_GRAPH = graph_from(EXTENSION_VERTICES, EXTENSION_EDGES)

assert len(EXTENSION_VERTICES) == 32 and len(EXTENSION_EDGES) == 48
assert nx.number_of_selfloops(EXTENSION_GRAPH) == 0
assert nx.is_connected(EXTENSION_GRAPH) and nx.is_bipartite(EXTENSION_GRAPH)
assert all(degree == 3 for _, degree in EXTENSION_GRAPH.degree())
planar, embedding = nx.check_planarity(EXTENSION_GRAPH)
assert planar
faces = plane_faces(embedding)
assert len(EXTENSION_VERTICES) - len(EXTENSION_EDGES) + len(faces) == 2
assert sum(cyclic_equal(face, SQUARE) for face in faces) == 1

ROOT = edge("u", "v")
FORCED_GATE = edge("x", "y")
SURVIVING_GATE = edge("b4", "b5")
COMMON_FACE_EXPECTED = ("b4", "b3", "t1", "y", "x", "t2", "x5", "b5")
common_face = next(face for face in faces if cyclic_equal(face, COMMON_FACE_EXPECTED))
boundary = face_edges(common_face)
assert FORCED_GATE in boundary and SURVIVING_GATE in boundary and ROOT not in boundary
delta = (boundary.index(SURVIVING_GATE) - boundary.index(FORCED_GATE)) % len(boundary)
closed_gate_arcs = (delta + 1, len(boundary) - delta + 1)
assert sorted(closed_gate_arcs) == [5, 5]
assert all(size >= 5 and size % 2 == 1 for size in closed_gate_arcs)
assert {
    frozenset((ATTACHMENT["u"], ATTACHMENT["y"])),
    frozenset((ATTACHMENT["v"], ATTACHMENT["x"])),
} == set(I)
assert SURVIVING_GATE not in CUBE[(0, 0)]
assert SURVIVING_GATE in CUBE[(1, 1)]

LIFTED = {
    state: matching | frozenset((ROOT, FORCED_GATE))
    for state, matching in CUBE.items()
}
assert all(
    perfect(EXTENSION_VERTICES, EXTENSION_EDGES, matching)
    for matching in LIFTED.values()
)
assert {
    state: nx.number_connected_components(
        graph_from(EXTENSION_VERTICES, EXTENSION_EDGES - matching)
    )
    for state, matching in LIFTED.items()
} == {(0, 0): 2, (1, 0): 1, (0, 1): 1, (1, 1): 2}

# Direct brace certificate: every independent edge pair occurs together in a
# perfect matching of the same 32-vertex graph.
extension_matchings = enumerate_perfect_matchings(EXTENSION_VERTICES, EXTENSION_EDGES)
assert len(extension_matchings) == 811
covered_pairs = {
    frozenset((first, second))
    for matching in extension_matchings
    for first, second in combinations(matching, 2)
}
independent_pairs = {
    frozenset((first, second))
    for first, second in combinations(EXTENSION_EDGES, 2)
    if first.isdisjoint(second)
}
assert len(independent_pairs) == 1032
assert independent_pairs <= covered_pairs
assert nx.node_connectivity(EXTENSION_GRAPH) == 3

# Complete fixed-I residual fibre and both surviving-gate sectors.
residual_matchings = enumerate_perfect_matchings(RESIDUAL_VERTICES, RESIDUAL_EDGES)
fibre = tuple(
    matching
    for matching in residual_matchings
    if complement_profile(matching) == (I, 0)
)
sector0 = tuple(matching for matching in fibre if SURVIVING_GATE not in matching)
sector1 = tuple(matching for matching in fibre if SURVIVING_GATE in matching)
distribution = Counter(
    delta_component_count(first, second)
    for first in sector0
    for second in sector1
)

assert len(residual_matchings) == 212
assert len(fibre) == 41
assert (len(sector0), len(sector1)) == (16, 25)
assert distribution == Counter({1: 69, 2: 179, 3: 115, 4: 29, 5: 6, 6: 2})
assert delta_component_count(CUBE[(0, 0)], CUBE[(1, 1)]) == 2

# Freeze one literal single-cycle crossing pair that supplements the cube.
M0 = frozenset(
    edge(*item)
    for item in (
        ("a0", "a1"), ("a2", "a3"), ("b0", "b11"),
        ("b1", "b2"), ("b10", "b9"), ("b3", "b4"),
        ("b5", "b6"), ("b7", "b8"), ("t0", "t1"),
        ("t2", "x5"), ("t3", "x9"), ("x0", "x1"),
        ("x2", "x3"), ("x7", "x8"),
    )
)
M1 = frozenset(
    edge(*item)
    for item in (
        ("a0", "a1"), ("a2", "a3"), ("b0", "x1"),
        ("b1", "x0"), ("b10", "b11"), ("b2", "b3"),
        ("b4", "b5"), ("b6", "b7"), ("b8", "b9"),
        ("t0", "t1"), ("t2", "x5"), ("t3", "x9"),
        ("x2", "x3"), ("x7", "x8"),
    )
)
assert M0 in sector0 and M1 in sector1
assert delta_component_count(M0, M1) == 1
assert len(M0 ^ M1) == 14

print("extension: 32 vertices, 48 edges; plane cubic bipartite")
print("legal-wide witness: attachment=(t0,t3,t2,t1), arcs=(5,5)")
print(
    f"brace certificate: {len(extension_matchings)} perfect matchings cover "
    f"all {len(independent_pairs)} independent edge pairs"
)
print(
    f"residual: {len(residual_matchings)} perfect matchings; "
    f"fixed-I fibre={len(fibre)}={len(sector0)}+{len(sector1)}"
)
print(
    "cross-sector component distribution="
    + ",".join(f"{key}^{distribution[key]}" for key in sorted(distribution))
)
print("XOR pair: double-E atomic distance 2; full-fibre minimum 1")
print("LEGAL_WIDE_PLANE_BRACE_XOR_CUBE_VERIFIED")
