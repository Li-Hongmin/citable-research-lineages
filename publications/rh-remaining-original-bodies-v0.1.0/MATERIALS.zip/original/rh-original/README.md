# 局部 Weil 形式与黎曼猜想

本项目研究 Riemann ζ 函数的 Weil 正性判据及其局部化算子。长期目标是：确定局部 Weil 二次型
\(Q_W^a\) 在全部尺度 \(a>0\) 上的非负性、退化机制与尖锐边界；若预期的非退化陈述不成立，
则构造结构性反例并确定正确的替代边界。

根目录数学单元以局部自伴算子 \(A_a\)、最低谱值 \(\lambda_a\)、prime-shift 结构和紧支撑边界
条件为核心。临界线比例与全局 screw-kernel 各自拥有独立单元；Weil–Krein 有限矩阵铅笔、
有限自伴谱近似和 spectral flow 只在它们直接解释这些对象时作为工具或候选机制使用。

根目录只承载 A 线（局部 Weil → RH）的稳定地图；三条研究线的证明链彼此独立。

## 稳定入口

- 论文化总入口：[论文组合与证据边界](papers/PAPER-PORTFOLIO-2026-08.md)。当前分为局部 Weil cutoff-free response--Schur、Euler--beta detector 层级和中尺度 Möbius signed dyadic gate；其中只有第一项的局部应用定理已闭合。
- A 线的结果索引：[黎曼猜想定理宇宙](THEOREM_UNIVERSE.md)。局部 Weil 方向的当前严格端点是[局部 Weil 正性推进到 \(\frac12\log11\)](notes/275-cutoff-free-local-weil-positivity-to-log11-half.md)；这是 cutoff-free 的有限端点定理，仍不等于全尺度 Weil 正性或 RH。另一路的[有限纯偶正弦 universal detector](notes/088-a-finite-pure-even-sine-family-universally-detects-rh.md)把 RH 等价压缩到一个有限模族的 cutoff 均方估计，但不等于已经证明 RH。
- B 线：[临界线上简单零点的无条件比例](units/critical-line-proportion/README.md)。
- C 线：[全局 screw-kernel 因子化](units/global-spectral-limit/README.md)。
- [M2-R 当前状态](CURRENT_STATUS_M2R.md)是 2026-08-11 的历史综合记录；数学结论以对应 note 和上述单元入口为准。
- 最新 phase 线索：[校正后的 Euler/函数方程 phase 分解](notes/540-bilateral-euler-phase-factor-is-the-explicit-infinite-reflection-candidate.md)
  与 [\(V_{15}\) 零自由 phase factor 的 RH 等价性](notes/541-zero-free-phase-factor-is-exactly-rh-for-v15.md)；
  前者给出显式算术输入，后者明确指出尚缺的是右半平面零自由延拓，不是边界模一条件。
- 最新 lcm phase 边界：[径向幅度变形仍有线性绝对质量](notes/698-radial-lcm-amplitude-deformation-still-has-linear-mass.md)；
  保持 \(tu=-1\) 的实径向变形在 \(R=1\) 处才最优，但仍只有 \(X\log X\) 级，不能替代 signed intertwiner。
- [完整复参数 lcm 绝对质量统一下界](notes/699-full-complex-lcm-amplitude-phase-absolute-mass-lower-bound.md)；
  任意 \(t\ne0,\ u=-1/t\) 都有首 Euler 指数 \(\kappa(t)\ge2\)，因此角度与幅度调节的绝对/Cauchy 族整体关闭。
- [任意乘法 lcm 因子化的绝对质量统一 no-go](notes/700-universal-multiplicative-lcm-factorization-absolute-mass-no-go.md)；
  不依赖特定平方根参数族，任何精确实现 \(\mu*\mu\) 的乘法因子化取绝对值后仍至少有 \(X\log X\) 质量。
- [任意 lcm 表示的绝对质量三角下界](notes/701-universal-lcm-representation-triangle-lower-bound.md)；
  去掉乘法性与参数化假设后，逐层三角不等式仍强迫至少 \(X\log X\) 的绝对质量，剩余核心是跨 lcm 层的 signed intertwiner。
- [prime-shift multiplier 的离线极点范数障碍](notes/702-prime-shift-multiplier-offline-pole-norm-obstruction.md)；
  量化说明任何只允许在 \(\sigma\downarrow\frac12\) 发散的 uniform signed bridge 都必须排除 \(\Re\rho>\frac12\) 的 zeta 零点。
- [endpoint-12 even tail 的固定裕量边界](notes/703-log12-even-tail-strict-negative-direction.md) 与
  [zero-gap 逻辑校正](notes/704-log12-fixed-gap-failure-does-not-close-zero-gap-tail.md)；
  \(C-10^{-12}I-LL^{\mathsf T}\) 有严格负 witness，但这不判定
  \(C-LL^{\mathsf T}\)；小裕量 tail 仍须在 OMEN 上重新认证。
- [任意重 shifted Möbius 卷积的 RH 极点门](notes/705-k-fold-shifted-mobius-convolution-retains-rh-pole.md)；
  将 \(\mu*\mu\) 推广到 \(\mu^{*k}\)，离线零点极点阶数变为 \(k\) 倍，增加 tensor 阶数不能绕过 RH 门。
- [k=2 signed/Krein 桥的二阶极点必要条件](notes/706-k2-krein-schur-requires-double-pole-or-frequency-mixing.md)；
  completed-zeta 奇部的一阶零点极点经 Schur 补要求至少二阶 odd 补偿，或必须引入频率混合/完整 arithmetic cross block。
- [最小双频 canonical reflection intertwiner](notes/707-minimal-two-frequency-reflection-intertwiner.md)；
精确解 \(J_\omega T=TR\) 强制两列同时存在并满足 \((\alpha,\omega\alpha)\)、\((\beta,-\omega\beta)\) 的形状，给出可审计的频率混合 defect。
- [\(k=2\) 高除数端点层的两频率移动 Möbius 分解](notes/730-k2-high-divisor-endpoint-layer-is-a-boundary-free-two-frequency-mobius-kernel.md)；
  \(d>N/2\) 层的核两端取零、只在 \(u=1/3\) 有导数跳点，不含孤立 Mertens 端点原子；剩余仍是 RH 强度的 moving signed covariance。
- [完整 \(k=2\) cofactor 核的连续性与 BV cap 代价](notes/731-full-k2-cofactor-kernel-is-continuous-but-bv-cap-grows.md)；
  所有激活边界均无值跳跃，但逐 cell 的总变差为 \(O(A\log A)\)，\(A\asymp Y^{1/4}\) 时普通 Abel 仍损失幂次。
- [\(k=2\) cofactor 均方的无条件对角二次界](notes/732-k2-cofactor-mean-square-diagonal-is-unconditionally-quadratic.md)；
  对角质量已降至 \(O(Y^2)\)，剩余全部集中在 \(\mu(d)\mu(e)\) 的 moving-\(N\) 非对角 signed covariance。
- [\(k=2\) cofactor 非对角宏观相干块](notes/733-k2-cofactor-macro-block-is-coherent-and-has-cubic-absolute-mass.md)；
  固定比例块的核条目同号，非对角绝对质量为 \(\Omega(Y^3)\)，排除纯 \(N\)-振荡或大筛捷径。
- [2026 短区间 \(\mu\)--相位定理留下固定 cofactor 门](notes/734-2026-short-interval-theorem-leaves-fixed-cofactor-gate.md)；
  短区间定理的 \(H\le X^{1-\varepsilon}\) 上限不覆盖固定 cofactor \(b=2\) 的宏观区间，逐 cofactor 的对数节省也不足以给出目标均方量纲。
- [Pandey--Radziwiłł 的 2026 (L^1) 下界不关闭 moving-cofactor 门](notes/735-pandey-radziwill-l1-bound-does-not-close-moving-cofactor-gate.md)；
  该文给出 Möbius/Liouville 指数和在加性频率上的 (L^1) 下界，平均变量和不等号方向都不匹配所需的 moving-(N) 协方差上界。
- notes 734--735 的固定 cell 区间实例以及 notes 736--745、747、749--751 的固定 cell 解释已由 [note 757](notes/757-correction-fixed-cofactor-support-is-one-over-a-to-two-over-a.md) 校正：后者的核是旧支撑上的人工 detector；真实 cofactor 支撑为 \(N/a<d<\min(2N/a,N)\)。人工核恒等式仍可使用，但不能直接接到 note 732 的真实 cofactor 协方差。
- [固定 b=2 cofactor 的单 cell Mellin detector](notes/736-fixed-b2-cofactor-is-a-one-cell-mellin-detector.md)；
  其均方门只可能漏掉明确的 archimedean 零集 K_2(s)，若该因子在右半平面无零则该单门即推出 RH。
- [固定 b=2 因子的低频零自由扇区](notes/737-fixed-b2-archimedean-low-frequency-zero-free-sector.md)；
  相位宽度直接给出 (|\Im s|\le\pi/\log2) 的零自由带，但严格 log-concavity 本身不足以排除高频右半平面零点。
- [所有固定 cofactor cell 的统一低频零自由带](notes/738-all-fixed-cofactor-cells-share-the-low-frequency-zero-free-band.md)；
  对每个 b\ge2 都得到同一 (|\Im s|\le\pi/\log2) 区域，有限 cofactor 家族的 archimedean 剩余统一集中到高频段。
- [2026 年“RH 证明”主张的原始来源核验](notes/739-2026-rh-proof-claims-do-not-close-the-arithmetic-gate.md)；
  已确认一篇 arXiv 版本明确撤回，另一篇只覆盖特殊区域；没有外部结果提供当前 moving-\(N\) Möbius covariance 的平方根级上界。
- [两个固定 cofactor cell 将 archimedean 盲点压成 \(B=B'=0\)](notes/740-two-cofactor-cells-reduce-archimedean-blind-set-to-multiple-zero-gate.md)；
  \(b=2,4\) 的 Mellin 因子都落在同一二维 frame \((A,B)\) 中；联合均方门下的离线零点只能落在 \(B\) 的重零点集，算术协方差上界仍未证明。
- [一次相位校正排除 \(B=B'\) 的更宽低频带](notes/741-affine-phase-flattening-excludes-low-frequency-double-zeros.md)；
  对共同盲点构造 \(1+i\tau(x-\frac12\log2)\) 的 affine phase flattening，严格得到
  \(|\Im s|>2\theta_0/\log2\)，其中 \(\theta_0\) 是 \(\cos\theta+\theta\sin\theta=0\) 在 \((\pi/2,\pi)\) 的唯一根。
- [中心一阶矩把 \(B=B'\) 共同盲点的低频带扩大一倍](notes/742-centered-first-moment-doubles-common-blind-band.md)；
  只用中心化因子 \(i\tau(x-\frac12\log2)\) 与 \(\Re(i\theta e^{-i\theta})=\theta\sin\theta\)，严格得到共同盲点必须满足 \(|\Im s|>2\pi/\log2\)。
- [\(b=2,4\) cross covariance 的精确负 parity resonance line](notes/743-b2-b4-cross-resonance-has-exact-negative-parity-line.md)；
  \(d=2e\) 是唯一正整数相位共振，\(\mu(2e)\mu(e)\) 使其贡献严格为负，并可精确写成 \(-c_{24}Y^2+O(Y^{3/2})\)；其余 signed covariance 仍未控制。
- [dyadic parity intertwiner 精确消去相邻 cofactor 的 log weight](notes/744-dyadic-parity-intertwiner-cancels-log-weight.md)；
  精确恒等式 \(U_b^{\rm even}+U_{2b}^{\rm odd}=-(\log2)P_b\) 把相邻 parity block 化为纯 sine 的 odd-Möbius 变换，其 Mellin 分子正是 \(B(s)\)。
- [endpoint expansion 将 \(B=B'\) 共同盲点压入紧频带](notes/745-endpoint-expansion-confines-common-blind-set-to-compact-band.md)；
  三次分部积分给出 \(B(s)\) 的统一 \(s^{-2}\) endpoint 主项和 \(O(|s|^{-3})\) 余项；显式估计可取 \(\mathcal T<29\)，结合 note 742 将共同盲点限制在明确紧盒内。
- [完整 \(k=2\) cofactor 核精确分解为 \(\zeta,\zeta'\) detector](notes/746-full-k2-cofactor-kernel-is-zeta-zeta-prime-detector.md)；
  完整 Mellin 核满足 \(K_{\mathrm{full}}=A_*(\zeta-1)+B_*\zeta'\)，完整化不产生独立 fixed-mode 通道，剩余承重项仍是 moving-\(N\) signed covariance。
- [affine 一阶 jet 的逐点相位正性具有尖锐 \(2\pi\) 宽度](notes/747-affine-first-jet-positivity-has-sharp-two-pi-width.md)；
  任意 \(a+b x\) 的逐点相位正性在支撑上的相位宽度至多为 \(2\pi\)，因此不能覆盖 note 745 剩余的高频紧盒。
- [旧支撑人工核的 \(B\) 共同盲点证书](notes/749-omencert-b-mellin-zero-free-box.md)；
  24\,925 个参数盒排除的是旧核的共同盲点，真实 cofactor frame 的证书见 note 758。
- [旧支撑人工核的两个 arithmetic gate 与 RH 等价](notes/750-joint-b2-b4-arithmetic-gate-is-equivalent-to-rh.md)；
  等价定理仍可用于该人工核；其与真实高除数 covariance 的直接连接已由 note 757 撤销。
- [dyadic parity reconstruction 保持 fixed-cofactor 均方门的指数](notes/751-dyadic-parity-reconstruction-preserves-cofactor-gate.md)；
  奇数/偶数分解是可逆的 dyadic difference，联合 \(b=2,4\) 门可投影到 odd-Möbius
  pure-sine 门，但不产生任何低于 RH 强度的幂次增益。
- [2026 新 averaged-Chowla 结果仍不关闭 moving-\(N\) 协方差门](notes/752-2026-averaged-chowla-results-do-not-close-moving-covariance.md)；
  Menon 2607.15574 仍只有对数级短区间节省，Zhang 2608.16108 只控制所有移位的联合平均；
  两者都不能覆盖 note 732 的 \(Y^{2+\varepsilon}\) signed covariance。
- [高除数 \(k=2\) 门等价于 \(k=2\) residual](notes/753-high-divisor-k2-gate-is-the-k2-residual-up-to-negligible-low-layer.md)；
  \(d\le Y^{3/4}\) 层无条件只有 \(O(Y^2\log^2Y)\) 能量，完整 cofactor 层精确化为
  \(-\sum[\Lambda+\mu\log(r/N)]\sin(2\pi r/N)\)，即 note 087 的 \(k=2\) residual。
- [真实 \(a=2,4\) cofactor frame 无共同盲点](notes/758-omencert-true-a2-a4-cofactor-frame-has-no-common-blind-point.md)；
  note 757 的支撑校正后，对 \(J(s)=\int_1^2\sin(2\pi u)u^{s-1}du\) 的共同零点证书恢复真实两 cell 的 RH 等价门；算术均方上界仍未证明。
- [完整 \(k=2\) 核的精确对数平方变差主项](notes/760-sharp-log-squared-variation-of-the-full-k2-cofactor-kernel.md)；
  实际高除数区间上的变差为 \(\frac{5\pi}{12}\log^2 A+O(1)\)，并有 Bernoulli 波形及倒数相位展开；普通 Abel 仍需要 Möbius 平方根级输入。
- [真实 cofactor 的 parity 与对角数据不能控制 moving Gram](notes/761-true-cofactor-parity-and-diagonal-data-do-not-bound-the-moving-gram.md)；
  保留平方自由支撑和精确 \(2\)-adic parity 的测试系数仍产生 \(\Omega(Y^3)\) 的真实 \(a=2\) cell 均方，对角项却只有 \(O(Y^2)\)；必须利用奇数位上的真实 Möbius 符号。
- [倒数频率间距支付 \(k=2\) 低除数至 \(Y^{4/5}\)](notes/762-reciprocal-frequency-spacing-pays-low-divisors-to-four-fifths.md)；
  Bernoulli 波形与初等频率间距给出 \(\sum_{N\asymp Y}|L_{N,D}|^2\ll\log^3(2Y)(D^3/Y+D^5/Y^2)\)，对所有 \(|c_d|\le1\) 成立；实际高除数算术门因此可从 \(d>Y^{4/5}\) 开始。
- [\(Y^{4/5}\) 低除数统一支付的尖锐性](notes/763-four-fifths-is-sharp-for-sign-blind-low-divisor-bounds.md)；
  块相干与随机符号构造给出匹配 note 762 幂次的 \(D^5Y^{-2}\log^2(Y/D)\) 下界；该幂边界对保留平方自由支撑、\(2\)-adic parity，甚至全局乘法性和全部 \(d\le D/2\) 真实 Möbius 系数的测试函数仍成立。另有真实 \(\mu(p)=-1\) 的单素数块下界：若完整 \(k=2\) 门成立且 \(D=Y^\alpha\)、\(\alpha>5/6\)，其余项必须给出同量级负协方差；目前未证明该门。
- [真实 Möbius 素数块的无条件远距离 product 负协方差](notes/764-unconditional-negative-offproduct-covariance-for-a-true-mobius-prime-block.md)；
  置 \(\omega(Y)=(\log Y)^{3/5}(\log\log Y)^{-1/5}\)、\(D=Ye^{-a\omega(Y)}\)。每个长度 \(D^2/(1000Y)\) 的滑动素数块都与补集产生 \(Y^{3-o(1)}\) 量级的负协方差；距离不超过 \(Ye^{-7a\omega(Y)}\) 的 product 配对可忽略。窄块另有精确能量常数 \(\pi^2/240\)。完整均方仍未达到 RH 所需的 \(Y^{2+\varepsilon}\)。
- [真实 cofactor cell 的素数--合数宏观负协方差](notes/765-unconditional-prime-composite-covariance-across-true-cofactor-scales.md)；
  每个固定 \(a\ge2\) 的素数部分都有 \(\kappa N/(a\log N)\) 的正主项，合数部分逐 \(N\) 抵消它；取 \(a=\lfloor Y^{1-\alpha}\rfloor\)、\(0<\alpha<1\) 时，负交叉量为 \(-7\kappa^2Y^{1+2\alpha}/(3\alpha^4\log^2Y)(1+o(1))\)，排除 \(o(Y/\log^3Y)\) 的 product 位移后仍成立。真实 \(a=2,4\) 的 \(Y^{2+\varepsilon}\) 算术门仍未证明。
- [固定幂 cofactor 带的三次素数--合数负协方差](notes/766-cubic-prime-composite-covariance-in-polynomial-cofactor-bands.md)；
  将真实 cells \(2\le a\le Y^{1-\alpha}\) 聚合，素数通道逐 \(N\) 为 \(\kappa(\alpha^{-1}-1)N+O_\alpha(N/\log Y)\)，非素数通道抵消它；交叉量为 \(-7\kappa^2(\alpha^{-1}-1)^2Y^3/3+o(Y^3)\)，去除 \(|n-m|\le Y/\log^6Y\) 的 product 配对后仍成立。\(\alpha>4/5\) 时这完全位于剩余高除数区，但不控制完整均方门。
- [真实高除数门的素数--非素数远 product 负协方差](notes/767-cubic-over-log-squared-covariance-in-the-actual-high-divisor-gate.md)；
  对硬截断 \(d>Y^\alpha\)、\(0<\alpha<1\)，完整核积分 \(K=\int_0^1\Phi(t)\,dt\) 严格为正；素数通道逐 \(N\) 为 \(-KN/\log N+O_\alpha(N/\log^2Y)\)，与非素数补集的负交叉量为 \(-7K^2Y^3/(3\log^2Y)+O_\alpha(Y^3/\log^3Y)\)。去除 \(|n-m|\le Y/\log^8Y\) 的 product 配对后仍成立；完整均方门未解决。
- [真实 cofactor cell 中固定比例远隔的素数--非素数负协方差](notes/768-macroscopically-separated-negative-covariance-in-a-true-cofactor-cell.md)；
  在同一个真实 \(a\) cell 的两个同号半波子区间中，所有 product 配对相距至少 \(Y/8\)，交叉项仍为负；取 \(a=Y^{1-\alpha}\) 时有显式 \(-c_\alpha Y^{1+2\alpha}\) 主项，固定 \(a=2\) 时为 \(-cY^3/\log^2Y\)。这是完整 Gram 的受限块，不给出完整均方上界。
- [2026 年全尺度奇 Weil 正性主张的继承 Schur 比较缺口](notes/769-inherited-schur-comparator-needs-a-funded-reference-term.md)；
  arXiv:2609.20367v2 的继承方向恒等式将负 Schur 能量拆成负参考项与正差额；其最终预算使用正差额时，所列承重推理尚需证明参考项在同一二次型中被独立支付。这不判定该文主定理真假，也不关闭本项目的真实算术门。
- [三个 parent 的 one-defect aligned 扣款超过目标对角](notes/770-three-parent-aligned-load-exceeds-the-target-diagonal-in-the-one-defect-model.md)；
  素数定理给出固定 parent 的 \(b_m^2/\Pi_m^{(0)}\sim2\log k/[\beta_0(2m+1)]\)；仅 \(m=1,2,3\) 的真实 \(\theta_{k,m}^2\) 权重和最终超过 \(B_k\)。因此只用该下枢轴支付 note 769 的参考扣款不能修复归纳；固定 parent 的真实枢轴增强见 note 771。
- [稀疏 source cut 的真实固定 parent 枢轴增强](notes/771-sparse-true-source-cuts-have-diverging-fixed-parent-pivots.md)；
  单胞形式的零延拓 Fourier 符号给出任意小测度源集的尖锐下界 \(\kappa(S)\ge(1-o(1))\log(1/|S|)\)。原文 Lemma 6.58 的同一 common-cut 枢轴因此对固定 \(m\) 至少以 \(\log\log k\) 增长；note 772 的局部密度证明进一步将固定及小 parent 的矩阵下界提升为 \(c\log k\)。
- [真实 source cut 的全数据下界与全 parent 扣款](notes/772-true-source-ground-pivots-in-polynomial-parent-bands.md)；
  在同一次单胞 common-cut 上，对扩张 parent 带的全部源函数证明尖锐的 \((1-o(1))\log(k/m)\) 下界，对小 parent 证明 \(c_A\log k\) 下界；ground 与槽内 transverse 因而获得同时的范数支付。扩张带 source-ground 矩阵更精确地为 \((\log(k/m)+1+o(1))I\)。全 parent 的 aligned 与完整 source-ground dual 扣款均至多为 \(\log k-\log\log k+o(\log\log k)\)，原始 mismatch 逆度量总扣款为 \(O(1)\)；沿素数 \(k\) 时次项尖锐。这些结果尚未识别完整 Weil harmonic graph 的实际扣款。
- [消去 mismatch 后的真实混合 forcing 总成本有界](notes/773-post-mismatch-mixed-forcing-has-bounded-total-cost.md)；
  对 note 772 的同一单胞 source-ground 矩阵作精确 Schur 分块，证明消去 mismatch 后改变的 inherited forcing 在全体 parent 上只造成 \(O(1)\) 的绝对扣款差；完整 source-ground dual 与带 \(\theta_{k,m}^2\) 的 aligned 总扣款相差 \(O(1)\)。完整 Weil harmonic graph 的同向量支付仍待核对。
- [真实 source 槽的旧 prime-shift 幂链及有界内部成本](notes/774-prime-power-source-chains-have-bounded-internal-shift-cost.md)；
  整数 dilation 在两个真实 source 槽间有交集恰当且仅当指标满足 \(n'=qn\)；旧算术压缩因此分解为素数幂链，算子范数小于 \(4\)。将全部内部边加入高指标单胞 source-ground 模型，只使算术 forcing 的逆度量扣款改变 \(O(1)\)；source--complement 反馈及完整 harmonic graph 仍未控制。
- [单个素数 source 的旧算术补空间耦合及奇旧算子交叉下界](notes/775-a-prime-source-has-logarithmic-arithmetic-coupling-to-the-complement.md)；
  对 \(p\in(k/2,k)\)，内部算术压缩在该 source 列为零，但补空间算术像的平方范数为 \((1/2+o(1))\log^2 k\)。在 \(k=2p-1\) 的端点奇空间，archimedean 与 polar 修正在选定正交测试族上各只有 \(O(1)\) 的系数范数，故完整旧算子的 source--complement 交叉块仍有 \((1/\sqrt2+o(1))\log k\) 下界。进一步用小素数幂子星作变分测试：若旧算子严格正，该 source 列的实际 Schur 反馈至少为 \(c\log k\)。剩余 source 枢轴、目标对角与 fold 的同向量余额仍未控制。
- [物理半 collar 的素数--dyadic forcing 配对](notes/776-physical-half-collar-forcing-pairs-prime-and-dyadic-source-branches.md)；
  对 \(k=2p-1\) 的单位奇 collar 测试向量，实际 \(B_{A,k}f_k\) 在同一 \(h_p\) 上的投影趋于 \(\log2/2\)：\(n=p\) 作用于下半槽、\(n=2\) 作用于上半槽且符号相反。奇素数幂补空间子星对新增 collar 的算术 forcing 精确正交，小子星上的完整 forcing 为 \(o(1)\)。这些同向量投影仍不足以判定完整逆响应或目标 Schur 符号。
- [物理 collar forcing 的精确算术范数与真实旧核逆响应下界](notes/777-physical-collar-forcing-has-logarithmic-inverse-response-on-prime-source-bands.md)；
  算术半槽两两不交，故其完整 \(L^2\) 平方范数精确为 \(\sum_{n\le k}\Lambda(n)^2/n\sim\frac12\log^2k\)，非算术 forcing 只有 \(O(1)\) 范数。沿 \(k=2p-1\)，在任一固定的低素数带 \(0<\alpha<\beta<1/2\) 或高素数带 \(1/2<\alpha<\beta<3/4\)，若完整旧奇算子严格正，则同一物理 collar 的真实逆响应至少为 \(c_{\alpha,\beta}\log k\)。同一向量的直接目标对角精确为 \(\log k+1-\gamma-\log\pi+o(1)\)；最终 Schur 符号与 RH 仍未判定。
- [完整物理 collar forcing 的 polar 投影提取 Chebyshev 误差](notes/778-physical-collar-polar-forcing-detects-the-chebyshev-error.md)；
  算术 forcing 与旧 polar 交叉的 \(k^{1/4}\) 主项相消，精确积分及 archimedean 估计给出 \(\langle s_k,B_{A,k}f_k\rangle=(\psi(k)-k)/(2k^{3/4})+O(k^{-1/4}\log k)\)。因此直接要求该投影有 \(O_\varepsilon(k^{-1/4+\varepsilon})\) 点态界已是 RH 强度的素数误差门；这不控制完整旧核逆响应。
- [物理半槽全素数幂测试的 \(9/32\) 对数逆响应下界](notes/780-all-prime-power-half-slots-give-nine-thirty-seconds-logarithmic-physical-inverse-response.md)；
  Legendre 能量、端点势与标量项对每个归一化物理区间有精确的位置消去恒等式。按整数乘积 \(nm\) 分组后，中点附近的异号 archimedean 交叉也是 \(o(1)\)，故无需 note 779 的两带间距。对任意 \(\eta>0\)，若完整旧奇算子严格正，充分大端点的实际 \(\langle B_{A,k}f_k,A_{k,-}^{-1}B_{A,k}f_k\rangle\ge(9/32-\eta)\log k\)。完整 Schur 符号与 RH 仍未判定。
- [半槽试探向量的精确旧核能量](notes/781-half-slot-trial-energy-has-a-finite-prime-power-chain-correction.md)；
  对固定 \(\beta<3/4\)，其能量无条件等于 \((\log k+1-\gamma-\log\pi)S_{k,\beta}-2\sum_p(\log p)^3/(p-1)^2+o(1)\)。同号素数幂链仅留下有限常数，故继续提升同一 collar 的逆响应须处理补空间反馈或更高指标的异号算术交叉。
- [平方自由半素数补槽的 \(9/29\) 物理逆响应下界](notes/782-squarefree-semiprime-response-raises-the-physical-inverse-bound-to-nine-twenty-ninths.md)；
  在旧奇空间中加入与 collar 算术 forcing 正交的 \(pq\) 半槽；它与两个真实素数父槽各有一条负平移边。若旧核严格正，完整同向量逆响应对任意 \(\eta>0\) 至少为 \((9/29-\eta)\log k\)。此值仍未决定完整 Schur 符号。
- [平方自由素因子层的 Jacobi 逆响应链](notes/783-squarefree-factor-layers-form-a-jacobi-response-chain.md)；
  固定有限层的真实旧核矩阵渐近为显式 Jacobi 链；其三层变分系数为 \(1359/4352\)，全有限层极限 \(C_\square\) 满足 \(9108/29159<C_\square<1/3\)。若旧核严格正，则同一物理 collar 的逆响应对任意 \(\eta>0\) 至少为 \((C_\square-\eta)\log k\)；这仍不判定完整 Schur 符号。
- [对数素数轮廓的两层连续变分下界](notes/784-logarithmic-prime-profiles-beat-all-constant-squarefree-layers.md)；
  对真实素数与半素数半槽引入随 \(\log p/\log k\) 变化的权重，得到显式正的连续能量与最优两层系数 \(C_{\rm prof}\)。其严格下界 \(6945750/22039497>5/16\) 超过全部常权平方自由层的保证系数；若旧核严格正，同一物理 collar 的逆响应至少为 \((C_{\rm prof}-\eta)\log k\)。完整 Schur 符号仍未判定。
- [全平方自由连续轮廓的逆响应变分上界](notes/785-squarefree-continuum-response-ceiling.md)；
  对任意固定有限因子层和有界连续对数轮廓，真实旧核的极限二次型具有显式非负平方余项。该半槽试探族的保证系数不超过 \(3/4-(\log4)/4<1\)；这不约束完整旧核逆响应，也不判定 Schur 符号。
- [全整数同号算术图及真实低段压缩的逆响应上界](notes/786-all-integer-same-arm-arithmetic-response-ceiling.md)；
  对全部半槽整数节点与任意系数，逐素数幂边的精确平方恒等式给出 \(\alpha<1\) 的正谱隙；算术 forcing 的有限图逆响应至多为 \([\alpha+(1-\alpha)\log(1-\alpha)+o(1)]\log k\)。当 \(\alpha\le1/2\) 时，同一上界还适用于真实旧核的低段主压缩；完整逆响应仍可能有补空间反馈。
- [Farey 间距控制真实半槽的异号算术范数](notes/787-farey-spacing-bounds-opposite-arm-arithmetic-operator.md)；
  异号算术压缩在全部整数半槽 \(n\le X<k\) 上满足 \(\|R_{k,X}^{\rm opp}\|\ll1+X^2\log(2X)/k^{3/2}\)。因此对每个固定 \(\alpha<3/4\)，真实旧奇算子的整个半槽主压缩有 \((1-\alpha)\log k-O_\alpha(1)\) 正谱隙，其压缩逆响应系数至多为 \(U(\alpha)<1\)；完整旧核与正交补的反馈未受此界控制。
- [分数指标半槽的对数级补空间反馈](notes/788-fractional-half-slots-force-logarithmic-complement-feedback.md)；
  沿 \(k=p^2\)，一族 \(p/q\) 分数半槽与全部整数半槽正交，却与整数槽 \(e_p\) 有精确素数幂平移边。真实旧奇算子该列到整数半槽补空间的范数至少为 \((1/(2\sqrt2)+o(1))\log k\)；若完整旧核严格正，同列的 Schur 反馈至少为 \((1/8+o(1))\log k\)。此结果不判定完整 collar Schur 符号。
- [整族倒数分数半槽的严格正主压缩](notes/789-reciprocal-fraction-half-slot-family-has-positive-compression.md)；
  将 \(p/q\) 扩展为全部整数分母 \(1\le d<p\) 后，真实旧核在这族正交半槽上的非根谱隙至少为 \((1/2+o(1))\log k\)。根 \(e_p\) 的有限族 Schur 反馈夹在 \(1/8\) 与 \((1-\log2)/2\) 倍 \(\log k\) 之间，故该族整体仍严格正；无限维补空间的反馈未受此上界控制。
- [倒数分数槽的全有限能量轮廓压缩](notes/790-reciprocal-slot-transverse-profile-compression.md)；
  把每个 \(p/d\) 槽扩展到全部有限能量 \(L^2\) 轮廓后，真实旧核压缩仍有 \(\frac12\log k-O(1)\) 谱隙，同一根列的压缩 Schur 反馈仍至多为 \(((1-\log2)/2+o(1))\log k\)。该结论不约束槽外补空间。
- [全 Farey 偶极的精确算术图与临界谱半径](notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md)；
  在 \(k=p^2\) 的全部既约 \(a/b>1\)、\(a,b<p\) 偶极上，素数幂矩阵精确为 \(-c_{x/y}-c_{y/x}-c_{xy}\)，其谱范数为 \(\log k+O(1)\)，完整 Archimedean 压缩仅偏离 \(D_kI\) 一个 \(O(1)\) 算子；真实 Farey 主压缩的最低谱值因此处于常数量级。若完整旧奇算子严格正，低整数根列的补反馈至少为 \((48/127-o(1))\log k\)；这仍不证明全尺度 Weil 正性或 RH。
- [单一平方自由双臂家族达到临界算术谱半径](notes/792-a-single-squarefree-two-arm-farey-family-has-critical-arithmetic-radius.md)；
  根 \(4/3\) 的双臂平方自由后代已达到 \(\lambda_{\max}(C|_{S_p})=2\log p+O(1)\)，真实主压缩最低谱值留在常数量级。
- [固定素数柱状轮廓的正 Weil 极限](notes/793-fixed-prime-cylinder-profiles-have-positive-squarefree-two-arm-weil-limits.md)；
  有限多个素数占据状态的任意固定轮廓具有精确三态张量极限且严格为正；自然调和权并非其中的最优轮廓。
- [平方自由双臂图的对数坐标 Dirichlet 极限](notes/794-squarefree-two-arm-logarithmic-coordinate-dirichlet-limit.md)；
  任意固定非恒定宏观对数轮廓的能量主项为 \(\log p\) 倍的 \(2I-P_1-P_2\) 二次型，只有常数轮廓留在常数量级临界带。
- [全 Farey 阶跃偶极的正 Archimedean 余项](notes/795-full-farey-dipole-archimedean-remainder-is-uniformly-positive.md)；
  note 791 的有界余项进一步满足 \(E_p\succeq(\log(729/512)-\zeta(3)/8-o(1))I>0\)；算术常数项与完整补空间 Schur 反馈仍决定局部 Weil 符号。
- [整个平方自由双臂 Farey 主压缩的正谱隙](notes/796-entire-squarefree-two-arm-farey-compression-has-a-uniform-positive-gap.md)；
  根 \(4/3\) 的全部平方自由双臂向量满足 \(P_{S_p}A_{p^2,-}P_{S_p}\succeq(\kappa-o(1))I\)，其中 \(\kappa>1/5\)；完整旧奇空间的 Schur 反馈仍未控制。
- [素数调和行界与强化的平方自由双臂谱隙](notes/797-uniform-prime-harmonic-bound-strengthens-the-squarefree-farey-gap.md)；
  统一不等式 \(\sum_{5\le q\le t}(\log q)/q\le\log t\) 将同一整个主压缩的下界加强到 \(\kappa_*-o(1)\)，其中 \(\kappa_*>9/5\)。
- [所有固定双臂根的平方自由 Farey 正谱隙](notes/798-all-fixed-two-arm-squarefree-farey-roots-have-positive-gaps.md)；
  任意固定互素 \(a,b\ge2\) 的完整平方自由双臂后代主压缩满足 \(P_{S_{a,b,p}}A_{p^2,-}P_{S_{a,b,p}}\succeq(1-\gamma_E-\log\pi+\log(ab)+\delta_0-o(1))I\)，下界常数统一大于 \(1\)。
- [全 Farey 内区主压缩的统一正谱隙](notes/799-full-farey-bulk-compression-has-a-uniform-positive-gap.md)；
  对任意 \(T_p\to\infty\)、\(T_p=o(p)\)，全部既约分子、分母不超过 \((p-1)/T_p\) 的偶极主压缩满足 \(A_{p^2,-}\succeq(1+\gamma_E-\log\pi+\delta_0-o(1))I\)。取 \(T_p=\log p\) 时，该内区捕获自然 Farey 调和权的渐近全部平方质量；全 Farey 扩展见 note 804。
- [真实 Möbius 谐波重合支付低既约频率](notes/800-true-mobius-harmonic-collisions-pay-low-reduced-reciprocal-frequencies.md)；
  统一互素 Möbius 调和界使 \(q\le Y^{4/5}\) 的既约倒数频率消去原始 \(\log(N/q)\) 系数，并给固定截断的 \(O(Y^2\log^3Y)\) 均方界。
- [精确 Poisson 核支付完整固定截止的低频与大分子](notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md)；
  无余项 Fourier 公式将低既约分母的支付延伸到 \(d\le Y\)，并对任意 \(|c_d|\le1\) 支付既约分子 \(a\ge Y^{1/3}\)。
- [移动截止的完整 \(k=2\) residual 缩域](notes/802-moving-cutoff-log-zero-pays-low-farey-frequencies-in-full-k2-residual.md)；
  对真实 \(d<N\) 截断，除 \(q>Y^{4/5},\ a<Y^{1/3}\) 扇区外的全部频率具有 \(O(Y^2\log^5Y)\) 均方能量；剩余扇区的 RH 强度 signed covariance 仍未证明。
- [全 Farey 外区块的对数谱隙与自然方向的正 Schur 余量](notes/803-farey-exterior-block-has-logarithmic-gap-and-natural-schur-direction-stays-positive.md)；
  对 \(Q=\lfloor(p-1)/\log p\rfloor\)，外区主压缩谱底至少为 \(\log p-O(\sqrt{\log p}\log\log p)\)。消去全部外区 Farey 偶极后，自然内区调和权的 Schur 余量趋于 \(1+\gamma_E-\log\pi+\log2>0\)。
- [整个全 Farey 阶跃偶极主压缩的统一正谱隙](notes/804-full-farey-step-dipole-compression-has-uniform-positive-gap.md)；
  对所有既约 \(1\le b<a<p\) 的偶极及其任意线性组合，\(P_{W_p}A_{p^2,-}P_{W_p}\succeq(1+\gamma_E-\log\pi+\delta_0-o(1))I\)。这闭合全 Farey 内外块，仍未控制无限维补空间 Schur 反馈。
- [密集 Farey 常值槽与阶跃偶极的联合正压缩](notes/805-dense-farey-constant-slots-have-attraction-and-positive-joint-compression.md)；
  一个约 \(p^2\) 维的正交常值奇槽族在 Archimedean 余项中有 \(-\Omega(\log p)\) 的显式方向，但其完整旧奇算子压缩仍有 \(\log p-O(1)\) 谱隙。更广地，固定 \(R>1\) 且 \((u_p-1)\log p\to\infty\) 时，全部 \(u_p\le x\le R\) 的 Farey 常值槽谱隙至少为 \((2-2/u_p)\log p-O_R(1)\)，与全阶跃偶极联合后保留 note 804 的渐近正谱隙；可选到包含任意接近全数的常值 Farey 槽。遗漏槽及无限维补空间的 Schur 反馈仍未控制。
- [全部有界 Farey 常值槽的双对数谱隙](notes/806-all-bounded-farey-constant-slots-have-loglog-gap-and-positive-joint-compression.md)；
  对每个固定 \(R>1\)，所有 \(1<x\le R\) 的常值奇槽压缩有 \(\log\log p-\log\log\log p-O_R(1)\) 谱隙；近对角与远斜率间的跨界块由有界 Hilbert 矩阵支付。更强地，若 \(R_p\to\infty\) 且 \(R_p\log(2R_p)=o(\log\log p)\)，则 \(1<x\le R_p\) 的全部常值槽与全阶跃偶极联合后仍保留 note 804 的渐近正谱隙，一次覆盖渐近全数的常值槽。余下槽、其余槽轮廓和无限维补空间仍待控制。
- [全 Farey 常值奇槽自然算术模态的对数能量](notes/807-natural-farey-constant-mode-has-two-thirds-logarithmic-energy.md)；
  在全部 Farey 常值奇槽上，算术异臂边相对阶跃偶极反号，形成带符号图平方项。整个纯算术矩阵 \(D_pI-C_{\parallel}+C_{\times}\) 有 \(1+\gamma_E-\log\pi-o(1)>0\) 的谱隙；自然权 \(v_{a/b}=(ab)^{-1/2}\) 的真实旧奇形式 Rayleigh 商至少为 \((2/3)\log p-O(\log\log p)\)。这仍不控制完整常值扇区的谱底或无限维补空间。
- [全 Farey 常值槽 polar 投影的正对数能量](notes/808-full-farey-constant-polar-projection-has-positive-logarithmic-energy.md)；
  真实 polar 向量在全部常值奇槽上的投影 \(S_p=P_{T_p}s_k\) 满足 \(A_{p^2,-}[S_p]/\|S_p\|^2\ge(1/2-3/\pi^2)\log p-O(\log\log p)>0\)。分子素数幂边的带符号平方项支付了 polar 秩一扣款；此为单向量结论，未给整族或无限维补空间的正性。
- [polar 主质量所在的 Farey 外区与小分子内区谱隙](notes/809-polar-heavy-farey-exterior-and-small-numerator-slots-have-growing-gaps.md)；
  对 \(Q=\lfloor(p-1)/\log p\rfloor\)，全部 \(a>Q,\ a/b>\log p\) 的常值槽主压缩有 \((1-3/\pi^2)\log p-O(\sqrt{\log p}\log\log p)\) 谱隙，并承载 polar 投影的渐近全部平方质量；全部 \(a\le Q\) 的常值槽有 \(2\log\log p-O(1)\) 谱隙。两块各自与全阶跃偶极联合正定；两块之间及无限维补空间的 Schur 耦合仍未控制。
- [全部 Farey 常值槽的三个增长谱隙主块](notes/810-three-growing-gap-blocks-cover-all-farey-constant-slots.md)；
  固定斜率阈值 \(r=3\) 与分子阈值 \(Q\) 将全部常值槽不交地分成 \(x\le3\)、\(x>3,a\le Q\)、\(x>3,a>Q\) 三块。它们各自有增长谱隙，第三块有 \((1-2/3-3/\pi^2)\log p-o(\log p)\) 谱隙、\(\asymp p^2\) 维且承载 polar 投影的渐近全部质量；每块各自与全阶跃偶极联合正定。三块之间的算术交叉及无限维补空间仍未控制。
- [全部 Farey 常值槽的非算术跨块支付](notes/811-nonarithmetic-cross-blocks-are-paid-in-full-farey-constant-slots.md)；
  在上述三块之间只移除素数幂算术交叉时，保留完整 Archimedean 核、polar 秩一项和块内算术边的全常值槽压缩仍有 \(\log\log p-\log\log\log p-O(1)\) 谱隙，并与全阶跃偶极联合正定。真实有限压缩尚缺三块之间的带符号素数幂交叉预算；无限维补空间另需真 Schur 控制。
- [固定有理槽的两条素数臂排除统一块范数 Schur 比较](notes/812-fixed-rational-prime-arms-defeat-uniform-farey-block-schur-bound.md)；
  任一固定 \(1<x<r\) 的常值槽向外区发出同臂与异臂两条素数臂，使跨块算术行范数平方至少为 \((2+o(1))\log p\log\log p\)。这超过 note 810 两个统一块谱隙的乘积，故仅靠统一最小谱值与交叉范数不能合并它们；未构造真实负方向。
- [深分子内区与 polar 主质量外区的真实联合谱隙](notes/813-deep-interior-and-polar-exterior-joint-farey-gap.md)；
  固定 \(r>2/(1-3/\pi^2)\)，\(\gamma_r=1-2/r-3/\pi^2\)。若 \(S\le(p-1)/\log p\) 且 \(\log((p-1)/S)\ge(1/\gamma_r+\eta)\log\log p\)，则全部 \(a\le S\) 的深内区常值槽与 \(a>(p-1)/\log p,\ a/b>r\) 的 polar 主质量外区保留真实算术交叉后，联合主压缩仍有 \((2\eta-o(1))\log\log p\) 谱隙，并可与全 Farey 阶跃偶极联合；例如 \(r=12,\ S=\lfloor(p-1)/(\log p)^2\rfloor\)。中间分子边界层、其他高分子低斜率槽及无限维补空间仍未控制。
- [带符号 Farey 内外算术交叉范数的尖锐两臂常数](notes/814-sharp-signed-farey-interior-exterior-arithmetic-cross-norm.md)；
  对每个 \(2\le S\le Q\)，note 813 的真实带符号算术跨块矩阵均满足 \(\|C^-_{E_rI_S}\|^2=(2+o(1))\log p\log\log p\)，其非负单坐标矩形同时满足 \(\|K_{U,L}\|^2=(1+o(1))\log p\log\log p\)。固定槽 \(x=2\) 已使两臂首项尖锐；推进到更浅内区须利用源位置的真实能量或同一二次型中的带符号平方项与真逆响应。
- [渐近全部平衡内区常值槽与 polar 外区的真实联合谱隙](notes/815-balanced-interior-collar-and-polar-exterior-joint-gap.md)；
  令 \(H=\log p\)、\(Q=\lfloor(p-1)/H\rfloor\)，取 \(A\to\infty\)、\(A=o((\log H)^2)\)。全部 \(a\le Q,\ b\ge Q/A\) 的常值槽占内区槽数的 \(1-o(1)\)，与固定 \(r>2/(1-3/\pi^2)\) 的 polar 外区保留真实算术交叉后有 \((2-o(1))\log H\) 联合谱隙，并可与全 Farey 阶跃偶极联合。内区小分母尾、外区低斜率槽及无限维补空间仍未控制。
- [深内区、平衡内区与 polar 外区的真实联合谱隙](notes/816-deep-and-balanced-interior-joint-polar-gap.md)；
  对 \(\alpha>1+1/\gamma_r\)，将全部 \(a\le(p-1)/H^\alpha\) 的深内区槽加入 note 815 的平衡内区和 polar 外区，真实联合主压缩仍有 \((2-o(1))\log H\) 谱隙，也可与全 Farey 阶跃偶极联合。深内区和平衡内区间没有素数幂算术边，因此固定槽 \(2/1\) 与渐近全部内区槽可同时纳入；中间小分母尾及无限维补空间仍未控制。
- [中间小分母尾仍有临界阶的真实算术跨块范数](notes/817-intermediate-small-denominator-tail-has-critical-cross-norm.md)；
  note 816 遗漏的 \(S<a\le Q,\ b<T\) 尾部虽占内区槽数的消失比例，其到 polar 外区的真实带符号素数幂交叉仍满足 \(\|C^-_{E_rM_p}\|^2\asymp_r H\log H\)。分子 \(Q/2<a\le Q\) 的自然权向量在指定外区矩形上有精确响应比 \((1+o(1))H\log H\)；必须利用尾部自身能量、带符号图平方项或外区真逆响应，不能凭槽数比例忽略这块。
- [渐近全部上分子内区与 polar 外区的线性联合谱隙](notes/818-upper-numerator-farey-interior-linear-joint-polar-gap.md)；
  固定 \(1<\beta<3\)、\(R=\lfloor(p-1)/H^\beta\rfloor\) 时，全部 \(R<a\le Q\) 的内区常值槽自身有 \(H-o(H)\) 谱隙，与 polar 外区 \(E_r\) 保留真实算术交叉后有 \((\gamma_r-o(1))H\) 联合谱隙，并可加入全 Farey 阶跃偶极。该族占 \(I_Q\) 的 \(1-o(1)\)，没有分母下限，包含 note 817 的临界向量；与 \(a\le R\) 深区合并仍需支付内区交叉和共同外区 Schur 预算。
- [深区—上分子内区的尖锐交叉及真实三块联合谱隙](notes/819-sharp-deep-upper-interior-cross-and-joint-gap.md)；
  对任意固定 \(\beta>1\) 与 \(2\le S\le P/H^\beta\)，深区 \(a\le S\) 到上分子内区 \(P/H^\beta<a\le Q\) 的真实带符号素数幂交叉范数平方一致为 \((2(\beta-1)+o(1))H\log H\)，固定槽 \(2/1\) 的两条素数臂达到首项。对 \(1<\beta<3\)、\(\alpha>\beta-1+1/\gamma_r\)，全部 \(a\le P/H^\alpha\) 与上分子内区、polar 外区保留真实交叉后仍有 \((2(\alpha-\beta+1-1/\gamma_r)-o(1))\log H\) 联合谱隙，并可加入全 Farey 阶跃偶极；若深区仅至 \(P^\theta\)，则有线性谱隙。仍缺两个阈值之间的中间分子带及无限维补空间。
- [分子环边界平方项支付中间高斜率走廊](notes/820-dyadic-numerator-annuli-pay-high-slope-interior-corridor.md)；
  对任意固定 \(\alpha>1\)，所有 \(P/H^\alpha<a\le Q\)、\(a/b\ge2\) 的内区常值槽自身有 \(H-o(H)\) 谱隙，与 polar 外区保留真实算术交叉后有 \((\gamma_r-o(1))H\) 联合谱隙。证明把分子分成 \(O(\log H)\) 个二进制环，每环由分子素数幂除法的边界平方项支付 \(H-O(\log H)\)，环间交叉仅 \(O(\sqrt H)\)。固定 \(1<\beta<3\)、\(\alpha>\beta\) 时，还可把 \(P/H^\beta<a\le Q\) 的全部斜率槽一起加入；中间走廊的近对角斜率 \(1<a/b<2\)、深区共同 Schur 预算及无限维补空间仍开放。
- [全部近对角内区槽加入高斜率上分子带与 polar 外区](notes/821-near-diagonal-farey-slots-join-high-slope-interior-and-polar-exterior.md)；
  固定 \(\alpha>1\) 时，所有 \(a\le Q,\ 1<a/b<2\) 的近对角槽到 \(P/H^\alpha<a\le Q,\ a/b\ge2\) 的真实带符号算术交叉仅 \(O_\alpha(\sqrt{H\log H})\)。它们与 polar 外区共同保留 \((\gamma_r-o(1))H\) 谱隙，且可加入全部 Farey 阶跃偶极；内区仅余 \(a\le P/H^\alpha,\ a/b\ge2\) 的深高斜率槽尚未支付。
- [整个 Farey 外区加入近对角与上分子内区](notes/822-entire-farey-exterior-joins-near-and-upper-interior-with-growing-gap.md)；
  对固定 \(\alpha>1\)，外区 \(a>Q\) 的全部斜率槽与 note 821 的内区族保留真实算术交叉后，联合主压缩仍有 \(\log H-\log\log H-O_{\alpha,r}(1)\) 谱隙，并可加入全阶跃偶极。外区有界斜率到高斜率块的算术范数仅 \(O_r(\sqrt H)\)；全 Farey 常值槽只余 \(a\le P/H^\alpha,\ a/b\ge2\) 的深高斜率槽未纳入，非恒定轮廓及无限维补空间另待处理。
- [幂次深高斜率槽加入整个 Farey 外区](notes/823-subpower-deep-high-slope-farey-slots-join-the-entire-exterior.md)；
  固定 \(0<\theta<(\sqrt5-1)/2\)、\(A=\lfloor(p-1)^\theta\rfloor\) 时，全部 \(a\le A,\ a/b\ge2\) 的深高斜率槽与 note 822 的内区、整个外区保留真实交叉后仍有 \(\log H-\log\log H-O(1)\) 谱隙，并可加入全阶跃偶极。全 Farey 常值槽仅余 \(A<a\le P/H^\alpha,\ a/b\ge2\)；非恒定轮廓及无限维补空间另待控制。
- [中分子适中斜率槽加入整个 Farey 外区](notes/824-moderate-slope-middle-farey-slots-join-the-entire-exterior.md)；
  在 note 823 的联合空间中再加入 \(A<a\le S=\lfloor(p-1)/H^\alpha\rfloor,\ 2\le a/b\le\lfloor H/2\rfloor\) 的全部槽，保留相同的线性主块谱隙、完整外区的 \(\log H-\log\log H-O(1)\) 谱隙及全阶跃偶极正性。全 Farey 常值槽仅余 \(A<a\le S,\ a/b>\lfloor H/2\rfloor\)；全尺度局部正性及 moving-\(N\) 算术门仍开放。
- [增长近对角根族的双素数臂真 Schur 响应](notes/825-growing-near-diagonal-farey-roots-have-explicit-prime-descendant-response.md)；
  对任意固定 \(0<\delta<\theta/2<1/2\)，分子至多 \(p^\delta\) 的全部近对角根与其落在中分子高斜率遗漏带的两条素数子臂，真实联合主压缩的谱底为 \((2-\sqrt{1-\theta^2})H+O(\log H)\)。消去这些素数子槽后，逐根 Schur 主项为 \(\frac{1-\theta}{2}H(1+\theta-\log(ab)/H)\)，根余量仍有线性正隙；移动根、合数后代和完整补空间的共同响应仍未控制。
- [固定根的移动双素数网格的显式二代响应](notes/826-two-prime-moving-near-farey-mesh-has-explicit-schur-and-spectral-shifts.md)；
  固定 \(x\in(1,2)\) 时，将两条素数臂与 \(z_{q,r}=xq/r\in(1,2)\) 的移动近对角层一同纳入真实常值奇槽压缩，最低谱仍为 \((2-\sqrt{1-\theta^2})H+O(\log H)\)。相对第一代，根的真 Schur 扣款精确增加 \(\frac{\log2}{6}(1-\theta^3)+o(1)\)，最低谱精确下降 \(\frac{2\log2}{3}(1-\theta^3)/(1-\theta^2)^{3/2}+o(1)\)；无限维补空间与 moving-\(N\) signed covariance 仍未支付。
- [高斜率双素数后代强制线性真 Schur 响应](notes/827-high-slope-two-prime-descendants-force-linear-true-schur-response.md)；
  同一固定根的 \(z_{q,r}=xq/r>H/2\) 槽位于 note 824 遗漏的高斜率带，并承载两亲子 forcing 的渐近全部 \(H^4\) 主质量；把它们加入真实主压缩后，相对第一代的根 Schur 扣款满足 \(\liminf (R_{V^{\rm hi}}-R_B)/H\ge(1-\theta^2)^2/32\)，此下界也传递到完整小分子内区的根响应。仍未估计完整遗漏带的谱底、无限维补空间或 moving-\(N\) signed covariance。
- [槽外全轮廓中心化素数算子有线性负谱](notes/828-exterior-prime-hankel-centered-spectrum-has-linear-negative-tail.md)；
  真正素数移位在该槽外空间是有限个反射的正核和。高频调制使其本质谱包含正负范数端点；与连续密度秩一项的自然 Rayleigh 方向合用，严格得到中心化算子的谱底至多为 \(-\bigl(3\log2/(256\zeta(2))+o(1)\bigr)p\)。因此不能对全部槽轮廓单独要求 \(O(\log p)\) 的负谱下界；高频 Archimedean 成本尚未支付，完整 Weil 正性与 RH 仍开放。
- [槽外重叠权的 Mellin 无零带与显式零点展开](notes/829-exterior-overlap-mellin-weight-zero-free-growing-band.md)；
  重叠权的 Mellin 变换精确因子化，且在 \(\delta\le\Re s\le1-\delta\)、\(|\Im s|\ll_\delta p^{1/6}(\log p)^{-1/3}\) 无零；素数幂加权短窗有绝对收敛的零点展开。其真实素数短窗误差见 note 830。
- [槽外真实素数 Rayleigh 值的无条件主项](notes/830-exterior-prime-rayleigh-has-unconditional-main-term.md)；
  固定窗口的 Sobolev 零点采样、Vinogradov--Korobov 零自由区及高频尾界给出 \(r_p=k_p+O(pe^{-c(\log p/\log\log p)^{1/3}})\)，将中心化素数算子的负谱上界加强到 \(-(3\log2/(128\zeta(2))+o(1))p\)。对每个固定 \(M>0\)，总变差至多 \(\exp(\kappa_M(\log p)^{3/2}/(\log\log p)^2)\) 的单位实轮廓满足 \((R_p-K_p)[a]=O_M(p/(\log p)^M)\)；自然向量的余弦调制若达到负线性值，频率须大于 \(\exp(\kappa(\log p)^{3/2}/(\log\log p)^2)\)，其中 \(\kappa>0\) 固定。完整 Weil 形式的 Archimedean 成本及 moving-\(N\) 算术门仍开放。
- [任意槽中心的稀疏对称支撑 Weil 正谱隙](notes/852-arbitrary-center-sparse-local-weil-positivity.md)；
  在 \(k=p^2\)、上臂固定比例带内，任取至多 \(p/32\) 个长度不超过 \(\log(1+p^{-2})\) 的相离区间及其反射，无需有理中心或 Farey 间距，完整 Weil 形式对该支撑上的全部有限能量轮廓有至少 \((\log p)/3\) 的谱隙。证明使用支撑测度的 Fourier 下界、每对槽至多一个整数位移及奇偶分解；它不控制与其余空间的 Schur 交叉，也不推出 RH。
- [超窄任意槽的素数四环排除与完整 Weil 压缩谱隙](notes/853-ultranarrow-prime-c4-free-weil-positivity.md)；
  将槽宽缩至 \(1/(100p^4)\)、中心间距设为至少三倍槽宽后，允许至多 \(p^2/256\) 个任意中心槽及其反射；完整形式在该支撑上的谱底至少为 \((2-\sqrt2)\log p-O(1)\)。素数反射槽图无四环，故其范数仅为 \(O(\sqrt M)\)；补空间交叉与 moving-\(N\) 算术门仍未解决。
- [整数对数格上完整 Weil 形式的宽度一致谱隙](notes/854-integer-log-lattice-sharp-weil-spectral-gap.md)；
  对贯穿 \((-\log p,\log p)\) 的 \(\lfloor p^2/16\rfloor\) 个整除槽，只要宽度 \(0<\ell\le(100p^2\log p)^{-1}\)，全部有限能量轮廓的压缩谱底一致为 \(\log(1/\ell)-\log N+O(1)\)。最大允许宽度的支撑测度为 \(\asymp1/\log p\)，谱底为 \(\log\log p+O(1)\)；固定质量宽度 \(\ell=c/p^2\) 的试函数给谱底有界上界。整除矩阵前任意固定多个本征值均为 \(\log N+O(1)\)，不能假定首本征值有增长的谱隙。超窄宽度下根槽与格内素数后代的单位向量交叉达 \(\log p+O(1)\)；外部补空间响应与全尺度正性仍未解决。
- [固定正测度整数对数格上的完整 Weil 压缩谱隙](notes/855-fixed-positive-mass-integer-log-grid-weil-gap.md)；
  通过指数倾斜的整除图 Schur 权，固定质量宽度 \(\ell=c/p^2\) 的全部有限能量轮廓仍满足 \(\lambda(U)=\log(1/\ell)-\log N+O(1)\)，其中 \(|U|\to c/16>0\)；足够小的固定 \(c\) 给统一正隙。这仍是压缩定理。
- [外侧整除层给固定质量 Weil 格的精确变分扣款](notes/856-exterior-divisibility-layer-gives-nonzero-weil-variational-feedback.md)；
  外侧整数层与内部自然轮廓有 \(\asymp\sqrt{\log N}\) 的真实 Weil 交叉；普通核经精确 Cauchy 核恒等式求和后，外侧成本主项给出变分扣款极限 \(\log4-3\kappa^2c/16>0\)。完整补空间的 true-Schur 符号及全尺度正性仍未知。
- [最大整数对数格自然轮廓的完整 Weil 形式极限](notes/857-maximal-integer-log-grid-exact-weil-rayleigh-limit.md)；
  对 \(M=(p^2-5)/4\)、\(\ell=c/p^2\)、\(0<c<4\)，完整 Rayleigh 极限为 \(\log(4/c)+C_\varphi+\gamma-\log(2\pi)+c(\int\varphi)^2/4\)。其单位区间负方向判据已由 note 858 排除。
- [单位区间对数形式的秩一严格谱隙](notes/858-unit-interval-logarithmic-form-has-a-strict-rank-one-gap.md)；
  显式偶、奇正超解与非负半区间跳核给 \(C_\varphi+|\int\varphi|^2\ge(46/25-\gamma)\|\varphi\|_2^2\)，严格高于 note 857 负方向阈值；因此该自然轮廓族的完整 Weil Rayleigh 极限有统一正隙。
- [固定素数赋值轮廓保留最大整数格 Weil 极限正隙](notes/859-fixed-prime-valuation-profiles-retain-maximal-weil-grid-gap.md)；
  对任意固定有限素数集及其截断赋值柱状系数，整除图罚项至少为 \(2\log2\) 倍系数方差，完整 Weil Rayleigh 极限仍至少为 \(46/25-\log(2\pi)>0\)。随尺度增长的调制、任意槽系数、补空间和全尺度正性仍未判定。
- [随尺度变化的固定素数赋值轮廓仍保留最大整数 Weil 格正隙](notes/860-varying-prime-valuation-profiles-retain-maximal-weil-gap.md)；
  对任意随尺度变化的有界赋值轮廓，只要固定素数集且归一化浓度满足 \((1+\log R)^2=o(\log M)\)，完整 Weil 极限仍有至少 \(46/25-\log(2\pi)\) 的正隙；证明同时给出赋值序列 Cauchy 自相关的统一 \(O(M)\) 余项。更稀疏轮廓及增长素数集不在此定理内。
- [真实 Möbius 系数使最大整数 Weil 格的 Rayleigh 值对数发散](notes/861-mobius-maximal-weil-grid-rayleigh-growth.md)；
  在相同最大整数格取槽系数 \(\mu(n)\) 时，整除 prime-shift 二次型为 \(-\zeta(2)^{-1}(\log M)^2+O(\log M)\)，完整 Weil Rayleigh 值为 \(2\log M+O(1)\)。moving-\(N\) 协方差中的全部整除对可无符号支付到 \(O(Y^2\log^2Y)\)；剩余的非整除加性配对仍未估计。
- [任意移动素数平方筛轮廓的最大整数 Weil 格正隙](notes/862-arbitrary-moving-prime-square-sieves-retain-maximal-weil-gap.md)；
  对可随 \(p\) 任意改变、甚至无限的素数集合，平方排除指标 \(T_p(n)=\prod_{q\in\mathcal P_p}\mathbf1_{q^2\nmid n}\) 的完整 Weil Rayleigh 值有一致极限，且至少为 \(46/25-\log(2\pi)-o(1)>0\)；特别覆盖真实平方自由指标 \(\mu^2(n)\)。这不支付 \(\mu(n)\) 的符号或 moving-\(N\) 非整除协方差。
- [对数级周期的最大宽整数 Weil 格统一正隙](notes/866-periodic-weil-grid-gap-through-logarithmic-periods.md)；
  任意预定 \(P_{\max}=o(\log N)\) 的增长周期及每槽随尺度任意变化的微观轮廓，在最大槽宽仍有至少 \(46/25-\log(2\pi)-o(1)\) 的完整 Weil 压缩正隙；某个固定比例 \(P\le c_*\log N\) 亦有严格正隙。结论不涉及槽外 true-Schur 交叉或 moving-\(N\) Möbius signed covariance。
- [线性对数阶宏观 Fourier 轮廓保持 Weil 正隙](notes/867-macroscopic-fourier-weil-gap-through-linear-logarithmic-order.md)；
  在最大宽整数格的固定素数赋值与共同微观轮廓族中，存在固定 \(c_*>0\)，使全部最高阶数 \(r\le c_*\log N\) 的对数 Fourier 多项式线性组合严格为正；在 \(r=o(\log N)\) 时低本征值还收敛到固定赋值算子的正谱。该压缩不控制槽外补空间或 moving-\(N\) 算术门。
- [固定余数类与微观轮廓的线性对数阶 Fourier–Weil 正隙](notes/868-fixed-residue-microprofile-fourier-weil-gap.md)；
  对固定周期 \(P\) 和固定有限维微观轮廓空间，允许每个余数类的宏观 Fourier 系数及微观轮廓独立变化；在 \(r\le c_*(P,W,\theta)\log N\) 的整个联合空间上，完整局部 Weil 主压缩仍有严格正隙。unit 素数幂的连续主项只消去单位群不变的宏观常数块，后者由 note 866 支付；槽外 true-Schur 与 moving-\(N\) 门仍开放。
- [完整 moving-\(k=2\) Farey 余项的六分之五端点裁剪](notes/831-moving-k2-farey-gate-pays-five-sixths-endpoint-collar.md)；
  note 802 的高分母、小分子余项按原始除数 \(d\) 裁去 \(N-\lfloor Y^{5/6}\rfloor<d<N\) 后，差的均方仍为 \(O(Y^2\log^5Y)\)。二阶端点零点与精确 Poisson 尾界支付此层；\(5/6\) 对任意有界系数的无符号支付是尖锐的。剩余 moving-\(N\) Möbius signed covariance 未受控。
- [移动 \(k=2\) 余门的斜楔缩域](notes/832-sloping-numerator-gate-for-moving-k2-farey-residual.md)；
  在分母带 \(R<q\le2R\) 无符号支付分子 \(a\ge\max\{3,\lceil R^{5/3}/Y^{4/3}\rceil\}\)，并裁去 \(N-\lfloor Y^{5/6}\rfloor<d<N\) 的物理端点。所得斜楔余项与完整 \(k=2\) residual 的差均方为 \(O(Y^2\log^7Y)\)；斜楔内部的 moving-\(N\) Möbius signed covariance 仍未估计。
- [移动 Farey 短分母块内的真实素数--合数负协方差](notes/833-prime-composite-covariance-within-a-moving-farey-denominator-block.md)；
  在 \(q\asymp Ye^{-a\omega(Y)}\) 的同一短块中，全部同频 Möbius 倍数合并后，素数频率仍有显式 \(Y^{3-o(1)}\) 能量，合数频率与之产生等量负协方差。固定 \(5/6<\alpha<1\) 时，\(q\asymp Y^\alpha\) 的素数块能量仍至少为 \(Y^{6\alpha-3}/\log^2Y\)；完整 \(Y^{2+\varepsilon}\) 均方门尚未证明。
- [固定幂尺度滑动 Farey 块的无条件素数--合数负协方差](notes/834-fixed-power-sliding-farey-block-prime-composite-covariance.md)；
  对每个固定 \(5/6<\alpha<1\)，存在一个长度 \(B\asymp Y^{2\alpha-1}/\log^2Y\)、分母 \(q\asymp Y^\alpha\) 的块；同频倍数合并后的素数能量为 \(\asymp_\alpha Y^{6\alpha-3}/\log^6Y\)，同块合数频率无条件产生等量负协方差。该存在性结论不估计完整斜楔余项的均方。
- [每个固定幂 Farey 短块的真实负协方差](notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md)；
  对所有固定 \(5/6<\alpha<1\) 及每个长度 \(B\asymp Y^{2\alpha-1}\)、分母 \(q\asymp Y^\alpha\) 的块，短区间 Möbius 强误差使同块完整频率和逐 \(N\) 小于素数部分；后者能量为 \(\asymp_\alpha Y^{6\alpha-3}/\log^2Y\)，故每块的素数--合数跨频率负协方差无条件具有等量主规模。跨块联合及完整 moving-\(N\) 算术门仍未控制。
- [固定幂 Farey 分母带的复权算子界与素数源负协方差](notes/836-fixed-power-farey-band-operator-and-prime-covariance.md)；
  任意固定 \(4/5<\alpha<1\) 的不交相干短块满足任意复权的对数幂算子节省；固定密度素数块源与整条同分子带的补集产生等量负协方差。分子 \(1\) 的 \(Y^{4/5}<q\le Y^{4/5}\log^C Y\) 领可从真实斜楔门中移除；固定幂整带上界仍为 \(D^5Y^{-2}\) 乘任意对数幂节省，未达到 \(Y^{2+\varepsilon}\) 门。
- [对数宽度 Farey 领内全部斜楔分子的无条件支付](notes/837-all-sloping-numerators-in-a-logarithmic-farey-collar.md)；
  对任意固定 \(C,A>0\)，真实斜楔中 \(Y^{4/5}<q\le Y^{4/5}\log^C Y\) 的**全部允许分子**合计均方为 \(O_{C,A}(Y^2\log^{-A}Y)\)。互素掩码的卷积、按分子缩短的相干块和物理截止共同给出此界；完整 moving-\(N\) 门缩至更高分母，固定幂带的 signed covariance 仍待控制。
- [九分之八尺度前的首阶 Farey 模型保留物理截止精度](notes/838-eight-ninths-first-order-farey-model-with-physical-cutoff.md)；
  对不随 \(N\) 变化的任意既约频率集合与 \(|c_d|\le1\)，在 \(Y^{4/5}\le D\le Y^{8/9}\) 的每条分母带，精确物理 Poisson 核与保留 \(c_{kq}\)、移动截止 \(kq<N\) 的首阶奇偶模型之差均方为 \(O(Y^2\log^5Y)\)。首阶模型的真实 Möbius signed covariance 仍未估计。
- [九分之八无符号 Poisson 比较的固定幂尖锐性](notes/839-sign-blind-eight-ninths-is-sharp-for-first-order-farey-comparison.md)；
  对每个固定 \(8/9\le\alpha<1\)，存在固定的分子 \(1\) 频率集合和 \(c_d=1\)，使精确物理核与首阶模型之差均方 \(\gg_\alpha D^9\log^4Y/Y^6\)（\(D=\lfloor Y^\alpha\rfloor\)）。因此任何更大固定幂指数的统一有界系数替换都不成立；真实 \(\mu\) 的替换与完整 moving-\(N\) 门仍待判定。
- [同相 Farey 素数臂的真实跨分子负协方差](notes/840-resonant-farey-prime-arms-have-negative-cross-numerator-covariance.md)；
  在固定 \(5/6<\alpha<1\) 的两条分子 \(2,3\) 短块，真实素数源的交叉主项为 \(-9D^2B^2/(160\pi^2Y\log^2D)\)，且权 \(10/9:1\) 消去共同载波；同块完整 Möbius 和有任意对数幂节省，故非素数补集给出相应负协方差。跨块、全分子和完整 moving-\(N\) 门仍待控制。
- [增长素数分子族的同相 Farey 源与真实 Möbius 补集](notes/841-growing-prime-numerator-farey-coherence-and-mobius-complement.md)；
  对固定 \(5/6<\alpha<1\)、\(0<\gamma<(6\alpha-5)/4\)，约 \(Y^\gamma/\log Y\) 条奇素数分子臂的真实素数源具有近秩一 Gram，合计均方主项为 \(\frac{25}{144\pi^2}D^6/[A^4Y^3(\log Y)^2(\log D)^2(\log A)^2]>Y^{2+\varepsilon}\)；同块完整 Möbius 和有任意对数幂节省，故与非素数补集的协方差为素数源能量的负值加相对 \(o(1)\)。跨块联合与完整 moving-\(N\) 门仍开放。
- [整个增长整数分子带的平均互素支付与真实负协方差](notes/842-entire-growing-numerator-farey-tube-has-average-coprimality-cancellation.md)；
  在相同固定 \(\alpha,\gamma\) 范围内，把 note 841 的素数分子扩为约 \(A=Y^\gamma\) 个连续整数分子。互素卷积核的分子平均由收敛 Euler 乘积支付；偶奇素数源合计均方主项为 \(D^6/[144\pi^2A^4Y^3(\log Y)^2(\log D)^2]>Y^{2+\varepsilon}\)，且整个同相管的真实 Möbius 和有任意对数幂节省，故源与补集有等量负协方差。该结果仍不估计其他频率管及完整斜楔的联合 Gram。
- [全部次端点分母带的上分子对数领支付](notes/843-upper-sloping-numerator-collar-below-subendpoint.md)；
  对 note 832 的全部实际二进制分带 \(Q\le R_j\)、\(2R_j\le Y^{1-\delta}\)，令 \(U_j=\max\{3,\lceil R_j^{5/3}/Y^{4/3}\rceil\}\)。真实斜楔中 \(U_j/(\log Y)^C\le a<U_j\) 的全部分子合计均方为 \(O_{\delta,C,S}(Y^2\log^{-S}Y)\)，跨所有这些分带相加亦然。\(U_j\le(\log Y)^C\) 的整带已支付；其余低分子及完整 moving-\(N\) signed covariance 仍未支付。
- [全部实际分母带的上分子对数领支付](notes/844-all-denominator-band-upper-numerator-collar-by-direct-mobius.md)；
  保留原始倍数 \(k\)，用真实 Möbius 的互素短块相消，免去 \(N/q\to\infty\) 的限制。对 note 832 的全部实际分带，包括 \(q\asymp Y\) 与截断末带，置 \(U_j=\min\{A,A_j\}\)，则 \(U_j/(\log Y)^C\le a<U_j\) 的真实物理 Poisson 项跨带合计均方为 \(O_{C,S}(Y^2\log^{-S}Y)\)。完整 residual 的目标门由此可等价地缩到 \(a<U_j/(\log Y)^C\)；该低分子 signed covariance 仍未控制。
- [物理末带增长分子同相管的真实负协方差](notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md)；
  对 \(0<\gamma<1/4\)、\(H=\lfloor Y^\gamma\rfloor\)，在 \(q>Y\)、\(a\asymp H\) 的同相短管中，物理截止只允许原始倍数 \(k=1\)。真实素数源的能量渐近为 \(\kappa Y^3/[H^4(\log Y)^4]\)，高于 \(Y^2\) 固定幂；整管 Möbius 和有任意对数幂节省，因此合数分母与素数源产生等量负协方差。该管属于 note 844 尚未支付的低分子斜楔；完整跨管协方差仍未控制。
- [物理末带相邻载波管的带符号素数 Gram](notes/846-terminal-carrier-prime-source-signed-cross-gram.md)；
  将 note 845 的载波改为 \((H+r)/Y\)，任意固定移位 \(r,s\) 的真实素数源交叉主项是 \(\kappa_{r-s}Y^3/[H^4(\log Y)^4]\)。相邻载波有与单管能量同阶的负交叉，隔一个载波则为正；固定有限管族的极限 Gram 仍严格正定。载波间距 \(1/Y\) 时不能按管近似正交，完整 Möbius 跨管协方差仍未估计。

## 研究单元边界

A 线、临界线比例 B 线与全局 screw-kernel C 线保持证明链独立，只共享明确标注的算子、
Krein 谱与数值认证接口。一条线的有限尺度证据不自动晋级为另一条线的定理。

并行研究单元：

- [临界线上简单零点的无条件比例](units/critical-line-proportion/README.md)：目标是严格超过
  \(0.6725007036794116\ldots\)；当前已关闭朴素向量窗口和单压缩 \(2\times2\) CGdL lift。
- [全局 screw-kernel 因子化](units/global-spectral-limit/README.md)：独立 C 线；已关闭依赖 canonical 下移的 Livšic 拟合主路线，现以显式 screw line 的亚指数双 \(L^2\) 增长为目标。其加权收敛横坐标精确等于零点最大水平偏离，Laplace 变换中的右半平面秩一极点逐一见证离线零点。

## 权威入口

- [接入时的数学边界](notes/000-cutover-2026-08-11.md)：对引用对话的有界重述；其中未核验主张不构成事实或证明。
- [局部谱底与第一次退化的文献归约](notes/001-local-weil-first-degeneration-literature-reduction.md)：基于 Suzuki 2026 全文核对后的严格入口与定义域边界。
- [第一次退化及邻接机制的前沿文献图](notes/002-first-degeneration-frontier-map.md)：截至 2026-08-11 的机制簇、路线关系与可迁移接口。
- [零延拓与全谱单调性](notes/003-zero-extension-and-full-spectrum-monotonicity.md)：证明完整闭形式定义域嵌套、全部本征值单调不增及负指标单调不减。
- [与 logarithmic Laplacian 的精确归一化](notes/004-exact-logarithmic-laplacian-normalization.md)：识别 \(D(Q_W^a)=H((-a,a))\)，并给出首次退化零模态的完整弱平移方程。
- [绝对值收缩的显式反例](notes/005-beurling-deny-obstruction-from-sign-changing-kernel.md)：由非对角核变号证明 \(a>1/6\) 时标准 positivity-preserving 基态路线失效。
- [全谱连续性与 spectral flow](notes/006-norm-resolvent-continuity-and-spectral-flow.md)：在固定区间建立 norm-resolvent 连续族，证明全部本征值连续，并把 spectral flow 识别为负指标差。
- [M2-R1 finite-shift 正则性定理](notes/007-M2R1-finite-shift-Linfinity-hinge.md)：把成对 Dirac shifts 改写成正离散跳跃项，证明零模态有界、连续并满足 \(\ell(d)^{1/2}\) 边界阶上界。
- [Collar UCP 与严格域单调归约](notes/008-collar-ucp-and-strict-domain-monotonicity.md)：证明谱底平台等价于较大区间存在 collar 支撑基态，并把唯一零尺度与立即负穿越归约到 ground-state collar UCP。
- [外侧 logarithmic flux 与平台障碍](notes/009-exterior-log-boundary-flux-obstruction.md)：计算非零 \(\ell(d)^{1/2}\) 边界系数产生的外侧发散，证明任何谱底平台都强制两个端点主系数为零并满足 Cauchy--Dini 抵消。
- [边界振荡抵消模型](notes/010-boundary-cancellation-model.md)：构造能量域内达到最优边界振幅但外侧 flux 有界的变号模型，证明边界上界本身不能排除平台。
- [Prime-free collar UCP](notes/011-prime-free-collar-ucp.md)：用 Archimedean 核的完备指数矩证明无平移空窗上的 UCP，并无条件得到 \(a<\frac12\log2\) 时对任意扩域的严格谱底下降。
- [第一次退化的秩一惯性分类](notes/012-first-degeneration-rank-one-inertia-dichotomy.md)：完整区分奇偶扇区的可见 Schur 零模态与不可见约化零核，并用 positivity-improving 四维模型证明现有抽象输入不足以排除后者。
- [约化偶谱的显式负阈值](notes/013-explicit-negative-reduced-even-spectrum.md)：用偶常函数和纯有理误差界证明 \(\mu_1(M_a^+)<-166951/5990400\) 对全部 \(a\ge1/8\) 成立，关闭约化偶谱全尺度非负路线。
- [Prime-free 奇扇区无不可见零核](notes/014-prime-free-odd-schur-reduction.md)：把奇函数折叠到半区间，证明严格正核差产生 positivity-improving 半群，并在 \(0<a\le\frac12\log2\) 与 \(A_a^-\succeq0\) 下推出 \(M_a^->0\)，从而把奇零模态严格化为单一 Schur 等号。
- [Prime-free 全谱严格尺度流](notes/015-prime-free-strict-spectral-scale-flow.md)：证明 digamma multiplier 的尺度交换子严格正且有界，从而得到全部约化本征值及奇偶扇区本征值在 \(0<a\le\frac12\log2\) 上严格下降，并给出每条解析谱支的严格负导数。
- [Prime-free 奇扇区的负 killing 障碍与 supersolution 归约](notes/016-odd-killing-obstruction-and-supersolution-reduction.md)：给出完整奇半区正跳核与 killing 势，构造 \(a=1/3\) 的显式负势反例关闭点态路线，并把全 prime-free 奇正性压缩为端点 \(a=\frac12\log2\) 上的一个 ground-state/Barta 证书。
- [Prime-free 奇扇区的 Yukawa 分解与显式正谱隙](notes/017-prime-free-odd-yukawa-gap.md)：将 digamma 乘子分为正 Yukawa 项，用 15 个一维 Robin 根与 Arb 有限证书证明 \(A_a^-\succeq0.0102I\) 于 \(0<a\le\frac12\log2\)，从而完全排除 prime-free 奇退化并证明奇 Schur 量严格为正。
- [Prime-free 偶扇区的 Yukawa--Schur 显式谱隙](notes/018-prime-free-even-yukawa-schur-gap.md)：在 Neumann 基中把偶算子写成一个单负对角算子加正边界秩和，用 20 维 Arb Schur 惯性证书证明 \(A_a^+\succeq1/2000\)，并与奇谱隙合并得到整个 prime-free 局部 Weil 算子一致严格为正。
- [首个 prime band 的精确反射--Schur 正性延伸](notes/019-first-prime-band-exact-reflection-schur-gap.md)：把唯一活跃的 \(n=2\) shift 精确写成边缘 collar 反射 \(\mp(\log2/\sqrt2)J\)，并以 Yukawa--Schur/Arb 证书证明 \(A_a\succeq5\times10^{-5}I\) 于全部 \(0<a\le0.36\)。
- [首个 prime band 的正谱隙推进至 \(a=2/5\)](notes/020-first-prime-band-gap-to-two-fifths.md)：扩大精确反射--Yukawa--Schur 证书，证明 \(A_a^+\succeq10^{-6}I\)、\(A_a^-\succeq10^{-4}I\)，从而 \(A_a\succeq10^{-6}I\) 于全部 \(0<a\le2/5\)。
- [Robin deficit 全尾的固定秩归约](notes/021-fixed-rank-robin-deficit-tail-reduction.md)：证明无限 Yukawa deficit 尾可由固定的 \(m(s+1)\) 维聚合空间和 \(O(K^{-s-3})\) 的显式标量代价控制，消除 Schur 维数随尾截断增长的障碍。
- [首个 prime activation band 的完整严格正性](notes/022-first-prime-band-complete-strict-positivity.md)：以固定秩 Robin-tail、解析 Arb 矩阵和 dyadic Householder--Cholesky 证书证明 \(A_a>0\) 于全部 \(0<a\le\frac12\log3\)，从而严格排除首次退化发生在整个 \(n=2\) activation band 内。
- [极点秩二与奇偶秩一归约路线](notes/006-rank-one-sector-reduction-route.md)：记录下一阶段的标量 Schur 补主线、约化形式的决定性正性检查及证据边界。
- [极点项的签名 \((1,1)\) 分解与约化 Markov 形式](notes/007-indefinite-polar-splitting-and-reduced-markov-form.md)：纠正正秩二猜想，证明奇扇区为负秩一，并建立约化形式的全尺度绝对值收缩。
- [两个素数平移的有限轨道分解](notes/023-two-prime-partial-reflection-orbit-reduction.md)：在 \(\log3/2\le a\le\log2\) 上把 \(J_{\log2},J_{\log3}\) 的联合轨道严格降为至多四点链，并给出精确纤维逆。
- [Yukawa 谱截断下模型的单调极限与 frame 铰链](notes/024-monotone-yukawa-lower-models-and-frame-hinge.md)：证明 baseline 模数下模型单调收敛到完整算子，排除算子范数与粗 coercivity 捷径，并把端点正性压缩为统一 Schur/frame 不等式。
- [两素数反射带的完整严格正性推进至 \(a=\log2\)](notes/025-two-prime-band-complete-strict-positivity-to-log2.md)：把 Archimedean 部分写成 Fourier 对角加正 Yukawa atoms，精确保留 \(n=2,3\) 的联合反射与极点秩一项，并以有限 Feshbach--Arb 证书证明 \(A_a>0\) 于全部 \(0<a\le\log2\)。
- [活跃 prime shifts 的精确奇偶半区压缩](notes/026-exact-parity-compression-of-active-prime-shifts.md)：对任意 \(d=\log n\) 严格证明半区算子为 \(-\alpha_n(S_d+S_d^*)-\sigma\alpha_nJ_d\)，核准 support、奇偶符号和 prime-power 系数，并识别首个 mixed chamber 的最小接口 \(S_2,J_2,J_3\)。
- [Active-prime graph 的无限稠密轨道反例](notes/027-active-prime-graph-infinite-dense-orbit.md)：证明在 \(a\ge\log6\) 时，\(\log2,\log3\) translation edges 已包含一个无理圆周旋转，故联合 component 可以无限且稠密；全尺度正确替代仅为 locally finite、至多可数的 orbit graph。
- [首个 mixed chamber 的完整严格正性](notes/028-first-mixed-band-complete-strict-positivity-to-log5-half.md)：精确保留 \(n=2\) 的 translation--reflection、\(n=3,4\) 的 reflections、有限正 Yukawa atoms 与极点秩一项，以 Arb--Feshbach 证书证明 \(A_a>0\) 于全部 \(0<a\le\frac12\log5\)。
- [Active-prime orbit 坐标与 resolvent 衰减](notes/029-active-prime-orbit-coordinates-and-resolvent-decay.md)：把固定尺度 orbit 坐标化为两层 \(\mathbf Z^r\)，证明 word-ball 多项式上界，并建立对无限稠密 component 仍成立的 \(L^2\) Neumann/Combes--Thomas support-offdiagonal resolvent 估计。
- [Robin frame 的无权衰减障碍与加权尾定理](notes/030-robin-frame-offdiagonal-obstruction-and-weighted-tail.md)：证明固定 mode 下不同 Yukawa levels 不发生 \(n-m\) 衰减，并严格建立 \(\sum_{n,j<M}d_{n,j}=O_a(M)\) 与 Schur 大-\(n\) 尾/交叉块界，从而以 \(N(M)/M^2\to\infty\) 把统一 frame 问题缩到有限核心。
- [Partial-reflection resolvent 的尖锐 Sobolev 阈值](notes/031-partial-reflection-resolvent-sobolev-threshold.md)：显式求逆单个 collar reflection，证明一阶及任意正阶 \(L^2\) commutator 均不有界、Fourier 衰减一般只有临界 \(1/|j-k|\)，而 \(H^s\) domain invariance 的尖锐范围为 \(|s|<1/2\)。
- [聚合 deficit 的临界对数障碍](notes/032-aggregated-deficit-critical-kernel-logarithmic-obstruction.md)：证明 \(q_{M,j}\asymp_a\log((M+1)/(j+1))\)，从而绝对临界 majorant 增长为 \((\log M)^2\)，即使 Hilbert cancellation 仍增长为 \(\log M\)；统一 frame 必须先精确 Schur 消去低模。
- [Normalized frame 与逃逸负模态](notes/033-normalized-frame-equivalence-and-escaping-negative-modes.md)：证明 frame 余量乘 \(\|E_M\|\) 与 Yukawa 下模型负谱底渐近等价，并以紧预解式极限的显式反例说明形式单调收敛不能阻止负方向逃向高频；A3 的正确目标因此是负谱子的 collective compactness。
- [统一 Yukawa 高频 coercivity 与无谱逃逸](notes/034-uniform-yukawa-coercivity-and-no-spectral-escape.md)：从 Robin 边界形式序和 operator-monotone Yukawa 函数推出对数增长的公共高频下界，证明下模型负方向 collective compactness 及负谱底无污染；由此严格关闭 uniform frame 作为独立 RH 捷径的路线。
- [首次退化下 rank-one/PF 刚性的极限](notes/035-first-degeneration-rank-one-rigidity-counterexamples.md)：两个 positivity-improving 四维族分别实现首次不可见奇零核和双扇区同时可见退化，证明首次性、严格 crossing、PF、谱隙及 cyclicity 都不足以自动选择唯一扇区；结合 note 013 还排除了以偶约化谱底非负选择奇扇区的条件。
- [Zero-cyclicity 的指数矩归约与外侧方程障碍](notes/036-zero-cyclicity-exponential-moment-obstruction.md)：把 Archimedean 外侧势写成半整数指数矩的解析 Dirichlet 级数，证明任一外侧开区间消失即可推出全部矩消失与 \(u=0\)，同时严格说明内点压缩方程、两个 polar moments 和有限 prime shifts 不提供所需的无限边界数据。
- [Exterior-potential UCP 与 zero-cyclicity 的等价性](notes/037-exterior-potential-ucp-is-equivalent-to-zero-cyclicity.md)：用全线 Wiener--Hopf 分解识别自由外侧 Hardy 数据，证明外侧势开区间消失、全部指数矩消失与 zero-cyclicity 处于同一难度层级；Fourier、Paley--Wiener、extension 和有限 shifts 本身不能提供更薄的桥梁。
- [Prime reflection 破坏奇半区 Markov/定号路线](notes/038-prime-reflection-destroys-odd-half-markov-ground-state-route.md)：精确计算 odd half-form 的 translation/reflection 绝对值差，用窄 bumps 证明任一 active reflection 原子压倒连续核并破坏 Markov 收缩；严格连接二点模型进一步显示 \(M^-\ge0\) 不推出 ground state 定号或 polar overlap 非零。
- [Screw-kernel 半正性不推出 injectivity](notes/039-screw-kernel-positivity-does-not-imply-injectivity.md)：把 \(G_a\) 的严格正性等价为谱测度支撑的 Paley--Wiener uniqueness，构造具有 Suzuki 精确 \(\frac12|t|\log|t|\) 主奇性但在长区间上有核的 PSD screw kernel，并指出 Friedrichs 零模态到普通 \(L^2\) 积分方程之间仍有导数正则性缺口。
- [有限 prime delays 不传播 polar moment](notes/040-finite-prime-delays-do-not-propagate-polar-moments.md)：证明 translation/reflection algebra 在半整数指数矩上逐坐标作用，区间压缩只增加 collar/exterior source，因而 \(U_0=0\) 不能由任何有限 active-prime delay 恒等式递推为全部矩消失。
- [一般 Wiener--Hopf/Toeplitz 黑箱不能推出 zero-cyclicity](notes/041-no-general-wiener-hopf-black-box-for-zero-cyclicity.md)：核对 Titchmarsh、Coburn--Simonenko、truncated Toeplitz 与 analytic-kernel UCP 的假设缺口，并以匹配 Suzuki 主奇性的无限维奇偶核反例排除通用 injectivity 定理。
- [Deficiency \((1,1)\) 不推出 reduced polar-cyclicity](notes/042-deficiency-one-does-not-imply-reduced-polar-cyclicity.md)：逐域核对 Suzuki defect vectors 与极点向量的错位、\(\lambda=0\) 的循环依赖，并以 simple symmetric 导数算子的显式反例证明 defect cyclicity 即使加交换性和正性仍不能控制 reduced 零核。
- [正径向 jumps 不强迫第二谱层简单或为奇](notes/043-positive-radial-jumps-do-not-force-second-mode-simplicity.md)：以离散和连续反例关闭 positivity-improving/反射对称到第二谱层的抽象推论，并核对 fractional Pohozaev、complete-Bernstein nodal 理论均不覆盖 finite prime atoms。
- [Renormalized logarithmic Pohozaev 铰链与 prime virial](notes/044-renormalized-log-pohozaev-hinge-and-prime-virial.md)：由 fractional identity 与 Fourier scaling 锁定候选 boundary trace 常数，证明该 trace 若成立将推出 pure-log 全谱简单，同时精确计算并否定 finite prime virial 的一般符号。
- [完整 joint virial 的驻定性与边界异常项](notes/045-joint-weil-virial-stationarity-and-boundary-anomaly.md)：逐项计算 Archimedean、prime、smooth remainder 与 polar 的尺度导数，证明半正定零模态上的一切形域切向 virial 必须精确为零，从而把唯一可承重对象压缩为非形域 logarithmic boundary anomaly。
- [直接 dilation 不产生 logarithmic boundary trace](notes/046-direct-dilation-does-not-produce-logarithmic-boundary-trace.md)：证明 logarithmic 主形式的缩放差商恒为全局 (2\|u\|^2)，与端点系数无关；同时证明临界 (1/\sqrt{\log}) 轮廓对所有固定 prime delays 及 activation 阈值只产生 (o(s)) 端点层，从而把 Pohozaev 路线进一步压缩为本征方程专属的 Green 边界配对。
- [边界 Volterra indicial root 与 Mellin-local 铰链](notes/047-volterra-boundary-indicial-root-and-mellin-local-hinge.md)：把零模态边界主方程化为 \(2tU-\int^tU\)，证明有界余项下唯一慢模为 \(B/\sqrt t+O(1/t)\)，并核准 finite prime shifts 不改变该 root；剩余最小命题是同尺度 Mellin 环奇异积分的 Dini/Besov 有界性。
- [Mellin-local symbol 与 Whitney--Dini 边界缺口](notes/048-mellin-local-symbol-and-whitney-dini-boundary-gap.md)：计算同尺度环的精确正 logarithmic symbol，排除所有 regularly-varying 单相位与 Volterra 主部的抵消，并把 trace existence 压成一维边界 uniform Whitney--Dini/weighted coercivity；最新 \(n\ge2\) interior Schauder 理论不覆盖该接口。
- [平均边界 trace 与 dyadic packet coercivity](notes/049-averaged-boundary-trace-and-dyadic-packet-coercivity.md)：给出平均 trace 等价的 signed Mellin tail 条件，证明平方根权重 commutator 为低阶，并以正 symbol 排除分离 dyadic packet 和频率级联 pseudomodes；唯一剩余项是移动 cutoff 的固定宽度端点 leakage。
- [平均 logarithmic boundary trace 的存在](notes/050-existence-of-the-averaged-logarithmic-boundary-trace.md)：利用 Mellin-local 算子消去常数及 dyadic 对偶估计，证明 signed tail \(\int^\infty t^{-3/2}\mathcal MU\) 普通收敛，从而对所有临界有界零模态建立 Cesàro/Mellin 平均边界系数；点态升级精确等价于额外的 Tauberian 控制。
- [Averaged trace 控制外侧 flux 但不决定 Pohozaev pairing](notes/051-averaged-trace-controls-exterior-flux-but-not-pohozaev-pairing.md)：证明平均系数已给出精确外侧 Stieltjes 渐近并可替代点态 trace 排除 collar/platform；同时识别 Green pairing 中独立的 conormal variance，最薄剩余条件为 \(T^{-1}\int_T^{2T}|tZ'|^2\to0\)。
- [Logarithmic 边界模态的 conormal variance 消失](notes/052-vanishing-conormal-variance-for-logarithmic-boundary-modes.md)：利用 averaged trace、Mellin accretivity 与慢 cutoff commutator，证明实际零模态满足 \(T^{-1}\int_T^{2T}|tZ'|^2\to0\)，从而闭合 smooth Green pairing 的边界正则性接口而无需点态 trace。
- [完整 averaged Weil--Pohozaev 恒等式](notes/053-full-weil-averaged-pohozaev-identity.md)：组装 weak-prime Pohozaev identity，区分 boundary anomaly 与普通 form stationarity，并把剩余铰链精确压成核专属 virial 严格不等式或零 averaged trace 的 boundary UCP。
- [严格局部 Weil 正性推进到 \(\frac12\log7\)](notes/054-strict-local-weil-positivity-to-log7-half.md)：精确保留 \(n=2,3,4,5\) prime blocks，以两步 Schur prime 范数界、奇扇区 Arb--LDL 与偶扇区四维 verified Schur 证书证明 \(A_a>0\) 于全部 \(0<a\le\frac12\log7\)。
- [严格局部 Weil 正性推进到 \(\frac12\log8\)](notes/055-strict-local-weil-positivity-to-log8-half.md)：精确保留 \(n=2,3,4,5,7\) prime blocks，以两步 prime 范数界、五维 verified Schur 及有限正 Yukawa 尾的完整合同 Feshbach 更新证明 \(A_a>0\) 于全部 \(0<a\le\frac12\log8\)。
- [严格局部 Weil 正性推进到 \(\frac12\log9=\log3\)](notes/056-strict-local-weil-positivity-to-log9-half.md)：以对角加权补空间预解式、PSD recovery 子因子和修正后的 true-Schur 公式 \(U_{\rm eff}=U-XC^{-1}V\)，分别用奇 rank-40 与偶 canonical rank-5 Arb 证书证明 \(A_a>0\) 于全部 \(0<a\le\log3\)。
- [历史文献驱动的因果—全正性证明路线图](notes/057-historical-causal-pf-route-map.md)：从 Schoenberg 单侧 PF∞、Báez-Duarte–Burnol 整数伸缩因果逼近和 Lagarias–Weil 正性出发，提出先核对整数 dilation Gram 与局部 Weil Schur 增益的精确接口，再决定是否进入全局逼近链；不把等价判据当作证明。
- [正算子有限压缩的 canonical 延拓与 metric Schur 公式](notes/058-canonical-extension-of-positive-compressions.md)：证明孤立加入 \(PYP\) 一般不是 \(Y\) 的 Loewner 下界，给出 \(YP(PYP)^\dagger PY\) 的合法 canonical 子因子及保留 cross 的 true-Schur 公式；因此此前基于孤立 Yukawa 压缩的 \(\frac12\log10\) 奇、偶候选均不构成正性定理。
- [Nyman--Weil 直接压缩障碍与对数半群桥](notes/060-nyman-weil-paley-wiener-obstruction-and-log-semigroup-bridge.md)：证明任何非零有限 Nyman 向量的 Mellin 像都不是有限指数型，关闭“dilation Gram = finite local Weil compression”；建立 \(O(e^{-a})\) 窗口 Gram 尾、\(n\mapsto qn\leftrightarrow\tau_{\log q}\) 精确协变，并把整数逼近重写为 Cayley 奇异内半群的广义 Schur 问题。
- [Báez--Duarte 精确窗口插值关闭 compact Weil 传递](notes/062-baez-duarte-exact-window-interpolation-closes-compact-weil-transfer.md)：历史自然逼近 \(B_N\) 在 \((N^{-1},\infty)\) 已精确等于 \(-\chi\)；在匹配 log-window 上该零 residual 解还唯一，故任何正内积都强制选出同一组已知 \(L^2\) 失败的系数。由此关闭窗口 Schur 传递，并把正确对象定位为缩放后的逃逸因果尾与 dual/Hardy 双通道可观测性。
- [Báez--Duarte 逃逸尾的 Mertens 壳分解与首壳非消失](notes/063-baez-duarte-tail-mertens-shell-localization.md)：把 \(\chi+B_N\) 精确写成 reciprocal Mertens 阶梯，证明任意常数中心化后的第一 dyadic shell 能量具有正 limsup，因而历史自然逼近的失败已局域在 \((1/(2N),1/N]\)；首个 dilation-invariant dual 窗则只保留 \(\gamma(N)\) 一个标量，不能控制该障碍。
- [Selberg 渐消 Möbius 逼近的仿射首壳 RH 判据](notes/064-selberg-affine-first-shell-rh-criterion.md)：对历史权重 \(\lambda_{k,N}=\mu(k)(1-\log k/\log N)\) 推导第一 reciprocal shell 的精确仿射 \(M,J,\Psi\) 闭式；两个消失矩除去常数与线性干扰，Mellin 组合精确消掉最高阶极点但保留每个 zeta 零点，因而仅需证明该单壳能量趋零即可推出 RH。离线零 \(\beta>1/2\) 反而强制子列下界 \(N^{2\beta-1}/\log^2N\)。
- [Barban--Vehov 的 \(H^{-1}\) 障碍与 incomplete-lcm 边界](notes/065-barban-vehov-hminus1-obstruction-and-weak-mertens-bridge.md)：把首壳误差识别为经典 Barban--Vehov 除数和的累计中心化误差，证明 Graham 的尖锐 \(H^0\) 二次均值只控制三角核的对角；再以 sawtooth 完整 lcm 周期分解和 Jordan 平方和证明周期主项已为 \(o(N^2)\)，从而把 RH 充分条件精确压成一个 signed incomplete-lcm 边界余项。弱 Mertens 均值可推出所需 \(O(N^2/\log N)\)，但该假设本身已蕴含 RH。
- [incomplete-lcm 边界的 Bernoulli--Dedekind 精确化与平衡区铰链](notes/066-balanced-bernoulli-dedekind-dispersion-hinge.md)：把双边界余项精确写成 cotangent Fourier 级数、耦合 shift--lcm 的三因子 Bernoulli--Dedekind 差及单壳 Stieltjes 相关；Maier--Rassias 的固定幂节省只覆盖分子分母多项式分离区，而非主导的 balanced near-diagonal 区。非二幂端点全量计算将超过 \(96.6\%\) 的块绝对质量局部到最后八个物理尺度，主块的 reduced balanced 质量超过 \(84.4\%\)，从而把下一新输入锁定为 balanced coupled Dedekind dispersion。
- [平衡物理块的精确缩放与反对角 Möbius 零点](notes/067-balanced-physical-scaling-and-antidiagonal-mobius-zero.md)：固定 gcd 切片的精确缩放与 Euler 分解；其中 \(1/\zeta(s+t)\) 及 anti-diagonal no-pinch 结论仅属于条件化切片。完整聚合的路线裁决已由 note 069 修正。
- [gcd completion 消去固定切片的反对角因子](notes/069-gcd-completion-cancels-the-fixed-slice-antidiagonal.md)：完整 gcd 求和逐素数补回 \(+p^{-(s+t)}\)，在物理曲面 \(z=s+t\) 上把局部因子恢复为 \((1-p^{-s})(1-p^{-t})\)。因此完整主积分严格回到 \(1/(\zeta(s)\zeta(t))\) 的一变量 Möbius Gram，并分解成有限 moving Mertens/Riesz cells。Menon 2026 的最新 almost-all short-interval 均方在 \(h\asymp N\) 时仍比所需 \(o(N)\) 平方根尺度差一个 \(N\) 次幂（仅附对数修正）。
- [sawtooth cells 的共享边界同号相加而非望远镜消去](notes/070-sawtooth-cell-boundaries-add-instead-of-telescope.md)：离散 Abel 公式把相邻差精确写成光滑项减去互不重叠的 jump packets；共享端点为 \(-A/2-A/2=-A\)，不消去。每个完整 cell 同时等于 \(G(v)=A(tN/v)\) 的“积分减梯形求积”，但误差测度仍含 \(-1\) Dirac 原子。固定-\(n\) 平铺只把目标降到 weighted-Mertens 均方；完整 \(n\)-sum 的唯一 telescope 是 \(\mu*1\) 与 \(-\mu*\log=\Lambda\)，输出 \(\log N+\Psi\) 而非零。
- [Selberg 首壳增量的 parity 符号障碍](notes/071-selberg-shell-increment-parity-sign-obstruction.md)：完整残差化为 \(R_N(y)=yB_N-\Psi(y)+\mathcal A_N(y)-\mathcal A_N(N)\)，其 shell increment \(q_N(n)=\Lambda(n)-\mu(n)\log(N/n)\) 随素因子个数奇偶混号。唯一正核 \(2N-\max(m,n)\) 只是累计 \(H^{-1}\) Gram 本身，不能由 Barban--Vehov 的 \(H^0\) 对角回收缺失次幂。DHJ Polymath 的历史 parity barrier 同样要求 sign-sensitive bilinear input；下一原子转为 \(Q_N(\theta)=\sum q_N(n)e(n\theta)\) 的低频双线性消去。
- [临界低频带退化为有限 weighted-Mertens transforms](notes/072-critical-low-frequency-band-has-no-type-II-oscillation.md)：固定 high block 中 \(n=dm\) 强制 \(m=O(1)\)，故所谓双线性卷积严格退化为有限个 smooth weighted-Mertens transforms。即使人为分解 \(d=rs\)，在 \(\theta=\xi/N\) 上整个 Type-II box 也只转 \(O(1)\) 圈。保留两个 affine modes 后，正确必要对象是 \(\|P^\perp D_{I,N}\|_2^2=o(N\log^2N)\)；Davenport、Wei Zhang 2022 的条件 uniform bound 与 Menon averaged Chowla 均差一个幂门槛。
- [Farey--Franel 正性只看完整 gcd 分量](notes/073-farey-franel-positivity-sees-the-complete-gcd-component.md)：Kanemitsu--Yoshimoto 的 Franel 公式经特殊 Mertens 向量与 Dedekind 三项关系收缩为 gcd 正核。Selberg shell 则精确为 \(K_N=NG_N/12+E_N\)：Franel 结构命中已经为低阶的 \(Q_2\) exact-resonance 项，不能恢复 \(E_N\) near-resonance；\(N=4\) 的显式二坐标反例已证明相同 gcd 能量可有不同 shell 能量。short Kubert 公式又严格回到 RH-equivalent Mertens 伸缩差。
- [Mellin 极点强迫 dyadic 平均首壳增长](notes/074-mellin-poles-force-dyadic-mean-shell-growth.md)：把 note 064 的点态子列探针升级为 dyadic \(L^2\) Abel 引理。若 \(\rho=\beta+i\gamma\) 是 \(q\) 重零点，则某子列上平均首壳能量至少为 \(Y^{2\beta-1}(\log Y)^{2q-4}\)；因此只要跨截断参数的 dyadic 平均为 \(Y^{o(1)}\) 即可推出 RH。新目标严格降为 \(\sum_{N\asymp Y}I_N\ll_\varepsilon Y^{3+\varepsilon}\)，而非逐个 \(I_N=o(N^2)\)。\(2^8\le Y\le2^{20}\) 的精确计算进一步给出 \(\overline{\mathcal E}(Y)\approx0.0196/\log^2Y\)，只作路线选择。
- [连续 cutoff 平均分裂为端点与斜率方差](notes/075-continuous-cutoff-average-splits-into-endpoints-and-slope-variance.md)：Letendre 的全截断 Möbius 矩在首壳强制的 \(N\ge n/2\) 区间退化为 \(M(n,N)=-\mu(n)\)；Alterman 的连续筛层仍只控制完整 \(H^0\) lcm 密度。实参数 cutoff 的精确导数与两端点 Poincaré 把新目标分裂为 \(D_y(y),D_{y/2}(y)\) 的平方根均值和一个去平均斜率的显式 PSD Möbius 核；两者用直接估计仍各差一个 \(Y\) 幂。
- [cutoff Fourier 平均保留 Farey near-collisions](notes/076-cutoff-fourier-average-leaves-farey-near-collisions.md)：对 \(N\) 再平均的精确核只是 \([S(2\Delta)-S(\Delta)]/(2\pi i\Delta)\)。远碰撞衰减，但 \(0<|he-kd|\lesssim de/Y\) 时仍为 \(Y^2\)；尤其 \(h=k=1,d,e\asymp Y\) 的宏观块全部拥挤于此。exact resonance 已由 \(Q_2\) 达标，普通 Farey spacing/large sieve 对非零 near-collisions 仍只给 \(Y^{4+o(1)}\)。
- [reciprocal 单包估计的 RH 等强性与超振荡障碍](notes/077-reciprocal-packet-bound-is-rh-strength-but-fixed-band-observability-fails.md)：完整证明固定 reciprocal 频带不能把远处局部 \(L^2\) 以统一常数外推到零频；显式 reciprocal-grid 超振荡反例与 Nazarov 1993 的项数指数代价一致。但若单包平方根均方对所有实尺度成立，Möbius 先验、解析 Hölder 传播和几何伸缩自举会把任意 Mertens 幂指数迭代到 \(1/2\)，故该 all-scale 单包命题与 RH 等价，不能作为更弱黑箱。
- [全 Fourier 包的有限 Ramanujan 原函数框架](notes/078-full-fourier-packets-form-a-finite-ramanujan-antiderivative-frame.md)：先约分全部 \(h/d=a/q\)，聚合系数精确为 \(\mu(q)\check m_q(N/q)/\log N\)，numerator 包形成 primitive sawtooth，其单位格跳跃为 \(-c_q(n)/q\)。因此完整跨 \(h\) 抵消等价于 Barban--Vehov 有限 Ramanujan 展开的离散原函数；Alterman 只控制跳跃的 \(\varphi(q)\)-权 \(H^0\)，而 primitive 原函数带 \(J_2(q)\)-权。新的直接求和加强为 \(Q_2(N)\ll N/\log^2N\)，故完整周期对角为 \(O(N^2/\log^2N)\)。精确中心化把剩余压成零模 \(\Gamma_N\) 与 signed incomplete-frame defect；素数模量族证明一般 frame 界仍损失近一整幂，下一输入必须使用 Möbius 系数与 defect 的联合消去。
- [路径 DST 把中心化 defect 压到平方根多个低模](notes/079-path-dst-reduces-the-centered-defect-to-sqrtN-low-modes.md)：primitive 原函数的路径差分有显式正弦奇异值 \(2\sin(\pi k/2N)\)。Barban--Vehov \(H^0\) 已无条件支付 \(k>\sqrt{N/\log N}\) 的全部能量，故中心化未知量只剩 \(N^{1/2+o(1)}\) 个低模；每个低模又精确等于带 Möbius 权的“全局 \(N\)-格点正弦求积减局部 \(N/d\)-格点求积”。仿射项删除 \(\Lambda\) 连续主项，但分开估计 PNT 误差已接近 RH；真正的新目标是对 cutoff \(N\) 作均方的 \(k^{-2}\)-加权格点求积缺陷。note 080 进一步证明零模 \(\Gamma_N\) 对 RH 探针不必控制。
- [中心化路径能量单独构成 RH 判据](notes/080-centered-path-energy-alone-is-an-rh-criterion.md)：修正 note 079 对零模的需求判断。Mellin 离线零探针本身有零均值，故严格看不见 \(\Gamma_N\)；中心化首壳方差的 dyadic \(Y^{3+\varepsilon}\) 界已经推出 RH。结合 DST 高频尾，唯一充分条件缩为前 \(\sqrt{N/\log N}\) 模的 \(k^{-2}\)-加权 cutoff 均方 \(\ll Y^{2+\varepsilon}\log^2Y\)。若存在 \(\beta>1/2\) 的零点，超临界质量必定位于这些低模，不能藏在零模或高频。
- [每个离线零都被某个固定正弦模看见](notes/081-every-offline-zero-is-visible-in-one-fixed-sine-mode.md)：固定 \(k\) 的连续 cutoff 模有精确 Mellin 像 \([c_k/(s-1)^2-W_k'(s)]/\zeta(s)+W_k(s)\zeta'(s)/\zeta(s)+W_k'(s)\)，末项只是 \(n=1\) 端点的整函数。正弦完备性证明每个 \(\zeta\)-零点至少被一个固定 \(k=k(\rho)\) 以非零极点看见。因此无需对增长到 \(\sqrt N\) 的模族作一致估计：只要逐个固定 \(k\) 证明 cutoff dyadic 均方 \(\ll_{k,\varepsilon}Y^{2+\varepsilon}\)，即推出 RH。下一最小元可固定为 \(k=1\) Gram，同时判别是否存在 universal finite detector。
- [固定正弦 cutoff 均方呈临界数值尺度](notes/082-fixed-sine-cutoff-means-have-critical-numerical-scaling.md)：对 \(Y=2^{10},\ldots,2^{19}\) 的可复现分层抽样显示，\(k\le16\) 的固定模二阶均值整体呈 \(Y^{1+o(1)}\)；\(k^{-2}\) 加权均值的全程/后五壳斜率为 0.9968/1.0256。最大壳上 residualized prime--Möbius 相关系数在 \(k=1,2,3\) 为 \(-0.8691,-0.9200,-0.9755\)，表明目标尺度依赖联合抵消，不能分项估计。此项是数值证据与猜想，不是证明。
- [两个正弦模把 universal detection 降为紧集无零性](notes/083-two-sine-modes-reduce-universal-detection-to-compact-nonvanishing.md)：构造显式二模行列式 \(D=C_1W_2-C_2W_1\)；若它在右半临界带无零，则 \(k=1,2\) 已检出任意重数的全部离线零。该 note 完成解析归约与高频渐近；提出的有限矩形任务现已由 note 086 严格闭合。
- [固定模 Gram 的两种坐标与高除数截断边界](notes/084-fixed-mode-gram-reduces-to-high-divisor-multiplicative-near-diagonal.md)：写出 divisor--\(\Delta\) 与完整 \(g_N\) product 两种精确 Gram。前者的 \(d\le Y^{3/4}\) 部分已支付，控制互补 high-divisor \(\Delta\)-sum 即足够；后者的 product diagonal 已支付，控制完整 off-diagonal 也足够。两种坐标不能拼接。\(k=2\) 的高除数块是纯短-cofactor 和，\(k=1\) 仍含必须联合抵消的 global--local 项。
- [\(k=1\) 的 \(a=2\) 高除数 cell 给出零自由 Mellin detector](notes/094-k1-a2-high-divisor-cell-has-a-zero-free-mellin-detector.md)：严格分解该 exact cell 的离散 Mellin 像为 \(K(s-1)/\zeta(s-1)+H(s)\)，并以 Arb 证明紧支撑权 \(K\) 在闭右半临界带无零；故其 dyadic 二次均值 \(\ll_\varepsilon Y^{2+\varepsilon}\) 与 RH 等价。这是更窄的 RH 判据，不是该均值的无条件证明。
- [单个 \(k=1,a=2\) cell 的移动尺度 Möbius 协方差门](notes/095-k1-a2-cell-reduces-to-moving-scale-mobius-covariance.md)：该 cell 的 dyadic 均方精确分成 \(O(Y^2)\) 对角与一个平滑移动尺度的 \(\mu(d)\mu(d-r)\) 协方差；后者的 \(Y^{2+\varepsilon}\) 界与 RH 等价。离散 Abel 只把它送到同样 RH 强度的 Mertens 均方；lcm/divisor \(H^0\) 核、相邻尺度 telescope 与 Dirichlet 去卷积均不提供直接 transfer。
- [有限 dilation 滤波不能消除 \(a=2\) cell 的 Mertens 端点](notes/096-finite-dilations-cannot-remove-the-a2-mertens-endpoint.md)：任一有限非零正尺度组合 \(G(t)=\sum c_jF(t/\lambda_j)\) 都在互异的 \(2\lambda_j/3\) 保留 jump 原子；有理尺度的公共格点 Abel 公式相应保留非零 \(M(2\lambda_jN/3)\) 系数。即便附加 Mellin 指数多项式零自由性，有限尺度滤波仍不能把 note 095 的 RH 级协方差门望远镜消除。
- [固定模是 Hardy-amalgam 空间中的协变导数](notes/085-fixed-mode-is-a-covariant-derivative-in-hardy-amalgam-space.md)：精确 dyadic \(Y^2\) 界对应 Mellin 逆像的 \(W(L^2,\ell^\infty)\)，而任意 \(\varepsilon\) 版对应全部右移半平面 \(H^2\) 的交。新恒等式 \(G_k=H_k'\)、\(H_k=W_k(\zeta-1)-c_k/(s-1)\) 给出一维协变导数及二维 ground-state 能量分解；但最干净的无权 Bergman 正性比临界逐壳尺度强一个对数，合适加权又失去符号。
- [前两个正弦模构成严格的 universal detector](notes/086-first-two-sine-modes-are-a-rigorous-universal-detector.md)：以 14 次端点分部积分的显式 Arb 余项证明 \(|\Im s|\ge28\) 时 \(D(s)\ne0\)，再对有限矩形作 1812 段区间辐角原理，得到 \(D\) 在整个闭右半临界带无零（除 \(s=1\) 的已知极点）。因此只需证明 \(k=1,2\) 两个 cutoff 均方 \(\ll Y^{2+\varepsilon}\) 即推出 RH；当前 RH 未证，算术端仍是 note 084 中两个不可拼接的替代 Gram 目标。
- [两正弦 cutoff 均方与 RH 等价](notes/087-two-sine-cutoff-mean-square-is-equivalent-to-rh.md)：RH 下的 \(M(x)=x^{1/2+o(1)}\) 与 \(\psi(x)-x=O(x^{1/2}\log^2x)\) 经端点为零的分部求和给每个固定模 \(\mathcal R_{N,k}=N^{1/2+o(1)}\)。结合 note 086，\(k=1,2\) 的 dyadic 均方 \(\ll_\varepsilon Y^{2+\varepsilon}\) 与 RH 精确等价。
- [存在有限纯偶正弦 universal detector](notes/088-a-finite-pure-even-sine-family-universally-detects-rh.md)：若偶模矩阵 \((W_{2a},W_{2a}')\) 在某点降秩，则 \(t^{s-1}(A+B\log t)\) 被迫关于 \(3/2\) 对称，与其一、三阶中心导数矛盾。高频、\(s=1\) jet 与紧性遂给出有限纯偶模 universal detector；对应 RH 等价式完全没有 \(B_NS_{N,k}\) 全局通道。当前正在检验是否可显式缩成 \(E=\{4,6\}\)。
- [\(\frac12\log10\) 偶扇区 weighted scalar-complement 的严格不定性](notes/059-log10-even-weighted-scalar-complement-is-indefinite.md)：以修正后的六个 signed prime jumps、P10 digamma-weighted 七维 tail enclosure 和 256-bit interval LDL 证明固定 \((R,N)=(280,500)\) 的完整 weighted 下模型惯性为 \((5,2,0)\)，从而关闭该下模型路线；不推出原 \(A^+\) 不定。
- [\(\frac12\log10\) 偶扇区 K400 true-complement 下模型的严格不定性](notes/060-log10-even-k400-true-complement-lower-model-is-indefinite.md)：完整保留补空间的前 120 个真实模及其全部 cross，以联合 covariance 支付余尾；393 维补块严格正，而七维 true Schur 惯性为 \((6,1,0)\)，故 clean K400 下模型惯性为 \((399,1,0)\)。该结果关闭这一更尖锐的固定补空间路线，不推出原算子不定。
- [完整 Yukawa atom 的精确 rank-one true-Schur 更新](notes/061-a-full-yukawa-atom-has-an-exact-rank-one-true-schur-update.md)：证明保留 atom 的全部补空间分量后，其对 K400 Schur 块的合法增益精确为一个 graph-corrected rank-one 项；利用 Parseval 恒等式把无限补空间 cross 化为有限的 \(PB_0r-(PB_0P)Pr\)。192-bit true-Schur 证书进一步证明 scalar K400/N500 加单个 full \(r_{500}\) 后仍有惯性 \((399,1,0)\)，从而严格关闭该单 atom 下模型路线；不推出原偶算子不定。
- [偶局部 Weil 算子的严格正性推进到 \(\frac12\log10\)](notes/064-strict-even-local-weil-positivity-to-log10-half.md)：在同源 scalar K400/N500 无限维下算子中完整加入 \(r_{500},\ldots,r_{539}\)，以 Parseval 保留全部 atom--atom 与 atom--base cross，并用 273→120→7 的 metric-Woodbury/Arb true-Schur 证书证明 \(A_a^+>0\) 于 \(0<a\le\frac12\log10\)。39 项前缀仍严格不定，40 项首次严格为正。
- [完整局部 Weil 正性推进到 \(\frac12\log10\)](notes/068-strict-local-weil-positivity-to-log10-half.md)：对奇扇区保留负 polar、全部无限补空间 cross 与完整 odd Yukawa family，213 项 Parseval--metric-Woodbury/192-bit true-Schur 证书首次严格为正；与偶扇区定理合并得到 \(A_a>0\) 于全部 \(0<a\le\frac12\log10\)，从而 \(a_{\rm deg}>\frac12\log10\)。
- [约化算子的严格正基态与奇扇区谱隙](notes/008-reduced-ground-state-and-odd-spectral-gap.md)：由纯跳 Dirichlet form 的不可约性证明基态简单、几乎处处严格正且为偶函数，并得到全尺度严格奇扇区谱隙。

新的永久记录只在得到定理、反例、严格归约或有明确范围的路线关闭后建立。探索代码与临时推导放入
`scratch/`，不进入版本控制。

全局路线、精确节点、历史量纲与 no-go 边的统一索引见
[定理宇宙](THEOREM_UNIVERSE.md)。
