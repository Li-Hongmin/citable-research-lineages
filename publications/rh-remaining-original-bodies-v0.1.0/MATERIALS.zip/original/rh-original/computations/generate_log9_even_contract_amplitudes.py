"""Generate the 192-bit even exact contract amplitudes used to select Q5."""
import sys
import numpy as np

dummy=np.zeros((1,720),dtype=object);dummy[0,0]='1'
np.savez('scratch/log9_even_q280_1000_dummy1_q64.npz',numerator=dummy,denominator='1')
EVEN_RK=1
EVEN_Q_PATH='scratch/log9_even_q280_1000_dummy1_q64.npz'
src=open('computations/log9_even_certificate_wrapper.py',encoding='utf-8').read()
if '--export-contract-amp-only' not in sys.argv:sys.argv.append('--export-contract-amp-only')
exec(compile(src,__file__,'exec'))
