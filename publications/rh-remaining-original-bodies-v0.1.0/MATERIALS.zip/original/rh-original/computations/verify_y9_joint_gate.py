#!/usr/bin/env python3
"""Exact OMEN regression for the y=9 joint beta gate.

This checks the complementary-pair formulas, the finite residual range, and
the m=41 sign change recorded in note 677.  It does not prove the remaining
joint tail inequality.
"""

from fractions import Fraction
from math import comb, factorial


def d_weight(m, r):
    degree = 3 * m + 3
    return Fraction(
        factorial(degree) * factorial(m + r - 2),
        comb(degree, 2)
        * 2**r
        * factorial(r - 1)
        * factorial(m - r)
        * factorial(2 * m + r + 1),
    )


def pair(m, r, a):
    p = m - r + 3
    q = 2 * m + r + 1
    points = (a,) if a == 9 - a else (a, 9 - a)
    return sum(
        k ** (p - 1)
        * (9 - k) ** (q - 1)
        * ((3 * m + 4) * k - 9 * p)
        for k in points
    )


def pair_formula(m, r, a):
    if a == 1:
        return (
            8 ** (2 * m + r) * (9 * r - 6 * m - 23)
            + 8 ** (m - r + 2) * (15 * m + 9 * r + 5)
        )
    if a == 2:
        return (
            2 ** (m - r + 2)
            * 7 ** (2 * m + r)
            * (9 * r - 3 * m - 19)
            + 7 ** (m - r + 2)
            * 2 ** (2 * m + r)
            * (12 * m + 9 * r + 1)
        )
    if a == 3:
        return (
            3 ** (m - r + 2) * 6 ** (2 * m + r) * (9 * r - 15)
            + 6 ** (m - r + 2) * 3 ** (2 * m + r)
            * (9 * m + 9 * r - 3)
        )
    if a == 4:
        return (
            4 ** (m - r + 2) * 5 ** (2 * m + r)
            * (9 * r + 3 * m - 11)
            + 5 ** (m - r + 2) * 4 ** (2 * m + r)
            * (6 * m + 9 * r - 7)
        )
    raise ValueError(a)


def group(m, a):
    return sum(
        (d_weight(m, r) * pair(m, r, a) for r in range(1, m + 1)),
        Fraction(0),
    )


def main():
    for m in range(1, 42):
        for r in range(1, m + 1):
            for a in range(1, 5):
                assert pair(m, r, a) == pair_formula(m, r, a)
        total = sum((group(m, a) for a in range(1, 5)), Fraction(0))
        assert total > 0, m
        assert group(m, 3) > 0 and group(m, 4) > 0, m
    assert group(41, 1) < 0
    assert group(41, 2) > 0
    print("Y9_PAIR_FORMULAS_OK", "m=1..41")
    print("Y9_TOTAL_FINITE_GATE_OK", "m=1..41")
    print("Y9_M41_GROUP_SIGNS_OK", "S41,1<0<S41,2,S41,3,S41,4")


if __name__ == "__main__":
    main()
