"""Arb certificate that the zero-baseline Q function is not Caratheodory.

Reproduce with:

    uv run --with python-flint python \
      computations/verify_zero_baseline_q_not_caratheodory.py
"""

from flint import acb, acb_series, arb, ctx


ctx.dps = 80

s = acb(arb("0.500001"), arb("541.6"))
x = acb_series([s, acb(1)], 2)
zeta_series = x.zeta()
zeta_value = zeta_series[0]
zeta_derivative = zeta_series[1]

c_value = (
    1
    + 1 / s
    + 1 / (s - 1)
    - arb.pi().log() / 2
    + (s / 2).digamma() / 2
)
q_value = (s - 1) / s * (zeta_derivative + c_value * zeta_value)

print("s =", s)
print("Q(s) =", q_value)
print("upper endpoint of Re Q(s) =", q_value.real.upper())

assert q_value.real.upper() < arb("-0.63")
print("PASS: Re Q(0.500001 + 541.6 i) < -0.63.")
