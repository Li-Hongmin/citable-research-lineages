"""Stage 3: certify the updated complement and true five-dimensional Schur block."""
from flint import arb,arb_mat,ctx
import numpy as np,sys,re
ctx.prec=int(sys.argv[1]) if len(sys.argv)>1 else 128
M=5;m=195
o=np.load('scratch/log8_odd_R200_N400_exact_small_map.npz');d=np.load('scratch/log8_odd_R200_tail_delta_blocks.npz')
C0=arb(1)/20000
def cr(s):
 q=str(s);x=float(q[1:].split(' +/-')[0]);r=float(q.split('+/-')[1][:-1]) if '+/-' in q else 0.;return x,r
Co=np.empty((m,m));Do=np.empty((m,m));Rad=np.empty((m,m))
ocs=o['c_arb'];dds=d['d22']
for i in range(m):
 for j in range(m):
  x,r=cr(ocs[i,j]);y,s=cr(dds[i,j]);Co[i,j]=x;Do[i,j]=y;Rad[i,j]=r+s
Cm=Co+Do-np.eye(m)/20000
Lf=np.linalg.cholesky((Cm+Cm.T)/2);scale=2**24
Li=np.rint(Lf*scale).astype(np.int64);del Lf,Cm
resinf=arb(0)
for i in range(m):
 rowsum=arb(0)
 for j in range(m):
  dot=sum((int(Li[i,k])*int(Li[j,k]) for k in range(min(i,j)+1)),0)
  cij=arb(str(ocs[i,j]))+arb(str(dds[i,j]))-(C0 if i==j else arb(0))
  rowsum+=abs(cij-arb(dot)/(scale*scale))
 if rowsum.upper()>resinf.upper():resinf=rowsum
cnew_lower=C0-resinf;print('Cnew_residual_inf',resinf,flush=True);print('Cnew_lower',cnew_lower,flush=True);assert cnew_lower.lower()>0
del Li,Co,Do,Rad
if '--c-only' in sys.argv:raise SystemExit(0)
xcs=o['x_arb'];scs=o['small_arb'];d11s=d['d11'];d12s=d['d12']
Xold=arb_mat([[arb(str(xcs[i,j])) for j in range(m)] for i in range(M)])
small=arb_mat([[arb(str(scs[i,j])) for j in range(M)] for i in range(M)])
d11=arb_mat([[arb(str(d11s[i,j])) for j in range(M)] for i in range(M)])
d12=arb_mat([[arb(str(d12s[i,j])) for j in range(m)] for i in range(M)])
Cold=arb_mat([[arb(str(ocs[i,j])) for j in range(m)] for i in range(m)])
Yold=Cold.solve(Xold.transpose());Aold=small+Xold*Yold;del Yold,Cold,small
Xnew=Xold+d12;del Xold,d12
Cnew=arb_mat([[arb(str(ocs[i,j]))+arb(str(dds[i,j])) for j in range(m)] for i in range(m)])
Ynew=Cnew.solve(Xnew.transpose());K=Aold+d11-Xnew*Ynew;K=(K+K.transpose())/2
T=[[K[i,j] for j in range(M)] for i in range(M)];perm=list(range(M));pivs=[]
for k in range(M):
 p=max(range(k,M),key=lambda i:float(T[i][i].mid()))
 if p!=k:
  T[k],T[p]=T[p],T[k]
  for row in T:row[k],row[p]=row[p],row[k]
  perm[k],perm[p]=perm[p],perm[k]
 piv=T[k][k];pivs.append(piv);print('true_pivot',k,piv,'perm',perm);assert piv.lower()>0
 for i in range(k+1,M):
  for j in range(i,M):
   z=T[j][i]-T[j][k]*T[i][k]/piv;T[j][i]=z;T[i][j]=z
print('TRUE_FULL_FESHBACH_CERTIFIED')
