"""Directed-ball certificate for note 016's killing-potential counterexample.

Reproduce with:

    uv run --with python-flint python computations/verify_odd_killing_counterexample.py
"""

from flint import arb, ctx

ctx.dps = 60

a = arb(1) / 3
x = arb(5) / 24
c0 = -arb.const_euler() - arb.pi() / 2 - arb.log(8 * arb.pi())


def tail(r):
    z = arb.exp(-r / 2)
    return arb.log((1 + z) / (1 - z)) / 2 + arb.atan(z)


w = (
    tail(a - x)
    + 2 * tail(x)
    - tail(a + x)
    + c0
    - 8 * arb.sinh(x / 2) * (arb.cosh(a / 2) - 1)
)

assert w > arb("-0.129")
assert w < arb("-0.128")
print(w)
