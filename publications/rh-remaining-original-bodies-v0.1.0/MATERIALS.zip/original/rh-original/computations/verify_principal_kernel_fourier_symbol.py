import math


def kappa_log(t: float) -> float:
    a = math.log(2.0)
    if abs(t) > a:
        return 0.0
    return 4.0 * math.exp(-abs(t)) - math.exp(abs(t))


def simpson_even_cos(xi: float, n: int = 20000) -> float:
    a = math.log(2.0)
    # Integrate the even function on [0,a] and double it.
    h = a / n
    total = kappa_log(0.0)
    total += kappa_log(a) * math.cos(xi * a)
    odd = 0.0
    even = 0.0
    for j in range(1, n):
        t = j * h
        value = kappa_log(t) * math.cos(xi * t)
        if j % 2:
            odd += value
        else:
            even += value
    return 2.0 * h * (total + 4.0 * odd + 2.0 * even) / 3.0


def main() -> None:
    a = math.log(2.0)
    for xi in [0.0, 0.25, 1.0, 2.0, 5.0, 13.0, 41.0]:
        numerical = simpson_even_cos(xi)
        exact = 2.0 * (5.0 - 4.0 * math.cos(a * xi)) / (1.0 + xi * xi)
        assert abs(numerical - exact) < 2e-8, (xi, numerical, exact)
        assert 2.0 / (1.0 + xi * xi) - 1e-12 <= exact
        assert exact <= 18.0 / (1.0 + xi * xi) + 1e-12
    print("principal-kernel Fourier symbol verified at 7 frequencies")


if __name__ == "__main__":
    main()
