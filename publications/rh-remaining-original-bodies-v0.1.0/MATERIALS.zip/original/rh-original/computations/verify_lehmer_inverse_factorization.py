#!/usr/bin/env python3
"""Exact verification of the Lehmer inverse and its local energy factorization."""

from fractions import Fraction


def lehmer(n):
    return [[Fraction(min(i, j), max(i, j)) for j in range(1, n + 1)]
            for i in range(1, n + 1)]


def mat_inv(a):
    n = len(a)
    aug = [row[:] + [Fraction(int(i == j)) for j in range(n)]
           for i, row in enumerate(a)]
    for col in range(n):
        pivot = next(r for r in range(col, n) if aug[r][col])
        aug[col], aug[pivot] = aug[pivot], aug[col]
        q = aug[col][col]
        aug[col] = [v / q for v in aug[col]]
        for r in range(n):
            if r == col:
                continue
            q = aug[r][col]
            if q:
                aug[r] = [u - q * v for u, v in zip(aug[r], aug[col])]
    return [row[n:] for row in aug]


def predicted(n):
    out = [[Fraction(0) for _ in range(n)] for _ in range(n)]
    for i in range(1, n + 1):
        if i < n:
            out[i - 1][i - 1] = Fraction(4 * i**3, 4 * i**2 - 1)
        else:
            out[i - 1][i - 1] = Fraction(n * n, 2 * n - 1)
        if i < n:
            b = Fraction(-i * (i + 1), 2 * i + 1)
            out[i - 1][i] = out[i][i - 1] = b
    return out


def check_energy(n):
    inv = predicted(n)
    for i in range(n):
        for j in range(n):
            if inv[i][j] != mat_inv(lehmer(n))[i][j]:
                raise AssertionError((n, i, j, inv[i][j], mat_inv(lehmer(n))[i][j]))


if __name__ == "__main__":
    for n in range(1, 13):
        check_energy(n)
    print("Lehmer inverse tridiagonal factorization verified for N=1..12")

