#!/usr/bin/env python3
"""Exploratory periodization scan; no proof is inferred from this file.

For large m the periodization is severely cancellation-prone.  The default
100-digit precision is useful only for moderate m; use ``--dps`` substantially
larger than the target degree and confirm any near-zero sign with exact
rational arithmetic at rational y.
"""
import argparse
import mpmath as mp


def next_R(r, m, j):
    A, B = 2*j+1, 3*m+1-j
    out = [0]*(len(r)+1)
    for k, x in enumerate(r):
        out[k] += (A-k)*x
        out[k+1] += (B-A+k)*x
    return out


def make_R(m):
    r=[1]
    for j in range(m-1): r=next_R(r,m,j)
    scale=max(r)
    return [mp.mpf(x)/scale for x in r]


def eval_v(r,m,u):
    if u == 0 or u == 1:
        return mp.mpf('0')
    p=r[-1]; q=mp.mpf('0')
    for x in reversed(r[:-1]):
        q=q*u+p; p=p*u+x
    L=2*m+2
    f=u**3*(1-u)**L*p
    d=3/u-L/(1-u)+q/p
    return -f*d


def scan(m, ys):
    r=make_R(m); worst=(mp.inf,None)
    for y in ys:
        nmax=int(mp.floor(y))
        p=mp.fsum(eval_v(r,m,mp.mpf(n)/y) for n in range(1,nmax+1))
        if p<worst[0]: worst=(p,y)
    return worst


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--m0',type=int,default=1); ap.add_argument('--m1',type=int,default=100); ap.add_argument('--ymax',type=int,default=100); ap.add_argument('--ny',type=int,default=500); ap.add_argument('--dps',type=int,default=100,help='working decimal precision; increase aggressively with m'); ap.add_argument('--skip-y1',action='store_true',help='omit the endpoint y=1 when reporting the sampled minimum')
    a=ap.parse_args(); mp.mp.dps=a.dps
    ys=[1+mp.mpf(a.ymax-1)*k/a.ny for k in range(a.ny+1)]
    if a.skip_y1:
        ys=ys[1:]
    for m in range(a.m0,a.m1+1):
        w,y=scan(m,ys); print(f'm={m} worst={mp.nstr(w,12)} at y={mp.nstr(y,12)}',flush=True)

if __name__=='__main__': main()
