"""Arb certificate for positivity of the prime-free even Weil operator.

At a = log(2)/2, retain the first 20 positive boundary ranks in the
Neumann--Yukawa decomposition.  After shifting by delta = 1/2000, the diagonal
Neumann multiplier D - delta has one negative entry.  A rational Schur witness
proves that the 20 by 20 Schur complement has exactly one negative eigenvalue,
hence D + U U^* is bounded below by delta.  All omitted Yukawa boundary ranks
are positive.

Run:
    uv run --with python-flint python \
      computations/verify_prime_free_even_schur.py
"""

from flint import acb, arb, ctx


ctx.dps = 100

A = arb.log(arb(2)) / 2
PI = arb.pi()
RANKS = 20
FOURIER_CUTOFF = 20
DELTA = arb(1) / 2000

# Decimal strings are exact certificate input (outward-rounded Arb balls), not
# floating-point output used as evidence.  They approximate the unique negative
# eigenvector of the Schur matrix only to make the strict inequality easy.
W_TEXT = (
    "0.9495477063904442",
    "0.2545615814717162",
    "0.1374766767900488",
    "0.08492303458440797",
    "0.05678310787307346",
    "0.040266364326271516",
    "0.02991962043066829",
    "0.023090402099464218",
    "0.018381823524930552",
    "0.01501327965818202",
    "0.012526481461905428",
    "0.01064060335530875",
    "0.009176969117815044",
    "0.008018059310537385",
    "0.007084275909257858",
    "0.00632028354670903",
    "0.005686712299213139",
    "0.00515496578640861",
    "0.004703884174017085",
    "0.0043175467218891",
)


def multiplier(omega: arb) -> arb:
    """m(omega) = Re psi(1/4 + i omega/2) - log(pi)."""
    z = acb(arb(1) / 4, omega / 2)
    return z.digamma().real - arb.log(PI)


def overlap(k: int, c: arb) -> arb:
    """<e_k, cosh(c x)> on (0,a), for the orthonormal Neumann basis."""
    if k == 0:
        return (c * A).sinh() / (c * A.sqrt())
    omega = arb(k) * PI / A
    sign = arb(-1 if k % 2 else 1)
    return (
        (arb(2) / A).sqrt()
        * c
        * (c * A).sinh()
        * sign
        / (c**2 + omega**2)
    )


def strictly_positive(x: arb) -> bool:
    return x.lower() > 0


def strictly_negative(x: arb) -> bool:
    return x.upper() < 0


w = tuple(arb(x) for x in W_TEXT)
c = tuple(arb(2) * (arb(n) + arb(1) / 4) for n in range(RANKS))
rho = []
for n, cn in enumerate(c):
    rn = arb(2) * (-cn * A).exp() / (cn * A).sinh()
    if n == 0:
        # The positive even polar rank has the same vector cosh(x/2).
        rn += 4
    rho.append(rn)
sqrt_rho = tuple(x.sqrt() for x in rho)

d0 = multiplier(arb(0)) - DELTA
d1 = multiplier(PI / A) - DELTA
assert strictly_negative(d0)
assert strictly_positive(d1)

# S_delta = I + U^* (D-delta)^{-1} U = I + G_+ - v v^*.
# Evaluate w^* S w through k <= K, and bound the positive k > K tail.
w_norm_sq = sum(x**2 for x in w)
u0_dot_w = sum(sqrt_rho[n] * overlap(0, c[n]) * w[n] for n in range(RANKS))
schur_partial = w_norm_sq - u0_dot_w**2 / (-d0)

for k in range(1, FOURIER_CUTOFF + 1):
    omega = arb(k) * PI / A
    dk = multiplier(omega) - DELTA
    assert strictly_positive(dk)
    uk_dot_w = sum(
        sqrt_rho[n] * overlap(k, c[n]) * w[n] for n in range(RANKS)
    )
    schur_partial += uk_dot_w**2 / dk

# For k > K,
# |<e_k, sum z_n cosh(c_n x)>|
# <= sqrt(2/a) H / omega_k^2,
# H = sum |z_n| c_n sinh(c_n a), z_n=sqrt(rho_n) w_n.
# Since m is strictly increasing on (0,infinity), D_k >= D_{K+1}; and
# sum_{k>K} k^-4 <= integral_K^infinity x^-4 dx = 1/(3 K^3).
H = sum(
    abs(w[n]) * sqrt_rho[n] * c[n] * (c[n] * A).sinh()
    for n in range(RANKS)
)
k_next = FOURIER_CUTOFF + 1
d_tail = multiplier(arb(k_next) * PI / A) - DELTA
assert strictly_positive(d_tail)
tail_upper = (
    arb(2)
    * A**3
    * H**2
    / (arb(3) * PI**4 * arb(FOURIER_CUTOFF) ** 3 * d_tail)
)
schur_upper = schur_partial + tail_upper

print(f"a={A}")
print(f"delta={DELTA}")
print(f"D0_minus_delta={d0}")
print(f"D1_minus_delta={d1}")
print(f"ranks={RANKS}")
print(f"fourier_cutoff={FOURIER_CUTOFF}")
print(f"w_norm_sq={w_norm_sq}")
print(f"schur_partial={schur_partial}")
print(f"tail_upper={tail_upper}")
print(f"schur_quadratic_upper={schur_upper}")
print(f"certified_negative={strictly_negative(schur_upper)}")

assert strictly_negative(schur_upper)
