#!/usr/bin/env python3
"""Exact OMEN-side check for note 469's projected-tail variance bound."""

from __future__ import annotations

import argparse
from fractions import Fraction


def mobius_table(n_max: int) -> list[int]:
    mu = [1] * (n_max + 1)
    mu[0] = 0
    primes: list[int] = []
    composite = [False] * (n_max + 1)
    for n in range(2, n_max + 1):
        if not composite[n]:
            primes.append(n)
            mu[n] = -1
        for p in primes:
            if n * p > n_max:
                break
            composite[n * p] = True
            if n % p == 0:
                mu[n * p] = 0
                break
            mu[n * p] = -mu[n]
    return mu


def run(max_n: int) -> int:
    mu = mobius_table(max_n)
    harmonic = [Fraction(0)] * (max_n + 1)
    for n in range(1, max_n + 1):
        harmonic[n] = harmonic[n - 1] + Fraction(1, n)

    def z_layer(m: int, cutoff: int, q: int) -> Fraction:
        b_max = m // (cutoff + 1)
        return sum(
            Fraction(mu[b], b) *
            (harmonic[m // b] - harmonic[max(cutoff, q // b)])
            for b in range(1, b_max + 1)
        )

    checked = 0
    for n in range(3, max_n + 1):
        for cutoff in range(1, (n - 1) // 2 + 1):
            h = cutoff + 1
            d0 = (n - 1) // h
            if d0 < 1:
                continue
            rows = list(range(1, n))
            weights = [2 * k + 1 for k in rows]
            # q_1 is the d=1 platform-off-platform column.
            m = n
            values = [z_layer(m, cutoff, k) for k in rows]
            # First tail block I_1=[h,2h-1].
            block = [k for k in rows if h <= k <= 2 * h - 1]
            if not block:
                continue
            block_w = [2 * k + 1 for k in block]
            x = [harmonic[k] - harmonic[cutoff] for k in block]
            weight_sum = sum(block_w)
            v_a = sum(Fraction(w) * xx * xx for w, xx in zip(block_w, x))
            v_a -= sum(Fraction(w) * xx for w, xx in zip(block_w, x)) ** 2 / weight_sum
            # The q_1 block covariance is independent of the additive z_0 constant.
            mean = sum(Fraction(w) * val for w, val in zip(block_w, values[h - 1:2 * h - 1])) / weight_sum
            projected = sum(
                Fraction(w) * (val - mean) ** 2
                for w, val in zip(block_w, values[h - 1:2 * h - 1])
            )
            if projected != v_a:
                raise AssertionError(("first-block-variance", n, cutoff, projected, v_a))
            if projected < 0:
                raise AssertionError(("negative", n, cutoff))
            checked += 1

    print(f"PASS {checked} exact first-tail variance instances")
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-n", type=int, default=80)
    args = parser.parse_args()
    raise SystemExit(run(args.max_n))
