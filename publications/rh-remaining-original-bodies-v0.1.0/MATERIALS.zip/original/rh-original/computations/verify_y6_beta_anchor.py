#!/usr/bin/env python3
"""Exact OMEN-side regression check for the y=6 beta anchor."""

from fractions import Fraction
from math import comb, factorial


def theta_plus(poly, c):
    return [value * (c - degree) for degree, value in enumerate(poly)]


def normalization(m):
    value = 3 * m + 4
    for j in range(1, m):
        value *= 3 * m + 2 - 2 * j
    return value


def coefficients(m):
    poly = [Fraction(0)] * (3 * m + 4)
    for j in range(3 * m + 2):
        poly[j + 2] = Fraction((-1) ** j * comb(3 * m + 1, j))
    for j in range(1, m):
        poly = theta_plus(poly, 2 * j + 1)
    poly = theta_plus(poly, -1)
    scale = normalization(m)
    return [value / scale for value in poly]


def direct_p6(m):
    poly = coefficients(m)
    return sum(
        sum(value * Fraction(k, 6) ** degree for degree, value in enumerate(poly))
        for k in range(1, 6)
    )


def d_coefficient(m, r):
    degree = 3 * m + 3
    return Fraction(
        factorial(degree) * factorial(m + r - 2),
        comb(degree, 2)
        * 2**r
        * factorial(r - 1)
        * factorial(m - r)
        * factorial(2 * m + r + 1),
    )


def beta_term(m, r):
    p = m - r + 3
    q = 2 * m + r + 1
    return sum(
        k ** (p - 1)
        * (6 - k) ** (q - 1)
        * ((3 * m + 4) * k - 6 * p)
        for k in range(1, 6)
    )


def beta_p6(m):
    total = sum(
        d_coefficient(m, r) * beta_term(m, r)
        for r in range(1, m + 1)
    )
    return total / (6 ** (3 * m + 3) * normalization(m))


def main():
    for m in range(1, 51):
        direct = direct_p6(m)
        beta = beta_p6(m)
        assert direct == beta, (m, direct, beta)
        assert direct > 0, (m, direct)
    print("y=6 beta/direct checks passed for m=1..50")


if __name__ == "__main__":
    main()
