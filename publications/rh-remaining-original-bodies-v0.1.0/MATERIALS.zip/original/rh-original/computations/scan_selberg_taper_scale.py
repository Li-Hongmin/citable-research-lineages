#!/usr/bin/env python3
"""OMEN-only exploratory scan for Selberg taper at N/D > 1."""
from math import log
import argparse


def mobius_sieve(n):
    mu = [1] * (n + 1)
    is_prime = [True] * (n + 1)
    primes = []
    mu[0] = 0
    for i in range(2, n + 1):
        if is_prime[i]:
            primes.append(i)
            mu[i] = -1
        for p in primes:
            if i * p > n:
                break
            is_prime[i * p] = False
            if i % p == 0:
                mu[i * p] = 0
                break
            mu[i * p] = -mu[i]
    return mu


def energy(D, ratio):
    N = int(round(ratio * D))
    mu = mobius_sieve(N)
    L = log(D)
    c = [0.0] * (D + 1)
    for d in range(1, D + 1):
        c[d] = 1.0 - log(d) / L
    a = [0.0] * (N + 1)
    # a_n=(c*mu)(n); divisor form is O(N log N).
    for d in range(1, D + 1):
        cd = c[d]
        for j in range(1, N // d + 1):
            a[d * j] += cd * mu[j]
    tail = 0.0
    E = 0.0
    for k in range(N - 1, 0, -1):
        tail += a[k + 1] / (k + 1)
        E += (2.0 * k + 1.0) * tail * tail
    return N, E


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-D", type=int, default=2000)
    ap.add_argument("--ratios", default="1,1.25,1.5,2,3")
    args = ap.parse_args()
    ratios = [float(x) for x in args.ratios.split(",")]
    for ratio in ratios:
        print(f"ratio={ratio}")
        for D in (100, 200, 400, 800, 1200, 1600, 2000):
            if D > args.max_D:
                continue
            N, E = energy(D, ratio)
            print(f"D={D} N={N} E={E:.9g} E/N={E/N:.9g} E/N^2={E/(N*N):.9g}")


if __name__ == "__main__":
    main()
