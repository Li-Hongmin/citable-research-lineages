#!/usr/bin/env python3
"""OMEN-only calibration of the growing-offset long-tail triple gate.

For the exact identity

    B_U(2U+q)-B_U(2U+q-1)
      = lambda(2U+q-1) S_U - C_U(q),

this script measures the accumulated triple term

    T_U(Q) = sum_{q<=Q} lambda(2U+q-1) C_U(q).

The identity is checked against FFT correlations.  This is finite diagnostic
evidence only; it is not an estimate for the Liouville function and does not
prove RH.
"""

from __future__ import annotations

import sys

import numpy as np


def liouville(n: int) -> np.ndarray:
    value = np.ones(n + 1, dtype=np.int8)
    value[0] = 0
    composite = np.zeros(n + 1, dtype=np.bool_)
    primes: list[int] = []
    for i in range(2, n + 1):
        if not composite[i]:
            primes.append(i)
            value[i] = -1
        for prime in primes:
            multiple = i * prime
            if multiple > n:
                break
            composite[multiple] = True
            value[multiple] = -value[i]
            if i % prime == 0:
                break
    return value


def profile(u: int, q_fraction: float = 0.5) -> None:
    q = max(1, int(u * q_fraction))
    values = liouville(2 * u + q)
    segment = values[u + 1 : 2 * u].astype(np.float64)
    length = 2 * u
    padded = np.zeros(length, dtype=np.float64)
    padded[: len(segment)] = segment
    transform = np.fft.rfft(padded)
    corr = np.rint(
        np.fft.irfft(transform * np.conj(transform), n=length)[:q + 1]
    ).astype(np.int64)
    shifts = corr[1 : q + 1]
    endpoint = values[2 * u : 2 * u + q].astype(np.int64)
    s = int(segment.sum())
    b0 = (s * s - len(segment)) // 2
    delta = endpoint * s - shifts
    b = b0 + np.cumsum(delta, dtype=np.int64)
    triple = int(np.dot(endpoint, shifts))
    qs = q * s
    weighted_delta = int(np.dot(endpoint, delta))
    identity_residual = weighted_delta - (qs - triple)
    flips = int(np.count_nonzero(endpoint[1:] != endpoint[:-1]))
    endpoint_variation = 2 + 2 * flips

    print(
        f"U={u} Q={q} S={s} B0={b0} BQ={int(b[-1])} "
        f"max|Bq|={int(np.max(np.abs(b)))}"
    )
    print(
        f"  Q*S={qs} T={triple} "
        f"T/(Q*S)={triple/qs if qs else float('nan'):.12g} "
        f"identity_residual={identity_residual} "
        f"endpoint_flips={flips} endpoint_variation={endpoint_variation}"
    )
    print(
        f"  |T|/(Q*sqrt(U))={abs(triple)/(q*np.sqrt(u)):.12g} "
        f"sum|Cq|/(Q*U)={np.abs(shifts).sum()/(q*u):.12g}"
    )


if __name__ == "__main__":
    sizes = [int(argument) for argument in sys.argv[1:]]
    for size in sizes or [2**14, 2**16, 2**18, 2**20]:
        profile(size)
