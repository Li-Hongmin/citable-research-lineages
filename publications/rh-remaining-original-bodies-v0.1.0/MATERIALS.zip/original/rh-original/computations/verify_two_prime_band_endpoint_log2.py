"""Rigorous Arb certificate for A^+_{log 2}>0 and A^-_{log 2}>0.

Usage:
    python verify_two_prime_band_endpoint_log2.py PREC R N +
    python verify_two_prime_band_endpoint_log2.py PREC R N -

All integrals are evaluated from closed exponential formulas.  Rates are stored
symbolically as r + i*q*pi/log(2), with rational r,q, so removable zero-rate
cases are detected exactly rather than by interval comparison.
"""
from fractions import Fraction
from flint import arb, acb, arb_mat, ctx
import sys, time

ctx.prec = int(sys.argv[1]) if len(sys.argv) > 1 else 320
R = int(sys.argv[2]) if len(sys.argv) > 2 else 30
N = int(sys.argv[3]) if len(sys.argv) > 3 else 80
PAR = sys.argv[4] if len(sys.argv) > 4 else "+"
if PAR not in {"+", "-"}:
    raise ValueError("parity must be + or -")

a = arb(2).log()
pi = arb.pi()
d2 = a
d3 = arb(3).log()
p2 = d2 / arb(2).sqrt()
p3 = d3 / arb(3).sqrt()
sigma = -1 if PAR == "+" else 1

# A rate key (r,q) represents r + i*q*pi/a, with r,q exact rationals.
def A(x: Fraction | int) -> arb:
    x = Fraction(x)
    return arb(x.numerator) / x.denominator

def rate_value(key):
    r, q = key
    return acb(A(r), A(q) * pi / a)

def key_neg(key):
    return (-key[0], -key[1])

def Iexp(key, lo, hi):
    if key == (Fraction(0), Fraction(0)):
        return acb(hi - lo)
    z = rate_value(key)
    return ((z * hi).exp() - (z * lo).exp()) / z

def inner(rep1, rep2, lo, hi):
    out = acb(0)
    for c1, k1 in rep1:
        for c2, k2 in rep2:
            # conjugation keeps the real exponent and reverses frequency.
            key = (k1[0] + k2[0], -k1[1] + k2[1])
            out += c1.conjugate() * c2 * Iexp(key, lo, hi)
    return out.real

def basis_rep(k):
    if PAR == "+":
        if k == 0:
            return [(acb(1 / a.sqrt()), (Fraction(0), Fraction(0)))]
        norm = (arb(2) / a).sqrt()
        return [
            (acb(norm / 2), (Fraction(0), Fraction(k))),
            (acb(norm / 2), (Fraction(0), Fraction(-k))),
        ]
    q = Fraction(2 * k + 1, 2)
    norm = (arb(2) / a).sqrt()
    return [
        (acb(0, -norm / 2), (Fraction(0), q)),
        (acb(0, norm / 2), (Fraction(0), -q)),
    ]

def reflect(rep, d):
    out = []
    for coeff, key in rep:
        out.append((coeff * (rate_value(key) * d).exp(), key_neg(key)))
    return out

def rank_rep(n):
    # c_n = 2(n+1/4) = 2n+1/2 is exact rational.
    ckey = Fraction(4 * n + 1, 2)
    c = A(ckey)
    em = (-c * a).exp()
    if PAR == "+":
        den = (1 - em * em).sqrt()
        return [
            (acb(em / den), (ckey, Fraction(0))),
            (acb(em / den), (-ckey, Fraction(0))),
        ]
    den = (1 + em * em).sqrt()
    return [
        (acb(em / den), (ckey, Fraction(0))),
        (acb(-em / den), (-ckey, Fraction(0))),
    ]

def polar_rep():
    return [
        (acb(1), (Fraction(1, 2), Fraction(0))),
        (acb(1 if PAR == "+" else -1), (Fraction(-1, 2), Fraction(0))),
    ]

def scale_cols(mat, signs):
    return arb_mat(
        [[mat[i, j] * signs[j] for j in range(mat.ncols())]
         for i in range(mat.nrows())]
    )

start = time.time()
BAS = [basis_rep(i) for i in range(R)]
FUN = [rank_rep(n) for n in range(N)] + [polar_rep()]
M = N + 1
signs = [1] * N + [1 if PAR == "+" else -1]
print(f"parameters parity={PAR} prec={ctx.prec} R={R} N={N}")

H = arb_mat([[inner(BAS[i], FUN[j], arb(0), a) for j in range(M)]
             for i in range(R)])
K = arb_mat([[inner(FUN[i], FUN[j], arb(0), a) for j in range(M)]
             for i in range(M)])
print("finite-rank Gram matrices built", flush=True)

Prows = [[arb(0) for _ in range(R)] for _ in range(R)]
Grows = [[arb(0) for _ in range(M)] for _ in range(R)]
for d, p in ((d2, p2), (d3, p3)):
    lo = d - a
    RB = [reflect(rep, d) for rep in BAS]
    RF = [reflect(rep, d) for rep in FUN]
    for i in range(R):
        for j in range(R):
            Prows[i][j] += sigma * p * inner(BAS[i], RB[j], lo, a)
        for j in range(M):
            Grows[i][j] += sigma * p * inner(BAS[i], RF[j], lo, a)
Pmat = arb_mat(Prows)
Gmat = arb_mat(Grows)

P2rows = [[arb(0) for _ in range(R)] for _ in range(R)]
for d, pd in ((d2, p2), (d3, p3)):
    RD = [reflect(rep, d) for rep in BAS]
    for e, pe in ((d2, p2), (d3, p3)):
        RE = [reflect(rep, e) for rep in BAS]
        # At a=log2 the ordering is exact: d2-a=0<d3-a.
        lo = d - a if d > e else e - a
        for i in range(R):
            for j in range(R):
                P2rows[i][j] += pd * pe * inner(RD[i], RE[j], lo, a)
P2mat = arb_mat(P2rows)
print("prime reflection matrices built", flush=True)

HS = scale_cols(H, signs)
GS = scale_cols(Gmat, signs)
Ht, Gt, HSt = H.transpose(), Gmat.transpose(), HS.transpose()
Bpp = Pmat + HS * Ht
B2pp = P2mat + GS * Ht + HS * Gt + HS * K * HSt
CC = B2pp - Bpp * Bpp

Dvals = []
for k in range(R):
    q = Fraction(k) if PAR == "+" else Fraction(2 * k + 1, 2)
    kappa = A(q) * pi / a
    Dvals.append(acb(arb(1) / 4, kappa / 2).digamma().real - pi.log())
qR = Fraction(R) if PAR == "+" else Fraction(2 * R + 1, 2)
kappa_R = A(qR) * pi / a
d_R = acb(arb(1) / 4, kappa_R / 2).digamma().real - pi.log()

rho = (p3 + (p3 * p3 + 4 * p2 * p2).sqrt()) / 2
mu = d_R - rho
if PAR == "-":
    mu -= 2 * (a.sinh() - a)
if not (mu > 0):
    raise ArithmeticError(f"complement lower bound is not positive: {mu}")
print("complement_lower_mu=", mu, flush=True)

S = arb_mat([
    [Bpp[i, j] - CC[i, j] / mu + (Dvals[i] if i == j else 0)
     for j in range(R)]
    for i in range(R)
])
# The exact matrix is symmetric; symmetrisation tightens roundoff enclosures.
S = (S + S.transpose()) / 2

# Rigorous no-pivot interval LDL^T.  Positive pivots certify S>0.
L = [[arb(0) for _ in range(R)] for _ in range(R)]
diag = [arb(0) for _ in range(R)]
min_lower = None
for i in range(R):
    pivot = S[i, i]
    for k in range(i):
        pivot -= L[i][k] * L[i][k] * diag[k]
    if not (pivot > 0):
        print("FAILED_PIVOT", i, pivot)
        raise SystemExit(2)
    diag[i] = pivot
    lo = pivot.lower()
    if min_lower is None or lo < min_lower:
        min_lower = lo
    L[i][i] = arb(1)
    for j in range(i + 1, R):
        val = S[j, i]
        for k in range(i):
            val -= L[j][k] * L[i][k] * diag[k]
        L[j][i] = val / pivot

print("CERTIFIED parity=", PAR)
print("min_LDL_pivot_lower=", min_lower)
print("elapsed_seconds=", time.time() - start)
