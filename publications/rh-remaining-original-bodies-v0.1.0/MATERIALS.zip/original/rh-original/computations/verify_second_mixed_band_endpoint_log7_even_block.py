"""Four-dimensional near-kernel certificate executed after the Arb matrix S is built."""

import sys
import numpy as np

assert PAR == "+" and R == 128 and N == 400
BLOCK = 4
VECTOR_BITS = 44
CHOLESKY_BITS = 52
C0 = arb(1) / 2000000

B = S
Bmid = np.array([[float(B[i, j].mid()) for j in range(R)] for i in range(R)])
initial_eigs = np.linalg.eigvalsh(Bmid)[:8]

# Exact rational Householder congruences.  At stage k the generator has its
# first k entries zero, so already isolated coordinates remain fixed.
for k in range(BLOCK):
    trailing = (Bmid[k:, k:] + Bmid[k:, k:].T) / 2
    _, vecs = np.linalg.eigh(trailing)
    q = vecs[:, 0]
    sign = 1.0 if q[0] >= 0 else -1.0
    witness_float = np.zeros(R)
    witness_float[k:] = q
    witness_float[k] -= sign
    witness_int = np.rint(witness_float * 2.0**VECTOR_BITS).astype(object)
    witness = [arb(int(z)) / (2**VECTOR_BITS) for z in witness_int]
    norm2 = sum((z * z for z in witness), arb(0))
    assert norm2.lower() > 0
    bw = [
        sum((B[i, j] * witness[j] for j in range(R)), arb(0))
        for i in range(R)
    ]
    wbw = sum((witness[i] * bw[i] for i in range(R)), arb(0))
    two = arb(2) / norm2
    four = arb(4) * wbw / norm2**2
    B = arb_mat([
        [
            B[i, j]
            - two * (witness[i] * bw[j] + bw[i] * witness[j])
            + four * witness[i] * witness[j]
            for j in range(R)
        ]
        for i in range(R)
    ])

    # Floating arithmetic selects the next witness only.
    witness_mid = np.array([float(z.mid()) for z in witness])
    householder_mid = (
        np.eye(R)
        - 2 * np.outer(witness_mid, witness_mid)
        / np.dot(witness_mid, witness_mid)
    )
    Bmid = householder_mid @ Bmid @ householder_mid

complement_dimension = R - BLOCK
Cminus = arb_mat([
    [
        B[i + BLOCK, j + BLOCK] - (C0 if i == j else arb(0))
        for j in range(complement_dimension)
    ]
    for i in range(complement_dimension)
])
Cmid = np.array([
    [
        float(Cminus[i, j].mid())
        for j in range(complement_dimension)
    ]
    for i in range(complement_dimension)
])
cholesky_float = np.linalg.cholesky((Cmid + Cmid.T) / 2)
scale = 2**CHOLESKY_BITS
cholesky = arb_mat([
    [
        arb(int(np.rint(cholesky_float[i, j] * scale))) / scale
        if j <= i else arb(0)
        for j in range(complement_dimension)
    ]
    for i in range(complement_dimension)
])
residual = Cminus - cholesky * cholesky.transpose()
residual_infinity = arb(0)
for i in range(complement_dimension):
    row_sum = sum(
        (abs(residual[i, j]) for j in range(complement_dimension)),
        arb(0),
    )
    if row_sum.upper() > residual_infinity.upper():
        residual_infinity = row_sum
complement_lower = C0 - residual_infinity
assert complement_lower.lower() > 0

A4 = arb_mat([[B[i, j] for j in range(BLOCK)] for i in range(BLOCK)])
cross = arb_mat([
    [B[i, j + BLOCK] for j in range(complement_dimension)]
    for i in range(BLOCK)
])
complement = arb_mat([
    [
        B[i + BLOCK, j + BLOCK]
        for j in range(complement_dimension)
    ]
    for i in range(complement_dimension)
])

# complement.solve is an Arb verified solve.  It is valid because positivity
# of the complement was independently certified above.
solution = complement.solve(cross.transpose())
small_schur = A4 - cross * solution

lower = [[arb(0) for _ in range(BLOCK)] for _ in range(BLOCK)]
pivots = []
for i in range(BLOCK):
    pivot = small_schur[i, i]
    for k in range(i):
        pivot -= lower[i][k] ** 2 * pivots[k]
    print("small_pivot", i, pivot, flush=True)
    assert pivot.lower() > 0
    pivots.append(pivot)
    lower[i][i] = arb(1)
    for j in range(i + 1, BLOCK):
        value = small_schur[j, i]
        for k in range(i):
            value -= lower[j][k] * lower[i][k] * pivots[k]
        lower[j][i] = value / pivot

print("initial_midpoint_eigs", initial_eigs, flush=True)
print("C0", C0, flush=True)
print("cholesky_residual_inf", residual_infinity, flush=True)
print("C_certified_lower", complement_lower, flush=True)
print("BLOCK4_CERTIFIED", flush=True)
sys.exit(0)
