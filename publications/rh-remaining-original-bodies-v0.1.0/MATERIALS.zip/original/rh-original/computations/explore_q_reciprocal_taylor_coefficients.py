"""Explore Taylor coefficients of 1 / Q(Cayley(z)) with Arb series.

The finite coefficient data are rigorous enclosures at the requested precision,
but they do not certify any infinite tail and are not evidence for RH.

Reproduce with:

    uv run --with python-flint --with numpy python \
      computations/explore_q_reciprocal_taylor_coefficients.py
"""

from __future__ import annotations

import argparse

import numpy as np
from flint import acb_series, arb, ctx


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--count", type=int, default=1024)
    parser.add_argument("--digits", type=int, default=1900)
    return parser.parse_args()


def reciprocal_series(count: int, digits: int) -> acb_series:
    # Derivatives lose one coefficient, so retain a small guard band.
    ctx.cap = count + 4
    ctx.dps = digits

    z = acb_series([0, 1])
    s = arb("0.5") + (1 + z) / (1 - z)
    ds_dz = s.derivative()

    zeta = s.zeta()
    dzeta_ds = zeta.derivative() / ds_dz

    gamma_factor = (
        arb("0.5")
        * s
        * (s - 1)
        * (-s * arb.pi().log() / 2).exp()
        * (s / 2).gamma()
    )
    dlog_gamma_factor_ds = gamma_factor.derivative() / ds_dz / gamma_factor

    q_series = (s - 1) / s * (
        dzeta_ds + (1 + dlog_gamma_factor_ds) * zeta
    )
    return 1 / q_series


def main() -> None:
    args = parse_args()
    if args.count < 1:
        raise ValueError("--count must be positive")

    reciprocal = reciprocal_series(args.count, args.digits)
    coefficients = np.array(
        [float(reciprocal[index].real.mid()) for index in range(args.count)]
    )

    max_imag_radius = max(
        (reciprocal[index].imag.rad() for index in range(args.count)),
        key=lambda value: float(value.log()) if value > 0 else float("-inf"),
    )
    max_real_radius = max(
        (reciprocal[index].real.rad() for index in range(args.count)),
        key=lambda value: float(value.log()) if value > 0 else float("-inf"),
    )

    print("FINITE ARB COEFFICIENT ENCLOSURES; NO INFINITE-TAIL CLAIM")
    print("count =", args.count)
    print("digits =", args.digits)
    print("max real radius =", max_real_radius)
    print("max imaginary radius =", max_imag_radius)
    print("N  partial_l1  partial_l2_squared  |g_N|")

    checkpoints = [
        value
        for value in (8, 16, 32, 64, 128, 256, 512, 1023)
        if value < args.count
    ]
    for endpoint in checkpoints:
        absolute = np.abs(coefficients[: endpoint + 1])
        print(
            endpoint,
            float(np.sum(absolute)),
            float(np.dot(absolute, absolute)),
            float(absolute[-1]),
        )


if __name__ == "__main__":
    main()
