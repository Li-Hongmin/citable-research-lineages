#!/usr/bin/env python3
"""OMEN-only Fourier-to-bilinear profile for the minor-arc shell block.

For a fixed FFT-grid minor mask M and dyadic shell E_j, this script expands

    (1/N) \int M(theta) |F_N(theta)|^2 K_H(theta) dtheta

as a signed lag sum \sum_r a_{j,r} C_r(N), where C_r is the circular
Möbius autocorrelation of the zero-padded vector.  The reconstruction is
checked against the direct Fourier sum.  It is a finite route diagnostic:
the lag profile is not an asymptotic estimate and does not prove RH.
"""

from __future__ import annotations

import gc
import math
import sys
from fractions import Fraction

import numpy as np


def mobius(n: int) -> np.ndarray:
    value = np.zeros(n + 1, dtype=np.int8)
    value[1] = 1
    composite = np.zeros(n + 1, dtype=np.bool_)
    primes: list[int] = []
    for i in range(2, n + 1):
        if not composite[i]:
            primes.append(i)
            value[i] = -1
        for prime in primes:
            multiple = i * prime
            if multiple > n:
                break
            composite[multiple] = True
            if i % prime == 0:
                value[multiple] = 0
                break
            value[multiple] = -value[i]
    return value


def half_to_full(values: np.ndarray) -> np.ndarray:
    """Reflect an even real rfft half-spectrum to a length-L full array."""
    return np.concatenate((values, values[-2:0:-1]))


def best_dyadic_block(corr: np.ndarray, n: int) -> tuple[int, int]:
    best = (0, 0)
    h = 1
    while h < n:
        signed = int(corr[h : min(2 * h, n)].sum())
        candidate = (abs(signed), h)
        if candidate > best:
            best = candidate
        h *= 2
    return best[1], int(corr[best[1] : min(2 * best[1], n)].sum())


def make_minor_mask(length: int, h: int, qmax: int) -> np.ndarray:
    fractions: set[Fraction] = set()
    for q in range(1, qmax + 1):
        for a in range(q):
            if math.gcd(a, q) == 1:
                raw = Fraction(a, q)
                fractions.add(min(raw, 1 - raw))
    half_size = length // 2 + 1
    major = np.zeros(half_size, dtype=np.bool_)
    radius = max(1, int(math.ceil(length / (8 * h))))
    for frac in fractions:
        center = int(round(float(frac) * length))
        major[
            max(0, center - radius) : min(half_size, center + radius + 1)
        ] = True
    return ~major


def profile(n: int = 2**22, qmax: int = 4096, shell_count: int = 6) -> None:
    value = mobius(n).astype(np.float64)
    length = 4 * n
    padded = np.zeros(length, dtype=np.float64)
    padded[1 : n + 1] = value[1:]
    transform = np.fft.rfft(padded)
    power = transform.real * transform.real + transform.imag * transform.imag
    corr = np.fft.irfft(power, n=length)
    h, signed = best_dyadic_block(corr, n)

    k = np.arange(len(power), dtype=np.int64)
    theta = k.astype(np.float64) / length
    denominator = np.sin(np.pi * theta)
    numerator = np.sin(np.pi * h * theta)
    phase = np.exp(2j * np.pi * (h + (h - 1) / 2.0) * theta)
    kernel = np.empty_like(phase)
    kernel[0] = h
    kernel[1:] = phase[1:] * numerator[1:] / denominator[1:]
    distance = np.minimum(k, length - k)
    theta_h = distance.astype(np.float64) * h / length
    shell = np.zeros(distance.shape, dtype=np.int32)
    active = theta_h > 1.0
    shell[active] = np.ceil(np.log2(theta_h[active])).astype(np.int32)
    multiplicity = np.full(k.shape, 2.0)
    multiplicity[(k == 0) | (k == length // 2)] = 1.0
    minor = make_minor_mask(length, h, qmax)
    scale = 1.0 / (n * length)
    correlation = corr.copy()

    print(f"N={n} H={h} corr={signed} qmax={qmax}")
    for j in range(shell_count):
        shell_half = shell == j
        weight_half = (minor & shell_half).astype(np.float64) * kernel.real
        direct = float(np.sum(multiplicity * power * weight_half) * scale)

        weight_full = half_to_full(weight_half)
        coeff = np.fft.ifft(weight_full).real
        lag_terms = correlation * coeff / n
        reconstructed = float(lag_terms.sum())

        print(
            f"shell={j} direct={direct:.12g} "
            f"reconstructed={reconstructed:.12g} "
            f"residual={reconstructed-direct:.3e}"
        )
        for radius in (0, 1, 2, 4, 8, 16, 32, 64, 128, 256,
                       512, 1024, 2048, 4096, 8192, 16384,
                       32768, 65536, 131072, 262144, 524288):
            upto = min(radius, length // 2 - 1)
            if radius == 0:
                partial = float(lag_terms[0])
            else:
                partial = float(
                    lag_terms[0]
                    + lag_terms[1 : upto + 1].sum()
                    + lag_terms[-upto:].sum()
                )
            print(f"  |r|<={radius} partial={partial:.12g}")
        abs_total = float(np.abs(lag_terms).sum())
        print(f"  lag_abs_total={abs_total:.12g}")
        del weight_full, coeff, lag_terms
        gc.collect()


if __name__ == "__main__":
    sizes = [int(argument) for argument in sys.argv[1:]]
    for size in sizes or [2**22]:
        profile(size)
