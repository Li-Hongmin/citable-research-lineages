#!/usr/bin/env python3
"""Strict Arb proof of one whitened tangent-disk factor-5 certificate."""

from __future__ import annotations

from flint import acb, acb_series, arb, ctx


BAND_TOP = arb("0.5")
TAU = arb("19029.5")
ARC_COUNT = 8192


def f_value(s: acb) -> acb:
    variable = acb_series([s, acb(1)], 3)
    gamma_factor = (
        variable
        * (variable - 1)
        / 2
        * (-variable * arb.pi().log() / 2).exp()
        * (variable / 2).gamma()
    )
    xi_series = gamma_factor * variable.zeta()
    return xi_series[0] + xi_series[1]


def f_value_and_derivative(s: acb) -> tuple[acb, acb]:
    variable = acb_series([s, acb(1)], 4)
    gamma_factor = (
        variable
        * (variable - 1)
        / 2
        * (-variable * arb.pi().log() / 2).exp()
        * (variable / 2).gamma()
    )
    xi_series = gamma_factor * variable.zeta()
    value = xi_series[0] + xi_series[1]
    derivative = xi_series[1] + 2 * xi_series[2]
    return value, derivative


def main() -> None:
    ctx.dps = 40
    ctx.cap = 4

    radius = 3 * BAND_TOP / 4
    center = acb(arb("0.5") + radius, TAU)
    center_value, center_derivative = f_value_and_derivative(center)
    logarithmic_jet = center_derivative / center_value

    total_upper_ball = arb(0)
    pi = arb.pi()
    half_width = pi / ARC_COUNT
    for index in range(ARC_COUNT):
        midpoint = (2 * index + 1) * pi / ARC_COUNT
        theta = arb(midpoint, half_width)
        point = center + radius * acb(theta.cos(), theta.sin())
        normalized = (
            f_value(point)
            / center_value
            * (-logarithmic_jet * (point - center)).exp()
        )
        total_upper_ball += normalized.real**2 + normalized.imag**2

    mean_square = total_upper_ball / ARC_COUNT
    upper = mean_square.upper()

    print("STRICT Arb whitened tangent-disk certificate")
    print("band top A =", BAND_TOP)
    print("center =", center)
    print("radius =", radius)
    print("arc count =", ARC_COUNT)
    print("R f'(c)/f(c) =", radius * logarithmic_jet)
    print("full circle mean-square enclosure =", mean_square)
    print("rigorous upper endpoint =", upper)
    print("factor-5 threshold = 5")
    if not upper < 5:
        raise AssertionError("the interval upper bound did not clear factor 5")
    print("PASS: the complete whitened q=1 circle moment is strictly below 5")


if __name__ == "__main__":
    main()
