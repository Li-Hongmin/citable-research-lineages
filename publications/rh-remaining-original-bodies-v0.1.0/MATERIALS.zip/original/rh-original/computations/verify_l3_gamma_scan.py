#!/usr/bin/env python3
"""Exact finite scan of the ``L=3`` Newton gamma layer.

This is deliberately a thin wrapper around the closed formula implemented in
``verify_gamma_newton_cone.py``.  Every value is a :class:`fractions.Fraction`;
there is no floating-point or interval arithmetic in this check.  The scan
checks all ``h=0,...,3m+1`` for ``m=1,...,M`` and stops at the first negative
coefficient.  It is a finite audit only: passing a range does not prove the
all-``m`` positivity statement.
"""

from __future__ import annotations

import argparse
from fractions import Fraction

from verify_gamma_newton_cone import gamma


L = 3


def scan(max_m: int) -> int:
    if max_m < 1:
        raise ValueError("M must be positive")

    global_min: tuple[Fraction, int, int] | None = None
    for m in range(1, max_m + 1):
        # In the notation of note 156, d=3m+1, so there are d+1 values of h.
        values = [gamma(m, h, L) for h in range(3 * m + 2)]
        # These low-index identities are useful guards against accidentally
        # changing the closed formula while refactoring the audit code.
        if m <= 2:
            assert values == [Fraction(0)] * (3 * m + 2), (
                f"unexpected low-index L=3 row for m={m}: {values}"
            )
        if m == 3:
            assert min(values) == Fraction(928, 15), values
        negatives = [(h, value) for h, value in enumerate(values) if value < 0]
        if negatives:
            h, value = negatives[0]
            print(f"NEGATIVE m={m} h={h} L={L} gamma={value}")
            return 1

        minimum = min(values)
        h_min = values.index(minimum)
        candidate = (minimum, m, h_min)
        if global_min is None or candidate[0] < global_min[0]:
            global_min = candidate

        # Keep the exact rational witness visible for every m.  This is useful
        # when a future run first finds a negative value or a new zero.
        print(f"m={m} h=0..{3*m+1} nonnegative; min={minimum} at h={h_min}")

    assert global_min is not None
    value, m, h = global_min
    print(
        f"SCAN PASSED: L={L}, m=1..{max_m}, all h=0..3m+1; "
        f"global minimum={value} at (m,h)=({m},{h})"
    )
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "-M",
        "--max-m",
        type=int,
        default=60,
        help="largest m to check (default: 60)",
    )
    args = parser.parse_args()
    raise SystemExit(scan(args.max_m))


if __name__ == "__main__":
    main()
