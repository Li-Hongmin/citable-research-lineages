#!/usr/bin/env python3
"""Exact finite check of the two phase choices in the lcm incidence.

The same-sign channel has local factor (1-p^-s)^2, while the opposite-sign
channel has local factor 1-p^(-2s).  The script checks both identities in
Gaussian integer arithmetic through a finite cutoff.
"""

from __future__ import annotations

import math


Pair = tuple[int, int]  # real, imaginary parts


def add(x: Pair, y: Pair) -> Pair:
    return x[0] + y[0], x[1] + y[1]


def mul(x: Pair, y: Pair) -> Pair:
    return x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0]


def factorization(n: int) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    p = 2
    while p * p <= n:
        if n % p == 0:
            k = 0
            while n % p == 0:
                n //= p
                k += 1
            out.append((p, k))
        p += 1
    if n > 1:
        out.append((n, 1))
    return out


def weight(sign: int, n: int) -> Pair:
    value = (1, 0)
    for _, k in factorization(n):
        if k >= 3:
            return (0, 0)
        if k == 1:
            value = mul(value, (-1, sign))
        elif k == 2:
            value = mul(value, (0, -sign))
    return value


def mobius(n: int) -> int:
    result = 1
    for p, k in factorization(n):
        if k >= 2:
            return 0
        result = -result
    return result


def mu2(n: int) -> int:
    return sum(mobius(d) * mobius(n // d) for d in range(1, n + 1) if n % d == 0)


def main(limit: int = 300) -> None:
    same = [(0, 0)] * (limit + 1)
    opposite = [(0, 0)] * (limit + 1)
    for d in range(1, limit + 1):
        for e in range(1, limit + 1):
            ell = math.lcm(d, e)
            if ell <= limit:
                same[ell] = add(same[ell], mul(weight(1, d), weight(1, e)))
                opposite[ell] = add(opposite[ell], mul(weight(1, d), weight(-1, e)))

    for n in range(1, limit + 1):
        expected_same = (mu2(n), 0)
        if same[n] != expected_same:
            raise AssertionError(("same", n, same[n], expected_same))
        expected_opposite = (mobius(math.isqrt(n)), 0) if math.isqrt(n) ** 2 == n else (0, 0)
        if opposite[n] != expected_opposite:
            raise AssertionError(("opposite", n, opposite[n], expected_opposite))

    print(f"phase_pair_lcm=ok through n={limit}")
    print("same-sign local series: (1-p^(-s))^2")
    print("opposite-sign local series: 1-p^(-2s)")
    same_sums = [sum(same[n][0] for n in range(1, x + 1)) for x in (2, 3)]
    opposite_sums = [sum(opposite[n][0] for n in range(1, x + 1)) for x in (2, 3)]
    print("phase_matrix_eigenvalues:", [
        (x, same_sums[i] + opposite_sums[i], same_sums[i] - opposite_sums[i])
        for i, x in enumerate((2, 3))
    ])


if __name__ == "__main__":
    main()
