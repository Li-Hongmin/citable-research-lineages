"""OMEN-only exact check of the eleven-channel z^4 Euler grouping."""

from fractions import Fraction
from math import comb, factorial


def eulerian_low(n: int, j: int) -> int:
    return sum(
        (-1) ** ell * comb(n + 1, ell) * (j + 1 - ell) ** n
        for ell in range(j + 1)
    )


def phi4(m: int, a: int, b: int) -> int:
    e = 2 * m + 2
    return sum(
        eulerian_low(a, i)
        * eulerian_low(b, j)
        * comb(e + 3 - i - j, 4 - i - j)
        for i in range(5)
        for j in range(5 - i)
    )


def weight_data(m: int, x: Fraction) -> tuple[Fraction, Fraction]:
    D = 3 * m + 3
    w = Fraction(0)
    theta = Fraction(0)
    for r in range(1, m + 1):
        d = Fraction(
            factorial(D) * factorial(m + r - 2),
            comb(D, 2)
            * 2**r
            * factorial(r - 1)
            * factorial(m - r)
            * factorial(2 * m + r + 1),
        )
        w += d * x**r
        theta += r * d * x**r
    return w, theta


def direct(m: int) -> Fraction:
    D = 3 * m + 3
    total = Fraction(0)
    for r in range(1, m + 1):
        d = Fraction(
            factorial(D) * factorial(m + r - 2),
            comb(D, 2)
            * 2**r
            * factorial(r - 1)
            * factorial(m - r)
            * factorial(2 * m + r + 1),
        )
        p = m - r + 3
        q = 2 * m + r + 1
        total += d * (q * phi4(m, p, q - 1) - p * phi4(m, p - 1, q))
    return total


def grouped(m: int) -> Fraction:
    W = lambda x: weight_data(m, Fraction(x))[0]
    U = lambda x: weight_data(m, Fraction(x))[1]
    P = (m + 1) * (m + 2) * (m + 3)
    c1 = Fraction(96 * 8**m * (m + 2) * (m + 3) + 648 * 27**m + m * P, 24)
    return (
        c1 * ((m - 2) * W(1) + 2 * U(1))
        + Fraction(2 ** (m + 1), 3)
        * (48 * 8**m - P)
        * ((3 * m - 1) * W(Fraction(1, 2)) + 3 * U(Fraction(1, 2)))
        + Fraction(9, 2)
        * 3**m
        * (m + 2)
        * (m + 3)
        * (5 * m * W(Fraction(1, 3)) + 4 * U(Fraction(1, 3)))
        - 16
        * 4**m
        * (m + 3)
        * ((7 * m + 1) * W(Fraction(1, 4)) + 5 * U(Fraction(1, 4)))
        + 25
        * 5**m
        * ((9 * m + 2) * W(Fraction(1, 5)) + 6 * U(Fraction(1, 5)))
        + Fraction(48 * 32**m - 4**m * P, 6) * (3 * U(2) - 5 * W(2))
        - 9
        * 12**m
        * ((4 * m * m + 9 * m - 9) * W(Fraction(2, 3)) + 5 * (m + 3) * U(Fraction(2, 3)))
        + Fraction(1, 2)
        * 9**m
        * (m + 2)
        * (m + 3)
        * (4 * U(3) - (m + 8) * W(3))
        - 4
        * 18**m
        * ((m * (m - 4) - 21) * W(Fraction(3, 2)) + (5 * m + 15) * U(Fraction(3, 2)))
        + 16**m * ((2 * m * m + 17 * m + 33) * W(4) - 5 * (m + 3) * U(4))
        + 25**m * (6 * U(5) - (3 * m + 14) * W(5))
    )


def main() -> None:
    for m in range(1, 25):
        assert direct(m) == grouped(m)
    print("J4_EULER_GROUPING_EXACT_M1_24")


if __name__ == "__main__":
    main()
