"""Arb certificate for the odd Weil operator at a=2/5.

The exact n=2 prime reflection is retained in the positive base
    (alpha-delta) I + (log(2)/sqrt(2)) J.
Eight Yukawa summands contribute two low-mode deficits each; the negative
odd polar vector is included as the seventeenth Schur column.

Run:
    uv run --with python-flint python \
      computations/verify_first_band_odd_at_040.py
"""

from flint import arb, ctx
import verify_first_prime_band_gap as core


ctx.dps = 100
core.A = arb(2) / 5
core.K_ODD = 8
core.N = 50

A = core.A
DLOG = core.DLOG
P = core.P
DELTA = arb(1) / 10000
LO = DLOG - A


alpha0, deficits = core.yukawa_data("odd")
alpha = alpha0 - DELTA
assert (alpha-P).lower() > 0

# Sixteen normalized Yukawa deficit columns followed by
# v(x)=2 sinh(x/2), whose rank is negative in the odd sector.
rows = [("sin", mu, weight) for mu, weight in deficits]
rows.append(("sinh", arb(0), arb(1)))
n = len(rows)
assert n == 17

q0 = 1 / alpha
qd = alpha / (alpha**2-P**2)
qr = -P / (alpha**2-P**2)
dq = qd-q0


def inner(r, s, lo, hi, diagonal=False):
    kr, mr, wr = r
    ks, ms, ws = s
    if kr == "sin" and ks == "sin":
        z = core.ss(mr, ms, lo, hi, diagonal)
    elif kr == "sin":
        z = core.sin_hyp(mr, lo, hi, False)
    elif ks == "sin":
        z = core.sin_hyp(ms, lo, hi, False)
    else:
        # Integral of (2 sinh(x/2))^2.
        z = 2*(arb.sinh(hi)-arb.sinh(lo)-(hi-lo))
    return wr*ws*z


def reflected(r, s, diagonal=False):
    """Integral over I of r(x)s(log(2)-x)."""
    kr, mr, wr = r
    ks, ms, ws = s
    if kr == "sin" and ks == "sin":
        z = (arb.sin(ms*DLOG)*core.sc(mr,ms,LO,A)
             -arb.cos(ms*DLOG)*core.ss(mr,ms,LO,A,diagonal))
    elif kr == "sin":
        z = (arb.sinh(DLOG/2)*core.sin_hyp(mr,LO,A,True)
             -arb.cosh(DLOG/2)*core.sin_hyp(mr,LO,A,False))
    elif ks == "sin":
        # J is self-adjoint, so this is the same expression after x -> d-x.
        z = (arb.sinh(DLOG/2)*core.sin_hyp(ms,LO,A,True)
             -arb.cosh(DLOG/2)*core.sin_hyp(ms,LO,A,False))
    else:
        # With eta=A-d/2 and I=(d-A,A):
        # integral_I 4 sinh(x/2)sinh((d-x)/2) dx
        # = 4 eta cosh(d/2)-4 sinh(eta) > 0.
        eta = A-DLOG/2
        z = 4*eta*arb.cosh(DLOG/2)-4*arb.sinh(eta)
    return wr*ws*z


# B^{-1}=alpha^{-1}I+
# (alpha/(alpha^2-p^2)-alpha^{-1})P_I-p/(alpha^2-p^2)J_I.
S = [[arb(0) for _ in range(n)] for _ in range(n)]
for i in range(n):
    for j in range(i+1):
        # The two directed formulas are analytically equal.  Averaging their
        # interval enclosures preserves inclusion and reduces asymmetry.
        ref = (reflected(rows[i],rows[j],i==j)
               +reflected(rows[j],rows[i],i==j))/2
        h = (q0*inner(rows[i],rows[j],arb(0),A,i==j)
             +dq*inner(rows[i],rows[j],LO,A,i==j)+qr*ref)
        S[i][j]=S[j][i]=(arb(1) if i==j else arb(0))-h

pivot = core.ldl_positive(S)

print(f"a={A}")
print(f"delta={DELTA}")
print(f"prime_coefficient={P}")
print(f"yukawa_scalar_lower={alpha0}")
print(f"base_alpha_minus_p={alpha-P}")
print(f"schur_dimension={n}")
print(f"minimum_LDL_pivot={pivot}")
print("certified_positive=True")
