"""Rigorous Householder isolation for the odd endpoint Schur ball."""

import numpy as np
from flint import arb,arb_mat,ctx

import verify_first_band_endpoint_odd_analytic as endpoint


ctx.dps=80
TERMS=3000;VECTOR_BITS=36;CHOLESKY_BITS=52;C0=arb(1)/100

Sbox,beta,young=endpoint.assemble_schur(TERMS);n=Sbox.nrows()
assert n==337
Smid=np.array([[float(Sbox[i,j].mid()) for j in range(n)] for i in range(n)])
evals,evecs=np.linalg.eigh(Smid);q=evecs[:,0]
sgn=1 if q[0]>=0 else -1
wfloat=q-sgn*np.eye(1,n,0).ravel()
wint=np.rint(wfloat*2**VECTOR_BITS).astype(object)
w=[arb(int(z))/(2**VECTOR_BITS) for z in wint]
t=sum((z*z for z in w),arb(0));assert t.lower()>0
sw=[sum((Sbox[i,j]*w[j] for j in range(n)),arb(0)) for i in range(n)]
wsw=sum((w[i]*sw[i] for i in range(n)),arb(0))
two=arb(2)/t;four=arb(4)*wsw/t**2

def Bij(i,j):
    return Sbox[i,j]-two*(w[i]*sw[j]+sw[i]*w[j])+four*w[i]*w[j]

a=Bij(0,0);r=[Bij(i,0) for i in range(1,n)]
Cminus=arb_mat([[Bij(i,j)-(C0 if i==j else arb(0))
                 for j in range(1,n)] for i in range(1,n)])
Cmid=np.array([[float(Cminus[i,j].mid()) for j in range(n-1)] for i in range(n-1)])
Lf=np.linalg.cholesky((Cmid+Cmid.T)/2);scale=2**CHOLESKY_BITS
L=arb_mat([[arb(int(np.rint(Lf[i,j]*scale)))/scale if j<=i else arb(0)
            for j in range(n-1)] for i in range(n-1)])
res=Cminus-L*L.transpose();resinf=arb(0)
for i in range(n-1):
    rowsum=sum((abs(res[i,j]) for j in range(n-1)),arb(0))
    if rowsum.upper()>resinf.upper():resinf=rowsum
clower=C0-resinf;assert clower.lower()>0
rnorm=sum((z*z for z in r),arb(0));schur=a-rnorm/clower
assert schur.lower()>0
maxrad=max(float(Sbox[i,j].rad()) for i in range(n) for j in range(n))
print(f'terms={TERMS}');print(f'dimension={n}')
print(f'floating_lambda_1={evals[0]:.17g}')
print(f'floating_lambda_2={evals[1]:.17g}')
print(f'input_max_entry_radius={maxrad}')
print(f'a_block={a}');print(f'r_norm_squared={rnorm}')
print(f'cholesky_residual_inf={resinf}');print(f'C_certified_lower={clower}')
print(f'certified_schur_lower={schur}');print('certified_positive=True')
