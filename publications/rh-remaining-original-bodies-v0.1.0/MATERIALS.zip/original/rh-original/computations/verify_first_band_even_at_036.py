"""Arb certificate for A_a^+ >= 1/20000 on 0<a<=9/25.

At a=9/25 only the n=2 prime shift is active. On the even half-sector it is
-p J on the edge collar, p=log(2)/sqrt(2). The proof combines its exact
piecewise inverse with the finite-Yukawa lower model from note 018.

Run:
    uv run --with python-flint python computations/verify_first_band_even_at_036.py
"""

from flint import arb, ctx

ctx.dps = 120
K, N = 20, 200
a = arb(9) / 25
d = arb(2).log()
pprime = d / arb(2).sqrt()
left = d - a
pi = arb.pi()
qtr = arb(1) / 4
C = qtr.digamma() - pi.log()
delta = arb(1) / 20000


def isolate_z(c, mode):
    lo = arb(0) if mode == 0 else arb(mode) * pi
    hi = (arb(mode) + arb(1) / 2) * pi - arb("1e-35")
    for _ in range(320):
        mid = (lo + hi) / 2
        fm = mid * arb.tan(mid) - c * a
        if fm < 0:
            lo = mid
        elif fm > 0:
            hi = mid
        else:
            raise ArithmeticError("root isolation lost sign")
    return lo.union(hi)


def ell(b, mu):
    return mu**2 / (b * (4 * b * b + mu**2))


def cc(mu, nu, lo, hi, same=False):
    if same:
        return (hi - lo) / 2 + (
            arb.sin(2 * mu * hi) - arb.sin(2 * mu * lo)
        ) / (4 * mu)
    return (
        (arb.sin((mu - nu) * hi) - arb.sin((mu - nu) * lo))
        / (2 * (mu - nu))
        + (arb.sin((mu + nu) * hi) - arb.sin((mu + nu) * lo))
        / (2 * (mu + nu))
    )


def cs(mu, nu, lo, hi, same=False):
    first = (
        -arb.cos((nu + mu) * hi) + arb.cos((nu + mu) * lo)
    ) / (2 * (nu + mu))
    if same:
        return first
    return first + (
        -arb.cos((nu - mu) * hi) + arb.cos((nu - mu) * lo)
    ) / (2 * (nu - mu))


def cref(mu, nu, lo, hi, same=False):
    return arb.cos(nu * d) * cc(mu, nu, lo, hi, same) + arb.sin(
        nu * d
    ) * cs(mu, nu, lo, hi, same)


def primitive_cosh(mu, x):
    return (
        arb(1) / 2 * arb.sinh(x / 2) * arb.cos(mu * x)
        + mu * arb.cosh(x / 2) * arb.sin(mu * x)
    ) / (mu**2 + arb(1) / 4)


def primitive_sinh(mu, x):
    return (
        arb(1) / 2 * arb.cosh(x / 2) * arb.cos(mu * x)
        + mu * arb.sinh(x / 2) * arb.sin(mu * x)
    ) / (mu**2 + arb(1) / 4)


data = []
for n in range(N):
    b = arb(n) + qtr
    c = 2 * b
    count = 3 if n < K else 1
    mus = [isolate_z(c, j) / a for j in range(count)]
    data.append((mus, [ell(b, mu) for mu in mus]))

alpha = C + sum(es[2] if n < K else es[0] for n, (_, es) in enumerate(data))
beta = alpha - delta
assert beta > pprime

vectors = []
for n in range(K):
    mus, es = data[n]
    for j in (0, 1):
        mu = mus[j]
        norm = cc(mu, mu, arb(0), a, True)
        vectors.append((mu, arb.sqrt(es[2] - es[j]) / arb.sqrt(norm)))

dim = len(vectors)
c0 = beta / (beta**2 - pprime**2) - 1 / beta
c1 = pprime / (beta**2 - pprime**2)
binv_w = [[arb(0) for _ in range(dim)] for _ in range(dim)]
binv_u = [arb(0) for _ in range(dim)]

for i, (mu, wi) in enumerate(vectors):
    full_u = 2 * (primitive_cosh(mu, a) - primitive_cosh(mu, arb(0)))
    collar_u = 2 * (primitive_cosh(mu, a) - primitive_cosh(mu, left))
    reflected_u = 2 * (
        arb.cosh(d / 2)
        * (primitive_cosh(mu, a) - primitive_cosh(mu, left))
        - arb.sinh(d / 2)
        * (primitive_sinh(mu, a) - primitive_sinh(mu, left))
    )
    binv_u[i] = wi * (full_u / beta + c0 * collar_u + c1 * reflected_u)
    for j, (nu, wj) in enumerate(vectors):
        if j > i:
            continue
        same = i == j
        full = cc(mu, nu, arb(0), a, same)
        collar = cc(mu, nu, left, a, same)
        reflected = (
            cref(mu, nu, left, a, same) + cref(nu, mu, left, a, same)
        ) / 2
        value = wi * wj * (full / beta + c0 * collar + c1 * reflected)
        binv_w[i][j] = binv_w[j][i] = value

unorm = 2 * (a + arb.sinh(a))
ucollar = 2 * ((a - left) + (arb.sinh(a) - arb.sinh(left)))
ureflected = 2 * (a - left) * arb.cosh(d / 2) + 4 * arb.sinh((a - left) / 2)
uinvu = unorm / beta + c0 * ucollar + c1 * ureflected

schur = [[arb(0) for _ in range(dim)] for _ in range(dim)]
for i in range(dim):
    for j in range(dim):
        schur[i][j] = (arb(1) if i == j else arb(0)) - binv_w[i][j]
        schur[i][j] += binv_u[i] * binv_u[j] / (1 + uinvu)

lower = [[arb(0) for _ in range(dim)] for _ in range(dim)]
pivots = [arb(0) for _ in range(dim)]
for i in range(dim):
    pivot = schur[i][i]
    for k in range(i):
        pivot -= lower[i][k] ** 2 * pivots[k]
    assert pivot > 0, (i, pivot)
    pivots[i] = pivot
    lower[i][i] = arb(1)
    for j in range(i + 1, dim):
        value = schur[j][i]
        for k in range(i):
            value -= lower[j][k] * lower[i][k] * pivots[k]
        lower[j][i] = value / pivots[i]

print("a=", a)
print("collar_width=", 2 * a - d)
print("delta=", delta)
print("alpha=", alpha)
print("beta_minus_prime=", beta - pprime)
print("minimum_LDL_pivot=", min(pivots, key=lambda x: float(x.mid())))
print("certified_positive=True")
