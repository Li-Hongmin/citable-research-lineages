"""Rigorous one-dimensional isolation for the 430x430 endpoint Schur ball.

The near-null eigenvector is used only to choose a dyadic Householder
generator.  Positivity of the 429-dimensional complement is certified by a
dyadic Cholesky witness and an Arb infinity-norm residual bound.
"""

import numpy as np
from flint import arb, arb_mat, ctx

import verify_first_band_endpoint_even_analytic as endpoint


ctx.dps = 80
TERMS = 10000
VECTOR_BITS = 32
CHOLESKY_BITS = 48
C0 = arb(7) / 10000


Sbox, beta, young = endpoint.assemble_schur(TERMS)
n = Sbox.nrows()
assert n == 430

# The floating computation selects the isolating direction; it is not used
# as proof.  All subsequent inequalities are Arb enclosures.
Smid = np.array([[float(Sbox[i, j].mid()) for j in range(n)] for i in range(n)])
evals, evecs = np.linalg.eigh(Smid)
q = evecs[:, 0]
sgn = 1.0 if q[0] >= 0 else -1.0
w_float = q - sgn * np.eye(1, n, 0).ravel()
w_int = np.rint(w_float * 2.0**VECTOR_BITS).astype(object)
w = [arb(int(z)) / (2**VECTOR_BITS) for z in w_int]
t = sum((z*z for z in w), arb(0))
assert t.lower() > 0

# B=H*S*H using the rank-one formula, H=I-2ww'/t.
sw = [sum((Sbox[i, j] * w[j] for j in range(n)), arb(0)) for i in range(n)]
w_sw = sum((w[i] * sw[i] for i in range(n)), arb(0))
two_over_t = arb(2) / t
four_scalar = arb(4) * w_sw / t**2


def Bij(i, j):
    return (Sbox[i, j]
            - two_over_t * (w[i] * sw[j] + sw[i] * w[j])
            + four_scalar * w[i] * w[j])


a = Bij(0, 0)
r = [Bij(i, 0) for i in range(1, n)]
Crows = [[Bij(i, j) - (C0 if i == j else arb(0))
          for j in range(1, n)] for i in range(1, n)]
Cminus = arb_mat(Crows)

# A dyadic Cholesky witness for midpoint(C-C0 I).
Cmid = np.array([[float(Cminus[i, j].mid()) for j in range(n-1)]
                 for i in range(n-1)])
Lfloat = np.linalg.cholesky((Cmid + Cmid.T) / 2)
scale = 2.0**CHOLESKY_BITS
Lrows = []
for i in range(n-1):
    row = []
    for j in range(n-1):
        integer = int(np.rint(Lfloat[i, j] * scale)) if j <= i else 0
        row.append(arb(integer) / (2**CHOLESKY_BITS))
    Lrows.append(row)
L = arb_mat(Lrows)
residual = Cminus - L * L.transpose()
residual_inf = arb(0)
for i in range(n-1):
    rowsum = sum((abs(residual[i, j]) for j in range(n-1)), arb(0))
    if rowsum.upper() > residual_inf.upper():
        residual_inf = rowsum
c_lower = C0 - residual_inf
assert c_lower.lower() > 0

# For every represented matrix in the input balls, C >= c_lower I and hence
# a-r'C^{-1}r >= lower(a)-||r||^2/c_lower.
rnorm_sq = sum((z*z for z in r), arb(0))
schur_lower = a - rnorm_sq / c_lower
assert schur_lower.lower() > 0

maxrad = max(float(Sbox[i, j].rad()) for i in range(n) for j in range(n))
print(f"terms={TERMS}")
print(f"dimension={n}")
print(f"vector_bits={VECTOR_BITS}")
print(f"cholesky_bits={CHOLESKY_BITS}")
print(f"floating_lambda_1={evals[0]:.17g}")
print(f"floating_lambda_2={evals[1]:.17g}")
print(f"input_max_entry_radius={maxrad}")
print(f"a_block={a}")
print(f"r_norm_squared={rnorm_sq}")
print(f"cholesky_residual_inf={residual_inf}")
print(f"C_certified_lower={c_lower}")
print(f"certified_schur_lower={schur_lower}")
print("certified_positive=True")
