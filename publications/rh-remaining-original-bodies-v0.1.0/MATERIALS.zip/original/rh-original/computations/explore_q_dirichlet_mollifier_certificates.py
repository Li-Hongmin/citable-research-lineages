#!/usr/bin/env python3
"""Explore center-normalized Dirichlet-polynomial L2 certificates for Q.

This is a nonrigorous midpoint scan.  For a fixed local cell it forms the
Poisson-weighted Gram matrix of

    1, 2**(-s), ..., K**(-s)

on the critical line and solves the finite constrained least-squares problem
with D_K(1/2 + a + i*tau) = 1.  A ratio below 5 is the numerical signature of
the q=1 local certificate from note 048; interval bounds and quadrature tails
are still needed for a proof.

Example:
    uv run --with python-flint --with numpy python \
      computations/explore_q_dirichlet_mollifier_certificates.py \
      --a 0.0625 --tau 540.375 --samples 8192 --max-k 6
"""

from __future__ import annotations

import argparse

import numpy as np
from flint import acb, arb, ctx

from explore_q_optimal_polynomial_approximants import boundary_samples, q_value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--a", type=float, required=True)
    parser.add_argument("--tau", type=float, required=True)
    parser.add_argument("--samples", type=int, default=8192)
    parser.add_argument("--max-k", type=int, default=8)
    parser.add_argument(
        "--damping-scale",
        type=float,
        help=(
            "optionally multiply by the center-normalized rational factor "
            "(a+L)/(s-(1/2-L+i*tau))"
        ),
    )
    parser.add_argument(
        "--report-radius",
        type=float,
        help="report the midpoint contribution from |t-tau| at most this radius",
    )
    parser.add_argument("--report-two-term-moments", action="store_true")
    parser.add_argument("--digits", type=int, default=50)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    ctx.dps = args.digits

    theta, q_boundary = boundary_samples(args.samples, args.a, args.tau)
    heights = args.tau + args.a / np.tan(theta / 2.0)
    weight = np.abs(q_boundary) ** 2
    if args.damping_scale is not None:
        if args.damping_scale <= 0:
            raise ValueError("--damping-scale must be positive")
        offset = heights - args.tau
        weight *= (args.a + args.damping_scale) ** 2 / (
            args.damping_scale**2 + offset**2
        )

    center = q_value(acb(arb(0.5 + args.a), arb(args.tau)))
    center_complex = complex(float(center.real.mid()), float(center.imag.mid()))
    center_abs_sq = abs(center_complex) ** 2
    s0 = 0.5 + args.a + 1j * args.tau

    integers = np.arange(1, args.max_k + 1, dtype=float)
    log_integers = np.log(integers)
    basis = np.exp(-(0.5 + 1j * heights[:, None]) * log_integers[None, :])
    center_basis = np.exp(-s0 * log_integers)

    print(f"a={args.a:.17g} tau={args.tau:.17g} samples={args.samples}")
    print(f"damping_scale={args.damping_scale}")
    print(f"|Q(center)|^2={center_abs_sq:.17g}")
    print("K ratio pass cond(A) coefficients")

    for k in range(1, args.max_k + 1):
        v = basis[:, :k]
        gram = (v.conj().T * weight) @ v / args.samples
        e = center_basis[:k]
        solved = np.linalg.solve(gram, e.conj())
        denominator = e @ solved
        coefficients = solved / denominator
        minimum = float(np.real(1.0 / denominator))
        ratio = minimum / center_abs_sq
        constraint = e @ coefficients
        coefficient_text = " ".join(
            f"{z.real:+.12f}{z.imag:+.12f}i" for z in coefficients
        )
        print(
            f"{k:2d} {ratio:.12f} {str(ratio < 5.0):5s} "
            f"{np.linalg.cond(gram):.6g} {coefficient_text} "
            f"constraint={constraint.real:+.12f}{constraint.imag:+.3e}i"
        )
        if args.report_two_term_moments and k == 2:
            lag = np.log(2.0)
            correlation = (
                np.sqrt(2.0) * np.exp(1j * args.tau * lag) * gram[0, 1]
            )
            print(
                f"   A00={gram[0, 0].real:.12e} "
                f"A01={gram[0, 1].real:+.12e}{gram[0, 1].imag:+.12e}i "
                f"C_log2={correlation.real:+.12e}{correlation.imag:+.12e}i "
                f"C_over_N={correlation / gram[0, 0]}"
            )
        if args.report_radius is not None:
            polynomial_values = v @ coefficients
            inside = np.abs(heights - args.tau) <= args.report_radius
            inside_ratio = float(
                np.mean(weight * np.abs(polynomial_values) ** 2 * inside)
                / center_abs_sq
            )
            print(
                f"   radius={args.report_radius:.12g} "
                f"inside_ratio={inside_ratio:.12f} "
                f"outside_ratio={ratio - inside_ratio:.12f}"
            )


if __name__ == "__main__":
    main()
