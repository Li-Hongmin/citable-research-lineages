#!/usr/bin/env python3
"""OMEN-only finite probe of rational-arc capture for an exceptional block.

For the largest signed dyadic block, measure |F_N|^2 on arcs of width
1/(8H) around reduced rationals with denominator at most 8.  This is a finite
route diagnostic, not an asymptotic major/minor-arc theorem.
"""

from __future__ import annotations

import math
import sys
from fractions import Fraction

import numpy as np


def mobius(n: int) -> np.ndarray:
    value = np.zeros(n + 1, dtype=np.int8)
    value[1] = 1
    composite = np.zeros(n + 1, dtype=np.bool_)
    primes: list[int] = []
    for i in range(2, n + 1):
        if not composite[i]:
            primes.append(i)
            value[i] = -1
        for prime in primes:
            multiple = i * prime
            if multiple > n:
                break
            composite[multiple] = True
            if i % prime == 0:
                value[multiple] = 0
                break
            value[multiple] = -value[i]
    return value


def profile(n: int, qmax: int = 8, width_factor: float = 1.0 / 8.0) -> None:
    mu = mobius(n).astype(np.float64)
    correlation_data = np.zeros(2 * n, dtype=np.float64)
    correlation_data[1 : n + 1] = mu[1:]
    correlation_transform = np.fft.rfft(correlation_data)
    correlation = np.rint(
        np.fft.irfft(
            correlation_transform * np.conj(correlation_transform), n=2 * n
        )[:n]
    ).astype(np.int64)
    best = (0, 0, 0)
    h = 1
    while h < n:
        signed = int(correlation[h : min(2 * h, n)].sum())
        candidate = (abs(signed), h, signed)
        if candidate > best:
            best = candidate
        h *= 2
    _, h, signed = best

    length = 4 * n
    padded = np.zeros(length, dtype=np.float64)
    padded[1 : n + 1] = mu[1:]
    transform = np.fft.rfft(padded)
    power = transform.real * transform.real + transform.imag * transform.imag
    k = np.arange(len(power), dtype=np.int64)
    theta = k.astype(np.float64) / length
    denominator = np.sin(np.pi * theta)
    numerator = np.sin(np.pi * h * theta)
    phase = np.exp(2j * np.pi * (h + (h - 1) / 2.0) * theta)
    kernel = np.empty_like(phase)
    kernel[0] = h
    kernel[1:] = phase[1:] * numerator[1:] / denominator[1:]
    multiplicity = np.full(k.shape, 2.0)
    multiplicity[(k == 0) | (k == length // 2)] = 1.0
    scale = 1.0 / (n * length)
    block = float(np.sum(multiplicity * power * kernel.real) * scale)
    print(f"N={n} H={h} D/N={block:.12g} corr={signed}")

    fractions: set[Fraction] = set()
    for q in range(1, qmax + 1):
        for a in range(q):
            if math.gcd(a, q) == 1:
                raw = Fraction(a, q)
                fractions.add(min(raw, 1 - raw))
    # The arcs are short intervals on the FFT grid.  Marking their slices is
    # equivalent to the distance test above but avoids a full-grid scan for
    # every rational, which is essential once qmax is increased beyond 8.
    major_mask = np.zeros(k.shape, dtype=np.bool_)
    radius = max(1, int(math.ceil(width_factor * length / h)))
    for frac in sorted(fractions):
        center = int(round(float(frac) * length))
        start = max(0, center - radius)
        stop = min(len(k), center + radius + 1)
        major_mask[start:stop] = True
    major_mass = float(np.sum(multiplicity[major_mask] * power[major_mask]) * scale)
    major_block = float(
        np.sum(multiplicity[major_mask] * power[major_mask] * kernel.real[major_mask])
        * scale
    )
    total_mass = float(np.sum(multiplicity * power) * scale)
    print(
        f"  major_union_mass={major_mass:.12g} "
        f"major_union_D/N={major_block:.12g} total_mass={total_mass:.12g}"
    )


if __name__ == "__main__":
    sizes = [int(argument) for argument in sys.argv[1:]]
    for size in sizes or [2**18, 2**20, 2**22]:
        profile(size)
