"""Cross-check analytic Arb integrals against 90-digit mpmath quadrature."""

import random
import mpmath as mp
from flint import arb

import verify_first_band_endpoint_even_analytic as cert


mp.mp.dps = 90
rng = random.Random(20260811)


def mp_desc_value(desc, x):
    out = mp.mpf("0")
    for c,k,w,p in desc:
        out += mp.mpf(float(c.mid()))*x**k*mp.cos(mp.mpf(float(w.mid()))*x+mp.mpf(float(p.mid())))
    return out


def check_contains(ball, value, label):
    # The mpmath descriptors are reconstructed through IEEE doubles, so this
    # is a numerical cross-check rather than a directed containment claim.
    err=abs(mp.mpf(float(ball.mid()))-value)
    if err > mp.mpf('2e-12'):
        raise AssertionError((label,ball,mp.nstr(value,40),mp.nstr(err,8)))


def main():
    a=mp.log(3)/2; d=mp.log(2); lo=d-a
    for case in range(24):
        nf=rng.randint(1,3); ng=rng.randint(1,3)
        f=[];g=[]
        for _ in range(nf):
            f.append((arb(str(rng.uniform(-2,2))),rng.randint(0,10),
                      arb(str(rng.uniform(-35,35))),arb(str(rng.uniform(-3,3)))))
        for _ in range(ng):
            # Every fourth case forces an almost-zero difference frequency.
            w=(float(f[0][2].mid())+1e-12 if case%4==0 else rng.uniform(-35,35))
            g.append((arb(str(rng.uniform(-2,2))),rng.randint(0,10),
                      arb(str(w)),arb(str(rng.uniform(-3,3)))))
        for left,right,name in [(mp.mpf('0'),a,'full'),(lo,a,'collar')]:
            got=cert.inner_desc(f,g,arb(mp.nstr(left,80)),arb(mp.nstr(right,80)))
            want=mp.quad(lambda x:mp_desc_value(f,x)*mp_desc_value(g,x),[left,right])
            check_contains(got,want,f"inner-{case}-{name}")
        gr=cert.reflected_desc(g)
        got=cert.inner_desc(f,gr,arb(mp.nstr(lo,80)),arb(mp.nstr(a,80)))
        want=mp.quad(lambda x:mp_desc_value(f,x)*mp_desc_value(g,d-x),[lo,a])
        check_contains(got,want,f"reflection-{case}")
        got=cert.inner_u(f,arb(mp.nstr(lo,80)),arb(mp.nstr(a,80)),reflected=True)
        want=mp.quad(lambda x:mp_desc_value(f,x)*2*mp.cosh((d-x)/2),[lo,a])
        check_contains(got,want,f"u-reflection-{case}")
    print("quad_comparisons=96")
    print("all_analytic_integrals_agree_with_mpmath_to_2e-12=True")


if __name__ == '__main__':
    main()
