#!/usr/bin/env python3
"""Strict Arb proof using an explicit degree-one outer OPUC multiplier."""

from __future__ import annotations

from flint import acb, acb_series, arb, ctx


BAND_TOP = arb("0.5")
TAU = arb("19029.5")
ARC_COUNT = 32768
MULTIPLIER = acb(arb("-0.76184993"), arb("-0.31736684"))


def f_value(s: acb) -> acb:
    variable = acb_series([s, acb(1)], 3)
    gamma_factor = (
        variable
        * (variable - 1)
        / 2
        * (-variable * arb.pi().log() / 2).exp()
        * (variable / 2).gamma()
    )
    xi_series = gamma_factor * variable.zeta()
    return xi_series[0] + xi_series[1]


def main() -> None:
    ctx.dps = 40
    ctx.cap = 4

    multiplier_modulus_squared = MULTIPLIER.real**2 + MULTIPLIER.imag**2
    if not multiplier_modulus_squared.upper() < 1:
        raise AssertionError("the degree-one multiplier is not zero-free on the disk")

    radius = 3 * BAND_TOP / 4
    center = acb(arb("0.5") + radius, TAU)
    center_value = f_value(center)
    total_upper_ball = arb(0)
    pi = arb.pi()
    half_width = pi / ARC_COUNT
    for index in range(ARC_COUNT):
        midpoint = (2 * index + 1) * pi / ARC_COUNT
        theta = arb(midpoint, half_width)
        z = acb(theta.cos(), theta.sin())
        point = center + radius * z
        normalized = f_value(point) / center_value * (1 + MULTIPLIER * z)
        total_upper_ball += normalized.real**2 + normalized.imag**2

    mean_square = total_upper_ball / ARC_COUNT
    upper = mean_square.upper()

    print("STRICT Arb degree-one OPUC tangent-disk certificate")
    print("band top A =", BAND_TOP)
    print("center =", center)
    print("radius =", radius)
    print("multiplier P(z) = 1 + p z with p =", MULTIPLIER)
    print("|p|^2 enclosure =", multiplier_modulus_squared)
    print("arc count =", ARC_COUNT)
    print("full circle mean-square enclosure =", mean_square)
    print("rigorous upper endpoint =", upper)
    print("factor-5 threshold = 5")
    if not upper < 5:
        raise AssertionError("the interval upper bound did not clear factor 5")
    print("PASS: the explicit outer degree-one multiplier clears factor 5")


if __name__ == "__main__":
    main()
