#!/usr/bin/env python3
"""Verify the exact h=H+r decomposition behind note 350."""

from fractions import Fraction


def mu(n: int) -> int:
    x = n
    p = 2
    parity = 0
    while p * p <= x:
        if x % p == 0:
            x //= p
            parity ^= 1
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1
    if x > 1:
        parity ^= 1
    return -1 if parity else 1


def check(N: int) -> None:
    direct = Fraction(0)
    decomposed = Fraction(0)
    for m in range(1, N + 1):
        for q in range(m + 1, N + 1):
            direct += Fraction(mu(m) * mu(q) * m, q)

    # The m=1 boundary is kept separate, exactly as in the note.
    # The h=1 strip is the only part not represented by H<h<=2H.
    for m in range(2, N):
        q = m + 1
        decomposed += Fraction(mu(m) * mu(q) * m, q)
    decomposed += sum(
        (Fraction(mu(q), q) for q in range(2, N + 1)),
        Fraction(0),
    )
    X = N - 1
    H = 1
    while H <= N - 2:
        for r in range(1, H + 1):
            for n in range(1, X + 1):
                q = n + H + 1 + r
                if q > N:
                    continue
                m = n + 1
                decomposed += Fraction(mu(m) * mu(q) * m, q)
        H *= 2
    assert decomposed == direct, (N, direct, decomposed)


if __name__ == "__main__":
    for n in range(4, 80):
        check(n)
    print("global h-dyadic Lehmer identity: OK")
