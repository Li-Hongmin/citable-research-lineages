#!/usr/bin/env python3
"""Exact finite check of the falling-factorial gamma cone.

This is an audit script for note 156, not an all-m theorem.  It evaluates the
closed gamma formula with integer Stirling numbers and Fraction arithmetic for
1 <= m <= M, 0 <= h <= 3m+1 and 0 <= L <= 3m+2.  The last range contains all
potentially nonzero coefficients in the displayed formula.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
from functools import lru_cache
from math import comb, factorial


@lru_cache(maxsize=None)
def stirling2(n: int, k: int) -> int:
    if n == k == 0:
        return 1
    if n == 0 or k == 0 or k > n:
        return 0
    return k * stirling2(n - 1, k) + stirling2(n - 1, k - 1)


@lru_cache(maxsize=None)
def F(r: int, t: int, M: int) -> int:
    return sum(
        stirling2(r, a) * stirling2(t, M - a) * factorial(a) * factorial(M - a)
        for a in range(M + 1)
    )


def gamma(m: int, h: int, L: int) -> Fraction:
    D, d = 3 * m + 3, 3 * m + 1
    total = Fraction(0)
    for q in range(2, m + 2):
        c_q = Fraction(
            factorial(2 * m - q) * factorial(q),
            2 ** (m - q + 2)
            * factorial(m - q + 1)
            * factorial(q - 2)
            * comb(D, 2),
        )
        outer = c_q * comb(D, q)
        bracket = Fraction(0)
        for s in range(min(D - q - 1, h) + 1):
            elev = Fraction(comb(D - q - 1, s) * comb(h, s), comb(d, s))
            bracket += elev * (
                (D - q) * F(q + 1, D - q - 1 - s, L + 1)
                - Fraction((q + 1) * (D - q), D - q - s)
                * F(q, D - q - s, L + 1)
            )
        if h >= D - q:
            bracket -= (q + 1) * Fraction(comb(h, D - q), comb(d, D - q)) * F(
                q, 0, L + 1
            )
        total += outer * bracket
    return total / factorial(L + 2)


def check(m: int) -> None:
    D, d = 3 * m + 3, 3 * m + 1
    bad = []
    for h in range(d + 1):
        for L in range(D):
            value = gamma(m, h, L)
            if value < 0:
                bad.append((h, L, value))
    if bad:
        raise AssertionError(f"m={m}: first negative gamma={bad[0]}")
    print(f"m={m}: gamma cone OK (h=0..{d}, L=0..{D-1})")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("-M", type=int, default=15)
    parser.add_argument("--single", type=int)
    args = parser.parse_args()
    if args.single is not None:
        check(args.single)
    else:
        for m in range(1, args.M + 1):
            check(m)


if __name__ == "__main__":
    main()
