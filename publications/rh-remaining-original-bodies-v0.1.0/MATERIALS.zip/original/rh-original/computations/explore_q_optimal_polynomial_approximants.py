"""Explore finite optimal polynomial inverses for the zero-baseline Q.

This is a non-rigorous midpoint quadrature probe, not an RH certificate.

Reproduce with, for example:

    uv run --with python-flint --with numpy python \
      computations/explore_q_optimal_polynomial_approximants.py \
      --samples 65536 --degrees 4 8 16 32 64
"""

from __future__ import annotations

import argparse
import math

import numpy as np
from flint import acb, acb_series, arb, ctx


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--samples", type=int, default=65536)
    parser.add_argument("--degrees", type=int, nargs="+", default=[4, 8, 16, 32, 64])
    parser.add_argument("--digits", type=int, default=25)
    parser.add_argument("--tau", type=float, default=0.0)
    parser.add_argument("--a", type=float, default=1.0)
    return parser.parse_args()


def q_value(s: acb) -> acb:
    x = acb_series([s, acb(1)], 2)
    zeta_series = x.zeta()
    zeta_value = zeta_series[0]
    zeta_derivative = zeta_series[1]
    c_value = (
        1
        + 1 / s
        + 1 / (s - 1)
        - arb.pi().log() / 2
        + (s / 2).digamma() / 2
    )
    return (s - 1) / s * (zeta_derivative + c_value * zeta_value)


def boundary_samples(
    sample_count: int, a: float, tau: float
) -> tuple[np.ndarray, np.ndarray]:
    theta = 2 * np.pi * (np.arange(sample_count) + 0.5) / sample_count
    values = np.empty(sample_count, dtype=np.complex128)
    for index, angle in enumerate(theta):
        height = 1 / math.tan(float(angle) / 2)
        s = acb(arb("0.5"), arb(str(tau + a * height)))
        value = q_value(s)
        values[index] = complex(float(value.real.mid()), float(value.imag.mid()))
    return theta, values


def toeplitz_moments(weight: np.ndarray, max_degree: int) -> np.ndarray:
    sample_count = len(weight)
    moments = np.fft.fft(weight)[: max_degree + 1] / sample_count
    midpoint_phase = np.exp(-1j * np.pi * np.arange(max_degree + 1) / sample_count)
    return moments * midpoint_phase


def toeplitz_matrix(moments: np.ndarray, degree: int) -> np.ndarray:
    matrix = np.empty((degree + 1, degree + 1), dtype=np.complex128)
    for row in range(degree + 1):
        for column in range(degree + 1):
            offset = row - column
            matrix[row, column] = (
                moments[offset] if offset >= 0 else np.conj(moments[-offset])
            )
    return (matrix + matrix.conj().T) / 2


def main() -> None:
    args = parse_args()
    if args.samples <= 2 * max(args.degrees):
        raise ValueError("--samples must exceed twice the largest requested degree")
    if args.a <= 0:
        raise ValueError("--a must be positive")
    ctx.dps = args.digits

    theta, values = boundary_samples(args.samples, args.a, args.tau)
    del theta
    weight = np.abs(values) ** 2
    moments = toeplitz_moments(weight, max(args.degrees))

    f_zero_ball = q_value(acb(arb(str(0.5 + args.a)), arb(str(args.tau))))
    f_zero = complex(float(f_zero_ball.real.mid()), float(f_zero_ball.imag.mid()))
    target = abs(f_zero) ** 2

    print("NON-RIGOROUS midpoint quadrature")
    print("samples =", args.samples)
    print("a =", args.a)
    print("tau =", args.tau)
    print("F_a_tau(0) = Q(1/2 + a + i tau) ~=", f_zero)
    print("target |F_a_tau(0)|^2 =", target)
    print("degree  r_n                 E_n(identity)       E_n(samples)")

    for degree in args.degrees:
        matrix = toeplitz_matrix(moments, degree)
        cholesky = np.linalg.cholesky(matrix)
        r_n = float(np.real(cholesky[-1, -1]) ** 2)

        right_hand_side = np.zeros(degree + 1, dtype=np.complex128)
        right_hand_side[0] = np.conj(f_zero)
        coefficients = np.linalg.solve(matrix, right_hand_side)

        grid = np.exp(2j * np.pi * (np.arange(args.samples) + 0.5) / args.samples)
        polynomial = np.polynomial.polynomial.polyval(grid, coefficients)
        sampled_error = float(np.sqrt(np.mean(np.abs(polynomial * values - 1) ** 2)))
        identity_error = math.sqrt(max(0.0, 1 - target / r_n))

        print(f"{degree:6d}  {r_n:.15f}  {identity_error:.12f}  {sampled_error:.12f}")


if __name__ == "__main__":
    main()
