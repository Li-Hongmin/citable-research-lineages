"""Generate the fixed log9 endpoint contract caches.

Usage:
  uv run --with python-flint --with numpy python computations/generate_log9_endpoint_contract_cache.py 256 280 500 + --export-small-map-only
  uv run --with python-flint --with numpy python computations/generate_log9_endpoint_contract_cache.py 192 280 500 - --export-small-map-only

The prime norm is deliberately the safe triangle bound.  This script is a
decision gate, not a permanent positivity certificate.
"""
with open('computations/verify_first_mixed_band_endpoint_log5.py', encoding='utf-8') as h:
    source = h.read()

changes = {
    'pi=arb.pi(); a=arb(5).log()/2': 'pi=arb.pi(); a=arb(3).log()',
    'd2=arb(2).log();d3=arb(3).log();d4=2*d2':
        'd2=arb(2).log();d3=arb(3).log();d4=2*d2;d5=arb(5).log();d7=arb(7).log();d8=3*d2',
    'alpha2=d2/arb(2).sqrt();alpha3=d3/arb(3).sqrt();alpha4=d2/2':
        'alpha2=d2/arb(2).sqrt();alpha3=d3/arb(3).sqrt();alpha4=d2/2;alpha5=d5/arb(5).sqrt();alpha7=d7/arb(7).sqrt();alpha8=d2/arb(8).sqrt()',
    "TERMS += [(-eps*alpha3,'ref',d3,d3-a,a),(-eps*alpha4,'ref',d4,d4-a,a)]":
        "TERMS += [(-eps*alpha3,'ref',d3,d3-a,a),(-eps*alpha4,'ref',d4,d4-a,a),(-eps*alpha5,'ref',d5,d5-a,a),(-eps*alpha7,'ref',d7,d7-a,a),(-eps*alpha8,'ref',d8,d8-a,a)]",
    'prime_bound=2*alpha2+alpha3+alpha4':
        'prime_bound=arb("2.677899");print("prime_two_step_bound",prime_bound,flush=True)',
    "L=[[arb(0) for _ in range(R)] for _ in range(R)];dd=[arb(0) for _ in range(R)];mn=None":
        "CACHE_PREFIX='log9';body=open('computations/log8_block_certificate_body.py',encoding='utf-8').read();body=body.replace('assert PAR == \"+\" and R == 128','assert R == 280').replace('BLOCK = 4','BLOCK = 5').replace('CHOLESKY_BITS = 52','CHOLESKY_BITS = 80').replace('C0 = arb(1) / 2000000',\"C0 = arb('1e-12')\").replace('assert clower.lower()>0','print(\"precheck_resinf\",resinf,\"precheck_clower\",clower,flush=True);assert clower.lower()>0').replace(\"if PAR=='-' and R==200 and BLOCK==5:\",\"if R==280:\").replace('            assert k==BLOCK-1\\n','').replace('if export_case and BLOCK==5 and N==400:','if BLOCK==5 and N==500:');exec(compile(body,__file__,'exec'))",
}
for old, new in changes.items():
    assert source.count(old) == 1, (old, source.count(old))
    source = source.replace(old, new)
exec(compile(source, __file__, 'exec'))
