"""Arb certificate for the odd Weil operator at a = 0.36.

The first prime term is +p J on the edge collar, where J is reflection.
Thirty positive Yukawa summands give a scalar-minus-rank-ten lower model.
After adding the negative odd polar rank, positivity reduces to an 11 by 11
Schur complement over the explicitly invertible operator alpha I + p J.

Run:
    uv run --with python-flint python \
      computations/verify_first_band_odd_at_036.py
"""

from flint import arb, ctx


ctx.dps = 100

A = arb(9) / 25
LENGTH = arb.log(arb(2))
COLLAR_LO = LENGTH - A
P = LENGTH / arb(2).sqrt()
DELTA = arb(1) / 1000
K = 5
N = 30
ROOT_RADIUS = arb("1e-10")

# Centers of the Dirichlet--Robin roots mu*cot(mu*a)=-c.  For n<K the
# first three roots are enclosed; otherwise only the first root is needed.
ROOT_TEXT = (
    ("4.66021824944956", "13.19517637434424", "21.88008192064342"),
    ("5.54070268440124", "13.59512963773213", "22.12910567087382"),
    ("6.12369684904677", "13.95638191826943", "22.36808625879195"),
    ("6.53708344270112", "14.27674944796280", "22.59471058903394"),
    ("6.84368307764302", "14.55796102178115", "22.80755520628369"),
    ("7.07890441442018",), ("7.26431251522104",),
    ("7.41375345268951",), ("7.53648380006312",),
    ("7.63889936683925",), ("7.72554432234401",),
    ("7.79972597093521",), ("7.86390267757096",),
    ("7.91993610353782",), ("7.96925956757881",),
    ("8.01299306221688",), ("8.05202347703474",),
    ("8.08706161173228",), ("8.11868338771309",),
    ("8.14736010156304",), ("8.17348095007579",),
    ("8.19737001978140",), ("8.21929925498127",),
    ("8.23949846567128",), ("8.25816313004851",),
    ("8.27546053531091",), ("8.29153465326434",),
    ("8.30651004321695",), ("8.32049500018503",),
    ("8.33358411257753",),
)

# Directed rational lower bounds for the retained scalar levels.
LEVEL_TEXT = (
    "3.997912264959", "0.789918284018", "0.427156077966",
    "0.284174429120", "0.206598965925", "0.059521564943",
    "0.040394355875", "0.028585266907", "0.020922980955",
    "0.015747292056", "0.012132568779", "0.009535806985",
    "0.007624695595", "0.006188423331", "0.005089046543",
    "0.004233828077", "0.003558919183", "0.003019420557",
    "0.002583155379", "0.002226668516", "0.001932597292",
    "0.001687907960", "0.001482690731", "0.001309322404",
    "0.001161875378", "0.001035694570", "0.000927090541",
    "0.000833114181", "0.000751389412", "0.000679987648",
)

# Directed upper bounds for L_n-ell_{n,j}, j=0,1 and n<K.
DEFICIT_TEXT = (
    ("0.043433780566", "0.003647437203"),
    ("0.125238529068", "0.016085670001"),
    ("0.138556698533", "0.024566142401"),
    ("0.129453064358", "0.029311419950"),
    ("0.114058826713", "0.031125198103"),
)


def pos(x):
    return x.lower() > 0


def neg(x):
    return x.upper() < 0


def ell(mu, b, c):
    return mu**2 / (b * (mu**2 + c**2))


def root_function(mu, c):
    return mu / (mu * A).tan() + c


def int_sin_sin(mu, nu, lo, hi):
    if mu is nu:
        return (hi-lo)/2 - ((2*mu*hi).sin()-(2*mu*lo).sin())/(4*mu)
    return (((mu-nu)*hi).sin()-((mu-nu)*lo).sin())/(2*(mu-nu)) - \
           (((mu+nu)*hi).sin()-((mu+nu)*lo).sin())/(2*(mu+nu))


def int_sin_cos(mu, nu, lo, hi):
    if mu is nu:
        return ((mu*hi).sin()**2-(mu*lo).sin()**2)/(2*mu)
    return (-(((mu+nu)*hi).cos()-((mu+nu)*lo).cos())/(2*(mu+nu))
            -(((mu-nu)*hi).cos()-((mu-nu)*lo).cos())/(2*(mu-nu)))


def int_sin_sin_ref(mu, nu, lo, hi):
    return ((nu*LENGTH).sin()*int_sin_cos(mu,nu,lo,hi)
            -(nu*LENGTH).cos()*int_sin_sin(mu,nu,lo,hi))


def int_sin_sinh(mu, lo, hi):
    """Integral of sin(mu*x) * 2*sinh(x/2)."""
    q = arb(1)/2
    def primitive(x):
        return 2*(q*(mu*x).sin()*(q*x).cosh()
                  -mu*(mu*x).cos()*(q*x).sinh())/(mu**2+q**2)
    return primitive(hi)-primitive(lo)


def int_sin_cosh(mu, lo, hi):
    q = arb(1)/2
    def primitive(x):
        return (q*(mu*x).sin()*(q*x).sinh()
                -mu*(mu*x).cos()*(q*x).cosh())/(mu**2+q**2)
    return primitive(hi)-primitive(lo)


def int_sin_ref_sinh(mu, lo, hi):
    q = arb(1)/2
    return (2*(q*LENGTH).sinh()*int_sin_cosh(mu,lo,hi)
            -(q*LENGTH).cosh()*int_sin_sinh(mu,lo,hi))


def int_v2(lo, hi):
    return (2*hi.sinh()-2*hi)-(2*lo.sinh()-2*lo)


def int_v_ref_v():
    d=A-LENGTH/2
    return 4*d*(LENGTH/2).cosh()-4*d.sinh()


# Enclose all roots and verify the unique-root brackets on their standard
# intervals ((j+1/2)pi/a,(j+1)pi/a).
roots=[]
levels=[arb(x)-arb("1e-7") for x in LEVEL_TEXT]
vectors=[]
for n,row in enumerate(ROOT_TEXT):
    b=arb(n)+arb(1)/4; c=2*b
    rr=[]
    for j,text in enumerate(row):
        center=arb(text); lo=center-ROOT_RADIUS; hi=center+ROOT_RADIUS
        assert pos(root_function(lo,c)) and neg(root_function(hi,c))
        assert pos(lo-(arb(j)+arb(1)/2)*arb.pi()/A)
        assert pos((arb(j)+1)*arb.pi()/A-hi)
        mu=arb(f"{text} +/- 1e-10")
        rr.append(mu)
    roots.append(rr)
    if n<K:
        assert pos(ell(rr[2],b,c)-levels[n])
        for j in range(2):
            deficit=arb(DEFICIT_TEXT[n][j])+arb("1e-7")
            assert pos(deficit-(levels[n]-ell(rr[j],b,c)))
            norm=int_sin_sin(rr[j],rr[j],arb(0),A)
            vectors.append((rr[j],(deficit/norm).sqrt()))
    else:
        assert pos(ell(rr[0],b,c)-levels[n])

c_inf=(arb(1)/4).digamma()-arb.log(arb.pi())
scalar_lower=c_inf+sum(levels)
alpha=scalar_lower-DELTA
assert pos(alpha-P)

# Columns are ten normalized Robin deficits and v=2 sinh(x/2).
Q=len(vectors)+1
same_coeff=alpha/(alpha**2-P**2)-1/alpha
ref_coeff=-P/(alpha**2-P**2)

def full(i,j):
    if i==Q-1 and j==Q-1: return int_v2(arb(0),A)
    if i==Q-1:
        mu,w=vectors[j]; return w*int_sin_sinh(mu,arb(0),A)
    if j==Q-1:
        mu,w=vectors[i]; return w*int_sin_sinh(mu,arb(0),A)
    mui,wi=vectors[i]; muj,wj=vectors[j]
    return wi*wj*int_sin_sin(mui,muj,arb(0),A)

def collar(i,j):
    if i==Q-1 and j==Q-1: return int_v2(COLLAR_LO,A)
    if i==Q-1:
        mu,w=vectors[j]; return w*int_sin_sinh(mu,COLLAR_LO,A)
    if j==Q-1:
        mu,w=vectors[i]; return w*int_sin_sinh(mu,COLLAR_LO,A)
    mui,wi=vectors[i]; muj,wj=vectors[j]
    return wi*wj*int_sin_sin(mui,muj,COLLAR_LO,A)

def reflected(i,j):
    if i==Q-1 and j==Q-1: return int_v_ref_v()
    if i==Q-1:
        mu,w=vectors[j]; return w*int_sin_ref_sinh(mu,COLLAR_LO,A)
    if j==Q-1:
        mu,w=vectors[i]; return w*int_sin_ref_sinh(mu,COLLAR_LO,A)
    mui,wi=vectors[i]; muj,wj=vectors[j]
    return wi*wj*int_sin_sin_ref(mui,muj,COLLAR_LO,A)

# S=I-U*(alpha I+pJ)^(-1)U.  Symmetrize the two analytically equal
# reflected expressions to reduce harmless interval asymmetry.
S=[[arb(0) for _ in range(Q)] for _ in range(Q)]
for i in range(Q):
    for j in range(i+1):
        rij=(reflected(i,j)+reflected(j,i))/2
        bij=full(i,j)/alpha+same_coeff*collar(i,j)+ref_coeff*rij
        S[i][j]=S[j][i]=(arb(1) if i==j else arb(0))-bij

# No-pivot interval LDL^T.  Strictly positive pivots certify S>0.
pivots=[]
for k in range(Q):
    pivot=S[k][k]-sum(S[k][j]**2*pivots[j] for j in range(k))
    assert pos(pivot)
    pivots.append(pivot)
    for i in range(k+1,Q):
        S[i][k]=(S[i][k]-sum(S[i][j]*S[k][j]*pivots[j]
                              for j in range(k)))/pivot

print(f"a={A}")
print(f"delta={DELTA}")
print(f"p={P}")
print(f"scalar_lower={scalar_lower}")
print(f"alpha_minus_p={alpha-P}")
print(f"schur_dimension={Q}")
print(f"minimum_LDL_pivot_lower={min(x.lower() for x in pivots)}")
print("certified_positive=True")
