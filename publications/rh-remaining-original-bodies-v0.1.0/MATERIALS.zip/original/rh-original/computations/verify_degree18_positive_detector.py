#!/usr/bin/env python3
"""Exact checks for note 146's degree-18 detector.

This is a small symbolic certificate, not a numerical scan: all sums use the
integer cutoff N=floor(y), and Bernstein coefficients are reconstructed over
Q.  It prints the Mellin factorization, moment constraints, and the signs of
the Bernstein coefficients for representative integer N.
"""

import sympy as sp

u, c, s, N, r = sp.symbols("u c s N r")
V = sp.expand(
    u**2 * (1 - u) ** 11
    * (8151 * u**5 + 3645 * u**4 + 198 * u**3 - 262 * u**2 - 77 * u - 7)
    / sp.Integer(8151)
)

assert sp.integrate(V, (u, 0, 1)) == 0
assert all(sp.Poly(V, u).coeff_monomial(u**k) == 0 for k in (1, 3, 5, 7, 9))

K = sp.factor(sum(coef / (power + s) for (power,), coef in sp.Poly(V, u).terms()))
expected = sp.Rational(1083801600, 19) * (s - 1)
for shift in (2, 4, 6, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18):
    expected /= s + shift
assert sp.factor(K - expected) == 0

P = 0
for (power,), coef in sp.Poly(V, u).terms():
    P += coef * sp.summation(c**power, (c, 1, N)) / (N + r) ** power
Q = sp.factor((N + r) ** 18 * P / (N * (N + 1)))
degree = 16
Q_poly = sp.Poly(sp.expand(Q), r)
bernstein = []
for k in range(degree + 1):
    value = sum(
        Q_poly.coeff_monomial(r**j)
        * sp.binomial(k, j)
        / sp.binomial(degree, j)
        for j in range(k + 1)
    )
    bernstein.append(sp.factor(value))

# N=1 has the first eleven coefficients zero and the remaining six positive.
assert all(b.subs(N, 1) == 0 for b in bernstein[:11])
assert all(b.subs(N, 1) > 0 for b in bernstein[11:])

# For N>=2, direct exact checks at a modest range catch transcription errors;
# the all-N proof is the rational coefficient table in note 146.
for n in range(2, 12):
    assert all(b.subs(N, n) > 0 for b in bernstein)

print("degree=", sp.degree(V, u))
print("K=", K)
print("odd moments and mean: zero")
print("Bernstein signs: N=1 first 11 zero, remaining positive; N=2..11 all positive")
