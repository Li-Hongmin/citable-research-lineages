#!/usr/bin/env python3
"""OMEN-only finite profile of the centered mu*mu hyperbola identity.

For Y=floor(sqrt(X)) the exact identity is

    M2(X) = M(Y)^2 + 2 sum_{a<=Y} mu(a) (M(floor(X/a))-M(Y)).

This script measures the signed cross term and its absolute mass.  It is a
finite diagnostic for the joint two-leg cancellation; it is not an estimate
for M2 and does not prove RH.
"""

from __future__ import annotations

import math
import sys

import numpy as np


def mobius_sieve(n: int) -> np.ndarray:
    prime = np.ones(n + 1, dtype=np.bool_)
    prime[:2] = False
    for p in range(2, math.isqrt(n) + 1):
        if prime[p]:
            prime[p * p : n + 1 : p] = False
    mu = np.ones(n + 1, dtype=np.int8)
    mu[0] = 0
    for p in range(2, n + 1):
        if prime[p]:
            mu[p::p] *= -1
            mu[p * p :: p * p] = 0
    return mu


def direct_mu2(n: int, mu: np.ndarray) -> np.ndarray:
    out = np.zeros(n + 1, dtype=np.int64)
    for a in range(1, n + 1):
        if mu[a] == 0:
            continue
        upto = n // a
        out[a : n + 1 : a] += int(mu[a]) * mu[1 : upto + 1]
    return out


def profile(x: int, prefix: np.ndarray, mu: np.ndarray) -> None:
    y = math.isqrt(x)
    a = np.arange(1, y + 1, dtype=np.int64)
    increments = prefix[x // a] - prefix[y]
    cross_half = int(np.dot(mu[1 : y + 1].astype(np.int64), increments))
    base = int(prefix[y]) ** 2
    total = base + 2 * cross_half
    abs_mass = int(np.abs(increments).sum())
    signed_mass = int(increments.sum())
    print(
        f"X={x} Y={y} M(Y)={int(prefix[y])} M2_identity={total} "
        f"base={base} cross={2*cross_half} "
        f"cross_abs_mass={abs_mass} cross_signed_unweighted={signed_mass}"
    )
    print(
        f"  |cross|/cross_abs={abs(2*cross_half)/(2*abs_mass) if abs_mass else 0:.12g} "
        f"total/sqrtX={total/math.sqrt(x):.12g} "
        f"cross/base={2*cross_half/base if base else float('nan'):.12g}"
    )


def main() -> None:
    sizes = [int(arg) for arg in sys.argv[1:]]
    sizes = sizes or [2**16, 2**18, 2**20, 2**22, 2**24]
    n = max(sizes)
    mu = mobius_sieve(n)
    prefix = np.cumsum(mu.astype(np.int64))
    check_n = min(2000, n)
    c = direct_mu2(check_n, mu)
    direct_prefix = np.cumsum(c)
    for x in range(1, check_n + 1):
        y = math.isqrt(x)
        a = np.arange(1, y + 1, dtype=np.int64)
        identity = int(prefix[y]) ** 2 + 2 * int(
            np.dot(mu[1 : y + 1].astype(np.int64), prefix[x // a] - prefix[y])
        )
        if identity != int(direct_prefix[x]):
            raise AssertionError((x, identity, int(direct_prefix[x])))
    print(f"identity_check=ok through X={check_n}")
    for x in sizes:
        profile(x, prefix, mu)


if __name__ == "__main__":
    main()
