#!/usr/bin/env python3
"""Exact OMEN-side check for note 470."""

from __future__ import annotations

import argparse
from fractions import Fraction


def mobius_table(n_max: int) -> list[int]:
    mu = [1] * (n_max + 1)
    mu[0] = 0
    primes: list[int] = []
    composite = [False] * (n_max + 1)
    for n in range(2, n_max + 1):
        if not composite[n]:
            primes.append(n)
            mu[n] = -1
        for p in primes:
            if n * p > n_max:
                break
            composite[n * p] = True
            if n % p == 0:
                mu[n * p] = 0
                break
            mu[n * p] = -mu[n]
    return mu


def run(max_n: int) -> int:
    mu = mobius_table(max_n)
    harmonic = [Fraction(0)] * (max_n + 1)
    for n in range(1, max_n + 1):
        harmonic[n] = harmonic[n - 1] + Fraction(1, n)

    def z_layer(m: int, cutoff: int, q: int) -> Fraction:
        b_max = m // (cutoff + 1)
        return sum((
            Fraction(mu[b], b) *
            (harmonic[m // b] - harmonic[max(cutoff, q // b)])
            for b in range(1, b_max + 1)
        ), Fraction(0))

    checked = 0
    for n in range(3, max_n + 1):
        for cutoff in range(1, (n - 1) // 2 + 1):
            h = cutoff + 1
            if 2 * h - 1 >= n:
                continue
            block = list(range(h, 2 * h))
            weights = [2 * k + 1 for k in block]
            x = [harmonic[k] - harmonic[cutoff] for k in block]
            wsum = sum(weights)
            mean = sum(Fraction(w) * xx for w, xx in zip(weights, x)) / wsum
            v_a = sum(Fraction(w) * (xx - mean) ** 2
                       for w, xx in zip(weights, x))

            # On I_1, q_d is zero for every d>=2; verify this exactly and
            # check that the Mobius combination has the same projected block.
            values = []
            for k in block:
                q_values = []
                for d in range(1, n + 1):
                    m = n // d
                    z0 = z_layer(m, cutoff, 0)
                    ell = min(n, h * d)
                    zq = z_layer(m, cutoff, k // d)
                    q_value = zq / d - (z0 / d if k < ell else Fraction(0))
                    if d >= 2 and q_value:
                        raise AssertionError(("support", n, cutoff, d, k, q_value))
                    q_values.append(mu[d] * q_value)
                values.append(sum(q_values))
            combo_mean = sum(Fraction(w) * val for w, val in zip(weights, values)) / wsum
            projected = sum(Fraction(w) * (val - combo_mean) ** 2
                             for w, val in zip(weights, values))
            if projected != v_a:
                raise AssertionError(("mobius-block", n, cutoff, projected, v_a))
            checked += 1

    print(f"PASS {checked} exact Mobius first-tail no-cancellation instances")
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-n", type=int, default=70)
    args = parser.parse_args()
    raise SystemExit(run(args.max_n))
