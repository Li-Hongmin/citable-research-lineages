"""OMEN-only symbolic extraction of the fifth-coefficient channels.

This is an exploratory SymPy script.  It rewrites the exact Eulerian
coefficient as a finite sum of terms
  scale(m) * ratio**r * polynomial(m,r) * d_{m,r},
which identifies possible dominant Beta channels without numerical fitting.
"""

import sympy as sp
from fractions import Fraction
from math import comb, factorial


m, r = sp.symbols("m r", integer=True, nonnegative=True)


def binom_poly(n, k):
    if k < 0:
        return sp.Integer(0)
    out = sp.Integer(1)
    for q in range(k):
        out *= n - q
    return sp.expand(out / sp.factorial(k))


def eulerian_terms(n, j):
    out = []
    for ell in range(j + 1):
        base = j + 1 - ell
        coeff = (-1) ** ell * binom_poly(n + 1, ell)
        out.append((base, sp.expand(coeff)))
    return out


def phi_terms(a, b):
    out = []
    e = 2 * m + 2
    for i in range(6):
        for j in range(6 - i):
            k = 5 - i - j
            den = binom_poly(e + k - 1, k)
            for alpha, ca in eulerian_terms(a, i):
                for beta, cb in eulerian_terms(b, j):
                    out.append((alpha, beta, sp.expand(ca * cb * den)))
    return out


def add_side(groups, multiplier, a_shift, b_shift):
    # a=m-r+a_shift, b=2m+r+b_shift.
    for alpha, beta, coeff in phi_terms(m - r + a_shift, 2 * m + r + b_shift):
        scale = sp.Integer(alpha) * sp.Integer(beta) ** 2
        ratio = sp.Rational(beta, alpha)
        factor = multiplier * sp.Integer(alpha) ** a_shift * sp.Integer(beta) ** b_shift
        key = (scale, ratio)
        groups[key] = sp.expand(groups.get(key, 0) + factor * coeff)


def main():
    groups = {}
    q = 2 * m + r + 1
    p = m - r + 3
    add_side(groups, q, 3, 0)
    add_side(groups, -p, 2, 1)
    nonzero = []
    for key, poly in groups.items():
        poly = sp.factor(poly)
        if poly != 0:
            nonzero.append((key, poly))
    nonzero.sort(key=lambda item: (item[0][0], item[0][1]))
    print("J5_CHANNEL_COUNT", len(nonzero))
    for (scale, ratio), poly in nonzero:
        print(f"scale={scale} ratio={ratio} poly={poly}")

    def eulerian_low(n, j):
        return sum(
            (-1) ** ell * comb(n + 1, ell) * (j + 1 - ell) ** n
            for ell in range(j + 1)
        )

    def phi5_exact(mm, a, b):
        ee = 2 * mm + 2
        return sum(
            eulerian_low(a, i)
            * eulerian_low(b, j)
            * comb(ee + 4 - i - j, 5 - i - j)
            for i in range(6)
            for j in range(6 - i)
        )

    def d_weight(mm, rr):
        dd = 3 * mm + 3
        return Fraction(
            factorial(dd) * factorial(mm + rr - 2),
            comb(dd, 2)
            * 2**rr
            * factorial(rr - 1)
            * factorial(mm - rr)
            * factorial(2 * mm + rr + 1),
        )

    def direct(mm):
        dd = 3 * mm + 3
        out = Fraction(0)
        for rr in range(1, mm + 1):
            pp, qq = mm - rr + 3, 2 * mm + rr + 1
            out += d_weight(mm, rr) * (
                qq * phi5_exact(mm, pp, qq - 1)
                - pp * phi5_exact(mm, pp - 1, qq)
            )
        return out

    def grouped(mm):
        out = Fraction(0)
        for (scale, ratio), poly in nonzero:
            aa = sp.Poly(poly, m, r).as_expr().subs({m: mm})
            for rr in range(1, mm + 1):
                out += (
                    d_weight(mm, rr)
                    * Fraction(int(scale) ** mm)
                    * Fraction(ratio) ** rr
                    * Fraction(int(aa.subs({r: rr})))
                )
        return out

    for mm in range(1, 13):
        assert grouped(mm) == direct(mm)
    print("J5_CHANNEL_RECONSTRUCTION_EXACT_M1_12")


if __name__ == "__main__":
    main()
