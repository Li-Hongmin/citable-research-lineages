#!/usr/bin/env python3
"""Exact finite scan of the L=4 Newton gamma row."""

from __future__ import annotations

import argparse
import sys

sys.path.insert(0, "computations")
from verify_gamma_newton_cone import gamma


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("-M", "--max-m", type=int, default=40)
    args = parser.parse_args()
    for m in range(1, args.max_m + 1):
        values = [gamma(m, h, 4) for h in range(3 * m + 2)]
        minimum = min(values)
        h = values.index(minimum)
        if minimum < 0:
            raise AssertionError((m, h, minimum))
        print(f"m={m}: min gamma_L4={minimum} at h={h}")


if __name__ == "__main__":
    main()
