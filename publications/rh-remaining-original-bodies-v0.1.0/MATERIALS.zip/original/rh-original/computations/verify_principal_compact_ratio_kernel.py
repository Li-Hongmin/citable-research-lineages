from fractions import Fraction


def mobius(n: int) -> int:
    if n == 1:
        return 1
    x, parity, p = n, 0, 2
    while p * p <= x:
        if x % p == 0:
            x //= p
            parity ^= 1
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        parity ^= 1
    return -1 if parity else 1


def lehmer(i: int, j: int) -> Fraction:
    return Fraction(min(i, j), max(i, j))


def kappa(m: int, n: int) -> Fraction:
    r = Fraction(m, n)
    if r <= Fraction(1, 2) or r >= 2:
        return Fraction(0)
    if r <= 1:
        return 4 * r - 1 / r
    return 4 / r - r


def compressed_kernel(m: int, n: int) -> Fraction:
    return 5 * lehmer(m, n) - 2 * lehmer(m, 2 * n) - 2 * lehmer(2 * m, n)


def main() -> None:
    for Y in range(1, 81):
        mu = [0] + [mobius(n) for n in range(1, Y + 1)]

        for m in range(1, Y + 1):
            for n in range(1, Y + 1):
                assert compressed_kernel(m, n) == kappa(m, n)

        a = [0] * (2 * Y + 1)
        for m in range(1, 2 * Y + 1):
            a[m] = 2 * (mu[m] if m <= Y else 0)
            if m % 2 == 0 and m // 2 <= Y:
                a[m] -= mu[m // 2]

        q_filtered = Fraction(0)
        for m in range(1, 2 * Y + 1):
            for n in range(1, 2 * Y + 1):
                q_filtered += Fraction(1, 2) * a[m] * a[n] * lehmer(m, n)

        q_compact = Fraction(0)
        for m in range(1, Y + 1):
            for n in range(1, Y + 1):
                q_compact += Fraction(1, 2) * mu[m] * mu[n] * kappa(m, n)
        assert q_filtered == q_compact

        q_split = Fraction(3, 2) * sum(mu[n] * mu[n] for n in range(1, Y + 1))
        for n in range(1, Y):
            for h in range(1, min(n, Y - n) + 1):
                q_split += mu[n] * mu[n + h] * (
                    Fraction(4 * n, n + h) - Fraction(n + h, n)
                )
        assert q_split == q_compact

    print("compact-ratio kernel verified for Y=1..80")


if __name__ == "__main__":
    main()
