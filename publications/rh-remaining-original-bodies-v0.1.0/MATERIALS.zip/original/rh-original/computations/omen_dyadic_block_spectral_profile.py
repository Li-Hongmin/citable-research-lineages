#!/usr/bin/env python3
"""OMEN-only profile of dyadic Mobius blocks versus low-frequency mass.

For a zero-padded FFT of mu(1),...,mu(N), report the largest signed dyadic
block D_H and the spectral mass of |F_N(theta)|^2 in arcs of width c/H.
This is a finite route diagnostic only; it is not an asymptotic estimate.
"""

from __future__ import annotations

import argparse
import math

import numpy as np


def mobius(n: int) -> np.ndarray:
    value = np.zeros(n + 1, dtype=np.int8)
    value[1] = 1
    composite = np.zeros(n + 1, dtype=np.bool_)
    primes: list[int] = []
    for i in range(2, n + 1):
        if not composite[i]:
            primes.append(i)
            value[i] = -1
        for prime in primes:
            multiple = i * prime
            if multiple > n:
                break
            composite[multiple] = True
            if i % prime == 0:
                value[multiple] = 0
                break
            value[multiple] = -value[i]
    return value


def profile(n: int) -> None:
    value = mobius(n).astype(np.float64)
    length = 2 * n
    data = np.zeros(length, dtype=np.float64)
    data[1 : n + 1] = value[1:]
    spectrum = np.fft.rfft(data)
    power = spectrum.real * spectrum.real + spectrum.imag * spectrum.imag
    corr = np.rint(np.fft.irfft(power, n=length)[:n]).astype(np.int64)

    total_power = float(power.sum())
    best = (0, 0, 0)
    block = 1
    while block < n:
        endpoint = min(2 * block, n)
        signed = int(corr[block:endpoint].sum())
        candidate = (abs(signed), block, signed)
        if candidate > best:
            best = candidate
        block *= 2

    _, h, signed = best
    distances = np.minimum(np.arange(len(power)), length - np.arange(len(power)))
    print(f"N={n} H={h} D_H/N={signed / n:.9g}")
    for c in (0.5, 1.0, 2.0, 4.0):
        # |theta| <= c/H corresponds to distance <= c*length/(2*pi*H).
        radius = c * length / (2.0 * math.pi * h)
        mass = float(power[distances <= radius].sum() / total_power)
        print(f"  low_mass_width_{c:g}/H={mass:.9g}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("sizes", nargs="*", type=int,
                        default=[2**16, 2**18, 2**20, 2**22])
    args = parser.parse_args()
    for n in args.sizes:
        profile(n)


if __name__ == "__main__":
    main()
