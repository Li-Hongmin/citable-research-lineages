"""Stream over dyadic height centers and report the smallest sampled |Q|.

This is a non-rigorous adversarial search for candidate failures of the
zero-order factor-5 condition.  It does not certify zeros or inequalities.
"""

from __future__ import annotations

import argparse
import heapq

from flint import acb, acb_series, arb, ctx


def q_value(s: acb) -> acb:
    """Evaluate Q and its zeta derivative with a length-two Arb series."""
    variable = acb_series([s, acb(1)], 2)
    zeta_series = variable.zeta()
    zeta_value = zeta_series[0]
    zeta_derivative = zeta_series[1]
    c_value = (
        1
        + 1 / s
        + 1 / (s - 1)
        - arb.pi().log() / 2
        + (s / 2).digamma() / 2
    )
    return (s - 1) / s * (zeta_derivative + c_value * zeta_value)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a", type=float, required=True)
    parser.add_argument("--tau-max", type=float, default=5000.0)
    parser.add_argument("--top", type=int, default=8)
    parser.add_argument("--digits", type=int, default=25)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.a <= 0 or args.tau_max < 0 or args.top <= 0:
        raise ValueError("require a>0, tau-max>=0, and top>0")
    ctx.dps = args.digits

    height_step = 2 * args.a
    last_index = int(args.tau_max // height_step)
    smallest: list[tuple[float, float, complex]] = []

    for index in range(last_index + 1):
        tau = height_step * index
        value_ball = q_value(acb(arb(str(0.5 + args.a)), arb(str(tau))))
        value = complex(float(value_ball.real.mid()), float(value_ball.imag.mid()))
        magnitude_squared = abs(value) ** 2
        item = (-magnitude_squared, tau, value)
        if len(smallest) < args.top:
            heapq.heappush(smallest, item)
        elif magnitude_squared < -smallest[0][0]:
            heapq.heapreplace(smallest, item)

    print("NON-RIGOROUS dyadic-center scan")
    print("a =", args.a)
    print("height step =", height_step)
    print("tau range = [0,", last_index * height_step, "]")
    print("centers scanned =", last_index + 1)
    print("tau                 |Q|^2                  Q")
    for negative_magnitude, tau, value in sorted(
        smallest, key=lambda item: -item[0]
    ):
        print(f"{tau:12.6f}  {-negative_magnitude:.16e}  {value!r}")


if __name__ == "__main__":
    main()
