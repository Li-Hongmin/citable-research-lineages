"""OMEN-only exact scan for the fourth integer coefficient.

This is a finite diagnostic for notes 625--627, not an all-m proof.
"""

from fractions import Fraction
from math import comb, factorial


def eulerian_low(n: int, j: int) -> int:
    """Return [z^j] A_n(z) from the finite Eulerian formula."""
    return sum(
        (-1) ** ell * comb(n + 1, ell) * (j + 1 - ell) ** n
        for ell in range(j + 1)
    )


def phi4(m: int, a: int, b: int) -> int:
    e = 2 * m + 2
    return sum(
        eulerian_low(a, i)
        * eulerian_low(b, j)
        * comb(e + 3 - i - j, 4 - i - j)
        for i in range(5)
        for j in range(5 - i)
    )


def coefficient(m: int) -> Fraction:
    D = 3 * m + 3
    total = Fraction(0)
    for r in range(1, m + 1):
        d = Fraction(
            factorial(D) * factorial(m + r - 2),
            comb(D, 2)
            * 2**r
            * factorial(r - 1)
            * factorial(m - r)
            * factorial(2 * m + r + 1),
        )
        p = m - r + 3
        q = 2 * m + r + 1
        total += d * (q * phi4(m, p, q - 1) - p * phi4(m, p - 1, q))
    return total


def main() -> None:
    values = {m: coefficient(m) for m in range(1, 151)}
    assert all(value >= 0 for value in values.values())
    assert values[1] == values[2] == values[3] == values[4] == 0
    assert all(values[m] > 0 for m in range(5, 151))
    print("J4_SCAN_NO_NEGATIVE", "m=1..150", "first_positive", values[5])


if __name__ == "__main__":
    main()
