#!/usr/bin/env python3
"""Exact OMEN-only check of the Selberg taper convolution identity."""
from fractions import Fraction
import argparse


def mobius(n):
    x, parity, p = n, 0, 2
    while p * p <= x:
        if x % p == 0:
            x //= p
            parity ^= 1
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        parity ^= 1
    return -1 if parity else 1


def divisors(n):
    return [d for d in range(1, n + 1) if n % d == 0]


def log_vector(n):
    out = {}
    p = 2
    x = n
    while p * p <= x:
        while x % p == 0:
            out[p] = out.get(p, 0) + 1
            x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        out[x] = out.get(x, 0) + 1
    return out


def check(D):
    # Work symbolically with L=log(D): c_d = 1 - ell_d/L.
    # Store a_n as (constant, coefficient of 1/L), i.e. A+B/L.
    for n in range(2, D + 1):
        A = sum(mobius(n // d) for d in divisors(n))
        if A != 0:
            return False, (D, n, "sum_mu", A)
        lhs = {}
        for d in divisors(n):
            for p, e in log_vector(d).items():
                lhs[p] = lhs.get(p, 0) + mobius(n // d) * e
        lhs = {p: e for p, e in lhs.items() if e}
        # The divisor-log identity is Lambda(n): one unit of log(p) only
        # when n is a positive power of a single prime p.
        fac = log_vector(n)
        expected = {}
        if len(fac) == 1:
            p = next(iter(fac))
            expected[p] = 1
        if lhs != expected:
            return False, (D, n, "log-divisor", lhs, expected)
    return True, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-D", type=int, default=120)
    args = ap.parse_args()
    total = 0
    for D in range(2, args.max_D + 1):
        ok, detail = check(D)
        if not ok:
            raise SystemExit(f"FAIL {detail}")
        total += D - 1
    print(f"PASSED exact support checks: D=2..{args.max_D}, cases={total}")


if __name__ == "__main__":
    main()
