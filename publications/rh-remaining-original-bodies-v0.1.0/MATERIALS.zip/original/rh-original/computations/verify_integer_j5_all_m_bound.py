"""OMEN-only exact certificate for the fifth-coefficient large-m tail.

The proof compares every non-x=6 channel with the x=6 channel using a
Beta-integral peak bound.  All inequalities below are rational and are
checked after shifting m=n+200.
"""

import sympy as sp

m, n = sp.symbols("m n", integer=True, nonnegative=True)


def rows():
    return [
        (1, sp.Rational(1), -m*(m-1)*(m+1)*(m+2)*(m+3)*(m-2)/120, -m*(m-1)*(m+1)*(m+2)*(m+3)/60),
        (2, sp.Rational(1,2), m*(m+1)*(m+2)*(m+3)*(3*m-1)/6, m*(m+1)*(m+2)*(m+3)/2),
        (3, sp.Rational(1,3), -3*(m+1)*(m+2)*(m+3)*(5*m)/2, -6*(m+1)*(m+2)*(m+3)),
        (4, sp.Rational(1,4), 8*(m+2)*(m+3)*(7*m+1), 40*(m+2)*(m+3)),
        (4, sp.Rational(2), -5*m*(m+1)*(m+2)*(m+3)/24, m*(m+1)*(m+2)*(m+3)/8),
        (5, sp.Rational(1,5), -25*(m+3)*(9*m+2), -150*(m+3)),
        (6, sp.Rational(1,6), 36*(11*m+3), 252),
        (8, sp.Rational(1), -4*(m+1)*(m+2)*(m+3)*(m-2)/3, -8*(m+1)*(m+2)*(m+3)/3),
        (9, sp.Rational(3), (m+1)*(m+2)*(m+3)*(m+8)/6, -2*(m+1)*(m+2)*(m+3)/3),
        (12, sp.Rational(2,3), 9*(m+2)*(m+3)*(4*m-3)/2, 45*(m+2)*(m+3)/2),
        (16, sp.Rational(1,2), -32*(m+3)*(3*m-1), -96*(m+3)),
        (16, sp.Rational(4), -(m+2)*(m+3)*(2*m+11)/2, 5*(m+2)*(m+3)/2),
        (18, sp.Rational(3,2), 2*(m+2)*(m+3)*(m-7), 10*(m+2)*(m+3)),
        (20, sp.Rational(2,5), 25*(8*m-1), 175),
        (25, sp.Rational(5), (m+3)*(3*m+14), -6*(m+3)),
        (27, sp.Rational(1), -27*(m+3)*(m-2), -54*(m+3)),
        (32, sp.Rational(2), 40*(m+3), -24*(m+3)),
        (36, sp.Rational(3,4), 16*(5*m-5), 112),
        (36, sp.Rational(6), -4*m-17, 7),
        (48, sp.Rational(4,3), 9*(2*m-9), 63),
        (50, sp.Rational(5,2), -4*(m+13), 28),
    ]


def peak(A, x):
    if A == 50 and x == sp.Rational(5, 2):
        return sp.Rational(175, 8)
    if A == 25 and x == 5:
        return sp.Rational(50, 3)
    return sp.Rational(A) * (2 + x) / 8


def main():
    total = 0
    checked = 0
    for A, x, a, b in rows():
        if A == 36 and x == 6:
            continue
        a, b = sp.sympify(a), sp.sympify(b)
        aa = 1 if a.subs(m, 200) >= 0 else -1
        bb = 1 if b.subs(m, 200) >= 0 else -1
        c = sp.expand(aa * a + m * bb * b)
        rho = sp.factor(peak(A, x) / 24)
        assert 0 < rho < 1
        dec = sp.Poly(sp.expand((c - rho * c.subs(m, m + 1)).subs(m, n + 200)), n)
        assert all(v > 0 for v in dec.all_coeffs())
        term200 = sp.Rational(15 * A, 32) * x * rho ** 199 * c.subs(m, 200)
        total += term200
        checked += 1
    assert total < 1
    print("J5_ALL_M_TAIL_BOUND_OK", "m>=200", "channels", checked)
    print("ENVELOPE_M200", sp.N(total, 20))


if __name__ == "__main__":
    main()
