#!/usr/bin/env python3
"""OMEN-only shell-by-major/minor-arc cross diagnostic.

The Fourier and shell definitions match omen_phase_defect_profile.py.  This
probe separates each shell's signed contribution on a fixed rational-arc
union from its minor-arc complement.  It is finite diagnostic evidence only.
"""

from __future__ import annotations

import importlib.util
import math
from fractions import Fraction

import numpy as np


def load_phase_module():
    spec = importlib.util.spec_from_file_location(
        "phase_profile", "computations/omen_phase_defect_profile.py"
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def profile(n: int = 2**22, qmax: int = 4096) -> None:
    phase = load_phase_module()
    value = phase.mobius(n).astype(np.float64)
    corr = phase.block_corr(value)
    best = (0, 0, 0)
    h = 1
    while h < n:
        signed = int(corr[h : min(2 * h, n)].sum())
        candidate = (abs(signed), h, signed)
        if candidate > best:
            best = candidate
        h *= 2
    _, h, signed = best

    length = 4 * n
    padded = np.zeros(length, dtype=np.float64)
    padded[1 : n + 1] = value[1:]
    transform = np.fft.rfft(padded)
    power = transform.real * transform.real + transform.imag * transform.imag
    k = np.arange(len(power), dtype=np.int64)
    theta = k.astype(np.float64) / length
    denominator = np.sin(np.pi * theta)
    numerator = np.sin(np.pi * h * theta)
    phase_factor = np.exp(2j * np.pi * (h + (h - 1) / 2.0) * theta)
    kernel = np.empty_like(phase_factor)
    kernel[0] = h
    kernel[1:] = phase_factor[1:] * numerator[1:] / denominator[1:]
    multiplicity = np.full(k.shape, 2.0)
    multiplicity[(k == 0) | (k == length // 2)] = 1.0
    distance = np.minimum(k, length - k)
    shell = phase.shell_index(distance, length, h)
    scale = 1.0 / (n * length)

    fractions: set[Fraction] = set()
    for q in range(1, qmax + 1):
        for a in range(q):
            if math.gcd(a, q) == 1:
                raw = Fraction(a, q)
                fractions.add(min(raw, 1 - raw))
    radius = max(1, int(math.ceil(length / (8 * h))))
    major = np.zeros(k.shape, dtype=np.bool_)
    for frac in fractions:
        center = int(round(float(frac) * length))
        major[max(0, center - radius) : min(len(k), center + radius + 1)] = True

    weights = multiplicity * power
    total = float(np.sum(weights * kernel.real) * scale)
    print(f"N={n} H={h} D/N={total:.12g} qmax={qmax}")
    for name, mask in (
        ("all", np.ones(k.shape, dtype=np.bool_)),
        ("major", major),
        ("minor", ~major),
    ):
        signed_shell = np.bincount(
            shell[mask], weights=weights[mask] * kernel.real[mask] * scale
        )
        absolute_shell = np.bincount(
            shell[mask], weights=weights[mask] * np.abs(kernel.real[mask]) * scale
        )
        print(
            name,
            "D/N",
            float(signed_shell.sum()),
            "W",
            float(absolute_shell.sum()),
        )
        # Print every occupied shell.  Earlier thresholded output made tiny
        # major-arc entries look like exact zeros in the note; retaining the
        # full values keeps the finite diagnostic auditable.
        for j, contribution in enumerate(signed_shell):
            if absolute_shell[j] > 0.0:
                print(
                    f"  shell={j} D={contribution:.12g} "
                    f"W={absolute_shell[j]:.12g}"
                )


if __name__ == "__main__":
    profile()
