"""Combine adjacent exact Arb Yukawa-family caches and fill cross-Gram entries."""

import os
import numpy as np
from flint import arb, arb_mat, ctx

ctx.prec = 192
OLD = os.environ.get(
    "YUKAWA_OLD",
    "scratch/log11_even_K400_N500_yukawa_500_640_parseval_arb_192.npz",
)
NEW = os.environ.get(
    "YUKAWA_NEW",
    "scratch/log11_even_K400_N500_yukawa_640_700_parseval_arb_192.npz",
)
OUT = os.environ.get(
    "YUKAWA_OUT",
    "scratch/log11_even_K400_N500_yukawa_500_700_parseval_arb_192.npz",
)

old = np.load(OLD, allow_pickle=True)
new = np.load(NEW, allow_pickle=True)
m0 = int(old["atom_hi"]) - int(old["atom_lo"])
m1 = int(new["atom_hi"]) - int(new["atom_lo"])
old_lo = int(old["atom_lo"])
old_hi = int(old["atom_hi"])
new_lo = int(new["atom_lo"])
new_hi = int(new["atom_hi"])
assert int(old["atom_lo"]) + m0 == int(new["atom_lo"])
assert int(old["atom_hi"]) == int(new["atom_lo"])
R = int(old["R"])


def mat(raw):
    return arb_mat([[arb(str(v)) for v in row] for row in raw])


def strings(A):
    vals = [[str(A[i, j]) for j in range(A.ncols())] for i in range(A.nrows())]
    width = max(len(v) for row in vals for v in row)
    return np.asarray(vals, dtype=f"<U{width}")


def concat_columns(key):
    a0, a1 = mat(old[key]), mat(new[key])
    out = arb_mat(R, m0 + m1)
    for i in range(R):
        for j in range(m0):
            out[i, j] = a0[i, j]
        for j in range(m1):
            out[i, m0 + j] = a1[i, j]
    return out


b = concat_columns("b")
h = concat_columns("h")
cross = concat_columns("cross")
e = concat_columns("e")

a = arb(11).log() / 2


def atom_gram(n, k):
    c = arb(2 * n) + arb(".5")
    d = arb(2 * k) + arb(".5")
    den = ((1 - (-2 * c * a).exp()) * (1 - (-2 * d * a).exp())).sqrt()
    diff = a if n == k else ((c - d) * a).sinh() / (c - d)
    return 2 * (-(c + d) * a).exp() * (
        diff + ((c + d) * a).sinh() / (c + d)
    ) / den


full = arb_mat(m0 + m1, m0 + m1)
g0, g1 = mat(old["gram_full"]), mat(new["gram_full"])
for i in range(m0):
    for j in range(m0):
        full[i, j] = g0[i, j]
for i in range(m1):
    for j in range(m1):
        full[m0 + i, m0 + j] = g1[i, j]
for i, n in enumerate(range(old_lo, old_hi)):
    for j, k in enumerate(range(new_lo, new_hi)):
        v = atom_gram(n, k)
        full[i, m0 + j] = v
        full[m0 + j, i] = v

gram_q = full - b.transpose() * b
mu = arb(str(old["t400"]))
metric = arb_mat(m0 + m1, m0 + m1)
for i in range(m0 + m1):
    for j in range(m0 + m1):
        metric[i, j] = gram_q[i, j] / mu + (1 if i == j else 0)
metric = (metric + metric.transpose()) / 2

np.savez(
    OUT,
    b=strings(b),
    h=strings(h),
    cross=strings(cross),
    e=strings(e),
    gram_full=strings(full),
    gram_q=strings(gram_q),
    metric=strings(metric),
    t400=np.array(str(mu)),
    a=np.array(str(a)),
    source_model=np.array("log11_even_K400_N500_scalar_lift"),
    cache_prefix=np.array("log11"),
    parity=np.array("+"),
    R=np.array(R),
    N=np.array(500),
    atom_lo=np.array(old_lo),
    atom_hi=np.array(new_hi),
    precision=np.array(min(int(old["precision"]), int(new["precision"]))),
    exact_parseval=np.array(True),
    parent_family=np.array(OLD),
    appended_family=np.array(NEW),
)
print("WROTE", OUT)
