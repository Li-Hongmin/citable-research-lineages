#!/usr/bin/env python3
"""Low-memory quadrature for the resonant Gamma ledger in note 098.

The correlated model uses the *actual numerical Mellin transform* of a
C-infinity compactly supported weight, rather than a Gaussian surrogate.
"""

from __future__ import annotations

import argparse
import numpy as np


LAMBDA = 0.999


def bump(x: np.ndarray) -> np.ndarray:
    out = np.zeros_like(x, dtype=float)
    mask = (x > 1.0) & (x < 2.0)
    z = (x[mask] - 1.0) * (2.0 - x[mask])
    out[mask] = np.exp(-1.0 / z)
    return out


def normalized_bump_grid(n: int) -> tuple[np.ndarray, np.ndarray]:
    x = np.linspace(1.0, 2.0, n)
    b = bump(x)
    b /= np.trapezoid(b, x)
    return x, b


def gamma2(t: np.ndarray, u: np.ndarray, T: float, m0: float) -> np.ndarray:
    U = 1.0 + np.abs(u)
    rho = 1.0 + np.abs(t - u)  # resonant orientation tau=t-u
    N = T ** (2.0 * LAMBDA)
    return U / rho + 1.0 / m0 + U / N + rho / (m0 * N)


def independent_average(T: float, n: int, m0: float) -> float:
    # Center/difference coordinates.  A logarithmic q mesh resolves the
    # width-one resonant strip even when T is large.
    s = np.linspace(1.0, 2.0, max(300, n // 4))
    qpos = np.concatenate(([0.0], np.geomspace(1.0e-5, T, n)))
    q = np.concatenate((-qpos[:0:-1], qpos))
    numerator = 0.0
    denominator = 0.0
    for si in s:
        t = T * si + q / 2.0
        u = T * si - q / 2.0
        joint = bump(t / T) * bump(u / T)
        denominator += np.trapezoid(joint, q)
        numerator += np.trapezoid(joint * gamma2(t, u, T, m0), q)
    return numerator / denominator


def mellin_power(q: np.ndarray, nx: int = 1400, chunk: int = 256) -> np.ndarray:
    """Return |int w(x)x^(iq) dx/x|^2, with w L2(dx/x)-normalized."""
    x = np.linspace(1.0, 2.0, nx)
    raw = bump(x)
    norm2 = np.trapezoid(raw * raw / x, x)
    w = raw / np.sqrt(norm2)
    logx = np.log(x)
    amp = w / x
    out = np.empty_like(q, dtype=float)
    for lo in range(0, q.size, chunk):
        qq = q[lo : lo + chunk]
        vals = np.trapezoid(amp[:, None] * np.exp(1j * logx[:, None] * qq), x, axis=0)
        out[lo : lo + chunk] = np.abs(vals) ** 2
    return out


def correlated_average(T: float, ns: int, nq: int, qmax: float, m0: float) -> tuple[float, float]:
    # s=(t+u)/(2T), q=t-u. Jacobian cancels after probability normalization.
    s = np.linspace(1.0, 2.0, ns)
    q = np.linspace(-qmax, qmax, nq)
    mq2 = mellin_power(q)
    numerator = 0.0
    denominator = 0.0
    for si in s:
        t = T * si + q / 2.0
        u = T * si - q / 2.0
        joint = bump(t / T) * bump(u / T) * mq2
        denominator += np.trapezoid(joint, q)
        numerator += np.trapezoid(joint * gamma2(t, u, T, m0), q)
    ds = s[1] - s[0]
    return numerator * ds / (denominator * ds), denominator * ds


def slope(Ts: np.ndarray, vals: np.ndarray) -> float:
    return float(np.polyfit(np.log(Ts), np.log(vals), 1)[0])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--t-powers", default="2,2.5,3,3.5,4")
    parser.add_argument("--n-independent", type=int, default=1600)
    parser.add_argument("--n-center", type=int, default=500)
    parser.add_argument("--n-difference", type=int, default=1601)
    parser.add_argument("--qmax", type=float, default=80.0)
    parser.add_argument("--m0", type=float, default=1.0)
    args = parser.parse_args()

    Ts = 10.0 ** np.array([float(v) for v in args.t_powers.split(",")])
    ind, corr, masses = [], [], []
    print("T independent_EGamma2 independent_RMS correlated_EGamma2 correlated_RMS corr_mass")
    for T in Ts:
        ai = independent_average(T, args.n_independent, args.m0)
        ac, mass = correlated_average(T, args.n_center, args.n_difference, args.qmax, args.m0)
        ind.append(ai)
        corr.append(ac)
        masses.append(mass)
        print(f"{T:.8g} {ai:.12g} {np.sqrt(ai):.12g} {ac:.12g} {np.sqrt(ac):.12g} {mass:.12g}")
    ind = np.asarray(ind)
    corr = np.asarray(corr)
    print(f"loglog_slope_EGamma2 independent={slope(Ts, ind):.8f} correlated={slope(Ts, corr):.8f}")
    print(f"loglog_slope_RMS independent={slope(Ts, np.sqrt(ind)):.8f} correlated={slope(Ts, np.sqrt(corr)):.8f}")
    print("independent_over_logT", " ".join(f"{v:.8g}" for v in ind / np.log(Ts)))
    print("correlated_over_T", " ".join(f"{v:.8g}" for v in corr / Ts))

    x, b = normalized_bump_grid(5000)
    independent_leading = 2.0 * np.trapezoid(x * b * b, x)
    q = np.linspace(-args.qmax, args.qmax, args.n_difference)
    mq2 = mellin_power(q)
    q_ratio = np.trapezoid(mq2 / (1.0 + np.abs(q)), q) / np.trapezoid(mq2, q)
    center_mean = np.trapezoid(x * bump(x) ** 2, x) / np.trapezoid(bump(x) ** 2, x)
    print(f"predicted_independent_EGamma2_over_logT={independent_leading:.12g}")
    print(f"predicted_correlated_EGamma2_over_T={center_mean*q_ratio:.12g}")


if __name__ == "__main__":
    main()
