"""Generate the fixed odd top-40 weighted-complement q64 basis."""
import re
import numpy as np
from scipy.linalg import svd

def mid(s):
    return float(re.search(r'\[?([^ ]+)', str(s)).group(1))

ex = np.load('scratch/log9_odd_R280_N400_exact_small_map.npz')
d = np.load('scratch/log9_odd_R280_N500_q280_1000_raw_v_float.npz')
raw, den = d['v'], d['den']
mu = 1.7020375626948444911211115524959743
w = 1 / mu - 1 / den
w[0] = 0.0
T = raw * np.sqrt(np.maximum(w, 0.0))
for row in ex['whist_arb']:
    h = np.array([mid(z) for z in row])
    T -= 2 * np.outer(h, h @ T) / (h @ h)
_, _, vh = svd(T[5:], full_matrices=False, lapack_driver='gesdd')
q64 = np.empty((40, 720), dtype=object)
for i in range(40):
    for j in range(720):
        q64[i, j] = str(int(round(float(vh[i, j]) * 2**64)))
np.savez(
    'scratch/log9_odd_q280_1000_rank40_q64.npz',
    numerator=q64,
    denominator='18446744073709551616',
)
print('GENERATED_LOG9_ODD_RANK40_Q64')
