#!/usr/bin/env python3
"""Cayley-midpoint scan of one-pole rational multipliers at one Q cell."""

from __future__ import annotations

import argparse

import numpy as np
from flint import acb, arb, ctx

from explore_q_optimal_polynomial_approximants import boundary_samples, q_value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a", type=float, required=True)
    parser.add_argument("--tau", type=float, required=True)
    parser.add_argument("--samples", type=int, default=16384)
    parser.add_argument("--damping-scales", type=float, nargs="+", required=True)
    parser.add_argument("--digits", type=int, default=40)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.a <= 0 or min(args.damping_scales) <= 0:
        raise ValueError("a and damping scales must be positive")
    ctx.dps = args.digits

    theta, boundary = boundary_samples(args.samples, args.a, args.tau)
    offsets = args.a / np.tan(theta / 2.0)
    boundary_square = np.abs(boundary) ** 2
    center_ball = q_value(acb(arb(str(0.5 + args.a)), arb(str(args.tau))))
    center = complex(float(center_ball.real.mid()), float(center_ball.imag.mid()))
    target = abs(center) ** 2

    print("NON-RIGOROUS Cayley midpoint rational-resolvent cell scan")
    print("a =", args.a, "tau =", args.tau, "samples =", args.samples)
    print("|Q(center)|^2 =", target)
    print("L                 ratio")
    for damping in args.damping_scales:
        rational_square = (args.a + damping) ** 2 / (damping**2 + offsets**2)
        ratio = float(np.mean(boundary_square * rational_square) / target)
        print(f"{damping:14.8g}  {ratio:.12f}")


if __name__ == "__main__":
    main()
