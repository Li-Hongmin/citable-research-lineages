#!/usr/bin/env python3
"""Exact OMEN-side check for note 471."""

from __future__ import annotations

import argparse
from fractions import Fraction


def mobius_table(n_max: int) -> list[int]:
    mu = [1] * (n_max + 1)
    mu[0] = 0
    primes: list[int] = []
    composite = [False] * (n_max + 1)
    for n in range(2, n_max + 1):
        if not composite[n]:
            primes.append(n)
            mu[n] = -1
        for p in primes:
            if n * p > n_max:
                break
            composite[n * p] = True
            if n % p == 0:
                mu[n * p] = 0
                break
            mu[n * p] = -mu[n]
    return mu


def run(max_n: int) -> int:
    mu = mobius_table(max_n)
    harmonic = [Fraction(0)] * (max_n + 1)
    for n in range(1, max_n + 1):
        harmonic[n] = harmonic[n - 1] + Fraction(1, n)

    def tail(q: int, m: int) -> Fraction:
        return sum((Fraction(mu[n], n) for n in range(q + 1, m + 1)), Fraction(0))

    checked = 0
    for n in range(2, max_n + 1):
        tails = [tail(q, n) for q in range(n + 1)]
        energy = sum(Fraction(2 * k + 1) * tails[k] ** 2 for k in range(1, n))

        for k in range(1, n):
            rhs = -sum((Fraction(1, d) * tail(k // d, n // d)
                        for d in range(2, n + 1)), Fraction(0))
            if tails[k] != rhs:
                raise AssertionError(("row", n, k, tails[k], rhs))

        envelope_terms = []
        for d in range(2, n + 1):
            m = n // d
            e_m = sum(Fraction(2 * q + 1) * tail(q, m) ** 2 for q in range(1, m))
            s_m = tail(0, m)
            b = e_m + Fraction(d * d - 1, d * d) * s_m ** 2
            direct_w = sum(Fraction(2 * k + 1) * tail(k // d, m) ** 2
                           for k in range(1, n))
            if direct_w != d * d * e_m + (d * d - 1) * s_m ** 2:
                raise AssertionError(("block", n, d, direct_w, e_m, s_m))
            envelope_terms.append(b)

        # Avoid irrational arithmetic: verify the non-optimized Cauchy envelope
        # with all weights lambda_d=1; it is weaker but exact.
        cauchy_bound = Fraction(len(envelope_terms)) * sum(envelope_terms)
        if energy > cauchy_bound:
            raise AssertionError(("envelope", n, energy, cauchy_bound))
        checked += 1

    print(f"PASS {checked} exact row-recursion and Cauchy-envelope instances")
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-n", type=int, default=60)
    args = parser.parse_args()
    raise SystemExit(run(args.max_n))
