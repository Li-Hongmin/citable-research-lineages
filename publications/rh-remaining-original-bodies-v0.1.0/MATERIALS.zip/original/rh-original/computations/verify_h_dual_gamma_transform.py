#!/usr/bin/env python3
"""Exact check of the h-dual binomial transform in note 366.

This verifies the identity against the original Stirling/Fraction formula for
small m.  It is a finite identity check, not an all-m positivity proof.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
from functools import lru_cache
from math import comb, factorial


@lru_cache(maxsize=None)
def stirling2(n: int, k: int) -> int:
    if n == k == 0:
        return 1
    if n == 0 or k == 0 or k > n:
        return 0
    return k * stirling2(n - 1, k) + stirling2(n - 1, k - 1)


@lru_cache(maxsize=None)
def F(a: int, b: int, M: int) -> int:
    return sum(
        stirling2(a, i)
        * stirling2(b, M - i)
        * factorial(i)
        * factorial(M - i)
        for i in range(M + 1)
    )


def data(m: int):
    D, d = 3 * m + 3, 3 * m + 1
    weights = {}
    for q in range(2, m + 2):
        c_q = Fraction(
            factorial(2 * m - q) * factorial(q),
            2 ** (m - q + 2)
            * factorial(m - q + 1)
            * factorial(q - 2)
            * comb(D, 2),
        )
        weights[q] = c_q * comb(D, q)

    K = {1: -3 * weights[2]}
    for q in range(2, m + 1):
        K[q] = weights[q] * (D - q) - weights[q + 1] * (q + 2)
    K[m + 1] = weights[m + 1] * (D - m - 1)
    return D, d, K


def gamma_original(m: int, h: int, L: int) -> Fraction:
    D, d, _ = data(m)
    M = L + 1
    total = Fraction(0)
    for q in range(2, m + 2):
        c_q = Fraction(
            factorial(2 * m - q) * factorial(q),
            2 ** (m - q + 2)
            * factorial(m - q + 1)
            * factorial(q - 2)
            * comb(D, 2),
        )
        w_q = c_q * comb(D, q)
        R = D - q - 1
        bracket = Fraction(0)
        for s in range(min(R, h) + 1):
            elev = Fraction(comb(R, s) * comb(h, s), comb(d, s))
            bracket += elev * (
                (D - q) * F(q + 1, R - s, M)
                - Fraction((q + 1) * (D - q), D - q - s)
                * F(q, R + 1 - s, M)
            )
        if h >= D - q:
            bracket -= (q + 1) * Fraction(comb(h, D - q), comb(d, D - q)) * F(
                q, 0, M
            )
        total += w_q * bracket
    return total / factorial(L + 2)


def gamma_dual(m: int, h: int, L: int) -> Fraction:
    D, d, K = data(m)
    M, r = L + 1, d - h
    transformed = 0
    for q, K_q in K.items():
        R = D - q - 1
        for s in range(R + 1):
            transformed += (
                K_q
                * comb(R, s)
                * comb(d - s, r)
                * F(q + 1, R - s, M)
            )
    prefactor = Fraction(
        factorial(r), factorial(L + 2) * (factorial(d) // factorial(h))
    )
    return prefactor * transformed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("-M", type=int, default=7)
    args = parser.parse_args()
    for m in range(1, args.M + 1):
        D, d, _ = data(m)
        for h in range(d + 1):
            for L in range(D):
                left = gamma_original(m, h, L)
                right = gamma_dual(m, h, L)
                if left != right:
                    raise AssertionError((m, h, L, left, right))
        print(f"m={m}: exact h-dual transform OK")


if __name__ == "__main__":
    main()
