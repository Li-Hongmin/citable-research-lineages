#!/usr/bin/env python3
"""Compute Arb Taylor jets for the whitened tangent-disk xi+xi' function."""

from __future__ import annotations

import argparse

from flint import acb, acb_series, arb, ctx


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--band-top", type=str, required=True)
    parser.add_argument("--tau", type=str, required=True)
    parser.add_argument("--order", type=int, default=16)
    parser.add_argument("--digits", type=int, default=50)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    band_top = arb(args.band_top)
    if (
        not (arb(0) < band_top <= arb("0.5"))
        or args.order < 2
        or args.digits < 20
    ):
        raise ValueError("invalid tangent-disk jet parameters")

    ctx.dps = args.digits
    # python-flint otherwise silently uses its default series cap (normally 10).
    ctx.cap = args.order + 3

    radius = 3 * band_top / 4
    center = acb(arb("0.5") + radius, arb(args.tau))
    variable = acb_series([center, acb(1)], args.order + 2)
    gamma_factor = (
        variable
        * (variable - 1)
        / 2
        * (-variable * arb.pi().log() / 2).exp()
        * (variable / 2).gamma()
    )
    xi_series = gamma_factor * variable.zeta()
    f_coefficients = [
        xi_series[degree] + (degree + 1) * xi_series[degree + 1]
        for degree in range(args.order + 1)
    ]

    logarithmic_jet = f_coefficients[1] / f_coefficients[0]
    exponential_coefficients = [acb(1)]
    for degree in range(1, args.order + 1):
        exponential_coefficients.append(
            exponential_coefficients[-1] * (-logarithmic_jet) / degree
        )

    whitened_coefficients = []
    for degree in range(args.order + 1):
        coefficient = sum(
            (f_coefficients[index] / f_coefficients[0])
            * exponential_coefficients[degree - index]
            for index in range(degree + 1)
        )
        whitened_coefficients.append(coefficient * radius**degree)

    print("Arb tangent-disk whitened Taylor jets")
    print("center =", center)
    print("radius =", radius)
    print("series cap =", ctx.cap)
    print("R f'(c)/f(c) =", radius * logarithmic_jet)
    print("degree        scaled coefficient enclosure        energy enclosure")
    partial_energy = arb(0)
    for degree, coefficient in enumerate(whitened_coefficients):
        energy = coefficient.real**2 + coefficient.imag**2
        partial_energy += energy
        print(degree, coefficient, energy)
    print("partial Parseval energy through order", args.order, "=", partial_energy)
    print(
        "This is a certified finite-jet subtotal only; no uncomputed Taylor "
        "tail bound is asserted."
    )


if __name__ == "__main__":
    main()
