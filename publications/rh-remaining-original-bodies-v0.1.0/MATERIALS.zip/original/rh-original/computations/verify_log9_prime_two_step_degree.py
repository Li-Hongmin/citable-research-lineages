"""Scratch grid-free two-step prime norm bound at a=log(3)."""
"""Exact-cell Arb verification of the log9 half-prime two-step bound."""
from fractions import Fraction as F
import sys
from flint import arb, ctx
ctx.prec = int(sys.argv[1]) if len(sys.argv) > 1 else 192

PR=(2,3,5,7); Z=(F(0),)*4
def V(*q): return tuple(F(x) for x in q)
def add(x,y): return tuple(a+b for a,b in zip(x,y))
def neg(x): return tuple(-a for a in x)
def sub(x,y): return add(x,neg(y))
def mul(c,x): return tuple(F(c)*a for a in x)
def av(x):
    return sum((arb(c.numerator)/c.denominator*arb(p).log() for c,p in zip(x,PR)),arb(0))
def lt(x,y): return av(x)<av(y)
def inside(x,l,h): return lt(l,x) and lt(x,h)

L2=V(1,0,0,0); L3=V(0,1,0,0); L4=mul(2,L2)
L5=V(0,0,1,0); L7=V(0,0,0,1); L8=mul(3,L2)
A=L3
DN={2:L2,3:L3,4:L4,5:L5,7:L7,8:L8}
E=[('x',1,L2,Z,sub(A,L2),'S+'),('x',1,neg(L2),L2,A,'S-')]
for n,k in ((2,'x'),(3,'y'),(4,'z'),(5,'w'),(7,'v'),(8,'u')):
    d=DN[n]; lo=Z if lt(d,A) else sub(d,A); hi=d if lt(d,A) else A
    E.append((k,-1,d,lo,hi,'J%d'%n))
def image(e,t): return add(mul(e[1],t),e[2])
def active(t): return [e for e in E if inside(t,e[3],e[4])]

base={Z,A}
for e in E: base|={e[3],e[4]}
cuts=set(base)
for e in E:
    for b in base:
        t=mul(e[1],sub(b,e[2]))
        if t in (Z,A) or (lt(Z,t) and lt(t,A)): cuts.add(t)
cuts=sorted(cuts,key=lambda q:float(av(q).mid()))

x=arb(2).log()/arb(2).sqrt(); y=arb(3).log()/arb(3).sqrt(); z=arb(2).log()/2
w=arb(5).log()/arb(5).sqrt(); v=arb(7).log()/arb(7).sqrt(); u=arb(2).log()/arb(8).sqrt()
W={'x':x,'y':y,'z':z,'w':w,'v':v,'u':u}; names=tuple(W)
def lindeg(t):
    q={k:0 for k in names}
    for e in active(t): q[e[0]]+=1
    return q
def padd(p,k,q):
    for j,c in q.items():
        ij=tuple(sorted((k,j))); p[ij]=p.get(ij,0)+c
def pval(p): return sum((arb(c)*W[i]*W[j] for (i,j),c in p.items()),arb(0))

rows=[]
for l,h in zip(cuts,cuts[1:]):
    m=mul(F(1,2),add(l,h)); p={}; detail=[]
    for e in active(m):
        q=lindeg(image(e,m)); padd(p,e[0],q); detail.append((e[5],q))
    rows.append((l,h,pval(p),p,detail))
best=max(rows,key=lambda r:float(r[2].mid())); sup=best[2]; poly=best[3]
for _,_,q,p,_ in rows: assert p==poly or q<sup, (q,sup,p)
print('bits',ctx.prec,'cells',len(rows),'active_n',[2,3,4,5,7,8])
print('sup_D2',sup); print('norm_bound',sup.sqrt()); print('poly',poly)
for l,h,q,p,d in rows:
    if p==poly: print('MAX',av(l),av(h),'detail',d)
