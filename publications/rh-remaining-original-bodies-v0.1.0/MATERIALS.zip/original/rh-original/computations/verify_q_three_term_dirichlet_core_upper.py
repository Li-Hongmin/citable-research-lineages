#!/usr/bin/env python3
"""Rigorous finite-core certificate for the note 049 three-term witness.

The displayed decimal coefficients are treated as exact rationals.  The
integral is analytically complexified, so Arb's validated quadrature encloses
the integral itself instead of summing pointwise interval suprema.  This file
does *not* bound the two infinite tails.

Reproduce with:

    uv run --with python-flint python \
      computations/verify_q_three_term_dirichlet_core_upper.py
"""

from __future__ import annotations

from decimal import Decimal

from flint import acb, arb, ctx

from verify_q_reverse_poisson_failure import q_value


ctx.dps = 35
A = arb(1) / 16
TAU = arb(4323) / 8
RADIUS = Decimal(50)
SUBINTERVAL = Decimal("0.25")
D_RE = ("0.507783617928", "-0.232016167436", "-0.640303853772")
D_IM = ("-0.017061423220", "-0.077291815102", "-0.085478016496")


def dirichlet_value(s: acb, reflected: bool = False) -> acb:
    total = acb(0)
    for n, (re, im) in enumerate(zip(D_RE, D_IM), start=1):
        coefficient = acb(arb(re), -arb(im) if reflected else arb(im))
        total += coefficient * (-s * arb(n).log()).exp()
    return total


def integrand(t: acb, analytic: bool) -> acb:
    del analytic  # every factor is meromorphic; poles produce nonfinite balls
    s_plus = acb(arb("0.5"), 0) + acb(0, 1) * t
    s_minus = acb(arb("0.5"), 0) - acb(0, 1) * t
    product = (
        q_value(s_plus)
        * dirichlet_value(s_plus)
        * q_value(s_minus)
        * dirichlet_value(s_minus, reflected=True)
    )
    return A / arb.pi() * product / (A**2 + (t - TAU) ** 2)


core = acb(0)
count = int(2 * RADIUS / SUBINTERVAL)
tau_decimal = Decimal(4323) / Decimal(8)
for j in range(count):
    lo = acb(arb(str(tau_decimal - RADIUS + j * SUBINTERVAL)))
    hi = acb(arb(str(tau_decimal - RADIUS + (j + 1) * SUBINTERVAL)))
    core += acb.integral(
        integrand,
        lo,
        hi,
        rel_tol=arb("1e-25"),
        abs_tol=arb("1e-28"),
        eval_limit=100000,
        depth_limit=30,
    )

s0 = acb(arb(9) / 16, TAU)
center_square = abs(q_value(s0) * dirichlet_value(s0)) ** 2
target = (5 * center_square).lower()
core_upper = core.real.upper()
tail_budget = (target - core_upper).lower()

assert core.imag.contains(0)
assert core_upper < arb("1.036560785318149")
assert center_square.lower() > arb("0.223577991592209")
assert tail_budget > arb("0.0813291726428")

print("RIGOROUS finite-core certificate")
print("coefficients =", list(zip(D_RE, D_IM)))
print("a = 1/16; tau = 4323/8; radius = 50")
print("analytic integral enclosure =", core)
print("|Q(s0)D(s0)|^2 =", center_square)
print("factor-five target lower =", target)
print("remaining budget for both infinite tails =", tail_budget)
print("PASS: the finite core is below the factor-five target")
