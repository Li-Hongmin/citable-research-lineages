#!/usr/bin/env python3
"""OMEN-only finite diagnostic for the low-frequency Lehmer sine gate.

For theta_j=(2j-1)pi/(2N+1), j<=ceil(sqrt(N)), compute
    L_J(N)=sum_j |sum_{n<=N} mu(n) sin(n theta_j)|^2/(2j-1)^2
using one FFT of length 4N+2.  This is a finite diagnostic only; it is
not an estimate intended for the proof of RH.
"""

from __future__ import annotations

import argparse
import math
import time

import numpy as np


def mobius_sieve(n: int) -> np.ndarray:
    mu = np.ones(n + 1, dtype=np.int8)
    prime = np.ones(n + 1, dtype=np.bool_)
    prime[:2] = False
    for p in range(2, n + 1):
        if not prime[p]:
            continue
        mu[p::p] *= -1
        if p * p <= n:
            mu[p * p :: p * p] = 0
            prime[p * p :: p] = False
    mu[0] = 0
    return mu


def one(n: int) -> tuple[float, float, float, int]:
    t0 = time.time()
    mu = mobius_sieve(n)
    length = 4 * n + 2
    data = np.zeros(length, dtype=np.float64)
    data[1 : n + 1] = mu[1 : n + 1]
    spectrum = np.fft.fft(data)
    jmax = math.isqrt(n)
    if jmax * jmax < n:
        jmax += 1
    odd = 2 * np.arange(1, jmax + 1, dtype=np.int64) - 1
    sine = spectrum[odd].imag
    weighted = float(np.sum((sine * sine) / (odd.astype(np.float64) ** 2)))
    first = float(sine[0] * sine[0])
    normalized = weighted / n
    return weighted, normalized, first / n, int(round(time.time() - t0))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--min-exp", type=int, default=10)
    ap.add_argument("--max-exp", type=int, default=20)
    args = ap.parse_args()
    print("N,L_J,L_J/N,A_1^2/N,seconds", flush=True)
    for e in range(args.min_exp, args.max_exp + 1):
        n = 1 << e
        vals = one(n)
        print(n, *vals, sep=",", flush=True)


if __name__ == "__main__":
    main()
