#!/usr/bin/env python3
"""High-precision finite probe of the low-frequency Dirichlet Gram evaluation norm."""

from __future__ import annotations

import argparse
import mpmath as mp


def evaluation_constant(n: int, delta: mp.mpf) -> mp.mpf:
    x = [mp.log(k) for k in range(1, n + 1)]
    gram = mp.matrix(n)
    for i in range(n):
        for j in range(n):
            z = x[i] - x[j]
            gram[i, j] = 2 * delta if z == 0 else 2 * mp.sin(delta * z) / z
    one = mp.matrix([1] * n)
    return (one.T * mp.lu_solve(gram, one))[0]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dps", type=int, default=180)
    parser.add_argument("--delta", type=str, default="1")
    parser.add_argument("sizes", nargs="*", type=int,
                        default=[8, 12, 16, 20, 24, 28, 32])
    args = parser.parse_args()
    mp.mp.dps = args.dps
    delta = mp.mpf(args.delta)
    for n in args.sizes:
        value = evaluation_constant(n, delta)
        print(f"N={n} Q={mp.nstr(value, 20)} Q/N={mp.nstr(value/n, 14)}")


if __name__ == "__main__":
    main()
