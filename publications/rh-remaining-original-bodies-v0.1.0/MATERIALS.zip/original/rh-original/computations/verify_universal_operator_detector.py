#!/usr/bin/env python3
"""Exact check of the universal Euler--beta representation V_m=C_m^{-1}D_m H_m."""

import argparse

import sympy as sp


def verify(m: int) -> None:
    u, s = sp.symbols("u s")
    H = u**2 * (1 - u) ** (3 * m + 1)
    differential = H
    for c in [-1] + [2 * j + 1 for j in range(1, m)]:
        differential = sp.expand(-u * sp.diff(differential, u) + c * differential)

    C = (3 * m + 4) * sp.prod(3 * m + 2 - 2 * j for j in range(1, m))
    V = sp.expand(differential / C)

    quotient = sp.cancel(V / (u**2 * (1 - u) ** (2 * m + 1)))
    assert sp.Poly(quotient, u).degree() == m
    assert sp.integrate(V, (u, 0, 1)) == 0
    assert all(sp.Poly(V, u).coeff_monomial(u**k) == 0 for k in range(1, 2 * m + 1, 2))

    positive_factor = H
    for j in range(1, m):
        positive_factor = sp.expand(-u * sp.diff(positive_factor, u) + (2 * j + 1) * positive_factor)
        factor_poly = sp.Poly(
            sp.cancel(positive_factor / (u**2 * (1 - u) ** (3 * m + 1 - j))), u
        )
        assert all(coef > 0 for coef in factor_poly.all_coeffs())

    mellin = sp.factor(
        (s - 1)
        * sp.prod(s + 2 * j + 1 for j in range(1, m))
        * sp.beta(s + 2, 3 * m + 2)
        / C
    )
    expected = sp.factor(
        sp.factorial(3 * m + 1)
        * (s - 1)
        / (
            C
            * sp.prod(s + 2 * j for j in range(1, m + 1))
            * sp.prod(s + k for k in range(2 * m + 1, 3 * m + 4))
        )
    )
    assert sp.simplify(sp.expand_func(mellin) - expected) == 0
    print(f"m={m}: operator, moments, and Mellin denominator OK")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("-M", type=int, default=10)
    args = parser.parse_args()
    for m in range(1, args.M + 1):
        verify(m)


if __name__ == "__main__":
    main()
