"""Arb certificate for positivity through an initial part of the n=2 band.

At a=179/500 the only active prime shift is d=log(2).  On each parity
half-sector it is +/- p J on the edge collar, p=log(2)/sqrt(2), where J is
reflection x -> d-x.  Finite Yukawa lower models and Schur complements prove
both sectors positive.  Domain monotonicity then covers every smaller scale.

Run:
    uv run --with python-flint python computations/verify_first_prime_band_gap.py
"""

from flint import arb, ctx

ctx.dps = 100
A = arb(9) / 25
DLOG = arb(2).log()
P = DLOG / arb(2).sqrt()
PI = arb.pi()
Q = arb(1) / 4
C = Q.digamma() - PI.log()
K = 20
K_ODD = 5
N = 200


def isolate_even(c, mode):
    lo = arb(0) if mode == 0 else arb(mode) * PI
    hi = (arb(mode) + arb(1) / 2) * PI - arb("1e-30")
    for _ in range(260):
        mid = (lo + hi) / 2
        fm = mid * arb.tan(mid) - c * A
        if fm < 0:
            lo = mid
        elif fm > 0:
            hi = mid
        else:
            raise ArithmeticError("even root isolation precision")
    return lo.union(hi) / A


def isolate_odd(c, mode):
    lo = (arb(mode) + arb(1) / 2) * PI + arb("1e-30")
    hi = (arb(mode) + 1) * PI - arb("1e-30")
    for _ in range(260):
        mid = (lo + hi) / 2
        fm = mid / arb.tan(mid) + c * A
        if fm > 0:
            lo = mid
        elif fm < 0:
            hi = mid
        else:
            raise ArithmeticError("odd root isolation precision")
    return lo.union(hi) / A


def ell(b, mu):
    return mu**2 / (b * (4 * b**2 + mu**2))


def sin_over(k, x):
    return x if k.contains(0) else arb.sin(k * x) / k


def cos_difference_over(k, lo, hi):
    return arb(0) if k.contains(0) else (arb.cos(k * lo) - arb.cos(k * hi)) / k


def cc(mu, nu, lo, hi, diagonal=False):
    if diagonal:
        return (hi-lo)/2 + (arb.sin(2*mu*hi)-arb.sin(2*mu*lo))/(4*mu)
    return ((arb.sin((mu-nu)*hi)-arb.sin((mu-nu)*lo))/(2*(mu-nu))
            +(arb.sin((mu+nu)*hi)-arb.sin((mu+nu)*lo))/(2*(mu+nu)))


def ss(mu, nu, lo, hi, diagonal=False):
    if diagonal:
        return (hi-lo)/2 - (arb.sin(2*mu*hi)-arb.sin(2*mu*lo))/(4*mu)
    return ((arb.sin((mu-nu)*hi)-arb.sin((mu-nu)*lo))/(2*(mu-nu))
            -(arb.sin((mu+nu)*hi)-arb.sin((mu+nu)*lo))/(2*(mu+nu)))


def sc(mu, nu, lo, hi):
    return (cos_difference_over(mu+nu, lo, hi)
            + cos_difference_over(mu-nu, lo, hi))/2


def sin_hyp(mu, lo, hi, cosh_kind):
    q=arb(1)/2
    def prim(x):
        if cosh_kind:
            return 2*(q*arb.sin(mu*x)*arb.sinh(q*x)-mu*arb.cos(mu*x)*arb.cosh(q*x))/(q*q+mu*mu)
        return 2*(q*arb.sin(mu*x)*arb.cosh(q*x)-mu*arb.cos(mu*x)*arb.sinh(q*x))/(q*q+mu*mu)
    return prim(hi)-prim(lo)


def cos_hyp(mu, lo, hi, cosh_kind):
    q=arb(1)/2
    def prim(x):
        if cosh_kind:
            return 2*(q*arb.cos(mu*x)*arb.sinh(q*x)+mu*arb.sin(mu*x)*arb.cosh(q*x))/(q*q+mu*mu)
        return 2*(q*arb.cos(mu*x)*arb.cosh(q*x)+mu*arb.sin(mu*x)*arb.sinh(q*x))/(q*q+mu*mu)
    return prim(hi)-prim(lo)


def ldl_positive(S):
    n=len(S); L=[[arb(0) for _ in range(n)] for _ in range(n)]; piv=[]
    for i in range(n):
        d=S[i][i]-sum(L[i][k]**2*piv[k] for k in range(i))
        assert d.lower()>0, (i,d)
        piv.append(d);L[i][i]=arb(1)
        for j in range(i+1,n):
            v=S[j][i]-sum(L[j][k]*L[i][k]*piv[k] for k in range(i))
            L[j][i]=v/d
    return min(piv,key=lambda z:float(z.mid()))


def yukawa_data(parity):
    alpha=C; vec=[]
    retained = K if parity == "even" else K_ODD
    isolate=isolate_even if parity=="even" else isolate_odd
    for n in range(N):
        b=arb(n)+Q;c=2*b
        mus=[isolate(c,j) for j in range(3 if n<retained else 1)]
        es=[ell(b,mu) for mu in mus]
        alpha += es[2] if n<retained else es[0]
        if n<retained:
            for j in (0,1):
                mu=mus[j]
                norm=(A/2 + arb.sin(2*mu*A)/(4*mu)) if parity=="even" else (A/2-arb.sin(2*mu*A)/(4*mu))
                vec.append((mu,(es[2]-es[j]).sqrt()/norm.sqrt()))
    return alpha,vec


def even_certificate():
    alpha,v=yukawa_data("even")
    assert (alpha-P).lower()>0
    # Exact shift is -P*J.  On the invariant collar J^2=I, hence
    # (alpha I-PJ)^-1=(alpha I+PJ)/(alpha^2-P^2).
    lo=DLOG-A; q0=1/alpha; qd=alpha/(alpha**2-P**2); qr=P/(alpha**2-P**2); dq=qd-q0
    n=len(v); H=[[arb(0) for _ in range(n)] for _ in range(n)]; z=[]
    def uc(mu,l,h): return cos_hyp(mu,l,h,True)
    def reflected_cos(mu,nu,diagonal):
        return arb.cos(nu*DLOG)*cc(mu,nu,lo,A,diagonal)+arb.sin(nu*DLOG)*sc(nu,mu,lo,A)
    def reflected_u_cos(mu):
        return (arb.cosh(DLOG/2)*cos_hyp(mu,lo,A,True)
                -arb.sinh(DLOG/2)*cos_hyp(mu,lo,A,False))
    for i,(mu,wi) in enumerate(v):
        z.append(wi*(q0*uc(mu,0,A)+dq*uc(mu,lo,A)+qr*reflected_u_cos(mu)))
        for j in range(i+1):
            nu,wj=v[j]
            val=wi*wj*(q0*cc(mu,nu,0,A,i==j)+dq*cc(mu,nu,lo,A,i==j)+qr*reflected_cos(mu,nu,i==j))
            H[i][j]=H[j][i]=val
    # u=2 cosh(x/2)
    uref=2*((arb.sinh(A-DLOG/2)-arb.sinh(lo-DLOG/2))+(A-lo)*arb.cosh(DLOG/2))
    uq=q0*2*(A+arb.sinh(A))+dq*2*((A-lo)+arb.sinh(A)-arb.sinh(lo))+qr*uref
    S=[[((arb(1) if i==j else arb(0))-H[i][j]+z[i]*z[j]/(1+uq)) for j in range(n)] for i in range(n)]
    return alpha,ldl_positive(S)


def odd_certificate():
    alpha,v=yukawa_data("odd")
    # First certify the operator before the negative odd pole at level gamma.
    # The pole is then removed by the elementary norm bound ||2sinh(x/2)||^2.
    gamma=arb(1)/50
    base=alpha-gamma
    assert (base-P).lower()>0
    rows=[("sin",mu,w) for mu,w in v]
    lo=DLOG-A;q0=1/base;qd=base/(base**2-P**2);qr=-P/(base**2-P**2);dq=qd-q0

    def inner(r,s,l,h,diag=False):
        kr,mr,wr=r;ks,ms,ws=s
        if kr=="sin" and ks=="sin": z=ss(mr,ms,l,h,diag)
        elif kr=="sin": z=sin_hyp(mr,l,h,False)
        elif ks=="sin": z=sin_hyp(ms,l,h,False)
        else: z=2*(arb.sinh(h)-arb.sinh(l)-(h-l))
        return wr*ws*z

    def reflected(r,s,diagonal=False):
        kr,mr,wr=r;ks,ms,ws=s
        if kr=="sin" and ks=="sin":
            z=arb.sin(ms*DLOG)*sc(mr,ms,lo,A)-arb.cos(ms*DLOG)*ss(mr,ms,lo,A,diagonal)
        elif kr=="sin" and ks=="sinh":
            z=2*(arb.sinh(DLOG/2)*sin_hyp(mr,lo,A,True)/2-arb.cosh(DLOG/2)*sin_hyp(mr,lo,A,False)/2)
        elif kr=="sinh" and ks=="sin":
            z=(arb.sin(ms*DLOG)*cos_hyp(ms,lo,A,False)
               -arb.cos(ms*DLOG)*sin_hyp(ms,lo,A,False))
        else:
            z=2*((arb.sinh(A-DLOG/2)-arb.sinh(lo-DLOG/2))-(A-lo)*arb.cosh(DLOG/2))
        return wr*ws*z

    n=len(rows);S=[[arb(0) for _ in range(n)] for _ in range(n)]
    for i in range(n):
        for j in range(i+1):
            h=q0*inner(rows[i],rows[j],0,A,i==j)+dq*inner(rows[i],rows[j],lo,A,i==j)+qr*reflected(rows[i],rows[j],i==j)
            S[i][j]=S[j][i]=(arb(1) if i==j else arb(0))-h
    pivot=ldl_positive(S)
    pole_norm=2*(arb.sinh(A)-A)
    gap=gamma-pole_norm
    assert gap.lower()>0
    return alpha,pivot,gap


if __name__ == "__main__":
    ae,pe=even_certificate()
    ao,po,go=odd_certificate()
    eps=2*A-DLOG
    print(f"a1={A}")
    print(f"epsilon0={eps}")
    print(f"prime_coefficient={P}")
    print(f"even_alpha={ae}")
    print(f"even_min_LDL_pivot={pe}")
    print(f"odd_alpha={ao}")
    print(f"odd_min_LDL_pivot={po}")
    print(f"odd_operator_gap={go}")
    print("certified_positive=True")
