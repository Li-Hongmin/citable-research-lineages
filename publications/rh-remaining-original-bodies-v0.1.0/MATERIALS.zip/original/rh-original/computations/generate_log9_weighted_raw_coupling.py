"""Generate the mode-weighted raw P-Q coupling at a=log(3).

Fixed data: R=280, N=500.  No parameter scan.  We expose Q modes
R,...,M-1 and bound the remaining Q tail by its first diagonal value.
"""
from fractions import Fraction
import sys
import numpy as np
from scipy.special import digamma

PAR = sys.argv[1] if len(sys.argv) > 1 else "-"
M = int(sys.argv[2]) if len(sys.argv) > 2 else 560
R, N = 280, 500
assert PAR in {"+", "-"} and M > R

a = np.log(3.0)
pi = np.pi
eps = 1 if PAR == "+" else -1

def rate(k):
    return float(k[0]) + 1j * float(k[1]) * pi / a

def iexp(k, lo, hi):
    z = rate(k)
    return hi-lo if z == 0 else (np.exp(z*hi)-np.exp(z*lo))/z

def inner(r1, r2, lo, hi):
    s = 0j
    for c1,k1 in r1:
        for c2,k2 in r2:
            k = (k1[0]+k2[0], -k1[1]+k2[1])
            s += np.conjugate(c1)*c2*iexp(k,lo,hi)
    return s.real

def basis(k):
    if PAR == "+":
        if k == 0:
            return [(1/np.sqrt(a),(Fraction(0),Fraction(0)))]
        c = np.sqrt(2/a)/2
        return [(c,(Fraction(0),Fraction(k))),(c,(Fraction(0),Fraction(-k)))]
    q=Fraction(2*k+1,2); c=np.sqrt(2/a)/2
    return [(-1j*c,(Fraction(0),q)),(1j*c,(Fraction(0),-q))]

def transform(rep, kind, d):
    out=[]
    for c,k in rep:
        z=rate(k)
        if kind == "ref": out.append((c*np.exp(z*d),(-k[0],-k[1])))
        elif kind == "plus": out.append((c*np.exp(z*d),k))
        else: out.append((c*np.exp(-z*d),k))
    return out

def rankrep(n):
    ck=Fraction(4*n+1,2); c=float(ck); em=np.exp(-c*a)
    if PAR == "+":
        den=np.sqrt(1-em*em)
        return [(em/den,(ck,Fraction(0))),(em/den,(-ck,Fraction(0)))]
    den=np.sqrt(1+em*em)
    return [(em/den,(ck,Fraction(0))),(-em/den,(-ck,Fraction(0)))]

def polar():
    return [(1.0,(Fraction(1,2),Fraction(0))),
            (1.0 if PAR == "+" else -1.0,(Fraction(-1,2),Fraction(0)))]

d2,d3=np.log(2.0),np.log(3.0)
d4,d5,d7,d8=2*d2,np.log(5.0),np.log(7.0),3*d2
aa={2:d2/np.sqrt(2),3:d3/np.sqrt(3),4:d2/2,
    5:d5/np.sqrt(5),7:d7/np.sqrt(7),8:d2/np.sqrt(8)}
terms=[(-eps*aa[2],"ref",d2,0,d2),(-aa[2],"plus",d2,0,a-d2),
       (-aa[2],"minus",d2,d2,a)]
for n,d in [(3,d3),(4,d4),(5,d5),(7,d7),(8,d8)]:
    terms.append((-eps*aa[n],"ref",d,d-a,a))

bp=[basis(k) for k in range(R)]
bq=[basis(k) for k in range(R,M)]
sg=np.ones(N+1); sg[-1]=1 if PAR == "+" else -1

def basis_rank_overlap(rep,n):
    """Stable <basis, normalized boundary exponential rank vector>."""
    c=2*n+.5; em=np.exp(-c*a)
    den=np.sqrt(1-em*em) if PAR=="+" else np.sqrt(1+em*em)
    sign=1.0 if PAR=="+" else -1.0
    ans=0j
    for cb,k in rep:
        w=float(k[1])*pi/a
        right=(np.exp(-1j*w*a)-em)/(c-1j*w)
        left=em*(1-np.exp(-(c+1j*w)*a))/(c+1j*w)
        ans += np.conjugate(cb)*(right+sign*left)/den
    return ans.real

def rank_gram(left):
    out=np.empty((len(left),N+1))
    for i,x in enumerate(left):
        for n in range(N): out[i,n]=basis_rank_overlap(x,n)
        out[i,N]=inner(x,polar(),0,a)
    return out

hp=rank_gram(bp)
hq=rank_gram(bq)
vpq=np.zeros((R,M-R))
for coeff,kind,d,lo,hi in terms:
    tq=[transform(x,kind,d) for x in bq]
    vpq += coeff*np.array([[inner(x,y,lo,hi) for y in tq] for x in bp])
vpq += (hp*sg)@hq.T

tag="even" if PAR=="+" else "odd"
q=np.arange(R,M,dtype=float) if PAR=="+" else np.arange(R,M,dtype=float)+0.5
dq=np.real(digamma(.25+.5j*q*pi/a))-np.log(pi)
rho=2.677899 + (2*(np.sinh(a)-a) if PAR=="-" else 0.0)
den=dq-rho
assert np.all(den>0)
if M==1000:
    np.savez(f'scratch/log9_{tag}_R280_N500_q280_1000_raw_v_float.npz',v=vpq,den=den)
    print('GENERATED_LOG9_RAW_COUPLING',tag,vpq.shape)
