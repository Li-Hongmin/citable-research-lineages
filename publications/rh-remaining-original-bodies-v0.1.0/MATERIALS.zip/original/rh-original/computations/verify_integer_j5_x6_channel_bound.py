"""OMEN-only exact certificate for positivity of the x=6 fifth channel.

The channel is 36**m * (7*U_6 - (4*m+17)*W_6).  A degree-20 geometric
lower bound for the Beta expectation is converted to an exact rational
inequality.  The shifted numerator at m=n+100 has positive coefficients.
"""

import sympy as sp


m, n = sp.symbols("m n", integer=True, nonnegative=True)


def rising(x, k):
    out = sp.Integer(1)
    for j in range(k):
        out *= x + j
    return out


def main() -> None:
    K = 20
    lower = (
        1
        - sum(
            sp.Rational(1, 4)
            * sp.Rational(3, 4) ** k
            * rising(m + 3, k)
            / rising(2 * m + 3, k)
            for k in range(K + 1)
        )
        - sp.Rational(3, 4) ** (K + 1)
    )
    diff = sp.factor(lower - (4 * m + 11) / (7 * (m - 1)))
    num, den = sp.fraction(diff)
    assert den.subs(m, 100) > 0
    shifted = sp.Poly(sp.expand(num.subs(m, n + 100)), n)
    assert all(c > 0 for c in shifted.all_coeffs())
    assert diff.subs(m, 100) > 0
    print("J5_X6_CHANNEL_OK", "m>=100", "degree", shifted.degree())
    print("J5_X6_SHIFTED_NUMERATOR_COEFFS", shifted.all_coeffs())


if __name__ == "__main__":
    main()
