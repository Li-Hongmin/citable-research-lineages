"""Arb certificate for the prime-free even Yukawa endpoint gap.

The certificate keeps two Robin eigenfunctions for n=0,...,K-1,
uses scalar ground-mode bounds for K<=n<N, discards the positive tail,
and retains the positive cosh rank-one term through a finite Schur complement.

Reproduce with:

    uv run --with python-flint python \
      computations/verify_prime_free_even_yukawa_schur.py
"""

from flint import arb, ctx


ctx.dps = 100
K = 20
N = 200

a = arb(2).log() / 2
pi = arb.pi()
quarter = arb(1) / 4
C = quarter.digamma() - pi.log()


def isolate_z(c, mode):
    """Enclose z solving z*tan(z)=c*a in (mode*pi,mode*pi+pi/2)."""
    lo = arb(0) if mode == 0 else mode * pi
    hi = mode * pi + pi / 2 - arb("1e-30")
    flo = lo * arb.tan(lo) - c * a
    fhi = hi * arb.tan(hi) - c * a
    assert flo < 0 and fhi > 0, (mode, flo, fhi)
    for _ in range(260):
        mid = (lo + hi) / 2
        fm = mid * arb.tan(mid) - c * a
        if fm < 0:
            lo = mid
        elif fm > 0:
            hi = mid
        else:
            raise ArithmeticError("insufficient precision in root isolation")
    return lo.union(hi)


def ell(b, mu):
    return mu * mu / (b * (4 * b * b + mu * mu))


data = []
for n in range(N):
    b = arb(n) + quarter
    c = 2 * b
    modes = 3 if n < K else 1
    mus = [isolate_z(c, j) / a for j in range(modes)]
    es = [ell(b, mu) for mu in mus]
    data.append((mus, es))

# The fully summed modewise scalar estimate is negative.  Since
# z_{n,0}<pi/2, ell_{n,0}<pi^2/(16*a^2*b_n^3).  Bound the omitted decreasing
# tail by f(N)+integral_N^infinity f(x) dx.
crude_partial = C + sum(es[0] for _, es in data)
bn = arb(N) + quarter
crude_tail_upper = (pi * pi / (16 * a * a)) * (
    1 / (bn**3) + 1 / (2 * bn**2)
)
crude_scalar_upper = crude_partial + crude_tail_upper
assert crude_scalar_upper < arb("-1.3"), crude_scalar_upper

# For n<K, retain the first two negative corrections to ell_{n,2} I.
# For K<=n<N, use T_n >= ell_{n,0} I.  For n>=N, use T_n >= 0.
alpha = C
for n, (_, es) in enumerate(data):
    alpha += es[2] if n < K else es[0]
assert alpha > 1, alpha
delta = arb("0.0005")
beta = alpha - delta

# w_i=sqrt(ell_2-ell_j)*g_{n,j}, with ||g_{n,j}||=1.
vectors = []
for n in range(K):
    mus, es = data[n]
    for j in (0, 1):
        mu = mus[j]
        norm2 = a / 2 + arb.sin(2 * mu * a) / (4 * mu)
        weight = arb.sqrt(es[2] - es[j]) / arb.sqrt(norm2)
        vectors.append((mu, weight, es[2] - es[j]))

p = len(vectors)
G = [[arb(0) for _ in range(p)] for _ in range(p)]
r = [arb(0) for _ in range(p)]

for i, (mu, wi, di) in enumerate(vectors):
    # u=2*cosh(x/2), so the lower model is alpha*I-WW*+|u><u|.
    overlap = (
        mu * arb.sin(mu * a) * arb.cosh(a / 2)
        + arb(1) / 2 * arb.cos(mu * a) * arb.sinh(a / 2)
    ) / (mu * mu + arb(1) / 4)
    r[i] = 2 * wi * overlap
    G[i][i] = di
    for j in range(i):
        nu, wj, _ = vectors[j]
        integral = (
            arb.sin((mu - nu) * a) / (2 * (mu - nu))
            + arb.sin((mu + nu) * a) / (2 * (mu + nu))
        )
        G[i][j] = G[j][i] = wi * wj * integral

unorm2 = 2 * (a + arb.sinh(a))
S = [[arb(0) for _ in range(p)] for _ in range(p)]
for i in range(p):
    for j in range(p):
        S[i][j] = (arb(1) if i == j else arb(0)) - G[i][j] / beta
        S[i][j] += r[i] * r[j] / (beta * (beta + unorm2))

# Directed interval LDL^T.  Strictly positive pivots certify S_delta>0,
# equivalently alpha*I-WW*+|u><u| >= delta*I.
L = [[arb(0) for _ in range(p)] for _ in range(p)]
D = [arb(0) for _ in range(p)]
for i in range(p):
    pivot = S[i][i]
    for k in range(i):
        pivot -= L[i][k] * L[i][k] * D[k]
    assert pivot > 0, (i, pivot)
    D[i] = pivot
    L[i][i] = arb(1)
    for j in range(i + 1, p):
        value = S[j][i]
        for k in range(i):
            value -= L[j][k] * L[i][k] * D[k]
        L[j][i] = value / D[i]

print(f"K={K} N={N} dimension={p}")
print("crude_infinite_scalar_upper=", crude_scalar_upper)
print("alpha=", alpha)
print("certified_operator_lower_bound=", delta)
print("minimum_LDL_pivot=", min(D, key=lambda x: float(x.mid())))
print("last_LDL_pivot=", D[-1])
print("certified_positive=True")
