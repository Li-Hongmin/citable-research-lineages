#!/usr/bin/env python3
"""Finite sanity check for terminal Liouville correlations.

This is diagnostic only: it does not prove or disprove an asymptotic bound.
For N in the requested list it computes

    c_h(N) = sum_{n <= N-h} lambda(n) lambda(n+h)

by zero-padded FFT and reports the terminal-half L1 norm.  A small direct
check is included so that the correlation orientation is not hidden in FFT
conventions.
"""

from __future__ import annotations

import argparse
import numpy as np


def liouville(n: int) -> np.ndarray:
    """Return lambda(1),...,lambda(n) using a linear sieve."""
    spf = np.zeros(n + 1, dtype=np.int32)
    value = np.ones(n + 1, dtype=np.int8)
    primes: list[int] = []
    for i in range(2, n + 1):
        if spf[i] == 0:
            spf[i] = i
            primes.append(i)
        value[i] = -value[i // spf[i]]
        for p in primes:
            v = i * p
            if v > n:
                break
            spf[v] = p
            if p == spf[i]:
                break
    return value


def correlations(value: np.ndarray) -> np.ndarray:
    n = len(value) - 1
    padded = np.zeros(2 * n, dtype=np.float64)
    padded[1 : n + 1] = value[1:]
    transform = np.fft.rfft(padded)
    corr = np.fft.irfft(transform * np.conj(transform), n=2 * n)
    return np.rint(corr[:n]).astype(np.int64)


def direct_check(value: np.ndarray, corr: np.ndarray, limit: int = 256) -> bool:
    n = len(value) - 1
    for h in range(min(n, limit)):
        direct = sum(int(value[k]) * int(value[k + h]) for k in range(1, n - h + 1))
        if direct != int(corr[h]):
            return False
    return True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("sizes", nargs="*", type=int,
                        default=[2**12, 2**13, 2**14, 2**15, 2**16,
                                 2**17, 2**18, 2**19])
    args = parser.parse_args()
    for n in args.sizes:
        value = liouville(n)
        corr = correlations(value)
        checked = direct_check(value, corr)
        terminal = int(np.abs(corr[n // 2 : n]).sum())
        dyadic = []
        h = 1
        while h < n:
            block = corr[h : min(2 * h, n)]
            dyadic.append((h, abs(int(block.sum()))))
            h *= 2
        h_max, d_max = max(dyadic, key=lambda pair: pair[1])
        print(
            f"N={n} direct_check={checked} "
            f"terminal_l1={terminal} "
            f"terminal_l1/N^(3/2)={terminal / n**1.5:.8f} "
            f"max_abs_dyadic={d_max} at H={h_max} "
            f"max_abs_dyadic/N={d_max / n:.8f}"
        )


if __name__ == "__main__":
    main()
