#!/usr/bin/env python3
"""OMEN-only exact verification of the two-window shell identity."""
from fractions import Fraction
import argparse


def mobius_sieve(n):
    mu = [1] * (n + 1)
    primes, is_prime = [], [True] * (n + 1)
    mu[0] = 0
    for i in range(2, n + 1):
        if is_prime[i]:
            primes.append(i)
            mu[i] = -1
        for p in primes:
            if i * p > n:
                break
            is_prime[i * p] = False
            if i % p == 0:
                mu[i * p] = 0
                break
            mu[i * p] = -mu[i]
    return mu


def check(N, M):
    mu = mobius_sieve(M)
    D = max(2, N // 2)
    c = [Fraction((7 * d * d + 3 * d + 1) % 11, 11)
         for d in range(1, D + 1)]
    a = [Fraction(0) for _ in range(M + 1)]
    for d, cd in enumerate(c, start=1):
        for j in range(1, M // d + 1):
            a[d * j] += cd * mu[j]
    B = sum((a[n] / n for n in range(N + 1, M + 1)), Fraction(0))
    for k in range(1, N):
        rN = sum((a[n] / n for n in range(k + 1, N + 1)), Fraction(0))
        rM = sum((a[n] / n for n in range(k + 1, M + 1)), Fraction(0))
        if rM - rN != B:
            return False, (N, M, k, rM - rN, B)
    EN = sum((2 * k + 1)
              * sum((a[n] / n for n in range(k + 1, N + 1)), Fraction(0)) ** 2
              for k in range(1, N))
    EM = sum((2 * k + 1)
              * sum((a[n] / n for n in range(k + 1, M + 1)), Fraction(0)) ** 2
              for k in range(1, M))
    W = N * N - 1
    if B * B * W > 2 * (EN + EM):
        return False, (N, M, "cauchy", B * B * W, 2 * (EN + EM))
    return True, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-N", type=int, default=40)
    args = ap.parse_args()
    cases = 0
    for N in range(4, args.max_N + 1, 2):
        for mult in (2, 3, 4):
            ok, detail = check(N, mult * N)
            if not ok:
                raise SystemExit(f"FAIL {detail}")
            cases += 1
    print(f"PASSED two-window bridge: N=4..{args.max_N}, M/N in 2,3,4; cases={cases}")


if __name__ == "__main__":
    main()
