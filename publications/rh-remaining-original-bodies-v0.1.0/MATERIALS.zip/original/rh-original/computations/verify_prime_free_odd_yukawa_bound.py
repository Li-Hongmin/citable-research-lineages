"""Certified lower bound for the prime-free odd Weil operator.

Run:
    uv run --with python-flint python \
      computations/verify_prime_free_odd_yukawa_bound.py

The certificate avoids numerical root finding.  For each Yukawa summand it
checks a decimal lower bound for the first Dirichlet--Robin frequency.
"""

from flint import arb, ctx


ctx.dps = 80

A = arb.log(arb(2)) / 2
C_INF = (arb(1) / 4).digamma() - arb.log(arb.pi())

# Strict lower bounds for the unique root mu_n in
# (pi/(2a), pi/a) of mu*cot(mu*a) = -2(n+1/4).
MU_LOWER = (
    "4.829994",
    "5.721068",
    "6.318106",
    "6.745143",
    "7.064005",
    "7.309939",
    "7.504615",
    "7.662065",
    "7.791735",
    "7.900191",
    "7.992122",
    "8.070956",
    "8.139251",
    "8.198950",
    "8.251553",
)


def strictly_positive(x: arb) -> bool:
    return x.lower() > 0


def strictly_negative(x: arb) -> bool:
    return x.upper() < 0


lower_sum = C_INF
root_checks = []
left_endpoint = arb.pi() / (2 * A)
right_endpoint = arb.pi() / A

for n, mu_text in enumerate(MU_LOWER):
    b = arb(n) + arb(1) / 4
    c = 2 * b
    mu = arb(mu_text)
    root_function = mu / (mu * A).tan() + c

    # On (pi/(2a), pi/a),
    # f'(mu)=cot(mu*a)-a*mu*csc(mu*a)^2 < 0.
    derivative = 1 / (mu * A).tan() - A * mu / (mu * A).sin() ** 2

    assert (mu - left_endpoint).lower() > 0
    assert (right_endpoint - mu).lower() > 0
    assert strictly_positive(root_function)
    assert strictly_negative(derivative)

    # ell_n(mu)=b^{-1} mu^2/(mu^2+c^2) is increasing for mu>0.
    summand_lower = mu**2 / (b * (mu**2 + c**2))
    lower_sum += summand_lower
    root_checks.append((n, mu_text, root_function, summand_lower))

# A^- = M^- - 2 |s><s| and
# 2 ||s||^2_{L^2(-a,a)} = 2(sinh(a)-a).
polar_norm = 2 * (A.sinh() - A)
odd_lower_bound = lower_sum - polar_norm

for n, mu_text, root_function, summand_lower in root_checks:
    print(
        f"n={n:02d} mu_lower={mu_text} "
        f"f(mu_lower)={root_function} ell_lower={summand_lower}"
    )

print(f"a={A}")
print(f"C_inf={C_INF}")
print(f"M_odd_lower={lower_sum}")
print(f"polar_norm_upper={polar_norm}")
print(f"A_odd_lower={odd_lower_bound}")
print(f"certified_positive={strictly_positive(odd_lower_bound)}")

assert strictly_positive(odd_lower_bound)
