#!/usr/bin/env python3
"""Rigorous full-line certificate for the rationally damped Q test cell.

The finite bands are enclosed with Arb.  Beyond |t-tau| = U, the script uses
the elementary Euler--Maclaurin consequence

    |Q(1/2+it)| <= 8*sqrt(|t|)*log(2*|t|),  |t| >= 1000,

proved in note 050.  Together with the rational damping factor this gives an
explicit integrable u^{-3} log^2(u) majorant for both infinite tails.
"""

from __future__ import annotations

from decimal import Decimal, getcontext

from flint import acb, arb, ctx

from verify_q_rational_damping_core_upper import finite_upper
from verify_q_reverse_poisson_failure import q_value


def main() -> None:
    ctx.dps = 30
    getcontext().prec = 50

    a_decimal = Decimal("0.0625")
    tau_decimal = Decimal("540.375")
    damping_decimal = Decimal("1")
    bands = (
        (Decimal("0"), Decimal("20"), Decimal("0.0001")),
        (Decimal("20"), Decimal("50"), Decimal("0.001")),
        (Decimal("50"), Decimal("100"), Decimal("0.005")),
        (Decimal("100"), Decimal("200"), Decimal("0.01")),
        (Decimal("200"), Decimal("400"), Decimal("0.02")),
        (Decimal("400"), Decimal("800"), Decimal("0.05")),
        (Decimal("800"), Decimal("1600"), Decimal("0.1")),
    )

    finite_total = arb(0)
    interval_count = 0
    for inner, outer, step in bands:
        upper, count = finite_upper(
            a_decimal,
            tau_decimal,
            damping_decimal,
            inner,
            outer,
            step,
        )
        finite_total += upper
        interval_count += count
        print(
            f"band {inner} <= |t-tau| <= {outer}, step={step}, "
            f"upper={upper}"
        )

    a = arb(str(a_decimal))
    tau = arb(str(tau_decimal))
    damping = arb(str(damping_decimal))
    cutoff = arb("1600")
    assert cutoff - tau >= arb("1000")
    beta = 1 + tau / cutoff
    logarithm = (2 * beta * cutoff).log()
    analytic_tail_upper = (
        64
        * a
        / arb.pi()
        * (a + damping) ** 2
        * beta
        / cutoff**2
        * (logarithm**2 + logarithm + arb("0.5"))
    ).upper()

    center = q_value(acb(arb("0.5625"), tau))
    target_lower = (5 * abs(center) ** 2).lower()
    full_upper = (finite_total + analytic_tail_upper).upper()
    margin_lower = (target_lower - full_upper).lower()

    print("finite intervals =", interval_count)
    print("finite total upper =", finite_total.upper())
    print("analytic infinite-tail upper =", analytic_tail_upper)
    print("full integral upper =", full_upper)
    print("5 * |Q(center)|^2 lower =", target_lower)
    print("strict margin lower =", margin_lower)
    print("proved full-line rational damping certificate =", full_upper < target_lower)
    assert full_upper < target_lower


if __name__ == "__main__":
    main()
