#!/usr/bin/env python3
"""Finite exact check for the absolute lcm-incidence local factors.

For u(n)=|a(n)|, where u(p)=sqrt(2), u(p^2)=1 and u(p^k)=0 for k>=3,
the absolute lcm layer b(n)=sum_[d,e]=n u(d)u(e) is multiplicative.
This script verifies the prime-power formulas through a small range using
exact pairs (r+s*sqrt(2)).  It is a certificate for the local algebra only,
not a numerical proof of RH.
"""

from __future__ import annotations

import math


Pair = tuple[int, int]


def add(x: Pair, y: Pair) -> Pair:
    return x[0] + y[0], x[1] + y[1]


def mul(x: Pair, y: Pair) -> Pair:
    return x[0] * y[0] + 2 * x[1] * y[1], x[0] * y[1] + x[1] * y[0]


def abs_weight_prime_power(k: int) -> Pair:
    if k == 0:
        return (1, 0)
    if k == 1:
        return (0, 1)
    if k == 2:
        return (1, 0)
    return (0, 0)


def factorization(n: int) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    p = 2
    while p * p <= n:
        if n % p == 0:
            k = 0
            while n % p == 0:
                n //= p
                k += 1
            out.append((p, k))
        p += 1
    if n > 1:
        out.append((n, 1))
    return out


def u(n: int) -> Pair:
    value = (1, 0)
    for _, k in factorization(n):
        value = mul(value, abs_weight_prime_power(k))
    return value


def main(limit: int = 300) -> None:
    got = [(0, 0)] * (limit + 1)
    for d in range(1, limit + 1):
        for e in range(1, limit + 1):
            ell = math.lcm(d, e)
            if ell <= limit:
                got[ell] = add(got[ell], mul(u(d), u(e)))

    expected_local = {
        0: (1, 0),
        1: (2, 2),  # 2 + 2*sqrt(2)
        2: (3, 2),  # 3 + 2*sqrt(2)
    }
    for p in [q for q in range(2, limit + 1) if all(q % r for r in range(2, math.isqrt(q) + 1))]:
        for k, expected in expected_local.items():
            n = p**k
            if n <= limit and got[n] != expected:
                raise AssertionError((p, k, got[n], expected))
        for k in range(3, 8):
            n = p**k
            if n <= limit and got[n] != (0, 0):
                raise AssertionError((p, k, got[n], (0, 0)))

    # Multiplicativity of the lcm layer on coprime inputs.
    for m in range(1, min(limit, 80) + 1):
        for n in range(1, min(limit // m, 80) + 1):
            if math.gcd(m, n) == 1 and got[m * n] != mul(got[m], got[n]):
                raise AssertionError((m, n, got[m * n], mul(got[m], got[n])))

    print(f"absolute_lcm_local_factors=ok through n={limit}")
    print("b(p), b(p^2) = (2+2sqrt2), (3+2sqrt2)")
    print("Euler factor = (1+(1+sqrt2)*p^(-s))^2")


if __name__ == "__main__":
    main()
