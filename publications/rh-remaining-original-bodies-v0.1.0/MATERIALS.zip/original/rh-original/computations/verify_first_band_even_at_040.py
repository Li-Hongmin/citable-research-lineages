"""Arb certificate for A_a^+ >= 1/1000000 on 0<a<=2/5.

The n=2 prime shift is retained as the exact edge-collar reflection.  For
the first 60 Yukawa summands we retain two low-mode deficits, use 400
positive summands in the scalar floor, and discard the remaining positive
tail.

Run:
    uv run --with python-flint python computations/verify_first_band_even_at_040.py
"""

# This file is intentionally kept formula-for-formula parallel to the
# independently certified a=9/25 script; only the rational endpoint,
# truncations, and requested gap differ.

source_path = __file__.replace(
    "verify_first_band_even_at_040.py", "verify_first_band_even_at_036.py"
)
with open(source_path, encoding="utf-8") as handle:
    source = handle.read()

replacements = {
    "K, N = 20, 200": "K, N = 60, 400",
    "a = arb(9) / 25": "a = arb(2) / 5",
    "delta = arb(1) / 20000": "delta = arb(1) / 1000000",
}
for old, new in replacements.items():
    assert source.count(old) == 1, (old, source.count(old))
    source = source.replace(old, new)

exec(compile(source, __file__, "exec"))
