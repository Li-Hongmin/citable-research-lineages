"""Grid-free Arb certificate for a=log(8)/2; usage: uv run --with python-flint python FILE [bits]."""
from fractions import Fraction as F
import sys
from flint import arb, ctx
ctx.prec=int(sys.argv[1]) if len(sys.argv)>1 else 256

# Exact Q-linear combinations of log(2),log(3),log(5),log(7).
PR=(2,3,5,7); Z=(F(0),)*4
def V(*q):return tuple(F(x) for x in q)
def add(x,y):return tuple(a+b for a,b in zip(x,y))
def neg(x):return tuple(-a for a in x)
def sub(x,y):return add(x,neg(y))
def mul(c,x):return tuple(F(c)*a for a in x)
def av(x):
 s=arb(0)
 for c,p in zip(x,PR):s+=arb(c.numerator)/c.denominator*arb(p).log()
 return s
def lt(x,y):return av(x)<av(y)
def inside(x,l,h):return lt(l,x) and lt(x,h)

L2=V(1,0,0,0);L3=V(0,1,0,0);L4=mul(2,L2);L5=V(0,0,1,0);L7=V(0,0,0,1)
A=mul(F(3,2),L2) # log(8)/2
DN={2:L2,3:L3,4:L4,5:L5,7:L7}
# (weight name, affine sign, constant, support lo, hi, label)
E=[('x',1,L2,Z,sub(A,L2),'S+'),('x',1,neg(L2),L2,A,'S-')]
for n,k in ((2,'x'),(3,'y'),(4,'z'),(5,'w'),(7,'v')):
 d=DN[n];lo=Z if lt(d,A) else sub(d,A);hi=d if lt(d,A) else A
 E.append((k,-1,d,lo,hi,'J%d'%n))
def image(e,t):return add(mul(e[1],t),e[2])
def active(t):return [e for e in E if inside(t,e[3],e[4])]

# Degree breakpoints and all inverse images under active affine maps.
base={Z,A}
for e in E:base|={e[3],e[4]}
cuts=set(base)
for e in E:
 for b in base:
  t=mul(e[1],sub(b,e[2]))
  if t in (Z,A) or (lt(Z,t) and lt(t,A)):cuts.add(t)
cuts=sorted(cuts,key=lambda q:float(av(q).mid()))
for l,h in zip(cuts,cuts[1:]):assert lt(l,h),(av(l),av(h))

x=arb(2).log()/arb(2).sqrt();y=arb(3).log()/arb(3).sqrt();z=arb(2).log()/2
w=arb(5).log()/arb(5).sqrt();v=arb(7).log()/arb(7).sqrt()
W={'x':x,'y':y,'z':z,'w':w,'v':v}; names=tuple(W)
def lindeg(t):
 q={k:0 for k in names}
 for e in active(t):q[e[0]]+=1
 return q
def padd(p,k,q):
 for j,c in q.items():
  ij=tuple(sorted((k,j)));p[ij]=p.get(ij,0)+c
def pval(p):return sum((arb(c)*W[i]*W[j] for (i,j),c in p.items()),arb(0))

rows=[]
for l,h in zip(cuts,cuts[1:]):
 m=mul(F(1,2),add(l,h));p={};detail=[]
 for e in active(m):
  q=lindeg(image(e,m));padd(p,e[0],q);detail.append((e[5],q))
 rows.append((l,h,pval(p),p,detail))
best=max(rows,key=lambda r:float(r[2].mid()));poly=best[3];sup=pval(poly)
for l,h,q,p,d in rows:assert p==poly or q<sup,(av(l),av(h),q,sup,p)
att=[r for r in rows if r[3]==poly]

print('bits',ctx.prec,'cells',len(rows),'active_n',[2,3,4,5,7])
print('sup_D2',sup);print('norm_bound',sup.sqrt());print('attaining_cells',len(att))
for l,h,q,p,d in att:print('MAX',av(l),av(h),'poly',p,'detail',d)
print('all_cells')
for l,h,q,p,d in rows:print(av(l),av(h),q,'poly',p,'detail',d)
