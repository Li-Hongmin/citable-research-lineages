#!/usr/bin/env python3
"""Exact Fraction check for note 367's L=3 h-dual closed form."""

from __future__ import annotations

from fractions import Fraction
from math import comb, factorial
from random import Random


def stirling2(n: int, k: int) -> int:
    row = [0] * (k + 1)
    row[0] = 1
    for i in range(1, n + 1):
        new = [0] * (k + 1)
        for j in range(1, min(i, k) + 1):
            new[j] = j * row[j] + row[j - 1]
        row = new
    return row[k] if 0 <= k <= n else 0


def F4(a: int, t: int) -> int:
    if t == 0:
        return 4**a - 4 * 3**a + 6 * 2**a - 4
    return 2 ** (a + t) + 3**a + 3**t - 5 * (2**a + 2**t) + 10


def w(m: int, q: int) -> Fraction:
    D = 3 * m + 3
    c = Fraction(
        factorial(2 * m - q) * factorial(q),
        2 ** (m - q + 2)
        * factorial(m - q + 1)
        * factorial(q - 2)
        * comb(D, 2),
    )
    return c * comb(D, q)


def Kcoef(m: int, q: int) -> Fraction:
    D = 3 * m + 3
    if q == 1:
        return -3 * w(m, 2)
    if q <= m:
        return w(m, q) * (D - q) - w(m, q + 1) * (q + 2)
    return w(m, q) * (D - m - 1)


def K(m: int, z: Fraction) -> Fraction:
    return sum((Kcoef(m, q) * z**q for q in range(1, m + 2)), Fraction(0))


def h_direct(m: int, y: Fraction) -> Fraction:
    D, d = 3 * m + 3, 3 * m + 1
    total = Fraction(0)
    for q in range(1, m + 2):
        R = D - q - 1
        inner = sum(
            comb(R, t) * y ** (q - 1 + t) * F4(q + 1, t)
            for t in range(R + 1)
        )
        total += Kcoef(m, q) * inner
    return total


def h_closed(m: int, y: Fraction) -> Fraction:
    D = 3 * m + 3
    B1, B2, B3 = 1 + y, 1 + 2 * y, 1 + 3 * y
    return (
        B2 ** (D - 1) * (2 * K(m, 2 * y / B2) - 5 * K(m, y / B2))
        + B3 ** (D - 1) * K(m, y / B3)
        + B1 ** (D - 1)
        * (3 * K(m, 3 * y / B1) - 10 * K(m, 2 * y / B1) + 10 * K(m, y / B1))
        + 4 * K(m, 4 * y)
        - 15 * K(m, 3 * y)
        + 20 * K(m, 2 * y)
        - 10 * K(m, y)
    ) / y


def main() -> None:
    rng = Random(367)
    points = [Fraction(1), Fraction(3, 2), Fraction(7, 3), Fraction(11, 4)]
    points += [Fraction(1 + rng.randrange(1, 12), 3) for _ in range(4)]
    for m in range(1, 9):
        for y in points:
            lhs, rhs = h_direct(m, y), h_closed(m, y)
            assert lhs == rhs, (m, y, lhs, rhs)
    print("L=3 h-dual closed form: exact Fraction checks passed for m=1..8")


if __name__ == "__main__":
    main()
