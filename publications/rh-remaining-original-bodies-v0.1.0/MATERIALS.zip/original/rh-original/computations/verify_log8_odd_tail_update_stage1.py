"""Stage 1: export the exact low-rank factors for the odd tail update."""
exec(compile(open('computations/log8_odd_tail_factor_assembly.py',encoding='utf-8').read(),__file__,'exec'))

# Exact low-rank factors in the original R-dimensional Fourier core.
Bpp=PP+Ho*Ho.transpose()-hp*hp.transpose()
W=V+Ho*Got-hp*gpt
G=W-Bpp*Ht                         # P B_400 Q f_n columns
Qgram=Gtt-Ht.transpose()*Ht        # <Qf_m,Qf_n>
del PP,V,Ho,Got,hp,gpt,Gtt,W,Bpp

# Transform factors by U^T, using the exact dyadic Householders exported by
# the old N=400 contraction.  No dense 200x200 Delta is formed.
wh=[[arb(str(dat['whist_arb'][j,k])) for k in range(R)] for j in range(M)]
def left_householders(F):
    out=F
    for w in wh:
        ww=sum((z*z for z in w),arb(0))
        row=arb_mat([[sum((w[k]*out[k,j] for k in range(R)),arb(0)) for j in range(out.ncols())]])
        # Explicit rank-one update avoids constructing an R x R Householder.
        out=arb_mat([[out[k,j]-2*w[k]*row[0,j]/ww for j in range(out.ncols())] for k in range(R)])
    return out
Hb=left_householders(Ht);Gb=left_householders(G)
if '--export-update-factors' in sys.argv:
    np.savez('scratch/log8_odd_R200_tail_update_factors.npz',
             hb=np.array([[str(Hb[i,j]) for j in range(100)] for i in range(R)]),
             gb=np.array([[str(Gb[i,j]) for j in range(100)] for i in range(R)]),
             qg=np.array([[str(Qgram[i,j]) for j in range(100)] for i in range(100)]),
             mu=np.array(str(mu)))
    print('EXPORTED_UPDATE_FACTORS');raise SystemExit(0)
m=R-M
H1=arb_mat([[Hb[i,j] for j in range(100)] for i in range(M)]);H2=arb_mat([[Hb[i+M,j] for j in range(100)] for i in range(m)])
G1=arb_mat([[Gb[i,j] for j in range(100)] for i in range(M)]);G2=arb_mat([[Gb[i+M,j] for j in range(100)] for i in range(m)])
def db(Ah,Ag,Bh,Bg):return Ah*Bh.transpose()-(Ag*Bh.transpose()+Ah*Bg.transpose()+Ah*Qgram*Bh.transpose())/mu
d11=db(H1,G1,H1,G1);d12=db(H1,G1,H2,G2);d22=db(H2,G2,H2,G2)
del Hb,Gb,Ht,G,Qgram,H1,H2,G1,G2
del old,tail,BAS,tb,tf
Xold=arb_mat([[arb(str(dat['x_arb'][i,j])) for j in range(m)] for i in range(M)])
Cold=arb_mat([[arb(str(dat['c_arb'][i,j])) for j in range(m)] for i in range(m)])

# Old C >= C0-resinf.  Reproduce its dyadic Cholesky residual, then pay the
# complete infinity norm of Delta22.
import numpy as np
C0=arb(1)/2000000
Cminus=Cold-arb_mat([[C0 if i==j else arb(0) for j in range(m)] for i in range(m)])
Cmid=np.array([[float(Cminus[i,j].mid()) for j in range(m)] for i in range(m)])
Lf=np.linalg.cholesky((Cmid+Cmid.T)/2);scale=2**52
Ld=arb_mat([[arb(int(np.rint(Lf[i,j]*scale)))/scale if j<=i else arb(0) for j in range(m)] for i in range(m)])
res=Cminus-Ld*Ld.transpose();resinf=arb(0);dnorm=arb(0)
for i in range(m):
    rr=sum((abs(res[i,j]) for j in range(m)),arb(0));dd=sum((abs(d22[i,j]) for j in range(m)),arb(0))
    if rr.upper()>resinf.upper():resinf=rr
    if dd.upper()>dnorm.upper():dnorm=dd
cnew_lower=C0-resinf-dnorm
print('old_C_residual_inf',resinf);print('Delta22_inf',dnorm);print('Cnew_lower',cnew_lower)
assert cnew_lower.lower()>0

# Recover A_old from old small=A-X C^-1 X^T, then form the actual new Schur.
Yold=Cold.solve(Xold.transpose());Aold=small+Xold*Yold
Cnew=Cold+d22;Xnew=Xold+d12;Anew=Aold+d11
Ynew=Cnew.solve(Xnew.transpose());Knew=Anew-Xnew*Ynew;Knew=(Knew+Knew.transpose())/2

T=[[Knew[i,j] for j in range(M)] for i in range(M)];perm=list(range(M));pivs=[]
for k in range(M):
    p=max(range(k,M),key=lambda i:float(T[i][i].mid()))
    if p!=k:
        T[k],T[p]=T[p],T[k]
        for row in T:row[k],row[p]=row[p],row[k]
        perm[k],perm[p]=perm[p],perm[k]
    piv=T[k][k];pivs.append(piv);print('true_pivot',k,piv,'perm',perm);assert piv.lower()>0
    for i in range(k+1,M):
        for j in range(i,M):
            z=T[j][i]-T[j][k]*T[i][k]/piv;T[j][i]=z;T[i][j]=z
print('mu',mu);print('TRUE_FULL_FESHBACH_CERTIFIED')
