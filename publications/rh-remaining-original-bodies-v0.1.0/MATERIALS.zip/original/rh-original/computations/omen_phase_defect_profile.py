#!/usr/bin/env python3
"""OMEN-only finite profile of the dyadic shell phase-defect identity.

The probe samples the zero-padded Fourier polynomial on a uniform grid and
reports the signed block, absolute shell weight W, and the internal/cross-shell
defects from notes/673-exact-phase-deficit-for-dyadic-frequency-shells.md.
It is a finite diagnostic only; it is not an asymptotic estimate or RH proof.
Run it on OMEN, not on the local workstation.
"""

from __future__ import annotations

import sys

import numpy as np


def mobius(n: int) -> np.ndarray:
    value = np.zeros(n + 1, dtype=np.int8)
    value[1] = 1
    composite = np.zeros(n + 1, dtype=np.bool_)
    primes: list[int] = []
    for i in range(2, n + 1):
        if not composite[i]:
            primes.append(i)
            value[i] = -1
        for prime in primes:
            multiple = i * prime
            if multiple > n:
                break
            composite[multiple] = True
            if i % prime == 0:
                value[multiple] = 0
                break
            value[multiple] = -value[i]
    return value


def block_corr(value: np.ndarray) -> np.ndarray:
    n = len(value) - 1
    padded = np.zeros(2 * n, dtype=np.float64)
    padded[1 : n + 1] = value[1:]
    transform = np.fft.rfft(padded)
    return np.rint(
        np.fft.irfft(transform * np.conj(transform), n=2 * n)[:n]
    ).astype(np.int64)


def shell_index(distance: np.ndarray, length: int, h: int) -> np.ndarray:
    theta_h = distance.astype(np.float64) * h / length
    index = np.zeros(distance.shape, dtype=np.int32)
    mask = theta_h > 1.0
    index[mask] = np.ceil(np.log2(theta_h[mask])).astype(np.int32)
    return index


def profile(n: int) -> None:
    value = mobius(n).astype(np.float64)
    corr = block_corr(value)
    best = (0, 0, 0)
    h = 1
    while h < n:
        signed = int(corr[h : min(2 * h, n)].sum())
        candidate = (abs(signed), h, signed)
        if candidate > best:
            best = candidate
        h *= 2
    _, h, signed = best

    # L=4N resolves the product |F_N|^2 K_H by trapezoidal sampling.
    length = 4 * n
    padded = np.zeros(length, dtype=np.float64)
    padded[1 : n + 1] = value[1:]
    transform = np.fft.rfft(padded)
    power = transform.real * transform.real + transform.imag * transform.imag
    k = np.arange(len(power), dtype=np.int64)
    theta = k.astype(np.float64) / length
    denominator = np.sin(np.pi * theta)
    numerator = np.sin(np.pi * h * theta)
    phase = np.exp(2j * np.pi * (h + (h - 1) / 2.0) * theta)
    kernel = np.empty_like(phase)
    kernel[0] = h
    kernel[1:] = phase[1:] * numerator[1:] / denominator[1:]

    distance = np.minimum(k, length - k)
    keep = distance <= length // 2
    distance = distance[keep]
    power = power[keep]
    kernel = kernel.real[keep]
    multiplicity = np.full(distance.shape, 2.0)
    multiplicity[(k[keep] == 0) | (k[keep] == length // 2)] = 1.0
    shell = shell_index(distance, length, h)
    count = int(shell.max()) + 1
    signed_shell = np.bincount(
        shell, weights=multiplicity * power * kernel, minlength=count
    )
    absolute_shell = np.bincount(
        shell, weights=multiplicity * power * np.abs(kernel), minlength=count
    )
    scale = 1.0 / (n * length)
    signed_shell *= scale
    absolute_shell *= scale
    ratio = np.divide(
        signed_shell,
        absolute_shell,
        out=np.zeros_like(signed_shell),
        where=absolute_shell > 0,
    )
    R = float(signed_shell.sum())
    W = float(absolute_shell.sum())
    phase_sign = 1.0 if R >= 0 else -1.0
    internal = float(np.sum(absolute_shell * (1.0 - ratio * ratio)))
    cross = float(np.sum(absolute_shell * (ratio - phase_sign) ** 2))
    lhs = 2.0 * (W - abs(R))
    print(
        f"N={n} H={h} D/N={R:.12g} corr={signed} W={W:.12g}"
    )
    print(
        f"  lhs={lhs:.12g} internal={internal:.12g} "
        f"cross={cross:.12g} residual={lhs-internal-cross:.3e}"
    )
    for j, (w, d, r) in enumerate(zip(absolute_shell, signed_shell, ratio)):
        if w > 1e-12:
            print(f"  shell={j} Wj={w:.12g} Dj={d:.12g} rj={r:.12g}")


if __name__ == "__main__":
    sizes = [int(argument) for argument in sys.argv[1:]]
    for size in sizes or [2**16, 2**18, 2**20, 2**22]:
        profile(size)
