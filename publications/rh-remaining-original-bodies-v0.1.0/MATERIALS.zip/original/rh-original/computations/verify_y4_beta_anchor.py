#!/usr/bin/env python3
"""Exact OMEN-side check for the y=4 Euler--beta anchor.

This is a finite formula/regression check only.  The all-m proof is in
notes/548-all-m-positivity-at-the-second-two-term-scale-y4.md.
"""

from fractions import Fraction
from math import comb, factorial


def apply_theta_plus(poly, c):
    return [value * (c - degree) for degree, value in enumerate(poly)]


def normalization(m):
    value = 3 * m + 4
    for j in range(1, m):
        value *= 3 * m + 2 - 2 * j
    return value


def v_coefficients(m):
    degree = 3 * m + 3
    poly = [Fraction(0)] * (degree + 1)
    for j in range(3 * m + 2):
        poly[j + 2] = Fraction((-1) ** j * comb(3 * m + 1, j))
    for j in range(1, m):
        poly = apply_theta_plus(poly, 2 * j + 1)
    poly = apply_theta_plus(poly, -1)
    scale = normalization(m)
    return [value / scale for value in poly]


def direct_p4(m):
    poly = v_coefficients(m)
    total = Fraction(0)
    for numerator in (1, 2, 3, 4):
        u = Fraction(numerator, 4)
        total += sum(value * u**degree for degree, value in enumerate(poly))
    return total


def d_coefficient(m, r):
    degree = 3 * m + 3
    bernstein_denominator = comb(degree, 2)
    return Fraction(
        factorial(degree) * factorial(m + r - 2),
        bernstein_denominator
        * 2**r
        * factorial(r - 1)
        * factorial(m - r)
        * factorial(2 * m + r + 1),
    )


def beta_formula_p4(m):
    value = Fraction(0)
    for r in range(1, m + 1):
        beta_term = (
            3 ** (2 * m + r) * (4 * r - m - 8)
            + 2 ** (3 * m + 3) * (m + 2 * r - 2)
            + 3 ** (m - r + 2) * (5 * m + 4 * r)
        )
        value += d_coefficient(m, r) * beta_term
    return value / (4 ** (3 * m + 3) * normalization(m))


def main():
    expected_small = {
        1: Fraction(5, 14336),
        2: Fraction(3, 131072),
        3: Fraction(3053, 763363328),
        4: Fraction(149005, 137438953472),
        5: Fraction(3141453, 8486855376896),
        6: Fraction(1087790415, 6192449487634432),
        7: Fraction(1347629977073, 14773917840100556800),
        8: Fraction(46056364956615, 1033017668127734890496),
        9: Fraction(579799640866163, 28860507564070896926720),
    }
    for m in range(1, 11):
        direct = direct_p4(m)
        formula = beta_formula_p4(m)
        assert direct == formula, (m, direct, formula)
        if m in expected_small:
            assert direct == expected_small[m], (m, direct)
        assert direct > 0, (m, direct)
    print("y=4 beta formula/direct checks passed for m=1..10")


if __name__ == "__main__":
    main()
