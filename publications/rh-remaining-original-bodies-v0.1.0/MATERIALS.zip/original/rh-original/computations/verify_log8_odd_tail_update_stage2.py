"""Stage 2: assemble and export all three blocks of the odd tail update."""
from flint import arb,arb_mat,ctx
import numpy as np,sys
ctx.prec=int(sys.argv[1]) if len(sys.argv)>1 else 128
R=200;M=5;m=195
old=np.load('scratch/log8_odd_R200_N400_exact_small_map.npz');fac=np.load('scratch/log8_odd_R200_tail_update_factors.npz')
Hb=arb_mat([[arb(str(fac['hb'][i,j])) for j in range(100)] for i in range(R)])
Gb=arb_mat([[arb(str(fac['gb'][i,j])) for j in range(100)] for i in range(R)])
Q=arb_mat([[arb(str(fac['qg'][i,j])) for j in range(100)] for i in range(100)]);mu=arb(str(fac['mu']))
H1=arb_mat([[Hb[i,j] for j in range(100)] for i in range(M)]);H2=arb_mat([[Hb[i+M,j] for j in range(100)] for i in range(m)])
G1=arb_mat([[Gb[i,j] for j in range(100)] for i in range(M)]);G2=arb_mat([[Gb[i+M,j] for j in range(100)] for i in range(m)])
def db(Ah,Ag,Bh,Bg):return Ah*Bh.transpose()-(Ag*Bh.transpose()+Ah*Bg.transpose()+Ah*Q*Bh.transpose())/mu
d11=db(H1,G1,H1,G1);d12=db(H1,G1,H2,G2);d22=db(H2,G2,H2,G2)
del Hb,Gb,Q,H1,H2,G1,G2
if '--export-delta-blocks' in sys.argv:
 np.savez('scratch/log8_odd_R200_tail_delta_blocks.npz',
          d11=np.array([[str(d11[i,j]) for j in range(M)] for i in range(M)]),
          d12=np.array([[str(d12[i,j]) for j in range(m)] for i in range(M)]),
          d22=np.array([[str(d22[i,j]) for j in range(m)] for i in range(m)]))
 print('EXPORTED_DELTA_BLOCKS');raise SystemExit(0)

small=arb_mat([[arb(str(old['small_arb'][i,j])) for j in range(M)] for i in range(M)])
Xold=arb_mat([[arb(str(old['x_arb'][i,j])) for j in range(m)] for i in range(M)])
Cold=arb_mat([[arb(str(old['c_arb'][i,j])) for j in range(m)] for i in range(m)])

C0=arb(1)/2000000;Cminus=Cold-arb_mat([[C0 if i==j else arb(0) for j in range(m)] for i in range(m)])
Cmid=np.array([[float(Cminus[i,j].mid()) for j in range(m)] for i in range(m)])
Lf=np.linalg.cholesky((Cmid+Cmid.T)/2);scale=2**52
Ld=arb_mat([[arb(int(np.rint(Lf[i,j]*scale)))/scale if j<=i else arb(0) for j in range(m)] for i in range(m)])
res=Cminus-Ld*Ld.transpose();resinf=arb(0);dnorm=arb(0)
for i in range(m):
 rr=sum((abs(res[i,j]) for j in range(m)),arb(0));dd=sum((abs(d22[i,j]) for j in range(m)),arb(0))
 if rr.upper()>resinf.upper():resinf=rr
 if dd.upper()>dnorm.upper():dnorm=dd
cnew_lower=C0-resinf-dnorm
print('old_C_residual_inf',resinf);print('Delta22_inf',dnorm);print('Cnew_lower',cnew_lower);assert cnew_lower.lower()>0
Yold=Cold.solve(Xold.transpose());Aold=small+Xold*Yold
Cnew=Cold+d22;Xnew=Xold+d12;Anew=Aold+d11;Ynew=Cnew.solve(Xnew.transpose());K=Anew-Xnew*Ynew;K=(K+K.transpose())/2
T=[[K[i,j] for j in range(M)] for i in range(M)];perm=list(range(M));pivs=[]
for k in range(M):
 p=max(range(k,M),key=lambda i:float(T[i][i].mid()))
 if p!=k:
  T[k],T[p]=T[p],T[k]
  for row in T:row[k],row[p]=row[p],row[k]
  perm[k],perm[p]=perm[p],perm[k]
 piv=T[k][k];pivs.append(piv);print('true_pivot',k,piv,'perm',perm);assert piv.lower()>0
 for i in range(k+1,M):
  for j in range(i,M):z=T[j][i]-T[j][k]*T[i][k]/piv;T[j][i]=z;T[i][j]=z
print('mu',mu);print('TRUE_FULL_FESHBACH_CERTIFIED')
