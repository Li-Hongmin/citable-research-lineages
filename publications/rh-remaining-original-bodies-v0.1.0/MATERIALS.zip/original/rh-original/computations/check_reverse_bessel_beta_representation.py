#!/usr/bin/env python3
"""Exact alignment check for the reverse-Bessel Beta representation.

The q-shift formula uses ``w_q = c_q * binom(D,q)``.  An earlier audit
mistakenly compared the Beta coefficients with ``(q+1)c_q``; that is a
different sequence.  This script checks the actual q-shift weights exactly.
"""

from __future__ import annotations

from fractions import Fraction
from math import comb, factorial


def recurrence_weights(m: int) -> dict[int, Fraction]:
    D = 3 * m + 3
    c: dict[int, Fraction] = {2: Fraction(1, comb(D, 2))}
    for j in range(m - 1):
        nxt: dict[int, Fraction] = {}
        for k in range(D + 1):
            nxt[k] = (2 * j + 3 - k) * c.get(k, 0) + k * c.get(k - 1, 0)
        c = nxt
    return {k: value * comb(D, k) for k, value in c.items() if value}


def claimed_beta_coefficients(m: int) -> dict[int, Fraction]:
    """Coefficients of the claimed A_m z^2 integral, exactly."""
    D = 3 * m + 3
    B = comb(D, 2)
    A = Fraction(factorial(D), 2**m * B * factorial(m - 1) * factorial(m + 2))
    out: dict[int, Fraction] = {}
    # z^(ell+2) comes from choosing ell powers of 2z.
    for ell in range(m):
        beta = Fraction(
            factorial(2 * m - 2 - ell) * factorial(m + 2),
            factorial(3 * m + 1 - ell),
        )
        out[ell + 2] = A * comb(m - 1, ell) * 2**ell * beta
    return out


def main() -> None:
    for m in range(1, 31):
        actual = recurrence_weights(m)
        claimed = claimed_beta_coefficients(m)
        assert actual == claimed, (m, actual, claimed)
    # The formerly reported m=4 discrepancy was a comparison with (q+1)c_q.
    assert {2: Fraction(3, 7), 3: Fraction(12, 7), 4: Fraction(24, 7), 5: Fraction(24, 7)} != recurrence_weights(4)
    print("q-shift Beta alignment passed exactly for m=1..30")


if __name__ == "__main__":
    main()
