import argparse
from fractions import Fraction
from math import comb


def mobius(n: int) -> int:
    if n == 1:
        return 1
    x, parity, p = n, 0, 2
    while p * p <= x:
        if x % p == 0:
            x //= p
            parity ^= 1
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        parity ^= 1
    return -1 if parity else 1


def check(X: int, q: int, r: int) -> None:
    J = 1
    while q**J <= X:
        J += 1
    support = q**r * X
    b = [0] * (support + 1)
    for m in range(1, support + 1):
        for ell in range(r + 1):
            scale = q**ell
            if m % scale == 0 and m // scale <= X:
                b[m] += (-1)**ell * comb(r, ell) * scale * mobius(m // scale)

    # Build all reciprocal tails once.  The original verifier recomputed each
    # tail from scratch, turning a finite certificate into an unnecessary
    # quadratic Fraction workload; this suffix recurrence is identical.
    tails = [Fraction(0)] * (support + 2)
    for m in range(support, 0, -1):
        tails[m] = tails[m + 1] + Fraction(b[m], m)

    def tail(k: int) -> Fraction:
        return tails[k]

    A = sum((Fraction(mobius(n), n) for n in range(1, X + 1)), Fraction(0))
    chain = sum(
        (comb(j, r - 1) * tail(q**j) for j in range(1, J + r)),
        Fraction(0),
    )
    assert A == (-1)**r * chain

    energy = sum((2 * k - 1) * tails[k] ** 2 for k in range(1, support + 1))
    chain_energy = sum(
        (2 * q**j - 1) * tail(q**j) ** 2 for j in range(1, J + r)
    )
    c_partial = sum(
        (Fraction(comb(j, r - 1) ** 2, 2 * q**j - 1)
         for j in range(1, J + r)),
        Fraction(0),
    )
    assert A * A <= c_partial * chain_energy <= c_partial * energy


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-x", type=int, default=40)
    parser.add_argument("--max-r", type=int, default=5)
    parser.add_argument("--qs", type=int, nargs="+", default=[2, 3, 4])
    args = parser.parse_args()
    for q in args.qs:
        for r in range(1, args.max_r + 1):
            for X in range(1, args.max_x + 1):
                check(X, q, r)
            print(f"completed q={q}, r={r}, X=1..{args.max_x}", flush=True)
    print(
        f"higher-order q-adic chain verified for q={args.qs}, "
        f"r=1..{args.max_r}, X=1..{args.max_x}"
    )


if __name__ == "__main__":
    main()
