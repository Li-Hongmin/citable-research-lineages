#!/usr/bin/env python3
"""Exact fixed-floor checks for note 147's degree-21 candidate."""

import sympy as sp

u, c, s, N, r, t = sp.symbols("u c s N r t")
V = sp.expand(
    u**2 * (1 - u) ** 13
    * (11264 * u**6 + 7865 * u**5 + 1893 * u**4 - 130 * u**3
       - 178 * u**2 - 39 * u - 3)
    / sp.Integer(11264)
)
assert sp.integrate(V, (u, 0, 1)) == 0
assert all(sp.Poly(V, u).coeff_monomial(u**k) == 0 for k in (1, 3, 5, 7, 9, 11))

K = sp.factor(sum(coef / (power + s) for (power,), coef in sp.Poly(V, u).terms()))
expected = sp.Integer(11427998400) * (s - 1)
for shift in (2, 4, 6, 8, 10, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21):
    expected /= s + shift
assert sp.factor(K - expected) == 0

P = sum(
    coef * sp.summation(c**power, (c, 1, N)) / (N + r) ** power
    for (power,), coef in sp.Poly(V, u).terms()
)
Q = sp.factor((N + r) ** 21 * P / (N * (N + 1)))
degree = 19
Q_poly = sp.Poly(sp.expand(Q), r)
bernstein = []
for k in range(degree + 1):
    value = sum(
        Q_poly.coeff_monomial(r**j)
        * sp.binomial(k, j)
        / sp.binomial(degree, j)
        for j in range(k + 1)
    )
    bernstein.append(sp.factor(value))

assert all(b.subs(N, 1) == 0 for b in bernstein[:13])
assert all(b.subs(N, 1) > 0 for b in bernstein[13:])

# Exact falling-factorial positivity for integer t=N-2>=0.
for b in bernstein:
    polynomial = sp.Poly(sp.together(b.subs(N, t + 2)), t)
    current = polynomial.as_expr()
    coefficients = []
    for j in range(6):
        coefficients.append(sp.factor(current.subs(t, 0) / sp.factorial(j)))
        current = sp.expand(current.subs(t, t + 1) - current)
    assert all(value > 0 for value in coefficients)

print("degree=", sp.degree(V, u))
print("K=", K)
print("odd moments and mean: zero")
print("N=1: first 13 Bernstein coefficients zero, remaining positive")
print("N>=2: all falling-factorial Bernstein coefficients positive")
