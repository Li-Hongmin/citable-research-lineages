#!/usr/bin/env python3
"""Diagnostic check for the raw shifted-correlation square gate.

For a Liouville or Mobius sequence a(1),...,a(N), compute

    C_h = sum_{n <= N-h} a(n)a(n+h),
    E(N,H) = sum_{H < h <= min(2H,N-1)} C_h**2.

The script is diagnostic only.  It uses a zero-padded FFT and verifies the
correlation orientation by direct summation for small N.  It reports both
E/N^2 and E*H/N^2, the latter being the scale that would have to remain
subpolynomial under a proposed E << N^(2+eps) H^(-1) gate.
"""

from __future__ import annotations

import argparse
import numpy as np


def values(n: int, kind: str) -> np.ndarray:
    """Return a(1),...,a(n) for kind in {lambda,mobius}."""
    spf = np.zeros(n + 1, dtype=np.int32)
    primes: list[int] = []
    for i in range(2, n + 1):
        if spf[i] == 0:
            spf[i] = i
            primes.append(i)
        for p in primes:
            v = i * p
            if v > n:
                break
            spf[v] = p
            if p == spf[i]:
                break

    out = np.ones(n + 1, dtype=np.int8)
    if kind == "lambda":
        for i in range(2, n + 1):
            out[i] = -out[i // spf[i]]
        return out
    if kind != "mobius":
        raise ValueError("kind must be lambda or mobius")
    squarefree = np.ones(n + 1, dtype=bool)
    for p in primes:
        out[p::p] *= -1
        squarefree[p * p :: p * p] = False
    out[~squarefree] = 0
    return out


def correlations(a: np.ndarray) -> np.ndarray:
    n = len(a) - 1
    size = 1
    while size < 2 * n:
        size *= 2
    padded = np.zeros(size, dtype=np.float64)
    padded[1 : n + 1] = a[1:]
    transform = np.fft.rfft(padded)
    corr = np.fft.irfft(transform * np.conj(transform), n=size)
    return np.rint(corr[:n]).astype(np.int64)


def direct_check(a: np.ndarray, corr: np.ndarray, limit: int = 256) -> bool:
    n = len(a) - 1
    for h in range(min(n, limit)):
        direct = sum(int(a[k]) * int(a[k + h]) for k in range(1, n - h + 1))
        if direct != int(corr[h]):
            return False
    return True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--kind", choices=("lambda", "mobius"), default="lambda")
    parser.add_argument("--theta", type=float, default=0.75,
                        help="use H=floor(N**theta), with 0<theta<1")
    parser.add_argument("sizes", nargs="*", type=int,
                        default=[2**10, 2**12, 2**14, 2**16, 2**18])
    args = parser.parse_args()
    for n in args.sizes:
        a = values(n, args.kind)
        corr = correlations(a)
        if not 0 < args.theta < 1:
            raise ValueError("theta must lie strictly between 0 and 1")
        H = max(1, int(n ** args.theta))
        block = corr[H + 1 : min(2 * H + 1, n)]
        energy = int(np.dot(block, block))
        print(
            f"kind={args.kind} N={n} direct_check={direct_check(a, corr)} "
            f"E/N^2={energy / n**2:.8g} "
            f"E*H/N^2={energy * H / n**2:.8g} "
            f"max|C_h|={int(np.max(np.abs(block)))}"
        )


if __name__ == "__main__":
    main()
