from fractions import Fraction
from math import comb, factorial


def cbinom(n, k):
    return comb(n, k) if 0 <= k <= n else 0


def eulerian(n):
    row = [1]
    for q in range(1, n):
        nxt = [0] * (q + 1)
        for j, value in enumerate(row):
            nxt[j] += (j + 1) * value
            nxt[j + 1] += (q - j) * value
        row = nxt
    return row


def convolution(a, b, k):
    return sum(
        (a[i] if i < len(a) else 0)
        * (b[k - i] if 0 <= k - i < len(b) else 0)
        for i in range(k + 1)
    )


def phi(m, a, b):
    e = 2 * m + 2
    return (
        convolution(eulerian(a), eulerian(b), 2)
        + e * convolution(eulerian(a), eulerian(b), 1)
        + comb(e + 1, 2)
    )


def coefficient(m):
    D = 3 * m + 3
    total = Fraction(0)
    for r in range(1, m + 1):
        d = Fraction(
            factorial(D) * factorial(m + r - 2),
            cbinom(D, 2)
            * 2**r
            * factorial(r - 1)
            * factorial(m - r)
            * factorial(2 * m + r + 1),
        )
        p = m - r + 3
        q = 2 * m + r + 1
        total += d * (q * phi(m, p, q - 1) - p * phi(m, p - 1, q))
    return total


def main():
    values = {m: coefficient(m) for m in range(1, 35)}
    assert values[1] == 0 and values[2] == 0
    assert all(values[m] > 0 for m in range(3, 35))
    print("EXACT_J2_COEFFICIENT_OK", values[1], values[2], values[3])


if __name__ == "__main__":
    main()
