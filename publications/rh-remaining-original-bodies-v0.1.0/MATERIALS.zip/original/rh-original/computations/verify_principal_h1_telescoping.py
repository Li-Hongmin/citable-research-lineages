#!/usr/bin/env python3
"""Exact check of the note 409 pair-kernel/telescoping identity."""

from fractions import Fraction
import argparse


def mobius(n: int) -> int:
    x = n
    p = 2
    parity = 1
    while p * p <= x:
        if x % p == 0:
            x //= p
            parity = -parity
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        parity = -parity
    return parity


def check(Y: int) -> None:
    a = []
    for m in range(1, 2 * Y + 1):
        value = 2 * mobius(m) if m <= Y else 0
        if m % 2 == 0:
            value -= mobius(m // 2)
        a.append(value)

    pair = Fraction(0)
    for m, am in enumerate(a, 1):
        for n, an in enumerate(a, 1):
            pair += Fraction(am * an * min(m, n), 2 * max(m, n))

    prefix = 0
    telescoped = Fraction(0)
    squares = []
    for n, an in enumerate(a, 1):
        old = prefix
        prefix += n * an
        telescoped += Fraction(prefix * prefix - old * old, 2 * n * n)
        squares.append(prefix)

    positive = Fraction(0)
    for n in range(1, 2 * Y):
        positive += Fraction(squares[n - 1] ** 2, 2) * (
            Fraction(1, n * n) - Fraction(1, (n + 1) * (n + 1))
        )

    assert prefix == 0, (Y, prefix)
    assert pair == telescoped == positive, (Y, pair, telescoped, positive)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("-M", type=int, default=50)
    args = parser.parse_args()
    for Y in range(1, args.M + 1):
        check(Y)
    print(f"exact principal H1 telescoping identity verified for Y=1..{args.M}")


if __name__ == "__main__":
    main()
