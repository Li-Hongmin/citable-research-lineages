#!/usr/bin/env python3
"""Explore finite OPUC/Toeplitz certificates on a tangent disk for xi+xi'."""

from __future__ import annotations

import argparse
import math

import numpy as np
from flint import ctx

from explore_f_tangent_disk_fractional_certificate import (
    log_gamma_normalization,
    q_midpoint,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--band-top", type=float, required=True)
    parser.add_argument("--tau", type=float, required=True)
    parser.add_argument("--samples", type=int, default=2048)
    parser.add_argument("--max-degree", type=int, default=12)
    parser.add_argument("--digits", type=int, default=35)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if (
        not 0 < args.band_top <= 0.5
        or args.samples < 4 * (args.max_degree + 1)
        or not 1 <= args.max_degree <= 64
        or args.digits < 20
    ):
        raise ValueError("invalid tangent-disk OPUC parameters")
    ctx.dps = args.digits

    radius = 0.75 * args.band_top
    center = complex(0.5 + radius, args.tau)
    center_q = q_midpoint(center.real, center.imag)
    center_log_normalization = log_gamma_normalization(center)
    theta = 2.0 * math.pi * (
        np.arange(args.samples, dtype=np.float64) + 0.5
    ) / args.samples
    z = np.exp(1j * theta)
    normalized_f = np.empty(args.samples, dtype=np.complex128)
    for index, unit in enumerate(z):
        point = center + radius * unit
        normalized_f[index] = q_midpoint(point.real, point.imag) / center_q * np.exp(
            log_gamma_normalization(point) - center_log_normalization
        )
    weight = np.abs(normalized_f) ** 2

    features = np.vstack([z**degree for degree in range(args.max_degree + 1)]).T
    gram = (features.conj().T * weight) @ features / args.samples
    gram = (gram + gram.conj().T) / 2

    print("NON-RIGOROUS tangent-disk OPUC/Toeplitz certificate scan")
    print("center =", center)
    print("radius =", radius)
    print("samples =", args.samples)
    print("degree   Schur residual       min optimizer zero modulus   factor-5 pass")
    print(f"{0:6d}   {gram[0, 0].real:.14f}   {'-':>25s}   {gram[0, 0].real < 5.0}")
    previous = gram[0, 0].real
    for degree in range(1, args.max_degree + 1):
        block = gram[1 : degree + 1, 1 : degree + 1]
        cross = gram[1 : degree + 1, 0]
        tail = np.linalg.solve(block, cross)
        coefficients = np.concatenate(([1.0 + 0.0j], -tail))
        residual = float(
            np.real(coefficients.conj() @ gram[: degree + 1, : degree + 1] @ coefficients)
        )
        roots = np.polynomial.polynomial.polyroots(coefficients)
        minimum_root_modulus = float(np.min(np.abs(roots)))
        if residual > previous * (1.0 + 2e-11):
            raise AssertionError("Schur residual lost numerical monotonicity")
        previous = residual
        print(
            f"{degree:6d}   {residual:.14f}   {minimum_root_modulus:25.14f}   "
            f"{residual < 5.0}"
        )
        if degree == 1:
            print("         degree-1 optimizer coefficients =", coefficients)


if __name__ == "__main__":
    main()
