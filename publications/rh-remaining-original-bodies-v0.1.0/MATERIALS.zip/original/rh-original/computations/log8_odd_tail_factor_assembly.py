"""Arb certificate for the exact 5x5 N=400 -> 500 scalar-Feshbach update."""
from fractions import Fraction
from flint import arb,acb,arb_mat,ctx
import numpy as np,sys
ctx.prec=int(sys.argv[1]) if len(sys.argv)>1 else 192
def A(x):x=Fraction(x);return arb(x.numerator)/x.denominator
pi=arb.pi();a=arb(8).log()/2;R=200;M=5
def rate(k):return acb(A(k[0]),A(k[1])*pi/a)
def Iexp(k,lo,hi):
 if k==(Fraction(0),Fraction(0)):return acb(hi-lo)
 z=rate(k);return ((z*hi).exp()-(z*lo).exp())/z
def inner(r1,r2,lo,hi):
 s=acb(0)
 for c1,k1 in r1:
  for c2,k2 in r2:s+=c1.conjugate()*c2*Iexp((k1[0]+k2[0],-k1[1]+k2[1]),lo,hi)
 return s.real
def basis(k):
 q=Fraction(2*k+1,2);n=(arb(2)/a).sqrt();return [(acb(0,-n/2),(Fraction(0),q)),(acb(0,n/2),(Fraction(0),-q))]
def rankrep(n):
 ck=Fraction(4*n+1,2);c=A(ck);em=(-c*a).exp();den=(1+em*em).sqrt();return [(acb(em/den),(ck,Fraction(0))),(acb(-em/den),(-ck,Fraction(0)))]
def polar():return [(acb(1),(Fraction(1,2),Fraction(0))),(acb(-1),(Fraction(-1,2),Fraction(0)))]
def transform(rep,kind,d):
 out=[]
 for c,k in rep:
  z=rate(k)
  if kind=='ref':out.append((c*(z*d).exp(),(-k[0],-k[1])))
  elif kind=='plus':out.append((c*(z*d).exp(),k))
  else:out.append((c*(-z*d).exp(),k))
 return out

dat=np.load('scratch/log8_odd_R200_N400_exact_small_map.npz')
small=arb_mat([[arb(str(dat['small_arb'][i,j])) for j in range(M)] for i in range(M)])
Z=arb_mat([[arb(str(dat['z_arb'][k,j])) for j in range(M)] for k in range(R)])
BAS=[basis(k) for k in range(R)]
old=[rankrep(n) for n in range(400)];tail=[rankrep(n) for n in range(400,500)];pol=polar()
Ho=arb_mat([[inner(BAS[k],f,arb(0),a) for f in old] for k in range(R)])
Ht=arb_mat([[inner(BAS[k],f,arb(0),a) for f in tail] for k in range(R)])
hp=arb_mat([[inner(BAS[k],pol,arb(0),a)] for k in range(R)])
qo=Z.transpose()*Ho;qt=Z.transpose()*Ht;qp=Z.transpose()*hp
d2=arb(2).log();terms=[(d2/arb(2).sqrt(),'ref',d2,arb(0),d2),(-d2/arb(2).sqrt(),'plus',d2,arb(0),a-d2),(-d2/arb(2).sqrt(),'minus',d2,d2,a)]
for n in (3,4,5,7):
 d=arb(n).log();al=(d/arb(n).sqrt()) if n in (3,5,7) else d2/2;terms.append((al,'ref',d,d-a,a))

# P_R prime P_R and <basis, prime f_tail>.
PP=arb_mat(R,R);V=arb_mat(R,100)
for coef,kind,d,lo,hi in terms:
 tb=[transform(e,kind,d) for e in BAS];tf=[transform(f,kind,d) for f in tail]
 for k in range(R):
  for l in range(R):PP[k,l]+=coef*inner(BAS[k],tb[l],lo,hi)
  for n in range(100):V[k,n]+=coef*inner(BAS[k],tf[n],lo,hi)

# Full-space Yukawa Gram matrices.
Got=arb_mat([[inner(old[n],tail[j],arb(0),a) for j in range(100)] for n in range(400)])
Gtt=arb_mat([[inner(tail[i],tail[j],arb(0),a) for j in range(100)] for i in range(100)])
gpt=arb_mat([[inner(pol,tail[j],arb(0),a) for j in range(100)]])
kap=A(Fraction(401,2))*pi/a;mu=acb(arb(1)/4,kap/2).digamma().real-pi.log()-arb('2.460537')-2*(a.sinh()-a)
