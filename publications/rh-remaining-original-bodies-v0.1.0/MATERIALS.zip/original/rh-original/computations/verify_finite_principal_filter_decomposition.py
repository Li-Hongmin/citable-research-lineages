#!/usr/bin/env python3
"""Exact finite check of the three-term decomposition in note 413."""

from fractions import Fraction


def mobius(n: int) -> int:
    x = n
    p = 2
    parity = 1
    while p * p <= x:
        if x % p == 0:
            x //= p
            parity = -parity
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        parity = -parity
    return parity


def lehmer(c):
    n = len(c) - 1
    total = Fraction(0)
    for m in range(1, n + 1):
        for k in range(1, n + 1):
            if c[m] and c[k]:
                total += Fraction(c[m] * c[k] * min(m, k), max(m, k))
    return total


for y in range(1, 41):
    n = 2 * y
    u = [0] * (n + 1)
    v = [0] * (n + 1)
    a = [0] * (n + 1)
    for m in range(1, n + 1):
        if m <= y:
            u[m] = mobius(m)
        if m % 2 == 0:
            v[m] = mobius(m // 2)
        a[m] = 2 * u[m] - v[m]
    lhs = Fraction(1, 2) * lehmer(a)
    cross = sum(
        Fraction(u[m] * v[k] * min(m, k), max(m, k))
        for m in range(1, n + 1)
        for k in range(1, n + 1)
    )
    cross_split = Fraction(0)
    for m in range(1, n + 1):
        for k in range(1, y + 1):
            if not u[m] or not v[2 * k]:
                continue
            if k >= m:
                weight = Fraction(m, 2 * k)
            elif 2 * k > m:
                weight = Fraction(m, 2 * k)
            else:
                weight = Fraction(2 * k, m)
            cross_split += u[m] * v[2 * k] * weight
    assert cross == cross_split, (y, cross, cross_split)
    rhs = 2 * lehmer(u) - 2 * cross + Fraction(1, 2) * lehmer(v)
    assert lhs == rhs, (y, lhs, rhs)
print("finite principal-filter three-term decomposition verified for Y=1..40")
