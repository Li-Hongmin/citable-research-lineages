#!/usr/bin/env python3
"""Finite diagnostic for the fixed-endpoint Möbius dyadic block-square.

For

    C_h(N) = sum_{n <= N-h} mu(n) mu(n+h),
    D_H(N) = sum_{H <= h < 2H} C_h(N),

the script reports sum_H |D_H(N)|^2 / N^2 over dyadic H.  The FFT
correlations are checked directly for the first few shifts.  This is a
finite diagnostic only; it is not an asymptotic estimate and does not
address moving endpoints or the RH-strength uniform bound.
"""

from __future__ import annotations

import argparse
import math

import numpy as np


def mobius(n: int) -> np.ndarray:
    """Return mu(1), ..., mu(n) by a linear sieve."""
    value = np.zeros(n + 1, dtype=np.int8)
    value[1] = 1
    composite = np.zeros(n + 1, dtype=np.bool_)
    primes: list[int] = []
    for i in range(2, n + 1):
        if not composite[i]:
            primes.append(i)
            value[i] = -1
        for prime in primes:
            multiple = i * prime
            if multiple > n:
                break
            composite[multiple] = True
            if i % prime == 0:
                value[multiple] = 0
                break
            value[multiple] = -value[i]
    return value


def correlations(value: np.ndarray) -> np.ndarray:
    """Compute C_h(N), 0 <= h < N, by zero-padded FFT."""
    n = len(value) - 1
    padded = np.zeros(2 * n, dtype=np.float64)
    padded[1 : n + 1] = value[1:]
    transform = np.fft.rfft(padded)
    result = np.fft.irfft(transform * np.conj(transform), n=2 * n)
    return np.rint(result[:n]).astype(np.int64)


def direct_check(value: np.ndarray, corr: np.ndarray, limit: int) -> bool:
    n = len(value) - 1
    for h in range(min(limit, n)):
        direct = sum(
            int(value[k]) * int(value[k + h])
            for k in range(1, n - h + 1)
        )
        if direct != int(corr[h]):
            return False
    return True


def report(n: int, check_limit: int) -> None:
    value = mobius(n).astype(np.float64)
    corr = correlations(value)
    checked = direct_check(value, corr, check_limit)

    square_sum = 0
    max_block = (0, 0, 0)
    block = 1
    while block < n:
        endpoint = min(2 * block, n)
        d_block = int(corr[block:endpoint].sum())
        square_sum += d_block * d_block
        candidate = (abs(d_block), block, d_block)
        if candidate > max_block:
            max_block = candidate
        block *= 2

    print(
        f"N={n} direct_check={checked} "
        f"sum_D2/N2={square_sum / n**2:.9g} "
        f"sqrt(sum_D2)/N={math.sqrt(square_sum) / n:.9g} "
        f"max_abs_D/N={max_block[0] / n:.9g} "
        f"argmax_H={max_block[1]}"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("sizes", nargs="*", type=int,
                        default=[2**12, 2**14, 2**16, 2**18, 2**20])
    parser.add_argument("--check-limit", type=int, default=128)
    args = parser.parse_args()
    if any(n < 2 for n in args.sizes) or args.check_limit < 0:
        raise ValueError("sizes must be >= 2 and check-limit must be nonnegative")
    for n in args.sizes:
        report(n, args.check_limit)


if __name__ == "__main__":
    main()
