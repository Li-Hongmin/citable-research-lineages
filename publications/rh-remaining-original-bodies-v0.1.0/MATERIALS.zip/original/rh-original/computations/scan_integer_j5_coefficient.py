"""OMEN-only exact diagnostic for the fifth integer coefficient.

This finite scan uses the same Eulerian interface as notes 627--630.  It is
deliberately a diagnostic: positivity on a finite range is not an all-m proof.
"""

from fractions import Fraction
from math import comb, factorial


def eulerian_low(n: int, j: int) -> int:
    return sum(
        (-1) ** ell * comb(n + 1, ell) * (j + 1 - ell) ** n
        for ell in range(j + 1)
    )


def phi5(m: int, a: int, b: int) -> int:
    e = 2 * m + 2
    return sum(
        eulerian_low(a, i)
        * eulerian_low(b, j)
        * comb(e + 4 - i - j, 5 - i - j)
        for i in range(6)
        for j in range(6 - i)
    )


def coefficient(m: int) -> Fraction:
    D = 3 * m + 3
    total = Fraction(0)
    for r in range(1, m + 1):
        d = Fraction(
            factorial(D) * factorial(m + r - 2),
            comb(D, 2)
            * 2**r
            * factorial(r - 1)
            * factorial(m - r)
            * factorial(2 * m + r + 1),
        )
        p = m - r + 3
        q = 2 * m + r + 1
        total += d * (q * phi5(m, p, q - 1) - p * phi5(m, p - 1, q))
    return total


def main() -> None:
    values = {m: coefficient(m) for m in range(1, 201)}
    negatives = {m: value for m, value in values.items() if value < 0}
    zeros = [m for m, value in values.items() if value == 0]
    print("J5_SCAN", "m=1..200", "negative_count", len(negatives))
    print("J5_ZEROS", zeros)
    if negatives:
        print("J5_FIRST_NEGATIVE", min(negatives), negatives[min(negatives)])
    else:
        print("J5_NO_NEGATIVE")


if __name__ == "__main__":
    main()
