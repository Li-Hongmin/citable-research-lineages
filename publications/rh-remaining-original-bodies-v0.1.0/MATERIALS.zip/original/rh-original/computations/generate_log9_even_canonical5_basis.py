"""Generate the canonical row(Ueff_exact) rank-five q64 basis."""
import re,numpy as np
from scipy.linalg import svd
def mid(s):return float(re.search(r'\[?([^ ]+)',str(s)).group(1))
ac=np.load('scratch/log9_even_contract_amp_q280_1000_arb.npz')['amp']
U=np.array([[mid(ac[i,j]) for j in range(720)] for i in range(5)])
_,s,Vh=svd(U,full_matrices=False,lapack_driver='gesdd')
assert s[-1]>0
Q=Vh[:5]
q64=np.empty(Q.shape,dtype=object)
for i in range(5):
 for j in range(720):q64[i,j]=str(int(round(float(Q[i,j])*2**64)))
np.savez('scratch/log9_even_q280_1000_canonical5_q64.npz',numerator=q64,denominator='18446744073709551616')
Qd=np.linalg.qr((np.array([[int(z) for z in row] for row in q64],float)/2**64).T,mode='reduced')[0].T
rem=U-(U@Qd.T)@Qd
print('Ueff_singular_values',s)
print('canonical_rank',len(s))
print('canonical_core_tail_op',np.linalg.svd(rem,compute_uv=False)[0]**2)
print('canonical_core_tail_trace',np.sum(rem*rem))
