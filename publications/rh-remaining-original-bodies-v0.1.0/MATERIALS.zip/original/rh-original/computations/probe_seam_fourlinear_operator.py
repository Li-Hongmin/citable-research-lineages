#!/usr/bin/env python3
"""Finite-modulus probe for the rho=sigma=.7, c=d=.3 HB seam.

The tensor is never stored.  For a fixed numerator a we contract

  K_a(r,s,c,d) = 1_(rd,sc)=1 exp(2 pi i a (rd)^(-1)/(sc))

on dyadic integer boxes r,s~P^.7 and c,d~P^.3.  Alternating exact
rank-one updates give a lower bound for its complex injective norm.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass

import numpy as np


def dyadic(x: float) -> np.ndarray:
    lo = max(1, int(math.ceil(x)))
    hi = max(lo + 1, int(math.ceil(2 * x)))
    return np.arange(lo, hi, dtype=np.int64)


@dataclass
class Box:
    r: np.ndarray
    s: np.ndarray
    c: np.ndarray
    d: np.ndarray

    @property
    def size(self) -> int:
        return len(self.r) * len(self.s) * len(self.c) * len(self.d)


def kernel_slice(a: int, r: np.ndarray, s0: int, c0: int, d: np.ndarray) -> np.ndarray:
    """Return K[r,d] for one (s,c), using exact modular inverses."""
    q = int(s0 * c0)
    rd = r[:, None] * d[None, :]
    good = np.gcd(rd, q) == 1
    out = np.zeros(rd.shape, dtype=np.complex128)
    if np.any(good):
        vals = rd[good] % q
        inv = np.fromiter((pow(int(v), -1, q) for v in vals), np.int64, len(vals))
        out[good] = np.exp((2j * np.pi / q) * ((a * inv) % q))
    return out


def contractions(a: int, box: Box, vecs: list[np.ndarray]) -> tuple[list[np.ndarray], complex]:
    xr, ys, zc, wd = vecs
    gr = np.zeros(len(box.r), dtype=np.complex128)
    gs = np.zeros(len(box.s), dtype=np.complex128)
    gc = np.zeros(len(box.c), dtype=np.complex128)
    gd = np.zeros(len(box.d), dtype=np.complex128)
    value = 0j
    for js, sv in enumerate(box.s):
        for jc, cv in enumerate(box.c):
            k = kernel_slice(a, box.r, int(sv), int(cv), box.d)
            kw = k @ wd
            xk = xr @ k
            base = ys[js] * zc[jc]
            gr += base * kw
            gd += base * xk
            scalar = xr @ kw
            gs[js] += zc[jc] * scalar
            gc[jc] += ys[js] * scalar
            value += base * scalar
    return [gr, gs, gc, gd], value


def normalize(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    return np.conjugate(v) / n if n else v


def ascent(a: int, box: Box, rng: np.random.Generator, starts: int, sweeps: int) -> float:
    best = 0.0
    dims = [len(box.r), len(box.s), len(box.c), len(box.d)]
    for _ in range(starts):
        vecs = []
        for n in dims:
            v = rng.normal(size=n) + 1j * rng.normal(size=n)
            vecs.append(v / np.linalg.norm(v))
        for _ in range(sweeps):
            # Recompute after every coordinate update: exact block maximization.
            for j in range(4):
                gs, _ = contractions(a, box, vecs)
                vecs[j] = normalize(gs[j])
        _, val = contractions(a, box, vecs)
        best = max(best, abs(val))
    return best


def random_baseline(a: int, box: Box, rng: np.random.Generator, trials: int) -> float:
    vals = []
    dims = [len(box.r), len(box.s), len(box.c), len(box.d)]
    for _ in range(trials):
        vecs = []
        for n in dims:
            v = rng.normal(size=n) + 1j * rng.normal(size=n)
            vecs.append(v / np.linalg.norm(v))
        vals.append(abs(contractions(a, box, vecs)[1]))
    return float(np.sqrt(np.mean(np.square(vals))))


def raw_l2(box: Box) -> float:
    count = 0
    for sv in box.s:
        for cv in box.c:
            q = int(sv * cv)
            rd = box.r[:, None] * box.d[None, :]
            count += int(np.count_nonzero(np.gcd(rd, q) == 1))
    return math.sqrt(count)


def pair_operator(a: int, box: Box, v: np.ndarray, adjoint: bool = False) -> np.ndarray:
    """Apply the (r,d)->(s,c) flattening, without materializing it."""
    if not adjoint:
        out = np.zeros((len(box.s), len(box.c)), dtype=np.complex128)
        for js, sv in enumerate(box.s):
            for jc, cv in enumerate(box.c):
                out[js, jc] = np.vdot(np.conjugate(kernel_slice(a, box.r, int(sv), int(cv), box.d)), v)
        return out
    out = np.zeros((len(box.r), len(box.d)), dtype=np.complex128)
    for js, sv in enumerate(box.s):
        for jc, cv in enumerate(box.c):
            out += np.conjugate(kernel_slice(a, box.r, int(sv), int(cv), box.d)) * v[js, jc]
    return out


def pair_spectral(a: int, box: Box, rng: np.random.Generator, iterations: int = 20) -> float:
    v = rng.normal(size=(len(box.r), len(box.d))) + 1j * rng.normal(size=(len(box.r), len(box.d)))
    v /= np.linalg.norm(v)
    for _ in range(iterations):
        w = pair_operator(a, box, v)
        v = pair_operator(a, box, w, adjoint=True)
        v /= np.linalg.norm(v)
    return float(np.linalg.norm(pair_operator(a, box, v)))


def is_prime(n: int) -> bool:
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    p = 3
    while p * p <= n:
        if n % p == 0:
            return False
        p += 2
    return True


def arithmetic_numerators(P: int, box: Box, rng: np.random.Generator, random_count: int) -> list[tuple[int, str]]:
    lo, hi = P * P, 2 * P * P
    ans: list[tuple[int, str]] = [(lo, "square"), (P * (P + 1), "adjacent_product")]
    # A prime numerator removes gcd resonance with every seam modulus.
    p = (lo + hi) // 2
    while not is_prime(p):
        p += 1
    ans.append((p, "prime"))
    for _ in range(random_count):
        ans.append((int(rng.integers(lo, hi + 1)), "random"))
        k = int(rng.integers(P, 2 * P + 1))
        ell = int(rng.integers(P, 2 * P + 1))
        a = k * ell
        if lo <= a <= hi:
            ans.append((a, "k_times_ell"))
    # Force a=0 modulo actual sc moduli; this targets the most coherent slice
    # while respecting a~P^2.
    moduli = np.unique(box.s[:, None] * box.c[None, :])
    if len(moduli) > random_count:
        moduli = rng.choice(moduli, size=random_count, replace=False)
    for q0 in moduli:
        q = int(q0)
        a = q * max(1, round(1.5 * P * P / q))
        if lo <= a <= hi:
            ans.append((a, "modulus_resonant"))
    # Preserve labels after de-duplication.
    return list(dict.fromkeys(ans))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--P", nargs="+", type=int, default=[24, 36, 54, 80, 120, 180])
    ap.add_argument("--numerators", type=int, default=3)
    ap.add_argument("--starts", type=int, default=5)
    ap.add_argument("--sweeps", type=int, default=8)
    ap.add_argument("--random-trials", type=int, default=12)
    ap.add_argument("--seed", type=int, default=8122026)
    ap.add_argument("--arithmetic-scan", action="store_true")
    ap.add_argument("--output", default="scratch/seam_fourlinear_operator.json")
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    rows = []
    for P in args.P:
        box = Box(dyadic(P**0.7), dyadic(P**0.7), dyadic(P**0.3), dyadic(P**0.3))
        # Avoid atypical a=0 mod many q: sample near the natural P^2 scale.
        if args.arithmetic_scan:
            tagged = arithmetic_numerators(P, box, rng, args.numerators)
        else:
            tagged = [(int(a), "random") for a in rng.integers(P * P, 2 * P * P + 1, size=args.numerators)]
        records = []
        trivial = raw_l2(box)
        for a0, kind in tagged:
            opt = ascent(int(a0), box, rng, args.starts, args.sweeps)
            rnd = random_baseline(int(a0), box, rng, args.random_trials)
            pair = pair_spectral(int(a0), box, rng)
            records.append({"a": int(a0), "kind": kind, "optimized": opt, "random_rms": rnd,
                            "trivial": trivial, "optimized_over_trivial": opt / trivial,
                            "random_over_trivial": rnd / trivial,
                            "pair_spectral_upper": pair,
                            "pair_spectral_over_trivial": pair / trivial})
        rows.append({"P": P, "dims": [len(box.r), len(box.s), len(box.c), len(box.d)],
                     "entries": box.size, "records": records,
                     "worst_optimized_over_trivial": max(x["optimized_over_trivial"] for x in records),
                     "median_random_over_trivial": float(np.median([x["random_over_trivial"] for x in records]))})
        print(json.dumps(rows[-1]))
    for key in ("worst_optimized_over_trivial", "median_random_over_trivial"):
        x = np.log([r["P"] for r in rows])
        y = np.log([r[key] for r in rows])
        slope, intercept = np.polyfit(x, y, 1)
        for r in rows:
            r.setdefault("fits", {})[key] = {"P_exponent": float(slope), "constant": float(np.exp(intercept))}
    payload = {"model": "fixed-a Kloosterman fourlinear seam", "rho": .7, "sigma": .7,
               "c_exp": .3, "d_exp": .3, "rows": rows}
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


if __name__ == "__main__":
    main()
