#!/usr/bin/env python3
"""Cayley scan of {1, 2**(-s)} with several rational damping scales."""

from __future__ import annotations

import argparse

import numpy as np
from flint import acb, arb, ctx

from explore_q_optimal_polynomial_approximants import boundary_samples, q_value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a", type=float, required=True)
    parser.add_argument("--tau", type=float, required=True)
    parser.add_argument("--samples", type=int, default=32768)
    parser.add_argument(
        "--damping-scales",
        type=float,
        nargs="+",
        required=True,
        help="positive L values; use 0 for the undamped limit",
    )
    parser.add_argument("--digits", type=int, default=40)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.a <= 0 or min(args.damping_scales) < 0:
        raise ValueError("a must be positive and damping scales nonnegative")
    ctx.dps = args.digits

    theta, boundary = boundary_samples(args.samples, args.a, args.tau)
    offsets = args.a / np.tan(theta / 2.0)
    heights = args.tau + offsets
    boundary_square = np.abs(boundary) ** 2
    center_ball = q_value(acb(arb(str(0.5 + args.a)), arb(str(args.tau))))
    center = complex(float(center_ball.real.mid()), float(center_ball.imag.mid()))
    target = abs(center) ** 2

    integers = np.array([1.0, 2.0])
    basis = np.exp(
        -(0.5 + 1j * heights[:, None]) * np.log(integers)[None, :]
    )
    center_basis = np.exp(
        -(0.5 + args.a + 1j * args.tau) * np.log(integers)
    )

    print("NON-RIGOROUS Cayley two-term Dirichlet-resolvent cell scan")
    print("a =", args.a, "tau =", args.tau, "samples =", args.samples)
    print("|Q(center)|^2 =", target)
    print(
        "L                 one_ratio      two_ratio      Lambda        "
        "required      surplus       cond(A)"
    )
    for damping in args.damping_scales:
        if damping == 0:
            weight = boundary_square
        else:
            weight = boundary_square * (args.a + damping) ** 2 / (
                damping**2 + offsets**2
            )
        gram = (basis.conj().T * weight) @ basis / args.samples
        solved = np.linalg.solve(gram, center_basis.conj())
        denominator = center_basis @ solved
        minimum = float(np.real(1.0 / denominator))
        one_ratio = float(np.mean(weight) / target)
        norm = float(np.real(gram[0, 0]))
        overlap = (
            np.sqrt(2.0)
            * np.exp(1j * args.tau * np.log(2.0))
            * gram[0, 1]
        )
        circular_mean = overlap / norm
        circular_variance = max(0.0, 1.0 - abs(circular_mean) ** 2)
        delay_gain = (
            abs(circular_mean - 2.0 ** (-args.a)) ** 2
            / circular_variance
        )
        required_gain = max(0.0, one_ratio / 5.0 - 1.0)
        print(
            f"{damping:14.8g}  {one_ratio:.12f}  "
            f"{minimum / target:.12f}  {delay_gain:.12f}  "
            f"{required_gain:.12f}  "
            f"{delay_gain - required_gain:.12f}  "
            f"{np.linalg.cond(gram):.8g}"
        )


if __name__ == "__main__":
    main()
