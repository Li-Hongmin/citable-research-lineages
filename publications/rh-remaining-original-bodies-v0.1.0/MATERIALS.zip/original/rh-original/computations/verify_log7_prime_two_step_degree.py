"""Finite Arb proof of the two-step prime degree bound at a=log(7)/2.

No spatial grid is used.  Breakpoints are exact Q-linear combinations of
log(2), log(3), log(5), log(7), so duplicate points are removed symbolically.
Arb is used only to certify their ordering and the final inequalities.

Run, for example:
    uv run --with python-flint python computations/verify_log7_prime_two_step_degree.py 256
"""

from fractions import Fraction as F
import sys

from flint import arb, ctx

ctx.prec = int(sys.argv[1]) if len(sys.argv) > 1 else 256

# Exact symbolic point sum c_p log(p), in prime order 2,3,5,7.
P = (2, 3, 5, 7)
ZERO = (F(0),) * 4


def vec(*x):
    return tuple(F(t) for t in x)


def add(x, y):
    return tuple(a + b for a, b in zip(x, y))


def neg(x):
    return tuple(-a for a in x)


def sub(x, y):
    return add(x, neg(y))


def scale(c, x):
    return tuple(F(c) * a for a in x)


def val(x):
    out = arb(0)
    for c, p in zip(x, P):
        out += (arb(c.numerator) / c.denominator) * arb(p).log()
    return out


L2 = vec(1, 0, 0, 0)
L3 = vec(0, 1, 0, 0)
L4 = scale(2, L2)
L5 = vec(0, 0, 1, 0)
A = vec(0, 0, 0, F(1, 2))
D = {2: L2, 3: L3, 4: L4, 5: L5}


def strict_lt(x, y):
    """Certify x<y, failing rather than guessing if Arb balls overlap."""
    return val(x) < val(y)


def inside(x, lo, hi):
    """Membership for a point known not to lie on any relevant boundary."""
    if not strict_lt(lo, x) or not strict_lt(x, hi):
        return False
    return True


# Edge supports are open because endpoints have measure zero for the Schur test.
# Each edge is (weight-name, affine sign, affine constant, support-lo, support-hi).
EDGES = [
    ("x", +1, L2, ZERO, sub(A, L2), "S+"),
    ("x", +1, neg(L2), L2, A, "S-"),
]
for n, name in ((2, "x"), (3, "y"), (4, "z"), (5, "w")):
    lo = ZERO if strict_lt(D[n], A) else sub(D[n], A)
    hi = D[n] if strict_lt(D[n], A) else A
    EDGES.append((name, -1, D[n], lo, hi, "J%d" % n))


def image(edge, t):
    _, sign, const, _, _, _ = edge
    return add(scale(sign, t), const)


def active_edges(t):
    return [e for e in EDGES if inside(t, e[3], e[4])]


# First-level degree breakpoints.
base = {ZERO, A}
for _, _, _, lo, hi, _ in EDGES:
    base.add(lo)
    base.add(hi)

# D(image_e(t)) changes only when image_e(t) crosses a base breakpoint.
cuts = set(base)
for e in EDGES:
    _, sign, const, lo, hi, _ = e
    for b in base:
        # sign*t+const=b, hence t=sign*(b-const).
        t = scale(sign, sub(b, const))
        # Keep [0,a] candidates; comparisons are strict except exact endpoints.
        if t == ZERO or t == A or (strict_lt(ZERO, t) and strict_lt(t, A)):
            cuts.add(t)

# Sort by certified Arb order.  Python's key is diagnostic only; every adjacent
# pair is then rigorously checked.
cuts = sorted(cuts, key=lambda q: float(val(q).mid()))
for left, right in zip(cuts, cuts[1:]):
    assert strict_lt(left, right), (left, right, val(left), val(right))

# Arb weights.
x = arb(2).log() / arb(2).sqrt()
y = arb(3).log() / arb(3).sqrt()
z = arb(2).log() / 2
w = arb(5).log() / arb(5).sqrt()
W = {"x": x, "y": y, "z": z, "w": w}
claimed = (x + y) * (2 * x + y) + z * (x + y + z) + w * (x + y + z + w)
NAMES = ("x", "y", "z", "w")


def lin_degree(t):
    out = {k: 0 for k in NAMES}
    for e in active_edges(t):
        out[e[0]] += 1
    return out


def poly_add_term(poly, left_name, linear):
    for right_name, multiplicity in linear.items():
        key = tuple(sorted((left_name, right_name)))
        poly[key] = poly.get(key, 0) + multiplicity


def poly_value(poly):
    return sum((arb(c) * W[i] * W[j] for (i, j), c in poly.items()), arb(0))


claimed_poly = {}
for left, linear in (
    ("x", {"x": 2, "y": 1}),
    ("y", {"x": 2, "y": 1}),
    ("z", {"x": 1, "y": 1, "z": 1}),
    ("w", {"x": 1, "y": 1, "z": 1, "w": 1}),
):
    poly_add_term(claimed_poly, left, linear)
assert (poly_value(claimed_poly) - claimed).contains(0)


def degree(t):
    return sum((W[e[0]] for e in active_edges(t)), arb(0))


rows = []
for left, right in zip(cuts, cuts[1:]):
    mid = scale(F(1, 2), add(left, right))
    first = active_edges(mid)
    d2_poly = {}
    detail = []
    for e in first:
        qlin = lin_degree(image(e, mid))
        poly_add_term(d2_poly, e[0], qlin)
        detail.append("%s:%s" % (e[5], qlin))
    d2 = poly_value(d2_poly)
    # The refined cut set guarantees all indicators are constant on this cell.
    assert d2_poly == claimed_poly or d2 < claimed, (left, right, d2, claimed, d2_poly)
    rows.append((left, right, d2, detail, d2_poly))

attained = [r for r in rows if r[4] == claimed_poly]
assert attained, "upper bound was not attained on any open cell"

print("precision_bits", ctx.prec)
print("number_of_open_cells", len(rows))
print("claimed_sup_D2", claimed)
print("claimed_norm_bound", claimed.sqrt())
print("safe_decimal_norm_bound", arb("1.975358"))
assert claimed.sqrt() < arb("1.975358")
print("attaining_cells", len(attained))
for left, right, d2, detail, _ in attained:
    print("  ", val(left), val(right), d2, "; ".join(detail))

print("all_cells")
for left, right, d2, detail, _ in rows:
    print("  ", val(left), val(right), d2, "; ".join(detail))
