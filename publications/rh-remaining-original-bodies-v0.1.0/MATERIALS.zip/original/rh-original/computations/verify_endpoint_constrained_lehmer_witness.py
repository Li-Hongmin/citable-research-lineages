#!/usr/bin/env python3
"""Finite exact checks for the endpoint-constrained witness in note 414."""

from fractions import Fraction


for m in (10, 20, 40, 80, 160):
    n = 2 * m
    alpha = Fraction(m + 1, 3 * m + 1)
    c = [Fraction(0)] + [
        Fraction(1) if j <= m else -alpha for j in range(1, n + 1)
    ]
    endpoint = sum(j * c[j] for j in range(1, n + 1))
    assert endpoint == 0, (m, endpoint)
    q = Fraction(0)
    for i in range(1, n + 1):
        for j in range(1, n + 1):
            q += c[i] * c[j] * Fraction(min(i, j), max(i, j))
    q /= 2
    print(m, float(q / (n * n)))

print("endpoint-constrained Lehmer witness verified for M=10,20,40,80,160")
