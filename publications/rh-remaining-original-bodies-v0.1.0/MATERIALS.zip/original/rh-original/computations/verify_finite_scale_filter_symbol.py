import math


def main() -> None:
    for j in range(2001):
        theta = 2.0 * math.pi * j / 2000.0
        z = complex(math.cos(theta), math.sin(theta))
        p_plus = 2.0 - z
        p_minus = 1.0 - 2.0 * z
        plus_sq = abs(p_plus) ** 2
        minus_sq = abs(p_minus) ** 2
        exact = 5.0 - 4.0 * math.cos(theta)
        assert abs(plus_sq - exact) < 1e-12
        assert abs(minus_sq - exact) < 1e-12
        assert 1.0 - 1e-12 <= exact <= 9.0 + 1e-12
    print("finite-scale filter symbol verified for P=2-z and P=1-2z")


if __name__ == "__main__":
    main()
