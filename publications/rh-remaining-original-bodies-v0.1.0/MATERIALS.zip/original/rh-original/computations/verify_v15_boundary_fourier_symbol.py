#!/usr/bin/env python3
"""Small Arb certificate for the signed boundary Fourier symbol.

For the one-sided reciprocal detector, the even boundary kernel has symbol
Re(zeta(i*t) K(i*t)).  This script records a few intervals for V_15; it is a
finite symbol check, not an infinite-dimensional positivity claim.
"""

from flint import acb, arb, ctx


ctx.prec = 192


def mellin_v15(s: acb) -> acb:
    numerator = arb(415134720) * (s - 1)
    denominator = acb(1)
    for k in (2, 4, 6, 8, 9, 10, 11, 12, 13, 14, 15):
        denominator *= s + k
    return numerator / denominator


def main() -> None:
    for t in (0, 1, 2, 3, 10):
        s = acb(0, t)
        symbol = (acb.zeta(s) * mellin_v15(s)).real
        print(f"t={t} Re(zeta*K)={symbol}")


if __name__ == "__main__":
    main()
