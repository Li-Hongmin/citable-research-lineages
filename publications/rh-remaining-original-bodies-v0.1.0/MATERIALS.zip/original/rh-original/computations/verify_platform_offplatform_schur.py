#!/usr/bin/env python3
"""Exact OMEN-side verification for note 468.

All Gram entries are represented as weighted rational sums; square roots in the
row vectors cancel.  The script checks the platform/off-platform block formulas
and the finite Schur completion identity.
"""

from __future__ import annotations

import argparse
from fractions import Fraction


def mobius_table(n_max: int) -> list[int]:
    mu = [1] * (n_max + 1)
    mu[0] = 0
    primes: list[int] = []
    composite = [False] * (n_max + 1)
    for n in range(2, n_max + 1):
        if not composite[n]:
            primes.append(n)
            mu[n] = -1
        for p in primes:
            if n * p > n_max:
                break
            composite[n * p] = True
            if n % p == 0:
                mu[n * p] = 0
                break
            mu[n * p] = -mu[n]
    return mu


def inverse(matrix: list[list[Fraction]]) -> list[list[Fraction]]:
    n = len(matrix)
    aug = [row[:] + [Fraction(int(i == j)) for j in range(n)] for i, row in enumerate(matrix)]
    for col in range(n):
        pivot = next((row for row in range(col, n) if aug[row][col]), None)
        if pivot is None:
            raise ValueError("singular")
        aug[col], aug[pivot] = aug[pivot], aug[col]
        scale = aug[col][col]
        aug[col] = [x / scale for x in aug[col]]
        for row in range(n):
            if row == col:
                continue
            factor = aug[row][col]
            if factor:
                aug[row] = [x - factor * y for x, y in zip(aug[row], aug[col])]
    return [row[n:] for row in aug]


def matmul(a: list[list[Fraction]], b: list[list[Fraction]]) -> list[list[Fraction]]:
    return [[sum(x * y for x, y in zip(row, col)) for col in zip(*b)] for row in a]


def transpose(a: list[list[Fraction]]) -> list[list[Fraction]]:
    return [list(col) for col in zip(*a)]


def gram(a: list[list[Fraction]], b: list[list[Fraction]], weights: list[int]) -> list[list[Fraction]]:
    return [[sum(Fraction(weights[k]) * a[i][k] * b[j][k] for k in range(len(weights)))
             for j in range(len(b))] for i in range(len(a))]


def run(max_n: int) -> int:
    mu = mobius_table(max_n)
    harmonic = [Fraction(0)] * (max_n + 1)
    for n in range(1, max_n + 1):
        harmonic[n] = harmonic[n - 1] + Fraction(1, n)

    def z_layer(m: int, cutoff: int, q: int) -> Fraction:
        b_max = m // (cutoff + 1)
        return sum(
            Fraction(mu[b], b) *
            (harmonic[m // b] - harmonic[max(cutoff, q // b)])
            for b in range(1, b_max + 1)
        )

    checked = 0
    for n in range(3, max_n + 1):
        for cutoff in range(1, n):
            ds = [d for d in range(1, n + 1) if (cutoff + 1) * d <= n]
            if not ds:
                continue
            rows = list(range(1, n))
            weights = [2 * k + 1 for k in rows]
            p_cols: list[list[Fraction]] = []
            q_cols: list[list[Fraction]] = []
            for d in ds:
                m = n // d
                z0 = z_layer(m, cutoff, 0)
                ell = min(n, (cutoff + 1) * d)
                p_col = []
                q_col = []
                for k in rows:
                    zq = z_layer(m, cutoff, k // d)
                    rval = zq / d
                    pval = z0 / d if k < ell else Fraction(0)
                    p_col.append(pval)
                    q_col.append(rval - pval)
                p_cols.append(p_col)
                q_cols.append(q_col)

            gp = gram(p_cols, p_cols, weights)
            c_actual = gram(p_cols, q_cols, weights)
            gq = gram(q_cols, q_cols, weights)
            gr = gram([[p_cols[i][k] + q_cols[i][k] for k in range(len(rows))]
                       for i in range(len(ds))],
                      [[p_cols[i][k] + q_cols[i][k] for k in range(len(rows))]
                       for i in range(len(ds))], weights)

            for i, d in enumerate(ds):
                ell_d = min(n, (cutoff + 1) * d)
                for j, e in enumerate(ds):
                    ell_e = min(n, (cutoff + 1) * e)
                    c_formula = Fraction(0)
                    if ell_d > ell_e:
                        lo = ell_e
                        hi = min(n - 1, ell_d - 1)
                        if lo <= hi:
                            m_e = n // e
                            z0_d = z_layer(n // d, cutoff, 0)
                            c_formula = z0_d / (d * e) * sum(
                                Fraction(2 * k + 1) * z_layer(m_e, cutoff, k // e)
                                for k in range(lo, hi + 1)
                            )
                    if c_actual[i][j] != c_formula:
                        raise AssertionError(("cross", n, cutoff, d, e,
                                              c_actual[i][j], c_formula))

            gi = inverse(gp)
            schur = [[gq[i][j] - sum(c_actual[k][i] * gi[k][l] * c_actual[l][j]
                                     for k in range(len(ds)) for l in range(len(ds)))
                      for j in range(len(ds))] for i in range(len(ds))]
            # Build the completed-square term directly to avoid ambiguous notation.
            ident = [[Fraction(int(i == j)) for j in range(len(ds))] for i in range(len(ds))]
            bmat = [[ident[i][j] + sum(gi[i][k] * c_actual[k][j]
                                       for k in range(len(ds)))
                     for j in range(len(ds))] for i in range(len(ds))]
            completed = matmul(matmul(transpose(bmat), gp), bmat)
            if any(gr[i][j] != completed[i][j] + schur[i][j]
                   for i in range(len(ds)) for j in range(len(ds))):
                raise AssertionError(("schur", n, cutoff))
            checked += 1

    print(f"PASS {checked} exact platform/off-platform Schur instances")
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-n", type=int, default=24)
    args = parser.parse_args()
    raise SystemExit(run(args.max_n))
