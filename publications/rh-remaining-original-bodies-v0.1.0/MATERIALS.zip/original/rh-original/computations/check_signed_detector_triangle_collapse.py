#!/usr/bin/env python3
"""Exact check of the signed detector triangle-collapse identity.

For a polynomial V supported on (0,1), define
    P(y) = sum_{c <= y} V(c/y),  y >= 1,
    g(log(a/b)) = P(max(a,b)/min(a,b))/2.
The finite Mobius quadratic form with g collapses to
    sum_{a <= N} mu(a) V(1/a).

The check uses the degree-15 detector and exact rational arithmetic.
"""

from fractions import Fraction
from math import comb


def mobius_upto(n):
    mu = [1] * (n + 1)
    prime = [True] * (n + 1)
    mu[0] = 0
    for p in range(2, n + 1):
        if prime[p]:
            for j in range(p, n + 1, p):
                prime[j] = False
                mu[j] *= -1
            pp = p * p
            if pp <= n:
                for j in range(pp, n + 1, pp):
                    mu[j] = 0
    return mu


def v15(u):
    return u * u * (1 - u) ** 9 * (
        1024 * u**4 + 207 * u**3 - 57 * u**2 - 27 * u - 3
    )


def P(y_num, y_den):
    """P(y) for y=y_num/y_den >= 1, exactly."""
    total = Fraction(0)
    for c in range(1, y_num // y_den + 1):
        total += v15(Fraction(c * y_den, y_num))
    return total


def check(N):
    mu = mobius_upto(N)
    quadratic = Fraction(0)
    for a in range(1, N + 1):
        for b in range(1, N + 1):
            if a >= b:
                quadratic += (
                    Fraction(mu[a] * mu[b], 2)
                    * P(a, b)
                )
            else:
                quadratic += (
                    Fraction(mu[a] * mu[b], 2)
                    * P(b, a)
                )
    linear = sum(
        (Fraction(mu[a]) * v15(Fraction(1, a))) for a in range(1, N + 1)
    )
    assert quadratic == linear, (N, quadratic, linear)
    return quadratic


if __name__ == "__main__":
    values = [check(n) for n in range(1, 21)]
    print("signed triangle-collapse passed for N=1..20")
    print("last exact value:", values[-1])
