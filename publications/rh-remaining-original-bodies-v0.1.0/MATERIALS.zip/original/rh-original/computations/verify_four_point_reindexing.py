#!/usr/bin/env python3
"""Check the reindexing n2=n1+d in the four-point expansion."""

from collections import Counter


def check(N: int, H: int) -> None:
    direct = Counter()
    reindexed = Counter()
    for h in range(1, H + 1):
        for n1 in range(1, N - h + 1):
            for n2 in range(1, N - h + 1):
                direct[(n1, n1 + h, n2, n2 + h)] += 1
                d = n2 - n1
                reindexed[(n1, n1 + h, n1 + d, n1 + d + h)] += 1
    assert direct == reindexed, (N, H, direct - reindexed, reindexed - direct)


if __name__ == "__main__":
    for N in range(4, 20):
        for H in range(1, N):
            check(N, H)
    print("four-point reindexing: OK")
