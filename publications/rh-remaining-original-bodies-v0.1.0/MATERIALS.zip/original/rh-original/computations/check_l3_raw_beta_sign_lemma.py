#!/usr/bin/env python3
"""Finite audit for the analytic L=3 raw-Beta sign lemma.

The all-m sign statements are proved symbolically in note 219.  This script
checks the coefficient formula, prefix positivity, and endpoint tails for a
finite range using exact Fraction arithmetic.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
from math import comb


def R(m: int, M: int, u: int) -> Fraction:
    L = 3 * m + 1 - M
    r2 = Fraction(u, L)
    r1 = Fraction(u * (u - 1), L * (L - 1))
    r0 = Fraction(u * (u - 1) * (u - 2), L * (L - 1) * (L - 2))
    f = (
        Fraction(3 * m + 1, 2) * r2
        - Fraction(m - 1, 2) * r1
        - Fraction(M, 8) * r0
        - 3
    )
    g = (3 * m + 1) * r2 - 2 * (m - 1) * r1 - M * r0
    return 2**u * f + 4 * (2 ** (M + 1) - 1) * g + 12 * (1 - 2**M)


def raw_prefixes(m: int, M: int) -> list[Fraction]:
    L = 3 * m + 1 - M
    coefficients = [
        comb(L, j) * R(m, M, L - j) for j in range(L + 1)
    ]
    return [sum(coefficients[: j + 1], Fraction(0)) for j in range(L + 1)]


def check(max_m: int) -> None:
    for m in range(4, max_m + 1):
        for M in range(m):
            prefixes = raw_prefixes(m, M)
            assert all(value > 0 for value in prefixes), (m, M, prefixes)
    print(f"raw L=3 Beta prefixes exact: m=4..{max_m} OK")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("-M", "--max-m", type=int, default=80)
    args = parser.parse_args()
    check(args.max_m)


if __name__ == "__main__":
    main()
