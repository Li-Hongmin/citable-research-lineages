#!/usr/bin/env python3
"""Exact small-range check of the complex lcm incidence factorization."""

from __future__ import annotations

import math


def mobius(n: int) -> list[int]:
    value = [0] * (n + 1)
    value[1] = 1
    composite = [False] * (n + 1)
    primes: list[int] = []
    for i in range(2, n + 1):
        if not composite[i]:
            primes.append(i)
            value[i] = -1
        for p in primes:
            j = i * p
            if j > n:
                break
            composite[j] = True
            if i % p == 0:
                value[j] = 0
                break
            value[j] = -value[i]
    return value


def factorization(n: int) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    p = 2
    while p * p <= n:
        if n % p == 0:
            k = 0
            while n % p == 0:
                n //= p
                k += 1
            out.append((p, k))
        p += 1
    if n > 1:
        out.append((n, 1))
    return out


def weight(n: int) -> tuple[int, int]:
    real, imag = 1, 0
    for _, k in factorization(n):
        if k >= 3:
            return (0, 0)
        # a(p)=i-1, a(p^2)=-i
        if k == 1:
            real, imag = real * -1 - imag, real - imag
        elif k == 2:
            real, imag = imag, -real
    return real, imag


def mul(z: tuple[int, int], w: tuple[int, int]) -> tuple[int, int]:
    return z[0] * w[0] - z[1] * w[1], z[0] * w[1] + z[1] * w[0]


def main(n: int = 500) -> None:
    mu = mobius(n)
    target = [0] * (n + 1)
    for d in range(1, n + 1):
        for e in range(1, n // d + 1):
            target[d * e] += mu[d] * mu[e]

    got = [(0, 0)] * (n + 1)
    for d in range(1, n + 1):
        ad = weight(d)
        if ad == (0, 0):
            continue
        for e in range(1, n + 1):
            l = math.lcm(d, e)
            if l <= n:
                got[l] = tuple(x + y for x, y in zip(got[l], mul(ad, weight(e))))
    mismatches = [k for k in range(1, n + 1) if got[k] != (target[k], 0)]
    if mismatches:
        raise AssertionError([(k, got[k], target[k]) for k in mismatches[:10]])
    print(f"exact_lcm_factorization=ok through n={n}")
    print("sample:", [(k, got[k][0]) for k in range(1, min(20, n + 1))])


if __name__ == "__main__":
    main()
