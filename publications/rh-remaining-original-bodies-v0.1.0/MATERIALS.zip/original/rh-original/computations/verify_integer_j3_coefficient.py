"""Exact OMEN-only certificate for the third integer coefficient.

Run this script on OMEN.  It uses only Fraction arithmetic and the closed
formula from notes 625--626; no floating point or finite-scan extrapolation is
used in the proof note.
"""

from fractions import Fraction
from math import comb, factorial


def phi3(m: int, a: int, b: int) -> int:
    linear = (m + 2) * (m + 3) // 2
    cubic = (m + 1) * (m + 2) * (m + 3) // 6
    D = 3 * m + 3
    return (
        2**a * 3**b
        + 3**a * 2**b
        + 4**a
        + 4**b
        - (m + 3) * (3**a + 3**b + 2**D)
        + linear * (2**a + 2**b)
        - cubic
    )


def coefficient(m: int) -> Fraction:
    D = 3 * m + 3
    total = Fraction(0)
    for r in range(1, m + 1):
        d = Fraction(
            factorial(D) * factorial(m + r - 2),
            comb(D, 2)
            * 2**r
            * factorial(r - 1)
            * factorial(m - r)
            * factorial(2 * m + r + 1),
        )
        p = m - r + 3
        q = 2 * m + r + 1
        total += d * (q * phi3(m, p, q - 1) - p * phi3(m, p - 1, q))
    return total


def main() -> None:
    values = {m: coefficient(m) for m in range(1, 50)}
    assert values[1] == values[2] == values[3] == 0
    assert all(values[m] > 0 for m in range(4, 50))
    print("EXACT_J3_BASE_OK", "m=1..49", "min_positive_m4", min(values[m] for m in range(4, 50)))


if __name__ == "__main__":
    main()
