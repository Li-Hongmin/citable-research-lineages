"""Analytic Arb assembly for the odd endpoint fixed-rank Robin-tail model."""

import argparse
import math
from flint import arb, arb_mat, ctx

import verify_first_band_endpoint_even_analytic as base


ctx.dps=80
A0=arb(2)/5; A=arb(3).log()/2; DLOG=arb(2).log(); PI=arb.pi()
PPRIME=DLOG/arb(2).sqrt(); Q=arb(1)/4
C0=Q.digamma()-PI.log()
M=4;S=3;K=80


def root_z(b,j,steps=190):
    lo=(arb(j)+arb(1)/2)*PI+arb("1e-70")
    hi=(arb(j)+1)*PI-arb("1e-70")
    target=2*b*A
    for _ in range(steps):
        mid=(lo+hi)/2; f=mid/arb.tan(mid)+target
        if f>0: lo=mid
        elif f<0: hi=mid
        else: break
    return lo.union(hi)


def ell(b,z):
    mu=z/A
    return mu**2/(b*(4*b**2+mu**2))


def raw_term(j,k):
    # x^k sin(theta_j x/a+k*pi/2), represented as a cosine descriptor.
    theta=(arb(j)+1)*PI
    return (arb(1),k,theta/A,arb(k)*PI/2-PI/2)


def analytic_young():
    bm=arb(K)+Q;theta_m=(arb(M)+1)*PI;qpow=2*S+5
    series_q=bm**(-qpow)+bm**(1-qpow)/(qpow-1)
    pref=theta_m**2/(4*A0**2);esum=arb(0)
    for j in range(M):
        theta=(arb(j)+1)*PI
        zbar=theta*(2*bm*A0)/(2*bm*A0+1)
        hbar=arb(1)/2-1/(4*zbar)
        esum += theta**(2*S+2)/((2*A0)**(2*S+2)*(2*S+3)
                 *arb(math.factorial(S+1))**2*hbar)
    eup=pref*esum*series_q
    dup=M*pref*(bm**-3+bm**-2/2)
    tau=(eup/dup).sqrt();rho=(1+1/tau)*eup
    return eup,dup,tau,rho


def build_descriptors(terms):
    alpha=C0;low=[]
    blocks=[[[arb(0) for _ in range(S+1)] for _ in range(S+1)]
            for _ in range(M)]
    for n in range(terms):
        b=arb(n)+Q;zs=[root_z(b,j) for j in range(M+1)]
        es=[ell(b,z) for z in zs];alpha += es[M]
        if n<K:
            for j in range(M):
                z=zs[j];mu=z/A
                norm2=A*(arb(1)/2-arb.sin(2*z)/(4*z))
                scale=((es[M]-es[j])/norm2).sqrt()
                low.append([(scale,0,mu,-PI/2)])
        else:
            for j in range(M):
                z=zs[j];eps=(arb(j)+1)*PI-z
                norm2=A*(arb(1)/2-arb.sin(2*z)/(4*z))
                coeff=[(-eps/A)**k/arb(math.factorial(k))/norm2.sqrt()
                       for k in range(S+1)]
                d=es[M]-es[j]
                for r in range(S+1):
                    for s in range(r+1):
                        blocks[j][r][s] += d*coeff[r]*coeff[s]
                        if r!=s: blocks[j][s][r]=blocks[j][r][s]
    eup,dup,tau,rho=analytic_young();agg=[]
    for j in range(M):
        L=base.cholesky_block(blocks[j])
        for col in range(S+1):
            desc=[]
            for k in range(col,S+1):
                raw=raw_term(j,k)
                desc.append((L[k][col]*(1+tau).sqrt(),)+raw[1:])
            agg.append(desc)
    return alpha-rho,low+agg,(eup,dup,tau,rho)


def inner_v(f,lo,hi,reflected=False):
    """Integral f(x)v(x), or f(x)v(d-x), v=2sinh(x/2)."""
    out=arb(0)
    for c,k,w,p in f:
        if reflected:
            out += c*(arb.exp(DLOG/2)*base.exp_trig_integral(k,w,p,-arb(1)/2,lo,hi)
                      -arb.exp(-DLOG/2)*base.exp_trig_integral(k,w,p,arb(1)/2,lo,hi))
        else:
            out += c*(base.exp_trig_integral(k,w,p,arb(1)/2,lo,hi)
                      -base.exp_trig_integral(k,w,p,-arb(1)/2,lo,hi))
    return out


def assemble_schur(terms):
    beta,funcs,young=build_descriptors(terms);lo=DLOG-A
    assert (beta-PPRIME).lower()>0
    q0=1/beta;qd=beta/(beta**2-PPRIME**2)
    qr=-PPRIME/(beta**2-PPRIME**2);dq=qd-q0
    n=len(funcs);H=[[arb(0) for _ in range(n)] for _ in range(n)]
    zv=[arb(0) for _ in range(n)]
    refl=[base.reflected_desc(f) for f in funcs]
    for i,f in enumerate(funcs):
        zv[i]=(q0*inner_v(f,arb(0),A)+dq*inner_v(f,lo,A)
               +qr*inner_v(f,lo,A,reflected=True))
        for j in range(i+1):
            g=funcs[j]
            full=base.inner_desc(f,g,arb(0),A)
            collar=base.inner_desc(f,g,lo,A)
            rr=(base.inner_desc(f,refl[j],lo,A)
                +base.inner_desc(g,refl[i],lo,A))/2
            H[i][j]=H[j][i]=q0*full+dq*collar+qr*rr
    vfull=2*(arb.sinh(A)-A)
    vcollar=2*(arb.sinh(A)-arb.sinh(lo)-(A-lo))
    eta=A-DLOG/2
    vref=4*eta*arb.cosh(DLOG/2)-4*arb.sinh(eta)
    hvv=q0*vfull+dq*vcollar+qr*vref
    rows=[]
    for i in range(n):
        rows.append([(arb(1) if i==j else arb(0))-H[i][j]
                     for j in range(n)]+[-zv[i]])
    rows.append([-zv[j] for j in range(n)]+[arb(1)-hvv])
    return arb_mat(rows),beta,young


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--terms',type=int,default=10000)
    ap.add_argument('--eig',action='store_true');ns=ap.parse_args()
    Sbox,beta,young=assemble_schur(ns.terms)
    print(f'terms={ns.terms}');print(f'dimension={Sbox.nrows()}')
    print(f'beta={beta}');print(f'young_E={young[0]}');print(f'young_rho={young[3]}')
    maxrad=max(float(Sbox[i,j].rad()) for i in range(Sbox.nrows()) for j in range(Sbox.ncols()))
    print(f'max_entry_radius={maxrad}')
    if ns.eig:
        ev=Sbox.eig(algorithm='rump',multiple=True)
        print(f'minimum_eigenvalue={min(ev,key=lambda z:float(z.real.mid()))}')
