#!/usr/bin/env python3
"""Scan Q cells using a rational filter and the basis {1, 2**(-s)}.

The weighted 2 by 2 Dirichlet Gram is obtained from two FFT convolutions for
each damping scale.  Padding, discretization, and floating-point arithmetic
make this an adversarial search only, not a proof.
"""

from __future__ import annotations

import argparse

import numpy as np
from flint import acb, arb, ctx
from scipy.signal import fftconvolve

from scan_q_dyadic_center_minima import q_value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a", type=float, required=True)
    parser.add_argument("--tau-min", type=float, default=0.0)
    parser.add_argument("--tau-max", type=float, default=1000.0)
    parser.add_argument("--padding", type=float, default=100.0)
    parser.add_argument("--points-per-a", type=int, default=8)
    parser.add_argument(
        "--l-over-a",
        type=float,
        nargs="+",
        default=[0.5, 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024],
    )
    parser.add_argument("--top", type=int, default=12)
    parser.add_argument(
        "--undamped-only",
        action="store_true",
        help="scan the raw two-term Dirichlet Gram without R_L",
    )
    parser.add_argument("--digits", type=int, default=25)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if (
        args.a <= 0
        or args.tau_min < 0
        or args.tau_max < args.tau_min
        or args.padding <= 0
        or args.points_per_a < 4
        or args.top <= 0
        or min(args.l_over_a) <= 0
    ):
        raise ValueError("invalid positive scan parameter")
    ctx.dps = args.digits

    step = args.a / args.points_per_a
    padding_steps = int(np.ceil(args.padding / step))
    center_stride = 2 * args.points_per_a
    first_center_index = int(np.ceil(args.tau_min / (2 * args.a)))
    last_center_index = int(np.floor(args.tau_max / (2 * args.a)))
    center_count = last_center_index - first_center_index + 1
    grid_start = first_center_index * center_stride - padding_steps
    grid_stop = last_center_index * center_stride + padding_steps
    grid_indices = np.arange(grid_start, grid_stop + 1)
    heights = grid_indices * step

    weight = np.empty(len(heights), dtype=np.float64)
    for index, height in enumerate(heights):
        value_ball = q_value(acb(arb("0.5"), arb(str(float(height)))))
        value = complex(float(value_ball.real.mid()), float(value_ball.imag.mid()))
        weight[index] = abs(value) ** 2
    log_two = np.log(2.0)
    phased_weight = weight * np.exp(-1j * heights * log_two) / np.sqrt(2.0)

    center_indices = padding_steps + center_stride * np.arange(center_count)
    center_heights = 2 * args.a * (
        first_center_index + np.arange(center_count)
    )
    target = np.empty(center_count, dtype=np.float64)
    for index, tau in enumerate(center_heights):
        value_ball = q_value(acb(arb(str(0.5 + args.a)), arb(str(float(tau)))))
        value = complex(float(value_ball.real.mid()), float(value_ball.imag.mid()))
        target[index] = abs(value) ** 2

    e_two = np.exp(-(0.5 + args.a + 1j * center_heights) * log_two)
    kernel_indices = np.arange(-padding_steps, padding_steps + 1)
    offsets = kernel_indices * step
    poisson = args.a / (np.pi * (args.a**2 + offsets**2))
    best_moment = np.full(center_count, np.inf)
    best_l = np.full(center_count, np.nan)
    best_one_term = np.full(center_count, np.inf)
    best_norm = np.full(center_count, np.nan)
    best_overlap = np.full(center_count, np.nan + 1j * np.nan)

    multipliers: list[float | None] = (
        [None] if args.undamped_only else list(args.l_over_a)
    )
    for multiplier in multipliers:
        if multiplier is None:
            damping = np.inf
            kernel = poisson
        else:
            damping = multiplier * args.a
            rational_square = (args.a + damping) ** 2 / (damping**2 + offsets**2)
            kernel = poisson * rational_square
        moment_zero = step * fftconvolve(weight, kernel, mode="same")[center_indices]
        moment_one = step * fftconvolve(
            phased_weight, kernel, mode="same"
        )[center_indices]

        best_one_term = np.minimum(best_one_term, moment_zero)

        determinant = 0.5 * moment_zero**2 - np.abs(moment_one) ** 2
        denominator_numerator = (
            0.5 * moment_zero
            + moment_zero * np.abs(e_two) ** 2
            - 2 * np.real(moment_one * np.conj(e_two))
        )
        minimum = determinant / denominator_numerator
        improved = minimum < best_moment
        best_moment[improved] = minimum[improved]
        best_l[improved] = damping
        best_norm[improved] = moment_zero[improved]
        best_overlap[improved] = moment_one[improved]

    raw_zero = step * fftconvolve(weight, poisson, mode="same")[center_indices]
    raw_one = step * fftconvolve(
        phased_weight, poisson, mode="same"
    )[center_indices]
    raw_determinant = 0.5 * raw_zero**2 - np.abs(raw_one) ** 2
    raw_denominator = (
        0.5 * raw_zero
        + raw_zero * np.abs(e_two) ** 2
        - 2 * np.real(raw_one * np.conj(e_two))
    )
    raw_two_term = raw_determinant / raw_denominator

    ratio = best_moment / target
    finite = np.isfinite(ratio)
    worst_indices = np.flatnonzero(finite)[np.argsort(ratio[finite])[-args.top :][::-1]]
    print("NON-RIGOROUS truncated FFT two-term Dirichlet-resolvent scan")
    print("a =", args.a)
    print("tau range = [0,", center_heights[-1], "]")
    print("dyadic centers =", center_count)
    print("grid step =", step)
    print("padding =", padding_steps * step)
    print("L/a candidates =", ["infinity"] if args.undamped_only else args.l_over_a)
    print("best_ratio         tau          best_L       |Q(center)|^2")
    for index in worst_indices:
        print(
            f"{ratio[index]: .12f}  {center_heights[index]:12.6f}  "
            f"{best_l[index]: .8f}  {target[index]: .12e}"
        )
    print(
        "sampled finite centers with best ratio >= 5 =",
        int(np.sum(ratio[finite] >= 5)),
    )
    if not args.undamped_only:
        one_ratio = best_one_term / target
        raw_two_ratio = raw_two_term / target
        comparable = finite & np.isfinite(one_ratio) & np.isfinite(raw_two_ratio)
        print(
            "one-term rational failures =",
            int(np.sum(one_ratio[comparable] >= 5)),
        )
        print(
            "raw two-term failures =",
            int(np.sum(raw_two_ratio[comparable] >= 5)),
        )
        print(
            "simultaneous failures of both simpler families =",
            int(
                np.sum(
                    (one_ratio[comparable] >= 5)
                    & (raw_two_ratio[comparable] >= 5)
                )
            ),
        )
        simultaneous = comparable & (one_ratio >= 5) & (raw_two_ratio >= 5)
        simultaneous_indices = np.flatnonzero(simultaneous)
        if len(simultaneous_indices):
            print(
                "simultaneous failure candidates: tau, one_ratio, "
                "raw_two_ratio, combined_ratio, best_L"
            )
            for index in simultaneous_indices[: args.top]:
                print(
                    f"{center_heights[index]:12.6f}  "
                    f"{one_ratio[index]:.12f}  {raw_two_ratio[index]:.12f}  "
                    f"{ratio[index]:.12f}  {best_l[index]:.8f}"
                )

        # Circular-variance form from note 062, using the same L that minimizes
        # the combined two-term residual at each center.
        circular_mean = (
            np.sqrt(2.0)
            * np.exp(1j * center_heights * log_two)
            * best_overlap
            / best_norm
        )
        circular_variance = np.maximum(0.0, 1.0 - np.abs(circular_mean) ** 2)
        center_distance = np.abs(circular_mean - np.exp(-args.a * log_two)) ** 2
        delay_gain = center_distance / circular_variance
        selected_one_ratio = best_norm / target
        required_gain = np.maximum(0.0, selected_one_ratio / 5.0 - 1.0)
        gain_surplus = delay_gain - required_gain
        needs_delay = (
            comparable
            & np.isfinite(delay_gain)
            & np.isfinite(selected_one_ratio)
            & (selected_one_ratio > 5.0)
        )
        print(
            "centers where the selected L needs delay gain =",
            int(np.sum(needs_delay)),
        )
        if np.any(needs_delay):
            print(
                "selected-L delay statistics: "
                "min(Lambda), max(required), min(surplus) =",
                float(np.min(delay_gain[needs_delay])),
                float(np.max(required_gain[needs_delay])),
                float(np.min(gain_surplus[needs_delay])),
            )
            hardest = np.flatnonzero(needs_delay)[
                np.argsort(gain_surplus[needs_delay])[: args.top]
            ]
            print(
                "smallest gain surplus: tau, rho1, Lambda, required, "
                "surplus, combined_ratio, best_L"
            )
            for index in hardest:
                print(
                    f"{center_heights[index]:12.6f}  "
                    f"{selected_one_ratio[index]:.12f}  "
                    f"{delay_gain[index]:.12f}  "
                    f"{required_gain[index]:.12f}  "
                    f"{gain_surplus[index]:.12f}  "
                    f"{ratio[index]:.12f}  {best_l[index]:.8f}"
                )


if __name__ == "__main__":
    main()
