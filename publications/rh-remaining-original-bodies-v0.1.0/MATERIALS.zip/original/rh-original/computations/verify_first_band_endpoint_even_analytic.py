"""Analytic Arb assembly for the even endpoint fixed-rank Robin-tail model.

No quadrature is used.  Every full/collar/reflection matrix element is reduced
to integrals of x^k exp(i*w*x), evaluated either by a small-frequency power
series with an explicit remainder ball or by integration-by-parts recurrence.

Default model: a=log(3)/2, M=5, S=5, K=80.  Yukawa terms n<T are retained;
n>=T are omitted as positive operators.  The note-021 Young error covers the
Taylor replacement for every n>=K.

Exploratory certificate script; keep in scratch until independently reviewed.
"""

import argparse
import math

from flint import arb, acb, arb_mat, ctx


ctx.dps = 80
A0 = arb(2) / 5
A = arb(3).log() / 2
DLOG = arb(2).log()
PI = arb.pi()
PPRIME = DLOG / arb(2).sqrt()
Q = arb(1) / 4
C0 = Q.digamma() - PI.log()
M = 5
S = 5
K = 80


def root_z(b, j, steps=190):
    """Directed isolation of z tan z=2ab in (j*pi,(j+1/2)*pi)."""
    lo = arb(j) * PI
    hi = (arb(j) + arb(1)/2) * PI
    # Keep endpoint poles strictly outside the balls.
    eta = arb("1e-70")
    if j == 0:
        lo = eta
    hi -= eta
    target = 2*b*A
    for _ in range(steps):
        mid = (lo+hi)/2
        f = mid*arb.tan(mid)-target
        if f < 0:
            lo = mid
        elif f > 0:
            hi = mid
        else:
            # At high precision this should not occur before desired width.
            break
    return lo.union(hi)


def ell(b, z):
    mu = z/A
    return mu**2 / (b*(4*b**2+mu**2))


def exp_poly_integral(k, omega, lo, hi, series_terms=48):
    """Integral x^k exp(i*omega*x) dx as an acb enclosure."""
    t_upper = float((abs(omega)*hi).upper())
    iw = acb(0, omega)
    if t_upper <= 0.5 or omega.contains(0):
        total = acb(0)
        power = acb(1)
        fact = arb(1)
        for r in range(series_terms):
            if r:
                power *= iw
                fact *= r
            moment = (hi**(k+r+1)-lo**(k+r+1))/(k+r+1)
            total += power*moment/fact
        # Pointwise exponential Taylor remainder, integrated against x^k.
        # Keep the actual Arb enclosure in the remainder.  ``t_upper`` is
        # used only to choose the evaluation branch; converting it back from
        # an IEEE float could otherwise round the rigorous upper bound down.
        # ``abs(arb_ball)`` is again a signed ball and even powers may become
        # indeterminate when it straddles zero.  ``abs_upper`` is a positive
        # directed magnitude bound, which is exactly what the Taylor estimate
        # needs.
        tt = omega.abs_upper() * hi.abs_upper()
        rem = (tt**series_terms/arb(math.factorial(series_terms))
               * arb.exp(tt)
               * (hi**(k+1)-lo**(k+1))/(k+1))
        return total + acb(arb(0, rem.upper()), arb(0, rem.upper()))

    ew_hi = (iw*hi).exp()
    ew_lo = (iw*lo).exp()
    vals = [(ew_hi-ew_lo)/iw]
    for r in range(1, k+1):
        boundary = (hi**r*ew_hi-lo**r*ew_lo)/iw
        vals.append(boundary-r*vals[-1]/iw)
    return vals[k]


def trig_integral(k, omega, phase, lo, hi, sine=False):
    z = acb(0, phase).exp()*exp_poly_integral(k, omega, lo, hi)
    return z.imag if sine else z.real


# A descriptor is a list of (coefficient, power, frequency, phase), denoting
# coefficient*x^power*cos(frequency*x+phase).
def inner_desc(f, g, lo, hi):
    out = arb(0)
    for cf, kf, wf, pf in f:
        for cg, kg, wg, pg in g:
            c = cf*cg/2
            out += c*trig_integral(kf+kg, wf-wg, pf-pg, lo, hi)
            out += c*trig_integral(kf+kg, wf+wg, pf+pg, lo, hi)
    return out


def reflected_desc(g):
    """Descriptor for x -> g(DLOG-x), expanded polynomially."""
    out = []
    for c, k, w, p in g:
        for r in range(k+1):
            coeff = c*math.comb(k, r)*DLOG**(k-r)*((-1)**r)
            out.append((coeff, r, -w, w*DLOG+p))
    return out


def exp_trig_integral(k, omega, phase, rate, lo, hi):
    """Integral x^k cos(omega*x+phase)*exp(rate*x) dx."""
    lam = acb(rate, omega)
    # Here |lam| is bounded away from zero (rate=+-1/2), so recurrence is safe.
    el_hi = (lam*hi).exp(); el_lo = (lam*lo).exp()
    vals = [(el_hi-el_lo)/lam]
    for r in range(1, k+1):
        vals.append((hi**r*el_hi-lo**r*el_lo)/lam-r*vals[-1]/lam)
    return (acb(0, phase).exp()*vals[k]).real


def inner_u(f, lo, hi, reflected=False):
    """Integral f(x)*u(x) or f(x)*u(DLOG-x), u=2cosh(x/2)."""
    out = arb(0)
    for c, k, w, p in f:
        if reflected:
            out += c*(arb.exp(DLOG/2)*exp_trig_integral(k,w,p,-arb(1)/2,lo,hi)
                      +arb.exp(-DLOG/2)*exp_trig_integral(k,w,p,arb(1)/2,lo,hi))
        else:
            out += c*(exp_trig_integral(k,w,p,arb(1)/2,lo,hi)
                      +exp_trig_integral(k,w,p,-arb(1)/2,lo,hi))
    return out


def raw_term(j, k):
    theta = (arb(j)+arb(1)/2)*PI
    return (arb(1), k, theta/A, arb(k)*PI/2)


def analytic_young():
    bm = arb(K)+Q
    theta_m = (arb(M)+arb(1)/2)*PI
    qpow = 2*S+5
    series_q = bm**(-qpow)+bm**(1-qpow)/(qpow-1)
    pref = theta_m**2/(4*A0**2)
    esum = arb(0)
    for j in range(M):
        theta = (arb(j)+arb(1)/2)*PI
        zbar = theta*(2*bm*A0)/(2*bm*A0+1)
        hbar = arb(1)/2-1/(4*zbar)
        esum += theta**(2*S+2)/(
            (2*A0)**(2*S+2)*(2*S+3)
            *arb(math.factorial(S+1))**2*hbar)
    eup = pref*esum*series_q
    series3 = bm**-3+bm**-2/2
    dup = M*pref*series3
    tau = (eup/dup).sqrt()
    rho = (1+1/tau)*eup
    return eup, dup, tau, rho


def cholesky_block(B):
    n = len(B); L = [[arb(0) for _ in range(n)] for _ in range(n)]
    for i in range(n):
        d = B[i][i]-sum(L[i][k]**2 for k in range(i))
        if not (d > 0):
            raise ArithmeticError(("tail Cholesky", i, d))
        L[i][i] = d.sqrt()
        for j in range(i+1,n):
            L[j][i] = (B[j][i]-sum(L[j][k]*L[i][k] for k in range(i)))/L[i][i]
    return L


def build_descriptors(terms):
    alpha = C0
    low = []
    blocks = [[[arb(0) for _ in range(S+1)] for _ in range(S+1)]
              for _ in range(M)]
    for n in range(terms):
        b = arb(n)+Q
        zs = [root_z(b,j) for j in range(M+1)]
        es = [ell(b,z) for z in zs]
        alpha += es[M]
        if n < K:
            for j in range(M):
                z=zs[j]; mu=z/A
                norm2=A*(arb(1)/2+arb.sin(2*z)/(4*z))
                scale=((es[M]-es[j])/norm2).sqrt()
                low.append([(scale,0,mu,arb(0))])
        else:
            for j in range(M):
                z=zs[j]; eps=(arb(j)+arb(1)/2)*PI-z
                norm2=A*(arb(1)/2+arb.sin(2*z)/(4*z))
                coeff=[]
                for k in range(S+1):
                    coeff.append((-eps/A)**k/arb(math.factorial(k))/norm2.sqrt())
                d=es[M]-es[j]
                for r in range(S+1):
                    for s in range(r+1):
                        blocks[j][r][s] += d*coeff[r]*coeff[s]
                        if r != s: blocks[j][s][r]=blocks[j][r][s]
    eup,dup,tau,rho=analytic_young()
    agg=[]
    for j in range(M):
        L=cholesky_block(blocks[j])
        for col in range(S+1):
            desc=[]
            for k in range(col,S+1):
                desc.append((L[k][col]*(1+tau).sqrt(),)+raw_term(j,k)[1:])
            agg.append(desc)
    return alpha-rho, low+agg, (eup,dup,tau,rho)


def assemble_schur(terms):
    beta, funcs, young = build_descriptors(terms)
    lo=DLOG-A
    q0=1/beta
    qd=beta/(beta**2-PPRIME**2)
    qr=PPRIME/(beta**2-PPRIME**2)
    dq=qd-q0
    n=len(funcs)
    H=[[arb(0) for _ in range(n)] for _ in range(n)]
    z=[arb(0) for _ in range(n)]
    reflected=[reflected_desc(f) for f in funcs]
    for i,f in enumerate(funcs):
        z[i]=(q0*inner_u(f,arb(0),A)+dq*inner_u(f,lo,A)
              +qr*inner_u(f,lo,A,reflected=True))
        for j in range(i+1):
            g=funcs[j]
            full=inner_desc(f,g,arb(0),A)
            collar=inner_desc(f,g,lo,A)
            # Average the two analytically equal reflected expressions.
            refl=(inner_desc(f,reflected[j],lo,A)
                  +inner_desc(g,reflected[i],lo,A))/2
            H[i][j]=H[j][i]=q0*full+dq*collar+qr*refl
    ufull=2*(A+arb.sinh(A))
    ucollar=2*((A-lo)+arb.sinh(A)-arb.sinh(lo))
    uref=2*(A-lo)*arb.cosh(DLOG/2)+4*arb.sinh((A-lo)/2)
    uq=q0*ufull+dq*ucollar+qr*uref
    Srows=[[(arb(1) if i==j else arb(0))-H[i][j]+z[i]*z[j]/(1+uq)
            for j in range(n)] for i in range(n)]
    return arb_mat(Srows), beta, young


def self_test():
    """Deterministic analytic identities; external mpmath comparison is separate."""
    x0=arb("0.11"); x1=arb("0.49")
    # omega=0 exact moments, including the series branch.
    for k in range(8):
        got=trig_integral(k,arb(0),arb(0),x0,x1)
        want=(x1**(k+1)-x0**(k+1))/(k+1)
        assert got.overlaps(want), (k,got,want)
    # Reflection is involutive at the level of integrals.
    f=[raw_term(2,k) for k in range(4)]
    rr=reflected_desc(reflected_desc(f))
    assert inner_desc(f,f,DLOG-A,A).overlaps(inner_desc(rr,rr,DLOG-A,A))
    print("analytic_self_test=True")


if __name__ == "__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--terms",type=int,default=10000)
    ap.add_argument("--self-test",action="store_true")
    ap.add_argument("--eig",action="store_true")
    ns=ap.parse_args()
    if ns.self_test: self_test()
    Sbox,beta,young=assemble_schur(ns.terms)
    print(f"terms={ns.terms}")
    print(f"dimension={Sbox.nrows()}")
    print(f"beta={beta}")
    print(f"young_E={young[0]}")
    print(f"young_rho={young[3]}")
    maxrad=max(float(Sbox[i,j].rad()) for i in range(Sbox.nrows()) for j in range(Sbox.ncols()))
    print(f"max_entry_radius={maxrad}")
    if ns.eig:
        ev=Sbox.eig(algorithm="rump",multiple=True)
        print(f"minimum_eigenvalue={min(ev,key=lambda z:float(z.real.mid()))}")
