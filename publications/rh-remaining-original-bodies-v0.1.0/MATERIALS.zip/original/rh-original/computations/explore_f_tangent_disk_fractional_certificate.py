#!/usr/bin/env python3
"""Explore compact tangent-disk fractional-moment certificates for xi+xi'."""

from __future__ import annotations

import argparse
import math

import numpy as np
from flint import acb, arb, ctx
from scipy.special import loggamma, logsumexp

from scan_q_dyadic_center_minima import q_value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--band-top",
        type=float,
        required=True,
        help="A with horizontal zero depth band A/2 < delta <= A",
    )
    parser.add_argument("--tau", type=float, required=True)
    parser.add_argument("--samples", type=int, default=2048)
    parser.add_argument(
        "--coefficients",
        type=int,
        default=12,
        help="number of whitened Taylor coefficients to report",
    )
    parser.add_argument("--digits", type=int, default=30)
    parser.add_argument(
        "--q",
        type=float,
        nargs="+",
        default=[0.0002, 0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 1.0],
    )
    return parser.parse_args()


def q_midpoint(real: float, imag: float) -> complex:
    s_ball = acb(arb(str(real)), arb(str(imag)))
    q_ball = q_value(s_ball)
    return complex(float(q_ball.real.mid()), float(q_ball.imag.mid()))


def log_gamma_normalization(s: complex) -> complex:
    """Log of s G(s)/(s-1) = s^2 Gamma(s/2)/(2 pi^(s/2))."""
    return (
        math.log(0.5)
        + 2.0 * np.log(s)
        - 0.5 * s * math.log(math.pi)
        + loggamma(s / 2.0)
    )


def logabs_f(real: float, imag: float) -> float:
    """Return log|xi(s)+xi'(s)| through the stable de-gamma Q coordinate."""
    q_mid = q_midpoint(real, imag)
    if q_mid == 0:
        return -math.inf
    s = complex(real, imag)
    return math.log(abs(q_mid)) + float(log_gamma_normalization(s).real)


def main() -> None:
    args = parse_args()
    if (
        not 0 < args.band_top <= 0.5
        or args.samples < 32
        or args.coefficients < 2
        or args.digits < 15
        or not args.q
        or min(args.q) <= 0
    ):
        raise ValueError("invalid tangent-disk parameters")
    ctx.dps = args.digits

    horizontal_depth = 0.75 * args.band_top
    radius = horizontal_depth
    center_real = 0.5 + horizontal_depth
    center_logabs = logabs_f(center_real, args.tau)
    center = complex(center_real, args.tau)
    center_q = q_midpoint(center_real, args.tau)
    center_log_normalization = log_gamma_normalization(center)

    theta = 2.0 * math.pi * (
        np.arange(args.samples, dtype=np.float64) + 0.5
    ) / args.samples
    delta_logabs = np.empty(args.samples, dtype=np.float64)
    normalized_f = np.empty(args.samples, dtype=np.complex128)
    unit_circle = np.exp(1j * theta)
    for index, angle in enumerate(theta):
        real = center_real + radius * math.cos(float(angle))
        imag = args.tau + radius * math.sin(float(angle))
        delta_logabs[index] = logabs_f(real, imag) - center_logabs
        point = complex(real, imag)
        normalized_f[index] = (
            q_midpoint(real, imag)
            / center_q
            * np.exp(
                log_gamma_normalization(point) - center_log_normalization
            )
        )

    # If f(c+Rz)/f(c) = sum a_n z^n, midpoint Fourier extraction gives
    # a_1 = R f'(c)/f(c). Multiplication by exp(-a_1 z) kills the first jet.
    first_jet = np.mean(normalized_f * np.conj(unit_circle))
    whitened_delta_logabs = delta_logabs - np.real(first_jet * unit_circle)
    whitened_normalized_f = normalized_f * np.exp(-first_jet * unit_circle)

    print("NON-RIGOROUS tangent-disk fractional-moment scan")
    print("band A/2 < delta <= A with A =", args.band_top)
    print("center =", complex(center_real, args.tau))
    print("outer radius =", radius)
    print("guaranteed inner radius =", radius / math.sqrt(5.0))
    print("samples =", args.samples)
    print(
        "delta log|f|: min, mean, max, std =",
        float(np.min(delta_logabs)),
        float(np.mean(delta_logabs)),
        float(np.max(delta_logabs)),
        float(np.std(delta_logabs)),
    )
    print("R f'(c)/f(c) =", first_jet)
    print(
        "q             raw log-ratio/q   raw pass   "
        "whitened log-ratio/q   whitened pass"
    )
    for q in args.q:
        raw_log_ratio = float(
            logsumexp(2.0 * q * delta_logabs) - math.log(args.samples)
        )
        whitened_log_ratio = float(
            logsumexp(2.0 * q * whitened_delta_logabs)
            - math.log(args.samples)
        )
        print(
            f"{q: .8g}    {raw_log_ratio / q: .12f}    "
            f"{raw_log_ratio < q * math.log(5.0)!s:5s}      "
            f"{whitened_log_ratio / q: .12f}    "
            f"{whitened_log_ratio < q * math.log(5.0)}"
        )

    total_whitened_energy = float(np.mean(np.abs(whitened_normalized_f) ** 2))
    coefficients = np.array(
        [
            np.mean(
                whitened_normalized_f * np.conj(unit_circle) ** degree
            )
            for degree in range(args.coefficients + 1)
        ],
        dtype=np.complex128,
    )
    energies = np.abs(coefficients) ** 2
    print("whitened Taylor coefficient energies")
    print("degree        coefficient                         energy")
    for degree, (coefficient, energy) in enumerate(zip(coefficients, energies)):
        print(f"{degree:4d}    {coefficient!s:>32s}    {energy:.14e}")
    print(
        "total energy, reported energy, unresolved tail =",
        total_whitened_energy,
        float(np.sum(energies)),
        total_whitened_energy - float(np.sum(energies)),
    )


if __name__ == "__main__":
    main()
