#!/usr/bin/env python3
"""Explore higher logarithmic-jet whitening on a tangent disk for xi+xi'."""

from __future__ import annotations

import argparse
import math

import numpy as np
from flint import acb, acb_series, arb, ctx

from explore_f_tangent_disk_fractional_certificate import (
    log_gamma_normalization,
    logabs_f,
    q_midpoint,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--band-top", type=float, required=True)
    parser.add_argument("--tau", type=float, required=True)
    parser.add_argument("--samples", type=int, default=2048)
    parser.add_argument("--max-order", type=int, default=6)
    parser.add_argument("--digits", type=int, default=40)
    return parser.parse_args()


def scaled_logarithmic_jets(
    center_real: float, tau: float, radius: float, order: int
) -> list[complex]:
    """Return coefficients [z^n] log(f(c+Rz)/f(c)), 1 <= n <= order."""
    center = acb(arb(str(center_real)), arb(str(tau)))
    variable = acb_series([center, acb(arb(str(radius)))], order + 2)
    gamma_factor = (
        variable
        * (variable - 1)
        / 2
        * (-variable * arb.pi().log() / 2).exp()
        * (variable / 2).gamma()
    )
    xi_series = gamma_factor * variable.zeta()
    f_series = acb_series(
        [
            xi_series[degree] + (degree + 1) * xi_series[degree + 1] / radius
            for degree in range(order + 1)
        ],
        order + 1,
    )
    log_series = (f_series / f_series[0]).log()
    return [
        complex(float(log_series[n].real.mid()), float(log_series[n].imag.mid()))
        for n in range(1, order + 1)
    ]


def main() -> None:
    args = parse_args()
    if (
        not 0 < args.band_top <= 0.5
        or args.samples < 64
        or not 1 <= args.max_order <= 32
        or args.digits < 20
    ):
        raise ValueError("invalid higher-jet whitening parameters")
    ctx.dps = args.digits
    ctx.cap = args.max_order + 3

    radius = 0.75 * args.band_top
    center_real = 0.5 + radius
    center = complex(center_real, args.tau)
    center_q = q_midpoint(center_real, args.tau)
    center_log_normalization = log_gamma_normalization(center)
    center_logabs = logabs_f(center_real, args.tau)
    log_jets = scaled_logarithmic_jets(
        center_real, args.tau, radius, args.max_order
    )

    theta = 2.0 * math.pi * (
        np.arange(args.samples, dtype=np.float64) + 0.5
    ) / args.samples
    unit_circle = np.exp(1j * theta)
    normalized_f = np.empty(args.samples, dtype=np.complex128)
    delta_logabs = np.empty(args.samples, dtype=np.float64)
    for index, z in enumerate(unit_circle):
        point = center + radius * z
        point_q = q_midpoint(point.real, point.imag)
        normalized_f[index] = point_q / center_q * np.exp(
            log_gamma_normalization(point) - center_log_normalization
        )
        delta_logabs[index] = logabs_f(point.real, point.imag) - center_logabs

    print("NON-RIGOROUS higher logarithmic-jet tangent-disk whitening")
    print("center =", center)
    print("radius =", radius)
    print("samples =", args.samples)
    print("order   mean-square ratio   log ratio   factor-5 pass")
    polynomial = np.zeros(args.samples, dtype=np.complex128)
    for order, coefficient in enumerate(log_jets, start=1):
        polynomial += coefficient * unit_circle**order
        whitened = normalized_f * np.exp(-polynomial)
        mean_square = float(np.mean(np.abs(whitened) ** 2))
        print(
            f"{order:5d}   {mean_square:.14f}   {math.log(mean_square):.12f}   "
            f"{mean_square < 5.0}"
        )
        if order <= 8:
            print("        scaled log jet =", coefficient)


if __name__ == "__main__":
    main()
