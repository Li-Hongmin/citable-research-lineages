#!/usr/bin/env python3
"""Exact triangular-minor certificate for [A_V15,D]."""
from fractions import Fraction
import sympy as sp


def v15(u: Fraction) -> Fraction:
    return u**2 * (1-u)**9 * (1024*u**4 + 207*u**3 - 57*u**2 - 27*u - 3)


def commutator(N: int) -> sp.Matrix:
    rows = []
    for a in range(1, N + 1):
        row = []
        for b in range(1, N + 1):
            q = a // b
            value = sum(
                (v15(Fraction(b*c, a)) for c in range(1, q + 1) if a % c != 0),
                Fraction(0),
            )
            row.append(sp.Rational(value.numerator, value.denominator))
        rows.append(row)
    return sp.Matrix(rows)


def main() -> None:
    for N in range(3, 25):
        M = commutator(N)
        r = (N - 1) // 2
        rows = [2*i + 1 for i in range(1, r + 1)]
        cols = list(range(1, r + 1))
        minor = M.extract([a - 1 for a in rows], [b - 1 for b in cols])
        assert minor.det() != 0
        assert M.rank() >= r

        # Verify the finite identity A*mu = D^{-1} A e_1 - D^{-1} C mu.
        Avec = sp.zeros(N, 1)
        Cvec = sp.zeros(N, 1)
        mu = [0] + [sp.mobius(a) for a in range(1, N + 1)]
        for a in range(1, N + 1):
            Avec[a - 1] = sp.Rational(v15(Fraction(1, a)).numerator,
                                       v15(Fraction(1, a)).denominator)
            Cvec[a - 1] = sum(M[a - 1, b - 1] * mu[b] for b in range(1, N + 1))
        Dinv = sp.zeros(N, N)
        for a in range(1, N + 1):
            for b in range(1, a + 1):
                if a % b == 0:
                    Dinv[a - 1, b - 1] = mu[a // b]
        lhs = commutator(N) * sp.Matrix(mu[1:])
        # A*mu is evaluated directly from the defining lower-triangular matrix.
        A = sp.zeros(N, N)
        for a in range(1, N + 1):
            for b in range(1, a + 1):
                x = v15(Fraction(b, a))
                A[a - 1, b - 1] = sp.Rational(x.numerator, x.denominator)
        assert A * sp.Matrix(mu[1:]) == Dinv * Avec - Dinv * lhs
    print("exact commutator triangular-minor certificate passed for N=3..24")


if __name__ == "__main__":
    main()
