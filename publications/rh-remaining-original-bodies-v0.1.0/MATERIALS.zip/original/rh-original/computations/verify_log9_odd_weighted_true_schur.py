"""Corrected fixed rank-40 odd true-Schur certificate at a=log(3).

Fixed: odd parity, R=280, N=500, q=280,...,999, rank=40.
Stops at the first failed strict inequality.  Scratch only until it passes.
"""
from fractions import Fraction
import sys,time,re
import numpy as np
from flint import arb,acb,arb_mat,ctx
ctx.prec=int(sys.argv[1]) if len(sys.argv)>1 else 192
R,N,K0,K1,RK=280,500,280,1000,40
pi=arb.pi();a=arb(3).log();t0=time.time()
def A(x):x=Fraction(x);return arb(x.numerator)/x.denominator
def rate(k):return acb(A(k[0]),A(k[1])*pi/a)
def Iexp(k,lo,hi):
 if k==(Fraction(0),Fraction(0)):return acb(hi-lo)
 z=rate(k);return ((z*hi).exp()-(z*lo).exp())/z
def inner(r1,r2,lo,hi):
 s=acb(0)
 for c1,k1 in r1:
  for c2,k2 in r2:s+=c1.conjugate()*c2*Iexp((k1[0]+k2[0],-k1[1]+k2[1]),lo,hi)
 return s.real
def basis(k):
 q=Fraction(2*k+1,2);c=(arb(2)/a).sqrt()/2
 return [(acb(0,-c),(Fraction(0),q)),(acb(0,c),(Fraction(0),-q))]
def transform(rep,kind,d):
 out=[]
 for c,k in rep:
  z=rate(k)
  if kind=='ref':out.append((c*(z*d).exp(),(-k[0],-k[1])))
  elif kind=='plus':out.append((c*(z*d).exp(),k))
  else:out.append((c*(-z*d).exp(),k))
 return out
def rankrep(n):
 ck=Fraction(4*n+1,2);c=A(ck);em=(-c*a).exp();den=(1+em*em).sqrt()
 return [(acb(em/den),(ck,Fraction(0))),(acb(-em/den),(-ck,Fraction(0)))]
def polar():return [(acb(1),(Fraction(1,2),Fraction(0))),(acb(-1),(Fraction(-1,2),Fraction(0)))]

d2=arb(2).log();d3=arb(3).log();d4=2*d2;d5=arb(5).log();d7=arb(7).log();d8=3*d2
al={2:d2/arb(2).sqrt(),3:d3/arb(3).sqrt(),4:d2/2,5:d5/arb(5).sqrt(),7:d7/arb(7).sqrt(),8:d2/arb(8).sqrt()}
terms=[(al[2],'ref',d2,arb(0),d2),(-al[2],'plus',d2,arb(0),a-d2),(-al[2],'minus',d2,d2,a)]
for n,d in [(3,d3),(4,d4),(5,d5),(7,d7),(8,d8)]:terms.append((al[n],'ref',d,d-a,a))
BP=[basis(k) for k in range(R)];BQ=[basis(k) for k in range(K0,K1)]
FUN=[rankrep(n) for n in range(N)]+[polar()];sg=[arb(1)]*N+[arb(-1)]
print('stage1_q64_loaded',flush=True)
qd=np.load('scratch/log9_odd_q280_1000_rank40_q64.npz',allow_pickle=True)
denq=int(str(qd['denominator']));nums=qd['numerator']
Q=arb_mat([[arb(int(str(nums[i,j])))/denq for j in range(K1-K0)] for i in range(RK)])
QG=Q*Q.transpose()
# Strict Cholesky of QG.
L=[[arb(0) for _ in range(RK)] for _ in range(RK)]
for i in range(RK):
 p=QG[i,i]-sum((L[i][k]*L[i][k] for k in range(i)),arb(0))
 if p.lower()<=0:raise ArithmeticError(('QGram_cholesky',i,p))
 L[i][i]=p.sqrt()
 for j in range(i+1,RK):L[j][i]=(QG[j,i]-sum((L[j][k]*L[i][k] for k in range(i)),arb(0)))/L[i][i]
Lm=arb_mat(L)
print('stage1_QGram_cholesky_pass',time.time()-t0,flush=True)

# Build P-Q coupling Vraw=P A Q for the finite N=500 lower operator.
HP=arb_mat([[inner(BP[i],FUN[n],arb(0),a) for n in range(N+1)] for i in range(R)])
HQ=arb_mat([[inner(BQ[j],FUN[n],arb(0),a) for n in range(N+1)] for j in range(K1-K0)])
HS=arb_mat([[HP[i,n]*sg[n] for n in range(N+1)] for i in range(R)])
Prows=[[arb(0) for _ in range(K1-K0)] for _ in range(R)]
for coeff,kind,d,lo,hi in terms:
 TQ=[transform(x,kind,d) for x in BQ]
 for i in range(R):
  for j in range(K1-K0):Prows[i][j]+=coeff*inner(BP[i],TQ[j],lo,hi)
Vraw=arb_mat(Prows)+HS*HQ.transpose()
print('stage2_raw_amplitudes_built',time.time()-t0,flush=True)

# Transform to the old exact Householder coordinates.
ex=np.load('scratch/log9_odd_R280_N400_exact_small_map.npz')
Vphysical=arb_mat([[Vraw[i,j] for j in range(K1-K0)] for i in range(R)])
for row in ex['whist_arb']:
 h=arb_mat([[arb(str(z))] for z in row]);hn=(h.transpose()*h)[0,0]
 Vraw=Vraw-h*((arb(2)/hn)*(h.transpose()*Vraw))

rho=arb('2.677899')+2*(a.sinh()-a)
qq=A(Fraction(2*R+1,2));mu=acb(arb(1)/4,qq*pi/(2*a)).digamma().real-pi.log()-rho
weights=[]
for q in range(K0,K1):
 fq=Fraction(2*q+1,2);dq=acb(arb(1)/4,A(fq)*pi/(2*a)).digamma().real-pi.log()-rho
 w=1/mu-1/dq
 if q==K0:
  weights.append(arb(0))
 else:
  if w.lower()<=0:raise ArithmeticError(('weight',q,w))
  weights.append(w.sqrt())
Tw=arb_mat([[Vraw[i,j]*weights[j] for j in range(K1-K0)] for i in range(R)])
Twphysical=arb_mat([[Vphysical[i,j]*weights[j] for j in range(K1-K0)] for i in range(R)])
# Nonorthogonal dyadic row span: F=Tw Q^T L^{-T}, via L F^T=Q Tw^T.
Braw=Tw*Q.transpose()
F=Lm.solve(Braw.transpose()).transpose()
U=arb_mat([[F[i,j] for j in range(RK)] for i in range(5)])
V=arb_mat([[F[i+5,j] for j in range(RK)] for i in range(275)])
Zraw=arb_mat([[arb(str(ex['z_arb'][i,j])) for j in range(5)] for i in range(R)])
Afull=Zraw.transpose()*Twphysical
Econtract=Afull*Afull.transpose()
if 'even' in __file__:
 np.savez('scratch/log9_even_contract_amp_q280_1000_arb.npz',
          amp=np.array([[str(Afull[i,j]) for j in range(K1-K0)] for i in range(5)]))
 if '--export-contract-amp-only' in sys.argv:
  print('EXPORTED_EVEN_CONTRACT_AMPLITUDES',flush=True);raise SystemExit(0)
Fphysical=Twphysical*Q.transpose()
Fphysical=Lm.solve(Fphysical.transpose()).transpose()
Ueff_direct=Zraw.transpose()*Fphysical
tail=Econtract-Ueff_direct*Ueff_direct.transpose();tail=(tail+tail.transpose())/2
tail_trace=sum((tail[i,i] for i in range(5)),arb(0))
if tail_trace.upper()>=arb('5e-37').lower():raise ArithmeticError(('core_tail_trace',tail_trace))
print('stage3_core_tail_trace',tail_trace,'PASS',time.time()-t0,flush=True)

# Verified old-C solve with 40 right-hand sides.
C=arb_mat([[arb(str(ex['c_arb'][i,j])) for j in range(275)] for i in range(275)])
Y=C.solve(V)
G=V.transpose()*Y
Xold=arb_mat([[arb(str(ex['x_arb'][i,j])) for j in range(275)] for i in range(5)])
Ueff=U-Xold*Y
# Independent identity check against the direct physical contraction.
identity_err=Ueff-Ueff_direct
identity_inf=arb(0)
for i in range(5):
 rowsum=sum((abs(identity_err[i,j]) for j in range(RK)),arb(0))
 if rowsum.upper()>identity_inf.upper():identity_inf=rowsum
print('Ueff_contract_identity_inf',identity_inf,flush=True)
ImG=arb_mat([[G[i,j]+(arb(1) if i==j else arb(0)) for j in range(RK)] for i in range(RK)])
Z=ImG.solve(Ueff.transpose())
corr=Ueff*Z
print('stage4_verified_C_solve_PASS',time.time()-t0,flush=True)

S=arb_mat([[arb(str(ex['small_arb'][i,j])) for j in range(5)] for i in range(5)])
SL=arb_mat([[S[i,j]+corr[i,j]-(tail_trace if i==j else arb(0)) for j in range(5)] for i in range(5)])
SL=(SL+SL.transpose())/2
# Symmetric diagonal-pivoted LDL.
T=[[SL[i,j] for j in range(5)] for i in range(5)];perm=list(range(5));pivs=[]
for k in range(5):
 p=max(range(k,5),key=lambda i:float(T[i][i].mid()))
 if p!=k:
  T[k],T[p]=T[p],T[k]
  for row in T:row[k],row[p]=row[p],row[k]
  perm[k],perm[p]=perm[p],perm[k]
 piv=T[k][k];pivs.append(piv);print('pivot',k,piv,flush=True)
 if not (piv>0):raise ArithmeticError(('final_pivot',k,piv,perm))
 for i in range(k+1,5):
  for j in range(i,5):
   z=T[j][i]-T[j][k]*T[i][k]/piv;T[j][i]=z;T[i][j]=z
print('RANK40_TRUE_SCHUR_CERTIFIED','perm',perm,'tail',tail_trace,'time',time.time()-t0,flush=True)
