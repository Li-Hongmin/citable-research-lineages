"""OMEN-only exact certificate for the x=5 Beta channel bound."""

import sympy as sp


def main() -> None:
    m, n, t = sp.symbols("m n t", integer=True, nonnegative=True)
    q = sp.Rational(5, 7)
    s = 1 - t
    p10 = sp.expand(
        1
        - sp.Rational(2, 7) * sum(q**k * s**k for k in range(11))
        - sp.Rational(2, 7) * q**11 / (1 - q)
    )
    beta_expectation = sum(
        coefficient * sp.rf(m, j) / sp.rf(2 * m + 3, j)
        for (j,), coefficient in sp.Poly(p10, t).terms()
    )
    target = (3 * m + 8) / (6 * (m - 1))
    numerator = sp.Poly(
        sp.together(beta_expectation - target).as_numer_denom()[0], m
    )
    shifted = sp.Poly(sp.expand(numerator.as_expr().subs(m, n + 100)), n)
    assert all(coefficient > 0 for coefficient in shifted.all_coeffs())
    print("X5_BETA_CHANNEL_OK", "degree", numerator.degree(), "m>=100")


if __name__ == "__main__":
    main()
