from fractions import Fraction


def mobius(n: int) -> int:
    if n == 1:
        return 1
    x, parity, p = n, 0, 2
    while p * p <= x:
        if x % p == 0:
            x //= p
            parity ^= 1
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        parity ^= 1
    return -1 if parity else 1


def check(X: int, q: int) -> None:
    J = 1
    while q**J <= X:
        J += 1
    support = q * X
    b = [0] * (support + 1)
    for m in range(1, support + 1):
        b[m] = mobius(m) if m <= X else 0
        if m % q == 0 and m // q <= X:
            b[m] -= q * mobius(m // q)

    def tail(k: int) -> Fraction:
        return sum((Fraction(b[m], m) for m in range(k, support + 1)), Fraction(0))

    A = sum((Fraction(mobius(n), n) for n in range(1, X + 1)), Fraction(0))
    chain_sum = sum((tail(q**j) for j in range(1, J + 1)), Fraction(0))
    assert A == -chain_sum

    energy = sum(
        (2 * k - 1) * tail(k) ** 2 for k in range(1, support + 1)
    )
    chain_energy = sum(
        (2 * q**j - 1) * tail(q**j) ** 2 for j in range(1, J + 1)
    )
    c_partial = sum(
        (Fraction(1, 2 * q**j - 1) for j in range(1, J + 1)), Fraction(0)
    )
    assert A * A <= c_partial * chain_energy <= c_partial * energy


def main() -> None:
    for q in (2, 3, 4, 5):
        for X in range(1, 81):
            check(X, q)
    print("q-adic chain energy gate verified for q=2,3,4,5 and X=1..80")


if __name__ == "__main__":
    main()
