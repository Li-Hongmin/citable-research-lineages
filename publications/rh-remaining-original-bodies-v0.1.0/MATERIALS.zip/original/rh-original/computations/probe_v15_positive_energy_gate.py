#!/usr/bin/env -S uv run --script
# /// script
# dependencies = ["mpmath", "numpy"]
# ///
"""Finite diagnostic for the |h|-weighted positive-energy gate.

This is deliberately not a proof.  It samples a finite frequency window and
therefore does not control the tail, the infinite divisor completion, or any
uniform-in-z estimate.
"""

from __future__ import annotations

import argparse
import math

import mpmath as mp
import numpy as np


K_NUMERATOR = mp.mpf(415134720)
K_DENOMINATOR = (2, 4, 6, 8, 9, 10, 11, 12, 13, 14, 15)


def mobius_sieve(n: int) -> np.ndarray:
    mu = np.ones(n + 1, dtype=np.int8)
    prime = np.ones(n + 1, dtype=bool)
    mu[0] = 0
    for p in range(2, n + 1):
        if not prime[p]:
            continue
        mu[p::p] *= -1
        if p * p <= n:
            mu[p * p :: p * p] = 0
        prime[p * p :: p] = False
    return mu


def kernel(s: mp.mpc) -> mp.mpc:
    out = K_NUMERATOR * (s - 1)
    for q in K_DENOMINATOR:
        out /= s + q
    return out


def sample(max_z: int, window: float, grid: int, dps: int) -> None:
    mp.mp.dps = dps
    freq = np.linspace(-window, window, grid, dtype=float)
    h = np.empty(grid, dtype=float)
    for i, t in enumerate(freq):
        z = mp.mpc(0, float(t))
        h[i] = float(mp.re(mp.zeta(z) * kernel(z)))
    weight = np.abs(h)
    mu = mobius_sieve(max_z)
    values = np.arange(1, max_z + 1, dtype=float)
    logs = np.log(values)
    targets = (20, 40, 80, 120, 200, 300, 400, 600, 800, 1000, 2000, 3000, 4000, 5000)
    targets = tuple(z for z in targets if z <= max_z)
    integrate = np.trapezoid if hasattr(np, "trapezoid") else np.trapz
    print(f"window={window:g}, grid={grid}, max_z={max_z}, dps={dps}")
    print(f"sampled |h| integral={float(integrate(weight, freq)):.12g}")
    print("z energy energy/z")
    for z in targets:
        coeff = mu[1 : z + 1].astype(float)
        phase = np.exp(1j * np.outer(freq, logs[:z]))
        poly = phase @ coeff
        energy = float(integrate(weight * np.abs(poly) ** 2, freq) / (2 * math.pi))
        print(f"{z:4d} {energy:.12g} {energy / z:.12g}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-z", type=int, default=1000)
    parser.add_argument("--window", type=float, default=160.0)
    parser.add_argument("--grid", type=int, default=8192)
    parser.add_argument("--dps", type=int, default=30)
    args = parser.parse_args()
    sample(args.max_z, args.window, args.grid, args.dps)


if __name__ == "__main__":
    main()
