"""Approximate all dyadic rank-one OPA residuals on a height interval.

For fixed Cayley scale ``a``, both Toeplitz moments are convolutions of the
critical-line weight ``|Q(1/2+it)|^2``:

    mu_0(tau) = int w(t) P_a(t-tau) dt,
    mu_1(tau) = int w(t) P_a(t-tau) conjugate(z(t-tau)) dt.

The convolution is truncated to a finite padding radius and discretized on a
uniform grid, so this script is an adversarial search tool, not a certificate.
Candidates must be rechecked by Cayley quadrature or Arb interval bounds.
"""

from __future__ import annotations

import argparse
import heapq
import math

import numpy as np
from flint import acb, acb_series, arb, ctx
from scipy.signal import fftconvolve


def q_value(s: acb) -> acb:
    variable = acb_series([s, acb(1)], 2)
    zeta_series = variable.zeta()
    zeta_value = zeta_series[0]
    zeta_derivative = zeta_series[1]
    c_value = (
        1
        + 1 / s
        + 1 / (s - 1)
        - arb.pi().log() / 2
        + (s / 2).digamma() / 2
    )
    return (s - 1) / s * (zeta_derivative + c_value * zeta_value)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a", type=float, required=True)
    parser.add_argument("--tau-max", type=float, default=1000.0)
    parser.add_argument("--padding", type=float, default=200.0)
    parser.add_argument("--points-per-a", type=int, default=8)
    parser.add_argument("--top", type=int, default=12)
    parser.add_argument("--digits", type=int, default=25)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if (
        args.a <= 0
        or args.tau_max < 0
        or args.padding <= 0
        or args.points_per_a < 4
        or args.top <= 0
    ):
        raise ValueError("invalid positive scale, interval, resolution, or top count")
    ctx.dps = args.digits

    step = args.a / args.points_per_a
    padding_steps = math.ceil(args.padding / step)
    maximum_steps = math.ceil(args.tau_max / step)
    grid_indices = np.arange(-padding_steps, maximum_steps + padding_steps + 1)
    heights = grid_indices * step

    weight = np.empty(len(heights), dtype=np.float64)
    for index, height in enumerate(heights):
        value_ball = q_value(acb(arb("0.5"), arb(str(float(height)))))
        value = complex(float(value_ball.real.mid()), float(value_ball.imag.mid()))
        weight[index] = abs(value) ** 2

    kernel_indices = np.arange(-padding_steps, padding_steps + 1)
    offsets = kernel_indices * step
    poisson = args.a / (np.pi * (args.a**2 + offsets**2))
    z_value = (-args.a + 1j * offsets) / (args.a + 1j * offsets)

    moment_zero = step * fftconvolve(weight, poisson, mode="same")
    # Convolution reverses the physical offset; z_value is therefore the
    # correct kernel for the moment defined with conjugate(z(t-tau)).
    moment_one = step * fftconvolve(weight, poisson * z_value, mode="same")

    center_stride = 2 * args.points_per_a
    center_count = int(args.tau_max // (2 * args.a)) + 1
    largest: list[tuple[float, float, float, float, float]] = []

    for center_index in range(center_count):
        tau = 2 * args.a * center_index
        array_index = padding_steps + center_index * center_stride
        mu_zero = float(moment_zero[array_index])
        mu_one = complex(moment_one[array_index])
        residual = mu_zero - abs(mu_one) ** 2 / mu_zero

        center_ball = q_value(acb(arb(str(0.5 + args.a)), arb(str(tau))))
        center_value = complex(
            float(center_ball.real.mid()), float(center_ball.imag.mid())
        )
        target = abs(center_value) ** 2
        error_square = 1 - target / residual
        zero_error_square = 1 - target / mu_zero

        item = (error_square, tau, residual, zero_error_square, target)
        if len(largest) < args.top:
            heapq.heappush(largest, item)
        elif error_square > largest[0][0]:
            heapq.heapreplace(largest, item)

    print("NON-RIGOROUS truncated FFT convolution scan")
    print("a =", args.a)
    print("tau range = [0,", 2 * args.a * (center_count - 1), "]")
    print("dyadic centers =", center_count)
    print("grid step =", step)
    print("kernel and boundary padding =", padding_steps * step)
    print("E1^2              tau           r1              E0^2          |Q(center)|^2")
    for error_square, tau, residual, zero_error_square, target in sorted(
        largest, reverse=True
    ):
        print(
            f"{error_square: .12f}  {tau:12.6f}  {residual: .12e}  "
            f"{zero_error_square: .12f}  {target: .12e}"
        )


if __name__ == "__main__":
    main()
