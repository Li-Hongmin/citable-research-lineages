"""Canonical graph-row rank-five even true-Schur certificate."""
EVEN_RK=5
EVEN_Q_PATH='scratch/log9_even_q280_1000_canonical5_q64.npz'
src=open('computations/log9_even_certificate_wrapper.py',encoding='utf-8').read()
exec(compile(src,__file__,'exec'))
