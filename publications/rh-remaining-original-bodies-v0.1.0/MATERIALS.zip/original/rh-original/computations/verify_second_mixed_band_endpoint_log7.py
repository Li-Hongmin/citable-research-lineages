"""Rigorous Arb--Feshbach certificate at a=log(7)/2.

Reuses the exact exponential-integral assembly of the log(5)/2 verifier,
adds the n=5 reflection, and replaces the crude prime norm by the certified
two-step Schur bound.  The even sector uses a four-dimensional near-kernel
Schur certificate; the odd sector uses direct interval LDL.

Commands:
    uv run --with python-flint --with numpy python \
      computations/verify_second_mixed_band_endpoint_log7.py 192 128 400 +
    uv run --with python-flint --with numpy python \
      computations/verify_second_mixed_band_endpoint_log7.py 256 128 400 -
"""

with open(
    "computations/verify_first_mixed_band_endpoint_log5.py",
    encoding="utf-8",
) as handle:
    source = handle.read()

changes = {
    '"""Rigorous Arb--Feshbach certificate at a=log(5)/2.':
        '"""Rigorous Arb--Feshbach certificate at a=log(7)/2.',
    "pi=arb.pi(); a=arb(5).log()/2":
        "pi=arb.pi(); a=arb(7).log()/2",
    "d2=arb(2).log();d3=arb(3).log();d4=2*d2":
        "d2=arb(2).log();d3=arb(3).log();d4=2*d2;d5=arb(5).log()",
    "alpha2=d2/arb(2).sqrt();alpha3=d3/arb(3).sqrt();alpha4=d2/2":
        "alpha2=d2/arb(2).sqrt();alpha3=d3/arb(3).sqrt();"
        "alpha4=d2/2;alpha5=d5/arb(5).sqrt()",
    "TERMS += [(-eps*alpha3,'ref',d3,d3-a,a),"
    "(-eps*alpha4,'ref',d4,d4-a,a)]":
        "TERMS += [(-eps*alpha3,'ref',d3,d3-a,a),"
        "(-eps*alpha4,'ref',d4,d4-a,a),"
        "(-eps*alpha5,'ref',d5,d5-a,a)]",
    "prime_bound=2*alpha2+alpha3+alpha4":
        "prime_bound=((alpha2+alpha3)*(2*alpha2+alpha3)"
        "+alpha4*(alpha2+alpha3+alpha4)"
        "+alpha5*(alpha2+alpha3+alpha4+alpha5)).sqrt()",
    "L=[[arb(0) for _ in range(R)] for _ in range(R)];"
    "dd=[arb(0) for _ in range(R)];mn=None":
        "if PAR=='+':\n"
        " exec(open('computations/verify_second_mixed_band_endpoint_log7_even_block.py',"
        "encoding='utf-8').read())\n"
        "L=[[arb(0) for _ in range(R)] for _ in range(R)];"
        "dd=[arb(0) for _ in range(R)];mn=None",
}

for old, new in changes.items():
    assert source.count(old) == 1, (old, source.count(old))
    source = source.replace(old, new)

exec(compile(source, __file__, "exec"))
