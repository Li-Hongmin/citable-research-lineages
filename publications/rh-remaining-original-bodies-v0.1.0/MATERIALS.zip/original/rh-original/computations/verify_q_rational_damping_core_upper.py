#!/usr/bin/env python3
"""Rigorous finite-interval upper bound for a rationally damped Q moment.

For

    R_L(s) = (a + L) / (s - (1/2 - L + i*tau)),

the factor is analytic in Re(s) > 1/2 and R_L(1/2+a+i*tau)=1.
This script partitions [tau-radius, tau+radius] into Arb balls and gives a
rigorous upper bound for the corresponding part of

    integral P_{a,tau}(t) |Q(1/2+it) R_L(1/2+it)|^2 dt.

It does not bound the two infinite tails; those must be added separately.
"""

from __future__ import annotations

import argparse
from decimal import Decimal, getcontext
from itertools import chain

from flint import acb, arb, ctx

from verify_q_reverse_poisson_failure import q_value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a", type=str, required=True)
    parser.add_argument("--tau", type=str, required=True)
    parser.add_argument("--damping-scale", type=str, default="1")
    parser.add_argument("--radius", type=str, default="5")
    parser.add_argument(
        "--inner-radius",
        type=str,
        default="0",
        help="if positive, bound only inner-radius <= |t-tau| <= radius",
    )
    parser.add_argument("--step", type=str, default="0.001")
    parser.add_argument("--digits", type=int, default=30)
    return parser.parse_args()


def finite_upper(
    a_decimal: Decimal,
    tau_decimal: Decimal,
    damping_decimal: Decimal,
    inner_radius_decimal: Decimal,
    radius_decimal: Decimal,
    step_decimal: Decimal,
) -> tuple[arb, int]:
    """Return an outward-rounded upper bound on a symmetric finite annulus."""
    if min(a_decimal, damping_decimal, radius_decimal, step_decimal) <= 0:
        raise ValueError("a, damping scale, radius, and step must be positive")
    if inner_radius_decimal < 0 or inner_radius_decimal >= radius_decimal:
        raise ValueError("inner radius must satisfy 0 <= inner radius < radius")

    side_count_decimal = (radius_decimal - inner_radius_decimal) / step_decimal
    side_count = int(side_count_decimal)
    if Decimal(side_count) != side_count_decimal:
        raise ValueError("radius-inner-radius must be an integer multiple of step")

    a = arb(str(a_decimal))
    damping = arb(str(damping_decimal))
    width = arb(str(step_decimal))
    half_width = step_decimal / 2
    integral_upper = arb(0)

    segment_left_edges = (
        tau_decimal - radius_decimal + Decimal(index) * step_decimal
        for index in range(side_count)
    )
    segment_right_edges = (
        tau_decimal + inner_radius_decimal + Decimal(index) * step_decimal
        for index in range(side_count)
    )
    for segment_left in chain(segment_left_edges, segment_right_edges):
        midpoint = segment_left + half_width
        height = arb(str(midpoint), str(half_width))
        q_boundary = q_value(acb(arb("0.5"), height))
        q_square_upper = (abs(q_boundary) ** 2).upper()

        offset_left = segment_left - tau_decimal
        offset_right = segment_left + step_decimal - tau_decimal
        if offset_left <= 0 <= offset_right:
            minimum_offset_square = Decimal(0)
        else:
            minimum_offset_square = min(abs(offset_left), abs(offset_right)) ** 2
        offset_square = arb(str(minimum_offset_square))

        poisson_upper = (
            a / (arb.pi() * (a**2 + offset_square))
        ).upper()
        damping_upper = (
            (a + damping) ** 2 / (damping**2 + offset_square)
        ).upper()
        integral_upper += width * poisson_upper * damping_upper * q_square_upper

    return integral_upper.upper(), 2 * side_count


def main() -> None:
    args = parse_args()
    ctx.dps = args.digits
    getcontext().prec = args.digits + 20

    a_decimal = Decimal(args.a)
    tau_decimal = Decimal(args.tau)
    damping_decimal = Decimal(args.damping_scale)
    radius_decimal = Decimal(args.radius)
    inner_radius_decimal = Decimal(args.inner_radius)
    step_decimal = Decimal(args.step)
    tau = arb(str(tau_decimal))
    center = q_value(acb(arb(str(Decimal("0.5") + a_decimal)), tau))
    target_lower = (5 * abs(center) ** 2).lower()
    core_upper, count = finite_upper(
        a_decimal,
        tau_decimal,
        damping_decimal,
        inner_radius_decimal,
        radius_decimal,
        step_decimal,
    )
    remaining = (target_lower - core_upper).lower()
    print("RIGOROUS Arb finite-interval upper bound")
    print("a =", args.a)
    print("tau =", args.tau)
    print("damping scale =", args.damping_scale)
    print("radius =", args.radius)
    print("inner radius =", args.inner_radius)
    print("step =", args.step)
    print("intervals =", count)
    print("core integral upper bound =", core_upper)
    print("5 * |Q(center)|^2 lower bound =", target_lower)
    print("remaining budget for both tails =", remaining)
    print("core is below target =", core_upper < target_lower)


if __name__ == "__main__":
    main()
