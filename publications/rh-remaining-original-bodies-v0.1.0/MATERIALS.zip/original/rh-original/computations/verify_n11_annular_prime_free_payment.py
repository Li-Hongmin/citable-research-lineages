"""Arb certificate for the first n=11 annular parity-payment condition.

The annulus is I_b=[log(11)-b,b], with
    a_11 < b <= log(11)-a_*,  a_*=log(201/20)/2.
All prime shifts n<11 have zero Q_b-Q_b block on this interval.  The
remaining block is the translated prime-free operator.  This certificate
proves its two parity restrictions are strictly larger than p_11, so the
dangerous n=11 reflection can be paid on the first activation interval.
All arithmetic is intended for OMEN with python-flint.
"""
from flint import arb, ctx


ctx.dps = 120
pi = arb.pi()
d11 = arb(11).log()
a_star = arb(201).log() / 2 - arb(20).log() / 2
h = d11 / 2 - a_star
p11 = d11 / arb(11).sqrt()
c_inf = (arb(1) / 4).digamma() - pi.log()


def lower_even_root(c):
    """Return an Arb interval known to lie below the first even root."""
    lo = arb(0)
    hi = pi / (2 * h) - arb("1e-30")
    for _ in range(180):
        x = (lo.upper() + hi.lower()) / 2
        f = x * (x * h).tan() - c
        if f.upper() < 0:
            lo = x
        elif f.lower() > 0:
            hi = x
        else:
            break
    return lo


def lower_odd_root(c):
    """Return an Arb interval known to lie below the first odd root."""
    lo = pi / (2 * h) + arb("1e-30")
    hi = pi / h - arb("1e-30")
    for _ in range(180):
        x = (lo.upper() + hi.lower()) / 2
        f = x / (x * h).tan() + c
        if f.upper() > 0:
            lo = x
        elif f.lower() < 0:
            hi = x
        else:
            break
    return lo


def yukawa_lower(parity, N=240):
    total = c_inf
    for n in range(N + 1):
        b_n = arb(n) + arb(1) / 4
        c_n = 2 * b_n
        mu = lower_even_root(c_n) if parity == "+" else lower_odd_root(c_n)
        # The Robin root is monotone on the relevant branch and the displayed
        # rational function is increasing in mu, so its lower endpoint is safe.
        ell = mu**2 / (b_n * (mu**2 + c_n**2))
        total += ell.lower()
    return total


even_lower = yukawa_lower("+")
odd_prime_free_lower = yukawa_lower("-")
center = d11 / 2
odd_polar_norm = 2 * (center / 2).cosh() ** 2 * (h.sinh() - h)
odd_lower = odd_prime_free_lower - odd_polar_norm

print("h_max", h)
print("a_star", a_star)
print("p11", p11)
print("even_prime_free_lower", even_lower)
print("odd_prime_free_lower", odd_prime_free_lower)
print("odd_polar_norm", odd_polar_norm)
print("odd_prime_free_after_polar", odd_lower)
print("even_surplus_over_p11", even_lower - p11)
print("odd_surplus_over_p11", odd_lower - p11)

assert (even_lower - p11).lower() > 0
assert (odd_lower - p11).lower() > 0
print("CERTIFIED_N11_ANNULAR_PARITY_PAYMENT")
