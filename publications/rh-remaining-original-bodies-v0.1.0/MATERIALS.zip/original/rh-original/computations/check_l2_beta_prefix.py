#!/usr/bin/env python3
"""Exact sanity checks for the corrected L=2 Beta-prefix proof.

The proof itself is in notes 163--164.  This script checks (i) the raw
q-shift cumulative coefficients against the Beta decomposition for a modest
exact range, and (ii) the R_{m,M}(u) sign pattern used in the tail/low-index
argument.  It is a finite certificate, not an all-m proof by itself.
"""

from __future__ import annotations

from fractions import Fraction
from math import comb, factorial


def qshift_k(m: int) -> dict[int, Fraction]:
    D = 3 * m + 3
    c: dict[int, Fraction] = {2: Fraction(1, comb(D, 2))}
    for j in range(m - 1):
        c = {
            k: (2 * j + 3 - k) * c.get(k, 0) + k * c.get(k - 1, 0)
            for k in range(D + 1)
        }
    w = {q: c[q] * comb(D, q) for q in c if c[q]}
    K = {1: -3 * w[2]}
    for q in range(2, m + 1):
        K[q] = w[q] * (D - q) - w[q + 1] * (q + 2)
    K[m + 1] = w[m + 1] * (D - m - 1)
    return K


def raw_prefixes(m: int) -> list[Fraction]:
    D = 3 * m + 3
    K = qshift_k(m)
    out: list[Fraction] = []
    running = Fraction(0)
    for s in range(D):
        running += sum(
            K[q] * (comb(D - 1 - q, s) if s <= D - 1 - q else 0)
            for q in K
        )
        out.append(running)
    return out


def beta_prefixes(m: int) -> list[Fraction]:
    D = 3 * m + 3
    A = Fraction(
        factorial(D),
        2**m * comb(D, 2) * factorial(m - 1) * factorial(m + 2),
    )
    out: list[Fraction] = []
    for s in range(D):
        total = Fraction(0)
        for k in range(m - 1):
            beta = Fraction(
                factorial(m + k - 1) * factorial(m + 2),
                factorial(2 * m + k + 2),
            )
            omega = A * comb(m - 2, k) * 2 ** (m - 2 - k) * beta
            mu = Fraction(m + k, 2 * m + k + 3)
            N = 2 * m + 1 + k

            def H(j: int) -> Fraction:
                return Fraction(sum(comb(N, i) for i in range(j + 1))) if j >= 0 else Fraction(0)

            B0 = 2 * m + (3 * m - 2) * mu
            B1 = -2 * m - 4 + (3 * m - 5) * mu
            B2 = -3 * mu
            total += omega * (B0 * H(s) + B1 * H(s - 1) + B2 * H(s - 2))
        out.append(total)
    return out


def R(m: int, M: int, u: int) -> Fraction:
    L = 3 * m + 1 - M
    A = (
        Fraction((3 * m + 1) * u, 2 * L)
        - Fraction((m - 1) * u * (u - 1), 2 * L * (L - 1))
        - Fraction(M * u * (u - 1) * (u - 2), 8 * L * (L - 1) * (L - 2))
        - 3
    )
    B = (
        Fraction((3 * m + 1) * u, L)
        - Fraction(2 * (m - 1) * u * (u - 1), L * (L - 1))
        - Fraction(M * u * (u - 1) * (u - 2), L * (L - 1) * (L - 2))
    )
    return 2**u * A + 4 * (2 ** (M + 1) - 1) * B + 12 * (1 - 2**M)


def main() -> None:
    for m in range(4, 21):
        assert raw_prefixes(m) == beta_prefixes(m), m
    for m in range(4, 101):
        for M in range(m):
            values = [R(m, M, u) for u in range(3 * m + 2 - M)]
            assert all(v >= 0 for v in values[7:]), (m, M)
            changes = sum((a >= 0) != (b >= 0) for a, b in zip(values, values[1:]))
            assert changes <= 1, (m, M, values[:10])
    print("corrected L=2 Beta-prefix checks passed: identity m=4..20; sign pattern m=4..100")


if __name__ == "__main__":
    main()
