"""Shared even-parity wrapper for the log9 weighted Arb certificates."""
src=open('computations/verify_log9_odd_weighted_true_schur.py',encoding='utf-8').read()
even_rk=globals().get('EVEN_RK',5)
even_q_path=globals().get('EVEN_Q_PATH','scratch/log9_even_q280_1000_canonical5_q64.npz')
changes={
'''def basis(k):
 q=Fraction(2*k+1,2);c=(arb(2)/a).sqrt()/2
 return [(acb(0,-c),(Fraction(0),q)),(acb(0,c),(Fraction(0),-q))]''':'''def basis(k):
 if k==0:return [(acb(1/a.sqrt()),(Fraction(0),Fraction(0)))]
 c=(arb(2)/a).sqrt()/2
 return [(acb(c),(Fraction(0),Fraction(k))),(acb(c),(Fraction(0),Fraction(-k)))]''',
''' ck=Fraction(4*n+1,2);c=A(ck);em=(-c*a).exp();den=(1+em*em).sqrt()
 return [(acb(em/den),(ck,Fraction(0))),(acb(-em/den),(-ck,Fraction(0)))]
def polar():return [(acb(1),(Fraction(1,2),Fraction(0))),(acb(-1),(Fraction(-1,2),Fraction(0)))]''':''' ck=Fraction(4*n+1,2);c=A(ck);em=(-c*a).exp();den=(1-em*em).sqrt()
 return [(acb(em/den),(ck,Fraction(0))),(acb(em/den),(-ck,Fraction(0)))]
def polar():return [(acb(1),(Fraction(1,2),Fraction(0))),(acb(1),(Fraction(-1,2),Fraction(0)))]''',
"FUN=[rankrep(n) for n in range(N)]+[polar()];sg=[arb(1)]*N+[arb(-1)]":"FUN=[rankrep(n) for n in range(N)]+[polar()];sg=[arb(1)]*(N+1)",
"terms=[(al[2],'ref',d2,arb(0),d2),(-al[2],'plus'":"terms=[(-al[2],'ref',d2,arb(0),d2),(-al[2],'plus'",
"terms.append((al[n],'ref',d,d-a,a))":"terms.append((-al[n],'ref',d,d-a,a))",
"scratch/log9_odd_q280_1000_rank40_q64.npz":even_q_path,
"scratch/log9_odd_R280_N400_exact_small_map.npz":"scratch/log9_even_R280_N400_exact_small_map.npz",
"rho=arb('2.677899')+2*(a.sinh()-a)":"rho=arb('2.677899')",
"RANK40_TRUE_SCHUR_CERTIFIED":f"EVEN_RANK{even_rk}_TRUE_SCHUR_CERTIFIED",
}
if even_rk!=40:
 changes["R,N,K0,K1,RK=280,500,280,1000,40"]=f"R,N,K0,K1,RK=280,500,280,1000,{even_rk}"
for old,new in changes.items():
 if src.count(old)!=1:raise AssertionError((old,src.count(old)))
 src=src.replace(old,new)
exec(compile(src,__file__,'exec'))
