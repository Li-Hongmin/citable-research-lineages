#!/usr/bin/env python3
"""Exact OMEN-side regression check for the y=8 beta anchor.

The finite range m <= 218 is the residual range in the analytic beta-mean
argument.  This script uses Fraction only and is not a proof by itself.
"""
from fractions import Fraction
from math import comb


def normalization(m):
    value = 3 * m + 4
    for j in range(1, m):
        value *= 3 * m + 2 - 2 * j
    return value


def coefficients(m):
    poly = [Fraction(0)] * (3 * m + 4)
    for j in range(3 * m + 2):
        poly[j + 2] = Fraction((-1) ** j * comb(3 * m + 1, j))
    for j in range(1, m):
        poly = [value * (2 * j + 1 - degree)
                for degree, value in enumerate(poly)]
    poly = [value * (-1 - degree) for degree, value in enumerate(poly)]
    scale = normalization(m)
    return [value / scale for value in poly]


def direct_p8(m):
    poly = coefficients(m)
    return sum(
        sum(value * Fraction(k, 8) ** degree
            for degree, value in enumerate(poly))
        for k in range(1, 8)
    )


def main():
    for m in range(1, 219):
        value = direct_p8(m)
        assert value > 0, (m, value)
    print("y=8 exact direct checks passed for m=1..218")


if __name__ == "__main__":
    main()
