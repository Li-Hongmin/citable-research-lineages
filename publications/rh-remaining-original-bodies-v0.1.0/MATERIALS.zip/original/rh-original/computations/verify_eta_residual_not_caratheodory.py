"""Arb certificate that the eta-grid residual is not Caratheodory.

Reproduce with:

    uv run --with python-flint python \
      computations/verify_eta_residual_not_caratheodory.py
"""

from flint import acb, acb_series, arb, ctx


ctx.dps = 80

s = acb(arb("0.7"), arb("9.8"))
x = acb_series([s, acb(1)], 2)
pi = arb.pi()
log_pi = pi.log()
log_two = arb(2).log()

xi = (
    x
    * (x - 1)
    / 2
    * (-x * log_pi / 2).exp()
    * (x / 2).gamma()
    * x.zeta()
)
xi_plus_derivative = xi[0] + xi[1]

# Canonical zero-mean-type eta-grid residual:
# R(s) = N(s) / B_art(s), where
# B_art(s) = [2^(s-1/2) D(s)/D(1-s)]^2 s/(s-1).
residual = (
    ((1 - 2 * s) * log_two).exp()
    * 2
    * xi_plus_derivative
    * (1 - (s * log_two).exp()) ** 2
    * (s * log_pi / 2).exp()
    / (s**2 * (s / 2).gamma())
)

print("s =", s)
print("R(s) =", residual)
print("upper endpoint of Re R(s) =", residual.real.upper())

assert residual.real.upper() < arb("-0.16")
print("PASS: Re R(0.7 + 9.8 i) < -0.16.")
