#!/usr/bin/env python3
"""Exact OMEN regression for the all-m y=8 beta-positivity proof.

The finite range m<=218 is checked by Fraction; the pair formulas are checked
against the direct beta summands through m=300.  The analytic tail is in note
676 and is not replaced by this finite scan.
"""

from fractions import Fraction
from math import comb, factorial


def normalization(m):
    value = 3 * m + 4
    for j in range(1, m):
        value *= 3 * m + 2 - 2 * j
    return value


def coefficients(m):
    poly = [Fraction(0)] * (3 * m + 4)
    for j in range(3 * m + 2):
        poly[j + 2] = Fraction((-1) ** j * comb(3 * m + 1, j))
    for j in range(1, m):
        poly = [
            value * (2 * j + 1 - degree)
            for degree, value in enumerate(poly)
        ]
    poly = [value * (-1 - degree) for degree, value in enumerate(poly)]
    scale = normalization(m)
    return [value / scale for value in poly]


def d_weight(m, r):
    degree = 3 * m + 3
    return Fraction(
        factorial(degree) * factorial(m + r - 2),
        comb(degree, 2)
        * 2**r
        * factorial(r - 1)
        * factorial(m - r)
        * factorial(2 * m + r + 1),
    )


def pair_direct(m, r, a):
    p = m - r + 3
    q = 2 * m + r + 1
    points = (a,) if a == 4 else (a, 8 - a)
    return sum(
        k ** (p - 1)
        * (8 - k) ** (q - 1)
        * ((3 * m + 4) * k - 8 * p)
        for k in points
    )


def pair_formula(m, r, a):
    if a == 1:
        return (
            7 ** (2 * m + r) * (8 * r - 5 * m - 20)
            + 7 ** (m - r + 2) * (13 * m + 8 * r + 4)
        )
    if a == 2:
        return (
            2 ** (m - r + 2)
            * 6 ** (2 * m + r)
            * (8 * r - 2 * m - 16)
            + 6 ** (m - r + 2)
            * 2 ** (2 * m + r)
            * (10 * m + 8 * r)
        )
    if a == 3:
        return (
            3 ** (m - r + 2)
            * 5 ** (2 * m + r)
            * (8 * r + m - 12)
            + 5 ** (m - r + 2)
            * 3 ** (2 * m + r)
            * (7 * m + 8 * r - 4)
        )
    if a == 4:
        return 4 ** (3 * m + 2) * 4 * (m + 2 * r - 2)
    raise ValueError(a)


def direct_p8(m):
    poly = coefficients(m)
    return sum(
        sum(
            value * Fraction(k, 8) ** degree
            for degree, value in enumerate(poly)
        )
        for k in range(1, 8)
    )


def beta_p8(m):
    total = Fraction(0)
    for r in range(1, m + 1):
        total += d_weight(m, r) * sum(
            pair_direct(m, r, a) for a in (1, 2, 3, 4)
        )
    return total / (8 ** (3 * m + 3) * normalization(m))


def main():
    for m in range(1, 219):
        for r in range(1, m + 1):
            for a in (1, 2, 3, 4):
                assert pair_direct(m, r, a) == pair_formula(m, r, a)
        direct = direct_p8(m)
        assert direct == beta_p8(m)
        assert direct > 0, (m, direct)
    for m in (219, 220, 250, 300):
        assert direct_p8(m) == beta_p8(m)
    print("Y8_PAIR_BETA_RECONSTRUCTION_OK", "m=1..300")
    print("Y8_FINITE_POSITIVITY_OK", "m=1..218")


if __name__ == "__main__":
    main()
