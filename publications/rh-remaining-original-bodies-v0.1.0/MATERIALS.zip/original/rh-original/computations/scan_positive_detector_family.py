#!/usr/bin/env python3
"""Exact exploratory scan of the detector family V_m, m=1,...,M.

The scan uses N=floor(y) as an integer and checks the Bernstein coefficients in
the falling-factorial basis of t=N-2.  It is deliberately small and symbolic;
it reports candidates and does not claim an all-m theorem.
"""

import argparse
import sympy as sp


def one_layer(m: int) -> None:
    u, c, N, r, t = sp.symbols("u c N r t")
    degree = 3 * m + 3
    quotient_degree = m
    a = sp.symbols(f"a0:{quotient_degree + 1}")
    quotient = sum(a[j] * u**j for j in range(quotient_degree + 1))
    V0 = sp.expand(u**2 * (1 - u) ** (2 * m + 1) * quotient)
    equations = [V0.coeff(u, k) for k in range(3, 2 * m, 2)]
    equations.append(sp.integrate(V0, (u, 0, 1)))
    solution = list(sp.linsolve(equations, a))[0]
    free = sorted(set().union(*(term.free_symbols for term in solution)), key=str)
    if len(free) != 1:
        raise AssertionError((m, free))
    scale = free[0]
    values = {symbol: (1 if symbol == scale else 0) for symbol in free}
    coefficients = [sp.simplify(term.subs(values)) for term in solution]
    V = sp.expand(V0.subs(dict(zip(a, coefficients))))
    assert sp.integrate(V, (u, 0, 1)) == 0
    assert all(sp.Poly(V, u).coeff_monomial(u**k) == 0 for k in range(1, 2 * m + 1, 2))

    P = sum(
        coef * sp.summation(c**power, (c, 1, N)) / (N + r) ** power
        for (power,), coef in sp.Poly(V, u).terms()
    )
    Q = sp.factor((N + r) ** degree * P / (N * (N + 1)))
    bernstein_degree = degree - 2
    Q_poly = sp.Poly(sp.expand(Q), r)
    bernstein = []
    for k in range(bernstein_degree + 1):
        bernstein.append(
            sp.factor(
                sum(
                    Q_poly.coeff_monomial(r**j)
                    * sp.binomial(k, j)
                    / sp.binomial(bernstein_degree, j)
                    for j in range(k + 1)
                )
            )
        )
    assert all(b.subs(N, 1) >= 0 for b in bernstein)
    for b in bernstein:
        current = sp.together(b.subs(N, t + 2))
        for j in range(m + 1):
            assert current.subs(t, 0) / sp.factorial(j) >= 0
            current = sp.expand(current.subs(t, t + 1) - current)
    print(f"m={m} degree={degree} exact falling-factorial signs: OK")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("-M", type=int, default=10)
    parser.add_argument("--single", type=int, default=None)
    args = parser.parse_args()
    if args.single is not None:
        one_layer(args.single)
        return
    for m in range(1, args.M + 1):
        one_layer(m)


if __name__ == "__main__":
    main()
