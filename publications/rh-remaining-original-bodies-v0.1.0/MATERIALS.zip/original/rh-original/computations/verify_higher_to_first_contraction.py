from fractions import Fraction
from math import comb


def mobius(n: int) -> int:
    if n == 1:
        return 1
    x, parity, p = n, 0, 2
    while p * p <= x:
        if x % p == 0:
            x //= p
            parity ^= 1
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        parity ^= 1
    return -1 if parity else 1


def suffix_mobius(X: int) -> list[Fraction]:
    values = [0] * (X + 1)
    for n in range(1, X + 1):
        values[n] = mobius(n)
    suffix = [Fraction(0)] * (X + 2)
    for n in range(X, 0, -1):
        suffix[n] = suffix[n + 1] + Fraction(values[n], n)
    return suffix


def B_x(y: Fraction, X: int, suffix: list[Fraction]) -> Fraction:
    if y > X:
        return Fraction(0)
    first = (y.numerator + y.denominator - 1) // y.denominator
    return suffix[first]


def T(r: int, q: int, k: int, X: int, suffix: list[Fraction]) -> Fraction:
    return sum(
        (
            (-1) ** ell
            * comb(r, ell)
            * B_x(Fraction(k, q**ell), X, suffix)
            for ell in range(r + 1)
        ),
        Fraction(0),
    )


def check(q: int, r: int, X: int) -> None:
    support = q**r * X
    suffix = suffix_mobius(X)
    for k in range(1, X + 1):
        lhs = T(1, q, k, X, suffix)
        rhs = (-1) ** (r + 1) * sum(
            (
                comb(j + r - 2, r - 2)
                * T(r, q, q ** (j + r - 1) * k, X, suffix)
                for j in range(0, 32)
                if q ** (j + r - 1) * k <= support
            ),
            Fraction(0),
        )
        assert lhs == rhs, (q, r, X, k, lhs, rhs)

    first_energy = sum(
        (Fraction(k) * T(1, q, k, X, suffix) ** 2 for k in range(1, X + 1)),
        Fraction(0),
    )
    high_energy = sum(
        (Fraction(n) * T(r, q, n, X, suffix) ** 2 for n in range(1, support + 1)),
        Fraction(0),
    )
    # Safe rational upper bounds for (sqrt(q)-1)^(-2(r-1)):
    # q=2: < 6^(r-1), q=3: < 2^(r-1), q=4: =1.
    factor_base = {2: 6, 3: 2, 4: 1}[q]
    rhs_energy = Fraction(1, factor_base ** (r - 1)) * high_energy
    assert first_energy <= rhs_energy, (q, r, X, first_energy, rhs_energy)


def main() -> None:
    for q in (2, 3, 4):
        for r in range(2, 5):
            for X in range(1, 7):
                check(q, r, X)
    print("higher-to-first contraction verified: q=2,3,4; r=2..4; X=1..6")


if __name__ == "__main__":
    main()
