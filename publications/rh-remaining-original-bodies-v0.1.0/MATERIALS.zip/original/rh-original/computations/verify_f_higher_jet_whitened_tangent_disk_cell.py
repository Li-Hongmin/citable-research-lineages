#!/usr/bin/env python3
"""Strict Arb proof for sixth logarithmic-jet whitening on one tangent disk."""

from __future__ import annotations

from flint import acb, acb_series, arb, ctx


BAND_TOP = arb("0.5")
TAU = arb("19029.5")
WHITENING_ORDER = 6
ARC_COUNT = 32768


def xi_series_at(variable: acb_series) -> acb_series:
    gamma_factor = (
        variable
        * (variable - 1)
        / 2
        * (-variable * arb.pi().log() / 2).exp()
        * (variable / 2).gamma()
    )
    return gamma_factor * variable.zeta()


def f_value(s: acb) -> acb:
    variable = acb_series([s, acb(1)], 3)
    xi_series = xi_series_at(variable)
    return xi_series[0] + xi_series[1]


def center_data(
    center: acb, radius: arb
) -> tuple[acb, list[acb]]:
    variable = acb_series([center, acb(radius)], WHITENING_ORDER + 2)
    xi_series = xi_series_at(variable)
    f_series = acb_series(
        [
            xi_series[degree]
            + (degree + 1) * xi_series[degree + 1] / radius
            for degree in range(WHITENING_ORDER + 1)
        ],
        WHITENING_ORDER + 1,
    )
    normalized_log = (f_series / f_series[0]).log()
    return f_series[0], [
        normalized_log[degree] for degree in range(1, WHITENING_ORDER + 1)
    ]


def main() -> None:
    ctx.dps = 40
    ctx.cap = WHITENING_ORDER + 3

    radius = 3 * BAND_TOP / 4
    center = acb(arb("0.5") + radius, TAU)
    center_value, log_jets = center_data(center, radius)

    total_upper_ball = arb(0)
    pi = arb.pi()
    half_width = pi / ARC_COUNT
    for index in range(ARC_COUNT):
        midpoint = (2 * index + 1) * pi / ARC_COUNT
        theta = arb(midpoint, half_width)
        z = acb(theta.cos(), theta.sin())
        point = center + radius * z
        log_polynomial = acb(0)
        power = acb(1)
        for coefficient in log_jets:
            power *= z
            log_polynomial += coefficient * power
        normalized = f_value(point) / center_value * (-log_polynomial).exp()
        total_upper_ball += normalized.real**2 + normalized.imag**2

    mean_square = total_upper_ball / ARC_COUNT
    upper = mean_square.upper()

    print("STRICT Arb sixth-log-jet tangent-disk certificate")
    print("band top A =", BAND_TOP)
    print("center =", center)
    print("radius =", radius)
    print("whitening order =", WHITENING_ORDER)
    print("arc count =", ARC_COUNT)
    print("scaled logarithmic jets =")
    for degree, coefficient in enumerate(log_jets, start=1):
        print(degree, coefficient)
    print("full circle mean-square enclosure =", mean_square)
    print("rigorous upper endpoint =", upper)
    print("factor-5 threshold = 5")
    if not upper < 5:
        raise AssertionError("the interval upper bound did not clear factor 5")
    print("PASS: the complete sixth-log-jet circle moment is strictly below 5")


if __name__ == "__main__":
    main()
