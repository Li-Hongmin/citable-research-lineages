# log11 双 parity cutoff-free 应用证书（2026-09-10 round 1）

固定参数：`a=log(11)/2, K=400, N=500, R=280, F=[500,850), q_f=8000, Arb 256-bit`。
从空 `scratch/` 生成每个 parity 的 safe base、verified graph、clean contracted base、完整
Yukawa/Parseval family，再运行 sharp checker。大 parent 只在未版本化 `scratch/`；哈希见
`PARENT-SHA256.txt`。本包保存实际源码、逐阶段日志和最终小型区间结果。

checker 构造
`G=P0+RP/t400+BF*BF.T-G1-(Rtot-R1)/t8000`，其中
`Rtot=RP+XF*BF.T+BF*XF.T+BF*GQ*BF.T`，且逐项构造 `U_q=c_q+BF*v_q`。
generator 保留 odd negative polar；family exporter 保存全部 `cross` 和 `gram_q`。
trigamma 级数给出 `t_q` 严格递增，两个新鲜 `t400` 均严格为正；`Rtot-R1` 是剩余
`U_q U_q^*` 的 Parseval Gram，故尾权方向合法。

even：393 维补块最小 pivot 下端约 `0.04079956`，最终核心 pivot 下端约 `3.6824e-50`。
odd：394 维补块最小 pivot 下端约 `0.00733669`，最终核心 pivot 下端约 `3.6435e-45`。
全部严格为正。本包只关闭 log11 双 parity 无限维应用证书；不关闭抽象方法定理、自足论文、
新颖性或异源审计门，也不证明 RH。

Round 2 后 checker 的成功契约已收紧：核心 pivot 数量必须恰为 even 7／odd 6，且每个
区间下端严格为正；负 pivot 或包含零的 pivot 都会以非零状态退出。轻量冻结结果可运行
`python verify_frozen_results.py` 核验参数、pivot 数量、严格符号与 bundle 哈希。

Round 4 后 manifest 契约进一步封闭：verifier 在验哈希前显式比较固定的 21 个预期相对
路径，要求条目数恰为 21、路径无重复且集合完全相等。因此空清单、删去任一项后的 20 项
清单以及用重复项补足数量的清单都会失败；集合通过后才逐项计算 SHA-256。
