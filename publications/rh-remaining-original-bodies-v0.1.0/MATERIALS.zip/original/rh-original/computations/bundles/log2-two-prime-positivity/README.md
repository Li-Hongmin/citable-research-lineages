# \(a=\log 2\) 两素数带严格正性证书

本 bundle 支撑 [note 025](../../../notes/025-two-prime-band-complete-strict-positivity-to-log2.md) 的端点证书。它只记录可复现的有限证书与原始输出；真正的数学量词、尾界和从有限证书到完整算子的论证仍以 note 025 为准。

## 入口与复现

驱动器是 verify_two_prime_band_endpoint_log2.py，调用格式为：

~~~text
python verify_two_prime_band_endpoint_log2.py PREC R N +
python verify_two_prime_band_endpoint_log2.py PREC R N -
~~~

本 bundle 的两组截断参数、四个 parity 运行为：

~~~text
python computations/verify_two_prime_band_endpoint_log2.py 320 30 80 +
python computations/verify_two_prime_band_endpoint_log2.py 320 30 80 -
python computations/verify_two_prime_band_endpoint_log2.py 320 40 100 +
python computations/verify_two_prime_band_endpoint_log2.py 320 40 100 -
~~~

运行环境：Python 3.x、python-flint 0.9.0；驱动器使用 Arb 区间算术。输出中的
CERTIFIED parity 与严格正的 min_LDL_pivot_lower 是有限 Schur/LDL 证书的机器可核验结果。

源码和四份 raw 输出的 SHA-256 见 SHA256SUMS.txt；其中使用仓库内相对路径，不依赖旧机器路径。
