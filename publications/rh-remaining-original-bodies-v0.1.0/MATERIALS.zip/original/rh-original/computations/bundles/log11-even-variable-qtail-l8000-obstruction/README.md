# \(a=\frac12\log11\) even \(J=640\) 的 variable-\(q\)-tail \(L=8000\) 门

本包冻结一个严格的有限门，并记录其在同一 full-space joint-Parseval 下模型中的位置。
令

\[
P=P_{400}^+,\qquad
F=(r_{500}^+,\ldots,r_{639}^+)=B_F\oplus V,\qquad
t_q=d_q-2.931158.
\]

设

\[
\mathcal B=P_0+\frac{R_P}{t_{400}}+B_FB_F^*,\qquad
R_L=\sum_{400\le q<L}U_qU_q^*,\qquad
H_L=\sum_{400\le q<L}\frac{U_qU_q^*}{t_q},
\]

其中 \(U_q=PB_0^+e_q+B_FV^*e_q\)，且完整 Parseval 恒等式给出
\(R_{\rm tot}=\sum_{q\ge400}U_qU_q^*\)。认证对象为

\[
G_L=\mathcal B-H_L-\frac{R_{\rm tot}-R_L}{t_L}.
\tag{1}
\]

对 \(L=8000\)，256-bit Arb 的 \(7\oplus393\) verified Schur 认证给出

\[
p_{\min}(H_{393})
=0.040763986927637844750543975424627\ldots>0,
\]

而七维 pivoted LDL（排列 \((6,2,3,4,5,1,0)\)）的末 pivot 为

\[
\boxed{[-1.60314879987627222815\cdot10^{-47}\pm4.53\cdot10^{-68}]<0.}
\]

前六个 pivot 严格正。因此

\[
\operatorname{inertia}(G_{8000})=(399,1,0).
\tag{2}
\]

这关闭了固定 \(F_{640}\) 的 scalar endpoint tail payment 在 \(L=8000\) 的正性门，
并不推出真正 Schur complement、full-space lower operator 或 Weil 算子不定。

## 结果与检查

- `results/q8000-gate-256.log`：新鲜 Arb 运行；
- `results/q8000-gate-256.npz`：全部区间 pivot、参数与来源；
- `results/parent-manifest.json`：结果、父缓存及源码的 SHA-256；
- `verify_frozen_results.py`：检查序列化区间的严格符号与参数。

```text
python3 verify_frozen_results.py
```

完整 replay 需要 manifest 中的四个 256-bit parent 位于项目 `scratch/`：

```text
[local archival reference] -u \
  computations/bundles/log201over20-local-weil-positivity/sources/log10_even_K400_sharp_safe_arb.py \
  --full400 --clean-no-yukawa --cache-prefix log11 256 11 1 \
  --family scratch/log11_even_K400_N500_yukawa_500_640_parseval_arb_256.npz 140 \
  --qf 8000
```

环境：OMEN，Python 3.10.12、NumPy 2.2.6、python-flint 0.9.0。
