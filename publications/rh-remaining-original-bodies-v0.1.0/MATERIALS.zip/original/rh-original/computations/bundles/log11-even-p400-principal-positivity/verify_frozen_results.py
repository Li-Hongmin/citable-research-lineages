"""Check the serialized strict inequalities in this small proof bundle.

This is an output-integrity check, not a regeneration of the parent caches.
"""
from pathlib import Path
import hashlib
import numpy as np
from flint import arb, ctx

ctx.prec = 256
ROOT = Path(__file__).resolve().parent
SUMS = ROOT / 'SHA256SUMS.txt'

for line in SUMS.read_text().splitlines():
    if not line.strip():
        continue
    expected, rel = line.split(maxsplit=1)
    got = hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()
    assert got == expected, (rel, got, expected)

z = np.load(ROOT / 'results/principal-positive-256.npz')
assert (int(z['precision']) == 256 and int(z['endpoint']) == 11
        and str(z['parity']) == '+' and int(z['R']) == 400
        and int(z['N']) == 500 and list(z['permutation']) == [6, 2, 3, 4, 5, 1, 0])
assert arb(str(z['C393_certified_lower'])).lower() > 0
assert all(arb(str(p)).lower() > 0 for p in z['Schur_pivots'])
print('FROZEN_LOG11_EVEN_P400_PRINCIPAL_CERTIFICATE_OK')
