"""Strict principal-compression gate at the log11 even endpoint.

The matrix formed below is exactly the P400 compression of L0 plus the
physical Yukawa atoms 500,...,563, in the common Householder coordinates.
If it is positive, the remaining PSD Yukawa atoms imply positivity of the
true P400 compression.  If it is negative, the retained negative vector is
tested against a direct rational majorant for the remaining atoms.
"""
import sys
from pathlib import Path
import hashlib
import json
import numpy as np
from flint import arb, arb_mat, ctx

BITS = int(sys.argv[1]) if len(sys.argv) > 1 else 128
ctx.prec = BITS
R, CORE, OLD = 400, 7, 393
a = arb(11).log()/2

base = np.load(f'scratch/log11_even_K400_N500_clean_full_contract_base_arb_{BITS}.npz')
safe = np.load(f'scratch/log11_even_K400_safe_base_arb_{BITS}.npz')
fam = np.load(f'scratch/log11_even_K400_N500_yukawa_500_564_parseval_arb_{BITS}.npz')
graph = np.load(f'scratch/log11_even_R280_N500_verified_graph_arb_{BITS}.npz')
manifest = Path(__file__).resolve().parents[1] / 'results' / 'parent-manifest.json'
if manifest.is_file():
    parents = json.loads(manifest.read_text())['parents']
    for name, expected in parents.items():
        got = hashlib.sha256((Path('scratch') / name).read_bytes()).hexdigest()
        assert got == expected, (name, got, expected)
    print('PARENT_SHA256_OK', flush=True)
assert (str(base['source']) == f'log11_even_K400_safe_base_arb_{BITS}.npz'
        and str(base['householder_source'])
        == f'log11_even_R280_N500_verified_graph_arb_{BITS}.npz')
assert (str(safe['parity']) == '+' and int(safe['R']) == R
        and int(safe['N']) == 500 and int(safe['precision']) == BITS)
assert (str(fam['parity']) == '+' and int(fam['R']) == R
        and int(fam['N']) == 500 and int(fam['atom_lo']) == 500
        and int(fam['atom_hi']) == 564 and int(fam['precision']) == BITS)
assert (str(graph['parity']) == '+' and int(graph['R']) == 280
        and int(graph['N']) == 500 and int(graph['precision']) == BITS)
assert (arb(str(safe['mu']))-arb(str(fam['t400']))).contains(0)
assert all((a-arb(str(z['a']))).contains(0) for z in (base,safe,fam,graph))

def mat(raw):
    return arb_mat([[arb(str(x)) for x in row] for row in raw])

S = mat(base['S']); Rc = mat(base['Rcov']); mu = arb(str(safe['mu']))
b = mat(fam['b'])
for row in graph['whist']:
    h = arb_mat([[arb(str(row[i]))] if i < 280 else [arb(0)] for i in range(R)])
    hh = (h.transpose()*h)[0, 0]
    b -= h*((arb(2)/hh)*(h.transpose()*b))
M = S + Rc/mu + b*b.transpose(); M=(M+M.transpose())/2
A=arb_mat([[M[i,j] for j in range(CORE)] for i in range(CORE)])
B=arb_mat([[M[CORE+i,j] for j in range(CORE)] for i in range(OLD)])
C=arb_mat([[M[CORE+i,CORE+j] for j in range(OLD)] for i in range(OLD)])

# A float Cholesky chooses a dyadic lower factor only.  The certificate is
# interval-valued: C-C0 I = L L^T + E and ||E||_infinity < C0, hence C>0.
C0 = arb('1e-11')
Cminus=arb_mat([[C[i,j]-(C0 if i==j else arb(0))
                 for j in range(OLD)] for i in range(OLD)])
Cmid=np.array([[float(Cminus[i,j].mid()) for j in range(OLD)]
               for i in range(OLD)])
print('C393_MIDPOINT_DIAGNOSTIC_EIGS',
      np.linalg.eigvalsh((Cmid+Cmid.T)/2)[:8],flush=True)
Lmid=np.linalg.cholesky((Cmid+Cmid.T)/2)
scale=2**100
L=arb_mat([[arb(int(np.rint(Lmid[i,j]*scale)))/scale if j<=i else arb(0)
            for j in range(OLD)] for i in range(OLD)])
E=Cminus-L*L.transpose()
resinf=arb(0)
for i in range(OLD):
    rowsum=sum((abs(E[i,j]) for j in range(OLD)),arb(0))
    if rowsum.upper()>resinf.upper(): resinf=rowsum
clower=C0-resinf
print('C393_RESIDUAL_INF',resinf,flush=True)
print('C393_CERTIFIED_LOWER',clower,flush=True)
if not clower.lower()>0:
    raise ArithmeticError(('C393_not_certified_positive',clower))
Y=C.solve(B)
SC=A-B.transpose()*Y; SC=(SC+SC.transpose())/2

# Pivoted LDL; use the first strictly negative pivot to obtain a graph witness.
T=[[SC[i,j] for j in range(CORE)] for i in range(CORE)]
perm=list(range(CORE)); pivots=[]; negative_step=None
for k in range(CORE):
    p=max(range(k,CORE),key=lambda i:abs(float(T[i][i].mid())))
    if p!=k:
        T[k],T[p]=T[p],T[k]
        for row in T: row[k],row[p]=row[p],row[k]
        perm[k],perm[p]=perm[p],perm[k]
    d=T[k][k]
    pivots.append(d)
    print('PIVOT',k,d,flush=True)
    if d.upper()<0:
        negative_step=k; break
    if not d.lower()>0:
        raise ArithmeticError(('indeterminate_pivot',k,d))
    for i in range(k+1,CORE):
        for j in range(i,CORE):
            v=T[j][i]-T[j][k]*T[i][k]/d
            T[j][i]=v;T[i][j]=v
if negative_step is None:
    print('CERTIFIED_PRINCIPAL_POSITIVE',flush=True)
    np.savez(f'scratch/log11_even_muinf_full_yukawa_principal_positive_arb_{BITS}.npz',
             C393_residual_inf=np.array(str(resinf)),
             C393_certified_lower=np.array(str(clower)),
             Schur_pivots=np.array([str(x) for x in pivots]),
             permutation=np.array(perm), precision=np.array(BITS),
             endpoint=np.array(11), parity=np.array('+'), R=np.array(R),
             N=np.array(500), prefix_lo=np.array(500), prefix_hi=np.array(564),
             theorem=np.array('P400_A_even_log11_half_is_positive'))
    raise SystemExit(0)

inds=perm[:negative_step]; last=perm[negative_step]
Ap=arb_mat([[SC[i,j] for j in inds] for i in inds])
bp=arb_mat([[SC[i,last]] for i in inds])
yp=Ap.solve(bp)
zc=[arb(0) for _ in range(CORE)]; zc[last]=arb(1)
for k,i in enumerate(inds): zc[i]=-yp[k,0]
den=2**100
nums=[int(round(float(v.mid())*den)) for v in zc]
z=arb_mat([[arb(n)/den] for n in nums])

# Exact minimizing graph lift, then freeze the full P400 midpoint dyadically.
xraw=arb_mat(CORE+OLD,1)
for i in range(CORE): xraw[i,0]=z[i,0]
yz=Y*z
for i in range(OLD): xraw[CORE+i,0]=-yz[i,0]
xnums=[int(round(float(xraw[i,0].mid())*den)) for i in range(R)]
x=arb_mat([[arb(n)/den] for n in xnums])
norm=(x.transpose()*x)[0,0]
ray=(x.transpose()*M*x)[0,0]/norm
print('NORM2',norm,flush=True); print('RAYLEIGH_M64',ray,flush=True)
if not ray.upper()<0: raise ArithmeticError(('dyadic_full_witness_not_negative',ray))

# Undo the orthogonal Householders and sum the rational upper atoms directly.
f=x
for row in list(graph['whist'])[::-1]:
    h=arb_mat([[arb(str(row[i]))] if i<280 else [arb(0)] for i in range(R)])
    hh=(h.transpose()*h)[0,0]
    f-=h*((arb(2)/hh)*(h.transpose()*f))

# Finite exact rational prefix.  The remaining analytic bound is deliberately
# phase-blind but exploits the exact geometric denominator at cutoff J.
J=200000
pi=arb.pi(); rt2=arb(2).sqrt()
alpha=[arb(k)*pi/(2*a) for k in range(R)]
energy=arb(0)
for n in range(564,J):
    t=arb(n)+arb('.25')
    val=f[0,0]/(arb(2)*a.sqrt()*t)
    for k in range(1,R):
        val += ((-1 if k%2 else 1)*rt2/a.sqrt()*t
                /(arb(2)*(t*t+alpha[k]*alpha[k])))*f[k,0]
    energy += val*val

# For t>=J+.25 expand each denominator through P terms.  If
# r=max(alpha/t)<1, the residual amplitude is bounded uniformly by the
# geometric remainder, and power sums are bounded by integrals.
P=8; t0=arb(J)+arb('.25')
coeff=[arb(0) for _ in range(P)]
coeff[0]=f[0,0]/(arb(2)*a.sqrt())
for k in range(1,R):
    amp=(-1 if k%2 else 1)*rt2/(arb(2)*a.sqrt())*f[k,0]
    for j in range(P): coeff[j]+=amp*((-1)**j)*alpha[k]**(2*j)
poly=arb(0)
for j in range(P):
    for k in range(P):
        s=2*(j+k)+2
        poly += abs(coeff[j]*coeff[k])*(t0**(-s)+t0**(1-s)/arb(s-1))
r=max(alpha[-1]/t0,arb(0))
amps=sum((abs(((-1 if k%2 else 1)*rt2/(arb(2)*a.sqrt())*f[k,0]))
          for k in range(1,R)),arb(0))
remamp=amps*r**(2*P)/(1-r*r)
# Sum ||poly||*||rem|| cross and residual square by Cauchy over q>=J.
polyamp=sum((abs(coeff[j])*t0**(-2*j-1) for j in range(P)),arb(0))
rem_energy=(arb(2)*polyamp*remamp+remamp*remamp)*(arb(1)+t0)
tail=(energy+poly+rem_energy)/norm
delta=-ray
print('PREFIX_564_J',energy/norm,flush=True)
print('ANALYTIC_POLY_TAIL',poly/norm,flush=True)
print('GEOMETRIC_REMAINDER_TAIL',rem_energy/norm,flush=True)
print('TOTAL_TAIL_UPPER',tail,flush=True)
print('TAIL_OVER_DEFICIT',tail/delta,flush=True)
print('STRICT_SURVIVAL',tail.upper()<delta.lower(),flush=True)
np.savez(f'scratch/log11_even_muinf_full_yukawa_direction_arb_{BITS}.npz',
         numerator=np.asarray(xnums,dtype=object),denominator=np.array(den,dtype=object),
         rayleigh=np.array(str(ray)),norm=np.array(str(norm)),
         tail_upper=np.array(str(tail)),ratio=np.array(str(tail/delta)),
         cutoff=np.array(J),P=np.array(P),precision=np.array(BITS))
