# \(a=\frac12\log 11\) 的 even \(P_{400}\) 主压缩正性证据包

本包严格证明唯一的有限维陈述

\[
\boxed{
 P_{400}^+A_{\frac12\log11}^+P_{400}^+>0.
}
\tag{1}

这里 \(P_{400}^+\) 是 even cosine Fourier 的前 \(400\) 个坐标正交投影。
它关闭该固定子空间中的所有负方向；它**不**证明完整
\(A_{\frac12\log11}^+\) 的正性，也不涉及 RH。

## 精确对象

令 \(L_0^+\) 含完整 active-prime/reflection 块、前 \(500\) 个 Yukawa atoms 和正 polar，

\[
U=(u_{500},\ldots,u_{563}).
\]

令 \(Q=H_1\cdots H_7\) 是相同的 seven Householder 合同。生成器保存

\[
S_{\rm safe}=P_{400}L_0^+P_{400}-\frac{R_{\rm cov}}{\mu},
\qquad \mu=t_{400}>0,
\]

故本包形成的区间矩阵为精确恒等式

\[
M=Q^T\left(S_{\rm safe}+\frac{R_{\rm cov}}\mu+(P_{400}U)(P_{400}U)^T\right)Q
=Q^TP_{400}(L_0^++UU^T)P_{400}Q.
\tag{2}
\]

全部尚未加入的 Yukawa atoms 是正半定，因而 (2) 的正定性蕴含 (1)。

把 \(M\) 分为 \(7\oplus393\)。保存的 256-bit Arb 运行认证

\[
C_{393}\succeq
(9.9967632974478\ldots\times10^{-12})I,
\tag{3}
\]

随后 verified solve 与对称选主元 LDL 的七个 pivot 都严格正；最小者为

\[
[1.6282644075998989764\pm7.99\cdot10^{-20} ]\times10^{-48}>0.
\tag{4}
\]

故 Sylvester--Schur 判据给出 \(M>0\)。

## 冻结输出

- `results/log11-even-principal-256.out`：(3)--(4) 的 Arb 输出。
- `results/principal-positive-256.npz`：参数、补块下界、排列及七个 pivot。
- `results/parent-manifest.json`：固定 parent caches 的精确 SHA-256。
- `sources/certify_log11_even_p400_principal_positive.py`：实际认证器。

先做不需要 parent caches 的冻结输出检查：

```text
python verify_frozen_results.py
```

这只核验序列化的 hash、参数及严格不等式；完整重放仍须执行下述认证器。

SHA-256：

```text
b93996b9fb67938461e82cef21c8380be8bd10730ddbfa58ba11a1b8371a5965  results/log11-even-principal-256.out
f636eaf24292226f223097ab02568d24750285d489fd3e8e18ae15edf4676a4a  results/principal-positive-256.npz
f4976e2cd0f126e30aa800a70a26c210ac1ea2024435af3fd25f9df57c70592b  results/parent-manifest.json
60280ddca5ea9601bdb48de7e646fa0d8b7ab3334be83bb74ef2ec10ad19c9c5  sources/certify_log11_even_p400_principal_positive.py
```

## 固定父缓存 replay

环境：Python 3.10、NumPy 2.2.6、python-flint 0.9.0（Arb 256-bit）。
将下列同精度 parent caches 放入项目 `scratch/`：

```text
log11_even_K400_safe_base_arb_256.npz
log11_even_R280_N500_verified_graph_arb_256.npz
log11_even_K400_N500_clean_full_contract_base_arb_256.npz
log11_even_K400_N500_yukawa_500_564_parseval_arb_256.npz
```

运行：

```text
python -u computations/bundles/log11-even-p400-principal-positivity/sources/certify_log11_even_p400_principal_positive.py 256
```

认证器先核验 parent 的 endpoint/parity/维数、共同 \(a\)、共同 \(\mu\)，再做 interval
残差 Cholesky 和 pivoted LDL；中点 Cholesky/eigenvalue 只选择证书，非数学依据。

从源码完全重生这四个 parent 的最小路径，可使用相邻
[`log201over20-local-weil-positivity`](../log201over20-local-weil-positivity/README.md)
包中的 generator、extract 与 Yukawa exporter，将 endpoint 改为 `--endpoint 11` 且精度改为 `256`。
