"""Arb certificate for nonvanishing of the b=2 Mellin factor B(s).

The script is intended to run on OMEN, not on the local workstation.
It encloses B(s)=int_0^L q(x) exp(-s*x) dx, q=-sin(2*pi*exp(-x)),
over a rectangular (sigma,t) box using a composite midpoint rule.
The midpoint remainder uses the uniform bound |f_xx| < 1400.
"""

from __future__ import annotations

import math
import multiprocessing as mp
import os
import sys
import time
from typing import Iterable

from flint import acb, arb, ctx


PREC = int(os.environ.get("ARB_PREC", "100"))
NQUAD = int(os.environ.get("ARB_NQUAD", "256"))
SIG_STEP = float(os.environ.get("SIG_STEP", "0.02"))
T_STEP = float(os.environ.get("T_STEP", "0.02"))
WORKERS = int(os.environ.get("ARB_WORKERS", str(min(16, os.cpu_count() or 1))))


def enclosure(box: tuple[float, float, float, float]) -> tuple[float, str]:
    """Return a rigorous lower bound for |B| on one parameter box."""

    sig0, sig1, t0, t1 = box
    ctx.prec = PREC
    pi = arb.pi()
    length = arb(2).log()
    n = NQUAD
    h = length / n

    sig_mid = arb(str((sig0 + sig1) / 2.0))
    sig_rad = arb(str((sig1 - sig0) / 2.0)) + arb("1e-12")
    t_mid = arb(str((t0 + t1) / 2.0))
    t_rad = arb(str((t1 - t0) / 2.0)) + arb("1e-12")
    s = acb(arb(sig_mid, sig_rad), arb(t_mid, t_rad))

    total = acb(0)
    for j in range(n):
        x = (arb(j) + arb("0.5")) * h
        q = -(2 * pi * (-x).exp()).sin()
        total += q * (-s * x).exp()
    total *= h

    # |q| <= 1, |q'| < 7, |q''| < 46, |s| < 30 imply
    # |(q exp(-sx))''| < 46 + 2*30*7 + 30^2 < 1400.
    error = length * h * h * arb(1400) / 24
    # A rectangle of radius error in each coordinate safely encloses the
    # complex midpoint-rule remainder.
    total += acb(arb(0, error.upper()), arb(0, error.upper()))
    lower = abs(total).lower()
    lower_f = float(lower)
    return lower_f, str(lower)


def boxes() -> Iterable[tuple[float, float, float, float]]:
    # 9.064 is below 2*pi/log(2), so the whole requested strict box is covered.
    sig0, sig1 = 0.5, 1.0
    t0, t1 = 9.064, 29.0
    s = sig0
    while s < sig1 - 1e-12:
        se = min(s + SIG_STEP, sig1)
        t = t0
        while t < t1 - 1e-12:
            te = min(t + T_STEP, t1)
            yield (s, se, t, te)
            t = te
        s = se


def main() -> int:
    all_boxes = list(boxes())
    started = time.time()
    failures: list[tuple[tuple[float, float, float, float], float, str]] = []
    minimum = (float("inf"), None, None)
    with mp.Pool(WORKERS) as pool:
        for box, result in zip(all_boxes, pool.imap(enclosure, all_boxes, chunksize=8)):
            lower_f, lower_s = result
            if lower_f < minimum[0]:
                minimum = (lower_f, box, lower_s)
            if lower_f <= 0.0:
                failures.append((box, lower_f, lower_s))

    elapsed = time.time() - started
    print(f"precision={PREC} nquad={NQUAD} workers={WORKERS}", flush=True)
    print(f"boxes={len(all_boxes)} elapsed_s={elapsed:.3f}", flush=True)
    print(f"minimum_lower={minimum[0]!r} box={minimum[1]} arb={minimum[2]}", flush=True)
    print(f"nonpositive_boxes={len(failures)}", flush=True)
    for item in failures[:20]:
        print("FAIL", item, flush=True)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
