"""Candidate signed endpoint tail bound for the frozen log11 F_640 witness.

For h_x whose cosine coefficients are c_q=<x,U_q>, this computes a rigorous
upper bound for sum_{q>=Q}(t_8000^{-1}-t_q^{-1}) |c_q|^2 by the larger
t_8000^{-1} sum |c_q|^2.  All prime/rank sources are merged into h_x before
endpoint jumps are formed.  The leading internal-jump square is summed with
its signs through a finite cutoff; only the remaining oscillatory pairs use
Abel absolute bounds.
"""
from fractions import Fraction
import os
from pathlib import Path
import hashlib
import sys

import numpy as np
from flint import arb, acb, arb_mat, ctx


P = int(sys.argv[1]) if len(sys.argv) > 1 else 16
Q = int(sys.argv[2]) if len(sys.argv) > 2 else 20000
M = int(sys.argv[3]) if len(sys.argv) > 3 else 200000
if not (P >= 2 and Q >= 8000 and M > Q):
    raise ValueError((P, Q, M))
ctx.prec = 256
ROOT = Path(os.environ.get('RH_PROJECT_ROOT', Path(__file__).resolve().parent.parent)).resolve()
E, R, N, FM = 400, 280, 500, 140
a = arb(11).log() / 2
pi = arb.pi()
norm = (arb(2) / a).sqrt()
rho = arb('2.931158')
WITNESS = Path(os.environ.get(
    'RH_WITNESS_PATH',
    ROOT / 'scratch/log11_even_F640_q8000_negative_witness_dyadic_224_arb_256.npz',
)).resolve()
FAMILY = ROOT / 'scratch/log11_even_K400_N500_yukawa_500_640_parseval_arb_256.npz'
GRAPH = ROOT / 'scratch/log11_even_R280_N500_verified_graph_arb_256.npz'


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for block in iter(lambda: fh.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


frozen = np.load(WITNESS, allow_pickle=True)
if str(frozen['family_sha256']) != sha256(FAMILY) or str(frozen['householder_sha256']) != sha256(GRAPH):
    raise ValueError('parent hash mismatch')
den = arb(int(str(frozen['denominator'])))
x = arb_mat([[arb(int(str(v))) / den] for v in frozen['numerator']])
norm2 = (x.transpose() * x)[0, 0]
ray = arb(str(frozen['rayleigh']))


def A(v):
    v = Fraction(v)
    return arb(v.numerator) / v.denominator


def rate(k):
    return acb(A(k[0]), A(k[1]) * pi / a)


def iexp(k, lo, hi):
    if k == (Fraction(0), Fraction(0)):
        return acb(hi - lo)
    z = rate(k)
    return ((z * hi).exp() - (z * lo).exp()) / z


def inner(r1, r2, lo, hi):
    ans = acb(0)
    for c1, k1 in r1:
        for c2, k2 in r2:
            ans += c1.conjugate() * c2 * iexp((k1[0] + k2[0], -k1[1] + k2[1]), lo, hi)
    return ans.real


def basis(k):
    if k == 0:
        return [(acb(1 / a.sqrt()), (Fraction(0), Fraction(0)))]
    c = norm / 2
    return [(acb(c), (Fraction(0), Fraction(k))), (acb(c), (Fraction(0), Fraction(-k)))]


def transform(rep, kind, d):
    out = []
    for c, k in rep:
        z = rate(k)
        if kind == 'ref':
            out.append((c * (z * d).exp(), (-k[0], -k[1])))
        elif kind == 'plus':
            out.append((c * (z * d).exp(), k))
        else:
            out.append((c * (-z * d).exp(), k))
    return out


def rankrep(n):
    ck = Fraction(4 * n + 1, 2)
    c = A(ck)
    em = (-c * a).exp()
    den = (1 - em * em).sqrt()
    return [(acb(em / den), (ck, Fraction(0))), (acb(em / den), (-ck, Fraction(0)))]


def polar():
    return [(acb(1), (Fraction(1, 2), Fraction(0))), (acb(1), (Fraction(-1, 2), Fraction(0)))]


def merge(reps):
    out = {}
    for rep in reps:
        for c, k in rep:
            out[k] = out.get(k, acb(0)) + c
    return [(c, k) for k, c in out.items() if c != 0]


def ev(rep, t, r):
    return sum((c * rate(k) ** r * (rate(k) * t).exp() for c, k in rep), acb(0)).real


graph = np.load(GRAPH, allow_pickle=True)
xphys = arb_mat([[x[i, 0]] for i in range(E)])
# U_q = H_7...H_1 W_q, hence x^T U_q=(H_1...H_7x)^T W_q.
for row in list(graph['whist'])[::-1]:
    h = arb_mat([[arb(str(row[i]))] if i < R else [arb(0)] for i in range(E)])
    hh = (h.transpose() * h)[0, 0]
    xphys -= h * ((arb(2) / hh) * (h.transpose() * xphys))
frep = []
for i in range(E):
    for c, k in basis(i):
        frep.append((acb(xphys[i, 0]) * c, k))

# This is the complete finite-rank response HE plus all F_640 atoms, now in
# physical coordinates.  It is exactly the same scalar response used by U_q.
smooth = []
for n in range(N):
    ov = inner(frep, rankrep(n), arb(0), a)
    for c, k in rankrep(n):
        smooth.append((acb(ov) * c, k))
ov = inner(frep, polar(), arb(0), a)
for c, k in polar():
    smooth.append((acb(ov) * c, k))
family = np.load(FAMILY, allow_pickle=True)
fam_b = family['b']
for n in range(FM):
    ov = sum((xphys[i, 0] * arb(str(fam_b[i, n])) for i in range(E)), arb(0))
    for c, k in rankrep(500 + n):
        smooth.append((acb(ov) * c, k))

d2, d3 = arb(2).log(), arb(3).log()
d4, d5, d7, d8, d9 = 2 * d2, arb(5).log(), arb(7).log(), 3 * d2, 2 * d3
aa = {2: d2 / arb(2).sqrt(), 3: d3 / arb(3).sqrt(), 4: d2 / 2,
      5: d5 / arb(5).sqrt(), 7: d7 / arb(7).sqrt(),
      8: d2 / arb(8).sqrt(), 9: d3 / 3}
terms = [(-aa[2], 'ref', d2, arb(0), d2), (-aa[2], 'plus', d2, arb(0), a - d2),
         (-aa[2], 'minus', d2, d2, a), (-aa[3], 'ref', d3, arb(0), d3),
         (-aa[3], 'plus', d3, arb(0), a - d3), (-aa[3], 'minus', d3, d3, a)]
for n, d in [(4, d4), (5, d5), (7, d7), (8, d8), (9, d9)]:
    terms.append((-aa[n], 'ref', d, d - a, a))
mapped = [(co, transform(frep, kind, d), lo, hi) for co, kind, d, lo, hi in terms]

# These ten named quantities are pairwise separated unless literally the same
# endpoint 0 or a; this removes any numerical endpoint-identification step.
points = [arb(0), d2, d3, a - d2, a - d3, d4 - a, d5 - a, d7 - a, d8 - a, d9 - a, a]
points = sorted(points, key=lambda v: float(v.mid()))
for left, right in zip(points, points[1:]):
    if not (right - left).lower() > 0:
        raise ValueError(('unseparated endpoints', left, right))
cells = []
for left, right in zip(points, points[1:]):
    mid = (left + right) / 2
    reps = [smooth]
    for co, rep, lo, hi in mapped:
        if lo < mid < hi:
            reps.append([(acb(co) * c, k) for c, k in rep])
    cells.append(merge(reps))

# Cosine integration by parts: derivative order 0 carries sine phases, and
# the zero-extension endpoint values do not enter its coefficient.
Br, jump0 = [], []
for r in range(P):
    vals = [ev(cells[0], points[0], r)]
    for j in range(1, len(points) - 1):
        vals.append(ev(cells[j], points[j], r) - ev(cells[j - 1], points[j], r))
    vals.append(-ev(cells[-1], points[-1], r))
    amp = arb(0)
    for j, value in enumerate(vals):
        if r % 2 == 0 and j in (0, len(vals) - 1):
            continue
        amp += abs(value)
        if r == 0:
            jump0.append((points[j], value))
    Br.append(amp)
    print('MERGED_JUMP_ABS', r, amp, flush=True)

# Retain all signs in the leading jump square from Q through M.  At M the
# diagonal phase tail is Hurwitz; every genuinely oscillatory difference/sum
# is paid by the one-step Abel bound.
H = arb(0)
for q in range(Q, M):
    phase = sum((J * (arb(q) * pi * pos / a).sin() for pos, J in jump0), arb(0))
    H += phase * phase / (arb(q) * arb(q))
Hrem = arb(0)
Mh = arb(M)
for i, (xi, Ji) in enumerate(jump0):
    for j, (xj, Jj) in enumerate(jump0):
        coeff = abs(Ji * Jj) / 2
        if i == j:
            Hrem += coeff * arb(2).zeta(Mh)
        else:
            theta = pi * (xi - xj) / a
            Hrem += coeff / (abs((theta / 2).sin()) * Mh * Mh)
        theta = pi * (xi + xj) / a
        Hrem += coeff / (abs((theta / 2).sin()) * Mh * Mh)
print('LEADING_H_PREFIX', H, 'LEADING_H_ABEL_REMAINDER', Hrem, flush=True)

kq = arb(Q) * pi / a
rmax, C = arb(0), arb(0)
for j, rep in enumerate(cells):
    for c, k in rep:
        lam = rate(k)
        rmax = max(rmax, abs(lam) / kq, key=lambda v: float(v.upper()))
        C += abs(c) * abs(lam) ** P * (abs((lam * points[j]).exp()) + abs((lam * points[j + 1]).exp()))
if not rmax.upper() < 1:
    raise ValueError(('nongeometric remainder', rmax))
C /= 1 - rmax
fac = a / pi
lead_amp = norm * fac * (H + Hrem).sqrt()
rest_amp = arb(0)
for r in range(1, P):
    rest_amp += norm * Br[r] * (fac ** (2 * r + 2) * arb(2 * r + 2).zeta(arb(Q))).sqrt()
rem_amp = norm * C * (fac ** (2 * P + 2) * arb(2 * P + 2).zeta(arb(Q))).sqrt()
total_amp = lead_amp + rest_amp + rem_amp
t8000 = acb(arb(1) / 4, arb(8000) * pi / (2 * a)).digamma().real - pi.log() - rho
upper = total_amp * total_amp / (t8000 * norm2)
print('RMAX', rmax, 'GEOMETRIC_C', C, flush=True)
print('LEAD_AMP', lead_amp, 'REST_AMP', rest_amp, 'REM_AMP', rem_amp, flush=True)
print('TAIL_UPPER_FROM_Q', upper, 'OVER_DEFICIT', upper / (-ray), flush=True)
if not upper.upper() < (-ray).lower():
    raise ArithmeticError(('true-schur-tail-does-not-close-witness', upper, ray))
print('CERTIFIED_TRUE_SCHUR_WITNESS_NEGATIVE', flush=True)
np.savez(ROOT / f'scratch/log11_even_F640_q8000_phase_tail_Q{Q}_P{P}_arb_256.npz',
         Q=np.array(Q), M=np.array(M), P=np.array(P), upper=np.array(str(upper)),
         ratio=np.array(str(upper / (-ray))), H_prefix=np.array(str(H)), H_remainder=np.array(str(Hrem)),
         witness_sha256=np.array(sha256(WITNESS)), source_sha256=np.array(sha256(__file__)))
