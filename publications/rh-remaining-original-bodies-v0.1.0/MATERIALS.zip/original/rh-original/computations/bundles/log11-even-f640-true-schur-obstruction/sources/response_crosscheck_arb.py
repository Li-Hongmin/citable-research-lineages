"""Crosscheck the phase-tail physical response against the gate convention."""
from pathlib import Path
import os
import sys

# Reuse only the construction up to the finite physical cell representatives.
# The source receives a trivial finite tail range, so its argument checks hold
# without executing its tail-bound section.
SOURCE = Path(os.environ.get(
    'RH_PHASE_SOURCE',
    'scratch/log11_even_f640_frozen_witness_phase_tail_arb.py',
))
prefix = SOURCE.read_text(encoding='utf-8').split('# Cosine integration by parts:')[0]
sys.argv = [str(SOURCE), '2', '20000', '20001']
exec(compile(prefix, str(SOURCE), 'exec'))


def from_gate(q):
    """The scalar response in precisely the W -> contract -> BF*V order."""
    bq = basis(q)
    ans = arb(0)
    for co, kind, d, lo, hi in terms:
        ans += co * inner(frep, transform(bq, kind, d), lo, hi)
    ans += inner(smooth, bq, arb(0), a)
    return ans


def from_physical_cells(q):
    bq = basis(q)
    ans = arb(0)
    for rep, left, right in zip(cells, points, points[1:]):
        ans += inner(rep, bq, left, right)
    return ans


for q in [0, 1, 7, 400, 7999, 8000, 8191, 20000]:
    gate = from_gate(q)
    cell = from_physical_cells(q)
    diff = gate - cell
    print('RESPONSE_CROSSCHECK', q, 'GATE', gate, 'CELL', cell, 'DIFF', diff,
          'CONTAINS_ZERO', diff.contains(0), flush=True)
    if not diff.contains(0):
        raise ArithmeticError(('response-mismatch', q, gate, cell, diff))
print('RESPONSE_CROSSCHECK_PASSED', flush=True)
