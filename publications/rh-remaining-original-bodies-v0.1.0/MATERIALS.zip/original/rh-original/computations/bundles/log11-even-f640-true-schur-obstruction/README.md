# \(a=\frac12\log11\) even \(F_{640}\) 真 Schur 下模型不定

令

\[
F_{640}=(r_{500}^+,\ldots,r_{639}^+),\qquad
\mathscr S_F=\mathcal B-\sum_{q\ge400}\frac{U_qU_q^*}{t_q}.
\]

本 bundle 认证一个 frozen ray \(x\) 满足

\[
\frac{x^*G_{8000}x}{\|x\|^2}
\le-6.43530356625703565541615\cdot10^{-48},
\]

以及

\[
0\le
\frac{x^*(\mathscr S_F-G_{8000})x}{\|x\|^2}
\le1.798986587628545218869376637\cdot10^{-48}.
\]

故

\[
\boxed{
\frac{x^*\mathscr S_Fx}{\|x\|^2}
\le-4.636316978628490436546773363\cdot10^{-48}<0.}
\]

这里尾界先以 \(t_q^{-1}\le t_{8000}^{-1}\) 支付，再对**完整合并的**
\(c_q=x^*U_q\) 作 16 阶 endpoint expansion。零阶 jump square 从 \(8000\) 到
\(200000\) 保留 signed phase；其余 nonzero phase 才由 Abel 界支付。没有逐
prime/polar/Yukawa source 取绝对值。

因此 fixed-\(F_{640}\) 的 cutoff-free Loewner 下算子不定。它不是
\(A_{\log11/2}^+\) 不定的证明：该下算子只满足
\(\underline L_{F_{640}}^+\preceq A_{\log11/2}^+\)。

数学陈述与边界见 [note 093](../../../notes/093-log11-even-f640-true-schur-lower-model-is-indefinite.md)。

## 冻结检查

```text
python3 verify_frozen_results.py
```

该命令只验证保存的 interval 符号、source/witness hash 和八个坐标交叉核验记录。

## 完整重放

父缓存须位于项目 `scratch/`，并与 `results/frozen-witness-256.npz` 内的 hash 相同：

```text
scratch/log11_even_K400_N500_clean_full_contract_base_arb_256.npz
scratch/log11_even_R280_N500_verified_graph_arb_256.npz
scratch/log11_even_K400_N500_yukawa_500_640_parseval_arb_256.npz
```

先用 parent caches 重建 \(G_{8000}\) 并导出 dyadic witness：

```text
[local archival reference] -u \
  computations/bundles/log201over20-local-weil-positivity/sources/log10_even_K400_sharp_safe_arb.py \
  --full400 --clean-no-yukawa --cache-prefix log11 256 11 1 \
  --family scratch/log11_even_K400_N500_yukawa_500_640_parseval_arb_256.npz 140 \
  --qf 8000 \
  --freeze-negative-witness scratch/log11_even_F640_q8000_negative_witness_dyadic_224_arb_256.npz \
  --tail-probe-end 9000
```

然后直接从 bundle 内冻结 witness 重放全尾：

```text
RH_PROJECT_ROOT="$PWD" \
RH_WITNESS_PATH="$PWD/computations/bundles/log11-even-f640-true-schur-obstruction/results/frozen-witness-256.npz" \
[local archival reference] -u \
  computations/bundles/log11-even-f640-true-schur-obstruction/sources/phase_tail_arb.py \
  16 8000 200000
```

最后重放 physical/collapsed coordinate response 的八点交叉检查：

```text
RH_PROJECT_ROOT="$PWD" \
RH_WITNESS_PATH="$PWD/computations/bundles/log11-even-f640-true-schur-obstruction/results/frozen-witness-256.npz" \
RH_PHASE_SOURCE="computations/bundles/log11-even-f640-true-schur-obstruction/sources/phase_tail_arb.py" \
[local archival reference] -u \
  computations/bundles/log11-even-f640-true-schur-obstruction/sources/response_crosscheck_arb.py
```

环境：OMEN、Python 3.10.12、NumPy 2.2.6、python-flint 0.9.0；全部计算为单核
256-bit Arb。
