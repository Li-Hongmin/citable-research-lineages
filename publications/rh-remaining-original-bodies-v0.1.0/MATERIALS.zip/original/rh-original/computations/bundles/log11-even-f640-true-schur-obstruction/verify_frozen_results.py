"""Check the frozen strict inequality for the log11 F_640 true Schur ray.

This only verifies serialized interval signs, hashes, and the saved finite
coordinate crosscheck.  The parent-cache Arb replay remains the proof-level
reproduction command in README.md.
"""
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
import re

import numpy as np


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'
SOURCES = ROOT / 'sources'
WITNESS = np.load(RESULTS / 'frozen-witness-256.npz', allow_pickle=True)
TAIL = np.load(RESULTS / 'phase-tail-q8000-p16-m200000-256.npz', allow_pickle=True)
MANIFEST = json.loads((RESULTS / 'parent-manifest.json').read_text(encoding='utf-8'))


def digest(path):
    h = sha256()
    with open(path, 'rb') as fh:
        for block in iter(lambda: fh.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def interval(value):
    match = re.fullmatch(r'\[([^ ]+) \+/- ([^\]]+)\]', str(value).strip())
    if match is None:
        raise ValueError(f'not an Arb interval: {value!r}')
    midpoint, radius = map(Decimal, match.groups())
    return midpoint - radius, midpoint + radius


for name, expected in MANIFEST['artifacts'].items():
    assert digest(ROOT / name) == expected, (name, digest(ROOT / name), expected)
for name, expected in MANIFEST['source_dependencies'].items():
    path = ROOT / name if name.startswith('sources/') else ROOT.parents[2] / name
    assert digest(path) == expected, (name, digest(path), expected)


assert int(WITNESS['bits']) == 224
assert str(WITNESS['coordinate']) == 'post-ordered-Householder'
assert str(WITNESS['parity']) == '+'
assert int(WITNESS['qf']) == 8000
assert int(WITNESS['R']) == 280 and int(WITNESS['N']) == 500
assert int(WITNESS['family_atom_lo']) == 500 and int(WITNESS['family_atom_hi']) == 640
assert tuple(int(v) for v in WITNESS['perm']) == (6, 2, 3, 4, 5, 1, 0)

ray_lower, ray_upper = interval(WITNESS['rayleigh'])
assert ray_upper < 0
tail_lower, tail_upper = interval(TAIL['upper'])
assert int(TAIL['Q']) == 8000 and int(TAIL['M']) == 200000 and int(TAIL['P']) == 16
assert str(TAIL['witness_sha256']) == digest(RESULTS / 'frozen-witness-256.npz')
assert str(TAIL['source_sha256']) == digest(SOURCES / 'phase_tail_arb.py')

# Since D_8000(x) <= TAIL['upper'], the upper endpoint of the full ray is
# bounded by ray_upper + tail_upper.  The strict negative sign is therefore
# independent of any midpoint convention.
true_schur_upper = ray_upper + tail_upper
assert true_schur_upper < 0

crosscheck = (RESULTS / 'response-crosscheck-256.log').read_text(encoding='utf-8')
assert crosscheck.count('RESPONSE_CROSSCHECK ') == 8
assert crosscheck.count('CONTAINS_ZERO True') == 8
assert 'RESPONSE_CROSSCHECK_PASSED' in crosscheck
phase_log = (RESULTS / 'phase-tail-q8000-p16-m200000-256.log').read_text(encoding='utf-8')
assert 'CERTIFIED_TRUE_SCHUR_WITNESS_NEGATIVE' in phase_log

print('FROZEN_LOG11_EVEN_F640_TRUE_SCHUR_INDEFINITE')
print('G8000_RAY_UPPER', ray_upper)
print('D8000_UPPER', tail_upper)
print('TRUE_SCHUR_RAY_UPPER', true_schur_upper)
