"""Check only the frozen small Schur outputs in this bundle.

This is level A of the README: it re-parses the saved core interval matrices,
recomputes their specified pivoted LDL chains, and checks the stored positive
complement-pivot bounds.  It does not reconstruct the 393/394-dimensional
complements, so it is not a standalone proof of those bounds.
"""
from pathlib import Path

import numpy as np
from flint import arb, ctx


ctx.prec = 192
ROOT = Path(__file__).resolve().parent
CASES = {
    "+": (ROOT / "results/even-final.npz", [6, 5, 1, 3, 2, 0, 4]),
    "-": (ROOT / "results/odd-final.npz", [5, 2, 0, 1, 4, 3]),
}


def positive_lower(value):
    return value.lower() > 0


for parity, (path, expected) in CASES.items():
    data = np.load(path)
    core = data["S"]
    size = core.shape[0]
    if str(data["parity"]) != parity:
        raise ValueError((path, "parity", data["parity"]))
    if int(data["precision"]) != 192:
        raise ValueError((path, "precision", data["precision"]))
    matrix = [[arb(str(core[i, j])) for j in range(size)] for i in range(size)]
    permutation = list(range(size))
    pivots = []
    for k, desired in enumerate(expected):
        source = permutation.index(desired)
        if source != k:
            matrix[k], matrix[source] = matrix[source], matrix[k]
            for row in matrix:
                row[k], row[source] = row[source], row[k]
            permutation[k], permutation[source] = permutation[source], permutation[k]
        pivot = matrix[k][k]
        if not positive_lower(pivot):
            raise ArithmeticError((path, "nonpositive pivot", k, pivot))
        pivots.append(pivot)
        for i in range(k + 1, size):
            for j in range(i, size):
                value = matrix[j][i] - matrix[j][k] * matrix[i][k] / pivot
                matrix[j][i] = value
                matrix[i][j] = value
    if permutation != expected:
        raise AssertionError((path, permutation, expected))
    hmin = arb(str(data["Hmin"]))
    if not positive_lower(hmin):
        raise ArithmeticError((path, "stored Hmin", hmin))
    print("FROZEN_OUTPUT_CHECK", parity)
    print("STORED_COMPLEMENT_MIN_PIVOT", hmin)
    print("CORE_PIVOT_PERM", permutation)
    for k, pivot in enumerate(pivots):
        print("CORE_PIVOT", k, pivot)
