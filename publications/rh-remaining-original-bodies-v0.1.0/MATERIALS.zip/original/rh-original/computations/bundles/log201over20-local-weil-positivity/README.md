# \(a=\frac12\log(201/20)\) 局部 Weil 严格正性证据包

本包支撑 [note 089](../../../notes/089-strict-local-weil-positivity-to-log201over20-half.md) 的端点

\[
a_*=\frac12\log\frac{201}{20}.
\]

它证明的数学结论是

\[
A_a^+>0,\qquad A_a^->0\qquad(0<a\le a_*).
\]

这不是全尺度 Weil 正性或 RH 的证明。有限输出升级为完整算子的唯一桥梁是 note 089 的
Loewner 下算子及 joint Parseval 恒等式；本 README 不以缓存或 SHA-256 替代该论证。

## 冻结对象

令 \(P=P_{400}\)、\(Q=I-P\)。对每个 parity，base 含完整 active-prime 块、\(n<500\)
Yukawa atoms 与 signed polar；加入的实际全空间 atom family 为

\[
F_+=(r_{500}^+,\ldots,r_{563}^+),\qquad
F_-=(r_{500}^-,\ldots,r_{755}^-).
\]

核心计算保留 \(P\)--\(Q\) 及 atom--base--atom 的全部 cross：

\[
R_{\rm tot}=R_P+X_FB_F^*+B_FX_F^*+B_FG_QB_F^*,
\]

\[
G=P_0+\frac{R_P}{t_{400}}+B_FB_F^*
-G_1-\frac{R_{\rm tot}-R_1}{t_{2000}}.
\]

其中 \(R_{\rm tot}-R_1\succeq0\) 是完整 Parseval 残差，且 \(t_q\) 单调递增；故此矩阵是
infinite-dimensional block lower model 的严格有限 Schur 下界，而非补零的有限压缩。

`results/prime-four-step-192.out` 以 200 个 exact-log cells 认证

\[
\sup T^4\mathbf1
=73.81706267887072825278\ldots,
\qquad
\|P^\sigma\|<2.931158.
\]

此图界先在 \(\frac12\log 11\) 计算；因为 \((-a_*,a_*)\) 的 prime block 是较大窗口 block
的零延拓压缩，所以也适用于 \(a_*\)。

## 运行环境

冻结运行在 OMEN：Python 3.10.12、NumPy 2.2.6、python-flint 0.9.0（Arb 192-bit）。
最小 Python 依赖固定于 `requirements.txt`。

## 三个复算层级

### A. 冻结输出检查

无需大父缓存：

~~~text
uv run --with numpy==2.2.6 --with python-flint==0.9.0 \
  python computations/bundles/log201over20-local-weil-positivity/verify_frozen_results.py
~~~

它重新解析两个保存的 core Schur 区间矩阵、执行指定的 pivoted LDL，并检查保存的
\(393\) / \(394\) 维补块最小 pivot 为正。该层只检验冻结输出的序列化与转录；它没有携带
完整补块或 Cholesky residual，因而**不能独立重证**补块正性。

### B. 固定父缓存 replay

从 `results/result-manifest.json` 取得四个同 SHA-256 的 parent files 后，置于 `scratch/`，运行：

~~~text
python -u scratch/log10_even_K400_sharp_safe_arb.py \
  --full400 --clean-no-yukawa --cache-prefix log201over20 192 201 20 \
  --family scratch/log201over20_even_K400_N500_yukawa_500_564_parseval_arb_192.npz 64

python -u scratch/log10_even_K400_sharp_safe_arb.py \
  --odd --full400 --clean-no-yukawa --cache-prefix log201over20 192 201 20 \
  --family scratch/log201over20_odd_K400_N500_yukawa_500_756_parseval_arb_192.npz 256
~~~

这层重新形成 \(H,R_1,G_1\) 和 true Schur complement，直接复算 Parseval/weight 支付；它信任
被冻结的 graph、contracted-base 与 Yukawa-family parents。OMEN 的 fresh replay raw outputs 已保存为
`results/even-sharp-192.log` 和 `results/odd-sharp-192.log`。

### C. 从源码完整再生

先将 `sources/generate_log10_endpoint_contract_cache.py`、
`sources/extract_log10_even_K400_full_contract_base.py`、
`sources/export_log10_even_yukawa_family_parseval_data.py` 与
`sources/log10_even_K400_sharp_safe_arb.py` 置入 `scratch/`，并将
`sources/verify_first_mixed_band_endpoint_log5.py` 和 `sources/log8_block_certificate_body.py`
置入 `computations/`；这是生成器中固定的相对路径接口。依次用 generator 生成 safe base 与
verified graph，再用 extract 形成 contracted base，用 generator 调用 family exporter，最后按 B 层命令
运行 sharp gate。生成器的四个位置参数必须在 flags 前；例如

~~~text
python -u scratch/generate_log10_endpoint_contract_cache.py 192 400 500 + \
  --endpoint-rational 201 20 --export-full-safe-matrix
~~~

两个 parity 都须各运行一次 safe-base 与 verified-graph 导出；family 导出分别为

~~~text
python -u scratch/generate_log10_endpoint_contract_cache.py 192 400 500 + \
  --endpoint-rational 201 20 --export-yukawa-family 500 564
python -u scratch/generate_log10_endpoint_contract_cache.py 192 400 500 - \
  --endpoint-rational 201 20 --export-yukawa-family 500 756
~~~

随后用 `extract_log10_even_K400_full_contract_base.py --cache-prefix log201over20 --precision 192
--n500-clean`（odd case 另加 `--odd`）形成两个 contracted bases。

同一软件版本下可将 parent hash 与 manifest 对照作字节身份检查；数学成功标准仍是新鲜 Arb 区间的
每一个承重下端严格为正，而不是 hash 恰好相同。

## 文件与完整性

`sources/` 是 B/C 层直接源码；`results/` 保存 final core caches、fresh replay raw outputs 与 prime
four-step output。`SHA256SUMS.txt` 覆盖本包所有冻结文件。大 parent caches 没有打包，因而 bundle
保持轻量；它们的名称和 SHA-256 记录在 `results/result-manifest.json`，不是额外的数学假设。
