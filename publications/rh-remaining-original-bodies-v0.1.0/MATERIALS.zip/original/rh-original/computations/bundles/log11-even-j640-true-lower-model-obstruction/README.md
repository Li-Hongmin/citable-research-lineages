# \(a=\frac12\log11\) even \(J=640\) 真下模型门不定的证据包

本包严格判定一个**有限的下界门**，不是完整 Weil 算子的符号：令

\[
a=\frac12\log11,\qquad P=P_{400}^+,qquad
F=B_F\oplus V=(r_{500}^+,\ldots,r_{639}^+),
\]

并用 \(t_q=d_q-2.931158\) 定义 \(Q=I-P\) 上的对角下界 \(T\)。沿
[note 089](../../../notes/089-strict-local-weil-positivity-to-log201over20-half.md) 的 full-space
Yukawa 分解，令

\[
\begin{aligned}
U_q&=PB_0^+e_q+B_FV^*e_q,\\
R_{\rm tot}&=\sum_{q\ge400}U_qU_q^*
=R_P+X_FB_F^*+B_FX_F^*+B_FG_QB_F^*,\\
R_1&=\sum_{400\le q<2000}U_qU_q^*,\qquad
G_1=\sum_{400\le q<2000}\frac{U_qU_q^*}{t_q}.
\end{aligned}
\]

这里 \(P_0=PL_0^+P-R_P/t_{400}\)。本包认证的矩阵是

\[
G_{11,640}=P_0+\frac{R_P}{t_{400}}+B_FB_F^*
-G_1-\frac{R_{\rm tot}-R_1}{t_{2000}}.
\tag{1}
\]

它是 \(\operatorname{Schur}_Q(\underline L_{11,640})\) 的 Loewner 下界；所有 base--atom
和 atom--atom cross 都保留在 \(R_{\rm tot}\) 中。

## 严格结论

在 seven-Householder 合同坐标将 (1) 分为 \(7\oplus393\)。256-bit Arb 给出

\[
H_{393}\succ0,qquad
p_{\min}(H_{393})
=0.04076175743113018099732688390629\ldots>0.
\]

其 verified Schur complement 的 pivoted LDL（排列 \((6,2,3,4,5,1,0)\)）前六个 pivot
严格正，而最后一个为

\[
\boxed{[-2.00233952790691326054\cdot10^{-47}\pm4.15\cdot10^{-68}]<0.}
\tag{2}
\]

故

\[
\operatorname{inertia}(G_{11,640})=(399,1,0),\qquad G_{11,640}\not>0.
\tag{3}
\]

## 精确边界

(3) 严格关闭了由 (1) 给出 \(G_{11,640}>0\) 的 \(J=640\)、\(t_{2000}\) joint-Parseval
有限门；它**不**推出 \(\underline L_{11,640}\) 不定，也不推出
\(A_{\frac12\log11}^+\) 存在负方向。原因只是

\[
G_{11,640}\preceq\operatorname{Schur}_Q(\underline L_{11,640});
\]

下界不定不能反推被下界的算子不定。

## 冻结结果与重放

- `results/j640-gate-256.log`：新鲜 Arb 运行输出；
- `results/j640-gate-256.npz`：\(H\) 下端、七个 interval pivot 和全部参数；
- `results/parent-manifest.json`：输出、父缓存和实际认证器的 SHA-256；
- `verify_frozen_results.py`：不依赖大缓存地检查保存区间的严格符号与参数。

先运行冻结检查：

```text
python3 verify_frozen_results.py
```

完整重放需将 manifest 中四个 256-bit parent 放回项目 `scratch/`，然后运行：

```text
[local archival reference] -u \
  computations/bundles/log201over20-local-weil-positivity/sources/log10_even_K400_sharp_safe_arb.py \
  --full400 --clean-no-yukawa --cache-prefix log11 256 11 1 \
  --family scratch/log11_even_K400_N500_yukawa_500_640_parseval_arb_256.npz 140
```

该命令的实际 Python/Arb 环境为 OMEN 上 Python 3.10.12、NumPy 2.2.6、python-flint 0.9.0。
