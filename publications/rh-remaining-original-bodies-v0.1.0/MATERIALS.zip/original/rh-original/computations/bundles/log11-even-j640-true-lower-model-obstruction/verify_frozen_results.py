"""Check the serialized strict signs of the log11 even J=640 lower gate.

This is an integrity check of the frozen interval output only.  It does not
replace the parent-cache Arb replay documented in README.md.
"""
from decimal import Decimal
from pathlib import Path
import re

import numpy as np


ROOT = Path(__file__).resolve().parent
DATA = np.load(ROOT / "results" / "j640-gate-256.npz", allow_pickle=True)


def interval(value):
    match = re.fullmatch(r"\[([^ ]+) \+/- ([^\]]+)\]", str(value).strip())
    if match is None:
        raise ValueError(f"not an Arb interval: {value!r}")
    midpoint, radius = map(Decimal, match.groups())
    return midpoint - radius, midpoint + radius


assert str(DATA["parity"]) == "+"
assert str(DATA["cache_prefix"]) == "log11"
assert int(DATA["precision"]) == 256
assert int(DATA["N"]) == 500
assert int(DATA["family_m"]) == 140
assert Decimal(str(DATA["endpoint_value"])) == Decimal(11)

h_lower, _ = interval(DATA["Hmin"])
assert h_lower > 0
pivots = DATA["pivots"]
assert len(pivots) == 7
for pivot in pivots[:-1]:
    lower, _ = interval(pivot)
    assert lower > 0
_, last_upper = interval(pivots[-1])
assert last_upper < 0
assert tuple(int(x) for x in DATA["perm"]) == (6, 2, 3, 4, 5, 1, 0)

print("FROZEN_LOG11_EVEN_J640_TRUE_LOWER_GATE_INDEFINITE")
print("H_MIN_LOWER", h_lower)
print("LAST_PIVOT_UPPER", last_upper)
