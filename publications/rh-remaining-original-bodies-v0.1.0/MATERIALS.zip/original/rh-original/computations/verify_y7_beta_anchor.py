#!/usr/bin/env python3
"""Exact OMEN-side regression check for the y=7 beta anchor.

This file is intended to be executed on OMEN.  It uses Fraction only; no
floating-point computation is part of the certificate.
"""

from fractions import Fraction
from math import comb, factorial


def normalization(m):
    value = 3 * m + 4
    for j in range(1, m):
        value *= 3 * m + 2 - 2 * j
    return value


def coefficients(m):
    poly = [Fraction(0)] * (3 * m + 4)
    for j in range(3 * m + 2):
        poly[j + 2] = Fraction((-1) ** j * comb(3 * m + 1, j))
    for j in range(1, m):
        poly = [value * (2 * j + 1 - degree) for degree, value in enumerate(poly)]
    poly = [value * (-1 - degree) for degree, value in enumerate(poly)]
    scale = normalization(m)
    return [value / scale for value in poly]


def d_coefficient(m, r):
    degree = 3 * m + 3
    return Fraction(
        factorial(degree) * factorial(m + r - 2),
        comb(degree, 2)
        * 2**r
        * factorial(r - 1)
        * factorial(m - r)
        * factorial(2 * m + r + 1),
    )


def beta_term(m, r, y=7):
    p = m - r + 3
    q = 2 * m + r + 1
    return sum(
        k ** (p - 1)
        * (y - k) ** (q - 1)
        * ((3 * m + 4) * k - y * p)
        for k in range(1, y)
    )


def pair_term(m, r, a, y=7):
    p = m - r + 3
    q = 2 * m + r + 1
    return sum(
        k ** (p - 1)
        * (y - k) ** (q - 1)
        * ((3 * m + 4) * k - y * p)
        for k in (a, y - a)
    )


def direct_p7(m):
    poly = coefficients(m)
    return sum(
        sum(value * Fraction(k, 7) ** degree for degree, value in enumerate(poly))
        for k in range(1, 7)
    )


def beta_p7(m):
    total = sum(
        d_coefficient(m, r) * beta_term(m, r)
        for r in range(1, m + 1)
    )
    return total / (7 ** (3 * m + 3) * normalization(m))


def pair_sum(m, a):
    return sum(
        d_coefficient(m, r) * pair_term(m, r, a)
        for r in range(1, m + 1)
    )


def main():
    # Exact finite part needed by the Beta-mean proof below the m=84 threshold.
    for m in range(1, 84):
        direct = direct_p7(m)
        beta = beta_p7(m)
        assert direct == beta, (m, direct, beta)
        assert direct > 0, (m, direct)
        for r in range(1, m + 1):
            assert sum(pair_term(m, r, a) for a in (1, 2, 3)) == beta_term(m, r)

    # The three complementary pairs are (1,6), (2,5), (3,4).
    for m in range(84, 101):
        for r in range(1, m + 1):
            assert sum(pair_term(m, r, a) for a in (1, 2, 3)) == beta_term(m, r)
        assert pair_sum(m, 1) > 0, ("pair16", m)
        assert pair_sum(m, 2) > 0, ("pair25", m)
        assert pair_sum(m, 3) > 0, ("pair34", m)

    for m in range(1, 101):
        assert direct_p7(m) > 0, (m, direct_p7(m))

    print("y=7 beta/direct checks passed for m=1..100")


if __name__ == "__main__":
    main()
