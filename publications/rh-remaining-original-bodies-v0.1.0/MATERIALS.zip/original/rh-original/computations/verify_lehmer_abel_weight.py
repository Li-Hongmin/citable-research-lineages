#!/usr/bin/env python3
"""Check the finite Abel identity and the 1/(4t) variation bound."""

from fractions import Fraction


def mu(n: int) -> int:
    x = n
    p = 2
    parity = 0
    while p * p <= x:
        if x % p == 0:
            x //= p
            parity ^= 1
            if x % p == 0:
                return 0
            while x % p == 0:
                x //= p
        p += 1
    if x > 1:
        parity ^= 1
    return -1 if parity else 1


def check(N: int, h: int) -> None:
    direct = Fraction(0)
    for m in range(1, N - h + 1):
        direct += Fraction(mu(m) * mu(m + h) * m, m + h)

    prefix = []
    running = 0
    for t in range(1, N + 1):
        if t + h <= N:
            running += mu(t) * mu(t + h)
        prefix.append(running)

    rhs = Fraction(N, N + h) * prefix[N - 1]
    for t in range(1, N):
        rhs += prefix[t - 1] * (
            Fraction(t, t + h) - Fraction(t + 1, t + h + 1)
        )
    assert rhs == direct, (N, h, direct, rhs)
    for t in range(1, N):
        delta = Fraction(t + 1, t + h + 1) - Fraction(t, t + h)
        assert delta <= Fraction(1, 4 * t), (N, h, t, delta)


if __name__ == "__main__":
    for n in range(3, 80):
        for h in range(1, n):
            check(n, h)
    print("Lehmer Abel identity: OK")
