#!/usr/bin/env python3
"""Exploratory floating-point search for negative P_m(y).

This is deliberately not a proof.  It uses the positive-factor recurrence for
the Euler--beta detector, evaluates V_m=-F_m', and scans a finite grid of y.
"""
import argparse
import math


def next_R(r, m, j):
    # R_{j+1}=((2j+1)(1-u)+(3m+1-j)u)R_j-u(1-u)R'_j.
    out = [0.0] * (len(r) + 2)
    A = 2 * j + 1
    B = 3 * m + 1 - j
    for k, x in enumerate(r):
        out[k] += (A - k) * x
        out[k + 1] += (B - A + k) * x
    scale = max(abs(x) for x in out)
    return [x / scale for x in out]


def horner_pair(r, u):
    p = r[-1]
    q = 0.0
    for x in reversed(r[:-1]):
        q = q * u + p
        p = p * u + x
    # p=R(u), q=R'(u) after the simultaneous Horner recurrence.
    return p, q


def value_logsign(r, m, u):
    if not (0.0 < u < 1.0):
        return 0.0
    p, q = horner_pair(r, u)
    if p <= 0.0:
        raise RuntimeError("positive coefficient polynomial evaluated nonpositive")
    L = 2 * m + 2
    logf = 3 * math.log(u) + L * math.log1p(-u) + math.log(p)
    d = 3 / u - L / (1 - u) + q / p
    if d == 0.0:
        return 0.0
    return (-1.0 if d > 0 else 1.0) * math.exp(logf + math.log(abs(d)))


def scan(m, ys):
    r = [1.0]
    for j in range(m - 1):
        r = next_R(r, m, j)
    worst = (float("inf"), None)
    for y in ys:
        nmax = int(math.floor(y + 1e-12))
        terms = [value_logsign(r, m, n / y) for n in range(1, nmax + 1)]
        p = math.fsum(terms)
        if p < worst[0]:
            worst = (p, y)
    return worst


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--m0", type=int, default=1)
    ap.add_argument("--m1", type=int, default=200)
    ap.add_argument("--ymax", type=float, default=30.0)
    ap.add_argument("--ny", type=int, default=3000)
    args = ap.parse_args()
    ys = [1.0 + (args.ymax - 1.0) * k / args.ny for k in range(args.ny + 1)]
    for m in range(args.m0, args.m1 + 1):
        w, y = scan(m, ys)
        print(f"m={m} worst={w:.6e} at y={y}", flush=True)


if __name__ == "__main__":
    main()
