#!/usr/bin/env python3
"""Scan dyadic centers for the best one-pole rational Q certificate.

For each L in a user-supplied list, this approximates the convolution

    integral P_a(t-tau) |Q(1/2+it)|^2
             * (a+L)^2/(L^2+(t-tau)^2) dt

on a padded uniform grid.  It then reports the centers with the largest ratio
after minimizing over L.  Truncation and floating-point FFT make this an
adversarial search, not a certificate.
"""

from __future__ import annotations

import argparse

import numpy as np
from flint import acb, arb, ctx
from scipy.signal import fftconvolve

from scan_q_dyadic_center_minima import q_value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a", type=float, required=True)
    parser.add_argument("--tau-max", type=float, default=600.0)
    parser.add_argument("--padding", type=float, default=100.0)
    parser.add_argument("--points-per-a", type=int, default=8)
    parser.add_argument(
        "--l-over-a",
        type=float,
        nargs="+",
        default=[0.5, 1, 2, 4, 8, 16, 32, 64],
    )
    parser.add_argument("--top", type=int, default=12)
    parser.add_argument("--digits", type=int, default=25)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if (
        args.a <= 0
        or args.tau_max < 0
        or args.padding <= 0
        or args.points_per_a < 4
        or args.top <= 0
        or min(args.l_over_a) <= 0
    ):
        raise ValueError("invalid positive scale, range, resolution, or L list")
    ctx.dps = args.digits

    step = args.a / args.points_per_a
    padding_steps = int(np.ceil(args.padding / step))
    maximum_steps = int(np.ceil(args.tau_max / step))
    grid_indices = np.arange(-padding_steps, maximum_steps + padding_steps + 1)
    heights = grid_indices * step

    weight = np.empty(len(heights), dtype=np.float64)
    for index, height in enumerate(heights):
        value_ball = q_value(acb(arb("0.5"), arb(str(float(height)))))
        value = complex(float(value_ball.real.mid()), float(value_ball.imag.mid()))
        weight[index] = abs(value) ** 2

    center_stride = 2 * args.points_per_a
    center_count = int(args.tau_max // (2 * args.a)) + 1
    center_indices = padding_steps + center_stride * np.arange(center_count)
    center_heights = 2 * args.a * np.arange(center_count)
    target = np.empty(center_count, dtype=np.float64)
    for index, tau in enumerate(center_heights):
        value_ball = q_value(acb(arb(str(0.5 + args.a)), arb(str(float(tau)))))
        value = complex(float(value_ball.real.mid()), float(value_ball.imag.mid()))
        target[index] = abs(value) ** 2

    kernel_indices = np.arange(-padding_steps, padding_steps + 1)
    offsets = kernel_indices * step
    poisson = args.a / (np.pi * (args.a**2 + offsets**2))
    best_moment = np.full(center_count, np.inf)
    best_l = np.full(center_count, np.nan)
    per_scale_statistics: list[tuple[float, float, int]] = []

    for multiplier in args.l_over_a:
        damping = multiplier * args.a
        rational_square = (args.a + damping) ** 2 / (damping**2 + offsets**2)
        moment = step * fftconvolve(weight, poisson * rational_square, mode="same")
        centered_moment = moment[center_indices]
        centered_ratio = centered_moment / target
        finite_ratio = centered_ratio[np.isfinite(centered_ratio)]
        per_scale_statistics.append(
            (
                multiplier,
                float(np.max(finite_ratio)),
                int(np.sum(finite_ratio >= 5)),
            )
        )
        improved = centered_moment < best_moment
        best_moment[improved] = centered_moment[improved]
        best_l[improved] = damping

    ratio = best_moment / target
    worst_indices = np.argsort(ratio)[-args.top :][::-1]
    print("NON-RIGOROUS truncated FFT rational-resolvent scan")
    print("a =", args.a)
    print("tau range = [0,", center_heights[-1], "]")
    print("dyadic centers =", center_count)
    print("grid step =", step)
    print("padding =", padding_steps * step)
    print("L/a candidates =", args.l_over_a)
    print("best_ratio         tau          best_L       |Q(center)|^2")
    for index in worst_indices:
        print(
            f"{ratio[index]: .12f}  {center_heights[index]:12.6f}  "
            f"{best_l[index]: .8f}  {target[index]: .12e}"
        )
    print("sampled centers with best ratio >= 5 =", int(np.sum(ratio >= 5)))
    print("per L/a: multiplier, maximum ratio, failures")
    for multiplier, maximum, failures in per_scale_statistics:
        print(f"{multiplier:10.4g}  {maximum: .12f}  {failures}")


if __name__ == "__main__":
    main()
