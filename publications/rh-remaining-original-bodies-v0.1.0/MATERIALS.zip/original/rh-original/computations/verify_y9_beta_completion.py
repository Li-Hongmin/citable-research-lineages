#!/usr/bin/env python3
"""Exact finite residue check for the y=9 beta-positivity completion.

The analytic tail certificate is the integration-by-parts identity recorded in
note 678.  This script only checks the finite residue range m <= 52 and the
pair formulas with exact rational arithmetic; it does not replace the tail
argument.
"""

from fractions import Fraction
from math import comb, factorial


def d_weight(m, r):
    degree = 3 * m + 3
    return Fraction(
        factorial(degree) * factorial(m + r - 2),
        comb(degree, 2)
        * 2**r
        * factorial(r - 1)
        * factorial(m - r)
        * factorial(2 * m + r + 1),
    )


def pair_direct(m, r, a):
    p = m - r + 3
    q = 2 * m + r + 1
    points = (a,) if a == 9 - a else (a, 9 - a)
    return sum(
        k ** (p - 1)
        * (9 - k) ** (q - 1)
        * ((3 * m + 4) * k - 9 * p)
        for k in points
    )


def pair_formula(m, r, a):
    if a == 1:
        return (
            8 ** (2 * m + r) * (9 * r - 6 * m - 23)
            + 8 ** (m - r + 2) * (15 * m + 9 * r + 5)
        )
    if a == 2:
        return (
            2 ** (m - r + 2)
            * 7 ** (2 * m + r)
            * (9 * r - 3 * m - 19)
            + 7 ** (m - r + 2)
            * 2 ** (2 * m + r)
            * (12 * m + 9 * r + 1)
        )
    if a == 3:
        return (
            3 ** (m - r + 2) * 6 ** (2 * m + r) * (9 * r - 15)
            + 6 ** (m - r + 2) * 3 ** (2 * m + r)
            * (9 * m + 9 * r - 3)
        )
    if a == 4:
        return (
            4 ** (m - r + 2) * 5 ** (2 * m + r)
            * (9 * r + 3 * m - 11)
            + 5 ** (m - r + 2) * 4 ** (2 * m + r)
            * (6 * m + 9 * r - 7)
        )
    raise ValueError(a)


def group(m, a):
    return sum(
        (d_weight(m, r) * pair_direct(m, r, a) for r in range(1, m + 1)),
        Fraction(0),
    )


def first_b18_group(m):
    return sum(
        (
            d_weight(m, r)
            * 8 ** (2 * m + r)
            * (9 * r - 6 * m - 23)
            for r in range(1, m + 1)
        ),
        Fraction(0),
    )


def main():
    for m in range(1, 53):
        for r in range(1, m + 1):
            for a in range(1, 5):
                assert pair_direct(m, r, a) == pair_formula(m, r, a)
        groups = [group(m, a) for a in range(1, 5)]
        assert sum(groups, Fraction(0)) > 0, m
        assert groups[2] > 0 and groups[3] > 0, m
    assert first_b18_group(52) > 0
    print("Y9_PAIR_FORMULAS_OK", "m=1..52")
    print("Y9_TOTAL_FINITE_RESIDUE_OK", "m=1..52")
    print("Y9_B18_FIRST_TERM_ANCHOR_OK", "m=52")


if __name__ == "__main__":
    main()
