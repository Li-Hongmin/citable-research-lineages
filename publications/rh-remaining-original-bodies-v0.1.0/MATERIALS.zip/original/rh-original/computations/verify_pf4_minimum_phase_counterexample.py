"""Exact certificate for global-spectral-limit note 020.

Run with:
    uv run --with sympy python computations/verify_pf4_minimum_phase_counterexample.py

Only exact SymPy arithmetic is used.  There is no floating-point root finding.
"""

from __future__ import annotations

import sympy as sp


def sign_word(values: list[sp.Expr]) -> str:
    signs = [sp.sign(value) for value in values if value != 0]
    assert all(sign in (-1, 1) for sign in signs)
    return "".join("+" if sign == 1 else "-" for sign in signs)


def variations(word: str) -> int:
    return sum(left != right for left, right in zip(word, word[1:]))


def routh_first_column(coefficients: list[sp.Expr]) -> list[sp.Expr]:
    degree = len(coefficients) - 1
    width = (degree + 2) // 2
    table = [[sp.S.Zero for _ in range(width)] for _ in range(degree + 1)]
    table[0][:] = coefficients[0::2] + [sp.S.Zero] * (
        width - len(coefficients[0::2])
    )
    table[1][:] = coefficients[1::2] + [sp.S.Zero] * (
        width - len(coefficients[1::2])
    )
    for row in range(2, degree + 1):
        assert table[row - 1][0] != 0
        for column in range(width - 1):
            table[row][column] = sp.factor(
                (
                    table[row - 1][0] * table[row - 2][column + 1]
                    - table[row - 2][0] * table[row - 1][column + 1]
                )
                / table[row - 1][0]
            )
    return [sp.factor(row[0]) for row in table]


def main() -> None:
    u, x, z, w, epsilon = sp.symbols("u x z w epsilon", real=True)
    kernel = sp.exp(-u**2) * (1 + u**4 / 80)

    expected_polynomials = {
        2: x**4 + 2 * x**3 + 160 * x**2 - 480 * x + 6400,
        3: (
            x**6
            + 6 * x**5
            + 249 * x**4
            - 954 * x**3
            + 20_160 * x**2
            - 113_760 * x
            + 531_200
        ),
        4: (
            x**8
            + 12 * x**7
            + 368 * x**6
            - 870 * x**5
            + 39_441 * x**4
            - 379_146 * x**3
            + 3_113_138 * x**2
            - 18_013_920 * x
            + 47_236_960
        ),
    }
    expected_factors = {
        2: sp.Rational(1, 3200),
        3: sp.Rational(1, 32000),
        4: sp.Rational(3, 160000),
    }
    expected_sturm = {
        2: ("+--++", "++--+", 2),
        3: ("+--++--", "++--+--", 3),
        4: ("+--++--++", "++--+++-+", 4),
    }

    print("Exact confluent Wronskian/Sturm certificates")
    for order in range(2, 5):
        matrix = sp.Matrix(
            [
                [sp.diff(kernel, u, i + j) for j in range(order)]
                for i in range(order)
            ]
        )
        wronskian = sp.factor(
            (-1) ** (order * (order - 1) // 2) * matrix.det()
        )
        expected = (
            expected_factors[order]
            * sp.exp(-order * u**2)
            * expected_polynomials[order].subs(x, u**2)
        )
        assert sp.simplify(wronskian - expected) == 0

        polynomial = sp.Poly(expected_polynomials[order], x, domain=sp.QQ)
        sturm = [sp.Poly(item, x) for item in sp.sturm(polynomial.as_expr(), x)]
        at_zero = sign_word([item.eval(0) for item in sturm])
        at_infinity = sign_word([item.LC() for item in sturm])
        expected_zero, expected_infinity, expected_variations = expected_sturm[order]
        assert at_zero == expected_zero
        assert at_infinity == expected_infinity
        assert variations(at_zero) == expected_variations
        assert variations(at_infinity) == expected_variations
        assert sp.count_roots(polynomial, 0, sp.oo) == 0
        assert sp.gcd(polynomial, polynomial.diff()).degree() == 0
        print(
            f"m={order}: V(0)=V(+inf)={expected_variations}; "
            "no positive roots"
        )

    matrix5 = sp.Matrix(
        [[sp.diff(kernel, u, i + j) for j in range(5)] for i in range(5)]
    )
    wronskian5_at_2 = sp.factor(matrix5.det().subs(u, 2))
    assert wronskian5_at_2 == -sp.Rational(137_508_381, 20_000) * sp.exp(-20)
    print(f"m=5: confluent witness H_5(2)={wronskian5_at_2} < 0")

    print("\nExact Fourier/Routh certificate")
    fourier_polynomial = z**4 - 12 * z**2 + 1292
    signed_polynomial = sp.expand(
        fourier_polynomial
        - sp.I * (sp.diff(fourier_polynomial, z) - z * fourier_polynomial / 2)
    )
    routh_polynomial = sp.Poly(
        sp.expand(2 * signed_polynomial.subs(z, -sp.I * w)), w, domain=sp.QQ
    )
    assert routh_polynomial.as_expr() == (
        w**5 + 2 * w**4 + 20 * w**3 + 24 * w**2 + 1340 * w + 2584
    )
    first_column = routh_first_column(routh_polynomial.all_coeffs())
    assert first_column == [1, 2, 8, 12, -sp.Rational(5024, 3), 2584]
    assert sp.gcd(routh_polynomial, routh_polynomial.diff()).degree() == 0
    routh_signs = sign_word(first_column)
    assert variations(routh_signs) == 2
    print(f"Routh first column: {first_column}")
    print("right-half-plane roots (hence lower-z-half-plane roots): 2")

    print("\nSuper-Gaussian perturbation top-scaling coefficients")
    perturbed_kernel = sp.exp(-u**2 - epsilon * u**4) * (1 + u**4 / 80)
    expected_top = {
        2: [sp.Rational(1, 3200), sp.Rational(3, 1600)],
        3: [
            sp.Rational(1, 32000),
            sp.Rational(9, 16000),
            sp.Rational(27, 8000),
            sp.Rational(27, 4000),
        ],
        4: [
            sp.Rational(3, 160000),
            sp.Rational(27, 40000),
            sp.Rational(81, 8000),
            sp.Rational(81, 1000),
            sp.Rational(729, 2000),
            sp.Rational(2187, 2500),
            sp.Rational(2187, 2500),
        ],
    }
    for order in range(2, 5):
        matrix = sp.Matrix(
            [
                [sp.diff(perturbed_kernel, u, i + j) for j in range(order)]
                for i in range(order)
            ]
        )
        normalized = sp.cancel(
            (-1) ** (order * (order - 1) // 2)
            * matrix.det()
            / sp.exp(-order * (u**2 + epsilon * u**4))
        )
        polynomial = sp.Poly(sp.expand(normalized).subs(u**2, x), x, epsilon)
        base_degree = 2 * order
        epsilon_degree = order * (order - 1) // 2
        top_coefficients: list[sp.Expr] = []
        for power in range(epsilon_degree + 1):
            coefficient = sp.Poly(polynomial.as_expr(), epsilon).coeff_monomial(
                epsilon**power
            )
            coefficient_polynomial = sp.Poly(coefficient, x)
            assert coefficient_polynomial.degree() <= base_degree + power
            top_coefficients.append(
                coefficient_polynomial.coeff_monomial(x ** (base_degree + power))
            )
        assert top_coefficients == expected_top[order]
        assert all(value > 0 for value in top_coefficients)
        print(f"m={order}: {top_coefficients}")

    print("\nAll exact checks passed.")


if __name__ == "__main__":
    main()
