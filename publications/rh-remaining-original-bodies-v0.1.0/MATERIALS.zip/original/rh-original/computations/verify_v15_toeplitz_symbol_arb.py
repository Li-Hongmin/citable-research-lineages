#!/usr/bin/env python3
"""Arb check for the two V15 log-Fourier symbol values in note 172."""

from flint import acb, arb, ctx

ctx.prec = 192
C = arb(415134720)


def K(s):
    den = acb(1)
    for k in (2, 4, 6, 8, 9, 10, 11, 12, 13, 14, 15):
        den *= s + k
    return C * (s - 1) / den


z0 = acb(0).zeta() * K(acb(0))
z2 = acb(0, 2).zeta() * K(acb(0, 2))
print("SYMBOL_AT_0", z0.real)
print("SYMBOL_AT_2", z2.real)
assert z0.real.lower() > 0
assert z2.real.upper() < 0
