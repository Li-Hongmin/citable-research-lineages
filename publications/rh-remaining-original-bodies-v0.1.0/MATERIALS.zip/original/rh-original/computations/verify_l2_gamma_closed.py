#!/usr/bin/env python3
"""Exact finite closure of the L=2 falling-factorial gamma layer.

This is deliberately a small certificate for the only low-m cases not covered
by the symbolic raw-Beta argument in notes 163--164.  It evaluates the exact
formula (8) of note 156 with Fraction arithmetic, and checks every h for
m=1,2,3 at L=2.  It is not a scan intended to prove any statement for all m.
"""

from __future__ import annotations

from fractions import Fraction
from functools import lru_cache
from math import comb, factorial


@lru_cache(maxsize=None)
def stirling2(n: int, k: int) -> int:
    if n == k == 0:
        return 1
    if n == 0 or k == 0 or k > n:
        return 0
    return k * stirling2(n - 1, k) + stirling2(n - 1, k - 1)


@lru_cache(maxsize=None)
def F(r: int, t: int, degree: int) -> int:
    """The convolution F_{r,t}(degree) in note 156, eq. (4)."""
    return sum(
        stirling2(r, a)
        * stirling2(t, degree - a)
        * factorial(a)
        * factorial(degree - a)
        for a in range(degree + 1)
    )


def gamma_l2(m: int, h: int) -> Fraction:
    """Exact gamma_{m,h,2} from note 156, eq. (8)."""
    D, d, L = 3 * m + 3, 3 * m + 1, 2
    total = Fraction(0)
    for q in range(2, m + 2):
        c_q = Fraction(
            factorial(2 * m - q) * factorial(q),
            2 ** (m - q + 2)
            * factorial(m - q + 1)
            * factorial(q - 2)
            * comb(D, 2),
        )
        outer = c_q * comb(D, q)
        bracket = Fraction(0)
        for s in range(min(D - q - 1, h) + 1):
            beta = Fraction(comb(D - q - 1, s) * comb(h, s), comb(d, s))
            bracket += beta * (
                (D - q) * F(q + 1, D - q - 1 - s, L + 1)
                - Fraction((q + 1) * (D - q), D - q - s)
                * F(q, D - q - s, L + 1)
            )
        if h >= D - q:
            bracket -= (q + 1) * Fraction(
                comb(h, D - q), comb(d, D - q)
            ) * F(q, 0, L + 1)
        total += outer * bracket
    return total / factorial(L + 2)


EXPECTED = {
    1: [Fraction(0)] * 5,
    2: [
        Fraction(3, 2), Fraction(3, 2), Fraction(5, 3), Fraction(2),
        Fraction(2), Fraction(5, 3), Fraction(3, 2), Fraction(3, 2),
    ],
    3: [
        Fraction(351), Fraction(747, 2), Fraction(1168, 3), Fraction(403),
        Fraction(424), Fraction(464), Fraction(524), Fraction(590),
        Fraction(1931, 3), Fraction(1359, 2), Fraction(702),
    ],
}


def main() -> None:
    for m, expected in EXPECTED.items():
        actual = [gamma_l2(m, h) for h in range(3 * m + 2)]
        assert actual == expected, (m, actual, expected)
        assert all(value >= 0 for value in actual)
        print(f"m={m}: exact L=2 table OK; min={min(actual)}")
        print("  " + ", ".join(map(str, actual)))


if __name__ == "__main__":
    main()
