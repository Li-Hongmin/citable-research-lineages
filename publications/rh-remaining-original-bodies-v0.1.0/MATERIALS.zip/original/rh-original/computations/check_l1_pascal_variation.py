#!/usr/bin/env python3
"""Exact finite check for the L=1 q-shift kernel with the correct weights.

The q-shift weight is c_q*binom(D,q), not (q+1)c_q.  The raw Pascal prefix
check is intended for m>=4; the small layers are handled directly from the
full Fraction gamma formula.
"""

from __future__ import annotations

from fractions import Fraction
from math import comb, factorial


def weights(m: int) -> dict[int, Fraction]:
    D = 3 * m + 3
    B = comb(D, 2)
    out: dict[int, Fraction] = {}
    for ell in range(m):
        q = ell + 2
        c_q = Fraction(
            factorial(2 * m - 2 - ell) * factorial(ell + 2),
            2 ** (m - ell)
            * factorial(m - 1 - ell)
            * factorial(ell)
            * B,
        )
        out[q] = c_q * comb(D, q)
    return out


def k_coefficients(m: int) -> dict[int, Fraction]:
    D = 3 * m + 3
    w = weights(m)
    K = {1: -3 * w[2]}
    for q in range(2, m + 1):
        K[q] = w[q] * (D - q) - w[q + 1] * (q + 2)
    K[m + 1] = w[m + 1] * (D - m - 1)
    return K


def raw_prefixes(m: int) -> list[Fraction]:
    D = 3 * m + 3
    K = k_coefficients(m)
    prefixes: list[Fraction] = []
    for s in range(D):
        coefficient = sum(
            K[q]
            * sum(comb(D - 1 - q, j) for j in range(min(s, D - 1 - q) + 1))
            for q in K
        )
        prefixes.append(coefficient)
    return prefixes


def beta_prefixes(m: int) -> list[Fraction]:
    """The Beta-component formula from note 162, evaluated exactly."""
    D = 3 * m + 3
    B_D = comb(D, 2)
    A_m = Fraction(
        factorial(D),
        2**m * B_D * factorial(m - 1) * factorial(m + 2),
    )
    out: list[Fraction] = []
    for s in range(D):
        total = Fraction(0)
        for k in range(m - 1):
            beta = Fraction(
                factorial(m + k - 1) * factorial(m + 2),
                factorial(2 * m + k + 2),
            )
            omega = A_m * comb(m - 2, k) * 2 ** (m - 2 - k) * beta
            mu = Fraction(m + k, 2 * m + k + 3)
            N_k = 2 * m + 1 + k

            def H(j: int) -> Fraction:
                if j < 0:
                    return Fraction(0)
                return Fraction(sum(comb(N_k, i) for i in range(j + 1)))

            B0 = 2 * m + (3 * m - 2) * mu
            B1 = -2 * m - 4 + (3 * m - 5) * mu
            B2 = -3 * mu
            total += omega * (B0 * H(s) + B1 * H(s - 1) + B2 * H(s - 2))
        out.append(total)
    return out


def main() -> None:
    # The direct Pascal scan can go much higher; the Beta identity check is
    # intentionally kept at a small exact range to avoid quadratic Fraction
    # growth in this lightweight certificate.
    for m in range(4, 21):
        D = 3 * m + 3
        K = k_coefficients(m)
        signs = [value > 0 for _, value in sorted(K.items()) if value]
        changes = sum(a != b for a, b in zip(signs, signs[1:]))
        assert changes <= 1, (m, K)
        assert sum(K.values()) > 0
        half = sum(value * Fraction(1, 2) ** q for q, value in K.items())
        assert half > 0
        prefixes = raw_prefixes(m)
        assert min(prefixes) > 0, (m, min(prefixes))
        assert prefixes == beta_prefixes(m), (m, prefixes, beta_prefixes(m))
    print("correct-weight L=1 Pascal/Beta check passed for m=4..20")


if __name__ == "__main__":
    main()
