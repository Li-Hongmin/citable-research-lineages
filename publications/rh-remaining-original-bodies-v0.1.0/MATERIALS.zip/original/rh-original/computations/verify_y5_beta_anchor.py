#!/usr/bin/env python3
"""Exact OMEN-side regression check for the y=5 beta anchor.

The all-m inequality is proved in note 549; this script checks the finite
small layers and the beta/direct formula identity using rational arithmetic.
"""

from fractions import Fraction
from math import comb, factorial


def theta_plus(poly, c):
    return [value * (c - degree) for degree, value in enumerate(poly)]


def normalization(m):
    value = 3 * m + 4
    for j in range(1, m):
        value *= 3 * m + 2 - 2 * j
    return value


def coefficients(m):
    poly = [Fraction(0)] * (3 * m + 4)
    for j in range(3 * m + 2):
        poly[j + 2] = Fraction((-1) ** j * comb(3 * m + 1, j))
    for j in range(1, m):
        poly = theta_plus(poly, 2 * j + 1)
    poly = theta_plus(poly, -1)
    scale = normalization(m)
    return [value / scale for value in poly]


def direct_p5(m):
    poly = coefficients(m)
    total = Fraction(0)
    for numerator in (1, 2, 3, 4):
        u = Fraction(numerator, 5)
        total += sum(value * u**degree for degree, value in enumerate(poly))
    return total


def d_coefficient(m, r):
    degree = 3 * m + 3
    return Fraction(
        factorial(degree) * factorial(m + r - 2),
        comb(degree, 2)
        * 2**r
        * factorial(r - 1)
        * factorial(m - r)
        * factorial(2 * m + r + 1),
    )


def beta_term(m, r):
    p = m - r + 3
    q = 2 * m + r + 1
    return sum(
        k ** (p - 1)
        * (5 - k) ** (q - 1)
        * ((3 * m + 4) * k - 5 * p)
        for k in range(1, 5)
    )


def beta_p5(m):
    total = sum(
        d_coefficient(m, r) * beta_term(m, r)
        for r in range(1, m + 1)
    )
    return total / (5 ** (3 * m + 3) * normalization(m))


def main():
    for m in range(1, 31):
        direct = direct_p5(m)
        beta = beta_p5(m)
        assert direct == beta, (m, direct, beta)
        assert direct > 0, (m, direct)
    print("y=5 beta/direct checks passed for m=1..30")


if __name__ == "__main__":
    main()
