"""Countercheck the hyper-Bessel monotonicity sentence in report 145--152.

This is an exploratory high-precision check of the expression exactly as written
in the report; a positive derivative at xi=4*sqrt(m) disproves that formulation.
It is not used as a proof of any detector statement.
"""

import sympy as sp
from fractions import Fraction


def alternating_hypergeometric_bracket(a, b, c, z_abs, terms=24):
    """Exact alternating-series enclosure for the m=1 threshold check."""
    term = Fraction(1)
    partial = term
    for n in range(terms):
        term *= (
            Fraction(a + n)
            * z_abs
            / (Fraction(b) + n)
            / (Fraction(c) + n)
            / (n + 1)
        )
        partial += (-1 if (n + 1) % 2 else 1) * term
    next_term = (
        term
        * Fraction(a + terms)
        * z_abs
        / (Fraction(b) + terms)
        / (Fraction(c) + terms)
        / (terms + 1)
    )
    if (terms + 1) % 2:
        return partial - next_term, partial
    return partial, partial + next_term


def exact_m1_lower_bound() -> Fraction:
    # At m=1, xi=4: f' = 48 H(3;5,11/2;-4) - 768/55 H(4;6,13/2;-4).
    h1 = alternating_hypergeometric_bracket(3, 5, Fraction(11, 2), Fraction(4))
    h2 = alternating_hypergeometric_bracket(4, 6, Fraction(13, 2), Fraction(4))
    return 48 * h1[0] - Fraction(768, 55) * h2[1]


def derivative_at_threshold(m: int):
    xi = sp.symbols("xi", positive=True)
    expr = xi**3 * sp.hyper(
        [m + 2],
        [sp.Rational(3 * m + 7, 2), sp.Rational(3 * m + 8, 2)],
        -xi**2 / 4,
    )
    derivative = sp.diff(expr, xi)
    return sp.N(derivative.subs(xi, 4 * sp.sqrt(m)), 60)


def main() -> None:
    lower = exact_m1_lower_bound()
    assert lower > 0
    print(f"m=1 exact alternating-series lower bound: {float(lower):.16g}")
    print("m, derivative at xi=4*sqrt(m)")
    for m in range(1, 11):
        value = derivative_at_threshold(m)
        print(f"{m}, {value}")


if __name__ == "__main__":
    main()
