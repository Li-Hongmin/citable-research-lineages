#!/usr/bin/env python3
"""OMEN-only diagnostic for fixed Dirichlet filters.

For a finite filter c, a_n=(c*mu)(n) and
E_N(c)=sum_{k=1}^{N-1}(2k+1)|sum_{k<n<=N} a_n/n|^2.
This is a finite diagnostic only; it is not evidence for RH.
"""

from __future__ import annotations

import argparse
import math
from array import array


def mobius_table(limit: int) -> array:
    mu = array("b", [0]) * (limit + 1)
    composite = bytearray(limit + 1)
    primes: list[int] = []
    mu[1] = 1
    for n in range(2, limit + 1):
        if not composite[n]:
            primes.append(n)
            mu[n] = -1
        for p in primes:
            q = n * p
            if q > limit:
                break
            composite[q] = 1
            if n % p == 0:
                mu[q] = 0
                break
            mu[q] = -mu[n]
    return mu


def energy(mu: array, n: int, prime_shift: int | None, sign: int) -> float:
    tail = 0.0
    total = 0.0
    for k in range(n - 1, 0, -1):
        q = k + 1
        a = mu[q]
        if prime_shift is not None and q % prime_shift == 0:
            a += sign * mu[q // prime_shift]
        tail += a / q
        total += (2 * k + 1) * tail * tail
    return total


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-n", type=int, default=1 << 23)
    parser.add_argument("--min-power", type=int, default=10)
    args = parser.parse_args()

    if args.max_n < (1 << args.min_power):
        raise SystemExit("max-n must be at least 2^min-power")
    mu = mobius_table(args.max_n)
    filters = {
        "delta1": (None, 0),
        "delta1_minus_delta2": (2, -1),
        "delta1_plus_delta2": (2, 1),
        "delta1_minus_delta3": (3, -1),
        "delta1_minus_delta5": (5, -1),
    }
    print("N,filter,E,E/N^2,log2(E ratio from previous)")
    previous: dict[str, float] = {}
    for power in range(args.min_power, int(math.log2(args.max_n)) + 1):
        n = 1 << power
        for name, (p, sign) in filters.items():
            value = energy(mu, n, p, sign)
            ratio = ""
            if name in previous and previous[name] > 0 and value > 0:
                ratio = f"{math.log2(value / previous[name]):.8f}"
            print(f"{n},{name},{value:.12e},{value/(n*n):.12e},{ratio}", flush=True)
            previous[name] = value


if __name__ == "__main__":
    main()
