#!/usr/bin/env python3
"""OMEN-only finite diagnostic for the Huxley--Watt joint residual.

This computes exact M(N), M(N^2) from a linear Mobius sieve up to max_n^2
and reports R_N = 2 M(N) - M(N^2), together with the two explicit terms in
the Huxley--Watt decomposition.  It is a finite diagnostic, not a theorem.
Run this file only on OMEN; it is intentionally not invoked locally.
"""

from __future__ import annotations

import argparse
from array import array
from math import log2


def mobius_table(limit: int) -> array:
    mu = array("b", [0]) * (limit + 1)
    composite = bytearray(limit + 1)
    primes: list[int] = []
    mu[1] = 1
    for n in range(2, limit + 1):
        if not composite[n]:
            primes.append(n)
            mu[n] = -1
        for p in primes:
            q = n * p
            if q > limit:
                break
            composite[q] = 1
            if n % p == 0:
                mu[q] = 0
                break
            mu[q] = -mu[n]
    return mu


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-n", type=int, default=1 << 12)
    parser.add_argument("--min-power", type=int, default=3)
    args = parser.parse_args()
    if args.max_n < (1 << args.min_power):
        raise SystemExit("max-n must be at least 2^min-power")

    limit = args.max_n * args.max_n
    targets = set()
    n = 1 << args.min_power
    while n <= args.max_n:
        targets.add(n)
        targets.add(n * n)
        n <<= 1

    mu = mobius_table(limit)
    cumulative = 0
    target_m: dict[int, int] = {}
    target_a: dict[int, float] = {}
    reciprocal_sum = 0.0
    for k in range(1, limit + 1):
        value = mu[k]
        cumulative += value
        if k <= args.max_n:
            reciprocal_sum += value / k
        if k in targets:
            target_m[k] = cumulative
            if k <= args.max_n:
                target_a[k] = reciprocal_sum

    print("N,M(N),M(N^2),R_N,a_N,main_N,half_M2,Z_quad,|R|/N^(3/2)")
    n = 1 << args.min_power
    while n <= args.max_n:
        mn = target_m[n]
        mn2 = target_m[n * n]
        residual = 2 * mn - mn2
        a = target_a[n]
        main = n * n * a * a
        half_m2 = 0.5 * mn * mn
        # From R_N = main_N - M(N)^2/2 + mu^T Z_N mu.
        z_quad = residual - main + half_m2
        scale = abs(residual) / (n ** 1.5)
        print(
            f"{n},{mn},{mn2},{residual},{a:.16e},{main:.8e},"
            f"{half_m2:.8e},{z_quad:.8e},{scale:.8e}"
        )
        n <<= 1


if __name__ == "__main__":
    main()
