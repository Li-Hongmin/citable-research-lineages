#!/usr/bin/env python3
"""Check the exact two-window partition used in note 349."""

from collections import Counter


def check_window(B: int, C: int, length: int) -> None:
    """Check one q-window of length <= B, including a partial terminal block."""
    target = Counter()
    for n in range(1, B + 1):
        for v in range(1, length + 1):
            target[(B + n, C + v)] += 1

    covered = Counter()
    for n in range(1, B + 1):
        for v in range(1, length + 1):
            m = B + n
            q = C + v
            if v > n:
                b2 = C
                h = v - n
            else:
                b2 = C - B
                h = B + v - n
            assert 1 <= h <= B
            assert q == b2 + n + h
            covered[(m, q)] += 1
    assert covered == target, (B, C, length, target - covered, covered - target)


def check(B: int, d: int) -> None:
    C = (2**d) * B
    target = Counter()
    for n in range(1, B + 1):
        m = B + n
        for u in range(1, C + 1):
            q = C + u
            target[(m, q)] += 1

    covered = Counter()
    for ell in range(2**d):
        for n in range(1, B + 1):
            for v in range(1, B + 1):
                m = B + n
                q = C + ell * B + v
                if v > n:
                    b2 = C + ell * B
                    h = v - n
                else:
                    b2 = C + (ell - 1) * B
                    h = B + v - n
                assert 1 <= h <= B
                assert q == b2 + n + h
                covered[(m, q)] += 1
    assert covered == target, (B, d, target - covered, covered - target)
    for length in range(1, B + 1):
        check_window(B, C, length)


if __name__ == "__main__":
    for B in (2, 3, 5, 8):
        for d in (1, 2, 3):
            check(B, d)
    print("dyadic Lehmer partition: OK")
