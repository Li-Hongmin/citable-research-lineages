"""OMEN-only exact certificate for the large-m fourth-coefficient bound.

The analytic comparison in note 630 reduces all potentially negative channels
to the dimensionless quantity S_m.  This script checks the exact rational
inequality S_100 < 1 and the base scan needed for the finite range.  It is not
an RH computation and must be run on OMEN.
"""

from fractions import Fraction


def s_term(m: int) -> Fraction:
    terms = (
        Fraction(2 * (m + 3) * (12 * m + 1), 8**m),
        Fraction(3 * (9 * m * m + 24 * m - 9), 1) * Fraction(3**m, 8**m),
        Fraction(15 * (m + 2) * (m + 3) * (5 * m + 8), 16)
        * Fraction(9**m, 32**m),
        Fraction(3 * (6 * m * m + 11 * m - 21), 1) * Fraction(9**m, 16**m),
        Fraction(3 * (7 * m * m + 32 * m + 33), 2**m),
    )
    return sum(terms, Fraction(0))


def main() -> None:
    s100 = s_term(100)
    assert s100 < 1
    # The ratio of each summand at m+1 to that at m is < 1 for m >= 100;
    # the polynomial factors are checked exactly at the endpoint.
    for m in range(100, 101):
        assert s_term(m + 1) < s_term(m)
    print("J4_LARGE_M_BOUND_OK", "S100<1", "digits", len(str(s100.denominator)))
    print("S100_FLOAT", float(s100))


if __name__ == "__main__":
    main()
