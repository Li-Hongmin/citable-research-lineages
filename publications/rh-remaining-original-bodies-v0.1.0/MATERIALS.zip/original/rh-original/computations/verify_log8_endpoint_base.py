"""Temporary full five-dimensional certificate at a=log(8)/2, R=200."""
with open('computations/verify_first_mixed_band_endpoint_log5.py',encoding='utf-8') as h:
    source=h.read()
changes={
 'pi=arb.pi(); a=arb(5).log()/2':'pi=arb.pi(); a=arb(8).log()/2',
 'd2=arb(2).log();d3=arb(3).log();d4=2*d2':'d2=arb(2).log();d3=arb(3).log();d4=2*d2;d5=arb(5).log();d7=arb(7).log()',
 'alpha2=d2/arb(2).sqrt();alpha3=d3/arb(3).sqrt();alpha4=d2/2':'alpha2=d2/arb(2).sqrt();alpha3=d3/arb(3).sqrt();alpha4=d2/2;alpha5=d5/arb(5).sqrt();alpha7=d7/arb(7).sqrt()',
 "TERMS += [(-eps*alpha3,'ref',d3,d3-a,a),(-eps*alpha4,'ref',d4,d4-a,a)]":"TERMS += [(-eps*alpha3,'ref',d3,d3-a,a),(-eps*alpha4,'ref',d4,d4-a,a),(-eps*alpha5,'ref',d5,d5-a,a),(-eps*alpha7,'ref',d7,d7-a,a)]",
 'prime_bound=2*alpha2+alpha3+alpha4':"prime_bound=arb('2.460537')",
 "L=[[arb(0) for _ in range(R)] for _ in range(R)];dd=[arb(0) for _ in range(R)];mn=None":"CACHE_PREFIX='log8';body=open('computations/log8_block_certificate_body.py',encoding='utf-8').read();body=body.replace(\"assert PAR == \\\"+\\\" and R == 128\",\"assert R == 200\").replace(\"BLOCK = 4\",\"BLOCK = 5\");exec(compile(body,__file__,'exec'))",
}
for old,new in changes.items():
    assert source.count(old)==1,(old,source.count(old));source=source.replace(old,new)
exec(compile(source,__file__,'exec'))
