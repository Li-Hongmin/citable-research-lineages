# 全 Farey 主压缩的固定素数横向谱模（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实旧奇算子压缩及精确算术图，和 [scratch 798](798-farey-critical-weight-rayleigh-constant-candidate.md) 的 Archimedean 接触常数。以下是有限主压缩的解析结论；同模型独立复核未发现承重错误，尚缺异源复核，不晋级永久 note。

## 命题

令奇素数 \(p\to\infty\)，\(H=\log p\)，\(k=p^2\)。取 note 791 的正交族 \(e_p\) 与 \(\{w_{a/b}:a/b\in\mathcal F_p\}\)，并令
\[
U_p=\mathbb C e_p\oplus W_p,\qquad
B_p=P_{U_p}A_{k,-}P_{U_p}|_{U_p},\qquad
c_*=1+\gamma_E+\log(2/\pi).
\]
固定一个有限素数集 \(\mathcal P\)。对每个 \(\ell\in\mathcal P\)，置
\[
\pi_\ell=\frac{\ell-1}{\ell+1},\qquad
g_\ell(a,b)=\mathbf1_{\ell\nmid ab}-\pi_\ell,\qquad
\lambda_\ell=\frac{\ell+1}{\ell-1}\log\ell.
\tag{1}
\]
对 \(S\subseteq\mathcal P\)，令 \(G_S(a,b)=\prod_{\ell\in S}g_\ell(a,b)\)，空积为一；在根 \((a,b)=(1,1)\) 处使用同一公式。定义
\[
u_{p,S}=\frac{G_S(1,1)}{\sqrt2}e_p
+\sum_{a/b\in\mathcal F_p}\frac{G_S(a,b)}{\sqrt{ab}}w_{a/b},
\qquad \mu_S=c_*+\sum_{\ell\in S}\lambda_\ell.
\tag{2}
\]
则对每个固定的 \(S\)，
\[
\boxed{\frac{\|(B_p-\mu_S)u_{p,S}\|}{\|u_{p,S}\|}\longrightarrow0.}
\tag{3}
\]
此外，若 \(\sigma_\ell^2=\pi_\ell(1-\pi_\ell)=2(\ell-1)/(\ell+1)^2\)，则
\[
\boxed{
\frac{\|u_{p,S}\|^2}{H^2}\longrightarrow
\frac1{2\zeta(2)}\prod_{\ell\in S}\sigma_\ell^2,
\qquad
\frac{\langle u_{p,S},u_{p,T}\rangle}{\|u_{p,S}\|\|u_{p,T}\|}
\longrightarrow0\quad(S\ne T).}
\tag{4}
\]
不同 \(S\) 的 \(\mu_S\) 两两不同。因此对每个固定 \(\mathcal P\)，\(B_p\) 的谱在每个 \(\mu_S\) 附近各有一个不同的本征值。尤其，完整根补全 Farey 主压缩除正权谱模 \(c_*\) 外，还有 \(c_*+3\log2\) 的有界横向谱模；相对于正权模的正交补没有随 \(\log p\) 增长的统一谱隙。

## 算术图的固定素数两态链

在 \(U_p\) 的正交基上，把负算术部分记为 \(-\widetilde C_p\)。根补全后 \(\widetilde C_p\) 逐项非负，其根--Farey 边为 \(\sqrt2\Lambda(x)/\sqrt x\)，其中 \(x\) 是整数素数幂。置正权 \(v_0=1/\sqrt2\)、\(v_{a/b}=1/\sqrt{ab}\)，并对定义在根加 Farey 节点上的函数 \(F\) 置
\[
(\mathscr L_pF)(x)
=\sum_y\widetilde C_p(x,y)\frac{v_y}{v_x}\bigl(F(x)-F(y)\bigr),
\qquad r_p(x)=\frac{(\widetilde C_pv)_x}{v_x}.
\tag{5}
\]
这里自环在 \(\mathscr L_p\) 中自动为零。精确恒等式是
\[
\frac{(\widetilde C_p(vF))_x}{v_x}=r_p(x)F(x)-(\mathscr L_pF)(x).
\tag{6}
\]
由 note 791 式 (14) 与根列，\(x=a/b\) 的行比为
\[
r_p(a/b)=2\log(p-1)
+\varepsilon((p-1)/a)+\varepsilon((p-1)/b),
\quad
\varepsilon(t)=\sum_{n\le t}\frac{\Lambda(n)}n-\log t,
\tag{7}
\]
而根行为 \(r_p(0)=2\sum_{n<p}\Lambda(n)/n\)。经典素数定理给 \(\varepsilon(t)\to-\gamma_E\)。故在任意固定 \(0<\alpha<1\) 的内区 \(a,b\le p^\alpha\) 上，连同根，
\[
r_p(x)=2H-2\gamma_E+o(1)
\tag{8}
\]
一致成立；在全图上，\(r_p(x)-(2H-2\gamma_E)=O(1)\) 一致成立。

固定 \(\ell\)。只有 \(\ell\) 的素数幂边能改变 \(\ell\nmid ab\) 的真值。若 \(\ell\mid ab\)，互素性使 \(\ell\) 仅整除分子或仅整除分母；恰有一次除去其全部 \(\ell\)-幂的操作到达 \(\ell\)-free 节点。其在 (5) 中的跳转率为 \(\log\ell\)。目标为 \(1\) 时，根列给出同一率。若 \(\ell\nmid ab\)，两个方向的可用操作分别在 \(a\ell^j<p\)、\(b\ell^j<p\) 时以 \((\log\ell)/\ell^j\) 的率到达 occupied 节点。因此
\[
(\mathscr L_pg_\ell)(a/b)=
\begin{cases}
-\log\ell,&\ell\mid ab,\\[2mm]
\displaystyle\log\ell\left(
\sum_{\substack{j\ge1\\a\ell^j<p}}\ell^{-j}
+\sum_{\substack{j\ge1\\b\ell^j<p}}\ell^{-j}\right),&\ell\nmid ab.
\end{cases}
\tag{9}
\]
根满足第二行的 \(a=b=1\) 版本。特别地，\(\mathscr L_pg_\ell\) 全局一致有界；在内区，两个几何级数的缺尾为 \(O_\ell(p^{\alpha-1})\)，所以
\[
\mathscr L_pg_\ell=\lambda_\ell g_\ell+o(1)
\quad\text{一致于内区与根。}
\tag{10}
\]
这里 free 态的等式为
\(\lambda_\ell(1-\pi_\ell)=2\log\ell/(\ell-1)\)，
occupied 态为 \(-\lambda_\ell\pi_\ell=-\log\ell\)。

一条 \(\ell\)-幂边不改变任何 \(m\ne\ell\) 的 free/occupied 态。因此对有限乘积有精确分解
\[
\mathscr L_pG_S
=\sum_{\ell\in S}(\mathscr L_pg_\ell)
  \prod_{m\in S\setminus\{\ell\}}g_m.
\tag{11}
\]
式 (9) 的几何级数缺尾在全图上至多为 \(O_\ell((a+b)/p)\)。式 (10) 及固定有限性给更明确的全图估计
\[
\mathscr L_pG_S
=\left(\sum_{\ell\in S}\lambda_\ell\right)G_S
+O_S((a+b)/p)
\tag{12}
\]
（根取 \(a=b=1\)）。特别地，误差在内区一致趋零。把 (8)、(12) 代入 (6)，得到算术压缩的内区逐行近似，并有全图一致有界的逐行误差。

## 调和质量与 Archimedean 压缩

在互素有序对的调和权 \(1/(ab)\) 下，固定素数 \(\ell\) 的局部 Euler 质量为
\[
1+2\sum_{j\ge1}\ell^{-j}=\frac{\ell+1}{\ell-1}.
\]
因此 free 态的归一化质量为 \(\pi_\ell=(\ell-1)/(\ell+1)\)，且有限多个素数的这些态在 \(H^2\) 主项上独立。更精确地，对任何固定的有限态型，Möbius 反演与调和数渐近给其 \(a,b<p\)、\(a>b\) 的加权质量为 \(H^2/(2\zeta(2))\) 乘相应局部概率，加 \(O_{\mathcal P}(H)\)。对 \(a,b\le p^\alpha\) 同式把 \(H^2\) 改为 \(\alpha^2H^2\)。由 \(\mathbb E g_\ell=0\)、\(\mathbb E g_\ell^2=\sigma_\ell^2\)，立即得到 (4)，根的固定质量可忽略。

固定 \(S\) 时 \(|G_S|=O_S(1)\)，而由 (4) \(\|u_{p,S}\|\asymp_SH\)。式 (12) 的截断误差还可直接平方求和：
\[
\sum_{a/b\in\mathcal F_p}\frac{(a+b)^2}{p^2ab}
\le\frac1{p^2}\sum_{a,b<p}\left(\frac ab+\frac ba+2\right)
\ll H.
\]
因此其作用于 \(u_{p,S}\) 的范数为 \(O_S(\sqrt H)=o(\|u_{p,S}\|)\)。式 (7)--(8) 的行比误差在内区趋零，外区一致有界；外区占全体 \(v^2\) 质量的极限为 \(1-\alpha^2\)。先取 \(p\to\infty\)，再令 \(\alpha\uparrow1\)，便得
\[
\frac{\|\bigl(\widetilde C_p-(2H-2\gamma_E-\sum_{\ell\in S}\lambda_\ell)I\bigr)u_{p,S}\|}
     {\|u_{p,S}\|}\to0.
\tag{13}
\]

scratch 798 的内区 Archimedean 行和估计给：从任一 \(a,b\le p^\alpha\) 节点至其他 Farey 节点的接触常数以外绝对行和为 \(O(p^{-2(1-\alpha)})\)；全族相应行和为 \(O(1)\)。根--Farey 列的 \(\ell^2\) 范数为 \(O(p^{-2})\)，全部根和 Farey 对角均为
\[
d_p:=2H+1-\gamma_E-\log\pi+\log2+o(1).
\tag{14}
\]
矩形 Schur 检验和同一个外区质量极限因此给
\[
\frac{\|(P_{U_p}G_kP_{U_p}-d_pI)u_{p,S}\|}{\|u_{p,S}\|}\to0.
\tag{15}
\]
polar 压缩范数趋零。由 \(B_p=G_k-\widetilde C_p-2|s_k\rangle\langle s_k|\) 与 (13)--(15)，且
\[
d_p-(2H-2\gamma_E)=c_*+o(1),
\]
证明 (3)。自伴矩阵的谱距离不超过任一单位向量的残差范数。各 \(\mu_S\) 不同，因为 \(\lambda_\ell\) 是非零有理数乘 \(\log\ell\)，有限个不同素数的对数在 \(\mathbb Q\) 上线性无关。最后一个结论取 \(S=\{2\}\)；将其与空集向量正交化，(3)--(4) 仍给 \(c_*+3\log2+o(1)\) 的 Rayleigh 商。\(\square\)

## 边界

这给出任意固定数目的有界横向谱模，说明把正权方向以外的全 Farey 图统一压到增长谱隙的策略不成立。它没有给出整个 Farey 主压缩的最低谱值，也没有控制与无限维正交补的 Schur 反馈。所有显示的谱模极限均为正数；这里没有证明全尺度 Weil 正性、真实 moving-\(N\) Möbius signed covariance 界或 RH。
