# 固定周期槽轮廓的低能量部分恰是素数赋值状态

日期：2026-10-03。依赖 [note 004](../notes/004-exact-logarithmic-laplacian-normalization.md)、[note 007](../notes/007-indefinite-polar-splitting-and-reduced-markov-form.md) 的完整 Weil 形式，[note 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md) 的整除矩阵，[note 858](../notes/858-unit-interval-logarithmic-form-has-a-strict-rank-one-gap.md) 的单位槽谱隙，以及 [scratch 981](981-valuation-dependent-microscopic-profiles-have-a-weil-gap.md) 的赋值状态常数块极限。本稿使用固定模数素数定理；是解析证明草稿，尚未异源复核，不作为全尺度 Weil 正性或 RH 的证明。
以下隐含常数均可依赖固定的 \(P,W,\theta\)。

## 定理

固定整数 \(P\ge1\)、有限维复空间
\(W\subset C_c^\infty((-1/2,1/2))\)，以及 \(0<\theta\le1\)。令
\(\mathcal H_P=W^{\mathbb Z/P\mathbb Z}\)，内积为
\[
\langle T,V\rangle_P=\frac1P\sum_{a\bmod P}\langle T_a,V_a\rangle_{L^2(-1/2,1/2)}.
\]
单位群 \(G_P=(\mathbb Z/P\mathbb Z)^\times\) 在余数上乘法作用，定义其正交投影
\[
(\Pi_PT)_a=\frac1{\varphi(P)}\sum_{u\in G_P}T_{ua}.
\tag{1}
\]
沿奇素数 \(p\to\infty\)，置
\[
H=\log p,\quad N=(p^2-3)/2,\quad L=\log N,\quad
L_N=\sum_{n\le N}n^{-1},\quad\ell=2\theta/p^2,
\quad y_n=H-\log(2n).
\]
对 \(u:[0,1]\to\mathcal H_P\)，在第 \(n\) 槽取
\[
(\mathcal U_pu)(y_n+t)
=\frac{\ell^{-1/2}u_{n\bmod P}(\log n/L,t/\ell)}
{\sqrt{nL_N}},\qquad |t|<\ell/2,
\tag{2}
\]
其余处为零。令 \(V_p\subset\mathrm{BV}([0,1];\mathbb C)\) 为有限维空间，包含常数，且到 \(L^2[0,1]\) 单射。设
\[
K_p=\sup_{0\ne f\in V_p}
\frac{\|f\|_\infty+\operatorname{Var}f}{\|f\|_2},
\qquad K_p=o(\sqrt L).
\tag{3}
\]
对 \(u\in\mathcal H_P\otimes V_p\) 记
\(\|u\|_2^2=\int_0^1\|u(x)\|_P^2dx\)，并作正交分解
\[
T=\Pi_P\int_0^1u(x)dx,\qquad w(x)=u(x)-T.
\tag{4}
\]
则对充分大 \(p\)，一致有
\[
\boxed{\quad Q_W^H[\mathcal U_pu]
\ge \frac\delta2\|T\|_P^2+\frac L2\|w\|_2^2>0
\quad(u\ne0),\qquad
\delta=46/25-\log(2\pi)>0.\quad}
\tag{5}
\]
物理范数满足
\(\|\mathcal U_pu\|_2^2=(1+O_{P,W,\theta}(K_p^2/L))\|u\|_2^2\)。
若 \(d_P\) 为 \(P\) 的正因子个数，则恰有
\(d_P\dim W\) 个有界 Rayleigh 本征值；它们收敛到
scratch 981 式 (3) 在赋值状态空间上的正算子本征值。
其余本征值一致为 \(L(1+o(1))\)。特别地，允许每个
余数类有不同复值微观轮廓，而不要求先假设赋值不变性。

## 固定模数的两个计数输入

对于每个 \(r\in G_P\)，固定模数素数定理及分部积分给
\[
A_r(z):=\sum_{\substack{k\le e^z\\k\equiv r\pmod P}}
\frac{\Lambda(k)}k
=\frac z{\varphi(P)}+O_P(1),\qquad z\ge0.
\tag{6}
\]
可从固定模数素数定理的可积误差
\(\psi(x;P,r)=x/\varphi(P)+O_P(xe^{-c_P\sqrt{\log x}})\)
推出；有限小 \(x\) 由常数吸收。若 \(k\) 为与 \(P\) 不互素的
素数幂，则其素数底数整除 \(P\)，且
\[
\sum_{(k,P)>1}\frac{\Lambda(k)}k
\le\sum_{q\mid P}\sum_{j\ge1}\frac{\log q}{q^j}<\infty.
\tag{7}
\]
此外，对任意模 \(P\) 周期序列 \(b_n\)，逐同余类调和求和给
\[
\sum_{n\le e^z}\frac{b_n}{n}
=z\,\frac1P\sum_{a\bmod P}b_a+O_P(\|b\|_\infty),
\qquad z\ge0.
\tag{8}
\]
式 (6)、(8) 的误差都对 \(z\) 一致，所以各自经一次
Stieltjes 分部积分后可与任何 BV 测试函数配对，代价至多为
其上确界加总变差。以下所有向量值估计只需在固定的
\(P\dim W\) 个标量坐标上应用此事实。

## 首阶算子与低块

先令 \(u,v\in\mathcal H_P\otimes\mathrm{BV}([0,1])\)，并以
\(\|u\|_{\mathrm{BV};P}\) 表示在一组固定正交基下全部标量
坐标的 \(\|f\|_\infty+\operatorname{Var}f\) 之和。有限维基的
选择只改变常数。槽相离及素数幂平移仅在 \(r=kn\) 时连接，
包括 \(\theta=1\)；这由 scratch 981 式 (5) 的严格不等式给出。

整除矩阵一侧的未归一化双线性和为
\[
S_N(u,v)=\sum_{n\le N}\frac1n
\sum_{k\le N/n}\frac{\Lambda(k)}k
\left\langle u_{n\bmod P}(x_n),
v_{kn\bmod P}(x_n+\log k/L)\right\rangle,
\quad x_n=\log n/L.
\]
对内层按 \(k\bmod P\) 使用 (6)，并以 (7) 支付非单位
素数幂，可得
\[
\sum_{k\le N/n}\frac{\Lambda(k)}k
v_{kn\bmod P}(x_n+\log k/L)
=L\int_{x_n}^1(\Pi_Pv)_{n\bmod P}(y)dy
+O_{P,W}(\|v\|_{\mathrm{BV};P}).
\tag{9}
\]
对外层再用 (8)，并用
\(\|x\mapsto\langle u(x),\int_x^1\Pi_Pv(y)dy\rangle_P\|_{\rm BV}
\ll_{P,W}\|u\|_{\mathrm{BV};P}\|v\|_{\mathrm{BV};P}\)，
便得到
\[
S_N(u,v)=L^2\int_{0\le x\le y\le1}
\langle u(x),\Pi_Pv(y)\rangle_P\,dx\,dy
+O_{P,W}(L\|u\|_{\mathrm{BV};P}
                  \|v\|_{\mathrm{BV};P}).
\tag{10}
\]
素数幂矩阵的另一侧是 \(\overline{S_N(v,u)}\)。因 \(\Pi_P\)
自伴，两三角域拼成单位方块；除以 \(L_N=L+O(1)\) 后，
\[
Q_{\rm prime}(\mathcal U_pu,\mathcal U_pv)
=-L\left\langle\Pi_P\int_0^1u,
                         \Pi_P\int_0^1v\right\rangle_P
+O_{P,W}(\|u\|_{\mathrm{BV};P}
           \|v\|_{\mathrm{BV};P}).
\tag{11}
\]

式 (8) 同时给物理 Gram
\[
\langle\mathcal U_pu,\mathcal U_pv\rangle
=\int_0^1\langle u(x),v(x)\rangle_Pdx
+O_{P,W}(L^{-1}\|u\|_{\mathrm{BV};P}
                     \|v\|_{\mathrm{BV};P}).
\tag{12}
\]
单槽 Fourier--gamma 项是 \(L\) 倍 (12) 的主项，加
\(O_{P,W}(\|u\|_{\mathrm{BV};P}\|v\|_{\mathrm{BV};P})\)。
普通跨槽核的绝对双和为 \(O_{W,\theta}(1)\)：先用固定
\(W\) 的共同实际支撑间隙控制相邻槽，再用
\(k(\log(r/n))/\sqrt{nr}
=\tfrac12((r-n)^{-1}+(r+n)^{-1})\) 的总和
\(O(N\log N)\)，乘 \(\ell/L_N=O(1/(N\log N))\)。
两个 polar 矩的乘积也是
\(O_{P,W}(\|u\|_{\mathrm{BV};P}\|v\|_{\mathrm{BV};P})\)。
因而完整真实 Weil 形式满足
\[
\boxed{\quad
Q_W^H(\mathcal U_pu,\mathcal U_pv)
=L\left\{\int_0^1\langle u(x),v(x)\rangle_Pdx
-\left\langle\Pi_P\int_0^1u,
                  \Pi_P\int_0^1v\right\rangle_P\right\}
+O_{P,W}(\|u\|_{\mathrm{BV};P}
           \|v\|_{\mathrm{BV};P}).\quad}
\tag{13}
\]
对 (3) 的整个空间，有限个坐标与 Cauchy--Schwarz 给
\(\|u\|_{\mathrm{BV};P}\ll_{P,W}K_p\|u\|_2\)，
因此 (12)--(13) 的误差一致为
\(O_{P,W}(K_p^2/L)\) 和 \(O_{P,W}(K_p^2)\)。

\(G_P\) 乘法在余数上的轨道，恰按
\(\gcd(a,P)\) 分类。保持性显然；反过来，逐素数幂
\(q^j\Vert P\)，同一截断赋值的两个非零余数可由模
\(q^{j-\min(\nu_q(a),j)}\) 的一个单位相乘得到；该单位可
提升为模 \(q^j\) 的单位，再由中国剩余定理合并。
因此 \(\mathrm{Ran}\Pi_P\) 正是只依赖
\((\min(\nu_q(n),\nu_q(P)))_{q\mid P}\) 的轮廓空间。
均匀余数的截断赋值分布正是 scratch 981 中
\(\pi_B\) 的推前测度，其中 \(B=\{q:q\mid P\}\)、
\(J_q=\nu_q(P)\)。

对 (4) 的常数低块 \(T\)，scratch 981 式 (3)--(4) 给
一个固定有限维形式 \(\mathscr L_{P,W}\) 满足
\[
Q_W^H[\mathcal U_pT]
=\mathscr L_{P,W}(T)+o(1)\|T\|_P^2,
\qquad \mathscr L_{P,W}(T)\ge\delta\|T\|_P^2.
\tag{14}
\]
式 (13) 的首阶算子是 \(L(I-P_0)\)，其中
\(P_0u=\Pi_P\int_0^1u\)。由 \(P_0w=0\)，高块至少
\((L-O(K_p^2))\|w\|_2^2\)，低高交叉至多
\(O(K_p)\|T\|_P\|w\|_2\)。由于 \(K_p^2=o(L)\)，
Young 不等式与 (14) 给 (5)。高块的有界谱参数逆为
\(O(L^{-1})\)，故低块的 Schur 扣款为
\(O(K_p^2/L)=o(1)\)。低块维数是
\(d_P\dim W\)，于是得所述谱分离；(12) 将其转为
物理 Rayleigh 本征值。\(\square\)

## 范围

本定理判定固定模数、固定有限维微观轮廓与
\(K_p=o(\sqrt{\log N})\) 的宏观复杂度下的全部线性组合。
它不约束模数随 \(p\) 增长、任意槽系数、格外补空间
的 true-Schur 扣款，也不证明 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md)
式 (15) 的三通道 signed covariance。异源复核与针对性
先例检索完成前，不晋级权威 note。
