# 临界加宽 Farey 槽的非精确源--目标交叉可绝对支付（候选）

日期：2026-09-29。依赖 [scratch 817](817-polynomial-denominator-exterior-slots-have-logarithmic-farey-leakage-candidate.md) 的源、目标族，[scratch 819](819-exterior-farey-forcing-has-an-exact-prime-divisor-norm-asymptotic-candidate.md) 的精确素数 forcing，[scratch 825](825-exterior-farey-forcing-needs-order-log-positive-prime-resonance-for-a-negative-two-plane-candidate.md) 的二维 Gram 预算，以及 [scratch 828](828-widened-farey-slots-with-exact-forcing-still-need-positive-prime-resonance-candidate.md) 的宽槽自能量与异臂高次素数幂支付。下文的近边估计直接证明；整体仍是未异源复核的候选，不能晋级为全算子或 RH 结论。

## 命题

令 \(p\to\infty\) 沿奇素数，\(H=\log p\)，
\[
Q=\lfloor p^{2/3}\rfloor,\qquad B=\lfloor p^{1/4}\rfloor,
\qquad P=p^{23/12},\qquad \eta=\frac{L}{P},
\tag{1}
\]
其中 \(1\le L=L(p)=o(H)\)。用共同半槽宽度 \(\eta\) 定义 817--819 的内部向量 \(v_\eta\) 与目标向量
\(w_\eta=\sum_{m/c\in\mathcal Y_{p,B}}t^{\rm pr}_{m/c}w^{(\eta)}_{m/c}\)，其中
\[
t^{\rm pr}_{m/c}=\frac{F_Q(m)}{\sqrt{mc}},\qquad
F_Q(m)=\sum_{\substack{r\mid m,\ r\text{ prime}\\m/r<Q}}\log r.
\tag{2}
\]
把 \(\langle v_\eta,\mathcal R_{p^2}w_\eta\rangle\) 中中心不完全重合的算术项记为 \(E_{\rm near}\)。则
\[
\boxed{|E_{\rm near}|\ll H^2L^2=o(H^4).}
\tag{3}
\]
特别地，\(L=1\) 时每条非精确边的整数缺陷只能是 \(d=\pm1\)，每条边的重叠核为负，因而 \(0\le E_{\rm near}\ll H^2\)。对任意固定 \(C>0\)，\(\eta=C/P\) 的绝对界也成立，常数可依赖 \(C\)；\(C<1\) 时直接限制到 \(1/P\) 的候选边集合。

结合 819 与 828，(3) 给出
\[
\begin{aligned}
\|t^{\rm pr}\|^2
 &=\left(\frac{307}{18432\zeta(2)}+o(1)\right)H^4,\\
\langle v_\eta,A_{p^2,-}w_\eta\rangle
 &=-\|t^{\rm pr}\|^2+o(H^4),\\
\langle v_\eta,A_{p^2,-}v_\eta\rangle
 &=\left(\frac{7}{54\zeta(2)}+o(1)\right)H^3.
\end{aligned}
\tag{4}
\]
若这个指定二维平面沿无穷多个 \(p\) 有负方向，则其目标异臂**素数**近共振必须满足
\[
\boxed{\quad
\frac{\langle t^{\rm pr},N^{\rm opp,pr}_{\eta}t^{\rm pr}\rangle}
{H\|t^{\rm pr}\|^2}
\ge \frac{2663}{7168}-o(1).
\quad}
\tag{5}
\]
这给 828 的严格 \(\kappa>23/12\) 区间补上 \(\kappa=23/12\) 与 \(o(\log p)\) 倍临界宽度。式 (5) 仍没有估计真实有符号素数和。

## 非精确边的精确整数条件

源 \(x=a/b>1\) 满足 \(1\le b<a<Q\)、\((a,b)=1\)，目标 \(y=m/c\) 满足 \(2\le c\le B\)、\(p\le m<cp\)、\((m,c)=1\)。把源的一臂写为 \(A/D\)，其中有序对 \((A,D)\) 是 \((a,b)\) 或 \((b,a)\)。能把该臂经素数幂 \(n\) 移近目标的整数缺陷为
\[
d=nAc-Dm\in\mathbb Z,
\qquad
\left|\log\left(1+\frac d{Dm}\right)\right|<2\eta.
\tag{6}
\]
对每个 \((A,D,c,m,d)\)，令 \(M=(Dm+d)/c\)。若 \(M\) 不是正整数，则没有这样的边；若是，则所有可能源和移位恰由
\[
n\mid M,\quad n\text{ 为素数幂},\quad A=M/n<Q,
\quad D<Q,\quad A\ne D,\quad(A,D)=1
\tag{7}
\]
给出，另须满足 (6)。同一个源的两臂不可能同时靠近同一外目标，因为其中心相距 \(2\log x\gg Q^{-1}\gg\eta\)。每条边的旧奇算术系数是
\(-\Lambda(n)R_\eta(|\log(1+d/(Dm))|)/\sqrt n\)，其中 \(R_\eta\) 是 818 式 (5) 的偶极自相关核。

因此 \(E_{\rm near}\) 本身有如下精确有限和（不满足 (6) 的指标视为零）：
\[
-\sum_{\substack{1\le D<Q,\ 2\le c\le B,\ p\le m<cp,\ (m,c)=1\\
d\in\mathbb Z\setminus\{0\},\ Dm+d>0,\ c\mid Dm+d}}
\frac{F_Q(m)R_\eta(|\log(1+d/(Dm))|)}{\sqrt{Dm(Dm+d)}}
\sum_{\substack{n\mid M,\ n\text{ prime power}\\
A=M/n<Q,\ A\ne D,\ (A,D)=1}}\Lambda(n),
\qquad M=\frac{Dm+d}{c}.
\tag{7a}
\]

若 \(|d|=1\)，则 \((D,c)=1\)，而 \(m\equiv-dD^{-1}\pmod c\)。在素数 forcing 支撑上写 \(m=hr\)，其中 \(r\) 为素数、\(h<Q\)，并取素数移位 \(n=q\) 时，新边的最小算术方程是
\[
qAc-Dhr=d,\qquad d=\pm1.
\tag{8}
\]
这里 \(q\ne r\)：否则左端可被 \(r>1\) 整除。式 (8) 显示越过临界边界后出现的是两个互异素数的短移位门；下文只在所声明的临界宽度内用绝对计数支付它。

## 边界层绝对估计

由 \(D<Q\)、\(m<cp\le Bp\) 得 \(X:=Dm<P\)。式 (6) 与 \(\eta=L/P=o(1)\) 给
\[
0<|d|\le3L,\qquad
X\ge\frac{P|d|}{3L}.
\tag{9}
\]
特别地，所有有效边都满足
\[
D\ge\frac{Q|d|}{4L},\qquad
c\ge\frac{B|d|}{4L},\qquad
m\ge\frac{Bp|d|}{4L}
\tag{10}
\]
对充分大的 \(p\) 成立。由于 \(|d|\ll L=o(H)\)，有 \(X+d\asymp X\)，且 \(\log M\ll H\)。

源权为 \((AD)^{-1/2}\)，目标 forcing 权为 \(F_Q(m)(mc)^{-1/2}\)。利用 \(nAc=X+d\)，一条边的交叉绝对权恰至多
\[
\frac{F_Q(m)\Lambda(n)}{\sqrt{ADnmc}}
=\frac{F_Q(m)\Lambda(n)}{\sqrt{X(X+d)}}
\ll\frac{F_Q(m)\Lambda(n)}X.
\tag{11}
\]
固定 \((D,c,m,d)\) 后，对 (7) 的所有源与素数幂相加；von Mangoldt 除数恒等式给
\[
\sum_{\substack{n\mid M\\n\text{ 为素数幂}}}\Lambda(n)
=\log M\ll H.
\tag{12}
\]
又 \(F_Q(m)\le\log m\ll H\)、\(|R_\eta|\le1\)。因而
\[
|E_{\rm near}|
\ll H^2
\sum_{1\le|d|\le3L}
\sum_{D\ge Q|d|/(4L)}^{Q-1}\frac1D
\sum_{c\ge B|d|/(4L)}^{B}
\sum_{\substack{Bp|d|/(4L)\le m<Bp\\Dm\equiv-d\pmod c}}
\frac1m.
\tag{13}
\]
若 \(g=(D,c)\nmid d\)，最内层为空；若 \(g\mid d\)，允许的 \(m\) 构成模 \(c/g\) 的一个剩余类，且 \(g\le|d|\)。设 \(\ell_d=1+\log(4L/|d|)\)，则按等差数列的积分比较，最内层至多
\[
\frac{g}{c}\log\frac{4L}{|d|}
+\frac{4L}{Bp|d|}.
\tag{14}
\]
两个外层调和和各为 \(O(\ell_d)\)。对第一项用 \(g\le|d|\)；对第二项只数 \(c\le B\)，可得
\[
|E_{\rm near}|
\ll H^2\sum_{1\le|d|\le3L}
\left(|d|\ell_d^3+\frac{L}{p|d|}\ell_d\right)
\ll H^2L^2.
\tag{15}
\]
最后一步由 \(\sum_{d\le3L}d[1+\log(4L/d)]^3=O(L^2)\) 和初等调和和得到，且对非整数 \(L\) 按整数 \(|d|\) 求和。这证明 (3)。

当 \(L=1\) 时还可精确排除 \(|d|\ge2\)：由 \(D\le Q-1\)、\(m\le Bp-1\) 得 \(X\le(Q-1)(Bp-1)\le P-Bp\)。因此对充分大 \(p\) 有 \(X+2<P\)，从而 \(\log(1+2/X)\ge2/(X+2)>2/P\)；对 \(X>2\) 也有 \(-\log(1-2/X)>2/X>2/P\)。所以 (6) 只允许 \(d=\pm1\)。对这些边，\(X+1<P\) 又给 \(\log(1+1/X)\ge1/(X+1)>1/P=\eta\)，以及 \(-\log(1-1/X)>1/X>\eta\)。因有效边还满足相移小于 \(2\eta\)，818 式 (5) 的外瓣公式给 \(R_\eta(s)=s/(2\eta)-1<0\)。源权与 \(t^{\rm pr}\) 均非负，旧奇算术系数为 \(-\Lambda(n)R_\eta(s)/\sqrt n\)，故 \(E_{\rm near}\ge0\)。此时 (10) 将 \(D,c,m\) 限制在各自最大值的固定比例带内，(13)--(15) 直接给 \(E_{\rm near}=O(H^2)\)。

## 二维门槛与未解决范围

临界宽度仍满足 \(\eta\ll p^{-7/4}\)，故源、目标各自保持正交，全部同臂边保持精确，非算术跨槽项仍为 \(o(H^4)\)。其自对角是 \(\log(1/\eta)+O(1)=(23/12)H-\log L+O(1)=(23/12+o(1))H\)。于是 828 式 (6) 给 (4) 的内部能量；819 的精确 forcing 与 (3) 给 (4) 的交叉。828 的高次素数幂异臂二次型估计在此宽度变为
\[
O_\varepsilon(H^4LB^3p^{-11/12+\varepsilon})
=O_\varepsilon(H^4L p^{-1/6+\varepsilon})=o(1).
\tag{16}
\]
825 式 (6) 的 forcing 支撑同臂界仍为 \((17/12)H+O(1)\)。所以目标对角下界为
\( (1/2+o(1))H\|t^{\rm pr}\|^2
-\langle t^{\rm pr},N^{\rm opp,pr}_\eta t^{\rm pr}\rangle\)。若二维平面有负方向，则用 (4) 配方要求
\[
\frac{\langle t^{\rm pr},N^{\rm opp,pr}_\eta t^{\rm pr}\rangle}
{H\|t^{\rm pr}\|^2}
\ge\frac12-\frac{54}{7}\frac{307}{18432}-o(1)
=\frac{2663}{7168}-o(1),
\]
即 (5)。

对固定 \(7/4<\kappa<23/12\)，写 \(\eta=p^{-\kappa}\) 等于 \(L=p^{23/12-\kappa}\)。式 (15) 只给 \(O(H^2p^{2(23/12-\kappa)})\)，不足以支付 \(H^4\)；不能据此断言新边确实有主项或忽略它们。[scratch 830](830-widened-farey-near-cross-discards-prime-powers-and-is-a-two-prime-shift-candidate.md) 进一步绝对支付该范围的非精确高次素数幂交叉，剩余真实门是互异双素数短移位和。本命题也不估计非精确 forcing 向量自身的范数。即使 (5) 的目标素数二次型得到控制，也只决定这个指定二维平面，不控制完整旧奇算子、全尺度局部 Weil 正性或 moving-\(N\) Möbius signed covariance。
