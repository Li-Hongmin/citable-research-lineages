# 互素直接源的常量级正负块与对数级总相消

日期：2026-10-01。依赖 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 的真实剩余门、[scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的带通核，以及 [scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 核过的 Matomäki--Shao--Tao--Teräväinen 2023 Theorem 3.1(i) 全区间 Möbius 短和。本稿把 [scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 的直接源正负补偿都限制到**物理 gcd 恰为 $1$**，并与 [scratch/868](868-large-physical-gcd-is-paid-in-the-full-observation-gram.md) 的大 gcd 绝对支付相接。所得四种符号配对有同一个精确一阶主常数，整层及距离过滤后的整层有任意固定对数幂相消；完整 signed 和的固定幂上界仍开放。本稿暂留 scratch 待异源复核。

## 定理

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，$\psi\in C_c^3((1,2))$ 实、非负且非零，$\phi=\psi/t$。取 scratch/859 的 $D,R,K_0$ 与 scratch/860 的 $w_H,J_H,K_{s,2}$，置 $L=\lfloor M/(32H)\rfloor$。选固定闭区间 $J\subset(1,2)$，使 $\phi\ge c_\psi>0$ 于 $J$。对 $\sigma\in\{+1,-1\}$，在 scratch/859 式 (12) 的有序剩余门中只取
\[
d=m,\qquad e=n,\qquad m,n\in MJ,\qquad
\mu(m)=+1,\quad\mu(n)=\sigma,
\quad(m,n)=1,
\quad K_0<|m-n|\le L,
\tag{1}
\]
且要求 $m,n$ 位于下文同一个完整长度 $L$ 小格。记这些真实直接源物理项的和为 $\mathfrak X_\sigma(M,H)$。则一致于所给 $H$，
\[
\boxed{\quad
\mathfrak X_+(M,H)\ge c_{s,\psi}>0,
\qquad
\mathfrak X_-(M,H)\le-c_{s,\psi}<0.
\quad}\tag{2}
\]
这里 $c_{s,\psi}$ 与 $M,H$ 无关。两块都处于 [scratch/868](868-large-physical-gcd-is-paid-in-the-full-observation-gram.md) 留下的 $\gcd(m,n)\le H$ 门内。尤其大物理 gcd 的目标量级绝对支付不能代替同一互素层里的真实正负抵消。

## 证明

先建立一个对所有所用小格一致的互素符号计数。取一个待固定的充分大常数 $z$，令 $Q=\prod_{p\le z}p$，并记
\[
\delta_Q=\frac1{\zeta(2)}\prod_{p\le z}\frac p{p+1}>0.
\tag{3}
\]
对任意 $I\subset MJ$、$|I|=L$，展开 $\mu(n)^2=\sum_{a^2\mid n}\mu(a)$，再在每个固定模数 $Q$ 的互素剩余类中计数，得到
\[
\sum_{n\in I,(n,Q)=1}\mu(n)^2
=\delta_QL+O_Q(\sqrt M).
\tag{4}
\]
这里主项来自 $\frac{\varphi(Q)}Q\sum_{(a,Q)=1}\mu(a)/a^2=\delta_Q$；截断 $a\le\sqrt{2M}$ 的尾及逐 $a$ 端点各为 $O_Q(\sqrt M)$。另一方面，所引 2023 定理 3.1(i) 对 $I$ 中每个固定模数 $Q$ 的互素等差进程给任意固定 $A>0$ 的 $O_{A,Q}(L\log^{-A}M)$ Möbius 短和；将有限个进程相加，
\[
\sum_{n\in I,(n,Q)=1}\mu(n)
=O_{A,Q}(L\log^{-A}M).
\tag{5}
\]
因为 $L\asymp M/H\gg M^{3/4}$，(4) 的误差为 $o(L)$，故每个这样的 $I$ 中
\[
\#\{n\in I:(n,Q)=1,\ \mu(n)=\pm1\}
=\left(\frac{\delta_Q}{2}+o_Q(1)\right)L.
\tag{6}
\]

在一个长度 $L$ 的小格中，若两个**不同**整数共有素因子，由 $(m,Q)=(n,Q)=1$，该素数 $p>z$；又因 $|m-n|<L$ 且 $p\mid m-n$，必有 $p<L$。对每个 $z<p<L$，格中 $p$ 的倍数至多 $L/p+1$ 个。因此有公共素因子的有序异点对至多
\[
\sum_{z<p<L}(L/p+1)^2
\le L^2\sum_{p>z}p^{-2}
+O(L\log L+L)
\le\frac{L^2}{z}+o(L^2).
\tag{7}
\]
由 Mertens 乘积定理，$\delta_Q\asymp1/\log z$；故可先固定足够大的 $z$，使 $1/z<\delta_Q^2/32$。由 (6)，每格中 $\mu(m)=+1,\mu(n)=\sigma$ 的有序对数至少为 $(\delta_Q^2/8+o_Q(1))L^2$。扣去 (7) 后仍有 $\gg_Q L^2$ 个互素有序对。再扣去 $|m-n|\le K_0$ 的至多 $O(L(K_0+1))$ 对，余量仍为 $\gg_Q L^2$，因为
\[
\frac{K_0+1}{L}
\ll\frac{H^4}{M\log^7(2M)}+\frac HM=o(1).
\tag{8}
\]
此论证对 $\sigma=\pm1$ 同时成立。

将 $MJ$ 划成完整的长度 $L$ 整数小格，并丢弃两端不足 $L$ 的部分。完整格数 $\asymp_\psi M/L\asymp_\psi H$。由 scratch/861 式 (5)，对同格 $|m-n|\le L$ 有 $J_H(m-n)\gg_s H$。对 $m,n>M$，scratch/859 式 (2) 的真实直接源系数为
\[
b_m(m)=-\frac{4\log2}{M}\phi(m/M),
\qquad
b_n(n)=-\frac{4\log2}{M}\phi(n/M).
\tag{9}
\]
因此 (1) 的每一项的符号恰为 $\mu(m)\mu(n)=\sigma$，绝对值至少为 $c_{s,\psi}H/M^2$。每格有 $\gg_Q L^2$ 项，格数 $\asymp H$，而 $H^2L^2/M^2\asymp1$，故得到 (2)。

最后核对剩余门：$d=m,e=n>M>D$，互素且不同意味着互不整除，约化比例的最大分子、分母为 $\max(m,n)>M>R$；(8) 给近差下限，$L<K_{s,2}$ 给远差上限。故 (1) 的每一项确属 scratch/859 式 (12) 的实际大约化比例、中距离高除数门。$\square$

### 四种符号配对的共同主常数

上述下界还有精确一阶形式。对 $\alpha,\beta\in\{+1,-1\}$，以 $\mathfrak X_{\alpha,\beta}$ 表示把式 (1) 的两个符号条件分别改成 $\mu(m)=\alpha$、$\mu(n)=\beta$ 后所得的有序物理项和；原来的 $\mathfrak X_\sigma=\mathfrak X_{+1,\sigma}$。令 $v=\chi_s^2$、$\widehat v(\xi)=\int_{\mathbb R}v(t)e(-t\xi)\,dt$，并置
\[
 C_{\rm sf,\perp}:=\prod_p\left(1-\frac3{p^2}+\frac2{p^3}\right)>0,
 \qquad
 A_v:=\int_0^1\!\int_0^1\widehat v\!\left(\frac{u-v}{32}\right)du\,dv>0.
\tag{2a}
\]
当 $M\to\infty$、$Y^{1/5}\le H\le Y^{1/4}$ 任意变化时，四个符号块满足一致渐近式
\[
 \boxed{\quad
 \mathfrak X_{\alpha,\beta}(M,H)
 =\alpha\beta\,\frac{C_{\rm sf,\perp}(\log2)^2 A_v}{8}
 \int_J\phi(t)^2\,dt+o_{s,\psi}(1),
 \qquad\alpha,\beta\in\{+1,-1\}.
 \quad}\tag{2b}
\]
因此正负块的主常数绝对值相同；这是局部一阶符号密度的结论，不是目标尺度的二点误差估计。

证明。对任意固定平方自由 $q$，记
\[
 \rho(q)=\frac1{\zeta(2)}\prod_{p\mid q}\frac1{p+1}.
\tag{2c}
\]
在任一长度 $L$ 的完整小格 $I$ 及其任意前缀 $I'$ 上，平方自由恒等式给
\[
 \sum_{n\in I',\,q\mid n}\mu(n)^2
 =\rho(q)|I'|+O_q(\sqrt M).
\tag{2d}
\]
确实，展开 $\mu^2(n)=\sum_{a^2\mid n}\mu(a)$ 后，每个 $a\le\sqrt{2M}$ 的倍数计数是 $|I'|/[q,a^2]+O(1)$；延伸主项到无穷的尾为 $O_q(|I'|/\sqrt M)$。局部素数因子给出 (2c)。2023 Theorem 3.1(i) 的最大等差进程界同时给
\[
 \sup_{I'\text{ 为 }I\text{ 的前缀}}\left|\sum_{n\in I',\,q\mid n}\mu(n)\right|
 \ll_{A}L(\log M)^{-A}.
\tag{2e}
\]
故对 $\alpha=\pm1$，格内满足 $q\mid n$、$\mu(n)=\alpha$ 的归一化位置测度，连同全部前缀，一致收敛到 $(\rho(q)/2)\,du$ 于 $[0,1]$。这里 $O_q(\sqrt M)/L=o(1)$，且定理输入对小格起点一致。

若格的左端为 $a_I$，令 $u_m=(m-a_I)/L$。由 scratch/860 式 (8) 的 Poisson 表达及其 Gevrey 衰减，在 $m,n\in I$ 上一致地有
\[
 \frac{J_H(m-n)}H
 =\widehat v\!\left(\frac{H L}{M}(u_m-u_n)\right)+o(1)
 =\widehat v\!\left(\frac{u_m-u_n}{32}\right)+o(1),
\tag{2f}
\]
因为 $HL/M\to1/32$；又 $\phi(m/M)=\phi(a_I/M)+o(1)$。固定 $q$ 时，两种符号的位置测度的乘积收敛，因而相应有序对的加权和，除以 $HL^2$，一致趋于
\[
 \frac{\rho(q)^2}{4}\,\phi(a_I/M)^2 A_v.
\tag{2g}
\]
删去 $|m-n|\le K_0$ 不改变此极限，因为这类对至多 $O(L(K_0+1))=o(L^2)$ 个。互素反演的尾也一致可控：在 $m\ne n$、同格且 $q\mid(m,n)$ 时 $q\le|m-n|<L$，所以对 $Q<q<L$ 的有序对数按全部 $q$ 过计至多
\[
 \sum_{Q<q<L}(L/q+1)^2
 \ll L^2/Q+L\log L+L.
\tag{2h}
\]
权 $\phi(m/M)\phi(n/M)J_H(m-n)$ 的绝对值为 $O(H)$。先对固定 $Q$ 使用 (2g)，再令 $Q\to\infty$，得到每格互素符号对的极限系数
\[
 \frac14\sum_{q\ge1}\mu(q)\rho(q)^2
 =\frac1{4\zeta(2)^2}\prod_p\left(1-\frac1{(p+1)^2}\right)
 =\frac{C_{\rm sf,\perp}}4.
\tag{2i}
\]
后一 Euler 因子也可直接核算：在素数 $p$ 处，两整数均平方自由且不同时被 $p$ 整除的概率为 $(1-1/p)^2+2(1-1/p)(1/p-1/p^2)=1-3/p^2+2/p^3$，与 (2i) 一致。
最后对完整小格求和。因 $L/M\to0$ 且 $HL/M\to1/32$，
\[
 \sum_I\frac{HL^2}{M^2}\phi(a_I/M)^2
 \longrightarrow\frac1{32}\int_J\phi(t)^2dt.
\tag{2j}
\]
式 (9) 的两个直接源系数给因子 $16(\log2)^2/M^2$，而 $\mu(m)\mu(n)=\alpha\beta$。合并 (2i)--(2j) 即得 (2b)。$A_v>0$ 是因为 $v\ge0$ 非零，且在 $|u-v|\le1$、$|t|\le4$ 时 $|2\pi t(u-v)/32|\le\pi/4$，故积分中的 Fourier 余弦为正。$\square$

## 同一互素层的 signed 总相消

令 $z_m=M^{-1}\mu(m)\phi(m/M)$，并令 $\mathfrak D^{\rm full}_{\perp}$ 为 (1) 所在的**全部互素直接源物理项**在施加距离过滤之前的 signed 和，即
\[
\mathfrak D^{\rm full}_{\perp}
=16(\log2)^2
\sum_{\substack{M<m,n<2M\\(m,n)=1}}
z_mz_nJ_H(m-n).
\tag{10}
\]
则对每个固定 $A>0$，一致于 $Y^{1/5}\le H\le Y^{1/4}$，
\[
\boxed{\quad
\mathfrak D^{\rm full}_{\perp}
=O_{A,s,\psi}((\log M)^{-A}).
\quad}\tag{11}
\]
若只保留剩余门原有的 $K_0<|m-n|\le K_{s,2}$，记为 $\mathfrak D^{\rm gate}_{\perp}$，则
\[
\boxed{\quad
\mathfrak D^{\rm gate}_{\perp}=O_{A,s,\psi}((\log M)^{-A})
\quad}\tag{12}
\]
该界在全部 $Y^{1/5}\le H\le Y^{1/4}$ 上一致成立。它仍不等于 $O_\varepsilon(H^4M^{-1+\varepsilon})$ 的固定幂目标。

证明 (11)。对 $q\ge1$ 设
\[
 Z_{q,h}=\sum_{\substack{M<m<2M\\q\mid m}}z_m e(-hm/M).
\]
有限除数反演 $\mathbf1_{(m,n)=1}=\sum_{q\mid(m,n)}\mu(q)$ 与 $w_H\ge0$ 给精确式及其绝对上界
\[
\frac{\mathfrak D^{\rm full}_{\perp}}{16(\log2)^2}
=\sum_{q\ge1}\mu(q)\sum_hw_H(h)|Z_{q,h}|^2,
\qquad
\left|\frac{\mathfrak D^{\rm full}_{\perp}}{16(\log2)^2}\right|
\le\sum_{q\ge1}\sum_hw_H(h)|Z_{q,h}|^2.
\tag{13}
\]

固定待选的 $B>0$，取 $Q_0=\lfloor(\log M)^B\rfloor$、$L_0=\lfloor M/(32H)\rfloor$、$B_0=\lfloor M^{2/3}\rfloor$。对每个 $q\le Q_0$，所引 2023 定理 3.1(i) 直接控制任意长度 $B_0$ 的物理整数块中 $q$ 的倍数这一等差进程的 Möbius 和为 $O_C(B_0\log^{-C}M)$，一致于该进程的起点及 $q$。把任意长度不超过 $L_0$ 的区间分成整块和至多两个端块；由 $B_0=o(L_0\log^{-C}M)$，再对固定光滑权 $\phi(m/M)$ 作 Abel 求和，得到对任意固定 $C>0$ 的一致界
\[
\sup_{\substack{I\subset(M,2M)\\|I|\le L_0}}
\left|\sum_{m\in I,\ q\mid m}z_m\right|
\ll_{C,\psi}\frac{L_0}{M}(\log M)^{-C}
\qquad(q\le Q_0).
\tag{14}
\]
与 [scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 式 (11) 完全相同的周期 Parseval 论证：$V_h=\sum_{j=0}^{L_0-1}e(-hj/M)$ 在 $w_H$ 支撑上满足 $|V_h|\gg L_0$，并且 $z_m$ 在周期拼接处为零。式 (14) 因而给
\[
\sum_hw_H(h)|Z_{q,h}|^2
\ll_{C,s,\psi}(\log M)^{-2C}
\qquad(q\le Q_0).
\tag{15}
\]

对 $q>Q_0$ 的非对角项直接展开平方并取绝对值。因 $|z_m|\ll_\psi M^{-1}$，且紧支撑使非对角公共除数 $q\le|m-n|<(1-\kappa_\psi)M$，每个 $q$ 的 $m$ 候选数为 $O(M/q)$；[scratch/868](868-large-physical-gcd-is-paid-in-the-full-observation-gram.md) 式 (6) 又给 $\sum_{k\ne0}|J_H(qk)|\ll M/q$。故
\[
\sum_{q>Q_0}\sum_{\substack{m\ne n\\q\mid m,n}}
|z_mz_nJ_H(m-n)|
\ll_{s,\psi}\sum_{q>Q_0}q^{-2}
\ll Q_0^{-1}.
\tag{16}
\]
对角绝对量至多
\[
\sum_{M<m<2M}|z_m|^2|J_H(0)|
\#\{q>Q_0:q\mid m\}
\ll_\psi\frac H{M^2}\sum_{M<m<2M}\tau(m)
\ll_\psi\frac{H\log(2M)}M.
\tag{17}
\]
由 (13)--(17)，$|\mathfrak D^{\rm full}_{\perp}|\ll Q_0\log^{-2C}M+Q_0^{-1}+H\log M/M$。对给定 $A$ 先取 $B>A+1$、再取 $C>B+A$，即证 (11)。

证明 (12) 只需删去近差与远差。近差也可利用真实 Möbius 符号，而无须承受绝对估计的 $\log^{-7}M$ 上限。令 $K=\lfloor K_0\rfloor$、$Q_0=\lfloor(\log M)^B\rfloor$，并将 $0<|m-n|\le K$ 的互素指示按式 (13) 的除数反演展开。由于 $H\ge Y^{1/5}$，一致地有 $K\gg M^{3/5}\log^{-7}M$；又 $H\le Y^{1/4}$ 给 $K\ll M^{3/4}$。所以长度 $2K$ 落在所引 2023 Theorem 3.1(i) 的 $M^{7/12+\epsilon}\le2K\le M^{1-\epsilon}$ 范围内，取例如固定 $\epsilon=1/100$ 即可。

固定 $q\le Q_0$ 和 $m$。该定理的**等差进程上确界**对 $(m-K,m+K]$ 中每个 $q\mid n$ 的左、右子进程及其前缀都给 $O_C(K\log^{-C}M)$ 的 $\mu$ 和。对固定 $m$，权
\[
 n\longmapsto \phi(n/M)J_H(m-n)
\]
在此区间的上确界与总变差均为 $O_{s,\psi}(H)$：确有 $|J_H|\ll_s H$、$|J_H'|\ll_s H^2/M$，而 $HK/M\ll1$。分别对 $n<m$、$n>m$ 作 Abel 求和，得到
\[
 \left|\sum_{\substack{0<|n-m|\le K\\q\mid n}}z_nJ_H(m-n)\right|
 \ll_{C,s,\psi}\frac{HK}{M}(\log M)^{-C}.
\tag{18}
\]
再按 $q\mid m$ 求和，并用 $\sum_m|z_m|\ll_\psi1$，小除数贡献为
\[
 O_{C,s,\psi}\!\left(\frac{HK}{M}Q_0(\log M)^{-C}\right).
\tag{19}
\]
对 $q>Q_0$ 直接取绝对值。因 $m\ne n$ 且 $q\mid(m,n)$，必有 $q\le K$；每个 $q$ 至多有 $O(M/q)$ 个 $m$，每个 $m$ 至多有 $O(K/q)$ 个允许的 $n=m+qj$，$j\ne0$。于是大除数贡献为
\[
 O_{s,\psi}\!\left(\frac{H}{M^2}\sum_{Q_0<q\le K}\frac Mq\frac Kq\right)
 \ll_{s,\psi}\frac{HK}{MQ_0}.
\tag{20}
\]
给定任意 $A>0$，先取 $B>A+1$，再取 $C>B+A+1$，式 (19)--(20) 证明近差 signed 和为 $O_{A,s,\psi}(HK M^{-1}\log^{-A}M)$；因 $HK/M\ll1$，它有任意固定对数幂节省。这里 $m=n$ 不在和内，且 $m>1$ 时本来不可能满足 $(m,m)=1$。

对 $|m-n|>K_{s,2}$，注意直接源 $d=m>D$ 使 $B(m)\ge4(\log2)|\phi(m/M)|/M\ge4(\log2)|z_m|$；故 scratch/860 式 (3) 的全物理绝对界给 $O_{s,\psi}(M^{-2})$。互素且 $m\ne n$ 的直接源自动满足原门的高除数、非整除及大约化比例条件，所以无其他删项。这证明 (12)。$\square$

## 边界

式 (2b) 给两个真实子块相反且绝对值相同的显式一阶主常数；式 (11)--(12) 证明整层及原距离过滤后的整层都通过实际 Möbius 符号达到任意固定对数幂的总相消。这些一阶结果将未决量定位为二点 signed 误差：目标 $H^4/M$ 在固定幂次低于 $Y^{1/4}$ 时趋零，仍须在**同一互素层**中证明固定幂级的联合相消，或通过它与其他小 gcd、非直接源的真实交叉完成补偿。单独消去大 gcd 和任意固定对数幂估计都不关闭 RH 门。
