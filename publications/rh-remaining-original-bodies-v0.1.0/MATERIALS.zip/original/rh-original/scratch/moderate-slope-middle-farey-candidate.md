# Candidate: moderate-slope middle Farey slots

Let p tend to infinity through odd primes, P=p-1, H=log p, Q=floor(P/H), S=floor(P/H^alpha), A=floor(P^theta). Fix alpha>1, r>2/(1-3/pi^2), 0<theta<(sqrt(5)-1)/2, and 0<eta<1. Put R=floor(eta H). Retain D_A,N,G,L,E from note 823 and set

M = span{psi_{a/b}: A<a<=S, 2<=a/b<=R}.

Claim: on D_A+N+G+E+M the old odd Weil compression has a linear gap (min{gamma_r,2-(1+sqrt(5))theta,2(1-eta)}-o(1))H. Upon adding L, the gap is log H-log log H-O_{alpha,r,theta,eta}(1). All Farey step dipoles can then be added with gap c_0-o(1). For eta=1/2 the linear coefficient stays kappa_{theta,r}, and the only missing constant slots are A<a<=S and a/b>floor(H/2).

Proof sketch for independent review (please verify every bound and basis issue):

Delete the same positive opposite-arm Archimedean matrix B once on the whole space, as in notes 821-823. Note 823 gives the reduced F=D_A+N+G+E block a (kappa-o(1))H gap and the L block a log H-log log H-O(1) gap, with reduced F-L cross O(sqrt H). Here kappa=min{gamma_r,2-(1+sqrt(5))theta}>0.

Write T(X)=sum_{n<=X}Lambda(n)/sqrt(n)=(2+o(1))sqrt(X), by partial summation from PNT. If x,y in [2,R], then a same-arm edge has integer prime-power ratio <=R, with at most two candidate y per n for fixed x; an opposite-arm edge has integer prime-power product <=R^2, with at most one candidate. Therefore the absolute row sums of C^-_{MM} are at most 2T(R)+T(R^2)=(2+o(1))R. Symmetry gives the same column bound. The full inner I_Q nonarithmetic same-arm norm and polar term are O(H^-1), while D_p=2H+O(1), so the reduced M block is >=(2-2eta-o(1))H.

For M to N, x<=R and y<2 force every prime-power ratio or product <=2R. Each n gives at most two candidates in either row or column, hence ||C^-_{MN}||=O(sqrt R)=O(sqrt H). For M to L, y<=r instead gives ||C^-_{ML}||=O_r(sqrt R)=O_r(sqrt H). The nonarithmetic I_Q-to-outer cross is O(1), and the polar M-L cross is O(H^-1/2).

For D_A to M, use the ordered coprime pair graph of note 803. Except for its global O(log H) cross-exponent-zero remainder, a single-coordinate edge must increase the numerator from n<=A to m>A, leaving the destination denominator t<=A unchanged. Since the destination slope is <=R, m<=Rt<=RA. Dropping coprimality and slope restrictions, either tensor term is bounded by the direct-sum one-coordinate rectangle K_{(A,RA],[1,A]}. With weight v_j=j^-1/2, the high-side weighted row sum is <=log m<=log(RA); the low-side weighted row sum is <=M(RA/n)-M(A/n)<=log R+O(1), uniformly because A/n>=1. Thus ||C^-_{M,D_A}||=O(sqrt(H log H))=o(H).

Notes 819 and 813, respectively, bound M to G and E by O_{alpha,r}(sqrt(H log H)), as M subset I_S. The nonarithmetic cross inside I_Q is O(H^-1), and M-E nonarithmetic and polar crosses are O_r(1). Consequently the total reduced M-F cross is o(H). The F+M block has the claimed linear gap by a two-block scalar comparison.

The reduced M-L cross is O_r(sqrt H), so the reduced L-(F+M) cross is O_r(sqrt H). Completing the square against the linear F+M gap removes O(1) from the L gap. Restore B>=0, then use the O(1) full constant-slot-to-W_p mixed norm from note 806 and the (c_0-o(1)) W_p gap from note 804.

Please identify any false claim, endpoint omission, misuse of Schur bounds, positive matrix issue, or incorrect asymptotic coefficient. Do not edit files. A failed theorem is an acceptable verdict.

## Next arithmetic hinge (exploratory, not part of the reviewed theorem)

Let U be the remaining slots A<a<=S, a/b>floor(H/2), and let e_{3/2} belong to N. For each prime q>=5 in (A/3,S/3], x_1=3q/2 belongs to U and C^-(x_1,3/2)=+(log q)/sqrt(q). For each prime q>=5 in (A/2,S/2], x_2=2q/3 belongs to U and C^-(x_2,3/2)=-(log q)/sqrt(q). The target sets are disjoint. Prime number theorem and partial summation therefore give

||P_U C^- e_{3/2}||^2 >= (1-theta^2+o(1))H^2.

Thus adjoining the full remaining U cannot treat its N cross as o(H). This is only a column lower bound; it neither gives a negative Weil direction nor determines the true inverse response on U.
