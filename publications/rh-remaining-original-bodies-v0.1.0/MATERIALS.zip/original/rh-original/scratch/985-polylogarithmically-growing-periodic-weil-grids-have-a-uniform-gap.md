# 缓增周期与最大槽宽的整数 Weil 格仍有统一正隙

日期：2026-10-03。承接 [scratch 984](984-maximal-width-periodic-weil-grids-allow-arbitrary-microscopic-profiles.md) 的最大宽度 Carleman 估计与 [scratch 983](983-arbitrary-microscopic-profiles-on-fixed-period-weil-grids.md) 的周期整除分解；使用标准 Siegel–Walfisz 素数定理把周期从固定 \(P\) 推到小于 \(\log N\) 的固定幂。以下为未异源复核的解析草稿，不作为全尺度 Weil 正性或 RH 的证明。

## 定理

固定 \(0<\sigma<1\)。沿奇素数 \(p\to\infty\)，记
\[
H=\log p,\quad N=(p^2-3)/2,\quad L=\log N,\quad
L_N=\sum_{n\le N}n^{-1}.
\]
允许整数周期 \(P=P_p\) 任意满足 \(1\le P\le L^{1-\sigma}\)；允许 \(0<\theta=\theta_p\le1\)。对每个余数类 \(a\bmod P\) 任意取随 \(p\) 变化的复值轮廓 \(T_a\in C_c^\infty((-1/2,1/2))\)，且
\(v=P^{-1}\sum_a\|T_a\|_2^2>0\)。置 \(\ell=2\theta/p^2\)、\(y_n=H-\log(2n)\)，并在 \(|t|<\ell/2\) 取
\[
U_p(y_n+t)=\frac{\ell^{-1/2}T_{n\bmod P}(t/\ell)}{\sqrt{nL_N}}
\quad(1\le n\le N),
\]
其余处为零。则存在只依赖 \(\sigma\) 的 \(\epsilon_\sigma(N)\to0\)，使一致于上述全部参数、周期和轮廓，
\[
\boxed{\quad
\|U_p\|_2^2=v\left(1+O\!\left(\frac P L\right)\right),
\qquad
Q_W^H[U_p]\ge
\left(\frac{46}{25}-\log(2\pi)-\epsilon_\sigma(N)\right)v.
\quad}                                                       \tag{1}
\]
这里 \(P\) 可以每次改变，微观轮廓的维数、频率与端点支撑间隙均不受统一限制；\(\theta=1\) 也包含在内。结论仅对这些周期槽数据的压缩成立。

## 周期求和与普通核

以下常数若无下标则绝对，带 \(\sigma\) 者可依赖固定 \(\sigma\)。对周期 \(P\) 的复序列 \(z_n\)，直接按余数类作调和求和，得到对所有 \(X\ge1\)
\[
\sum_{n\le X}\frac{z_n}{n}
=\frac{\log X}{P}\sum_{a\bmod P}z_a
 +O\!\left(\sum_{a\bmod P}|z_a|\right).             \tag{2}
\]
对非负 \(z_n\) 亦可将误差写成 \(O(P\bar z)\)，\(\bar z=P^{-1}\sum z_a\)。普通计数有类似的 \(\sum_{n\le X}z_n=X\bar z+O(\sum_a|z_a|)\)。这些界对 \(X<P\) 仍由平凡估计成立。因为 \(\sum_a\|T_a\|_2^2=Pv\)，(2) 给
\[
g_N:=\frac1{L_N}\sum_{n\le N}\frac{\|T_n\|_2^2}{n}
=v+O(Pv/L),\qquad
s_N:=\frac1{L_N}\sum_{n\le N}\frac{|\kappa_n|^2}{n}
=s+O(Pv/L),                                             \tag{3}
\]
其中 \(T_n=T_{n\bmod P}\)、\(\kappa_n=\int T_n\)、\(s=P^{-1}\sum|\kappa_a|^2\)。式 (1) 的范数等于 \(g_N\)。槽相离及 prime-shift 精确整除性质由 scratch 984 式 (2) 给出，和周期大小无关。

设 \(t=|P^{-1}\sum_a\kappa_a|^2\)。scratch 984 式 (4)--(7) 的相邻槽 Carleman 论证实际上对增长周期也有统一误差
\[
\frac1{L_N}\sum_{n<r\le N}
\frac{|\mathcal K_{nr}-\ell\kappa_n\overline{\kappa_r}k(\log(r/n))|}{\sqrt{nr}}
\ll\frac vL.                                               \tag{4}
\]
核对其周期常数：常规配对的导数误差由
\(\sum_{n\le N}n\|T_n\|_2^2\le N\sum_{n\le N}\|T_n\|_2^2\ll N(N+P)v\)
支付；远配对用 Cauchy–Schwarz 给
\((\sum_{n\le N}\|T_n\|_2/\sqrt n)^2\ll(N+P)Lv\)；近接触配对 \(r=n+1,n>N/3\) 的 Carleman 上界乘 \(n^{-1}\) 后总计
\(\ll N^{-1}\sum_{n\le N}\|T_n\|_2^2\ll v\)。由于 \(P=o(N)\)、\(\ell<1/N\)，除以 \(L_N\) 得 (4)。

周期自相关 \(c_d=P^{-1}\sum_a\operatorname{Re}(\kappa_a\overline{\kappa_{a+d}})\) 满足 \(|c_d|\le s\le v\)、\(P^{-1}\sum_{d\bmod P}c_d=t\)。对每个 \(d\)，一个不满周期造成的误差至多
\(\sum_{a\bmod P}|\kappa_a\kappa_{a+d}|\le Pv\)。再对周期 \(c_d\) 用 (2)，得到
\[
\sum_{n<r\le N}\frac{\operatorname{Re}(\kappa_n\overline{\kappa_r})}{r-n}
=N\log N\,t+O(NPv),
\qquad
\sum_{n<r\le N}\frac{|\kappa_n\kappa_r|}{r+n}\ll Nv+Pv.
\tag{5}
\]
对第二式，先用 \(2ab\le a^2+b^2\)。固定 \(r\) 时
\(\sum_{n<r}(r+n)^{-1}\le\log2+O(r^{-1})\)；固定 \(n\) 时
\(\sum_{r>n}(r+n)^{-1}\ll\log(2N/n)\)。对周期非负序列
\(z_n=|\kappa_n|^2\)，普通周期计数再作一次 Abel 求和给
\(\sum_{n\le N}z_n\log(2N/n)\ll Nv+Pv\log(2N)\ll Nv\)，因为
\(P\le L^{1-\sigma}\ll N/L\)。这证明所写的第二式。
scratch 984 式 (8) 的中心核恒等式与 (4)--(5) 遂给
\[
Q_{\rm ord}=-\theta t+O(Pv/L).                       \tag{6}
\]

极点矩的两种周期和满足
\(\sum_{n\le N}\kappa_n/n=L_N\bar\kappa+O(P\sqrt v)\)、
\(\sum_{n\le N}\kappa_n=N\bar\kappa+O(P\sqrt v)\)，因为
\(\sum_a|\kappa_a|\le P\sqrt v\)。逐槽指数矩误差由
\(|e^{\pm u/2}-1|\ll\ell\) 与 \(\|T_a\|_1\le\|T_a\|_2\) 一致支付，故
\[
Q_{\rm pol}=2\theta t+O(Pv/L).                    \tag{7}
\]
同槽 Fourier–gamma 的可积余项不依赖 \(P,\theta,T\)；由 note 858 的一槽不等式，若 \(\delta=46/25-\log(2\pi)\)，则
\[
Q_{\rm diag}\ge
\{\log(1/\ell)+\delta-\gamma\}g_N-s_N-O(\ell g_N).
\tag{8}

## 增长模数的素数幂罚项

令 \(G_P=(\mathbb Z/P\mathbb Z)^\times\)，\(\Pi_P\) 为其在余数上的平均投影。写 \(T=T^0+T^1\)，其中 \(T^0=\Pi_PT\)、\(T^1=(I-\Pi_P)T\)，并置
\(l=\|T^0\|_P\)、\(h=\|T^1\|_P\)、\(v=l^2+h^2\)。积分后的对应平方范数为 \(s=s_0+s_1\)，其中 \(s_1\le h^2\)，且 \(t\le v\)。note 854 的平方差恒等式仍给
\[
Q_{\rm prime}=-(L-\gamma)g_N+D_N+o_\sigma(1)v,
\quad
D_N=\frac1{L_N}\sum_{k\ge2}\frac{\Lambda(k)}k
\sum_{n\le N/k}\frac{\|T_n-T_{kn}\|_2^2}{n}\ge0.    \tag{9}
\]
这里的 \(o_\sigma(1)\) 对增长 \(P\) 一致。确实，令
\(R(x)=\sum_{k\le x}\Lambda(k)/k-\log x+\gamma\to0\)。按
\(n\le N/A\) 与 \(n>N/A\) 分段，前段至多
\(\sup_{x\ge A}|R(x)|g_N\)，后段由 (2) 至多
\(O(v(\log A+P)/L)\)；先令 \(N\to\infty\) 再令 \(A\to\infty\)。

取 \(\beta=\sigma/3\)、\(z_0=L^\beta\)。Siegel–Walfisz 定理说：对任意固定 \(A,B>0\)，若 \((a,q)=1\)、\(q\le(\log x)^B\)，则
\(\sum_{n\le x,n\equiv a\pmod q}\Lambda(n)
=x/\varphi(q)+O_{A,B}(x/(\log x)^A)\)，一致于 \(a,q,x\)（常数可以无效）。选 \(B>3(1-\sigma)/\sigma\)、\(A>3\)，则当 \(x=e^z\)、\(z\ge z_0\) 时，\(P\le L^{1-\sigma}\le z^B\)。在 \(x<e^{z_0}\) 用 \(\sum_{n\le x}\Lambda(n)/n\ll\log x\)；在其余区间对 Siegel–Walfisz 作分部积分。得到对每个 \(u\in G_P\)、\(0\le z\le L\) 统一的
\[
F_u(z):=\sum_{\substack{k\le e^z\\ k\equiv u\pmod P}}\frac{\Lambda(k)}k
=\frac z{\varphi(P)}+O_\sigma(L^\beta),
\quad
\sum_{\substack{k\le N\\k\equiv u\pmod P}}
\frac{\Lambda(k)}k\log(N/k)
=\frac{L^2}{2\varphi(P)}+O_\sigma(L^{1+\beta}).  \tag{10}
\]

对 \(u\in G_P\) 记 \(b_u=P^{-1}\sum_a\|T_a^1-T_{ua}^1\|_2^2\)。由 (2)，\(k\equiv u\pmod P\) 时内层调和和为
\(b_u\log(N/k)+O(Pb_u)\)。且 \(b_u\le4h^2\)、
\(\varphi(P)^{-1}\sum_ub_u=2h^2\)。将 (10) 代入 (9)，其中 \(O(Pb_u)\) 的总费用由
\(\sum_{k\le N}\Lambda(k)/k\ll L\) 支付，得
\[
D_N^{\rm unit}
=Lh^2+O_\sigma\!\left((P+P L^\beta+1)h^2\right)
\ge(L-E_L)h^2,
\quad E_L=O_\sigma(L^{1-2\sigma/3})=o(L).             \tag{11}
\]
这里用 \(\varphi(P)\le P\le L^{1-\sigma}\)。

若素数幂 \(k=q^j\) 与 \(P\) 不互素，则 \(q\mid P\)。其权重总量满足
\[
\sum_{q\mid P}\sum_{j\ge1}\frac{\log q}{q^j}
=\sum_{q\mid P}\frac{\log q}{q-1}
\le\log P.                                                \tag{12}
\]
这里不能仅凭权重总量界定坏项：\(a\mapsto q^ja\) 在模 \(P\) 上会合并余数类。令 \(d_{q,j}=\gcd(q^j,P)\)、\(J_q=\nu_q(P)\)。对任何周期轮廓 \(V\)，每个输出余数的原像至多 \(d_{q,j}\) 个，故
\[
\frac1P\sum_{a\bmod P}\|V_{q^ja}\|_2^2
\le d_{q,j}\|V\|_P^2,
\qquad
\sum_{q\mid P}\sum_{j\ge1}\frac{\log q}{q^j}d_{q,j}
\ll\sum_{q\mid P}(J_q+1)\log q\ll\log P.          \tag{12a}
\]
此外 \(\sum_{q\mid P,j\ge1}j(\log q)^2d_{q,j}/q^j\ll(\log P)^2\)。因此 \(D_N^{\rm bad}(V)\ll(1+P/L)(\log P)\|V\|_P^2\)。对 \(T^0\)，把每个平方差周期序列的调和和用 (2) 替换成 \(\log(N/q^j)\) 乘平均值；式 (12a) 支付调和误差，带因子 \(j\log q\) 的第二个界支付主项与极限 Dirichlet 形式的差。\(q^j>N\) 的极限尾由同一加权几何级数支付。遂得
\[
D_N^{\rm bad}(T^0)
=D_B(T^0)+O\!\left(
\frac{P\log P+(\log P)^2}{L}l^2\right)
=D_B(T^0)+o_\sigma(1)l^2.                           \tag{13}
\]
这里 \(D_B\) 是按各 \(q\mid P\) 的截断素数赋值状态定义的极限 Dirichlet 形式，模 \(P\) 的均匀余数分布恰给这些状态的乘积几何分布。其 Hilbert 空间值形式由标量积分的收缩给
\[
D_B(T^0)\ge2\log2\,(s_0-t).                     \tag{14}
\]
证明 (14) 只用 note 859 式 (12) 的单坐标方差常数
\(q\log q/(q-1)\ge2\log2\) 与乘积测度方差张量化，因此常数与 \(P\) 的素因子个数无关。由 (12a) 和平方差的 Cauchy–Schwarz，坏项的高低混合绝对值至多
\(C(\log P)lh\)，故
\[
D_N^{\rm bad}(T)
\ge2\log2\,(s_0-t)-C(\log P)lh-o_\sigma(1)l^2.       \tag{15}
\]

## 合并

由 (3)、(6)--(9)、(11)、(15)，保留 \(\log(1/\theta)g_N\) 原样，得
\[
\begin{aligned}
Q_W^H[U_p]-\delta v\ge{}&
\log(1/\theta)g_N-(1-\theta)t
+(2\log2-1)(s_0-t)\\
&+(L-E_L-1)h^2-C(\log P)lh-o_\sigma(1)v.
\end{aligned}                                             \tag{16}
\]
这里 \(\log(1/(\ell N))=\log(1/\theta)+O(N^{-1})\) 且 \(\delta(g_N-v)\)、\(s_N-s\) 仅为 \(O(Pv/L)=o(v)\)；\(\theta\) 的对数未与这个误差相乘。因 \(g_N\ge t-O(Pv/L)\) 及 \(-\log\theta\ge1-\theta\)，首行前两项至少为 \(-O(Pv/L)\)，而第三项非负。最后一行完成平方的负值至多
\[
O\!\left(\frac{(\log P)^2}{L-E_L-1}\right)l^2=o_\sigma(1)v.
\]
这证明 (1)。特别是在 \(P=L^{1-\sigma}\) 的边缘，统一损失仍为 \(O_\sigma(L^{-2\sigma/3})\) 加素数定理的 \(o(1)\) 余项。

## 边界

此结果把周期从固定模数推进到 \(P\le(\log N)^{1-\sigma}\)，在 \(\theta=1\) 仍允许每槽微观形状随尺度任意改变。它没有控制超过此范围的周期，更不覆盖一般非周期槽序列、槽外补空间或 note 849 式 (15) 的 moving-\(N\) Möbius signed covariance。异源证明复核和针对性先例检索前不晋级为权威 note。
