# 末带相邻载波 Gram 的增长有限节最小谱值指数趋零

日期：2026-10-02。依赖 [note 846](../notes/846-terminal-carrier-prime-source-signed-cross-gram.md) 式 (1)、(2)、(4a) 的真实末带素数源极限 Gram。本文只对该**极限 Toeplitz Gram** 给出解析上界；note 846 的误差仅对固定载波集一致，不能据此令载波数随 $Y$ 增长。此为探索证明，尚待异源复核，不控制完整 moving-$N$ 均方或 RH。

## 定理

令
\[
 w(z)=\frac{\mathcal L(z)^2}{z^2}>0\quad(3/2<z<8/5),
 \qquad
 \kappa_d=\frac1{2\pi^2}\int_{3/2}^{8/5}w(z)\cos(2\pi dz)\,dz,
\]
其中 $\mathcal L$ 是 note 846 式 (1) 的函数。对 $R\ge1$，令
$K_R=(\kappa_{r-s})_{0\le r,s\le R}$，并置
\[
 q=\sin^2(\pi/10)=\frac{3-\sqrt5}{8}<\frac1{10}.
\]
则 $K_R$ 对每个有限 $R$ 严格正定，但满足显式上界
\[
 \boxed{\quad
 0<\lambda_{\min}(K_R)
 \le\kappa_0(2R+1)q^R.
 \quad}\tag{1}
\]
事实上用中心二项式系数的标准估计，可把右端的 $2R+1$ 改为 $O(\sqrt R)$。因此这些正定有限 Gram 没有与载波数无关的正谱隙；对应的非负半无限 Toeplitz 型二次型在有限支撑向量上严格正，但其单位球下确界为零。

对证明中的非负单位向量 $x$，其对角质量恰为 $\kappa_0$，不同载波间的带符号质量满足
\[
 -\kappa_0\le\sum_{\substack{0\le r,s\le R\\r\ne s}}x_rx_s\kappa_{r-s}
 \le-\kappa_0+\kappa_0(2R+1)q^R.
\tag{1a}
\]
因此相邻载波的真实极限交叉 Gram 可抵消其对角质量的任意预定比例。

更贴近原始源装配的是**等权**向量。对任意 $R\ge0$，有
\[
 \boxed{\quad
 0<\sum_{r,s=0}^R\kappa_{r-s}
 \le\frac{\kappa_0}{\cos^2(\pi/10)}.
 \quad}\tag{1b}
\]
故等权对角质量为 $(R+1)\kappa_0$，而全部不同载波的交叉质量至多为
$-R\kappa_0+\kappa_0/\cos^2(\pi/10)$。这里的系数全为 $1$，不需要二项式调权。
事实上极限 Gram 的等权联合能量有精确极限
\[
 \lim_{R\to\infty}\sum_{r,s=0}^R\kappa_{r-s}
 =\frac1{4\pi^2}\int_{3/2}^{8/5}
   \frac{w(z)}{\cos^2(\pi(z-3/2))}\,dz>0.
\tag{1c}
\]

## 证明

note 846 式 (4a) 对实向量 $x=(x_0,\ldots,x_R)$ 给出
\[
 x^{\mathsf T}K_Rx
 =\frac1{2\pi^2}\int_{3/2}^{8/5}w(z)
   \left|\sum_{r=0}^R x_re^{2\pi irz}\right|^2dz.\tag{2}
\]
若右端为零，三角多项式在一个开区间恒零，故 $x=0$；这证明有限正定性。

取 $x_r=\binom Rr/\sqrt{\binom{2R}R}$。Vandermonde 恒等式给
$\sum_{r=0}^R x_r^2=1$，而二项式定理给
\[
 \sum_{r=0}^R x_re^{2\pi irz}
 =\frac{(1+e^{2\pi iz})^R}{\sqrt{\binom{2R}R}}.
\tag{3}
\]
写 $z=3/2+t$、$0\le t\le1/10$。由于 $e^{2\pi iz}=-e^{2\pi it}$，
\[
 |1+e^{2\pi iz}|
 =|1-e^{2\pi it}|
 =2\sin(\pi t)
 \le2\sin(\pi/10).
\tag{4}
\]
将 (3)–(4) 代入 (2)，得到
\[
 x^{\mathsf T}K_Rx
 \le \kappa_0\frac{[4\sin^2(\pi/10)]^R}{\binom{2R}R}.
\tag{5}
\]
中央二项式系数是 $\binom{2R}0,\ldots,\binom{2R}{2R}$ 中最大者，其和为 $4^R$，故
$\binom{2R}R\ge4^R/(2R+1)$。Rayleigh 原理把 (5) 变成 (1)。取上述单位向量并令 $R\to\infty$，因 $q<1$，二次型值趋零；半无限形式没有正下界。$\square$

式 (1a) 将 $x^{\mathsf T}K_Rx$ 拆成对角项 $\kappa_0\sum x_r^2=\kappa_0$ 与非对角项，再使用 (5) 的试向量上界和 (2) 的非负性。

为证 (1b)，在 (2) 中取每个 $x_r=1$，并用几何和
\[
 \left|\sum_{r=0}^Re^{2\pi irz}\right|
 =\left|\frac{1-e^{2\pi i(R+1)z}}{1-e^{2\pi iz}}\right|
 \le\frac1{\cos(\pi/10)},
\]
因为 $z=3/2+t$、$0\le t\le1/10$ 时分子至多 $2$，分母
$|1+e^{2\pi it}|=2\cos(\pi t)\ge2\cos(\pi/10)$。正性仍由 (2) 的三角多项式论证给出。
把几何和模方的分子写为 $2-2\cos(2\pi(R+1)z)$；分母在观察区间严格远离零，故加权振荡积分由 Riemann--Lebesgue 引理趋零。余下非振荡项恰为 (1c)。

## 对真实源管的精确含义

对**先固定**的 $R$ 和上面的 $x$，note 846 式 (2) 可逐项求和，因而
\[
 \lim_{Y\to\infty}
 \frac{H^4(\log Y)^4}{Y^3}
 \sum_{3Y/2<N\le8Y/5}
 \left|\sum_{r=0}^R x_rG_r(N)\right|^2
 =x^{\mathsf T}K_Rx\le\kappa_0(2R+1)q^R.
\tag{6}
\]
所以任意预定的小相对阈值，都可先选一个**固定**的有限相邻管组合，再让 $Y\to\infty$，使其素数源联合能量低于该阈值；每条单管的极限能量仍为 $\kappa_0$。这排除从“每个固定有限集严格正定”直接推出统一管级谱隙或逐管能量可加性的步骤。式 (6) 对 $R=R(Y)$ 不给结论，完整余项还必须处理所有管、补集和真实 $\mu$ 符号。

同样地，对先固定的 $R$，note 846 式 (2) 与 (1b) 给
\[
 0<\lim_{Y\to\infty}\frac{H^4(\log Y)^4}{Y^3}
 \sum_N\left|\sum_{r=0}^RG_r(N)\right|^2
 \le\frac{\kappa_0}{\cos^2(\pi/10)},
\tag{7}
\]
尽管逐管对角能量的同一归一化极限是 $(R+1)\kappa_0$。这是真实素数源的等权 signed 交叉抵消；对随 $Y$ 增长的 $R$ 仍需重新证明统一误差。
