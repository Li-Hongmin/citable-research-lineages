# 平方自由共振 cofactor 的目标量级 gcd 缩域

日期：2026-10-01。依赖 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 的真实高除数系数、[scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的带通核衰减与 [scratch/866](866-negative-mobius-cofactor-resonant-cross-covariance-is-paid.md) 式 (7) 的完整平方自由共振子和。本稿是该**子和**的精确算术缩域；暂留 scratch，未作异源复核。它不估计完整 moving-$N$ signed covariance，也不证明 RH。

## 定理

沿用上述三稿，令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$D=\lfloor M/(16H)\rfloor$、$G=\lfloor M/D\rfloor\asymp H$，$\phi(t)=\psi(t)/t$，且 $J_H(r)=\sum_h w_H(h)e(-hr/M)$。将 [scratch/866](866-negative-mobius-cofactor-resonant-cross-covariance-is-paid.md) 式 (7) 的全部平方自由 $q\ge2$、在整除、低约化比例及物理距离过滤**之前**的有序物理子和记为 $\mathfrak T^{\mathrm{sf,full}}_{M,H}$。定义
\[
 L(g)=4\Lambda(g)+2\mathbf1_{2\mid g}\Lambda(g/2),\qquad L(1)=0.
 \tag{1}
\]
则有
\[
\boxed{\quad
\mathfrak T^{\mathrm{sf,full}}_{M,H}
=-\frac{4\log2}{M^2}
\sum_{\substack{M<m,n<2M\\\mu(m)^2=\mu(n)^2=1\\g=(m,n)\le G}}
\mu(m)\mu(n)\phi(m/M)\phi(n/M)J_H(m-n)L(g)
+O_{s,\psi}\!\left(\frac{\log^2(2M)}H\right).
\quad}\tag{2}
\]
在 (2) 的平方自由支撑上，$L(g)$ 非零恰好仅在
\[
g=p\le G\quad(p\text{ 素数}),
\qquad\text{或}\qquad g=2p\le G\quad(p\text{ 奇素数}),
\tag{3}
\]
其值分别为 $4\log p$ 与 $2\log p$。特别地，在 $g\le G$ 的主和中，公共 gcd 含两个不同奇素数的项**逐物理点精确消失**；$g>G$ 的合计量由 (2) 的误差支付。$G$ 是不依赖物理点位置的完整除数求和界：$q\le G$ 时对所有 $m,n>M$ 均有 $m/q,n/q>D$。

若 $\mathfrak T^{\mathrm{sf}}_{M,H}$ 是 scratch/866 式 (7) 中施加原有过滤之后的子和，则
\[
\begin{aligned}
\mathfrak T^{\mathrm{sf}}_{M,H}
={}&-\frac{4\log2}{M^2}
\sum_{\substack{M<m,n<2M\\\mu(m)^2=\mu(n)^2=1\\g=(m,n)\le G}}
\mu(m)\mu(n)\phi(m/M)\phi(n/M)J_H(m-n)L(g)\\
&+O_{s,\psi}\!\left(
\frac{\log^2(2M)}H
+\frac{H^2\log^3(2M)}M
+\frac{H^4}{M\log^2(2M)}+M^{-2}\right).
\end{aligned}\tag{4}
\]
因此，对每个固定 $\varepsilon>0$，(4) 的误差为 $O_{s,\psi,\varepsilon}(H^4M^{-1+\varepsilon})$。在本共振子族内，达到这一目标幂次的 signed 上界等价于达到相同上界的 (3) 中的 prime-gcd 二点和。这里“等价”只指两个量相差已经支付的误差，绝不指该二点和已有上界。

## 证明

先在完整子和中令 $m=qu,n=qv$。若 $\mu(u)\mu(v)\ne0$ 且 $(u,q)=(v,q)=1$、$\mu(q)^2=1$，则 $m,n$ 均为平方自由数，且
\[
\mu(u)\mu(v)=\mu(m)\mu(n).
\]
反过来，平方自由 $m,n$ 的每个公共除数 $q\ge2$ 自动满足所需互素条件；唯一尚需检查的截断是 $m/q>D$、$n/q>D$。由 scratch/866 式 (7) 的未过滤版本，逐物理点的系数精确为
\[
C_D(m,n)=
\sum_{\substack{q\mid(m,n),\ q\ge2\\m/q>D,\ n/q>D}}
\mu(q)a(q),
\qquad
a(q)=4\log q-2\mathbf1_{2\mid q}\log(q/2).
\tag{5}
\]
故
\[
\mathfrak T^{\mathrm{sf,full}}_{M,H}
=\frac{4\log2}{M^2}
\sum_{\substack{M<m,n<2M\\\mu(m)^2=\mu(n)^2=1}}
\mu(m)\mu(n)\phi(m/M)\phi(n/M)J_H(m-n)C_D(m,n).
\tag{6}
\]

若 $g=(m,n)\le G$，则对每个 $q\mid g$ 有 $m/q,n/q>M/G\ge D$，所以 (5) 无截断。标准恒等式
\[
\sum_{q\mid g}\mu(q)\log q=-\Lambda(g)
\tag{7}
\]
给出 $4\log q$ 部分为 $-4\Lambda(g)$。当 $g=2t$、$t$ 奇时，将偶数除数写成 $q=2r$、$r\mid t$，可得
\[
\sum_{\substack{q\mid g\\2\mid q}}\mu(q)\log(q/2)
=-\sum_{r\mid t}\mu(r)\log r=\Lambda(t).
\tag{8}
\]
当 $g$ 为奇数时 (8) 的和为零。因此
\[
C_D(m,n)=-4\Lambda(g)-2\mathbf1_{2\mid g}\Lambda(g/2)=-L(g)
\qquad(g\le G).
\tag{9}
\]
因为 $g$ 也平方自由，$\Lambda(g)$ 仅在 $g$ 本身为素数时非零，$\Lambda(g/2)$ 仅在 $g=2p$、$p$ 奇素数时非零。这证明 (3) 及 (2) 的主项。

现对 $g>G$ 的全部物理点取绝对值。由 (5) 和 $q\mid g\le2M$，
\[
|C_D(m,n)|\le4\tau(g)\log(2M).
\tag{10}
\]
若 $m\ne n$，写 $m=ga,n=gb$；由于 $\phi$ 的支撑紧含于 $(1,2)$，有 $|m-n|\le(1-\kappa_\psi)M$。对给定 $g$，$m$ 的候选数为 $O(M/g)$，而 $m-n=gk$。scratch/860 式 (9) 的 Gevrey 衰减及单调函数的积分比较给
\[
\sum_{\substack{k\in\mathbb Z\setminus\{0\}\\|gk|\le(1-\kappa_\psi)M}}
|J_H(gk)|\ll_{s,\psi}H\frac{M/H}{g}
+H e^{-cH^{1/s}}\frac Mg
\ll_{s,\psi}\frac Mg.
\tag{11}
\]
末项利用 $H\gg M^{1/5}$。由初等除数均值 $\sum_{n\le x}\tau(n)\ll x\log(2x)$ 和分部求和，
\[
\sum_{g>G}\frac{\tau(g)}{g^2}
\ll\frac{\log(2G)}G.
\tag{12}
\]
所以 (6) 中 $g>G,m\ne n$ 的绝对量不超过
\[
\frac{\log(2M)}{M^2}
\sum_{g>G}\tau(g)\frac Mg\frac Mg
\ll\frac{\log^2(2M)}G
\ll\frac{\log^2(2M)}H.
\tag{13}
\]
对角 $m=n$ 有 $g=m$，$|J_H(0)|\ll H$；由 $\sum_{M<m<2M}\tau(m)\ll M\log(2M)$，其绝对量至多
\[
O\!\left(\frac{H\log^2(2M)}M\right)
=O\!\left(\frac{\log^2(2M)}H\right).
\tag{14}
\]
式 (9)、(13)、(14) 合成 (2)。scratch/866 式 (7) 的过滤误差直接给 (4)。最后 $H^5\ge Y=M/2$，所以 $H^{-1}\le2H^4/M$；固定对数幂可由 $M^\varepsilon$ 吸收，证明末句。$\square$

## 未付的最简单算术元

scratch/866 式 (9) 的混合项可精确写成真正的线性移位 Möbius 相关。以 $C_h=F_{15,h}$ 为共同臂，令 $u=5v+r$ 或 $u=3v+r$，则
\[
\begin{aligned}
\sum_h w_H(h)A_h\overline{C_h}
={}&\sum_{\substack{v\in U_{15},\ r\in\mathbb Z\\
M<15v+3r<2M\\5\nmid r,\ 3\nmid(5v+r)}}
\mu(v)\mu(5v+r)
\phi(15v/M)\phi((15v+3r)/M)J_H(3r),\\
\sum_h w_H(h)B_h\overline{C_h}
={}&\sum_{\substack{v\in U_{15},\ r\in\mathbb Z\\
M<15v+5r<2M\\3\nmid r,\ 5\nmid(3v+r)}}
\mu(v)\mu(3v+r)
\phi(15v/M)\phi((15v+5r)/M)J_H(5r).
\end{aligned}\tag{15}
\]
在给定 $v$ 和 $r$ 的条件下，$u>D$ 自动成立，因为 $3u$ 或 $5u$ 位于 $(M,2M)$；$r=0$ 被相应的模数条件排除。核 $J_H$ 将实质作用限制于 $|r|\ll_{s,B}(M/H)(\log M)^s$，但这仅是距离局部化。[Matomäki--Shao--Tao--Teräväinen 2023](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 的已用短区间输入只给任意固定对数幂节省。另核对 Matomäki--Radziwiłł, *Multiplicative functions in short intervals II*, [arXiv:2007.04290](https://arxiv.org/html/2007.04290)，2026-10-01：其 Corollary 1.1 的幂次节省作用于**超过固定阈值 $\delta$ 的例外集大小**，并未给此处所需的短和幅度固定幂均方界。上述两个来源均不能直接把 (15) 升级为 $H^4/M$ 的固定幂界。式 (2)--(4) 将共振族缩到 prime-gcd 相关，却仍需真实二点符号相消；没有把等价重述当作证明。
