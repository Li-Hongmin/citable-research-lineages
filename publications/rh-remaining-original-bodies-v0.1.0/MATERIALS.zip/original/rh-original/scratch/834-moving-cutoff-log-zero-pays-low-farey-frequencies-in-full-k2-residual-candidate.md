# 移动截止的零边界保留完整 \(k=2\) residual 的低 Farey 频率支付（候选）

日期：2026-09-29。依赖 [note 753](../notes/753-high-divisor-k2-gate-is-the-k2-residual-up-to-negligible-low-layer.md) 的完整层恒等式、[note 762](../notes/762-reciprocal-frequency-spacing-pays-low-divisors-to-four-fifths.md) 式 (4) 的间距均方界、[scratch 832](832-true-mobius-harmonic-collisions-pay-low-reduced-reciprocal-frequencies-candidate.md) 式 (12) 的一致 Möbius 调和界，及 [scratch 833](833-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff-candidate.md) 式 (4)--(5) 的精确 Poisson 核。本文把 833 的固定 \(d\le D\) 截断提升到真正随 \(N\) 变化的全部 \(d<N\)；证明尚未异源复核，留在 scratch。

## 命题与精确剩余门

令 \(Y\to\infty\) 沿正整数，\(Y<N\le2Y\)，\(H=\log(2Y)\)，
\[
Q=\lfloor Y^{4/5}\rfloor,
\qquad A=\lceil Y^{1/3}\rceil,
\qquad
\mathcal R_{N,2}=\sum_{d<N}\mu(d)\Phi(d/N),
\quad
\Phi(t)=\log t\sum_{1/t<m<2/t}\sin(2\pi mt).
\tag{1}
\]
在 833 式 (5) 的精确 Fourier 展开中，取 \(h<d\)，并唯一约分 \(h/d=a/q\in(0,1)\)。令 \(\mathcal U_N\) 为其中
\[
\boxed{\qquad q>Q,\qquad a<A \qquad}
\tag{2}
\]
的全部项，包括每个允许的 \(d=kq<N\)。则
\[
\boxed{\quad
\sum_{Y<N\le2Y}|\mathcal R_{N,2}-\mathcal U_N|^2
\ll Y^2H^5.
\quad}
\tag{3}
\]
因而对每个 \(\varepsilon>0\)，\(\mathcal R_{N,2}\) 的 \(O_\varepsilon(Y^{2+\varepsilon})\) 均方门与 \(\mathcal U_N\) 的同量级门双向等价：两向只对差使用三角不等式，并把 \(H^5\) 吸收到任意小的 \(Y^\varepsilon\) 中。这是目标的精确缩域，并非目标上界的证明。
更细地，\(q\le Q\) 的全部既约频率均方为 \(O(Y^2H^3)\)；\(a\ge A\) 的全部既约频率对任意固定 \(|c_d|\le1\) 均方为 \(O(Y^2H^5)\)。后者允许 \(q\le2Y\)，也允许移动截止 \(d<N\)。式 (3) 将**完整** \(k=2\) residual 的未控算术协方差定位到小分子、高分母的 Farey 扇区；它不估计 \(\mathcal U_N\)，更不证明 RH。

## 移动系数的间距均方引理

令圆周频率 \(\theta_1,\ldots,\theta_J\) 两两至少相距 \(\rho>0\)，\(w_j:[Y,2Y]\to\mathbb C\) 绝对连续。note 762 式 (4) 及 Minkowski 给出
\[
\boxed{\quad
\left\|\sum_{j=1}^Jw_j(N)e(N\theta_j)\right\|_{\ell^2(Y<N\le2Y)}
\ll \bigl(Y+1+\rho^{-1}\log(2J)\bigr)^{1/2}
\left(\|w(Y)\|_{\ell^2_j}
+\int_Y^{2Y}\|w'(t)\|_{\ell^2_j}\,dt\right).
\quad}
\tag{4}
\]
事实上 \(w_j(N)=w_j(Y)+\int_Y^{2Y}\mathbf1_{t<N}w'_j(t)dt\)。对固定 \(t\)，满足 \(t<N\le2Y\) 的 \(N\) 是长度至多 \(Y\) 的连续整数区间，故可在该区间对 \(w'_j(t)\) 用同一个固定系数间距界。先在 \(N\) 上用 Minkowski，后在 \(t\) 上积分，即得 (4)。对复权余弦和，分别写成正、负频率指数和的半和；两组各自具有相同的间距，故仍受同一界控制。

## 新进入的除数不产生边界原子

取 \(b_{j,h}=4^{j+1}\mathbf1_{2\mid h}-1\)。对 \(h<d\) 且既约 \(h/d=a/q\)，写 \(h=ka,d=kq\)。当 \(q\le Q\) 时 \(2q/(aN)<1\)；当 \(a\ge A\) 时 \(2q/(aN)<1\) 对充分大的 \(Y\) 也成立，因为 \(q<d<N\)。因此 833 式 (5) 在这两个频率域内可绝对展开为 \(j\ge0\) 的几何级数。

对真实 Möbius 低分母部分，定义在实数 \(t\in[Y,2Y]\) 上的系数
\[
W_{j,a,q}(t)
=\frac{\mu(q)q^{2j+1}}{a^{2j+2}}
\sum_{\substack{kq<t\\(k,q)=1}}
\frac{\mu(k)b_{j,ka}}k
\log\frac{t}{kq}
\qquad(q\le Q,\ 1\le a<q,\ (a,q)=1).
\tag{5}
\]
每当 \(t\) 越过一个 \(kq\)，新项从零值开始，故 \(W_{j,a,q}\) 连续、分段 \(C^1\)，在闭区间上绝对连续。几乎处处有**精确导数**
\[
\boxed{\quad
W'_{j,a,q}(t)
=\frac{\mu(q)q^{2j+1}}{a^{2j+2}t}
\sum_{\substack{kq<t\\(k,q)=1}}
\frac{\mu(k)b_{j,ka}}k.
\quad}
\tag{6}
\]
特别地，没有移动截止的原子导数。完整 \(q\le Q\) 部分的第 \(j\) 层精确等于
\[
F_j(N)=-\frac1{\pi N^{2j+1}}
\sum_{q\le Q}\sum_{\substack{a<q\\(a,q)=1}}
W_{j,a,q}(N)\cos\frac{2\pi aN}{q}.
\tag{7}
\]

## 真实 Möbius 低分母支付

对 \(t\in[Y,2Y]\) 与 \(q\le Q\) 有 \(t/q\ge Y^{1/5}\)。832 式 (12) 及其奇偶拆分在全部该范围一致给出
\[
\left|\sum_{\substack{kq<t\\(k,q)=1}}
\frac{\mu(k)b_{j,ka}}k\right|
\ll4^{j+1}E,
\qquad
\left|\sum_{\substack{kq<Y\\(k,q)=1}}
\frac{\mu(k)b_{j,ka}\log k}k\right|
\ll4^{j+1}H,
\tag{8}
\]
其中 \(E=e^{-c\omega(Y)}\)、\(\omega(Y)=(\log Y)^{3/5}(\log\log Y)^{-1/5}\)，\(c>0\) 为绝对常数。严格 \(kq<t\) 与 \(k\le t/q\) 只在一个可能的端点不同；该单项的调和权至多 \(q/t\le Y^{-1/5}\)，乘上 \(\log k\ll H\) 后仍可吸收到 \(E\)。当 \(q\) 为奇数且 \(a\) 为奇数时，(8) 还需同样用于 \(2q\le2Y\)。

由 (5)--(8)、\(q/\varphi(q)\ll H\)、\(\log(Y/q)\le H\)，得
\[
|W_{j,a,q}(Y)|
\ll4^{j+1}H\frac{q^{2j+1}}{a^{2j+2}},
\qquad
|W'_{j,a,q}(t)|
\ll4^{j+1}E\frac{q^{2j+1}}{a^{2j+2}t}.
\tag{9}
\]
因为 \(\sum_{q\le Q,a<q}q^{4j+2}a^{-4j-4}\ll Q^{4j+3}\)，
\[
\|W_j(Y)\|_{\ell^2_{q,a}}
+\int_Y^{2Y}\|W'_j(t)\|_{\ell^2_{q,a}}dt
\ll4^{j+1}H Q^{2j+3/2}.
\tag{10}
\]
既约 \(a/q\) 的圆周间距至少 \(Q^{-2}\)；频率数至多 \(Q^2\)。对 (7) 用 (4)，再以 \(N^{-(2j+1)}\le Y^{-(2j+1)}\) 支付外部因子，得到
\[
\|F_j\|_2
\ll
\frac{4^{j+1}H}{Y^{2j+1}}
(Y+Q^2H)^{1/2}Q^{2j+3/2}.
\tag{11}
\]
与 833 式 (15)--(16) 同样，\(4Q^2/Y^2=o(1)\)，故
\[
\left\|\mathcal F^{q\le Q}_{\cdot}\right\|_2^2
\ll Y^2H^3.
\tag{12}
\]

## 大分子无符号支付与完整分解

若只假设 \(|c_d|\le1\)，在 \(a\ge A\) 的域内把 (5) 改为
\[
W^{(c)}_{j,a,q}(t)
=\frac{q^{2j+1}}{a^{2j+2}}
\sum_{kq<t}\frac{c_{kq}b_{j,ka}}k\log\frac{t}{kq},
\qquad q\le2Y,\quad A\le a<q,\quad(a,q)=1.
\tag{13}
\]
这里的 \(k\) 不要求与 \(q\) 互素。与 (6) 相同，新项在进入时为零；平凡调和界给
\[
|W^{(c)}_{j,a,q}(Y)|
\ll4^{j+1}H^2\frac{q^{2j+1}}{a^{2j+2}},
\qquad
|(W^{(c)}_{j,a,q})'(t)|
\ll4^{j+1}H\frac{q^{2j+1}}{a^{2j+2}t}.
\tag{14}
\]
由于 \(\sum_{q\le2Y,a\ge A}q^{4j+2}a^{-4j-4}\ll
(2Y)^{4j+3}A^{-4j-3}\)，并且全体既约频率的间距至少 \((2Y)^{-2}\)，式 (4) 给第 \(j\) 层
\[
\|F_j^{(c),a\ge A}\|_2
\ll H^{5/2}Y^{3/2}A^{-3/2}(16/A^2)^j.
\tag{15}
\]
对充分大的 \(Y\) 有 \(A\ge5\)，故几何求和后
\[
\boxed{\quad
\left\|\mathcal F^{a\ge A}_{\cdot}(c)\right\|_2^2
\ll Y^3H^5/A^3
\ll Y^2H^5.
\quad}
\tag{16}
\]
同一个证明允许只保留 \(q>Q\)，以避免与 (12) 重复。

余下的 \(h\ge d\) 项在 833 式 (17) 的逐项论证下，对每个 \(d<N\) 为 \(O(H/N)\)；因此逐 \(N\) 的总和为 \(O(H)\)，其平方和为 \(O(YH^2)\)。note 753 式 (12) 将 (1) 的全除数和精确识别为 \(\mathcal R_{N,2}\)。把它拆成 \(q\le Q\)、\(q>Q,a\ge A\)、\(\mathcal U_N\) 及 \(h\ge d\) 四项，再用 (12)、(16) 和三角不等式，证明 (3)。\(\square\)

## 扇区内保留真实素数—非素数负协方差

限制到 (2) 的同一扇区时，令 \(P_U(N)=\mathcal U_N(c^{\rm pr})\)，其中 \(c^{\rm pr}_p=-1\) 对素数 \(p\) 成立、其余为零；令 \(C_U(N)=\mathcal U_N(\mu-c^{\rm pr})\)。则 \(\mathcal U_N=P_U(N)+C_U(N)\)。沿用 [note 767](../notes/767-cubic-over-log-squared-covariance-in-the-actual-high-divisor-gate.md) 的严格正数 \(K=\int_0^1\Phi(t)dt\)，可进一步得到候选渐近
\[
\boxed{\quad
\sum_{Y<N\le2Y}P_U(N)C_U(N)
=-\frac{7K^2}{3}\frac{Y^3}{\log^2Y}
+O\!\left(\frac{Y^3}{\log^3Y}\right).
\quad}
\tag{17}
\]

证明如下。note 767 式 (3) 在 \(D=Q\) 给出 \(D<p<N\) 的素数部分
\(-KN/\log N+O(N/\log^2Y)\)，且 \(\sum_{Q<d<N}\mu(d)\Phi(d/N)=o(N/\log^B Y)\) 对任意固定 \(B>0\) 一致成立。由 note 753 式 (5)，全部 \(d\le Q\) 的绝对贡献为 \(O(Q^2H/Y)=O(Y^{3/5}H)\)，所以对完整素数部分 \(P_{\rm all}(N)=-\sum_{p<N}\Phi(p/N)\) 和完整 residual 有
\[
P_{\rm all}(N)=-K\frac N{\log N}
+O\!\left(\frac N{\log^2Y}\right),
\qquad
\mathcal R_{N,2}=O_B\!\left(\frac N{\log^B Y}\right)
\quad(\forall B>0).
\tag{18}
\]
对素数系数 \(c^{\rm pr}\)，若 \(h<d=p\)，其既约分母必为 \(q=p\)。因此被 (2) 删去的 \(q\le Q\) 素数项只涉及 \(p\le Q\)，由 note 762 式 (2) 的有界系数估计支付；被删去的 \(a\ge A\) 项由本文式 (16) 支付，\(h\ge d\) 尾项仍为 \(O(YH^2)\) 平方和。故
\[
\|P_{\rm all}-P_U\|_2^2\ll Y^2H^5,
\qquad
\|\mathcal R_{\cdot,2}-\mathcal U\|_2^2\ll Y^2H^5.
\tag{19}
\]
式 (18)--(19) 给 \(\|P_U\|_2\asymp Y^{3/2}/\log Y\) 和
\(\|\mathcal U\|_2\ll_B Y^{3/2}/\log^B Y\)（任意固定 \(B\)）。于是 Cauchy--Schwarz 给
\(\sum_NP_U(N)\mathcal U_N=O(Y^3/\log^3Y)\)。另一方面，由 (18)--(19) 及
\(\sum_{Y<N\le2Y}N^2/\log^2N
=7Y^3/(3\log^2Y)+O(Y^3/\log^3Y)\)，得
\[
\sum_NP_U(N)^2
=\frac{7K^2}{3}\frac{Y^3}{\log^2Y}
+O\!\left(\frac{Y^3}{\log^3Y}\right).
\]
以 \(C_U=\mathcal U-P_U\) 代入，即得 (17)。\(\square\)

## 承重边界

式 (3) 是对真实 moving-\(N\) residual 的无条件缩域，优于只处理固定 \(d\le D\) 的 833。要得到 RH 所需的 \(Y^{2+\varepsilon}\) 门，仍须控制 \(\mathcal U_N\) 的均方；该扇区包含 \(k=1\)、小 \(a\) 与 \(q\asymp N\) 的真正 Möbius signed covariance。note 087 的 RH 等价条件同时要求 \(k=1,2\) 两个 residual；当前命题没有证明任一未控均方上界。重大结论的独立复核尚未完成，故本文件保持候选。
