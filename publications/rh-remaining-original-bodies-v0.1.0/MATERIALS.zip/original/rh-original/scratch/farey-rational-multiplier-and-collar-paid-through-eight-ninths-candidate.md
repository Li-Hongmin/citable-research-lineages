# 分子一固定幂带的有理乘子与物理裁剪支付至八分之九（候选）

日期：2026-09-30。依赖 [note 800](../notes/800-true-mobius-harmonic-collisions-pay-low-reduced-reciprocal-frequencies.md) 式 (12) 的一致互素 Möbius 调和界、[note 802](../notes/802-moving-cutoff-log-zero-pays-low-farey-frequencies-in-full-k2-residual.md) 式 (4) 的移动系数间距引理，以及 [note 833](../notes/833-prime-composite-covariance-within-a-moving-farey-denominator-block.md) 式 (1) 的真实同频系数。裁剪估计与[四分之五延伸候选](farey-prime-composite-block-covariance-down-to-four-fifths-candidate.md)式 (6) 相同；本文重新给出。结论尚待异源复核。

固定 \(4/5<\alpha\le8/9\)，令 \(D=\lfloor Y^\alpha\rfloor\)、\(L=\lfloor Y^{5/6}\rfloor\)、\(Y<N\le2Y\)。定义真实物理裁剪的分子 \(1\) 带
\[
T_{D,N}=\sum_{D/2<q\le D}F_{q,N},
\qquad F_{q,N}=-\frac{C_q(N)}{\pi N}\cos\frac{2\pi N}{q},
\tag{1}
\]
其中 \(C_q\) 取 note 833 式 (1)。令
\[
C_q^{(0)}(t)
=q\sum_{kq<t}\frac{\mu(kq)}k\log\frac{t}{kq}
\bigl(4\mathbf1_{2\mid k}-1\bigr),
\qquad
T_{D,N}^{(0)}=-\sum_{D/2<q\le D}
\frac{C_q^{(0)}(N)}{\pi N}\cos\frac{2\pi N}{q}.
\tag{2}
\]
这个模型只把两个精确 Poisson 有理乘子取其零阶值，并撤去物理 collar；它**保留**截止 \(kq<N\) 的全部真实 Möbius 调和和。

**候选命题。** 对每个 \(\varepsilon>0\)，
\[
\boxed{\quad
\sum_{Y<N\le2Y}|T_{D,N}-T_{D,N}^{(0)}|^2
\ll_{\alpha,\varepsilon}Y^{2+\varepsilon}.
\quad}\tag{3}
\]
故在上述固定幂走廊，单一分母带的真实 \(Y^{2+\varepsilon}\) 均方门与式 (2) 的零阶乘子门双向等价。该等价性本身不给任何一侧的目标上界。

## 有理乘子偏差

写
\[
M_q(t)=\sum_{\substack{kq<t\\(k,q)=1}}
\frac{\mu(k)}k\log\frac{t}{kq},\qquad
M_{2q}(t)=\sum_{\substack{kq<t\\(k,2q)=1}}
\frac{\mu(k)}k\log\frac{t}{kq},
\tag{4}
\]
其中第二项的截止仍为 \(kq<t\)，并且仅在 \(q\) 为奇数时使用。note 800 式 (12) 对 \(t/q\asymp Y^{1-\alpha}\) 一致给
\[
|M_q(t)|+|M_{2q}(t)|\ll_\alpha\log\log(3Y),
\qquad
|M'_q(t)|+|M'_{2q}(t)|
\ll_\alpha e^{-c_\alpha\omega(Y)}/Y
\quad\text{a.e.},
\tag{5}
\]
\(\omega(Y)=(\log Y)^{3/5}(\log\log Y)^{-1/5}\)。新进入的 \(k\) 在 \(kq=t\) 处以零对数权开始，故两个函数绝对连续。

置 \(v=q/t\)、\(P_4(v)=4/(1-4v^2)\)、\(P_1(v)=1/(1-v^2)\)。当 \(q\) 奇时，note 833 的完整未裁剪系数与 (2) 分别是
\[
C_q^{\rm full}(t)=\mu(q)q
\{P_4(v)(M_q-M_{2q})-P_1(v)M_q\},
\quad
C_q^{(0)}(t)=\mu(q)q\{4(M_q-M_{2q})-M_q\};
\tag{6}
\]
当 \(q\) 偶时，二者分别为 \(-\mu(q)qP_1(v)M_q\) 与
\(-\mu(q)qM_q\)。非平方自由 \(q\) 的两边都为零。因为
\(v\ll D/Y=o(1)\)，有 \(P_4-4,P_1-1=O(v^2)\) 及
\(dP_4/dt,dP_1/dt=O(v^2/Y)\)。由 (5) 得
\[
R_q^{\rm rat}(t):=C_q^{\rm full}(t)-C_q^{(0)}(t),
\quad
|R_q^{\rm rat}(t)|\ll_\alpha \frac{D^3}{Y^2}\log\log(3Y),
\quad
|(R_q^{\rm rat})'(t)|\ll_\alpha
\frac{D^3}{Y^3}\log\log(3Y).
\tag{7}
\]
不同整数 \(q\le D\) 的 \(1/q\pmod1\) 相隔至少 \(D^{-2}\)。把
\(R_q^{\rm rat}(t)/(\pi t)\) 当作 note 802 式 (4) 的移动权，余弦分别拆成正、负指数，得到
\[
\sum_{Y<N\le2Y}\left|
\sum_{D/2<q\le D}\frac{R_q^{\rm rat}(N)}{\pi N}
\cos\frac{2\pi N}{q}\right|^2
\ll_\alpha (Y+D^2\log D)\cdot
D\left(\frac{D^3}{Y^3}\log\log Y\right)^2
\ll_\alpha \frac{D^9}{Y^6}\log Y(\log\log Y)^2.
\tag{8}
\]
因 \(D^2\gg Y\) 得到末行。\(D=Y^\alpha\) 且 \(\alpha\le8/9\) 使末行 \(\ll_\varepsilon Y^{2+\varepsilon}\)。

## 物理 collar

被删除的每个 \(k\) 满足 \(N-L<kq<N\)，至多 \(L/q+1\) 个，且 \(1/k\ll q/Y\)、\(\log(N/kq)\ll L/Y\)。因此
\[
|C_q(N)-C_q^{\rm full}(N)|
\ll\frac{qL^2+q^2L}{Y^2}
\ll\frac{DL(L+D)}{Y^2}.
\tag{9}
\]
对每个 \(N\) 在整带逐项取绝对值，再对 \(N\) 求平方，得到
\[
\sum_{Y<N\le2Y}\left|
\sum_{D/2<q\le D}
\frac{C_q(N)-C_q^{\rm full}(N)}{\pi N}
\cos\frac{2\pi N}{q}\right|^2
\ll\frac{D^4L^2(L+D)^2}{Y^5}.
\tag{10}
\]
若 \(\alpha\le5/6\)，右边为 \(Y^{4\alpha-5/3+o(1)}\)，至多 \(Y^{5/3+o(1)}\)；若 \(5/6<\alpha\le8/9\)，它为 \(Y^{6\alpha-10/3+o(1)}\)，至多 \(Y^{2+o(1)}\)。将 (8)、(10) 用三角不等式合并即得 (3)。\(\square\)

**剩余算术门。** 虽然 \(C_q^{(0)}(t)=-qf_\kappa(q)+O_\alpha(qe^{-c_\alpha\omega(Y)})\)，这个调和余项的整带平方界仍可能是 \(Y^{5\alpha-2}e^{-c\omega(Y)}\)，对每个固定 \(\alpha>4/5\) 都超出 \(Y^{2+\varepsilon}\) 的目标。式 (3) 因而必须保留 (4) 的全部移动调和系数；把它们再替换成极限 \(q/\varphi(q)\) 是未经支付的一步。此结论只针对分子 \(1\) 的单一固定幂带，不估计跨分子、跨带合并，也不证明 RH。

## 条件性的纯 Möbius 入口

[固定分子转移候选](leading-farey-mobius-multiplier-transfer-candidate.md) 式 (11)--(20) 保留原始 \(k\)-和并证明如下条件推论：若对每个 \(\varepsilon>0\)、全部 \(1\le E\le X^{8/9}\) 一致有
\[
\sum_{X<n\le2X}
\left|\frac1n\sum_{E/2<q\le E}q\mu(q)
\cos\frac{2\pi n}{q}\right|^2
\ll_\varepsilon X^{2+\varepsilon},
\tag{11}
\]
则对每个固定 \(4/5<\alpha\le8/9\)，真实物理裁剪的 \(T_{D,N}\) 满足同量级门。确实，转移候选式 (12) 先给未裁剪完整同频系数的目标界；本文式 (9)--(10) 支付物理 collar。这里并未证明 (11)，而且从一个固定 \(E=X^\alpha\) 带无法套用该转移：卷积与原始 \(k\)-和会产生更小的 \(E/d\) 及移动截止。对固定 \(\alpha>8/9\)，式 (10) 的绝对 collar 预算也不再达到目标，须另作 signed 控制。
