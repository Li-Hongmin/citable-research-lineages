# 首个既约分子单块内的真实素数—非素数负协方差（候选）

日期：2026-09-29。依赖 [scratch 833](833-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff-candidate.md) 式 (5) 的精确 Fourier 表示，以及 [scratch 834](834-moving-cutoff-log-zero-pays-low-farey-frequencies-in-full-k2-residual-candidate.md) 式 (2) 的剩余 Farey 扇区。本文研究其中最简单的 \(a=1,\ N/2<q<N\) 子块；与 [note 765](../notes/765-unconditional-prime-composite-covariance-across-true-cofactor-scales.md) 的物理 cofactor cell 不同，这里固定的是 **Poisson 展开的一个既约 Fourier 分子**。仍待异源复核，留在 scratch。

## 命题

对 \(1/2<t<1\) 定义连续端点延拓的实函数
\[
f(t)=\frac{t\log(1/t)}{\pi(1-t^2)}\cos\frac{2\pi}{t},
\qquad f(1/2)=\frac{2\log2}{3\pi},\quad f(1)=\frac1{2\pi},
\qquad J=\int_{1/2}^1f(t)dt.
\tag{1}
\]
则 \(J>0\)。令
\[
S_1(N)=\sum_{N/2<d<N}\mu(d)f(d/N),
\quad P_1(N)=-\sum_{N/2<p<N}f(p/N),
\quad C_1(N)=S_1(N)-P_1(N).
\tag{2}
\]
这些项恰好是 833 式 (5) 中 \(h<d\)、既约 \(h/d=1/q\)、\(q>N/2\) 的全部项：此时 \(h=k,d=kq<N\) 迫使 \(k=1\)。对充分大的 \(Y\) 与 \(Y<N\le2Y\)，该子块包含在 834 式 (2) 的未控扇区内，因为 \(q>N/2>Y^{4/5}\)、\(a=1<Y^{1/3}\)。

对每个固定 \(B>0\) 一致有
\[
\boxed{\quad
P_1(N)=-J\frac N{\log N}
+O\!\left(\frac N{\log^2N}\right),
\qquad
S_1(N)=O_B\!\left(\frac N{\log^B N}\right).
\quad}
\tag{3}
\]
因此 \(C_1(N)=J N/\log N+O(N/\log^2N)\)，并且
\[
\boxed{\quad
\sum_{Y<N\le2Y}P_1(N)^2
=\frac{7J^2}{3}\frac{Y^3}{\log^2Y}
+O\!\left(\frac{Y^3}{\log^3Y}\right),
\qquad
\sum_{Y<N\le2Y}P_1(N)C_1(N)
=-\frac{7J^2}{3}\frac{Y^3}{\log^2Y}
+O\!\left(\frac{Y^3}{\log^3Y}\right).
\quad}
\tag{4}
\]
若在 (4) 的素数—非素数双和中只保留 \(|p-e|>R\)，对任意 \(R=o(Y/\log Y)\)，主项仍为 \(-\frac{7J^2}{3}Y^3/\log^2Y\) 乘以 \(1+o(1)\)。

## 单频核的严格正平均

置 \(x=1/t\)。则
\[
J=\frac1\pi\int_1^2w(x)\cos(2\pi x)dx,
\qquad
w(x)=\frac{\log x}{x(x^2-1)}
=\frac1{x(x+1)}\int_0^1\frac{du}{1+u(x-1)}.
\tag{5}
\]
在 \([1,2]\) 上，右侧每个因子均正、递减且凸；它们的乘积严格凸，积分保持严格凸性，故 \(w''(x)>0\) 对 \(1<x<2\) 成立，且 \(w\) 在 \(x=1\) 连续延拓为 \(1/2\)。事实上对三个正因子逐次求二阶导，纯二阶项非负，两两一阶导乘积也非负，而 \(1/x\) 的二阶导严格正；可在积分号下逐项判定。

把 \(x=1+u\)，并将后半周期反射至前半周期，可写
\[
\int_1^2w(x)\cos(2\pi x)dx
=\int_0^{1/2}g(u)\cos(2\pi u)du,
\qquad g(u)=w(1+u)+w(2-u).
\tag{6}
\]
严格凸性使 \(w'\) 严格递增，因而对 \(0<u<1/2\)，
\(g'(u)=w'(1+u)-w'(2-u)<0\)。再将 \(u\in(1/4,1/2)\) 反射至 \((0,1/4)\)，得到
\[
\int_0^{1/2}g(u)\cos(2\pi u)du
=\int_0^{1/4}
\bigl[g(u)-g(1/2-u)\bigr]\cos(2\pi u)du>0.
\tag{7}
\]
这是 \(J>0\) 的严格解析证明，不依赖数值积分。

## 每个完整倒数周期都有同号素数主项

式 (5) 的同一个权 \(w(x)\) 在全部 \(x>1\) 上严格凸。因此对每个固定整数 \(m\ge1\)，定义
\[
J_m:=\int_{1/(m+1)}^{1/m}f(t)dt
=\frac1\pi\int_m^{m+1}w(x)\cos(2\pi x)dx.
\tag{7a}
\]
把式 (6)--(7) 的 \([1,2]\) 平移为 \([m,m+1]\)，同样得到
\[
\boxed{J_m>0\qquad(m=1,2,\ldots).}
\tag{7b}
\]
这是一条统一的解析符号定理：首个 Poisson 谐波的任一完整倒数周期都不能靠该周期内的余弦振荡消去素数平均。其大小随 \(m\) 衰减。对 \(m\to\infty\)，
\[
w''(m)=\frac{12\log m-7}{m^5}
+O\!\left(\frac{\log m}{m^7}\right),
\qquad
\sup_{m\le x\le m+1}|w'''(x)|
\ll\frac{\log m}{m^6}.
\]
在 \(x=m+u\) 处 Taylor 展开，利用
\(\int_0^1\cos(2\pi u)du
=\int_0^1u\cos(2\pi u)du=0\) 与
\(\int_0^1u^2\cos(2\pi u)du=1/(2\pi^2)\)，得到
\[
\boxed{\quad
J_m=\frac{12\log m-7}{4\pi^3m^5}
+O\!\left(\frac{\log m}{m^6}\right)
\quad(m\to\infty).
\quad}
\tag{7c}
\]
式 (7c) 的余项来自 \(w'''(x)\ll(\log m)m^{-6}\)；二次 Taylor 项是 \(w''(m)/(4\pi^3)\)。

更具体地，对每个**固定** \(m\) 取
\[
S_m(N)=\sum_{N/(m+1)<d<N/m}\mu(d)f(d/N),
\quad P_m(N)=-\sum_{N/(m+1)<p<N/m}f(p/N),
\quad C_m(N)=S_m(N)-P_m(N).
\]
下节同一个有界变差 Abel 论证，在 \(d\asymp_mN\) 上给
\[
P_m(N)=-J_m\frac N{\log N}+O_m(N/\log^2N),
\qquad S_m(N)=O_{m,B}(N/\log^B N)
\quad(\forall B>0).
\]
故
\[
\sum_{Y<N\le2Y}P_m(N)C_m(N)
=-\frac{7J_m^2}{3}\frac{Y^3}{\log^2Y}
+O_m\!\left(\frac{Y^3}{\log^3Y}\right).
\tag{7d}
\]
这些是精确 Poisson 展开中 \(h=1,d=q\) 的各个固定倒数周期；\(m\ge2\) 时，同一既约频率 \(1/q\) 还可能收到 \(h=k,d=kq\) 的其他谐波，故 (7d) 只断言所选 \(h=1\) 子和，不替代完整频率系数。

## 真实 Möbius 与素数估计

先核对 (2) 的核。833 式 (5) 的 \(h=1\) 为奇数，其括号是
\(-[1-d^2/N^2]^{-1}\)；与外部负号相乘，恰给 \(\mu(d)f(d/N)\)。当既约 \(a=1\)、\(q>N/2\) 时 \(d=kq<N\) 只允许 \(k=1\)，所以 (2) 没有遗漏同频率的其他谐波。

函数 \(f\) 在 \([1/2,1]\) 上连续、分段光滑且总变差为绝对常数；在 \(t=1\) 的表面奇性由 \(\log(1/t)/(1-t^2)\to1/2\) 消去。Vinogradov--Korobov 零自由区给
\(M(x)=\sum_{n\le x}\mu(n)\ll x e^{-c\omega(x)}\)。在 \([N/2,N]\) 对 \(f(d/N)\) 作 Stieltjes 分部求和，得到
\[
S_1(N)\ll N e^{-c'\omega(N)}
\ll_B N/\log^B N.
\tag{8}
\]
同一零自由区的素数定理给 \(\pi(x)=\operatorname{li}(x)+O(xe^{-c\omega(x)})\)。在同一区间再次分部求和，并用 \(\log(Nt)=\log N+O(1)\) 对 \(1/2\le t\le1\) 一致成立，便得
\[
\sum_{N/2<p<N}f(p/N)
=N\int_{1/2}^1\frac{f(t)}{\log(Nt)}dt
+O(Ne^{-c'\omega(N)})
=J\frac N{\log N}+O(N/\log^2N),
\tag{9}
\]
证明 (3)。逐 \(N\) 相乘后用
\(\sum_{Y<N\le2Y}N^2/\log^2N
=\frac73Y^3/\log^2Y+O(Y^3/\log^3Y)\)，即得 (4)。

最后，\(f\) 在 \([1/2,1]\) 有界。对每个 \(N\)，\(p\in(N/2,N)\) 至多 \(O(N/\log N)\) 个；每个 \(p\) 的 \(|p-e|\le R\) 候选 \(e\) 至多 \(2R+1\) 个，且 \(|\mu(e)|\le1\)。因此近差配对在所有 \(Y<N\le2Y\) 上的绝对量为 \(O(RY^2/\log Y+Y^2/\log Y)\)，在 \(R=o(Y/\log Y)\) 下为 \(o(Y^3/\log^2Y)\)。删去这些配对不改变 (4) 的主项。\(\square\)

## 完整首谐波仍有严格正的素数平均

将式 (1) 的同一个 \(f(t)\) 定义于全部 \(0<t<1\)。在 \(t\downarrow0\) 时，\(|f(t)|\ll t\log(1/t)\)，故其积分绝对收敛。由 (7a)--(7c)，
\[
\boxed{\quad K_1:=\int_0^1f(t)dt
=\sum_{m\ge1}J_m>0.\quad}
\tag{10}
\]
定义整个 \(h=1\) Poisson 谐波及其素数部分
\[
S^{(h=1)}(N)=\sum_{d<N}\mu(d)f(d/N),
\qquad
P^{(h=1)}(N)=-\sum_{p<N}f(p/N),
\qquad
C^{(h=1)}=S^{(h=1)}-P^{(h=1)}.
\tag{11}
\]
式 (5) 的 \(h=1\) 项与 (11) 精确相同。对每个固定 \(B>0\)，一致有
\[
\boxed{\quad
S^{(h=1)}(N)=O_B(N/\log^B N),
\qquad
P^{(h=1)}(N)=-K_1\frac N{\log N}
+O(N/\log^2N).
\quad}
\tag{12}
\]
为证明 (12)，取 \(D=\lfloor N^{3/4}\rfloor\)。小除数由 \(|f(t)|\ll t\log(1/t)\) 给
\[
\sum_{d\le D}|f(d/N)|
\ll D^2\log N/N\ll N^{1/2}\log N.
\tag{13}
\]
对 \(t\le1/2\)，微分 (1) 给 \(|f'(t)|\ll\log(1/t)/t\)，而 \([1/2,1]\) 上导数有界。因此
\[
\operatorname{Var}_{[D/N,1]}f\ll\log^2N.
\tag{14}
\]
Vinogradov--Korobov 的 \(M(x)\ll xe^{-c\omega(x)}\) 在 \(D\le x\le N\) 上，结合 (13)--(14) 与 Abel 分部求和，给
\(S^{(h=1)}(N)\ll N^{1/2}\log N+N\log^2N e^{-c\omega(D)}\)，即 (12) 的第一式。

同样对素数计数函数分部求和，零自由区误差为 \(O(N\log^2N e^{-c\omega(D)})\)，主积分为
\[
N\int_{D/N}^1\frac{f(t)}{\log(Nt)}dt.
\]
因为 \(\log(Nt)\ge\frac34\log N+O(1)\)，且
\(\int_0^1|f(t)|\log(1/t)dt<\infty\)，把分母换成 \(\log N\) 的误差为 \(O(N/\log^2N)\)；把积分下限移至零的误差由 (13) 为 \(O(N^{1/2}\log N)\)。这证明 (12) 的第二式。于是
\[
\boxed{\quad
\sum_{Y<N\le2Y}P^{(h=1)}(N)C^{(h=1)}(N)
=-\frac{7K_1^2}{3}\frac{Y^3}{\log^2Y}
+O\!\left(\frac{Y^3}{\log^3Y}\right).
\quad}
\tag{15}
\]
令 \(Q=\lfloor Y^{4/5}\rfloor\)，并在 (11) 的三个和中只保留 \(Q<d<N\)，记为 \(S_{>Q}^{(h=1)},P_{>Q}^{(h=1)},C_{>Q}^{(h=1)}\)。因 \(Q/N\le Y^{-1/5}\)，
\[
\sum_{d\le Q}|f(d/N)|
\ll \frac{Q^2\log N}{N}
\ll Y^{3/5}\log Y.
\tag{16}
\]
式 (12) 因此直接给出，对每个固定 \(B>0\) 一致有
\[
S_{>Q}^{(h=1)}(N)=O_B(N/\log^B N),\qquad
P_{>Q}^{(h=1)}(N)=-K_1N/\log N+O(N/\log^2N).
\tag{17}
\]
逐 \(N\) 相乘得到位于 834 式 (2) **真实未控扇区内部**的候选渐近
\[
\boxed{\quad
\sum_{Y<N\le2Y}P_{>Q}^{(h=1)}(N)C_{>Q}^{(h=1)}(N)
=-\frac{7K_1^2}{3}\frac{Y^3}{\log^2Y}
+O\!\left(\frac{Y^3}{\log^3Y}\right).
\quad}
\tag{18}
\]
这里 \(h=1\) 时 \(a=1,q=d\)；(18) 仍只是该扇区的一条原始谐波，尚未包含同一既约频率的 \(h=k,d=kq\) 重合项。

## 边界

式 (4)、(7d)、(15) 与 (18) 给出候选的单一既约分子各周期、整个原始 \(h=1\) 谐波及其真实未控扇区截断中的 \(Y^3/\log^2Y\) 级负协方差。这是 Fourier 子块内部的素数—非素数补偿，不能界定它与其他 Farey 频率的交叉项，也不给 \(\sum_N|\mathcal U_N|^2\) 的 \(Y^{2+\varepsilon}\) 上界。完整 moving-\(N\) 算术门、全尺度 Weil 正性及 RH 仍未解决。
