# 固定正测度整数对数格的完整 Weil 谱底（待独立复核）

沿用 note 854 的 $H=\log p$、$N=\lfloor p^2/16\rfloor$、$y_n=H-\log4-\log n$，但令 $0<\ell\le c_0/p^2$，其中 $c_0>0$ 是足够小的绝对常数。令 $I_n=(y_n-\ell/2,y_n+\ell/2)$、$U=\bigcup_{n\le N}I_n$。候选定理是存在绝对 $c_0,C$，使所有充分大奇素数 $p$ 和全部上述 $\ell$ 满足

$$\bigl|\lambda(U)-[\log(1/\ell)-\log N]\bigr|\le C.$$

特别地，固定 $0<c\le c_0$、$\ell=c/p^2$ 时 $|U|\to c/16$，且
$\lambda(U)=\log(16/c)+O(1)$。进一步缩小 $c_0$ 即使整个固定正测度压缩有统一正隙。上界沿用 note 854 的共同轮廓 $n^{-1/2}$；其普通核交叉与 polar 在该试函数上都是 $O(\ell N)=O(1)$，对更小 $\ell$ 仍一致。

## 匹配上界的统一试函数

固定非负单位 $\varphi\in C_c^\infty((-1/2,1/2))$，置
$b_\ell(t)=\ell^{-1/2}\varphi(t/\ell)$、$L_N=\sum_{n\le N}1/n$，并在 $I_n$ 上取
$f(y_n+t)=n^{-1/2}b_\ell(t)/\sqrt{L_N}$。则 $\|f\|_2=1$，
Fourier 单槽主部之和恰为 $\log(1/\ell)+c_\varphi$，同槽光滑余核为 $O(\ell)$。
精确整除关系使 prime-shift Rayleigh 商为 $\log N+O(1)$。

普通核的跨槽绝对值至多
$$
\frac{C\ell}{L_N}\sum_{n\ne r}\frac1{\sqrt{nr}|\log(n/r)|}
\ll\frac{\ell N\log(2N)}{L_N}=O(\ell N).
$$
其中 $n<r\le2n$ 时被求和项为 $O((r-n)^{-1})$，逐 $n$ 求和 $O(\log(2n))$；$r>2n$ 时逐 $n$ 求和 $O(\sqrt{N/n})$。两个 polar 矩分别为
$$
|p_+(f)|\ll\sqrt{p\ell L_N},\qquad
|p_-(f)|\ll N\sqrt{\ell/p}/\sqrt{L_N},
$$
故 $|q_{\rm pol}(f)|\ll\ell N$。因此
$$Q_W^H[f]=\log(1/\ell)-\log N+O(1+\ell N)$$
对全部 $\ell\le c_0/p^2$ 一致，证明候选上界。

## 下界：将三种有害交叉合成一张非负矩阵

对全部有限能量 $f$ 分片并写 $a_n=\|f1_{I_n}\|_2$。单槽约化 Fourier 与有界光滑余核给
$\sum_n q_{\rm diag}[f_n]\ge[\log(1/\ell)-C_0]\|f\|_2^2$。
note 854 的整数唯一性在 $2N\ell<1$ 下保持，prime-shift 交叉绝对值至多 $\langle a,C_Na\rangle$，其中 $(C_N)_{n,kn}=\Lambda(k)/\sqrt k$。

不同槽普通约化核 $-k(|y-z|)$，$k(t)=e^{-t/2}/(1-e^{-2t})\le C/t$。取 $c_0$ 使 $\ell$ 小于任意中心距的固定比例，则每个块的范数至多
$$B_{nr}=C_B\frac{\ell}{|\log(n/r)|}\quad(n\ne r),\qquad B_{nn}=0.$$
完整 polar 核是 $2\cosh((y-z)/2)$；其块范数至多
$$P_{nr}=\ell e^{\ell/2}(\sqrt{r/n}+\sqrt{n/r})\quad(1\le n,r\le N).$$
因此对 $M=C_N+B+P$（实对称非负矩阵），
$$Q_W^H[f]\ge[\log(1/\ell)-C_0]\|f\|_2^2-\langle a,Ma\rangle.$$

## 指数倾斜的加权 Schur 权

置 $\alpha=\ell N$，$w_n=n^{-1/2}e^{a n/N}$，其中 $a=A\alpha$，$A$ 为固定足够大的常数；选 $c_0$ 使 $0<a\le1$。这里 $a$ 是倾斜参数，勿与槽范数向量混淆。由 Chebyshev 界 $\psi(x)=\sum_{k\le x}\Lambda(k)\le C_\psi x$ 和 note 854 的 $M_1(x)=\log x+O(1)$，

$$
\begin{aligned}
\frac{(C_Nw)_n}{w_n}
&=\sum_{k\le N/n}\frac{\Lambda(k)}k e^{a(k-1)n/N}
 +\sum_{k\mid n}\Lambda(k)e^{-a(1-1/k)n/N}\\
&\le\log N+C_1+C_\psi a e^a-\frac{a n\log n}{4N}.
\end{aligned}\tag{1}
$$
第一和相对 $M_1(N/n)$ 的增加不超过
$a e^a(n/N)\sum_{k\le N/n}\Lambda(k)\le C_\psi a e^a$。
第二和的每个正项的减少至少为
$$
1-e^{-a(1-1/k)n/N}
\ge\tfrac12a(1-1/k)n/N\ge a n/(4N),
$$
因为 $0\le a(1-1/k)n/N\le1$ 时 $1-e^{-t}\ge t/2$，而 $k\ge2$。乘以 $\Lambda(k)$ 并按 $k\mid n$ 求和，得到减少至少 $a n\log n/(4N)$。

普通核的加权行和满足
$$\frac{(Bw)_n}{w_n}
\le C_2e^a\ell[n\log(2n)+N].\tag{2}$$
证明按 $n/2\le r\le2n$、$r>2n$、$r<n/2$ 分段。近段用
$|\log(n/r)|\gg|n-r|/n$ 和 $\sqrt{n/r}\ll1$，得
$O(e^a\ell n\log(2n))$；两段远区的和分别为
$O(e^a\ell\sqrt{nN})$、$O(\ell n)$，均由 $O(e^a\ell N)$ 支付。

polar 的加权行和精确化为
$$\frac{(Pw)_n}{w_n}
\le\ell e^{a+\ell/2}\sum_{r\le N}(1+n/r)
\le C_3e^a\ell[N+n\log(2n)].\tag{3}$$
末步使用 $n\log(N/n)\le N/e$ 和 $\sum_{r\le N}1/r\le\log N+1$。

将 (2)--(3) 合并，有绝对 $D$ 使
$$\frac{((B+P)w)_n}{w_n}
\le De^a\alpha\left[\frac nN\log n+1\right].\tag{4}$$
取 $A=8De$，并令 $c_0$ 足够小以保证 $a=A\alpha\le1$。于是
$a/4=2De\alpha\ge De^a\alpha$，(1) 的负项支付 (4) 中随 $n$ 增长的项，得到
$$\sup_n\frac{(Mw)_n}{w_n}\le\log N+C_1+O(\alpha).$$
加权 Schur 检验给 $\|M\|\le\log N+C_4$，其中 $C_4$ 绝对且对 $p,\ell$ 一致。故
$$Q_W^H[f]\ge[\log(1/\ell)-\log N-C]\|f\|_2^2$$
对声明的整个闭形式域成立。连同匹配上界证明候选定理。

须复核：polar 作为有害块矩阵的系数、(1) 的负入边系数、(2)--(3) 在 $n=1$ 和 $n=N$ 两端的一致性、加权 Schur 与全部有限能量轮廓的接口；不要把此压缩定理外推到 $U^c$ 的 true-Schur 或 RH。
