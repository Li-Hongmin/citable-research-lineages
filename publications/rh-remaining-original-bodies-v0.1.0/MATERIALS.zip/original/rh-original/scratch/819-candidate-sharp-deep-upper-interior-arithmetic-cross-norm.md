# 候选：深区—上分子内区交叉的尖锐常数及子幂深区联合谱隙

日期：2026-09-30。尖锐交叉 (1) 已完成独立只读复核；子幂深区的三块结论 (5) 待复核。沿 [note 803](../notes/803-farey-exterior-block-has-logarithmic-gap-and-natural-schur-direction-stays-positive.md)、[note 807](../notes/807-natural-farey-constant-mode-has-two-thirds-logarithmic-energy.md)、[note 813](../notes/813-deep-interior-and-polar-exterior-joint-farey-gap.md) 及 [note 818](../notes/818-upper-numerator-farey-interior-linear-joint-polar-gap.md) 的记号，令奇素数 \(p\to\infty\)，\(P=p-1\)、\(H=\log p\)、\(Q=\lfloor P/H\rfloor\)。固定任意 \(\beta>1\)，令 \(R=\lfloor P/H^\beta\rfloor\)，并将全内区常值奇槽分为
\[
D_R=I_R=\operatorname{span}\{\psi_{a/b}:1\le b<a\le R,\ (a,b)=1\},\qquad
T_{R,Q}=\operatorname{span}\{\psi_{a/b}:R<a\le Q,\ 1\le b<a,\ (a,b)=1\}.
\]
令 \(C^-=C_{\parallel}-C_{\times}\) 是 note 807 的真实带符号素数幂矩阵，\(K_{U,L}\) 是 note 803 的一维非负矩形，\(L=\{1,\ldots,R\}\)、\(U=\{R+1,\ldots,Q\}\)。则
\[
\boxed{\quad
\|C^-_{T_{R,Q},D_R}\|^2=(2(\beta-1)+o_\beta(1))H\log H,
\qquad
\|K_{U,L}\|^2=((\beta-1)+o_\beta(1))H\log H.
\quad}\tag{1}
\]
特别地，\(\beta=2\) 时，note 818 中尚未支付的深区—上分子带交叉达到 \((2+o(1))H\log H\)；只用深区最小谱隙与上分子带最小谱隙的全局范数 Schur 方法有临界 \(\log H\) 扣款。

## 上界

note 803 式 (5)--(6) 的有序互素对嵌入，将 \(D_R\) 放在 \(L\times L\)，而 \(T_{R,Q}\) 放在 \((U\times L)\sqcup(L\times U)\sqcup(U\times U)\)。单坐标素数幂边从 \(L\times L\) 只能进入前两个互相正交的块；跨素数指数零点的余项在全图的算子范数为 \(O(\log H)\)。反对称折叠仍是等距嵌入，所以
\[
\|C^-_{T_{R,Q},D_R}\|\le\sqrt2\,\|K_{U,L}\|+O(\log H).\tag{2}
\]
取 \(v_m=m^{-1/2}\)。对输出 \(u\in U\)，加权行和为
\[
\frac{(K_{U,L}v_L)_u}{v_u}
=\sum_{\substack{n\mid u,\ n\text{ 为素数幂}\\u/n\le R}}\Lambda(n)
\le\log u\le H.
\]
对输入 \(m\in L\)，反向加权行和由统一 Mertens 公式给
\[
\frac{(K_{L,U}v_U)_m}{v_m}
=\sum_{R/m<n\le Q/m}\frac{\Lambda(n)}n
\le\log(Q/R)+O(1)=(\beta-1)\log H+O_\beta(1).
\]
矩形 Schur 检验遂给
\[
\|K_{U,L}\|^2\le H((\beta-1)\log H+O_\beta(1)).\tag{3}
\]
将 (3) 代入 (2)，得到 (1) 第一式的上界。

## 两条互不重合的素数臂

充分大时 \(2/1\in D_R\)。对每个奇素数 \(q\) 满足 \(R/2<q\le Q/2\)，槽 \(y=2q/1\) 属于 \(T_{R,Q}\)，且 \(C^-(y,2/1)=c_q=(\log q)/\sqrt q\)；这里 \(y/(2/1)=q\)，而 \(y(2/1)=4q\) 不是素数幂。对每个奇素数 \(R<q\le Q\)，槽 \(y=q/2\) 也属于 \(T_{R,Q}\)，且 \(C^-(y,2/1)=-c_q\)；这里 \(y(2/1)=q\)，而 \(y/(2/1)=q/4\) 及其倒数都不是整数素数幂。两族槽不重合，所以
\[
\|C^-_{T_{R,Q},D_R}\|^2
\ge\|C^-_{T_{R,Q},D_R}e_{2/1}\|^2
\ge\sum_{R/2<q\le Q/2}\frac{(\log q)^2}{q}
+\sum_{R<q\le Q}\frac{(\log q)^2}{q},\tag{4}
\]
两和均遍历奇素数。素数定理经部分求和给
\[
\sum_{A<q\le B}\frac{(\log q)^2}{q}
=\frac12((\log B)^2-(\log A)^2)+o(H\log H)
=((\beta-1)+o_\beta(1))H\log H
\]
当 \((A,B)=(R/2,Q/2)\) 或 \((R,Q)\) 时成立；固定倍数端点只引入 \(O(\log H)\) 级主项差。式 (4) 与 (2)--(3) 夹出 (1) 的第一式；再由 (2) 反推第二式的下界，并以 (3) 收尾。\(\square\)

## 子幂深区与上分子带、polar 外区的联合谱隙

现在再固定 \(1<\beta<3\)、\(0<\theta<1\)、\(r>2/(1-3/\pi^2)\)，令 \(S=\lfloor P^\theta\rfloor\) 和 \(\gamma_r=1-2/r-3/\pi^2>0\)。充分大时 \(S<R\)，故 \(I_S\)、\(T_{R,Q}\) 与 note 813 的 \(E_r\) 两两正交。它们连同全部 Farey 阶跃偶极 \(W_p\) 满足
\[
\boxed{\quad
P_{I_S\oplus T_{R,Q}\oplus E_r}A_{p^2,-}P_{I_S\oplus T_{R,Q}\oplus E_r}
\succeq\bigl(\min\{2(1-\theta),\gamma_r\}-o_{\theta,\beta,r}(1)\bigr)H I,
\quad}\tag{5}
\]
\[
P_{W_p\oplus I_S\oplus T_{R,Q}\oplus E_r}A_{p^2,-}
P_{W_p\oplus I_S\oplus T_{R,Q}\oplus E_r}
\succeq(c_0-o(1))I,
\qquad c_0=1+\gamma_E-\log\pi+\delta_0>0.\tag{6}
\]
若 \(\theta<1-\gamma_r/2\)，式 (5) 的首项就是 \(\gamma_rH\)。该联合空间同时包含每个固定有理槽和 note 817 的临界小分母向量，并占 \(I_Q\) 的 \(1-o(1)\) 维；其未覆盖的内区分子位于 \(S<a\le R\)。

证明 (5) 时，在整个三块上一次丢去 note 807 的正矩阵 \(B\)。note 813 式 (5) 对 \(I_S\) 给 \((2(1-\theta)-o(1))H\) 的对角下界；note 818 式 (2) 的第一式对 \(T_{R,Q}\) 给 \(H-o(H)\)；note 810 对 \(E_r\) 给 \((\gamma_r-o(1))H\)。式 (2)--(3) 的上界对 \(I_S\subset I_R\) 仍成立，所以深区—上分子带的算术交叉为 \(O_\beta(\sqrt{H\log H})\)。note 813 式 (7)--(10) 对深区—外区给同一阶；note 818 式 (9) 对上分子带—外区也给同一阶。整个 \(I_Q\) 上 note 809 的非算术同臂核范数和 polar 平方范数均为 \(O(H^{-1})\)；到 \(E_r\) 的同臂核和 polar 交叉范数分别由 notes 811、809--810 给 \(O_r(1)\)。因此丢去 \(B\) 后的三个真实交叉块全是 \(O_{\beta,r}(\sqrt{H\log H})=o(H)\)。对三块向量范数作三维标量比较，其最小特征值至少为三个对角下界的最小值减 \(O_{\beta,r}(\sqrt{H\log H})\)，即 (5)。note 806 的 \(W_p\) 混合范数为 \(O(1)\)，note 804 的 \(W_p\) 谱隙为 \((c_0-o(1))I\)；以 (5) 完成平方的阶跃损失为 \(O(H^{-1})\)，得 (6)。维数结论由 note 818 的 \(\dim T_{R,Q}/\dim I_Q\to1\) 直接得到。\(\square\)

## 边界

式 (1) 仅是跨块范数，不构成 Weil 负方向。使其尖锐的固定槽 \(2/1\) 自身具有 \(2H+O(1)\) 对角能量，不能用整个深区的最小谱隙 \(2\beta\log H-O(1)\) 代替。式 (5) 虽把固定槽与上分子带合并，却仍遗漏 \(P^\theta<a\le P/H^\beta\) 的中间深区。要加入这块，必须按源位置保留真实能量，或在共同外区使用真逆响应。外区低斜率槽、非恒定轮廓、无限维补空间、全尺度局部 Weil 正性及 moving-\(N\) Möbius signed covariance 仍未解决。
