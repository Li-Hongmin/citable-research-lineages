# 偶极缺陷核的整数格求和有精确正的分数部余量（候选）

日期：2026-09-29。承接 [scratch 818](818-polynomial-exterior-farey-compression-is-a-signed-near-resonance-matrix-candidate.md) 式 (5) 的偶极重叠核，以及 [scratch 830](830-widened-farey-near-cross-discards-prime-powers-and-is-a-two-prime-shift-candidate.md) 式 (3a) 的有符号整数缺陷和。这里只计算**无算术权、无同余筛选**的完整缺陷格；不能用它代替真实双素数和的估计。

## 精确格点恒等式

对 \(t>0\) 令
\[
T_t(u)=(1-|u|/t)_+,\qquad
r(u)=2T_1(u)-T_2(u).
\tag{1}
\]
则 \(r(u)=R_\eta(\eta|u|)\)：在 \(|u|\le1\) 为
\(1-3|u|/2\)，在 \(1\le|u|\le2\) 为 \(|u|/2-1\)，在 \(|u|\ge2\) 为零。
对每个 \(W>0\)，有**精确公式**
\[
\boxed{\quad
\sum_{d\in\mathbb Z}r(d/W)
=\frac{\operatorname{dist}(W,\mathbb Z)}{W}
\in\left[0,\min\left\{1,\frac1{2W}\right\}\right].
\quad}
\tag{2}
\]
故格点和在 \(W\in\mathbb Z_{>0}\) 时恰为零；在 \(W\) 为半整数时达到
\(1/(2W)\)。连续积分 \(\int_{\mathbb R}r(u)\,du=0\)，但它不蕴含整数格求和为零。

对于原来使用的**对数相移**，令 \(0<\eta<1/10\)、\(X>0\)、\(W=\eta X\)。把
\(R_\eta(s)=r(s/\eta)\) 按 818 式 (5) 定义，则一致地有
\[
\boxed{\quad
\sum_{\substack{d\in\mathbb Z\\X+d>0}}
R_\eta\!\left(\left|\log\left(1+\frac dX\right)\right|\right)
=\frac{\operatorname{dist}(W,\mathbb Z)}{W}
+O\!\left(\eta(1+W)\right).
\quad}
\tag{3}
\]
在 830 的 \(7/4<\kappa\le23/12\)、\(X=Dm<p^{23/12}\)、\(\eta=p^{-\kappa}\)
范围，(3) 的误差为
\[
O\!\left(p^{-\kappa}+p^{23/12-2\kappa}\right)=o(1)
\tag{4}
\]
一致地成立。式 (3) 的主项为非负且在 \(W\gg1\) 时至多 \(1/(2W)\)。

## 证明

令 \(\psi(t)=\{t\}(1-\{t\})\)。若 \(N=\lfloor t\rfloor\)，直接求和得
\[
\begin{aligned}
\sum_{d\in\mathbb Z}T_t(d)
&=1+2\sum_{j=1}^{N}\left(1-\frac jt\right)\\
&=1+2N-\frac{N(N+1)}t
=t+\frac{\psi(t)}t.
\end{aligned}
\tag{5}
\]
由 (1)，
\[
\sum_{d\in\mathbb Z}r(d/W)
=2\sum_dT_W(d)-\sum_dT_{2W}(d)
=\frac{2\psi(W)}W-\frac{\psi(2W)}{2W}.
\tag{6}
\]
写 \(\theta=\{W\}\)。当 \(0\le\theta\le1/2\) 时，(6) 等于
\(\theta/W\)；当 \(1/2\le\theta<1\) 时等于
\((1-\theta)/W\)。这就是 (2)。由 (1) 的两个三角函数面积立即有
\(\int_{\mathbb R}r=2\cdot1-2=0\)。

为证明 (3)，若任一侧的核非零，则 \(|d|\le3W\) 对足够小的 \(\eta\) 成立。
这时 \(|d/X|\le3\eta\)，Taylor 余项给
\[
\left|
\frac{|\log(1+d/X)|}{\eta}-\frac{|d|}{W}
\right|\ll\eta.
\tag{7}
\]
函数 \(r\) 在整条实线上是 \(3/2\)-Lipschitz，包括两个折点及支撑端点；
故每个可能非零的格点上，两核之差为 \(O(\eta)\)。这样的格点只有
\(O(1+W)\) 个。将差相加，再用 (2)，得到 (3)。最后 \(W\le
p^{23/12-\kappa}\)，给出 (4)。\(\square\)

## 对真实算术门的边界

830 式 (3a) 中的 \(d\) 还必须满足 \(c\mid Dm+d\)，并带有
\(F_Q(m)F_Q(M)\)、\((M,D)=1\) 和非恒定分母权。式 (2)--(3) 不能消掉这些
限制，也没有证明其带权和为 \(o(H^4)\)。它只精确指出：即使先把局部算术
权视作常数，连续核的零积分在整数格上仍留下
\(\operatorname{dist}(W,\mathbb Z)/W\) 的确定性余量；真实门还需控制
权重与缺陷同余类的相关。
