# 每个外侧根的次对数平方分母有理锥保留线性真 Weil 正隙（候选）

后续 [scratch/890](890-bounded-incoming-prime-load-pays-subexponential-farey-denominators.md) 将同一正隙推进至 \(\log B=o((\log X)^{2/3}(\log\log X)^{1/3})\)。本稿保留其逐中心有理入射界及同臂权重证明。

日期：2026-10-01。依赖 [scratch/884](884-sparse-exterior-weil-profiles-have-a-linear-positive-gap.md) 的实尺度外侧槽、[note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 的单槽闭形式和相离核，以及 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的旧奇素数幂平移约定。它加强并取代 [scratch/887](887-subcritical-growing-denominator-farey-cones-around-exterior-roots.md) 的平均中心结论：反射块现由有理数间距逐中心控制，不再删除原槽。以下是尚待异源复核的候选证明，故暂留 scratch。

## 陈述

令 \(X\to\infty\) 为实尺度，\(H=\log X\)、\(k=X^2\)、\(\ell=\log(1+X^{-2})\)、\(w=\ell/2\)。令整数 \(B=B(X)\ge1\) 满足
\[
B=o(H^2).
\tag{1}
\]
对 [scratch/884](884-sparse-exterior-weil-profiles-have-a-linear-positive-gap.md) 的**每个**原槽 \(y\in\mathcal G_X^\circ\)，取 \(N_y=\lfloor y/2\rfloor\) 和既约有理标签
\[
\mathcal R_{y,B}=\{1\}\cup
\left\{r=\frac ab:5\le r\le N_y,\quad 1\le b\le B,\quad(a,b)=1\right\}.
\tag{2}
\]
以 \(\log(Xy/r)\) 为上臂中心，取宽度 \(w\) 的槽及其关于 \(u\mapsto2H-u\) 的奇反射。记 \(\mathscr V_{y,B}\) 为这些槽上全部有限能量奇轮廓的直和闭形式域。存在绝对常数 \(C\)，对充分大的 \(X\)，所有 \(y\) 同时满足
\[
\boxed{\quad
A_{k,-}|_{\mathscr V_{y,B}}
\succeq
\left(H-C\bigl(\sqrt H+\sqrt B+\log(B+2)\bigr)\right)I
=(1-o(1))H I.
\quad}
\tag{3}
\]
同一估计还给出绝对常数 \(c_0,c_1>0\)：若 \(1\le B\le c_0H^2\)，则所有这些压缩均满足 \(A_{k,-}|_{\mathscr V_{y,B}}\succeq c_1H I\)。式 (4) 的尖锐主系数适用于 \(B=o(H^2)\)；固定比例端点见式 (4a)。
令 \(e_{y,1}\) 为根的单位常值半宽槽；消去所有 \(r>1\) 槽的**完整有限能量轮廓**所得真闭形式 Schur 扣款记为 \(R_{y,B}\)。则一致有
\[
\boxed{\quad
\left(\frac14+o(1)\right)H\le R_{y,B}
\le\left(1-\log2+o(1)\right)H,
\qquad
A_{k,-}[e_{y,1}]-R_{y,B}
\ge(1+\log2-o(1))H.
\quad}
\tag{4}
\]
对固定的充分小 \(0<c\le c_0\)，同一根 Schur 扣款在 \(1\le B\le cH^2\) 时还满足
\[
\left(\frac14+o(1)\right)H\le R_{y,B}
\le\bigl(1-\log2+O(\sqrt c)+o(1)\bigr)H,
\qquad
A_{k,-}[e_{y,1}]-R_{y,B}
\ge\bigl(1+\log2-O(\sqrt c)-o(1)\bigr)H.
\tag{4a}
\]
这里 \(O(\sqrt c)\) 的隐常数绝对，\(o(1)\) 对所有 \(y\) 和 \(B\le cH^2\) 一致。
根槽位于原 \(V_{\{y\}}\) 内，全部 \(r>1\) 槽与整个原 \(V_{\mathcal G_X^\circ}\) 正交。这是所列物理锥的真压缩；它不控制锥外 Schur 反馈或完整旧奇空间。

## 物理分离与非算术项

每个标签有 \(1\le r\le X/4\)，不同既约标签 \(a/b,c/d\) 满足
\[
|a/b-c/d|\ge (bd)^{-1}\ge B^{-2},\qquad
|\log(r/r')|\gg(B^2X)^{-1}\gg w.
\tag{5}
\]
在式 (1) 下 \(B^2/X\to0\)。因 \(r\le y/2\)，物理点 \(y/r\ge2\)，而 \(r\ge5\) 时 \(y/r\le X/10<X/8\)；原槽点均位于 \((X/8,X/2)\)。槽宽 \(w\) 与原槽宽 \(\ell\) 保证所述正交性和旧区间内部性。若素数幂平移 \(s\ge2\) 使两个同臂槽相交，则
\[
|sad-cb|<cb(e^w-1)\ll B^2/X<1;
\]
故必有 \(sr=r'\)，且两槽轮廓坐标精确重合。同臂算术块因而恰是边权 \(\Lambda(s)/\sqrt s\) 的乘法图张量 \(I_{L^2(0,w)}\)。

对固定 \(r=a/b\)，按分母 \(d\le B\) 将其他标签 \(c/d\) 排序：最近点距离至少 \(1/(bd)\)，其余点以 \(1/d\) 间隔增长。于是
\[
\sum_{r'\ne r}|r-r'|^{-1}
\ll B^3+B^2\log(BX).
\tag{6}
\]
[note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 的相离核 \(K(t)\ll t^{-1}+1\)，连同式 (5)--(6)，使全部同臂 Archimedean 非对角块的行和为
\(O((B^3+B^2H)/X)=o(1)\)。上下臂中心距至少 \(2\log2\)，异臂 Archimedean 行和为 \(O(B^2/X)=o(1)\)。polar 压缩范数至多
\[
O\!\left(wX\sum_{r\in\mathcal R_{y,B}}r^{-1}\right)
=O(B^2H/X)=o(1).
\tag{7}
\]
精确单槽闭形式对任意有限能量轮廓一致地至少为 \(2H-O(1)\) 倍范数平方；单位常值轮廓的对角为 \(D_X+o(1)\)，其中
\(D_X=2H+1-\gamma_E-\log\pi\)。这些估计对全部 \(y\) 一致。
每个固定 \(X\) 的标签数有限；相离槽之间的 Archimedean 核、有限素数幂平移和 polar 项均为有界 \(L^2\) 形式。因此限制闭形式的定义域是这些单槽形式域的有限直和，先对每槽光滑紧支撑轮廓计算的下界由形式核心延拓到全部有限能量轮廓。

## 反射块的逐中心有理入射界

固定 \(x=y\) 和一行标签 \(r\)。异臂反射块从 \(r\) 到 \(r'\) 只有在某个素数幂 \(s\) 满足
\[
\left|\log\frac{srr'}{x^2}\right|<w
\tag{8}
\]
时出现，该部分块的算子范数至多 \(C\Lambda(s)/\sqrt s\)。记 \(t=sr'\)。其约分后分母不超过 \(B\)，且全部可能的 \(t\) 落在
\(I_r=(x^2e^{-w}/r,x^2e^w/r)\) 中。该区间长至多 \(C/r\)；不同的约分后分母不超过 \(B\) 的有理数相距至少 \(B^{-2}\)。因此一行涉及的不同 \(t\) 至多
\[
K_r\le1+CB^2/r.
\tag{9}
\]

对一个 \(t=A/D\)（既约）定义
\[
W(t)=\sum_{\substack{s=p^j\text{ 素数幂}\\t/s\in\mathcal R_{y,B}}}
\frac{\Lambda(s)}{\sqrt s}.
\]
有 \(A=tD\le C X^2B\)，故 \(\log(A+2)\ll H\)。若 \(j\le v_p(A)\)，则 \(s\mid A\)；以 \(Z=\log(A+2)\) 分开 \(s\le Z\) 与 \(s>Z\)，Chebyshev 上界和 \(\sum_{p^j\mid A}\Lambda(p^j)=\log A\) 给
\[
\sum_{p^j\mid A}\frac{\Lambda(p^j)}{\sqrt{p^j}}
\ll\sqrt Z+\frac{\log A}{\sqrt Z}\ll\sqrt H.
\]
若 \(j>v_p(A)\)，则 \(t/p^j\) 约分后的分母含有 \(p^{j-v_p(A)}\)，所以 \(p^{j-v_p(A)}\le B\)。每个 \(p^h\le B\) 至多对应一项，故
\[
\boxed{\quad W(t)\ll\sqrt H+\sqrt B.\quad}
\tag{10}
\]
同样不加平方根权重时，两个素数幂类的 \(\Lambda\) 总和至多
\(\log A+\Psi(B)\ll H+B\)。又因 \(r'=t/s\le N_y\le X/4\)、\(x\ge X/8\)，式 (8) 强制 \(s\ge cX/r\)。因此还有
\[
W(t)\ll(H+B)\sqrt{r/X}.
\tag{11}
\]
对 \(r>B^2\)，式 (9)--(10) 直接给行和 \(O(\sqrt H+\sqrt B)\)。对 \(1\le r\le B^2\)，式 (9)、(11) 给行和
\[
O\!\left((H+B)\sqrt{r/X}(1+B^2/r)\right)
\ll (H+B)B^2/\sqrt X=o(1),
\tag{12}
\]
最后的 \(o(1)\) 对 \(B=O(H^2)\) 仍一致；式 (13) 的 \(o(H)\) 才使用 \(B=o(H^2)\)。整个异臂算术块是自伴块矩阵；以块范数的对称行和作 Schur 检验，得到**对每个 \(y\)** 的
\[
\boxed{\quad \|E_{y,B}\|\ll\sqrt H+\sqrt B=o(H).\quad}
\tag{13}
\]
这里没有平均中心、随机符号或素数间相关估计。

## 同臂图的分子分母权重

令 \(C_{y,B}\) 为正边权同臂图，取 \(v_{a/b}=(ab)^{-1/2}\)。记
\(M(T)=\sum_{p^j\le T}\Lambda(p^j)/p^j\le\log T+O(1)\)（\(T\ge1\)）。对 \(r=a/b\) 逐素数幂约分：

- 在 \(r\mapsto p^j r\) 方向，\(j\le v_p(b)\) 的加权行贡献逐项为 \(\log p\)，总共不超过 \(\log b\)；其余项在置 \(h=j-v_p(b)\) 后每项为 \(\log p/p^h\)，合计不超过 \(M(N_y/r)\)。
- 在 \(r\mapsto r/p^j\) 方向，\(j\le v_p(a)\) 的贡献总共不超过 \(\log a\)；其余项的约分后分母为 \(b p^h\le B\)，合计不超过 \(M(B/b)\)。标签下界 \(r/p^j\ge5\) 只删除边。

由此得到逐行上界
\[
\frac{(C_{y,B}v)_{a/b}}{v_{a/b}}
\le\log a+\log b+M(N_y/r)+M(B/b)
\le\log N_y+2\log B+O(1).
\tag{14}
\]
对称正权 Schur 检验给 \(\|C_{y,B}\|\le\log N_y+2\log B+O(1)\)。合并单槽下界、式 (7)、(13) 与 \(\log N_y=H+O(1)\)，证明 (3)。

为保留根 Schur 的素数幂余量，对每条无向边 \(r\leftrightarrow r'=sr\)、\(c=\Lambda(s)/\sqrt s\) 使用 Hilbert 值平方恒等式
\[
c\left\|\sqrt{v_{r'}/v_r}\,h_r-\sqrt{v_r/v_{r'}}\,h_{r'}\right\|^2
=c\frac{v_{r'}}{v_r}\|h_r\|^2
+c\frac{v_r}{v_{r'}}\|h_{r'}\|^2
-2c\operatorname{Re}\langle h_r,h_{r'}\rangle.
\tag{15}
\]
删去根标签 \(1\) 后，整数素数幂 \(q\ge5\) 到根的唯一边 \(s=q\) 消失；其在 \(q\) 行原先占去
\(c_qv_1/v_q=\Lambda(q)\)。因此补空间的闭形式满足
\[
\boxed{\quad
B_{y,B}^{\rm prof}\succeq
\bigoplus_{r\ne1}
\left(2H-\log N_y+\Lambda(r)\mathbf1_{\{r\text{ 为整数素数幂}\}}
-O\bigl(\sqrt H+\sqrt B+\log(B+2)\bigr)\right)I_{L^2(0,w)}.
\quad}
\tag{16}
\]
根的同臂列是 \(-b\otimes h_0\)，其中 \(h_0=w^{-1/2}\mathbf1_{(0,w)}\)、\(b_q=\Lambda(q)/\sqrt q\) 对整数素数幂 \(5\le q\le N_y\) 非零；式 (7)、(13) 使其余列的合范数为 \(O(\sqrt H+\sqrt B)\)。补空间隙为 \(H-o(H)\)，且 \(\|b\|=O(H)\)，所以这项列误差对 Schur 扣款贡献 \(o(H)\)。由式 (16) 的逆序比较、素数定理和高次素数幂的绝对可和性，
\[
R_{y,B}\le
\sum_{\substack{5\le q\le N_y\\q\text{ 素数幂}}}
\frac{\Lambda(q)^2/q}
{2H-\log N_y+\Lambda(q)-o(H)}+o(H)
=\int_0^{\log N_y}\frac{u}{2H-\log N_y+u}\,du+o(H)
=(1-\log2+o(1))H.
\tag{17}
\]
反向仅保留整数素数 \(5\le q\le N_y\) 的常值轮廓：其互相没有同臂边，补块为 \(2H I+o(H)\)，根列平方范数为 \((1/2+o(1))H^2\)。逆度量变分给 \(R_{y,B}\ge(1/4+o(1))H\)。根异臂自环权为 \(O(H/X)\)，polar 自项为 \(O(X^{-1})\)，故 \(A_{k,-}[e_{y,1}]=2H+O(1)\)。这证明 (4)。\(\square\)

对式 (4a)，在 \(B\le cH^2\) 下式 (13) 为 \(O(\sqrt c\,H)+o(H)\)，故选 \(c_0\) 足够小后补空间仍有固定比例的 \(H\) 级正隙，式 (16) 的分母改为 \(2H-\log N_y+\Lambda(q)-O(\sqrt c\,H)-o(H)\)。式 (17) 的积分随该分母的相对扰动连续，增量为 \(O(\sqrt c\,H)\)。下界的素数常值试探子空间只涉及整数标签；对这一子空间单独在式 (13) 取 \(B=1\)，其反射块为 \(O(\sqrt H)=o(H)\)，故原有的 \((1/4+o(1))H\) 下界保持。根反射列由式 (12) 甚至为 \(o(1)\)，于是同样得到式 (4a) 的枢轴界。\(\square\)

## 边界

有理入射界 (10) 的 \(\sqrt B\) 在 \(B\asymp H^2\) 达到对角预算的线性量级，当前行和论证不能继续给 \((1-o(1))H\) 正隙。这是证明方法的边界，不能推出真实反射算子在该尺度具有线性范数。本稿没有估计该锥到其余旧奇空间的 Schur 反馈，也不推出全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 或 RH。
