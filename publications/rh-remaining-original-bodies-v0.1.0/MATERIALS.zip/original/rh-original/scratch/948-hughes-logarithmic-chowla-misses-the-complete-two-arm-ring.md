# Hughes 的有效对数 Chowla 定理不触及完整两臂留存环带

日期：2026-10-02。依赖 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 式 (13)--(18)。核对来源：Scott D. Hughes, *Effective logarithmic two-point Chowla bounds in every window*, arXiv:2609.28526v1 (2026-09-22), Theorem 1.2--1.3；原文 PDF 已读，ResearchLibrary 已缓存。这里仅判定该定理能否作为当前门的输入，不判定其方法能否另行加强。

## 精确参数障碍

仍用 note 850 的 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$g=(u,v)$、$a=u/g$、$b=v/g$，以及乘子 $k,\ell<64H$。留存的物理位移写成
\[
\Delta=ku-\ell v=g(ka-\ell b)=gr,
\qquad |r|>\frac{H^7}{2M\log^8(2M)}.
\tag{1}
\]
设 $d=(k,\ell)$。只有 $d\mid r$ 才有整数解；有解时令 $k=dk'$、$\ell=d\ell'$，选一组解 $(a_0,b_0)$，则所有解由
\[
a=a_0+\ell't,
\qquad b=b_0+k't
\tag{2}
\]
参数化。欲对这组真实源应用 Hughes 的两线性形式定理，形式为
$L_1(t)=g(a_0+\ell't)$、$L_2(t)=g(b_0+k't)$，其行列式满足
\[
|a_1b_2-a_2b_1|=\frac{g^2|r|}{d}
>\frac{g^2H^7}{128MH\log^8(2M)}
\ge\frac{H^6}{128M\log^8(2M)}
\gg\frac{M^{1/5}}{\log^8(2M)}.
\tag{3}
\]
这里 $d<64H$，末式在整个指定 $H$ 区间一致成立。Hughes Theorem 1.2 的 augmented height $h$ 包含这个行列式，故 $h\gg M^{1/5}/\log^8M$。该定理要求
\[
x\ge\omega\ge\exp_4(C h\varepsilon^{-2})
\quad(0<\varepsilon\le1/10),
\tag{4}
\]
其中 $\exp_4$ 是四重指数。将 (2) 的参数平移，使当前实际正参数段从 $1$ 开始；由 $a,b=O(M/g)$，其末端 $t$ 至多为 $O(M)$。为了估计这一局部段，(4) 必须可用于端点 $x=O(M)$；但 $\log_4 x=O(\log_4M)$，与 (3)--(4) 矛盾，即使 $\varepsilon=1/10$ 固定。故 Theorem 1.2 不能逐项用于 note 850 式 (18) 的任何留存仿射相关。Theorem 1.3 的平移改进只把共同平移移出塔门，仍要求其 reduced height 至少覆盖行列式，因此结论相同。

此外，Hughes 控制的是 $\sum_{x/\omega<n\le x}g_1(L_1(n))g_2(L_2(n))/n$，误差为 $\varepsilon\log\omega$。当前 Gram 是 $t\asymp M$ 的自然密度相关，含随位移变化的带符号核。即使忽略 (3)--(4)，原定理也没有给出所需的 $O(H^4/M)$ 加权自然密度上界。

## 边界

这只排除把 Hughes 2026 的现成定理代入完整留存环带；不排除未来针对自然密度、增长系数与联合带通权的新二点方法。当前真实 signed Gram 仍未达到目标量级。
