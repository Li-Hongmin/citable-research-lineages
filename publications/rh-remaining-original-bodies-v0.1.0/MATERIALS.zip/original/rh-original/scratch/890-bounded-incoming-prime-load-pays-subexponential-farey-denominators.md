# 有界大素数入边将外侧有理锥推进到次指数分母（候选）

后续 [scratch/891](891-logarithmic-denominator-weight-pays-fixed-power-farey-cones.md) 用分母对数权重把式 (9) 的范数改进为 \(O(\log(B+2))\)，并用大完整分子因子支付低高块，从而将正锥推进到任意固定 \(B\le X^\alpha,\ \alpha<1/5\)。本稿保留原计数法及其较弱范围。

日期：2026-10-01。依赖 [scratch/888](888-all-exterior-rational-cones-below-log-squared-denominators.md) 的槽几何、单槽闭形式与同臂分子分母权重，以及 [scratch/889](889-critical-reflection-blocks-have-exact-rational-product-levels.md) 的精确反射乘积层。下面直接控制各层的谱范数，使每个外侧根的正锥覆盖 \(\log B=o(H^{2/3}(\log H)^{1/3})\)，其中 \(H=\log X\)。证明尚未异源复核，留在 scratch；它不处理锥外 Schur 反馈、moving-\(N\) 算术门或 RH。

## 定理

沿用 scratch/888 的实尺度 \(X\to\infty\)、原槽 \(y\in\mathcal G_X^\circ\)、标签
\[
\mathcal R_{y,B}=\{1\}\cup
\{a/b:5\le a/b\le \lfloor y/2\rfloor,\ b\le B,\ (a,b)=1\}
\]
及全部有限能量奇轮廓空间 \(\mathscr V_{y,B}\)。置 \(L_B=\log(B+2)\)。若整数 \(1\le B\le e^{H/10}\)，则对**每个** \(y\) 一致有异臂算术算子界
\[
\boxed{\quad
\|E_{y,B}\|\ll \sqrt H+
L_B\sqrt{1+\frac{L_B}{\log(H+2)}}.
\quad}
\tag{1}
\]
因此只要
\[
L_B=o\!\left(H^{2/3}(\log(H+2))^{1/3}\right),
\tag{1a}
\]
真实旧奇 Weil 闭形式的这些压缩满足
\[
\boxed{\quad
A_{X^2,-}|_{\mathscr V_{y,B}}
\succeq
\left(H-O\!\left(\sqrt H+
L_B\sqrt{1+\frac{L_B}{\log(H+2)}}\right)\right)I
=(1-o(1))H I.
\quad}
\tag{2}
\]
根单位常值半宽槽 \(e_{y,1}\) 对全部 \(r>1\) 完整轮廓的真 Schur 扣款仍一致满足
\[
\boxed{\quad
\left(\frac14+o(1)\right)H
\le R_{y,B}
\le\left(1-\log2+o(1)\right)H,
\qquad
A_{X^2,-}[e_{y,1}]-R_{y,B}
\ge(1+\log2-o(1))H.
\quad}
\tag{3}
\]
还存在绝对 \(c_0,c_1>0\)：若 \(L_B\le c_0H^{2/3}(\log(H+2))^{1/3}\)，则式 (2) 的压缩至少为 \(c_1H I\)；若固定 \(0<c\le c_0\) 且 \(L_B\le cH^{2/3}(\log(H+2))^{1/3}\)，式 (3) 的上界和枢轴下界可分别放宽 \(O(c^{3/2})H\)。

## 一个精确乘积层的算术范数

取 [scratch/889](889-critical-reflection-blocks-have-exact-rational-product-levels.md) 中的一个乘积层 \(P\)，其非负对称矩阵为
\[
K_P(r,r')=
\frac{\Lambda(s)}{\sqrt s}\,
\mathbf1_{\{s=P/(rr')\text{ 是整数素数幂}\}}.
\tag{4}
\]
所有 \(r=a/b,r'=a'/b'\) 均为既约且 \(b,b'\le B\)，而 \(\operatorname{den}(P)\le B^2\)。置 \(Q=H\)。把 (4) 的边按下列**互不重叠**的五类分开。

**小素数。** 对 \(s=p\le Q\)，每个固定 \(p\) 的 \(P\) 层边是部分置换 \(r'\!=P/(pr)\)，范数至多 \(\log p/\sqrt p\)。Chebyshev 分部求和给
\[
\left\|K_P^{\rm small}\right\|
\le\sum_{p\le Q}\frac{\log p}{\sqrt p}
\ll\sqrt H.
\tag{5}
\]

**高次幂且底数不超过 \(\max(B,H)\)。** 对 \(s=p^j\)、\(j\ge2\)、\(p\le T:=\max(B,H)\)，仍逐固定 \(s\) 使用部分置换范数。由 \(p-\sqrt p\asymp p\)（\(p\ge3\)）及 \(\sum_{p\le T}(\log p)/p\ll\log(T+2)\)，
\[
\left\|K_P^{\rm powers,\ p\le T}\right\|
\le\sum_{p\le T}\sum_{j\ge2}\frac{\log p}{p^{j/2}}
\ll \log(T+2)\ll L_B+\log(H+2).
\tag{6}
\]

**两个端点的分母都不含底数。** 剩余素数幂中，令 \(s=p\)、\(p>H\)，或令 \(s=p^j\)、\(j\ge2\)、\(p>\max(B,H)\)。在后一情形 \(p>B\)，故自动有 \(p\nmid bb'\)。若 \(p\nmid bb'\)，则对固定行 \(r\)，因 \(P/r=s r'\)，素数幂 \(s\) 必整除 \(P/r=A/D\) 的约分后分子 \(A\)。且 \(A\le C X^2B\)、\(\log B\le H/10\)，所以 scratch/888 的分子整除和界给
\[
\sum_{s\mid A,\ s\text{ 为素数幂}}\frac{\Lambda(s)}{\sqrt s}
\ll\sqrt{\log(A+2)}\ll\sqrt H.
\tag{7}
\]
该边类关于 \(r,r'\) 对称，非负矩阵的行和 Schur 检验给 \(\|K_P^{\rm free}\|\ll\sqrt H\)。

余下只有 \(s=p\) 且 \(H<p\le B\)，至少一个端点的分母含 \(p\)。

**两个分母都含 \(p\)。** 因 \(P=p r r'\)，其 \(p\)-进赋值至多 \(1-1-1=-1\)，故 \(p\mid\operatorname{den}(P)\)。由于 \(\operatorname{den}(P)\le B^2\) 而 \(p>H\)，这样的不同 \(p\) 至多 \(2L_B/\log H\) 个。逐固定 \(p\) 的部分置换界给
\[
\|K_P^{\rm both}\|
\ll \left(1+\frac{L_B}{\log H}\right)
\sup_{p>H}\frac{\log p}{\sqrt p}
\ll 1+\frac{L_B}{\sqrt H}.
\tag{8}
\]

**恰一个分母含 \(p\)。** 把边定向到分母含 \(p\) 的端点。一个整数 \(b'\le B\) 至多有
\(m_B=\lfloor L_B/\log H\rfloor\) 个素因子 \(p>H\)；固定目标 \(r'\) 与其中一个 \(p\) 后，来源 \(r=P/(p r')\) 唯一。令 \(T\) 为此定向边的矩阵，约定行标目标、列标来源。每行至多 \(m_B\) 个非零元。逐行使用 Cauchy--Schwarz，再按来源归并；每个来源和 \(p\) 至多决定一个目标，因此
\[
\|T h\|^2
\le m_B\sum_{r'}\sum_{r'\leftarrow r}K_P(r',r)^2|h_r|^2
\le m_B\left(\sum_{p\le B}\frac{(\log p)^2}{p}\right)\|h\|^2,
\qquad
\|T\|\ll \sqrt{m_B}\,L_B.
\tag{9}
\]
该对称边类为 \(T+T^*\)，故范数为 \(O(L_B\sqrt{m_B})\)。当 \(m_B=0\) 时这类边为空。

五类相加证明
\[
\boxed{\quad
\|K_P\|\ll\sqrt H+
L_B\sqrt{1+\frac{L_B}{\log H}}
\quad}
\tag{10}
\]
对所有允许的 \(P,y,B\) 一致。这里的关键是大素数边的**有界入边数**；式 (9) 保留平方质量，而没有对该行的所有大素数权重取绝对和。

## 返回完整轮廓和根 Schur

scratch/889 的乘积层分解原以 \(B\le H^2\) 陈述，但其唯一性只用 \(r>B^2\) 与有理数间距，而低标签行界为
\[
\epsilon_{X,B}\ll (H+B)B^2/\sqrt X=o(1)
\tag{11}
\]
在全部 \(B\le e^{H/10}\) 上仍一致成立，因为其右侧至多 \(O(e^{-H/5}\operatorname{poly}(H))\)。高标签原始行和 \(\ll\sqrt H+\sqrt B\ll e^{H/20}\)，故低高块范数至多 \(O(\sqrt{\epsilon_{X,B}e^{H/20}})=o(1)\)。各 \(P\) 层共同的部分反射 \(J_{\log(P/y^2)}\) 范数为一。于是 (10) 给 (1)，而根 \(r=1\) 的异臂算术列由 (11) 单独为 \(o(1)\)。

scratch/888 的同臂乘法图对权重 \(v_{a/b}=(ab)^{-1/2}\) 有
\[
\|C_{y,B}\|\le\log N_y+2\log B+O(1)=H+O(\log(B+2)),
\tag{12}
\]
Archimedean 非对角和 polar 压缩在 \(B\le e^{H/10}\) 仍为 \(o(1)\)，各单槽闭形式至少为 \(2H-O(1)\)。将 (1) 与 (12) 合并得到 (2)。式 (1a) 使
\(L_B\sqrt{1+L_B/\log(H+2)}=o(H)\)；scratch/888 的逐边配方、删除根边后的整数素数幂余量及素数定理积分不变，给出 (3)。其下界只在整数素数标签上取试探；该子空间的异臂块可在 (1) 中单独取 \(B=1\)，范数 \(O(\sqrt H)=o(H)\)。

若 \(L_B\le cH^{2/3}(\log(H+2))^{1/3}\) 且 \(c\) 为足够小的固定常数，则 (1) 为 \(O(c^{3/2}H)+o(H)\)，式 (2) 给固定比例正隙。补空间逆序比较的分母相对扰动为 \(O(c^{3/2})\)，因此根 Schur 上界与枢轴下界分别只改变 \(O(c^{3/2})H\)。\(\square\)

## 边界

式 (9) 的有界入边 Cauchy 界在
\(\log B\asymp H^{2/3}(\log H)^{1/3}\) 达到 \(H\) 级。它不证明不同大素数入边真的相干，也不控制 \(B=X^\alpha\) 等多项式尺度。当前需要判定固定乘积层内多个大素数入边是否可再正交化，或找到真实的线性谱块；方法边界本身不是反例。
