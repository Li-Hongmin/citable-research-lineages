# 全 Farey 偶极压缩的 Archimedean 误差一致有界（待异源复核）

日期：2026-09-29。依赖 [scratch 795](795-farey-dipole-exact-arithmetic-graph-candidate.md) 的全 Farey 偶极正交与精确素数幂图，以及 [note 780](../notes/780-all-prime-power-half-slots-give-nine-thirty-seconds-logarithmic-physical-inverse-response.md) 的单半槽位置消去和相离支撑核。这里不假定旧局部 Weil 算子正性，也不运行数值计算。

## 候选定理

令 \(p\to\infty\) 沿奇素数，\(k=p^2\)、\(L=\log k\)、\(\Delta=\frac12\log(1+p^{-2})\)。取 scratch 795 的全 Farey 族 \(\mathcal F_p\)、正交偶极 \(w_x\) 与其张成空间 \(W_p\)。将真实旧奇算子写成
\[
A_{k,-}=G_k+\mathcal R_k-2|s_k\rangle\langle s_k|,
\qquad D_k=L+1-\gamma_E-\log\pi.
\tag{1}
\]
则存在不依赖 \(p\) 的常数 \(C\)，使
\[
\boxed{P_{W_p}G_kP_{W_p}=D_k I_{W_p}+E_p,qquad
\|E_p\|\le C.}
\tag{2}
\]
并且
\[
\boxed{\|P_{W_p}s_k\|=O(p^{-3/2}),qquad
\|P_{W_p}G_ke_p\|=O(p^{-2}).}
\tag{3}
\]
若 \(C_p\) 是 \(\ell^2(\mathcal F_p)\) 上的精确非负边权矩阵
\[
C_p(x,y)=c_{x/y}+c_{y/x}+c_{xy},
\quad c_t=\begin{cases}\Lambda(t)/\sqrt t,&t\text{ 为整数素数幂},\\0,&\text{其他正有理数},\end{cases}
\tag{4}
\]
则 (2)--(3) 和 scratch 795 给出整个全 Farey 压缩的结构式
\[
\boxed{A_{k,-}|_{W_p}=D_k I-C_p+\widetilde E_p,
\quad\|\widetilde E_p\|\le C+o(1),
\quad
\bigl(\langle w_x,A_{k,-}e_p\rangle\bigr)_{x\in\mathcal F_p}
=-\sqrt2(c_x)_{x\in\mathcal F_p}+O_{\ell^2}(p^{-2}).}
\tag{5}
\]
这是一个无限增长维数、但误差算子范数一致有界的**主压缩公式**。它不声称 \(D_kI-C_p\) 或完整 \(A_{k,-}\) 为正。

## 均值为零的双半槽消去

沿 scratch 795 写 \(\varphi_z=(2\Delta)^{-1/2}h(u-\log z)\)，其中
\[
h(v)=1_{(-\Delta,0)}(v)-1_{(0,\Delta)}(v),
\qquad
H(v)=\int_{-\Delta}^{v}h(t)\,dt
=\begin{cases}v+\Delta,&-\Delta<v<0,\\\Delta-v,&0<v<\Delta,\\0,&\text{其他}.\end{cases}
\tag{6}
\]
故 \(\int h=0\)、\(H\ge0\)、\(\int H=\Delta^2\)。note 780 的相离支撑 Archimedean 核为 \(-K(|u-v|)\)，
\[
K(d)=\frac{e^{-d/2}}{1-e^{-2d}}
=\sum_{j\ge0}e^{-(2j+1/2)d},
\qquad |K''(d)|\le C d^{-3}\quad(d>0).
\tag{7}
\]
后一个界可逐项对指数级数求导；当 \(d\le1\) 用与积分比较，当 \(d\ge1\) 用指数衰减。

设两个不同物理中心相距 \(d>2\Delta\)。对 \(d\ge3\Delta\)，在交叉核中对两变量各分部积分一次，由 (6) 的零边界值，得到
\[
|\langle\varphi_z,G_k\varphi_{z'}\rangle|
\le\frac1{2\Delta}
\iint H(u)H(v)\sup_{|\xi-d|\le2\Delta}|K''(\xi)|\,du\,dv
\le C\frac{\Delta^3}{d^3}.
\tag{8}
\]
这里不同位置的局部势与标量乘子没有交叉项。当 \(2\Delta<d<3\Delta\) 时，直接用 \(K(t)\ll1/t\)；最近两长度不超过 \(2\Delta\) 的区间虽可在端点接触，\(\iint_0^{2\Delta}(u+v)^{-1}du\,dv=O(\Delta)\)，乘 \((2\Delta)^{-1}\) 后为 \(O(1)\)。扩大常数便使 (8) 对全部 \(d>2\Delta\) 成立。

## 全 Farey 行和与根列

scratch 795 的整数间距证明说明全部物理中心（每个 \(w_x\) 有两个）两两相距严格超过 \(2\Delta\)。按对数位置排序后，对任意一中心，第 \(j\) 个左邻或右邻的距离至少为 \(2j\Delta\)。式 (8) 因此给出绝对行和
\[
\sum_{z'\ne z}|\langle\varphi_z,G_k\varphi_{z'}\rangle|
\le C\sum_{j\ge1}j^{-3}=O(1),
\tag{9}
\]
与 Farey 族的 \(O(p^2)\) 维数无关。这里 \(-K\) 只用于**相离支撑的交叉项**；对角须用真实 \(G_k\) 的 Legendre 差分形式、势与标量项。note 780 式 (4) 给每个归一化单半槽的共同对角
\[
\log(1/\Delta)+1-\log(2\pi)-\gamma_E+O(\Delta)
=D_k+O(\Delta),
\tag{9a}
\]
其中最后一步使用 \(\Delta=1/(2k)+O(k^{-2})\)。\(\varphi_z\) 的两半槽各有半权，故其自对角之和仍是 (9a)；两相邻反号半槽的交叉绝对值由 note 780 式 (5) 的 \(\iint(s+t)^{-1}\) 接触积分一致控制为 \(O(1)\)。因此每个完整偶极的自能量为 \(D_k+O(1)\)，且该 \(O(1)\) 对中心位置一致。物理中心基上的 Archimedean 矩阵遂为 \(D_kI+O_{\rm op}(1)\)；把每一对中心等权合成 \(w_x\) 是等距压缩，证明 (2)。

由于每个 \(x=a/b\in\mathcal F_p\) 满足 \(x\ge1+1/(p-2)\)，根中心 \(p\) 与每个 Farey 中心的对数距离至少为 \(c/p\)。式 (8) 与 \(\Delta=O(p^{-2})\) 给出每个根--偶极 Archimedean 元素为 \(O(p^{-3})\)。又 \(|\mathcal F_p|<p^2\)，故其 \(\ell^2\) 列范数为 \(O(p^{-2})\)，证明 (3) 第二式。

在对数坐标，\(s_k(u)=\sinh((u-L/2)/2)\)，所以 \(\sup_{0<u<L}|s_k'(u)|\ll p^{1/2}\)。由 \(\int h=0\) 与 (6)，对每个 \(x\in\mathcal F_p\) 有
\[
|\langle s_k,w_x\rangle|
\le C(2\Delta)^{-1/2}\Delta^2p^{1/2}
\le C\Delta^{3/2}p^{1/2}=O(p^{-5/2}).
\tag{10}
\]
合并 \(|\mathcal F_p|<p^2\) 得 \(\|P_{W_p}s_k\|=O(p^{-3/2})\)，证明 (3) 第一式。note 788 的 \(\langle s_k,e_p\rangle=O(p^{-3})\) 使 polar 根列为 \(O(p^{-9/2})\)；其主压缩范数为 \(2\|P_{W_p}s_k\|^2=O(p^{-3})\)。算术主压缩与根列按 scratch 795 的 (3)--(4) 精确给出，故 (5) 成立。\(\square\)

## 数学边界

偶极的零均值把粗糙的 \(K(d)\ll d^{-1}\) 行和提升为 \(K''(d)\ll d^{-3}\) 行和，因此先前为压低 Archimedean 交叉而取固定 \(\beta<1\) 的限制不是全 Farey 压缩的必要条件。接下来必须直接判定 \(D_kI-C_p\) 的谱与根 Schur 余额；(5) 的 \(O(1)\) 误差本身不能给出全尺度 Weil 正性、moving-\(N\) Möbius signed covariance 或 RH。
