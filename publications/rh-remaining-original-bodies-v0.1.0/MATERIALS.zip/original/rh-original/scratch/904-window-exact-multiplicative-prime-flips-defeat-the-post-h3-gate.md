# 窗口内精确保留 \(\Lambda=f*\log\) 的乘法素数翻转仍不能支付 \(H^3\) 后环带

日期：2026-10-02。接 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)--(15)、[scratch/864](864-odd-source-kernel-has-an-exact-blind-interval.md) 式 (9)--(11)、[scratch/902](902-local-bandpass-rank-one-main-term-is-repaid-by-each-channel-sidelobe.md) 式 (18) 与 [scratch/903](903-prime-supported-modulation-defeats-first-moment-control-of-the-post-h3-ring.md)。本文给出更受算术约束的反模型：每个测试函数都乘法、平方自由支撑且取值于 \(\{0,\pm1\}\)，在 \(n\le M\) 与真实 \(\mu\) 完全相同；其卷积 \(f*\log\) 在整个观察窗内就是**真实** \(\Lambda\)。反模型仍不是真实 \(\mu\)，也不反驳实际门或 RH。以下完整论证留在 scratch，尚待异源复核。

## 命题

固定实值非负、非零 \(\psi\in C_c^3((1,2))\)，令 \(\varphi(t)=\psi(t)/t\)。取 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的非负偶带通权 \(\eta\)，满足 \(\eta\ge1\) 于 \(1\le |t|\le2\)。沿偶整数 \(M=2Y\to\infty\)，置
\[
H=\lceil Y^{1/5}\rceil,\quad h_0=\lfloor 3H/2\rfloor,\quad
L=\lfloor M/(32H)\rfloor,\quad B_*=\lfloor M^{71/120}\rfloor,\quad
T_\beta=\lfloor H^3(\log M)^\beta\rfloor,\quad
\delta_M=e^{-\sqrt{\log M}},                                      \tag{1}
\]
其中 \(\beta>0\) 任意固定。令 \(K_H(r)=\sum_h\eta(h/H)e(-hr/M)\)。对任一乘法函数 \(f\) 定义 \(\Lambda_f=f*\log\)，并在 \(M<m<2M\) 置
\[
c_f(m)=2\mathbf1_{2\mid m}(\Lambda_f(m/2)-1)
-4\{\Lambda_f(m)-1+(\log2)f(m)\},\quad
A_h(f)=\frac1M\sum_{M<m<2M}c_f(m)\varphi(m/M)e(-hm/M),
\tag{2}
\]
\[
E(f)=\sum_h\eta(h/H)|A_h(f)|^2,\qquad
Q_\beta(f)=\frac1{M^2}\sum_{T_\beta<|m-n|\le L}
c_f(m)c_f(n)\varphi(m/M)\varphi(n/M)K_H(m-n).              \tag{3}
\]
存在四个乘法函数 \(f_{00}=\mu,f_{10},f_{01},f_{11}\)，使每一个满足
\[
f_{ab}(n)\in\{0,\pm1\},\quad |f_{ab}(n)|=\mu(n)^2,\quad
f_{ab}(n)=\mu(n)\ (n\le M),\quad
f_{ab}(2u)=-f_{ab}(u)\ (u\ {m odd}),                         \tag{4}
\]
\[
\Lambda_{f_{ab}}(n)=\Lambda(n)\quad(n<2M),                    \tag{5}
\]
并且对任意固定 \(A,C>0\)，一致于长度 \(B_*\) 的所有 \(I\subset(M,2M)\)，
\[
\left|\sum_{m\in I}c_{f_{ab}}(m)\right|
\ll_A B_*(\log M)^{-A},\qquad
\mathbf1_{q\mid m}c_{f_{ab}}(m)=\mathbf1_{q\mid m}c_\mu(m)
\quad(1<q\le(\log M)^C).                                      \tag{6}
\]
然而对每个充分大的 \(M\)，四者中至少一个满足
\[
\boxed{\quad |Q_\beta(f_{ab})|\gg_{\psi,\eta,\beta}
\frac{\delta_M^2}{\log^2M}\gg\frac{H^4}{M}.\quad}       \tag{7}
\]
而且 \(f_{00},f_{10}\) 两者中至少一个满足
\[
\boxed{\quad E(f_{ab})\gg_{\psi,\eta}
\frac{\delta_M^2}{\log^2M}\gg\frac{H^4}{M}.\quad}       \tag{8}
\]
式 (7) 是 \(H^3(\log M)^\beta\) 后的真实位置环带在**这一测试类**中的反例；式 (8) 是完整非负带通门在同一测试类中的反例。两式都不指认 \(\mu\) 为失败者。

## 证明

选固定闭区间 \(J\subset(1,2)\)，其上 \(\varphi\ge c_\psi>0\)。当 \(M\) 足够大，\(h_0/H\in[1,2]\)。在 \(MJ\) 内选出长度为 \(L\) 的完整整数格 \(C\)，要求格内每个实数 \(x\) 满足 \(\cos(2\pi h_0x/M)\ge1/2\)。由于 \(h_0\asymp H\)、一个余弦周期长 \(M/h_0\asymp M/H\)，而 \(L\le M/(32H)\)，每个完整周期都有固定正比例的格符合要求。\(J\) 两端只损失 \(O(M/H)\) 长度，故所选格数 \(\gg_J M/L\)。在这些格中，只使用一条固定全局长度 \(B_*\) 整数网格里完全落入该格的块。因 \(L/B_*\to\infty\)，每个所选格含 \(\gg L/B_*\) 个这样的块。

Matomäki--Shao--Tao--Teräväinen 2023, Theorem 3.1(i) 与其式 (3.11)，按 [scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 式 (6)--(8) 的已核映射，给所有这些长度 \(B_*\) 的块
\(\sum\Lambda(n)=B_*+O_A(B_*(\log M)^{-A})\)：因为 \(71/120>7/12\)，且 \(B_*\ll M^{1-\epsilon}\)。素数幂在整个窗内的总权 \(O(\sqrt M\log M)=o(B_*)\)，故每块至少有 \(B_*/(2\log M)\) 个素数。令
\[
t=\left\lfloor\frac{\delta_M B_*}{100\log M}\right\rfloor.
\tag{9}
\]
则 \(t\to\infty\)，每块任取 \(2t\) 个不同素数，一半放入 \(S_1\)，另一半放入 \(S_2\)。两集不交，并满足
\[
|S_j|\asymp_{\psi}\frac{\delta_M M}{\log M},\qquad
|S_j\cap C|\gg_{\psi}\frac{\delta_M L}{\log M}
\quad\text{对每个所选 }C.                                      \tag{10}
\]
任意长度 \(B_*\) 的区间至多碰到两条全局 \(B_*\) 网格块，因此其中的 \(S_j\) 素数至多 \(2t\) 个。

对 \(a,b\in\{0,1\}\)，在 \(S_1\) 上当 \(a=1\) 时、在 \(S_2\) 上当 \(b=1\) 时，把素数值从 \(-1\) 翻为 \(+1\)；其余素数值均取 \(-1\)，所有素数高次幂值取零，并乘法延拓。这定义 \(f_{ab}\)，立即给 (4)。对 \(n<2M\)，\(f_{ab}-\mu\) 的非零位置只可能是 \(S_1\cup S_2\) 中的素数；在卷积
\((\Lambda_{f_{ab}}-\Lambda)(n)=((f_{ab}-\mu)*\log)(n)\)
里，这种素数 \(p>M\) 若整除 \(n<2M\)，必有 \(n=p\)，而对应因子 \(\log(n/p)=\log1=0\)。故 (5) 严格成立，并由 (2) 得
\[
c_{f_{ab}}(m)=c_\mu(m)-8(\log2)
\bigl(a\mathbf1_{S_1}(m)+b\mathbf1_{S_2}(m)\bigr).       \tag{11}
\]
事实上，这里有一个完整的窗口纤维分类：任意平方自由支撑的乘法 \(f\) 若在 \(n\le M\) 等于 \(\mu\)，则其在 \(n<2M\) 唯一可自由选的值正是 \(M<p<2M\) 的素数值，且**任意**这些值均自动满足 \((f*\log)(n)=\Lambda(n)\) 于 \(n<2M\)。前半句因该范围的合数所有素因子都小于 \(M\)，后半句由上段 \(\log1=0\) 证明。在取值限制 \(f(p)\in\{\pm1\}\) 下，该窗口纤维恰含 \(2^{\#\{p\ {m prime}:M<p<2M\}}\) 个成员。
真实 \(c_\mu\) 的长度 \(B_*\) 短和由同一 2023 定理给任意固定对数幂节省：\(\Lambda-1\) 用上段短素数公式，\(\mu\) 用 Theorem 3.1(i)，偶数项换元后区间长 \(B_*/2+O(1)\) 仍高于 \(x^{7/12+\epsilon}\)（取 \(0<\epsilon<1/120\)），端点误差 \(O(\log M)\)。式 (9)--(11) 的扰动在任意此类区间的总量至多 \(32(\log2)t\ll\delta_M B_*/\log M\)，也小于 \(B_*(\log M)^{-A}\)。被改变的数全是 \(p>M\) 的素数，任何 \(1<q\le(\log M)^C\) 都不能整除它们。于是 (6) 成立。

现在证明环带下界。若 \(|r|\le L\)，\(\eta\ge0\) 且其支撑满足 \(|h|\le4H\)，故 \(|2\pi hr/M|\le\pi/4\)。因此
\[
K_H(r)=\sum_h\eta(h/H)\cos(2\pi hr/M)\gg_\eta H>0.
\tag{12}
\]
在同一个所选 \(L\) 格内，\(S_1\times S_2\) 有 \(\gg\delta_M^2L^2/\log^2M\) 对；对每个 \(p\in S_1\)，其中距离不超过 \(T_\beta\) 的 \(q\in S_2\) 至多 \(2T_\beta+1\) 个。把所有格合并，短差删除量至多 \(O(\delta_M MT_\beta/\log M)\)，而总对数为 \(\gg\delta_M^2ML/\log^2M\)。其比值至多
\[
O\!\left(\frac{T_\beta\log M}{\delta_M L}\right)
=M^{-1/5+o(1)}\longrightarrow0.                         \tag{13}
\]
因此以 \(\mathcal B_\beta(1_{S_1},1_{S_2})\) 表示 (3) 中把两份 \(c_f\) 换成两集合指示函数后的实对称双线性式，有
\[
\mathcal B_\beta(1_{S_1},1_{S_2})
\gg_{\psi,\eta}\frac{H}{M^2}
\frac{\delta_M^2ML}{\log^2M}
\gg_{\psi,\eta}\frac{\delta_M^2}{\log^2M}.             \tag{14}
\]
注意 (12) 使整个环带内所有 \(S_1\times S_2\) 项非负，故限制到同格配对合法。将 (11) 代入二次型，混合二阶差精确为
\[
Q_\beta(f_{11})-Q_\beta(f_{10})-Q_\beta(f_{01})+Q_\beta(f_{00})
=128(\log2)^2\mathcal B_\beta(1_{S_1},1_{S_2}).        \tag{15}
\]
由三角不等式和 (14)，四个 \(|Q_\beta|\) 中至少一个达到 (7) 的首界。

最后只看 \(S_1\)。记
\(G_1(h)=M^{-1}\sum_{p\in S_1}\varphi(p/M)e(-hp/M)\)。因所选格上余弦至少 \(1/2\)，(10) 给
\[
\Re G_1(h_0)\ge\frac{c_\psi|S_1|}{2M}
\gg_\psi\frac{\delta_M}{\log M}.                      \tag{16}
\]
而 \(A_{h_0}(f_{10})-A_{h_0}(f_{00})=-8(\log2)G_1(h_0)\)。故两个复数 \(A_{h_0}(f_{10}),A_{h_0}(f_{00})\) 至少一个模长 \(\gg\delta_M/\log M\)。由于 \(\eta(h_0/H)\ge1\)，相应的 \(E\) 满足 (8) 的首界。

最后 \(H^4/M\asymp M^{-1/5}\)，而 \(\delta_M^2/\log^2M=M^{-o(1)}\)，证明 (7)--(8) 的严格超目标比较。\(\square\)

## 决策边界

该构造精确保留窗口内的 von Mangoldt **数值**与卷积恒等式，且保留完整平方自由支撑、乘法性、真实初始段和全部固定对数幂短和；它比仅调制 \(c(p)\) 的 scratch/903 更强。唯一被更改的基本算术事实是某些高素数的 \(f(p)=-1\)。由此可知，这些窗口内资料的任何组合都不能推出 (7) 所针对的固定幂环带界；证明真实 \(\mu\) 的门必须使用高素数符号 \(\mu(p)=-1\) 与窗外乘法/卷积信息的具体耦合，或其他排除上述翻转的真实算术输入。该陈述不限制一种全新的证明，也不把此反模型解释为真实算术下界。

窗外所需信息可精确定位。若在一个 \(p\in S_1\cup S_2\) 上翻转，则 \(\Lambda_f(2p)-\Lambda(2p)=2\log2\)；因此真实的 \(\Lambda(2p)=0\) 立即排除翻转。但联合观察系数在下一倍数处仍有 scratch/864 的盲性：把 (2) 的 \(c_f\) 公式用于全部整数并记 \(\Delta c=c_f-c_\mu\)，直接计算得
\[
\Delta c(p)=-8\log2,\qquad \Delta c(2p)=0,\qquad
\Delta c(3p)=-8\log(3/2).                                  \tag{17}
\]
其中 \(\Delta c(2p)=0\) 使用 \(\Delta\Lambda_f(2p)=2\log2\)、\(\Delta f(2p)=-2\) 的逐点相消。式 (17) 说明若仅延长同一个联合观察而不单独使用 \(\Lambda(2p)=0\)，首次可见的新倍数是 \(3p\)；这仍不是固定幂协方差估计。

## 补充：全部区间长度的 Ramachandra 型一阶界仍不足

把上文构造的稀疏度 \(\delta_M=e^{-\sqrt{\log M}}\) 改取 \(\delta'_M=e^{-V_M}\)，其中 \(V_M=(\log M/\log\log M)^{1/3}\)，并在式 (9) 中相应取 \(t=\lfloor\delta'_M B_*/(100\log M)\rfloor\)。其余素数格、四个乘法函数及 \(Q_\beta,E\) 的定义不变。记所得函数为 \(f'_{ab}\)；它们仍非真实 \(\mu\)。本补充使用 [note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 已核对的 Ramachandra 短和，以及 [scratch 954](954-every-physical-displacement-band-of-the-true-two-endpoint-coefficient-has-subexponential-cancellation.md) 式 (5) 对真实 \(c_\mu\) 的全长度推论。

固定任意 \(71/120<\vartheta<3/5\)。存在 \(c_\vartheta>0\)，使这四个模型**对每个整数区间** \(I\subset(M,2M)\) 一致满足
\[
\boxed{\quad
\left|\sum_{m\in I}c_{f'_{ab}}(m)\right|
\ll_\vartheta |I|e^{-c_\vartheta V_M}+M^\vartheta.
\quad}\tag{18}
\]
与此同时，四者中至少一个的完整带通能量、四者中至少一个的 \(H^3(\log M)^\beta<|m-n|\le L\) signed Gram 分别满足
\[
\boxed{\quad
E(f'_{ab})\gg\frac{e^{-2V_M}}{\log^2M}
\gg\frac{H^4}{M},\qquad
|Q_\beta(f'_{ab})|\gg_\beta\frac{e^{-2V_M}}{\log^2M}
\gg\frac{H^4}{M}.
\quad}\tag{19}
\]
两式见证函数可以不同。它们还保留本稿式 (4)--(5) 的平方自由乘法性、真实初始段及整个物理窗口内的 \(f'*\log=\Lambda\)。因此**Ramachandra 形式的全长度一阶估计，加上这些窗口内的真实结构，仍不能作为统一测试类上的固定幂二点门**；这不判定 \(f'_{00}=\mu\) 的真实能量。

证明 (18)。原文的素数格计数只要求 \(\delta'_M=o(1)\) 且 \(t\to\infty\)，两者由 \(B_*=M^{71/120+o(1)}\) 成立。每个全局长度 \(B_*\) 网格块在每一集合 \(S_j'\) 中至多含 \(t\) 个被选素数；任意长度 \(|I|\) 的区间最多与 \(\lfloor|I|/B_*\rfloor+2\) 个块相交。因此由原式 (11)，
\[
\left|\sum_{m\in I}(c_{f'_{ab}}(m)-c_\mu(m))\right|
\ll (|I|/B_*+2)t
\ll \frac{\delta'_M}{\log M}(|I|+B_*).
\tag{20}
\]
note 851 式 (4) 同时用于 \(\Lambda-1\)、\(\mu\) 和偶数换元，正如 scratch 954 式 (5)，给真实 \(c_\mu\) 的全区间界 \(O(|I|e^{-c_0V_M}+M^\vartheta)\)，其中 \(c_0>0\) 固定。取 \(0<c_\vartheta<\min(c_0,1)\)；式 (20) 的 \(|I|\) 项被 \(|I|e^{-c_\vartheta V_M}\) 吸收，而 \(\delta'_MB_*/\log M\le B_*\le M^\vartheta\) 对充分大 \(M\) 成立。相加即得 (18)。

证明 (19)。原式 (10) 的选择计数现在给 \(|S_j'|\asymp\delta'_M M/\log M\) 及每个所选 \(L\) 格内 \(|S_j'\cap C|\gg\delta'_ML/\log M\)；素数储量仍够，因为 \(\delta'_M=o(1)\)。原式 (13) 删除短差配对的比例变为
\[
O\!\left(\frac{T_\beta\log M}{\delta'_M L}\right)
=M^{-1/5+o(1)}\longrightarrow0,
\]
因为 \(H\asymp M^{1/5}\)、\(T_\beta=H^3(\log M)^\beta\)、\(L\asymp M^{4/5}\) 且 \(e^{V_M}=M^{o(1)}\)。原式 (14)--(16) 的同一正核双线性与四模型二阶差给 \(Q_\beta\) 下界 \((\delta'_M)^2/\log^2M\)；原式 (16) 的单频相干及两模型一阶差给 \(E\) 下界。最后 \(H^4/M=M^{-1/5+o(1)}\)，而 \(e^{-2V_M}/\log^2M=M^{-o(1)}\)，故两个严格超目标比较成立。\(\square\)
