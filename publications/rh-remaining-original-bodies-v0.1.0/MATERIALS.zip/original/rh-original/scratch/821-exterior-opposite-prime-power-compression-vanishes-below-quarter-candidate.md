# 薄分母外槽的全部异臂高次素数幂算子范数趋零（候选）

日期：2026-09-29。承接 [scratch 818](818-polynomial-exterior-farey-compression-is-a-signed-near-resonance-matrix-candidate.md) 的异臂近共振矩阵与 [scratch 820](820-exact-opposite-arm-exterior-resonances-have-vanishing-operator-norm-candidate.md) 的精确共振排除。这里用同余根数对增长的移位区间作算子范数估计；当分母指数小于 \(1/4\) 时，全部异臂高次素数幂项消失。真正的素数平移仍未估计。尚缺异源独立复核，留在 scratch。

## 命题

令 \(p\to\infty\) 沿奇素数，固定 \(0<\beta<1/2\)，取 \(B=\lfloor p^\beta\rfloor\) 和
\[
\mathcal Y_{p,B}
=\{m/b:2\le b\le B,\ p\le m<bp,\ (m,b)=1\}.
\]
令 \(1\le D\le B^2\) 为整数，可随 \(p\) 增长。把 scratch 818 式 (4) 的异臂矩阵中满足
\[
\delta=n b b'-m m',\qquad 1\le|\delta|\le D,
\qquad n=\ell^j,\quad \ell\text{ 为素数},\quad j\ge2
\tag{1}
\]
的条目之和记为 \(N^{\rm pp}_{\le D}\)，保留原重叠权 \(R_\Delta(|\log(n/(yy'))|)\)。对任意固定整数 \(J\ge2\) 和任意 \(\varepsilon>0\)，
\[
\boxed{\ 
\|N^{\rm pp}_{\le D}\|_{\rm op}
\ll_{J,\varepsilon}
(\log p)B^2Dp^{-1+\varepsilon}
+(\log p)^2B^2Dp^{-1+2/J}.
\ }
\tag{2}
\]
特别地，固定 \(0<\kappa<1-2\beta\) 并取 \(D\le\min(B^2,p^\kappa)\)，先取 \(J\) 使 \(2/J<1-2\beta-\kappa\)，再取充分小的 \(\varepsilon\)，便有
\[
\boxed{\ \|N^{\rm pp}_{\le D}\|_{\rm op}=o(1).\ }
\tag{3}
\]
若 \(\beta<1/4\)，可直接取 \(D=B^2\)：因为 \(B^2=p^{2\beta+o(1)}\) 且 \(4\beta<1\)，(2) 支付**全部非零异臂高次素数幂移位**。再加 scratch 820 的 \(\delta=0\) 部分，得到
\[
\boxed{\ \|N^{\rm opp,pp}_{p,B}\|_{\rm op}=o(1)
\qquad (0<\beta<1/4),\ }
\tag{4}
\]
其中 \(N^{\rm opp,pp}\) 是 scratch 818 的 \(N^{\rm opp}\) 中平移指标 \(n=\ell^j,\ j\ge2\) 的完整部分。

特别地，对 [scratch 819](819-exterior-farey-forcing-has-an-exact-prime-divisor-norm-asymptotic-candidate.md) 的实际 forcing \(t\)，在 \(\beta<1/4\) 时
\[
\langle t,N^{\rm opp,pp}_{p,B}t\rangle=o((\log p)^4).
\tag{5}
\]
因此这一薄分母区的任何 \((\log p)^5\) 级异臂贡献只能来自平移指标 \(n\) 本身为素数的项。

一个具体的非空参数点是 \((\alpha,\beta)=(2/3,1/8)\)。scratch 819 的常数在此为
\[
J_{\rm diag}=\frac{17}{4608},\qquad
J_{\rm pair}=\frac{11}{32768},\qquad
\frac{\|P_ZA_{p^2,-}v_{p,2/3}\|}{(\log p)\|v_{p,2/3}\|}
\longrightarrow\frac{\sqrt{1187}}{256}>0.
\]
同时 (4) 删除全部异臂高次素数幂平移。此组合仍只给交叉块范数和算术压缩的一部分；素数平移作用在实际 \(t\) 上的有符号二次型未定。

更贴近 scratch 819 的 \(\beta=1/4\) 实例：对任意 \(\eta>0\)，可先选一个固定 \(\beta<1/4\) 足够接近 \(1/4\)，使
\[
\lim_{p\to\infty}
\frac{\|P_ZA_{p^2,-}v_{p,2/3}\|}
{(\log p)\|v_{p,2/3}\|}
\ge \frac{\sqrt{307}}{64}-\eta,
\qquad
\|N^{\rm opp,pp}_{p,B}\|_{\rm op}\longrightarrow0.
\]
这里先固定 \(\beta\) 再令 \(p\to\infty\)；并未取得 \(\beta=1/4\) 端点的素数幂算子界。

## 证明

固定一行 \(y=m/b\)。若 (1) 有解，则
\[
\ell^j b b'-m m'=\delta.
\tag{A1}
\]
置 \(d=(m,bb')\)。式 (A1) 迫使 \(d\mid\delta\)，故 \(d\le D\)。除以 \(d\)，并用 \((bb'/d,m/d)=1\)，得到
\[
\ell^j\equiv (\delta/d)(bb'/d)^{-1}\pmod{M},
\qquad M=m/d.
\tag{A2}
\]
右侧与 \(M\) 的最大公因数至多 \(|\delta|/d\)。

先固定指数 \(j\)。若右侧 \(u\) 是模素数幂 \(\lambda^a\mid M\) 的单位，则 \(x^j=u\) 至多有 \(2j\) 个根：奇素数幂的单位群为循环群，模 \(2\) 的幂多出至多一个阶为 \(2\) 的因子。若 \(u\) 非单位但 \(v_\lambda(u)<a\)，则 \(\lambda\mid\delta\)，且 \(v_\lambda(u)\le v_\lambda(\delta)\)；任一根 \(x\) 满足 \(jv_\lambda(x)=v_\lambda(u)\)。除去这一共同素数幂后得到单位方程，它的每个根至多有 \(\lambda^{v_\lambda(u)}\) 个提升。若 \(u\equiv0\pmod{\lambda^a}\)，则 \(\lambda^a\mid\delta\)，根数也至多 \(\lambda^a\)。把这些坏素数处的因子相乘，代价至多 \((u,M)\le|\delta|/d\)。中国剩余定理遂给 (A2) 至多
\[
(\delta/d,M)(2j)^{\omega(M)}
\ll_{j,\varepsilon}(\delta/d,M)p^\varepsilon
\tag{A3}
\]
个模 \(M\) 的根类，末步使用固定 \(j\) 的标准除数界及 \(M\le m<Bp\)。

重叠几何有 \(n<p^2+1\)，故
\[
2\le\ell\le p^{2/j}\le p,\qquad M=m/d\ge p/D.
\tag{A4}
\]
每个模 \(M\) 的根类在 \([2,p]\) 中至多出现 \(d+1\le2d\) 次，因为 \(p/M\le d\)。固定 \(b',j\) 后，\(d\) 也固定，允许的移位只能写成 \(\delta=dh\)，\(1\le|h|\le D/d\)。利用 \(\gcd(h,M)=\sum_{e\mid(h,M)}\varphi(e)\)，有
\[
\sum_{1\le|h|\le X}(h,M)
\le2X\sum_{e\mid M}\frac{\varphi(e)}e
\le2X\tau(M).
\]
所以把 (A3) 的根类数、每类的至多 \(2d\) 次出现和全部移位一起求和，对固定 \(b',j\) 至多有 \(O_j(D(2j)^{\omega(M)}\tau(M))=O_{j,\varepsilon}(Dp^\varepsilon)\) 个底数 \(\ell\)。一旦 \(\ell,j,b',\delta\) 固定，(A1) 唯一确定 \(m'\)。对 \(2\le j\le J\) 和 \(b'\le B\) 求和，每行至多 \(O_{J,\varepsilon}(BDp^\varepsilon)\) 个候选条目。

对 \(j>J\)，不使用同余根数：这样的 \(j\) 共有 \(O(\log p)\) 个，每个 \(j\) 的底数至多 \(p^{2/j}\le p^{2/J}\)。高指数部分每行至多 \(O(BD(\log p)p^{2/J})\) 个候选条目。

任一实际重叠项满足
\[
n=\frac{mm'+\delta}{bb'}\gg\frac{p^2}{B^2},
\]
因而
\[
\left|\frac{\Lambda(n)}{\sqrt n}
R_\Delta\!\left(\left|\log\frac{n}{yy'}\right|\right)\right|
\ll\frac{B\log p}{p},
\tag{A5}
\]
其中 \(|R_\Delta|\le1\)，且 \(D\le B^2=o(p^2)\)。将两部分候选数乘 (A5)，得到每行绝对和的 (2)。矩阵实对称，列和同界；Schur 行列和检验完成证明。scratch 819 给 \(\|t\|^2=O((\log p)^4)\)，所以 (5) 也成立。\(\square\)

## 边界

固定行的素数平移对应 \(n b b'\equiv\delta\pmod m\)，其指标 \(n\) 可达 \(p^2\)；一个模 \(m/d\) 的根类可容纳约 \(p\) 个候选，故上面的短区间根数方法不支付素数项。若 \(\beta\ge1/4\)，(2) 不支付全部 \(|\delta|<B^2\) 的高次素数幂。真实 forcing 上的异臂有符号下界、Schur 补、moving-\(N\) Möbius 协方差与 RH 仍未解决。
