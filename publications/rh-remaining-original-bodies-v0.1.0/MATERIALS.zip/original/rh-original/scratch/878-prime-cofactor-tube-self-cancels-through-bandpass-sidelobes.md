# 素数 cofactor 管的近块与远块在真实高除数门中自我抵消

日期：2026-10-01。依赖 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 的真实源系数及式 (8)--(12) 的逐项绝对过滤预算、[scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的带通核、[scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 式 (6)--(7) 所核对的 Matomäki--Shao--Tao--Teräväinen 2023 全区间短和定理，以及 [scratch/877](877-doubled-prime-physical-rows-cancel-in-the-true-high-divisor-gram.md) 式 (2a) 的一大素因子系数。本文把单素数物理块扩成 \(H^{1/2}<q\le H\) 的真实 \(pq\) 行：原始过滤门中的近距离子块有常数量级正值，但这批行自身的较远距离项已给出等量负值。式 (23)--(27) 进一步核对源项过滤，并将顶端带的对数级抵消定位在四个互异素因子之间。该结论尚无异源复核；它不是固定幂协方差上界，也不证明全尺度局部 Weil 正性或 RH。

## 定理

令 \(M=2Y\)、\(Y^{1/5}\le H\le Y^{1/4}\)，固定 \(s>1\) 和非负非零的实函数 \(\psi\in C_c^3((1,2))\)，置 \(\phi(t)=\psi(t)/t\)。沿用 scratch/859--860 的 \(D,R,K_0,w_H,J_H,K=K_{s,2}\)。选闭区间 \(J\subset(1,2)\)，使 \(\phi\ge c_\psi>0\) 于 \(J\)，并令
\[
L=\left\lfloor\frac{M}{32H}\right\rfloor,\qquad
\mathcal T_{M,H}(J)=
\{m=pq\in MJ:p,q\text{ 为素数},\ H^{1/2}<q\le H\}.
\tag{1}
\]
在 scratch/859 式 (12) 的**原始有序剩余门**中，只取 \(m,n\in\mathcal T_{M,H}(J)\) 且 \(K_0<|m-n|\le L\) 的全部源项，记其 signed 和为 \(\mathfrak P_{M,H}^{\rm tube}\)。则存在只依赖 \(s,\psi,J\) 的 \(c>0\)，使
\[
\boxed{\qquad \mathfrak P_{M,H}^{\rm tube}\ge c
\qquad(M\text{ 充分大}) .\qquad}
\tag{2}
\]
再令 \(\mathfrak T_{M,H}^{\rm tube}\) 为同一原始剩余门中 \(m,n\in\mathcal T_{M,H}(J)\) 的**全部**项。则在整个给定 \(H\) 范围内
\[
\boxed{\qquad
\mathfrak T_{M,H}^{\rm tube}=o(1),\qquad
\mathfrak T_{M,H}^{\rm tube}-\mathfrak P_{M,H}^{\rm tube}
=-\mathfrak P_{M,H}^{\rm tube}+o(1)\le-c+o(1).
\qquad}
\tag{3}
\]
因此这条正块的首阶负补偿已在同一素数 cofactor 物理类中发生。若 \(\mathfrak S_{M,H}^{(s)}\) 是整个原始剩余门，已有 scratch/862 与过滤预算另外给出 \(\mathfrak S_{M,H}^{(s)}=o(1)\)。上述两个 \(o(1)\) 都不达到低于四分之一次幂的固定幂目标 \(H^4/M\)。

## 证明

正块只需要固定比例区间的素数定理，不需要短区间素数估计。写 \(J=[a,b]\)。对每个 \(H^{1/2}<q\le H\)，素数 \(p\) 落在 \((aM/q,bM/q)\)。由于 \(M/q\ge M/H\gg M^{3/4}\)，素数定理的相对误差对所有这些 \(q\) 一致趋于零，故
\[
\#\{p\text{ 素数}:pq\in MJ\}
=(1+o_J(1))\frac{(b-a)M}{q\log(M/q)}.
\tag{4}
\]
这里 \(p>M/q\gg H\ge q\)，所以每个 \(m=pq\) 在 (1) 中只计一次。素数调和和的 Mertens 推论给
\[
\sum_{\substack{H^{1/2}<q\le H\\q\text{ 素数}}}\frac1q
=\log2+o(1),\qquad
\frac{\log H}{\log M}\ge\frac15+o(1).
\tag{5}
\]

对 \(m=pq\in\mathcal T_{M,H}(J)\)，scratch/877 式 (2a) 给出真实高除数物理系数
\[
a_D(pq)=\frac{4\log(q/2)}M\,\phi(pq/M)>0.
\tag{6}
\]
令 \(S=\sum_{m\in\mathcal T_{M,H}(J)}a_D(m)\)。由 (4)--(6) 及 \(\phi\ge c_\psi\)，
\[
\begin{aligned}
S
&\ge c_\psi(b-a)(1-o(1))
\sum_{\substack{H^{1/2}<q\le H\\q\text{ 素数}}}
\frac{4\log(q/2)}{q\log(M/q)}\\
&\ge c_\psi(b-a)(1-o(1))
\frac{2\log H-4\log2}{\log M}
\sum_{\substack{H^{1/2}<q\le H\\q\text{ 素数}}}\frac1q
\gg_{\psi,J}1.
\end{aligned}
\tag{7}
\]
把 \(MJ\) 划成长度 \(L\) 的完整整数盒 \(I\)，记 \(S_I=\sum_{m\in\mathcal T_{M,H}(J)\cap I}a_D(m)\)。两端不足 \(L\) 的边界段至多含 \(2L+O(1)\) 个整数，且由 (6) 每个 \(a_D(m)\ll_\psi\log H/M\)，故其总质量 \(O_\psi(L\log H/M)=o(1)\)。所以 \(\sum_{I\text{ 完整盒}}S_I\gg_{\psi,J}1\)。

当 \(|m-n|\le L\)，scratch/861 式 (5) 的同一支撑角度计算给
\[
J_H(m-n)
=\sum_hw_H(h)\cos(2\pi h(m-n)/M)
\ge2^{-1/2}\sum_hw_H(h)\gg_s H.
\tag{8}
\]
设 \(\mathfrak U\) 为 \(m,n\in\mathcal T_{M,H}(J)\)、\(|m-n|\le L\) 的**未过滤**物理 Gram；它先对每个物理点合并所有高除数源，故其系数为 \(a_D(m)a_D(n)\)。式 (6)、(8) 使各项非负。完整盒数 \(T_J\asymp_J M/L\asymp_J H\)，且同盒两点相距不超过 \(L\)；由 Cauchy--Schwarz，
\[
\mathfrak U
\ge c_sH\sum_{I\text{ 完整盒}}S_I^2
\ge c_sH\,\frac{\bigl(\sum_I S_I\bigr)^2}{T_J}
\gg_{s,\psi,J}1.
\tag{9}
\]

将 \(\mathfrak U\) 恢复成原始剩余门。删去 \(|m-n|\le K_0\) 的源项，及源指标 \(d=e\)、\(d\mid e\) 或 \(e\mid d\)、最大约化比例不超过 \(R\) 的源项。scratch/859 式 (8)、(8a)、(8b)、(10) 的证明逐项取绝对值，因此限制到当前物理子族只会减小其总预算；它们合计为
\[
O_{s,\psi}\!\left(
\frac{H^2\log^3(2M)}M+
\frac{H^4}{M\log^2(2M)}
\right)=o(1).
\tag{10}
\]
又 \(K_0<L<K_{s,2}\) 对充分大 \(M\) 成立，故没有额外远差。式 (9)--(10) 证明 (2)。

为判明 (2) 的补偿来自何处，只取同一物理类的完整带通能量。记
\[
c_q=4\log(q/2),\qquad
\kappa_M=\sum_{\substack{H^{1/2}<q\le H\\q\text{ 素数}}}
\frac{c_q}{q\log(M/q)}\asymp1,\qquad
\eta(t)=\phi(t)\mathbf1_J(t).
\tag{11}
\]
把 \((M,2M)\) 按模 \(M\) 周期化；令
\(f_M(m)=M a_D(m)\mathbf1_{m\in\mathcal T_{M,H}(J)}\)，
\(g_M(m)=\kappa_M\eta(m/M)\)。当长度 \(L\) 的整数窗 \(I\) 完全在 \(MJ\) 内时，对每个 \(q\) 的素数 \(p\) 窗长 \(T=L/q+O(1)\)、位置 \(x\asymp_J M/q\)。取 \(\epsilon=1/20\)，在全部 \(q\le H\) 上
\[
\frac{T}{x^{7/12+\epsilon}}\gg_J M^{1/40},
\qquad
\frac{T}{x^{1-\epsilon}}\ll_J M^{-3/20}.
\tag{12}
\]
故 scratch/862 式 (7) 的全区间定理适用。素数幂的 \(\Lambda\) 权至多 \(O(\sqrt x\log^2x)\)，而 \(T/\sqrt x\gg M^{1/8}\)；又该窗内 \(\log p=\log(M/q)+O_J(1)\)。于是素数计数一致满足
\[
\#\{p\text{ 素数}:qp\in I\}
=\frac{L}{q\log(M/q)}
+O_J\!\left(\frac{L}{q\log^2M}\right).
\tag{13}
\]
在窗内以任一点冻结 Lipschitz 函数 \(\phi(m/M)\)，其振幅误差为 \(O_\psi(L/M)=O_\psi(H^{-1})\)。用 (13) 对 \(q\) 求和，并用 \(\sum_{H^{1/2}<q\le H,\ q\text{ 素数}}c_q/q\ll\log H\)，得
\[
\left|\sum_{m\in I}(f_M(m)-g_M(m))\right|
\ll_{\psi,J}\frac L{\log M}
\qquad(I\subset MJ,\ |I|=L).
\tag{14}
\]
对与 \(MJ\) 不相交的窗，两和均为零。只有 \(O(L)\) 个循环窗跨越 \(J\) 的两个端点；由于 \(|f_M(m)|\ll_\psi\log H\)、\(|g_M(m)|\ll_\psi1\)，这些窗各有平凡界 \(O_\psi(L\log H)\)。\(J\) 离周期接缝有固定距离，故接缝没有额外边界窗。

设 \(F_h=M^{-1}\sum_m f_M(m)e(-hm/M)\)、\(G_h=M^{-1}\sum_m g_M(m)e(-hm/M)\)，以及 \(V_h=\sum_{j=0}^{L-1}e(-hj/M)\)。在 \(w_H(h)\ne0\) 时 \(|V_h|\gg L\)。对窗和用周期 Parseval，并分别计入普通窗及边界窗，得到
\[
\sum_hw_H(h)|F_h-G_h|^2
\ll\frac M{L^2}
\left[
M\left(\frac L{M\log M}\right)^2
+L\left(\frac{L\log H}{M}\right)^2
\right]
\ll\frac1{\log^2M}+\frac{\log^2H}{H}.
\tag{15}
\]
\(\eta\) 是固定的有界变差函数，而 \(\kappa_M=O(1)\)；离散分部求和给 \(|G_h|\ll_{\psi,J}|h|^{-1}\)（\(1\le|h|\le4H\)），故 \(\sum_hw_H(h)|G_h|^2\ll H^{-1}\)。由 (15)，同一素数 cofactor 管的完整物理 Gram 满足
\[
\sum_hw_H(h)|F_h|^2
\ll_{s,\psi,J}\frac1{\log^2M}+\frac{\log^2H}{H}
=o(1).
\tag{16}
\]
由 scratch/859 式 (8)、(8a)、(8b)、(10) 与 scratch/860 式 (3)，把 (16) 的完整物理 Gram 限成原始剩余门内 \(m,n\in\mathcal T_{M,H}(J)\) 的全部项，只产生式 (10) 加 \(O(M^{-2})\) 的误差。因此 \(\mathfrak T_{M,H}^{\rm tube}=o(1)\)，扣去 (2) 即得 (3)。此外，未过滤物理 Gram 的 \(|m-n|>L\) 部分等于 (16) 减去 (9)，故至多为 \(-c+o(1)\)；由 (6) 所有物理系数为正，这个首阶负值来自 \(J_H\) 的负瓣。\(\square\)

## 同一素数 cofactor 的目标量级

在 (1) 中改取 \(H/2<q\le H\)，并仅保留原始剩余门里物理点 \(m=pq,n=p'q\) 有**同一个**素数 cofactor \(q\) 的全部有序源项，记其 signed 和为 \(\mathfrak D_{M,H}\)。则无条件地
\[
\boxed{\qquad
|\mathfrak D_{M,H}|\ll_{s,\psi,J}\frac{H^4}{M}.
\qquad}
\tag{17}
\]
这是真实已过滤门的一块目标上界；它没有控制不同 \(q\) 之间或该族与其他物理行之间的交叉。

证明时先不施加原门的源指标与距离过滤。固定 \(q\) 后令
\[
F_{q,h}=\frac{4\log(q/2)}M
\sum_{\substack{p\text{ 素数}\\pq\in MJ}}
\phi(pq/M)e(-hpq/M),\qquad
E_q=\sum_hw_H(h)|F_{q,h}|^2.
\tag{18}
\]
式 (6) 说明 \(E_q\) 正是该 \(q\) 的完整高除数物理 Gram。由 scratch/868 式 (6) 的非别名核行和、\(|J_H(0)|\ll_s H\ll M/q\)，以及固定比例区间素数定理的 \(\#\{p:pq\in MJ\}\ll_J M/(q\log(M/q))\)，
\[
\begin{aligned}
E_q
&\le\frac{16\log^2(q/2)\|\phi\|_\infty^2}{M^2}
\#\{p:pq\in MJ\}
\sum_{\substack{k\in\mathbb Z\\|qk|\le |J|M}}|J_H(qk)|\\
&\ll_{s,\psi,J}\frac{\log^2(q/2)}{q^2\log(M/q)}.
\end{aligned}
\tag{19}
\]
这里 \(|J|=b-a<1\)，scratch/868 式 (6) 的同一证明可取非别名裕量 \(1-|J|>0\)。对 \(H/2<q\le H\) 的素数求和，使用 \(\#\{q\text{ 素数}:H/2<q\le H\}\ll H/\log H\)、\(\log(M/q)\asymp\log M\)，得到
\[
\sum_{\substack{H/2<q\le H\\q\text{ 素数}}}E_q
\ll_{s,\psi,J}
\frac{\log^2H}{H\log H\log M}
\ll\frac1H
\ll\frac{H^4}{M}.
\tag{20}
\]
最后一个不等式用 \(H^5\ge Y=M/2\)。从每个完整 \(E_q\) 删去原门排除的源项及物理近差、远差时，scratch/859 式 (8)、(8a)、(8b)、(10) 和 scratch/860 式 (3) 的**全局逐项绝对预算**仍适用；总误差为
\[
O_{s,\psi}\!\left(
\frac{H^2\log^3(2M)}M+
\frac{H^4}{M\log^2(2M)}+M^{-2}
\right)
=O_{s,\psi}(H^4/M).
\tag{21}
\]
于是 \(\mathfrak D_{M,H}\) 与非负的 \(\sum_qE_q\) 相差至多 (21)，由 (20) 得 (17)。\(\square\)

同一论证给出斜向 cofactor 截止。对任意 \(3\le Q\le H\)，令 \(\mathfrak D_{M,H}(Q)\) 为原门中 \(m=pq,n=p'q\)、同一素数 \(Q<q\le H\) 的全部有序源项。由 (19)、\(\log(M/q)\asymp\log M\) 与素数上界 \(\pi(x)\ll x/\log x\)，分 dyadic \(q\) 带求和得
\[
\sum_{\substack{Q<q\le H\\q\text{ 素数}}}E_q
\ll_{\psi,J}\frac{1+\log Q}{Q\log M}.
\]
因此仍用 (21) 的全局过滤预算，
\[
\boxed{\quad
|\mathfrak D_{M,H}(Q)|
\ll_{s,\psi,J}
\frac{1+\log Q}{Q\log M}
+\frac{H^2\log^3(2M)}M
+\frac{H^4}{M\log^2(2M)}+M^{-2}.
\quad}\tag{22}
\]
特别地，若 \(Q\ge cM/H^4\) 且 \(Q\le H\)，其中 \(c>0\) 固定，则 (22) 为 \(O_{c,s,\psi,J}(H^4/M)\)。当 \(Q=H/2\) 时，由 \(H^5\ge M/2\) 也恢复 (17)。

## 四个互异素因子的原门恒等式

令 \(q,r\) 为不同奇素数且 \(q,r\le H\)，\(p,p'\) 为不同素数，\(m=pq,n=p'r\in MJ\)，并设 \(K_0<|m-n|\le K\)。由于 \(p,p'>M/H\gg H\)，这四个素数互异且 \((m,n)=1\)。两侧非零高除数源分别恰为
\[
d\in\{p,pq\},\qquad e\in\{p',p'r\}.
\]
任意这四对 \((d,e)\) 都有 \((d,e)=1\)、\(d\nmid e\)、\(e\nmid d\)，且
\(\max(d,e)\ge\min(p,p')>M/H>R\) 对充分大 \(M\) 成立。因此原门的源指标过滤**逐对完整保留**它们；固定该物理配对的真实 signed 源和精确等于
\[
\begin{array}{c|cc}
\text{物理点}&\text{cofactor 为奇素数的源}&\text{cofactor 为 }1\text{ 的源}\\ \hline
pq&\mu(p)b_p(pq)=4\log q\,\phi(m/M)/M
&\mu(pq)b_{pq}(pq)=-4\log2\,\phi(m/M)/M\\
p'r&\mu(p')b_{p'}(p'r)=4\log r\,\phi(n/M)/M
&\mu(p'r)b_{p'r}(p'r)=-4\log2\,\phi(n/M)/M
\end{array}
\]
其乘积展开正是四组被保留的源项，故
\[
\boxed{\quad
\sum_{\substack{d\mid m,\ e\mid n\\d,e>D\\
d\nmid e,\ e\nmid d,\ \max(d/(d,e),e/(d,e))>R}}
\mu(d)\mu(e)b_d(m)b_e(n)J_H(m-n)
=\frac{16\log(q/2)\log(r/2)}{M^2}
\phi(m/M)\phi(n/M)J_H(m-n).
\quad}\tag{23}
\]
这没有给 (23) 的四素数总和固定幂上界。它说明这一互素子族的源内 Möbius 符号已被完全合并；余下的符号来自 \(J_H(m-n)\)，其估计需要对 \(pq-p'r\) 的真实素数配对分布作控制。共享 \(p\) 的 \(q\ne r\) 配对有物理 gcd \(p>H\)，已由 scratch/868 式 (3) 在目标幂次内绝对支付；同 \(q\) 的上层由 (17)--(22) 支付。

## 顶端 cofactor 带的四素数交叉独自完成对数级抵消

式 (23) 可以进一步定位到一个 dyadic 素数带。令
\[
\mathcal Q=\{q\text{ 素数}:H/2<q\le H\},\qquad
\mathcal T^\top=\{pq\in MJ:p,q\text{ 素数},\ q\in\mathcal Q\}.
\]
在此物理类上仍以 (6) 定义 \(a_D(pq)\)，记其未过滤完整带通能量为
\[
\mathcal E^\top=\sum_h w_H(h)
\left|\sum_{m\in\mathcal T^\top}a_D(m)e(-hm/M)\right|^2\ge0.
\tag{24}
\]
令 \(\mathfrak C_4\) 是 (23) 在 \(q,r\in\mathcal Q\)、\(q\ne r\)、\(p\ne p'\) 及原门距离 \(K_0<|pq-p'r|\le K\) 上的全部有序和，\(\mathfrak P_4\) 是其中再限制 \(|pq-p'r|\le L\) 的和。则一致于 \(Y^{1/5}\le H\le Y^{1/4}\)，有
\[
\boxed{\quad
\mathcal E^\top\ll_{s,\psi,J}\frac1{\log^4M}+\frac{\log^2H}{H},
\qquad
\mathfrak P_4\gg_{s,\psi,J}\frac1{\log^2M}.
\quad}\tag{25}
\]
并且
\[
\boxed{\quad
|\mathfrak C_4-\mathcal E^\top|
\ll_{s,\psi,J}
\frac1H+\frac{H\log^2H}{M}
+\frac{H^4}{M\log^7(2M)}+M^{-2}
\ll_{s,\psi,J}\frac{H^4}{M}.
\quad}\tag{26}
\]
因而 \(\mathfrak C_4=o(\log^{-2}M)\)，而
\[
\boxed{\quad
\mathfrak C_4-\mathfrak P_4
=-\mathfrak P_4+o(\log^{-2}M)
\le-\frac{c}{\log^2M}
\quad}\tag{27}
\]
对某个 \(c=c(s,\psi,J)>0\) 及充分大 \(M\) 成立。式 (27) 的负号全部来自同一四素数族中 \(J_H(pq-p'r)\) 的远距离负瓣。另一方面，(26) 与 \(\mathcal E^\top\ge0\) 还给 \(\mathfrak C_4\ge-O(H^4/M)\)；四素数交叉的目标**上界**与 (24) 的目标上界等价，但两者都没有在这里得到证明。

证明 (25) 的能量界时，复用 (11)--(15) 的窗方法，但只对 \(q\in\mathcal Q\) 求和。素数调和估计给
\[
\sum_{q\in\mathcal Q}\frac1q\ll\frac1{\log H},\qquad
\sum_{q\in\mathcal Q}\frac{c_q}{q}\ll1,\qquad
\kappa_M^\top:=\sum_{q\in\mathcal Q}
\frac{c_q}{q\log(M/q)}\ll\frac1{\log M}.
\tag{28}
\]
在每个完全处于 \(MJ\) 的长度 \(L\) 窗上，(13) 的计数误差乘 \(c_q\) 后合计为 \(O(L/\log^2M)\)，因为本带的 \(\sum c_q/q\) 有界。冻结 \(\phi\) 与其模型 \(\kappa_M^\top\eta\) 只增加 \(O_\psi(L/(H\log M))\)。因此 (14) 在本带加强为
\[
\left|\sum_{m\in I}\bigl(f_M^\top(m)
-\kappa_M^\top\eta(m/M)\bigr)\right|
\ll_{\psi,J}\frac{L}{\log^2M},
\tag{29}
\]
其中 \(f_M^\top(m)=Ma_D(m)\mathbf1_{m\in\mathcal T^\top}\)。跨 \(J\) 端点的 \(O(L)\) 个循环窗仍用 \(O_\psi(L\log H)\) 平凡界。(15) 的周期 Parseval 由此给残差能量
\(O_{s,\psi,J}(\log^{-4}M+\log^2H/H)\)。模型的 BV Fourier 系数由 (28) 至多为 \(O((|h|\log M)^{-1})\)，频带能量为 \(O((H\log^2M)^{-1})\)。这证明 (25) 第一式。

再由 (4) 及素数调和式的 dyadic 渐近
\(\sum_{q\in\mathcal Q}q^{-1}\sim(\log2)/\log H\)，本带的总正质量满足
\[
S^\top:=\sum_{m\in\mathcal T^\top}a_D(m)
\asymp_{\psi,J}\frac1{\log M}.
\tag{30}
\]
长度 \(L\) 的两端残盒总质量为 \(O_\psi(L\log H/M)=o(\log^{-1}M)\)。于是 (8)--(9) 的同盒 Cauchy--Schwarz 对 \(\mathcal T^\top\) 给 \(|m-n|\le L\) 的未过滤正 Gram \(\gg\log^{-2}M\)。从中删除同 \(q\) 的物理配对，(19)--(20) 的**绝对行和证明**给成本 \(O(1/H)\)。共享 \(p\)、不同 \(q\) 的两点相距至少 \(p>M/H>L\)，所以近块中根本没有这类配对。比较完整能量时仍需支付它们：此时 \(p\asymp_J M/H\)，scratch/860 式 (9) 在 \(|p(q-r)|<(b-a)M\) 的非别名范围给
\[
\sum_{\substack{k\in\mathbb Z\setminus\{0\}\\|pk|\le(b-a)M}}
|J_H(pk)|\ll_{s,J}H.
\]
对至多 \(O_J(M/H)\) 个整数 \(p\) 和每个 \(p\) 的至多 \(H\) 个 \(q\) 过计，\(|a_D(pq)|\ll_\psi\log H/M\) 使共享 \(p\) 的绝对成本至多 \(O_{s,\psi,J}(H\log^2H/M)\)。

最后，(4) 与 \(q\in\mathcal Q\) 给 \(\#\mathcal T^\top\ll_J M/\log^2M\)。因此即使每个 \(m\) 附近的所有整数都当作候选，\(|m-n|\le K_0\) 的完整物理绝对质量也至多
\[
\#\mathcal T^\top(2K_0+1)
\left(\frac{C_\psi\log H}{M}\right)^2\!\sup_r|J_H(r)|
\ll_{s,\psi,J}\frac{H(K_0+1)}M
\ll\frac{H^4}{M\log^7(2M)}.
\tag{31}
\]
上述三个删除成本均为 \(o(\log^{-2}M)\)，且 \(K_0<L<K\)，所以 (23) 逐对保留的四素数近块给 (25) 第二式。比较 (24) 与 \(\mathfrak C_4\) 时，遗漏项恰由同 \(q\)、共享 \(p\)、(31) 的近差及 scratch/860 式 (3) 的 \(|m-n|>K\) 远差构成；分别取绝对值得 (26)。由于 \(H^5\gg M\) 且 \(H\to\infty\)，(25)--(26) 推出 (27)。\(\square\)

## 边界

式 (2) 的正块来自约 \(H\) 个素数 cofactor 的合并密度，强于只用 \(q=1\) 素数行所得的 \(\gg(\log M)^{-2}\) 正块。但式 (16) 说明同一物理类已由核负瓣自行支付这个常数主块；它不能作为必须由其他算术类抵消的证据。式 (25)--(27) 进一步把一个顶端 dyadic 带的 \(\gg\log^{-2}M\) 近块及负补偿都严格定位在四个互异素因子的配对中，并把同带的同 \(q\)、共享 \(p\) 与近差项支付到 \(H^4/M\)。这仍只有对数级总能量界，没有固定幂节省。式 (26) 只给该四素数子族的单侧目标界；其上侧需要比 (13) 的一阶素数短和更强的二点分布或与其他物理类的联合相消。完整 moving covariance、全尺度局部 Weil 正性与 RH 仍开放。
