# 稀疏素数完全乘法扭曲保留一阶数据但破坏两臂固定幂门

日期：2026-10-02。依赖 [scratch/933](933-high-prime-parity-residual-still-has-two-signs-in-final-ring.md) 的高素因子奇偶余项定义、[scratch/935](935-one-point-parity-data-do-not-control-the-complete-two-arm-gate.md) 的同一 cofactor-3 窗，以及 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的完整奇数源两臂核。短区间素数计数用 Matomäki–Shao–Tao–Teräväinen, *Higher uniformity of arithmetic functions in short intervals I. All intervals*, arXiv:2204.03754v4, Theorem 3.1(i) 与式 (3.11)，原文核对见 [scratch/936](936-logarithmic-quarter-power-collar-for-the-two-endpoint-residual.md)。以下证明尚待异源复核。

## 命题

令 $M=2Y$，$Q=(\log M)^2$，$\nu_Q=\mu-\mu^2\epsilon_Q$，$\delta_{M,H}=H/M^{1/4}$，$B_0=\lceil M^{2/3}\rceil$。固定 $0<\theta<1/20$，允许任意 $Y^{1/5}\le H\le Y^{1/4-\theta}$，于是 $\delta_{M,H}\ll M^{-\theta}$。取 scratch/935 的固定 $\psi,J,\eta$，特别 $J\Subset(6/5,2)$、$\psi\ge c_\psi>0$ 于 $J$、$\eta\ge1$ 于 $1\le|t|\le2$。令 $\mathcal K_h(u)$ 是 note 850 的**完整两臂**核，
\[
F_h^a=\sum_{\substack{D<u<2M/3\\u\text{ odd}}}a(u)\mathcal K_h(u).
\]
则对每个充分大的 $M$ 与所述 $H$，存在一个完全乘法函数 $\chi_{M,H}:\mathbb N\to\{\pm1\}$，其中 $\chi_{M,H}(2)=1$，而 $\chi_{M,H}(p)=-1$ 只发生在 $\asymp\delta_{M,H} M$ 个素数 $p\in U_M:=\{u\text{ odd}:3u/M\in J\}$ 上，使 $\widetilde\nu=\nu_Q\chi_{M,H}$ 满足：

1. 对所有正整数 $n$，$\widetilde\nu(n)^2=\nu_Q(n)^2$，支撑完全相同，且对所有奇数 $u$ 有 $\widetilde\nu(2u)=-\widetilde\nu(u)$。此外 $\widetilde\nu=(\mu\chi_{M,H})-(f_Q\chi_{M,H})$，两项仍各为乘法函数，其中 $f_Q=\mu^2\epsilon_Q$。
2. 对任意固定 $0<c<C<\infty$，一致于所有整数区间 $I\subset[cM,CM]$、$B_0\le |I|\le M^{4/5}$，甚至对该区间内任意模不超过 $1$ 的逐点权 $w$，都有
   \[
   \left|\sum_{n\in I}w(n)(\widetilde\nu(n)-\nu_Q(n))\right|
   \ll_C\delta_{M,H}|I|\ll_{\theta,C}M^{-\theta}|I|.\tag{1}
   \]
   因此任意固定对数幂精度也保持。同式尤其适用于奇数子和、任意等差进程及有界相位；平方和逐点未变，所以 scratch/933 的短区间一阶、二阶统计与 $\pm2$ 密度仍成立。
3. 对某个整数 $h_0\in[H,2H]$，
   \[
   |F_{h_0}^{\widetilde\nu}|\gg_{\psi,J}\delta_{M,H},
   \qquad
   \sum_h\eta(h/H)|F_h^{\widetilde\nu}|^2
   \gg\delta_{M,H}^2
   =\left(\frac{H^4}{M}\right)^{1/2}
   \gg\frac{H^4}{M}.\tag{2}
   \]

因此即使把 scratch/935 的逐点翻转限制为**完全乘法的稀疏素数扭曲**，相同的单点支撑、二进关系及 $M^{-\theta}$ 精度的全部有界一阶短区间测试仍不推出完整两臂固定幂门。$\widetilde\nu$ 不是实际 $\nu_Q$；本命题不否定其真实门或 RH。

## 证明

先取任意整数 $h_0\in[H,2H]$，记 $V=F_{h_0}^{\nu_Q}$，取单位复数 $\zeta$ 使 $\Re(\bar\zeta V)=|V|$（$V=0$ 时任取）。把 $U_M$ 的整数凸包分成长 $B_0$ 的整格，丢弃至多两个不足整格的端部。在其中每格代表 $u_j$ 上，称该格合格，若
\[
\Re\!\left(\bar\zeta\kappa e(-3h_0u_j/M)\right)
\ge |\kappa|/2,
\qquad \kappa=-4\log(3/2).\tag{3}
\]
相邻格的相位步长为 $O(HB_0/M)=O(M^{-1/12-\theta})=o(1)$，整个固定比例长的 $U_M$ 跨越 $\asymp H\to\infty$ 个周期。每周期中实部达到 (3) 的相位占 $1/3$；若每周期含 $P\asymp M/(HB_0)\to\infty$ 格，则其中合格格数为 $P/3+O(1)$，两端不完整周期只损失 $O(P)$ 格。因此合格格总数为 $(1/3+o(1))$ 倍的整格数，特别 $\gg_J M/B_0$。格内相位变化为 $o(1)$，因此每个合格格内全部 $p$ 对 (3) 的左端均有下界 $|\kappa|/3$。

[scratch/936](936-logarithmic-quarter-power-collar-for-the-two-endpoint-residual.md) 所核对的原文 Theorem 3.1(i) 与 (3.11)，在 $B_0\asymp M^{2/3}$ 的所有区间上给 $\sum\Lambda(n)=B_0+O_A(B_0(\log M)^{-A})$。素数高次幂的总权至多 $O(\sqrt M\log M)=o(B_0)$，且每个活动素数满足 $\log p=\log M+O(1)$，故每个合格格含 $(1+o(1))B_0/\log M$ 个素数，一致于格。置 $N_0=\lfloor\delta_{M,H}B_0\rfloor$。由 $H\ge Y^{1/5}$ 有 $N_0\gg M^{37/60+o(1)}\to\infty$，而 $\delta_{M,H}\log M\to0$，每个合格格可以选恰好 $N_0$ 个素数；其他格不选。令所选素数集为 $\mathcal P_{M,H}$。于是
\[
|\mathcal P_{M,H}|\asymp\frac M{B_0}N_0\asymp\delta_{M,H} M.\tag{4}
\]

定义 $\chi_{M,H}(p)=-1$ 当 $p\in\mathcal P_{M,H}$，其余素数取 $+1$，再完全乘法地延拓。因选中素数都大于 $Q$，逐个有 $\nu_Q(p)=\mu(p)-\mu^2(p)\epsilon_Q(p)=-1-1=-2$，而 $\widetilde\nu(p)=+2$。对 $u\in U_M$，note 850 的两个物理臂中仅 cofactor $3$ 活动，故
\[
\mathcal K_{h_0}(u)
=\frac\kappa M\phi(3u/M)e(-3h_0u/M),
\qquad \phi(x)=\psi(x)/x\ge c_{\psi,J}>0.\tag{5}
\]
每个选中素数 $p>2M/5$ 的奇数倍 $kp$（$k\ge3$）都大于 $2M/3$。因此在定义 $F_h^a$ 的**整个**奇数源范围内，扭曲改变的恰好是这些素数本身：
\[
F_{h_0}^{\widetilde\nu}-V
=4\sum_{p\in\mathcal P_{M,H}}\mathcal K_{h_0}(p).\tag{6}
\]
由 (3)、(5) 和 (4)，
\[
\Re\!\left(\bar\zeta(F_{h_0}^{\widetilde\nu}-V)\right)
\ge \frac{4c_{\psi,J}|\kappa|}{3M}|\mathcal P_{M,H}|
\gg\delta_{M,H}.
\]
原 $V$ 的该投影非负，故 (2) 的第一式成立。$\eta(h_0/H)\ge1$，而 $H^4/M=\delta_{M,H}^4\to0$，所以 $\delta_{M,H}^2\gg H^4/M$，得到 (2) 的后两式。

对所有 $n$，$\chi(n)^2=1$ 给平方与支撑不变。$\chi(2)=1$，并且 $\nu_Q(2u)=-\nu_Q(u)$ 对奇数 $u$ 成立，遂给第一项的二进关系。为证 (1)，只需数使 $\chi(n)\ne1$ 的 $n$。若 $n\in[cM,CM]$ 且被扭曲，必有某个 $p\in\mathcal P_{M,H}$ 整除 $n$，可写 $n=kp$，其中 $1\le k\le\lceil5C/2\rceil$。每个长 $B_0$ 的格选了至多 $N_0$ 个素数，因此对固定 $k$，落入 $I/k$ 的所选素数至多
\[
N_0\left(\frac{|I|}{kB_0}+2\right)
\ll_C\delta_{M,H}(|I|+B_0).
\]
对有限个 $k$ 求和，并用 $|\widetilde\nu(n)-\nu_Q(n)|\le4$、$|I|\ge B_0$，得逐点绝对差和 $\ll_C\delta_{M,H}|I|$。任意 $|w|\le1$ 的带权和都受此绝对和控制；又因 $\delta_{M,H}\ll M^{-\theta}$，得到 (1)。$\square$

## 边界

上述构造其实可把 $\delta_{M,H}$ 换成任意满足 $\delta B_0\to\infty$、$\delta\log M\to0$ 的正数；式 (1) 的误差变成 $O_C(\delta|I|)$，式 (2) 的能量下界变成 $\gg\delta^2$。若 $\delta/(H^2/\sqrt M)\to\infty$，其能量与目标 $H^4/M$ 的比值便趋于无穷。这给出**只依赖一般有界一阶测试**时必须越过的精度障碍，并不证明达到该精度就足够；上述 $\delta_{M,H}$ 是一个具有固定幂裕量的实例。

所选 $\chi_{M,H}$ 依赖观察尺度，并把少量大素数处实际恒等式 $\mu(p)=-1$ 改成 $\mu(p)\chi(p)=+1$。故这个反例指出：任何只要求乘法扭曲、短区间统计和支撑不变的证明都不够；真实素数符号或与之等价的跨素数、合数 signed 关系必须进入估计。它没有提供实际 Möbius 的上界，也没有改变 full moving-$N$ 门的开放状态。
