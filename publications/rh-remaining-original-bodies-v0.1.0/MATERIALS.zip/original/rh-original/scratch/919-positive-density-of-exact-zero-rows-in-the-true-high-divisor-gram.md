# 真实高除数 Gram 的精确零行具有正密度

日期：2026-10-02。依赖 [scratch/877](877-doubled-prime-physical-rows-cancel-in-the-true-high-divisor-gram.md) 式 (2g)--(2h) 的一大素因子物理系数分类、[scratch/917](917-small-physical-gcd-restores-the-complete-high-divisor-gram.md) 式 (2)--(7) 的原过滤门重组，以及素数定理和初等平方自由计数。这里把此前逐个或单一素数 cofactor 的零行提升为**正密度**的整族；仍不估计留下的 signed covariance，不证明 RH。本稿尚未异源复核，留在 scratch。

## 定理

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，并取 scratch/917 的 $D,G,a_D,\beta$。定义
\[
\mathcal E=\{q\ge1:\beta(q)=0\},
\qquad
\mathcal Z_{M,H}(J)=
\{m=pq\in MJ:p\text{ 为素数},\ q\le H,\ q\in\mathcal E\},
\tag{1}
\]
其中 $J=(a,b)$ 是 $(1,2)$ 内任意固定非空区间。置
$\delta_{\square}=1-1/\zeta(2)=1-6/\pi^2>0$。
则充分大 $M$ 时，(1) 的每个 $m$ 有唯一表示 $m=pq$，并且 $a_D(m)=0$。零行的数目有在整个 $H$ 范围一致的渐近式
\[
\boxed{\quad
\#\mathcal Z_{M,H}(J)
=\delta_{\square}|J|M
\log\!\left(\frac{\log M}{\log(M/H)}\right)
+O_J\!\left(\frac{M}{\log M}\right).
\quad}\tag{2}
\]
特别是 $\#\mathcal Z_{M,H}(J)\asymp_J M$，其占 $MJ$ 中整数的极限下界至少为
$\delta_{\square}\log(5/4)>0$；当 $\log H/\log M\to\alpha\in[1/5,1/4]$ 时，该比例趋于
$\delta_{\square}\log(1/(1-\alpha))$。
同一扇区的全部一大素因子行数把 (2) 的 $\delta_{\square}$ 换成 $1$；所以其中精确零行比例趋于 $\delta_{\square}$，非零行比例趋于 $1/\zeta(2)$。此外，除至多
$O_J(M\log\log(3M)/\log M)=o(M)$ 个位置外，这个扇区有逐点简式
\[
a_D(pq)=\frac{4\log2}{M}\,\mu(q)\phi(pq/M).
\tag{2a}
\]
式 (2a) 的例外不表示其 Gram 可无符号支付；稀疏行的系数可能含素数对数权。

令 $\mathfrak S_{\mathcal Z}$ 是 scratch/859 式 (12) 的**真实过滤源门**中，物理点 $m$ 或 $n$ 属于 $\mathcal Z_{M,H}((1,2))$ 的有序项之并集。则这些正密度行列可以**一次性**删除：
\[
\boxed{\quad
|\mathfrak S_{\mathcal Z}|
\ll_{s,\psi}\frac{\log^8(2M)}G
=O_{s,\psi}\!\left(\frac{H^3\log^4(2M)}M\right)
=o\!\left(\frac{H^4}M\right).
\quad}\tag{3}
\]
式 (3) 对整个零行族合计成立，不为每个物理位置另付误差。

## 证明

先分类 $\mathcal E$。scratch/877 式 (2h) 对 $q=2^a u$、$u$ 奇给
\[
\beta(q)=
\begin{cases}
4\Lambda(u)+4(\log2)\mu(u),&a=0,\\
0,&a=1,\ u=1,\\
-2\Lambda(u)-4(\log2)\mu(u),&a=1,\ u>1,\\
2\log2,&a\ge2,\ u=1,\\
0,&a\ge2,\ u>1.
\end{cases}\tag{4}
\]
若奇数 $u>1$ 平方自由且不是素数，则 $\Lambda(u)=0$、$\mu(u)=\pm1$，所以前两种含 $u>1$ 的行不为零。若 $u$ 是奇素数 $r$，两行分别为 $4\log(r/2)$ 与 $2\log(4/r)$，也不为零。若 $u$ 不是平方自由数，则 $\mu(u)=0$；此时 $\beta(q)\ne0$ 只可能是 $u$ 为奇素数幂，因为只有这时 $\Lambda(u)\ne0$。连同 $a\ge2$ 的两行，得到精确的稀疏例外描述：
\[
\mathcal E\mathbin{\triangle}\{q:\mu(q)=0\}
\subseteq
\{2\}\cup\{r^j:r\text{ 为素数},\,j\ge2\}
\cup\{2r^j:r\text{ 为奇素数},\,j\ge2\}.
\tag{5}
\]
每个例外族在 $q\le X$ 中只有 $O(\sqrt X\log X)$ 项。初等平方自由计数
$\sum_{q\le X}\mu(q)^2=X/\zeta(2)+O(\sqrt X)$ 因而给
\[
\#\{q\le X:q\in\mathcal E\}
=\delta_{\square}X+O(\sqrt X\log(2X)).
\tag{6}
\]
也可按 $2$-进层独立核对主常数：$4\mid q$ 给密度 $1/4$，奇数非平方自由数给 $1/2-4/\pi^2$，两倍该类奇数给 $1/4-2/\pi^2$；稀疏素数幂不改变密度，三项之和仍是 $1-6/\pi^2$。

对 $q\le H$、$pq\in MJ$，有 $p>aM/H>H\ge q$，因 $H^2=o(M)$。所以 $p$ 是 $m=pq$ 中唯一大于 $H$ 的素因子；不同 $(p,q)$ 不能给同一 $m$。scratch/917 式 (6) 逐行给
$a_D(pq)=M^{-1}\phi(pq/M)\beta(q)=0$。

因为 $M/q\ge M/H\gg M^{3/4}$，经典素数定理的定量余项
$\pi(x)=\operatorname{Li}(x)+O(xe^{-c\sqrt{\log x}})$
及 $\operatorname{Li}$ 的一次展开在固定比例区间上一致给
\[
\#\{p\text{ 素数}:aM/q<p<bM/q\}
=\frac{|J|M}{q\log(M/q)}
+O_J\!\left(\frac{M}{q\log^2 M}\right).
\tag{7}
\]
把 (7) 对 $q\le H$、$q\in\mathcal E$ 求和；由 $\sum_{q\le H}1/q\ll\log H\ll\log M$，总误差为 $O_J(M/\log M)$。

将 (6) 对 $f(t)=1/[t\log(M/t)]$ 分部求和。因为 $t\le H\ll M^{1/4}$，$f(t)\ll1/(t\log M)$ 且 $|f'(t)|\ll1/(t^2\log M)$；(6) 的误差项在边界和积分中合计为 $O(1/\log M)$。故
\[
\sum_{\substack{q\le H\\q\in\mathcal E}}
\frac1{q\log(M/q)}
=\delta_{\square}\int_1^H\frac{dt}{t\log(M/t)}
+O\!\left(\frac1{\log M}\right)
=\delta_{\square}\log\!\left(\frac{\log M}{\log(M/H)}\right)
+O\!\left(\frac1{\log M}\right).
\tag{8}
\]
联立 (7)--(8) 得 (2)。在所给 $H$ 范围，$\log H/\log M$ 一致落于 $[1/5+o(1),1/4+o(1)]$，所以主项为固定正比例。
把 (7)--(8) 中的 $\mathcal E$ 改成全部正整数 $q\le H$，其计数函数是 $\lfloor X\rfloor=X+O(1)$，即得定理中的全扇区行数和两种比例。由 scratch/917 式 (5)，
$\beta(q)-4(\log2)\mu(q)=4\Lambda(q)-2\mathbf1_{2\mid q}\Lambda(q/2)$，
故 (2a) 只可能在 $q$ 为素数幂或两倍素数幂时失败。对这些 $q\le H$ 用 (7) 的上界，并用
$\sum_{r\le H,\ r\ {\rm prime}}1/r\ll\log\log(3H)$、$\sum_{j\ge2,r\ {\rm prime}}r^{-j}<\infty$，其对应物理行数为 $O_J(M\log\log(3M)/\log M)$。这里 $p>H$ 仍保证逐行不重复。

最后，scratch/917 式 (2) 表明物理 gcd 不超过 $G$ 时，原过滤源门在每个 $(m,n)$ 上精确等于 $a_D(m)\overline{a_D(n)}J_H(m-n)$；若任一端属于 $\mathcal Z_{M,H}((1,2))$，此值为零。其余物理 gcd 大于 $G$ 的全部可能项由 scratch/868 式 (2b) 的绝对和统一界为 $O(\log^8(2M)/G)$。scratch/917 的 $G\gg M\log^4(2M)/H^3$ 给 (3)，且与 $H^4/M$ 之比至多 $O(\log^4 M/H)\to0$。$\square$

## 稀疏素数 cofactor 承担整个扇区的一阶主项

定义 $\mathcal P_{M,H}(J)=\{m=pq\in MJ:p\text{ 为素数},\,q\le H\}$，仍按唯一的 $p,q$ 表示求和，并置
$\Phi_J=\int_J\phi(t)\,dt$。则真实高除数系数满足
\[
\boxed{\quad
\sum_{m\in\mathcal P_{M,H}(J)}a_D(m)
=3\Phi_J\log\!\left(\frac{\log M}{\log(M/H)}\right)
+O_{\psi,J}\!\left(\frac1{\log M}\right).
\quad}\tag{9}
\]
相比之下，把该扇区的 $\beta(q)$ 逐行换成其在除素数幂及两倍素数幂外的通式 $4(\log2)\mu(q)$，所得一阶和只有
\[
\boxed{\quad
\frac{4\log2}{M}
\sum_{\substack{q\le H,\ p\ {\rm prime}\\pq\in MJ}}
\mu(q)\phi(pq/M)
=O_{\psi,J}\!\left(\frac1{\log M}\right).
\quad}\tag{10}
\]
因此，式 (2a) 中 $o(M)$ 个例外位置承担了 (9) 的整个常数量级主项；按物理行数忽略它们会改变算术判断。

证明只需在 (7) 中加上固定有界变差权 $\phi(pq/M)$。对每个 $q\le H$，定量素数定理与 Stieltjes 分部积分一致给
\[
\frac1M\sum_{\substack{p\ {\rm prime}\\pq\in MJ}}\phi(pq/M)
=\frac{\Phi_J}{q\log(M/q)}
+O_{\psi,J}\!\left(\frac1{q\log^2M}\right).
\tag{11}
\]
scratch/917 式 (5) 的 $|\beta(q)|\le4\Lambda(q)+2\mathbf1_{2\mid q}\Lambda(q/2)+4(\log2)|\mu(q)|$
及 $\sum_{n\le H}\Lambda(n)/n\ll\log(2H)$ 给
$\sum_{q\le H}|\beta(q)|/q\ll\log(2H)$，故 (11) 乘 $\beta(q)$ 求和的误差为 $O(1/\log M)$。

令 $\Psi(X)=\sum_{n\le X}\Lambda(n)$、$\mathcal M(X)=\sum_{n\le X}\mu(n)$。由 scratch/917 式 (5)，
\[
\sum_{q\le X}\beta(q)
=4\Psi(X)-2\Psi(X/2)+4(\log2)\mathcal M(X)
=3X+O_A\!\left(\frac{X}{\log^A(2X)}\right)
\quad(A>0),
\tag{12}
\]
其中最后一步使用经典素数定理及其等价的 Möbius 零均值定量式。对 (11) 的权 $1/[q\log(M/q)]$ 按 (12) 分部求和，完全同于 (8)，得到 $3\log(\log M/\log(M/H))+O(1/\log M)$，证明 (9)。若改乘 $\mu(q)$，其部分和是 $O_A(X/\log^A(2X))$，同一分部求和只留下 $O(1/\log M)$；(11) 的绝对误差也为 $O(1/\log M)$，证明 (10)。$\square$

## 边界

正密度零行只说明高除数物理 Gram 的支撑发生严格收缩。式 (9)--(10) 进一步说明式 (2a) 的稀疏例外不能按行数删除：其中 $H^{1/2}<q\le H$ 的素数 cofactor 管已有 [scratch/878](878-prime-cofactor-tube-self-cancels-through-bandpass-sidelobes.md) 式 (7)--(9) 的常数量级绝对质量和首瓣正块。其余行的中距离、低物理 gcd 符号相关仍可有远大于目标的正负子块；这些一阶公式不提供净固定幂二点上界。全尺度局部 Weil 正性与 RH 仍开放。
