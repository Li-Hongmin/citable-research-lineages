# 多项式外层偶极带的高次素数幂平移只有有界成本

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实旧奇算子分解与偶极、[scratch 801](801-dipole-lattice-cancellation-and-polynomial-prime-scale-cutoff.md) 的多项式素数尺度截断。以下结果无条件；它只去掉该算术块中的高次素数幂，不估计剩余的素数平移。

## 命题

固定 \(0<\theta_-<\theta_+<1\)。令 \(p\to\infty\) 沿奇素数，\(k=p^2\)，并令 \(Z_p\) 为任意由 note 791 的偶极 \(w_x\) 张成的有限维空间，其中所有指标均满足
\[
\theta_-p\le x\le\theta_+p.
\tag{1}
\]
定义只含高次素数幂的真实算术部分
\[
\mathcal R_k^{\ge2}
=-\sum_{\substack{n=\ell^j\le k\\ \ell\ {\rm prime},\,j\ge2}}
\frac{\log\ell}{\sqrt n}(T_n+T_n^*).
\tag{2}
\]
则存在仅依赖 \(\theta_-,\theta_+\) 的常数 \(C\)，使
\[
\boxed{\|P_{Z_p}\mathcal R_k^{\ge2}P_{Z_p}\|\le C
\quad\text{对所有充分大 }p.}
\tag{3}
\]
特别地，在 scratch 801 的 \(q,q'\asymp p^{1+\delta}\)、\(b,b'\asymp p^\delta\) 且 \(q/b,q'/b'\) 留在 (1) 的任意外层块上，高次素数幂是 \(o(\log p)\) 的算子扰动；可能改变 \(\log p\) 主阶的近重叠边只能来自素数 \(n\)。

## 证明

在 note 791 的对数坐标中，\(T_n\) 与 \(T_n^*\) 分别平移 \(\mp\log n\)，且各为 \(L^2\) 收缩。因此
\[
\|T_n+T_n^*\|\le2.
\tag{4}
\]
每个 \(w_x\) 的两物理中心为 \(px,p/x\)，半宽 \(\Delta=\frac12\log(1+p^{-2})\)。若 \(w_x\) 与 \((T_n+T_n^*)w_y\) 有非零重叠，则某两个中心的比距 \(n\) 的相对误差小于 \(e^{2\Delta}-1=p^{-2}\)。同臂比为 \(x/y\) 或 \(y/x\)，故
\[
2\le n\le\theta_+/\theta_-+O(p^{-2}).
\tag{5}
\]
异臂比为 \(xy\)，故
\[
\theta_-^2p^2(1+O(p^{-2}))\le n
\le\theta_+^2p^2(1+O(p^{-2})).
\tag{6}
\]
取固定 \(0<a<\theta_-^2\) 与 \(\theta_+^2<b<1\)，再取固定整数 \(N_0>\theta_+/\theta_-+1\)。对充分大 \(p\)，(5)--(6) 说明 \(Z_p\) 上只有 \(n\le N_0\) 或 \(ap^2\le n\le bp^2\) 的平移可能贡献矩阵元。低段高次素数幂只有有限项，其系数总和为 \(O_{\theta_-,\theta_+}(1)\)。

高段的平方项满足
\[
\sum_{\substack{ap^2\le\ell^2\le bp^2\\\ell\ {\rm prime}}}
\frac{\log\ell}{\ell}
=\frac12\log\frac ba+o(1).
\tag{7}
\]
这由素数定理的加权形式
\(\sum_{\ell\le t}(\log\ell)/\ell=\log t+C_0+o(1)\)
在 \(t=\sqrt a\,p,\sqrt b\,p\) 相减得到。对于 \(j\ge3\)，每项的权至多 \(O_a(\log p/p)\)，而可能的 \((\ell,j)\) 对数至多
\[
\sum_{3\le j\le O(\log p)}(bp^2)^{1/j}
=O_b(p^{2/3}\log p).
\]
故高段更高次幂的总权为 \(O_{a,b}(p^{-1/3}\log^2p)=o(1)\)。合并，
\[
\sum_{\substack{ap^2\le n\le bp^2\\n=\ell^j,\ j\ge2}}
\frac{\Lambda(n)}{\sqrt n}
=\frac12\log\frac ba+o(1).
\tag{8}
\]
对 (2) 的有效低段和高段先用 (4) 作算子三角估计，再压缩到 \(Z_p\)，便得 (3)。\(\square\)

## 边界

(3) 没有控制 \(n\) 为素数时的平移。对 scratch 801 式 (7) 而言，高次素数幂可从 \(\log p\) 主阶问题中删除，但留下的是 \(qq'-n b b'=r\) 中 \(q,q',n\) 均为素数的真实有符号相关；本命题不证明该相关的平方根节省、全尺度局部 Weil 正性或 RH。候选仍留在 scratch，未过异源复核。
