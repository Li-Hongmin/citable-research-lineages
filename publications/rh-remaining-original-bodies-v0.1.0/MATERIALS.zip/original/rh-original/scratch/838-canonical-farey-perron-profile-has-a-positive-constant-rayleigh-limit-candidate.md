# 临界全 Farey 正轮廓的真实 Weil Rayleigh 商趋于严格正常数（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实奇 Weil 主压缩、精确正权行恒等式与一致 Archimedean 算子界，以及 [note 780](../notes/780-all-prime-power-half-slots-give-nine-thirty-seconds-logarithmic-physical-inverse-response.md) 的单半槽能量。本文计算 note 791 尚只夹在 \(O(1)\) 内的一个**指定测试方向**的极限；证明尚待异源复核，留在 scratch。

## 命题

沿奇素数 \(p\to\infty\) 取 \(k=p^2\)，沿用 note 791 的 \(\mathcal F_p\)、正交偶极 \(w_{a/b}\)、\(W_p\) 与真实旧奇算子 \(A_{k,-}\)。定义正权测试向量
\[
u_p=\sum_{\substack{1\le b<a<p\\(a,b)=1}}
\frac{w_{a/b}}{\sqrt{ab}}.
\tag{1}
\]
则
\[
\boxed{\qquad
\lim_{p\to\infty}
\frac{\langle u_p,A_{p^2,-}u_p\rangle}{\|u_p\|^2}
=1+\gamma_E-\log\pi+\log2>0.
\qquad}
\tag{2}
\]
这判定了全 Farey 图中最自然的正临界轮廓：算术谱半径虽为 \(\log k+O(1)\)，该指定轮廓在真实算子中最终仍有严格正 Rayleigh 值。式 (2) 不判定其他向量、完整主压缩的最低谱值或全尺度局部 Weil 正性。

## 算术 Rayleigh 常数

令 \(L=\log k=2\log p\)、\(v_{a/b}=(ab)^{-1/2}\)。note 791 式 (15) 给
\[
\|u_p\|^2=\|v\|^2
=\frac{(\log p)^2}{2\zeta(2)}+O(\log p).
\tag{3}
\]
把 \(\mathfrak M(x)=\sum_{n\le x}\Lambda(n)/n\) 与 \(E(x)=\mathfrak M(x)-\log x\) 区分于 Möbius 部分和。经典素数定理带零自由区误差及 \(-\zeta'/\zeta(1+s)=s^{-1}-\gamma_E+O(s)\) 给
\[
E(x)=O(1),\qquad E(x)\longrightarrow-\gamma_E.
\tag{4}
\]
note 791 式 (14) 因而逐行精确改写为
\[
\frac{(C_pv)_{a/b}}{v_{a/b}}
=2\log(p-1)
+E\!\left(\frac{p-1}{a}\right)
+E\!\left(\frac{p-1}{b}\right)
-\Lambda(a)\mathbf1_{b=1}.
\tag{5}
\]
取 \(Q=\lfloor p/\log p\rfloor\)，并把 \(a,b\le Q\) 称为内区。由 (3) 对 \(Q\) 同样适用，内区的 \(v_x^2\) 权重占比为
\(1-O((\log\log p)/\log p)\)。内区中
\((p-1)/a,(p-1)/b\ge(1+o(1))\log p\to\infty\)，所以 (4) 的两个 \(E\) 一致趋于 \(-\gamma_E\)；外区因 \(E=O(1)\) 贡献为 \(o(1)\)。最后，\(b=1\) 的缺项总权为
\[
\sum_{a<p}\frac{\Lambda(a)}a=O(\log p)
=o(\|v\|^2).
\tag{6}
\]
故
\[
\boxed{\quad
\frac{\langle v,C_pv\rangle}{\|v\|^2}
=L-2\gamma_E+o(1).
\quad}
\tag{7}
\]

## Archimedean 接触项的 Rayleigh 极限

记 note 791 式 (6) 的
\[
P_{W_p}A_{k,-}P_{W_p}=D_kI-C_p+E_p,
\qquad D_k=L+1-\gamma_E-\log\pi,
\qquad\|E_p\|\le C.
\tag{8}
\]
需要的是 \(E_p\) 在指定 \(v\) 上的平均，而非 \(\|E_p\|\to0\)。沿用 \(Q=\lfloor p/\log p\rfloor\)，令 \(I_p=\{a/b\in\mathcal F_p:a,b\le Q\}\)，\(P_I\) 为其坐标投影。由 (3) 对 \(p\) 与 \(Q\) 分别使用，
\[
\frac{\|(I-P_I)v\|^2}{\|v\|^2}
=O\!\left(\frac{\log\log p}{\log p}\right).
\tag{9}
\]

下面证明内区到全 Farey 族的 Archimedean 交叉范数趋零。note 791 的物理槽宽 \(\Delta\asymp p^{-2}\)。若 \(x=a/b\in I_p\) 与不同的 \(y=c/d\in\mathcal F_p\) 同臂，则 \(|ad-bc|\ge1\) 且 \(ad,bc\le Qp\)，故两物理中心的对数距离 \(r\gg(Qp)^{-1}\)。异臂距离为 \(\log(xy)\ge\log x\gg Q^{-1}\)，满足更强的下界。全族物理中心两两相距至少 \(2\Delta\)。因此 note 791 式 (12) 的零矩核界和间距计数给每个内区行的交叉绝对和
\[
\ll \Delta^3\left((Qp)^3+\Delta^{-1}(Qp)^2\right)
\ll (Q/p)^2\ll(\log p)^{-2}.
\tag{10}
\]
全族的对应列绝对和由 note 791 的 Schur 证明一致为 \(O(1)\)，所以矩形 Schur 检验给非对角块范数 \(O(Q/p)=O((\log p)^{-1})\)。note 791 式 (13) 的 \(D_k+O(\Delta)\) 是单半槽对角；归一化左右半槽 \(e_-,e_+\) 的接触交叉由 \(K(d)=1/(2d)+O(1)\) 给
\[
\langle e_-,G_ke_+\rangle
=-\Delta^{-1}\int_0^\Delta\!\int_0^\Delta K(s+t)\,ds\,dt
=-\log2+O(\Delta).
\]
故每个物理偶极的对角修正为 \(\log2+O(\Delta)\)。同一 \(w_x\) 的两物理中心相距 \(\gg Q^{-1}\)，其自交叉由同一核界为 \(O(\Delta^3Q^3)=o(1)\)。note 791 的 polar 投影范数为 \(O(p^{-3/2})\)。合并可得
\[
\|P_I(E_p-(\log2)I)\|_{\ell^2(\mathcal F_p)\to\ell^2(I_p)}
=O((\log p)^{-1})+o(1).
\tag{11}
\]
将 \(v=P_Iv+(I-P_I)v\) 代入 \(\langle v,(E_p-(\log2)I)v\rangle\)，用 (8)、(9)、(11) 得
\[
\frac{|\langle v,(E_p-(\log2)I)v\rangle|}{\|v\|^2}
\ll\frac1{\log p}+\frac{\log\log p}{\log p}+o(1)=o(1).
\]
因此
\[
\boxed{\quad\langle v,E_pv\rangle/\|v\|^2=\log2+o(1).\quad}
\tag{12}
\]

式 (7)--(8)、(12) 给 (2)。常数严格正，例如 \(\gamma_E>1/2\)、\(\pi<4\)、\(\log4<3/2\)，故 \(1+\gamma_E-\log\pi>0\)。\(\square\)

## 边界

本结果只对 (1) 的指定正轮廓给出严格正常数。由 \(\lambda_{\min}(P_{W_p}A_{k,-}P_{W_p})\) 的符号仍未知，不能以一个正 Rayleigh 值推断整个压缩正性；正交补的 Schur 反馈也未控制。因而它既不证明全尺度局部 Weil 正性，也不证明或反驳 RH。
