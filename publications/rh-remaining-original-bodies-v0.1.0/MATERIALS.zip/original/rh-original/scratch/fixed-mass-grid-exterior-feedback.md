# 固定质量整数格的外侧整数层：真实交叉试探（待复核）

沿用固定质量候选定理，取固定非负实值单位
$\varphi\in C_c^\infty((-1/2,1/2))$，$\kappa=\int\varphi>0$，
$\ell=c/p^2$，$N=\lfloor p^2/16\rfloor$，$\alpha_p=\ell N\to c/16$。
令 $I_j=(H-\log4-\log j-\ell/2,H-\log4-\log j+\ell/2)$。
设 $U=\bigcup_{j\le N}I_j$、$E=\bigcup_{2N<r\le4N}I_r$。
取 $c>0$ 足够小，使这些槽相离且处于 $(-H,H)$；$E\subset U^c$。
记 $L=\sum_{j\le N}j^{-1}=\log N+O(1)$、
$T=\sum_{2N<r\le4N}r^{-1}\to\log2$，
$b_\ell(t)=\ell^{-1/2}\varphi(t/\ell)$。
在 $I_j$ 上定义
\[
f(y_j+t)=\frac{j^{-1/2}}{\sqrt L}b_\ell(t)\quad(j\le N),
\qquad
g(y_r+t)=\frac{r^{-1/2}}{\sqrt T}b_\ell(t)\quad(2N<r\le4N),
\]
别处取零。则 $f,g$ 为范数一的光滑实函数且支撑正交。

**候选结论。** 在上述规范下，完整 Weil 形式的双线性交叉满足
\[
\frac{Q_W^H(f,g)}{\sqrt L}
\longrightarrow
-\sqrt{\log2}+\frac{\kappa^2 c}{8\sqrt{\log2}}.\tag{1}
\]
存在绝对小的固定 $c>0$ 使 $Q_W^H[g]>0$，并且
\[
\liminf_{p\to\infty}
\left(Q_W^H[f]-\inf_{t\in\mathbb R}Q_W^H[f+t g]\right)
\ge \frac{(\log2-\kappa^2c/8)^2}{\log2}>0.\tag{2}
\]
这仅给某一个 $U$ 中试函数的外部变分反馈下界；不声称 $U^c$ 上的算子正定或完整 true-Schur 存在。

证明。$4N\le p^2/4$，所以 $I_r\subset(-H,H)$；
最小中心间距 $\gg p^{-2}$，小 $c$ 保证相离。
因为 $8N\ell<1$，所有涉及的 prime 位移只有精确整除边。
对 $r\in(2N,4N]$，从 $j\le N$ 入射的权总和为
\[
S_r=\sum_{\substack{k\mid r\\r/k\le N}}\Lambda(k)
=\log r-\sum_{\substack{k\mid r\\k<r/N}}\Lambda(k)
=\log r+O(1),\tag{3}
\]
因为 $2<r/N\le4$，被排除的素数幂只有 $k=2,3$。
共同轮廓完全对齐，因而 prime 交叉为
\[
Q_{\rm prime}(f,g)
=-\frac1{\sqrt{LT}}\sum_{2N<r\le4N}\frac{S_r}{r}
=-\sqrt{LT}+O(L^{-1/2}).\tag{4}
\]
约化普通核的两支撑间距至少 $\log2-O(\ell)$，故其绝对交叉至多
\[
\frac{C\ell}{\sqrt{LT}}
\sum_{j\le N}\sum_{2N<r\le4N}\frac1{\sqrt{jr}}
=O(\alpha_p L^{-1/2}).\tag{5}
\]
令 $m_\pm=\int b_\ell(t)e^{\pm t/2}dt$
$=\kappa\sqrt\ell(1+O(\ell))$。由 $e^{y_j/2}=\sqrt p/(2\sqrt j)$、
$e^{-y_j/2}=2\sqrt{j/p}$，极点交叉精确为
\[
Q_{\rm pol}(f,g)
=m_+m_-\left(2N\sqrt{L/T}+N\sqrt{T/L}\right)
=2\kappa^2\alpha_p\sqrt{L/T}+o(\sqrt L).\tag{6}
\]
式 (4)--(6) 给 (1)。

$E$ 内任意两个中心之比严格小于 $2$，故 $Q[g]$ 没有 prime 交叉。
单槽 Fourier 主部为 $\log(1/\ell)+O_\varphi(1)$；普通非对角核对非负 $g$ 只给负项，polar 自项
$Q_{\rm pol}[g]=4m_+m_-N=O(\alpha_p)$。于是
\[
Q[g]\le\log(1/\ell)+O_\varphi(1+\alpha_p).
\tag{7}
\]
另一方面，普通非对角核的最大绝对行和为
$O(\ell N\log N)=O(\alpha_p\log N)$，单槽 Fourier 下界为
$\log(1/\ell)-O(1)$，而 $Q_{\rm pol}[g]\ge0$。故足够小的固定 $c$ 保证
$Q[g]\ge(1-O(c))\log N-O(1)>0$。此时实变量 $t$ 的二次配方给
\[
Q[f]-\inf_tQ[f+tg]=\frac{Q(f,g)^2}{Q[g]}.
\]
由 (1)、(7) 及 $\log(1/\ell)/L\to1$ 得 (2)。
