# 槽外重叠权的真实素数 Rayleigh 差无条件小于线性尺度

日期：2026-09-30。沿用 [note 828](../notes/828-exterior-prime-hankel-centered-spectrum-has-linear-negative-tail.md) 的 \(r_p,k_p,R_p,K_p\) 与 [note 829](../notes/829-exterior-overlap-mellin-weight-zero-free-growing-band.md) 的 \(E_p,\omega_p,W_p\)。本文给出同一真实素数标量的无条件相对主项候选证明，继而候选加强 note 828 的中心化负谱常数；不估计 \(O(\log p)\) 的真实 Weil 门。承重的零点采样与零自由区组合尚未完成独立复核，故本稿留在 scratch。

## 定理

令 \(p\to\infty\) 沿奇素数，\(H=\log p\)。存在绝对常数 \(c>0\)，使
\[
\boxed{\quad
|r_p-k_p|\ll p\exp\!\left[-c\frac{H^{1/3}}{(\log H)^{1/3}}\right]=o(p).
\quad}
\tag{1}
\]
因此 note 828 的中心化真正素数算子满足
\[
\boxed{\quad
\inf\sigma(R_p-K_p)
\le-k_p+O\!\left(p e^{-c(H/\log H)^{1/3}}\right)
=-\left(\frac{3\log2}{128\zeta(2)}+o(1)\right)p.
\quad}
\tag{2}
\]
在 RH 条件下，同一标量还有 \(r_p-k_p=O(H)\)。式 (1)--(2) 都不控制使 \(R_p\) 出现负本质谱的调制向量的 Archimedean 能量，也不证明全尺度局部 Weil 正性。

**有界变差轮廓。** 将实值 \(a\in L^2(E_p)\) 平移为 \(a_p(v)=a(2H+v)\)，并在 \(V_p\) 外延零。对任意固定 \(B>0\)，若 \(\|a\|_2\le1\) 且其全实线总变差 \(\operatorname{Var}(a_p)\le p^B\)，则存在 \(c_B>0\) 使
\[
\boxed{\quad
|(R_p-K_p)[a]|
\ll_B p\exp[-c_B(H/\log H)^{1/3}].
\quad}
\tag{2a}
\]
**多项式频率调制。** 对任意固定 \(A>0\)，令 \(g_p=e^{u/2}\mathbf1_{E_p}/\|e^{u/2}\mathbf1_{E_p}\|_2\) 且 \(g_{p,t}(u)=\sqrt2g_p(u)\cos(tu)\)。式 (2a) 经固定常数归一化给
\[
|(R_p-K_p)[g_{p,t}]|
\ll_A p\exp[-c_A(H/\log H)^{1/3}]
\qquad(|t|\le p^A).
\tag{2b}
\]
特别地，若一列 \(t_p\) 使 \(\|g_{p,t_p}\|_2\to1\) 且 \((R_p-K_p)[g_{p,t_p}]\le-cp\)（\(c>0\) 固定），则 \(|t_p|>p^A\) 对每个固定 \(A\) 最终成立。这里的结论只针对这族调制向量，不是整个算子的低频谱界。

## 固定窗口上的零点采样

把 \(V_p=E_p-2H\) 平移到固定区间。note 829 的每个槽以 \(\log(x/p)\) 为中心，且 \(p/8\le x=n/b\le p/2\)；其宽 \(L=\log(1+p^{-2})\ll p^{-2}\)。允许的 \((n,b)\) 对数至多 \(Cp^{3/2}\sqrt p=Cp^2\)，且 note 829 已证明这些槽两两不交。因此
\[
V_p\subset[-\log8-1,-\log2+1],\qquad
|V_p|=O(1),\qquad
V_p\text{ 是 }M_p=O(p^2)\text{ 个不交区间的并}.
\tag{3}
\]
令
\[
F_p(s)=\int_{V_p}e^{sv}\,dv=p^{-2s}\int_{E_p}e^{su}\,du.
\tag{4}
\]
note 829 式 (1) 给 \(W_p(s)=p^{2s}F_p(s)^2\)。对 \(0\le\sigma\le1\)，函数 \((\sigma,t)\mapsto F_p(\sigma+it)\) 的任意总阶数至多二的偏导数是 \(v^{a+b}i^b e^{(\sigma+it)v}\) 在 \(V_p\) 上的积分。Plancherel 因而给
\[
\sum_{a+b\le2}\int_0^1\int_{\mathbb R}
|\partial_\sigma^a\partial_t^b F_p(\sigma+it)|^2\,dt\,d\sigma
\ll |V_p|\ll1.
\tag{5}
\]
对每个整数 \(j\)，在单位矩形 \(Q_j=[0,1]\times[j,j+1]\) 上用二维 Sobolev 嵌入 \(H^2(Q_j)\hookrightarrow L^\infty(Q_j)\)。常数与 \(j,p\) 无关。记
\(M_j=\sup_{(\sigma,t)\in Q_j}|F_p(\sigma+it)|^2\)，则 (5) 给
\[
\boxed{\qquad \sum_{j\in\mathbb Z}M_j\ll1.\qquad}
\tag{6}
\]
另一方面，(3)--(4) 在每个区间上精确积分，故当 \(|t|\ge2\) 时
\[
|F_p(\sigma+it)|\ll M_p/|t|\ll p^2/|t|
\qquad(0\le\sigma\le1).
\tag{7}
\]

令 \(n_j\) 为 \(\Im\rho\in[j,j+1)\) 的非平凡零点数，按重数计。Riemann--von Mangoldt 计数给 \(n_j\ll\log(2+|j|)\)。取 \(T=p^6\)，(6) 与 (7) 分别给
\[
\sum_{|\Im\rho|\le T}|F_p(\rho)|^2\ll H,
\qquad
\sum_{|\Im\rho|>T}|F_p(\rho)|^2
\ll p^4\sum_{|j|>T-1}\frac{\log(2+|j|)}{j^2}
\ll H p^{-2}.
\tag{8}
\]
尤其全部零点上的平方采样和为 \(O(H)\)，不需要 RH。

## 零自由区与真实素数

经典 Vinogradov--Korobov 零自由区（项目中的输入背景见 [note 516](../notes/516-vinogradov-korobov-baseline-for-the-first-sine-mode.md)）给某个绝对 \(c_0>0\)，使 \(|\Im\rho|\le p^6\) 的全部非平凡零点满足
\[
1-\Re\rho\ge
\frac{c_0}{H^{2/3}(\log H)^{1/3}}
\tag{9}
\]
（有限个低高度零点通过减小 \(c_0\) 包含在内）。因 \(|W_p(\rho)|=p^{2\Re\rho}|F_p(\rho)|^2\)，式 (8)--(9) 给
\[
\begin{aligned}
\sum_\rho |W_p(\rho)|
&\le p^2 e^{-2c_0(H/\log H)^{1/3}}
\sum_{|\Im\rho|\le T}|F_p(\rho)|^2
+p^2\sum_{|\Im\rho|>T}|F_p(\rho)|^2\\
&\ll p^2 H e^{-2c_0(H/\log H)^{1/3}}+H
\ll p^2 e^{-c(H/\log H)^{1/3}}.
\end{aligned}
\tag{10}
\]
由 note 829 式 (5)、\(k_p\asymp p\) 及其 \(O(1)\) 的高次素数幂修正，得到 (1)。在 RH 条件下，\(\Re\rho=1/2\)，(8) 直接给
\(\sum_\rho|W_p(\rho)|=p\sum_\rho|F_p(\rho)|^2\ll pH\)，故 \(r_p-k_p=O(H)\)。

最后 note 828 式 (5) 的负号调制对自然向量给
\(\inf\sigma(R_p-K_p)\le-r_p\)。将 (1) 与其
\(k_p=(3\log2/(128\zeta(2))+o(1))p\) 代入，即得 (2)。\(\square\)

## 有界变差轮廓的证明

固定 \(B\)，取满足 (2a) 假设的实值 \(a\)。对 \(z\in\mathbb C\) 置 \(G_a(z)=\int_{V_p}a_p(v)e^{zv}dv\)。仿照 (5)--(8)，这次在固定条带 \(-1/2\le\Re z\le1/2\) 用 Plancherel、二维 Sobolev 与有界变差的分部积分，得到
\[
\sum_{|\Im\rho|\le T}|G_a(\rho-1/2)|^2\ll H,
\qquad
\sum_{|\Im\rho|>T}|G_a(\rho-1/2)|^2
\ll p^{2B}H/T,
\tag{12}
\]
其中 \(T=p^{2B+4}\)；第二式为 \(O(Hp^{-4})\)。这里 Plancherel 常数只用 \(\|a\|_2\le1\)，高频分部积分常数只用全实线总变差 \(\le p^B\)。

定义紧支撑的素数权
\[
h_a(m)=m^{-1/2}\int_{E_p}a(u)a(2H+\log m-u)\,du.
\]
其 Mellin 变换由 note 829 式 (1) 的同一次变量替换精确给
\[
\mathcal H_a(s)
=p^{2s-1}G_a(s-1/2)^2.
\tag{13}
\]
在 \(s=1\) 的留数为
\(\mathcal H_a(1)=p^{-1}(\int_{E_p}a(u)e^{u/2}du)^2=K_p[a]\)，其中最后一步用 \(a\) 为实值及 note 828 式 (1) 的定义。该定义也逐项给出
\[
R_p[a]=\sum_{\ell\ \mathrm{prime}}(\log\ell)h_a(\ell).
\tag{13a}
\]
由 \(a_p\in BV\) 的分部积分，\(G_a(\sigma+it)=O_{p,a}(|t|^{-1})\) 于固定竖带成立；**式 (13) 的平方**使 \(\mathcal H_a(\sigma+it)=O_{p,a}(|t|^{-2})\)。\(h_a\) 是紧支撑 BV 函数的连续卷积乘以光滑权，故在素数幂点没有半权取值歧义。其支撑满足 \(m\asymp p^2>1\)，所以与 note 829 式 (4) 同样的 Mellin 反演和移线给出绝对收敛的显式公式
\[
\sum_{m\ge1}\Lambda(m)h_a(m)-K_p[a]
=-\sum_\rho\mathcal H_a(\rho)
-\sum_{j\ge1}\mathcal H_a(-2j).
\tag{14}
\]
由 (12) 与 \(|\mathcal H_a(\rho)|=p^{2\Re\rho-1}|G_a(\rho-1/2)|^2\)，同 (9)--(10) 的零自由区拆分得
\[
\sum_\rho|\mathcal H_a(\rho)|
\ll_B pH e^{-c'_B(H/\log H)^{1/3}}+pHp^{-4}
\ll_B p e^{-c_B(H/\log H)^{1/3}}.
\tag{15}
\]
平凡零点和为 \(O(p^{-5})\)，因为 \(V_p\) 有界且 \(\|a_p\|_1\ll1\)。对每个参与的素数幂，反射 \(J_m\) 在 \(L^2(E_p)\) 上的范数至多一；平方素数 \(\ell\asymp p\) 的 \(\sum(\log\ell)/\ell=O(1)\)。若 \(r\ge3\)，则 \(\ell^r\asymp p^2\)、\(\ell\ll p^{2/r}\)，且每项 \((\log\ell)/\ell^{r/2}\ll H/p\)；对 \(r\le C H\) 与全部可能的 \(\ell\) 平凡求和，总量为 \(O(p^{-1/3}H^2)=o(1)\)。因此从 (14) 换回真正素数只产生 \(O(1)\|a\|_2^2\) 的形式误差，被 (15) 右端吸收，证明 (2a)。

最后核对调制族。note 828 式 (1) 给 \(\|e^{u/2}\mathbf1_{E_p}\|_2^2=pk_p\asymp p^2\)；又 \(e^{u/2}\asymp p\) 于各槽，故 \(g_p\) 的槽内大小与导数均为 \(O(1)\)。全部 \(O(p^2)\) 个槽端点的跳跃总量为 \(O(p^2)\)；乘以 \(\cos(tu)\) 增加至多 \(O(|t||V_p|)\) 的内部变差。因此
\(\|g_{p,t}\|_2\le\sqrt2\)、\(\operatorname{Var}(g_{p,t}(2H+\cdot))\ll p^2+|t|\)。对固定 \(A\) 选 \(B>\max\{2,A\}\)，把 \(g_{p,t}/\sqrt2\) 代入 (2a) 即得 (2b)。\(\square\)

## 边界

式 (1) 是自然低频 Rayleigh 值的相对素数主项，不是全部槽轮廓的算子下界。式 (2) 只加强中心化素数算子的线性负谱；与完整 Weil 形式比较时，必须在同一调制向量上计入随频率增长的 Archimedean 成本。moving-\(N\) Möbius signed covariance 的高分母小分子门仍独立开放。
