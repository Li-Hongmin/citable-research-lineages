# 完整奇数源观察的高既约比例及互素单层有精确正负极限

日期：2026-10-02。依赖 [scratch/926](926-odd-source-normal-form-for-the-complete-two-arm-observation.md) 式 (4)、(9)--(12) 和 [note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md) 核对的 Matomäki--Shao--Tao--Teräväinen 2023 Theorem 1.1(i)。这是完整配对后的真实奇数源 Gram 的一个子块定理；它不估计完整 signed covariance 到固定幂目标，也不证明 RH。证明尚未异源复核。

## 命题

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，$\psi\in C_c^3((1,2))$ 为非负函数，并假设它在某个闭区间 $J\Subset(6/5,2)$ 上严格为正。置 $\phi(x)=\psi(x)/x$。令 $\eta\in C_c^2(\mathbb R)$ 为固定非负偶函数，支撑于 $1/2\le |t|\le4$，且 $\eta\ge1$ 于 $1\le|t|\le2$；写 $w_H(h)=\eta(h/H)$。取
\[
L=\left\lfloor\frac{M}{128H}\right\rfloor,
\qquad R=\left\lfloor\frac{H^2}{\log^4M}\right\rfloor,
\qquad U_M=\{u\text{ odd}:3u/M\in J\}.
\tag{1}
\]
对 $u,v\in U_M$，记 $g=(u,v)$、$a=u/g$、$b=v/g$，并令 $G_{u,v}$ 为 scratch/926 式 (12) 前定义的完整两臂 Gram。将
\[
C^\pm_{M,H}:=
\sum_{\substack{u,v\in U_M,\ u\ne v,\ |u-v|\le L\\
\max(a,b)>R,\ \mu(u)\mu(v)=\pm1}}
\mu(u)\mu(v)G_{u,v}.
\tag{2}
\]
则一致于上述 $H$，当 $M\to\infty$ 时
\[
\boxed{\quad C^+_{M,H}\gg_{\psi,\eta}1,
\qquad -C^-_{M,H}\gg_{\psi,\eta}1,
\qquad C^+_{M,H}+C^-_{M,H}=o_{\psi,\eta}(1).\quad}
\tag{3}
\]
实际上可给出两个符号块的精确极限。记 $\kappa=-4\log(3/2)$、$\rho=4/\pi^2$，并定义
\[
\mathscr C_{\psi,\eta,J}
=\frac{\kappa^2\rho^2}{3}
\left(\int_J\phi(x)^2\,dx\right)
\left(\int_{-1/128}^{1/128}\int_{\mathbb R}
\eta(t)\cos(6\pi tz)\,dt\,dz\right)>0.
\tag{3a}
\]
则 $C^+_{M,H}=\mathscr C_{\psi,\eta,J}/2+o(1)$ 且
$C^-_{M,H}=-\mathscr C_{\psi,\eta,J}/2+o(1)$，误差对所述 $H$ 一致。
特别地，scratch/926 式 (12) 的高既约比例部分，即使限制在这一个真实 odd-source cofactor-$3$ 扇区，逐项绝对质量也为 $\Omega(1)$。若 $H\le Y^{1/4-\theta}$ 且 $\theta>0$ 固定，目标 $H^4/M\ll M^{-4\theta}$；因此只用 $|\mu|\le1$、平方自由密度与带通核近对角正性来绝对支付这个部分，量纲上必然失败。式 (3) 同时证明其近距离净和已由真实 Möbius 符号抵消到 $o(1)$；现成短区间输入仍不提供目标所需的固定幂速率。

## 证明

因为 $u/M\in J/3\Subset(2/5,2/3)$，scratch/926 式 (4) 的奇臂只有 $t=3$：$t\ge5$ 将使 $ut>2M$。偶臂在 $u>M/3$ 时为空。因此令 $\kappa=-4\log(3/2)$，对所有 $u\in U_M$ 精确有
\[
\mathcal K_h(u)=\frac{\kappa}{M}\phi(3u/M)e(-3hu/M),
\qquad
G_{u,v}=\frac{\kappa^2}{M^2}\phi(3u/M)\phi(3v/M)
J_H(3(u-v)),
\tag{4}
\]
其中 $J_H(r)=\sum_h w_H(h)e(-hr/M)$。当 $|u-v|\le L$ 且 $w_H(h)\ne0$ 时，
\[
\left|\frac{2\pi h\,3(u-v)}M\right|
\le\frac{3\pi}{16}<\frac\pi2.
\]
由 $w_H$ 偶且非负、在 $H\le|h|\le2H$ 至少为 $1$，有 $J_H(3(u-v))\gg_\eta H$。又 $\phi\ge c_{\psi,J}>0$ 于 $J$，故此范围内 $G_{u,v}\gg_{\psi,\eta}H/M^2>0$。

将 $MJ/3$ 内的整数分成长度 $L$ 的不交整格，舍弃至多两个边界残格。整格数 $\asymp_J M/L\asymp H$。对每个整格 $I$，平方自由数的初等计数给
\[
\sum_{\substack{u\in I\\u\ {\rm odd}}}\mu(u)^2
=\frac4{\pi^2}L+O(\sqrt M).
\tag{5}
\]
这里 $L\asymp M/H\ge M^{3/4}$，故误差为 $o(L)$。note 835 所列 2023 Theorem 1.1(i) 的全区间等差进程界，取模数 $2$、进程为奇数，给任意固定 $A>0$ 的一致估计
\[
\sum_{\substack{u\in I\\u\ {\rm odd}}}\mu(u)
\ll_{A}\frac{L}{\log^A M}.
\tag{6}
\]
确切地说，在定理的 $M^{5/8+\epsilon}\le L\le M^{1-\epsilon}$ 范围内取固定 $\epsilon=1/100$；此范围对上述 $H$ 一致成立，也适用于下文的 $B=M^{2/3+o(1)}$。式 (5)--(6) 使每个整格里的 $\mu=+1$ 与 $\mu=-1$ 个数都为 $(2/\pi^2+o(1))L$。

于是每个整格各有 $\gg L^2$ 个异指标同号有序对及 $\gg L^2$ 个异号有序对。式 (4) 使同号对在 (2) 中贡献正数、异号对贡献负数，且每对的绝对值 $\gg H/M^2$。先不加 $\max(a,b)>R$ 限制，各类贡献的绝对值均至少
\[
\frac{H}{M^2}\cdot\frac ML\cdot L^2
\asymp\frac{HL}{M}\asymp1.
\tag{7}
\]
在这个近距离 $t=3$ 扇区，小比例对还可直接支付到固定幂以下。写 $u=ag,v=bg$。因 $u,v\asymp M$ 且 $\max(a,b)\le R$，有 $g\gg M/R$。固定 $g$ 时，$a$ 至多有 $O(M/g)$ 个选择，而 $|a-b|\le L/g$ 使每个 $a$ 的 $b$ 至多有 $O(1+L/g)$ 个选择。式 (4) 又给 $|G_{u,v}|\ll H/M^2$，故
\[
\sum_{\substack{u,v\in U_M,\ |u-v|\le L\\
\max(a,b)\le R}}|G_{u,v}|
\ll\frac H{M^2}\sum_{M/R\ll g\ll M}
\frac Mg\left(1+\frac Lg\right)
\ll\frac{H\log M}{M}+\frac RM
\ll M^{-1/2}\log M.
\tag{7a}
\]
最后一项对 $H\le Y^{1/4}$ 一致。删除这些小比例对及对角后，两个下界仍成立；此处比 scratch/926 式 (10) 的全源绝对界更强，因为同时利用了 $u,v\asymp M$ 和 $|u-v|\le L$。

还需证明净和趋零。先保留所有 $u,v\in U_M$、$|u-v|\le L$ 的对。对固定 $u$，$v$ 位于长度至多 $2L$ 的奇数等差进程。把它分成长 $B=\lfloor M^{2/3}\rfloor$ 的整块和至多两个余块；对整块用上述全区间定理，对余块用平凡界 $O(B)$。因 $B=o(L\log^{-A}M)$，任意此类进程的所有前缀满足
\[
\sup_{I\subset[u-L,u+L]\ {\rm interval}}
\left|\sum_{\substack{v\in I\\v\ {\rm odd}}}\mu(v)\right|
\ll_A L\log^{-A}M.
\tag{8}
\]
作为 $v$ 的权，$\phi(3v/M)J_H(3(u-v))$ 的上确界及总变差均为 $O_{\psi,\eta}(H)$：$|J_H|\ll H$，$|J_H'(r)|\ll H^2/M$，而 $L H/M\ll1$。分部求和使固定 $u$ 的带权内和为 $O_A(HL\log^{-A}M)$。再对 $O(M)$ 个 $u$ 求和、乘式 (4) 的 $M^{-2}$，得到整个近距离 signed 和为
\[
O_{A,\psi,\eta}(HL/M\log^{-A}M)=O_{A,\psi,\eta}(\log^{-A}M).
\tag{9}
\]
其中对角至多 $O_{\psi,\eta}(H/M)=o(1)$。最后删去 $\max(a,b)\le R$ 的对，其绝对质量由式 (7a) 控制，得到 $C^+_{M,H}+C^-_{M,H}=o(1)$。

为求精确极限，先计算绝对和。因式 (4) 的 $G_{u,v}>0$，忽略已有的 $o(1)$ 小比例与对角后，
\[
C^+_{M,H}-C^-_{M,H}
=\frac{\kappa^2}{M^2}
\sum_{\substack{u,v\in U_M\\|u-v|\le L}}
\mu(u)^2\mu(v)^2\phi(3u/M)\phi(3v/M)J_H(3(u-v))+o(1).
\tag{10}
\]
由式 (5) 的奇数平方自由计数，对任何位于 $u\asymp M$ 的区间 $I$，均有
$\sum_{u\in I,\ u\ {\rm odd}}\mu(u)^2=\rho|I|+O(\sqrt M)$。
在式 (10) 的内和及外和依次分部求和，可以将两个 $\mu^2$ 替换为密度 $\rho$ 的积分，总误差 $O_{\psi,\eta}(H/\sqrt M)=o(1)$。具体说，固定 $u$ 时内权的上确界及总变差均为 $O(H)$，故内和误差为 $O(H\sqrt M)$；对 $O(M)$ 个 $u$ 求和并除以 $M^2$，得到 $O(H/\sqrt M)$。内和替换后，外权上确界为 $O(HL)=O(M)$，总变差为 $O(HM)$，其中包含 $|u-v|=L$ 的移动端点；外和替换的归一化误差也为 $O(H/\sqrt M)$。

令 $x=3u/M\in J$、$z=H(v-u)/M$。有 $HL/M\to1/128$、$\phi(3v/M)=\phi(x)+O(H^{-1})$；$v\in U_M$ 的边界只切去比例 $O(H^{-1})$ 的区域。由 $\eta\in C_c^2$，一致于 $|z|\le1/128$ 的黎曼和给
\[
H^{-1}J_H(-3Mz/H)\longrightarrow
\int_{\mathbb R}\eta(t)\cos(6\pi tz)\,dt.
\tag{11}
\]
变量替换的 Jacobian 为 $du\,dv=(M^2/(3H))\,dx\,dz$，故式 (10) 趋于式 (3a) 的 $\mathscr C_{\psi,\eta,J}$。它严格为正：$|t|\le4$、$|z|\le1/128$ 蕴含 $|6\pi tz|\le3\pi/16<\pi/2$。结合净和 $o(1)$，得到式 (3a) 后的两个精确极限。$\square$

## 共同因子 $g=1$ 的单层极限

式 (2) 的高比例部分还可缩到单独的 $(u,v)=1$ 层。定义
\[
P^\pm_{M,H}:=
\sum_{\substack{u,v\in U_M,\ |u-v|\le L,\ (u,v)=1\\
\mu(u)\mu(v)=\pm1}}
\mu(u)\mu(v)G_{u,v}.
\tag{12}
\]
因为 $u,v\asymp M$ 而 $R\ll M^{1/2}$，这些对全部位于式 (2) 的高既约比例区。令
\[
\mathcal I_{\psi,\eta,J}
=\frac{\kappa^2}{3}
\left(\int_J\phi(x)^2\,dx\right)
\left(\int_{-1/128}^{1/128}\int_{\mathbb R}
\eta(t)\cos(6\pi tz)\,dt\,dz\right)>0,
\qquad
\delta_{\rm cop}
=\frac14\prod_{\substack{p\ {\rm prime}\\p\ge3}}
\left(1-\frac3{p^2}+\frac2{p^3}\right)>0.
\tag{13}
\]
则仍一致于 $Y^{1/5}\le H\le Y^{1/4}$，
\[
\boxed{\quad
P^+_{M,H}=\tfrac12\delta_{\rm cop}\mathcal I_{\psi,\eta,J}+o(1),
\qquad
P^-_{M,H}=-\tfrac12\delta_{\rm cop}\mathcal I_{\psi,\eta,J}+o(1).
\quad}
\tag{14}
\]
所以正负常量块及其净消去已经发生在单独的 $g=1$ 层，毋须在不同共同因子之间求和。

证明先固定素数截断 $Z\ge3$，仅排除 $u,v$ 的共同素因子 $p\le Z$。令 $q_Z=2\prod_{3\le p\le Z}p$。平方自由数在模 $q_Z$ 的每个固定剩余类里有自然密度，且长度为 $O(M)$ 的区间计数误差为 $O_Z(\sqrt M)$：展开 $\mu^2(n)=\sum_{d^2\mid n}\mu(d)$，逐 $d\le\sqrt M$ 计数剩余类即可。对式 (10) 的双和按这些剩余类两次分部求和，重复式 (10)--(11) 的连续极限，得到绝对质量
\[
\delta_Z\mathcal I_{\psi,\eta,J}+o_Z(1),\qquad
\delta_Z=\frac14
\prod_{\substack{3\le p\le Z\\p\ {\rm prime}}}
\left(1-\frac3{p^2}+\frac2{p^3}\right)
\prod_{\substack{p>Z\\p\ {\rm prime}}}
\left(1-\frac1{p^2}\right)^2.
\tag{15}
\]
这里 $p=2$ 的因子 $1/4$ 强制两个源均为奇数；对 $3\le p\le Z$，局部允许两数都不被 $p$ 整除，或恰有其中一个被 $p$ 整除一次，其密度是 $(1-1/p)^2(1+2/p)$。对 $p>Z$ 只要求两数各自平方自由，故局部因子是 $(1-1/p^2)^2$。于是 $\delta_Z\to\delta_{\rm cop}$。

从“小素数互素”切到真正 $(u,v)=1$ 的误差也受控。若一对数有共同素因子 $p>Z$，对每个这样的 $p\ll M$，候选对数至多
$(M/p+1)(L/p+1)$。式 (4) 给每对 $|G_{u,v}|\ll H/M^2$，所以由 $\sum_{n>Z}n^{-2}\ll Z^{-1}$ 和平凡的 $\sum_{p\le M}p^{-1}\ll\log M$，
\[
\sum_{\substack{u,v\in U_M,\ |u-v|\le L\\
\exists p>Z:\ p\mid u,\ p\mid v}}
|G_{u,v}|
\ll_{\psi,\eta}\frac1Z+\frac{H\log M}{M}
+\frac{\log M}{M}+\frac HM
=O_{\psi,\eta}(Z^{-1})+o(1).
\tag{16}
\]
先令 $M\to\infty$、再令 $Z\to\infty$，便得真正互素层的绝对质量趋于式 (13) 的 $\delta_{\rm cop}\mathcal I_{\psi,\eta,J}$。

最后证明互素层的净 signed 和为 $o(1)$。对固定 $Z$，小素数互素条件是模 $q_Z$ 的周期条件。固定 $u$ 后，允许的 $v$ 是有限个模 $q_Z$ 等差进程。note 835 的 2023 全区间 Möbius 定理对每个这种固定模数进程及其前缀给 $O_{A,Z}(L\log^{-A}M)$；与式 (8)--(9) 相同的分部求和使这一层净和为 $o_Z(1)$。真正互素条件与小素数条件的 signed 和之差，其绝对值由式 (16) 控制。先令 $M\to\infty$，再令 $Z\to\infty$，得到净和为 $o(1)$。联立绝对和极限，得到式 (14)。$\square$

## 大共同因子可在目标量级绝对支付

在同一个 $t=3$ 近距离扇区，还可给出随共同因子阈值变化的统一界：任取 $1\le G_0\le M$，
\[
\boxed{\quad
\sum_{\substack{u,v\in U_M,\ 0<|u-v|\le L\\(u,v)>G_0}}
|\mu(u)\mu(v)G_{u,v}|
\ll_{\psi,\eta,J}\frac1{G_0}.
\quad}
\tag{17}
\]
证明只需按 $g=(u,v)$ 分层并放宽互素限制。固定 $g$ 时，$u=ag\in U_M$ 的选择至多 $O(M/g)$ 个；对 $u\ne v$，每个 $a$ 的 $b=v/g$ 至多有 $O(L/g)$ 个选择，且 $g>L$ 时没有候选。式 (4) 对每对给 $|G_{u,v}|\ll H/M^2$，故左侧至多
\[
\frac{H}{M^2}
\sum_{G_0<g\le L}\frac{ML}{g^2}
\ll\frac{HL}{M G_0}\ll\frac1{G_0}.
\]
事实上，式 (17) 对这个 $t=3$ 扇区的**全部非对角频带 Gram**仍成立，去掉 $|u-v|\le L$ 也无需改变右侧：
\[
\boxed{\quad
\sum_{\substack{u,v\in U_M,\ u\ne v\\(u,v)>G_0}}
|\mu(u)\mu(v)G_{u,v}|
\ll_{\psi,\eta,J}G_0^{-1}.
\quad}
\tag{18}
\]
证明由 Poisson 求和及 $\eta\in C_c^2$ 得
\[
|J_H(3(u-v))|
\ll_{\eta,J}H\left(1+\frac{H|u-v|}{M}\right)^{-2}.
\tag{19}
\]
这里 $3|u-v|/M\le |J|<4/5$，与任何非零整数别名保持固定距离；最邻近整数的距离也与 $|u-v|/M$ 可比。固定 $g=(u,v)>G_0$，$u=ag\in U_M$ 只有 $O(M/g)$ 个选择。放宽 $(a,b)=1$ 后，对每个 $a$ 的非对角 $b$，令 $\alpha=Hg/M$，有
$\sum_{b\ne a}(1+\alpha|a-b|)^{-2}\ll\alpha^{-1}=M/(Hg)$。
将此与式 (4) 相乘，固定 $g$ 的绝对质量为 $O(g^{-2})$；对 $g>G_0$ 求和即得 (18)。取 $G_0=\max\{1,\lceil M/H^4\rceil\}$，所有更大的共同因子在**完整 $t=3$ 频带 Gram**中绝对支付到 $O(H^4/M)$。当 $H\asymp M^{1/5}$ 时，只余 $g\lesssim M^{1/5}$；这比 scratch/926 的全源小既约比例截断 $g\gtrsim M/H^2$ 更窄，但只适用于本稿选定的单 cofactor 扇区。

## 决策边界

高既约比例并非由于无精确物理碰撞或核振荡而自动稀疏；完整配对后保留下来的真实单 cofactor 扇区，甚至其 $g=1$ 单层，已有常量级近距离正、负质量。式 (18) 将这个**完整 $t=3$ 频带扇区**的未付共同因子缩到 $g\lesssim M/H^4$，但不缩小其他 cofactor 扇区的范围。近距离截断会引入低频泄漏：[note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (27)--(28) 的光滑正系数已有“近块为常量、整段频带超多项式小”的反例。因此单独要求本稿的 $g=1$ 近块达到 $O(H^4/M)$ 是比真实门更强、未经证明为必要的命题。真实下一步是保留远距离核的负瓣及其与其他源扇区的交叉，直接估计完整 signed Gram；对本稿的正负近块逐项取绝对值不会成功。
完整两臂的对应大共同因子缩域见 [scratch/928](928-large-gcd-tail-of-the-complete-odd-source-two-arm-gram.md)。
