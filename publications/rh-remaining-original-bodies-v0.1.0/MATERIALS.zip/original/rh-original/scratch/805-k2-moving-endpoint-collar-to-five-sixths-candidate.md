# \(k=2\) moving 端点 collar 可无条件支付至 \(Y^{5/6}\)（候选）

日期：2026-09-29。依赖 [note 730](../notes/730-k2-high-divisor-endpoint-layer-is-a-boundary-free-two-frequency-mobius-kernel.md) 的真实 \(d>N/2\) 核与端点展开、[note 762](../notes/762-reciprocal-frequency-spacing-pays-low-divisors-to-four-fifths.md) 的低除数均方界，以及 [note 753](../notes/753-high-divisor-k2-gate-is-the-k2-residual-up-to-negligible-low-layer.md) 的完整层恒等式。这是可丢弃层中的解析证明候选，未作异源复核。

## 命题

令 \(Y\ge4\) 为整数，\(1\le W\le Y/4\) 为整数，\(|c_d|\le1\)，并令
\[
 E_{N,W}(c):=\sum_{N-W\le d<N}c_d\Phi(d/N),
 \qquad Y<N\le2Y,
\]
其中 \(\Phi(t)=\log t\,\mathscr S(1/t)\) 是 note 760 的完整真实核。则
\[
 \boxed{\sum_{Y<N\le2Y}|E_{N,W}(c)|^2\ll W^6/Y^3.}\tag{1}
\]
特别地，\(W=\lfloor Y^{5/6}\rfloor\) 时，真实 \(c_d=\mu(d)\) 的整个端点层均方为 \(O(Y^2)\)。该层内部完整的 \(d\ne e\) signed covariance 也为 \(O(Y^2)\)。

指数 \(5/6\) 对所有 \(|c_d|\le1\) 的统一估计是尖锐的。若 \(W\to\infty\)、\(W=o(Y)\)，取固定的全局系数 \(c_d=1\)，则
\[
 \boxed{\sum_{Y<N\le2Y}|E_{N,W}(1)|^2
 \sim \frac{14\pi^2}{27}\frac{W^6}{Y^3}.}\tag{2}
\]

**协方差本身的不同尺度。** 对实系数 \(|c_d|\le1\) 及 \(0\le D<Y-W\)，令 \(\mathcal C_D(Y;c)\) 是 note 732 的完整 \(D<d,e<N\)、\(d\ne e\) 非对角和，令 \(\mathcal C_{D,W}^{\rm mid}(Y;c)\) 是只保留 \(D<d,e<N-W\) 的同一个和。则
\[
 \boxed{|\mathcal C_D(Y;c)-\mathcal C_{D,W}^{\rm mid}(Y;c)|\ll W^3.}\tag{2a}
\]
所以宽 \(\lfloor Y^{2/3}\rfloor\) 的 collar 可以从**真实 \(\mu\) 的协方差式本身**移除，代价为 \(O(Y^2)\)。指数 \(2/3\) 对统一 \(|c_d|\le1\) 的协方差比较也是尖锐的：取 \(D=\lfloor Y^{4/5}\rfloor\)、\(c_d=1\)，若 \(W\to\infty\)、\(W=o(Y)\)，则
\[
 \boxed{\mathcal C_D(Y;1)-\mathcal C_{D,W}^{\rm mid}(Y;1)
 \sim\frac{8\pi K\log2}{3}W^3>0.}\tag{2b}
\]
这里 \(K>0\) 如下文。式 (2a) 与 (1) 的指数不同，因为前者必须支付 collar 与中央层之间的交叉项。

记 \(D=\lfloor Y^{4/5}\rfloor\)、\(W=\lfloor Y^{5/6}\rfloor\)，并定义中央层
\[
 B_N=\sum_{D<d<N-W}\mu(d)\Phi(d/N).
\]
则对每个 \(\varepsilon>0\)，有严格的目标量级等价
\[
 \boxed{
 \sum_{Y<N\le2Y}|B_N|^2\ll_\varepsilon Y^{2+\varepsilon}
 \quad\Longleftrightarrow\quad
 \sum_{Y<N\le2Y}|\mathcal R_{N,2}|^2
 \ll_\varepsilon Y^{2+\varepsilon}.}\tag{3}
\]
因此在真实 \(k=2\) 门中，\(d\le Y^{4/5}\) 与 \(N-d\le Y^{5/6}\) 两端可同时支付；剩余是中央层及其内部的有符号协方差。式 (3) 是门的缩域，不是该门的证明。

**真实符号的中央层交叉项。** 令 \(P_N=-\sum_{D<p<N-W}\Phi(p/N)\) 为 \(B_N\) 的素数部分，\(C_N=B_N-P_N\)。沿用 [note 767](../notes/767-cubic-over-log-squared-covariance-in-the-actual-high-divisor-gate.md) 的严格正数 \(K=\int_0^1\Phi(t)dt\)。则
\[
 \boxed{\sum_{Y<N\le2Y}P_NC_N
 =-\frac{7K^2}{3}\frac{Y^3}{\log^2Y}
 +O\!\left(\frac{Y^3}{\log^3Y}\right).}\tag{3a}
\]
该负主项在剔除 \(d\le D\) 与 \(N-d\le W\) 后仍完整存在。若按 note 767 展开为 product \(n=ap,m=be\)，再只保留 \(|n-m|>Y/\log^8Y\) 的配对，(3a) 的主项仍不变，误差仍为 \(O(Y^3/\log^3Y)\)。这是实际中央层中保留 \(\mu(p)\mu(e)\) 的有符号估计；它没有给出 \(\sum|B_N|^2\) 的上界。

## 证明

若 \(d=N-h\)、\(1\le h\le W\le N/4\)，则 \(u=h/N<1/3\)。note 730 的精确式 (5)--(6) 给出
\[
 \Phi((N-h)/N)=L(u),\qquad
 L(u)=\log\frac1{1-u}\sin(4\pi u).
\tag{4}
\]
当 \(0\le u\le1/4\) 时，\(\log(1/(1-u))\ll u\) 且 \(|\sin(4\pi u)|\le4\pi u\)，所以 \(|L(u)|\ll u^2\)。于是逐个 \(N\) 有
\[
 |E_{N,W}(c)|
 \le\sum_{h=1}^{W}|L(h/N)|
 \ll N^{-2}\sum_{h=1}^{W}h^2
 \ll W^3/Y^2.
\tag{5}
\]
区间 \((Y,2Y]\) 恰有 \(Y\) 个整数，故 (5) 的平方和即 (1)。

证明 (2a) 时，记 \(H_N=\sum_{D<d<N}c_d\Phi(d/N)\)、\(B_N^{(c)}=H_N-E_{N,W}(c)\)。note 728 的 \(\sum_{d<N}|\Phi(d/N)|\ll N\) 给出 \(|B_N^{(c)}|\ll Y\)。平方展开并扣除各自的 divisor 对角项，得到精确恒等式
\[
 \mathcal C_D(Y;c)-\mathcal C_{D,W}^{\rm mid}(Y;c)
 =2\sum_{Y<N\le2Y}B_N^{(c)}E_{N,W}(c)
 +\sum_{Y<N\le2Y}E_{N,W}(c)^2
 -\sum_{Y<N\le2Y}\sum_{h\le W}c_{N-h}^2L(h/N)^2.
\]
第一项由 (5) 为 \(O(W^3)\)；后两项分别为 \(O(W^6/Y^3)\) 与 \(O(W^5/Y^3)\)，在 \(W\le Y/4\) 时也都为 \(O(W^3)\)。

为证尖锐的 (2b)，由 note 760 的变差界，对 \(\Phi\) 作 Riemann 和比较，得到 \(\sum_{d<N}\Phi(d/N)=NK+O(\log^2N)\)。note 729 的 \(|\Phi(d/N)|\ll(d/N)\log(N/d)\) 对 \(d\le D\le N/2\) 又给出
\[
 \sum_{d\le D}|\Phi(d/N)|\ll D^2N^{-1}\log(N/D)=o(Y)
 \quad(D=Y^{4/5}+O(1)).
\]
故 \(H_N=NK+o(Y)\) 对所有 \(Y<N\le2Y\) 一致。由 (2) 的逐点证明，\(E_{N,W}(1)=\frac{4\pi W^3}{3N^2}(1+o(1))\) 一致。将 \(B_N^{(1)}=H_N-E_{N,W}(1)\) 代入上式，后两项及 \(E^2\) 都是 \(o(W^3)\)，而
\[
 2\sum_{Y<N\le2Y}H_NE_{N,W}(1)
 =\left(\frac{8\pi K}{3}+o(1)\right)W^3
   \sum_{Y<N\le2Y}\frac1N
 =\left(\frac{8\pi K\log2}{3}+o(1)\right)W^3.
\]
这证明 (2b)。

对该层展开平方，写能量为对角加有符号非对角项 \(\mathcal D_E+\mathcal C_E\)。由 (4) 与 \(|\mu|\le1\)，
\[
 0\le\mathcal D_E
 \ll\sum_{Y<N\le2Y}\sum_{h\le W}(h/N)^4
 \ll W^5/Y^3.
\]
故对真实 \(c=\mu\) 而言，\(|\mathcal C_E|\le \sum_N|E_{N,W}(\mu)|^2+\mathcal D_E\ll W^6/Y^3\)；在 \(W=Y^{5/6}+O(1)\) 时为 \(O(Y^2)\)。这里未估计端点层与中央层之间的交叉项。

当 \(W=o(Y)\) 时，(4) 在整个 \(h\le W\) 上一致给出
\[
 L(h/N)=4\pi(h/N)^2+O((h/N)^3).
\]
因而 \(c_d=1\) 时，一致地有
\[
 E_{N,W}(1)
 =\frac{4\pi}{N^2}\sum_{h\le W}h^2
  +O\!\left(\frac1{N^3}\sum_{h\le W}h^3\right)
 =\frac{4\pi W^3}{3N^2}
 \left(1+O\!\left(\frac1W+\frac WY\right)\right).
\]
又 \(\sum_{Y<N\le2Y}N^{-4}=\frac7{24}Y^{-3}+O(Y^{-4})\)。平方后求和得到 (2)。若 \(W=Y^\beta\)、\(\beta>5/6\)，(2) 的指数是 \(6\beta-3>2\)；故无符号统一支付不能越过 \(5/6\)。

最后，由 note 753 的 \(\mathcal R_{N,2}=\sum_{d<N}\mu(d)\Phi(d/N)\)，当 \(Y\) 足够大时 \(D<N-W\)，逐 \(N\) 有
\[
 \mathcal R_{N,2}
 =\sum_{d\le D}\mu(d)\Phi(d/N)+B_N+E_{N,W}(\mu).
\]
note 762 将第一项的平方和界为 \(O(Y^2\log^3(2Y))\)，(1) 将第三项界为 \(O(Y^2)\)。两次使用 \(|a+b|^2\le2|a|^2+2|b|^2\)，并以任意 \(\varepsilon>0\) 吸收对数，证明 (3)。\(\square\)

为证 (3a)，令 \(H_D=\sum_{D<d<N}\mu(d)\Phi(d/N)\)，并沿用 note 767 的素数部分 \(P_D\)。该 note 在 \(D=Y^{4/5}\) 给出
\[
 P_D(N)=-K\frac N{\log N}+O(N/\log^2Y),
 \qquad H_D(N)=o(N/\log^A Y)
\]
对每个固定 \(A>0\) 成立。由 (5)，从两者删去 collar 的误差逐 \(N\) 至多为 \(O(Y^{1/2})\)。故同样有
\[
 P_N=-K\frac N{\log N}+O(N/\log^2Y),
 \qquad B_N=o(N/\log^A Y),
 \qquad C_N=K\frac N{\log N}+O(N/\log^2Y).
\]
逐 \(N\) 相乘，再用 \(\sum_{Y<N\le2Y}N^2/\log^2N=\frac73Y^3/\log^2Y+O(Y^3/\log^3Y)\)，即得 (3a)。

对远 product 陈述，从 note 767 的远配对式中删去至少一端位于 collar 的项。collar 中只有 \(a=2\) cofactor，因此逐 \(N\) 的全部绝对质量由 (5) 控制为 \(O(Y^{1/2})\)。所有高除数项在逐 cofactor 展开后的绝对质量至多
\[
 \sum_{D<d<N}\log(N/d)\#\{a:N/d<a<2N/d\}
 \ll N\sum_{D<d<N}\frac{\log(N/d)}d
 \ll Y\log^2Y.
\]
删去的交叉配对绝对质量在所有 \(N\) 上因此为 \(O(Y^{5/2}\log^2Y)=O(Y^3/\log^3Y)\)，与 product 位移限制无关。note 767 的 \(|n-m|>Y/\log^8Y\) 公式遂传给中央层。\(\square\)

## 承重边界

(1) 是对真实 \(\mu\) 有效的局部 signed covariance 上界，但证明只用了 \(|\mu|\le1\)。(2a) 可以从完整协方差中直接移除宽 \(Y^{2/3}\) 的 collar；对宽 \(Y^{5/6}\) 的 collar，中央层交叉项尚未单独控制。(3a) 的负交叉项利用了真实 \(\mu\) 与素数定理，仍只抵消选定的素数通道，不能当作中央层完整协方差的上界。(3) 只说明在目标**完整均方**中可以通过三角不等式移除更宽的 collar。中央层仍含 \(a=2\) 的宏观内部区间，故这些结论不证明 RH 或全尺度局部 Weil 正性。
