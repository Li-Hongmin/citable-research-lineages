# 多项式对数以下的素数奇偶部分在完整两臂门中可支付

日期：2026-10-02。依赖 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的完整奇数源两臂核、[scratch/931](931-squarefree-mask-complete-two-arm-band-below-target.md) 的平方自由 Fourier 引理与光滑 cofactor 截断。本稿证明一个真实 Möbius 源的目标精度分解；留下的余项仍未估计，故不证明 moving-\(N\) 算术门、全尺度局部 Weil 正性或 RH。尚待独立复核。

## 命题

令 \(M=2Y\)、\(Y^{1/5}\le H\le Y^{1/4}\)、\(D=\lfloor M/(32H)\rfloor\)，固定 \(\psi\in C_c^3((1,2))\)，\(\phi(x)=\psi(x)/x\)。令 \(\mathcal K_h(u)\) 为 note 850 的完整奇、偶物理臂合成核，并取固定有界非负频带权 \(w_H(h)=\eta(h/H)\)，支撑于 \(H/2\le|h|\le4H\)。

对任意固定 \(0<A<8/3\)，令
\[
Q=(\log(2M))^A,\qquad
\epsilon_Q(u)=(-1)^{\#\{p\le Q:p\mid u\}},\qquad
f_Q(u)=\mu(u)^2\epsilon_Q(u),
\]
并定义完整两臂源包
\[
F_{h,Q}=\sum_{\substack{D<u<2M/3\\u\ {\rm odd}}}f_Q(u)\mathcal K_h(u).
\]
则一致于给定的 \(H\) 区间，
\[
\boxed{\quad
\sum_h w_H(h)|F_{h,Q}|^2
=o_{\psi,\eta,A}\!\left(\frac{H^4}{M}\right).
\quad} \tag{1}
\]
更具体地，对任意固定
\[
\frac38<\sigma<\min\left(\frac12,\frac1A\right)
\tag{2}
\]
均有
\[
\sum_h w_H(h)|F_{h,Q}|^2
\ll_{\psi,\eta,A,\sigma}
M^{o(1)}
\left(H^{-5}+M^{-2\sigma}H^{2\sigma+2}\right);
\tag{3}
\]
这里 \(M^{o(1)}\) 对全部所述 \(H\) 一致。

特别取 \(Q=(\log(2M))^2\)、\(\sigma=2/5\)，式 (3) 的右侧与目标 \(H^4/M\) 之比为 \(O(M^{-1/25+o(1)})\)。

## 卷积恒等式

定义乘法函数 \(b_Q\)：
\[
b_Q(1)=1,\qquad
b_Q(p^j)=
\begin{cases}
2(-1)^j,&p\le Q,\ j\ge1,\\
0,&p>Q,\ j\ge1.
\end{cases}
\tag{4}
\]
那么
\[
\boxed{\quad f_Q=\mu^2*b_Q.\quad} \tag{5}
\]
确实，对 \(p\le Q\)，两边局部生成函数为
\[
(1+x)\left(1+2\sum_{j\ge1}(-x)^j\right)
=(1+x)\frac{1-x}{1+x}=1-x.
\]
这正是 \(f_Q(p)=-1\)、\(f_Q(p^j)=0\ (j\ge2)\)。对 \(p>Q\)，局部生成函数为 \(1+x\)，正是 \(f_Q(p)=+1\)、高次素数幂为零。乘法性给 (5)。

对 \(0<\sigma<1/2\)，其绝对 Dirichlet 质量满足
\[
E_Q(\sigma):=\sum_{d\ge1}\frac{|b_Q(d)|}{d^{1-\sigma}}
=\prod_{p\le Q}\frac{1+p^{\sigma-1}}{1-p^{\sigma-1}}
\le\exp(C_\sigma Q^\sigma).
\tag{6}
\]
最后一步由 \(\log[(1+x)/(1-x)]\ll_\sigma x\) 对 \(x=p^{\sigma-1}\le2^{-1/2}\)，以及
\(\sum_{p\le Q}p^{\sigma-1}\le\sum_{n\le Q}n^{\sigma-1}\ll_\sigma Q^\sigma\) 得到。若 \(Q=(\log(2M))^A\)、\(A\sigma<1\)，则 \(E_Q(\sigma)=M^{o(1)}\)，且 \(E_Q(0)\le E_Q(\sigma)\)。

## 平方自由包的统一尺度界

对 \(X\ge1/2\) 与 \(H/2\le|h|\le4H\)，置
\[
S_{\rm sf}(X,h)
=\sum_{u\ {\rm odd}}\mu(u)^2\phi(u/X)e(-hu/X).
\]
[scratch/931](931-squarefree-mask-complete-two-arm-band-below-target.md) 式 (3)--(5) 用平方因子展开和奇数格 Poisson 求和证明：当 \(X\ge32H\) 时，
\[
|S_{\rm sf}(X,h)|\ll_\psi XH^{-3}+\sqrt{XH}.
\tag{7}
\]
它对 \(1/2\le X<32H\) 也成立：活动正整数 \(u\in(X,2X)\) 至多 \(O(X+1)\) 个，而在此范围 \(X+1\ll\sqrt{XH}\)（\(H\to\infty\)）。因此 (7) 对所有 \(X\ge1/2\) 一致。

令
\[
S_Q(X,h)=\sum_{n\ {\rm odd}}f_Q(n)\phi(n/X)e(-hn/X).
\]
由 (5) 交换有限和，奇数 \(n\) 迫使 \(d,v\) 都为奇数，于是
\[
S_Q(X,h)
=\sum_{\substack{d\le2X\\d\ {\rm odd}}}
b_Q(d)S_{\rm sf}(X/d,h).
\tag{8}
\]
对这些 \(d\)，有 \(X/d\ge1/2\)。将 (7) 代入 (8)，第一项由 \(E_Q(0)\) 控制；第二项用 \(d\le2X\)、\(\sigma<1/2\) 的 Rankin 比较
\[
\sum_{d\le2X}\frac{|b_Q(d)|}{\sqrt d}
\le(2X)^{1/2-\sigma}E_Q(\sigma).
\]
因此
\[
|S_Q(X,h)|
\ll_{\psi,\sigma}
XH^{-3}E_Q(0)+X^{1-\sigma}H^{1/2}E_Q(\sigma).
\tag{9}
\]

## 完整 cofactor 求和与低源修正

沿 [scratch/931](931-squarefree-mask-complete-two-arm-band-below-target.md) 的光滑截断，选固定 \(\chi\in C_c^\infty([0,128))\)，\(\chi=1\) 于 \([0,64]\)。对 \(u>D\)，全部活动 cofactor \(k<64H\)，故截断不改变原核。暂解除 \(u>D\)，可将扩展源包写成
\[
\widetilde F_{h,Q}
=\frac1M\sum_{k<128H}\chi(k/H)W(k)S_Q(M/k,h),
\tag{10}
\]
其中 \(W(k)\) 是 note 850 的两臂合成权，满足 \(|W(k)|\ll\log(2k)\)。式 (9) 与
\[
\sum_{k<128H}\frac{|W(k)|}{k}\ll\log^2(2H),
\qquad
\sum_{k<128H}\frac{|W(k)|}{k^{1-\sigma}}
\ll_\sigma H^\sigma\log(2H)
\]
给出
\[
|\widetilde F_{h,Q}|
\ll_{\psi,\sigma}
H^{-3}E_Q(0)\log^2(2H)
+M^{-\sigma}H^{\sigma+1/2}E_Q(\sigma)\log(2H).
\tag{11}
\]
由于 \(|f_Q(u)|\le1\)，同一低源 Poisson 界（scratch/931 式 (7)--(8)）给
\[
|F_{h,Q}-\widetilde F_{h,Q}|
\ll_\psi H^{-3}\log^2(2M).
\tag{12}
\]
在 (2) 的 \(\sigma\) 下，(6) 给 \(E_Q(\sigma)=M^{o(1)}\)。频带只有 \(O_\eta(H)\) 个整数 \(h\)；将 (11)--(12) 平方求和便得到 (3)。

最后设 \(\gamma=\log H/\log M\)。给定范围内 \(\gamma\in[1/5+o(1),1/4+o(1)]\)。式 (3) 第二项除以 \(H^4/M\) 的 \(M\) 指数为
\[
1-2\sigma+(2\sigma-2)\gamma
\le\frac35-\frac85\sigma+o(1)<0
\qquad(\sigma>3/8).
\tag{13}
\]
第一项之比为 \(M H^{-9+o(1)}=o(1)\)。这证明 (1)。当 \(\sigma=2/5\) 时，(13) 的最大值为 \(-1/25\)，给出所述显式例子。证毕。

## 对真实 Möbius 门的含义

对全部整数 \(u\)，令
\[
\nu_Q(u)=-2\mu(u)^2\epsilon_Q(u)
\mathbf1_{\#\{p>Q:p\mid u\}\ {\rm odd}}.
\tag{14}
\]
逐点有
\[
\mu(u)=f_Q(u)+\nu_Q(u).
\tag{15}
\]
令 \(F_h^\mu,F_h^{\nu_Q}\) 为同一完整两臂核的源包。式 (1) 与带权 \(\ell^2\) 三角不等式给
\[
\boxed{\quad
\|F^\mu-F^{\nu_Q}\|_{H,\eta}
=o\!\left(\frac{H^2}{\sqrt M}\right).
\quad} \tag{16}
\]
再由 [scratch/926](926-odd-source-normal-form-for-the-complete-two-arm-observation.md) 式 (6)--(7)，[note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实联合观察包 \(\mathcal A_h(Y)\) 也满足
\[
\|\mathcal A(Y)-F^{\nu_Q}\|_{H,\eta}
=o\!\left(\frac{H^2}{\sqrt M}\right).
\tag{17}
\]
所以原始观察的 \(O(H^4/M)\) 频带门与 \(\nu_Q\) 的同量纲门等价。对 \(Q=(\log(2M))^2\)，这把可直接支付的素因子奇偶信息推进至对数平方尺度；未付的 \(\nu_Q\) 仍在整个留存位移带上保留跨乘子及两臂的真实符号相关。等价归约本身不提供 \(\nu_Q\) 的上界，也不证明 RH。
