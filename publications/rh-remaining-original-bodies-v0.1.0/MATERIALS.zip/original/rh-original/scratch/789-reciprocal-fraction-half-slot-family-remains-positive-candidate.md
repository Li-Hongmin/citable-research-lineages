# 整族倒数分数半槽仍保持正的真实旧核主压缩（已复核，待晋级）

日期：2026-09-29。依赖 [note 788](../notes/788-fractional-half-slots-force-logarithmic-complement-feedback.md) 的 \(k=p^2\) 分数半槽及算术边、[note 786](../notes/786-all-integer-same-arm-arithmetic-response-ceiling.md) 的全整数图平方分解、[note 780](../notes/780-all-prime-power-half-slots-give-nine-thirty-seconds-logarithmic-physical-inverse-response.md) 的位置无关单槽对角。

## 命题

令 \(p\to\infty\) 沿奇素数，\(k=p^2\)，\(L=\log k\)，并对全部整数 \(1\le d<p\) 设 \(v_d=u_{p/d}\)，其中 \(u_r\) 是 note 788 式 (3) 的归一化奇半槽，\(v_1=e_p\)。令 \(V_p=\operatorname{span}\{v_d:1\le d<p\}\)，\(B_p\) 为真实旧奇算子 \(A_{k,-}\) 在 \(\operatorname{span}\{v_d:2\le d<p\}\) 上的压缩。则 \(\{v_d\}\) 正交归一，且无须假定完整旧核正性便有
\[
B_p\succeq (\tfrac12+o(1))L I.
\tag{1}
\]
若 \(f_p=(\langle v_d,A_{k,-}e_p\rangle)_{2\le d<p}\)，则 \(B_p^{-1}\) 对充分大的 \(p\) 有定义，且
\[
(\tfrac18+o(1))L\ \le\ \langle f_p,B_p^{-1}f_p\rangle
\le\ \left(\frac{1-\log2}{2}+o(1)\right)L.
\tag{2}
\]
因此 \(A_{k,-}|_{V_p}\) 的 \(e_p\) Schur 枢轴至少为 \(\bigl((1+\log2)/2+o(1)\bigr)L\)，特别地整个有限维压缩严格正。式 (2) 只约束这一整族 \(p/d\) 指示半槽的有限维响应；不约束真实无限维正交补的反馈。

## 正交性与算术图

沿 note 788 的证明，对 \(1\le d,e<p\) 的下臂，其中心 \(p/d,p/e\) 不同且相隔超过宽度；上臂由反射得到相同结论。不同臂仅在 \(d=e=1\) 时接触于中点 \(t=p\)，交集测度仍为零。故 \(\{v_d\}\) 正交归一。

旧算术算子 \(\mathcal R_k=-\sum_{s\text{ 素数幂}}c_s(T_s+T_s^*)\) 在此基中的同号边精确为
\[
\langle v_d,\mathcal R_kv_e\rangle
=-\frac{\Lambda(s)}{\sqrt s}\quad
\text{当且仅当 }d=se\text{ 或 }e=sd;
\tag{3}
\]
其他同号矩阵元为零。异号边若存在，要求 \(k<s p^2/(de)<k+1\)，即
\(de<s<de+de/p^2\)，但 \(de<p^2\) 使该开区间不含整数。另一方向要求 \(sk<p^2/(de)\)，也不可能。因此完整算术压缩恰是包含单位节点 \(d=1\) 的整数乘法图。

## 非算术误差

对 \(2\le d,e<p\)，单槽 Archimedean 对角为 \(D_k+O(\Delta)\)，其中
\(D_k=L+1-\gamma_E-\log\pi\) 且 \(\Delta=\frac12\log(1+1/k)\asymp p^{-2}\)。不同槽的同号中心对数间距为 \(|\log(d/e)|\ge |d-e|/p\)，故两区间的实际距离至少为 \(|d-e|/(2p)\)，对充分大的 \(p\) 一致。由 note 780 的正核估计，相关矩阵元绝对值至多 \(C\Delta p/|d-e|\)。异号臂的距离至少为 \(\log4-O(\Delta)\)，矩阵元至多 \(C\Delta\)。因而所有行绝对和为
\[
O(\Delta p\log p)+O(p\Delta)=O(\log p/p)=o(1),
\tag{4}
\]
即 \(G_k|_{\operatorname{span}(v_2,\ldots,v_{p-1})}=D_kI+E_p\)，\(\|E_p\|=o(1)\)。根槽 \(e_p\) 的异号自交叉至多 \(O(1)\)，故 \(\langle e_p,G_ke_p\rangle=D_k+O(1)\)。

对极点向量 \(s_k(y)=\sinh(y/2)\)，note 778 的槽积分在 \(r=p/d\) 给出
\[
\langle s_k,v_d\rangle
=4F\sinh(\Delta/4)
\left(e^{-\Delta/4}d^{-1/2}-e^{\Delta/4}d^{1/2}\right),
\qquad F=(2\Delta)^{-1/2}.
\tag{5}
\]
因此 \(\sum_{2\le d<p}|\langle s_k,v_d\rangle|^2\ll
\Delta\sum_{d<p}d=O(1)\)，极点压缩的算子范数为 \(O(1)\)。在根槽，\(\langle s_k,e_p\rangle=O(p^{-3})\)，故极点对根列的范数为 \(O(p^{-3})\)（投影到此族后）。于是 \(B_p\succeq T_{k,p-1}-O(1)I\)，其中 \(T_{k,p-1}\) 是 note 786 在指标 \(2\le d<p\) 的图。其逐边平方恒等式给出
\[
T_{k,p-1}\succeq(D_k-\log(p-1)-O(1))I
=(\tfrac12+o(1))LI,
\tag{6}
\]
证明 (1)。

由 (3)，算术根列的非零项精确为 \(-c_d\)，其中 \(d<p\) 是素数幂。根列的 Archimedean 系数范数为 \(O(\sqrt p\,\Delta)=o(1)\)，极点系数范数也为 \(o(1)\)，故
\[
\|f_p\|^2=S_p+o(1)
=\left(\tfrac18+o(1)\right)L^2.
\tag{7}
\]
为取得 (2) 的上界，沿 note 786 的逐边平方预算保留素数幂节点的入边缺项，式 (6) 可加强为逐坐标下界
\[
B_p\succeq
\operatorname{diag}_{2\le d<p}
\left(\tfrac12L+\Lambda(d)-O(1)\right).
\tag{8}
\]
此处 \(\Lambda(d)=0\) 对非素数幂。写 \(f_p=-b+r_p\)，其中 \(b_d=c_d\) 且 \(\|r_p\|=o(1)\)。式 (1) 给出 \(\|B_p^{-1}\|=O(L^{-1})\)，故 \(r_p\) 对逆响应仅有 \(o(1)\) 的影响。式 (8) 与 Loewner 逆序于是给出
\[
\langle f_p,B_p^{-1}f_p\rangle
\le\sum_{\substack{d<p\\d\text{ 素数幂}}}
\frac{\Lambda(d)^2/d}{\frac12L+\Lambda(d)-O(1)}
=\left(\frac{1-\log2}{2}+o(1)\right)L.
\tag{9}
\]
末步以 \(H=\log p=L/2\) 用素数定理和 Stieltjes 分部积分化为
\(\int_0^H u/(H+u)\,du=H(1-\log2)\)；高次素数幂贡献 \(O(L^{-1})\)。以 \(g=\sum_{d\text{ 素数幂}}c_dv_d\) 测试逆度量，note 788 的 \(\langle g,Ae_p\rangle=-S_p+o(1)\)、\(\langle g,Ag\rangle\le D_kS_p+o(1)\) 给出 (2) 的下界。最后
\(\langle e_p,Ae_p\rangle=D_k+O(1)\)，由 (2) 得根 Schur 枢轴至少 \(\bigl((1+\log2)/2+o(1)\bigr)L\)。\(\square\)

## 边界

整族 \(p/d\) 分数半槽确实提供对数级反馈，但这一族自身的算术图、Archimedean 核和极点项仍使其主压缩严格正。该结论不阻止无限维补空间中的其他方向产生更大反馈，也不判定物理 collar Schur 值、全尺度局部 Weil 正性或 RH。
