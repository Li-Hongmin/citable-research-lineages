# 固定 Farey 分子斜率射线之间的真实 Möbius Gram 次幂抵消（候选）

> **量化更正（2026-09-30）：** 本稿所引 Motohashi--Ramachandra 指数型短区间 Möbius 率未从原始来源核实，note 835 已改用只给任意固定对数幂的 2023 定理。下文式 (3)、(18)--(19) 的次幂率撤回；不能以该率作为后续算术输入。同分子整带的可用对数版本见 [一分子候选](dyadic-farey-one-numerator-packet-orthogonality-candidate.md)。

日期：2026-09-30。依赖 [note 832](../notes/832-sloping-numerator-gate-for-moving-k2-farey-residual.md) 的真实斜楔、[note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md) 引用并核对的 Motohashi–Ramachandra 短区间 Möbius 界、[note 800](../notes/800-true-mobius-harmonic-collisions-pay-low-reduced-reciprocal-frequencies.md) 的一致互素调和界、[note 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 的精确同频系数、[note 802](../notes/802-moving-cutoff-log-zero-pays-low-farey-frequencies-in-full-k2-residual.md) 的移动大筛，以及[固定分子 Euler 乘子候选](leading-farey-mobius-multiplier-transfer-candidate.md)的 \(b_a\) 定义。本文先控制固定分子首阶模型的联合 Gram，再把结论转给真实有限 \(k\)-和与物理 collar；增长分子仍不在命题内。论证尚待异源复核。

固定 \(4/5<\alpha<1\) 及正整数 \(a,a'\)。令
\[
D=\lfloor Y^\alpha\rfloor,\qquad K=Y/D,
\qquad B=\lfloor D^2/Y\rfloor,
\qquad u(D)=\left(\frac{\log D}{\log\log D}\right)^{1/3}.
\tag{1}
\]
对固定分子 \(a\) 定义
\[
b_a(q)=
\begin{cases}
3\mu(q)q\varphi(q)^{-1}\mathbf1_{(a,q)=1},&2\mid a,\\
-\mu(q)q\varphi(q)^{-1}\mathbf1_{(a,q)=1}
-4\mu(q)q\varphi(q)^{-1}\mathbf1_{(a,q)=1}\mathbf1_{2\nmid q},&2\nmid a,
\end{cases}
\]
并取归一化复相位臂
\[
U_a(N;D)=\frac1N
\sum_{aD/2<q\le aD}\frac{q,b_a(q)}{a^2}
e\!\left(\frac{aN}{q}\right),
\qquad e(x)=e^{2\pi ix}.
\tag{2}
\]
\(b_a\) 已在非互素 \(q\) 上取零。只要 \(a\) 固定且 \(\alpha>4/5\)，这些频率在充分大的 \(Y\) 上均满足 note 832 的 \(q>Y^{4/5}\)、\(a<A_j\)：因为 \(q\asymp_a D\)、\(A_j\gg_a D^{5/3}/Y^{4/3}=Y^{(5\alpha-4)/3}\to\infty\)。物理裁剪归属须另按原始 \(kq\) 检查；(2) 本身是首阶模型。

**命题。** 存在 \(c_{a,a',\alpha}>0\)，使
\[
\boxed{\quad
\left|\sum_{Y<N\le2Y}U_a(N;D)
\overline{U_{a'}(N;D)}\right|
\ll_{a,a',\alpha}
\frac{D^5}{Y^2}e^{-c_{a,a',\alpha}u(D)}.
\quad}\tag{3}
\]
这包括 \(a=a'\) 的首阶单臂上界；当 \(a\ne a'\) 时，它是同一斜率 \(q/a\asymp D\) 上真正的跨分子 signed Gram 上界。对固定有限个分子及其复权线性组合，可由 (3) 得到同量纲的联合上界。该次幂节省慢于任何 \(D^{-\delta}\)，所以 (3) **没有**达到 \(Y^{2+\varepsilon}\) 目标。

## 1. 固定分子的短区间输入

对每个固定 \(a\)，\(b_a\) 是两个加权 Möbius 函数的固定线性组合。与 note 835 式 (5)--(8) 相同，存在卷积核 \(h_a,h_{a,o}\)，满足
\[
\sum_{d\ge1}\frac{|h_a(d)|+|h_{a,o}(d)|}{\sqrt d}<\infty,
\qquad
\mu(q)\frac q{\varphi(q)}\mathbf1_{(a,q)=1}=\mu*h_a,
\tag{4}
\]
奇数限制的同式使用 \(h_{a,o}\)。对 \(x\asymp_a D\)、\(x^{3/4}\le H\le x/2\)，把卷积指标在 \(d_0=x^{1/4}\) 分开。\(d\le d_0\) 时
\[
\frac{H/d}{(x/d)^{5/8}}
\ge x^{3/4-5/8-3/32}=x^{1/32},
\]
所以 note 835 所述短区间定理以固定指数 \(5/8>7/12\) 给低 \(d\) 部分 \(O_a(H e^{-cu(x)})\)。高 \(d\) 部分直接由 (4) 与 \(|\sum\mu|\le H/d+1\) 给
\(O_a(Hx^{-1/8}+x^{1/2})\)。故
\[
\sum_{x<q\le x+H}b_a(q)
\ll_a H e^{-c_a u(x)}
\qquad(x^{3/4}\le H\le x/2).
\tag{5}
\]
因为 \(B=D^{2-1/\alpha+o(1)}\gg_\alpha D^{3/4+\delta_\alpha}\)（可取 \(\delta_\alpha=(5/4-1/\alpha)/2>0\)），把任一长度在 \([B/2,B]\) 的整数块 \(I\subset(a'D/2,a'D]\) 的短前缀用 \(|b_{a'}(q)|\ll_{a'}\log\log(3D)\) 支付，长前缀用 (5)，便得
\[
\sup_{J\text{ 为 }I\text{ 的前缀}}
\left|\sum_{q\in J}b_{a'}(q)\right|
\ll_{a',\alpha}B e^{-c'_{a',\alpha}u(D)}.
\tag{6}
\]
这里把固定幂差 \(D^{3/4}/B\) 和多余的对数吸收进较小的 \(c'\)。

## 2. 移动整数采样核的变差

定义
\[
\mathcal K_Y(\theta)=\sum_{Y<N\le2Y}\frac{e(N\theta)}{N^2},
\qquad m(z)=\min(1,|z|^{-1}),\quad m(0)=1.
\tag{7}
\]
在 \(|\theta|\le C/D=o(1)\) 上，几何和与 Abel 求和给
\[
|\mathcal K_Y(\theta)|\ll Y^{-1}m(Y\theta),
\qquad
|\mathcal K_Y'(\theta)|\ll m(Y\theta).
\tag{8}
\]
确实，第一式由 \(\sum_{Y<N\le2Y}e(N\theta)\ll\min(Y,\|\theta\|^{-1})\) 与 \(N^{-2}\) 的上界及总变差给出；第二式对
\(2\pi i\sum N^{-1}e(N\theta)\) 同用 Abel 求和。这里 \(\|\theta\|=|\theta|\) 对充分大的 \(D\) 成立。

固定 \(q\in(aD/2,aD]\)，在 \(r\in(a'D/2,a'D]\) 上置
\[
\theta_q(r)=\frac aq-\frac{a'}r,
\quad z_q(r)=Y\theta_q(r),
\quad g_q(r)=\frac r{a'^2}\mathcal K_Y(\theta_q(r)).
\tag{9}
\]
则 \(z_q\) 严格递增，\(z_q'(r)\asymp_{a'}Y/D^2\asymp1/B\)，且 \(z_q\) 的全值域长度 \(O_{a,a'}(K)\)。由 (8) 与 \(r\asymp_{a'}D\) 得
\[
|g_q(r)|\ll_{a'}\frac DY m(z_q(r)),
\qquad
|g'_q(r)|\ll_{a'}\frac1D m(z_q(r)).
\tag{10}
\]
把整个 \(r\)-区间分成长度介于 \(B/2\) 与 \(B\) 的相邻整数块 \(I_j\)；因区间长度 \(\asymp_{a'}D\gg B\)，这种划分存在。\(z_q(I_j)\) 的长度 \(\asymp_{a'}1\)，不同块依次覆盖一段长度 \(O(K)\) 的实区间。由 \(\sum_{|j|\le CK}(1+|j|)^{-1}\ll\log(2K)\)、(10) 以及变量代换 \(dr\asymp B,dz\)，得到
\[
\sum_j|g_q(\sup I_j)|
+\sum_j\operatorname{Var}_{I_j}g_q
\ll_{a,a'}\frac DY\log(2K).
\tag{11}
\]
首项不能以“块数乘 \(\sup|g_q|\)”估计；必须保留 \(m(z)\) 的衰减，才能避免损失 \(K\)。

## 3. 联合 Gram

对每块应用 (6) 与 Abel 分部求和，再用 (11)，一致于外层 \(q\) 有
\[
\left|\sum_{a'D/2<r\le a'D}b_{a'}(r)g_q(r)\right|
\ll_{a,a',\alpha}
B e^{-c'u(D)}\frac DY\log(2K).
\tag{12}
\]
展开 (2) 的 Gram，内层 \(r\)-和正是 (12)，外层满足
\(\sum_{aD/2<q\le aD}|q b_a(q)|/a^2\ll_a D^2\log\log(3D)\)。故
\[
|\langle U_a,U_{a'}\rangle|
\ll_{a,a',\alpha}
D^2\log\log(3D)\cdot
B e^{-c'u(D)}\frac DY\log(2K)
\ll \frac{D^5}{Y^2}e^{-c_{a,a',\alpha}u(D)},
\]
因为 \(B\asymp D^2/Y\) 且可缩小指数常数吸收对数因子。这证明 (3)。\(\square\)

## 4. 真实有限倍数与物理 collar

对同一个固定 \(a\)，令 \(C_{a,q}^{\rm full}(t)\) 为 note 801 式 (7) 中把原始 \(d=kq\) 保留到 \(kq<t\) 的完整同频系数。令 \(C_{a,q}^{\rm phys}(N)\) 把截止改成 \(kq\le N-L\)，其中 \(L=\lfloor Y^{5/6}\rfloor\)。定义真实物理带
\[
V_a(N;D)=-\frac1{\pi N}
\sum_{aD/2<q\le aD}C_{a,q}^{\rm phys}(N)
\cos\frac{2\pi aN}{q}.
\tag{13}
\]
由于 \(a\) 固定、\(q\asymp_a D=o(Y)\)，note 801 式 (7) 的有理乘子均一致远离极点，且 \(N/q\gg_a Y^{1-\alpha}\)。note 800 的互素调和和及奇偶拆分，按 [分子一乘子候选](farey-rational-multiplier-and-collar-paid-through-eight-ninths-candidate.md) 式 (5)--(7) 的逐项导数论证，给出
\[
\begin{aligned}
R_{a,q}(t)&:=C_{a,q}^{\rm full}(t)-\frac{q,b_a(q)}{a^2},\\
|R_{a,q}(t)|&\ll_{a,\alpha}D\Delta_Y,
\qquad |R'_{a,q}(t)|\ll_{a,\alpha}\frac{D\Delta_Y}{Y}
\quad\text{a.e. on }[Y,2Y],\\
\Delta_Y&=e^{-c_{a,\alpha}(\log Y)^{3/5}(\log\log Y)^{-1/5}}
+(D/Y)^2\log\log(3Y).
\end{aligned}
\tag{14}
\]
这里新进入的 \(kq=t\) 项以零对数权开始；\(b_a(q)\) 与 \(t\) 无关。note 802 式 (4) 的移动大筛可用于 \(a/q\pmod1\)：相邻 \(q\) 的间距 \(\gg_a D^{-2}\)，而 q 数量 \(O_a(D)\)。把余弦拆成正负指数，给
\[
\left\|\frac1N\sum_{aD/2<q\le aD}
R_{a,q}(N)\cos\frac{2\pi aN}{q}\right\|_2^2
\ll_{a,\alpha}\frac{D^5}{Y^2}\Delta_Y^2\log(2Y).
\tag{15}
\]
在固定 \(\alpha<1\) 下，\(\Delta_Y^2\log Y\ll e^{-c'_{a,\alpha}u(D)}\)。

物理裁剪可删去至多 \(L/q+1\) 个 \(k\)。每个被删项满足 \(k\asymp N/q\)、\(k^{-1}\ll q/Y\)、\(0\le\log(N/kq)\ll L/Y\)，所以从 note 801 的精确系数直接得
\[
|C_{a,q}^{\rm phys}(N)-C_{a,q}^{\rm full}(N)|
\ll_a \frac{qL^2+q^2L}{Y^2}
\ll_a\frac{DL(L+D)}{Y^2}.
\tag{16}
\]
逐 \(N\) 对 \(O_a(D)\) 个 \(q\) 取绝对值，
\[
\sum_{Y<N\le2Y}
\left|\frac1N\sum_{aD/2<q\le aD}
(C_{a,q}^{\rm phys}(N)-C_{a,q}^{\rm full}(N))
\cos\frac{2\pi aN}{q}\right|^2
\ll_a\frac{D^4L^2(L+D)^2}{Y^5}.
\tag{17}
\]
式 (17) 相对于 \(D^5/Y^2\) 的比为
\(L^2(L+D)^2/(DY^3)\ll Y^{-c_\alpha}\)：当 \(D\le L\) 时至多 \(Y^{1/3}/D\)，当 \(D>L\) 时至多 \(DL^2/Y^3\le Y^{-1/3}\)。故它也被 \(e^{-c''u(D)}D^5/Y^2\) 吸收。

由 (3) 的 \(a=a'\) 情形，\(\|\Re U_a\|_2\le\|U_a\|_2\)，再合并 (15)--(17)，得到对每个固定 \(a\) 与 \(4/5<\alpha<1\) 的**真实物理带上界**
\[
\boxed{\quad
\sum_{Y<N\le2Y}|V_a(N;D)|^2
\ll_{a,\alpha}\frac{D^5}{Y^2}e^{-c_{a,\alpha}u(D)}.
\quad}\tag{18}
\]
对固定 \(a,a'\)，Cauchy--Schwarz 立刻给真实带的跨分子上界
\[
\boxed{\quad
\left|\sum_{Y<N\le2Y}V_a(N;D)V_{a'}(N;D)\right|
\ll_{a,a',\alpha}\frac{D^5}{Y^2}e^{-c_{a,a',\alpha}u(D)}.
\quad}\tag{19}
\]
这不同于 (3) 的复相位首阶 Gram，且完整保留每个频率内的有限 \(k\)-和及物理截止。

**边界。** (18)--(19) 对固定 \(\alpha>4/5\) 仍高于 \(Y^{2+\varepsilon}\)，因为 \(D^5/Y^2=Y^{5\alpha-2}\) 而 \(e^{-cu(D)}=Y^{-o(1)}\)。分子数随 \(Y\) 增长时，(5)--(17) 的常数与求和损失需重新核算。本文不估计 note 832 的完整 \(\mathcal V_N\)，不证明 RH。
