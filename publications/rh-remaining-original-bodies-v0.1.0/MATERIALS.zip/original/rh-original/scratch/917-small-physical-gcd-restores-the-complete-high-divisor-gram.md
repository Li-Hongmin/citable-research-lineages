# 扩大的物理 gcd 截止恢复完整高除数 Gram，并显露共同素数射线核

日期：2026-10-02。依赖 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 式 (2)、(12) 的真实高除数门、[scratch/868](868-large-physical-gcd-is-paid-in-the-full-observation-gram.md) 式 (3) 的大物理 gcd 绝对支付、[scratch/877](877-doubled-prime-physical-rows-cancel-in-the-true-high-divisor-gram.md) 的一大素因子物理系数，以及 [scratch/916](916-prime-flip-impulse-response-and-sharp-observation-delay.md) 的卷积响应。本文是对**真实**剩余门的精确代数缩域与目标量级删项，不给留下的完整 Gram 固定幂上界；尚未异源复核，留在 scratch。

## 定理：源过滤在扩大的物理 gcd 范围内自动满足

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，固定实值 $\psi\in C_c^3((1,2))$。取 scratch/859 的
\[
D=\left\lfloor\frac{M}{16H}\right\rfloor,
\quad R=\left\lfloor\frac{H^2}{\log^4(2M)}\right\rfloor,
\quad G=\left\lfloor\frac D R\right\rfloor,
\quad b_d(m),\quad K_0,K_1,J_H,
\]
并写
\[
a_D(m)=\sum_{\substack{d\mid m\\d>D}}\mu(d)b_d(m),
\qquad M<m<2M.
\tag{1}
\]
令 $\mathfrak S$ 是 scratch/859 式 (12) 的 signed 源门：$d,e>D$，$d\nmid e$、$e\nmid d$、$\max\{d/(d,e),e/(d,e)\}>R$，物理距离 $K_0<|m-n|\le K_1$。把它另限于 $(m,n)\le G$，记为 $\mathfrak S_{\le G}$。则充分大 $M$ 时有**精确**恒等式
\[
\boxed{\quad
\mathfrak S_{\le G}
=\sum_{\substack{M<m,n<2M\\(m,n)\le G\\
K_0<|m-n|\le K_1}}
a_D(m)\overline{a_D(n)}J_H(m-n).
\quad}\tag{2}
\]
且 $G\ge H$。scratch/868 式 (2b) 给出**不损失 $M^\varepsilon$** 的比较
\[
\boxed{\quad
\mathfrak S=\mathfrak S_{\le G}
+O_{s,\psi}\!\left(\frac{\log^8(2M)}G\right)
=\mathfrak S_{\le G}+o\!\left(\frac{H^4}M\right).\quad}\tag{3}
\]
所以目标指数的真实 signed 门可直接研究 (2) 的**完整物理行**；在该区域中逐源整除与小约化比例筛选不再割裂同一物理行的算术抵消。

## 定理：素数射线核与翻转响应相反

令 $\ell=\log2$，定义
\[
\alpha(k)=4\log k-2\mathbf1_{2\mid k}\log(k/2)
 +4\ell\mathbf1_{k=1},
\qquad \beta=\mu*\alpha.
\tag{4}
\]
这正是 scratch/877 的 $b_d(m)=-M^{-1}\alpha(m/d)\phi(m/M)$ 所用的 cofactor 核。由 $\mu*\log=\Lambda$，
\[
\boxed{\quad
\beta(k)=4\Lambda(k)-2\mathbf1_{2\mid k}\Lambda(k/2)
 +4\ell\mu(k)=-r(k),
\quad}\tag{5}
\]
其中 $r$ 是 scratch/916 式 (2) 的素数翻转响应核。若 $q\le H$、$p$ 为素数且 $M<pq<2M$，则
\[
\boxed{\quad a_D(pq)=\frac{\phi(pq/M)}M\beta(q)
=-\frac{\phi(pq/M)}M r(q).\quad}\tag{6}
\]
与 scratch/916 式 (3) 比较：当 $p$ 在窗口 $(M,2M)$ 被翻转且 $pq<M^2$ 时，联合系数的变化为 $-2\beta(q)$。这里 (6) 是真实高除数物理行，后一式只用于识别共同核，绝不把非真实模型当作真实估计。

特别地，若 $q=2^a u\le H$、$a\ge2$、$u>1$ 为奇数，则 $\mu(q)=\Lambda(q)=\Lambda(q/2)=0$，故
\[
\boxed{\quad a_D(pq)=0\quad
(M<pq<2M).\quad}\tag{7}
\]
式 (2) 使这些物理行列在 $(m,n)\le G$ 的**原过滤剩余门中精确为零**；其大 gcd 行列由 (3) 的同一个 $o(H^4/M)$ 总误差支付。最小的固定例子是 $q=12$：所有 $12p\in(M,2M)$ 且 $p$ 为素数的行均可在目标量级内删除。由素数定理，这一个例子已有 $\asymp M/\log M$ 个不同物理位置。scratch/877 的平方自由粗糙零行以及非平方自由零行在 (2) 中也都无需额外的因子间隙条件。

## 证明

固定 (2) 左侧的一项。因为 $d\mid m$、$e\mid n$，源 gcd $g=(d,e)$ 整除物理 gcd $(m,n)$，所以 $g\le G$。又 $d,e>D$ 与 $G\le D/R$ 给
\[
\frac d g,\frac e g>\frac D G\ge R.
\tag{8}
\]
在 $H\le(M/2)^{1/4}$ 下，充分大 $M$ 时 $R\ge1$、$D\ge M/(32H)$，从而
\[
G\ge\frac{M\log^4(2M)}{64H^3},
\qquad
\frac GH\ge\frac{M\log^4(2M)}{64H^4}
\ge\frac{\log^4(2M)}{32}>1.
\]
故 (8) 的两项都严格大于 $R$。同时 $d,e>D\ge G$；若 $d\mid e$，则 $(d,e)=d>G$，矛盾，反向亦然。因此 (2) 左侧的每个小物理 gcd 配对中，原有三个源过滤条件自动成立。对固定 $(m,n)$ 把所有 $d\mid m,e\mid n$ 重新求和，即得 $a_D(m)\overline{a_D(n)}$，证明 (2)。物理距离条件排除 $m=n$，故 scratch/868 式 (2b) 在 $T=G$ 直接给删除 $(m,n)>G$ 的绝对成本 $O(\log^8(2M)/G)$。由上面 $G$ 的下界，该成本至多 $O(H^3\log^4(2M)/M)=o(H^4/M)$，证明 (3)。

在 (4) 中，$\mathbf1_{2\mid k}\log(k/2)=(\delta_2*\log)(k)$。与 $\mu$ 卷积，并用 $\mu*\log=\Lambda$，立即得到 (5)。对于 $q\le H$，$p>M/q\ge M/H>D$ 且 $q<D$；因 $p>q$，$pq$ 的高除数恰为 $d=pt$、$t\mid q$。由 scratch/859 式 (2)，
\[
\begin{aligned}
a_D(pq)
&=-\frac{\phi(pq/M)}M
\sum_{t\mid q}\mu(pt)\alpha(q/t)\\
&=\frac{\phi(pq/M)}M
\sum_{t\mid q}\mu(t)\alpha(q/t)
=\frac{\phi(pq/M)}M\beta(q),
\end{aligned}
\]
证明 (6)。对 (7) 的 $q$，$q$ 与 $q/2$ 都含素因子 $2$ 和一个奇素因子，故两处 $\Lambda$ 为零；$4\mid q$ 又给 $\mu(q)=0$。所以 (5)--(6) 给逐行零值。对这些行应用 (2)--(3) 即得目标级删除。最后固定 $q=12$，素数 $p\in(M/12,M/6)$ 给 $12p\in(M,2M)$；固定比例区间的素数定理给其数目 $\asymp M/\log M$。$\square$

## 剩余边界

式 (2) 恢复的是完整高除数物理行，并以 $o(H^4/M)$ 误差删去已证明的零行；它没有对其余 $a_D(m)$ 的中距离、低物理 gcd 带符号二点和给出 $H^4M^{-1+\varepsilon}$ 上界。全尺度局部 Weil 正性与 RH 仍开放。
