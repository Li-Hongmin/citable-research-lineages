# 固定幂 Farey 短块负协方差候选推进至四分之五

日期：2026-09-30。把 [note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md) 的 \(\alpha>5/6\) 推至全部固定 \(4/5<\alpha<1\)。新的承重步骤仅是下面的多倍数端点裁剪式 (2)；其余使用该 note 已写明的 Matomäki--Shao--Tao--Teräväinen 2023 全区间短区间 Möbius 定理、Heath-Brown 1982 素数短区间定理，以及 [notes 800--801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 的同频系数。整条证明尚待异源复核，暂留 scratch；这不是完整 moving-\(N\) 均方门的证明。

## 命题

固定 \(4/5<\alpha<1\)，置
\[
D=\lfloor Y^\alpha\rfloor,\quad
B=\left\lfloor D^2/(1000Y)\right\rfloor,\quad
L=\lfloor Y^{5/6}\rfloor.
\tag{1}
\]
对**每个**长度为 \(B\) 的整数块 \(I=(t,t+B]\subset(D/2,D]\)，取 note 833 式 (1) 的真实物理裁剪系数 \(C_q(N)\)、\(F_{q,N}=-C_q(N)(\pi N)^{-1}\cos(2\pi N/q)\)，并令 \(G_{I,N}=\sum_{p\in I,\ p\ {\rm prime}}F_{p,N}\)、\(T_{I,N}=\sum_{q\in I}F_{q,N}\)，其中 \(Y<N\le2Y\)。则一致于全部这样的 \(I\)，对任意固定 \(A>0\) 有
\[
v_I:=\#\{p\in I:p\ {\rm prime}\}\sim B/\log D,\qquad
\sup_N|T_{I,N}|\ll_{\alpha,A}\frac{BD}{Y(\log Y)^A},
\tag{2a}
\]
\[
E_I:=\sum_{Y<N\le2Y}G_{I,N}^2
\asymp_\alpha\frac{D^6}{Y^3\log^2Y},\qquad
\sum_{Y<N\le2Y}G_{I,N}(T_{I,N}-G_{I,N})
=-(1+o(1))E_I.
\tag{2b}
\]
原始指标 \(d=kq,h=k,d\le N-L\) 全部位于 note 832 的真实斜楔 \(\mathcal V_N\)。当 \(4/5<\alpha\le5/6\) 时，\(E_I\) 可低于目标 \(Y^2\) 尺度；本命题仍只给每块内部的真实负协方差，不估计不同块的联合协方差。

同一证明也覆盖临界常数带：固定 \(c>2\)，改取 \(D=\lfloor cY^{4/5}\rfloor\)，其余按 (1) 定义，则每个 \(I\subset(D/2,D]\) 都有 \(q>Q=\lfloor Y^{4/5}\rfloor\)，而下文的短区间指数 \(\beta=3/4\) 仍满足式 (6) 的严格不等式；结论 (2a)--(2b) 原样成立，其能量量级为 \(Y^{9/5}/\log^2Y\)。常数 \(c>2\) 只用来使整个区间 \((D/2,D]\) 落在 \(q>Q\) 一侧。

## 多倍数端点裁剪

记 \(C_q^{\rm full}(N)\) 为 note 833 式 (1) 中把 \(kq\le N-L\) 改成 \(kq<N\) 的系数。对 \(q\asymp D\)、\(Y<N\le2Y\)，因 \(q/N=O(Y^{\alpha-1})=o(1)\)，奇偶括号
\[
\frac{4\mathbf1_{2\mid k}}{1-4q^2/N^2}
-\frac1{1-q^2/N^2}
\]
一致有界。若 \(N-L<kq<N\)，则 \(k\ge(N-L)/q\ge N/(2q)\)、\(\log(N/kq)\le2L/N\)，且此类整数 \(k\) 至多 \(L/q+1\) 个。因此不要求 \(q>L\)，仍有
\[
\boxed{\quad
|C_q(N)-C_q^{\rm full}(N)|
\ll q\left(\frac Lq+1\right)\frac qN\frac LN
\ll \frac{qL^2+q^2L}{Y^2}.
\quad}\tag{3}
\]
对 \(q>L\)，第二项恢复 note 833 式 (11)；对 \(q\le L\)，新增的第一项来自多删的倍数。两项相对主系数 \(q\) 都有固定幂节省：
\[
\frac{L^2}{Y^2}=O(Y^{-1/3}),\qquad
\frac{qL}{Y^2}=O_\alpha(Y^{\alpha-7/6}).
\tag{4}
\]

## 短块抵消与素数能量

写 \(f_\kappa(q)=\kappa_q\mu(q)q/\varphi(q)\)，其中奇 \(q\) 的 \(\kappa_q=5\)、偶 \(q\) 的 \(\kappa_q=1\)。note 835 式 (5)--(6) 给 \(f_\kappa=\mu*h_\kappa\) 及 \(\sum_d|h_\kappa(d)|/\sqrt d<\infty\)。令 \(\beta=2-1/\alpha\)。本范围满足
\[
\beta>3/4,\qquad B=D^{\beta+o(1)},\qquad B=o(D).
\tag{5}
\]
取 \(\epsilon_\alpha=\min\{1/64,(1-\beta)/4\}\)。对卷积指标 \(d\le D^{1/4}\)，应用 note 835 所核对的 2023 全区间短区间 Möbius 定理时，起点 \(x=t/d\asymp D/d\)、长度 \(H_0=B/d\) 满足
\[
\frac{H_0}{x^{5/8+\epsilon_\alpha}}
\gg D^{\beta-23/32-3\epsilon_\alpha/4+o(1)}\to\infty,
\qquad
\frac{H_0}{x^{1-\epsilon_\alpha}}
\ll D^{\beta-1+\epsilon_\alpha+o(1)}\to0.
\tag{6}
\]
第一个指数在 \(\beta>3/4\)、\(\epsilon_\alpha\le1/64\) 下至少为 \(3/4-23/32-3/256>0\)。该定理的最大进程界控制每个前缀；\(d>D^{1/4}\) 的平凡尾由 \(\sum|h_\kappa(d)|/\sqrt d<\infty\) 界为 \(BD^{-1/8}+D^{1/2}=o(B/\log^A D)\)。所以对任意固定 \(A>0\)，一致于所有块及前缀，
\[
\max_{t\le z\le t+B}
\left|\sum_{t<q\le z}f_\kappa(q)\right|
\ll_{\alpha,A}B/(\log D)^A.
\tag{7}
\]

notes 800--801 与 note 833 式 (10) 的奇偶主项给
\(C_q^{\rm full}(N)=-qf_\kappa(q)
+O_\alpha(qe^{-c_\alpha\omega(Y)}
+q\log\log(3Y)(q/N)^2)\)，其中
\(\omega(Y)=(\log Y)^{3/5}(\log\log Y)^{-1/5}\)。
代入 (3) 后，对 \(q\in I\) 一致有
\[
C_q(N)=-qf_\kappa(q)
+O_\alpha\!\left(qe^{-c_\alpha\omega(Y)}
+q\log\log(3Y)(q/N)^2
+qL^2/Y^2+q^2L/Y^2\right).
\tag{8}
\]
对 \(g_N(q)=q\cos(2\pi N/q)\)，块上的 \(\sup|g_N|\ll D\)、\(\operatorname{Var}_I g_N\ll B(1+Y/D)\ll D\)。以 (7) 作 Abel 求和，主项的绝对值为 \(O_{\alpha,A}(BD/\log^A Y)\)。式 (8) 的其余项逐 \(q\) 取绝对值，除以 \(\pi N\) 后相对于 \(BD/[Y\log Y]\) 的比至多
\[
O_\alpha\!\left(
\log Y\,e^{-c_\alpha\omega(Y)}
+\log Y\log\log Y\,(D/Y)^2
+\log Y\,(L/Y)^2
+\log Y\,DL/Y^2
\right)=o(1),
\tag{9}
\]
而各项实际有任意固定对数幂节省。于是得到 (2a) 的 \(T\) 界。

因 \(\beta>3/4>2/3\)，长度 \(B\) 的每个块可分割成 Heath-Brown 定理适用的 \(x^{2/3}\) 素数短区间，端部不足 \(O(D^{2/3})\) 的余段以 \(\Lambda(n)\le\log(2D)\) 支付；平方素数及更高幂的总权 \(O(\sqrt D\log^2D)=o(B)\)。故全部块一致有 \(v_I\sim B/\log D\)。对素数 \(p\in I\)，式 (8) 给 \(C_p(N)=5p+o(p)>0\) 一致。任取 \(q_0\in I\)，由 \(B=D^2/(1000Y)+O(1)\) 得
\[
\sup_{p\in I,\ Y<N\le2Y}
\left|\frac Np-\frac N{q_0}\right|\le8/1000+o(1).
\tag{10}
\]
因为 \(q_0=o(Y)\)，有 \(\gg Y\) 个 \(N\in(Y,2Y]\) 满足 \(\|N/q_0\|_{\mathbb R/\mathbb Z}\le1/12\)。在这些 \(N\) 上全部余弦同号且有正下界；对全部 \(N\)，\(|G_{I,N}|\ll v_ID/Y\)。于是
\[
E_I\asymp_\alpha Y(v_ID/Y)^2
\asymp_\alpha D^6/(Y^3\log^2Y).
\]
由 (2a)，\(\|T_I\|_{\ell^2_N}=o(\|G_I\|_{\ell^2_N})\)，展开内积即得 (2b)。最后 \(q>D/2>Y^{4/5}\)、既约分子 \(a=1<\min(A,A_j)\)、原始 \(d=kq\le N-L\)，所以各项确在 \(\mathcal V_N\) 中。\(\square\)

## 边界

该推论填满 note 762 的无符号低除数截止 \(4/5\) 与 note 835 的固定幂块范围之间的缺口，但没有给不同分母块的联合平方界。尤其不能把每块的负协方差直接相加后宣称 \(\sum_N|\mathcal V_N|^2\ll Y^{2+\varepsilon}\)：跨块项仍是同一 RH 强度的 signed covariance。
