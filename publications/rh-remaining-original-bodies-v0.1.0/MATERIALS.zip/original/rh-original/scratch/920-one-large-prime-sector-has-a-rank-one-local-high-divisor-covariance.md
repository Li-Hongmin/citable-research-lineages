# 一大素因子扇区与其补集的真实高除数首瓣协方差

日期：2026-10-02。依赖 [scratch/917](917-small-physical-gcd-restores-the-complete-high-divisor-gram.md) 的精确物理行、[scratch/918](918-short-cofactor-mobius-cancellation-in-the-restored-high-divisor-first-lobe.md) 的完整高除数短和、[scratch/919](919-positive-density-of-exact-zero-rows-in-the-true-high-divisor-gram.md) 的一大素因子一阶主项，以及 [scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的实际带通核。外部短区间输入为 Matomäki--Shao--Tao--Teräväinen, *Forum Math. Pi* **11** (2023), e29, Theorem 3.1(i) 的最大进程界及式 (3.11) 的素数模型主项，按 [scratch/913](913-logarithmic-critical-collar-of-the-true-moving-observation-gate.md) 的原文核对方式使用。本稿只确定真实局部协方差的常数量级结构，未给 RH 所需固定幂净界；尚未异源复核。

## 定理

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，固定实值非零 $\psi\in C_c^3((1,2))$，$\phi(x)=\psi(x)/x$。取 scratch/860 的实偶非负带通权 $w_H(h)=v(h/H)$ 与 $J_H(r)$，并置
\[
L=\left\lfloor\frac{M}{32H}\right\rfloor,\qquad
P_m=a_D(m)\mathbf1_{\{m=pq,\ p\ {\rm prime},\,q\le H\}},
\qquad C_m=a_D(m)-P_m.
\tag{1}
\]
表示 $m=pq$ 唯一。定义真实的平滑密度
\[
\rho_{M,H}(x)=\phi(x)\sum_{q\le H}
\frac{\beta(q)}{q\log(Mx/q)},\qquad
V_{M,H}=\frac1M\sum_{|r|\le L}J_H(r),\qquad
I_{M,H}=\int_1^2\rho_{M,H}(x)^2\,dx.
\tag{2}
\]
对 $U,V\in\{P,C\}$ 记
$Q_{UV}(L)=\sum_{|m-n|\le L}U_m\overline{V_n}J_H(m-n)$。
则对任意固定 $A>0$，一致于整个 $H$ 范围，
\[
\boxed{\quad
\begin{pmatrix}
Q_{PP}(L)&Q_{PC}(L)\\
Q_{CP}(L)&Q_{CC}(L)
\end{pmatrix}
=V_{M,H}I_{M,H}
\begin{pmatrix}1&-1\\-1&1\end{pmatrix}
+O_A((\log M)^{-A})\quad\text{逐项成立}.
\quad}\tag{3}
\]
其中
\[
\begin{aligned}
\rho_{M,H}(x)
&=3\phi(x)\log\!\left(\frac{\log M}{\log(M/H)}\right)
+O_\psi(1/\log M),\\
V_{M,H}
&=\int_{-1/32}^{1/32}\widehat v(u)\,du+O_s(H^{-1}+H/M),
\qquad \int_{-1/32}^{1/32}\widehat v(u)\,du>0.
\end{aligned}\tag{4}
\]
因此若 $\psi\not\equiv0$，$Q_{PP}$、$Q_{CC}$ 都有一致的正的常数下界，而两个交叉块都有一致的负的常数上界。四块相加仍为 scratch/918 的 $O_A((\log M)^{-A})$。这是真实高除数物理行的带符号补偿，不是完整 moving-$N$ 门的固定幂估计。

若把每块改成 scratch/859 式 (12) 的**原始过滤源项**，按同一物理行类别取
$K_0<|m-n|\le L$，则 (3) 的主矩阵仍成立，但误差改为 $o(1)$：
源过滤、物理 gcd 与近对角删项均不能抹去这两个常量级负交叉块。
同一四块的完整带通能量逐块为任意固定负对数幂，因此物理距离 $|m-n|>L$ 的旁瓣还满足
\[
Q_{UV}(|m-n|>L)
=-\sigma_U\sigma_V V_{M,H}I_{M,H}
+O_A((\log M)^{-A})
\quad(U,V\in\{P,C\}).
\tag{4a}
\]
故每个正的自块也由自身较远旁瓣偿还；首瓣的负交叉不是唯一补偿。

## 证明：一大素因子行的局部密度

先证明对所有整数区间 $I\subset(M,2M)$、$|I|\le L$，以及任意固定 $A>0$，有
\[
\boxed{\quad
\left|\sum_{m\in I}P_m
-\frac1M\int_I\rho_{M,H}(t/M)\,dt\right|
\ll_{A,\psi}\frac LM(\log M)^{-A}.
\quad}\tag{5}
\]
固定 $q\le H$，令 $x\asymp M/q$、$T_q=\lceil L/q\rceil+2$。与 scratch/918 式 (6) 相同，$T_q/x^{5/8}\gg M^{1/32}$ 且 $T_q/x^{23/24}\ll M^{-c}$，所以 2023 年 Theorem 3.1(i) 可统一取 $\varepsilon=1/24$。其最大进程界连同原文式 (3.11) 的 $\Lambda^\sharp$ 主项，按 scratch/913 式 (6)--(8) 的论证，给母区间中任意子区间 $K$ 的
\[
\left|\sum_{n\in K}(\Lambda(n)-1)\right|
\ll_B \frac Lq(\log M)^{-B}\qquad(B>0).
\tag{6}
\]
短 $K$ 由平凡 $O(|K|\log M)$ 界并入右侧；这里 $T_q\gg x^{2/3-o(1)}$。
高次素数幂在整个母区间的 $\Lambda$ 质量至多 $O(\sqrt x\log^2x)$，而
$T_q/\sqrt x\gg M^{1/8}$；故其损失也小于 (6) 右侧的任意固定对数幂。对权 $1/\log t$ 分部求和，得到
\[
\sup_{K\subset\text{母区间}}
\left|\#\{p\in K:p\ {\rm prime}\}
-\int_K\frac{dt}{\log t}\right|
\ll_B\frac Lq(\log M)^{-B}.
\tag{7}
\]
对固定 $q$ 的 $\phi(qp/M)$ 再分部求和；该权在 $I/q$ 上的上确界加总变差为 $O_\psi(1)$。乘以 $\beta(q)/M$ 并对 $q\le H$ 求和时，
$\sum_{q\le H}|\beta(q)|/q\ll\log M$
由 scratch/917 式 (5)、Chebyshev 界和调和和直接得到。预先在 (7) 多取两个对数幂，便将总误差压到 (5)。
余下的连续主项经 $t=qu$ 换元，精确成为
\[
\frac1M\int_I
\phi(t/M)\sum_{q\le H}\frac{\beta(q)}{q\log(t/q)}\,dt
=\frac1M\int_I\rho_{M,H}(t/M)\,dt,
\]
证明 (5)。

scratch/918 式 (2) 对完整 $a_D$ 给同样大小的零密度短和。因此 (5) 对补集 $C=a_D-P$ 也成立，只需把 $\rho_{M,H}$ 换成 $-\rho_{M,H}$。并且
$\sum_m|P_m|\ll1$：由 $a_D(pq)=M^{-1}\beta(q)\phi(pq/M)$、每个 $q$ 的素数上界
$O(M/(q\log M))$ 及 $\sum|\beta(q)|/q\ll\log M$ 即得。scratch/859 式 (9) 给
$\sum_m|C_m|\le\sum_m|a_D(m)|+\sum_m|P_m|\ll\log^2M$。

## 证明：短和转为局部 Gram

从 (2) 直接有 $\|\rho_{M,H}\|_\infty+\|\rho_{M,H}'\|_\infty\ll_\psi1$，因为
$\log(Mx/q)\asymp\log M$ 且 $\sum|\beta(q)|/q\ll\log M$。
核的上确界与在 $[-L,L]$ 上的总变差之和为 $O_s(H)$，见 scratch/918 式 (8)。
固定外层 $m$，把 $[m-L,m+L]$ 分成两个长度不超过 $L$ 的区间，再把 (5) 用离散 Abel 求和施于内层 $n$。对任意 $U,V\in\{P,C\}$，若 $\sigma_P=1$、$\sigma_C=-1$，则
\[
\sum_{|m-n|\le L}V_nJ_H(m-n)
=\frac{\sigma_V}{M}\sum_{|r|\le L}
\rho_{M,H}((m-r)/M)J_H(r)
+O_A((\log M)^{-A}).
\tag{8}
\]
这里按需要在 (5) 预先增加对数幂。由 $\rho$ 的一致 Lipschitz 界、$|J_H(r)|\ll H$ 及 $L\asymp M/H$，(8) 的主项为
$\sigma_VV_{M,H}\rho_{M,H}(m/M)+O_\psi(H^{-1})$；
后一误差小于任意固定负对数幂。

将 (8) 乘 $U_m$ 求和。$\sum|U_m|\ll\log^2M$ 仍可吸收在任意预选对数幂内。再把 $(M,2M)$ 分成 $O(M/L)=O(H)$ 个长度不超过 $L$ 的区间，对 (5) 作一次 Abel 求和，可得
\[
\sum_m U_m\rho_{M,H}(m/M)
=\sigma_U\int_1^2\rho_{M,H}(x)^2\,dx
+O_A((\log M)^{-A}).
\tag{9}
\]
式 (8)--(9) 给 (3)。所有求和都只在 $\phi$ 的紧支撑内，故边界截断没有周期别名问题。

证明 (4a) 所用的完整带通界也从 (5) 直接取得。令
$s_m=\rho_{M,H}(m/M)/M$ 并在物理窗外置零。对 $P-s$ 与 $C+s$，式 (5) 及 scratch/918 式 (2) 给所有长度不超过 $L$ 的滑动窗
$O_A((L/M)(\log M)^{-A})$ 的和；跨周期接缝时分成两个物理区间即可。窗长 $L$ 的几何和在 $w_H(h)\ne0$ 时模长 $\gg L$，所以周期 Parseval 如 scratch/913 式 (11)--(12) 给两条中心化序列的完整带通平方范数均为 $O_A((\log M)^{-A})$。另一方面 $\rho_{M,H}\in C_c^3((1,2))$ 且前三阶范数一致有界，三次分部积分使平滑序列 $s$ 的带通平方范数为 $O(H^{-5})$。正权 $w_H$ 下的 Cauchy--Schwarz 于是给每个 $U,V\in\{P,C\}$ 的完整带通交叉为 $O_A((\log M)^{-A})$。从中减去 (3) 的 $|m-n|\le L$ 部分，即得 (4a)。

最后 scratch/919 式 (12) 给 $\sum_{q\le X}\beta(q)=3X+O_A(X/\log^A(2X))$。对 (2) 中的 $q$ 权分部求和，在 $x\in[1,2]$ 上一致得到 (4) 第一式。Poisson 求和及整数求积给第二式；因 $v\ge0$、$\operatorname{supp}v\subset[-4,4]$，当 $|u|\le1/32$ 时 $\cos(2\pi ut)\ge\cos(\pi/4)>0$，所以 $\widehat v(u)>0$。又 $\log H/\log M\ge1/5+o(1)$，(4) 的系数有统一正下界；$\phi\not\equiv0$ 使 $I_{M,H}>c_\psi>0$。这证明全部断言。$\square$

核对原过滤门的接口：令 $\mathfrak S_{UV}^{\rm first}$ 为 scratch/859 式 (12) 只取物理行类别 $U,V$ 及 $K_0<|m-n|\le L$ 的子和。scratch/917 式 (2) 在 $(m,n)\le G$ 时逐物理配对将所有源过滤精确合成 $U_m\overline{V_n}J_H(m-n)$。对非对角 $(m,n)>G$，scratch/868 式 (2b) 在两侧各自的限制下仍给 $O(\log^8M/G)$ 的绝对费用；完整物理 Gram 的对角另由该稿式 (11) 支付 $O(H\log^5M/M)$。最后 scratch/859 式 (10) 对 $|m-n|\le K_0$ 给 $O(H^4/(M\log^2M))$。三项在所给 $H$ 范围一致为 $o(1)$，所以
\[
\mathfrak S_{UV}^{\rm first}
=\sigma_U\sigma_V V_{M,H}I_{M,H}+o(1),
\qquad \sigma_P=1,\quad\sigma_C=-1.
\tag{9a}
\]

## 边界

首瓣的正扇区、负交叉及正补集构成秩一主矩阵，展示真实源恢复后的常数量级抵消。scratch/919 的正密度零行不承担这项主值，稀疏素数 cofactor 才承担一阶密度。但目标 $H^4M^{-1+\varepsilon}$ 在低于四分之一次幂的频带仍比任意固定对数幂小；较远旁瓣、低 gcd 真二点余量和全尺度局部 Weil 正性均未关闭。
