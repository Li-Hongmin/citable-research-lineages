# 末带真素数窗的一致 Riesz 框架与逐窗同通道补偿

日期：2026-10-02。使用 [note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 式 (1) 的实际素数窗、[note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (11) 的观察频率，以及 [scratch 964](964-terminal-prime-mask-cancels-within-even-prime-observation-channel.md) 式 (9a)、(9b) 的窗质量和核近似。本稿把特定全选窗的 Gram 主项提升为对**任意复数窗权**一致的算子界，并把同通道补偿推进到每个非空选窗集合；仍不估计完整三通道的固定幂门，也不证明 RH。以下推导尚待异源复核。

## 命题

固定非负非零的实函数 $\psi\in C_c^3((1,11/10))$。令 $H=\lfloor Y^\gamma\rfloor$，其中固定 $1/5\le\gamma<1/4$，$Y\to\infty$ 沿整数。对 $H<a\le11H/10$，以 $I_a$ 表示 note 845 式 (1) 的素数窗，置
\[
 w_a=\sum_{p\in I_a\atop p\text{ prime}}\frac{\log p}{p}\psi(p/Y),\qquad
 P_a(h)=\sum_{p\in I_a\atop p\text{ prime}}\frac{\log p}{p}\psi(p/Y)e(-hp/Y).
\tag{1}
\]
取固定实偶的 $\eta\in C_c^\infty(\mathbb R)$，$\eta\ge0$，$\operatorname{supp}\eta\subset\{1/2\le|t|\le4\}$，且 $\eta(t)\ge1$ 于 $1\le|t|\le2$。写
\[
 \Theta_\eta(t)=\sum_{j\in\mathbb Z}\eta(t+j),\qquad
 P_\alpha(h)=\sum_a\alpha_aP_a(h),\qquad x_a=\alpha_aw_a
\tag{2}
\]
其中 $\alpha_a\in\mathbb C$ 任意。则一致于全部 $\alpha$，
\[
\boxed{\quad
\sum_{h\in\mathbb Z}\eta(h/H)|P_\alpha(h)|^2
=H\int_0^1\Theta_\eta(t)
  \left|\sum_a x_ae(-at)\right|^2dt
 +O_{\psi,\eta}\!\left(\frac H{\log Y}\sum_a|x_a|^2\right).
\quad}                                                        \tag{3}
\]
特别地，因 $2\le\Theta_\eta(t)\le\|\Theta_\eta\|_\infty$，
\[
\boxed{\quad
\left(2-O_{\psi,\eta}(1/\log Y)\right)H\sum_a|x_a|^2
\le\|P_\alpha\|_\eta^2
\le\left(\|\Theta_\eta\|_\infty
       +O_{\psi,\eta}(1/\log Y)\right)H\sum_a|x_a|^2.
\quad}                                                        \tag{4}
\]
两端对**单个窗、任意稀疏选择和有相位的权**都成立。进一步，一致于 $a$，
\[
 w_a=\frac{\psi(a/H)}{H\log Y}
      +O_{\psi,\gamma}\!\left(\frac1{H\log^2Y}
             +\frac{e^{-cV_Y}}{H\log Y}\right),
\qquad V_Y=(\log Y/\log\log Y)^{1/3},                         \tag{5}
\]
其中某个 $c>0$；因此若 $|\alpha_a|\le1$，则式 (4) 的自然量级是
\[
 H\sum_a|x_a|^2
 =\frac1{H\log^2Y}\sum_a|\alpha_a|^2\psi(a/H)^2
   +O_{\psi,\gamma}\!\left(\frac1{\log^3Y}
                  +\frac{e^{-cV_Y}}{\log^2Y}\right).       \tag{6}
\]
对仅含很少窗的选择，应使用 (4) 中的**实际** $w_a$，而非 (6) 的全窗绝对误差。

令 $B_h$ 是 scratch 964 式 (1) 的整条偶素数通道，$\mathcal A_h$ 是 note 849 式 (11) 的完整真实观察系数。存在只依赖固定参数的 $c_1>0$，使对每个实数 $p\in[Y,11Y/10]$，一致有
\[
\boxed{\quad
\left|\sum_{Y<q<2Y\atop q\text{ prime}}
\frac{\log q}{q}\psi(q/Y)K_H(2(p-q))\right|
\ll_{\psi,\eta}e^{-c_1V_Y}.
\quad}                                                        \tag{7}
\]
同一 $c_1$ 缩小后，还对 $x\in[2Y,11Y/5]$ 一致有完整三通道的逐点投影界
\[
\boxed{\quad
\left|\sum_{2Y<m<4Y}\frac{c(m)}m\psi(m/(2Y))K_H(x-m)\right|
\ll_{\psi,\eta}e^{-c_1V_Y},
\quad}                                                        \tag{7a}
\]
其中 $K_H(r)=\sum_h\eta(h/H)e(-hr/(2Y))$。固定任意 $c_\psi>0$，令 $S_Y$ 是 $\{a:H<a\le11H/10,\ \psi(a/H)\ge c_\psi\}$ 的**任意非空子集**，并设 $P_S=\sum_{a\in S_Y}P_a$、$Q_S=B-P_S$。由 (4)--(5)、(7) 推出对全部这类 $S_Y$ 一致的
\[
\boxed{\quad
\langle P_S,Q_S\rangle_\eta
=-\|P_S\|_\eta^2
  \left(1+O_{\psi,\eta,c_\psi}(\log Y\,e^{-c_1V_Y})\right),
\qquad
\|P_S\|_\eta^2\gg_{\psi,\eta,c_\psi}
\frac{|S_Y|}{H\log^2Y}.
\quad}                                                        \tag{8}
\]
这里 $Q_S$ 是**未选**的真正偶素数项；即使 $|S_Y|=1$，负交叉仍与选窗自能量相等到相对 $o(1)$。这只量化同一偶素数通道的补偿；其他通道与完整频带上界仍未控制。

在最低观察尺度 $H=\lfloor Y^{1/5}\rfloor$，取任意固定 $0<b<c_1$，并在 $\psi\ge c_\psi$ 的闭子区间内任意选择
$|S_Y|=\lfloor e^{bV_Y}\rfloor$ 个窗；充分大 $Y$ 时这些窗存在。此时 $M=2Y$，式 (5)、(7)--(8) 还给出**目标精度内**的真实负协方差
\[
\boxed{\quad
\|P_S\|_\eta^2\asymp_{\psi,\eta,c_\psi}
 \frac{e^{bV_Y}}{H\log^2Y}
 \gg\frac{H^4}{M},
\qquad
\langle P_S,Q_S\rangle_\eta
 =-\|P_S\|_\eta^2+o(H^4/M).
\quad}                                                        \tag{8a}
\]
事实上交叉余项至多 $O(e^{-(c_1-b)V_Y}/(H\log Y))=o(H^{-1})$，而 $H^4/M\asymp H^{-1}$。所以即使负交叉的绝对误差已低于完整门槛，该选窗的超门槛自能量仍在**同一偶素数通道**内被支付；不能从这种局部负交叉推断完整三通道算术门。
更直接地，式 (7a) 对同一稀疏选窗给
\[
\boxed{\quad
\langle P_S,\mathcal A-B\rangle_\eta=o(H^4/M),
\qquad
\langle P_S,\mathcal A-P_S\rangle_\eta
  =-\|P_S\|_\eta^2+o(H^4/M).
\quad}                                                        \tag{8b}
\]
因此该选窗在**完整真实三通道**中的超门槛负补偿，目标精度内已由未选偶素数承担；式 (8b) 没有控制与 $P_S$ 正交的剩余部分。
其实同样的输入可同时支付所选窗生成的整个有限维观察空间。以 $\eta(h/H)$ 为权，把非零频率坐标组成 Hilbert 空间，令 $\mathcal V_S=\operatorname{span}\{P_a:a\in S_Y\}$，$\Pi_S$ 为正交投影。式 (3)、(7)、(7a) 对任意复系数给
\[
\boxed{\quad
\|\Pi_S\mathcal A\|_\eta^2
+\|\Pi_SB\|_\eta^2
\ll_{\psi,\eta}\frac{|S_Y|}{H}e^{-2c_1V_Y}
=o(H^4/M)
\quad}                                                        \tag{8c}
\]
在 (8a) 的 $H=\lfloor Y^{1/5}\rfloor$、$|S_Y|=e^{bV_Y+O(1)}$ 且 $b<c_1$ 下成立。这个低于门槛的投影只覆盖 $|S_Y|=Y^{o(1)}$ 维；完整观察空间有 $\asymp H$ 个频率坐标。

这一结论还落在 note 849 式 (15) 的**真实中距离环带**。令 $p_m^S=(\log(m/2)/(m/2))\psi(m/(2Y))$ 当 $m=2p$、$p$ 为 $S_Y$ 中某个 $I_a$ 的素数，其余为零；令 $b_m$ 是全部 $Y<p<2Y$ 的同样偶素数序列，$a_m=c(m)\psi(m/M)/m$，其中 $M=2Y$。对固定 $0<\delta<1/5$ 置
\[
T=H^3/\log^2(2Y),\qquad U=Y^{1+\delta}/H,
\qquad
\mathcal Q_H^{(T,U]}(v,w)
=\sum_{T<|m-n|\le U}v_m\overline{w_n}K_H(m-n).
\tag{8d}
\]
若 $H=\lfloor Y^{1/5}\rfloor$、$|S_Y|=\lfloor e^{bV_Y}\rfloor$ 且 $0<b<c_1$，则
\[
\boxed{\begin{aligned}
\mathcal Q_H^{(T,U]}(p^S,p^S)
 &=\|P_S\|_\eta^2+o(H^4/M),\\
\mathcal Q_H^{(T,U]}(p^S,b-p^S)
 &=-\|P_S\|_\eta^2+o(H^4/M),\\
\mathcal Q_H^{(T,U]}(p^S,a-b)
 &=o(H^4/M).
\end{aligned}}                                               \tag{8e}
\]
故在**完整中距离环带**中，所选真素数窗的超门槛正自块由未选偶素数给出等量负块，而其他真实通道在这一选窗上的投影低于目标精度。式 (8e) 不界定其他块彼此之间的和。

## 证明

令 $K_H(r)=\sum_h\eta(h/H)e(-hr/(2Y))$。不同 $I_a$ 不交。对 $p\in I_a$，note 845 式 (6) 给
\[
\frac pY=\frac aH+O\!\left(\frac1{H\log Y}\right),
\tag{9}
\]
误差对 $a,p$ 一致。令 $\widehat\eta(\xi)=\int\eta(t)e(-\xi t)dt$。Poisson 求和、(9) 及 $|p-q|/Y<1/5$ 给任意固定 $A>3$ 的一致核近似
\[
 K_H(2(p-q))
=H\widehat\eta(a-b)
 +O_{\eta,A}\!\left(
       \frac H{\log Y}(1+|a-b|)^{-A}+H^{1-A}\right)
\quad(p\in I_a,q\in I_b).
\tag{10}
\]
这里 $j\ne0$ 的 Poisson 别名距零至少 $4H/5$；$j=0$ 项由 $\widehat\eta'$ 的快速衰减和 (9) 控制。因 $\log p\,\psi(p/Y)/p\ge0$，对 $p,q$ 求和后，(10) 的误差界正好乘 $w_aw_b$，而主项为 $Hw_aw_b\widehat\eta(a-b)$。当 $w_aw_b>0$ 时把平均误差除以 $w_aw_b$ 定义 $E_{ab}$；否则令 $E_{ab}=0$。该有限矩阵满足
\[
 E_{ab}=O_{\eta,A}\!\left(
       \frac H{\log Y}(1+|a-b|)^{-A}+H^{1-A}\right)
\]
每行与每列的绝对值和均为 $O_{\eta,A}(H/\log Y)$：第一项用 $A>1$ 的可和性，第二项用窗数 $O(H)$，并取 $A>3$。Schur 界于是给对任意 $x_a$ 的二次误差
$O(H(\log Y)^{-1}\sum_a|x_a|^2)$。展开 $\|P_\alpha\|_\eta^2$ 得
\[
\|P_\alpha\|_\eta^2
=H\sum_{a,b}x_a\overline{x_b}\widehat\eta(a-b)
 +O\!\left(\frac H{\log Y}\sum_a|x_a|^2\right).
\tag{11}
\]
Fourier 反演、把实线按单位区间分片，再用整数指数的周期性，给
\[
\sum_{a,b}x_a\overline{x_b}\widehat\eta(a-b)
=\int_0^1\Theta_\eta(t)
   \left|\sum_a x_ae(-at)\right|^2dt.
\tag{12}
\]
对 $0\le t\le1$，$t+1\in[1,2]$、$t-2\in[-2,-1]$；偶性与平台条件使两项各至少为 $1$，所以 $\Theta_\eta(t)\ge2$。再用 Parseval
$\int_0^1|\sum_a x_ae(-at)|^2dt=\sum_a|x_a|^2$，得到 (3)--(4)。

式 (5) 可直接从 note 845 式 (6) 和 note 851 式 (4) 得到。各 $I_a$ 的长度 $B_a\asymp Y/(H\log Y)\gg Y^{3/4}/\log Y$；在长度 $B_a$ 上，Ramachandra 对 $\Lambda-1$ 的误差相对 $B_a$ 为 $O(e^{-cV_Y})$，其 $Y^{7/12+\varepsilon}$ 项因 $\gamma<1/4$ 有固定幂余量。全部高次素数幂在 $[Y,2Y]$ 的 $\Lambda$ 质量为 $O(\sqrt Y\log Y)$，也有固定幂余量。因此
$\sum_{p\in I_a}\log p=B_a(1+O(e^{-cV_Y}))$，一致于 $a$。由 $B_a=aY/(H^2\log Y)+O(Y/(H^2\log^2Y)+1)$、(9) 及 $\psi$ 的 Lipschitz 界，代入 (1) 得 (5)。对 $|\alpha_a|\le1$ 平方并对 $O(H)$ 个窗求和，得 (6)。

证明 (7)。固定 $p\in[Y,11Y/10]$，写 $W=Y/H$，$\Phi(u)=\psi(u)/u$。把 (7) 左侧先用 $\Lambda(q)$ 代替真正素数项。由 note 851 式 (4)，任意整数区间 $I\subset[Y,2Y]$ 满足
\[
\left|\sum_{n\in I}(\Lambda(n)-1)\right|
\ll_{\vartheta}|I|e^{-c_0V_Y}+Y^\vartheta,
\qquad 7/12<\vartheta<3/5.
\tag{13}
\]
Poisson 求和与 $\psi$ 的紧支撑对任意 $A>3$ 给，在实际 $n\asymp Y$ 区域，
\[
|K_H(2(p-n))|\ll_{\psi,\eta,A}H(1+|p-n|/W)^{-A},
\qquad
\left|\frac d{dn}K_H(2(p-n))\right|
\ll_{\psi,\eta,A}\frac HW(1+|p-n|/W)^{-A}.
\tag{14}
\]
把 $|p-n|\le W$ 作为第零壳，以 $2^jW$ 作其余壳。每壳至多两个整数区间，长度 $O(2^jW)$；权 $n\mapsto\psi(n/Y)K_H(2(p-n))/n$ 在该壳的上确界加变差为 $O_{\psi,\eta,A}((H/Y)2^{-j(A-1)})$。在每壳用 (13) 作离散 Abel 求和，合计得到
\[
\left|\sum_{Y<n<2Y}\frac{\Lambda(n)-1}{n}
  \psi(n/Y)K_H(2(p-n))\right|
\ll_{\psi,\eta,\vartheta}
 e^{-c_0V_Y}+HY^{\vartheta-1}.
\tag{15}
\]
高次素数幂的 $\Lambda$ 总质量至多 $O(\sqrt Y\log Y)$；由 $|K_H|\ll H$，将 $\Lambda$ 换回真正素数只花 $O(H\log Y/\sqrt Y)$。把系数 $1$ 形成的平滑整数和写成
\[
\sum_h\eta(h/H)e(-hp/Y)
\sum_{n\ge1}\frac{\psi(n/Y)}n e(hn/Y).
\]
内和由 $\Phi\in C_c^3((1,2))$ 的 Poisson 求和与三次分部积分为 $O_\psi(H^{-3})$，外和只有 $O(H)$ 项，因此平滑项为 $O_{\psi,\eta}(H^{-2})$。由于 $H\le Y^{1/4}$、$\vartheta<3/5$，(15) 后三项都有固定负幂；缩小 $c_0$ 即得 (7)。

证明 (7a) 不需新外部输入。由 $c(m)=2\mathbf1_{2\mid m}(\Lambda(m/2)-1)-4(\Lambda(m)-1+(\log2)\mu(m))$ 与 note 851 式 (4)，每个 $I\subset(2Y,4Y)$ 都满足
\[
\left|\sum_{m\in I}c(m)\right|
\ll_{\vartheta}|I|e^{-c_2V_Y}+Y^\vartheta,
\qquad 7/12<\vartheta<3/5.
\tag{15a}
\]
偶数项换元 $m=2n$，至多产生 $O(\log Y)$ 的端点费用，已被 $Y^\vartheta$ 吸收。把证明 (13)--(15) 的中心 $p$ 换成 $x\in[2Y,11Y/5]$、长度 $Y$ 换成 $2Y$、素数系数换成 $c(m)$，则每个 dyadic 位移壳的 Abel 费用同样合计为 $O(e^{-c_2V_Y}+H(2Y)^{\vartheta-1})$。$\psi$ 的紧支撑使所有参与的 $|x-m|<Y/5$，故非零 Poisson 别名保持远离；无需单独的光滑密度项。缩小 $c_1$ 得 (7a)。

最后，(5) 使 $a\in S_Y$ 的 $w_a\ge c_\psi/(2H\log Y)$。由 (4)，
\[
\|P_S\|_\eta^2\gg H\sum_{a\in S_Y}w_a^2
\ge\frac{c_\psi}{2\log Y}\sum_{a\in S_Y}w_a.
\tag{16}
\]
另一方面，展开 Gram 并固定所选素数 $p$，(7) 给
$|\langle P_S,B\rangle_\eta|
\ll e^{-c_1V_Y}\sum_{a\in S_Y}w_a$。
与 (16) 比较，$\log Y\,e^{-c_1V_Y}\to0$；再用
$\langle P_S,B-P_S\rangle_\eta
=-\|P_S\|_\eta^2+\langle P_S,B\rangle_\eta$，得到 (8)。$\square$

对 (8a) 的稀疏选择，$\sum_{a\in S_Y}w_a\ll K/(H\log Y)$。在 $\langle P_S,\mathcal A\rangle_\eta$ 中固定每个选中素数 $p$，其内层正是 (7a) 取 $x=2p$；因此 $|\langle P_S,\mathcal A\rangle_\eta|\ll e^{-c_1V_Y}K/(H\log Y)=o(H^4/M)$。同理 (7) 给 $|\langle P_S,B\rangle_\eta|=o(H^4/M)$，二者相减得 (8b) 第一式；再减去 $\|P_S\|_\eta^2$ 得第二式。$\square$

证明 (8c) 时对任意 $F=\sum_{a\in S_Y}\alpha_aP_a$ 应用 (7)、(7a)，得到
$|\langle F,\mathcal A\rangle_\eta|+|\langle F,B\rangle_\eta|
\ll e^{-c_1V_Y}\sum_a|\alpha_a|w_a$。Cauchy--Schwarz 与 (4) 给后者至多
$O(e^{-c_1V_Y}\sqrt{|S_Y|/H}\,\|F\|_\eta)$。对 $F\in\mathcal V_S$、$\|F\|_\eta=1$ 取上确界，即得投影平方界；$H^5\asymp M$、$|S_Y|e^{-2c_1V_Y}=o(1)$ 给最后的目标比较。$\square$

证明 (8e) 的裁剪精度。对 $v\in\{p^S,b,a\}$，活动物理点都位于 $M<m<11M/10$，且
$|v_m|\ll_\psi\log M/M$、$\sum_m|v_m|\ll_\psi1$；对选中序列另有
$\sum_m|p_m^S|=\sum_{a\in S_Y}w_a\ll K/(H\log Y)$。在 $|m-n|\le T$ 上用 $|K_H|\ll H$、内侧至多 $O(T+1)$ 个整数，得对上述任意 $v$
\[
\sum_{|m-n|\le T}|p_m^Sv_nK_H(m-n)|
\ll_{\psi,\eta}\frac{K(T+1)}M
=o(H^4/M),
\tag{17}
\]
因为 $K=e^{bV_Y}=Y^{o(1)}$ 而 $T/H^4=1/(H\log^2Y)$。在 $|m-n|>U$ 上，$\psi$ 的紧支撑排除周期别名，Poisson 求和给任意 $A>1$
$|K_H(m-n)|\ll_{\psi,\eta,A}H(1+H|m-n|/M)^{-A}
\ll H Y^{-A\delta}$。因此远差绝对值至多
$O_{\psi,\eta,A}((K/\log Y)Y^{-A\delta})=o(H^4/M)$，取固定 $A$ 足够大即可。把 (17) 和远差从 (8b) 以及 $\|P_S\|_\eta^2$ 的完整 Fourier Gram 中扣除，便得 (8e)。$\square$

## 判断边界

式 (4) 证明选窗的能量不能通过选择窗相位自行消失；式 (7) 把补偿证明到单窗粒度。式 (8e) 在真实中距离环带的门槛精度内定位一个超门槛稀疏子块的全部负投影，且补偿只需同一偶素数通道。对 note 849 式 (15) 的完整 $c_{\rm tri}+3$ 二点和，仍需达到 $H^4/M$ 的固定幂估计；本稿没有控制选窗以外的完整 Gram。
