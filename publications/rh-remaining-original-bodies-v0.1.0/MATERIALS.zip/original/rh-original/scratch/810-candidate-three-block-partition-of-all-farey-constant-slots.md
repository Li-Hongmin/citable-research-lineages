# 候选：全部 Farey 常值槽可分成三个各自有增长谱隙的主块

日期：2026-09-30。证明草稿，尚待独立复核。依赖 [note 809](../notes/809-polar-heavy-farey-exterior-and-small-numerator-slots-have-growing-gaps.md) 的外区带符号算术 Dirichlet 界与小分子内区谱隙、[note 808](../notes/808-full-farey-constant-polar-projection-has-positive-logarithmic-energy.md) 的 polar 质量、[note 806](../notes/806-all-bounded-farey-constant-slots-have-loglog-gap-and-positive-joint-compression.md) 的低斜率谱隙和全常值槽与阶跃偶极的混合界、[note 805](../notes/805-dense-farey-constant-slots-have-attraction-and-positive-joint-compression.md) 的常值槽核，以及 [note 804](../notes/804-full-farey-step-dipole-compression-has-uniform-positive-gap.md) 的阶跃谱隙。

## 命题

沿奇素数 \(p\to\infty\)，记 \(H=\log p\)、\(Q=\lfloor(p-1)/H\rfloor\)，并沿上游 notes 取全 Farey 常值奇槽空间 \(T_p\) 和阶跃偶极空间 \(W_p\)。固定实数
\[
r>\frac{2}{1-3/\pi^2};
\tag{1}
\]
特别可取 \(r=3\)。把全 Farey 集不交地分成
\[
\mathcal B_r=\{a/b\le r\},\qquad
\mathcal J_r=\{a/b>r,\ a\le Q\},\qquad
\mathcal E_r=\{a/b>r,\ a>Q\},
\tag{2}
\]
并用 \(B_r,J_r,E_r\) 表示相应常值槽张成空间。则
\[
T_p=B_r\oplus J_r\oplus E_r
\tag{3}
\]
是正交直和，而且三个**分别取出的真实旧奇 Weil 主压缩**满足
\[
\begin{aligned}
P_{B_r}A_{p^2,-}P_{B_r}&\succeq
\bigl(\log H-\log\log H-O_r(1)\bigr)I,\\
P_{J_r}A_{p^2,-}P_{J_r}&\succeq
\bigl(2\log H-O(1)\bigr)I,\\
P_{E_r}A_{p^2,-}P_{E_r}&\succeq
\left(1-\frac2r-\frac3{\pi^2}\right)H I
-O_r(\sqrt H\log H)I.
\end{aligned}
\tag{4}
\]
进一步，\(\dim E_r\asymp_r p^2\)，且
\[
\|P_{E_r}s_{p^2}\|^2
=\|P_{T_p}s_{p^2}\|^2-O_r(1)
=\frac{H}{4\zeta(2)}+O_r(1).
\tag{5}
\]
对 \(X=B_r,J_r,E_r\) 分别有
\[
P_{W_p\oplus X}A_{p^2,-}P_{W_p\oplus X}
\succeq(c_0-o_r(1))I,
\quad c_0=1+\gamma_E-\log\pi+\delta_0>0.
\tag{6}
\]
式 (4)--(6) **不**断言三个块的联合正定。

## 证明

第一行是 note 806 对固定斜率上限 \(R=r\) 的结论。第二行由 \(J_r\subset I_p=\{a\le Q\}\) 对 note 809 的内区 Loewner 下界取主压缩得到。

对第三行，\(E_r\subset\{a>Q\}\)。note 809 式 (6)--(7) 给带符号算术下界
\[
(D_pI-C^-)_{E_rE_r}
\succeq\bigl(H-O(\sqrt H\log H)\bigr)I,
\qquad D_p=2H+1-\gamma_E-\log\pi.
\tag{7}
\]
对不同 \(x,y>r\)，note 805 式 (20) 的 Farey 间距为
\(|\log(x/y)|>r/p^2\)。排序后，第 \(j\) 个单侧邻点距中心至少为 \(jr/p^2\)。note 805 式 (8) 与 \(2p^2\Delta<1\) 遂给
\[
M_\Delta(|\log(x/y)|)
\le\frac1{2(jr-1)}+C\Delta,
\qquad \Delta=\tfrac12\log(1+p^{-2}).
\]
因为 \(|\mathcal E_r|\le p^2\)，两侧行和至多
\[
\|N_{E_rE_r}\|
\le 2\sum_{j\le|\mathcal E_r|}
\left(\frac1{2(jr-1)}+C\Delta\right)
\le\frac2rH+O_r(1).
\tag{8}
\]
note 808 式 (4) 给
\[
2\|P_{E_r}s_{p^2}\|^2
\le2\|P_{T_p}s_{p^2}\|^2
=\frac3{\pi^2}H+O(1).
\tag{9}
\]
在 note 807 式 (12) 的完整常值槽分解中，异臂 Archimedean 矩阵 \(B\succeq0\)，故其主压缩也非负。将 (7)--(9) 与单槽 \(-\log2+O(\Delta)\) 对角项合并，即得 (4) 第三行。式 (1) 使主系数严格为正。

note 808 式 (12) 在固定 \(x\le r\) 上给 polar 平方质量 \(O_r(1)\)；note 809 式 (10) 对 \(a\le Q\) 给 \(O(H^{-1})\)。它们覆盖 \(T_p\setminus E_r\)，结合 note 808 式 (4) 即得 (5) 的质量式。

维数上界为 \(|\mathcal F_p|=O(p^2)\)。取一个固定小矩形
\[
\frac{p}{2(r+1)}\le b\le\frac{p}{2r},
\qquad rb<a<(r+1)b.
\]
其点都满足 \(a/b>r\)、\(a<p\)，且对充分大的 \(p\) 有 \(a>Q\)。逐点 Möbius 反演的互素格点计数给该矩形内 \(c_rp^2+O_r(p\log p)\) 个既约点，\(c_r>0\)，从而 \(\dim E_r\asymp_r p^2\)。

最后 note 806 对全部常值 Farey 槽给 \(\|P_{W_p}A_{p^2,-}P_{T_p}\|=O(1)\)，所以三块各自的混合范数也有界。note 804 给 \(A_{W_p}\succeq(c_0-o(1))I\)；(4) 的三个增长谱隙分别使 Schur 损失趋零，证明 (6)。\(\square\)

## 边界

这个分拆覆盖了全部常值槽，且最大块同时承载 polar 的渐近全部质量。剩余问题是三个块之间的真实算术交叉以及全部槽内非恒定轮廓和无限维正交补；单独主压缩的正性不能替代这些 Schur 项，更不能推出全尺度 Weil 正性或 RH。
