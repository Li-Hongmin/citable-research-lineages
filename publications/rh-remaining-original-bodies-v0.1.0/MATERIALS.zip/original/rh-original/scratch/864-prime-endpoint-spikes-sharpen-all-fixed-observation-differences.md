# 质数端点尖峰使每个固定高阶观察差分范数都达到上界（探索证明，尚未独立复核）

日期：2026-10-02。直接使用 note 847 式 (4)--(8) 的观察序列和 note 849 式 (2)--(3) 已复核的端点导数跳跃。本结论只证明固定阶差分范数的阶是尖锐的，不给完整余项均方的下界。

## 命题

固定非零、实值 \(\psi\in C_c^3((1,2))\)，沿整数 \(Y\to\infty\) 令
\[
 W_n=\psi(n/Y)\mathcal R_{n,2},\qquad
 \Delta^2W_n=W_{n+2}-2W_{n+1}+W_n .
\]
则存在只依赖 \(\psi\) 的 \(c_\psi>0\)，使
\[
 \boxed{\quad
 \sum_{n\in\mathbb Z}|\Delta^2W_n|^2
 \ge c_\psi\frac{\log Y}{Y}
 \quad}
\]
对充分大 \(Y\) 成立。结合 note 847 式 (8)，该和为
\(\asymp_\psi(\log Y)/Y\)。

## 证明

在整数 \(n\) 上有 \(\sum_{n<r<2n}\sin(2\pi r/n)=0\)，故可以按 note 849 以
\[
 F_r(t)=\psi(t/Y)\mathbf1_{r/2<t<r}
 [a_r+\mu(r)\log(r/t)]\sin(2\pi r/t),
 \qquad a_r=\Lambda(r)-1,
\]
插值 \(W_n=-\sum_rF_r(n)\)。note 849 式 (2) 给连续函数 \(F_r\) 的导数跳跃
\[
 J_r=\frac{2\pi}{r}\psi(r/Y)a_r,\qquad
 J_{r/2}=-\frac{8\pi}{r}\psi(r/(2Y))
 [a_r+(\log2)\mu(r)] .
\]
其式 (3) 的光滑段界在 \(t\asymp Y\) 上还直接给
\(\lvert F_{r,\mathrm{reg}}''(t)\rvert
 \ll_\psi (|a_r|+|\mu(r)|)Y^{-2}\)；
相关 \(r\) 均满足 \(r\asymp Y\)。

对连续、分片 \(C^2\) 的函数 \(F\)，令
\[
 \tau_n(t)=
 \begin{cases}t-n,&n\le t\le n+1,\\ n+2-t,&n+1\le t\le n+2,\\0,&\text{其余}.\end{cases}
\]
两次积分或分布导数给精确式
\[
 \Delta^2F(n)=\int\tau_n(t)F''_{\mathrm{reg}}(t)\,dt
 +\sum_s\tau_n(s)\bigl(F'(s+)-F'(s-)\bigr).
\]
取 \(n=p-1\)，其中 \(p\asymp Y\) 为质数。唯一带非零三角权的上端点 \(r\) 是 \(r=p\)，其权为 \(1\)。带权下端点 \(r/2\) 只能来自
\(r=2p-1,2p,2p+1\)，权分别为 \(1/2,1,1/2\)。由 Chebyshev 界
\(\sum_{r\le4Y}(\Lambda(r)+1)\ll Y\)，全部光滑段积分之和为
\(O_\psi(Y^{-1})\)。因此
\[
\begin{aligned}
\Delta^2W_{p-1}
={}&-\frac{2\pi}{p}\psi(p/Y)(\log p-1)\\
&+\sum_{r\in\{2p-1,2p,2p+1\}}
 \tau_{p-1}(r/2)\frac{8\pi}{r}\psi(r/(2Y))
 [\Lambda(r)-1+(\log2)\mu(r)]
 +O_\psi(Y^{-1}).
\end{aligned}
\tag{*}
\]

取闭区间 \(J\subset(1,2)\) 使 \(|\psi|\ge c_0>0\) 于 \(J\)。
对 \(p\equiv2\pmod {15}\)，数 \(2p-1\) 被 \(3\) 整除，\(2p+1\) 被 \(5\) 整除。
除至多 \(O(\log Y)\) 个满足 \(2p-1=3^k\) 或 \(2p+1=5^k\) 的 \(p\) 外，
两数均非素数幂，故 \(\Lambda(2p\pm1)=0\)。
对奇素数 \(p\)，\(2p\) 也非素数幂。因此 (*) 的第二行是
\(O_\psi(Y^{-1})\)，而第一行的绝对值至少为
\(c_\psi(\log Y)/Y\)。

固定模数 \(15\) 的素数定理给
\(\#\{p\in YJ:p\equiv2\pmod {15}\}\gg_JY/\log Y\)。
去除上述 \(O(\log Y)\) 个例外后，取这些互异 \(n=p-1\) 的平方并求和，即得
\[
 \sum_n|\Delta^2W_n|^2
 \gg_\psi \frac{Y}{\log Y}
 \left(\frac{\log Y}{Y}\right)^2
 =\frac{\log Y}{Y}.
\]

## 每个固定阶数均保留同一尖峰

更一般地，对每个**固定**整数 \(j\ge2\)，有
\[
 \boxed{\quad
 \sum_{n\in\mathbb Z}|\Delta^jW_n|^2
 \asymp_{\psi,j}\frac{\log Y}{Y}.
 \quad}
\tag{**}
\]
上界由 \(\Delta^j=\Delta^{j-2}\Delta^2\) 和
\(\|\Delta\|_{\ell^2\to\ell^2}\le2\)，结合 note 847 式 (8) 立即得到。

为证下界，仍选 \(n=p-1\)。在整数样点
\(p-1,p,\ldots,p+j-1\) 上，\(F_p\) 只有第一个值非零，且
\[
 F_p(p-1)=\frac{2\pi}{p}\psi(p/Y)(\log p-1)
 +O_{\psi,j}(\log Y/Y^2).
\]
因此 \(F_p\) 对 \(\Delta^jW_{p-1}\) 的贡献为
\(-(-1)^j(2\pi/p)\psi(p/Y)(\log p-1)
+O_{\psi,j}(\log Y/Y^2)\)。

其他可能在 \((p-1,p+j-1)\) 内遇到的上端点为
\(r=p+k\)（\(1\le k\le j-2\)）；下端点为
\(r=2p+s\)（\(-1\le s\le2j-3\)）。其中 \(s=0\) 的
\(2p\) 自动不是素数幂。对每个其余线性式 \(p+k\)、
\(2p+s\) 选一个彼此不同、且不整除其非零常数项的固定奇素数
\(q_{k}\) 或 \(q_s\)，并以中国剩余定理选一个与其乘积互素的
剩余类，使各线性式分别被指定的素数整除。这个剩余类存在：
对 \(p+k\) 施加 \(p\equiv-k\pmod {q_k}\)；
对 \(2p+s\) 施加 \(p\equiv-s\,2^{-1}\pmod {q_s}\)。
每个指定素数均大于对应常数项的绝对值，故这些约束没有使
\(p\) 被它整除。

固定模数的素数定理给该剩余类中 \(p\in YJ\) 的个数
\(\gg_{\psi,j}Y/\log Y\)。对每个线性式，其值若仍是素数幂，
必为指定素数的某个幂；这只排除 \(O_j(\log Y)\) 个 \(p\)。
余下 \(p\) 使所有其他内部端点的 \(\Lambda(r)=0\)。
这些端点对应的 \(a_r=-1\)、\(|\mu(r)|\le1\)，每个
\(\Delta^jF_r(p-1)=O_{\psi,j}(Y^{-1})\)，且端点数仅
\(O_j(1)\)。不含内部端点的每个 \(F_r\) 在样点跨度内
属于一个光滑片或恒为零；因 \(j\ge2\) 且
\(|F''_r|\ll_\psi(|a_r|+|\mu(r)|)Y^{-2}\)，
其 \(j\) 阶差分至多
\(O_{\psi,j}((|a_r|+|\mu(r)|)Y^{-2})\)。
Chebyshev 界把这些光滑贡献总和控制在
\(O_{\psi,j}(Y^{-1})\)。于是上述每个 \(p\) 都给
\(|\Delta^jW_{p-1}|\gg_{\psi,j}(\log Y)/Y\)；
对 \(\gg Y/\log Y\) 个互异 \(p\) 求平方即得 (**)。

## 边界

式 (**) 说明原始序列的每个固定高阶差分都有同阶尖峰。
仅把 note 847 的全局差分范数和周期 Parseval 结合，第
\(j\) 阶所需的高频切点反而是
\(H\gtrsim Y^{(2j-3)/(2j)}\)（忽略对数），以 \(j=2\)
的 \(Y^{1/4}\) 最低。这是**该范数估计法**的边界，
不说明实际高观察频率能量达到这些上界；
减去 note 849 的显式端点主项后仍可建立更强估计。
