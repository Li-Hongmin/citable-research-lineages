# 全 Farey 外区块的对数谱隙与自然方向的正 Schur 余量（候选）

此候选已晋级为 [note 803](../notes/803-farey-exterior-block-has-logarithmic-gap-and-natural-schur-direction-stays-positive.md)；以该 note 为权威版本。

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确算术图、正权行式与 Archimedean 有界压缩，以及 [note 795](../notes/795-full-farey-dipole-archimedean-remainder-is-uniformly-positive.md) 的单偶极接触常数。本文给出全 Farey **阶跃偶极主压缩**中外区块的谱隙与一个指定内区向量的真实外区 Schur 余量；证明尚待异源复核，暂留 scratch。

## 命题

令奇素数 \(p\to\infty\)，\(P=p-1\)、\(H=\log p\)、\(Q=\lfloor P/H\rfloor\)、\(\tau=\log(P/Q)\sim\log H\)。沿 note 791 记 \(A_W=D_pI-C_p+E_p\)，\(D_p=2H+1-\gamma_E-\log\pi\)。令 \(I=\mathcal F_Q\)、\(R=\mathcal F_P\setminus I\)，\(A_R=P_RA_WP_R\)，并令 \(u_I,u_R\) 是分别在 \(I,R\) 上取坐标 \(v_{a/b}=(ab)^{-1/2}\) 的向量，\(Z_Q=\|u_I\|^2\)。则

\[
\boxed{\quad \|P_RC_pP_R\|\le H+O(\sqrt H\log H),\qquad
A_R\succeq\bigl(H-O(\sqrt H\log H)\bigr)I_R.\quad}\tag{1}
\]

特别地，充分大 \(p\) 时 \(A_R\succeq(H/2)I_R\)。沿自然内区向量的**完整外区** Schur 余量满足

\[
\boxed{\quad
\frac{\langle u_I,A_Wu_I\rangle
-\langle A_{RI}u_I,A_R^{-1}A_{RI}u_I\rangle}{Z_Q}
\longrightarrow c_*:=1+\gamma_E-\log\pi+\log2>0.\quad}\tag{2}
\]

这是消去 \(R\) 的全部 Farey 偶极后的单向量结论；不涉及 \(I\) 中任意轮廓的统一 Schur 界，也不消去 \(W_p^\perp\)。

## 1. 展开成有序互素对

令 \(\Omega_P=\{(a,b):1\le a,b\le P,\ (a,b)=1,\ a\ne b\}\)，在 \(\ell^2(\Omega_P)\) 上定义对称逐项非负矩阵
\[
B((a,b),(c,d))=c_{(a/b)/(c/d)}+c_{(c/d)/(a/b)},
\qquad c_t=\begin{cases}\Lambda(t)/\sqrt t,&t\text{ 为整数素数幂},\\0,&\text{其他情形}.\end{cases}
\tag{3}
\]
由 \(c_1=0\) 可知没有自环。把 \(f\in\ell^2(\mathcal F_P)\) 等距送到交换对称子空间，令
\((Jf)_{a,b}=f_{\max(a/b,b/a)}/\sqrt2\)。直接展开四个有序配对，得到
\[
J^*BJ(x,y)=c_{x/y}+c_{y/x}+c_{xy}=C_p(x,y).
\tag{4}
\]
此式对 \(x=y\) 也成立，包含 \(c_{x^2}\) 自环。外区在有序坐标中恰为
\(\Omega_R=\{(a,b)\in\Omega_P:\max(a,b)>Q\}\)，故
\(\|P_RC_pP_R\|\le\|P_{\Omega_R}BP_{\Omega_R}\|\)。

固定素数 \(\ell\)。若从互素对 \((a,b)\) 乘以或除以 \(\ell^r\) 后，\(\ell\) 仍在原来的分子臂或分母臂，只有一个整数坐标变化。全部这种边逐项由
\[
K_P\otimes I+I\otimes K_P,
\qquad K_P(m,n)=c_{m/n}+c_{n/m}
\quad(1\le m,n\le P)
\tag{5}
\]
支配；允许非互素端点只会把右侧增大。剩下的边跨越 \(\ell\)-指数零点：若 \(\ell^v\Vert ab\)、\(v\ge1\)，跨臂所需的素数幂是 \(\ell^{v+h}\)、\(h\ge1\)。因此跨臂矩阵每行的绝对和至多
\[
\sum_{\ell\mid ab}\sum_{h\ge1}\frac{\log\ell}{\ell^{(v_\ell+h)/2}}
\ll\sum_{\ell\mid ab}\frac{\log\ell}{\ell}
\ll\log H.\tag{6}
\]
最后一个界把 \(\ell\le H\) 的和放大为
\(\sum_{n\le H}\Lambda(n)/n=\log H+O(1)\)；对 \(\ell>H\)，用
\(\sum_{\ell\mid ab}\log\ell\le\log(ab)\le2H\)。跨臂矩阵对称，Schur 检验给算子范数 \(O(\log H)\)。

## 2. 单坐标上端带的块界

把 \(\{1,\dots,P\}=L\sqcup U\)，其中 \(L=\{1,\dots,Q\}\)、\(U=\{Q+1,\dots,P\}\)。记 \(K_{LL},K_{UU},K_{LU}\) 为 (5) 的相应块，并令 \(\alpha=\|K_{UU}\|\)、\(\beta=\|K_{LL}\|\)、\(\kappa=\|K_{LU}\|\)。

在 \(U\) 内，任一素数幂比值至多 \(P/Q\asymp H\)，每个素数幂至多给一条向上和一条向下的边。直接的普通行和界给
\[
\alpha\le2\sum_{n\le P/Q}\frac{\Lambda(n)}{\sqrt n}
\ll\sqrt H\log H.\tag{7}
\]
在 \(L\) 内取正权 \(v_m=m^{-1/2}\)。逐素数幂计数给
\[
\frac{(K_{LL}v)_m}{v_m}=\log m+\mathfrak M(Q/m)
\le\log Q+O(1),
\qquad \mathfrak M(t)=\sum_{n\le t}\frac{\Lambda(n)}n.
\tag{8}
\]
所以 \(\beta\le\log Q+O(1)\)。对矩形块，\(m\in U\) 一侧的加权行和至多
\(\sum_{n\mid m}\Lambda(m/n)\le\log m\le H\)；\(n\in L\) 一侧至多
\(\mathfrak M(P/n)-\mathfrak M(Q/n)\le\tau+O(1)\)。矩形 Schur 检验于是给
\[
\kappa\ll\sqrt{H(\tau+1)}.\tag{9}
\]

在整个有序对空间，\(\Omega_R\) 被包含于
\((U\times L)\sqcup(L\times U)\sqcup(U\times U)\)。把 (5) 压到这个三块并按每块向量范数比较，其标量支配矩阵是
\[
\begin{pmatrix}
\alpha+\beta&0&\kappa\\
0&\alpha+\beta&\kappa\\
\kappa&\kappa&2\alpha
\end{pmatrix}.
\tag{10}
\]
其范数至多 \(\max(\alpha+\beta,2\alpha)+\sqrt2\kappa\)。由 (7)--(9)、\(\tau\sim\log H\) 得
\[
\|P_{\Omega_R}BP_{\Omega_R}\|
\le\log Q+O(\sqrt H\log H)
=H+O(\sqrt H\log H).\tag{11}
\]
这里还加上了 (6) 的 \(O(\log H)\) 跨臂范数。note 791 的 \(\|E_p\|=O(1)\) 和 \(D_p=2H+O(1)\) 遂证明 (1)。

## 3. 真实 Schur 余量

置 \(u=u_I+u_R\)、\(h_R=P_RA_Wu\)。note 791 的正权行式给
\[
\frac{((D_pI-C_p)u)_{a/b}}{v_{a/b}}
=1-\gamma_E-\log\pi+2\log(p/P)
-e(P/a)-e(P/b)+\Lambda(a)\mathbf1_{b=1},
\quad e(t)=\mathfrak M(t)-\log t=O(1).
\tag{12}
\]
调和质量满足 \(Z_Q\asymp H^2\)、\(\|u_R\|^2=O(H\tau)\)。在非轴外区，(12) 的系数一致有界；轴上用 \(\Lambda(a)^2\le H\Lambda(a)\) 及 Mertens 估计得到
\[
\sum_{Q<a\le P}\frac{\Lambda(a)^2}{a}
\le H\bigl(\mathfrak M(P)-\mathfrak M(Q)\bigr)
\ll H(\tau+1).
\tag{13}
\]
故 \(\|P_R(D_pI-C_p)u\|^2/Z_Q\ll\tau/H\)。又 \(\|E_pu\|^2/Z_Q=O(1)\)，因 \(\|E_p\|=O(1)\) 且 \(\|u\|^2/Z_Q\to1\)。于是 \(\|h_R\|^2/Z_Q=O(1)\)，而 (1) 给
\[
0\le\frac{\langle h_R,A_R^{-1}h_R\rangle}{Z_Q}
\le\frac{2\|h_R\|^2}{HZ_Q}=O(H^{-1})=o(1).\tag{14}
\]

最后核对全正权能量的常数。\(e(t)\to-\gamma_E\)；把 \(a>P/M\) 的调和尾剔除后，其质量相对 \(Z_P\) 为 \(O(\log M/H)\)，再令固定 \(M\to\infty\)，便有
\[
\langle u,C_pu\rangle/\|u\|^2=2\log P-2\gamma_E+o(1).
\tag{15}
\]
轴修正相对质量为 \(O(H^{-1})\)。note 791 式 (12) 与内区 Farey 间距给
\(\|P_IE_pP_I-(\log2)I\|=o(1)\)；note 795 式 (7) 给单偶极对角 \(\log2+o(1)\)。由于 \(\|u_R\|/\|u_I\|\to0\) 且 \(\|E_p\|=O(1)\)，这也给
\(\langle u,E_pu\rangle/\|u\|^2\to\log2\)。结合
\(D_p=2H+1-\gamma_E-\log\pi\)、\(\log P=H+o(1)\)，得
\[
\langle u,A_Wu\rangle/Z_Q=c_*+o(1).\tag{16}
\]
令 \(g=A_{RI}u_I\)，则 \(h_R=g+A_Ru_R\)。在 \(R\) 上完成平方，得到精确恒等式
\[
\langle u_I,A_Wu_I\rangle-\langle g,A_R^{-1}g\rangle
=\langle u,A_Wu\rangle-\langle h_R,A_R^{-1}h_R\rangle.
\tag{17}
\]
(14)、(16)、(17) 证明 (2)。由 \(\gamma_E>1/2\)、\(\pi<4\)、\(\log2<1\)，有 \(c_*>3/2-\log2>1/2\)。\(\square\)

## 边界

这个结果排除了 [scratch 855](855-farey-boundary-residual-vanishes-unless-exterior-gap-collapses-candidate.md) 中该 **Farey 外区块** 出现近零谱隙的可能，也闭合了自然调和权方向的外区逆响应。它没有控制整个内区 Schur 算子、其余 Farey 轮廓、无限维补空间或 moving-\(N\) Möbius signed covariance，因此不构成 RH 证明。
