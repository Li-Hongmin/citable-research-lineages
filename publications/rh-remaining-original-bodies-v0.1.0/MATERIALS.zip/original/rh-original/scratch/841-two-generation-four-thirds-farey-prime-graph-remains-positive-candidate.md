# \(4/3\) 的两代素数 Farey 图仍有严格对数 Weil 谱隙（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确 Farey 算术图与有界 Archimedean 修正，以及 [scratch 840](840-four-thirds-prime-farey-star-has-a-strict-logarithmic-weil-gap-candidate.md) 的第一代星。本文加入全部互异双素数叶；尚待异源复核，留在 scratch。

## 命题

沿奇素数 \(p\to\infty\) 置 \(k=p^2\)、\(L=\log k\)、\(x_0=4/3\)，并令
\[
\mathcal P_p=\{q\ge5:q\text{ 素数},\ q<(p-1)/4\},
\quad
\mathcal Q_p=\{\{q,r\}:q,r\in\mathcal P_p,\ q<r,\ qr<(p-1)/4\}.
\]
在 note 791 的真实旧奇空间中取
\[
V_p^{(2)}=\operatorname{span}\bigl(
w_{4/3},\ w_{4q/3}\ (q\in\mathcal P_p),\
w_{4qr/3}\ (\{q,r\}\in\mathcal Q_p)
\bigr)\subset W_p.
\tag{1}
\]
则整个两代图的真实 Weil 主压缩满足
\[
\boxed{\quad
\lambda_{\min}\bigl(P_{V_p^{(2)}}A_{p^2,-}P_{V_p^{(2)}}\bigr)
\ge\left(1-\sqrt{\frac38}\right)L-O(1)>0.
\quad}
\tag{2}
\]
因此所有第一、二代素数叶及它们之间的真实算术边仍不能给出负方向。第三代及更深因子层未被包含。

## 精确三层图

写 \(c_q=\log q/\sqrt q\)。所有 (1) 中的分数均已约分为分母 \(3\)，其分子小于 \(p\)；所以 note 791 的对应 \(w_x\) 是正交单位族。任意两节点的乘积仍有分母 \(9\)，而其分子仅含 \(2\) 和 \(\ge5\) 的素因子，故乘积不可能为整数素数幂。比值为整数素数幂当且仅当两个标签的素数集合相差**恰好一个**素数。于是全部算术边精确为
\[
C_p(x_0,4q/3)=c_q,
\qquad
C_p(4q/3,4qr/3)=c_r,
\qquad
C_p(4r/3,4qr/3)=c_q;
\tag{3}
\]
其余非对角元和全部对角自环为零。

把中间的素数层放在一侧，把根与双素数层放在另一侧。算术矩阵便是 \(\begin{psmallmatrix}0&B^*\\B&0\end{psmallmatrix}\)。令
\[
S=\sum_{q\in\mathcal P_p}c_q^2,
\qquad
T_q=\sum_{\substack{r\in\mathcal P_p\\r\ne q,\ qr<(p-1)/4}}c_r^2\le S.
\]
在素数层上，\(BB^*\) 的根列贡献为 \(cc^*\)；每个双素数列 \(\{q,r\}\) 在第 \(q,r\) 行分别为 \(c_r,c_q\)。故对严格正向量 \(c=(c_q)_q\)，有精确行恒等式
\[
\frac{(BB^*c)_q}{c_q}=S+2T_q\le3S.
\tag{4}
\]
\(BB^*\) 对称、逐项非负且半正定；正权 Schur 界因此给
\[
\|B\|^2=\|BB^*\|\le3S,
\qquad
\left\|P_{V_p^{(2)}}C_pP_{V_p^{(2)}}\right\|\le\sqrt{3S}.
\tag{5}
\]
[scratch 840](840-four-thirds-prime-farey-star-has-a-strict-logarithmic-weil-gap-candidate.md) 式 (4) 给 \(S=L^2/8+O(L)\)，故 \(\sqrt{3S}=\sqrt{3/8}\,L+O(1)\)。note 791 式 (6) 给真实压缩 \(D_kI-C_p+E_p\)，其中 \(D_k=L+1-\gamma_E-\log\pi\)、\(\|E_p\|=O(1)\)。于是
\[
P_{V_p^{(2)}}A_{p^2,-}P_{V_p^{(2)}}
\succeq\bigl(D_k-\sqrt{3S}-O(1)\bigr)I,
\]
证明 (2)。\(\square\)

## 边界

该正谱隙只属于 (1) 的两代有限主压缩。继续加入第三代、素数幂、其他分母和完整无限维补空间时，Schur 反馈可能仍有 \(L\) 量级；不能由 (2) 推断全尺度局部 Weil 正性或 RH。
