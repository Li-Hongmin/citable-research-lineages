# 末带素数窗在同一两端点素数通道内取得负协方差

日期：2026-10-02。此稿依赖 [note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 的真实素数窗及其一致素数计数、[note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的观察变量 Fourier 坐标，以及 [note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 已核对的短和输入。[scratch 902](902-local-bandpass-rank-one-main-term-is-repaid-by-each-channel-sidelobe.md) 已发现素数通道的远旁瓣自偿；此稿对 note 845 的特定真素数窗给出整个带通 Gram 的显式常数，并接到 scratch 962 的真实短块。本稿是新推导，尚待异源复核；不估计完整 signed Gram，也不证明 RH。

## 命题

固定 \(1/5\le\gamma<1/4\)，沿整数 \(Y\to\infty\) 令 \(H=\lfloor Y^\gamma\rfloor\)、\(M=2Y\)。取实值非负、非零的 \(\psi\in C_c^3((1,11/10))\)，以及 note 849 的非负偶带通权 \(\eta\)，其中 \(\eta(1)\ge1\)。令 \(I_a\) 为 note 845 式 (1) 的真实素数窗，\(H<a\le11H/10\)，并置 \(\mathcal P=\bigcup_a\{p\in I_a:p\text{ 为素数}\}\)。在同一个观察频带定义
\[
P_h=\sum_{p\in\mathcal P}\frac{\log p}{p}\psi(p/Y)e(-hp/Y),\qquad
B_h=\sum_{Y<p<2Y\atop p\text{ 为素数}}\frac{\log p}{p}\psi(p/Y)e(-hp/Y),
\quad Q_h=B_h-P_h.                                      \tag{1}
\]
这里 \(B_h\) 正是 note 849 的单格 \(m=2p\) 处的偶素数端点通道；\(P_h\) 是其中被 \(I_a\) 选出的实际素数，不是 note 845 的物理 Poisson 子和 \(G_N\)。以 \(\langle U,V\rangle_\eta=\sum_{h\in\mathbb Z}\eta(h/H)U_h\overline{V_h}\) 记带通内积。则
\[
P_H=\frac{C_\psi+o(1)}{\log Y},\qquad
C_\psi=\int_1^{11/10}\psi(x)\,dx>0,                  \tag{2}
\]
且某个固定 \(c>0\) 满足
\[
\|B\|_\eta\ll_{\psi,\eta}e^{-cV_Y},\qquad
V_Y=(\log Y/\log\log Y)^{1/3}.                         \tag{3}
\]
更精确地，设 \(C_\eta=\sum_{n\in\mathbb Z}\eta(n)\ge4\)。则同一真实素数通道内有显式 Gram 主项
\[
\boxed{\quad
\|P\|_\eta^2
=\frac{C_\eta}{(\log Y)^2}\int_1^{11/10}\psi(x)^2\,dx
+o((\log Y)^{-2}),
\qquad
\langle P,Q\rangle_\eta=-\|P\|_\eta^2+o((\log Y)^{-2}).
\quad}                                                   \tag{4}
\]
若 \(\mathcal A_h\) 是 note 849 式 (11) 的**完整真实三通道系数**，则更直接地有
\[
\boxed{\quad
\langle P,\mathcal A-B\rangle_\eta=o((\log Y)^{-2}),
\qquad
\langle P,\mathcal A-P\rangle_\eta
=-\frac{C_\eta}{(\log Y)^2}\int_1^{11/10}\psi(x)^2dx
+o((\log Y)^{-2}).\quad}                              \tag{4a}
\]
因此对这一选窗在 \(\log^{-2}Y\) 主量级的补偿，未选偶素数已承担全部；其他真实通道的投影只在较小量级。式 (4a) 不把较小量级改进到 \(H^4/M\)。

还有目标精度内的真实短块版本。固定 \(7/12<\vartheta<\rho<3/5\)，将 \((M,2M)\) 分成长度 \(B_0=\lceil M^\rho\rceil\) 的连续整数块 \(C_i\)，取块中心 \(x_i\)。定义
\[
d_{2p}^{P}=M\frac{\log p}{p}\psi(p/Y)\mathbf1_{p\in\mathcal P},\qquad
d_{2p}^{Q}=M\frac{\log p}{p}\psi(p/Y)\mathbf1_{Y<p<2Y,\ p\notin\mathcal P},
\quad D_i^P=\sum_{m\in C_i}d_m^P,\quad D_i^Q=\sum_{m\in C_i}d_m^Q, \tag{5}
\]
其余 \(d_m^P,d_m^Q\) 均为零。若 \(K_H(k)=\sum_h\eta(h/H)e(-hk/M)\)，则
\[
\boxed{\quad
\frac1{M^2}\sum_{i,j}D_i^PD_j^QK_H(x_i-x_j)
=-\frac{C_\eta}{(\log Y)^2}\int_1^{11/10}\psi(x)^2\,dx
+o((\log Y)^{-2}),
\quad}                                                   \tag{6}
\]
其中从原整数 Gram 换成块 Gram 的绝对误差为
\[
O_{\psi,\eta,\vartheta,\rho}(HB_0/M)
=o(H^4/M).                                          \tag{7}
\]
令 \(D_i^{\rm all}=\sum_{m\in C_i}c(m)\psi(m/M)/(m/M)\) 为 scratch 962 的**完整真实短块**，且 \(D_i^B=D_i^P+D_i^Q\)。同一块化误差给
\[
\boxed{\quad
\frac1{M^2}\sum_{i,j}D_i^P(D_j^{\rm all}-D_j^B)K_H(x_i-x_j)
=o((\log Y)^{-2}),
\qquad
\frac1{M^2}\sum_{i,j}D_i^P(D_j^{\rm all}-D_j^P)K_H(x_i-x_j)
=-\frac{C_\eta\int_1^{11/10}\psi^2}{(\log Y)^2}
+o((\log Y)^{-2}).\quad}                              \tag{7b}
\]
所以这一选窗在完整短块中的领先负协方差由未选偶素数承担；它没有给剩余 \(H^4/M\) 精度的 Möbius 二点上界。

同一素数窗的**物理**源与端点掩码还有可核对的量级差。若 \(G_N\) 是 note 845 式 (2) 的真实 Poisson 子和，取任意固定 \(\chi\in C_c^\infty((3/2,8/5))\)，令 \(f(z)=\mathcal L(z)/z\) 如该 note 式 (3)，则
\[
\frac{2\pi H^2}{Y^2}
\sum_N\chi(N/Y)G_Ne(-HN/Y)
=\frac{\int\chi(z)f(z)\,dz+o(1)}{(\log Y)^2}.
\tag{7a}
\]
这是 note 849 第一 jet 乘子的形式归一化；它比 (2) 的 \(P_H\) 还小一位 \(\log Y\)。式 (7a) 不声称 \(G_N\) 单独具有 note 849 的端点展开，因而也不构造 \(G\mapsto P\) 的线性恒等式。

## 正近差与负远旁瓣

固定足够小的 \(0<\delta<1/4\)，使 \(\widehat\eta(v)>0\) 于 \(|v|\le\delta\)。取实值偶函数 \(\tau\in C_c^\infty((-\delta,\delta))\)，\(0\le\tau\le1\)、\(\tau(0)=1\)，并令
\[
K_H^{\rm near}(k)=K_H(k)\tau(Hk/M),\quad
K_H^{\rm far}=K_H-K_H^{\rm near},\quad
J_{\eta,\tau}=\int\widehat\eta(v)\tau(v)\,dv>0. \tag{7c}
\]
写 \(w_p=(\log p/p)\psi(p/Y)\)，且把 \(w_q\) 在 \(q\notin(Y,2Y)\) 置零。则同一实际素数窗有
\[
\boxed{\begin{aligned}
\sum_{p\in\mathcal P}\sum_{q\notin\mathcal P\atop q\text{ prime}}
w_pw_qK_H^{\rm near}(2(p-q))
&=\frac{J_{\eta,\tau}}{\log Y}
\int_1^{11/10}\frac{\psi(x)^2}{x}\,dx+o((\log Y)^{-1}),\\
\sum_{p\in\mathcal P}\sum_{q\notin\mathcal P\atop q\text{ prime}}
w_pw_qK_H^{\rm far}(2(p-q))
&=-\frac{J_{\eta,\tau}}{\log Y}
\int_1^{11/10}\frac{\psi(x)^2}{x}\,dx+o((\log Y)^{-1}).
\end{aligned}}                                            \tag{7d}
\]
近差项逐项非负，远旁瓣给出相反的 \(1/\log Y\) 主项。这仍不提供 \(H^4/M\) 精度。

式 (7d) 也适用于式 (5) 的短块 Gram：将两和中的 \(w_pw_qK_H^\star(2(p-q))\) 分别换为 \(M^{-2}D_i^PD_j^QK_H^\star(x_i-x_j)\) 并按 \(i,j\) 求和，\(\star\in\{\mathrm{near},\mathrm{far}\}\)，主项不变，且每次替换的绝对误差仍为 \(O(HB_0/M)=o(H^4/M)\)。

## 证明

note 845 式 (6)、(8) 对所有 \(a\) 一致给
\[
t_a=\frac{aY}{H}+O(1),\qquad
B_a=\frac{aY}{H^2\log Y}(1+o(1)),\qquad
\sum_{p\in I_a\atop p\text{ prime}}\log p=B_a(1+o(1)). \tag{8}
\]
相邻 \(t_a\) 相距 \(Y/H+O(1)\)，而 \(B_a\asymp Y/(H\log Y)\)，故各 \(I_a\) 对充分大 \(Y\) 不交。对 \(p\in I_a\)，有 \(p/Y=a/H+O((H\log Y)^{-1})\) 以及 \(e(-Hp/Y)=1+O(1/\log Y+H/Y)\)。将这些一致近似代入 (1)，使用 (8) 后得到
\[
P_H=\frac{1+o(1)}{H\log Y}
\sum_{H<a\le11H/10}\psi(a/H)
=\frac{C_\psi+o(1)}{\log Y},                         \tag{9}
\]
证明 (2)。为求整个 Gram，记
\[
w_a=\sum_{p\in I_a\atop p\text{ prime}}
\frac{\log p}{p}\psi(p/Y)
=\frac{\psi(a/H)}{H\log Y}+o\!\left(\frac1{H\log Y}\right)
\quad\text{一致于 }a.                                  \tag{9a}
\]
这里使用 (8) 以及 \(p/Y=a/H+O((H\log Y)^{-1})\)；误差的 \(o(\cdot)\) 是统一的绝对误差，不要求 \(\psi(a/H)>0\)。令 \(\widehat\eta(\xi)=\int\eta(t)e(-\xi t)dt\)。Poisson 求和和 \(p\in I_a,q\in I_b\) 给
\[
K_H(2(p-q))
=H\widehat\eta(a-b)
+O_A\!\left(\frac H{\log Y}(1+|a-b|)^{-A}+H^{1-A}\right)
\quad(A>2).                                             \tag{9b}
\]
因为 \(H(p-q)/Y=a-b+O(1/\log Y)\)，且 \(|p-q|/Y<1/5\)，所以非零周期别名都离原点至少 \(4H/5\)。由 \(\widehat\eta\) 的快速衰减、\(\sum_aw_a\ll1/\log Y\) 和 \(\sup_aw_a\ll1/(H\log Y)\)，把 (9b) 代入整数 Gram 的绝对误差为 \(O((\log Y)^{-3}+H^{1-A}(\log Y)^{-2})\)。再用 (9a) 替换 \(w_a\)，得到
\[
\begin{aligned}
\|P\|_\eta^2
&=H\sum_{a,b}w_aw_b\widehat\eta(a-b)+o((\log Y)^{-2})\\
&=\frac1{H(\log Y)^2}
\sum_{k\in\mathbb Z}\widehat\eta(k)
\sum_a\psi(a/H)\psi((a-k)/H)
+o((\log Y)^{-2})\\
&=\frac{\int_1^{11/10}\psi(x)^2dx}{(\log Y)^2}
\sum_{k\in\mathbb Z}\widehat\eta(k)
+o((\log Y)^{-2}).
\end{aligned}                                            \tag{9c}
\]
最后一步对每个固定 \(k\) 是 Riemann 和，再以 \(\widehat\eta\in\ell^1(\mathbb Z)\) 作控制收敛。Poisson 恒等式 \(\sum_k\widehat\eta(k)=\sum_n\eta(n)=C_\eta\) 证明 (4) 的能量主项。

证明 (3) 时令 \(L=\lfloor Y/(16H)\rfloor\)，把 \(b_n=(\log n/n)\psi(n/Y)\mathbf1_{n\text{ prime}}\) 和光滑密度 \(f_n=\psi(n/Y)/n\) 作为模 \(Y\) 的序列。note 851 式 (4) 的 Ramachandra 输入取长度 \(Y^{2/3}\) 后，对所有起点给 \(\Lambda-1\) 的 \(O(Y^{2/3}e^{-c_1V_Y})\) 短和。把任意长度 \(L\) 的窗口分成这些整段和至多两段余块，再对 \(\psi(n/Y)/n\) 作 Abel 求和。余块的平凡费用为 \(O(Y^{2/3}\log Y/Y)\)，全部高次素数幂的加权费用为 \(O(Y^{-1/2}\log Y)\)。由于 \(H\le Y^{1/4}\)，\(L\gg Y^{3/4}\)，缩小 \(c_1\) 后得到统一的
\[
\sup_{x\bmod Y}\left|\sum_{j=0}^{L-1}(b-f)_{x-j}\right|
\ll_\psi (L/Y)e^{-c_1V_Y}.                            \tag{10}
\]
在 \(\eta(h/H)\ne0\) 时 \(|h|\le4H\)，故长度 \(L\) 的几何和 \(\sum_{j<L}e(-hj/Y)\) 的模 \(\gg L\)。周期 Parseval 将 (10) 转成
\[
\sum_h\eta(h/H)|\widehat{b-f}(h)|^2
\ll_{\psi,\eta}e^{-2c_1V_Y}.                          \tag{11}
\]
\(f_n=Y^{-1}\varphi(n/Y)\)，\(\varphi(u)=\psi(u)/u\in C_c^3((1,2))\)，Poisson 求和及三次分部积分给其该频带能量 \(O_{\psi,\eta}(H^{-5})\)。由 \(H\ge Y^{1/5}\)，此项吸收进 (11)，得到 (3)（可再缩小 \(c\)）。于是 Cauchy--Schwarz 与 (2) 给
\[
|\langle P,B\rangle_\eta|
\le\|P\|_\eta\|B\|_\eta
=o(\|P\|_\eta^2).
\]
由 \(Q=B-P\) 得 (4) 第二式。

note 851 式 (1) 对同一 \(\psi,\eta,H\) 给完整 \(\|\mathcal A\|_\eta\ll e^{-c'V_Y}\)。结合 (3) 得 \(\|\mathcal A-B\|_\eta\ll e^{-c''V_Y}\)。由于 (4) 给 \(\|P\|_\eta\asymp1/\log Y\)，Cauchy--Schwarz 说明 \(\langle P,\mathcal A-B\rangle_\eta=o((\log Y)^{-2})\)。再把 \(\mathcal A-P=(B-P)+(\mathcal A-B)\) 分解，得到 (4a)。

最后证明块误差。对 \(d^P,d^Q\) 以及 \(d_m^{\rm all}=c(m)\psi(m/M)/(m/M)\) 均有 \(\sum_m|d_m|\ll_\psi M\)，且 Ramachandra 的同一 \(\Lambda\) 上界、\(|\mu|\le1\) 给任意长为 \(R\ge B_0\) 的局部区间 \(\sum_I|d_m|\ll R\)；这里 \(B_0\gg M^\vartheta\)，足以吸收短和的 \(M^\vartheta\) 余项。取 \(W=M/H\)。\(\psi\) 的支撑使所有非零配对的 \(|m-n|\le M/10\)，远离 \(K_H\) 的非零周期别名。Poisson 求和后逐项微分，对任意固定 \(A>2\) 给
\[
|K_H'(t)|\ll_{\eta,A}\frac{H^2}{M}(1+|t|/W)^{-A}
\quad (|t|\le M/5).                                  \tag{12}
\]
由于 \(B_0=o(W)\)，从 \(m-n\) 到 \(x_i-x_j\) 的线段仍在此范围。局部质量界及 dyadic 分壳给
\(\sup_m\sum_n|d_n^Q|(1+|m-n|/W)^{-A}\ll W\)。对每个配对用中值定理将 \(K_H(m-n)\) 换为 \(K_H(x_i-x_j)\)，其总费用至多
\[
\frac1{M^2}\frac{B_0H^2}{M}
\Bigl(\sum_m|d_m^P|\Bigr)O(W)
\ll\frac{HB_0}{M}.                                    \tag{13}
\]
原整数 Gram 按 Fourier 展开恰为 \(\langle P,Q\rangle_\eta\)。又 \(HB_0/M=o(H^4/M)\)，因为 \(B_0/H^3\ll M^{\rho-3/5}\to0\)。同时 (13) 是固定负幂，故它也小于 \(\|P\|_\eta^2\asymp(\log Y)^{-2}\)。式 (4) 遂推出 (6)--(7)。\(\square\)

完全相同的核替换估计适用于 \(d^P\) 与 \(d^{\rm all}-d^B\)、\(d^{\rm all}-d^P\) 的混合 Gram，因为上述绝对质量界对它们仍成立。原整数 Gram 分别是 (4a) 的两个内积；块化误差 \(O(HB_0/M)=o((\log Y)^{-2})\)，故得到 (7b)。

式 (7a) 直接由 note 845 式 (4) 验证：一致于观察窗，
\(G_N=Y[\pi H^2(\log Y)^2]^{-1}f(N/Y)\cos(2\pi HN/Y)
+o(Y/[H^2(\log Y)^2])\)。乘以 \(\chi(N/Y)e(-HN/Y)\) 后，余弦积给常数频率 \(1/2\) 与频率 \(2H\)；前者的整数 Riemann 和为 \(Y\int\chi f/2+o(Y)\)，后者由光滑权的几何和为 \(O(Y/H)\)。统一误差求和为 \(o(Y^2/[H^2(\log Y)^2])\)，乘式 (7a) 的系数即得结论。

证明 (7d)。固定 \(p\in\mathcal P\)，暂让 \(q\) 遍历全部 \(Y<q<2Y\) 的素数。Poisson 求和在 \(|H(p-q)/Y|<\delta\) 上给
\[
K_H^{\rm near}(2(p-q))
=H\widehat\eta(H(p-q)/Y)\tau(H(p-q)/Y)+O_A(H^{1-A}). \tag{14}
\]
核的非零周期别名与该短位移隔开至少 \((1-\delta)H\)；在 (14) 中取 \(A\ge6\)，其误差可吸收到下面的 \(H/Y\)。对 \(q\) 的加权素数和应用 note 851 式 (4) 的 \(\Lambda-1\) 全区间短和：其支持长 \(O(Y/H)\)，而权 \(q^{-1}\psi(q/Y)K_H^{\rm near}(2(p-q))\) 的上确界及总变差均为 \(O(H/Y)\)。一次 Abel 求和、素数幂总质量 \(O(\sqrt Y\log Y)\) 和普通整数求积于是给一致于 \(p\) 的误差
\[
O\!\left(e^{-cV_Y}+HY^{\vartheta-1}
+H\log Y/\sqrt Y+H/Y\right)=o(1),
\qquad 7/12<\vartheta<3/5.                          \tag{15}
\]
对整数密度积分取 \(v=H(p-q)/Y\)，并用 \(q/Y=p/Y-v/H\)，得到
\[
\sum_{Y<q<2Y\atop q\text{ prime}}
w_qK_H^{\rm near}(2(p-q))
=J_{\eta,\tau}\frac{\psi(p/Y)}{p/Y}+o(1).        \tag{16}
\]
把 (16) 乘 \(w_p\) 并对 \(p\in\mathcal P\) 求和，(9a) 与 Riemann 和给
\[
\sum_{p\in\mathcal P}\sum_{q\text{ prime}}
w_pw_qK_H^{\rm near}(2(p-q))
=\frac{J_{\eta,\tau}}{\log Y}
\int_1^{11/10}\frac{\psi(x)^2}{x}\,dx+o((\log Y)^{-1}). \tag{17}
\]
若 \(p\in I_a,q\in I_b\) 均被选中，\(a\ne b\) 给 \(|H(p-q)/Y|\ge1-o(1)>\delta\)，所以近差核为零。\(a=b\) 时该比值为 \(O(1/\log Y)\)，故 (9a) 给
\[
\sum_{p,q\in\mathcal P}w_pw_qK_H^{\rm near}(2(p-q))
=\frac{\widehat\eta(0)}{(\log Y)^2}
\int_1^{11/10}\psi(x)^2dx+o((\log Y)^{-2}).       \tag{18}
\]
从 (17) 扣除 (18) 得 (7d) 第一式。由 (4) 知完整 \(P\)--\(Q\) 交叉是 \(O((\log Y)^{-2})\)，所以远差等于完整交叉减去近差，得到 (7d) 第二式。\(\square\)

短块传递只需在 (12) 中把 \(K_H\) 换成 \(K_H^{\rm near}\) 或 \(K_H^{\rm far}\)。对前者求导产生 \(K_H'\tau(Ht/M)\) 和 \((H/M)K_H\tau'(Ht/M)\)，两者都满足 (12) 的同型衰减界；后者是原核减前者。因此 (13) 的 \(O(HB_0/M)\) 误差逐字适用。

## 决策边界

note 848 的 \(G_N\) 是原始 Poisson 项按分子、分母选出的子和；本稿的 \(P_h\) 是两端点展开后的偶素数系数掩码，两者之间没有逐项等同式。式 (7d) 将此掩码的 \(1/\log Y\) 级正近差与负远旁瓣都定位在同一真实素数通道。若要推进 note 849 式 (15)，下一承重项是减去这些平滑密度主项后，完整 \(\Lambda-1\) 与 \(\mu\) 短块之间达到 \(H^4/M\) 的二点估计；本稿的 \(o(\log^{-2}Y)\) 投影界尚不能支付它。
