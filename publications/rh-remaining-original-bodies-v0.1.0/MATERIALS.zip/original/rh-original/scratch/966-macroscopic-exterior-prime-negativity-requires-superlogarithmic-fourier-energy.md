# 槽外素数宏观负方向必有超对数 Fourier 能量

日期：2026-10-02。使用 [note 828](../notes/828-exterior-prime-hankel-centered-spectrum-has-linear-negative-tail.md) 的实际素数 Hankel 算子与槽集、[note 830](../notes/830-exterior-prime-rayleigh-has-unconditional-main-term.md) 式 (2a) 对任意固定多项式总变差的零自由区界，以及 [note 004](../notes/004-exact-logarithmic-laplacian-normalization.md) 的 Archimedean Fourier 归一化。本稿把 note 830 的 BV 类结论提升到所有对数 Fourier 能量受控的轮廓；证明尚待异源复核。它不证明完整 Weil 形式非负、全尺度局部 Weil 正性或 RH。

更强的近临界能量下界及强算子范数候选已写在 [槽外素数线性负方向草稿](exterior-prime-linear-negative-directions-require-logarithmic-fourier-energy.md) 式 (32)–(34)；本稿仅保留多项式 BV 截断路径。

## 命题

令 $p\to\infty$ 沿奇素数，$H=\log p$。沿用 note 828 的 $E_p\subset\mathbb R$、$R_p$、$K_p$，写 $V_p=E_p-2H$。对 $a\in L^2(E_p)$，把平移并在实线外延零的函数记为
\[
a_p(v)=a(2H+v)\mathbf1_{V_p}(v),\qquad
\widehat a_p(\xi)=\int_{\mathbb R}a_p(v)e^{-i\xi v}\,dv,
\]
并定义非负对数 Fourier 能量
\[
\mathcal L_p[a]=\frac1{2\pi}\int_{\mathbb R}
\log(2+|\xi|)|\widehat a_p(\xi)|^2\,d\xi.
\tag{1}
\]
对每个固定 $C>0$，无条件地有一致估计
\[
\boxed{\quad
\sup_{\substack{a\in L^2(E_p),\ \|a\|_2\le1\\
\mathcal L_p[a]\le C\log p}}
\bigl|(R_p-K_p)[a]\bigr|=o_C(p).
\quad}                                                        \tag{2}
\]
特别地，若某固定 $\varepsilon>0$ 下存在单位向量 $a_p$ 满足
\((R_p-K_p)[a_p]\le-\varepsilon p\)，则必有
\[
\boxed{\quad \mathcal L_p[a_p]/\log p\longrightarrow\infty.\quad}
\tag{3}
\]
note 828 的 $-\asymp p$ 本质谱因此只能由 Fourier 能量相对 $\log p$ 逃逸的轮廓逼近；这不限制其逃逸速度。对单位轮廓，式 (3) 中的 $\mathcal L_p$ 还可替换为 $\frac1{2\pi}\int\log|\xi|\,|\widehat a_p(\xi)|^2d\xi$，两者相差 $O(1)$，与 note 004 的对数 Laplacian 主乘子一致。

## 证明

第一步是一个与 $p$ 一致的算子范数界。note 828 式 (1) 中每个 $J_m$ 是压缩反射，故 $\|J_m\|\le1$；只有 $m\asymp p^2$ 的素数参与。Chebyshev 界 $\sum_{m\le Cp^2,\ m\ {m prime}}\log m\ll p^2$ 给
\[
\|R_p\|\le\sum_{m\ {m prime}}\frac{\log m}{\sqrt m}
\ll p.
\]
又 note 828 的 $\|K_p\|=k_p\asymp p$，因此存在绝对 $C_E$ 使
\[
\|R_p-K_p\|\le C_Ep.                              \tag{4}
\]

固定 $A>1$，令 $T=p^A$。在整条实线上对 $a_p$ 作正负频率对称的 Fourier 截断，
\[
g_T(v)=\frac1{2\pi}\int_{|\xi|\le T}
\widehat a_p(\xi)e^{i\xi v}\,d\xi,
\qquad b_T(v)=\mathbf1_{V_p}(v)g_T(v).
\tag{5}
\]
于是 $b_T$ 是 $L^2(V_p)$ 中的轮廓，$\|b_T\|_2\le\|g_T\|_2\le\|a_p\|_2\le1$。Plancherel 及 (1) 给
\[
\|a_p-b_T\|_2^2
\le\|a_p-g_T\|_2^2
=\frac1{2\pi}\int_{|\xi|>T}|\widehat a_p(\xi)|^2d\xi
\le\frac{\mathcal L_p[a]}{\log(2+T)}
\le\frac CA.
\tag{6}
\]
这一步无需 $a_p$ 原先有 BV 正则性。

由 Cauchy--Schwarz 与 Plancherel，
\[
\|g_T\|_\infty\ll T^{1/2}\|a_p\|_2,
\qquad
\|g'_T\|_\infty\ll T^{3/2}\|a_p\|_2.             \tag{7}
\]
note 830 式 (3) 给 $V_p$ 是 $O(p^2)$ 个两两不交区间之并，且 $|V_p|=O(1)$。将 $g_T$ 限制到各槽并把端点跳跃计入总变差，得到
\[
\operatorname{Var}_{\mathbb R}(b_T)
\ll |V_p|\|g'_T\|_\infty+p^2\|g_T\|_\infty
\ll T^{3/2}+p^2T^{1/2}.
\tag{8}
\]
因此对固定 $A$，可取另一个固定 $B>\max(3A/2,2+A/2)$，使充分大 $p$ 时 $\operatorname{Var}(b_T)\le p^B$。把 $b_T(v)$ 平移回 $E_p$ 后应用 note 830 式 (2a)。若 $a$ 复值，分别对 $\Re b_T$、$\Im b_T$ 应用；它们各自的范数至多 $1$、总变差至多 $p^B$，而 $R_p-K_p$ 是实核自伴算子，其复二次型是实部与虚部二次型之和。故对固定 $A$ 及相应 $B$，存在 $c_B>0$ 使
\[
|(R_p-K_p)[b_T]|
\ll_B p\exp[-c_B(H/\log H)^{1/3}]=o_A(p).
\tag{9}
\]

由 (4)、$\|a\|_2,\|b_T\|_2\le1$ 及 (6)，二次型的差至多
\[
\bigl|(R_p-K_p)[a]-(R_p-K_p)[b_T]\bigr|
\le2C_Ep\sqrt{C/A}.                                  \tag{10}
\]
给定任意 $\varepsilon>0$，先取固定 $A$ 使 (10) 右侧至多 $\varepsilon p/2$，再由 (9) 取充分大 $p$ 使其右侧至多 $\varepsilon p/2$。各界均对满足 (2) 约束的 $a$ 一致，证明 (2)。若 (3) 不成立，则有一个子列满足 $\mathcal L_p[a_p]\le C\log p$，与 (2) 及固定负值 $-\varepsilon p$ 矛盾。

最后比较两个 Fourier 权。$|V_p|=O(1)$ 与 $\|a\|_2\le1$ 给 $|\widehat a_p(\xi)|\le\|a_p\|_1\ll1$。在 $|\xi|<1$ 上，$\log(2+|\xi|)-\log|\xi|$ 的积分有限，故对两能量之差的贡献为 $O(1)$；在 $|\xi|\ge1$ 上该差有界，用 Plancherel 再给 $O(1)$。$\square$

## 判断边界

式 (2) 排除的是**对数 Fourier 能量有固定倍数上界时的线性负素数形式**；此前 note 830 的式 (2a) 只按 BV 多项式复杂度作此排除。完整 Weil 形式要求把仍可能为 $o(p)$ 的中心化素数误差压到 $O(\log p)$ 的实际 Archimedean 量级，式 (2) 尚无这一精度，不能据此宣称全尺度正性。
