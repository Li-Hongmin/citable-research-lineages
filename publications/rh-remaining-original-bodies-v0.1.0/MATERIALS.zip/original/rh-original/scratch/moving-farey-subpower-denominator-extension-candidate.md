# moving \(k=2\) Farey 低分母门的真实 Möbius 次幂推进（待异源复核）

> **量化更正（2026-09-30）：** 本稿把 note 835 所核对的 2023 短区间 Möbius 定理用于 \(e^{-c(\log Y/\log\log Y)^{1/3}}\) 率；该定理只给任意固定对数幂。因此式 (2)--(3) 与 \(Q_1=Y^{4/5}e^{\kappa U}\) 的次幂缩域结论撤回。可用的固定幂块族对数版本见 [更正候选](farey-fixed-power-operator-and-prime-frame-logarithmic-correction.md)，整条斜楔的对数版本见 [斜楔候选](sloping-farey-wedge-log-savings-candidate.md)。

依赖：[note 800](../notes/800-true-mobius-harmonic-collisions-pay-low-reduced-reciprocal-frequencies.md) 的一致互素调和界、[note 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 的精确 Poisson 系数、[note 802](../notes/802-moving-cutoff-log-zero-pays-low-farey-frequencies-in-full-k2-residual.md) 的移动大筛与完整余项缩域、[note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md) 的短区间卷积方法。本稿沿[块族算子抵消候选](farey-block-operator-cancellation-candidate.md)的块中心矩展开，允许分子 \(a\) 增长。下述推进是次幂范围的无条件候选上界，不是 RH 的证明。

令 \(Y\to\infty\) 沿正整数，\(H=\log(2Y)\)、\(U=(\log Y/\log\log Y)^{1/3}\)、\(Q_0=\lfloor Y^{4/5}\rfloor\)、\(A_0=\lceil Y^{1/3}\rceil\)。证明中先限制 \(0<\kappa\le1\)，以下指数节省常数不依赖 \(\kappa\)，最后再选定足够小的 \(\kappa\)。在 note 802 的精确 Fourier 分解中，对约分后的 \(h/d=a/q\)、\(d=kq<N\) 记对应项为 \(F_{a,q,N}\)，包括全部允许的 \(k\)；这是**未施加** note 831 物理端点裁剪的真实 moving 系数。令
\[
Q_1=\left\lfloor Y^{4/5}e^{\kappa U}\right\rfloor,
\qquad
\mathcal U_N^{>Q_1}
=\sum_{\substack{q>Q_1,\ 1\le a<A_0\\(a,q)=1}}F_{a,q,N}
\tag{1}
\]
（只计原始 \(d=kq<N\)）。

**候选定理。** 存在绝对 \(\kappa>0\)，使
\[
\boxed{\quad
\sum_{Y<N\le2Y}
\left|\sum_{Q_0<q\le Q_1}\sum_{\substack{1\le a<A_0\\(a,q)=1}}
F_{a,q,N}\right|^2\ll Y^2.
\quad}\tag{2}
\]
结合 note 802 式 (3)，于是完整 moving residual 满足
\[
\boxed{\quad
\sum_{Y<N\le2Y}|\mathcal R_{N,2}-\mathcal U_N^{>Q_1}|^2
\ll Y^2H^5.
\quad}\tag{3}
\]
因此 note 802 的真实算术门中，全部 \(q\le Q_1\) 的既约频率被无条件支付。推进量 \(Q_1/Q_0=e^{\kappa U+o(1)}\to\infty\)，但 \(Q_1=Y^{4/5+o(1)}\)；固定幂次高分母门仍开放。

## 1. 分子相关的加权短区间 Möbius 界

选 \(A_1=\lceil e^{2\kappa U}\rceil\)。对 \(a\le A_1\) 定义
\[
g_a(q)=\mu(q)\frac q{\varphi(q)}\mathbf1_{(a,q)=1},
\qquad
g_{a,o}(q)=g_a(q)\mathbf1_{2\nmid q},
\]
以及
\[
b_a(q)=
\begin{cases}
3g_a(q),&a\text{ 偶},\\
-g_a(q)-4g_{a,o}(q),&a\text{ 奇}.
\end{cases}
\tag{4}
\]
对充分大 \(Y\)，有 \(A_1<A_0\) 且 \(A_1<Q_0\)，所以这一小分子段自动满足 \(a<q\)。
note 800 式 (5) 的奇偶表说明：当 \((a,q)=1\) 时，\(b_a(q)=\lambda_{a,q}\mu(q)q/\varphi(q)\)，其 \(\lambda_{a,q}\) 分别为奇 \(q\)、偶 \(a\) 时 \(3\)，奇 \(q\)、奇 \(a\) 时 \(-5\)，偶 \(q\) 时 \(-1\)。

函数 \(g_a=\mu*h_a\)。若素数 \(p\mid a\)，则 \(h_a(p^j)=1\)；若 \(p\nmid a\)，则 \(h_a(p^j)=-1/(p-1)\)，对所有 \(j\ge1\) 成立。\(g_{a,o}\) 的卷积核还把 \(p=2\) 放入前一种情形。因此
\[
\sum_{d\ge1}\frac{|h_a(d)|+|h_{a,o}(d)|}{\sqrt d}
\ll \prod_{p\mid 2a}(1-p^{-1/2})^{-1}
\ll \exp(C\sqrt{\log(2a)})
=e^{o(U)}
\quad(a\le A_1),
\tag{5}
\]
其中最后一步只用 \(p_j\ge j+1\)、\(\omega(a)\ll\log a\)。

对 \(x\asymp Y^{4/5+o(1)}\)、\(x^{2/3}\le J\le x/2\)，按 note 835 式 (6) 的卷积和在 \(d_0=x^{1/10}\) 分割。\(d\le d_0\) 时
\[
\frac{J/d}{(x/d)^{5/8}}
\ge x^{2/3-5/8-(3/8)(1/10)}=x^{1/240},
\]
故 note 835 所引的逐区间 Möbius 界 (A) 以指数 \(5/8>7/12\) 一致应用；\(d>d_0\) 的绝对尾至多为
\(O(e^{C\sqrt{\log(2a)}}(Jx^{-1/20}+x^{1/2}))\)。由 (5) 吸收 \(e^{o(U)}\)，存在绝对 \(c_0>0\)，使
\[
\sum_{x<q\le x+J}b_a(q)
\ll J e^{-c_0 U}
\quad(a\le A_1,\ x^{2/3}\le J\le x/2),
\tag{6}
\]
误差对 \(a,x,J\) 一致。

## 2. 一个分子、一条二进制分母带

取 \(Q_0\le D\le2Q_1\) 的二进制带 \(D/2<q\le D\)，只保留 \(Q_0<q\le Q_1\)。固定 \(a\le A_1\)，令
\[
B_a=\left\lfloor\frac{D^2}{1000aY}\right\rfloor.
\]
因为 \(D\ge Q_0\)、\(a\le e^{2\kappa U}+1=Y^{o(1)}\)，有 \(B_a\gg D^{2/3+\delta}\)（可取任意固定 \(0<\delta<1/12\)），且 \(B_a=o(D)\)。把保留的 \(q\) 分成长度 \(B_a\) 的完整块 \(I_j=(t_j,t_j+B_a]\) 与至多两个不足一块的端块。由 (6) 及 \(|b_a(q)|\ll\log\log(3Y)\)，每个完整块满足
\[
\sup_{t_j\le z\le t_j+B_a}
\left|\sum_{t_j<q\le z}b_a(q)\right|
\ll B_ae^{-c_1U}
\tag{7}
\]
对某个绝对 \(c_1>0\) 一致于 \(a,D,j\)：短于 \(D^{2/3}\) 的前缀用平凡界，因 \(D^{2/3}\log\log Y/B_a\ll Y^{-1/15+o(1)}\)。

先取 note 801 系数的主项 \(C_{a,q}^{\rm lead}=qb_a(q)/a^2\)。对每块置
\(v_{j,q}=1/q-1/t_j\) 与
\(A_{j,m}=\sum_{q\in I_j}q b_a(q)v_{j,q}^m\)。对
\(\phi_m(x)=x(1/x-1/t_j)^m\) 直接求导，利用
\(|1/x-1/t_j|\le4B_a/D^2\)、\(x\asymp D\) 得
\(\sup_{I_j}|\phi_m|+\operatorname{Var}_{I_j}\phi_m
\ll(m+1)D(4B_a/D^2)^m\)。故 (7) 的分部求和给
\[
|A_{j,m}|\ll e^{-c_1U}B_aD(m+1)(4B_a/D^2)^m.
\tag{8}
\]
指数展开 \(e(aN/q)\) 时 \(aYB_a/D^2\le1/1000\)。块中心频率 \(a/t_j\pmod1\) 的间距至少 \(aB_a/D^2\asymp1/Y\)，所以 note 762 的初等大筛与 Minkowski 给完整块主项
\[
\left\|\frac1N\sum_j\sum_{q\in I_j}
\frac{qb_a(q)}{a^2}e(aN/q)\right\|_2^2
\ll e^{-c_2U}\frac{D^5}{a^5Y^2}
\tag{9}
\]
（吸收 \(\log Y\)，缩小 \(c_2>0\)）。更具体地，块数 \(M_a\ll D/B_a\)，初等大筛长度因子
\(Y+(D^2/(aB_a))\log(2M_a)\ll Y\log(2Y)\)。每个 \(m\) 的系数平方和至多
\(M_a e^{-2c_1U}B_a^2D^2a^{-4}(m+1)^2(4B_a/D^2)^{2m}\)；把 \((2\pi aN)^m/m!\) 用 \(N\le2Y\) 支付后，因 \(aYB_a/D^2\le1/1000\)，在 \(m\) 上的范数和收敛到绝对常数，留下
\(e^{-2c_1U}\log(2Y)B_aD^3/(Ya^4)\ll e^{-c_2U}D^5/(a^5Y^2)\)。余弦按正、负频率各用一次。

两个端块逐项取绝对值，使用 \(|b_a(q)|\ll\log\log Y\)，其能量至多
\[
\ll\frac{B_a^2D^2}{a^4Y}(\log\log Y)^2
\ll\frac{D^6}{a^6Y^3}(\log\log Y)^2.
\tag{10}
\]

## 3. 真正的移动同频系数

对 \((a,q)=1\)、\(q\le Q_1\)、\(a\le A_1\) 与实 \(Y\le t\le2Y\)，令 \(C_{a,q}(t)\) 为 note 801 式 (7) 的系数、截止 \(kq<t\)，并置
\(R_{a,q}(t)=C_{a,q}(t)-qb_a(q)/a^2\)。由 note 801 式 (6) 的两个有理乘子、note 800 式 (12) 对模数 \(q,2q\) 及共同截止 \(K=t/q\) 的一致界，
\[
|R_{a,q}(t)|\ll\frac q{a^2}\Delta_Y,
\qquad
|R'_{a,q}(t)|\ll\frac q{a^2Y}\Delta_Y\quad\text{a.e.},
\quad
\Delta_Y=e^{-c\omega(Y)}+(Q_1/Y)^2\log\log(3Y).
\tag{11}
\]
为核对 (11) 的符号，写
\(M_q(t)=\sum_{kq<t,(k,q)=1}\mu(k)k^{-1}\log(t/(kq))\)，
\(M_{2q}(t)=\sum_{kq<t,(k,2q)=1}\mu(k)k^{-1}\log(t/(kq))\)，
\(P_4(v)=4/(1-4v^2)\)、\(P_1(v)=1/(1-v^2)\)、\(v=q/(at)\)。精确地，\(C_{a,q}(t)\) 等于 \(\mu(q)q/a^2\) 乘以下列三式之一：偶 \(a\) 时 \((P_4-P_1)M_q\)；奇 \(a\)、奇 \(q\) 时 \(P_4(M_q-M_{2q})-P_1M_q\)；奇 \(a\)、偶 \(q\) 时 \(-P_1M_q\)。注意 \(M_{2q}\) 的截止仍为 \(k<t/q\)。

这里 \(t/q\ge Y^{1/6}\) 对充分大 \(Y\) 成立。note 800 给 \(M_q=q/\varphi(q)+O(e^{-c\omega(Y)})\) 与 \(M_{2q}=2q/\varphi(q)+O(e^{-c\omega(Y)})\)（后一项只在奇 \(q\) 情形使用），故上述三式在 \(v=0\) 的主乘子依次为 \(3,-5,-1\)，正是 (4)。新进入的 \(k\) 在 \(kq=t\) 处带零对数权，所以 \(R_{a,q}\) 绝对连续；几乎处处的 \(M_q',M_{2q}'\) 是对应互素调和部分和除以 \(t\)，而 \(P_4',P_1'=O(v^2/t)\)。这就给 (11) 的导数界。

固定 \(a\)，将 \(R_{a,q}(t)/(\pi t)\) 当作 note 802 式 (4) 的移动大筛权。因 \(a\le A_1=o(D)\)，各 \(a/q\) 均在靠近零的同一短弧，不发生圆周回绕；不同 \(q\asymp D\) 的 \(a/q\pmod1\) 相距至少 \(a/D^2\)。结合 (11)，该二进制带的真实系数误差满足
\[
\left\|\sum_{q\asymp D}\frac{R_{a,q}(N)}{\pi N}
\cos(2\pi aN/q)\right\|_2^2
\ll \left(Y+\frac{D^2}{a}\log(2D)\right)
\frac{D^3\Delta_Y^2}{a^4Y^2}
\ll e^{-c_3U}\frac{D^5}{a^5Y^2},
\tag{12}
\]
因为 \(D^2/a\gg Y\)，\(\Delta_Y\) 比 \(e^{-c_3U}\) 衰减更快；这里也分别处理余弦的两个指数。将 (9)--(12) 合并、对 \(1\le a<A_1\) 用 Minkowski 与 \(\sum a^{-5/2}<\infty\)、\(\sum a^{-3}<\infty\)，得到一条分母带的全部小分子贡献
\[
\|\mathcal F_{D}^{a<A_1}\|_2
\ll e^{-c_4U}\frac{D^{5/2}}Y
+\frac{D^3}{Y^{3/2}}\log\log Y.
\tag{13}
\]

## 4. 大分子与全部分母带

对 \(A_1\le a<A_0\)、\(Q_0<q\le Q_1\)，使用 note 802 式 (13)--(15) 的无符号移动系数证明，但把 \(q\)-和限制到 \(q\le Q_1\)。第零 Poisson 层的权平方和至多 \(O(H^4Q_1^3/A_1^3)\)，既约 Farey 频率间距至少 \(Q_1^{-2}\)，故
\[
\left\|\mathcal F^{a\ge A_1}_{Q_0<q\le Q_1}\right\|_2^2
\ll H^5\frac{Q_1^5}{Y^2A_1^3}.
\tag{14}
\]
这里频率数至多 \(Q_1^2\)，故 note 802 式 (4) 的大筛长度因子为
\(Y+Q_1^2\log(2Q_1)\ll Q_1^2H\)。第 \(m\ge1\) Poisson 层相对第零层有几何因子
\(O((16Q_1^2/(A_1^2Y^2))^m)\)，一致可求和；(14) 包含完整精确核和移动截止。此处没有使用 Möbius 符号。

从 \(Q_0\) 到 \(Q_1\) 至多有 \(O(1+\kappa U)\) 条二进制带。由 (13) 与 Minkowski，小分子的总能量至多
\[
\ll (1+U)^2\left(
e^{-c_4U}\frac{Q_1^5}{Y^2}
+\frac{Q_1^6}{Y^3}(\log\log Y)^2\right).
\tag{15}
\]
选固定 \(0<\kappa<c_4/10\)。则 (15) 第一项为
\(Y^2(1+U)^2e^{-(c_4-5\kappa)U}=O(Y^2)\)；第二项为
\(Y^{9/5+o(1)}=o(Y^2)\)。式 (14) 则为
\(\ll Y^2H^5e^{-\kappa U}=O(Y^2)\)，因为 \(A_1=e^{2\kappa U+o(1)}\)。这证明 (2)。最后 note 802 式 (3) 已支付 \(q\le Q_0\)、\(a\ge A_0\) 与高原始谐波，把 (2) 与它用三角不等式合并，得到 (3)。\(\square\)
