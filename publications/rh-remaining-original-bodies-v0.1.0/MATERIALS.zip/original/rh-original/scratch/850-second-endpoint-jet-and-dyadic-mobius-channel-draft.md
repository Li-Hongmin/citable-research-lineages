# 第二端点 jet 与额外的二倍尺度 Möbius 通道（待异源复核）

日期：2026-10-01。依赖 [note 753](../notes/753-high-divisor-k2-gate-is-the-k2-residual-up-to-negligible-low-layer.md) 的精确 residual 恒等式和 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的第一端点 jet。本稿是解析推导；Claude 只读复核在订阅预检阶段失败，尚未取得异源数学意见。这里不主张完整 signed covariance 界或 RH。

## 命题

令 $Y$ 为正整数，$\psi\in C_c^4((1,2))$，$e(x)=e^{2\pi i x}$，并沿用
$R_N=-\sum_{N<r<2N}[\Lambda(r)+\mu(r)\log(r/N)]\sin(2\pi r/N)$，
$S_h=\sum_{Y<N\le2Y}\psi(N/Y)R_Ne(-hN/Y)$。
置 $a_r=\Lambda(r)-1$、$b_r=\mu(r)$，并定义
\[
F_r(t)=\psi(t/Y)\mathbf1_{r/2<t<r}
\left[a_r+b_r\log(r/t)\right]\sin(2\pi r/t).
\tag{1}
\]
在两端取连续的零值。令 $J_{r,j}(s)=F_r^{(j)}(s+)-F_r^{(j)}(s-)$，
$s=r/2,r$，$j=1,2$。对 $1\le |h|\le Y/2$，完整 $k=2$ residual 的观察 Fourier 和满足
\[
\boxed{
S_h=-\sum_r\sum_{j=1}^2
\frac{J_{r,j}(r/2)e(-hr/(2Y))+J_{r,j}(r)e(-hr/Y)}
{(2\pi i h/Y)^{j+1}}
+O_\psi\left(\frac{Y^2}{|h|^4}+1\right).
}
\tag{2}
\]
其中只需对 $Y<r<4Y$ 求和。第一 jet 是 note 849 式 (1) 的两个显式和；第二 jet 的跳跃为
\[
\begin{aligned}
J_{r,2}(r/2)
&=-\frac{16\pi}{rY}\psi'(r/(2Y))[a_r+(\log2)b_r]
+\frac{32\pi}{r^2}\psi(r/(2Y))[a_r+(1+\log2)b_r],\\
J_{r,2}(r)
&=\frac{4\pi}{rY}\psi'(r/Y)a_r
-\frac{4\pi}{r^2}\psi(r/Y)[a_r+b_r].
\end{aligned}
\tag{3}
\]
若 $Y^{1/7}\le H\le Y/4$，把式 (2) 的主项记为 $T_{h,1}+T_{h,2}$，则
\[
\frac1Y\sum_{H\le |h|<2H}|S_h-T_{h,1}-T_{h,2}|^2
\ll_\psi \frac{Y^3}{H^7}+\frac HY
\ll_\psi Y^2.
\tag{4}
\]
故这一低频带若要达到 $Y^{2+\varepsilon}$ 的 residual 均方门，必须控制两个端点 jet 的联合算术平方和。

第二 jet 的上端点有一项
\[
\boxed{
T^{\mu,\mathrm{upper}}_{h,2}
=\frac{iY^3}{2\pi^2h^3}
\sum_{Y<r<2Y}\frac{\mu(r)}{r^2}
\psi(r/Y)e(-hr/Y)
=\frac{2iY^3}{\pi^2h^3}
\sum_{\substack{2Y<m<4Y\\2\mid m}}
\frac{\mu(m/2)}{m^2}
\psi(m/(2Y))e(-hm/(2Y)).
}
\tag{5}
\]
这在 note 849 的单格变量 $m$ 中引入 $\mu(m/2)$。例如 $m=4q$ 且 $q$ 为奇素数时，$\mu(m/2)=1$，而三通道系数 $c_{\rm tri}(m)$ 的 $p$、$2p$ 和 $\mu(m)$ 三项均为零。因此式 (29) 的三通道支撑并非第二 jet 的逐系数恒等式；是否能在目标平方量级支付新项，仍是算术问题。

## 证明

note 753 的精确恒等式及每个正整数 $N$ 的
$\sum_{N<r<2N}\sin(2\pi r/N)=0$ 给
\[
S_h=-\sum_r\sum_{n\in\mathbb Z}F_r(n)e(-hn/Y).
\tag{6}
\]
$\psi$ 的紧支撑使非零 $F_r$ 仅可能来自 $Y<r<4Y$，且在其支撑上 $r,t\asymp Y$。置 $A_r=|a_r|+|b_r|$。分片微分给
\[
|F_r^{(j)}(t)|\ll_\psi A_rY^{-j}\quad(0\le j\le4),\qquad
\operatorname{Var}(F_r')\ll_\psi A_r/Y,\quad
\operatorname{Var}(\mathbf1_{(r/2,r)}F_r^{(3)})\ll_\psi A_r/Y^3.
\tag{7}
\]
变差包含两端的导数跳跃；$F_r$ 本身连续且端点值为零。

用 $\widehat F_r(\xi)=\int F_r(t)e(-\xi t)dt$。连续分片 $C^2$ 函数的 Poisson 公式绝对收敛，故
\[
\sum_{n\in\mathbb Z}F_r(n)e(-hn/Y)
=\sum_{k\in\mathbb Z}\widehat F_r(h/Y+k).
\tag{8}
\]
由 $\operatorname{Var}(F_r')$，当 $|h|\le Y/2$ 时，
\[
\sum_{k\ne0}|\widehat F_r(h/Y+k)|
\ll_\psi \frac{A_r}{Y}
\sum_{k\ne0}|h/Y+k|^{-2}
\ll_\psi A_r/Y.
\tag{9}
\]
即使 $r/2$ 是整数，$F_r(r/2)=0$，所以采样端点没有半值或额外原子。Chebyshev 界及 $|b_r|\le1$ 给
$\sum_{r\le4Y}A_r\ll Y$；式 (9) 的总别名误差为 $O_\psi(1)$。

令 $\omega=2\pi h/Y$。对 (1) 的连续主支，按分布导数连续积分三次，保留 $F_r'$ 与 $F_r''$ 的端点跳跃：
\[
\widehat F_r(h/Y)
=\sum_{j=1}^2
\frac{J_{r,j}(r/2)e(-hr/(2Y))+J_{r,j}(r)e(-hr/Y)}
{(i\omega)^{j+1}}
+\frac{\widehat{\mathbf1_{(r/2,r)}F_r^{(3)}}(h/Y)}
{(i\omega)^3}.
\tag{10}
\]
式 (7) 对最后 Fourier 项再给一阶变差界，于是其绝对值
$\ll_\psi (A_r/Y^3)|\omega|^{-4}
\ll_\psi A_rY/|h|^4$。对 $r$ 求和后为 $O_\psi(Y^2/|h|^4)$；结合 (6)、(8)、(9) 得 (2)。

为核对 (3)，设 $x=t/r$，则 $d/dt=r^{-1}d/dx$。在 $x=1/2,1$，
$\sin(2\pi/x)=0$，其一阶 $x$ 导数分别为 $-8\pi,-2\pi$，二阶导数分别为 $32\pi,4\pi$；而
$d[a_r+b_r\log(1/x)]/dx=-b_r/x$。对 $\psi(rx/Y)[a_r+b_r\log(1/x)]\sin(2\pi/x)$ 作两次乘积求导，在 $x=1/2$ 取右侧值，在 $x=1$ 取左侧值的负数，即得 (3)。其中一阶跳跃是
\[
J_{r,1}(r/2)=-\frac{8\pi}{r}\psi(r/(2Y))[a_r+(\log2)b_r],
\qquad
J_{r,1}(r)=\frac{2\pi}{r}\psi(r/Y)a_r.
\tag{11}
\]
另用局部 Taylor 展开核对 $b_r$ 的系数：取 $a_r=0,b_r=1,\psi=1$，
在 $t=r-u$ 有 $F_r(t)=2\pi u^2/r^2+O(u^3/r^3)$；
在 $t=r/2+u$ 有
$F_r(t)=-8\pi(\log2)u/r+16\pi(1+\log2)u^2/r^2+O(u^3/r^3)$。
两式分别给 $J_{r,2}(r)=-4\pi/r^2$ 和
$J_{r,2}(r/2)=32\pi(1+\log2)/r^2$，与 (3) 相同。
式 (2) 中 $j=2$ 的上端点 $b_r$ 部分为
$-J_{r,2}^{\mu}(r)/(i\omega)^3$，代入 $J_{r,2}^{\mu}(r)=-4\pi b_r\psi(r/Y)/r^2$，再置 $m=2r$，得 (5)。

最后频带中整数 $h$ 的个数为 $O(H)$。将 (2) 的误差平方后除以 $Y$，得到 (4) 的第一界；$H^7\ge Y$ 给第二界。这里仍没有给出 $T_{h,1}+T_{h,2}$ 的目标上界。$\square$

## 边界

式 (5) 只证明多出一个真实系数序列，未证明其均方能量超标，也未证明其与原三通道缺少足够抵消。向 $H<Y^{1/5}$ 下降观察频率会增加待估的算术 jet；这不推进 note 849 的三通道 signed covariance 门本身。
