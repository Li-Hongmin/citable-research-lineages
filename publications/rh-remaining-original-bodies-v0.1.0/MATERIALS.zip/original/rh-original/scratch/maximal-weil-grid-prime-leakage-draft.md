# 最大整数 Weil 格的格外素数平移泄漏（待独立复核）

日期：2026-10-03。依赖 [note 871](../notes/871-unrestricted-microprofile-fourier-weil-grid-gap.md) 的最大宽整数格几何与 [note 004](../notes/004-exact-logarithmic-laplacian-normalization.md) 的素数平移归一化。下述结果只量化原始素数平移块，不估计完整 true-Schur 补，也不判定完整 Weil 形式的符号。

## 命题

固定 \(0<\theta<1\) 与非负实函数 \(\varphi\in C_c^\infty((-1/2,1/2))\)，\(\|\varphi\|_2=1\)。沿奇素数 \(p\to\infty\)，置
\[
H=\log p,\quad N=(p^2-3)/2,\quad L=\log N,\quad
L_N=\sum_{n\le N}n^{-1},\quad\ell=2\theta/p^2,
\quad y_n=H-\log(2n),\quad I_n=y_n+\ell(-1/2,1/2),
\quad U=\bigcup_{n\le N}I_n.
\]
在 \(I_n\) 上令
\[
f(y_n+\ell t)=\frac{\varphi(t)}{\sqrt{\ell nL_N}},
\qquad 1\le n\le N,
\]
并于其余位置置零，则 \(\|f\|_{L^2(-H,H)}=1\)，且 \(f\) 正是 note 871 中 \(P=1,r=0\) 的低块试函数。令素数平移算子按 note 004 定义为
\[
(\mathcal P_Hg)(x)=\sum_{k\le e^{2H}}\frac{\Lambda(k)}{\sqrt k}
\{g(x+\log k)+g(x-\log k)\},\qquad x\in(-H,H),
\]
函数在 \((-H,H)\) 外延为零。则
\[
\boxed{\quad
\liminf_{p\to\infty}\frac{1}{(\log N)^2}
\bigl\|\mathbf1_{(-H,H)\setminus U}\mathcal P_Hf\bigr\|_2^2
\ge\frac16.\quad}\tag{1}
\]
特别地，原始格外素数平移块作用于这一单位低块向量的范数至少为
\((1/\sqrt6-o(1))\log N\)。

## 证明

记 \(b_\ell(t)=\ell^{-1/2}\varphi(t/\ell)\)。固定素数 \(q\le N/2\) 和整数 \(q\le n\le N\)、\(q\nmid n\)。\(f\) 在 \(I_n\) 上的分量经 \(x\mapsto x-\log q\) 平移后，对 \(\mathcal P_Hf\) 的贡献是非负函数
\[
g_{q,n}(x)=\frac{\log q}{\sqrt{qnL_N}}
b_\ell(x-y_n-\log q),
\qquad \|g_{q,n}\|_2^2=\frac{(\log q)^2}{qnL_N}.
\tag{2}
\]
其中心 \(y_n+\log q=H-\log(2n/q)\) 位于 \((-H,H)\)，且距右端至少 \(\log2\)，距左端至少 \(\log q+o(1)\)，故充分大 \(p\) 时整个支撑都在 \((-H,H)\)。

该支撑与每个整数槽 \(I_m\) 不交。确实，中心距为 \(|\log(qm/n)|\)；因 \(q\nmid n\)，整数 \(qm\ne n\)，且 \(n\le N\)，所以
\[
|\log(qm/n)|\ge\log(1+1/N)>\ell
\tag{3}
\]
对充分大 \(p\) 成立。两槽同宽 \(\ell\)，式 (3) 恰保证不相交。

\(f\ge0\) 且全部 \(\Lambda(k)/\sqrt k\ge0\)，故 \(\mathcal P_Hf\ge0\)。在格外区域逐点保留 (2) 的非负分量，再把平方展开并舍弃所有非负交叉项，得到
\[
\bigl\|\mathbf1_{U^c}\mathcal P_Hf\bigr\|_2^2
\ge\frac1{L_N}
\sum_{\substack{q\le N/2\\q\ {m prime}}}
\frac{(\log q)^2}{q}
\sum_{\substack{q\le n\le N\\q\nmid n}}\frac1n.
\tag{4}
\]
这里 \(U^c\) 总在 \((-H,H)\) 内理解。逐素数的内和满足
\[
\sum_{\substack{q\le n\le N\\q\nmid n}}\frac1n
=\log(N/q)+O(1)+O\!\left(\frac{L}{q}\right),
\tag{5}
\]
因为被删去的倍数和恰为
\(q^{-1}\sum_{m\le N/q}m^{-1}\)。式 (5) 的两个误差代入 (4) 后分别为 \(O(L)\)、\(O(1)\)。素数定理与分部积分给
\[
\sum_{\substack{q\le N/2\\q\ {m prime}}}
\frac{(\log q)^2}{q}\log(N/q)
=\left(\frac16+o(1)\right)L^3,
\tag{6}
\]
其主积分为
\(\int_1^{N/2}(\log t)(L-\log t)\,dt/t=L^3/6+O(L^2)\)。由于 \(L_N=L+O(1)\)，(4)–(6) 推出 (1)。\(\square\)

## 边界

式 (1) 是 \(\mathcal P_H\) 的格外原始耦合范数下界。完整 Weil 形式还含无界的 Archimedean 对角与普通核、极点项，true-Schur 则需要格外块的逆或相应变分控制。因此本结果不能被直接解释为负 Weil 方向，也不能从 note 871 的格内正隙推出全尺度正性。
