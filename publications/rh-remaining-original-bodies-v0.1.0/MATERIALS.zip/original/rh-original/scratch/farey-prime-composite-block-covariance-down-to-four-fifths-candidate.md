# 真实 moving Farey 块的素数--合数负协方差延伸至四分之五以上

依赖：[note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md) 的短区间加权 Möbius 与素数计数、[note 833](../notes/833-prime-composite-covariance-within-a-moving-farey-denominator-block.md) 式 (1) 的真实物理裁剪系数、[note 800](../notes/800-true-mobius-harmonic-collisions-pay-low-reduced-reciprocal-frequencies.md) 式 (12) 的一致互素调和界、[note 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 式 (7) 的精确核及 [note 832](../notes/832-sloping-numerator-gate-for-moving-k2-farey-residual.md) 的斜楔。此稿把 note 835 的 \(\alpha>5/6\) 范围降至 \(\alpha>4/5\)；尚待独立复核，不晋级为正式定理。

固定 \(4/5<\alpha<1\)，令
\[
D=\lfloor Y^\alpha\rfloor,\qquad
B=\left\lfloor\frac{D^2}{1000Y}\right\rfloor,\qquad
L=\lfloor Y^{5/6}\rfloor.
\tag{1}
\]
对每个长度为 \(B\) 的整数块 \(I=(t,t+B]\subset(D/2,D]\)，令
\(F_{q,N}\) 为 note 833 式 (1) 的**真实、裁去 \(N-L<kq<N\)**
既约频率 \(1/q\) 项，并记
\[
G_{I,N}=\sum_{\substack{p\in I\\p\ {\rm prime}}}F_{p,N},
\quad
T_{I,N}=\sum_{q\in I}F_{q,N},
\quad
v_I=\#\{p\in I:p\ {\rm prime}\},
\quad E_I=\sum_{Y<N\le2Y}G_{I,N}^2.
\tag{2}
\]

**候选定理。** 当 \(Y\to\infty\) 时，以下各式对所有这样的 \(I\)
一致成立：
\[
v_I\sim\frac B{\log D},\qquad
\sup_{Y<N\le2Y}|T_{I,N}|
=o_\alpha\!\left(\frac{BD}{Y\log Y}\right),
\tag{3}
\]
\[
E_I\asymp_\alpha\frac{B^2D^2}{Y\log^2D}
\asymp_\alpha\frac{D^6}{Y^3\log^2Y},
\tag{4}
\]
\[
\sum_{Y<N\le2Y}G_{I,N}(T_{I,N}-G_{I,N})
=-(1+o_\alpha(1))E_I.
\tag{5}
\]
因此在 sign-blind 支付的尖锐端点 \(Y^{4/5}\) 以上，
**每个**固定幂长度的真实物理裁剪块都已有同量级素数--合数负协方差。
这些项全部属于 note 832 的剩余斜楔 \(\mathcal V_N\)；
(5) 没有估计不同块的合并均方。

## 1. 裁去多个原始倍数的统一端点界

先不裁剪，记 note 833 的完整同频系数为 \(C_q^{\rm full}(N)\)。
对 \(q\in I\) 有 \(q\asymp D=o(Y)\)，所以 note 833 式 (1) 中的
两个有理乘子一致为 \(O(1)\)。被裁去的每个 \(k\) 满足
\(N-L<kq<N\)，于是
\[
\frac1k\le\frac q{N-L}\ll\frac qY,
\qquad
0<\log\frac N{kq}\le\log\frac N{N-L}\ll\frac LY.
\]
这类整数 \(k\) 至多 \(L/q+1\) 个。因此不论 \(q\) 是否大于 \(L\)，
\[
\boxed{\quad
|C_q(N)-C_q^{\rm full}(N)|
\ll q\left(\frac Lq+1\right)\frac qY\frac LY
\ll \frac{qL^2+q^2L}{Y^2}.
\quad}
\tag{6}
\]
这里保留了新进入原始倍数的零对数权，没有引入端点原子。
note 835 所用的 \(O(q^2L/Y^2)\) 只在 \(q>L\) 时由“至多一个 \(k\)”
得到；式 (6) 对全部 \(q\asymp Y^\alpha\) 有效。除以主系数尺度 \(q\)
后，其代价为
\[
\frac{L^2+qL}{Y^2}
\ll Y^{-1/3}+Y^{\alpha-7/6}=o(1).
\tag{7}
\]

## 2. 四分之五以上的块前缀与素数计数

记 \(f_\kappa(q)=\mu(q)q\varphi(q)^{-1}
(1+4\mathbf1_{2\nmid q})\)。note 835 式 (5)--(8) 由
Motohashi--Ramachandra 的短区间 Möbius 界及绝对可和卷积推出：
对 \(x\asymp D\)、\(x^{3/4}\le H\le x/2\)，存在
\(c_\alpha>0\) 使
\[
\sum_{x<q\le x+H}f_\kappa(q)
\ll_\alpha H
\exp\!\left[-c_\alpha
\left(\frac{\log D}{\log\log D}\right)^{1/3}\right].
\tag{8}
\]
这里所用的 \(H\ge x^{3/4}\) 条件与 \(q>L\) 无关。
由 (1)，
\[
B=D^{\,2-1/\alpha+o(1)},\qquad
2-\frac1\alpha>\frac34
\quad\Longleftrightarrow\quad \alpha>\frac45.
\tag{9}
\]
对 \(t\le z\le t+B\)，若 \(z-t\ge D^{3/4}\)，(8) 给
\(O(B e^{-c_\alpha u(D)})\)，其中
\(u(D)=(\log D/\log\log D)^{1/3}\)；若更短，
\(|f_\kappa(q)|\ll\log\log(3D)\) 给
\(O(D^{3/4}\log\log D)\)。式 (9) 使二者均为
\(o_\alpha(B/\log D)\)。故
\[
\sup_{I}\sup_{t\le z\le t+B}
\left|\sum_{t<q\le z}f_\kappa(q)\right|
=o_\alpha(B/\log D).
\tag{10}
\]
同样，\(B\gg D^{3/4}\) 远大于 Heath-Brown 素数短区间定理所需
的 \(D^{7/12+\eta}\)。将其应用到每个 \(I\)，并支付
\(O(\sqrt D\log^2D)=o(B)\) 的素数幂权，得到
\(v_I\sim B/\log D\) 一致于 \(I\)。

## 3. 真实系数、总块抵消与负协方差

因为 \(K=N/q\asymp Y^{1-\alpha}\) 为固定幂，
note 800 式 (12) 对模数 \(q,2q\) 一致适用；
note 801 式 (7)--(9) 的精确 Poisson 系数和 note 833 的奇偶拆分给
\[
C_q^{\rm full}(N)
=-qf_\kappa(q)
+O_\alpha\!\left(
q e^{-c_\alpha\omega(Y)}
+q\log\log(3Y)(q/N)^2
\right),
\tag{11}
\]
其中 \(\omega(Y)=(\log Y)^{3/5}(\log\log Y)^{-1/5}\)。
与 (6) 合并，
\[
C_q(N)=-qf_\kappa(q)
+O_\alpha\!\left(
q e^{-c_\alpha\omega(Y)}
+q\log\log(3Y)(D/Y)^2
+\frac{qL^2+q^2L}{Y^2}
\right)
\tag{12}
\]
对 \(q\in I\)、\(Y<N\le2Y\) 一致。把这些误差逐 \(q\)
取绝对值，再除以 \(\pi N\)，相对于
\(BD/(Y\log Y)\) 的比至多
\[
O_\alpha\!\left(
\log Y\,e^{-c_\alpha\omega(Y)}
+\log Y\log\log Y(D/Y)^2
+\log Y\,\frac{L^2+DL}{Y^2}
\right)=o(1).
\tag{13}
\]

置 \(g_N(x)=x\cos(2\pi N/x)\)。在 \(I\) 上，
\[
\sup_I|g_N|+\operatorname{Var}_I g_N
\ll D+B(1+Y/D)\ll D,
\tag{14}
\]
因为 \(B\asymp D^2/Y\) 且 \(D\le Y\)。
对 \(\sum_{q\in I}f_\kappa(q)g_N(q)\) 用 (10) 分部求和，
再合并 (12)--(13)，得到式 (3) 的 \(T\) 点态式。

对奇素数 \(p\in I\)，
\(f_\kappa(p)=-5p/(p-1)\)，故由 (12)
\[
C_p(N)=5p+o_\alpha(p)
\tag{15}
\]
对 \(p,N,I\) 一致。取任意 \(q_0\in I\)，有
\[
\left|\frac Np-\frac N{q_0}\right|
\le\frac{2YB}{(D/2)^2}\le\frac8{1000}.
\tag{16}
\]
由于 \(q_0=o(Y)\)，满足
\(\|N/q_0\|_{\mathbb R/\mathbb Z}\le1/12\)
的 \(N\in(Y,2Y]\) 有 \(\gg Y\) 个。
在这些 \(N\) 上所有 \(\cos(2\pi N/p)\) 同号且有统一下界；
在全部 \(N\) 上又有显然上界。因此
\[
E_I\asymp_\alpha \frac{v_I^2D^2}{Y},
\]
与素数计数结合证明 (4)。式 (3)--(4) 给
\(\|T_I\|_2=o_\alpha(\|G_I\|_2)\)，于是
\[
\langle G_I,T_I-G_I\rangle
=-\|G_I\|_2^2+o_\alpha(\|G_I\|_2^2),
\]
即 (5)。

最后，\(\alpha>4/5\) 使 \(q>D/2>Y^{4/5}\)
对充分大的 \(Y\) 成立；note 832 式 (1) 对该 band 的
\(A_j\asymp Y^{(5\alpha-4)/3}\to\infty\)，故既约分子 \(1<A_j\)。
定义中又已取 \(kq\le N-L\)，所以全部项确实属于
\(\mathcal V_N\)。证毕。 \(\square\)

**边界。** 本结果是局部块内的无条件负协方差；
固定 \(\alpha>4/5\) 的跨块 \(\sum_I T_I\) 均方仍未达到
\(Y^{2+\varepsilon}\)。note 835 在 \(\alpha>5/6\) 的全部结论保留；
这里的新增内容是 \(4/5<\alpha\le5/6\) 的真实物理裁剪范围。

## 2026-09-30 内部核查

对式 (6)，被裁去的整数 \(k\) 至多 \(L/q+1\) 个；每项在 note 833
式 (1) 外层 \(q\)、调和因子 \(1/k\ll q/Y\) 和端点对数
\(\log(N/kq)\ll L/Y\) 下至多为 \(O(q^2L/Y^2)\)。相乘即得
\(O((qL^2+q^2L)/Y^2)\)，无需 \(q>L\)。

对式 (10)，note 835 式 (8) 施于 \(x=t\asymp D\) 与
\(H=z-t\ge D^{3/4}\)；不足该长度的前缀至多为
\(O(D^{3/4}\log\log D)\)。由
\(B/D^{3/4}=D^{5/4-1/\alpha+o(1)}\to\infty\)，
两项均为 \(o(B/\log D)\)。Matomäki--Teräväinen
*On the Möbius function in all short intervals*, arXiv:1911.09076v2，
§2.1 的原文式子确为
\(O(H\exp[-c(\log x/\log\log x)^{1/3}])\)，适用固定
\(\theta>7/12\)；本处沿用 note 835 的 \(\theta=5/8\) 卷积证明。

对式 (12)，note 801 式 (9) 在 \(a=1\)、\(v=q/N\) 时的奇、偶
乘子分别为
\(-4/(1-4v^2)-1/(1-v^2)=-5+O(v^2)\) 与
\(-1/(1-v^2)=-1+O(v^2)\)。乘以
\(\mu(q)q^2/\varphi(q)\) 并用 note 800 式 (12) 的
\(K=N/q\ge Y^{1-\alpha}\) 一致界，给出式 (11)；再加 (6) 即 (12)。
在 note 832 的 dyadic band 中 \(R_j\ge q/2\gg Y^\alpha\)，故
\(A_j\ge cY^{(5\alpha-4)/3}>1\)，且 \(q>Q\)、\(kq\le N-L\)。
因此式 (2) 的每项确在 \(\mathcal V_N\) 内。

以上是同源逐式核查，尚非项目要求的异源独立复核；此稿仍留在
`scratch/`。尤其式 (5) 不给不同块 \(T_I\) 的联合均方，
不能据此声称 moving-\(N\) 门或 RH 已闭合。
