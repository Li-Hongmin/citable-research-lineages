# 末带素数管的负补偿也发生在同一批素数的其他 Poisson 分子上

日期：2026-10-02。依赖 [note 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 式 (5) 的逐原始除数精确展开，以及 [note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 式 (1)–(15) 的真实末带素数管。这里证明与 note 845 的素数—合数补偿**并存**的另一条负补偿：在固定一批真实素数分母内，把全部 Poisson 分子加回以后，所选高频分子管几乎正交于原始除数和。以下解析证明尚待异源复核；它不估计完整 moving-$N$ 均方门。

## 定理

固定 $1/5\le\gamma<1/4$，$Y\to\infty$ 沿整数，$H=\lfloor Y^\gamma\rfloor$。沿用 note 845 的 $t_a=\lfloor aY/H\rfloor$、$B_a=\lfloor t_a^2/(aY\log Y)\rfloor$、$I_a=(t_a,t_a+B_a]$ 与精确物理 Poisson 项 $F_{a,p}(N)$，但只取
\[
\mathcal A^\star=\{a\in\mathbb Z:(13/12)H<a\le(11/10)H\},
\quad \mathcal P^\star=\bigcup_{a\in\mathcal A^\star}(I_a\cap\mathbb P),
\quad G_N^\star=\sum_{a\in\mathcal A^\star}
\sum_{p\in I_a\cap\mathbb P}F_{a,p}(N),
\quad P_N^\star=\sum_{p\in\mathcal P^\star}\mu(p)\Phi(p/N),
\quad T_N^\star=\sum_{a\in\mathcal A^\star}
\sum_{\substack{q\in I_a\\(a,q)=1}}F_{a,q}(N).\tag{1}
\]
其中 $\Phi$ 是 note 801 式 (1) 的原始余项核。令 $\chi\in C_c^\infty((3/2,8/5))$ 固定、非负、非零，内积 $\langle U,V\rangle_\chi=\sum_N\chi(N/Y)U_NV_N$。置
\[
\mathcal L_\star(z)=\int_{13/12}^{11/10}\log(z/x)\,dx,
\qquad
\kappa_{\star,\chi}=\frac1{2\pi^2}
\int_{3/2}^{8/5}\chi(z)\frac{\mathcal L_\star(z)^2}{z^2}\,dz>0.
\tag{2}
\]
则对每个固定整数 $K\ge3$，
\[
\|G^\star\|_\chi^2
=(\kappa_{\star,\chi}+o(1))
\frac{Y^3}{H^4(\log Y)^4},
\qquad
|\langle G^\star,P^\star\rangle_\chi|
\ll_{K,\gamma,\chi}
\frac{Y^3}{H^{K+2}(\log Y)^4}.
\tag{3}
\]
因此
\[
\boxed{\quad
\langle G^\star,P^\star-G^\star\rangle_\chi
=-(\kappa_{\star,\chi}+o(1))
\frac{Y^3}{H^4(\log Y)^4}.
\quad}\tag{4}
\]
同时，note 845 的完整短管估计在子集 $\mathcal A^\star$ 上仍一致成立，因而
\[
\langle G^\star,T^\star-G^\star\rangle_\chi
=-(\kappa_{\star,\chi}+o(1))
\frac{Y^3}{H^4(\log Y)^4}.
\tag{4a}
\]
由 note 801 式 (5)，$P_N^\star$ 是这些**原始素数除数** $p$ 的全部 Poisson 谐波之和；每个 $p$ 恰落在一个 $I_a$ 内，$G_N^\star$ 只选其一个高频谐波。把谐波 $h/p$ 约分后，$p\nmid h$ 的分母仍为 $p$，而 $p\mid h$ 的整数频率总量可忽略；式 (4) 在只保留前者时也成立。因此负补偿可以完全由同一批真实素数既约分母的其他分子提供，不要求合数分母。其量级因 $\gamma<1/4$ 而高于 $Y^{2+\varepsilon}$ 的某个固定幂。note 845 另证明了选定分子管内的真实素数—合数负协方差；两式属于不同的切分，不能相加成完整余项上界。

## 证明

**物理范围与正主项。** 对 $a\in\mathcal A^\star$，有 $a\asymp H$，$t_a=(a/H)Y+O(1)$，$B_a\asymp Y/(H\log Y)$。相邻中心满足 $t_{a+1}-t_a=Y/H+O(1)$，而 $B_a=o(Y/H)$，故 $I_a$ 两两不交。全部 $p\in\mathcal P^\star$ 满足
\[
(13/12+o(1))Y<p<(11/10+o(1))Y<3Y/2-L,
\quad L=\lfloor Y^{5/6}\rfloor,
\tag{5}
\]
且 $p>Y$，所以 note 845 式 (7) 的原始倍数只有 $k=1$。note 845 式 (8) 的短区间素数计数一致给
\[
\#(I_a\cap\mathbb P)=\frac{B_a}{\log Y}(1+o(1)),
\qquad
|\mathcal P^\star|\asymp\frac{Y}{(\log Y)^2}.
\tag{6}
\]
把 note 845 式 (9)–(11) 的分子范围改为 $\mathcal A^\star$，所有误差仍一致。其奇偶权 $c_a=4\mathbf1_{2\mid a}-1=1+2(-1)^a$ 的固定比例 Riemann 和给
\[
G_N^\star=
\frac{Y}{\pi H^2(\log Y)^2}
\frac{\mathcal L_\star(N/Y)}{N/Y}
\cos(2\pi HN/Y)
+o\!\left(\frac{Y}{H^2(\log Y)^2}\right)
\tag{7}
\]
一致于 $3Y/2<N\le8Y/5$。$\mathcal L_\star(z)>0$ 于该窗口，因为 $z>3/2>11/10$。对 (7) 平方、加 $\chi$ 并用余弦平方的几何和，得到 (3) 的第一式与 (2) 的严格正性。

**与同批原始素数除数正交。** 对上述 $p$ 和 $N/Y\in\operatorname{supp}\chi$，有 $p<N<2p$，且 $2N/p<3$：最后一个严格不等式由 $p/Y>13/12+o(1)$、$N/Y<8/5$ 给 $2N/p< (16/5)/(13/12)+o(1)=192/65+o(1)<3$。故 note 801 式 (1) 的活动整数只有 $m=2$，逐点精确为
\[
\Phi(p/N)=\log(p/N)\sin(4\pi p/N).
\tag{8}
\]
若 $z=N/Y$、$p/Y\in[13/12+o(1),11/10+o(1)]$，式 (8) 作为 $z$ 的函数在 $\operatorname{supp}\chi$ 上所有固定阶导数一致有界。

另一方面，note 845 式 (7) 与 $p>Y$ 给出精确式
\[
F_{a,p}(N)=a^{-2}A_{a,p}(N/Y)
\cos(2\pi aN/p),
\quad
A_{a,p}(z)=\frac{p}{\pi Yz}\log\frac{Yz}{p}
\left(\frac{4\mathbf1_{2\mid a}}{1-4(p/(aYz))^2}
-\frac1{1-(p/(aYz))^2}\right),
\tag{9}
\]
其中 $\mu(p)=-1$ 已计入正号。因 $a\asymp H$、$p\asymp Y$，$A_{a,p}$ 的任意固定阶 $z$ 导数也一致有界。于是对每个 $a,p,q$，
\[
g_{a,p,q}(z):=\chi(z)A_{a,p}(z)
\log\frac{q}{Yz}\sin\frac{4\pi q}{Yz}
\]
是统一 $C_c^K((3/2,8/5))$ 函数。因 $Ya/p\asymp H\to\infty$、$a/p=o(1)$，整数 Poisson 求和和 $K$ 次分部积分给
\[
\left|\sum_{N\in\mathbb Z}g_{a,p,q}(N/Y)
\cos(2\pi aN/p)\right|
\ll_{K,\chi}YH^{-K}.
\tag{10}
\]
具体说，零别名的 Fourier 变量大小为 $Ya/p\asymp H$，其余别名的大小至少为 $Y/2$；$\widehat g(\xi)\ll_K(1+|\xi|)^{-K}$ 且 $K\ge3$ 使别名和收敛。

将 (8)–(10) 代入 $\langle G^\star,P^\star\rangle_\chi$，对 $p,q\in\mathcal P^\star$ 与各自的 $a$ 取绝对值。由 $a\asymp H$、(6)，
\[
|\langle G^\star,P^\star\rangle_\chi|
\ll_{K,\chi} \frac{Y}{H^{K+2}}
|\mathcal P^\star|^2
\ll_{K,\gamma,\chi}
\frac{Y^3}{H^{K+2}(\log Y)^4},
\]
即 (3) 第二式。取 $K\ge3$ 后它是 $o(\|G^\star\|_\chi^2)$，展开内积即得 (4)。最后，note 801 式 (4) 的逐点 Fourier 恒等式只要求 $d<N$，即使该 note 后续均方定理限定 $D\le Y$，仍可在此对每个 $p>Y$ 单独使用，得到其式 (5) 的绝对收敛精确展开。又因 $p>Y$ 排除任何 $k\ge2$ 的原始倍数，(5) 的不交性说明每个 $p$ 在 $G^\star$ 中恰选一个 $a<p$。

严格按既约分母分类时，还需删去 $h=mp$ 的整数频率。式 (5) 对这些项的逐 $p,m$ 绝对大小为 $O((Np m^2)^{-1})$，故全部选中 $p$ 的该余项 $E_N$ 满足
\[
|E_N|\ll\frac{|\mathcal P^\star|}{Y^2}
\ll\frac1{Y(\log Y)^2}.
\]
由 (9)、(6) 有 $|G_N^\star|\ll Y/[H^2(\log Y)^2]$；于是
\[
|\langle G^\star,E\rangle_\chi|
\ll\frac{Y}{H^2(\log Y)^4}
=o\!\left(\frac{Y^3}{H^4(\log Y)^4}\right).
\]
因此把 $P^\star$ 换成仅含 $p\nmid h$、既约分母仍为 $p$ 的和，不改变 (4) 的主项。这证明所述同一素数既约分母内的负补偿。另一方面，note 845 式 (13)–(14) 对每个 $a$ 的上界及 $K(a)/a$ 平均在 $\mathcal A^\star\subset(H,11H/10]$ 上保持一致，故 $\sup_N|T_N^\star|\ll_A Y/[H^2(\log Y)^{A+1}]$。结合 (3) 第一式，$\langle G^\star,T^\star\rangle_\chi=o(\|G^\star\|_\chi^2)$，得到 (4a)。$\square$

## 边界

本定理不否定 note 845 的素数—合数负协方差：在固定分子管里按 $q$ 切分，合数项补偿素数项；在固定素数分母集合里按**全部分子**切分，其他分子也补偿所选管。两条是同一精确双指标和的不同切面。当前全尺度算术门仍需在所有分子与分母的联合和中控制平方范数；任何一条子块负协方差本身都不能提供该上界。

[scratch/939](939-same-prime-cancellation-localizes-to-a-vanishing-relative-numerator-window.md) 进一步把同素数补偿缩到邻近分子，并证明非素数原始除数的邻近分子产生对应的同阶正协方差，精确支付两种负补偿的重复计数；该稿仍待异源复核。
