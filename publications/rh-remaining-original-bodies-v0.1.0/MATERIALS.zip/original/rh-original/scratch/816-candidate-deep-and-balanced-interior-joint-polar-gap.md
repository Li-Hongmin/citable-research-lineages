# 候选：深内区和平衡内区同时加入 polar 外区

日期：2026-09-30。待独立复核。依赖 notes 809、810、811、813、814、815 和 806。沿这些 notes 的记号，令 \(P=p-1\)、\(H=\log p\)、\(Q=\lfloor P/H\rfloor\)，固定 \(r>2/(1-3/\pi^2)\)，写 \(\gamma_r=1-2/r-3/\pi^2>0\)。取任意 \(A_p\to\infty\)、\(A_p=o((\log H)^2)\)，令 \(T_p=\lceil Q/A_p\rceil\)。再固定
\[
\alpha>1+\gamma_r^{-1},\qquad S_p=\lfloor P/H^\alpha\rfloor.
\]
对充分大 \(p\)，有 \(2\le S_p<T_p\)。令
\[
D_p=I_{S_p}=\operatorname{span}\{\psi_{a/b}:b<a\le S_p,(a,b)=1\},
\quad B_p=I^{\rm bal}_{T_p,Q},
\quad E_p=E_r.
\]
则三块两两正交，且旧奇 Weil 主压缩保留全部真实算术交叉后满足
\[
P_{D_p\oplus B_p\oplus E_p}A_{p^2,-}P_{D_p\oplus B_p\oplus E_p}
\succeq(2-o_{r,\alpha,A_\bullet}(1))\log H\,I. \tag{1}
\]
与全部 Farey 阶跃偶极 \(W_p\) 联合后仍有
\[
P_{W_p\oplus D_p\oplus B_p\oplus E_p}A_{p^2,-}
P_{W_p\oplus D_p\oplus B_p\oplus E_p}
\succeq(c_0-o(1))I,
\quad c_0=1+\gamma_E-\log\pi+\delta_0>0. \tag{2}
\]
特别地，(1) 同时包含每个固定既约有理槽 \(a/b>1\)，包括 note 814 使内外全局交叉范数尖锐的 \(2/1\)，以及 note 815 的占全部内区槽数 \(1-o(1)\) 的平衡族。

## 证明

先证明 \(D_p\) 与 \(B_p\) 的算术矩阵块严格为零。设 \(x=a/b\in D_p\) 与 \(y=c/d\in B_p\)，则 \(a,b\le S_p<T_p\le c,d\)。若 \(y/x=\ell^k\) 是素数幂，约分 \(a\ell^k/b\) 后的分母整除 \(b\)，与 \(d>b\) 矛盾。若 \(x/y=\ell^k\)，则 \(y=a/(b\ell^k)\) 约分后的分子整除 \(a\)，与 \(c>a\) 矛盾。若 \(xy=\ell^k\)，则 \(y=b\ell^k/a\) 约分后的分母整除 \(a\)，与 \(d>a\) 矛盾。note 807 的 \(C^-=C_{\parallel}-C_{\times}\) 仅由这三类素数幂关系构成，故 \(C^-_{D_pB_p}=0\)。这也直接涵盖 note 803 中所谓跨指数零点边。note 809 的整个 \(I_Q\) 上有 \(\|N_{I_QI_Q}\|=O(H^{-1})\)、\(\|h_{I_Q}\|^2=O(H^{-1})\)。在三块联合空间上一次丢去正的异臂 Archimedean 矩阵后，剩余 \(D_p\)--\(B_p\) 交叉 \(X_{DB}\) 因而有
\[
\|X_{DB}\|=O(H^{-1}). \tag{3}
\]

note 813 式 (5) 在 \(D_p\) 给 \(g_D=2\alpha\log H-O(1)\)；note 809 式 (13) 在 \(B_p\subset I_Q\) 给 \(g_B=2\log H-O(1)\)；note 810 在 \(E_p\) 给 \(g_E=(\gamma_r-o_r(1))H\)。三者都是丢去同一个全局正矩阵后的下界。由 note 813 式 (7)--(10) 与 note 811 的非算术交叉界，剩余 \(D_p\)--\(E_p\) 交叉 \(X_{DE}\) 满足
\[
\|X_{DE}\|^2\le(2+o_r(1))H\log H. \tag{4}
\]
由 note 815 式 (8)--(9)，剩余 \(B_p\)--\(E_p\) 交叉 \(X_{BE}\) 满足
\[
\|X_{BE}\|^2\ll_r H\sqrt{A_p}+(\log H)^2+1=o(H\log H). \tag{5}
\]

对 \(x\in D_p,z\in B_p,y\in E_p\) 完成外区平方。令 \(d=\|X_{DE}\|\)、\(b=\|X_{BE}\|\)，所得 \(D_p\oplus B_p\) 下界的两个对角系数与交叉范数分别为
\[
g_D-d^2/g_E
\ge\bigl(2\alpha-2/\gamma_r-o(1)\bigr)\log H,
\quad
g_B-b^2/g_E=(2-o(1))\log H,
\quad
\|X_{DB}\|+db/g_E=o(\log H). \tag{6}
\]
这里最后一式由 \(db/g_E\ll_r\sqrt{\log H}\,A_p^{1/4}+o(1)=o(\log H)\) 得到。因 \(\alpha>1+1/\gamma_r\)，第一个对角系数比 \(2\log H\) 多固定正比例，第二个趋于 \(2\log H\)。二块标量比较遂给 \((2-o(1))\log H\) 的 Schur 余量。

外区完成平方所作的坐标变换为 \(y\mapsto y+g_E^{-1}(X_{ED}x+X_{EB}z)\)，它与恒等变换的算子范数距离至多 \((d+b)/g_E=o(1)\)。外区剩余对角为 \(g_E\asymp H\)，所以同样的 \((2-o(1))\log H\) 下界在原始三块正交范数中成立，证明 (1)。note 806 对全常值槽与 \(W_p\) 的混合范数为 \(O(1)\)，note 804 给 \(W_p\) 的 \((c_0-o(1))I\) 谱隙；用 (1) 完成平方，阶跃 Schur 损失为 \(O(1/\log H)=o(1)\)，证明 (2)。\(\square\)

## 边界

新加入的深内区并未填满 \(b<T_p\) 的中间小分母尾，且没有处理 \(a>Q,a/b\le r\)、非恒定槽轮廓和无限维补空间。因此 (1)--(2) 不推出全尺度局部 Weil 正性或 RH，也不解决 moving-\(N\) Möbius signed covariance。
