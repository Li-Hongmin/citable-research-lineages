# 候选：渐近全部上分子内区与 polar 外区具有线性联合谱隙

日期：2026-09-30。待独立复核。沿 notes 803、806、807、809--811、813 的记号，令奇素数 \(p\to\infty\)，\(P=p-1\)、\(H=\log p\)、\(Q=\lfloor P/H\rfloor\)。固定 \(1<\beta<3\) 和 \(r>2/(1-3/\pi^2)\)，令 \(\gamma_r=1-2/r-3/\pi^2>0\)、\(R=\lfloor P/H^\beta\rfloor\)，并定义全部斜率的上分子内区常值奇槽
\[
T_{R,Q}=\operatorname{span}\{\psi_{a/b}:R<a\le Q,\ 1\le b<a,\ (a,b)=1\}.
\tag{1}
\]
令 \(E_r=\operatorname{span}\{\psi_{c/d}:c>Q,\ c/d>r\}\)。则
\[
\boxed{\quad P_{T_{R,Q}}A_{p^2,-}P_{T_{R,Q}}\succeq(H-o_\beta(H))I,\quad
P_{T_{R,Q}\oplus E_r}A_{p^2,-}P_{T_{R,Q}\oplus E_r}
\succeq(\gamma_r-o_{r,\beta}(1))H I.\quad}\tag{2}
\]
进一步，全部 Farey 阶跃偶极 \(W_p\) 加入后仍有
\[
P_{W_p\oplus T_{R,Q}\oplus E_r}A_{p^2,-}P_{W_p\oplus T_{R,Q}\oplus E_r}
\succeq(c_0-o(1))I,
\qquad c_0=1+\gamma_E-\log\pi+\delta_0>0.
\tag{3}
\]
而且 \(\dim T_{R,Q}/\dim I_Q\to1\)。特别地，\(\beta=2\) 时 (2) 联合覆盖全部 \(P/H^2<a\le Q\) 的内区常值槽，**没有任何分母下限**，包括 note 817 的临界跨块向量。

## 上分子带的算术内部谱界

取整数坐标区间 \(L=\{1,\ldots,R\}\)、\(U=\{R+1,\ldots,Q\}\)。note 803 的有序互素对反对称等距嵌入 \(J_-\) 将 (1) 的坐标支撑送入
\[
\Omega_T=(U\times L)\sqcup(L\times U)\sqcup\bigl((U\times U)\cap\{a\ne b\}\bigr).
\tag{4}
\]
将 note 803 式 (5)--(6) 的非负算术有序图压到 \(\Omega_T\)，其单坐标部分由 \(K_Q\otimes I+I\otimes K_Q\) 支配，跨指数零点余项的全图范数为 \(O(\log H)\)。记一维块
\(\alpha_0=\|K_{UU}\|\)、\(\beta_0=\|K_{LL}\|\)、\(\kappa=\|K_{UL}\|\)。note 803 式 (10) 的同一个三块标量矩阵给
\[
\|C^-_{TT}\|
\le\max(\alpha_0+\beta_0,2\alpha_0)+\sqrt2\kappa+O(\log H).
\tag{5}
\]

因 \(u,u'\in U\) 的整数素数幂比值至多 \(Q/R\)，用
\(\sum_{n\le z}\Lambda(n)/\sqrt n\ll\sqrt z\) 的普通行和界，得到
\[
\alpha_0\le2\sum_{n\le Q/R}\frac{\Lambda(n)}{\sqrt n}
\ll\sqrt{Q/R}=O_\beta(H^{(\beta-1)/2})=o(H).
\tag{6}
\]
在 \(L\) 上取权 \(v_m=m^{-1/2}\)。note 803 式 (8) 以 \(R\) 代替 \(Q\) 给
\[
\beta_0\le\log R+O(1)=H-\beta\log H+O(1).
\tag{7}
\]
对矩形 \(U\times L\)，同一加权 Schur 检验的输出行权和至多 \(\log Q\le H\)，输入列权和至多
\(M(Q/m)-M(R/m)\le\log(Q/R)+O(1)=(\beta-1)\log H+O(1)\)。故
\[
\kappa^2\le H\bigl((\beta-1)\log H+O(1)\bigr),
\qquad\kappa=O_\beta(\sqrt{H\log H})=o(H).
\tag{8}
\]
把 (6)--(8) 代入 (5)，得到 \(\|C^-_{TT}\|\le H+o_\beta(H)\)。note 807 的常值槽精确分解中对角为 \(2H+O(1)\)，正的异臂 Archimedean 矩阵在整个联合空间上丢去；note 809 在 \(I_Q\) 上给 \(\|N\|=O(H^{-1})\)、\(\|h\|^2=O(H^{-1})\)。因 \(T_{R,Q}\subset I_Q\)，这些界推出 (2) 的第一式。

## 真实外区交叉、阶跃与维数

note 810 给 \(P_{E_r}A_{p^2,-}P_{E_r}\succeq(\gamma_r-o_r(1))H I\)，同样已丢去正的异臂 Archimedean 矩阵。note 813 式 (7)--(10) 的跨块算术上界对任何 \(I_S\subset I_Q\) 一致；取 \(S=Q\) 得
\[
\|C^-_{E_r,T_{R,Q}}\|
\le\|C^-_{E_r,I_Q}\|
\le(\sqrt2+o(1))\sqrt{H\log H}=o(H).
\tag{9}
\]
note 811 式 (7)、(11) 给同臂非算术核的此跨块范数 \(O_r(1)\)；note 809 的 \(\|h_{I_Q}\|^2=O(H^{-1})\) 与 note 810 的 \(\|h_{E_r}\|^2=O(H)\) 给 polar 跨块 \(O_r(1)\)。因此全局丢去正矩阵后的真实跨块范数仍为 \(O_r(\sqrt{H\log H})=o(H)\)。在 \(T_{R,Q}\oplus E_r\) 的两个对角下界中，\(H-o(H)>\gamma_rH-o(H)\)，且交叉为 \(o(H)\)；标量二块比较给 (2) 第二式。

note 806 对全部常值槽与 \(W_p\) 的混合范数为 \(O(1)\)，note 804 给 \(W_p\) 谱隙 \((c_0-o(1))I\)。由 (2) 的线性增长谱隙，阶跃 Schur 损失为 \(O(H^{-1})\)，证明 (3)。最后 \(I_Q=I_R\oplus T_{R,Q}\)，且 note 809 的互素格点计数给 \(\dim I_S\asymp S^2\)（\(S=R,Q\)）；因为 \(R/Q\asymp H^{1-\beta}\to0\)，得到 \(\dim T_{R,Q}/\dim I_Q\to1\)。\(\square\)

## 边界

尚未与 (2) 合并的内区为全部 \(a\le R\) 的深区；当 \(\beta=2,r=12\) 时 note 813 已分别证明它与 \(E_r\) 的联合正性，但深区和上分子带之间的真实算术交叉仍未支付。外区 \(a>Q,a/b\le r\)、非恒定槽轮廓、无限维补空间及 moving-\(N\) Möbius signed covariance 仍未解决，故 (2)--(3) 不推出 RH。
