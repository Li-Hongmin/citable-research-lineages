# 外槽 forcing 的二维负方向需要对数级正素数近共振（候选）

日期：2026-09-29。承接 [scratch 808](808-interior-farey-dipoles-have-a-sharp-growing-spectral-gap-candidate.md) 的内部正权能量、[scratch 818](818-polynomial-exterior-farey-compression-is-a-signed-near-resonance-matrix-candidate.md) 的目标压缩、[scratch 819](819-exterior-farey-forcing-has-an-exact-prime-divisor-norm-asymptotic-candidate.md) 的 forcing 范数，以及 [scratch 824](824-opposite-prime-power-quadratic-cost-vanishes-through-quarter-candidate.md) 的高次素数幂支付。本结果只判断一个明确的二维试探平面，尚缺异源复核，留在 scratch。

## 命题

令奇素数 \(p\to\infty\)、\(H=\log p\)，固定
\[
0<\alpha<1,
\qquad 0<\beta<\min\left\{\alpha,1-\alpha,\frac13\right\},
\quad Q=\lfloor p^\alpha\rfloor,
\quad B=\lfloor p^\beta\rfloor.
\tag{1}
\]
令 \(v=v_{p,\alpha}\) 为 808--819 的内部 Farey 正权向量，\(t^{\rm pr}\) 为 819 的外槽素数 forcing，视作真实旧奇空间中的向量 \(w=\sum_{y\in\mathcal Y_{p,B}}t^{\rm pr}_y w_y\)。记
\[
J=J_{\rm diag}(\alpha,\beta)+J_{\rm pair}(\alpha,\beta),
\qquad
g=2-\alpha-3\beta,
\qquad
\rho=\frac{J}{\alpha^2(1-\alpha)}.
\tag{2}
\]
则 \(J>0\)。若真实旧奇形式 \(A_{p^2,-}\) 在二维平面 \(\operatorname{span}\{v,w\}\) 上对无穷多个 \(p\) 出现负方向，则这些 \(p\) 必满足
\[
\boxed{\quad
\frac{\langle t^{\rm pr},N^{\rm opp,pr}_{p,B}t^{\rm pr}\rangle}
{H\|t^{\rm pr}\|^2}
\ge g-\rho-o(1).
\quad}
\tag{3}
\]
特别对 819 的完整泄漏参数 \((\alpha,\beta)=(2/3,1/4)\)，
\[
g=\frac7{12},\qquad \rho=\frac{921}{8192},\qquad
\boxed{\quad g-\rho=\frac{11573}{24576}>0.\quad}
\tag{3a}
\]
在 (1) 的**整个参数域**内还有统一的严格界
\[
\boxed{\quad g-\rho>\frac1{18}.\quad}
\tag{3b}
\]
故该二维平面的负方向要求素数近共振具有明确的正 \(H\|t^{\rm pr}\|^2\) 主项。若对充分大的 \(p\) 式 (3) 左端总小于 \(g-\rho\) 一个固定裕量，则这个**指定二维平面**最终严格正。式 (3) 是负方向的必要条件，不声称其发生，也不约束平面外的 Schur 反馈。

## 同臂矩阵在 forcing 支撑上的正权界

令 \(\mathcal S=\{m/b\in\mathcal Y_{p,B}:F_Q(m)>0\}\)。对每个 \(y=m/b\in\mathcal S\)，选一个 \(r\mid m\) 使 \(r\) 为素数且 \(a=m/r<Q\)。819 的条件给 \(r>p/Q>B\)。置 \(h_{m/b}=(mb)^{-1/2}\)。任一同臂素数幂边把 \(y\) 送到 \(ny\) 或 \(y/n\)；因全部目标在 \([p/B,p)\)，必有 \(n<B\)。在前一方向约分后，\(h_{ny}/h_y=(n,b)/\sqrt n\)；后一方向为 \((n,m)/\sqrt n=(n,a)/\sqrt n\)，最后一步用 \(n< B<r\)。因此 818 的非负同臂矩阵 \(C^{\rm same}\) 在 \(\mathcal S\) 上满足
\[
\frac{(C^{\rm same}_{\mathcal S}h)_y}{h_y}
\le S_B(b)+S_B(a),
\qquad
S_B(z)=\sum_{\substack{n\le B\\n\ {m prime\ power}}}
\frac{\Lambda(n)(n,z)}n.
\tag{4}
\]
若 \(\ell^v\Vert z\)，则 \(\ell^j\) 中 \(j\le v\) 的总贡献至多 \(v\log\ell\)；\(j>v\) 的贡献由 \(\sum_{n\le B}\Lambda(n)/n\) 支付。故经典 Mertens 素数和给
\[
S_B(z)\le\log z+\sum_{n\le B}\frac{\Lambda(n)}n
=\log z+\log B+O(1).
\tag{5}
\]
因 \(a<Q\)、\(b\le B\)，正权 Schur 行列检验推出
\[
\boxed{\quad
\|C^{\rm same}_{\mathcal S}\|_{\rm op}
\le(\alpha+3\beta)H+O(1).
\quad}
\tag{6}
\]
这里 \(C^{\rm same}_{\mathcal S}\) 是在 \(\mathcal S\) 上的主矩阵，不把 (6) 延伸到全部外槽或无限维补空间。

## 二维能量与阈值

808 的内部 Rayleigh 渐近及其范数给
\[
\langle v,A_{p^2,-}v\rangle
=\left(\frac{\alpha^2(1-\alpha)}{\zeta(2)}+o(1)\right)H^3.
\tag{7}
\]
819 给 \(\|t^{\rm pr}\|^2=(J/\zeta(2)+o(1))H^4\)，并由真实交叉 forcing 公式给
\[
\langle v,A_{p^2,-}w\rangle
=-\|t^{\rm pr}\|^2+o(H^4).
\tag{8}
\]
为核对误差，实际交叉列是 \(-t\) 加 \(o(1)\) 范数的非算术项；819 的 \(\|t-t^{\rm pr}\|=o(1)\)，而 \(\|t^{\rm pr}\|=O(H^2)\)。

818 的目标压缩对角为 \(2H+O(1)\)，非算术余项算子范数为 \(o(1)\)。824 式 (2) 支付 \(w\) 上的全部高次素数幂平移。由 (6)，
\[
\langle w,A_{p^2,-}w\rangle
\ge\bigl(g+o(1)\bigr)H\|t^{\rm pr}\|^2
-\langle t^{\rm pr},N^{\rm opp,pr}_{p,B}t^{\rm pr}\rangle.
\tag{9}
\]
若二维平面有负方向，则其 \(2\times2\) Gram 行列式为负，或目标对角本身为负。两种情形都给
\[
\langle w,A_{p^2,-}w\rangle
<\frac{|\langle v,A_{p^2,-}w\rangle|^2}
{\langle v,A_{p^2,-}v\rangle}
=\bigl(\rho+o(1)\bigr)H\|t^{\rm pr}\|^2.
\tag{10}
\]
将 (9)--(10) 合并即得 (3)。

为证明 (3b)，由 (2) 及 819 的积分，
\[
J_{\rm diag}=\alpha\beta^2\left(\frac12-\frac\alpha4+\frac\beta6\right),
\qquad
J_{\rm pair}\le\frac{(2\alpha-1)_+^2\beta^2}{4}
\le\frac{\alpha^2\beta^2}{4}.
\]
末个不等式在 \(\alpha\le1/2\) 时平凡，在 \(\alpha>1/2\) 时由
\(2\alpha-1\le\alpha\) 得到。因此
\[
J\le\alpha\beta^2\left(\frac12+\frac\beta6\right).
\]
又因 \(\beta<\alpha<1-\beta\) 与 \(\beta<1/3\)，凹函数
\(x(1-x)\) 给
\(\alpha(1-\alpha)>\beta(1-\beta)\)。于是
\[
\rho<\left(\frac12+\frac\beta6\right)
\frac\beta{1-\beta}<\frac5{18},
\qquad
g=2-\alpha-3\beta>1-2\beta>\frac13.
\]
两式相减即得 \(g-\rho>1/18\)。

最后核对较薄的子范围 \(\beta<(1-\alpha)/4\) 的强阈值。此时 \(\alpha+4\beta<1\)，故 \(g>1+\beta\)；同时 \(\beta<1/5\)。由 819 的积分，
\[
J_{\rm diag}\le\alpha\beta^2\left(\frac12+\frac\beta6\right),
\qquad
J_{\rm pair}\le\frac{(2\alpha-1)_+^2\beta^2}{4}
\le\frac{\alpha\beta^2}{4}.
\]
所以 \(J\le(47/60)\alpha\beta^2<\alpha\beta^2\)。再由
\(\beta<\alpha\)、\(4\beta<1-\alpha\) 得
\(\beta^2<\alpha(1-\alpha)/4\)，遂有
\(0<\rho<1/4\)。还可用同一参数域的尖锐初等比较
\(\alpha(1-\alpha)>(4/5)\beta\)：当 \(\alpha\le1/5\) 时由 \(\beta<\alpha\) 得到；当 \(\alpha\ge1/5\) 时由 \(\beta<(1-\alpha)/4\) 得到。因此
\(\rho<(47/60)\beta^2/[\alpha(1-\alpha)]<(47/48)\beta\)，再和 \(g>1+\beta\) 合并得到
\(g-\rho>1+\beta/48\)。在 (3a) 中，819 的
\(J=307/18432\) 与 \(\alpha^2(1-\alpha)=4/27\) 直接给
\(\rho=921/8192\)，而 \(g=2-2/3-3/4=7/12\)。\(\square\)

## 边界

式 (3b) 将这个路线判断扩展至全部 \(\beta<\min\{\alpha,1-\alpha,1/3\}\)：指定二维平面的负方向一律要求正的 \(\Omega(H^5)\) 素数近共振。对 \((2/3,1/4)\) 的完整泄漏实例，归一化阈值至少为 \(11573/24576\)；在较薄子范围 \(\beta<(1-\alpha)/4\)，阈值严格超过 \(1+\beta/48\)。因此只证明素数近共振二次型为 \(o(H^5)\) 不足以让这个二维平面变负。这些结论不排除其他向量、整个旧奇算子的负谱，亦不证明全尺度 Weil 正性、moving-\(N\) Möbius signed covariance 或 RH。
