# Farey 图的边界负行势在 \(x<\sqrt2\) 压缩内由边能量支付（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确算术图与有界 Archimedean 修正，以及 [scratch 838](838-canonical-farey-perron-profile-has-a-positive-constant-rayleigh-limit-candidate.md) 的正权轮廓。以下是指定有限压缩的精确结构；尚待异源复核，留在 scratch。

## 精确加权图恒等式

沿 note 791 取 \(k=p^2\)、\(L=\log k\)、\(v_x=(ab)^{-1/2}>0\)（\(x=a/b\in\mathcal F_p\)），并令 \(r_x=(C_pv)_x/v_x\)。对任意有限坐标向量 \(f_x=v_xF_x\)，对称性逐项给
\[
\boxed{\quad
\langle f,(D_kI-C_p)f\rangle
=\sum_x(D_k-r_x)|f_x|^2
+\frac12\sum_{x,y}C_p(x,y)v_xv_y|F_x-F_y|^2.
\quad}
\tag{1}
\]
对角自环在末和自动为零，已包含在 \(r_x\) 内。记 \(\mathfrak M(t)=\sum_{n\le t}\Lambda(n)/n\)、\(E(t)=\mathfrak M(t)-\log t\)。由 note 791 式 (14) 与 \(D_k=L+1-\gamma_E-\log\pi\)，行势精确为
\[
\boxed{\quad
D_k-r_{a/b}
=1-\gamma_E-\log\pi
+2\log\frac p{p-1}
-E\!\left(\frac{p-1}{a}\right)
-E\!\left(\frac{p-1}{b}\right)
+\Lambda(a)\mathbf1_{b=1}.
\quad}
\tag{2}
\]
这里 \(C_p(x,y)\ge0\)，故 (1) 的边能量非负，但 (2) 的行势并不逐点为正。

## 负行势与正压缩同时存在

取 \(a=p-2,b=p-3\)，则 \((a,b)=1\)、\(x=a/b>1\)，且对充分大的奇素数 \(p\)，\((p-1)/a<2\)、\((p-1)/b<2\)。此时 \(\mathfrak M((p-1)/a)=\mathfrak M((p-1)/b)=0\)，\(b>1\)，故由 note 791 式 (14) 直接得到
\[
r_x=\log(p-2)+\log(p-3)=L+o(1),
\qquad D_k-r_x\longrightarrow1-\gamma_E-\log\pi<0.
\tag{3}
\]
最后一个常数严格负，例如 \(\gamma_E>1/2\)、\(\log\pi>1/2\)。因此仅以 \(v\) 作逐行正 supersolution 的判据失败，即使 scratch 838 的 \(v\) 整体 Rayleigh 商为正。

另一方面，令
\[
B_p=\operatorname{span}\{w_x:x\in\mathcal F_p,\ 1<x<\sqrt2\}.
\]
对 \(x,y\in(1,\sqrt2)\)，三个可能的算术参数 \(x/y,y/x,xy\) 都严格小于 \(2\)，因此均不是大于一的整数素数幂；note 791 式 (4) 给出**整个** \(B_p\) 主压缩的 \(C_p\) 块恒为零，包括自环。由 note 791 式 (6) 的 \(\|E_p\|=O(1)\)，
\[
\boxed{\quad
P_{B_p}A_{p^2,-}P_{B_p}
=D_kI_{B_p}+P_{B_p}E_pP_{B_p}
\succeq(L-O(1))I_{B_p}>0
\quad(p\text{ 充分大}).
\quad}
\tag{4}
\]
式 (3) 的指定边界点满足 \(x<\sqrt2\)。更精确地，任意支撑于 \(B_p\) 的 \(f=vF\) 在 (1) 中有
\(\frac12\sum_{x,y}C_p(x,y)v_xv_y|F_x-F_y|^2=\sum_{x\in B_p}r_x|f_x|^2\)：负行势由通往 \(B_p\) 外的边能量**精确**支付，剩下的是 \(D_k\|f\|^2\)。因此该点不是实际 Weil 负方向。\(\square\)

## 消去正内区仍有对数级 Schur 代价

令 \(R_p=W_p\ominus B_p\)。对充分大的 \(p\)，\(x_0=4/3\in\mathcal F_p\) 且 \(x_0<\sqrt2\)。取素数 \(5\le q<(p-1)/4\)，则 \(y_q=4q/3\in\mathcal F_p\)、\(y_q>\sqrt2\)，并且 \(y_q/x_0=q\)。note 791 式 (4) 因而给
\[
C_p(x_0,y_q)\ge c_q=\frac{\log q}{\sqrt q}.
\]
各 \(y_q\) 不同，所以素数定理的 Stieltjes 形式给
\[
\|P_{R_p}C_pe_{x_0}\|^2
\ge\sum_{5\le q<(p-1)/4\atop q\text{ 素数}}\frac{(\log q)^2}{q}
=\left(\frac12+o(1)\right)(\log p)^2
=\left(\frac18+o(1)\right)L^2.
\tag{5}
\]
这里 \(e_{x_0}=w_{x_0}\) 是单位坐标。真实压缩 \(A_W=P_{W_p}A_{p^2,-}P_{W_p}=D_kI-C_p+E_p\) 的 \(\|E_p\|=O(1)\)，故同一列满足
\[
\|P_{R_p}A_We_{x_0}\|
\ge\left(\frac1{2\sqrt2}+o(1)\right)L.
\tag{6}
\]
由 (4)，\(A_B=P_{B_p}A_WP_{B_p}\) 对充分大 \(p\) 严格正，且
\(A_B\preceq(L+O(1))I_{B_p}\)。因此消去 \(B_p\) 对 \(R_p\) 的正 Schur 反馈 \(F_p=A_{RB}A_B^{-1}A_{BR}\) 满足
\[
\boxed{\quad
\|F_p\|
\ge\frac{\|A_{BR}\|^2}{L+O(1)}
\ge\left(\frac18+o(1)\right)L.
\quad}
\tag{7}
\]
式 (7) 是**真实**主压缩中的损失下界：\(B_p\) 自身的 \(L-O(1)\) 正间隙不能使它的消去只花费 \(O(1)\)。它并不说明整个 Schur 补为负。\(\square\)

## 边界

(4) 只控制 \(B_p\) 的主压缩，(7) 定量表明跨区反馈仍有对数级。\(R_p\) 的真实余块及无限维正交补的 Schur 反馈尚未合并；本文不判定全尺度局部 Weil 正性或 RH。
