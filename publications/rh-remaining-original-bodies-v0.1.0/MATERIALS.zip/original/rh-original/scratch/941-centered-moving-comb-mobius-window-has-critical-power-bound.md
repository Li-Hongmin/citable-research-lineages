# 中心化移动短管的 Möbius 和在五分之一次幂达到目标量纲

日期：2026-10-02。外部输入为 Priyamvad Srivastav, *Log-free bounds on exponential sums over primes*, arXiv:2505.07803v2 (2026-01-27), Theorem 1 的 Möbius 部分；2026-10-02 核对原文 HTML 的参数范围及式 (1.4) 的 $\mathscr G_\eta$。本稿只证明一个与 [note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 末带几何匹配的**中心化窗口**定理；不估计该 note 的未中心化真实 Poisson 和，亦不证明完整 moving-$N$ 门或 RH。以下解析证明尚待异源复核。

## 定理

令 $Y\to\infty$ 沿整数，$H$ 为满足 $Y^{1/5}\le H\le Y^{1/4}$ 的整数，固定 $f\in C_c^1((1,11/10))$。写 $x_n=n/Y$、$L_Y(x)=x/\log Y$，并定义
\[
\Omega_{Y,H}(n)
=\mathbf1_{\,0<\{Hn/Y\}<L_Y(x_n)}-L_Y(x_n).
\tag{1}
\]
则对每个固定 $\varepsilon>0$，一致于该 $H$ 范围，
\[
\boxed{\quad
\left|\sum_{n\ge1}\mu(n)f(n/Y)\Omega_{Y,H}(n)\right|
\ll_{f,\varepsilon} H^2Y^{1/2+\varepsilon}.
\quad}
\tag{2}
\]
因此乘上末带 Poisson 系数的 $H^{-2}$ 量级后，**中心化窗口的这一标量 Möbius 和**为 $O_{f,\varepsilon}(Y^{1/2+\varepsilon})$。式 (2) 保留的零模是
$\sum_n\mu(n)f(n/Y)L_Y(n/Y)$；本定理并不对它给固定幂节省。

## 外部估计及参数

取 $\eta=1/10$。原文 Theorem 1 在 $q=1$、$\alpha=\delta/X$、$|\delta|\le X^{3/10}$ 时给
\[
\left|\sum_{n\le X}\mu(n)e(n\alpha)\right|
\le\mathscr G_{1/10}(u,u)\frac{X}{\sqrt{\delta_0}},
\quad \delta_0=\max(1,|\delta|/4),
\quad u=\frac{\log\delta_0}{\log X}.
\tag{3}
\]
原文式 (1.4) 为
$\mathscr G_\eta(u,u_0)=4.01[1+\eta^3-(\eta+3u+u_0)/2]/[1-(\eta+5u+u_0)/2]$。当 $\eta=1/10$、$0\le u=u_0\le3/10$ 时分母至少 $1/20$，故因子一致有界。由 (3) 与 Abel 求和，对任意固定 $f\in C_c^1((1,11/10))$、$1\le k\le K$、频率
\[
\alpha=\frac{kH}{Y}
\quad\text{或}\quad
\alpha=\frac{k(H-1/\log Y)}{Y},
\qquad K=\left\lfloor\frac{Y^{3/10-\delta}}{2H}\right\rfloor,
\tag{4}
\]
只要固定 $0<\delta<1/100$，便有
\[
\left|\sum_n\mu(n)f(n/Y)e(n\alpha)\right|
\ll_f\frac{Y}{\sqrt{kH}}.
\tag{5}
\]
确实，Abel 求和只需 $X\asymp Y$ 的各个前缀；对此 $|X\alpha|\le(11/10)KH\le Y^{3/10-\delta}$ 对充分大 $Y$ 小于 $X^{3/10}$，且 $|X\alpha|\asymp kH\to\infty$。

## 平滑周期窗与硬边界

取非负 $C_c^\infty((-1,1))$ 函数 $\rho$，$\int\rho=1$。对 $0<\sigma<L_Y(1)/4$，令 $\rho_\sigma$ 为周期化的 $\sigma^{-1}\rho(t/\sigma)$，并在圆周 $\mathbb R/\mathbb Z$ 上定义
$g_{x,\sigma}=\rho_\sigma*\mathbf1_{(0,L_Y(x))}$。它的平均值为 $L_Y(x)$；对 $k\ne0$，Fourier 系数为
\[
\widehat g_{x,\sigma}(k)
=\widehat\rho(\sigma k)
\frac{1-e(-kL_Y(x))}{2\pi i k}.
\tag{6}
\]
而 $g_{x,\sigma}(t)$ 与硬指示函数只在 $t$ 距 $0$ 或 $L_Y(x)$ 的圆周距离不超过 $\sigma$ 时可能不同，差的绝对值至多 $1$。对 $n/Y\in\operatorname{supp}f$，条件分别是
\[
\left\|\frac{Hn}{Y}\right\|_{\mathbb R/\mathbb Z}\le\sigma,
\qquad
\left\|\frac{(H-1/\log Y)n}{Y}\right\|_{\mathbb R/\mathbb Z}\le\sigma.
\tag{7}
\]
任一实数 $c\asymp H$ 在固定比例长的 $n$ 区间内跨过 $O(H)$ 个整数相位；每个相位的 $\sigma$ 邻域含至多 $O(\sigma Y/H+1)$ 个整数 $n$。因此 (7) 涉及的 $n$ 总数为
\[
O_f(\sigma Y+H).
\tag{8}
\]
用 $|\mu(n)|\le1$，硬窗换成平滑窗的和误差也受 (8) 控制。

令 $\delta=\min(\varepsilon/8,1/200)$，$K$ 如 (4)，取
\[
\sigma=\frac{Y^\delta}{K}.
\tag{9}
\]
因为 $H\le Y^{1/4}$，有 $K\gg Y^{1/20-\delta}$、$\sigma\ll H Y^{-3/10+2\delta}=o(1/\log Y)$，故上述平滑窗合法，且 $K\sigma=Y^\delta$。

将 (6) 乘以 $e(kHn/Y)$，由于 $L_Y(n/Y)=n/(Y\log Y)$，每个非零模恰为
\[
\widehat\rho(\sigma k)\frac1{2\pi i k}
\left[e\!\left(\frac{kHn}{Y}\right)
-e\!\left(\frac{k(H-1/\log Y)n}{Y}\right)\right].
\tag{10}
\]
对 $1\le |k|\le K$ 用 (5)、$|\widehat\rho(\sigma k)|\le1$ 及
$\sum_{k\ge1}k^{-3/2}<\infty$，总贡献为 $O_f(Y/\sqrt H)$。对 $|k|>K$，$\widehat\rho(v)\ll_{\rho,A}(1+|v|)^{-A}$，先对 $n$ 用 $|\mu f|\ll_f1$，再绝对求 Fourier 尾，得对任意固定 $A>1$，
\[
\text{高模贡献}\ll_{f,\rho,A}
Y\sum_{k>K}\frac{(1+\sigma k)^{-A}}k
\ll_{f,\rho,A}Y(\sigma K)^{-A}
=Y^{1-A\delta}.
\tag{11}
\]
结合 (8)–(11)，中心化和的绝对值至多
\[
O_{f,\rho,A}\left(\frac{Y}{\sqrt H}
+\sigma Y+H+Y^{1-A\delta}\right).
\tag{12}
\]
由 $K\asymp Y^{3/10-\delta}/H$，有 $\sigma Y\ll H Y^{7/10+2\delta}$。在 $H\ge Y^{1/5}$ 时，
\[
\frac{Y}{\sqrt H}\le H^2\sqrt Y,
\qquad
H Y^{7/10+2\delta}\le H^2\sqrt Y\,Y^{2\delta}.
\]
取固定 $A$ 满足 $A\delta>1/10$，则 $Y^{1-A\delta}\le Y^{9/10}\le H^2\sqrt Y$；又 $H\ll H^2\sqrt Y$。因 $2\delta<\varepsilon$，式 (12) 给 (2)。$\square$

## 与真实末带的接口和边界

对 note 845 的 $I_a$，$q/Y=x$ 落在 $a/H$ 后长约 $x/(H\log Y)$ 的短窗；式 (1) 是它在变量 $\{Hx\}$ 中的首阶几何模型。这个模型的非零 Fourier 模可由现有 Möbius 加性定理支付到 $H^2Y^{1/2+\varepsilon}$，而平均 $L_Y(x)$ 所乘的零模仍受 Mertens 型信息支配。真实 $F_{a,q}(N)$ 另有奇偶系数、$q$ 依赖振幅和移动相位；不能把 (2) 直接替换为其上界。下一项决定性问题是对这些真实权的非零周期模做同样的定量支付，同时精确保留零模。
