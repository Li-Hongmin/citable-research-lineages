# 真实奇数源 $k=3$ 与 $k=1$ 交叉臂的常量异号补偿

日期：2026-10-01。接 [scratch/864](864-odd-source-kernel-has-an-exact-blind-interval.md) 式 (7)--(8) 的精确奇数源核、[scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 的高除数门及 [scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 所核对的 Matomäki--Shao--Tao--Teräväinen 2023 Theorem 3.1(i)。本稿在一个明确的 $k=3$ 对 $k=1$ 真实 Möbius 交叉臂中定位正负常量块；论证暂留 scratch 待异源复核。其 signed 总和只有任意对数幂节省，尚非 RH 所需固定幂界。

固定 $s>1$，沿用 scratch/860 的偶非负带通权 $w_H(h)$ 与 $J_H(r)=\sum_hw_H(h)e(-hr/M)$。令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$L=\lfloor M/(32H)\rfloor$、$K_0=H^3/\log^7(2M)$、$R=\lfloor H^2/\log^4(2M)\rfloor$。取非负 $\psi\in C_c^3((1,2))$，并假设某个固定闭区间 $J\subset(3/2,2)$ 上 $\phi(t)=\psi(t)/t\ge c_\psi>0$。记
\[
 U=\{u\text{ odd}:M/2<u<2M/3,\ 3u/M\in J\},
 \qquad V=\{v\text{ odd}:M<v<2M,\ v/M\in J\}.
\]
在 scratch/859 的真实剩余门中，取有序索引 $d=u,e=v$ 的指定物理项 $m=3u,n=v$，再施加
\[
 K_0<|3u-v|\le L,
 \qquad \max\{u/(u,v),v/(u,v)\}>R.
 \tag{1}
\]
其交叉和为
\[
 \mathfrak C_{31}=
 \frac{16(\log3)(\log2)}{M^2}
 \sum_{\substack{u\in U,\ v\in V\\(1)}}
 \mu(u)\mu(v)\phi(3u/M)\phi(v/M)J_H(3u-v).
 \tag{2}
\]
这是实际的 $\mu(u)\mu(v)b_u(3u)b_v(v)$ 项：$b_u(3u)=-4(\log3)M^{-1}\phi(3u/M)$、$b_v(v)=-4(\log2)M^{-1}\phi(v/M)$。条件 $u,v>D$ 自动成立；若 $u\mid v$ 且 $|3u-v|\le L=o(M)$，因 $u>M/2$，只能有 $v=3u$，但 $K_0<|3u-v|$ 已排除它；$v>u$ 则排除了 $v\mid u$。$L<K_{s,2}$，故 (2) 确在缩短远差后的大约化比例、中距离高除数门内。

把 (2) 按 $\mu(u)\mu(v)=+1$ 或 $-1$ 分成 $\mathfrak C_{31}^+$、$\mathfrak C_{31}^-$。则对每个固定 $A>0$，一致于上述 $H$，
\[
 \boxed{\quad
 \mathfrak C_{31}^+\ge c_{s,\psi}>0,
 \qquad \mathfrak C_{31}^-\le-c_{s,\psi}<0,
 \qquad \mathfrak C_{31}=O_{A,s,\psi}((\log M)^{-A}).
 \quad}\tag{3}
\]
因而这两条最简单的存活 cofactor 线本身已有常量级正负补偿，不能逐项取绝对值；(3) 仍远弱于 $H^4/M$ 的固定幂门。

## 证明

先暂时删除 (1) 的约化比例限制。对 $|r|\le L$，$|h|\le4H$ 保证 $|2\pi hr/M|\le\pi/4$，而 $w_H\ge1$ 于 $H\le|h|\le2H$，故
\[
 J_H(r)=\sum_hw_H(h)\cos(2\pi hr/M)\gg_s H.
 \tag{4}
\]

对任意长度 $T\gg M^{3/4}$、位置 $x\asymp M$ 的整数区间 $I$，平方自由展开 $\mu^2(n)=\sum_{a^2\mid n}\mu(a)$ 给出一致的奇数计数
\[
 \sum_{n\in I,\ n\text{ odd}}\mu(n)^2
 =\frac4{\pi^2}T+O(\sqrt M).
 \tag{5}
\]
文献定理 3.1(i) 对区间内的奇数等差进程直接给
$\sum_{n\in I,\ n\text{ odd}}\mu(n)=O_A(T\log^{-A}M)$，因为 $3/4>7/12$。合并 (5)，每个这样的 $I$ 均有
\[
 \#\{n\in I:n\text{ odd},\ \mu(n)=\pm1\}
 =\frac2{\pi^2}T+o(T),
 \tag{6}
\]
误差对所用全部区间一致。

把 $MJ$ 分成 $\asymp_J M/L\asymp_J H$ 个长度 $L$ 的完整格，忽略两个端格。对每格 $Q$，条件 $3u\in Q$ 给 $u$ 一个长度 $L/3$ 的区间，$v\in Q$ 给 $v$ 一个长度 $L$ 的区间；两者均满足 (6)。故每格同号及异号的有序 $(u,v)$ 各有 $\gg L^2$ 对。删去 $|3u-v|\le K_0$ 最多损失 $O(L(K_0+1))=o(L^2)$ 对，因为
\[
 \frac{K_0}{L}\ll\frac{H^4}{M\log^7M}=o(1).
\]
所留同格配对均满足 $|3u-v|\le L$，并由 (4) 与 $\phi\ge c_\psi$ 使 (2) 的每个非零项具有相应符号及绝对值 $\gg H/M^2$。汇总 $\asymp H$ 个格得到未加比例限制时
\[
 \mathfrak C_{31}^+\gg \frac{H\cdot L^2\cdot H}{M^2}\gg1,
 \qquad
 \mathfrak C_{31}^-\ll-1.
 \tag{7}
\]

为估 signed 总和，固定 $u$。在 $K_0<|3u-v|\le L$ 内，$v$ 分处至多两个长度 $L$ 的整数区间。沿用 scratch/862 的整块分割：取 $B_0=\lfloor M^{2/3}\rfloor$，定理 3.1(i) 逐个 $B_0$ 整块控制奇数进程，剩余端块用 $|\mu|\le1$，且 $B_0=o(L\log^{-A}M)$。于是对任意这样的子区间及每个固定 $A>0$，
\[
 \left|\sum_{v\in I,\ v\text{ odd}}\mu(v)\right|
 \ll_A L(\log M)^{-A}.
 \tag{8}
\]
在 $|r|\le L$ 有 $|J_H(r)|\ll H$、$|J'_H(r)|\ll H^2/M$。因此 $v\mapsto\phi(v/M)J_H(3u-v)$ 在上述每个区间上的上确界与总变差之和为 $O_{s,\psi}(H)$。对 (8) 作 Abel 求和，得到每个 $u$ 的内和 $O_A(HL\log^{-A}M)$。$|U|\ll M$，且 $HL/M\ll1$，故未加比例限制的 (2) 为 $O_A(\log^{-A}M)$。

最后，若 $u/(u,v),v/(u,v)\le R$，写 $u=at,v=bt$ 且 $\max(a,b)=q\le R$。对每个 $q$ 至多 $2q$ 个有序 $(a,b)$，而 $qt=\max(u,v)\le2M$，故这些 $(u,v)$ 总数 $O(MR)$。每个 (2) 的绝对值至多 $O_{s,\psi}(H/M^2)$，被比例限制删除的绝对量因此为
\[
 O_{s,\psi}\!\left(\frac{HR}{M}\right)
 \ll\frac{H^3}{M\log^4M}=O(M^{-1/4}),
 \tag{9}
\]
其中 $H\ll M^{1/4}$。式 (9) 比任意固定负对数幂小，不改变 (7) 或 signed 上界。$\square$

## 边界

这里 $\psi$ 在 $(3/2,2)$ 有正值是具体交叉臂存在的条件。式 (3) 用的是短区间 Möbius 的任意对数幂估计；它并未给出 $O_\varepsilon(H^4M^{-1+\varepsilon})$，也未控制其余 cofactor 线之间的协方差、完整 moving-$N$ 均方、全尺度局部 Weil 正性或 RH。
