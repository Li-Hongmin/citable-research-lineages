# 固定幂尺度的滑动 Farey 分母块：素数--合数负协方差候选

日期：2026-09-30。仅作待独立复核的证明草稿。依赖 notes 800、801、832、833 的精确频率系数与斜楔定义，以及 D. R. Heath-Brown, *Prime Numbers in Short Intervals and a Generalized Vaughan Identity*, Canadian Journal of Mathematics **34** (1982), 1365–1377, DOI 10.4153/CJM-1982-095-9，首页定理：固定 \(7/12<\theta\le1\) 时，\(\sum_{x-x^\theta<n\le x}\Lambda(n)\sim x^\theta\)。文献核对日期：2026-09-30；依据 Cambridge Core 原文 PDF 首页。

## 命题

固定 \(5/6<\alpha<1\)。令 \(Y\to\infty\)，\(D=\lfloor Y^\alpha\rfloor\)，\(B=\lfloor D^2/[Y(\log Y)^2]\rfloor\)，\(L=\lfloor Y^{5/6}\rfloor\)。存在整数 \(t=t(Y)\in[\lceil D/2\rceil,D-B]\)，置 \(I=(t,t+B]\cap\mathbb Z\)，\(Q=t+B\)，使 note 833 式 (1) 定义的
\[
G_N=\sum_{p\in I\text{ prime}}F_{p,N},\qquad
T_N=\sum_{q\in I}F_{q,N}\qquad(Y<N\le2Y)
\]
满足，记 \(v=\#\{p\in I:p\text{ prime}\}\)，
\[
v\sim\frac B{\log D},\qquad
\sup_{Y<N\le2Y}|T_N|=o\!\left(\frac{BD}{Y\log Y}\right),
\tag{1}
\]
\[
E_Y:=\sum_{Y<N\le2Y}G_N^2
\sim\frac{25v^2Q^2}{4\pi^2Y}
\asymp_\alpha\frac{Y^{6\alpha-3}}{(\log Y)^6},
\tag{2}
\]
\[
\sum_{Y<N\le2Y}G_N(T_N-G_N)=-(1+o(1))E_Y.
\tag{3}
\]
全部这些原始频率项位于 note 832 的 \(\mathcal V_N\) 内。式 (3) 是**无条件**、固定幂尺度、同一分子 \(1\) 与同一短分母块中的真实 \(\mu\) 负协方差。它对一个随 \(Y\) 选择的块成立；不控制 \(\mathcal V_N\) 的完整均方，也不证明 RH。

## 证明

置 \(f_\kappa(q)=\kappa_q\mu(q)q/\varphi(q)\)，其中奇 \(q\) 的 \(\kappa_q=5\)，偶 \(q\) 的 \(\kappa_q=1\)。note 833 式 (7) 已证明
\[
F_\kappa(x):=\sum_{q\le x}f_\kappa(q)\ll xe^{-c_f\omega(x)},
\qquad \omega(x)=(\log x)^{3/5}(\log\log x)^{-1/5},
\tag{4}
\]
且 \(|f_\kappa(q)|\ll\log\log(3q)\)。令 \(A=\lceil D/2\rceil\)，对 \(A\le t\le D-B\) 定义 \(S(t)=\sum_{t<q\le t+B}f_\kappa(q)\)。每个内部整数属于恰好 \(B\) 个滑动块；两端合计至多 \(2B\) 个整数的重数小于 \(B\)。若 \(M=D-B-A+1\asymp D\)，由 (4) 得
\[
\left|\frac1M\sum_{t=A}^{D-B}S(t)\right|
\ll B e^{-c\omega(D)}+\frac{B^2}{D}\log\log(3D)
=o\!\left(\frac B{\log D}\right).
\tag{5}
\]
又 \(|S(t+1)-S(t)|\le |f_\kappa(t+1)|+|f_\kappa(t+B+1)|\ll\log\log(3D)=o(B/\log D)\)。一般实数列若不变号，则其最小绝对值不超过平均值的绝对值；若变号，某个相邻换号对的绝对值不超过最大相邻差。因此由 (5) 可选一个 \(t\) 满足
\[
|S(t)|=o(B/\log D).
\tag{6}
\]
此选择与 \(N\) 无关。

下面核对该块的素数数目。对固定 \(\alpha>5/6\)，\(B=D^{2-1/\alpha+o(1)}\)，故 \(B\gg D^{3/4}\) 且 \(B=o(D)\)。Heath-Brown 首页定理取 \(\theta=2/3\)；把任意 \((t,t+B]\subset(D/2,D]\) 从右向左分成长度 \(x^{2/3}\) 的完整小段和一个不足 \(O(D^{2/3})\) 的余段。完整小段上的 \(\Lambda\)-和各为长度乘 \(1+o(1)\)，误差对 \(x\asymp D\) 一致；余段以 \(\Lambda(n)\le\log(2D)\) 支付。因此
\[
\sum_{t<n\le t+B}\Lambda(n)=B(1+o(1))
\tag{7}
\]
对所有上述 \(t\) 一致。素数幂 \(p^j\), \(j\ge2\), 的总权至多 \(O(\sqrt D\log^2 D)=o(B)\)，且每个素数的对数为 \(\log D+O(1)\)。于是所有这些块都满足
\[
v\sim B/\log D.
\tag{8}
\]

对 \(q\in I\) 有 \(N/q\asymp Y^{1-\alpha}\)，故 note 800 式 (12) 的一致 Möbius 调和界可与 note 801 式 (7) 的精确 Poisson 系数合用。与 note 833 式 (10)--(11) 的奇偶计算完全相同，均匀于 \(q\in I\)、\(Y<N\le2Y\)，
\[
C_q(N)=-qf_\kappa(q)
 +O_\alpha\!\left(q\eta_Y+q\log\log(3Y)(q/N)^2+q^2L/Y^2\right),
\qquad \eta_Y=e^{-c_\alpha\omega(Y)}.
\tag{9}
\]
严格端点与 \(d\le N-L\) 的裁剪见 note 833 式 (9)--(11)。因 \(q\gg D\gg L\)，每个 \(q\) 最多失去一个倍数 \(k\)，其贡献已含在末项。将 (9) 代入 \(T_N\) 并逐项求和，所得误差相对于 \(BD/(Y\log Y)\) 为
\[
O_\alpha\!\left(\log Y\,\eta_Y
+\log Y\log\log Y\,(D/Y)^2
+\frac{DL\log Y}{Y^2}\right)=o(1).
\tag{10}
\]
记 \(g_N(u)=u\cos(2\pi N/u)\)。在 \(I\) 上 \(|g_N(Q)|\ll D\)，\(\sup|g'_N|\ll Y/D\)，于是 (6) 和 \(\sum_{q\in I}|f_\kappa(q)|\ll B\log\log Y\) 给出，逐 \(N\) 一致，
\[
\left|\sum_{q\in I}f_\kappa(q)g_N(q)\right|
\le D|S(t)|+O\!\left(\frac{B^2Y}{D}\log\log Y\right)
=o\!\left(\frac{BD}{\log Y}\right),
\tag{11}
\]
因为 \(BY/D^2\ll(\log Y)^{-2}\)。由 (9)--(11) 即得 (1) 的点态式。

对素数 \(p\in I\)，\(f_\kappa(p)=-5p/(p-1)\)，故 (9) 为 \(C_p(N)=5p+o(p)\)，一致于 \(p,N\)。又
\[
\sup_{p\in I,\,Y<N\le2Y}|N/p-N/Q|\ll YB/D^2\ll(\log Y)^{-2},
\]
故
\[
G_N=-\frac{5vQ}{\pi N}\cos\frac{2\pi N}{Q}
+o\!\left(\frac{vD}{Y}\right)
\tag{12}
\]
逐 \(N\) 一致。由于 \(Q\asymp D\) 且 \(Q=o(Y)\)，有限几何和与 Abel 求和给
\[
\sum_{Y<N\le2Y}\frac{\cos^2(2\pi N/Q)}{N^2}
=\frac1{4Y}+O(Q/Y^2+Y^{-2}).
\tag{13}
\]
式 (8)、(12)--(13) 证明 (2)。由 (1)--(2)，\(\|T\|_2=o(\|G\|_2)\)，展开 \(\langle G,T-G\rangle\) 得 (3)。最后 \(q>Y^{4/5}\)、\(q>L\)，约分分子为 \(1<\min(A,A_j)\)，且全部原始 \(kq\le N-L\)；故这些项均属于 \(\mathcal V_N\)。\(\square\)

最薄弱接口：Heath-Brown 原文的短区间 \(\Lambda\)-渐近是否可按上述切分一致转用于每个 \(B\gg D^{3/4}\) 的滑动块；以及平均值加相邻差是否确实保证同一块满足 (6)。
