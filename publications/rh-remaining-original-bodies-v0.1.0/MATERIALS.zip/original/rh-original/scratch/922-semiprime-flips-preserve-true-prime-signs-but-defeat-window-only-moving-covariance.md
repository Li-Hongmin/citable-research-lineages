# 真素数符号仍不足以从单窗资料推出 moving covariance 固定幂门

日期：2026-10-02。接 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实联合观察、[scratch/904](904-window-exact-multiplicative-prime-flips-defeat-the-post-h3-gate.md) 的单窗扰动方法、[scratch/909](909-two-dyadic-observations-form-the-complete-prime-mobius-frame.md) 的两尺度恒等式及 [scratch/913](913-logarithmic-critical-collar-of-the-true-moving-observation-gate.md) 的短区间对数估计。这里把扰动从**素数**移到两素因子合数，因而保留全部真实素数值 $f(p)=\mu(p)=-1$。所得 $f$ 不乘法，不能当作真实 Möbius 函数；结论只判定一类窗口资料的推理能力，不反驳实际算术门或 RH。已完成静态逐式核对，尚未异源复核。

## 命题候选

令 $M=2Y\to\infty$ 沿偶整数，固定实值非负、非零的 $\psi\in C_c^3((1,2))$，$\phi(u)=\psi(u)/u$。令 $H=\lceil Y^{1/5}\rceil$、$h_0=\lfloor3H/2\rfloor$、$L=\lfloor M/(32H)\rfloor$、$B_*=\lfloor M^{71/120}\rfloor$、$\delta_M=e^{-\sqrt{\log M}}$，取 note 849 的非负偶带通权 $w_H(h)=v(h/H)$，其中 $v\ge1$ 于 $1\le|t|\le2$，并置 $J_H(r)=\sum_hw_H(h)e(-hr/M)$。对任意 $f$ 定义 $\Lambda_f=f*\log$ 及
\[
c_f(m)=2\mathbf1_{2\mid m}(\Lambda_f(m/2)-1)
-4\bigl(\Lambda_f(m)-1+(\log2)f(m)\bigr),
\quad
A_h(f)=\frac1M\sum_{M<m<2M}c_f(m)\phi(m/M)e(-hm/M).
\tag{1}
\]
存在四个函数 $f_{ab}$、$a,b\in\{0,1\}$，使 $f_{00}=\mu$，且每个函数同时满足：

1. $f_{ab}(n)\in\{0,\pm1\}$、$|f_{ab}(n)|=\mu(n)^2$ 对所有 $n$；$f_{ab}(n)=\mu(n)$ 对 $n\le M$ **及所有素数** $n=p$；$f_{ab}(2u)=-f_{ab}(u)$ 对每个奇数 $u$。
2. $\Lambda_{f_{ab}}(n)=\Lambda(n)$ 对所有 $n<2M$，而且在观察窗内，对于每个固定 $A>0$，任意长度 $B_*$ 的整数区间 $I$ 都有 $\sum_{m\in I}c_{f_{ab}}(m)=O_A(B_*(\log M)^{-A})$。对每个固定 $C>0$ 和 $1<q\le(\log M)^C$，还有 $\mathbf1_{q\mid m}c_{f_{ab}}(m)=\mathbf1_{q\mid m}c_\mu(m)$ 逐点成立。
3. 四者中至少一个的完整带通能量，以及四者中至少一个的真实位置中距离 signed Gram，分别超过目标：
   \[
   \boxed{\quad
   \sum_hw_H(h)|A_h(f_{ab})|^2
   \gg_{\psi,v}\frac{\delta_M^2}{\log^4M}
   \gg\frac{H^4}{M},
   \quad}\tag{2}
   \]
   \[
   \boxed{\quad
   \left|\sum_{T_\gamma<|m-n|\le L}
   \frac{c_{f_{ab}}(m)c_{f_{ab}}(n)}{M^2}
   \phi(m/M)\phi(n/M)J_H(m-n)\right|
   \gg_{\psi,v,\gamma}\frac{\delta_M^2}{\log^4M}
   \gg\frac{H^4}{M},
   \quad}\tag{3}
   \]
   其中 $T_\gamma=\lfloor H^3(\log M)^\gamma\rfloor$，$\gamma>0$ 是任意预先固定的常数；(2)、(3) 的见证函数可以不同。

因而**真实素数符号**、平方自由支撑、完整 $2$-adic parity、窗口内精确 $f*\log=\Lambda$、任意固定对数幂一阶短和及全部固定对数幂小模整除资料，合在一起仍不能对这一测试类推出 $H^4/M$。被破坏的事实是两素因子合数处的乘法关系 $f(pq)=f(p)f(q)$，这与 scratch/904 的高素数翻转障碍不同。

## 每个短块都有足够的两素因子数

取 $\theta=1/100$。把 $[M^\theta,2M^\theta]$ 内的素数记为 $p$；对每个 $B_*$ 整数块 $I\subset(M,2M)$，计数 $m=pq\in I$、$q$ 为素数。因 $q\asymp M/p$，相应的 $q$ 区间长度为 $B_*/p$。一致于上述 $p$ 与 $I$，
\[
\frac{B_*}{p}\gg (M/p)^{7/12+1/1000},
\qquad \frac{B_*}{p}\ll (M/p)^{1-1/1000}.
\tag{4}
\]
前一式的指数差为
$71/120-\theta-(1-\theta)(7/12+1/1000)=953/300000>0$。
Matomäki--Shao--Tao--Teräväinen 2023 Theorem 3.1(i) 与式 (3.11) 因而给每个这种 $q$ 区间的
\[
\#\{q\text{ prime}:pq\in I\}
=\frac{B_*}{p\log(M/p)}
+O_A\!\left(\frac{B_*}{p\log^A M}\right).
\tag{5}
\]
素数幂转换的全母区间费用为 $O(\sqrt{M/p}\log^2M)$，小于式 (5) 的误差；$1/\log q$ 权由 Abel 求和处理。由素数定理
$\sum_{M^\theta\le p\le2M^\theta}p^{-1}\asymp1/\log M$，把 (5) 对 $p$ 求和得**每个**完整 $B_*$ 块中有
\[
\#\{m=pq\in I:p,q\text{ prime},\ M^\theta\le p\le2M^\theta\}
\gg \frac{B_*}{\log^2M}.
\tag{6}
\]
对充分大的 $M$ 有 $q\gg M^{1-\theta}>p$，所以每个 $m$ 的表示唯一。这些 $m$ 为奇平方自由数，两个素因子都大于任意固定对数幂。

## 扰动与窗口资料

选闭区间 $J\subset(1,2)$，使 $\phi\ge c_\psi>0$ 于 $J$。余弦 $\cos(2\pi h_0m/M)$ 的周期为 $M/h_0\asymp M/H$；因 $L\ll M/h_0$ 且 $B_*=o(L)$，可在 $MJ$ 中选出 $\gg_\psi M/L$ 个互不相交的长度 $L$ 的整数格 $C$，使每格上余弦都至少 $1/2$，每格又含 $\gg L/B_*$ 个完整的全局 $B_*$ 网格块。由 (6)，每块有 $\gg B_*/\log^2M$ 个可选的两素因子数。

置 $t=\lfloor\delta_MB_*/(100\log^2M)\rfloor\to\infty$。在每个上述 $B_*$ 块内任取 $2t$ 个互异的两素因子数，分成各有 $t$ 个的 $S_1,S_2$。两集互不相交，且
\[
|S_j|\gg_\psi\frac{\delta_M M}{\log^2M},
\quad
|S_j\cap C|\gg_\psi\frac{\delta_M L}{\log^2M}
\quad\text{对每个所选 }C,
\tag{7}
\]
每个含至多 $B_*$ 个整数的区间至多与两个全局网格块相交；若以实端点定义“长度 $B_*$”并同时计入两端点，至多相交三个网格块。因此任意惯例下只含 $O(t)$ 个 $S_j$ 元素。

对 $a,b\in\{0,1\}$，把 $S_1$ 中的数在 $a=1$ 时、$S_2$ 中的数在 $b=1$ 时，从真实 $\mu(pq)=+1$ 翻为 $-1$；同时把其两倍从 $\mu(2pq)=-1$ 翻为 $+1$。其余所有正整数保持真实 $\mu$ 值。这定义 $f_{ab}$，立即给第 1 项；这些修改位置都不是素数，且第一个修改位置大于 $M$。

对 $n<2M$，每个被改动的 $s=pq$ 只能以 $n=s$ 出现在 $(f_{ab}-\mu)*\log$，其权为 $\log1=0$；两倍 $2s$ 已在窗外。因此 $\Lambda_{f_{ab}}(n)=\Lambda(n)$，而在 $M<m<2M$ 有精确式
\[
c_{f_{ab}}(m)=c_\mu(m)+8(\log2)
\bigl(a\mathbf1_{S_1}(m)+b\mathbf1_{S_2}(m)\bigr).
\tag{8}
\]
scratch/913 的真实系数长度 $B_*$ 短和为任意固定对数幂小（用原 2023 定理，因 $71/120>7/12$）。由 (8) 和每块至多 $2t$ 个扰动，新增和为 $O(\delta_MB_*/\log^2M)=O_A(B_*\log^{-A}M)$。因 $s=pq$ 的两个素因子均大于 $(\log M)^C$，每个 $1<q\le(\log M)^C$ 都不整除 $s$；故该模数的逐点整除资料也保留。第 2 项全部成立。

## 带通能量和中距离环带

在 $h=h_0$，式 (8)、$\phi(s/M)\ge c_\psi$、$\cos(2\pi h_0s/M)\ge1/2$ 给
\[
|A_{h_0}(f_{10})-A_{h_0}(f_{00})|
\ge \frac{4(\log2)c_\psi}{M}|S_1|
\gg_\psi\frac{\delta_M}{\log^2M}.
\]
两个复数中至少一个模长达到右侧一半，且 $w_H(h_0)\ge1$，证明 (2)。因为 $H^4/M=M^{-1/5+o(1)}$ 而 $\delta_M^2/\log^4M=M^{-o(1)}$，超目标比较严格成立。

在 $|r|\le L$，$|h|\le4H$ 使 $|2\pi hr/M|\le\pi/4$，故 $J_H(r)\gg_vH>0$。每个所选 $L$ 格中的 $S_1\times S_2$ 配对有 $\gg\delta_M^2L^2/\log^4M$ 个；其中距离不超过 $T_\gamma$ 的配对至多 $O(|S_1\cap C|T_\gamma)$。对所有格求和，后者与前者的比至多
\[
O\!\left(\frac{T_\gamma\log^2M}{\delta_M L}\right)
=M^{-1/5+o(1)}\to0.
\]
由 $HL/M\asymp1$，在式 (3) 的真实位置环带上，两集指示函数的双线性式满足
\[
\mathcal B_\gamma(\mathbf1_{S_1},\mathbf1_{S_2})
\gg_{\psi,v}\frac{H}{M^2}
\frac{\delta_M^2ML}{\log^4M}
\gg\frac{\delta_M^2}{\log^4M}.
\tag{9}
\]
四个模型系数的混合二阶差，按 (8) 精确等于
\[
Q_\gamma(f_{11})-Q_\gamma(f_{10})-Q_\gamma(f_{01})+Q_\gamma(f_{00})
=128(\log2)^2\mathcal B_\gamma(\mathbf1_{S_1},\mathbf1_{S_2}),
\]
其中 $Q_\gamma$ 为式 (3) 的二次型。三角不等式与 (9) 保证四个 $|Q_\gamma(f_{ab})|$ 中至少一个达到 (3)。$\square$

## 边界

真实 $\mu$ 在每个两素因子位置都满足 $\mu(pq)=\mu(p)\mu(q)=+1$；本反模型明确违反这条关系。只读素数符号、窗口内卷积和现有短和的证明路线因此不足以支付固定幂 signed Gram；若沿这条单窗路线继续，必须加入能排除上述合数扰动的真实算术关系，并在同一二点和中量化它的相消。这里的四选一反模型没有指认真实 $f_{00}=\mu$ 为失败者，不构成 RH 反例。

[scratch/923](923-any-fixed-factor-depth-still-leaves-a-window-only-moving-covariance-countermodel.md) 把该构造推广到任意预先固定的素因子深度；[scratch/924](924-mobius-inversion-moves-the-full-observation-to-cofactors-at-least-three.md) 则直接使用真实的 $\mu*1=\delta_1$，给出反模型不满足的精确源恒等式。
