# 素数翻转的完整卷积脉冲响应与联合观察的检测延迟

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10) 的真实观察系数、[scratch/904](904-window-exact-multiplicative-prime-flips-defeat-the-post-h3-gate.md) 的窗口素数翻转及其在 $p,2p,3p$ 的计算，以及 [scratch/910](910-dyadic-frame-and-local-convolution-still-admit-supercritical-prime-flip-models.md) 的单窗支持边界。本文给出任意倍数的精确响应，并确定只读联合观察 $c$ 与单独读取 $\Lambda$ 的不同检测位置。这是非真实模型的范围性结论，不估计真实 signed Gram，也不证明 RH。

## 定理

令 $M>6$，$S$ 为 $(M,2M)$ 内的任意有限素数集。定义平方自由支撑的乘法函数 $f_S$：在 $S$ 中的素数取 $+1$，其他素数取 $-1$，高次素数幂取 $0$。令 $\ell=\log2$、$\Lambda_S=f_S*\log$，并在全体正整数上定义
\[
c_S(n)=2\mathbf1_{2\mid n}\bigl(\Lambda_S(n/2)-1\bigr)
-4\bigl(\Lambda_S(n)-1+\ell f_S(n)\bigr).
\tag{1}
\]
$c=c_\varnothing$ 即真实的 note 849 系数。置
\[
r(k)=2\mathbf1_{2\mid k}\Lambda(k/2)-4\Lambda(k)-4\ell\mu(k),
\qquad \Lambda(1)=0.
\tag{2}
\]
则对每个 $n<M^2$ 有精确恒等式
\[
\boxed{\quad c_S(n)-c(n)
=2\sum_{\substack{p\in S\\p\mid n}}r(n/p).\quad}
\tag{3}
\]
特别地，对每个 $p\in S$，
\[
\begin{array}{c|rrrr}
k&1&2&3&4\\ \hline
c_S(kp)-c(kp)&-8\ell&0&-8\log(3/2)&-4\ell
\end{array}
\qquad(kp<M^2).
\tag{4}
\]
单独的 von Mangoldt 通道却已在 $2p$ 检出翻转：
\[
\Lambda_S(2p)-\Lambda(2p)=2\ell.\tag{5}
\]
因此，$c_S-c$ 在 $(2M,3M)$ **逐点为零**。若进一步
$S\subset(4M/3,2M)$，则它在整个下一 dyadic 物理窗
$(2M,4M)$ 逐点为零；每个被翻转的 $p$ 在联合观察中首次于
$n=3p$ 再次显现。对这样的 $S$，在 $(M,2M)$ 上任取
$\phi\in C_c((1,2))$，其频率包仍满足
\[
\frac1M\sum_{M<m<2M}(c_S(m)-c(m))\phi(m/M)e(-hm/M)
=-\frac{8\ell}{M}\sum_{p\in S}\phi(p/M)e(-hp/M).
\tag{6}
\]
故下一个完整物理窗的联合观察值相同，不能从那里为第一窗的
Gram 自动生成一条 $p\leftrightarrow2p$ 负配对。

## 证明

若 $n<M^2$，它至多含一个来自 $S$ 的素因子，且该素因子只能出现一次。对 $p\in S$ 与 $p\mid n$ 写 $n=pk$；此时 $k<M<p$，$f_S(k)=\mu(k)$，故
\[
f_S(pk)-\mu(pk)=\mu(k)-(-\mu(k))=2\mu(k).
\]
于是限制在 $n<M^2$ 的系数上，
\[
f_S-\mu=2\sum_{p\in S}\delta_p*\mu.
\tag{7}
\]
卷积某个 $n<M^2$ 只使用不超过 $n$ 的系数，所以可在该范围内把 (7) 与 $\log$ 卷积，并用 $\mu*\log=\Lambda$，得到
\[
\Lambda_S-\Lambda=2\sum_{p\in S}\delta_p*\Lambda.
\tag{8}
\]
式 (1) 的背景 $4-2\mathbf1_{2\mid n}$ 不随 $f_S$ 改变。把 (7)--(8) 代入其余三项，利用卷积的结合律，即得 (3)。

直接使用 $\mu(1)=1$、$\mu(2)=\mu(3)=-1$、$\mu(4)=0$ 及
$\Lambda(1)=0$、$\Lambda(2)=\Lambda(4)=\ell$、$\Lambda(3)=\log3$，有
\[
r(1)=-4\ell,\quad r(2)=0,\quad
r(3)=-4\log(3/2),\quad r(4)=-2\ell.
\]
代回 (3) 给 (4)。式 (8) 在 $n=2p$ 只含
$2\Lambda(2)=2\ell$，给 (5)。

在 $(2M,3M)$ 内，来自 $S$ 的倍数只能是 $2p$，而 $r(2)=0$。
若 $p>4M/3$，$3p>4M$，因此 $(2M,4M)$ 内仍只可能碰到
$2p$，证明两个逐点零陈述。由于 $r(1)\ne0$、$r(2)=0$、
$r(3)\ne0$，每个 $p$ 在第一窗后的首次非零响应恰为 $3p$。
最后 $(M,2M)$ 内只有 $n=p$ 能被 $S$ 改变，把 (4) 的首列
乘以光滑权并求和便得 (6)。$\square$

## 对真实算术门的含义

真实 $\mu$ 满足 $\Lambda(2p)=0$，但对奇素数 $p$ 展开该关系只是
\[
(\mu*\log)(2p)=\log(2p)-\log p-\log2=0.
\tag{9}
\]
它逐点固定 $\mu(p)=-1$，因此排除了上述翻转模型；代入真实单窗
$c(m)$ 后并没有产生涉及另一个独立位置 $q$ 的估计。在 note 849
式 (13) 的同窗 Gram 中，$p\in(M,2M)$ 时 $2p>2M$，所以
$a_pa_{2p}=0$。本稿不能从 (9) 推出 $H^4/M$ 上界；该固定幂缺口仍是
真实素数、倍素数与 Möbius 系数的联合二点问题。
