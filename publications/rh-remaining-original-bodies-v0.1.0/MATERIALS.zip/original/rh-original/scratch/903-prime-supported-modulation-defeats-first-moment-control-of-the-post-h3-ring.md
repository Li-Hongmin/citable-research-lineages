# 高素数支撑的一阶短和资料不能支付 \(H^3\) 后的固定幂环带（候选）

日期：2026-10-02。针对 [scratch/902](902-local-bandpass-rank-one-main-term-is-repaid-by-each-channel-sidelobe.md) 式 (18) 之后的第一个未付物理环带。只改动高素数系数、保持任意固定对数幂的一阶短和与所有小模整除进程资料，仍可令该环带二次型超过目标固定幂。**反模型不是真实的 von Mangoldt 权，不反驳实际算术门或 RH。**以下证明尚待异源复核。

## 命题

固定实值非负、非零的 \(\psi\in C_c^3((1,2))\)，置 \(\varphi(u)=\psi(u)/u\)，并取 note 849 的非负偶带通权 \(\eta\)。令 \(M=2Y\) 沿偶整数趋于无穷，
\[
H=\lceil Y^{1/5}\rceil,\quad L=\lfloor M/(32H)\rfloor,\quad
T_B=\lfloor H^3(\log M)^B\rfloor,\quad h_0=\lfloor3H/2\rfloor,\quad
\delta_M=e^{-\sqrt{\log M}},
\tag{1}
\]
其中 \(B>0\) 固定。记
\[
K_H(k)=\sum_h\eta(h/H)e(-hk/M),\qquad
\mathcal Q_B[v]=\sum_{T_B<|m-n|\le L}
\frac{v(m)v(n)}{M^2}\varphi(m/M)\varphi(n/M)K_H(m-n).
\tag{2}
\]
令 \(c(m)\) 为 note 849 式 (10) 的真实联合系数。存在实相位 \(\theta_M\)，使只在高素数上非零的
\[
d_{\theta_M}(m)=\mathbf1_{\{m\ {\rm prime}\}}(\log m)
\cos(2\pi h_0m/M+\theta_M)
\tag{3}
\]
满足
\[
\boxed{\quad \mathcal Q_B[d_{\theta_M}]\ge c_{\psi,\eta}>0.\quad}\tag{4}
\]
令 \(c_M^0=c\)、\(c_M^\pm=c\pm\delta_Md_{\theta_M}\)。这三组系数在素数以外逐点相同，高素数位置与符号相同，且 \(|c_M^\sigma(m)|\ll\log M\)。对任意固定 \(A>0\)，三组都满足
\[
\sup_{\substack{I\subset(M,2M)\\|I|=\lfloor M^{71/120}\rfloor}}
\left|\sum_{m\in I}c_M^\sigma(m)\right|
\ll_A |I|(\log M)^{-A}.
\tag{5}
\]
对任意固定 \(C>0\) 及 \(1<q\le(\log M)^C\)，还有
\(\mathbf1_{q\mid m}c_M^\pm(m)=\mathbf1_{q\mid m}c(m)\) 在观察区间逐点成立。然而对每个充分大的 \(M\)，三组中至少一组满足
\[
\boxed{\quad
\left|\mathcal Q_B[c_M^\sigma]\right|
\gg_{\psi,\eta}\delta_M^2,\qquad
\frac{\delta_M^2}{H^4/M}\longrightarrow\infty.
\quad}\tag{6}
\]
因此高素数支撑、系数符号与大小、全部固定对数幂一阶短和，以及小模整除进程资料，不足以推出这个剩余环带的固定幂上界。式 (6) 没有指认真实 \(c\) 为失败者。

## 证明：真实素数配对与相位平均

选闭区间 \(J\subset(1,2)\) 使 \(\varphi\ge c_\psi>0\) 于 \(J\)。素数定理给
\(P=\#\{p:p/M\in J\}\asymp_\psi M/\log M\)。把 \(MJ\) 分成 \(O_\psi(M/L)\) 个长度至多 \(L\) 的整数格，令每格含 \(P_j\) 个素数。Cauchy--Schwarz 给同格异素数的有序配对数
\[
\sum_jP_j(P_j-1)\ge\frac{P^2}{O_\psi(M/L)}-P
\gg_\psi\frac{ML}{\log^2M}.
\tag{7}
\]
其中 \(|p-q|\le T_B\) 的配对至多 \(P(2T_B+1)\ll MT_B/\log M\)。因
\[
\frac{T_B\log M}{L}
\ll M^{-1/5}(\log M)^{B+1}\longrightarrow0,
\tag{8}
\]
扣除这批配对后仍有 \(\gg ML/\log^2M\) 对满足 \(T_B<|p-q|\le L\)。

对 \(|k|\le L\)，\(\eta\ge0\)、\(\eta\ge1\) 于 \(1\le|h|/H\le2\) 及 \(|h|\le4H\) 给
\[
K_H(k)=\sum_h\eta(h/H)\cos(2\pi hk/M)\gg_\eta H;
\]
同时 \(\cos(2\pi h_0k/M)\ge\cos(3\pi/32+o(1))>0\)。对 \(\theta\in[0,2\pi]\) 平均二次型，并用
\(\langle\cos(x+\theta)\cos(y+\theta)\rangle_\theta=\tfrac12\cos(x-y)\)，得到
\[
\begin{aligned}
\frac1{2\pi}\int_0^{2\pi}\mathcal Q_B[d_\theta]\,d\theta
&=\frac1{2M^2}\sum_{\substack{p,q\ {\rm prime}\\T_B<|p-q|\le L}}
(\log p)(\log q)\varphi(p/M)\varphi(q/M)
K_H(p-q)\cos(2\pi h_0(p-q)/M)\\
&\gg_{\psi,\eta}\frac{H}{M^2}
\frac{ML}{\log^2M}\log^2M
\asymp_{\psi,\eta}1.
\end{aligned}\tag{9}
\]
第一行每项非负，第二行只取 (7)--(8) 保留的同格配对。因此存在相位 \(\theta_M\) 使 (4) 成立；无需素数对猜想或局部素数对极限。

## 证明：一阶资料与极化

Matomäki--Shao--Tao--Teräväinen, *Forum Math. Pi* **11** (2023), e29, Theorem 3.1(i) 对 \(\Lambda-\Lambda^\sharp\) 与 \(\mu\) 的长度门槛是 \(x^{7/12+\varepsilon}\)；原论文式 (3.11) 给 \(\Lambda^\sharp\) 的主项。两处已对照原 PDF，且 [scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 式 (6)--(8) 给出到本项目 \(c\) 的映射。因此真实 \(c\) 在长度 \(M^{71/120}\) 的全部块上满足 (5)。对任意整数区间 \(I\)，
\[
\left|\sum_{m\in I}(c_M^\pm(m)-c(m))\right|
\le\delta_M\sum_{\substack{p\in I\\p\ {\rm prime}}}\log p
\le\delta_M|I|\log(2M).
\tag{10}
\]
因 \(\delta_M\log^{A+1}M\to0\)，(5) 对两组扰动系数仍成立。被改动的素数都大于 \(M\)，故没有 \(1<q\le(\log M)^C\) 能整除它们。且在高素数处 \(c(p)=-4\log p+O(1)\)，扰动幅度至多 \(\delta_M\log p\)，所以原负号保持。

实对称二次型 (2) 满足
\[
\mathcal Q_B[c_M^+]+\mathcal Q_B[c_M^-]-2\mathcal Q_B[c_M^0]
=2\delta_M^2\mathcal Q_B[d_{\theta_M}].
\tag{11}
\]
由 (4)，右侧至少为 \(2c_{\psi,\eta}\delta_M^2\)，所以三个左侧数中至少一个绝对值 \(\gg\delta_M^2\)。最后 \(H^4/M=M^{-1/5+o(1)}\)，而
\(\delta_M^2=e^{-2\sqrt{\log M}}=M^{-o(1)}\)；两者之比趋于无穷，证明 (6)。\(\square\)

反模型只关闭一阶资料的推理方式。扰动破坏了真实高素数行的精确 von Mangoldt 权；若固定幂门成立，证明仍可利用 \(\Lambda=\mu*\log\)、素数幂支撑与真实双点相关。不能由 (6) 宣称实际 \(c\) 的环带下界或 RH 反例。
