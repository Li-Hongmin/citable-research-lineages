# 全 Farey 正权的边界残差趋零与近零模态必要条件（候选）

外区谱隙与自然方向的逆响应已由 [note 803](../notes/803-farey-exterior-block-has-logarithmic-gap-and-natural-schur-direction-stays-positive.md) 闭合；以下保留原候选推导，不再把近零模态作为活动障碍。

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确正权行式、Archimedean 相离核及一致有界压缩，[scratch 853](853-full-farey-bulk-archimedean-compression-tends-to-log2-candidate.md) 的内区对角极限，以及 [scratch 854](854-almost-full-farey-bulk-has-diverging-boundary-schur-feedback-candidate.md) 的内外边界流。以下新残差界与条件性谱推论尚待异源复核，留在 scratch。

## 命题

沿奇素数 \(p\to\infty\)，取 \(P=p-1\)、\(H=\log p\)、\(T=\log p\)、\(Q=\lfloor P/T\rfloor\)、\(\tau=\log(P/Q)\sim\log\log p\)。沿用 scratch 854 的全 Farey 主压缩 \(A_W=D_pI-C_p+E_p\)、内区 \(I=\mathcal F_Q\)、边界 \(R=\mathcal F_P\setminus I\) 以及向量 \(u_I,u_R\)，记 \(u=u_I+u_R\)、\(Z_Q=\|u_I\|^2\)。则
\[
\boxed{\quad
\frac{\|P_RA_Wu\|^2}{Z_Q}
\ll \frac{\log\log p}{\log p}+\frac1{\log^2p}=o(1).
\quad}\tag{1}
\]
若 \(A_R=P_RA_WP_R\succ0\)，则沿 \(u_I/\sqrt{Z_Q}\) 的精确 Schur 余量为
\[
\boxed{\quad
\frac1{Z_Q}\left(
\langle u_I,A_Wu_I\rangle
-\langle A_{RI}u_I,A_R^{-1}A_{RI}u_I\rangle
\right)
=c_*-\frac1{Z_Q}\langle h_R,A_R^{-1}h_R\rangle+o(1),
\quad h_R=P_RA_Wu,
\quad c_*=1+\gamma_E-\log\pi+\log2>0.
\quad}\tag{2}
\]
因此若 \(A_R\succeq g_pI\) 且 \(g_p\gg(\log\log p)/\log p\)，式 (1)--(2) 给该特定内区向量的 Schur 余量 \(c_*+o(1)>0\)。反过来，若该向量的 Schur 余量沿某子序列非正，而 \(A_R\succ0\)，则必有
\[
\boxed{\qquad \lambda_{\min}(A_R)
\ll \frac{\log\log p}{\log p}.\qquad}\tag{3}
\]
这是**必要条件**，不证明边界块存在如此小的特征值；它不排除其他内区向量或完整旧奇空间的负方向。

## 算术残差

note 791 式 (14) 写成
\[
\frac{(C_pv)_{a/b}}{v_{a/b}}
=2\log P+e(P/a)+e(P/b)-\Lambda(a)\mathbf1_{b=1},
\quad e(t)=\sum_{n\le t}\frac{\Lambda(n)}n-\log t=O(1).
\]
因此 \((D_pI-C_p)v\) 在 \(R\) 的非轴坐标逐点至多为 \(O(v_x)\)，在轴 \(b=1\) 另有 \(\Lambda(a)v_{a/1}\)，其中 \(Q<a\le P\)。用 \(Z_P-Z_Q\ll H\tau\)、\(Z_Q\asymp H^2\)，以及 \(\Lambda(a)\le\log a\le H\) 与 Mertens 估计，得到
\[
\sum_{Q<a\le P}\frac{\Lambda(a)^2}{a}
\le H\bigl(\mathfrak M(P)-\mathfrak M(Q)\bigr)
\ll H(\tau+1),
\]
可得
\[
\frac{\|P_R(D_pI-C_p)u\|^2}{Z_Q}
\ll\frac\tau H.
\tag{4}
\]
这里无需把素数与高次素数幂分开。

## Archimedean 内外块

内区任一物理中心与全 Farey 中另一中心的对数距离至少 \(d_0\gg(Qp)^{-1}\)：若两中心的有理标签不同，交叉相乘后的两个整数不同且各至多 \(Qp\)。全部 Farey 物理中心彼此相距至少 \(2\Delta\)，\(\Delta\asymp p^{-2}\)。按距离排序，note 791 式 (12) 对任一内区行给
\[
\sum_{\text{外区中心}}|E_p(x,y)|
\ll\Delta^3\left(d_0^{-3}+\Delta^{-1}d_0^{-2}\right)
\ll (Q/p)^2=O(T^{-2}).
\tag{5}
\]
全 Farey 列绝对行和由 note 791 的全局 Schur 证明为 \(O(1)\)。矩形 Schur 检验及 polar 秩一范数 \(O(p^{-3})\) 因而给
\[
\boxed{\quad\|P_RE_pP_I\|_{\rm op}\ll T^{-1}.\quad}\tag{6}
\]
注意式 (5) 对内区与外区的**不同**物理中心求和；自对角 \(\log2\) 不跨块。再由 \(\|E_p\|=O(1)\)、\(\|u_R\|^2/Z_Q\ll\tau/H\)，
\[
\frac{\|P_RE_pu\|}{\sqrt{Z_Q}}
\le\|P_RE_pP_I\|+\|E_p\|\frac{\|u_R\|}{\|u_I\|}
\ll T^{-1}+\sqrt{\tau/H}.
\tag{7}
\]
式 (4)、(7) 证明 (1)。

## Schur 恒等式与符号

若 \(A_R>0\)，令 \(g=A_{RI}u_I\)、\(h_R=g+A_Ru_R=P_RA_Wu\)。在 \(R\) 上完成平方，得到**精确**等式
\[
\langle u_I,A_Wu_I\rangle-\langle g,A_R^{-1}g\rangle
=\langle u,A_Wu\rangle-\langle h_R,A_R^{-1}h_R\rangle.
\tag{8}
\]
scratch 854 式 (1a) 给 \(\langle u,A_Wu\rangle/Z_Q=c_*+o(1)\)，故 (8) 给 (2)。由 (1) 与 \(A_R\succeq g_pI\)，
\[
0\le\frac{\langle h_R,A_R^{-1}h_R\rangle}{Z_Q}
\le\frac{\|h_R\|^2}{g_pZ_Q}
\ll\frac{\tau/H}{g_p}.
\]
若 \(g_p\gg\tau/H\)，右侧趋零。若 (2) 左侧非正，则 \(\langle h_R,A_R^{-1}h_R\rangle/Z_Q\ge c_*/2\) 对充分大 \(p\) 成立；结合同一上界与 \(g_p=\lambda_{\min}(A_R)\) 即得 (3)。\(\square\)

## 边界

式 (1) 把关键不确定性从“大交叉块范数”收缩为边界近零模态是否与真实残差 \(h_R\) 对齐。只有证明 \(A_R\) 的相应逆响应为 \(o(1)\)，才能把自然正权方向的正常数保留下来；其他 Farey 轮廓、\(W_p^\perp\)、moving-\(N\) signed covariance 及 RH 仍未判定。
