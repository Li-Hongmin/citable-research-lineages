# 移动平方筛下线性对数频宽的 Weil 格正隙候选

日期：2026-10-03。把 [scratch 868](868-growing-h1-log-profiles-under-moving-square-sieves.md) 的 \(J\asymp\sqrt{\log p}\) 候选推进到 \(J\asymp\log p\)。依赖 [note 862](../notes/862-arbitrary-moving-prime-square-sieves-retain-maximal-weil-gap.md) 的常数轮廓正隙与统一筛计数、[note 864](../notes/864-moving-square-sieve-log-profiles-have-finite-dimensional-weil-gap.md) 的完整 Weil 格分解。**新频宽与双线性误差尚待异源复核，留在 scratch；它不证明全尺度局部 Weil 正性或 RH。**

## 命题

沿 note 864 的奇素数 \(p\to\infty\) 取 \(M=(p^2-5)/4\)、\(L=\log M\)、固定 \(0<c<4\) 和固定实单位槽轮廓 \(\varphi\)。任取可随 \(p\) 变化的素数平方筛 \(\mathcal P_p\)，令 \(T_p(n)=\prod_{q\in\mathcal P_p}\mathbf1_{q^2\nmid n}\)，\(\alpha_p\ge\alpha_0=\zeta(2)^{-1}\)，\(\delta=46/25-\log(2\pi)>0\)。

存在仅依赖 \(c,\varphi\) 的 \(\kappa>0,p_0\)，使对所有奇素数 \(p\ge p_0\)、所有这些筛，以及所有非零三角多项式
\[
g(t)=\sum_{|j|\le J}c_j e^{2\pi ijt},
\qquad 0\le J\le\kappa L,
\tag{1}
\]
note 864 的完整局部 Weil 试函数 \(f_{p,g}\) 都满足
\[
\boxed{\qquad W_{p,g}>0,\qquad
Q_W^{\log p}[f_{p,g}]\ge\delta\alpha_0/16>0.\qquad}
\tag{2}
\]
因此同一移动筛全族中可同时允许维数 \(2\lfloor\kappa L\rfloor+1\asymp\log p\) 的对数轮廓空间，且坐标可随 \(p\) 变化。这里仍只有特定最大整数格的一族试函数，而非完整算子下界。

## 两个统一解析引理

写 \(t_n=\log n/L\)。note 862 的 \(A_p(x)=\sum_{n\le x}T_p(n)=\alpha_px+O(\sqrt x)\) 对全部移动筛有同一隐常数。对任意绝对连续的 \(F:[0,1]\to\mathbb C\)，Abel 求和直接给
\[
\left|\sum_{n\le M}\frac{T_p(n)}nF(t_n)
-\alpha_pL\int_0^1F(t)dt\right|
\le C\left(\|F\|_\infty+
\int_0^1e^{-Lt/2}|F'(t)|dt\right).
\tag{3}
\]
具体地，计数误差乘 \(F(\log x/L)/x\) 的端点为 \(O(\|F\|_\infty)\)；微分产生 \(x^{-3/2}|F|\) 与 \(x^{-3/2}|F'|/L\)。后者作 \(x=e^{Lt}\) 变量替换正好给式 (3) 的指数权。这一权不能粗略去掉：它是频宽改进的来源。

令 \(A(x)=\sum_{2\le k\le x}\Lambda(k)/k\)。经典素数定理的零自由区误差 \(\psi(x)=x+O(xe^{-b\sqrt{\log x}})\) 加 Abel 求和，以及 note 857 已核定的常数项 \(-\gamma\)，给
\[
R(u):=A(e^u)-u+\gamma,
\qquad \|R\|_\infty+\int_0^\infty|R(u)|du<\infty.
\tag{4}
\]
确实若 \(E(x)=\psi(x)-x\)，则
\(R(\log x)=E(x)/x-\int_x^\infty E(v)v^{-2}dv\)；右侧在 \(u=\log x\) 上至多为多项式乘 \(e^{-b'\sqrt u}\)，故可积。用 \(u=\log k\) 对 \(A(e^u)\) 作 Stieltjes 分部积分，令 \(U=L(1-t)\)，便得对任意 \(g\in C^1[0,1]\)
\[
\sum_{2\le k\le e^U}\frac{\Lambda(k)}k
g\!\left(t+\frac{\log k}{L}\right)
=L\int_t^1g(s)ds-\gamma g(t)
+R(U)g(1)-\frac1L\int_0^UR(u)g'(t+u/L)du.
\tag{5}
\]
在 \(U=0\) 时 \(R(0)=\gamma\)，所以端点也精确成立。特别地，(4)--(5) 的余项相对 \(L\int_t^1g\) 一致至多
\[
C\bigl(\|g\|_\infty+L^{-1}\|g'\|_\infty\bigr).
\tag{6}
\]

## 线性频宽下的二次型与交叉项

把 (1) 唯一写成 \(g=a+h\)，其中 \(a=\int_0^1g\) 且 \(\int_0^1h=0\)。置 \(R_h=\|h\|_2\)、\(B_J=\sqrt{2J+1}\)。Fourier Cauchy--Schwarz 与 Bernstein 不等式给
\[
\|h\|_\infty\le B_JR_h,
\qquad
\|h'\|_\infty\le2\pi J B_JR_h.
\tag{7}
\]
以下所有常数对 \(p,J,\mathcal P_p\) 一致，只依赖固定的 \(c,\varphi\)。先取固定小 \(\kappa_0>0\)，限制 \(J\le\kappa_0L\)。把 (3) 分别用于 \(|h|^2\)、\(\overline a h\)，利用 \(\int_0^1e^{-Lt/2}dt\le2/L\)，得
\[
W(h)=\alpha_pL R_h^2+O(J_+R_h^2),
\qquad
W(a,h)=O(B_J|a|R_h),
\quad J_+=J+1.
\tag{8}
\]
其中 \(|h|^2\) 的误差为 \(O((J_++J_+^2/L)R_h^2)\)，而 \(\overline a h\) 的误差为 \(O(B_J(1+J/L)|a|R_h)\)。故缩小 \(\kappa_0\) 后，\(W(g)\asymp L(|a|^2+R_h^2)\)，并特别有 \(\sum T_p(n)|h(t_n)|/n\ll LR_h\)。

令 \(\mathscr Q(g)=W(g)Q_W^{\log p}[f_{p,g}]\) 为未归一化的完整 Weil Hermitian 形式，\(\mathscr Q(a,h)\) 为其极化双线性项。下面逐项使用 note 864 式 (6)--(8) 与完整 Weil 分解，证明
\[
\boxed{\quad
|\mathscr Q(h)-\alpha_pL^2R_h^2|\le CLJ_+R_h^2,
\qquad
|\mathscr Q(a,h)|\le CLB_J|a|R_h.
\quad}
\tag{9}
\]

同槽 Fourier 项为 \((L+O(1))W(g)\)。由 (8)，其 \(h,h\) 误差相对 \(\alpha_pL^2R_h^2\) 为 \(O(LJ_+R_h^2)\)，\(a,h\) 项为 \(O(LB_J|a|R_h)\)。

素数幂整除矩阵先按 note 864 式 (7)--(8) 将 \(T_p(kn)\) 换为 \(T_p(n)\)。逐项保留两个因子而不使用平方范数极化，\(h,h\) 替换成本至多 \(CL\|h\|_\infty^2\ll LJ_+R_h^2\)；\(a,h\) 成本至多 \(CL|a|\|h\|_\infty\ll LB_J|a|R_h\)。替换后对内层用 (5)--(6)：\(h\) 的内层误差是 \(O(B_JR_h)\)，常数 \(a\) 的内层误差是 \(O(|a|)\)。与 (8) 的外层调和质量合并，误差在 \(h,h\) 为 \(O(LB_JR_h^2)\)，在 \(a,h\) 为 \(O(LB_J|a|R_h)\)。

内层主项需要把
\(F_g(t)=\overline{g(t)}\int_t^1g(s)ds\)
代入 (3)。对 \(h,h\)，有 \(\|F_h\|_\infty\ll B_JR_h^2\)、\(\|F_h'\|_\infty\ll(JB_J+J_+)R_h^2\)；对 \(a,h\) 则分别为 \(O(B_J|a|R_h)\)、\(O(JB_J|a|R_h)\)。因此 (3) 的误差在两种情形分别为 \(O(B_JR_h^2)\)、\(O(B_J|a|R_h)\)，乘内层的 \(L\) 后仍在 (9) 范围内。连续主项 \(2\alpha_pL^2\operatorname{Re}\int_{t<s}\overline g(t)g(s)dtds=\alpha_pL^2|\int g|^2\)，故在 \(h,h\) 及 \(a,h\) 上均为零。

普通跨槽核用 note 857 的绝对和 \(O(ML)\)；乘 \(\ell\asymp M^{-1}\) 后，\(h,h\) 至多 \(CL\|h\|_\infty^2\ll LJ_+R_h^2\)，\(a,h\) 至多 \(CL|a|\|h\|_\infty\ll LB_J|a|R_h\)。中心替换误差的 \(O(\ell^2M^2)\) 因子更小，按同样两个因子界支付。

极点项用 note 864 的两个线性矩 \(A_g=\sum T_p(n)g(t_n)/n\)、\(B_g=\sum T_p(n)g(t_n)\)。由 (3)、\(\int h=0\) 得 \(|A_h|\ll B_JR_h\)，而 \(|B_h|\le M B_JR_h\)；常数方向有 \(|A_a|\ll L|a|\)、\(|B_a|\ll M|a|\)。由于极点前因子 \(m_+m_-=O(\ell)=O(M^{-1})\)，它的 \(h,h\) 项为 \(O(J_+R_h^2)\)，\(a,h\) 项为 \(O(LB_J|a|R_h)\)。合并即得 (9)。

## 常数方向与均值零方向的联合支付

note 862 的任意移动筛常数轮廓正隙与 (8) 给充分大 \(p\) 时
\[
\mathscr Q(a)\ge (\delta\alpha_0/4)L|a|^2.
\tag{10}
\]
先固定足够小的 \(\kappa\le\kappa_0\)。由 (9) 与 \(\alpha_p\ge\alpha_0\)，当 \(J\le\kappa L\) 且 \(L\) 足够大时，
\[
\mathscr Q(h)\ge(\alpha_0/2)L^2R_h^2.
\]
交叉项用 Young 不等式：
\[
2|\mathscr Q(a,h)|
\le(\alpha_0/4)L^2R_h^2
+(4C^2/\alpha_0)J_+|a|^2.
\]
再次缩小 \(\kappa\)，使第二项对大 \(L\) 不超过 \((\delta\alpha_0/8)L|a|^2\)。于是
\[
\mathscr Q(a+h)\ge
(\delta\alpha_0/8)L|a|^2
+(\alpha_0/4)L^2R_h^2.
\]
由 (8) 的 \(W(g)\le2L(|a|^2+R_h^2)\)，得到 (2)。\(\square\)

## 边界

改进来自两个实际衰减：筛计数误差在对数坐标中带 \(e^{-Lt/2}\)，而加权素数定理的余项在 \(u=\log k\) 上可积。把它们直接换成无权 \(H^1\) 范数会损失一个 \(J\) 因子，退回 scratch 868 的 \(J\asymp\sqrt L\) 范围。

此证明使用的统一范数近似在 \(J\gg L\) 时确实失效。取均值零的归一化 Dirichlet 核
\[
h_J(t)=\frac1{\sqrt{2J}}\sum_{1\le|j|\le J}e^{2\pi ijt},
\qquad \|h_J\|_2=1,\quad |h_J(0)|^2=2J.
\]
任意移动平方筛都有 \(T_p(1)=1\)，故 \(W(h_J)\ge2J\)。当 \(J/L\to\infty\) 时，这与 \(W(h_J)=\alpha_pL+o(L)\) 不相容。这只标出当前均匀求积机制的自然尺度，不判定超线性频宽上的 Weil 形式符号。

式 (2) 仍不控制任意槽系数、素数一次幂符号、无限补空间 Schur 反馈。[scratch 875](875-half-integer-companion-retains-maximal-weil-grid-schur-feedback.md) 给出最大整数格外的半整数伴随方向，其 prime-shift 交叉为固定非零量级。故这里没有证明全尺度局部 Weil 正性或 RH。
