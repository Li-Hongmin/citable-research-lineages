# 候选：分子环边界平方项支付中间高斜率走廊

日期：2026-09-30。待独立复核。沿 notes 803、807、809、810、813、818 的记号，令奇素数 \(p\to\infty\)，\(P=p-1\)、\(H=\log p\)、\(Q=\lfloor P/H\rfloor\)。固定 \(\alpha>1\) 与 \(r>2/(1-3/\pi^2)\)，令 \(S=\lfloor P/H^\alpha\rfloor\)、\(\gamma_r=1-2/r-3/\pi^2>0\)，并取
\[
F_{S,Q}^{(2)}=\operatorname{span}\{\psi_{a/b}:S<a\le Q,\ 1\le b\le a/2,\ (a,b)=1\}.
\]
则完整旧奇 Weil 常值槽主压缩满足
\[
\boxed{\quad
P_{F_{S,Q}^{(2)}}A_{p^2,-}P_{F_{S,Q}^{(2)}}\succeq(H-o_\alpha(H))I,
\qquad
P_{F_{S,Q}^{(2)}\oplus E_r}A_{p^2,-}P_{F_{S,Q}^{(2)}\oplus E_r}
\succeq(\gamma_r-o_{\alpha,r}(1))H I.
\quad}\tag{1}
\]
加入全部 Farey 阶跃偶极 \(W_p\) 后仍有 \((c_0-o(1))I\) 谱隙。这里 \(E_r=\operatorname{span}\{\psi_{c/d}:c>Q,c/d>r\}\)，\(c_0=1+\gamma_E-\log\pi+\delta_0>0\)。\(\alpha\) 不受 note 818 的 \(\alpha<3\) 限制；代价是这里只取斜率 \(a/b\ge2\)。

## 单个分子环的边界能量

置 \(A_0=Q\)、\(A_{j+1}=\lfloor A_j/2\rfloor\)，直到首次 \(A_{m}\le S\)，将末端下界改为 \(S\)。于是 \(m=O_\alpha(\log H)\)，且区间 \((\max(S,A_{j+1}),A_j]\) 不交并覆盖 \((S,Q]\)。令
\[
B_j=\operatorname{span}\{\psi_{a/b}:\max(S,A_{j+1})<a\le A_j,\quad b\le A_{j+1},\quad(a,b)=1\}.
\tag{2}
\]
则 \(F_{S,Q}^{(2)}\subset\bigoplus_{j<m}B_j\)，因为 \(b\le a/2\le A_j/2\) 强制 \(b\le A_{j+1}\)。

沿 note 807 式 (5)、(16)--(17)，设 \(v_{a/b}=(ab)^{-1/2}\)，\(\widetilde L^-=\operatorname{diag}(\widetilde r)-C^-\succeq0\)，其中带符号平方和对应的根轴缺边以 \(+\Lambda(a)\mathbf1_{b=1}\) 对角补回，且
\[
D_pI-C^-=\widetilde L^-+\operatorname{diag}(V),\qquad V\ge-M
\tag{3}
\]
对所有 Farey 槽成立。若 \(x=a/b\in B_j\)，每个素数幂 \(n\mid a\) 将 \(x\) 经分子除法送到既约对 \((a/n,b)\) 的大于一方向；其新分子 \(\max(a/n,b)\le A_{j+1}\)，故离开 \(B_j\)。除 \(b=1,n=a\) 的根轴缺边外，此边在 \(\widetilde L^-\) 的边界平方和中支付
\[
c_n\frac{v_y}{v_x}|f_x|^2=\Lambda(n)|f_x|^2.
\]
缺边由 (3) 所述的正对角精确补回。因为 \(\sum_{n\mid a}\Lambda(n)=\log a\)，对 \(B_j\) 上任意系数都有
\[
P_{B_j}\widetilde L^-P_{B_j}\succeq(\log(A_j/2))I.
\tag{4}
\]
note 807 的正异臂 Archimedean 矩阵在全部环的联合空间一次丢去；note 809 在整个 \(I_Q\) 上给 \(\|N\|+2\|h\|^2=O(H^{-1})\)。因此每环真实对角下界至少
\[
\log(A_j/2)-O(1)\ge\log S-O(1)=H-\alpha\log H-O(1).
\tag{5}
\]

## 环间交叉与外区

若 \(i<j\)，则 \(B_i\) 的高分子坐标落在 \(U_i=(A_{i+1},A_i]\)，而 \(B_j\) 的两个整数坐标均 \(\le A_{i+1}\)。从较小环到较大环的单坐标素数幂边只能将一个整数坐标送入 \(U_i\)。note 803 的反对称有序对等距折叠与全图 \(O(\log H)\) 跨指数零点余项给
\[
\|C^-_{B_iB_j}\|\le\sqrt2\,\|K_{U_i,[1,A_{i+1}]}\|+O(\log H).
\tag{6}
\]
取权 \(v_n=n^{-1/2}\)。输出 \(u\in U_i\) 的加权行和至多 \(\log u\le H\)；输入 \(t\le A_{i+1}\) 的反向加权行和至多
\(M(A_i/t)-M(A_{i+1}/t)\le\log(A_i/A_{i+1})+O(1)=O(1)\)。矩形 Schur 检验故给
\[
\|K_{U_i,[1,A_{i+1}]}\|=O(\sqrt H),\qquad
\|C^-_{B_iB_j}\|=O(\sqrt H).
\tag{7}
\]
注意本估计只需输出高坐标所在的**一个二进制环**，不随较小环的位置增长。非算术同臂核与 polar 在整个 \(I_Q\) 上分别有 \(O(H^{-1})\) 范数。由于 \(m=O_\alpha(\log H)\)，由 (5)--(7) 对块算子作标量行和，得到
\[
P_{\bigoplus B_j}A_{p^2,-}P_{\bigoplus B_j}
\succeq\bigl(H-O_\alpha(\sqrt H\log H+\log H)\bigr)I
=(H-o_\alpha(H))I.
\tag{8}
\]
取子空间即得 (1) 第一式。

note 813 式 (7)--(10) 对任意 \(I_Q\) 子空间到 \(E_r\) 的真实算术交叉给 \(O(\sqrt{H\log H})=o(H)\)；notes 809--811 给非算术交叉 \(O_r(1)\)。note 810 给 \(E_r\) 对角下界 \((\gamma_r-o(1))H\)，且其正异臂 Archimedean 矩阵与前文在联合空间一次丢去。因此两个线性对角块和 \(o(H)\) 交叉给 (1) 第二式。note 806 对全部常值槽与 \(W_p\) 的混合范数为 \(O(1)\)，note 804 给 \(W_p\) 下界 \((c_0-o(1))I\)，故加入阶跃后只损失 \(O(H^{-1})\)。\(\square\)

## 边界

式 (1) 只覆盖中间和上分子内区中斜率至少 2 的槽，未覆盖 \(1<a/b<2\) 的近对角槽，也未与 \(a\le S\) 的深区作共同 Schur 预算。它不处理外区低斜率、非恒定轮廓、无限维补空间或 moving-\(N\) Möbius signed covariance。
