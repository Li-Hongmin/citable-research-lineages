# 有理中心平均与加权删点给出锥外素数槽 Schur 响应（候选，待异源复核）

日期：2026-10-01。沿用 [scratch/892](892-upper-prime-dilates-leak-linearly-outside-every-polynomial-rational-cone.md) 的根、素数槽、碰撞删除和真实算术列；单槽闭形式及相离核见 [note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md)，素数平移和奇反射的符号见 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md)。这里计算该素数补块自己的能量及其逆，不假定完整旧奇算子正定。

## 命题

令 \(X\to\infty\) 沿实数，\(H=\log X\)、\(k=X^2\)、\(w=\frac12\log(1+X^{-2})\)，并令
\[
\mathcal G_X^\circ=\left\{n/b:\ n,b\in\mathbb Z_{>0},\quad X^{3/2}/8<n<X^{3/2}/4,\quad
\sqrt X/2<b<\sqrt X,\quad(n,b)=1\right\}.
\]
对每个 \(y\in\mathcal G_X^\circ\) 和整数 \(1\le B\le X^{1/5}\)，取 scratch/892 的素数槽空间 \(W_{y,B}\)，其中被删除的素数既不与有理锥相交，也不产生根的其他素数幂平移。存在**与 \(B\) 无关**的集合 \(\mathcal G_X^{\rm good}\subset\mathcal G_X^\circ\)，满足
\[
|\mathcal G_X^\circ\setminus\mathcal G_X^{\rm good}|
\ll X^2/\sqrt H,
\tag{1}
\]
对每个良好 \(y\)，再从 \(W_{y,B}\) 中删去同一组与 \(B\) 无关的高反射负载素数槽，得到 \(W'_{y,B}\subset W_{y,B}\)。这一步删除的根列平方质量至多 \(1\)。对所有良好 \(y\) 和上述全部 \(B\)，真实旧奇 Weil 闭形式在 \(W'_{y,B}\) 上的压缩 \(B'_{y,B}:=A_{X^2,-}|_{W'_{y,B}}\) 满足
\[
\boxed{\quad B'_{y,B}=2H I+O_{\rm op}(\sqrt H),\qquad
B'_{y,B}\succ0.\quad}
\tag{2}
\]
令 \(f'_{y,B}\) 是根 \(e_{y,1}\) 到 \(W'_{y,B}\) 的真实形式列，则对应的**真实受限 Schur 扣款**为
\[
\boxed{\quad
\langle f'_{y,B},(B'_{y,B})^{-1}f'_{y,B}\rangle
=\left(\frac{11}{64}+o(1)\right)H.
\quad}
\tag{3}
\]
式 (2)--(3) 的误差对良好 \(y\) 和全部 \(B\) 一致。特别地，\(\mathbb C e_{y,1}\oplus W'_{y,B}\) 的压缩严格正，根枢轴为 \((117/64+o(1))H\)。这里**不声称未经加权删点的整个 \(W_{y,B}\) 正定**，也没有估计它与有理锥其余槽或完整正交补的交叉。

## 素数列与非反射能量

记
\[
\mathcal P_X=\{p\text{ prime}:X^{5/4}\le p\le X^{3/2}\},
\quad c_p=\frac{\log p}{\sqrt p},\quad z_p=p/y,
\]
并以 \(\mathcal P_{y,B}^\circ\subset\mathcal P_X\) 表示 scratch/892 删除后留下的素数。各单位奇常值槽 \(e_{z_p}\) 正交。其证明给出一致的
\[
\sum_{p\in\mathcal P_{y,B}^\circ}c_p^2
=\left(\frac{11}{32}+o(1)\right)H^2,
\qquad f_{y,B}=(c_p)_{p\in\mathcal P_{y,B}^\circ}+r_{y,B},
\quad\|r_{y,B}\|_2=o(1).
\tag{4}
\]
第二式中的两次半权配对均为正；其他根算术平移已按 scratch/892 式 (5) 删除。

不同素数 \(p,q\in\mathcal P_X\) 的同臂算术块为零。若素数幂 \(s\ge2\) 的平移使两槽相交，则 \(|\log(sp/q)|<w\) 或反向，故 \(|sp-q|<q(e^w-1)<1\)。整数性强迫 \(q=sp\)，与 \(p,q\) 都是素数矛盾；\(p=q\) 时亦无 \(s\ge2\) 自边。note 790 式 (4)--(5) 对常值轮廓的内部项为 \(1\)，而 \(\log(1/w)=2H+\log2+o(1)\)，故每个单位奇槽的 Archimedean 自能量为 \(2H+O(1)\)。对于异槽同臂，相离核 \(K(d)\ll d^{-1}+1\) 及 \(q\le X^{3/2}\) 给出绝对行和
\[
\ll wX^{3/2}\sum_{1\le m\le X^{3/2}}m^{-1}
=O(HX^{-1/2})=o(1).
\tag{5}
\]
异臂中心距至少 \(2\log(2X^{1/4})\)，故其行和 \(O(wX^{3/2}X^{-1/4})=o(1)\)。负秩一 polar 块的范数至多
\[
2\sum_{p\in\mathcal P_X}|\langle s_k,e_{z_p}\rangle|^2
\ll w\sum_{p\in\mathcal P_X}\frac p y=O(1).
\tag{6}
\]
所以除异臂算术反射之外，\(W_{y,B}\) 的整个压缩为 \(2H I+O_{\rm op}(1)\)，对所有 \(y,B\) 一致。

## 反射三元组的单次命中

在奇槽坐标中，素数幂 \(s\) 的异臂反射矩阵元为 \(+c_s\) 乘一个 \([0,1]\) 中的槽交叠系数，其中 \(c_s=\Lambda(s)/\sqrt s\)。它非零仅当
\[
\left|\log\frac{pq}{s y^2}\right|<w.
\tag{7}
\]
对**全部** \(p,q\in\mathcal P_X\) 构造非负的逐边上界矩阵和根列加权质量
\[
\widetilde K_y(p,q):=
\sum_{\substack{s\ge2\\s\text{ 为素数幂}}}
c_s\,\mathbf1_{\{|\log(pq/(s y^2))|<w\}},
\qquad
M_y:=\sum_{p,q\in\mathcal P_X}c_pc_q\widetilde K_y(p,q).
\tag{8}
\]
实际异臂算术块按条目受 \(\widetilde K_y\) 控制；\(M_y\) 只是其**根列加权总质量**，不能直接当作算子范数。若 (7) 成立，则 \(s<65X\)。固定 \((p,q,s)\)，置 \(t=\sqrt{pq/s}\)；允许的 \(y\) 落在 \((t e^{-w/2},t e^{w/2})\)。只要此区间碰到 \(\mathcal G_X^\circ\)，其长度至多
\[
\frac X2(e^w-1)<\frac1X
\tag{9}
\]
（\(X\) 充分大）。另一方面，不同既约 \(y=n/b,y'=n'/b'\) 满足
\[
|y-y'|\ge\frac1{bb'}>\frac1X.
\tag{10}
\]
故**每个反射三元组至多命中一个原始有理中心**。Chebyshev 界及分部求和给
\[
\sum_{y\in\mathcal G_X^\circ}M_y
\le\left(\sum_{p\in\mathcal P_X}c_p\right)^2
\sum_{s\le65X}c_s
\ll (X^{3/4})^2X^{1/2}=X^2.
\tag{11}
\]
Möbius 反演计数既约对给
\[
|\mathcal G_X^\circ|
=\frac{X^2}{16\zeta(2)}+O(X^{3/2}\log X).
\tag{12}
\]
取 \(\mathcal G_X^{\rm good}=\{y:M_y\le\sqrt H\}\)。由 (11)--(12) 和 Markov 不等式得 (1)。对每个这样的 \(y\) 和每个 \(p\in\mathcal P_X\)，定义加权行负载
\[
L_y(p):=\frac{(\widetilde K_y c)_p}{c_p}\ge0,
\qquad c=(c_p)_{p\in\mathcal P_X}.
\]
令 \(E_y=\{p:L_y(p)>\sqrt H\}\)。由于
\[
\sum_{p\in\mathcal P_X}c_p^2L_y(p)=M_y\le\sqrt H,
\qquad
\sum_{p\in E_y}c_p^2\le M_y/\sqrt H\le1,
\tag{13}
\]
这一删点不会改变 (4) 的平方质量主项。令
\(W'_{y,B}=\operatorname{span}\{e_{z_p}:p\in\mathcal P_{y,B}^\circ\setminus E_y\}\)。对留下的每一行，删去其他列只能降低正权行比，所以对实际非负反射块用权重 \(c_p\) 的 Schur 检验给
\[
\|K^{\rm reflect}_{y,B}|_{W'_{y,B}}\|_{\rm op}
\le\max_{p\notin E_y}\frac{(\widetilde K_y c)_p}{c_p}
\le\sqrt H.
\tag{14}
\]
由 (5)--(6)、(14) 得 (2)。

最后，(2) 的逆满足
\[
(B'_{y,B})^{-1}=(2H)^{-1}I+O_{\rm op}(H^{-3/2}).
\]
把 (4) 和 (13) 限制到 \(W'_{y,B}\) 后代入即得 (3)：平方质量仍为 \((11/32+o(1))H^2\)，主项为其除以 \(2H\)，其余为 \(o(H)\)。根自能量由同一单槽公式给 \(2H+O(1)\)；其异臂自反射若出现，则 \(s\asymp y^2\asymp X^2\)，唯一性和 \(c_s\ll H/X\) 使之为 \(o(1)\)，polar 自项也为 \(O(X^{-1})\)。所以二维块的根枢轴为 \((2-11/64+o(1))H= (117/64+o(1))H\)。\(\square\)

## 与非根有理锥槽的异臂算术交叉恰为零

这个接口还可无条件消去一类边。对任意 \(y,B\) 和锥内 \(r=a/b\ge5\)，有
\(a\le (y/2)b\le XB/4<X^{5/4}\le p\)。素数槽的上臂参数为
\(z_p=p/y\)，锥槽的上臂参数为 \(x_r=y/r\)，故两者的异臂反射乘积为
\(z_px_r=p/r=pb/a\)，与 \(y\) 无关。若某个素数幂 \(s\) 的反射使两槽相交，则
\[
\left|\log\frac{pb}{sa}\right|<w
\quad\Longrightarrow\quad
|pb-sa|<pb(e^w-1)
\ll X^{3/2}B/X^2=o(1).
\]
两边均为整数，故 \(sa=pb\)。由 \((a,b)=1\) 得 \(a\mid p\)，而
\(1<a<p\)，矛盾。因此 \(W_{y,B}\) 与 \(\mathscr V_{y,B}\) 中**全部非根槽**之间的异臂算术块精确为零，且对任意槽内轮廓成立。根 \(r=1\) 的异臂配对正是式 (4) 的 \(+c_p\)；在非根接口尚须控制同臂算术、相离 Archimedean 核及 polar 交叉。

## 边界

式 (3) 把 scratch/892 的线性形式交叉转化为几乎所有原始有理中心上的一个**经加权删点的**真实、正补块逆响应。它只涉及这一组素数槽；未经删点的整个 \(W_{y,B}\) 及有理锥与该素数块之间的同臂算术、非算术交叉和剩余无限维空间仍未支付。因此这里不推出完整旧奇空间正性、全尺度局部 Weil 正性或 RH。moving-\(N\) Möbius signed covariance 的真实算术门仍为 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (8)--(9)。
