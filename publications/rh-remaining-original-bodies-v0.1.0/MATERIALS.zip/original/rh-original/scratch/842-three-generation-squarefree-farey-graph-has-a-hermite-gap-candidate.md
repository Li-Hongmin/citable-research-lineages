# 三代平方自由 Farey 素数图的 Hermite 谱界仍给严格 Weil 谱隙（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确 Farey 算术图与有界 Archimedean 修正、[scratch 840](840-four-thirds-prime-farey-star-has-a-strict-logarithmic-weil-gap-candidate.md) 的素数平方质量，以及 [scratch 841](841-two-generation-four-thirds-farey-prime-graph-remains-positive-candidate.md) 的两代图。以下是第三代及一般固定层的直接范数界；尚待异源复核，留在 scratch。

## 命题

沿奇素数 \(p\to\infty\)，取 \(k=p^2\)、\(L=\log k\)、\(P=(p-1)/4\)。对 \(0\le j\le m\)，令 \(\mathcal S_j(p)\) 为由恰好 \(j\) 个互异素数 \(q\ge5\) 构成、乘积 \(n<P\) 的集合；\(\mathcal S_0(p)=\{1\}\)。定义
\[
V_p^{(m)}=\operatorname{span}\{w_{4n/3}:n\in\mathcal S_j(p),\ 0\le j\le m\}
\subset W_p.
\tag{1}
\]
对每个固定 \(m\)，令 \(J_{m+1}\) 为 \((m+1)\times(m+1)\) 的实对称三对角矩阵，其相邻层元素为
\((J_{m+1})_{j,j+1}=(J_{m+1})_{j+1,j}=\sqrt{j+1}\)（\(0\le j<m\)），其余为零。写 \(\lambda_{m+1}=\|J_{m+1}\|\)。则真实旧奇 Weil 压缩满足
\[
\boxed{\quad
\lambda_{\min}(P_{V_p^{(m)}}A_{p^2,-}P_{V_p^{(m)}})
\ge\left(1-\frac{\lambda_{m+1}}{2\sqrt2}\right)L-O_m(1).
\quad}
\tag{2}
\]
特别地，\(\lambda_4=\sqrt{3+\sqrt6}\)，所以**完整三代平方自由图**有
\[
\boxed{\quad
P_{V_p^{(3)}}A_{p^2,-}P_{V_p^{(3)}}
\succeq\left(1-\sqrt{\frac{3+\sqrt6}{8}}\right)L-O(1)
>0\quad(p\text{ 充分大}).
\quad}
\tag{3}
\]
若只用 (2) 的同一无符号层范数法，第四代的 \(\lambda_5=\sqrt{5+\sqrt{10}}>2\sqrt2\)，所以它首次不再给正主系数；这不说明第四代真实压缩有负谱。

## 精确平方自由层图

对每个标签 \(n\)，\(4n/3\) 已约分、分子小于 \(p\)。两个这样的分数之积为 \(16nn'/9\)，因为 \(3\nmid nn'\) 不可能为整数素数幂；自环同理。其比值为整数素数幂，当且仅当两个平方自由素数集合恰相差一个素数 \(q\)，此时边权为 \(c_q=\log q/\sqrt q\)。因此压缩后的算术矩阵只连接相邻因子层。记从第 \(j\) 层到第 \(j+1\) 层的加边算子为 \(B_j\)：
\[
(B_jf)(T)=\sum_{q\in T}c_q f(T\setminus\{q\}),
\qquad T\in\mathcal S_{j+1}(p),
\tag{4}
\]
其中若父节点不满足 \(n<P\) 则相应系数视为零（实际父节点自动满足，因为 \(q\ge5\)）。

设 \(S_p=\sum_{5\le q<P,\ q\text{ 素数}}c_q^2\)。对每个 \(T\) 在 (4) 使用至多 \(j+1\) 项的 Cauchy 不等式，再交换 \(T\) 与父节点的求和顺序，得到
\[
\begin{aligned}
\|B_jf\|^2
&\le(j+1)\sum_{T\in\mathcal S_{j+1}(p)}\sum_{q\in T}
c_q^2|f(T\setminus\{q\})|^2\\
&\le(j+1)S_p\|f\|^2.
\end{aligned}
\tag{5}
\]
故 \(\|B_j\|\le\sqrt{(j+1)S_p}\)，不需要任何素数之间的独立性假设。对分层向量 \(f=(f_0,\ldots,f_m)\)，记 \(z_j=\|f_j\|\)。对称性与 (5) 给
\[
|\langle f,C_pf\rangle|
\le2\sum_{j=0}^{m-1}\sqrt{(j+1)S_p}\,z_jz_{j+1}
\le\sqrt{S_p}\,\lambda_{m+1}\sum_{j=0}^m z_j^2.
\tag{6}
\]
因此 \(\|P_{V_p^{(m)}}C_pP_{V_p^{(m)}}\|\le\sqrt{S_p}\lambda_{m+1}\)。scratch 840 式 (4) 给 \(S_p=L^2/8+O(L)\)，所以 \(\sqrt{S_p}=L/(2\sqrt2)+O(1)\)。note 791 式 (6) 又给真实压缩 \(D_kI-C_p+E_p\)，其中 \(D_k=L+1-\gamma_E-\log\pi\)、\(\|E_p\|=O(1)\)；合并证明 (2)。

最后，\(J_4\) 的特征多项式为 \(t^4-6t^2+3\)，所以 \(\lambda_4=\sqrt{3+\sqrt6}<2\sqrt2\)，证明 (3)。\(J_5\) 的特征多项式为 \(t(t^4-10t^2+15)\)，故 \(\lambda_5=\sqrt{5+\sqrt{10}}>2\sqrt2\)。\(\square\)

## 边界

(3) 只覆盖固定的前三代平方自由素数标签与固定分母 \(3\)。第四代及其后、素数幂、其他分母和完整无限维正交补仍未控制；有限代正性不能外推为全尺度局部 Weil 正性或 RH。
