# 平滑观察小波去除 Haar 窗的高频幂次损失（待异源复核）

**后续校正（2026-10-01）：**[scratch/858](858-exact-bandpass-observation-removes-lower-frequency-leakage.md) 给出反模型证明草稿：式 (12) 虽是充分条件，但对单个 $H<Y^{1/4}$ 频带仍受带外低频固定幂泄漏；任意固定紧支撑平滑核都有此问题。单频带的精确匹配门应使用 scratch/858 的 Schwartz 带通核。式 (9) 关于**全部** dyadic 频带同时达标的陈述仍保留。

日期：2026-10-01。修正 [scratch/855](855-haar-bandpass-window-for-the-centered-three-channel-gate.md) 的方法选择：其 Haar 充分门在 $H=Y^{1/5}$ 时会额外要求控制 $h\asymp Y^{1/4}$ 的频率，代价达到固定幂。这里保留紧支撑的真实三通道 signed covariance，同时用平滑小波得到与全体 dyadic 频带目标相匹配的乘子。所有结论都是解析归约和反模型，未证明算术上界或 RH。

后续 [scratch/857](857-log-half-collar-payment-for-the-moving-k2-observation-tail.md) 只改善 $H\ge Y^{1/4}/\sqrt{\log Y}$ 的显式对数损失；note 847 已在该区间达到 $Y^{2+\varepsilon}$ 量级。本稿的小波算术门仍应聚焦 $H\le Y^{1/4-\delta}$ 的固定幂低频带。

## Haar 充分门严格强于本带目标

置 $M=2Y$、$H=\lfloor Y^{1/5}\rfloor$，令 $L$ 为 scratch/855 的偶数窗长。取非负非零 $\varphi\in C_c^\infty((1,2))$，并在一个周期内定义
\[
 a_m=\frac{\varphi(m/M)}M\cos(2\pi h_0m/M).
\tag{1}
\]
可以选择整数 $\tfrac12Y^{1/4}\le h_0\le Y^{1/4}$，使
$\operatorname{dist}(h_0L/M,\mathbb Z)\in[1/4,1/2]$：该区间上的 $h_0L/M$ 总长度 $\asymp Y^{1/20}\to\infty$，相邻格步长 $L/M=o(1)$。

Poisson 求和给 $\mathcal A_{h_0}=\sum_m a_me(-h_0m/M)\to\frac12\int\varphi>0$；而对 $|h|\asymp H$，$|\mathcal A_h|\ll_A h_0^{-A}$，对每个固定 $A$ 成立。因此 $H$ 频带能量比 $H^4/Y$ 小任意固定幂。另一方面，scratch/855 式 (4) 的 Haar 乘子在 $h_0$ 处满足
\[
 |B_{h_0}(1-e(-h_0L/M))|\gg M/h_0,
\]
所以 Parseval 给
\[
 \sum_{x\bmod M}|D_La(x)|^2
 \ge\frac1M|B_{h_0}(1-e(-h_0L/M))|^2|\mathcal A_{h_0}|^2
 \gg M/h_0^2\asymp Y^{1/2}.\tag{2}
\]
Haar 门却要求 $O(H^2Y^\varepsilon)=O(Y^{2/5+\varepsilon})$。此反模型在 $h_0\asymp Y^{1/4}$ 的频带只有 $O(1)$ 能量，与该频带的自然目标 $h_0^4/Y\asymp1$ 相容。故 Haar 门比目标频带**严格多要求至少 $Y^{1/10-o(1)}$**；scratch/855 的恒等式仍真，但式 (5d) 不宜被当作当前最便宜算术门。

## 一个显式紧支撑小波

取偶的非负函数 $\theta\in C_c^\infty((-1/100,1/100))$，$\int\theta=1$，令 $\phi=\theta*\theta$、$g=\phi'$。则 $g$ 为实奇函数，支撑于 $(-1/50,1/50)$，且按 $\widehat f(t)=\int f(u)e(-tu)du$ 有
\[
 \widehat g(t)=2\pi it\,\widehat\theta(t)^2.
\tag{3}
\]
因为 $|\widehat\theta(t)-1|\le2\pi |t|/100$，在 $1/2\le|t|\le4$ 上有 $|\widehat g(t)|\ge c_0>0$。令 $W=M/H$，对 $j\in\mathbb Z$ 置 $v_W(j)=g(j/W)$，并在 $\mathbb Z/M\mathbb Z$ 上定义
\[
 T_Wa(x)=\sum_jv_W(j)a_{x-j},\qquad
 G_W(h)=\sum_jv_W(j)e(-hj/M).
\tag{4}
\]
$v_W$ 只有 $O(W)$ 个非零项。由于 $g$ 为奇函数，
\[
 \sum_jv_W(j)=0,\qquad \sum_j(-1)^jv_W(j)=0
\tag{5}
\]
逐个 $W$ **精确成立**。Poisson 求和给
\[
 G_W(h)=W\sum_{k\in\mathbb Z}\widehat g(h/H+kW).
\tag{6}
\]
对 $H/2\le|h|\le4H$，非零别名随 $W\to\infty$ 快速消失，故 $|G_W(h)|\ge cW$。对 $q(h)=\min(h,M-h)$（$0\le h<M$），又有统一界
\[
 |G_W(h)|\ll W\frac{q(h)}H\quad(q(h)\le H),
 \qquad
 |G_W(h)|\ll_A W\left(\frac H{q(h)}\right)^A
 \quad(H\le q(h)\le M/2),\tag{7}
\]
任意固定 $A>0$ 均可取；第一式由 (5) 后逐项估计
$|e(-hj/M)-1|\ll |h j|/M$，第二式由 (6) 的 Schwartz 衰减给出。

周期 Parseval 立即给与目标匹配的充分条件：
\[
 \boxed{\quad
 \sum_h\eta(h/H)|\mathcal A_h|^2
 \ll_{g,\eta}\frac M{W^2}\sum_{x\bmod M}|T_Wa(x)|^2.
 \quad}\tag{8}
\]
因此 $\sum_x|T_Wa(x)|^2\ll_\varepsilon H^2Y^\varepsilon$ 足以支付 note 849 的 $H$ 频带。这仍是待证算术界。

与 Haar 不同，这个充分条件没有额外固定幂的高频泄漏。更精确地，若对**所有** dyadic $1\le K\le M/2$ 已有自然频带界
\[
 E_K:=\sum_{K\le q(h)<2K}|\mathcal A_h|^2\ll C K^4/M,
\tag{9}
\]
则 (7) 与 Parseval 给 $\sum_x|T_Wa(x)|^2\ll_g C H^2$。
证明在 $K\le H$ 时，每个 dyadic 贡献至多
$(W^2/M)(K/H)^2 E_K\ll C K^6/H^4$；在 $K\ge H$ 时取 (7) 的 $A>2$，贡献至多
$(W^2/M)(H/K)^{2A}E_K\ll C H^2(K/H)^{4-2A}$。两个 dyadic 级数均为 $O(CH^2)$，而 $h=0$ 因 (5) 没有贡献。故整族小波门与整族自然频带门在解析量纲上相匹配；这不提供任何一个未证的 $E_K$。

## 留下的真实算术协方差

令 $a_m=c(m)\psi(m/M)/m$，$c$ 为 note 849 式 (10)。小波自相关
\[
 Q_W(k)=\sum_jv_W(j)v_W(j+k)
\tag{10}
\]
支撑在 $|k|<W/25$，且 $|Q_W(k)|\ll W$；它的 Fourier 变换是 $|G_W(h)|^2\ge0$，而 $\sum_kQ_W(k)=0$。因此 $\sum_x|T_Wa(x)|^2=\sum_{m,n}a_m\overline{a_n}Q_W(m-n)$ 是一个紧支撑、保留符号的算术 Gram。由 note 849 式 (16)，$|m-n|\le H^3/\log^2(2Y)$ 的部分绝对值为 $O(H^2/\log Y)$。

把 $c_{\rm tri}$ 定义为 note 849 式 (29)，则
\[
 \sum_x|T_W(a-a^{\rm tri})(x)|^2
 \ll_g M/H^4+\log^2(2Y)=o(H^2),
 \qquad a_m^{\rm tri}=c_{\rm tri}(m)\psi(m/M)/m.\tag{11}
\]
证明把 $c-c_{\rm tri}=3+(-1)^{m+1}+q(m)$，$q$ 是高次素数幂项。
式 (5) 同时消去常数格与交替格的未加权项；$|w_{m+1}-w_m|\ll M^{-2}$ 和
$\sum_j|v_W(j)||j|\ll W^2$ 把两项加权余量逐 $x$ 界为
$O(W^2/M^2)$，平方后总计 $O(M/H^4)$。note 849 式 (33) 给
$\sum_m|w_mq(m)|\ll M^{-1/2}\log M$，而 $\|v_W\|_\infty\ll1$，故其卷积的平方和为 $O(\log^2M)$。合并得 (11)。

还可把待证门直接放在未加权的真实系数上。若
\[
 \sum_{M\le x\le2M+W}|T_Wc(x)|^2
 \ll_\varepsilon M^2H^2M^\varepsilon,
\tag{12}
\]
则 $\sum_x|T_Wa(x)|^2\ll_\varepsilon H^2M^\varepsilon$：写
$T_Wa(x)=w_xT_Wc(x)+\sum_jv_W(j)(w_{x-j}-w_x)c(x-j)$，第二项逐点
$O(W^2\log M/M^2)$，平方和 $O(M\log^2M/H^4)=o(H^2)$。在 (12) 中，由 (5) 精确消去 $c$ 的常数和奇偶背景，留下两个 von Mangoldt 尺度与 Möbius 的联合滑动算术和。高次素数幂还可在原始量级支付：其总质量为 $O(\sqrt M\log M)$，所以 $\|T_Wq\|_\infty\ll\sqrt M\log M$，在 $O(M)$ 个观察点上的平方和为 $O(M^2\log^2M)=o(M^2H^2)$。因此 (12) 在目标量级内也可只保留素数 $p$、倍素数 $2p$ 与 Möbius 三通道。式 (12) 是比 scratch/855 的硬窗门更贴近实际频带的下一项真实算术命题；仍无固定幂上界。
