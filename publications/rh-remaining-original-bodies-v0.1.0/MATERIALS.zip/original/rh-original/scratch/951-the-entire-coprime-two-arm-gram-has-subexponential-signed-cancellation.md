# 完整两臂 Gram 的互素层可单独达到次指数 signed 抵消

日期：2026-10-02。依赖 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的真实两臂核及格距估计、[note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 已核对的 Ramachandra 普通 Möbius 短和，以及 [scratch/950](950-the-coprime-layer-retains-the-complete-two-arm-negative-lobe.md) 式 (6)–(7) 的有限 Euler 因子恒等式。本稿尚未异源复核，保留在 `scratch/`。所证为整个乘子集合与两物理臂的**互素源层**，不把一个子块替代完整 moving-$N$ covariance；结果仍不足以支付固定幂内点，更不证明 RH。

## 命题

沿用 note 850 的 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$D=\lfloor M/(32H)\rfloor$、$\psi\in C_c^3((1,2))$、$\phi=\psi/x$、非负偶权 $\eta\in C_c^\infty$、$W(k)$、$\mathcal K_h(u)$ 与完整两臂 Gram $G_{u,v}$。置
\[
\mathfrak C_{\mathrm{cop}}=
\sum_{\substack{D<u,v<2M/3,\ u,v\text{ odd}\\(u,v)=1}}
\mu(u)\mu(v)G_{u,v},
\qquad V_M=(\log M/\log\log M)^{1/3}.                     \tag{1}
\]
这里 $u=v$ 自动不出现，因为 $u>D>1$。存在固定 $c>0$，使
\[
\boxed{\quad |\mathfrak C_{\mathrm{cop}}|
\ll_{\psi,\eta}e^{-cV_M}
\quad(Y^{1/5}\le H\le Y^{1/4}).\quad}                       \tag{2}
\]
更强地，令 $G_{u,v}^{(T,U]}$ 表示 $G_{u,v}$ 的乘子展开只保留
$T<|ku-\ell v|\le U$，其中 $0\le T<U\le M$ 可随 $M,H$ 任意变化，并将 (1) 中的 $G_{u,v}$ 换成它，记为 $\mathfrak C_{\mathrm{cop}}^{(T,U]}$。则
\[
\boxed{\quad
\sup_{0\le T<U\le M}|\mathfrak C_{\mathrm{cop}}^{(T,U]}|
\ll_{\psi,\eta}e^{-cV_M}.\quad}                         \tag{2a}
\]
互素源对无精确物理碰撞：若 $ku=\ell v$ 且 $(u,v)=1$，则 $u\mid\ell,v\mid k$，而 $u,v>D\gg H$、$k,\ell<64H$。所有活动位移又小于 $M$，所以 (2) 是 (2a) 的 $T=0,U=M$ 特例。特别地，把远端截为 $\min(U,M)$ 后，(2a) 直接覆盖 note 850 式 (18) 的完整互素留存环带。
这不依赖不同实际 gcd 层之间的抵消，且没有丢弃任何活动奇臂、偶臂或乘子。这里限制的是 Möbius 源 $\gcd(u,v)=1$；[scratch/870](870-full-three-channel-coprime-observation-gram-has-logarithmic-cancellation.md) 限制物理观察整数 $\gcd(m,n)=1$，两种分层不同。结合 scratch/950，源互素层内部同时存在常量级的负核瓣正负符号质量；式 (2) 只给它们及其余乘子、位移的联合次指数净界。

## 增长互素模数的任意短窗口

以下是承重的一阶估计。固定 $\epsilon=1/64$，置
$\theta=5/8+\epsilon=41/64$。对 $M^{7/10}\le X\le M$、
$1\le q\le M^{1/4}$，以及任意 $I=(x,x+L]\subset[X,2X]$、$0\le L\le X$，有某个固定 $c_0>0$ 使
\[
\left|\sum_{n\in I}\mu(n)\mathbf1_{(n,q)=1}\right|
\ll L e^{-c_0V_M}+X^\theta,                               \tag{3}
\]
常数一致于 $X,q,x,L$。证明使用 scratch/950 式 (6) 的逐点恒等式，写 $\mathcal S(q)=\{r:p\mid r\Rightarrow p\mid q\}$，并置
$E_\sigma(q)=\sum_{r\in\mathcal S(q)}r^{-\sigma}$。该稿式 (7) 给
\[
E_1(q)=\exp(o(V_M)),\qquad
E_\sigma(q)=M^{o(1)}\quad(0<\sigma<1),                      \tag{4}
\]
一致于此处的 $q$。把 $r$ 在 $R=X^{1/16}$ 处分开。对 $r\le R$，有 $x/r\asymp X/r\ge X^{15/16}\ge M^{21/32}$，note 851 式 (4) 以 $\varepsilon=1/24$ 给
\[
\sum_{m\in I/r}\mu(m)
\ll (L/r)e^{-c_1V_M}+(X/r)^{5/8}.                        \tag{5}
\]
将 (5) 对 $r\in\mathcal S(q)$ 求和，(4) 给
$O(Le^{-c_2V_M}+X^{5/8}M^{o(1)})$。对 $r>R$，平凡计数与 Rankin 界给
\[
\sum_{\substack{r\in\mathcal S(q)\\r>R}}\#(I/r)
\ll L R^{-1/2}E_{1/2}(q)
 +X^{1/8}E_{1/8}(q)
\ll L X^{-1/32}M^{o(1)}+X^{1/8}M^{o(1)}.                \tag{6}
\]
因为 $X\ge M^{7/10}$，第一项可吸收到 $Le^{-c_0V_M}$，其余两个多项式项都小于 $X^\theta$；适当缩小 $c_0$ 即得 (3)。该论证不引入模 $q$ 的 Dirichlet 特征，故不需要模数一致的 Dirichlet $L$ 零自由输入。

## 完整互素层的分层估计

对 (2a) 使用 $\mathbf1_{(u,v)=1}=\sum_{d\mid u,v}\mu(d)$，并取
$Z=\lfloor e^{V_M}\rfloor$。记 $\mathcal S_d^{(T,U]}$ 为 $d\mid u,v$ 的完整两臂双和，保留 $u,v$ 的原窗口、位移条件 $T<|ku-\ell v|\le U$ 以及**全部**活动 $k,\ell$。以下暂把它简写为 $\mathcal S_d$。则
\[
\mathfrak C_{\mathrm{cop}}^{(T,U]}=
\sum_{\substack{d\le Z\\d\text{ odd}}}\mu(d)\mathcal S_d
 +\sum_{\substack{d>Z\\d\text{ odd}}}\mu(d)\mathcal S_d.     \tag{7}
\]
当 $d\le Z$ 且 $\mu(d)\ne0$ 时，写 $u=da,v=db$，有
$\mu(u)\mu(v)=\mu(d)^2\mu(a)\mu(b)
\mathbf1_{(a,2d)=1}\mathbf1_{(b,2d)=1}$。
固定 $d,k,\ell,a$，设 $X=M/(\ell d)$ 与 $b_0=ka/\ell$。真正活动的 $b$ 落在 $[X,2X]$，再受源窗口截取；在这一集合上
\[
\frac1{M^2}W(k)W(\ell)
\phi(kda/M)\overline{\phi(\ell db/M)}
J_H\bigl(\ell d(b_0-b)\bigr)                             \tag{8}
\]
是对应的乘子项。由于 $\ell<64H$、$d\le Z=e^{V_M}=M^{o(1)}$，有 $X\ge M^{3/4-o(1)}\ge M^{7/10}$，而 $2d\le M^{1/4}$；因此 (3) 适用于 $b$ 的每个子窗口。

固定 $A>4$。令 $r=\ell d(b_0-b)$。对所有真实活动项，$kda/M,\ell db/M$ 都在 $\operatorname{supp}\phi\Subset(1,2)$，故 $|r|/M\le1-2\sigma_\psi$，其中 $\sigma_\psi>0$ 固定。Poisson 求和及其逐项微分为
\[
J_H(r)=H\sum_{m\in\mathbb Z}\widehat\eta(H(r/M+m)),\qquad
\frac d{db}J_H(r)=-\frac{H^2}{X}
\sum_{m\in\mathbb Z}\widehat\eta'(H(r/M+m)).
\]
$\eta,t\eta\in C_c^\infty$ 使 $\widehat\eta,\widehat\eta'$ 都有任意阶衰减；$m\ne0$ 的和在上述非别名区为 $O_A(H^{-A})$，可吸收进 $m=0$ 项的统一 majorant。因此
\[
|J_H(\ell d(b_0-b))|
\ll_A H(1+H|b-b_0|/X)^{-A},
\quad
\left|\frac d{db}J_H(\ell d(b_0-b))\right|
\ll_A \frac{H^2}{X}(1+H|b-b_0|/X)^{-A}.                 \tag{9}
\]
按 $|b-b_0|\asymp2^jX/H$ 分壳（中心壳取 $|b-b_0|\le X/H$）。位移条件等于 $T/(\ell d)<|b-b_0|\le U/(\ell d)$；它与每个壳及物理、源窗口相交后至多为四个区间，各长 $O(2^jX/H)$。此处把 $\phi$ 在 $[X,2X]$ 上零延拓为光滑权，不按它的非零集合另分区间。对每个区间的权 $w(b)=\overline{\phi(b/X)}J_H(\ell d(b_0-b))$，式 (9) 给
\[
\|w\|_\infty\ll_A H2^{-jA},\qquad
\operatorname{Var}(w)
\ll_A \frac{2^jX}{H}
\left(\frac H X+\frac{H^2}X\right)2^{-jA}
+H2^{-jA}
\ll_A H2^{-j(A-1)}.
\]
末项包含位移截断与源窗口的端点跳跃。式 (3) 对该区间每个前缀给
$O(2^jXH^{-1}e^{-c_0V_M}+X^\theta)$；离散分部求和后，该壳贡献至多
$O_A(H2^{-j(A-1)}(2^jXH^{-1}e^{-c_0V_M}+X^\theta))$。对 $j\ge0$ 求和得到
\[
\left|\sum_{\substack{b\text{ active},\ (b,2d)=1\\T<|kda-\ell db|\le U}}
\mu(b)\overline{\phi(\ell db/M)}
J_H\bigl(\ell d(b_0-b)\bigr)\right|
\ll H\left(\frac{X}{H}e^{-c_0V_M}+X^\theta\right).       \tag{10}
\]
对固定 $d,k$，活动 $a$ 的个数为 $O(M/(kd))$；若非空，$kd\le2M$，因此不需额外的 $+1$。记
$A_H=\sum_{k<64H}|W(k)|/k\ll\log^2(2H)$、
$B_{\theta,H}=\sum_{\ell<64H}|W(\ell)|/\ell^\theta
\ll H^{1-\theta}\log(2H)$。由 (8)--(10)，
\[
|\mathcal S_d|
\ll\frac{A_H^2}{d^2}e^{-c_0V_M}
 +\frac{H M^{\theta-1}A_HB_{\theta,H}}{d^{1+\theta}}
\ll \frac{\log^4(2M)e^{-c_0V_M}}{d^2}
 +\frac{H^{2-\theta}M^{\theta-1}\log^3(2M)}{d^{1+\theta}}. \tag{11}
\]
由于 $H\le Y^{1/4}\ll M^{1/4}$、$\theta=41/64$，
\[
H^{2-\theta}M^{\theta-1}
\ll M^{-1/2+3\theta/4}=M^{-5/256}.                    \tag{12}
\]
对 $d\le Z$ 求和，$\sum d^{-2}$ 与 $\sum d^{-1-\theta}$ 均收敛，故 (7) 的第一部分是 $O(e^{-c_3V_M})$。

对 $d>Z$，逐项取绝对值。note 850 式 (4)--(6) 的同一格距估计在这里以 $d$ 作为共同因子使用；不要求 $d=(u,v)$。固定 $d,k,\ell$ 时，活动 $a$ 有 $O(M/(kd))$ 个，固定 $a$ 的 $b$ 核 majorant 和为
$O(1+M/(H\ell d))$。于是
\[
\sum_{d>Z}|\mathcal S_d|
\ll\sum_{d>Z}\left(\frac{A_H^2}{d^2}
 +\frac{H A_H\sum_{\ell<64H}|W(\ell)|}{Md}\right)
\ll\frac{\log^4(2M)}Z+\frac{H^2\log^4(2M)}M
\ll e^{-c_4V_M}.                                          \tag{13}
\]
这里有活动项时 $d\ll M$，所以第二项的调和和至多 $O(\log M)$；$H\le M^{1/4}$ 使它为固定幂小量。所有界均与 $T,U$ 无关，故 (11)--(13) 与 (7) 证明 (2a)，进而证明 (2)。$\square$

## 边界

[Note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 已对**所有实际 gcd 层的完整和**给出次指数界；本稿的新范围是将同样等级的 signed 抵消单独证明在 $g=1$ 层及任意一个物理位移带，保留完整两臂与全部乘子。式 (3) 中的 $L e^{-c_0V_M}$ 使 (11) 的主误差始终为次指数。还有一个**本方法**量纲限制：若把 (3) 的短和余项写为 $X^\theta$，并把 Ramachandra 的 $7/12+\varepsilon$ 指数尽量逼近 $\theta\downarrow7/12$，则逐乘子取绝对值后的余项仍为 $H^{2-\theta}M^{\theta-1}$。在 $H\asymp M^{1/5}$，这至多由该输入证明 $M^{-2/15+o(1)}$，而目标是 $M^{-1/5}$。note 851 对**未按源 gcd 分层**的完整系数作精确乘子重组和周期 Parseval，已把对应幂次余项支付到目标以下；故这里的 $M^{-2/15}$ 缺口只属于当前逐乘子取绝对值的源互素证明，不能宣称为完整门的必要障碍。完整门依旧缺固定幂 signed 估计。
