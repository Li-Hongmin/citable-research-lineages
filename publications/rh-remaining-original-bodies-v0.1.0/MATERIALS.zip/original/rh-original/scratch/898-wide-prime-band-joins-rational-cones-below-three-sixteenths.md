# 全宽素数带与有理锥的联合正压缩：分母指数至 \(3/16\)（候选，待异源复核）

日期：2026-10-01。本稿沿用 [scratch/891](891-logarithmic-denominator-weight-pays-fixed-power-farey-cones.md) 的全轮廓有理锥正隙和根逆响应、[scratch/893](893-average-farey-spacing-pays-upper-prime-schur-block.md) 的有理根平均及素数块加权删点、[scratch/894](894-almost-all-rational-cones-join-prime-dilates-after-incidence-pruning.md) 的同臂事故计数，并使用 [scratch/897](897-wide-prime-dilates-create-exact-denominator-stars.md) 的精确分母星图。新点是把素数带下端降到 \(X\)：保留非根跨块的精确星图，在真实物理槽中支付它，而不声称它为零。上游仍是未异源复核候选，本文也只留在 scratch；完整旧空间及 RH 均未判定。

## 命题

令 \(X\to\infty\)、\(H=\log X\)、\(k=X^2\)、\(w=\frac12\log(1+X^{-2})\)，并令

\[
\mathcal G_X^\circ=\left\{\frac nd:\frac{X^{3/2}}8<n<\frac{X^{3/2}}4,
\quad\frac{\sqrt X}2<d<\sqrt X,\quad(n,d)=1\right\}.
\]

对 \(y\in\mathcal G_X^\circ\)，取 scratch/891 的有理锥

\[
\mathcal R_{y,B}=\{1\}\cup\{a/b:5\le a/b\le N_y=\lfloor y/2\rfloor,
\ (a,b)=1,\ b\le B\},\qquad 1\le B\le X^{3/16},
\]

以及全部奇槽有限能量轮廓的闭形式空间 \(\mathscr V_{y,B}\)。令

\[
\mathcal P_X^{\rm wide}=\{p\text{ prime}:X\le p\le X^{3/2}\},
\qquad z_p=p/y.
\]

存在与 \(B\) 无关的 \(\mathcal G_X^\dagger\subset\mathcal G_X^\circ\)，满足

\[
|\mathcal G_X^\circ\setminus\mathcal G_X^\dagger|=o(X^2),
\tag{1}
\]

使对每个 \(y\in\mathcal G_X^\dagger\)，可从上述素数带删去同一组与 \(B\) 无关、根列平方质量为 \(o(1)\) 的素数。余下素数的完整轮廓空间 \(\mathscr U_y^{\rm wide}\) 与所有 \(\mathscr V_{y,B}\) 物理正交，而且对全部 \(B\le X^{3/16}\) 一致有

\[
\boxed{\quad
A_{X^2,-}\big|_{\mathscr V_{y,B}\oplus\mathscr U_y^{\rm wide}}
\succeq cH I
\quad}\tag{2}
\]

其中 \(c>0\) 为绝对常数。余下素数的根反射列仍具有

\[
\sum_{p\in\mathcal Q_y}\frac{(\log p)^2}{p}
=\left(\frac58+o(1)\right)H^2.
\tag{3}
\]

令 \(e_{y,1}\) 为根的单位常值轮廓，\(M_{y,B}\) 为删除根后 \(C\oplus\mathscr U_y^{\rm wide}\) 的正闭形式块，\(f_{y,B}\) 为真实根列。该联合块的真受限 Schur 扣款还满足
\[
\boxed{\quad
\langle f_{y,B},M_{y,B}^{-1}f_{y,B}\rangle
\ge\left(\frac9{16}+o(1)\right)H.
\quad}\tag{3b}
\]

若 \(\mathscr O_y^{\rm wide}\) 表示所有被删素数槽的完整轮廓直和，则在同一个良好根集合上，对任意单位有限能量根轮廓 \(h\) 还有直接形式列界
\[
\sup_{\substack{v\in\mathscr O_y^{\rm wide}\cap D(\mathfrak a_{X^2,-})\\\|v\|_2=1}}
|A_{X^2,-}[\iota_yh,v]|
\ll H^{-1/8}=o(1).
\tag{3a}
\]

这里的联合压缩包含锥与素数槽内的**全部**有限能量轮廓、全部素数幂算术平移、Archimedean 核和奇 polar。式 \(2\) 不涉及这些槽之外的旧奇空间。

## 删点：把标签直和变成物理正交直和

下列三类事故先用最大 \(B_*=\lfloor X^{3/16}\rfloor\) 一次删除，因此删点与较小 \(B\) 无关。不同 \(y=n/d\in\mathcal G_X^\circ\) 的间距严格大于 \(1/X\)，且 \(|\mathcal G_X^\circ|\asymp X^2\)，见 scratch/893 式 \(10\)--\(12\)。每个下述固定整数元组若命中某个 \(y\)，允许的 \(y\) 区间长度小于 \(1/X\)，故至多命中一个根。

第一，素数槽 \(z_p\) 与锥标签 \(r=a/b\) 的物理槽相交，只可能满足

\[
|\log(pr/y^2)|<w.
\tag{4}
\]

可用 \(p\le X^{3/2}\)、\(b\le B_*\)、\(5b\le a\le Xb/4\) 的全部整数元组上界计数；它们至多有 \(O(X^{5/2}B_*^2)\) 个。每个 \(p\ge X\) 的根列平方质量 \(c_p^2=(\log p)^2/p\ll H^2/X\)。故这类事故素数的质量在全部根上的总和至多 \(O(H^2X^{3/2}B_*^2)\)，对根平均为

\[
O(H^2B_*^2X^{-1/2})=o(1).
\tag{5}
\]

根到 \(p/y\) 除 \(s=p\) 整槽反射外可能还有同臂素数幂平移；其条件为 \(|\log(ps/y^2)|<w\)。若命中，则 \(s\ll X\)。对全部 \(p\le X^{3/2}\)、\(s\ll X\) 作同样单次命中计数，得到这类事故素数质量的平均 \(O(H^2X^{-1/2})=o(1)\)。删除它们之后，根到各保留素数槽的唯一算术边是 \(+c_pJ\)。

第二，对锥的非根 \(r=a/b\) 与 \(p/y\) 的同臂算术事故，scratch/894 式 \(4\)--\(7\) 的逐三元组单次命中证明不要求 \(p\ge X^{5/4}\)。将其计数改在 \(X\le p\le X^{3/2}\) 求和，平均加权事故数至多

\[
B_*^2\left(H\sum_{p\in\mathcal P_X^{\rm wide}}
\frac{(\log p)^2}{p^2}
+X^{-2}\sum_{p\in\mathcal P_X^{\rm wide}}(\log p)^2\right)
\ll B_*^2(H^3X^{-1}+H^2X^{-1/2})=o(1).
\tag{6}
\]

两项分别来自 \(X^2H/(pr)\) 与 \(pr/X^2\) 两种同臂平移，已除以 \(|\mathcal G_X^\circ|\asymp X^2\)。删除有任一事故的素数，其平方质量不超过上述加权事故数，遂将非根跨块的全部同臂算术边消去。

第三，素数块内异臂反射采用 scratch/893 的非负上界矩阵 \(\widetilde K_y\)，但让 \(p,q\) 遍历本稿宽带。具体置
\[
M_y=\sum_{p,q\in\mathcal P_X^{\rm wide}}c_pc_q
\sum_{\substack{s\ {\rm 素数幂}\\|\log(pq/(sy^2))|<w}}c_s.
\]
若反射发生，\(s\le65X\)。每个 \((p,q,s)\) 至多命中一个 \(y\)，且 Chebyshev 界仍给

\[
\sum_yM_y\le
\left(\sum_{X\le p\le X^{3/2}}c_p\right)^2
\sum_{s\le65X}c_s\ll X^2.
\tag{7}
\]

因此除 \(O(X^2H^{-1/4})\) 个根外，\(M_y\le H^{1/4}\)。按原阈值 \(L_y(p)>\sqrt H\) 再删素数，平方质量至多 \(H^{-1/4}\)，留下的全轮廓素数反射块范数至多 \(\sqrt H\)。由 \(5\)--\(7\) 和 Markov，可取 \(1\) 的良好根集合，使所有删除的总平方质量 \(o(1)\)；例如第一、二类各以 \(H B_*X^{-1/4}=o(1)\) 为阈值。由素数定理

\[
\sum_{X\le p\le X^{3/2}}c_p^2
=\left(\tfrac12((3/2)^2-1)+o(1)\right)H^2
=\left(\tfrac58+o(1)\right)H^2,
\]

故 \(3\) 成立。

为同时证明 (3a)，对每个根置
\[
Z_y=\sum_{\substack{p\in\mathcal P_X^{\rm wide},\ s\ {\rm 素数幂}\\
|\log(ps/y^2)|<w}}\frac{\Lambda(s)^2}{s}.
\]
若条件成立则 \(s\ll X\)，而固定 \((p,s)\) 至多命中一个 \(y\)。因此
\[
\frac1{|\mathcal G_X^\circ|}\sum_yZ_y
\ll X^{-1/2}\sum_{s\ll X}\frac{\Lambda(s)^2}{s}
\ll H^3X^{-1/2}.
\]
再舍去 \(O(H^{3/2}X^{-1/4}X^2)=o(X^2)\) 个根后，\(Z_y\le H^{3/2}X^{-1/4}\)。每个目标素数槽的次级整数窗长度小于一，故至多有一个次级平移；对全部被删目标的算术列平方范数至多
\(2\sum_{p\notin\mathcal Q_y}c_p^2+2Z_y\ll H^{-1/4}\)。
根与全部宽带素数槽的相离 Archimedean 列为 \(o(1)\)，奇 polar 列也是 \(o(1)\)，所以 (3a) 成立。物理上与锥槽重叠的被删素数槽仍彼此正交；此处只估计根到它们的一次形式配对，不对它们与保留空间的间接耦合作结论。

## 真实跨块与 Schur 预算

删除 \(4\) 的碰撞后，锥与素数槽及各自内部槽是物理正交直和。各素数槽的单槽下界为 \(2H-O(1)\)；素数之间的同臂算术边为零，异臂算术块由 \(7\) 的删点压到 \(O(\sqrt H)\)。相离 Archimedean 同臂行和为 \(O(HX^{-1/2})\)。异臂物理中心乘积至少 \(4\)，每块为 \(O(w)\)，而素数槽数至多 \(X^{3/2}\)，故异臂行和为 \(O(X^{-1/2})\)。奇 polar 投影范数平方为 \(O(1)\)。于是全轮廓素数块 \(F\) 满足

\[
F\succeq(2H-C\sqrt H)I.
\tag{8}
\]

锥与素数槽之间的非算术同臂块范数为 \(O(1)\)：相邻且仅相离的槽用相离 Carleman 核的统一 \(L^2\) 界，其余两行的尾和分别为 \(O(wX^{3/2}H)\) 与 \(O(wXB_*^2H)\)。异臂中心乘积也至少 \(4\)，由槽数界所得矩形块范数为

\[
O\bigl(w\sqrt{X^{3/2}\cdot XB_*^2}\bigr)
=O(B_*X^{-3/4})=o(1).
\]

polar 跨块由锥投影 \(o(1)\) 与素数投影 \(O(1)\) 给 \(o(1)\)。因此非算术跨块总范数为 \(O(1)\)。同臂算术跨块已删除；非根异臂算术跨块恰为 scratch/897 的分母星图 \(T\)，不能删除。它从锥的非根轮廓到素数轮廓（或取伴随）满足

\[
\|T\|^2\le\sum_{\substack{b\le B_*\\b\text{ 素数幂}}}
\frac{\Lambda(b)^2}{b}
=\left(\frac{9}{512}+o(1)\right)H^2.
\tag{9}
\]

根到素数块的算术算子 \(g:h\mapsto(c_pJh)_p\) 则由 \(3\) 满足

\[
\|g\|^2=\left(\frac58+o(1)\right)H^2.
\tag{10}
\]

令 \(R\) 为锥根的完整轮廓空间，\(C\) 为非根锥完整轮廓空间，\(D=A|_C\)，\(f:R\to C\) 为根到非根形式列。对任意 \(h\in R\)，同臂整槽平移给
\[
(fh)_q=-c_qh\quad(q\text{ 为整数素数幂},\ 5\le q\le N_y),
\]
其余算术反射及非算术根列合成范数为 \(o(1)\) 的 \(L^2\) 算子，见 scratch/891 式 (9) 及其根列估计。注意此式逐轮廓成立，常值轮廓只是特例。scratch/891 式 (11) 给 \(D\succeq\bigoplus_{r\ne1}d_rI\)，其中
\[
d_r=2H-\log N_y+\Lambda(r)\mathbf1_{\{r\ {\rm 整数素数幂}\}}
-5\log B-C\sqrt H.
\]
由逆序比较，主列在任意单位 \(h\) 上的逆响应不超过
\(\sum_{q\le N_y}c_q^2/d_q=(F(\beta_B)+o(1))H\)，误差列经 \(D^{-1/2}\) 后只改变 \(o(H)\)。因此对所有 \(B\le B_*\)，

\[
D\succeq(1/16-o(1))HI,
\qquad f^*D^{-1}f\preceq(F(3/16)+o(1))HI
\preceq(5/6+o(1))HI,
\tag{11}
\]

这里 \(F(\beta)=1-(1-5\beta)\log[(2-5\beta)/(1-5\beta)]\) 在 \(0\le\beta<1/5\) 单调递增，且 \(F(3/16)=1-(\log17)/16<5/6\)。根单槽自能量至少 \((2-o(1))H I_R\)。将真实非根跨块写为 \(T+E\)，其中 \(\|E\|=O(1)\)，不影响以下主项。由 \(8\)--\(11\)，在 \(C\oplus\mathscr U_y^{\rm wide}\) 上先消去 \(D\) 后的素数 Schur 块

\[
S=F-(T+E)D^{-1}(T+E)^*
\succeq(55/32-o(1))HI.
\tag{12}
\]

其中 \(T\) 的方向取 \(C\to\mathscr U\)，所以 \(12\) 中写 \(TD^{-1}T^*\)。又对任意单位根轮廓，

\[
\|(T+E)D^{-1}f\|
\le\left(\sqrt{\frac{9}{512}}\sqrt{\frac{5/6}{1/16}}+o(1)\right)H
=\left(\frac{\sqrt{15}}8+o(1)\right)H
<\left(\frac12+o(1)\right)H,
\]

而 \(\|g\|<(4/5+o(1))H\)。故根到联合补块的逆响应由精确分块 Schur 恒等式界为

\[
\begin{aligned}
R_{\rm joint}
&=f^*D^{-1}f+
\bigl(g-(T+E)D^{-1}f\bigr)^*S^{-1}
\bigl(g-(T+E)D^{-1}f\bigr)\\
&\preceq\left(\frac56+\frac{(13/10)^2}{55/32}+o(1)\right)HI
< (1.82+o(1))HI.
\end{aligned}
\tag{13}
\]

为证明 (3b)，只在非根锥的整数素数标签 \(5\le q\le N_y\) 与保留宽带素数标签 \(p\) 上取常值试探向量 \(v\)：在 \(q\) 槽取 \(-c_qh_0\)，在 \(p\) 槽取 \(+c_ph_0\)，其中 \(h_0=w^{-1/2}\mathbf1_{(0,w)}\)。两组各自的同臂素数幂跨边为零；组间同臂边已删，异臂边由 scratch/897 的整数窗分类为零，因为其既约分子 \(q<p\)。组间非算术块仅有 \(O(1)\) 范数；两组各自的异臂反射块分别由 scratch/891 在 \(B=1\) 及上面的 \(M_y\) 删点给 \(O(\sqrt H)\) 范数。因此
\[
\|v\|^2=\sum_{q\le N_y,\ q\ {\rm prime}}c_q^2+
\sum_{p\in\mathcal Q_y}c_p^2
=\left(\frac98+o(1)\right)H^2,
\qquad
M_{y,B}[v]\le(2H+O(\sqrt H))\|v\|^2.
\]
真实根配对为
\(\langle f_{y,B},v\rangle=(9/8+o(1))H^2\)。
由正闭形式逆的变分不等式
\(\langle f,M^{-1}f\rangle\ge|\langle f,v\rangle|^2/M[v]\)，得到 (3b)。这里 \(B\) 只会增加其他非根槽，故试探向量及估计对全部 \(B\le B_*\) 一致。

根对角至少 \((2-o(1))H I_R\)，故根 Schur 枢轴有固定线性正隙；\(11\)--\(12\) 亦给联合补块的线性正隙。由于跨块范数为 \(O(H)\)、补块逆范数为 \(O(H^{-1})\)，闭形式配方的三角变换范数一致有界，于是整个 \(R\oplus C\oplus\mathscr U_y^{\rm wide}\) 有 \(2\) 的 \(cH\) 正隙。所有运算先在各槽光滑有限和核心上成立，随后由 note 790 的单槽闭形式核心及有界跨槽算子延拓。 \(\square\)

## 边界

这是经 \(y\) 平均及少量素数删点后的**联合压缩**，不是整个旧奇 Weil 算子。最薄弱的承重接口是 scratch/891 的全锥下界及逆响应、scratch/894 的同臂三元组计数向宽带的移植，以及相离槽 Carleman 块界；均需异源复核。即使 \(2\) 完全正确，其余连续补空间的 Schur 反馈与 note 849 的 moving-\(N\) signed covariance 仍未解决。
