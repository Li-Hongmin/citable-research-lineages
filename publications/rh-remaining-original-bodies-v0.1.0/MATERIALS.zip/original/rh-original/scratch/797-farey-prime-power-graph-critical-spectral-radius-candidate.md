# 全 Farey 素数幂图的正权行恒等式与临界谱半径（待异源复核）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的全 Farey 图 \(C_p(x,y)=c_{x/y}+c_{y/x}+c_{xy}\)。只研究该有限非负矩阵，不假定 RH 或旧算子正性。

## 候选定理

令 \(p\to\infty\) 为奇素数、\(L=2\log p\)、\(\mathcal F_p=\{a/b>1:1\le b<a<p,(a,b)=1\}\)。对 \(x=a/b\in\mathcal F_p\) 置 \(v_x=(ab)^{-1/2}>0\)，并定义
\[
M(t)=\sum_{n\le t}\frac{\Lambda(n)}n\quad(t\ge1).
\]
则有逐行精确恒等式
\[
\boxed{\frac{(C_pv)_{a/b}}{v_{a/b}}
=\log a+\log b-\Lambda(a)\mathbf1_{b=1}
+M\!\left(\frac{p-1}{a}\right)
+M\!\left(\frac{p-1}{b}\right).}
\tag{1}
\]
因此经典 \(M(t)=\log t+O(1)\) 与正权 Schur 检验给出
\[
\boxed{\|C_p\|_{\ell^2(\mathcal F_p)\to\ell^2(\mathcal F_p)}
=L+O(1).}
\tag{2}
\]
这个 \(O(1)\) 有上下两侧；(2) 不声称 \(D_kI-C_p\) 正定。

## 边的逐方向分类

因为 \(w_x=w_{1/x}\)，从固定 \(x=a/b>1\) 出发，式 \(C_p(x,y)=c_{x/y}+c_{y/x}+c_{xy}\) 的每条边恰对应于整数素数幂 \(n\) 的两种操作之一：把 \(x\) 乘 \(n\)，或把 \(x\) 除以 \(n\)，再取倒数使指标大于一。若结果恰为 \(1\)，该节点未收入 \(\mathcal F_p\)。不同 \(n\) 即使到同一目标，其矩阵权也逐项相加；自环亦按同一规则计一次。

固定素数 \(\ell\)。考察 \(x\mapsto xn\)、\(n=\ell^r\)。若 \(\ell\nmid b\)，化简后为 \(a\ell^r/b\)，当 \(a\ell^r<p\) 时贡献于 \((C_pv)_x/v_x\) 的权为
\[
c_{\ell^r}\frac{v_{a\ell^r/b}}{v_{a/b}}
=\frac{\log\ell}{\ell^r}.
\tag{3}
\]
若 \(\ell^v\Vert b\)，则对 \(1\le r\le v\)，目标为 \(a/(b/\ell^r)\)，每条贡献 \(\log\ell\)，合计 \(v\log\ell\)。对 \(r=v+h\)、\(h\ge1\)，目标为 \(a\ell^h/(b/\ell^v)\)，存在条件为 \(a\ell^h<p\)，而贡献正好是 \((\log\ell)/\ell^h\)。因此乘法方向的整行权恰为
\[
\log b+M((p-1)/a).
\tag{4}
\]
这里 \(M((p-1)/a)\) 的每个 \(\ell^h\) 项：若 \(\ell\nmid b\)，由原始 \(n=\ell^h\) 给出；若 \(\ell^v\Vert b\)，由跨约分的原始 \(n=\ell^{v+h}\) 给出。

同样考察 \(x\mapsto x/n\)。若 \(\ell\nmid a\)，就在分母加入 \(\ell^r\)，存在条件 \(b\ell^r<p\)，贡献 \((\log\ell)/\ell^r\)。若 \(\ell^v\Vert a\)，\(1\le r\le v\) 从分子删去 \(\ell^r\)，每条贡献 \(\log\ell\)，但当 \(b=1\) 且 \(n=a\) 时目标为单位节点 \(1\)，必须删去该条 \(\Lambda(a)\) 权；当 \(r=v+h\) 时跨约分在分母加入 \(\ell^h\)，条件 \(b\ell^h<p\)，贡献 \((\log\ell)/\ell^h\)。因此除法方向的整行权为
\[
\log a-\Lambda(a)\mathbf1_{b=1}+M((p-1)/b).
\tag{5}
\]
式 (4)--(5) 相加即得 (1)。

## 谱上界与下界

由经典 Mertens 求和 \(M(t)=\log t+O(1)\)（对所有 \(t\ge1\) 统一），(1) 给每一行
\[
\frac{(C_pv)_x}{v_x}
=2\log(p-1)-\Lambda(a)\mathbf1_{b=1}+O(1)
\le L+O(1).
\tag{6}
\]
对称且逐项非负的 \(C_p\) 应用正权 Schur 检验得 \(\|C_p\|\le L+O(1)\)。

另一方面，\(v^2\) 的总质量由 Möbius 反演为
\[
\|v\|^2
=\frac12\sum_{\substack{a,b<p\\(a,b)=1\\a\ne b}}\frac1{ab}
=\frac{(\log p)^2}{2\zeta(2)}+O(\log p).
\tag{7}
\]
式 (6) 的逐行 \(O(1)\) 是双向的，故 Rayleigh 商满足
\[
\frac{\langle v,C_pv\rangle}{\|v\|^2}
\ge2\log(p-1)-O(1)
-\frac{\sum_{2\le a<p}\Lambda(a)/a}{\|v\|^2}.
\tag{8}
\]
由 \(\sum_{a<p}\Lambda(a)/a=\log p+O(1)\) 与 (7)，末项为 \(O(1/\log p)\)。于是 \(\|C_p\|\ge L-O(1)\)，与上界合并得 (2)。\(\square\)

## 边界

临界谱半径与 note 791 的 \(P_{W_p}A_{k,-}P_{W_p}=D_kI-C_p+O_{\rm op}(1)\) 相配，说明这个全 Farey 主压缩的最低谱值有 \(-O(1)\) 下界，且算术主项的最大谱值达到 \(L+O(1)\)。常数级的谱偏差与 Archimedean 压缩、极点及完整补空间 Schur 仍可决定最终符号；(2) 不证明或反驳 RH。
