# 增长 dyadic 奇数格的全轮廓局部 Weil 谱隙

日期：2026-10-03。依赖 [note 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md)
的单槽闭形式下界和整除 Schur 检验、[note 007](../notes/007-indefinite-polar-splitting-and-reduced-markov-form.md)
的约化普通核与 polar 分解，以及
[scratch 972](972-fixed-depth-dyadic-odd-weil-grids-have-a-uniform-positive-limit.md)
的 dyadic 槽几何。本稿处理这些槽上的**任意**系数和有限能量轮廓；
证明尚未异源复核，故留在 scratch。全尺度补空间和 RH 均不在结论内。

## 命题候选

固定 $0<\theta<1$。沿奇素数 $p\to\infty$，取整数 $R=R(p)\ge0$，
满足 $R\to\infty$ 且
\[
2^R=o(p^2),\qquad \frac{\log M}{R2^R}\longrightarrow0,
\qquad
M=\left\lfloor\frac{p^2}{2^{R+1}}\right\rfloor-1.
\tag{1}
\]
置 $H=\log p$、$\ell=2\theta/p^2$，并对 $0\le r\le R$、
奇数 $1\le a\le M$ 令
\[
q_{r,a}=a/2^r,\quad
y_{r,a}=H-\log(2^{R+1}q_{r,a}),\quad
I_{r,a}=(y_{r,a}-\ell/2,y_{r,a}+\ell/2),\quad
U_{p,R}=\bigcup_{r,a}I_{r,a}.
\tag{2}
\]
则这些区间两两相离且位于 $(-H,H)$。存在只依赖 $\theta$
的常数 $C_\theta$，使局部 Weil 闭形式对所有支撑于 $U_{p,R}$
的有限能量函数满足
\[
\boxed{\quad
Q_W^H[f]\ge
\left[
R\log2-C_\theta\left(
1+\frac{\log M+\log(R+1)}{2^R}
+\sqrt{\frac{\log M}{2^R}}
\right)
\right]\|f\|_2^2.
\quad}\tag{3}
\]
因此在 (1) 下，整个槽并集压缩有
\[
\boxed{\quad
\inf_{\substack{f\ne0,\ \operatorname{supp}f\subset U_{p,R}\\
f\in D(Q_W^H)}}\frac{Q_W^H[f]}{\|f\|_2^2}
=R\log2+o(R)>0.
\quad}\tag{4}
\]
这里槽轮廓可各不相同，且任意复系数都允许。
例如取 $R=\lceil\log_2\log p\rceil$，则 (1) 成立，
上下界进一步给出谱底
$\log\log p+O_\theta(1)$，而
$|U_{p,R}|\asymp_\theta(\log\log p)/\log p$。

## 槽几何与精确算术矩阵

最小指标是 $2^{-R}$，最高中心为 $H-\log2$。最大指标是
$M$，而 $y_{0,M}+H=\log[p^2/(2^{R+1}M)]$
大于 $2^{R+1}/p^2>\ell/2$。不同指标落在
$2^{-R}\mathbb Z$ 且互异，故其差至少 $2^{-R}$；
所有指标至多 $M$，所以中心间距至少
\[
\log(1+2^{-R}/M)\ge(2+o(1))/p^2>\ell.
\tag{5}
\]
若素数幂平移使两槽相交，相应指标 $q,q'$ 满足
$|q'-kq|\le M(e^\ell-1)
=\theta2^{-R}(1+o(1))<2^{-R}$。
因而必有精确等式 $q'=kq$；同一 $r$ 内的边恰是奇素数幂整除，
不同 $r,s$ 间的边恰是同一奇数 $a$ 的 $2^{|r-s|}$ 边。

把每槽平移到公共局部坐标
$t\in(-\ell/2,\ell/2)$。素数幂形式于是精确等于
$C_{M,R}\otimes I_{L^2(-\ell/2,\ell/2)}$，其中
\[
C_{M,R}=C_{\rm odd}(M)\otimes I_{R+1}
+I_{\rm odd}(M)\otimes D_R,\qquad
(D_R)_{rs}=
\begin{cases}
(\log2)\,2^{-|r-s|/2},&r\ne s,\\
0,&r=s.
\end{cases}
\tag{6}
\]
这里 $C_{\rm odd}(M)$ 是奇数 $a\le M$ 上仅含奇素数幂的
整除矩阵，边权为 $\Lambda(k)/\sqrt{k}$。
对正权 $w_a=a^{-1/2}$，其逐行比值恰为
\[
\frac{(C_{\rm odd}w)_a}{w_a}
=A_{\rm odd}(M/a)+\log a
=\log M+O(1),
\tag{7}
\]
其中 $A_{\rm odd}(z)=\sum_{k\le z,\ k\ {\rm odd}}\Lambda(k)/k
=\log z-\gamma-\log2+O(1)$，误差对 $z\ge1$ 有界。
非负对称矩阵的加权 Schur 检验与
$\|D_R\|\le2(\log2)\sum_{d\ge1}2^{-d/2}
=2(\log2)(\sqrt2+1)$ 给
\[
\|C_{M,R}\|\le\log M+C
\tag{8}
\]
且 $C$ 与 $p,R,M$ 无关。故全部素数幂罚项被
$(\log M+C)\|f\|_2^2$ 支付。

## 普通核的统一行和

note 854 的单槽估计给所有槽轮廓之和
\[
\sum_{r,a}q_{\rm red}[f_{r,a}]
\ge(\log(1/\ell)-C)\|f\|_2^2.
\tag{9}
\]
不同槽的约化普通核是 $-k(|y-z|)$，其中
$k(t)=e^{-t/2}/(1-e^{-2t})$。由 (5) 和固定 $\theta<1$，
任意两个不同槽之间的积分块算子范数至多
$C_\theta\ell\,k(|\log(q/q')|)$。

固定 $q=a/2^r$，写第 $s$ 层的奇数变量为 $b$，并置
$v=2^sq=a2^{s-r}$。在 $b/v\in[1/2,2]$ 内，
$k(|\log(v/b)|)\ll v/|b-v|$；其余项合计 $O(M)$，
若 $v>2M$ 则更精确地合计 $O(M^{3/2}/\sqrt v)$。

先对 $s\ge r$ 求和。此时 $v$ 为整数；$s=r$ 时去掉
$b=v$，$s>r$ 时 $v$ 为偶数。因此当 $v\le2M$，
该层的近区和为 $O(v\log(2M))$。这些 $v$ 随 $s$
逐次倍增，合计 $O(M\log(2M))$。对 $v>2M$
的层，上述远区界是几何级数，合计 $O(M)$。

若 $s<r$，写 $j=r-s$ 和
\[
D_j=\operatorname{dist}\bigl(a,\,2^j(2\mathbb Z+1)\bigr)
\quad(1\le j\le r).
\]
$D_j$ 是正奇整数。第 $s$ 层的近区和至多
$C[(a/2^j)\log(2M)+a/D_j]$；远区至多 $CM$，
但这里可用 $O(M2^{-j/2})$：因为 $a/2^j\le M/2^j$，
对 $b>2a/2^j$ 的核满足
$k\ll\sqrt{(a/2^j)/b}$，对 $b<a/2^{j+1}$
的核满足 $k\ll\sqrt{b/(a/2^j)}$，两段合计
$O(\sqrt{aM/2^j}+a/2^j)\ll M2^{-j/2}$。
近区第一项对 $j$ 求和为 $O(M\log(2M))$。
对每个 $T\ge1$，$D_j\le T$ 蕴含某个奇数
$1\le d\le T$ 满足 $2^j\Vert a+d$ 或
$2^j\Vert a-d$。每个 $d$ 至多产生两个 $j$，
故 $\#\{j:D_j\le T\}\le2T$。把 $D_1,\ldots,D_r$
从小到大排列为 $D_{(1)},\ldots,D_{(r)}$，则
$D_{(k)}\ge k/2$，于是
\[
\sum_{j=1}^rD_j^{-1}
=\sum_{k=1}^rD_{(k)}^{-1}
\le2\sum_{k=1}^rk^{-1}\ll\log(r+1).
\]
这证明全部层的统一行和
\[
\sup_{r,a}\sum_{\substack{0\le s\le R,\ b\le M\ {\rm odd}\\
(s,b)\ne(r,a)}}k(|\log(q_{r,a}/q_{s,b})|)
\ll M\bigl(\log M+\log(R+1)\bigr).
\tag{10}
\]
对积分块用 Schur 检验，得到
\[
|Q_{\rm ord,cross}[f]|
\le C_\theta\,\ell M\bigl(\log M+\log(R+1)\bigr)\|f\|_2^2
\le C_\theta\frac{\log M+\log(R+1)}{2^R}\|f\|_2^2.
\tag{11}
\]
最后一步使用 $\ell M\le\theta2^{-R}$，并且 $M\to\infty$。

## Polar 项与合并

写 $P_\pm(f)=\int_{-H}^H e^{\pm y/2}f(y)\,dy$。
由于 $q_{\rm pol}[f]=2\operatorname{Re}(P_+(f)\overline{P_-(f)})$，
Cauchy--Schwarz 给
\[
|q_{\rm pol}[f]|
\le2\|e^{y/2}\mathbf1_U\|_2
\|e^{-y/2}\mathbf1_U\|_2\|f\|_2^2.
\tag{12}
\]
按 (2) 求和并用
$S_M=\sum_{a\le M,\ a\ {\rm odd}}a^{-1}\ll\log M$、
$\sum_{a\le M,\ a\ {\rm odd}}a\ll M^2$，得
\[
\|e^{y/2}\mathbf1_U\|_2^2
\ll \ell\,\frac p{2^{R+1}}\sum_{r=0}^R2^rS_M
\ll\ell p\log M,
\]
\[
\|e^{-y/2}\mathbf1_U\|_2^2
\ll\ell\,\frac{2^{R+1}}p\sum_{r=0}^R2^{-r}M^2
\ll\ell pM.
\]
故
\[
|q_{\rm pol}[f]|
\le C_\theta\sqrt{\frac{\log M}{2^R}}\|f\|_2^2.
\tag{13}
\]
把 (8)、(9)、(11)、(13) 相加，并用
$\log(1/\ell)-\log M
=R\log2-\log\theta+O(1/M)$，得到 (3)。
由 (1) 知
$(\log M+\log(R+1))/2^R=o(R)$、
$\sqrt{\log M/2^R}=o(R)$，
所以先得到 (4) 的下界。反向取固定非负实单位轮廓
$\varphi\in C_c^\infty((-1/2,1/2))$，只在 $r=R$
层以奇数自然权 $a^{-1/2}/\sqrt{S_M}$ 放置
$b_\ell(t)=\ell^{-1/2}\varphi(t/\ell)$。
该单位向量的 prime 对角罚项为
$\log M-\gamma-\log2+o(1)$；
普通跨槽与 polar 自项均为 $O_\varphi(\ell M)=O_\varphi(2^{-R})$，
同槽 Fourier 项为
$\log(1/\ell)+C_\varphi-\log(2\pi)+o(1)$。
这些估计只需 $M\to\infty$，详见 scratch 972 的
(3)、(6)--(7)、(10) 及增长深度段的对角误差。
故该试函数的 Rayleigh 商为
$R\log2-\log\theta+C_\varphi+\gamma+\log2-\log(2\pi)+o(1)
=R\log2+O_{\theta,\varphi}(1)$，证明 (4) 的上界。
对每个固定 $p$，上述槽数有限；先对每槽光滑函数证明，
再按 note 854 的光滑截断与闭形式稠密性延到声明的完整
有限能量类。$\square$

## 范围

式 (4) 是真实 Weil 形式在一族增长 dyadic 槽并集上的
全轮廓、全系数下界。其支撑测度趋零；
[note 855](../notes/855-fixed-positive-mass-integer-log-grid-weil-gap.md)
已在另一种整数格上给出固定正测度的全轮廓正压缩。
本稿新增的是层数增长时的精确算术张量结构和 $R\log2$
谱底渐近，并非按支撑测度扩大覆盖。它没有支付 $U_{p,R}$ 到其无限维补空间的
true-Schur 交叉，也没有给 moving-$N$ Möbius signed covariance
的固定幂界；两项仍是 RH 入口的承重障碍。
