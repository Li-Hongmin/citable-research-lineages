# 高素数全轮廓带的 polar 量级中心化负方向与真实短窗算术门（候选，待异源复核）

日期：2026-10-01。沿用 [note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 的单槽闭形式、[note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的旧奇算子分解，以及 [note 828](../notes/828-exterior-prime-hankel-centered-spectrum-has-linear-negative-tail.md) 的反射调制方法。本文针对 [scratch/898](898-wide-prime-band-joins-rational-cones-below-three-sixteenths.md) 未覆盖的高素数平移槽，保留**真实奇 polar**和全部素数幂反射。结论只排除将这两项单独压到 \(O(\log P)\) 下界的扩带法；高频轮廓的 Archimedean 能量尚未支付，不能推出旧 Weil 形式负方向或 RH 反例。

## 命题

固定 \(3/2<\tau<2\)，令 \(P\to\infty\) 沿奇素数，\(H=\log P\)、\(w=\frac12\log(1+P^{-2})\)，并取任意 \(y\in\mathcal G_P^\circ\subset(P/8,P/2)\)。令 \(T=P^\tau\)，对每个素数 \(T\le q\le2T\) 取上臂区间
\[
I_q=\left(\log\frac{Pq}{y}-\frac w2,\,
          \log\frac{Pq}{y}+\frac w2\right),
\qquad E=\bigcup_{T\le q\le2T,\ q\ {\rm prime}}I_q\subset(H,2H).
\]
这些区间两两不交。在 \(L^2(E)\) 上置
\[
(J_sg)(u)=\mathbf1_E(2H+\log s-u)\,
g(2H+\log s-u),\qquad
R=\sum_{s\ {\rm 素数幂}}\frac{\Lambda(s)}{\sqrt s}J_s,
\tag{1}
\]
\[
a(u)=P^{-1/2}e^{u/2}\mathbf1_E(u),\quad
b(u)=P^{1/2}e^{-u/2}\mathbf1_E(u),\quad
\mathcal K[g]=|\langle a-b,g\rangle|^2,\quad k=\|a\|_2^2.
\tag{2}
\]
这里 \(R-\mathcal K\) 恰是旧奇形式在这些槽上的**全部算术异臂项加真实 polar 项**；同臂算术块为零。均匀于上述 \(y\)，
\[
\boxed{\quad
k=\left(\frac{3}{4\tau}+o(1)\right)
\frac{P^{2\tau-2}}{yH}
\asymp_\tau\frac{P^{2\tau-3}}H,\qquad
\inf_{\substack{g\in L^2(E),\ \iota g\in D(\mathfrak a_{P^2,-})\\\|g\|_2=1}}
(R-\mathcal K)[g]\le-\frac{k}{2}+O_\tau(1).
\quad}\tag{3}
\]
特别地，\(k/H\to\infty\)，所以不存在与 \(P,y\) 一致的
\(R-\mathcal K\succeq-C_\tau H I\)。

令 \(g_0=a/\sqrt k\)，并定义非负重叠权
\[
\omega(t)=|E\cap(2H+\log t-E)|,\qquad
\vartheta(t)=\sum_{\ell\le t,\ \ell\ {\rm prime}}\log\ell .
\]
则真实旧奇 Weil 形式还满足精确算术接口
\[
\boxed{\quad
A_{P^2,-}[\iota g_0]
=2H+\frac1k\int_0^\infty\omega(t)\,d(\vartheta(t)-t)
+O_\tau(1).
\quad}\tag{4}
\]
因此若全尺度局部 Weil 正性成立，必有这族移动权的单侧算术界
\[
\int_0^\infty\omega(t)\,d(\vartheta(t)-t)
\ge-(2H+O_\tau(1))k .
\tag{5}
\]
式 (5) 是必要条件，尚未得到所需估计；它不把等价重述充作 RH 证明。

## 槽几何、polar 与高次幂

因 \(q\le2P^\tau=o(P^2)\)，不同素数中心的对数距离至少
\(\log(1+(2T)^{-1})\gg T^{-1}\gg w\)；且 \(q/y\asymp P^{\tau-1}\in(1,P)\)，故 \(E\subset(H,2H)\)。在上臂取 \(g/\sqrt2\)、下臂取其奇反射的负值，得到等距嵌入 \(\iota:L^2(E)\to H_{P^2}^{-}\)。旧 polar 向量为 \(s(u)=\sinh((u-H)/2)\)，故
\[
-2|\langle s,\iota g\rangle|^2
=-4\left|\int_Es(u)g(u)\,du\right|^2
=-\mathcal K[g].
\tag{6}
\]
若同臂素数幂平移使 \(I_q\) 与 \(I_{q'}\) 相交，则
\(|sq-q'|\ll q'w<1\)，因而 \(q'=sq\)，与 \(q,q'\) 均为素数矛盾。异臂项由 note 828 的两臂配对恰给 (1)，包括自反射与所有高次素数幂。

每个槽的指数积分为
\(\int_{I_q}e^u\,du=2\sinh(w/2)Pq/y\)，所以
\[
k=\frac{2\sinh(w/2)}y\sum_{T\le q\le2T,\ q\ {\rm prime}}q .
\]
素数定理的分部求和给
\(\sum_{T\le q\le2T}q=(3/2+o(1))T^2/\log T\)，而
\(2\sinh(w/2)=(1/2+o(1))P^{-2}\)，证明 (3) 的 \(k\) 渐近。另有
\[
\|b\|_2^2=2\sinh(w/2)y\sum_{T\le q\le2T}\frac1q
\ll P^{-1},\qquad
\|a\|_2\|b\|_2\ll_\tau P^{\tau-2}/\sqrt H=o(1).
\]
因此 \(\|\mathcal K-|a\rangle\langle a|\|_{\rm op}=o(1)\)。

若 \(J_s\ne0\)，则 \(s\asymp_\tau T^2/P^2=P^{2\tau-2}\)。对 \(s=\ell^2\)、\(\ell\) 为素数的总算子范数至多
\[
\sum_{\ell\asymp_\tau P^{\tau-1}}\frac{\log\ell}{\ell}=O_\tau(1);
\]
对 \(s=\ell^j,\ j\ge3\)，用绝对收敛级数
\(\sum_{\ell}\sum_{j\ge3}(\log\ell)/\ell^{j/2}<\infty\)。
因此若 \(R^{(1)}\) 只含真正素数 \(s\)，则
\[
\|R-R^{(1)}\|_{\rm op}=O_\tau(1).
\tag{7}
\]

## 调制方向与完整旧形式的低频接口

置 \(r=\langle g_0,R^{(1)}g_0\rangle\)。低频试探直接给
\[
(R-\mathcal K)[g_0]=r-k+O_\tau(1).
\tag{8}
\]
所有参与 \(R^{(1)}\) 的素数 \(s\) 都满足 \(s>P\)，因为
\(s\gg P^{2\tau-2}\) 且 \(\tau>3/2\)。反射中心
\(C_s=2H+\log s\) 在有理数域上线性无关：整数关系
\(\sum_sn_sC_s=0\) 会给 \(P^{2\sum n_s}\prod_ss^{n_s}=1\)，唯一分解迫使每个 \(n_s=0\)。对固定 \(P,y\)，Kronecker 定理遂给 \(t_j\to\infty\) 使每个参与的素数同时满足 \(\cos(t_jC_s)\to-1\)。

取 \(g_{t}(u)=\sqrt2g_0(u)\cos(tu)\)。Riemann--Lebesgue 引理给
\(\|g_{t_j}\|_2\to1\)、\(\mathcal K[g_{t_j}]\to0\)；逐个有限反射用
\[
2\cos(tu)\cos(t(C_s-u))
=\cos(tC_s)+\cos(t(2u-C_s))
\]
又给 \(R^{(1)}[g_{t_j}]\to-r\)。由 (7)，
\[
\inf_{\|g\|=1}(R-\mathcal K)[g]\le\min\{r-k,-r\}+O_\tau(1)
\le-k/2+O_\tau(1).
\]
\(g_0\) 与每个有限 \(t\) 的 \(g_t\) 在各槽上光滑、在槽端点为阶跃；note 790 的单槽闭形式容纳这些轮廓，故同一变分上界可在 (3) 的有限能量域内实现。这证明 (3)。

对 (4)，每个 \(s\) 的反射配对满足
\(a(u)a(C_s-u)=\sqrt s\)，因而
\[
r=\frac1k\sum_{s\ {\rm prime}}(\log s)\,\omega(s).
\]
变量 \(t=e^{u+v-2H}\) 又给
\[
\int_0^\infty\omega(t)\,dt
=P^{-2}\left(\int_Ee^u\,du\right)^2=k^2,
\]
故 \(r-k=k^{-1}\int\omega\,d(\vartheta-t)\) 精确成立。

最后核对完整 Archimedean 项。note 790 的单槽公式对 \(g_0\) 在每个宽 \(w\) 槽上的归一化轮廓给 \(2H+O(1)\) 自能量：该轮廓与常值只相差 \(O(w)\)。不同素数槽的同臂相离核行和为 \(O(wT\log T)=o(1)\)；上下异臂中心距至少 \(2(\tau-1)H-O(1)\)，其行和为 \(O(wT P^{1-\tau})=o(1)\)。所以 \(G_{P^2}[\iota g_0]=2H+O_\tau(1)\)。把 (6)--(8) 与 \(r-k\) 的精确式代入
\(A_{P^2,-}=G_{P^2}+\mathcal R_{P^2}-2|s\rangle\langle s|\)，即得 (4)。若完整旧形式非负，则 (4) 直接给 (5)。\(\square\)

## 边界

负方向属于算术反射加 polar 的**中心化部分**。使所有真正素数反射同时取负的 \(t_j\) 可以极大；本文未控制其 \(G_{P^2}\) 能量，因此不能断言完整 Weil 形式有负方向。式 (4) 给自然低频方向的真实算术门，却没有估计该门至 \(O(H)\)。这两点与 note 828 的机制一致；本稿的新范围是 898 遗漏的 \(q\asymp P^\tau\) 物理素数槽、真实 polar 及全部高次素数幂的 \(O(1)\) 支付。
