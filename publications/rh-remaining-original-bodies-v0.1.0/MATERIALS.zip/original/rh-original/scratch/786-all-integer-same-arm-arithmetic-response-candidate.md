# 全整数同号算术图的逆响应上界（待独立复核）

日期：2026-09-29。依赖 [note 777](../notes/777-physical-collar-forcing-has-logarithmic-inverse-response-on-prime-source-bands.md) 的真实算术半槽、[note 783](../notes/783-squarefree-factor-layers-form-a-jacobi-response-chain.md) 的同号平移矩阵元、[note 785](../notes/785-squarefree-continuum-response-ceiling.md) 的平方自由连续轮廓比较。本文的算子只保留真实旧核半槽矩阵中的对角与同号算术平移；不把它等同于完整旧核。

## 定理

固定 \(0<\alpha<1\)，令 \(L=\log k\)、\(X=k^\alpha\)、\(D_k=L+1-\gamma_E-\log\pi\)。在有限维空间 \(\ell^2(\{2\le n\le X\})\) 上定义实对称算术图
\[
 T_{k,X}[a]=D_k\sum_{2\le n\le X}|a_n|^2
 -2\mathop{\rm Re}\sum_{\substack{n\ge2,\ q\ge2\text{ 素数幂}\\nq\le X}}
 \frac{\Lambda(q)}{\sqrt q}\,\overline{a_n}a_{nq},
 \qquad b_n=\frac{\Lambda(n)}{\sqrt n}.
\tag{1}
\]
存在绝对常数 \(C\)，使对全部充分大的 \(k\) 和任意向量 \(a\)，
\[
\boxed{T_{k,X}[a]\ge
\sum_{\substack{2\le n\le X\\n\text{ 为素数幂}}}
\bigl((1-\alpha)L+\Lambda(n)-C\bigr)|a_n|^2
 +\sum_{\substack{2\le n\le X\\n\text{ 非素数幂}}}
\bigl((1-\alpha)L-C\bigr)|a_n|^2.}
\tag{2}
\]
因此 \(T_{k,X}>0\)，而且即使允许全部整数节点和任意随 \(k\) 变化的系数，也有
\[
\boxed{\limsup_{k\to\infty}\frac{\langle b,T_{k,X}^{-1}b\rangle}{L}
\le U(\alpha)=\alpha+(1-\alpha)\log(1-\alpha)<1.}
\tag{3}
\]

## 逐边平方与缺失的单位节点

对每条 \(n\to nq\) 边，有恒等式
\[
\Lambda(q)\left|\frac{a_n}{\sqrt q}-a_{nq}\right|^2
=\frac{\Lambda(q)}q|a_n|^2+\Lambda(q)|a_{nq}|^2
-2\frac{\Lambda(q)}{\sqrt q}\mathop{\rm Re}\overline{a_n}a_{nq}.
\tag{4}
\]
置
\[
P_X(n)=\sum_{q\le X/n}\frac{\Lambda(q)}q,
\qquad I(n)=\sum_{\substack{q\mid n\\q\text{ 素数幂}\\n/q\ge2}}\Lambda(q).
\]
每条边恰计一次。由于 \(\sum_{q\mid n}\Lambda(q)=\log n\)，
\[
I(n)=\log n-\Lambda(n)\mathbf1_{n\text{ 为素数幂}}.
\tag{5}
\]
注意对 \(n=q\) 没有从节点 \(1\) 进入的边。于是精确恒等式为
\[
\boxed{T_{k,X}[a]=
\sum_{n\le X}\bigl(D_k-P_X(n)-I(n)\bigr)|a_n|^2
+\sum_{\substack{n\ge2,\ q\text{ 素数幂}\\nq\le X}}
\Lambda(q)\left|\frac{a_n}{\sqrt q}-a_{nq}\right|^2.}
\tag{6}
\]
这里第一和的下限为 \(n=2\)。经典 Mertens 估计给出统一的
\(P_X(n)\le\log(X/n)+C_0\)。代入 \(D_k=L+O(1)\) 与 (5)，便得 (2)。固定 \(\alpha<1\) 后，右端对充分大 \(k\) 严格正。

## forcing 的逆度量

由 (2) 的 Loewner 逆序，
\[
\langle b,T_{k,X}^{-1}b\rangle\le
\sum_{\substack{q\le X\\q\text{ 素数幂}}}
\frac{\Lambda(q)^2/q}{(1-\alpha)L+\Lambda(q)-C}.
\tag{7}
\]
素数幂 \(q=p^r\)、\(r\ge2\) 的分子总和有界，故其对 (7) 的贡献为 \(O_\alpha(L^{-1})\)。对素数项，\(u_p=\log p\) 且
\[
\sum_{\log p\le u}\frac{\log p}{p}=u+O(1)
\qquad(u\ge0).
\tag{8}
\]
对 \(u/((1-\alpha)L+u-C)\) 作 Stieltjes 分部积分，误差为 \(O_\alpha(1)\)，得到
\[
\sum_{p\le X}\frac{(\log p)^2/p}{(1-\alpha)L+\log p-C}
=\int_0^{\alpha L}\frac{u}{(1-\alpha)L+u}\,du+O_\alpha(1)
=L U(\alpha)+O_\alpha(1).
\tag{9}
\]
因此 (3) 成立。\(\square\)

## 边界

此处矩阵的非对角边是完整旧算子半槽压缩中的真实**同号算术**边，但完整压缩还含异号算术、Archimedean 非对角和 polar 项。即使这个有限压缩的逆响应得到上界，也不能据此约束完整旧算子的逆响应，因为补空间 Schur 反馈可增大逆响应。式 (3) 不证明完整 Schur 非负、全尺度局部 Weil 正性或 RH。
