# 根补全 Farey 谱模的外层素数分数泄漏（候选）

日期：2026-09-29。依赖 [scratch 798](798-farey-critical-weight-rayleigh-constant-candidate.md) 的有限压缩谱模 \(u_p\)，以及 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的旧算术平移与偶极。本文检验该谱模作为完整旧奇算子试探函数时是否仍为近似特征向量；不假定 RH 或旧核正性。

## 候选命题

令 \(p\to\infty\) 沿奇素数，\(k=p^2\)、\(H=\log p\)、\(L=2H\)，\(\Delta=\frac12\log(1+p^{-2})\)，并取 scratch 798 的
\[
u_p=2^{-1/2}e_p+
\sum_{\substack{1\le b<a<p\\(a,b)=1}}\frac{w_{a/b}}{\sqrt{ab}},
\qquad
\|u_p\|^2=\frac{H^2}{2\zeta(2)}+O(H).
\tag{1}
\]
固定 \(0<\beta<1\)、\(1<Q<2\)，置
\[
\eta_Q=1-4\left(\log Q-1+\frac1Q\right)>0.
\]
令 \(Z_{p,\beta,Q}\) 是全部
\[
w_{q/b},\qquad p<q<Qp\text{ 为素数},\quad 2\le b\le p^\beta
\tag{2}
\]
的张成空间；对 \(q/b\notin\mathcal F_p\)，\(w_x\) 仍按 note 791 式 (1) 的同一偶极公式定义。\(P_Z\) 是其正交投影。则 \(Z_{p,\beta,Q}\perp u_p\)，而完整旧奇算子满足
\[
\boxed{
\liminf_{p\to\infty}
\frac{\|P_ZA_{k,-}u_p\|}{\|u_p\|}
\ge\eta_Q\sqrt{2\zeta(2)\,\beta\log Q}>0.
}
\tag{3}
\]
特别地，scratch 798 在 \(\mathbb Ce_p\oplus W_p\) 的常数级谱模不是完整旧奇算子的近似特征向量。式 (3) 只给出外层耦合下界，不判定完整旧算子的谱符号。

## 外层槽的正交性

对 (2) 的 \(x=q/b\)，有 \(1<x<p\)，且两物理中心 \(px,p/x\) 距旧空间端点至少 \(\gg p^{-1}\)（对固定 \(\beta<1\) 实际更远）。\(q\) 为素数且 \(b<q\)，故 \(q/b\) 既约。对两不同外层分数，清除分母后的两个同臂中心比含整数对 \(qb',q'b\)，其分子分母均小于 \(Qp^{1+\beta}<p^2\)；不同分数的对数间距因此大于 \(2\Delta\)。外层与 note 791 的 \(a/d\in\mathcal F_p\) 比较时，整数对为 \(qd,ab\)。若它们接近，较小者不超过 \(ab<p^{1+\beta}<p^2\)，故对数间距仍大于 \(2\Delta\)。异臂中心比是两个大于一的分数之积；外层 \(q/b\ge p^{1-\beta}\)，故异臂间距更大。于是 (2) 是与 \(e_p\) 及全部 \(W_p\) 正交的单位族。

## 整槽边与全部部分重叠

记 \(\mathcal R_k=-\sum_{n\text{ 素数幂}}c_n(T_n+T_n^*)\)，\(c_n=\Lambda(n)/\sqrt n\)。固定 \(x=q/b\) 如 (2)。与内层整数槽 \(w_b\) 有乘积关系 \(x b=q\)，因此一条精确整槽边给出
\[
\langle w_x,\mathcal R_kw_b\rangle=-c_q,
\qquad
c_q v_b=\frac{\log q}{\sqrt{qb}}.
\tag{4}
\]
其余整槽算术边与 \(u_p\) 的系数非负，故全部贡献非正。根 \(e_p\) 与 \(w_x\) 没有算术重叠：\(q/b\) 不是整数，且任意非整数近匹配的相对间距至少 \(1/q\gg\Delta\)。只需支付部分重叠所产生的正贡献。

对任意两个等宽偶极 \(\varphi_z,\varphi_{z'}\)，中心对数错位 \(s\in[0,2\Delta]\) 时，归一化自相关为
\[
\rho_\Delta(s)=
\begin{cases}
1-3s/(2\Delta),&0\le s\le\Delta,\\
-1+s/(2\Delta),&\Delta\le s\le2\Delta.
\end{cases}
\tag{5}
\]
每个算术近匹配在两个反射臂上各有半权，故整条关系的矩阵元为 \(-c_n\rho_\Delta(s)\)。令内层 \(y=a/d>1\)、\((a,d)=1\)、\(a,d<p\)。全部可能的算术比例关系只来自 \(x/y=qd/(ab)\)、\(y/x=ab/(qd)\) 和 \(xy=qa/(bd)\)。由于 \(ab,bd<p^{1+\beta}<p^2\)，非整槽重叠只能在下列两种式子之一发生：
\[
qd-nab=\pm1,
\qquad
qa-nbd=\pm1.
\tag{6}
\]
确实 \(qd,qa<Qp^2<2p^2\)，重叠容差为 \(2\Delta=\log(1+p^{-2})\)，所以非零整数差只能为 \(\pm1\)；反向 \(y/x\) 的可用分子 \(ab<p^2\) 只允许整槽相等。式 (6) 的非整槽错位满足
\(s\ge\log(1+1/(Qp^2))=(1/Q+o(1))p^{-2}>\Delta\)。故所有这类 \(\rho_\Delta(s)\le0\)，所产生的正算术矩阵元至多 \(c_n/2\)；第二种关系还可保留 \(-\rho_\Delta(s)\) 的精确位置权。

第一种式子 \(qd-nab=\pm1\) 若为部分重叠，必有 \(qd>p^2\)，从而 \(d>p/Q\) 和 \(a>d>p/Q\)；又 \(n<q/b<q\)。固定 \(n\) 和符号，\(nab\equiv\mp1\pmod q\) 唯一确定 \(a\pmod q\)，而 \(a<p<q\)，故至多一个内层父槽。每项的正贡献至多 \(C_Q\Lambda(n)/(p\sqrt n)\)。由 Chebyshev 上界及分部求和，
\[
P_{\rm ratio}(q,b)
\ll_Q\frac1p\sum_{n<q/b}\frac{\Lambda(n)}{\sqrt n}
\ll_Q\frac1{\sqrt{pb}}
=o\!\left(\frac H{\sqrt{qb}}\right)
\tag{7}
\]
对 \(q\in(p,Qp),b\le p^\beta\) 一致。

第二种式子 \(qa-nbd=\pm1\) 若为部分重叠，必有 \(a>p^2/q\)：由 \(2\Delta=\log(1+p^{-2})\)，无论 \(nbd=qa-1\) 还是 \(nbd=qa+1\)，重叠条件均迫使 \(qa>p^2\)。写 \(A=p^2/q\)。其错位 \(s=|\log(qa/(qa\mp1))|\) 满足 \(s\in[\Delta,2\Delta]\)，所以
\[
-\rho_\Delta(s)=1-\frac{s}{2\Delta}
=1-\frac Aa+O_Q(p^{-2})
\tag{8a}
\]
在全部实际重叠上均匀成立。固定符号与满足 \(b\mid qa\mp1\) 的 \(a\)，置 \(m=(qa\mp1)/b\)；全部可能父槽对应 \(d\mid m,n=m/d\)。舍去 \(d<a\)、互素及 prime-power 限制以外的非负项，利用
\(\sum_{d\mid m}\Lambda(m/d)=\log m\)，以及
\[
\frac{\Lambda(n)}{\sqrt{nad}}
=\frac{\Lambda(n)\sqrt b}{\sqrt{a(qa\mp1)}}
\le(1+o(1))\frac{\Lambda(n)}a\sqrt{\frac bq},
\]
得到两种符号的正部分总和
\[
P_{\rm prod}(q,b)
\le(1+o(1))\sqrt{\frac bq}
\sum_{\pm}\sum_{\substack{p^2/q<a<p\\b\mid qa\mp1}}
\left(1-\frac Aa\right)
\frac{\log((qa\mp1)/b)}a
+o\!\left(\frac H{\sqrt{qb}}\right).
\tag{8}
\]
每个符号的 \(a\) 位于一个模 \(b\) 的剩余类。函数
\(a\mapsto(1-A/a)/a\) 在 \([A,p]\) 上的上确界与总变差均为 \(O_Q(p^{-1})\)；因 \(b\le p^\beta=o(p)\)，模 \(b\) 求和的一步积分比较一致给出
\[
\sum_{\substack{A<a<p\\b\mid qa\mp1}}
\frac{1-A/a}{a}
\le\frac1b\left(\log\frac qp-1+\frac pq\right)+O_Q(p^{-1}).
\tag{9}
\]
又 \(\log((qa\mp1)/b)\le2H+O_Q(1)\)。将 (9) 代入 (8) 得
\[
P_{\rm prod}(q,b)
\le\left(4\left[\log\frac qp-1+\frac pq\right]+o(1)\right)
\frac H{\sqrt{qb}}
\le\left(4\left[\log Q-1+\frac1Q\right]+o(1)\right)
\frac H{\sqrt{qb}}.
\tag{10}
\]
函数 \(\log t-1+1/t\) 在 \(t>1\) 上严格递增，且
\(4(\log2-1/2)<1\)，所以 \(\eta_Q>0\)。式 (4)、(7)、(10) 合并，对 (2) 中所有 \(q,b\) 一致有
\[
\langle w_{q/b},\mathcal R_ku_p\rangle
\le-\left(\eta_Q-o(1)\right)
\frac H{\sqrt{qb}}.
\tag{11}
\]

## Archimedean 与 polar 不能抵消泄漏

把 note 791 的全体 Farey 中心与 (2) 的外层中心合并，刚证的间距仍大于 \(2\Delta\)。更强的是，对**任意**内层 \(a/d\) 与外层 \(q/b\)，同臂近比的整数对为 \(qd,ab\)，其中 \(ab<p^{1+\beta}\) 且因 \(q>p\) 为素数而不可能相等。因此同臂对数距离至少为 \(c p^{-(1+\beta)}\)；异臂距离至少为 \((1-\beta)H\)。令 \(\delta=c p^{-(1+\beta)}\)。note 791 式 (12) 的偶极双零矩交叉界及中心排序给出两族之间每行、每列的绝对和均为
\[
O\!\left(\sum_{j\ge1}\frac{\Delta^3}{\max(\delta,j\Delta)^3}\right)
=O\!\left((\Delta/\delta)^2\right)
=O(p^{-2(1-\beta)})=o(1).
\]
矩形 Schur 检验故给 \(\|P_ZG_kP_{W_p}\|=o(1)\)。根--外层 Archimedean 列也为 \(o(1)\)，因其中心距离至少 \((1-\beta)H\)。于是
\[
\|P_ZG_ku_p\|=o(\|u_p\|).
\tag{12}
\]
note 791 给 \(\|P_{\mathbb Ce_p\oplus W_p}s_k\|=O(p^{-3/2})\)；\(\|s_k\|=O(p^{1/2})\)，故 polar 项在 \(u_p\) 上的全空间范数为 \(O(H/p)=o(\|u_p\|)\)。

由正交性、(11) 与素数定理，
\[
\begin{aligned}
\|P_Z\mathcal R_ku_p\|^2
&\ge (\eta_Q-o(1))^2 H^2
\sum_{p<q<Qp}\frac1q\sum_{2\le b\le p^\beta}\frac1b\\
&=(\eta_Q-o(1))^2\,\beta\log Q\,H^2,
\end{aligned}
\tag{13}
\]
因为 \(\sum_{p<q<Qp}1/q=(\log Q+o(1))/H\)。用 (1)、(12) 和 polar 界从 \(P_ZA_{k,-}u_p\) 中减去非算术项，得到 (3)。\(\square\)

## 边界

式 (3) 关闭的是“把根补全 Farey 有限压缩谱模零延拓成完整旧核近似特征向量”这一步；它不关闭其他延拓或全尺度 Weil 正性。外层全部正的部分重叠已用 (6)--(10) 支付，仍须研究能否以真实算术补空间向量抵消该泄漏。
