# 根补全 Farey 图的常数级谱模（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的全 Farey 算术矩阵和一致 Archimedean 压缩、[note 780](../notes/780-all-prime-power-half-slots-give-nine-thirty-seconds-logarithmic-physical-inverse-response.md) 的单半槽对角。本文找出根补全的一个常数级谱模；不预设其为最低谱模。

## 候选命题

沿奇素数 \(p\to\infty\)，令 \(k=p^2\)、\(L=2\log p\)，采用 note 791 的 \(\mathcal F_p,W_p,C_p,A_{k,-}\)，并置 \(v_{a/b}=1/\sqrt{ab}\)。则
\[
\frac{\langle v,C_pv\rangle}{\|v\|^2}
=L-2\gamma_E+o(1),
\qquad
\frac{\langle v,P_{W_p}G_kP_{W_p}v\rangle}{\|v\|^2}
=D_k+\log2+o(1),
\tag{1}
\]
因此
\[
\boxed{\frac{\langle v,P_{W_p}A_{k,-}P_{W_p}v\rangle}{\|v\|^2}
=1+\gamma_E+\log(2/\pi)+o(1)>0.}
\tag{2}
\]
更强地，令 \(U_p=\mathbb C e_p\oplus W_p\)、\(u_p=2^{-1/2}e_p+\sum_{x\in\mathcal F_p}v_xw_x\)，\(B_p=P_{U_p}A_{k,-}P_{U_p}|_{U_p}\)。则
\[
\boxed{
\frac{\|(B_p-c_*)u_p\|}{\|u_p\|}\longrightarrow0,
\qquad
\operatorname{dist}(c_*,\operatorname{spec}B_p)\longrightarrow0,
\quad c_*=1+\gamma_E+\log(2/\pi)>0.
}
\tag{2a}
\]
这里的实际特征值属于根加 Farey 的**有限主压缩**；最低谱值及无限维补空间仍未确定。

## 算术平均

记 \(H=\log p\)、\(M(t)=\sum_{n\le t}\Lambda(n)/n\)。经典素数定理与 \(-\zeta'/\zeta\) 在 \(1\) 的 Laurent 常数给出
\[
M(t)=\log t-\gamma_E+o(1),\qquad t\to\infty,
\tag{3}
\]
且 \(M(t)-\log t\) 在 \(t\ge1\) 有界。note 791 式 (14) 可写成
\[
\frac{(C_pv)_{a/b}}{v_{a/b}}
=2\log(p-1)+\varepsilon((p-1)/a)+\varepsilon((p-1)/b)
-\Lambda(a)\mathbf1_{b=1},
\quad \varepsilon(t)=M(t)-\log t.
\tag{4}
\]
对任意固定 \(0<\alpha<1\)，\(a,b\le p^\alpha\) 上两个 \(\varepsilon\) 一致趋于 \(-\gamma_E\)。Möbius 反演给
\[
\|v\|^2=\frac{H^2}{2\zeta(2)}+O(H),\qquad
\sum_{\substack{a,b\le p^\alpha\\a>b,(a,b)=1}}\frac1{ab}
=\frac{\alpha^2H^2}{2\zeta(2)}+O_\alpha(H).
\tag{5}
\]
故外区的归一化 \(v^2\) 质量趋于 \(1-\alpha^2\)。\(\varepsilon\) 一致有界，先取 \(p\to\infty\) 再令 \(\alpha\uparrow1\)，得两项 \(\varepsilon\) 的加权平均各为 \(-\gamma_E+o(1)\)。缺失的单位节点项满足
\[
\frac{1}{\|v\|^2}\sum_{a<p}\frac{\Lambda(a)}a
=O(H^{-1})=o(1).
\]
式 (4) 加权平均即得 (1) 第一式。

对 (2a) 需要行误差的平方平均。定义根补全的非负算术矩阵
\[
\widetilde C_p=
\begin{pmatrix}0&(\sqrt2c_x)_x^{\!*}\\
(\sqrt2c_x)_x&C_p\end{pmatrix},
\qquad \widetilde v=(1/\sqrt2,(v_x)_x),
\quad c_x=\Lambda(x)/\sqrt x\text{ 若 }x\text{ 为整数素数幂，否则 }0.
\tag{5a}
\]
note 791 式 (4)、(14) 表明原来 \(b=1\) 的缺失单位节点项被根列**逐项精确抵消**：
\[
\frac{(\widetilde C_p\widetilde v)_{a/b}}{v_{a/b}}
=2\log(p-1)+\varepsilon((p-1)/a)+\varepsilon((p-1)/b),
\qquad
\frac{(\widetilde C_p\widetilde v)_{\rm root}}{1/\sqrt2}
=2M(p-1).
\tag{5b}
\]
在 \(a,b\le p^\alpha\) 上，(3) 使 (5b) 的 Farey 行比一致为 \(L-2\gamma_E+o(1)\)。在其外，行误差由 (3) 的有界性统一控制，而 (5) 的相对平方质量趋于 \(1-\alpha^2\)。根行也由 (3) 趋于 \(L-2\gamma_E\)。先取 \(p\to\infty\) 再令 \(\alpha\uparrow1\)，得到
\[
\frac{\|(\widetilde C_p-(L-2\gamma_E)I)\widetilde v\|}
{\|\widetilde v\|}\longrightarrow0.
\tag{5c}
\]

## Archimedean 平均

令 \(\Delta=\tfrac12\log(1+p^{-2})\)，\(\varphi_z\) 为 note 791 式 (1) 的两半反号偶极。note 780 式 (4) 给每个长度 \(\Delta\) 的归一化单半槽对角
\[
D_k+O(\Delta),\qquad D_k=L+1-\gamma_E-\log\pi.
\]
两个接触半槽的相反符号与相离核 \(-K(d)\) 使偶极内部交叉为
\[
\frac1\Delta\int_0^\Delta\!\int_0^\Delta K(s+t)\,ds\,dt
=\log2+O(\Delta),
\quad K(d)=\frac{e^{-d/2}}{1-e^{-2d}}=\frac1{2d}+O(1).
\tag{6}
\]
因此单个 \(\varphi_z\) 的 \(G_k\) 对角为 \(D_k+\log2+O(\Delta)\)，与位置无关。\(w_x=(\varphi_{px}+\varphi_{p/x})/\sqrt2\) 的两个中心距离至少 \(2\log x\gg p^{-1}\)；note 791 式 (12) 使其自交叉为 \(O(p^{-3})\)。所以全部 \(w_x\) 的对角均为 \(D_k+\log2+o(1)\)。

下面证明非对角的加权平均为 \(o(1)\)。固定 \(0<\alpha<1\)，令 \(I_{p,\alpha}\subset\mathcal F_p\) 由 \(a,b\le p^\alpha\) 定义。若 \(x=a/b\in I_{p,\alpha}\)，则其任一物理中心与不同 Farey 偶极的任一物理中心的对数距离至少为 \(c p^{-(1+\alpha)}\)。同臂由 \(|ad-bc|\ge1\)、\(bc<p^{1+\alpha}\) 得出；异臂距离至少 \(\log x\gg p^{-\alpha}\)。全部物理中心又两两相隔 \(>2\Delta\)。将其排序后，note 791 式 (12) 与最近距离 \(\delta\gg p^{-(1+\alpha)}\) 给出固定内区行的绝对和
\[
\sum_{y\ne x}|\langle w_x,G_kw_y\rangle|
\ll \sum_{j\ge1}\frac{\Delta^3}{\max(\delta,j\Delta)^3}
\ll \left(\frac\Delta\delta\right)^2
\ll p^{-2(1-\alpha)}.
\tag{7}
\]
任一 \(w_x\) 含两个物理中心，常数吸收此倍数。故内区非对角压缩的范数为 \(o(1)\)。全族非对角压缩的范数为 \(O(1)\)（note 791 式 (5)）；(5) 说明外区向量的相对范数趋于 \(\sqrt{1-\alpha^2}\)。以 Cauchy--Schwarz 支付内外和外外项，先取 \(p\to\infty\) 后令 \(\alpha\uparrow1\)，得
\[
\frac{\langle v,(P_{W_p}G_kP_{W_p}-(D_k+\log2)I)v\rangle}{\|v\|^2}=o(1).
\]
note 791 式 (5) 的 polar 投影范数为 \(O(p^{-3/2})\)，其 Rayleigh 贡献亦为 \(o(1)\)。式 (1)--(2) 遂成立。

上面的内区行和还给出向量范数版本。记 \(E_p=P_{W_p}G_kP_{W_p}-(D_k+\log2)I\)、\(P_I=P_{I_{p,\alpha}}\)、\(P_O=I-P_I\)。由 (7)，\(P_IE_p\) 的最大绝对行和为 \(o(1)\)；note 791 的全族行和界使它的最大绝对列和为 \(O(1)\)。矩形 Schur 检验给 \(\|P_IE_p\|=o(1)\)，对称性又给 \(\|E_pP_I\|=o(1)\)。所以
\[
\|E_pv\|\le o(1)\|v\|+O(1)\|P_Ov\|,
\]
而 (5) 使 \(\|P_Ov\|/\|v\|\to\sqrt{1-\alpha^2}\)。先取 \(p\to\infty\) 再令 \(\alpha\uparrow1\)，得到 \(\|E_pv\|/\|v\|\to0\)。根--Farey Archimedean 列范数为 \(O(p^{-2})\)，根对角为 \(D_k+\log2+o(1)\)。于是
\[
\frac{\|(P_{U_p}G_kP_{U_p}-(D_k+\log2)I)u_p\|}
{\|u_p\|}\longrightarrow0.
\tag{7a}
\]
polar 压缩范数由 note 791 式 (5) 与根投影界趋于零。结合 (5c)、(7a) 及
\(D_k+\log2-(L-2\gamma_E)=c_*\)，得到 (2a) 第一式；自伴有限矩阵的谱距离不超过任意单位向量的残差范数，得到第二式。

## 对根列反馈的量纲

note 791 式 (6) 的根列只在整数素数幂 \(x=n\) 上有算术系数 \(-\sqrt2\Lambda(n)/\sqrt n\)，所以
\[
\langle v,A_{k,-}e_p\rangle
=-\sqrt2\sum_{n<p}\frac{\Lambda(n)}n+O(p^{-2}\|v\|)
=-\sqrt2\log p+O(1).
\tag{8}
\]
记 \(c_*=1+\gamma_E+\log(2/\pi)>0\)。由 (2)、(5)、(8)，单用这个向量的逆度量变分商为
\[
\frac{|\langle v,A_{k,-}e_p\rangle|^2}{A_{k,-}[v]}
=\frac{4\zeta(2)}{c_*}+o(1).
\tag{9}
\]
若完整旧奇算子严格正，(9) 是补空间 Schur 反馈的一个合法但仅为常数量级的下界；note 791 的三素数向量已给出 \((48/127-o(1))L\)。因此这个正权方向本身不提高反馈的主阶系数。

## 精确边界

式 (2) 只计算了一个正权试探方向。即使其极限严格为正，其他方向的最低谱值、Farey 补空间 Schur 反馈以及完整局部 Weil 正性仍未判定。
