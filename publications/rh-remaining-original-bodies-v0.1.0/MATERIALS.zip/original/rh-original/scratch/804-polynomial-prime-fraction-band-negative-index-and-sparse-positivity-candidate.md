# 多项式素数分数带的负指标与稀疏正性（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的旧奇算子分解与偶极 Archimedean 估计，以及 [note 780](../notes/780-all-prime-power-half-slots-give-nine-thirty-seconds-logarithmic-physical-inverse-response.md) 的单槽对角。本文讨论真实算子的有限主压缩。同模型独立代理复核未发现承重错误；Claude 异源复核的订阅预检返回 auth_failed，因此本证明仍留在 scratch。

## 命题

固定 \(0<\delta<1/2\)、\(0<\theta_-<\theta_+<1\) 和 \(0<A_1<A_2\)。令 \(p\to\infty\) 沿奇素数，\(k=p^2\)、\(\Delta=\frac12\log(1+p^{-2})\)。在 \(u=\log t\) 坐标中，沿用 note 791 的
\[
\varphi_z=(2\Delta)^{-1/2}
\bigl(1_{(\log z-\Delta,\log z)}-1_{(\log z,\log z+\Delta)}\bigr),
\qquad w_x=\frac{\varphi_{px}+\varphi_{p/x}}{\sqrt2}.
\]
定义
\[
\mathcal X_p=
\left\{\frac qb:
\begin{array}{l}
q\ {\rm prime},\quad A_1p^{1+\delta}<q<A_2p^{1+\delta},\\
b\in\mathbb N,\quad \theta_-p<q/b<\theta_+p
\end{array}\right\},
\qquad Z_p=\operatorname{span}\{w_x:x\in\mathcal X_p\}.
\tag{1}
\]
记 \(M_p=\dim Z_p\)，\(B_p=P_{Z_p}A_{k,-}P_{Z_p}|_{Z_p}\)。则 \(\{w_x\}_{x\in\mathcal X_p}\) 是正交单位族，
\[
M_p\asymp_{\delta,A_1,A_2,\theta_\pm}\frac{p^{1+2\delta}}{\log p},
\tag{2}
\]
且完整真实旧奇主压缩的负指标满足
\[
\boxed{
n_-(B_p)\ll_{\delta,A_1,A_2,\theta_\pm}
\frac{M_p^2}{p^2}
\asymp\frac{p^{4\delta}}{\log^2p}
=o(M_p).}
\tag{3}
\]
更精确地，可写 \(B_p=B_{0,p}+P_p^{\rm prime}\)，其中
\[
B_{0,p}\succeq 2(\log p)I-O(1)I,\qquad
\operatorname{Tr}\bigl((P_p^{\rm prime})^2\bigr)
\ll M_p^2\frac{\log^2p}{p^2}.
\tag{4}
\]
\(P_p^{\rm prime}\) 只含异臂素数平移；(3) 不限制其最大负本征值。
事实上存在 \(E_p\subset Z_p\)，其余维数满足
\[
\boxed{
\operatorname{codim}_{Z_p}E_p\ll M_p^2/p^2,\qquad
B_p|_{E_p}\succeq
(\log p-O(1))I.}
\tag{4a}
\]

## 证明

由 (1)，每个分母 \(b\asymp p^\delta\)，且 \(q>b\) 为素数，故 \(q/b\) 已约分。两不同分数 \(q/b,q'/b'\) 的同臂整数对为 \(qb',q'b\ll p^{1+2\delta}=o(p^2)\)。它们不相等时对数距离大于 \(2\Delta=\log(1+p^{-2})\)；异臂中心距离至少 \(2\log(\theta_-p)\gg\Delta\)。所有偶极均完整位于 \((1,k)\)，故它们正交且单位化。

素数定理给 \(\#\{q\} \asymp p^{1+\delta}/\log p\)。对每个此类 \(q\)，(1) 的分母区间
\[
\frac q{\theta_+p}<b<\frac q{\theta_-p}
\]
含 \(\asymp p^\delta\) 个整数，故 (2) 成立。

令 \(H=\log p\)、\(D_k=2H+1-\gamma_E-\log\pi\)。不同物理中心的最小同臂对数间距为 \(\gg p^{-(1+2\delta)}\)，而 \(\Delta\asymp p^{-2}\)。note 791 式 (12) 的双零矩界及中心排序使非对角绝对行和为 \(o(1)\)。由 note 780 的单半槽对角 \(D_k+O(\Delta)\)，以及相邻反号半槽之间的
\[
\frac1\Delta\int_0^\Delta\!\int_0^\Delta K(s+t)\,ds\,dt
=\log2+O(\Delta),
\qquad K(d)=\frac{e^{-d/2}}{1-e^{-2d}},
\]
得到
\[
P_{Z_p}G_kP_{Z_p}=(D_k+\log2)I+o_{\rm op}(1).
\tag{5}
\]
每个偶极的 polar 投影为 \(O(p^{-5/2})\)；由 \(M_p\ll p^{1+2\delta}\) 得 polar 压缩范数 \(o(1)\)。

由于所有 \(x,y\in\mathcal X_p\) 都满足
\(\theta_-p<x,y<\theta_+p\)，平移 \(n\) 若产生同臂重叠，则
\(n\le(\theta_+/\theta_-)e^{2\Delta}\)，因而 \(n\le N_0\)，其中
\(N_0\) 仅依赖 \(\theta_\pm\)。所有这些低素数幂的整块算子范数满足
\[
\left\|P_{Z_p}\sum_{2\le n\le N_0}
\frac{\Lambda(n)}{\sqrt n}(T_n+T_n^*)P_{Z_p}\right\|
\le2\sum_{2\le n\le N_0}\frac{\Lambda(n)}{\sqrt n}=O(1).
\tag{6}
\]
这无须逐分母估计精确边。

异臂重叠则强制 \(\eta_0p^2\le n\le\eta_1p^2\)，其中
\(0<\eta_0<\eta_1<1\) 仅依赖 \(\theta_\pm\)。
这一高段的平方素数幂总权由素数定理给出
\[
\sum_{\sqrt{\eta_0} p\le\ell\le\sqrt{\eta_1} p}\frac{\log\ell}{\ell}
=\frac12\log(\eta_1/\eta_0)+o(1).
\]
对 \(j\ge3\)，因 \(n\ge\eta_0p^2\)，每项权为 \(O(H/p)\)；可用的 \((\ell,j)\) 对至多 \(O(p^{2/3}H)\) 个，总权 \(O(p^{-1/3}H^2)=o(1)\)。对这些高次幂逐项使用 \(\|T_n+T_n^*\|\le2\)，其整块压缩也只有 \(O(1)\) 范数。将 (5)、polar 项、全部低段平移及高段高次幂组成 \(B_{0,p}\)，得到 (4) 的更强下界 \(2H-O(1)\)。

剩余异臂素数边满足 \(n\asymp p^2\)。对任意 \(x,y\in\mathcal X_p\)，重叠要求 \(|\log(xy/n)|<2\Delta\)。允许的整数 \(n\) 落在长度 \(O_{\theta_\pm}(1)\) 的区间，因此至多 \(O_{\theta_\pm}(1)\) 个；每个权
\(\Lambda(n)/\sqrt n\ll H/p\)，自相关绝对值至多一。所以在正交基 \(\{w_x\}\) 中，
\[
|P_p^{\rm prime}(x,y)|\ll_{\theta_\pm} H/p.
\tag{7}
\]
逐项平方求和给 (4) 的迹界。

最后，若 \(B_p\) 有 \(d\) 维负子空间，则在该空间任意单位向量上
\(\langle v,P_p^{\rm prime}v\rangle\le-2H+O(1)\)。
按 min--max，\(P_p^{\rm prime}\) 至少有 \(d\) 个本征值不大于此负阈值。因而
\[
d(2-o(1))^2H^2
\le\operatorname{Tr}\bigl((P_p^{\rm prime})^2\bigr)
\ll M_p^2H^2/p^2,
\]
即 (3)。再令 \(E_p\) 为 \(P_p^{\rm prime}\) 中本征值大于
\(-H\) 的谱子空间。同一迹界给其余维数
\(O(M_p^2/p^2)\)，而 (4) 的 \(B_{0,p}\) 下界给 \(E_p\) 上的 (4a)。\(\square\)

## 可增长窄带的完整主压缩正性

同一证明还给出一个全正范围。令 \(T_p\to\infty\) 且
\[
T_p^2=o(\log p),
\tag{8}
\]
把 (1) 的素数区间改为 \(A_1pT_p<q<A_2pT_p\)，仍要求
\(\theta_-p<q/b<\theta_+p\)，并把相应压缩记为 \(B_p(T_p)\)。
此时 \(b\asymp T_p\)，素数定理给 \(M_p(T_p)\ll pT_p^2/\log p\)。
同臂整数对 \(qb',q'b\ll pT_p^2=o(p^2)\)，所以偶极仍正交，
而 (5) 的 Archimedean 误差为 \(O(T_p^4/p^2)=o(1)\)。
上述同臂有限平移与异臂高次素数幂的范数界
仍只有 \(O(1)\)。异臂素数矩阵满足 (7)，故
\[
\|P_p^{\rm prime}\|
\le\|P_p^{\rm prime}\|_{\rm HS}
\ll M_p(T_p)\frac{\log p}{p}
\ll T_p^2.
\]
polar 压缩仍为 \(o(1)\)。于是
\[
\boxed{
B_p(T_p)\succeq
\bigl(2\log p-O(T_p^2+1)\bigr)I
=(2-o(1))(\log p)I>0.}
\tag{9}
\]
式 (9) 是增长到 \(q\asymp pT_p\) 的真实旧奇**主压缩**正性；
完整算子仍可能因这批槽与其正交补的 Schur 反馈而失去正性。

## 极端负方向必须跨越线性多个槽

式 (7) 还给出一个与负指标不同的局部正性结论。存在只依赖固定参数的常数 \(c>0\)，使充分大 \(p\) 时，\(Z_p\) 中任意在至多 \(cp\) 个 \(w_x\) 上有非零坐标的向量 \(v\) 都满足
\[
\boxed{\langle v,B_pv\rangle\ge(\log p)\|v\|^2.}\tag{10}
\]
相应地，任何满足 \(\langle v,B_pv\rangle\le0\) 的非零向量必有
\[
\boxed{\|v\|_1^2\gg p\|v\|_2^2,\qquad
|\operatorname{supp}v|\gg p.}\tag{11}
\]
这里的 \(\ell^1,\ell^2\) 范数是相对于正交基 \(\{w_x\}\) 的坐标范数。因此所有阶数不超过 \(cp\) 的坐标主子矩阵都有对数量级正谱隙；特别地，固定或至多 \(c'p^{1-\delta}\) 个分子素数所生成的整块也有此性质，其中 \(c'>0\) 可依赖 (1) 的固定参数。

证明只用 (4) 与 (7)。由 (7) 取常数 \(C\) 使 \(|P_p^{\rm prime}(x,y)|\le C(\log p)/p\)。于是任意 \(v\) 满足
\[
\langle v,B_pv\rangle
\ge(2\log p-O(1))\|v\|_2^2
-\frac{C\log p}{p}\|v\|_1^2.
\tag{12}
\]
若 \(|\operatorname{supp}v|\le cp\)，Cauchy--Schwarz 给出 \(\|v\|_1^2\le cp\|v\|_2^2\)。取 \(c\le1/(2C)\)，对充分大 \(p\) 得 (10)。若左侧非正，(12) 反给 \(\|v\|_1^2\gg p\|v\|_2^2\)，再用 \(\|v\|_1^2\le|\operatorname{supp}v|\|v\|_2^2\) 得 (11)。每个固定 \(q\) 在 (1) 中只对应 \(O(p^\delta)\) 个分母，故最后一个断言也成立。\(\square\)

这仍是有限主压缩的结论。它把潜在的负本征值归于跨至少线性多个槽的异臂素数有符号相关；它不估计该相关的极端本征值，也不控制 \(Z_p^\perp\) 的 Schur 反馈。

## 边界

对固定 \(\delta>0\) 的多项式带，负指标比例趋零与稀疏正性均不代表 \(B_p\succeq0\)；一个离域的负方向就足以妨碍全尺度 Weil 正性。式 (9) 给出的也是有限主压缩正性，未控制其正交补 Schur 反馈。因此本文不证明全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 或 RH。
