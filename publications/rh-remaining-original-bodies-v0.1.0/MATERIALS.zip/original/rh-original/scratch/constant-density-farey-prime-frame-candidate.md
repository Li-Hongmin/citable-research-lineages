# 固定间隔 Farey 素数块的统一负协方差（候选）

> **量化更正（2026-09-30）：** 本稿的离散三角窗与素数框架论证可保留；但所引整族算子稿的次幂节省没有得到其文献输入支持，故下文式 (3)--(5a) 的次幂误差撤回。保留真实物理裁剪、改用任意固定对数幂误差的完整证明见 [更正候选](farey-fixed-power-operator-and-prime-frame-logarithmic-correction.md)。

日期：2026-09-30。本文将[稀疏块候选](sparse-farey-prime-frame-has-uniform-composite-cancellation-candidate.md)中的块间距从 \(C_0\log Y\) 改为固定整数 \(s\)。算术输入是[整族算子候选](farey-block-operator-cancellation-candidate.md)式 (1)、(8)--(10)，以及[note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md) 的短区间素数计数。整族算子候选及本文尚待异源复核；本文不估计完整 moving-\(N\) 余项。

固定 \(4/5<\alpha<1\)，令整数 \(Y\to\infty\)，
\[
D=\lfloor Y^\alpha\rfloor,\quad
B=\left\lfloor\frac{D^2}{1000Y}\right\rfloor,\quad
E_*=\frac{B^2D^2}{Y\log^2D},\quad
u_Y=\left(\frac{\log Y}{\log\log Y}\right)^{1/3}.
\tag{1}
\]
取一个充分大的**固定**正整数 \(s\)，置 \(t_j=\lfloor D/2\rfloor+jsB\)，保留 \(t_j+B\le3D/4\) 的 \(0\le j<M\)，并记 \(I_j=(t_j,t_j+B]\)。note 833 式 (1) 的真实物理裁剪频率 \(F_{q,N}\) 给出
\[
G_{j,N}=\sum_{p\in I_j\;\mathrm{prime}}F_{p,N},\qquad
T_{j,N}=\sum_{q\in I_j}F_{q,N},\qquad H_j=T_j-G_j.
\tag{2}
\]
这里 \(M\asymp Y/(sD)\to\infty\)。

**候选结论。** 存在只依赖 \(\alpha\) 与所选固定 \(s\) 的正数 \(c,C,c_\alpha\)，使每个复权列 \(w=(w_j)\) 满足
\[
cE_*\|w\|_2^2\le\|G_w\|_{\ell^2(Y<N\le2Y)}^2
\le CE_*\|w\|_2^2,\qquad
\|T_w\|_2^2\ll_\alpha E_*e^{-c_\alpha u_Y}\|w\|_2^2,
\tag{3}
\]
其中 \(G_w=\sum_jw_jG_j\)、\(T_w=\sum_jw_jT_j\)。因此
\[
\operatorname{Re}\langle G_w,H_w\rangle
=-\bigl(1+O_\alpha(e^{-c_\alpha u_Y/2})\bigr)\|G_w\|_2^2
\quad(w\ne0).
\tag{4}
\]
特别地，对 \(w_j=1\)，
\[
\|G_w\|_2^2\asymp_\alpha ME_*
\asymp_{\alpha,s}\frac{D^5}{Y^2\log^2Y},
\qquad
\langle G_w,H_w\rangle
=-\Theta_{\alpha,s}\!\left(\frac{D^5}{Y^2\log^2Y}\right).
\tag{5}
\]
再记整带总项 \(T_{\rm band}=\sum_{D/2<q\le D}F_{q,\cdot}\)，且此处取 \(G_w=G_{\rm sel}\) 为 \(w_j=1\) 的素数项。整族算子候选式 (2) 还给
\[
\langle G_{\rm sel},T_{\rm band}-G_{\rm sel}\rangle
=-(1+O_{\alpha,s}(e^{-c_\alpha u_Y/2}))\|G_{\rm sel}\|_2^2.
\tag{5a}
\]
所以负协方差在加入同一分母带的全部未选频率后依然成立。这比稀疏块候选式 (6) 多一因子 \(\log Y\)，并在固定比例的分母块上取得统一算术抵消；整带总项仍仅有次幂节省，未达到固定 \(\alpha>4/5\) 所需的 \(Y^{2+\varepsilon}\) 门。

## 离散三角窗给双侧框架界

对整数 \(L\ge1\)，定义
\[
\tau_L(n)=\frac1L\#\{(r,r'):0\le r,r'<L,\ r+r'=n\}.
\tag{6}
\]
其支撑是 \(0\le n\le2L-2\)，\(0\le\tau_L\le1\)，总质量为 \(L\)，且
\[
\left|\sum_n\tau_L(n)e(n\theta)\right|
=\frac1L\left|\sum_{r=0}^{L-1}e(r\theta)\right|^2
\le\min\left(L,\frac1{4L\|\theta\|_{\mathbb R/\mathbb Z}^2}\right).
\tag{7}
\]
若 \(\vartheta_1,\ldots,\vartheta_J\) 圆周间距至少 \(\rho\)，按某个中心两侧的第 \(k\) 个点逐行排序，式 (7) 的非对角绝对行和至多
\[
\frac1{4L}\,2\sum_{k\ge1}\frac1{(k\rho)^2}
=\frac{\pi^2}{12L\rho^2}.
\tag{8}
\]
因此对任意复系数 \(z_\nu\) 和整数位移 \(a\)，三角窗加权 Gram 的特征值均落在
\(L\pm\pi^2/(12L\rho^2)\)。

取 \(L=\lfloor Y/2\rfloor\)、\(a=Y+1\)。此时 \(\tau_L(N-a)\) 的支撑完全包含于 \(Y<N\le2Y\)，故该加权 Gram 给原区间 Gram 的下界。再取 \(L=Y\)、\(a=\lfloor Y/2\rfloor+1\)；对每个 \(Y<N\le2Y\) 都有
\(\tau_Y(N-a)\ge(Y-1)/(2Y)\)，故第二个加权 Gram 给原区间 Gram 的上界。只要 \(Y\rho\ge20\)，式 (8) 因而推出，例如，
\[
\frac{2Y}{5}\sum_\nu|z_\nu|^2
\le\sum_{Y<N\le2Y}\left|\sum_\nu z_\nu e(N\vartheta_\nu)\right|^2
\le3Y\sum_\nu|z_\nu|^2
\tag{9}
\]
对充分大的 \(Y\) 成立。该证明没有对 Dirichlet 核作产生 \(\log J\) 的逐行绝对和。

令 \(\theta_j=1/t_j\pmod1\)。正中心之间、负中心之间的间距至少 \(sB/D^2\)；正负中心之间的回绕距离至少 \(2/D\)，后者远大于 \(sB/D^2\)。故 \(\{\pm\theta_j\}_{j<M}\) 可取 \(\rho=sB/D^2\)，且 \(Y\rho\sim s/1000\)。固定选 \(s\) 充分大，使式 (9) 适用。

## 同一复权列上的真实素数臂

令 \(A_j=\sum_{p\in I_j,\ p\text{ prime}}p\)。对固定 \(\alpha>4/5\)，\(B\gg D^{3/4}\)，note 835 中使用的 Heath-Brown 短区间素数定理给所有这些块一致的
\[
A_j\asymp\frac{BD}{\log D},\qquad A_j^2/Y\asymp E_*.
\tag{10}
\]
置 \(P_N=\sum_jw_jA_j\cos(2\pi N/t_j)\)。在式 (9) 中对正、负中心分别取 \(z_{j,\pm}=w_jA_j/2\)。由于 \(Y<N\le2Y\)，
\[
\left\|\frac{P_N}{N}\right\|_2^2
\ge\frac1{20Y}\sum_j|w_jA_j|^2,
\qquad
\left\|\frac{P_N}{N}\right\|_2^2
\le\frac3{2Y}\sum_j|w_jA_j|^2.
\tag{11}
\]

对 \(p\in I_j\)，令 \(v_{j,p}=1/p-1/t_j\)，则 \(|v_{j,p}|\le4B/D^2\)。逐矩展开 \(e(N/p)\)，对每个矩系数用式 (9) 的上界，并以 Minkowski 对 \(m\ge1\) 求和，得到
\[
\left\|\frac1N\sum_jw_j\sum_{p\in I_j}p
\bigl[e(N/p)-e(N/t_j)\bigr]\right\|_2
\le\sqrt{\frac3Y}\left(e^{16\pi YB/D^2}-1\right)
\left(\sum_j|w_jA_j|^2\right)^{1/2}
<\frac1{10\sqrt Y}\left(\sum_j|w_jA_j|^2\right)^{1/2}.
\tag{12}
\]
对负指数取共轭相位但保留同一个 \(w_j\)，再取两个误差的半和，余弦相位误差也满足 (12)。式 (11) 的下界系数 \(1/\sqrt{20}>1/10\)，故有固定正间隙；对复 \(w\) 无需把 \(\sum_jw_jG_j\) 误写成某个实部。

对素数 \(p\)，\(f_\kappa(p)=-5p/(p-1)\)。写整族算子候选式 (8) 的 \(R_p(N)=C_p^{\rm full}(N)+pf_\kappa(p)\)，便有精确恒等式
\[
C_p^{\rm full}(N)=5p+\frac{5p}{p-1}+R_p(N).
\tag{13}
\]
整族算子候选式 (8)--(9) 的移动权间距证明限制到素数子集后仍给
\[
\left\|\sum_j\frac{w_j}{\pi N}
\sum_{p\in I_j}R_p(N)\cos(2\pi N/p)\right\|_2^2
\ll E_*\delta_Y^2\log^3Y\,\|w\|_2^2
=o(E_*\|w\|_2^2),
\tag{14}
\]
其中 \(\delta_Y=e^{-c_\alpha(\log Y)^{3/5}(\log\log Y)^{-1/5}}
+(D/Y)^2\log\log(3Y)\)。式 (14) 的平方范数在未归一化时为
\(O(BD^4\delta_Y^2\log Y/Y^2)\|w\|_2^2\)；因 \(D^2/(BY)\asymp1\)，其归一化正是所写的 \(O(\delta_Y^2\log^3Y)\)。整族算子候选式 (10) 同样给物理 collar 平方误差 \(O(E_*Y^{-1/3}\log^2Y)\|w\|_2^2\)。式 (13) 中余下的 \(5p/(p-1)=O(1)\) 用 \(\sum_j|w_j|\le\sqrt M\|w\|_2\) 逐 \(N\) 支付，其平方范数相对 \(E_*\|w\|_2^2\) 至多 \(O(M\log^2D/D^2)=o(1)\)。

由 \(F_{p,N}=-C_p(N)\cos(2\pi N/p)/(\pi N)\)、式 (10)--(14)，先得到 \(G_w\) 的双侧界，即 (3) 左式。整族算子候选式 (1) 对当前两两不交的块、同一个复权列 \(w\) 直接给 (3) 右式。最后 \(H_w=T_w-G_w\)，所以
\[
\bigl|\langle G_w,H_w\rangle+\|G_w\|_2^2\bigr|
\le\|G_w\|_2\|T_w\|_2
\ll_\alpha e^{-c_\alpha u_Y/2}\|G_w\|_2^2.
\tag{15}
\]
这同时证明 (4) 的实部断言。由 \(M\asymp D/(sB)\)、式 (10) 与 (3) 得 (5)。整族算子候选式 (2) 与 (5) 给 \(\|T_{\rm band}\|_2/\|G_{\rm sel}\|_2\ll_{\alpha,s}e^{-c_\alpha u_Y/2}\)，再次使用 (15) 的恒等式即得 (5a)。\(\square\)

**证据边界。** 三角窗引理及其与同一复权列的合并已在本稿完整写出；算术总块上界依赖仍在 `scratch/` 的整族算子候选，整条结果尚无异源复核。式 (5) 只针对固定比例的分母 \(1/q\) 块；其他分子、未选块及不同分母带可能改变完整余项。它既未证明完整 \(Y^{2+\varepsilon}\) signed covariance，也未证明或反驳 RH、全尺度局部 Weil 正性。
