# 完整两臂观察的奇数源正规形与承重非对角

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)--(15)、[scratch/863](863-direct-mobius-observation-channel-is-not-a-necessary-standalone-gate.md) 的完整物理行、[scratch/924](924-mobius-inversion-moves-the-full-observation-to-cofactors-at-least-three.md) 的真实 Möbius 反演及 [scratch/925](925-k3-k4-observation-cross-has-no-exact-collision-and-reduces-to-two-affine-mobius-forms.md) 的四倍数行消去。本稿只用真实的 \(\mu*1=\delta_1\) 与 \(\mu(2u)=-\mu(u)\)，把两条承重物理臂写成同一奇数源的两种奇数 cofactor 核，并绝对支付源对角。它不估计剩余的不同源 signed covariance，也不证明 RH。

## 逐物理行的精确式

令 \(\ell=\log2\)，对 \(n>2\) 定义
\[
c(n)=2\mathbf1_{2\mid n}(\Lambda(n/2)-1)
-4\{\Lambda(n)-1+\ell\mu(n)\},\qquad
b(n)=4-2\mathbf1_{2\mid n}.
\]
对奇数 \(t\ge3\) 置
\[
K_o(t)=-4\log(t/2),\qquad K_e(t)=2\log t-4\ell
=2\log(t/4).                                                     \tag{1}
\]
则每个奇数 \(v>1\) 都满足
\[
\boxed{\begin{aligned}
c(v)-4&=\sum_{\substack{u\mid v\\v/u\ge3}}\mu(u)K_o(v/u),\\
c(2v)-2&=\sum_{\substack{u\mid v\\v/u\ge3}}\mu(u)K_e(v/u).
\end{aligned}}                                                   \tag{2}
\]
全部 \(u\) 与 \(v/u\) 自动为奇数。此外，若 \(4\mid n\)，则
\[
c(n)-2=-2\ell\,\mathbf1_{n=2^j,\ j\ge2}.                     \tag{3}
\]
式 (2) 的两行不是分别待证的独立算术门；它们在同一观察窗中使用不同的底数区间。
二进配对还改变了 cofactor 的符号结构：\(K_o(t)<0\) 对全部奇数 \(t\ge3\)，但
\(K_e(3)=2\log(3/4)<0\)，而 \(K_e(t)>0\) 对全部奇数 \(t\ge5\)。
因此 scratch/924 中每个 \(\kappa(k)<0\) 的事实，不能直接变成完整偶臂的同号性。

证明：对奇数 \(v>1\)，\(\Lambda(v)=\sum_{u\mid v}\mu(u)\log(v/u)\)。\(\mu*1=\delta_1\) 又给
\(\mu(v)=-\sum_{u\mid v,\,u<v}\mu(u)\)。由于 \(v\) 为奇数，每个真 cofactor 至少为 \(3\)。将这两式代入
\(c(v)-4=-4\Lambda(v)-4\ell\mu(v)\) 得第一行。
又因 \(\Lambda(2v)=0\)、\(\mu(2v)=-\mu(v)\)，有
\(c(2v)-2=2\Lambda(v)+4\ell\mu(v)\)；同样代入给第二行。
若 \(4\mid n\) 且不是二的幂，则 \(\mu(n)=\Lambda(n)=\Lambda(n/2)=0\)，故 \(c(n)=2\)；二的幂直接代入得到 \(2-2\ell\)。证毕。

另一种不依赖上述两行计算的核对是：在 scratch/924 式 (3) 中，对 \(n=2v\) 将奇数除数 \(u\) 与偶数除数 \(2u\) 配对。奇 cofactor \(t=v/u\ge3\) 的合并系数为
\[
\kappa(2t)-\kappa(t)
=-2\log t+4\log(t/2)=K_e(t),
\]
而 \(t=1\) 时 \(\kappa(2)-\kappa(1)=0\)。奇数行直接使用 \(\kappa(t)=K_o(t)\)。这也核准了式 (2) 与原始 cofactor 公式的符号。

## 观察频带与精确源支撑

令 \(M=2Y\)，\(Y^{1/5}\le H\le Y^{1/4}\)，固定 \(\psi\in C_c^3((1,2))\)，\(\phi(x)=\psi(x)/x\)，并写 \(e(x)=e^{2\pi i x}\)。定义
\[
\begin{aligned}
\mathcal K^o_h(u)&=\frac1M\sum_{\substack{t\ge3\ {\rm odd}\\M<ut<2M}}
K_o(t)\phi(ut/M)e(-hut/M),\\
\mathcal K^e_h(u)&=\frac1M\sum_{\substack{t\ge3\ {\rm odd}\\M<2ut<2M}}
K_e(t)\phi(2ut/M)e(-2hut/M),
\end{aligned}                                                     \tag{4}
\]
且 \(\mathcal B_h=M^{-1}\sum_{M<m<2M}b(m)\phi(m/M)e(-hm/M)\)。note 849 的真实观察包于是对每个整数 \(h\) **精确**满足
\[
\boxed{\quad
\mathcal A_h
=\mathcal B_h
+\sum_{\substack{u<2M/3\\u\ {\rm odd}}}\mu(u)\mathcal K^o_h(u)
+\sum_{\substack{u<M/3\\u\ {\rm odd}}}\mu(u)\mathcal K^e_h(u)
-\frac{2\ell}{M}
\sum_{\substack{j\ge2\\M<2^j<2M}}
\phi(2^j/M)e(-h2^j/M).
\quad}                                                          \tag{5}
\]
这两个源范围来自 \(t\ge3\)：奇数行 \(ut<2M\) 给 \(u<2M/3\)，而 \(v_2=1\) 行 \(2ut<2M\) 给 \(u<M/3\)。末项至多一个二的幂。特别地，在式 (5) 中没有当前物理窗内的直接 \(\mu(m)\) 源、没有偶数源，也没有 cofactor \(1,2\)。

### 完整物理行的三角可观测性

式 (2) 还给出一个与频带估计不同的精确结论。对任意两个定义在奇数上的复序列 \(a,a'\)，把 (2) 右侧的 \(\mu(u)\) 分别换成 \(a(u),a'(u)\)，仅比较 \(M<n<2M\) 的所有奇数行与 \(v_2(n)=1\) 行。若
\[
a(u)=a'(u)\quad(u\le M/6,\ u\ {\rm odd}),
\]
且两组完整物理行逐点相同，则
\[
\boxed{\quad a(u)=a'(u)
\quad\text{对每个奇数 }u<2M/3.\quad}                         \tag{5a}
\]
反之，所有 \(u\ge2M/3\) 的源列在该窗口上严格为零，所以此阈值对源支撑是尖锐的。

证明令 \(z=a-a'\)，按奇数 \(u\) 从小到大归纳。若 \(M/6<u<M/3\)，则 \(n=6u\in(M,2M)\) 且 \(v_2(n)=1\)。该偶臂行的每个源 \(d\) 都满足 \(d\le(3u)/3=u\)，其中 \(d=u\) 的系数为 \(K_e(3)=2\log(3/4)\ne0\)。所有更小 \(d\) 的 \(z(d)\) 已为零，故这一行强制 \(z(u)=0\)。若 \(M/3<u<2M/3\)，则 \(n=3u\in(M,2M)\) 是奇数行；每个源 \(d\le u\)，而 \(d=u\) 的系数为 \(K_o(3)=-4\log(3/2)\ne0\)，同样强制 \(z(u)=0\)。所选的 \(6u\) 行与 \(3u\) 行分别为偶、奇物理行，互不重复。因为 \(M=2Y\) 为偶数，\(M/3\) 即使为整数也必为偶数，故两区间没有漏掉奇数源。最后 \(t\ge3\) 使 \(u\ge2M/3\) 的两臂都无法落入开窗口，证毕。

这个逐行逆映射对**未经 \(\psi\) 截断的完整系数行**甚至有一致的 \(\ell^2\) 稳定性。令 \(S=\{u\ {\rm odd}:M/6<u<2M/3\}\)，并令 \(y_u\) 为差序列 \(z\) 在上面选定的 \(6u\) 或 \(3u\) 行的值；假设 \(z(d)=0\) 对所有奇数 \(d\le M/6\)。写 \(D_u=K_e(3)\) 于前半区、\(D_u=K_o(3)\) 于后半区。上面的逐行公式恰为
\[
D_u^{-1}y_u=z(u)+(Nz)_u,\qquad
(Nz)_u=\sum_{\substack{t\in\{5,7,9,11\}\\d=3u/t\in S\cap\mathbb N}}
\frac{K_{e\text{ 或 }o}(t)}{D_u}\,z(d).                 \tag{5b}
\]
事实上所有未知源 \(d>M/6\) 的 cofactor 满足 \(t=3u/d<12\)，且为奇数；若不为 \(3\)，只能取列出的四值。每个非对角边使 \(d\le3u/5\)。因 \(u<2M/3\) 而 \((3/5)^3(2M/3)<M/6\)，严格有 \(N^3=0\)。设
\(R=\max_{t\in\{5,7,9,11\}}\max(|K_o(t)/K_o(3)|,|K_e(t)/K_e(3)|)\)。矩阵 \(N\) 每行至多四个、每列对每个 \(t\) 至多一个非零元，故 Schur 界给 \(\|N\|_{2\to2}\le4R\)。于是
\[
\boxed{\quad
\|z\|_{\ell^2(S)}
\le\frac{1+4R+16R^2}{\min(|K_o(3)|,|K_e(3)|)}
\|y\|_{\ell^2(S)}.
\quad}                                                        \tag{5c}
\]
常数与 \(M\) 无关。此界只涉及全部原始物理行；\(\psi\in C_c^3((1,2))\) 会遮住窗口两端的某些选定行。更明确地，对任意固定 \(\psi\) 和 \(H\le Y^{1/4}\)，式 (4) 从 \(S\) 上任意复源 \(z\) 到 \(H/2\le|h|\le4H\) 的频带向量是线性映射；其定义域维数 \(|S|=M/4+O(1)\)，值域维数只有 \(O(H)=o(M)\)。故这个**单频带映射**至少有 \(M/4-O(H)\) 维精确核，不能继承 (5c) 的逆界。此维数陈述只针对任意源的线性空间，不构造另一个满足真实全域 Möbius 反演的算术函数。

置 \(D=\lfloor M/(32H)\rfloor\)。对 \(H/2\le|h|\le4H\)，有
\[
\boxed{\quad
\mathcal A_h
=\sum_{\substack{D<u<2M/3\\u\ {\rm odd}}}
\mu(u)\bigl(\mathcal K^o_h(u)+\mathcal K^e_h(u)\bigr)
+O_\psi(H^{-3}\log^2M+M^{-1}).
\quad}                                                          \tag{6}
\]
在此式中 \(u\ge M/3\) 的偶臂自然为空。对任何固定有界非负、支撑于 \(1/2\le|x|\le4\) 的权 \(w_H(h)=v(h/H)\)，误差的带通平方和为
\[
O_{\psi,v}(H^{-5}\log^4M+H/M^2)=o(H^4/M).                   \tag{7}
\]

证明：\(\mathcal B_h\ll_\psi H^{-3}\) 由整数格与偶数格上的 Poisson 求和得到。对 \(u\le D\)，奇臂中令 \(X=M/u\ge32H\)，偶臂中令 \(X=M/(2u)\ge16H\)。两个内和都是奇数 \(t\) 格上的
\((a\log X+b\log(t/X)+c)\phi(t/X)e(-ht/X)\)。奇格 Poisson 别名出现在 \(h+jX/2\)，\(j\in\mathbb Z\)；在 \(H/2\le|h|\le4H\) 内，其距离零为 \(\gg H(1+|j|)\)。\(\phi\) 与 \((\log x)\phi(x)\) 的 Fourier 变换由三次分部积分为 \(O_\psi((1+|\xi|)^{-3})\)。计入奇格密度 \(X/2\) 与归一化 \(1/M\)，每个源的两臂分别为 \(O_\psi(\log M/(uH^3))\)。对 \(u\le D\) 求和花 \(O_\psi(H^{-3}\log^2M)\)；二的幂项为 \(O_\psi(M^{-1})\)，给 (6)。频带只有 \(O_v(H)\) 个整数，平方后给 (7)，因 \(M/H^9\ll M^{-4/5}\)。

## 源对角已在目标以下

若 \(w_H\) 如上且 \(\mathcal K_h(u)=\mathcal K^o_h(u)+\mathcal K^e_h(u)\)，则
\[
\boxed{\quad
\sum_{u>D}\mu(u)^2\sum_h w_H(h)|\mathcal K_h(u)|^2
\ll_{\psi,v}\frac{H^2\log^2(2H)}M
=o(H^4/M).
\quad}                                                          \tag{8}
\]
事实上 \(u>D\) 时两臂总共仅有 \(O(M/u)\) 个活动 cofactor，且 \(|K_o(t)|+|K_e(t)|\ll\log(2M/u)\)，故 \(|\mathcal K_h(u)|\ll_\psi\log(2M/u)/u\)。频率数为 \(O(H)\)，于是左侧至多
\(O_\psi(H\sum_{u>D}u^{-2}\log^2(2M/u))\ll H D^{-1}\log^2(2M/D)\)，即 (8)。

## 剩余算术判断

精确的剩余式为
\[
\mathfrak C_{\rm odd}
=\sum_{\substack{D<u,v<2M/3\\u,v\ {\rm odd},\ u\ne v}}
\mu(u)\mu(v)
\sum_h w_H(h)\mathcal K_h(u)\overline{\mathcal K_h(v)}.
\tag{9}
\]
由 (7)--(8) 与带权 \(\ell^2\) 三角不等式，\(\sum_h w_H(h)|\mathcal A_h|^2=O(H^4/M)\)
当且仅当 \(\mathfrak C_{\rm odd}=O(H^4/M)\)；这里的 \(O\) 是上界，且 \(\mathfrak C_{\rm odd}\) 的下界由非负总能量与 (8) 自动给出。这个等价只在目标量级成立，不声称替换前后的 Gram 差无条件为 \(o(H^4/M)\)。

偶臂只用 \(u<M/3\)，而 \(4\mid m\) 行已逐点消去。式 (9) 不允许把奇、偶物理臂或单个 cofactor 交叉分别当作必须达到固定幂的门：其交叉可能在完整和中抵消。现有一阶短和只能给任意对数幂节省，仍缺 \(H^4/M\) 的固定幂二点估计。

### 小约化比例的统一绝对支付

式 (9) 的源指标比 scratch/859 的未配对 \(d,e\) 更窄；同一初等计数在这里也直接成立。令
\[
R=\left\lfloor\frac{H^2}{\log^4M}\right\rfloor,
\qquad g=(u,v),\quad a=u/g,\quad b=v/g.
\]
则对任意 \(|\mu(u)|\le1\)、\(|\mu(v)|\le1\)，无需使用其符号，
\[
\boxed{\quad
\sum_{\substack{D<u,v<2M/3\\u,v\ {\rm odd},\ u\ne v\\
\max(a,b)\le R}}
\left|\sum_h w_H(h)\mathcal K_h(u)
\overline{\mathcal K_h(v)}\right|
\ll_{\psi,v}\frac{H^4}{M\log^2M}
=o(H^4/M).
\quad}                                                        \tag{10}
\]
证明由 (8) 前的逐源估计和频率个数得到
\[
\left|\sum_h w_H(h)\mathcal K_h(u)
\overline{\mathcal K_h(v)}\right|
\ll_{\psi,v}\frac{H\log^2(2H)}{uv}.
\]
固定互素奇数 \(a,b\) 并写 \(u=ag,v=bg\)。由于两源都大于 \(D\)，有 \(g>D/\min(a,b)\)。在 \(\max(a,b)\le R\ll D\) 下，
\[
\sum_{g>D/\min(a,b)}\frac1{(ag)(bg)}
\ll\frac1{D\max(a,b)}.
\]
对 \(\max(a,b)=q\le R\) 求和时，候选有序 \((a,b)\) 至多 \(2q\) 个，因而 \(\sum_{a,b}1/\max(a,b)\ll R\)。总成本为
\(O_{\psi,v}(H\log^2(2H)R/D)\ll H^2R\log^2M/M\)，取上述 \(R\) 即 (10)。由于所有可能的整数比 \(u/v\) 都不超过 \((2M/3)/D=O(H)\ll R\)，(10) 还绝对支付全部 \(u\mid v\) 或 \(v\mid u\) 的源对。

因此式 (9) 可在目标量级内只保留
\(\max(u/(u,v),v/(u,v))>R\) 的奇数源对；它们的净 signed 和仍没有固定幂上界。此处只是把新正规形的可绝对支付范围写清，不把它误称为实际剩余门已闭合。

### 每条既约比例上的真实符号恒定

上述未付项还具有一个精确的算术符号分类。对互素奇数 \(a,b\) 及任意 \(g\ge1\)，Möbius 乘法性逐点给
\[
\boxed{\quad
\mu(ag)\mu(bg)
=\mu(ab)\mu(g)^2\mathbf1_{(g,ab)=1}.
\quad}                                                        \tag{11}
\]
若 \((g,ab)=1\)，两次乘法性直接证明 (11)；若不互素，则因 \((a,b)=1\)，\(ag\) 或 \(bg\) 至少有一个平方因子，左侧为零。因而每一条固定既约源比例 \(a:b\) 上，非零的真实 Möbius 乘积始终取同一符号 \(\mu(ab)\)，不会在共同因子 \(g\) 上发生 Möbius 符号抵消。

记 \(G_{u,v}=\sum_h w_H(h)\mathcal K_h(u)\overline{\mathcal K_h(v)}\)。与 (10) 合并后，尚未支付的和精确写成
\[
\boxed{\quad
\sum_{\substack{a,b\ {\rm odd},\ (a,b)=1,\ a\ne b\\\max(a,b)>R}}
\mu(ab)
\sum_{\substack{g\ge1\ {\rm odd},\ (g,ab)=1\\D<ag,bg<2M/3}}
\mu(g)^2G_{ag,bg}.
\quad}                                                        \tag{12}
\]
这仍需跨既约比例的符号消去，或利用 \(G_{ag,bg}\) 的带通振荡；固定比例内的 \(\mu(g)\) 符号不能提供所缺的固定幂。式 (12) 是实际余项的算术分类，不是其上界。
这里必须限制 \(g\) 为奇数，因为式 (9) 的两条源指标均为奇数；若允许偶数 \(g\)，式 (12) 会额外计入并不存在的偶数源对。
对平滑观察频带，[scratch/928](928-large-gcd-tail-of-the-complete-odd-source-two-arm-gram.md) 进一步把完整两臂未付项绝对缩到 \(g\lesssim M\log^2M/H^3\)；小共同因子的 signed 和仍未证明目标上界。
