# 任意对数精度的素数短和与逐 cofactor 界仍不推出四素数目标

日期：2026-10-01。依赖 [scratch/878](878-prime-cofactor-tube-self-cancels-through-bandpass-sidelobes.md) 式 (19)--(20)、(23)--(30) 的真实顶端素数管，以及 [scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 式 (7) 所核准的全区间短素数和。本例只反驳一种将短区间边际估计和逐 \(q\) 能量提升为完整跨 \(q\) 界的推理；所造系数不是原始 Möbius 系数，不反驳真实门、局部 Weil 正性或 RH。

## 命题

固定 \(1/5\le\alpha<1/4\)，令 \(H=\lceil Y^\alpha\rceil\)、\(M=2Y\)，并取 scratch/878 的非负非零 \(\psi,J=[a,b]\) 与顶端真实素数物理类
\[
 \mathcal T^\top=\{m=pq\in MJ:p,q\text{ 为素数},\ H/2<q\le H\},
 \qquad
 a(m)=\frac{4\log(q/2)}M\phi(m/M)>0.
\tag{1}
\]
令 \(h_0\) 为任一满足 \(H\le h_0\le2H\) 的整数，取
\(\delta_M=\exp(-\sqrt{\log M})\)。存在相位 \(\theta_M\in[0,2\pi)\)，使
\[
 a_\theta(m)=a(m)\{1+\delta_M\cos(2\pi h_0m/M+\theta_M)\}
 \quad(m\in\mathcal T^\top)
\tag{2}
\]
同时具有下列性质：

1. 支撑仍全由真实的四素数配对 \((pq,p'r)\) 构成，且 \(0<a_\theta(m)\le2a(m)\)。若把同一个因子乘到物理行的每个高除数源，scratch/878 式 (23) 的源过滤逐对完整保留，所有源项的相对符号不变。
2. 对每个 \(q\in(H/2,H]\) 及每个长度 \(T\asymp M/H^2\) 的允许素数窗口 \(I_q\)，加权素数计数保持任意固定对数精度：对每个固定 \(A>0\)，一致于 \(q,I_q,\theta\)，
   \[
    \sum_{\substack{p\in I_q\\p\ {\rm prime}}}
      \{1+\delta_M\cos(2\pi h_0pq/M+\theta)\}\log p
    =|I_q|+O_A(|I_q|\log^{-A}M).
   \tag{3}
   \]
   逐 cofactor 完整带通能量也保持
   \[
    \sum_{\substack{H/2<q\le H\\q\ {\rm prime}}}
    \sum_h w_H(h)
    \left|\sum_{p:pq\in MJ}a_\theta(pq)e(-hpq/M)\right|^2
    \ll_{\psi,J,s}\frac1H
    \ll\frac{H^4}{M}.
   \tag{4}
   \]
3. 然而整个顶端管的频带能量满足
   \[
    \boxed{\quad
    \sum_h w_H(h)
      \left|\sum_{m\in\mathcal T^\top}a_{\theta_M}(m)e(-hm/M)\right|^2
    \gg_{\psi,J,s}\frac{\exp(-2\sqrt{\log M})}{\log^2M}
    \gg\frac{H^4}{M}.
    \quad}
   \tag{5}
   \]
   最后的 \(\gg\) 表示左边与右边之比趋于无穷。

若按 (2) 的行倍率同时乘到各源项，记 scratch/878 式 (23)--(26) 对这个修改后模型定义的原门四素数交叉为 \(\mathfrak C_{4,\theta_M}\)。则更强地有
\[
 \boxed{\quad
 \mathfrak C_{4,\theta_M}
 =\sum_h w_H(h)\left|\sum_{m\in\mathcal T^\top}
 a_{\theta_M}(m)e(-hm/M)\right|^2+O_{\psi,J,s}(H^4/M)
 \gg\frac{\exp(-2\sqrt{\log M})}{\log^2M}.
 \quad}
\tag{5a}
\]
因此，真实素数支撑、源过滤透明性、所有允许短窗口的任意对数幂 PNT 误差、以及逐 \(q\) 的目标量级能量，即使同时给出，也不足以推出**原过滤形状**的四素数整管固定幂目标。若真实目标为真，其证明必须使用未被 (2) 保留的额外算术信息，或借助其他物理族的联合相消。

## 证明

\(\delta_M\to0\)，故 (2) 的倍率严格在 \((0,2)\) 内，支撑与源过滤关系不变。对于 \(q\asymp H\)，所用素数窗口位于 \(x\asymp M/H\)、长度 \(T\asymp M/H^2\)。同 scratch/878 式 (12)，统一有
\(x^{7/12+1/20}\ll T\ll x^{1-1/20}\)。
scratch/862 式 (7) 给未扰动的 \(\Lambda\) 短和
\(\sum_{p\in I_q}\log p=T+O_A(T/\log^A M)\)；素数幂总量为 \(O(\sqrt x\log^2x)=o(T/\log^A M)\)。
扰动项的绝对值至多 \(\delta_M\sum_{p\in I_q}\log p\ll\delta_MT\)。
由于 \(\delta_M=o(\log^{-A}M)\) 对每个固定 \(A\) 成立，(3) 得证。

固定 \(q\) 时，scratch/878 式 (19) 的证明仅使用物理系数的绝对上界及核在 \(q\mathbb Z\) 上的非别名行和。用 \(a_\theta\le2a\) 重复该证明，所得单 \(q\) 界至多放大四倍；式 (20) 对 \(q\in(H/2,H]\) 求和即得 (4)。最后 \(H^5\gg M\)，所以 \(H^{-1}\ll H^4/M\)。

记未扰动管的总质量
\[
 S=\sum_{m\in\mathcal T^\top}a(m)\asymp_{\psi,J}\frac1{\log M}
\tag{6}
\]
（scratch/878 式 (30)），并置
\(F_j=\sum_{m\in\mathcal T^\top}a(m)e(-jh_0m/M)\)，其中 \(F_0=S\)。
在频率 \(h_0\)，(2) 的 Fourier 系数精确为
\[
 F_\theta(h_0)=F_1+\frac{\delta_M}{2}
       \left(e^{i\theta}S+e^{-i\theta}F_2\right).
\tag{7}
\]
对 \(\theta\in[0,2\pi)\) 平均平方模，交叉谐波积分均为零，故
\[
 \frac1{2\pi}\int_0^{2\pi}|F_\theta(h_0)|^2\,d\theta
 =|F_1|^2+\frac{\delta_M^2}{4}(S^2+|F_2|^2)
 \ge\frac{\delta_M^2S^2}{4}.
\tag{8}
\]
选取达到该平均下界的某个 \(\theta_M\)。由于 \(w_H(h_0)=1\)，(6)--(8) 给 (5) 的第一下界。对固定 \(\alpha<1/4\)，
\(H^4/M=M^{4\alpha-1+o(1)}\) 是固定负幂，而
\(\delta_M^2/\log^2M=M^{-o(1)}\)；所以二者之比趋于无穷。

最后核对原过滤门。scratch/878 式 (26) 比较 \(\mathfrak C_4\) 与完整能量时，遗漏项只有同 \(q\)、共享 \(p\)、物理近差及远差，分别由其式 (19)--(20)、共享 \(p\) 绝对行和、式 (31) 及 scratch/860 式 (3) 支付。这些证明全都逐项取绝对值。行倍率在 \((0,2)\) 内，所以每个遗漏上界至多放大四倍，合计仍为 \(O_{\psi,J,s}(H^4/M)\)；不同 \(q\)、不同 \(p\) 的四个源项仍由 scratch/878 式 (23) 完整保留。由 (5) 的超目标下界，得到 (5a)。\(\square\)

## 适用边界

(2) 是故意加入的非算术行权；真实 \(a_D(pq)\) 没有这个自由度。本例准确排除的是只调用 (3)、(4) 与支持结构的通用推理，并不排除利用原始 \(\Lambda\)、\(\mu\) 恒等式或跨物理族抵消的证明。尤其不能把 (5) 读成真实四素数管的下界。
