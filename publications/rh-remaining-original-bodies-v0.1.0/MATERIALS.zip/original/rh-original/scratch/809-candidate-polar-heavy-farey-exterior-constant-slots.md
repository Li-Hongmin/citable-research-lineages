# 候选：Farey 外区与小分子内区常值槽各有增长谱隙

日期：2026-09-30。证明草稿，尚待异源独立复核，不列为已晋级定理。依赖 [note 807](../notes/807-natural-farey-constant-mode-has-two-thirds-logarithmic-energy.md) 的带符号算术图及外区 Dirichlet 下界、[note 808](../notes/808-full-farey-constant-polar-projection-has-positive-logarithmic-energy.md) 的 polar 投影质量、[note 806](../notes/806-all-bounded-farey-constant-slots-have-loglog-gap-and-positive-joint-compression.md) 的全 Farey 阶跃混合界，以及 [note 804](../notes/804-full-farey-step-dipole-compression-has-uniform-positive-gap.md) 的阶跃谱隙。

## 定理

令 \(p\to\infty\) 沿奇素数，\(P=p-1\)、\(H=\log p\)、\(Q=\lfloor P/H\rfloor\)、\(k=p^2\)。沿前述 notes 的完整 Farey 集、常值奇槽 \(\psi_x\) 及阶跃偶极空间 \(W_p\)，取
\[
\mathcal U_p=\{x=a/b\in\mathcal F_p:a>Q,\ x>H\},
\qquad U_p=\operatorname{span}\{\psi_x:x\in\mathcal U_p\}.
\tag{1}
\]
另取完整小分子内区
\[
\mathcal I_p=\{x=a/b\in\mathcal F_p:a\le Q\},\qquad
I_p=\operatorname{span}\{\psi_x:x\in\mathcal I_p\}.
\tag{1a}
\]
则 \(\dim U_p\asymp p^2/H\)，并且真实旧奇 Weil 算子的**整个** \(U_p\) 主压缩满足
\[
\boxed{\quad
P_{U_p}A_{p^2,-}P_{U_p}
\succeq\left(1-\frac3{\pi^2}\right)H\,I_{U_p}
-O(\sqrt H\log H)\,I_{U_p}.
\quad}\tag{2}
\]
特别地，此下界对任意常值槽系数同时成立。若 \(s_k\) 是 polar 向量，则
\[
\|P_{U_p}s_k\|^2
=\|P_{T_p}s_k\|^2-O(\log H)
=\frac{H}{4\zeta(2)}+O(\log H);
\tag{3}
\]
故 \(U_p\) 承载完整常值槽 polar 投影的渐近全部平方质量。又有
\[
\boxed{\quad
P_{W_p\oplus U_p}A_{p^2,-}P_{W_p\oplus U_p}
\succeq(c_0-o(1))I,\qquad
c_0=1+\gamma_E-\log\pi+\delta_0>0.
\quad}\tag{4}
\]
互补地，\(\dim I_p\asymp p^2/H^2\)，其**全部斜率**上的常值槽满足
\[
\boxed{\quad
P_{I_p}A_{p^2,-}P_{I_p}
\succeq(2\log H-O(1))I_{I_p},
\qquad
P_{W_p\oplus I_p}A_{p^2,-}P_{W_p\oplus I_p}
\succeq(c_0-o(1))I.
\quad}\tag{4a}
\]
这里 (4) 与 (4a) 是两个主压缩结论；尚未声称 \(U_p\oplus I_p\) 的联合谱隙。

## 证明

在常值槽坐标中，note 807 式 (4)、(12) 给出
\[
A_T=(D_pI-C^-)-\log2\,I-N+B-2hh^*+O(\Delta)I,
\tag{5}
\]
其中 \(C^-=C_{\parallel}-C_{\times}\)、\(B\succeq0\)、\(N(x,x)=0\)、\(N(x,y)=M_\Delta(|\log(x/y)|)\ge0\) 对 \(x\ne y\)，\(h_x=\langle s_k,\psi_x\rangle\)，且 \(D_p=2H+1-\gamma_E-\log\pi\)。这是完整旧奇算子的精确有限主压缩；\(O(\Delta)I\) 来自位置一致的单槽正则项。

把 note 807 式 (16)--(18) 的外区记为
\(\mathcal R=\{a/b\in\mathcal F_p:a>Q\}\)。它们给
\[
\widetilde L^-_{\mathcal R\mathcal R}
=\operatorname{diag}(\widetilde r_{\mathcal R})-C^-_{\mathcal R\mathcal R}
\succeq\left(H-O(\sqrt H\log H)\right)I,
\qquad V_x=D_p-\widetilde r_x\ge-M
\quad(x\in\mathcal R).
\tag{6}
\]
因为 \(\mathcal U_p\subset\mathcal R\)，取主压缩保持 Loewner 下界，故
\[
(D_pI-C^-)_{\mathcal U_p\mathcal U_p}
\succeq\left(H-O(\sqrt H\log H)\right)I_{U_p}.
\tag{7}
\]
式 (6)--(7) 已包含全部带符号素数幂边；没有把异臂边取绝对值后误作负项。

对 \(x,y>H\)，note 805 式 (20) 的局部 Farey 间距给
\(|\log(x/y)|>H/p^2\)。把中心排序，第 \(j\) 个单侧邻点的权重由 note 805 式 (8) 控制为
\[
M_\Delta(|\log(x/y)|)
\le\frac1{2(jH-1)}+C\Delta.
\]
每侧求和至 \(|\mathcal U_p|\le p^2\) 得
\[
\|N_{\mathcal U_p\mathcal U_p}\|=O(1).
\tag{8}
\]
note 808 式 (4) 给 \(\|h\|^2=H/(4\zeta(2))+O(1)\)，所以
\[
\|2h_{\mathcal U_p}h_{\mathcal U_p}^*\|
=2\|h_{\mathcal U_p}\|^2
\le\frac{H}{2\zeta(2)}+O(1)
=\frac3{\pi^2}H+O(1).
\tag{9}
\]
将 (7)--(9) 代入 (5)，丢去 \(B\succeq0\)，便得 (2)。因为 \(1-3/\pi^2>0\)，该谱隙随 \(p\) 增长。

为核对 (3)，在 \(x\le H\) 的 polar 质量由 note 808 式 (12) 为 \(O(\log H)\)。在 \(a\le Q\) 的质量更小：由 \(h_{a/b}^2\le\lambda_\Delta^2a/b\)、note 808 式 (1) 的 \(\lambda_\Delta^2\asymp p^{-2}\)，放弃互素限制并求和得到
\[
\sum_{\substack{a\le Q\\b<a}}h_{a/b}^2
\ll p^{-2}\sum_{a\le Q}a\sum_{b<a}\frac1b
\ll p^{-2}Q^2\log Q=O(H^{-1}).
\tag{10}
\]
于是 \(T_p\setminus U_p\) 的 polar 质量为 \(O(\log H)\)，与 note 808 式 (4) 合并证明 (3)。

对 (4a)，在 \(\mathcal I_p\) 上，精确素数幂图是分子、分母均不超过 \(Q\) 的全 Farey 图。note 791 式 (14) 的正权行界以 \(Q\) 代替 \(p-1\) 给
\[
\|C^+_{\mathcal I_p\mathcal I_p}\|\le2\log Q+O(1),\qquad
\|C^-_{\mathcal I_p\mathcal I_p}\|\le2\log Q+O(1).
\tag{11}
\]
第二式由 \(|C^-|\le C^+\) 逐项支配。不同内区 Farey 中心的对数间距至少为 \(\log(1+Q^{-2})\gg Q^{-2}\)。用 note 805 式 (8) 的 \(M_\Delta(d)\ll\Delta/(d-2\Delta)+\Delta\) 并按邻点排序，有
\[
\|N_{\mathcal I_p\mathcal I_p}\|
\ll\Delta Q^2(1+\log Q)=O(H^{-1}).
\tag{12}
\]
polar 向量在内区的平方范数由 (10) 为 \(O(H^{-1})\)。因此在 (5) 中使用 \(D_p=2H+O(1)\)、\(B\succeq0\) 与 (11)--(12)，得到
\[
A_{I_p}\succeq
\left(2H-2\log Q-O(1)\right)I
=(2\log H-O(1))I.
\tag{13}
\]
互素对计数给 \(|\mathcal I_p|=Q^2/(2\zeta(2))+O(Q\log Q)\asymp p^2/H^2\)。最后 note 806 的全常值槽混合界也给 \(\|P_{W_p}A_{p^2,-}P_{I_p}\|=O(1)\)，与 (13) 和 note 804 的阶跃谱隙完成平方即得 (4a)。

维数上界由 \(x>H\Rightarrow b<a/H<p/H\) 给 \(O(p^2/H)\)。下界限制
\(p/2\le a\le3p/4\)、\(p/(4H)\le b\le p/(3H)\)；其比值 \(a/b>H\)、分子 \(a>Q\)，互素格点的 Möbius 反演给 \(c\,p^2/H+O(p\log p)\) 个点，\(c>0\)。故 \(\dim U_p\asymp p^2/H\)。

最后，note 806 的同臂 \(j^{-2}\) 混合界、异臂 \(c/p\) 分离、算术整槽正交和 polar 小混合，对**全部**常值 Farey 槽给
\(\|P_{W_p}A_{p^2,-}P_{T_p}\|=O(1)\)，所以在子空间 \(U_p\) 上也为 \(O(1)\)。note 804 有 \(A_{W_p}\succeq(c_0-o(1))I\)；用 (2) 的增长谱隙完成平方，Schur 损失为 \(O(1/H)=o(1)\)，得到 (4)。\(\square\)

## 边界

这两个定理均保留真正的 polar 秩一扣款与完整素数幂图。若再加入 note 806 已控制的 \(x\le R_p\) 扇区，尚未逐块覆盖的常值槽精确落在 \(a>Q,\ R_p<x\le H\) 的中间带；其数量至多 \(O(p^2/R_p)\)，polar 质量至多 \(O(\log H)\)。三个正主压缩之间的完整算术 Schur 耦合、槽内非恒定轮廓和无限维正交补仍未控制，故不推出全尺度 Weil 正性或 RH。
