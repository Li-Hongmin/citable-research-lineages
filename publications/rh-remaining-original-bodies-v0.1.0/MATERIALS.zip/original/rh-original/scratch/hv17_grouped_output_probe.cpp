#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <random>
#include <string>
#include <vector>

using cd = std::complex<double>;
static constexpr int SK = 32;
static constexpr int NA = 33;

static std::vector<int> mobius(int n) {
    std::vector<int> mu(n+1), lp(n+1), primes;
    mu[1]=1;
    for(int i=2;i<=n;i++) {
        if(!lp[i]) { lp[i]=i; primes.push_back(i); mu[i]=-1; }
        for(int p: primes) {
            long long v=1LL*p*i; if(v>n) break;
            lp[v]=p;
            if(i%p==0) { mu[v]=0; break; }
            mu[v]=-mu[i];
        }
    }
    return mu;
}

static std::vector<double> lambda_vals(int n) {
    std::vector<int> lp(n+1); std::vector<int> primes;
    for(int i=2;i<=n;i++) {
        if(!lp[i]) { lp[i]=i; primes.push_back(i); }
        for(int p:primes) { long long v=1LL*p*i; if(v>n) break; lp[v]=p; if(i%p==0) break; }
    }
    std::vector<double> L(n+1,0.0);
    for(int i=2;i<=n;i++) if(lp[i]) {
        int p=lp[i], t=i; while(t%p==0) t/=p;
        if(t==1) L[i]=std::log((double)p);
    }
    return L;
}

static std::vector<int> primes_in(int lo,int hi) {
    std::vector<bool> is(hi+1,true); is[0]=is[1]=false;
    for(int p=2;p*p<=hi;p++) if(is[p]) for(int j=p*p;j<=hi;j+=p) is[j]=false;
    std::vector<int> out; for(int i=lo;i<hi;i++) if(is[i]) out.push_back(i); return out;
}

struct Result { double joint, diag, ratio, sigma; long long edges; };

static Result run(int P,int qkeep,int qblock,int mode) {
    int hi=2*P, maxprod=4*P*P+2;
    auto mu=mobius(hi);
    auto lam=lambda_vals(hi);
    std::vector<double> beta(maxprod,0.0), gamma(maxprod,0.0);
    // Two-factor slice of the exact Vaughan layers (the final 1-factor is y=1):
    // L1=mu_{<=U}*log, L2=-mu_{<=U}*Lambda_{<=V}*1,
    // L3=mu_{>U}*Lambda_{>V}*1.  mode=0 selects L3, mode=1 selects L1+L2+L3.
    int U=(3*P)/2, V=U;
    for(int d=P;d<2*P;d++) for(int f=P;f<2*P;f++) {
      double l1=(d<=U)?mu[d]*std::log((double)f):0.0;
      double l2=(d<=U && f<=V)?-mu[d]*lam[f]:0.0;
      double l3=(d>U && f>V)?mu[d]*lam[f]:0.0;
      double val=(mode==0)?l3:((mode==1)?(l1+l2+l3):(l1+l2-l3));
      beta[d*f]+=val;
    }
    gamma=beta;
    std::vector<int> cs,bs;
    for(int x=P*P;x<=4*P*P;x++) { if(beta[x]!=0) cs.push_back(x); if(gamma[x]!=0) bs.push_back(x); }
    auto pp=primes_in(P,2*P); if((int)pp.size()>qkeep) pp.resize(qkeep);
    if(pp.empty()) return {};
    int K=pp.size(), C=maxprod;
    long long H=std::max(8LL,(long long)P*P/2), r0=(long long)qblock*2*H;
    long long rmin=r0-H, rmax=r0+H-1, R=2*H;
    std::vector<cd> sk((size_t)R*SK,cd(0,0));
    std::vector<double> signs((size_t)K*C*SK);
    uint64_t seed=0x9e3779b97f4a7c15ULL + P*1315423911ULL + qblock*2654435761ULL;
    for(size_t i=0;i<signs.size();i++) { seed^=seed>>12; seed^=seed<<25; seed^=seed>>27; signs[i]=(seed&1)?1.0:-1.0; }
    long long edges=0;
    // Use the exact grouped relation r = p*c - a*b. The sparse gamma array
    // avoids enumerating all (e,y) after their exact Lambda aggregation.
    for(int iq=0;iq<K;iq++) {
      long long q=pp[iq];
      for(int ia=0;ia<K;ia++) {
        long long a=pp[ia];
        for(int c:cs) {
          long long lo=(q*(long long)c-rmax + a-1)/a;
          long long hi_b=(q*(long long)c-rmin)/a;
          if(lo<P*P) lo=P*P; if(hi_b>4LL*P*P) hi_b=4LL*P*P;
          for(long long b=lo;b<=hi_b;b++) {
            double gb=gamma[(size_t)b]; if(gb==0) continue;
            long long r=q*(long long)c-a*b; if(r<rmin||r>rmax) continue;
            int ir=(int)(r-rmin); cd J(0,0);
            // finite full-height Dirichlet factor, normalized by T=P
            int T=P; long long den=4*H;
            if(r==0) J=cd(1.0,0.0);
            else {
              cd z=std::exp(cd(0.0,2.0*M_PI*(double)r/(double)den));
              J=(cd(1.0,0.0)-std::pow(z,T))/(cd((double)T,0.0)*(cd(1.0,0.0)-z));
            }
            double coeff=beta[c]*gb;
            int row=iq*C+c;
            const double *sg=&signs[(size_t)row*SK];
            for(int j=0;j<SK;j++) sk[(size_t)ir*SK+j]+=coeff*J*sg[j];
            edges++;
          }
        }
      }
    }
    double diag=0; for(int ir=0;ir<R;ir++) { double n=0; for(int j=0;j<SK;j++) n+=std::norm(sk[(size_t)ir*SK+j]); diag+=n; }
    double best=0; for(int u=0;u<NA;u++) {
      double alpha=-M_PI+2*M_PI*u/(NA-1); double n=0;
      for(int j=0;j<SK;j++) { cd z=0; for(int ir=0;ir<R;ir++) z += sk[(size_t)ir*SK+j]*std::exp(cd(0.0,alpha*(double)(rmin+ir)/(double)H)); n+=std::norm(z); }
      best=std::max(best,n);
    }
    Result out; out.joint=best; out.diag=diag; out.ratio=diag>0?best/diag:0; out.sigma=std::sqrt(best); out.edges=edges; return out;
}

int main(int argc,char**argv){
    if(argc<2){std::cerr<<"usage: hv17_grouped_output_probe P... [--qkeep K]\n";return 2;}
    int qkeep=2; std::vector<int> Ps;
    for(int i=1;i<argc;i++){std::string s=argv[i]; if(s=="--qkeep"&&i+1<argc) qkeep=std::stoi(argv[++i]); else Ps.push_back(std::stoi(s));}
    std::cout<<"P,mode,Q,H,edges,joint_sketch,diag_sketch,ratio,sigma_proxy\n";
    for(int P:Ps) for(int mode=0;mode<=2;mode++) for(int Q=-2;Q<=2;Q++) { auto r=run(P,qkeep,Q,mode); std::cout<<P<<","<<mode<<","<<Q<<","<<std::max(8LL,(long long)P*P/2)<<","<<r.edges<<","<<r.joint<<","<<r.diag<<","<<r.ratio<<","<<r.sigma<<"\n"<<std::flush; }
}
