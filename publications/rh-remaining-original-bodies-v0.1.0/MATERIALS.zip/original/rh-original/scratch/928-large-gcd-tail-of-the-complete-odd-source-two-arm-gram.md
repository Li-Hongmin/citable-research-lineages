# 完整奇数源两臂 Gram 的大共同因子尾项可绝对支付

日期：2026-10-02。依赖 [scratch/926](926-odd-source-normal-form-for-the-complete-two-arm-observation.md) 式 (4)、(9)--(12) 的真实两臂奇数源展开与小既约比例支付，以及 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的完整观察系数。本稿给出对所有剩余 cofactor 同时适用的共同因子尾界；它不估计小共同因子上的 signed covariance，不证明 RH 或全尺度局部 Weil 正性。证明尚未异源复核。

## 命题

设 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，
$D=\lfloor M/(32H)\rfloor$、
$R=\lfloor H^2/\log^4M\rfloor$。固定
$\psi\in C_c^3((1,2))$，令 $\phi(x)=\psi(x)/x$；
固定偶非负 $\eta\in C_c^2(\mathbb R)$，支撑于
$1/2\le|t|\le4$，且在 $1\le|t|\le2$ 上
$\eta(t)\ge1$；令 $w_H(h)=\eta(h/H)$。
对奇数 $D<u,v<2M/3$，沿用 scratch/926 式 (4) 的完整配对源核
$\mathcal K_h(u)=\mathcal K_h^o(u)+\mathcal K_h^e(u)$，写
\[
G_{u,v}=\sum_{h\in\mathbb Z}w_H(h)\mathcal K_h(u)
\overline{\mathcal K_h(v)},\qquad
g=(u,v),\quad a=u/g,\quad b=v/g.
\tag{1}
\]
则对任意 $1\le G_0\le 2M/(3R)$，在 $M$ 充分大时有
\[
\boxed{\quad
\sum_{\substack{D<u,v<2M/3,\ u,v\ {\rm odd},\ u\ne v\\
\max(a,b)>R,\ g>G_0}}
|G_{u,v}|
\ll_{\psi,\eta}\frac{H\log^2(2M)}{G_0}.
\quad}
\tag{2}
\]
特别取 $G_*=\lceil M\log^2M/H^3\rceil$，以本稿的平滑
$w_H$ 定义的完整不同源协方差满足
\[
\boxed{\quad
\mathfrak C_{\rm odd}
=\sum_{\substack{D<u,v<2M/3,\ u,v\ {\rm odd},\ u\ne v\\
(u,v)\le G_*}}
\mu(u)\mu(v)G_{u,v}
+O_{\psi,\eta}(H^4/M).
\quad}
\tag{3}
\]
在式 (3) 的留存区，对充分大的 $M$ 自动有 $a,b>R$。因此当
$H\asymp M^{1/5}$ 时，完整两臂 Gram 的真实未付不同源对可限制在
共同因子 $g\lesssim M^{2/5}\log^2M$；先前的小比例界只把
$g\gtrsim M^{3/5}\log^4M$ 自动付清。这里两个幂指数来自
$G_*=M/H^3$ 和 $M/R=M/H^2$；对数因子按上式保留。

## 证明

把两臂的奇 cofactor 合成一个物理乘子 $k$。对奇数
$t\ge3$ 置
\[
W(t)=K_o(t)=-4\log(t/2),\qquad
W(2t)=K_e(t)=2\log(t/4),
\tag{4}
\]
其余 $W(k)=0$。由于 $u>D=\lfloor M/(32H)\rfloor$ 蕴含
$u>M/(32H)$，活动条件 $M<ku<2M$ 使 $k<64H$。
scratch/926 式 (4) 因而精确地成为
\[
\mathcal K_h(u)=\frac1M\sum_{\substack{3\le k<64H\\M<ku<2M}}
W(k)\phi(ku/M)e(-hku/M).
\tag{5}
\]
若 $J_H(r)=\sum_h\eta(h/H)e(-hr/M)$，式 (1) 展开为
\[
G_{u,v}=\frac1{M^2}\sum_{k,\ell<64H}
W(k)\overline{W(\ell)}
\phi(ku/M)\overline{\phi(\ell v/M)}
J_H(ku-\ell v),
\tag{6}
\]
其中 $\phi$ 的支撑自动执行物理窗口限制。

因 $\psi$ 紧支撑于 $(1,2)$，存在固定 $\sigma_\psi>0$，使
式 (6) 中非零项的 $ku/M,\ell v/M$ 均落在
$[1+\sigma_\psi,2-\sigma_\psi]$。于是
$|(ku-\ell v)/M|\le1-2\sigma_\psi$，远离非零整数别名。
Poisson 求和及 $\eta\in C_c^2$ 的二次 Fourier 衰减给
\[
|J_H(ku-\ell v)|
\ll_{\eta,\psi}H\left(1+
\frac{H|ku-\ell v|}{M}\right)^{-2}.
\tag{7}
\]
这里 $ku-\ell v=g(ka-\ell b)$。

若 $(a,b)=1$ 且 $ka=\ell b$，则 $a\mid\ell$、$b\mid k$，
从而 $\max(a,b)<64H<R$，与式 (2) 的高既约比例条件冲突。
故式 (2) 中的每个活动 cofactor 对都满足整数
$ka-\ell b\ne0$。固定 $g,k,\ell,a$，放宽对 $b$ 的来源、
互素和窗口限制，只保留 $ka-\ell b\ne0$。映射
$b\mapsto ka-\ell b$ 是单射，所以令 $\alpha=Hg/M$ 后有
\[
\sum_{\substack{b\in\mathbb Z\\ka-\ell b\ne0}}
(1+\alpha|ka-\ell b|)^{-2}
\le\sum_{n\in\mathbb Z\setminus\{0\}}(1+\alpha|n|)^{-2}
\ll \alpha^{-1}=\frac{M}{Hg}.
\tag{8}
\]
这个界对 $\alpha>0$ 一致，不需要区分 $\ell$ 的大小。

由 $\max(a,b)>R$、$u,v<2M/3$，还知
$g<2M/(3R)$。对固定 $g,k$，条件
$ku\in\operatorname{supp}\phi$ 使 $a$ 落在长度
$O_\psi(M/(kg))$ 的整数区间。由于
$g<2M/(3R)$ 且 $k<64H$，
$M/(kg)\gg R/H\to\infty$，故整数 $a$ 的个数也是
$O_\psi(M/(kg))$。把 (7)--(8) 代入 (6)，先对 $a,b$ 求和，
得到固定 $g,k,\ell$ 的总绝对质量
\[
\ll_{\psi,\eta}
\frac{H|W(k)W(\ell)|}{M^2}
\frac{M}{kg}\frac{M}{Hg}
=\frac{|W(k)W(\ell)|}{kg^2}.
\tag{9}
\]
交换 $a,b$ 的求和次序并以 $\ell$ 计数，同理得到
$|W(k)W(\ell)|/(\ell g^2)$。同时取两界，式 (9) 的右侧
可加强为 $|W(k)W(\ell)|/[g^2\max(k,\ell)]$。由式 (4)
的对数系数及每个 $q$ 至多有 $2q$ 个
$\max(k,\ell)=q$ 的有序对，
\[
\sum_{k,\ell<64H}
\frac{|W(k)W(\ell)|}{\max(k,\ell)}
\ll H\log^2(2H).
\tag{10}
\]
最后对 $g>G_0$ 求和并用
$\sum_{g>G_0}g^{-2}\ll G_0^{-1}$，
得到式 (2)。

对式 (3)，先以 scratch/926 式 (10) 将全部
$\max(a,b)\le R$ 的不同源对绝对支付为
$O_{\psi,\eta}(H^4/(M\log^2M))$。余下的高比例对中，
式 (2) 在 $G_0=G_*$ 时给
$O_{\psi,\eta}(H\log^2M/G_*)=O_{\psi,\eta}(H^4/M)$。
而 $u,v>D$、$g\le G_*$ 意味着
\[
a,b>\frac{D}{G_*}
\gg\frac{H^2}{\log^2M}>R
\tag{11}
\]
对充分大的 $M$ 成立；此处最后一步使用
$R=H^2/\log^4M+O(1)$。故留存区不存在先前支付的小比例对，
得到式 (3)。$\square$

## 同一物理乘子的尾项更小

将式 (6) 中 $k=\ell$ 的部分记为
\[
G^{=}_{u,v}
=\frac1{M^2}\sum_{k<64H}|W(k)|^2
\phi(ku/M)\overline{\phi(kv/M)}J_H(k(u-v)).
\tag{12}
\]
此处对任何 $u\ne v$ 都没有精确物理碰撞，不需先限制
$\max(a,b)>R$。对任意 $G_0\ge1$，
\[
\boxed{\quad
\sum_{\substack{D<u,v<2M/3,\ u,v\ {\rm odd},\ u\ne v\\
(u,v)>G_0}}|G^{=}_{u,v}|
\ll_{\psi,\eta}G_0^{-1}.
\quad}
\tag{13}
\]
事实上，固定 $g=(u,v)$ 与 $k$，活动 $u=ag$ 的选择为
$O(M/(kg))$ 个；即使 $M/(kg)<1$，只要有活动行，
$kag<2M$ 仍给 $M/(kg)>1/2$，故此计数仍成立。
对 $b\ne a$，式 (7) 的核和满足
\[
\sum_{b\ne a}
\left(1+\frac{Hkg|a-b|}{M}\right)^{-2}
\ll\frac{M}{Hkg}.
\]
固定 $g,k$ 的绝对贡献因而至多
$O_{\psi,\eta}(|W(k)|^2/(k^2g^2))$。因为
$\sum_{k\ge3}|W(k)|^2/k^2<\infty$，对 $k$ 和
$g>G_0$ 求和得到 (13)。

取 $G_0=\lceil M/H^4\rceil$，同一乘子部分的全部
$g>G_0$ 非对角项已达到 $O(H^4/M)$。
相比式 (3) 的 $M\log^2M/H^3$，较大的未付共同因子范围只来自
式 (6) 中 $k\ne\ell$ 的跨乘子交叉；式 (13) 仍不支付
$g\le M/H^4$ 的真实 Möbius signed 自相关。

## 数学边界

式 (3) 是对完整两臂真实 signed covariance 的无条件缩域，
而非其上界。共同因子 $g=1$ 仍在留存区；[scratch/927](927-high-ratio-odd-source-blocks-need-mobius-sign-cancellation.md)
已证明它在单 cofactor 近距离子块中有相反的常量级符号质量。
任何精确物理碰撞 $ku=\ell v$ 都强迫
$\max(a,b)<64H<R$，故相关源对的**完整 Gram 条目**
已由 scratch/926 式 (10) 绝对支付；留存区只含非零物理位移。
继续支付式 (3) 必须保留真实 $\mu(u)\mu(v)$ 的跨源消去及
带通核的正负瓣。此缩域也没有把局部 Weil 正性扩展到全部尺度。
