# 槽外矩形的精确素数幂碰撞在算子范数中消失

日期：2026-09-30。对象沿用[槽外互素矩形候选](exterior-coprime-rectangle-carries-positive-fraction-of-polar-mass-candidate.md)的式 (1)、(2)、(8)–(11)。下述结论仅涉及有限矩阵中的**精确**乘积碰撞；其余移动短窗未估计。证明为本轮直接推导，尚未经过异源复核。

令 \(p\) 为充分大的奇素数，\(H=\log p\)，
\[
\mathcal G_p=\left\{x=\frac nb:\quad
\frac{p^{3/2}}8\le n\le\frac{p^{3/2}}4,\quad
\frac{\sqrt p}{2}\le b\le\sqrt p,\quad(n,b)=1\right\}.
\]
在 \(\ell^2(\mathcal G_p)\) 上定义精确碰撞矩阵
\[
R_p^{=}(x,y)=
\begin{cases}
\Lambda(xy)/\sqrt{xy},&xy\text{ 是整数素数幂},\\
0,&\text{其余}.
\end{cases}
\tag{1}
\]
这里若 \(xy=\ell^r\)，则 \(\Lambda(xy)=\log\ell\)。

**命题。** 对所有充分大的 \(p\)，每行 \(R_p^{=}\) 至多有九个非零元，且
\[
\boxed{\qquad \|R_p^{=}\|_{\rm op}\le72\frac{\log p}{p}=o(1).\qquad}
\tag{2}
\]
特别地，令 \(\mathcal R_p^{\rm near}\) 为槽外候选式 (8) 的素数幂矩阵去掉所有 \(m=xy\) 的项，\(K_p^{\rm cont}\) 为其式 (9)，则
\[
\mathcal E_p^{\rm mov}
=\mathcal R_p^{\rm near}-K_p^{\rm cont}+R_p^{=},
\qquad
\left|\lambda_{\min}(\mathcal E_p^{\rm mov})
-\lambda_{\min}(\mathcal R_p^{\rm near}-K_p^{\rm cont})\right|
\le72\frac{H}{p}.
\tag{3}
\]
所以精确碰撞不能支付或破坏候选式 (16) 的对数尺度谱门；所需算术信息位于非精确的单位短窗。

## 证明

固定 \(x=n/b\in\mathcal G_p\)，并令 \(y=n'/b'\in\mathcal G_p\) 满足 \(xy=m=\ell^r\)。由
\[
nn'=m bb',\qquad (n,b)=(n',b')=1
\]
可知 \(b'\mid n\)、\(b\mid n'\)。于是
\[
u:=n/b',\qquad v:=n'/b
\]
均为整数，且 \(m=uv\)。矩形的上下界给出
\[
\frac p8\le u,v\le\frac p2.
\tag{4}
\]
因为 \(uv\) 是素数幂，\(u\) 与 \(v\) 都是同一素数 \(\ell\) 的正整数幂。

对固定 \(n\)，区间 \([p/8,p/2]\) 内能整除 \(n\) 的素数幂至多三个：若出现两个不同素数底的幂 \(u_1,u_2\)，它们互素，故
\(n\ge u_1u_2\ge p^2/64>p^{3/2}/4\)（\(p>256\)），矛盾；对同一素数底，长度比为四的区间至多容纳三个连续幂。故 \(u\) 至多有三个选择。每个 \(u\) 唯一确定 \(b'=n/u\) 与素数底 \(\ell\)；由 (4)，\(v\) 至多有三个选择，每个 \(v\) 唯一确定 \(n'=bv\) 及 \(y\)。因此每行至多九个非零元。

由 (4)，\(m=uv\ge p^2/64\)，且 \(\ell\le u\le p/2\)，所以每个非零元至多为 \(8H/p\)。矩阵实对称、逐项非负；最大绝对行和界给 (2)。槽外候选式 (8) 在 \(m=xy\) 时三角权 \(\tau_L(0)=1\)，因此拆出 (1) 后其余项恰为 \(\mathcal R_p^{\rm near}\)；式 (11) 给出 (3) 的第一个等式，Weyl 特征值扰动界给第二个不等式。\(\square\)

## 直接的标量检验

令 \(a_x=\sqrt x\)、\(e=a/\|a\|\)。候选式 (7)、(9) 给
\[
\langle e,K_p^{\rm cont}e\rangle
=L\left(\frac{\sinh(L/4)}{L/4}\right)^2\|a\|^2
\sim\frac{3\log2}{128\zeta(2)}p,
\qquad L=\log(1+p^{-2}).
\tag{5}
\]
若拟证明的 \(\lambda_{\min}(\mathcal E_p^{\rm mov})\ge-(3/2-\eta)H\) 成立，它至少要求真实的非精确素数幂短窗满足
\[
\langle e,\mathcal R_p^{\rm near}e\rangle
\ge L\left(\frac{\sinh(L/4)}{L/4}\right)^2\|a\|^2
-(3/2-\eta)H-72H/p.
\tag{6}
\]
式 (6) 只给必要条件；(5) 中的 \(o(p)\) 尚不能换成 \(O(H)\)，因此不能把显示的渐近主项单独当作一个尖锐对数尺度测试。要在此方向真正判定 (16)，应直接比较 \(\langle e,\mathcal R_p^{\rm near}e\rangle\) 与式 (5) 左端的**精确**值。该比较没有在这里完成。
