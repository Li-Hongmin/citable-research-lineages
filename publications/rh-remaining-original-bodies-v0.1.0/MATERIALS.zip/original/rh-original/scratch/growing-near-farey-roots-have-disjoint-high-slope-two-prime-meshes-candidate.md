# 增长近对角根族的高斜率双素数网格接入已覆盖 Farey 背景（候选）

日期：2026-09-30。依赖 [note 825](../notes/825-growing-near-diagonal-farey-roots-have-explicit-prime-descendant-response.md) 的增长根族与第一代碰撞分类，以及[固定根候选稿](high-slope-two-prime-mesh-is-bipartite-and-has-a-linear-gap-candidate.md)的第二代亲子边。本文先判定增长根族的两代**真实主压缩**，再把它接入 note 824 已覆盖的 Farey 背景；完整遗漏带与无限维补空间仍未控制。以下结论尚待异源复核。

令 \(p\to\infty\) 沿奇素数，\(H=\log p\)、
\(A=\lfloor(p-1)^\theta\rfloor\)、
\(S=\lfloor(p-1)/H^\alpha\rfloor\)、
\(T=\lfloor(p-1)^\delta\rfloor\)，固定
\[
 \alpha>1,\qquad 0<\theta<1,\qquad 0<\delta<\theta/2.
\]
取 note 825 的根族
\[
 \mathcal X=\{x=a/b:1<b<a\le T,\ (a,b)=1,\ 1<x<2\},
\]
并对每个根使用同一两臂素数区间
\[
 \mathcal P_x=\{q\text{ 素数}:A/b<q\le S/a\},\qquad
 c_q=\frac{\log q}{\sqrt q},\qquad
 \tau_x^2=\sum_{q\in\mathcal P_x}c_q^2.
\]
记 \(u_{x,q}=qx\)、\(v_{x,q}=q/x\)，以及
\[
 \mathcal Z_x=\{z_{x;q,r}=xq/r:
 q,r\in\mathcal P_x,\ q\ne r,\ z_{x;q,r}>H/2\}.
\]
令 \(\mathcal V\) 为全部根、孩子和 \(\mathcal Z_x\) 槽的并集。
这是一族随 \(p\) 增长的根与第二代网格；note 825 给
\(|\mathcal X|\asymp T^2\)。

## 命题

对充分大的 \(p\)，全部 \(\mathcal Z_x\) 标签互不碰撞。带符号算术矩阵
\(C^-=C_{\parallel}-C_{\times}\) 在 \(\mathcal V\) 上满足：

1. 根到第二代为零，且**不同根**的孩子到第二代为零；
2. 整个第二代—第二代块精确为零，包括不同根之间；
3. 每个根内部只有根—孩子的 \((+c_q,-c_q)\) 边、孩子—第二代的
   \(u_{x,q}\leftrightarrow z_{x;q,r}:+c_r\) 与
   \(v_{x,r}\leftrightarrow z_{x;q,r}:-c_q\) 边。

根—根、孩子—孩子剩余算术块的算子范数为 \(O(1)\)；
因此真实旧奇 Weil 主压缩满足统一的候选下界
\[
 \boxed{\quad
 \lambda_{\min}(A_{\mathcal V})
 \ge
 \left(2-\sqrt{2(1-\theta^2)}\right)H
 -O_{\alpha,\theta,\delta}(\log H)>0.
 \quad}\tag{1}
\]
这个系数对全部增长根同时有效。它只涉及有限主压缩，未消去
\(\mathcal V^\perp\)。

## 大素数赋值排除跨根边

由 \(a,b\le T\) 与 \(q>A/b\ge A/T\)，所有使用的素数
\[
 q,r>A/T=p^{\theta-\delta+o(1)}>T.
 \tag{2}
\]
所以每个根 \(x=a/b\) 的分子、分母只含**小于所有标签素数**的因子。
若 \(z_{x;q,r}>H/2\)，则
\[
 \frac qr>\frac{H}{2x}>\frac H4,
 \qquad q>r
 \tag{3}
\]
对充分大 \(p\) 成立。

先看 \(z=xq/r\)、\(z'=x'q'/r'\)。
它们的比值在大素数上的赋值向量为
\(e_q-e_r-e_{q'}+e_{r'}\)，坐标和为零。
若 \(z/z'\) 或其倒数是整数，则该方向的全部大素数赋值非负，
又因坐标和为零，必须全部为零。于是 \(z/z'=x/x'\)；
它严格处于 \((1/2,2)\)，不可能是非平凡的整数素数幂。
若 \(z=z'\)，同理先得 \(x=x'\)，再从 \(q/r=q'/r'\) 及
\(q\ne r,\ q'\ne r'\) 得到 \((q,r)=(q',r')\)。
故标签无碰撞，也没有第二代比值边。

乘积 \(zz'=xx'qq'/(rr')\) 的大素数赋值坐标和也为零。
若它为整数，必有大素数多重集
\(\{q,q'\}=\{r,r'\}\)。但 (3) 给 \(q>r\)、\(q'>r'\)；
取较大的 \(r,r'\)，对应的 \(q\) 或 \(q'\) 严格更大，
故两多重集不可能相同。乘积边和自环因此也为零。
同样的未配对 \(q/r\) 赋值立即排除任何根—第二代边。

再取孩子 \(u_{x,s}=sx\) 与
\(z_{x';q,r}=x'q/r\)。其比值为
\[
 \frac{u_{x,s}}{z_{x';q,r}}
 =\frac{x}{x'}\frac{sr}{q}.
\]
要成为整数，分母中的大素数 \(q\) 必须由 \(s=q\) 消去；
这时值为 \(r(x/x')\)。
既约的小因子 \(x/x'\) 的分母不可能由 \(r>T\) 消去，
所以它必须为整数；又 \(x/x'\in(1/2,2)\)，只能等于 \(1\)。
于是 \(x=x'\)，留下亲子边 \(+c_r\)。
倒比值仍有未消去的 \(r\)，不是整数。
乘积 \(u_{x,s}z_{x';q,r}=xx'sq/r\) 若为整数，
必须 \(s=r\)，留下 \(xx'q\)；
整数条件使 \(xx'\in\{2,3\}\)，此时 \(2q,3q\)
各含两个不同素因子，不是素数幂。

对 \(v_{x,s}=s/x\) 同理：
\[
 \frac{v_{x,s}}{z_{x';q,r}}
 =\frac{sr}{xx'q},\qquad
 v_{x,s}z_{x';q,r}
 =\frac{x'}x\frac{sq}{r}.
\]
第一个比值只有 \(s=q\) 才可能消去大分母，
剩 \(r/(xx')\)；既约 \(xx'>1\) 的分子仅含不超过
\(T\) 的素因子，不可能整除大素数 \(r\)，故仍非整数。
第二个乘积必须 \(s=r\)，然后只有 \(x'=x\)
才成为整数素数幂 \(q\)，给亲子边 \(-c_q\)。
其倒比值也留有大素数分母。

最后，根—孩子及孩子—孩子的所有边由 note 825 式
(7)--(9) 分类：根只连自己的两臂；
孩子同层除了同根 \(u_{x,q}\)--\(v_{x,q}\) 的
\(-c_{q^2}\)，仅有相同 \(q\) 下
\(x_ix_j=2,3\) 的异根有限权匹配。
根—根也只有 \(2,3\) 乘积匹配。这些余块合起来范数
\(O(1)\)，与根数无关。

## 统一谱隙

对固定 \(x\)，令 \(w_x=(c_q,-c_q)_{q\in\mathcal P_x}\)，
孩子到 \(\mathcal Z_x\) 的块为 \(T_x\)。
与固定根稿式 (4) 相同，正臂不同 \(q\) 的目标支持不交，
负臂不同 \(r\) 的目标支持不交，故
\[
 \|w_x\|^2=2\tau_x^2,\qquad
 \|T_x\|^2\le2\tau_x^2.
\]
按 \((\{x\}\oplus\mathcal Z_x)\oplus Y_x\) 重排，
该根的二分算术块范数至多 \(2\tau_x\)。
上节证明跨根的承重块为零，因此全部承重算术矩阵是这些
根块的直和；余下根—根与孩子—孩子块仅 \(O(1)\)。

素数加权 Mertens 公式在全部端点上一致给
\[
 \tau_x^2
 =\frac12\!\left[\log^2(S/a)-\log^2(A/b)\right]
 +O(H)
 \le\frac12(1-\theta^2)H^2
 +O_{\alpha,\theta,\delta}(H\log H).
 \tag{4}
\]
写 \(t=\log b\)、\(\log a=t+\log x\) 后，主差
\(\log^2(S/a)-\log^2(A/b)\) 对 \(t\) 的导数恰为
\(-2\log(S/(Ax))<0\)。故其最大值在有界小分母处，
不随增长根族的上界 \(T\) 增大；(4) 的一致上界与固定根同阶。
所有槽的既约分子不超过 \(S<Q\)；note 809 在整个
\(I_Q\) 上给同臂非算术核和 polar 扣款范数 \(O(H^{-1})\)，
note 805 的异臂矩阵 \(B\succeq0\) 可在本主压缩上一并丢去。
故
\[
 A_{\mathcal V}\succeq
 \bigl(2H-2\max_{x\in\mathcal X}\tau_x-O(1)\bigr)I,
\]
将 (4) 代入即得 (1)。\(\square\)

## 无界碰撞构造

跨根第二代算术零块足以控制这族槽的自身谱。
增长的根数却使近对角槽的第二代邻居数无界，构造如下。

固定 \(\theta=1/3\)、\(0<\delta<1/6\)，取整数
\(D=\lfloor T/4\rfloor\)。由素数定理，可选素数
\[
 2A/D<r<3A/D,\qquad rD<q<2rD.
\]
这些区间随 \(p\) 增长，且 \(rD\asymp A\)、
\(q\asymp A\ll S/(2D)\)。置
\[
 y=\frac q{Dr}\in(1,2).
\]
充分大时 \(q>Dr\)、\(q<Q\)，故 \(y\) 已约分并属于
note 824 的近对角块 \(N\)。对**每个**素数
\(D<a<2D\)，根 \(x_a=a/D\) 属于上面的 \(\mathcal X\)，
且同一 \(q,r\) 均属于 \(\mathcal P_{x_a}\)。
相应第二代槽
\[
 z_a=x_a\frac qr=a\,y>H/2
\]
两两不同，并满足 \(z_a/y=a\)。其乘积留有大素数
分母，故真实算术条目恰为 \(C^-(y,z_a)=c_a>0\)。
因此这一近对角行的非零第二代邻居数为
\[
 \#\{a\text{ 素数}:D<a<2D\}
 \sim\frac D{\log D}\longrightarrow\infty,
\]
且边权平方和满足
\[
 \sum_{D<a<2D\atop a\ {\rm prime}}|C^-(y,z_a)|^2
 =\sum_{D<a<2D\atop a\ {\rm prime}}\frac{(\log a)^2}{a}
 =(\log2+o(1))\log D
 =(\delta\log2+o(1))H. \tag{5}
\]
这已排除固定根证明中的逐近对角槽**常数**邻居计数。

## 碰撞子图的精确带权范数

记 \(Z_* =\{z_a:D<a<2D,\ a\text{ 素数}\}\)，令
\(N\) 是 note 824 的**全部**近对角内区槽。上面的共同邻居
\(y=q/(Dr)\) 之外，\(Z_*\) 的其他近对角算术邻居实际上两两
不重叠。因此有更精确的候选结论
\[
 \boxed{\quad
 \|C^-_{N,Z_*}\|^2=(3\delta\log2+o(1))H.
 \quad}\tag{6}
\]

确实，\(t=q/(Dr)\in(1,2)\)，\(z_a=at\in(D,4D)\)。
由于 \(z_a>2>y\)，每条 \(z_a\)--\(y\in N\) 算术边
恰由下面两种互斥关系之一给出，\(n\) 是素数幂：
\[
 y=z_a/n,\quad z_a/2<n<z_a,\quad C^-(y,z_a)=+c_n;
 \qquad
 y=n/z_a,\quad z_a<n<2z_a,\quad C^-(y,z_a)=-c_n.
 \tag{7}
\]
两种关系不能同时成立，因为那将使 \(z_a^2\) 为整数，
但 \(r^2\) 是其既约分母的因子。式 (7) 中的 \(y\) 都属于
\(N\)：第一种的既约分子至多 \(aq<12DA\)，第二种至多
\(nDr<24DA\)，而 \(DA=p^{\theta+\delta+o(1)}=o(Q)\)。

若不同 \(a,b\) 的两条第一种边落在同一 \(y\)，则
\(a/b=n/m\)，其中 \(n,m\) 都是素数幂。由 \(a,b\) 为
不同素数，必有 \(n=a,m=b\)，所以 \(y=t\)。
两条第二种边若相遇，同样强制 \(n=a,m=b\)，却给
\(y=1/t<1\)，故不在 \(N\)。第一种与第二种边若相遇，
则两个素数幂的乘积等于
\(z_az_b=abq^2/(D^2r^2)\)；因 \(r>T>a,b,D\) 且
\(r\ne q\)，右端非整数，矛盾。因此 \(t\) 是唯一的
跨列共同邻居。

令 \(c=(c_a)_{D<a<2D,\ a\text{ 素数}}\)，
\(s_a=\sum_{z_a/2<n<2z_a}\Lambda(n)^2/n\)。
逐邻居作内积得到**精确** Gram 恒等式
\[
 (C^-_{N,Z_*})^*C^-_{N,Z_*}
 =\operatorname{diag}(s_a-c_a^2)+cc^*.
 \tag{8}
\]
固定比例区间的素数定理在 \(z_a\in(D,4D)\) 上一致给
\(s_a=(2\log2+o(1))\log D\)，素数幂 \(n=\ell^j\)、
\(j\ge2\) 的贡献为 \(o(1)\)。同一定理给
\(\|c\|^2=(\log2+o(1))\log D\)，而
\(\max_a c_a^2=o(1)\)。于是 (8) 是
\((2\delta\log2+o(1))H I+cc^*\)，在算子范数意义下
成立；其最大特征值给出 (6)。\(\square\)

作为真实主压缩的直接推论，\(N\)--\(N\) 算术块只有乘积
为 \(2,3\) 的匹配边，范数为 \(O(1)\)；\(Z_*\)--\(Z_*\)
算术块为零，因为不同比值 \(a/b\in(1/2,2)\)，而
\(z_az_b\) 留下 \(r^2\) 分母。note 809 在
\(N\oplus Z_*\subset I_Q\) 上给同臂非算术核及 polar 扣款
\(O(H^{-1})\)，异臂 Archimedean 块可整体保留为正项。因此
\[
 \lambda_{\min}(A_{N\oplus Z_*})
 \ge 2H-\sqrt{(3\delta\log2+o(1))H}-O(1)>0.
 \tag{9}
\]

式 (6) 表明无界行重数在这个子图中仍只产生
\(\sqrt H\) 级交叉；要将**全部**增长根网格接入 note 824，
还须控制不同 \((q,r,b)\) 子图之间的带权重叠。

## 全部增长网格到近对角块的次线性交叉

上述重叠也能按是否消去根的分子分开。记
\(Y=\bigcup_x\{u_{x,q},v_{x,q}\}\)、
\(Z=\bigcup_x\mathcal Z_x\)，并令
\(N_0=N\setminus\mathcal X\)。下面给出比 \(O(\sqrt H)\)
弱、但足以保持线性谱隙的候选界：
\[
 \boxed{\quad
 \|C^-_{N,Z}\|+\|C^-_{N_0,Y}\|
 =O_{\theta,\delta}\!\left(\frac{H}{\sqrt{\log H}}\right)=o(H).
 \quad}\tag{10}
\]

先取 \(z=xq/r=aq/(br)\in Z\)、\(y\in N\)。因
\(q>r>T\)、\(x<2\) 且 \(z>H/2\)，有
\(z<2q/r\)；任何算术标签 \(n=z/y\) 或 \(n=zy\)
都满足 \(z/2<n<2z<4q/r<q\)。
若 \(y=z/n\)，其既约分子恰含唯一的大素数 \(q>T\)，
分母中大于 \(T\) 的素数至多是 \(r\) 与 \(n\) 的素数底。
若 \(y=n/z\)，则其既约分母恰含唯一的大素数 \(q\)，
分子中大于 \(T\) 的素数同样至多两个。因此固定 \(y\)
与边的符号后，\(q\) 唯一，\(r\) 至多有两种选择。

对任一给定的 \((y,q,r)\)，两种符号统一写成
\[
 x=nu,\qquad
 u=yr/q\quad(y=z/n),\qquad
 u=r/(qy)\quad(y=n/z).
 \tag{11}
\]
将 \(u=U/V\) 约至互素正整数，\(n=\ell^j\)。
若 \(n\nmid a\)，则 \(\ell\mid V\)：否则 \(n\) 在
\(x=nU/V\) 的既约分子中完整保留，使 \(a\ge n>T\)。
固定 \(\ell\mid V\) 时，\(1<x<2\) 把 \(\ell^j\)
限制在 \((V/U,2V/U)\)，所以 \(j\) 至多一个。
因 \(y\) 的分子、分母均小于 \(p\)，且 \(q,r<p\)，
有 \(V\le p^2\)；由不同素因子乘积至少为阶乘，
\(\omega(V)=O(H/\log H)\)。所以固定 \(y\) 的
\(n\nmid a\) 第二代邻居数为 \(O(H/\log H)\)。
另一方面，每个 \(z\) 的近对角边平方权重至多
\[
 \sum_{z/2<n<2z}\frac{\Lambda(n)^2}{n}
 \ll\log(2z)\ll H.
 \tag{12}
\]
逐行 Cauchy--Schwarz 再交换求和，给出这部分矩阵的范数
\(O(H/\sqrt{\log H})\)。

若 \(n\mid a\)，写 \(a=hn\)；两种边的近对角槽分别是
\(h q/(br)\) 与 \(br/(hq)\)。每一种符号下，槽的既约
分子、分母唯一确定 \((q,r,h,b)\)，而第二代标签唯一确定
\((q,r,b,a)\)；故矩阵按 \((q,r,b)\) 成直和。固定其中一块，
行指标为 \(h\)，列指标为 \(a\in(b,2b)\)，非零条目
为 \(c_{a/h}\)。以 \(h^{-1/2}\)、\(a^{-1/2}\) 作
Schur 权，行和与列和分别至多
\[
 \sum_{b/h<n<2b/h}\frac{\Lambda(n)}n
 \le\log2+o(1),\qquad
 \sum_{n\mid a}\Lambda(n)=\log a\le\log T.
 \tag{13}
\]
这里第一式一致成立：\(y\in(1,2)\) 与
\(q/r>H/4\) 强制 \(b/h>H/8\)。每种符号的消去边范数
平方至多 \((\delta\log2+o(1))H\)。两种符号相加仍为
\(O(\sqrt H)\)；其中正号消去边由 (5) 达到该平方首项。
这证明 (10) 中的 \(N\)--\(Z\) 界。

对孩子 \(t=sx\) 或 \(s/x\)，近对角算术标签
\(n=t/y\) 或 \(n=ty\) 满足 \(t/2<n<2t\)。
由 \(s>A/T\gg T\) 及 \(x\in(1,2)\)，有
\(n>s/4>T\)、\(n<4s<s^2\)。若 \(n=s\)，唯一
近对角目标是本根 \(x\)，已从 \(N_0\) 删除。
否则 \(n=\ell^j\)、\(\ell\ne s\)，而固定 \(y\)
与边类型唯一确定 \(s\)：比值边的 \(y\) 分子含唯一
大素数 \(s\)，乘积边的分母含唯一大素数 \(s\)。
四种孩子/边类型中，根可写成 \(x=nf\) 或 \(x=f/n\)，
其中 \(f\) 由 \((y,s)\) 固定且既约分子、分母至多
\(p^2\)。前一种若 \(\ell\) 不整除 \(f\) 的分母，
根分子至少为 \(n>T\)；后一种若 \(\ell\) 不整除
\(f\) 的分子，根分母至少为 \(n>T\)。因此每种类型
至多 \(O(H/\log H)\) 个 \(\ell\)，且 \(1<x<2\)
对每个 \(\ell\) 至多允许一个指数 \(j\)。每个孩子列的
平方权重仍由 (12) 的同型式界为 \(O(H)\)。相同的
逐行 Cauchy--Schwarz 证明 (10) 中的 \(N_0\)--\(Y\) 界。

由此还得到完整近对角块与增长两代网格的联合候选谱隙。
记 \(U=N\cup Y\cup Z=N_0\sqcup\mathcal V\)，并令
\(c_\theta=2-\sqrt{2(1-\theta^2)}>0\)。
在同一次删除 note 805 的正矩阵 \(B\) 后，(1) 的证明
给 \(A^{\rm red}_{\mathcal V}\succeq
(c_\theta H-O(\log H))I\)；\(N_0\) 的算术块只有
乘积为 \(2,3\) 的匹配，故
\(A^{\rm red}_{N_0}\succeq(2H-O(1))I\)。
式 (10)、根到 \(N_0\) 的 \(O(1)\) 匹配及整个
\(I_Q\) 的非算术 \(O(H^{-1})\) 界，使两块交叉
\(O(H/\sqrt{\log H})\)。因两块对角首项相隔
\((2-c_\theta)H\)，二块谱比较仅损失
\(O(H/\log H)\)。恢复 \(B\succeq0\) 得
\[
 \boxed{\quad
 \lambda_{\min}(A_U)
 \ge c_\theta H-O_{\alpha,\theta,\delta}(H/\log H)>0.
 \quad}\tag{14}
\]
此式覆盖全部近对角常值槽和一个有 \(\asymp T^2\) 个根的
两代高斜率网格，但仍是有限主压缩，且尚待异源复核。

## 到适中斜率块的尺度加权交叉

令 \(M_R\) 为 note 824 的 \(A<\operatorname{num}(y)\le S\)、
\(2\le y\le R=\lfloor H/2\rfloor\) 全部常值槽。
上节的统一度数界与此处一列的 \(O(H\log H)\) 平方质量
直接相乘只给 \(O(H)\) 范数；按素数标签的大小支付度数后得到
\[
 \boxed{\quad
 \|C^-_{M_R,Y\cup Z}\|
 =O_{\theta,\delta}(\sqrt{H\log H})=o(H).
 \quad}\tag{15}
\]

对任一高斜率槽 \(t\in Y\cup Z\) 和 \(y\in M_R\)，
算术标签 \(n\) 只可能满足
\[
 t/R<n\le t/2\quad(y=t/n),
 \qquad 2t\le n\le Rt\quad(y=n/t).
 \tag{16}
\]
固定 \(t\) 时，每种符号下的 \(n\mapsto y\) 单射。
素数标签的加权列和由 Mertens 公式满足
\[
 \sum_{\substack{n\text{ 素数}\\ n\text{ 满足 }(16)}}
 \frac{\log n}{n}=O(\log R)=O(\log H),
 \tag{17}
\]
而全部高次素数幂的列平方质量统一有界：
\[
 \sum_{\ell\text{ 素数}}\sum_{j\ge2}
 \frac{(\log\ell)^2}{\ell^j}<\infty.
 \tag{18}
\]

先处理 \(z=aq/(br)\in Z\)。因 \(r>A/T\gg H\)、
\(R\le H/2\)，(16) 的每个 \(n<Rz<q\)。
固定 \(y\) 与边的符号后，\(q\) 是 \(y\) 既约分子
（比值边）或分母（乘积边）中唯一大于 \(T\) 的素数；
\(r\) 至多有两个选择。固定一个 \((y,q,r)\) 后，
式 (11) 仍将根写为 \(x=nU/V\)，其中 \((U,V)=1\)、
\(V\le p^2\)。若 \(n\nmid a\)，其素数底 \(\ell\mid V\)，
且 \(1<x<2\) 使每个 \(\ell\) 至多给一个指数。

若这些标签 \(n=\ell\) 本身是素数，则同一
\((y,q,r)\) 类的全部 \(\ell\) 位于 \((V/U,2V/U)\)。
写 \(N=V/U\)。若 \(N<2\)，区间 \((N,2N)\)
至多含素数 \(2,3\)；若 \(N\ge2\)，互异的 \(d\) 个
这种素数的乘积至少为 \(N^d\)，又整除 \(V\le p^2\)。
因 \(\log\ell\le\log(2N)\le2\log N\)，
对该类中任一 \(\ell\) 有
\[
 d\le \frac{2H}{\log N}
 \ll \frac{H}{\log(2+\ell)}
 \tag{19}
\]
（\(N<2\) 时同样成立）。
逐 \(y\) 分成至多四个符号/\(r\) 类作 Cauchy--Schwarz，
再交换求和。每个 \(z\) 的结果由 (17) 控制为
\[
 \|C^-_{M_R,Z;\ n\text{ 素数},\ n\nmid a}\|^2
 \ll H\sum_{\substack{n\text{ 素数}\\n\text{ 满足 }(16)}}
 \frac{c_n^2}{\log(2+n)}
 \ll H\log H.
 \tag{20}
\]
对 \(n=\ell^j,\ j\ge2\) 只用每行
\(O(H/\log H)\) 个候选及 (18)，范数平方
\(O(H/\log H)\)。

余下 \(n\mid a\) 的边仍写为 \(a=hn\)、
\(y=hq/(br)\) 或 \(y=br/(hq)\)，按 \((q,r,b)\)
直和。每块用 (13) 的同一 Schur 权：列和
\(\le\log T\)，行和
\(\sum_{b/h<n<2b/h}\Lambda(n)/n=O(1)\)，
此处不要求 \(b/h\to\infty\)。故消去边范数
\(O(\sqrt H)\)。这证明 \(Z\) 部分的 (15)。

孩子 \(t=sx\) 或 \(s/x\) 的标签也满足 (16)。
由于 \(s>A/T\gg TR\)，有 \(n>s/(2R)>T\)
和 \(n<4Rs<s^2\)。若 \(n=s\)，目标是根 \(x<2\)
或 \(1/x<1\)，不在 \(M_R\)；因此 \(n\) 与 \(s\)
互素。固定 \(y\)、比值/乘积符号及正负孩子臂后，
\(s\) 是 \(y\) 分子/分母中唯一大于 \(T\) 的素数。
与式 (10) 的孩子论证一样，\(x=n f\) 或 \(x=f/n\)，
其中 \(f\) 的既约分子、分母不超过 \(p^2\)；
素数标签 \(n=\ell\) 必须整除相应的分母或分子。
根条件 \(1<x<2\) 又把这类 \(\ell\) 限制在一个
倍数为 \(2\) 的区间。因此每个类别的素数度数满足
(19)，由 (17) 得范数平方 \(O(H\log H)\)。
高次素数幂的 \(O(H/\log H)\) 行度数和 (18) 给较小界。
两条孩子臂相加，证明 (15)。\(\square\)

式 (15) 的 \(\sqrt{H\log H}\) 阶在前述碰撞构造的
另一截面上已经尖锐。仍取 \(\theta=1/3\)、
\(0<\delta<1/6\)、\(D,r,q\) 及
\(Z_*=\{z_a=a q/(Dr):D<a<2D,\ a\text{ 素数}\}\)。
对每个 \(a\) 和素数幂 \(n\) 落在
\[
 z_a/R<n<z_a/2\quad\text{或}\quad
 2z_a<n<Rz_a,
 \tag{20a}
\]
相应 \(y=z_a/n\) 或 \(y=n/z_a\) 都在 \(M_R\)。
确实，两种目标的斜率落在 \((2,R)\)；其既约分子
分别是 \(aq\) 与 \(nDr\)，均大于 \(A\) 且至多
\(O(HDA)=o(S)\)。这里 \(n\) 不能含 \(a\) 或 \(q\)
作素数底：第一段有 \(n<z_a/2<a\)，第二段有
\(n>2z_a>a\) 而 \(n<Rz_a\ll a^2,q\)。
故上述分子没有被约掉。

不同 \(a,b\) 的第一类目标若相同，素数幂标签必为
\(n=a,m=b\)，与 \(n<z_a/2<a\) 矛盾；第二类
相同也强制 \(n=a,m=b\)，与 \(n>2z_a>a\) 矛盾。
两类混合相同会使两个素数幂之积等于非整数
\(z_az_b\)。故 \(C^-_{M_R,Z_*}\) 的不同列精确正交，
其范数平方等于最大列平方和。素数加权 Mertens 公式
\(\sum_{n\le X}\Lambda(n)^2/n
=\tfrac12\log^2 X+O(\log X)\) 给出，均匀于
\(z_a\in(D,4D)\)，
\[
\begin{aligned}
\|C^-_{M_R,Z_*}\|^2
&=\max_a\left(
 \sum_{z_a/R<n<z_a/2}\frac{\Lambda(n)^2}{n}
 +\sum_{2z_a<n<Rz_a}\frac{\Lambda(n)^2}{n}\right)\\
&=\max_a\bigl(2\log z_a\,\log(R/2)+O(H)\bigr)\\
&=(2\delta+o(1))H\log H.
\end{aligned}\tag{20b}
\]
因此 (15) 的阶不能统一降到 \(O(\sqrt H)\)；
其相对于线性谱隙仍为 \(o(H)\)。

## 到深高斜率块的素因子交叉

令 \(D_A\) 为 note 823--824 的
\(\operatorname{num}(y)\le A,\ y\ge2\) 全部槽。
增长根使固定根稿的 \(O_{a,b}(1)\) 常数失去一致性，
但可保留次线性候选界
\[
 \boxed{\quad
 \|C^-_{D_A,Y\cup Z}\|
 =O_{\theta,\delta}\!\left(\frac{H}{\sqrt{\log H}}\right)=o(H).
 \quad}\tag{21}
\]

每个 \(t\in Y\cup Z\) 的既约分子 \(m_t>A\)。
若 \(y=nt\)，约分后的分子至少为 \(m_t\)，
所以 \(y\notin D_A\)。若 \(y=t/n\)，要使分子降到
\(A\) 以下，\(n=\ell^j\) 的底 \(\ell\) 必须整除
\(m_t\)。若 \(y=n/t\ge2\)，原分子
\(n\operatorname{den}(t)>2m_t>2A\)，同样只有
\(\ell\mid m_t\) 才可能在约分后落到 \(D_A\)。
对孩子 \(m_t=as\) 或 \(bs\)，对二代 \(m_t=aq\)。
其中大素数标签 \(n=s^j\) 或 \(q^j\) 也不产生
\(D_A\) 边。逐项约分如下，其中 \(j\ge1\)：
\[
\begin{array}{c|cc}
t&t/n&n/t\\ \hline
sa/b & a/(bs^{j-1}) & bs^{j-1}/a\\
sb/a & b/(as^{j-1}) & as^{j-1}/b\\
aq/(br)&a/(brq^{j-1})&brq^{j-1}/a
\end{array}
\]
左列或小于 \(1\)，或在 \(j=1\) 时等于根
\(a/b<2\)；右列在 \(j=1\) 时或小于 \(1\)、
或等于根，或分子 \(br>A\)，而 \(j\ge2\) 时
分子至少 \(bs>A\)、\(as>A\) 或 \(br>A\)。
所以所有实际标签的素数底均整除相应的根坐标
\(m=a\) 或 \(b\)，其中 \(m\le T\)。

对每个源列，放弃目标限制后的平方边权总和至多
\[
 \sum_{\ell\mid m}\sum_{j\ge1}
 \frac{(\log\ell)^2}{\ell^j}
 =\sum_{\ell\mid m}\frac{(\log\ell)^2}{\ell-1}
 \ll\sum_{\ell\mid m}\log\ell
 \le\log m\le\log T\ll H.
 \tag{22}
\]
当 \(n\) **不整除**这个小坐标 \(m\) 时，
固定 \(y\) 的候选源数为 \(O(H/\log H)\)。
对二代，\(q,r\) 分别是 \(y\) 既约分子、分母中的
唯一大素数（比值边）或顺序相反（乘积边），
因标签底 \(\ell\le T\) 不能消去它们；固定
\((y,q,r)\) 后仍有式 (11) 的 \(x=nU/V\)。
若 \(n\nmid a\)，则 \(\ell\mid V\)，每个
\(\ell\) 至多一个指数。对孩子，固定 \(y\)、
孩子臂及边型后大素数 \(s\) 唯一；根为
\(x=nU/V\) 或 \(x=U/(Vn)\)。分别在
\(n\nmid a\) 或 \(n\nmid b\) 时，\(\ell\)
必须整除固定的 \(V\) 或 \(U\)，且仍至多一个指数。
这些固定整数均不超过 \(p^2\)，故其不同素因子数
\(O(H/\log H)\)。逐行 Cauchy--Schwarz 与 (22)
于是给非消去边的范数 \(O(H/\sqrt{\log H})\)。

余下 \(n\mid m\) 的消去边按大素数标签与另一根坐标
直和。二代 \(a=hn\) 时目标为 \(hq/(br)\) 或
\(br/(hq)\)，块指标为 \((q,r,b)\)。孩子正臂
\(a=hn\) 时目标为 \(sh/b\)，块指标为 \((s,b)\)；
孩子负臂 \(b=hn\) 时目标为 \(sh/a\)，块指标为
\((s,a)\)。同一块中根条件 \(1<a/b<2\) 使
\(n\) 对每个目标余因子 \(h\) 位于一个倍数为 \(2\)
的区间。用 (13) 的 \(h^{-1/2}\)、\(m^{-1/2}\)
Schur 权，行和为 \(O(1)\)，列和至多
\(\sum_{n\mid m}\Lambda(n)=\log m\le\log T\)。
各块及有限种边型的范数为 \(O(\sqrt H)\)，
证明 (21)。\(\square\)

## 与已覆盖 Farey 背景的联合候选谱隙

现在取 \(\theta=1/3\)、\(0<\delta<1/6\)、
\(\rho=1/2\) 及 note 824 的其他固定参数。
令 \(F=D_A\oplus N\oplus G\oplus E\oplus M_R\)，
并取其完整低斜率外区 \(L\)。由于 \(Y\cup Z\)
落在 note 824 唯一遗漏的高斜率中分子带，
式 (14)、(15)、(21) 与原有跨块估计给
\[
 \boxed{\quad
 A_{F\oplus Y\oplus Z}
 \succeq(\kappa_*-o(1))H I,
 \qquad
 \kappa_*:=\min\{1-\sqrt5/3,\gamma_r\}>0.
 \quad}\tag{23}
\]
这里必须把根与孩子的 \(H\) 级边留在同一个块中。
具体地，置 \(P=N\oplus Y\oplus Z\)。式 (14) 在
\(\theta=1/3\) 给其删正矩阵版下界
\((2/3-o(1))H\)，note 823 给
\(D_A\) 下界 \((4/3-o(1))H\) 和
\(\|A^{\rm red}_{D_A,N}\|\le(2/3+o(1))H\)。
式 (21) 使新增 \(D_A\)--\((Y\oplus Z)\) 交叉
为 \(o(H)\)，故 \(D_A\oplus P\) 的标量比较首项为
\(\left(\begin{smallmatrix}4/3&-2/3\\-2/3&2/3\end{smallmatrix}\right)H\)，
最低特征值 \((1-\sqrt5/3)H\)。

置 \(C=G\oplus E\oplus M_R\)。note 824 的删正
矩阵证明给 \(A^{\rm red}_{C}\succeq(\gamma_r-o(1))H\)。
原有 \(D_A\oplus N\) 到 \(C\) 的交叉是 \(o(H)\)；
新增 \(Y\oplus Z\) 到 \(M_R\) 由 (15) 支付，
到 \(G,E\) 分别由 notes 819、813 对整个
\(I_S\) 的矩形界支付，均为 \(O(\sqrt{H\log H})\)。
两块比较后恢复同一个正异臂矩阵 \(B\)，得到 (23)。

最后，\(Y\cup Z\subset I_S\)、\(S<Q/r\)，
note 822 的坐标排除给 \(C^-_{L,Y\cup Z}=0\)；
非算术与 polar 交叉为 \(O_r(1)\)。note 824 已给
\(A^{\rm red}_{L}\succeq
(\log H-\log\log H-O(1))I\) 及
\(\|A^{\rm red}_{L,F}\|=O(\sqrt H)\)。
利用 (23) 完成平方，再加入 note 804 的全阶跃偶极
\(W_p\) 和 note 806 的 \(O(1)\) 混合界，得到
\[
 \boxed{\quad
 A_{F\oplus Y\oplus Z\oplus L}
 \succeq(\log H-\log\log H-O(1))I,
 \qquad
 A_{W_p\oplus F\oplus Y\oplus Z\oplus L}
 \succeq(c_0-o(1))I.
 \quad}\tag{24}
\]
其中 \(c_0=1+\gamma_E-\log\pi+\delta_0>0\)。
这在真实有限主压缩中联合纳入 note 824 的整个背景和
\(\asymp T^2\) 个根的两代高斜率网格；尚待异源复核。

## 边界

式 (24) 只加入所选增长双素数网格，尚未覆盖完整高斜率
遗漏带。非恒定轮廓、无限维补空间和
moving-\(N\) Möbius signed covariance 均仍开放。
