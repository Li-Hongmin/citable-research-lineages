# Candidate: growing near-diagonal Farey roots and their prime descendants

Let p run through odd primes, P=p-1, H=log p, Q=floor(P/H), S=floor(P/H^alpha), A=floor(P^theta), with fixed alpha>1, 0<theta<1 and 0<delta<theta/2. Put B=floor(P^delta) and

X_p={x=a/b: 1<b<a<=B, (a,b)=1, 1<x<2}.

For each x=a/b in X_p, take prime children qx=aq/b for primes q with A<aq<=S and q/x=bq/a for primes q with A<bq<=S. Let Y_p be the union of these children, and V_p=span{psi_x:x in X_p union Y_p}. All children lie in the middle high-slope set U={A<num<=S, slope>floor(H/2)} for sufficiently large p. Claim:

lambda_min(P_V A_{p^2,-}P_V)=(2-sqrt(1-theta^2)+o(1))H.

More precisely, A_YY=2H I+O(1), A_XX=2H I+O(1), and, in the root basis indexed by a/b,

A_XY A_YY^{-1} A_YX
= [(1-theta)/2] H diag_{a/b in X_p}(1+theta-log(ab)/H)+o(H)I,

where the error is in operator norm uniformly as |X_p| grows. Thus the root Schur remainder is >=((3+theta^2)/2-o(1))H I.

Proof for adversarial review:

1. Every child prime q obeys q>A/B=p^{theta-delta+o(1)}>B eventually, since delta<theta/2. Every numerator and denominator of a product or ratio of two roots is a divisor of a product of root numerators or denominators, each <=B. Thus all of its prime factors are <=B, even though its numerical value can be as large as B^2. Hence q cannot divide any root numerator, denominator, or any two-root rational factor. Distinct children never coincide: an equality between children with primes q,q' would make q/q' such a two-root rational factor, hence forces q=q'; then equal arms require equal roots, while mixed arms require the product of two roots to be 1. Root and child coordinates are also disjoint.

2. Write C^-=C_parallel-C_cross as in note 807 and c_q=(log q)/sqrt q. A root x connects arithmetically to its own qx child by +c_q and to its own q/x child by -c_q. The q>B prime-factor observation excludes all other root-child arithmetic edges. Thus the root-child arithmetic block W has disjoint row supports and WW^* is diagonal with entries

Sigma_{a,b}=sum_{A/a<q<=S/a} (log q)^2/q + sum_{A/b<q<=S/b}(log q)^2/q,

where q is prime. Uniform PNT/partial summation over all a,b<=B, using q>=p^{theta-delta+o(1)}, gives

Sigma_{a,b}=(1-theta)H^2(1+theta-log(ab)/H)+o(H^2)

uniformly. In particular max_{X_p}Sigma_{a,b}=(1-theta^2+o(1))H^2, because the fixed root 3/2 is present and log(ab)>=0.

3. In the child-child arithmetic block, q!=q' gives no edges: ratios retain an uncanceled q' in the denominator and products retain distinct large primes q,q'. For a common q, plus-plus and minus-minus ratios of roots lie strictly in (1/2,2); their products q^2 x_i x_j or q^2/(x_i x_j) cannot be prime powers because x_i x_j>1 is a rational with factors <q. Mixed-arm ratio is x_i x_j in (1,4), so only 2 or 3 contribute; for each root x_i there is at most one partner 2/x_i and one partner 3/x_i. Mixed-arm product q^2 x_i/x_j is a prime power only for i=j, giving c_{q^2}=(log q)/q. Thus each q block has maximum absolute row sum <=c_2+c_3+o(1), and the whole C^-_YY has O(1) norm independent of |X_p|. Root-root C^-_XX has O(1) norm for the same bounded-ratio/product reason (note 821).

4. All roots and children have numerator<=S<Q. Note 809 gives the full I_Q same-arm nonarithmetic and polar norms O(H^-1). For the positive opposite-arm Archimedean B, use ||B||<=tr B. A root has slope x>=1+1/B, so M_Delta(2log x)<<Delta B; there are O(B^2) roots, giving O(Delta B^3). A child has slope >H/2, hence M_Delta(2log x)<<Delta; there are at most O(B^2 S) children, giving O(Delta B^2 S). Since Delta~1/(2p^2), delta<theta/2<1/2, both tend to zero. Thus B has o(1) norm on V_p. The exact Farey constant-slot formula now gives A_V=2H I-C^-_V+O(1) uniformly in operator norm.

5. By steps 2-4, A_YY=2H I+O(1), A_XX=2H I+O(1), A_XY=-W+o(1) (or O(1) suffices), and ||W||=(sqrt(1-theta^2)+o(1))H. The block matrix has lowest eigenvalue 2H-||W||+O(1), proving the spectral claim. Also A_YY^{-1}=(2H)^{-1}I+O(H^-2). Since ||W||=O(H), the true Schur response is WW^*/(2H)+O(1), and step 2 gives the displayed diagonal asymptotic uniformly. Since log(ab)>=0, its maximal coefficient is <=(1-theta^2)/2, yielding the root remainder.

Find any collision missed when X_p grows, failure of the uniform PNT error, or hidden O(H) contribution in B. Read only directly relevant notes; do not edit files, run computations, or use remote machines. An invalid theorem is an acceptable verdict.
