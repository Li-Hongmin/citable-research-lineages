# 平方自由双臂临界图的自然正权向量有严格正 Weil Rayleigh 极限（候选）

本稿的修正常数和完整证明已纳入 [note 793](../notes/793-fixed-prime-cylinder-profiles-have-positive-squarefree-two-arm-weil-limits.md)，以后者为准。

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实旧奇 Weil 压缩及相离槽核界、[note 792](../notes/792-a-single-squarefree-two-arm-farey-family-has-critical-arithmetic-radius.md) 的平方自由双臂家族和二变量调和质量。以下只判定一个指定临界向量；尚待异源复核，留在 scratch。

## 命题

沿 note 792 取 \(k=p^2\)、\(L=2\log p\)、\(X=(p-1)/4\)、\(Y=(p-1)/3\)，并设
\[
u_p=\sum_{(n,m)\in\mathcal N_p}\frac{w_{x_{n,m}}}{\sqrt{nm}}.
\]
记
\[
\beta_5=\lim_{t\to\infty}
\left(\sum_{5\le q\le t\atop q\text{ prime}}\frac{\log q}{q}-\log t\right),
\qquad
F_\infty=2\sum_{q\ge5\atop q\text{ prime}}\frac{\log q}{q(q+2)}.
\]
两个常数均收敛，且 \(\beta_5<0\)、\(F_\infty>0\)。真实 Weil Rayleigh 值有精确极限
\[
\boxed{\quad
\lim_{p\to\infty}\frac{\langle u_p,A_{p^2,-}u_p\rangle}{\|u_p\|^2}
=K_{4/3}:=1-\gamma_E-\log\pi+\log24-2\beta_5+F_\infty>0.
\quad} \tag{1}
\]
其正性只排除该指定正权轮廓作为负方向；note 792 的整个主压缩仍处于符号未定的 \(O(1)\) 临界带。

## 精确平方自由图行式

对 \((n,m)\in\mathcal N_p\)，将原始比值 \(4n/(3m)\) 的 \(q\ge5\) 素数指数记为 \(+1\)（\(q\mid n\)）、\(-1\)（\(q\mid m\)）或 \(0\)。note 791 式 (4) 的素数幂边在两个标签的原始比值相除时，恰要求仅一个指数改变：\(0\leftrightarrow\pm1\) 的权为 \(c_q=(\log q)/\sqrt q\)，\(+1\leftrightarrow-1\) 的权为 \(c_{q^2}=(\log q)/q\)。原始比值相乘保留 \(16/9\) 或其倒数，不可能额外产生素数幂边；折回到大于一的 Farey 标签只把比值边与乘积边互换。因为 \(\mathcal N_p\) 中没有 \(2,3\) 因子，家族内部也没有以 \(2,3\) 为底的边或自环。

令 \(v_{n,m}=(nm)^{-1/2}\)、\(a_q=(\log q)/q\)，并记 \(P_5(t)=\sum_{5\le q\le t,\ q\text{ 素数}}a_q\)。下式中的 \(q\) 始终为素数。上述分类给出**精确**加权行式
\[
\begin{aligned}
r_{n,m}:=\frac{(C_{S_p}v)_{n,m}}{v_{n,m}}
={}&\log n+\log m
+P_5(X/n)+P_5(Y/m)\\
&-\sum_{\substack{q\mid nm\\q\le X/n}}a_q
-\sum_{\substack{q\mid nm\\q\le Y/m}}a_q\\
&+\sum_{\substack{q\mid n\\mq\le Y}}a_q
+\sum_{\substack{q\mid m\\nq\le X}}a_q.
\end{aligned} \tag{2}
\]
前两行是删去各坐标素数及给任一坐标加入新素数；末行是将已有素数从一个坐标移到另一个坐标的 \(q^2\) 边。乘积 \(nm\) 在末行不变，所以该边的加权贡献仍为 \(a_q\)。

## 调和平均

记 \(Z=\|v\|^2=\sum_{n\le X,m\le Y}g(n,m)/(nm)\)，其中 \(g(n,m)=\mu^2(nm)\mathbf1_{(nm,6)=1}\)。note 792 式 (4)--(5) 给 \(Z\sim\mathfrak c\log X\log Y\)、\(\mathfrak c>0\)。对于每个固定素数 \(q\ge5\)，把其 Euler 局部因子 \(1+q^{-s}+q^{-t}\) 分别换成 \(q^{-s}\) 与 \(q^{-t}\)，同一调和卷积证明
\[
\Pr_v(q\mid n)\to\frac1{q+2},\qquad
\Pr_v(q\mid m)\to\frac1{q+2},\qquad
\Pr_v(q\mid nm)\to\frac2{q+2}. \tag{3}
\]
这里概率按权 \(g(n,m)/(nmZ)\) 定义。丢去 \(g\) 的限制并使用 \(Z\gg(\log X)(\log Y)\)，还一致得到 \(\Pr_v(q\mid nm)\ll1/q\)。因此带权 \(a_q\) 的素数和可用 \(\sum_q(\log q)/q^2<\infty\) 支配。

经典素数定理与 \(-\zeta'/\zeta(1+s)=s^{-1}-\gamma_E+O(s)\) 给
\[
P_5(t)=\log t+\beta_5+o(1),\qquad
\beta_5=-\gamma_E
-\sum_{q}\sum_{r\ge2}\frac{\log q}{q^r}
-\frac{\log2}{2}-\frac{\log3}{3}<0. \tag{4}
\]
对任意固定 \(T\)，\(\Pr_v(X/n\le T)\ll(\log T+1)/\log X\to0\)，且 \(P_5(t)-\log t\) 一致有界；故 (4) 可在调和平均下应用于 \(X/n\)，同理应用于 \(Y/m\)。

在 (2) 的两个排除和中，对固定 \(q\) 的截止 \(q\le X/n\) 或 \(q\le Y/m\) 以概率趋于一；在两个换臂和中，\(mq\le Y\) 或 \(nq\le X\) 同样如此。由 (3) 与上述可和支配，两个排除和各自的平均趋于 \(F_\infty\)，两个换臂和的**合计**平均趋于 \(F_\infty\)。于是
\[
\frac{\langle v,C_{S_p}v\rangle}{Z}
=\log X+\log Y+2\beta_5-F_\infty+o(1)
=L-\log12+2\beta_5-F_\infty+o(1). \tag{5}
\]

## Archimedean 接触项

note 791 式 (6) 写真实压缩为 \(D_kI-C_p+E_p\)，其中 \(D_k=L+1-\gamma_E-\log\pi\)、\(\|E_p\|=O(1)\)。令 \(Q=\lfloor p/\log p\rfloor\)，把 \(4n,3m\le Q\) 的标签称为内区。note 792 式 (4) 对截止 \(Q/4,Q/3\) 同样成立，所以内区的 \(v^2\) 质量占比趋于一。

不同内区 Farey 物理中心的对数距离 \(d\gg Q^{-2}\)，同一偶极的两臂距离 \(\gg Q^{-1}\)。note 791 式 (12) 的交叉界 \(O(\Delta^3/d^3)\)、\(\Delta\asymp p^{-2}\) 与内区中心间距求和给非对角绝对行和 \(O(\Delta^3Q^6)=O((Q/p)^6)=o(1)\)。但 note 791 式 (13) 的 \(D_k+O(\Delta)\) 是**单半槽**对角。写 \(\varphi_z=(e_--e_+)/\sqrt2\)，其中左右半槽均归一化；由式 (11) 的相离核及 \(K(d)=1/(2d)+O(1)\)，其接触交叉为
\[
\langle e_-,G_ke_+\rangle
=-\Delta^{-1}\int_0^\Delta\!\int_0^\Delta K(s+t)\,ds\,dt
=-\log2+O(\Delta).
\]
因此每个物理偶极的对角为 \(D_k+\log2+O(\Delta)\)；polar 压缩范数为 \(o(1)\)，所以内区 \(E_p-(\log2)I\) 的算子范数为 \(o(1)\)。用整体 \(\|E_p\|=O(1)\) 支付质量占比趋零的外区，得到
\[
\frac{\langle v,E_pv\rangle}{Z}=\log2+o(1). \tag{6}
\]
式 (5)--(6) 与 \(D_k\) 给 (1)。最后 \(\gamma_E<1\)、\(\pi<12\)、\(\beta_5<0\)、\(F_\infty>0\) 直接给 \(K_{4/3}>0\)。\(\square\)

## 边界

临界算术谱半径由整棵平方自由双臂图达到，但自然正权向量的真实 Weil 能量趋于严格正常数。要判定最低谱值，必须控制不同于该常值正权轮廓的谱变形及其完整正交补反馈；本文未证明全尺度局部 Weil 正性、moving-\(N\) 算术门或 RH。
