# Farey 间距控制真实半槽的异号算术算子范数（待独立复核）

日期：2026-09-29。依赖 [note 780](../notes/780-all-prime-power-half-slots-give-nine-thirty-seconds-logarithmic-physical-inverse-response.md) 的真实半槽异号相交条件与 [note 786](../notes/786-all-integer-same-arm-arithmetic-response-ceiling.md) 的全整数同号图配方。本文对任意系数控制异号算术压缩，而非只对固定轮廓求一个加权总和。

## 定理

令整数 \(k\ge7\)、\(2\le X<k\)，令 \(e_n\)、\(2\le n\le X\) 为 note 782 的归一化奇半槽，\(P_X\) 为其张成空间的正交投影。将旧算术压缩的同号边扣除后所得异号矩阵记为 \(R_{k,X}^{\rm opp}\)。存在绝对常数 \(C\)，使
\[
\boxed{\|R_{k,X}^{\rm opp}\|\le C\left(1+\frac{X^2\log(2X)}{k^{3/2}}\right).}
\tag{1}
\]
因此，对任意固定 \(0<\alpha<3/4\)、\(X=k^\alpha\)，异号算术压缩的范数为 \(O_\alpha(1)\)。对每个这样的固定 \(\alpha\)，存在 \(C_\alpha,k_0(\alpha)\)，使全部整数 \(k\ge k_0(\alpha)\) 上的真实旧奇算子在全部整数半槽上的主压缩 \(M_{k,X}=P_XA_{k,-}P_X|_{P_XH_k}\) 满足
\[
\boxed{M_{k,X}\succeq T_{k,X}-C_\alpha I\succ0,\qquad
\limsup_{k\to\infty}\frac{\langle P_Xb_k,M_{k,X}^{-1}P_Xb_k\rangle}{\log k}
\le U(\alpha)=\alpha+(1-\alpha)\log(1-\alpha).}
\tag{2}
\]
特别地，先固定 \(\alpha<3/4\) 再令 \(k\to\infty\)，此完整主压缩的逆响应保证系数统一不超过 \(3/4-(\log4)/4<1\)。这里的逆只作用于主压缩，不是完整旧核的逆。

## 固定一行的有理数间距

note 780 的整数支撑分析表明，一个方向要求 \(k<qnm<k+1\)，不可能；另一方向必须满足
\[
qk<nm<q(k+1),\qquad q\ge2\text{ 为素数幂}.
\tag{3}
\]
每条 \((n,m,q)\) 的矩阵元绝对值至多 \(2\Lambda(q)/\sqrt q\)，因为平移算子及半槽向量的范数至多一。固定 \(n\le X\)，由 \(m\le X\) 得
\[
q< Q_n:=\frac{nX}{k}<n,
\qquad \frac{k}{n}<\frac{m}{q}<\frac{k+1}{n}.
\tag{4}
\]
对固定 \(q<n\)，(3) 中允许的 \(m\) 位于长度 \(q/n<1\) 的区间，故至多一个。
若 \(Q_n\le2\)，该行没有异号算术边；以下只考虑 \(Q_n>2\)。

把 \(m/q\) 约为 \(a/b\)。分母 \(b\mid q\)，所以若 \(q=p^r\)，则 \(b=p^s\)。\(b=1\) 不可能：此时 \(m/q=a\in\mathbb Z\)，而 (4) 将迫使整数 \(na\) 严格位于 \(k\) 和 \(k+1\) 之间。固定约分分数 \(a/b\) 时，所有可能的 \(q\) 属于 \(b,bp,bp^2,\ldots\)，因此该分数上的全部边权至多
\[
2\sum_{r\ge0}\frac{\log p}{\sqrt{bp^r}}
\le C\frac{\log b}{\sqrt b}.
\tag{5}
\]

把分母按 \(B\le b<2B\) 分组，其中 \(B=2,4,8,\ldots\)。同一组中不同既约分数的间距至少 \(1/(4B^2)\)。它们均落在长度 \(1/n\) 的区间 (4) 内，故个数至多 \(1+4B^2/n\)。结合 (5)，第 \(B\) 组对固定行的绝对和至多
\[
C\frac{\log(2B)}{\sqrt B}\left(1+\frac{B^2}{n}\right).
\]
对 \(B\le Q_n\) 求和，利用几何级数给出
\[
\sum_{m\le X}|R_{k,X}^{\rm opp}(n,m)|
\le C\left(1+\frac{Q_n^{3/2}\log(2Q_n)}{n}\right)
\le C\left(1+\frac{X^2\log(2X)}{k^{3/2}}\right).
\tag{6}
\]
异号矩阵自伴，因此同一界也控制列和。Schur 行和界证明 (1)。

## 完整旧核主压缩

为把 note 786 的 Archimedean 行和估计扩展到 \(nm>k\)，先看同号半槽。因不同整数指标的对数间距至少为 \(c|n-m|/X\gg\Delta\)，其绝对行和仍为 \(O(X\log X/k)=o(1)\)。异号半槽令 \(w=nm\)。note 780 的两侧距离公式为
\[
\delta_w=\begin{cases}\log(k/w),&w\le k,\\
\log(w/(k+1)),&w\ge k+1.
\end{cases}
\]
当 \(w<k/2\) 或 \(w>2k\) 时，各矩阵元为 \(O(k^{-1})\)，每行合计 \(O(X/k)\)。在 \(k/2\le w\le2k\) 内，note 780 的接触槽积分给出 \(C/(1+|w-k|)\)。固定 \(n\) 后，\(w=nm\) 的步长为 \(n\)，故这一行的近区和至多 \(C(1+\log(2X)/n)\)。近区只可能在 \(n\ge k/(2X)\)，故统一至多 \(C(1+X\log(2X)/k)=O(1)\)。矩阵对称，Schur 行和界证明 Archimedean 差额的算子范数为 \(O(1)\)；\(n=m\) 的自槽交叉也计入其中。

polar 压缩满足
\(\|P_Xs_k\|^2\ll k^{-3/2}X^2+k^{-1/2}\log X=o(1)\) 当 \(\alpha<3/4\)。于是 (1) 和 note 786 的同号图恒等式合并给出
\(M_{k,X}\succeq T_{k,X}-C_\alpha I\)。note 786 的对角下界与逆序比较给出 (2)，其 forcing 余项 \(\|b_k-b_k^{\rm arith}\|=O(1)\) 只贡献 \(O_\alpha(1)\)。\(\square\)

## 边界

式 (1) 是对真实异号算术边的全系数算子范数估计；它不控制该半槽空间与其正交补之间的 Schur 反馈。式 (2) 只对固定 \(\alpha<3/4\) 后的充分大整数 \(k\) 成立，不涵盖端点 \(\alpha=3/4\) 或 \(\alpha=\alpha(k)\uparrow3/4\)。它是主压缩的正性和逆响应上界，不能上升为完整 \(A_{k,-}\) 的正性或逆响应上界，也不证明 moving-\(N\) Möbius signed covariance 或 RH。
