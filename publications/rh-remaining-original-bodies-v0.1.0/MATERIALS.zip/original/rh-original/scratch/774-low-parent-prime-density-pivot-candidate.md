# 小 parent 的素数槽局部密度与全 parent 单胞总扣款：待独立复核

日期：2026-09-29。依赖 notes 771–772。仍只研究真实 ground 的单胞 \(\mathfrak b\) common-cut；不识别完整 Weil harmonic graph。

## 候选定理

固定 \(A>3\)。当 \(1\le m\le(\log k)^A\)、\(\mathcal N_{k,m}\ne\varnothing\) 时，note 772 的两种单胞短化约定都满足
\[
\boxed{c_A\log k\le P_{k,m}^{\rm ex}\le\log(k/m)+O(1)}
\tag{1}
\]
其中 \(c_A>0\)。这包括每个固定 \(m\)，将 note 771 的 \(\log\log k\) 下界提升一个量级。

进一步，对所有非空 parent 求和，有
\[
\boxed{
\sum_m\frac{\theta_{k,m}^2b_m^2}{P_{k,m}^{\rm ex}}
=(1+o(1))\log k,
\qquad
\sum_m\langle\lambda_m,(D_{k,m}^{\rm src})^{-1}\lambda_m\rangle
=(1+o(1))\log k.}
\tag{2}
\]
第二式的 forcing 是 note 772 的原始 \(\lambda_m=(\Lambda(n)/\sqrt n)_n\)，仅在单胞 source-ground 矩阵中取逆。

## 素数槽的局部密度

置 \(R=k^{1/4}\)、\(\varepsilon=w_k/w_m\)、\(S_m=\bigcup_{n\in\mathcal N_{k,m}}I_n\)。对 parent 坐标中的任意区间 \(J\subset(0,1)\)，若 \(|J|=r\ge R^{-1}\)，则
\[
\boxed{|S_m\cap J|\ll_A\frac{r}{m\log k}.}
\tag{3}
\]
证明：若 \(r>1/2\)，note 772 的统一 PNT 计数给出 \(|S_m|\ll_A1/(m\log k)\)，足够。若 \(R^{-1}\le r\le1/2\)，令 \(J^+\) 是将 \(J\) 两端各扩大 \(\varepsilon\) 后与 \((0,1)\) 的交。所有与 \(J\) 相交的 source 槽中心都在 \(J^+\)。由
\[
x_n=\frac{\log(k/(mn))}{w_m}+\frac\varepsilon2,
\qquad n(x)=\frac{k}{m}\exp\!\bigl(-w_m(x-\varepsilon/2)\bigr),
\]
这些 \(n\) 落在某个长度 \(H\ll kr/m^2\) 的整数区间，区间位置 \(X\asymp k/m\)。将短区间必要时延长至长度 \(H'\asymp kr/m^2\)，不减少覆盖；因 \(m\le(\log k)^A\) 和 \(r\ge k^{-1/4}\)，有 \(H'\ge k^{3/4}/(\log k)^{2A+O(1)}\)，从而 \(\log H'\asymp\log k\)。Brun–Titchmarsh 不等式给出该整数区间内的素数数目 \(O(H'/\log H')=O_A(kr/(m^2\log k))\)。

高次素数幂也满足同一界。确实，对任意 \([X,X+H']\subset[c_A k/m,C_Ak/m]\)，逐指数 \(\ell\ge2\) 对整数底数计数，得
\[
\#\{p^\ell\in[X,X+H']:\ell\ge2\}
\le\sum_{2\le\ell\le\log_2(2k)}
\left(\frac{H'}{\ell X^{1-1/\ell}}+1\right)
\ll \log k\left(\frac{H'}{\sqrt X}+1\right)
=o\!\left(\frac{H'}{\log k}\right)
\tag{4}
\]
一致成立，因为 \(X\gg k/(\log k)^A\)、\(H'\gg k^{3/4}/(\log k)^{2A+O(1)}\)。每个槽长度为 \(\varepsilon\ll m/k\)，因此 \(|S_m\cap J|\le\varepsilon\,O_A(kr/(m^2\log k))\)，即 (3)。

统一 PNT 还给出 \(M_m=|\mathcal N_{k,m}|\asymp_A k/[m(m+1)\log k]\)：主项所对应的 prime 区间长度为 \(k/[m(m+1)]\)，经典零自由区误差一致可忽略；高次素数幂及被排除的 \(n\mid k\) 至多为低阶。故
\[
|S_m|=M_m\varepsilon\asymp_A\frac1{m\log k},
\quad
\|g_m\|_1\le\sqrt{|S_m|}\ll_A(m\log k)^{-1/2},
\quad
\|g_m\|_\infty\ll_A(m\log k)^{1/2},
\tag{5}
\]
其中 \(g_m=\sum_n\sqrt{n/C_m}\,v_n\)，\(\|g_m\|_2=1\)。最后一界由 \(n\asymp k/m\)、\(C_m\asymp(k/m)M_m\)、\(\|v_n\|_\infty\ll\varepsilon^{-1/2}\) 得到。

## 低频质量与继承枢轴

令 \(\widehat g_m\) 为酉 Fourier 变换，并记 \(A_R=\int_{-R}^R|\widehat g_m(\xi)|^2d\xi\)。取三角频率权 \(\varphi_R(\xi)=(1-|\xi|/(2R))_+\)，其逆 Fourier 核是非负的
\[
K_R(t)=\frac R\pi\left(\frac{\sin Rt}{Rt}\right)^2
\ll\frac R{1+R^2t^2}.
\]
因 \(\varphi_R\ge1/2\) 于 \([-R,R]\)，有
\[
A_R\le2\int\varphi_R(\xi)|\widehat g_m(\xi)|^2d\xi
=2\iint g_m(x)g_m(y)K_R(x-y)\,dx\,dy.
\tag{6}
\]
由 (3) 及 dyadic shells \(|x-y|\asymp2^j/R\)，对每个 \(x\) 得
\[
\int_{S_m}K_R(x-y)\,dy\ll_A\frac1{m\log k}.
\tag{7}
\]
中央壳使用 \(|S_m\cap(x-1/R,x+1/R)|\ll_A1/(Rm\log k)\)，第 \(j\) 壳的核为 \(O(R4^{-j})\)、源测度为 \(O_A(2^j/(Rm\log k))\)；半径大于 \(1\) 的尾部由 \(|S_m|\ll_A1/(m\log k)\) 支付。将 (5)、(7) 代入 (6) 得
\[
\boxed{A_R\ll_A\frac1{m\log k}.}
\tag{8}
\]
note 771 的 Fourier 符号满足 \(M(R)=\frac14\log k+O(1)\)。任一继承坐标为 \(1\) 的允许延拓 \(u\) 都满足 \(\langle u,g_m\rangle=1\)，所以 note 772 的低高频 Cauchy–Schwarz 给出
\[
1\le\sqrt{\mathfrak b[u]}
\left(\sqrt{\frac{A_R}{\log2}}+\frac1{\sqrt{M(R)}}\right)
\ll_A\sqrt{\frac{\mathfrak b[u]}{\log k}}.
\]
取下确界即得 (1) 的下界；上界是 note 772 的真实 ground 零延拓测试函数 \(u=g_m\)。

## 全 parent 求和

仍取固定 \(A,B>3\)，令 \(m_0=\lceil(\log k)^A\rceil\)、\(m_1=\lfloor k/(\log k)^B\rfloor\)。中带 \(m_0\le m\le m_1\) 的两项主项均由 note 772 给出 \((1+o(1))\log k\)。

低带 \(m<m_0\)：(5) 的同一素数计数给出
\[
F_m=\sum_{n\in\mathcal N_{k,m}}\frac{\Lambda(n)^2}{n},
\qquad
\sum_{m<m_0}F_m\ll_A\log k\sum_{m<m_0}\frac1m+1
\ll_A\log k\log\log k.
\tag{9}
\]
由 (1)、\(b_m^2\le F_m\)、\(\theta_{k,m}^2\le1\)，低带 aligned 扣款为 \(O_A(\log\log k)\)。由 note 772 的 (M1)--(M2)，低带原始 mismatch 逆度量和为 \(O_A(\log k/\log\log k)\)。又对每个正矩阵 \(D_m=D_{k,m}^{\rm src}\)，第二次变分 short 的恒等式是
\[
\langle\widehat r_m,D_m^{-1}\widehat r_m\rangle
=1/P_{k,m}^{\rm ex}.
\tag{10}
\]
为控制 \(\lambda_m^\perp\) 的**全逆矩阵**度量，按 \(\mathbb C\widehat r_m\oplus\operatorname{ran}Q_m\) 分块写
\(D_m=\begin{psmallmatrix}a_m&c_m^*\\c_m&B_m\end{psmallmatrix}\)，其中
\(P_{k,m}^{\rm ex}=a_m-c_m^*B_m^{-1}c_m\)。分块求逆与 Cauchy--Schwarz 给出
\[
\langle\lambda_m^\perp,D_m^{-1}\lambda_m^\perp\rangle
=\widehat\chi_{k,m}^{\rm src}
+\frac{|c_m^*B_m^{-1}\lambda_m^\perp|^2}{P_{k,m}^{\rm ex}}
\le\frac{a_m}{P_{k,m}^{\rm ex}}\widehat\chi_{k,m}^{\rm src}.
\]
零延拓测试函数给出 \(a_m=\langle\widehat r_m,D_m\widehat r_m\rangle\le\mathfrak b[g_m]\le\log(k/m)+O(1)\ll\log k\)，而 (1) 给出 \(a_m/P_{k,m}^{\rm ex}\ll_A1\)。再将 \(\lambda_m=b_m\widehat r_m+\lambda_m^\perp\) 放入 \(D_m^{-1/2}\)-范数的三角不等式，得到
\[
\langle\lambda_m,D_m^{-1}\lambda_m\rangle
\le\frac{2b_m^2}{P_{k,m}^{\rm ex}}
+O_A(\widehat\chi_{k,m}^{\rm src}).
\tag{11}
\]
故低带完整 source-ground dual debit 为 \(O_A(\log k/\log\log k)\)。

高带 \(m>m_1\)：每个 parent 至多一个指标，且 \(n\le k/m_1\ll(\log k)^B\)。单胞形式有 \(D_m\succeq(\log2)I\)，所以 aligned 与完整 dual debit 均至多
\[
\frac1{\log2}\sum_{n\le C(\log k)^B}\frac{\Lambda(n)^2}{n}
\ll_B(\log\log k)^2=o(\log k).
\]
三带合并证明 (2)。\(\square\)

## 边界

全 parent 的单胞 aligned 与完整 source-ground dual debit 现都只有一个 \(\log k\) 主项，和目标标量对角 \(B_k=\log k+O(1)\) 同阶。它们的低阶差额及完整 Weil harmonic graph 是否存在未复用正项或 signed cancellation，均不由 (2) 判定；moving-\(N\) Möbius 算术门仍开放。
