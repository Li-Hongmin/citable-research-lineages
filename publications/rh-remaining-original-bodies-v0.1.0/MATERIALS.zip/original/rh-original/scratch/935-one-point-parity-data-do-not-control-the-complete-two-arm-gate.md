# 相同支撑、二进奇偶与全区间一阶矩仍不能控制完整两臂门

日期：2026-10-02。依赖 [scratch/933](933-high-prime-parity-residual-still-has-two-signs-in-final-ring.md) 式 (3)–(4)、(24) 的真实高素因子奇偶余项短区间统计，及 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的完整两臂核。本文构造一个**非乘法测试系数**，证明这些一阶数据本身不足以推出目标固定幂频带界；它不反驳真实 \(\nu_Q\) 的门，更不反驳 RH。尚待异源复核。

## 命题

令 \(Y\to\infty\) 沿整数，\(M=2Y\)，\(H=\lceil Y^{1/5}\rceil\)，\(Q=(\log(2M))^2\)。固定 scratch/933 的非负 \(\psi\in C_c^3((1,2))\)、\(J\Subset(6/5,2)\) 且 \(\psi\ge c_\psi>0\) 于 \(J\)，以及非负偶 \(\eta\in C_c^\infty\) 且 \(\eta\ge1\) 于 \(1\le|t|\le2\)。设 \(\nu_Q=\mu-\mu^2\epsilon_Q\)，\(\mathcal K_h(u)\) 是 note 850 的**完整**奇、偶两臂核，\(F_h^a=\sum_{D<u<2M/3,\ u\text{ odd}}a(u)\mathcal K_h(u)\)。

存在实序列 \(\widetilde\nu_M(u)\in\{0,\pm2\}\)，满足：

1. 对每个整数 \(u\)，\(\widetilde\nu_M(u)^2=\nu_Q(u)^2\)，且 \(\widetilde\nu_M(u)=\nu_Q(u)\) 除非 \(u\in U_M\cup2U_M\)，其中 \(U_M=\{u\text{ odd}:3u/M\in J\}\)。平方自由、高素因子奇偶的**支撑**及全部二阶单点计数逐点保持；对每个奇数 \(u\) 还精确有 \(\widetilde\nu_M(2u)=-\widetilde\nu_M(u)\)。
2. 对任意固定 \(A>0\)，一致于所有整数区间 \(I\subset[cM,CM]\) 且 \(M^{2/3}\le|I|\le M^{4/5}\)，有
   \[
   \left|\sum_{u\in I,\ u\text{ odd}}
   (\widetilde\nu_M(u)-\nu_Q(u))\right|
   \ll_A |I|(\log M)^{-A}.
   \tag{1}
   \]
   因而 scratch/933 的一阶、二阶短区间结论及 \(\pm2\) 密度对 \(\widetilde\nu_M\) 原样成立；在长 \(B_0=\lceil M^{2/3}\rceil\) 的区间上，式 (24) 的第一矩主项 \(-\rho c_QB_0\) 也只增加任意固定负对数幂的误差。
3. 对某个整数 \(h_0\in[H,2H]\) 有
   \[
   |F_{h_0}^{\widetilde\nu_M}|
   \gg_{\psi,J}\delta_M,
   \qquad \delta_M=\exp(-\sqrt{\log M}),
   \tag{2}
   \]
   因而
   \[
   \boxed{\quad
   \sum_h\eta(h/H)|F_h^{\widetilde\nu_M}|^2
   \gg\delta_M^2
   \gg M^{-1/5}\asymp H^4/M.
   \quad}\tag{3}
   \]

故固定幂门必须使用 \(\nu_Q\) 的**实际符号排列**或等价的二点算术信息；确知它的支撑、平方值、任意对数精度的所有上述短区间一阶矩，仍不足够。

## 证明

令 \(B_0=\lceil M^{2/3}\rceil\)，把 \(U_M\) 的整数凸包切成长度 \(B_0\) 的整格；两个端部不足整格的部分不修改。scratch/933 式 (4) 对每个整格一致给
\[
\#\{u:\nu_Q(u)=2\}
=\#\{u:\nu_Q(u)=-2\}
=\left(\frac1{\pi^2}+o(1)\right)B_0.
\tag{4}
\]
取任意整数 \(h_0\in[H,2H]\)。原始完整包的该频率值记作 \(V=F_{h_0}^{\nu_Q}\)，取单位复数 \(\zeta\) 使 \(\Re(\overline\zeta V)=|V|\)；若 \(V=0\)，任取 \(\zeta\)。

在 \(U_M\) 中唯一活动的物理乘子是 \(3\)，故
\[
\mathcal K_{h_0}(u)
=\frac\kappa M\phi(3u/M)e(-3h_0u/M),
\qquad \kappa=-4\log(3/2),\quad
\phi(x)=\psi(x)/x\ge c_{\psi,J}>0.
\tag{5}
\]
每格选一个代表 \(u_j\)。称该格合格，若
\[
\left|\Re\left(\overline\zeta\,\kappa e(-3h_0u_j/M)\right)\right|
\ge\frac{|\kappa|}{2}.
\tag{6}
\]
相邻格的相位增量为 \(6\pi h_0B_0/M\asymp M^{-2/15}\to0\)，而全部格跨过 \(\asymp h_0\to\infty\) 个周期。每一完整周期中满足 \(|\cos\theta|\ge1/2\) 的相位比例为 \(2/3\)；按格代表作黎曼计数，端部不足一周期的格数占 \(o(1)\)，故合格格至少占所有整格的一个固定正比例。格内相位变化为 \(O(h_0B_0/M)=o(1)\)，所以 (6) 在合格格的每个源位置均保留 \(\ge|\kappa|/3\) 的绝对实部，并保持同一符号。

置 \(N_0=\lfloor\delta_MB_0\rfloor\)。因为 \(\delta_MB_0=\exp((2/3)\log M-\sqrt{\log M}+o(1))\to\infty\)，有 \(N_0\sim\delta_MB_0\)，而 \(N_0/B_0\to0\)。式 (4) 保证每个合格格内既有足够的 \(+2\) 源，也有足够的 \(-2\) 源。若 (6) 的实部为正，就选择 \(N_0\) 个原值 \(-2\) 的源翻为 \(+2\)；若为负，就选 \(N_0\) 个原值 \(+2\) 的源翻为 \(-2\)。其余奇数源不变；再对每个奇数 \(u\) 定义 \(\widetilde\nu_M(2u)=-\widetilde\nu_M(u)\)，保持 \(4\mid u\) 的源不变。原始 \(\nu_Q\) 在奇数 \(u\) 上也满足 \(\nu_Q(2u)=-\nu_Q(u)\)，因为 \(\mu(2u)=-\mu(u)\) 且 \(f_Q(2u)=-f_Q(u)\)。因此只有 \(U_M\cup2U_M\) 被修改，逐点平方不变。每次奇数源翻转的系数增量为 \(\pm4\)，其对 \(\Re(\overline\zeta F_{h_0})\) 的贡献由 (5) 至少为
\(4c_{\psi,J}|\kappa|/(3M)\)。合格格数 \(\gg M/B_0\)，且 \(N_0\sim\delta_MB_0\)，因此
\[
\Re\left(\overline\zeta
\bigl(F_{h_0}^{\widetilde\nu_M}-V\bigr)\right)
\gg\frac{M}{B_0}\frac{N_0}{M}
\gg\delta_M.
\]
原始投影为 \(|V|\ge0\)，遂得 (2)；偶数伴随源不进入这个只对奇数 \(u\) 求和的完整两臂正规形。\(\eta(h_0/H)\ge1\)；又 \(H^4/M\asymp M^{-1/5}\) 而 \(\delta_M^2/M^{-1/5}=\exp((\log M)/5-2\sqrt{\log M})\to\infty\)，故 (3) 成立。

翻转只交换 \(+2\) 与 \(-2\)，所以逐点平方和支撑不变。任意长 \(|I|\ge M^{2/3}\) 的区间与至多 \(|I|/B_0+2\) 个被处理的整格相交，每格翻转至多 \(N_0\) 个源，每次使一阶和改变绝对值 \(4\)。因此
\[
\left|\sum_{u\in I}(\widetilde\nu_M(u)-\nu_Q(u))\right|
\ll \delta_M|I|+\delta_MB_0+1
\ll\delta_M|I|+1.
\]
对每个固定 \(A>0\)，\(\delta_M=o((\log M)^{-A})\)，且 \(1=o(|I|(\log M)^{-A})\)，证明 (1)。结合 scratch/933 式 (24) 与不变的逐点平方，得到全部所述统计。证毕。

## 边界

\(\widetilde\nu_M\) 保留真实 \(\nu_Q\) 的支撑、平方值、精确二进奇偶关系，也满足其可由现有短区间定理证明的一阶结论。这比 note 849 式 (27)–(28) 的纯光滑核示例保留了更多真实算术数据；但翻转破坏 \(\nu_Q(u)=-2\epsilon_Q(u)\) 在支撑上的**逐点算术符号恒等式**，所以它不是 Möbius 函数的另一种表示。式 (3) 只关闭“由一阶统计与支撑推出完整频带门”的方法，不关闭真实 signed covariance，更不构成 RH 的反例。
