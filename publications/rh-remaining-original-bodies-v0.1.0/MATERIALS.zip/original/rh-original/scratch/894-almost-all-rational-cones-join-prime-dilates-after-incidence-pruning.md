# 几乎所有有理根的正锥可接入一整段锥外素数平移（候选，待异源复核）

日期：2026-10-01。依赖 [scratch/891](891-logarithmic-denominator-weight-pays-fixed-power-farey-cones.md) 的完整轮廓有理锥正隙和根 Schur 上界、[scratch/892](892-upper-prime-dilates-leak-linearly-outside-every-polynomial-rational-cone.md) 的素数槽与根列、[scratch/893](893-average-farey-spacing-pays-upper-prime-schur-block.md) 的反射加权删点及补块逆。全部仍为待异源复核的候选证明；这里判定此前剩下的锥与素数块之间同臂算术边，并保留真实旧奇 Weil 闭形式的其余交叉。

后续 [scratch/895](895-full-prime-profile-blocks-join-almost-all-rational-cones.md) 将这里每个素数槽的常值方向扩展为全部有限能量轮廓，并保留完整锥的联合正隙。

## 命题

沿用以上三稿的 \(X\to\infty\)、\(H=\log X\)、\(w=\frac12\log(1+X^{-2})\)、有理中心族 \(\mathcal G_X^\circ\)、整数 \(1\le B\le X^{1/5}\)、正锥 \(\mathscr V_{y,B}\) 和素数区间 \(\mathcal P_X=[X^{5/4},X^{3/2}]\cap\mathbb P\)。存在与 \(B\) 无关的 \(\mathcal G_X^*\subset\mathcal G_X^\circ\)，使
\[
|\mathcal G_X^\circ\setminus\mathcal G_X^*|\ll X^2/\sqrt H.
\tag{1}
\]
对每个 \(y\in\mathcal G_X^*\)，从 scratch/893 的 \(W'_{y,B}\) 再删去所有与 \(\mathscr V_{y,\lfloor X^{1/5}\rfloor}\) 的**非根槽**有任意同臂素数幂边的素数槽，得到 \(U_{y,B}\subset W'_{y,B}\)。这批额外删除的根列平方质量为 \(o(1)\)，对 \(y,B\) 一致；\(U_{y,B}\) 与锥的全部非根槽之间的**整个算术交叉精确为零**。

对每个固定 \(0<\alpha<1/5\)，所有充分大的 \(X\)、全部 \(y\in\mathcal G_X^*\) 和 \(B\le X^\alpha\)，令 \(V_{y,B}^0\) 为锥中 \(r>1\) 的全部完整轮廓，\(\mathscr S_{y,B}=\mathbb C e_{y,1}\oplus V_{y,B}^0\)。联合闭形式压缩 \(A_{X^2,-}|_{\mathscr S_{y,B}\oplus U_{y,B}}\) 严格正，且有依赖 \(\alpha\) 的线性谱隙。更精确地，令 \(R_{y,B}^{\rm cone}\) 是 scratch/891 中仅消去锥非根槽的真 Schur 扣款，\(R_{y,B}^{\rm joint}\) 是同时消去锥非根槽和 \(U_{y,B}\) 的扣款，则
\[
\boxed{\quad
R_{y,B}^{\rm joint}
=R_{y,B}^{\rm cone}
+\left(\frac{11}{64}+o(1)\right)H,
\quad}
\tag{2}
\]
误差对上述 \(y,B\) 一致。特别地，以 \(\beta_B=\log B/H\) 和 scratch/891 的
\(F(\beta)=1-(1-5\beta)\log[(2-5\beta)/(1-5\beta)]\) 记，有
\[
A_{X^2,-}[e_{y,1}]-R_{y,B}^{\rm joint}
\ge\left(2-F(\beta_B)-\frac{11}{64}-o(1)\right)H
\ge\left(\frac{53}{64}-o(1)\right)H.
\tag{3}
\]
式 (3) 的最后一步只用 \(F(\beta_B)<1\)。这里的 \(\mathscr S_{y,B}\) 只含根槽常值轮廓；锥的全部非常值根轮廓另由下述完整锥陈述覆盖。

对完整轮廓锥，有两个严格的线性谱隙结论：

1. 若固定 \(\alpha<53/320\)，则 \(A_{X^2,-}|_{\mathscr V_{y,B}\oplus U_{y,B}}\succ c_\alpha H I\)；在整段 \([X^{5/4},X^{3/2}]\) 中删去的素数仅损失 \(o(H^2)\) 根列平方质量。
2. 若固定 \(\alpha<1/5\)，取任一固定 \(\sigma\in[5/4,3/2)\) 满足
   \[
   d_\sigma:=\frac{9/4-\sigma^2}{4}<1-5\alpha.
   \tag{4a}
   \]
   令 \(U_{y,B}^{(\sigma)}\subset U_{y,B}\) 只保留 \(p\ge X^\sigma\) 的素数槽，则 \(A_{X^2,-}|_{\mathscr V_{y,B}\oplus U_{y,B}^{(\sigma)}}\succ c_{\alpha,\sigma}H I\)。其根常值列对这段素数补块的受限 Schur 响应为 \((d_\sigma+o(1))H\)。

这些断言对全部良好 \(y\) 和 \(B\le X^\alpha\) 一致；端点 \(\alpha=1/5\) 的锥谱隙仍未判定。

## 同臂三元组的平均加权计数

先用 \(B_*=\lfloor X^{1/5}\rfloor\) 定义一次与 \(B\) 无关的删除族。固定 \(y=n/d\in\mathcal G_X^\circ\)、锥标签 \(r=a/b\)（\(5\le r\le y/2\)、\(b\le B_*\)）和 \(p\in\mathcal P_X\)。素数槽与锥槽的上臂参数分别为 \(z_p=p/y\)、\(x_r=y/r\)。若一个整数素数幂 \(s\ge2\) 使同臂平移后的宽 \(w\) 槽相交，则必有以下两类之一：
\[
\left|\log\frac{spr}{y^2}\right|<w
\quad\text{或}\quad
\left|\log\frac{s y^2}{pr}\right|<w.
\tag{4}
\]
对固定的 \((p,r,s)\)，两类各自把 \(y\) 限于以 \(\sqrt{spr}\) 或 \(\sqrt{pr/s}\) 为中心、长度小于 \(1/X\) 的区间。scratch/893 式 (9)--(10) 的有理间距证明于是给出：**每类三元组在 \(\mathcal G_X^\circ\) 中至多命中一个 \(y\)**。

扩大标签集合为所有 \(5\le r=a/b\le X/4\)、\(1\le b\le B_*\)，允许非既约表示，只会增加计数。对给定 \(p,r\)，式 (4) 第一类的可能整数 \(s\) 至多 \(C X^2/(pr)\) 个；第二类至多 \(Cpr/X^2\) 个。直接按分母和分子求和有
\[
\sum_{\substack{b\le B_*\\5b\le a\le Xb/4}}\frac ba
\ll B_*^2H,
\qquad
\sum_{\substack{b\le B_*\\5b\le a\le Xb/4}}\frac ab
\ll B_*^2X^2.
\tag{5}
\]
这里每个 \(p,r\) 的 \(s\) 候选数可用区间上端作上界：即使上端小于 \(2\)，实际数为零，仍满足上述界；不另加一个会在求和中放大的常数。

记 \(c_p=(\log p)/\sqrt p\)。让 \(N_y(p)\) 计数 \(p\) 与最大锥的非根标签间满足 (4) 的 \((r,s,\text{类})\) 数量，令
\[
D_y:=\sum_{p\in\mathcal P_X}c_p^2N_y(p).
\tag{6}
\]
每个三元组至多命中一个 \(y\)，故 (5) 给
\[
\sum_{y\in\mathcal G_X^\circ}D_y
\ll B_*^2\left(
X^2H\sum_{p\in\mathcal P_X}\frac{(\log p)^2}{p^2}
+\sum_{p\in\mathcal P_X}(\log p)^2
\right).
\tag{7}
\]
甚至用所有整数代替素数的平凡界，也有
\(\sum_{p\in\mathcal P_X}(\log p)^2/p^2\ll H^2X^{-5/4}\) 与
\(\sum_{p\in\mathcal P_X}(\log p)^2\ll H^2X^{3/2}\)。结合 scratch/893 式 (12) 的 \(|\mathcal G_X^\circ|\asymp X^2\)，得到
\[
\frac1{|\mathcal G_X^\circ|}\sum_yD_y
\ll B_*^2\bigl(H^3X^{-5/4}+H^2X^{-1/2}\bigr)
\ll H^2X^{-1/10}=:\eta_X^2\longrightarrow0.
\tag{8}
\]
Markov 给 \(|\{y:D_y>\eta_X\}|\ll\eta_X X^2\)。与 scratch/893 的良好集合相交即得 (1)，因为 \(\eta_X\ll H^{-1/2}\)。对留下的每个 \(y\)，删去 \(N_y(p)>0\) 的全部素数，其根列平方质量至多 \(D_y\le\eta_X=o(1)\)。这次删除对全部 \(B\le B_*\) 同时消除同臂算术跨块。scratch/893 最后一节已证明非根锥槽的异臂算术跨块对**所有**这些 \(p,r\) 精确为零，故整个非根算术跨块消失。

## 非算术交叉、联合逆与正性

两个槽族内部各自的中心间距分别至少为
\[
\delta_{\rm cone}\gg (XB_*^2)^{-1}\gg X^{-7/5},
\qquad
\delta_{\rm prime}\gg X^{-3/2},
\tag{9}
\]
而 \(w\asymp X^{-2}\)。跨族重叠的素数已在 scratch/892 删除。对两条相离的长 \(w\) 槽，非局部核 \(K(d)\ll d^{-1}+1\) 给对应的任意轮廓块范数 \(O(1)\)：间隙靠近零时，把核 \(1/(u-v)\) 换元成 \(1/(t+t')\)，取 Schur 权 \(t^{-1/2}\) 即得一致界；中心距离至少 \(2w\) 时更有 \(O(w/d)\) 界。按另一族中心从近到远排序，每行至多常数个近邻，其余绝对行和在锥行至多 \(O(w\delta_{\rm prime}^{-1}H)=o(1)\)，在素数行至多 \(O(w\delta_{\rm cone}^{-1}H)=o(1)\)。所以同臂 Archimedean 跨块的算子范数为 \(O(1)\)。

异臂中心距至少 \(\log(z_p x_r)=\log(p/r)\ge H/4-O(1)\)，因而核 \(K\ll X^{-1/8}\)；槽数至多 \(O(B_*^2X)\) 与 \(X^{3/2}\)，矩形 Schur 行列和均为 \(o(1)\)。由 scratch/891 的 polar 锥投影界 \(\|P_{\mathscr V_{y,B}}s_k\|^2\ll B_*^2H/X=o(1)\) 和 scratch/893 的素数投影界 \(\|P_{U_{y,B}}s_k\|^2=O(1)\)，其秩一跨块也为 \(o(1)\)。因此在非根锥空间 \(V_{y,B}^0\) 与 \(U_{y,B}\) 之间，真实旧奇闭形式的**全部**跨块 \(C_{y,B}\) 满足
\[
\|C_{y,B}\|_{\rm op}=O(1).
\tag{10}
\]

固定 \(\alpha<1/5\) 且 \(B\le X^\alpha\)。scratch/891 给 \(D_{y,B}:=A|_{V_{y,B}^0}\succeq(1-5\alpha-o(1))H I\)，scratch/893 与本稿的额外删点给 \(F_{y,B}:=A|_{U_{y,B}}=2H I+O_{\rm op}(\sqrt H)\)。令 \(M_{y,B}\) 是 \(V_{y,B}^0\oplus U_{y,B}\) 的联合补块。由 (10)，
\[
M_{y,B}=\operatorname{diag}(D_{y,B},F_{y,B})+O_{\rm op}(1),
\quad M_{y,B}\succeq c_\alpha H I,
\quad
\left\|M_{y,B}^{-1}-\operatorname{diag}(D_{y,B}^{-1},F_{y,B}^{-1})\right\|
=O_\alpha(H^{-2}).
\tag{11}
\]
根常值槽到两个补块的真实形式列范数均为 \(O(H)\)；因此 (11) 的二次型误差为 \(O_\alpha(1)\)。素数列删除的平方质量为 \(o(H^2)\)，所以 scratch/893 的 \((11/64+o(1))H\) 逆响应仍适用，证明 (2)。scratch/891 的 \(R_{y,B}^{\rm cone}\le(F(\beta_B)+o(1))H\) 给 (3)。因补块 \(M_{y,B}\) 与这个**标量根**的 Schur 枢轴都有线性正下界，且 \(\|M_{y,B}^{-1}f_{y,B}\|=O_\alpha(1)\)，标准配方给 \(\mathscr S_{y,B}\oplus U_{y,B}\) 一个 \(c'_{\alpha}H\) 谱隙。

最后处理锥中根槽的**所有**非常值轮廓。scratch/892 的根算术列对每个保留的素数槽只通过常值平均配对：两次整槽平移与目标常值轮廓的配对之和为 \(c_p\langle h,h_0\rangle\)，其中 \(h\) 是任意根轮廓、\(h_0=w^{-1/2}\mathbf1_{(0,w)}\)。其他根算术平移已删除；全部非根算术跨块已由 (4) 和 scratch/893 的整数间距消去。上面相同的非算术行列界对根轮廓亦成立，故完整锥到 \(U_{y,B}^{(\sigma)}\) 的跨块为
\[
C_{y,B}^{(\sigma)}=|e_{y,1}\rangle\langle c^{(\sigma)}|+E_{y,B}^{(\sigma)},
\qquad \|E_{y,B}^{(\sigma)}\|=O(1),
\tag{12}
\]
其中 \(c^{(\sigma)}=(c_p)\) 在保留的 \(p\ge X^\sigma\) 上取值。素数定理、scratch/892 的原删除界以及 (8) 的额外删除界给
\[
\|c^{(\sigma)}\|^2
=\left(\frac{9/4-\sigma^2}{2}+o(1)\right)H^2,
\qquad
\|A|_{U_{y,B}^{(\sigma)}}^{-1}-(2H)^{-1}I\|=O(H^{-3/2}).
\tag{13}
\]
因此消去素数补块所减的锥上正半定形式满足
\[
C_{y,B}^{(\sigma)}(A|_{U_{y,B}^{(\sigma)}})^{-1}
(C_{y,B}^{(\sigma)})^*
\preceq (d_\sigma+o(1))H\,|e_{y,1}\rangle\langle e_{y,1}|
+o(H)I.
\tag{14}
\]
scratch/891 对**整个完整轮廓锥**给 \(A|_{\mathscr V_{y,B}}\succeq(1-5\alpha-o(1))H I\)。由 (14) 和 (4a)，完整锥消元后仍有 \((1-5\alpha-d_\sigma-o(1))H I\) 正隙；素数补块本身有 \((2-o(1))H\) 正隙，且 \(\|(A|_U)^{-1}(C_{y,B}^{(\sigma)})^*\|=O(1)\)。闭形式配方遂给完整联合空间的线性正隙。取 \(\sigma=5/4\) 时 \(d_\sigma=11/64\)，条件 (4a) 等价于 \(\alpha<53/320\)；对任意 \(\alpha<1/5\) 均可取充分接近 \(3/2\) 的固定 \(\sigma\)。\(\square\)

## 边界

所得结论仍是每个良好根附近的**有限素数平移补块与有理锥的联合压缩**；完整轮廓锥在靠近指数 \(1/5\) 时须缩短素数带。它没有覆盖坏根、其余素数平移、锥外连续轮廓或完整无限维补空间；也没有证明原始整个 \(W_{y,B}\) 的正性。于是全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 和 RH 均未由此判定。
