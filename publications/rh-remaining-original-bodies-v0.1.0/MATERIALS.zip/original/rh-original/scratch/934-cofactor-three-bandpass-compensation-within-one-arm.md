# Cofactor 3 的近块补偿已发生在同一物理臂

日期：2026-10-02。依赖 [scratch/933](933-high-prime-parity-residual-still-has-two-signs-in-final-ring.md) 式 (24)–(29) 的一致短区间一阶矩和近块渐近，以及 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的真实两臂核。本文只定位一个子块的负补偿，不控制完整 moving-\(N\) signed covariance。尚待异源复核。

## 命题

令 \(Y\to\infty\) 沿整数，\(M=2Y\)，并沿用 scratch/933 的 \(Q=(\log(2M))^2\)、\(c_Q\)、\(\rho=4/\pi^2\)、\(\psi,\eta,J,U_M\)、\(L\) 及正数 \(\mathscr I=\mathscr I_{\psi,\eta,J}\)。在 \(U_M\) 上唯一活动的物理乘子为 \(k=3\)，故记
\[
\mathcal B_{3,J}(a,b)=
\sum_{u,v\in U_M}a(u)b(v)
\frac{\kappa^2}{M^2}
\phi(3u/M)\phi(3v/M)J_H(3(u-v)),
\qquad a,b\in\{f_Q,\nu_Q,\mu\}.
\tag{1}
\]
其中 \(J_H(r)=\sum_h\eta(h/H)e(-hr/M)\)。令
\(K_M=(\log\log M)^2\)，并以 \(\mathcal B_{3,J}^{\rm ann}(a,b)\) 表示 (1) 中仅保留
\[
L<|u-v|\le K_M M/H
\tag{2}
\]
的有序对。则一致于 \(Y^{1/5}\le H\le Y^{1/4}\)，
\[
\boxed{\quad
\mathcal B_{3,J}(a,b)\ll_{A,\psi,\eta,J}(\log M)^{-A}
\quad\text{for every fixed }A>0,\qquad
\mathcal B_{3,J}^{\rm ann}(a,b)
=-m_am_b\mathscr I+o(c_Q^2),
\quad}
\tag{3}
\]
其中 \(m_f=\rho c_Q\)、\(m_\nu=-\rho c_Q\)、\(m_\mu=0\)。特别地，同一 \(k=3\) 臂的中距离环带已经给出
\[
\mathcal B_{3,J}^{\rm ann}(f_Q,f_Q)
=\mathcal B_{3,J}^{\rm ann}(\nu_Q,\nu_Q)
=-\rho^2c_Q^2\mathscr I+o(c_Q^2),
\qquad
\mathcal B_{3,J}^{\rm ann}(f_Q,\nu_Q)
=+\rho^2c_Q^2\mathscr I+o(c_Q^2).
\tag{4}
\]
由 scratch/933 式 (25) 的素数乘积常数，\(\rho^2c_Q^2\sim e^{-4\gamma}/[4(\log\log M)^4]\)。
式 (4) 的负号来自非负频带核的空间振荡；它不要求别的乘子或偶臂参与。对于真实 \(\mu\)，(3) 只给这一单乘子环带的 \(o(c_Q^2)\)，远弱于完整目标固定幂界。

更强地，存在只依赖 \(\eta\) 的**固定**常数 \(K_\eta>1/128\)，使把 (2) 的上端改成 \(K_\eta M/H\) 后，\(\nu_Q\) 的环带和满足
\[
\boxed{\quad
\mathcal B_{3,J}^{(K_\eta)}(\nu_Q,\nu_Q)
\le-\frac12\rho^2c_Q^2\mathscr I+o(c_Q^2).
\quad}\tag{4a}
\]
式 (4a) 在再加 \((u,v)\le Q\) 与 note 850 的物理位移截断后仍成立；因此负补偿已经位于一个固定倍数 \(M/H\) 的真实留存带内。

式 (3)–(4) 对 note 850 的最终留存条件仍成立：在 (2) 另加
\((u,v)\le G_\natural\) 与
\(T_\natural<|3(u-v)|\le M^{1+\delta}/H\) 后，主项不变。
在该环带中还可把实际共同因子缩到 \((u,v)\le Q\)，仍不改变 (3)–(4) 的主项。特别对 \(a=b=\nu_Q\)，下面式 (14) 将留下的系数写成只由既约分子、分母的大素因子奇偶支撑与小素数奇偶符号决定的精确形式。

## 证明：单乘子完整频带

令 \(B_0=\lceil M^{2/3}\rceil\)。scratch/933 式 (24) 给任意长 \(B_0\) 的整数区间 \(I\subset[cM,CM]\) 一致的一阶矩
\[
\sum_{u\in I,\ u\ {\rm odd}}a(u)
=m_aB_0+O(\varepsilon_MB_0),
\qquad
\varepsilon_M\ll_A\log^{-A}M+M^{-1/15+o(1)}
\tag{5}
\]
对三种 \(a\) 同时成立，且 \(A>0\) 可任意固定。取
\(S=\lfloor M/(100H)\rfloor\) 和
\(\Delta_M=\varepsilon_M+B_0/S\)。由 \(S\gg M^{3/4}\) 及 (5)，
\[
\Delta_M\ll_A\log^{-A}M+M^{-1/12+o(1)}
=o(c_Q)
\tag{6}
\]
（scratch/933 式 (25) 给 \(c_Q\asymp(\log\log M)^{-2}\)）。在奇数源上置 \(r_a(u)=a(u)-2m_a\)。每个长 \(B_0\) 的块的 \(r_a\) 和为 \(O(\varepsilon_MB_0+1)\)。把任意长度至多 \(S\) 的区间分为这些整块和至多两个余块，利用 \(|r_a|\ll1\)，得到统一的滑动和界
\[
\sup_{I\subset[M/3,3M/4],\ |I|\le S}
\left|\sum_{u\in I,\ u\ {\rm odd}}r_a(u)\right|
\ll\Delta_MS.
\tag{7}
\]

定义模 \(M\) 序列
\[
b_a(u)=\frac\kappa M\,\mathbf1_{u\in U_M}
\phi(3u/M)r_a(u),\qquad
R_h^a=\sum_{u\bmod M}b_a(u)e(-3hu/M).
\]
由于 \(J\Subset(6/5,2)\)，序列支撑位于 \((2M/5,2M/3)\)，与模 \(M\) 的拼接点相隔正比例距离。权 \(\mathbf1_{3u/M\in J}\phi(3u/M)\) 的总变差为 \(O_{\psi,J}(1)\)。对 (7) 作离散 Abel 求和；任何非零部分都位于 \([M/3,3M/4]\)，周期窗口跨拼接点时分为两段，得到
\[
\sup_{x\bmod M}
\left|\sum_{j=0}^{S-1}b_a(x-j)\right|
\ll_{\psi,J}\frac{\Delta_MS}{M}.
\tag{8}
\]
令 \(D_S(3h)=\sum_{j=0}^{S-1}e(-3hj/M)\)。在 \(\eta(h/H)\ne0\) 时 \(|h|\le4H\)，而 \(3|h|S/M\le12/100\)，故 \(|D_S(3h)|\gg S\)。这些 \(3h\pmod M\) 两两不同，因为 \(H=o(M)\)。离散 Parseval 与 (8) 遂给
\[
\sum_h\eta(h/H)|R_h^a|^2
\ll_{\psi,\eta,J}\frac M{S^2}
\sum_{x\bmod M}
\left|\sum_{j=0}^{S-1}b_a(x-j)\right|^2
\ll\Delta_M^2.
\tag{9}
\]

常密度部分的每一频率为
\[
P_h^a=\frac{2m_a\kappa}{M}
\sum_{u\in U_M}\phi(3u/M)e(-3hu/M).
\]
奇数格上的几何和及该权的有界变差，在 \(|h|\asymp H\ll M\) 时给
\(|P_h^a|\ll_{\psi,J}|m_a|/H\)，故
\[
\sum_h\eta(h/H)|P_h^a|^2
\ll m_a^2/H.
\tag{10}
\]
(9)–(10) 证明每种 \(a\) 的单乘子频带范数平方为
\(O(\Delta_M^2+m_a^2/H)\)。式 (5) 中的对数幂任意，\(H\ge Y^{1/5}\)，所以此界对任意固定 \(A>0\) 都是 \(O_A((\log M)^{-A})\)。对混合 \((a,b)\) 用 Cauchy–Schwarz 即得 (3) 的第一式；它特别是 \(o(c_Q^2)\)。

## 证明：负质量的位移范围

scratch/933 式 (28) 已由 (5) 的细格划分给出 \(|u-v|\le L\) 双和
\[
\mathcal B_{3,J}^{\rm near}(a,b)
=m_am_b\mathscr I+o(c_Q^2).
\tag{11}
\]
这里包含对角和极近位移；若先按 note 850 的共同因子及位移条件裁剪，scratch/933 式 (21)–(22) 的删项仍为 \(o(c_Q^2)\)，故 (11) 与其留存近块主项相同。

因 \(\eta\in C_c^\infty\) 且 \(3u/M,3v/M\in J\Subset(6/5,2)\)，\(|3(u-v)|/M\le |J|<4/5\)，所有非零 Poisson 别名均与零保持固定距离。故 Poisson 求和对任意固定 \(A>2\) 给
\[
|J_H(3(u-v))|
\ll_{A,\psi,\eta}
H\bigl(1+H|u-v|/M\bigr)^{-A}.
\tag{12}
\]
对 \(u,v\in U_M\)，\(|a(u)b(v)|\le4\)。固定 \(u\) 对 \(|u-v|>K_MM/H\) 求和，再对 \(O(M)\) 个 \(u\) 求和，(12) 给归一化绝对尾质量
\[
\ll_A K_M^{1-A}.
\tag{13}
\]
取 \(A=4\) 后，\(K_M^{-3}=(\log\log M)^{-6}=o(c_Q^2)\)。于是完整双和等于 (11) 加 (2) 的环带，加 \(o(c_Q^2)\) 的远尾。完整双和已由 (9)–(10) 证明为 \(o(c_Q^2)\)，移项便得 (3) 的第二式和 (4)。证毕。

最后核对留存条件。式 (2) 的左端大于 \(L\asymp M/H\)，而
\(T_\natural=H^3/\log^4(2M)=o(M/H)\)，故物理位移自动大于 \(T_\natural\)。其右端为 \(3K_MM/H=o(M^{1+\delta}/H)\)。对 \((u,v)=g>G_\natural\)，固定 \(g\) 的 \(u\) 至多 \(O(M/g)\) 个，每个 \(u\) 的 \(v\ne u\)、\(|u-v|\le K_MM/H\) 至多 \(O(K_MM/(Hg))\) 个。由 \(|J_H|\ll H\)，删去这些对的绝对成本
\[
\ll\frac H{M^2}\sum_{g>G_\natural}
\frac Mg\frac{K_MM}{Hg}
\ll\frac{K_M}{G_\natural}
=o(c_Q^2),
\]
因为 \(G_\natural\ge\log^4(2M)\) 且 \(K_M=(\log\log M)^2\)。这证明留存版的主项也不变。

同一计数从 \(g>Q\) 开始给中距离环带 \(O(K_M/Q)=o(c_Q^2)\)，而近块因宽度只有 \(L\asymp M/H\)，成本为 \(O(1/Q)=o(c_Q^2)\)。因此正、负两个对数级主项都可只留实际共同因子 \(g\le Q\)。为写清其符号，定义 \(\lambda_Q(n)=(-1)^{\#\{p>Q:p\mid n\}}\)，这里对任意正整数只数不同素因子。若 \((a,b)=1\)、\(g\le Q\)，则 \(\lambda_Q(g)=1\)，且逐点恒等式为
\[
\boxed{\quad
\nu_Q(ag)\nu_Q(bg)
=4\,\epsilon_Q(ab)\mu^2(abg)
\mathbf1_{\lambda_Q(a)=\lambda_Q(b)=-1}.
\quad}\tag{14}
\]
若 \(abg\) 不平方自由，两边均为零；否则 \((g,ab)=1\)，\(\epsilon_Q(ag)\epsilon_Q(bg)=\epsilon_Q(ab)\)。在平方自由数上 \(\mu(n)=\epsilon_Q(n)\lambda_Q(n)\)，故 \(\nu_Q(n)=\epsilon_Q(n)(\lambda_Q(n)-1)\)；再用 \(\lambda_Q(g)=1\) 即得 (14)。这一恒等式不提供跨既约比例的 signed 上界，但精确指出 (4) 的 \(\nu_Q\) 负主项可以只用 \(g\le Q\) 且 \(\lambda_Q(a)=\lambda_Q(b)=-1\) 的真实源对实现。

## 固定宽度的负环带

记 \(\widehat\eta(\xi)=\int_{\mathbb R}\eta(t)e(-\xi t)\,dt\)。对任意固定 \(K>1/128\)，与 scratch/933 式 (27) 相同的 \(B_0=\lceil M^{2/3}\rceil\) 分格法给
\[
\mathcal B_{3,J}^{(K)}(a,b)
=m_am_b\frac{\kappa^2}{3}
\left(\int_J\phi(x)^2dx\right)
\left(\int_{1/128<|z|\le K}\widehat\eta(3z)\,dz\right)
+o_K(c_Q^2).
\tag{15}
\]
这里 \(z=H(v-u)/M\)。每个格的一阶矩误差由 (5) 控制；\(U_M\) 两端不足整格的总长为 \(O(B_0)\)；跨两条固定位移边界的格对仅 \(O_K(M/B_0)\) 个。由 \(|J_H|\ll H\)、\(|J_H'|\ll H^2/M\) 与 \(|\phi'|\ll1\)，一对格内的核变化相对自然尺度 \(H\) 为 \(O_K(HB_0/M)\)。归一化总误差为 \(O_K(\varepsilon_M+HB_0/M)=o(c_Q^2)\)。余下的常密度双和作黎曼求积，\(H^{-1}J_H(-3Mz/H)\to\widehat\eta(3z)\) 在 \(|z|\le K\) 一致，\(\phi(3v/M)=\phi(3u/M)+O_K(H^{-1})\)；\(J\) 的两端各损失 \(O_K(H^{-1})\) 的 \(x\)-长度。这证明 (15)。

因为 \(\eta\) 是偶、非负且支撑离开零，\(\eta(0)=0\)，Fourier 反演给
\[
\int_{\mathbb R}\widehat\eta(3z)\,dz=\frac13\eta(0)=0.
\]
另一方面，\(|z|\le1/128\) 时 \(|6\pi tz|\le3\pi/16\) 对 \(\eta(t)\ne0\) 成立，故 \(A_\eta:=\int_{|z|\le1/128}\widehat\eta(3z)dz>0\)。取固定 \(K_\eta\) 使 \(\int_{|z|>K_\eta}|\widehat\eta(3z)|dz<A_\eta/2\)；光滑紧支撑保证这种选择存在。于是 (15) 中的 \(z\)-积分小于 \(-A_\eta/2\)，取 \(a=b=\nu_Q\) 即得 (4a)。此固定环带的 \(g>Q\) 删除成本为 \(O_{K_\eta}(1/Q)=o(c_Q^2)\)，而其全部物理位移落在 note 850 的 \((T_\natural,M^{1+\delta}/H]\) 内，证明所述留存版。

## 边界

这一定量定位说明 scratch/933 式 (32) 的补集主项可以全部在 \(U_M\) 内、同一个 \(k=\ell=3\) 的中距离环带中找到；式 (4a) 又把其中固定比例的负质量压入固定倍数 \(M/H\) 的位移带。两种环带都通过 note 850 的最终截断。式 (14) 排除了依靠该主项的共同因子 \(g\) 上 Möbius 符号变化来证明抵消；尚需处理跨既约比例的真实高素因子奇偶相关，以及其他乘子和两臂的联合和。尤其不能把 (4) 的负值外推为全 Gram 的上界。
