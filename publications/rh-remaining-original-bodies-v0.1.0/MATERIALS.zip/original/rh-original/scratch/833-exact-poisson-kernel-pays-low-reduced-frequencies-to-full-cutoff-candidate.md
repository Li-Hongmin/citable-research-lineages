# 精确 Poisson 核将低既约频率支付延伸到完整截止（候选）

日期：2026-09-29。依赖 [note 753](../notes/753-high-divisor-k2-gate-is-the-k2-residual-up-to-negligible-low-layer.md) 的真实低除数层定义、[note 762](../notes/762-reciprocal-frequency-spacing-pays-low-divisors-to-four-fifths.md) 式 (4) 的频率间距均方界，以及 [scratch 832](832-true-mobius-harmonic-collisions-pay-low-reduced-reciprocal-frequencies-candidate.md) 式 (12) 的一致 Möbius 调和界。这里的精确公式替代 note 760 的三次余项，所得定理仍待异源复核，故只留在 scratch；它不估计高既约频率的 signed covariance。

## 命题

令
\[
\mathscr S(x)=\sum_{x<m<2x}\sin\frac{2\pi m}{x},\qquad
\Phi(t)=\log t\,\mathscr S(1/t),\qquad
L_{N,D}(\mu)=\sum_{d\le D}\mu(d)\Phi(d/N).
\tag{1}
\]
固定 \(0<\delta\le1/5\)。对充分大的 \(Y\)，令
\[
Q=\lfloor Y^{4/5}\rfloor,\quad H=\log(2Y),\quad
Y^{4/5+\delta}\le D\le Y,\quad Y<N\le2Y.
\tag{2}
\]
下面式 (5) 的精确 Fourier 展开中，按 \(h<d\) 与 \(h\ge d\) 拆分；前者将 \(h/d=a/q\in(0,1)\) 约为既约分数。记 \(\mathcal F^{\le Q}_{N,D}\) 为 \(q\le Q\) 部分、\(\mathcal F^{>Q}_{N,D}\) 为 \(q>Q\) 部分。则
\[
\boxed{\quad
\sum_{Y<N\le2Y}|\mathcal F^{\le Q}_{N,D}|^2
\ll_\delta Y^2H^3,
\qquad
\sum_{Y<N\le2Y}|L_{N,D}(\mu)-\mathcal F^{>Q}_{N,D}|^2
\ll_\delta Y^2H^3.
\quad}
\tag{3}
\]
特别地，\(D=\lfloor Y^\alpha\rfloor\) 的全部固定 \(4/5<\alpha\le1\) 均被覆盖（取 \(0<\delta<\alpha-4/5\)）。此前 [scratch 832](832-true-mobius-harmonic-collisions-pay-low-reduced-reciprocal-frequencies-candidate.md) 的 \(\alpha\le7/8\) 只来自近似核余项的绝对界；精确核没有该余项。

## 精确核公式

对每个实数 \(x>1\)，有绝对收敛恒等式
\[
\boxed{\quad
\mathscr S(x)=\frac{x}{\pi}\sum_{n\ge1}
\frac{\cos(4\pi nx)-\cos(2\pi nx)}{n^2x^2-1}.
\quad}
\tag{4}
\]
证明只需周期化 \(f_x(t)=\mathbf1_{x<t<2x}\sin(2\pi t/x)\)。因为两个端点处正弦为零，该函数连续、紧支撑且导数分段有界变差；其周期化的 Fourier 级数绝对收敛，并在零点等于 \(\mathscr S(x)\)。第 \(n\) 个 Fourier 系数是
\[
\int_{\mathbb R}f_x(t)e(-nt)\,dt
=x\int_1^2\sin(2\pi u)e(-nxu)\,du
=\frac{x\,[e(-2nx)-e(-nx)]}{2\pi(n^2x^2-1)}.
\]
零模为零；配对 \(n\) 与 \(-n\) 即得 (4)。这里 \(e(v)=e^{2\pi i v}\)，且 \(x>1\) 保证分母不为零。

代入 \(x=N/d>1\)，再把第一项的 \(2n\) 与第二项的 \(n\) 统一记为 \(h\)，得到**无余项**的公式
\[
L_{N,D}(\mu)
=-\frac1{\pi N}\sum_{d\le D}\mu(d)d\log\frac Nd
\sum_{h\ge1}\frac{\cos(2\pi hN/d)}{h^2}
\left\{
\begin{cases}
\dfrac4{1-4d^2/(h^2N^2)},&2\mid h,\\
0,&2\nmid h
\end{cases}
-\frac1{1-d^2/(h^2N^2)}
\right\}.
\tag{5}
\]
偶数 \(h\) 的第一分母对应 \(n=h/2\ge1\)，故严格正；奇数 \(h\) 没有这一项，避免对不存在的分母作形式运算。所有求和都绝对收敛，\(d\)-和有限。
把分母的常数项取出，\(h\) 的系数为 \(4\mathbf1_{2\mid h}-1=1+2(-1)^h\)，与 note 760 式 (14) 的首项逐项一致。

## 同一既约频率的真实 Möbius 系数

在 \(h<d\) 中唯一写成 \(h=ka,d=kq\)，\((a,q)=1\)、\(1\le a<q\)、\(k\le K=D/q\)。令 \(v=q/(aN)\)，并置
\[
A(v)=\frac4{1-4v^2},\qquad B(v)=\frac1{1-v^2}.
\tag{6}
\]
对 \(q\le Q\) 有 \(v\le Q/Y=o(1)\)，故这些量一致有界。由 \(\mu(kq)=\mu(q)\mu(k)\mathbf1_{(k,q)=1}\)，式 (5) 的该频率系数为
\[
C_{a,q}^{\rm ex}(N)
=\frac{\mu(q)q}{a^2}
\sum_{\substack{k\le K\\(k,q)=1}}
\frac{\mu(k)}k\log\frac{N}{kq}
\bigl[A(v)\mathbf1_{2\mid ka}-B(v)\bigr],
\qquad
\mathcal F^{\le Q}_{N,D}
=-\frac1{\pi N}\sum_{q\le Q}\sum_{\substack{a<q\\(a,q)=1}}
C_{a,q}^{\rm ex}(N)\cos\frac{2\pi aN}{q}.
\tag{7}
\]
式 (7) 的括号和 \(d/h^2\) 中的 \(k^{-1}\) 完全保留；分母 \(1-4v^2\)、\(1-v^2\) 在约分后与 \(k\) 无关。

由 scratch 832 式 (12)，对 \(q\le Q\)、\(K\ge Y^\delta\) 一致地
\[
\sum_{\substack{k\le K\\(k,q)=1}}\frac{\mu(k)}k=O_\delta(E),
\qquad
\sum_{\substack{k\le K\\(k,q)=1}}\frac{\mu(k)\log k}k
=-\frac q{\varphi(q)}+O_\delta(E),
\quad E=e^{-c_\delta\omega(Y)}.
\tag{8}
\]
当 \(q\) 为奇数时也可把 \(q\) 换成 \(2q\)。按 \(q,a\) 奇偶性拆开 \(\mathbf1_{2\mid ka}\)，得到一致渐近
\[
\boxed{\quad
C_{a,q}^{\rm ex}(N)
=\frac{\mu(q)q^2}{a^2\varphi(q)}
\lambda_{a,q}(v)
+O_\delta\!\left(\frac q{a^2}e^{-c'_\delta\omega(Y)}\right),
\quad
\lambda_{a,q}(v)=
\begin{cases}
A(v)-B(v),&q\text{ 奇},\ a\text{ 偶},\\
-A(v)-B(v),&q\text{ 奇},\ a\text{ 奇},\\
-B(v),&q\text{ 偶}.
\end{cases}
\quad}
\tag{9}
\]
在 \(v=0\)，三种主系数依次为 \(3,-5,-1\)。式 (8) 的误差乘上 \(\log(N/q)\ll H\) 后，只需缩小 \(c'_\delta\) 即仍为 (9) 的误差量级。

## 均方证明

为了不对随 \(N\) 变化的 \(A(v),B(v)\) 错用固定系数大筛，利用 \(2v<1\) 的一致收敛展开
\[
A(v)\mathbf1_{2\mid ka}-B(v)
=\sum_{j\ge0}b_{j,ka}v^{2j},
\qquad b_{j,h}=4^{j+1}\mathbf1_{2\mid h}-1.
\tag{10}
\]
将 (7) 写成 \(\mathcal F^{\le Q}_{N,D}=\sum_{j\ge0}F_j(N)\)。定义不依赖 \(N\) 的
\[
\begin{aligned}
S_{j,a,q}&=\sum_{\substack{k\le D/q\\(k,q)=1}}
\frac{\mu(k)b_{j,ka}}k,&
T_{j,a,q}&=\sum_{\substack{k\le D/q\\(k,q)=1}}
\frac{\mu(k)b_{j,ka}\log k}k,\\
U_{j,a,q}&=\frac{\mu(q)q^{2j+1}}{a^{2j+2}}S_{j,a,q},&
V_{j,a,q}&=\frac{\mu(q)q^{2j+1}}{a^{2j+2}}
[-(\log q)S_{j,a,q}-T_{j,a,q}].
\end{aligned}
\tag{11}
\]
于是
\[
F_j(N)=-\frac1{\pi N^{2j+1}}
\left[\log N\sum_{q,a}U_{j,a,q}\cos\frac{2\pi aN}{q}
+\sum_{q,a}V_{j,a,q}\cos\frac{2\pi aN}{q}\right].
\tag{12}
\]
式 (8) 及 \(q/\varphi(q)\ll H\) 给出对全部 \(j\ge0\) 一致的
\[
|S_{j,a,q}|\ll_\delta 4^{j+1}E,
\qquad |T_{j,a,q}|\ll_\delta4^{j+1}H.
\tag{13}
\]
因为 \(\sum_{a\ge1}a^{-4j-4}\le\sum a^{-4}\)，且
\(\sum_{q\le Q}q^{4j+2}\le Q^{4j+3}\)，故
\[
\sum_{q,a}|U_{j,a,q}|^2
\ll_\delta16^{j+1}E^2Q^{4j+3},
\qquad
\sum_{q,a}|V_{j,a,q}|^2
\ll_\delta16^{j+1}H^2Q^{4j+3}.
\tag{14}
\]
不同既约 \(a/q\in(0,1)\)、\(q\le Q\) 的圆周距离至少 \(Q^{-2}\)。note 762 式 (4) 因而把 (12) 估为
\[
\|F_j\|_{\ell^2(Y<N\le2Y)}
\ll_\delta
\frac{4^{j+1}H}{Y^{2j+1}}
(Y+Q^2H)^{1/2}Q^{2j+3/2}.
\tag{15}
\]
这里先对 \(\log N\) 和常数项分别用固定系数间距界，最后才以 \(\log N\le H\)、\(N^{-1}\le Y^{-1}\) 作外部权重。由于 \(Q=Y^{4/5+o(1)}\)、\(Y+Q^2H\ll Q^2H\)，且 \(4Q^2/Y^2<1/2\) 对充分大的 \(Y\) 成立，Minkowski 与几何级数给
\[
\|\mathcal F^{\le Q}_{\cdot,D}\|_2
\ll_\delta H^{3/2}\frac{Q^{5/2}}Y
\sum_{j\ge0}\left(\frac{4Q^2}{Y^2}\right)^j
\ll_\delta YH^{3/2}.
\tag{16}
\]
这就是 (3) 的第一式。

对 (5) 的 \(h\ge d\) 部分，在原来的 \(n\) 记号中，第一余弦要求 \(n\ge d/2\)，第二要求 \(n\ge d\)。在这两段都有 \(d/(nN)\le2/N\)，分母因而一致远离零。于是每个 \(d\) 的绝对贡献为 \(O(H/N)\)，总尾项逐 \(N\) 为 \(O(DH/N)\)，其平方和为
\[
O\left(\frac{D^2H^2}{Y}\right)\ll YH^2.
\tag{17}
\]
式 (5) 精确分解为 \(\mathcal F^{\le Q}+\mathcal F^{>Q}+\text{尾项}\)；由 (16)--(17) 得 (3) 第二式。\(\square\)

## 边界

还有一个不使用 Möbius 符号的横向支付。对任意 \(|c_d|\le1\)、\(D\le Y\)，令 \(\mathcal F^{a\ge A}_{N,D}(c)\) 为 (5) 中 \(h<d\) 且既约分子 \(a\ge A\) 的部分，其中 \(3\le A\le Y\)。则
\[
\boxed{\quad
\sum_{Y<N\le2Y}|\mathcal F^{a\ge A}_{N,D}(c)|^2
\ll \frac{Y^3H^5}{A^3}.
\quad}
\tag{18}
\]
证明仍按 (10)--(12) 展开；此处的 \(k\) 遍历全部 \(k\le D/q\)，不附加 \((k,q)=1\)，并用 \(c_{kq}\) 直接替代 (11) 中的 \(\mu(q)\mu(k)\)。相应两组固定系数只有平凡界
\[
|S_{j,a,q}|\ll4^{j+1}H,
\qquad |T_{j,a,q}|\ll4^{j+1}H^2.
\]
在 \(q\le D\le Y\)、\(a\ge A\) 上，对应的固定系数平方和至多
\(O(16^{j+1}H^4Y^{4j+3}A^{-4j-3})\)，因为
\(\sum_{a\ge A}a^{-4j-4}\ll A^{-4j-3}\)。既约频率的圆周间距至少 \(Y^{-2}\)，所以 note 762 式 (4) 给第 \(j\) 层的 \(\ell^2\) 范数
\[
\ll H^{5/2}Y^{3/2}A^{-3/2}(4/A^2)^j.
\]
由于 \(A\ge3\)，对 \(j\) 求和即得 (18)。同一个证明允许再限制 \(q\) 的范围，故也支付其中的 \(q>Q\) 子和。

取 \(A=\lceil Y^{1/3}\rceil\)，并把未控部分定义为
\[
\mathcal U_{N,D}
=\mathcal F_{N,D}^{\,q>Y^{4/5},\ a<Y^{1/3}}
\quad\text{（两个阈值均按实际整数取整）},
\]
则 (3)、(17)--(18) 与三角不等式给出更窄的精确门
\[
\boxed{\quad
\sum_{Y<N\le2Y}|L_{N,D}(\mu)-\mathcal U_{N,D}|^2
\ll_\delta Y^2H^5
\quad(Y^{4/5+\delta}\le D\le Y).
\quad}
\tag{19}
\]
这把固定截断 \(d\le D\le Y\) 的真实 \(k=2\) 层中未控 reciprocal 频率压到既约分母 \(q>Y^{4/5}\)、分子 \(a<Y^{1/3}\) 的扇区。完整 residual 还含随 \(N\) 移动的 \(Y<d<N\) 层；式 (19) 不控制该层或上述扇区内部的 Möbius signed covariance，也不证明 RH。精确核在约分后保持 \(k^{-1}\) 谐波结构，且没有独立的近似余项；是否成为永久数学结论仍须异源复核。
