# 有限分母外槽层强迫 Farey 正权态的全空间算术泄漏无界（候选）

日期：2026-09-29。推广 [scratch 815](815-half-integer-exterior-slots-detect-fixed-arithmetic-leakage-candidate.md) 的半整数外槽。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实旧奇素数平移、槽间距及 polar 界，并使用 [scratch 809](809-farey-outer-completion-spends-the-interior-logarithmic-gap-candidate.md) 的内部正权态。以下是完整旧奇算子的**范数泄漏**结论，不是 Schur 反馈或负谱结论。尚缺异源复核，留在 scratch。

## 命题

令奇素数 \(p\to\infty\)、\(H=\log p\)、\(k=p^2\)。取整数 \(Q=Q(p)\) 满足
\[
t:=\log(p/Q)\to\infty,\qquad t=o(H),
\tag{1}
\]
并记
\[
v_I=\sum_{a/b\in\mathcal F_Q}\frac{w_{a/b}}{\sqrt{ab}},
\qquad
U_p=\mathbb C e_p\oplus W_p.
\tag{2}
\]
对每个**固定**整数 \(B\ge2\)，定义既约外槽
\[
\mathcal Y_{p,B}
=\left\{\frac mb:2\le b\le B,\ p\le m<bp,\ (m,b)=1\right\},
\qquad
Z_{p,B}=\operatorname{span}\{w_y:y\in\mathcal Y_{p,B}\}.
\tag{3}
\]
其中 \(w_y\) 仍由 note 791 式 (1) 的两臂物理偶极公式定义。对充分大 \(p\)，\(Z_{p,B}\subset U_p^\perp\cap H_{p^2}^-\)，且其所列 \(w_y\) 构成正交单位族。真实完整旧奇算子满足
\[
\boxed{
\liminf_{p\to\infty}
\frac{\|P_{Z_{p,B}}A_{p^2,-}v_I\|^2}{\|v_I\|^2}
\ge
\zeta(2)\sum_{b=2}^{B}\frac{\varphi(b)\log b}{b^2}.
}
\tag{4}
\]
右侧随 \(B\to\infty\) 满足
\[
\zeta(2)\sum_{b=2}^{B}\frac{\varphi(b)\log b}{b^2}
=\frac12(\log B)^2+O(\log B).
\tag{5}
\]
因此先对每个固定 \(B\) 取 \(p\to\infty\)，再让 \(B\to\infty\)，严格得到
\[
\boxed{
\frac{\|(I-P_{U_p})A_{p^2,-}v_I\|}{\|v_I\|}
\longrightarrow\infty.
}
\tag{6}
\]
(6) 不给出显式增长率，因为证明中 \(B\) 是先固定的；它不声称完整旧奇算子有负方向。

## 目标槽与算术平移

固定 \(B\)。每个 \(y=m/b\in\mathcal Y_{p,B}\) 都满足 \(p/B\le y<p\)，且与 \(1,p\) 的对数边界距离至少 \(\gg_B p^{-1}\)，大于 \(\Delta=\frac12\log(1+p^{-2})\)。两个不同的既约目标比值相差至少 \(1/B^2\)，故其对数中心间距 \(\gg_B p^{-1}\gg2\Delta\)；异臂距离更大。因此 \(\{w_y\}\) 正交单位化。

若 \(x=a'/b'\in\mathcal F_p\) 且 \(b'\ge b\)，则
\[
x\le\frac{p-1}{b'}\le\frac{p-1}{b}<\frac pb\le y,
\]
所以 \(|x-y|\ge1/b\)。若 \(b'<b\)，两个不同既约分数满足 \(|x-y|\ge1/(bb')\ge1/B^2\)。根与目标相距更远。于是所有目标槽都与 \(U_p\) 正交。

对源节点 \(x=a/b\in\mathcal F_Q\)，素数幂平移后折叠到 \(>1\) 的目标比值只能是 \(xn\)、\(x/n\) 或 \(n/x\)。其中 \(x/n\le Q=o(p)\)，与 \(y\ge p/B\) 相距很远；可能接近目标的 \(xn,n/x\) 的既约分母分别整除源节点的 \(b,a\)，所以至多为 \(Q\)。若此类输出 \(r\ne y=m/b_0\) 且 \(b_0\le B\)，则
\[
|r-y|\ge\frac1{b_0Q}\ge\frac1{BQ},
\qquad
|\log(r/y)|\gg\frac1{pBQ}\gg\frac1{p^2}=2\Delta.
\tag{7}
\]
故投影到 \(Z_{p,B}\) 的算术输出只来自**精确重合**。重合时平移保持局部反对称阶跃轮廓；所有源系数与素数幂权均为正，\(\mathcal R_{p^2}\) 的负号使各条贡献同号。

具体取源 \(x=a/b\in\mathcal F_Q\)，其中 \(2\le b\le B\)、\(b<a<Q\)、\((a,b)=1\)。若素数 \(q\) 满足 \(p\le aq<bp\)，则 \(q\ge p/Q=e^t>B\)，所以 \((q,b)=1\)，目标 \(y=aq/b\) 为 (3) 中的既约分数。源与目标两臂各给半权，合计矩阵元 \(-c_q=-\log q/\sqrt q\)。同一目标收到的其他平移贡献仍非正，因此
\[
\boxed{
\|P_{Z_{p,B}}\mathcal R_{p^2}v_I\|^2
\ge
\sum_{b=2}^{B}\frac1b
\sum_{\substack{b<a<Q\\(a,b)=1}}\frac1a
\sum_{\substack{q\ {\rm prime}\\p\le aq<bp}}
\frac{(\log q)^2}{q}.
}
\tag{8}
\]
即使不同 \((a,q)\) 给同一个 \(y\)，平方和中的交叉项也非负，故 (8) 保留各条对角贡献是合法下界。

## 渐近主项与其余两部分

由素数定理的 Stieltjes 分部求和，对任意固定 \(b\ge2\) 有
\[
\sum_{X\le q<bX}\frac{(\log q)^2}{q}
=(\log b+o_b(1))\log X\quad(X\to\infty).
\tag{9}
\]
(1) 保证 (8) 的 \(X=p/a\ge e^t\to\infty\)；因 \(B\) 固定，误差对所有 \(a,b\) 一致。令 \(h=\log Q=H-t\)。初等互素调和求和给
\[
\sum_{\substack{b<a<Q\\(a,b)=1}}\frac1a
=\frac{\varphi(b)}b h+O_b(1),
\quad
\sum_{\substack{b<a<Q\\(a,b)=1}}\frac{\log a}{a}
=\frac{\varphi(b)}{2b}h^2+O_b(h).
\tag{10}
\]
将 (9)--(10) 代入 (8)，再用 \(t=o(H)\)，得到
\[
\|P_{Z_{p,B}}\mathcal R_{p^2}v_I\|^2
\ge
\left(\frac12\sum_{b=2}^{B}\frac{\varphi(b)\log b}{b^2}
+o_B(1)\right)H^2.
\tag{11}
\]
另有
\[
\|v_I\|^2
=\frac{h^2}{2\zeta(2)}+O(h)
=\left(\frac1{2\zeta(2)}+o(1)\right)H^2.
\tag{12}
\]

所有源 \(x\le Q\)，目标 \(y\ge p/B\)，所以同臂中心距至少 \(t-\log B\to\infty\)，异臂更远。两个阶跃偶极零均值，note 791 的 Archimedean 核二阶导数界给每个跨槽元 \(O(\Delta^3/(t-\log B)^3)\)。又因 \(\sum_{x\in\mathcal F_Q}(ab)^{-1/2}=O(Q)\) 且 \(|\mathcal Y_{p,B}|=O_B(p)\)，
\[
\|P_{Z_{p,B}}G_{p^2}v_I\|
\ll_B p^{1/2}Q\Delta^3/(t-\log B)^3=o(1).
\tag{13}
\]
零均值与 \(\sup|s'_{p^2}|=O(p^{1/2})\) 给
\(\|P_{Z_{p,B}}s_{p^2}\|=O_B(p^{-2})\)；
note 791 的全 Farey 投影界给
\(|\langle s_{p^2},v_I\rangle|=O(Hp^{-3/2})\)。
polar 项在目标空间的范数也为 \(o(1)\)。因此 (11)--(13) 的算术下界保留到完整 \(A_{p^2,-}\)，与 (12) 合并证明 (4)。

最后用 \(\varphi(n)=n\sum_{d\mid n}\mu(d)/d\) 与调和数渐近：
\[
\sum_{b\le B}\frac{\varphi(b)\log b}{b^2}
=\sum_{d\le B}\frac{\mu(d)}{d^2}
 \sum_{m\le B/d}\frac{\log d+\log m}{m}
=\frac{\log^2B}{2\zeta(2)}+O(\log B).
\tag{14}
\]
这证明 (5)。因 \(Z_{p,B}\subset U_p^\perp\)，(4)--(5) 对每个固定 \(B\) 成立，任意大的固定下界都可取到，故 (6) 成立。\(\square\)

## 边界

全 Farey 正权态的主压缩可保持正的常数量级，而其完整旧奇像向槽外的范数相对原向量却趋于无穷；这精确否定把主压缩近似本征态直接当成完整旧奇算子近似本征态的推论。无界范数泄漏并不等于无界 Schur 成本：外槽能量、槽间耦合及所有其他补空间仍须处理。本文没有建立全尺度局部 Weil 正性、负方向或 moving-\(N\) Möbius signed covariance 的目标上界。
