# 观察频带把双素数通道化为短 cofactor 的真实 Möbius 协方差（待独立复核）

日期：2026-10-01。接 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实联合系数与 [scratch/858](858-exact-bandpass-observation-removes-lower-frequency-leakage.md) 的精确带通核。以下只使用恒等式 $\Lambda=\mu*\log$、Poisson 求和与除数函数的初等均值界；不假设 RH。结论无条件支付两个 $\Lambda$ 通道的小 Möbius 除数、整个高除数 Gram 的 $d=e$ 项、精确乘积碰撞及物理近差/远差。留下的仍是实际 $\mu(d)\mu(e)$ signed covariance；没有证明其目标上界。后续 [scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 收紧远差，[scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 证明对数级频带支付及真实异号负块；固定幂门仍开放。

## 1. 精确高除数式

令 $M=2Y$，$Y^{1/5}\le H\le Y^{1/4}$，$\psi\in C_c^3((1,2))$ 固定，$\phi(u)=\psi(u)/u$，$e(t)=e^{2\pi it}$。在 $H/2\le |h|\le4H$ 记 note 849 式 (11) 的实际和为
\[
 \mathcal A_h=\frac1M\sum_{M<m<2M}c(m)\phi(m/M)e(-hm/M),
 \quad c(m)=2\mathbf1_{2\mid m}(\Lambda(m/2)-1)
 -4\{\Lambda(m)-1+(\log2)\mu(m)\}.
\tag{1}
\]
置 $D=\lfloor M/(16H)\rfloor$。对 $d>D$ 和 $M<m<2M$ 定义
\[
 b_d(m)=\frac{\phi(m/M)}M\left[
 2\mathbf1_{2d\mid m}\log\frac m{2d}
 -4\mathbf1_{d\mid m}\log\frac md
 -4(\log2)\mathbf1_{m=d}\right],
 \qquad \mathcal K_h(d)=\sum_m b_d(m)e(-hm/M).
\tag{2}
\]
整除指示为零时对应的对数项定义为零。于是
\[
 \boxed{\quad
 \mathcal A_h=\sum_{D<d\le2M}\mu(d)\mathcal K_h(d)
 +O_\psi(H^{-3}\log^2M).
 \quad}\tag{3}
\]
而 (2) 中第一、第二项的非零 cofactor 分别满足
\[
 m/(2d)<16H,\qquad m/d<32H.
\tag{4}
\]
所以两个素数尺度与直接 Möbius 项在目标频带都已写成同一个**真实** $\mu(d)$ 的短 cofactor 和。

## 2. 小除数的无条件支付

为证明 (3)，对 $L=M/2,M$ 定义
\[
 \mathscr L_h(L)=\frac1L\sum_{n\ge1}\Lambda(n)\phi(n/L)e(-hn/L).
\]
$\Lambda=\mu*\log$ 与绝对有限求和给
\[
 \mathscr L_h(L)=\frac1L\sum_{d\le2L}\mu(d)
 \sum_{k\ge1}(\log k)\phi(k/X)e(-hk/X),\qquad X=L/d.
\tag{5}
\]
令 $F_0(u)=\phi(u)$、$F_1(u)=(\log u)\phi(u)$。两者是 $C_c^3((1,2))$，故
$|\widehat F_j(t)|\ll_\psi(1+|t|)^{-3}$。对每个 $d\le D$，有 $X\ge8H$；Poisson 求和给
\[
 \frac1L\sum_k(\log k)\phi(k/X)e(-hk/X)
 =\frac1d\sum_{j\in\mathbb Z}
 \left[(\log X)\widehat F_0(h+jX)+\widehat F_1(h+jX)\right].
\tag{6}
\]
因 $H/2\le|h|\le4H$、$X\ge8H$，所有 $|h+jX|\gg H(1+|j|)$（对 $j=0$ 也成立）。所以 (6) 的绝对值为
$O_\psi(d^{-1}\log M\,H^{-3})$。对 $d\le D$ 求和得到两个尺度各自的
$O_\psi(H^{-3}\log^2M)$。式 (1) 的 $4-2\mathbf1_{2\mid m}$ 平滑背景由 note 849 式 (32) 同样为 $O_\psi(H^{-3})$。把 $\mathscr L_h(M/2)-4\mathscr L_h(M)-4(\log2)M^{-1}\sum_m\mu(m)\phi(m/M)e(-hm/M)$ 展开并删去 $d\le D$，正得 (2)--(3)。式 (4) 由 $d>D\ge M/(16H)-1$ 及 $m<2M$ 直接给出（充分大 $M$ 时 $d>M/(16H)$）。$\square$

设 $\chi$ 为 scratch/858 的实偶带通权，$w_H(h)=\chi(|h|/H)^2$，只对 $H/2\le|h|\le4H$ 非零。由 (3)，误差的平方频带范数满足
\[
 \sum_hw_H(h)\left|\mathcal A_h-
 \sum_{d>D}\mu(d)\mathcal K_h(d)\right|^2
 \ll_\psi H^{-5}\log^4M
 =o(H^4/M).
\tag{7}
\]
最后一个 $o$ 在所给 $H$ 范围内一致，因为 $M/H^9\ll M^{-4/5}$。因此 note 849 所需的 $H^4/M$ 频带界与 (3) 主项的同量级界等价。

## 3. 对角、精确碰撞、近差和远差

记 $\mathcal G_{d,e}=\sum_hw_H(h)\mathcal K_h(d)\overline{\mathcal K_h(e)}$。由 (4) 与 $|\phi|\ll1$，
\[
 |\mathcal K_h(d)|\le\sum_m|b_d(m)|
 \ll_\psi\frac{\log(2M)}d,
 \qquad
 \boxed{\ \sum_{d>D}\mu(d)^2\mathcal G_{d,d}
 \ll_\psi H^2\log^2(2M)/M=o(H^4/M).\ }
\tag{8}
\]
事实上每个 $d$ 至多有 $O(1+M/d)$ 个允许的 cofactor，每项至多 $O_\psi(\log M/M)$；因 $D<d\le2M$，其 $\ell^1$ 范数为 $O_\psi(\log M/d)$。频率数 $O(H)$ 且 $\sum_{d>D}d^{-2}\ll D^{-1}\asymp H/M$，故 (8) 完全无符号。

同一估计还支付全部有整除关系的非对角索引。令 $d=qe$、$q\ge2$，并把 $e=qd$ 的对称项乘以二。由 $|\mathcal G_{d,e}|\ll H\|b_d\|_1\|b_e\|_1$，
\[
 \sum_{\substack{D<d,e\le2M,\ d\ne e\\d\mid e\ \text{或}\ e\mid d}}
 |\mu(d)\mu(e)\mathcal G_{d,e}|
 \ll H\log^2(2M)
 \sum_{q\ge2}\frac1q\sum_{e>D}e^{-2}
 \ll_\psi\frac{H^2\log^3(2M)}M
 =o(H^4/M).
 \tag{8a}
\]
因此 dyadic parity 等精确乘法关系的整条 Gram 贡献无需借用 Möbius 符号；未付项可进一步限定为 $d\nmid e$ 且 $e\nmid d$。

更一般地，低复杂度的**全部约化有理比例**也可绝对支付。对 $d\ne e$ 写唯一的 $d=at,e=bt$，其中 $(a,b)=1$；置
$R=\lfloor H^2/\log^4(2M)\rfloor$。在 $\max(a,b)\le R\ll D$ 时，$t>D/\min(a,b)>1$。若 $q=\max(a,b)$、$p=\min(a,b)$，则由 (8) 前的 $\ell^1$ 界
\[
 \sum_{t>D/p}|\mathcal G_{at,bt}|
 \ll H\log^2(2M)\frac1{pq}
 \sum_{t>D/p}t^{-2}
 \ll\frac{H\log^2(2M)}{qD}.
\]
每个 $q$ 至多有 $2q$ 个有序的 $p$，故
\[
 \boxed{\quad
 \sum_{\substack{D<d,e\le2M,\ d\ne e\\
 \max(d/(d,e),,e/(d,e))\le R}}
 |\mu(d)\mu(e)\mathcal G_{d,e}|
 \ll_\psi\frac{H^2R\log^2(2M)}M
 \ll_\psi\frac{H^4}{M\log^2(2M)}.
 \quad}\tag{8b}
\]
式 (8b) 支付全部小约化分子、分母；(8a) 另支付 $q>R$ 的整除线。两项都不估计大约化分子、分母且彼此接近的密集配对。

还可以按物理乘积 $m$ 裁剪 off-diagonal。定义
\[
 J_H(r)=\sum_hw_H(h)e(-hr/M),\qquad
 B(m)=\sum_{d>D}|b_d(m)|.
\]
由 (2)，$B(m)\ll_\psi \tau(m)\log(2M)/M$，其中 $\tau$ 是除数个数。初等式 $\tau(n)^2\le d_4(n)$ 及
$\sum_{n\le2M}d_4(n)\ll M\log^3(2M)$ 给
\[
 \sum_m B(m)^2\ll_\psi\frac{\log^5(2M)}M,
 \qquad \sum_mB(m)\ll_\psi\log^2(2M).
\tag{9}
\]
后一界由 $\sum_{n\le2M}\tau(n)\ll M\log(2M)$。这些标准均值也可直接把 $d_4(n)$ 展成四整数乘积、对前三个变量求调和和得到。

$J_H(0)\ll H$，故全部 $m=n$ 的**精确乘积碰撞**即使对 $d,e$ 均取绝对值，也由 (9) 界为 $O_\psi(H\log^5M/M)=o(H^4/M)$。对 $K_0=H^3/\log^7(2M)$，Cauchy--Schwarz 给每个 $r$ 的 $\sum_mB(m)B(m-r)\le\sum_mB(m)^2$；又 $|J_H(r)|\ll H$，所以
\[
 \sum_{\substack{m,n\\|m-n|\le K_0}}
 B(m)B(n)|J_H(m-n)|
 \ll_\psi H K_0\frac{\log^5(2M)}M
 \ll_\psi\frac{H^4}{M\log^2(2M)}.
\tag{10}
\]
这支付了所有真实 $\mu(d)\mu(e)$ 配对的物理近差，包括 $d\ne e$。

由 $\chi^2$ 的光滑性，Poisson 求和给每个固定 $A>0$ 的
$|J_H(r)|\ll_{A,\chi}H(1+|r|/W)^{-A}$，只要 $r=m-n$ 且 $m,n$ 位于 $\phi$ 的紧支撑内；跨周期别名因 $|r|\le(1-\kappa_\psi)M$ 而一致远离零。固定 $0<\sigma<1/5$，令 $K_1=WM^\sigma$。由 (9)，
\[
 \sum_{\substack{m,n\\|m-n|>K_1}}
 B(m)B(n)|J_H(m-n)|
 \ll_{A,\psi,\chi}H M^{-A\sigma}\log^4(2M)
 =O_{B,\psi,\chi,\sigma}(M^{-B})
\tag{11}
\]
对任意固定 $B>0$，只需取足够大的 $A$；这里 $K_1=o(M)$。

把 (8)、(8a)、(8b)、(10)、(11) 从高除数 Gram 扣除，当前**唯一未付的这条频带算术门**可写成
\[
 \boxed{\quad
 \sum_{\substack{D<d,e\le2M\\d\nmid e,\ e\nmid d\\
 \max(d/(d,e),\,e/(d,e))>R}}\mu(d)\mu(e)
 \sum_{\substack{M<m,n<2M\\K_0<|m-n|\le K_1}}
 b_d(m)\overline{b_e(n)}J_H(m-n)
 \ll_\varepsilon H^4M^{-1+\varepsilon},
 \quad}\tag{12}
\]
它是实际大除数 $d,e$ 与 $O(H)$ cofactor 的 signed covariance。由 (7)--(11)，(12) 与当前观察频带的 $H^4M^{-1+\varepsilon}$ 上界在同一量级等价。式 (12) 尚未证明；这一频带结果也不覆盖更低观察频率、完整 moving-$N$ 均方、全尺度局部 Weil 正性或 RH。

[note 762](../notes/762-reciprocal-frequency-spacing-pays-low-divisors-to-four-fifths.md) 已在原始 moving-$N$ 坐标无条件支付 $d\le Y^{4/5}$ 的完整 residual 层。本稿只在**两端点观察频率坐标**给出逐频小除数支付及短 cofactor 的共同 Möbius Gram；不能把它解读为超过 note 762 的全 residual 指数改进。
