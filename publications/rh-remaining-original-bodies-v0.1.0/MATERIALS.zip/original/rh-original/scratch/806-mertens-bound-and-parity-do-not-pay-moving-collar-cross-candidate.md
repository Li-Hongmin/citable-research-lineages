# Mertens 零自由区上界加平方自由 parity 仍不支付 moving collar 交叉项（候选）

日期：2026-09-29。直接对象是 [note 732](../notes/732-k2-cofactor-mean-square-diagonal-is-unconditionally-quadratic.md) 的真实高除数核与 [scratch 805](805-k2-moving-endpoint-collar-to-five-sixths-candidate.md) 的协方差 collar 分解。仅构造测试系数，**不对真实 Möbius 函数作下界断言**。本解析证明尚未异源复核。

## 命题

令
\[
 \omega(x)=\frac{(\log x)^{3/5}}{(\log\log x)^{1/5}}
 \quad(x\text{ 充分大}),\qquad
 \Phi(t)=\log t\sum_{1/t<a<2/t}\sin(2\pi at).
\]
给定任意固定 \(b>0\)，存在 \(a>b\)，使对所有充分大的整数 \(Y\)，可取一个**全局**实系数列 \(c=c^{(Y)}\) 满足
\[
 |c_n|\le\mu(n)^2,\qquad
 c_{2e}=-c_e\ (e\text{ 为奇数}),\qquad
 c_{2e}=0\ (e\text{ 为偶数}),
\tag{1}
\]
以及对每个实数 \(x\ge1\) 的一维零自由区型上界
\[
 \boxed{\left|\sum_{n\le x}c_n\right|
 \le x e^{-b\omega(x)}}
 \quad(x\text{ 足够大});
\tag{2}
\]
小 \(x\) 上左侧为零。置 \(D=\lfloor Y^{4/5}\rfloor\)、\(W=\lfloor Y^{5/6}\rfloor\)，并将 note 732 的 \(D<d,e<N\)、\(d\ne e\) 非对角和记为 \(\mathcal C_D(Y;c)\)，只保留 \(D<d,e<N-W\) 的和记为 \(\mathcal C_{D,W}^{\rm mid}(Y;c)\)。则
\[
 \boxed{
 \mathcal C_D(Y;c)-\mathcal C_{D,W}^{\rm mid}(Y;c)
 \gg_{a,b}Y^{5/2}e^{-4a\omega(Y)}.}
\tag{3}
\]
特别地，(3) 对每个固定 \(0<\varepsilon<1/2\) 都大于 \(Y^{2+\varepsilon}\) 的任意固定倍数（\(Y\to\infty\)）。故经典 Mertens 的一维部分和上界，即使与平方自由支撑及精确 \(2\)-adic parity 一起使用，仍不能推出宽 \(Y^{5/6}\) collar 在**非对角协方差式本身**中的 \(O_\varepsilon(Y^{2+\varepsilon})\) 可删性。真实 \(\mu\) 的奇数位符号规律未被 (1)--(2) 固定。

下面的加强版还可令 \(c_n=\mu(n)\) 对**所有 \(n\le D\)** 成立；此时 (2) 对某个绝对 \(b>0\) 成立，(3) 不变。

## 构造与证明

固定 \(a>b\)。令
\[
 N_0=\lfloor3Y/2\rfloor,\qquad
 L=\lfloor Y e^{-a\omega(Y)}\rfloor,\qquad
 I=[N_0,N_0+L)\cap\mathbb Z.
\tag{4}
\]
当 \(Y\to\infty\) 时，\(L=o(Y)\)、\(W=o(L)\)、\(L\gg\sqrt Y\)，且 \(N_0+L+W<2Y\)。对每个奇平方自由 \(m\in I\)，置 \(c_m=1\)、\(c_{2m}=-1\)；其它位置取零。\(2I\subset(2Y,\infty)\)，所以对本题全部 \(Y<N\le2Y\)，实际参与 cofactor 和的非零系数都为 \(+1\)。定义立即给出 (1)。

记 \(A(x)=\sum_{n\le x}c_n\)。全部正项位于 \(I\)，其偶数伴随负项位于更右方的 \(2I\)，故 \(A(x)=0\) 当 \(x<N_0\)，并且对所有 \(x\) 有 \(0\le A(x)\le L\)。函数 \(g_b(x)=x e^{-b\omega(x)}\) 在充分大的 \(x\) 上递增，因为 \(x\omega'(x)=O((\log x)^{-2/5})=o(1)\)。又 \(\omega(N_0)=\omega(Y)(1+o(1))\)，故由 \(a>b\) 得
\[
 \frac{L}{g_b(N_0)}
 \ll\exp\bigl(-(a-b+o(1))\omega(Y)\bigr)\longrightarrow0.
\]
对 \(x\ge N_0\) 使用 \(A(x)\le L\le g_b(N_0)\le g_b(x)\)，对 \(x<N_0\) 使用 \(A(x)=0\)，即证 (2)。

现在令
\[
 E_N=\sum_{N-W\le d<N}c_d\Phi(d/N),\qquad
 B_N=\sum_{D<d<N-W}c_d\Phi(d/N).
\tag{5}
\]
当 \(d=N-h\) 且 \(0<h\le L+W=o(Y)\) 时，\(d/N>3/4\) 对充分大 \(Y\) 成立。真实核只有 \(a=2\) cofactor，因而
\[
 \Phi((N-h)/N)
 =\log\frac1{1-h/N}\sin\frac{4\pi h}{N}.
\tag{6}
\]
在 \(0<h/N\le1/8\) 上，(6) 为正且 \(\Phi((N-h)/N)\asymp(h/N)^2\)，绝对常数一致。对任何 \(E_N\ne0\) 的 \(N\in(Y,2Y]\)，全部参与 \(B_N\) 的非零系数也来自 \(I\)，其距离 \(h=N-d\) 至多 \(L+W\)。故 \(B_N,E_N\ge0\)。端点层自身的 off-diagonal 项 \(\mathcal C_E\) 也非负。

取整数区间
\[
 J=\{N_0+\lceil L/2\rceil,\ldots,N_0+L-1\}.
\]
它含 \(\asymp L\) 个 \(N\)。对每个 \(N\in J\)，端点和 (5) 含有 \(W/2\le h\le W\) 中所有使 \(N-h\) 为奇平方自由数的项；中央和含有 \(L/4\le h\le L/2\) 中所有使 \(N-h\) 为奇平方自由数的项，因为 \(W=o(L)\)。[note 763](../notes/763-four-fifths-is-sharp-for-sign-blind-low-divisor-bounds.md) 的初等计数式
\[
 \#\{m\le x:m\text{ 为奇平方自由数}\}
 =\frac4{\pi^2}x+O(\sqrt x)
\tag{7}
\]
对上述两个长度分别为 \(\asymp W\) 与 \(\asymp L\) 的区间一致适用；因 \(W,L\gg\sqrt Y\)，两者分别含 \(\gg W\) 与 \(\gg L\) 个非零系数。由 (6) 遂有
\[
 E_N\gg W^3/Y^2,\qquad B_N\gg L^3/Y^2
 \qquad(N\in J).
\tag{8}
\]

平方展开并扣除 divisor 对角，得到精确恒等式
\[
 \mathcal C_D(Y;c)-\mathcal C_{D,W}^{\rm mid}(Y;c)
 =2\sum_{Y<N\le2Y}B_NE_N+\mathcal C_E.
\]
所有项非负，故仅保留 \(J\)，再用 (8) 得
\[
 \mathcal C_D(Y;c)-\mathcal C_{D,W}^{\rm mid}(Y;c)
 \gg L\frac{L^3W^3}{Y^4}
 =\frac{L^4W^3}{Y^4}
 \asymp Y^{5/2}e^{-4a\omega(Y)}.
\]
由于 \(\omega(Y)=o(\log Y)\)，该量除以 \(Y^{2+\varepsilon}\) 对每个 \(\varepsilon<1/2\) 趋于无穷，证明 (3)。\(\square\)

## 保留全部低除数真实值

这里使用经典 Vinogradov--Korobov 上界 \(M(x)=\sum_{n\le x}\mu(n)\ll x e^{-c_0\omega(x)}\)（见 [note 516](../notes/516-vinogradov-korobov-baseline-for-the-first-sine-mode.md)）。[note 744](../notes/744-dyadic-parity-intertwiner-cancels-log-weight.md) 的精确恒等式
\[
 M_{\rm odd}(x):=\sum_{\substack{n\le x\\n\ \mathrm{odd}}}\mu(n)
 =\sum_{j\ge0}M(x/2^j)
\]
亦给出某个 \(c_1>0\) 的 \(M_{\rm odd}(x)\ll x e^{-c_1\omega(x)}\)。具体地，将 \(j\) 在 \(2^j\le\sqrt x\) 截断：前段所有参数至少为 \(\sqrt x\)，因 \(\omega(\sqrt x)\asymp\omega(x)\)，可在 \(c_0\) 上缩小常数；后段绝对值总和 \(O(\sqrt x)\) 可吸收到同一形式中。

在上一节的奇平方自由块 \(I\) 之外，对**每个奇数 \(m\le D\)** 再置
\[
 \widetilde c_m=\mu(m),\qquad
 \widetilde c_{2m}=-\mu(m),
\]
并保留 \(I\) 上 \(\widetilde c_m=1\)、\(\widetilde c_{2m}=-1\)；其余位置为零。两组支撑不相交。于是 (1) 仍成立，而且 \(\widetilde c_n=\mu(n)\) 对所有 \(n\le D\) 成立。其全局部分和精确为
\[
 \widetilde A(x)
 =M_{\rm odd}(\min(x,D))
 -M_{\rm odd}(\min(x/2,D))+A_I(x),
\tag{9}
\]
其中 \(A_I\) 是上一节的块及偶数伴随部分和，\(0\le A_I\le L\)。当 \(x\le D\) 时，(9) 的前两项为 \(M(x)\)；当 \(D<x<2D\) 时，它们由 \(M_{\rm odd}\) 上界控制为 \(O(D e^{-c_1'\omega(D)})\)（缩小 \(c_1\)）；当 \(x\ge2D\) 时，两项精确抵消。取固定 \(b>0\) 小于上述 Mertens 指数常数，并取 \(a>b\)，上一节对 \(A_I\) 的证明表明 \(|\widetilde A(x)|\le x e^{-b\omega(x)}\) 对所有充分大的 \(x\) 成立。

因为 \(2D<N-W\) 在整个 dyadic 区间上成立，端点层 \(E_N\) 只含 \(I\) 的正系数，仍满足 (8)。中央层额外获得的低系数部分 \(B_N^{\rm low}\) 满足由 note 729 的小 \(t\) 核界推出的统一估计
\[
 |B_N^{\rm low}|
 \le\sum_{D<d\le2D}|\Phi(d/N)|
 \ll \frac{D^2}{Y}\log Y
 \ll Y^{3/5}\log Y.
\tag{10}
\]
它可能有任意符号，但 \(E_N\ne0\) 只在 \(O(L+W)=O(L)\) 个 \(N\) 上发生，且由 scratch 805 有 \(|E_N|\ll W^3/Y^2\)。因此低系数对中央与端点交叉项的总扰动至多
\[
 O\!\left(L\,Y^{3/5}\log Y\,\frac{W^3}{Y^2}\right)
 =O\!\left(Y^{21/10}e^{-a\omega(Y)}\log Y\right)
 =o\!\left(Y^{5/2}e^{-4a\omega(Y)}\right).
\]
块内的中央--端点交叉与端点自身 off-diagonal 仍非负，故 (3) 对 \(\widetilde c\) 原样成立。\(\square\)

## 边界与决策

这是一个对**通用推理输入**的反例；\(c\) 不是全局 \(\mu\)，只在加强版中保留了全部 \(n\le D\) 的真实值。它关闭“经典 Mertens 部分和界 + 已知低除数值 + 平方自由支撑 + \(2\)-adic parity 足以单独支付 \(Y^{5/6}\) 协方差 collar”这一推法。它与 scratch 805 的完整均方层可删性相容：均方可用三角不等式移除 collar，却不能据此逐块宣称真实协方差交叉已在目标量级。剩余可改变 RH 路线的输入必须作用于高处奇数位上的真实 Möbius signed two-point 结构或直接控制完整中央均方；(3) 不判定该真实输入是否成立。
