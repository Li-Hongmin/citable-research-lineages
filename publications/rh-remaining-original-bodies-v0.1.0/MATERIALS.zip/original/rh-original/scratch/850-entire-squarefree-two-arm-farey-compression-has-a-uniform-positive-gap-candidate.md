# 整个平方自由双臂 Farey 主压缩有一致正谱隙（候选）

此候选已晋级为 [note 796](../notes/796-entire-squarefree-two-arm-farey-compression-has-a-uniform-positive-gap.md)；以该 note 为权威版本。

日期：2026-09-29。依赖 [note 792](../notes/792-a-single-squarefree-two-arm-farey-family-has-critical-arithmetic-radius.md) 的 \(S_p\)、[note 793](../notes/793-fixed-prime-cylinder-profiles-have-positive-squarefree-two-arm-weil-limits.md) 的精确行式、[note 795](../notes/795-full-farey-dipole-archimedean-remainder-is-uniformly-positive.md) 的全 Farey Archimedean 正余项。以下将两个常数级估计合并，判定**全部** \(S_p\) 向量的主压缩符号；异源复核前留在 scratch。

## 命题

沿奇素数 \(p\to\infty\)，取 \(k=p^2\)、\(X=(p-1)/4\)、\(Y=(p-1)/3\)，并令 \(S_p\) 为 note 792 中根 \(4/3\) 的完整平方自由双臂 Farey 偶极空间。记
\[
c_{23}=\frac{\log2}{2}+\frac{\log3}{3},\qquad
b=1+\frac{1+\log5}{5}-c_{23},\qquad
\delta_0=\log\frac{729}{512}-\frac{\zeta(3)}8,
\]
\[
\boxed{\quad
\kappa=1-\gamma_E-\log\pi+\log12-2b+\delta_0>\frac15.
\quad}\tag{1}
\]
则真实旧奇 Weil 算子在整个 \(S_p\) 上满足
\[
\boxed{\quad
P_{S_p}A_{p^2,-}P_{S_p}\succeq(\kappa-o(1))I_{S_p}.
\quad}\tag{2}
\]
因此对充分大的此类 \(p\)，这个主压缩至少有 \(1/10\) 的正谱隙。该结论严格强于 note 792 的 \(O(1)\) 临界带定位；它仍不约束 \(S_p\) 与完整旧奇空间正交补之间的 Schur 反馈。

## 初等素数权上界

令 \(\psi(N)=\sum_{q^r\le N}\log q\)、\(M(N)=\sum_{q^r\le N}(\log q)/q^r=\sum_{n\le N}\Lambda(n)/n\)，其中 \(q\) 为素数。对任意整数 \(N\ge1\)，有初等界
\[
\psi(N)\le2N.
\tag{3}
\]
为证明它，令 \(h=\lceil N/2\rceil\)。每个 \(h<q^r\le N\) 在 \(\binom N{\lfloor N/2\rfloor}\) 的 \(q\)-进赋值中贡献至少一，因为
\(\lfloor N/q^r\rfloor=1\)，而两个下方阶乘的指标均小于 \(q^r\)；其余素数幂的赋值贡献非负。因此
\[
\psi(N)-\psi(h)
\le\log\binom N{\lfloor N/2\rfloor}
\le N\log2.
\tag{4}
\]
对偶数 \(N\)，归纳假设给 \(\psi(N)\le N+N\log2<2N\)。对奇数 \(N=2m+1\ge5\)，它给
\(\psi(N)\le2(m+1)+(2m+1)\log2\le2N\)，最后一步只用 \(\log2<4/5\)。\(N=1,2,3\) 直接成立，故 (3) 对所有 \(N\) 成立。

恒等式 \(\log N!=\sum_{n\le N}\Lambda(n)\lfloor N/n\rfloor\) 及
\(\lfloor N/n\rfloor\ge N/n-1\) 给
\[
NM(N)\le\log N!+\psi(N).
\]
又因 \(\log t\) 递增，
\[
\log N!\le\int_1^N\log t\,dt+\log N
=N\log N-N+1+\log N.
\]
结合 (3) 得
\[
M(N)\le\log N+1+\frac{1+\log N}{N}.
\tag{5}
\]
令 \(P_5(t)=\sum_{5\le q\le t,\ q\ {\rm prime}}(\log q)/q\)。对 \(t\ge5\)，取 \(N=\lfloor t\rfloor\)，从 (5) 减去 \(q=2,3\) 的首幂贡献 \(c_{23}\)，并利用 \((1+\log N)/N\) 在 \(N\ge5\) 递减，得到
\[
P_5(t)-\log t
\le1+\frac{1+\log5}{5}-c_{23}=b.
\tag{6}
\]
对 \(1\le t<5\)，左侧为 \(-\log t\le0<b\)，所以 (6) 对所有 \(t\ge1\) 一致成立。

## 精确行比与正压缩

对 note 792 的正权 \(v_{n,m}=(nm)^{-1/2}\)，note 793 式 (11b) 的精确恒等式是
\[
\frac{(C_{S_p}v)_{n,m}}{v_{n,m}}
=\left(\log n+P_5(X/n)
-\sum_{\substack{q\mid n\\q\le X/n}}\frac{\log q}{q}\right)
+\left(\log m+P_5(Y/m)
-\sum_{\substack{q\mid m\\q\le Y/m}}\frac{\log q}{q}\right).
\tag{7}
\]
两项中的占据素数和均非负。由 (6)，第一括号至多 \(\log X+b\)，第二括号至多 \(\log Y+b\)。因此正权 Schur 检验给
\[
\lambda_{\max}(C_{S_p})=\|C_{S_p}\|
\le\log X+\log Y+2b
=2\log p-\log12+2b+o(1).
\tag{8}
\]
这里 \(C_{S_p}\) 对称且逐项非负，故其算子范数等于 Perron 最大特征值。note 791 的 \(D_k=2\log p+1-\gamma_E-\log\pi\)，而 note 795 已独立证明 \(E_p\succeq(\delta_0-o(1))I\) 于整个 \(W_p\)，故也于 \(S_p\)。由
\(P_{S_p}A_{p^2,-}P_{S_p}=D_kI-C_{S_p}+P_{S_p}E_pP_{S_p}\)，(8) 立即给 (2)。

为给 (1) 的正性一个宽裕量，使用初等常数界
\[
\gamma_E<0.60,\quad\log\pi<1.15,\quad
\log12>2.48,\quad b<0.82,\quad\delta_0>0.11.
\]
最后一个还可由 note 795 的
\(\delta_0>217/729-3/16>0.11\) 直接看出。于是
\[
\kappa>1-0.60-1.15+2.48-2(0.82)+0.11=0.20.
\]
这证明 (1)。\(\square\)

## 边界

(2) 判定的是一个已达到 \(2\log p+O(1)\) **临界算术谱半径**的完整平方自由双臂主压缩，因而不能从临界主阶推断负方向。它未控制全 Farey 主压缩在 \(S_p^\perp\cap W_p\) 的反馈，更未控制无限维旧奇空间中的 Schur 反馈；全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 与 RH 均未由此判定。
