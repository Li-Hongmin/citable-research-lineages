# 保留真实素数支撑的可分离 Mellin 扰动击穿顶端四素数目标

日期：2026-10-01。依赖 [scratch/878](878-prime-cofactor-tube-self-cancels-through-bandpass-sidelobes.md) 式 (19)--(20)、(23)--(30) 的顶端管与原过滤门比较，以及 [scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 核对的 Matomäki--Shao--Tao--Teräväinen 2023 全区间短素数和。本文构造一个仍只含真实素数 \(p,q\)、正权且 \(p,q\) 可分离的微扰模型。它排除从这些结构和任意对数精度边际素数计数直接推出固定幂目标的通用推理；模型权重不是真实算术权，故不反驳真实门或 Riemann 假设。没有使用 OMEN 或数值计算。

## 命题

沿用 scratch/878 的 \(M=2Y\)、\(Y^{1/5}\le H\le Y^{1/4}\)、固定 \(s>1\)、非负非零 \(\psi\in C_c^3((1,2))\)、\(\phi(t)=\psi(t)/t\)、闭区间 \(J=[a,b]\subset(1,2)\) 与 \(w_H\)，并在 \(J\) 的内部取一段 \(\phi>0\)。令
\[
 \mathcal Q=\{q\text{ 素数}:H/2<q\le H\},\qquad
 c_q=4\log(q/2),\qquad
 \delta_M=\exp(-\sqrt{\log M}).
\]
固定 \(0<\kappa<1/20\) 并限制 \(H\le M^{1/4-\kappa}\)。存在 \(t\asymp H\) 和实相位 \(\theta,\xi\)，使
\[
 F_{\theta,\xi}(h)=\frac1M
 \sum_{\substack{q\in\mathcal Q,\ p\ {\rm prime}\\pq\in MJ}}
 c_q\,\phi(pq/M)
 \bigl(1+\delta_M\cos(t\log p+\theta)\bigr)
 \bigl(1+\delta_M\cos(t\log q+\xi)\bigr)
 e(-hpq/M)
\tag{1}
\]
满足
\[
 \boxed{\qquad
 \sum_h w_H(h)|F_{\theta,\xi}(h)|^2
 \gg_{s,\psi,J}\frac{\delta_M^4}{\log^2M},
 \qquad
 \frac{\delta_M^4/\log^2M}{H^4/M}\longrightarrow\infty.
 \qquad}\tag{2}
\]
两个括号严格为正、至多为 \(2\)，因此素数支撑、源内符号与乘积可分离性都保持。任一 \(p\) 或 \(q\) 整数区间 \(I\) 上，相应素数指示或 \(\Lambda\) 权计数因一个括号发生的改变量至多
\[
 O\bigl(\delta_M(|I|+1)\log M\bigr)
 =o_A\bigl((|I|+1)\log^{-A}M\bigr)\quad(\forall A>0).
\tag{3}
\]
固定 \(q\) 的完整带通能量和所有 \(q\in\mathcal Q\) 的能量和仍满足 scratch/878 式 (19)--(20) 的 \(O(1/H)\) 上界，原绝对行和证明的常数至多改变十六倍。若将 (1) 的行倍率同时施于相应高除数源，scratch/878 式 (23) 的四源逐对保留及式 (26) 的绝对误差比较也保持；因此其原过滤四素数 \(q\ne r\) 交叉同样超过 \(H^4/M\) 的目标上界。以上只针对构造的微扰模型。

## 引理：真实素数管的 Mellin 调制具有对数级带通能量

取 \(x_*\in(a,b)\) 与小的固定 \(u>0\)，使
\([x_*/(1+u),x_*]\subset(a,b)\) 且其上 \(\phi\ge c>0\)，并设
\(t=2\pi x_*H\)。定义
\[
 G_t(h)=\frac1M
 \sum_{\substack{q\in\mathcal Q,\ p\ {\rm prime}\\pq\in MJ}}
 c_q\phi(pq/M)(pq)^{it}e(-hpq/M).
\tag{4}
\]
则
\[
 \boxed{\qquad
 \sum_h w_H(h)|G_t(h)|^2\gg_{s,\psi,J}\frac1{\log^2M}.
 \qquad}\tag{5}
\]

**短窗近似。** 置 \(\eta(x)=\phi(x)\mathbf1_J(x)\) 和
\[
 \kappa_H=\sum_{q\in\mathcal Q}\frac{c_q}{q\log(M/q)}.
\tag{6}
\]
素数定理及分部求和给
\[
 \kappa_H\asymp_{\psi,J}\frac1{\log M}.
\tag{7}
\]
事实上 \(\sum_{q\in\mathcal Q}c_q/q\to4\log2\)，而
\(\log(M/q)\asymp\log M\)。

令 \(L=\lfloor M/(32H)\rfloor\)。对每个完全落在 \(MJ\) 的长度 \(L\) 物理整数窗 \(I\)，我们证明
\[
 \left|
 \sum_{\substack{q\in\mathcal Q,\ p\ {\rm prime}\\pq\in I}}
 c_q\phi(pq/M)(pq)^{it}
 -\kappa_H\sum_{m\in I}\phi(m/M)m^{it}
 \right|
 \ll_{\psi,J}\frac L{\log^2M}.
\tag{8}
\]
固定 \(q\in\mathcal Q\)，对应的 \(p\) 窗长
\(T=L/q+O(1)\asymp M/H^2\)，位置 \(x\asymp M/H\)。统一于整个 \(H\) 范围，\(T\ge x^{2/3-o(1)}\)。取整块长 \(B=\lfloor x^{13/20}\rfloor\)；于是 \(B\log^AM=o(T)\) 对每个固定 \(A\) 成立，且 \(13/20>7/12\)。scratch/862 核对的 2023 定理在每个完整 \(B\) 块给
\(\sum(\Lambda(n)-1)=O_A(B\log^{-A}M)\)。把 \(p\) 窗的任一前缀分成这样的整块及一个末块，末块以 \(\Lambda(n)\le\log(2M)\) 平凡支付，得到
\[
 \sup_{I'\subset I/q}
 \left|\sum_{n\in I'}(\Lambda(n)-1)\right|
 \ll_A T\log^{-A}M.
\tag{9}
\]
在这个 \(p\) 窗中 \(\log p=\log(M/q)+O_J(1)\)，高次素数幂的总 \(\Lambda\) 质量为 \(O(\sqrt{M/H}\log^2M)=o(T\log^{-A}M)\)。由 (9) 与正的 \(\Lambda\) 质量界，把素数计数同密度 \(1/\log(M/q)\) 比较，得到所有前缀的一致误差
\[
 \sup_{I'\subset I/q}
 \left|\#\{p\in I':p\text{ 素数}\}
       -\frac{|I'|}{\log(M/q)}\right|
 \ll_J\frac T{\log^2M}.
\tag{10}
\]
这里把 \(\log p\) 换为 \(\log(M/q)\) 的代价是
\(O(T/\log^2M)\)；长度小于一个整数单位的端点误差由右侧吸收。

在物理窗 \(I\) 上，函数
\(m\mapsto\phi(m/M)m^{it}\) 的上确界与总变差均为
\(O_{\psi,J}(1)\)，因为 \(tL/M=O(1)\)。用 (10) 对固定 \(q\) 作 Abel 求和，素数和同其连续密度积分的差为
\(O_{\psi,J}(c_q L/(q\log^2M))\)。对 \(q\in\mathcal Q\) 求和，利用
\(\sum_{q\in\mathcal Q}c_q/q=O(1)\)，总误差为
\(O_{\psi,J}(L/\log^2M)\)。连续积分的系数正是 (6)；将其改为物理整数和只花费
\(O_{\psi,J}(\kappa_H)\)，也被前述误差吸收。这证明 (8)。

**频带比较。** 定义物理序列
\[
 f_t(m)=\sum_{\substack{q\in\mathcal Q,\ p\ {\rm prime}\\m=pq}}
 c_q\eta(m/M)m^{it},\qquad
 g_t(m)=\kappa_H\eta(m/M)m^{it},
\]
并令 \(R_t(h)=M^{-1}\sum_m(f_t(m)-g_t(m))e(-hm/M)\)。
内部窗口由 (8) 给 \(O(L/\log^2M)\) 的未归一化窗和；只有跨越 \(J\) 两端的 \(O(L)\) 个循环窗口使用
\(O(L\log H)\) 平凡界。重复 scratch/878 式 (15) 的周期滑窗 Parseval（在 \(w_H(h)\ne0\) 时窗 Fourier 乘子绝对值 \(\gg L\)），得到
\[
 \sum_h w_H(h)|R_t(h)|^2
 \ll_{s,\psi,J}\frac1{\log^4M}+\frac{\log^2H}{H}
 =o(\log^{-2}M).
\tag{11}
\]
这一步没有假定单个素数 Fourier 系数有固定幂节省；只用 (10) 在长度 \(M/H^2\) 的全部窗口的对数精度计数。

**驻相主项。** 模型的 Fourier 系数满足
\[
 \frac1M\sum_m g_t(m)e(-hm/M)
 =\kappa_H M^{it}I_t(h)+O_{\psi,J}(\kappa_H H/M),
\quad
 I_t(h)=\int_J\phi(x)e^{i(t\log x-2\pi hx)}\,dx,
\tag{12}
\]
整数求积误差由被求和函数的 \(O(H)\) 总变差给出。当
\(H\le h\le(1+u)H\) 时，唯一驻点
\(x_h=t/(2\pi h)\in[x_*/(1+u),x_*]\) 远离 \(J\) 的边界。统一驻相估计为
\[
 I_t(h)=\phi(x_h)x_h^{it}e(-hx_h)e^{-i\pi/4}
        \frac{\sqrt{2\pi}\,x_h}{\sqrt t}
        +O_{\psi,J,u}(H^{-1}),
\qquad |I_t(h)|\gg H^{-1/2}.
\tag{13}
\]
故 \(w_H(h)=1\) 于该段给模型能量
\(\gg\kappa_H^2\gg\log^{-2}M\)。由 (11) 与平方三角不等式，真实调制管 \(G_t\) 也满足 (5)。

## 相位平均及原门接口

将 (1) 的两个余弦展开成正负指数。把 \(\theta,\xi\) 独立均匀地取遍 \([0,2\pi]\)，\(F_{\theta,\xi}(h)\) 关于相位字符 \(e^{i(\theta+\xi)}\) 的 Fourier 系数恰是
\(\delta_M^2G_t(h)/4\)。二维 Parseval 与 (5) 给
\[
 \frac1{(2\pi)^2}\int\!\int
   \sum_h w_H(h)|F_{\theta,\xi}(h)|^2\,d\theta\,d\xi
 \ge\frac{\delta_M^4}{16}\sum_hw_H(h)|G_t(h)|^2
 \gg\frac{\delta_M^4}{\log^2M}.
\tag{14}
\]
存在相位达到该下界。因为 \(H^4/M\le M^{-4\kappa}\) 而
\(\delta_M^4/\log^2M=M^{-o(1)}\)，得到 (2)。

式 (3) 由 \(|\cos|\le1\) 直接得出；相同的界适用于任意固定长度假设下的 p/q 边际短区间计数。固定 \(q\) 时，(1) 的每个行权相对原权至多乘 \(4\)，所以 scratch/878 式 (19)--(20) 的绝对核行和界至多乘 \(16\)。该文式 (26) 删除的同 \(q\)、共享 \(p\)、物理近差及远差全部以逐项绝对值支付；每个物理行倍率在 \((0,4)\)，故误差仍为 \(O_{s,\psi,J}(H^4/M)\)。式 (23) 的源过滤关系由素因子集合决定，倍率不改变它。因此原过滤四素数交叉与 (1) 的完整能量相差目标量级，在构造的相位上也违反其目标上界。\(\square\)

## 边界

相对于 [scratch/880](880-logarithmically-invisible-prime-row-modulation-defeats-the-four-prime-target.md) 的乘积行调制，这里两个微扰因子分别只看 \(p\) 和 \(q\)，保留真实双素数支撑及正源权。结论只排除以一变量对数精度短和、逐 \(q\) 能量、正权和可分离性为全部输入的通用论证。

2023 年 Matomäki--Shao--Tao--Teräväinen 原论文（*Forum Math. Pi* **11**, e29, DOI 10.1017/fmp.2023.28）的 Theorem 1.1(i)--(ii) 对 \(\mu\) 与 \(\Lambda-\Lambda^\sharp\) 的线性相位，即使区间长达到 \(x^{5/8+\varepsilon}\)，结论仍是任意固定对数幂节省；给固定幂节省的 (iii) 处理的是除数函数。本文 \(p\) 窗长 \(M/H^2\) 相对 \(x\asymp M/H\) 的指数至少为 \(2/3-o(1)\)，满足定理长度条件，却不会因此取得 \(H^4/M\le M^{-4\kappa}\) 所需的固定幂。该精确文献边界与反模型一致，仍不判定真实系数是否另有联合抵消。

顶端管的独立上界也不是完整 moving-\(N\) 门的必要条件。事实上，奇素数 \(p\gg H\)、\(q\in\mathcal Q\) 的物理行 \(m=pq\) 在高除数管中有 scratch/878 式 (6) 的系数 \(4\log(q/2)\phi(m/M)/M\)，而 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10) 的完整观察系数在同一行精确为
\[
 \frac{c(pq)}M\phi(pq/M)
 =\frac{4(1-\log2)}M\phi(pq/M).
\]
低除数及背景在这一行合计消去了 \(4(\log q-1)\phi(pq/M)/M\)。故若真实顶端管独立目标失败，仍需检查其与其他源和物理族在完整系数中的抵消。本文没有估计实际 \(\Lambda(p)-1\)、\(\Lambda(q)-1\) 或完整 moving-\(N\) 余项；全尺度局部 Weil 正性和 RH 仍未证明。
