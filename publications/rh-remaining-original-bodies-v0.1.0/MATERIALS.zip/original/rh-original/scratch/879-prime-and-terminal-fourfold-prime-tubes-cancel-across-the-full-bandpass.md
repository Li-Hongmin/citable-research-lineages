# 素数 cofactor 管与终端 \(4r\) 管的完整带通交叉抵消

日期：2026-10-01。依赖 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md)、[scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md)、[scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 式 (7)、[scratch/877](877-doubled-prime-physical-rows-cancel-in-the-true-high-divisor-gram.md) 式 (15)--(17) 与 [scratch/878](878-prime-cofactor-tube-self-cancels-through-bandpass-sidelobes.md) 式 (25)。结果尚未异源复核，留在 scratch；它没有给出固定幂的完整 covariance 上界。

## 命题

令 \(M=2Y\)、\(Y^{1/5}\le H\le Y^{1/4}\)、\(D=\lfloor M/(16H)\rfloor\)、\(L=\lfloor M/(32H)\rfloor\)。固定 \(s>1\) 及非负非零的实函数 \(\psi\in C_c^3((1,2))\)，置 \(\phi(u)=\psi(u)/u\)。取 \(J=[a,b]\subset(1,2)\)，使 \(\phi\ge c_\psi>0\) 于 \(J\)。沿用 scratch/859--860 的 \(w_H,J_H,K_0=H^3/\log^7(2M)\) 和 \(K=K_{s,2}\)。设
\[
\begin{aligned}
 A&=\{pq\in MJ:p,q\text{ 为素数},\ H/2<q\le H\},\\
 B&=\{4p'r\in MJ:p',r\text{ 为奇素数},\ 4bH<r\le8H\}.
\end{aligned}\tag{1}
\]
对 \(m\in A,n\in B\)，真实高除数物理系数 \(a_D\) 满足
\[
 a_D(pq)=\frac{4\log(q/2)}M\phi(pq/M)>0,\qquad
 a_D(4p'r)=-\frac{6\log2+2\log r}{M}\phi(4p'r/M)<0.
\tag{2}
\]
原剩余门的源指标过滤对每一对 \((m,n)\in A\times B\) 都保留全部高除数源项。只取该门的有序 \(A\times B\) 项，记其 signed 和为 \(\mathfrak C_{AB}\)；再按物理距离分为 \(K_0<|m-n|\le L\) 的 \(\mathfrak N_{AB}\) 和 \(L<|m-n|\le K\) 的 \(\mathfrak F_{AB}\)。则一致于给定 \(H\) 范围，
\[
 \boxed{|\mathfrak C_{AB}|\ll_{s,\psi,J}\log^{-4}(2M),\qquad
 \mathfrak N_{AB}\le-\frac{c}{\log^2M},\qquad
 \mathfrak F_{AB}\ge\frac{c}{\log^2M}-O_{s,\psi,J}(\log^{-4}M).}
\tag{3}
\]
这里 \(c=c(s,\psi,J)>0\)。若把 \(A\times B\) 与 \(B\times A\) 两个方向合计，三个量都乘以 \(2\)。

## 源项逐对完整保留

在 \(A\) 中，\(p>aM/H\gg H\ge q\)，且 \(p>D\)；非零高除数源恰为 \(d=p,pq\)。在 \(B\) 中，
\[
 \frac{aM}{32H}<p'<\frac{M}{16H},
\]
故充分大 \(M\) 时 \(D/2<p'\le D\)，而 \(r\asymp_J H\ll D\)。非零高除数源恰为 \(e=2p',p'r,2p'r\)。由 scratch/877 式 (10)，
\(\alpha(2r)=4\log2+2\log r\)、\(\alpha(4)=6\log2\)、\(\alpha(2)=4\log2\)。故
\[
 \sum_{e\in\{2p',p'r,2p'r\}}\mu(e)b_e(4p'r)
 =\frac{\phi(4p'r/M)}M[-\alpha(2r)-\alpha(4)+\alpha(2)],
\]
得到 (2) 的第二式；第一式是 scratch/878 式 (6)。

四个奇素数 \(p,q,p',r\) 两两不同：\(p>aM/H\)、\(p'\le M/(16H)\)，二者都远大于 \(8H\)，而 \(q\le H<4bH<r\)。因此 \((pq,4p'r)=1\)，每个上述 \(d,e\) 也互素。又 \(d,e>D>R\)，故 \(d\nmid e,e\nmid d\) 且 \(\max(d/(d,e),e/(d,e))>R\)。原门不删任一源项；其距离条件只依赖 \(m,n\)。每个被保留的物理配对的六个源项之和恰为 \(a_D(m)a_D(n)J_H(m-n)\)。

## 两个完整管的频带能量

记 \(c_q=4\log(q/2)\)、\(d_r=6\log2+2\log r\)，并按模 \(M\) 周期化定义
\[
 f_A(m)=M a_D(m){\bf1}_{m\in A},\qquad
 f_B(m)=M a_D(m){\bf1}_{m\in B},\qquad
 \eta(u)=\phi(u){\bf1}_{u\in J}.
\tag{4}
\]
相应的平滑密度为 \(\kappa_A\eta\) 和 \(-\kappa_B\eta\)，其中
\[
 \kappa_A=\sum_{\substack{H/2<q\le H\\q\ {\rm prime}}}
 \frac{c_q}{q\log(M/q)},\qquad
 \kappa_B=\sum_{\substack{4bH<r\le8H\\r\ {\rm prime}}}
 \frac{d_r}{4r\log(M/(4r))}.
\tag{5}
\]
素数调和估计给 \(\kappa_A,\kappa_B\asymp_J\log^{-1}M\)。其中 \(B\) 的比例区间非空，因为 \(b<2\)，且 \(\sum_{4bH<r\le8H,\ r\ {\rm prime}}r^{-1}\sim\log(2/b)/\log H\)。

以下验证 \(B\) 管的频带界；\(A\) 管已由 scratch/878 式 (25) 得到同一界。取长度 \(L\) 的整数窗 \(I\subset MJ\)。对每个上述 \(r\)，素数 \(p'\) 的窗口长 \(T=L/(4r)+O(1)\asymp_J M/H^2\)，所在尺度 \(x\asymp_J M/H\)。在整个 \(H\) 范围，\(T\ge x^{7/12+1/20}\) 且 \(T\le x^{1-1/20}\) 对充分大 \(M\) 成立；最紧的是 \(H\asymp M^{1/4}\) 时 \(T\asymp x^{2/3}\)。scratch/862 式 (7) 的全区间素数定理、素数幂的 \(O(\sqrt x\log^2x)=o(T/\log^A M)\) 上界，以及 \(\log p'=\log(M/(4r))+O_J(1)\)，一致给出
\[
 \#\{p':4rp'\in I\}
 =\frac{L}{4r\log(M/(4r))}
 +O_J\!\left(\frac{L}{r\log^2M}\right).
\tag{6}
\]
把 \(\phi\) 在 \(I\) 内任一点冻结，使用 \(\|\phi'\|_\infty L/M\ll_\psi H^{-1}\) 与 \(\sum_r d_r/r\ll_J1\)，再与离散平滑模型比较，得到每个完整内窗的一致界
\[
 \left|\sum_{m\in I}\{f_B(m)+\kappa_B\eta(m/M)\}\right|
 \ll_{\psi,J}\frac{L}{\log^2M}.
\tag{7}
\]
窗若与 \(MJ\) 不交，两项均为零。只有 \(O(L)\) 个循环窗跨过 \(J\) 的两个端点；对它们用 \(|f_B|\ll_\psi\log H\) 和 \(|\kappa_B\eta|\ll_\psi1\)，得到 \(O_\psi(L\log H)\) 的窗和界。

记 \(F_{B,h}=M^{-1}\sum_m f_B(m)e(-hm/M)\)，\(G_{B,h}=-M^{-1}\sum_m\kappa_B\eta(m/M)e(-hm/M)\)。令 \(V_h=\sum_{j=0}^{L-1}e(-hj/M)\)。在 \(w_H(h)\ne0\) 时，\(|V_h|\gg L\)。对 (7) 的循环窗和应用 Parseval，得
\[
 \sum_h w_H(h)|F_{B,h}-G_{B,h}|^2
 \ll_{s,\psi,J}
 \frac1{ML^2}\left[M\frac{L^2}{\log^4M}
 +L^3\log^2H\right]
 \ll\log^{-4}M+\frac{\log^2H}{H}.
\tag{8}
\]
函数 \(\eta=\phi{\bf1}_J\) 有界变差，故 \(|G_{B,h}|\ll_{\psi,J}\kappa_B/|h|\) 对频带中的 \(h\) 成立，其频带能量为 \(O(1/(H\log^2M))\)。于是
\[
 E_B:=\sum_hw_H(h)|F_{B,h}|^2
 \ll_{s,\psi,J}\log^{-4}M+\frac{\log^2H}{H}
 \ll_{s,\psi,J}\log^{-4}M.
\tag{9}
\]
scratch/878 式 (25) 给相同的 \(E_A\ll\log^{-4}M\)。Cauchy--Schwarz 因此给完整交叉
\[
 \left|\sum_{m\in A,n\in B}a_D(m)a_D(n)J_H(m-n)\right|
 =\left|\sum_hw_H(h)F_{A,h}\overline{F_{B,h}}\right|
 \le\sqrt{E_AE_B}\ll\log^{-4}M.
\tag{10}
\]

固定比例区间的素数定理及素数调和估计给 \(\#A\ll_J M/\log^2M\)；由 (2)，两类物理系数均为 \(O_\psi(\log H/M)\)。对每个 \(m\in A\)，最多 \(2K_0+1\) 个整数 \(n\) 满足 \(|m-n|\le K_0\)，而 \(|J_H|\ll_s H\)。故
\[
 \sum_{\substack{m\in A,n\in B\\|m-n|\le K_0}}
 |a_D(m)a_D(n)J_H(m-n)|
 \ll_{s,\psi,J}\frac{HK_0}{M}
 \ll\frac{H^4}{M\log^7(2M)}.
\tag{11}
\]
在 \(|m-n|>K\) 的绝对质量由 scratch/860 式 (3) 的全局源包络支付为 \(O(M^{-2})\)。式 (10)--(11) 与 \(H^4/M\ll1\) 说明
\[
 |\mathfrak C_{AB}|
 \ll\log^{-4}M+\frac{H^4}{M\log^7M}+M^{-2}
 \ll\log^{-4}M.
\tag{12}
\]

## 近距离负块与远距离补偿

在 \(|m-n|\le L\) 时，\(w_H(h)\ge0\) 且 \(|h|\le4H\) 给
\[
 J_H(m-n)=\sum_hw_H(h)\cos(2\pi h(m-n)/M)
 \ge2^{-1/2}\sum_hw_H(h)\gg_s H.
\tag{13}
\]
把 \(MJ\) 分成长度 \(L\) 的完整整数盒，舍弃至多两个残盒。对每个完整盒 \(I\)，(6) 及其 \(q\) 版、\(\phi\ge c_\psi\) 与 (5) 的素数调和下界给
\[
 \sum_{m\in A\cap I}a_D(m)\gg_{\psi,J}\frac{L}{M\log M},
 \qquad
 -\sum_{n\in B\cap I}a_D(n)\gg_{\psi,J}\frac{L}{M\log M}.
\tag{14}
\]
完整盒数为 \(\asymp_J M/L\asymp_J H\)。同盒所有 \(A\times B\) 配对的物理距离至多 \(L\)，且 (2)、(13) 使其贡献为负。因此由 (14)，同盒总交叉至多
\[
 -c_{s,\psi,J}H\frac ML
 \left(\frac{L}{M\log M}\right)^2
 \le-\frac{c'_{s,\psi,J}}{\log^2M}.
\tag{15}
\]
删除同盒中 \(|m-n|\le K_0\) 的项至多花费 (11)，它是 \(o(\log^{-2}M)\)。又所有满足 \(K_0<|m-n|\le L\) 的其余配对也由 (2)、(13) 给负贡献；于是 \(\mathfrak N_{AB}\le-c/\log^2M\)。由 \(K_0<L<K\) 及 (12)，有 \(\mathfrak F_{AB}=\mathfrak C_{AB}-\mathfrak N_{AB}\ge c/\log^2M-O(\log^{-4}M)\)，证明 (3)。因为 \(a_D(m)a_D(n)<0\)，此正的远距离合计必由 \(J_H\) 的负值项贡献。\(\square\)

## 边界

这次跨管检验排除了把 \(A\times B\) 的近距离异号配对单独解释为完整 Gram 的固定幂增益。式 (5) 的两条平滑密度各自只有 \(O(1/(H\log^2M))\ll H^4/M\) 的频带能量，因为 \(H^5\gg M\)。因此若单独研究这两个管的目标界，承重项是扣掉平滑密度后的短区间素数误差。当前对它的均方仍只有对数精度，(9)--(12) 远大于 \(H^4/M\) 在 \(H\le M^{1/4-\theta}\) 时的固定幂目标。单独支付两个管只是充分条件，不是完整三通道门的必要条件；完整门仍可能依赖跨物理族的联合消去。
