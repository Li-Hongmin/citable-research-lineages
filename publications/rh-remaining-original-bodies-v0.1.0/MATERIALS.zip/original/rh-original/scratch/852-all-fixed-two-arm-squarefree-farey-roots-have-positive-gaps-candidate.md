# 所有固定双臂根的平方自由 Farey 主压缩有显式正谱隙（待独立复核）

此候选已晋级为 [note 798](../notes/798-all-fixed-two-arm-squarefree-farey-roots-have-positive-gaps.md)；以该 note 为权威版本。

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确全 Farey 图、[note 795](../notes/795-full-farey-dipole-archimedean-remainder-is-uniformly-positive.md) 的正余项，以及 [note 797](../notes/797-uniform-prime-harmonic-bound-strengthens-the-squarefree-farey-gap.md) 的素数调和界。这里把 note 797 的根 \(4/3\) 扩到每个固定双臂互素根；只处理阶跃偶极主压缩。

## 命题

固定互素整数 \(a,b\ge2\)。令 \(p\to\infty\) 沿奇素数，\(k=p^2\)、\(X=(p-1)/a\)、\(Y=(p-1)/b\)，并定义
\[
\mathcal N_{a,b,p}=\{(n,m):1\le n\le X,\ 1\le m\le Y,\ \mu^2(nm)=1,\ (nm,6ab)=1\}.
\]
对每对指标取 note 791 的 Farey 标签
\(x_{n,m}=\max\{an/(bm),bm/(an)\}>1\)，令
\(S_{a,b,p}=\operatorname{span}\{w_{x_{n,m}}:(n,m)\in\mathcal N_{a,b,p}\}\)。记 \(\delta_0=\log(729/512)-\zeta(3)/8\)。则
\[
\boxed{P_{S_{a,b,p}}A_{p^2,-}P_{S_{a,b,p}}
\succeq\bigl(\kappa_{a,b}-o_{a,b}(1)\bigr)I,
\qquad \kappa_{a,b}=1-\gamma_E-\log\pi+\log(ab)+\delta_0>1.}
\tag{1}
\]
因而每个固定双臂根都给出正的完整平方自由后代主压缩；\(a,b\) 不随 \(p\) 变化。

## 标签与内部素数幂

由 \((a,b)=1\)、\((nm,ab)=1\)、\(\mu^2(nm)=1\)，\(an\) 与 \(bm\) 互素，且均小于 \(p\)。它们不能相等，因为 \(a,b\ge2\)。若两个原始比值相等，则 \(an bm'=an' bm\)，由两对各自互素得 \(an=an'\)、\(bm=bm'\)，即 \((n,m)=(n',m')\)。若两个原始比值互为倒数，则
\(a^2nn'=b^2mm'\)，与 \((nm n'm',ab)=1\) 及 \((a,b)=1\) 矛盾。故标签互异，\(\{w_{x_{n,m}}\}\) 为正交单位族，且 \(S_{a,b,p}\subset W_p\)。

把原始比值 \(an/(bm)\) 的素数指数记作带符号向量。每个 \(q\mid ab\) 有固定的非零指数，其余允许的 \(q\ge5\)、\(q\nmid ab\) 只有 \(0,+1,-1\) 三种状态；\(q=2,3\) 若不在 \(ab\) 中则固定为零。note 791 的算术图一条素数幂 \(q^r\) 边只改变一个 \(q\) 的带符号指数，或者在 \(x\mapsto x^{-1}\) 折叠后将**全部**指数反号。因为 \(a,b\ge2\) 且互素，固定根在至少两个不同素数上具有非零指数。故一条改变固定根素数的边不能留在本家族：不折叠时该指数错误，折叠时另一个固定根素数的指数错误。同理，\(2,3\) 中未被根占据的素数也不能产生内部边。

所以内部边仅来自 \(q\ge5,\ q\nmid ab\) 的 \(q\) 加入、删除与 \(q^2\) 换臂；没有更高素数幂边或自环。令
\(P_{a,b}(t)=\sum_{5\le q\le t,\ q\nmid ab}(\log q)/q\)、\(a_q=(\log q)/q\)，以及正权 \(v_{n,m}=(nm)^{-1/2}\)。与 note 793 式 (11a)--(11b) 相同的逐 \(q\) 计数给精确行比
\[
\begin{aligned}
\frac{(C_{S_{a,b,p}}v)_{n,m}}{v_{n,m}}
={}&\log n+P_{a,b}(X/n)-\!
\sum_{\substack{q\mid n\\q\le X/n}}a_q\\
&+\log m+P_{a,b}(Y/m)-\!
\sum_{\substack{q\mid m\\q\le Y/m}}a_q.
\end{aligned}\tag{2}
\]
例如 \(q\mid n\) 时，删除 \(q\) 给 \(\log q\)；若 \(mq\le Y\)，\(q^2\) 换臂给 \(a_q\)，恰抵消 \(m\) 臂在 \(P_{a,b}(Y/m)\) 中因 \(q\) 已占据而应删除的 \(a_q\)。另一臂同理。这也解释为何 (2) 的占据扣除只在原来的臂。

## 正权估计

note 797 已证明 \(P_5(t)\le\log t\) 对全部 \(t\ge1\)。由于 \(P_{a,b}(t)\le P_5(t)\) 且 (2) 的占据和非负，所有行满足
\[
\frac{(C_{S_{a,b,p}}v)_{n,m}}{v_{n,m}}
\le\log X+\log Y
=2\log p-\log(ab)+o_{a,b}(1).
\tag{3}
\]
\(C_{S_{a,b,p}}\) 对称、逐项非负，故正权 Schur 检验给其算子范数不超过 (3) 右端。note 791 的标量项是 \(D_k=2\log p+1-\gamma_E-\log\pi\)，note 795 的 \(E_p\succeq(\delta_0-o(1))I\) 可压缩到 \(S_{a,b,p}\)。因此
\[
P_{S_{a,b,p}}A_{p^2,-}P_{S_{a,b,p}}
\succeq\bigl(1-\gamma_E-\log\pi+\log(ab)+\delta_0-o_{a,b}(1)\bigr)I.
\]
互素 \(a,b\ge2\) 强制 \(ab\ge6\)。用 \(\gamma_E<0.60\)、\(\log\pi<1.15\)、\(\log6>1.79\)、\(\delta_0>0.11\)，得 \(\kappa_{a,b}>1.15>1\)。这证明 (1)。\(\square\)

## 边界

固定根的两个非零素数指数是排除根素数内部平移的承重条件；单臂根不在此命题中。式 (1) 不给全 Farey 主压缩、不同根之间的交叉或完整旧奇空间的 Schur 反馈任何正性判据；moving-\(N\) Möbius signed covariance 与 RH 仍未判定。
