# 单一平方自由双臂 Farey 家族已达到临界算术谱半径（候选）

本草稿已晋级为 [note 792](../notes/792-a-single-squarefree-two-arm-farey-family-has-critical-arithmetic-radius.md)；以后者为准。

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确 Farey 压缩及其全图谱上界。[scratch 843](843-each-farey-denominator-fiber-has-a-half-logarithmic-weil-gap-candidate.md) 表明单一分母只有半对数算术谱半径；[scratch 844](844-two-arm-farey-graph-through-two-prime-generations-retains-a-logarithmic-gap-candidate.md) 给双臂前两代正谱隙。本文保留同一根 \(4/3\) 的**全部平方自由双臂后代**，证明它已达到完整 Farey 图的主阶算术谱半径。尚待异源复核，留在 scratch。

## 命题

沿奇素数 \(p\to\infty\)，令 \(k=p^2\)、\(H=\log p\)、\(L=2H\)、\(X=(p-1)/4\)、\(Y=(p-1)/3\)。设 \(\mathcal N_p\) 是满足
\[
1\le n\le X,\quad 1\le m\le Y,\quad
\mu^2(nm)=1,\quad (nm,6)=1
\]
的整数对，其中 \(\mu^2(nm)=1\) 同时要求 \(n,m\) 平方自由且互素。对 \((n,m)\in\mathcal N_p\)，把
\[
x_{n,m}=\max\{4n/(3m),\,3m/(4n)\}>1
\]
视为 note 791 的 Farey 标签；令 \(S_p=\operatorname{span}\{w_{x_{n,m}}:(n,m)\in\mathcal N_p\}\)。则所有这些标签不同，且算术矩阵的主压缩满足
\[
\boxed{\quad
\lambda_{\max}(P_{S_p}C_pP_{S_p}|_{S_p})=L+O(1).\quad} \tag{1}
\]
真实旧奇 Weil 压缩因而已落在临界常数尺度：
\[
\boxed{\quad
\left|\lambda_{\min}(P_{S_p}A_{p^2,-}P_{S_p}|_{S_p})\right|=O(1).\quad} \tag{2}
\]
这里的 \(O(1)\) 不决定 (2) 中最低谱值的符号；它不证明该压缩或完整旧奇算子正性。

## 标签与可保留的素数边

因为 \(n,m\) 只含 \(q\ge5\) 的素因子，\(4n\) 与 \(3m\) 互素且都小于 \(p\)，故 \(x_{n,m}\in\mathcal F_p\)。原始比值 \(4n/(3m)\) 不可能为一。若两个原始比值相等，则 \(nm'=n'm\)，由各对内部的互素性得 \(n=n',m=m'\)；若它们互为倒数，则 \(16nn'=9mm'\)，与两边的 \(2\)-、\(3\)-进赋值矛盾。因此 \((n,m)\mapsto x_{n,m}\) 单射，\(\{w_{x_{n,m}}\}\) 是正交单位族。

记 \(c_q=(\log q)/\sqrt q\)。在原始比值 \(4n/(3m)\) 上删去 \(q\mid n\) 或 \(q\mid m\)，或在 \(q\ge5\)、\(q\nmid nm\) 时给 \(n\) 或 \(m\) 加上 \(q\) 而仍满足 \(nq\le X\) 或 \(mq\le Y\)，都将原始比值乘以 \(q\) 或 \(q^{-1}\)。折回 \(x\mapsto\max(x,x^{-1})\) 后，该边在 note 791 式 (4) 中成为比值边或乘积边，权均为 \(c_q\)。其他算术边逐项非负，故以正权
\[
v_{n,m}=(nm)^{-1/2},\qquad
F(r)=\sum_{q\mid r}\frac{\log q}{q},
\]
有逐行下界
\[
\begin{aligned}
\frac{(C_{S_p}v)_{n,m}}{v_{n,m}}
&\ge \log n+\log m
+\sum_{\substack{5\le q\le X/n\\q\nmid nm}}\frac{\log q}{q}
+\sum_{\substack{5\le q\le Y/m\\q\nmid nm}}\frac{\log q}{q}\\
&\ge\log X+\log Y-O(1)-2F(nm). \tag{3}
\end{aligned}
\]
最后一步使用 \(\sum_{5\le q\le t}(\log q)/q=\log t+O(1)\) 对 \(t\ge1\) 一致；它由 note 791 使用的 \(\sum_{q^r\le t}(\log q)/q^r=\log t+O(1)\) 减去绝对收敛的高素数幂级数以及 \(q=2,3\) 的两项得到。

## 调和质量与平均缺失权

令 \(g(n,m)=\mu^2(nm)\mathbf1_{(nm,6)=1}\)，\(Z(X,Y)=\sum_{n\le X,m\le Y}g(n,m)/(nm)=\|v\|^2\)。则
\[
\boxed{Z(X,Y)\sim\mathfrak c\log X\log Y,
\qquad \mathfrak c>0.} \tag{4}
\]
为直接核对，考虑二变量 Dirichlet 级数
\[
\sum_{n,m\ge1}\frac{g(n,m)}{n^s m^t}
=\prod_{q\ge5}(1+q^{-s}+q^{-t})
=\zeta(s)\zeta(t)\,h(s,t).
\]
其中 \(h\) 在 \((1,1)\) 的 Dirichlet 系数按 \(1/(de)\) 绝对可和：对 \(q\ge5\) 的局部因子为
\[
(1+u+v)(1-u)(1-v)
=1-u^2-v^2-uv+u^2v+uv^2,
\qquad u=q^{-s},\ v=q^{-t},
\]
其非恒定系数的绝对 \((1,1)\)-质量为 \(O(q^{-2})\)；\(q=2,3\) 只贡献有限因子 \((1-2^{-s})(1-2^{-t})(1-3^{-s})(1-3^{-t})\)。因此 \(g=1*_{2}h\)，从调和数 \(H_T=\log T+O(1)\)、绝对可和与支配收敛得到 (4)，其常数为
\[
\mathfrak c=h(1,1)
=\frac19\prod_{q\ge5}\left(1-\frac3{q^2}+\frac2{q^3}\right)>0. \tag{5}
\]
这里前因子是 \((1-1/2)^2(1-1/3)^2=1/9\)；(4) 只用 \(\mathfrak c>0\)。

再对缺失权求和。若 \(q\mid nm\)，由 \(g(n,m)=1\) 可知 \(q\) 只在一个坐标出现。用 \(n=qn'\) 或 \(m=qm'\) 并丢去剩余限制，得到
\[
\begin{aligned}
\sum_{n\le X,m\le Y}\frac{g(n,m)F(nm)}{nm}
&\le (\log X+O(1))(\log Y+O(1))
\sum_{q\ge5}\frac{2\log q}{q^2}\\
&=O(\log X\log Y). \tag{6}
\end{aligned}
\]
故 \(F(nm)\) 关于权 \(g(n,m)/(nm)\) 的平均为 \(O(1)\)。把 (3) 按 \(v_{n,m}^2\) 求和，再用 (4)--(6)，得
\[
\frac{\langle v,C_{S_p}v\rangle}{\|v\|^2}
\ge\log X+\log Y-O(1)=L-O(1). \tag{7}
\]
note 791 式 (7) 给完整 \(\|C_p\|\le L+O(1)\)，所以 (1) 成立。note 791 式 (6) 还给 \(P_{W_p}A_{p^2,-}P_{W_p}=D_kI-C_p+E_p\)、\(D_k=L+O(1)\)、\(\|E_p\|=O(1)\)；压缩至 \(S_p\)，由 Weyl 不等式得 (2)。\(\square\)

## 边界

临界主阶已经存在于一棵固定根的平方自由双臂子图中，故以“每个分母纤维有半对数谱隙”不能推出其并图保留主阶谱隙。剩余问题在常数级算术谱修正、有界 Archimedean 压缩及完整旧奇算子的无限维 Schur 反馈；moving-\(N\) Möbius signed covariance 仍无 \(Y^{2+\varepsilon}\) 上界。
