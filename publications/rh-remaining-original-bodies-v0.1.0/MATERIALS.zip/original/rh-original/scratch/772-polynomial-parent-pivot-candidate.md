# 多项式 parent 带的真实单胞枢轴与 aligned 负荷：修正稿，待异源复核

日期：2026-09-29。此稿尚未晋级为永久数学 note。依赖 note 771 的单胞形式、Desogus arXiv:2609.20367v2 的真实 source intervals (92)、Lemma 6.6 的 source/target ground-line invariance、`eq:true-ground-ew` 的真实缩放 ground 与 Lemma 6.58 的单胞 common-cut 枢轴。以下只谈该源截口，未证明完整 Weil harmonic graph 的预算。原稿把几何坐标的真实槽 ground 误写成常数；本稿改用真实 ground，全程在原几何坐标中计算单胞形式。

## 候选定理

任取固定 \(0<a<b<1\)。按原文记号，令
\[
\mathcal N_{k,m}=\{n=p^\ell\le k:n\nmid k,\ \lfloor k/n\rfloor=m\},
\quad
C_m=\sum_{n\in\mathcal N_{k,m}}n,\quad
b_m=\frac{\sum_{n\in\mathcal N_{k,m}}\Lambda(n)}{\sqrt{C_m}},
\]
\[
w_j=\log(1+1/j),\quad
\varepsilon_{k,m}=w_k/w_m,\quad
\theta_{k,m}^2=\frac{\Phi(w_m)}{\Phi(w_k)},\quad
\Phi(t)=\frac{t^2e^{-t}}{(1-e^{-t})^2}.
\]
只对非空 parent 定义其单胞精确继承枢轴 \(P_{k,m}^{\rm ex}\)。候选结论为
\[
P_{k,m}^{\rm ex}
=(1+o_{a,b}(1))\log(k/m)
\quad\text{一致于 }k^a\le m\le k^b,\ \mathcal N_{k,m}\ne\varnothing,
\tag{A}
\]
及
\[
\sum_{\substack{k^a\le m\le k^b\\\mathcal N_{k,m}\ne\varnothing}}
\frac{\theta_{k,m}^2b_m^2}{P_{k,m}^{\rm ex}}
=(b-a+o_{a,b}(1))\log k.
\tag{B}
\]
特别地，所有 parent 的相同非负 aligned 扣款之和的 \(\liminf/\log k\) 至少为 \(1\)，但本稿不对其上界或完整 Schur 形式下结论。

同一证明还覆盖一个随 \(k\) 扩张的带：任取固定 \(A,B>3\)，令
\[
(\log k)^A\le m\le k/(\log k)^B.
\tag{B0}
\]
此时 \(L=\log(1/\varepsilon)\ge B\log\log k+o(1)\)。在下文取
\(R=\varepsilon^{-1+L^{-1/2}}\) 时，(D) 给出的
\(A_RL\ll Le^{-\sqrt L}+(\log k)^2/m=o(1)\) 一致成立。故 (A)、(A')、(A'') 的相对渐近均一致延伸至 (B0)，而 (B) 在此带上的右边变为 \((1+o(1))\log k\)。这个加强把“所有 parent 的 \(\liminf\)”变成一个明示带上的实际渐近。

交叉核对：在 \(m\ge\sqrt k\) 的子带中，每个 parent 最多有一个整数 \(n\)，故 \(b_m^2=\Lambda(n)^2/n\)。note 771 的单区间下界与下文的真实 ground 测试函数上界给出 \(P_{k,m}^{\rm ex}\sim\log n\)（当 \(n\to\infty\)）；这一子带的主项是 \(\sum_{p\le\sqrt k}\log p/p\sim\frac12\log k\)，与 (B) 的系数相符。

## 解析枢轴

在 parent 归一化的 \((0,1)\) 上，每个 source interval \(I_n\) 长度为 \(\varepsilon=\varepsilon_{k,m}\)。其中心
\[
x_n=\frac{\log(k/(mn))}{w_m}+\frac{\varepsilon}{2}.
\]
若 \(n<n'\) 是相邻的两个 source 指标，由 \(n'\ge n+1\)、\(n\le k/m\) 得
\[
|x_n-x_{n'}|
=\frac{\log(n'/n)}{w_m}
\ge d:=\frac{\log(1+m/k)}{w_m},
\qquad
\frac{\varepsilon}{d}
=\frac{w_k}{\log(1+m/k)}
\le\frac1m+\frac1k.
\tag{C}
\]
记 \(\ell_n=x_n-\varepsilon/2\) 为 \(I_n\) 的左端点。原文的 source/target ground-line invariance 及真实缩放 ground 给出几何坐标中的单位槽函数
\[
v_n(x)=\varepsilon^{-1/2}e_{w_k}\!\left(\frac{x-\ell_n}{\varepsilon}\right)1_{I_n}(x),
\qquad
e_w(t)=\frac{e^{-wt/2}}{\left(\int_0^1e^{-ws}\,ds\right)^{1/2}}.
\]
设 \(M=|\mathcal N_{k,m}|\)，\(z_n=\sqrt{n/C_m}\)，
\[
g=\sum_{n\in\mathcal N_{k,m}}z_nv_n,
\qquad \|g\|_2=1.
\]
对酉 Fourier 变换，\(\widehat g(\xi)=\sqrt{\varepsilon/(2\pi)}\,F_{w_k}(\varepsilon\xi)\sum_nz_ne^{-i\xi x_n}\)，其中
\(F_w(t)=\int_0^1 e_w(s)e^{-it(s-1/2)}ds\) 满足
\(|F_w(t)|\le\|e_w\|_1\le1\)。令 \(A_R=\int_{-R}^R|\widehat g(\xi)|^2d\xi\)。先去掉模不超过 \(1\) 的共同因子，再展开余下的指数和平方，使用
\(\left|\int_{-R}^Re^{i\xi t}d\xi\right|\le2/|t|\) 与
\(2|z_iz_j|\le |z_i|^2+|z_j|^2\)，按中心顺序求和，得
\[
A_R\le\frac{\varepsilon R}{\pi}
+\frac{2\varepsilon H_{M-1}}{\pi d}
\le\frac{\varepsilon R}{\pi}
+O\!\left(\frac{\log k}{m}\right).
\tag{D}
\]
这里 \(H_0=0\)，所以单 source 也适用。

原文单胞形式 \(\mathfrak b\) 由零延拓给出 Fourier 符号
\[
\mathfrak b[u]=\int_{\mathbb R}M(\xi)|\widehat u(\xi)|^2d\xi,
\qquad
M(\xi)=\int_0^1\frac{1-\cos(\xi h)}h\,dh
=\log|\xi|+O(1),
\]
并满足 \(\mathfrak b[u]\ge(\log2)\|u\|_2^2\)。任何在继承方向取坐标 \(1\) 的共同截口延拓都满足 \(\langle u,g\rangle=1\)。低高频 Cauchy–Schwarz 因此给出
\[
1\le\sqrt{\mathfrak b[u]}
\left(\sqrt{\frac{A_R}{\log2}}+\frac1{\sqrt{M(R)}}\right).
\tag{E}
\]
取 \(L=\log(1/\varepsilon)\)、\(\eta=L^{-1/2}\)、\(R=\varepsilon^{-1+\eta}\)。多项式带上
\[
L=\log(k/m)+O(1/m)\asymp_{a,b}\log k,\quad
A_RL=O(Le^{-\sqrt L}+L\log k/m)=o_{a,b}(1),
\]
而 \(M(R)=L-\sqrt L+O(1)\)。式 (E) 对每个允许的延拓给出
\[
P_{k,m}^{\rm ex}\ge(1-o_{a,b}(1))L.
\]
反向取合法的真实 ground 测试函数 \(u=g\)。若 \(v_n\) 零延拓，平移重叠相关为
\[
\int_{\mathbb R}v_n(x+\varepsilon r)v_n(x)\,dx
=\frac{\sinh((1-r)w_k/2)}{\sinh(w_k/2)}
\qquad(0\le r\le1).
\]
由零延拓形式，每个槽的能量恰为
\[
\mathfrak b[v_n]
=L+c(w_k),\qquad
c(w):=\int_0^1\frac{1-\sinh((1-r)w/2)/\sinh(w/2)}r\,dr
=1+O(w^2).
\]
最后的展开在 \(r\in[0,1]\) 上一致，余项带有因子 \(r\)，故可除以 \(r\) 后积分。不同槽的二次型交叉项因 \(z_n>0\)、\(v_n\ge0\) 且支撑不交而非正，故
\[
P_{k,m}^{\rm ex}\le\mathfrak b[g]\le L+c(w_k)=L+1+O(k^{-2}).
\]
这证明 (A)。这里只使用继承坐标的必要条件 \(\langle u,g\rangle=1\) 与测试函数 \(g\) 的可行性，不需要断言所有允许的 source transverse 坐标均已被短掉。

更直接地，(D) 对**任意**满足 \(\sum|z_n|^2=1\) 的复系数成立，(E) 也不要求 \(z_n\ge0\)。令 \(D_{k,m}^{\rm src}\) 为以真实 \(v_n\) 为基、同一次共同补集短化并允许槽内正交方向继续变分后的单胞矩阵；若固定槽内正交方向为零，以下上下界同样成立。因此
\[
D_{k,m}^{\rm src}\succeq(1-o_{a,b}(1))L\,I
\quad\text{一致于多项式 parent 带}.
\tag{A'}
\]
还有一个对全矩阵有效的上界。真实槽 ground 坐标中的压缩矩阵以 \(\mathfrak b[v_n]=L+c(w_k)\) 为对角。对 \(i\ne j\)，因支撑不交，极化给出
\[
|\mathfrak b(v_i,v_j)|
=\frac12\int_{I_i}\!\int_{I_j}
\frac{v_i(x)v_j(y)}{|x-y|}\,dx\,dy
\le\frac{\varepsilon}{2(|i-j|d-\varepsilon)},
\]
其中指标按区间中心排序，且 \(\int v_n\le\sqrt\varepsilon\)。在所述带内 \(\varepsilon/d=o(1)\)，故矩阵行和为 \(O((\varepsilon/d)H_{M-1})=O(\log k/m)\)。变分短算子不超过压缩，于是某个绝对常数 \(C\) 给出
\[
D_{k,m}^{\rm src}\preceq
\bigl(L+c(w_k)+C\log k/m\bigr)I.
\tag{A_+}
\]
令 \(\lambda_m=(\Lambda(n)/\sqrt n)_{n\in\mathcal N_{k,m}}\)，其范数平方正是下节的 \(F_m\)。由 (A')、(A_+) 和逆矩阵的 Loewner 反序得到
\[
\frac{F_m}{L+c(w_k)+C\log k/m}
\le
\langle\lambda_m,(D_{k,m}^{\rm src})^{-1}\lambda_m\rangle
\le
\frac{F_m}{(1-o_{a,b}(1))L}.
\tag{A''}
\]
于是其**完整 source-ground dual debit** 在带内为
\((1+o_{a,b}(1))F_m/\log(k/m)\)，求和后也为
\((b-a+o_{a,b}(1))\log k\)。这仍只是单胞 \(\mathfrak b\) 截口的 dual debit；与完整 Weil harmonic graph 的对应需单独核验。

## 算术总和

记 \(T_m=\log(k/m)\) 与 \(F_m=\sum_{n\in\mathcal N_{k,m}}\Lambda(n)^2/n\)。在多项式带内，\(L=T_m+O(1/m)\)，且各 \(\mathcal N_{k,m}\) 对应的整数区间拼成
\((k/(\lfloor k^b\rfloor+1),\,k/\lceil k^a\rceil]\)。故
\[
\sum_m\frac{F_m}{L}
=\sum_{\substack{k/(\lfloor k^b\rfloor+1)<n\le k/\lceil k^a\rceil\\n=p^\ell,\ n\nmid k}}
\frac{\Lambda(n)^2}{n\log n}+o(\log k)
=(b-a+o(1))\log k,
\]
其中第一步使用 \(\log n=T_m+O(1/m)\)，第二步是后文所列的素数定理与高次素数幂收敛。结合 (A'') 即得到完整 source-ground dual debit 的同一主项。

正交投影给出精确恒等式
\[
F_m-b_m^2
=\min_{c\in\mathbb R}\sum_{n\in\mathcal N_{k,m}}
\frac{(\Lambda(n)-cn)^2}{n}.
\tag{F}
\]
取 \(c=T_m/(k/m)\)。若 \(n=p\) 为素数，则 \(n/(k/m)\in(m/(m+1),1]\)，故
\[
|\Lambda(p)-cp|\ll T_m/m,
\qquad
\sum_{p\in\mathcal N_{k,m}}\frac{(\Lambda(p)-cp)^2}{p}
\ll m^{-2}F_m.
\]
若 \(n=p^\ell,\ell\ge2\)，则 \(cn\ll\log n\)，而
\[
\sum_{p,\ell\ge2}\frac{(\log p^\ell)^2}{p^\ell}<\infty.
\]
于是将 (F) 对带内 parent 除以 \(T_m\) 求和，得到
\[
\sum_{m}\frac{F_m-b_m^2}{T_m}
\ll k^{-2a}\sum_m\frac{F_m}{T_m}+O(1)
=o(\log k),
\tag{G}
\]
因为 \(T_m\gg_{a,b}\log k\) 且
\(\sum_{n\le k}\Lambda(n)^2/n\ll\log^2k\)。此外 \(\log n=T_m+O(1/m)\) 一致，故
\[
\sum_m\frac{b_m^2}{T_m}
=\sum_{\substack{k/(\lfloor k^b\rfloor+1)<n\le k/\lceil k^a\rceil\\n=p^\ell,\ n\nmid k}}
\frac{\Lambda(n)^2}{n\log n}+o(\log k).
\tag{H}
\]
高次素数幂对右侧贡献 \(O(1)\)。排除 \(n\mid k\) 的损失为 \(o(1)\)：此带内 \(n\gg k^{1-b}\)，整除 \(k\) 的素数幂项数至多 \(\log k/\log2\)，每项为 \(O(\log k/k^{1-b})\)。素数定理与分部求和给出
\[
\sum_{k^{1-b+o(1)}<p\le k^{1-a+o(1)}}\frac{\log p}{p}
=(b-a+o(1))\log k.
\]
再由 (A) 及 \(\theta_{k,m}^2=1+O(k^{-2a})\) 一致成立，式 (B) 随之得到。

对扩张带 (B0)，令 \(m_0=\lceil(\log k)^A\rceil\)、\(m_1=\lfloor k/(\log k)^B\rfloor\)。对应的 prime-power 区间是
\((k/(m_1+1),k/m_0]\)，上下端分别为 \((1+o(1))(\log k)^B\) 与 \((1+o(1))k/(\log k)^A\)。在此带上 \(T_m\ge B\log\log k+o(1)\)、\(L=T_m+O(1/m)\)。于是将 \(1/L\) 换成 \(1/\log n\) 的总误差至多
\[
O\!\left(\frac1{m_0(\log\log k)^2}
\sum_{n\le k}\frac{\Lambda(n)^2}{n}\right)=o(1).
\]
由 (F) 的同一测试 \(c=T_m/(k/m)\)，素数部分的投影误差至多
\(O(m_0^{-2}\sum F_m/T_m)=o(1)\)；高次素数幂的误差至多
\(O(1/\log\log k)\)。排除 \(n\mid k\) 的损失至多
\(O((\log k)\log\log k/(\log k)^B)=o(1)\)。最后素数定理给出
\[
\sum_{(1+o(1))(\log k)^B<p\le(1+o(1))k/(\log k)^A}
\frac{\log p}{p}=(1+o(1))\log k.
\]
由于 \(\theta_{k,m}^2=1+O(m_0^{-2})\)，(A)、(A')、(A'') 与上述估计共同证明 (B0) 所述的 aligned 及完整 source-ground dual debit 主项。

## 边界

由 (B) 还可测试一种精确限定的标量修补。原文的 mismatch 指标就是 \(V_{k,m}=F_m-b_m^2\)。对固定 \(m=1\)，素数定理给出
\[
F_1=(\log2+o(1))\log k,\qquad
b_1^2=(2/3+o(1))\log k,
\]
所以 \(V_{k,1}=(\log2-2/3+o(1))\log k\)，其主系数严格为正。若一个修补方案必须从同一个目标对角
\(B_k=\frac12+\log(1/w_k)=\log k+O(1)\)
独立支付全部纯 aligned 参考扣款以及原文的粗 mismatch 支付 \(\sum_m V_{k,m}/\log2\)，那么 (B) 对任意 \(a,b\) 给出
\[
\limsup_{k\to\infty}\frac1{\log k}
\left(B_k-\sum_m\frac{\theta_{k,m}^2b_m^2}{P_{k,m}^{\rm ex}}
-\frac1{\log2}\sum_mV_{k,m}\right)
\le-\frac{\log2-2/3}{\log2}<0.
\tag{I}
\]
这只关闭**把两种扣款分别按上述方式从同一个 \(B_k\) 支付**的修补；若真实完整形式有未复用的正项、联合 Schur 抵消或更小的真实 mismatch debit，式 (I) 不排除它们。它也不证明完整局部 Weil 形式正或负，没有触及 moving-\(N\) Möbius signed covariance 的目标上界。
