# 固定赋值状态与宏观对数轮廓的张量压缩严格正

日期：2026-10-03。依赖 [note 859](../notes/859-fixed-prime-valuation-profiles-retain-maximal-weil-grid-gap.md) 的固定素数赋值低能量极限、[scratch 978](978-macroscopic-log-profiles-have-rank-one-weil-limit.md) 的两层 Abel 求和，以及 [notes 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md)、[857](../notes/857-maximal-integer-log-grid-exact-weil-rayleigh-limit.md)、[858](../notes/858-unit-interval-logarithmic-form-has-a-strict-rank-one-gap.md) 的真实 Weil 形式输入。以下为解析证明草稿，尚未异源复核。结论只在固定有限维张量族内，不证明全尺度 Weil 正性或 RH。

## 定理

固定 $0<\theta<1$、非负实单位轮廓 $\varphi\in C_c^\infty((-1/2,1/2))$、有限素数集 $B$，以及每个 $q\in B$ 的固定截断赋值 $J_q\ge0$。令 $\mathcal E_B$ 是所有只依赖
$(\min(\nu_q(n),J_q))_{q\in B}$ 的实函数构成的有限维空间；按
\[
 \pi_q(j)=(1-q^{-1})q^{-j},\quad
 \pi_B=\bigotimes_{q\in B}\pi_q,
 \quad \langle F,G\rangle_B=\mathbb E_{\pi_B}(FG),
 \quad m_F=\mathbb E_{\pi_B}F
\]
赋予内积。若 $B=\varnothing$，取 $\mathcal E_B=\mathbb R\mathbf1$。固定有限维实空间 $V\subset\mathrm{BV}([0,1])$，假设 $1\in V$ 且 $V\to L^2[0,1]$ 单射。

沿奇素数 $p\to\infty$ 置
$H=\log p$、$N=\lfloor p^2/2\rfloor-1$、$L=\log N$、
$L_N=\sum_{n\le N}1/n$、$\ell=2\theta/p^2$，并沿用
$y_n=H-\log(2n)$、$b_\ell(t)=\ell^{-1/2}\varphi(t/\ell)$。
对 $F\in\mathcal E_B$、$f\in V$，在第 $n$ 个槽定义
\[
 \mathcal T_N(F,f)(y_n+t)
 =\frac{F((\nu_q(n))_{q\in B})f(\log n/L)}{\sqrt{nL_N}}b_\ell(t),
 \qquad 1\le n\le N.                                    \tag{1}
\]
则对固定 $F,G\in\mathcal E_B$、$f,g\in V$，一致有
\[
 \langle\mathcal T_N(F,f),\mathcal T_N(G,g)\rangle_{L^2}
 =\langle F,G\rangle_B\int_0^1fg
 +O_{B,V}\!\left(\frac{\|F\|_B\|G\|_B\|f\|_2\|g\|_2}{L}\right), \tag{2}
\]
\[
 \boxed{Q_W^H(\mathcal T_N(F,f),\mathcal T_N(G,g))
 =L\langle F,G\rangle_B
   \left(\int_0^1fg-\int_0^1f\int_0^1g\right)
 +O_{B,V,\theta,\varphi}\!\left(\|F\|_B\|G\|_B\|f\|_2\|g\|_2\right).} \tag{3}
\]
误差在 $F,G,f,g$ 的固定有限维单位球上一致。低宏观频率块的常数极限更精确：
\[
 \boxed{\lim_{p\to\infty}Q_W^H(\mathcal T_N(F,1),\mathcal T_N(G,1))
 =b_{\theta,\varphi}\langle F,G\rangle_B
   +D_B(F,G)+\theta\kappa_\varphi^2m_Fm_G,}             \tag{4}
\]
其中
\[
 b_{\theta,\varphi}=\log(1/\theta)+C_\varphi+\gamma-\log(2\pi),
\quad
 D_B(F,G)=\sum_{q\in B}(\log q)\sum_{t\ge1}q^{-t}
 \mathbb E_{\pi_B}\!\left[
 (F(\mathbf j)-F(\mathbf j+t\mathbf e_q))
 (G(\mathbf j)-G(\mathbf j+t\mathbf e_q))\right].
\]
式 (4) 在 $\mathcal E_B$ 上满足统一的严格下界
\[
 b_{\theta,\varphi}\|F\|_B^2+D_B(F,F)
   +\theta\kappa_\varphi^2m_F^2
 \ge\delta\|F\|_B^2,
 \qquad \delta=46/25-\log(2\pi)>0.                    \tag{5}
\]
因此对充分大 $p$，整个固定维空间
$\mathcal W_N=\operatorname{span}\{\mathcal T_N(F,f):F\in\mathcal E_B,f\in V\}$ 上有 $Q_W^H>0$。相对于物理 $L^2$ 范数，其 $\dim\mathcal E_B$ 个低本征值趋于式 (4) 的正算子本征值，其余本征值均为 $L+O_{B,V,\theta,\varphi}(1)$。

## 证明

**赋值测度与算术主项。** 置 $P=\prod_{q\in B}q^{J_q}$。对 $F,G\in\mathcal E_B$，序列
$w(n)=F(\boldsymbol\nu(n))G(\boldsymbol\nu(n))$ 是模 $P$ 周期序列；中国剩余定理给其周期平均恰为 $v_{FG}=\langle F,G\rangle_B$。逐同余类调和求和因而给，对全部 $u\ge0$，
\[
 \sum_{n\le e^u}\frac{w(n)}n=v_{FG}u+O_{B,F,G}(1).   \tag{6}
\]
另一方面，从 $\sum_{k\le e^u}\Lambda(k)/k=u+O(1)$ 删除素数 $q\in B$ 的幂，只花
$\sum_{q\in B}\sum_{t\ge1}(\log q)q^{-t}<\infty$；故
\[
 \sum_{\substack{k\le e^u\\k\text{ 为 }q^t,\ q\notin B}}
 \frac{\Lambda(k)}k=u+O_B(1)                         \tag{7}
\]
对全部 $u\ge0$ 一致。对 $q\notin B$，乘以 $k=q^t$ 不改变 $F,G$ 的赋值状态。用 (7) 在素数幂变量作 Stieltjes 分部积分，再用 (6) 在 $n$ 变量作同一分部积分，正如 scratch 978 式 (8)--(10)，得到整除矩阵中这些边的双线性项为
\[
 L v_{FG}\left(\int_0^1f\right)\left(\int_0^1g\right)+O_{B,V}(1).
\]
对 $q\in B$ 的幂，绝对值按
$\sum_{t\ge1}(\log q)q^{-t}<\infty$ 及
$L_N^{-1}\sum_{n\le N}1/n=1$ 直接给 $O_{B,V}(1)$。
因而完整素数幂 Weil 项是上述秩一主项的负值加 $O(1)$。

同一 (6) 对 $n$ 变量应用有界变差求积，给
$L_N^{-1}\sum_{n\le N}w(n)f(\log n/L)g(\log n/L)
=v_{FG}\int_0^1fg+O_{B,V}(L^{-1})$，即 (2)。单槽 Fourier--gamma 对角项等于
$(L+O_{\theta,\varphi}(1))$ 倍此内积。普通跨槽核的绝对双和、polar 矩由自然权全格的 $O_{\theta,\varphi}(1)$ 界乘 $\|F\|_\infty\|G\|_\infty\|f\|_\infty\|g\|_\infty$ 支付。合并给 (3)。固定空间上各范数等价，故误差对单位球一致。

**常数块。** 当 $f=g=1$ 时，固定赋值函数的直接极限完全依照 note 859 式 (5)--(11) 的逐项计算：
记 $W_N(F)=\sum_{n\le N}F(\boldsymbol\nu(n))^2/n$，则周期调和求和给
$W_N(F)/L_N\to\|F\|_B^2$。note 859 的 ground-state 恒等式与加权素数定理逐项给
\[
 Q_{\rm prime}[\mathcal T_N(F,1)]
=-(\log N-\gamma)\frac{W_N(F)}{L_N}
   +D_B(F,F)+o(1).
\]
同槽项是 $D_\ell W_N(F)/L_N$，其中
$D_\ell-\log N+\gamma\to b_{\theta,\varphi}$。周期相关的离散 Cauchy 核给普通项
$-\theta\kappa_\varphi^2m_F^2+o(1)$；两个极点矩给
$2\theta\kappa_\varphi^2m_F^2+o(1)$。所以四项相加为
$b_{\theta,\varphi}\|F\|_B^2+D_B(F,F)+\theta\kappa_\varphi^2m_F^2+o(1)$。
把 note 859 的中心 $4$、$M\sim p^2/4$ 改为这里的中心 $2$、$N\sim p^2/2$ 后，普通核只看中心差
$y_n-y_r=\log(r/n)$，故其极限仍是
$-\ell N\kappa_\varphi^2m_F^2=-\theta\kappa_\varphi^2m_F^2$。
对极点矩，$e^{y_n/2}=\sqrt{p/(2n)}$、
$e^{-y_n/2}=\sqrt{2n/p}$，所以两因子相乘时中心常数精确消去：
\[
P_+P_-=\frac{m_+m_-}{L_N}
\left(\sum_{n\le N}\frac{F(\boldsymbol\nu(n))}{n}\right)
\left(\sum_{n\le N}F(\boldsymbol\nu(n))\right)
\longrightarrow\theta\kappa_\varphi^2m_F^2.
\]
Weil 形式中的系数 $2$ 给前述
$2\theta\kappa_\varphi^2m_F^2$。同时
$\log(1/\ell)-\log N\to\log(1/\theta)$，故式 (4) 的常数未遗漏
中心因子。全部整数整除与中心核误差仍适用。对一般 $F,G$ 由实极化得到 (4)。

note 859 式 (12a) 的乘积概率方差界给
$D_B(F,F)\ge2\log2(\|F\|_B^2-m_F^2)$。
note 858 给
$C_\varphi+\kappa_\varphi^2+\gamma\ge46/25$，且
$\kappa_\varphi^2\le1<2\log2$、$-\log\theta\ge1-\theta$。
逐项重排即得 (5)。

**整个有限维张量块。** 令 $V_0=\{f\in V:\int_0^1f=0\}$。
按 $V=\mathbb R\mathbf1\oplus V_0$ 把系数空间分成
$\mathcal E_B\otimes\mathbf1$ 和 $\mathcal E_B\otimes V_0$。
式 (3) 在第二块给 $L I+O(1)$，两块交叉给 $O(1)$；式 (4)--(5) 在第一块给极限为严格正的算子。对高块作 Schur 配方，低块只损失 $O(L^{-1})$，所以全块充分大时严格正，且低本征值趋于 (4) 的本征值。式 (2) 给物理 Gram $I+O(L^{-1})$；转到物理归一化只使高本征值改变 $O(1)$、低本征值极限不变。$\square$

## 边界

这个张量族同时允许固定的宏观跳跃和有限个素数的赋值调制；严格正性覆盖它们的全部线性组合。本定理固定 $B,J_q,V,\varphi$；[scratch 980](980-slowly-growing-log-profile-spaces-remain-weil-positive.md) 在 $B,J_q,\varphi$ 固定且 BV 嵌入常数为 $o(\sqrt{\log N})$ 时允许 $V$ 增长。格外补空间与 note 849 式 (15) 的真实 moving-$N$ Möbius signed covariance 仍不在结论内。
