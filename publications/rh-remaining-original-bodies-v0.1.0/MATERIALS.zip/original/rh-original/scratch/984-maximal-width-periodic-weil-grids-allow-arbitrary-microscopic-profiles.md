# 最大槽宽固定周期 Weil 格允许随尺度变化的任意微观轮廓

日期：2026-10-03。依赖 [note 004](../notes/004-exact-logarithmic-laplacian-normalization.md)、[note 007](../notes/007-indefinite-polar-splitting-and-reduced-markov-form.md) 的完整 Weil 形式，[note 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md) 的整除图恒等式，[note 858](../notes/858-unit-interval-logarithmic-form-has-a-strict-rank-one-gap.md) 的一槽谱隙，以及 [scratch 983](983-arbitrary-microscopic-profiles-on-fixed-period-weil-grids.md) 的固定周期素数幂分解。新步骤是使用 Carleman 核支付最大槽宽处可能几乎相接的相邻槽，因而去掉 scratch 983 在 \(\theta=1\) 的统一支撑间隙条件。以下为解析证明草稿；异源复核前不晋级为权威结果。

## 定理

固定整数 \(P\ge1\)。对每个充分大的奇素数 \(p\)，任意取 \(0<\theta=\theta_p\le1\) 和
\[
T^{(p)}=(T_a)_{a\bmod P},\qquad
T_a\in C_c^\infty((-1/2,1/2);\mathbb C),\qquad
v=\frac1P\sum_{a\bmod P}\|T_a\|_2^2>0.
\]
轮廓、支撑及 \(\theta\) 均可随 \(p\) 任意变化。置
\[
H=\log p,\quad N=(p^2-3)/2,\quad L_N=\sum_{n\le N}n^{-1},\quad
\ell=2\theta/p^2,\quad y_n=H-\log(2n),
\]
并在 \(|t|<\ell/2\) 定义
\[
U_p(y_n+t)=\frac{\ell^{-1/2}T_{n\bmod P}(t/\ell)}{\sqrt{nL_N}}
\quad(1\le n\le N),
\]
其余处置零。存在只依赖 \(P\) 的 \(\varepsilon_P(N)\to0\)，使对全部这些选择同时成立
\[
\boxed{\quad
\|U_p\|_2^2=v\bigl(1+O_P(L_N^{-1})\bigr),\qquad
Q_W^H[U_p]\ge
\left(\frac{46}{25}-\log(2\pi)-\varepsilon_P(N)\right)v.
\quad}                                                       \tag{1}
\]
特别地，\(\theta=1\) 时**不要求**各 \(T_a\) 的支撑离 \(\pm1/2\) 有统一距离。结论是固定周期整数格上的完整 Weil **压缩**正性；它不支付格外补空间的 true-Schur 交叉，也不判定全尺度局部正性或 RH。

## 1. 几何与周期平均

记 \(T_n=T_{n\bmod P}\)、\(\kappa_n=\int_{-1/2}^{1/2}T_n\)。因 \(\ell\le2/p^2\) 且
\[
N(e^\ell-1)<N\frac{\ell}{1-\ell}
\le\frac{p^2-3}{p^2-2}<1,                              \tag{2}
\]
全部槽相离；任何素数幂位移连接两槽时，整数中心只能满足 \(r=kn\)，包括 \(\theta=1\)。各槽也严格位于 \((-H,H)\)。每个 \(p\) 只使用有限个光滑紧支撑轮廓，因此 \(U_p\in C_c^\infty((-H,H))\)，即使这些轮廓的支撑间隙趋于零也如此。

设 \(\mathcal H_P=L^2(-1/2,1/2)^{\mathbb Z/P\mathbb Z}\)，取均匀余数内积。\(\Pi\) 是单位群 \((\mathbb Z/P\mathbb Z)^\times\) 在余数上的平均投影。写 \(T=T^0+T^1\)，其中 \(T^0=\Pi T\)、\(T^1=(I-\Pi)T\)，并设
\[
l=\|T^0\|_P,\quad h=\|T^1\|_P,\quad v=l^2+h^2,\quad
s=\frac1P\sum_a|\kappa_a|^2,\quad
t=\left|\frac1P\sum_a\kappa_a\right|^2.
\]
将 \(\kappa=\Pi\kappa+(I-\Pi)\kappa\) 的平方范数记为 \(s=s_0+s_1\)。积分泛函在单位区间上的范数为 1，故 \(s_1\le h^2\)、\(t\le v\)。逐同余类调和求和给
\[
g_N:=\frac1{L_N}\sum_{n\le N}\frac{\|T_n\|_2^2}{n}
=v+O_P(v/L_N),\qquad
s_N:=\frac1{L_N}\sum_{n\le N}\frac{|\kappa_n|^2}{n}
=s+O_P(v/L_N).                                             \tag{3}
\]
这些误差对任意随 \(p\) 变化的 \(T_a\) 一致；只用 \(\max_a\|T_a\|_2^2\le Pv\)。槽相离使 \(\|U_p\|_2^2=g_N\)，得到 (1) 的范数式。

## 2. 最大宽度处的普通核中心替换

这是新证明步骤。记
\[
k(z)=\frac{e^{-z/2}}{1-e^{-2z}}\quad(z>0),\qquad
\mathcal K_{nr}=\ell\!\int_{-1/2}^{1/2}\!\int_{-1/2}^{1/2}
T_n(u)\overline{T_r(w)}
k\bigl(s_{nr}+\ell(u-w)\bigr)\,du\,dw,
\quad s_{nr}=\log(r/n),\quad n<r.                           \tag{4}
\]
由 note 007，普通跨槽项为 \(-2L_N^{-1}\sum_{n<r}\operatorname{Re}\mathcal K_{nr}/\sqrt{nr}\)。我们证明**一致于全部 \(0<\theta\le1\) 及轮廓**，
\[
\frac1{L_N}\sum_{n<r\le N}
\frac{|\mathcal K_{nr}-\ell\kappa_n\overline{\kappa_r}k(s_{nr})|}{\sqrt{nr}}
\ll_P \frac v{L_N}.                                        \tag{5}
\]

令 \(d=r-n\)。称 \(d\ge2\) 的配对以及 \(d=1,n\le N/3\) 的配对为常规配对。因 \(\ell<1/N\) 且
\(s_{nr}=\log(1+d/n)\ge d/r\ge d/N\)，对 \(d\ge2\) 有 \(\ell/s_{nr}\le1/2\)；对 \(d=1,n\le N/3\) 也有 \(\ell/s_{nr}<1/2\)（充分大 \(N\)）。函数 \(k\) 满足 \(|k'(z)|\ll z^{-2}\)，故这些配对上
\[
|\mathcal K_{nr}-\ell\kappa_n\overline{\kappa_r}k(s_{nr})|
\ll \frac{\ell^2}{s_{nr}^2}\|T_n\|_2\|T_r\|_2.         \tag{6}
\]
当 \(r\le2n\)，有 \((nr)^{-1/2}s_{nr}^{-2}\ll n/d^2\)。由 \(2ab\le a^2+b^2\)、\(\sum_{d\ge1}d^{-2}<\infty\) 和 \(\sum_{n\le N}n\|T_n\|_2^2\ll_P N^2v\)，这些配对在 (5) 中总计 \(O_P(\ell^2N^2v/L_N)=O_P(v/L_N)\)。当 \(r>2n\)，\(s_{nr}\ge\log2\)，用 \(\max_n\|T_n\|_2^2\le Pv\) 及 \(\sum_{n\le N}n^{-1/2}\ll\sqrt N\)，其贡献为 \(O_P(\ell^2Nv/L_N)\)。

仅余 \(d=1,n>N/3\)。这些槽可以任意接近，但 \(s_{n,n+1}>\ell\)。在 (4) 中令 \(x=u+1/2\)、\(y=1/2-w\)，则
\[
s_{n,n+1}+\ell(u-w)
=(s_{n,n+1}-\ell)+\ell(x+y)\ge\ell(x+y).
\]
因为 \(k(z)\ll1/z\)，积分核被 \(C/(x+y)\) 支配。Carleman 核在 \(L^2(0,1)\) 上范数至多 \(\pi\)：以 \(x^{-1/2}\) 作 Schur 权即可，因为
\(\int_0^\infty y^{-1/2}(x+y)^{-1}dy=\pi x^{-1/2}\)。因此
\[
|\mathcal K_{n,n+1}|+|\ell\kappa_n\overline{\kappa_{n+1}}k(s_{n,n+1})|
\ll\|T_n\|_2\|T_{n+1}\|_2.                         \tag{7}
\]
第二项还用了 \(\ell k(s)\ll\ell/s\le1\)。将 (7) 乘以 \((n(n+1))^{-1/2}\ll N^{-1}\) 后对 \(N/3<n<N\) 求和，并用周期平均或 \(\max\|T_a\|^2\le Pv\)，得到 \(O_P(v)\)；再除以 \(L_N\) 即得 (5)。这里不使用任何依赖轮廓支撑间隙的常数。

令 \(\bar\kappa=P^{-1}\sum_a\kappa_a\)。note 856 的精确中心核恒等式给
\[
\frac{k(\log(r/n))}{\sqrt{nr}}
=\frac12\left(\frac1{r-n}+\frac1{r+n}\right).          \tag{8}
\]
设 \(c_d=P^{-1}\sum_{a\bmod P}\operatorname{Re}(\kappa_a\overline{\kappa_{a+d}})\)。它是周期序列，\(|c_d|\le s\le v\)，其周期平均恰为 \(t=|\bar\kappa|^2\)。对每个 \(d\)，完整周期计数给
\(\sum_{n\le N-d}\operatorname{Re}(\kappa_n\overline{\kappa_{n+d}})
=(N-d)c_d+O_P(v)\)。周期调和求和于是给
\[
\sum_{n<r\le N}\frac{\operatorname{Re}(\kappa_n\overline{\kappa_r})}{r-n}
=N\log N\,t+O_P(Nv),
\qquad
\sum_{n<r\le N}\frac{|\kappa_n\kappa_r|}{r+n}\ll_P Nv. \tag{9}
\]
结合 (5)、(8)--(9) 与 \(\ell N=\theta(1-3/p^2)\)，得到
\[
Q_{\rm ord}=-\theta t+O_P(v/L_N)                       \tag{10}
\]
一致于全部 \(0<\theta\le1\)。

## 3. 其余项与正隙

记 \(\delta=46/25-\log(2\pi)>0\)、\(L=\log N\)。note 858 的一槽不等式逐 \(T_a\) 给
\(C[T_a]+|\kappa_a|^2+\gamma\|T_a\|_2^2\ge(46/25)\|T_a\|_2^2\)。note 857 的 Fourier--gamma 余项属于 \(L^1\)，且缩放后的 Fourier 变换满足 \(\|\widehat{\ell^{-1/2}T_a(\cdot/\ell)}\|_\infty^2\le\ell\|T_a\|_2^2\)。因此对角项在轮廓随 \(p\) 变化时仍一致满足
\[
Q_{\rm diag}\ge
\{\log(1/\ell)+\delta-\gamma\}g_N-s_N-O(\ell g_N).
\tag{11}
\]

整除图的逐项平方差恒等式（note 854 式 (12)）给
\[
Q_{\rm prime}=-(L-\gamma)g_N+D_N+o_P(1)v,
\quad
D_N=\frac1{L_N}\sum_{k\ge2}\frac{\Lambda(k)}k
\sum_{n\le N/k}\frac{\|T_n-T_{kn}\|_2^2}{n}\ge0.    \tag{12}
\]
这里 \(\sum_{k\le x}\Lambda(k)/k=\log x-\gamma+o(1)\)，而 \(\sum_{n\le N}\|T_n\|^2R(N/n)/(nL_N)=o_P(1)v\) 对周期 \(T_n\) 一致：先在 \(n\le N/A\) 用 \(\sup_{x\ge A}|R(x)|\to0\)，再用末段的逐余数调和质量 \(O_P(v\log A/L_N)\)。

由极点项 \(2\operatorname{Re}(P_+\overline{P_-})\)、\(e^{y_n/2}=\sqrt{p/(2n)}\)、\(e^{-y_n/2}=\sqrt{2n/p}\)，以及 \(\int\ell^{-1/2}T_n(u/\ell)e^{\pm u/2}du=\sqrt\ell\{\kappa_n+O(\ell\|T_n\|_2)\}\)，周期普通和及调和和给
\[
Q_{\rm pol}=2\theta t+O_P(v/L_N).                    \tag{13}
\]
估计对 \(\theta\le1\) 一致，因为所有局部指数误差随 \(\ell\) 减小。

为估计 \(D_N\)，将素数幂按 \((k,P)=1\) 与 \((k,P)>1\) 分割。固定模数素数定理及分部积分给各单位余数类的
\(\sum_{k\le x,k\equiv u\pmod P}\Lambda(k)/k=(\log x)/\varphi(P)+O_P(1)\)。对单位 \(u\) 置 \(b_u=P^{-1}\sum_a\|T_a^1-T_{ua}^1\|_2^2\)。把内层周期调和和代入 \(D_N\)，再对 \(k\) 作一次分部积分，得到
\[
D_N^{\rm unit}=\frac{L}{2\varphi(P)}\sum_{u\in G_P}b_u+O_P(h^2)
=Lh^2+O_P(h^2),                                          \tag{14}
\]
因为 \(\varphi(P)^{-1}\sum_u b_u=2h^2\)。坏素数幂仅来自 \(q\mid P\)；其 \(\sum_{j\ge1}(\log q)/q^j\) 有限。平方差展开给
\[
D_N^{\rm bad}(T)\ge D_N^{\rm bad}(T^0)-C_Plh,
\quad
D_N^{\rm bad}(T^0)=D_B(T^0)+O_P(l^2/L_N),          \tag{15}
\]
其中 \(D_B\) 是固定赋值状态的极限 Dirichlet 形式。对标量 \(a\mapsto\int T_a^0\) 使用 note 859 式 (12)--(12a) 的几何分布方差不等式与张量化，可得
\[
D_B(T^0)\ge2\log2\,(s_0-t).                       \tag{16}
\]
式 (14)--(16) 对任意微观维数一致，只含固定模数 \(P\)。

由 (10)--(13) 及 (3)，注意
\(\log(1/(\ell N))=\log(1/\theta)+O(N^{-1})\)，整理得
\[
\begin{aligned}
Q_W^H[U_p]-\delta v\ge{}&
\log(1/\theta)g_N-(1-\theta)t
+(2\log2-1)(s_0-t)\\
&+(L-C_P-1)h^2-C_Plh-o_P(1)v.                         \tag{17}
\end{aligned}
\]
这里保留了 \(\log(1/\theta)g_N\)，因此 \(\theta\) 可以趋于零而不放大 (3) 的误差。由 \(-\log\theta\ge1-\theta\)、\(g_N\ge t-O_P(v/L_N)\)，首行前两项至少为 \(-O_P(v/L_N)\)，而 \(2\log2-1>0\)。最后
\((L-C_P-1)h^2-C_Plh\ge-O_P(l^2/L)\ge-O_P(v/L)\)。这证明 (1)。

## 边界

唯一新增估计是 (5)：最大槽宽处失效的是逐点导数中心替换，相邻槽整体交叉本身仍有统一的 \(L^2\) 界。它只占 \(n>N/3\) 的一个调和壳，因而在自然权 \(1/(nL_N)\) 下为 \(O(1/\log N)\)。本定理仍固定周期 \(P\)；模数增长、任意非周期槽系数和完整补空间都没有由此解决。
