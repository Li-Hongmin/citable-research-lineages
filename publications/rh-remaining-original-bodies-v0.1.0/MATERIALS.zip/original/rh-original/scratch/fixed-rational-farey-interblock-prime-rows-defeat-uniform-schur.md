# 固定有理槽的两条素数臂使统一块范数 Schur 判据失效

日期：2026-09-30。探索推导，未晋级为定理。沿 [note 811](../notes/811-nonarithmetic-cross-blocks-are-paid-in-full-farey-constant-slots.md) 取固定 \(r>2/(1-3/\pi^2)\)，令 \(x=a/b\in(1,r)\) 为固定既约有理数、\(H=\log p\)、\(Q=\lfloor(p-1)/H\rfloor\)。对充分大的奇素数 \(p\)，\(x\in B_r\)。

若 \(q\nmid ab\) 为素数，\(Q/a<q\le(p-1)/a\)，则 \(y=aq/b=xq\in E_r\)，且 \(C^-(x,y)=+\log q/\sqrt q\)。若 \(Q/b<q\le(p-1)/b\)，则 \(z=bq/a=q/x\in E_r\)，且 \(C^-(x,z)=-\log q/\sqrt q\)。两类目标对充分大的 \(q\) 不交，也没有额外的素数幂关系改变这些条目。故
\[
\|P_{E_r}C^-e_x\|^2
\ge\sum_{Q/a<q\le(p-1)/a}\frac{(\log q)^2}{q}
+\sum_{Q/b<q\le(p-1)/b}\frac{(\log q)^2}{q}
-O_{a,b}(1).
\]
素数版 Mertens 估计 \(\sum_{q\le t}(\log q)/q=\log t+O(1)\) 经分部求和，给每个和 \(H\log H+O_{a,b}(H+(\log H)^2)\)，因此
\[
\|C^-_{E_rB_r}\|^2\ge(2+o(1))H\log H.
\]
note 810 给 \(B_r\) 的**统一**下界 \(g_B=\log H-\log\log H-O_r(1)\)，给 \(E_r\) 的下界 \(g_E=\gamma_rH-o(H)\)，其中 \(0<\gamma_r=1-2/r-3/\pi^2<1\)。于是 \(g_Bg_E=(\gamma_r+o(1))H\log H<(2+o(1))H\log H\le\|C^-_{E_rB_r}\|^2\)。只用这两个统一谱隙和交叉算子范数的 \(2\times2\) Schur 判据必然失败；该比较失败本身不表示真实压缩不定。固定槽 \(e_x\) 的实际对角能量为 \(2H+O_{a,b}(1)\)，远大于统一的 \(g_B\)，故下一步须用源位置相关的预算。
