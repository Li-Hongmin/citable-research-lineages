# 完整两臂 Gevrey 环带保留真实源的常量级负核瓣

日期：2026-10-02。依赖 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的完整两臂源核及其式 (18)、[scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的 Gevrey 截止构造、[scratch/927](927-high-ratio-odd-source-blocks-need-mobius-sign-cancellation.md) 的奇数平方自由计数，以及 [note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 的 Ramachandra 短和输入。[scratch/934](934-cofactor-three-bandpass-compensation-within-one-arm.md) 已在固定宽度环带定位高素数奇偶余项的积分负补偿；此处另外给出完整两臂 Gram 的近对数远位移截断，以及一个**逐项为负**、含真实非零 Möbius 源对的显式子环带的精确正负符号质量。净 signed 和在该子块仍未达到固定幂目标；完整 signed covariance、局部 Weil 全尺度正性及 RH 均未解决。本稿尚未异源复核。

## 定理

令 $M=2Y$，$Y^{1/5}\le H\le Y^{1/4}$。固定 $s>1$，可取实偶非负的 Gevrey-$s$ 权 $\eta$，支撑于 $1/2\le |t|\le4$，且 $\eta(t)=1$ 于 $1\le |t|\le2$。还可让这个权满足**显式负瓣**
\[
 \widehat\eta(z)\le-c_*<0\qquad(1/4\le z\le5/12),
 \quad c_*:=\sqrt2\,\frac{\sin(5\pi/12)}{5\pi/12}.             \tag{0}
\]
沿用 note 850 的 $D,R,G_\natural,T_\natural$、完整两臂 $\mathcal K_h(u)$、$G_{u,v}$ 与 $\mathfrak C_{\rm odd}$，取 $w_H(h)=\eta(h/H)$。对任意固定 $B>0$，存在 $C_{s,B,\eta,\psi}>0$，使
\[
 U_{s,B}=C_{s,B,\eta,\psi}\frac MH(\log M)^s                         \tag{1}
\]
满足完整乘子展开中的绝对远尾
\[
 \sum_{\substack{D<u,v<2M/3,\ u,v\ \mathrm{odd}\\
 k,\ell<64H\ \mathrm{active},\ |ku-\ell v|>U_{s,B}}}
 \left|\frac{W(k)W(\ell)}{M^2}
 \phi(ku/M)\overline{\phi(\ell v/M)}J_H(ku-\ell v)\right|
 \ll_{s,B,\psi,\eta}M^{-B}.                                      \tag{2}
\]
其中 $J_H(r)=\sum_h\eta(h/H)e(-hr/M)$。因此 note 850 式 (18) 的远端 $M^{1+\delta}/H$ 对此固定权可换成 $U_{s,B}$，仍有 $O_{s,B,\psi,\eta}(H^4/M)$ 误差。

此外，固定实非负 $\psi\in C_c^3((1,2))$，并取闭区间 $J\Subset(6/5,2)$，使 $\psi>0$ 于 $J$。记 $\phi(x)=\psi(x)/x$，$\kappa=-4\log(3/2)$，$\rho=4/\pi^2$，并固定 $\alpha=1/4$、$\beta=5/12$。令 $\mathcal U_M=\{u\text{ odd}:3u/M\in J\}$，并在完整两臂 Gram 中定义
\[
 P^\pm_{M,H}=
 \sum_{\substack{u,v\in\mathcal U_M,\ (u,v)\le G_\natural\\
 \alpha<3H(v-u)/M<\beta,\ \mu(u)\mu(v)=\pm1}}
 \mu(u)\mu(v)G_{u,v}.                                             \tag{3}
\]
则一致于上述 $H$，
\[
 P^+_{M,H}=-\frac{\mathscr N}{2}+o(1),\qquad
 P^-_{M,H}= \frac{\mathscr N}{2}+o(1),                              \tag{4}
\]
其中严格正的常数为
\[
 \mathscr N=\frac{\kappa^2\rho^2}{9}
 \left(\int_J\phi(x)^2\,dx\right)
 \left(\int_{1/4}^{5/12}-\widehat\eta(z)\,dz\right)
 \ge\frac{\kappa^2\rho^2c_*}{54}
 \int_J\phi(x)^2\,dx>0.                                        \tag{5}
\]
式 (3) 的每个非零 $G_{u,v}$ 都严格为负。这些项满足 note 850 的 $\max(a,b)>R$、$g=(u,v)\le G_\natural$ 及 $T_\natural<|ku-\ell v|\le U_{s,B}$，故负瓣确实处于完整两臂的留存环带。更精确地，若 $V_M=(\log M/\log\log M)^{1/3}$，则该子块的净 signed 和满足
\[
 P^+_{M,H}+P^-_{M,H}
 \ll_{\psi,\eta} e^{-cV_M}+G_\natural^{-1}+H\log M/M          \tag{5a}
\]
对某个固定 $c>0$ 一致成立。在每个固定内点范围 $H\le M^{1/4-\theta}$，$\theta>0$，右侧为 $O_{\theta,\psi,\eta}(e^{-c'V_M})$。式 (4) 是核符号与 Möbius 两种符号的分块极限；它不要求两个分块分别达到 $H^4/M$，也不决定完整 signed 和。

## Gevrey 远尾

可直接采用 scratch/860 的构造：以 $a=1/(s-1)$、$\rho_a(t)=e^{-t^{-a}}\mathbf1_{t>0}$ 生成满足 $S(v)=0$ 于 $v\le0$、$S(v)=1$ 于 $v\ge1$ 的 Gevrey-$s$ 平台函数。令
\[
 \chi_s(t)=S\!\left(\frac{3/5-|t|}{1/10}\right),\qquad
 \eta(t)=\chi_s(t-3/2)+\chi_s(t+3/2).                            \tag{6a}
\]
$\chi_s$ 实偶非负，支撑于 $[-3/5,3/5]$，在 $[-1/2,1/2]$ 上等于 $1$；$|t|$ 在零附近只遇到常值段，因此不损害光滑性。两次平移后的支撑互不相交，$\eta$ 在 $[1,2]\cup[-2,-1]$ 上等于 $1$，并支撑于 $9/10\le|t|\le21/10$。Cauchy 导数估计与重复分部积分给
\[
 \|\eta^{(n)}\|_\infty\le C_s^{n+1}(n!)^s,
 \qquad |\widehat\eta(\xi)|\le C_s e^{-c_s|\xi|^{1/s}}.        \tag{6}
\]
这同时核准显式负瓣：
\[
 \widehat\eta(z)=2\cos(3\pi z)\widehat\chi_s(z).
\]
当 $1/4\le z\le5/12$ 时，$\cos(3\pi z)\le-1/\sqrt2$；而 $|t|\le3/5$ 保证 $\cos(2\pi zt)\ge0$，且 $\chi_s=1$ 于 $[-1/2,1/2]$，故
\[
 \widehat\chi_s(z)
 =\int\chi_s(t)\cos(2\pi zt)\,dt
 \ge\int_{-1/2}^{1/2}\cos(2\pi zt)\,dt
 =\frac{\sin(\pi z)}{\pi z}
 \ge\frac{\sin(5\pi/12)}{5\pi/12}.
\]
于是得到 (0)。
对任意真实活动项，$m=ku$、$n=\ell v$ 都落在 $M\operatorname{supp}\phi\Subset(M,2M)$。故存在 $\sigma_\psi>0$ 使 $|m-n|\le(1-\sigma_\psi)M$。Poisson 求和及 (6) 给
\[
 |J_H(m-n)|\ll_{s,\psi,\eta}H\left[
 e^{-c(H|m-n|/M)^{1/s}}+e^{-c_\psi H^{1/s}}\right].       \tag{7}
\]
完整两臂所有活动源-乘子项的**绝对系数**总质量满足
\[
 \frac1M\sum_{\substack{u\text{ odd},\ D<u<2M/3\\k\ \mathrm{active}}}
 |W(k)\phi(ku/M)|
 \ll_\psi \sum_{k<64H}\frac{|W(k)|}{k}
       +\frac1M\sum_{k<64H}|W(k)|
 \ll_\psi\log^2 M.                                               \tag{8}
\]
式 (8) 同时计入奇臂与偶臂。取 (1) 中常数足够大，使 (7) 在 $|m-n|>U_{s,B}$ 上为 $O(HM^{-B-3})$；第二项因 $H\gg M^{1/5}$ 比任意负幂小。由 (8) 两次相乘得 (2)。再把 note 850 已证明的大共同因子及近位移绝对支付与 (2) 合并，即得所述更窄的完整 signed 环带。

## 负瓣及其真实源质量

式 (0) 已给 $[\alpha,\beta]=[1/4,5/12]$ 上的一致负界。更一般地，任何实偶非负且支撑离开零的光滑带通权都有某个负瓣：Fourier 反演给 $\int_{\mathbb R}\widehat\eta(z)\,dz=\eta(0)=0$，而 $\widehat\eta(0)=\int\eta>0$。

若 $u\in\mathcal U_M$，则 $u>2M/5$，所以所有 $k\ge5$ 的奇臂项及所有 $k\ge6$ 的偶臂项均不活动；$k=3$ 正好活动。完整两臂列精确化为
\[
 \mathcal K_h(u)=\frac\kappa M\phi(3u/M)e(-3hu/M),\qquad
 G_{u,v}=\frac{\kappa^2}{M^2}\phi(3u/M)\phi(3v/M)J_H(3(u-v)).  \tag{9}
\]
在 (3) 的位移范围，$z=3H(v-u)/M\in[\alpha,\beta]$。Poisson 公式与 (6) 的非零别名界一致给
\[
 H^{-1}J_H(3(u-v))=\widehat\eta(z)+O(e^{-cH^{1/s}})<-c_*/2, \tag{10}
\]
故 $G_{u,v}<0$。

先忽略 $(u,v)\le G_\natural$，计算绝对质量
\[
 A_{M,H}=
 -\sum_{\substack{u,v\in\mathcal U_M\\
 \alpha<3H(v-u)/M<\beta}}
 \mu(u)^2\mu(v)^2G_{u,v}.                                         \tag{11}
\]
奇数平方自由计数的初等恒等式 $\mu^2(n)=\sum_{d^2\mid n}\mu(d)$ 给每个 $x\asymp M$ 的区间端点上一致的
\[
 \sum_{n\le x,\ n\ \mathrm{odd}}\mu(n)^2
   =\rho x+O(\sqrt M),\qquad \rho=4/\pi^2.                   \tag{12}
\]
对固定 $u$，(11) 的 $v$ 权的上确界及总变差均为 $O_{\psi,\eta}(H)$：活动位移长度 $O(M/H)$，且 $J_H'=O(H^2/M)$。由 (12) 分部求和，内层 $\mu(v)^2$ 可换成密度 $\rho$ 的积分，总归一化误差 $O(H/\sqrt M)=o(1)$。积分后的 $u$ 权上确界为 $O(M)$、总变差粗界为 $O(HM)$，故外层 $\mu(u)^2$ 同样可换成 $\rho$ 积分，归一化误差仍为 $O(H/\sqrt M)$。

在所得双积分中令 $x=3u/M$、$z=3H(v-u)/M$，Jacobian 为 $M^2/(9H)$。由 (10)、$v-u=O(M/H)=o(M)$ 和 $J$ 两端只有 $O(H^{-1})$ 相对边界损失，
\[
 A_{M,H}\longrightarrow
 \frac{\kappa^2\rho^2}{9}
 \int_J\phi(x)^2dx\int_\alpha^\beta-\widehat\eta(z)dz
 =\mathscr N.                                                     \tag{13}
\]

删除 $(u,v)>G_\natural$ 的对只花 $o(1)$。事实上，置 $g=(u,v)$ 并暂时放宽互素性；因为 $v-u\asymp M/H$，固定 $g$ 时 $u$ 至多有 $O(M/g+1)$ 个选择，$v-u$ 至多有 $O(M/(Hg)+1)$ 个选择，且 $g\ll M/H$。由 (9)--(10)，每对 $|G_{u,v}|\ll H/M^2$。因而被删绝对质量至多
\[
 \frac H{M^2}\sum_{G_\natural<g\ll M/H}
   (M/g+1)(M/(Hg)+1)
 \ll \frac1{G_\natural}+\frac{H\log M}{M}=o(1).             \tag{14}
\]
这里 $G_\natural\gg\log^4 M$。

再证明 (5a)。令 $B_0=\lfloor M^{2/3}\rfloor$、$V_M=(\log M/\log\log M)^{1/3}$。先把 note 851 式 (4) 的全整数 Möbius 短和转换到奇整数。对任意区间 $I=(x,x+B_0]$、$x\asymp M$，记 $\mathfrak M_{\rm odd}(I)=\sum_{n\in I,\ n\ {\rm odd}}\mu(n)$、$\mathfrak M(I)=\sum_{n\in I}\mu(n)$。偶数 $n=2m$ 中仅奇数 $m$ 可能使 $\mu(2m)\ne0$，且此时 $\mu(2m)=-\mu(m)$，故有精确递推
\[
 \mathfrak M_{\rm odd}(I)=\mathfrak M(I)+\mathfrak M_{\rm odd}(I/2).
\]
取 $J_0=\lceil C V_M\rceil$，其中固定 $C$ 稍大。迭代到 $J_0$ 后，note 851 的 Ramachandra 界取 $\varepsilon=1/24$，对全部 $0\le j<J_0$ 给
\[
 |\mathfrak M(I/2^j)|\ll (B_0/2^j)e^{-c_0V_M}+(M/2^j)^{5/8},
\]
因为 $M/2^{J_0}=M^{1-o(1)}$，相应的 $V_{M/2^j}\asymp V_M$，且同一外部常数适用。末项 $|\mathfrak M_{\rm odd}(I/2^{J_0})|\le B_0/2^{J_0}+1$。几何求和及 $M^{5/8}/B_0=M^{-1/24+o(1)}$ 于是给某个固定 $c_1>0$ 的一致估计
\[
 |\mathfrak M_{\rm odd}(I)|\ll B_0e^{-c_1V_M}.              \tag{15}
\]
把 (3) 中固定 $u$ 后的 $v$ 区间分为完整 $B_0$ 块与两个短余块，利用 $M/H\ge cM^{3/4}$，得到一致前缀界
\[
 \sup_{I\subset[v_0,v_0+O(M/H)]}
 \left|\sum_{v\in I,\ v\ \mathrm{odd}}\mu(v)\right|
 \ll (M/H)e^{-c_1V_M}+B_0.                                       \tag{16}
\]
对 (9) 的 $v$ 权分部求和，内和为 $O(H((M/H)e^{-c_1V_M}+B_0))$。再对 $O(M)$ 个 $u$ 求和并乘 $M^{-2}$，未限制 gcd 的净和为 $O(e^{-c_1V_M}+HB_0/M)$。因 $HB_0/M\ll M^{-1/12}$，再用 (14) 即得 (5a)；与 (13)--(14) 的绝对质量联立便得 (4)。

最后核对它确实处在 note 850 的**完整留存环带**。$u,v\asymp M$ 使 $u,v>D$。由 (3)、$g\le G_\natural$，有 $a=u/g,b=v/g\gg M/G_\natural\gg H^4/\log^4M>R$。其唯一活动乘子为 $k=\ell=3$，物理位移 $|3(u-v)|\asymp M/H$；而 $T_\natural/(M/H)\ll1/\log^4M$、$U_{s,B}/(M/H)\to\infty$。因此全部这些项同时满足 $T_\natural<|\Delta|\le U_{s,B}$。$\square$

## 边界

负瓣内正负 Möbius 质量各有严格非零极限；式 (5a) 在固定幂内点仍只有次指数净节省。[scratch/931](931-squarefree-mask-complete-two-arm-band-below-target.md) 已对完整两臂平方自由掩码证明目标以下的频带能量；本稿没有重新证明那个模型界。完整 signed covariance 允许不同位移、不同乘子与两臂之间再抵消，所以本定理不给它的下界，也不把这个子块变成单独必须达到 $H^4/M$ 的门。它确定的是：将完整环带缩到近对数物理距离后，远于 $T_\natural$ 的负核瓣仍有真实非零源质量，不能按正核近块处理。
